// VacBot: drives a robot-vacuum sprite around a room layer (Squad House v6 + Renovation Catalog test room).
// start(key, o): o.host (element the sprite is appended to), o.src + o.bb ([x, y, w, h] of the sprite image relative to its floor point),
//   o.home() -> {x, y} dock point (re-read live), o.spot() -> {x, y} random free floor point, o.sAt(y) -> sprite scale, o.z(y) -> z-index,
//   o.ms cleaning time (default 5 min), o.speed px/s, o.onDone() when it is parked again.
// stop(key, now): drive home (now = remove at once). isOn(key), stopAll(now).
(function () {
  if (window.VacBot) return;
  const B = new Map(), r1 = v => Math.round(v * 10) / 10;
  function mk(o) { const d = document.createElement('div'); d.style.cssText = 'position:absolute;left:0;top:0;width:0;height:0;pointer-events:none;transform-origin:0 0';
    const w = document.createElement('div'); w.style.cssText = 'position:absolute;left:0;top:0;width:0;height:0;transform-origin:0 0';
    const im = document.createElement('img'); im.src = o.src; im.alt = ''; im.draggable = false; im.style.cssText = 'position:absolute;max-width:none;left:' + o.bb[0] + 'px;top:' + o.bb[1] + 'px;width:' + o.bb[2] + 'px;height:' + o.bb[3] + 'px';
    w.appendChild(im); d.appendChild(w); return { d, w, im }; }
  function put(b, x, y) { b.x = x; b.y = y; const s = b.o.sAt(y); b.E.d.style.left = r1(x) + 'px'; b.E.d.style.top = r1(y) + 'px'; b.E.d.style.transform = 'scale(' + s.toFixed(3) + ')'; b.E.d.style.zIndex = String(b.o.z(y)); }
  // the robot is round and left-right symmetric, so it never mirrors (that showed it was flat); a direction change = a quick turn wiggle
  function face(b, dx) { if (Math.abs(dx) < 3) return; const f = dx < 0 ? -1 : 1; if (f === b.f) return; b.f = f; b.E.w.animate([{ transform: 'rotate(0deg)' }, { transform: 'rotate(' + (f * 7) + 'deg) translateY(-1px)' }, { transform: 'rotate(' + (-f * 3) + 'deg)' }, { transform: 'rotate(0deg)' }], { duration: 420, easing: 'ease-out' }); }
  function dust(b) { const h = b.o.host; if (!h || !b.E.d.isConnected) return; const cs = getComputedStyle(b.E.d), x = parseFloat(cs.left), y = parseFloat(cs.top), s = b.o.sAt(y);
    const e = document.createElement('div'); const sz = 9 * s * (b.o.k || 1); e.style.cssText = 'position:absolute;pointer-events:none;left:' + r1(x - sz / 2 + (Math.random() - 0.5) * 16 * s) + 'px;top:' + r1(y - sz / 2 - 3 * s) + 'px;width:' + r1(sz) + 'px;height:' + r1(sz) + 'px;z-index:' + b.o.z(y - 1) + ';background:radial-gradient(circle,#ffffff 0,#ffffff 18%,rgba(223,246,255,0.7) 34%,rgba(223,246,255,0) 68%);clip-path:polygon(50% 0,61% 39%,100% 50%,61% 61%,50% 100%,39% 61%,0 50%,39% 39%)';
    h.appendChild(e); const a = e.animate([{ opacity: 0, transform: 'scale(0.4)' }, { opacity: 1, transform: 'scale(1.1)', offset: 0.25 }, { opacity: 0, transform: 'scale(0.6) translateY(-6px)' }], { duration: 1300, easing: 'ease-out' }); a.onfinish = () => e.remove(); }
  function go(b, p, cb, ms) { if (b.dead) return; const x0 = b.x, y0 = b.y, dx = p.x - x0, dy = p.y - y0, dist = Math.hypot(dx, dy), s0 = b.o.sAt(y0), s1 = b.o.sAt(p.y);
    face(b, dx); const dur = ms || Math.max(350, dist / (b.o.speed || 42) * 1000);
    b.an = b.E.d.animate([{ left: r1(x0) + 'px', top: r1(y0) + 'px', transform: 'scale(' + s0.toFixed(3) + ')', zIndex: b.o.z(y0) }, { left: r1(p.x) + 'px', top: r1(p.y) + 'px', transform: 'scale(' + s1.toFixed(3) + ')', zIndex: b.o.z(p.y) }], { duration: dur, easing: 'cubic-bezier(.45,0,.55,1)', fill: 'forwards' });
    b.an.onfinish = () => { if (b.dead) return; b.an = null; put(b, p.x, p.y); cb && cb(); }; }
  function wander(b) { if (b.dead || b.mode !== 'out') return; const p = b.o.spot(); if (!p) { b.tw = setTimeout(() => wander(b), 800); return; }
    go(b, p, () => { b.tw = setTimeout(() => wander(b), 250 + Math.random() * 700); }); }
  function kill(key) { const b = B.get(key); if (!b) return; b.dead = true; clearTimeout(b.tm); clearTimeout(b.tw); clearInterval(b.ti); if (b.an) b.an.cancel(); b.E.d.remove(); B.delete(key); }
  function start(key, o) { if (B.has(key)) return false; const h = o.home && o.home(); if (!h || !o.host) return false;
    const b = { o, E: mk(o), mode: 'out', f: 1, x: h.x, y: h.y }; B.set(key, b); o.host.appendChild(b.E.d); put(b, h.x, h.y);
    b.E.im.animate([{ transform: 'rotate(-1.2deg)' }, { transform: 'rotate(1.2deg)' }], { duration: 240, direction: 'alternate', iterations: Infinity, easing: 'ease-in-out' });
    b.ti = setInterval(() => { if (b.an) dust(b); }, 420);
    b.tm = setTimeout(() => stop(key), o.ms || 300000);
    go(b, { x: h.x + (o.out ? o.out[0] : 0), y: h.y + (o.out ? o.out[1] : 34) }, () => wander(b), 1100);
    return true; }
  function stop(key, now) { const b = B.get(key); if (!b) return; if (now) { kill(key); return; } if (b.mode === 'back') return;
    b.mode = 'back'; clearTimeout(b.tm); clearTimeout(b.tw);
    if (b.an) { const cs = getComputedStyle(b.E.d), x = parseFloat(cs.left), y = parseFloat(cs.top); b.an.cancel(); b.an = null; put(b, x, y); }
    const h = b.o.home && b.o.home(); if (!h) { const cb = b.o.onDone; kill(key); cb && cb(); return; }
    const o = b.o, ox = o.out ? o.out[0] : 0, oy = o.out ? o.out[1] : 34;
    go(b, { x: h.x + ox, y: h.y + oy }, () => { const h2 = o.home() || h; go(b, h2, () => { const cb = o.onDone; cb && cb(); setTimeout(() => kill(key), 140); }, 1100); }); }
  window.VacBot = { start, stop, isOn: k => B.has(k) && B.get(k).mode === 'out', busy: k => B.has(k), stopAll: now => [...B.keys()].forEach(k => now ? kill(k) : stop(k)), keys: () => [...B.keys()] };
})();
