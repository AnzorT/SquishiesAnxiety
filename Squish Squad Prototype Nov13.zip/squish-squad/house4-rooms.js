// Squad House v4: room shells built from decor surfaces (wall/floor/trim/window/light/art/door, yard fence/ground/lights), level locks, starter layouts.
(function boot() {
  const X = window.House3D; if (!(X && X.K && X.CAT)) { setTimeout(boot, 20); return; } if (X.SPEC) return;
  const K = X.K, { mix, shade, f1, circ, ell } = K, CR = '#fffaf1', WH = '#ffffff', GOLD = '#e2b14a', VW = 852, FY0 = X.FY0;
  const pd = (d, f, s, w, o) => ({ d, f, s: s || 'none', w: w || 0, o: o == null ? 1 : o });
  const rr = (x, y, w, h, r) => { r = Math.min(r, w / 2, h / 2); return 'M' + f1(x + r) + ' ' + f1(y) + 'H' + f1(x + w - r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x + w) + ' ' + f1(y + r) + 'V' + f1(y + h - r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x + w - r) + ' ' + f1(y + h) + 'H' + f1(x + r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x) + ' ' + f1(y + h - r) + 'V' + f1(y + r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x + r) + ' ' + f1(y) + 'Z'; };
  const BL = 100, BR = 752, WY = y => (652 + 1.235 * (y - 100)) / 652;
  const sideB = (s, t) => s === 'L' ? [BL - BL * t, 100 + 162 * t] : [BR + (852 - BR) * t, 100 + 162 * t];
  const lum = h => { const c = parseInt(h.slice(1), 16); return ((c >> 16 & 255) * 0.3 + (c >> 8 & 255) * 0.59 + (c & 255) * 0.11) / 255; };

  const SPEC = {
    w_peel: { pat: 'peel', b0: '#d9c9ae', b1: '#e6d9c2', pc: '#c2ab88' }, w_plaster: { pat: 'plaster', b0: '#e8dcc6', b1: '#f1e8d6', pc: '#d8c8aa' }, w_daisy: { pat: 'daisy', b0: '#f3ecd2', b1: '#faf4e2', pc: '#e8c860' },
    w_tile: { pat: 'tile', b0: '#d7ecf3', b1: '#e8f5f9', pc: '#bcdbe6' }, w_burst: { pat: 'burst', b0: '#bfe8e0', b1: '#d8f3ee', pc: '#ffffff' }, w_linen: { pat: 'linen', b0: '#e6e3dc', b1: '#efede8', pc: '#d4d0c6' },
    w_candy: { pat: 'candy', b0: '#e6ddff', b1: '#f1ebff', pc: '#fff4c0' }, w_damask: { pat: 'damask', b0: '#efe2c4', b1: '#f6ebd3', pc: '#d4ad5a' },
    f_boards: { ft: 'boards', f0: '#a88a66', f1: '#b89a74', f2: '#c4a882', fl: '#7d6248', fd: '#5e4632', fli: '#cbb08a', op: [0.55, 0.18, 0.7] }, f_lino: { ft: 'lino', f0: '#cfc6a8', f1: '#ddd5ba', f2: '#e8e1ca', fl: '#b5aa8a', fd: '#c2b896', fli: '#efe9d6', op: [0.4, 0.4, 0.5] },
    f_oak: { ft: 'wood', f0: '#c98d52', f1: '#e0a96e', f2: '#f0c590', fl: '#a86b36', fd: '#b87a40', fli: '#fff2d8', op: [0.22, 0.18, 0.42] }, f_check: { ft: 'checker', f0: '#f3efe6', f1: '#f8f5ee', f2: '#ffffff', fl: '#d8d0c0', fd: '#3d4048', fli: '#ffffff', op: [0.8, 0, 0.2] },
    f_lightup: { ft: 'dance', f0: '#1c1f4d', f1: '#22265a', f2: '#292e68', fl: '#3d4596', fd: '#2a2e66', fli: '#2a2e66', op: [0, 0, 0.6] }, f_herring: { ft: 'herring', f0: '#d6b98e', f1: '#e2c79e', f2: '#ecd5b0', fl: '#b8956a', fd: '#c9a87c', fli: '#f4e2c4', op: [0.3, 0.3, 0.55] },
    f_wafer: { ft: 'wafer', f0: '#e8c88e', f1: '#f0d6a2', f2: '#f6e2b8', fl: '#c9a466', fd: '#ddb878', fli: '#fbeecf', op: [0.3, 0.3, 0.7] }, f_marble: { ft: 'marble', f0: '#e8e4dc', f1: '#f2efe8', f2: '#faf8f3', fl: '#cfc8bb', fd: '#ddd6c8', fli: '#ffffff', op: [0.3, 0.5, 0.6] },
    f_ballroom: { ft: 'ballroom', f0: '#5e1a26', f1: '#6e2230', f2: '#7f2a3a', fl: '#c9963f', fd: '#521620', fli: '#ffe2a0', op: [0.5, 0.9, 0.45] },
    g_patchy: { ft: 'patchy', f0: '#a3b46a', f1: '#b2c27a', f2: '#bccb86', fl: '#7d8c48', fd: '#a88a5c', fli: '#c8d696', op: [0.75, 0.3, 0.55] }, g_clover: { ft: 'grass', f0: '#7fbd5e', f1: '#93cf70', f2: '#a5dc84', fl: '#6fae50', fd: '#86c466', fli: '#b2e494', op: [0, 0.22, 0.5] },
    g_patio: { ft: 'patio', f0: '#cfc8bb', f1: '#dcd6ca', f2: '#e6e1d6', fl: '#aea594', fd: '#c2baa8', fli: '#efebe2', op: [0.3, 0.3, 0.7] }, g_mint: { ft: 'grass', f0: '#9fe0c4', f1: '#b4ead2', f2: '#c6f1de', fl: '#7cc9a8', fd: '#a0dcc0', fli: '#fff4c0', op: [0, 0.3, 0.5] },
    g_cloud: { ft: 'cloud', f0: '#dfeefa', f1: '#eaf4fc', f2: '#f6fbff', fl: '#bcd8ee', fd: '#cfe4f4', fli: '#ffffff', op: [0, 0.9, 0.4] },
    t_scuff: { w0: '#b9ab92', w1: '#a99a80', trim: '#d9cdb5' }, t_ging: { w0: '#e3946a', w1: '#d4845a', trim: '#fffaf1' }, t_pastel: { w0: '#bfe3d4', w1: '#a3d3c0', trim: '#fffaf1' }, t_stripe: { w0: '#e2554a', w1: '#c9443a', trim: '#fffaf1' },
    t_min: { w0: '#3e4046', w1: '#34363b', trim: '#f1eee8' }, t_frost: { w0: '#fff1a0', w1: '#f3e48a', trim: '#ffffff' }, t_gold: { w0: '#7f2030', w1: '#6a1a28', trim: '#e2b14a' },
    win_crack: { k: 'crack', fr: '#cbbfa6' }, win_oil: { k: 'curt', fr: '#e8dcc6', cu: '#c9a85a' }, win_lace: { k: 'lace', fr: CR, cu: WH }, win_flower: { k: 'flower', fr: CR, cu: '#e3946a' },
    win_port: { k: 'port', fr: '#d5dde2' }, win_big: { k: 'big', fr: '#2c2d31' }, win_bonbon: { k: 'bonbon', fr: '#cdb8f5' }, win_arch: { k: 'arch', fr: GOLD, cu: '#7a1e2c' },
    l_none: { k: 'none' }, l_bulb: { k: 'bulb' }, l_jar: { k: 'jar' }, l_wicker: { k: 'wicker' }, l_neon: { k: 'neon' }, l_disco: { k: 'disco' }, l_globe: { k: 'globe' }, l_sprinkle: { k: 'sprinkle' }, l_chand: { k: 'chand' },
    a_none: { k: 'none' }, a_cards: { k: 'cards' }, a_map: { k: 'map' }, a_flowers: { k: 'flowers' }, a_clock: { k: 'clock' }, a_records: { k: 'records' }, a_canvas: { k: 'canvas' }, a_rainbow: { k: 'rainbow' }, a_portrait: { k: 'portrait' },
    d_scuff: { k: 'scuff', c: '#a89478', cl: '#bfae90' }, d_plank: { k: 'plank', c: '#b08a5e', cl: '#c9a576' }, d_arch: { k: 'arch', c: '#9ab886', cl: '#c4d8b2' }, d_jet: { k: 'jet', c: '#5cc8c0', cl: '#bfeee8' },
    d_flush: { k: 'flush', c: '#e9e5dc', cl: '#f6f4ef' }, d_ginger: { k: 'ginger', c: '#c98d52', cl: '#fffaf1' }, d_palace: { k: 'palace', c: '#f3ead6', cl: '#e2b14a' },
    y_broken: { k: 'broken', c: '#c9b896' }, y_picket: { k: 'picket', c: CR }, y_slat: { k: 'slat', c: '#9a7550' }, y_cane: { k: 'cane', c: WH }, y_gold: { k: 'gold', c: GOLD }, y_hedge: { k: 'hedge', c: CR },
    yl_none: { k: 'none' }, yl_tiki: { k: 'string' },
  };
  const DEF = { wall: 'w_peel', floor: 'f_boards', trim: 't_scuff', win: 'win_crack', light: 'l_bulb', art: 'a_none', door: 'd_scuff', fence: 'y_broken', ground: 'g_patchy', ylight: 'yl_none' };
  const SLOTS_IN = ['wall', 'floor', 'trim', 'win', 'light', 'art'], SLOTS_OUT = ['fence', 'ground', 'ylight'];
  const ROOMS = {
    living: { name: 'Living Room', unlock: 1, doors: [{ s: 'L', to: 'kitchen' }, { s: 'R', to: 'bathroom' }, { s: 'B', x: 620, to: 'dance', k: 'up' }], winX: 270, artX: 470, lightX: 380,
      start: [['saggySofa', 426, 168], ['crateTable', 426, 238], ['boxTV', 232, 156]] },
    kitchen: { name: 'Kitchen', unlock: 2, doors: [{ s: 'R', to: 'living' }, { s: 'B', x: 430, to: 'backyard', k: 'glass' }, { s: 'B', x: 612, to: 'bedroom', k: 'up' }], winX: 262, artX: 521, lightX: 340,
      start: [['icebox', 176, 150], ['wobblyCounter', 292, 150], ['rustyStove', 520, 152], ['crateStool', 440, 256]] },
    bathroom: { name: 'Bathroom', unlock: 4, doors: [{ s: 'L', to: 'living' }, { s: 'B', x: 640, to: 'backyard', k: 'door' }], winX: 290, artX: 412, lightX: 470, fixed: [['mirror', 520]],
      start: [['washtub', 300, 176], ['chipBasin', 520, 152], ['oldBasket', 690, 250]], toys: [['duck', 560, 302]] },
    bedroom: { name: 'Bedroom', unlock: 6, doors: [{ s: 'R', to: 'dance' }, { s: 'B', x: 620, to: 'kitchen', k: 'down' }], winX: 330, artX: 474, lightX: 410,
      start: [['oldMattress', 330, 198], ['crateStand', 432, 150], ['rickWard', 192, 154]] },
    backyard: { name: 'Backyard', unlock: 8, out: 1, doors: [{ s: 'B', x: 200, to: 'dance', k: 'up', lab: 'STAIRS' }, { s: 'B', x: 360, to: 'bathroom', k: 'door' }, { s: 'B', x: 600, to: 'kitchen', k: 'glass' }], fixed: [['hwin', 480], ['hwin', 690]],
      start: [['tireSwing', 470, 204], ['oldSandbox', 232, 284], ['leakyPool', 660, 286]], toys: [] }, // Nov 7: no default ball in the yard (user)
    dance: { name: 'Dance Room', unlock: 11, doors: [{ s: 'L', to: 'bedroom' }, { s: 'B', x: 200, to: 'living', k: 'down' }, { s: 'B', x: 640, to: 'backyard', k: 'down', lab: 'BALCONY' }, { s: 'R', to: 'movie' }], winX: null, artX: 290, lightX: 540, fixed: [['neon', 410, 'DANCE']],
      start: [['crateStage', 426, 164], ['boombox', 318, 150], ['recPlayer', 226, 198]] },
    movie: { name: 'Movie Room', unlock: 12, doors: [{ s: 'L', to: 'dance' }], artX: 470, lightX: 380,
      start: [] },
  };
  const RKEYS = ['living', 'kitchen', 'bathroom', 'bedroom', 'backyard', 'dance', 'movie'];
  const NAME = { living: 'LIVING ROOM', kitchen: 'KITCHEN', bathroom: 'BATHROOM', bedroom: 'BEDROOM', dance: 'DANCE ROOM', backyard: 'BACKYARD', movie: 'MOVIE ROOM' };
  const YARD = { b0: '#f6e7c4', b1: '#fbf1da', l0: '#9fd2f2', l1: '#d4ecf8', r0: '#9fd2f2', r1: '#d4ecf8', w0: '#e9d6ac', w1: '#dcc594', wr0: '#e9d6ac', wr1: '#dcc594', trim: CR, pat: '#e3cfa2', edge: '#2a4a1a' };
  const slotsOf = rk => ROOMS[rk].out ? SLOTS_OUT : SLOTS_IN;
  const specOf = (slot, id) => SPEC[id] || SPEC[DEF[slot]];
  function palette(rk, sf) {
    if (ROOMS[rk].out) { const g = specOf('ground', sf.ground); return Object.assign({}, YARD, { f0: g.f0, f1: g.f1, f2: g.f2, fl: g.fl, fd: g.fd, fli: g.fli, op: g.op, door: '#84b6c9', doorL: '#b4d6e2' }); }
    const w = specOf('wall', sf.wall), t = specOf('trim', sf.trim), f = specOf('floor', sf.floor), d = specOf('door', sf.door);
    return { b0: w.b0, b1: w.b1, l0: mix(w.b0, '#ffffff', 0.12), l1: w.b0, r0: shade(w.b0, 0.88), r1: shade(w.b0, 0.94), pat: w.pc, w0: t.w0, w1: t.w1, wr0: shade(t.w0, 0.9), wr1: shade(t.w1, 0.9), trim: t.trim,
      f0: f.f0, f1: f.f1, f2: f.f2, fl: f.fl, fd: f.fd, fli: f.fli, op: f.op, door: d.c, doorL: d.cl, edge: lum(f.f1) < 0.35 ? '#000000' : shade(f.f0, 0.45) };
  }
  // ---------- decor drawers ----------
  function curtains(o, x, y, w, h, c) { const D = shade(c, 0.85); [-1, 1].forEach(s => { const a = x + s * (w / 2 + 16), b = x + s * (w / 2 - 6); o.push(pd('M' + a + ' ' + (y - 8) + 'H' + b + 'Q' + (b + s * 7) + ' ' + (y + h / 2) + ' ' + (b - s * 2) + ' ' + (y + h + 10) + 'H' + (a + s * 3) + 'Q' + (a - s * 4) + ' ' + (y + h / 2) + ' ' + a + ' ' + (y - 8) + 'Z', c, D, 1), pd('M' + f1((a + b) / 2) + ' ' + (y - 6) + 'Q' + f1((a + b) / 2 + s * 2) + ' ' + (y + h / 2) + ' ' + f1((a + b) / 2) + ' ' + (y + h + 8), 'none', D, 1.4, 0.8)); }); o.push(pd(rr(x - w / 2 - 22, y - 11, w + 44, 5, 2.5), '#b97a42')); }
  function hill(o, x, y, w, h) { o.push(pd('M' + (x - w / 2) + ' ' + (y + h * 0.78) + 'Q' + f1(x - w / 6) + ' ' + f1(y + h * 0.52) + ' ' + f1(x + w / 8) + ' ' + f1(y + h * 0.7) + 'T' + (x + w / 2) + ' ' + f1(y + h * 0.64) + 'V' + (y + h) + 'H' + (x - w / 2) + 'Z', '#a8d08a')); }
  function window_(o, x, S) {
    const k = S.k, w = k === 'big' ? 140 : 76, h = 46, y = 12;
    if (S.ir) { const [a, b, iw, ih] = S.ir; o.push(pd('M' + f1(x + a) + ' ' + b + 'h' + iw + 'v' + ih + 'h' + (-iw) + 'Z', 'url(#rnWin)')); return; }
    if (k === 'port') { o.push(pd(circ(x, 36, 28), S.fr, shade(S.fr, 0.7), 1.5), pd(circ(x, 36, 22), 'url(#hsSky)'), pd(ell(x - 2, 40, 12, 4), WH, 0, 0, 0.9), pd('M' + (x - 22) + ' 46Q' + x + ' 34 ' + (x + 22) + ' 44', 'none', '#a8d08a', 6, 0.9)); for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; o.push(pd(circ(x + 25 * Math.cos(a), 36 + 25 * Math.sin(a), 1.8), '#8a949a')); } return; }
    if (k === 'bonbon') { const C = ['#cdb8f5', WH, '#bff0dc', WH, '#fff1a0', WH, '#bfe4ff', WH]; C.forEach((c, i) => { const a0 = i / 8 * Math.PI * 2, a1 = (i + 1) / 8 * Math.PI * 2; o.push(pd('M' + x + ' 36L' + f1(x + 30 * Math.cos(a0)) + ' ' + f1(36 + 30 * Math.sin(a0)) + 'A30 30 0 0 1 ' + f1(x + 30 * Math.cos(a1)) + ' ' + f1(36 + 30 * Math.sin(a1)) + 'Z', c)); }); o.push(pd(circ(x, 36, 23), 'url(#hsSky)'), pd(ell(x - 6, 30, 9, 4), WH, 0, 0, 0.9), pd('M' + (x - 23) + ' 44Q' + x + ' 34 ' + (x + 23) + ' 42', 'none', '#b4ead2', 7, 0.9)); return; }
    if (k === 'arch') { const a = 'M' + (x - 34) + ' 62V36Q' + (x - 34) + ' 4 ' + x + ' 4Q' + (x + 34) + ' 4 ' + (x + 34) + ' 36V62Z', b = 'M' + (x - 28) + ' 58V37Q' + (x - 28) + ' 10 ' + x + ' 10Q' + (x + 28) + ' 10 ' + (x + 28) + ' 37V58Z'; o.push(pd(a, 'url(#hsGold)', '#c9961f', 1.4), pd(b, 'url(#hsSky)'), pd(ell(x + 10, 24, 9, 4), WH, 0, 0, 0.9), pd('M' + x + ' 10V58M' + (x - 28) + ' 36H' + (x + 28), 'none', GOLD, 3)); curtains(o, x, 6, 64, 52, S.cu); o.push(pd(circ(x - 46, 40, 3.5), 'url(#hsGold)'), pd(circ(x + 46, 40, 3.5), 'url(#hsGold)'), pd(rr(x - 40, 62, 80, 6, 3), GOLD)); return; }
    o.push(pd(rr(x - w / 2 - 5, y - 5, w + 10, h + 10, k === 'big' ? 3 : 8), S.fr, shade(S.fr, 0.75), 1), pd(rr(x - w / 2, y, w, h, k === 'big' ? 2 : 5), 'url(#hsSky)'));
    if (k !== 'crack') o.push(pd(circ(x + w * 0.28, y + 12, 6), '#fff1a8'), pd(ell(x - w * 0.2, y + 14, 11, 4.5), WH)); hill(o, x, y, w, h);
    if (k === 'crack') o.push(pd(rr(x - w / 2, y, w, h, 5), '#8a7454', 0, 0, 0.28), pd('M' + (x - 30) + ' ' + (y + 6) + 'L' + (x - 16) + ' ' + (y + 18) + 'L' + (x - 22) + ' ' + (y + 26) + 'L' + (x - 6) + ' ' + (y + 38) + 'M' + (x - 16) + ' ' + (y + 18) + 'L' + (x - 4) + ' ' + (y + 14), 'none', WH, 1.4, 0.9), pd('M' + (x + 6) + ' ' + (y + 4) + 'L' + (x + 34) + ' ' + (y + 40), 'none', '#e8dcc0', 7, 0.95), pd('M' + (x + 34) + ' ' + (y + 4) + 'L' + (x + 6) + ' ' + (y + 40), 'none', '#e8dcc0', 7, 0.95));
    if (k !== 'big') o.push(pd(rr(x - 2, y, 4, h, 1), S.fr), pd(rr(x - w / 2, y + h / 2 - 2, w, 4, 1), S.fr));
    else o.push(pd(rr(x - w / 6 - 1.5, y, 3, h, 1), S.fr), pd(rr(x + w / 6 - 1.5, y, 3, h, 1), S.fr));
    o.push(pd(rr(x - w / 2 - 9, y + h + 4, w + 18, 6, 3), k === 'crack' ? '#b9ab92' : S.fr));
    if (k === 'curt' || k === 'flower') curtains(o, x, y, w, h, S.cu);
    if (k === 'lace') { curtains(o, x, y, w, h, '#ffffff'); for (let i = 0; i < 5; i++) o.push(pd(circ(x - w / 2 - 10 + (i % 2) * 6, y + 6 + i * 9, 1.6), '#e6e0d2'), pd(circ(x + w / 2 + 6 + (i % 2) * 4, y + 6 + i * 9, 1.6), '#e6e0d2')); }
    if (k === 'flower') { o.push(pd(rr(x - w / 2 - 4, y + h + 6, w + 8, 12, 3), '#b97a42')); ['#e3946a', '#f2c255', CR, '#c4a0e0', '#e3946a', '#f2c255'].forEach((c, i) => { const fx = x - w / 2 + 6 + i * (w - 12) / 5; o.push(pd(circ(fx, y + h + 4, 5.5), '#7ab45c'), pd(circ(fx, y + h + 2, 3.4), c)); }); }
  }
  function light(o, x, S, sw) {
    const k = S.k, cord = (y) => o.push(pd('M' + x + ' 0V' + y, 'none', '#6a5a4a', 1.6));
    if (k === 'none') return;
    if (k === 'halo') { o.push(pd('M' + (x - 30) + ' 0V30M' + (x + 30) + ' 0V30M' + x + ' 0V48', 'none', '#8a8fa8', 1));
      [[30, 42, 11, '#4fe0d0', '#d6fffa'], [40, 30, 8, '#8f7bff', '#e6e0ff'], [48, 18, 5, '#ff4fd8', '#ffe0f6']].forEach(([y, rx, ry, c, h]) => o.push(pd(ell(x, y, rx, ry), 'none', c, 12, 0.2), pd(ell(x, y, rx, ry), 'none', c, 4.4), pd(ell(x, y, rx, ry), 'none', h, 1.6), pd(ell(x - rx * 0.45, y - ry * 0.75, rx * 0.22, 1), '#ffffff', 0, 0, 0.8))); return; }
    if (k === 'laser') { const W = sw ? 36 : 90, Ln = sw ? 40 : 230, C = ['#ff3b6b', '#4fe0d0', '#a6f06a', '#8f7bff', '#ffd66b'];
      o.push(pd('M' + (x - W) + ' 0V8M' + (x + W) + ' 0V8', 'none', '#6a6f80', 1.4), pd(rr(x - W - 6, 8, 2 * W + 12, 7, 2), '#3a3d4a', '#22242e', 1), pd('M' + (x - W - 4) + ' 11.5H' + (x + W + 4), 'none', '#6a6f80', 0.8));
      for (let i = 0; i < 5; i++) { const h0 = x - W + i * W / 2, c = C[i]; for (let j = -1; j <= 1; j++) { const ex = h0 + j * (sw ? 9 : 70) + (i - 2) * (sw ? 3 : 24), ey = 15 + Ln, dl = 'M' + f1(h0) + ' 18L' + f1(ex) + ' ' + f1(ey); o.push(pd(dl, 'none', c, 3.6, 0.16), pd(dl, 'none', c, 1, 0.8)); if (!sw) o.push(pd(ell(ex, ey, 5, 2), c, 0, 0, 0.5)); }
        o.push(pd(rr(h0 - 5, 14, 10, 6, 2), '#22242e'), pd(circ(h0, 19, 2.2), c)); } return; }
    if (k === 'truss') { const W = sw ? 40 : 110, Ln = sw ? 36 : 170, C = ['#ff9d4a', '#4fe0d0', '#ff4fd8', '#ffd66b', '#6ac8ff'], n = sw ? 3 : 5;
      o.push(pd('M' + (x - W + 10) + ' 0V6M' + (x + W - 10) + ' 0V6', 'none', '#9aa0ae', 1.4), pd(rr(x - W, 6, 2 * W, 10, 1.5), '#c9cfd8', '#7a8090', 1));
      let z = ''; for (let i = 0; i <= 2 * W; i += 8) z += (i ? 'L' : 'M') + f1(x - W + i) + ' ' + ((i / 8) % 2 ? 15 : 7); o.push(pd(z, 'none', '#7a8090', 1));
      for (let i = 0; i < n; i++) { const h0 = x - W + 14 + i * (2 * W - 28) / (n - 1), c = C[i], tx = h0 + (i - (n - 1) / 2) * (sw ? 6 : 34), sp = sw ? 9 : 34;
        o.push(pd('M' + f1(h0 - 4) + ' 26L' + f1(tx - sp) + ' ' + (26 + Ln) + 'L' + f1(tx + sp) + ' ' + (26 + Ln) + 'L' + f1(h0 + 4) + ' 26Z', c, 0, 0, 0.14), pd('M' + f1(h0 - 7) + ' 16V24M' + f1(h0 + 7) + ' 16V24', 'none', '#2c2e38', 2), pd(circ(h0, 23, 6.5), '#2c2e38', '#1a1b22', 1), pd(circ(h0, 24.5, 3.6), c), pd(circ(h0 - 1.2, 23.4, 1.2), WH, 0, 0, 0.9)); } return; }
    if (k === 'crys') { cord(8); const R = ['#bff0ff', '#e6d9ff', '#ffe0f6', '#fff1b8', '#c8ffe6']; o.push(pd(circ(x, 34, 46), 'url(#gNeon)', 0, 0, 0.7), pd(ell(x, 22, 34, 7), 'none', GOLD, 3), pd(ell(x, 34, 22, 5), 'none', GOLD, 2.4), pd('M' + x + ' 8V40', 'none', GOLD, 2.4));
      for (let i = 0; i < 9; i++) { const a = i / 9 * Math.PI * 2, dx = Math.cos(a) * 34, dy = 22 + Math.sin(a) * 7, Lq = 10 + (i % 3) * 5; o.push(pd(circ(x + dx, dy + Lq * 0.5, 5.5), R[i % 5], 0, 0, 0.35), pd('M' + f1(x + dx) + ' ' + f1(dy) + 'l-3 ' + f1(Lq * 0.5) + 'l3 ' + f1(Lq * 0.5) + 'l3 -' + f1(Lq * 0.5) + 'z', R[i % 5], WH, 0.8, 0.95)); }
      for (let i = 0; i < 5; i++) { const dx = (i - 2) * 9; o.push(pd('M' + f1(x + dx) + ' 36l-2.6 8l2.6 9l2.6-9z', R[(i + 2) % 5], WH, 0.8)); } return; }
    if (k !== 'neon' && k !== 'disco') o.push(pd(circ(x, k === 'chand' ? 40 : 44, 44), 'url(#gWarm)', 0, 0, 0.8));
    if (k === 'bulb') { cord(22); o.push(pd(rr(x - 4, 20, 8, 7, 2), '#6a625c'), pd(circ(x, 32, 6.5), '#fff6c8', '#d9c48a', 1), pd(circ(x - 2, 30, 2), WH)); }
    else if (k === 'jar') { cord(14); o.push(pd(rr(x - 9, 14, 18, 4, 1.5), '#a9b0b4'), pd(rr(x - 10, 18, 20, 24, 6), '#fff4c8', '#c9b48e', 1.2), pd(circ(x, 30, 4), '#ffd66b'), pd(rr(x - 7, 21, 4, 14, 2), WH, 0, 0, 0.7)); }
    else if (k === 'wicker') { cord(16); o.push(pd('M' + (x - 24) + ' 40Q' + (x - 24) + ' 16 ' + x + ' 16Q' + (x + 24) + ' 16 ' + (x + 24) + ' 40Z', '#d9b47a', '#a8824e', 1.2), pd('M' + (x - 22) + ' 32H' + (x + 22) + 'M' + (x - 18) + ' 24H' + (x + 18) + 'M' + (x - 10) + ' 17V40M' + x + ' 16V40M' + (x + 10) + ' 17V40', 'none', '#b8925a', 1), pd(ell(x, 41, 14, 3.5), '#fff6c8')); }
    else if (k === 'neon') { cord(10); o.push(pd(circ(x, 32, 20), 'none', '#4fe0d0', 9, 0.3), pd(circ(x, 32, 20), 'none', '#bffcf4', 3)); o.push(pd(circ(x, 32, 13), 'none', '#ff9d4a', 7, 0.3), pd(circ(x, 32, 13), 'none', '#ffe0c0', 2.4)); }
    else if (k === 'disco') { o.push(pd('M' + x + ' 0V14', 'none', '#c9cde8', 2), pd(circ(x, 34, 22), 'url(#dBall)'), pd('M' + (x - 22) + ' 26H' + (x + 22) + 'M' + (x - 22) + ' 34H' + (x + 22) + 'M' + (x - 21) + ' 42H' + (x + 21) + 'M' + (x - 8) + ' 13V55M' + (x + 8) + ' 13V55', 'none', '#5a5f96', 1, 0.6), pd(rr(x - 13, 21, 8, 7, 1), WH, 0, 0, 0.85)); }
    else if (k === 'globe') { cord(14); o.push(pd(rr(x - 5, 12, 10, 5, 2), '#2c2d31'), pd(circ(x, 32, 16), '#f6f1e2', '#d6cdb6', 1), pd(circ(x - 5, 26, 5), WH, 0, 0, 0.9), pd(circ(x, 34, 6), '#fff1a8', 0, 0, 0.8)); }
    else if (k === 'sprinkle') { cord(14); o.push(pd('M' + (x - 22) + ' 36Q' + (x - 20) + ' 14 ' + x + ' 14Q' + (x + 20) + ' 14 ' + (x + 22) + ' 36Z', '#cdb8f5', '#a98be8', 1.2)); ['#4fe0d0', '#ffd66b', '#ff9d4a', '#a6f06a', '#6ac8ff'].forEach((c, i) => o.push(pd(rr(x - 15 + i * 7, 20 + (i % 2) * 7, 5, 2.4, 1.2), c))); for (let i = 0; i < 5; i++) o.push(pd('M' + (x - 22 + i * 11) + ' 36q2 6 0 8', 'none', '#bff0dc', 4)); o.push(pd(ell(x, 37, 12, 3), '#fff6c8')); }
    else if (k === 'chand') { cord(10); o.push(pd(circ(x, 12, 4), 'url(#hsGold)'), pd('M' + (x - 34) + ' 34Q' + x + ' 50 ' + (x + 34) + ' 34', 'none', GOLD, 3), pd('M' + (x - 20) + ' 28Q' + x + ' 40 ' + (x + 20) + ' 28', 'none', GOLD, 2.4), pd('M' + x + ' 12V44', 'none', GOLD, 3)); [-34, -20, 0, 20, 34].forEach((dx, i) => { const yy = i === 2 ? 44 : Math.abs(dx) > 30 ? 34 : 28; o.push(pd(rr(x + dx - 2.4, yy - 10, 4.8, 10, 1.5), CR), pd(ell(x + dx, yy - 13, 2.4, 3.6), '#ffb347'), pd('M' + (x + dx) + ' ' + (yy + 2) + 'l-3 6l3 5l3-5z', '#e9f7fd', '#bfe4ff', 0.8)); }); }
  }
  function art(o, x, S, T) {
    const k = S.k; if (k === 'none') return;
    if (k === 'cards') { [[-20, 22, -0.12, '#f2c255'], [6, 18, 0.1, '#84b6c9'], [-6, 40, 0.06, '#e3946a'], [20, 38, -0.08, '#9fc684']].forEach(([dx, y, r, c]) => { const cx = x + dx, w = 22, h = 15, co = Math.cos(r), si = Math.sin(r), P = [[-w / 2, -h / 2], [w / 2, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]].map(([a, b]) => [cx + a * co - b * si, y + a * si + b * co]); o.push(pd(K.pathOf(P), WH, '#c9bfa8', 1), pd(K.pathOf(P.map(([a, b]) => [cx + (a - cx) * 0.7, y + (b - y) * 0.6])), c, 0, 0, 0.8), pd(circ(cx, y - h / 2 + 1, 1.8), '#e2554a')); }); }
    else if (k === 'map') o.push(pd(rr(x - 32, 14, 64, 44, 2), '#efe0bc', '#c9b48e', 1.2), pd('M' + (x - 22) + ' 30q8-10 16-2t14 4q4 10-8 12t-18-4z', '#a8c88a', 0, 0, 0.9), pd('M' + (x + 8) + ' 22q10-4 16 4t-4 10z', '#a8c88a', 0, 0, 0.9), pd('M' + (x - 14) + ' 48l8-6l8 4l10-8', 'none', '#e2554a', 1.4), pd('M' + (x + 14) + ' 36l3 3m0-3l-3 3', 'none', '#e2554a', 1.6), pd(circ(x - 32, 14, 2.4), '#b8714a'), pd(circ(x + 32, 14, 2.4), '#b8714a'));
    else if (k === 'flowers') { o.push(pd(rr(x - 26, 12, 52, 50, 4), 'url(#hsWood)'), pd(rr(x - 21, 17, 42, 40, 2), '#fbf6e8')); [[-8, 30, '#e3946a'], [8, 26, '#c4a0e0'], [0, 42, '#f2c255']].forEach(([dx, y, c]) => { o.push(pd('M' + (x + dx) + ' ' + (y + 4) + 'Q' + (x + dx + 2) + ' ' + (y + 12) + ' ' + (x) + ' 54', 'none', '#7ab45c', 1.4)); for (let i = 0; i < 5; i++) { const a = i / 5 * Math.PI * 2; o.push(pd(circ(x + dx + 4 * Math.cos(a), y + 4 * Math.sin(a), 3), c)); } o.push(pd(circ(x + dx, y, 2), '#fff1a8')); }); }
    else if (k === 'clock') { for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2, r = i % 2 ? 26 : 32; o.push(pd('M' + f1(x + 18 * Math.cos(a)) + ' ' + f1(36 + 18 * Math.sin(a)) + 'L' + f1(x + r * Math.cos(a)) + ' ' + f1(36 + r * Math.sin(a)), 'none', i % 2 ? '#e2554a' : GOLD, 2.4)); o.push(pd(circ(x + r * Math.cos(a), 36 + r * Math.sin(a), 2.6), i % 2 ? '#e2554a' : '#5cc8c0')); } o.push(pd(circ(x, 36, 17), 'url(#hsClock)', '#c9b48e', 1.2), pd('M' + x + ' 36L' + (x - 6) + ' 30', 'none', '#3b2e28', 2.4), pd('M' + x + ' 36L' + (x + 8) + ' 27', 'none', '#3b2e28', 1.6), pd(circ(x, 36, 2), '#e2554a')); }
    else if (k === 'records') [[-24, 28], [2, 22], [26, 34]].forEach(([dx, y], i) => o.push(pd(circ(x + dx, y + 8, 14), '#2b2b33'), pd(circ(x + dx, y + 8, 9), 'none', '#4a4a56', 1), pd(circ(x + dx, y + 8, 5), ['#e2554a', '#ffd23f', '#5cc8c0'][i]), pd(circ(x + dx, y + 8, 1.2), '#2b2b33'), pd('M' + (x + dx - 8) + ' ' + (y + 2) + 'A10 10 0 0 1 ' + (x + dx + 2) + ' ' + (y - 2), 'none', WH, 1.4, 0.5)));
    else if (k === 'canvas') o.push(pd(rr(x - 28, 12, 56, 50, 1), '#fbfaf6', '#d4d0c6', 1.2), pd(circ(x - 8, 32, 12), '#e8b04a'), pd(rr(x - 2, 26, 22, 26, 1), '#c46a4a', 0, 0, 0.9), pd('M' + (x - 24) + ' 54Q' + x + ' 40 ' + (x + 24) + ' 50', 'none', '#5a6270', 3));
    else if (k === 'rainbow') { ['#ff9d4a', '#ffd66b', '#a6f06a', '#6ac8ff', '#8f7bff'].forEach((c, i) => { const r = 30 - i * 5.5; o.push(pd('M' + (x - r) + ' 58A' + r + ' ' + r + ' 0 0 1 ' + (x + r) + ' 58', 'none', c, 5.5)); }); o.push(pd(circ(x - 30, 56, 8), WH), pd(circ(x - 22, 54, 9), WH), pd(circ(x + 22, 54, 9), WH), pd(circ(x + 30, 56, 8), WH)); }
    else if (k === 'portrait') { o.push(pd(ell(x, 36, 26, 30), 'url(#hsGold)', '#c9961f', 1.2), pd(ell(x, 36, 20, 24), '#7a1e2c'), pd(ell(x, 44, 12, 11), '#fbe3c4'), pd(circ(x - 4, 42, 1.6), '#3b2e28'), pd(circ(x + 4, 42, 1.6), '#3b2e28'), pd('M' + (x - 9) + ' 33L' + (x - 9) + ' 24L' + (x - 4) + ' 29L' + x + ' 22L' + (x + 4) + ' 29L' + (x + 9) + ' 24L' + (x + 9) + ' 33Z', GOLD, '#c9961f', 1), pd('M' + (x - 4) + ' 48q4 3 8 0', 'none', '#c4651f', 1.4)); }
  }
  function rust(o, P) {
    const web = (x, s) => { let d = ''; for (let i = 1; i <= 3; i++) d += 'M' + x + ' ' + (i * 9) + 'Q' + (x + s * i * 5) + ' ' + (i * 6) + ' ' + (x + s * i * 9) + ' 0'; d += 'M' + x + ' 0L' + (x + s * 30) + ' 30M' + x + ' 0L' + (x + s * 14) + ' 34M' + x + ' 0L' + (x + s * 34) + ' 12'; o.push(pd(d, 'none', '#ffffff', 1, 0.7)); };
    web(BL, 1); web(BR, -1);
    o.push(pd(ell(214, 40, 18, 12), '#8a6a48', 0, 0, 0.12), pd(ell(600, 26, 14, 20), '#8a6a48', 0, 0, 0.1), pd(ell(60, 120, 16, 24), '#8a6a48', 0, 0, 0.1), pd(ell(790, 110, 18, 22), '#8a6a48', 0, 0, 0.1));
    o.push(pd('M380 0L386 10L382 18L390 30L386 40', 'none', shade(P.b0, 0.7), 1.4), pd('M660 66L652 54L656 46L648 36', 'none', shade(P.b0, 0.7), 1.4), pd('M30 160L42 150L38 138L50 128', 'none', shade(P.b0, 0.7), 1.4));
    o.push(pd('M540 4Q552 8 548 22Q546 30 556 34L560 4Z', '#f1e8d6', shade(P.b0, 0.8), 1), pd('M170 70Q176 60 186 66L190 52L172 54Z', '#f1e8d6', shade(P.b0, 0.8), 1));
  }
  function fixed(k, a, P, o, T) {
    const x = a[1];
    if (k === 'hwin') { const w = 54, h = 44, y = 22; o.push(pd(rr(x - w / 2 - 16, y - 2, 13, h + 4, 3), '#84b6c9'), pd(rr(x + w / 2 + 3, y - 2, 13, h + 4, 3), '#84b6c9'), pd(rr(x - w / 2 - 5, y - 5, w + 10, h + 10, 8), CR), pd(rr(x - w / 2, y, w, h, 5), 'url(#hsSky)'), pd(rr(x - 2, y, 4, h, 1), CR), pd(rr(x - w / 2, y + h / 2 - 2, w, 4, 1), CR)); }
    else if (k === 'mirror') o.push(pd(circ(x, 36, 26), 'url(#hsWood)'), pd(circ(x, 36, 21), 'url(#bMirror)'), pd('M' + (x - 12) + ' 30L' + (x - 2) + ' 20M' + (x - 9) + ' 42L' + (x + 9) + ' 24', 'none', WH, 4, 0.8));
    else if (k === 'neon') T.push({ x, y: 54, t: a[2], f: '#eafffb', s: '#4fe0d0', sz: 36, glow: 1 });
  }
  function fence(o, S) {
    const k = S.k, c = S.c;
    const posts = s => { let d = ''; const N = k === 'slat' ? 30 : 15; for (let i = 0; i < N; i++) { if (k === 'broken' && (i === 4 || i === 9 || i === 12)) continue; const t0 = i / N + (k === 'slat' ? 0.004 : 0.012), t1 = (i + 1) / N - (k === 'slat' ? 0.004 : 0.012), p = sideB(s, t0), q = sideB(s, t1), H = k === 'gold' ? 54 : k === 'slat' ? 50 : 40, tilt = k === 'broken' && i % 3 === 1 ? 6 : 0, hp = H * WY(p[1]), hq = H * WY(q[1]) - tilt; const tip = k === 'slat' ? 0 : k === 'gold' ? 12 : 7; d += 'M' + f1(p[0]) + ' ' + f1(p[1]) + 'L' + f1(q[0]) + ' ' + f1(q[1]) + 'L' + f1(q[0]) + ' ' + f1(q[1] - hq) + 'L' + f1((p[0] + q[0]) / 2) + ' ' + f1((p[1] + q[1]) / 2 - (hp + hq) / 2 - tip) + 'L' + f1(p[0]) + ' ' + f1(p[1] - hp) + 'Z'; } return d; };
    const rail = (s, f) => { const p = sideB(s, 0), q = sideB(s, 1); return 'M' + f1(p[0]) + ' ' + f1(p[1] - 40 * f * WY(p[1])) + 'L' + f1(q[0]) + ' ' + f1(q[1] - 40 * f * WY(q[1])); };
    const hedge = s => { let d = ''; for (let i = 0; i < 7; i++) { const p = sideB(s, (i + 0.5) / 7), r = 18 * WY(p[1]); d += circ(p[0] + (s === 'L' ? -r * 0.4 : r * 0.4), p[1] - 46 * WY(p[1]), r); } return d; };
    // 'hedge' = only the hedges + the house gutter: a renovation fence picture (Squad House v6 rnFenceL/R) is drawn over the sides instead of the posts
    if (k === 'hedge') { ['L', 'R'].forEach(s => o.push(pd(hedge(s), '#7ab45c', '#4f8a40', 2.5))); o.push(pd(rr(95, 0, 662, 9, 0), '#c4651f'), pd('M95 9H757', 'none', '#9a4a14', 2)); return; }
    ['L', 'R'].forEach(s => {
      o.push(pd(hedge(s), k === 'broken' ? '#93a86a' : '#7ab45c', k === 'broken' ? '#6c7f48' : '#4f8a40', 2.5));
      if (k !== 'slat') o.push(pd(rail(s, 0.35) + rail(s, 0.7), 'none', shade(c, 0.78), 4));
      o.push(pd(posts(s), c, shade(c, 0.75), 1.2));
      if (k === 'cane') { let d = ''; for (let i = 0; i < 15; i++) { const p = sideB(s, (i + 0.5) / 15); for (let j = 1; j < 4; j++) d += 'M' + f1(p[0] - 4) + ' ' + f1(p[1] - j * 11 * WY(p[1])) + 'l8 -4'; } o.push(pd(d, 'none', '#e2554a', 3)); }
      if (k === 'gold') { let d = ''; for (let i = 0; i < 15; i++) { const p = sideB(s, (i + 0.5) / 15); d += circ(p[0], p[1] - 62 * WY(p[1]), 3.4 * WY(p[1])); } o.push(pd(d, 'url(#hsGold)')); }
    });
    if (k === 'broken') o.push(pd('M40 230l20 -6l4 4l-20 7z', shade(c, 0.85), shade(c, 0.6), 1), pd('M800 220l-22 -4l-2 5l22 5z', shade(c, 0.85), shade(c, 0.6), 1));
    o.push(pd(rr(95, 0, 662, 9, 0), '#c4651f'), pd('M95 9H757', 'none', '#9a4a14', 2));
  }
  const qb = (t, a, b, c) => (1 - t) * (1 - t) * a + 2 * (1 - t) * t * b + t * t * c;
  function ylights(o, S) { if (S.k === 'none') return; const C = ['#ff9d4a', '#ffd66b', '#a6f06a', '#6ac8ff', '#8f7bff', '#4fe0d0'], W = '#5a4a40';
    if (S.k === 'fairy') { [[105, 8, 30, 747, 8], [105, 20, 46, 747, 20], [0, 60, 90, 100, 30], [852, 60, 90, 752, 30]].forEach(([x0, y0, ym, x1, y1], r) => { const xm = (x0 + x1) / 2; o.push(pd('M' + x0 + ' ' + y0 + 'Q' + xm + ' ' + ym + ' ' + x1 + ' ' + y1, 'none', '#6a5a4a', 0.8, 0.7)); const N = r < 2 ? 34 : 8; for (let n = 0; n < N; n++) { const t = (n + 0.5) / N, bx = qb(t, x0, xm, x1), by = qb(t, y0, ym, y1) + 1.5; o.push(pd(circ(bx, by, 5), '#fff4c8', 0, 0, 0.22), pd(circ(bx, by, 1.7), '#fffbe6')); } }); return; }
    if (S.k === 'festoon') { [[105, 6, 50, 520, 10], [332, 10, 54, 747, 6]].forEach(([x0, y0, ym, x1, y1]) => { const xm = (x0 + x1) / 2; o.push(pd('M' + x0 + ' ' + y0 + 'Q' + xm + ' ' + ym + ' ' + x1 + ' ' + y1, 'none', '#2c2d31', 1.4)); for (let n = 0; n < 10; n++) { const t = (n + 0.5) / 10, bx = qb(t, x0, xm, x1), by = qb(t, y0, ym, y1); o.push(pd('M' + f1(bx) + ' ' + f1(by) + 'v4', 'none', '#2c2d31', 1.4), pd(rr(bx - 2.4, by + 3, 4.8, 4, 1), '#2c2d31'), pd(circ(bx, by + 12, 12), '#ffe9a0', 0, 0, 0.2), pd(ell(bx, by + 12, 4.2, 5.6), '#fff1b8', '#e2b14a', 0.8), pd(ell(bx - 1.4, by + 10, 1.2, 2), WH, 0, 0, 0.85)); } }); return; }
    if (S.k === 'lantern') { o.push(pd('M105 10Q426 40 747 10', 'none', W, 1.2)); for (let n = 0; n < 9; n++) { const t = (n + 0.5) / 9, bx = qb(t, 105, 426, 747), by = qb(t, 10, 40, 10), c = C[n % 6], h = 13 + (n % 3) * 3; o.push(pd('M' + f1(bx) + ' ' + f1(by) + 'v5', 'none', W, 1), pd(circ(bx, by + 6 + h, h + 8), c, 0, 0, 0.18), pd(ell(bx, by + 6 + h, h * 0.9, h), c, shade(c, 0.7), 1), pd('M' + f1(bx - h * 0.9) + ' ' + f1(by + 6 + h) + 'H' + f1(bx + h * 0.9) + 'M' + f1(bx - h * 0.8) + ' ' + f1(by + 6 + h * 0.55) + 'H' + f1(bx + h * 0.8) + 'M' + f1(bx - h * 0.8) + ' ' + f1(by + 6 + h * 1.45) + 'H' + f1(bx + h * 0.8), 'none', shade(c, 0.75), 0.8), pd(rr(bx - 4, by + 4, 8, 3, 1), '#2c2d31'), pd(rr(bx - 4, by + 5 + h * 2, 8, 3, 1), '#2c2d31'), pd(ell(bx - h * 0.35, by + 6 + h * 0.6, h * 0.22, h * 0.3), WH, 0, 0, 0.45)); } return; }
    if (S.k === 'torch') { [[30, 150], [70, 92], [782, 92], [822, 150], [140, 30], [712, 30]].forEach(([x, y]) => { o.push(pd(rr(x - 2, y - 10, 4, 74, 2), '#8a6a3e', '#5a4020', 0.8), pd('M' + (x - 2) + ' ' + (y + 6) + 'h4M' + (x - 2) + ' ' + (y + 24) + 'h4', 'none', '#5a4020', 1), pd('M' + (x - 7) + ' ' + (y - 22) + 'L' + (x + 7) + ' ' + (y - 22) + 'L' + (x + 4) + ' ' + (y - 8) + 'L' + (x - 4) + ' ' + (y - 8) + 'Z', GOLD, '#8a5d00', 1), pd(circ(x, y - 34, 22), '#ffb340', 0, 0, 0.18), pd('M' + x + ' ' + (y - 46) + 'C' + (x + 9) + ' ' + (y - 34) + ' ' + (x + 7) + ' ' + (y - 24) + ' ' + x + ' ' + (y - 22) + 'C' + (x - 7) + ' ' + (y - 24) + ' ' + (x - 9) + ' ' + (y - 34) + ' ' + x + ' ' + (y - 46) + 'Z', '#ff9d2a'), pd('M' + x + ' ' + (y - 38) + 'C' + (x + 4) + ' ' + (y - 31) + ' ' + (x + 3) + ' ' + (y - 25) + ' ' + x + ' ' + (y - 24) + 'C' + (x - 3) + ' ' + (y - 25) + ' ' + (x - 4) + ' ' + (y - 31) + ' ' + x + ' ' + (y - 38) + 'Z', '#ffe9a0')); }); return; } o.push(pd('M105 14Q426 44 747 14', 'none', '#5a4a40', 1.6), pd('M0 70Q50 96 100 40', 'none', '#5a4a40', 1.6), pd('M852 70Q802 96 752 40', 'none', '#5a4a40', 1.6)); for (let n = 0; n < 18; n++) { const t = (n + 0.5) / 18, bx = (1 - t) * (1 - t) * 105 + 2 * (1 - t) * t * 426 + t * t * 747, by = (1 - t) * (1 - t) * 14 + 2 * (1 - t) * t * 44 + t * t * 14 + 6; o.push(pd(circ(bx, by, 9), C[n % 6], 0, 0, 0.25), pd(ell(bx, by, 3.6, 5), C[n % 6], shade(C[n % 6], 0.75), 0.8)); } }
  const ARROW = { up: '\u2191 ', down: '\u2193 ' };
  const SIGN = { scuff: ['#c9b896', '#7d6248', '#4a3a28'], plank: ['#c09a6c', '#6b4a2a', '#3d2814'], arch: ['#fff6e2', '#5f8a4a', '#3f5a30'], jet: ['#e4eaee', '#3d6a6a', '#245050'], flush: ['#2c2d31', '#16171a', '#f1eee8'], ginger: ['#c98d52', '#7a4a24', '#fffaf1'], palace: ['#f3ead6', '#b8862a', '#7a1e2c'] };
  const SHAPE = { scuff: 'rect', plank: 'rect', flush: 'rect', jet: 'round', arch: 'arch', ginger: 'arch', palace: 'arch' };
  // door outline in door space: u 0..1 across, v 0..1 up (v can exceed 1 for the frame)
  function outl(sh, ua, ub, vb, vt) { const P = [[ua, vb], [ub, vb]], m = (ua + ub) / 2, hw = (ub - ua) / 2;
    if (sh === 'arch') { const vs = vb + (vt - vb) * 0.64; P.push([ub, vs]); for (let i = 1; i < 14; i++) { const an = i / 14 * Math.PI; P.push([m + hw * Math.cos(an), vs + (vt - vs) * Math.sin(an)]); } P.push([ua, vs]); }
    else if (sh === 'round') { const ru = hw * 0.42, rv = (vt - vb) * 0.16; for (let i = 0; i <= 5; i++) { const an = i / 5 * Math.PI / 2; P.push([ub - ru + ru * Math.cos(an), vt - rv + rv * Math.sin(an)]); } for (let i = 0; i <= 5; i++) { const an = Math.PI / 2 + i / 5 * Math.PI / 2; P.push([ua + ru + ru * Math.cos(an), vt - rv + rv * Math.sin(an)]); } }
    else P.push([ub, vt], [ua, vt]);
    return P; }
  const ell2 = (cu, cv, ru, rv, n = 16) => Array.from({ length: n }, (_, i) => [cu + ru * Math.cos(i / n * Math.PI * 2), cv + rv * Math.sin(i / n * Math.PI * 2)]);
  const box2 = (ua, ub, va, vb) => [[ua, va], [ub, va], [ub, vb], [ua, vb]];
  function door(dd, P, o, T, R, sp, lockLv, noLab) {
    const dark = R.dark, k = sp.k || 'arch', side = dd.s !== 'B', x = dd.x;
    const isUp = !side && dd.k === 'up', isDn = !side && dd.k === 'down', base = 100, vh = 74;
    const t0 = 0.4, t1 = 0.68, M = side ? (u, v) => { const p = sideB(dd.s, t0 + (t1 - t0) * u); return [p[0], p[1] - 72 * WY(p[1]) * v]; } : (u, v) => [x - 31 + 62 * u, base - vh * v];
    const pth = pts => 'M' + pts.map(q => { const p = M(q[0], q[1]); return f1(p[0]) + ' ' + f1(p[1]); }).join('L') + 'Z', ln = (a, b) => { const p = M(a[0], a[1]), q = M(b[0], b[1]); return 'M' + f1(p[0]) + ' ' + f1(p[1]) + 'L' + f1(q[0]) + ' ' + f1(q[1]); };
    const special = !side && (dd.k === 'up' || dd.k === 'down' || dd.k === 'glass'), sh = special ? 'arch' : (SHAPE[k] || 'arch'), du = side ? 0.03 / 0.28 : 5 / 62, vt = side ? 1 : 1, fT = side ? 1.08 : 80 / 74;
    const frame = pth(outl(sh, -du, 1 + du, 0, fT)), inner = pth(outl(sh, 0, 1, 0, vt)), sc = side ? WY(M(0.5, 0)[1]) : 1;
    let st = null;
    if (isDn) st = downStairs(o, x, lockLv, dark);
    else { if (dark) o.push(pd(frame, '#4fe0d0', '#4fe0d0', 6, 0.35));
    o.push(pd(frame, k === 'palace' ? GOLD : P.trim, shade(dark ? '#4fe0d0' : P.trim, 0.8), 1.5)); }
    if (special) {
      if (isUp) {
        o.push(pd(inner, '#3a2414'));
        for (let i = 0; i < 5; i++) o.push(pd(rr(x - 27 + i * 3, base - (i + 1) * 8.5, 54 - i * 6, 8.5, 1), shade(i % 2 ? '#a86b36' : '#c98d58', 1 - i * 0.1)));
      } else if (isDn) {
      } else if (dd.k === 'glass') { o.push(pd(inner, 'url(#hsSky)'), pd('M' + (x - 31) + ' 84Q' + (x - 10) + ' 72 ' + (x + 8) + ' 80T' + (x + 31) + ' 78V100H' + (x - 31) + 'Z', '#a8d08a'), pd('M' + x + ' 26V100M' + (x - 31) + ' 62H' + (x + 31), 'none', P.trim, 4), pd(circ(x + 24, 66, 3.5), 'url(#hsGold)')); }
    } else {
      const D = P.door, DL = P.doorL;
      o.push(pd(inner, D));
      if (k === 'plank' || k === 'scuff') { o.push(pd(ln([0.25, 0], [0.25, 1]) + ln([0.5, 0], [0.5, 1]) + ln([0.75, 0], [0.75, 1]), 'none', shade(D, 0.78), 1.4), pd(pth(box2(0, 1, 0.27, 0.35)), shade(D, 0.85)), pd(pth(box2(0, 1, 0.68, 0.76)), shade(D, 0.85)), pd(ln([0, 0.31], [1, 0.72]), 'none', shade(D, 0.82), 3));
        if (k === 'scuff') o.push(pd(ln([0.15, 0.5], [0.32, 0.46]) + ln([0.6, 0.15], [0.8, 0.19]), 'none', shade(D, 0.62), 1.4)); }
      else if (k === 'jet') o.push(pd(pth(ell2(0.5, 0.66, 0.24, 0.16)), 'url(#hsSky)', '#d5dde2', 3 * sc), pd(pth(box2(0.14, 0.86, 0.3, 0.34)), DL), pd(pth(box2(0.14, 0.86, 0.2, 0.24)), DL));
      else if (k === 'flush') o.push(pd(ln([0.12, 0.02], [0.12, 0.98]), 'none', shade(D, 0.9), 1), pd(pth(box2(0.8, 0.86, 0.38, 0.64)), '#2c2d31'));
      else if (k === 'ginger') { o.push(pd(pth(outl('arch', 0.08, 0.92, 0.06, 0.92)), 'none', CR, 2.4 * sc)); [[0.3, 0.6, '#e2554a'], [0.7, 0.6, '#a6f06a'], [0.5, 0.36, '#6ac8ff']].forEach(([u, v, c]) => o.push(pd(pth(ell2(u, v, 0.08, 0.06, 12)), c), pd(pth(ell2(u - 0.025, v + 0.02, 0.025, 0.02, 8)), WH, 0, 0, 0.7)));
        let z = ''; for (let i = 0; i <= 8; i++) { const p = M(0.12 + i * 0.095, 0.16 + (i % 2) * 0.05); z += (i ? 'L' : 'M') + f1(p[0]) + ' ' + f1(p[1]); } o.push(pd(z, 'none', CR, 2.4 * sc)); }
      else { const pc = k === 'palace' ? 1 : 0.75; o.push(pd(pth(box2(0.15, 0.85, 0.08, 0.42)), DL, 0, 0, pc), pd(pth(outl('arch', 0.15, 0.85, 0.5, 0.9)), DL, 0, 0, pc));
        if (k === 'palace') o.push(pd(pth(box2(0.22, 0.78, 0.13, 0.37)), D), pd(pth(outl('arch', 0.22, 0.78, 0.55, 0.84)), D), pd(pth(box2(0.15, 0.85, 0.08, 0.42)), 'none', GOLD, 1.4 * sc)); }
      if (k !== 'flush') { const kp = M(0.86, 0.46); o.push(pd(circ(kp[0], kp[1], 4 * sc), 'url(#hsGold)')); }
    }
    if (lockLv && !isDn) { [[0.18, 0.3], [0.52, 0.64], [0.82, 0.94]].forEach(([a, b], i) => o.push(pd(pth(box2(-0.05, 1.05, a, b)), i % 2 ? '#a07a50' : '#b08a5e', '#7d6248', 1))); const m = M(0.5, 0.58); lock(o, m[0], m[1]); }
    if (!noLab) {
      const lab = lockLv ? 'Lv ' + lockLv + ' · ' + NAME[dd.to] : (ARROW[dd.k] || '') + (dd.lab ? dd.lab + ' · ' : '') + NAME[dd.to], S3 = lockLv ? SIGN.scuff : (SIGN[k] || SIGN.arch);
      const top = isDn ? [x, 74] : M(0.5, fT), cx = top[0], w = 14 + lab.length * 5.1, h = 15, cy = top[1] - 6 - h / 2, ny = cy - h / 2 - 7;
      o.push(pd('M' + f1(cx) + ' ' + f1(ny) + 'L' + f1(cx - w * 0.32) + ' ' + f1(cy - h / 2) + 'M' + f1(cx) + ' ' + f1(ny) + 'L' + f1(cx + w * 0.32) + ' ' + f1(cy - h / 2), 'none', '#6b4426', 1.2));
      o.push(pd(rr(cx - w / 2, cy - h / 2 + 1.5, w, h, 3), 'rgba(60,30,10,0.25)'), pd(rr(cx - w / 2, cy - h / 2, w, h, 3), dark && !lockLv ? '#1c1f4d' : S3[0], dark && !lockLv ? '#4fe0d0' : S3[1], 1.8));
      if (k === 'palace' && !lockLv) o.push(pd(rr(cx - w / 2 + 2.5, cy - h / 2 + 2.5, w - 5, h - 5, 2), 'none', GOLD, 1));
      if (k === 'ginger' && !lockLv) o.push(pd(rr(cx - w / 2 + 2.5, cy - h / 2 + 2.5, w - 5, h - 5, 2), 'none', CR, 1.2));
      o.push(pd(circ(cx, ny, 2.2), 'url(#hsGold)', '#6b4426', 0.8));
      T.push({ x: cx, y: cy + 3.6, t: lab, f: lockLv ? '#b23a2e' : dark ? '#bffcf4' : S3[2], sz: 8.8 });
    }
    if (st) return { hit: (isDn ? '' : frame) + st.hit, spawn: [st.foot, 134], walk: [st.foot, 176] };
    if (!side) return { hit: frame, spawn: [x, 134], walk: [x, 176] };
    const tm = (t0 + t1) / 2, y = Math.max(FY0 + 6, 100 + 162 * tm + 10), ex = X.edge(y) + 30;
    return { hit: frame, spawn: [dd.s === 'L' ? ex : VW - ex, y], walk: [dd.s === 'L' ? ex + 90 : VW - ex - 90, y + 10] };
  }
  // ---------- stairs: built on the floor in front of the back wall, with the room's perspective (WY) ----------
  const SC = 426, ST = { LH: 40, Z: 22 };
  const PW = (px, z, h) => { const s = WY(100 + z); return [SC + (px - SC) * s, 100 + z - h * s]; };
  const wp = (pts, open) => 'M' + pts.map(q => { const p = PW(q[0], q[1], q[2]); return f1(p[0]) + ' ' + f1(p[1]); }).join('L') + (open ? '' : 'Z');
  const WT = '#c98d58', WF = '#a86b36', WS = '#8e5a2c', WE = '#6b4426', RL = '#e2ad74', RD = '#7d5232', NOSE = '#e7b47e';
  function upStairs(o, x) {
    const dir = x > SC ? -1 : 1, Z = ST.Z, LH = ST.LH, hw = 34, n = 4, sw = 14, rise = 8, ex = x + dir * hw, far = x - dir * hw, foot = ex + dir * sw * n, hl = LH - rise * n;
    const blocks = [[x - hw, x + hw, LH]];
    for (let j = 0; j < n; j++) { const a = ex + dir * sw * j, b = ex + dir * sw * (j + 1); blocks.push([Math.min(a, b), Math.max(a, b), LH - rise * (j + 1)]); }
    const lo = Math.min(foot, far), hi = Math.max(foot, far);
    o.push(pd(wp([[lo - 3, Z - 4, 0], [hi + 3, Z - 4, 0], [hi + 6, Z + 5, 0], [lo - 6, Z + 5, 0]]), '#2a1608', 0, 0, 0.18));
    const wr = wp([[foot, 1, hl + 15], [ex, 1, LH + 15]], 1);
    let br = ''; for (let j = 1; j < n; j += 2) { const bx = ex + dir * sw * (j + 0.5), h = LH - rise * (j + 1) + 15; br += wp([[bx, 1, h], [bx, 1, h - 6]], 1); }
    o.push(pd(br, 'none', RD, 1.4), pd(wr, 'none', RD, 3.4), pd(wr, 'none', RL, 1.6));
    blocks.forEach(([a, b, h]) => { const xs = dir < 0 ? a : b;
      o.push(pd(wp([[xs, 0, h], [xs, Z, h], [xs, Z, 0], [xs, 0, 0]]), WS, WE, 1));
      o.push(pd(wp([[a, Z, h], [b, Z, h], [b, Z, 0], [a, Z, 0]]), WF, WE, 1));
      o.push(pd(wp([[a, 0, h], [b, 0, h], [b, Z, h], [a, Z, h]]), WT, WE, 1));
      o.push(pd(wp([[a + 1, Z, h], [b - 1, Z, h]], 1), 'none', NOSE, 1.4));
      if (h < LH) o.push(pd(wp([[a + 1, Z, h - 2.5], [b - 1, Z, h - 2.5]], 1), 'none', WE, 0.8, 0.5)); });
    o.push(pd(wp([[x - hw + 4, Z, LH - 10], [x + hw - 4, Z, LH - 10]], 1) + wp([[x - hw + 4, Z, LH - 22], [x + hw - 4, Z, LH - 22]], 1), 'none', WE, 0.8, 0.45));
    const RH = 17, zr = Z - 2.5, nx = foot - dir * 3;
    let posts = ''; for (let j = 0; j < n - 1; j++) { const px = ex + dir * sw * (j + 0.5), h = LH - rise * (j + 1); posts += wp([[px, zr, h], [px, zr, h + RH]], 1); }
    for (let i = 0; i <= 5; i++) { const px = ex - dir * (2 * hw - 3) * i / 5; posts += wp([[px, zr, LH], [px, zr, LH + RH]], 1); }
    for (let i = 1; i < 3; i++) { const z = zr * i / 3; posts += wp([[far + dir * 3, z, LH], [far + dir * 3, z, LH + RH]], 1); }
    const rail = wp([[nx, zr, hl + RH + 2], [ex, zr, LH + RH], [far + dir * 3, zr, LH + RH], [far + dir * 3, 1, LH + RH]], 1);
    o.push(pd(posts, 'none', RD, 1.6), pd(wp([[nx, zr, hl], [nx, zr, hl + RH + 3]], 1), 'none', RD, 4.4), pd(wp([[nx, zr, hl], [nx, zr, hl + RH + 3]], 1), 'none', RL, 2));
    o.push(pd(rail, 'none', RD, 4.4), pd(rail, 'none', RL, 2.2));
    const k = PW(nx, zr, hl + RH + 4); o.push(pd(circ(k[0], k[1], 3), RL, RD, 1.2));
    const hit = wp([[lo - 4, 0, 0], [hi + 4, 0, 0], [hi + 4, Z + 4, 0], [lo - 4, Z + 4, 0]]) + wp([[x - hw, Z, LH + RH], [x + hw, Z, LH + RH], [x + hw, Z, 0], [lo, Z, 0], [lo, Z, hl + RH]]);
    return { hit, foot: foot + dir * 10 };
  }
  function downStairs(o, x, lockLv, dark) {
    const dir = x > SC ? -1 : 1, Z = 34, hw = 46, n = 5, d = 6.4, sw = 2 * hw / n, a = x - hw, b = x + hw, ent = dir < 0 ? a : b, far = ent - dir * 2 * hw;
    const pit = wp([[a, 0, 0], [b, 0, 0], [b, Z, 0], [a, Z, 0]]);
    o.push(pd(pit, dark ? '#0e0b20' : '#2a1a10'));
    for (let j = 0; j < n; j++) { const dj = d * (j + 1); if (dj >= Z) break; const x0 = ent - dir * sw * j, x1 = ent - dir * sw * (j + 1), tc = shade(WT, 1 - j * 0.16);
      const zc = Z - dj; o.push(pd(wp([[x0, 0, -dj], [x1, 0, -dj], [x1, zc, -dj], [x0, zc, -dj]]), tc));
      o.push(pd(wp([[x0, 0, -dj], [x1, 0, -dj]], 1), 'none', '#1a0e06', 1.6, 0.6));
      if (j < n - 1) o.push(pd(wp([[x1, 0, -dj], [x1, zc, -dj]], 1), 'none', NOSE, 1.6, 0.85 - j * 0.15)); }
    o.push(pd(wp([[a, 0, 0], [b, 0, 0], [b, 7, 0], [a, 7, 0]]), '#000000', 0, 0, 0.22));
    o.push(pd(pit, 'none', WE, 2), pd(wp([[a, Z, 0], [b, Z, 0]], 1), 'none', NOSE, 1.2, 0.6));
    if (lockLv) { [0, 1, 2].forEach(i => o.push(pd(wp([[a - 5, 2 + i * 8.6, 0], [b + 5, 2 + i * 8.6, 0], [b + 5, 8.5 + i * 8.6, 0], [a - 5, 8.5 + i * 8.6, 0]]), i % 2 ? '#a07a50' : '#b08a5e', '#7d6248', 1))); const m = PW(x, Z / 2, 0); lock(o, m[0], m[1] - 4); }
    const RH = 15, zr = Z + 1.5, s0 = ent - dir * 3, s1 = far + dir * 2;
    let posts = ''; for (let i = 1; i <= 4; i++) { const px = s0 + (s1 - s0) * i / 4; posts += wp([[px, zr, 0], [px, zr, RH]], 1); }
    for (let i = 1; i < 3; i++) { const z = zr * i / 3; posts += wp([[s1, z, 0], [s1, z, RH]], 1); }
    const rail = wp([[s0, zr, RH + 1], [s1, zr, RH], [s1, 1, RH]], 1);
    o.push(pd(posts, 'none', RD, 1.6), pd(wp([[s0, zr, 0], [s0, zr, RH + 3]], 1), 'none', RD, 4.4), pd(wp([[s0, zr, 0], [s0, zr, RH + 3]], 1), 'none', RL, 2));
    o.push(pd(rail, 'none', RD, 4.4), pd(rail, 'none', RL, 2.2));
    const k = PW(s0, zr, RH + 4); o.push(pd(circ(k[0], k[1], 3), RL, RD, 1.2));
    const hit = wp([[a - 4, 0, RH], [b + 4, 0, RH], [b + 4, Z + 5, 0], [a - 4, Z + 5, 0]]);
    return { hit, foot: ent + dir * 14 };
  }
  function lock(o, x, y) { o.push(pd('M' + (x - 5) + ' ' + (y - 2) + 'V' + (y - 7) + 'a5 5 0 0 1 10 0V' + (y - 2), 'none', '#5a5450', 2.6), pd(rr(x - 8, y - 2, 16, 13, 3), 'url(#hsGold)', '#a87a1a', 1), pd(circ(x, y + 4, 1.8), '#7a5a10')); }
  function boards(o, x, y, w, h) { o.push(pd(rr(x, y + h * 0.18, w, 11, 2), '#b08a5e', '#7d6248', 1), pd(rr(x, y + h * 0.55, w, 11, 2), '#a07a50', '#7d6248', 1), pd('M' + x + ' ' + (y + h) + 'L' + (x + 8) + ' ' + (y + h + 6) + 'L' + (x + w) + ' ' + (y + 6) + 'L' + (x + w - 8) + ' ' + y + 'Z', '#c09a6c', '#7d6248', 1)); [[x + 4, y + h * 0.18 + 5], [x + w - 4, y + h * 0.18 + 5], [x + 4, y + h * 0.55 + 5], [x + w - 4, y + h * 0.55 + 5]].forEach(([a, b]) => o.push(pd(circ(a, b, 1.4), '#5a5450'))); lock(o, x + w / 2, y + h * 0.42); }

  // k < 1 = big room: denser floor pattern so tiles match the smaller furniture/creatures
  const rowsK = (A, k) => { if (k === 1) return A; const o = []; for (let p = 0; p < A.length - 1 - 1e-6; p += k) { const i = Math.floor(p), f = p - i; o.push(Math.round(A[i] + (A[i + 1] - A[i]) * f)); } o.push(A[A.length - 1]); return o; };
  function floor(type, k) {
    k = k || 1;
    const H = 100, sp0 = 562 / 16.5 * k, sp1 = sp0 * WY(393), xb = (j, y) => 426 + j * (sp0 + (sp1 - sp0) * (y - H) / 293);
    const quad = (j, a, b, step) => 'M' + f1(xb(j, a)) + ' ' + a + 'L' + f1(xb(j + step, a)) + ' ' + a + 'L' + f1(xb(j + step, b)) + ' ' + b + 'L' + f1(xb(j, b)) + ' ' + b + 'Z';
    const RW = rowsK([100, 114, 130, 149, 171, 197, 228, 265, 310, 393], k), RB = rowsK([100, 122, 148, 180, 218, 264, 320, 393], k), RT = rowsK([100, 113, 128, 145, 165, 188, 215, 246, 283, 330, 393], k);
    let lines = '', dark = '', light = '', tiles = [];
    const vl = (a, b, st) => { for (let j = a; j <= b; j += st) lines += 'M' + f1(xb(j, H)) + ' ' + H + 'L' + f1(xb(j, 393)) + ' 393'; };
    if (type === 'wood' || type === 'boards') {
      const st = type === 'boards' ? 2 : 1; vl(-24, 24, st);
      for (let r = 1; r < RW.length - 1; r++) for (let j = -24; j < 24; j += st) if (((j * 2 + r) % 3 + 3) % 3 === 0) lines += 'M' + f1(xb(j, RW[r])) + ' ' + RW[r] + 'L' + f1(xb(j + st, RW[r])) + ' ' + RW[r];
      for (let r = 0; r < RW.length - 1; r++) for (let j = -24; j < 24; j += st) { const m = ((j * 7 + r * 3) % (type === 'boards' ? 9 : 5) + 9) % (type === 'boards' ? 9 : 5); if (m === 0) dark += type === 'boards' ? quad(j + 0.7, RW[r], RW[r + 1], 0.6) : quad(j, RW[r], RW[r + 1], 1); else if (m === 2) light += quad(j, RW[r], RW[r + 1], st); }
    } else if (type === 'checker' || type === 'dance') {
      for (let r = 0; r < RB.length - 1; r++) for (let j = -14; j < 14; j += 2) { const q = quad(j, RB[r], RB[r + 1], 2); if (type === 'dance') tiles.push({ i: j / 2, r, d: q }); else if ((((j / 2) + r) % 2 + 2) % 2 === 0) dark += q; }
      if (type === 'dance') { vl(-14, 14, 2); RB.forEach(y => lines += 'M0 ' + y + 'H852'); }
    } else if (type === 'tile') { vl(-24, 24, 1); RT.forEach(y => lines += 'M0 ' + y + 'H852'); for (let r = 0; r < RT.length - 1; r++) for (let j = -24; j < 24; j++) if (((j * 3 + r * 5) % 7 + 7) % 7 === 0) light += quad(j, RT[r], RT[r + 1], 1);
    } else if (type === 'lino' || type === 'marble' || type === 'ballroom') {
      const R = rowsK([100, 130, 170, 222, 290, 393], k); vl(-15, 15, 3); R.forEach(y => lines += 'M0 ' + y + 'H852');
      for (let r = 0; r < R.length - 1; r++) for (let j = -15; j < 15; j += 3) { const odd = ((j / 3 + r) % 2 + 2) % 2; if (odd) { if (type === 'marble') light += quad(j, R[r], R[r + 1], 3); else dark += quad(j, R[r], R[r + 1], 3); } }
      if (type === 'marble') for (let n = 0; n < 9; n++) { const y = 112 + n * 30, x = 140 + ((n * 211) % 560); lines += 'M' + x + ' ' + y + 'q30 8 50 -2t44 10'; }
      if (type === 'lino') for (let n = 0; n < 6; n++) dark += circ(160 + ((n * 173) % 540), 150 + n * 38, 10 + (n % 3) * 5);
      if (type === 'ballroom') for (let n = 0; n < 40; n++) { const y = 108 + ((n * 47) % 280), x = 426 + ((((n * 97) % 160) - 80) * 9 * WY(y) * 0.6), s = 2 + (n % 3); light += 'M' + f1(x) + ' ' + f1(y - s * 2) + 'L' + f1(x + s * 0.6) + ' ' + f1(y - s * 0.6) + 'L' + f1(x + s * 2) + ' ' + y + 'L' + f1(x + s * 0.6) + ' ' + f1(y + s * 0.6) + 'L' + f1(x) + ' ' + f1(y + s * 2) + 'L' + f1(x - s * 0.6) + ' ' + f1(y + s * 0.6) + 'L' + f1(x - s * 2) + ' ' + y + 'L' + f1(x - s * 0.6) + ' ' + f1(y - s * 0.6) + 'Z'; }
    } else if (type === 'herring') {
      for (let r = 0; r < RW.length - 1; r++) for (let j = -24; j < 24; j++) { const a = RW[r], b = RW[r + 1]; lines += (j + r) % 2 ? 'M' + f1(xb(j, a)) + ' ' + a + 'L' + f1(xb(j + 1, b)) + ' ' + b : 'M' + f1(xb(j + 1, a)) + ' ' + a + 'L' + f1(xb(j, b)) + ' ' + b; if (((j * 5 + r * 3) % 6 + 6) % 6 === 0) dark += quad(j, a, b, 1); }
      RW.forEach(y => lines += 'M0 ' + y + 'H852');
    } else if (type === 'wafer') { for (let j = -40; j <= 40; j += 2) lines += 'M' + f1(xb(j, H)) + ' ' + H + 'L' + f1(xb(j + 8, 393)) + ' 393M' + f1(xb(j, H)) + ' ' + H + 'L' + f1(xb(j - 8, 393)) + ' 393'; for (let n = 0; n < 30; n++) light += circ(150 + ((n * 131) % 560), 112 + ((n * 59) % 270), 2.4);
    } else if (type === 'grass' || type === 'patchy') {
      for (let j = -14; j < 14; j += 2) if (((j / 2) % 2 + 2) % 2 === 0) light += quad(j, H, 393, 2);
      for (let n = 0; n < 70; n++) { const y = 110 + ((n * 53) % 280), x = 426 + (((n * 97) % 160) - 80) * 10 * WY(y) * 0.6, k = WY(y) * 3; lines += 'M' + f1(x) + ' ' + y + 'l' + f1(-k) + ' ' + f1(-k * 2) + 'M' + f1(x + 3) + ' ' + y + 'l' + f1(k * 0.4) + ' ' + f1(-k * 2.4); }
      if (type === 'patchy') for (let n = 0; n < 9; n++) { const y = 140 + ((n * 71) % 230), x = 120 + ((n * 197) % 620); dark += ell(x, y, 30 * WY(y), 11 * WY(y)); }
    } else if (type === 'patio') { const R = rowsK([100, 126, 158, 198, 248, 312, 393], k); R.forEach(y => lines += 'M0 ' + y + 'H852'); for (let r = 0; r < R.length - 1; r++) for (let j = -18 + (r % 2) * 1.5; j < 18; j += 3) { lines += 'M' + f1(xb(j, R[r])) + ' ' + R[r] + 'L' + f1(xb(j, R[r + 1])) + ' ' + R[r + 1]; if (((Math.round(j) * 3 + r) % 4 + 4) % 4 === 0) light += quad(j, R[r], R[r + 1], 3); }
    } else if (type === 'cloud') { for (let n = 0; n < 26; n++) { const y = 120 + ((n * 53) % 260), x = 120 + ((n * 211) % 620), s = WY(y); light += ell(x, y, 34 * s, 12 * s) + ell(x + 24 * s, y - 6 * s, 20 * s, 10 * s); } }
    return { lines, dark, light, tiles };
  }
  const SH = {};
  function shell(rk, sf, lockOf) {
    const R = ROOMS[rk]; sf = sf || {};
    const locks = R.doors.map(d => lockOf ? lockOf(d.to) : 0);
    const kf = (X.BIG && X.BIG[rk]) || 1, key = rk + '|' + slotsOf(rk).map(s => sf[s] || DEF[s]).join(',') + '|' + locks.join(',') + '|' + kf + '|' + (sf.lx != null ? sf.lx : '') + '|' + (sf.lz || 1) + '|' + (SPEC[sf.win] && SPEC[sf.win].ir ? 'ir' : '');
    if (SH[key]) return SH[key];
    const P = palette(rk, sf), o = [], T = [], out = !!R.out, junk = !out && specOf('wall', sf.wall).pat === 'peel' && (sf.trim || DEF.trim) === 't_scuff' && (sf.floor || DEF.floor) === 'f_boards', dark = !out && lum(P.b0) < 0.4 && rk === 'dance' || (!out && specOf('floor', sf.floor).ft === 'dance' && lum(P.b0) < 0.5), Rr = { dark };
    if (out) fence(o, specOf('fence', sf.fence));
    else if (junk) rust(o, P);
    (R.fixed || []).forEach(a => fixed(a[0], a, P, o, T));
    if (!out) { if (R.winX != null) window_(o, R.winX, specOf('win', sf.win)); if (R.artX != null) art(o, R.artX, specOf('art', sf.art), T); }
    const doors = [];
    const top = [];
    if (out) ylights(top, specOf('ylight', sf.ylight)); else { const LX = R.lightX != null && sf.lx != null ? +sf.lx : R.lightX; const LS = specOf('light', sf.light), lz = +sf.lz || 1; if (LX != null && LS.k !== 'none') top.push(pd('M' + LX + ' -72V4', 'none', '#7a6a58', 1.6)); const n0 = top.length; light(top, LX, LS); if (lz !== 1 && LX != null) for (let i = n0; i < top.length; i++) top[i].tf = 'matrix(' + lz + ' 0 0 ' + lz + ' ' + f1(LX * (1 - lz)) + ' 0)'; }
    const fs = out ? specOf('ground', sf.ground) : specOf('floor', sf.floor), fl = floor(fs.ft, kf);
    SH[key] = { P, decor: o.concat(top).map(p => (p.tf == null ? Object.assign(p, { tf: '' }) : p)), texts: T, doors, floor: fl, fop: fs.op, wall: out ? 'siding' : specOf('wall', sf.wall).pat, out, dark, rusty: junk, name: R.name, light: out ? null : specOf('light', sf.light).k };
    return SH[key];
  }
  // ---------- catalog swatches for surfaces ----------
  const MOTIF = {
    stripe: (c) => [0, 1, 2, 3].map(i => pd(rr(6 + i * 18, 0, 9, 52, 0), c, 0, 0, 0.55)), peel: (c) => [pd(ell(22, 18, 10, 7), '#8a6a48', 0, 0, 0.15), pd('M50 0L54 10L50 18L58 30', 'none', c, 1.4), pd('M62 4Q70 8 66 20L74 22L72 2Z', '#f1e8d6', c, 1)],
    plaster: (c) => [pd(rr(10, 8, 22, 16, 2), c, 0, 0, 0.7), pd(rr(44, 26, 26, 18, 2), c, 0, 0, 0.7)], daisy: (c) => [[16, 14], [50, 10], [30, 36], [66, 34]].flatMap(([x, y]) => [0, 1, 2, 3, 4].map(i => pd(circ(x + 4 * Math.cos(i * 1.26), y + 4 * Math.sin(i * 1.26), 2.6), '#ffffff')).concat([pd(circ(x, y, 2), c)])),
    tile: (c) => [pd('M0 13H80M0 26H80M0 39H80M13 0V52M26 0V52M39 0V52M52 0V52M65 0V52', 'none', c, 1.4)], burst: (c) => [[18, 14], [56, 24], [30, 40]].map(([x, y]) => pd('M' + x + ' ' + (y - 7) + 'L' + (x + 1.6) + ' ' + (y - 1.6) + 'L' + (x + 7) + ' ' + y + 'L' + (x + 1.6) + ' ' + (y + 1.6) + 'L' + x + ' ' + (y + 7) + 'L' + (x - 1.6) + ' ' + (y + 1.6) + 'L' + (x - 7) + ' ' + y + 'L' + (x - 1.6) + ' ' + (y - 1.6) + 'Z', c)),
    linen: (c) => [pd('M0 6H80M0 14H80M0 22H80M0 30H80M0 38H80M0 46H80', 'none', c, 0.8)], candy: (c) => [0, 1, 2, 3, 4, 5].map(i => pd('M' + (i * 18 - 20) + ' 52L' + (i * 18 + 2) + ' 0H' + (i * 18 + 11) + 'L' + (i * 18 - 11) + ' 52Z', c, 0, 0, 0.8)),
    damask: (c) => [[20, 14], [60, 14], [40, 36]].map(([x, y]) => pd('M' + x + ' ' + (y - 10) + 'Q' + (x + 8) + ' ' + y + ' ' + x + ' ' + (y + 10) + 'Q' + (x - 8) + ' ' + y + ' ' + x + ' ' + (y - 10) + 'Z', c)),
  };
  function swatch(id) {
    const M = X.SURF[id], S = SPEC[id]; if (!M || !S) return { vb: '0 0 80 56', polys: [] };
    const o = [], T = [], sl = M.arch;
    if (sl === 'wall') { o.push(pd(rr(0, 0, 80, 56, 6), S.b0)); (MOTIF[S.pat] || (() => []))(S.pc).forEach(p => o.push(p)); o.push(pd(rr(0, 40, 80, 16, 0), '#d8cbb4', 0, 0, 0.0)); return { vb: '0 0 80 56', polys: o }; }
    if (sl === 'trim') { o.push(pd(rr(0, 0, 80, 56, 6), '#efe6d6'), pd(rr(0, 26, 80, 30, 0), S.w0), pd(rr(0, 24, 80, 4, 0), S.trim)); return { vb: '0 0 80 56', polys: o }; }
    if (sl === 'floor' || sl === 'ground') { const P = { f1: S.f1 }; o.push(pd('M14 0H66L80 56H0Z', S.f1)); const L = { wood: 'M22 0L14 56M34 0L30 56M46 0L50 56M58 0L66 56', boards: 'M28 0L22 56M52 0L58 56', checker: '', dance: '', tile: 'M28 0L24 56M40 0V56M52 0L56 56M0 28H80', lino: 'M40 0V56M0 26H80', marble: 'M40 0V56M0 26H80M10 40q14 -6 24 2', herring: 'M20 6l10 10l10 -10l10 10l10 -10M16 26l10 10l10 -10l10 10l10 -10M12 46l10 10l10 -10l10 10l10 -10', wafer: 'M14 0L40 56M40 0L66 56M66 0L40 56M40 0L14 56', ballroom: '', grass: 'M20 30l-2 -5M24 30l1 -6M50 18l-2 -5M54 18l1 -6M40 46l-2 -5M44 46l1 -6', patchy: 'M20 30l-2 -5M24 30l1 -6M56 40l-2 -5', patio: 'M0 18H80M0 38H80M30 0V18M54 18V38M24 38V56', cloud: '' }[S.ft] || '';
      if (S.ft === 'checker' || S.ft === 'dance') [[14, 0], [40, 14], [14, 28], [40, 42], [66, 28]].forEach(([x, y], i) => o.push(pd(rr(x - 4, y, 22, 14, 0), S.ft === 'dance' ? K.NEON[i] : S.fd, 0, 0, S.ft === 'dance' ? 0.9 : 0.85)));
      if (S.ft === 'ballroom') [[24, 14], [52, 30], [34, 44], [62, 12]].forEach(([x, y]) => o.push(pd(circ(x, y, 2.4), S.fli)));
      if (S.ft === 'patchy') o.push(pd(ell(50, 36, 14, 6), S.fd, 0, 0, 0.8));
      if (S.ft === 'cloud') o.push(pd(ell(30, 22, 14, 6), WH), pd(ell(52, 40, 16, 6), WH));
      if (L) o.push(pd(L, 'none', S.fl, 1.4)); return { vb: '0 0 80 56', polys: o }; }
    if (sl === 'win') { window_(o, 0, S); return { vb: '-56 -12 112 92', polys: o }; }
    if (sl === 'light') { if (S.k === 'none') return { vb: '0 0 80 56', polys: [] }; light(o, 0, S, 1); return { vb: S.k === 'laser' || S.k === 'truss' ? '-50 -4 100 70' : '-46 -4 92 64', polys: o }; }
    if (sl === 'art') { art(o, 0, S, T); return { vb: '-40 6 80 62', polys: o }; }
    if (sl === 'door') { const P = { door: S.c, doorL: S.cl, trim: CR }; door({ s: 'B', x: 0, to: 'living', k: 'door' }, P, o, [], {}, S, 0, 1); return { vb: '-40 16 80 86', polys: o }; }
    if (sl === 'fence') { const c = S.c, d = shade(c, 0.75); for (let i = 0; i < 5; i++) { const x = 6 + i * 15, h = S.k === 'gold' ? 46 : S.k === 'slat' ? 44 : 38, tilt = S.k === 'broken' && i === 2 ? 8 : 0; if (S.k === 'broken' && i === 3) continue; o.push(pd('M' + x + ' 56V' + (56 - h + tilt) + 'L' + (x + 6) + ' ' + (56 - h - (S.k === 'slat' ? 0 : 7) + tilt) + 'L' + (x + 12) + ' ' + (56 - h + tilt) + 'V56Z', c, d, 1.2)); if (S.k === 'cane') o.push(pd('M' + (x + 1) + ' 30l10 -4M' + (x + 1) + ' 42l10 -4', 'none', '#e2554a', 3)); if (S.k === 'gold') o.push(pd(circ(x + 6, 6, 3), 'url(#hsGold)')); } return { vb: '0 0 80 56', polys: o }; }
    if (sl === 'ylight' && S.k !== 'string') { if (S.k === 'none') return { vb: '0 0 80 56', polys: [] }; ylights(o, S); return { vb: S.k === 'torch' ? '0 40 200 140' : '230 -4 300 110', polys: o }; }
    if (sl === 'ylight') { if (S.k === 'none') return { vb: '0 0 80 56', polys: [] }; o.push(pd('M0 10Q40 40 80 10', 'none', '#5a4a40', 1.6)); ['#ff9d4a', '#ffd66b', '#a6f06a', '#6ac8ff', '#8f7bff'].forEach((c, i) => { const t = (i + 0.5) / 5, x = t * 80, y = 10 + 30 * 4 * t * (1 - t) * 0.5 + 6; o.push(pd(circ(x, y, 8), c, 0, 0, 0.3), pd(ell(x, y, 4, 5.5), c)); }); return { vb: '0 0 80 56', polys: o }; }
    return { vb: '0 0 80 56', polys: [] };
  }
  Object.assign(X, { ROOMS, RKEYS, NAME, SPEC, DEF, SLOTS_IN, SLOTS_OUT, slotsOf, shell, swatch, palette });
})();
