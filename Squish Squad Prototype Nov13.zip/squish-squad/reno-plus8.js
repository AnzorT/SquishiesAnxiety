// Renovation Catalog round 8b — Yard sections 2 + 3: plants & garden beds, swings, seating, shade structures, shed.
// Foliage = canopy balls in a layer whose hulls get a leaf texture (tex) + lit leaf sprinkles on the front hemispheres; gentle sway via layer wrap.
// Grow beds use r.kind 'grow' + r.modes (tap cycles the stages, last stage harvests and restarts). Sets RenoDraw.PLUS8; catalog edits RD.SET8.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS7 && RD.H7 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS8) return;
  const K = X.K, { solid, box, cyl, ball, arcW, prism, prismZ, f1 } = K;
  const { rep, rng, n4, P2, planeH, plane, planeX, an, BLUR, bbOf, mt, wd, cer, pt, tex } = RD.H3;
  const { atV, once, onceT, G, L, ellPts, lp, sp, quad, planeT, facing, tube, curve, water, WP, WDEF, FDEF, smoke, glowE, isPlay } = RD.H7;
  const N = RD.N, PI = Math.PI, GOLD = '#e2b14a', CH = '#d5dde2', B = b => b ? ` begin="${n4(b)}s"` : '';
  const fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {});
  const kOf = p => (p(0, 0, 0)[1] - p(0, 1, 0)[1]) / X.CA;
  const V3 = [0.394, 0.616, 0.682], LT = [-0.42, 0.8, 0.43], dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const LEAF = '<pattern id="q8lf" width="7" height="6" patternUnits="userSpaceOnUse"><path d="M1 2.4q1.4-1.6 3 0q-1.6 1.2-3 0Z" fill="#ffffff" fill-opacity="0.3"/><path d="M4 5q1.3-1.4 2.8 0q-1.4 1.1-2.8 0Z" fill="#000000" fill-opacity="0.22"/><path d="M0.4 5.2q1-1 2 0M5 1.2q0.8-0.8 1.6 0" stroke="#000000" stroke-opacity="0.2" stroke-width="0.3" fill="none"/></pattern>'
    + '<pattern id="q8lf2" width="11" height="9" patternUnits="userSpaceOnUse"><path d="M1 3q2.2-2.4 4.6 0q-2.4 1.8-4.6 0Z" fill="#000000" fill-opacity="0.16"/><path d="M6 7.4q2-2 4.2 0q-2.2 1.6-4.2 0Z" fill="#ffffff" fill-opacity="0.2"/></pattern>'
    + '<pattern id="q8wv" width="3" height="3" patternUnits="userSpaceOnUse"><path d="M0 0.75H3M0 2.25H3" stroke="#5a3a1a" stroke-opacity="0.35" stroke-width="0.5"/><path d="M0.75 0V0.75M2.25 0.75V2.25M0.75 2.25V3" stroke="#ffffff" stroke-opacity="0.22" stroke-width="0.45"/></pattern>';
  const LEAFT = s => tex(s, [['q8lf', 0.9], ['q8lf2', 0.6]]);
  const sprinkle = (p, k, cl, cols, seed, per, sz) => { const R = rng(seed); let s = ''; sz = sz || 1;
    cl.forEach(([x, y, z, r]) => rep(per || 10, () => { let d = [0, 1, 0]; for (let t = 0; t < 8; t++) { const c = [R() * 2 - 1, R() * 2 - 1, R() * 2 - 1], l = Math.hypot(...c); if (l > 0.3 && l < 1) { d = c.map(v => v / l); break; } }
      if (dot(d, V3) < 0.2) return; const q = p(x + d[0] * r, y + d[1] * r * 0.94, z + d[2] * r), li = dot(d, LT), c = li > 0.45 ? cols[2] : li > 0 ? cols[1] : cols[0];
      s += `<path d="M0 0q${f1(1.3 * sz)} ${f1(-1.1 * sz)} ${f1(2.8 * sz)} 0q${f1(-1.4 * sz)} ${f1(1.1 * sz)} ${f1(-2.8 * sz)} 0Z" fill="${c}" transform="translate(${P2(q)}) rotate(${f1(R() * 360)}) scale(${n4(k)})"/>`; })); return s; };
  const fruitOn = (o, cl, n, col, r, seed, o2) => { const R = rng(seed); rep(n, i => { const [x, y, z, rr] = cl[i % cl.length]; let d; for (let t = 0; t < 10; t++) { d = [R() * 2 - 1, R() * 0.8 - 0.5, R() * 2 - 1]; const l = Math.hypot(...d); d = d.map(v => v / l); if (dot(d, V3) > 0.1) break; } o.push(ball(x + d[0] * rr * 0.96, y + d[1] * rr * 0.9, z + d[2] * rr * 0.96, r, col, Object.assign({ k: 3, n: 10, shine: 1 }, o2 || {}))); }); };
  const sway = (p, x, y, z, a, d, b) => { const q = p(x, y, z); return atV('rotate', [`${-a} ${P2(q)}`, `${a} ${P2(q)}`, `${-a} ${P2(q)}`], d, b); };
  const flower5 = (q, k, s, col, mid) => `<g transform="translate(${P2(q)}) scale(${n4(k * s)})">${rep(5, i => `<ellipse cx="0" cy="-1.1" rx="0.75" ry="1.1" fill="${col}" transform="rotate(${i * 72})"/>`).join('')}<circle r="0.55" fill="${mid || '#ffd23a'}"/></g>`;
  const stageOf = S => { const M = (S.row && S.row.modes) || []; return Math.max(0, M.indexOf(S.st)); };

  // ======================= DWARF MEYER LEMON TREE IN HALF-BARREL =======================
  N.lemon8 = S => { const CL = [[0, 66, 0, 16], [-15, 58, 4, 12.5], [15, 60, -2, 13], [-7, 79, -6, 12.5], [9, 77, 7, 12], [-18, 71, -5, 10], [18, 72, 8, 10], [2, 54, 12, 11], [0, 88, 2, 9.5], [-4, 62, 14, 9]], GR = ['#2f6a2a', '#3f8a34', '#5aa844'];
    const D = { w: 60, d: 60, round: 1 };
    D.build = P => [cyl(0, 0, 0, 20, 24, '#9a6a3c', wd({ n: 28, rg: [[0, 0, 0.88], [12, 0, 1], [24, 0, 0.96]] })), ...[4, 19].map(y => arcW(0, y, 0, 20.6, 20.6, 1.2, 2.2, 4.4, 4.4 + 2 * PI, '#3a3c42', mt({ n: 30, shine: 1 }))), cyl(0, 23, 0, 18.6, 1.2, '#4a3424', pt({ n: 26 })),
      cyl(0, 23, 0, 2.6, 26, '#7a5a3e', wd({ n: 10, rg: [[0, 0, 1.25], [6, 0, 1], [26, 0, 0.75]] }))];
    D.layers = [{ build: P => { const o = CL.map(([x, y, z, r], i) => ball(x, y, z, r, GR[i % 3], pt({ k: 5, n: 14, soft: 1, sy: 0.9 }))); fruitOn(o, CL, 11, '#f6d23a', 2.5, 'lem', { sx: 1.15 }); return o; },
      wrap: (p, s) => { const k = kOf(p); let br = ''; [[-12, 58, 4], [12, 60, -2], [0, 70, 0], [8, 74, 6], [-6, 76, -6]].forEach(c => br += tube(curve([0, 48, 0], [c[0] * 0.3, 54, c[2] * 0.3], c, 5).map(q => p(...q)), 1.6, k, '#7a5a3e', '#b08a64', '#3a2a1a'));
        let bl = ''; const R = rng('lbl'); rep(7, i => { const c = CL[i]; bl += flower5(p(c[0] + (R() - 0.5) * 8, c[1] + c[3] * 0.6, c[2] + c[3] * 0.7), k, 0.9, '#fffaf0', '#f2c14a'); });
        return `<g>${sway(p, 0, 48, 0, 1.1, 5.2)}${br}${LEAFT(s)}${sprinkle(p, k, CL, GR.map(c => K.shade ? K.shade(c, 1.15) : c), 'lml', 14, 1.15)}${bl}</g>`; } }];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      rep(16, i => { const th = i / 16 * 2 * PI; if (facing(th) < 0.05) return; f += `<path d="M${P2(p(20.4 * Math.sin(th), 0.6, 20.4 * Math.cos(th)))}L${P2(p(20.4 * Math.sin(th), 23.4, 20.4 * Math.cos(th)))}" stroke="#5a3a1e" stroke-width="${f1(0.5 * k)}" opacity="0.55"/>`; });
      f += `<g transform="${planeH(p, 24.3)}">${rep(18, i => { const a = i * 2.4, r = 4 + (i % 6) * 2.3; return `<ellipse cx="${f1(r * Math.cos(a))}" cy="${f1(r * Math.sin(a))}" rx="1.6" ry="0.9" fill="${i % 2 ? '#7a5434' : '#5e4028'}" transform="rotate(${i * 37} ${f1(r * Math.cos(a))} ${f1(r * Math.sin(a))})"/>`; }).join('')}</g>`;
      return { defs: LEAF, front: f, bb: bbOf([p(-28, 0, -28), p(28, 0, 28), p(-28, 0, 28), p(28, 0, -28), p(0, 102, 0), p(-36, 72, 0), p(36, 72, 0)], 3) }; };
    return D; };

  // ======================= FRENCH BOXWOOD PARTERRE & ROSE ARCH =======================
  N.parterre8 = S => { const W = 74, DZ = 50, HG = '#3f7a34', HG2 = '#4f8f3e';
    const D = { w: 160, d: 110 };
    D.build = P => [box(0, 0, 0, 2 * W + 4, 1.4, 2 * DZ + 4, '#d9cdb2', pt({ r: 1 })), cyl(0, 0, 0, 7, 9, '#c4683a', pt({ n: 18, rg: [[0, 0, 0.7], [2, 0, 0.8], [7, 0, 1], [9, 0, 1.08]] }))];
    D.layers = [{ build: P => { const o = [], H2 = (x, z, w, d) => o.push(box(x, 1.4, z, w, 7, d, HG, fb({ r: 3.2, bev: 2.4 })));
        H2(0, DZ - 2, 2 * W, 4.4); H2(0, -DZ + 2, 2 * W, 4.4); H2(-W + 2, 0, 4.4, 2 * DZ - 8); H2(W - 2, 0, 4.4, 2 * DZ - 8);
        [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => { H2(sx * W / 2, sz * DZ / 2, 4, DZ - 14); H2(sx * (W / 2), sz * (DZ / 2), W - 22, 4); o.push(ball(sx * (W - 10), 12, sz * (DZ - 10), 5.6, HG2, fb({ k: 5, n: 12 })), cyl(sx * (W - 10), 1.4, sz * (DZ - 10), 1.2, 6, '#6a4a2a', wd({ n: 6 }))); });
        o.push(ball(0, 18.6, 0, 8.4, HG2, fb({ k: 5, n: 14 })), ball(0, 28, 0, 5.4, HG2, fb({ k: 5, n: 12 })));
        rep(20, i => { const t = i / 20 * 2 * PI; o.push(ball(20 * Math.cos(t), 4.4, 14 * Math.sin(t), 3.2, HG2, fb({ k: 3, n: 8 }))); });
        return o; }, wrap: (p, s) => LEAFT(s) }];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      // gravel + rose beds in the four knots
      f += `<g transform="${planeH(p, 1.5)}" opacity="0.6">${rep(60, i => { const R = rng('grv' + i)(); return `<circle cx="${f1(-W + ((i * 37) % 148))}" cy="${f1(-DZ + ((i * 53) % 100))}" r="${f1(0.5 + R)}" fill="#b8ab8e"/>`; }).join('')}</g>`;
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz], j) => { const R = rng('rose' + j); rep(9, i => { const x = sx * (W / 2 + (R() - 0.5) * 30), z = sz * (DZ / 2 + (R() - 0.5) * 22), q = p(x, 4, z); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><ellipse cx="0" cy="0.6" rx="3.4" ry="1.6" fill="#2f5a26"/><path d="M-2.4 0q1-2.6 2.4-1.2q1.4-1.4 2.4 1.2" fill="#3f7a34"/>${rep(3, m => `<circle cx="${(m - 1) * 1.6}" cy="${-1.6 - (m % 2)}" r="1.2" fill="${['#e8345a', '#f27aa0', '#c81e44'][(i + m) % 3]}"/><circle cx="${(m - 1) * 1.6 - 0.3}" cy="${-1.9 - (m % 2)}" r="0.4" fill="#ffd0dc"/>`).join('')}</g>`; }); });
      // white iron rose arch at the back with climbing roses
      const arch = side => rep(13, i => { const a = PI - i / 12 * PI; return [side * 3 + 22 * Math.cos(a), 30 + 22 * Math.sin(a), -DZ - 2]; });
      [-1, 1].forEach(s => { const pts = [[-22, 0, -DZ - 2 + s * 3], [-22, 30, -DZ - 2 + s * 3]].concat(rep(13, i => { const a = PI - i / 12 * PI; return [22 * Math.cos(a), 30 + 22 * Math.sin(a), -DZ - 2 + s * 3]; })).concat([[22, 0, -DZ - 2 + s * 3]]); const t = tube(pts.map(q => p(...q)), 1, k, '#f4f2ea', '#ffffff', '#6a6a60'); if (s < 0) bk += t; else f += t; });
      void arch; const R = rng('arch'); rep(34, i => { const u = i / 33, a = u < 0.22 ? null : PI - (u - 0.22) / 0.56 * PI, q = u < 0.22 ? p(-22, u / 0.22 * 30, -DZ - 0.5) : u > 0.78 ? p(22, (1 - u) / 0.22 * 30, -DZ - 0.5) : p(22 * Math.cos(a), 30 + 22 * Math.sin(a), -DZ - 0.5);
        f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><g>${atV('rotate', ['-6', '6', '-6'], 4 + R() * 2, -R() * 3)}<path d="M0 0q1.6-2.2 3.4-0.4q-1.6 1.6-3.4 0.4Z" fill="${R() > 0.5 ? '#3f7a34' : '#5a9a44'}" transform="rotate(${f1(R() * 360)})"/>${i % 3 === 0 ? `<circle cx="1" cy="-1" r="1.5" fill="${R() > 0.5 ? '#f27aa0' : '#e8345a'}"/><circle cx="0.7" cy="-1.3" r="0.5" fill="#ffd0dc"/>` : ''}</g></g>`; });
      return { defs: LEAF, back: bk, front: f, bb: bbOf([p(-W - 4, 0, -DZ - 4), p(W + 4, 0, DZ + 4), p(-W - 4, 0, DZ + 4), p(W + 4, 0, -DZ - 4), p(0, 56, -DZ), p(-26, 40, -DZ), p(26, 40, -DZ)], 3) }; };
    return D; };

  // ======================= ANCIENT TWISTED OLIVE & CYPRESS GROVE =======================
  N.grove8 = S => { const OL = [[-6, 72, 0, 15], [10, 66, 6, 13], [-20, 62, 6, 11], [4, 84, -6, 12], [20, 76, -4, 10.5], [-16, 82, -8, 10.5], [-2, 60, 14, 10], [-26, 72, -2, 9], [14, 86, 4, 9], [26, 66, 6, 8.5], [-10, 92, 0, 8]], OG = ['#6f8a5a', '#8fa878', '#b4c8a0'];
    const D = { w: 140, d: 90 };
    const CY = [[46, -18, 84, 9], [54, 22, 70, 8]], CYG = ['#1f3a22', '#2f5232', '#46704a'];
    D.build = P => [cyl(0, 0, 0, 62, 1.6, '#d8ccb0', pt({ n: 36, rz: 38 })), ball(-2, 1, 2, 9, '#6a5a48', wd({ sx: 1.5, sy: 0.6, k: 4, n: 12 }))];
    D.layers = [{ build: P => { const o = [];
        CY.forEach(([x, z, h, r]) => o.push(cyl(x, 1, z, 1.8, 6, '#5a4632', wd({ n: 8 })), cyl(x, 5, z, r, h, CYG[1], fb({ n: 18, rg: [[0, 0, 0.55], [h * 0.12, 0, 0.92], [h * 0.35, 0, 1], [h * 0.65, 0, 0.78], [h * 0.88, 0, 0.36], [h, 0, 0.05]] }))));
        OL.forEach(([x, y, z, r], i) => o.push(ball(x, y, z, r, OG[i % 2], fb({ k: 5, n: 14, sy: 0.72 }))));
        fruitOn(o, OL, 14, '#2a2430', 1.1, 'olv', { k: 2, n: 6 });
        return o; },
      wrap: (p, s) => { const k = kOf(p); let tr = '';
        // gnarled twisting trunk: three braided limbs
        [[-4, 0], [3, 2], [0, -3]].forEach(([dx, dz], j) => { const pts = rep(9, i => { const t = i / 8, a = t * 3.6 + j * 2.1; return [dx * (1 - t) + Math.cos(a) * 3.4 * (1 - t * 0.4) + [-8, 8, 2][j] * t * t, 2 + t * 58, dz * (1 - t) + Math.sin(a) * 3.4 * (1 - t * 0.4) + [2, 4, -6][j] * t * t]; }); tr += tube(pts.map(q => p(...q)), 4.6 - j * 0.8, k, ['#7a6a58', '#8a7a66', '#6a5a4a'][j], '#c8b8a0', '#2e261e'); });
        [[-20, 62, 6], [18, 76, -4], [4, 82, -6]].forEach(c => tr += tube(curve([0, 56, 0], [c[0] * 0.4, 62, c[2] * 0.4], c, 5).map(q => p(...q)), 1.8, k, '#7a6a58', '#b8a890', '#2e261e'));
        return `<g>${sway(p, 50, 6, -4, 0.7, 6.4)}${tr}${LEAFT(s)}${sprinkle(p, k, OL, ['#6a8456', '#9ab286', '#c8d8b4'], 'ols', 16, 1.05)}${sprinkle(p, k, CY.map(([x, z, h, r]) => [x, 5 + h * 0.4, z, r * 0.9]), CYG, 'cys', 26, 0.8)}</g>`; } }];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      [[-40, 20], [-30, 28], [24, 26], [-48, 6], [36, 24]].forEach(([x, z], i) => { const q = p(x, 1.6, z); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><g>${atV('rotate', ['-4', '4', '-4'], 3 + i * 0.4, -i)}${rep(7, j => `<path d="M0 0Q${f1((j - 3) * 1.4)} -5 ${f1((j - 3) * 2.2)} -9" stroke="#7a9a5a" stroke-width="0.6" fill="none"/><ellipse cx="${f1((j - 3) * 2.2)}" cy="-10.6" rx="0.8" ry="2" fill="${j % 2 ? '#9a7ad8' : '#b49af0'}"/>`).join('')}</g></g>`; });
      return { defs: LEAF, front: f, bb: bbOf([p(-64, 0, -40), p(64, 0, 40), p(-64, 0, 40), p(64, 0, -40), p(0, 98, 0), p(44, 92, -16), p(-36, 76, 6)], 3) }; };
    return D; };

  // ======================= ZEN TEMPLE GARDEN: LIMESTONE BUDDHA & PAGODA LANTERNS =======================
  N.zen8 = S => { const LS = '#d8cfbc', LS2 = '#c8bea8';
    const D = { w: 150, d: 100, glow: () => ({ y: 26, r: 40 }) };
    const lantern = (o, x, z) => { o.push(cyl(x, 0, z, 7, 3, LS2, pt({ n: 8 })), cyl(x, 3, z, 3, 14, LS, pt({ n: 8 })), cyl(x, 17, z, 6, 2, LS2, pt({ n: 8 })), box(x, 19, z, 9, 8, 9, LS, pt({ r: 0.8 })), cyl(x, 27, z, 10, 4, LS2, pt({ n: 8, rg: [[0, 0, 1], [1, 0, 1], [4, 0, 0.34]] })), cyl(x, 31, z, 2.4, 2, LS, pt({ n: 8 })), ball(x, 34, z, 2.4, LS2, pt({ sy: 1.4, k: 3, n: 8 }))); };
    D.build = P => { const o = [box(0, 0, 0, 148, 1.2, 98, '#e8e2d4', pt({ r: 2 }))];
      // Buddha: lotus base, crossed legs, robed torso, head with ushnisha, hands in the lap
      o.push(cyl(0, 1.2, -18, 18, 5, LS2, pt({ n: 20, rg: [[0, 0, 0.9], [3, 0, 1], [5, 0, 0.92]] })), ball(0, 9, -18, 15, LS, pt({ sx: 1.05, sy: 0.42, sz: 0.8, k: 4, n: 16 })), cyl(0, 10, -21, 9.5, 18, LS, pt({ n: 18, rz: 7.5, rg: [[0, 0, 1.08], [9, 0, 1], [14, 0, 0.9], [18, 0, 0.72]] })),
        ball(0, 31.6, -21, 6.2, LS, pt({ k: 5, n: 14, sy: 1.08 })), ball(0, 38.6, -21, 2.6, LS2, pt({ k: 3, n: 10 })), ball(0, 13.6, -13.6, 4.6, LS, pt({ sx: 1.4, sy: 0.5, k: 3, n: 10 })), ball(-9.6, 22, -20.6, 3.2, LS, pt({ sy: 1.6, k: 3, n: 8 })), ball(9.6, 22, -20.6, 3.2, LS, pt({ sy: 1.6, k: 3, n: 8 })));
      lantern(o, -48, -26); lantern(o, 50, -22);
      [[-30, 22, 9], [-6, 30, 8], [20, 26, 9]].forEach(([x, z, r]) => o.push(cyl(x, 1.2, z, r, 1.4, '#9a9488', pt({ n: 12, rz: r * 0.7 }))));
      [[-60, 20, 9], [58, 30, 7], [-52, -40, 7], [40, 2, 5]].forEach(([x, z, r]) => o.push(ball(x, 0.8, z, r, '#5f8a3e', fb({ sy: 0.5, k: 4, n: 12 }))));
      o.push(ball(40, 1, -40, 9, '#8a8478', pt({ sx: 1.4, sy: 0.8, k: 4, n: 12 })), ball(-24, 1, -40, 6, '#7a756a', pt({ sx: 1.2, sy: 0.9, k: 4, n: 10 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      // raked gravel: straight furrows + rings round the stones
      let rk = ''; rep(15, i => { const z = -46 + i * 6.4; rk += `<path d="M-72 ${f1(z)}Q-36 ${f1(z + 1.2)} 0 ${f1(z)}T72 ${f1(z)}" stroke="#c8bfae" stroke-width="0.9" fill="none"/><path d="M-72 ${f1(z + 0.9)}Q-36 ${f1(z + 2.1)} 0 ${f1(z + 0.9)}T72 ${f1(z + 0.9)}" stroke="#ffffff" stroke-width="0.5" fill="none" opacity="0.7"/>`; });
      f += `<g transform="${planeH(p, 1.25)}"><g clip-path="url(#z8c)">${rk}</g>${[[40, -40, 13], [-24, -40, 9]].map(([x, z, r]) => rep(3, j => `<ellipse cx="${x}" cy="${z}" rx="${r + j * 3.4}" ry="${(r + j * 3.4) * 0.8}" fill="none" stroke="#c8bfae" stroke-width="0.9"/>`).join('')).join('')}</g>`;
      [[-48, -26], [50, -22]].forEach(([x, z], i) => { const q = p(x, 23, z + 4.6), u = k; f += `<rect x="${f1(q[0] - 2.4 * u)}" y="${f1(q[1] - 2.6 * u)}" width="${f1(4.8 * u)}" height="${f1(5 * u)}" rx="${f1(0.6 * u)}" fill="#ffd27a">${an('opacity', '0.75;1;0.82;0.95;0.75', 2.2, -i)}</rect>`; const g = p(x, 23, z); f += `<circle cx="${f1(g[0])}" cy="${f1(g[1])}" r="${f1(14 * u)}" fill="url(#f7g)" opacity="0.65">${an('opacity', '0.5;0.75;0.55', 2.4, -i)}</circle>`; });
      const q = p(0, 33, -15.2); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><path d="M-2.4 -1.2q1 -0.7 1.8 0M0.6 -1.2q1 -0.7 1.8 0" stroke="#8a8270" stroke-width="0.5" fill="none"/><path d="M-1 2.4q1 0.6 2 0" stroke="#8a8270" stroke-width="0.45" fill="none"/></g>`;
      un += glowE(p, 0, 0, -18, 30, 20, '#ffe6a8', 0.2);
      return { defs: FDEF + `<clipPath id="z8c"><path d="M-72 -48H72V48H-72Z M20 -40a20 16 0 1 0 40 0a20 16 0 1 0 -40 0Z M-38 -40a14 11 0 1 0 28 0a14 11 0 1 0 -28 0Z" clip-rule="evenodd"/></clipPath>`, under: un, front: f, bb: bbOf([p(-76, 0, -50), p(76, 0, 50), p(-76, 0, 50), p(76, 0, -50), p(0, 46, -21), p(-48, 40, -26)], 3) }; };
    return D; };

  // ======================= CEDAR RAISED VEGETABLE BED (tap to grow) =======================
  N.cedarBed8 = S => { const si = stageOf(S), CED = '#b9733e', CED2 = '#cf8f55', W = 50, DZ = 24, H = 16;
    const D = { w: 120, d: 70 };
    D.build = P => { const o = []; [[0, DZ], [0, -DZ]].forEach(([x, z]) => [0, 8].forEach(y => o.push(box(x, y, z, 2 * W, 7.6, 3, y ? CED2 : CED, wd({ r: 0.6 }))))); [-W, W].forEach(x => [0, 8].forEach(y => o.push(box(x, y, 0, 3, 7.6, 2 * DZ - 3, y ? CED2 : CED, wd({ r: 0.6 })))));
      [[-W, -DZ], [W, -DZ], [-W, DZ], [W, DZ]].forEach(([x, z]) => o.push(box(x, 0, z, 4.4, H + 2, 4.4, '#a8683a', wd({ r: 0.6 })), box(x, H + 2, z, 5.4, 1.2, 5.4, CED2, wd({ r: 0.4 }))));
      o.push(box(0, 0, 0, 2 * W - 3, H - 2.4, 2 * DZ - 3, '#3a2a1e', pt({ r: 0.4 }))); return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      f += `<g transform="${planeH(p, H - 2.3)}">${rep(3, i => `<path d="M${-W + 4} ${-14 + i * 14}H${W - 4}" stroke="#2a1c12" stroke-width="2.4" opacity="0.6"/><path d="M${-W + 4} ${-15 + i * 14}H${W - 4}" stroke="#5a4230" stroke-width="0.8" opacity="0.7"/>`).join('')}${rep(40, i => `<circle cx="${f1(-W + 4 + (i * 23) % (2 * W - 8))}" cy="${f1(-DZ + 4 + (i * 17) % (2 * DZ - 8))}" r="0.6" fill="#6a5240"/>`).join('')}</g>`;
      // plank grain lines on the visible faces
      [[DZ + 1.55, 1]].forEach(() => [3.8, 11.8].forEach(y => f += `<g transform="${plane(p, DZ + 1.55, y, -W)}"><path d="M2 0H${2 * W - 2}M8 1.6H${2 * W - 12}" stroke="#7a4522" stroke-width="0.3" opacity="0.6"/></g>`));
      const rows = [-14, 0, 14], cols = rep(6, i => -40 + i * 16), grow = d => si === 4 ? '' : `<animateTransform attributeName="transform" type="scale" values="0.6;1.08;1" keyTimes="0;0.6;1" dur="0.7s"${B(d)} fill="freeze" additive="sum"/>`;
      const plant = (x, z, row, i) => { if (si === 4) return ''; const q = p(x, H - 2.3, z), d = (i % 6) * 0.06; let g = '';
        if (si === 0) g = i % 6 === 0 ? `<path d="M0 0V-6" stroke="#c9a070" stroke-width="0.5"/><rect x="-2.4" y="-9.6" width="4.8" height="3.6" rx="0.4" fill="#fffaf0" stroke="#9a8a6a" stroke-width="0.2"/><circle cy="-7.8" r="1" fill="${['#e8343c', '#7ab854', '#ff8a2a'][row]}"/>` : `<ellipse rx="1.4" ry="0.6" fill="#2a1c12"/><circle cx="-0.5" cy="-0.3" r="0.35" fill="#d8c08a"/><circle cx="0.6" cy="-0.1" r="0.35" fill="#d8c08a"/>`;
        else if (si === 1) g = `<path d="M0 0V-3.2" stroke="#6fae44" stroke-width="0.5"/><path d="M0 -3Q-2.6 -4.8 -3 -2.6Q-1.4 -2 0 -3ZM0 -3Q2.6 -4.8 3 -2.6Q1.4 -2 0 -3Z" fill="#8fd060"/>`;
        else if (row === 0) { const t = si >= 3; g = `<path d="M0 0V-24" stroke="#c9a070" stroke-width="0.7"/>${rep(si === 2 ? 4 : 6, j => `<path d="M0 ${-4 - j * 3.4}q${j % 2 ? 4 : -4} -2 ${j % 2 ? 6 : -6} 0q${j % 2 ? -3 : 3} 1.6 ${j % 2 ? -6 : 6} 0Z" fill="${j % 2 ? '#3f8a34' : '#5aa844'}"/>`).join('')}${t ? [[-3, -10], [3, -14], [-2.6, -18], [2.4, -7]].map(([u, v]) => `<circle cx="${u}" cy="${v}" r="2.1" fill="#e8343c"/><ellipse cx="${u - 0.6}" cy="${v - 0.7}" rx="0.7" ry="0.45" fill="#ffffff" opacity="0.6"/><path d="M${u - 0.8} ${v - 2}l0.8 0.6l0.8 -0.6" stroke="#3f8a34" stroke-width="0.4" fill="none"/>`).join('') : ''}`; }
        else if (row === 1) { const r = si === 2 ? 3.4 : 4.6; g = rep(7, j => `<ellipse cx="${f1(Math.cos(j * 0.9) * r * 0.5)}" cy="${f1(-r * 0.6 + Math.sin(j * 0.9) * r * 0.25)}" rx="${f1(r * 0.62)}" ry="${f1(r * 0.42)}" fill="${['#9ad86a', '#7ac050', '#b4e88a'][j % 3]}" stroke="#5a9a3a" stroke-width="0.2"/>`).join('') + `<ellipse cy="${f1(-r * 0.7)}" rx="${f1(r * 0.35)}" ry="${f1(r * 0.3)}" fill="#d8f2b0"/>`; }
        else g = `${si >= 3 ? '<path d="M-1.4 0L0 4L1.4 0Z" fill="#ff8a2a" transform="translate(0 -1)"/>' : ''}${rep(5, j => `<path d="M0 0Q${(j - 2) * 1.6} -4 ${(j - 2) * 2.4} ${-(si === 2 ? 6 : 9)}" stroke="#5aa844" stroke-width="0.8" fill="none"/>`).join('')}`;
        return `<g transform="translate(${P2(q)}) scale(${n4(k)})"><g>${grow(d)}${g}</g></g>`; };
      rows.forEach((z, row) => cols.forEach((x, i) => { if (row === 0 && i % 2) return; f += plant(x + (row === 1 ? 6 : 0), z, row, i); }));
      if (si === 4) { const q = p(W + 18, 0, 10); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><ellipse cy="0.6" rx="11" ry="3" fill="#000000" opacity="0.15"/><path d="M-9 -8H9L7 0H-7Z" fill="#c9965a" stroke="#7a5430" stroke-width="0.4"/>${rep(4, j => `<path d="M-8.4 ${-6.4 + j * 1.8}H8.4" stroke="#9a6a3a" stroke-width="0.4"/>`).join('')}<path d="M-8 -8Q0 -22 8 -8" stroke="#9a6a3a" stroke-width="1.2" fill="none"/>`
          + [[-5, -10, '#e8343c', 2.4], [-1, -11, '#e8343c', 2.4], [3, -10, '#9ad86a', 3.2], [6.4, -9.4, '#ff8a2a', 1.8], [-6.6, -9, '#ff8a2a', 1.8]].map(([u, v, col, r], j) => `<g opacity="0">${once('opacity', '0;1', '0;1', 0.2, 0.2 + j * 0.18)}<circle cx="${u}" cy="${v}" r="${r}" fill="${col}">${once('cy', `${v - 30};${v - 6};${v}`, '0;0.7;1', 0.5, 0.2 + j * 0.18)}</circle></g>`).join('') + '</g>'; }
      return { defs: '', front: f, bb: bbOf([p(-W - 4, 0, -DZ - 4), p(W + 4, 0, DZ + 4), p(-W - 4, 0, DZ + 4), p(W + 4, 0, -DZ - 4), p(-40, H + 30, -14), p(W + 32, 0, 10)], 3) }; };
    return D; };

  // ======================= TIERED TERRACOTTA HERB & STRAWBERRY TOWER (tap to grow) =======================
  N.tower8 = S => { const si = stageOf(S), TC = '#c4683a', TC2 = '#b05a30', T = [[0, 26, 22], [22, 19, 18], [40, 13, 15]];
    const POCK = []; T.forEach(([y, r, h], ti) => { const n = ti === 2 ? 0 : 6; rep(n, i => { const th = i / n * 2 * PI + ti * 0.5; POCK.push([th, r + 1.6, y + h * 0.6, ti]); }); });
    const D = { w: 64, d: 64, round: 1 };
    const tier = ti => { const o = [], [y, r, h] = T[ti]; o.push(cyl(0, y, 0, r, h, TC, pt({ n: 28, rg: [[0, 0, 0.86], [h - 3, 0, 1], [h - 2.6, 0, 1.08], [h, 0, 1.08]] })));
      POCK.filter(q => q[3] === ti).forEach(([th, r, y]) => o.push(ball(r * Math.sin(th), y - 2, r * Math.cos(th), 4.2, TC2, pt({ sy: 0.8, k: 4, n: 12 })), solid({ ax: 'y', sh: 'el', c: [(r + 1) * Math.sin(th), (r + 1) * Math.cos(th)], a: 3.6, b: 2.6, yaw: -th, n: 12, rings: [[y + 1.2, 0], [y + 2, 0]], col: TC, mat: 'paint' })));
      return o; };
    const soil = (p, ti) => { const [y, r, h] = T[ti]; return `<path d="${sp(p, ellPts(0, 0, r * 1.02, r * 1.02, 40), y + h)}" fill="#3a2a1e"/><path d="${sp(p, ellPts(0, 0, r * 0.7, r * 0.7, 30), y + h)}" fill="#2a1c12" opacity="0.5"/>`; };
    D.build = P => tier(0);
    D.layers = [{ build: P => tier(1), wrap: (p, s) => soil(p, 0) + s }, { build: P => tier(2), wrap: (p, s) => soil(p, 1) + s }];
    D.fx = c => { const p = c.p, k = c.k; let f = soil(p, 2);
      const berry = (q, ripe, s) => `<g transform="translate(${P2(q)}) scale(${n4(k * s)})"><path d="M0 0Q-2.4 -0.2 -2 2.4Q-1 4.8 0 5.2Q1 4.8 2 2.4Q2.4 -0.2 0 0Z" fill="${ripe ? '#e8243c' : si === 2 ? '#c8e08a' : '#f0f0d0'}"/>${ripe ? rep(6, j => `<circle cx="${f1((j % 3 - 1) * 1)}" cy="${f1(1.6 + Math.floor(j / 3) * 1.6)}" r="0.22" fill="#ffe06a"/>`).join('') : ''}<path d="M-1.4 0L0 -1L1.4 0L0 0.6Z" fill="#3f8a34"/></g>`;
      // strawberry plants nestled inside every pocket: leaves fan out of the opening, berries spill over the lip
      POCK.slice().sort((a, b) => facing(a[0]) - facing(b[0])).forEach(([th, r, y, ti], i) => { const fc = facing(th); if (fc < -0.25) return; const q = p((r + 1) * Math.sin(th), y + 1.8, (r + 1) * Math.cos(th));
        f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><ellipse rx="3.2" ry="1.3" fill="#2a1c12"/>${si === 0 ? '<path d="M0 0V-2.4" stroke="#6fae44" stroke-width="0.5"/><path d="M0 -2.2q-1.6-1.4-2.2 0q1 0.6 2.2 0ZM0 -2.2q1.6-1.4 2.2 0q-1 0.6-2.2 0Z" fill="#8fd060"/>'
          : `<g>${atV('rotate', ['-4', '4', '-4'], 3.6, -i * 0.3)}${rep(3, j => `<g transform="rotate(${-40 + j * 40})"><path d="M0 0V-4" stroke="#4f8a34" stroke-width="0.4"/>${rep(3, m => `<path d="M0 -4Q${-2.2 + m * 2.2} -7.4 ${-1.4 + m * 1.4} -4.2Z" fill="${m === 1 ? '#3f8a34' : '#5aa844'}" stroke="#2f6a26" stroke-width="0.15"/>`).join('')}</g>`).join('')}</g>${si === 1 ? flower5([1.4, -2.2], 1, 0.9, '#ffffff') : ''}`}</g>`;
        if (si >= 2 && si < 4) [[-1.6, 0.2], [1.5, 0.6]].forEach(([du, dy]) => { const b0 = p((r + 1.8) * Math.sin(th) + du * Math.cos(th), y + 2 - dy, (r + 1.8) * Math.cos(th) - du * Math.sin(th)); f += berry(b0, si === 3, 0.75); }); });
      // herbs on top: basil + rosemary + thyme
      const tq = p(0, T[2][0] + T[2][2], 0); f += `<g transform="translate(${P2(tq)}) scale(${n4(k)})"><g>${atV('rotate', ['-3', '3', '-3'], 4)}${rep(si === 0 ? 3 : 9, j => { const a = j * 0.7 - 2.8, l = si === 0 ? 3 : si < 3 ? 8 : 11; return `<path d="M0 0Q${f1(a * 2)} ${f1(-l * 0.5)} ${f1(a * 3)} ${-l}" stroke="${j % 3 ? '#4f7a3a' : '#5a8a6a'}" stroke-width="0.6" fill="none"/>${rep(3, m => `<ellipse cx="${f1(a * 3 * (0.4 + m * 0.3))}" cy="${f1(-l * (0.4 + m * 0.3))}" rx="${j % 3 ? 1.4 : 0.5}" ry="${j % 3 ? 0.8 : 1.6}" fill="${j % 3 ? '#5aa844' : '#6a8a6a'}"/>`).join('')}`; }).join('')}</g></g>`;
      if (si === 4) { const q = p(30, 0, 14); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><ellipse cy="0.4" rx="8" ry="2" fill="#000000" opacity="0.15"/><path d="M-7 -4.6H7Q6.4 0 0 0.4Q-6.4 0 -7 -4.6Z" fill="#2f6fb0" stroke="#1a3f6a" stroke-width="0.3"/><ellipse cy="-4.6" rx="7" ry="1.6" fill="#f4efe6"/>${rep(7, j => `<g opacity="0">${once('opacity', '0;1', '0;1', 0.2, 0.2 + j * 0.15)}<g transform="translate(${-4.4 + (j % 4) * 2.8} ${-5 - Math.floor(j / 4) * 2})"><path d="M0 0Q-1.6 0 -1.4 1.8Q-0.6 3.4 0 3.6Q0.6 3.4 1.4 1.8Q1.6 0 0 0Z" fill="#e8243c"/><path d="M-1 0L0 -0.8L1 0Z" fill="#3f8a34"/></g></g>`).join('')}</g>`; }
      return { defs: '', front: f, bb: bbOf([p(-32, 0, -32), p(32, 0, 32), p(-32, 0, 32), p(32, 0, -32), p(0, 66, 0), p(40, 0, 14)], 3) }; };
    return D; };

  // ======================= WOVEN RATTAN HANGING EGG CHAIR =======================
  N.eggSwing = S => { const HK = [0, 104, -6], TOPY = 78, RAT = '#b8864e';
    const D = { w: 80, d: 70, seats: [{ x: 0, z: 6, h: 32 }] };
    D.build = P => [cyl(0, 0, -6, 19, 2, '#2a2b30', mt({ n: 28, shine: 1, rg: [[0, 0, 1], [1.4, 0, 0.97], [2, 0, 0.88]] })), cyl(0, 2, -6, 3.4, 1.6, '#2a2b30', mt({ n: 12 }))];
    D.layers = [{ build: P => [cyl(0, 22, 0, 23, 56, RAT, fb({ n: 30, rg: [[0, 0, 0.32], [4, 0, 0.7], [14, 0, 0.96], [26, 0, 1], [40, 0, 0.92], [50, 0, 0.66], [56, 0, 0.22]] })), cyl(0, TOPY, 0, 2.6, 2, '#2a2b30', mt({ n: 10 }))],
      wrap: (p, s) => { const k = kOf(p); const hk = p(...HK);
        // front opening: shaded hollow, cream seat cushion + back pillow
        const TM = PI / 6, mouth = 'M' + rep(33, i => { const a = i / 32 * 2 * PI, u = 13 * Math.sin(a), y = 48 + 17 * Math.cos(a), R = 21.4; return P2(p(R * Math.sin(TM + u / R), y, R * Math.cos(TM + u / R))); }).join('L') + 'Z';
        const inner = `<path d="${mouth}" fill="#5a3a1e"/><path d="${mouth}" fill="url(#e8in)"/>`;
        const cush = (() => { const q = p(9, 34, 15.6), q2 = p(4, 48, 4); return `<ellipse cx="${f1(q2[0])}" cy="${f1(q2[1])}" rx="${f1(10 * k)}" ry="${f1(12 * k)}" fill="#f2ece0" stroke="#c8bca4" stroke-width="${f1(0.3 * k)}"/><ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(13 * k)}" ry="${f1(5 * k)}" fill="#f6f1e6" stroke="#c8bca4" stroke-width="${f1(0.3 * k)}"/><ellipse cx="${f1(q[0] - 3 * k)}" cy="${f1(q[1] - 1.4 * k)}" rx="${f1(5 * k)}" ry="${f1(1.4 * k)}" fill="#ffffff" opacity="0.6"/>`; })();
        const chain = rep(9, i => { const a = [HK[0], HK[1] - i * (HK[1] - TOPY - 2) / 8, HK[2] + (i / 8) * 6], q = p(...a); return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((i % 2 ? 0.6 : 1.1) * k)}" ry="${f1(1.5 * k)}" fill="none" stroke="#c9d0d6" stroke-width="${f1(0.6 * k)}"/>`; }).join('');
        return `<g>${atV('rotate', [`-2.6 ${P2(hk)}`, `2.6 ${P2(hk)}`, `-2.6 ${P2(hk)}`], 4.6)}${chain}<g>${tex(s, [['q8wv', 0.95]])}</g>${inner}<clipPath id="e8m"><path d="${mouth}"/></clipPath><g clip-path="url(#e8m)">${cush}</g><path d="${mouth}" fill="none" stroke="#8a5a2a" stroke-width="${f1(1.4 * k)}"/></g>`; } }];
    D.fx = c => { const p = c.p, k = c.k; const st0 = [p(0, 4, -26), p(0, 60, -34), p(0, 100, -26), p(...HK)];
      const stand = tube([p(0, 3, -6), p(0, 2.6, -28)].concat(curve([0, 2.6, -28], [0, 70, -40], [0, 104, -22], 10).map(q => p(...q))).concat([p(0, 106, -12), p(...HK)]), 2.4, k, '#2a2b30', '#8a8f98'); void st0;
      return { defs: LEAF + L('e8in', [[0, '#2a1a0c', 0.85], [1, '#7a5430', 0.3]]), back: stand, front: '', bb: bbOf([p(-28, 0, -40), p(28, 0, 22), p(0, 112, -24), p(-28, 0, 22), p(28, 0, -40)], 3) }; };
    return D; };

  // ======================= SUSPENDED CEDAR PORCH DAYBED SWING =======================
  N.porchSwing = S => { const CED = '#b9733e', CED2 = '#cf8f55', BX = 40, BZ = 18, BY = 22, BEAM = 92;
    const D = { w: 130, d: 70, seats: [{ x: -14, z: 2, h: BY + 9 }, { x: 14, z: 2, h: BY + 9 }] };
    D.build = P => { const o = []; [-1, 1].forEach(s => { o.push(box(s * 54, 0, -24, 5, BEAM, 5, CED, wd({ r: 0.8 })), box(s * 54, 0, 24, 5, BEAM, 5, CED, wd({ r: 0.8 })), box(s * 54, 0, 0, 5, 6, 58, CED2, wd({ r: 0.8 })), box(s * 54, BEAM - 8, 0, 5, 6, 54, CED2, wd({ r: 0.8 }))); });
      o.push(box(0, BEAM, 0, 118, 6, 7, CED2, wd({ r: 0.8 }))); return o; };
    const corners = [[-BX + 2, -BZ + 2], [BX - 2, -BZ + 2], [-BX + 2, BZ - 2], [BX - 2, BZ - 2]];
    D.layers = [{ build: P => { const o = [box(0, BY, 0, 2 * BX, 4, 2 * BZ, CED, wd({ r: 0.8 })), cush(0, BY + 4, 1.5, 2 * BX - 6, 6, 2 * BZ - 7, '#f2ece0'), box(0, BY + 4, -BZ + 1.6, 2 * BX - 6.2, 18, 3, CED2, wd({ r: 0.8 })), box(-BX + 1.6, BY + 4, 1.5, 3, 10, 2 * BZ - 3, CED2, wd({ r: 0.8 })), box(BX - 1.6, BY + 4, 1.5, 3, 10, 2 * BZ - 3, CED2, wd({ r: 0.8 }))]; // backrest runs between the side rails, the rails start in front of it (clear in x and z)
        o.push(ball(-26, BY + 10, -BZ + 6, 6, '#7aa8c8', fb({ sx: 1.2, sy: 1, sz: 0.5, k: 4, n: 12 })), ball(24, BY + 10, -BZ + 6, 6, '#e8b45a', fb({ sx: 1.2, sy: 1, sz: 0.5, k: 4, n: 12 })), ball(-2, BY + 10, -BZ + 7, 5, '#f4efe6', fb({ sx: 1.3, sy: 0.9, sz: 0.5, k: 4, n: 12 })));
        return o; },
      wrap: (p, s) => { const k = kOf(p); let rb = '', rf = '';
        corners.forEach(([x, z]) => { const top = [x * 1.05, BEAM, 0], bot = [x, BY + 2, z], t = tube([p(...top), p(...bot)], 0.9, k, '#e8dcc0', '#ffffff', '#8a7a5a') + `<circle cx="${f1(p(...bot)[0])}" cy="${f1(p(...bot)[1])}" r="${f1(1.3 * k)}" fill="none" stroke="#c9d0d6" stroke-width="${f1(0.6 * k)}"/>`; if (z < 0) rb += t; else rf += t; });
        const pv = p(0, BEAM, 0); return `<g>${atV('rotate', [`-1.6 ${P2(pv)}`, `1.6 ${P2(pv)}`, `-1.6 ${P2(pv)}`], 3.8)}${rb}${s}${rf}</g>`; } }];
    const cush = (x, y, z, w, h, d, c) => K.cush(x, y, z, w, h, d, c, fb({}));
    D.fx = c => ({ defs: '', front: '', bb: bbOf([c.p(-60, 0, -30), c.p(60, 0, 30), c.p(-60, BEAM + 8, -30), c.p(60, BEAM + 8, 30), c.p(-60, 0, 30), c.p(60, 0, -30)], 3) });
    return D; };

  // ======================= CINDERBLOCK & 2x4 PLANK BENCH (with backrest in front of its posts) =======================
  N.blockBench = S => { const CB = '#a9a8a2', PL = '#d8b98a';
    const D = { w: 110, d: 40, seats: [{ x: -16, z: 2, h: 17 }, { x: 16, z: 2, h: 17 }] };
    D.build = P => { const o = []; [-34, 34].forEach(x => o.push(box(x, 0, 0, 16, 7.6, 15, CB, pt({ r: 0.5 })), box(x, 7.6, 0, 16, 7.6, 15, CB, pt({ r: 0.5 }))));
      [-5, 0.2, 5.4].forEach(z => o.push(box(0, 15.2, z, 96, 1.8, 4.8, PL, wd({ r: 0.4 }))));
      [-34, 34].forEach(x => o.push(box(x - 4, 17, -5.4, 3.6, 24.2, 1.8, PL, wd({ r: 0.3 })), box(x + 4, 17, -5.4, 3.6, 24.2, 1.8, PL, wd({ r: 0.3 })))); // uprights stand on the back seat plank
      [28, 36].forEach(y => o.push(box(0, y, -3.6, 96, 4.8, 1.8, PL, wd({ r: 0.4 }))));
      return o; };
    D.fx = c => { const p = c.p; let f = '';
      [-34, 34].forEach(x => [0, 7.6].forEach(y => f += `<g transform="${plane(p, 7.55, y + 7.6, x - 8)}"><rect x="2" y="1.4" width="5" height="4.8" rx="0.6" fill="#6a6964"/><rect x="9" y="1.4" width="5" height="4.8" rx="0.6" fill="#6a6964"/><rect x="2" y="1.4" width="5" height="1" fill="#4a4946"/><rect x="9" y="1.4" width="5" height="1" fill="#4a4946"/></g>`));
      f += `<g transform="${planeH(p, 17.05)}">${[-5, 0.2, 5.4].map(z => `<path d="M-46 ${z}H46" stroke="#a8875a" stroke-width="0.3"/><circle cx="-44" cy="${z}" r="0.5" fill="#6a6a6a"/><circle cx="44" cy="${z}" r="0.5" fill="#6a6a6a"/>`).join('')}</g>`;
      return { defs: '', front: f, bb: bbOf([p(-50, 0, -10), p(50, 0, 10), p(-50, 42, -6), p(50, 42, -6)], 3) }; };
    return D; };

  // ======================= CAST-IRON PARK BENCH WITH OAK SLATS =======================
  N.parkBench = S => { const IR = '#1f2124', OAK = '#c08a52';
    const D = { w: 110, d: 44, seats: [{ x: -18, z: 2, h: 17 }, { x: 18, z: 2, h: 17 }] };
    D.build = P => { const o = [];
      rep(5, i => o.push(box(0, 15.4, -7 + i * 4.2, 88, 1.8, 3.4, OAK, wd({ r: 0.5 }))));
      rep(4, i => { const y = 21 + i * 5.6, z = -9.8 - i * 0.8; o.push(box(0, y, z, 88, 4.2, 1.6, OAK, wd({ r: 0.4 }))); });
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      let bk = ''; [-43, 43].forEach(x => { const P3 = a => a.map(([z, y]) => p(x, y, z)); let s2 = tube(P3([[11, 0], [9, 15], [10.6, 23.6]]), 1.8, k, IR, '#6a6e76') + tube(P3([[-12, 0], [-9, 15].concat(), [-10.4, 22], [-12.6, 33], [-14.6, 44]]), 1.8, k, IR, '#6a6e76') + tube(P3([[-10, 15], [9.4, 15]]), 1.5, k, IR, '#6a6e76') + tube(P3([[-10.6, 24], [12, 24], [13.4, 22.4]]), 1.7, k, IR, '#6a6e76');
        s2 += tube(P3(rep(9, i => { const a = i / 8 * 2 * PI; return [-1 + Math.cos(a) * 3.2, 7.4 + Math.sin(a) * 3.2]; })), 0.6, k, IR, '#6a6e76') + tube(P3(rep(7, i => { const a = PI + i / 6 * PI * 1.4; return [-11.6 + Math.cos(a) * 1.6, 36 + Math.sin(a) * 1.6]; })), 0.5, k, IR, '#6a6e76') + `<ellipse cx="${f1(p(x, 0, 11)[0])}" cy="${f1(p(x, 0, 11)[1])}" rx="${f1(2 * k)}" ry="${f1(0.9 * k)}" fill="#141416"/>`;
        if (x < 0) bk += s2; else f += s2; });
      return { defs: '', back: bk, front: f, bb: bbOf([p(-48, 0, -16), p(48, 0, 16), p(-48, 46, -16), p(48, 46, -16)], 3) }; };
    return D; };

  // ======================= SUN-BLEACHED RESIN LAWN CHAIRS (pair) =======================
  N.lawnChairs = S => { const RS = '#f2efe8';
    const D = { w: 110, d: 50, seats: [{ x: -24, z: 2, h: 15 }, { x: 24, z: 2, h: 15 }] };
    const chair = (o, cx) => { [[-9, 8], [9, 8]].forEach(([x, z]) => o.push(box(cx + x, 0, z, 2.6, 14, 2.6, RS, pt({ r: 1 }))));
      [[-9, -8], [9, -8]].forEach(([x, z]) => o.push(box(cx + x, 0, z, 2.6, 14, 2.6, RS, pt({ r: 1 }))));
      o.push(K.cush(cx, 13, 0.6, 22, 2.6, 19, RS, pt({ r: 3 })), prism(cx - 10.6, cx + 10.6, [[-9.6, 15], [-7.4, 15], [-10.4, 38], [-12.8, 38]], RS, pt({ r: 3 })), box(cx - 11, 21, 0, 2.2, 1.6, 18, RS, pt({ r: 0.8 })), box(cx + 11, 21, 0, 2.2, 1.6, 18, RS, pt({ r: 0.8 })), box(cx - 11, 14, 8.4, 2, 7, 2, RS, pt({ r: 0.8 })), box(cx + 11, 14, 8.4, 2, 7, 2, RS, pt({ r: 0.8 }))); };
    D.build = P => { const o = []; chair(o, -24); chair(o, 24); return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      [-24, 24].forEach(cx => { rep(4, i => { const y = 22 + i * 3.6, z = -9 - (y - 15) * (2.6 / 23) - 0.4, a = p(cx - 7, y, z + 0.1), b = p(cx + 7, y, z + 0.1); f += `<path d="M${P2(a)}L${P2(b)}" stroke="#b9b4aa" stroke-width="${f1(1.1 * k)}" stroke-linecap="round"/><path d="M${P2(a)}L${P2(b)}" stroke="#d6d1c6" stroke-width="${f1(0.5 * k)}" stroke-linecap="round" transform="translate(0 ${f1(0.5 * k)})"/>`; });
        f += `<g transform="${planeH(p, 15.7, cx, 0.6)}"><path d="M-6 -4L-3 1L-5 5" stroke="#c9c3b6" stroke-width="0.3" fill="none"/></g>`; });
      return { defs: '', front: f, bb: bbOf([p(-40, 0, -14), p(40, 0, 14), p(-40, 40, -14), p(40, 40, -14)], 3) }; };
    return D; };

  // ======================= CRANK-OPEN STRIPED PATIO UMBRELLA =======================
  N.umbrella8 = S => { const R = 46, TOP = 84, RIM = 72, C1 = '#2f86c8', C2 = '#fbf7ee';
    const D = { w: 100, d: 100, round: 1 };
    D.build = P => [cyl(0, 0, 0, 13, 3.6, '#2c2e33', mt({ n: 24, shine: 1, rg: [[0, 0, 1], [3, 0, 0.95], [3.6, 0, 0.6]] })), cyl(0, 3.6, 0, 1.6, TOP - 3.6, '#e8e4dc', mt({ n: 10, shine: 1 })), cyl(0, 30, 0, 2.6, 6, '#c9d0d6', mt({ n: 10, shine: 1 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      const rimP = i => { const a = i / 8 * 2 * PI + PI / 8; return [R * Math.cos(a), RIM, R * Math.sin(a)]; };
      // ribs underside (back ones first), canopy panels sorted back to front, scalloped valance
      const panels = rep(8, i => { const a = rimP(i), b = rimP(i + 1), m = [(a[0] + b[0]) / 2 * 0.98, RIM + 1.6, (a[2] + b[2]) / 2 * 0.98], dep = (m[0] * 0.5 + m[2] * 0.866); return { i, a, b, m, dep }; }).sort((u, v) => u.dep - v.dep);
      rep(8, i => { const a = rimP(i); bk += tube([p(0, TOP - 1, 0), p(a[0] * 0.98, RIM - 0.4, a[2] * 0.98)], 0.6, k, '#d8d2c4', '#ffffff', '#6a6a60') + tube([p(0, 46, 0), p(a[0] * 0.45, RIM - 4, a[2] * 0.45)], 0.45, k, '#d8d2c4', '#ffffff', '#6a6a60'); });
      panels.forEach(({ i, a, b, m }) => { const col = i % 2 ? C1 : C2, lit = 0.5 + 0.5 * Math.max(-1, Math.min(1, -((a[0] + b[0]) * 0.5 * 0.4 - (a[2] + b[2]) * 0.5 * 0.2) / R)); const A = p(...a), Bq = p(...b), M = p(...m), T0 = p(0, TOP, 0);
        f += `<path d="M${P2(T0)}L${P2(A)}Q${P2(M)} ${P2(Bq)}Z" fill="${col}" stroke="#8a8478" stroke-width="${f1(0.3 * k)}"/><path d="M${P2(T0)}L${P2(A)}Q${P2(M)} ${P2(Bq)}Z" fill="${lit > 0.55 ? '#ffffff' : '#000000'}" opacity="${n4(Math.abs(lit - 0.55) * 0.35)}"/>`;
        const fr = facing(Math.atan2(m[0], m[2])); if (fr > -0.1) { let v = ''; rep(5, j => { const t0 = j / 5, t1 = (j + 1) / 5, q0 = p(a[0] + (b[0] - a[0]) * t0, RIM, a[2] + (b[2] - a[2]) * t0), q1 = p(a[0] + (b[0] - a[0]) * t1, RIM, a[2] + (b[2] - a[2]) * t1); v += `<path d="M${P2(q0)}L${P2(q1)}Q${f1((q0[0] + q1[0]) / 2)} ${f1((q0[1] + q1[1]) / 2 + 4 * k)} ${P2(q0)}Z" fill="${col === C1 ? C2 : C1}" stroke="#8a8478" stroke-width="${f1(0.2 * k)}"/>`; }); f += v; } });
      const T0 = p(0, TOP, 0); f += `<circle cx="${f1(T0[0])}" cy="${f1(T0[1] - 2 * k)}" r="${f1(2.4 * k)}" fill="#e8e4dc" stroke="#8a8478" stroke-width="${f1(0.3 * k)}"/>`;
      const cq = p(2.6, 33, 0); bk += `<path d="M${P2(cq)}l${f1(4 * k)} ${f1(1 * k)}l0 ${f1(3 * k)}" stroke="#c9d0d6" stroke-width="${f1(0.7 * k)}" fill="none"/><circle cx="${f1(cq[0] + 4 * k)}" cy="${f1(cq[1] + 4 * k)}" r="${f1(1 * k)}" fill="#2c2e33"/>`;
      return { defs: '', back: '', front: bk + `<g>${atV('translate', ['0 0', `0 ${f1(-0.6 * k)}`, '0 0'], 3.4)}${f}</g>`, bb: bbOf([p(-R - 2, RIM - 4, -R - 2), p(R + 2, RIM - 4, R + 2), p(-R - 2, RIM - 4, R + 2), p(R + 2, RIM - 4, -R - 2), p(0, TOP + 4, 0), p(-14, 0, 14), p(14, 0, -14)], 3) }; };
    return D; };

  // ======================= MOTORIZED LOUVERED BIOCLIMATIC CABANA =======================
  N.cabana8 = S => { const W = 60, DZ = 40, H = 66, AL = '#3a3d42';
    const D = { w: 130, d: 90, seats: [{ x: -16, z: 4, h: 14 }, { x: 14, z: 4, h: 14 }] };
    D.build = P => { const o = [box(0, 0, 0, 2 * W + 8, 1.4, 2 * DZ + 8, '#cfc7b6', cer({ r: 1 }))]; [[-W, -DZ], [W, -DZ], [-W, DZ], [W, DZ]].forEach(([x, z]) => o.push(box(x, 1.4, z, 5, H, 5, AL, mt({ r: 0.8 }))));
      o.push(box(0, H, DZ, 2 * W + 5, 7, 5, AL, mt({ r: 0.8 })), box(0, H, -DZ, 2 * W + 5, 7, 5, AL, mt({ r: 0.8 })), box(-W, H, 0, 5, 7, 2 * DZ, AL, mt({ r: 0.8 })), box(W, H, 0, 5, 7, 2 * DZ, AL, mt({ r: 0.8 })));
      o.push(box(0, 1.4, -14, 82, 7, 28, '#3a3d42', mt({ r: 1 })), box(-42, 1.4, -14, 6, 17, 28, '#3a3d42', mt({ r: 1 })), box(42, 1.4, -14, 6, 17, 28, '#3a3d42', mt({ r: 1 })), box(0, 1.4, -27, 90, 22, 4, '#3a3d42', mt({ r: 1 })), K.cush(-19.6, 8.4, -12, 38, 6, 24, '#ece6d8', fb({})), K.cush(19.6, 8.4, -12, 38, 6, 24, '#ece6d8', fb({})), K.cush(-19.6, 14, -23, 38, 14, 6, '#ece6d8', fb({})), K.cush(19.6, 14, -23, 38, 14, 6, '#ece6d8', fb({})), K.cush(-26, 14, -18, 12, 10, 5, '#3f6a8a', fb({})), K.cush(26, 14, -18, 12, 10, 5, '#c8a45a', fb({})), box(0, 1.4, 18, 34, 11, 18, '#8a5a34', wd({ r: 1 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      // louver blades tilt open and closed (motorized), LED strip in the frame, privacy screen on the back
      f += `<clipPath id="cb8"><path d="${quad(p, [-W + 2.5, H + 7, -DZ + 2.5], [W - 2.5, H + 7, -DZ + 2.5], [W - 2.5, H + 7, DZ - 2.5], [-W + 2.5, H + 7, DZ - 2.5])}"/></clipPath><g clip-path="url(#cb8)">`;
      const n = 16; rep(n, i => { const x = -W + 4 + i * (2 * W - 8) / (n - 1), A = [x - 2.6, H + 5.4], Bv = [x + 2.6, H + 5.4]; const q = (dx, dy) => P2(p(x + dx, H + 5.4 + dy, -DZ + 2)), r = (dx, dy) => P2(p(x + dx, H + 5.4 + dy, DZ - 2));
        const sh = t => `M${q(-3.2 * t, 1.6 * (1 - t))}L${r(-3.2 * t, 1.6 * (1 - t))}L${r(3.2 * t, -1.6 * (1 - t))}L${q(3.2 * t, -1.6 * (1 - t))}Z`; void A; void Bv;
        f += `<path d="${sh(1)}" fill="#e2e4e8" stroke="#6a6e76" stroke-width="${f1(0.3 * k)}"><animate attributeName="d" values="${sh(1)};${sh(1)};${sh(0.18)};${sh(0.18)};${sh(1)}" keyTimes="0;0.35;0.5;0.85;1" dur="14s" repeatCount="indefinite"/></path>`; });
      f += '</g>';
      f += `<path d="M${P2(p(-W + 3, H + 0.4, DZ - 2.4))}L${P2(p(W - 3, H + 0.4, DZ - 2.4))}" stroke="#fff2c8" stroke-width="${f1(0.9 * k)}">${an('opacity', '0.7;1;0.7', 3)}</path>`;
      un += glowE(p, 0, 0, 0, 50, 34, '#fff2c8', 0.18);
      return { defs: FDEF, under: un, front: f, bb: bbOf([p(-W - 6, 0, -DZ - 6), p(W + 6, 0, DZ + 6), p(-W - 6, 0, DZ + 6), p(W + 6, 0, -DZ - 6), p(0, H + 10, -DZ), p(0, H + 10, DZ)], 3) }; };
    return D; };

  // ======================= TENSIONED CANVAS SHADE SAIL ON TIMBER POSTS =======================
  N.sail8 = S => { const PO = [[-52, -28, 74], [50, -34, 66], [10, 36, 56]], WD = '#9a6a3c';
    const D = { w: 120, d: 90, seats: [{ x: -6, z: 0, h: 0 }] };
    D.build = P => PO.map(([x, z, h]) => box(x, 0, z, 5, h, 5, WD, wd({ r: 0.8 }))).concat(PO.map(([x, z]) => cyl(x, 0, z, 5.6, 2, '#7a7468', pt({ n: 10 }))));
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      const C = PO.map(([x, z, h]) => [x * 0.9, h - 3, z * 0.9]), mid = (a, b, s) => [(a[0] + b[0]) / 2 * s, (a[1] + b[1]) / 2 + 2, (a[2] + b[2]) / 2 * s];
      const cen = [0, 58, -6], sh = (bl) => { const d = [0, 1, 2].map(i => { const a = C[i], b = C[(i + 1) % 3], m = mid(a, b, 0.8); return `${P2(p(...a))}Q${P2(p(m[0], m[1], m[2]))} `; }); return 'M' + d[0] + P2(p(...C[1])) + 'Q' + P2(p(...mid(C[1], C[2], 0.8))) + ' ' + P2(p(...C[2])) + 'Q' + P2(p(...mid(C[2], C[0], 0.8))) + ' ' + P2(p(...C[0])) + 'Z'; void bl; };
      const s0 = sh(), cc = p(...cen); f += `<g>${atV('translate', ['0 0', `0 ${f1(-1.4 * k)}`, '0 0'], 3.6)}<path d="${s0}" fill="#f6f0e2" stroke="#b8ad96" stroke-width="${f1(0.5 * k)}"/><path d="${s0}" fill="url(#sl8)"/><circle cx="${f1(cc[0])}" cy="${f1(cc[1])}" r="${f1(30 * k)}" fill="#ffffff" opacity="0.18"/></g>`;
      PO.forEach(([x, z, h], i) => { const a = C[i], b = [x, h - 1, z]; f += tube([p(...a), p(...b)], 0.7, k, '#d5dde2', '#ffffff', '#5a5e66') + `<circle cx="${f1(p(...a)[0])}" cy="${f1(p(...a)[1])}" r="${f1(1.4 * k)}" fill="none" stroke="#9aa1ad" stroke-width="${f1(0.6 * k)}"/>`; });
      return { defs: L('sl8', [[0, '#ffffff', 0.25], [0.6, '#000000', 0], [1, '#000000', 0.18]], 'x1="0" y1="0" x2="1" y2="1"'), front: f, bb: bbOf([p(-58, 0, -34), p(58, 0, 40), p(-58, 80, -34), p(56, 72, -40), p(12, 0, 42), p(12, 60, 42)], 3) }; };
    return D; };

  // ======================= WISTERIA-DRAPED CEDAR PERGOLA =======================
  N.wisteria8 = S => { const W = 54, DZ = 34, H = 70, CED = '#a8683a', CED2 = '#c08050';
    const D = { w: 130, d: 90, seats: [{ x: -12, z: 0, h: 14 }, { x: 12, z: 0, h: 14 }] };
    D.build = P => { const o = [box(0, 0, 0, 2 * W + 10, 1.2, 2 * DZ + 10, '#d8ccb0', pt({ r: 1 }))]; [[-W, -DZ], [W, -DZ], [-W, DZ], [W, DZ]].forEach(([x, z]) => o.push(box(x, 1.2, z, 6, H, 6, CED, wd({ r: 0.8 })), box(x, 1.2, z, 8, 6, 8, CED2, wd({ r: 0.8 }))));
      o.push(box(0, H, -DZ, 2 * W + 20, 7, 4, CED2, wd({ r: 0.6 })), box(0, H, DZ, 2 * W + 20, 7, 4, CED2, wd({ r: 0.6 })));
      rep(7, i => o.push(box(-W + i * (2 * W / 6), H + 7, 0, 3, 5, 2 * DZ + 18, CED, wd({ r: 0.5 }))));
      o.push(K.cush(0, 1.2, -6, 54, 12, 20, '#e8e2d4', fb({})), box(0, 1.2, 16, 26, 10, 14, '#8a8478', pt({ r: 1 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      // leafy vine canopy on the rafters + hanging racemes that sway
      const R = rng('wis'); let lv = '';
      rep(70, i => { const x = (R() - 0.5) * (2 * W + 12), z = (R() - 0.5) * (2 * DZ + 14), q = p(x, H + 12 + R() * 2, z); lv += `<path d="M0 0q2-2.2 4.4-0.4q-2.2 1.8-4.4 0.4Z" fill="${['#4f8a3a', '#6aa84a', '#3f7a2e'][i % 3]}" transform="translate(${P2(q)}) rotate(${f1(R() * 360)}) scale(${n4(k * 1.2)})"/>`; });
      let rc = ''; rep(26, i => { const x = (R() - 0.5) * (2 * W + 8), z = (R() - 0.5) * (2 * DZ + 8), q = p(x, H + 6, z), L0 = 10 + R() * 9; let g = ''; rep(12, j => { const t = j / 11; g += `<circle cx="${f1((R() - 0.5) * 2 * (1 - t))}" cy="${f1(t * L0)}" r="${f1((1.5 - t) * 1.3)}" fill="${['#b49af0', '#9a7ad8', '#c8b4f8', '#8a6ac8'][j % 4]}"/>`; });
        rc += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><g>${atV('rotate', ['-5', '5', '-5'], 3 + R() * 2, -R() * 3)}<path d="M0 0V3" stroke="#5a8a3a" stroke-width="0.4"/>${g}</g></g>`; });
      [[-W, DZ], [W, DZ]].forEach(([x, z]) => { const pts = rep(16, i => { const t = i / 15, a = t * 8; return p(x + Math.cos(a) * 3.6, 2 + t * (H - 2), z + Math.sin(a) * 3.6); }); f += `<path d="M${pts.map(P2).join('L')}" fill="none" stroke="#6a4a2a" stroke-width="${f1(1 * k)}"/>` + pts.filter((q, i) => i % 3 === 1).map(q => `<path d="M0 0q2-2 4 0q-2 1.6-4 0Z" fill="#5a9a44" transform="translate(${P2(q)}) scale(${n4(k)})"/>`).join(''); });
      f += lv + rc;
      return { defs: '', back: bk, front: f, bb: bbOf([p(-W - 12, 0, -DZ - 12), p(W + 12, 0, DZ + 12), p(-W - 12, H + 16, DZ + 12), p(W + 12, H + 16, -DZ - 12), p(-W - 12, 0, DZ + 12), p(W + 12, 0, -DZ - 12)], 3) }; };
    return D; };

  // ======================= MODERN CEDAR & BLACK STEEL GARDEN SHED =======================
  N.shed8 = S => { const W = 44, DZ = 30, HF = 70, HB = 58, CED = '#c08a56', BK = '#26272b';
    const D = { w: 110, d: 80 };
    D.build = P => [box(0, 0, 0, 2 * W + 16, 1.2, 2 * DZ + 20, '#b9b2a4', pt({ r: 1 })), box(0, 1.2, 0, 2 * W, HB, 2 * DZ, CED, wd({ r: 0.4 })), prism(-W, W, [[-DZ, HB + 1.2], [DZ, HB + 1.2], [DZ, HF + 1.2], [-DZ, HB + 1.2]], CED, wd({})),
      prism(-W - 3, W + 3, [[-DZ - 4, HB + 1], [DZ + 5, HF + 1], [DZ + 5, HF + 3.4], [-DZ - 4, HB + 3.4]], BK, mt({ shine: 1 })), box(0, 1.2, DZ + 0.6, 2 * W + 1, 2.4, 1.2, BK, mt({ r: 0.3 })), ...[[-W, -DZ], [W, -DZ], [-W, DZ], [W, DZ]].map(([x, z]) => box(x, 1.2, z, 2.4, HB + (z > 0 ? 12 : 0), 2.4, BK, mt({ r: 0.3 })))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      let fr = ''; rep(22, i => fr += `<path d="M${f1(2 + i * 4)} 0V${HB - 1}" stroke="#8a5a30" stroke-width="0.35" opacity="0.7"/>`);
      fr += `<rect x="${W - 13}" y="${HB - 52}" width="26" height="50" fill="${BK}"/><rect x="${W - 11}" y="${HB - 50}" width="22" height="47" fill="#3a2a1e"/>${rep(8, i => `<path d="M${W - 11} ${HB - 47 + i * 5.6}H${W + 11}" stroke="#2a1c12" stroke-width="0.5"/>`).join('')}<rect x="${W + 6}" y="${HB - 28}" width="1.4" height="9" rx="0.7" fill="#c9d0d6"/>`;
      fr += `<rect x="6" y="${HB - 50}" width="22" height="16" fill="${BK}"/><rect x="7.2" y="${HB - 48.8}" width="19.6" height="13.6" fill="url(#sh8g)"/><path d="M17 ${HB - 48.8}V${HB - 35.2}" stroke="${BK}" stroke-width="1"/>`;
      f += `<g transform="${plane(p, DZ + 0.05, HB + 1.2, -W)}">${fr}</g>`;
      let sd = ''; rep(15, i => sd += `<path d="M${f1(2 + i * 4)} 0V${HB - 1}" stroke="#8a5a30" stroke-width="0.35" opacity="0.6"/>`); sd += `<rect x="16" y="${HB - 54}" width="30" height="7" fill="${BK}"/><rect x="17" y="${HB - 53}" width="28" height="5" fill="url(#sh8g)"/>`;
      f += `<g transform="${planeX(p, W + 0.05, HB + 1.2, DZ)}"><g transform="scale(-1 1)">${sd}</g></g>`;
      { const q = p(W - 22, 0, DZ + 10); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><path d="M-5 -10H5L4 0H-4Z" fill="#2a2b30"/><path d="M-5 -10H5" stroke="#55575e" stroke-width="0.6"/>${rep(9, j => `<path d="M0 -10Q${(j - 4) * 1.6} -18 ${(j - 4) * 2.6} -24" stroke="${j % 2 ? '#4f8a3a' : '#6aa84a'}" stroke-width="1.2" fill="none"/>`).join('')}</g>`; }
      return { defs: L('sh8g', [[0, '#cfe8f2'], [0.5, '#8fb8cc'], [1, '#e8f6fb']], 'x1="0" y1="0" x2="1" y2="1"'), front: f, bb: bbOf([p(-W - 8, 0, -DZ - 10), p(W + 8, 0, DZ + 12), p(-W - 4, HB + 4, -DZ - 4), p(W + 4, HF + 4, DZ + 6), p(-W - 8, 0, DZ + 12), p(W + 8, 0, -DZ - 10)], 3) }; };
    return D; };

  // ---------- catalog edits ----------
  const GROW = ['Seeds', 'Sprouts', 'Leafy', 'Ripe', 'Harvest'], GROWT = ['Planted', 'Flowering', 'Green berries', 'Ripe', 'Harvest'];
  RD.SET8 = {
    'YRD-031': { spec: 'lemon8', live: 'Swaying', note: 'A dwarf Meyer lemon in an oak half-barrel with steel hoops and bark mulch. A lush, rounded canopy of glossy dark leaves (lit from the top, darker underneath) on three branching limbs, hung with bright lemons and white blossoms. It sways gently in the breeze.' },
    'YRD-067': { spec: 'parterre8', live: 'Roses swaying', note: 'A formal French parterre: clipped boxwood borders and knot hedges, cone topiaries, a ring of boxwood balls round a terracotta-potted topiary, four beds of red and pink roses on pale gravel, and a white iron arch at the back covered in climbing roses.' },
    'YRD-071': { spec: 'grove8', live: 'Swaying', note: 'An ancient olive with a gnarled trunk of three braided limbs and an airy silver-green crown dotted with black olives, beside two tall Italian cypresses, with lavender tufts on pale gravel.' },
    'YRD-064': { spec: 'zen8', live: 'Lanterns glowing', note: 'A raked-gravel zen garden: a seated limestone Buddha on a lotus base, two stone pagoda lanterns with warm flickering windows, stepping stones, moss mounds and rocks ringed by raked circles.' },
    'YRD-027': { spec: 'cedarBed8', kind: 'grow', modes: GROW, modeLbl: 'STAGE', live: 'Tap to grow', note: 'A clean cedar raised bed with corner posts and dark soil furrows. Tap to grow: seeds with plant tags, sprouts, leafy plants, then ripe tomatoes on stakes, lettuce heads and carrots. The last tap harvests everything into a basket and the bed starts again.' },
    'YRD-047': { spec: 'tower8', kind: 'grow', modes: GROWT, modeLbl: 'STAGE', live: 'Tap to grow', note: 'Three stacked terracotta pots with planting pockets all round. The strawberry plants grow inside each pocket and their berries hang over the lip; herbs fill the top. Tap to grow: planted, flowering, green berries, ripe red berries, then harvest into a bowl and replant.' },
    'YRD-050': { spec: 'eggSwing', live: 'Gently swinging', note: 'A woven rattan egg chair with a cream seat cushion and back pillow. It hangs from a curved black steel stand by a chain that is fixed to the top of the egg, and swings gently.' },
    'YRD-070': { spec: 'porchSwing', live: 'Gently swinging', note: 'A cedar daybed swing on its own timber frame. Four ropes run from the top beam down to the corners of the bed frame, so the bed hangs from them properly. Soft mattress and throw pillows; it sways slowly. Seats 2.' },
    'YRD-013': { spec: 'blockBench', note: 'Two stacks of cinderblocks with 2x4 planks laid across for the seat and a two-board backrest screwed to posts that drop into the block holes (the backrest sits in front of its posts). Seats 2.' },
    'YRD-033': { spec: 'parkBench', note: 'A classic park bench: black cast-iron side frames with scroll detail and warm oak slats for the seat and the curved back (the back slats sit in front of the iron posts). Seats 2.' },
    'YRD-006': { spec: 'lawnChairs', note: 'A pair of white resin lawn chairs with slatted backs, arms and four legs each. The backrests sit in front of their back legs. Seats 2.' },
    'YRD-029': { spec: 'umbrella8', live: 'Canopy breathing', note: 'A crank-open patio umbrella with a weighted base, a crank handle on the pole, eight ribs and a blue-and-white striped canopy with a scalloped valance.' },
    'YRD-069': { spec: 'cabana8', live: 'Louvers moving', note: 'A charcoal aluminium bioclimatic pergola: the roof louvers tilt open and shut on their motor, a warm LED strip runs round the frame, and inside there is a deep lounge sofa with cushions and a teak coffee table. Seats 2.' },
    'YRD-009': { name: 'Tensioned Canvas Shade Sail on Timber Posts', spec: 'sail8', live: 'Sail breathing', note: 'A clean triangular canvas shade sail with curved edges, tensioned from three timber posts by stainless turnbuckles. The sail breathes gently in the breeze.' },
    'YRD-049': { spec: 'wisteria8', live: 'Wisteria swaying', note: 'A cedar pergola with notched rafters, a leafy vine canopy on top and long lilac wisteria racemes hanging down that sway in the breeze. Vines spiral up the front posts. A cushioned bench and stone table sit underneath. Seats 2.' },
    'YRD-012': { name: 'Modern Cedar & Black Steel Garden Shed', spec: 'shed8', note: 'A modern garden shed: vertical cedar cladding, a black steel mono-pitch roof and trim, a black-framed door, glass clerestory windows and a tall planter by the door, on a gravel apron.' },
  };
  const edit7 = RD.edit;
  RD.edit = rows => edit7(rows).map(r => RD.SET8[r.id] ? Object.assign({}, r, RD.SET8[r.id]) : r);
  RD.H8 = { fb, kOf, LEAF, LEAFT, sprinkle, fruitOn, sway, flower5, stageOf, V3, LT, dot };
  RD.PLUS8 = 1;
})();
