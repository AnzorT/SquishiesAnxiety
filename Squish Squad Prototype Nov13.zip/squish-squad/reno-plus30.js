// Renovation Catalog round 30 — Bedroom realism pass (same rules as the Kitchen + Bathroom: floor -> walls -> ceiling -> electronics -> furniture).
// Floors = r.f30: the 80 x 56 perspective trapezoid build of plus20 / plus27 / plus29 (W(u, y) floor space, creature scale).
// BED-005 cold splintery subfloor planks, 025 beige loop-pile carpet, 045 honey oak strip hardwood.
// Sets RenoDraw.PLUS30; catalog edits RD.SET30; helpers RD.H30.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS29 && RD.H12 && RD.H12.SURF12 && RD.H27 && RD.H20 && RD.H13 && RD.H10 && RD.N && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS30) return;
  const shade = X.K.shade, PI = Math.PI, H = RD.H10, N = RD.N;
  const { rng, an, at, SPL, f1, n4, rep, cam, P2 } = H;
  const { fblot, FL } = RD.H13;
  const { W, polyW, lineW, crvW, chip } = RD.H20;
  const { quadW, dot, dotD, walk } = RD.H27;
  const TR = 'M14 0H66L80 56H0Z';
  const wk = v => (52 + 28 * v) / 80, gv = t => t * (0.7 + 0.3 * t), K = y => wk(gv(y));
  const pt = p => f1(p[0]) + ' ' + f1(p[1]);
  const KT = k => ` keyTimes="${k}"`;
  // a soft window-light patch on the floor that drifts slowly (sun moving), 4 panes
  const sun = (u0, y0, u1, y1, op, T, col) => { const pane = (a, b, c, d) => polyW([[a, b], [c, b], [c + 0.03, d], [a + 0.03, d]]), mu = (u0 + u1) / 2, my = (y0 + y1) / 2;
    return `<g filter="url(#fb3)" opacity="${op}"><g>${at('translate', '0 0;2.4 0.6;0 0', T)}${an('opacity', '0.7;1;0.7', T)}<path d="${pane(u0, y0, mu - 0.008, my - 0.012)}${pane(mu + 0.008, y0, u1, my - 0.012)}${pane(u0 + 0.02, my + 0.012, mu - 0.004, y1)}${pane(mu + 0.012, my + 0.012, u1 + 0.02, y1)}" fill="${col || '#fff4d8'}"/></g></g>`; };

  // ======================= FLOORS =======================
  // BED-005 COLD SPLINTERY SUBFLOOR PLANKS (T1): bare rough-sawn pine subfloor boards gone grey, laid front to back with uneven dark gaps you could lose a coin
  // in, circular-saw swirl marks, lifting splinters, rows of rusty nail heads over the joists, a knothole right through, one fresher yellow patch board,
  // old white paint drips and a roller swipe, a water ring, a tack strip left along the back wall with its little tacks, carpet-pad crumbs and dust bunnies.
  // Live: a cold draught breathes up through the gaps as faint blue wisps and a dust bunny stirs.
  function fSub() { const R = rng('sub30'), NP = 8, PC = ['#a89a84', '#9c8e78', '#b0a28a', '#948670', '#a4967e', '#8e8068'];
    let s = '<rect width="80" height="56" fill="#141010"/>', gr = '', sw = '', sp = '', nl = '', ends = '', ov = '';
    const gaps = rep(NP + 1, () => 0.003 + R() * 0.004);
    for (let i = 0; i < NP; i++) { const u0 = i / NP + gaps[i] / 2, u1 = (i + 1) / NP - gaps[i + 1] / 2, cw = u1 - u0; let y = -R() * 0.5;
      while (y < 1.03) { const L = 0.55 + R() * 0.8, ya = Math.max(y, -0.02), yb = Math.min(y + L - 0.004, 1.04), Q = rng('subp' + i + '_' + f1(y)), patch = i === 5 && y > 0.2 && y < 0.9;
        const col = patch ? '#c8b07e' : shade(PC[(Q() * PC.length) | 0], 0.92 + Q() * 0.12);
        s += `<path d="${polyW([[u0 + (Q() - 0.5) * 0.002, ya], [u1 + (Q() - 0.5) * 0.002, ya], [u1 + (Q() - 0.5) * 0.003, yb], [u0 + (Q() - 0.5) * 0.003, yb]])}" fill="${col}"/>`;
        rep(9, () => { const f = 0.06 + Q() * 0.88, a = 0.015 + Q() * 0.04, ph = Q() * 6, w = 1 + Q() * 2; gr += crvW(rep(8, j => { const t = j / 7; return [u0 + cw * Math.min(0.96, Math.max(0.04, f + a * Math.sin(t * w * 3 + ph))), ya + t * (yb - ya)]; })); });
        rep(2, () => { const cu = u0 + cw * (0.3 + Q() * 0.4), cy = ya + (yb - ya) * (0.2 + Q() * 0.6); rep(3, n => { const rr = 0.04 + n * 0.025; sw += crvW(rep(6, j => { const a = -0.9 + j * 0.36; return [cu + Math.sin(a) * rr * 0.55, cy - Math.cos(a) * rr + rr]; })); }); });
        rep(2, () => { const su = u0 + cw * (0.1 + Q() * 0.8), sy = ya + (yb - ya) * Q(), l = 0.03 + Q() * 0.05; sp += `<path d="${polyW([[su, sy], [su + 0.004, sy + l * 0.4], [su + 0.0015, sy + l], [su - 0.001, sy + l * 0.3]])}" fill="#d8ccb4"/><path d="${lineW([[su + 0.004, sy + l * 0.4], [su + 0.0015, sy + l]])}" stroke="#2a2018" stroke-width="0.18" fill="none" opacity="0.6"/>`; });
        if (y > 0) ends += lineW([[u0, y], [u1, y]]);
        y += L; }
      [0.12, 0.38, 0.64, 0.9].forEach((jy, j) => [0.28, 0.72].forEach(f => { const u = u0 + cw * f + (R() - 0.5) * 0.004, yy = jy + (R() - 0.5) * 0.01; nl += dot(u, yy, 0.42, 'fill="#5a2e14" opacity="0.45"') + dot(u, yy, 0.24, `fill="${R() < 0.3 ? '#8a8478' : '#3a2214'}"`) + dot(u - 0.001, yy - 0.003, 0.08, 'fill="#c8b8a0" opacity="0.6"'); })); }
    s += `<path d="${gr}" stroke="#5e5242" stroke-width="0.16" fill="none" opacity="0.4"/><path d="${sw}" stroke="#d8ccb8" stroke-width="0.12" fill="none" opacity="0.3"/>` + sp + nl;
    s += `<path d="${ends}" stroke="#141010" stroke-width="0.5"/>`;
    // gaps: lighter lip on one side
    s += `<path d="${rep(NP - 1, i => lineW([[(i + 1) / NP + 0.004, -0.02], [(i + 1) / NP + 0.004, 1.04]])).join('')}" stroke="#d8ccb4" stroke-width="0.12" opacity="0.35"/>`;
    // knothole through (dark, with the joist glimpse), patch board nails bright
    s += dot(0.31, 0.56, 1.5, 'fill="#5a4a38"') + dot(0.31, 0.56, 1.05, 'fill="#0e0a08"') + dot(0.312, 0.57, 0.5, 'fill="#3a2a1c" opacity="0.6"');
    // paint drips + roller swipe, water ring, old stains
    s += rep(9, () => dot(0.45 + R() * 0.3, 0.1 + R() * 0.35, 0.25 + R() * 0.5, 'fill="#f2efe6" opacity="0.85"')).join('') + `<path d="${crvW([[0.52, 0.18], [0.6, 0.2], [0.68, 0.19]])}" stroke="#f2efe6" stroke-width="1.6" fill="none" opacity="0.5" stroke-linecap="round"/>`;
    s += dot(0.2, 0.3, 2.6, 'fill="none" stroke="#5a4a38" stroke-width="0.4" opacity="0.5"') + fblot('sub30', 18, ['#6a5a48', '#c8bca8', '#4a3e30'], 0.22, 7);
    // tack strip along the back wall + its tacks, pad crumbs, dust bunnies
    s += `<path d="${quadW(0.02, 0.005, 0.98, 0.022)}" fill="#8a6a44"/>` + rep(28, i => dot(0.03 + i * 0.034, 0.013, 0.16, 'fill="#c8c4bc"')).join('');
    s += rep(30, () => dot(0.05 + R() * 0.9, 0.02 + R() * 0.12, 0.1 + R() * 0.25, `fill="${R() < 0.5 ? '#c8a050' : '#7a9a5a'}" opacity="0.8"`)).join('');
    const bun = (u, y, r) => '<g opacity="0.85">' + rep(14, () => { const p = W(u + (R() - 0.5) * 0.02 * r, y + (R() - 0.5) * 0.02 * r), k = K(y), a = R() * 6.3, l = (0.8 + R() * 1.2) * r * k; return `<path d="M${pt(p)}q${f1(Math.cos(a) * l)} ${f1(Math.sin(a) * l * 0.4 - l * 0.4)} ${f1(Math.cos(a) * l * 1.6)} ${f1(Math.sin(a) * l * 0.6)}" stroke="${R() < 0.5 ? '#b8b0a4' : '#8a8478'}" stroke-width="0.18" fill="none"/>`; }).join('') + '</g>';
    s += bun(0.06, 0.12, 1.2) + `<g>${at('translate', '0 0;1.2 -0.2;0.4 0.1;0 0', 7)}${bun(0.9, 0.3, 1)}</g>` + bun(0.12, 0.9, 1.4);
    // cold draught: faint blue wisps up through two gaps
    s += [[2 / NP, 0.4], [4 / NP, 0.75], [6 / NP, 0.22]].map(([u, y], i) => { const p = W(u, y), k = K(y), T = 6 + i * 1.3; return `<g transform="translate(${pt(p)}) scale(${n4(k)})"><path d="M0 0q-1 -2 0 -4t0 -4" stroke="#cfe4f2" stroke-width="1.4" fill="none" opacity="0" filter="url(#fb1)">${an('opacity', '0;0.4;0', T, -i * 2)}<animateTransform attributeName="transform" type="translate" values="0 0;0.6 -4" dur="${T}s" begin="${-i * 2}s" repeatCount="indefinite"/></path></g>`; }).join('');
    s += `<path d="${TR}" fill="none" stroke="#1a1612" stroke-width="8" opacity="0.3" filter="url(#fb3)"/>`;
    return FL(s, 1); }

  // BED-025 BEIGE LOOP-PILE BERBER CARPET (T2): a wall-to-wall oatmeal berber in tight looped rows, heathered with darker and lighter flecks, vacuum stripes
  // running across it, a matted traffic lane from the door to the bed, a faded coffee stain, a couple of snagged loops, a flattened square where a dresser
  // stood, and a dark line of dust along the skirting. Live: a warm window patch of morning light drifts slowly across and dust motes glint in it.
  function fBerber() { const R = rng('berb30'), base = '#d4c4a2';
    let s = `<rect width="80" height="56" fill="${base}"/>`;
    // heathered tone blobs, then the loop rows (one stroke per row, alternating light/dark) and fleck dots
    s += fblot('berb30h', 30, ['#c8b692', '#e0d2b4', '#bcaa86'], 0.35, 10);
    let rl = '', rd = '';
    for (let y = 0.004, j = 0; y < 1.03; y += 0.0105 + 0.004 * y, j++) { const L = lineW([[-0.02, y], [1.02, y]]); if (j % 2) rd += L; else rl += L; }
    s += `<path d="${rd}" stroke="#a08c68" stroke-width="0.32" stroke-dasharray="0.45 0.3" fill="none" opacity="0.7"/><path d="${rl}" stroke="#f2e8d2" stroke-width="0.26" stroke-dasharray="0.35 0.4" fill="none" opacity="0.75"/>`;
    s += `<rect width="80" height="56" fill="url(#c30l)" opacity="0.14"/>`;
    s += rep(260, () => { const u = R() * 1.02 - 0.01, y = R() * 1.02; return dot(u, y, 0.1 + R() * 0.12, `fill="${R() < 0.55 ? '#8a7656' : '#f6efe0'}" opacity="${f1(0.4 + R() * 0.4)}"`); }).join('');
    // vacuum stripes: broad bands across, alternately lighter / darker
    s += rep(7, i => `<path d="${polyW([[-0.02 + i * 0.15, -0.02], [0.06 + i * 0.15, -0.02], [0.08 + i * 0.15, 1.04], [0 + i * 0.15, 1.04]])}" fill="${i % 2 ? '#fff6e4' : '#8a7656'}" opacity="0.11"/>`).join('');
    // traffic lane (matted, darker) from the front left to the back right, flattened dresser footprint, coffee stain, snags, skirting dust
    const lane = crvW([[0.18, 1.06], [0.3, 0.75], [0.5, 0.5], [0.72, 0.25]]);
    s += `<g filter="url(#fb3)"><path d="${lane}" stroke="#8a7656" stroke-width="12" fill="none" opacity="0.16"/><path d="${lane}" stroke="#6a5a40" stroke-width="5" fill="none" opacity="0.08"/></g>`;
    s += `<path d="${quadW(0.62, 0.05, 0.86, 0.17)}" fill="#a89470" opacity="0.22"/>` + [[0.63, 0.06], [0.85, 0.06], [0.63, 0.16], [0.85, 0.16]].map(([u, y]) => `<path d="${dotD(u, y, 0.9)}" fill="#8a7656" opacity="0.4"/>`).join('');
    s += `<g filter="url(#fb1)">${dot(0.36, 0.7, 3.2, 'fill="#9a7a50" opacity="0.28"')}${dot(0.38, 0.69, 2, 'fill="#8a6a40" opacity="0.18"')}</g>` + `<path d="${dotD(0.36, 0.7, 3.1)}" fill="none" stroke="#8a6a40" stroke-width="0.25" opacity="0.3"/>`;
    s += [[0.58, 0.82], [0.81, 0.44]].map(([u, y]) => { const p = W(u, y), k = K(y); return `<path d="M${pt(p)}q${f1(0.6 * k)} ${f1(-1.6 * k)} ${f1(1.4 * k)} ${f1(-0.3 * k)}" stroke="#e8dcc0" stroke-width="${f1(0.35 * k)}" fill="none"/><path d="M${pt(p)}q${f1(0.6 * k)} ${f1(-1.6 * k)} ${f1(1.4 * k)} ${f1(-0.3 * k)}" stroke="#8a7656" stroke-width="${f1(0.1 * k)}" fill="none" transform="translate(0.15 0.15)"/>`; }).join('');
    s += `<path d="${lineW([[0, 0.006], [1, 0.006]])}" stroke="#5a4a36" stroke-width="0.9" opacity="0.35" filter="url(#fb1)"/>`;
    s += `<path d="${TR}" fill="none" stroke="#6a5a40" stroke-width="7" opacity="0.22" filter="url(#fb3)"/>`;
    // morning light + motes
    s += sun(0.5, 0.3, 0.78, 0.62, 0.55, 26);
    s += rep(8, i => { const p = W(0.52 + R() * 0.25, 0.3 + R() * 0.3), T = 6 + R() * 4; return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="0.18" fill="#fff8e0" opacity="0">${an('opacity', '0;0.9;0', T, -i)}${an('cy', `${f1(p[1])};${f1(p[1] - 3)}`, T, -i)}</circle>`; }).join('');
    return FL(`<defs><pattern id="c30l" width="0.9" height="0.7" patternUnits="userSpaceOnUse"><ellipse cx="0.45" cy="0.35" rx="0.32" ry="0.22" fill="none" stroke="#9a8664" stroke-width="0.12"/></pattern></defs>` + s); }

  // BED-045 HONEY OAK STRIP HARDWOOD (T3): narrow 2 1/4in red-oak strips in warm honey with random butt joints, open cathedral grain and ray flecks, a few
  // darker mineral streaks, tight joints with a hairline shadow, a satin poly finish catching the window, a couple of fine scratches by the bed and a
  // chair-leg dent. Live: the reflection of the window slides slowly across the boards.
  function fOak30() { const R = rng('oak30'), NP = 16, PC = ['#c8904e', '#c08648', '#d09a58', '#b87e42', '#cc9452', '#d4a060', '#bc8446'];
    let s = '<rect width="80" height="56" fill="#5a3a1e"/>', gr = '', cat = '', ray = '', mn = '', ends = '';
    for (let i = 0; i < NP; i++) { const u0 = i / NP, u1 = (i + 1) / NP, cw = u1 - u0; let y = -R() * 0.7;
      while (y < 1.03) { const L = 0.3 + R() * 0.65, ya = Math.max(y, -0.02), yb = Math.min(y + L, 1.04), Q = rng('oak30p' + i + '_' + f1(y));
        s += `<path d="${quadW(u0 + 0.0012, ya, u1 - 0.0012, yb)}" fill="${shade(PC[(Q() * PC.length) | 0], 0.95 + Q() * 0.1)}"/>`;
        rep(4, () => { const f = 0.1 + Q() * 0.8, a = 0.03 + Q() * 0.05, ph = Q() * 6; gr += crvW(rep(7, j => { const t = j / 6; return [u0 + cw * Math.min(0.94, Math.max(0.06, f + a * Math.sin(t * 5 + ph))), ya + t * (yb - ya)]; })); });
        if (Q() < 0.55) { const uc = u0 + cw * (0.35 + Q() * 0.3), yc = ya + (yb - ya) * (0.15 + Q() * 0.55); for (let n = 1; n <= 4; n++) { const w = cw * 0.1 * n, h = 0.03 * n; cat += crvW([[uc - w, yc + h], [uc - w * 0.5, yc + h * 0.25], [uc, yc], [uc + w * 0.5, yc + h * 0.25], [uc + w, yc + h]]); } }
        rep(4, () => { const u = u0 + cw * (0.15 + Q() * 0.7), yy = ya + (yb - ya) * Q(); ray += lineW([[u, yy], [u + 0.002, yy + 0.008]]); });
        if (Q() < 0.18) { const u = u0 + cw * (0.3 + Q() * 0.4), yy = ya + (yb - ya) * Q() * 0.6; mn += `<path d="${crvW([[u, yy], [u + 0.002, yy + 0.06], [u - 0.001, yy + 0.12]])}" stroke="#4a2e18" stroke-width="0.5" fill="none" opacity="0.35" stroke-linecap="round"/>`; }
        if (y > 0) ends += lineW([[u0, y], [u1, y]]);
        y += L; } }
    s += `<path d="${gr}" stroke="#7a4e24" stroke-width="0.14" fill="none" opacity="0.4"/><path d="${cat}" stroke="#6a421e" stroke-width="0.18" fill="none" opacity="0.38"/><path d="${ray}" stroke="#f0c890" stroke-width="0.14" fill="none" opacity="0.4"/>` + mn;
    s += `<path d="${ends}" stroke="#4a2e16" stroke-width="0.22" opacity="0.85"/>` + `<path d="${rep(NP - 1, i => lineW([[(i + 1) / NP, -0.02], [(i + 1) / NP, 1.04]])).join('')}" stroke="#f2d0a0" stroke-width="0.1" opacity="0.3" transform="translate(0.2 0)"/>`;
    s += fblot('oak30', 14, ['#e8c088', '#8a5a2e'], 0.16, 8);
    // scratches + dent
    s += rep(5, () => { const u = 0.45 + R() * 0.2, y = 0.55 + R() * 0.2, P = [[u, y], [u + 0.04 + R() * 0.04, y + (R() - 0.5) * 0.04]]; return `<path d="${lineW(P)}" stroke="#f6dcb0" stroke-width="0.12" opacity="0.55"/>`; }).join('') + `<path d="${dotD(0.28, 0.36, 0.5)}" fill="#7a4e24" opacity="0.35"/>`;
    // satin sheen: soft window reflection sliding across + a wide low gloss
    s += `<g filter="url(#fb3)"><g>${at('translate', '0 0;6 0.6;0 0', 30)}<path d="${polyW([[0.16, 0.0], [0.3, 0.0], [0.34, 0.42], [0.14, 0.42]])}" fill="#fff6e4" opacity="0.2"/><path d="${polyW([[0.33, 0.0], [0.4, 0.0], [0.44, 0.42], [0.36, 0.42]])}" fill="#fff6e4" opacity="0.14"/></g>${dot(0.6, 0.25, 9, 'fill="#fff0d8" opacity="0.1"')}</g>`;
    s += `<path d="${TR}" fill="none" stroke="#3a2412" stroke-width="7" opacity="0.25" filter="url(#fb3)"/>`;
    return FL(s); }

  // BED-065 HEATED HERRINGBONE ASH WITH A SUNKEN PLUSH PERIMETER (T4): a raised island of pale oiled ash herringbone (blond-grey blocks, fine straight grain,
  // soft matte sheen) edged with a bronze nosing, stepping down to a wide sunken border of deep ivory-greige plush carpet that runs round the walls.
  // Live: warmth shimmers up off the heated ash and a soft glint travels along the bronze nosing.
  function fHerr() { const R = rng('herr30'), U0 = 0.13, U1 = 0.87, Y0 = 0.12, Y1 = 0.86, AY = 1.25, w = 0.026, L = 0.104, S2 = Math.SQRT2;
    const AC = ['#d8ccb6', '#cfc2aa', '#e0d4c0', '#d4c8b0', '#c8bba2', '#dccfb8'];
    let s = `<rect width="80" height="56" fill="#cfc4b4"/>`;
    // plush perimeter
    s += fblot('herr30p', 34, ['#e2d9cc', '#bfb4a4', '#d6ccbe'], 0.4, 9) + rep(420, () => dot(R() * 1.04 - 0.02, R() * 1.04 - 0.02, 0.12 + R() * 0.14, `fill="${R() < 0.5 ? '#a89c8a' : '#f2ebe0'}" opacity="${f1(0.35 + R() * 0.35)}"`)).join('');
    s += rep(6, i => `<path d="${polyW([[-0.02 + i * 0.18, -0.02], [0.07 + i * 0.18, -0.02], [0.1 + i * 0.18, 1.04], [0.01 + i * 0.18, 1.04]])}" fill="${i % 2 ? '#ffffff' : '#8a7e6c'}" opacity="0.06"/>`).join('');
    // herringbone island (clipped): staircases of A (along +x) and B (along +y) blocks in a 45-degree frame, tiled by (L, -L)
    const tf = (x, y) => { const a = (x - y) / S2, b = (x + y) / S2; return [0.5 + a, Y0 + b / AY]; };
    let hb = '', gr = '';
    for (let m = -16; m <= 16; m++) for (let k = -34; k <= 34; k++) { const ox = k * w + m * L, oy = k * w - m * L;
      [[ox, oy, L, w, 0], [ox, oy + w, w, L, 1]].forEach(([x, y, dx, dy, t]) => { const P = [[x, y], [x + dx, y], [x + dx, y + dy], [x, y + dy]].map(([a, b]) => tf(a, b)); const c = P.reduce((q, p) => [q[0] + p[0] / 4, q[1] + p[1] / 4], [0, 0]);
        if (c[0] < U0 - 0.08 || c[0] > U1 + 0.08 || c[1] < Y0 - 0.1 || c[1] > Y1 + 0.1) return; const Q = rng('hb' + m + '_' + k + t);
        hb += `<path d="${polyW(P)}" fill="${shade(AC[(Q() * AC.length) | 0], 0.96 + Q() * 0.08)}" stroke="#a89a80" stroke-width="0.12"/>`;
        rep(3, j => { const f = 0.2 + j * 0.3 + (Q() - 0.5) * 0.1, A = t ? [x + dx * f, y + dy * 0.04] : [x + dx * 0.04, y + dy * f], B = t ? [x + dx * f + (Q() - 0.5) * 0.004, y + dy * 0.96] : [x + dx * 0.96, y + dy * f + (Q() - 0.5) * 0.004]; gr += lineW([tf(...A), tf(...B)]); }); }); }
    const isl = polyW([[U0, Y0], [U1, Y0], [U1, Y1], [U0, Y1]]);
    s += `<defs><clipPath id="h30c"><path d="${isl}"/></clipPath><linearGradient id="h30n" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8a6436"/><stop offset="0.5" stop-color="#d8b07a"/><stop offset="1" stop-color="#8a6436"/></linearGradient></defs>`;
    // step shadow on the plush round the island, then the island, its front step face and the bronze nosing
    s += `<path d="${isl}" fill="none" stroke="#3a3028" stroke-width="2.6" opacity="0.35" filter="url(#fb1)" transform="translate(0.4 0.9)"/>`;
    s += `<g clip-path="url(#h30c)">${hb}<path d="${gr}" stroke="#b0a28a" stroke-width="0.08" fill="none" opacity="0.6"/>${fblot('herr30i', 14, ['#f2eadc', '#a8987c'], 0.18, 7)}<g filter="url(#fb3)"><g>${at('translate', '0 0;4 0.6;0 0', 28)}<path d="${polyW([[0.3, Y0], [0.42, Y0], [0.46, 0.6], [0.3, 0.6]])}" fill="#ffffff" opacity="0.16"/></g></g></g>`;
    { const a = W(U0, Y1), b = W(U1, Y1); s += `<path d="M${pt(a)}L${pt(b)}L${f1(b[0])} ${f1(b[1] + 0.9)}L${f1(a[0])} ${f1(a[1] + 0.9)}Z" fill="#a8987c"/>`; }
    s += `<path d="${isl}" fill="none" stroke="#9a7444" stroke-width="0.55"/><path d="${isl}" fill="none" stroke="#e8c890" stroke-width="0.18" opacity="0.8"/>`;
    { const a = W(U0, Y1), b = W(U1, Y1); s += `<ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="3" ry="0.35" fill="#fff4d8" opacity="0">${an('cx', `${f1(a[0])};${f1(b[0])}`, 9)}${an('opacity', '0;0.9;0.9;0', 9)}</ellipse>`; }
    // heat shimmer over the ash
    s += rep(6, i => { const p = W(U0 + 0.1 + i * 0.12, 0.3 + (i % 3) * 0.18), k = K(0.3 + (i % 3) * 0.18), T = 5 + i * 0.7; return `<g transform="translate(${pt(p)}) scale(${n4(k)})"><path d="M0 0q1 -1.5 0 -3t0 -3" stroke="#fff2dc" stroke-width="1.2" fill="none" opacity="0" filter="url(#fb1)">${an('opacity', '0;0.35;0', T, -i)}<animateTransform attributeName="transform" type="translate" values="0 0;0.4 -3" dur="${T}s" begin="${-i}s" repeatCount="indefinite"/></path></g>`; }).join('');
    s += `<path d="${TR}" fill="none" stroke="#6a5e4c" stroke-width="7" opacity="0.2" filter="url(#fb3)"/>`;
    return FL(s); }

  // BED-085 CLOUD-CUSHION MEMORY-STONE HEATED FLOOR WITH NIGHTTIME FOOTSTEP GLOW (T5): big pillowed slabs of warm pearl-grey memory stone, each softly
  // domed with a velvety bevel, set in fine seams that hold a thread of warm night light; the room is in its night mood. Live: soft footprints press
  // into the stone one after another from the door toward the bed, each glowing warm amber and fading like a memory, and the seams breathe.
  function fMem() { const R = rng('mem30'), NU = 4, NV = 3, gu = 0.005, gy = 0.009, ru = 0.014, ry = 0.024;
    let s = `<rect width="80" height="56" fill="#5a5048"/><defs><radialGradient id="m30p" cx="45%" cy="40%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.22"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.2"/></radialGradient><radialGradient id="m30g"><stop offset="0" stop-color="#ffcf8a" stop-opacity="0.9"/><stop offset="1" stop-color="#ffb060" stop-opacity="0"/></radialGradient></defs>`;
    const rr = (u0, y0, u1, y1) => { const P = []; [[u1 - ru, y0 + ry, -PI / 2], [u1 - ru, y1 - ry, 0], [u0 + ru, y1 - ry, PI / 2], [u0 + ru, y0 + ry, PI]].forEach(([cu, cy, a0]) => { for (let i = 0; i <= 4; i++) { const a = a0 + i / 8 * PI; P.push([cu + ru * Math.cos(a), cy + ry * Math.sin(a)]); } }); return polyW(P); };
    s += `<path d="${TR}" fill="#ffb868" opacity="0.5"><animate attributeName="opacity" values="0.35;0.6;0.35" dur="7s" repeatCount="indefinite"/></path>`;
    for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const u0 = i / NU + gu, u1 = (i + 1) / NU - gu, y0 = j / NV + gy, y1 = (j + 1) / NV - gy, d = rr(u0, y0, u1, y1), Q = rng('mem' + i + j);
      s += `<path d="${d}" fill="${shade(['#ddd2c4', '#e2d8ca', '#d8cdbe', '#e4dacc'][(i + j * 2) % 4], 0.97 + Q() * 0.06)}"/>` + rep(30, () => dot(u0 + (u1 - u0) * Q(), y0 + (y1 - y0) * Q(), 0.1 + Q() * 0.2, `fill="${Q() < 0.5 ? '#a8a094' : '#ece6dc'}" opacity="0.5"`)).join('') + `<path d="${d}" fill="url(#m30p)"/>`; }
    s += fblot('mem30', 12, ['#e8e0d4', '#8a8074'], 0.16, 9);
    // night mood: cool-dim the slabs, warm toward the bed (back right)
    s += `<path d="${TR}" fill="#3a3048" opacity="0.14"/><g filter="url(#fb3)">${dot(0.78, 0.18, 26, 'fill="#ffb868" opacity="0.18"')}</g>`;
    // footsteps from the front left toward the bed: each presses in (dimple), glows, fades; a 9-step cycle
    const steps = rep(9, i => { const t = i / 8, u = 0.2 + t * 0.52 + (i % 2 ? 0.035 : -0.035), y = 0.95 - t * 0.78; return [u, y]; }), T = 10;
    s += steps.map(([u, y], i) => { const p = W(u, y), k = K(y), b = -(T - i * 0.8), sx = (i % 2 ? 1 : -1);
      const fp = `<g transform="translate(${pt(p)}) scale(${n4(k * 0.6)} ${n4(k * 0.6 * (0.55 + 0.2 * gv(y)))}) rotate(${f1(28)}) scale(${sx} 1)">${RD.H29.foot(0, 0, 1, '#ffd08a', 1)}</g>`;
      const dim = `<g transform="translate(${pt(p)}) scale(${n4(k * 0.6)} ${n4(k * 0.6 * (0.55 + 0.2 * gv(y)))}) rotate(28) scale(${sx} 1)">${RD.H29.foot(0.3, 0.4, 1.05, '#3a3028', 1)}</g>`;
      const kt = ' keyTimes="0;0.04;0.1;0.5;0.62;1"';
      return `<g opacity="0">${an('opacity', '0;0.5;0.5;0.2;0;0', T, b, kt)}${dim}</g><g opacity="0">${an('opacity', '0;1;0.85;0.35;0;0', T, b, kt)}<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(4 * k)}" ry="${f1(2.4 * k)}" fill="url(#m30g)"/>${fp}</g>`; }).join('');
    // seams: thread of warm light that breathes
    let sm = ''; for (let i = 1; i < NU; i++) sm += lineW([[i / NU, 0], [i / NU, 1.02]]); for (let j = 1; j < NV; j++) sm += lineW([[0, j / NV], [1, j / NV]]);
    s += `<path d="${sm}" stroke="#ffc878" stroke-width="0.35" fill="none" opacity="0.5" filter="url(#fb1)"><animate attributeName="opacity" values="0.3;0.7;0.3" dur="7s" repeatCount="indefinite"/></path><path d="${sm}" stroke="#ffe2b0" stroke-width="0.12" fill="none" opacity="0.7"/>`;
    s += `<path d="${TR}" fill="none" stroke="#1a1620" stroke-width="8" opacity="0.3" filter="url(#fb3)"/>`;
    return FL(s, 1); }

  // ======================= RUGS (flat 3D floor pieces: RD.H13 slab / top / face, footprints kept) =======================
  // BED-017 SMALL ACRYLIC BATHMAT BESIDE THE BED (T1): 120 x 72 kept. A cheap peach acrylic bath mat pressed into service as a bedside rug, lying a bit
  // crooked: pilled synthetic fuzz with a faint embossed seashell, a flattened grey patch where feet land every morning, bleach spots, crumbs and a hair,
  // a dropped grey sock, and the back corner curling up to show the cracked rubber backing. Live: the curled corner lifts and settles in the draught.
  N.rug30a = S => { const { slab, top, face, rrP } = RD.H13, { DEF29, RUG } = RD.H29, W0 = 100, Dd = 58, T = 1.2, A = 0.1, ca = Math.cos(A), sa = Math.sin(A), rot = ([x, z]) => [x * ca - z * sa, x * sa + z * ca];
    const P = rrP(W0, Dd, 4).map(rot), D = RUG(120, 72);
    D.fx = ctx => { const C = cam(ctx), R = rng('rug30a'), id = C.u('ra'), k = C.k;
      let a = `<rect x="${-W0 / 2 - 2}" y="${-Dd / 2 - 2}" width="${W0 + 4}" height="${Dd + 4}" fill="#e6a088"/>`;
      let lt = '', dk = ''; rep(1400, () => { const x = (R() - 0.5) * W0, z = (R() - 0.5) * Dd, l = 0.5 + R() * 0.7, an2 = R() * 6.3, d = `M${f1(x)} ${f1(z)}l${f1(Math.cos(an2) * l)} ${f1(Math.sin(an2) * l)}`; if (R() < 0.5) lt += d; else dk += d; });
      a += `<path d="${dk}" stroke="#c87e66" stroke-width="0.45" stroke-linecap="round" opacity="0.7"/><path d="${lt}" stroke="#f6c2ac" stroke-width="0.4" stroke-linecap="round" opacity="0.75"/>`;
      a += `<g opacity="0.3" fill="none" stroke="#b86a52" stroke-width="0.9"><path d="M-10 10Q0 -12 10 10Z"/>${rep(5, i => `<path d="M0 10L${-8 + i * 4} -6"/>`).join('')}</g>`;
      a += `<g filter="url(#m29b)"><ellipse cx="-6" cy="4" rx="22" ry="12" fill="#a08070" opacity="0.4"/></g>` + rep(4, () => `<g filter="url(#m29s)"><ellipse cx="${f1((R() - 0.5) * 70)}" cy="${f1((R() - 0.5) * 40)}" rx="${f1(2 + R() * 3)}" ry="${f1(1.4 + R() * 2)}" fill="#f8e8dc" opacity="0.75"/></g>`).join('');
      a += rep(40, () => `<circle cx="${f1((R() - 0.5) * W0 * 0.9)}" cy="${f1((R() - 0.5) * Dd * 0.9)}" r="${f1(0.4 + R() * 0.4)}" fill="${R() < 0.5 ? '#f2b8a0' : '#d08870'}"/>`).join('');
      a += rep(8, () => `<circle cx="${f1((R() - 0.5) * W0 * 0.8)}" cy="${f1((R() - 0.5) * Dd * 0.8)}" r="0.35" fill="#c8a060"/>`).join('') + `<path d="M12 -8q6 -3 10 1t9 -2" stroke="#2a1e14" stroke-width="0.15" fill="none"/>`;
      a += `<g transform="translate(22 10) rotate(-24)"><path d="M-9 -2.4H4Q8 -2.4 9.4 0.6Q10 3.6 6.6 3.6H1Q-1 3.6 -1 1.6H-9Z" fill="#8a8c90" stroke="#5a5c60" stroke-width="0.3"/><path d="M-9 -2.4V1.6" stroke="#6a6c70" stroke-width="1.6"/><path d="M-5 -2.4V1.6M-3 -2.4V1.6" stroke="#9a9ca0" stroke-width="0.3"/><ellipse cx="7" cy="1" rx="2.2" ry="1.8" fill="#9a9ca0" opacity="0.6"/></g>`;
      const art = `<g transform="rotate(${f1(A * 180 / PI)})">${a}</g>`;
      // curled back-right corner: underside rubber flap lifting
      const cn = rot([W0 / 2, -Dd / 2]), e1 = rot([W0 / 2 - 15, -Dd / 2]), e2 = rot([W0 / 2, -Dd / 2 + 11]);
      const flap = lift => { const tip = rot([W0 / 2 - 4, -Dd / 2 + 3.6]); return 'M' + [[e1[0], T, e1[1]], [tip[0], T + lift, tip[1]], [e2[0], T, e2[1]]].map(p => P2(C.P(p))).join('L') + 'Z'; };
      const hole = 'M' + [[e1[0], T + 0.02, e1[1]], [cn[0], T + 0.02, cn[1]], [e2[0], T + 0.02, e2[1]]].map(p => P2(C.P(p))).join('L') + 'Z';
      const cur = `<path d="${hole}" fill="#000" opacity="0.18"/><path d="${flap(5)}" fill="#a49e96" stroke="#6a645c" stroke-width="0.3">${an('d', `${flap(5)};${flap(7)};${flap(5)}`, 6)}</path>`
        + (() => { const q = C.P([(e1[0] + e2[0]) / 2, T + 2.4, (e1[1] + e2[1]) / 2]); return rep(5, i => `<circle cx="${f1(q[0] + (i - 2) * 0.9 * k)}" cy="${f1(q[1] + (i % 2) * 0.5 * k)}" r="${f1(0.3 * k)}" fill="#7a746c"/>`).join('') + `<path d="M${f1(q[0] - 2 * k)} ${f1(q[1] + 1 * k)}l${f1(1.4 * k)} ${f1(-0.6 * k)}l${f1(0.6 * k)} ${f1(0.8 * k)}" stroke="#5a544c" stroke-width="${f1(0.15 * k)}" fill="none"/>`; })();
      const s = slab(C, P, T, '#c88a74') + top(C, T, face(id, P, art, 0.22)) + cur;
      return { defs: DEF29, front: s, bb: C.bb(6) }; };
    return D; };

  // shag / pile strokes over an area: n strokes of length l in random directions, lighter tips
  const pile = (R, x0, z0, w, d, n, l, cB, cT, inside) => { let a = '', b = ''; rep(n, () => { const x = x0 + R() * w, z = z0 + R() * d; if (inside && !inside(x, z)) return; const t = R() * 6.3, L = l * (0.6 + R() * 0.7), dx = Math.cos(t) * L, dz = Math.sin(t) * L * 0.8 - L * 0.35;
      a += `M${f1(x)} ${f1(z)}l${f1(dx)} ${f1(dz)}`; b += `M${f1(x + dx * 0.6)} ${f1(z + dz * 0.6)}l${f1(dx * 0.4)} ${f1(dz * 0.4)}`; }); return `<path d="${a}" stroke="${cB}" stroke-width="0.7" stroke-linecap="round" fill="none"/><path d="${b}" stroke="${cT}" stroke-width="0.5" stroke-linecap="round" fill="none"/>`; };
  const fringe = (R, x0, z0, z1, sd, len, col, dk) => { let f = ''; for (let z = z0; z < z1; z += 1.3) f += `M${f1(x0)} ${f1(z)}q${f1(sd * len * 0.5)} ${f1((R() - 0.5) * 1.4)} ${f1(sd * (len + R() * 1.6))} ${f1((R() - 0.5) * 1.6)}`; return `<path d="${f}" stroke="${col}" stroke-width="0.6" fill="none" stroke-linecap="round"/><path d="${f}" stroke="${dk}" stroke-width="0.18" fill="none" opacity="0.5"/>`; };

  // BED-037 SOFT CREAM MOROCCAN BERBER SHAG (T2): 180 x 130 kept. A Beni Ourain-style cream wool shag: long soft pile with lighter tips, an irregular hand-
  // knotted charcoal diamond lattice (each line a run of dark knots, not a drawn line), a few wobbles where the weaver changed her mind, tasselled fringe
  // on both short ends, slightly flattened where it is walked on. Live: a soft sheen rolls through the pile.
  N.rug30b = S => { const { slab, top, face, rrP } = RD.H13, { DEF29, RUG } = RD.H29, W0 = 160, Dd = 116, T = 2.4, P = rrP(W0, Dd, 3), D = RUG(180, 130);
    D.fx = ctx => { const C = cam(ctx), R = rng('rug30b'), id = C.u('rb'), gid = C.u('rbg');
      let a = `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="#ece4d4"/>` + pile(R, -W0 / 2, -Dd / 2, W0, Dd, 3200, 2.6, '#d8ccb6', '#fbf6ec');
      // lattice: diamonds of dark knots (cols every 26 across, rows every 30 deep), with wobble
      let kn = ''; const knot = (x, z) => { kn += `M${f1(x + (R() - 0.5) * 0.8)} ${f1(z + (R() - 0.5) * 0.8)}l${f1((R() - 0.5) * 1.6)} ${f1(-0.6 - R())}`; };
      [1, -1].forEach(sg => { for (let o = -W0; o <= W0; o += 22) { const ph = (o + sg * 7) * 0.13; for (let z = -Dd / 2 + 4; z <= Dd / 2 - 4; z += 1.25) { const x = o + sg * z * 0.8 + Math.sin(z * 0.08 + ph) * 1.2; if (Math.abs(x) < W0 / 2 - 4) knot(x, z); } } });
      a += `<path d="${kn}" stroke="#3a3632" stroke-width="1.5" stroke-linecap="round"/><path d="${kn}" stroke="#5a5650" stroke-width="0.6" stroke-linecap="round" transform="translate(0.3 -0.4)"/>`;
      a += `<g filter="url(#m29b)"><ellipse cx="18" cy="16" rx="34" ry="18" fill="#b8ac96" opacity="0.28"/></g>`;
      a += `<defs><linearGradient id="${gid}" x1="0" y1="0" x2="1" y2="0.3"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.35"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs><rect x="-150" y="${-Dd / 2}" width="60" height="${Dd}" fill="url(#${gid})">${an('x', '-150;110', 9)}</rect>`;
      const fr = top(C, 0.05, fringe(R, -W0 / 2, -Dd / 2 + 2, Dd / 2 - 2, -1, 5, '#efe6d4', '#a89a80') + fringe(R, W0 / 2, -Dd / 2 + 2, Dd / 2 - 2, 1, 5, '#efe6d4', '#a89a80'));
      const s = fr + slab(C, P, T, '#d8ccb6') + top(C, T, face(id, P, a, 0.18));
      return { defs: DEF29, front: s, bb: C.bb(8) }; };
    return D; };

  // BED-057 FAUX-SHEEPSKIN PELTS ON A WOVEN WOOL RUNNER (T3): 250 x 70 kept. A long flat-woven oatmeal wool runner with rust, ochre and charcoal bands and a
  // stepped geometric border, knotted fringe at both ends, with two faux-sheepskin pelts thrown over it (one ivory, one dove grey), their fluffy curly edges
  // spilling over onto the floor. Live: the pelts' long fur catches a slow drifting sheen.
  N.rug30c = S => { const { slab, top, face, rrP } = RD.H13, { DEF29, RUG } = RD.H29, W0 = 236, Dd = 60, T = 0.8, P = rrP(W0, Dd, 1.5), D = RUG(250, 70);
    const pelt = (cx, cz, s, rot, R) => rep(22, i => { const t = i / 22 * 2 * PI, leg = [0.55, 1.15, 2.35, 3.05, 4.15].some(q => Math.abs(t - q) < 0.18) ? 1.25 : 1; const r = (1 + 0.12 * Math.sin(t * 3 + 1) + (R() - 0.5) * 0.08) * leg; return [cx + Math.cos(t + rot) * 26 * s * r, cz + Math.sin(t + rot) * 16 * s * r]; });
    D.fx = ctx => { const C = cam(ctx), R = rng('rug30c'), id = C.u('rc'), k = C.k;
      let a = `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="#d8c8a8"/>`;
      for (let z = -Dd / 2; z < Dd / 2; z += 0.9) a += `<path d="M${-W0 / 2} ${f1(z)}H${W0 / 2}" stroke="${R() < 0.5 ? '#c8b896' : '#e4d6ba'}" stroke-width="0.5" stroke-dasharray="1.2 0.6" opacity="0.7"/>`;
      [-0.4, -0.18, 0.18, 0.4].forEach((f, i) => { const x = f * W0; a += `<rect x="${f1(x - 4)}" y="${-Dd / 2}" width="8" height="${Dd}" fill="${['#a8482a', '#c8902e', '#c8902e', '#a8482a'][i]}"/><rect x="${f1(x - 1)}" y="${-Dd / 2}" width="2" height="${Dd}" fill="#3a302a"/>`; });
      let st = ''; for (let x = -W0 / 2 + 4; x < W0 / 2 - 4; x += 8) st += `M${x} ${-Dd / 2 + 4}h4v3h4v-3`; a += `<path d="${st}" stroke="#3a302a" stroke-width="1.2" fill="none"/><path d="${st}" stroke="#3a302a" stroke-width="1.2" fill="none" transform="translate(0 ${Dd - 11}) scale(1 -1) translate(0 ${-Dd + 11 + 0})"/>`;
      a += `<rect x="${-W0 / 2 + 2}" y="${-Dd / 2 + 2}" width="${W0 - 4}" height="${Dd - 4}" fill="none" stroke="#3a302a" stroke-width="0.8"/>`;
      const fr = top(C, 0.05, fringe(R, -W0 / 2, -Dd / 2 + 2, Dd / 2 - 2, -1, 4, '#e8dcc0', '#8a7a5a') + fringe(R, W0 / 2, -Dd / 2 + 2, Dd / 2 - 2, 1, 4, '#e8dcc0', '#8a7a5a'));
      // pelts (drawn on top of the runner, spilling past it): shadow, body, curly fur, edge tufts, sheen
      const PE = [[-46, 2, 1.25, 0.15, '#f4efe4', '#ddd4c2'], [42, -4, 1.2, -0.3, '#c8c4bc', '#a8a49c']];
      const pel = PE.map(([x, z, s0, rt, c0, c1], i) => { const Q = rng('pelt' + i), Pp = pelt(x, z, s0, rt, Q), d = 'M' + Pp.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L') + 'Z', pid = C.u('pp');
          let cur = ''; rep(260, () => { const t = Q() * 2 * PI, r = Math.sqrt(Q()) * 0.9; const px = x + Math.cos(t) * 26 * s0 * r, pz = z + Math.sin(t) * 16 * s0 * r; cur += `M${f1(px)} ${f1(pz)}q${f1(1 + Q())} ${f1(-1.4)} ${f1(2 + Q())} 0`; });
          let tuft = ''; Pp.forEach((p, j) => { const q = Pp[(j + 1) % Pp.length]; rep(4, n => { const f = n / 4, px = p[0] + (q[0] - p[0]) * f, pz = p[1] + (q[1] - p[1]) * f, dx = px - x, dz = pz - z, L = Math.hypot(dx, dz) || 1; tuft += `M${f1(px)} ${f1(pz)}q${f1(dx / L * 2 + (Q() - 0.5) * 2)} ${f1(dz / L * 1.4)} ${f1(dx / L * 3.6)} ${f1(dz / L * 2.6 + (Q() - 0.5) * 1.4)}`; }); });
          return `<path d="${d}" fill="#000" opacity="0.18" transform="translate(1.6 2.2)" filter="url(#m29s)"/><path d="${d}" fill="${c0}"/><defs><clipPath id="${pid}"><path d="${d}"/></clipPath></defs><g clip-path="url(#${pid})"><path d="${cur}" stroke="${c1}" stroke-width="0.6" fill="none" stroke-linecap="round"/><path d="${cur}" stroke="#ffffff" stroke-width="0.25" fill="none" opacity="0.5" transform="translate(-0.3 -0.3)"/><ellipse cx="${x - 60}" cy="${z}" rx="14" ry="30" fill="#ffffff" opacity="0.18" filter="url(#m29b)">${an('cx', `${x - 50};${x + 50}`, 10 + i * 2, -i * 4)}</ellipse></g><path d="${tuft}" stroke="${c0}" stroke-width="1.1" fill="none" stroke-linecap="round"/><path d="${tuft}" stroke="${c1}" stroke-width="0.3" fill="none"/>`; }).join('');
      const s = fr + slab(C, P, T, '#b8a888') + top(C, T, face(id, P, a, 0.15)) + top(C, T + 0.4, pel);
      return { defs: DEF29, front: s, bb: C.bb(8) }; };
    return D; };

  // BED-077 PLUSH HAND-LOOMED TIBETAN SILK & CASHMERE CARPET (T4): 200 x 130 kept. A deep, dense hand-knotted carpet in soft slate-blue cashmere wool with
  // Tibetan cloud scrolls and a central medallion worked in ivory and champagne-gold silk, a narrow tiger-stripe guard border, a hand-bound edge and the
  // tiny tufts of a hand-knotted pile. Live: the silk catches the light as a slow sheen travels across the carpet and the scrolls glow.
  N.rug30d = S => { const { slab, top, face, rrP } = RD.H13, { DEF29, RUG } = RD.H29, W0 = 186, Dd = 118, T = 1.8, P = rrP(W0, Dd, 2), D = RUG(200, 130);
    D.fx = ctx => { const C = cam(ctx), R = rng('rug30d'), id = C.u('rd'), sg = C.u('rds');
      let a = `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="#4a5a6e"/>` + pile(R, -W0 / 2, -Dd / 2, W0, Dd, 1600, 1.2, '#3e4c5e', '#5e6e84');
      // abrash: soft horizontal colour bands
      a += rep(6, i => `<rect x="${-W0 / 2}" y="${f1(-Dd / 2 + i * Dd / 6)}" width="${W0}" height="${f1(Dd / 6)}" fill="${i % 2 ? '#6a7a90' : '#2e3a48'}" opacity="0.08"/>`).join('');
      // cloud scroll: a curl with a tail; silk = gradient fill + light edge
      const cloud = (x, z, s, fl) => `<g transform="translate(${x} ${z}) scale(${fl * s} ${s})"><path d="M-10 4Q-14 -4 -6 -6Q-4 -12 4 -9Q12 -10 11 -2Q16 2 9 6Q4 9 -2 6Q-8 9 -10 4Z" fill="url(#${sg})" stroke="#f4e6c4" stroke-width="0.6"/><path d="M-4 1Q-3 -4 2 -3Q5 -1 3 2Q1 3 0 1" fill="none" stroke="#c8a860" stroke-width="0.7"/><path d="M9 6Q16 9 20 6" fill="none" stroke="#f4e6c4" stroke-width="1.2" stroke-linecap="round"/></g>`;
      a += `<defs><linearGradient id="${sg}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6eedc"/><stop offset="0.5" stop-color="#e4cc94"/><stop offset="1" stop-color="#f6eedc"/></linearGradient></defs>`;
      a += `<ellipse cx="0" cy="0" rx="26" ry="18" fill="none" stroke="#e4cc94" stroke-width="1.4"/><ellipse cx="0" cy="0" rx="22" ry="15" fill="#3a485a"/>` + cloud(0, 0, 1.2, 1) + cloud(-4, -8, 0.6, -1);
      [[-60, -30, 1], [60, -30, -1], [-60, 30, -1], [60, 30, 1], [-28, 36, 1], [30, -38, -1], [-80, 4, 1], [80, -2, -1]].forEach(([x, z, fl], i) => a += cloud(x, z, 0.9 + (i % 3) * 0.15, fl));
      // tiger-stripe guard border + bound edge
      const B = 6; a += `<rect x="${-W0 / 2 + B}" y="${-Dd / 2 + B}" width="${W0 - 2 * B}" height="${Dd - 2 * B}" fill="none" stroke="#c8a860" stroke-width="0.8"/>`;
      let ts = ''; for (let x = -W0 / 2 + 2; x < W0 / 2 - 2; x += 3.2) { ts += `M${f1(x)} ${-Dd / 2 + 1}q1 2 0 4M${f1(x)} ${Dd / 2 - 1}q1 -2 0 -4`; } for (let z = -Dd / 2 + 6; z < Dd / 2 - 6; z += 3.2) { ts += `M${-W0 / 2 + 1} ${f1(z)}q2 1 4 0M${W0 / 2 - 1} ${f1(z)}q-2 1 -4 0`; }
      a += `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="none" stroke="#d8a85a" stroke-width="10" stroke-opacity="0.45"/><path d="${ts}" stroke="#2a2420" stroke-width="1.1" fill="none" stroke-linecap="round"/>`;
      a += `<rect x="-160" y="${-Dd / 2}" width="70" height="${Dd}" fill="#ffffff" opacity="0.14" filter="url(#m29b)" transform="skewX(-20)">${an('x', '-160;150', 11)}</rect>`;
      const s = slab(C, P, T, '#3a4656') + top(C, T, face(id, P, a, 0.25));
      return { defs: DEF29, front: s, bb: C.bb(6) }; };
    return D; };

  // BED-097 HEATED SOUND-DAMPENING CLOUD-FIBER SANCTUARY RUG (T5): 200 x 130 oval kept. A thick oval of cloud-white fibre built up from soft cumulus billows,
  // quilted into sound-dampening concentric channels, with a rolled pillow rim bound in champagne silk piping. A warm amber glow seeps out from under the
  // edge onto the floor. Live: warmth breathes out from the centre in slow rings and a soft sheen drifts across the billows.
  N.rug30e = S => { const { slab, top, face, ellP } = RD.H13, { DEF29, RUG } = RD.H29, A = 93, B = 60, T = 5, P = ellP(A, B, 64), D = RUG(200, 130);
    D.fx = ctx => { const C = cam(ctx), R = rng('rug30e'), id = C.u('re'), pg = C.u('rep'), gl = C.u('reg'), hw = C.u('reh');
      const inE = (x, z, s) => (x * x) / (A * A * s * s) + (z * z) / (B * B * s * s) < 1;
      let a = `<defs><radialGradient id="${pg}" cx="0.42" cy="0.38" r="0.62"><stop offset="0" stop-color="#ffffff"/><stop offset="0.55" stop-color="#f6f2ec"/><stop offset="1" stop-color="#ddd5ca"/></radialGradient>`
        + `<radialGradient id="${hw}"><stop offset="0" stop-color="#ffb868" stop-opacity="0.5"/><stop offset="0.6" stop-color="#ffc88a" stop-opacity="0.16"/><stop offset="1" stop-color="#ffd8a8" stop-opacity="0"/></radialGradient></defs>`
        + `<ellipse rx="${A}" ry="${B}" fill="#ece6dc"/>`;
      // cumulus billows: soft puffs, back to front, each with a shadow on its front side
      const PF = []; rep(120, () => { const t = R() * 2 * PI, r = Math.sqrt(R()) * 0.96, x = Math.cos(t) * A * r, z = Math.sin(t) * B * r; PF.push([x, z, 8 + R() * 8]); });
      PF.sort((p, q) => p[1] - q[1]);
      a += PF.map(([x, z, r]) => `<ellipse cx="${f1(x + 0.6)}" cy="${f1(z + 2.2)}" rx="${f1(r)}" ry="${f1(r * 0.78)}" fill="#b4a898" opacity="0.24" filter="url(#m29b)"/><ellipse cx="${f1(x)}" cy="${f1(z)}" rx="${f1(r)}" ry="${f1(r * 0.78)}" fill="url(#${pg})" filter="url(#m29s)"/>`).join('');
      a += pile(R, -A, -B, 2 * A, 2 * B, 1000, 1.6, '#ece6dc', '#ffffff', (x, z) => inE(x, z, 0.98));
      // quilted sound-dampening channels: concentric sunken seams (dark lower lip, light upper lip)
      [0.3, 0.56, 0.8].forEach(s => { a += `<ellipse rx="${f1(A * s)}" ry="${f1(B * s)}" fill="none" stroke="#8a7e70" stroke-width="1.6" opacity="0.2" filter="url(#m29b)"/><ellipse rx="${f1(A * s)}" ry="${f1(B * s)}" fill="none" stroke="#9a8e80" stroke-width="0.45" opacity="0.45"/><ellipse cy="-0.6" rx="${f1(A * s)}" ry="${f1(B * s)}" fill="none" stroke="#ffffff" stroke-width="0.5" opacity="0.7"/>`; });
      // stitch ticks along the channels
      let st = ''; [0.3, 0.56, 0.8].forEach(s => { const n = Math.round(60 * s); for (let i = 0; i < n; i++) { const t = i / n * 2 * PI, x = Math.cos(t) * A * s, z = Math.sin(t) * B * s; st += `M${f1(x - Math.sin(t) * 0.5)} ${f1(z + Math.cos(t) * 0.35)}l${f1(Math.sin(t))} ${f1(-Math.cos(t) * 0.7)}`; } });
      a += `<path d="${st}" stroke="#d8c8a4" stroke-width="0.3" opacity="0.7"/>`;
      // heat: centre glow breathes + rings of warmth travel outward
      a += `<ellipse rx="${A * 0.5}" ry="${B * 0.5}" fill="url(#${hw})">${an('opacity', '0.55;1;0.55', 8, 0, SPL(2))}</ellipse>`;
      [0, 4.5].forEach(ph => { a += `<ellipse rx="10" ry="6.5" fill="none" stroke="#ffc07a" stroke-width="3" opacity="0" filter="url(#m29b)">${an('rx', `10;${A * 0.92}`, 9, -ph)}${an('ry', `6.5;${B * 0.92}`, 9, -ph)}${an('opacity', '0;0.32;0', 9, -ph, KT('0;0.25;1'))}</ellipse>`; });
      // rolled pillow rim + champagne silk piping
      a += `<ellipse rx="${A - 3}" ry="${B - 3}" fill="none" stroke="#fbf8f2" stroke-width="5"/><ellipse rx="${A - 6}" ry="${B - 6}" fill="none" stroke="#9a8e80" stroke-width="1.4" opacity="0.18" filter="url(#m29s)"/><ellipse cx="-0.4" cy="-0.8" rx="${A - 3}" ry="${B - 3}" fill="none" stroke="#ffffff" stroke-width="1.2" opacity="0.8"/>`
        + `<ellipse rx="${A - 0.6}" ry="${B - 0.6}" fill="none" stroke="#d8bf8a" stroke-width="1"/><ellipse rx="${A - 0.6}" ry="${B - 0.6}" fill="none" stroke="#fff4dc" stroke-width="0.3" stroke-dasharray="1.4 1"/>`;
      // drifting sheen
      a += `<rect x="-170" y="${-B}" width="80" height="${2 * B}" fill="#ffffff" opacity="0.2" filter="url(#m29b)" transform="skewX(-22)">${an('x', '-170;150', 13)}</rect>`;
      // warm under-glow seeping onto the floor round the edge
      const glow = top(C, 0.03, `<defs><radialGradient id="${gl}"><stop offset="0.78" stop-color="#ffb05a" stop-opacity="0.55"/><stop offset="0.9" stop-color="#ffc47e" stop-opacity="0.22"/><stop offset="1" stop-color="#ffd8a8" stop-opacity="0"/></radialGradient></defs><ellipse rx="${A + 12}" ry="${B + 9}" fill="url(#${gl})">${an('opacity', '0.6;1;0.6', 8, 0, SPL(2))}</ellipse>`);
      // soft fibre fluff spilling over the rim (softens the edge so it reads as a thick cushion, not a tray)
      let tf = ''; rep(300, () => { const t = R() * 2 * PI, x = Math.cos(t) * A, z = Math.sin(t) * B, nx = Math.cos(t), nz = Math.sin(t), d = R() * 0.8, tw = (R() - 0.5) * 1.6, L = 0.6 + R(); tf += `M${f1(x - nx * (d + 1))} ${f1(z - nz * (d + 1))}q${f1(nx * L * 0.5 - nz * tw)} ${f1(nz * L * 0.5 + nx * tw * 0.7)} ${f1(nx * L)} ${f1(nz * L * 0.8)}`; });
      const fluff = `<path d="${tf}" stroke="#f6f1e8" stroke-width="0.9" fill="none" stroke-linecap="round"/><path d="${tf}" stroke="#ffffff" stroke-width="0.4" fill="none" stroke-linecap="round" opacity="0.8" transform="translate(-0.2 -0.3)"/>`;
      const sh = top(C, 0.03, `<ellipse cx="2" cy="3" rx="${A + 2}" ry="${B + 2}" fill="#6a4a2a" opacity="0.16" filter="url(#m29b)"/>`);
      const s = sh + glow + slab(C, P, T, '#efe8dc').replace(/^<g[^>]*><path[^>]*\/><\/g>/, '') + top(C, T, face(id, P, a, 0.12) + fluff);
      return { defs: DEF29, front: s, bb: C.bb(12) }; };
    return D; };

  // ======================= WALLS (r.s12 80 x 56 tiles registered into RD.H12.SURF12, same pipeline as the Bathroom walls in plus29) =======================
  const WMEMO30 = {};
  { const { blot, outlet, BB, SURF12 } = RD.H12;
    const memo = (k, f) => () => WMEMO30[k] || (WMEMO30[k] = f());
    const stip = (R, n, y0, y1, a, b, o0, o1) => { let s = ''; rep(n, () => s += `<circle cx="${f1(R() * 80)}" cy="${f1(y0 + R() * (y1 - y0))}" r="${f1(0.07 + R() * 0.12)}" fill="${R() < 0.5 ? a : b}" opacity="${f1(o0 + R() * o1)}"/>`); return s; };

    // BED-001 SCUFFED EGGSHELL DRYWALL WITH POSTER TACK MARKS (T1): tired eggshell paint over drywall with roller stipple and lap marks, a taped seam
    // showing through with two nail pops, the brighter ghosts of posters that hung here for years, with greasy blue-tack stains, leftover blobs and
    // pulled-off paint at the corners, pin holes, a bent nail, grey furniture scuffs and a black shoe scuff, a cracked almond outlet painted round, and a
    // cheap MDF skirting with chipped paint. Live: a torn poster corner still stuck under yellowed tape flutters in the draught.
    const wDry = memo('d01', () => { const R = rng('wd01');
      let up = '<rect width="80" height="56" fill="#e8e1cf"/>' + blot('wd01', 32, ['#efe9d8', '#ddd4be', '#e4dcc8', '#d4cab2'], 0.4, 3.6)
        + rep(9, i => `<rect x="${f1(i * 9 + R() * 3)}" width="${f1(3 + R() * 3)}" height="56" fill="${R() < 0.5 ? '#ffffff' : '#bcb298'}" opacity="${f1(0.04 + R() * 0.04)}"/>`).join('')
        + stip(R, 520, 0, 56, '#ffffff', '#b8ae94', 0.12, 0.2) + '<rect width="80" height="5" fill="url(#d01m)"/>';
      let s = up;
      // taped seam + nail pops
      s += '<g filter="url(#wb1)"><rect x="38.4" width="3.2" height="56" fill="#f2ecdc" opacity="0.5"/><path d="M38.4 0V56" stroke="#c4b89c" stroke-width="0.25" opacity="0.5"/><path d="M41.6 0V56" stroke="#c4b89c" stroke-width="0.25" opacity="0.4"/></g>';
      [[40, 14.2], [12.4, 31]].forEach(([x, y]) => s += `<circle cx="${x}" cy="${y}" r="0.75" fill="#f4eee0"/><circle cx="${x}" cy="${y}" r="0.75" fill="none" stroke="#a89c80" stroke-width="0.12" stroke-dasharray="0.5 0.35"/><circle cx="${f1(x + 0.15)}" cy="${f1(y + 0.15)}" r="0.32" fill="#9a907c" opacity="0.5"/>`);
      s += '<path d="M39.6 22Q40.2 26 39.8 30.4Q40.3 33 40 35.6" stroke="#8a7e66" stroke-width="0.1" fill="none" opacity="0.7"/>';
      // poster ghosts: paint that stayed brighter under the paper, with a dust line along the top
      const ghost = (x, y, w, h, rot) => `<g transform="rotate(${rot} ${x + w / 2} ${y + h / 2})"><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#f4eedd" opacity="0.42"/><rect x="${x}" y="${f1(y - 0.2)}" width="${w}" height="0.3" fill="#a89a7c" opacity="0.22"/><rect x="${f1(x + w - 0.3)}" y="${y}" width="0.3" height="${h}" fill="#b8ac90" opacity="0.12"/></g>`;
      s += ghost(5, 7, 19, 26, -1.5) + ghost(50, 5, 23, 16, 0.8) + ghost(29.5, 9, 7, 10, 3);
      // corner tack marks: greasy halo, leftover blue tack / white tack, or pulled-off paint
      const tack = (x, y, k) => { let o = `<ellipse cx="${x}" cy="${y}" rx="1.3" ry="1.1" fill="#c4b088" opacity="0.4" filter="url(#wb1)"/>`;
        if (k === 1) o += `<path d="M${f1(x - 0.5)} ${f1(y - 0.2)}q0.3 -0.6 0.8 -0.3q0.5 0 0.3 0.6q0 0.5 -0.6 0.4q-0.6 0 -0.5 -0.7Z" fill="#4a84c4"/><path d="M${f1(x - 0.3)} ${f1(y - 0.35)}q0.3 -0.2 0.5 0" stroke="#9cc4ec" stroke-width="0.12" fill="none"/>`;
        if (k === 2) o += `<path d="M${f1(x - 0.4)} ${f1(y)}q0.2 -0.5 0.7 -0.3q0.3 0.2 0 0.6q-0.4 0.2 -0.7 -0.3Z" fill="#f4f0e4" stroke="#b8ae94" stroke-width="0.08"/>`;
        if (k === 3) o += `<path d="M${f1(x - 0.9)} ${f1(y - 0.3)}l0.5 -0.5l0.7 0.2l0.5 -0.3l0.2 0.6l-0.4 0.5l-0.8 0.1l-0.6 0.1Z" fill="#c8b898"/><path d="M${f1(x - 0.9)} ${f1(y - 0.3)}l0.5 -0.5l0.7 0.2l0.5 -0.3" stroke="#f8f4e8" stroke-width="0.14" fill="none"/>`;
        return o; };
      s += tack(5.4, 7.5, 1) + tack(23.5, 7, 3) + tack(5.8, 32.6, 0) + tack(23.2, 32.2, 2) + tack(50.4, 5.4, 3) + tack(72.6, 5.6, 0) + tack(50.3, 20.6, 1) + tack(72.8, 21.4, 2) + tack(30, 9.4, 0) + tack(36.2, 9.8, 1);
      // pin holes, a bent nail with a torn hole
      rep(9, () => { const x = 2 + R() * 76, y = 3 + R() * 36; s += `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.22" fill="#f8f4e8"/><circle cx="${f1(x)}" cy="${f1(y)}" r="0.11" fill="#3a3428"/>`; });
      s += '<path d="M62.6 27.4l-0.5 -0.4l0.3 -0.6l0.6 0.1l0.4 0.5Z" fill="#c8bc9e"/><path d="M62.8 27.2l1.2 -0.5" stroke="#6a665e" stroke-width="0.32" stroke-linecap="round"/><circle cx="64.1" cy="26.7" r="0.34" fill="#8a867c"/><path d="M62.8 27.4l1.2 0.9" stroke="#000" stroke-width="0.3" opacity="0.15" filter="url(#wb1)"/>';
      // scuffs: grey furniture rub band, smudges, a black shoe scuff near the skirting
      s += '<g filter="url(#wb1)"><path d="M8 41.2Q24 40.4 34 41.6" stroke="#8a8070" stroke-width="0.9" opacity="0.18" fill="none"/><ellipse cx="58" cy="38" rx="3" ry="1.6" fill="#6a6252" opacity="0.1"/><ellipse cx="66" cy="34" rx="1.2" ry="1.8" fill="#8a7e66" opacity="0.14"/></g>'
        + '<path d="M18 49.6q2 -0.8 4.4 -0.4M19 50.4q1.6 -0.4 3 0" stroke="#2a2622" stroke-width="0.3" opacity="0.5" fill="none" stroke-linecap="round"/><path d="M44 41q1.4 -0.6 3.2 -0.2" stroke="#5a544a" stroke-width="0.2" opacity="0.35" fill="none"/>';
      // cracked almond outlet, painted round its edge
      s += '<rect x="67.4" y="44.6" width="3" height="4.6" rx="0.3" fill="#000" opacity="0.15" filter="url(#wb1)"/><rect x="67.2" y="44.2" width="3" height="4.6" rx="0.3" fill="#e6dcc0" stroke="#b8aa86" stroke-width="0.12"/><rect x="67.05" y="44.05" width="3.3" height="4.9" rx="0.35" fill="none" stroke="#e8e1cf" stroke-width="0.3" opacity="0.8"/>'
        + [45, 47].map(y => `<rect x="67.95" y="${y}" width="0.22" height="0.6" fill="#4a4436"/><rect x="69.15" y="${y}" width="0.22" height="0.6" fill="#4a4436"/><path d="M68.55 ${f1(y + 0.95)}a0.18 0.18 0 0 1 0.36 0v0.18h-0.36Z" fill="#4a4436"/>`).join('')
        + '<circle cx="68.7" cy="46.5" r="0.18" fill="#b8aa86"/><path d="M68.7 46.5l0.8 -0.5l0.3 -0.9M68.7 46.5l-0.6 0.7" stroke="#6a5e44" stroke-width="0.07" fill="none"/>';
      // torn poster corner still stuck under yellowed tape (live: flutters)
      const fl = 'M50.6 5.6L55.4 5.8L50.8 10.6Z', fl2 = 'M50.6 5.6L55.2 6.6L51.6 10.2Z';
      s += `<path d="M50.8 6.6L54.8 6.4L51 10.4Z" fill="#000" opacity="0.12" filter="url(#wb1)"><animate attributeName="d" values="M50.8 6.6L54.8 6.4L51 10.4Z;M50.8 6.6L54.6 7.4L51.8 10Z;M50.8 6.6L54.8 6.4L51 10.4Z" dur="5s" repeatCount="indefinite" ${SPL(2)}/></path>`
        + `<path d="${fl}" fill="#1e1a2a"><animate attributeName="d" values="${fl};${fl2};${fl}" dur="5s" repeatCount="indefinite" ${SPL(2)}/></path>`
        + `<path d="M50.6 5.6L53.2 5.7L50.7 8.3Z" fill="#c83a5a"/><path d="M51.2 6.2l1.2 0.05" stroke="#f4d84a" stroke-width="0.3"/>`
        + '<rect x="49.6" y="4.6" width="3.2" height="1.8" fill="#e8d698" opacity="0.55" transform="rotate(-8 51.2 5.5)"/><rect x="49.6" y="4.6" width="3.2" height="0.3" fill="#ffffff" opacity="0.4" transform="rotate(-8 51.2 5.5)"/>';
      s += `<rect y="${f1(BB - 1.6)}" width="80" height="1.6" fill="#8a8068" opacity="0.12" filter="url(#wb1)"/>`;
      const board = '#e6e0ce';
      return { mat: s, sup: up, board,
        defs: '<linearGradient id="d01m" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8a8068" stop-opacity="0.16"/><stop offset="1" stop-color="#8a8068" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.06, ao: 0.16, board: `<rect y="${f1(BB + 0.3)}" width="80" height="0.35" fill="#ffffff" opacity="0.5"/>` + [[9, 0.8], [33, 1.4], [61, 0.6]].map(([x, w]) => `<path d="M${x} ${f1(BB + 0.2)}h${w}l-0.2 0.7h${f1(-w + 0.5)}Z" fill="#a8885e"/>`).join('')
          + stip(rng('d01b'), 40, BB + 0.5, 56, '#8a8068', '#ffffff', 0.15, 0.25) + '<path d="M26 55.2q2 -0.5 4.6 -0.2" stroke="#2a2622" stroke-width="0.3" opacity="0.4" fill="none"/>' } }; });

    // BED-021 SOFT LAVENDER & CREAM PAINTED WALLS (T2): soft lavender matte paint above a white painted chair rail, warm cream below, a fresh coat but
    // a home-painted one: faint roller stipple and lap bands, a slightly wavy cut-in line where lavender meets the rail with one tiny drip on the cream,
    // a touch-up patch that dried a shade off, the soft shadow of the ceiling corner, a white outlet and a satin white skirting.
    // Live: a warm patch of afternoon window light slides slowly across the lavender.
    const wLav = memo('d21', () => { const R = rng('wl21'), CR = 33.6, CH = 2.4;
      let up = '<rect width="80" height="56" fill="#c4b6dc"/>' + blot('wl21', 28, ['#ccc0e2', '#b8aad2', '#c8bade', '#beb0d8'], 0.35, 3.4)
        + rep(8, i => `<rect x="${f1(i * 10 + R() * 4)}" width="${f1(4 + R() * 3)}" height="56" fill="${R() < 0.5 ? '#ffffff' : '#7a6aa0'}" opacity="0.035"/>`).join('')
        + stip(R, 380, 0, 56, '#ffffff', '#8a7aac', 0.08, 0.14) + '<rect width="80" height="6" fill="url(#d21m)"/>';
      let s = up;
      // touch-up patch dried a shade off
      s += '<g filter="url(#wb2)"><rect x="16" y="14" width="7" height="5" rx="1.5" fill="#cabde2" opacity="0.5"/></g>';
      // drifting warm window light (clipped to the lavender)
      s += `<g clip-path="url(#d21u)"><g filter="url(#wb2)" opacity="0.5"><path d="M0 4h9l-3 26h-9Z M11 4h9l-3 26h-9Z" fill="#ffe4b8" opacity="0.32">${at('translate', '-14 0;94 0', 40)}</path></g></g>`;
      // cream lower wall
      s += `<rect y="${f1(CR + CH)}" width="80" height="${f1(BB - CR - CH)}" fill="#f1e8d4"/>` + blot('wl21c', 14, ['#f4ecdc', '#e8dcc4'], 0.3, 2.6).replace('<g ', `<g clip-path="url(#d21l)" `) + stip(rng('wl21s'), 160, CR + CH, BB, '#ffffff', '#c8b894', 0.1, 0.15);
      // wavy cut-in line + tiny drip
      let cut = `M0 ${f1(CR - 0.1)}`; for (let x = 4; x <= 80; x += 4) cut += `L${x} ${f1(CR - 0.1 + (R() - 0.5) * 0.35)}`;
      s += `<path d="${cut}" stroke="#b8aad2" stroke-width="0.35" fill="none"/><path d="M27.4 ${f1(CR + CH)}q0.15 0.9 0.05 1.6q-0.05 0.3 -0.2 0" stroke="#bcaed8" stroke-width="0.32" fill="none" stroke-linecap="round"/><circle cx="27.3" cy="${f1(CR + CH + 1.7)}" r="0.22" fill="#bcaed8"/>`;
      // chair rail moulding: shadow, ogee profile, highlights
      s += `<rect y="${f1(CR + CH - 0.2)}" width="80" height="1" fill="#5a4a3a" opacity="0.14" filter="url(#wb1)"/><rect y="${f1(CR)}" width="80" height="${CH}" fill="url(#d21k)"/>`
        + `<rect y="${f1(CR + 0.25)}" width="80" height="0.22" fill="#ffffff"/><rect y="${f1(CR + 1.25)}" width="80" height="0.18" fill="#c8c0b0" opacity="0.7"/><rect y="${f1(CR + 1.5)}" width="80" height="0.2" fill="#ffffff" opacity="0.7"/>`
        + '<path d="M52 ' + f1(CR + 0.1) + 'v' + f1(CH - 0.2) + '" stroke="#d4ccbc" stroke-width="0.12"/>';
      // outlet on the cream
      s += `<rect x="61.4" y="44.4" width="3" height="4.6" rx="0.3" fill="#000" opacity="0.12" filter="url(#wb1)"/><rect x="61.2" y="44" width="3" height="4.6" rx="0.3" fill="#fbfaf6" stroke="#d4d0c4" stroke-width="0.1"/>`
        + [44.8, 46.8].map(y => `<rect x="61.95" y="${y}" width="0.2" height="0.55" fill="#6a665c"/><rect x="63.1" y="${y}" width="0.2" height="0.55" fill="#6a665c"/><path d="M62.5 ${f1(y + 0.9)}a0.16 0.16 0 0 1 0.32 0v0.16h-0.32Z" fill="#6a665c"/>`).join('') + '<circle cx="62.7" cy="46.3" r="0.15" fill="#d4d0c4"/>';
      s += `<rect y="${f1(BB - 1.4)}" width="80" height="1.4" fill="#8a7a5a" opacity="0.1" filter="url(#wb1)"/>`;
      const board = '#f8f6f0';
      return { mat: s, sup: up, board,
        defs: `<clipPath id="d21u"><rect width="80" height="${CR}"/></clipPath><clipPath id="d21l"><rect y="${f1(CR + CH)}" width="80" height="${f1(BB - CR - CH)}"/></clipPath>`
          + '<linearGradient id="d21m" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a3a6a" stop-opacity="0.16"/><stop offset="1" stop-color="#4a3a6a" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="d21k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fdfcf8"/><stop offset="0.3" stop-color="#f2efe8"/><stop offset="0.55" stop-color="#ddd8cc"/><stop offset="0.75" stop-color="#f6f4ee"/><stop offset="1" stop-color="#d0cabc"/></linearGradient>',
        ro: { top: 0.08, ao: 0.1, board: `<rect y="${f1(BB + 0.3)}" width="80" height="0.5" fill="#ffffff" opacity="0.9"/><rect y="${f1(BB + 1.1)}" width="80" height="0.2" fill="#d8d4c8"/>` } }; });


    const pp = p => f1(p[0]) + ' ' + f1(p[1]);
    const crs = (P, k) => { const o = []; for (let i = 0; i < P.length - 1; i++) { const p0 = P[Math.max(i - 1, 0)], p1 = P[i], p2 = P[i + 1], p3 = P[Math.min(i + 2, P.length - 1)];
        for (let j = 0; j < k; j++) { const t = j / k, t2 = t * t, t3 = t2 * t; o.push([0, 1].map(c => 0.5 * (2 * p1[c] + (-p0[c] + p2[c]) * t + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t2 + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t3))); } }
      o.push(P[P.length - 1]); return o; };
    // tapered brush stroke along a Catmull-Rom spine (filled outline, slightly ragged edge)
    const brush = (S, w0, w1, R) => { const n = S.length, L = [], Q = [];
      S.forEach((p, i) => { const a = S[Math.max(i - 1, 0)], b = S[Math.min(i + 1, n - 1)], dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1, w = (w0 + (w1 - w0) * i / (n - 1)) / 2 * (0.85 + R() * 0.3);
        L.push([p[0] - dy / l * w, p[1] + dx / l * w]); Q.push([p[0] + dy / l * w, p[1] - dx / l * w]); });
      return 'M' + L.map(pp).join('L') + 'L' + Q.reverse().map(pp).join('L') + 'Z'; };
    const wrap = g => g + `<g transform="translate(-80 0)">${g}</g><g transform="translate(80 0)">${g}</g>`;

    // BED-041 BOTANICAL CHINOISERIE WALLPAPER & WAINSCOTING (T3): hand-painted-style chinoiserie paper on a soft celadon ground with a linen weave and a
    // faint mica sheen: two flowering plum trees in umber brush strokes with blush and white blossoms and buds, a stand of bamboo with ink-green leaves
    // and a little indigo songbird on a branch; the paper's seam at the drop; below, a sage-painted raised-panel wainscot with a moulded cap rail,
    // bevelled panels, brush marks in the satin paint, a slim outlet on a stile and a matching skirting. Live: the mica ground glimmers as the light moves.
    const wChin = memo('d41', () => { const R = rng('wc41'), RB = rng('wc41b'), WT = 30.4, CAP = 2.2, Y0 = WT + CAP;
      let ground = '<rect width="80" height="56" fill="#cfdbc9"/>' + blot('wc41', 30, ['#d9e4d3', '#c3d2bf', '#d4dfcd', '#bccbb6'], 0.42, 4.2)
        + rep(112, i => `<rect y="${f1(i * 0.5)}" width="80" height="0.18" fill="${i % 2 ? '#ffffff' : '#8a9e86'}" opacity="${f1(0.04 + R() * 0.04)}"/>`).join('')
        + rep(60, () => `<rect x="${f1(R() * 80)}" width="0.12" height="56" fill="#8a9e86" opacity="0.06"/>`).join('')
        + stip(R, 260, 0, 56, '#ffffff', '#93a68e', 0.1, 0.16);
      // painted motif
      const BR = [
        [[[14, 58], [14.4, 40], [13.4, 31], [15.6, 23], [14.6, 16], [17.2, 10.4], [21.4, 5.6]], 1.9, 0.5],
        [[[15.3, 20.2], [19, 18.4], [23.4, 15.6], [27.4, 15.8], [31, 14.6], [34.6, 11.6]], 0.85, 0.22],
        [[[15.2, 13.4], [12.2, 10.8], [9, 9.6], [5.6, 6.6]], 0.7, 0.2],
        [[[27.4, 15.8], [29, 19], [32, 21], [35, 21.2]], 0.5, 0.16],
        [[[18.2, 8.4], [19.4, 4.6], [18.4, 1.8], [19.6, -1.6]], 0.5, 0.16],
        [[[14, 27], [10.8, 25.6], [8, 22.4], [4.6, 21.6]], 0.6, 0.18],
        [[[58, 58], [58.4, 40], [59.2, 30], [56.6, 23.6], [57.8, 17.6], [56, 12], [52.2, 7.6]], 1.8, 0.5],
        [[[57.2, 22], [61.6, 19.8], [66, 20.2], [70.4, 17], [74.4, 15.4], [79, 13.6], [86, 10.6]], 0.85, 0.2],
        [[[57.4, 15], [60.8, 11.6], [64.4, 8.6], [68.4, 7.8]], 0.6, 0.18],
        [[[53.6, 8.8], [50, 9], [47.2, 6.4], [44, 6.6]], 0.5, 0.16],
        [[[66, 20.2], [67.6, 23.6], [71, 25.4]], 0.42, 0.14],
      ].map(([P, a, b]) => [crs(P, 5), a, b]);
      let tree = '';
      BR.forEach(([S, a, b]) => { const d = brush(S, a, b, RB);
        tree += `<path d="${d}" fill="#5a4030"/><path d="M${S.map(p => pp([p[0] - 0.18, p[1] - 0.1])).join('L')}" stroke="#9a7a58" stroke-width="${f1(Math.max(0.08, b * 0.6))}" fill="none" opacity="0.55" stroke-linecap="round"/>`; });
      // knots + moss dots on the trunks
      [[14.2, 33], [15, 24.6], [58.6, 33.4], [57.4, 26]].forEach(([x, y]) => tree += `<ellipse cx="${x}" cy="${y}" rx="0.45" ry="0.3" fill="#3a2a1e"/><circle cx="${f1(x - 0.6)}" cy="${f1(y + 1.2)}" r="0.2" fill="#6a7a4a" opacity="0.7"/>`);
      // bamboo stand (behind the plum, between the trees)
      let bam = '';
      [[36.8, 9.4, 0.95], [39.4, 14, 0.8], [33.6, 17.6, 0.65]].forEach(([x, top, w]) => { bam += `<rect x="${f1(x - w / 2)}" y="${top}" width="${w}" height="${f1(58 - top)}" fill="#7e9a6a"/><rect x="${f1(x - w / 2)}" y="${top}" width="${f1(w * 0.3)}" height="${f1(58 - top)}" fill="#a8c094" opacity="0.6"/>`;
        for (let y = top + 3.2; y < 31; y += 3.6 + R() * 0.8) bam += `<rect x="${f1(x - w / 2 - 0.12)}" y="${f1(y)}" width="${f1(w + 0.24)}" height="0.32" rx="0.12" fill="#4e6a44"/>`; });
      const leaf = (x, y, rot, l) => `<path d="M0 0Q${f1(l * 0.35)} ${f1(-l * 0.16)} ${l} 0Q${f1(l * 0.35)} ${f1(l * 0.12)} 0 0Z" fill="${R() < 0.5 ? '#4f7050' : '#5f8258'}" transform="translate(${f1(x)} ${f1(y)}) rotate(${f1(rot)})"/>`;
      [[36.8, 12, 0], [39.4, 16.8, 1], [33.6, 20.4, 0], [36.8, 19.4, 1], [39.4, 24.2, 0]].forEach(([x, y, side]) => rep(4, k => bam += leaf(x, y + k * 0.25, (side ? -20 : 200) + (k - 1.5) * 24 + (R() - 0.5) * 10, 3.2 + R() * 1.6)));
      // blossoms + buds along the thinner branches
      let bl = '';
      const PK = ['#eebcb6', '#f4cfc8', '#e6a8a4', '#f8e2dc', '#ffffff'];
      const flower = (x, y, r, c) => { let o = `<g transform="rotate(${f1(R() * 72)} ${f1(x)} ${f1(y)})">`;
        for (let k = 0; k < 5; k++) { const a = k * 1.2566; o += `<circle cx="${f1(x + Math.cos(a) * r * 0.55)}" cy="${f1(y + Math.sin(a) * r * 0.55)}" r="${f1(r * 0.48)}" fill="${c}" stroke="#c8867e" stroke-width="0.05"/>`; }
        return o + `</g><circle cx="${f1(x - r * 0.15)}" cy="${f1(y - r * 0.2)}" r="${f1(r * 0.35)}" fill="#ffffff" opacity="0.45"/><circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r * 0.2)}" fill="#c8843e"/>`
          + rep(4, k => `<circle cx="${f1(x + Math.cos(k * 1.6 + 0.4) * r * 0.36)}" cy="${f1(y + Math.sin(k * 1.6 + 0.4) * r * 0.36)}" r="0.06" fill="#8a4a2a"/>`).join(''); };
      BR.slice(1).forEach(([S]) => { for (let i = 2; i < S.length; i += 2 + Math.floor(R() * 3)) { const p = S[i], ox = (R() - 0.5) * 1.6, oy = (R() - 0.5) * 1.6;
        if (R() < 0.72) bl += flower(p[0] + ox, p[1] + oy, 0.75 + R() * 0.5, PK[Math.floor(R() * PK.length)]);
        else bl += `<ellipse cx="${f1(p[0] + ox)}" cy="${f1(p[1] + oy)}" rx="0.32" ry="0.42" fill="#c86a70" transform="rotate(${f1(R() * 90 - 45)} ${f1(p[0] + ox)} ${f1(p[1] + oy)})"/><path d="M${pp([p[0] + ox, p[1] + oy + 0.3])}l${f1(-ox * 0.4)} ${f1(-oy * 0.4)}" stroke="#5a4030" stroke-width="0.1"/>`; } });
      // songbird perched on the left branch
      const bird = '<g transform="translate(25.4 13.4)"><path d="M-0.6 1.1L-3.8 3.2L-3.2 3.6L-0.2 1.8Z" fill="#2e3c62"/><ellipse cx="0.4" cy="0.6" rx="1.7" ry="1.15" fill="#3e5486" transform="rotate(-14 0.4 0.6)"/>'
        + '<path d="M-0.6 0.9Q0.6 2.4 1.8 1Q1 1.9 -0.6 0.9Z" fill="#e0a654"/><path d="M-0.8 0.2Q0.6 -0.5 1.4 0.6Q0.2 0.3 -0.8 0.2Z" fill="#26325a"/><circle cx="1.8" cy="-0.5" r="0.85" fill="#3e5486"/>'
        + '<path d="M2.5 -0.6l0.75 0.15l-0.7 0.25Z" fill="#3a2a1e"/><circle cx="2" cy="-0.7" r="0.14" fill="#14141a"/><circle cx="2.04" cy="-0.74" r="0.05" fill="#ffffff"/>'
        + '<path d="M0 1.7l-0.1 0.9M0.7 1.7l0.1 0.8" stroke="#3a2a1e" stroke-width="0.1"/><path d="M-0.4 -0.2Q0.6 -0.9 1.6 -0.6" stroke="#8aa0d0" stroke-width="0.12" fill="none" opacity="0.7"/></g>';
      const motif = bam + tree + bl + bird;
      let paper = ground + `<g>${wrap(motif)}</g>`;
      // paper drop seam at x=40 (a hair of mismatch) + mica glimmer
      paper += '<rect x="39.9" width="0.2" height="56" fill="#ffffff" opacity="0.35"/><rect x="40.1" width="0.12" height="56" fill="#7a8e76" opacity="0.25"/>';
      paper += rep(46, () => { const x = R() * 80, y = R() * 30, T = 5 + R() * 6; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(0.12 + R() * 0.12)}" fill="#fffbea" opacity="0">${an('opacity', '0;0.85;0', T, -R() * T, SPL(2))}</circle>`; }).join('')
        + `<rect x="-30" width="16" height="56" fill="url(#d41s)" transform="skewX(-20)">${an('x', '-30;110', 18)}</rect>`;
      paper += '<rect width="80" height="5" fill="url(#d41m)"/>';
      // sage raised-panel wainscot
      let wn = `<rect y="${f1(Y0)}" width="80" height="${f1(BB - Y0)}" fill="#8a9e8a"/>`
        + rep(40, () => `<rect x="${f1(R() * 80)}" y="${f1(Y0)}" width="${f1(0.1 + R() * 0.2)}" height="${f1(BB - Y0)}" fill="${R() < 0.5 ? '#a4b6a2' : '#748a76'}" opacity="0.35"/>`).join('');
      for (let i = 0; i < 4; i++) { const x = i * 20 + 2.6, y = Y0 + 2.6, w = 14.8, h = BB - Y0 - 5.4, b = 1.3;
        wn += `<rect x="${f1(x - 0.4)}" y="${f1(y - 0.4)}" width="${f1(w + 0.8)}" height="${f1(h + 0.8)}" fill="#6a7e6c"/><rect x="${f1(x - 0.4)}" y="${f1(y - 0.4)}" width="${f1(w + 0.8)}" height="0.35" fill="#4e6052" opacity="0.8"/>`
          + `<path d="M${f1(x)} ${f1(y)}h${w}l${-b} ${b}h${f1(-w + 2 * b)}Z" fill="#a8baa6"/><path d="M${f1(x)} ${f1(y)}v${f1(h)}l${b} ${-b}v${f1(-h + 2 * b)}Z" fill="#9aae98"/>`
          + `<path d="M${f1(x + w)} ${f1(y)}v${f1(h)}l${-b} ${-b}v${f1(-h + 2 * b)}Z" fill="#748a76"/><path d="M${f1(x)} ${f1(y + h)}h${w}l${-b} ${-b}h${f1(-w + 2 * b)}Z" fill="#667a68"/>`
          + `<rect x="${f1(x + b)}" y="${f1(y + b)}" width="${f1(w - 2 * b)}" height="${f1(h - 2 * b)}" fill="#91a590"/><rect x="${f1(x + b)}" y="${f1(y + b)}" width="${f1(w - 2 * b)}" height="${f1(h - 2 * b)}" fill="url(#d41p)"/>`; }
      wn += '<g filter="url(#wb2)"><path d="M10 33L17 33L13 54L6 54Z M50 33L54 33L50 54L46 54Z" fill="#ffffff" opacity="0.14"/></g>';
      wn += `<rect x="58.8" y="45.4" width="2.6" height="4" rx="0.3" fill="#000" opacity="0.15" filter="url(#wb1)"/><rect x="58.6" y="45" width="2.6" height="4" rx="0.3" fill="#f4f2ea" stroke="#9aa894" stroke-width="0.1"/>`
        + [45.6, 47.6].map(y => `<rect x="59.3" y="${y}" width="0.2" height="0.5" fill="#5a5e58"/><rect x="60.3" y="${y}" width="0.2" height="0.5" fill="#5a5e58"/>`).join('') + '<circle cx="59.9" cy="47" r="0.13" fill="#c8ccc0"/>';
      let s = paper + wn;
      // cap rail: shadow on the paper, moulded profile, shadow on the panels
      s += `<rect y="${f1(WT - 0.9)}" width="80" height="1" fill="#2a3a2a" opacity="0.14" filter="url(#wb1)"/><rect y="${f1(WT)}" width="80" height="${CAP}" fill="url(#d41k)"/>`
        + `<rect y="${f1(WT + 0.3)}" width="80" height="0.2" fill="#d4e0d0" opacity="0.9"/><rect y="${f1(WT + 1.3)}" width="80" height="0.15" fill="#5a6e5c"/><rect y="${f1(WT + 1.5)}" width="80" height="0.2" fill="#b8c8b4" opacity="0.8"/>`
        + `<rect y="${f1(Y0)}" width="80" height="1" fill="#1e2a1e" opacity="0.2" filter="url(#wb1)"/>`;
      s += `<rect y="${f1(BB - 1.4)}" width="80" height="1.4" fill="#2a3a2a" opacity="0.12" filter="url(#wb1)"/>`;
      const board = '#7e9280';
      return { mat: s, sup: paper, board,
        defs: '<linearGradient id="d41m" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a4a3a" stop-opacity="0.16"/><stop offset="1" stop-color="#3a4a3a" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="d41s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff6dc" stop-opacity="0"/><stop offset="0.5" stop-color="#fff6dc" stop-opacity="0.16"/><stop offset="1" stop-color="#fff6dc" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="d41p" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#2a3a2a" stop-opacity="0.1"/></linearGradient>'
          + '<linearGradient id="d41k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#bccab8"/><stop offset="0.25" stop-color="#a4b6a2"/><stop offset="0.55" stop-color="#7e9280"/><stop offset="0.75" stop-color="#9eb09c"/><stop offset="1" stop-color="#6a7e6c"/></linearGradient>',
        ro: { top: 0.07, ao: 0.14, board: `<rect y="${f1(BB + 0.3)}" width="80" height="0.4" fill="#b4c4b0" opacity="0.8"/><rect y="${f1(BB + 1.2)}" width="80" height="0.2" fill="#5e7262"/>` } }; });

    // BED-061 PADDED VELVET ACOUSTIC HEADBOARD WALL & WALNUT PANELING (T4): book-matched American walnut veneer panels across the top (mirrored
    // cathedral figure, a dark mineral streak, satin oil finish, a warm wash of cove light), a slim brushed-brass reveal, then floor-height channel-tufted
    // olive velvet: every channel a padded roll with the velvet's silvery edge sheen and deep crown, stitched seams and soft crush marks in the pile;
    // a walnut plinth with a brass edge. Live: sheen rolls across the velvet channels and a glint slides along the brass.
    const wVel = memo('d61', () => { const R = rng('wv61'), WT = 15.4, RV = 0.8, Y0 = WT + RV, CW = 5;
      // walnut field (full height, so the side walls can repeat it): each panel its own leaf, book-matched about its centre
      const H = 56;
      const leafW = i => { const Q = rng('wv61l' + i); let h = `<rect width="10" height="${H}" fill="url(#d61w)"/><rect width="10" height="${H}" fill="${['#7a4e34', '#4e2e1c', '#6a4028', '#5a3420'][i]}" opacity="0.25"/>`;
        for (let k = 0; k < 10; k++) { const x = 9.7 - k * 0.5 + (Q() - 0.5) * 0.25, ph = Q() * 6; let d = `M${f1(x)} 0`; for (let y = 3; y <= H; y += 3) d += `L${f1(x + Math.sin(y * 0.17 + ph) * 0.22)} ${y}`;
          h += `<path d="${d}" stroke="${Q() < 0.65 ? '#3a2214' : '#9a6c46'}" stroke-width="${f1(0.08 + Q() * 0.14)}" fill="none" opacity="${f1(0.22 + Q() * 0.22)}"/>`; }
        const cx = 2.6 + Q() * 2.2, n = 5 + Math.floor(Q() * 3), lean = (Q() - 0.5) * 1.2;
        for (let k = 0; k < n; k++) { const hk = 0.6 + k * (0.55 + Q() * 0.12), yk = WT - 3 - k * (1.5 + Q() * 0.5) - Q() * 0.6, ax = cx + lean * (k / n), w1 = (Q() - 0.5) * 0.5;
          const d = `M${f1(cx - hk)} ${H}V${f1(WT + 2)}C${f1(cx - hk + w1)} ${f1(yk + (WT - yk) * 0.5)} ${f1(ax - hk * 0.38)} ${f1(yk + 0.5)} ${f1(ax)} ${f1(yk)}C${f1(ax + hk * 0.38)} ${f1(yk + 0.5)} ${f1(cx + hk - w1)} ${f1(yk + (WT - yk) * 0.5)} ${f1(cx + hk)} ${f1(WT + 2)}V${H}`;
          h += `<path d="${d}" stroke="#2e1a0e" stroke-width="${f1(0.1 + Q() * 0.12)}" fill="none" opacity="${f1(0.28 + Q() * 0.2)}"/>`
            + (k % 2 ? `<path d="${d}" stroke="#b07e52" stroke-width="0.36" fill="none" opacity="0.12" transform="translate(0.26 0.3)"/>` : ''); }
        if (i === 2) h += '<path d="M7.2 0Q7.6 6 7 11Q6.6 13.4 7.4 15.4V56" stroke="#24140a" stroke-width="0.5" fill="none" opacity="0.25" filter="url(#wb1)"/>';
        h += stip(Q, 120, 0, H, '#c8986a', '#24140a', 0.08, 0.14).replace(/<circle/g, '<circle transform="scale(0.125 1)"');
        return h; };
      let wal = '';
      for (let i = 0; i < 4; i++) { const x0 = i * 20, lf = leafW(i); wal += `<g transform="translate(${x0} 0)">${lf}</g><g transform="translate(${x0 + 20} 0) scale(-1 1)">${lf}</g>`
        + `<rect x="${f1(x0 - 0.1)}" width="0.2" height="${H}" fill="#1a0e06" opacity="0.7"/><rect x="${f1(x0 + 0.1)}" width="0.12" height="${H}" fill="#b8865a" opacity="0.35"/>`; }
      wal += '<rect width="80" height="56" fill="url(#d61f)"/><rect width="80" height="10" fill="url(#d61c)"/>';
      wal += '<g filter="url(#wb2)"><path d="M18 0L24 0L20 56L14 56Z M58 0L61 0L57 56L54 56Z" fill="#ffe2b8" opacity="0.1"/></g>';
      let s = wal;
      // brass reveal
      s += `<rect y="${f1(WT - 0.2)}" width="80" height="${f1(RV + 0.4)}" fill="#1a1008"/><rect y="${f1(WT)}" width="80" height="${RV}" fill="url(#d61b)"/><rect y="${f1(WT + 0.08)}" width="80" height="0.12" fill="#fff4d0" opacity="0.7"/>`
        + `<rect x="-6" y="${f1(WT)}" width="5" height="${RV}" fill="url(#d61g)">${an('x', '-6;86;86', 11, -3, KT('0;0.6;1'))}</rect>`;
      // velvet channels
      let v = `<rect y="${f1(Y0)}" width="80" height="${f1(BB - Y0)}" fill="#1c2212"/>`;
      for (let i = 0; i < 80 / CW; i++) { const x = i * CW;
        v += `<rect x="${f1(x + 0.18)}" y="${f1(Y0 + 0.2)}" width="${f1(CW - 0.36)}" height="${f1(BB - Y0 - 0.3)}" rx="1.6" fill="url(#d61v)"/>`
          + `<rect x="${f1(x + 0.18)}" y="${f1(Y0 + 0.2)}" width="${f1(CW - 0.36)}" height="${f1(BB - Y0 - 0.3)}" rx="1.6" fill="url(#d61e)"/>`
          + `<path d="M${f1(x + CW)} ${f1(Y0 + 1)}V${f1(BB - 0.6)}" stroke="#0e1208" stroke-width="0.28"/><path d="M${f1(x + CW - 0.35)} ${f1(Y0 + 1.6)}V${f1(BB - 1.2)}" stroke="#6e7a50" stroke-width="0.07" stroke-dasharray="0.3 0.25" opacity="0.55"/>`; }
      // pile texture + crush marks
      v += rep(700, () => `<circle cx="${f1(R() * 80)}" cy="${f1(Y0 + R() * (BB - Y0))}" r="${f1(0.04 + R() * 0.05)}" fill="${R() < 0.5 ? '#8e9a6a' : '#141a0c'}" opacity="${f1(0.15 + R() * 0.2)}"/>`).join('');
      v += '<g filter="url(#wb2)"><ellipse cx="22.4" cy="40" rx="1.4" ry="3.6" fill="#a4ae82" opacity="0.16"/><ellipse cx="61.6" cy="30" rx="1.1" ry="2.6" fill="#a4ae82" opacity="0.13"/><ellipse cx="47.6" cy="47" rx="1.2" ry="2" fill="#0e1208" opacity="0.18"/></g>';
      // sheen rolling across + warm downlight on the top of the channels
      v += `<rect x="-24" y="${f1(Y0)}" width="18" height="${f1(BB - Y0)}" fill="url(#d61s)" transform="skewX(-8)">${an('x', '-24;104', 15, 0, SPL(1))}</rect>`;
      v += `<rect y="${f1(Y0)}" width="80" height="7" fill="url(#d61d)"/>`;
      s += `<g clip-path="url(#d61k)">${v}</g>`;
      s += `<rect y="${f1(Y0)}" width="80" height="1" fill="#000" opacity="0.3" filter="url(#wb1)"/><rect y="${f1(BB - 1.2)}" width="80" height="1.2" fill="#000" opacity="0.22" filter="url(#wb1)"/>`;
      const board = '#3e2818';
      return { mat: s, sup: wal, board,
        defs: `<clipPath id="d61k"><rect y="${f1(Y0)}" width="80" height="${f1(BB - Y0)}"/></clipPath>`
          + '<linearGradient id="d61w" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6e4630"/><stop offset="0.35" stop-color="#5e3a26"/><stop offset="0.7" stop-color="#674130"/><stop offset="1" stop-color="#58361f"/></linearGradient>'
          + '<linearGradient id="d61f" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd8a8" stop-opacity="0.08"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#1a0e06" stop-opacity="0.12"/></linearGradient>'
          + '<linearGradient id="d61c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffcf8a" stop-opacity="0.22"/><stop offset="1" stop-color="#ffcf8a" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="d61b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f4dca0"/><stop offset="0.45" stop-color="#c8a060"/><stop offset="1" stop-color="#7a5a2a"/></linearGradient>'
          + '<linearGradient id="d61g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff8e0" stop-opacity="0"/><stop offset="0.5" stop-color="#fff8e0" stop-opacity="0.95"/><stop offset="1" stop-color="#fff8e0" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="d61v" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#26301a"/><stop offset="0.12" stop-color="#76825a"/><stop offset="0.3" stop-color="#4c5834"/><stop offset="0.55" stop-color="#3a4628"/><stop offset="0.8" stop-color="#4a5632"/><stop offset="0.93" stop-color="#5e6a44"/><stop offset="1" stop-color="#1c2412"/></linearGradient>'
          + '<linearGradient id="d61e" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0e1208" stop-opacity="0.5"/><stop offset="0.05" stop-color="#0e1208" stop-opacity="0"/><stop offset="0.95" stop-color="#0e1208" stop-opacity="0"/><stop offset="1" stop-color="#0e1208" stop-opacity="0.5"/></linearGradient>'
          + '<linearGradient id="d61s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#e8f0c8" stop-opacity="0"/><stop offset="0.5" stop-color="#e8f0c8" stop-opacity="0.14"/><stop offset="1" stop-color="#e8f0c8" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="d61d" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd49a" stop-opacity="0.2"/><stop offset="1" stop-color="#ffd49a" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.04, ao: 0.2, board: `<rect y="${BB}" width="80" height="0.35" fill="#d8b878"/><rect y="${f1(BB + 0.05)}" width="80" height="0.1" fill="#fff0c8" opacity="0.7"/>`
          + rep(14, () => `<rect x="${f1(R() * 80)}" y="${f1(BB + 0.4)}" width="${f1(2 + R() * 6)}" height="0.08" fill="#1e1208" opacity="0.5"/>`).join('') } }; });

    // BED-081 SOUNDPROOF SILK-WOVEN & STARLIGHT-PROJECTING SMART WALLS (T5): floor-to-ceiling pillowed acoustic panels upholstered in hand-woven shot
    // silk (midnight indigo warp, plum weft) with visible slubs and a moving moire sheen, joined by champagne-gold pin trims; a hidden cove washes warm
    // light down the top, a warm amber reveal glows along the skirting. Projected onto the silk: a warm starfield and a soft milky-way band.
    // Live: the projected sky drifts slowly across, stars twinkle and now and then a shooting star crosses.
    const wSilk = memo('d81', () => { const R = rng('ws81'), PW = 40;
      let silk = '<rect width="80" height="56" fill="url(#d81a)"/>';
      silk += rep(140, i => `<rect y="${f1(i * 0.4)}" width="80" height="0.16" fill="${i % 2 ? '#8a7aa8' : '#0c0c1e'}" opacity="${f1(0.06 + R() * 0.06)}"/>`).join('')
        + rep(90, () => `<rect x="${f1(R() * 80)}" width="0.08" height="56" fill="#6a6a9a" opacity="0.08"/>`).join('')
        + rep(70, () => `<rect x="${f1(R() * 80)}" y="${f1(R() * 56)}" width="${f1(1 + R() * 3.4)}" height="${f1(0.14 + R() * 0.12)}" rx="0.08" fill="${R() < 0.6 ? '#9a88b8' : '#1a1430'}" opacity="${f1(0.18 + R() * 0.2)}"/>`).join('');
      silk += `<rect width="80" height="56" fill="url(#d81m)"><animate attributeName="x" values="-20;0;-20" dur="22s" repeatCount="indefinite" ${SPL(2)}/></rect>`;
      // pillowed panels: soft dark edges, a highlight on the upper left of each pillow
      for (let i = 0; i < 2; i++) { const x = i * PW; silk += `<rect x="${x}" width="${PW}" height="56" fill="url(#d81p)"/><rect x="${x}" width="${PW}" height="56" fill="url(#d81q)"/>`; }
      // projected sky: two copies side by side, sliding one tile-width per loop
      let sky = '';
      const SC = ['#fff6e0', '#fff0d0', '#f6dca8', '#ffe8d8', '#f8d4c8'];
      rep(80, () => { const x = R() * 80, y = 1 + R() * 51, r = 0.06 + Math.pow(R(), 3) * 0.32, c = SC[Math.floor(R() * SC.length)], T = 2.5 + R() * 6, o = 0.5 + R() * 0.5;
        sky += (r > 0.2 ? `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r * 4)}" fill="${c}" opacity="0.18" filter="url(#wb1)"/>` : '')
          + `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="${c}" opacity="${f1(o)}">${an('opacity', `${f1(o)};${f1(o * 0.25)};${f1(o)}`, T, -R() * T, SPL(2))}</circle>`
          + (r > 0.26 ? `<path d="M${f1(x - r * 5)} ${f1(y)}H${f1(x + r * 5)}M${f1(x)} ${f1(y - r * 5)}V${f1(y + r * 5)}" stroke="${c}" stroke-width="0.07" opacity="0.6"/>` : ''); });
      // milky-way band: haze + dense dust
      sky += '<g filter="url(#wb2)"><path d="M-4 40Q20 30 42 22Q62 15 84 6L86 12Q62 22 44 29Q22 37 -4 47Z" fill="#f4d8b0" opacity="0.08"/><path d="M-4 42Q22 32 44 25Q64 18 84 9" stroke="#ffe8c8" stroke-width="1.6" opacity="0.08" fill="none"/></g>';
      rep(170, () => { const t = R(), x = -4 + t * 88, y = 43 - t * 34 + (R() - 0.5) * 7 * (0.5 + R()); sky += `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(0.04 + R() * 0.06)}" fill="#fff0d8" opacity="${f1(0.25 + R() * 0.4)}"/>`; });
      let s = silk + `<g clip-path="url(#d81c)"><g><g>${sky}</g><g transform="translate(80 0)">${sky}</g>${at('translate', '0 0;-80 0', 140)}</g>`;
      // shooting star
      s += `<g opacity="0"><path d="M0 0L-7 2.6" stroke="url(#d81t)" stroke-width="0.24" stroke-linecap="round"/><circle r="0.24" fill="#fff8ec"/>${at('translate', '58 6;58 6;30 17;30 17', 17, 0, KT('0;0.62;0.7;1'))}${an('opacity', '0;0;1;0;0', 17, 0, KT('0;0.62;0.66;0.7;1'))}</g></g>`;
      // champagne-gold pin trims at the panel joints
      [0, 40, 80].forEach(x => s += `<rect x="${f1(x - 0.45)}" width="0.9" height="56" fill="#0a0814" opacity="0.6" filter="url(#wb1)"/><rect x="${f1(x - 0.22)}" width="0.44" height="56" fill="url(#d81g)"/><rect x="${f1(x - 0.06)}" width="0.1" height="56" fill="#fff4d8" opacity="0.6"/>`);
      // warm cove wash at the top + amber reveal glow at the bottom
      s += '<rect width="80" height="12" fill="url(#d81w)"/><rect width="80" height="0.8" fill="#0a0814"/><rect y="0.8" width="80" height="0.15" fill="#ffd89a" opacity="0.7"/>';
      s += `<rect y="${f1(BB - 7)}" width="80" height="7" fill="url(#d81r)"><animate attributeName="opacity" values="0.85;1;0.85" dur="7s" repeatCount="indefinite" ${SPL(2)}/></rect><rect y="${f1(BB - 0.5)}" width="80" height="0.5" fill="#ffc070"/><rect y="${f1(BB - 0.4)}" width="80" height="0.15" fill="#fff0c8"/>`;
      const board = '#2a2234';
      return { mat: s, sup: s, board,
        defs: '<clipPath id="d81c"><rect width="80" height="56"/></clipPath>'
          + '<linearGradient id="d81a" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2c2a52"/><stop offset="0.45" stop-color="#262246"/><stop offset="0.75" stop-color="#34264a"/><stop offset="1" stop-color="#2a1e3e"/></linearGradient>'
          + '<linearGradient id="d81m" x1="0" y1="0" x2="20" y2="7" gradientUnits="userSpaceOnUse" spreadMethod="reflect"><stop offset="0" stop-color="#b4a0d8" stop-opacity="0"/><stop offset="0.5" stop-color="#b4a0d8" stop-opacity="0.07"/><stop offset="1" stop-color="#b4a0d8" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="d81p" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#05040e" stop-opacity="0.55"/><stop offset="0.07" stop-color="#05040e" stop-opacity="0"/><stop offset="0.93" stop-color="#05040e" stop-opacity="0"/><stop offset="1" stop-color="#05040e" stop-opacity="0.55"/></linearGradient>'
          + '<radialGradient id="d81q" cx="0.35" cy="0.3" r="0.75"><stop offset="0" stop-color="#c8b8e8" stop-opacity="0.1"/><stop offset="1" stop-color="#c8b8e8" stop-opacity="0"/></radialGradient>'
          + '<linearGradient id="d81g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8a6a3a"/><stop offset="0.5" stop-color="#ecd29a"/><stop offset="1" stop-color="#8a6a3a"/></linearGradient>'
          + '<linearGradient id="d81t" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff4dc" stop-opacity="0.9"/><stop offset="1" stop-color="#fff4dc" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="d81w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffc88a" stop-opacity="0.26"/><stop offset="1" stop-color="#ffc88a" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="d81r" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffb060" stop-opacity="0.32"/><stop offset="1" stop-color="#ffb060" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.03, ao: 0.16, board: `<rect y="${f1(BB + 0.2)}" width="80" height="0.3" fill="#d8bc84" opacity="0.8"/><rect y="${f1(BB + 0.5)}" width="80" height="1.6" fill="#ffb060" opacity="0.08"/>` } }; });

    Object.assign(SURF12, { bd01dry: wDry, bd21lav: wLav, bd41chin: wChin, bd61vel: wVel, bd81silk: wSilk });
  }

  // ======================= WALL HANGINGS (BED-004/024/044/064/084): wall pieces like the plus29 mirrors (box3 + face decals, cyl3, WD planes); footprints + elev kept =======================
  { const { box3, cyl3 } = RD.H15, { WD } = RD.H12, { ext } = RD.H11, DEF19 = RD.H19.DEF19;
    const shW = (C, x, y, w, h, rx, op, z) => WD(C, x + 1, y - 1.4, z || 0.04, `<rect width="${f1(w)}" height="${f1(h)}" rx="${rx || 0.6}" fill="#2a2018" opacity="${op || 0.3}" filter="url(#m10b1)"/>`);
    // wonky hand-cut 5-point star (svg coords)
    const starP = (R, cx, cy, r, rot, jit) => { let d = ''; for (let i = 0; i < 10; i++) { const a = rot + i * PI / 5 - PI / 2, rr = (i % 2 ? r * 0.44 : r) * (1 + (R() - 0.5) * jit); d += (i ? 'L' : 'M') + f1(cx + Math.cos(a) * rr) + ' ' + f1(cy + Math.sin(a) * rr); } return d + 'Z'; };
    const tape = (x, y, w, h, rot, mask) => `<g transform="rotate(${f1(rot)} ${f1(x)} ${f1(y)})">` + (mask
      ? `<path d="M${f1(x - w / 2)} ${f1(y - h / 2)}h${f1(w)}l-0.2 ${f1(h * 0.25)}l0.2 ${f1(h * 0.25)}l-0.2 ${f1(h * 0.25)}l0.2 ${f1(h * 0.25)}h${f1(-w)}l0.2 ${f1(-h * 0.25)}l-0.2 ${f1(-h * 0.25)}l0.2 ${f1(-h * 0.25)}Z" fill="#e6d6ae" opacity="0.94"/><rect x="${f1(x - w / 2)}" y="${f1(y - h / 2)}" width="${f1(w)}" height="0.14" fill="#ffffff" opacity="0.5"/>`
      : `<rect x="${f1(x - w / 2)}" y="${f1(y - h / 2)}" width="${f1(w)}" height="${f1(h)}" fill="#efe2a8" opacity="0.42"/><rect x="${f1(x - w / 2)}" y="${f1(y - h / 2)}" width="${f1(w)}" height="${f1(h)}" fill="none" stroke="#ffffff" stroke-width="0.1" opacity="0.6"/><rect x="${f1(x - w / 2 + 0.3)}" y="${f1(y - h / 2 + 0.2)}" width="${f1(w * 0.4)}" height="0.16" fill="#ffffff" opacity="0.5"/>`) + '</g>';

    // BED-004 PAPER STAR CUTOUTS TAPED ABOVE BED (T1): a kid-made night sky: wonky hand-cut stars in yellow construction paper (scissor nicks, pencil lines
    // still showing), two in crinkled kitchen foil, one crayon-coloured and one with dried glitter glue, a crescent moon cut from a cereal box and painted
    // yellow (printed cardboard showing at a torn edge), all stuck up with yellowed clear tape and masking tape; a few glow-in-the-dark plastic stickers
    // in between, a torn tape scrap where a star fell and a faint pencil arc. Live: one star hanging by a single corner of tape swings in the draught,
    // and the glow stickers glow softly.
    N.hang30a = S => { const D = { w: 76, d: 8, mount: 'wall', elev: 36, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('hang30a'), id = C.u('h04'), X0 = -34, Y0 = 34, W = 68, Hh = 34;
        ext(C, [[X0, Y0 + 1, 0], [X0 + W, -2, 0], [X0 + W, -2, 1.2]]);
        let sh = '', p = '', top = '';
        // pencil arc guide
        p += `<path d="M4 25Q34 -2 64 22" stroke="#7a7468" stroke-width="0.12" fill="none" opacity="0.2" stroke-dasharray="2.4 1.2"/>`;
        // cereal-box moon
        const mx = 9, my = 9, moon = `M${mx} ${my - 7.4}A7.4 7.4 0 1 0 ${mx + 5.6} ${my + 4.8}A5.8 5.8 0 1 1 ${mx} ${my - 7.4}Z`;
        sh += `<path d="${moon}" fill="#000" transform="translate(0.7 0.9)"/>`;
        p += `<clipPath id="${id}m"><path d="${moon}"/></clipPath><path d="${moon}" fill="#c8a868"/><path d="${moon}" fill="#f2cc3c" transform="translate(0.15 0.1) scale(0.985)"/><g clip-path="url(#${id}m)">`
          + rep(14, () => `<path d="M${f1(mx - 5 + R() * 6)} ${f1(my - 5 + R() * 10)}l${f1(1 + R() * 2)} ${f1((R() - 0.5) * 0.6)}" stroke="${R() < 0.5 ? '#ffe070' : '#d8a828'}" stroke-width="0.3" opacity="0.6"/>`).join('') + '</g>'
          + `<path d="M${mx - 6.9} ${my + 2.6}l0.9 0.4l0.5 -0.6l0.6 0.9l-1.2 0.9Z" fill="#d84a3a"/><path d="M${mx - 6.6} ${my + 3.1}l0.6 0.2" stroke="#ffffff" stroke-width="0.25"/><path d="M${mx - 7.2} ${my + 2.4}l0.8 0.9l0.4 -0.3" stroke="#a89878" stroke-width="0.12" fill="none"/>`
          + `<circle cx="${mx - 4.6}" cy="${my - 1.4}" r="0.4" fill="#2a2a2a"/><path d="M${mx - 5.8} ${my + 1.8}q1.1 0.9 2 0" stroke="#2a2a2a" stroke-width="0.22" fill="none" stroke-linecap="round"/>`;
        top += tape(mx - 1, my - 7.2, 3.6, 1.4, -12, 1) + tape(mx + 4.6, my + 4.2, 3, 1.2, 30, 0);
        // stars: [x, y, r, kind, rot]  kind 0 yellow paper, 1 foil, 2 crayon, 3 glitter
        const ST = [[22, 6, 3.4, 0, 0.1], [31, 3.4, 2.4, 1, -0.2], [41, 6.4, 3.8, 0, 0.3], [52, 4.2, 2.6, 2, 0.1], [61, 10, 3.2, 0, -0.15], [17, 15, 2.2, 0, 0.4], [28, 13.6, 3, 3, -0.1],
          [47, 15.4, 2.6, 1, 0.25], [57, 20, 2.2, 0, 0.05], [8, 24, 2.6, 0, 0.2], [36, 21.6, 2.4, 0, -0.3], [23, 26, 2, 2, 0.15]];
        ST.forEach(([x, y, r, k, rot], i) => { const d = starP(R, x, y, r, rot, 0.28);
          sh += `<path d="${d}" fill="#000" transform="translate(0.5 0.7)"/>`;
          if (k === 1) p += `<path d="${d}" fill="url(#${id}f)"/>` + rep(7, () => `<path d="M${f1(x + (R() - 0.5) * r * 1.2)} ${f1(y + (R() - 0.5) * r * 1.2)}l${f1((R() - 0.5) * 1.6)} ${f1((R() - 0.5) * 1.6)}" stroke="${R() < 0.5 ? '#ffffff' : '#6a6e74'}" stroke-width="0.12" opacity="0.8"/>`).join('');
          else if (k === 2) p += `<clipPath id="${id}s${i}"><path d="${d}"/></clipPath><path d="${d}" fill="#f4eee0"/><g clip-path="url(#${id}s${i})">` + rep(9, j => `<path d="M${f1(x - r * 0.7)} ${f1(y - r * 0.6 + j * r * 0.16)}l${f1(r * 1.4)} ${f1(-0.4 + R() * 0.8)}" stroke="${j % 3 ? '#f4a43a' : '#e86a8a'}" stroke-width="0.36" opacity="0.75"/>`).join('') + `</g><path d="${d}" fill="none" stroke="#e8902a" stroke-width="0.25"/>`;
          else { p += `<path d="${d}" fill="${['#f2c43a', '#f4cc48', '#eebc30'][i % 3]}"/><path d="${d}" fill="none" stroke="#c89a20" stroke-width="0.1"/>`
            + rep(5, () => `<path d="M${f1(x + (R() - 0.5) * r)} ${f1(y + (R() - 0.5) * r)}l${f1(R() * 1.2)} ${f1((R() - 0.5) * 0.3)}" stroke="#d8a828" stroke-width="0.08" opacity="0.6"/>`).join('');
            if (R() < 0.5) p += `<path d="M${f1(x - r * 0.9)} ${f1(y - r * 0.3)}l${f1(r * 0.6)} ${f1(r * 0.25)}" stroke="#7a7468" stroke-width="0.1" opacity="0.5"/>`;
            if (k === 3) p += rep(26, () => `<circle cx="${f1(x + (R() - 0.5) * r)}" cy="${f1(y + (R() - 0.5) * r)}" r="${f1(0.08 + R() * 0.12)}" fill="${['#e84a8a', '#8a4ae8', '#ffffff', '#4ab8e8'][Math.floor(R() * 4)]}"/>`).join('') + `<ellipse cx="${f1(x + 0.4)}" cy="${f1(y + 0.6)}" rx="0.9" ry="0.6" fill="#ffffff" opacity="0.35"/>`; }
          // curled corner on a few
          if (i % 4 === 1) p += `<path d="M${f1(x + r * 0.15)} ${f1(y - r * 0.95)}l${f1(r * 0.45)} ${f1(r * 0.35)}l${f1(-r * 0.15)} ${f1(r * 0.2)}Z" fill="#fff4c8" opacity="0.7"/>`;
          top += tape(x + (R() - 0.5) * r * 0.6, y - r * 0.55, 1.6 + r * 0.4, 1.1, (R() - 0.5) * 40, R() < 0.35); });
        // glow-in-the-dark stickers
        const GL = [[13, 3.4, 1.1], [35.4, 10.4, 0.9], [44, 25.4, 1.2], [64.6, 3.4, 1], [6, 17.4, 0.8], [53.4, 26, 0.9], [29, 30.4, 1]];
        let glow = '';
        GL.forEach(([x, y, r], i) => { const d = starP(rng('g' + i), x, y, r, i, 0.02);
          glow += `<path d="${d}" fill="#d6f0b4" opacity="0.5" filter="url(#m12b1)">${an('opacity', '0.15;0.55;0.15', 5 + i % 3, -i * 1.3, SPL(2))}</path>`;
          p += `<path d="${d}" fill="#e6efd2"/><path d="${d}" fill="none" stroke="#c4d0ac" stroke-width="0.1"/>`; });
        // torn tape scrap where a star fell + pin hole
        top += tape(46, 31, 2, 1, 14, 0) + '<path d="M45.4 30.6l1 0.4l0.4 0.8" stroke="#f2c43a" stroke-width="0.3" fill="none"/>';
        // swinging star (hangs from one corner of tape)
        const sx = 63.6, sy = 26.4, sd = starP(R, sx + 0.9, sy + 2.6, 2.8, 0.35, 0.25);
        const swing = `<g>${at('rotate', `-4 ${sx} ${sy};9 ${sx} ${sy};-4 ${sx} ${sy}`, 5.5, 0, SPL(2))}<path d="${sd}" fill="#000" opacity="0.18" filter="url(#m12b1)" transform="translate(0.9 1.2)"/><path d="${sd}" fill="#f4cc48"/><path d="${sd}" fill="none" stroke="#c89a20" stroke-width="0.1"/><path d="M${sx} ${sy}l1.6 2.4" stroke="#d8a828" stroke-width="0.12" opacity="0.6"/></g>`;
        top += tape(sx, sy - 0.2, 2.2, 1.1, -20, 0);
        let s = WD(C, X0, Y0, 0.03, `<g filter="url(#m12b1)" opacity="0.22">${sh}</g>`) + WD(C, X0, Y0, 0.08, glow + p) + WD(C, X0, Y0, 0.5, swing) + WD(C, X0, Y0, 0.14, top);
        return { defs: DEF19 + `<defs><linearGradient id="${id}f" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f6f8"/><stop offset="0.3" stop-color="#9aa0a8"/><stop offset="0.5" stop-color="#e8ecf0"/><stop offset="0.75" stop-color="#8a9098"/><stop offset="1" stop-color="#d8dce0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-024 MACRAME WOVEN WALL HANGING & FAIRY LIGHTS (T2): natural cotton cord macrame on a pale driftwood dowel hung from a nail by a cord loop:
    // lark's head knots over the dowel, a band of square knots, an alternating square-knot net opening into a V, a big double-half-hitch diamond with
    // a gathering knot, spiral twists down both sides and a long brushed-out fringe cut in a V; copper-wire fairy lights draped in swags from push pins
    // either side, ending in a little battery box. Live: the lights twinkle in a slow wave, casting warm spots on the wall, and the fringe sways.
    N.hang30b = S => { const D = { w: 110, d: 8, mount: 'wall', elev: 44, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('hang30b'), id = C.u('h24'), MW = 30, DY = 40, NC = 16;
        ext(C, [[-50, 50, 0], [50, -12, 0], [50, -12, 3.6]]);
        // fairy lights: swags between pins (world coords, y up)
        const PIN = [[-49, 30], [-36, 41], [-17, 46.4], [17, 46.4], [36, 41], [49, 28]], SAG = [6, 5, 4.4, 5, 6];
        let wire = '', bulbs = '', spots = '', pins = '', bi = 0;
        const sx = x => f1(x + 50), sy = y => f1(52 - y);
        for (let i = 0; i < PIN.length - 1; i++) { const [a, b] = [PIN[i], PIN[i + 1]], mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2 - SAG[i] * 2;
          wire += `<path d="M${sx(a[0])} ${sy(a[1])}Q${sx(mx)} ${sy(my)} ${sx(b[0])} ${sy(b[1])}" stroke="#a8683a" stroke-width="0.22" fill="none"/>`;
          for (let t = 0.1; t < 0.95; t += 0.16) { const x = (1 - t) * (1 - t) * a[0] + 2 * t * (1 - t) * mx + t * t * b[0], y = (1 - t) * (1 - t) * a[1] + 2 * t * (1 - t) * my + t * t * b[1], T = 3.6, ph = -(bi * 0.45) % T; bi++;
            spots += `<circle cx="${sx(x)}" cy="${f1(52 - y + 0.6)}" r="2.6" fill="#ffc870" opacity="0.2">${an('opacity', '0.08;0.26;0.08', T, ph, SPL(2))}</circle>`;
            bulbs += `<g transform="translate(${sx(x)} ${sy(y)})"><path d="M0 -0.3v0.5" stroke="#a8683a" stroke-width="0.16"/><ellipse cy="0.55" rx="0.42" ry="0.6" fill="#ffe2a0"/><ellipse cy="0.55" rx="0.42" ry="0.6" fill="#fff6d8" opacity="0.6">${an('opacity', '0.25;1;0.25', T, ph, SPL(2))}</ellipse><ellipse cx="-0.12" cy="0.4" rx="0.12" ry="0.2" fill="#ffffff" opacity="0.8"/></g>`; } }
        PIN.forEach(([x, y], i) => pins += `<circle cx="${sx(x)}" cy="${sy(y)}" r="0.65" fill="${['#e84a5a', '#f2c040', '#4a9ae8'][i % 3]}"/><circle cx="${f1(+sx(x) - 0.2)}" cy="${f1(+sy(y) - 0.22)}" r="0.22" fill="#ffffff" opacity="0.7"/>`);
        // tail down to a battery box at the left
        wire += `<path d="M${sx(-49)} ${sy(30)}Q${sx(-51)} ${sy(18)} ${sx(-48.6)} ${sy(6)}" stroke="#a8683a" stroke-width="0.22" fill="none"/>`;
        pins += `<g transform="translate(${sx(-50.4)} ${sy(6)})"><rect width="3.6" height="5.4" rx="0.5" fill="#f4f2ec" stroke="#b8b4a8" stroke-width="0.12"/><rect x="1" y="1" width="1.6" height="0.8" rx="0.2" fill="#3a3a3a"/><circle cx="1.8" cy="3.4" r="0.3" fill="#7ad86a"/></g>`;
        let s = WD(C, -50, 52, 0.04, `<g filter="url(#m10b2)">${spots}</g>`);
        // hanging cord loop + nail
        s += WD(C, -16, 51, 0.6, `<path d="M1 11.2L16 2.2L31 11.2" stroke="#d8ccb2" stroke-width="0.5" fill="none"/><path d="M1 11.2L16 2.2L31 11.2" stroke="#f4eee0" stroke-width="0.2" fill="none" transform="translate(-0.1 -0.1)"/><circle cx="16" cy="2" r="0.6" fill="#6a6a66"/><circle cx="15.8" cy="1.8" r="0.2" fill="#c8c8c4"/>`);
        // macrame body (svg coords: x 0..MW, y 0 at dowel)
        const cx = i => 1.1 + i * (MW - 2.2) / (NC - 1);
        const knot = (x, y, w, h, rot) => `<g transform="rotate(${f1(rot || 0)} ${f1(x)} ${f1(y)})"><ellipse cx="${f1(x + 0.15)}" cy="${f1(y + 0.35)}" rx="${f1(w / 2)}" ry="${f1(h / 2)}" fill="#5a4a34" opacity="0.35"/><ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(w / 2)}" ry="${f1(h / 2)}" fill="url(#${id}k)"/><path d="M${f1(x - w * 0.3)} ${f1(y - h * 0.1)}q${f1(w * 0.3)} ${f1(-h * 0.3)} ${f1(w * 0.6)} 0" stroke="#fffaf0" stroke-width="0.14" fill="none" opacity="0.8"/><path d="M${f1(x)} ${f1(y - h / 2)}v${f1(h)}" stroke="#b8a888" stroke-width="0.08" opacity="0.6"/></g>`;
        let m = '';
        // cords (background)
        for (let i = 0; i < NC; i++) { const x = cx(i); let d = `M${f1(x)} 0`; for (let y = 2; y <= 37; y += 2) d += `L${f1(x + Math.sin(y * 0.8 + i) * 0.12)} ${y}`;
          m += `<path d="${d}" stroke="#bcae92" stroke-width="0.62" fill="none"/><path d="${d}" stroke="#f2ebdc" stroke-width="0.3" fill="none" transform="translate(-0.1 0)"/>`; }
        // lark's heads over the dowel
        for (let i = 0; i < NC; i += 2) m += knot((cx(i) + cx(i + 1)) / 2, 0.2, 1.9, 1.5);
        // band of square knots
        for (let g = 0; g < 4; g++) { const x = (cx(g * 4) + cx(g * 4 + 3)) / 2; m += knot(x, 3.6, 3.3, 1.3) + knot(x, 5.1, 3.3, 1.3); }
        // alternating net opening into a V
        for (let k = 0; k < 4; k++) { const off = k % 2 ? 2 : 0; for (let g = 0; g * 4 + off + 3 < NC; g++) { const a = g * 4 + off, x = (cx(a) + cx(a + 3)) / 2; m += knot(x, 7.6 + k * 2.3, 3, 1.15); } }
        // double-half-hitch diamond + gathering knot + spiral sinnets
        const dm = [[MW / 2, 19.4], [4.6, 27.4], [MW / 2, 35.4], [MW - 4.6, 27.4]];
        for (let e = 0; e < 4; e++) { const [a, b] = [dm[e], dm[(e + 1) % 4]], n = 9, ang = Math.atan2(b[1] - a[1], b[0] - a[0]) * 180 / PI; for (let j = 0; j < n; j++) { const t = (j + 0.5) / n; m += knot(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, 1.5, 0.95, ang); } }
        m += knot(MW / 2, 27.4, 3.6, 2.8) + knot(MW / 2, 25.6, 2.6, 0.9) + knot(MW / 2, 29.2, 2.6, 0.9);
        [1.8, MW - 1.8].forEach(x => { for (let j = 0; j < 9; j++) m += knot(x + (j % 2 ? 0.25 : -0.25), 19.6 + j * 1.6, 2.4, 1.15, j % 2 ? 22 : -22); });
        // bottom square-knot row, then the fringe
        for (let g = 0; g < 4; g++) { const x = (cx(g * 4) + cx(g * 4 + 3)) / 2; m += knot(x, 37.4, 3.3, 1.3); }
        let fr = '';
        for (let i = 0; i < NC; i++) { const x = cx(i), L = 5 + Math.abs(x - MW / 2) * 0.55 + R() * 0.6, y1 = 38 + L;
          fr += `<path d="M${f1(x)} 38Q${f1(x + 0.2)} ${f1(38 + L * 0.5)} ${f1(x + (R() - 0.5) * 0.6)} ${f1(y1 - L * 0.35)}" stroke="#c4b69a" stroke-width="0.6" fill="none"/><path d="M${f1(x)} 38V${f1(y1 - L * 0.35)}" stroke="#f2ebdc" stroke-width="0.28" fill="none" transform="translate(-0.1 0)"/>`;
          rep(4, () => fr += `<path d="M${f1(x)} ${f1(y1 - L * 0.4)}q${f1((R() - 0.5) * 0.8)} ${f1(L * 0.2)} ${f1((R() - 0.5) * 1.4)} ${f1(L * 0.4 + R() * 0.6)}" stroke="#ece2cc" stroke-width="0.14" fill="none" opacity="0.9"/>`); }
        m += `<g>${at('rotate', `-1.4 ${MW / 2} 38;1.4 ${MW / 2} 38;-1.4 ${MW / 2} 38`, 7, 0, SPL(2))}${fr}</g>`;
        s += WD(C, -MW / 2, DY + 0.3, 0.3, `<g filter="url(#m12b1)" opacity="0.2" transform="translate(0.7 1)">${m.replace(/fill="url\(#[^)]*\)"/g, 'fill="#3a2a1a"').replace(/stroke="#[0-9a-f]{6}"/g, 'stroke="#3a2a1a"')}</g>`);
        s += cyl3(C, [-18, DY, 1.4], [18, DY, 1.4], 0.95, '#c8b48e', { n: 12 });
        s += WD(C, -MW / 2, DY + 0.3, 2.5, m);
        s += WD(C, -50, 52, 0.7, wire + bulbs + pins);
        return { defs: DEF19 + `<defs><radialGradient id="${id}k" cx="0.4" cy="0.35" r="0.7"><stop offset="0" stop-color="#fbf6ea"/><stop offset="0.6" stop-color="#e6dcc6"/><stop offset="1" stop-color="#b8a888"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-044 FRAMED PRESSED-FLOWER BOTANICAL GALLERY SET (T3): five slim natural-oak frames hung as a gallery, each with a deep bevel-cut white mat and a
    // pressed specimen on cotton rag paper, faded the way real pressed flowers fade: a big bracken fern frond with a sprig of Queen Anne's lace, a violet
    // pansy, a pink cosmos, a lavender sprig and golden ginkgo leaves, each with a pencilled Latin label; glass with a soft reflection.
    // Live: a glint travels along the gallery from frame to frame.
    N.hang30c = S => { const D = { w: 110, d: 8, mount: 'wall', elev: 44, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('h44'), FD = 1.6;
        ext(C, [[-44, 46, 0], [44, -2, 0], [44, -2, FD + 0.6]]);
        // [cx, bottom, w, h, specimen, label]
        const F = [[-29, 21, 22, 22, 'pansy', 'Viola tricolor'], [-29, 1, 22, 17, 'lav', 'Lavandula'], [0, 1, 32, 42, 'fern', 'Pteridium aquilinum'], [29, 24, 22, 18, 'cosmos', 'Cosmos bipinnatus'], [29, 1, 22, 20, 'ginkgo', 'Ginkgo biloba']];
        const SP = {
          fern: (w, h, R) => { let o = '', d = `M${f1(w * 0.48)} ${f1(h * 0.97)}`; const pts = []; for (let i = 0; i <= 12; i++) { const t = i / 12, x = w * 0.48 + Math.sin(t * 2.2) * w * 0.12, y = h * 0.97 - t * h * 0.9; pts.push([x, y]); d += `L${f1(x)} ${f1(y)}`; }
            for (let i = 1; i < 12; i++) { const [x, y] = pts[i], L = w * 0.38 * (1 - i / 13) + 1, n = 6; [-1, 1].forEach(sd => { let q = `M${f1(x)} ${f1(y)}`; const ex = x + sd * L, ey = y - L * 0.35; q += `Q${f1(x + sd * L * 0.5)} ${f1(y - L * 0.05)} ${f1(ex)} ${f1(ey)}`;
              o += `<path d="${q}" stroke="#7a8a4e" stroke-width="0.18" fill="none"/>`; for (let j = 1; j <= n; j++) { const t = j / (n + 1), px = x + sd * L * t, py = y - L * 0.35 * t * t - L * 0.05 * t, pl = (1 - t) * 1.3 + 0.35;
                o += `<ellipse cx="${f1(px + sd * 0.1)}" cy="${f1(py + pl * 0.55)}" rx="${f1(pl * 0.32)}" ry="${f1(pl * 0.6)}" fill="${R() < 0.75 ? '#8a9a58' : '#a8a05a'}" opacity="0.9" transform="rotate(${f1(sd * -18)} ${f1(px)} ${f1(py + pl * 0.55)})"/><ellipse cx="${f1(px + sd * 0.1)}" cy="${f1(py - pl * 0.45)}" rx="${f1(pl * 0.3)}" ry="${f1(pl * 0.5)}" fill="#96a462" opacity="0.85" transform="rotate(${f1(sd * 18)} ${f1(px)} ${f1(py - pl * 0.45)})"/>`; } }); }
            o = `<path d="${d}" stroke="#6a6a3a" stroke-width="0.45" fill="none"/>` + o;
            // Queen Anne's lace sprig
            const qx = w * 0.78, qy = h * 0.38; o += `<path d="M${f1(w * 0.7)} ${f1(h * 0.97)}Q${f1(w * 0.82)} ${f1(h * 0.66)} ${f1(qx)} ${f1(qy + 2.4)}" stroke="#8a9466" stroke-width="0.22" fill="none"/>`;
            rep(9, k => { const a = -PI / 2 + (k - 4) * 0.28, ex = qx + Math.cos(a) * 2.6, ey = qy + 2.4 + Math.sin(a) * 2.6; o += `<path d="M${f1(qx)} ${f1(qy + 2.4)}L${f1(ex)} ${f1(ey)}" stroke="#9aa478" stroke-width="0.08"/>` + rep(6, () => `<circle cx="${f1(ex + (R() - 0.5) * 1.1)}" cy="${f1(ey + (R() - 0.5) * 0.8)}" r="0.2" fill="#f6f2e4" stroke="#d8d0b8" stroke-width="0.04"/>`).join(''); });
            return o; },
          pansy: (w, h, R) => { const x = w / 2, y = h * 0.42; let o = `<path d="M${f1(x)} ${f1(y + 2)}Q${f1(x + 1.4)} ${f1(h * 0.7)} ${f1(x - 0.6)} ${f1(h * 0.93)}" stroke="#7a8a50" stroke-width="0.32" fill="none"/><ellipse cx="${f1(x + 2.4)}" cy="${f1(h * 0.74)}" rx="1.2" ry="2" fill="#7e8c52" transform="rotate(40 ${f1(x + 2.4)} ${f1(h * 0.74)})"/>`;
            [[-2.2, -2.6, 2.6, '#6a4a9a'], [2.2, -2.6, 2.6, '#6a4a9a'], [-2.8, 0.4, 2.3, '#8a6ab8'], [2.8, 0.4, 2.3, '#8a6ab8'], [0, 2, 2.8, '#d8b84a']].forEach(([dx, dy, r, c], k) => {
              o += `<ellipse cx="${f1(x + dx)}" cy="${f1(y + dy)}" rx="${r}" ry="${f1(r * 0.85)}" fill="${c}" opacity="0.88"/>`;
              if (k > 1) rep(5, j => o += `<path d="M${f1(x)} ${f1(y + 0.4)}l${f1(dx * 0.5 + (j - 2) * 0.35)} ${f1(dy * 0.5 + 0.6)}" stroke="#3a2a4a" stroke-width="0.1" opacity="0.7"/>`); });
            return o + `<circle cx="${f1(x)}" cy="${f1(y + 0.4)}" r="0.5" fill="#f2d070"/><ellipse cx="${f1(x)}" cy="${f1(y + 3)}" rx="2.2" ry="0.9" fill="#c89a3a" opacity="0.5"/>`; },
          cosmos: (w, h, R) => { const x = w * 0.45, y = h * 0.42; let o = `<path d="M${f1(x)} ${f1(y + 1)}Q${f1(x + 2)} ${f1(h * 0.7)} ${f1(x + 1)} ${f1(h * 0.95)}" stroke="#7a8a50" stroke-width="0.26" fill="none"/>`;
            rep(3, k => o += `<path d="M${f1(x + 1.4)} ${f1(h * (0.66 + k * 0.08))}l${f1(2 + k)} ${f1(-1 - k * 0.5)}M${f1(x + 2.4 + k)} ${f1(h * (0.66 + k * 0.08) - 0.8)}l0.9 0.8" stroke="#8a9a5a" stroke-width="0.14"/>`);
            rep(8, k => { const a = k * PI / 4 + 0.2; o += `<ellipse cx="${f1(x + Math.cos(a) * 2.1)}" cy="${f1(y + Math.sin(a) * 2.1)}" rx="1.9" ry="0.95" fill="${k % 2 ? '#e8a0b4' : '#dc8aa4'}" opacity="0.9" transform="rotate(${f1(a * 180 / PI)} ${f1(x + Math.cos(a) * 2.1)} ${f1(y + Math.sin(a) * 2.1)})"/>`; });
            return o + `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.9" fill="#d8a83a"/>` + rep(10, () => `<circle cx="${f1(x + (R() - 0.5) * 1.4)}" cy="${f1(y + (R() - 0.5) * 1.4)}" r="0.12" fill="#a8742a"/>`).join(''); },
          lav: (w, h, R) => { let o = ''; [[w * 0.3, -14], [w * 0.5, 0], [w * 0.7, 16]].forEach(([x0, rot]) => { let g = `<path d="M${f1(x0)} ${f1(h * 0.95)}V${f1(h * 0.15)}" stroke="#8a9a6a" stroke-width="0.2"/>`;
              for (let y = h * 0.16; y < h * 0.5; y += 0.7) g += `<ellipse cx="${f1(x0 + (R() - 0.5) * 0.7)}" cy="${f1(y)}" rx="0.38" ry="0.3" fill="${R() < 0.5 ? '#8a6ab0' : '#7a5aa4'}" opacity="0.9"/>`;
              o += `<g transform="rotate(${rot} ${f1(x0)} ${f1(h * 0.95)})">${g}</g>`; });
            return o + `<path d="M${f1(w * 0.36)} ${f1(h * 0.8)}h${f1(w * 0.28)}" stroke="#c8a870" stroke-width="0.5"/>`; },
          ginkgo: (w, h, R) => { let o = ''; [[w * 0.36, h * 0.38, -20, '#d8b04a'], [w * 0.62, h * 0.3, 18, '#c8a03a'], [w * 0.5, h * 0.62, 4, '#e2bc5a']].forEach(([x, y, rot, c]) => {
              o += `<g transform="rotate(${rot} ${f1(x)} ${f1(y)})"><path d="M${f1(x)} ${f1(y + 3.6)}V${f1(y + 6)}" stroke="#a88a3a" stroke-width="0.2"/><path d="M${f1(x)} ${f1(y + 3.6)}L${f1(x - 3.2)} ${f1(y - 0.4)}Q${f1(x - 1.6)} ${f1(y - 1.8)} ${f1(x - 0.2)} ${f1(y - 1)}L${f1(x)} ${f1(y - 0.2)}L${f1(x + 0.2)} ${f1(y - 1)}Q${f1(x + 1.6)} ${f1(y - 1.8)} ${f1(x + 3.2)} ${f1(y - 0.4)}Z" fill="${c}" opacity="0.92"/>`
                + rep(9, k => `<path d="M${f1(x)} ${f1(y + 3.4)}L${f1(x - 2.8 + k * 0.7)} ${f1(y - 0.6 - Math.sin(k / 8 * PI) * 0.6)}" stroke="#a8862a" stroke-width="0.06" opacity="0.6"/>`).join('') + '</g>'; });
            return o; } };
        let s = '';
        F.forEach(([cx, by, w, h, sp, lab], i) => { const R = rng('h44' + i), b = 1.5, mt = sp === 'fern' ? 4 : 2.6, iw = w - 2 * (b + mt), ih = h - 2 * (b + mt) - 1.2;
          const art = `<rect width="${f1(iw)}" height="${f1(ih)}" fill="#f2ead6"/>` + rep(30, () => `<circle cx="${f1(R() * iw)}" cy="${f1(R() * ih)}" r="${f1(0.1 + R() * 0.2)}" fill="#c8b890" opacity="0.25"/>`).join('')
            + `<rect width="${f1(iw)}" height="${f1(ih)}" fill="url(#${id}p)"/>` + SP[sp](iw, ih, R);
          const face = `<rect width="${w}" height="${h}" fill="url(#${id}o)"/>` + rep(10, () => { const y = R() * h; return `<path d="M0 ${f1(y)}h${w}" stroke="#a87c4a" stroke-width="0.08" opacity="0.4"/>`; }).join('')
            + `<rect x="${b}" y="${b}" width="${f1(w - 2 * b)}" height="${f1(h - 2 * b)}" fill="#f8f5ee"/><rect x="${b}" y="${b}" width="${f1(w - 2 * b)}" height="0.5" fill="#3a2a1a" opacity="0.25"/><rect x="${b}" y="${b}" width="0.4" height="${f1(h - 2 * b)}" fill="#3a2a1a" opacity="0.18"/>`
            + `<rect x="${f1(b + mt - 0.5)}" y="${f1(b + mt - 0.5)}" width="${f1(iw + 1)}" height="${f1(ih + 1)}" fill="#fdfcf8"/><path d="M${f1(b + mt - 0.5)} ${f1(b + mt - 0.5)}l0.5 0.5h${f1(iw)}l0.5 -0.5Z" fill="#e6e0d0"/><path d="M${f1(b + mt - 0.5)} ${f1(b + mt - 0.5)}l0.5 0.5v${f1(ih)}l-0.5 0.5Z" fill="#ece6d8"/>`
            + `<g transform="translate(${f1(b + mt)} ${f1(b + mt)})">${art}</g>`
            + `<text x="${f1(w / 2)}" y="${f1(h - b - mt * 0.4)}" text-anchor="middle" font-family="'Segoe Script','Bradley Hand',cursive" font-size="${sp === 'fern' ? 1.15 : 0.95}" fill="#6a6458" opacity="0.85" font-style="italic">${lab}</text>`
            + `<path d="M${f1(w * 0.1)} 0H${f1(w * 0.32)}L${f1(w * 0.02)} ${h}H0V${f1(h * 0.5)}Z" fill="#ffffff" opacity="0.1"/>`
            + `<clipPath id="${id}c${i}"><rect x="${b}" y="${b}" width="${f1(w - 2 * b)}" height="${f1(h - 2 * b)}"/></clipPath><g clip-path="url(#${id}c${i})"><rect x="-14" y="0" width="7" height="${h}" fill="url(#${id}g)" transform="skewX(-22)">${an('x', `-14;-14;${w + 20};${w + 20}`, 12, 0, KT(`0;${f1(0.08 + i * 0.1)};${f1(0.3 + i * 0.1)};1`))}</rect></g>`;
          s += shW(C, cx - w / 2, by + h, w, h, 0.4, 0.32) + box3(C, { c: [cx, by, FD / 2], w, h, d: FD, col: '#d0aa78', r: 0.25, dec: { f: face } }); });
        return { defs: DEF19 + `<defs><linearGradient id="${id}o" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e2c494"/><stop offset="0.5" stop-color="#d0aa78"/><stop offset="1" stop-color="#b8905e"/></linearGradient>`
          + `<linearGradient id="${id}p" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="1" stop-color="#c8b080" stop-opacity="0.15"/></linearGradient>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-064 HAND-EMBROIDERED SILK KIMONO TAPESTRY IN SHADOWBOX (T4): a deep black-lacquer shadowbox with a gilded inner fillet, lined in ivory silk
    // linen and lit from a hidden warm strip along the top; inside, a crimson silk furisode hung by its sleeves on a bamboo pole: hand-embroidered
    // cranes in white silk with black necks and red crowns, gold-couched clouds and plum blossoms, gold seigaiha waves round the hem and sleeve ends,
    // an ivory and gold collar, soft drape folds and the kimono's own shadow on the lining; glass front with a reflection.
    // Live: light slides across the silk and the gold threads glint.
    N.hang30d = S => { const D = { w: 76, d: 8, mount: 'wall', elev: 36, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('hang30d'), id = C.u('h64'), W = 48, H = 40, BD = 4.4, b = 3, dd = 2.2;
        ext(C, [[-W / 2 - 1, H + 1, 0], [W / 2 + 1, -2, 0], [W / 2 + 1, -2, BD + 0.6]]);
        const ix = b + 0.5, iw = W - 2 * ix, ih = H - 2 * ix, bx = ix + dd, bw = iw - 2 * dd, bh = ih - 2 * dd;
        // kimono in back-panel coords (bw x bh ~ 37 x 29)
        const KW = bw, k0 = (KW - 36) / 2;
        const body = `M${f1(k0 + 11)} 3L${f1(k0 + 25)} 3L${f1(k0 + 26.2)} 27.4L${f1(k0 + 9.8)} 27.4Z`;
        const slL = `M${f1(k0 + 0.6)} 3H${f1(k0 + 11.6)}V18.4H${f1(k0 + 3)}Q${f1(k0 + 0.6)} 18.4 ${f1(k0 + 0.6)} 16Z`, slR = `M${f1(k0 + 24.4)} 3H${f1(k0 + 35.4)}V16Q${f1(k0 + 35.4)} 18.4 ${f1(k0 + 33)} 18.4H${f1(k0 + 24.4)}Z`;
        const sil = body + slL + slR;
        let k = `<clipPath id="${id}k"><path d="${sil}"/></clipPath>`;
        let in1 = `<path d="${sil}" fill="url(#${id}s)"/>`;
        // drape folds
        [[k0 + 13.4, 3, 0.9], [k0 + 16.6, 14, 0.7], [k0 + 22.4, 6, 1], [k0 + 4.2, 3, 0.8], [k0 + 8.6, 6, 0.6], [k0 + 27.6, 4, 0.8], [k0 + 32, 3, 0.7]].forEach(([x, y0, w]) => in1 += `<path d="M${f1(x)} ${y0}Q${f1(x + 0.4)} 14 ${f1(x + 0.2)} 28" stroke="#3a0810" stroke-width="${w}" opacity="0.32" fill="none" filter="url(#m12b1)"/><path d="M${f1(x + 0.8)} ${y0}Q${f1(x + 1.2)} 14 ${f1(x + 1)} 28" stroke="#e8606a" stroke-width="${f1(w * 0.5)}" opacity="0.2" fill="none" filter="url(#m12b1)"/>`);
        // seigaiha waves on hem + sleeve ends
        const waves = (x0, x1, y0, y1) => { let o = `<rect x="${f1(x0)}" y="${f1(y0)}" width="${f1(x1 - x0)}" height="${f1(y1 - y0)}" fill="#3a0c16"/>`; const r = 1.3;
          for (let row = 0, y = y1; y > y0 - r; row++, y -= r * 0.6) for (let x = x0 - (row % 2 ? r : 0); x < x1 + r; x += r * 2) [1, 0.66, 0.33].forEach((q, j) => o += `<path d="M${f1(x - r * q)} ${f1(y)}A${f1(r * q)} ${f1(r * q)} 0 0 1 ${f1(x + r * q)} ${f1(y)}" stroke="${j ? '#c8a050' : '#e8c878'}" stroke-width="${j ? 0.1 : 0.14}" fill="${j ? 'none' : '#3a0c16'}"/>`);
          return o + `<path d="M${f1(x0)} ${f1(y0)}H${f1(x1)}" stroke="#e8c878" stroke-width="0.3"/>`; };
        in1 += waves(k0 + 9, k0 + 27, 23, 27.6) + waves(k0, k0 + 12, 15.4, 18.6) + waves(k0 + 24, k0 + 36, 15.4, 18.6);
        // gold clouds
        const cloud = (x, y, s) => { const d = `M${f1(x)} ${f1(y)}h${f1(5 * s)}a${f1(1.1 * s)} ${f1(1.1 * s)} 0 0 0 0 ${f1(-2.2 * s)}a${f1(1.4 * s)} ${f1(1.4 * s)} 0 0 0 ${f1(-2.6 * s)} -0.4a${f1(1.2 * s)} ${f1(1.2 * s)} 0 0 0 ${f1(-2.2 * s)} 0.6a${f1(1 * s)} ${f1(1 * s)} 0 0 0 ${f1(-0.2 * s)} ${f1(2 * s)}Z`;
          return `<path d="${d}" fill="#c89a48" opacity="0.35"/><path d="${d}" fill="none" stroke="#f0d088" stroke-width="0.22" stroke-dasharray="0.35 0.12"/>`; };
        in1 += cloud(k0 + 2, 7.4, 1) + cloud(k0 + 27, 11.4, 0.9) + cloud(k0 + 14.4, 19.6, 1.1) + cloud(k0 + 18, 7, 0.7);
        // cranes
        const crane = (x, y, s, fl) => `<g transform="translate(${f1(x)} ${f1(y)}) scale(${fl ? -s : s} ${s})">`
          + `<path d="M0 0Q-3 -4.6 -7.4 -4.2Q-5 -2.6 -4.6 -1Q-6.4 -1.6 -8 -0.6Q-4 0.4 0 0.8Z" fill="#fbf8f0" stroke="#e8c878" stroke-width="0.14"/><path d="M-7.4 -4.2l1 0.9M-8 -0.6l1.2 0.1M-6.6 -3.2l0.8 0.6" stroke="#1a1414" stroke-width="0.5" stroke-linecap="round"/>`
          + `<path d="M0.4 0.2Q2.6 -4 6 -2.6Q3.6 -1.6 3.2 0.4Z" fill="#f4efe4" stroke="#e8c878" stroke-width="0.14"/><path d="M6 -2.6l-0.9 0.5" stroke="#1a1414" stroke-width="0.5" stroke-linecap="round"/>`
          + `<ellipse cx="1" cy="0.6" rx="2.4" ry="1" fill="#ffffff" stroke="#e8c878" stroke-width="0.12"/><path d="M3 0.2Q5 -0.6 5.6 -2.4Q6 -3.4 6.8 -3" stroke="#1a1414" stroke-width="0.42" fill="none"/><circle cx="6.8" cy="-3.1" r="0.36" fill="#f4f0e8"/><circle cx="6.9" cy="-3.3" r="0.18" fill="#d8202a"/><path d="M7.1 -3l1 0.3" stroke="#c8a050" stroke-width="0.14"/>`
          + `<path d="M-1.2 1.1l-1.6 1.6M-0.4 1.2l-1.2 1.9" stroke="#3a2a20" stroke-width="0.14"/></g>`;
        in1 += crane(k0 + 7.6, 11.2, 0.9, 0) + crane(k0 + 22.6, 15.6, 0.7, 1);
        // plum blossoms
        rep(14, () => { const x = k0 + 1.4 + R() * 33, y = 4 + R() * 18, r = 0.4 + R() * 0.25; in1 += rep(5, j => `<circle cx="${f1(x + Math.cos(j * 1.2566) * r)}" cy="${f1(y + Math.sin(j * 1.2566) * r)}" r="${f1(r * 0.62)}" fill="${R() < 0.6 ? '#fbf4ec' : '#f4c0c8'}"/>`).join('') + `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r * 0.35)}" fill="#e8c060"/>`; });
        // satin-stitch texture over everything + glinting gold threads + sliding light
        in1 += `<rect width="${f1(KW)}" height="30" fill="url(#${id}t)"/>`
          + rep(16, j => { const x = k0 + 1 + R() * 34, y = 4 + R() * 23, T = 4 + R() * 4; return `<path d="M${f1(x - 0.45)} ${f1(y)}H${f1(x + 0.45)}M${f1(x)} ${f1(y - 0.45)}V${f1(y + 0.45)}" stroke="#fff4c8" stroke-width="0.09" opacity="0">${an('opacity', '0;0.95;0', T, -R() * T, SPL(2))}</path>`; }).join('')
          + `<rect x="-20" y="0" width="9" height="30" fill="url(#${id}g)" transform="skewX(-24)">${an('x', '-20;50', 13, 0, SPL(1))}</rect>`;
        k += in1.replace(/^/, `<g clip-path="url(#${id}k)">`) + '</g>';
        // collar (eri) + front overlap seam
        k += `<path d="M${f1(k0 + 15.6)} 3L${f1(k0 + 18.4)} 13.4" stroke="#f4ecd8" stroke-width="1.4"/><path d="M${f1(k0 + 15.1)} 3L${f1(k0 + 17.9)} 13.4" stroke="#d8b060" stroke-width="0.3"/>`
          + `<path d="M${f1(k0 + 20.6)} 3L${f1(k0 + 18.4)} 12" stroke="#ece2cc" stroke-width="1.3"/><path d="M${f1(k0 + 18.6)} 13.4L${f1(k0 + 19.6)} 27.4" stroke="#3a0810" stroke-width="0.25" opacity="0.6"/>`;
        // bamboo pole + silk cords
        k += `<path d="M${f1(k0 - 1)} 2.2H${f1(k0 + 37)}" stroke="#7a5a2a" stroke-width="1.5" stroke-linecap="round"/><path d="M${f1(k0 - 1)} 1.9H${f1(k0 + 37)}" stroke="#d8b878" stroke-width="0.5"/>`
          + [k0 + 5, k0 + 15, k0 + 26, k0 + 33].map(x => `<rect x="${f1(x)}" y="1.4" width="0.4" height="1.6" fill="#5a3a1a"/>`).join('')
          + `<path d="M${f1(k0 + 8)} 2.2L${f1(k0 + 18)} -1.2L${f1(k0 + 28)} 2.2" stroke="#c8a050" stroke-width="0.2" fill="none"/><circle cx="${f1(k0 + 18)}" cy="-1.2" r="0.4" fill="#c8a050"/>`;
        // lining + kimono shadow + light from the top strip
        const back = `<rect width="${f1(bw)}" height="${f1(bh)}" fill="#e6dcc6"/>` + rep(Math.round(bh / 0.5), i => `<rect y="${f1(i * 0.5)}" width="${f1(bw)}" height="0.16" fill="${i % 2 ? '#ffffff' : '#b8a888'}" opacity="0.1"/>`).join('')
          + `<path d="${sil}" fill="#2a1a10" opacity="0.32" filter="url(#m10b1)" transform="translate(0.6 1.4)"/>` + k
          + `<rect width="${f1(bw)}" height="${f1(bh)}" fill="url(#${id}l)"><animate attributeName="opacity" values="0.85;1;0.85" dur="9s" repeatCount="indefinite" ${SPL(2)}/></rect>`;
        // interior walls (perspective trapezoids)
        const walls = `<path d="M${ix} ${ix}h${f1(iw)}l${-dd} ${dd}h${f1(-bw)}Z" fill="#6a5a44"/><path d="M${ix} ${ix}h${f1(iw)}" stroke="#fff0c8" stroke-width="0.6" opacity="0.9" filter="url(#m12b1)"/><path d="M${f1(ix + 1)} ${f1(ix + 0.3)}h${f1(iw - 2)}" stroke="#fffbe8" stroke-width="0.25"/>`
          + `<path d="M${ix} ${ix}v${f1(ih)}l${dd} ${-dd}v${f1(-bh)}Z" fill="#c8bca4"/><path d="M${f1(ix + iw)} ${ix}v${f1(ih)}l${-dd} ${-dd}v${f1(-bh)}Z" fill="#b4a890"/><path d="M${ix} ${f1(ix + ih)}h${f1(iw)}l${-dd} ${-dd}h${f1(-bw)}Z" fill="#ddd2bc"/>`;
        const face = `<rect width="${W}" height="${H}" fill="url(#${id}f)"/><rect x="0.3" y="0.3" width="${W - 0.6}" height="${H - 0.6}" fill="none" stroke="#5a5050" stroke-width="0.2"/><rect x="${f1(b - 0.6)}" y="${f1(b - 0.6)}" width="${f1(W - 2 * b + 1.2)}" height="${f1(H - 2 * b + 1.2)}" fill="url(#${id}d)"/>`
          + walls + `<g transform="translate(${f1(bx)} ${f1(bx)})">${back}</g>`
          + `<path d="M${f1(ix + 3)} ${ix}L${f1(ix + 9)} ${ix}L${f1(ix + 1)} ${f1(ix + ih)}L${ix} ${f1(ix + ih)}V${f1(ix + 20)}Z" fill="#ffffff" opacity="0.08"/><path d="M${f1(ix + 12)} ${ix}L${f1(ix + 14)} ${ix}L${f1(ix + 5)} ${f1(ix + ih)}L${f1(ix + 3)} ${f1(ix + ih)}Z" fill="#ffffff" opacity="0.06"/>`
          + `<rect x="${ix}" y="${ix}" width="${f1(iw)}" height="${f1(ih)}" fill="none" stroke="#e8c878" stroke-width="0.5"/>`;
        let s = shW(C, -W / 2, H, W, H, 0.6, 0.38) + box3(C, { c: [0, 0, BD / 2], w: W, h: H, d: BD, col: '#24201e', r: 0.3, gl: 0.2, dec: { f: face } });
        return { defs: DEF19 + `<defs><linearGradient id="${id}f" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4a4240"/><stop offset="0.3" stop-color="#1e1a1a"/><stop offset="0.6" stop-color="#2e2826"/><stop offset="1" stop-color="#141010"/></linearGradient>`
          + `<linearGradient id="${id}d" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4dc98"/><stop offset="0.5" stop-color="#b8904a"/><stop offset="1" stop-color="#e8c878"/></linearGradient>`
          + `<linearGradient id="${id}s" x1="0" y1="0" x2="0.4" y2="1"><stop offset="0" stop-color="#b42430"/><stop offset="0.5" stop-color="#9a1824"/><stop offset="1" stop-color="#6e0e1a"/></linearGradient>`
          + `<pattern id="${id}t" width="0.5" height="0.5" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><rect width="0.5" height="0.16" fill="#ffffff" opacity="0.07"/></pattern>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffe8c0" stop-opacity="0"/><stop offset="0.5" stop-color="#ffe8c0" stop-opacity="0.22"/><stop offset="1" stop-color="#ffe8c0" stop-opacity="0"/></linearGradient>`
          + `<radialGradient id="${id}l" cx="0.5" cy="0" r="1"><stop offset="0" stop-color="#ffe0a0" stop-opacity="0.3"/><stop offset="0.6" stop-color="#ffe0a0" stop-opacity="0.06"/><stop offset="1" stop-color="#2a1a10" stop-opacity="0.18"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-084 LIVING KINETIC SAND-MANDALA & BIOLUMINESCENT WALL MURAL (T5): a deep forest-night mural sprayed onto the wall with a feathered edge:
    // glowing mycelium threads branching out from the centre, foxfire mushrooms with amber caps, curled fern fiddleheads and moss in soft
    // lime-gold light, fireflies; at its heart a brass drum under a glass dome holding a hand-poured sand mandala (terracotta, ochre, ivory,
    // lapis, black and gold sand, every grain visible). Live: the mandala's rings slowly turn against each other, the inner lotus breathes,
    // sand flows round the groove, light pulses travel out along the mycelium and fireflies drift.
    N.hang30e = S => { const D = { w: 76, d: 8, mount: 'wall', elev: 36, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('hang30e'), id = C.u('h84'), MW = 70, MH = 46, RR = 14, CY = 22;
        ext(C, [[-MW / 2, MH, 0], [MW / 2, -2, 0], [MW / 2, -2, 3.4]]);
        const cx = MW / 2, cy = MH - CY;
        // painted ground with a feathered spray edge
        let blob = 'M'; for (let i = 0; i <= 40; i++) { const a = i / 40 * 2 * PI, r = 1 + Math.sin(a * 3 + 1) * 0.025 + Math.sin(a * 5) * 0.015; blob += (i ? 'L' : '') + f1(cx + Math.cos(a) * 33 * r) + ' ' + f1(MH / 2 + Math.sin(a) * 21.6 * r); } blob += 'Z';
        let m = `<path d="${blob}" fill="#16201c" filter="url(#m10b2)"/><path d="${blob}" fill="url(#${id}b)" transform="translate(${f1(cx)} ${f1(MH / 2)}) scale(0.95) translate(${f1(-cx)} ${f1(-MH / 2)})"/><clipPath id="${id}c"><path d="${blob}" transform="translate(${f1(cx)} ${f1(MH / 2)}) scale(0.97) translate(${f1(-cx)} ${f1(-MH / 2)})"/></clipPath><g clip-path="url(#${id}c)">`
          + rep(140, () => { const a = R() * 2 * PI, r = 0.9 + R() * 0.12; return `<circle cx="${f1(cx + Math.cos(a) * 33 * r)}" cy="${f1(MH / 2 + Math.sin(a) * 21.6 * r)}" r="${f1(0.06 + R() * 0.14)}" fill="#1e2a24" opacity="${f1(0.4 + R() * 0.5)}"/>`; }).join('');
        // mycelium threads: glow + core + travelling pulses
        let th = '', pu = '';
        rep(16, i => { const a0 = i / 16 * 2 * PI + (R() - 0.5) * 0.2; let x = cx + Math.cos(a0) * (RR + 0.5), y = cy + Math.sin(a0) * (RR + 0.5) * 0.98, a = a0, d = `M${f1(x)} ${f1(y)}`; const L = 4 + Math.floor(R() * 4);
          for (let j = 0; j < L; j++) { a += (R() - 0.5) * 0.9; const st = 2 + R() * 1.6, nx = x + Math.cos(a) * st, ny = y + Math.sin(a) * st * 0.9;
            d += `Q${f1((x + nx) / 2 + (R() - 0.5) * 1.4)} ${f1((y + ny) / 2 + (R() - 0.5) * 1.4)} ${f1(nx)} ${f1(ny)}`; x = nx; y = ny;
            if (R() < 0.35) th += `<path d="M${f1(x)} ${f1(y)}q${f1(Math.cos(a + 0.9) * 1.4)} ${f1(Math.sin(a + 0.9) * 1.4)} ${f1(Math.cos(a + 0.6) * 2.6)} ${f1(Math.sin(a + 0.6) * 2.6)}" stroke="#c8e088" stroke-width="0.12" fill="none" opacity="0.6"/>`; }
          th += `<path d="${d}" stroke="#a8d070" stroke-width="0.9" fill="none" opacity="0.18" filter="url(#m12b1)"/><path d="${d}" stroke="#d8ec9c" stroke-width="0.16" fill="none" opacity="0.8"/><circle cx="${f1(x)}" cy="${f1(y)}" r="0.32" fill="#f4f8c8"/>`;
          const T = 5 + R() * 3; pu += `<path d="${d}" pathLength="100" stroke="#fff8c8" stroke-width="0.45" fill="none" stroke-linecap="round" stroke-dasharray="3 97" opacity="0.9"><animate attributeName="stroke-dashoffset" values="100;0" dur="${f1(T)}s" begin="${f1(-R() * T)}s" repeatCount="indefinite"/></path>`; });
        m += th + `<g filter="url(#m12b1)">${pu}</g>` + pu;
        // foxfire mushrooms + fiddleheads + moss along the bottom
        const shroom = (x, y, s, c) => `<g transform="translate(${f1(x)} ${f1(y)}) scale(${s})"><ellipse cy="-1.6" rx="3" ry="2" fill="${c}" opacity="0.28" filter="url(#m10b1)"><animate attributeName="opacity" values="0.18;0.4;0.18" dur="${f1(5 + R() * 3)}s" begin="${f1(-R() * 5)}s" repeatCount="indefinite"/></ellipse>`
          + `<path d="M-0.3 0Q-0.5 -1 -0.2 -2H0.3Q0.5 -1 0.3 0Z" fill="#e8e0b8"/><path d="M-1.8 -1.9Q-1.6 -3.4 0 -3.6Q1.6 -3.4 1.8 -1.9Z" fill="${c}"/><path d="M-1.8 -1.9H1.8" stroke="#8a6a2a" stroke-width="0.14"/>` + rep(5, j => `<path d="M${f1(-1.4 + j * 0.7)} -1.9l${f1((j - 2) * 0.1)} 0.3" stroke="#8a6a2a" stroke-width="0.06"/>`).join('') + `<path d="M-1 -2.9Q0 -3.4 0.8 -3" stroke="#fff4c8" stroke-width="0.2" fill="none"/></g>`;
        [[14, 38.6, 1, '#ffb850'], [16.4, 39.4, 0.7, '#ffcc70'], [12.2, 39.8, 0.55, '#ffc060'], [55.4, 37.4, 0.9, '#f8b048'], [57.8, 38.8, 0.6, '#ffd078'], [33, 42.2, 0.6, '#ffc868'], [38.6, 42.6, 0.75, '#ffb850'], [10, 16, 0.6, '#d8ec8a'], [60, 12.6, 0.7, '#d8ec8a']].forEach(a => m += shroom(...a));
        [[20.4, 40.4, 1], [50, 40, -1], [7, 26, 1], [63, 26.4, -1]].forEach(([x, y, sd]) => m += `<path d="M${x} ${y}q${f1(sd * 0.6)} -3 ${f1(sd * 0.2)} -5.4q${f1(-sd * 0.4)} -1.6 ${f1(sd * 1.2)} -1.8q${f1(sd * 1.2)} 0.2 ${f1(sd * 0.6)} 1.2q${f1(-sd * 0.5)} 0.5 ${f1(-sd * 0.8)} -0.2" stroke="#c8e088" stroke-width="0.3" fill="none"/><path d="M${x} ${y}q${f1(sd * 0.6)} -3 ${f1(sd * 0.2)} -5.4" stroke="#a8d070" stroke-width="1" fill="none" opacity="0.2" filter="url(#m12b1)"/>`);
        m += rep(70, () => { const x = 8 + R() * 54, y = 38 + R() * 5 - Math.abs(x - cx) * 0.06; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(0.15 + R() * 0.3)}" fill="${R() < 0.6 ? '#4a6a3a' : '#a8c868'}" opacity="${f1(0.5 + R() * 0.4)}"/>`; }).join('');
        m += '</g>';
        // fireflies
        m += rep(9, i => { const x = 6 + R() * 58, y = 5 + R() * 34, T = 9 + R() * 8, dx = (R() - 0.5) * 8, dy = (R() - 0.5) * 6;
          return `<g>${at('translate', `0 0;${f1(dx)} ${f1(dy)};${f1(dx * 0.3)} ${f1(-dy)};0 0`, T, -R() * T, SPL(3))}<circle cx="${f1(x)}" cy="${f1(y)}" r="1.1" fill="#ffd878" opacity="0.3" filter="url(#m12b1)"/><circle cx="${f1(x)}" cy="${f1(y)}" r="0.22" fill="#fff4c0">${an('opacity', '0.2;1;0.2', f1(2 + R() * 2), -R() * 3, SPL(2))}</circle></g>`; }).join('');
        let s = WD(C, -MW / 2, MH, 0.04, m);
        // sand mandala drum
        const cap = cr => { const kk = cr / RR; let o = `<g transform="scale(${n4(kk)})"><circle r="${RR}" fill="url(#${id}z)"/><circle r="${RR - 1.2}" fill="#e8d8b4"/>`;
          const grain = (r0, r1, n, cols) => rep(n, () => { const a = R() * 2 * PI, r = r0 + R() * (r1 - r0); return `<circle cx="${f1(Math.cos(a) * r)}" cy="${f1(Math.sin(a) * r)}" r="${f1(0.05 + R() * 0.07)}" fill="${cols[Math.floor(R() * cols.length)]}" opacity="0.7"/>`; }).join('');
          // outer ring: terracotta drops on black band (turns slowly)
          let L1 = `<circle r="${f1(RR - 1.8)}" fill="none" stroke="#2a221c" stroke-width="1.1"/>` + rep(24, j => { const a = j * 15; return `<path d="M0 ${f1(-(RR - 2.6))}q0.9 1.6 0 3q-0.9 -1.4 0 -3Z" fill="#c8643a" transform="rotate(${a})"/><circle cy="${f1(-(RR - 1.8))}" r="0.25" fill="#f2e4c4" transform="rotate(${a + 7.5})"/>`; }).join('');
          L1 += grain(RR - 4.4, RR - 1.3, 220, ['#8a3a1a', '#f4e8cc', '#3a2a1e']);
          o += `<g>${at('rotate', '0;360', 200)}${L1}</g>`;
          // groove ring with flowing sand
          o += `<circle r="${f1(RR - 4.9)}" fill="none" stroke="#c8b48a" stroke-width="0.8"/><circle r="${f1(RR - 4.9)}" fill="none" stroke="#fff0c8" stroke-width="0.3" stroke-dasharray="0.3 0.6" opacity="0.9"><animate attributeName="stroke-dashoffset" values="0;-9" dur="6s" repeatCount="indefinite"/></circle>`;
          // middle: 12 lotus petals ochre + lapis (counter-turning)
          let L2 = `<circle r="${f1(RR - 5.6)}" fill="#3a5a7a"/>` + rep(12, j => `<path d="M0 ${f1(-(RR - 5.6))}C2.4 -6.4 1.8 -3.6 0 -2.6C-1.8 -3.6 -2.4 -6.4 0 ${f1(-(RR - 5.6))}Z" fill="#d8a040" stroke="#f4e0a0" stroke-width="0.14" transform="rotate(${j * 30 + 15})"/><path d="M0 ${f1(-(RR - 6.6))}C1.2 -5.8 0.8 -4.2 0 -3.6C-0.8 -4.2 -1.2 -5.8 0 ${f1(-(RR - 6.6))}Z" fill="#c8643a" transform="rotate(${j * 30 + 15})"/>`).join('')
            + grain(2.6, RR - 5.6, 260, ['#f4e0a0', '#8a5a1a', '#1e3a5a', '#c8643a']);
          o += `<g>${at('rotate', '0;-360', 140)}${L2}</g>`;
          // inner lotus (breathes) + gold core that glows
          let L3 = `<circle r="3.2" fill="#f4ecd8"/>` + rep(8, j => `<path d="M0 -3.4C1.2 -2.6 1 -1.4 0 -0.8C-1 -1.4 -1.2 -2.6 0 -3.4Z" fill="#9a2a2a" stroke="#f4d890" stroke-width="0.1" transform="rotate(${j * 45})"/>`).join('') + grain(0.6, 3.2, 70, ['#ffffff', '#c8a050']);
          o += `<g>${at('scale', '0.95;1.05;0.95', 9, 0, SPL(2))}${L3}</g><circle r="1.2" fill="#ffd878" opacity="0.5" filter="url(#m12b1)">${an('opacity', '0.3;0.8;0.3', 6, 0, SPL(2))}</circle><circle r="0.8" fill="#f4c850"/><circle r="0.3" fill="#fff8e0"/>`;
          // brass bezel + glass dome
          o += `<circle r="${f1(RR - 0.6)}" fill="none" stroke="url(#${id}r)" stroke-width="1.2"/><circle r="${f1(RR - 0.1)}" fill="none" stroke="#5a4020" stroke-width="0.2"/><ellipse cx="-4" cy="-6" rx="6" ry="3" fill="#ffffff" opacity="0.14" transform="rotate(-30 -4 -6)"/><path d="M${f1(-RR * 0.7)} ${f1(RR * 0.2)}A${f1(RR * 0.75)} ${f1(RR * 0.75)} 0 0 0 ${f1(-RR * 0.1)} ${f1(RR * 0.72)}" stroke="#ffffff" stroke-width="0.4" fill="none" opacity="0.3"/></g>`;
          return o; };
        s += WD(C, -RR - 6, CY + RR + 6, 0.06, `<circle cx="${RR + 6}" cy="${RR + 6}" r="${RR + 2.4}" fill="#e8f0a0" opacity="0.3" filter="url(#m10b2)">${an('opacity', '0.2;0.42;0.2', 8, 0, SPL(2))}</circle>`);
        s += cyl3(C, [0, CY, 0.3], [0, CY, 2.6], RR, '#b8925a', { n: 40, cap, capCol: '#c8a468' });
        return { defs: DEF19 + `<defs><radialGradient id="${id}b" cx="0.5" cy="0.48" r="0.6"><stop offset="0" stop-color="#2a3a30"/><stop offset="0.6" stop-color="#1a2620"/><stop offset="1" stop-color="#121a16"/></radialGradient>`
          + `<radialGradient id="${id}z"><stop offset="0.8" stop-color="#c8a468"/><stop offset="1" stop-color="#7a5a2a"/></radialGradient>`
          + `<linearGradient id="${id}r" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f8e4a8"/><stop offset="0.45" stop-color="#b8904a"/><stop offset="0.7" stop-color="#f0d090"/><stop offset="1" stop-color="#8a6a32"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };
  }

  // ======================= CEILINGS (r.c30) — same frame + hook as the Bathroom ceilings (plus29 r.c29): RD.H14 frame + G.VY depth, t 0 = front edge, 1 = back wall line =======================
  // card = the tier's new Bedroom wall (SURF12 bd01..bd81) under the ceiling; res.ceilRoom = the wide room ceiling (Squad House v6 rt.ceil)
  { const { mould, mkV } = RD.H21, CFRM = RD.H14.FRM, { cE, cDoc, cShade } = RD.H27, { SURF12, tile: wTile } = RD.H12;
    const cEl = (P, rx, ry, ex, dy) => `<ellipse cx="${f1(P.x)}" cy="${f1(P.y + (dy || 0))}" rx="${f1(rx)}" ry="${f1(ry)}" ${ex}/>`;
    const cBl = (G, sd, n, cols, op, w) => { const R = rng(sd); return `<g filter="url(#cb6)" opacity="${op}">` + rep(n, i => { const t = 0.05 + R() * 0.92, y = G.y(t), z = G.z(y); return `<ellipse cx="${f1(G.x(R() * 1.1 - 0.05, y))}" cy="${f1(y)}" rx="${f1((w + R() * w) * z)}" ry="${f1((4 + R() * 5) * z)}" fill="${cols[i % cols.length]}"/>`; }).join('') + '</g>'; };
    const loc = (P, inner) => `<g transform="translate(${f1(P.x)} ${f1(P.y)}) scale(1 ${n4(P.q)})">${inner}</g>`;
    const ring = (R, r, n, j) => 'M' + rep(n, i => { const a = i / n * 2 * PI, k = r * (1 - j / 2 + R() * j); return f1(Math.cos(a) * k) + ' ' + f1(Math.sin(a) * k); }).join('L') + 'Z';
    // nested tide-ring water stain (local coords, scaled by z)
    const soft = (Q, r) => { const ph = [Q() * 6, Q() * 6, Q() * 6, Q() * 6], am = [0.1, 0.07, 0.05, 0.03].map(a => a * (0.6 + Q() * 0.8)); return k => 'M' + rep(48, i => { const a = i / 48 * 2 * PI, f = 1 + am.reduce((s, m, j) => s + m * Math.sin((j + 2) * a + ph[j] + k * j * 0.6), 0); return f1(Math.cos(a) * r * k * f) + ' ' + f1(Math.sin(a) * r * k * f); }).join('L') + 'Z'; };
    const stain = (P, rw, sd, fresh) => { const z = P.z, Q = rng(sd), sh = soft(Q, rw * z); let o = `<path d="${sh(1)}" fill="${fresh ? '#b88a4a' : '#d0b070'}" opacity="${fresh ? 0.22 : 0.16}" filter="url(#cb3)"/>`;
      [1, 0.9, 0.62, 0.55, 0.3].forEach((k, i) => { const d = sh(k);
        o += `<path d="${d}" fill="${fresh ? '#b88a4a' : '#c8a868'}" opacity="${f1((fresh ? 0.1 : 0.05) + i * 0.02)}"/><path d="${d}" fill="none" stroke="${fresh ? '#7a4e1e' : '#9a7440'}" stroke-width="${f1((i ? 0.7 : 1.4) * z)}" opacity="${f1((fresh ? 0.5 : 0.34) - i * 0.04)}" filter="url(#cb1)"/>`; });
      return loc(P, o); };

    // BED-009 WATER-SPOTTED PLASTER CEILING (T1): old lath-and-plaster gone ivory-yellow, trowel swirls and the faint ghost lines of the joists, a network of
    // hairline map cracks, three old brown tide-ring water stains and one fresh dark one where the plaster sags into a bulge with a crack across it, a
    // dried patch of unpainted white filler that somebody sanded and never painted, paint flakes lifting to grey plaster, and a cracked old cove moulding.
    // Live: a drop of water slowly swells under the fresh stain, lets go and falls.
    function cSpot(G) { const R = rng('spot30');
      let s = `<path d="${G.tr}" fill="#e6dec8"/>` + cBl(G, 'spot30b', 18, ['#eee8d6', '#d6ccb0', '#ddd4ba', '#e8dcc0'], 0.55, 46) + cBl(G, 'spot30c', 10, ['#f4f0e2', '#cfc4a6'], 0.35, 22), ov = '';
      // trowel swirls
      rep(26, () => { const P = cE(G, R(), 0.05 + R() * 0.9), z = P.z, r = (4 + R() * 6) * z; s += loc(P, `<path d="M${f1(-r)} 0A${f1(r)} ${f1(r * 0.7)} 0 0 1 ${f1(r)} 0" stroke="${R() < 0.5 ? '#f6f2e6' : '#c8bc9c'}" stroke-width="${f1(0.6 * z)}" fill="none" opacity="0.35"/>`); });
      // joist ghost lines (dust settles where the plaster is coldest)
      for (let u = 0.08; u < 1; u += 0.12) s += `<path d="M${G.P(u, -0.02)}L${G.P(u + 0.004, 1.02)}" stroke="#a89c7c" stroke-width="${f1(3.2 * G.s)}" opacity="0.08" filter="url(#cb3)"/>`;
      // hairline map cracks (random walks), with a lit lip
      let cr = '';
      rep(6, i => { let u = 0.08 + R() * 0.84, t = 0.08 + R() * 0.84, a = R() * 2 * PI; const pts = [];
        rep(5 + (R() * 6 | 0), () => { const P = cE(G, u, t); pts.push([P.x, P.y]); a += (R() - 0.5) * 1.3; u += Math.cos(a) * 0.022; t += Math.sin(a) * 0.04;
          if (R() < 0.2) { const b = a + (R() < 0.5 ? 1 : -1) * (0.7 + R() * 0.6), Q = cE(G, u + Math.cos(b) * 0.03, t + Math.sin(b) * 0.06); cr += `<path d="M${P2([P.x, P.y])}L${P2([Q.x, Q.y])}" stroke="#6a5e48" stroke-width="${f1(0.28 * P.z)}" fill="none" opacity="0.6"/>`; } });
        const d = 'M' + pts.map(P2).join('L'); cr += `<path d="${d}" stroke="#6a5e48" stroke-width="${f1(0.26 * G.s)}" fill="none" opacity="0.45" stroke-linejoin="bevel"/><path d="${d}" stroke="#fffaf0" stroke-width="${f1(0.3 * G.s)}" fill="none" opacity="0.55" transform="translate(${f1(0.35 * G.s)} ${f1(0.35 * G.s)})"/>`; });
      s += cr;
      // old stains
      s += stain(cE(G, 0.22, 0.66), 34, 'st1') + stain(cE(G, 0.78, 0.36), 22, 'st2') + stain(cE(G, 0.62, 0.88), 16, 'st3');
      // unpainted sanded filler patch
      { const P = cE(G, 0.86, 0.72), z = P.z, Q = rng('fil30'), d = `M${f1(-13 * z)} ${f1(-7 * z)}Q${f1(-2 * z)} ${f1(-9 * z)} ${f1(12 * z)} ${f1(-6.4 * z)}Q${f1(14 * z)} 0 ${f1(11 * z)} ${f1(7 * z)}Q${f1(0)} ${f1(8.6 * z)} ${f1(-12 * z)} ${f1(6 * z)}Q${f1(-14.4 * z)} 0 ${f1(-13 * z)} ${f1(-7 * z)}Z`;
        s += loc(P, `<path d="${d}" fill="#f8f6f0"/><path d="${d}" fill="#ffffff" opacity="0.7" transform="scale(0.7)"/>` + rep(10, () => { const r = (1 + Q() * 6) * z, x = (Q() - 0.5) * 8 * z, y = (Q() - 0.5) * 6 * z; return `<path d="M${f1(x - r)} ${f1(y)}A${f1(r)} ${f1(r)} 0 0 1 ${f1(x + r)} ${f1(y)}" stroke="#d8d0bc" stroke-width="${f1(0.25 * z)}" fill="none" opacity="0.6"/>`; }).join('') + `<path d="${d}" fill="none" stroke="#c8bc9c" stroke-width="${f1(0.4 * z)}" opacity="0.5"/>`); }
      // paint flakes lifting to grey plaster
      [[0.14, 0.32, 5], [0.46, 0.2, 4], [0.9, 0.56, 3.6], [0.36, 0.9, 3]].forEach(([u, t, r], i) => { const P = cE(G, u, t), z = P.z, Q = rng('fk30' + i), d = ring(Q, r * z, 12, 0.6);
        s += loc(P, `<path d="${d}" fill="#b4ac9c"/><path d="${d}" fill="none" stroke="#f4efe0" stroke-width="${f1(0.8 * z)}"/>`);
        const x = P.x + r * z * 0.7, y = P.y, w = 3 * z, h = 3.4 * z, fl = `M${f1(x - w / 2)} ${f1(y)}Q${f1(x - w * 0.5)} ${f1(y + h * 0.8)} ${f1(x + w * 0.1)} ${f1(y + h)}Q${f1(x + w * 0.4)} ${f1(y + h * 0.5)} ${f1(x + w / 2)} ${f1(y)}Z`;
        ov += `<g>${at('rotate', `-3 ${f1(x)} ${f1(y)};4 ${f1(x)} ${f1(y)};-3 ${f1(x)} ${f1(y)}`, 5 + i, -i, SPL(2))}<path d="${fl}" fill="#000000" opacity="0.12" transform="translate(${f1(0.6 * z)} ${f1(0.9 * z)})"/><path d="${fl}" fill="#efe8d6" stroke="#b0a68c" stroke-width="${f1(0.25 * z)}"/></g>`; });
      // fresh stain with a sagging bulge + crack + the drip
      { const P = cE(G, 0.44, 0.48), z = P.z;
        s += stain(P, 19, 'st4', 1) + loc(P, `<ellipse cx="${f1(-2 * z)}" cy="${f1(-3 * z)}" rx="${f1(9 * z)}" ry="${f1(7 * z)}" fill="#ffffff" opacity="0.18" filter="url(#cb3)"/><ellipse cx="${f1(2.6 * z)}" cy="${f1(4 * z)}" rx="${f1(10 * z)}" ry="${f1(7 * z)}" fill="#5a3a14" opacity="0.2" filter="url(#cb3)"/>`
          + `<path d="M${f1(-11 * z)} ${f1(-2 * z)}L${f1(-6 * z)} ${f1(-1 * z)}L${f1(-3 * z)} ${f1(1.4 * z)}L${f1(2 * z)} ${f1(0.6 * z)}L${f1(5 * z)} ${f1(3 * z)}L${f1(10 * z)} ${f1(2.4 * z)}" stroke="#3a2a14" stroke-width="${f1(0.5 * z)}" fill="none"/><path d="M${f1(2 * z)} ${f1(0.6 * z)}l${f1(1 * z)} ${f1(-4 * z)}" stroke="#3a2a14" stroke-width="${f1(0.35 * z)}" fill="none"/>`
          + `<ellipse cx="${f1(0.4 * z)}" cy="${f1(1.4 * z)}" rx="${f1(3 * z)}" ry="${f1(2 * z)}" fill="#6a4418" opacity="0.4"/>`);
        const T = 7, dx = P.x + 0.4 * z, dy = P.y + 1.4 * z * P.q, fall = 26 * z;
        const drop = h => `M${f1(dx - 0.9 * z)} ${f1(dy)}Q${f1(dx - 0.9 * z)} ${f1(dy + h * 0.7 * z)} ${f1(dx)} ${f1(dy + h * z)}Q${f1(dx + 0.9 * z)} ${f1(dy + h * 0.7 * z)} ${f1(dx + 0.9 * z)} ${f1(dy)}Z`;
        ov += `<g>${at('translate', `0 0;0 0;0 ${f1(fall)};0 0`, T, 0, KT('0;0.8;0.9;1'))}<path d="${drop(0.3)}" fill="#cfd8d6" stroke="#8a7a5a" stroke-width="${f1(0.15 * z)}">${an('d', `${drop(0.3)};${drop(2.4)};${drop(2.6)};${drop(0.3)}`, T, 0, KT('0;0.78;0.9;1'))}${an('opacity', '0.7;1;1;0;0', T, 0, KT('0;0.78;0.86;0.9;1'))}</path><circle cx="${f1(dx - 0.3 * z)}" cy="${f1(dy + 0.6 * z)}" r="${f1(0.22 * z)}" fill="#ffffff" opacity="0.8"/></g>`; }
      return s + ov + cShade(G, 0.22, 0.04) + mould(G, 2, ['#c4bba0', '#ddd5bf'], '#f0ebdc'); }


    const { cHi } = RD.H27;
    const hp = (G, u, t, m) => { const y = G.y(t); return [G.x(u, y), cHi(G, y, m)]; };

    // BED-029 FLAT WHITE CEILING WITH 3-BLADE PADDLE FAN (T2): a freshly rolled flat white ceiling (faint roller laps, one taped seam ghosting
    // through, a nail pop) with a grey dust halo round the fan canopy; a budget white ceiling fan on a short downrod: plain white motor housing,
    // three light-oak laminate blades on white steel irons, a switch housing with a small frosted bowl light and two pull chains with wooden
    // beads; a round smoke alarm off to one side. Live: the blades turn on low, the pull chains sway and the alarm's LED blinks now and then.
    function cFan(G) { const R = rng('fan30');
      let s = `<path d="${G.tr}" fill="#f1f0ea"/>` + cBl(G, 'fan30b', 14, ['#f6f5f0', '#e2e0d6', '#ecebe4'], 0.45, 60), ov = '';
      for (let u = 0.06; u < 1; u += 0.09) s += `<path d="M${G.P(u, -0.02)}L${G.P(u + (R() - 0.5) * 0.01, 1.02)}" stroke="${R() < 0.5 ? '#ffffff' : '#dcdad0'}" stroke-width="${f1(5 * G.s)}" opacity="0.25" filter="url(#cb3)"/>`;
      s += `<path d="M${G.P(0.33, -0.02)}L${G.P(0.33, 1.02)}" stroke="#e6e4da" stroke-width="${f1(6 * G.s)}" opacity="0.6" filter="url(#cb1)"/>`;
      { const P = cE(G, 0.2, 0.7), z = P.z; s += loc(P, `<circle r="${f1(0.9 * z)}" fill="#f8f8f4"/><circle r="${f1(0.9 * z)}" fill="none" stroke="#c8c4b8" stroke-width="${f1(0.2 * z)}" stroke-dasharray="${f1(0.5 * z)} ${f1(0.3 * z)}"/>`); }
      // smoke alarm
      { const P = cE(G, 0.8, 0.3), z = P.z;
        s += loc(P, `<circle r="${f1(5.6 * z)}" fill="#000000" opacity="0.08" filter="url(#cb1)"/><circle r="${f1(5.2 * z)}" fill="#f8f8f4" stroke="#d0cec4" stroke-width="${f1(0.3 * z)}"/><circle r="${f1(3.8 * z)}" fill="none" stroke="#dedcd2" stroke-width="${f1(0.25 * z)}"/>`
          + rep(12, k => `<path d="M${f1(Math.cos(k * PI / 6) * 2.4 * z)} ${f1(Math.sin(k * PI / 6) * 2.4 * z)}L${f1(Math.cos(k * PI / 6) * 3.4 * z)} ${f1(Math.sin(k * PI / 6) * 3.4 * z)}" stroke="#bcbab0" stroke-width="${f1(0.5 * z)}"/>`).join('')
          + `<circle r="${f1(1.4 * z)}" fill="#efeee8" stroke="#cfcdc4" stroke-width="${f1(0.2 * z)}"/><circle cx="${f1(3 * z)}" cy="${f1(-3 * z)}" r="${f1(0.45 * z)}" fill="#e83a2a" opacity="0.2">${an('opacity', '0.2;0.2;1;0.2', 9, 0, KT('0;0.9;0.93;1'))}</circle>`); }
      // fan
      { const P = cE(G, 0.5, 0.5), z = P.z, hy = cHi(G, P.y, 0.93), H = { x: P.x, y: hy, q: P.q }, L = 31 * z;
        s += '<g filter="url(#cb6)">' + loc(P, `<circle r="${f1(L * 0.9)}" fill="#9a968a" opacity="0.18"/><circle r="${f1(L * 0.5)}" fill="#f4f3ee" opacity="0.5"/>`) + '</g>';
        s += loc(P, `<ellipse rx="${f1(4 * z)}" ry="${f1(4 * z)}" fill="#f6f6f2" stroke="#c8c6bc" stroke-width="${f1(0.3 * z)}"/>`)
          + `<path d="M${f1(P.x)} ${f1(P.y)}V${f1(hy)}" stroke="#e8e6de" stroke-width="${f1(1.4 * z)}"/><path d="M${f1(P.x - 0.4 * z)} ${f1(P.y)}V${f1(hy)}" stroke="#ffffff" stroke-width="${f1(0.4 * z)}"/>`
          + `<path d="M${f1(P.x)} ${f1(P.y + 1.4 * z)}V${f1(hy)}" stroke="#c4c2b8" stroke-width="${f1(0.3 * z)}" transform="translate(${f1(0.6 * z)} 0)"/>`;
        // motor housing (seen from below: a drum with a band)
        s += loc(H, `<ellipse rx="${f1(7.6 * z)}" ry="${f1(7.6 * z)}" fill="#e8e6de" stroke="#b8b6aa" stroke-width="${f1(0.3 * z)}"/><ellipse rx="${f1(6.2 * z)}" ry="${f1(6.2 * z)}" fill="#f4f3ee"/>`);
        // blades: light-oak laminate on white irons, turning on low
        const blade = `<path d="M${f1(5 * z)} ${f1(-1.2 * z)}L${f1(9 * z)} ${f1(-1.8 * z)}L${f1(9 * z)} ${f1(1.8 * z)}L${f1(5 * z)} ${f1(1.2 * z)}Z" fill="#f0efe8" stroke="#b8b6aa" stroke-width="${f1(0.25 * z)}"/>`
          + `<path d="M${f1(8.4 * z)} ${f1(-2.8 * z)}H${f1(L)}Q${f1(L + 2.4 * z)} 0 ${f1(L)} ${f1(2.8 * z)}H${f1(8.4 * z)}Z" fill="url(#k30o)" stroke="#8a6a44" stroke-width="${f1(0.25 * z)}"/>`
          + rep(5, k => `<path d="M${f1(9 * z)} ${f1((-2 + k) * z)}Q${f1(16 * z)} ${f1((-2 + k + (R() - 0.5) * 0.6) * z)} ${f1(L)} ${f1((-2 + k) * z)}" stroke="#a8804e" stroke-width="${f1(0.15 * z)}" fill="none" opacity="0.5"/>`).join('')
          + `<path d="M${f1(9 * z)} ${f1(-2.6 * z)}H${f1(L - 1 * z)}" stroke="#ffffff" stroke-width="${f1(0.25 * z)}" opacity="0.5"/><circle cx="${f1(7.4 * z)}" cy="${f1(-0.8 * z)}" r="${f1(0.3 * z)}" fill="#8a887e"/><circle cx="${f1(7.4 * z)}" cy="${f1(0.8 * z)}" r="${f1(0.3 * z)}" fill="#8a887e"/>`;
        const blades = rep(3, k => `<g transform="rotate(${k * 120})">${blade}</g>`).join('');
        ov += loc(H, `<circle r="${f1(L + 1 * z)}" fill="#c8a070" opacity="0.08"/><g>${at('rotate', '0;360', 2.6)}${blades}</g>`);
        // switch housing + frosted bowl + pull chains
        const by = cHi(G, P.y, 0.905), B = { x: P.x, y: by, q: P.q };
        ov += loc(H, `<ellipse rx="${f1(4.6 * z)}" ry="${f1(4.6 * z)}" fill="#f4f3ee" stroke="#b8b6aa" stroke-width="${f1(0.3 * z)}"/>`)
          + `<path d="M${f1(P.x - 3.4 * z)} ${f1(hy)}V${f1(by)}M${f1(P.x + 3.4 * z)} ${f1(hy)}V${f1(by)}" stroke="#d8d6cc" stroke-width="${f1(0.6 * z)}"/><rect x="${f1(P.x - 3.4 * z)}" y="${f1(hy)}" width="${f1(6.8 * z)}" height="${f1(by - hy)}" fill="#efeee8"/>`
          + loc(B, `<circle r="${f1(4.8 * z)}" fill="#fff6e0" opacity="0.5" filter="url(#cb3)"/><circle r="${f1(3.8 * z)}" fill="url(#k30b)" stroke="#d8d4c8" stroke-width="${f1(0.25 * z)}"/><ellipse cx="${f1(-1.2 * z)}" cy="${f1(-1.2 * z)}" rx="${f1(1.2 * z)}" ry="${f1(0.8 * z)}" fill="#ffffff" opacity="0.7"/>`);
        [[-2.2, 7.4, 0], [2.2, 5.6, 1.1]].forEach(([dx, len, ph]) => { const x = P.x + dx * z, y = by - 0.4 * z;
          ov += `<g>${at('rotate', `-6 ${f1(x)} ${f1(y)};6 ${f1(x)} ${f1(y)};-6 ${f1(x)} ${f1(y)}`, 3.2, -ph, SPL(2))}<path d="M${f1(x)} ${f1(y)}V${f1(y + len * z)}" stroke="#b8a888" stroke-width="${f1(0.3 * z)}" stroke-dasharray="${f1(0.35 * z)} ${f1(0.15 * z)}"/><ellipse cx="${f1(x)}" cy="${f1(y + (len + 0.8) * z)}" rx="${f1(0.6 * z)}" ry="${f1(0.9 * z)}" fill="#b8865a"/><ellipse cx="${f1(x - 0.2 * z)}" cy="${f1(y + (len + 0.5) * z)}" rx="${f1(0.18 * z)}" ry="${f1(0.3 * z)}" fill="#e8c090"/></g>`; }); }
      return s + ov + `<defs><linearGradient id="k30o" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#c49a64"/><stop offset="0.5" stop-color="#d8b07a"/><stop offset="1" stop-color="#c09460"/></linearGradient><radialGradient id="k30b" cx="0.4" cy="0.4"><stop offset="0" stop-color="#ffffff"/><stop offset="0.7" stop-color="#f4f0e4"/><stop offset="1" stop-color="#d8d2c2"/></radialGradient></defs>`
        + cShade(G, 0.18, 0.05) + mould(G, 2, ['#e4e2da', '#f4f3ee'], '#ffffff'); }

    // BED-049 VAULTED SHIPLAP WOOD CEILING WITH EXPOSED BEAM (T3): white-washed pine shiplap boards running up both slopes of a vault to the ridge (the
    // left slope catching more light than the right), every board a hair different with soft grain and a dark nickel gap, a few knots ghosting through
    // the wash; a chunky rough-sawn oak ridge beam with saw marks, drying checks and black iron strap brackets with bolt heads. Live: a warm band of
    // late sun from the gable window slides across the boards with dust motes glinting in it.
    function cShip(G) { const R = rng('ship30'), NB = 34, u0 = 0.462, u1 = 0.538, MB = 0.94;
      let s = '', gaps = '', gr = '';
      for (let i = 0; i < NB; i++) { const a = i / NB, b = (i + 1) / NB, lit = a < 0.5 ? 1.02 - a * 0.08 : 0.94 - (a - 0.5) * 0.1;
        s += `<path d="${G.quad(a, -0.02, b, 1.02)}" fill="${shade('#ece5d6', lit * (0.97 + R() * 0.05))}"/>`;
        gaps += `M${G.P(b, -0.02)}L${G.P(b, 1.02)}`;
        rep(3, () => { const u = a + R() * (b - a), t0 = R() * 0.8; gr += `M${G.P(u, t0)}L${G.P(u + (R() - 0.5) * 0.004, t0 + 0.1 + R() * 0.3)}`; });
        if (R() < 0.25) { const P = cE(G, a + (b - a) / 2, 0.1 + R() * 0.8); s += cEl(P, 1.4 * P.z, 2.4 * P.z * P.q * 2, 'fill="#b8a07a" opacity="0.4"'); } }
      s += `<path d="${gr}" stroke="#c8b894" stroke-width="${f1(0.3 * G.s)}" opacity="0.5"/><path d="${gaps}" stroke="#6a5a44" stroke-width="${f1(0.7 * G.s)}" opacity="0.75"/><path d="${gaps}" stroke="#fffaf0" stroke-width="${f1(0.3 * G.s)}" opacity="0.6" transform="translate(${f1(0.5 * G.s)} 0)"/>`;
      // vault shading toward the ridge
      s += `<path d="${G.quad(0.5, -0.02, 1.02, 1.02)}" fill="#5a4a30" opacity="0.08"/><path d="${G.quad(0.38, -0.02, 0.5, 1.02)}" fill="#ffffff" opacity="0.06"/>`;
      // sliding sunbeam with motes
      { const sb = `<path d="${G.quad(-0.1, -0.02, 0.06, 1.02)}" fill="#ffd89a" opacity="0.26" filter="url(#cb3)"/>` + rep(14, () => { const P = cE(G, -0.08 + R() * 0.12, 0.1 + R() * 0.85); return `<circle cx="${f1(P.x)}" cy="${f1(P.y)}" r="${f1(0.5 * P.z)}" fill="#fff4d0" opacity="0">${an('opacity', '0;0.9;0', f1(2 + R() * 3), -R() * 4, SPL(2))}</circle>`; }).join('');
        s += `<g>${at('translate', `${f1(-G.W * 0.1)} 0;${f1(G.W * 1.1)} 0`, 36, 0)}${sb}</g>`; }
      // ridge beam (hangs below the boards): sides + soffit, saw marks, checks, iron straps
      const TS = rep(13, i => -0.02 + 1.04 * i / 12), side = (u, col) => `<path d="M${TS.map(t => P2(hp(G, u, t, 1))).join('L')}L${TS.slice().reverse().map(t => P2(hp(G, u, t, MB))).join('L')}Z" fill="${col}"/>`;
      s += `<path d="M${TS.map(t => P2(hp(G, u1 + 0.02, t, 1))).join('L')}L${TS.slice().reverse().map(t => P2(hp(G, u1 + 0.05, t, 1))).join('L')}Z" fill="#3a2a18" opacity="0.18" filter="url(#cb3)"/>`;
      s += side(u0, '#8a6644') + side(u1, '#5e4228');
      const sof = 'M' + TS.map(t => P2(hp(G, u0, t, MB))).join('L') + 'L' + TS.slice().reverse().map(t => P2(hp(G, u1, t, MB))).join('L') + 'Z';
      let bm = `<path d="${sof}" fill="#76563a"/>`;
      rep(10, k => { const u = u0 + (u1 - u0) * (k + 0.5) / 10; bm += `<path d="M${TS.map(t => P2(hp(G, u + Math.sin(t * 9 + k) * 0.002, t, MB))).join('L')}" stroke="${k % 3 ? '#5a3e24' : '#9a7a54'}" stroke-width="${f1(0.4 * G.s)}" fill="none" opacity="0.55"/>`; });
      rep(14, () => { const t = R(), y = G.y(t), a = hp(G, u0, t, MB), b = hp(G, u1, t, MB); bm += `<path d="M${P2(a)}Q${f1((a[0] + b[0]) / 2)} ${f1(a[1] + 1.2 * G.z(y))} ${P2(b)}" stroke="#4a3220" stroke-width="${f1(0.3 * G.z(y))}" fill="none" opacity="0.35"/>`; });
      [[0.49, 0.12, 0.42], [0.51, 0.55, 0.85]].forEach(([u, t0, t1]) => bm += `<path d="M${rep(8, i => P2(hp(G, u + (R() - 0.5) * 0.004, t0 + (t1 - t0) * i / 7, MB))).join('L')}" stroke="#24160a" stroke-width="${f1(0.8 * G.s)}" fill="none"/>`);
      s += bm;
      // iron straps
      [0.08, 0.36, 0.64, 0.92].forEach(t => { const y = G.y(t), z = G.z(y), dt = 0.009, q = (u, tt, m) => P2(hp(G, u, tt, m));
        s += `<path d="M${q(u0 - 0.008, t - dt, 1)}L${q(u0, t - dt, 1)}L${q(u0, t - dt, MB)}L${q(u1, t - dt, MB)}L${q(u1, t - dt, 1)}L${q(u1 + 0.008, t - dt, 1)}L${q(u1 + 0.008, t + dt, 1)}L${q(u1, t + dt, 1)}L${q(u1, t + dt, MB)}L${q(u0, t + dt, MB)}L${q(u0, t + dt, 1)}L${q(u0 - 0.008, t + dt, 1)}Z" fill="#26241f"/>`
          + `<path d="M${q(u0, t - dt, MB)}L${q(u1, t - dt, MB)}" stroke="#6a665c" stroke-width="${f1(0.3 * z)}"/>`
          + [u0 + 0.012, u1 - 0.012].map(u => { const p = hp(G, u, t, MB); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.9 * z)}" fill="#3a3832"/><circle cx="${f1(p[0] - 0.25 * z)}" cy="${f1(p[1] - 0.25 * z)}" r="${f1(0.3 * z)}" fill="#8a867a"/>`; }).join(''); });
      return s + cShade(G, 0.16, 0.05) + mould(G, 2, ['#ddd4c2', '#efe8da'], '#fbf8f0'); }

    // BED-069 TRAY CEILING WITH CONCEALED WARM COVE ILLUMINATION (T4): a smooth warm-greige satin ceiling stepping up into a deep tray framed by a
    // white crown moulding; inside, champagne Venetian plaster with soft polished clouding, washed by warm light from an LED strip hidden on the cove
    // ledge (brightest at the edges, fading to the middle), a hand-cast plaster ceiling rose at the centre and four trimless pin lights in the outer
    // band. Live: the cove glow breathes softly and a slow sheen drifts across the polished plaster.
    function cTray(G) { const R = rng('tray30'), u0 = 0.17, u1 = 0.83, t0 = 0.14, t1 = 0.8, M = 1.05;
      let s = `<path d="${G.tr}" fill="#e6ddcf"/>` + cBl(G, 'tray30b', 12, ['#ece4d8', '#dcd2c2'], 0.4, 60);
      const O = G.quad(u0, t0, u1, t1), US = rep(9, i => u0 + (u1 - u0) * i / 8), TS = rep(9, i => t0 + (t1 - t0) * i / 8);
      const Q = (u, t) => P2(hp(G, u, t, M)), iq = `M${Q(u0, t0)}L${Q(u1, t0)}L${Q(u1, t1)}L${Q(u0, t1)}Z`;
      // inner plaster
      const c = cE(G, 0.5, (t0 + t1) / 2), z = c.z;
      let v = `<path d="${iq}" fill="url(#k30v)"/>`;
      v += '<g filter="url(#cb6)" opacity="0.45">' + rep(18, () => { const p = hp(G, u0 + R() * (u1 - u0), t0 + R() * (t1 - t0), M); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1((10 + R() * 16) * z)}" ry="${f1((3 + R() * 4) * z)}" fill="${R() < 0.5 ? '#f8ecd2' : '#c8b088'}"/>`; }).join('') + '</g>';
      v += rep(10, () => { const p = hp(G, u0 + R() * (u1 - u0), t0 + R() * (t1 - t0), M); return `<path d="M${f1(p[0])} ${f1(p[1])}q${f1(6 * z)} ${f1(-1.5 * z)} ${f1(12 * z)} ${f1(0.5 * z)}" stroke="#fff8e8" stroke-width="${f1(0.5 * z)}" fill="none" opacity="0.35"/>`; }).join('');
      v += `<rect x="${f1(-G.W * 0.3)}" y="0" width="${f1(G.W * 0.12)}" height="${f1(G.H)}" fill="url(#k30h)" transform="skewX(-30)">${an('x', `${f1(-G.W * 0.3)};${f1(G.W * 1.3)}`, 22)}</rect>`;
      // cove glow (breathing): strong at the edges of the tray ceiling
      v += `<g opacity="0.9">${an('opacity', '0.75;1;0.75', 8, 0, SPL(2))}<path d="${iq}" fill="none" stroke="#ffc878" stroke-width="${f1(26 * z)}" opacity="0.38" filter="url(#cb6)"/><path d="${iq}" fill="none" stroke="#ffe4b0" stroke-width="${f1(8 * z)}" opacity="0.45" filter="url(#cb3)"/></g>`;
      // ceiling rose
      { const p = hp(G, 0.5, (t0 + t1) / 2, M), P = { x: p[0], y: p[1], q: c.q };
        v += loc(P, `<circle r="${f1(12 * z)}" fill="#000000" opacity="0.06" filter="url(#cb3)"/><circle r="${f1(11 * z)}" fill="#f4ecdc"/>` + rep(16, k => `<path d="M0 ${f1(-5 * z)}Q${f1(2.6 * z)} ${f1(-8 * z)} 0 ${f1(-10.6 * z)}Q${f1(-2.6 * z)} ${f1(-8 * z)} 0 ${f1(-5 * z)}Z" fill="#fbf6ea" stroke="#d4c6a8" stroke-width="${f1(0.25 * z)}" transform="rotate(${k * 22.5})"/>`).join('')
          + `<circle r="${f1(5 * z)}" fill="none" stroke="#d8ccb0" stroke-width="${f1(0.6 * z)}"/><circle r="${f1(3.4 * z)}" fill="#f8f2e4" stroke="#d4c6a8" stroke-width="${f1(0.3 * z)}"/><circle r="${f1(1.2 * z)}" fill="#e8dcc4"/>`); }
      // recess faces: far face (lit hardest), sides
      const face = (A, col, lit) => `<path d="M${A.map(a => P2(hp(G, a[0], a[1], 1))).join('L')}L${A.slice().reverse().map(a => P2(hp(G, a[0], a[1], M))).join('L')}Z" fill="${col}"/>` + (lit ? `<path d="M${A.map(a => P2(hp(G, a[0], a[1], M))).join('L')}" stroke="#ffd890" stroke-width="${f1(2 * z)}" opacity="0.6" filter="url(#cb1)"/>` : '');
      v += face(TS.map(t => [u0, t]), '#efe6d6', 1) + face(TS.map(t => [u1, t]), '#d8cebc', 1) + face(US.map(u => [u, t1]), '#f6eedc', 1);
      s += `<clipPath id="k30t"><path d="${O}"/></clipPath><g clip-path="url(#k30t)">${v}</g>`;
      // crown moulding round the opening + the warm light line at the cove lip
      s += `<path d="${O}" fill="none" stroke="#bfb29a" stroke-width="${f1(4 * G.s)}"/><path d="${O}" fill="none" stroke="#fbf8f0" stroke-width="${f1(2.4 * G.s)}"/><path d="${O}" fill="none" stroke="#d8ccb4" stroke-width="${f1(0.6 * G.s)}" transform="translate(0 ${f1(1 * G.s)})"/>`
        + `<path d="${O}" fill="none" stroke="#ffd08a" stroke-width="${f1(1.2 * G.s)}" opacity="0.7">${an('opacity', '0.55;0.85;0.55', 8, 0, SPL(2))}</path>`;
      // pin lights in the outer band
      [[0.07, 0.24], [0.93, 0.24], [0.07, 0.86], [0.93, 0.86]].forEach(([u, t]) => { const P = cE(G, u, t), k = P.z;
        s += '<g filter="url(#cb3)">' + cEl(P, 7 * k, 7 * k * P.q, 'fill="#ffe0a8" opacity="0.35"') + '</g>' + cEl(P, 1.3 * k, 1.3 * k * P.q, 'fill="#3a3430"') + cEl(P, 0.8 * k, 0.8 * k * P.q, 'fill="#fff4d8"'); });
      return s + `<defs><linearGradient id="k30v" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e8d8b8"/><stop offset="0.5" stop-color="#dcc8a2"/><stop offset="1" stop-color="#d2bc94"/></linearGradient>`
        + `<linearGradient id="k30h" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff8e8" stop-opacity="0"/><stop offset="0.5" stop-color="#fff8e8" stop-opacity="0.3"/><stop offset="1" stop-color="#fff8e8" stop-opacity="0"/></linearGradient></defs>`
        + cShade(G, 0.14, 0.05) + mould(G, 3, ['#d6ccb8', '#ebe3d4', '#f6f1e6'], '#ffffff'); }


    // BED-089 3D HOLOGRAPHIC AURORA BOREALIS & DEEP-SPACE SLEEP DOME (T5): a deep night-blue lacquered ceiling with a fine gold pinstripe, opening
    // into a great shallow dome framed by a champagne-gold rim; the dome falls away into deep space (rings darkening to the apex): a dense
    // starfield, soft rose / violet / amber nebula clouds and the milky way, with aurora curtains in emerald fading to rose hanging across it;
    // a warm amber reveal glows round the rim. Live: the sky turns slowly, the aurora curtains ripple and drift, stars twinkle, a shooting star
    // crosses now and then and the rim light breathes.
    function cAurora(G) { const R = rng('aur30'), P = cE(G, 0.5, 0.52), z = P.z, q = P.q, rowW = G.x(1, P.y) - G.x(0, P.y), RX = Math.min(rowW * 0.31, G.H * 0.52 / q), NR = 12;
      let s = `<path d="${G.tr}" fill="#1c1e30"/>` + cBl(G, 'aur30b', 14, ['#242640', '#16182a', '#2a2238'], 0.6, 60);
      s += rep(40, () => { const Q = cE(G, R() * 1.1 - 0.05, 0.03 + R() * 0.95), rx = (10 + R() * 16) * Q.z, a0 = R() * 2 * PI; return `<path d="M${rep(7, k => { const a = a0 + 1.4 * k / 6; return P2([Q.x + Math.cos(a) * rx, Q.y + Math.sin(a) * rx * Q.q]); }).join('L')}" stroke="#34365a" stroke-width="${f1(2.4 * Q.z)}" fill="none" opacity="0.16"/>`; }).join('');
      // gold pinstripe inset round the room
      s += `<path d="${G.quad(0.04, 0.05, 0.96, 0.95)}" fill="none" stroke="#c8a860" stroke-width="${f1(0.6 * G.s)}" opacity="0.8"/>`;
      const ringY = k => { const f = k / NR, ph = f * PI / 2; return { r: RX * Math.cos(ph * 0.92), y: P.y - RX * q * 0.5 * Math.sin(ph) }; };
      let d = '';
      for (let k = 0; k < NR; k++) { const a = ringY(k), f = k / NR; d += `<ellipse cx="${f1(P.x)}" cy="${f1(a.y)}" rx="${f1(a.r)}" ry="${f1(a.r * q)}" fill="${shade('#1a2040', 1 - f * 0.55)}"/>`; }
      const top = ringY(NR - 1), cy = (P.y + top.y) / 2;
      // sky group (turns slowly about the dome centre, foreshortened)
      let sky = '';
      sky += '<g filter="url(#cb6)">' + [[-0.4, -0.2, '#c87aa8', 0.32], [0.35, 0.15, '#8a6ad8', 0.3], [0.1, -0.45, '#e8a860', 0.22], [-0.2, 0.45, '#6a8ae0', 0.22]].map(([dx, dy, c, o]) => `<ellipse cx="${f1(dx * RX)}" cy="${f1(dy * RX)}" rx="${f1(RX * 0.45)}" ry="${f1(RX * 0.25)}" fill="${c}" opacity="${o}"/>`).join('') + '</g>';
      sky += `<g filter="url(#cb3)"><path d="M${f1(-RX)} ${f1(RX * 0.3)}Q0 ${f1(-RX * 0.1)} ${f1(RX)} ${f1(-RX * 0.5)}" stroke="#f4e0d0" stroke-width="${f1(RX * 0.16)}" fill="none" opacity="0.14"/></g>`;
      sky += rep(240, () => { const a = R() * 2 * PI, r = Math.sqrt(R()) * RX, s0 = 0.15 + Math.pow(R(), 4) * 0.9; return `<circle cx="${f1(Math.cos(a) * r)}" cy="${f1(Math.sin(a) * r)}" r="${f1(s0 * z)}" fill="${['#ffffff', '#fff2d8', '#f8e0f0', '#e0e8ff'][(R() * 4) | 0]}" opacity="${f1(0.5 + R() * 0.5)}">${s0 > 0.6 ? an('opacity', '1;0.3;1', n4(2 + R() * 4), n4(-R() * 4), SPL(2)) : ''}</circle>`; }).join('');
      d += `<g transform="translate(${f1(P.x)} ${f1(cy)}) scale(1 ${n4(q)})"><g>${at('rotate', '0;360', 240)}${sky}</g></g>`;
      // aurora curtains: rippling ribbons, emerald below to rose on top
      rep(4, i => { const x0 = P.x - RX * 0.8, x1 = P.x + RX * 0.8, yb = cy + RX * q * (0.1 + i * 0.12) - RX * q * 0.15, h = RX * q * (0.8 + R() * 0.3), w = (n, ph) => { let o = `M${f1(x0)} ${f1(yb)}`; for (let j = 1; j <= 8; j++) { const x = x0 + (x1 - x0) * j / 8; o += `Q${f1(x - (x1 - x0) / 16)} ${f1(yb + Math.sin(j * 1.3 + ph + n) * RX * q * 0.18)} ${f1(x)} ${f1(yb + Math.sin(j * 0.9 + ph) * RX * q * 0.1)}`; } return o; };
        const A = w(0, i), B = w(1.6, i + 0.8), band = p => `${p}l0 ${f1(-h)}L${f1(x0)} ${f1(yb - h)}Z`, T = 11 + i * 3;
        d += `<path d="${band(A)}" fill="url(#k30a)" opacity="${f1(0.42 - i * 0.06)}" filter="url(#cb3)">${an('d', `${band(A)};${band(B)};${band(A)}`, T, -i * 2, SPL(2))}<animateTransform attributeName="transform" type="translate" values="${f1(-RX * 0.06)} 0;${f1(RX * 0.06)} 0;${f1(-RX * 0.06)} 0" dur="${T * 1.7}s" repeatCount="indefinite"/></path>`
          + `<path d="${A}" stroke="#c8ffd8" stroke-width="${f1(1.4 * z)}" fill="none" opacity="${f1(0.35 - i * 0.05)}" filter="url(#cb1)">${an('d', `${A};${B};${A}`, T, -i * 2, SPL(2))}</path>`; });
      // shooting star
      d += `<g opacity="0">${an('opacity', '0;0;1;0;0', 15, 0, KT('0;0.7;0.73;0.78;1'))}<path d="M0 0l${f1(-14 * z)} ${f1(5 * z)}" stroke="url(#k30m)" stroke-width="${f1(0.6 * z)}" stroke-linecap="round"/><circle r="${f1(0.6 * z)}" fill="#ffffff"/>${at('translate', `${f1(P.x + RX * 0.4)} ${f1(cy - RX * q * 0.4)};${f1(P.x + RX * 0.4)} ${f1(cy - RX * q * 0.4)};${f1(P.x - RX * 0.2)} ${f1(cy - RX * q * 0.1)};${f1(P.x - RX * 0.2)} ${f1(cy - RX * q * 0.1)}`, 15, 0, KT('0;0.7;0.78;1'))}</g>`;
      // dome edge shading (the dome curves away)
      d += `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(RX)}" ry="${f1(RX * q)}" fill="url(#k30d)"/>`;
      s += `<clipPath id="k30c"><ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(RX)}" ry="${f1(RX * q)}"/></clipPath><g clip-path="url(#k30c)">${d}</g>`;
      // amber reveal glow + champagne-gold rim
      s += `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(RX + 4 * z)}" ry="${f1((RX + 4 * z) * q)}" fill="none" stroke="#ffb860" stroke-width="${f1(8 * z)}" opacity="0.5" filter="url(#cb3)">${an('opacity', '0.35;0.65;0.35', 9, 0, SPL(2))}</ellipse>`
        + `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(RX + 1.4 * z)}" ry="${f1((RX + 1.4 * z) * q)}" fill="none" stroke="#8a6a32" stroke-width="${f1(3.4 * z)}"/><ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(RX + 1.4 * z)}" ry="${f1((RX + 1.4 * z) * q)}" fill="none" stroke="url(#k30g)" stroke-width="${f1(2.4 * z)}"/>`
        + `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(RX + 0.6 * z)}" ry="${f1((RX + 0.6 * z) * q)}" fill="none" stroke="#fff4d0" stroke-width="${f1(0.4 * z)}" opacity="0.8"/>`;
      return s + `<defs><linearGradient id="k30a" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#7affb0" stop-opacity="0.9"/><stop offset="0.35" stop-color="#4ad8a0" stop-opacity="0.6"/><stop offset="0.7" stop-color="#d878c8" stop-opacity="0.35"/><stop offset="1" stop-color="#f8a0c0" stop-opacity="0"/></linearGradient>`
        + `<radialGradient id="k30d"><stop offset="0.7" stop-color="#05060e" stop-opacity="0"/><stop offset="1" stop-color="#05060e" stop-opacity="0.75"/></radialGradient>`
        + `<linearGradient id="k30g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f8e4a8"/><stop offset="0.45" stop-color="#c8a050"/><stop offset="0.7" stop-color="#f4dca0"/><stop offset="1" stop-color="#9a7838"/></linearGradient>`
        + `<linearGradient id="k30m" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`
        + cShade(G, 0.2, 0.04) + mould(G, 2, ['#1a1a2a', '#2a2a3e'], '#c8a860'); }

    const CEIL30 = { spot: cSpot, fan: cFan, ship: cShip, tray: cTray, aur: cAurora }, CM30 = {};
    const WALL30 = { spot: 'bd01dry', fan: 'bd21lav', ship: 'bd41chin', tray: 'bd61vel', aur: 'bd81silk' }, CB30 = { spot: ['#e6dec8', '#d2c8b0'], fan: ['#f1f0ea', '#f4f3ee'], ship: ['#ece5d6', '#efe8da'], tray: ['#e6ddcf', '#f6f1e6'], aur: ['#1c1e30', '#c8a860'] }, WS30 = { spot: '#d8d0bc', fan: '#c4b6dc', ship: '#cfdbc9', tray: '#5e3a26', aur: '#2c2a52' };
    const cardOf30 = k => { const G = mkV(CFRM.card), S = SURF12[WALL30[k]](), ws = WS30[k];
      return `<svg x="16" y="26" width="48" height="30" viewBox="0 0 80 56" preserveAspectRatio="xMidYMax slice">${wTile(S)}</svg><path d="M0 0L16 26V56H0Z" fill="${shade(ws, 0.86)}"/><path d="M80 0L64 26V56H80Z" fill="${shade(ws, 0.78)}"/><path d="M16 26V56M64 26V56" stroke="#000000" stroke-opacity="0.2" stroke-width="0.6"/>`
        + cDoc(G, CEIL30[k](G)) + `<path d="${G.tr}" fill="none" stroke="#000000" stroke-opacity="0.25" stroke-width="0.5"/>`; };
    const draw30c = RD.draw;
    RD.draw = (r, o) => { const res = draw30c(r, o); if (!res || res._p30c) return res;
      try { const c = r.c30 && CEIL30[r.c30]; if (c && res.surf) { res._p30c = 1; res.vb = '0 0 80 56';
          const M = CM30[r.c30] || (CM30[r.c30] = (() => { const G = mkV(CFRM.room); return { svg: RD.svgDoc('0 0 80 56', [], cardOf30(r.c30)), room: RD.svgDoc('0 0 ' + G.W + ' ' + G.H, [], cDoc(G, c(G))) }; })());
          res.svg = M.svg; res.src = 'data:image/svg+xml,' + encodeURIComponent(M.svg); res.ceilRoom = M.room; res.ceilBase = CB30[r.c30][0]; res.ceilTrim = CB30[r.c30][1]; } } catch (e) { console.warn('reno plus30 ceil', r.id, e); }
      return res; };
    RD.H30C = { CEIL30, cardOf30 };
  }


  // ======================= BEDROOM CHANDELIERS (BED-010/030/050/070/090): were flat 'light' swatches, now hanging pieces like the Living Room (plus21)
  // and Kitchen (plus27) lights: spec + s3 null, mount 'ceil'; Squad House v6 initH migration s.bed30 hangs the one in use =======================
  { const { cyl3 } = RD.H15;
    const DEFL = '<filter id="l30b1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.8"/></filter><filter id="l30b3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>'
      + '<radialGradient id="l30g" cx="45%" cy="40%" r="60%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.5" stop-color="#fff4d0"/><stop offset="1" stop-color="#f4d898"/></radialGradient><radialGradient id="l30w" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff0c0" stop-opacity="0.85"/><stop offset="0.35" stop-color="#ffd27a" stop-opacity="0.35"/><stop offset="1" stop-color="#ffc060" stop-opacity="0"/></radialGradient>';
    const glow = (C, q, r, op, A) => { const c = C.P(q); return `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * C.k)}" fill="url(#l30w)" opacity="${op}">${A || ''}</circle>`; };
    const swing = (C, q, deg, T, b) => { const c = C.P(q); return `<animateTransform attributeName="transform" type="rotate" values="${-deg} ${P2(c)};${deg} ${P2(c)};${-deg} ${P2(c)}" dur="${n4(T)}s" begin="${n4(b || 0)}s" repeatCount="indefinite"${SPL(2)}/>`; };
    const FLK = (T, b) => an('opacity', '1;0.86;1;0.62;1;1', T, b, ' keyTimes="0;0.3;0.45;0.5;0.56;1"');
    const ring = (C, y, r, a0, a1, n) => rep(n + 1, i => { const a = a0 + (a1 - a0) * i / n; return C.p(r * Math.sin(a), y, r * Math.cos(a)); });
    const sph = (C, q, r, col, o) => H.sph(C, q, r, col, o);
    const vis = (C, a) => Math.cos(a - C.thV) > 0.02;

    // BED-010 BARE BULB WITH PAPER ORIGAMI SHADE (T1): a yellowed plastic ceiling rose with paint overspray, a twisted white flex, a cream bakelite
    // lampholder and a bare pear bulb hanging half out of a home-folded paper shade: a faceted origami lantern in cheap printer paper, a bit
    // lopsided, one facet split and mended with tape and a brown scorch where it sits too close to the bulb. Live: the bulb flickers now and then,
    // the paper glows warm and the whole thing sways in the draught.
    N.bulb30 = S => { const T = 40, D = { w: 30, d: 30, zs: 1.6, mount: 'ceil', build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, v = C.v, R = rng('bulb30'), N8 = 8, st = 2 * PI / N8;
        const pt = (r, y, a) => [r * Math.sin(a), y, r * Math.cos(a)];
        const TP = rep(N8, i => pt(3.4, 23, i * st)), MD = rep(N8, i => pt(10.4, 18.2, (i + 0.5) * st + 0.08)), BT = rep(N8, i => pt(7.2, 13.4, (i + 1) * st));
        const F = [];
        rep(N8, i => { const j = (i + 1) % N8; F.push([TP[i], TP[j], MD[i]], [TP[j], MD[i], MD[j]], [MD[i], BT[i], MD[j]], [BT[i], MD[j], BT[j]]); });
        const nrm = f => { const [a, b, c] = f, u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], w = [c[0] - a[0], c[1] - a[1], c[2] - a[2]], n = [u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]], m = [(a[0] + b[0] + c[0]) / 3, 0, (a[2] + b[2] + c[2]) / 3], sg = n[0] * m[0] + n[2] * m[2] < 0 ? -1 : 1; return n.map(x => x * sg / (Math.hypot(...n) || 1)); };
        const dep = f => f.reduce((s, p) => s + p[0] * v[0] + p[1] * v[1] + p[2] * v[2], 0) / 3;
        const poly = (f, fill, ex) => `<path d="M${f.map(p => P2(C.P(p))).join('L')}Z" fill="${fill}" stroke="#c8a46a" stroke-width="${f1(0.18 * k)}" stroke-linejoin="round" ${ex || ''}/>`;
        const fs = F.map((f, i) => ({ f, i, n: nrm(f), d: dep(f) })).sort((a, b) => a.d - b.d);
        let back = '', front = '';
        fs.forEach(o => { const fr = o.n[0] * v[0] + o.n[1] * v[1] + o.n[2] * v[2] > 0, lum = 0.9 + 0.12 * (o.n[0] * -0.5 + o.n[1] * 0.6 + o.n[2] * 0.4);
          if (!fr) back += poly(o.f, shade('#f0cf90', 0.9 + (o.i % 3) * 0.04));
          else front += poly(o.f, shade('#fde6b4', Math.min(1.1, lum + (o.i % 2) * 0.05)), `opacity="0.94"`) + (o.i === 9 ? (() => { const c = C.P([(o.f[0][0] + o.f[1][0] + o.f[2][0]) / 3, (o.f[0][1] + o.f[1][1] + o.f[2][1]) / 3, (o.f[0][2] + o.f[1][2] + o.f[2][2]) / 3]); return `<rect x="${f1(c[0] - 1.6 * k)}" y="${f1(c[1] - 0.6 * k)}" width="${f1(3.2 * k)}" height="${f1(1.2 * k)}" fill="#efe2a8" opacity="0.55" transform="rotate(-24 ${f1(c[0])} ${f1(c[1])})"/><path d="M${f1(c[0] - 0.8 * k)} ${f1(c[1] - 1.4 * k)}l${f1(0.5 * k)} ${f1(1.2 * k)}l${f1(-0.3 * k)} ${f1(1.4 * k)}" stroke="#8a6a3a" stroke-width="${f1(0.15 * k)}" fill="none"/>`; })() : ''); });
        // scorch on the facets nearest the bulb top
        const sc = C.P([0, 20.6, 4]);
        const scorch = `<ellipse cx="${f1(sc[0])}" cy="${f1(sc[1])}" rx="${f1(2.6 * k)}" ry="${f1(1.8 * k)}" fill="#8a5a24" opacity="0.28" filter="url(#l30b1)"/>`;
        // bulb
        const bc = C.P([0, 9.4, 0]);
        const bulb = cyl3(C, [0, 20, 0], [0, 13.6, 0], 1.05, '#c8c4b8', { mat: 'gloss', olw: 0.3 }) + `<g>${FLK(7.3)}<circle cx="${f1(bc[0])}" cy="${f1(bc[1] - 0.3 * k)}" r="${f1(2.9 * k)}" fill="url(#l30g)" stroke="#e8c888" stroke-width="${f1(0.2 * k)}"/><ellipse cx="${f1(bc[0])}" cy="${f1(bc[1])}" rx="${f1(1.2 * k)}" ry="${f1(0.9 * k)}" fill="#ffffff" opacity="0.9" filter="url(#l30b1)"/><path d="M${f1(bc[0] - 0.8 * k)} ${f1(bc[1] - 0.2 * k)}q${f1(0.4 * k)} ${f1(-0.8 * k)} ${f1(0.8 * k)} 0t${f1(0.8 * k)} 0" stroke="#ff9a2a" stroke-width="${f1(0.2 * k)}" fill="none"/></g>`
          + `<path d="M${f1(bc[0] - 1.6 * k)} ${f1(bc[1] - 1.8 * k)}q${f1(-0.6 * k)} ${f1(1.4 * k)} 0 ${f1(3 * k)}" stroke="#ffffff" stroke-width="${f1(0.35 * k)}" fill="none" opacity="0.8"/>`;
        const lo = C.p(7.2 * Math.sin(C.thV), 13.4, 7.2 * Math.cos(C.thV)), bid = C.u('bk');
        const bulbLo = `<clipPath id="${bid}"><rect x="${f1(bc[0] - 8 * k)}" y="${f1(lo[1] - 0.6 * k)}" width="${f1(16 * k)}" height="${f1(12 * k)}"/></clipPath><g clip-path="url(#${bid})">${bulb}</g>`;
        let s = glow(C, [0, 12, 0], 13, 0.6, FLK(7.3)) + back + bulb + `<g>${FLK(7.3)}${front}</g>` + bulbLo + glow(C, [0, 9.4, 0], 8, 0.7, FLK(7.3)) + scorch;
        // holder + flex (twisted) + rose
        s = cyl3(C, [0, 26, 0], [0, 21.4, 0], 1.6, '#e6dcc0', { olw: 0.4 }) + cyl3(C, [0, 22.2, 0], [0, 21.4, 0], 2, '#ddd2b4', { olw: 0.4 }) + s;
        const c0 = C.P([0, T - 1.4, 0]), c1 = C.P([0, 26, 0]);
        s = `<path d="M${P2(c0)}L${P2(c1)}" stroke="#ece8dc" stroke-width="${f1(0.7 * k)}"/><path d="M${P2(c0)}L${P2(c1)}" stroke="#b8b2a2" stroke-width="${f1(0.7 * k)}" stroke-dasharray="${f1(0.5 * k)} ${f1(0.5 * k)}" opacity="0.6"/>` + s;
        const rose = cyl3(C, [0, T - 1.6, 0], [0, T, 0], 3.6, '#e6dfc8', { olw: 0.5 }) + rep(5, () => { const q = C.p((R() - 0.5) * 7, T - 0.4, (R() - 0.5) * 7); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.25 * k)}" fill="#c8bea0" opacity="0.6"/>`; }).join('');
        return { defs: DEFL, front: rose + `<g>${swing(C, [0, T - 1.4, 0], 1.8, 6.4)}${s}</g>`, bb: C.bb(5) }; };
      return D; };

    // BED-030 WOVEN BAMBOO DRUM FLUSH-MOUNT (T2): a white steel ceiling plate holding a shallow drum of hand-woven bamboo: honey and natural
    // strips in an over-under basket weave with a braided rim at top and bottom, warm light leaking through every gap, a white rice-paper
    // diffuser glowing underneath and dappled spots of light thrown onto the ceiling round it. Live: the dapples shimmer and the glow breathes.
    N.bamb30 = S => { const T = 12, RD0 = 14, H0 = 8.4, Y1 = T - 1.2, Y0 = Y1 - H0, D = { w: 34, d: 34, zs: 1.6, mount: 'ceil', build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('bamb30'), a0 = C.thV - PI / 2 - 0.05, a1 = C.thV + PI / 2 + 0.05;
        let sp = '';
        rep(18, i => { const a = i / 18 * 2 * PI + R() * 0.3, r = 17 + R() * 12, q = C.p(r * Math.sin(a), T, r * Math.cos(a)); sp += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((1 + R() * 1.4) * k)}" ry="${f1(0.5 * k)}" fill="#ffe2a6">${an('opacity', '0.15;0.7;0.15', n4(2.6 + R() * 2.6), n4(-R() * 3), SPL(2))}</ellipse>`; });
        let s = glow(C, [0, Y0 - 2, 0], 18, 0.5, an('opacity', '0.45;0.65;0.45', 6, 0, SPL(2)));
        // glowing core seen through the weave
        s += cyl3(C, [0, Y0 + 0.4, 0], [0, Y1, 0], RD0 - 0.3, '#ffcf80', { olw: 0 });
        // weave: horizontal weavers (front half) over vertical stakes, over-under
        const NW = 6, NS = 30;
        let wv = '';
        for (let r = 0; r < NW; r++) { const y = Y0 + 0.9 + r * (H0 - 1.8) / (NW - 1);
          for (let j = 0; j < NS; j++) { const b0 = j / NS * 2 * PI, b1 = (j + 1) / NS * 2 * PI; if (!vis(C, (b0 + b1) / 2)) continue; const over = (j + r) % 2 === 0;
            const P = ring(C, y, RD0 + (over ? 0.25 : 0), b0 + 0.02, b1 - 0.02, 3);
            wv += `<path d="M${P.map(P2).join('L')}" stroke="${over ? '#d6a868' : '#a87840'}" stroke-width="${f1(1.05 * k)}" fill="none" stroke-linecap="round"/>` + (over ? `<path d="M${P.map(P2).join('L')}" stroke="#f0cc90" stroke-width="${f1(0.3 * k)}" fill="none" transform="translate(0 ${f1(-0.3 * k)})"/>` : ''); } }
        for (let j = 0; j < NS; j++) { const a = (j + 0.5) / NS * 2 * PI; if (!vis(C, a)) continue; const p0 = C.p((RD0 + 0.1) * Math.sin(a), Y0 + 0.3, (RD0 + 0.1) * Math.cos(a)), p1 = C.p((RD0 + 0.1) * Math.sin(a), Y1 - 0.3, (RD0 + 0.1) * Math.cos(a));
          wv += `<path d="M${P2(p0)}L${P2(p1)}" stroke="#b88a50" stroke-width="${f1(0.5 * k)}" stroke-dasharray="${f1(0.9 * k)} ${f1(1.4 * k)}" stroke-dashoffset="${f1((j % 2) * 1.15 * k)}"/>`; }
        s += wv;
        // braided rims
        const rim = (y, w) => { const P = ring(C, y, RD0 + 0.4, a0, a1, 40); return `<path d="M${P.map(P2).join('L')}" stroke="#8a5a2a" stroke-width="${f1(w * k)}" fill="none" stroke-linecap="round"/><path d="M${P.map(P2).join('L')}" stroke="#d8a868" stroke-width="${f1(w * 0.6 * k)}" fill="none" stroke-dasharray="${f1(0.8 * k)} ${f1(0.5 * k)}" stroke-linecap="round"/>`; };
        s += rim(Y0 + 0.1, 1.4) + rim(Y1 - 0.1, 1.2);
        // rice-paper diffuser underneath (bottom ellipse edge)
        { const P = ring(C, Y0 - 0.2, RD0 - 0.6, a0, a1, 30); s += `<path d="M${P.map(P2).join('L')}" stroke="#fff4dc" stroke-width="${f1(0.8 * k)}" fill="none" opacity="0.9"/>`; }
        // woven lid: spokes + concentric rounds, then a small white canopy
        { const L = ring(C, Y1, RD0 + 0.4, 0, 2 * PI, 60); let lid = `<path d="M${L.map(P2).join('L')}Z" fill="#c89458" stroke="#8a5a2a" stroke-width="${f1(0.4 * k)}"/>`;
          for (let r = 4; r < RD0; r += 1.3) { const Q = ring(C, Y1 + 0.02, r, 0, 2 * PI, 48); lid += `<path d="M${Q.map(P2).join('L')}Z" fill="none" stroke="${r % 2.6 < 1.3 ? '#e2b47a' : '#a87440'}" stroke-width="${f1(0.55 * k)}" stroke-dasharray="${f1(1.2 * k)} ${f1(0.6 * k)}"/>`; }
          rep(16, i => { const a = i / 16 * 2 * PI, p0 = C.p(4 * Math.sin(a), Y1 + 0.03, 4 * Math.cos(a)), p1 = C.p(RD0 * Math.sin(a), Y1 + 0.03, RD0 * Math.cos(a)); lid += `<path d="M${P2(p0)}L${P2(p1)}" stroke="#8a5a2a" stroke-width="${f1(0.3 * k)}" opacity="0.7"/>`; });
          s = sp + s + lid + cyl3(C, [0, Y1, 0], [0, T, 0], 4.4, '#f2f0ea', { olw: 0.5 }); }
        return { defs: DEFL, front: s, bb: C.bb(5) }; };
      return D; };

    const zs = (C, L) => L.sort((a, b) => (a.q[0] * C.v[0] + a.q[1] * C.v[1] + a.q[2] * C.v[2]) - (b.q[0] * C.v[0] + b.q[1] * C.v[1] + b.q[2] * C.v[2])).map(o => o.s).join('');
    const isF = (C, q) => q[0] * C.v[0] + q[2] * C.v[2] > 0;
    const rp = (C, P, w, col, hi) => `<path d="M${P.map(P2).join('L')}" stroke="${col}" stroke-width="${f1(w * C.k)}" fill="none" stroke-linecap="round"/><path d="M${P.map(P2).join('L')}" stroke="${hi}" stroke-opacity="0.55" stroke-width="${f1(w * 0.3 * C.k)}" fill="none" transform="translate(0 ${f1(-w * 0.25 * C.k)})"/>`;

    // BED-050 CAPIZ SHELL TIERED COASTAL CHANDELIER (T3): a white-washed iron frame of three tiers hung from a jute-wrapped chain, every ring strung
    // with strands of thin round capiz shells on fishing line: translucent pearly discs, each a slightly different white with a faint pink-gold
    // iridescence, some turned edge-on; warm bulbs inside glowing through the shells. Live: the strands sway and the shells shimmer as they turn.
    N.capiz30 = S => { const T = 58, TI = [{ y: 46, r: 7, n: 10, m: 4 }, { y: 38, r: 11, n: 14, m: 5 }, { y: 29, r: 15, n: 18, m: 6 }], WH = '#f4f1ea', D = { w: 44, d: 44, zs: 1.6, mount: 'ceil', build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('capiz30'), L = []; let gl = '', n = 0;
        TI.forEach((t, ti) => { gl += glow(C, [0, t.y - 4, 0], t.r * 1.3, 0.55, an('opacity', '0.45;0.65;0.45', 5 + ti, -ti, SPL(2)));
          rep(t.n, i => { const a = i / t.n * 2 * PI + ti * 0.3, x = t.r * Math.sin(a), z = t.r * Math.cos(a), id = n++, top = C.P([x, t.y, z]); let st = `<path d="M${P2(top)}l0 ${f1(t.m * 2.3 * k)}" stroke="#d8d4c8" stroke-width="${f1(0.08 * k)}"/>`;
            rep(t.m, j => { const p = C.P([x, t.y - 1.4 - j * 2.3, z]), tw = 0.3 + 0.7 * Math.abs(Math.cos(a * 3 + j * 1.7)), rx = 1.25 * k * tw, ry = 1.25 * k, c = ['#f8eedc', '#f2e4cc', '#fbf3e6', '#efdfc4'][(R() * 4) | 0];
              st += `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(rx)}" ry="${f1(ry)}" fill="${c}" opacity="0.95" stroke="#a89474" stroke-width="${f1(0.16 * k)}"/><ellipse cx="${f1(p[0])}" cy="${f1(p[1] + ry * 0.35)}" rx="${f1(rx * 0.7)}" ry="${f1(ry * 0.45)}" fill="#e0c8a0" opacity="0.35"/><ellipse cx="${f1(p[0] - rx * 0.25)}" cy="${f1(p[1] - ry * 0.3)}" rx="${f1(rx * 0.5)}" ry="${f1(ry * 0.4)}" fill="url(#l30p)" opacity="0.7">${an('opacity', '0.2;0.8;0.2', n4(3 + R() * 3), n4(-R() * 4), SPL(2))}</ellipse>`; });
            L.push({ q: [x, t.y - t.m, z], s: `<g>${at('rotate', `-3 ${P2(top)};3 ${P2(top)};-3 ${P2(top)}`, n4(3.4 + (id % 5) * 0.5), n4(-id * 0.27), SPL(2))}${st}</g>` }); }); });
        const Lb = L.filter(o => !isF(C, o.q)).map(o => Object.assign(o, { s: `<g opacity="0.75">${o.s}</g>` })), Lf = L.filter(o => isF(C, o.q)), bk = C.thV + PI;
        const rings = (a0, a1) => TI.map(t => rp(C, ring(C, t.y, t.r, a0, a1, 24), 0.9, '#d8d2c4', '#ffffff')).join('');
        const arms = TI.map(t => rep(4, i => { const a = i * PI / 2 + 0.3; return `<path d="M${P2(C.p(0, t.y + 3, 0))}L${P2(C.p(t.r * Math.sin(a), t.y, t.r * Math.cos(a)))}" stroke="#cfc8b8" stroke-width="${f1(0.5 * k)}"/>`; }).join('')).join('');
        const bulbs = TI.map(t => `<circle cx="${f1(C.P([0, t.y - 2, 0])[0])}" cy="${f1(C.P([0, t.y - 2, 0])[1])}" r="${f1(1.4 * k)}" fill="#fff4d8"/>`).join('');
        const chainP = rep(9, i => C.p(0, T - 1.4 - i * (T - 1.4 - 49) / 8, 0));
        const chain = `<path d="M${chainP.map(P2).join('L')}" stroke="#a8875a" stroke-width="${f1(1.2 * k)}"/><path d="M${chainP.map(P2).join('L')}" stroke="#d8bc8a" stroke-width="${f1(1.2 * k)}" stroke-dasharray="${f1(0.4 * k)} ${f1(0.4 * k)}"/>`;
        const body = gl + zs(C, Lb) + rings(bk - PI / 2, bk + PI / 2) + arms + bulbs + cyl3(C, [0, 26, 0], [0, 49, 0], 0.5, WH, { olw: 0.3 }) + H.sph(C, [0, 25.6, 0], 1.2, WH) + chain + rings(C.thV - PI / 2, C.thV + PI / 2) + zs(C, Lf);
        return { defs: DEFL + '<radialGradient id="l30p" cx="40%" cy="40%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.5" stop-color="#f8e4ec"/><stop offset="1" stop-color="#e8dcc0" stop-opacity="0"/></radialGradient>', front: cyl3(C, [0, T - 1.4, 0], [0, T, 0], 4.6, '#c8a878', { olw: 0.5 }) + `<g>${swing(C, [0, T, 0], 1, 8)}${body}</g>`, bb: C.bb(5) }; };
      return D; };

    // BED-070 BRUSHED GOLD & FROSTED GLASS CLOUD CHANDELIER (T4): a brushed-gold canopy and slim rod holding a billowing cloud of hand-blown frosted
    // glass globes in many sizes, each on its own short gold stem from a central gold hub, glowing a soft warm white from inside with a brighter
    // core and a crisp sheen on the frosting. Live: the globes breathe in a slow wave through the cloud and a glint runs along the gold.
    N.cloud30 = S => { const T = 52, CY = 30, GD = '#c8a462', D = { w: 56, d: 56, zs: 1.5, mount: 'ceil', build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('cloud30'), L = [], P0 = [];
        rep(60, () => { if (P0.length >= 19) return; const a = R() * 2 * PI, e = (R() - 0.5) * 1.6, rr = 6 + R() * 12, p = [rr * Math.cos(e) * Math.sin(a), CY + Math.sin(e) * 7 + (R() - 0.5) * 2, rr * Math.cos(e) * Math.cos(a)], r = 2.4 + R() * 2.8;
          if (P0.every(o => Math.hypot(o.p[0] - p[0], o.p[1] - p[1], o.p[2] - p[2]) > o.r + r + 0.6)) P0.push({ p, r }); });
        P0.forEach((o, i) => { const c = C.P(o.p), hub = C.P([0, CY + 1, 0]), rr = o.r * k;
          const s = `<path d="M${P2(hub)}L${P2(c)}" stroke="${GD}" stroke-width="${f1(0.5 * k)}"/><path d="M${P2(hub)}L${P2(c)}" stroke="#fff0c0" stroke-width="${f1(0.15 * k)}" opacity="0.7"/>`
            + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(rr * 1.7)}" fill="url(#l30w)" opacity="0.35">${an('opacity', '0.2;0.45;0.2', 7, n4(-i * 0.37), SPL(2))}</circle>`
            + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(rr)}" fill="url(#l30f)" stroke="#e8dcc4" stroke-width="${f1(0.15 * k)}"/><circle cx="${f1(c[0] + rr * 0.1)}" cy="${f1(c[1] + rr * 0.15)}" r="${f1(rr * 0.45)}" fill="#fffaf0" opacity="0.6" filter="url(#l30b1)">${an('opacity', '0.35;0.85;0.35', 7, n4(-i * 0.37), SPL(2))}</circle>`
            + `<ellipse cx="${f1(c[0] - rr * 0.38)}" cy="${f1(c[1] - rr * 0.42)}" rx="${f1(rr * 0.28)}" ry="${f1(rr * 0.16)}" fill="#ffffff" opacity="0.75" transform="rotate(-35 ${f1(c[0] - rr * 0.38)} ${f1(c[1] - rr * 0.42)})"/>`
            + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(rr * 0.98)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.25 * k)}" stroke-dasharray="${f1(rr * 1.2)} ${f1(rr * 6)}" stroke-dashoffset="${f1(rr * 4.4)}" opacity="0.6"/>`;
          L.push({ q: o.p, s }); });
        const hub = H.sph(C, [0, CY + 1, 0], 2.2, GD) + cyl3(C, [0, CY + 2.6, 0], [0, CY + 1.2, 0], 1.4, GD, { mat: 'gloss', olw: 0.3 });
        const rod = cyl3(C, [0, CY + 2.6, 0], [0, T - 1.2, 0], 0.55, GD, { mat: 'gloss', olw: 0.3 });
        const rt = C.P([0, CY + 2.6, 0]), rb = C.P([0, T - 1.2, 0]), gl = `<path d="M${P2(rt)}L${P2(rb)}" stroke="#fffbe8" stroke-width="${f1(0.4 * k)}" stroke-dasharray="${f1(2 * k)} ${f1(40 * k)}" stroke-linecap="round"><animate attributeName="stroke-dashoffset" values="${f1(42 * k)};0" dur="5s" repeatCount="indefinite"/></path>`;
        const Lb = L.filter(o => o.q[0] * C.v[0] + (o.q[1] - CY) * C.v[1] + o.q[2] * C.v[2] <= 0), Lf = L.filter(o => o.q[0] * C.v[0] + (o.q[1] - CY) * C.v[1] + o.q[2] * C.v[2] > 0);
        const body = glow(C, [0, CY, 0], 34, 0.5, an('opacity', '0.4;0.6;0.4', 7, 0, SPL(2))) + zs(C, Lb) + rod + gl + hub + zs(C, Lf);
        return { defs: DEFL + '<radialGradient id="l30f" cx="45%" cy="45%" r="60%"><stop offset="0" stop-color="#fffdf6"/><stop offset="0.55" stop-color="#fbf2de"/><stop offset="0.85" stop-color="#ead8b4"/><stop offset="1" stop-color="#d8c094"/></radialGradient>',
          front: cyl3(C, [0, T - 1.2, 0], [0, T, 0], 4.8, GD, { mat: 'gloss' }) + `<g>${swing(C, [0, T, 0], 0.6, 9)}${body}</g>`, bb: C.bb(5) }; };
      return D; };

    // BED-090 FLOATING BIOLUMINESCENT FEATHER-HALO LIGHT SCULPTURE (T5): a slim polished champagne-gold halo hovering in the air with nothing holding
    // it, under a pale glowing disc set flush in the ceiling; from the halo hang long soft feathers that glow from within like deep-sea creatures,
    // pearl-white at the quill warming to gold and rose at the tips, with fine glowing barbs. Live: the halo bobs gently as it floats, a bead of
    // light runs round it, the feathers ripple one after another, their glow drifts through gold, rose and lilac, and glowing motes drift down.
    N.halo30 = S => { const T = 54, HY = 36, HR = 17, D = { w: 50, d: 50, zs: 1.5, mount: 'ceil', build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('halo30'), L = [], NF = 22;
        rep(NF, i => { const a = i / NF * 2 * PI + 0.1, x = HR * Math.sin(a), z = HR * Math.cos(a), len = 11 + R() * 5, out = 2 + R() * 2.5;
          const p0 = C.P([x, HY - 0.4, z]), p1 = C.P([(HR + out) * Math.sin(a), HY - len, (HR + out) * Math.cos(a)]), dx = p1[0] - p0[0], dy = p1[1] - p0[1], l = Math.hypot(dx, dy) || 1, nx = -dy / l, ny = dx / l, w = 2.1 * k, cv = (R() - 0.5) * 2 * k;
          const pt = (t, s) => [p0[0] + dx * t + nx * (s + cv * Math.sin(t * PI)), p0[1] + dy * t + ny * (s + cv * Math.sin(t * PI))];
          const outline = 'M' + P2(pt(0.04, 0)) + 'Q' + P2(pt(0.3, w * 1.25)) + ' ' + P2(pt(0.62, w)) + 'Q' + P2(pt(0.9, w * 0.6)) + ' ' + P2(pt(1, 0)) + 'Q' + P2(pt(0.88, -w * 0.5)) + ' ' + P2(pt(0.6, -w * 0.85)) + 'Q' + P2(pt(0.28, -w * 1.1)) + ' ' + P2(pt(0.04, 0)) + 'Z';
          let barbs = ''; for (let t = 0.12; t < 0.96; t += 0.06) { const ww = w * (t < 0.6 ? 0.8 + t * 0.3 : (1 - t) * 2.2); barbs += `M${P2(pt(t, 0))}L${P2(pt(t + 0.06, ww))}M${P2(pt(t, 0))}L${P2(pt(t + 0.06, -ww * 0.85))}`; }
          const T0 = 4 + (i % 5) * 0.6, ph = -i * 0.33, sw = P2(p0);
          const s = `<g>${at('rotate', `-5 ${sw};5 ${sw};-5 ${sw}`, n4(T0), n4(ph), SPL(2))}<path d="${outline}" fill="url(#l30h)" opacity="0.4" filter="url(#l30b1)">${an('opacity', '0.25;0.6;0.25', 6, n4(-i * 0.5), SPL(2))}</path>`
            + `<path d="${outline}" fill="url(#l30e)" opacity="0.82"/><path d="${barbs}" stroke="#fff8ee" stroke-width="${f1(0.09 * k)}" opacity="0.7"/>`
            + `<path d="${outline}" fill="#f0a8c8" opacity="0">${an('opacity', '0;0.35;0;0;0', 18, n4(-i * 0.8), KT('0;0.25;0.5;0.75;1'))}</path><path d="${outline}" fill="#c8a8f8" opacity="0">${an('opacity', '0;0;0;0.3;0', 18, n4(-i * 0.8), KT('0;0.25;0.5;0.75;1'))}</path>`
            + `<path d="M${P2(pt(0, 0))}Q${P2(pt(0.5, cv * 0.2))} ${P2(pt(0.97, 0))}" stroke="#fffaf0" stroke-width="${f1(0.22 * k)}" fill="none"/></g>`;
          L.push({ q: [x, HY - 6, z], s }); });
        const Lb = L.filter(o => !isF(C, o.q)), Lf = L.filter(o => isF(C, o.q)), bk = C.thV + PI;
        const halo = (a0, a1) => rp(C, ring(C, HY, HR, a0, a1, 40), 1.2, '#c8a868', '#fff4d0');
        const full = ring(C, HY, HR, 0, 2 * PI, 64), bead = `<path d="M${full.map(P2).join('L')}" pathLength="100" stroke="#fffbe8" stroke-width="${f1(0.9 * k)}" fill="none" stroke-linecap="round" stroke-dasharray="4 96"><animate attributeName="stroke-dashoffset" values="100;0" dur="6s" repeatCount="indefinite"/></path>`;
        const motes = rep(10, i => { const a = R() * 2 * PI, r = R() * HR, p = C.P([r * Math.sin(a), HY - 4, r * Math.cos(a)]), T0 = 7 + R() * 5; return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.35 * k)}" fill="#fff0d0" opacity="0">${an('opacity', '0;0.9;0', n4(T0), n4(-R() * T0), SPL(2))}${at('translate', `0 0;${f1((R() - 0.5) * 3 * k)} ${f1(14 * k)}`, n4(T0), n4(-R() * T0))}</circle>`; }).join('');
        const body = glow(C, [0, HY - 6, 0], 32, 0.55, an('opacity', '0.4;0.62;0.4', 8, 0, SPL(2))) + zs(C, Lb) + halo(bk - PI / 2, bk + PI / 2) + motes + halo(C.thV - PI / 2, C.thV + PI / 2) + bead + zs(C, Lf);
        const disc = cyl3(C, [0, T - 0.6, 0], [0, T, 0], 8, '#f4ecdc', { olw: 0.4 }) + (() => { const P = ring(C, T - 0.62, 6.4, 0, 2 * PI, 40); return `<path d="M${P.map(P2).join('L')}Z" fill="#fff6e0"/><path d="M${P.map(P2).join('L')}Z" fill="none" stroke="#ffe0a8" stroke-width="${f1(1.6 * k)}" opacity="0.6" filter="url(#l30b1)">${an('opacity', '0.4;0.8;0.4', 8, 0, SPL(2))}</path>`; })();
        return { defs: DEFL + '<linearGradient id="l30e" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fffaf2"/><stop offset="0.55" stop-color="#fbe6c4"/><stop offset="1" stop-color="#f4c49a"/></linearGradient><radialGradient id="l30h"><stop offset="0" stop-color="#ffe8b8"/><stop offset="1" stop-color="#ffc898" stop-opacity="0"/></radialGradient>',
          front: disc + `<g>${at('translate', `0 0;0 ${f1(-1.6 * k)};0 0`, 6, 0, SPL(2))}${body}</g>`, bb: C.bb(5) }; };
      return D; };
  }

  // ======================= BEDROOM ELECTRONICS (BED-020/040/060/080/100): fx-only per-face pieces (RD.H10 box3/cyl3/sph, like the plus28 fridges), footprints kept =======================
  { const { box3, cyl3, sph, shadow, mist, FR } = H, DEF19 = RD.H19.DEF19;
    const line3 = (C, P, w, col, ex) => '<path d="M' + P.map(p => P2(C.P(p))).join('L') + '" stroke="' + col + '" stroke-width="' + f1(w * C.k) + '" fill="none" stroke-linecap="round" stroke-linejoin="round"' + (ex ? ' ' + ex : '') + '/>';
    const PLN = (C, y, svg) => `<g transform="${FR(C, [0, y, 0], [1, 0, 0], [0, 0, 1])}">${svg}</g>`;
    const vs = (C, L) => L.sort((a, b) => (a.q[0] * C.v[0] + a.q[1] * C.v[1] + a.q[2] * C.v[2]) - (b.q[0] * C.v[0] + b.q[1] * C.v[1] + b.q[2] * C.v[2])).map(o => o.s).join('');
    const cord = (C, P, col) => line3(C, P, 0.45, col || '#2a2a2a') + line3(C, P, 0.15, '#6a6a6a', 'transform="translate(-0.2 -0.2)"');
    // clock dial (svg, centred, radius r): ticks, numerals, hands; ticking second hand
    const dial = (r, o) => { o = o || {}; let s = `<circle r="${r}" fill="${o.bg || '#f8f4e8'}"/>` + rep(60, i => { const a = i * 6 * PI / 180, l = i % 5 ? 0.35 : 0.8; return `<path d="M${f1(Math.sin(a) * (r - 0.3))} ${f1(-Math.cos(a) * (r - 0.3))}L${f1(Math.sin(a) * (r - 0.3 - l))} ${f1(-Math.cos(a) * (r - 0.3 - l))}" stroke="${o.ink || '#2a2a2a'}" stroke-width="${i % 5 ? 0.06 : 0.14}"/>`; }).join('');
      if (o.num) [12, 3, 6, 9].forEach((n, j) => { const a = j * PI / 2; s += `<text x="${f1(Math.sin(a) * (r - 1.6))}" y="${f1(-Math.cos(a) * (r - 1.6) + 0.45)}" text-anchor="middle" font-family="Georgia,serif" font-size="${f1(r * 0.28)}" font-weight="bold" fill="${o.ink || '#2a2a2a'}">${n}</text>`; });
      s += `<path d="M0 0L${f1(r * 0.32)} ${f1(-r * 0.3)}" stroke="${o.ink || '#1a1a1a'}" stroke-width="${f1(r * 0.08)}" stroke-linecap="round"/><path d="M0 0L${f1(-r * 0.08)} ${f1(-r * 0.72)}" stroke="${o.ink || '#1a1a1a'}" stroke-width="${f1(r * 0.055)}" stroke-linecap="round"/>`;
      s += `<g><animateTransform attributeName="transform" type="rotate" values="${rep(60, i => i * 6).join(';')}" dur="60s" calcMode="discrete" repeatCount="indefinite"/><path d="M0 ${f1(r * 0.18)}L0 ${f1(-r * 0.82)}" stroke="#c8202a" stroke-width="${f1(r * 0.025)}"/></g><circle r="${f1(r * 0.06)}" fill="#1a1a1a"/>`;
      if (o.alarm != null) s += `<path d="M0 0L${f1(Math.sin(o.alarm) * r * 0.5)} ${f1(-Math.cos(o.alarm) * r * 0.5)}" stroke="#c8902a" stroke-width="${f1(r * 0.03)}"/>`;
      return s; };

    // BED-020 TICKING WIND-UP ALARM CLOCK & BOX FAN (T1): a yellowed beige plastic box fan with a dusty white grille (fluffy dust in the ring
    // corners), a cracked carry handle mended with tape, a three-speed dial and a faded brand sticker, its plastic blades spinning behind the grille
    // with a strip of paper tied on that streams in the breeze; beside it a dented chrome twin-bell wind-up alarm clock on two splayed legs, its
    // hammer between the bells, a key on the back and a yellowed dial. Live: the blades spin, the paper streamer flutters and the second hand ticks.
    N.fan30 = S => { const D = { w: 28, d: 18, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('fan30'), id = C.u('e20'), FW = 19, FH = 21, FD = 6, FX = -4, FZ = -2;
        const grille = (w, h, front) => { const cx = w / 2, cy = h / 2 + 0.4, r = 8.4; let g = `<rect x="0.9" y="1.3" width="${f1(w - 1.8)}" height="${f1(h - 2.2)}" rx="1.4" fill="#1e1c1a"/>`;
          if (front) g += `<g transform="translate(${f1(cx)} ${f1(cy)})${front === 2 ? ' scale(-1 1)' : ''}"><circle r="${f1(r * 0.98)}" fill="#c8c0a8" opacity="0.15">${an('opacity', '0.1;0.2;0.1', 0.6)}</circle><g>${at('rotate', '0;360', 0.45)}${rep(5, i => `<path d="M0 0C${f1(r * 0.25)} ${f1(-r * 0.15)} ${f1(r * 0.75)} ${f1(-r * 0.55)} ${f1(r * 0.9)} ${f1(-r * 0.2)}C${f1(r * 0.85)} ${f1(r * 0.15)} ${f1(r * 0.4)} ${f1(r * 0.2)} 0 0Z" fill="#d8d0b8" opacity="0.5" transform="rotate(${i * 72})"/>`).join('')}</g><circle r="${f1(r * 0.16)}" fill="#e2dcc8" stroke="#8a826c" stroke-width="0.1"/></g>`;
          g += rep(5, i => `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(r * (0.25 + i * 0.19))}" fill="none" stroke="#f2eee2" stroke-width="0.32"/>`).join('') + rep(12, i => { const a = i * PI / 6; return `<path d="M${f1(cx + Math.cos(a) * r * 0.25)} ${f1(cy + Math.sin(a) * r * 0.25)}L${f1(cx + Math.cos(a) * r)} ${f1(cy + Math.sin(a) * r)}" stroke="#f2eee2" stroke-width="0.24"/>`; }).join('')
            + `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(r * 0.25)}" fill="#ece6d4" stroke="#b8b09a" stroke-width="0.1"/>`
            + rep(26, () => { const a = R() * 2 * PI, rr = r * (0.3 + R() * 0.7); return `<circle cx="${f1(cx + Math.cos(a) * rr)}" cy="${f1(cy + Math.sin(a) * rr)}" r="${f1(0.15 + R() * 0.25)}" fill="#9a907a" opacity="0.6"/>`; }).join('')
            + [[1.4, 1.8], [w - 1.4, 1.8], [1.4, h - 1.4], [w - 1.4, h - 1.4]].map(([x, y]) => `<circle cx="${f1(x)}" cy="${f1(y)}" r="1.1" fill="#a89a80" opacity="0.5" filter="url(#m12b1)"/>`).join('');
          if (front === 1) g += `<g transform="translate(${f1(w - 2.6)} ${f1(h - 2.8)})"><circle r="1.3" fill="#ece6d2" stroke="#8a826c" stroke-width="0.12"/><path d="M0 0L0.9 -0.5" stroke="#3a3a3a" stroke-width="0.25"/><text x="-1.9" y="-0.9" font-size="0.45" fill="#5a5448" font-family="Arial">OFF</text><text x="0.7" y="-1.4" font-size="0.45" fill="#5a5448" font-family="Arial">3</text></g>`
            + `<rect x="1.4" y="${f1(h - 2.6)}" width="5" height="1.5" rx="0.2" fill="#d8402a" opacity="0.55"/><text x="3.9" y="${f1(h - 1.5)}" text-anchor="middle" font-size="0.75" font-weight="bold" fill="#f8f0d8" font-family="Arial" opacity="0.8">BREEZ</text>`;
          return g; };
        const sides = rep(10, () => `<path d="M${f1(R() * FD)} ${f1(R() * FH)}l${f1(R() * 1.2)} ${f1((R() - 0.5) * 0.4)}" stroke="#b8ae94" stroke-width="0.1"/>`).join('');
        const tapeS = `<rect x="1" y="2" width="4" height="1.6" fill="#c8c0a0" opacity="0.8" transform="rotate(-8 3 3)"/>`;
        let fan = box3(C, { c: [FX - 6, 0, FZ], w: 3, h: 1.2, d: 8, col: '#cfc6ac', r: 0.4 }) + box3(C, { c: [FX + 6, 0, FZ], w: 3, h: 1.2, d: 8, col: '#cfc6ac', r: 0.4 })
          + box3(C, { c: [FX, 1, FZ], w: FW, h: FH, d: FD, col: '#e2dac2', r: 1.2, dec: { f: grille(FW, FH, 1), b: grille(FW, FH, 2), l: sides + tapeS, r: sides } })
          + box3(C, { c: [FX, FH + 1, FZ], w: 8, h: 1.4, d: 2.4, col: '#d8d0b6', r: 0.6, dec: { f: '<rect x="3" y="-0.1" width="2.4" height="1.6" fill="#c8c0a0" opacity="0.85"/><path d="M3.4 0.2V1.2M4.2 0.2V1.2M5 0.2V1.2" stroke="#a89e80" stroke-width="0.08"/>' } });
        // paper streamer tied to the front grille
        const sp = C.P([FX + 2, FH - 3, FZ + FD / 2 + 0.2]), k = C.k, sl = `M0 0C${f1(3 * k)} ${f1(-0.6 * k)} ${f1(5 * k)} ${f1(0.8 * k)} ${f1(8 * k)} ${f1(0.2 * k)}L${f1(8 * k)} ${f1(1.2 * k)}C${f1(5 * k)} ${f1(1.8 * k)} ${f1(3 * k)} ${f1(0.4 * k)} 0 ${f1(1 * k)}Z`, sl2 = `M0 0C${f1(3 * k)} ${f1(0.8 * k)} ${f1(5 * k)} ${f1(-0.8 * k)} ${f1(8 * k)} ${f1(0.6 * k)}L${f1(8 * k)} ${f1(1.6 * k)}C${f1(5 * k)} ${f1(0.2 * k)} ${f1(3 * k)} ${f1(1.8 * k)} 0 ${f1(1 * k)}Z`;
        const streamer = C.v[2] > 0 ? `<g transform="translate(${P2(sp)})"><path d="${sl}" fill="#f4f0e4" stroke="#c8c0a8" stroke-width="${f1(0.1 * k)}"><animate attributeName="d" values="${sl};${sl2};${sl}" dur="0.5s" repeatCount="indefinite"/></path></g>` : '';
        // twin-bell alarm clock
        const CX = 9.4, CZ = 4.4, CY = 6.2, cr = 3.3, fr = C.v[2] > 0;
        let clk = cyl3(C, [CX - 1.4, 0, CZ - 0.3], [CX - 2.2, CY - 2.6, CZ - 0.3], 0.35, '#b8bcc0', { mat: 'chrome', olw: 0.25 }) + cyl3(C, [CX + 1.4, 0, CZ - 0.3], [CX + 2.2, CY - 2.6, CZ - 0.3], 0.35, '#b8bcc0', { mat: 'chrome', olw: 0.25 });
        const bells = [-1, 1].map(sg => ({ q: [CX + sg * 1.9, CY + 3, CZ - 0.4], s: sph(C, [CX + sg * 1.9, CY + 3, CZ - 0.4], 1.65, '#c8ccd2') + cyl3(C, [CX + sg * 1.9, CY + 3, CZ - 0.4], [CX + sg * 1.1, CY + 2, CZ - 0.4], 0.18, '#a8acb0', { olw: 0.2 }) }));
        const body = cyl3(C, [CX, CY, CZ - 1.1], [CX, CY, CZ + 0.6], cr, '#c4c8cc', { mat: 'chrome', n: 32, olw: 0.35, cap: fr ? rr => `<g transform="scale(${n4(rr / cr)})"><circle r="${cr}" fill="#a8acb0"/>${dial(cr - 0.45, { bg: '#f2ead4', num: 1, alarm: 3.6 })}<path d="M${f1(-cr * 0.6)} ${f1(-cr * 0.5)}A${f1(cr * 0.8)} ${f1(cr * 0.8)} 0 0 1 ${f1(cr * 0.2)} ${f1(-cr * 0.75)}" stroke="#ffffff" stroke-width="0.3" fill="none" opacity="0.5"/></g>` : rr => `<circle r="${f1(rr * 0.9)}" fill="#b8bcc0"/><circle r="${f1(rr * 0.5)}" fill="none" stroke="#8a8e92" stroke-width="0.15"/>` });
        const key = fr ? '' : cyl3(C, [CX, CY + 0.5, CZ - 1.1], [CX, CY + 0.5, CZ - 2.2], 0.25, '#a8acb0', { olw: 0.2 }) + box3(C, { c: [CX, CY - 0.4, CZ - 2.4], w: 2.6, h: 1.8, d: 0.25, col: '#b8bcc0', r: 0.1 });
        const hammer = line3(C, [[CX, CY + cr - 0.2, CZ - 0.4], [CX, CY + cr + 1.4, CZ - 0.4]], 0.3, '#8a8e92') + sph(C, [CX, CY + cr + 1.6, CZ - 0.4], 0.45, '#b8bcc0') + cyl3(C, [CX, CY + cr, CZ - 0.4], [CX, CY + cr + 3.6, CZ - 0.4], 0.12, '#8a8e92', { olw: 0.15 }) + sph(C, [CX, CY + cr + 3.8, CZ - 0.4], 0.5, '#c8ccd2');
        clk += vs(C, [{ q: [CX, CY, CZ], s: body + key }, ...bells]) + hammer;
        const items = [{ q: [FX, 10, FZ], s: fan + streamer }, { q: [CX, 4, CZ], s: clk }];
        let s = shadow(C, FX, FZ, 13, 6, 0.55) + shadow(C, CX, CZ, 4.4, 2.4, 0.5) + cord(C, [[FX + 4, 3, FZ - FD / 2], [FX + 6, 0.3, FZ - FD / 2 - 2], [FX + 12, 0.3, -9]], '#e8e2d0') + vs(C, items);
        C.p(-15, 0, 0); C.p(15, 0, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-040 WHITE-NOISE SOUND MACHINE & COOL-MIST HUMIDIFIER (T2): a squat cream drum sound machine with a slotted dome lid and a ring of side
    // vents, a soft amber power dot; beside it a pebble-shaped ultrasonic humidifier: a frosted clear tank half full of water on a white base with
    // a warm amber night-light ring, a rotating mist nozzle, on a knitted coaster; a coiled cord. Live: a cool mist plume rolls up from the nozzle,
    // the water trembles, the night-light ring breathes and soft sound ripples ring out of the sound machine's vents.
    N.mist30 = S => { const D = { w: 36, d: 18, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('mist30'), id = C.u('e40'), HX = -8, HZ = -1, SX = 10, SZ = 2;
        // humidifier
        let hum = PLN(C, 0.06, `<ellipse cx="${HX}" cy="${HZ}" rx="9" ry="6.4" fill="#c87a5a"/>` + rep(5, i => `<ellipse cx="${HX}" cy="${HZ}" rx="${f1(8.6 - i * 1.7)}" ry="${f1(6 - i * 1.2)}" fill="none" stroke="${i % 2 ? '#e8a07a' : '#a85a3a'}" stroke-width="0.5"/>`).join(''))
          + cyl3(C, [HX, 0.1, HZ], [HX, 3.2, HZ], 6.4, '#f2f0ea', { r2: 6.2, olw: 0.4 })
          + `<g>${an('opacity', '0.6;1;0.6', 6, 0, SPL(2))}${(() => { const P = rep(41, i => { const a = i / 40 * 2 * PI; return C.p(HX + 6.3 * Math.sin(a), 1.4, HZ + 6.3 * Math.cos(a)); }).filter((p, i) => Math.cos(i / 40 * 2 * PI - C.thV) > 0); return `<path d="M${P.map(P2).join('L')}" stroke="#ffb860" stroke-width="${f1(0.6 * C.k)}" fill="none"/><path d="M${P.map(P2).join('L')}" stroke="#ffc878" stroke-width="${f1(2.4 * C.k)}" fill="none" opacity="0.35" filter="url(#m12b1)"/>`; })()}</g>`;
        hum += cyl3(C, [HX, 3.2, HZ], [HX, 9.4, HZ], 5.8, '#bcd0d4', { r2: 5.4, op: 0.5, olw: 0.3, noCap: 1 }) + cyl3(C, [HX, 3.2, HZ], [HX, 8.2, HZ], 5.6, '#9ab8c0', { r2: 5.3, op: 0.45, olw: 0 });
        { const wq = rep(33, i => { const a = i / 32 * 2 * PI; return C.p(HX + 5.3 * Math.sin(a), 8.2, HZ + 5.3 * Math.cos(a)); }); hum += `<path d="M${wq.map(P2).join('L')}Z" fill="#c8e0e4" opacity="0.6"><animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(0.12 * C.k)};0 0" dur="0.9s" repeatCount="indefinite"/></path>`; }
        hum += cyl3(C, [HX, 9.4, HZ], [HX, 13.8, HZ], 5.4, '#e8eef0', { r2: 2.6, op: 0.55, olw: 0.3 }) + cyl3(C, [HX, 13.6, HZ], [HX, 15.4, HZ], 1.4, '#f4f2ee', { olw: 0.3, capCol: '#3a3a3a' });
        hum += (() => { const a = C.P([HX - 3, 11, HZ + 4]); return `<path d="M${f1(a[0])} ${f1(a[1])}q${f1(-0.6 * C.k)} ${f1(3 * C.k)} ${f1(0.4 * C.k)} ${f1(6 * C.k)}" stroke="#ffffff" stroke-width="${f1(0.5 * C.k)}" fill="none" opacity="0.7"/>`; })();
        const plume = mist(C, HX, 15.6, HZ, 5, 0.75);
        // sound machine
        const SR = 4.8, SH = 4.6;
        let snd = cyl3(C, [SX, 0, SZ], [SX, SH, SZ], SR, '#efe8d8', { olw: 0.4 }) + (() => { let v = ''; for (let i = 0; i < 24; i++) { const a = i / 24 * 2 * PI; if (Math.cos(a - C.thV) < 0.1) continue; v += line3(C, [[SX + (SR + 0.02) * Math.sin(a), 1.2, SZ + (SR + 0.02) * Math.cos(a)], [SX + (SR + 0.02) * Math.sin(a), SH - 1, SZ + (SR + 0.02) * Math.cos(a)]], 0.35, '#8a8070'); } return v; })()
          + cyl3(C, [SX, SH, SZ], [SX, SH + 1.6, SZ], SR - 0.1, '#f6f0e2', { r2: SR - 1.6, olw: 0.4, cap: rr => `<g>${rep(6, i => `<path d="M${f1(-rr * 0.8)} ${f1(-rr * 0.75 + i * rr * 0.3)}H${f1(rr * 0.8)}" stroke="#8a8070" stroke-width="0.4" opacity="0.5" stroke-dasharray="${f1(rr * 0.25)} 0.4"/>`).join('')}</g>` })
          + (() => { const a = C.P([SX + SR * Math.sin(C.thV), 0.9, SZ + SR * Math.cos(C.thV)]); return `<circle cx="${f1(a[0])}" cy="${f1(a[1])}" r="${f1(0.3 * C.k)}" fill="#ffb050"/><circle cx="${f1(a[0])}" cy="${f1(a[1])}" r="${f1(0.9 * C.k)}" fill="#ffb050" opacity="0.3"/>`; })();
        const rip = rep(3, i => { const c = C.P([SX, SH * 0.5, SZ]); return `<g transform="translate(${P2(c)})"><ellipse rx="${f1((SR + 1) * C.k)}" ry="${f1((SR + 1) * C.k * 0.5)}" fill="none" stroke="#c8b8a0" stroke-width="${f1(0.25 * C.k)}" opacity="0">${an('opacity', '0;0.5;0', 3, -i)}<animateTransform attributeName="transform" type="scale" values="1;1.5" dur="3s" begin="${-i}s" repeatCount="indefinite"/></ellipse></g>`; }).join('');
        const items = [{ q: [HX, 6, HZ], s: hum }, { q: [SX, 2, SZ], s: snd }];
        let s = shadow(C, HX, HZ, 9, 6.4, 0.45) + shadow(C, SX, SZ, 6, 4, 0.5) + cord(C, [[SX, 0.4, SZ - SR], [SX - 2, 0.3, -7], [HX + 3, 0.3, -7.6], [HX + 6, 0.3, -9]], '#f0ece4') + vs(C, items) + `<g>${rip}</g>` + plume;
        C.p(-18, 0, 0); C.p(18, 0, 0); C.p(HX, 26, HZ);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-060 SMART SUNRISE ALARM, AIR PURIFIER & ESSENTIAL OIL NEBULIZER (T3): a tall cylindrical air purifier in a warm grey knitted fabric sleeve
    // with a pale oak top, a perforated outlet and a soft LED air-quality ring; a frosted round sunrise lamp on a white stand with a dim clock under
    // its face; a little walnut and glass oil nebulizer with an amber bottle of lavender oil. Live: the sunrise face slowly fills with dawn (deep red
    // to orange to warm white) and fades back, the purifier ring breathes and air shimmers off its top, and a fine scented mist curls up from the
    // nebulizer.
    N.dawn30 = S => { const D = { w: 28, d: 18, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('dawn30'), id = C.u('e60'), PX = -7.4, PZ = -2, PR = 5.4, PH = 24, LX = 5.6, LZ = -0.6, NX = 11, NZ = 5;
        // purifier: knit sleeve (rings of stitches on the visible half), oak top with perforations + LED ring
        let pur = cyl3(C, [PX, 0, PZ], [PX, 1.2, PZ], PR + 0.2, '#e8e4dc', { olw: 0.35 }) + cyl3(C, [PX, 1.2, PZ], [PX, PH, PZ], PR, '#b8b0a4', { mat: 'matte', olw: 0.4, noCap: 1 });
        for (let y = 2; y < PH - 0.5; y += 0.9) { const P = rep(21, i => { const a = C.thV - PI / 2 + i / 20 * PI; return C.p(PX + (PR + 0.03) * Math.sin(a), y, PZ + (PR + 0.03) * Math.cos(a)); }); pur += `<path d="M${P.map(P2).join('L')}" stroke="${(y | 0) % 2 ? '#a8a094' : '#c8c0b4'}" stroke-width="${f1(0.28 * C.k)}" fill="none" stroke-dasharray="${f1(0.35 * C.k)} ${f1(0.2 * C.k)}" opacity="0.7"/>`; }
        pur += cyl3(C, [PX, PH, PZ], [PX, PH + 1.6, PZ], PR + 0.1, '#d8bc90', { olw: 0.35, cap: rr => `<circle r="${f1(rr * 0.92)}" fill="#d4b88c"/>` + rep(5, i => `<circle r="${f1(rr * (0.2 + i * 0.15))}" fill="none" stroke="#5a4a3a" stroke-width="0.3" stroke-dasharray="0.25 0.35"/>`).join('') + `<circle r="${f1(rr * 0.95)}" fill="none" stroke="#f8d8a0" stroke-width="0.35">${an('opacity', '0.4;1;0.4', 5, 0, SPL(2))}</circle><circle cx="${f1(rr * 0.6)}" cy="${f1(rr * 0.6)}" r="0.35" fill="#8ad08a"/>` });
        const air = rep(4, i => { const a = C.P([PX + (i - 1.5) * 2.2, PH + 2, PZ]); return `<path d="M${f1(a[0])} ${f1(a[1])}q${f1(0.8 * C.k)} ${f1(-3 * C.k)} 0 ${f1(-6 * C.k)}" stroke="#ffffff" stroke-width="${f1(0.5 * C.k)}" fill="none" opacity="0">${an('opacity', '0;0.5;0', 3, -i * 0.7)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-3 * C.k)}" dur="3s" begin="${-i * 0.7}s" repeatCount="indefinite"/></path>`; }).join('');
        // sunrise lamp: round frosted face on a stand, clock under the face
        const LY = 8.2, LR = 5.2, fr = C.v[2] > 0;
        let lamp = box3(C, { c: [LX, 0, LZ], w: 9, h: 2.4, d: 6, col: '#f2f0ea', r: 1.2, dec: { f: `<rect x="2.6" y="0.5" width="3.8" height="1.4" rx="0.3" fill="#2a2420"/><text x="4.5" y="1.6" text-anchor="middle" font-size="1.1" font-family="Arial" fill="#ffb060">6:30</text>` } })
          + box3(C, { c: [LX, 2.4, LZ - 0.6], w: 2.4, h: 2.4, d: 1.8, col: '#ece8e0', r: 0.6 });
        lamp += cyl3(C, [LX, LY, LZ - 1.4], [LX, LY, LZ + 0.4], LR, '#f4f2ec', { n: 36, olw: 0.4, cap: fr ? rr => `<circle r="${f1(rr * 0.9)}" fill="url(#${id}d)"/><circle r="${f1(rr * 0.9)}" fill="#fff4dc" opacity="0">${an('opacity', '0;0;0.85;0.85;0', 24, 0, KT('0;0.15;0.55;0.75;1'))}</circle><circle r="${f1(rr * 0.9)}" fill="#ff8a3a" opacity="0">${an('opacity', '0;0.7;0.5;0.3;0', 24, 0, KT('0;0.2;0.45;0.7;1'))}</circle><ellipse cx="${f1(-rr * 0.3)}" cy="${f1(-rr * 0.35)}" rx="${f1(rr * 0.35)}" ry="${f1(rr * 0.18)}" fill="#ffffff" opacity="0.4" transform="rotate(-30 ${f1(-rr * 0.3)} ${f1(-rr * 0.35)})"/>` : undefined });
        const halo = fr ? (() => { const c = C.P([LX, LY, LZ + 0.6]); return `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(9 * C.k)}" fill="#ffb060" opacity="0" filter="url(#m11b4)">${an('opacity', '0;0.15;0.45;0.4;0', 24, 0, KT('0;0.2;0.55;0.75;1'))}</circle>`; })() : '';
        // nebulizer: walnut base, glass dome, amber bottle upside down, mist
        let neb = cyl3(C, [NX, 0, NZ], [NX, 2.2, NZ], 2.4, '#6a4428', { olw: 0.3 }) + cyl3(C, [NX, 2.2, NZ], [NX, 5, NZ], 1.9, '#e8f0f0', { r2: 1, op: 0.55, olw: 0.25 })
          + cyl3(C, [NX, 8.6, NZ], [NX, 5.2, NZ], 1.2, '#a8601e', { op: 0.92, olw: 0.25 }) + cyl3(C, [NX, 5.6, NZ], [NX, 4.8, NZ], 0.6, '#2a2a2a', { olw: 0.2 })
          + (() => { const a = C.P([NX, 7, NZ + 1.2]); return `<rect x="${f1(a[0] - 0.8 * C.k)}" y="${f1(a[1] - 0.6 * C.k)}" width="${f1(1.6 * C.k)}" height="${f1(1.2 * C.k)}" fill="#efe6d2"/><rect x="${f1(a[0] - 0.6 * C.k)}" y="${f1(a[1] - 0.2 * C.k)}" width="${f1(1.2 * C.k)}" height="${f1(0.3 * C.k)}" fill="#8a6ab0"/>`; })();
        const nm = mist(C, NX + 0.6, 5, NZ, 3, 0.3);
        const items = [{ q: [PX, 12, PZ], s: pur + air }, { q: [LX, 5, LZ], s: halo + lamp }, { q: [NX, 3, NZ], s: neb + nm }];
        let s = shadow(C, PX, PZ, 7, 6, 0.5) + shadow(C, LX, LZ, 6.4, 4, 0.45) + shadow(C, NX, NZ, 3, 2.2, 0.45) + cord(C, [[LX, 0.4, LZ - 3], [LX - 1, 0.3, -8], [PX + 4, 0.3, -8.4]], '#f0ece4') + vs(C, items);
        C.p(-14, 0, 0); C.p(14, 0, 0);
        return { defs: DEF19 + `<defs><radialGradient id="${id}d"><stop offset="0" stop-color="#ffd8a0"/><stop offset="0.5" stop-color="#ff9a5a"/><stop offset="1" stop-color="#c8402a"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    const glw = (C, q, r, col, op, A) => { const c = C.P(q); return `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * C.k)}" fill="${col}" opacity="${op}" filter="url(#m11b4)">${A || ''}</circle>`; };

    // BED-080 CONCEALED CEILING PROJECTOR FOR BEDTIME MOVIES (T4): a walnut ceiling disc with a brushed-brass ring whose hatch has slid open; a
    // matte-black cinema projector with a brass vent band has dropped out of it on a brass telescoping arm, its glass lens glowing, throwing a soft
    // warm beam across the room. Was a floor piece: now hangs from the ceiling (mount 'ceil', Squad House v6 migration s.bed30c lifts placed ones).
    // Live: the beam flickers with the colours of the film, dust motes glint in it and the status light breathes.
    N.proj30 = S => { const T = 16, D = { w: 60, d: 50, zs: 1, mount: 'ceil', build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('proj30'), id = C.u('e80'), k = C.k;
        const dcl = C.u('dc');
        const disc = cyl3(C, [0, T - 2.2, 0], [0, T - 1.6, 0], 11.3, '#c8a462', { mat: 'metal', olw: 0.3 })
          + cyl3(C, [0, T - 1.6, 0], [0, T, 0], 11, '#6a4428', { olw: 0.4, capCol: '#6a4428', cap: rr => `<clipPath id="${dcl}"><circle r="${f1(rr)}"/></clipPath><circle r="${f1(rr)}" fill="#6a4428"/><g clip-path="url(#${dcl})">` + rep(14, i => `<path d="M${f1(-rr)} ${f1(-rr + i * rr / 7)}Q0 ${f1(-rr + i * rr / 7 + (R() - 0.5) * 2)} ${f1(rr)} ${f1(-rr + i * rr / 7)}" stroke="#4a2c18" stroke-width="0.25" fill="none" opacity="0.6"/>`).join('') + `</g><circle r="${f1(rr * 0.98)}" fill="none" stroke="#d8b878" stroke-width="0.6"/>` });
        const arm = cyl3(C, [0, T - 2.2, 0], [0, 9.6, 0], 0.9, '#c8a462', { mat: 'metal', olw: 0.3 }) + cyl3(C, [0, 9.8, 0], [0, 5, 0], 0.6, '#d8b878', { mat: 'metal', olw: 0.3 }) + cyl3(C, [0, 5.4, 0], [0, 5, 0], 2.4, '#c8a462', { mat: 'metal', olw: 0.3 });
        const vent = w => `<rect x="0" y="0.6" width="${w}" height="0.9" fill="#c8a462"/>` + rep(Math.floor(w / 0.8), i => `<rect x="${f1(0.3 + i * 0.8)}" y="2.2" width="0.4" height="1.4" rx="0.15" fill="#111111"/>`).join('');
        const body = box3(C, { c: [0, 0.4, 0], w: 13, h: 4.6, d: 9.4, col: '#2c2a28', r: 1.4, gl: 0.25, dec: { f: vent(13) + `<circle cx="11.6" cy="3.6" r="0.3" fill="#ffb050">${an('opacity', '0.4;1;0.4', 4, 0, SPL(2))}</circle>`, b: vent(13), l: vent(9.4) } });
        const L = [8.6, 2.8, 0.8], lens = cyl3(C, [6.4, 2.8, 0.8], L, 1.9, '#1a1a1a', { olw: 0.3, capCol: '#3a3430', cap: rr => `<circle r="${f1(rr * 0.85)}" fill="#c8a462"/><circle r="${f1(rr * 0.68)}" fill="url(#${id}l)"/><circle cx="${f1(-rr * 0.2)}" cy="${f1(-rr * 0.25)}" r="${f1(rr * 0.18)}" fill="#ffffff" opacity="0.8"/>` });
        // beam
        const L2 = C.P(L), E = [32, -8, 0.8], ring = rep(16, i => { const a = i / 16 * 2 * PI; return C.P([E[0], E[1] + Math.sin(a) * 7, E[2] + Math.cos(a) * 7]); }), E2 = C.P(E), bp = H.pth(H.hull([L2].concat(ring)));
        const beam = `<defs><linearGradient id="${id}b" gradientUnits="userSpaceOnUse" x1="${f1(L2[0])}" y1="${f1(L2[1])}" x2="${f1(E2[0])}" y2="${f1(E2[1])}"><stop offset="0" stop-color="#fff2d0" stop-opacity="0.6"/><stop offset="0.5" stop-color="#ffe4b8" stop-opacity="0.2"/><stop offset="1" stop-color="#ffd8a0" stop-opacity="0"/></linearGradient></defs>`
          + `<path d="${bp}" fill="url(#${id}b)"/><path d="${bp}" fill="url(#${id}b)" opacity="0.6"><animate attributeName="opacity" values="0.3;0.7;0.45;0.8;0.35;0.6;0.3" dur="5s" repeatCount="indefinite"/></path>`
          + `<path d="${bp}" fill="#b89aff" opacity="0">${an('opacity', '0;0.12;0;0;0.1;0', 9)}</path><path d="${bp}" fill="#ffb070" opacity="0">${an('opacity', '0;0;0.14;0;0;0', 9)}</path>`
          + rep(12, () => { const t = 0.15 + R() * 0.8, p = C.P([L[0] + (E[0] - L[0]) * t, L[1] + (E[1] - L[1]) * t + (R() - 0.5) * 9 * t, L[2] + (R() - 0.5) * 9 * t]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.25 * k)}" fill="#fff8e0" opacity="0">${an('opacity', '0;0.9;0', n4(2 + R() * 3), n4(-R() * 4), SPL(2))}</circle>`; }).join('');
        const lglow = glw(C, L, 4, '#ffe8c0', 0.6, an('opacity', '0.45;0.75;0.5;0.8;0.45', 5));
        const front = C.v[0] > 0;
        let s = disc + arm + (front ? body + lens : lens + body) + lglow + beam;
        return { defs: DEF19 + `<defs><radialGradient id="${id}l"><stop offset="0" stop-color="#fffbe8"/><stop offset="0.4" stop-color="#ffe0a0"/><stop offset="1" stop-color="#5a4a6a"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-100 NEURAL-WAVE LUCID DREAM INDUCER & OXYGEN-ENRICHED MICRO-CLIMATE HUB (T5): a two-tier honed travertine plinth banded in champagne gold,
    // its top planted with a ring of living moss and tiny white flowers, round a gold cradle holding a floating pearl orb with a slow rose-and-amber
    // dream swirl inside; two crossed polished-gold gyroscope rings circle it; beside it a silk-wrapped neural headband rests on a slim brass stand.
    // Live: the orb breathes and its swirl turns, soft neural waves ripple out round it, the rings' glints travel, oxygen-rich mist rolls out of the
    // plinth's shadow gap and the headband's gold dots pulse slowly.
    N.dream30 = S => { const D = { w: 70, d: 70, zs: 0.45, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('dream30'), id = C.u('e100'), k = C.k, OY = 34, OR = 10, GR = 17;
        const trav = rr => `<circle r="${f1(rr)}" fill="#e6d8be"/>` + rep(40, () => { const a = R() * 2 * PI, r = R() * rr; return `<ellipse cx="${f1(Math.cos(a) * r)}" cy="${f1(Math.sin(a) * r)}" rx="${f1(0.4 + R() * 1.4)}" ry="${f1(0.2 + R() * 0.4)}" fill="#c8b490" opacity="0.6"/>`; }).join('');
        let base = cyl3(C, [0, 0, 0], [0, 1.6, 0], 27, '#2a2420', { olw: 0.3 }) + cyl3(C, [0, 1.6, 0], [0, 9, 0], 28, '#e2d4b8', { mat: 'matte', olw: 0.4 }) + cyl3(C, [0, 9, 0], [0, 10, 0], 28.3, '#d4b070', { mat: 'metal', olw: 0.3 })
          + cyl3(C, [0, 10, 0], [0, 13, 0], 23, '#e8dcc4', { mat: 'matte', olw: 0.4, cap: trav });
        // shadow-gap glow + mist
        base += glw(C, [0, 1, 0], 30, '#ffd8a0', 0.25, an('opacity', '0.15;0.32;0.15', 8, 0, SPL(2)));
        // moss ring + flowers on the top
        let moss = ''; rep(260, () => { const a = R() * 2 * PI, r = 9 + R() * 12.5, p = C.P([r * Math.sin(a), 13.2 + R() * 0.8, r * Math.cos(a)]); moss += `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1((0.5 + R() * 0.9) * k)}" fill="${['#5a7a3a', '#6a8a44', '#7e9a50', '#4a6a30'][(R() * 4) | 0]}"/>`; });
        rep(26, () => { const a = R() * 2 * PI, r = 10 + R() * 11, p = C.P([r * Math.sin(a), 14.2, r * Math.cos(a)]); moss += `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.4 * k)}" fill="#fffaf0"/><circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.15 * k)}" fill="#f0c860"/>`; });
        const cradle = cyl3(C, [0, 13, 0], [0, 18, 0], 4.6, '#d4b070', { mat: 'metal', r2: 2.6, olw: 0.3 }) + cyl3(C, [0, 18, 0], [0, 19.2, 0], 3.6, '#e8c888', { mat: 'metal', olw: 0.3 });
        // orb with swirl
        const oc = C.P([0, OY, 0]), orR = OR * k, oid = C.u('ok');
        const orb = glw(C, [0, OY, 0], OR * 2.4, '#ffd8b0', 0.5, an('opacity', '0.35;0.65;0.35', 7, 0, SPL(2)))
          + `<clipPath id="${oid}"><circle cx="${f1(oc[0])}" cy="${f1(oc[1])}" r="${f1(orR)}"/></clipPath><circle cx="${f1(oc[0])}" cy="${f1(oc[1])}" r="${f1(orR)}" fill="url(#${id}o)"/>`
          + `<g clip-path="url(#${oid})"><g filter="url(#m12b1)">${at('rotate', `0 ${P2(oc)};360 ${P2(oc)}`, 26)}<ellipse cx="${f1(oc[0] - orR * 0.3)}" cy="${f1(oc[1])}" rx="${f1(orR * 0.6)}" ry="${f1(orR * 0.25)}" fill="#f4a0b0" opacity="0.5" transform="rotate(30 ${P2(oc)})"/><ellipse cx="${f1(oc[0] + orR * 0.3)}" cy="${f1(oc[1] + orR * 0.2)}" rx="${f1(orR * 0.55)}" ry="${f1(orR * 0.2)}" fill="#ffc870" opacity="0.5" transform="rotate(-20 ${P2(oc)})"/><ellipse cx="${f1(oc[0])}" cy="${f1(oc[1] - orR * 0.4)}" rx="${f1(orR * 0.4)}" ry="${f1(orR * 0.15)}" fill="#c8a8f0" opacity="0.4"/></g></g>`
          + `<circle cx="${f1(oc[0])}" cy="${f1(oc[1])}" r="${f1(orR)}" fill="#fff8f0" opacity="0.2">${an('opacity', '0.1;0.35;0.1', 7, 0, SPL(2))}</circle><ellipse cx="${f1(oc[0] - orR * 0.35)}" cy="${f1(oc[1] - orR * 0.4)}" rx="${f1(orR * 0.3)}" ry="${f1(orR * 0.18)}" fill="#ffffff" opacity="0.75" transform="rotate(-30 ${f1(oc[0] - orR * 0.35)} ${f1(oc[1] - orR * 0.4)})"/>`;
        // neural waves: rings in the orb's horizontal plane expanding out
        const waves = `<g transform="${FR(C, [0, OY - 2, 0], [1, 0, 0], [0, 0, 1])}">` + rep(3, i => `<circle r="${OR + 2}" fill="none" stroke="#ffd0b0" stroke-width="0.5" opacity="0">${an('opacity', '0;0.6;0', 6, -i * 2)}<animate attributeName="r" values="${OR + 2};${OR + 16}" dur="6s" begin="${-i * 2}s" repeatCount="indefinite"/></circle>`).join('') + '</g>';
        // gyroscope rings: split into back/front halves by depth
        const gyro = (front) => { let o = ''; [[1, 0], [0, 1]].forEach(([ax, az], j) => { const P = rep(65, i => { const t = i / 64 * 2 * PI; return [GR * Math.cos(t) * ax, OY + GR * Math.sin(t), GR * Math.cos(t) * az]; });
            let d = '', on = false; P.forEach(p => { const f = p[0] * C.v[0] + (p[1] - OY) * C.v[1] + p[2] * C.v[2] > 0; if (f === front) { d += (on ? 'L' : 'M') + P2(C.P(p)); on = true; } else on = false; });
            o += `<path d="${d}" stroke="#a8823e" stroke-width="${f1(1.3 * k)}" fill="none" stroke-linecap="round"/><path d="${d}" stroke="#f4dca0" stroke-width="${f1(0.45 * k)}" fill="none" stroke-linecap="round"/>`
              + (front ? `<path d="${d}" pathLength="100" stroke="#fffbe8" stroke-width="${f1(0.6 * k)}" fill="none" stroke-dasharray="5 95" stroke-linecap="round"><animate attributeName="stroke-dashoffset" values="${j ? 0 : 100};${j ? 100 : 0}" dur="7s" repeatCount="indefinite"/></path>` : ''); });
          return o; };
        const ringsBack = gyro(false), ringsFront = gyro(true);
        const pins = [[GR, OY], [-GR, OY]].map(([x, y]) => sph(C, [x, y, 0], 0.9, '#e8c888')).join('');
        // headband on a brass stand
        const HX = 26, HZ = 22, HY = 20;
        let hb = cyl3(C, [HX, 0, HZ], [HX, 0.8, HZ], 3, '#c8a462', { mat: 'metal', olw: 0.3 }) + cyl3(C, [HX, 0.8, HZ], [HX, HY, HZ], 0.45, '#d8b878', { mat: 'metal', olw: 0.25 });
        { const P = rep(25, i => { const t = PI * i / 24; return C.P([HX + 4.4 * Math.cos(t), HY + 4.4 * Math.sin(t) * 0.9 - 4, HZ]); }); hb += `<path d="M${P.map(P2).join('L')}" stroke="#d8cbb8" stroke-width="${f1(2 * k)}" fill="none" stroke-linecap="round"/><path d="M${P.map(P2).join('L')}" stroke="#f6efe4" stroke-width="${f1(1 * k)}" fill="none" stroke-linecap="round"/>`
          + [5, 9, 12, 15, 19].map((i, j) => `<circle cx="${f1(P[i][0])}" cy="${f1(P[i][1])}" r="${f1(0.35 * k)}" fill="#ffc870">${an('opacity', '0.3;1;0.3', 4, -j * 0.6, SPL(2))}</circle>`).join(''); }
        const mists = [0, 1, 2, 3, 4, 5].map(i => { const a = i / 6 * 2 * PI; if (Math.cos(a - C.thV) < -0.2) return ''; return mist(C, 28.5 * Math.sin(a), 0.6, 28.5 * Math.cos(a), 3, 0.8); }).join('');
        const items = [{ q: [0, 10, 0], s: base + moss + cradle + ringsBack + orb + waves + pins + ringsFront }, { q: [HX, 10, HZ], s: hb }];
        let s = shadow(C, 0, 0, 30, 30, 0.5) + vs(C, items) + mists;
        C.p(-35, 0, 0); C.p(35, 0, 0); C.p(0, OY + GR + 2, 0);
        return { defs: DEF19 + `<defs><radialGradient id="${id}o" cx="40%" cy="38%" r="65%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.45" stop-color="#fff2e6"/><stop offset="0.85" stop-color="#f4d8c8"/><stop offset="1" stop-color="#e0b8a8"/></radialGradient></defs>`, front: s, bb: C.bb(4) }; };
      return D; };

    // BED-002 CARDBOARD MOVING BOX NEXT TO MATTRESS (T1): an upturned double-wall moving box doing duty as a nightstand: kraft board gone soft and
    // scuffed, corrugated edges showing at the flaps, printed THIS SIDE UP arrows (upside down now) and a FRAGILE stamp, marker scrawl "BEDROOM -
    // MISC" crossed out to "BOOKS!!", a crushed top corner, packing tape across the top and down the front with a torn curling end, a coffee ring and
    // a burn-free tea-light scorch on top. Live: the torn tape end lifts and flutters in the draught.
    N.box30 = S => { const D = { w: 60, d: 46, zs: 0.7, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('box30'), id = C.u('f02'), BW = 46, BH = 38, BD = 34;
        const corr = (w, h) => rep(Math.floor(w / 0.6), i => `<path d="M${f1(i * 0.6)} 0V${h}" stroke="#a87c48" stroke-width="0.08" opacity="${f1(0.15 + R() * 0.1)}"/>`).join('')
          + rep(10, () => `<ellipse cx="${f1(R() * w)}" cy="${f1(R() * h)}" rx="${f1(2 + R() * 5)}" ry="${f1(1 + R() * 2)}" fill="${R() < 0.5 ? '#8a6438' : '#e0b880'}" opacity="0.1"/>`).join('');
        const arrows = (x, y) => `<g transform="translate(${x} ${y}) rotate(180)"><path d="M-2.6 2V-0.6H-3.6L-1.8 -2.8L0 -0.6H-1V2ZM1 2V-0.6H0L1.8 -2.8L3.6 -0.6H2.6V2Z" fill="#2a2420" opacity="0.75"/><text y="4" text-anchor="middle" font-family="Arial Black,Arial" font-weight="bold" font-size="1.3" fill="#2a2420" opacity="0.75">THIS SIDE UP</text></g>`;
        const front = `<rect width="${BW}" height="${BH}" fill="#c89a62"/>` + corr(BW, BH) + arrows(BW - 9, BH - 9)
          + `<g transform="translate(8 26) rotate(-8)"><rect x="-6" y="-2.2" width="12" height="4.4" fill="none" stroke="#b8302a" stroke-width="0.45" opacity="0.7"/><text y="1.1" text-anchor="middle" font-family="Arial Black,Arial" font-weight="bold" font-size="2.8" fill="#b8302a" opacity="0.7">FRAGILE</text></g>`
          + `<text x="6" y="11" font-family="'Comic Sans MS','Marker Felt',cursive" font-size="3.6" fill="#1a1a1a" transform="rotate(-3 6 11)">BEDROOM - MISC</text><path d="M5 9.6L33 8.2" stroke="#1a1a1a" stroke-width="0.5"/><text x="10" y="17" font-family="'Comic Sans MS','Marker Felt',cursive" font-size="4.4" fill="#1a1a1a" transform="rotate(-5 10 17)">BOOKS!!</text>`
          + `<rect x="${f1(BW / 2 - 3.4)}" y="0" width="6.8" height="13" fill="#c8b480" opacity="0.55"/><rect x="${f1(BW / 2 - 3.4)}" y="0" width="1" height="13" fill="#ffffff" opacity="0.25"/>`
          + `<path d="M${BW} 0L${BW - 6} 0L${BW - 2.4} 4.2L${BW} 5.6Z" fill="#a87a44" opacity="0.6"/><path d="M${BW - 6} 0L${BW - 2.4} 4.2L${BW} 5.6" stroke="#6a4a24" stroke-width="0.25" fill="none"/><path d="M${BW - 4.4} 1.6l1.6 1.6" stroke="#6a4a24" stroke-width="0.15"/>`
          + `<path d="M0 ${BH - 0.4}H${BW}" stroke="#6a4a24" stroke-width="0.6" opacity="0.4"/>` + rep(6, () => `<path d="M${f1(R() * BW)} ${f1(BH - R() * 4)}l${f1(R() * 3)} ${f1(-R())}" stroke="#7a5430" stroke-width="0.2" opacity="0.5"/>`).join('');
        const side = (lab) => `<rect width="${BD}" height="${BH}" fill="#c4965e"/>` + corr(BD, BH) + (lab ? `<rect x="4" y="6" width="14" height="8" fill="#f4f0e4"/><text x="5" y="9" font-family="Arial" font-size="1.4" fill="#3a3a3a">MOVE-IT SUPPLY</text><text x="5" y="11.4" font-family="Arial" font-size="1.2" fill="#3a3a3a">DOUBLE WALL · 65 lb</text><path d="M5 12.6h11" stroke="#3a3a3a" stroke-width="0.3" stroke-dasharray="0.3 0.2"/>` : arrows(BD / 2, BH - 10)) + `<rect x="${f1(BD / 2 - 5)}" y="4" width="10" height="3.6" rx="1.6" fill="#3a2a18" opacity="0.65"/>`;
        // top: seam between the (now bottom) flaps is underneath; top shows the box bottom with tape cross, corrugated cut edge, coffee ring
        const top = `<rect width="${BW}" height="${BD}" fill="#ccA068"/>` + corr(BW, BD) + `<path d="M0 ${f1(BD / 2)}H${BW}" stroke="#7a5430" stroke-width="0.5" opacity="0.6"/>`
          + `<rect x="0" y="${f1(BD / 2 - 3.4)}" width="${BW}" height="6.8" fill="#c8b480" opacity="0.6"/><rect x="0" y="${f1(BD / 2 - 3.4)}" width="${BW}" height="0.8" fill="#ffffff" opacity="0.25"/>`
          + `<rect x="${f1(BW / 2 - 3.4)}" y="${f1(BD / 2)}" width="6.8" height="${f1(BD / 2)}" fill="#c8b480" opacity="0.6"/>`
          + `<circle cx="12" cy="9" r="3.2" fill="none" stroke="#7a4a1e" stroke-width="0.5" opacity="0.5"/><circle cx="12.4" cy="9.3" r="2.9" fill="none" stroke="#7a4a1e" stroke-width="0.2" opacity="0.35"/><path d="M8.4 10.4q-1 1.4 -0.2 2.6" stroke="#7a4a1e" stroke-width="0.3" fill="none" opacity="0.4"/>`
          + `<ellipse cx="34" cy="26" rx="4" ry="3" fill="#5a3a1e" opacity="0.12"/>` + `<path d="M${BW} 0L${BW - 6} 0L${BW - 3} 3.4L${BW} 4Z" fill="#9a6e3a" opacity="0.7"/>`;
        let s = shadow(C, 0, 0, BW * 0.62, BD * 0.62, 0.55) + box3(C, { c: [0, 0, 0], w: BW, h: BH, d: BD, col: '#c89a62', r: 0.3, dec: { f: front, b: side(0), l: side(1), r: side(0), t: top } });
        // torn tape end (front, curls off the top edge and flutters)
        if (C.v[2] > -0.2) { const a = C.P([-3.4, BH - 13, BD / 2 + 0.1]), kk = C.k, t1 = `M0 0L${f1(6.8 * kk)} 0L${f1(6 * kk)} ${f1(4 * kk)}Q${f1(3.4 * kk)} ${f1(5.6 * kk)} ${f1(1 * kk)} ${f1(4.6 * kk)}Z`, t2 = `M0 0L${f1(6.8 * kk)} 0L${f1(6.4 * kk)} ${f1(3 * kk)}Q${f1(3.8 * kk)} ${f1(3.4 * kk)} ${f1(0.6 * kk)} ${f1(3.8 * kk)}Z`;
          s += `<g transform="translate(${P2(a)})"><path d="${t1}" fill="#d8c898" opacity="0.85" stroke="#a8986a" stroke-width="${f1(0.1 * kk)}"><animate attributeName="d" values="${t1};${t2};${t1}" dur="3.4s" repeatCount="indefinite" ${SPL(2)}/></path></g>`; }
        C.p(-30, 0, 0); C.p(30, 0, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    const clipB = (C, w, h, svg) => { const i = C.u('cb'); return `<clipPath id="${i}"><rect width="${f1(w)}" height="${f1(h)}"/></clipPath><g clip-path="url(#${i})">${svg}</g>`; };
    const decC = (C, o) => { const d = o.dec; if (!d) return o; const W = o.w, Hh = o.h, Dd = o.d, sz = { f: [W, Hh], b: [W, Hh], l: [Dd, Hh], r: [Dd, Hh], t: [W, Dd], u: [W, Dd] }, nd = {}; Object.keys(d).forEach(k => nd[k] = clipB(C, sz[k][0], sz[k][1], d[k])); return Object.assign({}, o, { dec: nd }); };
    const grainH = (R, w, h, n, c, o) => rep(n, () => { const y = R() * h; return `<path d="M0 ${f1(y)}Q${f1(w * 0.3)} ${f1(y + (R() - 0.5) * 1.2)} ${f1(w * 0.6)} ${f1(y + (R() - 0.5) * 0.8)}T${f1(w)} ${f1(y + (R() - 0.5) * 1)}" stroke="${c}" stroke-width="${f1(0.08 + R() * 0.14)}" fill="none" opacity="${f1((o || 0.4) * (0.5 + R() * 0.6))}"/>`; }).join('');
    const grainV = (R, w, h, n, c, o) => rep(n, () => { const x = R() * w; return `<path d="M${f1(x)} 0Q${f1(x + (R() - 0.5) * 1.2)} ${f1(h * 0.4)} ${f1(x + (R() - 0.5) * 0.8)} ${f1(h * 0.7)}T${f1(x + (R() - 0.5))} ${f1(h)}" stroke="${c}" stroke-width="${f1(0.08 + R() * 0.14)}" fill="none" opacity="${f1((o || 0.4) * (0.5 + R() * 0.6))}"/>`; }).join('');
    const veins = (R, w, h, n) => rep(n, i => { let x = R() * w, y = -1, d = `M${f1(x)} ${f1(y)}`; const a = (R() - 0.5) * 1.6; for (let j = 0; j < 8; j++) { x += Math.sin(a + (R() - 0.5)) * w / 8; y += h / 7; d += `L${f1(x)} ${f1(y)}`; }
      return `<path d="${d}" stroke="${i % 3 ? '#9a9ca2' : '#c8a868'}" stroke-width="${f1(0.15 + R() * 0.4)}" fill="none" opacity="${f1(0.35 + R() * 0.4)}" stroke-linejoin="round"/><path d="${d}" stroke="#b8bcc4" stroke-width="${f1(1.2 + R())}" fill="none" opacity="0.1"/>`; }).join('');

    // BED-022 SINGLE-DRAWER WHITE PINE NIGHTSTAND (T2): a budget flat-pack pine nightstand in thin white paint with the grain still showing through,
    // a single drawer with a turned wooden knob and a hairline gap, an open shelf underneath on square legs, a chipped corner showing raw pine, a
    // ring mark and a scuff on the top, a cam-lock cap on the side; on the shelf a stack of paperbacks with a ribbon bookmark hanging out.
    // Live: the ribbon bookmark sways.
    N.pine30 = S => { const D = { w: 48, d: 42, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('pine30'), W = 38, DD = 32, HT = 42, WH = '#f2efe6';
        const paint = (w, h, v) => (v ? grainV : grainH)(R, w, h, 6, '#d8ccb0', 0.5) + rep(4, () => `<ellipse cx="${f1(R() * w)}" cy="${f1(R() * h)}" rx="${f1(1 + R() * 3)}" ry="0.5" fill="#e8dcc0" opacity="0.4"/>`).join('');
        const legs = [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([sx, sz]) => ({ q: [sx * (W / 2 - 1.6), 14, sz * (DD / 2 - 1.6)], s: box3(C, decC(C, { c: [sx * (W / 2 - 1.6), 0, sz * (DD / 2 - 1.6)], w: 2.8, h: HT - 2.4, d: 2.8, col: WH, r: 0.2, dec: { f: paint(2.8, HT - 2.4, 1) + (sx > 0 && sz > 0 ? '<rect x="0.4" y="36" width="2" height="1.4" fill="#d8b080"/>' : ''), r: paint(2.8, HT - 2.4, 1), l: paint(2.8, HT - 2.4, 1) } })) }));
        const back = { q: [0, 18, -DD / 2 + 1.2], s: box3(C, decC(C, { c: [0, 7, -DD / 2 + 1.2], w: W - 4, h: HT - 9.4, d: 0.8, col: '#ece8de', r: 0 })) };
        const sides = [-1, 1].map(sx => ({ q: [sx * (W / 2 - 1.6), 30, 0], s: box3(C, decC(C, { c: [sx * (W / 2 - 1.6), HT - 13.6, 0], w: 1.2, h: 11.2, d: DD - 4, col: WH, r: 0, dec: { r: paint(DD - 4, 11.2) + (sx > 0 ? `<circle cx="${f1(DD / 2 - 2)}" cy="5.6" r="0.7" fill="#e8e4d8" stroke="#a8a090" stroke-width="0.12"/><path d="M${f1(DD / 2 - 2.4)} 5.6h0.8" stroke="#8a8478" stroke-width="0.12"/>` : ''), l: paint(DD - 4, 11.2) } })) }));
        const shelf = { q: [0, 8, 0], s: box3(C, decC(C, { c: [0, 6.4, 0], w: W - 3, h: 1.6, d: DD - 3, col: WH, r: 0.2, dec: { t: paint(W - 3, DD - 3), f: paint(W - 3, 1.6) } })) };
        // drawer (front face a hair proud, gap line, knob)
        const dfront = `<rect width="${W - 4.4}" height="10.4" fill="${WH}"/>` + paint(W - 4.4, 10.4) + `<rect x="0.2" y="0.2" width="${W - 4.8}" height="10" fill="none" stroke="#c8c0ae" stroke-width="0.25"/><path d="M0 10.3H${W - 4.4}" stroke="#5a5040" stroke-width="0.35" opacity="0.6"/>`;
        const drawer = { q: [0, 30, DD / 2 - 1], s: box3(C, decC(C, { c: [0, HT - 13.4, 0.4], w: W - 4.4, h: 10.4, d: DD - 2.4, col: WH, r: 0.2, dec: { f: dfront } })) + (C.v[2] > 0 ? cyl3(C, [0, HT - 8.2, DD / 2 - 0.6], [0, HT - 8.2, DD / 2 + 0.6], 0.5, '#d8b080', { olw: 0.25 }) + sph(C, [0, HT - 8.2, DD / 2 + 1.5], 1.2, '#d8b484') : '') };
        const topDec = `<rect width="${W + 1}" height="${DD + 1}" fill="${WH}"/>` + paint(W + 1, DD + 1) + `<circle cx="9" cy="10" r="3" fill="none" stroke="#c8b898" stroke-width="0.4" opacity="0.6"/><path d="M24 22q4 -1 7 0.4" stroke="#8a8478" stroke-width="0.3" opacity="0.4"/>` + `<path d="M${W + 1} ${DD + 1}l-2.2 0l1 -1.6l1.2 -0.6Z" fill="#d8b080"/>`;
        const top = { q: [0, HT, 0], s: box3(C, decC(C, { c: [0, HT - 2.4, 0], w: W + 1, h: 2.4, d: DD + 1, col: WH, r: 0.5, dec: { t: topDec, f: paint(W + 1, 2.4) + `<path d="M${W - 1} 0l2 0l0 2.4l-1.4 -0.6Z" fill="#d8b080"/>`, r: paint(DD + 1, 2.4), l: paint(DD + 1, 2.4) } })) };
        // paperbacks on the shelf + swaying ribbon
        const BK = [['#c84a3a', 6.6, 1.4], ['#3a6a8a', 6.2, 1.2], ['#e8c860', 6.8, 1.6], ['#5a8a5a', 6, 1.1]];
        let y = 8, bk = '';
        BK.forEach(([c, w, h], i) => { const ox = (R() - 0.5) * 1.2; bk += box3(C, decC(C, { c: [-6 + ox, y, 2], w: w * 1.5, h, d: w, col: c, r: 0.2, dec: { f: `<rect y="${f1(h * 0.3)}" width="${f1(w * 1.5)}" height="${f1(h * 0.3)}" fill="#f4f0e4" opacity="0.6"/>`, r: `<rect width="${w}" height="${h}" fill="#f4efe2"/>` + rep(4, j => `<path d="M0 ${f1(h * (j + 1) / 5)}H${w}" stroke="#c8c0aa" stroke-width="0.06"/>`).join('') } })); y += h; });
        const rb = C.P([-1, 9.6, 2 + 3.4]), k = C.k, rbn = `<g>${at('rotate', `-8 ${P2(rb)};8 ${P2(rb)};-8 ${P2(rb)}`, 3.2, 0, SPL(2))}<path d="M${P2(rb)}l${f1(0.2 * k)} ${f1(3.6 * k)}l${f1(-0.4 * k)} ${f1(0.6 * k)}l${f1(0.6 * k)} -0.3l0.2 ${f1(0.5 * k)}" stroke="#a82a3a" stroke-width="${f1(0.45 * k)}" fill="none" stroke-linejoin="round"/></g>`;
        const books = { q: [-6, 9, 2], s: bk + (C.v[2] > -0.3 ? rbn : '') };
        const lb = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] <= 0), lf = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] > 0);
        const sd = sides.slice().sort((p, q) => p.q[0] * C.v[0] - q.q[0] * C.v[0]);
        let s = shadow(C, 0, 0, W * 0.62, DD * 0.62, 0.5) + lb.map(o => o.s).join('') + back.s + sd[0].s + shelf.s + books.s + drawer.s + sd[1].s + lf.map(o => o.s).join('') + top.s;
        C.p(-24, 0, 0); C.p(24, 0, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-042 MID-CENTURY CANE & WALNUT 2-DRAWER BEDSIDE TABLE (T3): an oiled American walnut case with softly rounded edges and a long straight grain,
    // two drawers faced in hand-woven rattan cane framed in walnut with slim brass pulls, a lip-edged top, on four splayed tapered legs ending in
    // brass ferrules. Live: a warm sheen slides along the oiled walnut top and the brass pulls glint.
    N.cane30 = S => { const D = { w: 48, d: 42, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('cane30'), id = C.u('f42'), W = 36, DD = 28, Y0 = 15, HC = 21, WN = '#6e442a';
        const cane = (w, h) => { let o = `<rect width="${w}" height="${h}" fill="#c89a5a"/>`; const g = 1.1;
          for (let x = 0; x < w + h; x += g) o += `<path d="M${f1(x)} 0L${f1(x - h)} ${h}" stroke="#e8c48a" stroke-width="0.32"/><path d="M${f1(x - h)} 0L${f1(x)} ${h}" stroke="#e8c48a" stroke-width="0.32"/>`;
          for (let x = g / 2; x < w; x += g) o += `<path d="M${f1(x)} 0V${h}" stroke="#d8ae70" stroke-width="0.28"/>`;
          for (let y = g / 2; y < h; y += g) o += `<path d="M0 ${f1(y)}H${w}" stroke="#d8ae70" stroke-width="0.28"/>`;
          for (let x = g / 2; x < w; x += g) for (let y = g / 2; y < h; y += g) o += `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.22" fill="#4a2c18" opacity="0.55"/>`;
          return o; };
        const fW = W - 2.4, dh = (HC - 3.6) / 2;
        const front = `<rect width="${W}" height="${HC}" fill="${WN}"/>` + grainH(R, W, HC, 10, '#4a2a18', 0.5)
          + [0, 1].map(i => { const y = 1.2 + i * (dh + 1.2); return `<rect x="1.2" y="${f1(y)}" width="${f1(fW)}" height="${f1(dh)}" fill="#3a2214"/><g transform="translate(2.4 ${f1(y + 1.2)})">${cane(fW - 2.4, dh - 2.4)}</g><rect x="2.4" y="${f1(y + 1.2)}" width="${f1(fW - 2.4)}" height="${f1(dh - 2.4)}" fill="none" stroke="#3a2214" stroke-width="0.4"/>`
            + `<rect x="${f1(W / 2 - 3)}" y="${f1(y + 0.35)}" width="6" height="0.6" rx="0.3" fill="#d8b46a"/><rect x="${f1(W / 2 - 3)}" y="${f1(y + 0.35)}" width="6" height="0.2" fill="#fff0c0" opacity="0.8"/>`; }).join('');
        const side = `<rect width="${DD}" height="${HC}" fill="${WN}"/>` + grainH(R, DD, HC, 10, '#4a2a18', 0.5);
        const legs = [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([sx, sz]) => { const a = [sx * (W / 2 - 3), Y0 + 0.5, sz * (DD / 2 - 3)], b = [sx * (W / 2 + 0.6), 1.2, sz * (DD / 2 + 0.6)], c = [sx * (W / 2 + 0.8), 0, sz * (DD / 2 + 0.8)];
          return { q: [a[0], 8, a[2]], s: cyl3(C, a, b, 1.25, '#6a4228', { r2: 0.75, olw: 0.3 }) + cyl3(C, b, c, 0.75, '#d8b46a', { mat: 'metal', r2: 0.65, olw: 0.25 }) }; });
        const sheenId = C.u('sh');
        const topD = `<rect width="${W + 1.2}" height="${DD + 1.2}" fill="${WN}"/>` + grainH(R, W + 1.2, DD + 1.2, 18, '#4a2a18', 0.5) + grainH(R, W + 1.2, DD + 1.2, 8, '#a87048', 0.35)
          + `<clipPath id="${sheenId}"><rect width="${W + 1.2}" height="${DD + 1.2}"/></clipPath><g clip-path="url(#${sheenId})"><rect x="-12" y="-4" width="8" height="${DD + 10}" fill="url(#${id}g)" transform="skewX(-20)">${an('x', `-12;${W + 14}`, 9)}</rect></g>`;
        const caseB = box3(C, decC(C, { c: [0, Y0, 0], w: W, h: HC, d: DD, col: WN, r: 1.6, dec: { f: front, l: side, r: side, b: side } }));
        const top = box3(C, decC(C, { c: [0, Y0 + HC, 0], w: W + 1.2, h: 1.4, d: DD + 1.2, col: '#74482c', r: 1.4, gl: 0.2, dec: { t: topD, f: grainH(R, W + 1.2, 1.4, 2, '#4a2a18', 0.6) } }));
        const bk = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] <= 0), fr = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] > 0);
        let s = shadow(C, 0, 0, W * 0.66, DD * 0.66, 0.45) + bk.map(o => o.s).join('') + caseB + top + fr.map(o => o.s).join('');
        C.p(-24, 0, 0); C.p(24, 0, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffe0b0" stop-opacity="0"/><stop offset="0.5" stop-color="#ffe0b0" stop-opacity="0.22"/><stop offset="1" stop-color="#ffe0b0" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-062 FLOATING FLUTED MARBLE NIGHTSTAND WITH HIDDEN SAFE (T4): a block of honed Calacatta marble floating clear of the floor on a hidden
    // bracket, its front carved into deep vertical flutes, a polished brass inlay line along the top edge, grey and gold veins running across the
    // top and down the sides, a warm LED wash glowing on the floor underneath; one flute is really a door: now and then it swings open a crack to
    // show a brass keypad glowing behind, then closes. Live: the under-glow breathes, a glint runs along the brass and the hidden safe peeks.
    N.flute30 = S => { const D = { w: 48, d: 42, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('flute30'), id = C.u('f62'), W = 40, DD = 30, Y0 = 16, HB = 18, MB = '#f2efe8';
        const fl = (w, h, n) => { const fw = w / n; let o = `<rect width="${w}" height="${h}" fill="${MB}"/>`;
          for (let i = 0; i < n; i++) o += `<rect x="${f1(i * fw + 0.15)}" y="0.6" width="${f1(fw - 0.3)}" height="${f1(h - 1.2)}" rx="${f1(fw * 0.45)}" fill="url(#${id}f)"/>`;
          return o + veins(R, w, h, 4); };
        const n = 12, fw = W / n, sx = 8;
        const front = fl(W, HB, n) + `<rect y="0" width="${W}" height="0.45" fill="#d8b46a"/>`
          + `<g><rect x="${f1(sx * fw + 0.2)}" y="1" width="${f1(fw - 0.4)}" height="${f1(HB - 2)}" fill="#1a140e" opacity="0">${an('opacity', '0;0;0.85;0.85;0', 16, 0, KT('0;0.6;0.66;0.9;1'))}</rect>`
          + `<g opacity="0">${an('opacity', '0;0;1;1;0', 16, 0, KT('0;0.62;0.68;0.88;1'))}<rect x="${f1(sx * fw + 0.6)}" y="${f1(HB / 2 - 3)}" width="${f1(fw - 1.2)}" height="6" rx="0.3" fill="#c8a058"/>${rep(4, j => `<circle cx="${f1(sx * fw + fw / 2)}" cy="${f1(HB / 2 - 2 + j * 1.4)}" r="0.35" fill="#fff0c0"/>`).join('')}</g></g>`;
        const side = fl(DD, HB, 1).replace(/<rect x="0\.15"[^>]*\/>/, '') + veins(R, DD, HB, 3);
        const top = `<rect width="${W}" height="${DD}" fill="${MB}"/>` + veins(R, W, DD, 6) + `<rect y="${f1(DD - 0.6)}" width="${W}" height="0.6" fill="#d8b46a"/><rect x="-6" y="${f1(DD - 0.6)}" width="5" height="0.6" fill="#fffbe0">${an('x', `-6;${W + 6}`, 7)}</rect>`;
        const body = box3(C, decC(C, { c: [0, Y0, 0], w: W, h: HB, d: DD, col: MB, r: 0.4, gl: 0.15, dec: { f: front, t: top, l: side, r: side, b: side } }));
        const glow = PLN(C, 0.06, `<ellipse cx="0" cy="0" rx="${W * 0.62}" ry="${DD * 0.6}" fill="#ffd090" opacity="0.4" filter="url(#m11b4)">${an('opacity', '0.28;0.5;0.28', 7, 0, SPL(2))}</ellipse>`);
        const strip = (() => { const a = C.P([-W / 2 + 2, Y0 - 0.1, DD / 2 - 2]), b = C.P([W / 2 - 2, Y0 - 0.1, DD / 2 - 2]); return `<path d="M${P2(a)}L${P2(b)}" stroke="#ffd8a0" stroke-width="${f1(0.6 * C.k)}" opacity="0.8"/>`; })();
        let s = shadow(C, 0, 0, W * 0.5, DD * 0.5, 0.25) + glow + strip + body;
        C.p(-24, 0, 0); C.p(24, 0, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}f" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#c8c8cc"/><stop offset="0.25" stop-color="#e8e8ea"/><stop offset="0.55" stop-color="#ffffff"/><stop offset="0.85" stop-color="#dcdce0"/><stop offset="1" stop-color="#b4b4ba"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-082 VOICE-ACTIVATED SMART NIGHTSTAND WITH INDUCTIVE CHARGING & TEA BREWER (T5): a softly rounded ivory lacquer cabinet on a champagne-gold
    // plinth, topped with a slab of backlit honey onyx; a glowing champagne charging ring set into the onyx with a phone resting on it; a sunken brew
    // well holding a glass teapot of steeping tea on a warm hotplate; a woven ivory speaker band across the front with a gold voice light bar, and a
    // hidden drawer with a slim gold pull. Live: the tea slowly deepens to amber while steam curls up, the charging ring pulses, and the voice light
    // ripples as if it is speaking.
    N.smart30 = S => { const D = { w: 48, d: 42, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('smart30'), id = C.u('f82'), W = 38, DD = 30, HB = 34, k = C.k, IV = '#f6f1e8', GD = '#d4b06a';
        const plinth = box3(C, decC(C, { c: [0, 0, 0], w: W - 3, h: 3, d: DD - 3, col: GD, r: 1.2, gl: 0.2, dec: { f: `<rect width="${W - 3}" height="0.3" fill="#fff0c8"/>` } }));
        const band = `<rect x="2" y="5" width="${W - 4}" height="5.4" rx="2.7" fill="#e8e0d0"/>` + rep(Math.floor((W - 6) / 0.7), i => `<path d="M${f1(3 + i * 0.7)} 5.4V10" stroke="#d4cab6" stroke-width="0.25"/>`).join('')
          + `<rect x="${f1(W / 2 - 7)}" y="7.4" width="14" height="0.7" rx="0.35" fill="#5a4a30" opacity="0.3"/>` + rep(9, i => `<rect x="${f1(W / 2 - 6.4 + i * 1.5)}" y="7.4" width="1.1" height="0.7" rx="0.35" fill="#ffd890">${an('opacity', '0.2;1;0.3;0.8;0.2', 2.4, -i * 0.12, SPL(4))}</rect>`).join('')
          + `<path d="M3 ${f1(HB - 15)}H${W - 3}" stroke="#d8d0c0" stroke-width="0.3"/><rect x="${f1(W / 2 - 4)}" y="${f1(HB - 14)}" width="8" height="0.6" rx="0.3" fill="${GD}"/>`;
        const body = box3(C, decC(C, { c: [0, 3, 0], w: W, h: HB - 5, d: DD, col: IV, r: 3, gl: 0.3, f: 1.16, dec: { f: band } }));
        // onyx top: honey bands, backlit glow, charging ring + phone, brew well with teapot
        const onyx = `<rect width="${W + 1}" height="${DD + 1}" fill="#e2a868"/>` + rep(14, i => { const y = i * (DD + 1) / 13 + (R() - 0.5) * 2; return `<path d="M0 ${f1(y)}Q${f1(W * 0.3)} ${f1(y + (R() - 0.5) * 4)} ${f1(W * 0.6)} ${f1(y + (R() - 0.5) * 3)}T${W + 1} ${f1(y + (R() - 0.5) * 3)}" stroke="${i % 3 === 0 ? '#fff0d0' : i % 3 === 1 ? '#b8743a' : '#f0c890'}" stroke-width="${f1(0.4 + R() * 2.2)}" fill="none" opacity="${f1(0.45 + R() * 0.35)}" stroke-linecap="round"/>`; }).join('') + `<g filter="url(#m12b1)">` + rep(6, () => `<ellipse cx="${f1(R() * W)}" cy="${f1(R() * DD)}" rx="${f1(3 + R() * 5)}" ry="${f1(1 + R() * 2)}" fill="#fff4dc" opacity="0.3"/>`).join('') + '</g>'
          + `<rect width="${W + 1}" height="${DD + 1}" fill="url(#${id}o)"><animate attributeName="opacity" values="0.7;1;0.7" dur="8s" repeatCount="indefinite"/></rect>`
          + `<circle cx="10" cy="${f1(DD / 2)}" r="6" fill="none" stroke="#fff0c8" stroke-width="0.6">${an('opacity', '0.3;1;0.3', 3, 0, SPL(2))}</circle><circle cx="10" cy="${f1(DD / 2)}" r="6" fill="none" stroke="#ffe0a0" stroke-width="2" opacity="0.35" filter="url(#m12b1)">${an('opacity', '0.15;0.55;0.15', 3, 0, SPL(2))}</circle>`
          + `<g transform="rotate(-12 10 ${f1(DD / 2)})"><rect x="6.4" y="${f1(DD / 2 - 7)}" width="7.2" height="14" rx="1.4" fill="#1e1c1c"/><rect x="6.9" y="${f1(DD / 2 - 6.4)}" width="6.2" height="12.8" rx="1" fill="#2a2830"/><rect x="8" y="${f1(DD / 2 + 3)}" width="4" height="0.5" rx="0.25" fill="#7ad08a"/><rect x="8" y="${f1(DD / 2 + 3)}" width="1" height="0.5" rx="0.25" fill="#c8f0c0">${an('width', '1;4;4', 4, 0, KT('0;0.85;1'))}</rect></g>`
          + `<circle cx="${f1(W - 10)}" cy="${f1(DD / 2)}" r="7.4" fill="#3a2a18"/><circle cx="${f1(W - 10)}" cy="${f1(DD / 2)}" r="7.4" fill="none" stroke="${GD}" stroke-width="0.6"/><circle cx="${f1(W - 10)}" cy="${f1(DD / 2)}" r="6" fill="#c84a20" opacity="0.45" filter="url(#m12b1)">${an('opacity', '0.3;0.6;0.3', 5, 0, SPL(2))}</circle>`;
        const top = box3(C, decC(C, { c: [0, HB - 2, 0], w: W + 1, h: 2, d: DD + 1, col: '#e0a86a', r: 3.2, gl: 0.35, dec: { t: onyx, f: `<rect width="${W + 1}" height="2" fill="#f0d8a8"/><rect y="1.6" width="${W + 1}" height="0.4" fill="${GD}"/>` } }));
        // glass teapot in the well (sits on the hotplate); tea colour deepens
        const TX = W / 2 - 10, TZ = 0.5, TY = HB;
        const pot = cyl3(C, [TX, TY - 0.6, TZ], [TX, TY + 1.4, TZ], 4.6, '#e8eef0', { r2: 5.4, op: 0.45, olw: 0.25 }) + cyl3(C, [TX, TY + 1.4, TZ], [TX, TY + 6.4, TZ], 5.4, '#e8eef0', { r2: 3.6, op: 0.4, olw: 0.25 })
          + `<g>${cyl3(C, [TX, TY - 0.4, TZ], [TX, TY + 3.6, TZ], 4.4, '#d89a48', { r2: 4.9, op: 0.55, olw: 0 })}<animate attributeName="opacity" values="0.4;1;1;0.4" dur="20s" keyTimes="0;0.6;0.9;1" repeatCount="indefinite"/></g>`
          + cyl3(C, [TX, TY + 6.4, TZ], [TX, TY + 7.6, TZ], 2, GD, { mat: 'metal', olw: 0.25 }) + sph(C, [TX, TY + 8.1, TZ], 0.7, GD)
          + line3(C, [[TX + 4.6, TY + 2, TZ], [TX + 7.6, TY + 4.4, TZ], [TX + 8.4, TY + 5.6, TZ]], 0.7, '#e8eef0', 'opacity="0.6"') + (() => { const P = rep(9, i => { const a = PI * (-0.4 + i / 8 * 0.8); return [TX - 5.4 - 1.6 * Math.cos(a), TY + 3.6 + 2.2 * Math.sin(a), TZ]; }); return line3(C, P, 0.55, GD); })();
        const steam = mist(C, TX, TY + 8.6, TZ, 4, 0.35);
        let s = shadow(C, 0, 0, W * 0.6, DD * 0.6, 0.45) + plinth + body + top + vs(C, [{ q: [TX, TY + 3, TZ], s: pot }]) + steam;
        C.p(-24, 0, 0); C.p(24, 0, 0); C.p(0, HB + 18, 0);
        return { defs: DEF19 + `<defs><radialGradient id="${id}o" cx="50%" cy="50%" r="65%"><stop offset="0" stop-color="#fff2d0" stop-opacity="0.7"/><stop offset="0.6" stop-color="#ffd8a0" stop-opacity="0.25"/><stop offset="1" stop-color="#a8622a" stop-opacity="0.2"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-003 PLASTIC FOLDING STOOL (T1): a sun-faded sky-blue plastic folding stool: a rounded top with a carry slot and a grid of anti-slip dimples,
    // two splayed leg panels with big cut-outs and cross braces, grey hinge rivets, scuffed feet; white stress marks at the hinges, a crack bound
    // with clear tape and a half-peeled $3.99 sticker. One leg is a bit short. Live: now and then the stool rocks on its short leg and settles.
    N.fold30 = S => { const SH = 38, D = { w: 40, d: 40, round: 0, act: 'sit', seats: [{ x: 0, z: 0, h: SH }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('fold30'), BL = '#7ab4d8', TW = 30, TD = 26;
        const dimp = (w, d) => `<rect width="${w}" height="${d}" fill="${BL}"/>` + rep(Math.floor(w / 2.2), i => rep(Math.floor(d / 2.2), j => `<circle cx="${f1(1.4 + i * 2.2)}" cy="${f1(1.4 + j * 2.2)}" r="0.45" fill="#5a94b8" opacity="0.6"/>`).join('')).join('')
          + `<rect x="${f1(w / 2 - 5)}" y="${f1(d / 2 - 1.4)}" width="10" height="2.8" rx="1.4" fill="#1e2a34"/><rect x="${f1(w / 2 - 5)}" y="${f1(d / 2 - 1.4)}" width="10" height="0.5" rx="0.25" fill="#3a4a54"/>`
          + `<rect x="3" y="${f1(d - 7)}" width="6" height="3.4" rx="0.3" fill="#f4f0e4" transform="rotate(-6 6 ${f1(d - 5)})"/><text x="6" y="${f1(d - 4.7)}" text-anchor="middle" font-family="Arial" font-weight="bold" font-size="1.5" fill="#c83a2a" transform="rotate(-6 6 ${f1(d - 5)})">$3.99</text><path d="M7.6 ${f1(d - 7.4)}l1.6 0.6l-0.6 1.6Z" fill="#e4dcc8"/>`
          + `<path d="M${f1(w - 6)} 2l1.2 3l-0.8 2.4l1 2" stroke="#f4f8fc" stroke-width="0.3" fill="none"/><rect x="${f1(w - 8)}" y="3.6" width="4.4" height="2.6" fill="#ffffff" opacity="0.25" transform="rotate(30 ${f1(w - 6)} 5)"/>`;
        const panel = (dd, hh) => `<rect width="${dd}" height="${hh}" fill="${BL}"/>` + rep(6, () => `<path d="M${f1(R() * dd)} ${f1(R() * hh)}l${f1(R() * 2)} ${f1((R() - 0.5) * 0.6)}" stroke="#ffffff" stroke-width="0.12" opacity="0.6"/>`).join('') + `<circle cx="2.4" cy="2.4" r="0.7" fill="#9aa4ac" stroke="#5a646c" stroke-width="0.12"/><circle cx="${f1(dd - 2.4)}" cy="2.4" r="0.7" fill="#9aa4ac" stroke="#5a646c" stroke-width="0.12"/><path d="M1.4 1.2q1 1 0.8 2.4M${f1(dd - 1.4)} 1.2q-1 1 -0.8 2.4" stroke="#e8f4fc" stroke-width="0.18" fill="none" opacity="0.8"/>`;
        const leg = sx => box3(C, decC(C, { c: [sx * (TW / 2 - 2), 0, 0], w: 1.6, h: SH - 2.4, d: TD - 2, col: BL, r: 0.3, hole: { l: [2.6, 3.2, 2.6, 5], r: [2.6, 3.2, 2.6, 5] }, dec: { l: panel(TD - 2, SH - 2.4), r: panel(TD - 2, SH - 2.4) } }));
        const brace = sz => box3(C, { c: [0, 4, sz * (TD / 2 - 2.4)], w: TW - 5, h: 1.6, d: 1.4, col: '#6aa4c8', r: 0.3 });
        const feet = [-1, 1].map(sx => [-1, 1].map(sz => box3(C, { c: [sx * (TW / 2 - 2), 0, sz * (TD / 2 - 2.4)], w: 2.4, h: 0.8, d: 3, col: '#5a6a74', r: 0.3 })).join('')).join('');
        const top = box3(C, decC(C, { c: [0, SH - 2.4, 0], w: TW, h: 2.4, d: TD, col: BL, r: 3, gl: 0.15, dec: { t: dimp(TW, TD) } }));
        const lb = C.v[0] > 0 ? [leg(-1), leg(1)] : [leg(1), leg(-1)], bb = C.v[2] > 0 ? [brace(-1), brace(1)] : [brace(1), brace(-1)];
        const body = feet + bb[0] + lb[0] + bb[1] + lb[1] + top, pv = C.P([TW / 2 - 2, 0, TD / 2 - 2.4]);
        let s = shadow(C, 0, 0, TW * 0.6, TD * 0.6, 0.45) + `<g><animateTransform attributeName="transform" type="rotate" values="0 ${P2(pv)};0 ${P2(pv)};-1.4 ${P2(pv)};0.6 ${P2(pv)};-0.6 ${P2(pv)};0 ${P2(pv)};0 ${P2(pv)}" keyTimes="0;0.7;0.74;0.78;0.82;0.86;1" dur="7s" repeatCount="indefinite"/>${body}</g>`;
        C.p(-20, 0, 0); C.p(20, 0, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-023 FAUX-FUR ROUND VANITY STOOL (T2): a plump round stool upholstered in long shaggy blush-ivory faux fur that spills over the edge and hides
    // the base, a soft dip in the middle of the seat, on four short tapered legs in brushed gold tone with felt pads, one of the legs' gold finish
    // worn to silver. Live: the fur ripples in a soft draught and a sheen moves over it.
    N.fur30 = S => { const SH = 36, D = { w: 70, d: 70, round: 1, act: 'sit', seats: [{ x: 0, z: 0, h: SH, k: 'sit' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('fur30'), k = C.k, RR = 17, Y0 = 9, FUR = ['#f6e6dc', '#efd8cc', '#fbf0e8', '#e6cabc', '#ffffff'];
        const legs = [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([sx, sz], i) => { const a = [sx * 9, Y0 + 0.5, sz * 9], b = [sx * 11, 0.6, sz * 11];
          return { q: a, s: cyl3(C, a, b, 1.3, i === 2 ? '#c8c8c4' : '#d4b06a', { mat: 'metal', r2: 0.8, olw: 0.25 }) + cyl3(C, b, [b[0], 0, b[2]], 0.9, '#8a7a6a', { olw: 0.2 }) }; });
        const lb = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] <= 0), lf = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] > 0);
        const core = cyl3(C, [0, Y0, 0], [0, SH - 1.2, 0], RR, '#f2e0d4', { r2: RR - 0.6, ol: 0, capCol: '#f6e8de' });
        // fur: strokes over the top (pointing out from a soft centre dip) and a fringe round the visible side that spills below the base
        let top = '', side = '', hang = '';
        rep(900, () => { const a = R() * 2 * PI, r = Math.sqrt(R()) * (RR + 0.6), p = C.P([r * Math.sin(a), SH - 1.2 + (r / RR) * 0.6, r * Math.cos(a)]), L = (0.8 + R() * 1.2) * k, ex = Math.sin(a) * L, ey = Math.cos(a) * L * 0.5 + 0.3 * k;
          top += `<path d="M${P2(p)}q${f1(ex * 0.4)} ${f1(ey * 0.2 - 0.4 * k)} ${f1(ex)} ${f1(ey)}" stroke="${FUR[(R() * 5) | 0]}" stroke-width="${f1((0.35 + R() * 0.35) * k)}" fill="none" stroke-linecap="round"/>`; });
        rep(900, () => { const a = C.thV + (R() - 0.5) * PI * 1.15, y = Y0 + R() * (SH - Y0), p = C.P([(RR + 0.3) * Math.sin(a), y, (RR + 0.3) * Math.cos(a)]), L = (0.7 + R() * 1.1) * k, ang = (R() - 0.5) * 2.4;
          side += `<path d="M${P2(p)}q${f1(Math.sin(ang) * L * 0.6)} ${f1(Math.cos(ang) * L * 0.3)} ${f1(Math.sin(ang) * L)} ${f1(Math.abs(Math.cos(ang)) * L)}" stroke="${FUR[(R() * 5) | 0]}" stroke-width="${f1((0.4 + R() * 0.4) * k)}" fill="none" stroke-linecap="round"/>`; });
        rep(160, () => { const a = C.thV + (R() - 0.5) * PI * 1.1, p = C.P([(RR + 0.3) * Math.sin(a), Y0 + 1, (RR + 0.3) * Math.cos(a)]), L = (1.2 + R() * 1.8) * k;
          hang += `<path d="M${P2(p)}q${f1((R() - 0.5) * 1.4 * k)} ${f1(L * 0.6)} ${f1((R() - 0.5) * 1.8 * k)} ${f1(L)}" stroke="${FUR[(R() * 4) | 0]}" stroke-width="${f1((0.4 + R() * 0.3) * k)}" fill="none" stroke-linecap="round"/>`; });
        const tc = C.P([0, SH - 1.2, 0]), dip = `<ellipse cx="${f1(tc[0])}" cy="${f1(tc[1])}" rx="${f1(7 * k)}" ry="${f1(3.6 * k)}" fill="#c8a898" opacity="0.25" filter="url(#m12b1)"/>`;
        const rim = (() => { const P = rep(41, i => { const a = C.thV - PI / 2 - 0.2 + i / 40 * (PI + 0.4); return C.P([(RR + 0.6) * Math.sin(a), SH - 1.6, (RR + 0.6) * Math.cos(a)]); }); return `<path d="M${P.map(P2).join('L')}" stroke="#f8ece4" stroke-width="${f1(2.4 * k)}" fill="none" stroke-linecap="round" opacity="0.9"/>`; })();
        const wave = g => `<g>${at('skewX', '0;1.4;0;-1;0', 5.5, 0, SPL(4))}${g}</g>`;
        const sheen = (() => { const c = C.P([0, SH, 0]); return `<ellipse cx="${f1(c[0])}" cy="${f1(c[1])}" rx="${f1(8 * k)}" ry="${f1(3 * k)}" fill="#ffffff" opacity="0.2" filter="url(#m12b1)">${at('translate', `${f1(-10 * k)} 0;${f1(10 * k)} 0;${f1(-10 * k)} 0`, 9, 0, SPL(2))}</ellipse>`; })();
        let s = shadow(C, 0, 0, RR + 4, RR + 4, 0.5) + lb.map(o => o.s).join('') + lf.map(o => o.s).join('') + core + wave(hang) + side + top + dip + sheen;
        C.p(-24, 0, 0); C.p(24, 0, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // ---- chairs with backs: real solids (X.K) so the seat split (srcB / srcF) works for a sitter; fx adds sheen / details ----
    const SK = () => { const K = X.K; return { box: K.box, cyl: K.cyl, ball: K.ball, solid: K.solid, pillowY: K.pillowY, pillowZ: K.pillowZ }; };
    const gl30 = o => (p, L) => L.map(k => { k.par = p; o.push(k); return k; });
    const sheenG = (id, T, op) => `<linearGradient id="${id}" x1="0" y1="0" x2="1" y2="0.4"><stop offset="0.25" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.45" stop-color="#ffffff" stop-opacity="${op || 0.22}"/><stop offset="0.52" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-0.5 0;0.5 0;-0.5 0" dur="${T}s" repeatCount="indefinite" calcMode="spline" keyTimes="0;0.5;1" keySplines="0.45 0 0.55 1;0.45 0 0.55 1"/></linearGradient>`;
    const inF = (S, cx, cz) => { const cap = [], inn = [], out = []; S.faces.forEach(F => { if (F.cap) { cap.push(F); return; } const q = F.q, mx = q.reduce((s, p) => s + p[0], 0) / q.length, mz = q.reduce((s, p) => s + p[2], 0) / q.length, L = Math.hypot(mx - cx, mz - cz) || 1;
      ((F.n[0] * (mx - cx) + F.n[2] * (mz - cz)) / L < -0.3 ? inn : out).push(F); }); S.faces = inn.concat(out, cap); return S; };
    const sectorP = (A, B, th, a0, a1, n) => { const o = [], i = []; for (let k = 0; k <= n; k++) { const t = a0 + (a1 - a0) * k / n; o.push([A * Math.cos(t), B * Math.sin(t)]); i.push([(A - th) * Math.cos(t), (B - th) * Math.sin(t)]); } return o.concat(i.reverse()); };

    // BED-043 VELVET SCALLOPED-BACK SHELL CHAIR ON GOLD CASTERS (T3): a round blush-rose velvet seat in a curved shell back of seven stitched channels,
    // each rising to a rounded scallop (tallest in the middle), on a slim polished-gold frame ring with four short tapered legs on gold ball casters.
    // Seat {0, 12, 38} kept. Live: the velvet sheen drifts across the channels and seat.
    N.shell30 = S => { const GD = '#d4b06a', VV = '#d89a9c', ZC = 2;
      const D = { w: 94, d: 88, act: 'sit', seats: [{ x: 0, z: 12, h: 38 }], build: () => { const { cyl, ball, solid } = SK(), o = [], VT = { mat: 'fab', soft: 1, tex: 'url(#b30v43) none', texO: 1 };
          [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => { const x = sx * 16, z = ZC + sz * 15; o.push(cyl(x, 3.6, z, 1.6, 26, GD, { n: 10, mat: 'metal', rg: [[0, 0, 0.6], [26, 0, 1]] }), ball(x, 0, z, 2.2, GD, { k: 4, n: 10, mat: 'metal' })); });
          o.push(cyl(0, 29, ZC, 24, 2.2, GD, { rz: 22, n: 24, mat: 'metal' }));
          o.push(solid(Object.assign({ ax: 'y', sh: 'el', c: [0, ZC + 2], a: 25, b: 23, n: 24, rings: [[31, 3, 0.95], [33, 0, 1], [36.6, 0, 1], [38.4, 4, 0.94]], col: VV }, VT)));
          const NC = 7; for (let i = 0; i < NC; i++) { const t = -1 + 2 * i / (NC - 1), ang = t * 1.5, x = 21.6 * Math.sin(ang), z = ZC - 21.6 * Math.cos(ang) + 2, top = 68 - Math.abs(t) * 9;
            o.push(solid(Object.assign({ ax: 'y', sh: 'el', c: [x, z], a: 6.7, b: 3.6, n: 14, yaw: -ang, rings: [[33, 0, 0.92], [36, 0, 1], [top - 6, 0, 1], [top - 2.4, 0, 0.9], [top, 0, 0.62]], col: VV }, VT))); }
          return o; } };
      D.fx = ctx => { const C = cam(ctx); const st = C.v[2] > 0 ? (() => { let s = ''; for (let i = 0; i < 6; i++) { const t = -1 + 2 * (i + 0.5) / 6, ang = t * 1.55, x = 23.4 * Math.sin(ang), z = ZC - 23.4 * Math.cos(ang) + 2, top = 66 - Math.abs(t) * 14; const a = C.P([x, 37, z]), b = C.P([x, top, z]); s += `<path d="M${P2(a)}L${P2(b)}" stroke="#a86a6e" stroke-width="${f1(0.35 * C.k)}" opacity="0.6"/>`; } return s; })() : '';
        return { defs: sheenG('b30v43', 9, 0.26), front: '', back: '' }; };
      return D; };

    // BED-063 ERGONOMIC ITALIAN LEATHER & WALNUT LOUNGE CHAIR (T4): moulded walnut plywood shells (seat, lower and upper back) cradling plump cognac
    // aniline leather cushions with deep button tufts and piped edges, padded leather armrests on walnut arms, on a polished aluminium five-star
    // swivel base. Seat {0, 12, 38} kept. Live: a warm sheen glides over the leather and the aluminium base glints.
    N.lounge30 = S => { const WN = '#5e3a22', LT = '#9a5428', AL = '#c8ccd0';
      const D = { w: 94, d: 88, act: 'sit', seats: [{ x: 0, z: 12, h: 38 }], build: () => { const { box, cyl, ball, solid, pillowY, pillowZ } = SK(), o = [], on = gl30(o), LV = { mat: 'fab', soft: 1, tex: 'url(#b30l63) none', texO: 1 };
          rep(5, i => { const a = i / 5 * 2 * PI + 0.3; o.push(solid({ ax: 'y', sh: 'rr', c: [Math.sin(a) * 11, Math.cos(a) * 11], a: 11, b: 1.6, r: 1.2, yaw: -a + PI / 2, rings: [[0.6, 0, 0.9], [2.4, 0, 1], [3.6, 0.6, 0.95]], col: AL, mat: 'metal' }), ball(Math.sin(a) * 21, 0, Math.cos(a) * 21, 1.2, '#2a2a2a', { k: 3, n: 8 })); });
          o.push(cyl(0, 3.6, 0, 2.6, 24, AL, { n: 12, mat: 'metal' }));
          o.push(solid({ ax: 'y', sh: 'rr', c: [0, 2], a: 24, b: 22, r: 9, rings: [[27.6, 0, 0.96], [30, 0, 1], [31.4, 0, 1]], col: WN, mat: 'wood' }));
          const SE = solid(Object.assign({ ax: 'y', sh: 'rr', c: [0, 3], a: 22, b: 20, r: 9, rings: [[31.4, 1, 0.97], [33, 0, 1], [37, 0, 1], [38.6, 4, 0.92]], col: LT }, LV)); o.push(SE);
          o.push(solid({ ax: 'z', sh: 'rr', c: [0, 48], a: 23, b: 14, r: 7, rings: [[-22, 0, 1], [-19.6, 0, 1]], col: WN, mat: 'wood' }), solid({ ax: 'z', sh: 'rr', c: [0, 71], a: 22, b: 10, r: 7, rings: [[-25, 0, 1], [-22.6, 0, 1]], col: WN, mat: 'wood' }));
          o.push(pillowZ(0, 36, -16.4, 40, 24, 6.4, LT, LV), pillowZ(0, 62, -19.6, 38, 18, 6, LT, LV));
          [-1, 1].forEach(sx => { o.push(box(sx * 25, 31.4, -2, 3, 13, 4, WN, { r: 1.4, mat: 'wood' }), box(sx * 25.2, 44, -5, 6.2, 3, 24, WN, { r: 2.6, mat: 'wood' }));
            o.push(solid(Object.assign({ ax: 'y', sh: 'rr', c: [sx * 25.2, -5], a: 3, b: 11.4, r: 2.6, rings: [[47, 1, 0.95], [48, 0, 1], [50, 0, 1], [51, 1.6, 0.9]], col: LT }, LV))); });
          return o; } };
      D.fx = ctx => { const C = cam(ctx), k = C.k; let s = '';
        // buttons on the visible cushions
        const btn = q => { const p = C.P(q); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.75 * k)}" fill="#5a2c12"/><circle cx="${f1(p[0] - 0.2 * k)}" cy="${f1(p[1] - 0.2 * k)}" r="${f1(0.3 * k)}" fill="#c87a48" opacity="0.7"/>`; };
        if (C.v[2] > 0.1) { [[-9, 48], [0, 48], [9, 48], [-6, 71], [6, 71]].forEach(([x, y], i) => s += btn([x, y, i < 3 ? -13.1 : -16.5])); }
        if (C.v[1] > 0.2) [[-8, 6], [8, 6], [0, -4]].forEach(([x, z]) => s += btn([x, 38.7, z]));
        return { defs: sheenG('b30l63', 11, 0.3), front: s }; };
      return D; };

    // BED-083 ZERO-GRAVITY FLOATING MEDITATION & READING POD CHAIR (T5): an egg-shaped pod in ivory lacquer with a champagne-gold rim, open to the
    // front and lined with quilted pearl silk, hovering over a black-glass base disc that glows warm underneath; a slim gold reading arm arcs over
    // from the shell to a small warm lamp; a halo of soft motes drifts in the gap. Seat {0, 12, 52} kept. Live: the pod lining's sheen drifts, the
    // levitation glow breathes, the reading lamp glows and the motes rise through the gap.
    N.pod30 = S => { const IV = '#f4efe6', GD = '#d4b06a', PL = '#e8cfc4', YB = 34, YT = 104;
      const prof = y => { const t = (y - YB) / (YT - YB); return Math.max(0.12, Math.sin(Math.PI * Math.min(1, t * 0.95 + 0.03)) * (1 - 0.18 * t)); };
      const D = { w: 94, d: 88, pad: [0, 8, 0, 0], act: 'sit', seats: [{ x: 0, z: 12, h: 52 }], build: () => { const { cyl, solid } = SK(), o = [], a0 = 0.94 * PI, a1 = 2.06 * PI;
          o.push(cyl(0, 0, 0, 26.6, 1.2, GD, { n: 28, mat: 'metal' }), cyl(0, 1.2, 0, 26, 1.8, '#1e1c26', { n: 28, mat: 'gloss' }));
          const RY = []; for (let y = YB; y <= YT + 0.01; y += 5) RY.push([y, 0, prof(y)]);
          o.push(inF(solid({ ax: 'y', sh: 'poly', pts: sectorP(30, 28, 2.6, a0, a1, 20), cv: 0, c: [0, 0], rings: RY, col: IV, mat: 'gloss', tex: 'url(#b30p83) none', texO: 0.8 }), 0, 0));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('pod30'), k = C.k; let under = '', s = '';
        under += `<g transform="${FR(C, [0, 0.05, 0], [1, 0, 0], [0, 0, 1])}"><ellipse rx="34" ry="34" fill="#ffc880" opacity="0.3" filter="url(#m11b4)">${an('opacity', '0.2;0.42;0.2', 6, 0, SPL(2))}</ellipse></g>`;
        // levitation glow + motes in the gap between base and pod
        const g0 = C.P([0, 3, 0]), g1 = C.P([0, YB, 0]);
        s += `<ellipse cx="${f1(g0[0])}" cy="${f1((g0[1] + g1[1]) / 2)}" rx="${f1(16 * k)}" ry="${f1(Math.abs(g1[1] - g0[1]) / 2)}" fill="#ffe0b0" opacity="0.18" filter="url(#m11b4)">${an('opacity', '0.1;0.28;0.1', 6, 0, SPL(2))}</ellipse>`
          + rep(10, () => { const a = R() * 2 * PI, r = R() * 14, p = C.P([r * Math.sin(a), 4, r * Math.cos(a)]), T = 4 + R() * 3; return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.4 * k)}" fill="#fff0c8" opacity="0">${an('opacity', '0;0.9;0', n4(T), n4(-R() * T), SPL(2))}${at('translate', `0 0;0 ${f1(-(YB - 6) * k * 0.8)}`, n4(T), n4(-R() * T))}</circle>`; }).join('');
        // gold rim line along the shell's front edges
        const rimE = sg => { const a = sg > 0 ? 2.06 * PI : 0.94 * PI, P = rep(15, i => { const y = YB + (YT - YB) * i / 14, r = prof(y); return C.P([30 * r * Math.cos(a), y, 28 * r * Math.sin(a)]); }); return `<path d="M${P.map(P2).join('L')}" stroke="${GD}" stroke-width="${f1(1 * k)}" fill="none" stroke-linecap="round"/>`; };
        // reading arm + lamp
        const A = [[18, 92, -10], [20, 104, 0], [14, 104, 14], [8, 98, 20]], lamp = C.P([8, 96.6, 20]);
        const arm = '<path d="M' + A.map(q => P2(C.P(q))).join('L') + `" stroke="${GD}" stroke-width="${f1(0.8 * k)}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>` + H.cyl3(C, [8, 98.6, 20], [8, 96, 20], 1.6, GD, { r2: 2.6, mat: 'metal', olw: 0.3 })
          + `<circle cx="${f1(lamp[0])}" cy="${f1(lamp[1])}" r="${f1(7 * k)}" fill="#ffd890" opacity="0.35" filter="url(#m11b4)">${an('opacity', '0.25;0.45;0.25', 5, 0, SPL(2))}</circle><ellipse cx="${f1(lamp[0])}" cy="${f1(lamp[1])}" rx="${f1(2 * k)}" ry="${f1(0.8 * k)}" fill="#fff4d8"/>`;
        // quilted pearl-silk seat cushion inside the hood: in front of the shell only while the opening faces you
        const qid = C.u('pq'), seat = H.cyl3(C, [0, 45, 4], [0, 52.4, 4], 20, PL, { r2: 19, mat: 'matte', olw: 0.35, cap: rr => `<clipPath id="${qid}"><circle r="${f1(rr)}"/></clipPath><circle r="${f1(rr)}" fill="${PL}"/><g clip-path="url(#${qid})">` + rep(9, i => `<path d="M${f1(-rr + i * rr / 4)} ${f1(-rr)}l${f1(rr * 2)} ${f1(rr * 2)}M${f1(-rr + i * rr / 4)} ${f1(rr)}l${f1(rr * 2)} ${f1(-rr * 2)}" stroke="#c8a8a0" stroke-width="0.35" opacity="0.6"/>`).join('') + rep(16, i => `<circle cx="${f1(-rr + (i % 4 + 0.5) * rr / 2)}" cy="${f1(-rr + ((i / 4) | 0) * rr / 2 + rr / 4)}" r="0.5" fill="#b8908a"/>`).join('') + `</g><circle r="${f1(rr * 0.98)}" fill="url(#b30p83)"/>` })
          + H.cyl3(C, [0, 52.4, -16], [0, 62, -18], 9, PL, { r2: 7.5, mat: 'matte', olw: 0.3 });
        const fr = C.v[2] > 0.3;
        return { defs: sheenG('b30p83', 10, 0.3), under, back: fr ? '' : seat, front: (fr ? seat : '') + s + rimE(1) + rimE(-1) + arm }; };
      return D; };

    // ---- reading lights (small round table/floor lamps keep small/round/glow; 046 stays a wall piece) ----
    const bez3 = (a, b, c, d, n) => rep(n + 1, i => { const t = i / n, u = 1 - t; return [0, 1, 2].map(j => u * u * u * a[j] + 3 * u * u * t * b[j] + 3 * u * t * t * c[j] + t * t * t * d[j]); });
    const moth = (C, q, rx, rz, T) => { const c = C.P(q), k = C.k; return `<g><animateMotion path="M${f1(c[0] - rx * k)} ${f1(c[1])}a${f1(rx * k)} ${f1(rz * k)} 0 1 0 ${f1(2 * rx * k)} 0a${f1(rx * k)} ${f1(rz * k)} 0 1 0 ${f1(-2 * rx * k)} 0" dur="${T}s" repeatCount="indefinite"/><g transform="scale(${n4(k * 0.8)})"><path d="M0 0L-1.4 -0.9L-1.2 0.4ZM0 0L1.4 -0.9L1.2 0.4Z" fill="#e8dcc4"><animateTransform attributeName="transform" type="scale" values="1 1;1 0.3;1 1" dur="0.16s" repeatCount="indefinite"/></path><ellipse rx="0.3" ry="0.6" fill="#8a7a5a"/></g></g>`; };

    // BED-006 CLIP-ON PLASTIC DESK LAMP (T1): a cheap clip lamp clamped onto a stack of three old paperbacks for a base: black spring-clamp jaws with a
    // rusty spring, a crinkled chrome gooseneck, a yellowed white plastic dome shade with a heat-browned vent ring and a bare bulb glowing under it;
    // a thin white cord with an inline roller switch trails off the books. Live: the bulb flickers now and then and a moth circles the light.
    N.clip30 = S => { const D = { w: 34, d: 34, small: 1, round: 1, glow: () => ({ y: 40, r: 46 }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('clip30'), k = C.k;
        const BK = [['#8a3a2a', 15, 2.4], ['#2a4a6a', 14, 2.2], ['#c8a040', 15.6, 2.6]];
        let y = 0, books = '';
        BK.forEach(([c, w, h], i) => { books += box3(C, decC(C, { c: [0.4 * (i - 1), y, 0], w, h, d: w * 0.68, col: c, r: 0.3, dec: { f: `<rect width="${w}" height="${h}" fill="${c}"/><rect x="0.4" y="${f1(h * 0.3)}" width="${f1(w - 0.8)}" height="${f1(h * 0.18)}" fill="#f4e8c8" opacity="0.5"/>`, r: `<rect width="${f1(w * 0.68)}" height="${h}" fill="#f2ead6"/>` + rep(5, j => `<path d="M0 ${f1(h * (j + 1) / 6)}H${f1(w * 0.68)}" stroke="#c8bc9c" stroke-width="0.06"/>`).join(''), l: `<rect width="${f1(w * 0.68)}" height="${h}" fill="#f2ead6"/>` } })); y += h; });
        // spring clamp on the top book's back edge
        const CY = y, CZ = -3.4;
        let clamp = box3(C, { c: [0, CY - 1.4, CZ], w: 3, h: 1.2, d: 6, col: '#1e1e1e', r: 0.4 }) + box3(C, { c: [0, CY, CZ], w: 3, h: 1.2, d: 6, col: '#2a2a2a', r: 0.4 })
          + cyl3(C, [-1.6, CY + 1.6, CZ - 2.4], [1.6, CY + 1.6, CZ - 2.4], 0.9, '#8a5a3a', { mat: 'metal', olw: 0.25 }) + box3(C, { c: [0, CY + 1.2, CZ - 4.4], w: 2.6, h: 4.4, d: 1.4, col: '#2a2a2a', r: 0.4 });
        // gooseneck
        const G = bez3([0, CY + 1.4, CZ], [0, CY + 18, CZ - 2], [2, CY + 30, CZ + 8], [3, CY + 26, CZ + 16], 18);
        let neck = ''; for (let i = 0; i < G.length - 1; i++) neck += cyl3(C, G[i], G[i + 1], 0.75, '#b8bcc0', { mat: 'chrome', olw: 0.2, noCap: i > 0 && i < G.length - 2 ? 1 : 0 });
        neck += `<path d="M${G.map(p => P2(C.P(p))).join('L')}" stroke="#ffffff" stroke-width="${f1(0.18 * k)}" stroke-dasharray="${f1(0.25 * k)} ${f1(0.25 * k)}" fill="none" opacity="0.7"/>`;
        // dome shade (opening down) + bulb
        const SC = [3, CY + 22, CZ + 16];
        const shade = cyl3(C, [SC[0], SC[1] + 6, SC[2]], [SC[0], SC[1], SC[2]], 2.2, '#f0ead0', { r2: 7.4, olw: 0.35, capCol: '#fff4d8', cap: rr => `<circle r="${f1(rr)}" fill="#fff6dc"/><circle r="${f1(rr * 0.4)}" fill="#ffffff"/>` })
          + (() => { const P = rep(13, i => { const a = C.thV - PI / 2 + i / 12 * PI; return C.P([SC[0] + 3 * Math.sin(a), SC[1] + 5, SC[2] + 3 * Math.cos(a)]); }); return `<path d="M${P.map(P2).join('L')}" stroke="#8a6a3a" stroke-width="${f1(0.4 * k)}" stroke-dasharray="${f1(0.5 * k)} ${f1(0.4 * k)}" fill="none" opacity="0.7"/>`; })();
        const bc = C.P([SC[0], SC[1] - 1.4, SC[2]]);
        const FL = an('opacity', '1;0.75;1;0.5;1;1', 6.7, 0, KT('0;0.3;0.42;0.46;0.52;1'));
        const bulb = `<g>${FL}<circle cx="${f1(bc[0])}" cy="${f1(bc[1])}" r="${f1(9 * k)}" fill="#ffe8b0" opacity="0.35" filter="url(#m11b4)"/><circle cx="${f1(bc[0])}" cy="${f1(bc[1])}" r="${f1(2.2 * k)}" fill="#fff8e0"/></g>`;
        const cd0 = cord(C, [[0, 0.3, -7], [-5, 0.3, -10], [-12, 0.3, -9]]);
        const sw = box3(C, { c: [-9, 0, -9.6], w: 3, h: 1.2, d: 1.6, col: '#f2f0ea', r: 0.4 });
        const facing = C.v[1] > 0.5;
        let s = shadow(C, 0, 0, 10, 7, 0.45) + cd0 + sw + books + clamp + neck + (facing ? shade + bulb : bulb + shade) + moth(C, [SC[0], SC[1] - 3, SC[2]], 6, 3, 4.6);
        C.p(-17, 0, 0); C.p(17, 0, 0); C.p(0, SC[1] + 9, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-026 CERAMIC BASE TABLE LAMP WITH PLEATED SHADE (T2): a plump gourd-shaped ceramic base in sage-green crackle glaze with a cream foot ring, a
    // brass neck and harp with a little acorn finial, and a box-pleated cream linen drum shade glowing warm from inside (pleats lit, seam darker),
    // a linen cord. Live: the shade's glow breathes softly and the pool of light under it warms and cools.
    N.cer30 = S => { const D = { w: 34, d: 34, small: 1, round: 1, glow: () => ({ y: 46, r: 50 }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('cer30'), k = C.k, SG = '#9ab090';
        const glaze = rr => '';
        let base = cyl3(C, [0, 0, 0], [0, 1.6, 0], 5.4, '#ece4d0', { olw: 0.3 });
        const prof = [[1.6, 5.2], [2.8, 6.6], [4.4, 7.9], [6.4, 8.9], [8.6, 9.4], [11, 9.2], [13.4, 8.4], [15.6, 7], [17.6, 5.4], [19.4, 3.9], [21.2, 2.9], [23, 2.4]];
        for (let i = 0; i < prof.length - 1; i++) base += cyl3(C, [0, prof[i][0], 0], [0, prof[i + 1][0], 0], prof[i][1], SG, Object.assign({ r2: prof[i + 1][1], mat: 'gloss', n: 32, noCap: i < prof.length - 2 ? 1 : 0 }, i ? { ol: 0 } : { olw: 0.35 }));
        // crackle glaze lines on the visible half
        base += rep(26, () => { const a = C.thV + (R() - 0.5) * PI * 0.9, y0 = 3 + R() * 17, r = (() => { for (let i = 1; i < prof.length; i++) if (y0 <= prof[i][0]) { const [ya, ra] = prof[i - 1], [yb, rb] = prof[i]; return ra + (rb - ra) * (y0 - ya) / (yb - ya); } return 3; })(), p = C.P([(r + 0.05) * Math.sin(a), y0, (r + 0.05) * Math.cos(a)]); return `<path d="M${P2(p)}l${f1((R() - 0.5) * 1.6 * k)} ${f1((R() - 0.5) * 1.6 * k)}l${f1((R() - 0.5) * 1.2 * k)} ${f1((R() - 0.5) * 1.2 * k)}" stroke="#6a8064" stroke-width="${f1(0.1 * k)}" fill="none" opacity="0.6"/>`; }).join('');
        base += cyl3(C, [0, 23, 0], [0, 25, 0], 1.6, '#c8a058', { mat: 'metal', olw: 0.25 }) + cyl3(C, [0, 25, 0], [0, 33, 0], 0.4, '#c8a058', { mat: 'metal', olw: 0.2 });
        // pleated drum shade (glowing)
        const SY0 = 30, SY1 = 46, R0 = 11.5, R1 = 8.4, NP = 36;
        const harp = [-1, 1].map(sg => `<path d="M${P2(C.P([0, 33, 0]))}L${P2(C.P([sg * 7, 44, 0]))}" stroke="#c8a058" stroke-width="${f1(0.3 * k)}"/>`).join('');
        const back = cyl3(C, [0, SY0, 0], [0, SY1, 0], R0, '#f6e6c4', { r2: R1, olw: 0, capCol: '#fff2d8', noCap: 1, f: 1.2 });
        let pleat = ''; for (let i = 0; i < NP; i++) { const a = i / NP * 2 * PI; if (Math.cos(a - C.thV) < 0.02) continue; const a1 = C.P([R0 * Math.sin(a), SY0, R0 * Math.cos(a)]), b1 = C.P([R1 * Math.sin(a), SY1, R1 * Math.cos(a)]); pleat += `<path d="M${P2(a1)}L${P2(b1)}" stroke="${i % 2 ? '#e0c49a' : '#fffaf0'}" stroke-width="${f1((i % 2 ? 0.35 : 0.5) * k)}" opacity="0.8"/>`; }
        const rimB = (y, r) => { const P = rep(25, i => { const a = C.thV - PI / 2 + i / 24 * PI; return C.P([r * Math.sin(a), y, r * Math.cos(a)]); }); return `<path d="M${P.map(P2).join('L')}" stroke="#d8c09a" stroke-width="${f1(0.7 * k)}" fill="none"/>`; };
        const topOpen = (() => { const P = rep(33, i => { const a = i / 32 * 2 * PI; return C.P([R1 * Math.sin(a), SY1, R1 * Math.cos(a)]); }); return `<path d="M${P.map(P2).join('L')}Z" fill="#fff4dc"/><path d="M${P.map(P2).join('L')}Z" fill="#ffe8b8" opacity="0.6"/>`; })();
        const glowS = `<g>${an('opacity', '0.85;1;0.85', 7, 0, SPL(2))}${back}${pleat}</g>`;
        const fin = H.sph(C, [0, 46.8, 0], 0.8, '#c8a058');
        const pool = PLN(C, 0.06, `<ellipse rx="16" ry="16" fill="#ffd890" opacity="0.3" filter="url(#m11b4)">${an('opacity', '0.2;0.38;0.2', 7, 0, SPL(2))}</ellipse>`);
        const cd0 = cord(C, [[0, 0.3, -5], [-4, 0.3, -12], [-14, 0.3, -11]], '#e8dcc0');
        const top = C.v[1] > 0;
        let s = pool + shadow(C, 0, 0, 7, 7, 0.4) + cd0 + base + harp + (top ? glowS + topOpen : topOpen + glowS) + rimB(SY0, R0) + rimB(SY1, R1) + fin;
        C.p(-17, 0, 0); C.p(17, 0, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-046 ARTICULATED BRASS SWING-ARM WALL SCONCE (T3): a round brushed-brass backplate with a rocker switch, a two-section swing arm with knurled
    // knuckles and a tension knob, a linen-covered cord clipped along the arm, and a brass cone shade lined in white enamel, angled down to throw a
    // warm reading cone. Live: dust motes drift through the beam and a glint slides along the brass.
    N.swing30 = S => { const D = { w: 40, d: 12, mount: 'wall', elev: 62, glow: () => ({ y: 22, r: 50 }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('swing30'), k = C.k, BR = '#c9a256', { WD } = RD.H12, { ext } = RD.H11;
        const plate = cyl3(C, [-14, 22, 0], [-14, 22, 1.4], 4.4, BR, { mat: 'metal', olw: 0.35, cap: rr => `<circle r="${f1(rr * 0.92)}" fill="none" stroke="#f4dca0" stroke-width="0.3"/><rect x="-0.8" y="-2.6" width="1.6" height="2.4" rx="0.4" fill="#2a2420"/>` + rep(30, i => `<path d="M${f1(-rr)} ${f1(-rr + i * rr / 15)}H${f1(rr)}" stroke="#a8823e" stroke-width="0.08" opacity="0.5"/>`).join('') });
        const P0 = [-14, 22, 1.4], K1 = [-14, 22, 4], K2 = [0, 25, 8], K3 = [12, 22, 12];
        let arm = cyl3(C, P0, K1, 0.9, BR, { mat: 'metal', olw: 0.25 }) + H.sph(C, K1, 1.4, BR) + cyl3(C, K1, K2, 0.75, BR, { mat: 'metal', olw: 0.25 }) + H.sph(C, K2, 1.5, BR)
          + cyl3(C, [K2[0], K2[1] + 1.6, K2[2]], [K2[0], K2[1] + 2.6, K2[2]], 1.2, '#a8823e', { mat: 'metal', olw: 0.2 }) + cyl3(C, K2, K3, 0.75, BR, { mat: 'metal', olw: 0.25 }) + H.sph(C, K3, 1.3, BR);
        // cord along the arm with clips
        const cd = bez3([-14, 20, 1.8], [-8, 18, 5], [2, 23, 9], [12, 20.6, 12], 12);
        arm = `<path d="M${cd.map(p => P2(C.P(p))).join('L')}" stroke="#e8dcc4" stroke-width="${f1(0.5 * k)}" fill="none"/>` + arm;
        // cone shade angled down-forward
        const SA = [12, 21, 12], SB = [15, 12, 16];
        const shade = cyl3(C, SA, SB, 2.4, BR, { r2: 6, mat: 'metal', olw: 0.35, capCol: '#fff8ea', cap: rr => `<circle r="${f1(rr)}" fill="#fffaf0"/><circle r="${f1(rr * 0.4)}" fill="#ffffff"/><circle r="${f1(rr * 0.92)}" fill="none" stroke="#c9a256" stroke-width="0.4"/>` });
        // light cone + motes
        const L0 = C.P(SB), ring = rep(16, i => { const a = i / 16 * 2 * PI; return C.P([17 + Math.cos(a) * 9, -14, 22 + Math.sin(a) * 9]); }), bp = H.pth(H.hull([L0].concat(ring))), E2 = C.P([17, -14, 22]), gid = C.u('sc');
        const beam = `<defs><linearGradient id="${gid}" gradientUnits="userSpaceOnUse" x1="${f1(L0[0])}" y1="${f1(L0[1])}" x2="${f1(E2[0])}" y2="${f1(E2[1])}"><stop offset="0" stop-color="#fff0c8" stop-opacity="0.5"/><stop offset="1" stop-color="#ffe0a8" stop-opacity="0"/></linearGradient></defs><path d="${bp}" fill="url(#${gid})"/>`
          + rep(10, () => { const t = 0.15 + R() * 0.75, p = C.P([15 + 2 * t + (R() - 0.5) * 8 * t, 12 - 26 * t, 16 + 6 * t + (R() - 0.5) * 8 * t]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.25 * k)}" fill="#fff8e0" opacity="0">${an('opacity', '0;0.9;0', n4(2.5 + R() * 3), n4(-R() * 4), SPL(2))}</circle>`; }).join('');
        const glint = (() => { const a = C.P(K1), b = C.P(K2); return `<path d="M${P2(a)}L${P2(b)}" stroke="#fffbe8" stroke-width="${f1(0.4 * k)}" stroke-dasharray="${f1(1.6 * k)} ${f1(60 * k)}" stroke-linecap="round"><animate attributeName="stroke-dashoffset" values="${f1(62 * k)};0" dur="6s" repeatCount="indefinite"/></path>`; })();
        const wash = WD(C, -24, 30, 0.04, `<ellipse cx="10" cy="10" rx="9" ry="9" fill="#2a2018" opacity="0.25" filter="url(#m10b1)"/>`);
        let s = wash + plate + arm + glint + shade + beam;
        ext(C, [[-20, 32, 0], [20, -14, 0], [20, -14, 22]]);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-066 ALABASTER SPHERE TOUCH-DIMMING DAWN-SIMULATOR LAMP (T4): a hand-turned globe of translucent alabaster with honey and cream veins and a few
    // darker mineral threads, glowing from within, seated in a hammered brass cup on a slim walnut plinth with a brass touch ring. Live: a slow dawn
    // runs through the stone, deep amber warming to soft white and back, the veins glow brighter as it brightens and the touch ring pulses.
    N.alab30 = S => { const D = { w: 34, d: 34, small: 1, round: 1, glow: () => ({ y: 26, r: 48 }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('alab30'), id = C.u('a66'), k = C.k, SR = 11, SY = 18;
        const plinth = cyl3(C, [0, 0, 0], [0, 2.6, 0], 7.4, '#5e3a22', { olw: 0.35 }) + cyl3(C, [0, 2.6, 0], [0, 3.2, 0], 7.2, '#d4b06a', { mat: 'metal', olw: 0.25, cap: rr => `<circle r="${f1(rr * 0.9)}" fill="none" stroke="#fff0c0" stroke-width="0.4">${an('opacity', '0.3;1;0.3', 3.6, 0, SPL(2))}</circle>` })
          + cyl3(C, [0, 3.2, 0], [0, 7.6, 0], 3.4, '#c8a058', { r2: 6.4, mat: 'metal', olw: 0.3 });
        const c = C.P([0, SY, 0]), r = SR * k, cid = C.u('ac');
        let ves = ''; rep(10, i => { const y0 = -r + R() * 2 * r, y1 = y0 + (R() - 0.5) * r * 1.2, d = `M${f1(-r * 1.1)} ${f1(y0)}C${f1(-r * 0.4)} ${f1(y0 + (R() - 0.5) * r)} ${f1(r * 0.3)} ${f1(y1 + (R() - 0.5) * r)} ${f1(r * 1.1)} ${f1(y1)}`, thin = i % 3 === 0;
          ves += `<path d="${d}" stroke="${thin ? '#a8723a' : '#fff4dc'}" stroke-width="${f1((thin ? 0.16 : 0.9 + R() * 1.2) * k)}" fill="none" opacity="${thin ? 0.45 : 0.35}" stroke-linecap="round"${thin ? '' : ' filter="url(#m12b1)"'}/>`; });
        const sph = `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * 2.2)}" fill="#ffc878" opacity="0.3" filter="url(#m11b4)">${an('opacity', '0.15;0.4;0.15', 16, 0, SPL(2))}</circle>`
          + `<clipPath id="${cid}"><circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r)}"/></clipPath><circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r)}" fill="url(#${id}a)"/>`
          + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r)}" fill="url(#${id}w)" opacity="0">${an('opacity', '0;0.85;0', 16, 0, SPL(2))}</circle>`
          + `<g clip-path="url(#${cid})"><g transform="translate(${P2(c)})">${ves}</g></g>`
          + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r)}" fill="url(#${id}s)"/><ellipse cx="${f1(c[0] - r * 0.35)}" cy="${f1(c[1] - r * 0.4)}" rx="${f1(r * 0.28)}" ry="${f1(r * 0.16)}" fill="#ffffff" opacity="0.5" transform="rotate(-30 ${f1(c[0] - r * 0.35)} ${f1(c[1] - r * 0.4)})"/>`;
        let s = shadow(C, 0, 0, 8, 8, 0.45) + plinth + sph;
        C.p(-17, 0, 0); C.p(17, 0, 0); C.p(0, SY + SR + 2, 0);
        return { defs: DEF19 + `<defs><radialGradient id="${id}a" cx="45%" cy="50%" r="60%"><stop offset="0" stop-color="#ffd8a0"/><stop offset="0.6" stop-color="#f0b468"/><stop offset="1" stop-color="#c47a3a"/></radialGradient>`
          + `<radialGradient id="${id}w" cx="45%" cy="50%" r="60%"><stop offset="0" stop-color="#fffbf0"/><stop offset="0.7" stop-color="#fff0d8"/><stop offset="1" stop-color="#f0d0a8"/></radialGradient>`
          + `<radialGradient id="${id}s" cx="35%" cy="30%" r="80%"><stop offset="0.5" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#5a2a0a" stop-opacity="0.35"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-086 LEVITATING MOON-PHASE ORB WITH MELATONIN-SYNC GLOW (T5): a detailed moon (grey-ivory regolith, dark maria, rayed craters) floating on
    // nothing above a walnut and brass maglev base whose ring glows a sleepy amber; the moon's own light is a warm, blue-free glow. Live: the moon
    // turns slowly as it floats and bobs, its phase shadow sweeps across over a long cycle, and the base ring breathes.
    N.moon30 = S => { const D = { w: 34, d: 34, small: 1, round: 1, glow: () => ({ y: 30, r: 50 }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('moon30'), id = C.u('m86'), k = C.k, MR = 9.4, MY = 27;
        const base = cyl3(C, [0, 0, 0], [0, 3.4, 0], 9, '#5a3820', { olw: 0.35 }) + cyl3(C, [0, 3.4, 0], [0, 4.4, 0], 8.6, '#d4b06a', { mat: 'metal', olw: 0.3, cap: rr => `<circle r="${f1(rr * 0.7)}" fill="#2a1e14"/><circle r="${f1(rr * 0.7)}" fill="none" stroke="#ffb860" stroke-width="0.8">${an('opacity', '0.4;1;0.4', 5, 0, SPL(2))}</circle><circle r="${f1(rr * 0.7)}" fill="none" stroke="#ffc878" stroke-width="2.4" opacity="0.3" filter="url(#m12b1)"/>` });
        const c = C.P([0, MY, 0]), r = MR * k, cid = C.u('mc');
        // lunar surface texture (two copies side by side; translated = rotation)
        const tex = w => { let o = `<rect x="0" y="${f1(-r)}" width="${f1(w)}" height="${f1(2 * r)}" fill="#d8d2c4"/>`;
          [[0.2, -0.2, 0.42], [0.55, 0.15, 0.32], [0.8, -0.35, 0.25], [0.35, 0.4, 0.22]].forEach(([u, v, s]) => o += `<ellipse cx="${f1(u * w)}" cy="${f1(v * r)}" rx="${f1(s * r * 1.4)}" ry="${f1(s * r)}" fill="#9a968c" opacity="0.7" filter="url(#m12b1)"/>`);
          rep(30, () => { const x = R() * w, y = (R() - 0.5) * 2 * r, cr = (0.15 + Math.pow(R(), 2) * 0.9) * k; o += `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(cr)}" fill="#a8a294"/><circle cx="${f1(x - cr * 0.25)}" cy="${f1(y - cr * 0.25)}" r="${f1(cr * 0.7)}" fill="#ece6d8" opacity="0.7"/>`; });
          [[0.7, 0.55]].forEach(([u, v]) => { o += rep(10, j => { const a = j / 10 * 2 * PI; return `<path d="M${f1(u * w)} ${f1(v * r)}l${f1(Math.cos(a) * r * 0.5)} ${f1(Math.sin(a) * r * 0.5)}" stroke="#f4f0e4" stroke-width="${f1(0.2 * k)}" opacity="0.5"/>`; }).join(''); });
          return o; };
        const W = 4 * r, T = tex(W);
        const moon = `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * 2.4)}" fill="#ffc888" opacity="0.32" filter="url(#m11b4)">${an('opacity', '0.22;0.4;0.22', 8, 0, SPL(2))}</circle>`
          + `<clipPath id="${cid}"><circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r)}"/></clipPath><g clip-path="url(#${cid})"><g transform="translate(${f1(c[0] - r)} ${f1(c[1])})"><g>${at('translate', `0 0;${f1(-W)} 0`, 90)}${T}<g transform="translate(${f1(W)} 0)">${T}</g></g></g>`
          + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r)}" fill="#ffd8a0" opacity="0.18"/>`
          + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * 1.04)}" fill="#14100c" opacity="0.62"><animate attributeName="cx" values="${f1(c[0] - r * 2.1)};${f1(c[0] + r * 2.1)}" dur="60s" repeatCount="indefinite"/></circle></g>`
          + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r)}" fill="url(#${id}l)"/>`;
        const bob = `<g>${at('translate', `0 0;0 ${f1(-1.2 * k)};0 0`, 6, 0, SPL(2))}${moon}</g>`;
        const beam = (() => { const a = C.P([0, 4.6, 0]), b = C.P([0, MY - MR, 0]); return `<path d="M${f1(a[0] - 4 * k)} ${f1(a[1])}L${f1(b[0] - 2 * k)} ${f1(b[1])}L${f1(b[0] + 2 * k)} ${f1(b[1])}L${f1(a[0] + 4 * k)} ${f1(a[1])}Z" fill="#ffd8a0" opacity="0.12" filter="url(#m12b1)">${an('opacity', '0.06;0.18;0.06', 5, 0, SPL(2))}</path>`; })();
        let s = shadow(C, 0, 0, 9, 9, 0.45) + base + beam + bob;
        C.p(-17, 0, 0); C.p(17, 0, 0); C.p(0, MY + MR + 2, 0);
        return { defs: DEF19 + `<defs><radialGradient id="${id}l" cx="40%" cy="35%" r="70%"><stop offset="0.55" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#2a1a0a" stop-opacity="0.45"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-007 BATTERED WOODEN FOOTLOCKER TRUNK (T1): an old pine footlocker with a scuffed olive-drab paint gone to bare wood on every edge, dented tin
    // corner caps, steel straps with rivets, a sprung hasp with no padlock, rope side handles (one frayed), a faded stencil "PROPERTY OF - BUNK 7" and a
    // peeling band sticker; the lid sits ajar on a striped sock caught in it. Act 'play' + use kept. Live: the caught sock sways.
    N.trunk30 = S => { const D = { w: 94, d: 58, act: 'play', use: { x: 0, z: 54 }, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('trunk30'), W = 64, DD = 34, HB = 26, LH = 7, OD = '#5e6a42';
        const wear = (w, h) => `<rect width="${w}" height="${h}" fill="${OD}"/>` + rep(Math.floor(h / 4.6), i => `<path d="M0 ${f1((i + 1) * 4.6)}H${w}" stroke="#3a4228" stroke-width="0.3" opacity="0.7"/>`).join('')
          + rep(18, () => { const x = R() * w, y = R() * h; return `<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(0.6 + R() * 2.4)}" ry="${f1(0.3 + R() * 0.8)}" fill="#a88a5a" opacity="${f1(0.4 + R() * 0.4)}"/>`; }).join('')
          + `<rect width="${w}" height="1" fill="#a88a5a" opacity="0.6"/><rect y="${f1(h - 1)}" width="${w}" height="1" fill="#a88a5a" opacity="0.6"/><rect width="1" height="${h}" fill="#a88a5a" opacity="0.5"/><rect x="${f1(w - 1)}" width="1" height="${h}" fill="#a88a5a" opacity="0.5"/>`;
        const strapV = (x, h) => `<rect x="${x}" width="2.4" height="${h}" fill="#4a4a46"/>` + rep(Math.floor(h / 5), i => `<circle cx="${f1(x + 1.2)}" cy="${f1(2.5 + i * 5)}" r="0.45" fill="#8a8a84"/>`).join('');
        const corner = (x, y, sx, sy) => `<path d="M${x} ${y}h${4 * sx}l${-1 * sx} ${1.4 * sy}h${-1.6 * sx}v${1.6 * sy}l${-1.4 * sx} ${1 * sy}Z" fill="#9a9a94" stroke="#5a5a54" stroke-width="0.15"/>`;
        const front = wear(W, HB) + strapV(12, HB) + strapV(W - 14.4, HB) + corner(0, 0, 1, 1) + corner(W, 0, -1, 1) + corner(0, HB, 1, -1) + corner(W, HB, -1, -1)
          + `<g opacity="0.55"><text x="${f1(W / 2)}" y="11" text-anchor="middle" font-family="'Courier New',monospace" font-weight="bold" font-size="3" fill="#e8e0c8">PROPERTY OF</text><text x="${f1(W / 2)}" y="15.6" text-anchor="middle" font-family="'Courier New',monospace" font-weight="bold" font-size="3.6" fill="#e8e0c8">BUNK 7</text></g>`
          + `<rect x="${f1(W / 2 - 2.4)}" y="0" width="4.8" height="5" rx="0.6" fill="#7a7a74" stroke="#3a3a36" stroke-width="0.2"/><path d="M${f1(W / 2 - 1)} 4.2v-1.6h2v1.6" stroke="#3a3a36" stroke-width="0.5" fill="none"/>`
          + `<g transform="rotate(-8 50 20)"><circle cx="50" cy="20" r="3.2" fill="#d8402a"/><circle cx="50" cy="20" r="2.2" fill="#f4d860"/><path d="M47.6 21.6l1.4 -2l1.2 1.6l1.6 -2.4" stroke="#1a1a1a" stroke-width="0.4" fill="none"/><path d="M51.6 17.4l1.4 -0.6l-0.4 1.6Z" fill="#e8e0d0"/></g>`;
        const side = (frayed) => wear(DD, HB) + corner(0, 0, 1, 1) + corner(DD, 0, -1, 1) + `<rect x="${f1(DD / 2 - 5)}" y="7" width="10" height="2.4" rx="1.2" fill="#3a3a36"/><path d="M${f1(DD / 2 - 4)} 9.4q4 4 8 0" stroke="#c8b488" stroke-width="1.1" fill="none"/>` + (frayed ? `<path d="M${f1(DD / 2 + 4)} 9.4l0.6 2.4M${f1(DD / 2 + 4)} 9.4l1.2 1.8M${f1(DD / 2 + 4)} 9.4l-0.2 2.6" stroke="#d8c498" stroke-width="0.3"/>` : '');
        const body = box3(C, decC(C, { c: [0, 0, 0], w: W, h: HB, d: DD, col: OD, r: 0.6, dec: { f: front, b: wear(W, HB), l: side(0), r: side(1) } }));
        // lid ajar, hinged at the back top edge
        const th = 0.12, A = [[1, 0, 0], [0, Math.cos(th), Math.sin(-th) * -1 * -1], [0, Math.sin(th), Math.cos(th)]];
        A[1] = [0, Math.cos(th), -Math.sin(th)]; A[2] = [0, Math.sin(th), Math.cos(th)];
        const hinge = [0, HB, -DD / 2], lc = [hinge[0] + A[2][0] * DD / 2, hinge[1] + A[2][1] * DD / 2, hinge[2] + A[2][2] * DD / 2];
        const lidTop = wear(W, DD) + strapV(12, DD) + strapV(W - 14.4, DD) + `<rect x="${f1(W / 2 - 9)}" y="${f1(DD / 2 - 5)}" width="18" height="10" fill="#a88a5a" opacity="0.25"/>`;
        const lid = box3(C, decC(C, { c: lc, ax: A, w: W + 0.8, h: LH, d: DD + 0.8, col: OD, r: 0.6, dec: { t: lidTop, f: wear(W + 0.8, LH) + strapV(12, LH) + strapV(W - 14, LH), l: wear(DD + 0.8, LH), r: wear(DD + 0.8, LH) } }));
        // dark gap under the lid front + the caught sock
        const g0 = C.P([-W / 2 + 1, HB + 0.1, DD / 2]), g1 = C.P([W / 2 - 1, HB + 0.1, DD / 2]), g2 = C.P([W / 2 - 1, HB + DD * Math.sin(th) * 0.9, DD / 2 + 0.2]), g3 = C.P([-W / 2 + 1, HB + DD * Math.sin(th) * 0.9, DD / 2 + 0.2]);
        const gap = C.v[2] > 0 ? `<path d="M${P2(g0)}L${P2(g1)}L${P2(g2)}L${P2(g3)}Z" fill="#1a140e" opacity="0.85"/>` : '';
        const sp = C.P([10, HB + 1.6, DD / 2 + 0.6]), k = C.k, sock = `M0 0L${f1(3 * k)} 0L${f1(3.2 * k)} ${f1(7 * k)}Q${f1(3.4 * k)} ${f1(9 * k)} ${f1(5.6 * k)} ${f1(9.4 * k)}L${f1(5.6 * k)} ${f1(11.6 * k)}Q${f1(1.6 * k)} ${f1(11.8 * k)} ${f1(0.4 * k)} ${f1(8 * k)}Z`;
        const sk = C.v[2] > 0 ? `<g transform="translate(${P2(sp)})"><g>${at('rotate', '-5;6;-5', 4.2, 0, SPL(2))}<path d="${sock}" fill="#f2ece0" stroke="#a8a090" stroke-width="${f1(0.12 * k)}"/>${[1.6, 3.2, 4.8].map(y => `<path d="M${f1(0.1 * k)} ${f1(y * k)}L${f1(3.1 * k)} ${f1(y * k)}" stroke="#c83a3a" stroke-width="${f1(0.5 * k)}"/>`).join('')}<path d="M0 0L${f1(3 * k)} 0" stroke="#3a6aa8" stroke-width="${f1(0.6 * k)}"/></g></g>` : '';
        let s = shadow(C, 0, 0, W * 0.62, DD * 0.66, 0.5) + body + gap + lid + sk;
        C.p(-47, 0, 0); C.p(47, 0, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    const clipPLN = (C, y, x0, z0, w, d, svg) => { const i = C.u('pc'); return PLN(C, y, `<clipPath id="${i}"><rect x="${f1(x0)}" y="${f1(z0)}" width="${f1(w)}" height="${f1(d)}"/></clipPath><g clip-path="url(#${i})">${svg}</g>`); };
    // fabric weave texture for a face (fine warp/weft + slubs)
    const linen = (R, w, h, a, b) => rep(Math.ceil(h / 0.5), i => `<path d="M0 ${f1(i * 0.5)}H${f1(w)}" stroke="${i % 2 ? a : b}" stroke-width="0.14" opacity="0.35"/>`).join('') + rep(Math.ceil(w / 0.6), i => `<path d="M${f1(i * 0.6)} 0V${f1(h)}" stroke="${b}" stroke-width="0.1" opacity="0.18"/>`).join('')
      + rep(Math.round(w * h / 18), () => `<path d="M${f1(R() * w)} ${f1(R() * h)}h${f1(0.6 + R() * 1.6)}" stroke="${R() < 0.5 ? a : b}" stroke-width="0.22" opacity="0.5"/>`).join('');
    // tufting cell grid on a top face: puffy diamonds (highlight in each), pleats between buttons, shadowed covered buttons
    const tufts = (R, w, d, nx, nz, col, dk, m) => { const bx = (w - 2 * m) / nx, bz = (d - 2 * m) / nz, B = []; let o = '';
      for (let j = 0; j <= nz; j++) for (let i = 0; i <= nx; i++) { if ((i + j) % 2) continue; B.push([m + i * bx, m + j * bz]); }
      o += '<g filter="url(#m12b1)">'; B.forEach(([x, z]) => { o += `<ellipse cx="${f1(x + bx)}" cy="${f1(z + bz * 0.85)}" rx="${f1(bx * 0.95)}" ry="${f1(bz * 0.8)}" fill="url(#tp30)"/><ellipse cx="${f1(x)}" cy="${f1(z + 0.4)}" rx="${f1(bx * 0.35)}" ry="${f1(bz * 0.3)}" fill="${dk}" opacity="0.12"/>`; }); o += '</g>';
      B.forEach(([x, z]) => { [[bx, bz], [-bx, bz], [bx, -bz], [-bx, -bz]].forEach(([dx, dz]) => { const x2 = x + dx, z2 = z + dz; if (x2 < m - 0.1 || x2 > w - m + 0.1 || z2 < m - 0.1 || z2 > d - m + 0.1) return;
        o += `<path d="M${f1(x)} ${f1(z)}Q${f1(x + dx / 2 + dz * 0.04)} ${f1(z + dz / 2 - dx * 0.04)} ${f1(x2)} ${f1(z2)}" stroke="${dk}" stroke-width="0.7" fill="none" opacity="0.3"/><path d="M${f1(x + 0.3)} ${f1(z + 0.3)}L${f1(x2 + 0.3)} ${f1(z2 + 0.3)}" stroke="#ffffff" stroke-width="0.3" opacity="0.25"/>`; }); });
      B.forEach(([x, z]) => { o += `<ellipse cx="${f1(x + 0.2)}" cy="${f1(z + 0.4)}" rx="1.5" ry="1.2" fill="${dk}" opacity="0.4"/><circle cx="${f1(x)}" cy="${f1(z)}" r="1.05" fill="${col}" stroke="${dk}" stroke-width="0.18"/><circle cx="${f1(x - 0.3)}" cy="${f1(z - 0.3)}" r="0.4" fill="#ffffff" opacity="0.45"/>`; });
      return o; };

    // BED-027 UPHOLSTERED LINEN STORAGE OTTOMAN BENCH (T2): a long ottoman in warm oatmeal slub linen: a deep padded lift-up lid with a button-tufted top
    // and a contrast flax piping round both edges, a gathered fabric pull-tab at the front where it opens, linen-wrapped sides with soft wrinkles at the
    // corners, on four turned beech legs; a chunky cable-knit cream throw slung over one end with a tasselled edge. Seats {+-34, 2, 30} kept.
    // Live: the throw's tassels sway and a soft sheen moves along the linen lid.
    N.ott30 = S => { const D = { w: 144, d: 50, act: 'sit', seats: [{ x: -34, z: 2, h: 30 }, { x: 34, z: 2, h: 30 }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('ott30'), k = C.k, id = C.u('o27'), W = 110, DD = 40, LN = '#d2c4a6', LD = '#9a8a6a', Y0 = 6, HB = 17, LH = 7;
        const legs = [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([sx, sz]) => { const x = sx * (W / 2 - 5), z = sz * (DD / 2 - 5);
          return { q: [x, 3, z], s: cyl3(C, [x, 0, z], [x, 1.2, z], 1.6, '#c89a62', { olw: 0.25 }) + cyl3(C, [x, 1.2, z], [x, 3.4, z], 2.4, '#d8ae74', { r2: 2.8, olw: 0.25 }) + cyl3(C, [x, 3.4, z], [x, Y0 + 0.2, z], 2.8, '#d8ae74', { r2: 2.2, olw: 0.25 }) }; });
        const side = (w, h, tab) => `<rect width="${w}" height="${h}" fill="${LN}"/>` + linen(R, w, h, '#e8dcc0', LD)
          + `<path d="M0 ${f1(h - 0.6)}H${w}" stroke="${LD}" stroke-width="0.9" opacity="0.5"/><path d="M0 ${f1(h - 1)}H${w}" stroke="#efe6d2" stroke-width="0.5"/>`
          + [[2, 1], [w - 2, -1]].map(([x, sd]) => rep(4, j => `<path d="M${f1(x)} ${f1(2 + j * 3.4)}q${f1(sd * 2)} 1 ${f1(sd * 3)} 2.6" stroke="${LD}" stroke-width="0.25" fill="none" opacity="0.35"/>`).join('')).join('')
          + `<rect width="${w}" height="${h}" fill="url(#${id}v)"/>`;
        const body = box3(C, decC(C, { c: [0, Y0, 0], w: W, h: HB, d: DD, col: LN, r: 2.6, dec: { f: side(W, HB), b: side(W, HB), l: side(DD, HB), r: side(DD, HB) } }));
        const lidS = (w) => `<rect width="${w}" height="${LH}" fill="${LN}"/>` + linen(R, w, LH, '#ece2c8', LD) + `<path d="M0 0.4H${w}M0 ${f1(LH - 0.4)}H${w}" stroke="#b8a682" stroke-width="0.9"/><path d="M0 0.2H${w}M0 ${f1(LH - 0.6)}H${w}" stroke="#f2ead8" stroke-width="0.35"/>`
          + `<rect x="0" y="0" width="${w}" height="${LH}" fill="url(#${id}l)"/>`;
        const lidF = lidS(W + 1.2) + `<path d="M${f1(W / 2 - 3)} ${f1(LH)}q3 2.6 6 0" fill="${LN}" stroke="${LD}" stroke-width="0.25"/><path d="M${f1(W / 2 - 2)} ${f1(LH + 0.4)}l0.6 1.2M${f1(W / 2)} ${f1(LH + 0.6)}v1.4M${f1(W / 2 + 2)} ${f1(LH + 0.4)}l-0.6 1.2" stroke="${LD}" stroke-width="0.2" opacity="0.6"/>`;
        const lidT = `<rect width="${W + 1.2}" height="${DD + 1.2}" fill="${LN}"/>` + linen(R, W + 1.2, DD + 1.2, '#ece2c8', LD) + `<rect width="${W + 1.2}" height="${DD + 1.2}" fill="url(#${id}t)"/>` + tufts(R, W + 1.2, DD + 1.2, 10, 2, '#d8cbb0', '#7a6a4a', 7)
          + `<rect x="-30" y="-6" width="16" height="${DD + 14}" fill="url(#${id}g)" transform="skewX(-16)">${an('x', `-30;${W + 30}`, 12)}</rect>`;
        const lid = box3(C, decC(C, { c: [0, Y0 + HB, 0], w: W + 1.2, h: LH, d: DD + 1.2, col: LN, r: 3.2, dec: { t: lidT, f: lidF, b: lidS(W + 1.2), l: lidS(DD + 1.2), r: lidS(DD + 1.2) } }));
        // chunky cable-knit throw slung over the left end
        const knit = (w, h, edge) => { let o = `<rect width="${w}" height="${h}" fill="#f0e8d8"/>`; for (let x = 1.6; x < w; x += 3.2) { for (let y = 0; y < h; y += 1.6) o += `<path d="M${f1(x - 1.2)} ${f1(y)}l1.2 1.4l1.2 -1.4" stroke="#cfc2a6" stroke-width="0.55" fill="none"/>`; }
          for (let x = 6; x < w; x += 9.6) o += `<path d="M${f1(x)} 0${rep(Math.ceil(h / 3), i => `q1.6 0.75 0 1.5q-1.6 0.75 0 1.5`).join('')}" stroke="#d8ccb0" stroke-width="1.6" fill="none"/><path d="M${f1(x)} 0${rep(Math.ceil(h / 3), i => `q1.6 0.75 0 1.5q-1.6 0.75 0 1.5`).join('')}" stroke="#fffaf0" stroke-width="0.5" fill="none" transform="translate(-0.3 0)"/>`;
          return o + (edge ? `<path d="M0 ${f1(h - 0.6)}${rep(Math.ceil(w / 2.4), i => `q0.6 1 1.2 0q0.6 -1 1.2 0`).join('')}" stroke="#cfc2a6" stroke-width="0.4" fill="none"/>` : ''); };
        const TX0 = -W / 2 - 1.4, TW = 18, TY = Y0 + HB + LH;
        const throwTop = box3(C, decC(C, { c: [TX0 + TW / 2, TY, 0], w: TW, h: 1.6, d: DD + 2.8, col: '#f0e8d8', r: 0.8, dec: { t: knit(TW, DD + 2.8), f: knit(TW, 1.6), b: knit(TW, 1.6) } }));
        const hang = sz => box3(C, decC(C, { c: [TX0 + TW / 2, Y0 + 5, sz * (DD / 2 + 1.6)], w: TW, h: HB + LH - 3.4, d: 1.4, col: '#f0e8d8', r: 0.6, dec: { f: knit(TW, HB + LH - 3.4, 1), b: knit(TW, HB + LH - 3.4, 1) } }));
        const endHang = box3(C, decC(C, { c: [TX0 - 0.2, Y0 + 7, 0], w: 1.4, h: HB + LH - 5.4, d: DD + 2.8, col: '#ece4d2', r: 0.6, dec: { l: knit(DD + 2.8, HB + LH - 5.4, 1), r: knit(DD + 2.8, HB + LH - 5.4, 1) } }));
        let tass = ''; [1, -1].forEach(sz => { if (sz * C.v[2] <= 0) return; rep(6, i => { const x = TX0 + 1.6 + i * 3, top = C.P([x, Y0 + 5, sz * (DD / 2 + 2.4)]); tass += `<g>${at('rotate', `-7 ${P2(top)};7 ${P2(top)};-7 ${P2(top)}`, n4(3 + i * 0.3), n4(-i * 0.4), SPL(2))}<path d="M${P2(top)}l0 ${f1(4.4 * k)}" stroke="#e6dcc6" stroke-width="${f1(1 * k)}" stroke-linecap="round"/><path d="M${P2(top)}l0 ${f1(1.2 * k)}" stroke="#bfb294" stroke-width="${f1(1.3 * k)}"/></g>`; }); });
        const lb = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] <= 0), lf = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] > 0);
        const hz = C.v[2] > 0 ? [hang(-1), hang(1)] : [hang(1), hang(-1)], endSide = C.v[0] < 0;
        let s = shadow(C, 0, 0, W * 0.56, DD * 0.7, 0.5) + lb.map(o => o.s).join('') + lf.map(o => o.s).join('') + (endSide ? '' : endHang) + hz[0] + body + lid + throwTop + hz[1] + (endSide ? endHang : '') + tass;
        C.p(-72, 0, 0); C.p(72, 0, 0);
        return { defs: DEF19 + `<defs><radialGradient id="tp30" cx="45%" cy="40%" r="60%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.32"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.08"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient><linearGradient id="${id}v" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.7" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#3a2a10" stop-opacity="0.16"/></linearGradient>`
          + `<linearGradient id="${id}l" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#3a2a10" stop-opacity="0.18"/></linearGradient>`
          + `<radialGradient id="${id}t" cx="50%" cy="45%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.18"/><stop offset="1" stop-color="#3a2a10" stop-opacity="0.12"/></radialGradient>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.18"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-047 WOVEN LEATHER & TEAK MID-CENTURY DAYBED BENCH (T3): an oiled teak frame (rounded rails, finger-jointed corners) on tapered legs with
    // brass ferrules; the deck and the raked head end strung with 2 cm saddle-leather straps in a tight basket weave, every strap stitched and wrapped
    // round the side rails; a round cognac leather bolster with piped, button-centred ends, a folded mustard wool throw with fringe at the foot.
    // Nap {0, 24, 30} and w 80 d 170 kept. Live: a warm sheen slides along the leather and the brass ferrules glint.
    N.day30 = S => { const D = { w: 80, d: 170, act: 'nap', seats: [{ x: 0, z: 24, h: 30, k: 'nap' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('day30'), k = C.k, id = C.u('d47'), TK = '#9a6236', W = 54, Z0 = -76, Z1 = 76, RY = 23, RH = 4.4;
        const grain = (w, h) => `<rect width="${w}" height="${h}" fill="${TK}"/>` + grainH(R, w, h, Math.max(3, Math.round(h * 1.4)), '#6a3c1c', 0.5) + grainH(R, w, h, 2, '#c48a52', 0.4);
        const legs = [[-1, Z0 + 7], [1, Z0 + 7], [-1, Z1 - 7], [1, Z1 - 7], [-1, 0], [1, 0]].map(([sx, z]) => { const x = sx * (W / 2 - 3.4);
          return { q: [x, 10, z], s: cyl3(C, [x, 1.4, z], [x, RY, z], 1.1, TK, { r2: 1.9, olw: 0.3 }) + cyl3(C, [x, 0, z], [x, 1.6, z], 1, '#d4b06a', { mat: 'metal', r2: 1.1, olw: 0.25 }) }; });
        // woven deck (a strap layer box) + rails
        const SY = RY + RH - 1.2, g = 2.2;
        const weave = (w, d) => { let o = `<rect width="${w}" height="${d}" fill="#3a2010"/>`;
          for (let i = 0; i * g < w; i++) for (let j = 0; j * g < d; j++) { const x = i * g, z = j * g, over = (i + j) % 2 === 0;
            o += over ? `<rect x="${f1(x + 0.12)}" y="${f1(z - 0.2)}" width="${f1(g - 0.24)}" height="${f1(g + 0.4)}" rx="0.35" fill="#b8784a"/><rect x="${f1(x + 0.3)}" y="${f1(z)}" width="${f1(g - 0.6)}" height="${f1(g * 0.35)}" rx="0.2" fill="#d6965e" opacity="0.7"/>`
              : `<rect x="${f1(x - 0.2)}" y="${f1(z + 0.12)}" width="${f1(g + 0.4)}" height="${f1(g - 0.24)}" rx="0.35" fill="#9a5e34"/><rect x="${f1(x)}" y="${f1(z + 0.3)}" width="${f1(g * 0.35)}" height="${f1(g - 0.6)}" rx="0.2" fill="#c08048" opacity="0.6"/>`; }
          return o + `<rect width="${w}" height="${d}" fill="url(#${id}s)"/>`; };
        const deck = box3(C, decC(C, { c: [0, SY, 4], w: W - 5, h: 1.2, d: Z1 - Z0 - 18, col: '#a86a3c', r: 0.2, dec: { t: weave(W - 5, Z1 - Z0 - 18) } }));
        const wraps = (d) => grain(d, RH) + rep(Math.floor(d / g), i => i % 2 ? '' : `<rect x="${f1(i * g)}" y="-0.1" width="${f1(g - 0.2)}" height="${f1(RH * 0.6)}" rx="0.3" fill="#a86a3c"/><path d="M${f1(i * g + 0.3)} ${f1(RH * 0.45)}h${f1(g - 0.8)}" stroke="#e8c090" stroke-width="0.15" stroke-dasharray="0.3 0.25"/>`).join('');
        const rails = [-1, 1].map(sx => ({ q: [sx * (W / 2 - 1.3), RY, 0], s: box3(C, decC(C, { c: [sx * (W / 2 - 1.3), RY, 0], w: 2.6, h: RH, d: Z1 - Z0, col: TK, r: 1, dec: { l: wraps(Z1 - Z0), r: wraps(Z1 - Z0), t: grain(2.6, Z1 - Z0) } })) }));
        const ends = [Z0 + 1.3, Z1 - 1.3].map(z => box3(C, decC(C, { c: [0, RY, z], w: W - 5, h: RH, d: 2.6, col: TK, r: 1, dec: { f: grain(W - 5, RH), b: grain(W - 5, RH), t: grain(W - 5, 2.6) } })));
        // raked head end: tilted woven panel in a teak frame
        const th = 0.62, A = [[1, 0, 0], [0, Math.cos(th), Math.sin(th)], [0, -Math.sin(th), Math.cos(th)]], hp = [0, SY, Z0 + 8];
        const head = box3(C, decC(C, { c: [hp[0], hp[1], hp[2]], ax: A, w: W - 3, h: 22, d: 2.4, col: TK, r: 0.8, dec: { f: grain(W - 3, 22) + `<g transform="translate(2.6 2.6)">${weave(W - 8.2, 16.8)}</g>`, b: grain(W - 3, 22), t: grain(W - 3, 2.4) } }));
        // bolster (axis x) with piped button ends
        const BZ = Z0 + 18, BY = SY + 6;
        const bol = cyl3(C, [-W / 2 + 5, BY, BZ], [W / 2 - 5, BY, BZ], 5.4, '#8a4622', { olw: 0.35, n: 32, capCol: '#7a3c1c', cap: rr => `<circle r="${f1(rr * 0.92)}" fill="none" stroke="#e8b47a" stroke-width="0.35"/>` + rep(12, i => `<path d="M0 0L${f1(Math.cos(i * PI / 6) * rr * 0.85)} ${f1(Math.sin(i * PI / 6) * rr * 0.85)}" stroke="#5a2a10" stroke-width="0.25" opacity="0.6"/>`).join('') + `<circle r="${f1(rr * 0.18)}" fill="#5a2a10"/>` })
          + (() => { const a = C.P([-W / 2 + 6, BY + 5.2, BZ]), b = C.P([W / 2 - 6, BY + 5.2, BZ]); return `<path d="M${P2(a)}L${P2(b)}" stroke="#d89a62" stroke-width="${f1(1.2 * k)}" opacity="0.45" stroke-linecap="round"/>`; })();
        // folded mustard throw with fringe at the foot
        const FZ = Z1 - 22, fr = rep(14, i => `<path d="M${f1(1 + i * 2.6)} 0v2.6" stroke="#c8902a" stroke-width="0.45"/>`).join('');
        const throwF = box3(C, decC(C, { c: [0, SY + 1.2, FZ], w: W - 10, h: 3.4, d: 16, col: '#d8a038', r: 1.4, dec: { t: `<rect width="${W - 10}" height="16" fill="#d8a038"/>` + linen(R, W - 10, 16, '#e8b850', '#a87420'), f: `<rect width="${W - 10}" height="3.4" fill="#c8922e"/><path d="M0 1.1H${W - 10}M0 2.3H${W - 10}" stroke="#a87420" stroke-width="0.25"/>` } }))
          + (C.v[2] > 0 ? (() => { const p = C.P([-(W - 10) / 2, SY + 1.4, FZ + 8.1]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})">${fr}</g>`; })() : '');
        const lb = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] <= 0), lf = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] > 0), rs = rails.slice().sort((a, b) => a.q[0] * C.v[0] - b.q[0] * C.v[0]);
        const headFirst = C.v[2] > 0;
        let s = shadow(C, 0, 0, W * 0.7, (Z1 - Z0) * 0.56, 0.5) + lb.map(o => o.s).join('') + rs[0].s + (headFirst ? head : '') + ends[headFirst ? 0 : 1] + deck + ends[headFirst ? 1 : 0] + lf.map(o => o.s).join('') + rs[1].s + (headFirst ? '' : head) + bol + throwF;
        C.p(-40, 0, 0); C.p(40, 0, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0.3"><stop offset="0.3" stop-color="#ffe0b8" stop-opacity="0"/><stop offset="0.5" stop-color="#ffe0b8" stop-opacity="0.25"/><stop offset="0.7" stop-color="#ffe0b8" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-0.6 0;0.6 0;-0.6 0" dur="11s" repeatCount="indefinite"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-067 TUFTED CASHMERE & BRASS CABRIOLE-LEG BENCH (T4): a long bench in warm dove cashmere: a deep, crowned seat with diamond tufting (puffy
    // pillowed diamonds, pleats folding into every covered button), soft pleats running down the sides from the edge tufts, a self-piped edge, an apron
    // finished with a close row of polished brass nailheads, on four sculpted polished-brass cabriole legs with acanthus knees and pad feet.
    // Seats {+-34, 2, 30} kept. Live: a soft sheen drifts across the cashmere and a glint runs down the brass legs.
    N.cab30 = S => { const D = { w: 144, d: 50, act: 'sit', seats: [{ x: -34, z: 2, h: 30 }, { x: 34, z: 2, h: 30 }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('cab30'), k = C.k, id = C.u('c67'), CM = '#cbc1ba', CD = '#8a807a', BR = '#d0a85a', W = 108, DD = 40, AY = 17.6, AH = 4.6, SY0 = AY + AH, SH = 8;
        // cabriole leg: polyline of points (knee out, ankle in, foot out) as tapered cyl3 segments + knee scroll + pad foot
        const leg = (sx, sz) => { const ox = sx, oz = sz, P = [[0, AY + 0.4, 0, 2.2], [1.2, AY - 2, 1.2, 2.5], [1.6, AY - 5, 1.6, 2], [0.6, AY - 9, 0.6, 1.3], [-0.4, 6, -0.4, 1], [-0.2, 3, -0.2, 1], [0.8, 1.2, 0.8, 1.3]];
          const X = sx * (W / 2 - 6), Z = sz * (DD / 2 - 6), Q = P.map(([dx, y, dz, r]) => [[X + ox * dx, y, Z + oz * dz], r]);
          let o = ''; for (let i = 0; i < Q.length - 1; i++) o += cyl3(C, Q[i][0], Q[i + 1][0], Q[i][1], BR, { r2: Q[i + 1][1], mat: 'metal', olw: 0.2, noCap: 1, n: 16 });
          o += sph(C, [X + ox * 1.6, AY - 3.2, Z + oz * 1.6], 1.6, '#e0bc70') + cyl3(C, [X + ox * 0.8, 0, Z + oz * 0.8], [X + ox * 0.8, 1.2, Z + oz * 0.8], 2, BR, { mat: 'metal', r2: 1.4, olw: 0.2 });
          const a = C.P(Q[2][0]), b = C.P(Q[4][0]); o += `<path d="M${P2(a)}L${P2(b)}" stroke="#fff4d0" stroke-width="${f1(0.35 * k)}" stroke-dasharray="${f1(1.4 * k)} ${f1(30 * k)}" stroke-linecap="round"><animate attributeName="stroke-dashoffset" values="${f1(31 * k)};0" dur="${n4(5 + (sx + sz + 2) * 0.4)}s" repeatCount="indefinite"/></path>`;
          return { q: [X, 8, Z], s: o }; };
        const legs = [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([sx, sz]) => leg(sx, sz));
        const nails = w => `<rect width="${w}" height="${AH}" fill="${CM}"/>` + linen(R, w, AH, '#ddd4cc', CD) + rep(Math.floor((w - 2) / 1.5), i => `<circle cx="${f1(1 + i * 1.5)}" cy="${f1(AH - 1.4)}" r="0.55" fill="#e8c878"/><circle cx="${f1(0.85 + i * 1.5)}" cy="${f1(AH - 1.55)}" r="0.2" fill="#fff4d0"/>`).join('') + `<path d="M0 0.4H${w}" stroke="${CD}" stroke-width="0.5" opacity="0.5"/>`;
        const apron = box3(C, decC(C, { c: [0, AY, 0], w: W - 4, h: AH, d: DD - 4, col: CM, r: 1.4, dec: { f: nails(W - 4), b: nails(W - 4), l: nails(DD - 4), r: nails(DD - 4) } }));
        const seatSide = (w, nx) => `<rect width="${w}" height="${SH}" fill="${CM}"/>` + linen(R, w, SH, '#e2dad2', CD) + rep(nx + 1, i => { const x = 4 + i * (w - 8) / nx; return `<path d="M${f1(x)} 0q0.6 ${f1(SH * 0.5)} 0 ${f1(SH - 1.4)}" stroke="${CD}" stroke-width="0.45" fill="none" opacity="0.4"/><path d="M${f1(x + 0.5)} 0.4q0.6 ${f1(SH * 0.5)} 0 ${f1(SH - 2)}" stroke="#ffffff" stroke-width="0.3" fill="none" opacity="0.35"/>`; }).join('')
          + `<path d="M0 0.6H${w}" stroke="#f0e8e2" stroke-width="0.7"/><path d="M0 1.1H${w}" stroke="${CD}" stroke-width="0.35" opacity="0.5"/><path d="M0 ${f1(SH - 0.6)}H${w}" stroke="${CD}" stroke-width="0.6" opacity="0.5"/><rect width="${w}" height="${SH}" fill="url(#${id}v)"/>`;
        const top = `<rect width="${W}" height="${DD}" fill="${CM}"/>` + linen(R, W, DD, '#e2dad2', CD) + `<rect width="${W}" height="${DD}" fill="url(#${id}c)"/>` + tufts(R, W, DD, 12, 3, '#c4bab3', '#6a605a', 5)
          + `<rect x="-30" y="-6" width="18" height="${DD + 14}" fill="url(#${id}g)" transform="skewX(-16)">${an('x', `-30;${W + 30}`, 11)}</rect>`;
        const seat = box3(C, decC(C, { c: [0, SY0, 0], w: W, h: SH, d: DD, col: CM, r: 4, dec: { t: top, f: seatSide(W, 12), b: seatSide(W, 12), l: seatSide(DD, 3), r: seatSide(DD, 3) } }));
        const lb = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] <= 0), lf = legs.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] > 0);
        let s = shadow(C, 0, 0, W * 0.56, DD * 0.7, 0.5) + lb.map(o => o.s).join('') + apron + lf.map(o => o.s).join('') + seat;
        C.p(-72, 0, 0); C.p(72, 0, 0);
        return { defs: DEF19 + `<defs><radialGradient id="tp30" cx="45%" cy="40%" r="60%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.32"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.08"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient><radialGradient id="${id}c" cx="50%" cy="45%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="1" stop-color="#2a201a" stop-opacity="0.14"/></radialGradient>`
          + `<linearGradient id="${id}v" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.6" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#2a201a" stop-opacity="0.18"/></linearGradient>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-087 HEATED MASSAGE & SHOE-VALET SMART BEDSIDE LOUNGE BENCH (T5): a long bench in ivory nappa leather with deep channel quilting along its
    // top, on a polished champagne-gold plinth; under the seat an open, warmly lit shoe valet holding velvet slippers and a pair of tan loafers on a
    // walnut shelf; a slim gold touch strip on the end with heat and massage icons. Seats {+-34, 2, 30} kept. Live: warmth glows along the channel
    // seams and breathes, massage rollers ripple slowly along under the leather, and the valet light and touch icons pulse.
    N.valet30 = S => { const D = { w: 144, d: 50, act: 'sit', seats: [{ x: -34, z: 2, h: 30 }, { x: 34, z: 2, h: 30 }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('valet30'), k = C.k, id = C.u('v87'), W = 112, DD = 40, IV = '#f2ebe0', GD = '#d4b06a', PY = 3.4, BH = 15, SY = PY + BH, SH = 9;
        const plinth = box3(C, decC(C, { c: [0, 0, 0], w: W - 6, h: PY, d: DD - 6, col: GD, r: 1.6, gl: 0.3, dec: { f: `<rect width="${W - 6}" height="0.4" fill="#fff4d0"/>` } }));
        // valet niche on the front face: warm lit recess, walnut shelf, slippers + loafers
        const shoe = (x, col, low) => `<g transform="translate(${x} ${f1(BH - 3.4)})"><path d="M0 2.4Q0 0.6 2 0.4L7 0Q9.4 0 9.6 1.4L9.6 2.4Z" fill="${col}"/><path d="M0.6 2.4H9.4" stroke="#2a1a10" stroke-width="0.5"/>${low ? `<path d="M2 0.8q2 -0.6 4 -0.4" stroke="#fff4dc" stroke-width="0.25" fill="none" opacity="0.5"/>` : `<ellipse cx="7.4" cy="0.6" rx="1.6" ry="0.5" fill="#f4e8d8" opacity="0.6"/>`}</g>`;
        const nicheF = `<rect width="${W}" height="${BH}" fill="${IV}"/>` + linen(R, W, BH, '#ffffff', '#c8b8a0')
          + `<rect x="5" y="2.4" width="${W - 10}" height="${BH - 4}" rx="1.6" fill="#3a2a1e"/><rect x="5" y="2.4" width="${W - 10}" height="${BH - 4}" rx="1.6" fill="url(#${id}n)">${an('opacity', '0.75;1;0.75', 6, 0, SPL(2))}</rect>`
          + `<rect x="5" y="${f1(BH - 2.2)}" width="${W - 10}" height="0.8" fill="#7a4a28"/><rect x="6" y="2.6" width="${W - 12}" height="0.4" fill="#fff0c8" opacity="0.9"/>`
          + shoe(12, '#8a2a3a', 0) + shoe(22.6, '#8a2a3a', 0) + shoe(W - 38, '#a86a3a', 1) + shoe(W - 27, '#a86a3a', 1) + `<rect x="${f1(W / 2 - 6)}" y="${f1(BH - 4)}" width="12" height="1.6" rx="0.4" fill="#d8c8b0"/><path d="M${f1(W / 2 - 5)} ${f1(BH - 3.2)}h10" stroke="#a89878" stroke-width="0.2"/>`
          + `<path d="M0 0.5H${W}" stroke="${GD}" stroke-width="0.5"/>`;
        const bodyS = w => `<rect width="${w}" height="${BH}" fill="${IV}"/>` + linen(R, w, BH, '#ffffff', '#c8b8a0') + `<path d="M0 0.5H${w}" stroke="${GD}" stroke-width="0.5"/>`;
        const ctrl = w => bodyS(w) + `<rect x="${f1(w / 2 - 4)}" y="4" width="8" height="5" rx="1" fill="#2a2420"/>` + [[w / 2 - 2, 6.5, '♨'], [w / 2 + 2, 6.5, '≈']].map(([x, y, g], i) => `<text x="${f1(x)}" y="${f1(y + 0.6)}" text-anchor="middle" font-size="2" fill="${GD}">${g}<animate attributeName="opacity" values="0.5;1;0.5" dur="${3 + i}s" repeatCount="indefinite"/></text>`).join('');
        const body = box3(C, decC(C, { c: [0, PY, 0], w: W, h: BH, d: DD, col: IV, r: 2.4, dec: { f: nicheF, b: bodyS(W), l: ctrl(DD), r: bodyS(DD) } }));
        // quilted leather top: lengthwise channels, warm seams, massage ripple
        const NC = 6, cw = DD / NC;
        const top = `<rect width="${W}" height="${DD}" fill="${IV}"/>` + rep(NC, i => `<rect x="1" y="${f1(i * cw + 0.3)}" width="${W - 2}" height="${f1(cw - 0.6)}" rx="${f1(cw * 0.45)}" fill="url(#${id}q)"/>`).join('')
          + rep(NC - 1, i => `<path d="M2 ${f1((i + 1) * cw)}H${W - 2}" stroke="#ffb860" stroke-width="0.5" opacity="0.4" filter="url(#m12b1)">${an('opacity', '0.15;0.55;0.15', 7, -i * 0.6, SPL(2))}</path><path d="M2 ${f1((i + 1) * cw)}H${W - 2}" stroke="#b8a488" stroke-width="0.2" stroke-dasharray="0.6 0.4"/>`).join('')
          + rep(3, j => `<ellipse cx="0" cy="${f1(DD / 2)}" rx="5" ry="${f1(DD * 0.42)}" fill="#ffffff" opacity="0.18" filter="url(#m12b1)">${an('cx', `-8;${W + 8}`, 9, -j * 3)}</ellipse>`).join('');
        const seatS = w => `<rect width="${w}" height="${SH}" fill="${IV}"/><rect width="${w}" height="${SH}" fill="url(#${id}v)"/><path d="M0 0.6H${w}M0 ${f1(SH - 0.6)}H${w}" stroke="#d8ccb8" stroke-width="0.6"/><path d="M0 ${f1(SH - 0.3)}H${w}" stroke="${GD}" stroke-width="0.3"/>`;
        const seat = box3(C, decC(C, { c: [0, SY, 0], w: W + 1, h: SH, d: DD + 1, col: IV, r: 4, gl: 0.2, dec: { t: top, f: seatS(W + 1), b: seatS(W + 1), l: seatS(DD + 1), r: seatS(DD + 1) } }));
        const glow = PLN(C, 0.05, `<ellipse rx="${W * 0.55}" ry="${DD * 0.7}" fill="#ffd090" opacity="0.25" filter="url(#m11b4)">${an('opacity', '0.15;0.32;0.15', 7, 0, SPL(2))}</ellipse>`);
        let s = glow + shadow(C, 0, 0, W * 0.5, DD * 0.6, 0.4) + plinth + body + seat;
        C.p(-72, 0, 0); C.p(72, 0, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}q" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e2d6c4"/><stop offset="0.35" stop-color="#fffaf2"/><stop offset="0.7" stop-color="#f2e8da"/><stop offset="1" stop-color="#d6c8b2"/></linearGradient>`
          + `<linearGradient id="${id}v" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.25"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#5a4a30" stop-opacity="0.18"/></linearGradient>`
          + `<linearGradient id="${id}n" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd8a0" stop-opacity="0.75"/><stop offset="0.5" stop-color="#e8a868" stop-opacity="0.35"/><stop offset="1" stop-color="#3a2a1e" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-008 HALF-EMPTY WATER GLASS & PAPERBACK BOOK (T1): a well-thumbed paperback lying face-down and open, its cracked spine, dog-eared corners,
    // yellowed page edges and a coffee ring on the cover; beside it a cheap ribbed tumbler half full of yesterday's water with a few bubbles clinging to
    // the inside and a fingerprint smudge, sitting in its own wet ring. Live: a bubble lets go and rises and light shimmers through the water.
    N.glass30 = S => { const D = { w: 22, d: 22, small: 1, round: 1, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('glass30'), k = C.k, id = C.u('g08');
        // open face-down book: two cover halves tented slightly over the spine (box3 with tilted axes) + page block edge
        const th = 0.12, BW = 7.4, BD = 10.4;
        const cover = sg => { const ph = -sg * th, A = [[Math.cos(ph), Math.sin(ph), 0], [-Math.sin(ph), Math.cos(ph), 0], [0, 0, 1]];
          const c = [-2.4 + sg * (BW / 2 + 0.4) * Math.cos(th), 0.5 + (BW / 2) * Math.sin(th) * 0 , -1];
          return box3(C, decC(C, { c, ax: A, w: BW, h: 0.9, d: BD, col: sg < 0 ? '#2a5a7a' : '#2a5a7a', r: 0.1, dec: { t: `<rect width="${BW}" height="${BD}" fill="#2e6284"/>` + (sg > 0 ? `<text x="1" y="3" font-family="Georgia,serif" font-size="1.3" font-style="italic" fill="#f4d860">the long</text><text x="1" y="4.6" font-family="Georgia,serif" font-size="1.3" font-style="italic" fill="#f4d860">night</text><circle cx="5" cy="7.6" r="1.8" fill="none" stroke="#6a4a2a" stroke-width="0.35" opacity="0.5"/>` : `<text x="1" y="2.4" font-family="Arial" font-size="0.7" fill="#d8e4ec">"Impossible to put down"</text>` + rep(5, i => `<path d="M1 ${f1(4 + i * 1)}h${f1(4 + R() * 1.6)}" stroke="#c8d8e4" stroke-width="0.25"/>`).join('')) + `<path d="M${sg > 0 ? BW - 1.6 : 0} 0l1.6 0l${sg > 0 ? 0 : -1.6} 1.6Z" fill="#e8dcc0"/>`, f: `<rect width="${BW}" height="0.9" fill="#f2e8cc"/>` + rep(6, i => `<path d="M0 ${f1(0.15 + i * 0.13)}H${BW}" stroke="#c8b890" stroke-width="0.04"/>`).join('') } })); };
        const spine = box3(C, decC(C, { c: [-2.4, 0, -1], w: 1.2, h: 1.6, d: BD, col: '#24506e', r: 0.3, dec: { t: rep(5, i => `<path d="M0.2 ${f1(1 + i * 2)}h0.8" stroke="#8aa8c0" stroke-width="0.12"/>`).join('') } }));
        const book = shadow(C, -2.4, -1, 9, 6.4, 0.45) + (C.v[0] > 0 ? cover(-1) + spine + cover(1) : cover(1) + spine + cover(-1));
        // glass
        const GX = 5.6, GZ = 5, GR = 2.6, GH = 8.6, WL = 4.2;
        const ring = PLN(C, 0.05, `<circle cx="${GX}" cy="${GZ}" r="${GR + 0.4}" fill="none" stroke="#9ab0b8" stroke-width="0.3" opacity="0.5"/><ellipse cx="${GX + 0.8}" cy="${GZ + 0.4}" rx="${GR + 0.6}" ry="${GR}" fill="#c8dce4" opacity="0.25"/>`);
        const gb = cyl3(C, [GX, 0, GZ], [GX, GH, GZ], GR * 0.92, '#dfeaee', { r2: GR, op: 0.3, olw: 0.25, noCap: 1 });
        const water = cyl3(C, [GX, 0.4, GZ], [GX, WL, GZ], GR * 0.88, '#c8e0ea', { r2: GR * 0.94, op: 0.55, olw: 0, capCol: '#e4f2f6' });
        const ribs = rep(10, i => { const a = C.thV - PI / 2 + (i + 0.5) / 10 * PI, p0 = C.P([GX + GR * 0.93 * Math.sin(a), 0.6, GZ + GR * 0.93 * Math.cos(a)]), p1 = C.P([GX + GR * Math.sin(a), GH - 1.2, GZ + GR * Math.cos(a)]); return `<path d="M${P2(p0)}L${P2(p1)}" stroke="#ffffff" stroke-width="${f1(0.18 * k)}" opacity="0.4"/>`; }).join('');
        const rim = (() => { const P = rep(33, i => { const a = i / 32 * 2 * PI; return C.P([GX + GR * Math.sin(a), GH, GZ + GR * Math.cos(a)]); }); return `<path d="M${P.map(P2).join('L')}Z" fill="none" stroke="#f4fafc" stroke-width="${f1(0.3 * k)}" opacity="0.9"/>`; })();
        const bubs = rep(6, () => { const a = C.thV + (R() - 0.5) * 2, y = 0.8 + R() * 3, p = C.P([GX + GR * 0.8 * Math.sin(a), y, GZ + GR * 0.8 * Math.cos(a)]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1((0.12 + R() * 0.12) * k)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.06 * k)}" opacity="0.8"/>`; }).join('');
        const rise = (() => { const a = C.P([GX + 0.6, 1, GZ + 0.6]), b = C.P([GX + 0.6, WL, GZ + 0.6]); return `<circle cx="${f1(a[0])}" cy="${f1(a[1])}" r="${f1(0.2 * k)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.07 * k)}" opacity="0">${an('opacity', '0;0;0.9;0.9;0', 7, 0, KT('0;0.6;0.65;0.9;1'))}${an('cy', `${f1(a[1])};${f1(a[1])};${f1(a[1])};${f1(b[1])};${f1(b[1])}`, 7, 0, KT('0;0.6;0.65;0.9;1'))}</circle>`; })();
        const shim = (() => { const p = C.P([GX, WL * 0.5, GZ + GR * 0.7]); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(1.2 * k)}" ry="${f1(0.5 * k)}" fill="#ffffff" opacity="0.4">${an('opacity', '0.2;0.6;0.3;0.5;0.2', 3, 0, SPL(4))}</ellipse>`; })();
        const smudge = (() => { const p = C.P([GX - 1, 6.4, GZ + GR]); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(0.7 * k)}" ry="${f1(0.9 * k)}" fill="#ffffff" opacity="0.25"/>`; })();
        const gl = shadow(C, GX, GZ, 3.2, 3.2, 0.3) + water + bubs + rise + shim + gb + ribs + smudge + rim;
        let s = ring + vs(C, [{ q: [-2.4, 0, -1], s: book }, { q: [GX, 0, GZ], s: gl }]);
        C.p(-11, 0, 0); C.p(11, 0, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-028 CERAMIC RING CONE, SLEEP MASK & LAVENDER PILLOW SPRAY (T2): a little hand-thrown cone on a saucer in speckled oatmeal glaze with two rings
    // stacked on it (a thin gold band and a silver one with a tiny stone), a dusty-rose satin sleep mask with a ruffled edge and its elastic in a loop,
    // and a frosted lilac glass bottle of lavender pillow spray with a silver pump and a kraft label printed with a lavender sprig. Live: now and then a
    // fine puff of mist drifts from the sprayer, and the rings glint.
    N.cone30 = S => { const D = { w: 34, d: 20, small: 1, round: 0, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('cone30'), k = C.k, id = C.u('c28');
        // ring cone + saucer
        const CX = -9, CZ = -1;
        const speck = rr => rep(18, () => { const a = R() * 2 * PI, r = R() * rr; return `<circle cx="${f1(Math.cos(a) * r)}" cy="${f1(Math.sin(a) * r)}" r="0.12" fill="#6a5a44"/>`; }).join('');
        let cone = cyl3(C, [CX, 0, CZ], [CX, 0.9, CZ], 4.2, '#e6dcc8', { r2: 4.6, olw: 0.3, cap: rr => `<circle r="${f1(rr)}" fill="#e8dec8"/>` + speck(rr) + `<circle r="${f1(rr * 0.85)}" fill="none" stroke="#c8b898" stroke-width="0.2"/>` })
          + cyl3(C, [CX, 0.9, CZ], [CX, 8.4, CZ], 2.2, '#ece2ce', { r2: 0.35, mat: 'gloss', olw: 0.3 });
        const ringAt = (y, r, col, stone) => { const P = rep(33, i => { const a = i / 32 * 2 * PI; return C.P([CX + r * Math.sin(a), y + 0.25 * Math.cos(a * 1), CZ + r * Math.cos(a)]); }); return `<path d="M${P.map(P2).join('L')}Z" fill="none" stroke="${col}" stroke-width="${f1(0.45 * k)}"/><path d="M${P.map(P2).join('L')}Z" fill="none" stroke="#ffffff" stroke-width="${f1(0.12 * k)}" opacity="0.6" stroke-dasharray="${f1(1 * k)} ${f1(6 * k)}"><animate attributeName="stroke-dashoffset" values="0;${f1(-14 * k)}" dur="4s" repeatCount="indefinite"/></path>` + (stone ? (() => { const p = C.P([CX + r * Math.sin(C.thV), y + 0.3, CZ + r * Math.cos(C.thV)]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.4 * k)}" fill="#d8e8f4" stroke="#8a9aa8" stroke-width="${f1(0.06 * k)}"/>`; })() : ''); };
        cone += ringAt(3.4, 1.55, '#d8b058', 0) + ringAt(5, 1.05, '#c8ccd0', 1);
        // sleep mask (flat on the surface, plane decal)
        const MX = 2, MZ = 3;
        const mask = PLN(C, 0.6, `<g transform="translate(${MX} ${MZ}) rotate(-8)"><ellipse cx="0.3" cy="0.4" rx="8.4" ry="4" fill="#000000" opacity="0.15" filter="url(#m12b1)"/>`
          + `<path d="M-8 0Q-8 -3.6 -3.6 -3.4Q0 -3.2 0 -1.8Q0 -3.2 3.6 -3.4Q8 -3.6 8 0Q8 3.4 3.6 3.4Q1 3.4 0 1.6Q-1 3.4 -3.6 3.4Q-8 3.4 -8 0Z" fill="#d8a8a4"/>`
          + `<path d="M-8 0Q-8 -3.6 -3.6 -3.4Q0 -3.2 0 -1.8Q0 -3.2 3.6 -3.4Q8 -3.6 8 0Q8 3.4 3.6 3.4Q1 3.4 0 1.6Q-1 3.4 -3.6 3.4Q-8 3.4 -8 0Z" fill="none" stroke="#e8c4c0" stroke-width="0.7" stroke-dasharray="0.5 0.3"/>`
          + `<ellipse cx="-3.6" cy="-0.4" rx="2.6" ry="1.4" fill="#ffffff" opacity="0.25"/><ellipse cx="3.6" cy="-0.4" rx="2.6" ry="1.4" fill="#ffffff" opacity="0.2"/><path d="M-6 0.6q2 1.2 4 0M2 0.6q2 1.2 4 0" stroke="#b88884" stroke-width="0.25" fill="none"/>`
          + `<path d="M-8 -0.6Q-9.6 -4 -5 -4.4Q0 -5 5 -4.4Q9.6 -4 8 -0.6" stroke="#c89894" stroke-width="0.6" fill="none"/></g>`);
        // lavender spray bottle
        const BX = 12, BZ = -3;
        const bottle = cyl3(C, [BX, 0, BZ], [BX, 7.6, BZ], 2.3, '#c8b4dc', { op: 0.85, mat: 'gloss', olw: 0.3, noCap: 1 }) + cyl3(C, [BX, 0.3, BZ], [BX, 5.4, BZ], 2.1, '#a888c8', { op: 0.45, olw: 0 })
          + cyl3(C, [BX, 7.6, BZ], [BX, 8.6, BZ], 1, '#c8ccd0', { mat: 'chrome', olw: 0.25 }) + cyl3(C, [BX, 8.6, BZ], [BX, 10.4, BZ], 0.8, '#d8dce0', { mat: 'chrome', olw: 0.25 })
          + (() => { const a = C.P([BX, 9.8, BZ]); return `<rect x="${f1(a[0] + 0.6 * k)}" y="${f1(a[1] - 0.25 * k)}" width="${f1(0.8 * k)}" height="${f1(0.5 * k)}" fill="#b8bcc0"/>`; })()
          + (C.v[2] > -0.2 ? (() => { const p = C.P([BX - 1.6, 5.4, BZ + 2.3]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><rect width="3.2" height="3.4" rx="0.2" fill="#d8c4a0"/><path d="M1.6 3L1.6 0.8" stroke="#6a7a4a" stroke-width="0.12"/>${rep(5, i => `<ellipse cx="${f1(1.6 + (i % 2 ? 0.25 : -0.25))}" cy="${f1(0.9 + i * 0.3)}" rx="0.2" ry="0.14" fill="#8a6ab0"/>`).join('')}<text x="1.6" y="3.1" text-anchor="middle" font-size="0.4" font-family="Georgia,serif" fill="#3a3028">lavender</text></g>`; })() : '');
        const mist = (() => { const a = C.P([BX + 1.6, 9.8, BZ]); return `<g opacity="0">${an('opacity', '0;0;0.7;0', 9, 0, KT('0;0.8;0.85;1'))}<ellipse cx="${f1(a[0] + 2 * k)}" cy="${f1(a[1])}" rx="${f1(2.2 * k)}" ry="${f1(1 * k)}" fill="url(#m10mst)"><animate attributeName="cx" values="${f1(a[0] + 1 * k)};${f1(a[0] + 1 * k)};${f1(a[0] + 2 * k)};${f1(a[0] + 6 * k)}" keyTimes="0;0.8;0.85;1" dur="9s" repeatCount="indefinite"/></ellipse></g>`; })();
        const items = [{ q: [CX, 3, CZ], s: shadow(C, CX, CZ, 5, 5, 0.35) + cone }, { q: [BX, 4, BZ], s: shadow(C, BX, BZ, 3, 3, 0.35) + bottle + mist }];
        let s = mask + vs(C, items);
        C.p(-17, 0, 0); C.p(17, 0, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // faceted glass helper: vertical facet lines + glints on the visible half of a cylinder band
    const facets = (C, x, z, y0, y1, r0, r1, n, ph) => { let o = ''; for (let i = 0; i < n; i++) { const a = i / n * 2 * PI + (ph || 0); if (Math.cos(a - C.thV) < 0.05) continue; const p0 = C.P([x + r0 * Math.sin(a), y0, z + r0 * Math.cos(a)]), p1 = C.P([x + r1 * Math.sin(a), y1, z + r1 * Math.cos(a)]);
      o += `<path d="M${P2(p0)}L${P2(p1)}" stroke="${i % 2 ? '#ffffff' : '#9ab4c4'}" stroke-width="${f1((i % 2 ? 0.16 : 0.1) * C.k)}" opacity="${i % 2 ? 0.75 : 0.5}"/>`; } return o; };

    // BED-048 CRYSTAL CARAFE SET, LEATHER JOURNAL & BRASS BOOKMARK (T3): a cut-crystal night carafe with its tumbler upturned over the neck, half full of
    // water, standing on a little round brass tray; beside it a tan pebbled-leather journal with a wrap tie, gilt-edged pages and a slim brass leaf
    // bookmark peeking out on a silk tassel. Live: light catches the crystal facets in turn and the bookmark's tassel sways.
    N.carafe30 = S => { const D = { w: 32, d: 24, small: 1, round: 0, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('carafe30'), k = C.k, id = C.u('k48');
        const CX = -8, CZ = 0;
        const tray = cyl3(C, [CX, 0, CZ], [CX, 0.7, CZ], 6.2, '#d4b06a', { mat: 'metal', olw: 0.3, cap: rr => `<circle r="${f1(rr * 0.86)}" fill="#c8a058"/><circle r="${f1(rr * 0.86)}" fill="none" stroke="#fff0c0" stroke-width="0.3" opacity="0.7"/>` });
        const body = cyl3(C, [CX, 0.7, CZ], [CX, 6, CZ], 3.6, '#e4eef2', { r2: 3.8, op: 0.42, olw: 0.3, noCap: 1 }) + cyl3(C, [CX, 6, CZ], [CX, 9.6, CZ], 3.8, '#e4eef2', { r2: 1.3, op: 0.42, olw: 0.3, noCap: 1 }) + cyl3(C, [CX, 9.6, CZ], [CX, 12, CZ], 1.3, '#e4eef2', { op: 0.42, olw: 0.3, noCap: 1 });
        const water = cyl3(C, [CX, 1, CZ], [CX, 4.6, CZ], 3.4, '#bcd8e4', { r2: 3.55, op: 0.5, olw: 0, capCol: '#dcecf2' });
        const tumbler = cyl3(C, [CX, 14.8, CZ], [CX, 10.6, CZ], 2.2, '#e8f0f4', { r2: 2, op: 0.5, olw: 0.3, capCol: '#f4f8fa' });
        const fac = facets(C, CX, CZ, 0.9, 5.8, 3.62, 3.82, 16) + facets(C, CX, CZ, 10.8, 14.6, 2.02, 2.22, 12, 0.13);
        const glint = rep(3, i => { const a = C.thV + (i - 1) * 0.6, p = C.P([CX + 3.8 * Math.sin(a), 3 + i * 2.6, CZ + 3.8 * Math.cos(a)]); return `<path d="M${f1(p[0] - 0.8 * k)} ${f1(p[1])}H${f1(p[0] + 0.8 * k)}M${f1(p[0])} ${f1(p[1] - 0.8 * k)}V${f1(p[1] + 0.8 * k)}" stroke="#ffffff" stroke-width="${f1(0.14 * k)}" opacity="0">${an('opacity', '0;1;0', 5, -i * 1.6, SPL(2))}</path>`; }).join('');
        const carafe = shadow(C, CX, CZ, 6.6, 6.6, 0.3) + tray + water + body + fac + tumbler + glint;
        // leather journal + wrap tie + brass bookmark
        const JX = 7, JZ = 1, JW = 11, JD = 15, JH = 2.4;
        const peb = (w, d) => `<rect width="${w}" height="${d}" fill="#a8703e"/>` + rep(Math.round(w * d / 1.2), () => `<circle cx="${f1(R() * w)}" cy="${f1(R() * d)}" r="${f1(0.12 + R() * 0.15)}" fill="${R() < 0.5 ? '#8a5a2e' : '#c48a52'}" opacity="0.6"/>`).join('') + `<rect x="0.6" y="0.6" width="${f1(w - 1.2)}" height="${f1(d - 1.2)}" fill="none" stroke="#e8c49a" stroke-width="0.18" stroke-dasharray="0.4 0.3" opacity="0.8"/>`;
        const pages = w => `<rect width="${w}" height="${JH}" fill="#a8703e"/><rect y="0.4" width="${w}" height="${f1(JH - 0.8)}" fill="#e8d498"/>` + rep(6, i => `<path d="M0 ${f1(0.6 + i * 0.22)}H${w}" stroke="#c8a048" stroke-width="0.05"/>`).join('');
        const jour = box3(C, decC(C, { c: [JX, 0, JZ], w: JW, h: JH, d: JD, col: '#a8703e', r: 0.6, dec: { t: peb(JW, JD) + `<path d="M0 ${f1(JD * 0.55)}H${JW}" stroke="#5a3218" stroke-width="0.45"/><circle cx="${f1(JW - 1.4)}" cy="${f1(JD * 0.55)}" r="0.5" fill="#d4b06a"/>`, f: pages(JW), r: pages(JD), l: `<rect width="${JD}" height="${JH}" fill="#8a5a2e"/>`, b: pages(JW) } }));
        const bm = (() => { const a = C.P([JX + 2, JH, JZ - JD / 2 + 0.2]), b = C.P([JX + 2, JH + 4, JZ - JD / 2 - 0.8]); return `<path d="M${P2(a)}L${P2(b)}" stroke="#d4b06a" stroke-width="${f1(0.9 * k)}" stroke-linecap="round"/><ellipse cx="${f1(b[0])}" cy="${f1(b[1])}" rx="${f1(1.2 * k)}" ry="${f1(0.7 * k)}" fill="#e2c07a" transform="rotate(-50 ${P2(b)})"/><g>${at('rotate', `-8 ${P2(b)};8 ${P2(b)};-8 ${P2(b)}`, 3.6, 0, SPL(2))}<path d="M${P2(b)}q${f1(0.6 * k)} ${f1(2 * k)} ${f1(-0.2 * k)} ${f1(4 * k)}" stroke="#7a2a3a" stroke-width="${f1(0.35 * k)}" fill="none"/><path d="M${f1(b[0] - 0.2 * k)} ${f1(b[1] + 4 * k)}l${f1(-0.4 * k)} ${f1(1.4 * k)}M${f1(b[0] - 0.2 * k)} ${f1(b[1] + 4 * k)}l${f1(0.4 * k)} ${f1(1.4 * k)}" stroke="#9a3a4a" stroke-width="${f1(0.25 * k)}"/></g>`; })();
        const journal = shadow(C, JX, JZ, 7, 9, 0.35) + jour + bm;
        let s = vs(C, [{ q: [CX, 5, CZ], s: carafe }, { q: [JX, 1, JZ], s: journal }]);
        C.p(-16, 0, 0); C.p(16, 0, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-068 WOODEN MECHANICAL WATCH WINDER, SILK EYE MASK & ARTISANAL CANDLE (T4): a burl-walnut watch winder with a bevelled glass lid and a brass
    // hinge, a gold automatic watch on a cream suede cushion inside; a folded champagne silk eye mask; an amber glass candle vessel with a cork-cream
    // label and a crackling wooden wick. glow {30, 34} kept. Live: the winder cushion turns the watch slowly, the candle flame flickers and the wood
    // wick sends up a thin wisp.
    N.winder30 = S => { const D = { w: 32, d: 22, small: 1, round: 0, glow: () => ({ y: 30, r: 34 }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('winder30'), k = C.k, id = C.u('w68');
        const WX = -6, WZ = -1, BW = 12, BD = 10, BH = 9;
        const burl = (w, h) => `<rect width="${w}" height="${h}" fill="#6a4228"/>` + rep(14, () => { const x = R() * w, y = R() * h, r = 0.4 + R() * 1.4; return `<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(r)}" ry="${f1(r * 0.7)}" fill="none" stroke="${R() < 0.5 ? '#4a2a14' : '#9a6a40'}" stroke-width="0.18" opacity="0.7"/>`; }).join('') + grainH(R, w, h, 6, '#3a2010', 0.4);
        const box = box3(C, decC(C, { c: [WX, 0, WZ], w: BW, h: BH, d: BD, col: '#6a4228', r: 0.6, gl: 0.25, dec: { f: burl(BW, BH) + `<rect x="${f1(BW / 2 - 1.4)}" y="${f1(BH - 3)}" width="2.8" height="1.4" rx="0.3" fill="#d4b06a"/>`, l: burl(BD, BH), r: burl(BD, BH), b: burl(BW, BH) } }));
        // inside, seen through the glass lid: suede cushion + watch turning
        const cc = C.P([WX, BH + 0.85, WZ + 0.2]);
        const watch = `<g transform="translate(${P2(cc)}) scale(${n4(k)})"><ellipse rx="4.4" ry="3.3" fill="#e8dcc4"/><ellipse rx="4.4" ry="3.3" fill="url(#${id}c)"/><g>${at('rotate', '0;360', 20)}<rect x="-1.2" y="-3" width="2.4" height="6" rx="0.8" fill="#8a5a2e"/><circle r="1.9" fill="#d8b058" stroke="#8a6a2a" stroke-width="0.2"/><circle r="1.5" fill="#f4ecd8"/>${rep(12, i => `<path d="M${f1(Math.sin(i * PI / 6) * 1.2)} ${f1(-Math.cos(i * PI / 6) * 1.2)}L${f1(Math.sin(i * PI / 6) * 1.4)} ${f1(-Math.cos(i * PI / 6) * 1.4)}" stroke="#3a2a1a" stroke-width="0.08"/>`).join('')}<path d="M0 0L0 -1.1M0 0L0.8 0.3" stroke="#2a1a10" stroke-width="0.12"/></g></g>`;
        const lid = box3(C, decC(C, { c: [WX, BH, WZ], w: BW + 0.4, h: 0.8, d: BD + 0.4, col: '#5a3820', r: 0.6, dec: { t: `<rect width="${BW + 0.4}" height="${BD + 0.4}" fill="#5a3820"/><rect x="1.2" y="1.2" width="${f1(BW - 2)}" height="${f1(BD - 2)}" fill="#cfe0e8" opacity="0.18"/><path d="M1.2 1.2L${f1(BW - 0.8)} ${f1(BD - 0.8)}" stroke="#ffffff" stroke-width="0.3" opacity="0.4"/>` } }));
        // candle: amber vessel, label, wax, wood wick + flame
        const CX = 9, CZ = -2;
        const cand = cyl3(C, [CX, 0, CZ], [CX, 7.4, CZ], 3.4, '#a8601e', { op: 0.85, mat: 'gloss', olw: 0.3, cap: rr => `<circle r="${f1(rr * 0.9)}" fill="#efe4cc"/><circle r="${f1(rr * 0.9)}" fill="url(#${id}w)"/>` })
          + (C.v[2] > -0.2 ? (() => { const p = C.P([CX - 2.2, 4.6, CZ + 3.3]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><rect width="4.4" height="2.6" rx="0.2" fill="#ece0c4"/><text x="2.2" y="1.2" text-anchor="middle" font-size="0.62" font-family="Georgia,serif" fill="#3a2a1a">FIG &amp; CEDAR</text><text x="2.2" y="2.1" text-anchor="middle" font-size="0.4" font-family="Georgia,serif" fill="#7a6a4a">hand poured</text></g>`; })() : '');
        const fp = C.P([CX, 7.5, CZ]);
        const flame = `<circle cx="${f1(fp[0])}" cy="${f1(fp[1] - 1.4 * k)}" r="${f1(5 * k)}" fill="#ffb860" opacity="0.3" filter="url(#m11b4)">${an('opacity', '0.22;0.38;0.25;0.36;0.22', 2.4, 0, SPL(4))}</circle><rect x="${f1(fp[0] - 0.7 * k)}" y="${f1(fp[1] - 0.6 * k)}" width="${f1(1.4 * k)}" height="${f1(0.5 * k)}" fill="#3a2a1a"/>`
          + `<g transform="translate(${f1(fp[0])} ${f1(fp[1] - 0.6 * k)}) scale(${n4(k)})"><path d="M0 0Q-1.4 -1.4 0 -3.6Q1.4 -1.4 0 0Z" fill="#ffb648"><animate attributeName="d" values="M0 0Q-1.4 -1.4 0 -3.6Q1.4 -1.4 0 0Z;M0 0Q-1.2 -1.6 0.3 -3.9Q1.3 -1.3 0 0Z;M0 0Q-1.5 -1.3 -0.2 -3.4Q1.4 -1.5 0 0Z;M0 0Q-1.4 -1.4 0 -3.6Q1.4 -1.4 0 0Z" dur="1.6s" repeatCount="indefinite"/></path><path d="M0 -0.2Q-0.6 -1 0 -2.2Q0.6 -1 0 -0.2Z" fill="#fff4c8"/></g>`
          + `<path d="M${f1(fp[0])} ${f1(fp[1] - 4.4 * k)}q${f1(-1 * k)} ${f1(-2 * k)} 0 ${f1(-4 * k)}q${f1(1 * k)} ${f1(-2 * k)} 0 ${f1(-4 * k)}" stroke="#d8d0c4" stroke-width="${f1(0.25 * k)}" fill="none" opacity="0">${an('opacity', '0;0.5;0', 5)}</path>`;
        // silk eye mask folded in front
        const mask = PLN(C, 0.5, `<g transform="translate(1 7) rotate(6)"><ellipse cx="0.2" cy="0.4" rx="6" ry="2.6" fill="#000" opacity="0.12" filter="url(#m12b1)"/><path d="M-6 0Q-6 -2.6 -2.6 -2.4Q0 -2.2 0 -1.2Q0 -2.2 2.6 -2.4Q6 -2.6 6 0Q6 2.4 2.6 2.4Q0.8 2.4 0 1.2Q-0.8 2.4 -2.6 2.4Q-6 2.4 -6 0Z" fill="#e8d4b0"/><path d="M-5 -0.4Q-2.6 -1.6 0 -0.6Q2.6 -1.6 5 -0.4" stroke="#fff8e8" stroke-width="0.8" fill="none" opacity="0.6"/><path d="M-6 0Q-6 -2.6 -2.6 -2.4Q0 -2.2 0 -1.2Q0 -2.2 2.6 -2.4Q6 -2.6 6 0" stroke="#c8b088" stroke-width="0.2" fill="none"/></g>`);
        let s = mask + vs(C, [{ q: [WX, 4, WZ], s: shadow(C, WX, WZ, 7.4, 6.4, 0.35) + box + lid + watch + PLN(C, BH + 0.9, `<g transform="translate(${WX} ${WZ})"><rect x="${f1(-BW / 2 + 1)}" y="${f1(-BD / 2 + 1)}" width="${f1(BW - 2)}" height="${f1(BD - 2)}" fill="#d8e8f0" opacity="0.16"/><path d="M${f1(-BW / 2 + 1.4)} ${f1(-BD / 2 + 1.4)}L${f1(-BW / 2 + 5)} ${f1(BD / 2 - 1.4)}" stroke="#ffffff" stroke-width="0.5" opacity="0.5"/><rect x="${f1(-BW / 2 + 1)}" y="${f1(-BD / 2 + 1)}" width="${f1(BW - 2)}" height="${f1(BD - 2)}" fill="none" stroke="#c8a058" stroke-width="0.3"/></g>`) }, { q: [CX, 3, CZ], s: shadow(C, CX, CZ, 4, 4, 0.35) + cand + flame }]);
        C.p(-16, 0, 0); C.p(16, 0, 0); C.p(CX, 16, CZ);
        return { defs: DEF19 + `<defs><radialGradient id="${id}c" cx="45%" cy="40%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="1" stop-color="#8a7a5a" stop-opacity="0.3"/></radialGradient><radialGradient id="${id}w"><stop offset="0" stop-color="#d8c8a8"/><stop offset="0.35" stop-color="#efe4cc" stop-opacity="0"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-088 LEVITATING DREAM-CRYSTAL ORB & SMART HYDRATION ELIXIRS (T5): a faceted rose-quartz crystal orb floating over a black onyx and gold base
    // whose ring glows warm, a soft light inside the crystal; beside it a gold rack holding three slim glass elixir vials (amber chamomile, rose,
    // pale gold honey) with glowing level marks. Live: the crystal floats, turns and sparkles, the base ring breathes and tiny bubbles rise in the vials.
    N.elix30 = S => { const D = { w: 26, d: 26, small: 1, round: 1, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('elix30'), k = C.k, id = C.u('x88');
        const BX = -4, BZ = 0, OY = 12, OR = 3.8;
        const base = cyl3(C, [BX, 0, BZ], [BX, 2, BZ], 4.4, '#1e1c22', { mat: 'gloss', olw: 0.3 }) + cyl3(C, [BX, 2, BZ], [BX, 2.5, BZ], 4.2, '#d4b06a', { mat: 'metal', olw: 0.25, cap: rr => `<circle r="${f1(rr * 0.65)}" fill="#2a2024"/><circle r="${f1(rr * 0.65)}" fill="none" stroke="#ffc888" stroke-width="0.5">${an('opacity', '0.4;1;0.4', 5, 0, SPL(2))}</circle>` });
        const oc = C.P([BX, OY, BZ]), r = OR * k;
        const gem = rep(8, i => { const a0 = i / 8 * 2 * PI, a1 = (i + 1) / 8 * 2 * PI; return `<path d="M0 ${f1(-r)}L${f1(Math.cos(a0) * r)} ${f1(Math.sin(a0) * r * 0.3)}L${f1(Math.cos(a1) * r)} ${f1(Math.sin(a1) * r * 0.3)}Z" fill="${['#f4c0c8', '#e8a0b0', '#f8d4d8', '#d890a4'][i % 4]}" opacity="0.92"/><path d="M0 ${f1(r)}L${f1(Math.cos(a0) * r)} ${f1(Math.sin(a0) * r * 0.3)}L${f1(Math.cos(a1) * r)} ${f1(Math.sin(a1) * r * 0.3)}Z" fill="${['#d890a4', '#f4c0c8', '#c87890', '#e8a0b0'][i % 4]}" opacity="0.92"/>`; }).join('');
        const orb = `<circle cx="${f1(oc[0])}" cy="${f1(oc[1])}" r="${f1(r * 2.4)}" fill="#ffc0c8" opacity="0.3" filter="url(#m11b4)">${an('opacity', '0.2;0.4;0.2', 6, 0, SPL(2))}</circle>`
          + `<g>${at('translate', `0 0;0 ${f1(-1 * k)};0 0`, 5, 0, SPL(2))}<g transform="translate(${P2(oc)})"><g>${at('scale', '1 1;-1 1;1 1', 12, 0, SPL(2))}${gem}</g><circle r="${f1(r * 0.35)}" fill="#fff4f0" opacity="0.6" filter="url(#m12b1)">${an('opacity', '0.4;0.85;0.4', 4, 0, SPL(2))}</circle>`
          + rep(4, i => `<path d="M${f1((R() - 0.5) * r)} ${f1((R() - 0.5) * r)}m-0.8 0h1.6m-0.8 -0.8v1.6" stroke="#ffffff" stroke-width="0.2" opacity="0">${an('opacity', '0;1;0', n4(2 + R() * 2), n4(-R() * 3), SPL(2))}</path>`).join('') + '</g></g>';
        // vial rack: gold base + rail, 3 vials
        const VX = 7, VZ = 1, cols = ['#d8902a', '#e88aa0', '#f0c860'];
        let rack = box3(C, { c: [VX, 0, VZ], w: 10, h: 1.2, d: 4, col: '#d4b06a', r: 0.5, gl: 0.3 }) + box3(C, { c: [VX, 6, VZ], w: 10, h: 0.6, d: 4, col: '#d4b06a', r: 0.3, gl: 0.3 });
        [-3, 0, 3].forEach((dx, i) => { const x = VX + dx, h = 4 + i * 0.6;
          rack += cyl3(C, [x, 1.2, VZ], [x, 1.2 + h, VZ], 0.95, cols[i], { op: 0.75, olw: 0, capCol: shade(cols[i], 1.2) }) + cyl3(C, [x, 1.2, VZ], [x, 9.4, VZ], 1.05, '#e8f0f4', { op: 0.3, olw: 0.25, noCap: 1 }) + cyl3(C, [x, 9.4, VZ], [x, 10.6, VZ], 0.9, '#d4b06a', { mat: 'metal', olw: 0.2 })
            + (() => { const a = C.P([x, 1.6, VZ + 1]), b = C.P([x, 1.2 + h, VZ + 1]); return `<circle cx="${f1(a[0])}" cy="${f1(a[1])}" r="${f1(0.15 * k)}" fill="#ffffff" opacity="0">${an('opacity', '0;0.9;0', n4(2.4 + i * 0.5), n4(-i))}${an('cy', `${f1(a[1])};${f1(b[1])}`, n4(2.4 + i * 0.5), n4(-i))}</circle>` + [0.3, 0.6].map(f => { const m = C.P([x + 1.05, 1.2 + h * f + 1.2, VZ]); return `<path d="M${f1(m[0] - 0.4 * k)} ${f1(m[1])}h${f1(0.6 * k)}" stroke="#fff0c0" stroke-width="${f1(0.12 * k)}" opacity="0.8"/>`; }).join(''); })(); });
        let s = vs(C, [{ q: [BX, 3, BZ], s: shadow(C, BX, BZ, 5, 5, 0.35) + base + orb }, { q: [VX, 4, VZ], s: shadow(C, VX, VZ, 6.4, 3.4, 0.35) + rack }]);
        C.p(-13, 0, 0); C.p(13, 0, 0); C.p(BX, OY + 6, BZ);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // soft reflection of the bedroom for a W x H mirror: wall gradient, a bright window with mullions, a floor band, a lamp bloom, sheen streaks
    const refl30 = (id, W, H, o) => { o = o || {}; const wy = H * 0.12, ww = W * 0.34, wh = H * 0.34, wx = W * (o.wx == null ? 0.52 : o.wx);
      return `<defs><linearGradient id="${id}r" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${o.top || '#d8d0e2'}"/><stop offset="0.68" stop-color="${o.mid || '#c8bcd4'}"/><stop offset="0.7" stop-color="${o.floor || '#a88a68'}"/><stop offset="1" stop-color="${shade(o.floor || '#a88a68', 0.8)}"/></linearGradient></defs>`
        + `<rect width="${W}" height="${H}" fill="url(#${id}r)"/><g filter="url(#m12b1)" opacity="0.85"><rect x="${f1(wx)}" y="${f1(wy)}" width="${f1(ww)}" height="${f1(wh)}" fill="#fbf6ea"/><path d="M${f1(wx + ww / 2)} ${f1(wy)}V${f1(wy + wh)}M${f1(wx)} ${f1(wy + wh / 2)}H${f1(wx + ww)}" stroke="#b8a888" stroke-width="${f1(W * 0.02)}"/></g>`
        + `<ellipse cx="${f1(W * 0.2)}" cy="${f1(H * 0.55)}" rx="${f1(W * 0.2)}" ry="${f1(H * 0.08)}" fill="#ffe0a8" opacity="0.35" filter="url(#m12b1)"/>`
        + rep(Math.round(W / 4), i => `<path d="M${f1(i * 4 + 2)} ${f1(H * 0.7)}L${f1(i * 4 + 2 + (i * 4 - W / 2) * 0.3)} ${H}" stroke="#7a5a3a" stroke-width="0.2" opacity="0.4"/>`).join('')
        + `<path d="M${f1(W * 0.1)} 0H${f1(W * 0.3)}L${f1(W * 0.06)} ${H}H0V${f1(H * 0.5)}Z" fill="#ffffff" opacity="0.16"/><path d="M${f1(W * 0.4)} 0H${f1(W * 0.46)}L${f1(W * 0.22)} ${H}H${f1(W * 0.16)}Z" fill="#ffffff" opacity="0.1"/>`; };

    // BED-011 OVER-THE-DOOR NARROW PLASTIC-FRAME MIRROR (T1): a tall narrow budget mirror in a yellowed white plastic frame hung on two bent wire hooks,
    // its thin acrylic glass warping the reflection, a photo-booth strip tucked into one corner, a dusty smudge, a peeled price sticker and a corner of
    // the frame cracked and held with clear tape. Wall piece (w 60, elev 36) kept. Live: the flexible glass makes the reflection wobble now and then.
    N.door30 = S => { const D = { w: 60, d: 8, mount: 'wall', elev: 36, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('door30'), id = C.u('m11'), MW = 16, MH = 52, F = 1.4, { WD } = RD.H12, { ext } = RD.H11;
        ext(C, [[-MW / 2 - 2, MH + 4, 0], [MW / 2 + 2, -1, 0], [MW / 2 + 2, -1, 2]]);
        const gw = MW - 2 * F, gh = MH - 2 * F, wob = `<animateTransform attributeName="transform" type="skewX" values="0;0;1.6;-1.2;0.6;0;0" keyTimes="0;0.7;0.75;0.8;0.85;0.9;1" dur="8s" repeatCount="indefinite"/>`;
        const glass = `<clipPath id="${id}k"><rect x="${F}" y="${F}" width="${f1(gw)}" height="${f1(gh)}"/></clipPath><g clip-path="url(#${id}k)"><g transform="translate(${F} ${F})"><g>${wob}${refl30(id, gw, gh, { wx: 0.35 })}</g></g></g>`;
        const face = `<rect width="${MW}" height="${MH}" rx="0.8" fill="#ece6d4"/><rect x="0.3" y="0.3" width="${f1(MW - 0.6)}" height="${f1(MH - 0.6)}" rx="0.6" fill="none" stroke="#ffffff" stroke-width="0.3" opacity="0.8"/>` + glass
          + `<rect x="${F}" y="${F}" width="${f1(gw)}" height="${f1(gh)}" fill="none" stroke="#c8c0a8" stroke-width="0.3"/>`
          + `<g transform="translate(${f1(MW - 6)} ${F + 0.4}) rotate(8)"><rect width="4.4" height="13" fill="#f4f0e4"/>${rep(4, i => `<rect x="0.5" y="${f1(0.5 + i * 3.1)}" width="3.4" height="2.6" fill="${['#c8a088', '#b89078', '#d0a890', '#a88470'][i]}"/><circle cx="2.2" cy="${f1(1.6 + i * 3.1)}" r="0.7" fill="#5a4030" opacity="0.5"/>`).join('')}</g>`
          + `<ellipse cx="5" cy="${f1(MH * 0.62)}" rx="2.4" ry="3.4" fill="#ffffff" opacity="0.25"/><rect x="2" y="${f1(MH - 6)}" width="3.6" height="1.6" fill="#ece4d0" opacity="0.8"/><path d="M2.4 ${f1(MH - 5.4)}h2.4" stroke="#c8402a" stroke-width="0.3" opacity="0.6"/>`
          + `<path d="M0 ${f1(MH - 3)}l1.4 0.4l-0.4 1.2l1 1.4" stroke="#8a826c" stroke-width="0.15" fill="none"/><rect x="-0.2" y="${f1(MH - 4)}" width="3" height="3" fill="#ffffff" opacity="0.3" transform="rotate(20 1 ${f1(MH - 2.5)})"/>`;
        let s = WD(C, -MW / 2 + 1, MH + 1.4, 0.04, `<rect width="${MW}" height="${MH}" rx="0.8" fill="#2a2018" opacity="0.25" filter="url(#m10b1)"/>`)
          + box3(C, { c: [0, 0, 0.6], w: MW, h: MH, d: 1.2, col: '#ece6d4', r: 0.3, dec: { f: face } });
        [-4.4, 4.4].forEach(x => { s += line3(C, [[x, MH - 0.6, 1.2], [x, MH + 3.4, 1.2], [x, MH + 3.4, -0.6], [x, MH + 1.6, -0.8]], 0.45, '#8a8c90'); });
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-031 FREESTANDING OAK CHEVAL TILT MIRROR (T2): a tall honey-oak cheval: a framed mirror pivoting between two turned uprights on splayed trestle
    // feet, with brass tilt knobs, a slim stretcher bar, a bevelled glass edge and a cotton scarf hung over one upright. w 70 d 40 kept.
    // Live: a glint slides slowly down the bevel and the scarf's fringe stirs.
    N.cheval30 = S => { const D = { w: 70, d: 40, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('cheval30'), id = C.u('m31'), OK = '#c89858', PX = 15, PY = 40, MW = 24, MH = 58;
        const grainV2 = (w, h) => `<rect width="${w}" height="${h}" fill="${OK}"/>` + grainV(R, w, h, Math.max(3, Math.round(w * 1.2)), '#9a6a34', 0.5);
        // uprights + feet + stretcher
        const ups = [-1, 1].map(sx => { const x = sx * PX; return { q: [x, 30, 0], s: box3(C, decC(C, { c: [x, 0, 0], w: 3.4, h: 2.6, d: 20, col: OK, r: 1.2, dec: { t: grainV2(3.4, 20), l: grainV2(20, 2.6), r: grainV2(20, 2.6) } })) + cyl3(C, [x, 2.6, 0], [x, PY + 6, 0], 1.4, OK, { r2: 1.1, olw: 0.3 }) + H.sph(C, [x, PY + 7, 0], 1.4, OK) + cyl3(C, [x + sx * 1.6, PY, 0], [x + sx * 2.6, PY, 0], 1.3, '#d4b06a', { mat: 'metal', olw: 0.25 }) }; });
        const bar = cyl3(C, [-PX, 8, 0], [PX, 8, 0], 0.8, OK, { olw: 0.3 });
        // tilting mirror frame (box3 with axes tilted back about x through the pivots)
        const th = 0.1, A = [[1, 0, 0], [0, Math.cos(th), -Math.sin(th)], [0, Math.sin(th), Math.cos(th)]];
        const c = [0, PY - MH / 2 * Math.cos(th), 0 + MH / 2 * Math.sin(th)];
        const gw = MW - 4, gh = MH - 4, glint = `<rect x="0" y="-10" width="${gw}" height="5" fill="url(#${id}g)" transform="skewY(-12)">${an('y', `-10;${gh + 10}`, 10)}</rect>`;
        const face = grainV2(MW, MH) + `<rect x="1.6" y="1.6" width="${MW - 3.2}" height="${MH - 3.2}" fill="#8a5a2a"/><clipPath id="${id}k"><rect x="2" y="2" width="${gw}" height="${gh}"/></clipPath><g clip-path="url(#${id}k)"><g transform="translate(2 2)">${refl30(id, gw, gh)}${glint}</g></g>`
          + `<rect x="2" y="2" width="${gw}" height="${gh}" fill="none" stroke="#ffffff" stroke-width="0.6" opacity="0.5"/><rect x="2.6" y="2.6" width="${gw - 1.2}" height="${gh - 1.2}" fill="none" stroke="#9aa8b0" stroke-width="0.3" opacity="0.6"/>`;
        const mir = box3(C, decC(C, { c, ax: A, w: MW, h: MH, d: 1.6, col: OK, r: 0.4, dec: { f: face, b: grainV2(MW, MH), l: grainV2(1.6, MH), r: grainV2(1.6, MH), t: grainV2(MW, 1.6) } }));
        // scarf over the right upright
        const sp = C.P([PX, PY + 6, 0]), k = C.k, scarf = `<g transform="translate(${P2(sp)})"><path d="M${f1(-1 * k)} 0Q${f1(-1.6 * k)} ${f1(8 * k)} ${f1(-2 * k)} ${f1(16 * k)}L${f1(1 * k)} ${f1(16 * k)}Q${f1(1.6 * k)} ${f1(8 * k)} ${f1(1.4 * k)} 0Z" fill="#c86a4a"/><path d="M${f1(-1.2 * k)} ${f1(3 * k)}l${f1(2.6 * k)} 0M${f1(-1.4 * k)} ${f1(7 * k)}l${f1(2.8 * k)} 0M${f1(-1.7 * k)} ${f1(11 * k)}l${f1(3 * k)} 0" stroke="#f4dcb0" stroke-width="${f1(0.4 * k)}"/><g>${at('skewX', '-6;6;-6', 3.4, 0, SPL(2))}${rep(6, i => `<path d="M${f1((-2 + i * 0.6) * k)} ${f1(16 * k)}l0 ${f1(1.6 * k)}" stroke="#c86a4a" stroke-width="${f1(0.25 * k)}"/>`).join('')}</g></g>`;
        const fr = C.v[2] > 0, ordered = ups.sort((a, b) => a.q[0] * C.v[0] - b.q[0] * C.v[0]);
        let s = shadow(C, 0, 0, PX + 6, 10, 0.4) + bar + ordered[0].s + mir + ordered[1].s + scarf;
        C.p(-35, 0, 0); C.p(35, 0, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.4"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-051 OVERSIZED ARCHED BRASS FLOOR-LEANING MIRROR (T3): a huge arch-topped mirror in a slim brushed-brass frame leaning back against the wall on
    // two felt pads, a soft shadow behind it, a draped linen throw and a small trailing pothos in a terracotta pot at its foot. w 70 d 40 kept.
    // Live: a glint slides down the arch and the pothos leaves sway.
    N.arch30 = S => { const D = { w: 70, d: 40, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('arch30'), id = C.u('m51'), k = C.k, BR = '#c9a256', MW = 38, MH = 86, th = 0.13;
        const U = [1, 0, 0], V = [0, -Math.cos(th), -Math.sin(th)], O = [-MW / 2, MH * Math.cos(th), -10 + MH * Math.sin(th) * 0 ];
        const top = [0, MH * Math.cos(th), -12 - MH * Math.sin(th) * 0.0];
        const base = [-MW / 2, 0, -2], up = [0, Math.cos(th), -Math.sin(th)], O2 = [base[0] + up[0] * MH, base[1] + up[1] * MH, base[2] + up[2] * MH];
        const arch = (w, h, r) => `M0 ${h}V${r}A${r} ${r} 0 0 1 ${w} ${r}V${h}Z`;
        const gw = MW - 3, gh = MH - 3, aid = C.u('ak');
        const glint = `<rect x="0" y="-12" width="${gw}" height="6" fill="url(#${id}g)" transform="skewY(-14)">${an('y', `-12;${gh + 12}`, 12)}</rect>`;
        const plane = (dz, svg) => `<g transform="${FR(C, [O2[0], O2[1], O2[2] + dz], U, [0, -Math.cos(th), Math.sin(th)])}">${svg}</g>`;
        const back = plane(-1.2, `<path d="${arch(MW, MH, MW / 2)}" fill="#8a6a32"/>`);
        const front = plane(0, `<path d="${arch(MW, MH, MW / 2)}" fill="url(#${id}b)"/><clipPath id="${aid}"><path d="${arch(gw, gh, gw / 2)}" transform="translate(1.5 1.5)"/></clipPath><g clip-path="url(#${aid})"><g transform="translate(1.5 1.5)">${refl30(id, gw, gh, { wx: 0.3 })}${glint}</g></g><path d="${arch(gw, gh, gw / 2)}" transform="translate(1.5 1.5)" fill="none" stroke="#fff4d0" stroke-width="0.4" opacity="0.7"/><path d="${arch(MW, MH, MW / 2)}" fill="none" stroke="#7a5a28" stroke-width="0.3"/>`);
        const wallSh = `<g transform="${FR(C, [O2[0] + 3, O2[1] - 2, -12.6], U, [0, -1, 0])}"><path d="${arch(MW, MH - 6, MW / 2)}" fill="#2a2018" opacity="0.2" filter="url(#m10b1)"/></g>`;
        // throw over the frame corner + pothos in terracotta
        const tp = C.P([MW / 2 - 4, MH * 0.55 * Math.cos(th), -2 - MH * 0.55 * Math.sin(th) + 1]);
        const throwS = `<g transform="translate(${P2(tp)}) scale(${n4(k)})"><path d="M-2 0Q3 -2 6 0Q7 14 4 30L-1 30Q1 14 -2 0Z" fill="#e8dcc4"/><path d="M0 2Q2 15 1 28M3 1Q5 15 3 29" stroke="#c8b898" stroke-width="0.3" fill="none"/>${rep(6, i => `<path d="M${f1(-0.8 + i * 0.9)} 30l0 2" stroke="#d8ccb0" stroke-width="0.3"/>`).join('')}</g>`;
        const PXp = -MW / 2 - 4, PZ = 6;
        const pot = cyl3(C, [PXp, 0, PZ], [PXp, 7, PZ], 3.2, '#c86a42', { r2: 4, olw: 0.3, capCol: '#4a3220' }) + cyl3(C, [PXp, 7, PZ], [PXp, 8.2, PZ], 4.2, '#d47a50', { olw: 0.3, capCol: '#4a3220' });
        const leaf = (x, y, a, s) => `<path d="M0 0Q${f1(s * 0.6)} ${f1(-s * 0.5)} ${f1(s)} 0Q${f1(s * 0.6)} ${f1(s * 0.5)} 0 0Z" fill="${R() < 0.5 ? '#4e8a3e' : '#6aa04a'}" stroke="#2e5a24" stroke-width="0.12" transform="translate(${f1(x)} ${f1(y)}) rotate(${f1(a)})"/>`;
        const pc = C.P([PXp, 8.2, PZ]);
        let vines = ''; rep(5, j => { let x = 0, y = 0, d = 'M0 0'; const L = 6 + j * 2, dir = j % 2 ? 1 : -1; for (let i = 0; i < L; i++) { x += dir * (0.6 + R() * 0.8); y += 0.9 + R() * 0.4 - (i < 3 ? 2.2 : 0); d += `L${f1(x)} ${f1(y)}`; if (i % 2) vines += leaf(x, y, dir > 0 ? 20 + R() * 60 : 120 + R() * 60, 2.2 + R() * 0.8); } vines = `<path d="${d}" stroke="#5a7a3a" stroke-width="0.25" fill="none"/>` + vines; });
        const plant = `<g transform="translate(${P2(pc)}) scale(${n4(k)})"><g>${at('rotate', '-2;2;-2', 5, 0, SPL(2))}${vines}</g></g>`;
        const pads = [-1, 1].map(sx => box3(C, { c: [sx * (MW / 2 - 4), 0, -2], w: 4, h: 0.8, d: 3, col: '#5a5450', r: 0.3 })).join('');
        let s = shadow(C, 0, -4, MW * 0.6, 8, 0.35) + wallSh + pads + (C.v[2] > 0 ? back + front + throwS : front + back) + shadow(C, PXp, PZ, 4, 4, 0.35) + pot + plant;
        C.p(-35, 0, 0); C.p(35, 0, 0); C.p(0, MH + 2, -12);
        return { defs: DEF19 + `<defs><linearGradient id="${id}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4dca0"/><stop offset="0.4" stop-color="${BR}"/><stop offset="0.7" stop-color="#e8c880"/><stop offset="1" stop-color="#8a6a32"/></linearGradient>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.4"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-071 BACKLIT ORNATE GILDED PARISIAN DRESSING MIRROR (T4): a tall Louis XV floor mirror leaning on the wall, its thick hand-carved frame water-gilded
    // in warm gold with a ribbed acanthus moulding, a beaded inner edge, a scallop-shell crest flanked by C-scrolls and carved roses at the foot. A warm LED
    // strip behind the frame washes the wall in a soft golden halo. A blush velvet pouf on a gilt band sits beside it. w 70 d 40 kept.
    // Live: the halo breathes, a glint slides down the glass and the gilding catches tiny twinkles.
    N.paris30 = S => { const D = { w: 70, d: 40, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('m71'), k = C.k, MW = 34, MH = 72, th = 0.09, M = MW / 2;
        const up = [0, Math.cos(th), -Math.sin(th)], base = [-M, 0, -12], O2 = [base[0] + up[0] * MH, base[1] + up[1] * MH, base[2] + up[2] * MH], U = [1, 0, 0], V = [0, -Math.cos(th), Math.sin(th)];
        const plane = (dz, svg) => `<g transform="${FR(C, [O2[0], O2[1], O2[2] + dz], U, V)}">${svg}</g>`;
        // serpentine-topped glass outline (svg y down, 0 = top of the straight sides)
        const G = (i) => `M${i} ${MH - i}V${12 + i}C${i} ${6 + i} ${6 + i} ${5 + i} ${10 + i * 0.6} ${5 + i}C${M - 6} ${5 + i} ${M - 5} ${i * 0.6} ${M} ${i * 0.6 - 1}C${M + 5} ${i * 0.6} ${M + 6} ${5 + i} ${MW - 10 - i * 0.6} ${5 + i}C${MW - 6 - i} ${5 + i} ${MW - i} ${6 + i} ${MW - i} ${12 + i}V${MH - i}Z`;
        const gw = MW, gh = MH, glint = `<rect x="0" y="-12" width="${gw}" height="6" fill="url(#${id}g)" transform="skewY(-14)">${an('y', `-12;${gh + 12}`, 13)}</rect>`;
        const cid = C.u('pk');
        // crest: scallop shell + C-scrolls + leaf sprays; foot roses
        const shell = `<g transform="translate(${M} -2)">${rep(9, i => { const a = -PI + (i + 0.5) * PI / 9; return `<path d="M0 0Q${f1(Math.cos(a - 0.12) * 5)} ${f1(Math.sin(a - 0.12) * 5)} ${f1(Math.cos(a) * 7.4)} ${f1(Math.sin(a) * 7.4)}Q${f1(Math.cos(a + 0.12) * 5)} ${f1(Math.sin(a + 0.12) * 5)} 0 0Z" fill="url(#${id}b)" stroke="#7a5418" stroke-width="0.25"/>`; }).join('')}<circle r="1.6" fill="url(#${id}b)" stroke="#7a5418" stroke-width="0.25"/></g>`;
        const scroll = sx => `<g transform="translate(${M} 2) scale(${sx} 1)"><path d="M3 -1C8 -6 14 -4 15 0C16 4 12 5 11 2C10 0 12 -1 13 0" fill="none" stroke="url(#${id}b)" stroke-width="1.7" stroke-linecap="round"/><path d="M3 -1C8 -6 14 -4 15 0C16 4 12 5 11 2" fill="none" stroke="#7a5418" stroke-width="0.25"/>`
          + `<path d="M6 -3Q8 -8 12 -7Q10 -5 9 -3Z" fill="url(#${id}b)" stroke="#7a5418" stroke-width="0.2"/><path d="M15 1Q19 0 20 3Q17 3 15.6 2.4Z" fill="url(#${id}b)" stroke="#7a5418" stroke-width="0.2"/></g>`;
        const rose = (x, y) => `<g transform="translate(${x} ${y})">${rep(5, i => `<ellipse cx="0" cy="-1.3" rx="1" ry="1.4" fill="url(#${id}b)" stroke="#7a5418" stroke-width="0.18" transform="rotate(${i * 72})"/>`).join('')}<circle r="0.9" fill="#f6e2a4" stroke="#7a5418" stroke-width="0.18"/>`
          + `<path d="M1.6 1.2Q4 2.4 5.4 1M-1.6 1.2Q-4 2.4 -5.4 1" stroke="url(#${id}b)" stroke-width="1" fill="none" stroke-linecap="round"/></g>`;
        const tw = (x, y, b) => `<g transform="translate(${x} ${y})" opacity="0"><path d="M0 -1.6L0.3 -0.3L1.6 0L0.3 0.3L0 1.6L-0.3 0.3L-1.6 0L-0.3 -0.3Z" fill="#fffbe8"/>${an('opacity', '0;0;1;0;0', 7, b, KT('0;0.5;0.56;0.64;1'))}</g>`;
        const frame = `<path d="${G(2.2)}" fill="none" stroke="#5a3c12" stroke-width="7.4" stroke-linejoin="round" opacity="0.6"/><path d="${G(2.2)}" fill="none" stroke="url(#${id}b)" stroke-width="6.4" stroke-linejoin="round"/>`
          + `<path d="${G(2.2)}" fill="none" stroke="#6a4614" stroke-width="5.2" stroke-dasharray="0.7 1.3" opacity="0.35"/><path d="${G(2.2)}" fill="none" stroke="#fff2c0" stroke-width="2.4" stroke-dasharray="0.7 1.3" stroke-dashoffset="0.4" opacity="0.28"/>`
          + `<path d="${G(5)}" fill="none" stroke="#fff0b8" stroke-width="0.8" stroke-dasharray="0.05 1.1" stroke-linecap="round"/><path d="${G(5.4)}" fill="none" stroke="#7a5418" stroke-width="0.3"/><path d="${G(-0.8)}" fill="none" stroke="#7a5418" stroke-width="0.4"/>`
          + scroll(1) + scroll(-1) + shell + rose(4, MH - 3) + rose(MW - 4, MH - 3) + rose(M, MH - 1.4)
          + tw(5, 20, 0) + tw(MW - 3, 40, 2.3) + tw(M + 3, -6, 4.1) + tw(3, MH - 12, 5.6);
        const face = `<clipPath id="${cid}"><path d="${G(5)}"/></clipPath><g clip-path="url(#${cid})">${refl30(id, gw, gh, { wx: 0.56, top: '#e6d8c4', mid: '#d8c6ae', floor: '#9a7454' })}<rect width="${gw}" height="${gh}" fill="#ffd890" opacity="0.08"/>${glint}</g>` + frame;
        const halo = `<g transform="${FR(C, [O2[0], O2[1] + 1, -19.6], U, [0, -1, 0])}"><g filter="url(#${id}h)"><path d="${G(1)}" fill="none" stroke="#ffd48a" stroke-width="9" opacity="0.55">${an('opacity', '0.4;0.7;0.4', 6, 0, SPL(2))}</path><path d="${G(3)}" fill="#ffe2a8" opacity="0.18"/></g></g>`;
        const back = plane(-1.6, `<path d="${G(2.2)}" fill="#6a4a1e" stroke="#5a3c12" stroke-width="7"/>`), mid = plane(-0.8, `<path d="${G(2.2)}" fill="none" stroke="#8a6224" stroke-width="7"/>`);
        // blush velvet pouf on a gilt band
        const PX = 23, PZ = 6, R0 = 7.4;
        const pouf = shadow(C, PX, PZ, R0 + 1, R0 * 0.6, 0.35) + cyl3(C, [PX, 0, PZ], [PX, 2.2, PZ], R0 + 0.2, '#d4ac58', { mat: 'metal', olw: 0.25 })
          + cyl3(C, [PX, 2.2, PZ], [PX, 11, PZ], R0, '#d49a98', { mat: 'matte', olw: 0.3, capCol: '#e2acaa' }) + cyl3(C, [PX, 10.6, PZ], [PX, 11.4, PZ], R0 + 0.15, '#c08886', { olw: 0, ol: 0, noCap: 1 })
          + `<g transform="translate(${P2(C.P([PX, 11.4, PZ]))}) scale(${n4(k)})"><ellipse rx="1" ry="0.6" fill="#a86a6a"/><ellipse cx="-0.2" cy="-0.15" rx="0.4" ry="0.25" fill="#f4c8c4"/></g>`;
        const fr = C.v[2] > 0;
        let s = shadow(C, 0, -6, M + 4, 9, 0.35) + halo + (fr ? back + mid + plane(0, face) : plane(0, face) + mid + back);
        s = fr ? s + pouf : pouf + s;
        C.p(-35, 0, 0); C.p(35, 0, 0); C.p(0, MH + 12, -18);
        return { defs: DEF19 + `<defs><linearGradient id="${id}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0b0"/><stop offset="0.3" stop-color="#e2b65a"/><stop offset="0.55" stop-color="#f6d888"/><stop offset="0.8" stop-color="#b88a34"/><stop offset="1" stop-color="#8a6420"/></linearGradient>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#fff8e0" stop-opacity="0.42"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>`
          + `<filter id="${id}h" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="3"/></filter></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-091 360-DEGREE HOLOGRAPHIC WARDROBE TRY-ON SMART MIRROR (T5): a tall frameless smart mirror in a slim brushed champagne-gold edge on a low gold
    // foot, facing a round champagne try-on turntable. A warm hologram of an outfit stands in a soft light column above the turntable, slowly turning
    // through 360 degrees, while the glass shows the same look with a swatch carousel and a turning 360 icon. w 70 d 40 kept.
    // Live: the hologram turns and cycles a gown, a trench and a jumpsuit, a scan line sweeps up, motes rise and the turntable ring rotates.
    N.holo30 = S => { const D = { w: 70, d: 40, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('m91'), k = C.k, CH = '#d8c094', MW = 30, MH = 74, MZ = -14, TZ = 6, TR0 = 11;
        const T = 15, FD = [['1;1;0;0;1', '0;0.31;0.35;0.97;1'], ['0;0;1;1;0;0', '0;0.31;0.35;0.64;0.68;1'], ['0;0;1;1;0', '0;0.64;0.68;0.97;1']];
        const fade = i => an('opacity', FD[i][0], T, 0, KT(FD[i][1]));
        const OUT = [
          'M-2 -40H2L3 -35L8 -33L5.6 -24L4 -23Q8 -12 13 -1Q0 1.4 -13 -1Q-8 -12 -4 -23L-5.6 -24L-8 -33L-3 -35Z',
          'M-2 -40H2L3 -35L9 -33L10 -18L8.6 -17L9.6 -4Q0 -2.6 -9.6 -4L-8.6 -17L-10 -18L-9 -33L-3 -35Z',
          'M-2 -40H2L3 -35L8 -33L7 -22L6 -21L5.4 -1H1L0 -16L-1 -1H-5.4L-6 -21L-7 -22L-8 -33L-3 -35Z'];
        const DET = ['<path d="M-4 -23Q0 -21.6 4 -23M-6 -10Q0 -8 6 -10M-9 -5Q0 -3 9 -5" stroke="#fff4d8" stroke-width="0.25" fill="none" opacity="0.7"/>',
          '<path d="M-3 -35L0 -26L3 -35M-9.4 -20H9.4M0 -26V-4M-2 -22h0.6M-2 -15h0.6" stroke="#fff4d8" stroke-width="0.3" fill="none" opacity="0.75"/><rect x="-1.4" y="-21" width="2.8" height="1.8" fill="none" stroke="#fff4d8" stroke-width="0.25"/>',
          '<path d="M-6.4 -22H6.4M-3 -35L0 -30L3 -35M-2.4 -28h0.5M-2.4 -25h0.5" stroke="#fff4d8" stroke-width="0.3" fill="none" opacity="0.75"/>'];
        const FILL = ['#f0b8a8', '#e8c890', '#f4e2c4'];
        const fig = (sc, op) => `<g opacity="${op}">${rep(3, i => `<g opacity="${i ? 0 : 1}">${fade(i)}<path d="${OUT[i]}" fill="${FILL[i]}" fill-opacity="0.42" stroke="#fff0c8" stroke-width="0.35"/><path d="${OUT[i]}" fill="url(#${id}l)"/>${DET[i]}</g>`).join('')}`
          + `<path d="M0 -40V-42.6" stroke="#f6e2b0" stroke-width="0.6"/><circle cy="-43" r="0.9" fill="#f6e2b0"/></g>`;
        // hologram billboard over the turntable
        const hp = C.P([0, 3, TZ]), turn = at('scale', '1 1;0.18 1;-1 1;0.18 1;1 1', 9, 0, ' calcMode="spline" keyTimes="0;0.25;0.5;0.75;1" keySplines="0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1"');
        const motes = rep(10, i => { const x = ((i * 37) % 19) - 9.5, d = 4 + (i % 4); return `<circle cx="${f1(x)}" cy="0" r="0.35" fill="#fff4d0" opacity="0">${an('cy', '0;-44', d, -i * 0.7)}${an('opacity', '0;0.9;0', d, -i * 0.7)}</circle>`; }).join('');
        const holo = `<g transform="translate(${P2(hp)}) scale(${n4(k)})"><path d="M-11 0L-8 -48H8L11 0Z" fill="url(#${id}c)" opacity="0.6">${an('opacity', '0.45;0.65;0.45', 5, 0, SPL(2))}</path>`
          + `<g><g>${turn}${fig(1, 0.95)}</g></g><rect x="-11" y="-2" width="22" height="0.5" fill="#fff4d0" opacity="0.6">${an('y', '-1;-46;-1', 6)}${an('opacity', '0.7;0.2;0.7', 6)}</rect>${motes}</g>`;
        // turntable
        const PLNt = svg => `<g transform="${FR(C, [0, 2.6, TZ], [1, 0, 0], [0, 0, 1])}">${svg}</g>`;
        const table = shadow(C, 0, TZ, TR0 + 2, TR0 * 0.6, 0.35) + cyl3(C, [0, 0, TZ], [0, 2.6, TZ], TR0, CH, { mat: 'metal', olw: 0.3, capCol: '#efe2c4' })
          + PLNt(`<circle r="${TR0 - 1}" fill="none" stroke="#c8ae7c" stroke-width="0.3"/><g>${at('rotate', '0;360', 18)}<circle r="${TR0 - 2.2}" fill="none" stroke="#ffd890" stroke-width="0.7" stroke-dasharray="3 1.4" opacity="0.9"/>${rep(24, i => `<path d="M${f1(Math.cos(i * PI / 12) * (TR0 - 0.4))} ${f1(Math.sin(i * PI / 12) * (TR0 - 0.4))}L${f1(Math.cos(i * PI / 12) * (TR0 - 1.4))} ${f1(Math.sin(i * PI / 12) * (TR0 - 1.4))}" stroke="#a88c58" stroke-width="0.25"/>`).join('')}</g>`
            + `<circle r="7.6" fill="url(#${id}p)">${an('opacity', '0.6;1;0.6', 5, 0, SPL(2))}</circle>`);
        // mirror: glass slab with UI overlay
        const echo = `<g transform="translate(${MW * 0.44} ${MH * 0.8}) scale(0.95)"><g>${turn}${fig(1, 0.55)}</g></g>`;
        const sw = rep(3, i => `<rect x="${MW - 6}" y="${f1(20 + i * 7)}" width="4" height="5" rx="1" fill="${FILL[i]}" opacity="0.85"/>`).join('')
          + `<rect x="${MW - 6.6}" y="19.4" width="5.2" height="6.2" rx="1.3" fill="none" stroke="#fff6dc" stroke-width="0.45">${at('translate', '0 0;0 7;0 14', T, 0, ' calcMode="discrete" keyTimes="0;0.3333;0.6667"')}</rect>`;
        const ui = `<g transform="translate(${MW - 4} 9)"><g>${at('rotate', '0;360', 9)}<path d="M-2.6 0A2.6 2.6 0 1 1 0 2.6" stroke="#fff0c8" stroke-width="0.4" fill="none"/><path d="M0 2.6l1 -0.8l0 1.6Z" fill="#fff0c8"/></g></g>`
          + `<rect x="4" y="${MH - 7}" width="${MW - 8}" height="0.5" rx="0.25" fill="#ffffff" opacity="0.3"/><rect x="4" y="${MH - 7}" width="0" height="0.5" rx="0.25" fill="#ffe2a8">${an('width', `0;${MW - 8}`, T / 3)}</rect>`
          + `<rect x="3" y="6" width="9" height="1" rx="0.5" fill="#fff4dc" opacity="0.5"/><rect x="3" y="8.4" width="6" height="0.6" rx="0.3" fill="#fff4dc" opacity="0.35"/>`;
        const gw = MW - 1.6, gh = MH - 1.6, mk = C.u('hk');
        const glint = `<rect x="0" y="-12" width="${gw}" height="6" fill="url(#${id}g)" transform="skewY(-14)">${an('y', `-12;${gh + 12}`, 11)}</rect>`;
        const face = `<rect width="${MW}" height="${MH}" rx="1.6" fill="url(#${id}e)"/><clipPath id="${mk}"><rect x="0.8" y="0.8" width="${gw}" height="${gh}" rx="1.1"/></clipPath><g clip-path="url(#${mk})"><g transform="translate(0.8 0.8)">${refl30(id, gw, gh, { wx: 0.12, top: '#e4dccc', mid: '#d6ccb8', floor: '#a0866a' })}<rect width="${gw}" height="${gh}" fill="#2a2018" opacity="0.08"/>${echo}${sw}${ui}${glint}</g></g>`;
        const mirror = box3(C, { c: [0, 3, MZ], w: MW, h: MH, d: 1.6, col: CH, r: 0.6, dec: { f: face } });
        const foot = box3(C, { c: [0, 0, MZ], w: MW + 4, h: 3, d: 9, col: CH, r: 1.2, dec: { t: `<rect width="${MW + 4}" height="9" fill="${CH}"/><rect y="4.2" width="${MW + 4}" height="0.4" fill="#fff4dc" opacity="0.5"/>` } })
          + `<g filter="url(#${id}h)"><ellipse cx="${P2(C.P([0, 0, MZ + 5])).split(' ')[0]}" cy="${P2(C.P([0, 0, MZ + 5])).split(' ')[1]}" rx="${f1(14 * k)}" ry="${f1(2 * k)}" fill="#ffe0a0" opacity="0.4"/></g>`;
        const fr = C.v[2] > 0, mir = shadow(C, 0, MZ, MW / 2 + 4, 6, 0.35) + foot + mirror, tt = table + holo;
        let s = fr ? mir + tt : tt + mir;
        C.p(-35, 0, 0); C.p(35, 0, 0); C.p(0, MH + 4, MZ); C.p(0, 50, TZ);
        return { defs: DEF19 + `<defs><linearGradient id="${id}e" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6e8c8"/><stop offset="0.5" stop-color="${CH}"/><stop offset="1" stop-color="#9a8058"/></linearGradient>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.35"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>`
          + `<linearGradient id="${id}c" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.7"/><stop offset="0.6" stop-color="#ffe8c0" stop-opacity="0.18"/><stop offset="1" stop-color="#fff0d0" stop-opacity="0"/></linearGradient>`
          + `<pattern id="${id}l" width="2" height="1" patternUnits="userSpaceOnUse"><rect width="2" height="0.35" fill="#ffffff" opacity="0.25"/></pattern>`
          + `<radialGradient id="${id}p" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff2c8" stop-opacity="0.9"/><stop offset="0.6" stop-color="#ffd890" stop-opacity="0.35"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient>`
          + `<filter id="${id}h" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="1.6"/></filter></defs>`, front: s, bb: C.bb(3) }; };
      return D; };


    // ======================= CLOTHES STORAGE (BED-013/033/..): floor pieces, garmrack 110 x 46 / wardrobe 106 x 54 footprints kept =======================
    // BED-013 WOBBLY METAL GARMENT RACK WITH WIRE HANGERS (T1): a cheap chrome-look rack gone dull, the top rail bowing, one upright joint wrapped in
    // duct tape, one caster missing so that foot is propped on a paperback. Wire dry-cleaner hangers hold a dry-cleaning bag over a white shirt, a grey
    // hoodie, a red flannel shirt and folded jeans, plus one bare hanger. A wire shelf below holds sneakers and a shoebox. w 110 d 46 kept.
    // Live: the whole rack wobbles, the clothes jiggle on their hangers and the empty hanger swings.
    N.rack30 = S => { const D = { w: 110, d: 46, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('rack30'), id = C.u('r13'), k = C.k, ST = '#a4a8ac', RY = 128, X0 = 46;
        const hook = w => `<path d="M0 5.6V2.2Q0 0.2 1.5 0.2Q2.9 0.2 2.9 1.6" stroke="#8e9498" stroke-width="0.4" fill="none" stroke-linecap="round"/><path d="M-0.4 5.2l0.8 0.6M-0.4 6l0.8 0.6" stroke="#8e9498" stroke-width="0.3"/><path d="M0 6L${-w} 10.4H${w}Z" stroke="#8e9498" stroke-width="0.4" fill="none" stroke-linejoin="round"/>`;
        const G = {
          bag: hook(9) + `<path d="M-4 7.6L-9.4 10.6V30H9.4V10.6L4 7.6Q0 9.6 -4 7.6Z" fill="#ffffff" stroke="#d4d8dc" stroke-width="0.3"/><path d="M-2 7.8L0 13L2 7.8" stroke="#d8d8d8" stroke-width="0.3" fill="none"/><path d="M0 13V30" stroke="#e4e4e4" stroke-width="0.3"/>${rep(5, i => `<circle cx="0.7" cy="${15 + i * 3}" r="0.3" fill="#d0d0d0"/>`).join('')}`
            + `<path d="M0 6L-11.6 12V44L-10 45.6H10L11.6 44V12Z" fill="#e8eef2" opacity="0.4" stroke="#b8c4cc" stroke-width="0.35"/><path d="M-8 16Q-6 26 -8.6 36M6 14Q8 24 5.6 40M-2 30Q2 33 6 31" stroke="#ffffff" stroke-width="0.5" fill="none" opacity="0.6"/><rect x="3" y="11" width="3.4" height="2.4" rx="0.3" fill="#f2b8c8" transform="rotate(12 4.7 12.2)"/>`,
          hood: hook(10) + `<path d="M-5 7Q-6 2 0 1.6Q6 2 5 7Z" fill="#7a7f86"/><path d="M-10 10.4L-5 7.4Q0 10 5 7.4L10 10.4L12.6 34L10.4 34.4L9.6 18L9.4 36H-9.4L-9.6 18L-10.4 34.4L-12.6 34Z" fill="#8e939a"/>`
            + `<path d="M-9.4 33H9.4V36H-9.4Z" fill="#7a7f86"/><path d="M-5 24H5L6 31H-6Z" fill="#848990" stroke="#70757c" stroke-width="0.3"/><path d="M-1.6 9.4V18M1.6 9.4V17" stroke="#e8e8e8" stroke-width="0.35"/><rect x="-1.9" y="17.6" width="0.6" height="1.2" fill="#c8c8c8"/><rect x="1.3" y="16.6" width="0.6" height="1.2" fill="#c8c8c8"/>`
            + `<path d="M-3 12Q0 20 -2 30M4 13Q3 22 5 32" stroke="#ffffff" stroke-width="0.6" fill="none" opacity="0.12"/>`,
          flan: hook(9) + `<path d="M-9.4 10.4L-4 7.4Q0 9 4 7.4L9.4 10.4L11.4 31L9.4 31.4L8.8 17V34Q0 35.4 -8.8 34V17L-9.4 31.4L-11.4 31Z" fill="url(#${id}p)"/><path d="M-4 7.4L-1.6 12L0 9M4 7.4L1.6 12L0 9" fill="#9a2a22" stroke="#6a1a14" stroke-width="0.2"/>`
            + `<path d="M0 11V34" stroke="#6a1a14" stroke-width="0.3"/>${rep(5, i => `<circle cx="0.8" cy="${14 + i * 4}" r="0.4" fill="#f0e6d8"/>`).join('')}<rect x="-6.4" y="15" width="4" height="3.4" fill="none" stroke="#6a1a14" stroke-width="0.25"/>`,
          jean: `<path d="M0 5.6V2.2Q0 0.2 1.5 0.2Q2.9 0.2 2.9 1.6" stroke="#8e9498" stroke-width="0.4" fill="none"/><path d="M0 6L-9 10.4H9Z" stroke="#8e9498" stroke-width="0.4" fill="none"/>`
            + `<path d="M-7.6 9.6H7.6L8.4 30L0.6 30.6L0 14L-0.6 30.6L-8.4 30Z" fill="#3e5e8e"/><path d="M-7.6 9.6H7.6L7.8 12H-7.8Z" fill="#4e70a2"/><path d="M-4 12L-4.6 29M4 12L4.6 29" stroke="#c89a4a" stroke-width="0.25" stroke-dasharray="0.6 0.4"/><path d="M-8.4 28.6L-0.6 29.2M8.4 28.6L0.6 29.2" stroke="#6a88b8" stroke-width="0.8"/>`
            + `<path d="M-6 14Q-5 22 -6.4 27M5 16Q6 22 5.4 27" stroke="#ffffff" stroke-width="0.6" fill="none" opacity="0.15"/>`,
          bare: hook(9) };
        // garments facing front, slightly staggered in z; each sways from its hook, the bare hanger swings
        const H0 = [[-33, 'bag', -2, 1.5], [-15, 'hood', 1.4, 2], [2, 'flan', -1.4, 2], [19, 'jean', 1.8, 2.4], [36, 'bare', 0, 10]];
        const plane = (x, z, svg) => `<g transform="${FR(C, [x, RY + 1.6, z], [1, 0, 0], [0, -1, 0])}"><g transform="scale(1.65)">${svg}</g></g>`;
        const gar = H0.map(([x, kk, z, a], i) => ({ z, s: plane(x, z, `<g>${at('rotate', `${-a} 1.5 0.2;${a} 1.5 0.2;${-a} 1.5 0.2`, 2.6 + i * 0.4, -i * 0.5, SPL(2))}${G[kk]}</g>`) }));
        gar.sort((a, b) => (a.z - b.z) * (C.v[2] >= 0 ? 1 : -1));
        // base: two feet along z with casters (front-left caster missing: paperback shim), wire shelf, shoebox + sneakers
        let base = '';
        [-1, 1].forEach(sx => { const x = sx * X0; base += cyl3(C, [x, 4, -20], [x, 4, 20], 1.4, ST, { mat: 'chrome', olw: 0.25 });
          [-19, 19].forEach(z => { if (sx < 0 && z > 0) base += box3(C, { c: [x, 0, z], w: 6, h: 2.6, d: 4.4, col: '#c84a3a', r: 0.3, dec: { f: `<rect width="6" height="2.6" fill="#f2ecdc"/><rect width="6" height="0.5" fill="#c84a3a"/><rect y="2.1" width="6" height="0.5" fill="#c84a3a"/>` } });
            else base += cyl3(C, [x - 0.8, 1.4, z], [x + 0.8, 1.4, z], 1.4, '#2a2a2c', { olw: 0.2 }) + cyl3(C, [x, 2.8, z], [x, 4, z], 0.5, ST, { olw: 0.15 }); }); });
        const shelf = `<g transform="${FR(C, [-44, 12, -16], [1, 0, 0], [0, 0, 1])}"><rect width="88" height="32" fill="none" stroke="${ST}" stroke-width="0.9"/>${rep(21, i => `<path d="M${f1(4 + i * 4)} 0V32" stroke="${ST}" stroke-width="0.35"/>`).join('')}</g>`;
        const sbox = box3(C, { c: [-22, 12.2, -2], w: 22, h: 9, d: 16, col: '#c8955a', r: 0.3, dec: { f: `<rect width="22" height="9" fill="#c8955a"/><rect y="0" width="22" height="2" fill="#b07a44"/><rect x="8" y="4" width="6" height="3" fill="#f2eee4"/>`, t: `<rect width="22" height="16" fill="#d4a46a"/><path d="M0 8H22" stroke="#b07a44" stroke-width="0.4"/>` } });
        const shoe = (x, z, c) => { const p = C.P([x, 12.4, z]); return `<g transform="translate(${P2(p)}) scale(${n4(k * 1.8)})"><path d="M-6 0V-2.6Q-6 -4.6 -3.6 -4.6L-1 -4.4Q1 -2.4 4 -2Q6.2 -1.6 6.2 0Z" fill="${c}"/><path d="M-6.2 0H6.4V-0.9H-6.2Z" fill="#f4f0e8"/><path d="M-2.4 -4.2L0.6 -2.4M-1.6 -4.4L1.2 -3" stroke="#f4f0e8" stroke-width="0.3"/><path d="M-3.4 -2.6Q0 -1 3.4 -1.4" stroke="#ffffff" stroke-width="0.4" fill="none" opacity="0.4"/></g>`; };
        // uprights (right one taped at a joint), bowing top rail
        const ups = [-1, 1].map(sx => cyl3(C, [sx * X0, 4, 0], [sx * X0, RY + 2, 0], 1.2, ST, { mat: 'chrome', olw: 0.25 }) + H.sph(C, [sx * X0, RY + 2.4, 0], 1.6, '#3a3a3c')).join('')
          + cyl3(C, [X0, 66, 0], [X0, 72, 0], 1.7, '#8a8e90', { mat: 'matte', olw: 0.2 }) + cyl3(C, [-X0, 10, -15], [-X0, 10, 15], 0.6, ST, { olw: 0.15 }) + cyl3(C, [X0, 10, -15], [X0, 10, 15], 0.6, ST, { olw: 0.15 });
        let rail = ''; const ry = x => RY - 2.4 * (1 - (x / X0) * (x / X0)); for (let i = 0; i < 6; i++) { const xa = -X0 + i * (2 * X0 / 6), xb = xa + 2 * X0 / 6; rail += cyl3(C, [xa, ry(xa), 0], [xb, ry(xb), 0], 1, ST, { mat: 'chrome', olw: 0.2, noCap: i > 0 && i < 5 ? 1 : 0 }); }
        const pv = C.P([0, 3, 0]), wob = `<animateTransform attributeName="transform" type="rotate" values="-0.5 ${P2(pv)};0.6 ${P2(pv)};-0.3 ${P2(pv)};0.4 ${P2(pv)};-0.5 ${P2(pv)}" dur="3.4s" repeatCount="indefinite"/>`;
        const fr = C.v[2] >= 0, shoes = shoe(10, -4, '#e8e4dc') + shoe(26, 5, '#d8d2c8');
        let top = ups + rail + gar.map(g => g.s).join('');
        let s = shadow(C, 0, 0, 54, 22, 0.32) + base + shelf + (fr ? sbox + shoes : shoes + sbox) + `<g>${wob}${top}</g>`;
        C.p(-55, 0, -23); C.p(55, 0, 23); C.p(0, RY + 4, 0); C.p(-48, 80, 0); C.p(48, 80, 0);
        return { defs: DEF19 + `<defs><pattern id="${id}p" width="4" height="4" patternUnits="userSpaceOnUse"><rect width="4" height="4" fill="#b8342a"/><rect width="1.6" height="4" fill="#2a1a1a" opacity="0.55"/><rect width="4" height="1.6" fill="#2a1a1a" opacity="0.55"/><path d="M3 0V4M0 3H4" stroke="#e8c070" stroke-width="0.15" opacity="0.6"/></pattern></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-033 2-DOOR WHITE LAMINATE ARMOIRE (T2): a flat-pack white laminate wardrobe on a grey kick plinth, two doors with slim aluminium bar handles; the
    // right door's hinge has dropped so it never quite shuts and keeps drifting open on a dark glimpse of hanging clothes. The edge banding is peeling at
    // the top corner, there is a barcode assembly sticker on the side, a canvas tote hangs off the left handle, and a rattan basket and a taped cardboard
    // box sit on top. w 106 d 54 kept. Live: the right door creaks open a little and drifts back, the tote sways.
    N.armo30 = S => { const D = { w: 106, d: 54, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('armo30'), id = C.u('a33'), k = C.k, WH = '#f4f2ee', W = 100, HH = 146, DZ = 25, Y0 = 6;
        const lam = (w, h) => `<rect width="${w}" height="${h}" fill="${WH}"/><rect width="${w}" height="${h}" fill="url(#${id}l)"/>`;
        const clothes = rep(7, i => `<rect x="${51 + i * 6.6}" y="14" width="${5.6 + R() * 1.4}" height="${48 + R() * 30}" rx="1" fill="${['#c86a5a', '#4a6a8a', '#e8d8b8', '#6a8a5a', '#2a2a3a', '#d8a848', '#8a6aa8'][i]}" opacity="0.75"/>`).join('');
        const face = lam(W, HH) + `<rect x="50" y="2" width="49" height="${HH - 8}" fill="#3a3430"/><path d="M50 9H99" stroke="#9a9a9a" stroke-width="0.8"/>${clothes}<rect x="50" y="2" width="49" height="${HH - 8}" fill="#000000" opacity="0.35"/>`
          + `<rect x="1" y="2" width="48.6" height="${HH - 8}" fill="none" stroke="#d8d4cc" stroke-width="0.4"/><rect x="1.4" y="2.4" width="47.8" height="0.6" fill="#ffffff" opacity="0.8"/>`
          + `<rect x="44.6" y="58" width="1.4" height="26" rx="0.7" fill="#b4b8bc"/><rect x="44.8" y="58" width="0.5" height="26" fill="#eef0f2"/>`
          + `<g transform="translate(45.3 60)"><g>${at('rotate', '-4 0 0;4 0 0;-4 0 0', 3.8, 0, SPL(2))}<path d="M-0.6 0Q-3 4 -5 8M0.6 0Q3 4 5 8" stroke="#d8c8a4" stroke-width="0.6" fill="none"/><path d="M-7 8H7L6.4 26H-6.4Z" fill="#e8dcc0"/><path d="M-7 8H7V9.4H-7Z" fill="#d4c6a4"/><circle cx="0" cy="17" r="3.4" fill="#c86a4a" opacity="0.8"/><path d="M-2 17h4M0 15v4" stroke="#f4e8d0" stroke-width="0.5"/></g></g>`
          + `<path d="M0 ${HH - 6}H${W}" stroke="#d8d4cc" stroke-width="0.4"/><path d="M0 0.6Q4 1.4 7 0.4Q8.6 3 6.4 5" stroke="#e8e4dc" stroke-width="0.9" fill="none"/><path d="M0 0H8" stroke="#c8a878" stroke-width="0.8"/>`;
        const side = (w, h) => lam(w, h) + `<g transform="translate(${w * 0.55} ${h * 0.7})"><rect width="9" height="5" fill="#ffffff" stroke="#d8d4cc" stroke-width="0.2"/>${rep(12, i => `<rect x="${f1(0.8 + i * 0.6)}" y="0.8" width="${i % 3 ? 0.25 : 0.4}" height="2.6" fill="#2a2a2a"/>`).join('')}<rect x="0.8" y="3.8" width="7" height="0.4" fill="#8a8a8a"/></g>`;
        const body = box3(C, decC(C, { c: [0, Y0, 0], w: W, h: HH, d: 50, col: WH, r: 0.3, dec: { f: face, l: side(50, HH), r: side(50, HH), t: lam(W, 50) } }));
        const plinth = box3(C, { c: [0, 0, 0], w: W - 2, h: Y0, d: 48, col: '#9a9894', r: 0.3 }), crown = box3(C, { c: [0, Y0 + HH, 0], w: W + 2, h: 2.4, d: 52, col: WH, r: 0.4, dec: { f: lam(W + 2, 2.4), t: lam(W + 2, 52) } });
        // the drifting right door: hinge at x 50 on the front, free edge swings out; corners recomputed per key angle and animated as path d
        const AN = [0.07, 0.3, 0.26, 0.07], T = 9, KTd = KT('0;0.35;0.55;1'), SPd = ' calcMode="spline" keySplines="0.3 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1"';
        const dp = (a, t, y, o) => { const dx = -Math.cos(a), dz = Math.sin(a), nx = Math.sin(a), nz = Math.cos(a); return C.P([50 + dx * t + nx * o, y, DZ + dz * t + nz * o]); };
        const qa = (fn) => AN.map(a => fn(a)).join(';');
        const quad = (t0, t1, y0, y1, o0, o1) => a => 'M' + P2(dp(a, t0, y0, o0)) + 'L' + P2(dp(a, t1, y0, o1)) + 'L' + P2(dp(a, t1, y1, o1)) + 'L' + P2(dp(a, t0, y1, o0)) + 'Z';
        const anim = (fn, fill, extra) => `<path d="${fn(AN[0])}" fill="${fill}"${extra || ''}>${an('d', qa(fn), T, 0, KTd + SPd)}</path>`;
        const DY0 = Y0 + 8, DY1 = Y0 + HH - 2;
        const door = anim(quad(49, 49, DY0, DY1, 0, 1.6), '#d8d4cc')
          + anim(quad(0, 49, DY0, DY1, 1.6, 1.6), WH) + anim(quad(1, 48, DY1 - 0.6, DY1 - 1.4, 1.6, 1.6), '#ffffff', ' opacity="0.7"')
          + anim(quad(45.6, 46.8, 74, 100, 2.6, 2.6), '#b4b8bc') + anim(quad(45.6, 46, 74, 100, 2.7, 2.7), '#eef0f2');
        // top: rattan basket + taped cardboard box
        const TY = Y0 + HH + 2.4;
        const bsk = box3(C, decC(C, { c: [-24, TY, 2], w: 30, h: 12, d: 26, col: '#c8a068', r: 1.2, dec: { f: `<rect width="30" height="12" fill="#c8a068"/>${rep(10, i => `<path d="M0 ${f1(1 + i * 1.1)}H30" stroke="#a87c44" stroke-width="0.45"/>`).join('')}${rep(15, i => `<path d="M${f1(1 + i * 2)} 0V12" stroke="#e0bc84" stroke-width="0.5" opacity="0.6"/>`).join('')}<rect width="30" height="1.4" fill="#9a6a34"/>` } }));
        const cbx = box3(C, decC(C, { c: [20, TY, -3], w: 28, h: 16, d: 24, col: '#c8955a', r: 0.3, dec: { f: `<rect width="28" height="16" fill="#c8955a"/><rect x="11" width="6" height="16" fill="#d8c8a0" opacity="0.7"/><path d="M3 6h6M3 8h4" stroke="#3a2a1a" stroke-width="0.4"/>`, t: `<rect width="28" height="24" fill="#d4a46a"/><path d="M0 12H28" stroke="#9a6a34" stroke-width="0.4"/><rect y="10" width="28" height="4" fill="#d8c8a0" opacity="0.7"/>` } }));
        const fr = C.v[2] > 0, tops = (C.v[0] > 0 ? bsk + cbx : cbx + bsk);
        let s = shadow(C, 0, 0, 56, 30, 0.35) + plinth + (fr ? body + crown + tops + door : door + body + crown + tops);
        C.p(-53, 0, -27); C.p(53, 0, 40); C.p(0, TY + 18, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}l" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#c8c4bc" stop-opacity="0.25"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };


    // shared garment-on-hanger art (front-facing, hook at 0 0, y down, ~20 wide); k = shirt | knit | dress | coat | pants; c = cloth colour, hc = hanger colour
    const garm30 = (k, c, hc) => { const d = shade(c, 0.82), l = shade(c, 1.15);
      let o = `<path d="M0 6V2.2Q0 0.2 1.4 0.2Q2.8 0.2 2.8 1.6" stroke="#c8ccd0" stroke-width="0.4" fill="none"/>`;
      const hang = `<path d="M-9.4 7.6Q0 4.4 9.4 7.6" stroke="${hc}" stroke-width="1.2" fill="none" stroke-linecap="round"/>`;
      if (k === 'shirt' || k === 'knit') o += hang + `<path d="M-8.4 7.4L-4 5.8Q0 7.8 4 5.8L8.4 7.4L10.4 28L8.6 28.4L8 15V32H-8V15L-8.6 28.4L-10.4 28Z" fill="${c}"/>`
        + (k === 'shirt' ? `<path d="M-4 5.8L-1.4 10L0 7.6M4 5.8L1.4 10L0 7.6" fill="${l}" stroke="${d}" stroke-width="0.2"/><path d="M0 9V32" stroke="${d}" stroke-width="0.3"/>` : `<path d="M-8 29.6H8M-8 30.8H8M-10.2 26.6l1.8 0.2M10.2 26.6l-1.8 0.2" stroke="${d}" stroke-width="0.5"/><path d="M-3.4 6.4Q0 9.4 3.4 6.4" stroke="${d}" stroke-width="0.9" fill="none"/>`);
      else if (k === 'dress') o += hang + `<path d="M-4 5.8Q0 7.4 4 5.8L5 14L4.2 16Q8 28 11.4 41Q0 43 -11.4 41Q-8 28 -4.2 16L-5 14Z" fill="${c}"/><path d="M-4.6 15.4Q0 16.8 4.6 15.4" stroke="${d}" stroke-width="0.6" fill="none"/><path d="M-2 18Q-3 30 -5 40M2.4 18Q3 30 5.6 40" stroke="${d}" stroke-width="0.5" fill="none" opacity="0.7"/>`;
      else if (k === 'coat') o += hang + `<path d="M-9.4 7.6L-4 5.8L0 12L4 5.8L9.4 7.6L11 38L9.4 38.4L8.6 20V45H-8.6V20L-9.4 38.4L-11 38Z" fill="${c}"/><path d="M-4 5.8L-2 16L0 12M4 5.8L2 16L0 12" fill="${l}" stroke="${d}" stroke-width="0.25"/><path d="M0 12V45" stroke="${d}" stroke-width="0.35"/>${rep(3, i => `<circle cx="1.4" cy="${20 + i * 7}" r="0.55" fill="${d}"/>`).join('')}<path d="M-8 25h4M4 25h4" stroke="${d}" stroke-width="0.4"/>`;
      else o += `<path d="M-9.4 7.6L0 5.4L9.4 7.6" stroke="${hc}" stroke-width="1.2" fill="none" stroke-linecap="round"/><path d="M-7 7.2H7L7.6 31L0.6 31.4L0 14L-0.6 31.4L-7.6 31Z" fill="${c}"/><path d="M-7 7.2H7V9H-7Z" fill="${l}"/><path d="M0 14V31" stroke="${d}" stroke-width="0.3"/>`;
      return o + `<path d="M-3 12Q-2 22 -4 32M3.4 13Q2.6 24 4.4 34" stroke="#ffffff" stroke-width="0.7" fill="none" opacity="0.12"/>`; };

    // BED-053 SLIDING MIRRORED-DOOR REACH-IN CLOSET (T3): a built-in reach-in closet in white with a pale oak fascia, two full-height bypass doors of
    // bevelled mirror in slim brushed-aluminium frames running on top and floor tracks. Behind: a warm-lit interior with an oak hanging rail of shirts,
    // knits, a dress and a coat, a shelf of folded sweaters and storage boxes, a warm LED strip under the shelf and a slanted shoe rack. w 106 d 54 kept.
    // Live: the front mirror door glides open to the left and back, and a glint slides down the glass.
    N.reach30 = S => { const D = { w: 106, d: 54, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('reach30'), id = C.u('c53'), W = 104, HH = 160, OK = '#d8b888', AL = '#c4c8cc', DZ = 25;
        const iv = (() => { let o = `<rect width="${W}" height="${HH}" fill="#f6f4ef"/><rect x="2" y="12" width="${W - 4}" height="${HH - 18}" fill="url(#${id}i)"/>`;
          o += `<rect x="2" y="28" width="${W - 4}" height="2.4" fill="${OK}"/><rect x="2" y="30.4" width="${W - 4}" height="1.4" fill="#ffe6b0" opacity="0.8"/><rect x="2" y="30" width="${W - 4}" height="10" fill="url(#${id}g)"/>`;
          // folded sweater stacks + boxes on the shelf
          [[8, ['#c86a5a', '#e8d8b8', '#6a8aa8', '#d8c8a8']], [26, ['#8a9a7a', '#f0e6d4', '#b88a6a']], [64, ['#4a5a7a', '#c8b098', '#e8c8c0', '#9a7a9a']]].forEach(([x, cs]) => cs.forEach((c, i) => o += `<rect x="${x}" y="${f1(27.6 - (i + 1) * 3.2)}" width="13" height="3" rx="1.2" fill="${c}"/><path d="M${x + 1} ${f1(27.6 - (i + 1) * 3.2 + 1.5)}h11" stroke="${shade(c, 0.85)}" stroke-width="0.25"/>`));
          o += `<rect x="44" y="18" width="15" height="9.6" fill="#e8e2d6"/><rect x="44" y="18" width="15" height="1.6" fill="#d8d0c2"/><rect x="48" y="21" width="7" height="3" fill="#ffffff"/><rect x="82" y="16" width="17" height="11.6" fill="#c8a878"/><rect x="82" y="16" width="17" height="2" fill="#b8925e"/>`;
          o += `<rect x="3" y="36" width="${W - 6}" height="1.4" rx="0.7" fill="${OK}"/>`;
          [['shirt', '#f2efe8'], ['knit', '#c8a074'], ['shirt', '#9ab4d0'], ['dress', '#2a2a34'], ['shirt', '#e8b8b0'], ['coat', '#b8885a'], ['knit', '#7a8a6a'], ['shirt', '#ffffff'], ['dress', '#a85a6a'], ['coat', '#4a5260']].forEach(([kk, c], i) => o += `<g transform="translate(${f1(9 + i * 9.4)} 35.8) scale(1.05)">${garm30(kk, c, '#c8a878')}</g>`);
          o += `<path d="M4 ${HH - 18}L${W - 4} ${HH - 18}M4 ${HH - 11}L${W - 4} ${HH - 11}" stroke="${OK}" stroke-width="1"/>` + rep(6, i => { const x = 8 + i * 15.6, c = ['#3a2a22', '#e8e0d4', '#a8342a', '#2a2a2a', '#c89a6a', '#6a7a9a'][i]; return `<path d="M${x} ${HH - 18.6}l2 -3.6h4.4l1.6 3.6Z" fill="${c}"/><path d="M${x + 7} ${HH - 18.6}l2 -3.6h4.4l1.6 3.6Z" fill="${shade(c, 0.9)}"/><path d="M${x + 1} ${HH - 11.6}h7v-2.4q-3 -1 -7 0Z" fill="${shade(c, 0.85)}"/>`; }).join('');
          o += `<rect x="2" y="12" width="${W - 4}" height="${HH - 18}" fill="url(#${id}v)"/>`;
          o += `<rect width="${W}" height="12" fill="${OK}"/>${grainV(R, W, 12, 30, '#b8925e', 0.35)}<rect y="11.4" width="${W}" height="0.6" fill="#8a6a40" opacity="0.5"/><rect x="2" y="12" width="${W - 4}" height="1.2" fill="${AL}"/><rect x="2" y="${HH - 6}" width="${W - 4}" height="1.4" fill="${AL}"/><rect y="${HH - 4.6}" width="${W}" height="4.6" fill="#e8e4dc"/>`;
          return o; })();
        const body = box3(C, decC(C, { c: [0, 0, 0], w: W, h: HH, d: 50, col: '#f2f0ea', r: 0.4, dec: { f: iv, l: `<rect width="50" height="${HH}" fill="#ecebe6"/>`, r: `<rect width="50" height="${HH}" fill="#ecebe6"/>`, t: `<rect width="${W}" height="50" fill="${OK}"/>` + grainV(R, W, 50, 40, '#b8925e', 0.3) } }));
        // mirror doors (rear track fixed on the left, front track slides from the right to the left)
        const DW = 51, DH = HH - 18.6, mir = (x0, z) => { const mid = C.u('md'), gl = `<rect x="0" y="-14" width="${DW}" height="7" fill="url(#${id}s)" transform="skewY(-14)">${an('y', `-14;${DH + 14}`, 11, x0 > 0 ? -5 : 0)}</rect>`;
          return `<g transform="${FR(C, [x0, HH - 12.6, z], [1, 0, 0], [0, -1, 0])}"><rect width="${DW}" height="${DH}" fill="${AL}"/><clipPath id="${mid}"><rect x="1.4" y="1.4" width="${DW - 2.8}" height="${DH - 2.8}"/></clipPath><g clip-path="url(#${mid})"><g transform="translate(1.4 1.4)">${refl30(mid, DW - 2.8, DH - 2.8, { wx: x0 > 0 ? 0.2 : 0.62, top: '#e6ded2', mid: '#d6ccbe', floor: '#a4886a' })}${gl}</g></g>`
            + `<rect x="1.4" y="1.4" width="${DW - 2.8}" height="${DH - 2.8}" fill="none" stroke="#ffffff" stroke-width="0.5" opacity="0.6"/><rect x="0.3" width="0.5" height="${DH}" fill="#eef0f2"/><rect x="${DW - 0.8}" width="0.5" height="${DH}" fill="#8a8e92"/><rect x="${x0 > 0 ? 2.4 : DW - 3.4}" y="${f1(DH * 0.4)}" width="1" height="20" rx="0.5" fill="#9a9ea2"/></g>`; };
        const p0 = C.P([0, 0, DZ]), p1 = C.P([-46, 0, DZ]), dv = [p1[0] - p0[0], p1[1] - p0[1]];
        const doors = mir(-50.4, DZ + 0.8) + `<g>${at('translate', `${f1(dv[0])} ${f1(dv[1])};${f1(dv[0])} ${f1(dv[1])};0 0;0 0;${f1(dv[0])} ${f1(dv[1])}`, 16, 0, ' calcMode="spline" keyTimes="0;0.3;0.5;0.8;1" keySplines="0 0 1 1;0.45 0 0.55 1;0 0 1 1;0.45 0 0.55 1"')}${mir(-0.6, DZ + 2)}</g>`;
        const fr = C.v[2] > 0;
        let s = shadow(C, 0, 0, 56, 30, 0.35) + (fr ? body + doors : doors + body);
        C.p(-53, 0, -27); C.p(53, 0, 27); C.p(0, HH + 2, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}i" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f2e2c8"/><stop offset="0.4" stop-color="#e2d0b4"/><stop offset="1" stop-color="#c8b494"/></linearGradient>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.5"/><stop offset="1" stop-color="#ffe2a8" stop-opacity="0"/></linearGradient>`
          + `<linearGradient id="${id}v" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3a2a1a" stop-opacity="0.25"/><stop offset="0.15" stop-color="#3a2a1a" stop-opacity="0"/><stop offset="0.85" stop-color="#3a2a1a" stop-opacity="0"/><stop offset="1" stop-color="#3a2a1a" stop-opacity="0.25"/></linearGradient>`
          + `<linearGradient id="${id}s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.4"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-073 CUSTOM WALK-IN BOUTIQUE CLOSET WITH ILLUMINATED ISLAND (T4): a boutique wall of figured walnut with a champagne-gold crown and warm LED
    // coves: a hanging bay of silk dresses and a camel coat, a centre bay of lit glass cubbies holding handbags, and a bay of angled lit shoe shelves,
    // drawers below. In front, a walnut island with a glass top glows over a navy velvet tray of watches, rings and a pendant, with champagne pulls and a
    // light under the plinth; a white orchid and a handbag sit on top. w 106 d 54 kept. Live: the island glows and its jewels twinkle, the cubby lights
    // pass a soft wave along the wall, the dresses sway.
    N.walk30 = S => { const D = { w: 106, d: 54, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('walk30'), id = C.u('w73'), k = C.k, WN = '#6a4428', GD = '#d8b46a', W = 104, HH = 150, BZ = -19;
        const wal = (w, h) => `<rect width="${w}" height="${h}" fill="${WN}"/>` + grainV(R, w, h, Math.max(4, Math.round(w * 0.8)), '#4a2c18', 0.5);
        const bay = (x, w) => `<rect x="${x}" y="12" width="${w}" height="112" fill="url(#${id}b)"/><rect x="${x}" y="12" width="${w}" height="3" fill="#fff0c8" opacity="0.9"/><rect x="${x}" y="12" width="${w}" height="112" fill="url(#${id}v)"/>`;
        let f = wal(W, HH) + bay(4, 31) + bay(37, 30) + bay(69, 31);
        // left bay: dresses + coat, swaying
        [['dress', '#e8b8b0', 8], ['coat', '#b8885a', 15], ['dress', '#1e1e28', 22], ['dress', '#e8dcc8', 29]].forEach(([kk, c, x], i) => f += `<g transform="translate(${x} 17)"><g>${at('rotate', `-1.6 1.4 0.2;1.6 1.4 0.2;-1.6 1.4 0.2`, 4 + i * 0.6, -i, SPL(2))}<g transform="scale(0.95)">${garm30(kk, c, GD)}</g></g></g>`);
        f += `<rect x="5" y="16.4" width="29" height="1.2" rx="0.6" fill="${GD}"/>`;
        // centre bay: 4 glass shelves with lit cubby glows (wave) and handbags
        const bags = [['#c8342a', 0], ['#e8dcc8', 1], ['#2a2a2a', 2], ['#d8a85a', 0], ['#7a9a8a', 1], ['#f0c8c8', 2], ['#5a3a2a', 1], ['#e8e4dc', 0]];
        for (let r = 0; r < 4; r++) { const y = 38 + r * 27; f += `<rect x="37" y="${y - 25}" width="30" height="25" fill="#ffe2a8" opacity="0">${an('opacity', '0;0.35;0', 6, -r * 0.8)}</rect><rect x="37" y="${y}" width="30" height="1" fill="#e8f4f0" opacity="0.7"/><rect x="37" y="${y + 1}" width="30" height="0.4" fill="#ffffff" opacity="0.5"/>`;
          [0, 1].forEach(j => { const [c, t] = bags[r * 2 + j], x = 44 + j * 15;
            f += t === 0 ? `<path d="M${x - 5} ${y}L${x - 4} ${y - 8}H${x + 4}L${x + 5} ${y}Z" fill="${c}"/><path d="M${x - 2.6} ${y - 8}Q${x} ${y - 13} ${x + 2.6} ${y - 8}" stroke="${shade(c, 0.8)}" stroke-width="0.7" fill="none"/><rect x="${x - 1}" y="${y - 6.4}" width="2" height="1.2" fill="${GD}"/>`
              : t === 1 ? `<rect x="${x - 5.4}" y="${y - 7}" width="10.8" height="7" rx="1.6" fill="${c}"/><path d="M${x - 5.4} ${y - 4.4}Q${x} ${y - 2} ${x + 5.4} ${y - 4.4}" stroke="${shade(c, 0.8)}" stroke-width="0.4" fill="none"/><circle cx="${x}" cy="${y - 3.4}" r="0.7" fill="${GD}"/>`
              : `<path d="M${x - 4} ${y}Q${x - 5} ${y - 7} ${x} ${y - 7}Q${x + 5} ${y - 7} ${x + 4} ${y}Z" fill="${c}"/><path d="M${x - 2} ${y - 7}Q${x} ${y - 10} ${x + 2} ${y - 7}" stroke="${GD}" stroke-width="0.5" fill="none"/>`; }); }
        // right bay: angled lit shoe shelves
        for (let r = 0; r < 5; r++) { const y = 34 + r * 20; f += `<path d="M69 ${y}L100 ${y - 4}V${y - 3}L69 ${y + 1}Z" fill="#e8f4f0" opacity="0.6"/><path d="M69 ${y + 1}L100 ${y - 3}" stroke="#ffe2a8" stroke-width="0.6" opacity="0.8"/>`;
          [0, 1, 2].forEach(j => { const x = 73 + j * 9.6, yy = y - j * 1.24 - 0.4, c = ['#c8342a', '#e8dcc8', '#2a2a2a', '#d8a85a', '#f0c8c8', '#5a3a2a', '#7a8aa8'][(r * 3 + j) % 7];
            f += (r + j) % 2 ? `<path d="M${x} ${yy}L${x + 1} ${yy - 4}Q${x + 4} ${yy - 4.4} ${x + 6.4} ${yy - 1.2}L${x + 6.4} ${yy}Z" fill="${c}"/><path d="M${x + 0.6} ${yy}V${yy + 0.01}L${x + 1.2} ${yy - 2.6}" stroke="${shade(c, 0.7)}" stroke-width="0.5"/>`
              : `<path d="M${x} ${yy}V${yy - 2.6}Q${x + 2} ${yy - 3.4} ${x + 4} ${yy - 2.6}Q${x + 6.4} ${yy - 2} ${x + 6.6} ${yy}Z" fill="${c}"/><path d="M${x} ${yy}H${x + 6.6}" stroke="${shade(c, 0.6)}" stroke-width="0.5"/>`; }); }
        // crown, LED cove, pilasters gold lines, drawers
        f += `<rect width="${W}" height="9" fill="${GD}"/><rect width="${W}" height="2" fill="#fff0c0" opacity="0.6"/><rect y="8" width="${W}" height="1" fill="#8a6a30"/><rect y="9" width="${W}" height="4" fill="#ffe2a8" opacity="0.5" filter="url(#m12b1)"/>`
          + [3.4, 35.8, 67.8, 100.2].map(x => `<rect x="${x}" y="12" width="0.5" height="112" fill="${GD}" opacity="0.8"/>`).join('')
          + rep(3, i => `<rect x="${4 + i * 32.6}" y="127" width="31" height="19" fill="${shade(WN, 1.08)}" stroke="#3a2414" stroke-width="0.3"/><rect x="${16 + i * 32.6}" y="135.6" width="7" height="1" rx="0.5" fill="${GD}"/>`).join('');
        const wall = box3(C, decC(C, { c: [0, 0, BZ], w: W, h: HH, d: 16, col: WN, r: 0.3, dec: { f, l: wal(16, HH), r: wal(16, HH), t: wal(W, 16) } }));
        // island
        const IW = 52, ID = 24, IH = 34, IZ = 12;
        const jew = `<rect width="${IW + 4}" height="${ID + 4}" fill="#2a3450"/>` + [1, 2, 3].map(i => `<path d="M${f1(i * (IW + 4) / 4)} 2V${ID + 2}" stroke="#1a2238" stroke-width="0.6"/>`).join('')
          + [7, 21].map((x, i) => `<rect x="${x - 1.4}" y="7" width="2.8" height="14" rx="1" fill="${i ? '#8a5a3a' : '#c8b088'}"/><circle cx="${x}" cy="14" r="3.6" fill="${GD}"/><circle cx="${x}" cy="14" r="2.8" fill="#f4f0e8"/><path d="M${x} 14l0 -2M${x} 14l1.4 0.6" stroke="#2a2a2a" stroke-width="0.25"/>`).join('')
          + [[32, 9, '#e8f4ff'], [37, 13, '#d82a4a'], [33, 18, '#4a8ad8'], [39, 20, '#e8f4ff']].map(([x, y, g]) => `<circle cx="${x}" cy="${y}" r="1.6" fill="none" stroke="${GD}" stroke-width="0.6"/><circle cx="${x}" cy="${y - 1.6}" r="0.8" fill="${g}"/>`).join('')
          + `<path d="M45 6Q50 16 54 6" stroke="${GD}" stroke-width="0.35" fill="none"/><path d="M49.6 11.6l0.9 1.6l-0.9 1.6l-0.9 -1.6Z" fill="#e8f4ff"/>`
          + [[37, 13, 0], [49.6, 13, 1.6], [7, 11, 3.2], [33, 18, 4.4]].map(([x, y, b]) => `<path d="M${x} ${y - 1.6}l0.3 1.3l1.3 0.3l-1.3 0.3l-0.3 1.3l-0.3 -1.3l-1.3 -0.3l1.3 -0.3Z" fill="#ffffff" opacity="0">${an('opacity', '0;0;1;0;0', 6, -b, KT('0;0.5;0.56;0.64;1'))}</path>`).join('')
          + `<rect width="${IW + 4}" height="${ID + 4}" fill="url(#${id}g)"/><rect width="${IW + 4}" height="${ID + 4}" fill="#ffe8b8" opacity="0.1">${an('opacity', '0.04;0.16;0.04', 5, 0, SPL(2))}</rect>`;
        const ifr = wal(IW, IH) + rep(2, i => `<rect x="${2 + i * 24.6}" y="3" width="23.4" height="12" fill="${shade(WN, 1.08)}" stroke="#3a2414" stroke-width="0.3"/><rect x="${2 + i * 24.6}" y="17" width="23.4" height="12" fill="${shade(WN, 1.08)}" stroke="#3a2414" stroke-width="0.3"/><rect x="${10 + i * 24.6}" y="8.6" width="7.4" height="1" rx="0.5" fill="${GD}"/><rect x="${10 + i * 24.6}" y="22.6" width="7.4" height="1" rx="0.5" fill="${GD}"/>`).join('') + `<rect y="${IH - 3}" width="${IW}" height="3" fill="#2a1a10"/><rect y="${IH - 3}" width="${IW}" height="1" fill="#ffe2a8" opacity="0.8"/>`;
        const isl = `<g filter="url(#m12b1)" opacity="0.7">${an('opacity', '0.5;0.8;0.5', 5, 0, SPL(2))}<g transform="${FR(C, [0, 0.1, IZ], [1, 0, 0], [0, 0, 1])}"><ellipse rx="${IW * 0.62}" ry="${ID * 0.75}" fill="#ffe0a0" opacity="0.45"/></g></g>`
          + box3(C, decC(C, { c: [0, 0, IZ], w: IW, h: IH, d: ID, col: WN, r: 0.4, dec: { f: ifr, b: wal(IW, IH), l: wal(ID, IH), r: wal(ID, IH) } }))
          + box3(C, { c: [0, IH, IZ], w: IW + 4, h: 1.4, d: ID + 4, col: '#dfe8e4', r: 0.3, dec: { t: jew, f: `<rect width="${IW + 4}" height="1.4" fill="#cfe0da"/>` } });
        // orchid + handbag on the island
        const op = C.P([15, IH + 1.4, IZ - 4]), bp = C.P([-14, IH + 1.4, IZ + 2]);
        const orchid = `<g transform="translate(${P2(op)}) scale(${n4(k)})"><path d="M-2.6 0L-2.2 -5H2.2L2.6 0Z" fill="#f4f2ee"/><ellipse cx="-2.4" cy="-5.6" rx="3" ry="1" fill="#3a6a3a" transform="rotate(-20 -2.4 -5.6)"/><ellipse cx="2.4" cy="-5.4" rx="3" ry="1" fill="#4a7a44" transform="rotate(16 2.4 -5.4)"/>`
          + `<g>${at('rotate', '-2 0 -5;2 0 -5;-2 0 -5', 5, 0, SPL(2))}<path d="M0 -5Q0.6 -14 4 -18" stroke="#5a6a3a" stroke-width="0.35" fill="none"/>${[[1, -13], [2.6, -16], [4.2, -18.6]].map(([x, y]) => `<g transform="translate(${x} ${y})">${rep(5, i => `<ellipse cy="-1" rx="0.9" ry="1.3" fill="#ffffff" transform="rotate(${i * 72})"/>`).join('')}<circle r="0.5" fill="#e88aa8"/></g>`).join('')}</g></g>`;
        const hbag = `<g transform="translate(${P2(bp)}) scale(${n4(k)})"><path d="M-6 0L-5 -8H5L6 0Z" fill="#c8342a"/><path d="M-6 0L-5 -8H5L6 0Z" fill="url(#${id}h)"/><path d="M-3 -8Q0 -14 3 -8" stroke="#8a2018" stroke-width="0.8" fill="none"/><path d="M-5.4 -5.6H5.4" stroke="#8a2018" stroke-width="0.3"/><rect x="-1.2" y="-6.4" width="2.4" height="1.6" fill="${GD}"/></g>`;
        const fr = C.v[2] > 0, top = C.v[0] > 0 ? hbag + orchid : orchid + hbag;
        let s = shadow(C, 0, BZ, 56, 12, 0.3) + shadow(C, 0, IZ, 32, 16, 0.3) + (fr ? wall + isl + top : isl + top + wall);
        C.p(-53, 0, -27); C.p(53, 0, 27); C.p(0, HH + 2, BZ);
        return { defs: DEF19 + `<defs><linearGradient id="${id}b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f6e2c2"/><stop offset="0.5" stop-color="#d8b890"/><stop offset="1" stop-color="#a88460"/></linearGradient>`
          + `<linearGradient id="${id}v" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2a1a0a" stop-opacity="0.3"/><stop offset="0.2" stop-color="#2a1a0a" stop-opacity="0"/><stop offset="0.8" stop-color="#2a1a0a" stop-opacity="0"/><stop offset="1" stop-color="#2a1a0a" stop-opacity="0.3"/></linearGradient>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.15"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>`
          + `<linearGradient id="${id}h" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000000" stop-opacity="0.2"/><stop offset="0.4" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="1" stop-color="#000000" stop-opacity="0.15"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-093 AI AUTOMATED CAROUSEL WARDROBE WITH VIRTUAL OUTFIT MIRROR (T5): a tall ivory lacquer wardrobe with champagne-gold pinstripes, crown and plinth.
    // Its wide open bay is a warm-lit conveyor: garments ride a gold oval track, the front row gliding one way and the back row the other, under a soft
    // spotlight where the chosen piece stops. The right panel is a virtual outfit mirror: a dress form overlay tries on the outfits in turn beside swatches
    // and a breathing AI ring. w 106 d 54 kept. Live: the carousel turns, the mirror cycles outfits, a scan line sweeps and the status ring breathes.
    N.caro30 = S => { const D = { w: 106, d: 54, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('w93'), IV = '#f4efe4', GD = '#d6b26a', W = 104, HH = 160;
        const BX = 5, BW = 62, BY = 16, BH = 128, cid = C.u('bk'), SP = 17, T = 22;
        const KS = [['shirt', '#f2efe8'], ['dress', '#e8b8b0'], ['coat', '#c8a074'], ['knit', '#7a8a9a'], ['dress', '#2a2a34'], ['shirt', '#a8c0d8'], ['coat', '#5a4a4a'], ['knit', '#e8d8b8']];
        const row = (sc, dir, y, op, off) => { const L = KS.length * SP; let g = ''; for (let i = -2 * KS.length; i < KS.length; i++) { const [kk, c] = KS[(((i + off) % KS.length) + KS.length) % KS.length]; g += `<g transform="translate(${f1(BX + 6 + i * SP)} ${y}) scale(${sc})">${garm30(kk, c, GD)}</g>`; }
          return `<g opacity="${op}"><g>${at('translate', dir > 0 ? `0 0;${L} 0` : `${L} 0;0 0`, T * (dir > 0 ? 1 : 1.3))}${g}</g></g>`; };
        let f = `<rect width="${W}" height="${HH}" fill="${IV}"/><rect width="${W}" height="${HH}" fill="url(#${id}l)"/>`;
        f += `<clipPath id="${cid}"><rect x="${BX}" y="${BY}" width="${BW}" height="${BH}" rx="2"/></clipPath><g clip-path="url(#${cid})"><rect x="${BX}" y="${BY}" width="${BW}" height="${BH}" fill="url(#${id}b)"/>`
          + `<ellipse cx="${BX + BW / 2}" cy="${BY + 7}" rx="${BW / 2 - 3}" ry="3.4" fill="none" stroke="${GD}" stroke-width="1"/>` + row(1.3, -1, BY + 4, 0.55, 3) + `<rect x="${BX}" y="${BY}" width="${BW}" height="${BH}" fill="#2a1e14" opacity="0.25"/>` + row(1.75, 1, BY + 9, 1, 0)
          + `<path d="M${BX + BW / 2 - 6} ${BY}L${BX + BW / 2 + 6} ${BY}L${BX + BW / 2 + 16} ${BY + BH}H${BX + BW / 2 - 16}Z" fill="url(#${id}c)"/><rect x="${BX}" y="${BY + BH - 14}" width="${BW}" height="14" fill="url(#${id}f)"/>`
          + `<rect x="${BX}" y="${BY}" width="${BW}" height="${BH}" fill="url(#${id}v)"/></g><rect x="${BX}" y="${BY}" width="${BW}" height="${BH}" rx="2" fill="none" stroke="${GD}" stroke-width="0.7"/>`;
        // virtual mirror panel
        const MX = 71, MW = 29, mk = C.u('vm');
        const FIG = 'M-2 -40H2L3 -35L8 -33L5.6 -24L4 -23Q8 -12 12 -1Q0 1.4 -12 -1Q-8 -12 -4 -23L-5.6 -24L-8 -33L-3 -35Z';
        f += `<clipPath id="${mk}"><rect x="${MX}" y="${BY}" width="${MW}" height="${BH}" rx="1.6"/></clipPath><g clip-path="url(#${mk})"><g transform="translate(${MX} ${BY})">${refl30(mk, MW, BH, { wx: 0.1, top: '#e8e0d2', mid: '#dcd2c0', floor: '#a48a6c' })}</g>`
          + `<g transform="translate(${MX + MW / 2} ${BY + 100}) scale(1.6)"><path d="${FIG}" fill="#e8b8b0" fill-opacity="0.5" stroke="#fff4dc" stroke-width="0.3">${an('fill', '#e8b8b0;#c8a074;#7a8a9a;#2a2a34;#e8b8b0', 16, 0, ' calcMode="discrete" keyTimes="0;0.25;0.5;0.75;1"')}</path><path d="M0 -40V-42.6" stroke="#fff4dc" stroke-width="0.4"/></g>`
          + `<rect x="${MX}" y="${BY}" width="${MW}" height="0.6" fill="#fff4d0" opacity="0.7">${an('y', `${BY + BH};${BY}`, 4)}</rect>`
          + rep(4, i => `<circle cx="${MX + 5 + i * 6.4}" cy="${BY + BH - 8}" r="2" fill="${['#e8b8b0', '#c8a074', '#7a8a9a', '#2a2a34'][i]}" stroke="#fff6e0" stroke-width="0.3"/>`).join('')
          + `<circle cx="${MX + 5}" cy="${BY + BH - 8}" r="2.8" fill="none" stroke="#fff6e0" stroke-width="0.4">${an('cx', [0, 1, 2, 3, 0].map(i => MX + 5 + i * 6.4).join(';'), 16, 0, ' calcMode="discrete" keyTimes="0;0.25;0.5;0.75;1"')}</circle>`
          + `<g transform="translate(${MX + MW - 5} ${BY + 6})"><circle r="2.6" fill="none" stroke="${GD}" stroke-width="0.5"/><circle r="1.4" fill="#ffe2a8">${an('r', '1;1.8;1', 3, 0, SPL(2))}${an('opacity', '0.6;1;0.6', 3, 0, SPL(2))}</circle></g><rect x="${MX + 3}" y="${BY + 4}" width="10" height="0.9" rx="0.45" fill="#fff6e0" opacity="0.6"/><rect x="${MX + 3}" y="${BY + 6.4}" width="6" height="0.6" rx="0.3" fill="#fff6e0" opacity="0.4"/>`
          + `</g><rect x="${MX}" y="${BY}" width="${MW}" height="${BH}" rx="1.6" fill="none" stroke="${GD}" stroke-width="0.8"/>`;
        f += `<rect width="${W}" height="8" fill="${GD}"/><rect width="${W}" height="2" fill="#fff0c0" opacity="0.6"/><rect y="${HH - 10}" width="${W}" height="10" fill="${shade(IV, 0.94)}"/><rect y="${HH - 10}" width="${W}" height="0.8" fill="${GD}"/><rect y="${HH - 3}" width="${W}" height="3" fill="${GD}"/>`
          + `<rect x="2" y="10" width="${W - 4}" height="${HH - 22}" fill="none" stroke="${GD}" stroke-width="0.35"/><circle cx="${W / 2}" cy="${HH - 5.4}" r="0.8" fill="#ffd890">${an('opacity', '0.3;1;0.3', 2.4)}</circle>`;
        const sd = (w, h) => `<rect width="${w}" height="${h}" fill="${IV}"/><rect width="${w}" height="${h}" fill="url(#${id}l)"/><rect x="2" y="10" width="${w - 4}" height="${h - 22}" fill="none" stroke="${GD}" stroke-width="0.35"/><rect width="${w}" height="8" fill="${GD}"/><rect y="${h - 3}" width="${w}" height="3" fill="${GD}"/>`;
        const body = box3(C, decC(C, { c: [0, 0, 0], w: W, h: HH, d: 50, col: IV, r: 0.6, dec: { f, l: sd(50, HH), r: sd(50, HH), t: `<rect width="${W}" height="50" fill="${GD}"/><rect x="2" y="2" width="${W - 4}" height="46" fill="${IV}"/>` } }));
        const glow = `<g filter="url(#m12b1)" opacity="0.6"><g transform="${FR(C, [-16, 0.1, 30], [1, 0, 0], [0, 0, 1])}"><ellipse rx="26" ry="6" fill="#ffe0a0" opacity="0.5"/></g></g>`;
        let s = shadow(C, 0, 0, 56, 30, 0.35) + body + (C.v[2] > 0 ? glow : '');
        C.p(-53, 0, -27); C.p(53, 0, 27); C.p(0, HH + 2, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}l" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="0.45" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#b8a888" stop-opacity="0.2"/></linearGradient>`
          + `<linearGradient id="${id}b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f0dcc0"/><stop offset="0.6" stop-color="#b8987a"/><stop offset="1" stop-color="#7a6048"/></linearGradient>`
          + `<linearGradient id="${id}c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff2d0" stop-opacity="0.45"/><stop offset="1" stop-color="#fff2d0" stop-opacity="0"/></linearGradient>`
          + `<linearGradient id="${id}f" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.45"/><stop offset="1" stop-color="#ffe2a8" stop-opacity="0"/></linearGradient>`
          + `<linearGradient id="${id}v" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2a1a0a" stop-opacity="0.4"/><stop offset="0.18" stop-color="#2a1a0a" stop-opacity="0"/><stop offset="0.82" stop-color="#2a1a0a" stop-opacity="0"/><stop offset="1" stop-color="#2a1a0a" stop-opacity="0.4"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };


    // ======================= PET BEDS (BED-014/034/054..): floor pieces, petbed 70 x 60 round footprint kept =======================
    // BED-014 SHOEBOX LINED WITH A HAND TOWEL (T1): an old brown cardboard shoebox, one corner crushed, a strip of masking tape across the front with a
    // scribbled name and a heart, lined with a faded striped hand towel whose frayed corner flops over the front edge. The lid lies behind it, a chewed
    // tennis ball and a knotted sock toy wait beside it. Live: the tennis ball rocks a little and the towel corner stirs.
    N.shoe30 = S => { const D = { w: 70, d: 60, round: 1, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('shoe30'), id = C.u('p14'), k = C.k, CB = '#c4935c', BW = 46, BD = 30, BH = 13, T = 0.8;
        const card = (w, h, o) => `<rect width="${w}" height="${h}" fill="${CB}"/>` + rep(Math.round(w / 3), () => `<path d="M${f1(R() * w)} 0v${h}" stroke="#a87a48" stroke-width="0.12" opacity="0.4"/>`).join('') + (o || '');
        const fT = card(BW, BH, `<path d="M0 0.6H${BW}" stroke="#a87a48" stroke-width="0.3"/><g transform="translate(10 4.4) rotate(-3)"><rect width="20" height="3.6" fill="#ece0b8" opacity="0.92"/><path d="M2 2.2q1 -1.4 2 0t2 0t2 0q1 -1.6 2.4 -0.2" stroke="#3a3a8a" stroke-width="0.35" fill="none"/><path d="M15.4 1.4q0.7 -0.8 1.2 0q0.5 -0.8 1.2 0q0 1 -1.2 1.8q-1.2 -0.8 -1.2 -1.8Z" fill="#d84a5a"/></g>`
          + `<path d="M${BW - 7} 0L${BW - 4} 3.4L${BW} 4" stroke="#8a6034" stroke-width="0.35" fill="none"/><path d="M${BW - 7} 0L${BW} 0V4L${BW - 4} 3.4Z" fill="#000000" opacity="0.12"/><rect x="2" y="${BH - 3}" width="8" height="1.4" fill="#2a2a2a" opacity="0.18"/>`);
        const wall = (c, w, h, d, dec) => box3(C, { c, w, h, d, col: CB, r: 0.2, dec });
        const back = wall([0, 0, -BD / 2 + T / 2], BW, BH, T, { f: card(BW, BH), b: card(BW, BH) }), front = wall([0, 0, BD / 2 - T / 2], BW, BH, T, { f: fT, b: card(BW, BH) });
        const sides = [-1, 1].map(sx => ({ x: sx, s: wall([sx * (BW / 2 - T / 2), 0, 0], T, BH, BD - 2 * T, { l: card(BD, BH), r: card(BD, BH) }) }));
        sides.sort((a, b) => (a.x - b.x) * (C.v[0] >= 0 ? -1 : 1));
        // towel: terry plane sagging inside + frayed flap over the front edge
        const terry = (w, d) => `<rect width="${w}" height="${d}" fill="#d8c8b4"/>` + rep(Math.round(d / 0.7), i => `<path d="M0 ${f1(i * 0.7)}H${w}" stroke="#c4b29a" stroke-width="0.25" stroke-dasharray="0.3 0.3" opacity="0.7"/>`).join('') + `<rect y="${f1(d * 0.3)}" width="${w}" height="2.2" fill="#8aa8b8" opacity="0.7"/><rect y="${f1(d * 0.3 + 2.8)}" width="${w}" height="0.8" fill="#8aa8b8" opacity="0.6"/>`
          + `<path d="M4 4Q12 9 22 6T40 8M6 18Q16 14 28 19T42 16" stroke="#a8967c" stroke-width="0.5" fill="none" opacity="0.5"/>`;
        const towel = `<g transform="${FR(C, [-BW / 2 + T, 5, -BD / 2 + T], [1, 0, 0], [0, 0, 1])}">${terry(BW - 2 * T, BD - 2 * T)}<rect width="${BW - 2 * T}" height="${BD - 2 * T}" fill="url(#${id}s)"/></g>`;
        const flap = `<g transform="${FR(C, [-BW / 2 + 4, BH + 0.4, BD / 2 + 0.1], [1, 0, 0], [0, -1, 0])}"><g>${at('skewX', '0;3;-1;0', 5, 0, SPL(3))}<path d="M0 0H16L15 3Q13 7 9 9L4 8Q1 5 0 0Z" fill="#d8c8b4"/><rect y="1.6" width="15.6" height="1.6" fill="#8aa8b8" opacity="0.7"/>${rep(10, i => `<path d="M${f1(4 + i * 0.6)} ${f1(8 - (i % 3) * 0.2)}l${f1(R() - 0.5)} 1.4" stroke="#c4b29a" stroke-width="0.25"/>`).join('')}<path d="M0 0H16" stroke="#e8dcc8" stroke-width="0.8"/></g></g>`;
        const rimTowel = `<g transform="${FR(C, [-BW / 2, BH + 0.2, -BD / 2], [1, 0, 0], [0, 0, 1])}"><rect width="${BW}" height="1.6" rx="0.8" fill="#d8c8b4"/><rect x="${BW - 1.6}" width="1.6" height="${BD}" rx="0.8" fill="#d0c0aa"/></g>`;
        // lid lying behind at an angle
        const lid = box3(C, { c: [-6, 0, -BD / 2 - 9], w: BW + 2, h: 3, d: BD + 2, col: CB, r: 0.3, ax: [[Math.cos(0.25), 0, -Math.sin(0.25)], [0, 1, 0], [Math.sin(0.25), 0, Math.cos(0.25)]], dec: { t: card(BW + 2, BD + 2, `<rect x="4" y="4" width="14" height="8" fill="#f2ece0" opacity="0.8"/><path d="M6 7h9M6 9h6" stroke="#8a7a6a" stroke-width="0.4"/>`) } });
        // tennis ball (rocks) + knotted sock
        const bp = C.P([BW / 2 + 7, 3.2, 10]), ball = `<g transform="translate(${P2(bp)}) scale(${n4(k)})"><g>${at('rotate', '-12;14;-6;10;-12', 4, 0, SPL(4))}<circle r="3.2" fill="#cfe04a"/><circle r="3.2" fill="url(#${id}b)"/><path d="M-2.6 -1.8Q0 0 -2.6 1.8M2.6 -1.8Q0 0 2.6 1.8" stroke="#f4f4e0" stroke-width="0.5" fill="none"/><path d="M-1 -2.6l0.6 0.5M1.4 1.6l-0.6 0.6" stroke="#8a9a3a" stroke-width="0.3"/></g></g>`;
        const sp = C.P([-BW / 2 - 6, 0.6, 12]), sock = `<g transform="translate(${P2(sp)}) scale(${n4(k)})"><path d="M-6 0Q-6 -2.4 -3 -2.2L2 -2.4Q4.6 -2.8 5 -0.4Q5 0.6 3 0.6H-5Z" fill="#e85a5a"/><path d="M-6 -1.2H-3.4V0.4H-6Z" fill="#ffffff" opacity="0.6"/><ellipse cx="0" cy="-1.4" rx="1.6" ry="1.4" fill="#c84040"/><path d="M-2 -1.6h1M1 -2h1" stroke="#ffffff" stroke-width="0.5"/></g>`;
        const fr = C.v[2] >= 0;
        let s = shadow(C, 0, 0, 30, 20, 0.3) + lid + (fr ? back + sides[0].s + towel + rimTowel + sides[1].s + front + flap : front + sides[0].s + towel + rimTowel + sides[1].s + back);
        s += fr ? sock + ball : ball + sock;
        C.p(-35, 0, -30); C.p(35, 0, 30); C.p(0, 16, 0);
        return { defs: DEF19 + `<defs><radialGradient id="${id}b" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.4"/><stop offset="1" stop-color="#4a5a10" stop-opacity="0.3"/></radialGradient>`
          + `<radialGradient id="${id}s" cx="50%" cy="50%" r="60%"><stop offset="0" stop-color="#000000" stop-opacity="0.12"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-034 PLUSH DONUT CUDDLE CUSHION (T2): a round calming donut bed in oatmeal-and-blush shag faux fur: a high fluffy bolster rim all round a sunken
    // cushion, a non-slip base peeking out, a little plush carrot toy and a folded mini fleece blanket in the hollow. Live: a soft sheen travels round the
    // fluffy rim and the fur tips stir.
    N.donut30 = S => { const D = { w: 70, d: 60, round: 1, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('donut30'), id = C.u('p34'), k = C.k, FU = '#ead8c6', RO = 31, RI = 16, RH = 14;
        const base = cyl3(C, [0, 0, 0], [0, 1.4, 0], RO - 1, '#8a7a6e', { mat: 'matte', olw: 0.2 }) + cyl3(C, [0, 1.4, 0], [0, RH - 4, 0], RO, FU, { r2: RO - 1, mat: 'matte', olw: 0, ol: 0, capCol: FU });
        const P = (y, svg) => `<g transform="${FR(C, [0, y, 0], [1, 0, 0], [0, 0, 1])}">${svg}</g>`;
        let fur = ''; for (let i = 0; i < 1100; i++) { const a = R() * 2 * PI, r = RI + 1 + R() * (RO - RI - 1), L = 0.4 + R() * 0.6, b = a + (R() - 0.5) * 2; fur += `<path d="M${f1(Math.cos(a) * r)} ${f1(Math.sin(a) * r)}l${f1(Math.cos(b) * L)} ${f1(Math.sin(b) * L)}" stroke="${R() < 0.3 ? '#fbf0e6' : R() < 0.5 ? '#e2cebc' : '#f2e2d2'}" stroke-width="0.55" stroke-linecap="round" opacity="0.85"/>`; }
        const rim = P(RH - 4, `<circle r="${(RO + RI) / 2}" fill="none" stroke="url(#${id}r)" stroke-width="${RO - RI}"/>`) + P(RH - 2.6, `<circle r="${(RO + RI) / 2 + 0.6}" fill="none" stroke="${FU}" stroke-width="${RO - RI - 4}" opacity="0.9"/><circle r="${RI + 1.6}" fill="none" stroke="#b8a08c" stroke-width="2" opacity="0.5"/>${fur}`
          + `<g>${at('rotate', '0;360', 14)}<path d="M${RO - 4} 0A${RO - 4} ${RO - 4} 0 0 1 ${f1((RO - 4) * Math.cos(1))} ${f1((RO - 4) * Math.sin(1))}" stroke="#ffffff" stroke-width="6" fill="none" opacity="0.18" filter="url(#m12b1)"/></g>`);
        const hollow = P(5, `<circle r="${RI + 1}" fill="url(#${id}h)"/>` + rep(160, () => { const a = R() * 2 * PI, r = R() * RI, L = 0.6 + R() * 0.6; return `<path d="M${f1(Math.cos(a) * r)} ${f1(Math.sin(a) * r)}l${f1(L * Math.cos(a + 1))} ${f1(L * Math.sin(a + 1))}" stroke="#f4e4d4" stroke-width="0.3" opacity="0.6"/>`; }).join('')
          + `<g transform="translate(4 3) rotate(-18)"><rect x="-7" y="-5" width="14" height="10" rx="2" fill="#b8c8d8"/><path d="M-7 -1H7M-7 1.4H7" stroke="#a0b4c8" stroke-width="0.6"/><path d="M-7 -5h14" stroke="#d4e0ec" stroke-width="0.8"/>${rep(8, i => `<circle cx="${-5 + i * 1.4}" cy="3.4" r="0.3" fill="#ffffff" opacity="0.7"/>`).join('')}</g>`);
        // fur fringe along the outer silhouette (billboard tufts)
        let edge = ''; for (let i = 0; i < 140; i++) { const a = i / 140 * 2 * PI; if (Math.cos(a - C.thV) < -0.15) continue; const p = C.P([RO * Math.sin(a), RH - 5 + R() * 2, RO * Math.cos(a)]); edge += `<path d="M${P2(p)}l${f1((R() - 0.5) * 1.2 * k)} ${f1((0.5 + R() * 0.6) * k)}" stroke="${R() < 0.5 ? '#f2e2d2' : '#e2ceba'}" stroke-width="${f1(0.9 * k)}" stroke-linecap="round" opacity="0.8"/>`; }
        // plush carrot toy in the hollow
        const cp = C.P([-6, 6.4, 2]), carrot = `<g transform="translate(${P2(cp)}) scale(${n4(k)}) rotate(-24)"><path d="M-5 -1.6Q4 -1.8 7 0Q4 1.8 -5 1.6Q-6 0 -5 -1.6Z" fill="#f08a3a"/><path d="M-2 -1.4v2.8M1 -1.2v2.4M4 -0.8v1.6" stroke="#d06a20" stroke-width="0.3"/><g>${at('rotate', '-8 -5 0;8 -5 0;-8 -5 0', 3, 0, SPL(2))}<path d="M-5 0Q-8 -3 -9 -2M-5 0Q-8.4 -0.4 -9.4 1M-5 0Q-7.6 2.4 -8 3.4" stroke="#5aa04a" stroke-width="0.9" fill="none" stroke-linecap="round"/></g></g>`;
        let s = shadow(C, 0, 0, RO + 2, RO * 0.82, 0.3) + base + hollow + carrot + rim + edge;
        C.p(-35, 0, -30); C.p(35, 0, 30); C.p(0, RH + 2, 0);
        return { defs: DEF19 + `<defs><radialGradient id="${id}r" cx="50%" cy="50%" r="50%"><stop offset="0.5" stop-color="#b89c86"/><stop offset="0.62" stop-color="#e2ccb8"/><stop offset="0.82" stop-color="#f6e8da"/><stop offset="1" stop-color="#d8c0aa"/></radialGradient>`
          + `<radialGradient id="${id}h" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#f2dcd0"/><stop offset="0.7" stop-color="#e2c4b6"/><stop offset="1" stop-color="#a88a7a"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-054 MINIATURE CANOPY FOUR-POSTER PET BED (T3): a little four-poster in oiled walnut with slim turned posts and ball finials, a woven-cane
    // headboard, a thick sage linen mattress with piping, a cream bolster and a knit throw folded over the corner. Ivory linen valances hang round the
    // canopy rails, sheer voile drapes are tied back at the four posts and a string of tiny warm lights loops along the top. w 70 d 60 kept.
    // Live: the sheers sway and the little lights twinkle.
    N.canopy30 = S => { const D = { w: 70, d: 60, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('canopy30'), id = C.u('p54'), k = C.k, WN = '#7a5234', PX = 27, PZ = 21, TH = 58;
        const wal = (w, h) => `<rect width="${w}" height="${h}" fill="${WN}"/>` + grainV(R, w, h, Math.max(3, Math.round(w * 0.8)), '#5a3a22', 0.5);
        const lin = (w, h, c) => `<rect width="${w}" height="${h}" fill="${c}"/>` + linen(R, w, h, shade(c, 0.85), shade(c, 1.1));
        const plat = box3(C, decC(C, { c: [0, 4, 0], w: 58, h: 6, d: 46, col: WN, r: 0.6, dec: { f: wal(58, 6), b: wal(58, 6), l: wal(46, 6), r: wal(46, 6) } }));
        const mat = box3(C, decC(C, { c: [0, 10, 1], w: 54, h: 7, d: 42, col: '#9fb294', r: 2, dec: { t: lin(54, 42, '#a4b698') + `<rect x="1" y="1" width="52" height="40" rx="1.6" fill="none" stroke="#7e9474" stroke-width="0.5"/>`, f: lin(54, 7, '#96aa8a') + `<path d="M0 0.8H54" stroke="#7e9474" stroke-width="0.6"/>`, l: lin(42, 7, '#8ea284'), r: lin(42, 7, '#8ea284') } }));
        const cane = `<rect width="54" height="18" fill="${WN}"/><rect x="3" y="3" width="48" height="12" fill="#e2c890"/>` + rep(16, i => `<path d="M${3 + i * 3} 3l12 12M${3 + i * 3} 15l12 -12" stroke="#b8945a" stroke-width="0.4"/>`).join('') + rep(4, i => `<path d="M3 ${3 + i * 4}H51" stroke="#c8a870" stroke-width="0.3"/>`).join('') + `<rect x="3" y="3" width="48" height="12" fill="none" stroke="#4a2c18" stroke-width="0.5"/>`;
        const head = box3(C, decC(C, { c: [0, 10, -PZ], w: 54, h: 18, d: 1.6, col: WN, r: 0.3, dec: { f: cane, b: wal(54, 18) } }));
        const post = (x, z) => cyl3(C, [x, 0, z], [x, TH, z], 1.3, WN, { olw: 0.25 }) + cyl3(C, [x, 0, z], [x, 3, z], 1.9, WN, { r2: 1.4, olw: 0.25 }) + H.sph(C, [x, TH + 1.4, z], 1.8, '#8a6040') + cyl3(C, [x, 24, z], [x, 25.6, z], 1.7, WN, { olw: 0.2 });
        const rails = [[[-PX, TH, -PZ], [PX, TH, -PZ]], [[-PX, TH, PZ], [PX, TH, PZ]], [[-PX, TH, -PZ], [-PX, TH, PZ]], [[PX, TH, -PZ], [PX, TH, PZ]]].map(([a, b]) => cyl3(C, a, b, 0.7, WN, { olw: 0.2 })).join('');
        // valances: scalloped ivory linen strips on the 4 rails (planes)
        const val = (o, U, L) => `<g transform="${FR(C, o, U, [0, -1, 0])}"><path d="M0 0H${L}V4.2${rep(Math.round(L / 6), i => `Q${f1(L - i * 6 - 3)} 7 ${f1(L - i * 6 - 6)} 4.2`).join('')}V0Z" fill="#f2ece0"/><path d="M0 0.6H${L}" stroke="#d8ccb4" stroke-width="0.5"/><path d="M0 4H${L}" stroke="#e2d8c4" stroke-width="0.3" opacity="0.6"/></g>`;
        const vals = [{ z: -PZ, s: val([-PX, TH + 0.6, -PZ], [1, 0, 0], 2 * PX) }, { z: PZ, s: val([-PX, TH + 0.6, PZ], [1, 0, 0], 2 * PX) }, { x: -PX, s: val([-PX, TH + 0.6, -PZ], [0, 0, 1], 2 * PZ) }, { x: PX, s: val([PX, TH + 0.6, -PZ], [0, 0, 1], 2 * PZ) }];
        // sheer drapes tied at each post (billboard, sway)
        const drp = (x, z, sx, ph) => { const p = C.P([x, TH, z]), ky = (C.P([x, 0.5, z])[1] - p[1]) / TH; return `<g transform="translate(${P2(p)}) scale(${n4(k)} ${n4(ky)})" opacity="0.72"><g>${at('skewX', '-3;3;-3', 5, ph, SPL(2))}<path d="M${-sx * 0.6} 0H${sx * 5}Q${sx * 3} 18 ${sx * 1.2} 33Q${sx * 4} 44 ${sx * 6} ${TH - 1}H${-sx * 1.4}Q${-sx * 0.2} 44 ${-sx * 0.8} 33Q${-sx * 1} 18 ${-sx * 0.6} 0Z" fill="#fbf8f2"/><path d="M${sx * 1} 2Q${sx * 1.6} 18 ${sx * 0.6} 32M${sx * 3} 2Q${sx * 2.4} 18 ${sx * 1} 32M${sx * 2} 36Q${sx * 3} 46 ${sx * 4} ${TH - 1}" stroke="#e2dace" stroke-width="0.4" fill="none"/></g><rect x="${f1(-2.2)}" y="32" width="4.4" height="1.6" rx="0.8" fill="#c8a870"/></g>`; };
        // bolster + knit throw
        const bol = cyl3(C, [-24, 20.4, -16], [24, 20.4, -16], 3.4, '#f0e8da', { mat: 'matte', olw: 0.25, capCol: '#e2d6c2' });
        const knit = (w, h) => { let o = `<rect width="${w}" height="${h}" fill="#d8a888"/>`; for (let x = 1.6; x < w; x += 3.2) for (let y = 0; y < h; y += 1.6) o += `<path d="M${f1(x - 1.2)} ${f1(y)}l1.2 1.4l1.2 -1.4" stroke="#b88866" stroke-width="0.35" fill="none"/>`; return o; };
        const thr = `<g transform="${FR(C, [8, 17.2, -2], [1, 0, 0], [0, 0, 1])}">${knit(19, 24)}<rect width="19" height="24" fill="url(#${id}t)"/></g><g transform="${FR(C, [8, 17.2, 22.2], [1, 0, 0], [0, -1, 0])}">${knit(19, 12)}${rep(8, i => `<path d="M${1 + i * 2.4} 12v1.6" stroke="#c8987a" stroke-width="0.5"/>`).join('')}</g>`;
        // fairy lights looping along the front + back rails
        const fl = z => { let o = '', d = ''; for (let i = 0; i <= 12; i++) { const x = -PX + i * (2 * PX / 12), y = TH - 1.6 - Math.sin(i / 12 * PI * 3) * 1.4 - (i % 4 === 2 ? 1.4 : 0), p = C.P([x, y, z]); d += (i ? 'L' : 'M') + P2(p); o += `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.55 * k)}" fill="#ffe2a0">${an('opacity', '0.5;1;0.5', 1.6 + (i % 3) * 0.5, -i * 0.4)}</circle>`; }
          return `<path d="${d}" stroke="#6a5a40" stroke-width="${f1(0.15 * k)}" fill="none"/>${o}`; };
        const fr = C.v[2] >= 0, xs = C.v[0] >= 0;
        const posts = [[-PX, -PZ], [PX, -PZ], [-PX, PZ], [PX, PZ]].map(([x, z]) => ({ x, z, s: post(x, z) + drp(x, z, x < 0 ? 1 : -1, -(x + z) * 0.05) }));
        const back = posts.filter(p => (p.z < 0) === fr), frontP = posts.filter(p => (p.z < 0) !== fr);
        const vb = vals.filter(v => v.z != null ? (v.z < 0) === fr : false), vf = vals.filter(v => v.z != null ? (v.z < 0) !== fr : false), vs = vals.filter(v => v.x != null).sort((a, b) => (a.x - b.x) * (xs ? -1 : 1));
        let s = shadow(C, 0, 0, 34, 28, 0.32) + back.map(p => p.s).join('') + vb.map(v => v.s).join('') + fl(fr ? -PZ : PZ) + (fr ? head + plat + mat + bol + thr : plat + mat + thr + bol + head)
          + vs.map(v => v.s).join('') + rails + frontP.map(p => p.s).join('') + vf.map(v => v.s).join('') + fl(fr ? PZ : -PZ);
        C.p(-35, 0, -30); C.p(35, 0, 30); C.p(0, TH + 4, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}t" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.15"/><stop offset="1" stop-color="#000000" stop-opacity="0.12"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };


    // depth helper: draw ascending (far first)
    const dep30 = (C, x, z) => x * C.v[0] + z * C.v[2];

    // BED-074 HEATED ORTHOPEDIC MEMORY-FOAM PET BUNK ATTACHED TO MASTER BED (T4): a walnut-framed bunk on brass feet with two polished brass hook arms
    // and a leather strap at the back that clip it to the side rail of the big bed. Inside: a dusty-blue velvet U-bolster, a cream sherpa cover over
    // layered orthopedic memory foam (one corner folded back to show the egg-crate layer), a brass name plaque and a slim heat controller on its cord
    // with an amber ring. w 70 d 60 kept. Live: a warm glow breathes over the cushion, heat shimmer rises and the controller ring pulses.
    N.bunk30 = S => { const D = { w: 70, d: 60, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('bunk30'), id = C.u('p74'), k = C.k, WN = '#6a4428', BR = '#d6b06a', VB = '#7c8cab';
        const wal = (w, h) => `<rect width="${w}" height="${h}" fill="${WN}"/>` + grainV(R, w, h, Math.max(3, Math.round(w * 0.8)), '#4a2c18', 0.5);
        const tray = box3(C, decC(C, { c: [0, 2.4, 0], w: 64, h: 9, d: 52, col: WN, r: 0.8, dec: { f: wal(64, 9) + `<rect x="27" y="3" width="10" height="3.2" rx="0.6" fill="${BR}"/><rect x="27" y="3" width="10" height="0.8" fill="#fff0c0" opacity="0.6"/><path d="M29 4.8h6" stroke="#8a6a30" stroke-width="0.4"/>`, b: wal(64, 9), l: wal(52, 9), r: wal(52, 9) } }));
        const feet = [[-29, -23], [29, -23], [-29, 23], [29, 23]].map(([x, z]) => cyl3(C, [x, 0, z], [x, 2.4, z], 1.6, BR, { r2: 1.2, mat: 'metal', olw: 0.2 })).join('');
        // cushion: sherpa top with a folded-back corner showing foam layers, layered front
        const sher = (w, d) => `<rect width="${w}" height="${d}" fill="#efe6d8"/>` + rep(Math.round(w * d / 9), () => `<circle cx="${f1(R() * w)}" cy="${f1(R() * d)}" r="${f1(0.35 + R() * 0.3)}" fill="none" stroke="${R() < 0.5 ? '#ddd2c0' : '#fbf6ee'}" stroke-width="0.25"/>`).join('');
        const egg = (w, d) => `<rect width="${w}" height="${d}" fill="#e2d8b8"/>` + rep(Math.round(w / 2.2) * Math.round(d / 2.2), i => { const cx = (i % Math.round(w / 2.2)) * 2.2 + 1.1, cy = Math.floor(i / Math.round(w / 2.2)) * 2.2 + 1.1; return `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="0.8" fill="#cfc4a0"/>`; }).join('');
        const top = `<clipPath id="${id}k"><path d="M0 0H56V42H12L0 30Z"/></clipPath>${egg(56, 42)}<g clip-path="url(#${id}k)">${sher(56, 42)}</g><path d="M0 30L12 42L4 44Z" fill="#e4dac8" stroke="#c8bca6" stroke-width="0.3"/><path d="M0 30L12 42" stroke="#d2c6b0" stroke-width="0.6"/>`
          + `<rect width="56" height="42" fill="#ffb060" opacity="0.06">${an('opacity', '0.03;0.14;0.03', 5, 0, SPL(2))}</rect>`;
        const layers = `<rect width="56" height="7" fill="#efe6d8"/><rect y="2.4" width="56" height="2.2" fill="#e2d8b8"/><rect y="4.6" width="56" height="2.4" fill="#b8b0a4"/>` + rep(12, i => `<circle cx="${2 + i * 4.6}" cy="3.4" r="0.7" fill="#cfc4a0"/>`).join('');
        const cush = box3(C, decC(C, { c: [0, 11.4, 3], w: 56, h: 7, d: 42, col: '#efe6d8', r: 1.4, dec: { t: top, f: layers, l: layers.replace(/56/g, '42'), r: layers.replace(/56/g, '42') } }));
        // U bolster (velvet)
        const vel = { mat: 'matte', olw: 0.25, capCol: shade(VB, 1.1) };
        const bol = { b: cyl3(C, [-26, 18, -20], [26, 18, -20], 5, VB, vel), l: cyl3(C, [-28, 18, -18], [-28, 18, 20], 4.4, shade(VB, 0.95), vel), r: cyl3(C, [28, 18, -18], [28, 18, 20], 4.4, shade(VB, 0.95), vel) };
        // brass hook arms + leather strap at the back
        const hookA = x => line3(C, [[x, 10, -26], [x, 44, -27], [x, 48, -29], [x, 47, -33], [x, 43, -33.6]], 1.1, BR) + line3(C, [[x - 0.3, 10, -25.6], [x - 0.3, 44, -26.6]], 0.3, '#fff0c0');
        const strap = box3(C, { c: [0, 36, -26.8], w: 41, h: 4, d: 0.8, col: '#7a4a2a', r: 0.4, dec: { f: `<rect width="41" height="4" fill="#7a4a2a"/><path d="M0.6 0.6H40.4M0.6 3.4H40.4" stroke="#c89a6a" stroke-width="0.2" stroke-dasharray="0.6 0.4"/><rect x="18.5" y="0.4" width="4" height="3.2" rx="0.4" fill="none" stroke="${BR}" stroke-width="0.6"/>` } });
        // controller on a cord
        const cp = C.P([40, 0.6, 18]), cord = line3(C, [[30, 6, 14], [34, 1, 16], [38, 0.4, 18]], 0.5, '#2a2a2a');
        const ctl = `<g transform="translate(${P2(cp)}) scale(${n4(k)})"><rect x="-3.6" y="-2" width="7.2" height="2.6" rx="1.2" fill="#2a2a2c"/><rect x="-3.6" y="-2" width="7.2" height="0.6" rx="0.3" fill="#4a4a4e"/><circle cx="0" cy="-0.8" r="0.9" fill="none" stroke="#ffb050" stroke-width="0.35">${an('opacity', '0.4;1;0.4', 2.4, 0, SPL(2))}</circle></g>`;
        const tp = C.P([0, 18.6, 3]), heat = `<g transform="translate(${P2(tp)}) scale(${n4(k)})">${rep(3, i => `<path d="M${-12 + i * 12} 0q-1.6 -3 0 -6t0 -6" stroke="#ffd8a0" stroke-width="0.6" fill="none" opacity="0">${an('opacity', '0;0.5;0', 4, -i * 1.3)}${at('translate', '0 0;0 -5', 4, -i * 1.3)}</path>`).join('')}</g>`;
        const pil = `<g transform="translate(${P2(C.P([10, 18.6, -6]))}) scale(${n4(k)})"><path d="M-6 0Q-7 -3.4 -5 -5.6Q0 -4.8 5 -5.6Q7 -3.4 6 0Q0 1 -6 0Z" fill="#f4ece0"/><path d="M-2 -3.4q1 -1 2 0q1 -1 2 0q0 1.4 -2 2.4q-2 -1 -2 -2.4Z" fill="#c86a6a"/></g>`;
        const parts = [{ d: dep30(C, 0, -27), s: hookA(-20) + hookA(20) + strap }, { d: dep30(C, 0, -20) + 0.1, s: bol.b }, { d: dep30(C, 0, 0), s: tray + cush + pil }, { d: dep30(C, -28, 0) + 0.2, s: bol.l }, { d: dep30(C, 28, 0) + 0.2, s: bol.r }, { d: dep30(C, 38, 18), s: cord + ctl }];
        parts.sort((a, b) => a.d - b.d);
        let s = shadow(C, 0, 0, 36, 30, 0.32) + feet + parts.map(p => p.s).join('') + heat;
        C.p(-35, 0, -30); C.p(35, 0, 30); C.p(0, 50, -30);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-094 FLOATING CLOUD-CRADLE PET SLEEP POD WITH LULLABY HUM (T5): a cradle of soft ivory cloud puffs hovering over a pearl base disc ringed in
    // champagne gold, a peach-glow cushion and a tiny star pillow in its hollow, warm light pooled on the base beneath, little gold stars circling.
    // w 70 d 60 kept. Live: the cloud bobs gently, the glow breathes with it, lullaby notes drift up and the stars orbit.
    N.cloud94 = S => { const D = { w: 70, d: 60, round: 1, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('cloud94'), id = C.u('p94'), k = C.k, GD = '#d6b26a', CY = 27;
        const PL = (y, svg) => `<g transform="${FR(C, [0, y, 0], [1, 0, 0], [0, 0, 1])}">${svg}</g>`;
        const base = cyl3(C, [0, 0, 0], [0, 2.4, 0], 22, '#f2ece4', { mat: 'gloss', olw: 0.25, capCol: '#f8f4ee' }) + PL(2.45, `<circle r="21.4" fill="none" stroke="${GD}" stroke-width="0.9"/><circle r="19.6" fill="none" stroke="${GD}" stroke-width="0.3" opacity="0.7"/>`);
        const glow = PL(2.9, `<ellipse rx="18" ry="16" fill="url(#${id}g)">${an('opacity', '0.6;1;0.6', 4.6, 0, SPL(2))}</ellipse>`);
        const puffs = []; for (let i = 0; i < 14; i++) { const a = i / 14 * 2 * PI + 0.1, rr = 6 + R() * 2.2, x = Math.sin(a) * 23, z = Math.cos(a) * 19, y = CY + (R() - 0.5) * 2; puffs.push({ d: dep30(C, x, z), s: H.sph(C, [x, y, z], rr, '#fbf6ee') }); }
        for (let i = 0; i < 7; i++) { const a = i / 7 * 2 * PI + 0.5, x = Math.sin(a) * 15, z = Math.cos(a) * 12; puffs.push({ d: dep30(C, x, z), s: H.sph(C, [x, CY - 3.4, z], 6.4, '#f4ece2') }); }
        const cush = { d: 0, s: PL(CY + 1.4, `<ellipse rx="19" ry="15.6" fill="url(#${id}c)"/>` + rep(40, () => `<circle cx="${f1((R() - 0.5) * 30)}" cy="${f1((R() - 0.5) * 24)}" r="${f1(1.4 + R() * 1.6)}" fill="#ffffff" opacity="0.12"/>`).join('')) + `<g transform="translate(${P2(C.P([3, CY + 1.8, -2]))}) scale(${n4(k)})"><path d="M0 -6L1.8 -2L6 -1.6L2.8 1.2L3.8 5.4L0 3.2L-3.8 5.4L-2.8 1.2L-6 -1.6L-1.8 -2Z" fill="#f2d48a" stroke="#c8a050" stroke-width="0.3" stroke-linejoin="round"/><path d="M-1 -1q1 0.8 2 0" stroke="#8a6a30" stroke-width="0.3" fill="none"/></g>` };
        const back = puffs.filter(p => p.d < 0).sort((a, b) => a.d - b.d), front = puffs.filter(p => p.d >= 0).sort((a, b) => a.d - b.d);
        const bob = at('translate', '0 0;0 -2.2;0 0', 4.6, 0, SPL(2));
        const notes = rep(3, i => `<g opacity="0">${an('opacity', '0;0.9;0', 6, -i * 2)}${at('translate', `${(i - 1) * 8} 0;${(i - 1) * 8 + 6} -22`, 6, -i * 2)}<path d="M0 0V-4.4L3 -5.4V-1" stroke="#c8a050" stroke-width="0.5" fill="none"/><ellipse cx="-0.8" cy="0.2" rx="1.1" ry="0.8" fill="#c8a050"/><ellipse cx="2.2" cy="-0.8" rx="1.1" ry="0.8" fill="#c8a050"/></g>`).join('');
        const np = C.P([0, CY + 8, 0]), stars = rep(4, i => `<g>${at('rotate', `${i * 90} 0 0;${i * 90 + 360} 0 0`, 12)}<g transform="translate(26 0)"><path d="M0 -1.4L0.4 -0.4L1.4 0L0.4 0.4L0 1.4L-0.4 0.4L-1.4 0L-0.4 -0.4Z" fill="#ffe8a8">${an('opacity', '0.5;1;0.5', 2, -i * 0.5)}</path></g></g>`).join('');
        const orbit = `<g transform="translate(${P2(C.P([0, CY + 4, 0]))}) scale(${n4(k)} ${n4(k * Math.abs(Math.sin(0.45)) + 0.1)})">${stars}</g>`;
        const cloud = `<g>${bob}${back.map(p => p.s).join('')}${cush.s}${front.map(p => p.s).join('')}<g transform="translate(${P2(np)}) scale(${n4(k)})">${notes}</g></g>`;
        const beam = `<path d="M${P2(C.P([-17, 3, 0]))}L${P2(C.P([-13, CY - 6, 0]))}L${P2(C.P([13, CY - 6, 0]))}L${P2(C.P([17, 3, 0]))}Z" fill="url(#${id}m)">${an('opacity', '0.5;0.9;0.5', 4.6, 0, SPL(2))}</path>`;
        let s = shadow(C, 0, 0, 26, 22, 0.3) + base + glow + `<g filter="url(#m12b1)" opacity="0.35">${PL(3, '<ellipse rx="17" ry="14" fill="#8a7a6a" opacity="0.4"/>')}</g>` + cloud + orbit;
        C.p(-35, 0, -30); C.p(35, 0, 30); C.p(0, CY + 34, 0);
        return { defs: DEF19 + `<defs><radialGradient id="${id}g" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffdca0" stop-opacity="0.9"/><stop offset="1" stop-color="#ffd0a0" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}c" cx="50%" cy="45%" r="55%"><stop offset="0" stop-color="#fff2e2"/><stop offset="0.7" stop-color="#f6dcc8"/><stop offset="1" stop-color="#e2c0aa"/></radialGradient><linearGradient id="${id}m" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffe2b0" stop-opacity="0.05"/><stop offset="1" stop-color="#ffe2b0" stop-opacity="0.4"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // ======================= PRIMARY BEDS (BED-015/035/..): bed 140 x 186 footprint, act 'nap', 2 nap seats at x +-30 z -30 (h follows the mattress top) =======================
    // BED-015 THIN TWIN FOAM MATTRESS DIRECTLY ON FLOOR (T1): a sagging thin foam twin mattress straight on the floorboards, its faded ticking cover split
    // at one corner to show yellowed foam, a blue fitted sheet half pulled off, one flat yellowed pillow, a red-and-grey fleece blanket kicked into a heap at
    // the foot. On the floor: a cheap alarm clock, a phone on a long charging cable, a mug and a face-down paperback. Live: the phone lights up with a
    // notification now and then and the clock's colon blinks.
    N.floor30 = S => { const MT = 9; const D = { w: 140, d: 186, act: 'nap', seats: [{ x: -30, z: -30, h: MT, k: 'nap' }, { x: 30, z: -30, h: MT, k: 'nap' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('floor30'), id = C.u('b15'), k = C.k, MW = 104, MD = 176, MZ = 2;
        const tick = (w, h) => `<rect width="${w}" height="${h}" fill="#e6ddcb"/>` + rep(Math.round(w / 3), i => `<path d="M${f1(i * 3 + 1)} 0V${h}" stroke="#a8b4c4" stroke-width="0.5" opacity="0.5"/>`).join('');
        const side = (w, h, torn) => tick(w, h) + `<path d="M0 ${f1(h * 0.5)}H${w}" stroke="#c8bca8" stroke-width="0.4" stroke-dasharray="1 0.6"/>` + (torn ? `<path d="M0 0.8L5 1.4L7 4.6L4 7.4L0 7Z" fill="#e8cc6a"/>${rep(10, () => `<circle cx="${f1(R() * 5)}" cy="${f1(1.6 + R() * 5)}" r="0.35" fill="#c8a848"/>`).join('')}<path d="M0 0.8L5 1.4L7 4.6L4 7.4L0 7" stroke="#a8987c" stroke-width="0.3" fill="none"/>` : '');
        const sheet = `<path d="M0 0H${MW}V${MD * 0.62}Q${MW - 10} ${MD * 0.7} ${MW - 26} ${MD * 0.66}Q${MW * 0.5} ${MD * 0.74} 20 ${MD * 0.68}Q8 ${MD * 0.72} 0 ${MD * 0.7}Z" fill="#9ab0c8"/>`
          + rep(9, () => { const x = R() * MW, y = R() * MD * 0.6; return `<path d="M${f1(x)} ${f1(y)}q${f1(4 + R() * 6)} ${f1(-1 + R() * 2)} ${f1(10 + R() * 8)} ${f1(R() * 3)}" stroke="#7e94ae" stroke-width="0.5" fill="none" opacity="0.6"/>`; }).join('')
          + `<path d="M0 ${f1(MD * 0.7)}Q8 ${f1(MD * 0.72)} 20 ${f1(MD * 0.68)}Q${MW * 0.5} ${f1(MD * 0.74)} ${MW - 26} ${f1(MD * 0.66)}Q${MW - 10} ${f1(MD * 0.7)} ${MW} ${f1(MD * 0.62)}" stroke="#b8cade" stroke-width="0.8" fill="none"/>`;
        const topD = tick(MW, MD) + `<ellipse cx="${MW * 0.5}" cy="${MD * 0.55}" rx="${MW * 0.3}" ry="${MD * 0.2}" fill="#8a7a5a" opacity="0.08"/><ellipse cx="${MW * 0.7}" cy="${MD * 0.82}" rx="6" ry="4" fill="none" stroke="#b8a070" stroke-width="0.6" opacity="0.5"/>` + sheet;
        const mat = box3(C, decC(C, { c: [0, 0, MZ], w: MW, h: MT, d: MD, col: '#e6ddcb', r: 2.6, dec: { t: topD, f: side(MW, MT, 1), b: side(MW, MT), l: side(MD, MT), r: side(MD, MT) } }));
        const pil = box3(C, { c: [-22, MT - 0.4, MZ - 70], w: 50, h: 5, d: 28, col: '#ece4cc', r: 2.4, dec: { t: `<rect width="50" height="28" fill="#ece4cc"/><ellipse cx="22" cy="14" rx="14" ry="8" fill="#d8ccac" opacity="0.5"/><path d="M6 6q10 4 18 1M10 22q14 -3 30 1" stroke="#cfc4a6" stroke-width="0.6" fill="none"/>` } });
        // blanket heap at the foot: lumpy fleece rolls
        const FL = '#b0483a';
        const plaid = `<pattern id="${id}p" width="8" height="8" patternUnits="userSpaceOnUse"><rect width="8" height="8" fill="${FL}"/><rect width="3" height="8" fill="#6e7278" opacity="0.55"/><rect width="8" height="3" fill="#6e7278" opacity="0.55"/><path d="M5.5 0V8M0 5.5H8" stroke="#e8dcc8" stroke-width="0.3" opacity="0.6"/></pattern>`;
        const blob = 'M10 0Q22 -6 36 -2Q50 -8 62 0Q74 4 70 14Q78 24 64 30Q50 36 38 30Q24 38 12 30Q-2 26 2 16Q-6 6 10 0Z';
        const heap = `<g transform="${FR(C, [-38, MT + 0.4, MZ + 50], [1, 0, 0], [0, 0, 1])}"><defs>${plaid}</defs><path d="${blob}" fill="#000000" opacity="0.18" transform="translate(1.6 2)" filter="url(#m12b1)"/><path d="${blob}" fill="url(#${id}p)"/>`
          + `<path d="M8 8Q22 4 34 10T60 8M6 20Q20 14 30 20T66 22M18 28Q32 24 46 30" stroke="#5a2018" stroke-width="1.6" fill="none" opacity="0.35" stroke-linecap="round"/><path d="M10 6Q24 2 34 8T60 6M8 18Q20 12 30 18T64 20" stroke="#ffffff" stroke-width="1" fill="none" opacity="0.18" stroke-linecap="round"/></g>`
          + `<g transform="${FR(C, [MW / 2 + 0.2, MT, MZ + 56], [0, 0, 1], [0, -1, 0])}"><path d="M0 0H22Q24 5 21 9.4Q12 11 2 9.6Q-1 5 0 0Z" fill="url(#${id}p)"/><path d="M4 2Q6 6 5 9M14 1Q15 6 13 9.6" stroke="#5a2018" stroke-width="1" fill="none" opacity="0.3"/></g>`;
        // floor clutter
        const clock = box3(C, { c: [64, 0, MZ - 78], w: 9, h: 6, d: 4, col: '#e8e4dc', r: 1, ax: [[Math.cos(0.3), 0, -Math.sin(0.3)], [0, 1, 0], [Math.sin(0.3), 0, Math.cos(0.3)]], dec: { f: `<rect width="9" height="6" rx="1" fill="#e8e4dc"/><rect x="1" y="1.4" width="7" height="3.2" fill="#1a1a1a"/><path d="M1.8 2v2.2M3 2h1.2v1.1h-1.2v1.1h1.2M5.6 2v1.1h1.2M6.8 2v2.2" stroke="#e83a2a" stroke-width="0.35" fill="none"/><g>${an('opacity', '1;1;0;0', 1, 0, KT('0;0.5;0.5;1'))}<circle cx="4.9" cy="2.6" r="0.2" fill="#e83a2a"/><circle cx="4.9" cy="3.6" r="0.2" fill="#e83a2a"/></g>` } });
        const phone = box3(C, { c: [62, 0, MZ - 50], w: 6, h: 0.8, d: 12, col: '#2a2a2e', r: 0.8, dec: { t: `<rect width="6" height="12" rx="0.8" fill="#1a1a1e"/><rect x="0.5" y="0.6" width="5" height="10.8" rx="0.5" fill="#e8d8b8" opacity="0">${an('opacity', '0;0;0.95;0.95;0', 9, 0, KT('0;0.7;0.72;0.86;1'))}</rect><rect x="1" y="2" width="4" height="1.4" rx="0.4" fill="#ffffff" opacity="0">${an('opacity', '0;0;1;1;0', 9, 0, KT('0;0.7;0.72;0.86;1'))}</rect>` } });
        const cable = line3(C, [[62, 0.3, MZ - 44], [66, 0.3, MZ - 30], [60, 0.3, MZ - 20], [68, 0.3, MZ - 6], [70, 0.3, -90]], 0.45, '#f2f2f0');
        const mug = cyl3(C, [-62, 0, MZ - 60], [-62, 7, MZ - 60], 3.4, '#d8e4d0', { olw: 0.25, capCol: '#5a3a24' }) + line3(C, [[-58.6, 5.4, MZ - 60], [-56.6, 4.6, MZ - 60], [-56.6, 2.4, MZ - 60], [-58.6, 1.8, MZ - 60]], 0.7, '#d8e4d0');
        const book = box3(C, { c: [-60, 0, MZ + 30], w: 12, h: 1.6, d: 17, col: '#f2ece0', r: 0.2, ax: [[Math.cos(-0.4), 0, -Math.sin(-0.4)], [0, 1, 0], [Math.sin(-0.4), 0, Math.cos(-0.4)]], dec: { t: `<rect width="12" height="17" fill="#3a6a8a"/><rect x="2" y="3" width="8" height="1.2" fill="#f2d870"/><rect x="2" y="5" width="6" height="0.6" fill="#f2ece0"/>` } });
        const items = [{ d: dep30(C, 0, MZ), s: mat + pil + heap }, { d: dep30(C, 64, MZ - 78), s: clock }, { d: dep30(C, 62, MZ - 40), s: cable + phone }, { d: dep30(C, -62, MZ - 60), s: mug }, { d: dep30(C, -60, MZ + 30), s: book }];
        items.sort((a, b) => a.d - b.d);
        let s = shadow(C, 0, MZ, 58, 92, 0.3) + items.map(i => i.s).join('');
        C.p(-70, 0, -93); C.p(70, 0, 93); C.p(0, MT + 14, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };


    const TPD = '<radialGradient id="tp30" cx="45%" cy="40%" r="60%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.32"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.08"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>';
    const pil30 = (C, c, w, h, d, col, t, ax) => box3(C, Object.assign({ c, w, h, d, col, r: Math.min(h / 2, 4), dec: t ? { t } : undefined }, ax ? { ax } : {}));
    const tiltX = a => [[1, 0, 0], [0, Math.cos(a), -Math.sin(a)], [0, Math.sin(a), Math.cos(a)]];
    // a curtain billboard hanging from (x, top, z) to the floor, gathered at a tie; ky fits the projected height
    const drape30 = (C, x, top, z, sx, wd, fill, ph, tie) => { const p = C.P([x, top, z]), ky = (C.P([x, 0.5, z])[1] - p[1]) / top, k = C.k, T = top;
      return `<g transform="translate(${P2(p)}) scale(${n4(k)} ${n4(ky)})"><g>${at('skewX', '-2.4;2.4;-2.4', 6, ph, SPL(2))}<path d="M${-sx * 0.8} 0H${sx * wd}Q${sx * wd * 0.6} ${f1(T * 0.3)} ${sx * wd * 0.22} ${f1(T * 0.56)}Q${sx * wd * 0.8} ${f1(T * 0.78)} ${sx * wd * 1.2} ${T}H${-sx * 1.6}Q${-sx * 0.2} ${f1(T * 0.78)} ${-sx * 0.8} ${f1(T * 0.56)}Z" fill="${fill}"/>`
        + `<path d="M${sx * wd * 0.2} 2Q${sx * wd * 0.3} ${f1(T * 0.3)} ${sx * 0.4} ${f1(T * 0.54)}M${sx * wd * 0.6} 2Q${sx * wd * 0.4} ${f1(T * 0.3)} ${sx * wd * 0.1} ${f1(T * 0.55)}M${sx * wd * 0.3} ${f1(T * 0.6)}Q${sx * wd * 0.5} ${f1(T * 0.8)} ${sx * wd * 0.7} ${T}" stroke="#000000" stroke-width="0.5" fill="none" opacity="0.1"/></g>${tie || ''}</g>`; };

    // BED-035 PINE PLATFORM FRAME WITH SPRING MATTRESS (T2): a honey-pine platform bed with a plank headboard and a low footboard, a white quilted spring
    // mattress with blue border tape and side vents, a faded blue gingham duvet with the white sheet turned down, two plump pillows and a well-loved plush
    // bunny. Bed 140 x 186 + nap seats kept (h = duvet top). Live: a warm sunbeam drifts slowly across the duvet and the bunny's ear flops.
    N.pinebed30 = S => { const TOP = 40; const D = { w: 140, d: 186, act: 'nap', seats: [{ x: -30, z: -30, h: TOP, k: 'nap' }, { x: 30, z: -30, h: TOP, k: 'nap' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('pinebed30'), id = C.u('b35'), k = C.k, PN = '#e0b474';
        const pine = (w, h, vert) => `<rect width="${w}" height="${h}" fill="${PN}"/>` + (vert ? grainV(R, w, h, Math.round(w * 0.6), '#b8864a', 0.45) : rep(Math.round(h * 0.8), () => { const y = R() * h; return `<path d="M0 ${f1(y)}Q${f1(w * 0.5)} ${f1(y + (R() - 0.5) * 2)} ${w} ${f1(y + (R() - 0.5))}" stroke="#b8864a" stroke-width="0.25" fill="none" opacity="0.45"/>`; }).join('')) + `<circle cx="${f1(w * 0.3)}" cy="${f1(h * 0.5)}" r="1.4" fill="#a8743a" opacity="0.5"/>`;
        const planks = (w, h) => pine(w, h, 1) + rep(8, i => `<path d="M${f1(w / 8 * i)} 8V${h}" stroke="#9a6a34" stroke-width="0.7"/>`).join('') + `<rect width="${w}" height="8" fill="${shade(PN, 0.92)}"/><path d="M0 8H${w}" stroke="#9a6a34" stroke-width="0.6"/><rect width="${w}" height="1" fill="#f4d8a8" opacity="0.6"/>`;
        const head = box3(C, decC(C, { c: [0, 0, -89], w: 138, h: 76, d: 4, col: PN, r: 0.6, dec: { f: planks(138, 76), b: planks(138, 76), t: pine(138, 4), l: pine(4, 76, 1), r: pine(4, 76, 1) } }));
        const foot = box3(C, decC(C, { c: [0, 0, 90], w: 138, h: 26, d: 3, col: PN, r: 0.6, dec: { f: planks(138, 26), b: planks(138, 26), t: pine(138, 3) } }));
        const frame = box3(C, decC(C, { c: [0, 4, 1], w: 134, h: 12, d: 176, col: PN, r: 0.6, dec: { f: pine(134, 12), b: pine(134, 12), l: pine(176, 12), r: pine(176, 12) } }));
        const legs = [[-64, -84], [64, -84], [-64, 86], [64, 86]].map(([x, z]) => box3(C, { c: [x, 0, z], w: 6, h: 4, d: 6, col: shade(PN, 0.85), r: 0.4 })).join('');
        const mside = (w, h) => `<rect width="${w}" height="${h}" fill="#f6f4ee"/><rect width="${w}" height="1.6" fill="#7a96c0"/><rect y="${h - 1.6}" width="${w}" height="1.6" fill="#7a96c0"/>` + rep(Math.round(w / 10), i => `<path d="M${i * 10 + 5} 3Q${i * 10 + 7} ${h / 2} ${i * 10 + 5} ${h - 3}" stroke="#dcdad2" stroke-width="0.5" fill="none"/>`).join('') + [0.3, 0.7].map(u => `<circle cx="${f1(w * u)}" cy="${f1(h / 2)}" r="1" fill="#d8d6ce" stroke="#b8b6ae" stroke-width="0.3"/>`).join('');
        const mat = box3(C, decC(C, { c: [0, 16, 2], w: 128, h: 18, d: 168, col: '#f6f4ee', r: 2.4, dec: { f: mside(128, 18), b: mside(128, 18), l: mside(168, 18), r: mside(168, 18) } }));
        const ging = (w, h) => `<rect width="${w}" height="${h}" fill="#eef2f6"/><rect width="${w}" height="${h}" fill="url(#${id}g)"/>`;
        const duvT = ging(134, 140) + `<path d="M10 30Q40 22 70 34T130 28M6 80Q50 70 90 84T132 78M20 118Q60 110 110 122" stroke="#5a6e8a" stroke-width="1.4" fill="none" opacity="0.18" stroke-linecap="round"/><path d="M10 28Q40 20 70 32T130 26M6 78Q50 68 90 82T132 76" stroke="#ffffff" stroke-width="1" fill="none" opacity="0.4"/>`
          + `<g opacity="0.5">${at('translate', '-20 -10;40 30;-20 -10', 30, 0, SPL(2))}<path d="M20 30L60 20L80 60L40 70Z" fill="#fff0c0" filter="url(#m12b1)"/></g>`;
        const duv = box3(C, decC(C, { c: [0, 32, 16], w: 134, h: 8, d: 140, col: '#d8e0ea', r: 3, dec: { t: duvT, f: ging(134, 8), l: ging(140, 8), r: ging(140, 8) } }));
        const fold = box3(C, { c: [0, 38.4, -50], w: 133, h: 2.4, d: 12, col: '#fbfaf6', r: 1.2, dec: { t: `<rect width="133" height="12" fill="#fbfaf6"/><path d="M0 2H133" stroke="#9ab0d0" stroke-width="0.8"/>` } });
        const pt = `<rect width="54" height="30" fill="#fbfaf6"/><path d="M6 10Q27 6 48 12M10 22Q27 18 44 22" stroke="#e2e0d8" stroke-width="0.8" fill="none"/><ellipse cx="27" cy="15" rx="18" ry="9" fill="url(#tp30)"/>`;
        const pils = pil30(C, [-31, 34, -68], 54, 9, 30, '#fbfaf6', pt) + pil30(C, [31, 34, -68], 54, 9, 30, '#fbfaf6', pt);
        const bp = C.P([38, TOP, -42]), bunny = `<g transform="translate(${P2(bp)}) scale(${n4(k * 1.3)})"><ellipse cx="0" cy="-5" rx="5.4" ry="5" fill="#e8dcd0"/><ellipse cx="0" cy="-3.6" rx="3" ry="2.6" fill="#f6eee6"/><circle cy="-13" r="4.4" fill="#e8dcd0"/><path d="M-1.6 -16.4Q-3 -24 -1 -24.6Q0.8 -24 0 -16.6Z" fill="#e8dcd0"/><path d="M-1.4 -17Q-2 -22 -1 -22.6" stroke="#e8b8b0" stroke-width="0.8" fill="none"/>`
          + `<g>${at('rotate', '0 1.6 -16;0 1.6 -16;40 1.6 -16;40 1.6 -16;0 1.6 -16', 7, 0, KT('0;0.5;0.56;0.8;1'))}<path d="M1.6 -16.4Q3 -24 5 -24Q6 -22 2.8 -16Z" fill="#e8dcd0"/></g><circle cx="-1.6" cy="-13.4" r="0.55" fill="#3a2a2a"/><circle cx="1.6" cy="-13.4" r="0.55" fill="#3a2a2a"/><path d="M-0.5 -11.6l0.5 0.5l0.5 -0.5" stroke="#c87a7a" stroke-width="0.4" fill="none"/><path d="M-3 -12.4l-2.4 -0.4M3 -12.4l2.4 -0.4" stroke="#b8aaa0" stroke-width="0.2"/></g>`;
        const fr = C.v[2] >= 0;
        let s = shadow(C, 0, 2, 72, 96, 0.32) + legs + (fr ? head + frame + mat + pils + duv + fold + bunny + foot : foot + frame + mat + duv + fold + bunny + pils + head);
        C.p(-70, 0, -93); C.p(70, 0, 93); C.p(0, 78, -89);
        return { defs: DEF19 + `<defs>${TPD}<pattern id="${id}g" width="8" height="8" patternUnits="userSpaceOnUse"><rect width="4" height="8" fill="#9ab0d0" opacity="0.45"/><rect width="8" height="4" fill="#9ab0d0" opacity="0.45"/></pattern></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-055 QUEEN TUFTED LINEN UPHOLSTERED BED WITH PILLOW-TOP (T3): a softly rounded upholstered frame in oatmeal linen with a tall button-tufted
    // headboard and piped edges on slim walnut feet, a deep white pillow-top mattress, crisp white sheets, sage linen euro shams leaning on the headboard,
    // two white sleeping pillows, an ochre velvet lumbar cushion, and a sage linen duvet folded across the foot. Bed 140 x 186 + nap seats kept.
    // Live: a warm sheen glides across the tufted headboard and the lumbar's tassels sway.
    N.lin55 = S => { const TOP = 45; const D = { w: 140, d: 186, act: 'nap', seats: [{ x: -30, z: -30, h: TOP, k: 'nap' }, { x: 30, z: -30, h: TOP, k: 'nap' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('lin55'), id = C.u('b55'), k = C.k, LN = '#d8ccb4', LD = '#b8aa8e', SG = '#a8b49a';
        const lin = (w, h, c) => `<rect width="${w}" height="${h}" fill="${c || LN}"/>` + linen(R, w, h, shade(c || LN, 0.88), shade(c || LN, 1.08));
        const hf = lin(148, 96) + `<rect x="3" y="3" width="142" height="90" rx="4" fill="none" stroke="${LD}" stroke-width="0.8"/>` + tufts(R, 148, 96, 9, 5, '#d0c4aa', '#7a6a4a', 9)
          + `<g opacity="0.5">${at('translate', '-60 0;180 0', 12)}<rect x="0" y="-10" width="18" height="120" fill="url(#${id}s)" transform="skewX(-18)"/></g>`;
        const head = box3(C, decC(C, { c: [0, 4, -88], w: 148, h: 96, d: 10, col: LN, r: 5, dec: { f: hf, b: lin(148, 96), t: lin(148, 10), l: lin(10, 96), r: lin(10, 96) } }));
        const rail = (w, h) => lin(w, h) + `<path d="M0 1.4H${w}M0 ${h - 1.4}H${w}" stroke="${LD}" stroke-width="0.8"/>`;
        const frame = box3(C, decC(C, { c: [0, 4, 3], w: 144, h: 24, d: 180, col: LN, r: 4, dec: { f: rail(144, 24), b: rail(144, 24), l: rail(180, 24), r: rail(180, 24), t: lin(144, 180) } }));
        const legs = [[-66, -80], [66, -80], [-66, 86], [66, 86]].map(([x, z]) => cyl3(C, [x, 0, z], [x, 4, z], 1.8, '#5a3a22', { r2: 2.2, olw: 0.2 })).join('');
        const wht = (w, h) => `<rect width="${w}" height="${h}" fill="#fbfaf7"/><path d="M0 ${f1(h * 0.5)}H${w}" stroke="#e8e6e0" stroke-width="0.5"/>`;
        const mat = box3(C, decC(C, { c: [0, 28, 3], w: 134, h: 12, d: 172, col: '#fbfaf7', r: 2, dec: { f: wht(134, 12), l: wht(172, 12), r: wht(172, 12) } }));
        const ptT = `<rect width="132" height="170" fill="#ffffff"/>` + rep(10, i => `<path d="M0 ${i * 17 + 8}H132" stroke="#eeece6" stroke-width="0.6"/>`).join('') + `<path d="M8 40Q60 34 120 44M10 100Q70 92 124 104" stroke="#e6e2d8" stroke-width="1" fill="none"/>`;
        const ptop = box3(C, decC(C, { c: [0, 40, 3], w: 132, h: 5, d: 170, col: '#ffffff', r: 2.4, dec: { t: ptT, f: wht(132, 5), l: wht(170, 5), r: wht(170, 5) } }));
        const duvT = lin(138, 70, SG) + `<path d="M0 12H138" stroke="${shade(SG, 0.8)}" stroke-width="1.2"/><path d="M0 13.4H138" stroke="#ffffff" stroke-width="0.6" opacity="0.4"/><path d="M14 30Q60 24 120 34M8 52Q70 46 130 56" stroke="${shade(SG, 0.8)}" stroke-width="1" fill="none" opacity="0.5"/>`;
        const duv = box3(C, decC(C, { c: [0, 45, 50], w: 138, h: 7, d: 70, col: SG, r: 3, dec: { t: duvT, f: lin(138, 7, SG), l: lin(70, 7, SG), r: lin(70, 7, SG) } })) + `<g transform="${FR(C, [-69, 45, 85.2], [1, 0, 0], [0, -1, 0])}">${lin(138, 14, SG)}<path d="M0 14Q34 16 69 14T138 14" stroke="${shade(SG, 0.75)}" stroke-width="1" fill="none"/></g>`;
        const sham = x => box3(C, decC(C, { c: [x, 45, -84], w: 62, h: 46, d: 7, col: SG, r: 3, ax: tiltX(0.22), dec: { f: lin(62, 46, SG) + `<rect x="5" y="5" width="52" height="36" fill="none" stroke="${shade(SG, 0.82)}" stroke-width="0.8"/><rect width="62" height="46" fill="url(#${id}v)" opacity="0.6"/><path d="M10 14Q20 20 18 34M50 12Q44 22 48 36" stroke="${shade(SG, 0.8)}" stroke-width="0.8" fill="none" opacity="0.6"/>`, t: lin(62, 7, SG) } }));
        const pt = `<rect width="58" height="28" fill="#ffffff"/><path d="M6 9Q29 5 52 11M8 20Q29 16 50 21" stroke="#ecebe6" stroke-width="0.8" fill="none"/><ellipse cx="29" cy="14" rx="20" ry="9" fill="url(#tp30)"/>`;
        const pils = pil30(C, [-32, 45, -64], 58, 11, 28, '#ffffff', pt) + pil30(C, [32, 45, -64], 58, 11, 28, '#ffffff', pt);
        const lumb = box3(C, decC(C, { c: [0, 45, -50], w: 50, h: 15, d: 9, col: '#c89048', r: 4, ax: tiltX(0.25), dec: { f: `<rect width="50" height="15" fill="#c89048"/><rect width="50" height="15" fill="url(#${id}v)"/>` + rep(5, i => `<path d="M${5 + i * 10} 2V13" stroke="#a87030" stroke-width="0.5" opacity="0.6"/>`).join('') } }))
          + [-25, 25].map(x => { const p = C.P([x, 52, -49]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><g>${at('rotate', '-8 0 0;8 0 0;-8 0 0', 3, x * 0.02, SPL(2))}<path d="M0 0V2.4" stroke="#a87030" stroke-width="0.5"/><path d="M-1 2.4H1L1.4 6H-1.4Z" fill="#d8a050"/></g></g>`; }).join('');
        const fr = C.v[2] >= 0;
        let s = shadow(C, 0, 3, 74, 96, 0.32) + legs + (fr ? head + frame + mat + ptop + sham(-34) + sham(34) + pils + lumb + duv : frame + mat + ptop + duv + lumb + pils + sham(-34) + sham(34) + head);
        C.p(-74, 0, -93); C.p(74, 0, 93); C.p(0, 102, -88);
        return { defs: DEF19 + `<defs>${TPD}<linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff4dc" stop-opacity="0"/><stop offset="0.5" stop-color="#fff4dc" stop-opacity="0.45"/><stop offset="1" stop-color="#fff4dc" stop-opacity="0"/></linearGradient>`
          + `<linearGradient id="${id}v" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.2"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-075 KING SOLID WALNUT FOUR-POSTER CANOPY BED WITH SILK DRAPES (T4): tall hand-turned solid walnut posts with brass collars and urn finials, a
    // carved arched walnut headboard with a gilded inlay line, a low footboard, a canopy of champagne silk valances with a gold bullion fringe, and heavy
    // champagne silk drapes at each post held with gold tassel tiebacks. On the bed: an ivory silk duvet with a turned-down band, four pillows and a bolster,
    // and a gold-thread throw across the foot. Bed 140 x 186 + nap seats kept. Live: the silk drapes sway with a sliding sheen and the duvet shimmers.
    N.k4p30 = S => { const TOP = 42; const D = { w: 140, d: 186, act: 'nap', seats: [{ x: -30, z: -30, h: TOP, k: 'nap' }, { x: 30, z: -30, h: TOP, k: 'nap' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('k4p30'), id = C.u('b75'), k = C.k, WN = '#5a3820', GD = '#d6b06a', SK = '#ecdcb8', PX = 66, PZ = 87, TH = 150;
        const wal = (w, h) => `<rect width="${w}" height="${h}" fill="${WN}"/>` + grainV(R, w, h, Math.max(4, Math.round(w * 0.5)), '#3a2010', 0.5) + grainV(R, w, h, 3, '#8a5a34', 0.3);
        const hb = wal(126, 84) + `<path d="M6 84V30Q6 14 30 12Q50 10 63 3Q76 10 96 12Q120 14 120 30V84" fill="none" stroke="${GD}" stroke-width="0.8"/><path d="M12 84V34Q12 20 32 18Q50 16 63 10Q76 16 94 18Q114 20 114 34V84" fill="${shade(WN, 1.12)}" stroke="#3a2010" stroke-width="0.5"/>`
          + `<g transform="translate(63 10)">${rep(7, i => { const a = -PI + (i + 0.5) * PI / 7; return `<path d="M0 0L${f1(Math.cos(a) * 6)} ${f1(Math.sin(a) * 6)}" stroke="${GD}" stroke-width="0.6"/>`; }).join('')}</g>`;
        const head = box3(C, decC(C, { c: [0, 6, -88], w: 126, h: 84, d: 5, col: WN, r: 0.8, dec: { f: hb, b: wal(126, 84), t: wal(126, 5) } }));
        const foot = box3(C, decC(C, { c: [0, 6, 88], w: 126, h: 24, d: 4, col: WN, r: 0.8, dec: { f: wal(126, 24) + `<rect x="6" y="5" width="114" height="14" fill="none" stroke="${GD}" stroke-width="0.6"/>`, b: wal(126, 24), t: wal(126, 4) } }));
        const frame = box3(C, decC(C, { c: [0, 6, 0], w: 130, h: 16, d: 172, col: WN, r: 0.8, dec: { f: wal(130, 16), l: wal(172, 16), r: wal(172, 16), b: wal(130, 16) } }));
        const post = (x, z) => cyl3(C, [x, 0, z], [x, 4, z], 3.6, WN, { r2: 3, olw: 0.3 }) + cyl3(C, [x, 4, z], [x, 30, z], 2.8, WN, { olw: 0.3 }) + cyl3(C, [x, 30, z], [x, 32, z], 3.4, GD, { mat: 'metal', olw: 0.2 })
          + H.sph(C, [x, 38, z], 4, WN) + cyl3(C, [x, 42, z], [x, TH, z], 2, WN, { r2: 1.7, olw: 0.3 }) + cyl3(C, [x, 70, z], [x, 71.6, z], 2.6, GD, { mat: 'metal', olw: 0.2 }) + H.sph(C, [x, TH + 2.6, z], 2.8, WN) + cyl3(C, [x, TH + 5, z], [x, TH + 7, z], 0.8, GD, { mat: 'metal', olw: 0.2 });
        const rails = [[[-PX, TH, -PZ], [PX, TH, -PZ]], [[-PX, TH, PZ], [PX, TH, PZ]], [[-PX, TH, -PZ], [-PX, TH, PZ]], [[PX, TH, -PZ], [PX, TH, PZ]]].map(([a, b]) => cyl3(C, a, b, 1.2, WN, { olw: 0.25 })).join('');
        const valS = L => `<rect width="${L}" height="10" fill="url(#${id}k)"/><path d="M0 0.8H${L}" stroke="${GD}" stroke-width="1"/><path d="M0 10H${L}" stroke="${GD}" stroke-width="0.6"/>` + rep(Math.round(L / 1.6), i => `<path d="M${f1(i * 1.6 + 0.8)} 10v${f1(2.4 + (i % 2) * 0.6)}" stroke="${GD}" stroke-width="0.5"/>`).join('');
        const val = (o, U, L) => `<g transform="${FR(C, o, U, [0, -1, 0])}">${valS(L)}</g>`;
        const vals = [{ z: -PZ, s: val([-PX, TH + 1, -PZ], [1, 0, 0], 2 * PX) }, { z: PZ, s: val([-PX, TH + 1, PZ], [1, 0, 0], 2 * PX) }, { x: -PX, s: val([-PX, TH + 1, -PZ], [0, 0, 1], 2 * PZ) }, { x: PX, s: val([PX, TH + 1, -PZ], [0, 0, 1], 2 * PZ) }];
        const tie = `<g transform="translate(0 ${f1(TH * 0.56)})"><rect x="-3" y="-1" width="6" height="2" rx="1" fill="${GD}"/><path d="M1 1L2 5H0Z" fill="${GD}"/><path d="M0.4 5h3.2l0.6 6h-4.4Z" fill="${GD}"/>${rep(5, i => `<path d="M${f1(0.2 + i * 0.9)} 11v2" stroke="${GD}" stroke-width="0.35"/>`).join('')}</g>`;
        const posts = [[-PX, -PZ], [PX, -PZ], [-PX, PZ], [PX, PZ]].map(([x, z]) => ({ x, z, s: post(x, z) + drape30(C, x, TH, z, x < 0 ? 1 : -1, 12, `url(#${id}k)`, -(x + z) * 0.03, tie) }));
        const mat = box3(C, { c: [0, 22, 1], w: 128, h: 14, d: 168, col: '#fbf8f2', r: 2, dec: { f: `<rect width="128" height="14" fill="#fbf8f2"/><path d="M0 7H128" stroke="#e8e2d6" stroke-width="0.5"/>` } });
        const silkT = `<rect width="132" height="146" fill="url(#${id}d)"/>` + rep(6, i => `<path d="M0 ${20 + i * 22}Q66 ${14 + i * 22} 132 ${22 + i * 22}" stroke="#d8c8a4" stroke-width="0.8" fill="none" opacity="0.6"/>`).join('') + `<rect y="0" width="132" height="10" fill="#f8f2e4"/><path d="M0 10H132" stroke="${GD}" stroke-width="0.6"/>`
          + `<g opacity="0.55">${at('translate', '-80 0;220 0', 9)}<rect x="0" y="-10" width="24" height="170" fill="url(#${id}s)" transform="skewX(-24)"/></g>`;
        const duv = box3(C, decC(C, { c: [0, 34, 10], w: 134, h: 8, d: 146, col: '#f2e8d4', r: 3, dec: { t: silkT, f: `<rect width="134" height="8" fill="#ecdec4"/>`, l: `<rect width="146" height="8" fill="#ece0c8"/>`, r: `<rect width="146" height="8" fill="#e6d8bc"/>` } }));
        const thr = box3(C, decC(C, { c: [0, 42, 60], w: 138, h: 2, d: 30, col: GD, r: 1, dec: { t: `<rect width="138" height="30" fill="#c8a058"/>` + rep(23, i => `<path d="M${i * 6} 0L${i * 6 + 15} 30" stroke="#f0d890" stroke-width="0.4" opacity="0.6"/><path d="M${i * 6 + 15} 0L${i * 6} 30" stroke="#8a6a30" stroke-width="0.3" opacity="0.5"/>`).join('') } }))
          + `<g transform="${FR(C, [-69, 43, 75.2], [1, 0, 0], [0, -1, 0])}"><rect width="138" height="12" fill="#c8a058"/>${rep(46, i => `<path d="M${i * 3 + 1} 12v2.4" stroke="${GD}" stroke-width="0.5"/>`).join('')}</g>`;
        const pt = c => `<rect width="56" height="28" fill="${c}"/><ellipse cx="28" cy="14" rx="20" ry="9" fill="url(#tp30)"/><rect x="1.4" y="1.4" width="53.2" height="25.2" fill="none" stroke="${GD}" stroke-width="0.4" opacity="0.7"/>`;
        const pils = pil30(C, [-31, 36, -78], 56, 12, 26, '#efe2c8', pt('#efe2c8'), tiltX(0.35)) + pil30(C, [31, 36, -78], 56, 12, 26, '#efe2c8', pt('#efe2c8'), tiltX(0.35))
          + pil30(C, [-31, 36, -62], 56, 10, 28, '#fbf8f2', pt('#fbf8f2')) + pil30(C, [31, 36, -62], 56, 10, 28, '#fbf8f2', pt('#fbf8f2')) + cyl3(C, [-26, 41, -46], [26, 41, -46], 5, '#d8c090', { mat: 'gloss', olw: 0.25, capCol: GD });
        const fr = C.v[2] >= 0, xs = C.v[0] >= 0;
        const back = posts.filter(p => (p.z < 0) === fr), frontP = posts.filter(p => (p.z < 0) !== fr);
        const vb = vals.filter(v => v.z != null && (v.z < 0) === fr), vf = vals.filter(v => v.z != null && (v.z < 0) !== fr), vs = vals.filter(v => v.x != null).sort((a, b) => (a.x - b.x) * (xs ? -1 : 1));
        const bed = fr ? head + frame + mat + pils + duv + thr + foot : foot + frame + mat + duv + thr + pils + head;
        let s = shadow(C, 0, 0, 74, 96, 0.34) + back.map(p => p.s).join('') + vb.map(v => v.s).join('') + bed + vs.map(v => v.s).join('') + rails + frontP.map(p => p.s).join('') + vf.map(v => v.s).join('');
        C.p(-70, 0, -93); C.p(70, 0, 93); C.p(0, TH + 9, 0);
        return { defs: DEF19 + `<defs>${TPD}<linearGradient id="${id}k" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#c8b088"/><stop offset="0.25" stop-color="#f6ead0"/><stop offset="0.5" stop-color="#d8c49c"/><stop offset="0.75" stop-color="#f2e4c4"/><stop offset="1" stop-color="#bca07a"/></linearGradient>`
          + `<linearGradient id="${id}d" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f8f0de"/><stop offset="0.5" stop-color="#ecdcbc"/><stop offset="1" stop-color="#f4e8d0"/></linearGradient>`
          + `<linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };


    // BED-095 LEVITATING ZERO-GRAVITY SMART SLEEP POD WITH CIRCADIAN CLIMATE CONTROL (T5): a pearl-white oval sleep pod with a champagne-gold rim floating
    // above a low pearl plinth on a pool of warm light. Inside: a plush quilted mattress, ivory pillows and a soft blush duvet. A translucent canopy hood
    // arches over the head end, its light strip shifting through the day's colours (dawn amber, soft gold, dusk peach); climate vents breathe warm air.
    // Bed 140 x 186 + nap seats kept (h = mattress top). Live: the pod bobs, the circadian strip shifts colour and warm air wisps rise from the rim vents.
    N.pod95 = S => { const TOP = 37; const D = { w: 140, d: 186, act: 'nap', seats: [{ x: -30, z: -30, h: TOP, k: 'nap' }, { x: 30, z: -30, h: TOP, k: 'nap' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('pod95'), id = C.u('b95'), k = C.k, GD = '#d6b26a', PE = '#f4efe8';
        const PL = (y, svg) => `<g transform="${FR(C, [0, y, 0], [1, 0, 0], [0, 0, 1])}">${svg}</g>`;
        let base = PL(0.1, `<ellipse rx="82" ry="104" fill="url(#${id}g)">${an('opacity', '0.5;0.9;0.5', 6, 0, SPL(2))}</ellipse>`); for (let i = 0; i <= 4; i++) base += PL(i, `<ellipse rx="${28 - i * 0.4}" ry="${42 - i * 0.4}" fill="${i < 4 ? shade(PE, 0.8 + i * 0.04) : PE}"/>`);
        base += PL(4.05, `<ellipse rx="26.6" ry="40.6" fill="none" stroke="${GD}" stroke-width="0.8"/><ellipse rx="20" ry="32" fill="#ffe8c0" opacity="0.6">${an('opacity', '0.4;0.8;0.4', 6, 0, SPL(2))}</ellipse>`);
        // hull: lofted ellipses from the keel up to the rim
        let hull = ''; const HY0 = 14, HY1 = 33; for (let i = 0; i <= 14; i++) { const t = i / 14, y = HY0 + (HY1 - HY0) * t, e = Math.sqrt(1 - (1 - t) * (1 - t)), rx = 26 + 40 * e, rz = 46 + 46 * e; hull += PL(y, `<ellipse rx="${f1(rx)}" ry="${f1(rz)}" fill="${shade(PE, 0.62 + 0.38 * t)}" stroke="${shade(PE, 0.55 + 0.3 * t)}" stroke-width="0.4"/>`); }
        hull += PL(HY1 - 4, `<ellipse rx="64.6" ry="90.4" fill="none" stroke="${GD}" stroke-width="0.5" opacity="0.8"/>`);
        const rim = PL(HY1 + 0.1, `<ellipse rx="66" ry="92" fill="${PE}"/><ellipse rx="66" ry="92" fill="none" stroke="${GD}" stroke-width="1.2"/><ellipse rx="61" ry="87" fill="#d8ccc0"/><ellipse rx="60" ry="86" fill="url(#${id}i)"/>`
          + rep(8, i => { const a = (i + 0.5) / 8 * 2 * PI; return `<rect x="-2.4" y="-0.5" width="4.8" height="1" rx="0.5" fill="#b8aa98" transform="translate(${f1(Math.cos(a) * 63.6)} ${f1(Math.sin(a) * 89.4)}) rotate(${f1(a * 180 / PI + 90)})"/>`; }).join(''));
        const matT = `<ellipse rx="57" ry="82" fill="#fbf8f2"/>` + rep(9, i => `<path d="M-57 ${-72 + i * 18}H57" stroke="#ece6dc" stroke-width="0.6"/>`).join('') + `<rect x="-60" y="-26" width="120" height="120" fill="#f2d4c8"/><path d="M-60 -24Q0 -30 60 -24" stroke="#fbeae2" stroke-width="6" fill="none"/><path d="M-60 -21Q0 -27 60 -21" stroke="#e2b8aa" stroke-width="0.6" fill="none"/>` + rep(5, i => `<path d="M-50 ${0 + i * 14}Q0 ${-6 + i * 14} 50 ${2 + i * 14}" stroke="#e2b8aa" stroke-width="0.8" fill="none" opacity="0.6"/>`).join('');
        const mat = PL(HY1 + 2.6, `<clipPath id="${id}c"><ellipse rx="58" ry="84"/></clipPath><g clip-path="url(#${id}c)">${matT}</g>`);
        const pils = pil30(C, [-26, HY1 + 2.6, -62], 44, 9, 24, '#fbf8f2', `<rect width="44" height="24" fill="#fbf8f2"/><ellipse cx="22" cy="12" rx="16" ry="8" fill="url(#tp30)"/>`) + pil30(C, [26, HY1 + 2.6, -62], 44, 9, 24, '#fbf8f2', `<rect width="44" height="24" fill="#fbf8f2"/><ellipse cx="22" cy="12" rx="16" ry="8" fill="url(#tp30)"/>`);
        // canopy hood: translucent half-shell over the head end (strip of quads between two arcs), circadian light strip on its front edge
        const AR = (z, sc) => rep(17, i => { const a = PI * i / 16; return [-Math.cos(a) * 60 * sc, HY1 + Math.sin(a) * 44 * sc, z]; });
        const A0 = AR(-46, 1), A1 = AR(-84, 0.86); let hood = '';
        for (let i = 0; i < 16; i++) { const q = [A0[i], A0[i + 1], A1[i + 1], A1[i]].map(p => P2(C.P(p))); hood += `<path d="M${q[0]}L${q[1]}L${q[2]}L${q[3]}Z" fill="#f6e6cc" fill-opacity="${f1(0.3 + 0.14 * Math.sin(PI * i / 16))}" stroke="#fff8ee" stroke-width="0.2" stroke-opacity="0.4"/>` + (i % 4 === 0 && i ? `<path d="M${q[0]}L${q[3]}" stroke="${GD}" stroke-width="${f1(0.6 * k)}"/>` : ''); }
        hood += `<path d="M${A1.map(p => P2(C.P(p))).join('L')}" stroke="${GD}" stroke-width="${f1(0.8 * k)}" fill="none"/><path d="M${A0.map(p => P2(C.P(p))).join('L')}" stroke="${GD}" stroke-width="${f1(1 * k)}" fill="none"/>`
          + `<path d="M${A0.map(p => P2(C.P([p[0] * 0.97, p[1] - 1.2, p[2] + 0.6]))).join('L')}" stroke="#ffc880" stroke-width="${f1(1.6 * k)}" fill="none" stroke-linecap="round" filter="url(#m12b1)">${an('stroke', '#ffb870;#ffe0a0;#ffd8b8;#ffc0a0;#ffb870', 24)}</path>`;
        const wisps = rep(4, i => { const a = (i + 0.5) / 4 * 2 * PI + 0.4, p = C.P([Math.cos(a) * 63.6, HY1 + 1, Math.sin(a) * 89.4]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><path d="M0 0q-2 -4 0 -8t0 -8" stroke="#fff4e0" stroke-width="1" fill="none" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.5;0', 5, -i * 1.2)}${at('translate', '0 0;1 -6', 5, -i * 1.2)}</path></g>`; }).join('');
        const ctrl = (() => { const p = C.P([66, HY1 - 4, 30]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><circle r="2.4" fill="none" stroke="${GD}" stroke-width="0.5"/><circle r="1.2" fill="#ffe2a8">${an('opacity', '0.5;1;0.5', 3, 0, SPL(2))}</circle></g>`; })();
        const fr = C.v[2] >= 0, bob = at('translate', '0 0;0 -2.4;0 0', 6, 0, SPL(2));
        const pod = `<g>${bob}${hull}${rim}${mat}${fr ? pils + hood : hood + pils}${wisps}${C.v[0] > 0 ? ctrl : ''}</g>`;
        let s = shadow(C, 0, 0, 50, 70, 0.3) + base + `<g filter="url(#m12b1)" opacity="0.4">${PL(4.1, '<ellipse rx="34" ry="54" fill="#7a6a5a" opacity="0.4"/>')}</g>` + pod;
        C.p(-70, 0, -93); C.p(70, 0, 93); C.p(0, HY1 + 48, -60);
        return { defs: DEF19 + `<defs>${TPD}<radialGradient id="${id}g" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffdca0" stop-opacity="0.8"/><stop offset="1" stop-color="#ffd0a0" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}i" cx="50%" cy="50%" r="50%"><stop offset="0.85" stop-color="#cfc2b4"/><stop offset="1" stop-color="#a89a8a"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // ======================= DRAWER CHESTS (BED-016/036/..): dresser 104 x 46 footprint kept =======================
    // BED-016 PLASTIC 3-DRAWER STERILITE TOWER (T1): a frosted white plastic 3-drawer tower on little casters, colourful clothes blurred behind the frosted
    // drawer fronts, the top drawer stuck half open and overstuffed, a sock caught in the middle drawer and dangling out, a stack of folded T-shirts and a
    // hair tie on top. Beside it, a blue plastic laundry basket heaped with clothes, a sleeve hanging over the edge. Live: the dangling sock sways.
    N.ster30 = S => { const D = { w: 104, d: 46, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('ster30'), id = C.u('d16'), k = C.k, TX = -22, TW = 38, TD = 30, DH = 18, Y0 = 4;
        const blobs = (w, h, n) => `<g filter="url(#m12b1)" opacity="0.55">` + rep(n, () => `<ellipse cx="${f1(R() * w)}" cy="${f1(h * 0.35 + R() * h * 0.6)}" rx="${f1(3 + R() * 5)}" ry="${f1(2 + R() * 3)}" fill="${['#e86a6a', '#5a7ab8', '#f2c84a', '#7ab87a', '#c87ab8', '#2a2a3a'][Math.floor(R() * 6)]}"/>`).join('') + `</g>`;
        const front = (w, h) => `<rect width="${w}" height="${h}" fill="#f4f6f6"/>${blobs(w, h, 7)}<rect width="${w}" height="${h}" fill="#ffffff" opacity="0.55"/><rect x="${f1(w / 2 - 6)}" y="2" width="12" height="3" rx="1.5" fill="#d8dcdc" stroke="#b8bcbc" stroke-width="0.3"/><rect x="0.3" y="0.3" width="${w - 0.6}" height="${h - 0.6}" fill="none" stroke="#ffffff" stroke-width="0.5"/>`;
        const shell = (w, h) => `<rect width="${w}" height="${h}" fill="#e8ecec"/><rect width="${w}" height="${h}" fill="#ffffff" opacity="0.3"/>`;
        const body = box3(C, decC(C, { c: [TX, Y0, 0], w: TW, h: DH * 3 + 2, d: TD, col: '#eef0f0', r: 0.8, dec: { l: shell(TD, DH * 3 + 2), r: shell(TD, DH * 3 + 2), b: shell(TW, DH * 3 + 2), t: shell(TW, TD), f: `<rect width="${TW}" height="${DH * 3 + 2}" fill="#3a3e40"/>` } }));
        const drw = (i, out) => box3(C, decC(C, { c: [TX, Y0 + 1 + i * DH, out], w: TW - 1.4, h: DH - 1, d: TD - 1, col: '#f2f4f4', r: 0.6, dec: { f: front(TW - 1.4, DH - 1), l: shell(TD - 1, DH - 1), r: shell(TD - 1, DH - 1), t: `<rect width="${TW - 1.4}" height="${TD - 1}" fill="#f4f6f6"/><rect x="1.2" y="1.2" width="${TW - 3.8}" height="${TD - 3.4}" fill="#8a9aa8"/>` + `<g>` + rep(9, () => `<ellipse cx="${f1(2 + R() * (TW - 6))}" cy="${f1(2 + R() * (TD - 6))}" rx="${f1(3 + R() * 4)}" ry="${f1(2 + R() * 3)}" fill="${['#e86a6a', '#5a7ab8', '#f2c84a', '#7ab87a', '#c87ab8', '#f2ece0'][Math.floor(R() * 6)]}"/>`).join('') + `</g>` } }));
        const casters = [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([sx, sz]) => cyl3(C, [TX + sx * 16 - 1, 2, sz * 12], [TX + sx * 16 + 1, 2, sz * 12], 2, '#3a3a3c', { olw: 0.2 })).join('');
        const sp = C.P([TX + 6, Y0 + 1 + DH * 2 - 1, TD / 2 + 0.6]), sock = `<g transform="translate(${P2(sp)}) scale(${n4(k)})"><g>${at('rotate', '-6 0 0;7 0 0;-6 0 0', 3.2, 0, SPL(2))}<path d="M-1.4 0H1.4V9Q1.4 11 3.6 11.4V13.4Q-1.4 13.6 -1.4 10Z" fill="#f2f2ee"/><path d="M-1.4 1H1.4M-1.4 2H1.4" stroke="#e86a6a" stroke-width="0.5"/><path d="M1.4 11.6Q2.6 12 3.6 13.4" stroke="#c8c8c0" stroke-width="0.6" fill="none"/></g></g>`;
        // folded tees on top + hair tie
        const tees = [['#e86a6a', 0], ['#f2ece0', 1], ['#5a7ab8', 2]].map(([c, i]) => box3(C, { c: [TX + (i - 1) * 0.6, Y0 + DH * 3 + 2 + i * 3, -1], w: 24, h: 3, d: 18, col: c, r: 1.2, dec: { t: `<rect width="24" height="18" fill="${c}"/><path d="M4 2Q12 5 20 2" stroke="${shade(c, 0.8)}" stroke-width="0.6" fill="none"/>`, f: `<rect width="24" height="3" fill="${shade(c, 0.92)}"/><path d="M1 1.5H23" stroke="${shade(c, 0.78)}" stroke-width="0.4"/>` } })).join('')
          + `<g transform="${FR(C, [TX + 8, Y0 + DH * 3 + 11.2, 2], [1, 0, 0], [0, 0, 1])}"><circle r="2" fill="none" stroke="#2a2a2a" stroke-width="0.7"/></g>`;
        // laundry basket: blue lattice walls, clothes heap top, a sleeve hanging over the front
        const BX = 30, BW = 40, BD = 30, BH = 22;
        const lat = (w, h) => `<rect width="${w}" height="${h}" fill="#4a7ac8"/>` + rep(Math.floor((w - 4) / 4), i => rep(Math.floor((h - 6) / 5), j => `<rect x="${f1(3 + i * 4)}" y="${f1(4 + j * 5)}" width="2.4" height="3.4" rx="1" fill="#2a4a88"/>`).join('')).join('') + `<rect width="${w}" height="2.4" fill="#6a96d8"/>`;
        const heap = `<rect width="${BW}" height="${BD}" fill="#4a7ac8"/><g>` + rep(16, () => { const c = ['#e86a6a', '#f2ece0', '#5a7ab8', '#2a2a3a', '#f2c84a', '#9ab8a0', '#c87ab8'][Math.floor(R() * 7)]; return `<path d="M${f1(3 + R() * (BW - 14))} ${f1(3 + R() * (BD - 12))}q${f1(4 + R() * 6)} ${f1(-2 - R() * 2)} ${f1(10 + R() * 4)} ${f1(R() * 3)}q-2 ${f1(5 + R() * 3)} ${f1(-9 - R() * 4)} ${f1(5 + R() * 2)}Z" fill="${c}" stroke="${shade(c, 0.75)}" stroke-width="0.3"/>`; }).join('') + `</g>`;
        const bsk = box3(C, decC(C, { c: [BX, 0, 4], w: BW, h: BH, d: BD, col: '#4a7ac8', r: 1.2, dec: { f: lat(BW, BH), b: lat(BW, BH), l: lat(BD, BH), r: lat(BD, BH), t: heap } }))
          + `<g transform="${FR(C, [BX - 6, BH + 0.2, 4 + BD / 2 + 0.2], [1, 0, 0], [0, -1, 0])}"><path d="M0 0H8L7.4 10Q6 12 3 11.6L1 10Z" fill="#e86a6a"/><path d="M1 10L7.4 10" stroke="#c84a4a" stroke-width="0.6"/></g>`;
        const tower = shadow(C, TX, 0, 22, 18, 0.32) + casters + body + drw(0, 0) + drw(1, 0) + drw(2, 7) + sock + tees;
        const fr = dep30(C, TX, 0) <= dep30(C, BX, 4);
        let s = (fr ? tower + shadow(C, BX, 4, 24, 18, 0.3) + bsk : shadow(C, BX, 4, 24, 18, 0.3) + bsk + tower);
        C.p(-52, 0, -23); C.p(52, 0, 23); C.p(0, 82, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-036 4-DRAWER PINE CHEST WITH WOODEN KNOBS (T2): a honey-pine chest of four graduated drawers with turned wooden knobs, a rounded overhanging top,
    // a shaped plinth with bracket feet and visible knots, the top drawer a hair proud. On top: a crocheted doily, a small framed photo, a ceramic trinket
    // dish with a ring, a jar candle and a trailing pothos in a terracotta pot. w 104 d 46 kept. Live: the candle flickers and the pothos sways.
    N.pinech30 = S => { const D = { w: 104, d: 46, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('pinech30'), id = C.u('d36'), k = C.k, PN = '#e0b474', W = 84, DD = 40, H0 = 8, HS = [16, 17, 18, 20];
        const pine = (w, h) => `<rect width="${w}" height="${h}" fill="${PN}"/>` + rep(Math.max(2, Math.round(h * 0.6)), () => { const y = R() * h; return `<path d="M0 ${f1(y)}Q${f1(w * 0.5)} ${f1(y + (R() - 0.5) * 2)} ${w} ${f1(y + (R() - 0.5))}" stroke="#b8864a" stroke-width="0.25" fill="none" opacity="0.45"/>`; }).join('') + (w > 20 ? `<ellipse cx="${f1(w * (0.2 + R() * 0.6))}" cy="${f1(h * 0.5)}" rx="1.6" ry="1" fill="#a8743a" opacity="0.5"/>` : '');
        const HT = HS.reduce((a, b) => a + b, 0) + 1.6;
        const carcass = box3(C, decC(C, { c: [0, H0, 0], w: W, h: HT, d: DD, col: PN, r: 0.4, dec: { f: `<rect width="${W}" height="${HT}" fill="#7a5028"/>`, l: pine(DD, HT), r: pine(DD, HT), b: pine(W, HT) } }));
        let yy = H0 + 0.8; const drs = HS.slice().reverse().map((h, i) => { const y = yy; yy += h; const proud = i === 3 ? 1.2 : 0;
          return box3(C, decC(C, { c: [0, y + 0.4, DD / 2 - 0.6 + proud], w: W - 3, h: h - 0.8, d: 1.6, col: PN, r: 0.4, dec: { f: pine(W - 3, h - 0.8) + `<rect x="0.6" y="0.6" width="${W - 4.2}" height="${h - 2}" fill="none" stroke="#c8965a" stroke-width="0.5"/>`, t: pine(W - 3, 1.6) } }))
            + [-1, 1].map(sx => { const p = [sx * 20, y + h / 2, DD / 2 + 1 + proud]; return cyl3(C, p, [p[0], p[1], p[2] + 1.6], 1, '#c8945a', { olw: 0.2 }) + H.sph(C, [p[0], p[1], p[2] + 2.6], 1.7, '#d8a468'); }).join(''); }).join('');
        const top = box3(C, decC(C, { c: [0, H0 + HT, 0], w: W + 4, h: 3, d: DD + 3, col: PN, r: 1.4, dec: { t: pine(W + 4, DD + 3), f: pine(W + 4, 3), l: pine(DD + 3, 3), r: pine(DD + 3, 3) } }));
        const plinth = box3(C, decC(C, { c: [0, 0, 0], w: W + 2, h: H0, d: DD + 1, col: PN, r: 0.4, dec: { f: pine(W + 2, H0) + `<path d="M8 ${H0}Q8 3 14 3H${W - 12}Q${W - 6} 3 ${W - 6} ${H0}Z" fill="#000000" opacity="0.5"/>`, l: pine(DD + 1, H0), r: pine(DD + 1, H0) } }));
        const TY = H0 + HT + 3;
        const doily = `<g transform="${FR(C, [-14, TY + 0.1, 2], [1, 0, 0], [0, 0, 1])}"><circle r="13" fill="#fbf8f0" opacity="0.92"/>${rep(16, i => `<circle cx="${f1(Math.cos(i * PI / 8) * 12)}" cy="${f1(Math.sin(i * PI / 8) * 12)}" r="1.6" fill="#fbf8f0"/>`).join('')}${rep(3, i => `<circle r="${4 + i * 3}" fill="none" stroke="#e2dccc" stroke-width="0.4" stroke-dasharray="0.8 0.6"/>`).join('')}</g>`;
        const frame = box3(C, decC(C, { c: [-20, TY, -6], w: 12, h: 15, d: 1.2, col: '#f2ece0', r: 0.3, ax: tiltX(0.15), dec: { f: `<rect width="12" height="15" fill="#f2ece0"/><rect x="1.6" y="1.6" width="8.8" height="11.8" fill="#9ac0d8"/><path d="M1.6 10Q5 7 10.4 9V13.4H1.6Z" fill="#7aa86a"/><circle cx="4.4" cy="8.4" r="1.4" fill="#e8b890"/><circle cx="7.4" cy="8" r="1.6" fill="#d8a080"/><path d="M3.4 9.6h2v3h-2ZM6.2 9.4h2.4v3.4h-2.4Z" fill="#c84a4a"/>` } }));
        const dish = cyl3(C, [-8, TY + 0.2, 8], [-8, TY + 1.4, 8], 3.6, '#e8eef0', { r2: 4.2, mat: 'gloss', olw: 0.2, capCol: '#d8e4ea' }) + `<g transform="${FR(C, [-8, TY + 1.5, 8], [1, 0, 0], [0, 0, 1])}"><circle r="1.2" fill="none" stroke="#d6b06a" stroke-width="0.4"/></g>`;
        const cnd = cyl3(C, [10, TY, 6], [10, TY + 7, 6], 3, '#e8d8b8', { mat: 'gloss', op: 0.85, olw: 0.2, capCol: '#f2e8d0' }) + (() => { const p = C.P([10, TY + 7.6, 6]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><path d="M0 0V-1" stroke="#2a2a2a" stroke-width="0.3"/><g>${at('scale', '1 1;0.85 1.15;1.05 0.9;1 1', 0.8)}<path d="M0 -1Q-1 -2.6 0 -4.4Q1 -2.6 0 -1Z" fill="#ffc860"/></g><circle cy="-2" r="3" fill="#ffd890" opacity="0.25">${an('opacity', '0.2;0.35;0.15;0.25', 1.4)}</circle></g>`; })();
        const PX = 28, PZ = -2, potS = cyl3(C, [PX, TY, PZ], [PX, TY + 7, PZ], 3.6, '#c86a42', { r2: 4.4, olw: 0.25, capCol: '#4a3220' });
        const leaf = (x, y, a, sz) => `<path d="M0 0Q${f1(sz * 0.6)} ${f1(-sz * 0.5)} ${f1(sz)} 0Q${f1(sz * 0.6)} ${f1(sz * 0.5)} 0 0Z" fill="${R() < 0.5 ? '#4e8a3e' : '#6aa04a'}" stroke="#2e5a24" stroke-width="0.12" transform="translate(${f1(x)} ${f1(y)}) rotate(${f1(a)})"/>`;
        let vines = ''; [[1, 14], [1, 22], [-1, 8], [1, 30]].forEach(([dir, L], j) => { let x = 0, y = 0, d = 'M0 0'; for (let i = 0; i < L; i++) { x += dir * (0.4 + R() * 0.7) * (i < 4 ? 1.4 : 0.3); y += i < 3 ? -1.2 : 1.1 + R() * 0.3; d += `L${f1(x)} ${f1(y)}`; if (i % 2) vines += leaf(x, y, dir > 0 ? 30 + R() * 60 : 100 + R() * 60, 2.2 + R() * 0.8); } vines = `<path d="${d}" stroke="#5a7a3a" stroke-width="0.25" fill="none"/>` + vines; });
        const plant = `<g transform="translate(${P2(C.P([PX, TY + 7, PZ]))}) scale(${n4(k)})"><g>${at('rotate', '-1.6;1.6;-1.6', 5, 0, SPL(2))}${vines}</g></g>`;
        let s = shadow(C, 0, 0, 48, 24, 0.32) + plinth + carcass + drs + top + doily + frame + dish + cnd + potS + plant;
        C.p(-52, 0, -23); C.p(52, 0, 23); C.p(0, TY + 16, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };


    // BED-056 6-DRAWER MID-CENTURY TEAK LOWBOY DRESSER (T3): a long low teak dresser with book-matched horizontal grain, six drawers in two banks with
    // sculpted recessed finger pulls along their top edges, softly rounded corners, on splayed tapered legs with brass ferrules. On top: a stack of art
    // books, a speckled ceramic vase of dried pampas and bunny tails, a brass tray with a perfume bottle. w 104 d 46 kept.
    // Live: the pampas plumes sway and a warm sheen slides along the oiled top.
    N.teak56 = S => { const D = { w: 104, d: 46, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('teak56'), id = C.u('d56'), k = C.k, TK = '#b0703c', W = 100, DD = 42, LY = 15, BH = 34;
        const teak = (w, h) => `<rect width="${w}" height="${h}" fill="${TK}"/>` + grainH(R, w, h, Math.max(3, Math.round(h * 1.2)), '#7a4420', 0.45) + grainH(R, w, h, 2, '#d89a60', 0.35);
        const dw = (W - 3) / 2, dh = (BH - 3) / 3;
        let fr = teak(W, BH) + `<rect x="1" y="1" width="${W - 2}" height="${BH - 2}" fill="#3a2010"/>`;
        for (let c = 0; c < 2; c++) for (let r = 0; r < 3; r++) { const x = 1.2 + c * (dw + 0.6), y = 1.2 + r * (dh + 0.3); fr += `<g transform="translate(${f1(x)} ${f1(y)})">${teak(dw, dh)}<path d="M${f1(dw * 0.2)} 0.2H${f1(dw * 0.8)}Q${f1(dw * 0.78)} 2.6 ${f1(dw * 0.72)} 2.6H${f1(dw * 0.28)}Q${f1(dw * 0.22)} 2.6 ${f1(dw * 0.2)} 0.2Z" fill="#4a2810"/><path d="M${f1(dw * 0.28)} 2.6H${f1(dw * 0.72)}" stroke="#e0a870" stroke-width="0.3" opacity="0.6"/></g>`; }
        const body = box3(C, decC(C, { c: [0, LY, 0], w: W, h: BH, d: DD, col: TK, r: 1.4, dec: { f: fr, l: teak(DD, BH), r: teak(DD, BH), b: teak(W, BH), t: teak(W, DD) + `<g opacity="0.5">${at('translate', '-40 0;140 0', 10)}<rect x="0" y="-4" width="16" height="${DD + 8}" fill="url(#${id}s)" transform="skewX(-20)"/></g>` } }));
        const legs = [[-44, -16], [44, -16], [-44, 16], [44, 16]].map(([x, z]) => { const sx = Math.sign(x), sz = Math.sign(z); return cyl3(C, [x + sx * 3, 0, z + sz * 2.4], [x, LY + 0.2, z], 1.1, '#6a3a1c', { r2: 1.9, olw: 0.25 }) + cyl3(C, [x + sx * 3, 0, z + sz * 2.4], [x + sx * 2.8, 1.6, z + sz * 2.2], 1.15, '#d6b06a', { mat: 'metal', olw: 0.15 }); });
        const TY = LY + BH;
        const books = [['#2a4a5a', 26, 20], ['#e8dcc4', 24, 18], ['#b84a2a', 25, 19]].map(([c, w, d], i) => box3(C, { c: [-26 + i * 0.6, TY + i * 2.6, -2], w, h: 2.6, d, col: c, r: 0.3, ax: [[Math.cos(i * 0.12), 0, -Math.sin(i * 0.12)], [0, 1, 0], [Math.sin(i * 0.12), 0, Math.cos(i * 0.12)]], dec: { f: `<rect width="${w}" height="2.6" fill="#f4efe4"/><rect width="${w}" height="0.4" fill="${c}"/><rect y="2.2" width="${w}" height="0.4" fill="${c}"/>`, t: `<rect width="${w}" height="${d}" fill="${c}"/><rect x="3" y="4" width="${w - 6}" height="2" fill="#f4efe4" opacity="0.7"/>` } })).join('');
        const VX = 10, VZ = -6, vase = cyl3(C, [VX, TY, VZ], [VX, TY + 5, VZ], 5, '#e8e0d2', { r2: 5.6, olw: 0.25 }) + cyl3(C, [VX, TY + 5, VZ], [VX, TY + 12, VZ], 5.6, '#e8e0d2', { r2: 2.2, olw: 0.25 }) + cyl3(C, [VX, TY + 12, VZ], [VX, TY + 14, VZ], 2, '#e8e0d2', { r2: 2.4, olw: 0.25, capCol: '#3a2a1a' });
        const plume = (dx, L, a, c) => `<g>${at('rotate', `${a - 3} 0 0;${a + 3} 0 0;${a - 3} 0 0`, 4 + L * 0.05, -dx * 0.3, SPL(2))}<path d="M0 0L0 ${-L}" stroke="#b89a6a" stroke-width="0.35"/><ellipse cy="${-L - 4}" rx="2.2" ry="5.4" fill="${c}"/><ellipse cy="${-L - 4}" rx="1.2" ry="4.4" fill="#ffffff" opacity="0.3"/></g>`;
        const vp = C.P([VX, TY + 14, VZ]), dried = `<g transform="translate(${P2(vp)}) scale(${n4(k)})">${plume(-2, 22, -14, '#efe2c8') + plume(1, 26, 6, '#e8d8b8') + plume(3, 18, 22, '#f2e6d0')}${[[-10, 12], [12, 14], [-4, 16]].map(([a, L]) => `<g transform="rotate(${a})"><path d="M0 0V${-L}" stroke="#a8946a" stroke-width="0.3"/><ellipse cy="${-L - 1.2}" rx="1" ry="1.6" fill="#f6eedc"/></g>`).join('')}</g>`;
        const tray = cyl3(C, [30, TY, 6], [30, TY + 1, 6], 7, '#d6b06a', { mat: 'metal', olw: 0.2, capCol: '#e8c880' }) + cyl3(C, [31, TY + 1, 6], [31, TY + 7, 6], 1.8, '#f2d8c8', { mat: 'gloss', op: 0.8, olw: 0.2 }) + cyl3(C, [31, TY + 7, 6], [31, TY + 8.6, 6], 0.9, '#d6b06a', { mat: 'metal', olw: 0.15 });
        const tops = [{ d: dep30(C, -26, -2), s: books }, { d: dep30(C, VX, VZ), s: vase + dried }, { d: dep30(C, 30, 6), s: tray }].sort((a, b) => a.d - b.d).map(o => o.s).join('');
        const legsS = legs.map((s, i) => ({ s, d: dep30(C, [-44, 44, -44, 44][i], [-16, -16, 16, 16][i]) }));
        let s = shadow(C, 0, 0, 52, 24, 0.32) + legsS.filter(l => l.d < 0).map(l => l.s).join('') + body + legsS.filter(l => l.d >= 0).map(l => l.s).join('') + tops;
        C.p(-52, 0, -23); C.p(52, 0, 23); C.p(0, TY + 46, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffe8c8" stop-opacity="0"/><stop offset="0.5" stop-color="#ffe8c8" stop-opacity="0.35"/><stop offset="1" stop-color="#ffe8c8" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-076 SHAGREEN & BRUSHED BRASS 8-DRAWER MASTER CREDENZA (T4): a long credenza faced in sea-green shagreen (the pebbled ray-skin texture) framed by
    // brushed brass inlay strips, eight drawers in two rows with slim brass bar pulls, a polished brass edge on a honed stone top, on a recessed brass
    // plinth. On top: an alabaster sphere lamp glowing warm, a stack of linen books under a rock crystal, and a black lacquer jewellery tray with a watch
    // and a pearl strand. w 104 d 46 kept. Live: the lamp glow breathes and glints slide along the brass.
    N.shag76 = S => { const D = { w: 104, d: 46, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('shag76'), id = C.u('d76'), k = C.k, BR = '#cfae6a', SG = '#97aa90', W = 102, DD = 44, PY = 6, BH = 50;
        const shag = (w, h) => `<rect width="${w}" height="${h}" fill="${SG}"/><rect width="${w}" height="${h}" fill="url(#${id}p)"/><rect width="${w}" height="${h}" fill="url(#${id}v)"/>`;
        const brush = (w, h) => `<rect width="${w}" height="${h}" fill="${BR}"/>` + rep(Math.round(h * 3), i => `<path d="M0 ${f1(i / 3)}H${w}" stroke="${i % 2 ? '#e8cc8a' : '#b8964e'}" stroke-width="0.12" opacity="0.6"/>`).join('');
        const dw = (W - 4) / 4, dh = (BH - 3) / 2;
        let fr = brush(W, BH);
        for (let c = 0; c < 4; c++) for (let r = 0; r < 2; r++) { const x = 1.6 + c * (dw + 0.27), y = 1.2 + r * (dh + 0.6); fr += `<g transform="translate(${f1(x)} ${f1(y)})">${shag(dw - 0.6, dh - 0.4)}<rect width="${f1(dw - 0.6)}" height="${f1(dh - 0.4)}" fill="none" stroke="#f0d890" stroke-width="0.35"/><rect x="${f1(dw / 2 - 5)}" y="${f1(dh / 2 - 0.7)}" width="10" height="1.4" rx="0.7" fill="#e8c878"/><rect x="${f1(dw / 2 - 5)}" y="${f1(dh / 2 - 0.7)}" width="10" height="0.5" fill="#fff0c0" opacity="0.8"/></g>`; }
        fr += `<g opacity="0.6">${at('translate', '-30 0;140 0', 7)}<rect x="0" y="-4" width="6" height="${BH + 8}" fill="url(#${id}s)" transform="skewX(-16)"/></g>`;
        const body = box3(C, decC(C, { c: [0, PY, 0], w: W, h: BH, d: DD, col: SG, r: 0.6, dec: { f: fr, l: shag(DD, BH) + `<rect width="${DD}" height="${BH}" fill="none" stroke="${BR}" stroke-width="1.2"/>`, r: shag(DD, BH) + `<rect width="${DD}" height="${BH}" fill="none" stroke="${BR}" stroke-width="1.2"/>`, b: shag(W, BH) } }));
        const plinth = box3(C, decC(C, { c: [0, 0, 0], w: W - 8, h: PY, d: DD - 6, col: BR, r: 0.4, dec: { f: brush(W - 8, PY), l: brush(DD - 6, PY), r: brush(DD - 6, PY) } }));
        const TY = PY + BH;
        const stone = (w, d) => `<rect width="${w}" height="${d}" fill="#ece6dc"/>` + rep(5, () => `<path d="M${f1(R() * w)} 0Q${f1(R() * w)} ${f1(d * 0.5)} ${f1(R() * w)} ${d}" stroke="#c8beb0" stroke-width="0.4" fill="none" opacity="0.6"/>`).join('');
        const top = box3(C, decC(C, { c: [0, TY, 0], w: W + 2, h: 2.6, d: DD + 2, col: '#ece6dc', r: 0.4, dec: { t: stone(W + 2, DD + 2), f: brush(W + 2, 2.6), l: brush(DD + 2, 2.6), r: brush(DD + 2, 2.6) } }));
        const TT = TY + 2.6;
        // alabaster sphere lamp on a brass stem
        const LX = -32, LZ = -6, lamp = cyl3(C, [LX, TT, LZ], [LX, TT + 1.6, LZ], 5, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [LX, TT + 1.6, LZ], [LX, TT + 12, LZ], 0.7, BR, { mat: 'metal', olw: 0.15 })
          + `<g filter="url(#m12b1)">${(() => { const p = C.P([LX, TT + 20, LZ]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(16 * k)}" fill="#ffd8a0" opacity="0.3">${an('opacity', '0.2;0.38;0.2', 5, 0, SPL(2))}</circle>`; })()}</g>` + H.sph(C, [LX, TT + 20, LZ], 8.6, '#f6ead6')
          + (() => { const p = C.P([LX, TT + 20, LZ]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(8.4 * k)}" fill="url(#${id}l)">${an('opacity', '0.7;1;0.7', 5, 0, SPL(2))}</circle>` + rep(4, i => `<path d="M${f1(p[0] - 6 * k + i * 3 * k)} ${f1(p[1] - 6 * k)}q${f1(2 * k)} ${f1(6 * k)} ${f1(-1 * k)} ${f1(12 * k)}" stroke="#d8c0a0" stroke-width="${f1(0.4 * k)}" fill="none" opacity="0.4"/>`).join(''); })();
        const books = [['#d8ccb4', 24, 18], ['#a8b4a8', 22, 16]].map(([c, w, d], i) => box3(C, { c: [4, TT + i * 3, 2], w, h: 3, d, col: c, r: 0.3, dec: { f: `<rect width="${w}" height="3" fill="#f4efe4"/><rect width="${w}" height="0.5" fill="${c}"/><rect y="2.5" width="${w}" height="0.5" fill="${c}"/>`, t: `<rect width="${w}" height="${d}" fill="${c}"/>` + linen(R, w, d, shade(c, 0.9), shade(c, 1.08)) } })).join('');
        const cp = C.P([4, TT + 6, 2]), crystal = `<g transform="translate(${P2(cp)}) scale(${n4(k)})"><path d="M-4 0L-3 -6L0 -9L3 -6.4L4 0Z" fill="#f2f4f6" opacity="0.85" stroke="#c8d0d8" stroke-width="0.3"/><path d="M-3 -6L0 -3L3 -6.4M0 -3V0M0 -9L0 -3" stroke="#d8dee4" stroke-width="0.3" fill="none"/><path d="M-1.6 -6L-0.4 -7.6" stroke="#ffffff" stroke-width="0.6">${an('opacity', '0;1;0', 4)}</path></g>`;
        const trayS = box3(C, decC(C, { c: [32, TT, 4], w: 22, h: 1.6, d: 14, col: '#1a1a1c', r: 0.6, dec: { t: `<rect width="22" height="14" fill="#1a1a1c"/><rect x="1" y="1" width="20" height="12" rx="0.6" fill="#2a2a2e"/><circle cx="7" cy="7" r="3" fill="${BR}"/><circle cx="7" cy="7" r="2.3" fill="#f4f0e6"/><path d="M7 7V5.2M7 7l1.2 0.6" stroke="#2a2a2a" stroke-width="0.25"/><rect x="5.6" y="1.4" width="2.8" height="2.4" fill="#5a3a24"/><rect x="5.6" y="10.2" width="2.8" height="2.4" fill="#5a3a24"/>` + rep(16, i => { const a = i / 16 * 2 * PI; return `<circle cx="${f1(15 + Math.cos(a) * 4)}" cy="${f1(7 + Math.sin(a) * 3.4)}" r="0.7" fill="#f8f4ec" stroke="#d8d0c4" stroke-width="0.1"/>`; }).join('') } }));
        const tops = [{ d: dep30(C, LX, LZ), s: lamp }, { d: dep30(C, 4, 2), s: books + crystal }, { d: dep30(C, 32, 4), s: trayS }].sort((a, b) => a.d - b.d).map(o => o.s).join('');
        let s = shadow(C, 0, 0, 54, 26, 0.34) + plinth + body + top + tops;
        C.p(-52, 0, -23); C.p(52, 0, 23); C.p(0, TT + 30, 0);
        return { defs: DEF19 + `<defs><pattern id="${id}p" width="2.2" height="2" patternUnits="userSpaceOnUse"><circle cx="0.6" cy="0.5" r="0.42" fill="#e6eedc" opacity="0.75"/><circle cx="1.7" cy="1.5" r="0.36" fill="#e6eedc" opacity="0.65"/><circle cx="1.6" cy="0.4" r="0.18" fill="#5e7258" opacity="0.6"/><circle cx="0.5" cy="1.5" r="0.2" fill="#5e7258" opacity="0.5"/></pattern>`
          + `<radialGradient id="${id}v" cx="50%" cy="50%" r="70%"><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.08"/><stop offset="1" stop-color="#3a4a32" stop-opacity="0.25"/></radialGradient>`
          + `<radialGradient id="${id}l" cx="50%" cy="45%" r="50%"><stop offset="0" stop-color="#fff2d8" stop-opacity="0.95"/><stop offset="0.7" stop-color="#ffe0b0" stop-opacity="0.4"/><stop offset="1" stop-color="#ffd8a0" stop-opacity="0"/></radialGradient>`
          + `<linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff6d8" stop-opacity="0"/><stop offset="0.5" stop-color="#fff6d8" stop-opacity="0.55"/><stop offset="1" stop-color="#fff6d8" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-096 SEAMLESS TOUCH-OPEN SMART DRESSER WITH ULTRASONIC JEWELRY CLEANER (T5): a handle-less dresser in matte ivory lacquer with hairline seams and
    // a slim champagne touch strip on a floating plinth lit from beneath. A built-in ultrasonic cleaning basin is set into the top: a shallow glass well
    // glowing warm, rings turning slowly in the shimmering water. One drawer glides open at a touch to show a blush velvet organizer of rings and earrings.
    // w 104 d 46 kept. Live: the drawer glides open and closes, the basin bubbles and ripples, the touch strip and under-glow breathe.
    N.smart96 = S => { const D = { w: 104, d: 46, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('smart96'), id = C.u('d96'), k = C.k, IV = '#f2ede4', GD = '#d6b26a', W = 100, DD = 44, PY = 7, BH = 52;
        const lac = (w, h) => `<rect width="${w}" height="${h}" fill="${IV}"/><rect width="${w}" height="${h}" fill="url(#${id}l)"/>`;
        const fr = lac(W, BH) + `<path d="M${W / 2} 0V${BH}M0 ${BH / 3}H${W}M0 ${BH * 2 / 3}H${W}" stroke="#d8d0c2" stroke-width="0.35"/><rect x="0.6" y="${f1(BH * 2 / 3 + 0.4)}" width="${f1(W / 2 - 1.2)}" height="${f1(BH / 3 - 1)}" fill="#4a3c30" opacity="0">${an('opacity', '0;0;1;1;0;0', 12, -6, KT('0;0.31;0.33;0.84;0.86;1'))}</rect>`
          + `<rect x="6" y="2" width="${W - 12}" height="0.8" rx="0.4" fill="${GD}"/><rect x="6" y="2" width="${W - 12}" height="0.8" rx="0.4" fill="#ffe8b0">${an('opacity', '0.2;0.9;0.2', 4, 0, SPL(2))}</rect>`;
        const body = box3(C, decC(C, { c: [0, PY, 0], w: W, h: BH, d: DD, col: IV, r: 1.6, dec: { f: fr, l: lac(DD, BH), r: lac(DD, BH), b: lac(W, BH) } }));
        const plinth = box3(C, { c: [0, 0, 0], w: W - 10, h: PY, d: DD - 8, col: '#cfc6b8', r: 0.6 }) + `<g filter="url(#m12b1)"><g transform="${FR(C, [0, 0.1, 0], [1, 0, 0], [0, 0, 1])}"><ellipse rx="${W * 0.58}" ry="${DD * 0.62}" fill="#ffd8a0" opacity="0.3">${an('opacity', '0.18;0.34;0.18', 5, 0, SPL(2))}</ellipse></g></g>`;
        const TY = PY + BH;
        // top with the cleaning basin cut in (right side)
        const BX = 26, BZ = 2, BR0 = 9;
        const topD = lac(W, DD) + `<g transform="translate(${W / 2 + BX} ${DD / 2 + BZ})"><ellipse rx="${BR0 + 1.6}" ry="${BR0 + 1.6}" fill="${GD}"/><ellipse rx="${BR0 + 0.6}" ry="${BR0 + 0.6}" fill="#e8dcc4"/><circle r="${BR0}" fill="url(#${id}w)"/>`
          + `<g>${at('rotate', '0;360', 16)}<g transform="translate(-3 1)"><circle r="1.8" fill="none" stroke="${GD}" stroke-width="0.7"/><circle cy="-1.9" r="0.7" fill="#e8f4ff"/></g><g transform="translate(3.4 -1.4)"><circle r="1.5" fill="none" stroke="#e8e8ec" stroke-width="0.6"/></g><g transform="translate(1 4)"><circle r="1.6" fill="none" stroke="#e8b8a0" stroke-width="0.6"/><circle cy="-1.7" r="0.5" fill="#d84a6a"/></g></g>`
          + rep(3, i => `<circle r="2" fill="none" stroke="#ffffff" stroke-width="0.3" opacity="0">${an('r', `1;${BR0}`, 3, -i)}${an('opacity', '0.7;0', 3, -i)}</circle>`).join('')
          + rep(8, i => `<circle cx="${f1((R() - 0.5) * BR0 * 1.4)}" cy="0" r="0.35" fill="#ffffff" opacity="0">${an('cy', `${f1(BR0 * 0.6)};${f1(-BR0 * 0.6)}`, 1.6 + R(), -i * 0.3)}${an('opacity', '0;0.8;0', 1.6 + R(), -i * 0.3)}</circle>`).join('')
          + `<circle r="${BR0}" fill="none" stroke="#ffffff" stroke-width="0.4" opacity="0.6"/></g><rect x="${W / 2 + BX - 4}" y="${DD / 2 + BZ + BR0 + 3}" width="8" height="1" rx="0.5" fill="#ffe2a8">${an('opacity', '0.4;1;0.4', 2.4)}</rect>`;
        const top = box3(C, decC(C, { c: [0, TY, 0], w: W + 1, h: 1.6, d: DD + 1, col: IV, r: 0.8, dec: { t: topD } }));
        // the touch-open drawer (bottom-left): front panel + exposed velvet organizer slide out along +z (screen-space translate)
        const DX0 = -W / 2 + 0.4, DY0 = PY + 0.4, DWW = W / 2 - 0.8, DHH = BH / 3 - 0.8, OUT = 16;
        const p0 = C.P([0, 0, 0]), p1 = C.P([0, 0, OUT]), dv = `${f1(p1[0] - p0[0])} ${f1(p1[1] - p0[1])}`;
        const slide = at('translate', `0 0;0 0;${dv};${dv};0 0;0 0`, 12, -6, ' calcMode="spline" keyTimes="0;0.3;0.42;0.75;0.87;1" keySplines="0 0 1 1;0.4 0 0.6 1;0 0 1 1;0.4 0 0.6 1;0 0 1 1"');
        const vel = `<rect width="${DWW}" height="${OUT}" fill="#d8a8a4"/>` + rep(5, i => `<path d="M${f1((i + 1) * DWW / 6)} 0V${OUT}" stroke="#b88884" stroke-width="0.8"/>`).join('') + rep(5, i => `<circle cx="${f1((i + 0.5) * DWW / 6)}" cy="${f1(OUT * 0.4)}" r="1.4" fill="none" stroke="${i % 2 ? '#e8e8ec' : GD}" stroke-width="0.6"/><circle cx="${f1((i + 0.5) * DWW / 6)}" cy="${f1(OUT * 0.75)}" r="0.6" fill="${['#e8f4ff', '#d84a6a', '#f8f4ec', '#4a8ad8', '#e8f4ff'][i]}"/>`).join('');
        const tray = `<g opacity="0">${an('opacity', '0;0;1;1;0;0', 12, -6, KT('0;0.36;0.42;0.75;0.8;1'))}<g transform="${FR(C, [DX0, DY0 + DHH - 1.2, DD / 2 - OUT], [1, 0, 0], [0, 0, 1])}">${vel}<rect width="${DWW}" height="${OUT}" fill="url(#${id}d)"/></g></g>`;
        const dfront = box3(C, { c: [DX0 + DWW / 2, DY0, DD / 2 + 0.6], w: DWW, h: DHH, d: 1.2, col: IV, r: 0.4, dec: { f: lac(DWW, DHH) } });
        const drawer = `<g>${slide}${tray}${dfront}</g>`;
        const fr0 = C.v[2] >= 0;
        let s = shadow(C, 0, 0, 54, 26, 0.3) + plinth + body + top + (fr0 ? drawer : '');
        C.p(-52, 0, -23); C.p(52, 0, 23 + OUT); C.p(0, TY + 4, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}l" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.45"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#b8a888" stop-opacity="0.18"/></linearGradient>`
          + `<radialGradient id="${id}w" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff2d8"/><stop offset="0.7" stop-color="#f2dcb8"/><stop offset="1" stop-color="#d8bc94"/></radialGradient>`
          + `<linearGradient id="${id}d" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000000" stop-opacity="0.35"/><stop offset="0.4" stop-color="#000000" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };


    // ======================= BED LINENS (BED-018/038/..): the 'linens' piece is a stack of bedding (90 x 60) - kept as a folded stack, made real =======================
    const yawM = a => [[Math.cos(a), 0, -Math.sin(a)], [0, 1, 0], [Math.sin(a), 0, Math.cos(a)]];
    // folded fabric layer: fold edges + soft creases on the front, fabric fill on the other faces
    const fold30 = (C, c, w, h, d, col, a, fab, opt) => { const fe = (W, H) => fab(W, H) + `<path d="M0 ${f1(H * 0.5)}Q${f1(W * 0.5)} ${f1(H * 0.5 + 0.8)} ${W} ${f1(H * 0.5)}" stroke="${shade(col, 0.72)}" stroke-width="0.6" fill="none" opacity="0.6"/><rect width="${W}" height="${f1(H * 0.3)}" fill="#ffffff" opacity="0.12"/><rect y="${f1(H * 0.75)}" width="${W}" height="${f1(H * 0.25)}" fill="#000000" opacity="0.1"/>`;
      return box3(C, decC(C, Object.assign({ c, w, h, d, col, r: Math.min(h / 2, 3), ax: yawM(a || 0), dec: { f: fe(w, h), b: fe(w, h), l: fab(d, h), r: fe(d, h), t: fab(w, d) } }, opt || {}))); };

    // BED-018 PILLED POLYESTER BLANKET & FLAT PILLOW (T1): a faded maroon polyester fleece blanket folded sloppily in three, covered in pills and lint, its
    // satin binding frayed and coming loose in a dangling strip, with a flat yellowed polyester pillow sagging on top, a loose thread trailing.
    // Live: the loose binding strip sways and a little static spark crackles now and then.
    N.pill30 = S => { const D = { w: 90, d: 60, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('pill30'), id = C.u('l18'), k = C.k, MR = '#8a4a4a';
        const fleece = (w, h) => `<rect width="${w}" height="${h}" fill="${MR}"/><rect width="${w}" height="${h}" fill="url(#${id}p)"/>` + rep(Math.round(w * h / 14), () => `<circle cx="${f1(R() * w)}" cy="${f1(R() * h)}" r="${f1(0.3 + R() * 0.3)}" fill="${R() < 0.6 ? '#a86a68' : '#6a3a3a'}"/>`).join('') + rep(Math.round(w * h / 160), () => `<path d="M${f1(R() * w)} ${f1(R() * h)}q1 -0.6 2 0" stroke="#d8c8b8" stroke-width="0.2" fill="none" opacity="0.7"/>`).join('');
        const L = [[0, 0, 80, 7, 52, 0.02], [1.6, 7, 78, 7, 50, -0.04], [-1, 14, 76, 6.4, 49, 0.05]].map(([dx, y, w, h, d, a]) => fold30(C, [dx, y, 0], w, h, d, MR, a, fleece));
        const bind = (() => { const p = C.P([40, 13, 22]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><g>${at('rotate', '-6 0 0;8 0 0;-6 0 0', 3.4, 0, SPL(2))}<path d="M0 0Q2 6 0.6 12Q0 15 1.6 17" stroke="#c89a98" stroke-width="1.6" fill="none" stroke-linecap="round"/><path d="M0 0Q2 6 0.6 12" stroke="#e8c8c4" stroke-width="0.4" fill="none"/>${rep(4, i => `<path d="M1.6 ${17 + i * 0.1}l${f1(-1 + i * 0.6)} 1.6" stroke="#c89a98" stroke-width="0.25"/>`).join('')}</g></g>`; })();
        const pil = box3(C, decC(C, { c: [-2, 20.4, -2], w: 54, h: 4.4, d: 32, col: '#ece2c4', r: 2.2, ax: yawM(-0.1), dec: { t: `<rect width="54" height="32" fill="#ece2c4"/><ellipse cx="26" cy="16" rx="16" ry="9" fill="#d8c8a0" opacity="0.6"/><path d="M27 2Q26 16 28 30" stroke="#d2c6a4" stroke-width="1.2" fill="none"/><path d="M6 6q8 3 16 1M32 25q8 -3 16 0" stroke="#cfc2a0" stroke-width="0.6" fill="none"/>`, f: `<rect width="54" height="4.4" fill="#e2d8b8"/><path d="M0 2.2H54" stroke="#cfc2a0" stroke-width="0.3" stroke-dasharray="1 0.6"/>` } }));
        const thread = line3(C, [[-30, 24.6, 8], [-34, 22, 14], [-36, 14, 20], [-40, 0.4, 24], [-46, 0.3, 28]], 0.18, '#e8dcc0');
        const sp = C.P([10, 25, 0]), spark = `<g transform="translate(${P2(sp)}) scale(${n4(k)})" opacity="0">${an('opacity', '0;0;1;0;1;0;0', 9, 0, KT('0;0.8;0.81;0.82;0.83;0.85;1'))}<path d="M0 -6L1.4 -3L-0.6 -2.4L1 1" stroke="#fff6c0" stroke-width="0.5" fill="none"/><circle r="1.6" fill="#fff6c0" opacity="0.5"/></g>`;
        let s = shadow(C, 0, 0, 44, 30, 0.32) + L.join('') + bind + pil + thread + spark;
        C.p(-45, 0, -30); C.p(45, 0, 30); C.p(0, 28, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}p" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.12"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-038 CRISP COTTON PERCALE DUVET & DOWN-ALTERNATIVE PILLOWS (T2): a neatly folded set of crisp white cotton percale: a duvet cover folded into a
    // tall stack with a navy stitched hem, a fitted sheet and pillowcases beneath in soft blue stripe, wrapped in a kraft paper band with a little swing
    // tag on twine, and two plump down-alternative pillows leaning against the stack. Live: the swing tag turns on its string and a sheen slides along the
    // folds.
    N.perc30 = S => { const D = { w: 90, d: 60, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('perc30'), id = C.u('l38'), k = C.k;
        const white = (w, h) => `<rect width="${w}" height="${h}" fill="#fbfaf7"/>` + rep(Math.round(h * 2), i => `<path d="M0 ${f1(i * 0.5)}H${w}" stroke="#eceae4" stroke-width="0.12"/>`).join('') + `<path d="M0 ${f1(h - 1.2)}H${w}" stroke="#2a3a6a" stroke-width="0.25" stroke-dasharray="0.8 0.5"/>`;
        const stripe = (w, h) => `<rect width="${w}" height="${h}" fill="#f2f6fa"/>` + rep(Math.round(w / 2.4), i => `<rect x="${f1(i * 2.4)}" width="0.8" height="${h}" fill="#9ab4d0" opacity="0.6"/>`).join('');
        const SX = -12, L = [[0, 6, stripe, '#eef2f6'], [6, 6, stripe, '#eef2f6'], [12, 6, white, '#fbfaf7'], [18, 6, white, '#fbfaf7'], [24, 6, white, '#fbfaf7']].map(([y, h, fab, col], i) => fold30(C, [SX + (i % 2) * 0.6, y, -4], 52, h, 40, col, (i % 3 - 1) * 0.015, fab));
        const kr = (w, h) => `<rect width="${w}" height="${h}" fill="#c8a06a"/><rect x="${f1(w * 0.3)}" y="${f1(h * 0.25)}" width="${f1(w * 0.4)}" height="${f1(h * 0.5)}" fill="#f4ecdc"/><path d="M${f1(w * 0.35)} ${f1(h * 0.42)}h${f1(w * 0.3)}M${f1(w * 0.35)} ${f1(h * 0.6)}h${f1(w * 0.18)}" stroke="#2a3a6a" stroke-width="0.35"/>`;
        const band = box3(C, decC(C, { c: [SX + 0.3, -0.2, -4], w: 9, h: 30.6, d: 40.6, col: '#c8a06a', r: 0.4, dec: { f: kr(9, 30.6), t: `<rect width="9" height="40.6" fill="#c8a06a"/>`, l: `<rect width="40.6" height="30.6" fill="#c8a06a"/>`, r: `<rect width="40.6" height="30.6" fill="#c8a06a"/>`, b: `<rect width="9" height="30.6" fill="#c8a06a"/>` } }));
        const tp = C.P([SX + 4.5, 24, 16.4]), tag = `<g transform="translate(${P2(tp)}) scale(${n4(k)})"><path d="M0 0V3" stroke="#8a6a3a" stroke-width="0.25"/><g transform="translate(0 3)"><g>${at('skewX', '-30;30;-30', 4, 0, SPL(2))}<path d="M-2 0H2V5L0 6.4L-2 5Z" fill="#f4ecdc" stroke="#c8b898" stroke-width="0.2"/><circle cy="1" r="0.4" fill="#c8b898"/><path d="M-1.2 3h2.4M-1.2 4h1.6" stroke="#2a3a6a" stroke-width="0.25"/></g></g></g>`;
        const sheen = (() => { const a = C.P([SX - 26, 30.1, -24]), b = C.P([SX + 26, 30.1, -24]), c2 = C.P([SX + 26, 30.1, 16]), d = C.P([SX - 26, 30.1, 16]); const cid = C.u('sc'); return `<clipPath id="${cid}"><path d="M${P2(a)}L${P2(b)}L${P2(c2)}L${P2(d)}Z"/></clipPath><g clip-path="url(#${cid})"><g opacity="0.6">${at('translate', `${f1(-60 * k)} 0;${f1(60 * k)} 0`, 6)}<rect x="${f1((a[0] + c2[0]) / 2 - 4 * k)}" y="${f1(Math.min(a[1], b[1]) - 10)}" width="${f1(8 * k)}" height="${f1(60 * k)}" fill="url(#${id}s)" transform="skewX(-20)"/></g></g>`; })();
        // two plump pillows leaning on the right
        const pil = (x, y, z, a) => box3(C, decC(C, { c: [x, y, z], w: 30, h: 12, d: 44, col: '#ebe8de', r: 5.9, olw: 0.4, olc: '#a09c90', ax: yawM(a), dec: { t: `<rect width="30" height="44" fill="#f2f0e8"/><ellipse cx="15" cy="22" rx="11" ry="16" fill="url(#tp30)"/><path d="M15 2V42" stroke="#eeece6" stroke-width="0.6"/>`, f: `<rect width="30" height="13" fill="#e2dfd4"/><path d="M0 6.5H30" stroke="#e2e0d8" stroke-width="0.6"/>`, r: `<rect width="44" height="13" fill="#d8d4c8"/><path d="M0 6.5H44" stroke="#dedcd4" stroke-width="0.6"/>`, l: `<rect width="44" height="13" fill="#e8e5dc"/>` } }));
        const pils = { d: dep30(C, 28, 2), s: pil(28, 0, 2, 0.08) + pil(27, 12, 1, -0.1) };
        const stack = { d: dep30(C, SX, -4), s: L.join('') + band + sheen + tag };
        let s = shadow(C, 0, 0, 44, 30, 0.3) + [stack, pils].sort((a, b) => a.d - b.d).map(o => o.s).join('');
        C.p(-45, 0, -30); C.p(45, 0, 30); C.p(0, 34, 0);
        return { defs: DEF19 + `<defs>${TPD}<linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.7"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-058 WASHED BELGIAN FLAX LINEN BEDDING & CHUNKY KNIT THROW (T3): stone-washed Belgian flax bedding in oatmeal, clay and sage, softly rumpled and
    // stacked in a low woven seagrass basket with rope handles, frayed hems showing, a cream chunky-knit throw with fat loops spilling over the basket rim
    // and a sprig of dried lavender tied with twine on top. Live: the throw's pom tassel swings and the lavender nods.
    N.flax30 = S => { const D = { w: 90, d: 60, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('flax30'), id = C.u('l58'), k = C.k, BW = 80, BD = 52, BH = 16;
        const sea = (w, h) => `<rect width="${w}" height="${h}" fill="#c8b07a"/>` + rep(Math.round(h / 1.6), j => rep(Math.round(w / 3), i => `<path d="M${f1(i * 3 + (j % 2) * 1.5)} ${f1(j * 1.6)}q0.75 0.8 1.5 0" stroke="${(i + j) % 3 ? '#a88c54' : '#e2cc96'}" stroke-width="0.7" fill="none"/>`).join('')).join('') + `<rect width="${w}" height="1.4" fill="#9a7e48"/>`;
        const bsk = box3(C, decC(C, { c: [0, 0, 0], w: BW, h: BH, d: BD, col: '#c8b07a', r: 2, dec: { f: sea(BW, BH), b: sea(BW, BH), l: sea(BD, BH), r: sea(BD, BH), t: `<rect width="${BW}" height="${BD}" fill="#8a7448"/>` } }));
        const handles = [-1, 1].map(sx => line3(C, [[sx * (BW / 2 + 0.6), BH - 3, -8], [sx * (BW / 2 + 3), BH - 1, -4], [sx * (BW / 2 + 3), BH - 1, 4], [sx * (BW / 2 + 0.6), BH - 3, 8]], 1.4, '#d8c4a0')).join('');
        const lin = (c) => (w, h) => `<rect width="${w}" height="${h}" fill="${c}"/>` + linen(R, w, h, shade(c, 0.86), shade(c, 1.08)) + rep(3, () => `<path d="M${f1(R() * w)} 0q${f1((R() - 0.5) * 4)} ${f1(h * 0.5)} ${f1((R() - 0.5) * 3)} ${h}" stroke="${shade(c, 0.78)}" stroke-width="0.5" fill="none" opacity="0.5"/>`).join('') + `<path d="M0 ${f1(h - 0.4)}H${w}" stroke="${shade(c, 0.9)}" stroke-width="0.4" stroke-dasharray="0.3 0.4"/>`;
        const L = [[BH - 2, 6, '#c89a7a', 0.03], [BH + 4, 6, '#d8ccb4', -0.05], [BH + 10, 5.4, '#a8b49a', 0.06], [BH + 15.4, 5.4, '#e2d8c6', -0.02]].map(([y, h, c, a], i) => fold30(C, [(i % 2 ? 1.6 : -1.4) - 6, y, -3], 60, h, 40, c, a, lin(c)));
        // chunky knit throw: lies over the top of the stack and spills over the front rim
        const knit = (w, h) => { let o = `<rect width="${w}" height="${h}" fill="#efe6d4"/>`; for (let x = 2.5; x < w; x += 5) for (let y = 0; y < h; y += 3) o += `<path d="M${f1(x - 2)} ${f1(y)}Q${f1(x - 1.6)} ${f1(y + 2.6)} ${f1(x)} ${f1(y + 3)}Q${f1(x + 1.6)} ${f1(y + 2.6)} ${f1(x + 2)} ${f1(y)}" fill="#f8f2e6" stroke="#d2c4a8" stroke-width="0.35"/>`; return o; };
        const TT = BH + 20.8;
        const thTop = `<g transform="${FR(C, [8, TT + 0.2, -8], [1, 0, 0], [0, 0, 1])}"><path d="M0 0H22L24 30H-2Z" fill="url(#${id}k)"/></g>`;
        const thFront = `<g transform="${FR(C, [6, TT, 17], [1, 0, 0], [0, -1, 0])}"><path d="M0 0H26Q27 14 26 ${TT - 4}Q14 ${TT - 2} 2 ${TT - 3}Q-1 14 0 0Z" fill="url(#${id}k)"/><path d="M2 ${TT - 3}Q14 ${TT - 2} 26 ${TT - 4}" stroke="#d2c4a8" stroke-width="0.6" fill="none"/></g>`;
        const tp = C.P([30, TT - 22, 18]), pom = `<g transform="translate(${P2(tp)}) scale(${n4(k)})"><g>${at('rotate', '-10 0 0;10 0 0;-10 0 0', 3, 0, SPL(2))}<path d="M0 0V4" stroke="#e2d8c4" stroke-width="0.6"/><circle cy="6" r="2.6" fill="#f2ead8"/>${rep(10, i => `<path d="M0 6l${f1(Math.cos(i * 0.63) * 2.8)} ${f1(Math.sin(i * 0.63) * 2.8)}" stroke="#ded2b8" stroke-width="0.3"/>`).join('')}</g></g>`;
        const lp = C.P([-14, TT + 0.4, 0]), lav = `<g transform="translate(${P2(lp)}) scale(${n4(k)}) rotate(-70)"><g>${at('rotate', '-3 0 0;3 0 0;-3 0 0', 4, 0, SPL(2))}${rep(5, i => `<g transform="rotate(${(i - 2) * 8})"><path d="M0 0V-14" stroke="#7a8a5a" stroke-width="0.35"/>${rep(6, j => `<ellipse cx="${j % 2 ? 0.5 : -0.5}" cy="${-9 - j * 1}" rx="0.6" ry="0.9" fill="${j % 2 ? '#8a6aa8' : '#9a7ab8'}"/>`).join('')}</g>`).join('')}<path d="M-1.6 -3H1.6" stroke="#b8946a" stroke-width="0.8"/></g></g>`;
        const fr = C.v[2] >= 0;
        let s = shadow(C, 0, 0, 44, 30, 0.3) + (fr ? handles + bsk : bsk + handles) + L.join('') + thTop + lav + (fr ? thFront + pom : '');
        C.p(-45, 0, -30); C.p(45, 0, 30); C.p(0, TT + 6, 0);
        return { defs: DEF19 + `<defs><pattern id="${id}k" width="5" height="3" patternUnits="userSpaceOnUse"><rect width="5" height="3" fill="#efe6d4"/><path d="M0.5 0Q0.9 2.6 2.5 3Q4.1 2.6 4.5 0" fill="#f8f2e6" stroke="#d2c4a8" stroke-width="0.35"/></pattern></defs>`, front: s, bb: C.bb(3) }; };
      return D; };


    // BED-078 1000-THREAD-COUNT MULBERRY SILK SHEETS & GOOSE-DOWN CLOUD COMFORTER (T4): a lofty ivory goose-down comforter folded into a plump cloud with
    // sewn-through baffle boxes, on a stack of champagne, blush and ivory mulberry silk sheets with a liquid sheen, a pair of silk pillowcases folded on top
    // with a gold-embroidered monogram tag, tied round with a wide champagne satin ribbon and bow. Live: a satin sheen glides across the silk folds and the
    // ribbon tails stir.
    N.silk78 = S => { const D = { w: 90, d: 60, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('silk78'), id = C.u('l78'), k = C.k, GD = '#d6b26a';
        const silk = c => (w, h) => `<rect width="${w}" height="${h}" fill="${c}"/><rect width="${w}" height="${h}" fill="url(#${id}g)"/><g opacity="0.7">${at('translate', `${-w} 0;${w * 2} 0`, 6)}<rect x="0" y="-2" width="${f1(w * 0.2)}" height="${h + 4}" fill="url(#${id}s)" transform="skewX(-25)"/></g>`;
        const S0 = [['#e8d4b0', 0], ['#ecc8bc', 4.2], ['#f4ecdc', 8.4]].map(([c, y], i) => fold30(C, [i % 2 ? 0.8 : -0.6, y, 0], 74, 4.2, 50, c, (i - 1) * 0.02, silk(c))).join('');
        const down = (w, h) => { let o = `<rect width="${w}" height="${h}" fill="#f8f4ec"/>`; const nx = 4, ny = Math.max(1, Math.round(h / 12)), bx = w / nx, by = h / ny;
          for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) o += `<ellipse cx="${f1((i + 0.5) * bx)}" cy="${f1((j + 0.5) * by)}" rx="${f1(bx * 0.48)}" ry="${f1(by * 0.48)}" fill="url(#tp30)"/>`;
          for (let i = 1; i < nx; i++) o += `<path d="M${f1(i * bx)} 0V${h}" stroke="#ddd4c4" stroke-width="0.7"/>`; for (let j = 1; j < ny; j++) o += `<path d="M0 ${f1(j * by)}H${w}" stroke="#ddd4c4" stroke-width="0.7"/>`;
          return o + `<rect width="${w}" height="${h}" fill="none" stroke="#e8dcc8" stroke-width="1"/>`; };
        const com = box3(C, decC(C, { c: [0, 12.6, 0], w: 70, h: 20, d: 48, col: '#f8f4ec', r: 7, dec: { t: down(70, 48), f: down(70, 20), b: down(70, 20), l: down(48, 20), r: down(48, 20) } }));
        const pc = fold30(C, [2, 32.6, -2], 40, 3.6, 26, '#efe2c8', 0.06, silk('#efe2c8'));
        const tg = (() => { const p = C.P([18, 34, 11]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><rect x="-3" y="-1.6" width="6" height="3.2" rx="0.4" fill="#fbf6ea" stroke="${GD}" stroke-width="0.3"/><path d="M-1.4 0.8L-0.7 -0.8L0 0.4L0.7 -0.8L1.4 0.8" stroke="${GD}" stroke-width="0.35" fill="none"/></g>`; })();
        // satin ribbon round the stack (front + top strips) and a bow
        const RB = '#e2c890', RT = 32.7, strip = (w, h) => silk(RB)(w, h) + `<path d="M0.4 0V${h}M${w - 0.4} 0V${h}" stroke="#b89a5a" stroke-width="0.25"/>`;
        const rib = (C.v[2] >= 0 ? `<g transform="${FR(C, [-17, RT, 25.6], [1, 0, 0], [0, -1, 0])}">${strip(6, RT)}</g>` : `<g transform="${FR(C, [-11, RT, -25.6], [-1, 0, 0], [0, -1, 0])}">${strip(6, RT)}</g>`) + `<g transform="${FR(C, [-17, RT + 0.05, -25.6], [1, 0, 0], [0, 0, 1])}">${strip(6, 51.2)}</g>`;
        const bp = C.P([-14, RT, 18]), bow = `<g transform="translate(${P2(bp)}) scale(${n4(k)})"><path d="M0 0Q-8 -7 -10 -1Q-8 4 0 0Z" fill="${RB}" stroke="#b89a5a" stroke-width="0.3"/><path d="M0 0Q8 -7 10 -1Q8 4 0 0Z" fill="${RB}" stroke="#b89a5a" stroke-width="0.3"/><path d="M-6 -2Q-4 -1 -1 -0.4M6 -2Q4 -1 1 -0.4" stroke="#fff4d8" stroke-width="0.6" fill="none"/>`
          + `<g>${at('rotate', '-6 0 0;6 0 0;-6 0 0', 4, 0, SPL(2))}<path d="M-1 0.6L-5 10L-3 9.4L-2.4 11L0 1Z" fill="${RB}" stroke="#b89a5a" stroke-width="0.25"/><path d="M1 0.6L4 10L2.2 9.6L1.4 11.2L0 1Z" fill="${shade(RB, 0.92)}" stroke="#b89a5a" stroke-width="0.25"/></g><ellipse rx="1.8" ry="1.6" fill="${shade(RB, 0.9)}" stroke="#b89a5a" stroke-width="0.3"/></g>`;
        let s = shadow(C, 0, 0, 42, 30, 0.3) + S0 + com + rib + pc + tg + bow;
        C.p(-45, 0, -30); C.p(45, 0, 30); C.p(0, 40, 0);
        return { defs: DEF19 + `<defs>${TPD}<linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.35"/><stop offset="0.45" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0.18"/><stop offset="1" stop-color="#8a6a40" stop-opacity="0.12"/></linearGradient>`
          + `<linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.75"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-098 SELF-MAKING TEMPERATURE-REGULATING CASHMERE & SILVER-ION SMART BEDDING (T5): dove-grey cashmere bedding woven with a faint grid of silver-ion
    // thread, stacked on a slim champagne-gold charging tray; the top layer folds itself, its corner lifting, turning over and settling with a crisp fold. A
    // warm-to-cool band of light travels along an embedded thread as it regulates, and a small control puck beside it shows a breathing temperature ring.
    // Live: the top fold lifts and turns over on its own, the temperature band travels, the silver grid glints and the puck ring breathes.
    N.smartbed30 = S => { const D = { w: 90, d: 60, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('smartbed30'), id = C.u('l98'), k = C.k, GD = '#d6b26a', CG = '#c8c4c0';
        const cash = c => (w, h) => `<rect width="${w}" height="${h}" fill="${c}"/>` + rep(Math.round(h * 2), i => `<path d="M0 ${f1(i * 0.5)}H${w}" stroke="${shade(c, 0.94)}" stroke-width="0.15"/>`).join('') + `<rect width="${w}" height="${h}" fill="url(#${id}g)"/>`;
        const tray = box3(C, { c: [0, 0, 0], w: 78, h: 2.4, d: 54, col: GD, r: 1, dec: { t: `<rect width="78" height="54" fill="#e2c890"/><rect x="2" y="2" width="74" height="50" rx="1.4" fill="#d6b26a"/>`, f: `<rect width="78" height="2.4" fill="${GD}"/><rect x="34" y="0.8" width="10" height="0.8" rx="0.4" fill="#fff0c8">${an('opacity', '0.3;1;0.3', 3, 0, SPL(2))}</rect>` } });
        const L = [[2.4, '#bcb8b4'], [7.4, '#d8d4d0'], [12.4, CG]].map(([y, c], i) => fold30(C, [i % 2 ? 0.6 : -0.6, y, 0], 70, 5, 48, c, 0, cash(c))).join('');
        const TOPY = 17.4;
        const grid = (() => { const a = C.P([-35, TOPY + 0.05, -24]), cid = C.u('gc'); return `<g transform="${FR(C, [-35, TOPY + 0.05, -24], [1, 0, 0], [0, 0, 1])}"><clipPath id="${cid}"><rect width="70" height="48"/></clipPath><g clip-path="url(#${cid})">${rep(15, i => `<path d="M${i * 5} 0V48" stroke="#eef0f4" stroke-width="0.2" opacity="0.6"/>`).join('')}${rep(10, i => `<path d="M0 ${i * 5}H70" stroke="#eef0f4" stroke-width="0.2" opacity="0.6"/>`).join('')}`
          + `<rect x="0" y="22" width="18" height="2.4" rx="1.2" fill="url(#${id}t)">${an('x', '-18;70', 5)}</rect><g opacity="0.7">${at('translate', '-30 0;100 0', 7)}<rect x="0" y="-4" width="4" height="56" fill="#ffffff" opacity="0.4" transform="skewX(-25)"/></g></g></g>`; })();
        // self-folding top flap: a 70 x 22 half-layer hinged on the line z = 0 at the top; angle 0 = lying folded back toward -z, PI = flat toward +z
        const AN = [0.06, 0.06, 1.6, 3.06, 3.06, 1.6, 0.06], KTs = KT('0;0.15;0.3;0.45;0.65;0.8;1'), T = 12, HW = 35, FL = 22;
        const fp = (a, x, t) => C.P([x, TOPY + 2.4 + Math.sin(a) * t, -Math.cos(a) * t]);
        const qd2 = (t0, t1) => a => 'M' + P2(fp(a, -HW, t0)) + 'L' + P2(fp(a, HW, t0)) + 'L' + P2(fp(a, HW, t1)) + 'L' + P2(fp(a, -HW, t1)) + 'Z';
        const animP = (fn, fill, ex) => `<path d="${fn(AN[0])}" fill="${fill}"${ex || ''}>${an('d', AN.map(fn).join(';'), T, 0, KTs)}</path>`;
        const flap = animP(qd2(0, FL), '#d4d0cc', ' stroke="#a8a4a0" stroke-width="0.3"') + animP(qd2(FL - 1.2, FL), '#e8e4e0') + animP(qd2(0, 1.6), '#b8b4b0');
        const base2 = fold30(C, [0, TOPY, 0], 70, 2.4, 48, '#d2ceca', 0, cash('#d2ceca'));
        // control puck
        const pp = C.P([40, 0.2, 22]), puck = cyl3(C, [40, 0, 22], [40, 2, 22], 4.4, '#f2ece2', { mat: 'gloss', olw: 0.2, capCol: '#f8f4ec' }) + `<g transform="${FR(C, [40, 2.05, 22], [1, 0, 0], [0, 0, 1])}"><circle r="3" fill="none" stroke="#e8d8c0" stroke-width="0.5"/><circle r="3" fill="none" stroke="#ffc890" stroke-width="0.7" stroke-dasharray="6 13">${an('stroke', '#ffc890;#f0e4d8;#ffc890', 6)}${at('rotate', '0;360', 8)}</circle><circle r="0.8" fill="${GD}"/></g>`;
        let s = shadow(C, 0, 0, 42, 30, 0.3) + tray + L + base2 + grid + flap + puck;
        C.p(-45, 0, -30); C.p(45, 0, 30); C.p(0, TOPY + 26, 0);
        return { defs: DEF19 + `<defs><linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.25"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#3a3a40" stop-opacity="0.12"/></linearGradient>`
          + `<linearGradient id="${id}t" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffb070" stop-opacity="0"/><stop offset="0.4" stop-color="#ffc890" stop-opacity="0.9"/><stop offset="0.7" stop-color="#e8e4f0" stop-opacity="0.9"/><stop offset="1" stop-color="#e8e4f0" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // ======================= VANITY / DESK (BED-019 tray 52 x 40, BED-039.. desk) =======================
    // BED-019 LAP TRAY ON THE BED (T1): a scuffed white plastic lap tray with fold-out legs and a raised lip, doing duty as a desk: a steaming cup of instant
    // noodles with a fork, a spiral notebook with a pen and doodles, a phone propped on the noodle cup, crumbs and a ring stain. Live: steam curls from the
    // noodles and the phone lights up with a message.
    N.lap30 = S => { const D = { w: 52, d: 40, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('lap30'), id = C.u('t19'), k = C.k, TW = 48, TD = 32, TY = 12;
        const legs = [-1, 1].map(sx => line3(C, [[sx * 18, 0.6, -12], [sx * 18, TY - 0.6, -12]], 0.9, '#cfccc4') + line3(C, [[sx * 18, 0.6, 12], [sx * 18, TY - 0.6, 12]], 0.9, '#cfccc4') + line3(C, [[sx * 18, 0.6, -12], [sx * 18, 0.6, 12]], 0.9, '#d8d4cc')).join('');
        const topD = `<rect width="${TW}" height="${TD}" fill="#f2f0ea"/><rect x="1.4" y="1.4" width="${TW - 2.8}" height="${TD - 2.8}" rx="1" fill="#ece9e2"/>` + rep(10, () => `<path d="M${f1(R() * TW)} ${f1(R() * TD)}l${f1(R() * 4 - 2)} ${f1(R() * 2)}" stroke="#c8c4bc" stroke-width="0.2"/>`).join('')
          + `<circle cx="30" cy="22" r="3.4" fill="none" stroke="#c8a888" stroke-width="0.6" opacity="0.6"/>` + rep(8, () => `<circle cx="${f1(26 + R() * 14)}" cy="${f1(18 + R() * 10)}" r="0.3" fill="#c89a5a"/>`).join('');
        const tray = box3(C, decC(C, { c: [0, TY, 0], w: TW, h: 2, d: TD, col: '#ece9e2', r: 0.8, dec: { t: topD, f: `<rect width="${TW}" height="2" fill="#e2dfd8"/><rect x="${TW / 2 - 6}" y="0.5" width="12" height="1" rx="0.5" fill="#c8c4bc"/>` } }));
        const lip = [[0, -TD / 2], [0, TD / 2]].map(([x, z]) => box3(C, { c: [0, TY + 2, z], w: TW, h: 1.6, d: 1, col: '#f2f0ea', r: 0.4 })).join('') + [-1, 1].map(sx => box3(C, { c: [sx * TW / 2, TY + 2, 0], w: 1, h: 1.6, d: TD, col: '#f2f0ea', r: 0.4 })).join('');
        const T0 = TY + 2;
        const nb = box3(C, decC(C, { c: [-9, T0, 2], w: 20, h: 1.2, d: 22, col: '#f8f6f0', r: 0.2, ax: yawM(0.15), dec: { t: `<rect width="20" height="22" fill="#fbfaf6"/>` + rep(8, i => `<path d="M3 ${3 + i * 2.4}H19" stroke="#9ab8d8" stroke-width="0.2"/>`).join('') + `<path d="M2.4 0V22" stroke="#e88a8a" stroke-width="0.25"/>` + rep(9, i => `<circle cx="0.8" cy="${1.6 + i * 2.4}" r="0.6" fill="none" stroke="#8a8a8a" stroke-width="0.3"/>`).join('') + `<path d="M5 6q2 -2 4 0t4 0M6 11h8M5 16q3 3 6 0" stroke="#3a4a8a" stroke-width="0.3" fill="none"/><path d="M14 15l1.4 -1.4l1 1" stroke="#3a4a8a" stroke-width="0.3" fill="none"/>` } }))
          + line3(C, [[-14, T0 + 1.6, 9], [-2, T0 + 1.6, 4]], 0.5, '#2a4a9a');
        const cup = cyl3(C, [12, T0, -2], [12, T0 + 9, -2], 4, '#f4f0e6', { r2: 4.6, olw: 0.25, capCol: '#d8a860' }) + `<g transform="${FR(C, [12, T0 + 9.05, -2], [1, 0, 0], [0, 0, 1])}"><circle r="4.2" fill="#e8b860"/>${rep(10, i => `<path d="M${f1(-3 + R() * 6)} ${f1(-3 + R() * 6)}q1 -1 2 0t2 0" stroke="#f4d890" stroke-width="0.4" fill="none"/>`).join('')}<circle cx="1.6" cy="-1" r="0.8" fill="#5a8a3a"/><circle cx="-1.4" cy="1.4" r="0.6" fill="#e86a3a"/></g>`
          + line3(C, [[13, T0 + 8.6, -2], [16, T0 + 15, -4]], 0.4, '#b8bcc0') + `<g transform="${FR(C, [8, T0 + 2.6, 2.2], [1, 0, 0], [0, -1, 0])}"><rect width="8" height="4" fill="#d84a3a"/><rect x="1" y="1" width="6" height="0.8" fill="#f2d870"/></g>`;
        const steam = (() => { const p = C.P([12, T0 + 9.4, -2]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})">${rep(3, i => `<path d="M${-2 + i * 2} 0q-1.4 -3 0 -6t0 -6" stroke="#ffffff" stroke-width="0.6" fill="none" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.7;0', 3.6, -i * 1.2)}${at('translate', '0 0;0.6 -4', 3.6, -i * 1.2)}</path>`).join('')}</g>`; })();
        const phone = box3(C, decC(C, { c: [16.4, T0, 5], w: 6.4, h: 11, d: 0.8, col: '#2a2a2e', r: 0.8, ax: tiltX(-0.3), dec: { f: `<rect width="6.4" height="11" rx="0.8" fill="#1a1a1e"/><rect x="0.5" y="0.6" width="5.4" height="9.8" rx="0.5" fill="#e8dcc8" opacity="0">${an('opacity', '0;0;0.95;0.95;0', 8, 0, KT('0;0.6;0.62;0.8;1'))}</rect><rect x="1" y="2" width="4.4" height="1.4" rx="0.5" fill="#ffffff" opacity="0">${an('opacity', '0;0;1;1;0', 8, 0, KT('0;0.6;0.62;0.8;1'))}</rect>` } }));
        const fr = C.v[2] >= 0;
        let s = shadow(C, 0, 0, 26, 18, 0.3) + legs + tray + lip + [{ d: dep30(C, -9, 2), s: nb }, { d: dep30(C, 12, -2), s: cup }, { d: dep30(C, 16.4, 5), s: phone }].sort((a, b) => a.d - b.d).map(o => o.s).join('') + steam;
        C.p(-26, 0, -20); C.p(26, 0, 20); C.p(0, T0 + 18, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };


    // BED-039 COMPACT FOLDING LAPTOP WRITING DESK (T2): a small birch-ply folding desk with a white-painted top edge and two white steel A-frame legs that
    // fold flat, a slim shelf rail under the top. On it: an open laptop, a mug of tea, a pencil cup, a cluster of sticky notes and a little succulent.
    // desk 116 x 58, act 'play', use kept. Live: the laptop cursor blinks as lines of text type out, and the tea steams.
    N.fold39 = S => { const D = { w: 116, d: 58, act: 'play', use: { x: 0, z: 50 }, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('fold39'), id = C.u('k39'), k = C.k, BI = '#e2c89c', W = 84, DD = 44, TY = 46, ST = '#f2f0ea';
        const birch = (w, h) => `<rect width="${w}" height="${h}" fill="${BI}"/>` + grainH(R, w, h, Math.max(3, Math.round(h * 0.6)), '#c8a874', 0.4);
        const ply = (w, h) => `<rect width="${w}" height="${h}" fill="${BI}"/>` + rep(4, i => `<path d="M0 ${f1((i + 0.5) * h / 4)}H${w}" stroke="#b8945a" stroke-width="0.25"/>`).join('');
        const top = box3(C, decC(C, { c: [0, TY, 0], w: W, h: 2.4, d: DD, col: BI, r: 0.4, dec: { t: birch(W, DD), f: ply(W, 2.4), b: ply(W, 2.4), l: ply(DD, 2.4), r: ply(DD, 2.4) } }));
        const frame = [-1, 1].map(sx => { const x = sx * (W / 2 - 5); return line3(C, [[x, 0.6, -DD / 2 + 4], [x, TY - 0.4, -2], [x, 0.6, DD / 2 - 4]], 1.6, ST) + line3(C, [[x, 0.6, -DD / 2 + 2], [x, 0.6, -DD / 2 + 6]], 2, '#c8c4bc') + line3(C, [[x, 0.6, DD / 2 - 6], [x, 0.6, DD / 2 - 2]], 2, '#c8c4bc') + H.sph(C, [x, 22, -9.6], 1.2, '#b8b4ac'); });
        const rail = line3(C, [[-W / 2 + 5, 22, -9.6], [W / 2 - 5, 22, -9.6]], 1.2, ST);
        const T0 = TY + 2.4;
        // laptop: base + tilted screen
        const LX = -6, LZ = 2, base = box3(C, { c: [LX, T0, LZ], w: 30, h: 1.4, d: 20, col: '#c8ccd0', r: 0.6, dec: { t: `<rect width="30" height="20" fill="#c8ccd0"/><rect x="2" y="2" width="26" height="10" rx="0.6" fill="#3a3e44"/>` + rep(5, j => rep(12, i => `<rect x="${2.4 + i * 2.1}" y="${2.4 + j * 1.9}" width="1.7" height="1.5" rx="0.3" fill="#5a5e64"/>`).join('')).join('') + `<rect x="10" y="13.4" width="10" height="5.4" rx="0.6" fill="#b8bcc0"/>` } });
        const sw = 30, sh = 19, scr = (() => { let t = ''; for (let i = 0; i < 6; i++) t += `<rect x="3" y="${3 + i * 2}" width="0" height="0.8" rx="0.4" fill="#5a6a8a">${an('width', `0;0;${12 + (i * 7) % 10};${12 + (i * 7) % 10}`, 12, 0, KT(`0;${f1(i / 6)};${f1((i + 0.9) / 6)};1`))}</rect>`; return `<rect width="${sw}" height="${sh}" rx="1" fill="#2a2e34"/><rect x="1" y="1" width="${sw - 2}" height="${sh - 2.6}" fill="#f4f0e6"/><rect x="1" y="1" width="${sw - 2}" height="1.6" fill="#d8dee8"/>${t}<rect x="3" y="15" width="0.5" height="1" fill="#2a2a3a">${an('opacity', '1;1;0;0', 1, 0, KT('0;0.5;0.5;1'))}</rect>`; })();
        const screen = box3(C, { c: [LX, T0 + 1.2, LZ - 10], w: sw, h: sh, d: 0.8, col: '#b8bcc0', r: 0.6, ax: tiltX(-0.22), dec: { f: scr, b: `<rect width="${sw}" height="${sh}" fill="#c8ccd0"/><circle cx="${sw / 2}" cy="${sh / 2}" r="2" fill="#d8dce0"/>` } });
        const glow = (() => { const p = C.P([LX, T0 + 10, LZ - 6]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(18 * k)}" fill="#fff4dc" opacity="0.18" filter="url(#m12b1)"/>`; })();
        const mug = cyl3(C, [22, T0, -4], [22, T0 + 7, -4], 3.2, '#d87a5a', { olw: 0.25, capCol: '#8a5a30' }) + line3(C, [[25.2, T0 + 5.4, -4], [27, T0 + 4.6, -4], [27, T0 + 2.4, -4], [25.2, T0 + 1.8, -4]], 0.8, '#d87a5a') + line3(C, [[21, T0 + 7, -4], [19.4, T0 + 3, -1.4]], 0.15, '#f2f0ea') + `<g transform="${FR(C, [18.4, T0 + 3.4, -1.2], [1, 0, 0], [0, -1, 0])}"><rect width="2" height="2.4" fill="#f2e8c8"/></g>`;
        const steam = (() => { const p = C.P([22, T0 + 7.4, -4]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})">${rep(2, i => `<path d="M${-1 + i * 2} 0q-1.2 -3 0 -6t0 -6" stroke="#ffffff" stroke-width="0.5" fill="none" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.7;0', 3.6, -i * 1.8)}${at('translate', '0 0;0.6 -3', 3.6, -i * 1.8)}</path>`).join('')}</g>`; })();
        const pc = cyl3(C, [-32, T0, -12], [-32, T0 + 8, -12], 2.8, '#7a9ab8', { olw: 0.25, capCol: '#3a4a5a' }) + [[-33, '#f2c84a'], [-31.4, '#e86a5a'], [-32, '#2a2a2a']].map(([x, c], i) => line3(C, [[x, T0 + 6, -12 + (i - 1) * 0.8], [x + (i - 1) * 1.6, T0 + 14 + i, -12 + (i - 1) * 1.2]], 0.5, c)).join('');
        const notes = `<g transform="${FR(C, [24, T0 + 0.05, 6], [1, 0, 0], [0, 0, 1])}"><rect width="7" height="7" fill="#f6e070" transform="rotate(6)"/><rect x="3" y="3" width="7" height="7" fill="#f8a8b8" transform="rotate(-8 6 6)"/><path d="M4.4 5h4M4.4 7h3" stroke="#6a4a6a" stroke-width="0.3" transform="rotate(-8 6 6)"/></g>`;
        const suc = cyl3(C, [-32, T0, 10], [-32, T0 + 4, 10], 2.6, '#f2eee6', { olw: 0.2, capCol: '#6a5a40' }) + (() => { const p = C.P([-32, T0 + 4, 10]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})">${rep(7, i => { const a = -PI / 2 + (i - 3) * 0.42; return `<ellipse cx="${f1(Math.cos(a) * 1.4)}" cy="${f1(Math.sin(a) * 1.4)}" rx="0.7" ry="1.6" fill="${i % 2 ? '#8ab89a' : '#6ea084'}" transform="rotate(${f1(a * 180 / PI + 90)} ${f1(Math.cos(a) * 1.4)} ${f1(Math.sin(a) * 1.4)})"/>`; }).join('')}</g>`; })();
        const items = [{ d: dep30(C, LX, LZ), s: base + screen + glow }, { d: dep30(C, 22, -4), s: mug + steam }, { d: dep30(C, -32, -12), s: pc }, { d: dep30(C, 24, 6), s: notes }, { d: dep30(C, -32, 10), s: suc }].sort((a, b) => a.d - b.d).map(o => o.s).join('');
        const fr = C.v[2] >= 0;
        let s = shadow(C, 0, 0, 46, 24, 0.3) + (fr ? rail + frame.join('') : frame.join('') + rail) + top + items;
        C.p(-58, 0, -29); C.p(58, 0, 29); C.p(0, T0 + 22, 0);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-059 HOLLYWOOD LIGHTED MAKEUP VANITY TABLE WITH DRAWER (T3): a white lacquer vanity table with a slim centre drawer and gold tapered legs, a big
    // Hollywood mirror in a white frame ringed with round warm globe bulbs standing on the back, an acrylic organiser of lipsticks, a pressed-powder
    // palette, a cup of brushes, a glass perfume bottle and a little blush ring dish. desk 116 x 58, act 'play', use kept.
    // Live: the globe bulbs glow and breathe (one flickers), and a glint slides across the mirror.
    N.holly59 = S => { const D = { w: 116, d: 58, act: 'play', use: { x: 0, z: 50 }, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('holly59'), id = C.u('k59'), k = C.k, WH = '#f6f4ef', GD = '#d6b26a', W = 96, DD = 44, TY = 40;
        const lac = (w, h) => `<rect width="${w}" height="${h}" fill="${WH}"/><rect width="${w}" height="${h}" fill="url(#${id}l)"/>`;
        const apron = box3(C, decC(C, { c: [0, TY - 8, 0], w: W, h: 8, d: DD, col: WH, r: 0.6, dec: { f: lac(W, 8) + `<rect x="${W / 2 - 18}" y="1.2" width="36" height="5.6" fill="none" stroke="#dcd8d0" stroke-width="0.4"/><rect x="${W / 2 - 4}" y="3.4" width="8" height="1.2" rx="0.6" fill="${GD}"/>`, l: lac(DD, 8), r: lac(DD, 8), b: lac(W, 8) } }));
        const top = box3(C, decC(C, { c: [0, TY, 0], w: W + 2, h: 2, d: DD + 2, col: WH, r: 0.6, dec: { t: lac(W + 2, DD + 2), f: lac(W + 2, 2) } }));
        const legs = [[-44, -19], [44, -19], [-44, 19], [44, 19]].map(([x, z]) => ({ d: dep30(C, x, z), s: cyl3(C, [x, 0, z], [x, TY - 8, z], 1, GD, { r2: 1.8, mat: 'metal', olw: 0.2 }) }));
        // Hollywood mirror on the back of the top
        const MW = 64, MH = 50, MZ = -18, mid = C.u('hm');
        const bulbs = []; const ring = (n, f) => { for (let i = 0; i < n; i++) bulbs.push(f(i, n)); };
        ring(7, (i, n) => [4 + i * (MW - 8) / (n - 1), 3]); ring(5, (i, n) => [3, 10 + i * (MH - 16) / (n - 1)]); ring(5, (i, n) => [MW - 3, 10 + i * (MH - 16) / (n - 1)]);
        const face = `<rect width="${MW}" height="${MH}" rx="1.4" fill="${WH}"/><clipPath id="${mid}"><rect x="7" y="7" width="${MW - 14}" height="${MH - 9}"/></clipPath><g clip-path="url(#${mid})"><g transform="translate(7 7)">${refl30(mid, MW - 14, MH - 9, { wx: 0.6, top: '#ece2d4', mid: '#e0d4c2', floor: '#a88a6a' })}<rect width="${MW - 14}" height="${MH - 9}" fill="#ffe8c0" opacity="0.12"/><rect x="0" y="-10" width="${MW - 14}" height="6" fill="url(#${id}g)" transform="skewY(-14)">${an('y', `-10;${MH + 10}`, 9)}</rect></g></g><rect x="7" y="7" width="${MW - 14}" height="${MH - 9}" fill="none" stroke="#e2ddd2" stroke-width="0.6"/>`
          + bulbs.map(([x, y], i) => `<circle cx="${f1(x)}" cy="${f1(y)}" r="4.2" fill="#ffe0a0" opacity="0.35" filter="url(#m12b1)">${an('opacity', '0.25;0.45;0.25', 4, -i * 0.2, SPL(2))}</circle><circle cx="${f1(x)}" cy="${f1(y)}" r="2.2" fill="#fff6e0" stroke="#e8dcc0" stroke-width="0.3">${i === 9 ? an('opacity', '1;1;0.4;1;0.5;1;1', 6, 0, KT('0;0.7;0.72;0.74;0.76;0.78;1')) : ''}</circle><circle cx="${f1(x - 0.6)}" cy="${f1(y - 0.6)}" r="0.7" fill="#ffffff"/>`).join('');
        const mirror = box3(C, { c: [0, TY + 2, MZ], w: MW, h: MH, d: 2.4, col: WH, r: 0.8, ax: tiltX(0.06), dec: { f: face, b: lac(MW, MH) } });
        const T0 = TY + 2;
        const org = box3(C, { c: [-30, T0, -6], w: 14, h: 6, d: 8, col: '#f0f4f6', r: 0.3, dec: { f: `<rect width="14" height="6" fill="#f0f4f6" opacity="0.7"/>` + rep(5, i => `<rect x="${1.4 + i * 2.5}" y="0.6" width="1.6" height="5" rx="0.6" fill="${['#c8344a', '#e87a7a', '#a8344a', '#d8907a', '#8a2a3a'][i]}"/><rect x="${1.4 + i * 2.5}" y="3" width="1.6" height="2.6" fill="${GD}"/>`).join(''), t: `<rect width="14" height="8" fill="#e8eef0"/>` + rep(5, i => `<circle cx="${2.2 + i * 2.5}" cy="4" r="0.9" fill="${['#c8344a', '#e87a7a', '#a8344a', '#d8907a', '#8a2a3a'][i]}"/>`).join('') } });
        const pal = box3(C, { c: [-10, T0, 8], w: 16, h: 1.2, d: 10, col: '#2a2a2c', r: 0.4, dec: { t: `<rect width="16" height="10" rx="0.6" fill="#2a2a2c"/>` + rep(8, i => `<rect x="${1.2 + (i % 4) * 3.6}" y="${1.4 + Math.floor(i / 4) * 4}" width="3" height="3" rx="0.4" fill="${['#e8c0a8', '#d8a080', '#b87a5a', '#8a5a40', '#f0d0c8', '#d8a0a0', '#c8a0b8', '#e8d8b0'][i]}"/>`).join('') } });
        const brushes = cyl3(C, [26, T0, -6], [26, T0 + 7, -6], 2.6, '#f2e4e0', { olw: 0.2, capCol: '#3a2a2a' }) + rep(5, i => { const a = (i - 2) * 0.22; return line3(C, [[26, T0 + 6, -6], [26 + Math.sin(a) * 10, T0 + 6 + Math.cos(a) * 10, -6]], 0.6, '#2a2a2c') + H.sph(C, [26 + Math.sin(a) * 11, T0 + 6 + Math.cos(a) * 11, -6], 1, ['#e8d0c0', '#3a2a2a', '#d8b8a8', '#f2e4d8', '#8a6a5a'][i]); }).join('');
        const perf = cyl3(C, [36, T0, 6], [36, T0 + 6, 6], 2.8, '#f6d8d0', { mat: 'gloss', op: 0.75, olw: 0.25 }) + cyl3(C, [36, T0 + 6, 6], [36, T0 + 7.6, 6], 1.2, GD, { mat: 'metal', olw: 0.2 }) + H.sph(C, [36, T0 + 9.2, 6], 1.8, '#f2e4d8');
        const dish = cyl3(C, [12, T0, 10], [12, T0 + 1, 10], 3.4, '#f2c8c0', { r2: 4, mat: 'gloss', olw: 0.2, capCol: '#f6d8d0' });
        const items = [{ d: dep30(C, -30, -6), s: org }, { d: dep30(C, -10, 8), s: pal }, { d: dep30(C, 26, -6), s: brushes }, { d: dep30(C, 36, 6), s: perf }, { d: dep30(C, 12, 10), s: dish }].sort((a, b) => a.d - b.d).map(o => o.s).join('');
        const fr = C.v[2] >= 0;
        let s = shadow(C, 0, 0, 50, 24, 0.3) + legs.filter(l => l.d < 0).map(l => l.s).join('') + (fr ? apron + top + mirror + items : mirror + apron + top + items) + legs.filter(l => l.d >= 0).map(l => l.s).join('');
        C.p(-58, 0, -29); C.p(58, 0, 29); C.p(0, T0 + MH + 2, MZ);
        return { defs: DEF19 + `<defs><linearGradient id="${id}l" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#c8bca8" stop-opacity="0.2"/></linearGradient>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.4"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BED-079 EXECUTIVE LEATHER-INLAY WALNUT WRITING DESK (T4): a twin-pedestal desk in figured walnut with a forest-green leather writing surface tooled
    // in gold leaf, three drawers each side with brass bail pulls, a centre drawer with a brass keyhole, on moulded plinths. On top: a brass banker's lamp
    // with a green glass shade glowing warm, an open leather journal with a ribbon, a fountain pen on its stand, a cut-crystal inkwell and a small brass
    // globe. desk 116 x 58, act 'play', use kept. Live: the lamp glow breathes, the journal's page lifts and settles, and the globe slowly turns.
    N.exec79 = S => { const D = { w: 116, d: 58, act: 'play', use: { x: 0, z: 50 }, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('exec79'), id = C.u('k79'), k = C.k, WN = '#5a3820', GD = '#d6b06a', W = 108, DD = 52, TY = 46, PW = 30;
        const wal = (w, h) => `<rect width="${w}" height="${h}" fill="${WN}"/>` + grainV(R, w, h, Math.max(3, Math.round(w * 0.5)), '#3a2010', 0.5) + grainV(R, w, h, 2, '#8a5a34', 0.3);
        const drawers = (w, h, n) => wal(w, h) + rep(n, i => { const y = 2 + i * (h - 4) / n, dh = (h - 4) / n - 1.4; return `<rect x="2" y="${f1(y)}" width="${w - 4}" height="${f1(dh)}" fill="${shade(WN, 1.1)}" stroke="#2a1608" stroke-width="0.4"/><path d="M${f1(w / 2 - 4)} ${f1(y + dh / 2 - 1)}q4 3 8 0" stroke="${GD}" stroke-width="0.7" fill="none"/><circle cx="${f1(w / 2 - 4)}" cy="${f1(y + dh / 2 - 1)}" r="0.7" fill="${GD}"/><circle cx="${f1(w / 2 + 4)}" cy="${f1(y + dh / 2 - 1)}" r="0.7" fill="${GD}"/>`; }).join('');
        const ped = sx => box3(C, decC(C, { c: [sx * (W / 2 - PW / 2), 4, 0], w: PW, h: TY - 4, d: DD - 2, col: WN, r: 0.4, dec: { f: drawers(PW, TY - 4, 3), b: wal(PW, TY - 4), l: wal(DD - 2, TY - 4), r: wal(DD - 2, TY - 4) } }));
        const plinth = sx => box3(C, decC(C, { c: [sx * (W / 2 - PW / 2), 0, 0], w: PW + 2, h: 4, d: DD, col: shade(WN, 0.8), r: 0.4, dec: { f: wal(PW + 2, 4) + `<path d="M0 0.8H${PW + 2}" stroke="${GD}" stroke-width="0.3"/>` } }));
        const cw = W - 2 * PW, centre = box3(C, decC(C, { c: [0, TY - 8, 0], w: cw, h: 8, d: DD - 2, col: WN, r: 0.4, dec: { f: wal(cw, 8) + `<rect x="2" y="1.4" width="${cw - 4}" height="5.2" fill="${shade(WN, 1.1)}" stroke="#2a1608" stroke-width="0.4"/><circle cx="${cw / 2}" cy="3.6" r="0.9" fill="${GD}"/><path d="M${cw / 2} 3.8v1.4" stroke="#2a1608" stroke-width="0.4"/>`, b: wal(cw, 8) } }));
        const leather = `<rect width="${W + 2}" height="${DD + 2}" fill="${WN}"/>` + grainH(R, W + 2, DD + 2, 12, '#3a2010', 0.4) + `<rect x="5" y="5" width="${W - 8}" height="${DD - 8}" fill="#2e5a44"/><rect x="5" y="5" width="${W - 8}" height="${DD - 8}" fill="url(#${id}t)"/><rect x="7" y="7" width="${W - 12}" height="${DD - 12}" fill="none" stroke="${GD}" stroke-width="0.6"/><rect x="8.4" y="8.4" width="${W - 14.8}" height="${DD - 14.8}" fill="none" stroke="${GD}" stroke-width="0.25" stroke-dasharray="0.6 0.5"/>`
          + [[8, 8], [W - 6, 8], [8, DD - 6], [W - 6, DD - 6]].map(([x, y]) => `<path d="M${x - 1.6} ${y}h3.2M${x} ${y - 1.6}v3.2" stroke="${GD}" stroke-width="0.4"/>`).join('');
        const top = box3(C, decC(C, { c: [0, TY, 0], w: W + 2, h: 2.4, d: DD + 2, col: WN, r: 0.6, dec: { t: leather, f: wal(W + 2, 2.4) + `<path d="M0 1.2H${W + 2}" stroke="#2a1608" stroke-width="0.3"/>`, l: wal(DD + 2, 2.4), r: wal(DD + 2, 2.4), b: wal(W + 2, 2.4) } }));
        const T0 = TY + 2.4;
        // banker's lamp
        const LX = -36, LZ = -12, lamp = box3(C, { c: [LX, T0, LZ], w: 12, h: 1.6, d: 7, col: GD, r: 0.6 }) + cyl3(C, [LX, T0 + 1.6, LZ], [LX, T0 + 14, LZ], 0.6, GD, { mat: 'metal', olw: 0.2 })
          + cyl3(C, [LX - 8, T0 + 15, LZ + 1], [LX + 8, T0 + 15, LZ + 1], 3.6, '#2e7a50', { mat: 'gloss', olw: 0.3, capCol: '#1e5a3a' })
          + (() => { const p = C.P([LX, T0 + 12, LZ + 3]); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1] + 8 * k)}" rx="${f1(16 * k)}" ry="${f1(7 * k)}" fill="#ffe0a0" opacity="0.35" filter="url(#m12b1)">${an('opacity', '0.25;0.45;0.25', 5, 0, SPL(2))}</ellipse>`; })();
        // open journal + ribbon + lifting page
        const JX = 2, JZ = 6, jt = `<rect width="30" height="20" rx="0.8" fill="#6a3a22"/><rect x="1" y="0.8" width="13.6" height="18.4" fill="#f4ecd8"/><rect x="15.4" y="0.8" width="13.6" height="18.4" fill="#f6efdc"/>` + rep(7, i => `<path d="M3 ${3 + i * 2.2}H13M17 ${3 + i * 2.2}H${i % 3 ? 27 : 23}" stroke="#8a7a68" stroke-width="0.25"/>`).join('') + `<path d="M15 0.8V19.2" stroke="#c8b898" stroke-width="0.6"/><path d="M15 19L14.6 23L15.4 22.4L16 23.4L15.6 19" fill="#a8342a"/>`;
        const jrn = box3(C, { c: [JX, T0, JZ], w: 30, h: 1.4, d: 20, col: '#6a3a22', r: 0.3, ax: yawM(0.1), dec: { t: jt } });
        const AN = [0.02, 0.02, 0.5, 0.02, 0.02], hinge = a => { const c = Math.cos(0.1), s0 = Math.sin(0.1), P = (u, v) => { const x = u * Math.cos(a), y = u * Math.sin(a); return C.P([JX + x * c + 0 - (v) * s0 * 0, T0 + 1.5 + y, JZ - x * s0 + v]); }; return 'M' + P2(P(0, -9)) + 'L' + P2(P(13, -9)) + 'L' + P2(P(13, 9)) + 'L' + P2(P(0, 9)) + 'Z'; };
        const page = `<path d="${hinge(AN[0])}" fill="#fbf6e6" stroke="#d8ccb0" stroke-width="0.2">${an('d', AN.map(hinge).join(';'), 9, 0, KT('0;0.55;0.65;0.8;1'))}</path>`;
        // pen on stand, inkwell, globe
        const pen = box3(C, { c: [30, T0, -14], w: 10, h: 1.6, d: 6, col: '#1a1a1c', r: 0.6 }) + line3(C, [[30, T0 + 1.6, -14], [26, T0 + 10, -16]], 1, '#1a1a1c') + line3(C, [[26, T0 + 10, -16], [25, T0 + 12, -16.6]], 0.6, GD) + line3(C, [[30.2, T0 + 1.6, -14], [27, T0 + 8, -15.4]], 0.3, '#5a5a60', `opacity="0.6"`);
        const ink = cyl3(C, [38, T0, -2], [38, T0 + 4, -2], 3, '#e8eef2', { mat: 'gloss', op: 0.75, olw: 0.25, capCol: '#1a2a4a' }) + H.sph(C, [38, T0 + 5, -2], 1.6, GD);
        const GX = 40, GZ = 12, globe = cyl3(C, [GX, T0, GZ], [GX, T0 + 1.2, GZ], 3, GD, { mat: 'metal', olw: 0.2 }) + cyl3(C, [GX, T0 + 1.2, GZ], [GX, T0 + 4, GZ], 0.5, GD, { mat: 'metal', olw: 0.15 })
          + (() => { const p = C.P([GX, T0 + 9, GZ]), r = 5 * k, cid = C.u('gl'); return `<clipPath id="${cid}"><circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(r)}"/></clipPath><circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(r)}" fill="#e8d8b0"/><g clip-path="url(#${cid})"><g>${at('translate', `0 0;${f1(-4 * r)} 0`, 20)}${rep(4, i => `<path d="M${f1(p[0] - r + i * 2 * r)} ${f1(p[1] - r * 0.4)}q${f1(r * 0.4)} ${f1(-r * 0.4)} ${f1(r * 0.8)} 0t${f1(r * 0.3)} ${f1(r * 0.7)}q${f1(-r * 0.6)} ${f1(r * 0.3)} ${f1(-r * 1.1)} ${f1(-r * 0.3)}Z" fill="#a8885a"/>`).join('')}</g></g><circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(r)}" fill="url(#${id}g)"/><path d="M${f1(p[0] - r * 1.2)} ${f1(p[1] + r * 0.4)}A${f1(r * 1.25)} ${f1(r * 1.25)} 0 0 1 ${f1(p[0] + r * 0.4)} ${f1(p[1] - r * 1.2)}" stroke="${GD}" stroke-width="${f1(0.6 * k)}" fill="none"/>`; })();
        const items = [{ d: dep30(C, LX, LZ), s: lamp }, { d: dep30(C, JX, JZ), s: jrn + page }, { d: dep30(C, 30, -14), s: pen }, { d: dep30(C, 38, -2), s: ink }, { d: dep30(C, GX, GZ), s: globe }].sort((a, b) => a.d - b.d).map(o => o.s).join('');
        const peds = [-1, 1].map(sx => ({ d: dep30(C, sx * 40, 0), s: plinth(sx) + ped(sx) })).sort((a, b) => a.d - b.d).map(o => o.s).join('');
        let s = shadow(C, 0, 0, 58, 28, 0.34) + (C.v[2] >= 0 ? peds + centre : centre + peds) + top + items;
        C.p(-58, 0, -29); C.p(58, 0, 29); C.p(0, T0 + 22, 0);
        return { defs: DEF19 + `<defs><radialGradient id="${id}t" cx="50%" cy="50%" r="70%"><stop offset="0.4" stop-color="#ffffff" stop-opacity="0.06"/><stop offset="1" stop-color="#0a1a10" stop-opacity="0.35"/></radialGradient>`
          + `<radialGradient id="${id}g" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.4"/><stop offset="1" stop-color="#3a2a10" stop-opacity="0.4"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };


    // BED-099 HOLOGRAPHIC DREAM-JOURNALING & SMART BEAUTY STATION (T5): a curved ivory waterfall desk with a champagne-gold edge and a softly lit kick,
    // a round smart mirror on a slim gold stem whose warm scan ring sweeps a face outline beside little skin-reading arcs, and a projector puck casting a
    // warm hologram of a dream journal that writes itself while dream symbols (crescent moon, cloud, stars) drift around it. Rose-quartz roller and three
    // glass serum bottles with gold caps. desk 116 x 58, act 'play', use kept. Live: the journal writes and pages, symbols drift, the scan ring sweeps.
    N.dream99 = S => { const D = { w: 116, d: 58, act: 'play', use: { x: 0, z: 50 }, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('dream99'), id = C.u('k99'), k = C.k, IV = '#f4efe6', GD = '#d6b26a', W = 100, DD = 46, TY = 44;
        const lac = (w, h) => `<rect width="${w}" height="${h}" fill="${IV}"/><rect width="${w}" height="${h}" fill="url(#${id}l)"/>`;
        const sides = [-1, 1].map(sx => ({ d: dep30(C, sx * 48, 0), s: box3(C, decC(C, { c: [sx * (W / 2 - 1.6), 0, 0], w: 3.2, h: TY, d: DD, col: IV, r: 1.4, dec: { l: lac(DD, TY), r: lac(DD, TY), f: lac(3.2, TY) } })) }));
        const top = box3(C, decC(C, { c: [0, TY, 0], w: W, h: 3, d: DD, col: IV, r: 1.4, dec: { t: lac(W, DD) + `<rect x="1" y="1" width="${W - 2}" height="${DD - 2}" rx="2" fill="none" stroke="${GD}" stroke-width="0.4" opacity="0.7"/>`, f: lac(W, 3) + `<rect y="2.2" width="${W}" height="0.8" fill="${GD}"/>`, l: lac(DD, 3), r: lac(DD, 3), b: lac(W, 3) } }));
        const kick = `<g filter="url(#m12b1)"><g transform="${FR(C, [0, 0.1, 0], [1, 0, 0], [0, 0, 1])}"><ellipse rx="44" ry="18" fill="#ffd8a0" opacity="0.35">${an('opacity', '0.25;0.45;0.25', 5, 0, SPL(2))}</ellipse></g></g>`;
        const back = box3(C, { c: [0, 10, -DD / 2 + 4], w: W - 6.4, h: 3, d: 2, col: IV, r: 0.6 });
        const T0 = TY + 3;
        // round smart mirror on a stem (right back)
        const MX = 26, MZ = -14, MR = 15, MY = T0 + 30;
        const face = `<circle cx="${MR}" cy="${MR}" r="${MR}" fill="${GD}"/><circle cx="${MR}" cy="${MR}" r="${MR - 1.4}" fill="#e8dcc8"/><clipPath id="${id}m"><circle cx="${MR}" cy="${MR}" r="${MR - 1.4}"/></clipPath><g clip-path="url(#${id}m)"><g transform="translate(1.4 1.4)">${refl30(id + 'r', 2 * MR - 2.8, 2 * MR - 2.8, { wx: 0.2, top: '#ece2d4', mid: '#e0d4c2', floor: '#a88a6a' })}</g>`
          + `<path d="M${MR} ${MR - 9}C${MR + 7} ${MR - 9} ${MR + 7.4} ${MR + 1} ${MR + 5} ${MR + 6}Q${MR} ${MR + 11} ${MR - 5} ${MR + 6}C${MR - 7.4} ${MR + 1} ${MR - 7} ${MR - 9} ${MR} ${MR - 9}Z" fill="none" stroke="#fff0c8" stroke-width="0.5" opacity="0.8"/><path d="M${MR - 3} ${MR - 1}h1.6M${MR + 1.4} ${MR - 1}h1.6M${MR - 1.6} ${MR + 4.4}q1.6 1 3.2 0" stroke="#fff0c8" stroke-width="0.4" fill="none" opacity="0.8"/>`
          + `<rect x="0" y="0" width="${2 * MR}" height="1.2" fill="#ffe2a8" opacity="0.8">${an('y', `2;${2 * MR - 3};2`, 5, 0, SPL(2))}</rect>`
          + [[MR - 10, MR + 9, '#ffd8a0'], [MR + 10, MR + 9, '#f6c8b8']].map(([x, y, c]) => `<circle cx="${x}" cy="${y}" r="2.4" fill="none" stroke="#ffffff" stroke-width="0.4" opacity="0.5"/><circle cx="${x}" cy="${y}" r="2.4" fill="none" stroke="${c}" stroke-width="0.6" stroke-dasharray="11 4" transform="rotate(-90 ${x} ${y})"/>`).join('') + `</g>`;
        const mirror = cyl3(C, [MX, T0, MZ], [MX, T0 + 1.2, MZ], 4, GD, { mat: 'metal', olw: 0.2 }) + cyl3(C, [MX, T0 + 1.2, MZ], [MX, MY - MR, MZ], 0.6, GD, { mat: 'metal', olw: 0.15 })
          + `<g transform="${FR(C, [MX - MR, MY + MR, MZ], [1, 0, 0], [0, -1, 0])}">${C.v[2] >= 0 ? `<circle cx="${MR}" cy="${MR}" r="${MR + 0.4}" fill="#8a6a30"/>` + face : `<circle cx="${MR}" cy="${MR}" r="${MR}" fill="${GD}"/><circle cx="${MR}" cy="${MR}" r="${MR - 3}" fill="none" stroke="#b8944a" stroke-width="0.6"/>`}</g>`;
        // projector puck + hologram dream journal (billboard over the left of the desk)
        const PX = -22, PZ = 0, puck = cyl3(C, [PX, T0, PZ], [PX, T0 + 2, PZ], 5, '#f2ece2', { mat: 'gloss', olw: 0.2, capCol: '#fbf8f2' }) + `<g transform="${FR(C, [PX, T0 + 2.05, PZ], [1, 0, 0], [0, 0, 1])}"><circle r="2.4" fill="#ffe2a8">${an('opacity', '0.5;1;0.5', 3, 0, SPL(2))}</circle><circle r="3.6" fill="none" stroke="${GD}" stroke-width="0.4"/></g>`;
        const hp = C.P([PX, T0 + 2, PZ]);
        let lines = ''; for (let i = 0; i < 7; i++) { const w = 12 + (i * 5) % 7; lines += `<rect x="-11" y="${-38 + i * 3.4}" width="0" height="0.8" rx="0.4" fill="#e8b860">${an('width', `0;0;${w};${w};0`, 14, -9, KT(`0;${n4(i / 8)};${n4((i + 0.9) / 8)};0.95;1`))}</rect>`; }
        const sym = (x, y, svg, T, ph) => `<g opacity="0.85"><g>${at('translate', `${x} ${y};${x + 3} ${y - 4};${x} ${y}`, T, ph, SPL(2))}${svg}</g></g>`;
        const holo = `<g transform="translate(${P2(hp)}) scale(${n4(k)})"><path d="M-3 0L-15 -46H15L3 0Z" fill="url(#${id}c)"/><g>${at('translate', '0 0;0 -1.4;0 0', 4, 0, SPL(2))}<path d="M-14 -44H14V-12H-14Z" fill="#ffd898" fill-opacity="0.3" stroke="#f6d898" stroke-width="0.6"/><path d="M0 -44V-12" stroke="#fff0d0" stroke-width="0.3" opacity="0.6"/><rect x="-14" y="-44" width="28" height="32" fill="url(#${id}h)"/>${lines}`
          + `<path d="M3 -40q3 2 0 4M5 -34h6M3 -30h8M3 -26h5" stroke="#f6d898" stroke-width="0.6" fill="none"/></g>`
          + sym(-20, -40, '<path d="M0 -3A3 3 0 1 0 2.4 2A2.2 2.2 0 1 1 0 -3Z" fill="#ffe2a8"/>', 7, 0) + sym(16, -48, '<path d="M-4 0q0 -2.4 2.4 -2.2q1 -2 3 -1q2 -0.6 2.6 1.6q2 0.4 1.6 1.6Z" fill="#fff4e0" opacity="0.9"/>', 9, -3)
          + sym(-18, -22, '<path d="M0 -1.6L0.4 -0.4L1.6 0L0.4 0.4L0 1.6L-0.4 0.4L-1.6 0L-0.4 -0.4Z" fill="#fff0c0"/>', 5, -1) + sym(18, -24, '<path d="M0 -1.4L0.35 -0.35L1.4 0L0.35 0.35L0 1.4L-0.35 0.35L-1.4 0L-0.35 -0.35Z" fill="#fff0c0"/>', 6, -2)
          + rep(6, i => `<circle cx="${(i - 2.5) * 3}" cy="0" r="0.35" fill="#fff4d0" opacity="0">${an('cy', '0;-44', 4 + i % 3, -i * 0.7)}${an('opacity', '0;0.9;0', 4 + i % 3, -i * 0.7)}</circle>`).join('') + `</g>`;
        // serums + roller
        const bottles = [[2, -6, '#f2d8c8'], [7, -9, '#efe4d0'], [11, -5, '#f6e2dc']].map(([x, z, c]) => ({ d: dep30(C, x, z), s: cyl3(C, [x, T0, z], [x, T0 + 6, z], 1.8, c, { mat: 'gloss', op: 0.8, olw: 0.2 }) + cyl3(C, [x, T0 + 6, z], [x, T0 + 7.4, z], 1, GD, { mat: 'metal', olw: 0.15 }) + H.sph(C, [x, T0 + 8.4, z], 1, '#f2e4d8') }));
        const roller = line3(C, [[-2, T0 + 0.8, 12], [8, T0 + 0.8, 14]], 0.8, GD) + cyl3(C, [8, T0 + 1.4, 12.6], [8, T0 + 1.4, 15.4], 1.4, '#f2c8cc', { mat: 'gloss', olw: 0.2 }) + cyl3(C, [-3.4, T0 + 0.9, 11.6], [-1, T0 + 0.9, 12.4], 0.9, '#f2c8cc', { mat: 'gloss', olw: 0.15 });
        const items = [{ d: dep30(C, MX, MZ), s: mirror }, { d: dep30(C, PX, PZ), s: puck + holo }, ...bottles, { d: dep30(C, 3, 13), s: roller }].sort((a, b) => a.d - b.d).map(o => o.s).join('');
        const fr = C.v[2] >= 0;
        let s = shadow(C, 0, 0, 52, 24, 0.3) + kick + sides.sort((a, b) => a.d - b.d)[0].s + (fr ? back : '') + sides.sort((a, b) => a.d - b.d)[1].s + top + items;
        C.p(-58, 0, -29); C.p(58, 0, 29); C.p(0, MY + MR + 2, MZ); C.p(PX, T0 + 52, PZ);
        return { defs: DEF19 + `<defs><linearGradient id="${id}l" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#c8b8a0" stop-opacity="0.2"/></linearGradient>`
          + `<linearGradient id="${id}c" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.55"/><stop offset="1" stop-color="#ffe8c0" stop-opacity="0"/></linearGradient>`
          + `<pattern id="${id}h" width="2" height="1" patternUnits="userSpaceOnUse"><rect width="2" height="0.3" fill="#ffffff" opacity="0.18"/></pattern></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // ======================= BEDROOM WINDOWS (front-on art the house shell draws in its window slot; RD.H19.WIN19 keys b*, row r.w19) =======================
    { const WIN = RD.H19.WIN19;
    const WDEF = '<filter id="b1" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="0.6"/></filter><filter id="b2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.6"/></filter>'
      + '<linearGradient id="gref" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.22"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0.02"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
      + '<linearGradient id="tc" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8e4426"/><stop offset="0.35" stop-color="#d4804e"/><stop offset="0.6" stop-color="#c06a3e"/><stop offset="1" stop-color="#7e3a20"/></linearGradient>';
    const bev = (x, y, w, h, c, t) => '<rect x="' + f1(x) + '" y="' + f1(y) + '" width="' + f1(w) + '" height="' + f1(h) + '" fill="' + c + '"/><path d="M' + f1(x) + ' ' + f1(y) + 'h' + f1(w) + 'l' + (-t) + ' ' + t + 'h' + f1(-(w - 2 * t)) + 'v' + f1(h - 2 * t) + 'l' + (-t) + ' ' + t + 'Z" fill="#ffffff" opacity="0.38"/><path d="M' + f1(x + w) + ' ' + f1(y + h) + 'h' + f1(-w) + 'l' + t + ' ' + (-t) + 'h' + f1(w - 2 * t) + 'v' + f1(-(h - 2 * t)) + 'l' + t + ' ' + (-t) + 'Z" fill="#000000" opacity="0.2"/>';
    const ring = (x0, y0, x1, y1, t, c, e) => bev(x0, y0, x1 - x0, t, c, e) + bev(x0, y1 - t, x1 - x0, t, c, e) + bev(x0, y0 + t, t, y1 - y0 - 2 * t, c, e) + bev(x1 - t, y0 + t, t, y1 - y0 - 2 * t, c, e);
    const reveal = (x0, y0, x1, y1, d, c) => '<path d="M' + x0 + ' ' + y0 + 'H' + x1 + 'L' + (x1 - d) + ' ' + (y0 + d) + 'H' + (x0 + d) + 'Z" fill="' + shade(c, 0.62) + '"/><path d="M' + x0 + ' ' + y0 + 'L' + (x0 + d) + ' ' + (y0 + d) + 'V' + (y1 - d) + 'L' + x0 + ' ' + y1 + 'Z" fill="' + shade(c, 0.78) + '"/><path d="M' + x1 + ' ' + y0 + 'V' + y1 + 'L' + (x1 - d) + ' ' + (y1 - d) + 'V' + (y0 + d) + 'Z" fill="' + shade(c, 0.95) + '"/><path d="M' + x0 + ' ' + y1 + 'L' + (x0 + d) + ' ' + (y1 - d) + 'H' + (x1 - d) + 'L' + x1 + ' ' + y1 + 'Z" fill="' + shade(c, 1.06) + '"/>';
    const sill = (x0, x1, y, c, d) => '<rect x="' + x0 + '" y="' + (y + 2.6) + '" width="' + (x1 - x0) + '" height="2" fill="#000000" opacity="0.22" filter="url(#b1)"/><path d="M' + (x0 + d) + ' ' + (y - d) + 'H' + (x1 - d) + 'L' + x1 + ' ' + y + 'H' + x0 + 'Z" fill="' + shade(c, 1.08) + '"/><rect x="' + x0 + '" y="' + y + '" width="' + (x1 - x0) + '" height="3" fill="' + c + '"/><rect x="' + x0 + '" y="' + y + '" width="' + (x1 - x0) + '" height="0.4" fill="#ffffff" opacity="0.5"/><rect x="' + x0 + '" y="' + (y + 2.6) + '" width="' + (x1 - x0) + '" height="0.4" fill="#000000" opacity="0.2"/>';
    const cloud = (x, y, k, c) => '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') scale(' + n4(k) + ')"><ellipse cx="0.6" cy="1.4" rx="7" ry="2.2" fill="' + shade(c, 0.86) + '"/><ellipse rx="7" ry="2.6" fill="' + c + '"/><circle cx="-3" cy="-1.6" r="3" fill="' + c + '"/><circle cx="1.4" cy="-2.8" r="3.8" fill="' + c + '"/><circle cx="4.8" cy="-0.9" r="2.5" fill="' + c + '"/><circle cx="0.4" cy="-3.6" r="1.6" fill="#ffffff" opacity="0.6"/></g>';
    const drift = (q, w, d) => '<g>' + at('translate', '0 0;' + f1(w) + ' 0', d) + q + '<g transform="translate(' + f1(-w) + ' 0)">' + q + '</g></g>';
    const sway = (x, y, k, a, d, ph, inner) => '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') scale(' + n4(k) + ')"><g>' + at('rotate', (-a) + ' 0 0;' + a + ' 0 0;' + (-a) + ' 0 0', d, -ph, SPL(2)) + inner + '</g></g>';
    const tree = (x, y, k, c, ph) => sway(x, y, k, 0, 1, 0, '<path d="M-1 0L-0.7 -10H0.7L1 0Z" fill="#6a4a2e"/>') + sway(x, y - 8 * k, k, 2.5, 5 + ph, ph, '<circle cx="-3.6" cy="-3" r="4.6" fill="' + shade(c, 0.85) + '"/><circle cx="3.4" cy="-3.6" r="4.4" fill="' + shade(c, 0.9) + '"/><circle cy="-7" r="5.4" fill="' + c + '"/><circle cx="-1.6" cy="-8.6" r="2.2" fill="' + shade(c, 1.2) + '"/><circle cx="2.6" cy="-5" r="1.8" fill="' + shade(c, 1.12) + '"/>');
    const glassRef = (x, y, w, h) => '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="url(#gref)"/><path d="M' + f1(x + w * 0.2) + ' ' + y + 'L' + f1(x + w * 0.05) + ' ' + (y + h) + 'H' + f1(x + w * 0.12) + 'L' + f1(x + w * 0.27) + ' ' + y + 'Z" fill="#ffffff" opacity="0.08"/>';
      // BED-012 DRAFTY WINDOW WITH PAPER ACCORDION SHADE (T1): an old single-hung wood window, its white paint flaking to grey wood, the meeting rail
      // and bottom sash gapping so you can see daylight, foam weatherstrip peeling off and hanging, a cracked pane held with yellowed tape and a little
      // fog of condensation in the lower corners. A cheap pleated paper shade is stuck on with its adhesive strip, half down, one pleat torn and the bottom
      // bent, the cord lock clipped crooked. Outside: a grey overcast sky, the neighbour's brick wall, a bare branch. A rolled towel blocks the draught on
      // the sill. Live: the paper pleats flutter in the draught, faint cold wisps slip in under the sash, the bare branch sways and a dry leaf blows past.
      WIN.bwin12 = () => { const FC = '#e4ddcc', R = rng('bwin12');
        let s = '<defs>' + WDEF + '<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a8b0b8"/><stop offset="1" stop-color="#d8dad6"/></linearGradient>'
          + '<pattern id="bk" width="6" height="3" patternUnits="userSpaceOnUse"><rect width="6" height="3" fill="#9a6a58"/><path d="M0 0.1H6M0 1.6H6M1.5 0.1V1.6M4.5 1.6V3" stroke="#c8beb0" stroke-width="0.25"/></pattern>'
          + '<linearGradient id="fog" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0.55"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="pl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fbf8f0"/><stop offset="0.5" stop-color="#ece6d6"/><stop offset="1" stop-color="#cfc6b2"/></linearGradient>'
          + '<clipPath id="gc"><rect x="-30" y="-6" width="60" height="64"/></clipPath></defs>';
        // wall shadow + casing + reveal
        s += '<rect x="-38" y="-13" width="78" height="82" fill="#000000" opacity="0.16" filter="url(#b2)"/>' + ring(-37, -13, 37, 64, 5, FC, 1) + bev(-39, -16, 78, 4, FC, 0.8) + reveal(-32, -8, 32, 64, 1.6, '#cfc8b8');
        // outside
        let sc = '<rect x="-31" y="-7" width="62" height="66" fill="url(#k)"/>' + drift(cloud(-10, 2, 1, '#c8ccd0') + cloud(20, -2, 0.8, '#d4d6d8'), 62, 90);
        sc += '<path d="M-31 47H-26V44H-23V47H-14L-10 43H-2L2 47H8V59H-31Z" fill="#7e848c"/><rect x="-22" y="40" width="2.4" height="5" fill="#8a6a5a"/><path d="M-6 43V36M-9 37.4H-3M-8 39H-4" stroke="#5a5e64" stroke-width="0.3"/>'
          + '<path d="M-31 52H8V59H-31Z" fill="#6a7078"/>' + rep(4, i => '<rect x="' + (-28 + i * 9) + '" y="53.6" width="2" height="2.4" fill="#e8d8a0" opacity="0.5"/>').join('');
        sc += '<rect x="6" y="6" width="26" height="54" fill="url(#bk)"/><rect x="6" y="6" width="26" height="54" fill="#5a4a48" opacity="0.18"/><rect x="5" y="5" width="27" height="1.6" fill="#7a706a"/><rect x="5.6" y="6" width="0.8" height="54" fill="#3a2c28" opacity="0.4"/>'
          + '<path d="M18 6V60" stroke="#6a6a6a" stroke-width="0.8"/><rect x="17" y="22" width="2" height="1" fill="#5a5a5a"/><rect x="17" y="40" width="2" height="1" fill="#5a5a5a"/>';
        // bare branch from the top-left, swaying
        sc += sway(-31, 30, 1, 2.4, 6, 0.4, '<path d="M0 0Q8 3 16 2Q22 1 27 4M10 2.4Q13 -2 18 -4M16 2Q19 6 23 9M22 1.4Q25 -1 29 -1" stroke="#4a3e34" stroke-width="0.9" fill="none" stroke-linecap="round"/><path d="M18 -4l2 -1.6M23 9l1.6 1.4M27 4l2.4 0.6" stroke="#4a3e34" stroke-width="0.4" stroke-linecap="round"/>');
        // dry leaf blowing past
        sc += '<g>' + at('translate', '-44 32;-10 44;8 38;50 52', 11, 0) + '<g>' + at('rotate', '0;200;400', 11) + '<path d="M0 -1.4Q1.4 0 0 1.4Q-1.4 0 0 -1.4Z" fill="#b8763a"/><path d="M0 -1.4V1.4" stroke="#7a4a20" stroke-width="0.15"/></g></g>';
        s += '<g clip-path="url(#gc)">' + sc + '<rect x="-30" y="-6" width="60" height="64" fill="#8a8470" opacity="0.12"/>' + glassRef(-30, -6, 60, 64)
          + '<path d="M-30 58V48Q-26 52 -18 54Q-10 55 -6 58Z" fill="url(#fog)"/><path d="M30 58V50Q26 53 20 55Q14 56 10 58Z" fill="url(#fog)"/>'
          + rep(5, () => { const x = -28 + R() * 56; return '<path d="M' + f1(x) + ' ' + f1(45 + R() * 6) + 'q0.2 3 0 ' + f1(4 + R() * 3) + '" stroke="#ffffff" stroke-width="0.35" opacity="0.4" fill="none"/>'; }).join('')
          // cracked lower-left pane + yellowed tape
          + '<path d="M-22 32L-19 38L-24 44L-20 50M-19 38L-14 40L-11 46M-24 44L-29 46" stroke="#ffffff" stroke-width="0.25" fill="none" opacity="0.85"/><path d="M-22 32L-19 38L-24 44" stroke="#5a5a5a" stroke-width="0.12" fill="none" opacity="0.6" transform="translate(0.25 0.25)"/>'
          + '<g transform="translate(-19.6 39) rotate(-28)"><rect x="-5" y="-1.1" width="10" height="2.2" fill="#e8d498" opacity="0.62"/><path d="M-5 -1.1l-0.3 0.6l0.3 0.5M5 -1.1l0.3 0.6l-0.3 0.5" stroke="#c8b070" stroke-width="0.15" fill="none"/></g></g>';
        // sashes: upper (fixed) + lower, 2-over-2 with muntins, paint flaking to grey wood
        s += ring(-30, -6, 30, 27.4, 2.6, FC, 0.6) + bev(-1, -4, 2, 30, FC, 0.4) + ring(-30, 25.6, 30, 58, 2.6, shade(FC, 0.98), 0.6) + bev(-1, 27, 2, 29, FC, 0.4) + bev(-30.4, 24.8, 60.8, 3.2, shade(FC, 0.96), 0.6);
        // gap at the meeting rail + bottom (daylight + darkness), crooked sash lock
        s += '<rect x="-27" y="24.4" width="54" height="0.5" fill="#2a2620" opacity="0.6"/><path d="M-28 58.2H28" stroke="#f4f2ea" stroke-width="0.35" opacity="0.8"/>'
          + '<g transform="translate(3 26.4) rotate(-8)"><ellipse rx="2.4" ry="0.9" fill="#8a8478"/><path d="M-1.6 -0.3Q0 -1.8 2.2 -0.8" stroke="#a8a294" stroke-width="0.7" fill="none" stroke-linecap="round"/></g>';
        const flk = (x0, y0, w, h, n) => rep(n, () => { const x = x0 + R() * w, y = y0 + R() * h, a = 0.3 + R() * 1, b = 0.25 + R() * 0.6; return '<path d="M' + f1(x) + ' ' + f1(y) + 'l' + f1(a) + ' ' + f1(-b * 0.3) + 'l' + f1(a * 0.3) + ' ' + f1(b) + 'l' + f1(-a * 1.2) + ' ' + f1(b * 0.4) + 'Z" fill="' + (R() < 0.6 ? '#a49a88' : '#b8ae9a') + '" stroke="#fbf8f0" stroke-width="0.12"/>'; }).join('');
        s += flk(-37, -13, 74, 5, 16) + flk(-37, -8, 5, 70, 12) + flk(32, -8, 5, 70, 12) + flk(-30, 55.4, 60, 2.6, 8) + flk(-30, 25, 60, 2.6, 6);
        // peeling foam weatherstrip hanging off the right side, swaying
        s += sway(29.6, 30, 1, 6, 3.2, 0.2, '<path d="M0 0Q1.6 6 0.4 12Q-0.6 15 0.8 18" stroke="#3a3a36" stroke-width="1.2" fill="none" stroke-linecap="round"/><path d="M0 0Q1.6 6 0.4 12" stroke="#6a6a62" stroke-width="0.4" fill="none"/>');
        // pleated paper accordion shade: adhesive headrail at -6, 15 pleats down to ~y 24, fluttering more toward the bottom
        const NP = 15, PH = 2;
        let sh = '<rect x="-30" y="-6.4" width="60" height="1.6" fill="#f4f0e6"/><rect x="-30" y="-6.4" width="60" height="0.5" fill="#d8d0bc"/><path d="M-30 -4.8l1.4 0.8M30 -4.8l-1.6 0.9" stroke="#b8ae98" stroke-width="0.25"/>';
        for (let i = 0; i < NP; i++) { const y = -4.8 + i * PH, am = 0.1 + i * 0.09, dur = 2.2 + (i % 3) * 0.3, tear = i === NP - 1;
          const p = '<path d="M-30 ' + f1(y) + 'H30L30 ' + f1(y + PH * 0.55) + 'H-30Z" fill="url(#pl)"/><path d="M-30 ' + f1(y + PH * 0.55) + 'H30V' + f1(y + PH) + 'H-30Z" fill="#c8bea8"/><path d="M-30 ' + f1(y + PH) + 'H30" stroke="#a89e88" stroke-width="0.15"/>'
            + (i === 6 ? '<path d="M8 ' + f1(y) + 'l3 ' + f1(PH * 0.55) + 'l3 ' + f1(-PH * 0.55) + 'Z" fill="#b8ae98" opacity="0.7"/>' : '')
            + (tear ? '<path d="M18 ' + f1(y + PH) + 'L21 ' + f1(y + PH + 2.6) + 'L24 ' + f1(y + PH + 0.6) + 'L26 ' + f1(y + PH + 3.4) + 'L30 ' + f1(y + PH + 1) + 'V' + f1(y + PH) + 'Z" fill="#ece6d6" stroke="#b8ae98" stroke-width="0.15"/>' : '');
          sh += '<g>' + at('translate', '0 0;' + f1(am * 0.6) + ' ' + f1(am * 0.5) + ';' + f1(-am * 0.3) + ' ' + f1(-am * 0.2) + ';0 0', dur, -i * 0.18, ' calcMode="spline" keyTimes="0;0.35;0.7;1" keySplines="0.4 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1"') + p + '</g>'; }
        const by = -4.8 + NP * PH;
        sh += '<path d="M-18 -4V' + f1(by + 3) + 'M14 -4V' + f1(by + 2) + '" stroke="#f6f2e8" stroke-width="0.25" opacity="0.8"/><path d="M-18 ' + f1(by) + 'V' + f1(by + 9) + '" stroke="#f6f2e8" stroke-width="0.25"/>'
          + '<g transform="translate(-18 ' + f1(by + 9) + ') rotate(12)"><rect x="-1" width="2" height="2.6" rx="0.4" fill="#f2eee4" stroke="#a8a090" stroke-width="0.15"/><circle cy="1.3" r="0.35" fill="#a8a090"/></g>';
        s += '<rect x="-30" y="' + f1(by) + '" width="60" height="2.4" fill="#000000" opacity="0.14" filter="url(#b1)"/>' + sh;
        // cold wisps slipping in under the lower sash
        s += rep(3, i => '<path d="M' + (-16 + i * 14) + ' 58Q' + (-12 + i * 14) + ' 52 ' + (-16 + i * 14) + ' 46T' + (-14 + i * 14) + ' 36" stroke="#dce8f2" stroke-width="1.4" fill="none" stroke-linecap="round" opacity="0" filter="url(#b1)">' + an('opacity', '0;0.5;0', 5, -i * 1.6) + at('translate', '0 2;2 -6', 5, -i * 1.6) + '</path>').join('');
        // sill with chipped paint + rolled striped towel draught-stopper
        s += sill(-40, 40, 64, FC, 1.4) + flk(-38, 64.4, 76, 2.4, 10);
        const tw = '<g transform="translate(0 61.6)"><rect x="-26" y="-2.4" width="52" height="4.8" rx="2.4" fill="#c8b8a0"/>' + rep(8, i => '<rect x="' + (-24 + i * 6.4) + '" y="-2.4" width="2.2" height="4.8" fill="#8a9ab0" opacity="0.6"/>').join('')
          + '<rect x="-26" y="-2.4" width="52" height="1.4" rx="0.7" fill="#ffffff" opacity="0.22"/><rect x="-26" y="0.8" width="52" height="1.6" rx="0.8" fill="#000000" opacity="0.14"/><ellipse cx="26" rx="1.4" ry="2.4" fill="#b8a890"/><path d="M26 -1.6a1 1.6 0 1 0 0.01 0" stroke="#8a7a60" stroke-width="0.25" fill="none"/></g>';
        s += '<rect x="-27" y="62.6" width="56" height="2" fill="#000000" opacity="0.2" filter="url(#b1)"/>' + tw;
        return { vb: [-44, -20, 88, 92], s }; };

      // bilinear quad helpers for perspective panels drawn front-on: q = [TL, TR, BL, BR]
      const BLq = (q, u, v) => [(1 - v) * ((1 - u) * q[0][0] + u * q[1][0]) + v * ((1 - u) * q[2][0] + u * q[3][0]), (1 - v) * ((1 - u) * q[0][1] + u * q[1][1]) + v * ((1 - u) * q[2][1] + u * q[3][1])];
      const qd = (q, u0, v0, u1, v1) => 'M' + pt(BLq(q, u0, v0)) + 'L' + pt(BLq(q, u1, v0)) + 'L' + pt(BLq(q, u1, v1)) + 'L' + pt(BLq(q, u0, v1)) + 'Z';
      const poly = P => 'M' + P.map(pt).join('L') + 'Z';
      const folds = (id, w, a, b) => '<pattern id="' + id + '" width="' + w + '" height="10" patternUnits="userSpaceOnUse"><rect width="' + w + '" height="10" fill="' + a + '"/><rect x="' + f1(w * 0.3) + '" width="' + f1(w * 0.35) + '" height="10" fill="' + b + '"/><rect x="' + f1(w * 0.42) + '" width="' + f1(w * 0.12) + '" height="10" fill="#ffffff" opacity="0.18"/><rect x="' + f1(w * 0.85) + '" width="' + f1(w * 0.15) + '" height="10" fill="#000000" opacity="0.14"/></pattern>';
      // a curtain panel hanging from (x0..x1, y0) to y1, the hem billowing: d animates between still and blown shapes
      const drape = (x0, x1, y0, y1, fill, bl, dur, ph) => { const m = (x0 + x1) / 2, sh = (k) => 'M' + f1(x0) + ' ' + f1(y0) + 'H' + f1(x1) + 'C' + f1(x1 + k * 0.3) + ' ' + f1(y0 + (y1 - y0) * 0.4) + ' ' + f1(x1 + k) + ' ' + f1(y0 + (y1 - y0) * 0.75) + ' ' + f1(x1 + k * 1.1) + ' ' + f1(y1 - Math.abs(k) * 0.2)
          + 'Q' + f1(m + k * 0.9) + ' ' + f1(y1 + 1.2) + ' ' + f1(x0 + k * 0.7) + ' ' + f1(y1) + 'C' + f1(x0 + k * 0.6) + ' ' + f1(y0 + (y1 - y0) * 0.7) + ' ' + f1(x0 + k * 0.1) + ' ' + f1(y0 + (y1 - y0) * 0.3) + ' ' + f1(x0) + ' ' + f1(y0) + 'Z';
        return '<path d="' + sh(0) + '" fill="' + fill + '">' + an('d', sh(0) + ';' + sh(bl) + ';' + sh(bl * 0.4) + ';' + sh(bl * 0.9) + ';' + sh(0), dur, ph, ' calcMode="spline" keyTimes="0;0.3;0.5;0.7;1" keySplines="0.4 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1"') + '</path>'; };

      // BED-032 CASEMENT WINDOW WITH SHEER LACE & BLACKOUT CURTAINS (T2): a white-painted wood casement pair, the left sash shut with a cockspur handle,
      // the right sash pushed open outward on its stay arm. A floral lace sheer hangs inside, the open side billowing into the room; over it a pair of
      // dusty-navy cotton blackout curtains on a wooden pole with ball finials, tied back with fabric tiebacks. A succulent sits on the sill.
      // Outside: a sunny suburban garden with a lilac tree, a hedge and a neighbour's roof. Live: the lace billows on the breeze, a butterfly flits by.
      WIN.bcas32 = () => { const FC = '#f2eee4', R = rng('bcas32');
        let s = '<defs>' + WDEF + '<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#86bfe8"/><stop offset="1" stop-color="#dcf0f8"/></linearGradient>'
          + '<pattern id="lc" width="5" height="5" patternUnits="userSpaceOnUse"><circle cx="2.5" cy="2.5" r="1.3" fill="none" stroke="#ffffff" stroke-width="0.25"/><circle cx="2.5" cy="2.5" r="0.4" fill="#ffffff"/>' + rep(6, i => '<ellipse cx="' + f1(2.5 + Math.cos(i * PI / 3) * 1.9) + '" cy="' + f1(2.5 + Math.sin(i * PI / 3) * 1.9) + '" rx="0.45" ry="0.25" fill="#ffffff" opacity="0.8" transform="rotate(' + (i * 60) + ' ' + f1(2.5 + Math.cos(i * PI / 3) * 1.9) + ' ' + f1(2.5 + Math.sin(i * PI / 3) * 1.9) + ')"/>').join('') + '<circle cx="0" cy="0" r="0.3" fill="#ffffff"/><circle cx="5" cy="5" r="0.3" fill="#ffffff"/></pattern>'
          + folds('fl', 3.4, '#ffffff', '#e8e4dc') + folds('fb', 4.4, '#4e6082', '#3a4a6a')
          + '<clipPath id="gc"><rect x="-28" y="-4" width="56" height="60"/></clipPath></defs>';
        s += '<rect x="-34" y="-10" width="70" height="74" fill="#000000" opacity="0.16" filter="url(#b2)"/>' + ring(-33, -9, 33, 61, 4.2, FC, 1) + reveal(-29, -5, 29, 61, 1.4, '#e2dccc');
        let sc = '<rect x="-29" y="-5" width="58" height="62" fill="url(#k)"/>' + drift(cloud(-12, 6, 0.8, '#ffffff') + cloud(16, 0, 0.6, '#ffffff'), 58, 70);
        sc += '<path d="M-29 30L-20 22L-6 22L2 30Z" fill="#a8604a"/><rect x="-26" y="30" width="26" height="14" fill="#efe6d4"/><rect x="-21" y="33" width="5" height="6" fill="#9ab8d0"/><rect x="-11" y="33" width="5" height="6" fill="#9ab8d0"/><rect x="-16" y="18" width="2.4" height="5" fill="#8a5a48"/>';
        sc += '<path d="M-29 40Q-10 37 6 40T29 39V57H-29Z" fill="#7fb468"/><rect x="-29" y="38" width="58" height="6" rx="3" fill="#4e8a44"/>' + rep(14, i => '<circle cx="' + f1(-28 + i * 4.2) + '" cy="' + f1(38.4 + R()) + '" r="' + f1(2 + R()) + '" fill="' + (i % 2 ? '#5a9a4c' : '#468040') + '"/>').join('');
        sc += tree(17, 41, 1.3, '#b49ad8', 0.3) + '<path d="M-29 50Q0 47 29 50V57H-29Z" fill="#94c47a"/>';
        sc += '<g>' + at('translate', '-34 20;-8 12;6 22;34 8', 12) + '<g transform="scale(0.8)"><path d="M0 0L-1.6 -1.4Q-2.4 0 -1.4 0.8Z" fill="#f2a83a">' + an('d', 'M0 0L-1.6 -1.4Q-2.4 0 -1.4 0.8Z;M0 0L-0.5 -1.6Q-1 0 -0.4 0.8Z;M0 0L-1.6 -1.4Q-2.4 0 -1.4 0.8Z', 0.3) + '</path><path d="M0 0L1.6 -1.4Q2.4 0 1.4 0.8Z" fill="#f2a83a">' + an('d', 'M0 0L1.6 -1.4Q2.4 0 1.4 0.8Z;M0 0L0.5 -1.6Q1 0 0.4 0.8Z;M0 0L1.6 -1.4Q2.4 0 1.4 0.8Z', 0.3) + '</path><path d="M0 -0.8V0.8" stroke="#3a2a1a" stroke-width="0.3"/></g></g>';
        s += '<g clip-path="url(#gc)">' + sc + '</g>';
        // right sash open outward (hinged on the right jamb): a foreshortened panel in the gap, glass catching the sky
        const OQ = [[13, -2], [28, -4], [13, 54], [28, 56]];
        s += '<path d="' + qd(OQ, 0, 0, 1, 1) + '" fill="' + shade(FC, 0.9) + '"/><path d="' + qd(OQ, 0.16, 0.04, 0.86, 0.96) + '" fill="#cfe4f0" opacity="0.55"/><path d="' + qd(OQ, 0.3, 0.04, 0.5, 0.96) + '" fill="#ffffff" opacity="0.25"/><path d="' + qd(OQ, 0.16, 0.48, 0.86, 0.52) + '" fill="' + shade(FC, 0.9) + '"/>'
          + '<path d="M14 50L24 56.6" stroke="#8a8478" stroke-width="0.6"/><circle cx="24" cy="56.6" r="0.5" fill="#6a6458"/>';
        // closed left sash + jamb + mullion, cockspur handle
        s += ring(-28, -4, 0.4, 56, 2.6, FC, 0.6) + bev(-25.4, 24, 25.8, 1.8, FC, 0.4) + glassRef(-25.4, -1.4, 25.8, 54.8) + bev(-0.6, -4, 2.6, 60, FC, 0.5) + ring(-29, -5, 29, 57, 1.4, shade(FC, 0.97), 0.4)
          + '<g transform="translate(-2.4 26)"><rect x="-0.7" y="-1.6" width="1.4" height="3.2" rx="0.5" fill="#d8d2c4"/><path d="M0 0Q-0.6 3 -2.8 4.2" stroke="#e4ded0" stroke-width="0.8" fill="none" stroke-linecap="round"/><path d="M0 0Q-0.6 3 -2.8 4.2" stroke="#9a9486" stroke-width="0.2" fill="none"/></g>';
        // lace sheer on a slim rod: left panel hangs still, right panel billows in through the open sash
        s += '<path d="M-29 -3.6H29" stroke="#e8e4da" stroke-width="0.7"/>';
        const lace = (x0, x1, bl, ph) => '<g opacity="0.62">' + drape(x0, x1, -3.4, 57, 'url(#fl)', bl, 6, ph).replace('fill="url(#fl)"', 'fill="url(#fl)" fill-opacity="0.45"') + drape(x0, x1, -3.4, 57, 'url(#lc)', bl, 6, ph) + '</g>';
        s += lace(-28, -6, 1.2, 0) + lace(4, 27, -9, -0.4);
        // sill + succulent
        s += sill(-37, 37, 61, FC, 1.2) + '<ellipse cx="-22" cy="61" rx="3.4" ry="0.7" fill="#000000" opacity="0.25" filter="url(#b1)"/><path d="M-24.8 55.4L-24 61H-20L-19.2 55.4Z" fill="#f2eee6"/><path d="M-24 55.4L-23.6 61H-22.6L-23 55.4Z" fill="#ffffff" opacity="0.6"/><rect x="-25.2" y="54.6" width="6.4" height="1.4" rx="0.3" fill="#e2dcd0"/><path d="M-21 56L-20.6 61H-20L-20.2 56Z" fill="#c8c0b0" opacity="0.6"/>';
        s += '<g transform="translate(-22 55)">' + rep(9, i => { const a = -PI / 2 + (i - 4) * 0.36; return '<ellipse cx="' + f1(Math.cos(a) * 1.6) + '" cy="' + f1(Math.sin(a) * 1.6 + 0.4) + '" rx="0.8" ry="1.8" fill="' + (i % 2 ? '#8ab89a' : '#6ea084') + '" transform="rotate(' + f1(a * 180 / PI + 90) + ' ' + f1(Math.cos(a) * 1.6) + ' ' + f1(Math.sin(a) * 1.6 + 0.4) + ')"/>'; }).join('') + '<circle r="0.9" cy="0.2" fill="#a8d0b0"/></g>';
        // blackout curtains: wooden pole + ball finials + rings, panels tied back
        const bk = (side) => { const sx = side, o = x => f1(sx * x); return '<path d="M' + o(30) + ' -13.4H' + o(50) + 'C' + o(50) + ' 6 ' + o(49) + ' 22 ' + o(46) + ' 32C' + o(48) + ' 46 ' + o(51) + ' 60 ' + o(52) + ' 72H' + o(36) + 'C' + o(38) + ' 58 ' + o(41) + ' 44 ' + o(43) + ' 32C' + o(37) + ' 22 ' + o(32) + ' 6 ' + o(30) + ' -13.4Z" fill="url(#fb)"/>'
          + '<path d="M' + o(30) + ' -13.4C' + o(32) + ' 6 ' + o(37) + ' 22 ' + o(43) + ' 32" stroke="#2a3650" stroke-width="0.5" fill="none" opacity="0.6"/><path d="M' + o(36) + ' 72H' + o(52) + '" stroke="#34405c" stroke-width="1"/>'
          + '<path d="M' + o(41.6) + ' 30.4Q' + o(46) + ' 33.6 ' + o(51) + ' 30.4L' + o(51) + ' 32.8Q' + o(46) + ' 36 ' + o(41.6) + ' 32.8Z" fill="#6a7c9c"/><circle cx="' + o(51.4) + '" cy="31.6" r="0.7" fill="#c8b48a"/>'; };
        s += '<rect x="-52" y="-12" width="104" height="4" fill="#000000" opacity="0.14" filter="url(#b1)"/>' + bk(-1) + bk(1);
        s += '<rect x="-50" y="-16" width="100" height="2.2" rx="1.1" fill="#9a6a3e"/><rect x="-50" y="-16" width="100" height="0.7" rx="0.35" fill="#c89a68"/>' + [-53, 53].map(x => '<circle cx="' + x + '" cy="-14.9" r="2.4" fill="#9a6a3e"/><circle cx="' + (x - 0.7) + '" cy="-15.6" r="0.8" fill="#d8aa78"/>').join('')
          + rep(12, i => { const x = (i < 6 ? -49.6 + i * 3.4 : 32 + (i - 6) * 3.4); return '<ellipse cx="' + f1(x) + '" cy="-14.9" rx="0.7" ry="1.6" fill="none" stroke="#7a522e" stroke-width="0.4"/>'; }).join('')
          + [-46, 46].map(x => '<rect x="' + (x - 1.2) + '" y="-14" width="2.4" height="2.6" fill="#7a522e"/>').join('');
        return { vb: [-56, -20, 112, 96], s }; };

      // BED-052 COZY CUSHIONED WINDOW SEAT ALCOVE WITH SHUTTERS (T3): a deep sage-painted alcove with a built-in window seat: a multi-pane window at the
      // back with louvred plantation shutters folded open against the side walls, a thick striped linen cushion with piping, scatter pillows in rust
      // velvet, cream knit and mustard check, a chunky knit throw hanging over the edge, a book and a mug of cocoa, two drawers with brass cup pulls
      // below. Outside: a rainy green garden. A warm lamp glow fills the nook. Live: rain trickles down the panes, the trees sway and steam curls from the mug.
      WIN.bseat52 = () => { const SG = '#9fb294', CR = '#f2ede2', R = rng('bseat52');
        let s = '<defs>' + WDEF + '<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#94a2aa"/><stop offset="1" stop-color="#c8d2cc"/></linearGradient>'
          + '<radialGradient id="lw" cx="20%" cy="35%" r="70%"><stop offset="0" stop-color="#ffd890" stop-opacity="0.32"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient>'
          + '<pattern id="tk" width="4" height="4" patternUnits="userSpaceOnUse"><rect width="4" height="4" fill="#ece4d2"/><rect x="0.6" width="0.5" height="4" fill="#6a84a4" opacity="0.7"/><rect x="2.2" width="0.25" height="4" fill="#6a84a4" opacity="0.5"/></pattern>'
          + '<pattern id="kn" width="1.6" height="1.4" patternUnits="userSpaceOnUse"><rect width="1.6" height="1.4" fill="#e8dcc4"/><path d="M0 0L0.8 1.2L1.6 0" stroke="#c8b898" stroke-width="0.3" fill="none"/></pattern>'
          + '<pattern id="ck" width="3" height="3" patternUnits="userSpaceOnUse"><rect width="3" height="3" fill="#d8a83a"/><rect width="1.5" height="3" fill="#b8862a" opacity="0.6"/><rect width="3" height="1.5" fill="#b8862a" opacity="0.6"/></pattern>'
          + '<clipPath id="gc"><rect x="-26" y="-20" width="52" height="64"/></clipPath></defs>';
        // alcove: ceiling, sides, back
        s += '<rect x="-56" y="-44" width="112" height="132" fill="#000000" opacity="0.14" filter="url(#b2)"/>';
        s += '<path d="' + poly([[-50, -38], [50, -38], [38, -30], [-38, -30]]) + '" fill="' + shade(SG, 0.82) + '"/><path d="' + poly([[-50, -38], [-38, -30], [-38, 54], [-50, 62]]) + '" fill="' + shade(SG, 0.88) + '"/><path d="' + poly([[50, -38], [38, -30], [38, 54], [50, 62]]) + '" fill="' + shade(SG, 0.78) + '"/>';
        s += '<rect x="-38" y="-30" width="76" height="84" fill="' + SG + '"/>' + '<rect x="-38" y="-30" width="76" height="84" fill="url(#lw)"/>';
        // window: casing, scene, rain, muntins
        s += '<rect x="-31" y="-24" width="62" height="72" fill="#000000" opacity="0.16" filter="url(#b1)"/>' + ring(-30, -24, 30, 48, 3.4, CR, 0.8) + reveal(-26.6, -20.6, 26.6, 44.6, 1, '#d8d2c2');
        let sc = '<rect x="-27" y="-21" width="54" height="66" fill="url(#k)"/>' + drift(cloud(-10, -12, 0.9, '#b8c0c4') + cloud(14, -16, 0.7, '#c4cacc'), 54, 120);
        sc += '<path d="M-27 18Q-12 10 2 15T27 12V45H-27Z" fill="#8a9e86"/><path d="M-27 28Q-6 22 12 27T27 25V45H-27Z" fill="#6e8a68"/>' + tree(-16, 24, 1.8, '#4e7a4a', 0.2) + tree(18, 22, 1.4, '#5a8654', 1.1) + '<path d="M-27 36Q0 33 27 36V45H-27Z" fill="#5e7a56"/>';
        sc += '<g opacity="0.35">' + at('translate', '0 -12;-3 6', 0.6) + rep(26, () => { const x = -30 + R() * 64, y = -24 + R() * 74; return '<path d="M' + f1(x) + ' ' + f1(y) + 'l-0.6 3" stroke="#e8eef0" stroke-width="0.2"/>'; }).join('') + '</g>';
        // drops on the glass: beads + a few trickling down
        sc += rep(30, () => '<circle cx="' + f1(-26 + R() * 52) + '" cy="' + f1(-20 + R() * 64) + '" r="' + f1(0.25 + R() * 0.35) + '" fill="#ffffff" opacity="0.45"/>').join('');
        sc += rep(6, i => { const x = -24 + i * 9 + R() * 3, d = 5 + R() * 4; return '<g>' + at('translate', '0 -24;' + f1(R() - 0.5) + ' 70', d, -i * 1.3) + '<path d="M' + f1(x) + ' 0q0.3 -3 0 -6" stroke="#ffffff" stroke-width="0.3" opacity="0.5" fill="none"/><ellipse cx="' + f1(x) + '" cy="0.4" rx="0.5" ry="0.65" fill="#ffffff" opacity="0.6"/></g>'; }).join('');
        s += '<g clip-path="url(#gc)">' + sc + glassRef(-26, -20, 52, 64) + '</g>';
        s += [-8.7, 8.7].map(x => bev(x - 0.7, -20, 1.4, 64, CR, 0.3)).join('') + [1, 22].map(y => bev(-26, y - 0.7, 52, 1.4, CR, 0.3)).join('') + bev(-26.6, -20.6, 53.2, 1.6, CR, 0.4);
        s += sill(-31, 31, 46.4, CR, 0.8);
        // shutters folded against the side walls (louvred, 2 tiers each)
        [-1, 1].forEach(sx => { const Q = [[sx * 38, -30], [sx * 50, -38], [sx * 38, 54], [sx * 50, 62]], c = sx < 0 ? '#f0ebe0' : '#e2dccf';
          [[0.1, 0.06, 0.46, 0.48], [0.5, 0.06, 0.88, 0.48], [0.1, 0.5, 0.46, 0.86], [0.5, 0.5, 0.88, 0.86]].forEach(([u0, v0, u1, v1]) => {
            s += '<path d="' + qd(Q, u0, v0, u1, v1) + '" fill="' + c + '" stroke="' + shade(c, 0.8) + '" stroke-width="0.25"/>';
            for (let v = v0 + 0.03; v < v1 - 0.02; v += 0.024) s += '<path d="M' + pt(BLq(Q, u0 + 0.06, v)) + 'L' + pt(BLq(Q, u1 - 0.06, v)) + '" stroke="' + shade(c, 0.78) + '" stroke-width="0.3"/>';
            s += '<path d="M' + pt(BLq(Q, (u0 + u1) / 2, v0 + 0.03)) + 'L' + pt(BLq(Q, (u0 + u1) / 2, v1 - 0.03)) + '" stroke="' + shade(c, 0.9) + '" stroke-width="0.4"/>'; });
          s += '<circle cx="' + pt(BLq(Q, 0.08, 0.3)).split(' ')[0] + '" cy="' + pt(BLq(Q, 0.08, 0.3)).split(' ')[1] + '" r="0.4" fill="#b89a5a"/>'; });
        // warm sconce glow top-left corner + soft light on the seat
        s += '<g transform="translate(-44 6)"><path d="M0 0h2v3h-2Z" fill="#b8924a"/><path d="M-2 -5H4L3 0H-1Z" fill="#f6e6c4"/><ellipse cx="1" cy="-2" rx="9" ry="9" fill="#ffd890" opacity="0.25" filter="url(#b2)">' + an('opacity', '0.2;0.3;0.2', 5, 0, SPL(2)) + '</ellipse></g>';
        // seat: wooden top + cushion (top + front) + piping
        s += '<path d="' + poly([[-38, 54], [38, 54], [50, 62], [-50, 62]]) + '" fill="#c49a68"/>';
        s += '<path d="' + poly([[-37, 47.6], [37, 47.6], [48.6, 55.6], [-48.6, 55.6]]) + '" fill="url(#tk)"/><path d="' + poly([[-37, 47.6], [37, 47.6], [48.6, 55.6], [-48.6, 55.6]]) + '" fill="#000000" opacity="0.06"/>'
          + '<path d="M-48.6 55.6H48.6Q49.4 58.6 48.6 61.4H-48.6Q-49.4 58.6 -48.6 55.6Z" fill="url(#tk)"/><path d="M-48.6 58.4H48.6V61.4H-48.6Z" fill="#000000" opacity="0.12"/><path d="M-48.6 55.6H48.6" stroke="#f8f2e4" stroke-width="0.6"/><path d="M-37 47.6H37" stroke="#d8ccb4" stroke-width="0.5"/>';
        // pillows leaning on the back wall
        const pil = (x, w, h, a, fill, extra) => '<g transform="translate(' + x + ' 51) rotate(' + a + ')"><path d="M' + f1(-w / 2) + ' 0Q' + f1(-w / 2 - 1) + ' ' + f1(-h / 2) + ' ' + f1(-w / 2 + 0.6) + ' ' + f1(-h) + 'Q0 ' + f1(-h + 1.6) + ' ' + f1(w / 2 - 0.6) + ' ' + f1(-h) + 'Q' + f1(w / 2 + 1) + ' ' + f1(-h / 2) + ' ' + f1(w / 2) + ' 0Q0 1.4 ' + f1(-w / 2) + ' 0Z" fill="' + fill + '"/>' + (extra || '')
          + '<path d="M' + f1(-w / 2 + 1) + ' ' + f1(-h + 1) + 'Q0 ' + f1(-h / 2) + ' ' + f1(w / 2 - 1) + ' ' + f1(-h + 1) + '" stroke="#ffffff" stroke-width="0.4" opacity="0.25" fill="none"/><path d="M' + f1(-w / 2) + ' 0Q0 1.4 ' + f1(w / 2) + ' 0" stroke="#000000" stroke-width="0.8" opacity="0.15" fill="none"/></g>';
        s += pil(-26, 15, 14, -8, '#a8502e', '<ellipse cx="-2" cy="-9" rx="4" ry="2" fill="#ffffff" opacity="0.12"/>') + pil(-12, 13, 12, 5, 'url(#kn)') + pil(26, 14, 13, 9, 'url(#ck)');
        // book + mug with steam
        s += '<g transform="translate(4 52.4)"><path d="M-5 0L0 -1.4L5 0L5 0.8L0 -0.6L-5 0.8Z" fill="#3a5a6e"/><path d="M-4.8 0.1L0 -1.1L4.8 0.1" stroke="#f4ecd8" stroke-width="0.4" fill="none"/></g>';
        s += '<g transform="translate(13 51.4)"><rect x="-1.8" y="-3.4" width="3.6" height="3.8" rx="0.6" fill="#e8dccb"/><rect x="-1.8" y="-3.4" width="3.6" height="0.7" fill="#5a3a24"/><path d="M1.8 -2.6q1.4 0.2 1.2 1.2t-1.2 0.9" stroke="#e8dccb" stroke-width="0.5" fill="none"/>'
          + rep(2, i => '<path d="M' + (-0.6 + i * 1.2) + ' -4q-0.8 -1.6 0 -3t0 -3" stroke="#ffffff" stroke-width="0.4" fill="none" opacity="0">' + an('opacity', '0;0.6;0', 3.6, -i * 1.8) + at('translate', '0 0.6;0.4 -2', 3.6, -i * 1.8) + '</path>').join('') + '</g>';
        // knit throw over the right front edge
        s += '<path d="M30 49L44 52.4L46 64Q45.6 72 41 74L33 71Q35 62 31 56Z" fill="url(#kn)"/><path d="M30 49L44 52.4L46 64Q45.6 72 41 74L33 71Q35 62 31 56Z" fill="none" stroke="#b8a888" stroke-width="0.3"/><path d="M33 71L41 74" stroke="#d0c0a0" stroke-width="1.2" stroke-dasharray="0.4 0.5"/>';
        // bench front: 2 drawers, brass cup pulls, plinth
        s += '<rect x="-50" y="62" width="100" height="22" fill="' + shade(SG, 0.96) + '"/>' + [-25, 25].map(x => ring(x - 22, 64.6, x + 22, 81, 1.6, shade(SG, 0.96), 0.5) + '<path d="M' + (x - 3) + ' 70.6h6q0 2.4 -3 2.4t-3 -2.4Z" fill="#c8a058"/><path d="M' + (x - 3) + ' 70.6h6" stroke="#f0d890" stroke-width="0.4"/>').join('')
          + '<rect x="-50" y="84" width="100" height="3" fill="' + shade(SG, 0.8) + '"/><rect x="-50" y="62" width="100" height="0.8" fill="#000000" opacity="0.2"/>';
        // alcove casing (top + sides)
        s += bev(-54, -42, 108, 4.4, CR, 1) + bev(-54, -38, 4.2, 125, CR, 1) + bev(49.8, -38, 4.2, 125, CR, 1);
        return { vb: [-58, -46, 116, 136], s }; };

      // BED-072 FRENCH DOORS OPENING TO PRIVATE JULIET BALCONY (T4): tall cream-painted French doors with slim divided lites and polished brass
      // espagnolette bolts, both swung wide into the room under a fixed transom, onto a wrought-iron Juliet railing with scrolls and gilded tips, window
      // boxes of red geraniums and trailing ivy. Ivory silk sheers hang either side and billow in. Outside: a golden-hour view over terracotta and zinc
      // rooftops with chimney pots and a distant dome. Live: the sheers billow, swallows wheel across the sky, the geraniums nod and the sun glows.
      WIN.bfr72 = () => { const FC = '#f4eedf', R = rng('bfr72');
        let s = '<defs>' + WDEF + '<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c8a4c0"/><stop offset="0.45" stop-color="#f4c49a"/><stop offset="0.8" stop-color="#fbe0b0"/></linearGradient>'
          + '<radialGradient id="sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff6d8"/><stop offset="0.3" stop-color="#ffe0a0" stop-opacity="0.8"/><stop offset="1" stop-color="#ffd090" stop-opacity="0"/></radialGradient>'
          + '<linearGradient id="br" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8a6420"/><stop offset="0.5" stop-color="#f6d888"/><stop offset="1" stop-color="#b88a34"/></linearGradient>'
          + folds('fs', 3.8, '#fbf6ea', '#ece2cc') + '<clipPath id="gc"><rect x="-30" y="-42" width="60" height="138"/></clipPath></defs>';
        s += '<rect x="-38" y="-50" width="76" height="150" fill="#000000" opacity="0.16" filter="url(#b2)"/>' + reveal(-31, -43, 31, 98, 1.6, '#e2dac8');
        let sc = '<rect x="-31" y="-43" width="62" height="141" fill="url(#k)"/><circle cx="12" cy="44" r="18" fill="url(#sun)">' + an('r', '17;19;17', 6, 0, SPL(2)) + '</circle><circle cx="12" cy="44" r="4.4" fill="#fff4d0"/>'
          + drift(cloud(-14, -26, 0.9, '#f8dcd0') + cloud(18, -34, 0.7, '#f6d4cc') + cloud(4, 6, 0.6, '#fbe4c8'), 62, 140);
        // distant dome + rooftops (3 layers)
        sc += '<path d="M-20 56V48Q-20 40 -14 38Q-8 40 -8 48V56Z" fill="#b8a0a8"/><path d="M-14 38V34" stroke="#b8a0a8" stroke-width="0.6"/><circle cx="-14" cy="33.6" r="0.6" fill="#b8a0a8"/>';
        sc += '<path d="M-31 58L-24 52H-12L-8 56L0 50H10L16 55H24L31 50V98H-31Z" fill="#a88a8e"/>';
        sc += '<path d="M-31 66L-26 60H-14L-10 64H-4L2 58H14L20 63H31V98H-31Z" fill="#b8764e"/><path d="M-31 66L-26 60H-14L-10 64H-4L2 58H14L20 63H31" stroke="#8a5434" stroke-width="0.4" fill="none"/>' + rep(6, i => '<rect x="' + (-27 + i * 10) + '" y="' + (54 + (i % 2) * 3) + '" width="2" height="5" fill="#9a5a3a"/><rect x="' + (-27.4 + i * 10) + '" y="' + (53.4 + (i % 2) * 3) + '" width="2.8" height="0.8" fill="#7a4a30"/>').join('');
        sc += '<path d="M-31 74H31V98H-31Z" fill="#7e8890"/>' + rep(10, i => '<path d="M' + (-31 + i * 6.4) + ' 74V98" stroke="#6a747c" stroke-width="0.3"/>').join('') + rep(5, i => '<rect x="' + (-27 + i * 12) + '" y="78" width="3" height="4" rx="1.5" fill="#f4d890" opacity="0.7"/>').join('');
        // swallows wheel across
        sc += rep(3, i => '<g>' + at('translate', '-40 ' + (-10 + i * 6) + ';0 ' + (-24 + i * 4) + ';44 ' + (-6 + i * 5), 9, -i * 0.5) + '<path d="M-1.6 -0.6Q-0.8 0 0 0.4Q0.8 0 1.6 -0.6" stroke="#3a3040" stroke-width="0.4" fill="none">' + an('d', 'M-1.6 -0.6Q-0.8 0 0 0.4Q0.8 0 1.6 -0.6;M-1.6 0.6Q-0.8 0 0 0.4Q0.8 0 1.6 0.6;M-1.6 -0.6Q-0.8 0 0 0.4Q0.8 0 1.6 -0.6', 0.4) + '</path></g>').join('');
        // stone threshold outside + Juliet railing + window boxes
        sc += '<rect x="-31" y="90" width="62" height="8" fill="#d8ccb8"/><rect x="-31" y="90" width="62" height="1" fill="#f0e6d4"/>';
        let rail = '<rect x="-30" y="58" width="60" height="1.6" rx="0.8" fill="#2a2624"/><rect x="-30" y="58" width="60" height="0.5" fill="url(#br)"/><rect x="-30" y="86" width="60" height="1.4" fill="#2a2624"/>';
        for (let i = 0; i <= 12; i++) { const x = -30 + i * 5; rail += '<path d="M' + x + ' 59V86" stroke="#2a2624" stroke-width="0.6"/><path d="M' + x + ' 59l-0.5 -1.6h1Z" fill="#d8b058"/>';
          if (i < 12) rail += '<path d="M' + (x + 2.5) + ' 66C' + (x + 0.6) + ' 66 ' + (x + 0.6) + ' 70 ' + (x + 2.5) + ' 70C' + (x + 4.4) + ' 70 ' + (x + 4.4) + ' 74 ' + (x + 2.5) + ' 74M' + (x + 2.5) + ' 78C' + (x + 1) + ' 78 ' + (x + 1) + ' 81 ' + (x + 2.5) + ' 81C' + (x + 4) + ' 81 ' + (x + 4) + ' 78 ' + (x + 2.5) + ' 78" stroke="#2a2624" stroke-width="0.45" fill="none"/>'; }
        sc += rail;
        const box = (x0) => { let o = '<rect x="' + x0 + '" y="60" width="20" height="5" fill="#a8603a"/><rect x="' + x0 + '" y="60" width="20" height="1" fill="#c8805a"/>';
          for (let i = 0; i < 5; i++) { const x = x0 + 2 + i * 4; o += sway(x, 60, 1, 4, 3 + i * 0.4, i * 0.6, '<path d="M0 0Q0.4 -3 0 -6" stroke="#4e7a38" stroke-width="0.35" fill="none"/>' + rep(3, j => '<circle cx="' + f1(Math.cos(j * 2.1) * 1.2) + '" cy="' + f1(-6.4 + Math.sin(j * 2.1) * 1.2) + '" r="1.3" fill="#d8342a"/>').join('') + '<circle cy="-6.6" r="0.9" fill="#f04a3a"/><ellipse cx="-1.6" cy="-2.6" rx="1.8" ry="1.2" fill="#5a8a3e"/><ellipse cx="1.6" cy="-3.4" rx="1.6" ry="1.1" fill="#4e7e36"/>'); }
          o += rep(4, i => '<path d="M' + (x0 + 2 + i * 5) + ' 64Q' + (x0 + 3 + i * 5) + ' 70 ' + (x0 + 1 + i * 5) + ' ' + (74 + (i % 2) * 4) + '" stroke="#3e6a30" stroke-width="0.35" fill="none"/>' + rep(4, j => '<ellipse cx="' + f1(x0 + 2 + i * 5 + (j % 2 ? 0.8 : -0.6)) + '" cy="' + f1(66 + j * 2.6) + '" rx="0.9" ry="0.6" fill="#4a7e3a"/>').join('')).join('');
          return o; };
        sc += box(-27) + box(7);
        s += '<g clip-path="url(#gc)">' + sc + '</g>';
        // transom (fixed, 4 lites) + frame
        s += ring(-30, -42, 30, -22, 2.4, FC, 0.5) + [-15, 0, 15].map(x => bev(x - 0.6, -40, 1.2, 16, FC, 0.3)).join('') + glassRef(-27.6, -39.6, 55.2, 15.2) + bev(-31, -23, 62, 2.4, FC, 0.5);
        // doors swung into the room: hinge on the jamb, free edge foreshortened outward over the wall
        [-1, 1].forEach(sx => { const Q = sx < 0 ? [[-48, -26], [-30, -21], [-48, 100], [-30, 96]] : [[30, -21], [48, -26], [30, 96], [48, 100]];
          s += '<path d="' + qd(Q, -0.02, -0.01, 1.04, 1.01) + '" fill="#000000" opacity="0.18" filter="url(#b1)"/><path d="' + qd(Q, 0, 0, 1, 1) + '" fill="' + FC + '"/>';
          for (let r = 0; r < 5; r++) for (let c = 0; c < 2; c++) { const u0 = 0.12 + c * 0.39, v0 = 0.04 + r * 0.142, a = qd(Q, u0, v0, u0 + 0.36, v0 + 0.128);
            s += '<path d="' + a + '" fill="#e8c8a0" opacity="0.75"/><path d="' + qd(Q, u0, v0, u0 + 0.12, v0 + 0.128) + '" fill="#ffffff" opacity="0.2"/><path d="' + a + '" fill="none" stroke="' + shade(FC, 0.82) + '" stroke-width="0.25"/>'; }
          s += '<path d="' + qd(Q, 0.1, 0.75, 0.9, 0.98) + '" fill="' + shade(FC, 0.96) + '" stroke="' + shade(FC, 0.82) + '" stroke-width="0.3"/>';
          const fu = sx < 0 ? 0.05 : 0.95, ra = BLq(Q, fu, 0.02), rb = BLq(Q, fu, 0.98), hp = BLq(Q, fu, 0.52);
          s += '<path d="M' + pt(ra) + 'L' + pt(rb) + '" stroke="url(#br)" stroke-width="0.9"/><g transform="translate(' + pt(hp) + ')"><ellipse rx="0.9" ry="1.6" fill="#c8a050"/><path d="M0 0h' + (-sx * 3.4) + '" stroke="#e8c870" stroke-width="0.8" stroke-linecap="round"/></g>'; });
        // jambs + head casing + interior marble threshold
        s += bev(-35, -48, 70, 5, FC, 1) + bev(-35, -43, 5, 141, FC, 1) + bev(30, -43, 5, 141, FC, 1) + '<rect x="-34" y="96" width="68" height="4" fill="#ece6dc"/><path d="M-30 97.6q10 -0.6 18 0.4t24 -0.2" stroke="#c8c0b4" stroke-width="0.2" fill="none"/>';
        // ivory silk sheers on a brass rod, billowing in
        s += '<rect x="-60" y="-52" width="120" height="1.6" rx="0.8" fill="url(#br)"/>' + [-61, 61].map(x => '<circle cx="' + x + '" cy="-51.2" r="1.6" fill="#d8b060"/>').join('');
        s += '<g opacity="0.88">' + drape(-58, -46, -50.4, 99, 'url(#fs)', 7, 7, 0) + drape(46, 58, -50.4, 99, 'url(#fs)', -7, 7, -2.4) + '</g>';
        return { vb: [-64, -56, 128, 158], s }; };

      // BED-092 MOTORIZED PANORAMIC GLASS WALL OPENING TO SKY-TERRACE (T5): a floor-to-ceiling wall of four near-frameless glass panels in slim
      // champagne-bronze profiles under a header with a warm LED cove; the middle two slide apart on a motor to open the room onto a sky terrace:
      // teak deck, glass balustrade with a brass cap rail, an infinity pool on the edge, two cream loungers and an olive tree in a stone planter, above a
      // golden-hour sea of clouds with mountain peaks. Live: the middle panels glide open and closed, clouds drift below, the pool shimmers, the olive sways.
      WIN.bsky92 = () => { const BZ = '#b89a6a', R = rng('bsky92');
        let s = '<defs>' + WDEF + '<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b4a0c8"/><stop offset="0.4" stop-color="#f0c0a4"/><stop offset="0.68" stop-color="#fde4bc"/></linearGradient>'
          + '<radialGradient id="sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff8dc"/><stop offset="0.3" stop-color="#ffe2a8" stop-opacity="0.75"/><stop offset="1" stop-color="#ffd098" stop-opacity="0"/></radialGradient>'
          + '<linearGradient id="pw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e8c8b8"/><stop offset="1" stop-color="#c8a8a8"/></linearGradient>'
          + '<linearGradient id="gl" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0.02"/><stop offset="0.55" stop-color="#fff4e0" stop-opacity="0.1"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="br" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8a6a3a"/><stop offset="0.5" stop-color="#f0d8a0"/><stop offset="1" stop-color="#a88450"/></linearGradient>'
          + '<clipPath id="gc"><rect x="-92" y="-44" width="184" height="142"/></clipPath></defs>';
        s += '<rect x="-98" y="-52" width="196" height="152" fill="#000000" opacity="0.14" filter="url(#b2)"/>';
        let sc = '<rect x="-93" y="-45" width="186" height="144" fill="url(#k)"/><circle cx="46" cy="30" r="26" fill="url(#sun)">' + an('r', '25;28;25', 7, 0, SPL(2)) + '</circle><circle cx="46" cy="30" r="5.4" fill="#fff6d8"/>';
        sc += drift(cloud(-60, -30, 1.1, '#f8dcd4') + cloud(-10, -36, 0.8, '#f6d6d0') + cloud(30, -22, 0.9, '#fae2d4'), 186, 160);
        // peaks + sea of clouds (drifting layers)
        sc += '<path d="M-93 40L-74 26L-64 32L-48 18L-34 30L-20 24L-6 36H-93Z" fill="#b8a2b8"/><path d="M-48 18L-44 22L-46 24L-41 25" stroke="#f4e8f0" stroke-width="0.8" fill="none"/><path d="M14 38L30 28L42 34L60 22L78 32L93 26V40H14Z" fill="#c4acbc"/><path d="M60 22L64 26L61 27" stroke="#f8eef4" stroke-width="0.8" fill="none"/>';
        const sea = (y, c, a, T, ph) => '<g>' + at('translate', '0 0;' + a + ' 0;0 0', T, ph, SPL(2)) + '<path d="M-110 ' + y + rep(14, i => 'q8 -' + (3 + (i % 3)) + ' 16 0').join('') + 'V60H-110Z" fill="' + c + '"/></g>';
        sc += sea(40, '#f8e4dc', 10, 30, 0) + sea(46, '#fbeee4', -12, 26, -6) + sea(52, '#fff6ec', 8, 22, -3);
        // balustrade (glass + brass cap) and infinity pool at the far edge, deck boards
        sc += '<rect x="-93" y="56" width="186" height="16" fill="#ffffff" opacity="0.14"/>' + rep(8, i => '<path d="M' + (-93 + i * 24) + ' 56V72" stroke="#d8c8b0" stroke-width="0.4"/>').join('') + '<rect x="-93" y="55.2" width="186" height="1.2" fill="url(#br)"/>';
        sc += '<rect x="-88" y="68" width="74" height="8" fill="url(#pw)"/><rect x="-88" y="68" width="74" height="1" fill="#fff0e0" opacity="0.8"/>' + rep(6, i => '<path d="M' + (-84 + i * 12) + ' 72q3 -0.8 6 0" stroke="#fff6e8" stroke-width="0.4" fill="none" opacity="0">' + an('opacity', '0;0.8;0', 3, -i * 0.5) + '</path>').join('');
        sc += '<rect x="-93" y="76" width="186" height="23" fill="#b07a4a"/><rect x="-93" y="76" width="186" height="1" fill="#d8a878"/>' + [79, 82.6, 86.8, 91.6, 97].map(y => '<path d="M-93 ' + y + 'H93" stroke="#8a5a32" stroke-width="0.35"/>').join('')
          + rep(9, i => '<path d="M' + f1(-80 + i * 20) + ' 76L' + f1(-88 + i * 22) + ' 99" stroke="#9a6a3e" stroke-width="0.2" opacity="0.6"/>').join('') + '<rect x="-93" y="76" width="186" height="23" fill="#ffd8a0" opacity="0.08"/>';
        // two loungers + olive tree in a stone planter
        const lng = x => '<g transform="translate(' + x + ' 82)"><rect x="-1" y="-1" width="24" height="1.6" fill="#8a6a44"/><path d="M0 0V5M22 0V5" stroke="#6a4a2c" stroke-width="0.8"/><rect x="-1" y="-3.4" width="18" height="2.6" rx="1" fill="#f4ecdc"/><path d="M16 -3.2L23 -11L25 -10L18.6 -1.6Z" fill="#f0e6d2"/><rect x="2" y="-5" width="5" height="2" rx="1" fill="#d8a878"/></g>';
        sc += lng(18) + lng(44);
        sc += '<rect x="68" y="78" width="16" height="12" fill="#ddd2c0"/><rect x="67" y="77" width="18" height="2" fill="#ece4d6"/>' + sway(76, 77, 1, 2, 5, 0.2, '<path d="M0 0Q-1 -6 0.6 -12Q-2 -16 -4 -19M0.6 -12Q3 -16 5 -18" stroke="#6a5a48" stroke-width="0.9" fill="none"/>' + rep(26, () => '<ellipse cx="' + f1((R() - 0.5) * 18) + '" cy="' + f1(-16 - R() * 9) + '" rx="1.6" ry="0.55" transform="rotate(' + f1(R() * 60 - 30) + ')" fill="' + (R() < 0.5 ? '#8a9a6a' : '#a4b084') + '"/>').join(''));
        s += '<g clip-path="url(#gc)">' + sc + '</g>';
        // glass panels: 1 and 4 fixed, 2 and 3 slide outward over them
        const panel = (x, w) => '<rect x="' + x + '" y="-44" width="' + w + '" height="142" fill="#fff4e4" opacity="0.08"/><rect x="' + x + '" y="-44" width="' + w + '" height="142" fill="url(#gl)"/><path d="M' + f1(x + w * 0.25) + ' -44L' + f1(x + w * 0.05) + ' 98H' + f1(x + w * 0.14) + 'L' + f1(x + w * 0.34) + ' -44Z" fill="#ffffff" opacity="0.06"/>'
          + '<rect x="' + x + '" y="-44" width="1" height="142" fill="' + BZ + '"/><rect x="' + f1(x + w - 1) + '" y="-44" width="1" height="142" fill="' + shade(BZ, 0.8) + '"/>';
        s += panel(-92, 46) + panel(46, 46);
        const SL = (dx, T) => at('translate', '0 0;' + dx + ' 0;' + dx + ' 0;0 0;0 0', T, 0, ' calcMode="spline" keyTimes="0;0.2;0.6;0.8;1" keySplines="0.45 0 0.55 1;0 0 1 1;0.45 0 0.55 1;0 0 1 1"');
        s += '<g>' + SL(-42, 24) + '<rect x="-47" y="-44" width="47" height="142" fill="#000000" opacity="0.06"/>' + panel(-46, 46) + '<rect x="-4" y="22" width="1" height="18" rx="0.5" fill="url(#br)"/></g>';
        s += '<g>' + SL(42, 24) + '<rect x="0" y="-44" width="47" height="142" fill="#000000" opacity="0.06"/>' + panel(0, 46) + '<rect x="3" y="22" width="1" height="18" rx="0.5" fill="url(#br)"/></g>';
        // header with motor housing + warm LED cove, floor track, slim jambs
        s += '<rect x="-98" y="-52" width="196" height="8" fill="#ece4d8"/><rect x="-98" y="-45" width="196" height="1.2" fill="' + BZ + '"/><rect x="-96" y="-44" width="192" height="3" fill="#ffd890" opacity="0.4" filter="url(#b1)">' + an('opacity', '0.3;0.5;0.3', 6, 0, SPL(2)) + '</rect>'
          + '<rect x="-98" y="-52" width="196" height="1" fill="#ffffff" opacity="0.6"/><rect x="-96" y="96.6" width="192" height="1.6" fill="' + BZ + '"/><rect x="-96" y="96.6" width="192" height="0.5" fill="#f0dcb0"/>'
          + '<rect x="-96" y="-44" width="4" height="142" fill="#e6dccd"/><rect x="92" y="-44" width="4" height="142" fill="#ddd2c2"/><rect x="-92.6" y="-44" width="0.8" height="142" fill="' + BZ + '"/><rect x="91.8" y="-44" width="0.8" height="142" fill="' + BZ + '"/>';
        // tiny status light on the jamb (motor)
        s += '<circle cx="-94" cy="30" r="0.7" fill="#ffd890">' + an('opacity', '0.4;1;0.4', 3) + '</circle>';
        return { vb: [-100, -54, 200, 156], s }; };

    }

  }

  const FLOOR30 = { sub: fSub, berber: fBerber, oak: fOak30, herr: fHerr, mem: fMem }, MEMO = {};
  const draw29 = RD.draw;
  RD.draw = (r, o) => { const res = draw29(r, o); if (!res || res._p30) return res;
    try { const f = r.f30 && FLOOR30[r.f30]; if (f && res.surf) { res._p30 = 1; res.vb = '0 0 80 56'; res.svg = MEMO[r.f30] || (MEMO[r.f30] = RD.svgDoc('0 0 80 56', [], f())); res.src = 'data:image/svg+xml,' + encodeURIComponent(res.svg); } } catch (e) { console.warn('reno plus30', r.id, e); }
    return res; };

  RD.SET30 = {
    'BED-005': { f30: 'sub', live: 'Cold draught', note: 'Bare rough-sawn pine subfloor boards gone grey, with uneven dark gaps between them, circular-saw swirls, lifting splinters, rows of rusty nail heads over the joists, a knothole right through, one fresher yellow patch board, old white paint drips and a roller swipe, a water ring, a leftover tack strip along the wall, carpet-pad crumbs and dust bunnies. A cold draught breathes up through the gaps.' },
    'BED-025': { f30: 'berber', live: 'Morning light drifts', note: 'Wall-to-wall oatmeal berber in tight looped rows, heathered with darker and lighter flecks, with vacuum stripes, a matted traffic lane to the bed, a faded coffee stain, a couple of snagged loops, a flattened square where a dresser stood and a line of dust along the skirting. A warm patch of morning light drifts across with dust motes glinting in it.' },
    'BED-045': { f30: 'oak', live: 'Window reflection glides', note: 'Narrow honey red-oak strips with random butt joints, open cathedral grain and ray flecks, a few darker mineral streaks and tight hairline joints under a satin finish, with a couple of fine scratches by the bed and a chair-leg dent. The window reflection slides slowly across the boards.' },
    'BED-065': { f30: 'herr', live: 'Heated warmth + nosing glint', note: 'A raised island of pale oiled ash herringbone (blond-grey blocks with fine straight grain and a soft matte sheen) edged with a bronze nosing, stepping down to a wide sunken border of deep ivory-greige plush carpet round the walls. Warmth shimmers up off the heated ash and a glint travels along the bronze.' },
    'BED-085': { f30: 'mem', live: 'Glowing footsteps', note: 'Big pillowed slabs of warm pearl-grey memory stone, each softly domed with a velvety bevel, set in fine seams holding a thread of warm night light. Soft footprints press into the stone one after another from the door toward the bed, each glowing warm amber and fading like a memory, while the seams breathe.' },
    'BED-017': { spec: 'rug30a', live: 'Curling corner lifts', note: 'A cheap peach acrylic bath mat pressed into service as a bedside rug, lying a bit crooked: pilled synthetic fuzz with a faint embossed seashell, a flattened grey patch where feet land every morning, bleach spots, crumbs and a hair, a dropped grey sock, and the back corner curling up to show the cracked rubber backing.' },
    'BED-037': { spec: 'rug30b', live: 'Sheen rolls through the shag', note: 'A Beni Ourain-style cream wool shag with long soft pile and lighter tips, an irregular hand-knotted charcoal diamond lattice (each line a run of dark knots) with a few wobbles, tasselled fringe on both short ends, slightly flattened where it is walked on. A soft sheen rolls through the pile.' },
    'BED-057': { spec: 'rug30c', live: 'Sheen drifts over the fur', note: 'A long flat-woven oatmeal wool runner with rust, ochre and charcoal bands, a stepped geometric border and knotted fringe, with two faux-sheepskin pelts (one ivory, one dove grey) thrown over it, their curly fluffy edges spilling onto the floor. A slow sheen drifts over the fur.' },
    'BED-077': { spec: 'rug30d', live: 'Silk sheen travels', note: 'A deep hand-knotted carpet in soft slate-blue cashmere wool with Tibetan cloud scrolls and a central medallion worked in ivory and champagne-gold silk, a narrow tiger-stripe guard border, a hand-bound edge and gentle colour banding. A slow sheen travels across and the silk scrolls glow.' },
    'BED-097': { spec: 'rug30e', live: 'Warmth breathes in rings', note: 'A thick oval of cloud-white fibre built up from soft cumulus billows, quilted into sound-dampening concentric channels with fine stitching, finished with a rolled pillow rim bound in champagne silk piping. A warm amber glow seeps out from under the edge onto the floor. Warmth breathes out from the centre in slow rings and a soft sheen drifts across the billows.' },
    'BED-001': { s12: 'bd01dry', live: 'Torn poster corner flutters', note: 'Tired eggshell paint over drywall with roller stipple and lap marks, a taped seam showing through with two nail pops and a hairline crack. Brighter rectangles show where posters hung for years, with greasy blue-tack stains, leftover blue and white tack and pulled-off paint at the corners, plus pin holes, a bent nail, grey furniture scuffs, a black shoe scuff, a cracked almond outlet painted round its edge and a cheap MDF skirting with chipped paint. A torn poster corner still stuck under yellowed tape flutters in the draught.' },
    'BED-021': { s12: 'bd21lav', live: 'Afternoon light slides by', note: 'Soft lavender matte paint above a white painted chair rail, with warm cream below. A fresh but home-painted job: faint roller stipple and lap bands, a slightly wavy cut-in line along the rail with one tiny lavender drip on the cream, a touch-up patch that dried a shade off, the soft shadow of the ceiling corner, a white outlet and a satin white skirting. A warm patch of afternoon window light slides slowly across the lavender.' },
    'BED-041': { s12: 'bd41chin', live: 'Mica ground glimmers', note: 'Hand-painted-style chinoiserie paper on a soft celadon ground with a linen weave: two flowering plum trees in umber brush strokes covered in blush and white blossoms and buds, a stand of bamboo with ink-green leaves and a little indigo songbird perched on a branch. Below, a sage-painted raised-panel wainscot with a moulded cap rail, bevelled panels and brush marks in the satin paint, a slim outlet on a stile and a matching skirting. Flecks of mica in the paper glimmer as the light moves.' },
    'BED-061': { s12: 'bd61vel', live: 'Sheen rolls through the velvet', note: 'Book-matched American walnut veneer across the top, with mirrored cathedral figure, a dark mineral streak and a satin oil finish under a warm wash of cove light, over a slim brushed-brass reveal. Below, floor-height channel-tufted olive velvet: each channel a padded roll with the silvery edge sheen and deep crown of real velvet, stitched seams and soft crush marks in the pile, on a walnut plinth with a brass edge. A sheen rolls slowly across the channels and a glint slides along the brass.' },
    'BED-081': { s12: 'bd81silk', live: 'Starlight drifts, a star shoots by', note: 'Floor-to-ceiling pillowed acoustic panels upholstered in hand-woven shot silk (midnight indigo warp, plum weft) with visible slubs and a soft moving moire, joined by champagne-gold pin trims. A hidden cove washes warm light down from the top and a warm amber reveal glows along the skirting. A warm starfield and a soft milky-way band are projected onto the silk: the sky drifts slowly across, the stars twinkle and now and then a shooting star crosses.' },
    'BED-004': { spec: 'hang30a', live: 'Loose star swings', note: 'A kid-made night sky above the bed: wonky hand-cut stars in yellow construction paper with scissor nicks and pencil lines still showing, two in crinkled kitchen foil, one crayon-coloured and one crusted with glitter glue, and a smiling crescent moon cut from a cereal box and painted yellow, the printed cardboard showing at a torn edge. Everything is stuck up with yellowed clear tape and masking tape, with glow-in-the-dark plastic stickers in between, a torn tape scrap where a star fell and a faint pencil guide arc. One star hangs by a single corner of tape and swings in the draught while the glow stickers glow softly.' },
    'BED-024': { spec: 'hang30b', live: 'Fairy lights twinkle', note: 'Natural cotton macrame on a pale driftwood dowel, hung from a nail by a cord loop: lark\'s head knots over the dowel, a band of square knots, an alternating square-knot net that opens into a V, a big double-half-hitch diamond round a gathering knot, spiral twists down both sides and a long brushed-out fringe cut in a V. Copper-wire fairy lights are draped in swags from coloured push pins either side, ending in a little battery box. The lights twinkle in a slow wave, throwing warm spots on the wall, and the fringe sways.' },
    'BED-044': { spec: 'hang30c', live: 'Glint travels the gallery', note: 'Five slim natural-oak frames hung as a gallery, each with a deep bevel-cut white mat and a pressed specimen on cream cotton paper, faded the way real pressed flowers fade: a big bracken fern frond with a sprig of Queen Anne\'s lace, a violet pansy, a pink cosmos, three lavender sprigs tied with raffia and golden ginkgo leaves, each with a pencilled Latin label. A soft glint travels along the glass from frame to frame.' },
    'BED-064': { spec: 'hang30d', live: 'Light slides over the silk', note: 'A deep black-lacquer shadowbox with a gilded inner fillet, lined in ivory silk and lit by a hidden warm strip along the top. Inside, a crimson silk furisode hangs by its sleeves on a bamboo pole: hand-embroidered cranes in white silk with black necks and red crowns, gold-couched clouds and plum blossoms, gold seigaiha waves round the hem and sleeve ends, an ivory and gold collar, soft drape folds and the kimono\'s own shadow on the lining, behind glass. Light slides slowly across the silk and the gold threads glint.' },
    'BED-084': { spec: 'hang30e', live: 'Mandala turns, mycelium pulses', note: 'A deep forest-night mural sprayed onto the wall with a feathered edge: glowing mycelium threads branching out from the centre, foxfire mushrooms with amber caps, curled fern fiddleheads and moss in soft lime-gold light, and fireflies. At its heart a brass drum under a glass dome holds a hand-poured sand mandala in terracotta, ochre, ivory, lapis, black and gold sand. The mandala\'s rings slowly turn against each other, the inner lotus breathes, sand flows round the groove, pulses of light travel out along the mycelium and fireflies drift.' },
    'BED-009': { c30: 'spot', live: 'Leak drips', note: 'Old lath-and-plaster gone ivory-yellow, with trowel swirls, the faint ghost lines of the joists and a network of hairline map cracks. Three old brown tide-ring water stains, and one fresh dark one where the plaster sags into a bulge with a crack across it. A patch of white filler someone sanded and never painted, paint flakes lifting to grey plaster and a tired cove moulding. A drop of water slowly swells under the fresh stain, lets go and falls.' },
    'BED-029': { c30: 'fan', live: 'Fan turns on low', note: 'A freshly rolled flat white ceiling with faint roller laps, one taped seam ghosting through, a nail pop and a grey dust halo round the fan. A budget white ceiling fan on a short downrod: plain white motor housing, three light-oak laminate blades on white steel irons, a switch housing with a small frosted bowl light and two pull chains with wooden beads, plus a round smoke alarm off to one side. The blades turn on low, the pull chains sway and the alarm LED blinks now and then.' },
    'BED-049': { c30: 'ship', live: 'Late sun slides across', note: 'White-washed pine shiplap running up both slopes of a vault to the ridge, the left slope catching more light than the right, each board a hair different with soft grain, a dark nickel gap and a few knots ghosting through the wash. A chunky rough-sawn oak ridge beam with saw marks, drying checks and black iron strap brackets with bolt heads. A warm band of late sun from the gable window slides across the boards with dust motes glinting in it.' },
    'BED-069': { c30: 'tray', live: 'Cove glow breathes', note: 'A smooth warm-greige satin ceiling stepping up into a deep tray framed by a white crown moulding. Inside is champagne Venetian plaster with soft polished clouding, washed by warm light from an LED strip hidden on the cove ledge (brightest at the edges, fading to the middle), with a hand-cast plaster ceiling rose at the centre and four trimless pin lights in the outer band. The cove glow breathes softly and a slow sheen drifts across the polished plaster.' },
    'BED-089': { c30: 'aur', live: 'Aurora ripples, sky turns', note: 'A deep night-blue lacquered ceiling with a fine gold pinstripe opens into a great shallow dome framed by a champagne-gold rim, with a warm amber reveal glowing round it. The dome falls away into deep space: a dense starfield, soft rose, violet and amber nebula clouds and the Milky Way, with aurora curtains in emerald fading to rose hanging across it. The sky turns slowly, the aurora ripples and drifts, stars twinkle and now and then a shooting star crosses.' },
    'BED-010': { spec: 'bulb30', s3: null, live: 'Flickers and sways', note: 'A yellowed plastic ceiling rose with paint overspray, a twisted white flex and a cream bakelite lampholder, with a bare pear bulb hanging half out of a home-folded paper shade: a faceted origami lantern in cheap printer paper, a bit lopsided, one facet split and mended with tape and a brown scorch where it sits too close to the bulb. The bulb flickers now and then, the paper glows warm and the whole thing sways in the draught.' },
    'BED-030': { spec: 'bamb30', s3: null, live: 'Dappled light shimmers', note: 'A white steel ceiling plate holding a shallow drum of hand-woven bamboo: honey and natural strips in an over-under basket weave with braided rims, warm light leaking through every gap, a rice-paper diffuser glowing underneath and dappled spots of light thrown onto the ceiling around it. The dapples shimmer and the glow breathes.' },
    'BED-050': { spec: 'capiz30', s3: null, live: 'Shell strands sway', note: 'A white-washed iron frame of three tiers hung from a jute-wrapped chain, every ring strung with strands of thin round capiz shells on fishing line: translucent pearly discs, each a slightly different white with a faint pink-gold sheen, some turned edge-on, with warm bulbs inside glowing through them. The strands sway and the shells shimmer as they turn.' },
    'BED-070': { spec: 'cloud30', s3: null, live: 'Globes breathe in a wave', note: 'A brushed-gold canopy and slim rod holding a billowing cloud of hand-blown frosted glass globes in many sizes, each on its own short gold stem from a central gold hub, glowing soft warm white from inside with a brighter core and a crisp sheen on the frosting. The globes breathe in a slow wave through the cloud and a glint runs down the gold.' },
    'BED-090': { spec: 'halo30', s3: null, live: 'Halo floats, feathers ripple', note: 'A slim polished champagne-gold halo hovers in the air with nothing holding it, under a pale glowing disc set flush in the ceiling. From the halo hang long soft feathers that glow from within like deep-sea creatures, pearl-white at the quill warming to gold at the tips, with fine glowing barbs. The halo bobs gently, a bead of light runs round it, the feathers ripple one after another as their glow drifts through gold, rose and lilac, and glowing motes drift down.' },
    'BED-020': { spec: 'fan30', live: 'Fan whirs, clock ticks', note: 'A yellowed beige plastic box fan with a dusty white grille (fluff caught in the corners), a cracked carry handle mended with tape, a three-speed dial and a faded brand sticker, its blades spinning behind the grille with a strip of paper tied on that streams in the breeze. Beside it a chrome twin-bell wind-up alarm clock on two splayed legs, with the hammer between its bells, a key on the back and a yellowed dial. The blades spin, the paper streamer flutters and the second hand ticks.' },
    'BED-040': { spec: 'mist30', live: 'Mist rolls, sound ripples', note: 'A squat cream sound machine with a slotted lid, a ring of side vents and a soft amber power dot. Beside it a pebble-shaped ultrasonic humidifier: a frosted clear tank half full of water on a white base with a warm amber night-light ring and a mist nozzle, sitting on a knitted coaster. A cool mist plume rolls up from the nozzle, the water trembles, the night-light breathes and soft sound ripples ring out of the vents.' },
    'BED-060': { spec: 'dawn30', live: 'Dawn fills the lamp', note: 'A tall cylindrical air purifier in a warm grey knitted fabric sleeve with a pale oak top, a perforated outlet and a soft air-quality ring. Next to it a frosted round sunrise lamp on a white stand with a dim clock below its face, and a little walnut and glass nebulizer with an upside-down amber bottle of lavender oil. The sunrise face slowly fills with dawn, deep red to orange to warm white, and fades back; the purifier ring breathes with air shimmering off its top, and a fine scented mist curls up from the nebulizer.' },
    'BED-080': { spec: 'proj30', live: 'Film light flickers', note: 'A walnut ceiling disc with a brushed-brass ring whose hatch has slid open. A matte-black cinema projector with a brass vent band has dropped out of it on a brass telescoping arm, its glass lens glowing as it throws a soft warm beam across the room. The beam flickers with the colours of the film, dust motes glint in it and the status light breathes.' },
    'BED-100': { spec: 'dream30', live: 'Orb dreams, waves ripple', note: 'A two-tier honed travertine plinth banded in champagne gold, its top planted with a ring of living moss and tiny white flowers around a gold cradle. Above it floats a pearl orb with a slow rose-and-amber dream swirl inside, circled by two crossed polished-gold gyroscope rings, and beside it a silk-wrapped neural headband rests on a slim brass stand. The orb breathes and its swirl turns, soft waves ripple out around it, glints travel along the rings, oxygen-rich mist rolls out of the gap under the plinth and the headband\'s gold dots pulse slowly.' },
    'BED-002': { spec: 'box30', live: 'Torn tape flutters', note: 'An upturned double-wall moving box doing duty as a nightstand: soft scuffed kraft board with corrugated edges, THIS SIDE UP arrows now pointing down, a red FRAGILE stamp, marker scrawl "BEDROOM - MISC" crossed out and replaced with "BOOKS!!", a crushed top corner, packing tape across the top and down the front with a torn end curling off, a coffee ring on top and hand-holes on the sides. The torn tape end lifts and flutters in the draught.' },
    'BED-022': { spec: 'pine30', live: 'Bookmark ribbon sways', note: 'A budget flat-pack pine nightstand in thin white paint with the grain showing through: a single drawer with a turned wooden knob and a hairline gap, an open shelf below on square legs, a chipped corner showing raw pine, a ring mark and a scuff on the top and a cam-lock cap on the side. On the shelf sits a stack of paperbacks with a red ribbon bookmark hanging out, swaying gently.' },
    'BED-042': { spec: 'cane30', live: 'Sheen slides along the walnut', note: 'An oiled American walnut case with softly rounded edges and long straight grain, two drawers faced in hand-woven rattan cane framed in walnut with slim brass pulls, a lipped top, on four splayed tapered legs ending in brass ferrules. A warm sheen slides along the oiled top and the brass pulls glint.' },
    'BED-062': { spec: 'flute30', live: 'Hidden safe peeks open', note: 'A block of honed Calacatta marble floating clear of the floor, its front carved into deep vertical flutes, with a polished brass line along the top edge, grey and gold veins across the top and sides and a warm LED wash glowing on the floor beneath. One flute is really a door: now and then it swings open a crack to show a brass keypad glowing behind, then closes. The under-glow breathes and a glint runs along the brass.' },
    'BED-082': { spec: 'smart30', live: 'Tea steeps, voice light ripples', note: 'A softly rounded ivory lacquer cabinet on a champagne-gold plinth, topped with a slab of backlit honey onyx. A glowing champagne charging ring is set into the onyx with a phone resting on it, and a sunken brew well holds a glass teapot of steeping tea on a warm hotplate. A woven ivory speaker band runs across the front with a gold voice light bar, above a hidden drawer with a slim gold pull. The tea slowly deepens to amber while steam curls up, the charging ring pulses and the voice light ripples as if it is speaking.' },
    'BED-003': { spec: 'fold30', live: 'Rocks on its short leg', note: 'A sun-faded sky-blue plastic folding stool: a rounded top with a carry slot and a grid of anti-slip dimples, two leg panels with big cut-outs, cross braces, grey hinge rivets and scuffed feet, white stress marks at the hinges, a crack bound with clear tape and a half-peeled $3.99 sticker. One leg is a bit short, so now and then it rocks and settles.' },
    'BED-023': { spec: 'fur30', live: 'Fur ripples', note: 'A plump round stool upholstered in long shaggy blush-ivory faux fur that spills over the edge and hides the base, with a soft dip in the middle of the seat, on four short tapered gold-tone legs with felt pads (one leg worn through to silver). The fur ripples in a soft draught and a sheen moves over it.' },
    'BED-043': { spec: 'shell30', live: 'Velvet sheen drifts', note: 'A round blush-rose velvet seat in a curved shell back of seven stitched channels, each rising to a rounded scallop (tallest in the middle), on a slim polished-gold frame ring with four short tapered legs on gold ball casters. The velvet sheen drifts slowly across the channels and seat.' },
    'BED-063': { spec: 'lounge30', live: 'Sheen glides over the leather', note: 'Moulded walnut plywood shells for the seat, lower back and upper back cradle plump cognac aniline leather cushions with button tufts, with padded leather armrests on walnut arms, all on a polished aluminium five-star swivel base. A warm sheen glides over the leather.' },
    'BED-083': { spec: 'pod30', live: 'Pod floats, motes rise', note: 'An egg-shaped pod in ivory lacquer with champagne-gold edges, open to the front and lined with quilted pearl silk, hovering over a black-glass base disc that glows warm underneath. A slim gold reading arm arcs over from the shell to a small warm lamp. The lining\'s sheen drifts, the levitation glow breathes, the reading lamp glows and soft motes rise through the gap.' },
    'BED-006': { spec: 'clip30', live: 'Flickers, moth circles', note: 'A cheap clip lamp clamped onto a stack of three old paperbacks for a base: black spring-clamp jaws with a rusty spring, a crinkled chrome gooseneck and a yellowed white plastic dome shade with a heat-browned vent ring, with a bare bulb glowing under it and a thin white cord with an inline switch trailing off the books. The bulb flickers now and then and a moth circles the light.' },
    'BED-026': { spec: 'cer30', live: 'Shade glow breathes', note: 'A plump gourd-shaped ceramic base in sage-green crackle glaze with a cream foot ring, a brass neck and harp with a little finial, and a box-pleated cream linen drum shade glowing warm from inside, on a linen cord. The shade\'s glow breathes softly and the pool of light beneath it warms and cools.' },
    'BED-046': { spec: 'swing30', live: 'Motes drift in the beam', note: 'A round brushed-brass backplate with a rocker switch, a two-section swing arm with knurled knuckles and a tension knob, a linen cord running along the arm and a brass cone shade lined in white enamel, angled down to throw a warm reading cone. Dust motes drift through the beam and a glint slides along the brass.' },
    'BED-066': { spec: 'alab30', live: 'Dawn glows through the stone', note: 'A hand-turned globe of translucent alabaster with honey and cream veins and a few darker mineral threads, glowing from within, seated in a hammered brass cup on a slim walnut plinth with a brass touch ring. A slow dawn runs through the stone, deep amber warming to soft white and back, and the touch ring pulses.' },
    'BED-086': { spec: 'moon30', live: 'Moon turns, phase sweeps', note: 'A detailed moon with grey-ivory regolith, dark maria and rayed craters floating on nothing above a walnut and brass maglev base whose ring glows a sleepy amber, giving off a warm, blue-free light. The moon turns slowly as it floats and bobs, its phase shadow sweeps across over a long cycle, and the base ring breathes.' },
    'BED-007': { spec: 'trunk30', live: 'Caught sock sways', note: 'An old pine footlocker in scuffed olive-drab paint worn to bare wood on every edge, with dented tin corner caps, riveted steel straps, a sprung hasp with no padlock, rope side handles (one frayed), a faded stencil "PROPERTY OF - BUNK 7" and a peeling band sticker. The lid sits ajar on a striped sock caught in it, which sways gently.' },
    'BED-027': { spec: 'ott30', live: 'Throw tassels sway', note: 'A long ottoman in warm oatmeal slub linen: a deep padded lift-up lid with a button-tufted top and flax piping round both edges, a gathered pull-tab at the front where it opens, linen-wrapped sides with soft wrinkles at the corners, on four turned beech legs, with a chunky cable-knit cream throw slung over one end. The throw\'s tassels sway and a soft sheen moves along the lid.' },
    'BED-047': { spec: 'day30', live: 'Sheen slides along the leather', note: 'An oiled teak frame on tapered legs with brass ferrules, its deck and raked head end strung with saddle-leather straps in a tight basket weave, every strap stitched and wrapped round the side rails, with a round cognac leather bolster with button-centred ends and a folded mustard wool throw with fringe at the foot. A warm sheen slides along the leather and the brass ferrules glint.' },
    'BED-067': { spec: 'cab30', live: 'Sheen drifts over the cashmere', note: 'A long bench in warm dove cashmere: a deep crowned seat with diamond tufting (puffy pillowed diamonds with pleats folding into every covered button), soft pleats down the sides, a piped edge and an apron finished with a close row of polished brass nailheads, on four sculpted polished-brass cabriole legs with rounded knees and pad feet. A soft sheen drifts across the cashmere and a glint runs down the brass legs.' },
    'BED-087': { spec: 'valet30', live: 'Warm seams breathe, massage ripples', note: 'A long bench in ivory nappa leather with deep channel quilting along its top, on a polished champagne-gold plinth. Under the seat is an open, warmly lit shoe valet holding velvet slippers and tan loafers on a walnut shelf, and a slim touch strip on one end shows heat and massage icons. Warmth glows and breathes along the channel seams, massage rollers ripple slowly along under the leather, and the valet light and icons pulse.' },
    'BED-008': { spec: 'glass30', live: 'A bubble rises', note: 'A well-thumbed paperback lying face-down and open, with a cracked spine, dog-eared corners, yellowed page edges and a coffee ring on the cover, beside a cheap ribbed tumbler half full of yesterday\'s water with bubbles clinging inside and a fingerprint smudge, sitting in its own wet ring. Now and then a bubble lets go and rises, and light shimmers through the water.' },
    'BED-028': { spec: 'cone30', live: 'Lavender mist puffs', note: 'A little hand-thrown ring cone on a saucer in speckled oatmeal glaze holding a thin gold band and a silver ring with a tiny stone, a dusty-rose satin sleep mask with a ruffled edge and a looped elastic, and a frosted lilac bottle of lavender pillow spray with a silver pump and a kraft label printed with a lavender sprig. Now and then a fine puff of mist drifts from the sprayer, and the rings glint.' },
    'BED-048': { spec: 'carafe30', live: 'Crystal glints, tassel sways', note: 'A cut-crystal night carafe half full of water with its tumbler upturned over the neck, standing on a little round brass tray, beside a tan pebbled-leather journal with a wrap tie, gilt-edged pages and a slim brass leaf bookmark on a silk tassel. Light catches the crystal facets in turn and the bookmark\'s tassel sways.' },
    'BED-068': { spec: 'winder30', live: 'Watch turns, candle flickers', note: 'A burl-walnut watch winder with a glass lid and brass pull, a gold automatic watch on a cream suede cushion inside; a folded champagne silk eye mask; and an amber glass candle vessel with a hand-poured "Fig & Cedar" label and a crackling wooden wick. The winder turns the watch slowly, the candle flame flickers and a thin wisp rises from the wick.' },
    'BED-088': { spec: 'elix30', live: 'Crystal floats and sparkles', note: 'A faceted rose-quartz crystal floating over a black onyx and gold base whose ring glows warm, with a soft light inside the crystal, beside a gold rack of three slim glass elixir vials (amber chamomile, rose and pale honey) with glowing level marks. The crystal floats, turns and sparkles, the base ring breathes and tiny bubbles rise in the vials.' },
    'BED-011': { spec: 'door30', live: 'Reflection wobbles', note: 'A tall narrow budget mirror in a yellowed white plastic frame hung on two bent wire hooks, its thin acrylic glass warping the reflection, with a photo-booth strip tucked into one corner, a dusty smudge, a peeled price sticker and a cracked corner held with clear tape. Now and then the flexible glass makes the reflection wobble.' },
    'BED-031': { spec: 'cheval30', live: 'Glint slides down the glass', note: 'A tall honey-oak cheval mirror: a framed, bevelled mirror tilting between two turned uprights on trestle feet, with brass tilt knobs, a slim stretcher bar and a cotton scarf hung over one upright. A glint slides slowly down the glass and the scarf\'s fringe stirs.' },
    'BED-051': { spec: 'arch30', live: 'Glint slides down the arch', note: 'A huge arch-topped mirror in a slim brushed-brass frame leaning back against the wall on two felt pads, with a soft shadow behind it, a linen throw draped over one side and a small trailing pothos in a terracotta pot at its foot. A glint slides down the arch and the pothos leaves sway.' },
    'BED-071': { spec: 'paris30', live: 'Halo breathes, gilding twinkles', note: 'A tall Louis XV floor mirror leaning on the wall in a thick hand-carved frame, water-gilded in warm gold, with a ribbed acanthus moulding, a beaded inner edge, a scallop-shell crest between curling C-scrolls and carved roses at the foot. A warm LED strip hidden behind the frame washes the wall in a soft golden halo, and a blush velvet pouf on a gilt band sits beside it. The halo breathes, a glint slides down the glass and the gilding catches tiny twinkles.' },
    'BED-091': { spec: 'holo30', live: 'Hologram turns through outfits', note: 'A tall frameless smart mirror with a slim brushed champagne-gold edge on a low gold foot, facing a round champagne try-on turntable. A warm hologram of an outfit stands in a soft column of light above the turntable and slowly turns all the way round, cycling through a silk gown, a belted trench and a jumpsuit, while the glass shows the same look beside a swatch carousel and a turning 360 icon. A scan line sweeps up, motes of light rise and the turntable ring rotates.' },
    'BED-012': { w19: 'bwin12', live: 'Paper shade flutters in the draught', note: 'An old single-hung wood window with its white paint flaking to grey wood. The sashes gap at the meeting rail, foam weatherstrip peels off and hangs, a cracked pane is held with yellowed tape and the lower corners fog with condensation. A cheap pleated paper shade is stuck on with its adhesive strip, half down, one pleat torn and the cord lock clipped crooked. Outside are a grey sky, the neighbour\'s brick wall and a bare branch, and a rolled towel blocks the draught on the sill. The paper pleats flutter, faint cold wisps slip in under the sash, the branch sways and a dry leaf blows past.' },
    'BED-032': { w19: 'bcas32', live: 'Lace billows on the breeze', note: 'A white-painted wood casement pair: the left sash shut with a cockspur handle, the right one pushed open outward on its stay arm. A floral lace sheer hangs inside, the open side billowing into the room, and over it a pair of dusty-navy cotton blackout curtains hang from a wooden pole with ball finials, tied back with fabric tiebacks. A little succulent sits on the sill. Outside is a sunny garden with a lilac tree, a hedge and the neighbour\'s roof, and a butterfly flits past.' },
    'BED-052': { w19: 'bseat52', live: 'Rain trickles, cocoa steams', note: 'A deep sage-painted alcove with a built-in window seat. A many-paned window sits at the back with louvred white shutters folded open against the side walls. The seat has a thick striped linen cushion with piping, scatter pillows in rust velvet, cream knit and mustard check, a chunky knit throw over the edge, an open book and a mug of cocoa, with two drawers and brass cup pulls below. A warm wall light glows in the nook. Outside it is raining on a green garden: drops trickle down the panes, the trees sway and steam curls from the mug.' },
    'BED-072': { w19: 'bfr72', live: 'Sheers billow, swallows wheel', note: 'Tall cream-painted French doors with slim divided panes and polished brass espagnolette bolts, both swung wide into the room under a fixed transom. Outside is a wrought-iron Juliet railing with scrolls and gilded tips, and window boxes of red geraniums with trailing ivy. Ivory silk sheers hang on a brass rod either side. The view is a golden-hour sky over terracotta and zinc rooftops with chimney pots and a distant dome. The sheers billow in, swallows wheel across the sky, the geraniums nod and the sun glows.' },
    'BED-092': { w19: 'bsky92', live: 'Glass glides open, clouds drift', note: 'A floor-to-ceiling wall of four near-frameless glass panels in slim champagne-bronze profiles, under a header with a warm LED cove. The middle two panels slide apart on a motor to open the room onto a sky terrace: a teak deck, a glass balustrade with a brass cap rail, an infinity pool on the edge, two cream loungers and an olive tree in a stone planter, above a golden-hour sea of clouds with mountain peaks. The panels glide open and closed, the clouds drift below, the pool shimmers and the olive sways.' },
    'BED-013': { spec: 'rack30', live: 'Rack wobbles, hanger swings', note: 'A cheap chrome-look garment rack gone dull, its top rail bowing, one upright joint wrapped in duct tape and one caster missing, so that foot is propped on a paperback. Wire dry-cleaner hangers hold a dry-cleaning bag over a white shirt, a grey hoodie, a red flannel shirt and folded jeans, plus one bare hanger. A wire shelf below holds a pair of sneakers and a shoebox. The whole rack wobbles, the clothes jiggle and the empty hanger swings.' },
    'BED-033': { spec: 'armo30', live: 'Door creaks open, tote sways', note: 'A flat-pack white laminate wardrobe on a grey kick plinth with two doors and slim aluminium bar handles. The right door\'s hinge has dropped, so it never quite shuts and keeps drifting open on a dark glimpse of hanging clothes. The edge banding is peeling at the top corner, there is a barcode assembly sticker on the side, a canvas tote hangs off the left handle, and a rattan basket and a taped cardboard box sit on top. The door creaks open a little and drifts back, and the tote sways.' },
    'BED-053': { spec: 'reach30', live: 'Mirror door glides open', note: 'A built-in reach-in closet in white with a pale oak fascia and two full-height bypass doors of mirror in slim brushed-aluminium frames on top and floor tracks. Behind them is a warm-lit interior: an oak rail of shirts, knits, dresses and a coat, a shelf of folded sweaters and storage boxes with a warm LED strip beneath, and a slanted shoe rack. The front mirror door glides open to the left and back, and a glint slides down the glass.' },
    'BED-073': { spec: 'walk30', live: 'Island glows, jewels twinkle', note: 'A boutique wall of figured walnut with a champagne-gold crown and warm light coves: a hanging bay of silk dresses and a camel coat, a centre bay of lit glass cubbies holding handbags, and a bay of angled lit shoe shelves, with drawers below. In front stands a walnut island with a glass top glowing over a navy velvet tray of watches, rings and a pendant, champagne pulls and a light under the plinth, and a white orchid and a red handbag on top. The island glows and its jewels twinkle, a soft wave of light passes along the cubbies and the dresses sway.' },
    'BED-093': { spec: 'caro30', live: 'Carousel turns, mirror tries outfits', note: 'A tall ivory lacquer wardrobe with champagne-gold pinstripes, crown and plinth. Its wide open bay is a warm-lit conveyor where garments ride a gold oval track, the front row gliding one way and the back row the other, under a soft spotlight. The right panel is a virtual outfit mirror where a dress form tries on each outfit in turn beside colour swatches and a breathing gold status ring. The carousel turns, the mirror cycles outfits and a scan line sweeps up.' },
    'BED-014': { spec: 'shoe30', live: 'Tennis ball rocks', note: 'An old brown cardboard shoebox with one corner crushed and a strip of masking tape across the front with a scribbled name and a heart, lined with a faded striped hand towel whose frayed corner flops over the front edge. The lid lies behind it, and a chewed tennis ball and a knotted sock toy wait beside it. The tennis ball rocks a little and the towel corner stirs.' },
    'BED-034': { spec: 'donut30', live: 'Sheen circles the fluffy rim', note: 'A round calming donut bed in oatmeal-and-blush shag faux fur: a high fluffy rim all the way round a sunken cushion, with a non-slip base peeking out underneath. A folded blue fleece blanket and a plush carrot toy lie in the hollow. A soft sheen travels round the rim and the carrot\'s leaves wiggle.' },
    'BED-054': { spec: 'canopy30', live: 'Sheers sway, lights twinkle', note: 'A little four-poster in oiled walnut with slim turned posts and ball finials, a woven-cane headboard, a thick sage linen mattress with piping, a cream bolster and a knit throw folded over the corner. Ivory linen valances hang round the canopy rails, sheer voile drapes are tied back at the four posts and a string of tiny warm lights loops along the top. The sheers sway and the little lights twinkle.' },
    'BED-074': { spec: 'bunk30', live: 'Warm glow breathes, heat shimmers', note: 'A walnut-framed bunk on brass feet with two polished brass hook arms and a leather strap at the back that clip it to the side rail of the big bed. Inside are a dusty-blue velvet U-bolster and a cream sherpa cover over layered orthopedic memory foam, with one corner folded back to show the egg-crate layer, plus a little heart pillow, a brass name plaque and a slim heat controller on its cord. A warm glow breathes over the cushion, heat shimmer rises and the controller ring pulses.' },
    'BED-094': { spec: 'cloud94', live: 'Cloud bobs, lullaby notes drift', note: 'A cradle of soft ivory cloud puffs hovering over a pearl base disc ringed in champagne gold, with a peach-glow cushion and a tiny star pillow in its hollow and warm light pooled on the base beneath. The cloud bobs gently, the glow breathes with it, little lullaby notes drift up and tiny gold stars circle around it.' },
    'BED-015': { spec: 'floor30', live: 'Phone lights up', note: 'A sagging thin foam twin mattress straight on the floorboards, its faded ticking cover split at one corner to show yellowed foam, a blue fitted sheet half pulled off, one flat yellowed pillow and a red-and-grey fleece blanket kicked into a heap at the foot. On the floor are a cheap alarm clock, a phone on a long charging cable, a mug and a face-down paperback. Now and then the phone lights up with a notification, and the clock\'s colon blinks.' },
    'BED-035': { spec: 'pinebed30', live: 'Sunbeam drifts, bunny ear flops', note: 'A honey-pine platform bed with a plank headboard and a low footboard, a white quilted spring mattress with blue border tape and side vents, a faded blue gingham duvet with the white sheet turned down, two plump pillows and a well-loved plush bunny. A warm sunbeam drifts slowly across the duvet and the bunny\'s ear flops.' },
    'BED-055': { spec: 'lin55', live: 'Sheen glides over the tufting', note: 'A softly rounded upholstered frame in oatmeal linen with a tall button-tufted headboard and piped edges on slim walnut feet, a deep white pillow-top mattress with crisp white sheets, sage linen euro shams leaning on the headboard, two white sleeping pillows, an ochre velvet lumbar cushion with tassels and a sage linen duvet folded across the foot. A warm sheen glides across the tufted headboard and the lumbar\'s tassels sway.' },
    'BED-075': { spec: 'k4p30', live: 'Silk drapes sway and shimmer', note: 'Tall hand-turned solid walnut posts with brass collars and finials, a carved arched walnut headboard with a gilded inlay line and a low footboard, under a canopy of champagne silk valances with a gold bullion fringe and heavy champagne silk drapes at each post held with gold tassel tiebacks. On the bed lie an ivory silk duvet with a turned-down band, four pillows and a bolster, and a gold-thread throw across the foot. The silk drapes sway and a sheen glides across the duvet.' },
    'BED-095': { spec: 'pod95', live: 'Pod floats, light follows the day', note: 'A pearl-white oval sleep pod with a champagne-gold rim, floating above a low pearl plinth on a pool of warm light. Inside are a plush quilted mattress, ivory pillows and a soft blush duvet. A translucent canopy hood arches over the head end, its light strip shifting through the colours of the day, from dawn amber to soft gold to dusk peach. The pod bobs gently and warm air wisps rise from the climate vents round the rim.' },
    'BED-016': { spec: 'ster30', live: 'Caught sock dangles', note: 'A frosted white plastic 3-drawer tower on little casters, colourful clothes blurred behind the drawer fronts. The top drawer is stuck half open and overstuffed, a sock is caught in the middle drawer and dangling out, and a stack of folded T-shirts and a hair tie sit on top. Beside it is a blue plastic laundry basket heaped with clothes, a red sleeve hanging over the edge. The caught sock sways.' },
    'BED-036': { spec: 'pinech30', live: 'Candle flickers, pothos sways', note: 'A honey-pine chest of four graduated drawers with turned wooden knobs, a rounded overhanging top, a shaped plinth and visible knots, the top drawer sticking out a hair. On top are a crocheted doily, a small framed photo, a ceramic trinket dish with a ring, a jar candle and a trailing pothos in a terracotta pot. The candle flickers and the pothos sways.' },
    'BED-056': { spec: 'teak56', live: 'Pampas sways, sheen slides', note: 'A long low teak dresser with book-matched horizontal grain and six drawers in two banks, each with a sculpted recessed finger pull along its top edge, on splayed tapered legs with brass ferrules. On top are a stack of art books, a speckled ceramic vase of dried pampas and bunny tails, and a brass tray with a perfume bottle. The pampas plumes sway and a warm sheen slides along the oiled top.' },
    'BED-076': { spec: 'shag76', live: 'Lamp glows, brass glints', note: 'A long credenza faced in sea-green shagreen, the pebbled ray-skin texture, framed by brushed brass inlay strips: eight drawers in two rows with slim brass bar pulls, a honed stone top with a polished brass edge, on a recessed brass plinth. On top are an alabaster sphere lamp glowing warm, a stack of linen books under a rock crystal, and a black lacquer jewellery tray with a watch and a pearl strand. The lamp glow breathes and glints slide along the brass.' },
    'BED-096': { spec: 'smart96', live: 'Drawer glides open, basin bubbles', note: 'A handle-less dresser in matte ivory lacquer with hairline seams and a slim champagne touch strip, on a floating plinth lit from beneath. A built-in ultrasonic cleaning basin is set into the top: a shallow glass well glowing warm, with rings turning slowly in the shimmering water. One drawer glides open at a touch to show a blush velvet organizer of rings and earrings, then closes again. The basin bubbles and ripples, and the touch strip and under-glow breathe.' },
    'BED-018': { spec: 'pill30', live: 'Loose binding sways, static sparks', note: 'A faded maroon polyester fleece blanket folded sloppily in three, covered in pills and lint, its satin binding frayed and coming loose in a dangling strip, with a flat yellowed pillow sagging on top and a loose thread trailing to the floor. The loose binding sways and a little static spark crackles now and then.' },
    'BED-038': { spec: 'perc30', live: 'Swing tag turns, sheen slides', note: 'A neatly folded set of crisp cotton percale: white duvet cover folds with a navy stitched hem stacked on a soft blue-stripe fitted sheet and pillowcases, wrapped in a kraft paper band with a little swing tag on twine, and two plump down-alternative pillows stacked beside it. The swing tag turns on its string and a sheen slides along the folds.' },
    'BED-058': { spec: 'flax30', live: 'Pom tassel swings, lavender nods', note: 'Stone-washed Belgian flax bedding in clay, oatmeal, sage and natural, softly rumpled with frayed hems and stacked in a low woven seagrass basket with rope handles. A cream chunky-knit throw with fat loops spills over the rim with a pom tassel, and a sprig of dried lavender tied with twine lies on top. The pom swings and the lavender nods.' },
    'BED-078': { spec: 'silk78', live: 'Satin sheen glides', note: 'A lofty ivory goose-down comforter folded into a plump cloud with sewn-through baffle boxes, on a stack of champagne, blush and ivory mulberry silk sheets with a liquid sheen, and a pair of silk pillowcases folded on top with a gold-embroidered monogram tag, all tied round with a wide champagne satin ribbon and bow. A satin sheen glides across the silk folds and the ribbon tails stir.' },
    'BED-098': { spec: 'smartbed30', live: 'Top layer folds itself', note: 'Dove-grey cashmere bedding woven with a faint grid of silver-ion thread, stacked on a slim champagne-gold charging tray. The top layer folds itself: it lifts, turns over and settles with a crisp fold, then unfolds again. A warm-to-cool band of light travels along an embedded thread, the silver grid glints and a small control puck beside it shows a breathing temperature ring.' },
    'BED-019': { spec: 'lap30', live: 'Noodles steam, phone lights up', note: 'A scuffed white plastic lap tray with fold-out legs and a raised lip, doing duty as a desk: a steaming cup of instant noodles with a fork, a spiral notebook with doodles and a pen, a phone propped up beside it, crumbs and a ring stain. Steam curls from the noodles and the phone lights up with a message.' },
    'BED-039': { spec: 'fold39', live: 'Text types out, tea steams', note: 'A small birch-ply folding desk with white steel A-frame legs that fold flat and a slim rail underneath. On it are an open laptop, a mug of tea with the tag hanging out, a pencil cup, a cluster of sticky notes and a little succulent. Lines of text type out on the laptop with a blinking cursor, and the tea steams.' },
    'BED-059': { spec: 'holly59', live: 'Globe bulbs glow, one flickers', note: 'A white lacquer vanity table with a slim centre drawer and gold tapered legs, and a big Hollywood mirror in a white frame ringed with round warm globe bulbs standing at the back. On the table are an acrylic organiser of lipsticks, a pressed-powder palette, a cup of brushes, a glass perfume bottle and a little blush ring dish. The bulbs glow and breathe, one flickers now and then, and a glint slides across the mirror.' },
    'BED-079': { spec: 'exec79', live: 'Lamp glows, page lifts, globe turns', note: 'A twin-pedestal desk in figured walnut with a forest-green leather writing surface tooled in gold leaf, three drawers each side with brass bail pulls and a centre drawer with a brass keyhole, on moulded plinths. On top are a brass banker\'s lamp with a green glass shade, an open leather journal with a ribbon, a fountain pen on its stand, a cut-crystal inkwell and a small brass globe. The lamp glow breathes, the journal\'s page lifts and settles, and the globe slowly turns.' },
    'BED-099': { spec: 'dream99', live: 'Dream journal writes itself', note: 'A curved ivory waterfall desk with a champagne-gold edge and a softly glowing base, a round smart mirror on a slim gold stem that sweeps a warm scan ring over a face outline beside little skin-reading arcs, and a projector puck casting a warm hologram of a dream journal that writes itself while dream symbols drift around it: a crescent moon, a cloud and stars. A rose-quartz roller and three glass serum bottles with gold caps sit on the desk.' },
  };
  const edit29 = RD.edit;
  RD.edit = rows => edit29(rows).map(r => RD.SET30[r.id] ? Object.assign({}, r, RD.SET30[r.id]) : r);
  RD.H30 = { FLOOR30, sun, K };
  RD.PLUS30 = 1;
})();
