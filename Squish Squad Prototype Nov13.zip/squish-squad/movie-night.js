// Movie Night (Renovation Catalog test room + Squad House Movie Room).
// 1) Tap a speaker: it vibrates, hops on the beat, sends out sound rings + music notes and plays a groove.
// 2) Home theater: screen + projector/player + speakers placed = synced (signal links blink together).
//    With 4+ creatures in the room the lights dim, the projector beams and a 10 s app ad plays on the screen,
//    speakers and creatures bounce to its beat. With movies.js loaded the screen plays the
//    movie for its tier instead (pause / resume / pick / resume where you left off; see movies.js).
(function () {
  if (window.MovieNight) return;
  const BEAT = 0.5, DIM = 1.2, AD = 10, UP = 1.2, STEP = BEAT / 4;
  const INK = '#3a1a5c', NOTE = ['\u266A', '\u266B', '\u266C'], NC = ['#ffd66b', '#8fe8ff', '#a6f06a', '#ffb36b', '#c9a6ff'];
  const csrc = k => 'export/tripo/' + k + '/' + k + '-front.svg';
  const cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
  const E = { out: x => 1 - Math.pow(1 - x, 3), back: x => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); } };
  const P = (t, a, b, e = E.out) => e(cl((t - a) / (b - a)));

  // ---------- audio ----------
  const A = { ctx: null, out: null, nb: null }; let CUR = null;
  function ac() {
    if (A.ctx) { if (A.ctx.state === 'suspended') A.ctx.resume(); return A.ctx; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null;
    const c = A.ctx = new AC(), comp = c.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4; comp.connect(c.destination);
    A.out = c.createGain(); A.out.gain.value = 0.5; A.out.connect(comp);
    const n = c.sampleRate, b = c.createBuffer(1, n, n), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; A.nb = b; return c;
  }
  ['pointerdown', 'keydown', 'touchstart'].forEach(ev => window.addEventListener(ev, () => ac(), { capture: true, passive: true }));
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
  function env(g, t, v, at, dur, sus) { g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(Math.max(v, 0.0002), t + at); if (sus) { const h = Math.max(t + at, t + dur * 0.72); g.gain.setValueAtTime(Math.max(v, 0.0002), h); } g.gain.exponentialRampToValueAtTime(0.0001, t + dur); }
  function tone(t, f, dur, o = {}) {
    const c = A.ctx; if (!c) return; const os = c.createOscillator(), g = c.createGain(); os.type = o.type || 'sine'; os.frequency.setValueAtTime(f, t);
    if (o.to) os.frequency.exponentialRampToValueAtTime(o.to, t + (o.slide || dur));
    if (o.vib) { const lf = c.createOscillator(), lg = c.createGain(); lf.frequency.value = o.vib[0]; lg.gain.setValueAtTime(0, t); lg.gain.linearRampToValueAtTime(o.vib[1], t + Math.min(0.35, dur * 0.4)); lf.connect(lg); lg.connect(os.frequency); lf.start(t); lf.stop(t + dur + 0.05); }
    let node = os; if (o.lp) { const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = o.lp; os.connect(lp); node = lp; }
    node.connect(g); g.connect(CUR || A.out); env(g, t, o.vol || 0.2, o.at || 0.005, dur, o.sus); os.start(t); os.stop(t + dur + 0.05);
  }
  function noise(t, dur, o = {}) {
    const c = A.ctx; if (!c) return; const s = c.createBufferSource(); s.buffer = A.nb; const f = c.createBiquadFilter(); f.type = o.ft || 'highpass'; f.frequency.setValueAtTime(o.f || 6000, t);
    if (o.fTo) f.frequency.exponentialRampToValueAtTime(o.fTo, t + dur); f.Q.value = o.q || 0.7; const g = c.createGain(); s.connect(f); f.connect(g); g.connect(CUR || A.out);
    env(g, t, o.vol || 0.1, o.at || 0.002, dur, o.sus); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05);
  }
  const kick = (t, v = 0.9) => tone(t, 150, 0.32, { to: 42, slide: 0.12, vol: v, at: 0.002 });
  const snare = (t, v = 0.32) => { noise(t, 0.16, { ft: 'bandpass', f: 1800, q: 0.8, vol: v }); tone(t, 220, 0.08, { to: 160, vol: v * 0.5, type: 'triangle' }); };
  const hat = (t, v = 0.07) => noise(t, 0.04, { f: 7500, vol: v });
  const bass = (t, m, v = 0.26) => tone(t, mtof(m), 0.2, { type: 'sawtooth', lp: 520, vol: v, at: 0.008 });
  const lead = (t, m, d = 0.18, v = 0.1) => { tone(t, mtof(m), d, { type: 'square', lp: 2600, vol: v, at: 0.006 }); tone(t, mtof(m + 12), d * 0.7, { type: 'triangle', vol: v * 0.4 }); };
  const bell = (t, m, d = 0.5, v = 0.12) => { tone(t, mtof(m), d, { vol: v }); tone(t, mtof(m) * 2.76, d * 0.4, { vol: v * 0.25 }); };
  const chord = (t, ms, d, v = 0.06) => ms.forEach(m => tone(t, mtof(m), d, { type: 'sawtooth', lp: 1800, vol: v, at: 0.01 }));
  const crash = (t, v = 0.18) => noise(t, 1.3, { f: 5000, vol: v });
  const squishS = (t, k) => { tone(t, 280 - k * 10, 0.2, { to: 90, slide: 0.15, vol: 0.5 }); tone(t + 0.04, 520 + k * 80, 0.1, { to: 1100 + k * 120, slide: 0.07, vol: 0.18 }); };
  const PROG = [[36, [60, 64, 67]], [33, [57, 60, 64]], [29, [53, 57, 60]], [31, [55, 59, 62]]];
  const MEL = [76, 0, 79, 0, 81, 79, 76, 0, 74, 0, 76, 72, 0, 74, 76, 0];
  function groove(t, s) {
    const bar = Math.floor(s / 16) % 4, i = s % 16, rt = PROG[bar][0];
    if (i % 4 === 0) kick(t, 0.85); if (bar === 3 && i === 14) kick(t, 0.55);
    if (i === 4 || i === 12) snare(t); if (i % 2 === 1) hat(t, i % 4 === 3 ? 0.09 : 0.05);
    if (i % 2 === 0) bass(t, rt + (i % 8 === 6 ? 12 : 0)); if (i === 0) chord(t, PROG[bar][1], 0.9, 0.03);
    const m = MEL[(i + bar * 5) % 16]; if (m && (bar !== 3 || i < 10)) lead(t, m);
  }

  // ---------- speaker jam ----------
  const K = new Map(), J = { on: false, timer: 0, t0: 0, step: 0, p0: 0, bus: null };
  function startJam() {
    if (J.on || SH) return; J.on = true; J.p0 = performance.now() + 60; J.step = 0; const c = ac();
    if (c) { J.bus = c.createGain(); J.bus.gain.value = J.mute ? 0.0001 : 1; J.bus.connect(A.out); J.t0 = c.currentTime + 0.06;
      const tick = () => { CUR = J.bus; while (J.t0 + J.step * STEP < c.currentTime + 0.2) { groove(J.t0 + J.step * STEP, J.step); J.step++; } CUR = null; };
      tick(); J.timer = setInterval(tick, 40); }
  }
  function stopJam() {
    if (!J.on) return; J.on = false; clearInterval(J.timer);
    const b = J.bus, c = A.ctx; J.bus = null; if (b && c) { b.gain.setTargetAtTime(0.0001, c.currentTime, 0.05); setTimeout(() => { try { b.disconnect(); } catch (e) {} }, 400); }
  }
  function resetEl(el) { if (el) { el.style.transform = ''; el._mnB = undefined; } }
  function toggle(key, get) { if (K.has(key)) { stop(key); return false; } K.set(key, get); startJam(); emit(); loop(); return true; }
  function stop(key) { const g = K.get(key); if (!g) return; const o = g(); if (o) resetEl(o.el); K.delete(key); if (!K.size) stopJam(); emit(); }

  // ---------- theater ----------
  let TH = null, L = null, RM = null, prevReady = false, SH = null, ART = null;
  // focus mode: the movie zooms off the screen to fill the whole view (FZ.p 0..1 = zoom progress)
  const FZ = { on: false, p: 0, last: 0, ctl: 0, gd: 0, box: null }, FZD = 0.75;
  const noProp = n => ['pointerdown', 'pointerup', 'click', 'mousedown', 'touchstart', 'wheel', 'contextmenu'].forEach(ev => n.addEventListener(ev, e => e.stopPropagation()));
  function el(tag, css, parent, txt) { const n = document.createElement(tag); if (css) n.style.cssText = css; if (txt != null) n.textContent = txt; if (parent) parent.appendChild(n); return n; }
  function nodes() {
    if (L._mn) return L._mn; const N = {};
    N.dim = el('div', 'position:absolute;inset:-60px;opacity:0;', L); // bleeds past the layer so the whole view dims (gradient centre is offset by 60 to match)
    N.svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); N.svg.setAttribute('style', 'position:absolute;left:0;top:0;width:100%;height:100%;overflow:visible;'); L.appendChild(N.svg);
    N.svg.innerHTML = '<defs><linearGradient id="mnBeam" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#ffffff" stop-opacity="0.8"></stop><stop offset="1" stop-color="#d6ecff" stop-opacity="0.14"></stop></linearGradient></defs><polygon fill="url(#mnBeam)" opacity="0"></polygon><g></g>';
    N.grad = N.svg.querySelector('linearGradient'); N.beam = N.svg.querySelector('polygon'); N.links = N.svg.querySelector('g');
    N.vh = el('div', 'position:absolute;left:0;top:0;', L);
    N.fb = el('button', 'position:absolute;left:0;top:0;width:34px;height:34px;border-radius:50%;border:2px solid #8a6420;background:#e2b14a;color:#3a1a5c;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;pointer-events:none;opacity:0;transform:scale(0.6);transition:opacity .25s ease, transform .25s cubic-bezier(.3,1.6,.5,1);box-shadow:0 3px 0 rgba(90,58,30,0.35), 0 0 0 3px rgba(255,236,170,0.3);z-index:4;', L);
    N.fb.innerHTML = ICON.full; N.fb.title = 'Watch full screen'; N.fb.setAttribute('aria-label', 'Watch full screen'); noProp(N.fb); N.fb.onclick = () => focus(true);
    L._mn = N; mkUI(N); return N;
  }
  function ovl(N) { if (N.ov) return N.ov;
    const ov = N.ov = el('div', 'position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:2147483000;display:none;pointer-events:auto;overflow:hidden;', document.body);
    N.bd = el('div', 'position:absolute;inset:0;background:rgba(0,0,0,0);', ov); N.fv = el('div', 'position:absolute;left:0;top:0;', ov);
    N.gl = el('div', 'position:absolute;left:0;top:0;width:0;height:0;pointer-events:none;opacity:0;background:linear-gradient(105deg,rgba(255,255,255,0) 40%,rgba(255,255,255,0.3) 50%,rgba(255,255,255,0) 60%);background-size:300% 100%;background-repeat:no-repeat;', ov);
    N.xb = el('button', 'position:absolute;top:22px;right:28px;width:40px;height:40px;border-radius:50%;border:2px solid #8a6420;background:#e2b14a;color:#3a1a5c;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;opacity:0;transition:opacity .3s ease;box-shadow:0 3px 0 rgba(0,0,0,0.45);', ov);
    N.xb.innerHTML = ICON.shrink; N.xb.title = 'Back to the room'; N.xb.setAttribute('aria-label', 'Back to the room'); N.xb.onclick = () => focus(false);
    noProp(ov); ['pointermove', 'pointerdown'].forEach(ev => ov.addEventListener(ev, () => { FZ.ctl = performance.now(); }));
    return ov; }
  function focus(on) { const N = L && L._mn; if (!N) return; on = !!on; if (on && (!SH || !TH || !TH.screen)) return; if (on === FZ.on) return;
    FZ.on = on; FZ.last = FZ.ctl = performance.now();
    fsApi(on);
    if (on) { const ov = ovl(N); ov.style.display = 'block'; ov.style.opacity = '1'; FZ.gd = 0; N.gl.style.opacity = '0'; N.fv.appendChild(SH.vid.root); ov.appendChild(N.ui); N.ui.style.transition = 'opacity .3s ease'; N.fb.style.opacity = '0'; N.fb.style.pointerEvents = 'none'; menu(false); }
    const c = A.ctx; if (c) { const t = c.currentTime; noise(t, 0.5, { ft: 'bandpass', f: on ? 500 : 2600, fTo: on ? 3000 : 420, q: 1.1, vol: 0.05, at: 0.22 }); }
    emit(); loop(); }
  // real full screen when the browser allows it (falls back to the fixed overlay covering the whole page)
  function fsApi(on) { try { const d = document, cur = d.fullscreenElement || d.webkitFullscreenElement;
    if (on && !cur) { const r = d.documentElement, f = r.requestFullscreen || r.webkitRequestFullscreen; if (f) { const p = f.call(r); if (p && p.catch) p.catch(() => {}); } }
    else if (!on && cur) { const f = d.exitFullscreen || d.webkitExitFullscreen; if (f) { const p = f.call(d); if (p && p.catch) p.catch(() => {}); } } } catch (e) {} }
  ['fullscreenchange', 'webkitfullscreenchange'].forEach(ev => document.addEventListener(ev, () => { if (!(document.fullscreenElement || document.webkitFullscreenElement) && FZ.on && performance.now() - FZ.last > 400) focus(false); }));
  function fzOff(N) { if (N.ov) { N.ov.style.display = 'none'; N.ov.style.opacity = '1'; } if (SH && SH.vid.root.parentNode !== N.vh) N.vh.appendChild(SH.vid.root);
    if (N.ui.parentNode !== L) L.appendChild(N.ui); N.ui.style.opacity = ''; N.ui.style.pointerEvents = 'auto'; N.ui.style.transition = ''; }
  function fzEnd(N) { const was = N.ov && N.ov.style.display !== 'none'; FZ.on = false; FZ.p = 0; if (N.ui.parentNode !== L) L.appendChild(N.ui); N.ui.style.opacity = ''; N.ui.style.pointerEvents = 'auto'; N.ui.style.transition = '';
    if (was) N.ov.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 450, easing: 'ease-out' }).onfinish = () => { if (!FZ.on) fzOff(N); }; }
  const bk = x => 1 + 2 * Math.pow(x - 1, 3) + Math.pow(x - 1, 2);
  function fzStep(N, now) {
    if (!FZ.on && FZ.p === 0) { if (N.ov && N.ov.style.display !== 'none') fzOff(N); return 0; }
    const dt = Math.min(0.1, Math.max(0, (now - (FZ.last || now)) / 1000)); FZ.last = now; FZ.p = cl(FZ.p + (FZ.on ? dt : -dt) / FZD);
    if (!FZ.on && FZ.p === 0) { fzOff(N); return 0; }
    const p = FZ.p, e = bk(p * p * (3 - 2 * p));
    N.bd.style.background = 'rgba(0,0,0,' + cl(p * 1.4).toFixed(3) + ')'; N.bd.style.backdropFilter = N.bd.style.webkitBackdropFilter = 'blur(' + (10 * p).toFixed(1) + 'px)';
    const show = FZ.on && p > 0.85 && (now - FZ.ctl < 2600 || (SH && SH.pause) || N.menu.style.display !== 'none'), op = show ? '1' : '0';
    if (N.xb.style.opacity !== op) { N.xb.style.opacity = op; N.ui.style.opacity = op; N.xb.style.pointerEvents = N.ui.style.pointerEvents = show ? 'auto' : 'none'; N.ov.style.cursor = show || !FZ.on ? '' : 'none'; }
    if (FZ.on && p === 1 && !FZ.gd && FZ.box) { FZ.gd = 1; const b = FZ.box; Object.assign(N.gl.style, { left: b[0] + 'px', top: b[1] + 'px', width: b[2] + 'px', height: b[3] + 'px' });
      N.gl.animate([{ opacity: 0, backgroundPosition: '100% 0' }, { opacity: 1, offset: 0.2 }, { opacity: 0, backgroundPosition: '0% 0' }], { duration: 950, easing: 'ease-out' }); }
    return e; }
  function theater(layer, room, info, art) {
    if (art) ART = art;
    if (!layer || !info) { if (SH) { SH.done = true; stopShow(); } ML().forEach(m => lsS('mn.pos.' + m.id, null)); if (L && L._mn) { L._mn.links.innerHTML = ''; } TH = null; L = layer || null; RM = room || null; prevReady = false; return; }
    L = layer; RM = room; TH = info; nodes();
    if (SH && !info.ready) stopShow();
    if (info.ready && !prevReady && !SH) play();
    prevReady = info.ready; loop();
  }
  function centerOf(u, fy) { const n = RM && RM.querySelector('[data-u="' + u + '"]'); if (!n) return null; return [n.offsetLeft + n.offsetWidth / 2, n.offsetTop + n.offsetHeight * (fy == null ? 0.5 : fy)]; }
  function quad(sc) { const m = sc.m; return [[0, 0], [sc.w, 0], [sc.w, sc.h], [0, sc.h]].map(([x, y]) => [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]]); }
  function hull(pts) { const p = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]), cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]), lo = [], up = [];
    p.forEach(q => { while (lo.length > 1 && cr(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); });
    p.slice().reverse().forEach(q => { while (up.length > 1 && cr(up[up.length - 2], up[up.length - 1], q) <= 0) up.pop(); up.push(q); }); return lo.slice(0, -1).concat(up.slice(0, -1)); }

  // ---------- movies (movies.js): picked by screen tier, pause / resume / resume-where-you-left-off ----------
  const ML = () => (window.SquadMovies && window.SquadMovies.list) || [], AdMv = { id: 'ad', tier: 0, title: 'Squish Squad trailer', dur: AD, ad: true };
  const lsG = k => { try { return localStorage.getItem(k); } catch (e) { return null; } }, lsS = (k, v) => { try { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, String(v)); } catch (e) {} };
  const fmt = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
  let REACT = null, CAST = [];
  function unlocked() { const tr = (TH && TH.tier) || 1; return ML().filter(m => m.mk && m.tier <= tr); }
  function pickMv(id) { const A = unlocked(); if (!A.length) return AdMv; const w = id || lsG('mn.pick'); return A.find(m => m.id === w) || A[A.length - 1]; }
  function mkFilm(mv) {
    const root = el('div', 'position:absolute;left:0;top:0;transform-origin:0 0;overflow:hidden;background:#05030a;border-radius:1px;');
    const st = el('div', 'position:absolute;left:0;top:0;width:320px;height:180px;transform-origin:0 0;overflow:hidden;', root);
    const F = mv.mk(ART || {}); st.appendChild(F.root); const LK = window.SquadMovies.look((TH && TH.tier) || 1, st, F.root);
    return { root, st, upd: t => { const o = F.upd(t); LK.upd(performance.now()); return o; } };
  }
  function mkBus(c, mv) { const g = c.createGain(); if (mv.old) { const hp = c.createBiquadFilter(), lp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 180; lp.type = 'lowpass'; lp.frequency.value = 3400; g.connect(hp); hp.connect(lp); lp.connect(A.out); g._ch = [hp, lp]; } else g.connect(A.out); return g; }
  function killBus(b) { const c = A.ctx; if (!b || !c) return; b.gain.setTargetAtTime(0.0001, c.currentTime, 0.06); setTimeout(() => { try { b.disconnect(); (b._ch || []).forEach(n => n.disconnect()); } catch (e) {} }, 600); }
  function idxOf(mv, t) { if (mv.ad) return 0; const R = window.SquadMovies.record(mv); let i = 0; while (i < R.length && R[i][0] < t - 0.001) i++; return i; }
  function savePos(s) { if (!s || s.mv.ad) return; const m = s.mt; lsS('mn.pos.' + s.mv.id, !s.done && m > 2 && m < s.mv.dur - 3 ? m.toFixed(1) : null); }
  function play(id) {
    if (!TH || !TH.synced || !L) return; const mv = pickMv(id); if (SH) stopShow(true); stopJam();
    if (!mv.ad) lsS('mn.pick', mv.id);
    let pos = mv.ad ? 0 : +(lsG('mn.pos.' + mv.id) || 0); if (!(pos > 2 && pos < mv.dur - 3)) pos = 0;
    const c = ac(), N = nodes();
    SH = { mv, vid: mv.ad ? mkVideo(ART || {}) : mkFilm(mv), mt: pos - DIM, age: 0, pause: false, last: performance.now(), done: false, endA: 0, bus: null, ei: 0, a0: 0, sv: -1, msg: pos ? 'Resuming at ' + fmt(pos) : '', msgT: 3 };
    (FZ.on && N.fv ? N.fv : N.vh).appendChild(SH.vid.root);
    if (c) { SH.bus = mkBus(c, mv); CUR = SH.bus; const t = c.currentTime;
      noise(t, 1.1, { ft: 'lowpass', f: 1400, fTo: 160, vol: 0.06, at: 0.3 }); noise(t + DIM - 0.18, 0.03, { ft: 'bandpass', f: 3200, q: 2, vol: 0.25 });
      if (mv.ad) adAudio(t + DIM); CUR = null; SH.a0 = t - SH.mt; SH.ei = idxOf(mv, pos); }
    menu(false); emit(); loop();
  }
  function setPause(p) { if (!SH || SH.done || SH.pause === !!p) return; SH.pause = !!p; const c = A.ctx;
    if (p) { killBus(SH.bus); SH.bus = null; savePos(SH); }
    else { SH.last = performance.now(); if (c && !SH.mv.ad) { ac(); SH.bus = mkBus(c, SH.mv); SH.a0 = c.currentTime - SH.mt; SH.ei = idxOf(SH.mv, Math.max(0, SH.mt)); } }
    emit(); loop(); }
  function sched(s) { const c = A.ctx, R = window.SquadMovies.record(s.mv);
    if (c.state !== 'running') { while (s.ei < R.length && R[s.ei][0] < s.mt) s.ei++; s.a0 = c.currentTime - s.mt; return; }
    if (Math.abs(c.currentTime - s.a0 - s.mt) > 0.12) s.a0 = c.currentTime - s.mt;
    const ah = s.mt + 0.3; CUR = s.bus;
    while (s.ei < R.length && R[s.ei][0] < ah) { const r = R[s.ei++], w = s.a0 + r[0]; if (w < c.currentTime - 0.05) continue; const at = Math.max(w, c.currentTime); if (r[1] === 't') tone(at, r[2], r[3], r[4]); else noise(at, r[2], r[3]); }
    CUR = null; }
  function cues(m0, m1) { const C = SH && SH.mv.cues; if (!C || m1 - m0 > 1) return; C.forEach(([t, k, a1, a2]) => { if (t > m0 && t <= m1) { if (k === 'confetti') confetti(); else if (k === 'pop') popOut(a1, a2); else if (REACT) { try { REACT(k); } catch (e) {} } } }); }
  // holo finale: confetti bursts out of the screen and floats down over the room
  // holo pop-out: a star leaps out of the top of the screen over the room, flips and dives back in (movie shows the leap + return)
  function popOut(key, x) { const sc = TH && TH.screen; if (!sc || !L || FZ.on || !key) return; const q = quad(sc), u = Math.max(0, Math.min(1, (x == null ? 160 : x) / 320)), px = q[0][0] + (q[1][0] - q[0][0]) * u, py = q[0][1] + (q[1][1] - q[0][1]) * u;
    const hs = Math.hypot(q[3][0] - q[0][0], q[3][1] - q[0][1]), sz = Math.max(40, hs * 0.8), cx = (q[0][0] + q[2][0]) / 2, dx = (cx - px) * 0.25, f = v => v.toFixed(0);
    const im = el('img', 'position:absolute;left:' + f(px - sz / 2) + 'px;top:' + f(py - sz * 0.94) + 'px;width:' + f(sz) + 'px;height:' + f(sz) + 'px;transform-origin:50% 94%;pointer-events:none;opacity:0;filter:drop-shadow(0 0 3px rgba(150,240,255,0.95)) drop-shadow(0 8px 6px rgba(0,0,0,0.35));', L);
    im.alt = ''; im.onerror = () => im.remove(); im.src = 'export/tripo/' + key + '/' + key + '-front.svg';
    im.animate([{ transform: 'translate(0px,' + f(sz * 0.55) + 'px) scale(0.45)', opacity: 0 }, { transform: 'translate(' + f(dx * 0.3) + 'px,' + f(-sz * 0.2) + 'px) scale(1.05) rotate(-8deg)', opacity: 1, offset: 0.18, easing: 'ease-out' },
      { transform: 'translate(' + f(dx * 0.7) + 'px,' + f(-sz * 0.42) + 'px) scale(1.15) rotate(8deg)', opacity: 1, offset: 0.5 }, { transform: 'translate(' + f(dx) + 'px,' + f(-sz * 0.3) + 'px) scale(1.08) rotate(-3deg)', opacity: 1, offset: 0.78, easing: 'ease-in' },
      { transform: 'translate(' + f(dx * 0.4) + 'px,' + f(sz * 0.7) + 'px) scale(0.5)', opacity: 0 }], { duration: 1650, delay: 380, easing: 'ease-in-out', fill: 'both' }).onfinish = () => im.remove();
    [380, 1880].forEach(dl => { const rg = el('div', 'position:absolute;left:' + f(px - sz * 0.4) + 'px;top:' + f(py - sz * 0.08) + 'px;width:' + f(sz * 0.8) + 'px;height:' + f(sz * 0.16) + 'px;border-radius:50%;border:2px solid rgba(160,240,255,0.95);box-sizing:border-box;box-shadow:0 0 10px rgba(140,230,255,0.8);pointer-events:none;opacity:0;', L);
      rg.animate([{ transform: 'scale(0.3)', opacity: 0.95 }, { transform: 'scale(1.6)', opacity: 0 }], { duration: 700, delay: dl, easing: 'ease-out', fill: 'both' }).onfinish = () => rg.remove(); });
    const C = ['#ffffff', '#a6f4ff', '#ffd66b', '#ff8fb8']; for (let i = 0; i < 14; i++) { const p = el('div', 'position:absolute;left:' + f(px) + 'px;top:' + f(py) + 'px;width:4px;height:4px;border-radius:50%;background:' + C[i % 4] + ';box-shadow:0 0 4px ' + C[i % 4] + ';pointer-events:none;opacity:0;', L), a = Math.PI + Math.random() * Math.PI, sp = sz * (0.3 + Math.random() * 0.5);
      p.animate([{ transform: 'translate(0,0) scale(1)', opacity: 1 }, { transform: 'translate(' + f(Math.cos(a) * sp) + 'px,' + f(Math.sin(a) * sp * 0.8) + 'px) scale(0.3)', opacity: 0 }], { duration: 600 + Math.random() * 300, delay: 400, easing: 'ease-out', fill: 'both' }).onfinish = () => p.remove(); } }
  function confetti() { const sc = TH && TH.screen; if (!sc || !L) return; const q = quad(sc), cx = (q[0][0] + q[2][0]) / 2, cy = (q[0][1] + q[2][1]) / 2, H = L.offsetHeight || 393, C = ['#ffd66b', '#ff8fb8', '#8fe8ff', '#a6f06a', '#c9a6ff', '#ffb36b'];
    for (let i = 0; i < 70; i++) { const w = 4 + Math.random() * 5, p = el('div', 'position:absolute;left:' + cx.toFixed(0) + 'px;top:' + cy.toFixed(0) + 'px;width:' + w.toFixed(1) + 'px;height:' + (w * 0.55).toFixed(1) + 'px;border-radius:1px;background:' + C[i % 6] + ';pointer-events:none;', L);
      const a = Math.random() * Math.PI * 2, sp = 80 + Math.random() * 260, dx = Math.cos(a) * sp, up = -Math.abs(Math.sin(a)) * sp * 0.6 - 40, fall = H - cy + 40, d = 2600 + Math.random() * 2200, r = (Math.random() - 0.5) * 1400;
      p.animate([{ transform: 'translate(0,0) rotate(0deg)', opacity: 1 }, { transform: 'translate(' + (dx * 0.7).toFixed(0) + 'px,' + up.toFixed(0) + 'px) rotate(' + (r * 0.3).toFixed(0) + 'deg)', opacity: 1, offset: 0.25 }, { transform: 'translate(' + (dx + Math.sin(a * 5) * 30).toFixed(0) + 'px,' + fall.toFixed(0) + 'px) rotate(' + r.toFixed(0) + 'deg)', opacity: 0.85 }], { duration: d, easing: 'cubic-bezier(.2,.6,.4,1)' }).onfinish = () => p.remove(); } }
  function stopShow(keep) {
    if (!SH) return; const s = SH; savePos(s); SH = null; killBus(s.bus);
    if (s.vid.root.parentNode) s.vid.root.parentNode.removeChild(s.vid.root);
    if (L && L._mn) { const N = L._mn; N.dim.style.opacity = '0'; N.beam.setAttribute('opacity', '0'); N.fb.style.opacity = '0'; N.fb.style.pointerEvents = 'none'; if (keep !== true) fzEnd(N); }
    if (RM) RM.querySelectorAll('[data-kind="spk"],[data-kind="crew"]').forEach(n => resetEl(n.firstElementChild));
    menu(false); uiUpd(); if (REACT) { try { REACT('end'); } catch (e) {} }
    if (K.size) startJam(); emit(); loop();
  }
  // ---------- player controls (bottom of the room while a movie is on) ----------
  const ICON = { pause: '<svg viewBox="0 0 16 16" width="14" height="14"><rect x="3" y="2" width="3.6" height="12" rx="1.2" fill="currentColor"></rect><rect x="9.4" y="2" width="3.6" height="12" rx="1.2" fill="currentColor"></rect></svg>',
    play: '<svg viewBox="0 0 16 16" width="14" height="14"><path d="M4.5 2.5 L13.5 8 L4.5 13.5Z" fill="currentColor" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"></path></svg>',
    list: '<svg viewBox="0 0 16 16" width="15" height="15"><path d="M3 4h10M3 8h10M3 12h10" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path></svg>',
    skip: '<svg viewBox="0 0 16 16" width="14" height="14"><path d="M2.5 3 L8 8 L2.5 13Z M7.5 3 L13 8 L7.5 13Z" fill="currentColor" stroke="currentColor" stroke-width="1" stroke-linejoin="round"></path><rect x="12.6" y="3" width="2" height="10" rx="0.8" fill="currentColor"></rect></svg>',
    full: '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 6.2V2.5h3.7M9.8 2.5h3.7v3.7M13.5 9.8v3.7H9.8M6.2 13.5H2.5V9.8"></path></svg>',
    shrink: '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2.5V6H2.5M13.5 6H10V2.5M10 13.5V10h3.5M2.5 10H6v3.5"></path></svg>' };
  function mkUI(N) {
    const u = N.ui = el('div', "position:absolute;left:50%;bottom:12px;transform:translateX(-50%);display:none;align-items:center;gap:8px;padding:5px 6px;border-radius:999px;background:#f6ead2;border:2px solid #c9ad86;box-shadow:0 3px 0 rgba(90,58,30,0.28);pointer-events:auto;font-family:'Fredoka',sans-serif;font-weight:600;color:#5a3a1e;user-select:none;-webkit-user-select:none;z-index:5;", L);
    ['pointerdown', 'pointerup', 'click', 'mousedown', 'touchstart', 'wheel'].forEach(ev => u.addEventListener(ev, e => e.stopPropagation()));
    const B = (ic, tip, main) => { const b = el('button', 'width:34px;height:34px;border-radius:50%;border:2px solid ' + (main ? '#8a6420' : '#c9ad86') + ';background:' + (main ? '#e2b14a' : '#fbf3e3') + ';color:#3a1a5c;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;flex:none;', u); b.innerHTML = ICON[ic]; b._ic = ic; b.title = tip; return b; };
    N.pp = B('pause', 'Pause', true);
    const mid = el('div', 'display:flex;flex-direction:column;gap:4px;width:180px;', u), row = el('div', 'display:flex;align-items:baseline;justify-content:space-between;gap:6px;', mid);
    N.ttl = el('div', 'font-size:12px;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;', row);
    N.tm = el('div', 'font-size:10.5px;line-height:1.15;white-space:nowrap;font-variant-numeric:tabular-nums;color:#8a5a2e;flex:none;', row);
    const bar = el('div', 'height:7px;border-radius:99px;background:#e2cfa8;overflow:hidden;', mid); N.fill = el('div', 'height:100%;width:0;border-radius:99px;background:#8a6420;', bar);
    N.ls = B('list', 'Pick a movie'); N.fs = B('full', 'Watch full screen'); N.sk = B('skip', 'End the movie');
    N.fs.onclick = () => focus(!FZ.on);
    N.menu = el('div', 'position:absolute;right:0;bottom:48px;width:270px;display:none;flex-direction:column;gap:3px;padding:8px;border-radius:18px;background:#fbf3e3;border:2px solid #c9ad86;box-shadow:0 4px 0 rgba(90,58,30,0.25);', u);
    N.pp.onclick = () => { if (SH) setPause(!SH.pause); }; N.sk.onclick = () => { if (SH) stopShow(); }; N.ls.onclick = () => menu(N.menu.style.display === 'none');
  }
  function menu(on) { const N = L && L._mn; if (!N || !N.menu) return; if (!on) { N.menu.style.display = 'none'; return; } N.menu.innerHTML = '';
    el('div', 'font-size:12px;color:#8a5a2e;padding:2px 6px 3px;', N.menu, 'Movies');
    const tr = (TH && TH.tier) || 1;
    ML().forEach(m => { const ok = !!m.mk && m.tier <= tr, cur = !!(SH && SH.mv.id === m.id), rs = +(lsG('mn.pos.' + m.id) || 0) > 2;
      const sub = m.tier > tr ? 'Needs a tier ' + m.tier + ' screen' : !m.mk ? 'Unlocked \u00b7 movie coming soon' : cur ? 'Now showing' : Math.round(m.dur / 60) + ' min' + (rs ? ' \u00b7 resumes where you left off' : '');
      const b = el('button', "display:flex;align-items:center;gap:8px;text-align:left;padding:6px 9px;min-height:42px;border-radius:12px;border:2px solid " + (cur ? '#8a6420' : 'transparent') + ';background:' + (cur ? '#f3dca6' : ok ? '#ffffff' : 'transparent') + ';cursor:' + (ok && !cur ? 'pointer' : 'default') + ";font-family:'Fredoka',sans-serif;color:" + (ok ? '#3a1a5c' : '#9a8262') + ';', N.menu);
      el('div', 'width:22px;height:22px;border-radius:50%;flex:none;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;background:' + (ok ? '#e2b14a' : '#eadcc2') + ';color:#3a1a5c;', b, String(m.tier));
      const tx = el('div', 'display:flex;flex-direction:column;gap:1px;min-width:0;', b); el('div', 'font-size:12.5px;font-weight:600;line-height:1.15;', tx, m.title); el('div', 'font-size:10.5px;font-weight:500;line-height:1.15;color:' + (ok ? '#8a5a2e' : '#a8916f') + ';', tx, sub);
      if (ok && !cur) b.onclick = () => { menu(false); play(m.id); }; });
    N.menu.style.display = 'flex'; }
  function uiUpd() { const N = L && L._mn; if (!N || !N.ui) return; const on = !!SH, d = on ? 'flex' : 'none'; if (N.ui.style.display !== d) N.ui.style.display = d; if (!on) return;
    { const fr = L.getBoundingClientRect(), rr = RM ? RM.getBoundingClientRect() : fr, k = fr.height ? L.offsetHeight / fr.height : 1, top = (N.ui.parentNode !== L ? window.innerHeight - 70 : (rr.bottom - fr.top) * k - 104).toFixed(0) + 'px'; if (N.ui.style.top !== top) { N.ui.style.top = top; N.ui.style.bottom = 'auto'; } }
    { const fi = FZ.on ? 'shrink' : 'full'; if (N.fs && N.fs._ic !== fi) { N.fs._ic = fi; N.fs.innerHTML = ICON[fi]; N.fs.title = FZ.on ? 'Back to the room' : 'Watch full screen'; } }
    const mv = SH.mv, m = Math.max(0, Math.min(mv.dur, SH.mt)), ttl = SH.msgT > 0 && SH.msg ? SH.msg : mv.title, tm = fmt(m) + ' / ' + fmt(mv.dur), ic = SH.pause ? 'play' : 'pause';
    if (N.ttl.textContent !== ttl) N.ttl.textContent = ttl; if (N.tm.textContent !== tm) N.tm.textContent = tm; N.fill.style.width = (100 * m / mv.dur).toFixed(2) + '%';
    if (N.pp._ic !== ic) { N.pp._ic = ic; N.pp.innerHTML = ICON[ic]; N.pp.title = SH.pause ? 'Play' : 'Pause'; } }
  function adAudio(t0) {
    noise(t0, 0.5, { ft: 'bandpass', f: 400, fTo: 5000, q: 1.2, vol: 0.12, at: 0.4 });
    tone(t0 - 0.3, 58, 10.8, { vol: 0.02, at: 0.3 });
    kick(t0 + 0.5, 1); crash(t0 + 0.5); chord(t0 + 0.5, [60, 64, 67, 72], 0.9);
    [84, 88, 91, 96].forEach((m, i) => bell(t0 + 0.62 + i * 0.06, m, 0.6, 0.06)); kick(t0 + 1, 0.6); kick(t0 + 1.5, 0.6); hat(t0 + 1.25); hat(t0 + 1.75);
    for (let s = 0; s < 52; s++) groove(t0 + 2 + s * STEP, s);
    [2.5, 3, 3.5, 4].forEach((x, k) => squishS(t0 + x, k));
    [72, 74, 76, 79, 81, 84].forEach((m, i) => bell(t0 + 4.6 + 0.16 * i, m, 0.4, 0.14));
    tone(t0 + 7, 180, 0.4, { to: 420, slide: 0.25, vol: 0.2, type: 'triangle' });
    kick(t0 + 8.5, 1); crash(t0 + 8.5); chord(t0 + 8.5, [60, 64, 67, 72], 1.3);
    [72, 76, 79, 84, 88].forEach((m, i) => lead(t0 + 8.6 + i * 0.1, m, 0.25, 0.1));
    kick(t0 + 9, 0.7); snare(t0 + 9.25, 0.25); kick(t0 + 9.5, 0.9); chord(t0 + 9.5, [48, 55, 60, 64, 67, 72], 1.2, 0.045);
    [96, 100, 103, 108].forEach((m, i) => bell(t0 + 9.6 + i * 0.05, m, 0.7, 0.05));
  }

  // ---------- the 10 s ad (320 x 180 stage, fitted onto the screen quad) ----------
  const OUT = (c, w) => [[w, 0], [-w, 0], [0, w], [0, -w], [w * 0.7, w * 0.7], [-w * 0.7, w * 0.7], [w * 0.7, -w * 0.7], [-w * 0.7, -w * 0.7]].map(([x, y]) => x + 'px ' + y + 'px 0 ' + c).join(',') + ',0 ' + (w + 1.5) + 'px 0 ' + c;
  function mkVideo(art) {
    const root = el('div', 'position:absolute;left:0;top:0;transform-origin:0 0;overflow:hidden;background:#05030a;border-radius:1px;');
    const st = el('div', "position:absolute;left:0;top:0;width:320px;height:180px;transform-origin:0 0;overflow:hidden;font-family:'Fredoka',sans-serif;font-weight:700;", root);
    const bg = el('div', 'position:absolute;inset:0;', st);
    const rays = el('div', 'position:absolute;left:-40px;top:-110px;width:400px;height:400px;', st);
    rays.innerHTML = '<svg viewBox="-200 -200 400 400" width="400" height="400">' + Array.from({ length: 12 }, (_, i) => { const a = i / 12 * Math.PI * 2, b = a + Math.PI / 12; return '<path d="M0 0L' + (Math.cos(a) * 260).toFixed(1) + ' ' + (Math.sin(a) * 260).toFixed(1) + 'L' + (Math.cos(b) * 260).toFixed(1) + ' ' + (Math.sin(b) * 260).toFixed(1) + 'Z" fill="#ffffff"></path>'; }).join('') + '</svg>';
    const sc = [0, 1, 2, 3, 4].map(() => el('div', 'position:absolute;inset:0;display:none;', st));
    const T = (p, s, size, col, sh, extra) => el('div', 'position:absolute;left:0;top:0;white-space:nowrap;line-height:1;font-size:' + size + 'px;color:' + col + ';text-shadow:' + sh + ';' + (extra || ''), p, s);
    const I = (p, k, w) => { const n = el('img', 'position:absolute;left:0;top:0;width:' + w + 'px;height:' + w + 'px;transform-origin:50% 94%;filter:drop-shadow(0 4px 4px rgba(20,8,40,0.35));', p); n.src = csrc(k); n.alt = ''; n._w = w; return n; };
    const put = (n, x, y, k = 1, r = 0, o = 1) => { n.style.transform = 'translate(' + x + 'px,' + y + 'px) translate(-50%,-50%) rotate(' + r + 'deg) scale(' + k + ')'; n.style.opacity = o; };
    const foot = (n, x, y, sx = 1, sy = 1, r = 0, o = 1) => { const w = n._w; n.style.transform = 'translate(' + (x - w / 2) + 'px,' + (y - w * 0.94) + 'px) rotate(' + r + 'deg) scale(' + sx + ',' + sy + ')'; n.style.opacity = o; };
    const star = (p, c) => T(p, '\u2726', 14, c || '#fff', '0 0 6px rgba(255,255,255,0.8)');
    const V = {};
    // A: logo slam
    V.a1 = T(sc[0], 'SQUISH', 54, '#ffd66b', OUT(INK, 3)); V.a2 = T(sc[0], 'SQUAD', 46, '#ffffff', OUT(INK, 3));
    V.ap = [I(sc[0], 'mittens', 78), I(sc[0], 'pip', 72)]; V.as = [0, 1, 2, 3].map(() => star(sc[0]));
    // B: squish
    V.bc = T(sc[1], 'SQUISH THEM!', 22, '#ffffff', OUT(INK, 2.5)); V.br = el('div', 'position:absolute;left:0;top:0;width:100px;height:100px;border-radius:50%;border:3px solid #ffffff;box-sizing:border-box;', sc[1]);
    V.bm = I(sc[1], 'mittens', 128); V.bw = T(sc[1], 'SQUISH!', 28, '#ffd66b', OUT(INK, 2.5)); V.bx = T(sc[1], 'COMBO x1', 18, '#a6f06a', OUT(INK, 2));
    // C: collect
    V.cc = T(sc[2], 'COLLECT THEM ALL!', 21, INK, OUT('#ffffff', 2.5)); V.ck = ['mochi', 'boba', 'kiwi', 'floof', 'gumdrop', 'mallow'].map(k => I(sc[2], k, 58)); V.cs = V.ck.map(() => star(sc[2], '#fff8d0'));
    // D: home
    V.dc = T(sc[3], 'BUILD YOUR SQUAD HOUSE', 19, '#ffffff', OUT(INK, 2.5)); const so = art.sofa;
    if (so && so.src) { V.ds = el('img', 'position:absolute;left:0;top:0;transform-origin:50% 100%;filter:drop-shadow(0 5px 5px rgba(0,30,30,0.35));', sc[3]); V.ds.src = so.src; V.ds.alt = ''; }
    V.dk = ['pip', 'mittens', 'boba'].map(k => I(sc[3], k, 60));
    // E: end card
    V.e1 = T(sc[4], 'SQUISH SQUAD', 38, '#ffd66b', OUT(INK, 3)); V.e2 = T(sc[4], 'FREE TO PLAY', 13, '#ffffff', OUT(INK, 1.5), 'letter-spacing:2px;');
    V.eb = el('div', "position:absolute;left:0;top:0;width:132px;height:36px;border-radius:999px;border:3px solid #ffffff;box-sizing:border-box;background:linear-gradient(#ffe27a,#f5b02a);box-shadow:0 4px 0 " + INK + ";display:flex;align-items:center;justify-content:center;font-size:17px;color:" + INK + ";", sc[4], 'PLAY NOW');
    V.ek = [I(sc[4], 'mittens', 88), I(sc[4], 'boba', 84)]; V.es = [0, 1, 2].map(() => star(sc[4]));
    const leader = T(st, 'NOW SHOWING', 16, '#ffffff', 'none', 'letter-spacing:3px;'), flash = el('div', 'position:absolute;inset:0;background:#ffffff;opacity:0;', st), blk = el('div', 'position:absolute;inset:0;background:#05030a;opacity:0;', st);
    const BG = ['radial-gradient(circle at 50% 45%, #8a4ad8, #2a0f4f 75%)', 'radial-gradient(circle at 50% 55%, #5a74ee, #1d2a7a 78%)', 'radial-gradient(circle at 50% 60%, #ffe58a, #f59a2a 80%)', 'radial-gradient(circle at 50% 60%, #5fe0c8, #0f6a6a 80%)', 'radial-gradient(circle at 50% 45%, #8a4ad8, #2a0f4f 75%)'];
    const SPILL = ['155,92,240', '90,116,238', '255,207,74', '63,208,184', '155,92,240'];
    const press = (t, list) => { let last = null; list.forEach(p => { if (t >= p) last = p; }); if (last === null) return { sq: 0, n: 0, d: 99 }; const d = t - last, n = list.filter(p => t >= p).length;
      return { sq: d < 0.08 ? d / 0.08 : d < 0.15 ? 1 : Math.max(0, Math.cos((d - 0.15) * 14) * Math.exp(-(d - 0.15) * 7)), n, d }; };
    function upd(t) {
      const si = t < 2 ? 0 : t < 4.5 ? 1 : t < 7 ? 2 : t < 8.5 ? 3 : 4, ph = ((t % BEAT) + BEAT) % BEAT / BEAT, bn = Math.floor(t / BEAT), bp = Math.exp(-ph * 5), hop = Math.sin(Math.PI * ph);
      sc.forEach((s, i) => { s.style.display = t >= 0 && i === si ? 'block' : 'none'; });
      bg.style.background = t < 0 ? '#05030a' : BG[si]; bg.style.opacity = si === 0 ? P(t, 0, 0.4) : 1;
      rays.style.display = t >= 0 && (si === 0 || si === 4) ? 'block' : 'none'; rays.style.opacity = 0.12 + 0.08 * bp; rays.style.transform = 'rotate(' + (t * 25) + 'deg)';
      put(leader, 160, 90, 1, 0, t < 0 ? P(t, -1.0, -0.6) * (1 - P(t, -0.25, 0)) : 0);
      if (si === 0) { const k1 = P(t, 0.42, 0.85, E.back), k2 = P(t, 0.6, 1.02, E.back), pu = t > 1 ? 1 + 0.05 * bp : 1, ex = P(t, 1.8, 2);
        put(V.a1, 160, 70, k1 * pu * (1 + ex * 0.3), -4 * (1 - k1), k1 > 0 ? 1 - ex : 0); put(V.a2, 160, 116, k2 * pu * (1 + ex * 0.3), 3 * (1 - k2), k2 > 0 ? 1 - ex : 0);
        foot(V.ap[0], 56, 214 - 54 * P(t, 1.0, 1.35, E.back), 1, 1, -8); foot(V.ap[1], 264, 214 - 54 * P(t, 1.1, 1.45, E.back), 1, 1, 8);
        [[50, 38], [272, 34], [32, 124], [290, 130]].forEach(([x, y], i) => put(V.as[i], x, y, 0.8 + 0.4 * Math.sin(t * 9 + i * 2), 0, P(t, 0.5, 0.7) * (0.55 + 0.45 * Math.sin(t * 7 + i))));
      }
      if (si === 1) { const pr = press(t, [2.5, 3, 3.5, 4]), en = P(t, 2.0, 2.35, E.back);
        put(V.bc, 160, 24, P(t, 2.0, 2.3, E.back), 0, 1);
        foot(V.bm, 160, 178 + 70 * (1 - en) - (pr.n ? 0 : 4 * hop), 1 + 0.32 * pr.sq, 1 - 0.3 * pr.sq, 0, 1);
        const rd = cl(pr.d / 0.45); V.br.style.transform = 'translate(160px,112px) translate(-50%,-50%) scale(' + (0.3 + 1.6 * rd) + ')'; V.br.style.opacity = pr.n ? 0.85 * (1 - rd) : 0;
        const W = [[250, 66, 12], [72, 70, -12], [252, 100, 10], [70, 104, -10]][Math.max(0, pr.n - 1)];
        put(V.bw, W[0], W[1], P(pr.d, 0, 0.2, E.back), W[2], pr.n ? 1 - P(pr.d, 0.32, 0.5) : 0);
        V.bx.textContent = 'COMBO x' + Math.max(1, pr.n); put(V.bx, 262, 156, 1 + 0.4 * Math.exp(-pr.d * 8), -4, pr.n ? 1 : 0);
      }
      if (si === 2) { put(V.cc, 160, 26, P(t, 4.5, 4.8, E.back), 0, 1);
        V.ck.forEach((n, i) => { const a = 4.6 + 0.16 * i, k = P(t, a, a + 0.32, E.back), h = (bn + i) % 2 ? 0 : hop * 7 * (t > 5.6 ? 1 : 0), x = 38 + 48.8 * i, y = 150 + (i % 2 ? 14 : 0);
          foot(n, x, y - h, k, k, (i % 2 ? 4 : -4) * hop, k > 0.01 ? 1 : 0); put(V.cs[i], x + 18, y - 52, 0.6 + P(t, a, a + 0.2), 0, t > a ? 1 - P(t, a + 0.15, a + 0.5) : 0); });
      }
      if (si === 3) { put(V.dc, 160, 24, P(t, 7.0, 7.3, E.back), 0, 1); const k = P(t, 7.0, 7.32, E.back);
        let seats = [[112, 140], [160, 140], [208, 140]];
        if (V.ds) { const s = Math.min(210 / so.w, 108 / so.h), w = so.w * s, h = so.h * s, x0 = 160 - w / 2, y0 = 172 - h; V.ds.style.width = w + 'px'; V.ds.style.height = h + 'px';
          V.ds.style.transform = 'translate(' + x0 + 'px,' + y0 + 'px) scale(' + k + ')'; V.ds.style.opacity = k > 0.01 ? 1 : 0;
          if (so.seats && so.seats.length >= 3) { const bb = so.bb || [0, 0, so.w, so.h], pick = so.seats.length > 3 ? [0, Math.floor(so.seats.length / 2), so.seats.length - 1] : [0, 1, 2]; seats = pick.map(j => [x0 + (so.seats[j].x - bb[0]) * s, y0 + (so.seats[j].y - bb[1]) * s]); }
          const cw = Math.max(44, Math.min(72, 78 * s)); V.dk.forEach(n => { n._w = cw; n.style.width = cw + 'px'; n.style.height = cw + 'px'; }); }
        V.dk.forEach((n, i) => { const a = 7.2 + 0.15 * i, d = P(t, a, a + 0.3, E.back), h = (bn + i) % 2 ? 0 : hop * 4 * (t > 7.7 ? 1 : 0), [x, y] = seats[i];
          foot(n, x, y - 70 * (1 - d) - h, 1, 1, 0, t > a ? 1 : 0); });
      }
      if (si === 4) { const k = P(t, 8.5, 8.85, E.back);
        put(V.e1, 160, 52, k * (1 + 0.04 * bp), 0, k > 0.01 ? 1 : 0); put(V.e2, 160, 86, 1, 0, P(t, 8.8, 9.0));
        put(V.eb, 160, 126, P(t, 8.9, 9.2, E.back) * (1 + 0.07 * bp), 0, t > 8.9 ? 1 : 0);
        foot(V.ek[0], 46 - 90 * (1 - P(t, 8.6, 8.95, E.back)), 186 - (bn % 2 ? 0 : hop * 6), 1, 1, -6); foot(V.ek[1], 274 + 90 * (1 - P(t, 8.65, 9.0, E.back)), 186 - (bn % 2 ? hop * 6 : 0), 1, 1, 6);
        [[118, 18], [212, 22], [252, 92]].forEach(([x, y], i) => put(V.es[i], x, y, 0.8 + 0.4 * Math.sin(t * 9 + i * 2), 0, P(t, 9.0, 9.2) * (0.55 + 0.45 * Math.sin(t * 7 + i))));
      }
      let fl = 0; [2, 4.5, 7, 8.5].forEach(c => { fl = Math.max(fl, 1 - Math.abs(t - c) / 0.1); }); flash.style.opacity = 0.85 * cl(fl);
      blk.style.opacity = P(t, AD, AD + 0.5);
      return { rgb: t < 0 ? '200,210,255' : SPILL[si], lit: t < 0 ? 0.25 : (1 - P(t, AD, AD + 0.5)) * (0.85 + 0.15 * bp) + fl * 0.6 };
    }
    return { root, st, upd };
  }

  // ---------- frame loop ----------
  let RAF = 0, TO = 0;
  function loop() { if (RAF) return; RAF = requestAnimationFrame(frame); TO = setTimeout(frame, 60); }
  function spawn(fx, tgt, n) {
    if (!fx || !fx.isConnected) return; const a = tgt.getBoundingClientRect(), b = fx.getBoundingClientRect(); if (!a.width) return;
    const cx = a.left - b.left + a.width / 2, cy = a.top - b.top + a.height * 0.45, w = Math.max(24, a.width * 0.7), c = NC[n % NC.length];
    const r = el('div', 'position:absolute;left:' + (cx - w / 2) + 'px;top:' + (cy - w / 2) + 'px;width:' + w + 'px;height:' + w + 'px;border-radius:50%;border:2.5px solid ' + c + ';box-sizing:border-box;pointer-events:none;', fx);
    r.animate([{ transform: 'scale(0.35)', opacity: 0.9 }, { transform: 'scale(1.7)', opacity: 0 }], { duration: 620, easing: 'ease-out' }).onfinish = () => r.remove();
    const sz = Math.max(15, Math.min(34, a.width * 0.3)), dx = (n % 2 ? 1 : -1) * (a.width * 0.35 + Math.random() * 10);
    const s = el('span', "position:absolute;left:" + (cx - sz / 3) + "px;top:" + (a.top - b.top + a.height * 0.2 - sz / 2) + "px;font-family:'Fredoka',sans-serif;font-weight:700;font-size:" + sz + "px;line-height:1;color:" + c + ";text-shadow:0 2px 0 " + INK + ";pointer-events:none;", fx, NOTE[n % 3]);
    s.animate([{ transform: 'translate(0,0) rotate(0deg) scale(0.6)', opacity: 0 }, { transform: 'translate(' + dx * 0.4 + 'px,' + (-a.height * 0.35) + 'px) rotate(' + (dx > 0 ? 10 : -10) + 'deg) scale(1.1)', opacity: 1, offset: 0.25 },
      { transform: 'translate(' + dx + 'px,' + (-a.height * 0.95 - 20) + 'px) rotate(' + (dx > 0 ? -12 : 12) + 'deg) scale(0.9)', opacity: 0 }], { duration: 1300, easing: 'ease-out' }).onfinish = () => s.remove();
  }
  function bounce(tgt, fx, ph, n, now, amp) {
    const hop = Math.sin(Math.PI * ph), sq = Math.exp(-ph * 9), big = n % 4 === 0 ? 1.6 : 1, H = tgt.offsetHeight || 60;
    const jx = Math.sin(now * 0.11) * 1.5 * amp * (0.35 + sq), jy = Math.cos(now * 0.137) * 0.9 * amp * (0.35 + sq);
    const ty = -hop * H * 0.1 * big * amp, sx = 1 + 0.14 * sq * amp - 0.04 * hop, sy = 1 - 0.14 * sq * amp + 0.06 * hop * amp, rot = (n % 2 ? 1 : -1) * 3 * hop * amp * big;
    tgt.style.transformOrigin = '50% 100%'; tgt.style.transform = 'translate(' + jx.toFixed(2) + 'px,' + (ty + jy).toFixed(2) + 'px) rotate(' + rot.toFixed(2) + 'deg) scale(' + sx.toFixed(3) + ',' + sy.toFixed(3) + ')';
    if (tgt._mnB !== n) { tgt._mnB = n; spawn(fx, tgt, n); }
  }
  function frame() {
    cancelAnimationFrame(RAF); clearTimeout(TO); RAF = 0; const now = performance.now(); let beat = null;
    if (SH) { const dt = Math.min(0.25, Math.max(0, (now - SH.last) / 1000)); SH.last = now;
      if (!SH.pause) { SH.age += dt;
        if (!SH.done) { const m0 = SH.mt; SH.mt += dt; if (SH.mt >= SH.mv.dur) { SH.mt = SH.mv.dur; SH.done = true; } cues(m0, SH.mt); if (Math.floor(SH.mt) !== SH.sv) { SH.sv = Math.floor(SH.mt); savePos(SH); } }
        else SH.endA += dt; if (SH.msgT > 0 && SH.mt > 0) SH.msgT -= dt; }
      if (SH.done && SH.endA > UP + 0.6) stopShow(); }
    if (SH && !SH.pause && !SH.done && SH.mt >= 0) { if (SH.mv.ad) { const b = SH.mt / BEAT; beat = { n: Math.floor(b), ph: b - Math.floor(b), amp: SH.mt < 2 ? 0.55 : 1 }; } else if (SH.mv.beat) beat = SH.mv.beat(SH.mt); }
    else if (!SH && J.on) { const b = Math.max(0, (now - J.p0) / 500); beat = { n: Math.floor(b), ph: b - Math.floor(b), amp: 1 }; }
    if (SH && !SH.pause && !SH.mv.ad && SH.bus && A.ctx) sched(SH);
    const list = [], dead = []; K.forEach((g, key) => { const o = g(); if (!o || !o.el || !o.el.isConnected) dead.push(key); else list.push(o); }); dead.forEach(k => stop(k));
    if (SH && RM) RM.querySelectorAll('[data-kind="spk"]').forEach(n => { const t = n.firstElementChild; if (t && !list.some(o => o.el === t)) list.push({ el: t, fx: L }); });
    list.forEach(o => { if (beat) bounce(o.el, o.fx, beat.ph, beat.n, now, beat.amp); else resetEl(o.el); });
    if (SH && RM && beat) RM.querySelectorAll('[data-kind="crew"]').forEach((n, i) => { const t = n.firstElementChild; if (!t) return; const h = (beat.n + i) % 2 ? 0 : Math.sin(Math.PI * beat.ph), H = t.offsetHeight || 40;
      t.style.transformOrigin = '50% 90%'; t.style.transform = 'translateY(' + (-h * H * 0.08).toFixed(2) + 'px) scale(' + (1 + 0.04 * h) + ',' + (1 - 0.03 * h) + ')'; });
    if (TH && L && L._mn) {
      const N = L._mn, sc = TH.screen, q = sc ? quad(sc) : null, cen = q ? [(q[0][0] + q[2][0]) / 2, (q[0][1] + q[2][1]) / 2] : null, pl = TH.player ? centerOf(TH.player, 0.35) : null;
      if (TH.synced && TH.edit !== false && !SH && cen) {
        const pts = [cen].concat((TH.spk || []).map(u => centerOf(u, 0.4)).filter(Boolean)), pu = Math.exp(-((now / 500) % 1) * 4), off = (-now * 0.03).toFixed(1);
        let s = ''; if (pl) pts.forEach(p => { s += '<line x1="' + pl[0].toFixed(1) + '" y1="' + pl[1].toFixed(1) + '" x2="' + p[0].toFixed(1) + '" y2="' + p[1].toFixed(1) + '" stroke="#6fe39a" stroke-width="2" stroke-dasharray="5 6" stroke-dashoffset="' + off + '" stroke-linecap="round" opacity="0.75"></line>'; });
        (pl ? [pl] : []).concat(pts).forEach(p => { s += '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="' + (6 + 6 * pu).toFixed(1) + '" fill="#6fe39a" opacity="' + (0.25 * pu).toFixed(2) + '"></circle><circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="3.5" fill="#6fe39a" stroke="#1e4a2a" stroke-width="1.5"></circle>'; });
        N.links.innerHTML = s;
      } else N.links.innerHTML = '';
      uiUpd();
      if (SH && q) {
        const dOp = SH.done ? 1 - cl(SH.endA / UP) : E.out(cl(SH.age / DIM)), v = SH.vid, m = sc.m, s = Math.max(sc.w / 320, sc.h / 180), fin = SH.done ? 1 - cl((SH.endA - 0.5) / 0.6) : 1;
        const fe = fzStep(N, now);
        if (fe <= 0) { v.root.style.width = sc.w + 'px'; v.root.style.height = sc.h + 'px'; v.root.style.transform = 'matrix(' + m.map(x => x.toFixed(4)).join(',') + ')';
          v.st.style.transform = 'translate(' + ((sc.w - 320 * s) / 2).toFixed(2) + 'px,' + ((sc.h - 180 * s) / 2).toFixed(2) + 'px) scale(' + s.toFixed(4) + ')'; }
        else { // zoom from the screen quad to a 16:9 frame filling the view: size, rotation/skew, offset and picture fit all blend with the same eased progress
          const m0 = m[0] * m[3] - m[1] * m[2] < 0 ? [-m[0], -m[1], m[2], m[3], m[4] + m[0] * sc.w, m[5] + m[1] * sc.w] : m, LR = L.getBoundingClientRect(), kk = LR.width / (L.offsetWidth || LR.width || 1), mm = [m0[0] * kk, m0[1] * kk, m0[2] * kk, m0[3] * kk, LR.left + m0[4] * kk, LR.top + m0[5] * kk], W = window.innerWidth || 852, Hh = window.innerHeight || 393, sx = Math.hypot(mm[0], mm[1]) || 1, sy = Math.hypot(mm[2], mm[3]) || 1;
          let Wt = Hh * 16 / 9, Ht = Hh; if (Wt > W) { Wt = W; Ht = W * 9 / 16; } const tx = (W - Wt) / 2, ty = (Hh - Ht) / 2, s1 = Math.min(Wt / 320, Ht / 180), lp = (a, b) => a + (b - a) * fe; FZ.box = [tx, ty, Wt, Ht];
          v.root.style.width = lp(sc.w * sx, Wt).toFixed(2) + 'px'; v.root.style.height = lp(sc.h * sy, Ht).toFixed(2) + 'px';
          v.root.style.transform = 'matrix(' + [lp(mm[0] / sx, 1), lp(mm[1] / sx, 0), lp(mm[2] / sy, 0), lp(mm[3] / sy, 1), lp(mm[4], tx), lp(mm[5], ty)].map(x => x.toFixed(4)).join(',') + ')';
          v.st.style.transform = 'translate(' + lp((sc.w - 320 * s) / 2 * sx, (Wt - 320 * s1) / 2).toFixed(2) + 'px,' + lp((sc.h - 180 * s) / 2 * sy, (Ht - 180 * s1) / 2).toFixed(2) + 'px) scale(' + lp(s * sx, s1).toFixed(4) + ',' + lp(s * sy, s1).toFixed(4) + ')'; }
        const o = v.upd(SH.mt), on = cl((SH.age - DIM + 0.6) / 0.6); v.root.style.opacity = (on * fin).toFixed(3);
        v.root.style.boxShadow = fe > 0 ? '0 0 ' + (50 * fe).toFixed(1) + 'px ' + (8 * fe).toFixed(1) + 'px rgba(' + o.rgb + ',' + (0.4 * o.lit * on * Math.min(1, fe)).toFixed(2) + ')' : '0 0 ' + (8 / Math.max(0.3, Math.abs(m[0]))).toFixed(1) + 'px 2px rgba(' + o.rgb + ',' + (0.7 * o.lit * on).toFixed(2) + ')';
        { const fbOn = false, b = N.fb; // corner expand button removed: full screen lives in the player bar only
          if (fbOn) { const a = q[1], d1 = [q[0][0] - a[0], q[0][1] - a[1]], d2 = [q[2][0] - a[0], q[2][1] - a[1]], l1 = Math.hypot(d1[0], d1[1]) || 1, l2 = Math.hypot(d2[0], d2[1]) || 1, i1 = Math.min(24, l1 * 0.2) / l1, i2 = Math.min(24, l2 * 0.25) / l2;
            b.style.left = (a[0] + d1[0] * i1 + d2[0] * i2 - 17).toFixed(1) + 'px'; b.style.top = (a[1] + d1[1] * i1 + d2[1] * i2 - 17).toFixed(1) + 'px'; }
          const bo = fbOn ? '1' : '0'; if (b.style.opacity !== bo) { b.style.opacity = bo; b.style.transform = fbOn ? 'scale(1)' : 'scale(0.6)'; b.style.pointerEvents = fbOn ? 'auto' : 'none'; } }
        const R = Math.max(Math.abs(q[1][0] - q[0][0]), 80) * 1.4;
        N.dim.style.opacity = dOp.toFixed(3);
        N.dim.style.background = 'radial-gradient(circle at ' + (cen[0] + 60).toFixed(0) + 'px ' + (cen[1] + 60).toFixed(0) + 'px, rgba(' + o.rgb + ',' + (0.3 * o.lit * on).toFixed(2) + ') 0, rgba(' + o.rgb + ',0) ' + R.toFixed(0) + 'px), radial-gradient(ellipse at ' + (cen[0] + 60).toFixed(0) + 'px ' + (cen[1] + 60).toFixed(0) + 'px, rgba(8,5,18,0.5), rgba(8,5,18,0.88) 70%)';
        if (pl) { N.beam.setAttribute('points', hull([pl].concat(q)).map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ')); N.grad.setAttribute('x1', pl[0]); N.grad.setAttribute('y1', pl[1]); N.grad.setAttribute('x2', cen[0]); N.grad.setAttribute('y2', cen[1]);
          N.beam.setAttribute('opacity', (0.32 * on * Math.min(1, o.lit + 0.2) * (SH.done ? 1 - cl(SH.endA / 0.6) : 1)).toFixed(3)); }
        else N.beam.setAttribute('opacity', '0');
      }
    }
    if (K.size || SH || (TH && TH.synced)) loop();
  }

  const subs = new Set(); function emit() { subs.forEach(f => { try { f(); } catch (e) {} }); }
  window.MovieNight = { jamMute: v => { J.mute = !!v; if (J.bus && A.ctx) J.bus.gain.setTargetAtTime(v ? 0.0001 : 1, A.ctx.currentTime, 0.05); }, toggle, stop, isOn: k => K.has(k), theater, play: id => play(id), stopShow, showing: () => !!SH, paused: () => !!(SH && SH.pause), pause: () => setPause(true), resume: () => setPause(false), togglePause: () => { if (SH) setPause(!SH.pause); },
    focus: v => focus(v === undefined ? !FZ.on : v), focused: () => FZ.on,
    onReact: f => { REACT = f; }, cast: v => { if (v !== undefined) CAST = Array.isArray(v) ? v : []; return CAST; }, now: () => SH && { id: SH.mv.id, title: SH.mv.title, t: SH.mt, dur: SH.mv.dur, paused: SH.pause },
    _seek: s => { if (SH) { SH.mt = s; SH.age = Math.max(SH.age, DIM + 1); if (A.ctx && SH.bus) { SH.a0 = A.ctx.currentTime - s; SH.ei = idxOf(SH.mv, s); } frame(); } }, sub: f => { subs.add(f); return () => subs.delete(f); } };
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && FZ.on) focus(false); });
})();
