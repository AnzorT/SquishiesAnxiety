// Renovation Catalog round 19 — Living Room WALLS remodel (user: "they look like texture, not real like the Movie Room walls").
// Same game style as the Movie Room walls (plus12): wall surfaces = creature-scale seamless 80 x 56 tiles through the plus12 tile pipeline (RD.H12.SURF12),
// wall art + wall quotes = lit 3D wall pieces (cam / box3 / cyl3 / WD wall decals + wall shadows), windows = detailed front-on window art that the house shell
// draws in its window slot (X.SPEC['rv_<id>'].ir = rect around winX; Squad House v6 fills it with url(#rnWin)). Sets RenoDraw.PLUS19; catalog edits RD.SET19.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS18 && RD.H12 && RD.H12.tile && RD.H15 && RD.H11 && RD.H10 && X && X.K && X.SPEC)) { setTimeout(boot, 30); return; } if (RD.PLUS19) return;
  const K = X.K, shade = K.shade, N = RD.N, H = RD.H10, PI = Math.PI;
  const { cam, an, at, SPL, f1, n4, rep, P2, rng } = H;
  const { ext } = RD.H11, { DEF12, WD, wsh, innerW, tile, blot, outlet, BB, SURF12 } = RD.H12, { box3, cyl3 } = RD.H15;
  const sph = (C, q, r, col, o) => { const c = C.P(q); return H.sph(C, q, r, col, o) + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * C.k)}" fill="none" stroke="${shade(col, 0.35)}" stroke-width="0.5"/>`; };
  const pane = (C, O, U, V, w, h, o) => RD.H11.pane(C, O, U, V, w, h, Object.assign({}, o, { g: 0.3, e: 0.12, t: 0.03 }));
  const xe = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const T = (x, y, sz, col, txt, ex) => `<text x="${f1(x)}" y="${f1(y)}" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="${f1(sz)}" fill="${col}"${ex ? ' ' + ex : ''}>${txt}</text>`;
  const SCRIPT = "'Brush Script MT','Segoe Script','Lucida Handwriting',cursive", HAND = "'Segoe Print','Comic Sans MS','Marker Felt',cursive", SERIF = "Georgia,'Times New Roman',serif";
  const DEF19 = DEF12 + '<pattern id="tw19" width="0.9" height="0.9" patternUnits="userSpaceOnUse"><path d="M0 0.45H0.9M0.45 0V0.9" stroke="#5a4a30" stroke-opacity="0.12" stroke-width="0.18"/></pattern>'
    + '<linearGradient id="br19" x1="0" y1="0" x2="0.3" y2="1"><stop offset="0" stop-color="#fff0b0"/><stop offset="0.35" stop-color="#e2b456"/><stop offset="0.7" stop-color="#b38432"/><stop offset="1" stop-color="#7a5418"/></linearGradient>'
    + '<linearGradient id="gd19" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff3c0" stop-opacity="0.55"/><stop offset="0.4" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.75" stop-color="#5a3a08" stop-opacity="0.18"/><stop offset="1" stop-color="#5a3a08" stop-opacity="0.32"/></linearGradient>';

  // ======================= WALL SURFACES (creature-scale 80 x 56 tiles, plus12 pipeline) =======================
  const capBoard = (col, h) => { const t = BB - h; return `<rect y="${f1(t - 0.9)}" width="80" height="0.9" fill="#000000" opacity="0.14" filter="url(#wb1)"/><rect y="${f1(t)}" width="80" height="${f1(h)}" fill="${col}"/><rect y="${f1(t)}" width="80" height="0.35" fill="${shade(col, 1.12)}"/><rect y="${f1(t + 0.55)}" width="80" height="0.2" fill="${shade(col, 0.8)}"/><rect y="${f1(BB - 0.25)}" width="80" height="0.25" fill="${shade(col, 0.86)}"/>`; };
  const swPlate = (x, y, col) => `<rect x="${f1(x + 0.25)}" y="${f1(y + 0.35)}" width="1.6" height="2.5" rx="0.2" fill="#000000" opacity="0.2" filter="url(#wb1)"/><rect x="${x}" y="${y}" width="1.6" height="2.5" rx="0.2" fill="${col}" stroke="${shade(col, 0.72)}" stroke-width="0.1"/><rect x="${f1(x + 0.58)}" y="${f1(y + 0.7)}" width="0.44" height="1.1" rx="0.12" fill="${shade(col, 0.93)}" stroke="${shade(col, 0.7)}" stroke-width="0.08"/><rect x="${f1(x + 0.6)}" y="${f1(y + 0.72)}" width="0.4" height="0.45" fill="#ffffff" opacity="0.7"/>`;
  const scuffs = (seed, n, a, b) => { const R = rng(seed); return rep(n, () => `<path d="M${f1(R() * 78)} ${f1(BB + 0.5 + R() * 1.6)}h${f1(0.6 + R() * 1.6)}" stroke="${R() < 0.5 ? a : b}" stroke-width="${f1(0.12 + R() * 0.16)}" stroke-linecap="round" opacity="0.6"/>`).join(''); };

  // LIV-001 water-stained off-white rental wallpaper: faded stripes + rose sprigs, strip seams (one lifting), ceiling-leak stains, nail holes, a torn spot
  function sPaper() { const R = rng('lp19');
    let s = '<rect width="80" height="56" fill="#ebe2ca"/>' + blot('lp19', 30, ['#f1e9d4', '#e1d6ba', '#e8dec4'], 0.3, 3);
    for (let i = 0; i < 10; i++) { const x = i * 8; s += `<rect x="${x + 0.6}" width="3" height="56" fill="#d9cba8" opacity="0.32"/><rect x="${x + 5.3}" width="0.2" height="56" fill="#c4b088" opacity="0.5"/><rect x="${x + 6.1}" width="0.2" height="56" fill="#c4b088" opacity="0.5"/>`; }
    const sprig = (x, y) => `<g transform="translate(${f1(x)} ${f1(y)})"><path d="M0 1.3Q0.2 0.3 0 -0.6M0 0.5Q-0.6 0.2 -0.9 -0.3M0 0.7Q0.6 0.5 0.8 0" stroke="#93a07a" stroke-width="0.16" fill="none" opacity="0.75"/><circle cy="-0.8" r="0.45" fill="#d39c98" opacity="0.7"/><circle cx="-0.95" cy="-0.45" r="0.3" fill="#d39c98" opacity="0.6"/><circle cx="0.85" cy="-0.1" r="0.3" fill="#d39c98" opacity="0.6"/><circle cy="-0.8" r="0.14" fill="#f3e2b0"/></g>`;
    for (let i = 0; i < 10; i++) for (let j = -1; j < 8; j++) s += sprig(i * 8 + 4.4, j * 8 + (i % 2) * 4 + 3);
    s += '<rect width="80" height="22" fill="url(#lpy)"/>';
    [0, 26.67, 53.33, 80].forEach(x => s += `<path d="M${f1(x)} 0V56" stroke="#b3a482" stroke-width="0.14" opacity="0.65"/><path d="M${f1(x + 0.18)} 0V56" stroke="#ffffff" stroke-width="0.12" opacity="0.45"/>`);
    s += '<path d="M53.33 0V8.5L52.7 0Z" fill="#000000" opacity="0.18" filter="url(#wb1)"/><path d="M53.33 0V8Q54.3 4.6 55.6 0Z" fill="#f7f0de" stroke="#b3a482" stroke-width="0.12"/><path d="M53.6 0.6Q54.2 3.4 53.5 6.4" stroke="#d8cba8" stroke-width="0.14" fill="none"/>';
    const stain = (cx, w, h, sd) => { const Q = rng(sd); let d = `M${f1(cx - w / 2)} 0`; for (let i = 1; i < 10; i++) { const t = i / 10; d += `L${f1(cx - w / 2 + w * t)} ${f1(h * Math.sin(PI * t) * (0.72 + 0.4 * Q()))}`; } return d + `L${f1(cx + w / 2)} 0Z`; };
    [[16, 15, 14, 'st1'], [65, 9, 8, 'st2']].forEach(([cx, w, h, sd]) => { const d1 = stain(cx, w, h, sd), d2 = stain(cx + 1, w * 0.62, h * 0.6, sd + 'b');
      s += `<path d="${d1}" fill="#c4a670" opacity="0.26" filter="url(#wb2)"/><path d="${d1}" fill="none" stroke="#977a46" stroke-width="0.35" opacity="0.42" filter="url(#wb1)"/><path d="${d2}" fill="#b5955c" opacity="0.2" filter="url(#wb1)"/><path d="${d2}" fill="none" stroke="#86683a" stroke-width="0.22" opacity="0.38"/>`; });
    s += '<path d="M31.2 22.6L32.6 21.4L34.4 22L35.2 23.8L33.8 25.2L31.8 24.6Z" fill="#c9c2b2"/><path d="M31.2 22.6L32.6 21.4L34.4 22L35.2 23.8L33.8 25.2L31.8 24.6Z" fill="none" stroke="#f7f0de" stroke-width="0.22"/><path d="M32.2 23.6l1.2 0.3" stroke="#aaa294" stroke-width="0.12"/>';
    [[40.5, 15.2], [12.2, 30.4], [45.6, 15.4]].forEach(([x, y]) => s += `<circle cx="${x}" cy="${y}" r="0.2" fill="#5a4c38"/><circle cx="${x + 0.06}" cy="${y + 0.06}" r="0.26" fill="none" stroke="#ffffff" stroke-width="0.06" opacity="0.6"/>`);
    const sup = s; s += outlet(47.4, 46.3, '#efe7d4', '#5a5244');
    return { mat: s, sup, defs: '<linearGradient id="lpy" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#cdb27a" stop-opacity="0.16"/><stop offset="1" stop-color="#cdb27a" stop-opacity="0"/></linearGradient>', board: '#dcd1b9',
      ro: { top: 0.06, ao: 0.15, board: capBoard('#dcd1b9', 0.9) + scuffs('lpb', 16, '#9c917c', '#ece4d2') } }; }

  // LIV-021 warm sage matte paint: roller laps + stipple, white two-step skirting, outlet, switch and a little round thermostat
  function sSage() { const R = rng('sg19'); let s = '<rect width="80" height="56" fill="#9caf8b"/>' + blot('sg19', 30, ['#a7b996', '#90a381', '#a1b391'], 0.32, 3.4);
    for (let i = 0; i < 16; i++) s += `<rect x="${i * 5}" width="5" height="56" fill="${i % 2 ? '#ffffff' : '#000000'}" opacity="${f1(0.008 + R() * 0.012)}"/>`;
    s += '<rect width="80" height="56" fill="url(#sgs)"/>';
    const sup = s; s += outlet(36.2, 46.4, '#f3efe5', '#6a665c');
    if (0) s += '<g transform="translate(10.6 27.4)"><circle cx="0.25" cy="0.35" r="1.3" fill="#000000" opacity="0.2" filter="url(#wb1)"/><circle r="1.2" fill="#f3efe5" stroke="#b9b3a2" stroke-width="0.1"/><circle r="0.78" fill="#2d3b3f"/><circle r="0.78" fill="none" stroke="#f0a64a" stroke-width="0.14" stroke-dasharray="1.5 3.4"/><rect x="-0.34" y="-0.16" width="0.68" height="0.3" rx="0.06" fill="#8fe8c4"/><circle cx="-0.35" cy="-0.5" r="0.3" fill="#ffffff" opacity="0.3"/></g>';
    return { mat: s, sup, defs: '<pattern id="sgs" width="1.5" height="1.5" patternUnits="userSpaceOnUse"><circle cx="0.4" cy="0.5" r="0.2" fill="#000000" fill-opacity="0.06"/><circle cx="1.1" cy="1.1" r="0.17" fill="#ffffff" fill-opacity="0.07"/></pattern>', board: '#f2eee3',
      ro: { top: 0.07, ao: 0.12, board: capBoard('#f2eee3', 1.4) + scuffs('sgb', 8, '#c9c3b4', '#ffffff') } }; }

  // LIV-041 half-height shaker wainscoting: cream plaster above a chair rail, recessed shaker panels below
  function sWain() { const UP = '#eee2c6', PN = '#f2ede2', CR = 31.2, y0 = CR + 2.8, y1 = BB - 2.2;
    const sup = `<rect width="80" height="56" fill="${UP}"/>` + blot('wn19', 26, ['#f4ead2', '#e5d8b8', '#ebdfc2'], 0.3, 3);
    let s = sup + `<rect y="${CR}" width="80" height="${56 - CR}" fill="${PN}"/>`;
    for (let i = 0; i < 8; i++) { const a = i * 10 + 1.7, b = i * 10 + 8.3, e = 0.55;
      s += `<rect x="${a}" y="${y0}" width="${f1(b - a)}" height="${f1(y1 - y0)}" fill="${shade(PN, 0.96)}"/>`
        + `<path d="M${a} ${y0}H${b}L${f1(b - e)} ${f1(y0 + e)}H${f1(a + e)}Z" fill="${shade(PN, 0.8)}"/><path d="M${a} ${y0}V${f1(y1)}L${f1(a + e)} ${f1(y1 - e)}V${f1(y0 + e)}Z" fill="${shade(PN, 0.87)}"/>`
        + `<path d="M${b} ${y0}V${f1(y1)}L${f1(b - e)} ${f1(y1 - e)}V${f1(y0 + e)}Z" fill="#ffffff" opacity="0.75"/><path d="M${a} ${f1(y1)}H${b}L${f1(b - e)} ${f1(y1 - e)}H${f1(a + e)}Z" fill="${shade(PN, 1.04)}"/>`
        + `<rect x="${f1(a + e)}" y="${f1(y0 + e)}" width="${f1(b - a - 2 * e)}" height="1.6" fill="#000000" opacity="0.05"/>`; }
    s += `<rect y="${f1(CR + 1.6)}" width="80" height="1.1" fill="#000000" opacity="0.16" filter="url(#wb1)"/><rect y="${CR}" width="80" height="1.7" fill="#f6f2ea"/><rect y="${CR}" width="80" height="0.35" fill="#ffffff"/><rect y="${f1(CR + 0.8)}" width="80" height="0.18" fill="${shade(PN, 0.82)}"/><rect y="${f1(CR + 1.5)}" width="80" height="0.2" fill="${shade(PN, 0.72)}"/><rect y="${f1(CR - 0.5)}" width="80" height="0.5" fill="#000000" opacity="0.06"/>`;
    s += outlet(9.25, 45.6, '#f6f2ea', '#6a665c');
    return { mat: s, sup, board: '#f1ece0', ro: { top: 0.07, ao: 0.12, board: capBoard('#f1ece0', 1.2) + scuffs('wnb', 6, '#cfc8b8', '#ffffff') } }; }

  // LIV-061 herringbone (chevron) oak feature wall on the back wall; the side walls get the limewash plaster (S.smat)
  function sHerr() { const R = rng('hb19'), PC = ['#b98a58', '#a87a4a', '#c69866', '#9c6f42', '#b48252', '#cfa574'], ds = PC.map(() => ''); let gr = '';
    for (let c = 0; c < 10; c++) for (let r = -3; r < 29; r++) { const x = c * 8, y = r * 2;
      ds[Math.floor(R() * 6)] += `M${x} ${y + 4}L${x + 4} ${y}V${y + 2}L${x} ${y + 6}Z`; ds[Math.floor(R() * 6)] += `M${x + 4} ${y}L${x + 8} ${y + 4}V${y + 6}L${x + 4} ${y + 2}Z`;
      const j = R() * 0.5; gr += `M${f1(x + 0.5 + j)} ${f1(y + 4.5 - j)}L${f1(x + 3.3)} ${f1(y + 1.7)}M${f1(x + 4.7)} ${f1(y + 1.4 + j)}L${f1(x + 7.4 - j)} ${f1(y + 4.1)}`; }
    let s = '<rect width="80" height="56" fill="#3a2414"/>' + ds.map((d, i) => `<path d="${d}" fill="${PC[i]}" stroke="#4a2c16" stroke-width="0.16" stroke-opacity="0.75"/>`).join('')
      + `<path d="${gr}" stroke="#6a4224" stroke-width="0.12" opacity="0.32" fill="none"/>` + rep(10, c => `<path d="M${c * 8 + 4} 0V56" stroke="#2a1608" stroke-width="0.14" opacity="0.35"/>`).join('')
      + '<rect width="80" height="56" fill="url(#hbg)"/>' + blot('hb19', 18, ['#ffe0b0', '#5a3418'], 0.12, 5);
    let m = '<rect width="80" height="56" fill="#dcd3c3"/>' + blot('lw19', 26, ['#e9e2d6', '#cbc0ad', '#d6ccbb', '#ece6db'], 0.55, 6);
    const Q = rng('lwb'); m += '<g filter="url(#wb1)">' + rep(26, () => { const x = 4 + Q() * 72, y = 4 + Q() * 46, l = 4 + Q() * 8, b = (Q() - 0.5) * 4; return `<path d="M${f1(x)} ${f1(y)}q${f1(l / 2)} ${f1(b)} ${f1(l)} ${f1((Q() - 0.5) * 2)}" stroke="${Q() < 0.5 ? '#f2ede4' : '#c2b6a2'}" stroke-width="${f1(0.8 + Q() * 1.2)}" stroke-linecap="round" fill="none" opacity="0.4"/>`; }).join('') + '</g>';
    return { mat: s, smat: m, defs: '<linearGradient id="hbg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.1"/></linearGradient>', board: '#3d2a1c',
      ro: { top: 0.05, ao: 0.12, board: `<rect y="${BB}" width="80" height="0.35" fill="#1a110a"/>` } }; }

  // LIV-081 bookmatched Calacatta Viola marble (mirror-matched slabs) with brass inlay strips (moving sheen removed at user request)
  function sMarb() { const R = rng('mv19');
    const wav = (x0, a, p1, b, p2, c, p3) => 'M' + rep(30, j => { const y = -2 + j * 2; return f1(x0 + a * Math.sin(2 * PI * y / 56 + p1) + b * Math.sin(4 * PI * y / 56 + p2) + c * Math.sin(6 * PI * y / 56 + p3)) + ' ' + y; }).join('L');
    let v = '<g filter="url(#wb2)">' + [[12, 6, 0.4, 3, 1.2, 1, 2], [28, 5, 2.4, 2, 0.3, 1.2, 1]].map(p => `<path d="${wav(...p)}" stroke="#c9c4bc" stroke-width="3.4" fill="none" opacity="0.18"/>`).join('') + '</g>';
    const main = [[10, 7, 0.3, 3, 1.1, 1.2, 2.2], [24, 6, 2.2, 2.4, 0.4, 1.4, 1], [33, 3, 4, 1.6, 2, 0.8, 0.2]];
    v += '<g filter="url(#wb1)">' + main.map(p => `<path d="${wav(...p)}" stroke="#b4aea4" stroke-width="1" fill="none" opacity="0.28"/>`).join('') + '</g>' + main.map(p => `<path d="${wav(...p)}" stroke="#9a948a" stroke-width="0.3" fill="none" opacity="0.6"/>`).join('');
    v += rep(7, () => { const x = 3 + R() * 34, y = R() * 50, l = 3 + R() * 6, a = (R() - 0.5) * 2.4; return `<path d="M${f1(x)} ${f1(y)}q${f1(l * 0.4)} ${f1(l * 0.5)} ${f1(l * Math.sin(a))} ${f1(l)}" stroke="#a8a297" stroke-width="0.18" fill="none" opacity="0.6"/>`; }).join('');
    v += rep(4, () => `<path d="${wav(4 + R() * 32, 2 + R() * 4, R() * 6, 1 + R(), R() * 6, 0.5, R() * 6)}" stroke="#d8cfa8" stroke-width="0.12" fill="none" opacity="0.7"/>`).join('');
    const slab = `<g clip-path="url(#mvc)">${v}</g>`;
    let s = '<rect width="80" height="56" fill="#f2f0ec"/>' + blot('mv19', 26, ['#f7f5f1', '#e6e2dc', '#eeebe6'], 0.35, 4) ;
    s += '<rect x="0" width="80" height="56" fill="url(#mvr)"/>';
    s += [0, 40, 80].map(x => `<rect x="${x - 0.38}" width="0.76" height="56" fill="url(#mvb)"/><rect x="${x - 0.12}" width="0.18" height="56" fill="#fff6d0" opacity="0.8"/>`).join('');
    return { mat: s, defs: '<clipPath id="mvc"><rect width="40" height="56"/></clipPath><linearGradient id="mvb" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8a6420"/><stop offset="0.5" stop-color="#f2d58a"/><stop offset="1" stop-color="#9a7228"/></linearGradient>'
      + '<linearGradient id="mvr" x1="0" y1="0" x2="1" y2="0"><stop offset="0.2" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.36" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.76" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.8" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
      + '<linearGradient id="mvs" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.38"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>', board: '#b48a42',
      ro: { top: 0.05, ao: 0.1, board: `<rect y="${BB}" width="80" height="0.5" fill="#f2d58a"/><rect y="${f1(BB + 0.9)}" width="80" height="0.25" fill="#fff0b8" opacity="0.6"/>` } }; }
  Object.assign(SURF12, { lpaper: sPaper, lsage: sSage, lwain: sWain, lherr: sHerr, lmarb: sMarb });

  // ======================= LIV-004 FREE PIZZA-SHOP CALENDAR (live date, day marks, pencil on a string) =======================
  const MONTHS = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'], DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const pizzaPhoto = (p, w, h) => { const cx = w * 0.4, cy = h * 0.56, r = h * 0.42, a0 = -0.45, a1 = 0.35, wedge = rr => `M${f1(cx)} ${f1(cy)}L${f1(cx + rr * Math.cos(a1))} ${f1(cy + rr * Math.sin(a1))}A${f1(rr)} ${f1(rr)} 0 1 1 ${f1(cx + rr * Math.cos(a0))} ${f1(cy + rr * Math.sin(a0))}Z`;
    const sl = rr => `M0 0L${f1(rr * Math.cos(a0))} ${f1(rr * Math.sin(a0))}A${f1(rr)} ${f1(rr)} 0 0 1 ${f1(rr * Math.cos(a1))} ${f1(rr * Math.sin(a1))}Z`, sx = cx + r * 0.42, sy = cy - r * 0.18, R = rng('pz' + p);
    const pep = (x, y, k) => `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r * 0.13 * k)}" fill="#b8352a"/><circle cx="${f1(x - r * 0.03)}" cy="${f1(y - r * 0.03)}" r="${f1(r * 0.05 * k)}" fill="#e2675a" opacity="0.7"/>`;
    return `<defs><pattern id="${p}t" width="3" height="3" patternUnits="userSpaceOnUse"><rect width="3" height="3" fill="#f4eee4"/><rect width="1.5" height="1.5" fill="#d9483b"/><rect x="1.5" y="1.5" width="1.5" height="1.5" fill="#d9483b"/></pattern><radialGradient id="${p}c" cx="45%" cy="40%" r="62%"><stop offset="0" stop-color="#ffe58a"/><stop offset="1" stop-color="#eab348"/></radialGradient><clipPath id="${p}k"><rect width="${f1(w)}" height="${f1(h)}"/></clipPath></defs>`
      + `<g clip-path="url(#${p}k)"><rect width="${f1(w)}" height="${f1(h)}" fill="url(#${p}t)"/><ellipse cx="${f1(cx + 1)}" cy="${f1(cy + 1.4)}" rx="${f1(r * 1.02)}" ry="${f1(r * 0.98)}" fill="#000000" opacity="0.2"/>`
      + `<path d="${wedge(r)}" fill="#d9974c"/><path d="${wedge(r * 0.88)}" fill="#c8452e"/><path d="${wedge(r * 0.82)}" fill="url(#${p}c)"/>`
      + [[-0.5, -0.4], [0.2, -0.62], [-0.6, 0.3], [-0.05, 0.08], [0.15, 0.6], [-0.35, 0.68]].map(([a, b]) => pep(cx + a * r, cy + b * r, 1)).join('')
      + rep(5, i => `<ellipse cx="${f1(cx + (R() - 0.6) * r)}" cy="${f1(cy + (R() - 0.5) * r)}" rx="${f1(r * 0.08)}" ry="${f1(r * 0.04)}" fill="#3f8a3a" transform="rotate(${f1(R() * 180)} ${f1(cx)} ${f1(cy)})"/>`).join('')
      + `<g transform="translate(${f1(sx + r * 0.3)} ${f1(sy - r * 0.08)}) rotate(-8)"><path d="${sl(r)}" fill="#d9974c"/><path d="${sl(r * 0.88)}" fill="#c8452e"/><path d="${sl(r * 0.82)}" fill="url(#${p}c)"/>${pep(r * 0.5, -r * 0.04, 0.9)}</g>`
      + rep(3, i => `<path d="M${f1(cx + r * 0.8)} ${f1(cy - r * (0.2 - i * 0.14))}q${f1(r * 0.12)} ${f1(r * 0.05)} ${f1(r * 0.3)} ${f1(-r * 0.04)}" stroke="#ffe58a" stroke-width="${f1(r * 0.05)}" fill="none" stroke-linecap="round"/>`).join('')
      + rep(3, i => `<path d="M${f1(cx - r * 0.3 + i * r * 0.3)} ${f1(cy - r * 1.08)}q${f1(-r * 0.12)} ${f1(-r * 0.15)} 0 ${f1(-r * 0.3)}t0 ${f1(-r * 0.3)}" stroke="#ffffff" stroke-width="0.3" fill="none" opacity="0.7"/>`).join('')
      + `<rect width="${f1(w)}" height="${f1(h)}" fill="#ffe9b0" opacity="0.16"/></g><rect width="${f1(w)}" height="${f1(h)}" fill="none" stroke="#cbbd9c" stroke-width="0.3"/>`; };
  N.cal19 = S => { const W = 44, Hh = 72, PH = 29, Y0 = 6, YT = Y0 + Hh, X0 = -W / 2;
    const D = { w: 56, d: 4, mount: 'wall', elev: 44, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), d = new Date(), Yr = d.getFullYear(), Mo = d.getMonth(), td = d.getDate(), f0 = new Date(Yr, Mo, 1).getDay(), nd = new Date(Yr, Mo + 1, 0).getDate(), mk = new Set(String(S.ex || '').split(',').filter(Boolean).map(Number)), p = C.u('cl'), gy = PH + 1;
      const pg = `M0 ${gy}H${W}V${Hh - 6.5}L${W - 6.5} ${Hh}H0Z`;
      let g = `<rect x="0.8" y="${gy + 0.5}" width="${W - 0.3}" height="${Hh - gy}" fill="#d6c9ab"/><rect x="0.4" y="${gy + 0.25}" width="${W - 0.1}" height="${Hh - gy}" fill="#e8ddc3"/>`
        + `<rect width="${W}" height="${PH}" fill="#f8f1de"/><g transform="translate(2.2 2.2)">${pizzaPhoto(p, W - 4.4, PH - 8.4)}</g>`
        + T(W / 2, PH - 3.3, 3.2, '#c8342a', 'SQUISH PIZZA', 'letter-spacing="0.2"') + T(W / 2, PH - 1, 1.4, '#6b5a48', 'FREE DELIVERY · CALL 555-0199')
        + `<circle cx="${W / 2}" cy="1.8" r="0.95" fill="#4a3a28" opacity="0.7"/><rect width="${W}" height="${PH}" fill="#e8cf8a" opacity="0.12"/>`
        + `<path d="${pg}" fill="#fbf6e7"/><rect x="1.4" y="${gy + 1.4}" width="${W - 2.8}" height="4.8" fill="#d9483b"/>` + T(W / 2, gy + 4.9, 2.9, '#ffffff', MONTHS[Mo] + ' ' + Yr, 'letter-spacing="0.25"');
      const cw = (W - 4) / 7, cx = i => 2 + cw * (i + 0.5), rows = Math.ceil((f0 + nd) / 7);
      'SMTWTFS'.split('').forEach((w, i) => g += T(cx(i), gy + 9.4, 1.9, i ? '#6b4426' : '#d9483b', w));
      for (let r = 0; r <= rows; r++) g += `<path d="M2 ${f1(gy + 10.5 + r * 4.5)}H${r === rows ? W - 7 : W - 2}" stroke="#ddcfae" stroke-width="0.18"/>`;
      for (let i = 0; i < nd; i++) { const cell = f0 + i, x = cx(cell % 7), y = gy + 13.9 + Math.floor(cell / 7) * 4.5, day = i + 1;
        if (day === td) g += `<circle cx="${f1(x)}" cy="${f1(y - 0.8)}" r="2" fill="none" stroke="#d9483b" stroke-width="0.5">${an('r', '2;2.35;2', 1.6)}</circle>`;
        g += T(x, y, 2.3, day === td ? '#d9483b' : '#3b2614', day);
        if (day < td) g += `<path d="M${f1(x - 1.5)} ${f1(y - 2.4)}L${f1(x + 1.5)} ${f1(y + 0.5)}M${f1(x + 1.4)} ${f1(y - 2.5)}L${f1(x - 1.4)} ${f1(y + 0.6)}" stroke="#d9483b" stroke-width="0.32" stroke-linecap="round" opacity="0.6"/>`;
        if (mk.has(day)) g += `<circle cx="${f1(x + 1.9)}" cy="${f1(y - 2.6)}" r="0.95" fill="#3f9a5a" stroke="#ffffff" stroke-width="0.25"/>`; }
      g += T(W / 2 - 3, Hh - 1.2, 1.6, '#8a5a34', 'Today · ' + DAYS[d.getDay()] + ' ' + td);
      g += `<circle cx="${W * 0.72}" cy="${gy + 23}" r="4" fill="none" stroke="#a0703c" stroke-width="0.45" opacity="0.22" stroke-dasharray="16 2 5 1.5"/>`;
      g += rep(12, i => { const x = 3 + i * 3.45; return `<ellipse cx="${f1(x + 0.4)}" cy="${f1(PH - 1)}" rx="0.45" ry="0.32" fill="#4a3a28"/><ellipse cx="${f1(x + 0.4)}" cy="${f1(gy + 1.1)}" rx="0.45" ry="0.32" fill="#4a3a28"/><path d="M${f1(x + 0.4)} ${f1(gy + 1.1)}C${f1(x - 1)} ${f1(gy + 0.5)} ${f1(x - 1)} ${f1(PH - 0.4)} ${f1(x + 0.4)} ${f1(PH - 1)}" stroke="#6d747c" stroke-width="0.55" fill="none"/><path d="M${f1(x + 0.1)} ${f1(gy + 0.7)}C${f1(x - 0.6)} ${f1(gy + 0.3)} ${f1(x - 0.6)} ${f1(PH - 0.1)} ${f1(x + 0.1)} ${f1(PH - 0.6)}" stroke="#e6eaee" stroke-width="0.16" fill="none"/>`; }).join('');
      const c1 = [W - 6.5, Hh], c2 = [W, Hh - 6.5], fl = (t, q1, q2) => `M${P2(c1)}L${P2(c2)}Q${P2(q1)} ${P2(t)}Q${P2(q2)} ${P2(c1)}Z`, d1 = fl([W - 5.6, Hh - 5.6], [W - 2.6, Hh - 5.2], [W - 5.2, Hh - 2.6]), d2 = fl([W - 4.4, Hh - 4.6], [W - 2, Hh - 4.2], [W - 4.2, Hh - 2]);
      g += `<path d="${d1}" fill="#000000" opacity="0.25" transform="translate(-0.5 -0.6)" filter="url(#m12b1)"/><path d="${d1}" fill="#efe6cf" stroke="#cbbd9c" stroke-width="0.2"><animate attributeName="d" values="${d1};${d2};${d1}" dur="3.8s" repeatCount="indefinite"${SPL(2)}/></path>`;
      g += `<path d="M0 0H${W}V${Hh - 6.5}L${W - 6.5} ${Hh}H0Z" fill="url(#m12gl)" opacity="0.5"/>`;
      // pencil hanging on a string from the nail, swinging a little
      const nx = W / 2, ny = -1.4, pen = `<path d="M${nx} ${ny}Q${W + 2.4} 8 ${W + 3.2} 24" stroke="#bdb3a0" stroke-width="0.24" fill="none"/><g transform="translate(${W + 2.4} 24)"><rect width="1.6" height="1.6" rx="0.4" fill="#ef8f9c"/><rect y="1.5" width="1.6" height="1.2" fill="#c9ccd0"/><path d="M0 2.1H1.6" stroke="#8a8f96" stroke-width="0.15"/><rect y="2.7" width="1.6" height="10.6" fill="#f2c230"/><rect x="0.55" y="2.7" width="0.5" height="10.6" fill="#ffdd6a"/><rect x="1.2" y="2.7" width="0.4" height="10.6" fill="#d4a21a"/><path d="M0 13.3H1.6L0.8 15.6Z" fill="#ecc38a"/><path d="M0.5 14.7H1.1L0.8 15.6Z" fill="#3a3a3a"/></g>`;
      let s = wsh(C, X0, YT, W, Hh, { dx: 1.2, dy: 2.2, op: 0.36 });
      s += WD(C, X0, YT, 0.06, `<g opacity="0.22" filter="url(#m12b1)" transform="translate(1 1.6)">${pen.replace(/fill="[^"]*"/g, 'fill="#000000"').replace(/stroke="#bdb3a0"/, 'stroke="#000000"')}</g>`);
      s += WD(C, X0, YT, 0.7, g, W, Hh);
      const pv = `${f1(nx)} ${f1(ny)}`; s += WD(C, X0, YT, 1.1, `<g>${at('rotate', `-3 ${pv};4 ${pv};-3 ${pv}`, 4.6, 0, SPL(2))}${pen}</g>`);
      ext(C, [[X0 + W + 5, YT - 42, 1.1]]);
      s += cyl3(C, [0, YT + 1.4, 0], [0, YT + 1.4, 1.8], 0.35, '#8a8f96') + sph(C, [0, YT + 1.4, 1.9], 0.85, '#9aa0a8');
      return { defs: DEF19, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= LIV-024 ROUND BRASS-RIM MIRROR ON A LEATHER STRAP =======================
  N.rmir19 = S => { const R0 = 19, CY = 30, BR = '#c99a3e', LE = '#7a4a26', PY = CY + R0 + 13;
    const D = { w: 46, d: 6, mount: 'wall', elev: 52, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), id = C.u('rm'), top = -(CY + R0 - 4.5);
      const strap = `M-10.5 ${f1(top)}L0 ${-PY}L10.5 ${f1(top)}`;
      let s = WD(C, 0, 0, 0.06, `<circle cx="1.6" cy="${-CY + 2.6}" r="${R0}" fill="#000000" opacity="0.38" filter="url(#m10b3)"/><path d="${strap}" transform="translate(0.8 1.6)" stroke="#000000" stroke-width="3" fill="none" opacity="0.22" stroke-linejoin="round" filter="url(#m12b1)"/>`);
      s += WD(C, 0, 0, 1.6, `<path d="${strap}" stroke="${LE}" stroke-width="3.2" fill="none" stroke-linejoin="round"/><path d="${strap}" stroke="${shade(LE, 1.25)}" stroke-width="2.2" fill="none" stroke-linejoin="round"/><path d="${strap}" stroke="#f0d2a4" stroke-width="0.22" stroke-dasharray="0.8 0.6" fill="none" stroke-linejoin="round" opacity="0.8"/><path d="M-9 ${f1(top - 1.4)}L-1.4 ${-PY + 1.6}" stroke="#ffffff" stroke-width="0.4" opacity="0.25"/>`);
      ext(C, [[-12, PY + 2, 0], [12, CY - R0, 0]]);
      s += cyl3(C, [0, PY, 0], [0, PY, 3.2], 1.2, BR) + sph(C, [0, PY, 3.6], 1.9, BR);
      s += cyl3(C, [0, CY, 0.5], [0, CY, 3.6], R0, BR, { mat: 'gloss', n: 44, capCol: BR, cap: cr => { const rg = cr * 0.84;
        return `<defs><radialGradient id="${id}r" cx="35%" cy="28%" r="80%"><stop offset="0" stop-color="#fff2c4"/><stop offset="0.45" stop-color="#dcaa4c"/><stop offset="1" stop-color="#8a6420"/></radialGradient><linearGradient id="${id}g" x1="0" y1="0" x2="0.35" y2="1"><stop offset="0" stop-color="#eef3f4"/><stop offset="0.5" stop-color="#c3cfd4"/><stop offset="1" stop-color="#93a3aa"/></linearGradient><linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.55"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient><clipPath id="${id}c"><circle r="${f1(rg)}"/></clipPath></defs>`
          + `<circle r="${f1(cr)}" fill="url(#${id}r)"/><circle r="${f1(cr * 0.955)}" fill="none" stroke="#fff3c8" stroke-width="${f1(cr * 0.02)}" opacity="0.75"/><circle r="${f1(cr * 0.885)}" fill="none" stroke="#7a5418" stroke-width="${f1(cr * 0.035)}"/>`
          + `<g clip-path="url(#${id}c)"><circle r="${f1(rg)}" fill="url(#${id}g)"/><rect x="${f1(-rg)}" y="${f1(-rg)}" width="${f1(2 * rg)}" height="${f1(rg * 1.15)}" fill="#e9dcc0" opacity="0.4"/><rect x="${f1(-rg)}" y="${f1(rg * 0.18)}" width="${f1(2 * rg)}" height="${f1(rg)}" fill="#b98a58" opacity="0.4"/>`
          + `<rect x="${f1(-rg * 0.72)}" y="${f1(-rg * 0.82)}" width="${f1(rg * 0.5)}" height="${f1(rg * 0.72)}" fill="#ffffff" opacity="0.6"/><path d="M${f1(-rg * 0.47)} ${f1(-rg * 0.82)}V${f1(-rg * 0.1)}M${f1(-rg * 0.72)} ${f1(-rg * 0.46)}H${f1(-rg * 0.22)}" stroke="#d9cdb4" stroke-width="${f1(rg * 0.04)}"/>`
          + `<ellipse cx="${f1(rg * 0.4)}" cy="${f1(rg * 0.35)}" rx="${f1(rg * 0.32)}" ry="${f1(rg * 0.2)}" fill="#7f9a6e" opacity="0.4"/><g transform="rotate(28)"><rect x="${f1(-rg * 2)}" y="${f1(-rg * 1.4)}" width="${f1(rg * 0.4)}" height="${f1(rg * 2.8)}" fill="url(#${id}s)">${at('translate', `0 0;0 0;${f1(rg * 3.6)} 0`, 7.5, 0, ' keyTimes="0;0.5;1"')}</rect></g>`
          + `<path d="M${f1(-rg * 0.75)} ${f1(-rg * 0.2)}A${f1(rg * 0.78)} ${f1(rg * 0.78)} 0 0 1 ${f1(-rg * 0.2)} ${f1(-rg * 0.75)}" stroke="#ffffff" stroke-width="${f1(rg * 0.05)}" fill="none" opacity="0.55" stroke-linecap="round"/></g>`
          + `<circle r="${f1(rg)}" fill="none" stroke="#ffffff" stroke-width="${f1(rg * 0.04)}" opacity="0.6"/><circle r="${f1(rg * 0.97)}" fill="none" stroke="#5a6a70" stroke-width="${f1(rg * 0.015)}" opacity="0.5"/>`; } });
      return { defs: DEF19, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= LIV-044 TRIPTYCH OF TEXTURED GALLERY-WRAPPED CANVASES (one abstract across all three) =======================
  const triArt = () => { const R = rng('tri19');
    const imp = (x, y, l, a, col) => { const dx = l * Math.cos(a), dy = l * Math.sin(a), d = `M${f1(x)} ${f1(y)}q${f1(dx / 2 - dy * 0.2)} ${f1(dy / 2 + dx * 0.2)} ${f1(dx)} ${f1(dy)}`;
      return `<path d="${d}" stroke="#000000" stroke-opacity="0.2" stroke-width="1.5" fill="none" stroke-linecap="round" transform="translate(0.3 0.35)"/><path d="${d}" stroke="${col}" stroke-width="1.35" fill="none" stroke-linecap="round"/><path d="${d}" stroke="#ffffff" stroke-opacity="0.4" stroke-width="0.4" fill="none" stroke-linecap="round" transform="translate(-0.25 -0.3)"/>`; };
    let s = '<rect width="100" height="44" fill="#efe5d1"/>' + rep(46, () => { const x = R() * 100, y = R() * 44, l = 3 + R() * 6, a = (R() - 0.5) * 0.6; return `<path d="M${f1(x)} ${f1(y)}l${f1(l * Math.cos(a))} ${f1(l * Math.sin(a))}" stroke="${R() < 0.5 ? '#f8f0e1' : '#dfd2b8'}" stroke-width="${f1(0.6 + R() * 0.9)}" stroke-linecap="round" opacity="0.75"/>`; }).join('');
    s += '<rect x="64" y="21" width="32" height="23" fill="#d6a03c"/><path d="M5 44A25 25 0 0 1 55 44Z" fill="#c25f3b"/><path d="M14 44A16 16 0 0 1 46 44" fill="none" stroke="#e48f69" stroke-width="3"/><circle cx="58" cy="15" r="10" fill="#8ca584"/><circle cx="84" cy="11" r="4.4" fill="#e7b39e"/><path d="M76 34H100" stroke="#efe5d1" stroke-width="1.2"/>';
    for (let i = 0; i < 14; i++) { const th = PI + R() * PI, rr = 5 + R() * 18; s += imp(30 + rr * Math.cos(th), 44 + rr * Math.sin(th), 2.4 + R() * 3, th + PI / 2, shade('#c25f3b', 0.88 + R() * 0.3)); }
    for (let i = 0; i < 8; i++) { const th = R() * 2 * PI, rr = R() * 8; s += imp(58 + rr * Math.cos(th), 15 + rr * Math.sin(th), 2 + R() * 2.4, th + PI / 2, shade('#8ca584', 0.88 + R() * 0.3)); }
    for (let i = 0; i < 9; i++) s += imp(66 + R() * 26, 23 + R() * 18, 3 + R() * 3, (R() - 0.5) * 0.5, shade('#d6a03c', 0.86 + R() * 0.3));
    s += '<path d="M3 11C30 2 50 31 97 15" fill="none" stroke="#2c3b5a" stroke-width="1.15" stroke-linecap="round"/><path d="M3 11C30 2 50 31 97 15" fill="none" stroke="#ffffff" stroke-width="0.3" stroke-opacity="0.35" transform="translate(-0.2 -0.3)"/>';
    s += rep(9, () => `<path d="M${f1(R() * 100)} ${f1(R() * 44)}l0.9 -0.4l0.5 0.8l-0.8 0.5Z" fill="#e8c35a"/>`).join('') + rep(12, () => `<circle cx="${f1(R() * 100)}" cy="${f1(R() * 44)}" r="${f1(0.25 + R() * 0.35)}" fill="#2c3b5a" opacity="0.8"/>`).join('');
    return s + '<rect width="100" height="44" fill="url(#tw19)"/>'; };
  N.trip19 = S => { const FS = [-35, 0, 35], CW = 30, Hh = 44, Y0 = 6, DP = 3.2;
    const D = { w: 108, d: 6, mount: 'wall', elev: 46, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), aid = C.u('ta'), art = `<use href="#${aid}"/>`; let s = '', defs = `<g id="${aid}">${triArt()}</g>`;
      FS.forEach((x, i) => { const ox = i * 35, p = C.u('tc'), sideCol = '#000000';
        defs += `<clipPath id="${p}"><rect width="${CW}" height="${Hh}"/></clipPath><clipPath id="${p}s"><rect width="${DP}" height="${Hh}"/></clipPath><clipPath id="${p}t"><rect width="${CW}" height="${DP}"/></clipPath>`;
        const face = `<g clip-path="url(#${p})"><g transform="translate(${-ox} 0)">${art}</g></g><rect width="${CW}" height="${Hh}" fill="url(#m12gl)" opacity="0.35"/>`;
        const sideR = `<g clip-path="url(#${p}s)"><g transform="matrix(${-DP} 0 0 1 ${f1((ox + CW) * DP)} 0)">${art}</g></g><rect width="${DP}" height="${Hh}" fill="${sideCol}" opacity="0.16"/>`;
        const sideL = `<g clip-path="url(#${p}s)"><g transform="matrix(${-DP} 0 0 1 ${f1((ox + 1) * DP)} 0)">${art}</g></g><rect width="${DP}" height="${Hh}" fill="${sideCol}" opacity="0.28"/>`;
        const topF = `<g clip-path="url(#${p}t)"><g transform="matrix(1 0 0 ${-DP} ${-ox} ${DP})">${art}</g></g><rect width="${CW}" height="${DP}" fill="#ffffff" opacity="0.12"/>`;
        s += wsh(C, x - CW / 2, Y0 + Hh, CW, Hh, { dx: 1.8, dy: 2.8, op: 0.42 });
        s += box3(C, { c: [x, Y0, DP / 2], w: CW, h: Hh, d: DP, r: 0.2, col: '#e7dcc6', dec: { f: face, r: sideR, l: sideL, t: topF } }); });
      return { defs: DEF19 + `<defs>${defs}</defs>`, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= LIV-064 VENETIAN ETCHED MIRROR WITH A NEON SCRIPT =======================
  const archPts = (x0, y0, w, h, n) => { const r = w / 2, L = h - r, A = PI * r, tot = 2 * L + A; return rep(n + 1, i => { const s = tot * i / n;
    if (s <= L) return [x0, y0 + h - s]; if (s <= L + A) { const a = PI - (s - L) / r; return [x0 + r + r * Math.cos(a), y0 + r - r * Math.sin(a)]; } return [x0 + w, y0 + r + (s - L - A)]; }); };
  const archD = (x0, y0, w, h) => `M${f1(x0)} ${f1(y0 + h)}V${f1(y0 + w / 2)}A${f1(w / 2)} ${f1(w / 2)} 0 0 1 ${f1(x0 + w)} ${f1(y0 + w / 2)}V${f1(y0 + h)}Z`;
  N.venet19 = S => { const W = 52, Hh = 74, Y0 = 6, BW = 7.5, X0 = -W / 2, YT = Y0 + Hh;
    const D = { w: 58, d: 8, mount: 'wall', elev: 46, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), id = C.u('vn'), oD = archD(0, 0, W, Hh), iD = archD(BW, BW, W - 2 * BW, Hh - 2 * BW), n = 22, Po = archPts(0, 0, W, Hh, n), Pi = archPts(BW, BW, W - 2 * BW, Hh - 2 * BW, n);
      let s = WD(C, X0 - 12, YT + 12, 0.05, `<rect width="${W + 24}" height="${Hh + 24}" rx="26" fill="#ff4fa0" opacity="0.32" filter="url(#m11b8)">${an('opacity', '0.24;0.38;0.26;0.36;0.24', 3.4)}</rect>`);
      s += WD(C, X0, YT, 0.06, `<path d="${oD}" fill="#000000" opacity="0.4" transform="translate(1.4 2.2)" filter="url(#m12b1)"/>`);
      [0.3, 0.7].forEach((z, i) => s += WD(C, X0, YT, z, `<path d="${oD}" fill="${i ? '#5f666c' : '#3c4146'}"/>`));
      let seg = `<defs><linearGradient id="${id}a" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f8fa"/><stop offset="0.5" stop-color="#b9c6cc"/><stop offset="1" stop-color="#e3eaee"/></linearGradient><linearGradient id="${id}b" x1="1" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d8e2e6"/><stop offset="0.5" stop-color="#93a4ac"/><stop offset="1" stop-color="#c6d2d7"/></linearGradient>`
        + `<linearGradient id="${id}m" x1="0" y1="0" x2="0.4" y2="1"><stop offset="0" stop-color="#e6edf0"/><stop offset="0.55" stop-color="#b6c4cb"/><stop offset="1" stop-color="#8f9fa7"/></linearGradient><radialGradient id="${id}p" cx="50%" cy="55%" r="60%"><stop offset="0" stop-color="#ff7fbf" stop-opacity="0.55"/><stop offset="1" stop-color="#ff7fbf" stop-opacity="0"/></radialGradient>`
        + `<linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient><clipPath id="${id}c"><path d="${iD}"/></clipPath></defs>`;
      for (let i = 0; i < n; i++) { const a = Po[i], b = Po[i + 1], c = Pi[i + 1], e = Pi[i], m = [(a[0] + b[0] + c[0] + e[0]) / 4, (a[1] + b[1] + c[1] + e[1]) / 4];
        seg += `<path d="M${P2(a)}L${P2(b)}L${P2(c)}L${P2(e)}Z" fill="url(#${id}${i % 2 ? 'a' : 'b'})" stroke="#6f7c84" stroke-width="0.22"/><path d="M${P2(a)}L${P2(b)}" stroke="#ffffff" stroke-width="0.35" opacity="0.8"/>`
          + `<g transform="translate(${P2(m)})" stroke="#ffffff" stroke-width="0.22" fill="none" opacity="0.75"><path d="M0 -1.6Q1 0 0 1.6Q-1 0 0 -1.6ZM-1.6 0Q0 1 1.6 0Q0 -1 -1.6 0Z"/><circle r="0.35"/></g>`; }
      seg += `<g clip-path="url(#${id}c)"><path d="${iD}" fill="url(#${id}m)"/><rect x="${BW}" y="${Hh * 0.55}" width="${W - 2 * BW}" height="${Hh * 0.45}" fill="#c9a77a" opacity="0.28"/><rect width="${W}" height="${Hh}" fill="url(#${id}p)"/>`
        + `<g transform="rotate(24)"><rect x="-40" y="-20" width="9" height="${Hh + 40}" fill="url(#${id}s)">${at('translate', '0 0;0 0;80 0', 8, 0, ' keyTimes="0;0.55;1"')}</rect></g></g>`
        + `<path d="${iD}" fill="none" stroke="#ffffff" stroke-width="0.6" opacity="0.7"/><path d="${archD(BW + 1.6, BW + 1.6, W - 2 * BW - 3.2, Hh - 2 * BW - 3.2)}" fill="none" stroke="#ffffff" stroke-width="0.25" stroke-dasharray="0.5 0.8" opacity="0.7"/>`
        + `<path d="${oD}" fill="none" stroke="#56636a" stroke-width="0.4"/>`;
      s += WD(C, X0, YT, 1.1, seg, W, Hh);
      const crest = `M${W / 2 - 9} 3Q${W / 2 - 8} -3 ${W / 2 - 4} -2Q${W / 2 - 3} -7 ${W / 2} -7.6Q${W / 2 + 3} -7 ${W / 2 + 4} -2Q${W / 2 + 8} -3 ${W / 2 + 9} 3Z`;
      s += WD(C, X0, YT, 1.3, `<path d="${crest}" fill="url(#${id}a)" stroke="#6f7c84" stroke-width="0.25"/><path d="M${W / 2 - 4} -2Q${W / 2} 0 ${W / 2 + 4} -2M${W / 2} -6.4V-1" stroke="#ffffff" stroke-width="0.3" fill="none" opacity="0.8"/>`);
      ext(C, [[0, YT + 8, 1.3]]);
      Po.filter((q, i) => i % 2 === 0).forEach(q => s += sph(C, [X0 + q[0], YT - q[1], 1.5], 0.8, '#dfe8ec'));
      [[-12, 30], [12, 30], [-12, 58], [12, 58]].forEach(([x, y]) => s += cyl3(C, [x, Y0 + y, 1.2], [x, Y0 + y, 3.3], 0.5, '#d9dce0'));
      const fs = 10.5, tw = W - 2 * BW - 4, ty = Hh * 0.52, txt = (st, ex) => `<text x="${W / 2}" y="${f1(ty)}" text-anchor="middle" font-family="${SCRIPT}" font-size="${fs}" textLength="${f1(tw)}" lengthAdjust="spacingAndGlyphs" ${st}>${ex || ''}hey cutie</text>`;
      const heart = `M${W / 2} ${f1(ty + 9.6)}C${W / 2 - 3.6} ${f1(ty + 6.8)} ${W / 2 - 3} ${f1(ty + 3.4)} ${W / 2} ${f1(ty + 5)}C${W / 2 + 3} ${f1(ty + 3.4)} ${W / 2 + 3.6} ${f1(ty + 6.8)} ${W / 2} ${f1(ty + 9.6)}Z`;
      const FLK = an('opacity', '1;1;0.3;1;0.5;1;1', 7, 0, ' keyTimes="0;0.78;0.79;0.81;0.82;0.84;1"');
      s += WD(C, X0, YT, 3.4, `<g filter="url(#m12b2)" opacity="0.65">${txt('fill="none" stroke="#ff4fa0" stroke-width="2.4"')}<path d="${heart}" fill="none" stroke="#5ff0ff" stroke-width="2.2"/></g>`
        + txt('fill="#ff6fb4" stroke="#ff4fa0" stroke-width="0.5"') + txt('fill="#ffe2f1" opacity="0.7"') + `<g>${FLK}<path d="${heart}" fill="none" stroke="#5ff0ff" stroke-width="0.9"/><path d="${heart}" fill="none" stroke="#e8feff" stroke-width="0.3"/></g>`);
      return { defs: DEF19, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= LIV-084 LIVING OIL MASTERPIECE IN A CARVED GILT FRAME (keeps the 5 living paintings) =======================
  N.master19 = S => { const FW = 128, FH = 102, HL = 12.5, HT = 13.5, HB = 11.5, Dp = 6, GOLD = '#d2a23e';
    const D = { w: 132, d: 18, mount: 'wall', elev: 34, build: () => [] };
    const orn = () => { let o = `<path d="M0 0H${FW}V${FH}H0ZM${HL} ${HT}V${FH - HB}H${FW - HL}V${HT}Z" fill="url(#gd19)" fill-rule="evenodd"/>`;
      o += `<rect x="2.4" y="2.4" width="${FW - 4.8}" height="${FH - 4.8}" fill="none" stroke="#8a6420" stroke-width="0.5"/><rect x="${HL - 2.6}" y="${HT - 2.6}" width="${FW - 2 * HL + 5.2}" height="${FH - HT - HB + 5.2}" fill="none" stroke="#fff1b0" stroke-width="0.5" opacity="0.8"/>`;
      const beads = (x0, y0, x1, y1, n) => rep(n, i => { const t = (i + 0.5) / n, x = x0 + (x1 - x0) * t, y = y0 + (y1 - y0) * t; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.65" fill="#f6dc8a" stroke="#8a6420" stroke-width="0.18"/>`; }).join('');
      const bi = HL - 1.3; o += beads(bi, HT - 1.3, FW - bi, HT - 1.3, 46) + beads(bi, FH - HB + 1.3, FW - bi, FH - HB + 1.3, 46) + beads(bi, HT - 1.3, bi, FH - HB + 1.3, 36) + beads(FW - bi, HT - 1.3, FW - bi, FH - HB + 1.3, 36);
      const leaf = (x, y, rot) => `<g transform="translate(${f1(x)} ${f1(y)}) rotate(${rot})"><path d="M-2.2 0Q-2 -2.6 0 -3.2Q2 -2.6 2.2 0Q1 -0.6 0 0.4Q-1 -0.6 -2.2 0Z" fill="#e8c062" stroke="#8a6420" stroke-width="0.2"/><path d="M0 -2.8V0" stroke="#8a6420" stroke-width="0.2"/></g>`;
      for (let x = 10; x < FW - 8; x += 5.4) o += leaf(x, 7.2, 0) + leaf(x, FH - 5.2, 180);
      for (let y = 12; y < FH - 10; y += 5.4) o += leaf(5.2, y, 270) + leaf(FW - 5.2, y, 90);
      [[6, 6], [FW - 6, 6], [6, FH - 6], [FW - 6, FH - 6]].forEach(([x, y]) => o += `<circle cx="${x}" cy="${y}" r="4.4" fill="#e8c062" stroke="#8a6420" stroke-width="0.3"/>` + rep(8, i => `<path d="M${x} ${y}l${f1(4 * Math.cos(i * PI / 4))} ${f1(4 * Math.sin(i * PI / 4))}" stroke="#8a6420" stroke-width="0.25"/>`).join('') + `<circle cx="${x}" cy="${y}" r="1.6" fill="#fff1b0" stroke="#8a6420" stroke-width="0.25"/>`);
      o += `<path d="M${FW / 2 - 12} 2.6Q${FW / 2 - 6} -1 ${FW / 2} 1.4Q${FW / 2 + 6} -1 ${FW / 2 + 12} 2.6Q${FW / 2 + 6} 6 ${FW / 2} 9Q${FW / 2 - 6} 6 ${FW / 2 - 12} 2.6Z" fill="#f2d07a" stroke="#8a6420" stroke-width="0.3"/><circle cx="${FW / 2}" cy="4.6" r="1.8" fill="#fff1b0" stroke="#8a6420" stroke-width="0.25"/>`;
      o += `<rect x="${FW / 2 - 15}" y="${FH - 9.4}" width="30" height="5" rx="0.6" fill="url(#br19)" stroke="#7a5418" stroke-width="0.2"/>` + T(FW / 2, FH - 6, 2.4, '#4a3410', (S.st || 'Sunset Sea').toUpperCase(), 'letter-spacing="0.2"');
      return o; };
    D.fx = ctx => { const C = cam(ctx), F0 = N.masterpiece(S).fx(ctx) || {}; let s = '';
      s += WD(C, -FW / 2 - 6, FH + 14, 0.05, `<path d="M${FW / 2 - 14} 0H${FW / 2 + 32}L${FW + 12} ${FH * 0.75}H0Z" fill="#fff0c8" opacity="0.16" filter="url(#m12b2)">${an('opacity', '0.12;0.2;0.12', 5, 0, SPL(2))}</path>`);
      s += wsh(C, -FW / 2, FH, FW, FH, { dx: 2.8, dy: 3.6, op: 0.5 });
      s += WD(C, -54, 91, 2.6, '<rect width="108" height="82" fill="#2a2440"/>');
      s += F0.front || '';
      s += innerW(C, -FW / 2 + HL, FW / 2 - HL, HB, FH - HT, 2.9, Dp, '#b88a30', 0.9);
      s += box3(C, { c: [0, 0, Dp / 2], w: FW, h: FH, d: Dp, r: 0.6, col: GOLD, hole: { f: [HL, HT, HL, HB] }, dec: { f: orn() } });
      s += pane(C, [-FW / 2 + HL, FH - HT, Dp - 0.6], [1, 0, 0], [0, -1, 0], FW - 2 * HL, FH - HT - HB, { t: 0.03, g: 0.7, e: 0.2 });
      [-22, 22].forEach(x => s += cyl3(C, [x, FH - 1, 3], [x, FH + 5.5, 11.5], 0.55, '#c99a3e'));
      s += cyl3(C, [-30, FH + 6.4, 12.6], [30, FH + 6.4, 12.6], 2.6, '#c99a3e', { mat: 'gloss', n: 20 }) + sph(C, [-30.6, FH + 6.4, 12.6], 2.7, '#c99a3e') + sph(C, [30.6, FH + 6.4, 12.6], 2.7, '#c99a3e');
      const lq = C.p(0, FH + 4, 12.6); s += `<ellipse cx="${f1(lq[0])}" cy="${f1(lq[1] + C.k)}" rx="${f1(28 * C.k)}" ry="${f1(1.3 * C.k)}" fill="#fff4c8" opacity="0.85">${an('opacity', '0.7;0.95;0.7', 5, 0, SPL(2))}</ellipse>`;
      s += WD(C, -FW / 2 + HL, FH - HT, 3, `<defs><linearGradient id="mpw19" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0c0" stop-opacity="0.32"/><stop offset="0.55" stop-color="#fff0c0" stop-opacity="0.05"/><stop offset="1" stop-color="#fff0c0" stop-opacity="0"/></linearGradient></defs><path d="M${(FW - 2 * HL) / 2 - 30} 0H${(FW - 2 * HL) / 2 + 30}L${FW - 2 * HL} ${(FH - HT - HB) * 0.8}H0Z" fill="url(#mpw19)"/>`);
      return { defs: DEF19 + (F0.defs || ''), front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= WALL QUOTES (custom text) =======================
  const qt = S => (S.txt || (S.row && S.row.txt0) || 'Home Sweet Home').slice(0, 26), qw = (t, k, a, b) => Math.max(a, Math.min(b, 24 + t.length * k));
  // LIV-101 hand-lettered paper banner: swallowtail paper on twine with two wooden clothespins, two-tone marker letters + doodles, sways a little
  N.qPaper19 = S => { const t = qt(S), W = qw(t, 5.8, 62, 150), Hh = 22, Y0 = 22, YT = Y0 + Hh, X0 = -W / 2;
    const D = { w: W + 18, d: 4, mount: 'wall', elev: 50, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), ban = `M0 0H${W}L${f1(W - 5)} ${Hh / 2}L${W} ${Hh}H0L5 ${Hh / 2}Z`, tw = `M-9 -5Q${f1(W / 2)} 5 ${f1(W + 9)} -5`, fs = 10, tl = W - 20;
      const tx = (st, dx) => `<text x="${f1(W / 2 + (dx || 0))}" y="${f1(Hh / 2 + 3.4 + (dx || 0))}" text-anchor="middle" font-family="${HAND}" font-weight="700" font-size="${fs}" textLength="${f1(tl)}" lengthAdjust="spacingAndGlyphs" ${st}>${xe(t)}</text>`;
      const star = (x, y, r, c) => `<path d="M${x} ${f1(y - r)}L${f1(x + r * 0.3)} ${f1(y - r * 0.3)}L${f1(x + r)} ${y}L${f1(x + r * 0.3)} ${f1(y + r * 0.3)}L${x} ${f1(y + r)}L${f1(x - r * 0.3)} ${f1(y + r * 0.3)}L${f1(x - r)} ${y}L${f1(x - r * 0.3)} ${f1(y - r * 0.3)}Z" fill="${c}"/>`;
      const hrt = (x, y, r, c) => `<path d="M${x} ${f1(y + r)}C${f1(x - r * 1.4)} ${f1(y)} ${f1(x - r)} ${f1(y - r * 1.2)} ${x} ${f1(y - r * 0.4)}C${f1(x + r)} ${f1(y - r * 1.2)} ${f1(x + r * 1.4)} ${y} ${x} ${f1(y + r)}Z" fill="${c}"/>`;
      let b = `<path d="${ban}" fill="#fbf6ea" stroke="#d9cdb2" stroke-width="0.3"/>` + rep(6, i => `<rect x="${f1(5 + i * (W - 10) / 6)}" width="${f1((W - 10) / 12)}" height="${Hh}" fill="#000000" opacity="0.025"/>`).join('')
        + [W / 3, 2 * W / 3].map(x => `<path d="M${f1(x)} 0.4V${Hh - 0.4}" stroke="#000000" stroke-opacity="0.1" stroke-width="0.35"/><path d="M${f1(x + 0.35)} 0.4V${Hh - 0.4}" stroke="#ffffff" stroke-width="0.3"/>`).join('')
        + tx('fill="#ff9fb4"', 0.55) + tx('fill="#3654a8"') + `<path d="M${f1(W * 0.2)} ${Hh - 3}q${f1(W * 0.05)} -1.4 ${f1(W * 0.1)} 0t${f1(W * 0.1)} 0t${f1(W * 0.1)} 0t${f1(W * 0.1)} 0t${f1(W * 0.1)} 0t${f1(W * 0.1)} 0" stroke="#e0533a" stroke-width="0.55" fill="none" stroke-linecap="round"/>`
        + star(8.6, 4.2, 1.6, '#f2b632') + star(W - 8.6, 4.4, 1.4, '#f2b632') + hrt(8.8, Hh - 5, 1.6, '#e0533a') + hrt(W - 8.8, Hh - 5, 1.4, '#e0533a') + `<path d="${ban}" fill="url(#m12gl)" opacity="0.5"/>`;
      const pins = [W * 0.2, W * 0.8];
      let sw = WD(C, X0, YT, 1.4, b, W, Hh) + WD(C, X0, YT, 1.9, `<path d="${tw}" stroke="#a8875a" stroke-width="0.55" fill="none"/><path d="${tw}" stroke="#e2c79a" stroke-width="0.2" stroke-dasharray="0.6 0.6" fill="none"/>`);
      pins.forEach(x => sw += box3(C, { c: [X0 + x, YT - 3.2, 2.1], w: 1.9, h: 6, d: 1.3, r: 0.3, col: '#d9b27a' }) + cyl3(C, [X0 + x - 1.05, YT + 0.6, 2.1], [X0 + x + 1.05, YT + 0.6, 2.1], 0.35, '#b8bcc2'));
      const pv = C.p(0, YT + 1, 1.6), pq = P2(pv);
      let s = WD(C, X0, YT, 0.06, `<path d="${ban}" fill="#000000" opacity="0.28" transform="translate(1 2)" filter="url(#m12b1)"/><path d="${tw}" stroke="#000000" stroke-width="0.6" opacity="0.18" fill="none" transform="translate(0.6 1.2)"/>`);
      [-9, W + 9].forEach(x => s += sph(C, [X0 + x, YT + 5, 0.8], 1, '#d9483b'));
      s += `<g>${at('rotate', `-0.7 ${pq};0.7 ${pq};-0.7 ${pq}`, 4.4, 0, SPL(2))}${sw}</g>`;
      return { defs: DEF19, front: s, bb: C.bb(4) }; };
    return D; };

  // LIV-102 painted driftwood plank on a jute rope, swinging slowly from its nail
  N.qDrift19 = S => { const t = qt(S), W = qw(t, 6, 66, 156), Hh = 20, Y0 = 20, YT = Y0 + Hh, NY = YT + 13, DP = 3.4, WC = '#b8a68b';
    const D = { w: W + 10, d: 6, mount: 'wall', elev: 48, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('dw' + W), id = C.u('dw');
      let gr = rep(9, i => { const y = 2 + i * 2 + (R() - 0.5); return `<path d="M0 ${f1(y)}C${f1(W * 0.25)} ${f1(y + (R() - 0.5) * 2.4)} ${f1(W * 0.6)} ${f1(y + (R() - 0.5) * 2.4)} ${W} ${f1(y + (R() - 0.5))}" stroke="${shade(WC, 0.72)}" stroke-width="${f1(0.2 + R() * 0.25)}" fill="none" opacity="0.6"/>`; }).join('');
      gr += rep(3, () => { const x = 6 + R() * (W - 12), y = 4 + R() * 12; return `<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(1.6 + R())}" ry="${f1(0.8 + R() * 0.4)}" fill="${shade(WC, 0.7)}"/><ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(2.8 + R())}" ry="${f1(1.5)}" fill="none" stroke="${shade(WC, 0.78)}" stroke-width="0.25"/>`; }).join('');
      gr += rep(14, () => `<path d="M${f1(R() * W)} ${f1(R() * Hh)}h${f1(2 + R() * 5)}" stroke="#ffffff" stroke-width="0.35" opacity="0.25"/>`).join('');
      const fs = 9.6, txt = `<defs><mask id="${id}m"><rect width="${W}" height="${Hh}" fill="#ffffff"/>${rep(60, () => `<circle cx="${f1(R() * W)}" cy="${f1(R() * Hh)}" r="${f1(0.2 + R() * 0.5)}" fill="#000000"/>`).join('')}</mask></defs><g mask="url(#${id}m)"><text x="${W / 2}" y="${f1(Hh / 2 + 3.3)}" text-anchor="middle" font-family="${SERIF}" font-style="italic" font-weight="700" font-size="${fs}" textLength="${f1(W - 18)}" lengthAdjust="spacingAndGlyphs" fill="#fbf8f0">${xe(t)}</text></g>`;
      const starF = `<g transform="translate(${W - 6.5} ${Hh - 5.2}) rotate(12)"><path d="${rep(10, i => { const a = -PI / 2 + i * PI / 5, r = i % 2 ? 1.2 : 3; return (i ? 'L' : 'M') + f1(r * Math.cos(a)) + ' ' + f1(r * Math.sin(a)); }).join('')}Z" fill="#e88a4a" stroke="#a8552a" stroke-width="0.25" stroke-linejoin="round"/>${rep(5, i => { const a = -PI / 2 + i * 2 * PI / 5; return `<circle cx="${f1(1.6 * Math.cos(a))}" cy="${f1(1.6 * Math.sin(a))}" r="0.3" fill="#ffd2a8"/>`; }).join('')}</g>`;
      const ex = W / 2 - 7, rope = `M${-ex} ${YT - 0.6}L0 ${NY}L${ex} ${YT - 0.6}`, ropeL = [[-ex, YT - 0.6, 2.4], [0, NY, 2.4], [ex, YT - 0.6, 2.4]].map(C.P);
      let sw = box3(C, { c: [0, Y0, DP / 2], w: W, h: Hh, d: DP, r: 1.6, col: WC, dec: { f: gr + txt + starF, t: rep(5, () => `<path d="M${f1(R() * W)} ${f1(R() * DP)}h${f1(3 + R() * 6)}" stroke="${shade(WC, 0.7)}" stroke-width="0.25"/>`).join('') } });
      const rp = `M${P2(ropeL[0])}L${P2(ropeL[1])}L${P2(ropeL[2])}`;
      sw += `<path d="${rp}" stroke="#8a6a3e" stroke-width="${f1(C.k * 0.9)}" fill="none" stroke-linejoin="round" stroke-linecap="round"/><path d="${rp}" stroke="#d8b884" stroke-width="${f1(C.k * 0.5)}" stroke-dasharray="${f1(C.k * 0.5)} ${f1(C.k * 0.5)}" fill="none"/>`;
      [-ex, ex].forEach(x => sw += sph(C, [x, YT - 0.4, 2.4], 0.9, '#9aa0a8'));
      const pq = P2(C.p(0, NY, 1.6));
      let s = WD(C, -W / 2, YT, 0.06, `<rect x="1.8" y="2.8" width="${W}" height="${Hh}" rx="2" fill="#000000" opacity="0.38" filter="url(#m10b3)"/>`) + WD(C, 0, 0, 0.06, `<path d="M${-ex} ${-YT}L0 ${-NY}L${ex} ${-YT}" transform="translate(1 2)" stroke="#000000" stroke-width="0.8" opacity="0.2" fill="none"/>`);
      s += `<g>${at('rotate', `-1.1 ${pq};1.1 ${pq};-1.1 ${pq}`, 5.2, 0, SPL(2))}${sw}</g>`;
      s += cyl3(C, [0, NY, 0], [0, NY, 3], 0.4, '#7d838b') + sph(C, [0, NY, 3.1], 1, '#8a8f96');
      return { defs: DEF19, front: s, bb: C.bb(4) }; };
    return D; };

  // LIV-103 script vinyl wall decal: matte letters with a satin sheen that sweeps over them + a flourish and a leaf sprig
  N.qVinyl19 = S => { const t = qt(S), W = qw(t, 7, 70, 168), Hh = 30, Y0 = 18, YT = Y0 + Hh;
    const D = { w: W + 6, d: 2, mount: 'wall', elev: 54, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), id = C.u('vy'), fs = 15, tl = W - 10;
      const tx = st => `<text x="${W / 2}" y="${f1(Hh * 0.56)}" text-anchor="middle" font-family="${SCRIPT}" font-size="${fs}" textLength="${f1(tl)}" lengthAdjust="spacingAndGlyphs" ${st}>${xe(t)}</text>`;
      const fl = `M${f1(W * 0.14)} ${f1(Hh * 0.8)}C${f1(W * 0.3)} ${f1(Hh * 0.95)} ${f1(W * 0.42)} ${f1(Hh * 0.66)} ${f1(W * 0.5)} ${f1(Hh * 0.8)}S${f1(W * 0.72)} ${f1(Hh * 0.95)} ${f1(W * 0.84)} ${f1(Hh * 0.76)}`;
      const leaf = (x, y, r) => `<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="2" ry="0.9" transform="rotate(${r} ${f1(x)} ${f1(y)})" fill="#2f2a28"/>`;
      const sprig = `<path d="M${f1(W * 0.84)} ${f1(Hh * 0.76)}q2.6 -1.4 5 -4.6" stroke="#2f2a28" stroke-width="0.5" fill="none"/>` + leaf(W * 0.84 + 2.6, Hh * 0.76 - 2.2, -40) + leaf(W * 0.84 + 4.4, Hh * 0.76 - 4.6, -70) + leaf(W * 0.84 + 1.2, Hh * 0.76 - 1.4, 20);
      const body = tx('') + `<path d="${fl}" stroke-width="0.8" fill="none" stroke-linecap="round"/>` + sprig;
      let g = `<defs><linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3d3532"/><stop offset="1" stop-color="#1f1a19"/></linearGradient><linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.35"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient><clipPath id="${id}c">${tx('')}</clipPath></defs>`;
      g += `<g fill="#000000" stroke="#000000" opacity="0.22" transform="translate(0.16 0.26)">${body}</g><g fill="url(#${id}g)" stroke="#2f2a28">${body}</g>`;
      g += `<g clip-path="url(#${id}c)"><rect x="-20" y="0" width="14" height="${Hh}" fill="url(#${id}s)" transform="skewX(-20)">${at('translate', `0 0;0 0;${f1(W + 40)} 0`, 9, 0, ' keyTimes="0;0.6;1" additive="sum"')}</rect></g>`;
      const s = WD(C, -W / 2, YT, 0.08, g, W, Hh);
      return { defs: DEF19, front: s, bb: C.bb(4) }; };
    return D; };

  // LIV-104 brass script letters: cut brass with real thickness, a soft wall shadow and glints that sparkle along the letters
  N.qBrass19 = S => { const t = qt(S), W = qw(t, 7, 70, 168), Hh = 28, Y0 = 18, YT = Y0 + Hh;
    const D = { w: W + 6, d: 4, mount: 'wall', elev: 54, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), fs = 15, tl = W - 8;
      const tx = st => `<text x="${W / 2}" y="${f1(Hh * 0.62)}" text-anchor="middle" font-family="${SCRIPT}" font-size="${fs}" textLength="${f1(tl)}" lengthAdjust="spacingAndGlyphs" ${st}>${xe(t)}</text>`;
      let s = WD(C, -W / 2, YT, 0.06, `<g filter="url(#m12b1)" opacity="0.4" transform="translate(0.9 1.5)">${tx('fill="#000000"')}</g>`, W, Hh);
      [[0.4, '#6a4a18'], [0.8, '#8a6424'], [1.2, '#a07a30']].forEach(([z, c]) => s += WD(C, -W / 2, YT, z, tx(`fill="${c}"`)));
      const gl = rep(4, i => { const x = W * (0.16 + i * 0.22), y = Hh * (0.36 + (i % 2) * 0.16); return `<g transform="translate(${f1(x)} ${f1(y)})" opacity="0">${an('opacity', '0;0;1;0;0', 4.8, -i * 1.2, ' keyTimes="0;0.6;0.68;0.76;1"')}<path d="M0 -2.2L0.35 -0.35L2.2 0L0.35 0.35L0 2.2L-0.35 0.35L-2.2 0L-0.35 -0.35Z" fill="#ffffff"/><circle r="0.6" fill="#fff6d0"/></g>`; }).join('');
      s += WD(C, -W / 2, YT, 1.6, tx('fill="url(#br19)" stroke="#7a5418" stroke-width="0.22"') + tx('fill="none" stroke="#fff4c8" stroke-width="0.18" opacity="0.6" transform="translate(-0.15 -0.2)"') + gl);
      [-W / 2 + 3, W / 2 - 3].forEach(x => s += sph(C, [x, Y0 + Hh * 0.45, 1.2], 0.5, '#d9b25a'));
      return { defs: DEF19, front: s, bb: C.bb(4) }; };
    return D; };

  // LIV-105 glowing neon script on a clear acrylic backer with chrome standoffs, pink glow on the wall, flickers now and then
  N.qNeon19 = S => { const t = qt(S), W = qw(t, 7, 74, 172), Hh = 32, Y0 = 18, YT = Y0 + Hh, COL = '#ff5fa8';
    const D = { w: W + 10, d: 6, mount: 'wall', elev: 52, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), fs = 15.5, tl = W - 14;
      const tx = st => `<text x="${W / 2}" y="${f1(Hh * 0.6)}" text-anchor="middle" font-family="${SCRIPT}" font-size="${fs}" textLength="${f1(tl)}" lengthAdjust="spacingAndGlyphs" ${st}>${xe(t)}</text>`;
      const und = `M${f1(W * 0.22)} ${f1(Hh * 0.8)}Q${f1(W * 0.5)} ${f1(Hh * 0.9)} ${f1(W * 0.78)} ${f1(Hh * 0.8)}`;
      const FLK = an('opacity', '1;1;0.25;1;0.45;1;1', 6.5, 0, ' keyTimes="0;0.82;0.83;0.85;0.86;0.88;1"');
      let s = WD(C, -W / 2 - 14, YT + 14, 0.05, `<rect width="${W + 28}" height="${Hh + 28}" rx="24" fill="${COL}" opacity="0.4" filter="url(#m11b8)">${an('opacity', '0.32;0.46;0.34;0.44;0.32', 3.6)}</rect>`);
      s += WD(C, -W / 2, YT, 0.06, `<rect x="1" y="1.6" width="${W}" height="${Hh}" rx="3" fill="#000000" opacity="0.12" filter="url(#m12b1)"/><path d="M${W - 6} ${Hh}Q${W - 4} ${Hh + 6} ${W - 7} ${Hh + 12}" stroke="#2a2a2e" stroke-width="0.6" fill="none"/>`);
      ext(C, [[W / 2 - 9, Y0 - 13, 0]]);
      s += WD(C, -W / 2 + 0.5, Y0 - 11, 0.4, '<rect width="6" height="3.4" rx="0.6" fill="#24252a"/><circle cx="4.6" cy="1.7" r="0.45" fill="#7fffb0"/>');
      [[-W / 2 + 4, Y0 + 4], [W / 2 - 4, Y0 + 4], [-W / 2 + 4, YT - 4], [W / 2 - 4, YT - 4]].forEach(([x, y]) => s += cyl3(C, [x, y, 0], [x, y, 2.4], 0.9, '#d9dce0'));
      s += H.box3(C, { c: [0, Y0, 2], w: W, h: Hh, d: 0.9, r: 3, col: '#e2f3ff', op: 0.28, olc: '#a9c4d4', olw: 0.5, olo: 0.8, edge: 0.6 });
      [[-W / 2 + 4, Y0 + 4], [W / 2 - 4, Y0 + 4], [-W / 2 + 4, YT - 4], [W / 2 - 4, YT - 4]].forEach(([x, y]) => s += sph(C, [x, y, 3.1], 1.1, '#e6e8ec'));
      s += WD(C, -W / 2, YT, 3.3, `<g>${FLK}<g filter="url(#m12b2)" opacity="0.7">${tx(`fill="none" stroke="${COL}" stroke-width="2.6"`)}<path d="${und}" stroke="#5ff0ff" stroke-width="2.4" fill="none"/></g>${tx(`fill="${COL}" stroke="${COL}" stroke-width="0.6"`)}${tx('fill="#ffe6f3" opacity="0.75"')}</g>`
        + `<path d="${und}" stroke="#5ff0ff" stroke-width="1" fill="none" stroke-linecap="round"/><path d="${und}" stroke="#eaffff" stroke-width="0.3" fill="none" stroke-linecap="round"/>`, W, Hh);
      return { defs: DEF19, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= WINDOWS (front-on art the house shell draws in its window slot) =======================
  const WDEF = '<filter id="b1" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="0.6"/></filter><filter id="b2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.6"/></filter>'
    + '<linearGradient id="gref" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.22"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0.02"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>';
  const bev = (x, y, w, h, c, t) => `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="${c}"/><path d="M${f1(x)} ${f1(y)}h${f1(w)}l${-t} ${t}h${f1(-(w - 2 * t))}v${f1(h - 2 * t)}l${-t} ${t}Z" fill="#ffffff" opacity="0.38"/><path d="M${f1(x + w)} ${f1(y + h)}h${f1(-w)}l${t} ${-t}h${f1(w - 2 * t)}v${f1(-(h - 2 * t))}l${t} ${-t}Z" fill="#000000" opacity="0.2"/>`;
  const ring = (x0, y0, x1, y1, t, c, e) => bev(x0, y0, x1 - x0, t, c, e) + bev(x0, y1 - t, x1 - x0, t, c, e) + bev(x0, y0 + t, t, y1 - y0 - 2 * t, c, e) + bev(x1 - t, y0 + t, t, y1 - y0 - 2 * t, c, e);
  const reveal = (x0, y0, x1, y1, d, c) => `<path d="M${x0} ${y0}H${x1}L${x1 - d} ${y0 + d}H${x0 + d}Z" fill="${shade(c, 0.62)}"/><path d="M${x0} ${y0}L${x0 + d} ${y0 + d}V${y1 - d}L${x0} ${y1}Z" fill="${shade(c, 0.78)}"/><path d="M${x1} ${y0}V${y1}L${x1 - d} ${y1 - d}V${y0 + d}Z" fill="${shade(c, 0.95)}"/><path d="M${x0} ${y1}L${x0 + d} ${y1 - d}H${x1 - d}L${x1} ${y1}Z" fill="${shade(c, 1.06)}"/>`;
  const sill = (x0, x1, y, c, d) => `<rect x="${x0}" y="${y + 2.6}" width="${x1 - x0}" height="2" fill="#000000" opacity="0.22" filter="url(#b1)"/><path d="M${x0 + d} ${y - d}H${x1 - d}L${x1} ${y}H${x0}Z" fill="${shade(c, 1.08)}"/><rect x="${x0}" y="${y}" width="${x1 - x0}" height="3" fill="${c}"/><rect x="${x0}" y="${y}" width="${x1 - x0}" height="0.4" fill="#ffffff" opacity="0.5"/><rect x="${x0}" y="${y + 2.6}" width="${x1 - x0}" height="0.4" fill="#000000" opacity="0.2"/>`;
  const cloud = (x, y, k, c) => `<g transform="translate(${f1(x)} ${f1(y)}) scale(${n4(k)})"><ellipse cx="0.6" cy="1.4" rx="7" ry="2.2" fill="${shade(c, 0.86)}"/><ellipse rx="7" ry="2.6" fill="${c}"/><circle cx="-3" cy="-1.6" r="3" fill="${c}"/><circle cx="1.4" cy="-2.8" r="3.8" fill="${c}"/><circle cx="4.8" cy="-0.9" r="2.5" fill="${c}"/><circle cx="0.4" cy="-3.6" r="1.6" fill="#ffffff" opacity="0.6"/></g>`;
  const drift = (s, w, d) => `<g>${at('translate', `0 0;${f1(w)} 0`, d)}${s}<g transform="translate(${f1(-w)} 0)">${s}</g></g>`;
  const tree = (x, y, k, c, ph) => `<g transform="translate(${f1(x)} ${f1(y)}) scale(${n4(k)})"><path d="M-1 0L-0.7 -10H0.7L1 0Z" fill="#6a4a2e"/><g>${at('rotate', '-2.5 0 -8;2.5 0 -8;-2.5 0 -8', 5 + (ph || 0), -(ph || 0), SPL(2))}<circle cx="-3.6" cy="-11" r="4.6" fill="${shade(c, 0.85)}"/><circle cx="3.4" cy="-11.6" r="4.4" fill="${shade(c, 0.9)}"/><circle cy="-15" r="5.4" fill="${c}"/><circle cx="-1.6" cy="-16.6" r="2.2" fill="${shade(c, 1.2)}"/><circle cx="2.6" cy="-13" r="1.8" fill="${shade(c, 1.12)}"/></g></g>`;
  const glassRef = (x, y, w, h) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#gref)"/><path d="M${f1(x + w * 0.2)} ${y}L${f1(x + w * 0.05)} ${y + h}H${f1(x + w * 0.12)}L${f1(x + w * 0.27)} ${y}Z" fill="#ffffff" opacity="0.08"/>`;

  // LIV-012 cracked single pane with bent plastic blinds: chipped casing, taped crack, overcast rooftops, a swaying broken bottom rail
  function w12() { const FC = '#e7ddc6', R = rng('w12');
    let s = `<defs>${WDEF}<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#aebfca"/><stop offset="1" stop-color="#e3e8e2"/></linearGradient><clipPath id="gc"><rect x="-34.5" y="9.5" width="69" height="51"/></clipPath></defs>`;
    s += '<rect x="-43" y="3" width="88" height="67" fill="#000000" opacity="0.2" filter="url(#b2)"/>' + ring(-44, 1, 44, 66, 5, FC, 1.2) + reveal(-39, 6, 39, 66, 2, '#cfc5ae');
    let sc = '<rect x="-35" y="8" width="70" height="54" fill="url(#k)"/>' + drift(cloud(-20, 18, 1.2, '#eef1f2') + cloud(14, 14, 0.9, '#e6eaec'), 70, 46);
    sc += '<path d="M-35 44L-26 38L-17 44V40H-8V44L2 36L12 44V39H20V44H35V62H-35Z" fill="#8e99a5"/><path d="M-35 50L-22 46L-12 50L0 47L14 51L35 48V62H-35Z" fill="#7a8592"/>' + rep(6, i => `<rect x="${-31 + i * 11}" y="52" width="2.2" height="2.6" fill="#f2d48a" opacity="${i % 2 ? 0.8 : 0.3}"/>`).join('');
    sc += '<rect x="21" y="18" width="1.4" height="44" fill="#6a5a4a"/><path d="M17 22H27" stroke="#6a5a4a" stroke-width="1"/><path d="M-35 25Q-8 32 22 22Q30 20 35 23M-35 29Q-6 36 22 25" stroke="#3a3a3e" stroke-width="0.3" fill="none"/>';
    sc += `<g transform="translate(-6 30.2)"><g>${at('translate', '0 0;0 -0.6;0 0;0 0', 1.6, 0, ' keyTimes="0;0.1;0.2;1"')}<ellipse rx="1.4" ry="1" fill="#3a3330"/><circle cx="1" cy="-0.8" r="0.7" fill="#3a3330"/><path d="M1.6 -0.8l0.8 0.2l-0.8 0.2Z" fill="#e8a040"/></g></g>`;
    s += `<g clip-path="url(#gc)">${sc}<rect x="-35" y="8" width="70" height="54" fill="#d8cdb0" opacity="0.12"/>` + glassRef(-35, 8, 70, 54)
      + '<path d="M-29 58L-21 50L-23 44L-15 36M-21 50L-11 52L-5 47M-23 44L-31 40M-15 36L-9 30" stroke="#ffffff" stroke-width="0.45" fill="none" opacity="0.85"/><path d="M-28.6 58.4L-20.6 50.4L-22.6 44.4L-14.6 36.4" stroke="#5a6470" stroke-width="0.2" fill="none" opacity="0.5"/>'
      + '<g transform="translate(-19 46) rotate(-42)"><rect x="-9" y="-1.8" width="18" height="3.6" fill="#a7adb3" opacity="0.92"/><path d="M-9 -1.8V1.8M9 -1.8V1.8" stroke="#7d848c" stroke-width="0.3" stroke-dasharray="0.4 0.4"/><rect x="-8" y="-1.2" width="14" height="0.6" fill="#ffffff" opacity="0.35"/></g></g>';
    s += ring(-37, 7.5, 37, 62.5, 2.6, FC, 0.8);
    s += rep(14, () => { const x = -43 + R() * 86, y = R() < 0.5 ? 2 + R() * 3.5 : 61.5 + R() * 3.5; return `<path d="M${f1(x)} ${f1(y)}l${f1(0.6 + R())} ${f1(0.2)}l-0.2 ${f1(0.7 + R() * 0.5)}l${f1(-0.8 - R())} -0.2Z" fill="#a98a5e" opacity="0.8"/>`; }).join('');
    let bl = '<path d="M-24 10V48M0 10V48M24 10V48" stroke="#d6cdb8" stroke-width="0.3"/>';
    for (let i = 0; i < 14; i++) { const y = 11.2 + i * 2.6; if (i === 11) continue;
      const d = i === 5 ? `M-34.5 ${y}H-6L-2 ${y + 1.6}L2 ${y + 0.3}H34.5V${y + 2}H2L-2 ${y + 3.5}L-6 ${y + 1.9}H-34.5Z` : i === 8 ? `M-34.5 ${y}L34.5 ${y + 1.4}V${y + 3.3}L-34.5 ${y + 1.9}Z` : `M-34.5 ${y}H34.5V${y + 1.9}H-34.5Z`;
      bl += `<path d="${d}" fill="#efe9d8"/><path d="M-34.5 ${y + 0.15}H34.5" stroke="#ffffff" stroke-width="0.25" opacity="0.8"/><path d="${d}" fill="none" stroke="#b9b09a" stroke-width="0.18"/>`; }
    s += bl + bev(-35.5, 8.6, 71, 2.8, '#ebe5d4', 0.5) + `<g>${at('rotate', '-2.6 -34 48;-1.6 -34 48;-2.6 -34 48', 3.6, 0, SPL(2))}${bev(-35, 47.6, 70, 2.4, '#e4ddca', 0.5)}</g>`;
    s += '<path d="M32.5 10.6V58" stroke="#e8e2d2" stroke-width="0.5"/><path d="M32.5 58l-0.9 2.8h1.8Z" fill="#e0d8c2" stroke="#b9b09a" stroke-width="0.15"/><path d="M-32 10.6V30" stroke="#cfc6b0" stroke-width="0.8" stroke-linecap="round"/>';
    s += sill(-47, 47, 66, '#ddd2b9', 2) + bev(-40, 69, 80, 4, '#ddd2b9', 0.6);
    return { vb: [-48, 0, 96, 75], s }; }

  // LIV-032 white double-hung window with a cotton roman shade: sash lock, lift handles, sunny garden with a swaying tree
  function w32() { const FC = '#f6f2ea';
    let s = `<defs>${WDEF}<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fbbe8"/><stop offset="1" stop-color="#d6eefa"/></linearGradient><radialGradient id="sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff8d0"/><stop offset="0.35" stop-color="#fff0a0" stop-opacity="0.7"/><stop offset="1" stop-color="#fff0a0" stop-opacity="0"/></radialGradient>`
      + '<linearGradient id="fd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f6eedd"/><stop offset="0.7" stop-color="#e6dbc4"/><stop offset="1" stop-color="#c9bb9e"/></linearGradient><pattern id="ln" width="2" height="0.7" patternUnits="userSpaceOnUse"><rect width="2" height="0.18" fill="#8a7a5a" fill-opacity="0.12"/></pattern><clipPath id="gc"><rect x="-36.6" y="-4.6" width="73.2" height="76.6"/></clipPath></defs>';
    s += '<rect x="-42" y="-11" width="88" height="90" fill="#000000" opacity="0.18" filter="url(#b2)"/>' + ring(-43, -11, 43, 74, 5, FC, 1.2) + bev(-46, -15, 92, 4.6, FC, 0.8) + '<rect x="-43" y="-10.4" width="86" height="0.8" fill="#000000" opacity="0.15"/>' + reveal(-38, -6, 38, 74, 1.4, '#e3ddd0');
    let sc = '<rect x="-37" y="-5" width="74" height="78" fill="url(#k)"/><circle cx="24" cy="2" r="16" fill="url(#sun)"/><circle cx="24" cy="2" r="4.2" fill="#fff6c8"/>' + drift(cloud(-18, 10, 1, '#ffffff') + cloud(16, 20, 0.8, '#ffffff'), 74, 52);
    sc += '<path d="M-37 46Q-18 38 0 44T37 40V73H-37Z" fill="#9cc79e"/><path d="M-37 54Q-10 48 12 54T37 52V73H-37Z" fill="#7fb07a"/>' + tree(-24, 60, 1.6, '#5f9a4e', 0) + tree(26, 56, 1.1, '#6fa85a', 1.3);
    sc += rep(9, i => `<rect x="${-36 + i * 8.6}" y="60" width="2.4" height="13" fill="#ffffff"/><path d="M${-36 + i * 8.6} 60l1.2 -1.6l1.2 1.6" fill="#ffffff"/>`).join('') + '<rect x="-37" y="63" width="74" height="1.4" fill="#f2f2f2"/><rect x="-37" y="68" width="74" height="1.4" fill="#f2f2f2"/>';
    s += `<g clip-path="url(#gc)">${sc}${glassRef(-37, -5, 74, 78)}</g>`;
    s += ring(-36.6, -4.6, 36.6, 34, 2.8, FC, 0.7) + bev(-1, -1.8, 2, 33, FC, 0.4) + ring(-36.6, 31, 36.6, 72, 2.8, FC, 0.7) + bev(-1, 33.8, 2, 35.4, FC, 0.4) + bev(-36.6, 30.8, 73.2, 3.4, shade(FC, 0.98), 0.6);
    s += '<g transform="translate(0 32.4)"><ellipse rx="3" ry="1.1" fill="#b8892e"/><path d="M-2.2 -0.4Q0 -2.4 2.6 -1" stroke="#e8c062" stroke-width="0.8" fill="none" stroke-linecap="round"/><circle cx="2.6" cy="-1" r="0.7" fill="#f2d07a"/></g>';
    [-20, 20].forEach(x => s += `<path d="M${x - 2.4} 70.4Q${x} 73.4 ${x + 2.4} 70.4" stroke="#c99a3e" stroke-width="0.7" fill="none"/>`);
    let sh = '<rect x="-36.6" y="-4.6" width="73.2" height="6" fill="url(#fd)"/>';
    [[1.4, 6.8], [6.8, 12.2], [12.2, 17.6]].forEach(([a, b]) => sh += `<path d="M-37.2 ${a}H37.2Q37.8 ${f1((a + b) / 2)} 37.2 ${b}H-37.2Q-37.8 ${f1((a + b) / 2)} -37.2 ${a}Z" fill="url(#fd)"/><path d="M-37.2 ${b}H37.2" stroke="#a89878" stroke-width="0.3"/><path d="M-36 ${f1(a + 0.6)}H36" stroke="#ffffff" stroke-width="0.35" opacity="0.6"/>`);
    sh += '<rect x="-37" y="17.4" width="74" height="1.6" rx="0.6" fill="#e2d7bf"/><rect x="-36.6" y="-4.6" width="73.2" height="23.6" fill="url(#ln)"/>';
    s += `<rect x="-37" y="18.6" width="74" height="2" fill="#000000" opacity="0.14" filter="url(#b1)"/>${sh}`;
    s += '<path d="M35 19V41Q35 43 38 43.4L41.2 44" stroke="#efe8d8" stroke-width="0.45" fill="none"/><rect x="40.4" y="42.4" width="1.6" height="3.6" rx="0.4" fill="#c99a3e"/><path d="M41.2 44.4l1.6 2.2" stroke="#efe8d8" stroke-width="0.45"/>';
    s += sill(-47, 47, 74, '#f1ece0', 2) + bev(-39, 77, 78, 5, FC, 0.7);
    return { vb: [-48, -16, 96, 99], s }; }

  // LIV-052 floor-to-ceiling bay window: three glazed walls in perspective, wood bay floor with sun patches, long linen drapes on a brass rod
  function w52() { const FC = '#f4f0e8', O = [-82, -40, 82, 98], cpX = 44, cpT = -30, cpB = 86;
    const L = (u, v) => [-82 + 38 * u, (-40 + 10 * u) + v * ((98 - 12 * u) - (-40 + 10 * u))], Rr = (u, v) => { const p = L(u, v); return [-p[0], p[1]]; };
    const quad = (F, u0, u1, v0, v1, c, o) => `<path d="M${P2(F(u0, v0))}L${P2(F(u1, v0))}L${P2(F(u1, v1))}L${P2(F(u0, v1))}Z" fill="${c}"${o ? ` opacity="${o}"` : ''}/>`;
    let s = `<defs>${WDEF}<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6fb2e6"/><stop offset="0.6" stop-color="#bfe2f6"/><stop offset="1" stop-color="#e8f5fa"/></linearGradient><radialGradient id="sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff8d0"/><stop offset="0.35" stop-color="#fff0a0" stop-opacity="0.7"/><stop offset="1" stop-color="#fff0a0" stop-opacity="0"/></radialGradient>`
      + '<linearGradient id="dr" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#d9cfbc"/><stop offset="0.5" stop-color="#f4ede0"/><stop offset="1" stop-color="#cfc4ae"/></linearGradient><linearGradient id="cl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d6cfc0"/><stop offset="1" stop-color="#ece6da"/></linearGradient></defs>';
    s += '<rect x="-84" y="-42" width="170" height="142" fill="#000000" opacity="0.14" filter="url(#b2)"/>';
    let sc = '<rect x="-82" y="-40" width="164" height="138" fill="url(#k)"/><circle cx="54" cy="-20" r="26" fill="url(#sun)"/><circle cx="54" cy="-20" r="5.4" fill="#fff6c8"/>' + drift(cloud(-50, -18, 1.3, '#ffffff') + cloud(4, -26, 1, '#ffffff') + cloud(40, 0, 0.8, '#ffffff'), 164, 70);
    sc += '<path d="M-82 34Q-60 22 -36 30T10 26T50 30T82 24V98H-82Z" fill="#8fbf8a"/>' + rep(12, i => tree(-80 + i * 14.5, 34 - (i % 3), 0.9 + (i % 2) * 0.25, ['#5f9a4e', '#6aa65a', '#548c46'][i % 3], i * 0.4)).join('');
    sc += '<path d="M-82 44Q0 38 82 44V98H-82Z" fill="#9fd17e"/>' + rep(8, i => `<path d="M${-82 + i * 22} 98L${-60 + i * 22} 44H${-49 + i * 22}L${-71 + i * 22} 98Z" fill="#ffffff" opacity="0.06"/>`).join('') + tree(58, 70, 2.6, '#5a9448', 0.8);
    sc += rep(16, i => `<circle cx="${-64 + i * 8}" cy="${f1(76 + (i % 3) * 1.6)}" r="1.5" fill="${['#ef8f7f', '#f2c94c', '#ffffff', '#b9a6e0'][i % 4]}"/><circle cx="${-64 + i * 8}" cy="${f1(78.4 + (i % 3) * 1.6)}" r="1.2" fill="#4f8a3e"/>`).join('');
    s += sc + glassRef(-82, -40, 164, 138);
    s += '<path d="M-82 -40H82L44 -30H-44Z" fill="url(#cl)"/><path d="M-44 -30H44" stroke="#bdb4a2" stroke-width="0.4"/>';
    s += '<path d="M-82 98H82L44 86H-44Z" fill="#c4976a"/>' + rep(9, i => `<path d="M${f1(-82 + i * 20.5)} 98L${f1(-44 + i * 11)} 86" stroke="#9a7048" stroke-width="0.3"/>`).join('') + '<path d="M-44 86H44" stroke="#8a6440" stroke-width="0.5"/>';
    s += `<g>${an('opacity', '0.5;0.75;0.5', 6, 0, SPL(2))}<path d="M-20 97L-8 87H14L4 97Z" fill="#fff4cc" opacity="0.5"/><path d="M14 97L22 87H36L32 97Z" fill="#fff4cc" opacity="0.4"/></g>`;
    [[L, 0.9], [Rr, 1.06]].forEach(([F, k]) => { const c = shade(FC, k);
      s += quad(F, 0, 1, 0, 0.03, c) + quad(F, 0, 1, 0.965, 1, c) + quad(F, 0, 0.05, 0, 1, c) + quad(F, 0.95, 1, 0, 1, c) + quad(F, 0.47, 0.53, 0, 1, c) + quad(F, 0, 1, 0.2, 0.215, c) + quad(F, 0, 1, 0.965, 1, '#000000', 0.12); });
    s += ring(-cpX, cpT, cpX, cpB, 2.4, FC, 0.5) + bev(-1.2, cpT + 2.4, 2.4, cpB - cpT - 4.8, FC, 0.4) + bev(-cpX + 2.4, -6, 2 * cpX - 4.8, 1.8, FC, 0.4);
    [-6, 6].forEach(x => s += `<rect x="${x - 0.5}" y="40" width="1" height="5" rx="0.4" fill="#c99a3e"/>`);
    s += ring(-86, -44, 86, 102, 4, FC, 1) + '<rect x="-86" y="98" width="172" height="4" fill="#efe9dc"/>';
    s += '<rect x="-100" y="-48.4" width="200" height="2.6" rx="1.3" fill="url(#br19)"/><circle cx="-100" cy="-47.1" r="2.4" fill="#e2b456" stroke="#8a6420" stroke-width="0.3"/><circle cx="100" cy="-47.1" r="2.4" fill="#e2b456" stroke="#8a6420" stroke-width="0.3"/>';
    const drape = (x0, w, sg) => { const pl = 6; let d = `<g>${at('rotate', `0 ${x0 + w / 2} -46;${sg * 0.9} ${x0 + w / 2} -46;0 ${x0 + w / 2} -46`, 7, 0, SPL(2))}<path d="M${x0} -46H${x0 + w}V100H${x0 - sg * 1.6}Z" fill="#000000" opacity="0.15" transform="translate(${sg * 1.4} 1)" filter="url(#b1)"/><path d="M${x0} -46H${x0 + w}L${x0 + w + sg * 0.6} 100H${x0 - sg * 1.2}Z" fill="#ede5d6"/>`;
      for (let i = 0; i < pl; i++) { const a = x0 + i * w / pl, b = a + w / pl; d += `<path d="M${f1(a)} -46H${f1(b)}L${f1(b + sg * 0.3 + (i - pl / 2) * 0.3)} 100H${f1(a + (i - pl / 2) * 0.3)}Z" fill="url(#dr)" opacity="0.9"/>`; }
      d += rep(pl + 1, i => `<circle cx="${f1(x0 + i * w / pl)}" cy="-47" r="1.2" fill="none" stroke="#b38432" stroke-width="0.5"/>`).join('') + `<rect x="${x0 - 1}" y="96.6" width="${w + 2}" height="1.2" fill="#d6ccb8" opacity="0.8"/></g>`; return d; };
    s += drape(-99, 24, -1) + drape(75, 24, 1);
    return { vb: [-102, -51, 204, 153], s }; }

  // LIV-072 motorized smart-tint panoramic window wall: slim black steel panes over hills and a city, the tint rolls down and back up, wall touch panel
  function w72() { const FC = '#2a2c31';
    let s = `<defs>${WDEF}<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7cbbe8"/><stop offset="0.65" stop-color="#cfe6f2"/><stop offset="1" stop-color="#fbe2c0"/></linearGradient><radialGradient id="sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff8d0"/><stop offset="0.35" stop-color="#ffe7a0" stop-opacity="0.7"/><stop offset="1" stop-color="#ffe7a0" stop-opacity="0"/></radialGradient>`
      + '<linearGradient id="tn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1c2840" stop-opacity="0.78"/><stop offset="0.9" stop-color="#2a3a58" stop-opacity="0.62"/><stop offset="1" stop-color="#7fb8ff" stop-opacity="0.5"/></linearGradient><clipPath id="gc"><rect x="-118" y="-38" width="236" height="124"/></clipPath></defs>';
    s += '<rect x="-120" y="-40" width="244" height="132" fill="#000000" opacity="0.16" filter="url(#b2)"/>' + reveal(-121, -41, 121, 87, 3, '#e8e4dc');
    let sc = '<rect x="-118" y="-38" width="236" height="124" fill="url(#k)"/><circle cx="80" cy="-6" r="30" fill="url(#sun)"/><circle cx="80" cy="-6" r="6" fill="#fff4c8"/>' + drift(cloud(-90, -24, 1.3, '#ffffff') + cloud(-20, -30, 1, '#ffffff') + cloud(50, -18, 0.9, '#ffffff'), 236, 90);
    sc += '<path d="M-118 26L-90 8L-66 20L-40 2L-12 18L14 6L42 22L70 4L96 18L118 8V60H-118Z" fill="#9db8d4"/><path d="M-118 34L-80 22L-50 32L-20 20L20 32L60 22L118 32V60H-118Z" fill="#82a2c2"/>';
    const R = rng('w72'); sc += rep(30, i => { const x = -116 + i * 7.9, h = 8 + R() * 22, w = 4 + R() * 3.4; return `<rect x="${f1(x)}" y="${f1(52 - h)}" width="${f1(w)}" height="${f1(h + 10)}" fill="${['#6f86a2', '#7d93ae', '#61789a'][i % 3]}"/>` + rep(Math.floor(h / 3), j => `<rect x="${f1(x + 0.9)}" y="${f1(54 - h + j * 3)}" width="${f1(w - 1.8)}" height="0.8" fill="#dfe9f2" opacity="0.4"/>`).join(''); }).join('');
    sc += '<path d="M-118 60Q-60 50 0 58T118 54V86H-118Z" fill="#7fae6e"/>' + rep(14, i => tree(-114 + i * 17.4, 72 + (i % 2) * 4, 1.1 + (i % 3) * 0.2, ['#4f8a42', '#5c9a4c', '#477e3a'][i % 3], i * 0.5)).join('');
    sc += rep(3, i => `<g><animateMotion dur="${14 + i * 3}s" begin="${-i * 5}s" repeatCount="indefinite" path="M-130 ${-10 + i * 8}Q0 ${-26 + i * 6} 130 ${-6 + i * 4}"/><path d="M-1.6 0Q-0.8 -1 0 0Q0.8 -1 1.6 0" stroke="#3a3e48" stroke-width="0.4" fill="none"/></g>`).join('');
    sc += `<rect x="-118" y="-38" width="236" height="0" fill="url(#tn)">${an('height', '0;124;124;0;0', 18, 0, ' keyTimes="0;0.3;0.55;0.85;1"')}</rect><rect x="-118" y="-38" width="236" height="1" fill="#bfe4ff" opacity="0.8">${an('y', '-38;86;86;-38;-38', 18, 0, ' keyTimes="0;0.3;0.55;0.85;1"')}</rect>`;
    s += `<g clip-path="url(#gc)">${sc}${glassRef(-118, -38, 236, 124)}</g>`;
    s += ring(-119, -39, 119, 87, 2.2, FC, 0.4) + [-59, 0, 59].map(x => bev(x - 1, -37, 2, 122, FC, 0.3)).join('') + bev(-117, 58, 234, 1.8, FC, 0.3);
    s += [-30, 30, 88, -88].map(x => `<rect x="${x - 0.4}" y="66" width="0.8" height="7" rx="0.3" fill="#8a8f96"/>`).join('');
    s += sill(-123, 123, 88, '#d9d5cc', 2.4);
    s += `<rect x="102" y="64" width="12" height="7" rx="1" fill="#14161b" stroke="#3a3e46" stroke-width="0.3"/><text x="108" y="66.6" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="1.6" fill="#9fdcff">TINT</text><rect x="103.6" y="68" width="8.8" height="1.4" rx="0.7" fill="#2a2e36"/><rect x="103.6" y="68" width="1" height="1.4" rx="0.7" fill="#5fd0ff">${an('width', '1;8.8;8.8;1;1', 18, 0, ' keyTimes="0;0.3;0.55;0.85;1"')}</rect>`;
    return { vb: [-124, -44, 248, 137], s }; }

  // LIV-092 holographic weather-shifting skyline panorama: sunny -> rain -> starry night -> snow, glowing edge, scanlines, flying cars, a live-sky HUD
  function w92() { const KT = ' keyTimes="0;0.2;0.25;0.45;0.5;0.7;0.75;0.95;1"', VA = ['1;1;0;0;0;0;0;0;1', '0;0;1;1;0;0;0;0;0', '0;0;0;0;1;1;0;0;0', '0;0;0;0;0;0;1;1;0'], cyc = i => an('opacity', VA[i], 32, 0, KT);
    const x0 = -128, y0 = -42, w = 256, h = 132, R = rng('w92');
    let s = `<defs>${WDEF}<linearGradient id="s0" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5fb0f0"/><stop offset="1" stop-color="#d4f0ff"/></linearGradient><linearGradient id="s1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4f5c6c"/><stop offset="1" stop-color="#93a2b0"/></linearGradient><linearGradient id="s2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#070b26"/><stop offset="1" stop-color="#2c2664"/></linearGradient><linearGradient id="s3" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9fb0c2"/><stop offset="1" stop-color="#e6edf3"/></linearGradient>`
      + '<radialGradient id="sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff8d0"/><stop offset="0.35" stop-color="#ffe7a0" stop-opacity="0.7"/><stop offset="1" stop-color="#ffe7a0" stop-opacity="0"/></radialGradient><pattern id="scn" width="4" height="1.4" patternUnits="userSpaceOnUse"><rect width="4" height="0.45" fill="#9ff8ff" fill-opacity="0.07"/></pattern>'
      + `<linearGradient id="shm" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#9ff8ff" stop-opacity="0"/><stop offset="0.5" stop-color="#dffcff" stop-opacity="0.32"/><stop offset="1" stop-color="#9ff8ff" stop-opacity="0"/></linearGradient><clipPath id="gc"><rect x="${x0}" y="${y0}" width="${w}" height="${h}" rx="5"/></clipPath></defs>`;
    s += `<rect x="${x0 - 6}" y="${y0 - 6}" width="${w + 12}" height="${h + 12}" rx="12" fill="#3fd0ff" opacity="0.3" filter="url(#b2)">${an('opacity', '0.22;0.38;0.22', 4)}</rect><rect x="${x0 - 2}" y="${y0 - 1}" width="${w + 6}" height="${h + 5}" rx="6" fill="#000000" opacity="0.2" filter="url(#b2)"/>`;
    let sc = `<g>${cyc(0)}<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="url(#s0)"/><circle cx="70" cy="-14" r="26" fill="url(#sun)"/><circle cx="70" cy="-14" r="6" fill="#fff6c8"/>${drift(cloud(-90, -20, 1.2, '#ffffff') + cloud(0, -28, 1, '#ffffff'), w, 80)}</g>`;
    sc += `<g opacity="0">${cyc(1)}<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="url(#s1)"/>${drift(cloud(-100, -26, 2, '#7a8696') + cloud(-30, -30, 2.4, '#6e7a8a') + cloud(50, -24, 2, '#7a8696'), w, 60)}</g>`;
    sc += `<g opacity="0">${cyc(2)}<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="url(#s2)"/>${rep(60, i => `<circle cx="${f1(x0 + R() * w)}" cy="${f1(y0 + R() * 70)}" r="${f1(0.25 + R() * 0.45)}" fill="#ffffff">${an('opacity', '0.3;1;0.3', 1.5 + R() * 3, -R() * 3)}</circle>`).join('')}<circle cx="-70" cy="-20" r="8" fill="#fff4d6"/><circle cx="-66" cy="-23" r="7" fill="#11163a"/></g>`;
    sc += `<g opacity="0">${cyc(3)}<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="url(#s3)"/></g>`;
    let sky = '', lit = '';
    for (let i = 0; i < 26; i++) { const bx = x0 + i * 10 + R() * 2, bw = 6 + R() * 4, bh = 26 + R() * 64, top = 90 - bh, c = ['#34425f', '#3c4b6a', '#2c3a56'][i % 3];
      sky += `<rect x="${f1(bx)}" y="${f1(top)}" width="${f1(bw)}" height="${f1(bh)}" fill="${c}"/><rect x="${f1(bx)}" y="${f1(top)}" width="${f1(bw * 0.3)}" height="${f1(bh)}" fill="#ffffff" opacity="0.06"/>`;
      if (i % 4 === 1) sky += `<path d="M${f1(bx + bw / 2)} ${f1(top - 8)}V${f1(top)}" stroke="${c}" stroke-width="0.8"/><circle cx="${f1(bx + bw / 2)}" cy="${f1(top - 8)}" r="0.7" fill="#ff5a5a">${an('opacity', '1;0.2;1', 1.4, -i * 0.2)}</circle>`;
      if (i % 5 === 3) sky += `<path d="M${f1(bx)} ${f1(top)}Q${f1(bx + bw / 2)} ${f1(top - 5)} ${f1(bx + bw)} ${f1(top)}Z" fill="${c}"/>`;
      for (let j = 0; j < bh / 4 - 1; j++) for (let q = 0; q < 2; q++) { const on = R() < 0.55; sky += `<rect x="${f1(bx + 1 + q * (bw / 2))}" y="${f1(top + 2 + j * 4)}" width="${f1(bw / 2 - 2)}" height="1.4" fill="#cfe6ff" opacity="0.22"/>`; if (on) lit += `<rect x="${f1(bx + 1 + q * (bw / 2))}" y="${f1(top + 2 + j * 4)}" width="${f1(bw / 2 - 2)}" height="1.4" fill="#ffd77a"/>`; } }
    sc += sky + `<g opacity="0">${cyc(2)}<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="#0b1030" opacity="0.35"/>${lit}</g>`;
    const rain = rep(70, () => `<path d="M${f1(x0 + R() * w)} ${f1(y0 + R() * h)}l-1.2 4" stroke="#cfe0f0" stroke-width="0.35" opacity="0.7"/>`).join('');
    sc += `<g opacity="0">${cyc(1)}<g>${at('translate', `0 0;-6 ${h}`, 0.9)}${rain}<g transform="translate(6 ${-h})">${rain}</g></g></g>`;
    const snow = rep(60, () => `<circle cx="${f1(x0 + R() * w)}" cy="${f1(y0 + R() * h)}" r="${f1(0.4 + R() * 0.6)}" fill="#ffffff"/>`).join('');
    sc += `<g opacity="0">${cyc(3)}<g>${at('translate', `0 0;8 ${h}`, 9)}${snow}<g transform="translate(-8 ${-h})">${snow}</g></g><rect x="${x0}" y="86" width="${w}" height="4" fill="#ffffff" opacity="0.9"/></g>`;
    sc += rep(3, i => `<g><animateMotion dur="${9 + i * 4}s" begin="${-i * 3}s" repeatCount="indefinite" path="M${x0 - 10} ${-4 + i * 12}Q0 ${-14 + i * 10} ${x0 + w + 10} ${2 + i * 10}"/><rect x="-2.6" y="-0.9" width="5.2" height="1.8" rx="0.9" fill="#d8e4f0"/><circle cx="2.4" r="0.6" fill="#ffe680"/><circle cx="-2.4" r="0.5" fill="#ff5a6a"/></g>`).join('');
    sc += `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="url(#scn)"/><rect x="${x0 - 60}" y="${y0}" width="40" height="${h}" fill="url(#shm)" transform="skewX(-14)">${at('translate', `0 0;0 0;${w + 120} 0`, 7, 0, ' keyTimes="0;0.4;1" additive="sum"')}</rect>`;
    s += `<g clip-path="url(#gc)">${sc}${glassRef(x0, y0, w, h)}</g>`;
    s += `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" rx="5" fill="none" stroke="#12141a" stroke-width="2.4"/><rect x="${x0 + 1.4}" y="${y0 + 1.4}" width="${w - 2.8}" height="${h - 2.8}" rx="4" fill="none" stroke="#5ff0ff" stroke-width="0.6">${an('opacity', '0.5;1;0.5', 2.6)}</rect>`;
    [[x0, y0], [x0 + w, y0], [x0, y0 + h], [x0 + w, y0 + h]].forEach(([x, y]) => s += `<circle cx="${x}" cy="${y}" r="1.6" fill="#1a1d24" stroke="#5ff0ff" stroke-width="0.4"/>`);
    const icons = ['<circle r="2.6" fill="#ffd34a"/>' + rep(8, i => `<path d="M${f1(3.4 * Math.cos(i * PI / 4))} ${f1(3.4 * Math.sin(i * PI / 4))}l${f1(1.2 * Math.cos(i * PI / 4))} ${f1(1.2 * Math.sin(i * PI / 4))}" stroke="#ffd34a" stroke-width="0.6"/>`).join(''),
      '<ellipse cy="-0.6" rx="3.8" ry="2" fill="#cfd8e2"/><path d="M-2 2l-0.6 2M0 2l-0.6 2M2 2l-0.6 2" stroke="#8fd0ff" stroke-width="0.5"/>', '<circle r="3" fill="#fff4d6"/><circle cx="1.4" cy="-1" r="2.6" fill="#0b1a2a"/>', '<path d="M0 -3.4V3.4M-3 -1.7L3 1.7M-3 1.7L3 -1.7" stroke="#ffffff" stroke-width="0.6"/>'];
    s += `<g transform="translate(${x0 + 6} ${y0 + 6})"><rect width="38" height="12" rx="3" fill="#0b1a2a" opacity="0.6" stroke="#5ff0ff" stroke-width="0.35"/>` + icons.map((ic, i) => `<g opacity="${i ? 0 : 1}">${cyc(i)}<g transform="translate(6.4 6)">${ic}</g><text x="14" y="7.6" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="4.2" fill="#e8feff">${['24°', '17°', '9°', '-2°'][i]}</text></g>`).join('') + '<text x="35" y="4.6" text-anchor="end" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="1.8" fill="#5ff0ff">LIVE SKY</text></g>';
    return { vb: [-136, -50, 272, 148], s }; }
  const WIN19 = { crack: w12, hung: w32, bay: w52, tint: w72, holo: w92 }, WMEMO = {};
  const winArt = k => WMEMO[k] || (WMEMO[k] = (() => { const o = WIN19[k](); return { vb: o.vb, svg: RD.svgDoc(o.vb.join(' '), [], o.s) }; })());

  // ---------- draw hook: windows ----------
  const draw18 = RD.draw;
  RD.draw = (r, o) => { const res = draw18(r, o); if (!res || res._p19) return res;
    try { if (r.w19 && WIN19[r.w19] && res.surf) { const A = winArt(r.w19); res._p19 = 1; res.svg = A.svg; res.src = 'data:image/svg+xml,' + encodeURIComponent(A.svg); res.vb = A.vb.join(' '); res.win19 = A.vb; } } catch (e) { console.warn('reno plus19', r.id, e); }
    if (r.w19 && res.win19) { const sp = X.SPEC['rv_' + r.id]; if (sp) sp.ir = res.win19; }
    return res; };

  // ---------- catalog edits ----------
  RD.SET19 = {
    'LIV-001': { s12: 'lpaper', note: 'Old off-white rental wallpaper with faded stripes and tiny rose sprigs. One seam has started to lift, there are brown water stains from a ceiling leak, a few old nail holes and a little torn spot.' },
    'LIV-021': { s12: 'lsage', note: 'Walls rolled in a soft sage matte paint (you can see the roller texture), with a crisp white skirting board, a light switch and a little round thermostat.' },
    'LIV-041': { s12: 'lwain', note: 'Cream plaster on top and white shaker panels below a chair rail, every panel a real recessed square with soft shadows.' },
    'LIV-061': { s12: 'lherr', note: 'A herringbone oak feature wall in mixed honey and walnut planks on the back wall, and chalky limewash plaster on the side walls.' },
    'LIV-081': { s12: 'lmarb', note: 'Bookmatched smooth white marble with thin brass inlay strips.' },
    'LIV-004': { spec: 'cal19', note: 'A free calendar from Squish Pizza hanging on a nail. It always shows today, past days get crossed off, and you can tap days to mark them. A pencil on a string swings next to it.' },
    'LIV-024': { spec: 'rmir19', live: 'Glinting glass', note: 'A round mirror with a thick brass rim hanging from a stitched leather strap on a brass peg. A soft glint slides across the glass.' },
    'LIV-044': { spec: 'trip19', note: 'Three deep gallery-wrapped canvases that make one abstract painting together, with thick raised brush strokes, the paint wrapping round their sides.' },
    'LIV-064': { spec: 'venet19', live: 'Glowing neon', note: 'An arched Venetian mirror made of bevelled, etched glass pieces with little glass rosettes, and a pink "hey cutie" neon script glowing on it.' },
    'LIV-084': { spec: 'master19', note: 'A living painting in a carved gilt frame with a brass picture light. It moves on its own. Tap it to repaint.' },
    'LIV-101': { spec: 'qPaper19', live: 'Swaying banner', note: 'A hand-lettered paper banner clipped to a twine with two wooden clothespins, with marker doodles. Write any words you like.' },
    'LIV-102': { spec: 'qDrift19', live: 'Swinging sign', note: 'A weathered driftwood plank with distressed white painted letters and a little starfish, hanging from a jute rope. Write any words you like.' },
    'LIV-103': { spec: 'qVinyl19', note: 'A matte script vinyl decal with a flourish and a leaf sprig, stuck straight onto the wall. Write any words you like.' },
    'LIV-104': { spec: 'qBrass19', live: 'Sparkling brass', note: 'Thick cut-brass script letters standing off the wall, with little sparkles running along them. Write any words you like.' },
    'LIV-105': { spec: 'qNeon19', live: 'Glowing neon', note: 'Pink neon script on a clear acrylic panel with chrome standoffs. It lights up the wall and flickers now and then. Write any words you like.' },
    'LIV-012': { w19: 'crack', live: 'Drifting clouds', note: 'A cracked single-pane window with chipped paint and a taped crack. The bent plastic blinds are missing a slat and the bottom rail hangs crooked.' },
    'LIV-032': { w19: 'hung', live: 'Swaying trees', note: 'A white double-hung window with a brass sash lock and a cotton roman shade, looking out on a sunny garden.' },
    'LIV-052': { w19: 'bay', live: 'Swaying drapes', note: 'A floor-to-ceiling bay window with three glass walls, a sunny wood floor and long linen drapes on a brass rod.' },
    'LIV-072': { w19: 'tint', live: 'Smart tint', note: 'A panoramic black-steel window wall over the hills and the city. The smart tint slowly rolls down the glass and back up.' },
    'LIV-092': { w19: 'holo', live: 'Changing weather', note: 'A frameless holographic panorama of a future skyline that changes weather on its own: sunshine, rain, a starry night and snow.' },
  };
  const edit18 = RD.edit;
  RD.edit = rows => edit18(rows).map(r => RD.SET19[r.id] ? Object.assign({}, r, RD.SET19[r.id]) : r);
  RD.H19 = { DEF19, WIN19, winArt };
  RD.PLUS19 = 1;
})();
