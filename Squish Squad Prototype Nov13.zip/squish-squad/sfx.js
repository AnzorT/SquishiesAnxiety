(function () {
  const S = { ctx: null, enabled: true, musicVol: 0.5, sfxVol: 0.8, want: null, track: null, hold: null, squish: null, reel: null };
  const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);

  function init() {
    if (S.ctx) return S.ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    const c = (S.ctx = new AC());
    const comp = c.createDynamicsCompressor();
    comp.threshold.value = -14; comp.ratio.value = 4; comp.connect(c.destination);
    S.master = c.createGain(); S.master.gain.value = S.enabled ? 1 : 0; S.master.connect(comp);
    S.sfx = c.createGain(); S.sfx.gain.value = S.sfxVol; S.sfx.connect(S.master);
    S.mus = c.createGain(); S.mus.gain.value = S.musicVol * 0.5; S.mus.connect(S.master);
    const len = c.sampleRate * 1.8, ir = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3); }
    S.verb = c.createConvolver(); S.verb.buffer = ir;
    S.verbIn = c.createGain(); S.verbIn.gain.value = 0.35; S.verbIn.connect(S.verb); S.verb.connect(S.master);
    S.mverb = c.createConvolver(); S.mverb.buffer = ir; S.mverbIn = c.createGain(); S.mverbIn.gain.value = 0.4; S.mverbIn.connect(S.mverb); S.mverb.connect(S.mus);
    const nl = c.sampleRate * 2; S.noiseBuf = c.createBuffer(1, nl, c.sampleRate);
    const nd = S.noiseBuf.getChannelData(0); for (let i = 0; i < nl; i++) nd[i] = Math.random() * 2 - 1;
    return c;
  }
  function ready() { const c = S.ctx; if (!c || c.state === 'closed') return null; if (c.state === 'suspended' && !document.hidden) c.resume(); return c; }
  function unlock() {
    const c = init(); if (!c) return;
    if (c.state === 'suspended') c.resume().then(() => { if (S.want && !S.track) startTrack(S.want); });
    else if (S.want && !S.track) startTrack(S.want);
  }
  ['pointerdown', 'keydown', 'touchstart'].forEach((ev) => window.addEventListener(ev, unlock, { capture: true, passive: true }));
  document.addEventListener('visibilitychange', () => { if (!S.ctx) return; document.hidden ? S.ctx.suspend() : S.ctx.resume(); });

  function tone(f, t, dur, o) {
    o = o || {}; const c = S.ctx;
    const osc = c.createOscillator(), g = c.createGain();
    osc.type = o.type || 'sine'; osc.frequency.setValueAtTime(f, t);
    if (o.to) osc.frequency.exponentialRampToValueAtTime(o.to, t + (o.slide || dur));
    if (o.detune) osc.detune.value = o.detune;
    const v = o.vol == null ? 0.3 : o.vol, a = o.attack || 0.004;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    let out = g;
    if (o.lp) { const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = o.lp; g.connect(lp); out = lp; }
    osc.connect(g); out.connect(o.bus || S.sfx);
    if (o.verb) { const s = c.createGain(); s.gain.value = o.verb; out.connect(s); s.connect(o.vbus || S.verbIn); }
    osc.start(t); osc.stop(t + dur + 0.05);
    return osc;
  }
  function noise(t, dur, o) {
    o = o || {}; const c = S.ctx;
    const src = c.createBufferSource(); src.buffer = S.noiseBuf; src.loop = true;
    const f = c.createBiquadFilter(); f.type = o.ft || 'bandpass'; f.Q.value = o.q || 1;
    f.frequency.setValueAtTime(o.f || 1000, t);
    if (o.fTo) f.frequency.exponentialRampToValueAtTime(o.fTo, t + dur);
    const g = c.createGain(), v = o.vol == null ? 0.2 : o.vol;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + (o.attack || 0.005));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(o.bus || S.sfx);
    if (o.verb) { const s = c.createGain(); s.gain.value = o.verb; g.connect(s); s.connect(o.vbus || S.verbIn); }
    src.start(t, Math.random()); src.stop(t + dur + 0.05);
  }
  function bell(f, t, dur, vol, bus) {
    tone(f, t, dur, { vol, verb: 0.6, bus });
    tone(f * 2.76, t, dur * 0.4, { vol: vol * 0.25, verb: 0.6, bus });
    tone(f * 5.4, t, dur * 0.15, { vol: vol * 0.1, bus });
  }
  function sparkle(t, n, base) {
    for (let i = 0; i < (n || 7); i++) bell((base || 1800) * Math.pow(2, Math.floor(Math.random() * 8) / 5), t + i * 0.045 + Math.random() * 0.02, 0.5, 0.07);
  }
  function arp(notes, t, gap, vol, dur) { notes.forEach((m, i) => bell(mtof(m), t + i * gap, dur || 0.8, vol || 0.14)); }

  const SOUNDS = {
    tap(t) { tone(480, t, 0.09, { to: 980, slide: 0.05, vol: 0.22 }); noise(t, 0.03, { f: 3000, q: 2, vol: 0.05 }); },
    bonk(t) { tone(180, t, 0.18, { type: 'triangle', to: 110, vol: 0.25 }); },
    swoosh(t) { noise(t, 0.24, { f: 500, fTo: 2600, q: 1.4, vol: 0.12, attack: 0.08 }); tone(700, t + 0.05, 0.12, { to: 1100, vol: 0.05 }); },
    swipe(t) { noise(t, 0.32, { f: 2600, fTo: 600, q: 1.2, vol: 0.13, attack: 0.1 }); tone(880, t + 0.12, 0.2, { vol: 0.08, verb: 0.3 }); },
    whoosh(t) { noise(t, 0.4, { f: 300, fTo: 1800, q: 0.8, vol: 0.12, attack: 0.15 }); bell(mtof(84), t + 0.18, 0.6, 0.06); },
    popOpen(t) { tone(300, t, 0.14, { to: 900, slide: 0.08, vol: 0.2 }); bell(mtof(88), t + 0.06, 0.4, 0.05); },
    popClose(t) { tone(800, t, 0.12, { to: 260, slide: 0.08, vol: 0.18 }); },
    tick(t) { tone(2200, t, 0.03, { type: 'triangle', vol: 0.14 }); noise(t, 0.02, { f: 5000, q: 3, vol: 0.08 }); },
    coin(t) { tone(1318, t, 0.08, { type: 'square', vol: 0.05, lp: 5000 }); tone(1976, t + 0.07, 0.35, { type: 'square', vol: 0.05, lp: 5000 }); bell(1976, t + 0.07, 0.4, 0.08); },
    coinShower(t) { for (let i = 0; i < 6; i++) SOUNDS.coin(t + i * 0.07 + Math.random() * 0.03); },
    spend(t) { tone(1500, t, 0.05, { type: 'triangle', vol: 0.12 }); tone(1000, t + 0.06, 0.2, { type: 'triangle', vol: 0.12 }); noise(t + 0.06, 0.12, { f: 4000, q: 2, vol: 0.06 }); },
    win(t) { arp([72, 76, 79, 84], t, 0.09, 0.16); sparkle(t + 0.35, 6); },
    jackpot(t) { arp([72, 76, 79, 84, 88, 91], t, 0.08, 0.16, 1.2); [60, 64, 67].forEach((m) => tone(mtof(m), t + 0.5, 1.4, { type: 'triangle', vol: 0.07, attack: 0.05, verb: 0.4 })); sparkle(t + 0.5, 12, 2200); },
    fail(t) { tone(520, t, 0.45, { type: 'triangle', to: 220, slide: 0.4, vol: 0.18 }); tone(530, t, 0.45, { type: 'triangle', to: 224, slide: 0.4, vol: 0.1 }); },
    boxOpen(t) { noise(t, 0.7, { f: 400, fTo: 5000, q: 0.9, vol: 0.18, attack: 0.5 }); tone(300, t, 0.75, { to: 1600, slide: 0.7, vol: 0.08, type: 'triangle' }); tone(80, t + 0.7, 0.4, { to: 40, vol: 0.4 }); noise(t + 0.7, 0.35, { ft: 'lowpass', f: 1500, vol: 0.3 }); },
    reveal(t) { SOUNDS.jackpot(t); },
    unlock(t) { [2400, 3720, 5150].forEach((f, i) => tone(f, t + i * 0.008, 0.25, { vol: 0.06, verb: 0.3 })); tone(900, t + 0.12, 0.08, { type: 'square', vol: 0.06, lp: 3000 }); noise(t + 0.12, 0.05, { f: 2500, q: 4, vol: 0.12 }); arp([79, 84, 88, 91], t + 0.25, 0.07, 0.13); sparkle(t + 0.5, 8); },
    achievement(t) { arp([67, 72, 76, 79, 84], t, 0.1, 0.16, 1.1); tone(mtof(48), t, 1.2, { type: 'triangle', vol: 0.1, attack: 0.02 }); sparkle(t + 0.5, 9, 2400); },
    boost(t) { tone(200, t, 0.5, { type: 'sawtooth', to: 1600, slide: 0.45, vol: 0.06, lp: 2400 }); SOUNDS.coinShower(t + 0.35); },
    adStart(t) { bell(mtof(76), t, 0.4, 0.1); bell(mtof(83), t + 0.12, 0.6, 0.1); },
    adDone(t) { arp([76, 83, 88], t, 0.08, 0.12); },
    ready(t) { bell(mtof(84), t, 0.9, 0.1); bell(mtof(91), t + 0.1, 1, 0.08); },
    blip(t) { tone(1200, t, 0.06, { vol: 0.07 }); },
    sparkle(t) { sparkle(t, 10); },
    squelch(t) { noise(t, 0.18, { f: 700, fTo: 280, q: 3, vol: 0.28, attack: 0.02 }); tone(260, t, 0.14, { to: 150, vol: 0.12 }); },
    release(t) {
      tone(180, t, 0.16, { to: 520, slide: 0.07, vol: 0.28 });
      noise(t, 0.22, { f: 400, fTo: 1600, q: 4, vol: 0.18 });
      for (let i = 0; i < 5; i++) tone(900 + Math.random() * 900, t + 0.05 + Math.random() * 0.18, 0.03, { vol: 0.05, to: 1800 });
    },
  };

  function holdStart() {
    const c = ready(); if (!c) return; holdStop();
    const o = c.createOscillator(), o2 = c.createOscillator(), g = c.createGain();
    o.type = 'triangle'; o2.type = 'sine'; o.frequency.value = 260; o2.frequency.value = 390;
    g.gain.setValueAtTime(0.0001, c.currentTime); g.gain.linearRampToValueAtTime(0.06, c.currentTime + 0.1);
    o.connect(g); o2.connect(g); g.connect(S.sfx); o.start(); o2.start();
    S.hold = { o, o2, g, last: 0 };
  }
  function holdUpdate(p) {
    const c = ready(); if (!c || !S.hold) return;
    const f = 260 + p * 700, t = c.currentTime;
    S.hold.o.frequency.setTargetAtTime(f, t, 0.03); S.hold.o2.frequency.setTargetAtTime(f * 1.5, t, 0.03);
    S.hold.g.gain.setTargetAtTime(0.05 + p * 0.07, t, 0.05);
    const step = Math.floor(p * 10); if (step > S.hold.last) { S.hold.last = step; tone(f * 2, t, 0.05, { vol: 0.05 }); }
  }
  function holdStop() {
    if (!S.hold || !S.ctx) return; const { o, o2, g } = S.hold, t = S.ctx.currentTime;
    g.gain.cancelScheduledValues(t); g.gain.setTargetAtTime(0.0001, t, 0.04);
    o.stop(t + 0.3); o2.stop(t + 0.3); S.hold = null;
  }

  function squishStart() {
    const c = ready(); if (!c) return; squishStop();
    const t = c.currentTime; thump(t, 220, 0.1); bub(t + 0.05, 420, 0.05);
    const sq = { on: true };
    const loop = () => { if (!sq.on || !S.ctx) return; const n = S.ctx.currentTime + 0.01; bub(n, rr(300, 700), rr(0.03, 0.05)); if (Math.random() < 0.3) drop(n + 0.1, rr(800, 1100), 0.035); sq.timer = setTimeout(loop, rr(260, 600)); };
    sq.timer = setTimeout(loop, 250); S.squish = sq;
  }
  function squishStop() { const sq = S.squish; if (!sq) return; S.squish = null; sq.on = false; clearTimeout(sq.timer); }

  function wheelSpin(ms) {
    const c = ready(); if (!c) return; const t0 = c.currentTime, T = ms / 1000;
    noise(t0, 0.4, { f: 600, fTo: 2400, q: 1, vol: 0.12, attack: 0.1 });
    let x = 0;
    while (x < T - 0.05) {
      const p = x / T, gap = 0.035 + Math.pow(p, 2.6) * 0.42;
      SOUNDS.tick(t0 + x); x += gap;
    }
  }
  function reelStart() {
    reelStop(); const run = () => { const c = ready(); if (c) SOUNDS.tick(c.currentTime); S.reel = setTimeout(run, 70); }; run();
  }
  function reelLand(ms) {
    reelStop(); const c = ready(); if (!c) return; const t0 = c.currentTime, T = ms / 1000; let x = 0, gap = 0.07;
    while (x < T) { SOUNDS.tick(t0 + x); gap *= 1.12; x += gap; }
    tone(mtof(72), t0 + T - 0.05, 0.3, { type: 'triangle', vol: 0.12 });
  }
  function reelStop() { clearTimeout(S.reel); S.reel = null; }

  // --- music ---
  function swell(f, t, dur, o) {
    const c = S.ctx, osc = c.createOscillator(), g = c.createGain(), lp = c.createBiquadFilter();
    osc.type = o.type || 'sine'; osc.frequency.value = f; if (o.detune) osc.detune.value = o.detune;
    lp.type = 'lowpass'; lp.frequency.value = o.lp || 1400; lp.Q.value = 0.3;
    const a = Math.min(o.attack || 1, dur * 0.45), r = Math.min(o.release || 1.2, dur * 0.5), v = o.vol;
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + a); g.gain.setValueAtTime(v, t + dur - r); g.gain.linearRampToValueAtTime(0, t + dur);
    osc.connect(lp); lp.connect(g); g.connect(o.bus || S.sfx);
    if (o.verb) { const sg = c.createGain(); sg.gain.value = o.verb; g.connect(sg); sg.connect(o.vbus || S.verbIn); }
    osc.start(t); osc.stop(t + dur + 0.05);
  }
  const keys = (f, t, dur, v, bus) => { tone(f, t, dur, { vol: v, attack: 0.012, bus, lp: 1800, verb: 0.35, vbus: S.mverbIn }); tone(f * 2, t, dur * 0.35, { vol: v * 0.18, attack: 0.008, bus, lp: 2400 }); };
  const kalimba = (f, t, v, bus) => { tone(f, t, 1.2, { vol: v, attack: 0.003, bus, lp: 3200, verb: 0.55, vbus: S.mverbIn }); tone(f * 3, t, 0.12, { vol: v * 0.1, bus, lp: 4000 }); };
  const MAJ = [0, 2, 4, 7, 9, 12, 14, 16, 19], MIN = [0, 3, 5, 7, 10, 12, 15, 17, 19];
  const PRESETS = {
    dream:   { bpm: 72,  key: 77, scale: MAJ, chords: [[53,57,60,64],[52,55,59,62],[50,53,57,60],[48,52,55,59]], pad: 0.022, bass: 0.07, arp: [[0,0],[6,2],[10,1],[12,3]], mel: 0.5, mStep: 4 },
    party:   { bpm: 104, key: 72, scale: MAJ, chords: [[48,52,55,62],[45,52,55,60],[41,48,52,57],[43,50,52,59]], pad: 0.014, bass: 0.09, arp: [[0,0],[2,1],[4,2],[6,3],[8,2],[10,1],[12,2],[14,3]], mel: 0.55, mStep: 2, kick: [0,8], hat: true },
    cozy:    { bpm: 78,  key: 79, scale: MAJ, chords: [[43,50,54,59],[40,47,50,54],[36,43,47,52],[38,45,47,54]], pad: 0.018, bass: 0.08, arp: [[0,0],[3,2],[6,1],[10,3],[12,2]], mel: 0.45, mStep: 2, kick: [0,10], swing: true },
    calm:    { bpm: 54,  key: 76, scale: MAJ, chords: [[40,47,51,54],[37,44,47,52],[33,40,44,49],[35,42,47,51]], pad: 0.026, bass: 0.05, arp: [[0,0],[8,2]], mel: 0.3, mStep: 4 },
    mystery: { bpm: 88,  key: 69, scale: MIN, chords: [[45,52,55,59],[38,45,48,54],[41,48,52,57],[40,47,50,55]], pad: 0.018, bass: 0.08, arp: [[0,0],[4,2],[6,1],[10,3],[14,2]], mel: 0.5, mStep: 2, kick: [0,8], hat: true },
    crib_living:  { bpm: 80,  key: 74, scale: MAJ, chords: [[50,54,57,61],[47,50,54,57],[43,47,50,54],[45,49,52,55]], pad: 0.018, bass: 0.075, arp: [[0,0],[3,2],[6,1],[10,3],[13,2]], mel: 0.45, mStep: 2, kick: [0,10], swing: true, snap: true },
    crib_kitchen: { bpm: 98,  key: 76, scale: MAJ, chords: [[48,52,55,60],[53,57,60,64],[50,53,57,62],[55,59,62,65]], pad: 0.012, bass: 0.085, arp: [[0,0],[2,2],[4,1],[6,3],[8,0],[10,2],[12,1],[14,3]], mel: 0.6, mStep: 1, kick: [0,6,8], swing: true, pluck: true },
    crib_bath:    { bpm: 66,  key: 79, scale: MAJ, chords: [[43,47,50,55],[45,48,52,57],[40,43,47,52],[41,45,48,53]], pad: 0.024, bass: 0.05, arp: [[0,0],[6,2],[12,1]], mel: 0.4, mStep: 2, drip: true },
    crib_bed:     { bpm: 46,  key: 81, scale: MAJ, chords: [[41,45,48,52],[38,41,45,48],[36,40,43,47],[43,47,50,53]], pad: 0.03, bass: 0.035, arp: [[0,0],[8,1]], mel: 0.5, mStep: 2, musicbox: true },
    crib_dance:   { bpm: 118, key: 69, scale: MIN, chords: [[45,48,52,55],[41,45,48,52],[48,52,55,59],[43,47,50,55]], pad: 0.012, bass: 0.1, arp: [[0,0],[2,1],[4,2],[6,3],[8,0],[10,1],[12,2],[14,3]], mel: 0.55, mStep: 2, kick: [0,4,8,12], hat: true, clap: true, octBass: true },
    club_disco:   { bpm: 122, key: 72, scale: MAJ, chords: [[48,52,55,59],[45,48,52,55],[41,45,48,52],[43,47,50,53]], pad: 0.014, bass: 0.1, arp: [[0,0],[2,2],[4,1],[6,2],[8,0],[10,2],[12,1],[14,3]], mel: 0.6, mStep: 2, kick: [0,4,8,12], hat: true, clap: true, octBass: true },
    club_house:   { bpm: 124, key: 67, scale: MIN, chords: [[43,46,50,53],[41,44,48,51],[39,43,46,50],[38,41,45,48]], pad: 0.02, bass: 0.11, arp: [[0,0],[3,1],[6,2],[10,1],[12,3]], mel: 0.4, mStep: 4, kick: [0,4,8,12], hat: true, clap: true },
    club_synth:   { bpm: 108, key: 70, scale: MIN, chords: [[46,49,53,56],[42,46,49,53],[44,48,51,55],[41,44,48,51]], pad: 0.024, bass: 0.09, arp: [[0,0],[1,1],[2,2],[3,3],[4,2],[5,1],[6,0],[7,1],[8,2],[9,3],[10,2],[11,1],[12,0],[13,1],[14,2],[15,3]], mel: 0.35, mStep: 4, kick: [0,8], hat: true, octBass: true },
    club_bounce:  { bpm: 100, key: 74, scale: MAJ, chords: [[50,54,57,62],[55,59,62,66],[52,55,59,64],[57,61,64,69]], pad: 0.012, bass: 0.1, arp: [[0,0],[4,2],[6,1],[10,3],[12,2]], mel: 0.6, mStep: 2, kick: [0,6,8,14], hat: true, clap: true },
    club_turbo:   { bpm: 140, key: 69, scale: MIN, chords: [[45,48,52,55],[43,47,50,55],[41,45,48,53],[40,44,47,52]], pad: 0.01, bass: 0.12, arp: [[0,0],[2,1],[4,2],[6,3],[8,0],[10,1],[12,2],[14,3]], mel: 0.5, mStep: 2, kick: [0,4,8,12], hat: true, clap: true, octBass: true },
    crib_yard:    { bpm: 92,  key: 78, scale: [0,2,4,7,9,12,14,16,19], chords: [[42,46,49,54],[47,51,54,59],[44,47,51,56],[49,53,56,61]], pad: 0.014, bass: 0.07, arp: [[0,0],[4,2],[8,1],[12,3]], mel: 0.55, mStep: 2, kick: [0,8], hat: true, birds: true },
  };
  function motif(P, seed) {
    let sd = seed; const rnd = () => ((sd = (sd * 9301 + 49297) % 233280) / 233280);
    const out = []; let d = 2 + Math.floor(rnd() * 3);
    for (let i = 0; i < 32; i++) {
      if (i % P.mStep || rnd() > P.mel) { out.push(null); continue; }
      d = Math.max(0, Math.min(P.scale.length - 1, d + [-2, -1, -1, 1, 1, 2][Math.floor(rnd() * 6)]));
      out.push(P.scale[d]);
    }
    return out;
  }
  function startTrack(name) {
    const c = ready(); if (!c) return;
    const P = PRESETS[name]; if (!P) return;
    const bus = c.createGain(); bus.gain.setValueAtTime(0.0001, c.currentTime); bus.gain.linearRampToValueAtTime(1, c.currentTime + 2);
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3200; bus.connect(lp); lp.connect(S.mus);
    const A = motif(P, 11), B = motif(P, 23);
    const tr = { name, P, bus, step: 0, next: c.currentTime + 0.15 };
    const six = 60 / P.bpm / 4;
    tr.timer = setInterval(() => {
      if (!S.ctx) return;
      while (tr.next < S.ctx.currentTime + 0.2) {
        const s = tr.step % 16, bar = Math.floor(tr.step / 16), ci = Math.floor(bar / 2) % 4, ch = P.chords[ci];
        const t = tr.next + (P.swing && s % 4 === 2 ? six * 0.33 : 0);
        if (s === 0 && bar % 2 === 0) {
          const d = six * 32 + 1.2;
          ch.forEach((m, i) => { swell(mtof(m + 12), t, d, { vol: P.pad, attack: 1.4, release: 1.6, lp: 1100, bus, detune: (i - 1.5) * 5 }); });
          swell(mtof(ch[0] + 24), t, d, { vol: P.pad * 0.35, type: 'triangle', attack: 2, release: 1.6, lp: 1600, bus });
        }
        if (s === 0) tone(mtof(ch[0] - 12), t, six * 10, { vol: P.bass, attack: 0.03, bus, lp: 500 });
        if (s === 8) tone(mtof(ch[0] - 12 + 7), t, six * 6, { vol: P.bass * 0.7, attack: 0.03, bus, lp: 500 });
        P.arp.forEach(([st, ni]) => { if (st === s) keys(mtof(ch[ni % ch.length] + 12), t, six * 6, 0.03, bus); });
        const sec = bar % 8, mot = sec < 2 || sec === 4 || sec === 5 ? A : sec < 4 ? B : null;
        const mi = mot && mot[tr.step % 32];
        if (mi != null) kalimba(mtof(P.key + mi), t, 0.045, bus);
        if (P.kick && P.kick.indexOf(s) >= 0) tone(95, t, 0.28, { to: 48, slide: 0.12, vol: 0.09, attack: 0.004, bus, lp: 600 });
        if (P.hat && s % 4 === 2) noise(t, 0.025, { ft: 'highpass', f: 8000, vol: 0.012, bus });
        if (P.snap && (s === 4 || s === 12)) noise(t, 0.04, { f: 2200, q: 3, vol: 0.03, bus });
        if (P.clap && (s === 4 || s === 12)) { noise(t, 0.09, { f: 1500, q: 1, vol: 0.05, bus }); noise(t + 0.012, 0.06, { f: 1800, q: 1.2, vol: 0.03, bus }); }
        if (P.octBass && s % 2 === 1) tone(mtof(ch[0] + (s % 4 === 1 ? 0 : 12) - 12), t, six * 0.8, { vol: P.bass * 0.55, attack: 0.01, bus, lp: 900 });
        if (P.pluck && s % 4 === 3) tone(mtof(ch[2] + 24), t, 0.12, { type: 'triangle', vol: 0.02, attack: 0.003, bus, lp: 2600 });
        if (P.drip && s % 8 === 5 && Math.random() < 0.6) tone(900 + Math.random() * 700, t, 0.12, { to: 1800 + Math.random() * 600, slide: 0.06, vol: 0.03, attack: 0.005, bus, lp: 2600, verb: 0.5, vbus: S.mverbIn });
        if (P.musicbox && s % 4 === 0 && Math.random() < 0.5) bell(mtof(P.key + 12 + P.scale[Math.floor(Math.random() * 5)]), t, 1.4, 0.03, bus);
        if (P.birds && s === 6 && bar % 3 === 1) { const f0 = 2600 + Math.random() * 900; for (let k = 0; k < 3; k++) tone(f0 * (1 + k * 0.06), t + k * 0.07, 0.06, { to: f0 * 1.25, slide: 0.04, vol: 0.018, attack: 0.004, bus }); }
        tr.step++; tr.next += six;
      }
    }, 25);
    S.track = tr;
  }
  function stopTrack() {
    const tr = S.track; if (!tr) return; S.track = null; clearInterval(tr.timer);
    if (S.ctx) { const t = S.ctx.currentTime; tr.bus.gain.cancelScheduledValues(t); tr.bus.gain.setValueAtTime(tr.bus.gain.value, t); tr.bus.gain.linearRampToValueAtTime(0.0001, t + 1.2); setTimeout(() => tr.bus.disconnect(), 1800); }
  }

  // --- per-creature calm ASMR voices (tonal only, no noise beds) ---
  const rr = (a, b) => a + Math.random() * (b - a);
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  const PENTA = [0, 2, 4, 7, 9, 12, 14, 16];
  const pen = (base) => mtof(base + pick(PENTA));
  function bed() { return { out: null, nodes: [] }; }
  function duck(on) { S.duck = on; if (S.mus && S.ctx) S.mus.gain.setTargetAtTime(on ? 0.0001 : S.musicVol * 0.5, S.ctx.currentTime, on ? 0.15 : 0.6); }
  function bedStop(b, t) { if (!b || !b.out) return; b.out.gain.cancelScheduledValues(t); b.out.gain.setTargetAtTime(0.0001, t, 0.25); b.nodes.forEach(n => { try { n.stop(t + 1.5); } catch (e) {} }); }
  const drop = (t, f, v) => tone(f, t, 0.16, { to: f * 1.7, slide: 0.035, vol: v, attack: 0.004, lp: 3000, verb: 0.45 });
  const bub = (t, f, v) => tone(f, t, 0.1, { to: f * 2, slide: 0.07, vol: v, attack: 0.006, lp: 2200, verb: 0.2 });
  const thump = (t, f, v) => tone(f, t, 0.14, { to: f * 0.55, slide: 0.09, vol: v, attack: 0.006, lp: 900 });
  const click = (t, f, v) => tone(f, t, 0.025, { type: 'triangle', vol: v, attack: 0.001, lp: 5000 });
  const chime = (t, f, v) => { tone(f, t, 1.8, { vol: v, attack: 0.004, verb: 0.7 }); tone(f * 2.76, t, 0.5, { vol: v * 0.12, verb: 0.7 }); };
  const pluck = (t, f, v) => { tone(f, t, 0.9, { vol: v, attack: 0.003, lp: 2600, verb: 0.45 }); tone(f * 2, t, 0.15, { vol: v * 0.15, lp: 3000 }); };
  const hum = (t, f, dur, v) => swell(f, t, dur, { vol: v, attack: dur * 0.4, release: dur * 0.5, lp: 700, verb: 0.3 });
  const snap = (t, n, v) => { for (let i = 0; i < n; i++) noise(t + rr(0, 0.15), rr(0.002, 0.006), { f: rr(1500, 3000), q: 0.8, vol: v * rr(0.4, 1) }); };
  const CRE = [
    { // 0 Glorp — water drips
      bed: { pad: [110, 165] }, gap: [450, 1000],
      start(t) { thump(t, 200, 0.1); drop(t + 0.08, 900, 0.06); },
      tick(t) { drop(t, rr(650, 1100), 0.06); if (Math.random() < 0.25) drop(t + 0.16, rr(900, 1300), 0.035); },
      end(t) { bub(t, 300, 0.07); drop(t + 0.2, 1200, 0.05); },
    },
    { // 1 Puffle — soft fluffy pats
      bed: { pad: [131, 196] }, gap: [500, 1000],
      start(t) { thump(t, 260, 0.08); },
      tick(t) { thump(t, rr(260, 380), 0.06); if (Math.random() < 0.3) chime(t + 0.1, pen(91), 0.012); },
      end(t) { thump(t, 300, 0.07); bub(t + 0.15, 500, 0.04); },
    },
    { // 2 Nubbin — tiny giggles
      bed: { pad: [147, 220] }, gap: [900, 1600],
      start(t) { bub(t, 400, 0.05); },
      tick(t) { const b = 76 + pick([0, 2, 4]); [0, 2, 4].forEach((d, i) => bub(t + i * 0.09, mtof(b + PENTA[d]), 0.035)); },
      end(t) { bub(t, mtof(88), 0.04); bub(t + 0.1, mtof(84), 0.035); },
    },
    { // 3 Dotty — bubbly
      bed: { pad: [165, 247] }, gap: [250, 600],
      start(t) { bub(t, 400, 0.06); },
      tick(t) { bub(t, rr(400, 850), rr(0.03, 0.055)); },
      end(t) { for (let i = 0; i < 5; i++) bub(t + i * 0.07, 450 + i * 110, 0.04); },
    },
    { // 4 Spike — tiny prickle taps
      bed: { pad: [123, 185] }, gap: [500, 1100],
      start(t) { thump(t, 220, 0.08); },
      tick(t) { for (let i = 0; i < 3; i++) click(t + i * 0.05, rr(2200, 3200), 0.03); if (Math.random() < 0.2) pluck(t + 0.2, pen(67), 0.03); },
      end(t) { pluck(t, mtof(72), 0.04); pluck(t + 0.12, mtof(79), 0.035); },
    },
    { // 5 Stellie — star chimes
      bed: { pad: [262, 392], padVol: 0.004 }, gap: [500, 1100],
      start(t) { chime(t, mtof(84), 0.035); },
      tick(t) { chime(t, pen(84), rr(0.018, 0.032)); },
      end(t) { [0, 4, 7, 12].forEach((d, i) => chime(t + i * 0.09, mtof(84 + d), 0.025)); },
    },
    { // 6 Puffington — sleepy hums
      bed: { pad: [98, 147], padVol: 0.007 }, gap: [2000, 3200],
      start(t) { hum(t, 196, 1.6, 0.03); },
      tick(t) { hum(t, pick([196, 220, 247, 294]), 1.8, 0.022); },
      end(t) { hum(t, 147, 2, 0.03); },
    },
    { // 7 Noodle — wobbly glides
      bed: { pad: [110, 165] }, gap: [700, 1300],
      start(t) { tone(300, t, 0.4, { to: 450, slide: 0.2, vol: 0.04, attack: 0.03, lp: 1200 }); },
      tick(t) { const f = rr(300, 420); tone(f, t, 0.45, { to: f * 1.5, slide: 0.2, vol: 0.04, attack: 0.03, lp: 1200 }); tone(f * 1.5, t + 0.22, 0.35, { to: f, vol: 0.03, attack: 0.03, lp: 1200 }); },
      end(t) { tone(260, t, 0.6, { to: 520, slide: 0.35, vol: 0.04, attack: 0.03, lp: 1200 }); },
    },
    { // 8 Glimmer — crystal
      bed: { pad: [523], padVol: 0.003 }, gap: [600, 1200],
      start(t) { chime(t, 2093, 0.03); },
      tick(t) { chime(t, pick([1760, 2093, 2349, 2637, 3136]), rr(0.018, 0.03)); },
      end(t) { [2637, 3136, 3520, 4186].forEach((f, i) => chime(t + i * 0.07, f, 0.02)); },
    },
    { // 9 Ember — gentle fire crackle
      bed: { pad: [98, 147], padVol: 0.009 }, gap: [90, 300],
      start(t) { hum(t, 147, 1, 0.03); },
      tick(t) { snap(t, Math.random() < 0.7 ? 1 : 2, 0.035); if (Math.random() < 0.05) thump(t, 120, 0.05); },
      end(t) { snap(t, 4, 0.03); hum(t, 110, 1.2, 0.025); },
    },
    { // 10 Mochi — soft dough
      bed: { pad: [110, 165] }, gap: [700, 1200],
      start(t) { thump(t, 180, 0.1); },
      tick(t) { thump(t, rr(150, 210), 0.09); },
      end(t) { thump(t, 180, 0.09); bub(t + 0.15, 260, 0.05); },
    },
    { // 11 Zappy — soft zips
      bed: { pad: [147, 220] }, gap: [500, 1000],
      start(t) { tone(2000, t, 0.12, { to: 900, vol: 0.03, lp: 4000 }); },
      tick(t) { tone(rr(1800, 2400), t, 0.08, { to: rr(900, 1200), vol: 0.025, lp: 4000 }); click(t + 0.1, 2600, 0.02); },
      end(t) { tone(2000, t, 0.3, { to: 400, vol: 0.03, lp: 3000, verb: 0.3 }); },
    },
    { // 12 Bubbles — water balloon
      bed: { pad: [98, 147] }, gap: [350, 800],
      start(t) { bub(t, 220, 0.07); },
      tick(t) { bub(t, rr(180, 320), 0.06); if (Math.random() < 0.3) drop(t + 0.12, rr(700, 1000), 0.035); },
      end(t) { for (let i = 0; i < 4; i++) bub(t + i * 0.08, 200 + i * 60, 0.05); },
    },
    { // 13 Grumps — grumbly then content
      bed: { pad: [82, 123] }, gap: [1100, 1800],
      start(t) { tone(120, t, 0.5, { type: 'triangle', to: 95, vol: 0.06, attack: 0.04, lp: 500 }); },
      tick(t) { if (Math.random() < 0.7) tone(rr(110, 130), t, 0.55, { type: 'triangle', to: rr(90, 100), vol: 0.055, attack: 0.05, lp: 500 }); else pluck(t, mtof(76), 0.03); },
      end(t) { tone(120, t, 0.4, { type: 'triangle', to: 90, vol: 0.05, attack: 0.04, lp: 500 }); pluck(t + 0.45, mtof(81), 0.035); },
    },
    { // 14 Sprout — seedling plucks
      bed: { pad: [196, 294], padVol: 0.004 }, gap: [600, 1100],
      start(t) { pluck(t, mtof(72), 0.04); },
      tick(t) { pluck(t, pen(72), 0.035); if (Math.random() < 0.3) click(t + 0.2, 1200, 0.025); },
      end(t) { [0, 4, 7].forEach((d, i) => pluck(t + i * 0.1, mtof(72 + d), 0.035)); },
    },
    { // 15 Cinder — deep warm bloops
      bed: { pad: [65, 98], padVol: 0.01 }, gap: [900, 1600],
      start(t) { tone(70, t, 0.8, { vol: 0.08, attack: 0.03, lp: 400 }); },
      tick(t) { const f = rr(70, 100); tone(f, t, 0.4, { to: f * 1.6, slide: 0.25, vol: 0.07, attack: 0.02, lp: 400 }); if (Math.random() < 0.2) snap(t + 0.2, 1, 0.025); },
      end(t) { tone(70, t, 1, { to: 50, vol: 0.08, attack: 0.03, lp: 400 }); },
    },
    { // 16 Pearla — shell harp
      bed: { pad: [220, 330], padVol: 0.004 }, gap: [900, 1500],
      start(t) { pluck(t, mtof(76), 0.035); },
      tick(t) { const b = 72 + pick([0, 2, 4]); [0, 2, 4].forEach((d, i) => pluck(t + i * 0.12, mtof(b + PENTA[d]), 0.028)); },
      end(t) { chime(t, 1320, 0.022); },
    },
    { // 17 Tako — suction pops
      bed: { pad: [110, 165] }, gap: [450, 900],
      start(t) { thump(t, 280, 0.08); },
      tick(t) { thump(t, rr(240, 320), 0.07); },
      end(t) { for (let i = 0; i < 4; i++) thump(t + i * 0.1, 300 - i * 20, 0.06); },
    },
    { // 18 Fuzzball — woolly hums
      bed: { pad: [131, 196], padVol: 0.007 }, gap: [700, 1200],
      start(t) { hum(t, 196, 0.6, 0.03); },
      tick(t) { hum(t, rr(180, 240), 0.5, 0.025); thump(t + 0.1, 200, 0.03); },
      end(t) { hum(t, 165, 0.9, 0.03); },
    },
    { // 19 Cosmo — tiny galaxy
      bed: { pad: [110, 165, 220], padVol: 0.005 }, gap: [900, 1700],
      start(t) { tone(880, t, 1.5, { to: 440, slide: 1.2, vol: 0.025, attack: 0.1, verb: 0.9 }); },
      tick(t) { chime(t, pen(76), 0.02); },
      end(t) { tone(330, t, 1.6, { to: 990, slide: 1.2, vol: 0.025, attack: 0.1, verb: 0.9 }); },
    },
  ];
  function creatureStart(id) {
    const c = ready(); if (!c || !S.enabled) return; creatureStop(true);
    duck(true); const P = CRE[id]; if (!P) { squishStart(); return; }
    const t = c.currentTime; P.start(t);
    const cr = { P, b: bed(t, P.bed), on: true };
    const loop = () => { if (!cr.on || !S.ctx) return; P.tick(S.ctx.currentTime + 0.01); cr.timer = setTimeout(loop, rr(P.gap[0], P.gap[1])); };
    cr.timer = setTimeout(loop, rr(P.gap[0], P.gap[1]));
    S.cre = cr;
  }
  function creatureStop(silent) {
    squishStop(); if (S.duck) duck(false);
    const cr = S.cre; if (!cr || !S.ctx) return; S.cre = null; cr.on = false; clearTimeout(cr.timer);
    const t = S.ctx.currentTime; bedStop(cr.b, t); if (!silent) cr.P.end(t);
  }
  function creaturePreview(id, secs) { creatureStart(id); clearTimeout(S.creT); S.creT = setTimeout(() => creatureStop(), (secs || 4) * 1000); }
  function wav(buf) {
    const ch = buf.numberOfChannels, n = buf.length, sr = buf.sampleRate, ab = new ArrayBuffer(44 + n * ch * 2), v = new DataView(ab);
    const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    w(0, 'RIFF'); v.setUint32(4, 36 + n * ch * 2, true); w(8, 'WAVEfmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, ch, true);
    v.setUint32(24, sr, true); v.setUint32(28, sr * ch * 2, true); v.setUint16(32, ch * 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * ch * 2, true);
    const d = []; for (let c = 0; c < ch; c++) d.push(buf.getChannelData(c));
    let o = 44; for (let i = 0; i < n; i++) for (let c = 0; c < ch; c++) { const s = Math.max(-1, Math.min(1, d[c][i])); v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true); o += 2; }
    return new Blob([ab], { type: 'audio/wav' });
  }
  function renderCreature(id, secs) {
    secs = secs || 8; const P = CRE[id]; const sr = 44100;
    const c = new OfflineAudioContext(2, sr * secs, sr);
    const keep = { ctx: S.ctx, master: S.master, sfx: S.sfx, verb: S.verb, verbIn: S.verbIn, noiseBuf: S.noiseBuf };
    const comp = c.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4; comp.connect(c.destination);
    const master = c.createGain(); master.gain.value = 2.2; master.connect(comp);
    const sfx = c.createGain(); sfx.gain.value = 1; sfx.connect(master);
    const len = sr * 1.8, ir = c.createBuffer(2, len, sr);
    for (let k = 0; k < 2; k++) { const d = ir.getChannelData(k); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3); }
    const verb = c.createConvolver(); verb.buffer = ir; const verbIn = c.createGain(); verbIn.gain.value = 0.35; verbIn.connect(verb); verb.connect(master);
    const nb = c.createBuffer(1, sr * 2, sr); const nd = nb.getChannelData(0); for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
    Object.assign(S, { ctx: c, master, sfx, verb, verbIn, noiseBuf: nb });
    try {
      const t0 = 0.05, tEnd = secs - 1.8; P.start(t0); const b = bed(t0, P.bed);
      let x = t0 + rr(P.gap[0], P.gap[1]) / 1000; while (x < tEnd) { P.tick(x); x += rr(P.gap[0], P.gap[1]) / 1000; }
      bedStop(b, tEnd); P.end(tEnd);
    } finally { Object.assign(S, keep); }
    return c.startRendering().then(wav);
  }

  window.SFX = {
    play(name, delay) { const c = ready(); if (!c || !S.enabled || !SOUNDS[name]) return; SOUNDS[name](c.currentTime + (delay || 0)); },
    boxTap(n) {
      const c = ready(); if (!c || !S.enabled) return; const t = c.currentTime;
      tone(150 + n * 15, t, 0.16, { to: 90, vol: 0.35 }); noise(t, 0.06, { f: 900 + n * 150, q: 2, vol: 0.18 });
      bell(mtof(72 + [0, 2, 4, 7, 9, 12, 14, 16, 19, 24][Math.min(9, n - 1)]), t + 0.02, 0.5, 0.1);
    },
    music(name) {
      S.want = name || null;
      if (S.track && S.track.name === name) return;
      stopTrack(); if (name && ready()) startTrack(name);
    },
    setEnabled(on) { S.enabled = !!on; if (S.master) S.master.gain.setTargetAtTime(on ? 1 : 0, S.ctx.currentTime, 0.08); if (!on) { squishStop(); holdStop(); reelStop(); } },
    setVolumes(music, sfx) {
      S.musicVol = music; S.sfxVol = sfx;
      if (S.mus) { S.mus.gain.setTargetAtTime(S.duck ? 0.0001 : music * 0.5, S.ctx.currentTime, 0.1); S.sfx.gain.setTargetAtTime(sfx, S.ctx.currentTime, 0.1); }
    },
    creatureStart, creatureStop, creaturePreview, renderCreature,
    holdStart, holdUpdate, holdStop, squishStart, squishStop, wheelSpin, reelStart, reelLand, reelStop,
    stopAll() { stopTrack(); creatureStop(true); squishStop(); holdStop(); reelStop(); },
  };
})();
