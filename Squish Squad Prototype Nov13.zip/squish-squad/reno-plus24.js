// Renovation Catalog round 24 — Living Room furniture detail pass 1: the 13 round-22 pieces the user flagged as "needs much more detailed texture"
// (lamps 002/042/062/082, consoles 023/063/083, coffee 056/076, side 019/039/059/099). Each N.<x>24 wraps N.<x>22 (same verified geometry, fx, anims)
// and glues surface texture on top: grain, veins, weave, strata, pores, brushing, reflections, scuffs, labels + a few small props.
// dec(): one cv:0 solid holding many flat decal faces lifted off a surface; every face is culled on its own when it turns away (no fn needed).
// Sets RenoDraw.PLUS24; catalog edits RD.SET24; toolkit RD.H24 {dec, spot, elP, wv, at, rrect, ext}.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS23 && RD.H22 && RD.H16 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS24) return;
  const K = X.K, { box, cyl, ball, shade, mix } = K;
  const N = RD.N, PI = Math.PI, BR = '#d4a548', CH = '#d5dde2';
  const { tilt, rotF, rod, pipe, M_, W_, F_, PL, rep } = RD.H16;
  const { band, R0, glue, rp, book } = RD.H22;
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], mul = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
  const cr = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], nz = a => { const L = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / L, a[1] / L, a[2] / L]; };
  const X3 = [1, 0, 0], Y3 = [0, 1, 0], Z3 = [0, 0, 1], cN = a => [Math.cos(a), 0, Math.sin(a)];
  const wv = (m, f) => rep(m + 1, i => f(i / m));
  // dec: decal solid. line(P, N, w, taper) = ribbon along points P on a surface with normal N (one vector or one per point); poly(P, n) = flat patch
  const dec = (col, o) => { const S = Object.assign({ faces: [], pts: [], col, cv: 0, zb: 0, noOut: 1 }, o || {}), LF = 0.05;
    S.line = (P, Nn, w, tp) => { const n = P.length; if (n < 2) return S; const nn = i => Array.isArray(Nn[0]) ? Nn[i] : Nn;
      const L = P.map((p, i) => { const t = nz(sub(P[Math.min(n - 1, i + 1)], P[Math.max(0, i - 1)])), q = nn(i), sd = nz(cr(t, q)), k = (tp ? Math.max(0.2, Math.sin(PI * i / (n - 1))) : 1) * w / 2, b = add(p, mul(q, LF)); return [add(b, mul(sd, k)), add(b, mul(sd, -k))]; });
      for (let i = 0; i < n - 1; i++) { const q = [L[i][0], L[i + 1][0], L[i + 1][1], L[i][1]]; S.faces.push({ q, n: nz(add(nn(i), nn(i + 1))) }); q.forEach(p => S.pts.push(p.slice())); } return S; };
    S.poly = (P, n) => { const q = P.map(p => add(p, mul(n, LF))); S.faces.push({ q, n: n.slice() }); q.forEach(p => S.pts.push(p.slice())); return S; };
    return S; };
  const elP = (c, u, v, rx, ry, m) => rep(m || 10, i => { const a = i / (m || 10) * 2 * PI; return add(c, add(mul(u, Math.cos(a) * rx), mul(v, Math.sin(a) * ry))); });
  // spot: small ellipse lying on a surface (rx along the horizontal tangent, ry along the other one), turned by rot
  const spot = (D, c, n, rx, ry, rot, m) => { let u = Math.abs(n[1]) > 0.9 ? X3 : nz(cr(Y3, n)), v = nz(cr(n, u)); if (rot) { const a = Math.cos(rot), b = Math.sin(rot), u2 = add(mul(u, a), mul(v, b)); v = add(mul(v, a), mul(u, -b)); u = u2; } return D.poly(elP(c, u, v, rx, ry, m || 8), n); };
  const rrect = (cx, y, cz, w, d, yaw, ox, oz) => { const c = Math.cos(yaw || 0), s = Math.sin(yaw || 0); ox = ox || 0; oz = oz || 0; return [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([a, b]) => { const u = ox + a * w / 2, v = oz + b * d / 2; return [cx + u * c - v * s, y, cz + u * s + v * c]; }); };
  const bb = S => { const L = [1e9, -1e9, 1e9, -1e9, 1e9, -1e9]; S.pts.forEach(p => { for (let k = 0; k < 3; k++) { if (p[k] < L[2 * k]) L[2 * k] = p[k]; if (p[k] > L[2 * k + 1]) L[2 * k + 1] = p[k]; } }); return L; };
  // at: smallest solid (of colour col) whose box holds p; glued details are skipped unless all
  const at = (o, p, col, m, all) => { m = m == null ? 0.6 : m; let best = null, bv = 1e18; o.forEach(S => { if ((S.par && !all) || (col && S.col !== col) || !S.pts) return; const L = bb(S);
    if (p[0] < L[0] - m || p[0] > L[1] + m || p[1] < L[2] - m || p[1] > L[3] + m || p[2] < L[4] - m || p[2] > L[5] + m) return; const v = (L[1] - L[0] + 0.1) * (L[3] - L[2] + 0.1) * (L[5] - L[4] + 0.1); if (v < bv) { bv = v; best = S; } }); return best; };
  const ext = (src, f, more) => S => { const B = N[src](S), D = Object.assign({}, B, more || {}); if (B.build) D.build = (...a) => { const o = B.build(...a); f(o, glue(o), R0(src + '24')); return o; }; return D; };
  const ringY = (D, cx, cz, r, y, w, m) => D.line(wv(m || 40, t => [cx + Math.cos(t * 2 * PI) * r, y, cz + Math.sin(t * 2 * PI) * r]), Y3, w);
  const ringC = (D, cx, cz, r, y, w, m, wob, ph) => D.line(wv(m || 40, t => { const a = t * 2 * PI; return [cx + Math.cos(a) * r, y + (wob ? wob * Math.sin(a * 3 + (ph || 0)) : 0), cz + Math.sin(a) * r]; }), wv(m || 40, t => cN(t * 2 * PI)), w);

  // ======================= LAMPS =======================
  // LIV-002 torchiere: brushed rings, scuffs, rust + price sticker on the base, rubber foot, rust streaks + rotary switch on the pole, wrinkled tape + loose flap, ribbed shade with scorch + 2nd crack, rocker switch on the cord
  N.torch24 = ext('torch22', (o, on, R) => { const ST = '#8a8f94', TA = -0.22, piv = [7, 121, 7], RT = rotF([1, 0, 0], TA), P = v => rp(RT, piv, v);
    const BS = at(o, [9, 1, 0], ST);
    if (BS) { const d1 = dec('#dfe4e8', { op: 0.5 }), d2 = dec('#3e3428', { op: 0.55 }), d3 = dec('#9a5a2e', { op: 0.6 });
      [4, 5.6, 7.2, 8.8, 10].forEach((r, k) => ringY(d1, 0, 0, r, 3, k % 2 ? 0.12 : 0.2, 48));
      rep(8, () => { const a = R() * 2 * PI, r = 4.4 + R() * 5, L = 1.2 + R() * 2, b = a + 1.3 + R(), p = [Math.cos(a) * r, 3, Math.sin(a) * r]; d2.line([p, add(p, [Math.cos(b) * L, 0, Math.sin(b) * L])], Y3, 0.18); });
      rep(8, () => { const a = R() * 2 * PI, r = 4.2 + R() * 5.6; spot(d3, [Math.cos(a) * r, 3, Math.sin(a) * r], Y3, 0.3 + R() * 0.6, 0.2 + R() * 0.35, R() * 3); });
      rep(7, () => { const a = R() * 2 * PI; spot(d3, [Math.cos(a) * 11.9, 1.4, Math.sin(a) * 11.9], nz([Math.cos(a), 0.78, Math.sin(a)]), 0.6 + R() * 0.6, 0.3, 0); });
      const SK = dec('#f28a3a'); SK.poly(elP([5, 3, -4.6], X3, Z3, 2.2, 1.5, 14), Y3); const SK2 = dec('#fff4dc'); SK2.poly(elP([5, 3, -4.6], X3, Z3, 1.5, 0.95, 12), Y3);
      const SK3 = dec('#5a3a22'); rep(5, i => SK3.line([[4.1 + i * 0.42, 3, -5.1], [4.1 + i * 0.42, 3, -4.1]], Y3, i % 2 ? 0.12 : 0.22));
      on(BS, [band(0, 0, 0, 13.06, 0.9, '#2a2b30', { n: 26, noOut: 1 }), d1, d2, d3, SK, SK2, SK3]); }
    const PO = at(o, [0.4, 27, 0.2], ST);
    if (PO) { const y = 33, x = 0.8 * (y - 5.4) / 42.6, z = 0.4 * (y - 5.4) / 42.6, d = dec('#8a4a24', { op: 0.6 });
      rep(8, () => { const a = R() * 2 * PI, yy = 8 + R() * 36, xx = 0.8 * (yy - 5.4) / 42.6, zz = 0.4 * (yy - 5.4) / 42.6; spot(d, [xx + Math.cos(a), yy, zz + Math.sin(a)], cN(a), 0.32, 0.5 + R() * 0.7, 0); });
      on(PO, [d, cyl(x, y - 1.7, z, 1.8, 3.4, '#2a2b30', PL({ n: 12 })), band(x, y + 1.1, z, 1.82, 0.35, '#5c6166', { n: 12, noOut: 1 })]);
      on(PO, [box(x, y - 0.8, z + 1.9, 1.3, 1.4, 1.2, '#e8e2d4', PL({ r: 0.4 }))], Z3); }
    const TP = at(o, [0.3, 62, 0.5], '#b9bec4', 0.6, 1);
    if (TP) { const d = dec('#7d8288', { op: 0.55 }); [60.9, 62.4, 63.8].forEach((y, k) => ringC(d, 0.3, 0.5, 1.62, y, 0.16, 16, 0.25, k)); on(TP, [d]);
      on(TP, [tilt(box(1.95, 59.6, 1.2, 0.25, 2.4, 1.4, '#c6cbd0', { r: 0.2, noOut: 1 }), [0, 0, 1], 0.25, [1.9, 62, 1.2])], X3); }
    const SH = at(o, P([7, 125, 7]), '#eadcbe', 0.6, 1);
    if (SH) { const rr = y => 6 * (y < 4 ? 0.45 + 0.5 * y / 4 : 0.95 + 1.3 * (y - 4) / 9), sl = y => y < 4 ? 0.75 : 0.867;
      const pt = (a, y, k) => P([7 + Math.cos(a) * rr(y) * (k || 1.01), 118 + y, 7 + Math.sin(a) * rr(y) * (k || 1.01)]), nn = (a, y) => RT(nz([Math.cos(a), -sl(y), Math.sin(a)]));
      const RB = dec('#cdbb94', { op: 0.75 }), HL = dec('#fff8e6', { op: 0.6 }); rep(20, i => { const a = i / 20 * 2 * PI, Y = wv(8, t => 0.6 + t * 12); RB.line(Y.map(y => pt(a, y)), Y.map(y => nn(a, y)), 0.3); HL.line(Y.map(y => pt(a + 0.07, y)), Y.map(y => nn(a + 0.07, y)), 0.14); });
      const SC = dec('#a8743a', { op: 0.35 }); spot(SC, pt(2.4, 10.4), nn(2.4, 10.4), 2.6, 1.4, 0); spot(SC, pt(2.4, 10.8), nn(2.4, 10.8), 1.3, 0.7, 0);
      const CK = dec('#6a5a40', { op: 0.8 }); CK.line([pt(1.25, 12.6), pt(1.32, 11), pt(1.24, 9.6), pt(1.36, 8.2), pt(1.3, 7)], [nn(1.25, 12), nn(1.3, 11), nn(1.25, 9.6), nn(1.35, 8.2), nn(1.3, 7)], 0.3, 1);
      on(SH, [RB, HL, SC, CK]); }
    const CD = at(o, [-3, 0.8, -15], '#3a3b40');
    if (CD) { const LD = dec('#d9443a'); LD.poly(elP([-3, 1.4, -15], X3, Z3, 0.5, 0.5, 8), Y3); on(CD, [box(-3, 0, -15, 2.2, 1.4, 3.6, '#f2efe6', PL({ r: 0.6, yaw: 0.785 })), LD]); } });

  // LIV-042 arc lamp: grey + pale veins over every face of the marble block, knurled hub, joint collars along the arc, dome vents + seam + chrome reflections, foot switch puck
  N.arc24 = ext('arc22', (o, on, R) => { const MB = '#f4f1ec', BX = -40, BZ = -8, DX = 30, DZ = 8, DY = 92;
    const bez = t => { const Q = [[BX, 12, BZ], [BX, 156, BZ], [DX, 158, DZ], [DX, DY + 14, DZ]], u = 1 - t; return [0, 1, 2].map(k => u * u * u * Q[0][k] + 3 * u * u * t * Q[1][k] + 3 * u * t * t * Q[2][k] + t * t * t * Q[3][k]); };
    const BS = at(o, [BX + 8, 5, BZ], MB);
    if (BS) { const V1 = dec('#9d958a', { op: 0.7 }), V2 = dec('#c2bbb0', { op: 0.6 }), h = 13;
      const vn = (D, f, n, u0, v0, u1, v1, w, amp, ph) => D.line(wv(14, t => f(u0 + (u1 - u0) * t + Math.sin(t * 9 + ph) * amp * 0.4, v0 + (v1 - v0) * t + Math.sin(t * 6.3 + ph) * amp)), n, w, 1);
      const FZ = (u, v) => [BX + u, v, BZ + h], BK = (u, v) => [BX - u, v, BZ - h], FX = (u, v) => [BX + h, v, BZ - u], FXm = (u, v) => [BX - h, v, BZ + u], TPf = (u, v) => [BX + u, 11, BZ + v];
      vn(V1, FZ, Z3, -10.4, 9.4, 10.4, 2, 0.42, 0.8, 1); vn(V2, FZ, Z3, -3, 7, 6, 0.8, 0.22, 0.6, 2); vn(V2, FZ, Z3, 2, 9.6, 10.4, 6, 0.18, 0.5, 3);
      vn(V1, FX, X3, -10.4, 2, 10.4, 9.4, 0.4, 0.8, 4); vn(V2, FX, X3, -4, 3.5, 4, 1, 0.2, 0.5, 5);
      vn(V1, FXm, mul(X3, -1), -10.4, 6, 10.4, 3, 0.35, 0.7, 6); vn(V1, BK, mul(Z3, -1), -10.4, 3, 10.4, 9, 0.35, 0.7, 7);
      vn(V1, TPf, Y3, -10.4, 6, 10.4, -9, 0.3, 0.8, 8); vn(V2, TPf, Y3, -8, -10, 4, 10, 0.18, 0.6, 9); vn(V2, TPf, Y3, 3, 10, 10, -2, 0.16, 0.5, 10);
      const SP = dec('#b7afa2', { op: 0.5 }); rep(14, () => spot(SP, [BX + (R() - 0.5) * 20, 11, BZ + (R() - 0.5) * 20], Y3, 0.3 + R() * 0.5, 0.2 + R() * 0.3, R() * 3, 6));
      on(BS, [V2, V1, SP]); }
    const HB = at(o, [BX + 2.6, 12.6, BZ], CH);
    if (HB) { const KN = dec('#8e989f', { op: 0.65 }); rep(18, i => { const a = i / 18 * 2 * PI; KN.line([[BX + Math.cos(a) * 2.83, 11.5, BZ + Math.sin(a) * 2.83], [BX + Math.cos(a) * 2.83, 14, BZ + Math.sin(a) * 2.83]], cN(a), 0.22); }); on(HB, [KN]); }
    [0.24, 0.52, 0.8].forEach(t => { const p = bez(t), d = nz(sub(bez(t + 0.01), p)), S = at(o, p, CH, 0.4); if (S) on(S, [rod(add(p, mul(d, -1.1)), add(p, mul(d, 1.1)), 1.75, '#b4bec5', M_({ n: 10 })), rod(add(p, mul(d, -1.5)), add(p, mul(d, -1.1)), 1.5, '#8e989f', M_({ n: 10, noOut: 1 }))]); });
    const DM = at(o, [DX + 11, DY + 2, DZ], CH);
    if (DM) { const pf = [[0, 1], [4, 0.96], [8, 0.8], [11, 0.55], [13, 0.25], [14, 0.08]], rr = y => { for (let i = 0; i < 5; i++) if (y <= pf[i + 1][0]) { const [y0, a] = pf[i], [y1, b] = pf[i + 1]; return 14 * (a + (b - a) * (y - y0) / (y1 - y0)); } return 1; }, sl = y => (rr(Math.min(14, y + 0.2)) - rr(Math.max(0, y - 0.2))) / 0.4;
      const pt = (a, y) => [DX + Math.cos(a) * rr(y) * 1.004, DY + y, DZ + Math.sin(a) * rr(y) * 1.004], nn = (a, y) => nz([Math.cos(a), -sl(y), Math.sin(a)]);
      const H1 = dec('#30353a', { op: 0.85 }); rep(18, i => { const a = i / 18 * 2 * PI, n = nn(a, 9.6), u = [-Math.sin(a), 0, Math.cos(a)], v = nz(cr(n, u)); H1.poly(elP(pt(a, 9.6), u, v, 0.5, 0.5, 8), n); });
      const S1 = dec('#7d878e', { op: 0.6 }); S1.line(wv(36, t => pt(t * 2 * PI, 3.2)), wv(36, t => nn(t * 2 * PI, 3.2)), 0.3);
      const RF = dec('#ffffff', { op: 0.7 }), RK = dec('#5d666d', { op: 0.32 });
      [[2.5, 1.6, RF], [1.0, 2.4, RK]].forEach(([a, w, D]) => { const Y = wv(10, t => 0.8 + t * 10.6); D.line(Y.map(y => pt(a, y)), Y.map(y => nn(a, y)), w, 1); });
      on(DM, [S1, RK, RF, H1]); }
    const CD = at(o, [BX - 7, 0.6, BZ - 21], '#3a3b40');
    if (CD) { const LD = dec('#ff6a4a', { emit: 1 }); LD.poly(elP([BX - 8.4, 1.62, BZ - 25.6], X3, Z3, 0.5, 0.5, 8), Y3); const RG2 = dec('#5a5c62', { op: 0.8 }); ringY(RG2, BX - 8.4, BZ - 25.6, 1.8, 1.62, 0.25, 20);
      on(CD, [cyl(BX - 8.4, 0, BZ - 25.6, 2.6, 1.6, '#2a2b30', PL({ n: 16 })), RG2, LD]); } });

  // LIV-062 alabaster totem: amber + white veins and cloudy inclusions wrapping round every stone, grooved spacers, patina + engraved rings on the bronze base
  const ST62 = [[11, 15, 0.6], [13.5, 19, -1], [9, 13, 1.2], [12, 21, 0], [8, 12, -0.6], [10.5, 17, 0.5]];
  N.alab24 = ext('alab22', (o, on, R) => { const BRZ = '#7a5534', AL = ['#fbe8c8', '#f7dcb6', '#fdeed6'];
    let y = 4.6; const L = ST62.map(([r, h, dx]) => { const s = { r, h, dx, y }; y += h + 2.4; return s; });
    const pf = t => { const Kk = [[0, 0.5], [0.18, 0.9], [0.5, 1], [0.82, 0.9], [1, 0.5]]; for (let i = 0; i < 4; i++) if (t <= Kk[i + 1][0]) return Kk[i][1] + (Kk[i + 1][1] - Kk[i][1]) * (t - Kk[i][0]) / (Kk[i + 1][0] - Kk[i][0]); return 0.5; };
    L.forEach((s, i) => { const S = at(o, [s.dx + s.r * 0.6, s.y + s.h / 2, 0], AL[i % 3]); if (!S) return;
      const pt = (a, t) => { const f = pf(t) * 1.01; return [s.dx + Math.cos(a) * s.r * f, s.y + s.h * t, Math.sin(a) * s.r * 0.86 * f]; }, nn = a => nz([Math.cos(a) / s.r, 0, Math.sin(a) / (s.r * 0.86)]);
      const V1 = dec('#d79a66', { op: 0.5, emit: 1 }), V2 = dec('#ffffff', { op: 0.75, emit: 1 }), V3 = dec('#e9c89c', { op: 0.4, emit: 1 });
      rep(5, () => { const a = R() * 2 * PI, t = 0.18 + R() * 0.64; spot(V3, pt(a, t), nn(a), 0.8 + R() * 1.6, 0.4 + R() * 0.8, (R() - 0.5) * 0.8); });
      rep(5, k => { const a0 = R() * 2 * PI, da = 1.2 + R() * 1.8, t0 = 0.22 + R() * 0.56, amp = 0.06 + R() * 0.12, ph = R() * 6, D = k % 2 ? V2 : V1, T = wv(16, u => [a0 + da * u, Math.min(0.88, Math.max(0.12, t0 + amp * Math.sin(u * 7 + ph) + 0.05 * Math.sin(u * 19 + ph)))]);
        D.line(T.map(([a, t]) => pt(a, t)), T.map(([a]) => nn(a)), k % 2 ? 0.22 : 0.42, 1); });
      on(S, [V3, V1, V2]);
      const SP = at(o, [s.dx * 0.5 + 3.1, s.y + s.h + 1.2, 0], BRZ); if (SP) { const G = dec('#3e2a1a', { op: 0.75 }), HL = dec('#c9925a', { op: 0.6 }); ringC(G, s.dx * 0.5, 0, 3.43, s.y + s.h + 1.2, 0.32, 24); ringC(HL, s.dx * 0.5, 0, 3.43, s.y + s.h + 0.5, 0.2, 24); on(SP, [G, HL]); } });
    const BS = at(o, [11, 2, 0], BRZ);
    if (BS) { const PA = dec('#6f9a80', { op: 0.5 }), EN = dec('#3e2a1a', { op: 0.7 }), HL = dec('#c9925a', { op: 0.55 });
      rep(12, () => { const a = R() * 2 * PI, r = 4 + R() * 7.6; spot(PA, [Math.cos(a) * r, 4.6, Math.sin(a) * r], Y3, 0.4 + R() * 0.9, 0.3 + R() * 0.5, R() * 3); });
      rep(10, () => { const a = R() * 2 * PI; spot(PA, [Math.cos(a) * 13.4, 0.8 + R() * 3, Math.sin(a) * 13.4], nz([Math.cos(a), 0.3, Math.sin(a)]), 0.5 + R() * 0.8, 0.3 + R() * 0.4, 0); });
      ringY(EN, 0, 0, 11.6, 4.6, 0.3, 48); ringY(EN, 0, 0, 10.4, 4.6, 0.2, 48); ringY(HL, 0, 0, 12.2, 4.6, 0.22, 48);
      on(BS, [PA, EN, HL]); } });

  // LIV-082 bio tower: carved ribs + glowing runes + pores on the pot, moss tufts + tiny glowing mushrooms round the glass foot, brass ribs + band + condensation drops on the glass, vents in the cap
  N.bio24 = ext('bio22', (o, on, R) => { const POT = '#2b3436', PT = at(o, [14, 8, 0], POT); if (!PT) return;
    const RB = dec('#4a5a5f', { op: 0.9 }), RS = dec('#161c1e', { op: 0.8 }), GL = dec('#5cf2b0', { emit: 1, op: 0.9 }), PO = dec('#1a2022', { op: 0.6 });
    ringC(RB, 0, 0, 15.03, 3, 0.6, 40); ringC(RS, 0, 0, 15.03, 3.7, 0.28, 40); ringC(RB, 0, 0, 15.03, 13.2, 0.6, 40); ringC(RS, 0, 0, 15.03, 12.5, 0.28, 40);
    rep(12, i => { const a = i / 12 * 2 * PI + 0.13, c = [Math.cos(a) * 15.03, 8, Math.sin(a) * 15.03], u = [-Math.sin(a), 0, Math.cos(a)];
      GL.line(i % 2 ? [add(c, add(mul(u, -1), [0, -1.8, 0])), add(c, [0, 1.8, 0]), add(c, add(mul(u, 1), [0, -1.8, 0]))] : [add(c, [0, -1.8, 0]), add(c, [0, 1.8, 0])], cN(a), 0.34);
      if (!(i % 2)) GL.line([add(c, add(mul(u, -0.9), [0, 0.3, 0])), add(c, add(mul(u, 0.9), [0, 0.3, 0]))], cN(a), 0.3); });
    rep(40, () => { const a = R() * 2 * PI, y = 1 + R() * 14; spot(PO, [Math.cos(a) * 15.03, y, Math.sin(a) * 15.03], cN(a), 0.2 + R() * 0.35, 0.15 + R() * 0.2, 0, 6); });
    on(PT, [RB, RS, GL, PO]);
    rep(16, i => { const a = i / 16 * 2 * PI + R() * 0.2, r = 12.4 + R() * 0.8; on(PT, [ball(Math.cos(a) * r, 17.2, Math.sin(a) * r, 1.4 + R() * 0.7, ['#4f8a3e', '#6fae5a', '#3e7a3a'][i % 3], { sy: 0.6, k: 3, n: 8, shine: 0, mat: 'fab' })], cN(a)); });
    [0.6, 2.3, 4.4].forEach((a, i) => { const x = Math.cos(a) * 12.6, z = Math.sin(a) * 12.6; on(PT, [cyl(x, 17.8, z, 0.35, 2.4 + i * 0.4, '#e8fff2', { n: 6, noOut: 1 }), ball(x, 19.9 + i * 0.4, z, 1 + i * 0.15, ['#7fd8ff', '#b48cff', '#9affdc'][i], { sy: 0.55, k: 3, n: 8, emit: 1, noOut: 1 })], cN(a)); });
    const RIB = dec(BR, { op: 0.9 }), DR = dec('#ffffff', { op: 0.55 }), DH = dec('#9fe8ff', { op: 0.35 });
    rep(4, i => { const a = PI / 4 + i * PI / 2; RIB.line([[Math.cos(a) * 10.75, 17.4, Math.sin(a) * 10.75], [Math.cos(a) * 10.75, 113, Math.sin(a) * 10.75]], cN(a), 0.8); });
    ringC(RIB, 0, 0, 10.75, 65, 0.9, 40); ringC(RIB, 0, 0, 10.75, 18, 0.9, 40);
    rep(36, () => { const a = R() * 2 * PI, y = 22 + R() * 88; spot(DR, [Math.cos(a) * 10.66, y, Math.sin(a) * 10.66], cN(a), 0.18 + R() * 0.25, 0.25 + R() * 0.35, 0, 6); });
    rep(3, i => { const a = 2.2 + i * 0.12; DH.line([[Math.cos(a) * 10.66, 24, Math.sin(a) * 10.66], [Math.cos(a) * 10.66, 106, Math.sin(a) * 10.66]], cN(a), i === 1 ? 1.4 : 0.4); });
    on(PT, [DH, RIB, DR]);
    const CP = at(o, [11.3, 114.6, 0], BR, 0.6, 1); if (CP) { const VT = dec('#3a2a14', { op: 0.8 }); rep(24, i => { const a = i / 24 * 2 * PI; VT.line([[Math.cos(a) * 11.63, 113.9, Math.sin(a) * 11.63], [Math.cos(a) * 11.63, 115.6, Math.sin(a) * 11.63]], cN(a), 0.4); }); on(CP, [VT]); } });

  // ======================= CONSOLE TABLES =======================
  // LIV-023 iron + glass console: green glass edges + glints on both glass layers, leveler feet + edge highlights on the legs, woven basket with a knit throw, keys, coin, envelope, framed photo
  N.iron24 = ext('iron22', (o, on, R) => { const IR = '#25262a', GL = '#cfe6ee', W = 118, Dp = 28, H = 56;
    const edge = (y0, h, w2, d2) => { const E = dec('#78c4a8', { op: 0.85 }); E.poly([[-w2, y0, d2], [w2, y0, d2], [w2, y0 + h, d2], [-w2, y0 + h, d2]], Z3).poly([[w2, y0, -d2], [-w2, y0, -d2], [-w2, y0 + h, -d2], [w2, y0 + h, -d2]], mul(Z3, -1)).poly([[w2, y0, d2], [w2, y0, -d2], [w2, y0 + h, -d2], [w2, y0 + h, d2]], X3).poly([[-w2, y0, -d2], [-w2, y0, d2], [-w2, y0 + h, d2], [-w2, y0 + h, -d2]], mul(X3, -1)); return E; };
    const streak = (y, d2) => { const E = dec('#ffffff', { op: 0.5 }); [[-40, 8], [-24, 3], [26, 6]].forEach(([x, wd]) => E.poly([[x, y, d2], [x + wd, y, d2], [x + wd - 12, y, -d2], [x - 12, y, -d2]], Y3)); return E; };
    const TP = at(o, [0, H + 0.6, 0], GL), SH = at(o, [0, 13.2, 0], GL);
    if (TP) on(TP, [edge(H + 0.15, 0.9, W / 2 + 1, Dp / 2 + 1), streak(H + 1.2, Dp / 2 - 0.5)]);
    if (SH) on(SH, [edge(12.85, 0.7, W / 2 - 2, Dp / 2 - 2), streak(13.7, Dp / 2 - 3)]);
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => { const x = sx * (W / 2 - 1), z = sz * (Dp / 2 - 1), L = at(o, [x, 30, z], IR); if (!L) return;
      const HL = dec('#6a6d74', { op: 0.8 }); HL.line([[x - 0.45, 1.4, z + 0.9], [x - 0.45, H - 2.2, z + 0.9]], Z3, 0.25).line([[x + 0.9, 1.4, z - 0.45], [x + 0.9, H - 2.2, z - 0.45]], X3, 0.2);
      on(L, [cyl(x, 0, z, 1.35, 1, '#8a8f94', M_({ n: 10 })), HL]); });
    const BK = at(o, [-21.5, 18, 0], '#c9a06a');
    if (BK) { const r = y => 9 * (0.9 + 0.1 * (y - 13.7) / 9) + 0.04, P3 = (a, y) => [-30 + Math.cos(a) * r(y), y, Math.sin(a) * r(y)], A = dec('#7a5636', { op: 0.85 }), B2 = dec('#e6c48e', { op: 0.9 });
      rep(30, i => { const a = i / 30 * 2 * PI; [[14.1, 17.9], [19.5, 21.5]].forEach(([y0, y1]) => A.line([P3(a, y0), P3(a, y1)], cN(a), 0.3)); });
      [14.7, 15.9, 17.1, 20.0, 21.0].forEach((y, k) => rep(30, i => { const a0 = (i + (k % 2) * 0.5) / 30 * 2 * PI, a1 = a0 + 0.16; B2.line([P3(a0, y), P3((a0 + a1) / 2, y + 0.1), P3(a1, y)], [cN(a0), cN((a0 + a1) / 2), cN(a1)], 0.8); }));
      const TH = box(-30, 22.3, -0.5, 11, 2.4, 10, '#c96f5a', F_({ r: 3.4 })), KN = dec('#a8503e', { op: 0.75 });
      rep(5, i => KN.line(wv(8, t => [-35 + t * 10, 24.72, -4.5 + i * 2 + (Math.floor(t * 8) % 2 ? 0.5 : -0.5)]), Y3, 0.3));
      on(BK, [A, B2, TH]); on(TH, [KN]); }
    [['#2f5a8a', 0], ['#e0b04c', 1], ['#c4643a', 2]].forEach(([col, i]) => { const B = at(o, [26, 13.7 + i * 2.6 + 1.3, 0], col); if (!B) return; const yaw = [0, 0.1, -0.08][i], E = dec(shade(col, 0.6), { op: 0.9 }), G = dec('#e2b14a', { op: 0.95 });
      E.poly(rrect(26, 13.7 + (i + 1) * 2.6, 0, 22, 1.4, yaw, 0, -5.2), Y3); G.poly(rrect(26, 13.7 + (i + 1) * 2.6, 0, 8, 0.5, yaw, -5, 3), Y3); on(B, [E, G]); });
    const TR = at(o, [28, H + 1.6, 0], BR);
    if (TR) { const KY = dec('#c9ced3'), KB = dec('#b88a2a'); KY.poly(elP([24, H + 2.12, -2.6], X3, Z3, 1.3, 1.3, 10), Y3).poly(rrect(26.6, H + 2.12, -2.6, 3.8, 0.9, 0.15), Y3); KB.poly(elP([24, H + 2.16, -2.6], X3, Z3, 0.6, 0.6, 8), Y3).poly(rrect(32, H + 2.12, 2.2, 2.4, 2.4, 0.4), Y3);
      on(TR, [KY, KB, cyl(33.6, H + 2.1, -2.6, 1.3, 0.3, '#c99a3a', M_({ n: 12 }))]); }
    if (TP) { const EV = dec('#f6f0e2'), EF = dec('#c9bea6', { op: 0.9 }), STM = dec('#d9483b'); const Q = rrect(-8, H + 1.2, 5, 14, 9, -0.12);
      EV.poly(Q, Y3); EF.line([Q[3], add(mul(add(Q[2], Q[3]), 0.5), mul(sub(add(Q[0], Q[1]), add(Q[2], Q[3])), 0.22)), Q[2]], Y3, 0.3); STM.poly(rrect(-8, H + 1.22, 5, 2.4, 2.8, -0.12, 4.6, -2.4), Y3); on(TP, [EV, EF, STM]); }
    const FR = tilt(box(6, H + 1.2, -8, 11, 8.6, 1, '#2c2d31', W_({ r: 0.4 })), X3, -0.12, [6, H + 1.2, -8.5]); o.push(FR);
    const PH = dec('#9fd0ee'), PG = dec('#7fb25a'), PF = dec('#f2c94a'), MT = dec('#f6f0e2');
    MT.poly([[1.4, H + 2.1, -7.45], [10.6, H + 2.1, -7.45], [10.6, H + 9, -7.45], [1.4, H + 9, -7.45]], Z3); PH.poly([[2.4, H + 4.6, -7.4], [9.6, H + 4.6, -7.4], [9.6, H + 8.2, -7.4], [2.4, H + 8.2, -7.4]], Z3);
    PG.poly([[2.4, H + 2.9, -7.4], [9.6, H + 2.9, -7.4], [9.6, H + 4.8, -7.4], [6, H + 5.6, -7.4], [2.4, H + 4.4, -7.4]], Z3); PF.poly(elP([4.4, H + 4.6, -7.36], X3, Y3, 0.6, 1.4, 8), Z3).poly(elP([7.4, H + 4.4, -7.36], X3, Y3, 0.6, 1.2, 8), Z3);
    on(FR, [MT, PH, PG, PF].map(D => tilt(D, X3, -0.12, [6, H + 1.2, -8.5]))); });

  // LIV-063 burl console: swirling grain + burl eye clusters + lacquer glints on the top, fluted legs with highlights, stems + leaves on the fruit, veined stone orb, cover titles
  N.burl24 = ext('burl22', (o, on, R) => { const BU = '#a2653a', TY = 52, YT = TY + 4;
    const TP = at(o, [0, TY + 2, 0], BU);
    if (TP) { const G1 = dec('#5a2c12', { op: 0.42 }), G2 = dec('#d8a066', { op: 0.38 }), EY = dec('#3a1a08', { op: 0.85 }), RG2 = dec('#c88a52', { op: 0.55 }), RG3 = dec('#6e3a1c', { op: 0.5 });
      rep(16, k => { const z0 = -14.5 + k * 1.95, ph = R() * 6, a1 = 0.6 + R() * 0.9, f1 = 0.08 + R() * 0.05; (k % 3 ? G1 : G2).line(wv(44, t => { const x = -59 + 118 * t; return [x, YT, Math.max(-15.3, Math.min(15.3, z0 + a1 * Math.sin(x * f1 + ph) + 0.6 * Math.sin(x * 0.31 + ph * 2)))]; }), Y3, k % 3 ? 0.26 : 0.4); });
      rep(40, () => { const cx = (R() - 0.5) * 108, cz = (R() - 0.5) * 24, rx = 0.8 + R() * 0.4, rz = 0.55 + R() * 0.25; rep(2 + Math.floor(R() * 4), () => spot(EY, [cx + (R() - 0.5) * 1.4, YT, cz + (R() - 0.5) * 0.9], Y3, 0.12 + R() * 0.16, 0.1 + R() * 0.1, R() * 3, 6));
        RG2.line(wv(16, t => [cx + Math.cos(t * 2 * PI) * rx, YT, cz + Math.sin(t * 2 * PI) * rz]), Y3, 0.22); RG3.line(wv(18, t => [cx + Math.cos(t * 2 * PI) * rx * 1.7, YT, cz + Math.sin(t * 2 * PI) * rz * 1.6]), Y3, 0.18); });
      const GLs = dec('#fff4e0', { op: 0.24 }); GLs.poly([[-50, YT, 15], [-38, YT, 15], [-24, YT, -15], [-36, YT, -15]], Y3).poly([[10, YT, 15], [14, YT, 15], [28, YT, -15], [24, YT, -15]], Y3);
      on(TP, [G1, G2, RG3, RG2, EY, GLs]); }
    [-52, 52].forEach(x => [-1, 1].forEach(sz => { const z = sz * 13, L = at(o, [x, 20, z], BR); if (!L) return; const F = dec('#9a7428', { op: 0.65 }), Hh = dec('#fff0b8', { op: 0.75 }), y0 = 3.4, y1 = TY - 3.4;
      [-0.6, 0.6].forEach(d => { F.line([[x + d, y0, z + 1.3], [x + d, y1, z + 1.3]], Z3, 0.2).line([[x + d, y0, z - 1.3], [x + d, y1, z - 1.3]], mul(Z3, -1), 0.2).line([[x + 1.3, y0, z + d], [x + 1.3, y1, z + d]], X3, 0.2).line([[x - 1.3, y0, z + d], [x - 1.3, y1, z + d]], mul(X3, -1), 0.2); });
      Hh.line([[x - 1.0, y0, z + 1.3], [x - 1.0, y1, z + 1.3]], Z3, 0.25).line([[x - 1.3, y0, z + 1.0], [x - 1.3, y1, z + 1.0]], mul(X3, -1), 0.25); on(L, [F, Hh]); }));
    [['#e0b04c', -37, -0.6], ['#d9663a', -31, -0.6], ['#e86fa8', -37, 4.6], ['#4f9a4a', -31, 4.6]].forEach(([col, x, z], i) => { const F = at(o, [x, TY + 9.6, z], col); if (!F) return; const tp = TY + 12.2;
      on(F, [rod([x, tp - 0.3, z], [x + 0.3, tp + 1.3, z - 0.2], 0.22, '#5a3a1a', { n: 5, noOut: 1 })].concat(i % 2 ? [ball(x + 0.6, tp + 0.6, z - 0.6, 0.9, '#5f9a4a', { sx: 1.6, sy: 0.35, k: 3, n: 8, yaw: 0.6 })] : []));
      if (i === 1) { const DP = dec(shade(col, 0.78), { op: 0.6 }); rep(18, () => { const a = R() * 2 * PI, b = (R() - 0.3) * 1.2, n = [Math.cos(a) * Math.cos(b), Math.sin(b), Math.sin(a) * Math.cos(b)]; spot(DP, add([x, TY + 9.6, z], mul(n, 2.62)), n, 0.16, 0.16, 0, 5); }); on(F, [DP]); } });
    const OR = at(o, [36, TY + 14, -2], '#e9e3d8');
    if (OR) { const c = [36, TY + 14, -2], V = dec('#a39a88', { op: 0.65 }), V2 = dec('#c8bfae', { op: 0.6 });
      [[0.5, 0.3, V, 0.4], [1.6, -0.4, V2, 0.24], [2.6, 0.9, V, 0.22]].forEach(([yaw, tl, D, w]) => { const e1 = [Math.cos(yaw), Math.sin(tl) * 0.4, Math.sin(yaw)], e2 = nz(cr(e1, [0, 1, 0.2])), Q = wv(40, t => { const a = t * 2 * PI; return nz(add(mul(e1, Math.cos(a)), mul(e2, Math.sin(a) + 0.15 * Math.sin(a * 5)))); }); D.line(Q.map(n => add(c, mul(n, 7.04))), Q, w); });
      on(OR, [V, V2]); }
    [['#1f3a4a', 0], ['#e0d4b8', 1]].forEach(([col, i]) => { const B = at(o, [10, TY + 4 + i * 3.2 + 1.6, 4], col); if (!B) return; const yaw = [0, 0.08][i], E = dec(i ? '#b44a3a' : '#e2b14a', { op: 0.9 });
      E.poly(rrect(10, TY + 4 + (i + 1) * 3.2, 4, 14, 1.2, yaw, 0, 5), Y3).poly(rrect(10, TY + 4 + (i + 1) * 3.2, 4, 10, 5, yaw, 0, -1.5), Y3); on(B, [E]); }); });

  // LIV-083 liquid-metal console: environment reflections (dark horizon, sky blue, white streaks) down every leg segment and across the top, drips hanging under the front edge, dried branch in the black vase
  N.liquid24 = ext('liquid22', (o, on, R) => { const Dp = 32, TY = 46;
    const legR = sx => [[[0, sx * 36, 0, 15, 10], [2.4, sx * 36, 0, 14, 9.4], [5, sx * 35, 0, 9, 6.4]], [[5, sx * 35, 0, 8.4, 6], [16, sx * 31.6, 1, 4.4, 3.6], [28, sx * 30.6, 0, 3.8, 3.2]], [[28, sx * 30.6, 0, 3.8, 3.2], [37, sx * 33, -1, 7, 5], [43, sx * 36, 0, 13, 8.6], [46, sx * 37, 0, 16, 10.4]]];
    const ip = (Rg, y) => { for (let i = 0; i < Rg.length - 1; i++) if (y <= Rg[i + 1][0]) { const A = Rg[i], B = Rg[i + 1], t = (y - A[0]) / (B[0] - A[0]); return A.map((v, k) => v + (B[k] - v) * t); } return Rg[Rg.length - 1]; };
    [-1, 1].forEach(sx => legR(sx).forEach(Rg => { const y0 = Rg[0][0], y1 = Rg[Rg.length - 1][0], mid = ip(Rg, (y0 + y1) / 2), S = at(o, [mid[1], mid[0], mid[2]], CH); if (!S) return; const sc = Math.max(0.35, Math.min(1, mid[3] / 9));
      const Wt = dec('#ffffff', { op: 0.85 }), Dk = dec('#4d575e', { op: 0.55 }), Bl = dec('#9fb4c4', { op: 0.55 });
      [[2.35, Wt, 0.9], [2.05, Wt, 0.35], [1.15, Dk, 1.6], [0.5, Bl, 1.2], [-0.7, Dk, 1.2], [-2.4, Bl, 1]].forEach(([t, D, w]) => { const Y = wv(10, u => y0 + 0.2 + (y1 - y0 - 0.4) * u);
        D.line(Y.map(y => { const q = ip(Rg, y); return [q[1] + Math.cos(t) * q[3] * 1.01, y, q[2] + Math.sin(t) * q[4] * 1.01]; }), Y.map(y => { const q = ip(Rg, y); return nz([Math.cos(t) / q[3], 0, Math.sin(t) / q[4]]); }), w * sc); });
      on(S, [Bl, Dk, Wt]); }));
    const TP = at(o, [0, TY + 2.3, 0], CH);
    if (TP) { const yT = TY + 4.6, Dk = dec('#6c777f', { op: 0.42 }), Bl = dec('#a9c0d2', { op: 0.4 }), Wt = dec('#ffffff', { op: 0.75 }), FL = dec('#ffffff', { op: 0.8 }), FD = dec('#5d666d', { op: 0.5 });
      Dk.poly(wv(20, t => [-44 + 88 * t, yT, -1 + Math.sin(t * 7) * 1.2]).concat(wv(20, t => [44 - 88 * t, yT, -5.5 + Math.sin(t * 5 + 1)])), Y3);
      Bl.poly(wv(20, t => [-44 + 88 * t, yT, -6 + Math.sin(t * 5 + 1)]).concat(wv(20, t => [44 - 88 * t, yT, -12 + Math.sin(t * 4 + 2) * 0.6])), Y3);
      Wt.poly([[-38, yT, 12], [-30, yT, 12], [-18, yT, -12], [-26, yT, -12]], Y3).poly([[18, yT, 12], [21, yT, 12], [33, yT, -12], [30, yT, -12]], Y3);
      FL.line(wv(10, t => [-44 + 88 * t, TY + 1.5, Dp / 2]), Z3, 0.5); FD.line(wv(10, t => [-44 + 88 * t, TY + 0.6, Dp / 2]), Z3, 0.6);
      on(TP, [Bl, Dk, Wt, FD, FL].concat([-30, -6, 38].map((x, i) => ball(x, TY - 2 - i * 0.5, Dp / 2 - 2.2, 0.8, CH, { sy: 1.7, k: 4, n: 10, mat: 'metal', shine: 1 })))); }
    const VS = at(o, [-20, TY + 10, -4], '#2a2b30');
    if (VS) { const t0 = [-20, TY + 16.6, -4], BW = '#5a4030', b1 = pipe([t0, [-22, TY + 26, -4.6], [-25, TY + 34, -5], [-27, TY + 40, -3.6]], 0.32, BW, { n: 5 }), b2 = pipe([t0, [-17, TY + 25, -3.6], [-14.6, TY + 31, -4.4], [-12.6, TY + 35, -6]], 0.28, BW, { n: 5 });
      on(VS, b1.concat(b2, [[-25, TY + 34, -5], [-27, TY + 40, -3.6], [-22.6, TY + 28, -4.4], [-14.6, TY + 31, -4.4], [-12.6, TY + 35, -6], [-16.6, TY + 26.6, -3.8]].map((p, i) => ball(p[0] + 0.5, p[1], p[2], 0.75 + (i % 2) * 0.25, i % 3 ? '#f6efe2' : '#e8d4c0', { k: 3, n: 8, shine: 0 })))); } });

  // ======================= COFFEE TABLES =======================
  // LIV-056 live-edge walnut: flowing grain round two knots, resin-filled crack (bowties on top), sapwood rings, brushed steel, turned-bowl rings, mossy texture, latte heart + handle, spoon, book
  N.live24 = ext('live22', (o, on, R) => { const WAL = '#6e4226', SAP = '#d9b07c', ST = '#232428', TY = 26.4, YT = TY + 4;
    const outl = (a, b, g) => rep(32, i => { const t = i / 32 * 2 * PI, c = Math.cos(t), s = Math.sin(t), w = 1 + g * (0.05 * Math.sin(5 * t + 1) + 0.03 * Math.sin(9 * t + 2)) * Math.abs(s); return [a * Math.sign(c) * Math.pow(Math.abs(c), 0.32), b * w * Math.sign(s) * Math.pow(Math.abs(s), 0.8)]; });
    const pin = (P, x, z) => { let c = false; for (let i = 0, j = P.length - 1; i < P.length; j = i++) { const [xi, zi] = P[i], [xj, zj] = P[j]; if ((zi > z) !== (zj > z) && x < (xj - xi) * (z - zi) / (zj - zi) + xi) c = !c; } return c; };
    const SW = at(o, [40, TY + 1.5, 0], SAP), HW = SW && o.find(S => S.col === WAL && S.par === SW);
    if (HW) { const IN = outl(54, 23.4, 1.4), G1 = dec('#3a1f0e', { op: 0.5 }), G2 = dec('#a06a3c', { op: 0.45 }), KN = dec('#24120a', { op: 0.85 }), KR = dec('#4a2a14', { op: 0.6 }), CK = dec('#1c0f06', { op: 0.92 }), SH = dec('#ffffff', { op: 0.12 });
      const knots = [[18, 8, 1.6, 1], [-36, -9, 1.1, 0.7]];
      rep(14, k => { const z0 = -22 + k * 3.4 + (R() - 0.5), ph = R() * 6, D = k % 2 ? G2 : G1; let cur = []; const fl = () => { if (cur.length > 1) D.line(cur, Y3, k % 2 ? 0.3 : 0.4, 1); cur = []; };
        for (let i = 0; i <= 60; i++) { const x = -54 + i * 1.8; let z = z0 + 1.6 * Math.sin(x * 0.06 + ph) + 0.7 * Math.sin(x * 0.17 + 2 * ph); knots.forEach(([kx, kz, a]) => { const d = z - kz, f = Math.exp(-((x - kx) * (x - kx)) / (30 * a)); if (Math.abs(d) < 7) z += Math.sign(d || 1) * f * (7 - Math.abs(d)) * 0.6; });
          if (pin(IN, x, z)) cur.push([x, YT, z]); else fl(); } fl(); });
      knots.forEach(([x, z, a, b]) => { spot(KN, [x, YT, z], Y3, a, b, 0.1, 12); [1.7, 2.5, 3.4].forEach(k => KR.line(wv(22, t => [x + Math.cos(t * 2 * PI) * a * k, YT, z + Math.sin(t * 2 * PI) * b * k * 1.25]), Y3, 0.22)); });
      CK.line([[-12, YT, 23.6], [-12.6, YT, 20], [-11.4, YT, 14], [-12.2, YT, 9.6], [-11.6, YT, 6.6], [-12.6, YT, 3.4], [-13.6, YT, -1.6], [-14.2, YT, -5]], Y3, 0.6, 1);
      SH.poly([[-40, YT, 18], [-30, YT, 18], [-14, YT, -16], [-24, YT, -16]], Y3);
      const BT = o.filter(S => S.par === HW && S.col === '#2e1a0c'); BT.forEach(S => o.splice(o.indexOf(S), 1));
      on(HW, [G1, G2, KR, KN, SH, CK]); BT.forEach(S => o.push(S)); }
    if (SW) { const SR = dec('#b8844e', { op: 0.6 }), SL = dec('#f2d4a4', { op: 0.6 }), BKk = dec('#4a2e18', { op: 0.7 }), close = P => P.concat([P[0]]);
      SR.line(close(outl(56, 26.3, 1.2)).map(([x, z]) => [x, TY + 3, z]), Y3, 0.3); SL.line(close(outl(56.6, 27.3, 1.1)).map(([x, z]) => [x, TY + 3, z]), Y3, 0.22);
      outl(56.7, 27.4, 1.1).forEach(([x, z], i) => { if (i % 3 === 0) spot(BKk, [x, TY + 3, z], Y3, 0.6 + R() * 0.6, 0.3, Math.atan2(z, x) + PI / 2, 6); }); on(SW, [SR, SL, BKk]); }
    [-40, 40].forEach(x => [-1, 1].forEach(sz => { const L = at(o, [x, 12, sz * 20], ST); if (!L) return; const HL = dec('#5a5c62', { op: 0.85 }); HL.line([[x - 0.8, 3, sz * 20 + 1.5], [x - 0.8, TY - 3, sz * 20 + 1.5]], Z3, 0.3).line([[x + 1.5, 3, sz * 20 - 0.8], [x + 1.5, TY - 3, sz * 20 - 0.8]], X3, 0.25); on(L, [HL]); }));
    const BW = at(o, [33, TY + 6, -4], '#8a5a34');
    if (BW) { const L1 = dec('#a87448', { op: 0.7 }), L2 = dec('#5e3a1e', { op: 0.6 }); ringC(L1, 26, -4, 8.5, TY + 6.2, 0.35, 36); ringC(L2, 26, -4, 8.95, TY + 7.6, 0.3, 36); ringC(L1, 26, -4, 7.4, TY + 5, 0.25, 36); on(BW, [L2, L1]); }
    [['#5f9a4a', 23, -5], ['#7fb25a', 26, -2.4], ['#4f8a3e', 29, -5]].forEach(([col, x, z]) => { const M = at(o, [x, TY + 10.4, z], col); if (!M) return; const c = [x, TY + 10.4, z], D1 = dec(shade(col, 0.7), { op: 0.7 }), D2 = dec(shade(col, 1.3), { op: 0.7 });
      rep(22, j => { const a = R() * 2 * PI, b = (R() - 0.2) * 1.3, n = [Math.cos(a) * Math.cos(b), Math.sin(b), Math.sin(a) * Math.cos(b)]; spot(j % 2 ? D1 : D2, add(c, mul(n, 3.02)), n, 0.3, 0.3, 0, 5); }); on(M, [D1, D2]); });
    const CF = at(o, [-30, TY + 9.85, -6], '#5a3418'), CU = at(o, [-27.5, TY + 6, -6], '#f2efe8');
    if (CF) { const LA = dec('#e8d2b0'); LA.poly([[-30, TY + 10, -4.6], [-31.3, TY + 10, -6], [-31.2, TY + 10, -7], [-30.5, TY + 10, -7.4], [-30, TY + 10, -6.8], [-29.5, TY + 10, -7.4], [-28.8, TY + 10, -7], [-28.7, TY + 10, -6]], Y3); on(CF, [LA]); }
    if (CU) on(CU, pipe([[-27.1, TY + 8.4, -6], [-25.2, TY + 8, -6], [-25.2, TY + 5.8, -6], [-27.1, TY + 5.4, -6]], 0.5, '#f2efe8', { mat: 'cer', n: 5 }));
    if (HW) { on(HW, [rod([-24, YT + 0.3, -2.6], [-20, YT + 0.3, 1.8], 0.25, CH, M_({ n: 5 })), ball(-24.6, YT, -3.4, 1, CH, { sx: 0.7, sy: 0.3, k: 3, n: 8, mat: 'metal', yaw: 0.8 })]);
      const BKs = book(-4, YT, -12, 18, 2.4, 13, '#3f6a5a', 0.25); BKs[0].par = HW; o.push(BKs[0], BKs[1]); const T = dec('#e2b14a', { op: 0.9 }); T.poly(rrect(-4, YT + 2.4, -12, 10, 1, 0.25, 0, 2), Y3); glue(o)(BKs[0], [T]); } }, { fx: undefined });

  // LIV-076 travertine + bronze drums: broken strata bands + pores all round the stone, top veins + bevel, brushed + mottled bronze, river stones in the bowl, cover title
  N.drum24 = ext('drum22', (o, on, R) => { const TV = '#eadcc2', BZ = '#4e3e32';
    const T = at(o, [16, 15, -6], TV);
    if (T) { const cx = -12, cz = -6, r = 30.02, P = (a, y) => [cx + Math.cos(a) * r, y, cz + Math.sin(a) * r], S1 = dec('#c2aa80', { op: 0.6 }), S2 = dec('#fbf3e4', { op: 0.65 }), PO = dec('#a89070', { op: 0.75 });
      rep(13, k => { const y0 = 1.8 + k * 2.15 + (R() - 0.5) * 0.6, ph = R() * 6, D = k % 3 === 1 ? S2 : S1, w = k % 3 === 1 ? 0.32 : 0.2 + R() * 0.22; let a = R() * 2 * PI; const end = a + 2 * PI;
        while (a < end - 0.3) { const len = Math.min(end - a, 0.5 + R() * 1.6), A = wv(Math.max(3, Math.ceil(len * 10)), t => a + len * t); D.line(A.map(q => P(q, y0 + 0.35 * Math.sin(q * 3 + ph) + 0.2 * Math.sin(q * 11 + ph))), A.map(cN), w, 1); a += len + 0.15 + R() * 0.5; } });
      rep(80, () => { const a = R() * 2 * PI, y = 1 + R() * 28; spot(PO, P(a, y), cN(a), 0.25 + R() * 0.7, 0.12 + R() * 0.18, 0, 6); });
      const TVn = dec('#cdb894', { op: 0.55 }), BV = dec('#fff8ec', { op: 0.7 });
      rep(6, k => { const z0 = -26 + k * 9 + R() * 3, ph = R() * 6; const L = wv(30, t => [cx - 28 + 56 * t, 30, cz + z0 + 1.6 * Math.sin(t * 6 + ph)]).filter(p => Math.hypot(p[0] - cx, p[2] - cz) < 28.5); if (L.length > 1) TVn.line(L, Y3, 0.3, 1); });
      ringY(BV, cx, cz, 29.4, 30, 0.5, 56); on(T, [S1, S2, PO, TVn, BV]); }
    const B = at(o, [48, 10, 16], BZ);
    if (B) { const BL = dec('#6e5a48', { op: 0.5 }), BD = dec('#2e241e', { op: 0.35 }), TR = dec('#7a6654', { op: 0.45 });
      rep(80, i => { const a = i / 80 * 2 * PI + R() * 0.03, y0 = 0.4 + R() * 3, y1 = 19.8 - R() * 4; BL.line([[32 + Math.cos(a) * 17.02, y0, 16 + Math.sin(a) * 17.02], [32 + Math.cos(a) * 17.02, y1, 16 + Math.sin(a) * 17.02]], cN(a), 0.14 + R() * 0.12); });
      rep(14, () => { const a = R() * 2 * PI, y = 2 + R() * 16; spot(BD, [32 + Math.cos(a) * 17.03, y, 16 + Math.sin(a) * 17.03], cN(a), 1.2 + R() * 2.4, 0.8 + R() * 1.6, 0); });
      [8, 9.6, 11.2, 12.8, 14.4, 15.8].forEach(rr => ringY(TR, 32, 16, rr, 21, 0.18, 40)); on(B, [BL, BD, TR]); }
    const BW = at(o, [32 + 6, 23, 16], '#f2efe8');
    if (BW) on(BW, [ball(30.4, 25, 15.2, 2, '#6b6e70', { sy: 0.5, k: 4, n: 10 }), ball(33.6, 25, 17.4, 1.6, '#a29484', { sy: 0.5, k: 4, n: 10 }), ball(33.8, 25, 13.4, 1.3, '#3e4144', { sy: 0.55, k: 4, n: 10 })]);
    const BK = at(o, [-28, 31.3, 4], '#2f4f5a');
    if (BK) { const E = dec('#e2b14a', { op: 0.9 }); E.poly(rrect(-28, 32.6, 4, 12, 1, 0.2, 0, -3), Y3).poly(rrect(-28, 32.6, 4, 7, 0.6, 0.2, 0, -1.2), Y3); on(BK, [E]); } });

  // ======================= SIDE TABLES =======================
  // LIV-019 milk crate: lit ledges + shadows in every hole, corner ribs, rim + foot lines, scuffs, barcode sticker, noodle-cup print, glowing phone screen, charger plug
  N.crate24 = ext('crate22', (o, on, R) => { const RED = '#d9363b', W = 34, H = 30, Dp = 30, zf = Dp / 2, xf = W / 2, C = at(o, [0, 15, 0], RED);
    if (C) { const LT = dec('#f2777a', { op: 0.9 }), DK = dec('#6e1216', { op: 0.6 }), SC = dec('#f6e6e0', { op: 0.35 }), XZ = mul(X3, 1);
      rep(3, i => rep(2, j => { const x = -10 + i * 10, y = 6 + j * 10; LT.line([[x - 3, y + 0.25, zf + 0.25], [x + 3, y + 0.25, zf + 0.25]], Z3, 0.5); DK.line([[x - 3, y + 6.75, zf + 0.25], [x + 3, y + 6.75, zf + 0.25]], Z3, 0.5).line([[x - 3.25, y + 1, zf + 0.25], [x - 3.25, y + 6.5, zf + 0.25]], Z3, 0.4); }));
      rep(3, i => rep(2, j => { const z = -9 + i * 9, y = 6 + j * 10; LT.line([[xf + 0.25, y + 0.25, z - 2.7], [xf + 0.25, y + 0.25, z + 2.7]], XZ, 0.5); DK.line([[xf + 0.25, y + 6.75, z - 2.7], [xf + 0.25, y + 6.75, z + 2.7]], XZ, 0.5); }));
      [1, -1].forEach(s => { LT.line([[s * (xf - 2.2), 1.5, zf], [s * (xf - 2.2), H - 2, zf]], Z3, 0.5); DK.line([[s * (xf - 3.1), 1.5, zf], [s * (xf - 3.1), H - 2, zf]], Z3, 0.35); LT.line([[xf, 1.5, s * (zf - 2.2)], [xf, H - 2, s * (zf - 2.2)]], XZ, 0.5); DK.line([[xf, 1.5, s * (zf - 3.1)], [xf, H - 2, s * (zf - 3.1)]], XZ, 0.35); });
      LT.line([[-xf + 2.4, H - 1.1, zf], [xf - 2.4, H - 1.1, zf]], Z3, 0.5).line([[xf, H - 1.1, -zf + 2.4], [xf, H - 1.1, zf - 2.4]], XZ, 0.5); DK.line([[-xf + 2.4, H - 2.2, zf], [xf - 2.4, H - 2.2, zf]], Z3, 0.35).line([[-xf + 2.4, 1.3, zf], [xf - 2.4, 1.3, zf]], Z3, 0.5).line([[xf, 1.3, -zf + 2.4], [xf, 1.3, zf - 2.4]], XZ, 0.5);
      rep(10, () => { const x = (R() - 0.5) * 28, y = 2 + R() * 26, a = (R() - 0.5) * 0.8, L = 1 + R() * 3; SC.line([[x, y, zf + 0.1], [x + Math.cos(a) * L, y + Math.sin(a) * L, zf + 0.1]], Z3, 0.2); });
      rep(8, () => { const z = (R() - 0.5) * 26, y = 2 + R() * 26, a = (R() - 0.5) * 0.8, L = 1 + R() * 3; SC.line([[xf + 0.1, y, z], [xf + 0.1, y + Math.sin(a) * L, z + Math.cos(a) * L]], XZ, 0.2); });
      const LB = dec('#f4f0e6'), LC = dec('#2a2d34'); LB.poly([[xf + 0.3, 13.3, -5], [xf + 0.3, 13.3, 5], [xf + 0.3, 15.7, 5], [xf + 0.3, 15.7, -5]], XZ); rep(12, i => LC.line([[xf + 0.3, 13.7, -1 + i * 0.45], [xf + 0.3, 15.3, -1 + i * 0.45]], XZ, i % 3 ? 0.14 : 0.28)); LC.line([[xf + 0.3, 14.5, -4.4], [xf + 0.3, 14.5, -2]], XZ, 0.3);
      on(C, [LT, DK, SC, LB, LC]); }
    const CU = at(o, [9, H + 5.6, 4], '#fbf6ec');
    if (CU) { const YW = dec('#f2c230'), RD2 = dec('#e8402a'), TX = dec('#3a2a22', { op: 0.8 }), rr = y => 4.6 * (0.78 + 0.22 * (y - H) / 8.4) + 0.03;
      YW.line(wv(30, t => { const a = t * 2 * PI; return [5 + Math.cos(a) * rr(H + 6.4), H + 6.4 + Math.sin(a * 6) * 0.35, 4 + Math.sin(a) * rr(H + 6.4)]; }), wv(30, t => cN(t * 2 * PI)), 0.9);
      rep(6, i => { const a = 0.4 + i * 0.3; spot(RD2, [5 + Math.cos(a) * rr(H + 1.6), H + 1.6, 4 + Math.sin(a) * rr(H + 1.6)], cN(a), 0.35, 0.35, 0, 6); });
      [1.2, 1.7, 2.2].forEach((a, i) => TX.line([[5 + Math.cos(a) * rr(H + 7.4), H + 7.4 - i * 0.02, 4 + Math.sin(a) * rr(H + 7.4)], [5 + Math.cos(a + 0.3) * rr(H + 7.4), H + 7.4, 4 + Math.sin(a + 0.3) * rr(H + 7.4)]], cN(a + 0.15), 0.3));
      on(CU, [YW, RD2, TX]); }
    const PH = at(o, [-6, H + 0.35, -6], '#2a2d34');
    if (PH) { const SCR = dec('#5d8fd8', { emit: 1 }), BAR = dec('#ffffff', { emit: 1, op: 0.85 }), IC = dec('#9fe27a', { emit: 1 });
      SCR.poly(rrect(-6, H + 0.72, -6, 3.8, 8, 0.4), Y3); BAR.poly(rrect(-6, H + 0.74, -6, 3.2, 1.2, 0.4, 0, -2.6), Y3); IC.poly(rrect(-6, H + 0.74, -6, 0.9, 0.9, 0.4, -1, 0.6), Y3).poly(rrect(-6, H + 0.74, -6, 0.9, 0.9, 0.4, 0.4, 0.6), Y3);
      on(PH, [SCR, BAR, IC]); }
    const CB = at(o, [-W / 2 - 0.8, 15, 7], '#f4f4f4');
    if (CB) on(CB, [box(-W / 2 - 0.8, 1, 8.1, 1.6, 2.6, 1.4, '#f4f4f4', PL({ r: 0.4 })), rod([-W / 2 - 1.3, 0.2, 8.1], [-W / 2 - 1.3, 1.1, 8.1], 0.18, '#c9ced3', M_({ n: 4 })), rod([-W / 2 - 0.3, 0.2, 8.1], [-W / 2 - 0.3, 1.1, 8.1], 0.18, '#c9ced3', M_({ n: 4 }))]); });

  // LIV-039 white tulip table: chamfer + under-edge lines, soft reflections + gloss streak on the top, pedestal highlights, glide ring, tulip petals + 2nd leaf, water line, teacup on a saucer
  N.bistro24 = ext('bistro22', (o, on, R) => { const WH = '#f7f5f0', TP = at(o, [15, 37, 0], WH);
    if (TP) { const E = dec('#cfccc4', { op: 0.6 }), Gs = dec('#ffffff', { op: 0.95 }), Sd = dec('#dcd8cf', { op: 0.55 }), Rf = dec('#e3e0d8', { op: 0.6 });
      ringY(E, 0, 0, 18.3, 38.4, 0.35, 48); ringC(Sd, 0, 0, 19.02, 36.5, 0.6, 48);
      Rf.poly(wv(16, t => { const a = 3.6 + t * 1.6; return [Math.cos(a) * 16.5, 38.4, Math.sin(a) * 16.5]; }).concat(wv(16, t => { const a = 5.2 - t * 1.6; return [Math.cos(a) * 12.5, 38.4, Math.sin(a) * 12.5]; })), Y3);
      Gs.poly([[-14, 38.4, 8], [-10, 38.4, 10], [4, 38.4, -12], [0, 38.4, -14]], Y3); on(TP, [E, Rf, Gs, Sd]); }
    const SM = at(o, [2.8, 17, 0], WH);
    if (SM) { const HL = dec('#ffffff', { op: 0.95 }), SD = dec('#d6d2c9', { op: 0.6 }); [[2.5, HL, 0.6], [0.9, SD, 0.8], [-0.3, SD, 0.5]].forEach(([a, D, w]) => D.line([[Math.cos(a) * 3.02, 7, Math.sin(a) * 3.02], [Math.cos(a) * 3.02, 28, Math.sin(a) * 3.02]], cN(a), w)); on(SM, [SD, HL]); }
    const BS = at(o, [12.4, 1, 0], WH);
    if (BS) { const GR = dec('#cfccc4', { op: 0.6 }); ringY(GR, 0, 0, 11.4, 2.4, 0.3, 48); on(BS, [band(0, 0, 0, 13.04, 0.5, '#8a8780', { n: 30, noOut: 1 }), GR]); }
    const TU = at(o, [-4.2, 55, -2.4], '#ff6f8a');
    if (TU) { [0, 2.1, 4.2].forEach((a, i) => on(TU, [ball(-4.2 + Math.cos(a) * 1.1, 53.6, -2.4 + Math.sin(a) * 1.1, 1.45, i % 2 ? '#f2557a' : '#ff8fa6', { sy: 1.75, k: 4, n: 10 })], cN(a)));
      const STM = at(o, [-4.6, 49, -2.2], '#5f9a4a'); if (STM) on(STM, [ball(-3, 47.2, -2.8, 1.3, '#5f9a4a', { sx: 0.6, sy: 1.9, k: 3, n: 8 })]); }
    const VS = at(o, [-3, 42, -2], '#bfe2ee');
    if (VS) { const WL = dec('#8fc4dc', { op: 0.8 }); ringC(WL, -5, -2, 2.45, 43.5, 0.3, 20); on(VS, [WL]); }
    const SAU = cyl(8, 38.4, -7.5, 4.4, 0.6, '#f2ede4', { n: 18, mat: 'cer', rg: [[0, 0, 0.82], [0.6, 0, 1]] }), CUP = cyl(8, 39, -7.5, 2.7, 3.4, '#eef3f6', { n: 16, mat: 'cer', rg: [[0, 0, 0.7], [3.4, 0, 1]] }); o.push(SAU, CUP);
    const RIM = dec('#e2b14a', { op: 0.9 }); ringC(RIM, 8, -7.5, 2.72, 42.1, 0.25, 20); const SR = dec('#e2b14a', { op: 0.9 }); ringY(SR, 8, -7.5, 3.9, 39, 0.2, 24); glue(o)(SAU, [SR]);
    glue(o)(CUP, [cyl(8, 42.2, -7.5, 2.45, 0.2, '#b8743a', { n: 14, noOut: 1 }), RIM].concat(pipe([[10.6, 41.6, -7.5], [12.2, 41.2, -7.5], [12.2, 39.8, -7.5], [10.4, 39.5, -7.5]], 0.32, '#eef3f6', { mat: 'cer', n: 5 }))); });

  // LIV-059 fluted oak tambour: grain + knot + water ring on the top, grain on the sides, back and frame rails, slat highlights, brass leg ferrules, a novel with a ribbon bookmark
  N.tambour24 = ext('tambour22', (o, on, R) => { const OK = '#cd9a60', OL = shade(OK, 1.12), OD = shade(OK, 0.7), W = 40, Dp = 36, BY = 6, BH = 36, TY = BY + BH + 2.4;
    const TP = at(o, [0, TY - 1.2, 0], OL), BD = at(o, [0, BY + BH / 2, 0], OK);
    if (TP) { const G1 = dec('#a0703c', { op: 0.5 }), G2 = dec('#f2cc94', { op: 0.45 }), KN = dec('#6a4220', { op: 0.75 }), WR = dec('#9a7044', { op: 0.3 });
      rep(12, k => { const z0 = -17.5 + k * 3.1, ph = R() * 6; (k % 2 ? G2 : G1).line(wv(26, t => { const x = -20 + 40 * t; let z = z0 + 0.9 * Math.sin(x * 0.12 + ph) + 0.4 * Math.sin(x * 0.4 + ph); const d = z - (-9), f = Math.exp(-((x - 10) * (x - 10)) / 18); if (Math.abs(d) < 5) z += Math.sign(d || 1) * f * (5 - Math.abs(d)) * 0.6; return [x, TY, Math.max(-18.6, Math.min(18.6, z))]; }), Y3, k % 2 ? 0.28 : 0.36, 1); });
      spot(KN, [10, TY, -9], Y3, 0.9, 0.55, 0, 10); KN.line(wv(16, t => [10 + Math.cos(t * 2 * PI) * 1.6, TY, -9 + Math.sin(t * 2 * PI) * 1.1]), Y3, 0.2);
      ringY(WR, -9, 7, 3, TY, 0.35, 24); on(TP, [G1, G2, WR, KN]); }
    if (BD) { const G1 = dec('#9a6a38', { op: 0.45 }), G2 = dec('#ecc28a', { op: 0.4 });
      [1, -1].forEach(s => rep(6, k => { const z0 = -14 + k * 5.6, ph = R() * 6; (k % 2 ? G2 : G1).line(wv(14, t => { const y = BY + 1 + (BH - 2) * t; return [s * W / 2, y, z0 + 0.8 * Math.sin(y * 0.2 + ph)]; }), mul(X3, s), 0.3, 1); }));
      rep(6, k => { const x0 = -16 + k * 6.4, ph = R() * 6; G1.line(wv(14, t => { const y = BY + 1 + (BH - 2) * t; return [x0 + 0.8 * Math.sin(y * 0.2 + ph), y, -Dp / 2]; }), mul(Z3, -1), 0.3, 1); });
      [BY + 1.2, BY + BH - 1.4].forEach((y, k) => { G1.line(wv(16, t => [-18.4 + 36.8 * t, y + 0.3 * Math.sin(t * 9 + k), Dp / 2]), Z3, 0.25, 1); G2.line(wv(16, t => [-18.4 + 36.8 * t, y + 0.8 + 0.25 * Math.sin(t * 7 + k), Dp / 2]), Z3, 0.2, 1); });
      const SL = dec('#f6d6a4', { op: 0.75 }); rep(10, i => { const x = -0.6 + i * 2.3, a = 2.0; SL.line([[x + Math.cos(a) * 1.16, BY + 3.4, Dp / 2 + 0.05 + Math.sin(a) * 1.16], [x + Math.cos(a) * 1.16, BY + BH - 3.4, Dp / 2 + 0.05 + Math.sin(a) * 1.16]], cN(a), 0.3); });
      on(BD, [G1, G2, SL]); }
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => { const x = sx * (W / 2 - 4), z = sz * (Dp / 2 - 4), L = at(o, [x, BY / 2, z], OD); if (L) on(L, [cyl(x, 0, z, 2.15, 1.4, BR, M_({ n: 10 }))]); });
    const yaw = -0.2, c = Math.cos(yaw), s = Math.sin(yaw), BKs = book(-9, TY, -5, 14, 2, 10, '#7f2030', yaw); o.push(BKs[0], BKs[1]);
    const RB = dec('#e2b14a'), fz = (u, y) => [-9 + u * c - 5 * s, y, -5 + u * s + 5 * c], fn = [-s, 0, c]; RB.line([[-9 + 2 * c - 1 * s, TY + 2, -5 + 2 * s + 1 * c], fz(2.4, TY + 2)], Y3, 0.5).line([fz(2.4, TY + 2), fz(2.5, TY + 0.4)], fn, 0.5);
    const TT = dec('#e2b14a', { op: 0.9 }); TT.poly(rrect(-9, TY + 2, -5, 8, 0.8, yaw, 0, -2), Y3); glue(o)(BKs[0], [TT, RB]); });

  // LIV-099 levitating side pedestal: fine rings + LED dots round the floating top, app icons + charging bolt on the phone, vents + status LEDs + rubber foot on the base
  N.lev24 = S => { const B = N.lev22(S), CY = '#7fe8ff', WH = '#f2f4f8', TY = 26, D = Object.assign({}, B);
    D.layers = B.layers.map(L => Object.assign({}, L, { build: () => { const o = L.build(), on = glue(o), T = at(o, [14, TY + 1.5, 0], WH);
      if (T) { const RG2 = dec('#cdd4de', { op: 0.5 }), LD = dec(CY, { emit: 1 }); [13, 14.4, 15.8].forEach(r => ringY(RG2, 0, 0, r, TY + 3, 0.18, 48)); rep(28, i => { const a = i / 28 * 2 * PI; spot(LD, [Math.cos(a) * 17.02, TY + 1.6, Math.sin(a) * 17.02], cN(a), 0.28, 0.28, 0, 6); }); on(T, [RG2, LD]); }
      const PH = at(o, [4, TY + 4.1, 2], '#2a2d34');
      if (PH) { const cols = ['#ff7a5a', '#ffd24a', '#7fe27a', '#7fc8ff', '#c48cff', '#ffffff'], IC = cols.map(col => dec(col, { emit: 1 })); rep(6, i => IC[i].poly(rrect(4, TY + 4.6, 2, 1, 1, 0.3, -1.3 + (i % 3) * 1.3, -3 + Math.floor(i / 3) * 1.5), Y3));
        const BOLT = dec('#9affb0', { emit: 1 }), q = (u, v) => { const c = Math.cos(0.3), s = Math.sin(0.3); return [4 + u * c - v * s, TY + 4.62, 2 + u * s + v * c]; }; BOLT.poly([q(0.3, 0.6), q(-0.6, 2.2), q(0, 2.2), q(-0.4, 3.6), q(0.7, 1.8), q(0.1, 1.8)], Y3);
        on(PH, IC.concat([BOLT])); }
      return o; } }));
    D.build = () => { const o = B.build(), on = glue(o), BS = at(o, [12, 1.7, 0], '#23262d');
      if (BS) { const VT = dec('#0e1013', { op: 0.9 }), LDs = ['#7fe27a', CY, '#ffb84a'].map(col => dec(col, { emit: 1 }));
        rep(24, i => { const a = i / 24 * 2 * PI; VT.line([[Math.cos(a) * 9.6, 3.4, Math.sin(a) * 9.6], [Math.cos(a) * 11, 3.4, Math.sin(a) * 11]], Y3, 0.35); });
        [-0.25, 0, 0.25].forEach((d, i) => { const a = PI / 2 + d; spot(LDs[i], [Math.cos(a) * 12.25, 1.7, Math.sin(a) * 12.25], nz([Math.cos(a), 0.45, Math.sin(a)]), 0.3, 0.3, 0, 6); });
        on(BS, [band(0, 0, 0, 13.03, 0.6, '#0e1013', { n: 28, noOut: 1 }), VT].concat(LDs)); }
      return o; };
    return D; };

  // ======================= FIREPLACES (pass 2) =======================
  const grainX = (D1, D2, x0, x1, y, z0, z1, n, R, w) => rep(n, k => { const zc = z0 + (z1 - z0) * (k + 0.5) / n, ph = R() * 6, a = 0.3 + R() * 0.6;
    (k % 2 ? D2 : D1).line(wv(30, t => { const x = x0 + (x1 - x0) * t; return [x, y, Math.max(z0 + 0.2, Math.min(z1 - 0.2, zc + a * Math.sin(x * 0.09 + ph) + 0.3 * Math.sin(x * 0.27 + ph * 2)))]; }), Y3, (w || 0.3) * (0.7 + R() * 0.6), 1); });
  // speck: cnt small spots at f(u, v) on a flat face (f may return null to skip a spot)
  const speck = (D, cnt, f, nrm, r0, r1, R, m) => rep(cnt, () => { const p = f(R(), R()), r = r0 + R() * (r1 - r0); if (p) spot(D, p, nrm, r, r * (0.6 + R() * 0.4), R() * 3, m || 6); });
  const seg = (D, A, B, n, w) => D.line([A, B], n, w);

  // LIV-015 faux brick: tile tones + speckle + crack + chip on the hearth, paper ball in the firebox, panel seam + nails + sun-faded print + scuffs + star sticker on the brick print,
  // particleboard flecks + print-sheet edge + screws on the sides, shipping label + 'this side up' arrows on the back, mantel grain/knots/water ring/scratches/burn/wax puddle, candle drips,
  // heater: top vents, thermostat ticks + pointer, badge, power LED, warm yellowing, warning sticker, guard wires over the coils
  N.faux24 = ext('faux23', (o, on, R) => { const MO = '#d8cbb6', OY = 45.4, HY = 4, MY = 74, ZF = 15, ZB = ZF + 0.7, mZ = mul(Z3, -1);
    const HE = at(o, [0, 2, 4], '#6f6a64');
    if (HE) { const TL = ['#7c766e', '#635d56', '#746d64', '#5c5751', '#6b655d'].map(c => dec(c, { op: 0.55 })), SP = dec('#8f8a82', { op: 0.6 }), SPd = dec('#45413c', { op: 0.6 }), CK = dec('#2e2b28', { op: 0.85 }), CP = dec('#a8a299', { op: 0.85 });
      const xs = [-64, -48, -32, -16, 0, 16, 32, 48, 64], zs = [-15, -5, 4, 13, 23];
      xs.slice(0, -1).forEach((x0, i) => zs.slice(0, -1).forEach((z0, j) => { const x1 = xs[i + 1], z1 = zs[j + 1]; TL[(i * 3 + j * 7) % 5].poly([[x0 + 0.3, HY, z0 + 0.3], [x1 - 0.3, HY, z0 + 0.3], [x1 - 0.3, HY, z1 - 0.3], [x0 + 0.3, HY, z1 - 0.3]], Y3); }));
      speck(SP, 70, (u, v) => [-63 + u * 126, HY, -14 + v * 36], Y3, 0.15, 0.4, R); speck(SPd, 50, (u, v) => [-63 + u * 126, HY, -14 + v * 36], Y3, 0.12, 0.35, R);
      speck(SPd, 24, (u, v) => [-63 + u * 126, 0.5 + v * 3, 23], Z3, 0.15, 0.4, R);
      CK.line([[6, HY, 22.6], [8.4, HY, 20], [7.6, HY, 17.6], [10.4, HY, 15.2], [11.2, HY, 13.4]], Y3, 0.24, 1);
      CP.poly([[47.7, HY, 22.7], [44.6, HY, 22.7], [45.6, HY, 21.4], [47.7, HY, 20.6]], Y3).poly([[47.7, 3.6, 23], [44.6, 3.6, 23], [45.6, 2.4, 23], [47.7, 2, 23]], Z3);
      on(HE, TL.concat([SP, SPd, CK, CP, ball(-18, HY + 1.35, 9, 1.5, '#f2efe6', F_({ k: 3, n: 8, sy: 0.85 }))])); }
    const PLf = at(o, [-43, 20, 1], MO), PRt = at(o, [43, 20, 1], MO), LT = at(o, [0, 60, 0], MO);
    if (LT) { const SM = dec('#4a3226', { op: 0.55 }), SL = dec('#f0dcc6', { op: 0.45 }), NL = dec('#8d8780'), FD = dec('#ffffff', { op: 0.1 });
      spot(FD, [-30, 62, ZB], Z3, 18, 8, 0.2, 14); spot(FD, [-22, 64, ZB], Z3, 9, 4, -0.1, 12);
      seg(SM, [8, OY + 0.4, ZB], [8, MY - 0.4, ZB], Z3, 0.25); seg(SL, [8.35, OY + 0.4, ZB], [8.35, MY - 0.4, ZB], Z3, 0.15);
      [OY + 2, OY + 9.5, OY + 17, OY + 24.5].forEach(y => { spot(NL, [8.9, y, ZB], Z3, 0.32, 0.32, 0, 6); spot(NL, [-58.6, y, ZB], Z3, 0.32, 0.32, 0, 6); });
      const LB = dec('#f4f0e6'), BC2 = dec('#2a2d34'), RDt = dec('#d9483b');
      LB.poly([[44, 57, -15], [30, 57, -15], [30, 66, -15], [44, 66, -15]], mZ); rep(14, i => seg(BC2, [42.8 - i * 0.5, 58, -15], [42.8 - i * 0.5, 61, -15], mZ, i % 3 ? 0.14 : 0.28));
      seg(RDt, [43, 64.6, -15], [35, 64.6, -15], mZ, 0.8); seg(BC2, [43, 62.7, -15], [33, 62.7, -15], mZ, 0.3);
      on(LT, [FD, SM, SL, NL, LB, BC2, RDt]); }
    const star = (D, c, r1, r2, rot) => D.poly(rep(10, i => { const a = rot + i * PI / 5, r = i % 2 ? r2 : r1; return [c[0] + Math.sin(a) * r, c[1] + Math.cos(a) * r, c[2]]; }), Z3);
    [[PLf, -1], [PRt, 1]].forEach(([P, s]) => { if (!P) return; const NL = dec('#8d8780'), SC = dec('#f2d8c4', { op: 0.38 });
      [8, 20, 32, 42].forEach(y => spot(NL, [s * 58.6, y, ZB], Z3, 0.32, 0.32, 0, 6));
      rep(7, () => { const x = s * (30 + R() * 28), y = 5 + R() * 9, a = (R() - 0.5) * 0.5, L = 1.5 + R() * 3; seg(SC, [x, y, ZB], [x + Math.cos(a) * L, y + Math.sin(a) * L, ZB], Z3, 0.25); });
      const L2 = [SC, NL]; if (s < 0) { const SH2 = dec('#c99a1a', { op: 0.7 }), ST2 = dec('#f2c230'); star(SH2, [-47.8, 27.8, ZB], 2.6, 1.15, 0.15); star(ST2, [-48, 28, ZB + 0.02], 2.3, 1.0, 0.15); L2.push(SH2, ST2); }
      on(P, L2); });
    const side = (P, sx, y0, y1, z0) => { if (!P) return; const n = mul(X3, sx), x = sx * 60, S1 = dec('#b6a68c', { op: 0.6 }), S2 = dec('#efe6d6', { op: 0.6 }), ED = dec('#f6f1e8'), SR = dec('#8d8780'), SS = dec('#4a4540');
      const f = (u, v) => [x, y0 + 0.5 + u * (y1 - y0 - 1), z0 + 0.5 + v * (ZF - z0 - 1)]; speck(S1, 30, f, n, 0.12, 0.35, R); speck(S2, 20, f, n, 0.12, 0.3, R);
      seg(ED, [x, y0 + 0.2, ZF - 0.25], [x, y1 - 0.2, ZF - 0.25], n, 0.4);
      [y0 + 4, y1 - 4].forEach(y => { spot(SR, [x, y, 0], n, 0.5, 0.5, 0, 8); seg(SS, [x, y - 0.4, 0.3], [x, y + 0.4, -0.3], n, 0.14); });
      on(P, [S1, S2, ED, SR, SS]); };
    side(PLf, -1, HY, OY, -13); side(LT, -1, OY, MY, -15); side(PRt, 1, HY, OY, -13); side(LT, 1, OY, MY, -15);
    const BK = at(o, [0, 20, -14], '#1e1c1b');
    if (BK) { const AR = dec('#cfc6b6', { op: 0.85 }), DU = dec('#5a5550', { op: 0.35 }), SC = dec('#77716a', { op: 0.4 });
      [-40, 40].forEach(x => { AR.poly([[x, 36, -15], [x - 3, 31, -15], [x - 1.2, 31, -15], [x - 1.2, 26, -15], [x + 1.2, 26, -15], [x + 1.2, 31, -15], [x + 3, 31, -15]], mZ); seg(AR, [x - 4.4, 23.4, -15], [x + 4.4, 23.4, -15], mZ, 0.6); seg(AR, [x - 3.4, 21.8, -15], [x + 3.4, 21.8, -15], mZ, 0.5); });
      speck(DU, 18, (u, v) => [-24 + u * 48, HY + 0.8 + v * 10, -13], Z3, 0.6, 1.6, R);
      rep(6, () => { const x = -22 + R() * 44, y = HY + 2 + R() * 30, a = (R() - 0.5) * 1.2, L = 1.5 + R() * 3; seg(SC, [x, y, -13], [x + Math.cos(a) * L, y + Math.sin(a) * L, -13], Z3, 0.2); });
      on(BK, [DU, SC, AR]); }
    const MT = at(o, [0, MY + 2, 2], '#a87a4e');
    if (MT) { const yT = MY + 4, G1 = dec('#7a5232', { op: 0.5 }), G2 = dec('#c99c66', { op: 0.45 }), KN = dec('#4a2e18', { op: 0.8 }), KR = dec('#7a5232', { op: 0.5 }), WR = dec('#6a4528', { op: 0.35 }), SC = dec('#e0bb88', { op: 0.5 }), WX = dec('#f4e9d0'), BN = dec('#2e1c10', { op: 0.55 });
      grainX(G1, G2, -64.6, 64.6, yT, -15.6, 19.6, 14, R, 0.32);
      [[-18, 10, 1.1], [44, -6, 0.8]].forEach(([x, z, a]) => { spot(KN, [x, yT, z], Y3, a, 0.6, 0.1, 10); [1.8, 2.8].forEach(k => KR.line(wv(18, t => [x + Math.cos(t * 2 * PI) * a * k, yT, z + Math.sin(t * 2 * PI) * 0.78 * k]), Y3, 0.2)); });
      ringY(WR, -6, -4, 3.4, yT, 0.45, 28); ringY(WR, -4.6, -3.2, 3.3, yT, 0.2, 28);
      rep(6, () => { const x = -60 + R() * 120, z = -12 + R() * 28, a = (R() - 0.5) * 0.6, L = 2 + R() * 4; seg(SC, [x, yT, z], [x + Math.cos(a) * L, yT, z + Math.sin(a) * L], Y3, 0.18); });
      WX.poly(rep(12, i => { const a = i / 12 * 2 * PI, r = 3.1 + (i % 3 ? 0.4 : -0.3) + (i === 4 ? 1.4 : 0); return [26 + Math.cos(a) * r, yT, 4 + Math.sin(a) * r]; }), Y3);
      spot(BN, [16, yT, 13], Y3, 0.7, 0.5, 0.4, 8);
      G1.line(wv(30, t => [-64.6 + 129.2 * t, MY + 0.6 + 0.2 * Math.sin(t * 17), 20]), Z3, 0.25, 1); G2.line(wv(30, t => [-64.6 + 129.2 * t, MY + 3.3 + 0.2 * Math.sin(t * 13 + 1), 20]), Z3, 0.22, 1);
      [-1, 1].forEach(s => rep(3, k => G1.line(wv(10, t => [s * 65, MY + 0.5 + t * 3, -14 + k * 11 + Math.sin(t * PI) * 2.4]), mul(X3, s), 0.22)));
      on(MT, [G1, G2, KR, KN, WR, SC, BN, WX]); }
    [[26, 4, 2.2, 5, '#f4e9d0', '#fffaf0'], [32, 7, 1.8, 3.2, '#e86f8a', '#f6a0b4']].forEach(([x, z, r, h, col, dc]) => { const C = at(o, [x, MY + 4 + h / 2, z], col); if (!C) return; const DR = dec(dc, { op: 0.95 });
      rep(5, i => { const a = 0.3 + i * 1.25 + R() * 0.4, L = 1 + R() * h * 0.55, e = [x + Math.cos(a) * r, MY + 4 + h - 0.1 - L, z + Math.sin(a) * r]; DR.line(wv(4, t => [x + Math.cos(a) * r, MY + 4 + h - 0.1 - t * L, z + Math.sin(a) * r]), cN(a), 0.5); spot(DR, e, cN(a), 0.32, 0.38, 0, 6); }); on(C, [DR]); });
    const HT = at(o, [0, HY + 10, -1], '#ece6da');
    if (HT) { const yT = HY + 20, YL = dec('#c9a868', { op: 0.25 }), VT = dec('#8a847a', { op: 0.85 }), TK = dec('#5a5650'), RDd = dec('#d9483b'), BD = dec('#b9bec4'), BT2 = dec('#3a3a3e', { op: 0.8 }), LD = dec('#ff3a2a', { emit: 1 }), WN = dec('#f2c230'), WT = dec('#2a2a2e');
      rep(5, i => seg(VT, [-12, yT, -6.4 + i * 0.8], [12, yT, -6.4 + i * 0.8], Y3, 0.4));
      rep(9, i => { const a = PI * 0.75 + i * PI * 1.5 / 8, c = Math.cos(a), s = Math.sin(a); seg(TK, [10 + c * 2.05, yT, 2 + s * 2.05], [10 + c * (i % 4 ? 2.5 : 2.8), yT, 2 + s * (i % 4 ? 2.5 : 2.8)], Y3, 0.16); });
      spot(RDd, [10, yT + 1.4, 0.9], Y3, 0.3, 0.3, 0, 6);
      spot(YL, [0, 21.8, 5], Z3, 12, 2, 0, 14); BD.poly([[-4, 21, 5], [4, 21, 5], [4, 22.8, 5], [-4, 22.8, 5]], Z3); seg(BT2, [-3.2, 21.9, 5], [1.4, 21.9, 5], Z3, 0.55); spot(BT2, [2.8, 21.9, 5], Z3, 0.4, 0.4, 0, 6);
      spot(LD, [10, 22, 5], Z3, 0.45, 0.45, 0, 8);
      WN.poly([[14, 10, -4.2], [14, 10, 1.8], [14, 15.4, -1.2]], X3); seg(WT, [14, 11.9, -1.2], [14, 13.9, -1.2], X3, 0.4); spot(WT, [14, 11, -1.2], X3, 0.24, 0.24, 0, 6);
      on(HT, [YL, VT, TK, RDd, BD, BT2, LD, WN, WT]); }
    const GR = at(o, [0, HY + 9, 5.3], '#2b2b2e', 0.6, 1);
    if (GR) { const GW = dec('#a9aeb4', { op: 0.9 }); rep(11, i => seg(GW, [-10 + i * 2, HY + 3.4, 5.66], [-10 + i * 2, HY + 15.6, 5.66], Z3, 0.22)); seg(GW, [-10.6, HY + 9.5, 5.66], [10.6, HY + 9.5, 5.66], Z3, 0.3); on(GR, [GW]); } });

  // LIV-055 white mantel: granite flecks + ash + reflections on the hearth, cleft layers + rust + mica on the slate, soot streaks on the firebox brick, bark grooves + white ash + ember cracks on the logs,
  // gilt beading + rosettes + foxing on the mirror, carved swags + bellflower drops on the frieze, panel mouldings on the sides, kick scuffs on the plinths, grain through the paint + wax drips on the shelf and candles
  N.mantel24 = ext('mantel23', (o, on, R) => { const PNT = '#f4f1ea', PL2 = mix(PNT, '#ffffff', 0.4), SL = '#2c2e33', ZF = 20;
    const HR = at(o, [0, 1.5, 6], '#18191c');
    if (HR) { const W1 = dec('#d8dce0', { op: 0.75 }), G1 = dec('#5a5e66', { op: 0.7 }), G2 = dec('#34373d', { op: 0.8 }), AS = dec('#8a8580', { op: 0.28 }), RF = dec('#ffffff', { op: 0.08 }), ft = (u, v) => [-69 + u * 138, 3, -19 + v * 50], ff = (u, v) => [-69 + u * 138, 0.3 + v * 2.4, 32];
      speck(G2, 60, ft, Y3, 0.5, 1.3, R); speck(G1, 80, ft, Y3, 0.15, 0.45, R); speck(W1, 50, ft, Y3, 0.08, 0.22, R); speck(G1, 30, ff, Z3, 0.12, 0.35, R); speck(W1, 16, ff, Z3, 0.08, 0.2, R);
      rep(7, () => spot(AS, [-24 + R() * 48, 3, 12 + R() * 12], Y3, 2 + R() * 3, 1 + R() * 1.4, (R() - 0.5) * 0.4, 10));
      RF.poly([[-60, 3, 32], [-48, 3, 32], [-38, 3, 22.4], [-50, 3, 22.4]], Y3).poly([[20, 3, 32], [24, 3, 32], [34, 3, 22.4], [30, 3, 22.4]], Y3);
      on(HR, [G2, G1, W1, AS, RF]); }
    const slate = (P, x0, x1, y0, y1) => { if (!P) return; const C1 = dec('#1c1e22', { op: 0.7 }), C2 = dec('#454951', { op: 0.6 }), RS = dec('#6e5038', { op: 0.35 }), MI = dec('#8a8f98', { op: 0.6 }), A = (x1 - x0) * (y1 - y0);
      const n = Math.max(3, Math.round((y1 - y0) / 2.4)); rep(n, k => { const y = y0 + (y1 - y0) * (k + 0.5) / n + (R() - 0.5) * 0.6, ph = R() * 6; let x = x0 + R() * 2; while (x < x1 - 1) { const L = Math.min(x1 - x, 2 + R() * 8), xa = x; (R() < 0.6 ? C1 : C2).line(wv(6, t => [xa + L * t, y + 0.35 * Math.sin((xa + L * t) * 0.5 + ph), ZF]), Z3, 0.2 + R() * 0.3, 1); x += L + 0.5 + R() * 3; } });
      rep(Math.round(A / 40), () => spot(RS, [x0 + 0.6 + R() * (x1 - x0 - 1.2), y0 + 0.6 + R() * (y1 - y0 - 1.2), ZF], Z3, 0.4 + R() * 0.9, 0.3 + R() * 0.5, R() * 3, 8));
      speck(MI, Math.round(A / 12), (u, v) => [x0 + u * (x1 - x0), y0 + v * (y1 - y0), ZF], Z3, 0.08, 0.2, R);
      on(P, [RS, C1, C2, MI]); };
    slate(at(o, [-34, 20, 0], SL), -37.6, -31.2, 3.6, 52.2); slate(at(o, [34, 20, 0], SL), 31.2, 37.6, 3.6, 52.2); slate(at(o, [0, 57, 0], SL), -37.6, 37.6, 53.9, 60.6);
    const FB = at(o, [0, 20, -18.5], '#5e3426');
    if (FB) { const SO = dec('#0a0605', { op: 0.3 }), SO2 = dec('#1a0e0a', { op: 0.45 });
      rep(9, i => { const x = -24 + i * 6 + (R() - 0.5) * 2, y0 = 16 + R() * 6, L = 18 + R() * 14, ph = R() * 6; SO.line(wv(10, t => [x + 1.4 * Math.sin(t * 4 + ph), Math.min(52.4, y0 + L * t), -16.9]), Z3, 2 + R() * 2.4, 1); });
      speck(SO2, 14, (u, v) => [-28 + u * 56, 6 + v * 12, -16.9], Z3, 0.6, 1.6, R); on(FB, [SO, SO2]); }
    [['#6a5442', [-20, 11, 6], [20, 11, 6], 2.6], ['#5e4a3a', [-18, 11.2, -6], [19, 11.6, -6], 2.8], ['#725a46', [-12, 16.6, -4], [14, 16, 3], 2.2]].forEach(([col, a, b, r]) => { const L = at(o, mul(add(a, b), 0.5), col); if (!L) return;
      const u = nz(sub(b, a)), e2 = nz(cr(u, Y3)), e1 = nz(cr(e2, u)), len = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]), P = (t, th) => { const n = add(mul(e1, Math.cos(th)), mul(e2, Math.sin(th))); return [add(add(a, mul(u, t * len)), mul(n, r)), n]; };
      const BK2 = dec(shade(col, 0.62), { op: 0.8 }), BH = dec(shade(col, 1.35), { op: 0.55 }), AS = dec('#e8e2d8', { op: 0.75 }), EM = dec('#ff7a2a', { emit: 1, op: 0.9 });
      rep(9, i => { const th = -PI * 0.7 + i * PI * 1.4 / 8 + (R() - 0.5) * 0.2, t0 = 0.04 + R() * 0.2, t1 = 0.75 + R() * 0.2, Q = wv(10, s => P(t0 + (t1 - t0) * s, th + 0.08 * Math.sin(s * 9 + i))); (i % 2 ? BH : BK2).line(Q.map(q => q[0]), Q.map(q => q[1]), 0.3 + R() * 0.25, 1); });
      rep(7, () => { const [p, n] = P(0.1 + R() * 0.8, (R() - 0.5) * 0.9); spot(AS, p, n, 0.8 + R() * 1.2, 0.4 + R() * 0.5, 0, 8); });
      rep(3, i => { const t = 0.2 + i * 0.26 + R() * 0.06, Q = wv(5, s => P(t + s * 0.08, PI * 0.58 + s * 0.3)); EM.line(Q.map(q => q[0]), Q.map(q => q[1]), 0.28, 1); });
      on(L, [BK2, BH, AS, EM]); });
    const MP = [0, 92, -16], RT = rotF(X3, -0.06), PM = v => rp(RT, MP, v), nF = RT(Z3), MF = at(o, PM([0, 112, -17]), '#c9a04a');
    if (MF) { const HL = dec('#f6dc8a', { op: 0.9 }), DK = dec('#7a5a22', { op: 0.75 }), FX2 = dec('#8a7a5a', { op: 0.3 }), z = -16;
      const rl = (D, x0, y0, x1, y1, w) => { [[x0, y0, x1, y0], [x1, y0, x1, y1], [x1, y1, x0, y1], [x0, y1, x0, y0]].forEach(([a, b, c, d]) => seg(D, PM([a, b, z]), PM([c, d, z]), nF, w)); };
      rl(DK, -20.4, 94.6, 20.4, 129.4, 0.4); rl(HL, -22.6, 92.4, 22.6, 131.6, 0.3); rl(DK, -22.1, 92.9, 22.1, 131.1, 0.16);
      const bead = (x, y) => { spot(DK, PM([x + 0.12, y - 0.12, z]), nF, 0.36, 0.36, 0, 6); spot(HL, PM([x, y, z]), nF, 0.3, 0.3, 0, 6); };
      rep(19, i => { const x = -18 + i * 2; bead(x, 93.5); bead(x, 130.5); }); rep(16, i => { const y = 97 + i * 2.05; bead(-21.5, y); bead(21.5, y); });
      [[-21.5, 93.5], [21.5, 93.5], [-21.5, 130.5], [21.5, 130.5]].forEach(([x, y]) => { spot(DK, PM([x + 0.2, y - 0.2, z]), nF, 1.3, 1.3, 0, 10); spot(HL, PM([x, y, z]), nF, 1.15, 1.15, 0, 10); spot(DK, PM([x, y, z]), nF, 0.45, 0.45, 0, 6); });
      [[-18, 97, 2.4], [17, 127, 2], [-16.6, 126.6, 1.2], [18, 98.6, 1.4]].forEach(([x, y, r2]) => rep(4, () => spot(FX2, PM([x + (R() - 0.5) * r2 * 2, y + (R() - 0.5) * r2 * 2, -15.9]), nF, 0.3 + R() * 0.6, 0.3 + R() * 0.5, R() * 3, 8)));
      on(MF, [FX2, DK, HL]); }
    [-1, 1].forEach(sg => { const P = at(o, [sg * 51.5, 30, 0], PNT); if (!P) return; const x = sg * 65, n = mul(X3, sg), SD = dec('#c9c4ba', { op: 0.75 }), HL = dec('#ffffff', { op: 0.9 }), SC = dec('#9a958c', { op: 0.35 }), CK = dec('#a8a398', { op: 0.5 });
      const pr = (D, z0, y0, z1, y1, w) => { seg(D, [x, y0, z0], [x, y0, z1], n, w); seg(D, [x, y1, z0], [x, y1, z1], n, w); seg(D, [x, y0, z0], [x, y1, z0], n, w); seg(D, [x, y0, z1], [x, y1, z1], n, w); };
      pr(SD, -15, 13, 15, 53, 0.5); pr(HL, -14.4, 13.6, 14.4, 52.4, 0.3); seg(SD, [x, 9, -19.6], [x, 9, 19.6], n, 0.4);
      rep(5, () => { const xx = sg * 51.5 + (R() - 0.5) * 18, y = 3.6 + R() * 4, a = (R() - 0.5) * 0.6, L = 1.4 + R() * 2.6; seg(SC, [xx, y, 22.2], [xx + Math.cos(a) * L, y + Math.sin(a) * L, 22.2], Z3, 0.3); });
      CK.line([[x, 40, -8], [x, 37.6, -6.4], [x, 36.2, -7.6], [x, 33, -5.8]], n, 0.14);
      on(P, [SD, HL, SC, CK]); });
    const FRb = at(o, [0, 70, 0], PNT);
    if (FRb) { const SW = dec(PL2), SS = dec('#bdb6a8', { op: 0.85 }), CR2 = dec('#b8b2a6', { op: 0.4 });
      [-1, 1].forEach(sg => { const A = wv(16, t => [sg * (22 + 16 * t), 82 - 6.5 * Math.sin(PI * t), ZF]);
        SS.line(A.map(p => [p[0], p[1] - 0.7, ZF]), Z3, 1.7, 1); SW.line(A, Z3, 1.8, 1);
        rep(6, k => { const p = A[1 + k * 2 + 1]; seg(SS, [p[0] - 0.6, p[1] + 0.7, ZF], [p[0] + 0.6, p[1] - 0.7, ZF], Z3, 0.25); });
        [22, 38].forEach(x0 => { rep(3, j => { const y = 80 - j * 2.2; spot(SS, [sg * x0 + 0.2, y - 0.3, ZF], Z3, 0.8 - j * 0.15, 0.95 - j * 0.15, 0, 8); spot(SW, [sg * x0, y, ZF], Z3, 0.72 - j * 0.15, 0.88 - j * 0.15, 0, 8); });
          spot(SS, [sg * x0 + 0.2, 82.3, ZF], Z3, 1.3, 0.9, 0, 10); spot(SW, [sg * x0, 82.6, ZF], Z3, 1.2, 0.8, 0, 10); }); });
      rep(4, () => { const x = -38 + R() * 76, y = 62 + R() * 3; CR2.line(wv(4, t => [x + t * 3, y + (t * 4 % 2 > 1 ? 0.4 : -0.4) * (R() + 0.3), ZF]), Z3, 0.12); });
      on(FRb, [SS, SW, CR2]); }
    const SH = at(o, [0, 90, 2], PL2);
    if (SH) { const G = dec('#d8d2c6', { op: 0.28 }), WX = dec('#fbf6ea'), WXs = dec('#d8d0c0', { op: 0.6 });
      grainX(G, G, -69, 69, 92, -20, 24, 10, R, 0.25);
      [-54, 54].forEach(x => rep(3, () => { const a = R() * 2 * PI, c = [x + Math.cos(a) * 4.4, 92, 6 + Math.sin(a) * 4.4]; spot(WXs, c, Y3, 0.9, 0.7, a, 8); spot(WX, c, Y3, 0.72, 0.55, a, 8); }));
      on(SH, [G, WXs, WX]); }
    [-54, 54].forEach(x => { const C = at(o, [x, 111, 6], '#f8f2e4'); if (!C) return; const DR = dec('#fffcf4'), DS = dec('#e0d6c4', { op: 0.75 });
      rep(4, i => { const a = 0.4 + i * 1.6 + R() * 0.5, L = 1.4 + R() * 4, pa = (aa, t) => [x + Math.cos(aa) * 1.4, 116.9 - t * L, 6 + Math.sin(aa) * 1.4];
        DS.line(wv(4, t => pa(a + 0.12, t)), cN(a + 0.12), 0.45); DR.line(wv(4, t => pa(a, t)), cN(a), 0.42); spot(DR, pa(a, 1), cN(a), 0.32, 0.4, 0, 6); });
      on(C, [DS, DR]); }); });

  // LIV-095 ethanol slab: honed basalt flecks + mica + edge highlights, glowing control panel (flame, level bars, power), brushed burner with screws + fuel cap,
  // smudges + fingerprint + green edges on the glass, warm flame reflections + dust on the dark back glass, glints + flecks on the river stones, rail highlight
  N.etha24 = ext('etha23', (o, on, R) => { const ST = '#1b1d22', GL = '#d6f0fa', ZF = 20;
    const SB = at(o, [0, 10, 0], ST), SC0 = ['#f4f1ea', '#dcd8cf', '#b9b4aa', '#e8e4dc'], stones = SB ? o.filter(S => S.par === SB && SC0.includes(S.col)) : [];
    const SL = stones.map(S => { const L = bb(S); return [(L[0] + L[1]) / 2, (L[2] + L[3]) / 2, (L[4] + L[5]) / 2, (L[1] - L[0]) / 2, (L[3] - L[2]) / 2]; });
    if (SB) { const MI = dec('#c8ccd4', { op: 0.55 }), GR = dec('#3a3e46', { op: 0.7 }), EH = dec('#555a64', { op: 0.9 });
      const ffr = (u, v) => { const x = -55 + u * 110, y = 7.2 + v * 5.8; return x > 38 && x < 50 && y > 8.4 && y < 12.6 ? null : [x, y, ZF]; };
      const ftp = (u, v) => { const x = -55 + u * 110, z = -19.5 + v * 39; return Math.abs(x) < 40.5 && Math.abs(z) < 5.5 || SL.some(s => Math.hypot(x - s[0], z - s[2]) < s[3] + 0.4) ? null : [x, 15, z]; };
      speck(GR, 50, ffr, Z3, 0.2, 0.6, R); speck(MI, 40, ffr, Z3, 0.06, 0.16, R); speck(GR, 70, ftp, Y3, 0.2, 0.55, R); speck(MI, 50, ftp, Y3, 0.06, 0.16, R);
      [-1, 1].forEach(s => { const f = (u, v) => [s * 56, 7.2 + v * 7.4, -19.4 + u * 38.8], n = mul(X3, s); speck(GR, 14, f, n, 0.2, 0.5, R); speck(MI, 10, f, n, 0.06, 0.16, R); seg(EH, [s * 56, 14.7, -19.4], [s * 56, 14.7, 19.4], n, 0.3); seg(EH, [s * 55.7, 15, -19.4], [s * 55.7, 15, 19.4], Y3, 0.3); });
      seg(EH, [-55.4, 15, 19.7], [55.4, 15, 19.7], Y3, 0.35); seg(EH, [-55.4, 14.6, ZF], [55.4, 14.6, ZF], Z3, 0.3);
      const zc = ZF + 0.15, FLm = dec('#ff9a3a', { emit: 1 }), FLi = dec('#ffe08a', { emit: 1 }), LV = ['#3ad6a0', '#3ad6a0', '#ffd24a', '#3a4450'].map((c, i) => dec(c, { emit: i < 3 ? 1 : 0 })), PW = dec('#7fe8ff', { emit: 1 });
      FLm.poly([[40.8, 9.5, zc], [41.9, 9.5, zc], [42.2, 10.5, zc], [41.5, 11.6, zc], [41.3, 10.8, zc], [40.9, 11.2, zc], [40.5, 10.4, zc]], Z3); FLi.poly(elP([41.4, 10, zc], X3, Y3, 0.3, 0.4, 6), Z3);
      LV.forEach((D, i) => D.poly([[43.4 + i * 1.1, 9.6, zc], [44.1 + i * 1.1, 9.6, zc], [44.1 + i * 1.1, 10 + i * 0.45, zc], [43.4 + i * 1.1, 10 + i * 0.45, zc]], Z3));
      PW.line(wv(14, t => { const a = 0.6 + t * (2 * PI - 1.2); return [47.9 + Math.sin(a) * 0.55, 10.4 + Math.cos(a) * 0.55, zc]; }), Z3, 0.18); seg(PW, [47.9, 10.4, zc], [47.9, 11.1, zc], Z3, 0.18);
      on(SB, [GR, MI, EH, FLm, FLi, PW].concat(LV));
      stones.forEach((S, i) => { const [cx, cy, cz, rx, ry] = SL[i], pt = d => { d = nz(d); return [[cx + d[0] * rx, cy + d[1] * ry, cz + d[2] * rx], nz([d[0] / rx, d[1] / ry, d[2] / rx])]; };
        const HLs = dec('#ffffff', { op: 0.6 }), FK = dec(shade(S.col, 0.7), { op: 0.8 }); let [p, n] = pt([-0.35, 1, -0.3]); spot(HLs, p, n, rx * 0.28, rx * 0.18, 0.5, 8);
        rep(3, () => { [p, n] = pt([(R() - 0.5) * 1.2, 1, (R() - 0.5) * 1.2]); spot(FK, p, n, 0.12 + R() * 0.12, 0.1 + R() * 0.08, 0, 5); }); on(S, [FK, HLs]); }); }
    const BT = at(o, [0, 16, 0], CH);
    if (BT) { const B1 = dec('#ffffff', { op: 0.55 }), B2 = dec('#8e989f', { op: 0.5 }), SC = dec('#3a3e44', { op: 0.85 });
      [-1, 1].forEach(s => rep(5, k => seg(k % 2 ? B2 : B1, [-39.4, 17, s * (2.1 + k * 0.6)], [39.4, 17, s * (2.1 + k * 0.6)], Y3, 0.14 + (k % 2) * 0.06)));
      seg(B1, [-39.4, 16.4, 5], [39.4, 16.4, 5], Z3, 0.25);
      [[38.6, 3.3], [38.6, -3.3], [-38.6, 3.3], [-38.6, -3.3]].forEach(([x, z]) => { spot(SC, [x, 17, z], Y3, 0.38, 0.38, 0, 8); seg(B1, [x - 0.3, 17, z], [x + 0.3, 17, z], Y3, 0.1); });
      on(BT, [B2, B1, SC, cyl(38.6, 17, 0, 0.9, 0.5, '#9aa3aa', M_({ n: 10 }))]); }
    const FP = at(o, [0, 30, 18.7], GL);
    if (FP) { const SM = dec('#ffffff', { op: 0.1 }), FPr = dec('#ffffff', { op: 0.18 }), ED = dec('#78c4a8', { op: 0.8 });
      [[-36, 24, 4, 2.6], [-31, 22, 2, 1.4], [22, 40, 3, 2], [44, 21, 2.2, 1.6]].forEach(([x, y, rx, ry]) => spot(SM, [x, y, 19], Z3, rx, ry, 0.3, 12));
      rep(3, i => [1.2, 0.85, 0.5].forEach(k => FPr.line(wv(14, t => [26 + i * 1.8 + Math.cos(t * 2 * PI) * k * 0.8, 22.5 - i * 0.5 + Math.sin(t * 2 * PI) * k, 19]), Z3, 0.1)));
      [-1, 1].forEach(s => seg(ED, [s * 54, 15.3, 18.7], [s * 54, 50.4, 18.7], mul(X3, s), 0.55));
      on(FP, [SM, FPr, ED]); }
    const BPn = at(o, [0, 30, -18.7], '#14161a');
    if (BPn) { const RF = dec('#ff9a4a', { op: 0.07 }), RF2 = dec('#ffd9a0', { op: 0.16 }), DS = dec('#8a8f98', { op: 0.25 }), zb = -18.4;
      spot(RF, [0, 24, zb], Z3, 40, 6, 0, 20); spot(RF, [0, 21, zb], Z3, 34, 3, 0, 18); RF2.poly([[-38, 17.4, zb], [38, 17.4, zb], [38, 18.4, zb], [-38, 18.4, zb]], Z3);
      speck(DS, 26, (u, v) => [-52 + u * 104, 16 + v * 34, zb], Z3, 0.1, 0.3, R); on(BPn, [RF, RF2, DS]); }
    const RL = at(o, [0, 51, 18.7], CH, 0.6, 1); if (RL) { const H = dec('#ffffff', { op: 0.75 }); seg(H, [-54, 51.1, 19.16], [54, 51.1, 19.16], Z3, 0.25); on(RL, [H]); } });

  // ======================= TABLETOP DECOR + PLANTS (pass 3) =======================
  { const { arcW } = K, f1 = K.f1, { face } = RD.H23, { frame, an, em, fxEll, FONT } = RD.H16, { RG, ell } = RD.H22, atS = RD.H3.atS, GOLD = '#e2b14a';
    const P2 = q => f1(q[0]) + ' ' + f1(q[1]);
    const L_ = (cx, cz, yw) => { const c = Math.cos(yw || 0), s = Math.sin(yw || 0); return (u, y, v) => [cx + u * c - v * s, y, cz + u * s + v * c]; };
    const NL = yw => { const c = Math.cos(yw || 0), s = Math.sin(yw || 0); return (u, v) => [u * c - v * s, 0, u * s + v * c]; };
    const rq = (L, u0, v0, u1, v1, y) => [L(u0, y, v0), L(u1, y, v0), L(u1, y, v1), L(u0, y, v1)];
    const cP = (cx, cz, r, a, y) => [cx + Math.cos(a) * r, y, cz + Math.sin(a) * r];
    const dash = (D, L, u0, v0, u1, v1, y, w, len) => [[u0, v0, u1, v0], [u1, v0, u1, v1], [u1, v1, u0, v1], [u0, v1, u0, v0]].forEach(([a, b, c, d]) => { const n = Math.max(2, Math.round(Math.hypot(c - a, d - b) / len)); for (let i = 0; i < n; i += 2) { const t0 = i / n, t1 = (i + 1) / n; D.line([L(a + (c - a) * t0, y, b + (d - b) * t0), L(a + (c - a) * t1, y, b + (d - b) * t1)], Y3, w); } });
    // decals on a round (y-axis) body: rf(y) = radius at height y
    const ringL = (D, cx, cz, rf, y, w, a0, a1, m, wob) => D.line(wv(m, t => { const a = a0 + (a1 - a0) * t; return cP(cx, cz, rf(y), a, y + (wob ? wob(a) : 0)); }), wv(m, t => cN(a0 + (a1 - a0) * t)), w);
    const vL = (D, cx, cz, rf, a, y0, y1, w) => D.line(wv(6, t => { const y = y0 + (y1 - y0) * t; return cP(cx, cz, rf(y), a, y); }), cN(a), w);
    const band3 = (D, cx, cz, rf, y0, y1, a0, a1, m) => rep(m, i => { const p = a0 + (a1 - a0) * i / m, q = a0 + (a1 - a0) * (i + 1) / m; D.poly([cP(cx, cz, rf(y0), p, y0), cP(cx, cz, rf(y0), q, y0), cP(cx, cz, rf(y1), q, y1), cP(cx, cz, rf(y1), p, y1)], cN((p + q) / 2)); });
    const spotC = (D, cx, cz, rf, a, y, rx, ry, rot) => spot(D, cP(cx, cz, rf(y), a, y), cN(a), rx, ry, rot || 0, 8);
    const heart = (D, cx, y, cz, s, a) => D.poly(rep(20, i => { const th = i / 20 * 2 * PI, hx = Math.pow(Math.sin(th), 3), hy = (13 * Math.cos(th) - 5 * Math.cos(2 * th) - 2 * Math.cos(3 * th) - Math.cos(4 * th)) / 16; return [cx + (hx * Math.cos(a) - hy * Math.sin(a)) * s, y, cz + (hx * Math.sin(a) + hy * Math.cos(a)) * s]; }), Y3);
    const elS = (c, rx, ry, rz, d) => { d = nz(d); return [[c[0] + d[0] * rx, c[1] + d[1] * ry, c[2] + d[2] * rz], nz([d[0] / rx, d[1] / ry, d[2] / rz])]; };
    const flameG = (c, P, id) => { const q = c.p(P[0], P[1], P[2]), k = c.k; return '<g transform="translate(' + P2(q) + ') scale(' + f1(k) + ')"><ellipse cy="-1.4" rx="4.4" ry="4.8" fill="url(#' + id + ')">' + an('opacity', '0.4;0.8;0.5;0.75;0.4', 1.6) + '</ellipse><g><animateTransform attributeName="transform" type="skewX" values="0;7;-5;4;0" dur="1.5s" repeatCount="indefinite"/><path d="M0 -3.8Q1.7 -1.3 0.5 0.4Q0 0.7 -0.5 0.4Q-1.6 -1 0 -3.8Z" fill="#ffd24a" stroke="#ff8a2a" stroke-width="0.22"/><path d="M0 -1.6Q0.6 -0.6 0.2 0.2Q-0.5 -0.4 0 -1.6Z" fill="#fff6d0"/></g><ellipse cy="0.45" rx="0.35" ry="0.5" fill="#5a8aff" opacity="0.7"/></g>'; };

    // LIV-008 stack of old coupons on a cork coaster: 6 clipped coupons (dashed cut lines, price blocks, print lines, paperclip, '50¢ OFF' + EXPIRED stamp on top),
    // cork coaster (grain, coffee ring, faded print ring), orange-handled scissors, a ballpoint pen
    N.coupons25 = S => { const R = R0('coupons25L'), CC = ['#efe6cf', '#f6e27a', '#f4b8c4', '#bfe0b0', '#f2ead8', '#cfe2f2'], PCs = ['#d9483b', '#2b6fb8', '#e07a1a', '#3a8a3a', '#7a3a9a', '#d9483b'], YW = [0.06, -0.14, 0.22, -0.05, 0.12, -0.18], TH = 0.42;
      const SH = CC.map((col, i) => ({ col, cx: 6 + (R() - 0.5) * 2.4, cz: -1 + (R() - 0.5) * 2, yaw: YW[i], y: i * TH, w: 18 - (i % 2) * 1.6, d: 9.6 + (i % 3) * 0.6 })), T = SH[SH.length - 1];
      return { w: 40, d: 32, small: 1, topH: 3, build: () => { const o = [], on = glue(o), Rr = R0('coupons25');
        const CO = cyl(-12.5, 0, 5, 6.5, 0.8, '#b98a56', { n: 26, mat: 'fab' }); o.push(CO);
        { const D1 = dec('#7a5232', { op: 0.75 }), D2 = dec('#dcb486', { op: 0.65 }), RA = dec('#5a3018', { op: 0.42 }), RB = dec('#6a3a1a', { op: 0.14 }), PR = dec('#7a2a2a', { op: 0.16 }), disk = (u, v) => { const a = u * 2 * PI, r = Math.sqrt(v) * 6.1; return [-12.5 + Math.cos(a) * r, 0.8, 5 + Math.sin(a) * r]; };
          speck(D1, 40, disk, Y3, 0.06, 0.16, Rr); speck(D2, 30, disk, Y3, 0.06, 0.14, Rr);
          rep(28, i => { const a = i / 28 * 2 * PI + Rr() * 0.2; spot(D1, [-12.5 + Math.cos(a) * 6.5, 0.2 + Rr() * 0.4, 5 + Math.sin(a) * 6.5], cN(a), 0.18, 0.12, 0, 5); });
          RB.poly(elP([-11.5, 0.8, 4], X3, Z3, 3.9, 3.9, 24), Y3); ringY(RA, -11.5, 4, 3.7, 0.8, 0.32, 36); ringY(RA, -11.1, 4.4, 3.4, 0.8, 0.12, 30);
          ringY(PR, -12.5, 5, 5.5, 0.8, 0.22, 40); ringY(PR, -12.5, 5, 4.9, 0.8, 0.1, 40); on(CO, [D1, D2, RB, RA, PR]); }
        let TOPC = null;
        SH.forEach((s, i) => { const L = L_(s.cx, s.cz, s.yaw), C = box(s.cx, s.y, s.cz, s.w, TH, s.d, s.col, { r: 0.15, yaw: s.yaw, mat: 'fab' }); o.push(C); TOPC = C;
          const yt = s.y + TH, hw = s.w / 2 - 0.8, hd = s.d / 2 - 0.8, DS = dec('#9a9080', { op: 0.55 }), PB = dec(PCs[i]), TX = dec('#aaa498', { op: 0.6 }), SG = dec(shade(s.col, 0.86));
          dash(DS, L, -hw, -hd, hw, hd, yt, 0.06, 0.8); PB.poly(rq(L, -hw + 0.5, -hd + 0.5, -hw + 6.2, hd - 0.5, yt), Y3);
          (i === SH.length - 1 ? [-0.3, 1.1] : [-2.6, -1, 0.6, 2.2]).forEach((v, k) => seg(TX, L(-hw + 7.2, yt, v), L(hw - 1 - (k % 2) * 3, yt, v), Y3, 0.16));
          [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([a, b]) => { const n = NL(s.yaw)(a, b), u = a * s.w / 2, v = b * s.d / 2, e = a ? [0, s.d / 2 - 0.3] : [s.w / 2 - 0.3, 0]; SG.line([L(u - e[0], s.y + TH * 0.5, v - e[1]), L(u + e[0], s.y + TH * 0.5, v + e[1])], n, 0.12); });
          on(C, [SG, DS, PB, TX]); });
        { const L = L_(T.cx, T.cz, T.yaw), yt = T.y + TH + 0.14, hd = T.d / 2, u = 2.4; on(TOPC, pipe([[u, hd - 3.4], [u, hd + 0.8], [u + 1.3, hd + 0.8], [u + 1.3, hd - 2.6], [u + 0.4, hd - 2.6], [u + 0.4, hd + 0.2]].map(([a, b]) => L(a, yt, b)), 0.13, '#c9ced3', M_({ n: 5 }))); }
        [-13.6, -10.6].forEach(z => o.push(arcW(-15, 0, z, 1.7, 1.15, 0.55, 0.6, 0, 2 * PI, '#e8742a', PL({ n: 18 }))));
        const B1 = box(-8.2, 0, -11.9, 10.4, 0.28, 1.1, '#c9ced3', M_({ r: 0.2, yaw: 0.08 })), B2 = box(-8.2, 0.28, -12.3, 10.4, 0.28, 1.1, '#d5dde2', M_({ r: 0.2, yaw: -0.08 })); o.push(B1, B2);
        { const H1 = dec('#ffffff', { op: 0.7 }); seg(H1, [-12.4, 0.57, -12.5], [-3.6, 0.57, -11.8], Y3, 0.14); on(B2, [H1, cyl(-12.3, 0.56, -12.1, 0.5, 0.14, '#8a9096', M_({ n: 10 }))]); }
        const PEN = rod([-3.5, 0.55, 11.6], [11.5, 0.55, 12.8], 0.55, '#2b5fb8', PL({ n: 10 })); o.push(PEN);
        { const H2 = dec('#ffffff', { op: 0.45 }); seg(H2, [-3.2, 1.05, 11.5], [11.2, 1.05, 12.7], Y3, 0.16); on(PEN, [H2, rod([11.5, 0.55, 12.8], [14.2, 0.55, 13], 0.62, '#1d2a44', PL({ n: 10 })), rod([-3.5, 0.55, 11.6], [-4.8, 0.55, 11.5], 0.3, '#c9ced3', M_({ n: 8 })), box(12.8, 1.15, 13.45, 2.6, 0.2, 0.32, '#c9ced3', M_({ r: 0.1, yaw: 0.07 }))]); }
        return o; },
      fx: c => { const M = frame(c.p, [T.cx, T.y + TH + 0.07, T.cz], [Math.cos(T.yaw), 0, Math.sin(T.yaw)], [-Math.sin(T.yaw), 0, Math.cos(T.yaw)]), hw = T.w / 2 - 0.8, px = -hw + 3.35;
        return { front: '<g transform="' + M + '"><text x="' + f1(px) + '" y="0.2" text-anchor="middle" ' + FONT + ' font-size="2.5" fill="#fff">50¢</text><text x="' + f1(px) + '" y="2.3" text-anchor="middle" ' + FONT + ' font-size="1.25" fill="#fff">OFF</text><text x="' + f1(-hw + 7.2) + '" y="-1.9" ' + FONT + ' font-size="1.25" fill="#3a352e">Squish Mart</text><text x="' + f1(-hw + 7.2) + '" y="3.3" font-family="monospace" font-size="0.85" fill="#b0302a">EXP 03/09/98</text><g transform="translate(' + f1(hw - 2.8) + ' 1.9) rotate(-16)" opacity="0.7"><rect x="-3" y="-0.95" width="6" height="1.9" rx="0.35" fill="none" stroke="#c8303a" stroke-width="0.22"/><text y="0.45" text-anchor="middle" ' + FONT + ' font-size="1.15" fill="#c8303a" letter-spacing="0.15">EXPIRED</text></g></g>' }; } }; };

    // LIV-028 soy candle in an amber glass jar (kraft label with lavender print, rim + glass glints, wax top with melt pool, wick + flame), wooden lid with grain + burned logo,
    // speckled ceramic trinket dish (gold rim, painted swirl) holding a ring, pearl studs and a hair tie, matchbox + burnt match
    N.candle25 = S => { const JX = -8, JR = 6.5, JH = 11, DX = 11, DZ = 0, rJ = y => JR * (y < 0.8 ? 0.95 + 0.05 * y / 0.8 : y > JH - 0.8 ? 1 - 0.07 * (y - JH + 0.8) / 0.8 : 1);
      return { w: 44, d: 40, small: 1, topH: 12, build: () => { const o = [], on = glue(o), R = R0('candle25'), fr = PI / 2;
        const J = cyl(JX, 0, 0, JR, JH, '#b8701f', { n: 26, shine: 1, rg: [[0, 0, 0.95], [0.8, 0, 1], [JH - 0.8, 0, 1], [JH, 0, 0.93]] }); o.push(J);
        { const LB = dec('#dcc092'), LK = dec('#7a6248', { op: 0.55 }), LV = dec('#8a6ab8'), LG = dec('#6a8a4a'), HL = dec('#ffffff', { op: 0.55 }), HL2 = dec('#ffe0a8', { op: 0.35 }), WX = dec('#f3e7cf'), WS = dec('#b89a6a', { op: 0.55 }), RM = dec('#e8b060', { op: 0.7 }), MP = dec('#e6d2aa', { op: 0.85 });
          band3(LB, JX, 0, rJ, 3, 8.4, fr - 2.1, fr + 2.1, 20); [3.4, 8].forEach(y => ringL(LK, JX, 0, rJ, y, 0.08, fr - 2.05, fr + 2.05, 20));
          [[6.8, 0.45, 0.22], [5.6, 0.3, 0.1]].forEach(([y, ha, w]) => ringL(LK, JX, 0, rJ, y, w, fr - ha, fr + ha, 6));
          rep(5, i => spotC(LV, JX, 0, rJ, fr + 0.95 + (i % 2) * 0.05, 4.4 + i * 0.6, 0.22, 0.3)); vL(LG, JX, 0, rJ, fr + 0.97, 3.8, 7.4, 0.12);
          vL(HL, JX, 0, rJ, fr + 0.75, 1.2, JH - 1.2, 0.5); vL(HL2, JX, 0, rJ, fr + 1.05, 1.5, JH - 1.5, 0.22); vL(HL, JX, 0, rJ, fr - 1.25, 2, JH - 2, 0.18);
          RM.line(wv(30, t => cP(JX, 0, JR * 0.93 - 0.3, t * 2 * PI, JH)), Y3, 0.5); WX.poly(elP([JX, JH, 0], X3, Z3, JR * 0.93 - 0.6, JR * 0.93 - 0.6, 26), Y3);
          WS.poly(wv(14, t => cP(JX, 0, JR * 0.93 - 0.6, PI + t * PI, JH)).concat(wv(14, t => { const a = 2 * PI - t * PI; return [JX + Math.cos(a) * (JR * 0.93 - 0.6), JH, Math.sin(a) * (JR * 0.93 - 0.6) * 0.55]; })), Y3);
          spot(MP, [JX, JH, 0.2], Y3, 3.1, 3.1, 0, 18);
          on(J, [LB, LK, LV, LG, HL, HL2, RM, WX, WS, MP, rod([JX, JH, 0], [JX + 0.15, JH + 1.5, 0], 0.18, '#2a2020', { n: 4 }), ball(JX + 0.25, JH + 1.6, 0, 0.28, '#1a1414', { k: 3, n: 6 })]); }
        const LD = cyl(JX - 2, 0, 13.5, 6.2, 1.3, '#c8925a', W_({ n: 26 })); o.push(LD);
        { const G1 = dec('#9a6a3a', { op: 0.5 }), G2 = dec('#e0b47e', { op: 0.5 }), BN = dec('#5a3418', { op: 0.6 }), SL = dec('#e8e2d6');
          [1.4, 2.6, 3.6, 4.6, 5.5].forEach((r, i) => (i % 2 ? G2 : G1).line(wv(30, t => { const a = t * 2 * PI; return [JX - 2 + Math.cos(a) * r * (1 + 0.06 * Math.sin(a * 3 + i)), 1.3, 13.5 + Math.sin(a) * r * 0.92]; }), Y3, 0.18));
          ringY(BN, JX - 2, 13.5, 2.2, 1.3, 0.14, 24); seg(BN, [JX - 3.2, 1.3, 13.5], [JX - 0.8, 1.3, 13.5], Y3, 0.25); ringC(SL, JX - 2, 13.5, 6.2, 0.25, 0.3, 40); on(LD, [G1, G2, BN, SL]); }
        const DI = cyl(DX, 0, DZ, 9, 2.4, '#e4dccd', { n: 30, mat: 'cer', rg: [[0, 0, 0.72], [0.5, 0, 0.84], [2.4, 0, 1]] }); o.push(DI);
        { const GZ = dec('#f2ece2'), SPk = dec('#8a6a4a', { op: 0.45 }), GD = dec(GOLD), BL = dec('#6a98c0', { op: 0.6 }), FT = dec('#b8ab98'), rD = y => 9 * (y < 0.5 ? 0.72 + 0.24 * y : 0.84 + 0.16 * (y - 0.5) / 1.9);
          GZ.poly(elP([DX, 2.4, DZ], X3, Z3, 7.8, 7.8, 28), Y3); speck(SPk, 22, (u, v) => { const a = u * 2 * PI, r = Math.sqrt(v) * 8.6; return [DX + Math.cos(a) * r, 2.4, DZ + Math.sin(a) * r]; }, Y3, 0.06, 0.16, R);
          BL.line(wv(24, t => { const a = t * 2 * PI; return [DX + Math.cos(a) * (5.6 + 0.5 * Math.sin(a * 5)), 2.4, DZ + Math.sin(a) * (5.6 + 0.5 * Math.sin(a * 5))]; }), Y3, 0.3);
          ringY(GD, DX, DZ, 8.85, 2.4, 0.4, 44); ringL(GD, DX, DZ, rD, 2.2, 0.2, 0, 2 * PI, 44); ringL(FT, DX, DZ, rD, 0.15, 0.3, 0, 2 * PI, 40);
          rep(18, () => spotC(SPk, DX, DZ, rD, R() * 2 * PI, 0.6 + R() * 1.4, 0.08, 0.08));
          on(DI, [GZ, BL, SPk, GD, FT, arcW(DX - 2.6, 2.4, DZ + 1.6, 1.5, 1.5, 0.4, 0.5, 0, 2 * PI, GOLD, M_({ n: 18, shine: 1 })), ball(DX - 2.6, 3.2, DZ + 3.2, 0.55, '#7fd0ff', { k: 3, n: 8, shine: 1 }),
            ball(DX + 2.6, 3.05, DZ - 2, 0.65, '#fbf6ee', { k: 3, n: 8, shine: 1 }), ball(DX + 3.8, 3.05, DZ - 0.8, 0.65, '#fbf6ee', { k: 3, n: 8, shine: 1 }), arcW(DX + 1.6, 2.4, DZ + 4.6, 1.9, 1.6, 0.7, 0.8, 0, 2 * PI, '#e86f8a', F_({ n: 16 }))]); }
        const MB = box(2, 0, 15, 7.4, 2, 4.6, '#f2ead8', { r: 0.2, yaw: 0.25 }); o.push(MB);
        { const L = L_(2, 15, 0.25), N2 = NL(0.25), RD2 = dec('#c8303a'), YL = dec('#f2c230'), BK = dec('#2a2420', { op: 0.9 }), ST = dec('#6a4a3a', { op: 0.85 });
          RD2.poly(rq(L, -3.2, -1.8, 3.2, 1.8, 2), Y3); YL.poly([L(-1.6, 2, -0.9), L(-0.6, 2, 0.2), L(-1.2, 2, 1.1), L(-2, 2, 0.2)], Y3); [-0.7, 0.4].forEach((v, k) => seg(BK, L(0.2, 2, v), L(2.6 - k, 2, v), Y3, 0.3));
          [1, -1].forEach(sg => ST.poly([L(-3.4, 0.35, sg * 2.3), L(3.4, 0.35, sg * 2.3), L(3.4, 1.65, sg * 2.3), L(-3.4, 1.65, sg * 2.3)], N2(0, sg))); on(MB, [RD2, YL, BK, ST]); }
        const MT = rod([7, 0.24, 17.8], [11.6, 0.24, 18.6], 0.22, '#e8d2a0', W_({ n: 5 })); o.push(MT); on(MT, [rod([7, 0.24, 17.8], [8.2, 0.24, 18.0], 0.24, '#2a1c14', { n: 5 }), ball(6.8, 0.3, 17.76, 0.42, '#1a1412', { k: 3, n: 6 })]);
        return o; },
      fx: c => ({ defs: RG('q25cf', '#fff3b0', '#ffb347', 0.8) + RG('q25cg', '#ffd9a0', '#ffb347', 0.35), back: fxEll(c, JX, 0.1, 0, 13, 'url(#q25cg)', an('opacity', '0.5;0.8;0.55;0.8;0.5', 1.6)), front: flameG(c, [JX + 0.25, JH + 1.85, 0], 'q25cf') }) }; };

    // LIV-048 three cloth-bound art books (page blocks with page lines, gilt spine bands + titles, cloth weave, debossed frames, worn corners), red ribbon bookmark,
    // a postcard sticking out, brass magnifying glass with a turned wood handle
    N.books25 = S => { const BK = [[0, 0, 0, 36, 5.2, 30, '#2f4870', 0, 'MODERN ART'], [-1.6, 5.2, 0.5, 31, 4.6, 26, '#7f2030', 0.09, 'BAUHAUS'], [1.2, 9.8, -0.6, 27, 4, 22, '#1f4f3e', -0.11, 'MATISSE']], TY = 13.8, mx = -2.5, mz = -3.2;
      return { w: 52, d: 40, small: 1, topH: 15, build: () => { const o = [], on = glue(o), B = [];
        BK.forEach(([x, y, z, w, t, d, col, yaw]) => { const S1 = box(x, y, z, w, t, d, col, { r: 0.5, yaw, mat: 'fab' }); o.push(S1); B.push(S1); const L = L_(x, z, yaw), Nn = NL(yaw), hw = w / 2, hd = d / 2, yb = y + 0.75, yt = y + t - 0.75;
          const PG = dec('#f4ecd8'), PLn = dec('#cfc2a4', { op: 0.85 }), GB = dec(GOLD), CW = dec(shade(col, 1.18), { op: 0.35 }), DB = dec(shade(col, 0.72), { op: 0.8 }), WR = dec(mix(col, '#ffffff', 0.45), { op: 0.5 });
          [[hw, -hd + 0.6, hw, hd - 1.4, 1, 0], [-hw, -hd + 0.6, -hw, hd - 1.4, -1, 0], [-hw + 0.6, -hd, hw - 0.6, -hd, 0, -1]].forEach(([u0, v0, u1, v1, nu, nv]) => { const n = Nn(nu, nv); PG.poly([L(u0, yb, v0), L(u1, yb, v1), L(u1, yt, v1), L(u0, yt, v0)], n); rep(4, k => { const yy = yb + (yt - yb) * (k + 0.5) / 4; PLn.line([L(u0, yy, v0), L(u1, yy, v1)], n, 0.09); }); });
          [[y + 0.55, 0.22], [y + 0.85, 0.1], [y + t - 0.55, 0.22], [y + t - 0.85, 0.1]].forEach(([yy, ww]) => GB.line([L(-hw + 0.8, yy, hd), L(hw - 0.8, yy, hd)], Nn(0, 1), ww));
          DB.line([L(-hw + 0.5, y + t, hd - 1.6), L(hw - 0.5, y + t, hd - 1.6)], Y3, 0.18);
          rep(7, k => CW.line([L(-hw + 0.6, y + t, -hd + 2 + k * (d - 4) / 6), L(hw - 0.6, y + t, -hd + 2 + k * (d - 4) / 6)], Y3, 0.08));
          const fu = hw - 2.2, fv0 = -hd + 2.2, fv1 = hd - 3.2; [[-fu, fv0, fu, fv0], [fu, fv0, fu, fv1], [fu, fv1, -fu, fv1], [-fu, fv1, -fu, fv0]].forEach(([a, b, c2, e]) => DB.line([L(a, y + t, b), L(c2, y + t, e)], Y3, 0.16));
          [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => spot(WR, L(a * (hw - 0.7), y + t, b * (hd - 0.7)), Y3, 0.9, 0.6, yaw + a * b * 0.8, 8));
          on(S1, [PG, PLn, CW, DB, WR, GB]); });
        { const [x, y, z, w, t, d, , yaw] = BK[1], L = L_(x, z, yaw), RB = dec('#c8303a'), RB2 = dec('#c8303a'), u = -6, hd = d / 2; RB.line([L(u, y + t - 0.4, -hd), L(u, y + 0.2, -hd)], NL(yaw)(0, -1), 0.9);
          RB2.line([L(u, 5.2, -hd), L(u - 0.4, 5.2, -hd - 1.4), L(u - 0.2, 5.2, -hd - 2.2)], Y3, 0.9); on(B[1], [RB]); on(B[0], [RB2]); }
        { const PC = on(B[0], [box(19.2, 2.0, 4, 3.4, 0.16, 8.6, '#f6efe0', { r: 0.1 })])[0], SP = dec('#c8303a'), LN = dec('#3a5a9a', { op: 0.7 }); SP.poly([[19.6, 2.16, 0.4], [20.6, 2.16, 0.4], [20.6, 2.16, 1.6], [19.6, 2.16, 1.6]], Y3); rep(3, k => seg(LN, [18.2, 2.16, 3 + k * 1.4], [20.6, 2.16, 3 + k * 1.4], Y3, 0.1)); on(PC, [SP, LN]); }
        const RNG = arcW(mx, TY, mz, 6.4, 6.4, 1.2, 1.3, 0, 2 * PI, BR, M_({ n: 30, shine: 1 })); o.push(RNG);
        { const HL = dec('#ffffff', { op: 0.7 }), ED = dec('#8a6a22', { op: 0.6 }); ringY(HL, mx, mz, 5.95, TY + 1.3, 0.16, 30); ringY(ED, mx, mz, 5.5, TY + 1.3, 0.12, 30); on(RNG, [HL, ED, cyl(mx, TY + 0.1, mz, 5.2, 0.6, '#e6f6fd', { n: 26, op: 0.35, shine: 1 })]); }
        const hd0 = [mx + 6.6, TY + 1.2, mz + 1.5], hd1 = [mx + 8.8, TY + 1.2, mz + 2], hd2 = [mx + 16, TY + 1.2, mz + 3.8], HW = rod(hd1, hd2, 1.15, '#3a2416', W_({ n: 12, shine: 1 })); o.push(rod(hd0, hd1, 0.85, BR, M_({ n: 10, shine: 1 })), HW);
        { const G = dec('#6a4428', { op: 0.6 }), d = nz(sub(hd2, hd1)); [-0.5, 0.5].forEach(s2 => G.line(wv(6, t => add(add(hd1, mul(d, 0.4 + t * 6.6)), [0, 1.16, s2 * 0.3])), Y3, 0.1)); on(HW, [G, ball(hd2[0] + 0.2, hd2[1], hd2[2] + 0.05, 1.15, BR, M_({ k: 3, n: 10 }))]); }
        return o; },
      fx: c => { let f = ''; BK.forEach(([x, y, z, w, t, d, col, yaw, title], bi) => { const cs = Math.cos(yaw), sn = Math.sin(yaw); if (face(c, -sn, cs) < 0.08) return; const L = L_(x, z, yaw), M = frame(c.p, L(-w / 2, y + t, d / 2 + 0.06), [cs, 0, sn], [0, -1, 0]);
          f += '<g transform="' + M + '"><text x="' + f1(w / 2) + '" y="' + f1(t / 2 + 0.95) + '" text-anchor="middle" font-family="Georgia, \'Times New Roman\', serif" font-weight="700" font-size="' + f1(Math.min(2.7, t * 0.58)) + '" letter-spacing="0.4" fill="#f2d27a">' + title + '</text><text x="' + f1(w - 2.4) + '" y="' + f1(t / 2 + 0.5) + '" text-anchor="middle" font-family="Georgia, serif" font-size="1.1" fill="#f2d27a">' + ['I', 'II', 'III'][bi] + '</text></g>'; });
        { const [x, , z, , , , , yaw] = BK[2], L = L_(x, z, yaw), cs = Math.cos(yaw), sn = Math.sin(yaw), M = frame(c.p, L(2, TY + 0.06, 5.6), [cs, 0, sn], [-sn, 0, cs]);
          f += '<g transform="' + M + '"><text text-anchor="middle" font-family="Georgia, serif" font-weight="700" font-size="2.2" letter-spacing="0.6" fill="#e2c26a">MATISSE</text><text y="2.1" text-anchor="middle" font-family="Georgia, serif" font-style="italic" font-size="1.2" fill="#d8b85a">the cut-outs</text></g>'; }
        const q = c.p(mx - 1.5, TY + 0.8, mz - 1.5), k = c.k; f += '<path d="M' + f1(q[0] - 2.6 * k) + ' ' + f1(q[1]) + 'Q' + f1(q[0] - 0.6 * k) + ' ' + f1(q[1] - 1.8 * k) + ' ' + f1(q[0] + 2.6 * k) + ' ' + f1(q[1] - 1.2 * k) + '" fill="none" stroke="#fff" stroke-width="' + f1(0.5 * k) + '" opacity="0.75">' + an('opacity', '0.35;0.85;0.35', 4.5) + '</path>';
        return { front: f }; } }; };

    // LIV-068 cut-crystal ikebana vase (facet edges, diamond cuts, water + stems inside) with a plum branch in bloom, a leafy branch and a red camellia,
    // black incense dish with raked sand, a burning stick (ember, ash curl, rising smoke), paulownia incense box, stone cairn, kokedama moss ball, all on a cleft slate tray
    N.ikebana25 = S => { const TY = 1.4, VX = -11, VZ = -3, VH = 20, IX = 11, IZ = 3, rV = y => 6 * (y < 7 ? 0.86 + 0.14 * y / 7 : 1 - 0.34 * (y - 7) / 13), sb = [IX + 1, TY + 2.6, IZ - 0.5], sd = [3.8, 11.4, -1.2], sp = t => add(sb, mul(sd, t)), TIP = add(sp(1), [0.9, 0.7, 0]);
      return { w: 56, d: 36, small: 1, topH: 22, build: () => { const o = [], on = glue(o), R = R0('ikebana25');
        const TR = box(0, 0, 0, 52, TY, 28, '#2c2f35', { r: 0.8, mat: 'cer' }); o.push(TR);
        { const C1 = dec('#1c1e22', { op: 0.7 }), C2 = dec('#4a4e56', { op: 0.6 }), EH = dec('#5a5f68', { op: 0.9 }), CA2 = dec('#bfefff', { op: 0.22 });
          rep(9, k => { const z = -12.5 + k * 3.1 + (R() - 0.5), ph = R() * 6; let x = -25 + R() * 3; while (x < 24) { const Lg = Math.min(24 - x, 3 + R() * 9), xa = x; (R() < 0.6 ? C1 : C2).line(wv(6, t => [xa + Lg * t, TY, z + 0.4 * Math.sin((xa + Lg * t) * 0.4 + ph)]), Y3, 0.15 + R() * 0.25, 1); x += Lg + 1 + R() * 4; } });
          seg(EH, [-25.4, TY, 13.8], [25.4, TY, 13.8], Y3, 0.3); seg(EH, [-25.6, TY - 0.3, 14], [25.6, TY - 0.3, 14], Z3, 0.25);
          spot(CA2, [VX + 2.5, TY, VZ + 9], Y3, 3.2, 1.6, 0.3, 14); spot(CA2, [VX + 1.8, TY, VZ + 8.4], Y3, 1.4, 0.6, 0.3, 10); on(TR, [C1, C2, EH, CA2]); }
        const V = cyl(VX, TY, VZ, 6, VH, '#e3f3fa', { n: 8, op: 0.45, shine: 1, rg: [[0, 0, 0.86], [7, 0, 1], [VH, 0, 0.66]] }); o.push(V);
        { const FE = dec('#ffffff', { op: 0.75 }), CU = dec('#ffffff', { op: 0.4 }), WT = dec('#8fd0ea', { op: 0.22 }), STm = dec('#4a7a3a', { op: 0.5 }), MO = dec('#2a4a52', { op: 0.55 }), rr = y => rV(y - TY);
          band3(WT, VX, VZ, rr, TY + 0.6, TY + 12.5, 0, 2 * PI, 16);
          [[PI / 2 - 0.25, 0.3], [PI / 2 + 0.2, -0.2], [PI / 2 + 0.05, 0.5]].forEach(([a, da]) => STm.line(wv(6, t => { const y = TY + 1 + t * (VH - 1.4); return cP(VX, VZ, rr(y), a + da * t * 0.3, y); }), wv(6, t => cN(a + da * t * 0.3)), 0.3));
          rep(8, k => { const a0 = k * PI / 4, a1 = a0 + PI / 4; CU.line([cP(VX, VZ, rr(TY + 1), a0, TY + 1), cP(VX, VZ, rr(TY + 6), a1, TY + 6)], cN(a0 + PI / 8), 0.14); CU.line([cP(VX, VZ, rr(TY + 1), a1, TY + 1), cP(VX, VZ, rr(TY + 6), a0, TY + 6)], cN(a0 + PI / 8), 0.14); });
          rep(8, k => vL(FE, VX, VZ, rr, k * PI / 4, TY + 0.2, TY + VH - 0.2, 0.16)); ringL(FE, VX, VZ, rr, TY + 7, 0.2, 0, 2 * PI, 32); ringL(FE, VX, VZ, rr, TY + 12.5, 0.12, 0, 2 * PI, 32);
          MO.poly(elP([VX, TY + VH, VZ], X3, Z3, 2.6, 2.6, 16), Y3); on(V, [WT, STm, CU, FE, MO]); }
        const y0 = TY + VH, lerp = (P, s, t) => add(P[s], mul(sub(P[s + 1], P[s]), t));
        const P1 = [[VX - 0.8, y0, VZ - 0.6], [VX - 2.6, y0 + 8.5, VZ - 1.3], [VX - 1.6, y0 + 17, VZ - 2], [VX + 2.6, y0 + 24.5, VZ - 2.4], [VX + 8.4, y0 + 28.4, VZ - 2]], b1 = pipe(P1, 0.42, '#5a4030', W_({ n: 6 })); b1.forEach(s => o.push(s));
        [[0, 0.6, -1, 1], [1, 0.35, 1, -1], [1, 0.8, -1, 1], [2, 0.3, 1, 1], [2, 0.7, -1, -1], [3, 0.25, 1, 1], [3, 0.6, -1, 1], [3, 0.95, 1, -1]].forEach(([si, t, sx, sz], i) => { const p = add(lerp(P1, si, t), [sx * 0.9, 0.3, sz * 0.6]);
          on(b1[si], i % 3 === 2 ? [ball(p[0], p[1], p[2], 0.6, '#d8507a', { k: 3, n: 8 })] : [ball(p[0], p[1], p[2], 1.1, i % 2 ? '#f6c2d0' : '#fbe4ea', { k: 3, n: 9, sy: 0.8 }), ball(p[0], p[1] + 0.75, p[2] + 0.2, 0.35, '#c83a6a', { k: 2, n: 6 })]); });
        const P2b = [[VX + 0.9, y0, VZ + 0.5], [VX + 4.2, y0 + 4.6, VZ + 1.6], [VX + 9, y0 + 7.2, VZ + 3], [VX + 14.4, y0 + 6.6, VZ + 4]], b2 = pipe(P2b, 0.32, '#4a5a2a', { n: 6 }); b2.forEach(s => o.push(s));
        [[0, 0.7, 1], [1, 0.3, -1], [1, 0.75, 1], [2, 0.4, -1], [2, 0.9, 1]].forEach(([si, t, sg], i) => { const p = add(lerp(P2b, si, t), [0, 0.4, sg * 1.3]); on(b2[si], [ball(p[0], p[1], p[2], 1.7, i % 2 ? '#3f7a34' : '#5a9a44', { sx: 1.5, sy: 0.3, sz: 0.75, k: 3, n: 9 })]); });
        const P3 = [[VX - 0.4, y0, VZ + 1.2], [VX - 3.6, y0 + 2.2, VZ + 3.4], [VX - 6.6, y0 + 1.8, VZ + 5.2]], b3 = pipe(P3, 0.32, '#3f6a2e', { n: 6 }); b3.forEach(s => o.push(s));
        { const fc = [VX - 7.6, y0 + 2.2, VZ + 5.8]; on(b3[1], [ball(VX - 4.6, y0 + 2.6, VZ + 2.6, 2, '#2f5a2a', { sx: 1.4, sy: 0.3, sz: 0.7, k: 3, n: 9 }), ball(VX - 5.4, y0 + 2.4, VZ + 6.4, 1.8, '#2f5a2a', { sx: 1.3, sy: 0.3, sz: 0.7, k: 3, n: 9 }), ball(fc[0], fc[1], fc[2], 2.2, '#b81e34', { sy: 0.6, k: 4, n: 12 })]
          .concat(rep(5, i => { const a = i / 5 * 2 * PI; return ball(fc[0] + Math.cos(a) * 1.5, fc[1] + 1.1, fc[2] + Math.sin(a) * 1.5, 1.2, i % 2 ? '#d8283e' : '#e8344a', { sy: 0.5, k: 3, n: 9 }); }), [ball(fc[0], fc[1] + 1.6, fc[2], 0.7, '#f2c230', { k: 3, n: 8 })])); }
        const ID = cyl(IX, TY, IZ, 6.4, 2.6, '#1e1f22', { n: 28, mat: 'cer', shine: 1, rg: [[0, 0, 0.78], [0.8, 0, 0.92], [2.6, 0, 1]] }); o.push(ID);
        { const yT = TY + 2.6, SD = dec('#d9ceb3'), RK = dec('#b3a586', { op: 0.9 }), AS = dec('#8a8580', { op: 0.8 }), RM = dec('#ffffff', { op: 0.22 }), GL2 = dec('#c9a66a', { op: 0.5 }), sx = sb[0], sz = sb[2];
          SD.poly(elP([IX, yT, IZ], X3, Z3, 5.6, 5.6, 28), Y3); [1.2, 2.2, 3.2].forEach(r => ringY(RK, sx, sz, r, yT, 0.16, 28));
          [4.1, 4.7, -4.3].forEach(dz => { const h = Math.sqrt(Math.max(0, 5.3 * 5.3 - dz * dz)); seg(RK, [IX - h, yT, IZ + dz], [IX + h, yT, IZ + dz], Y3, 0.16); });
          [[0.7, 0.4], [-0.5, 0.8], [0.3, -0.7]].forEach(([dx, dz]) => spot(AS, [sx + dx, yT, sz + dz], Y3, 0.3, 0.2, dx, 6));
          ringY(RM, IX, IZ, 6.25, yT, 0.25, 40); ringC(GL2, IX, IZ, 6.3, TY + 2.2, 0.16, 40);
          on(ID, [SD, RK, AS, RM, GL2, rod(sp(0), sp(0.12), 0.14, '#d8c0a0', { n: 4 }), rod(sp(0.12), sp(0.93), 0.24, '#6a2f22', { n: 5 }), rod(sp(0.93), sp(0.98), 0.26, '#ff6a2a', em({ n: 5 })), ball(...sp(0.955), 0.33, '#ff8a3a', em({ k: 3, n: 6 }))].concat(pipe([sp(0.98), add(sp(1), [0.4, 0.4, 0]), add(sp(1), [0.9, 0.45, 0])], 0.2, '#a8a39c', { n: 5 }))); }
        const IB = box(15, TY, -9, 12, 2.4, 4.4, '#d8b88a', W_({ r: 0.3 })); o.push(IB);
        { const G = dec('#b8935e', { op: 0.6 }), LBL = dec('#f4ead8'), SP = dec('#c8303a'), TX = dec('#3a2a22', { op: 0.85 }), yT = TY + 2.4;
          rep(4, k => G.line(wv(12, t => [9.2 + t * 11.6, yT, -10.7 + k * 1.1 + 0.15 * Math.sin(t * 9 + k)]), Y3, 0.12));
          LBL.poly([[11, yT, -10.4], [15.4, yT, -10.4], [15.4, yT, -7.6], [11, yT, -7.6]], Y3); SP.poly(elP([16.8, yT, -9], X3, Z3, 0.9, 0.9, 12), Y3); rep(3, k => seg(TX, [11.6, yT, -9.9 + k * 0.85], [14.8 - (k % 2) * 1.2, yT, -9.9 + k * 0.85], Y3, 0.22));
          on(IB, [G, LBL, SP, TX].concat(rep(4, k => rod([21, TY + 0.8 + (k % 2) * 0.7, -10 + k * 0.6], [23.4, TY + 0.8 + (k % 2) * 0.7, -10.1 + k * 0.62], 0.22, '#7a3a2a', { n: 4 })))); }
        [[0.5, 3.2, 0.47, '#8a8580'], [0.8, 2.4, 0.48, '#a39e96'], [0.6, 1.7, 0.5, '#6f6a64']].reduce((y, [x, r, sy, col], i) => { const h = r * sy, z = 9 - i * 0.15, c = [x, y + h, z], S1 = ball(x, y + h, z, r, col, { sy, k: 4, n: 12 }); o.push(S1);
          const HL = dec('#ffffff', { op: 0.45 }), FK = dec(shade(col, 0.7), { op: 0.7 }); let [p, n] = elS(c, r, h, r, [-0.35, 1, -0.3]); spot(HL, p, n, r * 0.3, r * 0.16, 0.5, 8);
          rep(5, () => { [p, n] = elS(c, r, h, r, [(R() - 0.5) * 2, 0.3 + R(), (R() - 0.3) * 2]); spot(FK, p, n, 0.12 + R() * 0.14, 0.1 + R() * 0.08, R() * 3, 5); }); on(S1, [FK, HL]); return y + 2 * h; }, TY);
        const KB = ball(-20, TY + 3, 8, 3, '#4f7a3a', { k: 5, n: 14, mat: 'fab' }); o.push(KB);
        { const c = [-20, TY + 3, 8], TW = dec('#b89a6a', { op: 0.9 }), M1 = dec('#6f9a4a', { op: 0.7 }), M2 = dec('#2f5a26', { op: 0.6 });
          [0.4, 1.5, 2.6].forEach(ph => { const Q = wv(24, t => { const a = t * 2 * PI, d = [Math.cos(a) * Math.cos(ph), Math.sin(a), Math.cos(a) * Math.sin(ph)]; return [add(c, mul(d, 3.02)), d]; }); TW.line(Q.map(q => q[0]), Q.map(q => q[1]), 0.14); });
          rep(30, () => { const d = nz([(R() - 0.5) * 2, R() * 1.4 - 0.2, (R() - 0.5) * 2]); spot(R() < 0.5 ? M1 : M2, add(c, mul(d, 3)), d, 0.25, 0.18, R() * 3, 5); });
          on(KB, [M1, M2, TW].concat(rep(3, i => { const a = i * 2.1; return ball(-20 + Math.cos(a) * 0.8, TY + 6.3, 8 + Math.sin(a) * 0.8, 0.9, '#7ab84a', { sx: 1.4, sy: 0.35, k: 3, n: 8 }); }))); }
        return o; },
      fx: c => { const q = c.p(TIP[0], TIP[1], TIP[2]), k = c.k, g = c.p(VX - 3, TY + 10, VZ + 5);
        const sm = '<g transform="translate(' + P2(q) + ') scale(' + f1(k) + ')"><g><animateTransform attributeName="transform" type="skewX" values="0;7;-5;3;0" dur="6s" repeatCount="indefinite"/><path d="M0 0C-1.5 -4 1.8 -7 0.4 -11S-1.6 -18 0.8 -22S2.6 -28 0.2 -32" fill="none" stroke="url(#q25sm)" stroke-width="0.55" stroke-linecap="round" stroke-dasharray="6 2.4">' + an('stroke-dashoffset', '0;-16.8', 3.2) + '</path><path d="M0.2 -6C2 -10 -1 -14 1.4 -19S0 -26 2.2 -30" fill="none" stroke="url(#q25sm)" stroke-width="0.3" opacity="0.7"/></g></g>';
        return { defs: '<linearGradient id="q25sm" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="-32"><stop offset="0" stop-color="#ece8e0" stop-opacity="0.8"/><stop offset="1" stop-color="#ece8e0" stop-opacity="0"/></linearGradient>',
          front: sm + '<ellipse cx="' + f1(g[0]) + '" cy="' + f1(g[1]) + '" rx="' + f1(0.7 * k) + '" ry="' + f1(6 * k) + '" fill="#ffffff" opacity="0.3">' + an('opacity', '0.1;0.55;0.1', 5) + '</ellipse>' }; } }; };

    // LIV-088 chronometer + meteorite detail: brass inlay frame, engraved hour ring, sheen + ripples, front plaque, side bands + under-glow on the obsidian base;
    // walnut stand grain, polish, brass label; regmaglypt thumbprints, rust + metal glints on the meteorite; brushed pin; meridians, gold equator, hour ticks, stars + highlight on the floating sphere
    N.chrono25 = S => { const B = N.chrono(S), L0 = B.layers[0];
      return Object.assign({}, B, { fx: c => { const F = Object.assign({}, B.fx(c)); if (face(c, 0, 1) < 0.05) F.front = F.front.replace(/^<g transform="translate\([^"]*\) scale\([^"]*\)">.*?<\/g>/, ''); return F; }, build: P => { const o = B.build(P), on = glue(o), R = R0('chrono25'), MT = o.filter(S1 => (S1.col === '#4b4a4c' || S1.col === '#2e2d30') && !S1.par), CEN = S1 => { const L = bb(S1); return [(L[0] + L[1]) / 2, (L[2] + L[3]) / 2, (L[4] + L[5]) / 2]; }, M0 = MT[0], c0 = M0 && CEN(M0);
        if (M0) MT.slice(1).forEach(S1 => { const d = sub(CEN(S1), c0); S1.par = M0; if (Math.hypot(d[0], d[1], d[2]) > 0.5) S1.fn = nz(d); }); { const PNo = o.find(S1 => S1.col === '#9aa3a8' && !S1.par), STo = o.find(S1 => S1.col === '#3a2416' && !S1.par); if (PNo && STo) PNo.par = STo; }
        const BS = at(o, [-12, 2.5, 0], '#16161a'), ST = at(o, [15, 1.5, 0], '#3a2416'), PN = at(o, [15, 5, 0], '#9aa3a8', 0.6, 1);
        if (BS) { const yT = 5, IN = dec(BR, { op: 0.95 }), TK = dec('#c9a24a', { op: 0.9 }), SH = dec('#ffffff', { op: 0.07 }), RP = dec('#3a3a44', { op: 0.6 }), GL = dec('#6ac8ff', { emit: 1, op: 0.85 }), x0 = -24.3, x1 = 0.3, z0 = -9.3, z1 = 9.3;
          [[x0, z0, x1, z0], [x1, z0, x1, z1], [x1, z1, x0, z1], [x0, z1, x0, z0]].forEach(([a, b, c2, d]) => seg(IN, [a, yT, b], [c2, yT, d], Y3, 0.3)); [[x0, z0], [x1, z0], [x0, z1], [x1, z1]].forEach(([x, z]) => spot(IN, [x, yT, z], Y3, 0.45, 0.45, 0, 8));
          rep(48, i => { const a = i / 48 * 2 * PI, l = i % 4 ? 0.4 : 0.8, r0 = 8.4; seg(TK, [-12 + Math.cos(a) * r0, yT, Math.sin(a) * r0], [-12 + Math.cos(a) * (r0 + l), yT, Math.sin(a) * (r0 + l)], Y3, i % 4 ? 0.1 : 0.2); });
          SH.poly([[-24, yT, -2], [-18, yT, -9.4], [-14.6, yT, -9.4], [-20.6, yT, -2]], Y3); SH.poly([[-6, yT, 9.4], [0, yT, 2], [0.2, yT, 4.4], [-3.6, yT, 9.4]], Y3);
          [2.2, 3.2, 4.2].forEach(r => RP.line(wv(10, t => { const a = PI + t * PI / 2; return [-24 + Math.cos(a) * -r * 0.9, yT, 9 + Math.sin(a) * r]; }), Y3, 0.08));
          [[Z3, 10, 1], [mul(Z3, -1), -10, 1]].forEach(([n, z]) => { seg(IN, [-23, 4.2, z], [-1, 4.2, z], n, 0.25); seg(GL, [-22, 0.4, z], [-2, 0.4, z], n, 0.35); }); [[X3, 1], [mul(X3, -1), -25]].forEach(([n, x]) => seg(IN, [x, 4.2, -8], [x, 4.2, 8], n, 0.25));
          on(BS, [SH, RP, IN, TK, GL]); const PQ = on(BS, [box(-12, 1.1, 10, 10, 2.6, 0.32, BR, M_({ r: 0.2 }))], Z3)[0], EN = dec('#5a4214', { op: 0.85 });
          seg(EN, [-15.6, 2.9, 10.18], [-8.4, 2.9, 10.18], Z3, 0.26); seg(EN, [-14.6, 2.1, 10.18], [-9.4, 2.1, 10.18], Z3, 0.16); [[-16.4, 1.6], [-7.6, 1.6], [-16.4, 3.2], [-7.6, 3.2]].forEach(([x, y]) => spot(EN, [x, y, 10.18], Z3, 0.2, 0.2, 0, 6)); on(PQ, [EN]); }
        if (ST) { const yT = 3, G1 = dec('#24160c', { op: 0.55 }), G2 = dec('#5a3a22', { op: 0.5 }), HLs = dec('#ffffff', { op: 0.12 });
          [1.8, 3.0, 4.2, 5.4, 6.6, 7.6].forEach((r, i) => (i % 2 ? G2 : G1).line(wv(32, t => { const a = t * 2 * PI; return [15 + Math.cos(a) * r * (1 + 0.05 * Math.sin(a * 4 + i)), yT, Math.sin(a) * r * (1 + 0.05 * Math.cos(a * 3 + i))]; }), Y3, 0.16));
          rep(20, i => vL(i % 2 ? G1 : G2, 15, 0, () => 8, i / 20 * 2 * PI + R() * 0.1, 0.2, 2.8, 0.12)); spot(HLs, [12.5, yT, -2.5], Y3, 2.4, 1.2, 0.6, 12); on(ST, [G1, G2, HLs]);
          const PL3 = on(ST, [box(15, 0.7, 7.85, 4.4, 1.5, 0.3, BR, M_({ r: 0.2 }))], Z3)[0], EN = dec('#5a4214', { op: 0.85 }); seg(EN, [13.4, 1.75, 8.18], [16.6, 1.75, 8.18], Z3, 0.2); seg(EN, [13.9, 1.2, 8.18], [16.1, 1.2, 8.18], Z3, 0.14); on(PL3, [EN]); }
        if (PN) { const BL = dec('#ffffff', { op: 0.4 }); rep(3, k => vL(BL, 15, 0, () => 1.4, PI / 2 + 0.5 + k * 0.3, 3.2, 6.8, 0.1)); on(PN, [BL]); }
        o.filter(S1 => S1.col === '#4b4a4c' && (!S1.par || S1.par === M0)).forEach(S1 => { const L = bb(S1), c = [(L[0] + L[1]) / 2, (L[2] + L[3]) / 2, (L[4] + L[5]) / 2], rx = (L[1] - L[0]) / 2, ry = (L[3] - L[2]) / 2;
          const TH2 = dec('#2a292c', { op: 0.65 }), RS = dec('#7a4a2a', { op: 0.5 }), MG = dec('#d5dde2', { op: 0.85 });
          rep(Math.round(rx * 1.6), () => { const [p, n] = elS(c, rx, ry, rx, [(R() - 0.5) * 2, 0.2 + R(), (R() - 0.3) * 2]); spot(TH2, p, n, rx * (0.14 + R() * 0.12), rx * (0.1 + R() * 0.08), R() * 3, 9); });
          rep(3, () => { const [p, n] = elS(c, rx, ry, rx, [(R() - 0.5) * 2, R() * 0.8, 0.4 + R()]); spot(RS, p, n, 0.3 + R() * 0.4, 0.2 + R() * 0.3, R() * 3, 7); });
          rep(4, () => { const [p, n] = elS(c, rx, ry, rx, [-0.4 + (R() - 0.5), 0.8 + R() * 0.4, 0.2 + (R() - 0.5)]); spot(MG, p, n, 0.12, 0.08, 0, 5); }); on(S1, [TH2, RS, MG]); });
        return o; },
        layers: [Object.assign({}, L0, { build: P => { const o = L0.build(P), on = glue(o), SP = o[0], c = [-12, 14, 0], r = 5.4, R = R0('chrono25s');
          if (SP) { const ML = dec('#9aa3aa', { op: 0.8 }), EQ = dec(GOLD), TK = dec('#6a4a12'), STr = dec('#ffffff', { op: 0.85 }), HL = dec('#ffffff', { op: 0.5 }), gp = d => { d = nz(d); return [add(c, mul(d, r + 0.02)), d]; };
            rep(6, m => { const ph = m * PI / 6, Q = wv(24, t => gp([Math.sin(t * PI) * Math.cos(ph), Math.cos(t * PI), Math.sin(t * PI) * Math.sin(ph)])); ML.line(Q.map(q => q[0]), Q.map(q => q[1]), 0.1); });
            { const Q = wv(40, t => gp([Math.cos(t * 2 * PI), 0, Math.sin(t * 2 * PI)])); EQ.line(Q.map(q => q[0]), Q.map(q => q[1]), 0.45); }
            rep(12, i => { const a = i / 12 * 2 * PI, [p1, n1] = gp([Math.cos(a), 0.14, Math.sin(a)]), [p2] = gp([Math.cos(a), -0.14, Math.sin(a)]); TK.line([p1, p2], [n1, n1], 0.16); });
            rep(14, () => { const [p, n] = gp([(R() - 0.5) * 2, (R() - 0.3) * 2, (R() - 0.5) * 2]); spot(STr, p, n, 0.12, 0.12, 0, 5); });
            { const [p, n] = gp([-0.45, 0.75, 0.5]); spot(HL, p, n, 1.3, 0.8, 0.6, 12); } on(SP, [ML, EQ, TK, STr, HL]); }
          return o; } })] }); };

    // LIV-020 half-wilted pothos (same leaves): yogurt cup rebuilt (ribs, torn strawberry label with logo, nutrition panel + barcode, price sticker, taped crack, foil scrap, drain holes, drip),
    // soil with perlite + a fallen leaf + a pink plastic spoon, cup lid used as a saucer (pink print, puddle, fallen yellow + brown leaves)
    N.pothos25 = S => { const B = N.flora({ pl: 'pothos' }), rC = y => 10 * (0.8 + 0.2 * (y - 1) / 14), fr = PI / 2;
      return Object.assign({}, B, { build: () => { const o = [], on = glue(o), R = R0('pothos25');
        const SA0 = cyl(0, 0, 0, 11.6, 1, '#f6f1e8', PL({ n: 28, rg: [[0, 0, 0.94], [1, 0, 1]] })); o.push(SA0);
        { const PK = dec('#e86f8a'), PK2 = dec('#f6c2cc'), PD = dec('#8fb0c4', { op: 0.32 }), PDh = dec('#ffffff', { op: 0.35 }), YL = dec('#d8c45a'), YLv = dec('#a8943a', { op: 0.8 }), BRw = dec('#9a6a3a'), DT = dec('#8a7a60', { op: 0.25 });
          ringY(PK, 0, 0, 10.6, 1, 1.1, 48); ringY(PK2, 0, 0, 9.4, 1, 0.35, 48); speck(DT, 16, (u, v) => { const a = u * 2 * PI, r = 8.4 + v * 2.8; return [Math.cos(a) * r, 1, Math.sin(a) * r]; }, Y3, 0.15, 0.4, R);
          PD.poly(elP([6.2, 1, 6.4], X3, Z3, 3.2, 2, 18), Y3); spot(PDh, [5.6, 1, 6], Y3, 0.9, 0.3, 0.4, 10);
          heart(YL, -7.4, 1, 5.8, 1.5, 0.6); seg(YLv, [-7.4 + Math.sin(0.6) * 1.3, 1, 5.8 - Math.cos(0.6) * 1.3], [-7.4 - Math.sin(0.6) * 1.1, 1, 5.8 + Math.cos(0.6) * 1.1], Y3, 0.1); heart(BRw, 8.2, 1, -6, 1.2, 2.4);
          on(SA0, [PK, PK2, DT, PD, PDh, YL, YLv, BRw]); }
        const C = cyl(0, 1, 0, 10, 14, '#f4f2ec', PL({ n: 28, rg: [[0, 0, 0.8], [14, 0, 1]] })); o.push(C);
        { const LB = dec('#f3a6b6'), WH = dec('#ffffff'), RDs = dec('#e0303e'), GRs = dec('#4f9a3a'), SD = dec('#ffe58a'), TB = dec('#c83a5a'), RB = dec('#e2ded4', { op: 0.9 }), DR = dec('#8a7a5a', { op: 0.2 }), TP = dec('#f2e8b0', { op: 0.45 }), CK = dec('#9a958c', { op: 0.9 }), FO = dec('#c9ced3'), FOh = dec('#ffffff', { op: 0.75 }), HO = dec('#3a3028', { op: 0.85 }), NUT = dec('#ffffff'), BC = dec('#2a2a2e'), WD = dec('#bcd8e4', { op: 0.35 }), PRc = dec('#ff8a2a'), RS = dec('#e8e2d6', { op: 0.9 });
          rep(28, i => vL(RB, 0, 0, rC, i / 28 * 2 * PI, 1.3, 3.6, 0.14)); band3(DR, 0, 0, rC, 1.05, 1.8, 0, 2 * PI, 24);
          band3(LB, 0, 0, rC, 4, 12.2, 0.55, 2 * PI - 0.25, 30); [[-0.05, 6], [0.25, 9.4]].forEach(([a, y]) => spotC(RS, 0, 0, rC, a, y, 1.2, 0.6));
          WH.line(wv(10, t => { const y = 4 + 8.2 * t; return cP(0, 0, rC(y), 0.55 + 0.05 * Math.sin(t * 40), y); }), cN(0.58), 0.24);
          WH.line(wv(36, t => { const a = 0.62 + t * (2 * PI - 0.95); return cP(0, 0, rC(10.8), a, 10.8 + 0.35 * Math.sin(a * 6)); }), wv(36, t => cN(0.62 + t * (2 * PI - 0.95))), 0.7);
          [fr - 0.6, fr + 0.34, fr + 1.25, fr + 2.3, fr + 3.4].forEach(a => { spotC(RDs, 0, 0, rC, a, 6.2, 1.1, 1.35); spotC(GRs, 0, 0, rC, a, 7.55, 0.8, 0.35); [[-0.04, 6.6], [0.04, 6.1], [0, 5.5]].forEach(([da, y]) => spotC(SD, 0, 0, rC, a + da, y, 0.12, 0.16)); });
          spotC(WH, 0, 0, rC, fr, 8.8, 2.4, 1.0); ringL(TB, 0, 0, rC, 8.9, 0.36, fr - 0.17, fr + 0.17, 6); ringL(TB, 0, 0, rC, 8.35, 0.16, fr - 0.12, fr + 0.12, 4);
          const bk = 3 * PI / 2; band3(NUT, 0, 0, rC, 5, 10, bk - 0.4, bk + 0.4, 4); rep(6, i => ringL(BC, 0, 0, rC, 5.6 + i * 0.75, i ? 0.1 : 0.22, bk - 0.32, bk + 0.32 - (i % 2) * 0.12, 4));
          band3(NUT, 0, 0, rC, 5, 7.8, bk + 0.6, bk + 0.95, 3); rep(12, i => vL(BC, 0, 0, rC, bk + 0.63 + i * 0.027, 5.4, 7.4, i % 3 ? 0.06 : 0.12));
          spotC(PRc, 0, 0, rC, fr + 0.95, 2.6, 1.3, 0.8); ringL(WH, 0, 0, rC, 2.6, 0.18, fr + 0.88, fr + 1.02, 3);
          CK.line(wv(6, t => cP(0, 0, rC(8.6 + 5 * t), fr + 1.55 + 0.05 * Math.sin(t * 12), 8.6 + 5 * t)), cN(fr + 1.55), 0.14); band3(TP, 0, 0, rC, 9.4, 12.8, fr + 1.4, fr + 1.72, 3);
          FO.poly([[fr - 1.25, 15], [fr - 0.7, 15], [fr - 0.82, 13.6], [fr - 0.98, 12.4], [fr - 1.12, 13.4]].map(([a, y]) => cP(0, 0, rC(y), a, y)), cN(fr - 1)); FOh.line([cP(0, 0, rC(14.6), fr - 1.1, 14.6), cP(0, 0, rC(13.4), fr - 0.95, 13.4)], cN(fr - 1), 0.12);
          [fr + 0.5, fr - 0.2, fr + 1.1].forEach(a => spotC(HO, 0, 0, rC, a, 1.7, 0.3, 0.3)); vL(WD, 0, 0, rC, fr + 0.7, 1.4, 6, 0.3);
          on(C, [RB, DR, LB, RS, WH, RDs, GRs, SD, TB, NUT, BC, PRc, TP, CK, FO, FOh, HO, WD]); }
        on(C, [band(0, 14.4, 0, 10.1, 0.6, '#ffffff', PL({ n: 28 }))]);
        const SO = on(C, [cyl(0, 14.92, 0, 9.5, 0.16, '#4a3020', { n: 26 })])[0];
        { const PE = dec('#f2f0ea'), DK = dec('#2e1c10', { op: 0.7 }), Y2 = dec('#c9b04a'), yS = 15.08, disk = (u, v) => { const a = u * 2 * PI, r = Math.sqrt(v) * 9; return [Math.cos(a) * r, yS, Math.sin(a) * r]; };
          speck(DK, 40, disk, Y3, 0.3, 0.8, R); speck(PE, 26, disk, Y3, 0.15, 0.32, R); heart(Y2, -3.4, yS, 4.2, 1.6, 2.2);
          on(SO, [DK, PE, Y2, rod([3.2, yS, -2.4], [6.4, yS + 6.4, -5], 0.42, '#f6a0b4', PL({ n: 8 })), ball(6.5, yS + 6.6, -5.1, 0.6, '#f6a0b4', PL({ k: 3, n: 8, sy: 0.6 }))]); }
        return o; } }); };

    // LIV-100 floating zen sky-garden: brushed base with a glowing emitter + water moat + runes; island rebuilt (rock with strata + moss, hanging rocks, glowing crystals, roots,
    // soil band with grass fringe, mossy grass top with gravel path, stepping stones, tiny pond + lily pads, flowers, stone lantern); glass orb around it, all bobbing together
    N.terra25 = S => { const B = N.flora({ pl: 'terrarium' }), L0 = B.layers[0], GY = 40.5, GR = 15.6, GS = 0.16, gH = (x, z) => GY + GR * GS * Math.sqrt(Math.max(0, 1 - (x * x + z * z) / (GR * GR))) + 0.05, OC = 37, OR = 32, LX = -9, LZ = 6.5;
      return Object.assign({}, B, { w: 64, d: 56,
        build: () => { const o = [], on = glue(o);
          const B1 = cyl(0, 0, 0, 15, 2, '#23252b', M_({ n: 30, shine: 1, rg: [[0, 0, 0.96], [0.4, 0, 1], [2, 0, 1]] })), B2 = cyl(0, 2, 0, 12.6, 1.6, '#3a3d44', M_({ n: 28, rg: [[0, 0, 1], [1.6, 0, 0.94]] })); o.push(B1, B2);
          { const WA = dec('#4fb8e8', { op: 0.55 }), WAh = dec('#d8f4ff', { op: 0.5 }), RU = dec('#6ac8ff', { emit: 1, op: 0.8 }), BRu = dec('#8a9098', { op: 0.5 });
            rep(30, i => vL(BRu, 0, 0, () => 15, i / 30 * 2 * PI, 0.3, 1.8, 0.08)); WA.line(wv(48, t => [Math.cos(t * 2 * PI) * 13.8, 2, Math.sin(t * 2 * PI) * 13.8]), Y3, 1.7); ringY(WAh, 0, 0, 13.3, 2, 0.15, 48); ringY(WAh, 0.4, 0.2, 14.3, 2, 0.1, 40);
            rep(16, i => { const a = i / 16 * 2 * PI; ringL(RU, 0, 0, () => 15, 1.05, 0.22, a - 0.08, a + 0.08, 3); vL(RU, 0, 0, () => 15, a + (i % 2 ? 0.05 : -0.05), 0.7, 1.4, 0.14); }); on(B1, [BRu, WA, WAh, RU]); }
          { const BT = dec('#9aa3aa', { op: 0.9 }); rep(8, i => { const a = i / 8 * 2 * PI + 0.2; spot(BT, [Math.cos(a) * 11, 3.6, Math.sin(a) * 11], Y3, 0.35, 0.35, 0, 6); }); on(B2, [BT]); }
          const EM = on(B2, [cyl(0, 3.6, 0, 9.6, 0.25, '#6ac8ff', em({ n: 26 }))])[0];
          { const RI = dec('#e8fbff', { emit: 1, op: 0.7 }), HX = dec('#2a8ac8', { emit: 1, op: 0.6 }), yT = 3.85; rep(12, i => { const a = i / 12 * 2 * PI; seg(HX, [Math.cos(a) * 3.2, yT, Math.sin(a) * 3.2], [Math.cos(a) * 8, yT, Math.sin(a) * 8], Y3, 0.14); }); [3, 5.6, 8.2].forEach(r => ringY(RI, 0, 0, r, yT, 0.22, 36)); on(EM, [HX, RI]); }
          return o; },
        layers: [Object.assign({}, L0, { build: () => { const o = [], on = glue(o), R = R0('terra25i');
          const RK = ball(0, 26.4, 0, 12, '#7a6a5a', { sy: 0.55, k: 6, n: 18 }), SO = cyl(0, 33, 0, 15.2, 5, '#6e5a44', { n: 28, rg: [[0, 0, 0.72], [5, 0, 1]] }), GRb = ball(0, GY, 0, GR, '#5a8f3a', { sy: GS, k: 3, n: 22 });
          const r1 = ball(-5, 15, 2.5, 5.6, '#6a5a4a', { sy: 0.75, k: 5, n: 14 }), r2 = ball(6, 15.6, -2, 5, '#5a4a3a', { sy: 0.8, k: 5, n: 12 }), r3 = ball(0.4, 8.2, 0.4, 2.6, '#4e4034', { k: 4, n: 10 }); o.push(RK, SO, GRb, r1, r2, r3);
          { const rK = y => 12 * Math.sqrt(Math.max(0.02, 1 - Math.pow((y - 26.4) / 6.6, 2))), S1 = dec('#5a4a3c', { op: 0.6 }), S2 = dec('#9a8a78', { op: 0.5 }), MS = dec('#5f9a3e', { op: 0.85 }), MD = dec('#3f6f2e', { op: 0.8 });
            [21.5, 23.6, 25.8, 28, 30.2].forEach((y, i) => ringL(i % 2 ? S2 : S1, 0, 0, rK, y, 0.24, 0, 2 * PI, 36, a => 0.4 * Math.sin(a * 3 + y)));
            rep(14, i => { const a = i / 14 * 2 * PI + R() * 0.3; spotC(MS, 0, 0, rK, a, 31.6, 1.4 + R(), 0.6); if (i % 2) vL(MD, 0, 0, rK, a + 0.05, 28.4 + R() * 1.4, 31.4, 0.35); }); on(RK, [S1, S2, MD, MS]); }
          [[r1, [-5, 15, 2.5], 5.6, 4.2], [r2, [6, 15.6, -2], 5, 4]].forEach(([Sr, c, rx, ry]) => { const S1 = dec('#3e3228', { op: 0.5 }), MS = dec('#5f9a3e', { op: 0.75 }); rep(6, () => { const [p, n] = elS(c, rx, ry, rx, [(R() - 0.5) * 2, (R() - 0.6) * 1.6, (R() - 0.5) * 2]); spot(S1, p, n, 0.4 + R() * 0.5, 0.25, R() * 3, 6); }); rep(4, () => { const [p, n] = elS(c, rx, ry, rx, [(R() - 0.5) * 2, 0.7, (R() - 0.5) * 2]); spot(MS, p, n, 0.8, 0.4, R() * 3, 7); }); on(Sr, [S1, MS]); });
          on(r2, [rod([9.6, 14.6, -3.4], [12.4, 13.4, -4.6], 0.7, '#b07aff', em({ n: 6 })), rod([9.2, 13, -2.4], [11.4, 11.2, -2.8], 0.5, '#d0a8ff', em({ n: 6 })), rod([8.8, 15.8, -4.4], [10.4, 17.2, -5.6], 0.45, '#9a6aff', em({ n: 6 }))], [0.9, 0, -0.42]);
          on(r3, pipe([[0.4, 5.8, 0.4], [0.9, 4.9, 1], [0.6, 4.2, 1.6]], 0.16, '#5a3e28', { n: 4 })); on(r1, pipe([[-6, 10.9, 4.5], [-6.6, 8.4, 5.4], [-6.2, 6.6, 6.2]], 0.14, '#5a3e28', { n: 4 }));
          { const rS = y => 15.2 * (0.72 + 0.28 * (y - 33) / 5), PB = dec('#4a3a2a', { op: 0.75 }), RT = dec('#3a2a1a', { op: 0.6 }), FR = dec('#4f8a36');
            rep(30, () => spotC(PB, 0, 0, rS, R() * 2 * PI, 33.6 + R() * 3.4, 0.28, 0.22)); rep(10, () => { const a = R() * 2 * PI; RT.line(wv(4, t => { const y = 34 + t * 3; return cP(0, 0, rS(y), a + 0.06 * Math.sin(t * 6), y); }), cN(a), 0.12); });
            ringL(FR, 0, 0, rS, 37.6, 0.8, 0, 2 * PI, 48, a => 0.25 * Math.sin(a * 9)); on(SO, [PB, RT, FR]); }
          { const top = (x, z) => [x, gH(x, z), z], LG = dec('#7ab84a', { op: 0.7 }), DG = dec('#3f6f2e', { op: 0.6 }), GV = dec('#e2dccd'), STn = dec('#b8b3aa'), PO = dec('#3a8ac0', { op: 0.9 }), POh = dec('#cdefff', { op: 0.6 }), LP = dec('#6fae46'), FLc = ['#ffffff', '#f6a0b4', '#ffe066'].map(c => dec(c));
            const okP = (x, z) => Math.hypot(x - 10.2, z - 5.2) > 3.6 && Math.hypot(x - LX, z - LZ) > 2.6 && Math.hypot(x, z) > 3;
            speck(LG, 80, (u, v) => { const a = u * 2 * PI, r = Math.sqrt(v) * 14.8, x = Math.cos(a) * r, z = Math.sin(a) * r; return okP(x, z) ? top(x, z) : null; }, Y3, 0.15, 0.42, R); speck(DG, 50, (u, v) => { const a = u * 2 * PI, r = Math.sqrt(v) * 14.8, x = Math.cos(a) * r, z = Math.sin(a) * r; return okP(x, z) ? top(x, z) : null; }, Y3, 0.15, 0.4, R);
            rep(28, i => { const t = i / 27, x = -12 + 13 * t + (R() - 0.5) * 1.2, z = 9 - 11 * t + 2 * Math.sin(t * PI * 2) + (R() - 0.5) * 1.2; if (Math.hypot(x, z) > 2.6) spot(GV, top(x, z), Y3, 0.3 + R() * 0.15, 0.24, R() * 3, 6); });
            [[-8.6, 1.4], [-5, -1.6], [-1.6, -3.4]].forEach(([x, z]) => spot(STn, top(x, z), Y3, 1, 0.75, x, 10));
            PO.poly(elP(top(10.2, 5.2), X3, Z3, 2.8, 2, 18), Y3); spot(POh, top(9.4, 4.6), Y3, 1.1, 0.35, 0.3, 10); spot(LP, top(11.2, 5.6), Y3, 0.6, 0.5, 0, 8); spot(LP, top(9.6, 6.2), Y3, 0.45, 0.4, 0, 8); spot(FLc[1], top(11.1, 5.5), Y3, 0.22, 0.22, 0, 6);
            rep(22, i => { const a = R() * 2 * PI, r = 4 + R() * 10.5, x = Math.cos(a) * r, z = Math.sin(a) * r; if (okP(x, z)) spot(FLc[i % 3], top(x, z), Y3, 0.2, 0.2, 0, 6); });
            on(GRb, [DG, LG, GV, STn, PO, POh, LP].concat(FLc));
            const h = gH(LX, LZ) - 0.05, WN = dec('#ffb85a', { emit: 1, op: 0.95 }), LB = box(LX, h + 2.9, LZ, 1.9, 1.5, 1.9, '#a8a399', { r: 0.3 });
            on(GRb, [cyl(LX, h - 0.1, LZ, 1.3, 0.6, '#9a958c', { n: 8 }), box(LX, h + 0.5, LZ, 0.9, 2.4, 0.9, '#a8a399', { r: 0.2 }), LB]);
            [[Z3, 0, 0.96], [mul(Z3, -1), 0, -0.96], [X3, 0.96, 0], [mul(X3, -1), -0.96, 0]].forEach(([n, dx, dz]) => { const c = [LX + dx, h + 3.65, LZ + dz], u = Math.abs(n[0]) > 0.5 ? Z3 : X3; WN.poly([add(c, add(mul(u, -0.45), [0, -0.45, 0])), add(c, add(mul(u, 0.45), [0, -0.45, 0])), add(c, add(mul(u, 0.45), [0, 0.45, 0])), add(c, add(mul(u, -0.45), [0, 0.45, 0]))], n); });
            on(LB, [WN]); on(GRb, [cyl(LX, h + 4.4, LZ, 2.2, 1, '#8a857c', { n: 6, rg: [[0, 0, 1], [0.3, 0, 1.05], [1, 0, 0.25]] }), ball(LX, h + 5.6, LZ, 0.35, '#8a857c', { k: 3, n: 6 })]); }
          return o; } })],
        fx: c => { const F = B.fx(c), k = c.k, q = c.p(0, OC, 0), Rr = OR * k, lq = c.p(LX, gH(LX, LZ) + 3.6, LZ), pq = c.p(10.2, gH(10.2, 5.2), 5.2), mv = atS('translate', '0 0;0 -4;0 0', 4);
          const orb = '<g>' + mv + '<ellipse cx="' + f1(lq[0]) + '" cy="' + f1(lq[1]) + '" rx="' + f1(4 * k) + '" ry="' + f1(4 * k) + '" fill="url(#q25lg)">' + an('opacity', '0.55;0.9;0.6;0.85;0.55', 2.2) + '</ellipse>'
            + '<ellipse cx="' + f1(pq[0]) + '" cy="' + f1(pq[1]) + '" rx="' + f1(1.4 * k) + '" ry="' + f1(1.4 * k * X.SA) + '" fill="none" stroke="#e8fbff" stroke-width="' + f1(0.18 * k) + '">' + an('rx', f1(0.6 * k) + ';' + f1(2.6 * k), 2.4) + an('ry', f1(0.6 * k * X.SA) + ';' + f1(2.6 * k * X.SA), 2.4) + an('opacity', '0.9;0', 2.4) + '</ellipse>'
            + '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(Rr) + '" fill="url(#q25orb)" stroke="#dff6ff" stroke-opacity="0.55" stroke-width="' + f1(0.35 * k) + '"/>'
            + '<path d="M' + f1(q[0] - Rr * 0.78) + ' ' + f1(q[1] - Rr * 0.3) + 'A' + f1(Rr * 0.84) + ' ' + f1(Rr * 0.84) + ' 0 0 1 ' + f1(q[0] - Rr * 0.18) + ' ' + f1(q[1] - Rr * 0.82) + '" fill="none" stroke="#ffffff" stroke-width="' + f1(1.1 * k) + '" stroke-linecap="round" opacity="0.55"/>'
            + '<ellipse cx="' + f1(q[0] + Rr * 0.5) + '" cy="' + f1(q[1] + Rr * 0.55) + '" rx="' + f1(Rr * 0.2) + '" ry="' + f1(Rr * 0.07) + '" transform="rotate(-40 ' + f1(q[0] + Rr * 0.5) + ' ' + f1(q[1] + Rr * 0.55) + ')" fill="#ffffff" opacity="0.25"/>'
            + '<circle cx="' + f1(q[0] - Rr * 0.5) + '" cy="' + f1(q[1] - Rr * 0.56) + '" r="' + f1(0.9 * k) + '" fill="#ffffff">' + an('opacity', '0.2;1;0.2', 3.6) + '</circle></g>';
          const bb0 = F.bb || [q[0], q[1], q[0], q[1]];
          return Object.assign({}, F, { defs: (F.defs || '') + RG('q25lg', '#ffe2a0', '#ffb85a', 0.6) + '<radialGradient id="q25orb" cx="38%" cy="32%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.06"/><stop offset="0.75" stop-color="#cfeefa" stop-opacity="0.08"/><stop offset="1" stop-color="#9fd8f0" stop-opacity="0.3"/></radialGradient>',
            front: (F.front || '') + orb, bb: [Math.min(bb0[0], q[0] - Rr - 2), Math.min(bb0[1], q[1] - Rr - 6), Math.max(bb0[2], q[0] + Rr + 2), Math.max(bb0[3], q[1] + Rr + 2)] }); } }); };
  }

  // ---------- catalog edits ----------
  RD.SET24 = {
    'LIV-002': { spec: 'torch24', note: 'A cheap grey torchiere: scuffed, rusty base with a $4.99 sticker, a bent pole with rust streaks and a rotary switch, held together with wrinkled tape, a bendy gooseneck and a ribbed plastic bowl shade with a scorch mark and two cracks. The bulb flickers now and then.' },
    'LIV-042': { spec: 'arc24', note: 'A chrome arc with jointed collars that rises from a veined white marble block and curves over the sofa, ending in a vented, mirror-shiny dome shade that throws a pool of warm light below. A foot switch on the cord.' },
    'LIV-062': { spec: 'alab24', note: 'A totem of six smooth alabaster stones with amber and white veins and cloudy inclusions, stacked on grooved bronze spacers over a patinated base. Light glows through the stones and slowly breathes from one to the next.' },
    'LIV-082': { spec: 'bio24', note: 'A glass column ribbed in brass, misted with drops, on a carved stone pot with glowing runes. A glowing vine spirals up inside, moss and tiny glowing mushrooms ring its foot. Spores drift up and a pulse of light climbs the vine.' },
    'LIV-023': { spec: 'iron24', note: 'A slim black iron frame with green-edged glass top and shelf: keys, a coin and a letter in the brass tray, a framed photo and a succulent on top, a woven basket with a knit throw and books below.' },
    'LIV-063': { spec: 'burl24', note: 'A swirly burl-wood top full of tiny burl eyes under a glossy lacquer, on fluted brass legs with a gallery rail at the back. A brass bowl of fruit, a veined stone orb and art books on top.' },
    'LIV-083': { spec: 'liquid24', live: 'Dripping', note: 'A mirror-chrome console that looks poured: its legs flow up like liquid metal into the top, reflecting the room. Drips hang under the edge, a shine sweeps across, ripples spread on the top and a drop drips down into a little puddle. A dried branch in a black vase.' },
    'LIV-056': { spec: 'live24', note: 'A thick walnut slab with flowing grain around two knots, a resin-filled crack held by two wooden bowties and a pale sapwood rim with bits of bark, on black steel frames. A turned bowl of moss balls, a latte with a heart, a spoon and a book.' },
    'LIV-076': { spec: 'drum24', note: 'A big cream travertine drum with broken bands and little pores all round, nested with a smaller brushed, smoky bronze drum with a brass rim. A book, a brass orb and a white bowl of river stones.' },
    'LIV-019': { spec: 'crate24', note: 'A scuffed red plastic milk crate turned upside down, with a barcode sticker on the side, a cup of instant noodles and a fork on top, and a phone whose charger cable hangs over the side.' },
    'LIV-039': { spec: 'bistro24', note: 'A glossy white tulip table on one slim pedestal, with a bud vase holding a pink tulip, a little book and a cup of tea on a gold-rimmed saucer.' },
    'LIV-059': { spec: 'tambour24', note: 'A small grained-oak cabinet on brass-capped legs with a fluted tambour door slid half open to show books inside. A glass of water, reading glasses and a novel with a ribbon bookmark on top.' },
    'LIV-015': { spec: 'faux24', note: 'A drafty fake fireplace: a printed brick panel with a seam, nail heads, a sun-faded patch, scuffs, a gold star sticker and one corner peeling off, on a speckled tile hearth with a cracked tile. In the empty firebox a little space heater glows orange behind its guard, cord trailing past a paper ball. A grainy wood mantel with a water ring, a plastic clock that ticks and a dripping candle that flickers sideways; a sock dries on a pin, swinging in the draft.' },
    'LIV-055': { spec: 'mantel24', note: 'A classic white mantel: fluted pilasters, carved swags and bellflower drops on the frieze, a dentil crown and panelled sides, over a cleft black slate surround with brass trim and a flecked granite hearth. Ceramic gas logs with white ash and glowing cracks burn on a grate with blue-based flames in a sooty brick firebox behind a brass mesh screen; dripping candles flicker either side of a beaded gilt mirror.' },
    'LIV-095': { spec: 'etha24', note: 'A honed black basalt slab that seems to float on a warm under-glow, glass on three sides with green edges. A brushed steel burner sends up a row of flames and softly glowing water-vapour mist between glinting river stones; the flames reflect in the dark back glass and a little panel shows the flame level.' },
    'LIV-008': { spec: 'coupons25', note: 'A little stack of six clipped coupons in faded colours, each with dashed scissor lines and a price box, a paperclip on the top one (50¢ OFF, long EXPIRED). Next to it a cork coaster with an old coffee ring, orange-handled scissors and a ballpoint pen.' },
    'LIV-028': { spec: 'candle25', note: 'A soy candle in an amber glass jar with a kraft lavender & fig label, a soft melt pool and a flickering flame, its wooden lid beside it. A speckled ceramic dish with a gold rim holds a ring, two pearl studs and a hair tie, next to a matchbox and a burnt match.' },
    'LIV-048': { spec: 'books25', note: 'Three cloth-bound art books stacked a little crooked, with gilt titles on the spines, debossed covers, worn corners and a red ribbon bookmark, a postcard tucked in the bottom one. A brass magnifying glass with a turned wooden handle lies on top.' },
    'LIV-068': { spec: 'ikebana25', note: 'A cut-crystal vase holding a plum branch in blossom, a leafy branch and a red camellia, on a cleft slate tray. Beside it an incense stick glows in a black dish of raked sand, its smoke curling up, with a wooden incense box, a little stone cairn and a moss ball.' },
    'LIV-088': { spec: 'chrono25', live: 'Levitating', note: 'A polished steel sphere with meridian lines, a gold equator and tiny stars floats above an obsidian base inlaid with brass and an engraved hour ring, inside armillary rings. Beside it, a rare iron meteorite covered in thumbprint dents sits on a walnut stand with a brass label.' },
    'LIV-020': { spec: 'pothos25', note: 'A half-wilted pothos in an old strawberry yogurt cup with a torn label, a taped crack, a bit of foil stuck to the rim and holes poked in the bottom, standing on its lid as a saucer with a little puddle and fallen leaves. A pink plastic spoon is stuck in the soil.' },
    'LIV-100': { spec: 'terra25', live: 'Levitating', note: 'A tiny sky island floats inside a glass orb above a glowing base with a water ring: a bonsai on a mossy lawn with a gravel path, stepping stones, a tiny pond with lily pads and a glowing stone lantern. The rocks underneath have moss, roots and glowing crystals, and a little waterfall spills over the edge.' },
    'LIV-099': { spec: 'lev24', live: 'Floating', note: 'A white round top ringed with tiny lights floats over a vented glowing base and gently bobs. Rings of light rise between them and the phone on the top charges wirelessly.' },
  };
  const edit23 = RD.edit;
  RD.edit = rows => edit23(rows).map(r => RD.SET24[r.id] ? Object.assign({}, r, RD.SET24[r.id]) : r);
  RD.H24 = { dec, spot, elP, wv, at, rrect, ext, ringY, ringC };
  RD.PLUS24 = 1;
})();
