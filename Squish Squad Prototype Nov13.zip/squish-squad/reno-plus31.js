// Renovation Catalog round 31 — Dance Club realism pass (same rules as the Kitchen / Bathroom / Bedroom: floor -> walls -> ceiling -> electronics -> furniture).
// Floors = r.f31: the 80 x 56 perspective trapezoid build of plus20 / plus27 / plus29 / plus30 (W(u, y) floor space, creature scale).
// CLB-005 duct-taped cardboard breakdance mat on concrete, 025 black-and-white checkerboard vinyl, 045 70s light-up acrylic disco squares.
// The CLB add-ons CLB-101..114 are left as they are. Sets RenoDraw.PLUS31; catalog edits RD.SET31; helpers RD.H31.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS30 && RD.H12 && RD.H12.SURF12 && RD.H27 && RD.H20 && RD.H13 && RD.H10 && RD.N && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS31) return;
  const shade = X.K.shade, PI = Math.PI, H = RD.H10, N = RD.N;
  const { rng, an, at, SPL, f1, n4, rep, cam, P2 } = H;
  const { fblot, FL } = RD.H13;
  const { W, polyW, lineW, crvW } = RD.H20;
  const { quadW, dot, dotD } = RD.H27;
  const { hexW } = RD.H29;
  const TR = 'M14 0H66L80 56H0Z';
  const wk = v => (52 + 28 * v) / 80, gv = t => t * (0.7 + 0.3 * t), K = y => RD._FLAT ? 0.82 : wk(gv(y));
  const pt = p => f1(p[0]) + ' ' + f1(p[1]);
  const KT = k => ` keyTimes="${k}"`;
  // soft coloured light pools drifting over a floor (party lights from above)
  const pools = (L, op) => `<g filter="url(#fb3)" style="mix-blend-mode:screen">` + L.map(([u, y, r, c, T, du, dy], i) => `<g>${at('translate', `0 0;${du} ${dy};0 0`, T, -i * 2, SPL(2))}${dot(u, y, r, `fill="${c}" opacity="${op}"`)}</g>`).join('') + `</g>`;

  // ======================= FLOORS =======================
  // CLB-005 DUCT-TAPED CARDBOARD BREAKDANCE MAT ON CONCRETE (T1): a bare garage slab of grey troweled concrete with saw-cut joints, a hairline crack, oil
  // and drink stains, and in the middle a breakdance mat made of three flattened appliance boxes duct-taped together with silver tape, printed arrows and a
  // fragile-glass mark still on them, dark circular scuffs where heads and backs spun, a sneaker skid, a water ring, one tape strip peeling up at the
  // corner, chalk marks and an orange extension cord snaking along the wall. Live: the loose tape end flutters and dust motes swirl over the spin spot.
  function fCard() { const R = rng('card31');
    let s = '<rect width="80" height="56" fill="#86847e"/>';
    // concrete: trowel swirls, aggregate specks, stains, joints, crack
    s += fblot('conc31', 30, ['#9a9890', '#74726c', '#8e8c84', '#6a6862'], 0.32, 9);
    s += `<path d="${rep(40, () => { const u = R(), y = R(); return crvW(rep(5, j => { const a = j * 0.5 + R(); return [u + Math.cos(a) * 0.04, y + Math.sin(a) * 0.03]; })); }).join('')}" stroke="#a8a69e" stroke-width="0.18" fill="none" opacity="0.35"/>`;
    s += rep(160, () => dot(R(), R() * 1.02, 0.08 + R() * 0.14, `fill="${R() < 0.5 ? '#5e5c56' : '#b2b0a8'}" opacity="0.6"`)).join('');
    s += [[0.33], [0.67]].map(([u]) => `<path d="${lineW([[u, -0.02], [u, 1.04]])}" stroke="#4e4c48" stroke-width="0.4"/><path d="${lineW([[u + 0.003, -0.02], [u + 0.003, 1.04]])}" stroke="#b8b6ae" stroke-width="0.15" opacity="0.5"/>`).join('')
      + `<path d="${lineW([[-0.02, 0.5], [1.02, 0.5]])}" stroke="#4e4c48" stroke-width="0.4"/>`;
    s += `<path d="${crvW([[0.04, 0.72], [0.1, 0.74], [0.13, 0.8], [0.19, 0.83], [0.22, 0.92]])}" stroke="#3e3c38" stroke-width="0.25" fill="none"/>`;
    s += [[0.12, 0.3, 3.2, '#3a3832'], [0.86, 0.66, 2.4, '#4a4640'], [0.8, 0.18, 1.6, '#5a5248']].map(([u, y, r, c]) => `<g filter="url(#fb1)">${dot(u, y, r, `fill="${c}" opacity="0.45"`)}${dot(u + 0.02, y + 0.02, r * 0.6, `fill="${c}" opacity="0.3"`)}</g>`).join('');
    if (RD._PART === 'base') return FL(s); if (RD._PART === 'over') s = '';
    // the mat: three flattened boxes
    const SH = [[0.15, 0.18, 0.85, 0.42, '#c49a62'], [0.14, 0.41, 0.84, 0.64, '#b88e58'], [0.16, 0.63, 0.85, 0.87, '#c8a068']]; // boxes lie with their long side along the front edge
    s += `<path d="${polyW([[0.15, 0.2], [0.87, 0.2], [0.87, 0.9], [0.15, 0.9]])}" fill="#000000" opacity="0.25" filter="url(#fb1)"/>`;
    SH.forEach(([u0, y0, u1, y1, c], i) => { s += `<path d="${polyW([[u0, y0], [u1, y0 + 0.005], [u1 + 0.003, y1], [u0 - 0.002, y1 - 0.004]])}" fill="${c}"/>`;
      s += `<path d="${rep(26, j => lineW([[u0 + 0.004, y0 + 0.02 + j * (y1 - y0 - 0.04) / 25], [u1 - 0.004, y0 + 0.02 + j * (y1 - y0 - 0.04) / 25]])).join('')}" stroke="${shade(c, 0.88)}" stroke-width="0.12" opacity="0.6"/>`;
      s += `<path d="${lineW([[u0 + 0.03, y0 + 0.05], [u1 - 0.03, y0 + 0.05]])}" stroke="${shade(c, 0.8)}" stroke-width="0.3" stroke-dasharray="0.8 0.6" opacity="0.6"/>`; });
    // printed marks: up arrows, fragile glass, box logo blocks
    const arrow = (u, y) => `<path d="${polyW([[u, y], [u + 0.018, y + 0.05], [u + 0.007, y + 0.05], [u + 0.007, y + 0.1], [u - 0.007, y + 0.1], [u - 0.007, y + 0.05], [u - 0.018, y + 0.05]])}" fill="#3a2a1a" opacity="0.55"/>`;
    s += arrow(0.26, 0.22) + arrow(0.3, 0.22) + arrow(0.7, 0.7) + arrow(0.74, 0.7);
    s += `<path d="${polyW([[0.5, 0.45], [0.54, 0.45], [0.53, 0.51], [0.522, 0.51], [0.522, 0.56], [0.535, 0.57], [0.505, 0.57], [0.518, 0.56], [0.518, 0.51], [0.51, 0.51]])}" fill="#a83a2a" opacity="0.6"/>`
      + `<path d="${quadW(0.64, 0.26, 0.76, 0.32)}" fill="#3a5a8a" opacity="0.45"/><path d="${quadW(0.65, 0.34, 0.74, 0.36)}" fill="#3a2a1a" opacity="0.4"/>`;
    // spin scuffs, sneaker skid, water ring
    s += `<g filter="url(#fb1)">` + [[0.5, 0.48, 7], [0.5, 0.48, 4.6], [0.44, 0.58, 3]].map(([u, y, r]) => `<path d="${dotD(u, y, r)}" fill="none" stroke="#5a3e22" stroke-width="${f1(r * 0.25)}" opacity="0.32"/>`).join('') + `</g>`
      + `<path d="${crvW([[0.3, 0.68], [0.36, 0.66], [0.42, 0.67]])}" stroke="#2a2a2a" stroke-width="1" fill="none" opacity="0.35" stroke-linecap="round"/>` + `<path d="${dotD(0.72, 0.5, 2)}" fill="none" stroke="#8a6a40" stroke-width="0.35" opacity="0.6"/>`;
    // silver duct tape: seams + edges + crossing patches
    const tape = (u0, y0, u1, y1) => `<path d="${polyW([[u0, y0], [u1, y0], [u1, y1], [u0, y1]])}" fill="#b8bcc0"/><path d="${polyW([[u0, y0], [u1, y0], [u1, y0 + (y1 - y0) * 0.35], [u0, y0 + (y1 - y0) * 0.35]])}" fill="#e2e6ea" opacity="0.6"/>`
      + `<path d="${rep(5, j => lineW([[u0 + (u1 - u0) * R(), y0 + (y1 - y0) * R()], [u0 + (u1 - u0) * R(), y0 + (y1 - y0) * R()]])).join('')}" stroke="#8a8e94" stroke-width="0.12" opacity="0.7"/>`;
    s += tape(0.13, 0.4, 0.86, 0.43) + tape(0.13, 0.62, 0.86, 0.65) + tape(0.13, 0.17, 0.16, 0.88) + tape(0.84, 0.17, 0.87, 0.88) + tape(0.3, 0.16, 0.36, 0.21) + tape(0.62, 0.84, 0.68, 0.89);
    // peeling tape end at the front-right corner, fluttering
    const pp = W(0.8, 0.87), k = K(0.87);
    s += `<g transform="translate(${pt(pp)}) scale(${n4(k)})"><g>${at('rotate', '-8 0 0;10 0 0;-4 0 0;-8 0 0', 2.6, 0, SPL(3))}<path d="M0 0L3.4 -1.6L4.6 0.4L1 1.6Z" fill="#d4d8dc" stroke="#8a8e94" stroke-width="0.12"/></g></g>`;
    // chalk marks + extension cord along the back
    s += `<path d="${lineW([[0.86, 0.36], [0.9, 0.42]])}${lineW([[0.9, 0.36], [0.86, 0.42]])}" stroke="#f2f0e8" stroke-width="0.3" opacity="0.6"/><path d="${crvW([[0.12, 0.62], [0.13, 0.68], [0.12, 0.74]])}" stroke="#f2e8a8" stroke-width="0.3" fill="none" opacity="0.5"/>`;
    if (!RD._PART) s += `<path d="${crvW([[-0.02, 0.06], [0.2, 0.08], [0.3, 0.05], [0.5, 0.09], [0.7, 0.06], [0.86, 0.1], [0.92, 0.2], [0.95, 0.4], [1.02, 0.45]])}" stroke="#e86a2a" stroke-width="0.9" fill="none" stroke-linecap="round"/><path d="${crvW([[-0.02, 0.055], [0.2, 0.075], [0.3, 0.045], [0.5, 0.085]])}" stroke="#ffb080" stroke-width="0.25" fill="none" opacity="0.6"/>`;
    // dust motes swirling over the spin spot
    const cp = W(0.5, 0.48), ck = K(0.48);
    s += `<g transform="translate(${pt(cp)}) scale(${n4(ck)} ${n4(ck * 0.5)})">${rep(12, i => `<g>${at('rotate', `${i * 30} 0 0;${i * 30 + 360} 0 0`, 6 + (i % 3))}<circle cx="${3 + (i % 4) * 1.4}" cy="${-1 - (i % 3)}" r="0.3" fill="#e8e2d4" opacity="0.7">${an('opacity', '0.2;0.8;0.2', 2 + (i % 3), -i * 0.3)}</circle></g>`).join('')}</g>`;
    s += `<path d="${TR}" fill="none" stroke="#2a2826" stroke-width="7" opacity="0.3" filter="url(#fb3)"/>`;
    return FL(s, 1); }

  // CLB-025 BLACK-AND-WHITE CHECKERBOARD VINYL DANCE FLOOR (T2): budget 12-inch vinyl tiles laid in a black-and-white checkerboard, the whites gone a
  // little ivory, dark seams, black heel scuffs and grey skid arcs on the whites, a chipped tile corner showing the grey backing, a lifted tile edge, a
  // sticky soda spill, a glossy floor-polish sheen, and coloured party-light pools (magenta, amber, violet) gliding over it.
  // Live: the light pools glide across the tiles and the gloss shifts.
  function fCheck() { const R = rng('check31'), NC = 10, NR = 8;
    let s = '<rect width="80" height="56" fill="#141416"/>';
    for (let i = 0; i < NC; i++) for (let j = 0; j < NR; j++) { const u0 = i / NC, u1 = (i + 1) / NC, y0 = j / NR * 1.04 - 0.02, y1 = (j + 1) / NR * 1.04 - 0.02, wh = (i + j) % 2 === 0, c = wh ? shade('#ece6d8', 0.95 + R() * 0.06) : shade('#1e1e22', 0.9 + R() * 0.2);
      s += `<path d="${quadW(u0 + 0.0015, y0 + 0.002, u1 - 0.0015, y1 - 0.002)}" fill="${c}"/>`;
      if (wh && R() < 0.5) s += `<path d="${crvW([[u0 + 0.02 + R() * 0.03, y0 + 0.03 + R() * 0.05], [u0 + 0.05, y0 + 0.07], [u0 + 0.08, y0 + 0.05 + R() * 0.04]])}" stroke="#6a6862" stroke-width="${f1(0.2 + R() * 0.4)}" fill="none" opacity="0.4" stroke-linecap="round"/>`;
      if (wh && R() < 0.35) s += dot(u0 + 0.03 + R() * 0.04, y0 + 0.03 + R() * 0.06, 0.4 + R() * 0.5, 'fill="#1a1a1a" opacity="0.45"');
      if (!wh && R() < 0.3) s += `<path d="${lineW([[u0 + 0.02 + R() * 0.05, y0 + 0.04], [u0 + 0.06 + R() * 0.03, y0 + 0.06 + R() * 0.04]])}" stroke="#4a4a50" stroke-width="0.2" opacity="0.6"/>`; }
    s += `<path d="${polyW([[0.3, 0.385], [0.33, 0.385], [0.3, 0.42]])}" fill="#8a8680"/><path d="${lineW([[0.6, 0.645], [0.7, 0.645]])}" stroke="#ffffff" stroke-width="0.35" opacity="0.7"/><path d="${lineW([[0.6, 0.65], [0.7, 0.65]])}" stroke="#000000" stroke-width="0.35" opacity="0.4"/>`;
    s += `<g filter="url(#fb1)">${dot(0.76, 0.3, 2.4, 'fill="#8a4a2a" opacity="0.25"')}${dot(0.78, 0.31, 1.4, 'fill="#5a2a14" opacity="0.25"')}</g>` + dot(0.765, 0.3, 1.6, 'fill="#ffffff" opacity="0.18"');
    s += fblot('check31', 18, ['#5a5650', '#c8c2b4'], 0.1, 7);
    // gloss + drifting party light pools
    s += `<g filter="url(#fb3)"><g>${at('translate', '0 0;4 0.4;0 0', 20)}<path d="${polyW([[0.12, 0], [0.24, 0], [0.3, 0.5], [0.12, 0.5]])}" fill="#ffffff" opacity="0.12"/></g>${dot(0.5, 0.3, 10, 'fill="#ffffff" opacity="0.06"')}</g>`;
    s += pools([[0.25, 0.4, 8, '#ff3aa0', 11, 18, 4], [0.7, 0.6, 9, '#ffb030', 13, -16, -6], [0.5, 0.2, 7, '#8a5aff', 9, 10, 8], [0.85, 0.85, 7, '#ff5a5a', 15, -20, -3]], 0.5);
    s += `<path d="${TR}" fill="none" stroke="#0a0a0c" stroke-width="7" opacity="0.4" filter="url(#fb3)"/>`;
    return FL(s); }

  // CLB-045 70s RETRO LIGHT-UP ACRYLIC DISCO SQUARES (T3): a grid of frosted acrylic squares in a black frame, each lit from beneath in strong
  // seventies colours (amber, tangerine, hot pink, violet, gold, lime), the frosting showing a soft hot spot in the middle of each square, the lights
  // throwing a glow over the frame. Live: the squares light up in travelling chase patterns: a diagonal wave, then rows, while the colours swap.
  function fDisco() { const R = rng('disco31'), NC = 8, NR = 6, PAL = ['#ff8c00', '#ff4400', '#ff0080', '#8c00ff', '#ffd600', '#66ff00'];
    let s = '<rect width="80" height="56" fill="#000000"/>', glow = '';
    for (let i = 0; i < NC; i++) for (let j = 0; j < NR; j++) { const u0 = i / NC, u1 = (i + 1) / NC, y0 = j / NR * 1.04 - 0.02, y1 = (j + 1) / NR * 1.04 - 0.02, um = (u0 + u1) / 2, ym = (y0 + y1) / 2;
      const c = PAL[(i * 2 + j * 3) % PAL.length], c2 = PAL[(i * 2 + j * 3 + 2) % PAL.length], g = 0.012, ph = -((i + j) % 8) * 0.25, ph2 = -(j % 6) * 0.35;
      const tile = (col) => `<path d="${quadW(u0 + g, y0 + g, u1 - g, y1 - g)}" fill="${X.K.mix(col, '#100808', 0.1)}"/>`;
      // dim base + lit layer (two colours alternating) + hot spot
      s += tile(c);
      s += `<g opacity="0">${an('opacity', '0;1;0.15;0', 2, ph, KT('0;0.15;0.6;1'))}<path d="${quadW(u0 + g, y0 + g, u1 - g, y1 - g)}" fill="${c}"/>${dot(um, ym, 2.6, 'fill="#fff6e0" opacity="0.3" filter="url(#fb1)"')}</g>`;
      s += `<g opacity="0">${an('opacity', '0;0;1;0.2;0', 6, ph2, KT('0;0.5;0.58;0.85;1'))}<path d="${quadW(u0 + g, y0 + g, u1 - g, y1 - g)}" fill="${c2}"/>${dot(um, ym, 2.4, 'fill="#ffffff" opacity="0.25" filter="url(#fb1)"')}</g>`;
      // frosted texture
      s += `<path d="${rep(6, () => dotD(u0 + g + R() * (u1 - u0 - 2 * g), y0 + g + R() * (y1 - y0 - 2 * g), 0.12))}" fill="#ffffff" opacity="0.05"/>`;
      if ((i + j) % 3 === 0) glow += dot(um, ym, 5, `fill="${c}" opacity="0.26"`); }
    // aluminium frame grid with a bright top edge
    s += `<path d="${rep(NC + 1, i => lineW([[i / NC, -0.02], [i / NC, 1.04]])).join('')}${rep(NR + 1, j => lineW([[-0.02, j / NR * 1.04 - 0.02], [1.02, j / NR * 1.04 - 0.02]])).join('')}" stroke="#000000" stroke-width="1.1"/>`
      + `<path d="${rep(NC + 1, i => lineW([[i / NC - 0.002, -0.02], [i / NC - 0.002, 1.04]])).join('')}${rep(NR + 1, j => lineW([[-0.02, j / NR * 1.04 - 0.024], [1.02, j / NR * 1.04 - 0.024]])).join('')}" stroke="#000000" stroke-width="0.25" opacity="0"/>`;
    s += `<g filter="url(#fb3)" style="mix-blend-mode:screen">${glow}</g>`;
    s += `<g filter="url(#fb3)">${dot(0.3, 0.2, 9, 'fill="#ffffff" opacity="0"')}</g>`;
    s += `<path d="${TR}" fill="none" stroke="#141418" stroke-width="7" opacity="0.35" filter="url(#fb3)"/>`;
    return FL(s); }


  // CLB-065 PRESSURE-SENSITIVE INTERACTIVE RGB MATRIX DANCE FLOOR (T4): big panels of smoked black glass over a dense matrix of tiny LED pixels, set in
  // brushed-steel seams. Where feet land, rings of light ripple out pixel by pixel in magenta, amber and violet, and a slow warm colour wave rolls across
  // the whole floor; the glass carries soft reflections. Live: footstep ripples bloom and spread, the colour wave rolls.
  function fRGB() { const R = rng('rgb31'), NX = 46, NY = 30, CL = 'pix31';
    let s = '<rect width="80" height="56" fill="#06060a"/>', pix = '', dim = '';
    for (let j = 0; j < NY; j++) for (let i = 0; i < NX; i++) { const u = (i + 0.5) / NX, y = (j + 0.5) / NY * 1.04 - 0.02, p = W(u, y), k = K(y), r = 0.5 * k;
      pix += `<rect x="${f1(p[0] - r)}" y="${f1(p[1] - r * 0.7)}" width="${f1(2 * r)}" height="${f1(1.4 * r)}"/>`; }
    s += `<defs><clipPath id="${CL}">${pix}</clipPath></defs><g clip-path="url(#${CL})"><rect width="80" height="56" fill="#2e2438"/>`;
    // rolling warm wave
    s += `<g opacity="1"><g>${at('translate', '-90 0;90 0', 9, -4)}<rect x="0" y="0" width="30" height="56" fill="url(#rgbw31)"/></g></g>`;
    // footstep ripples (ring bands expanding)
    [[0.3, 0.35, '#ff3aa0', 0], [0.7, 0.55, '#ffb030', 1.4], [0.45, 0.78, '#a45aff', 2.6], [0.8, 0.22, '#ff5a6a', 3.8], [0.18, 0.7, '#ffd040', 5]].forEach(([u, y, c, b]) => {
      const rr = [0.6, 4, 9, 14], d = rr.map(r => dotD(u, y, r)).join(';');
      s += `<path d="${dotD(u, y, 0.6)}" fill="none" stroke="${c}" stroke-width="2.2" opacity="0">${an('d', d, 3.2, -b)}${an('opacity', '0;1;0.6;0', 3.2, -b)}</path>`
        + `<path d="${dotD(u, y, 0.6)}" fill="${c}" opacity="0">${an('opacity', '0;0.9;0;0', 3.2, -b)}</path>`; });
    s += `</g>`;
    // glass panels + steel seams + reflections
    { const FT = RD._FLAT ? 1 : 0; s += `<path d="${rep(5 + FT, i => lineW([[(i + 1 - FT) / 6, -0.02], [(i + 1 - FT) / 6, 1.04]])).join('')}${rep(3 + FT, j => lineW([[-0.02, (j + 1 - FT) / 4], [1.02, (j + 1 - FT) / 4]])).join('')}" stroke="#3a3e46" stroke-width="${FT ? 0.8 : 0.55}"/>`
      + `<path d="${rep(5 + FT, i => lineW([[(i + 1 - FT) / 6 + (FT ? 0.006 : -0.002), -0.02], [(i + 1 - FT) / 6 + (FT ? 0.006 : -0.002), 1.04]])).join('')}" stroke="#9aa0aa" stroke-width="0.15" opacity="0.5"/>`; }
    s += `<g filter="url(#fb3)"><g>${at('translate', '0 0;5 0.4;0 0', 24)}<path d="${polyW([[0.1, 0], [0.22, 0], [0.28, 0.6], [0.1, 0.6]])}" fill="#ffffff" opacity="0.07"/></g>${dot(0.55, 0.2, 10, 'fill="#ffffff" opacity="0.04"')}</g>`;
    s += `<path d="${TR}" fill="none" stroke="#000000" stroke-width="7" opacity="0.45" filter="url(#fb3)"/>`;
    return FL(`<defs><linearGradient id="rgbw31" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ff3aa0" stop-opacity="0"/><stop offset="0.3" stop-color="#ff3aa0" stop-opacity="0.8"/><stop offset="0.6" stop-color="#ffb030" stop-opacity="0.8"/><stop offset="1" stop-color="#a45aff" stop-opacity="0"/></linearGradient></defs>` + s); }

  // CLB-085 KINETIC ENERGY-HARVESTING LEVITATION & HAPTIC BASS DANCE FLOOR (T5): a honeycomb of pearl-white hexagonal pads hovering a hair above a dark
  // energy well, each pad edged in champagne gold; through the gaps a warm gold light glows from the harvesters beneath. With every bass beat a ring of pads
  // dips and lifts outward from the centre, golden energy pulses spread through the gaps and sparks run to the edge. Live: the pads ripple to the bass
  // in rings, the gaps pulse gold and sparks race outward.
  function fLev() { const R = rng('lev31'), ru = 0.058, ay = 1.25;
    let s = '<rect width="80" height="56" fill="#120a04"/>';
    // energy well glow + bass rings under the pads
    s += `<g filter="url(#fb3)">${dot(0.5, 0.5, 34, 'fill="#ffa83a" opacity="0.55"')}${dot(0.5, 0.5, 16, 'fill="#ffe0a0" opacity="0.6"')}${dot(0.15, 0.85, 14, 'fill="#ffa83a" opacity="0.35"')}${dot(0.85, 0.2, 12, 'fill="#ffa83a" opacity="0.35"')}</g>`;
    s += rep(3, i => { const d = [1, 10, 22, 34].map(r => dotD(0.5, 0.5, r)).join(';'); return `<path d="${dotD(0.5, 0.5, 1)}" fill="none" stroke="#ffd070" stroke-width="2.4" opacity="0" filter="url(#fb1)">${an('d', d, 2.4, -i * 0.8)}${an('opacity', '0;0.9;0.5;0', 2.4, -i * 0.8)}</path>`; }).join('');
    // pads (back rows first), each bobbing with a phase from its distance to the centre
    const dx = ru * 1.75, dy = ru * ay * 1.5 * 0.68;
    for (let j = -1; j * dy < 1.06; j++) for (let i = -1; i * dx < 1.06; i++) { const u = i * dx + (j % 2 ? dx / 2 : 0), y = j * dy;
      const d = Math.hypot((u - 0.5) * 1.4, y - 0.5), ph = -(d * 3.2) % 2.4, k = K(Math.max(0, Math.min(1, y)));
      const hex = hexW(u, y, ru * 0.8, ay * 0.62, PI / 6), hexI = hexW(u, y - 0.004, ru * 0.56, ay * 0.62, PI / 6);
      s += `<path d="${hexW(u, y + 0.012, ru * 0.8, ay * 0.62, PI / 6)}" fill="#000000" opacity="0.5"/><g>${at('translate', `0 0;0 ${f1(0.9 * k)};0 ${f1(-0.4 * k)};0 0`, 2.4, ph, ' calcMode="spline" keyTimes="0;0.2;0.5;1" keySplines="0.3 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1"')}<path d="${hex}" fill="#e6ddd0" stroke="#d6b26a" stroke-width="0.5"/><path d="${hexI}" fill="#f6f0e6" opacity="0.7"/><path d="${hexW(u - 0.008, y - 0.01, ru * 0.3, ay * 0.62, PI / 6)}" fill="#ffffff" opacity="0.55"/></g>`; }
    // sparks racing outward along the gaps
    s += rep(10, i => { const a = i / 10 * 2 * PI + 0.3, u1 = 0.5 + Math.cos(a) * 0.55, y1 = 0.5 + Math.sin(a) * 0.55, p0 = W(0.5, 0.5), p1 = W(u1, y1); return `<circle r="0.45" fill="#fff0b0" opacity="0">${an('cx', `${f1(p0[0])};${f1(p1[0])}`, 2.4, -i * 0.24)}${an('cy', `${f1(p0[1])};${f1(p1[1])}`, 2.4, -i * 0.24)}${an('opacity', '0;1;0', 2.4, -i * 0.24)}</circle>`; }).join('');
    s += `<g filter="url(#fb3)">${dot(0.35, 0.2, 9, 'fill="#ffffff" opacity="0.06"')}</g><path d="${TR}" fill="none" stroke="#0a0604" stroke-width="7" opacity="0.4" filter="url(#fb3)"/>`;
    return FL(s); }

  // ======================= FLOOR RUNNERS (flat 3D floor pieces: RD.H13 slab / top / face, footprints kept) =======================
  // CLB-017 STAINED GARAGE RUBBER MAT (T1): mat 120 x 72 kept. A heavy charcoal rubber garage mat with a raised coin-dot grip pattern, faded grey where it
  // has been walked on, a big oil stain with a rainbow sheen, a muddy tyre track across one end, a torn notch in the edge, sawdust and grit, a flattened
  // bottle cap and a scuffed sneaker print. Live: the oily rainbow sheen shimmers.
  N.mat31a = S => { const { slab, top, face, rrP } = RD.H13, { DEF29, RUG } = RD.H29, W0 = 108, Dd = 62, T = 1.4, A = -0.05, ca = Math.cos(A), sa = Math.sin(A), rot = ([x, z]) => [x * ca - z * sa, x * sa + z * ca];
    const P = rrP(W0, Dd, 2).map(rot), D = RUG(120, 72);
    D.fx = ctx => { const C = cam(ctx), R = rng('mat31a'), id = C.u('m17');
      let a = `<rect x="${-W0 / 2 - 2}" y="${-Dd / 2 - 2}" width="${W0 + 4}" height="${Dd + 4}" fill="#2e2e30"/>`;
      for (let x = -W0 / 2 + 3; x < W0 / 2; x += 4.2) for (let z = -Dd / 2 + 3; z < Dd / 2; z += 4.2) a += `<circle cx="${f1(x)}" cy="${f1(z)}" r="1.3" fill="#3a3a3c"/><path d="M${f1(x - 1)} ${f1(z - 0.6)}a1.3 1.3 0 0 1 2 0" stroke="#5a5a5e" stroke-width="0.35" fill="none"/>`;
      a += `<g filter="url(#m29b)"><ellipse cx="-8" cy="2" rx="30" ry="16" fill="#8a8a88" opacity="0.28"/></g>`;
      // oil stain with a shimmering rainbow sheen
      a += `<g filter="url(#m29s)"><ellipse cx="18" cy="-6" rx="13" ry="8" fill="#0e0e10" opacity="0.8"/><ellipse cx="24" cy="-2" rx="6" ry="4" fill="#0e0e10" opacity="0.7"/></g>`
        + `<g opacity="0.22" filter="url(#m29s)"><ellipse cx="18" cy="-6" rx="9" ry="5" fill="url(#${id}o)"><animateTransform attributeName="transform" type="rotate" values="0 18 -6;40 18 -6;0 18 -6" dur="7s" repeatCount="indefinite"/></ellipse></g>`;
      // muddy tyre track, torn notch shading, grit, bottle cap, sneaker print
      a += `<g opacity="0.5">` + rep(14, i => `<rect x="${-W0 / 2 + 2 + i * 4.4}" y="${Dd / 2 - 16}" width="2.6" height="10" rx="0.6" fill="#6a5640" transform="rotate(-8 0 0)"/>`).join('') + `</g>`;
      a += rep(90, () => `<circle cx="${f1((R() - 0.5) * W0)}" cy="${f1((R() - 0.5) * Dd)}" r="${f1(0.25 + R() * 0.35)}" fill="${R() < 0.5 ? '#c8a870' : '#8a8478'}" opacity="0.8"/>`).join('');
      a += `<g transform="translate(-30 -14)"><circle r="2.2" fill="#c8c4bc"/><circle r="1.6" fill="#a8342a"/>${rep(12, i => `<path d="M${f1(Math.cos(i * 0.52) * 2.2)} ${f1(Math.sin(i * 0.52) * 2.2)}l${f1(Math.cos(i * 0.52) * 0.5)} ${f1(Math.sin(i * 0.52) * 0.5)}" stroke="#a8a49c" stroke-width="0.4"/>`).join('')}</g>`;
      a += `<g transform="translate(-14 12) rotate(20)" opacity="0.4"><path d="M-2.4 -6Q0 -8 2.4 -6V4Q0 6 -2.4 4Z" fill="#8a8a86"/>${rep(5, i => `<path d="M-2 ${-5 + i * 2}H2" stroke="#4a4a48" stroke-width="0.5"/>`).join('')}</g>`;
      const art = `<g transform="rotate(${f1(A * 180 / PI)})">${a}</g>`;
      const nt = rot([W0 / 2 - 22, Dd / 2]), notch = `<path d="M${[[nt[0] - 3, T + 0.05, nt[1]], [nt[0], T + 0.05, nt[1] - 3.4], [nt[0] + 3, T + 0.05, nt[1]]].map(p => P2(C.P(p))).join('L')}Z" fill="#1a1a1c"/>`;
      const s = slab(C, P, T, '#1e1e20') + top(C, T, face(id, P, art, 0.18)) + notch;
      return { defs: DEF29 + `<defs><linearGradient id="${id}o" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff5a8a"/><stop offset="0.25" stop-color="#ffd05a"/><stop offset="0.5" stop-color="#7ad07a"/><stop offset="0.75" stop-color="#7a8aff"/><stop offset="1" stop-color="#d07aff"/></linearGradient></defs>`, front: s, bb: C.bb(6) }; };
    return D; };

  // shag / pile strokes over an area (copied from plus30): n strokes of length l in random directions, lighter tips
  const pile = (R, x0, z0, w, d, n, l, cB, cT, inside) => { let a = '', b = ''; rep(n, () => { const x = x0 + R() * w, z = z0 + R() * d; if (inside && !inside(x, z)) return; const t = R() * 6.3, L = l * (0.6 + R() * 0.7), dx = Math.cos(t) * L, dz = Math.sin(t) * L * 0.8 - L * 0.35;
      a += `M${f1(x)} ${f1(z)}l${f1(dx)} ${f1(dz)}`; b += `M${f1(x + dx * 0.6)} ${f1(z + dz * 0.6)}l${f1(dx * 0.4)} ${f1(dz * 0.4)}`; }); return `<path d="${a}" stroke="${cB}" stroke-width="0.7" stroke-linecap="round" fill="none"/><path d="${b}" stroke="${cT}" stroke-width="0.5" stroke-linecap="round" fill="none"/>`; };
  const fringe = (R, x0, z0, z1, sd, len, col, dk) => { let f = ''; for (let z = z0; z < z1; z += 1.3) f += `M${f1(x0)} ${f1(z)}q${f1(sd * len * 0.5)} ${f1((R() - 0.5) * 1.4)} ${f1(sd * (len + R() * 1.6))} ${f1((R() - 0.5) * 1.6)}`; return `<path d="${f}" stroke="${col}" stroke-width="0.6" fill="none" stroke-linecap="round"/><path d="${f}" stroke="${dk}" stroke-width="0.18" fill="none" opacity="0.5"/>`; };

  // CLB-037 UV-REACTIVE NEON SPLATTER CARPET RUNNER (T2): runner 250 x 70 kept. A cheap black low-pile carpet runner flicked and spattered with UV paint in
  // hot pink, highlighter yellow, tangerine and lime: big splats with satellite droplets, flick lines and a couple of drips, bound with a neon pink edge
  // tape, the pile scuffed grey down the middle. Live: the blacklight pulses and the splatters glow brighter and dimmer with it.
  N.run31a = S => { const { slab, top, face, rrP } = RD.H13, { DEF29, RUG } = RD.H29, W0 = 236, Dd = 58, T = 0.8, P = rrP(W0, Dd, 1.5), D = RUG(250, 70);
    D.fx = ctx => { const C = cam(ctx), R = rng('run31a'), id = C.u('r37');
      let a = `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="#141418"/>` + pile(R, -W0 / 2, -Dd / 2, W0, Dd, 2600, 0.8, '#202026', '#2c2c34');
      a += `<g filter="url(#m29b)"><rect x="${-W0 / 2 + 20}" y="-8" width="${W0 - 40}" height="16" rx="8" fill="#5a5a62" opacity="0.25"/></g>`;
      const NE = ['#ff3aa8', '#f2ff3a', '#ff8a2a', '#7aff4a'];
      let sp = ''; rep(16, i => { const c = NE[i % 4], x = (R() - 0.5) * (W0 - 20), z = (R() - 0.5) * (Dd - 12), r = 3 + R() * 6;
        let d = 'M'; rep(12, j => { const t = j / 12 * 2 * PI, rr = r * (0.7 + R() * 0.5); d += `${f1(x + Math.cos(t) * rr)} ${f1(z + Math.sin(t) * rr * 0.8)}${j < 11 ? 'L' : 'Z'}`; });
        sp += `<path d="${d}" fill="${c}" stroke="${c}" stroke-width="1.4" stroke-linejoin="round"/>` + rep(7, () => { const t = R() * 2 * PI, dd = r * (1.3 + R() * 1.4); return `<circle cx="${f1(x + Math.cos(t) * dd)}" cy="${f1(z + Math.sin(t) * dd * 0.8)}" r="${f1(0.4 + R() * 1)}" fill="${c}"/>`; }).join('')
          + (R() < 0.5 ? `<path d="M${f1(x)} ${f1(z)}l${f1((R() - 0.5) * 30)} ${f1((R() - 0.5) * 14)}" stroke="${c}" stroke-width="${f1(0.6 + R())}" stroke-linecap="round"/>` : ''); });
      a += `<g opacity="0.85">${an('opacity', '0.65;1;0.75;1;0.65', 3.4)}<g filter="url(#m29s)" opacity="0.6">${sp}</g>${sp}</g>`;
      a += `<rect x="${-W0 / 2 + 1}" y="${-Dd / 2 + 1}" width="${W0 - 2}" height="${Dd - 2}" fill="none" stroke="#ff3aa8" stroke-width="2"/><rect x="${-W0 / 2 + 1}" y="${-Dd / 2 + 1}" width="${W0 - 2}" height="${Dd - 2}" fill="none" stroke="#ffa8d8" stroke-width="0.5"/>`;
      const glow = top(C, 0.05, `<g filter="url(#m29b)" opacity="0.45">${an('opacity', '0.3;0.55;0.35;0.55;0.3', 3.4)}<rect x="${-W0 / 2 - 4}" y="${-Dd / 2 - 4}" width="${W0 + 8}" height="${Dd + 8}" rx="6" fill="#a050ff" opacity="0.4"/></g>`);
      const s = glow + slab(C, P, T, '#ff3aa8') + top(C, T, face(id, P, a, 0.12));
      return { defs: DEF29, front: s, bb: C.bb(8) }; };
    return D; };

  // CLB-057 PLUSH LEOPARD-PRINT LOUNGE RUG (T3): rug 200 x 130 kept. A deep plush faux-fur rug in a warm honey-gold leopard print: broken black rosettes with
  // amber centres and scattered spots, a dense soft pile with lighter tips, softly rounded corners and a slight curl of fur over the edge.
  // Live: a soft sheen glides through the plush.
  N.run31b = S => { const { slab, top, face, rrP } = RD.H13, { DEF29, RUG } = RD.H29, W0 = 184, Dd = 116, T = 2.2, P = rrP(W0, Dd, 10), D = RUG(200, 130);
    D.fx = ctx => { const C = cam(ctx), R = rng('run31b'), id = C.u('r57');
      let a = `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="#d8a458"/>`;
      a += `<g filter="url(#m29b)">` + rep(14, () => `<ellipse cx="${f1((R() - 0.5) * W0)}" cy="${f1((R() - 0.5) * Dd)}" rx="${f1(10 + R() * 14)}" ry="${f1(6 + R() * 8)}" fill="${R() < 0.5 ? '#e8bc70' : '#c48e44'}" opacity="0.5"/>`).join('') + `</g>`;
      let ro = ''; for (let x = -W0 / 2 + 8; x < W0 / 2; x += 19) for (let z = -Dd / 2 + 8; z < Dd / 2; z += 16) { const cx = x + (R() - 0.5) * 10 + ((Math.round(z / 16)) % 2 ? 9 : 0), cz = z + (R() - 0.5) * 7, r = 3.6 + R() * 2;
        if (R() < 0.75) { ro += `<ellipse cx="${f1(cx)}" cy="${f1(cz)}" rx="${f1(r * 0.75)}" ry="${f1(r * 0.6)}" fill="#a8681e"/>`; rep(4 + (R() * 2 | 0), j => { const t = j / 5 * 2 * PI + R() * 0.4; ro += `<ellipse cx="${f1(cx + Math.cos(t) * r)}" cy="${f1(cz + Math.sin(t) * r * 0.85)}" rx="${f1(1.4 + R() * 0.8)}" ry="${f1(0.9 + R() * 0.5)}" transform="rotate(${f1(t * 57 + 90)} ${f1(cx + Math.cos(t) * r)} ${f1(cz + Math.sin(t) * r * 0.85)})" fill="#1e140c"/>`; }); }
        else ro += `<circle cx="${f1(cx)}" cy="${f1(cz)}" r="${f1(1.2 + R())}" fill="#1e140c"/>`; }
      a += ro + pile(R, -W0 / 2, -Dd / 2, W0, Dd, 3800, 1.4, '#b88440', '#f2d090');
      a += `<g opacity="0.5">${at('translate', `${-W0} 0;${W0} 0`, 9)}<rect x="0" y="${-Dd / 2}" width="40" height="${Dd}" fill="url(#${id}s)" transform="skewX(-20)"/></g>`;
      const edge = top(C, 0.05, (() => { let f = ''; P.forEach((p, j) => { const q = P[(j + 1) % P.length]; rep(3, n => { const t = n / 3, x = p[0] + (q[0] - p[0]) * t, z = p[1] + (q[1] - p[1]) * t, L = Math.hypot(x, z) || 1; f += `M${f1(x)} ${f1(z)}q${f1(x / L * 1.4)} ${f1(z / L * 1)} ${f1(x / L * 2.6 + (R() - 0.5))} ${f1(z / L * 2 + (R() - 0.5))}`; }); }); return `<path d="${f}" stroke="#d8a458" stroke-width="0.9" fill="none" stroke-linecap="round"/>`; })());
      const s = edge + slab(C, P, T, '#b88440') + top(C, T, face(id, P, a, 0.14));
      return { defs: DEF29 + `<defs><linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff2d0" stop-opacity="0"/><stop offset="0.5" stop-color="#fff2d0" stop-opacity="0.45"/><stop offset="1" stop-color="#fff2d0" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(8) }; };
    return D; };

  // CLB-077 METALLIC SILVER-THREAD & BLACK VELVET VIP CARPET (T4): runner 250 x 70 kept. A deep black velvet runner embroidered in metallic silver thread:
  // an art-deco border of stepped chevrons and sunburst fans down the length, a fine double guard line, a silver bullion-bound edge and silver tassels at
  // both ends; the velvet shows crush marks where the nap was brushed the other way. Live: a glint travels along the silver threads and the velvet sheen shifts.
  N.run31c = S => { const { slab, top, face, rrP } = RD.H13, { DEF29, RUG } = RD.H29, W0 = 230, Dd = 58, T = 1.4, P = rrP(W0, Dd, 1.2), D = RUG(250, 70);
    D.fx = ctx => { const C = cam(ctx), R = rng('run31c'), id = C.u('r77'), SV = '#d8dce2';
      let a = `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="#0e0e12"/>` + pile(R, -W0 / 2, -Dd / 2, W0, Dd, 1600, 0.6, '#16161c', '#24242c');
      a += `<g filter="url(#m29b)">` + rep(6, () => `<ellipse cx="${f1((R() - 0.5) * W0)}" cy="${f1((R() - 0.5) * Dd * 0.6)}" rx="${f1(10 + R() * 16)}" ry="${f1(4 + R() * 5)}" fill="#3a3a46" opacity="0.5"/>`).join('') + `</g>`;
      let dc = `<rect x="${-W0 / 2 + 3}" y="${-Dd / 2 + 3}" width="${W0 - 6}" height="${Dd - 6}" fill="none" stroke="${SV}" stroke-width="0.6"/><rect x="${-W0 / 2 + 5}" y="${-Dd / 2 + 5}" width="${W0 - 10}" height="${Dd - 10}" fill="none" stroke="${SV}" stroke-width="0.25"/>`;
      for (let x = -W0 / 2 + 14; x < W0 / 2 - 10; x += 20) { dc += `<g transform="translate(${x} 0)"><path d="M-6 -8L0 -14L6 -8M-4 -8L0 -12L4 -8M-6 8L0 14L6 8M-4 8L0 12L4 8" stroke="${SV}" stroke-width="0.45" fill="none"/>` + rep(7, j => { const t = PI + j * PI / 6; return `<path d="M0 0L${f1(Math.cos(t) * 6)} ${f1(Math.sin(t) * 6)}M0 0L${f1(Math.cos(t) * 6)} ${f1(-Math.sin(t) * 6)}" stroke="${SV}" stroke-width="0.3"/>`; }).join('') + `<circle r="1.4" fill="${SV}"/><path d="M10 -18V18" stroke="${SV}" stroke-width="0.25" stroke-dasharray="1 1"/></g>`; }
      a += dc + `<g opacity="0.9">${at('translate', `${-W0} 0;${W0} 0`, 6)}<rect x="0" y="${-Dd / 2}" width="16" height="${Dd}" fill="url(#${id}g)" transform="skewX(-25)"/></g>`;
      a += `<g opacity="0.35">${at('translate', `${W0 * 0.4} 0;${-W0 * 0.4} 0;${W0 * 0.4} 0`, 14, 0, SPL(2))}<ellipse cx="0" cy="0" rx="40" ry="${Dd / 2}" fill="url(#${id}v)"/></g>`;
      const tas = top(C, 0.05, [-1, 1].map(sd => rep(5, i => { const z = -Dd / 2 + 7 + i * (Dd - 14) / 4, x = sd * W0 / 2; return `<path d="M${f1(x)} ${f1(z)}h${sd * 3}" stroke="${SV}" stroke-width="0.5"/><path d="M${f1(x + sd * 3)} ${f1(z - 1.2)}L${f1(x + sd * 8)} ${f1(z - 2)}L${f1(x + sd * 8)} ${f1(z + 2)}L${f1(x + sd * 3)} ${f1(z + 1.2)}Z" fill="${SV}"/><path d="M${f1(x + sd * 5)} ${f1(z - 1.4)}V${f1(z + 1.4)}" stroke="#8a8e96" stroke-width="0.3"/>`; }).join('')).join(''));
      const s = tas + slab(C, P, T, '#a8acb4') + top(C, T, face(id, P, a, 0.1));
      return { defs: DEF29 + `<defs><linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.55"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient><radialGradient id="${id}v" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#6a6a7a" stop-opacity="0.6"/><stop offset="1" stop-color="#6a6a7a" stop-opacity="0"/></radialGradient></defs>`, front: s, bb: C.bb(8) }; };
    return D; };

  // CLB-097 FIBER-OPTIC BEAT-SYNCED WAVEFORM LOUNGE TAPESTRY (T5): rug 200 x 130 kept. A deep midnight-plum plush rug woven through with fibre-optic strands:
  // a long audio waveform of glowing bars runs down its length in a warm gradient from rose to amber to gold, framed by two thin light lines, and the cut
  // fibre ends sparkle through the pile like stars. Live: the waveform bars bounce to the beat, the frame lines pulse and fibre tips twinkle.
  N.run31d = S => { const { slab, top, face, rrP } = RD.H13, { DEF29, RUG } = RD.H29, W0 = 184, Dd = 116, T = 2.6, P = rrP(W0, Dd, 8), D = RUG(200, 130);
    D.fx = ctx => { const C = cam(ctx), R = rng('run31d'), id = C.u('r97');
      let a = `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="#1e1426"/>` + pile(R, -W0 / 2, -Dd / 2, W0, Dd, 3000, 1, '#281a32', '#3a2a46');
      const NB = 46, bw = (W0 - 28) / NB;
      let bars = ''; for (let i = 0; i < NB; i++) { const x = -W0 / 2 + 14 + i * bw, env = 0.35 + 0.65 * Math.sin(i / NB * PI), h0 = 6 + env * 26 * (0.4 + R() * 0.6), h1 = 4 + env * 30 * R(), h2 = 6 + env * 34 * (0.5 + R() * 0.5), T0 = 0.9 + (i % 5) * 0.07;
        bars += `<rect x="${f1(x)}" y="${f1(-h0 / 2)}" width="${f1(bw * 0.55)}" height="${f1(h0)}" rx="${f1(bw * 0.27)}" fill="url(#${id}w)">${an('height', `${f1(h0)};${f1(h2)};${f1(h1)};${f1(h0)}`, T0, -i * 0.05)}${an('y', `${f1(-h0 / 2)};${f1(-h2 / 2)};${f1(-h1 / 2)};${f1(-h0 / 2)}`, T0, -i * 0.05)}</rect>`; }
      a += `<g filter="url(#m29s)" opacity="0.7">${bars}</g>${bars}`;
      a += [-1, 1].map(sd => `<path d="M${-W0 / 2 + 10} ${sd * (Dd / 2 - 10)}H${W0 / 2 - 10}" stroke="#ffb870" stroke-width="0.7" opacity="0.7">${an('opacity', '0.4;0.95;0.4', 0.9)}</path>`).join('');
      a += rep(90, () => { const x = (R() - 0.5) * W0 * 0.96, z = (R() - 0.5) * Dd * 0.96, T0 = 1.5 + R() * 3; return `<circle cx="${f1(x)}" cy="${f1(z)}" r="${f1(0.3 + R() * 0.3)}" fill="${R() < 0.5 ? '#ffd8a0' : '#ffb0c8'}" opacity="0">${an('opacity', '0;1;0', T0, -R() * T0)}</circle>`; }).join('');
      const glow = top(C, 0.05, `<g filter="url(#m29b)" opacity="0.4">${an('opacity', '0.3;0.5;0.3', 0.9)}<rect x="${-W0 / 2 - 3}" y="${-Dd / 2 - 3}" width="${W0 + 6}" height="${Dd + 6}" rx="10" fill="#ff9a6a" opacity="0.35"/></g>`);
      const s = glow + slab(C, P, T, '#2a1c34') + top(C, T, face(id, P, a, 0.1));
      return { defs: DEF29 + `<defs><linearGradient id="${id}w" x1="0" y1="0" x2="1" y2="0" gradientUnits="userSpaceOnUse" x1="${-W0 / 2}" x2="${W0 / 2}"><stop offset="0" stop-color="#ff6aa8"/><stop offset="0.5" stop-color="#ffa860"/><stop offset="1" stop-color="#ffe08a"/></linearGradient></defs>`.replace(' x1="0" y1="0" x2="1" y2="0" gradientUnits', ' y1="0" y2="0" gradientUnits'), front: s, bb: C.bb(8) }; };
    return D; };

  // ======================= WALLS (r.s12 80 x 56 tiles registered into RD.H12.SURF12, same pipeline as the Bedroom walls in plus30) =======================
  const WMEMO31 = {};
  { const { blot, BB, SURF12 } = RD.H12;
    const memo = (k, f) => () => WMEMO31[k] || (WMEMO31[k] = f());
    const stip = (R, n, y0, y1, a, b, o0, o1) => { let s = ''; rep(n, () => s += `<circle cx="${f1(R() * 80)}" cy="${f1(y0 + R() * (y1 - y0))}" r="${f1(0.07 + R() * 0.12)}" fill="${R() < 0.5 ? a : b}" opacity="${f1(o0 + R() * o1)}"/>`); return s; };
    const wrap = g => `<g transform="translate(-80 0)">${g}</g>${g}<g transform="translate(80 0)">${g}</g>`;

    // CLB-001 CINDERBLOCK WALLS WITH GRAFFITI TAGS & FOIL SHEETS (T1): grey-painted cinderblock in running bond, the paint thin over the pitted block
    // face, deep raked mortar joints, damp tide marks and white efflorescence near the floor, rust streaks under an old bracket; spray-paint tags and
    // throw-ups in hot pink, yellow and violet with drips and white outlines, and sheets of crinkled kitchen foil taped up with silver duct tape to bounce
    // the light, a stapled party flyer, a scuffed black base. Live: the foil glints as coloured light passes and a loose foil corner flutters.
    const wBlock = memo('c01', () => { const R = rng('wc01'), BW = 16, BH = 7.6;
      let up = '<rect width="80" height="56" fill="#8e8c88"/>';
      for (let r = 0; r * BH < BB + BH; r++) for (let c = -1; c < 6; c++) { const x = c * BW + (r % 2 ? BW / 2 : 0), y = r * BH, col = shade('#9a9894', 0.92 + R() * 0.14);
        up += `<rect x="${f1(x + 0.5)}" y="${f1(y + 0.5)}" width="${BW - 1}" height="${f1(BH - 1)}" fill="${col}"/><rect x="${f1(x + 0.5)}" y="${f1(y + 0.5)}" width="${BW - 1}" height="0.5" fill="#b8b6b0" opacity="0.6"/><rect x="${f1(x + 0.5)}" y="${f1(y + BH - 1)}" width="${BW - 1}" height="0.5" fill="#5a5854" opacity="0.5"/>`; }
      up += stip(R, 900, 0, BB, '#6e6c66', '#bab8b0', 0.3, 0.4) + blot('wc01', 24, ['#a8a6a0', '#7a7872', '#8a8882'], 0.25, 4);
      let s = up;
      s += '<g filter="url(#wb1)">' + rep(6, () => { const x = R() * 80; return `<path d="M${f1(x)} ${f1(BB - 14 - R() * 6)}Q${f1(x + 2)} ${f1(BB - 6)} ${f1(x + (R() - 0.5) * 4)} ${BB}" stroke="#6a6a64" stroke-width="${f1(1.4 + R() * 2)}" fill="none" opacity="0.35"/>`; }).join('')
        + `<rect y="${f1(BB - 8)}" width="80" height="8" fill="#f2f0e8" opacity="0.14"/></g>` + '<path d="M61 6v1.6h3V6" stroke="#4a4844" stroke-width="0.7" fill="none"/><g filter="url(#wb1)"><path d="M62.5 8Q63 14 62.2 22" stroke="#9a5a2a" stroke-width="1" opacity="0.45" fill="none"/></g>';
      // foil sheets (crinkled), taped corners; one corner flutters
      const foil = (x, y, w, h, rot, id2) => { let f = `<g transform="rotate(${rot} ${x + w / 2} ${y + h / 2})"><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#c01f)"/>`;
        rep(26, () => { const px = x + R() * w, py = y + R() * h; f += `<path d="M${f1(px)} ${f1(py)}l${f1((R() - 0.5) * 5)} ${f1((R() - 0.5) * 4)}l${f1((R() - 0.5) * 4)} ${f1((R() - 0.5) * 3)}" stroke="${R() < 0.5 ? '#ffffff' : '#7a7e86'}" stroke-width="0.18" fill="none" opacity="0.7"/>`; });
        f += `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#c01g)" opacity="0.8"><animate attributeName="x" values="${x - w};${x + w}" dur="5s" begin="${-id2 * 1.7}s" repeatCount="indefinite"/></rect>`;
        [[x - 1, y - 1], [x + w - 3, y - 1], [x - 1, y + h - 1.6], [x + w - 3, y + h - 1.6]].forEach(([tx, ty]) => f += `<rect x="${f1(tx)}" y="${f1(ty)}" width="4" height="2.6" fill="#b8bcc0" opacity="0.95"/><rect x="${f1(tx)}" y="${f1(ty)}" width="4" height="0.6" fill="#e2e6ea"/>`);
        return f + '</g>'; };
      s += foil(4, 6, 20, 27, -2, 0) + foil(48, 3, 17, 22, 1.5, 1);
      s += `<g transform="translate(65 25)"><path d="M0 0L3.6 0.6L0.4 4Z" fill="#c8ccd2" stroke="#8a8e94" stroke-width="0.12"><animate attributeName="d" values="M0 0L3.6 0.6L0.4 4Z;M0 0L3 1.8L1.2 3.6Z;M0 0L3.6 0.6L0.4 4Z" dur="2.4s" repeatCount="indefinite" ${SPL(2)}/></path></g>`;
      // graffiti: a bubble throw-up (abstract letter blobs), a tag scrawl, drips
      // bubble-letter throw-up: four fat rounded letter blocks (holes, notches) with a violet 3D drop, black + white outlines, shine and drips
      const L1 = (x, y, w, h, kind) => { const r = Math.min(w, h) * 0.42; let d = `M${x + r} ${y}H${x + w - r}Q${x + w} ${y} ${x + w} ${y + r}V${y + h - r}Q${x + w} ${y + h} ${x + w - r} ${y + h}H${x + r}Q${x} ${y + h} ${x} ${y + h - r}V${y + r}Q${x} ${y} ${x + r} ${y}Z`;
        if (kind === 'o') d += `M${x + w / 2} ${y + h * 0.3}a${w * 0.16} ${h * 0.2} 0 1 0 0.01 0Z`;
        if (kind === 'b') d += `M${x + w * 0.35} ${y + h * 0.22}h${w * 0.2}v${h * 0.16}h${-w * 0.2}ZM${x + w * 0.35} ${y + h * 0.58}h${w * 0.24}v${h * 0.16}h${-w * 0.24}Z`;
        if (kind === 'n') d += `M${x + w * 0.42} ${y + h}V${y + h * 0.45}Q${x + w * 0.5} ${y + h * 0.38} ${x + w * 0.58} ${y + h * 0.45}V${y + h}Z`;
        return d; };
      const LT = [[22, 30, 10, 12, 'n', '#ff4fa8'], [30.6, 29, 9.4, 13, 'b', '#f2e23a'], [38.8, 30.4, 10, 11.6, 'n', '#ff8a3a'], [47.6, 29.4, 9.6, 12.8, 'b', '#a45aff']];
      let gr = '';
      LT.forEach(([x, y, w, h, kd]) => gr += `<path d="${L1(x + 1.2, y + 1.4, w, h, kd)}" fill="#3a1a4a" fill-rule="evenodd" stroke="#0e0a10" stroke-width="1.6" stroke-linejoin="round"/>`);
      LT.forEach(([x, y, w, h, kd, c]) => gr += `<path d="${L1(x, y, w, h, kd)}" fill="${c}" fill-rule="evenodd" stroke="#0e0a10" stroke-width="1.6" stroke-linejoin="round"/><path d="${L1(x, y, w, h, kd)}" fill="none" stroke="#ffffff" stroke-width="0.45" stroke-linejoin="round"/><path d="M${x + 1.6} ${y + 2.6}q1 -1.4 2.6 -1.2" stroke="#ffffff" stroke-width="0.8" fill="none" stroke-linecap="round" opacity="0.8"/>`
        + `<path d="M${x + w * 0.3} ${y + h}v${2 + (x % 3)}" stroke="${c}" stroke-width="0.7"/><circle cx="${x + w * 0.3}" cy="${y + h + 2.3 + (x % 3)}" r="0.45" fill="${c}"/>`);
      gr += `<path d="M66 14q2 -4 3 0t3 0q1 -5 3 -1M67 17h8" stroke="#1a1a1e" stroke-width="0.7" fill="none" stroke-linecap="round"/><path d="M6 42q2 -4 4 -1t3 -2l2 3q1 -3 3 0" stroke="#ff4fa8" stroke-width="0.8" fill="none" stroke-linecap="round"/><path d="M12 44.6h8" stroke="#ff4fa8" stroke-width="0.4"/>`;
      s += gr + '<g filter="url(#wb1)" opacity="0.4"><ellipse cx="40" cy="36" rx="22" ry="9" fill="#ff4fa8" opacity="0.12"/></g>';
      // stapled flyer
      s += '<g transform="rotate(4 32 12)"><rect x="28" y="6" width="8" height="11" fill="#f2e8d0"/><rect x="29" y="7" width="6" height="5" fill="#2a1a3a"/><circle cx="32" cy="9.5" r="1.6" fill="#ff8a3a"/><path d="M29 13.6h6M29 15h4" stroke="#3a2a2a" stroke-width="0.4"/><path d="M28.6 6.6h1M34.6 6.6h1" stroke="#8a8e94" stroke-width="0.3"/></g>';
      const board = '#2a2a2c';
      return { mat: s, sup: up, board,
        defs: '<linearGradient id="c01f" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e8ecf0"/><stop offset="0.3" stop-color="#a8acb4"/><stop offset="0.55" stop-color="#f2f4f6"/><stop offset="0.8" stop-color="#9a9ea6"/><stop offset="1" stop-color="#d8dce2"/></linearGradient>'
          + '<linearGradient id="c01g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ff6ac8" stop-opacity="0"/><stop offset="0.5" stop-color="#ffd0f0" stop-opacity="0.8"/><stop offset="1" stop-color="#ff6ac8" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.04, ao: 0.2, board: `<rect y="${f1(BB + 0.3)}" width="80" height="0.3" fill="#5a5a5e" opacity="0.6"/>` + stip(rng('c01b'), 40, BB + 0.5, 56, '#8a8a8a', '#1a1a1a', 0.2, 0.3) } }; });

    // CLB-021 BLACK ACOUSTIC FOAM PYRAMID PANELS (T2): the walls lined edge to edge with square charcoal acoustic foam panels, each a 4 x 4 field of soft
    // pyramids whose faces catch the light differently, glued up a little crooked with gaps, one panel's corner peeling off its glue dab, dust on the tips,
    // and a strip of black rubber skirting. Live: a coloured party-light wash slowly sweeps across, picking out the pyramid relief.
    const wFoam = memo('c21', () => { const R = rng('wc21'), PS = 13.3;
      let up = '<rect width="80" height="56" fill="#0e0e10"/>';
      for (let r = 0; r * PS < BB; r++) for (let c = 0; c < 6; c++) { const x0 = c * PS + (R() - 0.5) * 0.4, y0 = r * PS + (R() - 0.5) * 0.4, n = 4, q = (PS - 0.6) / n;
        for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { const x = x0 + 0.3 + i * q, y = y0 + 0.3 + j * q, cx = x + q / 2, cy = y + q / 2;
          up += `<path d="M${f1(x)} ${f1(y)}L${f1(x + q)} ${f1(y)}L${f1(cx)} ${f1(cy)}Z" fill="#3a3a3e"/><path d="M${f1(x)} ${f1(y)}L${f1(x)} ${f1(y + q)}L${f1(cx)} ${f1(cy)}Z" fill="#2c2c30"/><path d="M${f1(x + q)} ${f1(y)}L${f1(x + q)} ${f1(y + q)}L${f1(cx)} ${f1(cy)}Z" fill="#18181a"/><path d="M${f1(x)} ${f1(y + q)}L${f1(x + q)} ${f1(y + q)}L${f1(cx)} ${f1(cy)}Z" fill="#121214"/><circle cx="${f1(cx)}" cy="${f1(cy)}" r="0.22" fill="#5a5a60" opacity="0.7"/>`; } }
      up += stip(R, 300, 0, BB, '#4a4a50', '#0a0a0c', 0.2, 0.3);
      let s = up + '<path d="M53.2 26.6L58 26.6L53.2 31.4Z" fill="#2a2a2e"/><path d="M53.2 26.6L58 26.6L53.6 30.8Z" fill="#0a0a0c" opacity="0.5" transform="translate(0.8 0.8)"/><circle cx="54.6" cy="27.8" r="0.9" fill="#d8d0b8" opacity="0.6"/>';
      s += `<g style="mix-blend-mode:screen" opacity="0.85"><rect x="-40" y="0" width="40" height="56" fill="url(#c21w)"><animate attributeName="x" values="-40;80" dur="9s" repeatCount="indefinite"/></rect><rect x="-40" y="0" width="30" height="56" fill="url(#c21v)"><animate attributeName="x" values="-40;80" dur="9s" begin="-4.5s" repeatCount="indefinite"/></rect></g>`;
      const board = '#141416';
      return { mat: s, sup: s, board,
        defs: '<linearGradient id="c21w" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ff3aa0" stop-opacity="0"/><stop offset="0.5" stop-color="#ff3aa0" stop-opacity="0.38"/><stop offset="1" stop-color="#ff3aa0" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="c21v" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffaa40" stop-opacity="0"/><stop offset="0.5" stop-color="#ffaa40" stop-opacity="0.3"/><stop offset="1" stop-color="#ffaa40" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.03, ao: 0.22, board: `<rect y="${f1(BB + 0.3)}" width="80" height="0.3" fill="#3a3a3e" opacity="0.8"/>` } }; });

    // CLB-041 BRICK WALLS WITH NEON TUBE ACCENT STRIPS (T3): warm red-brown brick in running bond, every brick its own shade, sanded mortar slightly
    // recessed, a few chipped arrises and soot-dark headers, the lower course painted matt black; two real glass neon tubes run along it on clear clips, a
    // straight hot-pink line high up and an amber wave lower down, their feed cables dropping to a transformer box, each throwing a soft glow on the brick.
    // Live: the neon hums with a faint flicker and the glow breathes on the brick.
    const wBrick = memo('c41', () => { const R = rng('wc41'), BW = 10, BH = 3.6;
      let up = '<rect width="80" height="56" fill="#b8a898"/>';
      for (let r = 0; r * BH < BB; r++) for (let c = -1; c < 9; c++) { const x = c * BW + (r % 2 ? BW / 2 : 0), y = r * BH, col = shade(['#9a4a32', '#a85a3a', '#8a3e2a', '#b0603e', '#7e3a28'][(R() * 5) | 0], 0.9 + R() * 0.2);
        up += `<rect x="${f1(x + 0.35)}" y="${f1(y + 0.35)}" width="${BW - 0.7}" height="${f1(BH - 0.7)}" fill="${col}"/><rect x="${f1(x + 0.35)}" y="${f1(y + 0.35)}" width="${BW - 0.7}" height="0.3" fill="#ffffff" opacity="0.12"/>`
          + (R() < 0.25 ? `<rect x="${f1(x + 1 + R() * 6)}" y="${f1(y + 0.8)}" width="${f1(1 + R() * 2)}" height="${f1(1 + R())}" fill="#3a1e14" opacity="0.25"/>` : ''); }
      up += stip(R, 800, 0, BB, '#5a2a1a', '#d8a888', 0.15, 0.3);
      let s = up + `<rect y="${f1(BB - 7.2)}" width="80" height="7.2" fill="#18161a" opacity="0.92"/>`;
      // neon: pink straight line + amber wave, glass tubes with glow, clips, cable
      const tube = (d, c, w, id2) => `<g><path d="${d}" stroke="${c}" stroke-width="${w * 6}" fill="none" opacity="0.18" filter="url(#wb2)">${an('opacity', '0.14;0.22;0.14', 3, -id2, SPL(2))}</path><path d="${d}" stroke="${c}" stroke-width="${w * 2.4}" fill="none" opacity="0.5" filter="url(#wb1)"/>`
        + `<path d="${d}" stroke="${c}" stroke-width="${w}" fill="none" stroke-linecap="round">${an('opacity', '1;1;0.82;1;1;0.9;1', 4.2, -id2 * 1.3, KT('0;0.4;0.42;0.44;0.8;0.81;1'))}</path><path d="${d}" stroke="#ffffff" stroke-width="${f1(w * 0.35)}" fill="none" stroke-linecap="round" opacity="0.85"/></g>`;
      const pink = 'M-2 12H82', amb = 'M-2 36' + rep(8, i => `Q${f1(i * 10 + 3)} ${i % 2 ? 40 : 32} ${f1(i * 10 + 8)} 36`).join('') + 'H82';
      s += tube(pink, '#ff3aa8', 1, 0) + tube(amb, '#ffaa3a', 1, 1);
      s += [6, 26, 46, 66].map(x => `<rect x="${x}" y="10.6" width="1.4" height="2.8" rx="0.3" fill="#e8f0f4" opacity="0.6"/>`).join('') + [8, 28, 48, 68].map(x => `<rect x="${x}" y="34.6" width="1.4" height="2.8" rx="0.3" fill="#e8f0f4" opacity="0.6"/>`).join('');
      s += '<path d="M74 12.6V30M75 36.8V40" stroke="#1a1a1c" stroke-width="0.5"/><rect x="72.4" y="40" width="5" height="4" rx="0.4" fill="#3a3a3e"/><rect x="72.8" y="40.4" width="1.4" height="0.8" fill="#8a8a8a"/>';
      const board = '#141216';
      return { mat: s, sup: up + `<rect y="${f1(BB - 7.2)}" width="80" height="7.2" fill="#18161a" opacity="0.92"/>`, board, defs: '',
        ro: { top: 0.04, ao: 0.2, board: `<rect y="${f1(BB + 0.3)}" width="80" height="0.3" fill="#3a3238" opacity="0.8"/>` } }; });

    // CLB-061 3D GEOMETRIC MIRROR-TILE & SOUND-REACTIVE LED MATRIX WALLS (T4): the upper wall clad in faceted champagne-tinted mirror tiles, triangles
    // tilted at different angles so each catches the room differently (warm club lights, dark ceiling, a sparkle), framed by a slim brushed-bronze
    // rail; below it a band of black glass hiding an LED matrix where a sound-reactive equaliser dances in warm pixel bars, then a dark plinth.
    // Live: the equaliser bars bounce to the music and sparkles flash across the mirror facets.
    const wMirror = memo('c61', () => { const R = rng('wc61'), TS = 8, Y1 = 30;
      let s = '<rect width="80" height="56" fill="#1a1618"/>';
      const MC = ['#d8c8b4', '#a89888', '#e8dccc', '#7a6a62', '#c4a890', '#f0e4d4', '#5a4a48', '#b89a8a'];
      for (let r = 0; r * TS < Y1; r++) for (let c = 0; c < 10; c++) { const x = c * TS, y = r * TS, up = (r + c) % 2 === 0;
        const t1 = up ? `M${x} ${y}L${x + TS} ${y}L${x} ${y + TS}Z` : `M${x} ${y}L${x + TS} ${y}L${x + TS} ${y + TS}Z`, t2 = up ? `M${x + TS} ${y}L${x + TS} ${y + TS}L${x} ${y + TS}Z` : `M${x} ${y}L${x} ${y + TS}L${x + TS} ${y + TS}Z`;
        [t1, t2].forEach(t => { s += `<path d="${t}" fill="url(#c61m${(R() * 6) | 0})" stroke="#1a1412" stroke-width="0.35"/>`; if (R() < 0.22) s += `<path d="${t}" fill="${['#ff6aa8', '#ffb050', '#c08aff'][(R() * 3) | 0]}" opacity="0.22"/>`; }); }
      s += `<rect width="80" height="${Y1}" fill="url(#c61g)"/>`;
      s += rep(9, i => { const x = 2 + R() * 76, y = 2 + R() * (Y1 - 4); return `<path d="M${f1(x - 1.4)} ${f1(y)}H${f1(x + 1.4)}M${f1(x)} ${f1(y - 1.4)}V${f1(y + 1.4)}" stroke="#ffffff" stroke-width="0.25" stroke-linecap="round" opacity="0">${an('opacity', '0;0;1;0;0', 3 + (i % 3), -i * 0.6, KT('0;0.6;0.66;0.74;1'))}</path>`; }).join('');
      s += `<rect y="${Y1}" width="80" height="1.2" fill="url(#c61r)"/>`;
      // LED matrix band with an equaliser
      const LY0 = Y1 + 1.2, LY1 = BB - 4;
      s += `<rect y="${LY0}" width="80" height="${f1(LY1 - LY0)}" fill="#0a080c"/>`;
      let eq = ''; const NB = 20, bw = 80 / NB;
      for (let i = 0; i < NB; i++) { const x = i * bw + 0.5, h0 = 3 + R() * 8, h1 = 2 + R() * 13, h2 = 4 + R() * 10, T = 0.8 + (i % 4) * 0.12;
        eq += `<rect x="${f1(x)}" y="${f1(LY1 - 0.5 - h0)}" width="${f1(bw - 1)}" height="${f1(h0)}" fill="url(#c61e)">${an('height', `${f1(h0)};${f1(h1)};${f1(h2)};${f1(h0)}`, T, -i * 0.07)}${an('y', `${f1(LY1 - 0.5 - h0)};${f1(LY1 - 0.5 - h1)};${f1(LY1 - 0.5 - h2)};${f1(LY1 - 0.5 - h0)}`, T, -i * 0.07)}</rect>`; }
      s += `<g filter="url(#wb1)" opacity="0.6">${eq}</g>${eq}<rect y="${LY0}" width="80" height="${f1(LY1 - LY0)}" fill="url(#c61p)"/><rect y="${LY0}" width="80" height="${f1(LY1 - LY0)}" fill="url(#c61s)"/>`;
      s += `<rect y="${f1(LY1)}" width="80" height="0.8" fill="url(#c61r)"/>`;
      const board = '#120e10';
      return { mat: s, sup: s, board,
        defs: '<linearGradient id="c61m0" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4ead8"/><stop offset="0.5" stop-color="#8a7a6e"/><stop offset="1" stop-color="#2a2224"/></linearGradient><linearGradient id="c61m1" x1="1" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a3032"/><stop offset="0.5" stop-color="#c8b4a0"/><stop offset="1" stop-color="#f8eee0"/></linearGradient><linearGradient id="c61m2" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#1e1a1c"/><stop offset="0.5" stop-color="#6a5a52"/><stop offset="1" stop-color="#e8d8c0"/></linearGradient><linearGradient id="c61m3" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#d8c4ac"/><stop offset="0.5" stop-color="#fff6e8"/><stop offset="1" stop-color="#5a4a44"/></linearGradient><linearGradient id="c61m4" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a3c3a"/><stop offset="0.5" stop-color="#2a2224"/><stop offset="1" stop-color="#b8a490"/></linearGradient><linearGradient id="c61m5" x1="1" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#e8d4bc"/><stop offset="0.5" stop-color="#4a3a38"/><stop offset="1" stop-color="#a8907c"/></linearGradient><linearGradient id="c61g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.18"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#2a1a20" stop-opacity="0.3"/></linearGradient>'
          + '<linearGradient id="c61r" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e8c890"/><stop offset="0.5" stop-color="#a8804a"/><stop offset="1" stop-color="#6a4a28"/></linearGradient>'
          + '<linearGradient id="c61e" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ff4a9a"/><stop offset="0.55" stop-color="#ffa040"/><stop offset="1" stop-color="#ffe08a"/></linearGradient>'
          + '<pattern id="c61p" width="1" height="1" patternUnits="userSpaceOnUse"><rect width="1" height="1" fill="none" stroke="#0a080c" stroke-width="0.32"/></pattern>'
          + '<linearGradient id="c61s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="0.4" stop-color="#ffffff" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.03, ao: 0.18, board: `<rect y="${f1(BB + 0.2)}" width="80" height="0.3" fill="#a8804a" opacity="0.8"/>` } }; });

    // CLB-081 INFINITE-DEPTH HOLOGRAPHIC VISUALIZER & LIQUID-LIGHT PLASMA WALLS (T5): deep black glass panels framed in thin champagne-gold seams; inside each
    // panel an endless tunnel of glowing rounded frames recedes to a bright vanishing point while warm liquid-light plasma (rose, amber, violet and gold
    // blobs) flows and merges across the glass. Live: the tunnel frames stream toward you endlessly, the plasma blobs drift, swell and merge.
    const wPlasma = memo('c81', () => { const R = rng('wc81'), cx = 40, cy = 24;
      let s = '<rect width="80" height="56" fill="#08060c"/>';
      // plasma blobs (blurred), drifting
      const PB = [['#ff4a9a', 20, 18, 16], ['#ffa040', 58, 30, 18], ['#a45aff', 36, 40, 15], ['#ffd870', 66, 10, 11], ['#ff6a5a', 8, 36, 12]];
      s += '<g filter="url(#wb2)" opacity="0.75" style="mix-blend-mode:screen">' + PB.map(([c, x, y, r], i) => `<g>${at('translate', `0 0;${f1((R() - 0.5) * 24)} ${f1((R() - 0.5) * 14)};${f1((R() - 0.5) * 18)} ${f1((R() - 0.5) * 12)};0 0`, 14 + i * 3, -i * 2, ' calcMode="spline" keyTimes="0;0.33;0.66;1" keySplines="0.4 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1"')}<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${f1(r * 0.7)}" fill="${c}" opacity="0.6">${an('rx', `${r};${f1(r * 1.3)};${r}`, 7 + i, -i, SPL(2))}</ellipse></g>`).join('') + '</g>';
      // infinite tunnel = ONE-OFF overlay (S.one): drawn once per wall (catalog back wall; one per panel of the round Dance Club wall), not once per tile
      let one = `<rect x="${cx - 30}" y="${cy - 21}" width="60" height="42" rx="10" fill="#07050a" opacity="0.92" filter="url(#wb2)"/>` + rep(8, i => `<g transform="translate(${cx} ${cy})"><g opacity="0"><animateTransform attributeName="transform" type="scale" values="0.03;1.7" dur="8s" begin="${-i}s" repeatCount="indefinite" calcMode="spline" keyTimes="0;1" keySplines="0.7 0 1 1"/>${an('opacity', '0;0.95;0.7;0', 8, -i, KT('0;0.2;0.8;1'))}<rect x="-26" y="-17" width="52" height="34" rx="8" fill="none" stroke="url(#c81t)" stroke-width="1.8" vector-effect="non-scaling-stroke"/></g></g>`).join('');
      one += `<circle cx="${cx}" cy="${cy}" r="3" fill="#fff4dc" opacity="0.8" filter="url(#wb1)">${an('opacity', '0.5;1;0.5', 2.4, 0, SPL(2))}</circle>`;
      // glass sheen; no vertical seams (one continuous black-glass wall for the single whole-wall tunnel), gold line at the skirting only
      s += '<rect width="80" height="56" fill="url(#c81g)"/>' + [].map(x => `<rect x="${f1(x - 0.35)}" width="0.7" height="56" fill="url(#c81s)"/>`).join('') + `<rect y="${f1(BB - 0.6)}" width="80" height="0.6" fill="url(#c81s)"/>`;
      const board = '#0c0a10';
      return { mat: s, sup: s, one, board,
        defs: '<linearGradient id="c81t" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd890"/><stop offset="0.5" stop-color="#ff6aa8"/><stop offset="1" stop-color="#b07aff"/></linearGradient>'
          + '<linearGradient id="c81g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.08"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.04"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="c81s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8a6a3a"/><stop offset="0.5" stop-color="#f0d8a0"/><stop offset="1" stop-color="#8a6a3a"/></linearGradient>',
        ro: { top: 0.02, ao: 0.16, board: `<rect y="${f1(BB + 0.2)}" width="80" height="0.3" fill="#d8bc84" opacity="0.7"/>` } }; });

    // CLB-081: in a room the tunnel is ONE tunnel spanning the whole wall (res.wallOne = 320 x 56 overlay, res.wallOneFull = 1: catalog back wall at
    // 100 % width, Squad House flat back wall 100..752, round Dance Club wall across all panels); the 80 x 56 S.one stays for the catalog card only
    const BIG81 = (cy, skirt) => { const cx = 160, R = rng('big81'), BBY = 53.6;
      // whole wall in one piece: black glass + one sheen, plasma blobs spread across the full width (no tile cuts), one tunnel, gold skirting line
      const PC = ['#ff4a9a', '#ffa040', '#a45aff', '#ffd870', '#ff6a5a'];
      const blobs = rep(16, i => { const x = 6 + i * 20 + (R() - 0.5) * 10, y = 8 + R() * 38, r = 10 + R() * 9, c = PC[i % 5], T = 14 + R() * 10;
        return `<g>${at('translate', `0 0;${f1((R() - 0.5) * 30)} ${f1((R() - 0.5) * 12)};${f1((R() - 0.5) * 24)} ${f1((R() - 0.5) * 10)};0 0`, T, -R() * T, ' calcMode="spline" keyTimes="0;0.33;0.66;1" keySplines="0.4 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1"')}<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(r)}" ry="${f1(r * 0.7)}" fill="${c}" opacity="0.55">${an('rx', `${f1(r)};${f1(r * 1.3)};${f1(r)}`, 7 + (i % 5), -i, SPL(2))}</ellipse></g>`; }).join('');
      const tun = rep(10, i => `<g transform="translate(${cx} ${cy})"><g opacity="0"><animateTransform attributeName="transform" type="scale" values="0.02;1.8" dur="10s" begin="${-i}s" repeatCount="indefinite" calcMode="spline" keyTimes="0;1" keySplines="0.7 0 1 1"/>${an('opacity', '0;0.95;0.75;0', 10, -i, KT('0;0.2;0.8;1'))}<rect x="-150" y="-26" width="300" height="52" rx="14" fill="none" stroke="url(#c81T)" stroke-width="2.2" vector-effect="non-scaling-stroke"/></g></g>`).join('')
        + `<ellipse cx="${cx}" cy="${cy}" rx="9" ry="3.4" fill="#fff4dc" opacity="0.8" filter="url(#c81B)">${an('opacity', '0.5;1;0.5', 2.4, 0, SPL(2))}</ellipse>`;
      const sk = skirt ? `<rect y="${BBY}" width="320" height="${f1(56 - BBY)}" fill="#0c0a10"/><rect y="${f1(BBY - 0.5)}" width="320" height="0.6" fill="url(#c81S)"/><rect y="${f1(BBY + 0.2)}" width="320" height="0.3" fill="#d8bc84" opacity="0.7"/>` : '';
      return 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 56" preserveAspectRatio="none"><defs><filter id="c81B" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.2"/></filter><filter id="c81P" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>`
        + `<linearGradient id="c81T" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd890"/><stop offset="0.5" stop-color="#ff6aa8"/><stop offset="1" stop-color="#b07aff"/></linearGradient>`
        + `<linearGradient id="c81G" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.06"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.03"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>`
        + `<linearGradient id="c81S" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8a6a3a"/><stop offset="0.5" stop-color="#f0d8a0"/><stop offset="1" stop-color="#8a6a3a"/></linearGradient></defs>`
        + `<rect width="320" height="56" fill="#08060c"/><g filter="url(#c81P)" opacity="0.75" style="mix-blend-mode:screen">${blobs}</g>${tun}<rect width="320" height="56" fill="url(#c81G)"/>${sk}</svg>`); };
    const B81F = BIG81(24, 1), B81R = BIG81(17, 0);
    const draw81 = RD.draw; RD.draw = (r, o) => { const res = draw81(r, o); if (res && r && r.s12 === 'cl81plas' && res.wallOne) { res.wallOne = B81F; res.wallOneR = B81R; res.wallOneFull = 1; } return res; };

    // ===== Dance Club walls as ONE continuous piece (same fixes as CLB-081): wide versions of each club wall (WW units wide, features placed once along
    // the wall instead of once per 80-unit tile, light sweeps cross the whole wall once). res.wallOne (320 wide, catalog back wall at 100 %) and
    // res.wallRnd (384 wide, bent onto the curved Dance Club wall in 16 skewed strips so courses / neon / skirting follow the curve). =====
    const stipP = (id, R, n, y1, a, b, o0, o1) => `<pattern id="${id}" width="80" height="${f1(y1)}" patternUnits="userSpaceOnUse">${stip(R, n, 0, y1, a, b, o0, o1)}</pattern>`;
    const blotW = (seed, WW, n, cols, op, sz) => rep(Math.ceil(WW / 80), i => `<g transform="translate(${i * 80} 0)">${blot(seed + i, n, cols, op, sz)}</g>`).join('');
    const wBlockW = WW => { const R = rng('wc01w'), BW = 16, BH = 7.6;
      let up = `<rect width="${WW}" height="56" fill="#8e8c88"/>`;
      for (let r = 0; r * BH < BB + BH; r++) for (let c = -1; c < WW / BW + 1; c++) { const x = c * BW + (r % 2 ? BW / 2 : 0), y = r * BH, col = shade('#9a9894', 0.92 + R() * 0.14);
        up += `<rect x="${f1(x + 0.5)}" y="${f1(y + 0.5)}" width="${BW - 1}" height="${f1(BH - 1)}" fill="${col}"/><rect x="${f1(x + 0.5)}" y="${f1(y + 0.5)}" width="${BW - 1}" height="0.5" fill="#b8b6b0" opacity="0.6"/><rect x="${f1(x + 0.5)}" y="${f1(y + BH - 1)}" width="${BW - 1}" height="0.5" fill="#5a5854" opacity="0.5"/>`; }
      up += `<rect width="${WW}" height="${BB}" fill="url(#c01wS)"/>` + blotW('wc01w', WW, 24, ['#a8a6a0', '#7a7872', '#8a8882'], 0.25, 4);
      let s = up + '<g filter="url(#wb1)">' + rep(Math.round(6 * WW / 80), () => { const x = R() * WW; return `<path d="M${f1(x)} ${f1(BB - 14 - R() * 6)}Q${f1(x + 2)} ${f1(BB - 6)} ${f1(x + (R() - 0.5) * 4)} ${BB}" stroke="#6a6a64" stroke-width="${f1(1.4 + R() * 2)}" fill="none" opacity="0.35"/>`; }).join('') + `<rect y="${f1(BB - 8)}" width="${WW}" height="8" fill="#f2f0e8" opacity="0.14"/></g>`;
      [0.18, 0.71].forEach(t => { const x = WW * t; s += `<path d="M${f1(x)} 6v1.6h3V6" stroke="#4a4844" stroke-width="0.7" fill="none"/><g filter="url(#wb1)"><path d="M${f1(x + 1.5)} 8Q${f1(x + 2)} 14 ${f1(x + 1.2)} 22" stroke="#9a5a2a" stroke-width="1" opacity="0.45" fill="none"/></g>`; });
      const foil = (x, y, w, h, rot, k) => { let f = `<g transform="rotate(${rot} ${f1(x + w / 2)} ${f1(y + h / 2)})"><rect x="${f1(x)}" y="${y}" width="${w}" height="${h}" fill="url(#c01f)"/>`;
        rep(26, () => { const px = x + R() * w, py = y + R() * h; f += `<path d="M${f1(px)} ${f1(py)}l${f1((R() - 0.5) * 5)} ${f1((R() - 0.5) * 4)}l${f1((R() - 0.5) * 4)} ${f1((R() - 0.5) * 3)}" stroke="${R() < 0.5 ? '#ffffff' : '#7a7e86'}" stroke-width="0.18" fill="none" opacity="0.7"/>`; });
        f += `<rect x="${f1(x)}" y="${y}" width="${w}" height="${h}" fill="url(#c01g)" opacity="0.8"><animate attributeName="x" values="${f1(x - w)};${f1(x + w)}" dur="5s" begin="${-k * 1.7}s" repeatCount="indefinite"/></rect>`;
        [[x - 1, y - 1], [x + w - 3, y - 1], [x - 1, y + h - 1.6], [x + w - 3, y + h - 1.6]].forEach(([tx, ty]) => f += `<rect x="${f1(tx)}" y="${f1(ty)}" width="4" height="2.6" fill="#b8bcc0" opacity="0.95"/><rect x="${f1(tx)}" y="${f1(ty)}" width="4" height="0.6" fill="#e2e6ea"/>`);
        return f + '</g>'; };
      const FO = []; for (let x = 6; x < WW - 24; x += 44 + R() * 30) FO.push(x);
      FO.forEach((x, i) => { if (i % 3 === 1) return; s += foil(x, 3 + R() * 5, 16 + R() * 6, 20 + R() * 8, (R() - 0.5) * 4, i); });
      { const x = FO[2] || WW * 0.5; s += `<g transform="translate(${f1(x + 18)} 25)"><path d="M0 0L3.6 0.6L0.4 4Z" fill="#c8ccd2" stroke="#8a8e94" stroke-width="0.12"><animate attributeName="d" values="M0 0L3.6 0.6L0.4 4Z;M0 0L3 1.8L1.2 3.6Z;M0 0L3.6 0.6L0.4 4Z" dur="2.4s" repeatCount="indefinite" ${SPL(2)}/></path></g>`; }
      const L1 = (x, y, w, h, kind) => { const r = Math.min(w, h) * 0.42; let d = `M${f1(x + r)} ${f1(y)}H${f1(x + w - r)}Q${f1(x + w)} ${f1(y)} ${f1(x + w)} ${f1(y + r)}V${f1(y + h - r)}Q${f1(x + w)} ${f1(y + h)} ${f1(x + w - r)} ${f1(y + h)}H${f1(x + r)}Q${f1(x)} ${f1(y + h)} ${f1(x)} ${f1(y + h - r)}V${f1(y + r)}Q${f1(x)} ${f1(y)} ${f1(x + r)} ${f1(y)}Z`;
        if (kind === 'o') d += `M${f1(x + w / 2)} ${f1(y + h * 0.3)}a${f1(w * 0.16)} ${f1(h * 0.2)} 0 1 0 0.01 0Z`;
        if (kind === 'b') d += `M${f1(x + w * 0.35)} ${f1(y + h * 0.22)}h${f1(w * 0.2)}v${f1(h * 0.16)}h${f1(-w * 0.2)}ZM${f1(x + w * 0.35)} ${f1(y + h * 0.58)}h${f1(w * 0.24)}v${f1(h * 0.16)}h${f1(-w * 0.24)}Z`;
        if (kind === 'n') d += `M${f1(x + w * 0.42)} ${f1(y + h)}V${f1(y + h * 0.45)}Q${f1(x + w * 0.5)} ${f1(y + h * 0.38)} ${f1(x + w * 0.58)} ${f1(y + h * 0.45)}V${f1(y + h)}Z`;
        return d; };
      const throwUp = (x0, y0, sc, cols, kinds) => { const LT = kinds.map((kd, i) => [x0 + i * 8.6 * sc, y0 + (i % 2 ? -1 : 0.4) * sc, (9.4 + (i % 2) * 0.4) * sc, (12 + (i % 2)) * sc, kd, cols[i % cols.length]]); let g = '';
        LT.forEach(([x, y, w, h, kd]) => g += `<path d="${L1(x + 1.2 * sc, y + 1.4 * sc, w, h, kd)}" fill="#3a1a4a" fill-rule="evenodd" stroke="#0e0a10" stroke-width="${f1(1.6 * sc)}" stroke-linejoin="round"/>`);
        LT.forEach(([x, y, w, h, kd, c]) => g += `<path d="${L1(x, y, w, h, kd)}" fill="${c}" fill-rule="evenodd" stroke="#0e0a10" stroke-width="${f1(1.6 * sc)}" stroke-linejoin="round"/><path d="${L1(x, y, w, h, kd)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.45 * sc)}" stroke-linejoin="round"/><path d="M${f1(x + 1.6 * sc)} ${f1(y + 2.6 * sc)}q${f1(sc)} ${f1(-1.4 * sc)} ${f1(2.6 * sc)} ${f1(-1.2 * sc)}" stroke="#ffffff" stroke-width="${f1(0.8 * sc)}" fill="none" stroke-linecap="round" opacity="0.8"/>`
          + `<path d="M${f1(x + w * 0.3)} ${f1(y + h)}v${f1(2 + R() * 2)}" stroke="${c}" stroke-width="0.7"/>`);
        return g + `<g filter="url(#wb1)" opacity="0.4"><ellipse cx="${f1(x0 + 18 * sc)}" cy="${f1(y0 + 6 * sc)}" rx="${f1(22 * sc)}" ry="${f1(9 * sc)}" fill="${cols[0]}" opacity="0.12"/></g>`; };
      s += throwUp(WW * 0.36, 29, 1, ['#ff4fa8', '#f2e23a', '#ff8a3a', '#a45aff'], ['n', 'b', 'n', 'b']);
      if (WW > 200) s += throwUp(WW * 0.78, 33, 0.8, ['#3ad8a0', '#ff4fa8', '#f2e23a'], ['x', 'x', 'x']);
      rep(Math.max(1, Math.round(WW / 110)), i => { const x = WW * (0.08 + i * 0.27) + R() * 10, y = 38 + R() * 8; s += `<path d="M${f1(x)} ${f1(y)}q2 -4 4 -1t3 -2l2 3q1 -3 3 0" stroke="${['#ff4fa8', '#1a1a1e', '#a45aff'][i % 3]}" stroke-width="0.8" fill="none" stroke-linecap="round"/>`; });
      [[WW * 0.27, 6, 4], [WW * 0.62, 9, -3]].forEach(([x, y, rot]) => { s += `<g transform="rotate(${rot} ${f1(x + 4)} ${y + 5})"><rect x="${f1(x)}" y="${y}" width="8" height="11" fill="#f2e8d0"/><rect x="${f1(x + 1)}" y="${y + 1}" width="6" height="5" fill="#2a1a3a"/><circle cx="${f1(x + 4)}" cy="${y + 3.5}" r="1.6" fill="#ff8a3a"/><path d="M${f1(x + 1)} ${y + 7.6}h6M${f1(x + 1)} ${y + 9}h4" stroke="#3a2a2a" stroke-width="0.4"/></g>`; });
      return { mat: s, board: '#2a2a2c',
        defs: stipP('c01wS', rng('wc01s'), 900, BB, '#6e6c66', '#bab8b0', 0.3, 0.4) + '<linearGradient id="c01f" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e8ecf0"/><stop offset="0.3" stop-color="#a8acb4"/><stop offset="0.55" stop-color="#f2f4f6"/><stop offset="0.8" stop-color="#9a9ea6"/><stop offset="1" stop-color="#d8dce2"/></linearGradient>'
          + '<linearGradient id="c01g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ff6ac8" stop-opacity="0"/><stop offset="0.5" stop-color="#ffd0f0" stop-opacity="0.8"/><stop offset="1" stop-color="#ff6ac8" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.04, ao: 0.2, board: `<rect y="${f1(BB + 0.3)}" width="${WW}" height="0.3" fill="#5a5a5e" opacity="0.6"/>` } }; };

    const wFoamW = WW => { const R = rng('wc21w'), PS = 13.3, q = (PS - 0.6) / 4;
      // pyramid relief as a pattern (light from the top-left), panel joints drawn over it
      const pyr = `<pattern id="c21wP" width="${f1(q)}" height="${f1(q)}" patternUnits="userSpaceOnUse"><path d="M0 0L${f1(q)} 0L${f1(q / 2)} ${f1(q / 2)}Z" fill="#3a3a3e"/><path d="M0 0L0 ${f1(q)}L${f1(q / 2)} ${f1(q / 2)}Z" fill="#2c2c30"/><path d="M${f1(q)} 0L${f1(q)} ${f1(q)}L${f1(q / 2)} ${f1(q / 2)}Z" fill="#18181a"/><path d="M0 ${f1(q)}L${f1(q)} ${f1(q)}L${f1(q / 2)} ${f1(q / 2)}Z" fill="#121214"/><circle cx="${f1(q / 2)}" cy="${f1(q / 2)}" r="0.22" fill="#5a5a60" opacity="0.7"/></pattern>`;
      let s = `<rect width="${WW}" height="56" fill="#0e0e10"/>`;
      for (let r = 0; r * PS < BB; r++) for (let c = 0; c < WW / PS + 1; c++) { const x0 = c * PS + (R() - 0.5) * 0.4, y0 = r * PS + (R() - 0.5) * 0.4; s += `<rect x="${f1(x0 + 0.3)}" y="${f1(y0 + 0.3)}" width="${f1(PS - 0.6)}" height="${f1(PS - 0.6)}" fill="url(#c21wP)" transform="rotate(${f1((R() - 0.5) * 0.6)} ${f1(x0 + PS / 2)} ${f1(y0 + PS / 2)})"/>`; }
      s += `<rect width="${WW}" height="${BB}" fill="url(#c21wS)"/>`;
      [0.3, 0.74].forEach(t => { const x = Math.round(WW * t / PS) * PS + 0.3, y = 2 * PS + 0.3; s += `<path d="M${f1(x)} ${f1(y)}L${f1(x + 4.8)} ${f1(y)}L${f1(x)} ${f1(y + 4.8)}Z" fill="#2a2a2e"/><circle cx="${f1(x + 1.4)}" cy="${f1(y + 1.2)}" r="0.9" fill="#d8d0b8" opacity="0.6"/>`; });
      // ONE pink wash and ONE amber wash sweep across the whole wall
      const T = 9 * (WW + 60) / 120;
      s += `<g style="mix-blend-mode:screen" opacity="0.85"><rect x="-60" y="0" width="60" height="56" fill="url(#c21w)"><animate attributeName="x" values="-60;${WW}" dur="${f1(T)}s" repeatCount="indefinite"/></rect><rect x="-50" y="0" width="45" height="56" fill="url(#c21v)"><animate attributeName="x" values="-50;${WW}" dur="${f1(T)}s" begin="${f1(-T / 2)}s" repeatCount="indefinite"/></rect></g>`;
      return { mat: s, board: '#141416',
        defs: pyr + stipP('c21wS', rng('wc21s'), 300, BB, '#4a4a50', '#0a0a0c', 0.2, 0.3) + '<linearGradient id="c21w" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ff3aa0" stop-opacity="0"/><stop offset="0.5" stop-color="#ff3aa0" stop-opacity="0.38"/><stop offset="1" stop-color="#ff3aa0" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="c21v" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffaa40" stop-opacity="0"/><stop offset="0.5" stop-color="#ffaa40" stop-opacity="0.3"/><stop offset="1" stop-color="#ffaa40" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.03, ao: 0.22, board: `<rect y="${f1(BB + 0.3)}" width="${WW}" height="0.3" fill="#3a3a3e" opacity="0.8"/>` } }; };

    const wBrickW = WW => { const R = rng('wc41w'), BW = 10, BH = 3.6;
      let s = `<rect width="${WW}" height="56" fill="#b8a898"/>`;
      for (let r = 0; r * BH < BB; r++) for (let c = -1; c < WW / BW + 1; c++) { const x = c * BW + (r % 2 ? BW / 2 : 0), y = r * BH, col = shade(['#9a4a32', '#a85a3a', '#8a3e2a', '#b0603e', '#7e3a28'][(R() * 5) | 0], 0.9 + R() * 0.2);
        s += `<rect x="${f1(x + 0.35)}" y="${f1(y + 0.35)}" width="${BW - 0.7}" height="${f1(BH - 0.7)}" fill="${col}"/><rect x="${f1(x + 0.35)}" y="${f1(y + 0.35)}" width="${BW - 0.7}" height="0.3" fill="#ffffff" opacity="0.12"/>`
          + (R() < 0.25 ? `<rect x="${f1(x + 1 + R() * 6)}" y="${f1(y + 0.8)}" width="${f1(1 + R() * 2)}" height="${f1(1 + R())}" fill="#3a1e14" opacity="0.25"/>` : ''); }
      s += `<rect width="${WW}" height="${BB}" fill="url(#c41wS)"/><rect y="${f1(BB - 7.2)}" width="${WW}" height="7.2" fill="#18161a" opacity="0.92"/>`;
      const tube = (d, c, w, id2) => `<g><path d="${d}" stroke="${c}" stroke-width="${w * 6}" fill="none" opacity="0.18" filter="url(#wb2)">${an('opacity', '0.14;0.22;0.14', 3, -id2, SPL(2))}</path><path d="${d}" stroke="${c}" stroke-width="${w * 2.4}" fill="none" opacity="0.5" filter="url(#wb1)"/>`
        + `<path d="${d}" stroke="${c}" stroke-width="${w}" fill="none" stroke-linecap="round">${an('opacity', '1;1;0.82;1;1;0.9;1', 4.2, -id2 * 1.3, KT('0;0.4;0.42;0.44;0.8;0.81;1'))}</path><path d="${d}" stroke="#ffffff" stroke-width="${f1(w * 0.35)}" fill="none" stroke-linecap="round" opacity="0.85"/></g>`;
      const pink = `M-2 12H${WW + 2}`, amb = 'M-2 36' + rep(Math.ceil(WW / 10), i => `Q${f1(i * 10 + 3)} ${i % 2 ? 40 : 32} ${f1(i * 10 + 8)} 36`).join('') + `H${WW + 2}`;
      s += tube(pink, '#ff3aa8', 1, 0) + tube(amb, '#ffaa3a', 1, 1);
      for (let x = 6; x < WW; x += 20) s += `<rect x="${x}" y="10.6" width="1.4" height="2.8" rx="0.3" fill="#e8f0f4" opacity="0.6"/><rect x="${x + 2}" y="34.6" width="1.4" height="2.8" rx="0.3" fill="#e8f0f4" opacity="0.6"/>`;
      const bx = WW * 0.82; s += `<path d="M${f1(bx + 1.6)} 12.6V30M${f1(bx + 2.6)} 36.8V40" stroke="#1a1a1c" stroke-width="0.5"/><rect x="${f1(bx)}" y="40" width="5" height="4" rx="0.4" fill="#3a3a3e"/><rect x="${f1(bx + 0.4)}" y="40.4" width="1.4" height="0.8" fill="#8a8a8a"/>`;
      return { mat: s, board: '#141216', defs: stipP('c41wS', rng('wc41s'), 800, BB, '#5a2a1a', '#d8a888', 0.15, 0.3),
        ro: { top: 0.04, ao: 0.2, board: `<rect y="${f1(BB + 0.3)}" width="${WW}" height="0.3" fill="#3a3238" opacity="0.8"/>` } }; };

    const wMirrorW = WW => { const R = rng('wc61w'), TS = 8, Y1 = 30, base = wMirror();
      let s = `<rect width="${WW}" height="56" fill="#1a1618"/>`;
      for (let r = 0; r * TS < Y1; r++) for (let c = 0; c < WW / TS; c++) { const x = c * TS, y = r * TS, up = (r + c) % 2 === 0;
        const t1 = up ? `M${x} ${y}L${x + TS} ${y}L${x} ${y + TS}Z` : `M${x} ${y}L${x + TS} ${y}L${x + TS} ${y + TS}Z`, t2 = up ? `M${x + TS} ${y}L${x + TS} ${y + TS}L${x} ${y + TS}Z` : `M${x} ${y}L${x} ${y + TS}L${x + TS} ${y + TS}Z`;
        [t1, t2].forEach(t => { s += `<path d="${t}" fill="url(#c61m${(R() * 6) | 0})" stroke="#1a1412" stroke-width="0.35"/>`; if (R() < 0.22) s += `<path d="${t}" fill="${['#ff6aa8', '#ffb050', '#c08aff'][(R() * 3) | 0]}" opacity="0.22"/>`; }); }
      s += `<rect width="${WW}" height="${Y1}" fill="url(#c61gW)"/>`;
      s += rep(Math.round(9 * WW / 80), i => { const x = 2 + R() * (WW - 4), y = 2 + R() * (Y1 - 4); return `<path d="M${f1(x - 1.4)} ${f1(y)}H${f1(x + 1.4)}M${f1(x)} ${f1(y - 1.4)}V${f1(y + 1.4)}" stroke="#ffffff" stroke-width="0.25" stroke-linecap="round" opacity="0">${an('opacity', '0;0;1;0;0', 3 + (i % 3), -i * 0.6, KT('0;0.6;0.66;0.74;1'))}</path>`; }).join('');
      s += `<rect y="${Y1}" width="${WW}" height="1.2" fill="url(#c61r)"/>`;
      const LY0 = Y1 + 1.2, LY1 = BB - 4; s += `<rect y="${LY0}" width="${WW}" height="${f1(LY1 - LY0)}" fill="#0a080c"/>`;
      let eq = ''; const bw = 4, NB = Math.ceil(WW / bw);
      for (let i = 0; i < NB; i++) { const x = i * bw + 0.5, h0 = 3 + R() * 8, h1 = 2 + R() * 13, h2 = 4 + R() * 10, T = 0.8 + (i % 4) * 0.12;
        eq += `<rect x="${f1(x)}" y="${f1(LY1 - 0.5 - h0)}" width="${f1(bw - 1)}" height="${f1(h0)}" fill="url(#c61e)">${an('height', `${f1(h0)};${f1(h1)};${f1(h2)};${f1(h0)}`, T, -i * 0.07)}${an('y', `${f1(LY1 - 0.5 - h0)};${f1(LY1 - 0.5 - h1)};${f1(LY1 - 0.5 - h2)};${f1(LY1 - 0.5 - h0)}`, T, -i * 0.07)}</rect>`; }
      s += `<g filter="url(#wb1)" opacity="0.6">${eq}</g>${eq}<rect y="${LY0}" width="${WW}" height="${f1(LY1 - LY0)}" fill="url(#c61p)"/><rect y="${LY0}" width="${WW}" height="${f1(LY1 - LY0)}" fill="url(#c61sW)"/><rect y="${f1(LY1)}" width="${WW}" height="0.8" fill="url(#c61r)"/>`;
      return { mat: s, board: '#120e10', defs: base.defs + '<linearGradient id="c61gW" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.55" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="0.8" stop-color="#2a1a20" stop-opacity="0.2"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.06"/></linearGradient>'
          + '<linearGradient id="c61sW" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0.08"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.06"/></linearGradient>',
        ro: { top: 0.03, ao: 0.18, board: `<rect y="${f1(BB + 0.2)}" width="${WW}" height="0.3" fill="#a8804a" opacity="0.8"/>` } }; };

    // CLB-113 matte black club walls (no s12 tile): plain matte black panels with soft vertical joints, one continuous piece
    const w113W = WW => { let s = `<rect width="${WW}" height="56" fill="#19181c"/>`; for (let x = 0; x < WW; x += 13.3) s += `<rect x="${f1(x)}" width="0.5" height="${BB}" fill="#0c0b0e"/><rect x="${f1(x + 0.5)}" width="0.3" height="${BB}" fill="#2c2a30" opacity="0.7"/>`;
      s += `<rect width="${WW}" height="${BB}" fill="url(#m113g)"/>`;
      return { mat: s, board: '#0e0d10', defs: '<linearGradient id="m113g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0.04"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.03"/></linearGradient>', ro: { top: 0.04, ao: 0.2 } }; };

    // the wall + the same room shading / skirting board as the tile pipeline (plus12 room()), WW wide
    const wideDoc = (S, WW) => { const o = S.ro || {}, lip = shade(S.board, 1.35), dk = shade(S.board, 0.7);
      const wsh = `<linearGradient id="wshW" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000000" stop-opacity="0.2"/><stop offset="0.07" stop-color="#000000" stop-opacity="0"/><stop offset="0.22" stop-color="#ffffff" stop-opacity="${o.top || 0.06}"/><stop offset="0.55" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.84" stop-color="#000000" stop-opacity="0"/><stop offset="0.957" stop-color="#000000" stop-opacity="${o.ao || 0.13}"/></linearGradient>`;
      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${WW} 56" preserveAspectRatio="none"><defs>${'<filter id="wb2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.3"/></filter><filter id="wb1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.45"/></filter>'}${S.defs || ''}${wsh}<clipPath id="wtcW"><rect width="${WW}" height="56"/></clipPath></defs>`
        + `<g clip-path="url(#wtcW)">${S.mat}</g><rect width="${WW}" height="56" fill="url(#wshW)"/><rect y="${f1(BB - 0.8)}" width="${WW}" height="1" fill="#000000" opacity="0.18" filter="url(#wb1)"/>`
        + `<rect y="${BB}" width="${WW}" height="${f1(56 - BB)}" fill="${S.board}"/><rect y="${BB}" width="${WW}" height="0.45" fill="${lip}"/><rect y="55.35" width="${WW}" height="0.65" fill="${dk}"/>${o.board || ''}</svg>`; };
    const WIDE31 = { cl01blk: wBlockW, cl21foam: wFoamW, cl41brick: wBrickW, cl61mir: wMirrorW, m113: w113W }, WC31 = {};
    const wideURL = (key, WW) => WC31[key + WW] || (WC31[key + WW] = 'data:image/svg+xml,' + encodeURIComponent(wideDoc(WIDE31[key](WW), WW)));
    // bend a 384-wide wall onto the curved Dance Club wall: band top = the room's ceiling arc, band height 130 (wall top to floor line), 16 skewed strips
    const rndURL = key => { const k0 = key + '|rnd'; if (WC31[k0]) return WC31[k0];
      const top = x => 270 - 300 * Math.sqrt(Math.max(0, 1 - Math.pow((x - 426) / 600, 2))), X0 = -20, X1 = 872, N = 16;
      let defs = `<image id="w" href="${wideURL(key, 384)}" x="${X0}" y="0" width="${X1 - X0}" height="130" preserveAspectRatio="none"/>`, body = '';
      for (let i = 0; i < N; i++) { const xa = X0 + (X1 - X0) * i / N, xb = X0 + (X1 - X0) * (i + 1) / N, ta = top(xa), tb = top(xb), sl = (tb - ta) / (xb - xa), c = ta - sl * xa;
        defs += `<clipPath id="s${i}"><rect x="${f1(xa - 0.6)}" y="-1" width="${f1(xb - xa + 1.2)}" height="132"/></clipPath>`;
        body += `<g transform="matrix(1 ${sl.toFixed(5)} 0 1 0 ${c.toFixed(2)})"><g clip-path="url(#s${i})"><use href="#w"/></g></g>`; }
      return (WC31[k0] = 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="-20 -40 892 240" preserveAspectRatio="none"><defs>${defs}</defs>${body}</svg>`)); };
    const drawW31 = RD.draw; RD.draw = (r, o) => { const res = drawW31(r, o);
      try { if (res && r && r.id && /^CLB-/.test(r.id) && res.kind === 'wall' && r.s12 !== 'cl81plas') { const key = r.s12 && WIDE31[r.s12] ? r.s12 : r.id === 'CLB-113' ? 'm113' : null;
        if (key) { res.wallOne = wideURL(key, 320); res.wallOneFull = 1; res.wallRnd = rndURL(key); } } } catch (e) { console.warn('reno plus31 wide wall', r && r.id, e); }
      return res; };
    RD.H31W = { wideURL, rndURL };

    Object.assign(SURF12, { cl01blk: wBlock, cl21foam: wFoam, cl41brick: wBrick, cl61mir: wMirror, cl81plas: wPlasma });
  }

  // ======================= CLUB WALL ART (CLB-004/024/044/064/084): wall pieces (box3 + face decals, WD planes); footprints + elev kept =======================
  { const { box3, cyl3 } = RD.H15, { WD } = RD.H12, { ext } = RD.H11, DEF19 = RD.H19.DEF19;
    const shW = (C, x, y, w, h, rx, op, z) => WD(C, x + 1, y - 1.4, z || 0.04, `<rect width="${f1(w)}" height="${f1(h)}" rx="${rx || 0.6}" fill="#000000" opacity="${op || 0.3}" filter="url(#m10b1)"/>`);
    const star5 = (cx, cy, r, rot) => { let d = ''; for (let i = 0; i < 10; i++) { const a = rot + i * PI / 5 - PI / 2, rr = i % 2 ? r * 0.45 : r; d += (i ? 'L' : 'M') + f1(cx + Math.cos(a) * rr) + ' ' + f1(cy + Math.sin(a) * rr); } return d + 'Z'; };

    // CLB-004 GLOW-IN-THE-DARK PLASTIC WALL STARS (T1): a loose spray of cheap pale-green phosphorescent plastic stars, a crescent moon, a ringed planet and a
    // comet stuck straight onto the cinderblock with blobs of white sticky tack; a couple of stars peeling off, one fallen and leaving a grey tack mark,
    // a faint marker doodle. In the dark club they glow a soft yellow-green. Live: the glow charges up under a passing light and slowly fades, and the
    // peeling star curls in the air.
    N.stars31 = S => { const D = { w: 76, d: 8, mount: 'wall', elev: 36, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('stars31'), id = C.u('s04'), X0 = -34, Y0 = 36;
        ext(C, [[X0, Y0 + 1, 0], [X0 + 68, -2, 0], [X0 + 68, -2, 1]]);
        const PG = '#d8e8b8', GL = '#c8ff7a';
        let base = '', glow = '';
        const add = (shape, k) => { base += `<path d="${shape}" fill="${PG}" stroke="#a8b890" stroke-width="0.25"/>`; glow += `<path d="${shape}" fill="${GL}"/>`; };
        [[8, 8, 4.4, 0.2], [20, 5, 2.6, -0.3], [30, 12, 3.4, 0.5], [44, 6, 2.2, 0.1], [56, 10, 4, -0.2], [64, 4, 2, 0.4], [14, 20, 2.4, 0.3], [38, 22, 3, -0.4], [50, 26, 2.2, 0.2], [24, 28, 1.8, 0], [62, 24, 2.8, 0.6], [6, 30, 2, -0.1]].forEach(([x, y, r, rot]) => add(star5(x, y, r, rot)));
        const moon = 'M47 14A6 6 0 1 0 53 21A4.6 4.6 0 1 1 47 14Z'; add(moon);
        const planet = 'M18 36a3.2 3.2 0 1 0 0.01 0Z'; add(planet); base += '<ellipse cx="18" cy="39.2" rx="5.6" ry="1.4" fill="none" stroke="#a8b890" stroke-width="0.9" transform="rotate(-14 18 39.2)"/>'; glow += '<ellipse cx="18" cy="39.2" rx="5.6" ry="1.4" fill="none" stroke="#c8ff7a" stroke-width="0.7" transform="rotate(-14 18 39.2)"/>';
        const comet = 'M58 32l2 -1.4l0.6 2.2l-2.2 0.6Z'; add(comet); base += '<path d="M58 32.4L48 36.6L58.4 33.4Z" fill="#d8e8b8" opacity="0.7"/>'; glow += '<path d="M58 32.4L48 36.6L58.4 33.4Z" fill="#c8ff7a" opacity="0.6"/>';
        const tack = [[8, 8], [30, 12], [56, 10], [38, 22], [62, 24], [47, 18], [18, 36]].map(([x, y]) => `<ellipse cx="${x + 0.6}" cy="${y + 0.4}" rx="0.7" ry="0.5" fill="#f2f0ea" opacity="0.5"/>`).join('');
        const mark = '<path d="M33 30.4l1.6 -1l1.4 1.4l-0.6 1.6l-1.8 0.2Z" fill="#8a8a86" opacity="0.4"/><path d="M4 40q4 -3 8 0" stroke="#2a2a3a" stroke-width="0.3" fill="none" opacity="0.4"/>';
        const peel = `<g transform="translate(20 5)"><g>${at('rotate', '0 0 0;18 0 0;6 0 0;0 0 0', 4, 0, SPL(3))}<path d="${star5(0, 0, 2.6, -0.3)}" fill="${PG}" stroke="#a8b890" stroke-width="0.25"/></g></g>`;
        const G = `<g opacity="0.7"><animate attributeName="opacity" values="0.25;0.95;0.8;0.5;0.25" keyTimes="0;0.08;0.3;0.7;1" dur="9s" repeatCount="indefinite"/><g filter="url(#m12b1)">${glow}</g>${glow}</g>`;
        let s = WD(C, X0, Y0, 0.03, `<g filter="url(#m12b1)" opacity="0.25" transform="translate(0.5 0.6)">${base}</g>`) + WD(C, X0, Y0, 0.08, base + G + tack + mark) + WD(C, X0, Y0, 0.3, peel);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-024 CUSTOM PINK NEON 'GOOD VIBES' FLAMINGO SIGN (T2): a hand-bent pink neon flamingo standing on one leg with a coral beak tip and a warm white
    // eye, and 'good vibes' in looping script beneath in white-pink neon, the glass tubes held off the wall on a clear acrylic backing cut to the shape and
    // fixed with four chrome standoffs, a black power cable running down to a little dimmer. Live: the neon breathes and hums, and now and then a letter
    // stutters before catching.
    N.flam31 = S => { const D = { w: 110, d: 10, mount: 'wall', elev: 50, glow: () => ({ y: 30, r: 70, c: 'url(#gNeon)' }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('n24'), X0 = -40, Y0 = 60, W = 80, Hh = 58;
        ext(C, [[X0, Y0 + 6, 0], [X0 + W, -2, 0], [X0 + W, -2, 3]]);
        const fl = 'M14 25L9 23.4L15 21Q20 13 32 15Q41 16 42 22Q42.6 29 34 31.6Q24 34 17 29.6Q14.6 27.8 14 25', neck = 'M40 18Q47 13 43 7Q39 1 44 -1Q48 -2.4 50 1', head = 'M50 1Q51.6 3.4 49 4.4Q47 4.6 46.2 2.6', leg = 'M28 32L28 46M29 36.6L35 39.4L29.6 42', wing = 'M20 23Q27 18.6 35 22.4M23 26Q29 23 34 25';
        const tube = (d, c, w, ph) => `<path d="${d}" stroke="${c}" stroke-width="${w * 5}" fill="none" opacity="0.25" filter="url(#m12b2)" stroke-linecap="round" stroke-linejoin="round">${an('opacity', '0.18;0.32;0.18', 3.2, ph, SPL(2))}</path><path d="${d}" stroke="${c}" stroke-width="${w * 2.2}" fill="none" opacity="0.6" filter="url(#m12b1)" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" stroke="${c}" stroke-width="${w}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" stroke="#ffffff" stroke-width="${f1(w * 0.35)}" fill="none" opacity="0.85" stroke-linecap="round" stroke-linejoin="round"/>`;
        const txt = (w, c, op) => `<text x="40" y="54" text-anchor="middle" font-family="'Brush Script MT','Segoe Script','Snell Roundhand',cursive" font-style="italic" font-size="13" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" opacity="${op}">good vibes</text>`;
        const backer = `<path d="M10 -4H58Q62 -4 62 0V40Q74 42 74 50V54Q74 60 68 60H12Q6 60 6 54V50Q6 42 6 38V0Q6 -4 10 -4Z" fill="#ffffff" opacity="0.08" stroke="#ffffff" stroke-opacity="0.35" stroke-width="0.4"/>`;
        const neon = tube(fl, '#ff4fa8', 1.1, 0) + tube(neck, '#ff4fa8', 1.1, 0) + tube(head, '#ff4fa8', 1.1, 0) + tube(leg, '#ff4fa8', 1, 0) + tube(wing, '#ff7ac0', 0.8, 0) + tube('M49.8 1.6Q53.4 2.4 52.4 5.8', '#ff8a5a', 1, 0) + tube('M52.4 5.8L51.6 6.6', '#3a2a3a', 0.9, 0) + `<circle cx="48.4" cy="1.8" r="0.6" fill="#fff4e8"/>`
          + `<g>${an('opacity', '1;1;0.25;1;0.4;1;1', 7, 0, KT('0;0.62;0.63;0.65;0.66;0.68;1'))}<g filter="url(#m12b2)">${txt(4, '#ffb0d8', 0.3)}</g><g filter="url(#m12b1)">${txt(1.8, '#ff9ad0', 0.6)}</g>${txt(0.9, '#ffd0ea', 1)}${txt(0.3, '#ffffff', 0.9)}</g>`;
        const stand = [[10, 52], [70, 52], [10, -1], [58, -1]].map(([x, y]) => cyl3(C, [X0 + x, Y0 - y, 0], [X0 + x, Y0 - y, 2.6], 0.9, '#c8ccd2', { mat: 'chrome', olw: 0.15 })).join('');
        const cable = `<path d="M40 60Q40 66 44 72" stroke="#1a1a1c" stroke-width="0.6" fill="none"/><rect x="42" y="70" width="5" height="3" rx="0.5" fill="#2a2a2e"/><circle cx="44.5" cy="71.5" r="0.7" fill="#5a5a60"/>`;
        let s = WD(C, X0, Y0, 0.05, `<g filter="url(#m12b2)" opacity="0.3"><ellipse cx="36" cy="24" rx="30" ry="24" fill="#ff4fa8" opacity="0.5"/><ellipse cx="40" cy="52" rx="30" ry="7" fill="#ffb0d8" opacity="0.5"/></g>` + cable) + stand + WD(C, X0, Y0, 2.4, backer + neon);
        return { defs: DEF19, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-044 FRAMED GOLD & PLATINUM VINYL RECORD AWARDS (T3): a hang of three music-industry style award frames in satin black with a thin silver fillet:
    // a big gold record in the centre and a platinum and a smaller gold either side, each LP mounted over its cover-art panel on black suede with a small
    // engraved plaque (no real names), the grooves catching the light, glass fronts with a soft reflection, a brass picture light above the centre frame.
    // Live: light rings sweep round the grooves and a glint slides across the glass.
    N.award31 = S => { const D = { w: 110, d: 8, mount: 'wall', elev: 44, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('a44'), FD = 2;
        ext(C, [[-46, 50, 0], [46, -2, 0], [46, -2, FD + 4]]);
        const F = [[-31, 6, 24, 30, '#d8dce2', 'pl'], [0, 2, 30, 40, '#e8c86a', 'g'], [31, 8, 22, 28, '#e8c86a', 'g2']];
        let s = '';
        F.forEach(([cx, by, w, h, rc, k], i) => { const b = 1.6, iw = w - 2 * b, ih = h - 2 * b, rr = Math.min(iw * 0.36, ih * 0.3), rx = iw * 0.42 + b, ry = b + ih * 0.38;
          let face = `<rect width="${w}" height="${h}" fill="#141416"/><rect x="0.4" y="0.4" width="${w - 0.8}" height="${h - 0.8}" fill="none" stroke="#3a3a3e" stroke-width="0.4"/><rect x="${b}" y="${b}" width="${f1(iw)}" height="${f1(ih)}" fill="#1e1c20"/><rect x="${b - 0.3}" y="${b - 0.3}" width="${f1(iw + 0.6)}" height="${f1(ih + 0.6)}" fill="none" stroke="#c8ccd2" stroke-width="0.3"/>`;
          // cover art panel behind the record (abstract, warm)
          face += `<clipPath id="${id}i${i}"><rect x="${b}" y="${b}" width="${f1(iw)}" height="${f1(ih)}"/></clipPath><g clip-path="url(#${id}i${i})">`;
          face += `<rect x="${f1(rx + rr * 0.3)}" y="${f1(ry - rr)}" width="${f1(rr * 1.9)}" height="${f1(rr * 2)}" fill="${['#5a2a4a', '#2a2a4a', '#4a2a1a'][i]}"/><circle cx="${f1(rx + rr * 1.3)}" cy="${f1(ry)}" r="${f1(rr * 0.5)}" fill="${['#ff8a5a', '#e8c86a', '#ff4fa8'][i]}" opacity="0.7"/>`;
          // the disc + grooves + label + spindle, with a sweeping light ring
          face += `<circle cx="${f1(rx)}" cy="${f1(ry)}" r="${f1(rr)}" fill="${rc}"/>` + rep(9, j => `<circle cx="${f1(rx)}" cy="${f1(ry)}" r="${f1(rr * (0.42 + j * 0.065))}" fill="none" stroke="${shade(rc, j % 2 ? 0.82 : 1.1)}" stroke-width="0.25"/>`).join('')
            + `<circle cx="${f1(rx)}" cy="${f1(ry)}" r="${f1(rr * 0.34)}" fill="${['#c84a3a', '#2a2a4a', '#f2e8d0'][i]}"/><circle cx="${f1(rx)}" cy="${f1(ry)}" r="0.4" fill="#1a1a1a"/>`
            + `<g transform="translate(${f1(rx)} ${f1(ry)})"><g>${at('rotate', '0;360', 6 + i, -i)}<path d="M0 ${f1(-rr * 0.4)}A${f1(rr * 0.4)} ${f1(rr * 0.4)} 0 0 1 ${f1(rr * 0.35)} ${f1(-rr * 0.2)}L${f1(rr * 0.85)} ${f1(-rr * 0.45)}A${f1(rr * 0.97)} ${f1(rr * 0.97)} 0 0 0 0 ${f1(-rr * 0.97)}Z" fill="#ffffff" opacity="0.45"/></g></g>`;
          face += `</g>`;
          // engraved plaque (no real names)
          face += `<rect x="${f1(w / 2 - iw * 0.3)}" y="${f1(h - b - 5)}" width="${f1(iw * 0.6)}" height="3.6" fill="#c8a858"/><path d="M${f1(w / 2 - iw * 0.22)} ${f1(h - b - 3.8)}h${f1(iw * 0.44)}M${f1(w / 2 - iw * 0.16)} ${f1(h - b - 2.4)}h${f1(iw * 0.32)}" stroke="#5a4a20" stroke-width="0.3"/>`;
          // glass reflection + sweeping glint
          face += `<path d="M${f1(w * 0.1)} 0H${f1(w * 0.3)}L${f1(w * 0.04)} ${h}H0V${f1(h * 0.6)}Z" fill="#ffffff" opacity="0.07"/><clipPath id="${id}c${i}"><rect width="${w}" height="${h}"/></clipPath><g clip-path="url(#${id}c${i})"><rect x="-12" y="0" width="6" height="${h}" fill="url(#${id}g)" transform="skewX(-22)">${an('x', `-12;-12;${w + 18};${w + 18}`, 11, 0, KT(`0;${f1(0.1 + i * 0.12)};${f1(0.34 + i * 0.12)};1`))}</rect></g>`;
          s += shW(C, cx - w / 2, by + h, w, h, 0.4, 0.4) + box3(C, { c: [cx, by, FD / 2], w, h, d: FD, col: '#141416', r: 0.3, dec: { f: face } }); });
        // brass picture light above the centre frame
        s += cyl3(C, [-9, 46, 1], [9, 46, 1], 1.1, '#c8a050', { mat: 'metal', olw: 0.2 }) + cyl3(C, [0, 44, 0], [0, 46, 1], 0.4, '#c8a050', { mat: 'metal', olw: 0.15 })
          + WD(C, -16, 45, 0.06, `<path d="M8 1H24L32 40H0Z" fill="url(#${id}l)" opacity="0.5"/>`);
        return { defs: DEF19 + `<defs><linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.45"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient><linearGradient id="${id}l" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.8"/><stop offset="1" stop-color="#ffe2a8" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-064 INFINITY-TUNNEL LED HEXAGONAL WALL SCULPTURE (T4): ledWall 132 kept (act 'party' + glow kept). A honeycomb cluster of three deep hexagonal
    // infinity mirrors in brushed gunmetal: a big one in the middle and two smaller ones beside it, each a two-way mirror front over a ring of LEDs, so the
    // light repeats into a tunnel of shrinking hexagons; warm magenta, amber and gold, a slim chrome bezel and the cluster's glow on the wall.
    // Live: the light chases inward down each tunnel and the colours shift from module to module.
    N.hex31 = S => { const D = { w: 132, d: 8, mount: 'wall', elev: 36, act: 'party', party: 1, glow: () => ({ y: 40, r: 100, c: 'url(#gNeon)' }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('x64'), DZ = 4;
        ext(C, [[-66, 84, 0], [66, -2, 0], [66, -2, DZ + 1]]);
        const M = [[0, 42, 34, 0], [-46, 30, 21, 1], [46, 54, 21, 2]];
        const hexPts = (cx, cy, r) => rep(6, i => { const a = i * PI / 3 + PI / 6; return [cx + Math.cos(a) * r, cy + Math.sin(a) * r]; });
        let s = WD(C, -66, 84, 0.05, `<g filter="url(#m12b2)" opacity="0.5">` + M.map(([x, y, r, i]) => `<circle cx="${66 + x}" cy="${84 - y}" r="${r * 1.3}" fill="${['#ff4fa8', '#ffa040', '#ffd060'][i]}" opacity="0.4"/>`).join('') + `</g>`);
        M.forEach(([cx, cy, r, mi]) => { const P0 = hexPts(cx, cy, r), back = P0.map(([x, y]) => C.P([x, y, 0])), fr = P0.map(([x, y]) => C.P([x, y, DZ]));
          // side walls of the prism (visible ones only by facing)
          for (let i = 0; i < 6; i++) { const j = (i + 1) % 6, n = [Math.cos(i * PI / 3 + PI / 3), Math.sin(i * PI / 3 + PI / 3)], vis = n[0] * C.v[0] + n[1] * (C.v[1] || 0) > -0.2;
            if (vis) s += `<path d="M${P2(back[i])}L${P2(back[j])}L${P2(fr[j])}L${P2(fr[i])}Z" fill="${shade('#5a5c62', 0.7 + 0.3 * Math.abs(n[0]))}" stroke="#2a2a2e" stroke-width="0.3"/>`; }
          // the front: mirror + tunnel of hex rings
          const loc = ([x, y]) => [x - cx + r, cy - y + r];
          const hp2 = k => 'M' + hexPts(cx, cy, r * k).map(p => { const q = loc(p); return f1(q[0]) + ' ' + f1(q[1]); }).join('L') + 'Z';
          const PAL = [['#ff4fa8', '#ffa040', '#ffd060'], ['#ffa040', '#ffd060', '#ff4fa8'], ['#ffd060', '#ff4fa8', '#ffa040']][mi];
          let f = `<path d="${hp2(1)}" fill="#0c0a10"/>`;
          for (let k = 0; k < 9; k++) { const sc = 0.86 * Math.pow(0.8, k); f += `<path d="${hp2(sc)}" fill="none" stroke="${PAL[k % 3]}" stroke-width="${f1(1.4 * Math.pow(0.85, k))}" opacity="${f1(0.95 - k * 0.09)}">${an('stroke', `${PAL[k % 3]};${PAL[(k + 1) % 3]};${PAL[(k + 2) % 3]};${PAL[k % 3]}`, 6, -mi * 1.5)}${an('opacity', `${f1(0.95 - k * 0.09)};${f1(0.3 - k * 0.02)};${f1(0.95 - k * 0.09)}`, 1.6, -(k * 0.18) - mi * 0.4)}</path>`; }
          f += `<path d="${hp2(0.86)}" fill="none" stroke="#ffffff" stroke-width="0.25" opacity="0.6"/><path d="${hp2(1)}" fill="url(#${id}g)"/><path d="${hp2(0.97)}" fill="none" stroke="#d8dce2" stroke-width="1.2"/><path d="${hp2(1)}" fill="none" stroke="#3a3a40" stroke-width="0.4"/>`;
          s += WD(C, cx - r, cy + r, DZ, f); });
        return { defs: DEF19 + `<defs><linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.4" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-084 12-FOOT CYBERNETIC CHROME MASCOT HEAD WITH LASER EYES (T5): infinity 92 kept (act 'party' + glow kept). A giant polished-chrome mascot head
    // of the club's own robo-cat, mounted on a gunmetal wall plate: a mirror-bright dome with two angular ears lined in champagne gold, a wraparound black
    // glass visor with two big round eyes, a grille muzzle with a little equaliser, panel seams, rivets and whisker light-bars. Live: the eyes blaze and
    // their warm laser beams sweep the room, the equaliser grille bounces and the chrome catches moving reflections.
    N.mascot31 = S => { const D = { w: 92, d: 8, mount: 'wall', elev: 42, act: 'party', party: 1, glow: () => ({ y: 40, r: 80, c: 'url(#gNeon)' }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('m84'), X0 = -36, Y0 = 72, W = 72;
        ext(C, [[X0, Y0, 0], [X0 + W, -6, 0], [X0 + W, -6, 6]]);
        const plate = `<rect x="6" y="6" width="60" height="64" rx="8" fill="#2a2c32"/><rect x="6" y="6" width="60" height="64" rx="8" fill="none" stroke="#5a5c64" stroke-width="0.8"/>` + [[10, 10], [62, 10], [10, 66], [62, 66]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="1" fill="#8a8c94"/>`).join('');
        const head = 'M14 34Q14 14 36 12Q58 14 58 34Q60 52 48 60Q36 66 24 60Q12 52 14 34Z';
        const earL = 'M16 22L12 2L28 14Z', earR = 'M56 22L60 2L44 14Z';
        let h = `<path d="${earL}" fill="url(#${id}c)" stroke="#3a3c42" stroke-width="0.6"/><path d="M17 18L14.6 7L24 14Z" fill="url(#${id}g)"/><path d="${earR}" fill="url(#${id}c)" stroke="#3a3c42" stroke-width="0.6"/><path d="M55 18L57.4 7L48 14Z" fill="url(#${id}g)"/>`;
        h += `<path d="${head}" fill="url(#${id}c)" stroke="#3a3c42" stroke-width="0.7"/><path d="${head}" fill="url(#${id}r)"/>`;
        h += `<g opacity="0.55"><clipPath id="${id}k"><path d="${head}"/></clipPath><g clip-path="url(#${id}k)"><rect x="-20" y="0" width="12" height="80" fill="#ffffff" opacity="0.5" transform="skewX(-20)">${an('x', '-20;90', 5)}</rect></g></g>`;
        h += `<path d="M36 13V24M22 20Q36 26 50 20" stroke="#6a6c74" stroke-width="0.35" fill="none"/>` + [[24, 16], [48, 16], [20, 46], [52, 46]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="0.7" fill="#9a9ca4" stroke="#4a4c52" stroke-width="0.2"/>`).join('');
        // visor + eyes
        h += `<path d="M17 28Q36 22 55 28L54 40Q36 46 18 40Z" fill="#0c0a10" stroke="#d6b26a" stroke-width="0.7"/><path d="M19 29Q36 24 53 29" stroke="#ffffff" stroke-width="0.4" fill="none" opacity="0.4"/>`;
        [27, 45].forEach((x, i) => { h += `<circle cx="${x}" cy="34" r="4.6" fill="#ff4fa8" opacity="0.35" filter="url(#m12b2)">${an('r', '4.6;6;4.6', 1.2, -i * 0.3)}</circle><circle cx="${x}" cy="34" r="3.4" fill="#ff7ab8"/><circle cx="${x}" cy="34" r="2" fill="#ffd0a0">${an('r', '1.6;2.4;1.6', 1.2, -i * 0.3)}</circle><circle cx="${x - 1}" cy="33" r="0.7" fill="#ffffff"/>`; });
        // muzzle grille with an equaliser + whisker light bars
        h += `<rect x="28" y="46" width="16" height="9" rx="3" fill="#1a1a20" stroke="#8a8c94" stroke-width="0.5"/>` + rep(6, i => { const x = 29.6 + i * 2.3, a = 2 + (i * 3) % 5, b = 6 - (i % 3); return `<rect x="${f1(x)}" y="${f1(54 - a)}" width="1.4" height="${a}" fill="#ffb050">${an('height', `${a};${b};${a}`, 0.6 + i * 0.08)}${an('y', `${f1(54 - a)};${f1(54 - b)};${f1(54 - a)}`, 0.6 + i * 0.08)}</rect>`; }).join('');
        h += [[-1, 48], [1, 48], [-1, 51], [1, 51]].map(([sd, y]) => `<rect x="${sd < 0 ? 14 : 46}" y="${y}" width="12" height="0.9" rx="0.45" fill="#ffd060" transform="rotate(${sd * (y === 48 ? -6 : 6)} ${sd < 0 ? 26 : 46} ${y})">${an('opacity', '0.5;1;0.5', 1.2, y * 0.01)}</rect>`).join('');
        // sweeping laser beams from the eyes (drawn on the wall plane, fanning down into the room)
        const beams = [27, 45].map((x, i) => `<g transform="translate(${x} 34)"><g>${at('rotate', `${i ? -40 : 40} 0 0;${i ? 30 : -30} 0 0;${i ? -40 : 40} 0 0`, 4, -i * 2, SPL(2))}<path d="M-0.6 0L0.6 0L5 90L-5 90Z" fill="url(#${id}b)" opacity="0.7"/><path d="M-0.15 0L0.15 0L1 90L-1 90Z" fill="#fff0e0" opacity="0.8"/></g></g>`).join('');
        let s = WD(C, X0, Y0, 0.05, `<g filter="url(#m12b2)" opacity="0.4"><circle cx="36" cy="36" r="34" fill="#ff4fa8" opacity="0.35"/></g>` + plate) + WD(C, X0, Y0, 4, h) + WD(C, X0, Y0, 5, `<g style="mix-blend-mode:screen">${beams}</g>`);
        return { defs: DEF19 + `<defs><radialGradient id="${id}c" cx="38%" cy="30%" r="75%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.25" stop-color="#d8dce4"/><stop offset="0.5" stop-color="#7a7e88"/><stop offset="0.7" stop-color="#e8ecf2"/><stop offset="0.85" stop-color="#5a5e68"/><stop offset="1" stop-color="#a8acb6"/></radialGradient>`
          + `<linearGradient id="${id}r" x1="0" y1="0" x2="0" y2="1"><stop offset="0.55" stop-color="#ff7ab8" stop-opacity="0"/><stop offset="1" stop-color="#ffb070" stop-opacity="0.35"/></linearGradient>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0c0"/><stop offset="0.5" stop-color="#d6b26a"/><stop offset="1" stop-color="#8a6a30"/></linearGradient>`
          + `<linearGradient id="${id}b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff6aa8" stop-opacity="0.9"/><stop offset="1" stop-color="#ffb050" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };
  }

  // ======================= CEILINGS (r.c31) — same frame + hook as plus30 (RD.H14 frame + G.VY depth, t 0 = front edge, 1 = back wall line) =======================
  // card = the tier's new club wall (SURF12 cl01..cl81) under the ceiling; res.ceilRoom = the wide room ceiling (Squad House v6 rt.ceil)
  { const { mould, mkV } = RD.H21, CFRM = RD.H14.FRM, { cE, cDoc, cShade, cHi } = RD.H27, { SURF12, tile: wTile } = RD.H12;
    const hp = (G, u, t, m) => { const y = G.y(t); return [G.x(u, y), cHi(G, y, m)]; };

    // CLB-009 EXPOSED GARAGE RAFTERS WITH CHRISTMAS LIGHTS (T1): no ceiling at all, just the underside of the garage roof: rough OSB roof deck with its
    // chip pattern and stamped grade marks between raw pine 2x6 rafters running front to back, nail-plate joints, cobwebs in the corners, a forgotten
    // fluorescent tube fixture, and a cheap string of multicoloured Christmas lights swagged from rafter to rafter. Live: the bulbs twinkle out of step
    // and the cobweb sways in the draught.
    function cRaft(G) { const R = rng('raft31'), MB = 0.93, NR = 8;
      let s = `<path d="${G.tr}" fill="#a8885e"/>`;
      // OSB chips
      rep(420, () => { const P = cE(G, R(), R()), z = P.z, w = (2 + R() * 4) * z, hh = (0.8 + R() * 1.4) * z * P.q * 3; s += `<rect x="${f1(P.x - w / 2)}" y="${f1(P.y - hh / 2)}" width="${f1(w)}" height="${f1(hh)}" fill="${['#c8a874', '#8a6a42', '#b8945e', '#d4b884', '#7a5a38'][(R() * 5) | 0]}" opacity="0.55" transform="rotate(${f1((R() - 0.5) * 50)} ${f1(P.x)} ${f1(P.y)})"/>`; });
      [[0.3, 0.3], [0.7, 0.64]].forEach(([u, t]) => { const P = cE(G, u, t), z = P.z; s += `<g transform="translate(${f1(P.x)} ${f1(P.y)}) scale(${f1(z)} ${f1(z * P.q * 2)})"><rect x="-9" y="-3" width="18" height="6" fill="none" stroke="#3a4a8a" stroke-width="0.4" opacity="0.45"/><path d="M-7 -1h8M-7 1h11" stroke="#3a4a8a" stroke-width="0.6" opacity="0.4"/></g>`; });
      s += cShade(G, 0.22, 0.04);
      // rafters: sides + soffit from the deck (m 1) down to MB
      const TS = rep(13, i => -0.02 + 1.04 * i / 12);
      for (let i = 0; i < NR; i++) { const uc = (i + 0.5) / NR, u0 = uc - 0.012, u1 = uc + 0.012;
        const side = (u, col) => `<path d="M${TS.map(t => P2(hp(G, u, t, 1))).join('L')}L${TS.slice().reverse().map(t => P2(hp(G, u, t, MB))).join('L')}Z" fill="${col}"/>`;
        s += (uc < 0.5 ? side(u1, '#8a6a40') : side(u0, '#8a6a40'));
        const sof = 'M' + TS.map(t => P2(hp(G, u0, t, MB))).join('L') + 'L' + TS.slice().reverse().map(t => P2(hp(G, u1, t, MB))).join('L') + 'Z';
        s += `<path d="${sof}" fill="#d4b47e"/>` + `<path d="M${TS.map(t => P2(hp(G, uc + (R() - 0.5) * 0.004, t, MB))).join('L')}" stroke="#a8844e" stroke-width="${f1(0.3 * G.s)}" fill="none" opacity="0.6"/>`;
        [0.3, 0.75].forEach(t => { if (R() < 0.6) { const p = hp(G, uc, t, MB), z = G.z(G.y(t)); s += `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(1.4 * z)}" ry="${f1(1 * z)}" fill="#7a5430" opacity="0.6"/>`; } }); }
      // fluorescent fixture across two rafters (off), cobwebs in the corners
      { const a = hp(G, 0.32, 0.45, MB - 0.01), b = hp(G, 0.56, 0.45, MB - 0.01), z = G.z(G.y(0.45)); s += `<path d="M${P2(a)}L${P2(b)}" stroke="#d8d8d0" stroke-width="${f1(3 * z)}" stroke-linecap="round"/><path d="M${P2(a)}L${P2(b)}" stroke="#f4f4ee" stroke-width="${f1(1.2 * z)}" stroke-linecap="round"/><path d="M${f1(a[0])} ${f1(a[1] + 1.6 * z)}L${f1(a[0] + 8 * z)} ${f1(a[1] + 1.4 * z)}" stroke="#8a8a80" stroke-width="${f1(0.5 * z)}"/>`; }
      const web = (u, t, sc) => { const p = hp(G, u, t, MB), z = G.z(G.y(t)) * sc; return `<g transform="translate(${P2(p)})"><g>${at('rotate', '-4 0 0;4 0 0;-4 0 0', 5, 0, SPL(2))}${rep(6, i => `<path d="M0 0L${f1(Math.cos(i * 0.5 + 0.3) * 14 * z)} ${f1(Math.sin(i * 0.5 + 0.3) * 10 * z)}" stroke="#f0eee8" stroke-width="${f1(0.18 * z)}" opacity="0.5"/>`).join('')}${rep(4, k => `<path d="M${f1(3 * (k + 1) * z)} ${f1(1.2 * (k + 1) * z)}Q${f1(2.4 * (k + 1) * z)} ${f1(3 * (k + 1) * z)} ${f1(1.2 * (k + 1) * z)} ${f1(3.8 * (k + 1) * z)}" stroke="#f0eee8" stroke-width="${f1(0.15 * z)}" fill="none" opacity="0.45"/>`).join('')}</g></g>`; };
      s += web(1 / 16, 0.92, 1.4) + web(15 / 16 - 0.03, 0.88, 1.1);
      // Christmas light swags crossing the rafters at two depths
      const LC = ['#ff4a4a', '#ffd040', '#4a9aff', '#5ad06a', '#ff8a3a', '#d070ff'];
      [0.24, 0.62].forEach((t, row) => { const pts = []; for (let i = 0; i < NR; i++) { const uc = (i + 0.5) / NR; pts.push(hp(G, uc, t + (i % 2 ? 0.02 : -0.02), MB)); }
        let d = 'M' + P2(pts[0]), bulbs = '';
        for (let i = 0; i < pts.length - 1; i++) { const a = pts[i], b = pts[i + 1], z = G.z(G.y(t)), sag = 7 * z, mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2 + sag; d += `Q${f1(mx)} ${f1(my + sag)} ${P2(b)}`;
          for (let k = 1; k <= 3; k++) { const f = k / 4, x = (1 - f) * (1 - f) * a[0] + 2 * f * (1 - f) * mx + f * f * b[0], y = (1 - f) * (1 - f) * a[1] + 2 * f * (1 - f) * (my + sag) + f * f * b[1], c = LC[(i * 3 + k + row) % LC.length], T = 1.4 + ((i + k) % 4) * 0.5;
            bulbs += `<circle cx="${f1(x)}" cy="${f1(y + 1.2 * z)}" r="${f1(3 * z)}" fill="${c}" opacity="0.35" filter="url(#cb3)">${an('opacity', '0.15;0.5;0.15', T, -(i + k) * 0.3)}</circle><ellipse cx="${f1(x)}" cy="${f1(y + 1.2 * z)}" rx="${f1(0.7 * z)}" ry="${f1(1.2 * z)}" fill="${c}">${an('opacity', '0.55;1;0.55', T, -(i + k) * 0.3)}</ellipse><rect x="${f1(x - 0.4 * z)}" y="${f1(y - 0.2 * z)}" width="${f1(0.8 * z)}" height="${f1(0.6 * z)}" fill="#2a3a2a"/>`; } }
        s += `<path d="${d}" stroke="#1e2a1e" stroke-width="${f1(0.35 * G.s)}" fill="none"/>` + bulbs; });
      return s + mould(G, 1.2, ['#6a5a44'], '#8a7a60'); }

    // CLB-029 BLACK PAINTED CEILING WITH STEEL LIGHTING TRUSS (T2): the whole ceiling sprayed flat black, joists, a duct and conduit included, so it
    // disappears; across the middle hangs a silver aluminium box truss on short chains, its four chords laced with zigzag braces, with six PAR cans
    // clamped under it in coloured gels and their cables taped along the top chord. Live: the cans pulse and swap colours to the beat, throwing soft
    // light cones down into the room.
    function cTruss(G) { const R = rng('truss31');
      let s = `<path d="${G.tr}" fill="#18181c"/>`;
      for (let u = 0.06; u < 1; u += 0.11) s += `<path d="${G.quad(u, -0.02, u + 0.018, 1.02)}" fill="#222228"/><path d="M${G.P(u + 0.018, -0.02)}L${G.P(u + 0.018, 1.02)}" stroke="#0a0a0c" stroke-width="${f1(0.6 * G.s)}"/>`;
      // a black duct + conduit
      s += `<path d="${G.quad(0.1, 0.2, 0.9, 0.27)}" fill="#202026"/><path d="M${G.P(0.1, 0.235)}L${G.P(0.9, 0.235)}" stroke="#2c2c34" stroke-width="${f1(1.4 * G.s)}"/><path d="M${G.P(0.05, 0.82)}L${G.P(0.95, 0.8)}" stroke="#26262c" stroke-width="${f1(0.6 * G.s)}"/>`;
      s += cShade(G, 0.2, 0.03);
      // box truss: 4 chords between u 0.06..0.94 at t 0.46 / 0.56, hung at m 0.88 (top) / 0.84 (bottom)
      const U = rep(25, i => 0.06 + 0.88 * i / 24), ch = (t, m) => 'M' + U.map(u => P2(hp(G, u, t, m))).join('L');
      const T0 = 0.3, T1 = 0.38, MT = 0.9, MBo = 0.865, z = G.z(G.y(0.34));
      [[0.12], [0.5], [0.88]].forEach(([u]) => [T0, T1].forEach(t => { const a = hp(G, u, t, 1), b = hp(G, u, t, MT); s += `<path d="M${P2(a)}L${P2(b)}" stroke="#8a8c90" stroke-width="${f1(0.5 * z)}" stroke-dasharray="${f1(0.8 * z)} ${f1(0.4 * z)}"/>`; }));
      let lace = ''; U.forEach((u, i) => { if (i === U.length - 1) return; const u2 = U[i + 1];
        lace += `M${P2(hp(G, u, T0, MT))}L${P2(hp(G, u2, T0, MBo))}M${P2(hp(G, u, T1, MT))}L${P2(hp(G, u2, T1, MBo))}M${P2(hp(G, u, T0, MBo))}L${P2(hp(G, u2, T1, MBo))}M${P2(hp(G, u, T0, MT))}L${P2(hp(G, u, T1, MT))}`; });
      s += `<path d="${lace}" stroke="#a8acb2" stroke-width="${f1(0.35 * z)}" fill="none"/>`;
      s += [[T0, MT], [T1, MT], [T0, MBo], [T1, MBo]].map(([t, m], i) => `<path d="${ch(t, m)}" stroke="${i < 2 ? '#d8dce2' : '#b8bcc2'}" stroke-width="${f1(1 * z)}" fill="none"/><path d="${ch(t, m)}" stroke="#ffffff" stroke-width="${f1(0.3 * z)}" fill="none" opacity="0.6"/>`).join('');
      s += `<path d="${ch(T0 - 0.004, MT)}" stroke="#141414" stroke-width="${f1(0.5 * z)}" fill="none" stroke-dasharray="${f1(6 * z)} ${f1(2 * z)}"/>`;
      // PAR cans under the truss with gel colours + cones
      const GEL = ['#ff3aa0', '#ffaa3a', '#a45aff', '#ff5a5a', '#ffd040', '#ff7ac0'];
      [0.14, 0.28, 0.42, 0.58, 0.72, 0.86].forEach((u, i) => { const p = hp(G, u, (T0 + T1) / 2, MBo - 0.012), c = GEL[i], c2 = GEL[(i + 2) % 6], T = 2 + (i % 3) * 0.5;
        s += `<path d="M${f1(p[0] - 22 * z)} ${f1(p[1] + 70 * z)}L${f1(p[0] - 3 * z)} ${f1(p[1] + 4 * z)}H${f1(p[0] + 3 * z)}L${f1(p[0] + 22 * z)} ${f1(p[1] + 70 * z)}Z" fill="${c}" opacity="0.22" filter="url(#cb1)">${an('opacity', '0.08;0.3;0.08', T, -i * 0.4)}${an('fill', `${c};${c2};${c}`, T * 3, -i)}</path>`
          + `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(4.4 * z)}" ry="${f1(5.4 * z)}" fill="#2a2a2e" stroke="#5a5a62" stroke-width="${f1(0.4 * z)}"/><path d="M${f1(p[0] - 5 * z)} ${f1(p[1] - 2 * z)}h${f1(10 * z)}" stroke="#9a9ca2" stroke-width="${f1(0.8 * z)}"/><ellipse cx="${f1(p[0])}" cy="${f1(p[1] + 3 * z)}" rx="${f1(3.4 * z)}" ry="${f1(2 * z)}" fill="${c}">${an('fill', `${c};${c2};${c}`, T * 3, -i)}${an('opacity', '0.6;1;0.6', T, -i * 0.4)}</ellipse>`
          + `<circle cx="${f1(p[0])}" cy="${f1(p[1] + 3 * z)}" r="${f1(8 * z)}" fill="${c}" opacity="0.35" filter="url(#cb3)">${an('fill', `${c};${c2};${c}`, T * 3, -i)}</circle>`; });
      return `<defs><linearGradient id="c29b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0e0" stop-opacity="0.8"/><stop offset="1" stop-color="#ffd0e0" stop-opacity="0"/></linearGradient></defs>` + s + mould(G, 1, ['#141418'], '#2a2a30'); }

    // CLB-049 MIRRORED COFFERED CEILING WITH SUSPENDED DISCO BALLS (T3): a grid of deep coffers between glossy black beams, every coffer lined with a
    // mosaic of little mirror squares catching the club lights, a slim warm LED line round each coffer, and three mirror balls of different sizes hanging
    // on chains. Live: the balls turn, their facets flashing, and a scatter of light specks sweeps across the ceiling.
    function cCoffer(G) { const R = rng('coffer31'), NU = 6, NT = 4, bw = 0.012;
      let s = `<path d="${G.tr}" fill="#0e0e12"/>`;
      for (let i = 0; i < NU; i++) for (let j = 0; j < NT; j++) { const u0 = i / NU + bw, u1 = (i + 1) / NU - bw, t0 = j / NT + bw * 1.6, t1 = (j + 1) / NT - bw * 1.6;
        s += `<path d="${G.quad(u0, t0, u1, t1)}" fill="#2a2830"/>`;
        const n = 6, m = 4; for (let a = 0; a < n; a++) for (let b = 0; b < m; b++) { const ua = u0 + 0.004 + (u1 - u0 - 0.008) * a / n, ub = u0 + 0.004 + (u1 - u0 - 0.008) * (a + 1) / n - 0.002, ta = t0 + 0.008 + (t1 - t0 - 0.016) * b / m, tb = t0 + 0.008 + (t1 - t0 - 0.016) * (b + 1) / m - 0.004;
          s += `<path d="${G.quad(ua, ta, ub, tb)}" fill="${['#b8b0b8', '#a49ca8', '#c4b8c0', '#988e9a', '#d0c0c4', '#aca0aa', '#e0ccc8'][(R() * 7) | 0]}"/>`; }
        s += `<path d="${G.quad(u0, t0, u1, t1)}" fill="url(#c49r)"/>`; s += `<path d="${G.quad(u0, t0, u1, t1)}" fill="none" stroke="#ffd090" stroke-width="${f1(0.35 * G.s)}" opacity="0.8"/>`; }
      s += `<path d="${G.tr}" fill="url(#c49g)"/>`;
      // glossy beams highlight lines
      for (let i = 1; i < NU; i++) s += `<path d="M${G.P(i / NU, -0.02)}L${G.P(i / NU, 1.02)}" stroke="#3a3a44" stroke-width="${f1(0.4 * G.s)}"/>`;
      // light specks sweeping
      s += `<g>${at('translate', `0 0;${f1(G.W * 0.18)} ${f1(G.H * 0.05)};0 0`, 12, 0, SPL(2))}` + rep(60, () => { const P = cE(G, R(), R()); return `<circle cx="${f1(P.x)}" cy="${f1(P.y)}" r="${f1((0.5 + R() * 0.8) * P.z)}" fill="${R() < 0.5 ? '#fff4e0' : '#ffd0e8'}" opacity="0">${an('opacity', '0;1;0', 1 + R() * 2, -R() * 3)}</circle>`; }).join('') + `</g>`;
      s += cShade(G, 0.18, 0.04);
      // disco balls on chains
      [[0.26, 0.3, 13], [0.6, 0.18, 17], [0.82, 0.5, 10]].forEach(([u, t, r], k) => { const top = hp(G, u, t, 1), y = G.y(t), z = G.z(y), drop = (k === 1 ? 26 : 18) * z, cx = top[0], cy = top[1] + drop, rr = r * z, cid = 'c49c' + k;
        s += `<path d="M${P2(top)}L${f1(cx)} ${f1(cy - rr)}" stroke="#a8a8b0" stroke-width="${f1(0.4 * z)}" stroke-dasharray="${f1(0.7 * z)} ${f1(0.3 * z)}"/>`
          + `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(rr * 1.6)}" fill="#ffe8f4" opacity="0.18" filter="url(#cb3)"/><clipPath id="${cid}"><circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(rr)}"/></clipPath><circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(rr)}" fill="url(#c49s)"/>`
          + `<g clip-path="url(#${cid})"><g>${at('translate', `0 0;${f1(rr * 0.5)} 0`, 1.6 + k * 0.4)}` + rep(9, a => rep(9, b => { const x = cx - rr + a * rr / 4 - rr * 0.5, yy = cy - rr + b * rr / 4; return `<rect x="${f1(x)}" y="${f1(yy)}" width="${f1(rr / 4.4)}" height="${f1(rr / 4.4)}" fill="${['#ffffff', '#c8c8d0', '#8a8a94', '#e8e8f0', '#ffd8ec'][(a * 3 + b * 7 + k) % 5]}" opacity="0.6"/>`; }).join('')).join('') + `</g></g>`
          + `<circle cx="${f1(cx - rr * 0.3)}" cy="${f1(cy - rr * 0.35)}" r="${f1(rr * 0.25)}" fill="#ffffff" opacity="0.6"/>`
          + rep(3, g => `<path d="M${f1(cx + (g - 1) * rr * 0.4)} ${f1(cy - rr * 0.2 + g * rr * 0.2)}m-${f1(rr * 0.4)} 0h${f1(rr * 0.8)}m-${f1(rr * 0.4)} -${f1(rr * 0.4)}v${f1(rr * 0.8)}" stroke="#ffffff" stroke-width="${f1(0.3 * z)}" opacity="0">${an('opacity', '0;1;0', 1.4 + g * 0.5, -g - k)}</path>`).join(''); });
      return `<defs><linearGradient id="c49g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff7ab8" stop-opacity="0.12"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#ffb060" stop-opacity="0.14"/></linearGradient><radialGradient id="c49r" cx="50%" cy="50%" r="70%"><stop offset="0" stop-color="#ffd8b0" stop-opacity="0.35"/><stop offset="1" stop-color="#2a1a20" stop-opacity="0.45"/></radialGradient><radialGradient id="c49s" cx="40%" cy="35%" r="65%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.6" stop-color="#a8a8b4"/><stop offset="1" stop-color="#4a4a54"/></radialGradient></defs>` + s + mould(G, 1.4, ['#141418', '#2a2a30'], '#d0a860'); }

    // CLB-069 MOTORIZED KINETIC TRIANGLE LED CEILING GRID (T4): a ceiling of matte black triangular panels on hidden motors, every seam traced with a warm
    // LED line; the panels tilt in slow waves so their faces catch more or less light, and the seams glow from rose through amber to gold as the wave
    // passes. Live: tilting waves ripple through the triangles and the LED seams follow them.
    function cKinetic(G) { const R = rng('kin31'), NU = 10, NT = 6;
      let s = `<path d="${G.tr}" fill="#0c0a0e"/>`, seams = '';
      for (let j = 0; j < NT; j++) for (let i = 0; i < NU; i++) { const u0 = i / NU, u1 = (i + 1) / NU, t0 = j / NT, t1 = (j + 1) / NT, ph = -((i + j * 0.6) * 0.35) % 6;
        const A = (j + i) % 2 ? [[u0, t0], [u1, t0], [u0, t1]] : [[u0, t0], [u1, t1], [u0, t1]], B = (j + i) % 2 ? [[u1, t0], [u1, t1], [u0, t1]] : [[u0, t0], [u1, t0], [u1, t1]];
        [A, B].forEach((T, k) => { const d = 'M' + T.map(([u, t]) => G.P(u, t)).join('L') + 'Z';
          s += `<path d="${d}" fill="${k ? '#26222a' : '#1c1a20'}"/><path d="${d}" fill="#f4e0d0" opacity="0">${an('opacity', '0;0.22;0.05;0', 6, ph - k * 0.4, KT('0;0.3;0.6;1'))}</path><path d="${d}" fill="#000000" opacity="0">${an('opacity', '0;0;0.35;0', 6, ph - k * 0.4, KT('0;0.3;0.6;1'))}</path>`;
          seams += d; }); }
      s += `<path d="${seams}" fill="none" stroke="url(#c69l)" stroke-width="${f1(0.5 * G.s)}"><animate attributeName="stroke-opacity" values="0.55;1;0.55" dur="3s" repeatCount="indefinite"/></path><path d="${seams}" fill="none" stroke="#ffb070" stroke-width="${f1(1.4 * G.s)}" opacity="0.18" filter="url(#cb1)"/>`;
      s += `<g opacity="0.5" style="mix-blend-mode:screen"><g>${at('translate', `${f1(-G.W * 0.6)} 0;${f1(G.W * 0.6)} 0`, 6)}<path d="${G.quad(0.4, -0.02, 0.6, 1.02)}" fill="url(#c69w)"/></g></g>`;
      return `<defs><linearGradient id="c69l" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ff5aa0"/><stop offset="0.5" stop-color="#ffaa50"/><stop offset="1" stop-color="#ffd870"/></linearGradient><linearGradient id="c69w" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffb070" stop-opacity="0"/><stop offset="0.5" stop-color="#ffb070" stop-opacity="0.35"/><stop offset="1" stop-color="#ffb070" stop-opacity="0"/></linearGradient></defs>` + s + cShade(G, 0.15, 0.03) + mould(G, 1.4, ['#141418'], '#ffb070'); }

    // CLB-089 360-DEGREE IMMERSION DOME WITH FLOATING LASER HALO RIGS (T5): the middle of the ceiling opens into a deep projection dome ringed in a
    // brushed champagne-gold torus; the dome is wrapped in a slow warm nebula (rose, amber, violet, gold) with a faint star field and gold meridian lines
    // tracing its curve. Below it three slim gold halo rings float on nothing, each trimmed with a running LED band and firing fans of warm laser beams
    // down into the room. Live: the nebula turns and drifts, stars twinkle, the halos bob out of step, their LED bands run and the laser fans sweep.
    function cDome(G) { const R = rng('dome31'), U0 = 0.5, T0 = 0.42, RU = 0.36, RT = 0.36, NA = 48;
      const dp = (rho, a, h) => { const m = 1 + h * Math.sqrt(Math.max(0, 1 - rho * rho)); return hp(G, U0 + RU * rho * Math.cos(a), T0 + RT * rho * Math.sin(a), m); };
      const ringD = (rho, h) => 'M' + rep(NA, i => P2(dp(rho, i / NA * 2 * PI, h))).join('L') + 'Z', HH = 0.42;
      let s = `<path d="${G.tr}" fill="#16101a"/>`;
      // satin plaster round the dome: faint warm radial bounce
      s += `<path d="${G.tr}" fill="url(#c89a)"/>` + cShade(G, 0.18, 0.04);
      const rim = ringD(1, HH);
      let dome = '';
      const RC = ['#1e0e1e', '#2e1430', '#40193e', '#521e48', '#64264e', '#763050', '#883c50', '#9a4a4e', '#ac5a4c', '#bc6c4c'];
      RC.forEach((c, i) => { const rho = 1 - i / RC.length; dome += `<path d="${ringD(rho, HH)}" fill="${c}"/>`; });
      // nebula blobs + stars inside, clipped to the rim
      const neb = rep(24, i => { const a = R() * 2 * PI, rho = Math.sqrt(R()) * 0.85, p = dp(rho, a, HH), z = G.z(p[1]); const c = ['#ff5a9a', '#ffaa40', '#b070ff', '#ffd870', '#ff7a5a'][i % 5];
        return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1((22 + R() * 26) * z)}" ry="${f1((9 + R() * 12) * z)}" fill="${c}" opacity="${n4(0.35 + R() * 0.3)}" transform="rotate(${f1(R() * 180)} ${f1(p[0])} ${f1(p[1])})">${an('opacity', '0.3;0.75;0.3', 6 + R() * 6, -R() * 8, SPL(2))}</ellipse>`; }).join('');
      const stars = rep(70, () => { const p = dp(Math.sqrt(R()) * 0.97, R() * 2 * PI, HH); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1((0.25 + R() * 0.4) * G.z(p[1]))}" fill="#fff4e0">${an('opacity', '0.2;1;0.2', 2 + R() * 3, -R() * 4)}</circle>`; }).join('');
      const apex = dp(0, 0, HH);
      let mer = ''; rep(12, i => { const a = i / 12 * 2 * PI; mer += 'M' + rep(9, j => P2(dp(1 - j / 8, a, HH))).join('L'); });
      rep(3, j => { mer += ringD(0.25 + j * 0.25, HH); });
      s += `<clipPath id="c89k"><path d="${rim}"/></clipPath><g clip-path="url(#c89k)">${dome}`
        + `<g filter="url(#cb3)" style="mix-blend-mode:screen"><g>${at('translate', `0 0;${f1(G.W * 0.05)} ${f1(G.H * 0.03)};${f1(-G.W * 0.04)} ${f1(G.H * 0.02)};0 0`, 30, 0, SPL(3))}${neb}</g></g>`
        + `<g>${at('translate', `0 0;${f1(G.W * 0.03)} 0;0 0`, 40, 0, SPL(2))}${stars}</g>`
        + `<path d="${mer}" fill="none" stroke="#ffd890" stroke-width="${f1(0.25 * G.s)}" opacity="0.28"/>`
        + `<circle cx="${f1(apex[0])}" cy="${f1(apex[1])}" r="${f1(G.W * 0.15)}" fill="url(#c89c)">${an('opacity', '0.6;1;0.6', 8, 0, SPL(2))}</circle></g>`;
      // gold torus rim
      s += `<path d="${ringD(1.03, HH)}" fill="none" stroke="#6a5030" stroke-width="${f1(2.2 * G.s)}"/><path d="${rim}" fill="none" stroke="url(#c89r)" stroke-width="${f1(1.6 * G.s)}"/><path d="${rim}" fill="none" stroke="#fff0c8" stroke-width="${f1(0.3 * G.s)}" opacity="0.7"/>`;
      s += `<path d="${ringD(1.07, HH)}" fill="none" stroke="#ffb870" stroke-width="${f1(2.4 * G.s)}" opacity="0.18" filter="url(#cb1)">${an('opacity', '0.1;0.28;0.1', 6, 0, SPL(2))}</path>`;
      // floating halo rigs
      const LZ = ['#ff5a9a', '#ffaa40', '#ffd870', '#b070ff'];
      [[0.3, 0.3, 0.92, 0.07], [0.7, 0.3, 0.92, 0.07], [0.5, 0.58, 0.9, 0.08]].forEach(([u, t, m, r], k) => { const ring = rep(36, i => { const a = i / 36 * 2 * PI; return hp(G, u + r * Math.cos(a), t + r * 0.8 * Math.sin(a), m); }), c = hp(G, u, t, m), z = G.z(G.y(t)), d = 'M' + ring.map(P2).join('L') + 'Z', T = 5 + k * 1.3, cA = LZ[k % 4], cB = LZ[(k + 1) % 4];
        let fan = ''; rep(9, j => { const ang = (j - 4) * 7 * PI / 180, L = G.H * 0.95, e = [c[0] + Math.sin(ang) * L, c[1] + Math.cos(ang) * L]; fan += `M${P2(c)}L${P2(e)}`; });
        s += `<g>${at('translate', `0 0;0 ${f1(-3 * z)};0 0`, T, -k * 1.7, SPL(2))}`
          + `<ellipse cx="${f1(c[0])}" cy="${f1(c[1])}" rx="${f1(r * G.W * 0.9)}" ry="${f1(r * G.W * 0.35)}" fill="${cA}" opacity="0.14" filter="url(#cb3)"/>`
          + `<g opacity="0.75" style="mix-blend-mode:screen"><g>${at('rotate', `-14 ${P2(c)};14 ${P2(c)};-14 ${P2(c)}`, 4 + k, -k, SPL(2))}<path d="${fan}" stroke="${cA}" stroke-width="${f1(2.4 * G.s)}" opacity="0.35" filter="url(#cb1)">${an('stroke', `${cA};${cB};${cA}`, 9, -k * 2)}</path><path d="${fan}" stroke="${cA}" stroke-width="${f1(0.5 * G.s)}">${an('stroke', `${cA};${cB};${cA}`, 9, -k * 2)}${an('opacity', '1;0.4;1;1', 2.4, -k, KT('0;0.1;0.2;1'))}</path></g></g>`
          + `<path d="${d}" fill="none" stroke="#7a6038" stroke-width="${f1(2 * z)}"/><path d="${d}" fill="none" stroke="url(#c89r)" stroke-width="${f1(1.3 * z)}"/>`
          + `<path d="${d}" fill="none" stroke="${cA}" stroke-width="${f1(0.6 * z)}" stroke-dasharray="${f1(3 * z)} ${f1(3 * z)}">${an('stroke-dashoffset', `0;${f1(-12 * z)}`, 1.2)}${an('stroke', `${cA};${cB};${cA}`, 9, -k * 2)}</path></g>`; });
      return `<defs><radialGradient id="c89a" cx="50%" cy="40%" r="60%"><stop offset="0" stop-color="#ff9a6a" stop-opacity="0.12"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></radialGradient>`
        + `<radialGradient id="c89c" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffe8c0" stop-opacity="0.55"/><stop offset="1" stop-color="#ffb070" stop-opacity="0"/></radialGradient>`
        + `<linearGradient id="c89r" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#b08848"/><stop offset="0.35" stop-color="#f4dca0"/><stop offset="0.6" stop-color="#c8a060"/><stop offset="1" stop-color="#f0d090"/></linearGradient></defs>` + s + mould(G, 1.4, ['#1a121c', '#2a1e28'], '#d8b060'); }

    const CEIL31 = { raft: cRaft, truss: cTruss, coffer: cCoffer, kin: cKinetic, dome: cDome }, CM31 = {};
    const WALL31 = { raft: 'cl01blk', truss: 'cl21foam', coffer: 'cl41brick', kin: 'cl61mir', dome: 'cl81plas' }, CB31 = { raft: ['#a8885e', '#6a5a44'], truss: ['#18181c', '#141418'], coffer: ['#0e0e12', '#d0a860'], kin: ['#0c0a0e', '#ffb070'], dome: ['#16101a', '#d8b060'] }, WS31 = { raft: '#8e8c88', truss: '#1a1a1e', coffer: '#8a3e2a', kin: '#2a2224', dome: '#2a1630' };
    const cardOf31 = k => { const G = mkV(CFRM.card), S = SURF12[WALL31[k]](), ws = WS31[k];
      return `<svg x="16" y="26" width="48" height="30" viewBox="0 0 80 56" preserveAspectRatio="xMidYMax slice">${wTile(S)}</svg><path d="M0 0L16 26V56H0Z" fill="${shade(ws, 0.86)}"/><path d="M80 0L64 26V56H80Z" fill="${shade(ws, 0.78)}"/><path d="M16 26V56M64 26V56" stroke="#000000" stroke-opacity="0.2" stroke-width="0.6"/>`
        + cDoc(G, CEIL31[k](G)) + `<path d="${G.tr}" fill="none" stroke="#000000" stroke-opacity="0.25" stroke-width="0.5"/>`; };
    const draw31c = RD.draw;
    RD.draw = (r, o) => { const res = draw31c(r, o); if (!res || res._p31c) return res;
      try { const c = r.c31 && CEIL31[r.c31]; if (c && res.surf) { res._p31c = 1; res.vb = '0 0 80 56';
          const M = CM31[r.c31] || (CM31[r.c31] = (() => { const G = mkV(CFRM.room); return { svg: RD.svgDoc('0 0 80 56', [], cardOf31(r.c31)), room: RD.svgDoc('0 0 ' + G.W + ' ' + G.H, [], cDoc(G, c(G))) }; })());
          res.svg = M.svg; res.src = 'data:image/svg+xml,' + encodeURIComponent(M.svg); res.ceilRoom = M.room; res.ceilBase = CB31[r.c31][0]; res.ceilTrim = CB31[r.c31][1]; } } catch (e) { console.warn('reno plus31 ceil', r.id, e); }
      return res; };
    RD.H31C = { CEIL31, WALL31, CB31, WS31, cardOf31, hp };
  }

  // ======================= MAIN CLUB LIGHT (CLB-006/026/046/066/086): 006/026 were flat 'light' swatches (plus4 s4 foil / mirror), now hanging
  // pieces like the Living Room / Kitchen / Bedroom lights: spec + s4 null, mount 'ceil'; Squad House v6 initH migration s.clb31a hangs the one in use =======================
  { const { box3, cyl3 } = RD.H15, mix = X.K.mix;
    const DEFC = '<filter id="l31b1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.8"/></filter><filter id="l31b3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>';
    const swing = (C, q, deg, T, b) => { const c = C.P(q); return `<animateTransform attributeName="transform" type="rotate" values="${-deg} ${P2(c)};${deg} ${P2(c)};${-deg} ${P2(c)}" dur="${n4(T)}s" begin="${n4(b || 0)}s" repeatCount="indefinite"${SPL(2)}/>`; };
    const FLK = (T, b) => an('opacity', '1;0.8;1;0.45;1;0.9;1', T, b, KT('0;0.22;0.3;0.33;0.36;0.6;1'));
    const nrm = (x, y, z) => { const l = Math.hypot(x, y, z) || 1; return [x / l, y / l, z / l]; };
    const anD = (a, v, d, b) => `<animate attributeName="${a}" values="${v}" dur="${d}s" calcMode="discrete"${b ? ` begin="${n4(b)}s"` : ''} repeatCount="indefinite"/>`;
    const near = (C, r, y) => C.P([r * Math.sin(C.thV), y, r * Math.cos(C.thV)]);
    let UID = 0;
    // faceted mirror ball really turning (copied from plus4 mball): F discrete frames per tile step, glints from a fixed light environment
    function mball(cx, cy, R, o) { const F = o.F || 6, cols = o.cols || 18, rows = o.rows || 10, dt = o.dt || 0.09, e = 0.38, ce = Math.cos(e), se = Math.sin(e), env = o.env, base = o.base, hi = o.hi || '#f4f0f0', id = 'mb31' + (++UID);
      const pr = (ph, th) => { const x = Math.cos(ph) * Math.sin(th), y = Math.sin(ph), z = Math.cos(ph) * Math.cos(th); return [x, y * ce - z * se, y * se + z * ce]; };
      const sc = v => f1(cx + R * v[0]) + ' ' + f1(cy - R * v[1]);
      const gp = 0.11, dph = PI / rows, dth = 2 * PI / cols; let fr = '';
      for (let f = 0; f < F; f++) { let g = '';
        for (let i = 0; i < rows; i++) { const p0 = -PI / 2 + i * dph, pa = p0 + dph * gp, pb = p0 + dph * (1 - gp), pc = p0 + dph / 2;
          for (let j = 0; j < cols; j++) { const t0 = j * dth + f * dth / F, ta = t0 + dth * gp, tb = t0 + dth * (1 - gp), n = pr(pc, t0 + dth / 2); if (n[2] < 0.05) continue;
            const r = [2 * n[2] * n[0], 2 * n[2] * n[1], 2 * n[2] * n[2] - 1]; let col = mix(base, hi, Math.max(0, Math.min(1, 0.14 + 0.3 * (n[1] + 1) / 2 + 0.14 * n[2])));
            env.forEach(L => { const v = Math.max(0, r[0] * L.d[0] + r[1] * L.d[1] + r[2] * L.d[2]), s = Math.min(1, Math.pow(v, L.p) * L.s); if (s > 0.02) col = mix(col, L.c, s); });
            g += `<path d="M${sc(pr(pa, ta))}L${sc(pr(pa, tb))}L${sc(pr(pb, tb))}L${sc(pr(pb, ta))}Z" fill="${col}"/>`; } }
        fr += `<g opacity="${f ? 0 : 1}">${anD('opacity', rep(F, m => m === f ? 1 : 0).join(';'), n4(F * dt))}${g}</g>`; }
      const Cc = ` cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(R)}"`;
      const s = `<defs><radialGradient id="${id}r" cx="50%" cy="50%" r="50%"><stop offset="0.6" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#140c10" stop-opacity="0.6"/></radialGradient><radialGradient id="${id}h" cx="32%" cy="27%" r="42%"><stop offset="0" stop-color="#fff" stop-opacity="0.5"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient><clipPath id="${id}c"><circle${Cc}/></clipPath></defs>`
        + `<circle${Cc} fill="#1c1418"/><g clip-path="url(#${id}c)">${fr}</g><circle${Cc} fill="url(#${id}r)"/><circle${Cc} fill="url(#${id}h)"/><circle${Cc} fill="none" stroke="#141014" stroke-width="${f1(R * 0.035)}"/>`;
      return { s, T: cols * F * dt }; }
    // light specks thrown round the room on an ellipse (front half bright, back half faint), one lap per ball turn
    const specks = (cx, cy, rx, ry, n, T, cols, sz) => { const path = `M${f1(cx - rx)} ${f1(cy)}A${f1(rx)} ${f1(ry)} 0 1 0 ${f1(cx + rx)} ${f1(cy)}A${f1(rx)} ${f1(ry)} 0 1 0 ${f1(cx - rx)} ${f1(cy)}`;
      return rep(n, i => { const b = -n4(T * i / n), c = cols[i % cols.length], s = sz * (0.7 + ((i * 37) % 10) / 18), q = s * 0.28;
        return `<g><circle r="${f1(s * 1.1)}" fill="${c}" opacity="0.3"/><path d="M0 ${f1(-s)}L${f1(q)} ${f1(-q)}L${f1(s)} 0L${f1(q)} ${f1(q)}L0 ${f1(s)}L${f1(-q)} ${f1(q)}L${f1(-s)} 0L${f1(-q)} ${f1(-q)}Z" fill="${c}"/>`
          + `<animateMotion dur="${n4(T)}s" begin="${b}s" repeatCount="indefinite" path="${path}"/>${an('opacity', '1;1;0.12;0.12;1', n4(T), b, KT('0;0.44;0.54;0.94;1'))}</g>`; }).join(''); };
    // crumpled kitchen-foil ball in screen space (cx, cy, R px)
    const foil = (cx, cy, R, seed, id) => { const Rn = rng(seed), n = 15, w = R / 7.4, pts = rep(n, i => { const a = i / n * 2 * PI, r = R * (0.84 + Rn() * 0.24); return [cx + Math.cos(a) * r, cy + Math.sin(a) * r]; }), outl = 'M' + pts.map(P2).join('L') + 'Z';
      let s = `<defs><radialGradient id="${id}g" cx="34%" cy="30%" r="75%"><stop offset="0" stop-color="#fbfcfe"/><stop offset="0.5" stop-color="#bcc2cc"/><stop offset="1" stop-color="#6a707c"/></radialGradient><clipPath id="${id}c"><path d="${outl}"/></clipPath></defs><path d="${outl}" fill="url(#${id}g)"/><g clip-path="url(#${id}c)">`;
      rep(20, i => { const a = Rn() * 2 * PI, rr = Rn() * R * 0.85, x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr, s2 = R * (0.18 + Rn() * 0.22), b = Rn() * PI, lit = (x - cx) + (y - cy) < 0;
        s += `<path d="M${[0, 2.1, 4.2].map(k2 => P2([x + Math.cos(b + k2) * s2, y + Math.sin(b + k2) * s2 * 0.8])).join('L')}Z" fill="${i % 4 === 0 ? '#ffffff' : lit ? '#e8ecf2' : '#7c838e'}" opacity="${i % 4 === 0 ? 0.85 : 0.5}">${i % 4 === 0 ? an('opacity', '0.1;0.95;0.1', 2.6, -i * 0.4) : ''}</path>`; });
      let d = ''; rep(11, () => { let x = cx + (Rn() - 0.5) * R * 1.4, y = cy + (Rn() - 0.5) * R * 1.4; d += `M${f1(x)} ${f1(y)}`; rep(3, () => { x += (Rn() - 0.5) * R * 0.55; y += (Rn() - 0.5) * R * 0.55; d += `L${f1(x)} ${f1(y)}`; }); });
      return { s: s + `<path d="${d}" fill="none" stroke="#50565f" stroke-width="${f1(0.32 * w)}" opacity="0.6"/><path d="${d}" transform="translate(${f1(0.3 * w)} ${f1(0.3 * w)})" fill="none" stroke="#ffffff" stroke-width="${f1(0.22 * w)}" opacity="0.5"/></g><path d="${outl}" fill="none" stroke="#5a606a" stroke-width="${f1(0.45 * w)}"/>`, outl }; };

    // CLB-006 PARTY BULB + FOIL BALL (T1): a cracked, yellowed plastic ceiling rose with a cobweb, a white flex with a lump of electrical tape, a black
    // bakelite lampholder with a chipped shade ring and a cheap painted-blue party bulb (the paint scratched off in one spot so a white glint shows through,
    // dust on its shoulder); beside it a lumpy ball of crumpled kitchen foil on a bit of string, held to the ceiling with a strip of masking tape.
    // Live: the bulb flickers now and then, both sway in the draught out of step and the foil ball twists, glints winking.
    N.foil31 = S => { const T = 46, D = { w: 34, d: 34, zs: 1.6, mount: 'ceil', build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('foil31'), id = C.u('f31'), BC = '#3f74ff';
        const rose = cyl3(C, [0, T - 1.8, 0], [0, T, 0], 3.6, '#e2d6b0', { olw: 0.5 }), rc = near(C, 3.6, T - 0.9);
        const crack = `<path d="M${f1(rc[0] - 1.6 * k)} ${f1(rc[1] - 0.8 * k)}l${f1(0.8 * k)} ${f1(0.7 * k)}l${f1(-0.3 * k)} ${f1(0.7 * k)}l${f1(0.7 * k)} ${f1(0.5 * k)}" stroke="#7a6a48" stroke-width="${f1(0.2 * k)}" fill="none"/>`;
        const web = (() => { const a = C.P([-3.4, T, 1]), b = C.P([0, T - 9, 0]), c = C.P([3, T, -1]); return `<path d="M${P2(a)}Q${f1((a[0] + b[0]) / 2 - k)} ${f1((a[1] + b[1]) / 2)} ${P2(b)}M${P2(c)}Q${f1((c[0] + b[0]) / 2 + k)} ${f1((c[1] + b[1]) / 2)} ${P2(b)}M${P2(a)}Q${f1((a[0] + c[0]) / 2)} ${f1((a[1] + c[1]) / 2 + 2.4 * k)} ${P2(c)}" stroke="#d8d8d8" stroke-width="${f1(0.1 * k)}" fill="none" opacity="0.5"/>`; })();
        const c0 = C.P([0, T - 1.8, 0]), c1 = C.P([0, 27, 0]);
        const flex = `<path d="M${P2(c0)}L${P2(c1)}" stroke="#ece6d6" stroke-width="${f1(0.7 * k)}"/><path d="M${P2(c0)}L${P2(c1)}" stroke="#b0a890" stroke-width="${f1(0.7 * k)}" stroke-dasharray="${f1(0.5 * k)} ${f1(0.6 * k)}" opacity="0.5"/>` + cyl3(C, [0, 36.2, 0], [0, 33.8, 0], 0.75, '#1e1e22', { olw: 0.2 });
        const holder = cyl3(C, [0, 27, 0], [0, 22.6, 0], 1.7, '#242428', { mat: 'gloss', olw: 0.3 }) + cyl3(C, [0, 23.6, 0], [0, 22.8, 0], 2.3, '#2c2c30', { olw: 0.3 });
        const hc = near(C, 2.3, 23.2), chip = `<path d="M${f1(hc[0] - 0.8 * k)} ${f1(hc[1] - 0.4 * k)}l${f1(0.6 * k)} ${f1(0.8 * k)}l${f1(0.7 * k)} ${f1(-0.6 * k)}Z" fill="#6a6a70"/>`;
        const b0 = C.P([0, 22.6, 0]), bk = k;
        const bulbP = `M-1.6 0C-1.6 2 -3.6 3.2 -3.6 6.4A3.6 3.8 0 0 0 3.6 6.4C3.6 3.2 1.6 2 1.6 0Z`;
        const bulb = `<g transform="translate(${P2(b0)}) scale(${n4(bk)})"><rect x="-1.3" y="-0.4" width="2.6" height="1.4" fill="#b8b4a8"/><path d="M-1.3 0.2h2.6M-1.3 0.7h2.6" stroke="#7a766c" stroke-width="0.2"/>`
          + `<g>${FLK(7.1)}<path d="${bulbP}" fill="url(#${id}b)" stroke="#2a58c8" stroke-width="0.2"/><ellipse cx="-1.6" cy="5" rx="0.7" ry="1.8" fill="#ffffff" opacity="0.55"/><path d="M1.4 7.6l0.9 -0.5l0.4 0.6l-0.8 0.5Z" fill="#fffef4"/><circle cx="1.8" cy="7.6" r="1.2" fill="#ffffff" opacity="0.4" filter="url(#l31b1)"/></g>`
          + `<path d="M-2.6 2.6q1 -0.6 2 -0.4" stroke="#a8a090" stroke-width="0.5" opacity="0.5" fill="none"/></g>`;
        const bc = [b0[0], b0[1] + 6.4 * k];
        const glow = `<g>${FLK(7.1)}<circle cx="${f1(bc[0])}" cy="${f1(bc[1])}" r="${f1(20 * k)}" fill="url(#${id}g)"/><path d="M${f1(bc[0] - 4 * k)} ${f1(bc[1] + 2 * k)}L${f1(bc[0] - 11 * k)} ${f1(bc[1] + 30 * k)}H${f1(bc[0] + 11 * k)}L${f1(bc[0] + 4 * k)} ${f1(bc[1] + 2 * k)}Z" fill="url(#${id}c)"/></g>`;
        // foil ball on a string, taped to the ceiling
        const FX = 11, FZ = -2, fy = 15, ft = C.P([FX, T - 0.05, FZ]), fb = C.P([FX, fy + 4.4, FZ]), fc = C.P([FX, fy, FZ]), FR_ = 4.6 * k, fo = foil(fc[0], fc[1], FR_, 'foil31b', id + 'f');
        const tape = `<path d="M${[[FX - 2.4, FZ - 0.7], [FX + 2.4, FZ - 1.1], [FX + 2.6, FZ + 0.9], [FX - 2.2, FZ + 1.2]].map(([x, z]) => P2(C.P([x, T - 0.05, z]))).join('L')}Z" fill="#e8dcae" stroke="#c8b888" stroke-width="${f1(0.1 * k)}" opacity="0.95"/>`;
        const ballG = `<g>${swing(C, [FX, T, FZ], 3, 6.3, -2)}<path d="M${P2(ft)}L${P2(fb)}" stroke="#e8e2d2" stroke-width="${f1(0.22 * k)}"/><g transform="translate(${P2(fc)})"><g>${at('scale', '1 1;0.84 1;1 1', 5.2, 0, SPL(2))}<g transform="translate(${f1(-fc[0])} ${f1(-fc[1])})">${fo.s}</g></g></g>`
          + `<path d="${fo.outl}" fill="url(#${id}t)">${FLK(7.1)}</path></g>`;
        // dust on the bulb shoulder
        const dust = rep(6, () => `<circle cx="${f1(b0[0] + (R() - 0.5) * 4 * k)}" cy="${f1(b0[1] + (1.4 + R() * 1.4) * k)}" r="${f1(0.18 * k)}" fill="#c8c0a8" opacity="0.6"/>`).join('');
        C.p(-8, 4, -8); C.p(12, 4, 8); C.p(0, T, 0); C.p(FX, 7, FZ);
        return { defs: DEFC + `<defs><radialGradient id="${id}b" cx="40%" cy="62%" r="60%"><stop offset="0" stop-color="#e6f0ff"/><stop offset="0.4" stop-color="#8ab2ff"/><stop offset="1" stop-color="${BC}"/></radialGradient>`
          + `<radialGradient id="${id}g" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="${BC}" stop-opacity="0.6"/><stop offset="0.4" stop-color="${BC}" stop-opacity="0.22"/><stop offset="1" stop-color="${BC}" stop-opacity="0"/></radialGradient>`
          + `<linearGradient id="${id}c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${BC}" stop-opacity="0.16"/><stop offset="1" stop-color="${BC}" stop-opacity="0"/></linearGradient><linearGradient id="${id}t" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${BC}" stop-opacity="0.55"/><stop offset="0.6" stop-color="${BC}" stop-opacity="0"/></linearGradient></defs>`,
          front: rose + crack + web + tape + ballG + `<g>${swing(C, [0, T - 1.8, 0], 2.2, 5.1)}${glow}${flex}${holder}${chip}${bulb}${dust}</g>`, bb: C.bb(5) }; };
      return D; };

    // CLB-026 MIRROR BALL + PINSPOT (T2): a 12-inch glass mirror ball on a short chain under a black ceiling motor (green power LED), lit by a small
    // black pinspot can on a ceiling bracket whose warm white beam hits it from the side; real tiles that turn with the motor, with glints from the
    // pinspot and the room. Live: the ball turns, its light rays rotate, specks of light circle the room and dust motes drift in the beam.
    N.mball31 = S => { const T = 56, D = { w: 56, d: 56, zs: 1.5, mount: 'ceil', build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('mball31'), id = C.u('m31'), BR = 10.5, BY = T - 17 - BR;
        const plate = cyl3(C, [0, T - 1, 0], [0, T, 0], 3.2, '#26262c', { olw: 0.3 });
        const ch0 = C.P([0, T - 1, 0]), ch1 = C.P([0, T - 7, 0]);
        const chain = `<path d="M${P2(ch0)}L${P2(ch1)}" stroke="#a8a8b0" stroke-width="${f1(0.6 * k)}" stroke-dasharray="${f1(0.9 * k)} ${f1(0.4 * k)}"/>`;
        const motor = box3(C, { c: [0, T - 12, 0], w: 7, h: 5, d: 7, col: '#2a2c34', r: 0.8 }) + cyl3(C, [0, T - 12, 0], [0, T - 16.6, 0], 0.5, '#b8bccc', { mat: 'metal', olw: 0.15 });
        const led = near(C, 3.6, T - 9.6);
        const ledS = `<circle cx="${f1(led[0])}" cy="${f1(led[1])}" r="${f1(0.45 * k)}" fill="#7ae89a">${an('opacity', '1;0.4;1', 1.2)}</circle>`;
        const bc = C.P([0, BY, 0]), Rp = BR * k, ENV = [{ d: nrm(-0.7, 0.45, 0.55), c: '#fff6e4', p: 22, s: 1.5 }, { d: nrm(0.75, 0.15, 0.62), c: '#ffc8d8', p: 16, s: 0.7 }, { d: nrm(0.15, -0.65, 0.74), c: '#ffd08a', p: 16, s: 0.6 }];
        const MB = mball(bc[0], bc[1], Rp, { env: ENV, F: 6, cols: 18, rows: 10, dt: 0.09, base: '#3a3240' }), TT = MB.T, Lr = 44 * k;
        const sp = C.P([-26, T - 5, 8]), a = Math.atan2(bc[1] - sp[1], bc[0] - sp[0]), ca = Math.cos(a), sa = Math.sin(a), lx = sp[0] + ca * 4.6 * k, ly = sp[1] + sa * 4.6 * k, px = -sa, py = ca;
        const brk = C.P([-26, T, 8]);
        const pin = `<path d="M${P2(brk)}L${P2(sp)}" stroke="#3a3c44" stroke-width="${f1(0.9 * k)}"/><path d="M${f1(brk[0] - 2.4 * k)} ${f1(brk[1])}h${f1(4.8 * k)}" stroke="#3a3c44" stroke-width="${f1(0.9 * k)}" stroke-linecap="round"/>`
          + `<g transform="translate(${P2(sp)}) rotate(${f1(a * 180 / PI)}) scale(${n4(k * 0.72)})"><rect x="-6" y="-3.6" width="12" height="7.2" rx="1.6" fill="#24252a" stroke="#101114" stroke-width="0.5"/><rect x="-4" y="-3.6" width="1" height="7.2" fill="#3a3c44"/><rect x="-1.5" y="-3.6" width="1" height="7.2" fill="#3a3c44"/><rect x="5.4" y="-3" width="1.6" height="6" rx="0.5" fill="#fff6e4"/><circle cx="7" cy="0" r="2.6" fill="#fff6e4" opacity="0.6"/></g>`;
        const beam = `<path d="M${f1(lx + px * 1.6 * k)} ${f1(ly + py * 1.6 * k)}L${f1(bc[0] + px * Rp * 0.85)} ${f1(bc[1] + py * Rp * 0.85)}L${f1(bc[0] - px * Rp * 0.85)} ${f1(bc[1] - py * Rp * 0.85)}L${f1(lx - px * 1.6 * k)} ${f1(ly - py * 1.6 * k)}Z" fill="url(#${id}B)"/>`;
        const motes = rep(10, i => { const f = 0.15 + R() * 0.75, x = lx + (bc[0] - lx) * f + (R() - 0.5) * Rp * f, y = ly + (bc[1] - ly) * f + (R() - 0.5) * Rp * f; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(0.22 * k)}" fill="#fff8e8" opacity="0">${an('opacity', '0;0.9;0', 3 + R() * 3, -R() * 5)}${at('translate', `0 0;${f1((R() - 0.5) * 3 * k)} ${f1(2 * k)}`, 5 + R() * 3, -R() * 5)}</circle>`; }).join('');
        const halo = `<circle cx="${f1(bc[0])}" cy="${f1(bc[1])}" r="${f1(40 * k)}" fill="url(#${id}H)">${an('opacity', '0.8;1;0.8', 1.6)}</circle>`;
        const rays = `<g transform="translate(${P2(bc)})"><g><animateTransform attributeName="transform" type="rotate" values="0;360" dur="${n4(TT * 1.5)}s" repeatCount="indefinite"/>` + rep(12, i => { const b = i * PI / 6, w = 0.08; return `<path d="M0 0L${f1(Math.cos(b - w) * Lr)} ${f1(Math.sin(b - w) * Lr)}L${f1(Math.cos(b + w) * Lr)} ${f1(Math.sin(b + w) * Lr)}Z" fill="url(#${id}R)" opacity="${i % 2 ? 0.5 : 0.85}">${an('opacity', i % 2 ? '0.3;0.65;0.3' : '0.85;0.5;0.85', 1.3 + (i % 3) * 0.3)}</path>`; }).join('') + `</g></g>`;
        const sk = `<g filter="url(#l31b1)" opacity="0.6">${specks(bc[0], bc[1] + 6 * k, 46 * k, 22 * k, 9, TT, ['#ffffff', '#ffe0c8'], 2 * k)}</g>` + specks(bc[0], bc[1] + 6 * k, 46 * k, 22 * k, 16, TT, ['#ffffff', '#ffe8d8', '#fff0c0'], 1.7 * k);
        const far = -26 * C.v[0] + 8 * C.v[2] < 0;
        C.p(-30, T, 8); C.p(14, BY - BR - 2, 0); C.p(0, T, 0); C.p(0, BY - BR, 0);
        return { defs: DEFC + `<defs><radialGradient id="${id}H" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff6e4" stop-opacity="0.7"/><stop offset="0.4" stop-color="#fff0dc" stop-opacity="0.24"/><stop offset="1" stop-color="#fff0dc" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}R" gradientUnits="userSpaceOnUse" cx="0" cy="0" r="${f1(Lr)}"><stop offset="0.25" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>`
          + `<linearGradient id="${id}B" gradientUnits="userSpaceOnUse" x1="${f1(lx)}" y1="${f1(ly)}" x2="${f1(bc[0])}" y2="${f1(bc[1])}"><stop offset="0" stop-color="#fff6e4" stop-opacity="0.8"/><stop offset="1" stop-color="#fff6e4" stop-opacity="0.25"/></linearGradient></defs>`,
          front: halo + rays + sk + (far ? pin + beam + motes : '') + plate + chain + motor + ledS + (far ? '' : beam + motes) + MB.s + (far ? '' : pin), bb: C.bb(5) }; };
      return D; };
    const { shadow, FR, sph } = RD.H10;
    const line3 = (C, P, w, col, ex) => '<path d="M' + P.map(p => P2(C.P(p))).join('L') + '" stroke="' + col + '" stroke-width="' + f1(w * C.k) + '" fill="none" stroke-linecap="round" stroke-linejoin="round"' + (ex ? ' ' + ex : '') + '/>';
    const PLN = (C, y, svg) => `<g transform="${FR(C, [0, y, 0], [1, 0, 0], [0, 0, 1])}">${svg}</g>`;
    const dep = (C, x, z) => x * C.v[0] + z * C.v[2];
    const WARM = ['#ffb040', '#ff4f8a', '#fff1dc', '#b45aff', '#ffd25a', '#ff5a3a'];
    // jagged lightning in screen space: V variants flicking on/off (discrete), bowed by bow px
    const bolt = (a, b, bow, n, amp, seed, T, w, gc) => { const Rn = rng(seed), V = 3; let s = '';
      for (let v = 0; v < V; v++) { const dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy) || 1;
        const pts = rep(n + 1, i => { const t = i / n, j = i === 0 || i === n ? 0 : (Rn() - 0.5) * 2 * amp; return [a[0] + dx * t - dy / L * j, a[1] + dy * t + dx / L * j - Math.sin(t * PI) * bow]; }), d = 'M' + pts.map(P2).join('L');
        s += `<g opacity="0">${anD('opacity', rep(V * 2, m => m === v * 2 ? 1 : 0).join(';'), n4(T))}<path d="${d}" stroke="${gc || '#d68aff'}" stroke-width="${f1(w * 3.4)}" opacity="0.5" filter="url(#l31b1)" fill="none"/><path d="${d}" stroke="#fff6fc" stroke-width="${f1(w)}" fill="none" stroke-linejoin="round"/></g>`; }
      return s; };

    // CLB-046 DMX MOVING-HEAD BEAM SPOTLIGHTS & STROBE BAR (T3): a matte black lighting stand (tripod legs with rubber feet, telescoping brushed
    // aluminium mast with a black locking knob) carrying a T-bar with two compact moving heads on top and a slim LED strobe bar beneath. A DMX
    // cable runs down the mast held with strips of gaffer tape to a little controller clamped halfway, its LEDs blinking. Live: the heads pan and
    // sweep tight warm beams (amber, rose, white, violet) in and out of step, and the strobe bar fires quick white bursts.
    N.dmx31 = S => { const D = { w: 62, d: 62, round: 1, act: 'party', party: 1, glow: () => ({ y: 96, r: 80, c: 'url(#gNeon)' }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('d46'), BK = '#1e1f24', AL = '#b8bcc4', TB = 104;
        const legs = [90, 210, 330].map(a => { const r = a * PI / 180, fx = 26 * Math.cos(r), fz = 26 * Math.sin(r);
          return { d: dep(C, fx, fz), s: line3(C, [[0, 36, 0], [fx * 0.9, 3, fz * 0.9], [fx, 1.2, fz]], 1.5, BK) + cyl3(C, [fx, 0, fz], [fx, 1.6, fz], 1.6, '#2a2a2a', { olw: 0.2 }) + line3(C, [[0, 44, 0], [fx * 0.35, 30, fz * 0.35]], 0.9, '#2a2b30') }; }).sort((a, b) => a.d - b.d);
        const mast = cyl3(C, [0, 30, 0], [0, 66, 0], 1.9, BK, { olw: 0.25 }) + cyl3(C, [0, 66, 0], [0, TB, 0], 1.3, AL, { mat: 'metal', olw: 0.2 }) + cyl3(C, [0, 64, 0], [0, 67, 0], 2.4, '#2a2b30', { olw: 0.2 })
          + line3(C, [[0, 65.5, 0], [3.6, 65.5, 0]], 0.9, '#2a2b30') + cyl3(C, [3.6, 64.4, 0], [3.6, 66.6, 0], 1.3, '#2a2b30', { olw: 0.2 });
        // DMX cable + gaffer tape + controller
        const cab = line3(C, [[-19, TB + 2, 1.5], [-10, TB - 1, 2.6], [1.6, TB - 6, 2.2], [2.2, 72, 2.2], [2.2, 38, 2.2], [9, 4, 12], [14, 0.4, 22]], 0.45, '#111114') + line3(C, [[19, TB + 2, 1.5], [10, TB - 1, 2.6], [2, TB - 6, 2.2]], 0.45, '#111114');
        const tape = [92, 80, 56, 44].map(y => cyl3(C, [0, y - 0.8, 0], [0, y + 0.8, 0], y > 66 ? 1.55 : 2.15, '#2c2c2e', { olw: 0.1 })).join('');
        const ctl = box3(C, { c: [0, 70, 4.4], w: 8, h: 5, d: 3, col: '#23242a', r: 0.5, dec: { f: `<rect width="8" height="5" fill="#23242a"/><rect x="0.8" y="0.8" width="3.8" height="1.6" fill="#3a2a10"/><text x="1" y="2.2" font-size="1.3" fill="#ffb040" font-family="monospace">A001</text>`
          + [5.4, 6.4].map((x, i) => `<circle cx="${x}" cy="1.6" r="0.35" fill="${i ? '#ff4f6a' : '#7ae89a'}">${an('opacity', '1;0.2;1', 0.7 + i * 0.4)}</circle>`).join('') + rep(4, i => `<circle cx="${1.4 + i * 1.7}" cy="3.8" r="0.5" fill="#55565e"/>`).join('') } });
        // T-bar + strobe bar
        const tbar = box3(C, { c: [0, TB, 0], w: 56, h: 2.4, d: 2.4, col: BK, r: 0.3 });
        const cells = rep(10, i => `<rect x="${1.2 + i * 3.76}" y="0.9" width="3.1" height="2.6" rx="0.3" fill="#e8e6e0"/><rect x="${1.2 + i * 3.76}" y="0.9" width="3.1" height="2.6" rx="0.3" fill="#ffffff" opacity="0">${anD('opacity', i % 2 ? '0;1;0;0;0;0;1;0;0;0;0;0' : '0;0;0;1;0;0;0;0;1;0;1;0', 1.2)}</rect>`).join('');
        const strobe = box3(C, { c: [0, TB - 6.6, 1.2], w: 40, h: 4.4, d: 3, col: '#202126', r: 0.4, dec: { f: `<rect width="40" height="4.4" fill="#202126"/>${cells}` } }) + line3(C, [[-14, TB - 2.2, 1.2], [-14, TB, 1.2]], 0.7, BK) + line3(C, [[14, TB - 2.2, 1.2], [14, TB, 1.2]], 0.7, BK);
        const sb = C.P([0, TB - 4.4, 4]);
        const flash = `<ellipse cx="${f1(sb[0])}" cy="${f1(sb[1])}" rx="${f1(40 * k)}" ry="${f1(14 * k)}" fill="#fff8f0" opacity="0" filter="url(#l31b3)">${anD('opacity', '0;0.6;0;0;0;0;0.5;0;0;0;0.45;0', 1.2)}</ellipse>`;
        // moving heads
        const head = (x, i) => { const hy = TB + 10.5, A = [0, 0.86, 0.51], c = [x, hy, 0], f = [x + A[0] * 5.6, hy + A[1] * 5.6, A[2] * 5.6], b = [x - A[0] * 4.6, hy - A[1] * 4.6, -A[2] * 4.6];
          const base = box3(C, { c: [x, TB + 1.2, 0], w: 9, h: 4.6, d: 9, col: '#24252b', r: 1 }), bp = C.P([x, TB + 5.8, 0]);
          const yoke = [-1, 1].map(s => ({ d: dep(C, x + s * 5.2, 0), s: box3(C, { c: [x + s * 5.2, TB + 5.6, 0], w: 1.3, h: 9.4, d: 3.4, col: '#2a2b31', r: 0.4 }) })).sort((p, q) => p.d - q.d);
          const lens = C.P(f), tip = C.P([x + A[0] * 110, hy + A[1] * 110, A[2] * 110]), dx = tip[0] - lens[0], dy = tip[1] - lens[1], L = Math.hypot(dx, dy) || 1, nx = -dy / L, ny = dx / L, W0 = 2 * k, W1 = 7 * k;
          const c0 = WARM[i * 2 % 6], c1 = WARM[(i * 2 + 1) % 6], c2 = WARM[(i * 2 + 3) % 6], cv = `${c0};${c1};${c2};${c0}`;
          const beam = `<path d="M${f1(lens[0] + nx * W0)} ${f1(lens[1] + ny * W0)}L${f1(tip[0] + nx * W1)} ${f1(tip[1] + ny * W1)}L${f1(tip[0] - nx * W1)} ${f1(tip[1] - ny * W1)}L${f1(lens[0] - nx * W0)} ${f1(lens[1] - ny * W0)}Z" fill="url(#${id}b${i})" style="mix-blend-mode:screen"/>`
            + `<path d="M${P2(lens)}L${P2(tip)}" stroke="${c0}" stroke-width="${f1(1.2 * k)}" opacity="0.55" style="mix-blend-mode:screen">${an('stroke', cv, 9, -i * 3)}</path>`;
          const hd = cyl3(C, b, f, 4.2, '#26272d', { mat: 'gloss', olw: 0.3, capCol: '#1a1a1e' }) + `<circle cx="${f1(lens[0])}" cy="${f1(lens[1])}" r="${f1(3 * k)}" fill="${c0}">${an('fill', cv, 9, -i * 3)}</circle><circle cx="${f1(lens[0])}" cy="${f1(lens[1])}" r="${f1(1.4 * k)}" fill="#ffffff" opacity="0.85"/><circle cx="${f1(lens[0])}" cy="${f1(lens[1])}" r="${f1(6 * k)}" fill="${c0}" opacity="0.4" filter="url(#l31b1)">${an('fill', cv, 9, -i * 3)}</circle>`;
          const front = A[2] * C.v[2] > 0, swp = `<g>${at('rotate', `${i ? 18 : -18} ${P2(bp)};${i ? -26 : 26} ${P2(bp)};${i ? 18 : -18} ${P2(bp)}`, 3.4 + i * 0.9, -i * 1.3, SPL(2))}`;
          const defs = `<linearGradient id="${id}b${i}" gradientUnits="userSpaceOnUse" x1="${f1(lens[0])}" y1="${f1(lens[1])}" x2="${f1(tip[0])}" y2="${f1(tip[1])}"><stop offset="0" stop-color="${c0}" stop-opacity="0.75">${an('stop-color', cv, 9, -i * 3)}</stop><stop offset="1" stop-color="${c0}" stop-opacity="0">${an('stop-color', cv, 9, -i * 3)}</stop></linearGradient>`;
          return { d: dep(C, x, 0), defs, s: base + yoke[0].s + swp + (front ? hd + beam : beam + hd) + `</g>` + yoke[1].s }; };
        const heads = [head(-19, 0), head(19, 1)].sort((p, q) => p.d - q.d);
        const haze = (() => { const p = C.P([0, TB + 40, 0]); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(60 * k)}" ry="${f1(30 * k)}" fill="#ffd8b0" opacity="0.1" filter="url(#l31b3)"/>`; })();
        const fr = C.v[2] >= 0;
        let s = shadow(C, 0, 0, 30, 30, 0.25) + haze + legs[0].s + legs[1].s + (fr ? '' : ctl) + mast + cab + tape + (fr ? ctl : '') + legs[2].s + tbar + heads[0].s + strobe + flash + heads[1].s;
        C.p(-30, 0, -30); C.p(30, 0, 30); C.p(0, TB + 60, 0);
        return { defs: DEFC + `<defs>${heads.map(h => h.defs).join('')}</defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-066 FULL-COLOR RGB ANIMATION LASER PROJECTOR & GIANT MIRROR SPHERE (T4): a round plinth of polished black marble with gold veins and a
    // brushed brass band, a fluted brass column with two collars, a laser projector in a gloss black and brass housing on a bracket halfway up,
    // and a giant mirror sphere turning on a brass motor hub at the top. Live: the sphere turns and throws warm specks round the room while the
    // projector draws sweeping fans, a turning star and blinking beam bursts in rose, amber, gold, violet and red.
    N.laser31 = S => { const D = { w: 60, d: 60, round: 1, zs: 1.2, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('l66'), R = rng('laser31'), BR = '#c9a24e', SY = 150, SR = 22;
        const marble = PLN(C, 6.05, `<circle r="16" fill="#141216"/>` + rep(5, () => { let x = (R() - 0.5) * 26, y = (R() - 0.5) * 26, d = `M${f1(x)} ${f1(y)}`; rep(5, () => { x += (R() - 0.5) * 8; y += (R() - 0.5) * 8; d += `L${f1(x)} ${f1(y)}`; }); return `<path d="${d}" stroke="#c8a456" stroke-width="0.25" fill="none" opacity="0.7"/>`; }).join('') + `<circle r="16" fill="url(#${id}m)"/>`);
        const plinth = cyl3(C, [0, 0, 0], [0, 4.6, 0], 19, '#16141a', { mat: 'gloss', olw: 0.3 }) + cyl3(C, [0, 4.6, 0], [0, 6, 0], 17.4, BR, { mat: 'metal', olw: 0.25 }) + cyl3(C, [0, 6, 0], [0, 6.05, 0], 16, '#16141a', { mat: 'gloss', olw: 0.2 }) + marble;
        const col = cyl3(C, [0, 6, 0], [0, 124, 0], 2.6, BR, { mat: 'metal', olw: 0.25 }) + [[-1.4, 0.25], [1.2, 0.25]].map(([dx]) => line3(C, [[dx * Math.cos(C.thV) , 8, -dx * Math.sin(C.thV)], [dx * Math.cos(C.thV), 122, -dx * Math.sin(C.thV)]], 0.25, '#8a6a2a', 'opacity="0.6"')).join('')
          + cyl3(C, [0, 58, 0], [0, 61, 0], 3.8, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [0, 120, 0], [0, 124, 0], 4, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [0, 124, 0], [0, 127.4, 0], 5.4, '#1c1a1e', { mat: 'gloss', olw: 0.25 });
        const proj = box3(C, { c: [0, 82, 4], w: 15, h: 9, d: 13, col: '#18171c', r: 1.2, dec: { f: `<rect width="15" height="9" fill="#18171c"/><rect x="0.4" y="0.4" width="14.2" height="8.2" rx="1" fill="none" stroke="${BR}" stroke-width="0.4"/><circle cx="7.5" cy="3.6" r="2.4" fill="#2a1a28" stroke="${BR}" stroke-width="0.35"/><circle cx="7.5" cy="3.6" r="1.1" fill="#fff0f4"/>`
          + rep(3, i => `<circle cx="${2 + i * 1.3}" cy="7.4" r="0.35" fill="${['#ff4f8a', '#ffb040', '#ffd25a'][i]}">${an('opacity', '1;0.3;1', 0.6 + i * 0.3)}</circle>`).join('') + `</g>`.slice(0, 0), t: `<rect width="15" height="13" fill="#1e1c22"/>${rep(5, i => `<rect x="2" y="${2 + i * 2}" width="11" height="0.7" rx="0.35" fill="#0c0b0e"/>`).join('')}` } })
          + box3(C, { c: [0, 80.6, -2.6], w: 4, h: 1.6, d: 3.6, col: BR, r: 0.3 });
        const o = C.P([0, 85.4, 10.6]);
        const fan = (n, c0, sp, sw, T, ph, L, cols, blink) => { const vals = cols.concat(cols[0]).join(';'); let core = '';
          rep(n, i => { const a = (c0 + (n > 1 ? (i / (n - 1) - 0.5) * 2 * sp : 0)) * PI / 180, e = [o[0] + Math.sin(a) * L * k, o[1] - Math.cos(a) * L * k]; core += `M${P2(o)}L${P2(e)}`; });
          return `<g>${blink ? anD('opacity', blink, 2.4, -ph) : ''}<g>${at('rotate', `${-sw} ${P2(o)};${sw} ${P2(o)};${-sw} ${P2(o)}`, T, -ph, SPL(2))}<path d="${core}" stroke="${cols[0]}" stroke-width="${f1(2.6 * k)}" opacity="0.35" filter="url(#l31b1)">${an('stroke', vals, 6, -ph)}</path><path d="${core}" stroke="${cols[0]}" stroke-width="${f1(0.7 * k)}">${an('stroke', vals, 6, -ph)}</path><path d="${core}" stroke="#ffffff" stroke-width="${f1(0.2 * k)}" opacity="0.7"/></g></g>`; };
        const star = `<g transform="translate(${P2(o)})"><g>${at('rotate', '0;360', 7)}` + rep(8, i => { const a = i * PI / 4, L = 52 * k; return `<path d="M0 0L${f1(Math.cos(a) * L)} ${f1(Math.sin(a) * L * 0.5 - L * 0.55)}" stroke="#ff4f8a" stroke-width="${f1(0.6 * k)}" opacity="0.8">${an('stroke', '#ff4f8a;#b45aff;#ffd25a;#ff4f8a', 5)}</path>`; }).join('') + `</g></g>`;
        const lasers = `<g style="mix-blend-mode:screen">${fan(7, -42, 16, 14, 3.2, 0, 92, ['#ffb040', '#ff4f8a', '#b45aff'])}${fan(7, 42, 16, 14, 3.6, 1.2, 92, ['#b45aff', '#ffd25a', '#ff4f8a'])}${fan(11, 0, 34, 6, 5, 0.6, 74, ['#ffd25a', '#ff5a3a', '#ffb040'], '1;0;1;1;0;0;1;0')}`
          + `<g opacity="0">${anD('opacity', '0;0;1;1;0;0;0;0', 4.8)}${star}</g>` + rep(10, i => { const q = [o[0] + (R() - 0.5) * 140 * k, o[1] - (20 + R() * 70) * k]; return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.9 * k)}" fill="${WARM[i % 6]}">${an('opacity', '0;1;0', 1 + R(), -R() * 2)}</circle>`; }).join('') + `</g>`;
        const sc = C.P([0, SY, 0]), Rp = SR * k, MB = mball(sc[0], sc[1], Rp, { env: [{ d: nrm(-0.6, 0.55, 0.6), c: '#fff4e4', p: 24, s: 1.4 }, { d: nrm(0.7, 0.2, 0.68), c: '#ff9ac0', p: 16, s: 0.8 }, { d: nrm(0.2, -0.6, 0.75), c: '#ffc860', p: 14, s: 0.8 }], F: 6, cols: 22, rows: 12, dt: 0.08, base: '#2c2630' });
        const hub = cyl3(C, [0, 127.4, 0], [0, SY - SR + 0.6, 0], 0.9, BR, { mat: 'metal', olw: 0.15 });
        const sk = `<g filter="url(#l31b1)" opacity="0.55">${specks(sc[0], sc[1] + 20 * k, 64 * k, 30 * k, 9, MB.T, ['#ffffff', '#ffd8e8'], 2.2 * k)}</g>` + specks(sc[0], sc[1] + 20 * k, 64 * k, 30 * k, 18, MB.T, ['#ffffff', '#ffe0c8', '#fff0c0', '#ffc8dc'], 1.8 * k);
        const halo = `<circle cx="${f1(sc[0])}" cy="${f1(sc[1])}" r="${f1(SR * 2 * k)}" fill="url(#${id}h)"/>`;
        const pool = PLN(C, 0.1, `<ellipse rx="40" ry="40" fill="url(#${id}p)">${an('opacity', '0.6;1;0.6', 4, 0, SPL(2))}</ellipse>`);
        const fr = C.v[2] >= 0;
        const s = pool + shadow(C, 0, 0, 20, 20, 0.3) + plinth + (fr ? col + proj : proj + col) + lasers + halo + hub + MB.s + sk;
        C.p(-24, 0, -24); C.p(24, 0, 24); C.p(0, SY + SR + 4, 0); C.p(-60, 150, 0); C.p(60, 150, 0);
        return { defs: DEFC + `<defs><radialGradient id="${id}m" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.22"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}h" cx="50%" cy="50%" r="50%"><stop offset="0.4" stop-color="#ffe8d8" stop-opacity="0.35"/><stop offset="1" stop-color="#ffe8d8" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}p" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ff8ab0" stop-opacity="0.3"/><stop offset="0.6" stop-color="#ffb060" stop-opacity="0.12"/><stop offset="1" stop-color="#ffb060" stop-opacity="0"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-086 VOLUMETRIC 3D HOLOGRAM DANCER & ION-PLASMA LIGHTNING GENERATOR (T5): a stepped emitter dais in gloss black lacquer with a brushed
    // champagne-gold band and a glowing gold lens, throwing a warm column of light in which a rose-gold hologram dancer (an original round-eared
    // figure drawn in light) grooves with scanlines and the odd glitch. Either side stands a lightning generator: walnut and brass base, a glass
    // tube with a copper coil and a polished brass sphere on top. Live: the dancer dances, light motes rise, ripples spread over the floor, and
    // rose-violet lightning arcs jump between the spheres and crackle into the air.
    N.holo31 = S => { const D = { w: 120, d: 50, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('h86'), GD = '#d8b46a', HC = '#ffb48a', LT = '#fff2e4', TX = 44, TZ = -4, TY = 60;
        const dais = cyl3(C, [0, 0, 0], [0, 3.6, 0], 26, '#141216', { mat: 'gloss', olw: 0.3 }) + cyl3(C, [0, 3.6, 0], [0, 5, 0], 24, GD, { mat: 'metal', olw: 0.25 }) + cyl3(C, [0, 5, 0], [0, 8, 0], 19, '#18161a', { mat: 'gloss', olw: 0.25 })
          + PLN(C, 8.05, `<circle r="12" fill="url(#${id}e)"/><g>${at('rotate', '0;360', 12)}${rep(3, i => `<circle r="${5 + i * 2.6}" fill="none" stroke="${GD}" stroke-width="0.35" stroke-dasharray="${2 + i} ${1.4 + i}" opacity="0.8"/>`).join('')}</g>`);
        const coil = x => { const base = box3(C, { c: [x, 0, TZ], w: 15, h: 5, d: 15, col: '#5a3820', r: 1.2 }) + box3(C, { c: [x, 5, TZ], w: 12, h: 1.4, d: 12, col: GD, r: 0.6 }),
            tube = cyl3(C, [x, 6.4, TZ], [x, 42, TZ], 4.6, '#c86a3a', { olw: 0.25 }) + rep(12, i => cyl3(C, [x, 9 + i * 2.7, TZ], [x, 9.8 + i * 2.7, TZ], 4.7, '#8a4a24', { olw: 0.1 })).join('') + cyl3(C, [x, 6.4, TZ], [x, 44, TZ], 6, '#f4f0ff', { mat: 'gloss', op: 0.22, olw: 0.2 }),
            cap = cyl3(C, [x, 44, TZ], [x, 46, TZ], 6.6, GD, { mat: 'metal', olw: 0.2 }) + cyl3(C, [x, 46, TZ], [x, 51, TZ], 1.2, GD, { mat: 'metal', olw: 0.15 }) + sph(C, [x, TY - 3, TZ], 6.2, '#e8cc88');
          return base + tube + cap; };
        const coils = [-1, 1].map(s => ({ d: dep(C, s * TX, TZ), s: coil(s * TX) }));
        const ft = C.P([0, 10, 0]), top = C.P([0, 88, 0]), ln = C.P([0, 8.4, 0]), tL = C.P([-TX, TY + 2, TZ]), tR = C.P([TX, TY + 2, TZ]);
        const limb = (d, pv, vals) => `<g>${at('rotate', vals.split(';').map(v => v + ' ' + pv).join(';'), 1.2)}<path d="${d}" fill="none" stroke="${HC}" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" opacity="0.75"/><path d="${d}" fill="none" stroke="${LT}" stroke-width="0.9" stroke-linecap="round" stroke-linejoin="round"/></g>`;
        const fig = `<g>${at('rotate', '-5 0 0;5 0 0;-5 0 0', 2.4)}<g>${at('translate', '0 0;0 -2.6;0 0;0 -2.6;0 0', 1.2)}`
          + limb('M-2 -26L-5 -13L-6 0', '-2 -26', '0;-14;0;6;0') + limb('M2 -26L5 -13L6 0', '2 -26', '0;-6;0;14;0') + limb('M5 -40L10 -32L12 -24', '5 -40', '-20;-70;-25;-135;-20')
          + `<ellipse cx="0" cy="-33" rx="6.4" ry="9" fill="${HC}" fill-opacity="0.42" stroke="${LT}" stroke-width="0.9"/><ellipse cx="0" cy="-33" rx="6.4" ry="9" fill="url(#${id}s)"/>`
          + limb('M-5 -40L-10 -32L-12 -24', '-5 -40', '20;110;160;110;20')
          + `<g>${at('rotate', '-9 0 -44;9 0 -44;-9 0 -44', 1.2)}<circle cx="-5.2" cy="-56" r="2.7" fill="${HC}" fill-opacity="0.5" stroke="${LT}" stroke-width="0.8"/><circle cx="5.2" cy="-56" r="2.7" fill="${HC}" fill-opacity="0.5" stroke="${LT}" stroke-width="0.8"/>`
          + `<circle cx="0" cy="-50" r="6.8" fill="${HC}" fill-opacity="0.45" stroke="${LT}" stroke-width="0.9"/><circle cx="0" cy="-50" r="6.8" fill="url(#${id}s)"/><path d="M-3.4 -50.6q1-1.2 2 0M1.4 -50.6q1-1.2 2 0M-1.6 -47.4q1.6 1.4 3.2 0" fill="none" stroke="${LT}" stroke-width="0.8" stroke-linecap="round"/></g></g></g>`;
        let h = `<path d="M${f1(ln[0] - 6 * k)} ${f1(ln[1])}L${f1(top[0] - 26 * k)} ${f1(top[1])}L${f1(top[0] + 26 * k)} ${f1(top[1])}L${f1(ln[0] + 6 * k)} ${f1(ln[1])}Z" fill="url(#${id}c)">${an('opacity', '0.7;1;0.75;0.95;0.7', 2.2)}</path>`;
        h += `<g>${anD('opacity', '0.95;0.95;0.95;0.45;0.95;0.95;0.95;0.95;0.2;0.9', 3.1)}<g><animateTransform attributeName="transform" type="translate" values="0 0;0 0;${f1(1.4 * k)} 0;0 0;0 0;${f1(-k)} 0;0 0" dur="2.7s" calcMode="discrete" repeatCount="indefinite"/>`
          + `<g transform="translate(${P2(ft)}) scale(${n4(k)})"><g filter="url(#l31b1)" opacity="0.6">${fig}</g>${fig}</g></g></g>`;
        rep(10, i => { const x = (i % 5 - 2) * 4.4, e0 = C.P([x, 10, i % 2 ? 4 : -4]), d = 2.2 + (i % 3) * 0.5; h += `<circle cx="${f1(e0[0])}" cy="${f1(e0[1])}" r="${f1(0.6 * k)}" fill="#fff0dc">${an('cy', `${f1(e0[1])};${f1(e0[1] - 70 * k)}`, d, -i * 0.37)}${an('opacity', '0;1;0', d, -i * 0.37)}</circle>`; });
        let z = '';
        [tL, tR].forEach((t, i) => { z += `<circle cx="${f1(t[0])}" cy="${f1(t[1])}" r="${f1(8 * k)}" fill="#e08aff" opacity="0.4" filter="url(#l31b1)">${an('opacity', '0.2;0.55;0.25;0.5;0.2', 0.9, -i * 0.3)}</circle>`; });
        z += bolt(tL, tR, 34 * k, 16, 4 * k, 'h86a', 1.6, 1.2 * k, '#e08aff') + bolt(tL, tR, 22 * k, 14, 5 * k, 'h86b', 2.2, 0.8 * k, '#ff8ac8');
        [[-1, -26, -14], [-1, -12, -28], [-1, -30, 6], [1, 26, -14], [1, 12, -28], [1, 30, 6]].forEach(([s, dx, dy], i) => { const t = s < 0 ? tL : tR; z += bolt(t, [t[0] + dx * k, t[1] + dy * k], (i % 2 ? 4 : -4) * k, 6, 3 * k, 'h86' + i, 1 + (i % 3) * 0.25, 0.7 * k, i % 2 ? '#ff8ac8' : '#c88aff'); });
        const ripple = PLN(C, 0.2, rep(3, j => `<ellipse rx="26" ry="26" fill="none" stroke="#ffb48a" stroke-width="0.8">${an('rx', '26;56', 2.4, -j * 0.8)}${an('ry', '26;56', 2.4, -j * 0.8)}${an('opacity', '0.7;0', 2.4, -j * 0.8)}</ellipse>`).join(''));
        coils.sort((a, b) => a.d - b.d);
        const backC = coils.filter(c => c.d < 0).map(c => c.s).join(''), frontC = coils.filter(c => c.d >= 0).map(c => c.s).join('');
        const s = ripple + shadow(C, 0, 0, 30, 30, 0.3) + shadow(C, -TX, TZ, 10, 10, 0.3) + shadow(C, TX, TZ, 10, 10, 0.3) + backC + dais + h + frontC + z;
        C.p(-TX - 12, 0, TZ - 10); C.p(TX + 12, 0, TZ + 10); C.p(0, 92, 0); C.p(-TX - 30, TY + 20, TZ); C.p(TX + 30, TY + 20, TZ);
        return { defs: DEFC + `<defs><radialGradient id="${id}e" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff4e0"/><stop offset="0.5" stop-color="#ffc888"/><stop offset="1" stop-color="#b07040"/></radialGradient>`
          + `<linearGradient id="${id}c" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffc898" stop-opacity="0.5"/><stop offset="1" stop-color="#ffc898" stop-opacity="0.02"/></linearGradient>`
          + `<pattern id="${id}s" width="4" height="2.4" patternUnits="userSpaceOnUse"><rect width="4" height="0.7" fill="#ffffff" opacity="0.35"/><animateTransform attributeName="patternTransform" type="translate" values="0 0;0 -2.4" dur="0.6s" repeatCount="indefinite"/></pattern></defs>`, front: s, bb: C.bb(3) }; };
      return D; };
  }


  // ======================= CLUB AUDIO (CLB-002/022/042/062/082): fx-only, footprints + party flags kept (002 paPro had none; 022 speaker + 042
  // spkWall carry the spk() party set: act party, party 1, bass 1, anim pulse, glow when on) =======================
  { const { box3: B10, cyl3, sph, shadow, FR, yawA } = RD.H10;
    const DEFA = '<filter id="a31b1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.8"/></filter><filter id="a31b3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>';
    const dep = (C, x, z) => x * C.v[0] + z * C.v[2];
    const line3 = (C, P, w, col, ex) => `<path d="M${P.map(p => P2(C.P(p))).join('L')}" stroke="${col}" stroke-width="${f1(w * C.k)}" fill="none" stroke-linecap="round" stroke-linejoin="round"${ex ? ' ' + ex : ''}/>`;
    const PLN = (C, y, svg, x, z) => `<g transform="${FR(C, [x || 0, y, z || 0], [1, 0, 0], [0, 0, 1])}">${svg}</g>`;
    const anD = (a, v, d, b) => `<animate attributeName="${a}" values="${v}" dur="${d}s" calcMode="discrete"${b ? ` begin="${n4(b)}s"` : ''} repeatCount="indefinite"/>`;
    const SPK = { act: 'party', party: 1, bass: 1, anim: 'pulse', glow: v => v === 'on' ? { y: 70, r: 90, c: 'url(#gNeon)' } : null };
    const tiltX = a => [[1, 0, 0], [0, Math.cos(a), Math.sin(a)], [0, -Math.sin(a), Math.cos(a)]];
    const tiltZ = a => [[Math.cos(a), Math.sin(a), 0], [-Math.sin(a), Math.cos(a), 0], [0, 0, 1]];
    // pumping cone in face-local units: centre (x, y), radius r, beat T, phase b
    const cone = (id, x, y, r, T, b, o) => { o = o || {}; const kt = o.kt || '0;0.12;0.3;1', v = o.v || '1;0.9;1;1';
      return `<circle cx="${x}" cy="${y}" r="${n4(r + 0.9)}" fill="${o.rim || '#3a3b40'}"/><circle cx="${x}" cy="${y}" r="${n4(r + 0.2)}" fill="#141418"/>`
        + `<g transform="translate(${x} ${y})"><g><animateTransform attributeName="transform" type="scale" values="${v}" keyTimes="${kt}" dur="${T}s" begin="${-b}s" repeatCount="indefinite"/>`
        + `<circle r="${n4(r)}" fill="#26272c"/><circle r="${n4(r * 0.94)}" fill="url(#${id}k)"/>${rep(3, i => `<circle r="${n4(r * (0.4 + i * 0.18))}" fill="none" stroke="#000" stroke-width="0.12" opacity="0.4"/>`).join('')}<circle r="${n4(r * 0.3)}" fill="url(#${id}d)"/></g></g>`; };
    const coneDefs = id => `<radialGradient id="${id}k" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#5a5c64"/><stop offset="0.6" stop-color="#34353b"/><stop offset="1" stop-color="#1c1d21"/></radialGradient><radialGradient id="${id}d" cx="38%" cy="32%" r="70%"><stop offset="0" stop-color="#9a9ca6"/><stop offset="1" stop-color="#2a2b30"/></radialGradient>`;

    // CLB-002 SINGLE CRACKLING PORTABLE PA SPEAKER ON TRIPOD (T1): a battered off-brand plastic PA box leaning a little on a cheap wobbly tripod.
    // Scuffed black plastic with a cracked top corner held together with silver duct tape, a dented perforated grille over the woofer, a peeling
    // star sticker and a moulded top handle; on the side panel one knob is missing (bare shaft) and the power light flickers. The tripod clamp is
    // reinforced with zip ties, one leg has a tape repair, and the power cord trails off into a tangle on the floor. Live: the woofer pumps
    // unevenly, the box buzzes and crackles with little static sparks, the light flickers.
    N.pa31 = S => { const D = { w: 56, d: 54, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('p02'), R = rng('pa31'), BK = '#24252a', CW = 30, CH = 42, CD = 24, CY = 80, A = tiltZ(-0.06);
        const legs = [90, 210, 330].map((a, i) => { const r = a * PI / 180, fx = 24 * Math.cos(r), fz = 24 * Math.sin(r);
          return { d: dep(C, fx, fz), s: line3(C, [[0, 34, 0], [fx * 0.92, 2.4, fz * 0.92], [fx, 0.8, fz]], 1.3, '#2c2d32') + cyl3(C, [fx, 0, fz], [fx, 1.4, fz], 1.4, '#1a1a1a', { olw: 0.2 }) + line3(C, [[0, 42, 0], [fx * 0.4, 27, fz * 0.4]], 0.7, '#3a3b40')
            + (i === 1 ? line3(C, [[fx * 0.5, 18.4, fz * 0.5], [fx * 0.55, 15.6, fz * 0.55]], 2.2, '#a8a8a2') : '') }; }).sort((a, b) => a.d - b.d);
        const mast = cyl3(C, [0, 26, 0], [0, 56, 0], 1.7, '#2a2b30', { olw: 0.25 }) + cyl3(C, [0, 56, 0], [0, CY + 1, 0], 1.2, '#9a9ca2', { mat: 'metal', olw: 0.2 }) + cyl3(C, [0, 54, 0], [0, 58, 0], 2.3, '#1e1f23', { olw: 0.2 })
          + cyl3(C, [0, 55, 0], [0, 56.2, 0], 2.5, '#f0ece0', { olw: 0.1 }) + cyl3(C, [0, 57, 0], [0, 57.8, 0], 2.5, '#f0ece0', { olw: 0.1 }) + line3(C, [[2.3, 55.6, 0], [3.6, 55.2, 0.4]], 0.35, '#f0ece0');
        // front face
        const grid = `<pattern id="${id}g" width="1.2" height="1.2" patternUnits="userSpaceOnUse"><rect width="1.2" height="1.2" fill="#1a1b1f"/><circle cx="0.6" cy="0.6" r="0.36" fill="#000" opacity="0.9"/></pattern>`;
        const front = `<rect width="${CW}" height="${CH}" fill="${BK}"/>`
          + `<rect x="7" y="4" width="16" height="7" rx="1.4" fill="#141418"/><path d="M9 5.4h12l-2 4.2h-8Z" fill="#0a0a0c"/>`
          + `<g opacity="0.85">${cone(id, 15, 27.5, 10.2, 0.52, 0, { v: '1;0.88;1;1;0.94;1;1', kt: '0;0.1;0.25;0.5;0.6;0.72;1' })}</g>`
          + `<rect x="3" y="15" width="24" height="25" rx="1.6" fill="url(#${id}g)" opacity="0.72"/><rect x="3" y="15" width="24" height="25" rx="1.6" fill="none" stroke="#3a3b40" stroke-width="0.5"/>`
          + `<ellipse cx="20.5" cy="33" rx="3.6" ry="2.6" fill="#000" opacity="0.45"/><path d="M17.4 31.4q3 -1.6 6.2 0.4" stroke="#6a6b70" stroke-width="0.35" fill="none"/>`
          + `<g transform="translate(6.4 36.6) rotate(-14)"><path d="M0 -2.4L0.7 -0.8L2.4 -0.7L1.1 0.4L1.5 2.1L0 1.2L-1.5 2.1L-1.1 0.4L-2.4 -0.7L-0.7 -0.8Z" fill="#f0c040"/><path d="M0.9 1.4L1.9 2.6L1 2.8Z" fill="#c8c0a8"/></g>`
          + rep(9, () => { const x = R() * CW, y = R() * CH; return `<path d="M${f1(x)} ${f1(y)}l${f1((R() - 0.5) * 5)} ${f1((R() - 0.5) * 2)}" stroke="#6a6b72" stroke-width="0.18" opacity="0.6"/>`; }).join('')
          + `<path d="M${CW - 9} 0L${CW} 0L${CW} 7L${CW - 2} 8L${CW - 10} 1.4Z" fill="#a9aaa6"/><path d="M${CW - 9} 0.8l7.6 6.2M${CW - 7} 0.4l6.6 5" stroke="#c8c9c4" stroke-width="0.25" opacity="0.8"/><path d="M${CW - 10} 1.4l-0.6 0.9l1 0.3l-0.4 0.8" stroke="#8a8b86" stroke-width="0.3" fill="none"/>`;
        const side = `<rect width="${CD}" height="${CH}" fill="#202125"/><rect x="3" y="6" width="${CD - 6}" height="22" rx="1" fill="#17181b"/>`
          + [[7, 11, 1], [12, 11, 1], [17, 11, 0]].map(([x, y, ok]) => ok ? `<circle cx="${x}" cy="${y}" r="1.7" fill="#3a3b40"/><path d="M${x} ${y}l0 -1.5" stroke="#d8d8d0" stroke-width="0.35"/>` : `<circle cx="${x}" cy="${y}" r="0.5" fill="#8a8a88"/><circle cx="${x}" cy="${y}" r="1.7" fill="none" stroke="#2a2b30" stroke-width="0.3" stroke-dasharray="0.6 0.6"/>`).join('')
          + `<circle cx="8" cy="19" r="2.4" fill="#0c0c0e" stroke="#4a4b50" stroke-width="0.4"/><circle cx="15" cy="19" r="1.6" fill="#0c0c0e" stroke="#4a4b50" stroke-width="0.35"/><circle cx="20" cy="24" r="0.7" fill="#ff4a3a">${an('opacity', '1;0.2;1;1;0.1;1', 2.3, 0, KT('0;0.05;0.1;0.6;0.65;1'))}</circle>`
          + `<path d="M3 32h18" stroke="#2a2b30" stroke-width="0.4"/><path d="M5 34.4h6" stroke="#55565c" stroke-width="0.25"/>`;
        const top = `<rect width="${CW}" height="${CD}" fill="#2a2b30"/><rect x="${CW - 9}" y="0" width="9" height="6" fill="#a9aaa6"/>`;
        const cab = B10(C, { c: [0, CY, 0], ax: A, w: CW, h: CH, d: CD, col: BK, r: 2.2, mat: 'noise', gl: 0.08, dec: { f: front, r: side, l: side, t: top } });
        const hp = (u, v, s) => [A[0][0] * u + A[1][0] * v, CY + A[0][1] * u + A[1][1] * v, A[2][2] * s];
        const handle = line3(C, [hp(-7, CH, 0), hp(-6, CH + 3.2, 0), hp(6, CH + 3.2, 0), hp(7, CH, 0)], 1.4, '#1c1d21');
        // cable from the back to a floor tangle
        const cab0 = hp(4, 8, -CD / 2), cable = line3(C, [cab0, [6, CY - 8, -14], [8, 40, -12], [12, 3, -16], [16, 0.4, -20]], 0.5, '#111113')
          + PLN(C, 0.3, `<path d="M0 0c6 -4 12 2 6 6c-7 4 -12 -4 -4 -7c8 -2 10 8 2 9c-6 0 -6 -6 1 -5M6 6c4 3 10 5 20 3" stroke="#111113" stroke-width="0.55" fill="none"/>`, 14, -22);
        // crackle sparks + buzz
        const sp = C.P(hp(CW / 2 + 1, CH * 0.7, CD / 2)), sp2 = C.P(hp(-CW / 2 - 1, CH * 0.35, CD / 2));
        const crack = [[sp, 1], [sp2, -1]].map(([p, sg], i) => `<g opacity="0">${anD('opacity', i ? '0;0;0;0;1;0;0;1;0;0;0;0' : '0;1;0;0;0;0;1;1;0;0;0;0', 1.7)}<path d="M${f1(p[0])} ${f1(p[1])}l${f1(sg * 2.4 * k)} ${f1(-1.2 * k)}l${f1(-sg * 0.8 * k)} ${f1(1.8 * k)}l${f1(sg * 2.6 * k)} ${f1(-0.6 * k)}M${f1(p[0] + sg * 1.4 * k)} ${f1(p[1] + 2.4 * k)}l${f1(sg * 1.8 * k)} ${f1(0.8 * k)}" stroke="#fff4c8" stroke-width="${f1(0.35 * k)}" fill="none"/><circle cx="${f1(p[0] + sg * 2 * k)}" cy="${f1(p[1])}" r="${f1(2.4 * k)}" fill="#ffe08a" opacity="0.35" filter="url(#a31b1)"/></g>`).join('');
        const wC = C.P(hp(0, CH * 0.35, CD / 2 + 4)), waves = rep(3, j => `<ellipse cx="${f1(wC[0])}" cy="${f1(wC[1])}" rx="${f1(6 * k)}" ry="${f1(8 * k)}" fill="none" stroke="#e8e0d0" stroke-width="${f1(0.3 * k)}">${an('rx', `${f1(8 * k)};${f1(22 * k)}`, 1.3, -j * 0.43)}${an('ry', `${f1(10 * k)};${f1(26 * k)}`, 1.3, -j * 0.43)}${an('opacity', '0.4;0', 1.3, -j * 0.43)}</ellipse>`).join('');
        const buzz = `<animateTransform attributeName="transform" type="translate" values="0 0;${f1(0.3 * k)} 0;0 0;${f1(-0.25 * k)} ${f1(0.15 * k)};0 0" dur="0.26s" calcMode="discrete" repeatCount="indefinite"/>`;
        const fr = C.v[2] >= 0;
        const s = shadow(C, 0, 0, 26, 26, 0.25) + PLN(C, 0.25, `<path d="M-4 -2l3 -1.4l3 1.6" stroke="#5a4a30" stroke-width="0.4" fill="none" opacity="0"/>`) + (fr ? cable : '') + legs[0].s + legs[1].s + mast + legs[2].s + (fr ? '' : cable) + `<g>${buzz}${cab}${handle}</g>` + waves + crack;
        C.p(-26, 0, -26); C.p(26, 0, 26); C.p(0, CY + CH + 5, 0); C.p(-18, CY + 20, 0); C.p(18, CY + 20, 0);
        return { defs: DEFA + `<defs>${grid}${coneDefs(id)}</defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-022 PAIR OF 12-INCH ACTIVE CLUB MONITORS (T2): two matching black monitor cabinets in textured paint, toed in a little on rubber
    // isolation pads atop a low black carpeted riser. Each has an exposed 12-inch woofer with a steel rim and screws, a flared horn waveguide
    // above it, a bass port slot and a small amber power light; a cable runs between them, and a can of soda sits on the riser. Live: both woofers
    // pump to the beat, the dust caps throb, sound rings spread and a warm glow pulses along the riser's front edge.
    N.mon31 = S => { const D = Object.assign({ w: 54, d: 40, zs: 1.15, build: () => [] }, SPK);
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('m22'), BK = '#25262b', RH = 7, CW = 21, CH = 36, CD = 25;
        const riser = B10(C, { c: [0, 0, 0], w: 54, h: RH, d: 38, col: '#1c1c20', r: 1, mat: 'foam', dec: { f: `<rect width="54" height="${RH}" fill="none"/><rect y="${RH - 1.2}" width="54" height="1.2" fill="#ffb060" opacity="0.4">${an('opacity', '0.15;0.6;0.15;0.15', 0.6, 0, KT('0;0.15;0.5;1'))}</rect>` } });
        const mon = (sx, b) => { const x = sx * 14.4, A = yawA(-sx * 0.14), z = -2;
          const front = `<rect width="${CW}" height="${CH}" fill="${BK}"/>`
            + `<ellipse cx="${CW / 2}" cy="8" rx="8.4" ry="5" fill="#1a1b1f" stroke="#3a3b40" stroke-width="0.4"/><ellipse cx="${CW / 2}" cy="8" rx="6.2" ry="3.4" fill="url(#${id}h)"/><ellipse cx="${CW / 2}" cy="8" rx="2" ry="1.3" fill="#08080a"/>`
            + cone(id, CW / 2, 23.4, 8.2, 0.6, b, { rim: '#8a8c94' }) + [[2.4, 15], [18.6, 15], [2.4, 32], [18.6, 32]].map(([u, v]) => `<circle cx="${u}" cy="${v}" r="0.45" fill="#a8aab2"/>`).join('')
            + `<rect x="5.5" y="33.6" width="10" height="1.3" rx="0.65" fill="#0a0a0c"/><circle cx="${CW - 2.4}" cy="2.4" r="0.55" fill="#ffb040">${an('opacity', '0.7;1;0.7', 2, -b)}</circle>`;
          const cab = B10(C, { c: [x, RH + 1.4, z], ax: A, w: CW, h: CH, d: CD, col: BK, r: 1.6, mat: 'noise', gl: 0.06, dec: { f: front } });
          const pads = [-1, 1].map(px => cyl3(C, [x + px * 8, RH, z], [x + px * 8, RH + 1.4, z], 2.6, '#3a2a24', { olw: 0.15 })).join('');
          const wc = C.P([x - sx * 1.5, RH + 1.4 + 13, z + CD / 2 + 2]);
          const rings = rep(3, j => `<ellipse cx="${f1(wc[0])}" cy="${f1(wc[1])}" rx="${f1(7 * k)}" ry="${f1(7 * k)}" fill="none" stroke="#ffe0c0" stroke-width="${f1(0.3 * k)}">${an('rx', `${f1(9 * k)};${f1(20 * k)}`, 1.2, -j * 0.4 - b)}${an('ry', `${f1(9 * k)};${f1(20 * k)}`, 1.2, -j * 0.4 - b)}${an('opacity', '0.25;0', 1.2, -j * 0.4 - b)}</ellipse>`).join('');
          return { d: dep(C, x, z), s: pads + cab, r: rings }; };
        const M = [mon(-1, 0), mon(1, 0.3)].sort((a, b) => a.d - b.d);
        const cable = line3(C, [[-6, RH + 4, -15], [-2, RH + 0.4, -17], [3, RH + 0.4, -17], [6, RH + 4, -15]], 0.5, '#101012');
        const can = cyl3(C, [0, RH, 8], [0, RH + 6.2, 8], 1.6, '#c8382c', { mat: 'metal', olw: 0.2 }) + cyl3(C, [0, RH + 6.2, 8], [0, RH + 6.8, 8], 1.45, '#c8c8cc', { mat: 'metal', olw: 0.15 });
        const fr = C.v[2] >= 0;
        const s = shadow(C, 0, 0, 30, 22, 0.3) + riser + (fr ? cable : '') + M[0].s + (fr ? '' : cable) + can + M[1].s + M[0].r + M[1].r;
        C.p(-28, 0, -20); C.p(28, 0, 20); C.p(0, RH + CH + 4, 0);
        return { defs: DEFA + `<defs>${coneDefs(id)}<radialGradient id="${id}h" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#050506"/><stop offset="0.7" stop-color="#2a2b30"/><stop offset="1" stop-color="#4a4b52"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-042 STACKED HORN-LOADED BASS BINS & LINE-ARRAY TOWERS (T3): in the middle a 2 x 2 stack of big folded-horn bass bins in black textured
    // paint with steel corner protectors, each horn mouth folding back into a deep throat where the driver works; either side a ground-stacked
    // line array: a sub base and eight slim curved elements on brushed-steel splay hinges under a flybar, perforated grilles and little status
    // lights. Live: the drivers pump deep in the horns, pressure ripples roll out of the mouths, the arrays' lights flicker and the floor dust hops.
    N.bins31 = S => { const D = Object.assign({ w: 214, d: 52, pivot: [0, 70, 26], build: () => [] }, SPK);
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('b42'), BK = '#1e1f23', ST = '#a8acb4';
        const grille = `<pattern id="${id}g" width="1" height="1" patternUnits="userSpaceOnUse"><rect width="1" height="1" fill="#2a2b30"/><circle cx="0.5" cy="0.5" r="0.3" fill="#0c0c0e"/></pattern>`;
        const hornF = (W, H, b) => { const m = 2.4;
          return `<rect width="${W}" height="${H}" fill="${BK}"/><rect x="${m}" y="${m}" width="${W - 2 * m}" height="${H - 2 * m}" fill="#0a0a0c"/>`
            + `<path d="M${m} ${m}H${W - m}L${W * 0.62} ${H * 0.38}H${W * 0.38}Z" fill="#4a4b52"/><path d="M${m} ${H - m}H${W - m}L${W * 0.62} ${H * 0.62}H${W * 0.38}Z" fill="#18181c"/><path d="M${m} ${m}V${H - m}L${W * 0.38} ${H * 0.62}V${H * 0.38}Z" fill="#34353b"/><path d="M${W - m} ${m}V${H - m}L${W * 0.62} ${H * 0.62}V${H * 0.38}Z" fill="#2a2b30"/>`
            + `<path d="M${m} ${m}L${W * 0.38} ${H * 0.38}M${W - m} ${m}L${W * 0.62} ${H * 0.38}M${m} ${H - m}L${W * 0.38} ${H * 0.62}M${W - m} ${H - m}L${W * 0.62} ${H * 0.62}" stroke="#5a5b62" stroke-width="0.35"/>`
            + `<rect x="${W * 0.38}" y="${H * 0.38}" width="${W * 0.24}" height="${H * 0.24}" fill="#060607"/>` + cone(id, W / 2, H / 2, H * 0.1, 0.5, b, { rim: '#2a2b30', v: '1;0.8;1;1' })
            + `<path d="M${W / 2} ${m}V${H * 0.38}" stroke="#2c2d32" stroke-width="1.2"/>` + [[0, 0], [W - 4, 0], [0, H - 4], [W - 4, H - 4]].map(([u, v]) => `<rect x="${u}" y="${v}" width="4" height="4" fill="${ST}"/><circle cx="${u + 2}" cy="${v + 2}" r="0.5" fill="#55575e"/>`).join(''); };
        const sideH = (Dd, H) => `<rect width="${Dd}" height="${H}" fill="${BK}"/><rect x="${Dd / 2 - 6}" y="${H / 2 - 2}" width="12" height="4" rx="2" fill="#0c0c0e"/><path d="M${Dd / 2 - 4.6} ${H / 2}h9.2" stroke="${ST}" stroke-width="1"/>`
          + [[0, 0], [Dd - 4, 0], [0, H - 4], [Dd - 4, H - 4]].map(([u, v]) => `<rect x="${u}" y="${v}" width="4" height="4" fill="${ST}"/>`).join('');
        const bins = []; [0, 1].forEach(row => [-1, 1].forEach(sx => { const x = sx * 24, y = row * 34, b = (row * 2 + (sx > 0)) * 0.07;
          bins.push({ d: dep(C, x, 0) + row * 1000, s: B10(C, { c: [x, y, 0], w: 48, h: 34, d: 46, col: BK, r: 0.6, mat: 'noise', gl: 0.05, dec: { f: hornF(48, 34, b), l: sideH(46, 34), r: sideH(46, 34), t: `<rect width="48" height="46" fill="#24252a"/><path d="M4 8h40M4 38h40" stroke="#55575e" stroke-width="0.8"/>` } }) }); }));
        bins.sort((a, b) => a.d - b.d);
        // ripples out of the horn mouths
        const rip = rep(2, i => { const c = C.P([i ? 24 : -24, 17 + (i ? 34 : 0), 26]); return rep(3, j => `<ellipse cx="${f1(c[0])}" cy="${f1(c[1])}" rx="${f1(12 * k)}" ry="${f1(9 * k)}" fill="none" stroke="#ffd8b0" stroke-width="${f1(0.4 * k)}">${an('rx', `${f1(14 * k)};${f1(34 * k)}`, 1, -j * 0.33 - i * 0.5)}${an('ry', `${f1(10 * k)};${f1(24 * k)}`, 1, -j * 0.33 - i * 0.5)}${an('opacity', '0.25;0', 1, -j * 0.33 - i * 0.5)}</ellipse>`).join(''); }).join('');
        // line arrays
        const array = sx => { const x = sx * 83, parts = [];
          parts.push(B10(C, { c: [x, 0, -2], w: 42, h: 28, d: 44, col: BK, r: 0.6, mat: 'noise', gl: 0.05, dec: { f: `<rect width="42" height="28" fill="${BK}"/><rect x="3" y="3" width="36" height="22" rx="1" fill="url(#${id}g)"/>${cone(id, 21, 14, 8, 0.5, 0.2, { rim: '#2a2b30', v: '1;0.88;1;1' })}<rect x="3" y="3" width="36" height="22" rx="1" fill="url(#${id}g)" opacity="0.6"/>` } }));
          let c = [x, 28, -2], a = 0;
          rep(8, i => { const A = tiltX(a), el = B10(C, { c: c.slice(), ax: A, w: 38, h: 8.2, d: 30, col: '#202126', r: 0.4, gl: 0.08,
              dec: { f: `<rect width="38" height="8.2" fill="#202126"/><rect x="1.4" y="1" width="35.2" height="6.2" rx="0.6" fill="url(#${id}g)"/><path d="M1.4 4.1h35.2" stroke="#3a3b40" stroke-width="0.3"/><circle cx="35.6" cy="1.6" r="0.4" fill="${i % 3 ? '#7ae89a' : '#ffb040'}">${an('opacity', '1;0.3;1', 0.5 + (i % 4) * 0.23, -i * 0.2)}</circle>`,
                l: `<rect width="30" height="8.2" fill="#26272c"/><rect x="2" y="1" width="6" height="6.2" fill="${ST}"/><circle cx="5" cy="4.1" r="0.8" fill="#55575e"/>`, r: `<rect width="30" height="8.2" fill="#26272c"/><rect x="22" y="1" width="6" height="6.2" fill="${ST}"/><circle cx="25" cy="4.1" r="0.8" fill="#55575e"/>` } });
            parts.push(el); c = [c[0] + A[1][0] * 8.4, c[1] + A[1][1] * 8.4, c[2] + A[1][2] * 8.4]; a += 0.022 + i * 0.006; });
          parts.push(B10(C, { c: c.slice(), ax: tiltX(a), w: 36, h: 1.6, d: 24, col: '#5a5d64', r: 0.3, gl: 0.15 }) + line3(C, [[c[0] - 12, c[1] + 1.6, c[2]], [c[0], c[1] + 6, c[2]], [c[0] + 12, c[1] + 1.6, c[2]]], 0.5, '#8a8d94'));
          C.p(x, c[1] + 8, c[2]);
          return { d: dep(C, x, 0), s: parts.join('') }; };
        const arrs = [array(-1), array(1)];
        const all = arrs.concat([{ d: 0, s: bins.map(b => b.s).join('') }]).sort((a, b) => a.d - b.d);
        const dust = rep(14, i => { const q = C.P([(i / 13 - 0.5) * 200, 0.4, 30 + (i % 3) * 3]); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.4 * k)}" fill="#c8c0b0">${an('cy', `${f1(q[1])};${f1(q[1] - 2.4 * k)};${f1(q[1])};${f1(q[1])}`, 0.5, -i * 0.05, KT('0;0.15;0.35;1'))}</circle>`; }).join('');
        const s = shadow(C, 0, 2, 110, 30, 0.3) + all.map(o => o.s).join('') + rip + dust;
        C.p(-108, 0, -26); C.p(108, 0, 26); C.p(0, 70, 0);
        return { defs: DEFA + `<defs>${coneDefs(id)}${grille}</defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    const isOn = S => /(^|\|)(on|play)$/.test(S.st || '');
    const GLD = (id, a, b) => `<linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a || '#f6e2a8'}"/><stop offset="0.45" stop-color="${b || '#c89a48'}"/><stop offset="0.7" stop-color="#e8c87c"/><stop offset="1" stop-color="#8a6428"/></linearGradient>`;
    // a soft light band sliding across a face (face units W x H), clipped to it
    const glint = (cid, W, H, T, b) => `<clipPath id="${cid}"><rect width="${W}" height="${H}"/></clipPath><g clip-path="url(#${cid})"><rect x="-14" y="${-H}" width="8" height="${H * 3}" fill="#fff6dc" opacity="0.28" transform="rotate(24 0 0)">${an('x', `-${n4(W * 0.6 + 14)};${n4(W * 1.6)};${n4(W * 1.6)}`, T, -b, KT('0;0.4;1'))}</rect></g>`;

    // CLB-062 GOLD-ANODIZED ACOUSTIC WALL STACK (T4): a three-box horn stack in piano-black lacquer with champagne-gold anodised horns: a folded
    // bass horn at the bottom, a big square mid-range flare with a bullet phase plug, and twin round treble horns either side of a slim ribbon on
    // top; gold edge trims and pinstripes, standing on gold spikes on a black marble plinth. Live: the drivers pump in the throats, warm light
    // breathes deep in the horns and a soft glint slides across the gold.
    N.gold31 = S => { const D = Object.assign({ w: 70, d: 50, pivot: [0, 75, 24], zs: 1.2, build: () => [] }, SPK);
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('g62'), BK = '#141317', W = 64, Dd = 44, PH = 5;
        const gl = `url(#${id}a)`, pin = (w, h) => `<rect x="1" y="1" width="${w - 2}" height="${h - 2}" fill="none" stroke="#c8a050" stroke-width="0.3" opacity="0.7"/>`;
        const bass = `<rect width="${W}" height="40" fill="${BK}"/>${pin(W, 40)}<rect x="4" y="4" width="${W - 8}" height="32" fill="${gl}"/>`
          + `<path d="M5.5 5.5H${W - 5.5}L${W * 0.6} 17H${W * 0.4}Z" fill="#f2dca0"/><path d="M5.5 34.5H${W - 5.5}L${W * 0.6} 23H${W * 0.4}Z" fill="#7a5a24"/><path d="M5.5 5.5V34.5L${W * 0.4} 23V17Z" fill="#c89a48"/><path d="M${W - 5.5} 5.5V34.5L${W * 0.6} 23V17Z" fill="#a8803c"/>`
          + `<rect x="${W * 0.4}" y="17" width="${W * 0.2}" height="6" fill="#0a0806"/><rect x="${W * 0.4}" y="17" width="${W * 0.2}" height="6" fill="#ffb060" opacity="0.2">${an('opacity', '0.1;0.4;0.1', 3, 0, SPL(2))}</rect>${cone(id, W / 2, 20, 2.6, 0.5, 0, { rim: '#6a5020', v: '1;0.78;1;1' })}` + glint(id + 'q0', W, 40, 6, 0);
        const mid = `<rect width="${W}" height="34" fill="${BK}"/>${pin(W, 34)}<rect x="9" y="2.5" width="${W - 18}" height="29" rx="3" fill="url(#${id}m)"/>`
          + rep(4, i => `<rect x="${9 + i * 3.4}" y="${2.5 + i * 2.4}" width="${W - 18 - i * 6.8}" height="${29 - i * 4.8}" rx="${3 - i * 0.5}" fill="none" stroke="#fff0c8" stroke-width="0.25" opacity="${0.5 - i * 0.1}"/>`).join('')
          + `<circle cx="${W / 2}" cy="17" r="6" fill="#0a0806"/><circle cx="${W / 2}" cy="17" r="6" fill="#ffb060" opacity="0.15">${an('opacity', '0.08;0.35;0.08', 2.4, -0.6, SPL(2))}</circle>${cone(id, W / 2, 17, 5, 0.5, 0.15, { rim: '#6a5020' })}<circle cx="${W / 2}" cy="17" r="2.2" fill="url(#${id}b)"/>` + glint(id + 'q1', W, 34, 6, 1);
        const top = `<rect width="${W}" height="20" fill="${BK}"/>${pin(W, 20)}` + [16, W - 16].map(x => `<circle cx="${x}" cy="10" r="8.4" fill="url(#${id}m)"/><circle cx="${x}" cy="10" r="5" fill="none" stroke="#fff0c8" stroke-width="0.3" opacity="0.5"/><circle cx="${x}" cy="10" r="2.2" fill="#0a0806"/><circle cx="${x}" cy="10" r="1" fill="url(#${id}b)"/>`).join('')
          + `<rect x="${W / 2 - 3}" y="3" width="6" height="14" rx="0.8" fill="#0c0b0e" stroke="#c8a050" stroke-width="0.4"/>${rep(6, i => `<path d="M${W / 2 - 2 + i * 0.8} 4v12" stroke="#4a4030" stroke-width="0.25"/>`).join('')}` + glint(id + 'q2', W, 20, 6, 2);
        const side = (h) => `<rect width="${Dd}" height="${h}" fill="${BK}"/><rect x="1.2" y="1.2" width="${Dd - 2.4}" height="${h - 2.4}" fill="none" stroke="#c8a050" stroke-width="0.3" opacity="0.6"/>`;
        const tp = `<rect width="${W}" height="${Dd}" fill="#1a191d"/><rect x="1.2" y="1.2" width="${W - 2.4}" height="${Dd - 2.4}" fill="none" stroke="#c8a050" stroke-width="0.35" opacity="0.7"/>`;
        const box = (y, h, f) => B10(C, { c: [0, y, 0], w: W, h, d: Dd, col: BK, r: 0.6, gl: 0.22, dec: { f, l: side(h), r: side(h), t: tp } });
        const plinth = B10(C, { c: [0, 0, 0], w: W + 6, h: 2.4, d: Dd + 6, col: '#151418', r: 0.6, gl: 0.3, dec: { t: `<rect width="${W + 6}" height="${Dd + 6}" fill="#151418"/>${rep(4, i => `<path d="M${4 + i * 17} 2q6 ${10 + i * 3} -2 ${Dd}" stroke="#d8c8a8" stroke-width="0.25" fill="none" opacity="0.4"/>`).join('')}` } });
        const spikes = [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([sx, sz]) => ({ d: dep(C, sx, sz), s: cyl3(C, [sx * (W / 2 - 4), 2.4, sz * (Dd / 2 - 4)], [sx * (W / 2 - 4), PH, sz * (Dd / 2 - 4)], 1.6, '#d8b060', { mat: 'metal', r2: 0.4, olw: 0.15 }) })).sort((a, b) => a.d - b.d).map(o => o.s).join('');
        const stack = box(PH, 40, bass) + box(PH + 40.4, 34, mid) + box(PH + 74.8, 20, top);
        const wC = C.P([0, PH + 57, Dd / 2 + 4]), rings = rep(3, j => `<ellipse cx="${f1(wC[0])}" cy="${f1(wC[1])}" rx="${f1(12 * k)}" ry="${f1(10 * k)}" fill="none" stroke="#ffe0b0" stroke-width="${f1(0.35 * k)}">${an('rx', `${f1(14 * k)};${f1(34 * k)}`, 1.1, -j * 0.37)}${an('ry', `${f1(11 * k)};${f1(28 * k)}`, 1.1, -j * 0.37)}${an('opacity', '0.25;0', 1.1, -j * 0.37)}</ellipse>`).join('');
        const s = shadow(C, 0, 0, 40, 30, 0.3) + plinth + spikes + stack + rings;
        C.p(-38, 0, -28); C.p(38, 0, 28); C.p(0, PH + 96, 0);
        return { defs: DEFA + `<defs>${coneDefs(id)}${GLD(id + 'a')}<radialGradient id="${id}m" cx="50%" cy="50%" r="60%"><stop offset="0" stop-color="#5a4218"/><stop offset="0.3" stop-color="#a8803c"/><stop offset="0.7" stop-color="#e8cc88"/><stop offset="1" stop-color="#f6e2a8"/></radialGradient><radialGradient id="${id}b" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="#fff4d0"/><stop offset="1" stop-color="#a8803c"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-082 OMNIDIRECTIONAL SONIC-BEAM & SUB-HARMONIC LEVITATION BASS REACTORS (T5): two tapering towers of smoked obsidian glass ringed with
    // champagne-gold driver bands, each band split by a warm amber light seam, capped with a polished dome and gold finial; between them a black-gold
    // sphere floats over a gold-ringed emitter disc. Live: amber light runs up the seams, pressure rings ripple out of the towers, warm sonic beams
    // ripple from the towers to the sphere, the sphere bobs and turns its glint, and rings roll across the floor (the haze ring is the fog system).
    N.react31 = S => { const D = { w: 150, d: 70, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('r82'), TX = 44, TZ = -6, GD = '#d8b468', SY = 42, SR = 13;
        const tower = x => { let s = cyl3(C, [x, 0, TZ], [x, 4, TZ], 11, '#141216', { mat: 'gloss', olw: 0.3 }) + cyl3(C, [x, 4, TZ], [x, 5.2, TZ], 10, GD, { mat: 'metal', olw: 0.2 });
          const segs = [5.2, 22, 39, 56, 73, 90], rr = y => 8 - (y - 5) * 0.022;
          segs.forEach((y0, i) => { if (i === segs.length - 1) return; const y1 = segs[i + 1] - 2.4;
            s += cyl3(C, [x, y0, TZ], [x, y1, TZ], rr(y0), '#1a1820', { mat: 'gloss', r2: rr(y1), olw: 0.25 }) + cyl3(C, [x, y1, TZ], [x, y1 + 2.4, TZ], rr(y1) + 0.6, GD, { mat: 'metal', olw: 0.2 });
            const c = C.P([x, y1 + 1.2, TZ]); s += `<ellipse cx="${f1(c[0])}" cy="${f1(c[1])}" rx="${f1((rr(y1) + 0.7) * k)}" ry="${f1((rr(y1) + 0.7) * k * 0.45)}" fill="none" stroke="#ffb060" stroke-width="${f1(0.6 * k)}" opacity="0.3">${an('opacity', '0.15;0.9;0.15;0.15', 2, -i * 0.25, KT('0;0.15;0.4;1'))}</ellipse>`;
            const dc = C.P([x, (y0 + y1) / 2, TZ]); s += `<ellipse cx="${f1(dc[0])}" cy="${f1(dc[1])}" rx="${f1(3.6 * k)}" ry="${f1(5 * k)}" fill="#0a090c" stroke="${GD}" stroke-width="${f1(0.4 * k)}"/><ellipse cx="${f1(dc[0])}" cy="${f1(dc[1])}" rx="${f1(2 * k)}" ry="${f1(2.8 * k)}" fill="#2a2630"><animate attributeName="rx" values="${f1(2 * k)};${f1(2.6 * k)};${f1(2 * k)};${f1(2 * k)}" keyTimes="0;0.12;0.3;1" dur="0.5s" repeatCount="indefinite"/></ellipse>`; });
          s += sph(C, [x, 92, TZ], 6.4, '#26222a') + cyl3(C, [x, 98, TZ], [x, 103, TZ], 0.9, GD, { mat: 'metal', r2: 0.2, olw: 0.15 });
          const pc = C.P([x, 50, TZ]); s += rep(3, j => `<ellipse cx="${f1(pc[0])}" cy="${f1(pc[1])}" rx="${f1(10 * k)}" ry="${f1(26 * k)}" fill="none" stroke="#ffd8a0" stroke-width="${f1(0.35 * k)}">${an('rx', `${f1(10 * k)};${f1(30 * k)}`, 1.4, -j * 0.47)}${an('ry', `${f1(30 * k)};${f1(46 * k)}`, 1.4, -j * 0.47)}${an('opacity', '0.35;0', 1.4, -j * 0.47)}</ellipse>`).join('');
          return { d: dep(C, x, TZ), s }; };
        const T = [tower(-TX), tower(TX)].sort((a, b) => a.d - b.d);
        const disc = cyl3(C, [0, 0, 4], [0, 3, 4], 18, '#141216', { mat: 'gloss', olw: 0.3 }) + PLN(C, 3.05, `<circle r="16" fill="url(#${id}e)"/><circle r="16.6" fill="none" stroke="${GD}" stroke-width="1"/><g>${at('rotate', '0;360', 14)}<circle r="11" fill="none" stroke="#f0d08a" stroke-width="0.35" stroke-dasharray="3 2"/></g>`, 0, 4);
        const sc = C.P([0, SY, 4]), Rp = SR * k;
        const beam = (sx, b) => { const t = C.P([sx * TX, 56, TZ]), mx = (t[0] + sc[0]) / 2, my = (t[1] + sc[1]) / 2 - 8 * k; return `<path d="M${P2(t)}Q${f1(mx)} ${f1(my)} ${P2(sc)}" stroke="#ffc070" stroke-width="${f1(2.4 * k)}" fill="none" opacity="0.3" filter="url(#a31b1)"/><path d="M${P2(t)}Q${f1(mx)} ${f1(my)} ${P2(sc)}" stroke="#fff0d0" stroke-width="${f1(0.6 * k)}" fill="none" stroke-dasharray="${f1(2 * k)} ${f1(3 * k)}">${an('stroke-dashoffset', `0;${f1(-10 * k)}`, 0.6, -b)}</path>`; };
        const sphere = `<g>${at('translate', `0 0;0 ${f1(-3 * k)};0 0`, 4, 0, SPL(2))}<circle cx="${f1(sc[0])}" cy="${f1(sc[1])}" r="${f1(Rp * 1.8)}" fill="url(#${id}h)"/><circle cx="${f1(sc[0])}" cy="${f1(sc[1])}" r="${f1(Rp)}" fill="url(#${id}s)"/>`
          + `<ellipse cx="${f1(sc[0])}" cy="${f1(sc[1])}" rx="${f1(Rp)}" ry="${f1(Rp * 0.28)}" fill="none" stroke="${GD}" stroke-width="${f1(0.8 * k)}"/><ellipse cx="${f1(sc[0])}" cy="${f1(sc[1])}" rx="${f1(Rp * 0.28)}" ry="${f1(Rp)}" fill="none" stroke="${GD}" stroke-width="${f1(0.4 * k)}" opacity="0.7"><animate attributeName="rx" values="${f1(Rp * 0.28)};${f1(Rp)};${f1(Rp * 0.28)}" dur="6s" repeatCount="indefinite"/></ellipse>`
          + `<ellipse cx="${f1(sc[0] - Rp * 0.35)}" cy="${f1(sc[1] - Rp * 0.4)}" rx="${f1(Rp * 0.28)}" ry="${f1(Rp * 0.18)}" fill="#ffffff" opacity="0.55"/></g>`;
        const floorR = PLN(C, 0.2, rep(3, j => `<ellipse rx="18" ry="18" fill="none" stroke="#ffc888" stroke-width="0.7">${an('rx', '18;70', 2.4, -j * 0.8)}${an('ry', '18;40', 2.4, -j * 0.8)}${an('opacity', '0.5;0', 2.4, -j * 0.8)}</ellipse>`).join(''), 0, 4);
        const glowB = PLN(C, 3.2, `<ellipse rx="14" ry="14" fill="#ffc070" opacity="0.4" filter="url(#a31b3)">${an('opacity', '0.25;0.55;0.25', 4, 0, SPL(2))}</ellipse>`, 0, 4);
        const s = floorR + shadow(C, -TX, TZ, 13, 13, 0.3) + shadow(C, TX, TZ, 13, 13, 0.3) + T[0].s + disc + glowB + beam(-1, 0) + beam(1, 0.3) + sphere + T[1].s;
        C.p(-TX - 14, 0, TZ - 14); C.p(TX + 14, 0, TZ + 14); C.p(0, 104, 0); C.p(-60, 50, 0); C.p(60, 50, 0);
        return { defs: DEFA + `<defs><radialGradient id="${id}e" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff0d0"/><stop offset="0.5" stop-color="#ffb868"/><stop offset="1" stop-color="#6a4020"/></radialGradient>`
          + `<radialGradient id="${id}s" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#6a5a48"/><stop offset="0.35" stop-color="#2a2228"/><stop offset="0.8" stop-color="#0e0c10"/><stop offset="1" stop-color="#4a3820"/></radialGradient>`
          + `<radialGradient id="${id}h" cx="50%" cy="50%" r="50%"><stop offset="0.5" stop-color="#ffc070" stop-opacity="0.35"/><stop offset="1" stop-color="#ffc070" stop-opacity="0"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-010 OSCILLATING FAN WITH SOAP-BUBBLE WAND (T1): a cheap pedestal fan gone yellow with age: a cracked round base with a strip of tape and
    // a row of piano-key switches (one stuck down), a scuffed pole, grey dust on the blades and a bent bit of cage taped back. Someone has wired
    // a yellow plastic bubble wheel to the pole with a twisted coat hanger, its rings dipping into a pink tray of soapy water. Live: the head
    // turns side to side with the blades whirring, the wheel turns through the soap and bubbles drift off (more when switched on).
    N.bfan31 = S => { const on = isOn(S), D = { w: 60, d: 50, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('f10'), R = rng('bfan31'), PL = '#e6dcc0', HY = 70, GR = 17;
        const base = cyl3(C, [0, 0, 0], [0, 3, 0], 15, PL, { olw: 0.35 }) + PLN(C, 3.05, `<path d="M-6 4l3 -1.4l1.6 2l3.4 -1" stroke="#8a7a58" stroke-width="0.3" fill="none"/><rect x="-11" y="-4" width="6" height="2.4" fill="#cfc6b4" opacity="0.9" transform="rotate(-20)"/>` + rep(4, i => `<rect x="${-4 + i * 2.6}" y="7" width="2.2" height="3.6" rx="0.4" fill="${i === 1 ? '#a89c84' : '#f2ead8'}" stroke="#a89c84" stroke-width="0.2"/>`).join('') + `<circle r="15" fill="url(#${id}d)"/>`);
        const pole = cyl3(C, [0, 3, 0], [0, 42, 0], 1.6, '#d8ceb4', { olw: 0.3 }) + cyl3(C, [0, 40, 0], [0, 43, 0], 2.2, PL, { olw: 0.25 }) + cyl3(C, [0, 43, 0], [0, HY - 5, 0], 1.2, '#b8b4ac', { mat: 'metal', olw: 0.2 });
        // head: motor + cage + blades, oscillating
        const cc = C.P([0, HY, 4]), pv = C.P([0, HY - 5, 0]);
        const cage = (z, dense) => `<g transform="${FR(C, [0, HY, z], [1, 0, 0], [0, -1, 0])}"><circle r="${GR}" fill="none" stroke="#d8ceb0" stroke-width="0.7"/>${rep(3, i => `<circle r="${GR * (0.3 + i * 0.22)}" fill="none" stroke="#cfc5a8" stroke-width="0.3"/>`).join('')}${rep(dense ? 18 : 10, i => { const a = i / (dense ? 18 : 10) * 2 * PI; return `<path d="M${n4(Math.cos(a) * 3)} ${n4(Math.sin(a) * 3)}L${n4(Math.cos(a) * GR)} ${n4(Math.sin(a) * GR)}" stroke="#cfc5a8" stroke-width="0.25"/>`; }).join('')}`
          + (dense ? `<circle r="3.4" fill="${PL}" stroke="#b8ae94" stroke-width="0.3"/><path d="M${GR - 2} -6q2.4 2 1.4 5" stroke="#b8ae94" stroke-width="0.5" fill="none"/><rect x="${GR - 4}" y="-4" width="4.4" height="2.4" fill="#d8d0bc" opacity="0.95" transform="rotate(30 ${GR - 2} -3)"/>` : '') + `</g>`;
        const blades = `<g transform="${FR(C, [0, HY, 2], [1, 0, 0], [0, -1, 0])}"><g><animateTransform attributeName="transform" type="rotate" values="0;360" dur="${on ? 0.24 : 0.5}s" repeatCount="indefinite"/>` + rep(3, i => `<path d="M0 0C4 -3 13 -5 14 -1C14 3 6 3 0 0Z" fill="#cbe0e8" opacity="0.75" stroke="#9ab4c0" stroke-width="0.2" transform="rotate(${i * 120})"/><path d="M6 -2.6C9 -3.2 12 -3 13 -1.4" stroke="#8a8a80" stroke-width="0.5" fill="none" opacity="0.5" transform="rotate(${i * 120})"/>`).join('') + `<circle r="3" fill="#d8ceb4"/></g><circle r="${GR - 1}" fill="#e0ecf0" opacity="0.12"/></g>`;
        const motor = cyl3(C, [0, HY, -9], [0, HY, -1], 5.4, PL, { olw: 0.3, r2: 4.6 }) + cyl3(C, [0, HY - 5, -4], [0, HY - 3.6, -4], 2, '#d8ceb4', { olw: 0.2 });
        const fr = C.v[2] >= 0, head = fr ? motor + cage(-0.5, 0) + blades + cage(4.4, 1) : cage(4.4, 1) + blades + cage(-0.5, 0) + motor;
        const osc = `<g>${at('rotate', `-11 ${P2(pv)};11 ${P2(pv)};-11 ${P2(pv)}`, 7, 0, SPL(2))}${head}</g>`;
        // coat hanger arm, bubble wheel + tray in front of the pole
        const WC = [7, 51, 14], tray = B10(C, { c: [7, 41, 14], w: 16, h: 3.4, d: 8, col: '#f08ab0', r: 1.2, gl: 0.2, dec: { t: `<rect width="16" height="8" fill="#f8c8dc"/><rect x="1" y="1" width="14" height="6" rx="1" fill="url(#${id}s)"/>` } });
        const hanger = line3(C, [[0, 36, 0], [3, 36.4, 4], [5, 39, 12], [6, 41, 14]], 0.4, '#9a9ca2') + line3(C, [[0, 52, 0], [3, 52.4, 6], [WC[0], WC[1], WC[2] - 1.2]], 0.4, '#9a9ca2') + cyl3(C, [0, 35, 0], [0, 37, 0], 1.9, '#9a9ca2', { olw: 0.1 });
        const wheel = `<g transform="${FR(C, WC, [1, 0, 0], [0, -1, 0])}"><g><animateTransform attributeName="transform" type="rotate" values="0;360" dur="5s" repeatCount="indefinite"/>` + rep(6, i => { const a = i / 6 * 2 * PI, x = Math.cos(a) * 7, y = Math.sin(a) * 7; return `<path d="M0 0L${n4(x * 0.7)} ${n4(y * 0.7)}" stroke="#f4c430" stroke-width="0.7"/><circle cx="${n4(x)}" cy="${n4(y)}" r="2.2" fill="url(#${id}f)" stroke="#f4c430" stroke-width="0.6"/>`; }).join('') + `<circle r="1.6" fill="#f4c430" stroke="#c89a20" stroke-width="0.3"/></g></g>`;
        const b0 = C.P([WC[0], WC[1] + 6, WC[2] + 1]), NB = on ? 16 : 9;
        const bubbles = rep(NB, i => { const r = (1 + R() * 2.4) * k, T = 3 + R() * 3, dx = (24 + R() * 40) * k, dy = -(16 + R() * 34) * k, b = -i * T / NB;
          return `<g opacity="0">${an('opacity', '0;0.95;0.9;0', T, b, KT('0;0.1;0.8;1'))}<g>${at('translate', `0 0;${f1(dx * 0.5)} ${f1(dy * 0.6)};${f1(dx)} ${f1(dy)}`, T, b, SPL(2))}<circle cx="${f1(b0[0])}" cy="${f1(b0[1])}" r="${f1(r)}" fill="url(#${id}b)" stroke="#ffffff" stroke-width="${f1(0.15 * k)}" stroke-opacity="0.8"/><circle cx="${f1(b0[0] - r * 0.35)}" cy="${f1(b0[1] - r * 0.35)}" r="${f1(r * 0.22)}" fill="#ffffff" opacity="0.85"/></g></g>`; }).join('');
        const cord = line3(C, [[-3, 1.4, -14], [-8, 0.4, -20], [-16, 0.3, -18], [-24, 0.3, -24]], 0.45, '#efe6d0');
        const s = shadow(C, 0, 0, 18, 18, 0.25) + cord + base + (fr ? pole + osc + hanger + tray + wheel : tray + hanger + wheel + pole + osc) + bubbles;
        C.p(-22, 0, -22); C.p(22, 0, 22); C.p(0, HY + GR + 2, 0); C.p(50, 90, 0);
        return { defs: DEFA + `<defs><radialGradient id="${id}d" cx="35%" cy="35%" r="75%"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#8a7a50" stop-opacity="0.18"/></radialGradient>`
          + `<radialGradient id="${id}b" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="0.7" stop-color="#ffd8f0" stop-opacity="0.18"/><stop offset="0.85" stop-color="#d0e8ff" stop-opacity="0.45"/><stop offset="1" stop-color="#ffe0a0" stop-opacity="0.7"/></radialGradient>`
          + `<radialGradient id="${id}f" cx="50%" cy="50%" r="50%"><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="1" stop-color="#ffe0f0" stop-opacity="0.6"/></radialGradient>`
          + `<linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffe8f4"/><stop offset="0.5" stop-color="#f8b8d4"/><stop offset="1" stop-color="#ffffff"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // soft smoke puffs in screen space: from o drifting by (dx, dy), growing r0 -> r1, n staggered over T
    const puffs = (o, dx, dy, n, T, r0, r1, col, op, b0) => rep(n, i => { const b = -(b0 || 0) - i * T / n, j = ((i * 37) % 10) / 10 - 0.5;
      return `<circle cx="${f1(o[0])}" cy="${f1(o[1])}" r="${f1(r0)}" fill="${col}" opacity="0" filter="url(#a31b3)">${an('r', `${f1(r0)};${f1(r1)}`, T, b)}${an('opacity', `0;${op};${n4(op * 0.6)};0`, T, b, KT('0;0.15;0.6;1'))}${at('translate', `0 0;${f1(dx * 0.55 + j * Math.abs(dy) * 0.4)} ${f1(dy * 0.55 + j * 6)};${f1(dx + j * Math.abs(dy) * 0.6)} ${f1(dy)}`, T, b, SPL(2))}</circle>`; }).join('');

    // CLB-030 COMPACT HALLOWEEN MINI FOG MACHINE (T2): a little black plastic fog box from a seasonal shop: scuffed body with vent slats, a carry
    // handle, an orange pumpkin badge, a translucent bottle of purple fog juice half full plugged into the top, a brass nozzle with a sticky drip
    // under it, and a wired remote with a coiled cord lying on the floor beside a small puddle of fluid. A plastic toy spider sits on top. Live:
    // the ready light blinks, the nozzle glows and short light puffs drift out (more when switched on).
    N.fogm31 = S => { const on = isOn(S), D = { w: 70, d: 48, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('f30'), R = rng('fogm31'), BK = '#222226', BW = 44, BH = 17, BD = 26;
        const front = `<rect width="${BW}" height="${BH}" fill="${BK}"/>${rep(9, i => `<rect x="${4 + i * 2.4}" y="4" width="1.2" height="9" rx="0.6" fill="#0c0c0e"/>`).join('')}`
          + `<circle cx="32" cy="8.6" r="4.4" fill="#f08a28" stroke="#a85a14" stroke-width="0.4"/><path d="M29.6 7.4l1 -1.2l1 1.2ZM32.4 7.4l1 -1.2l1 1.2ZM29.4 9.8q2.6 1.8 5.2 0" fill="#3a1a08" stroke="#3a1a08" stroke-width="0.4"/><path d="M32 4.2v-1" stroke="#4a7a2a" stroke-width="0.6"/>`
          + `<circle cx="40" cy="13" r="0.6" fill="#5aff8a">${an('opacity', '1;0.2;1', 1.2)}</circle>` + rep(6, () => `<path d="M${f1(R() * BW)} ${f1(R() * BH)}l${f1((R() - 0.5) * 4)} ${f1((R() - 0.5) * 1.4)}" stroke="#55565c" stroke-width="0.2"/>`).join('')
          + `<rect x="2" y="12.4" width="5" height="3" rx="0.4" fill="#f4e8c8" opacity="0.85" transform="rotate(-6 4 14)"/><rect x="2.6" y="13.2" width="3.4" height="0.5" fill="#c84020" opacity="0.6" transform="rotate(-6 4 14)"/>`;
        const side = `<rect width="${BD}" height="${BH}" fill="${BK}"/>${rep(6, i => `<rect x="${5 + i * 2.6}" y="5" width="1.2" height="8" rx="0.6" fill="#0c0c0e"/>`).join('')}`;
        const body = B10(C, { c: [0, 2.2, 0], w: BW, h: BH, d: BD, col: BK, r: 2, mat: 'noise', gl: 0.12, dec: { f: front, b: front, l: side, r: side } });
        const feet = [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([a, b]) => cyl3(C, [a * 18, 0, b * 10], [a * 18, 2.2, b * 10], 1.8, '#111', { olw: 0.15 })).join('');
        const T0 = 2.2 + BH, nz = [BW / 2, 11, 0];
        const nozzle = cyl3(C, [BW / 2 - 1, 11, 0], [BW / 2 + 5, 11, 0], 2.6, '#1a1a1e', { olw: 0.2 }) + cyl3(C, [BW / 2 + 4, 11, 0], [BW / 2 + 5.6, 11, 0], 1.6, '#c8a050', { mat: 'metal', olw: 0.2 });
        const tip = C.P([BW / 2 + 5.8, 11, 0]), drip = C.P([BW / 2 + 4.6, 9.6, 1.4]);
        const dripS = `<path d="M${f1(drip[0])} ${f1(drip[1])}q${f1(0.4 * k)} ${f1(1.6 * k)} 0 ${f1(2.4 * k)}q${f1(-0.4 * k)} ${f1(-0.8 * k)} 0 ${f1(-2.4 * k)}Z" fill="#b8a0d8" opacity="0.7"/>`;
        const glow = `<circle cx="${f1(tip[0])}" cy="${f1(tip[1])}" r="${f1(3 * k)}" fill="#ff9a40" opacity="0.5" filter="url(#a31b1)">${an('opacity', '0.25;0.6;0.25', 2.4)}</circle>`;
        const bottle = cyl3(C, [-10, T0, 4], [-10, T0 + 11, 4], 4.2, '#d8c8f0', { mat: 'gloss', op: 0.45, olw: 0.25 }) + cyl3(C, [-10, T0, 4], [-10, T0 + 5.4, 4], 3.8, '#9a6ad8', { op: 0.7, olw: 0 }) + cyl3(C, [-10, T0 + 11, 4], [-10, T0 + 13.4, 4], 2.2, '#f08a28', { olw: 0.2 });
        const handle = line3(C, [[-16, T0, -6], [-15, T0 + 6, -6], [8, T0 + 6, -6], [9, T0, -6]], 2, '#2a2b30') + line3(C, [[-15, T0 + 6.5, -6], [8, T0 + 6.5, -6]], 0.5, '#5a5b62');
        const sp = C.P([4, T0 + 0.8, 6]), spider = `<g transform="translate(${P2(sp)}) scale(${n4(k)})"><ellipse rx="1.6" ry="1.1" fill="#0a0a0a"/><circle cx="1.6" cy="-0.2" r="0.8" fill="#0a0a0a"/>${rep(4, i => `<path d="M${-0.8 + i * 0.6} -0.6q${-1 + i * 0.5} -1.6 ${-2 + i * 1} -0.6M${-0.8 + i * 0.6} 0.6q${-1 + i * 0.5} 1.6 ${-2 + i * 1} 0.8" stroke="#0a0a0a" stroke-width="0.25" fill="none"/>`).join('')}<circle cx="1.9" cy="-0.4" r="0.18" fill="#ff3a2a"/></g>`;
        const remote = B10(C, { c: [14, 0, 21], w: 7, h: 2.2, d: 11, col: '#1c1c20', r: 1, dec: { t: `<rect width="7" height="11" fill="#1c1c20"/><circle cx="3.5" cy="3.4" r="1.4" fill="#e83a2a"/><circle cx="3.5" cy="7.4" r="1" fill="#3ac85a"/>` } });
        const cord = line3(C, [[-BW / 2 + 2, 6, BD / 2 - 2], [-14, 0.4, 18], [-6, 0.4, 24], [2, 0.4, 20], [10.6, 1, 21]], 0.4, '#101012') + PLN(C, 0.3, `<path d="M0 0c2 -2 4 0 2 2c-2 2 -4 0 -2 -2m1.6 0c2 -2 4 0 2 2c-2 2 -4 0 -2 -2" stroke="#101012" stroke-width="0.4" fill="none"/>`, -8, 22);
        const puddle = PLN(C, 0.15, `<path d="M0 0c3 -2 7 -1 8 1c1 2 -3 3 -6 2.4c-2 -0.4 -3 -2 -2 -3.4Z" fill="#c8b8e8" opacity="0.4"/>`, 27, 6);
        const out = puffs(tip, (on ? 70 : 34) * k, -8 * k, on ? 8 : 4, on ? 3 : 4.4, 2 * k, (on ? 16 : 10) * k, '#f4f0f8', on ? 0.7 : 0.4);
        const fr = C.v[2] >= 0;
        const s = shadow(C, 0, 0, 26, 16, 0.3) + puddle + cord + remote + feet + body + (fr ? handle + bottle : bottle + handle) + nozzle + dripS + glow + spider + out;
        C.p(-26, 0, -15); C.p(30, 0, 28); C.p(0, T0 + 14, 0); C.p(70, 20, 0);
        return { defs: DEFA, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-050 HIGH-OUTPUT CLUB HAZE MACHINE & UV BLACKLIGHT CANNONS (T3): a sleek matte black hazer with brushed aluminium carry rails, a fan grille
    // and a small amber readout, sitting on a black road case with aluminium edging, ball corners and butterfly latches; beside it two compact UV
    // cannons on floor yokes tilted up at the room. Live: the hazer's fan turns and haze drifts out of the nozzle (thicker when on), the UV
    // cannons breathe a violet glow and their beams pick out fluorescent specks.
    N.haze31 = S => { const on = isOn(S), D = { w: 130, d: 80, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('h50'), R = rng('haze31'), CX = -22, AL = '#b8bcc4';
        const caseF = (w, h) => `<rect width="${w}" height="${h}" fill="#1c1d21"/><rect width="${w}" height="1.6" fill="${AL}"/><rect y="${h - 1.6}" width="${w}" height="1.6" fill="${AL}"/>` + [w * 0.25, w * 0.75].map(x => `<rect x="${x - 3}" y="${h / 2 - 2.4}" width="6" height="4.8" rx="0.6" fill="${AL}"/><circle cx="${x}" cy="${h / 2}" r="1.4" fill="#8a8d94"/>`).join('');
        const rcase = B10(C, { c: [CX, 0, 0], w: 70, h: 15, d: 46, col: '#1c1d21', r: 0.6, mat: 'noise', dec: { f: caseF(70, 15), b: caseF(70, 15), l: caseF(46, 15), r: caseF(46, 15), t: `<rect width="70" height="46" fill="#1e1f23"/><rect width="70" height="46" fill="none" stroke="${AL}" stroke-width="1.4"/>` } })
          + [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([a, b]) => sph(C, [CX + a * 35, 15, b * 23], 1.6, '#c8ccd4')).join('');
        const HW = 44, HH = 16, HD = 26, HX = CX + 12, Y0 = 15;
        const hf = `<rect width="${HW}" height="${HH}" fill="#18191d"/><rect x="3" y="3" width="13" height="5" rx="0.6" fill="#120a04"/><text x="4.4" y="6.9" font-size="3.4" font-family="monospace" fill="#ffb040">75%</text>`
          + rep(4, i => `<circle cx="${4 + i * 3.2}" cy="11.6" r="1" fill="#2a2b30" stroke="#55565c" stroke-width="0.2"/>`).join('') + `<circle cx="18" cy="11.6" r="0.5" fill="#5aff8a">${an('opacity', '1;0.3;1', 1.5)}</circle>`
          + `<circle cx="33" cy="8" r="6" fill="#0c0c0e" stroke="#55565c" stroke-width="0.4"/><g transform="translate(33 8)"><g><animateTransform attributeName="transform" type="rotate" values="0;360" dur="0.6s" repeatCount="indefinite"/>${rep(5, i => `<path d="M0 0q2 -1 5 -0.4l-1 1.6Z" fill="#3a3b42" transform="rotate(${i * 72})"/>`).join('')}</g></g>${rep(5, i => `<path d="M27.6 ${4 + i * 2}h10.8" stroke="#3a3b42" stroke-width="0.35"/>`).join('')}`;
        const hside = `<rect width="${HD}" height="${HH}" fill="#18191d"/>${rep(6, i => `<rect x="${4 + i * 3}" y="4" width="1.4" height="8" rx="0.7" fill="#0a0a0c"/>`).join('')}`;
        const hazer = B10(C, { c: [HX, Y0, 0], w: HW, h: HH, d: HD, col: '#18191d', r: 2, mat: 'noise', gl: 0.1, dec: { f: hf, l: hside, r: hside } });
        const rails = [-1, 1].map(sz => line3(C, [[HX - 16, Y0 + HH, sz * 10], [HX - 15, Y0 + HH + 4, sz * 10], [HX + 15, Y0 + HH + 4, sz * 10], [HX + 16, Y0 + HH, sz * 10]], 1, AL)).join('');
        const nzP = [HX + HW / 2, 31 - 0, 0], nozzle = cyl3(C, [HX + HW / 2 - 1, 23, 0], [HX + HW / 2 + 3, 23, 0], 3, '#2a2b30', { olw: 0.2 }), tip = C.P([HX + HW / 2 + 3.2, 23, 0]);
        const haze = puffs(tip, (on ? 90 : 50) * k, -16 * k, on ? 10 : 5, on ? 4 : 5.5, 4 * k, (on ? 26 : 18) * k, '#f0eef8', on ? 0.55 : 0.32);
        // UV cannons
        const cannon = (x, z, b) => { const A = [0.32, 0.86, 0.3], L = Math.hypot(...A), a = A.map(v => v / L), c = [x, 16, z], f = [x + a[0] * 7, 16 + a[1] * 7, z + a[2] * 7], bk = [x - a[0] * 6, 16 - a[1] * 6, z - a[2] * 6];
          const base = cyl3(C, [x, 0, z], [x, 1.6, z], 8, '#1c1d21', { olw: 0.25 }) + line3(C, [[x - 7, 1.6, z], [x - 7, 16, z]], 1.2, '#26272c') + line3(C, [[x + 7, 1.6, z], [x + 7, 16, z]], 1.2, '#26272c') + line3(C, [[x - 7, 1.6, z], [x + 7, 1.6, z]], 1.2, '#26272c');
          const head = cyl3(C, bk, f, 6.2, '#202126', { mat: 'gloss', olw: 0.3, capCol: '#14141a' }), lc = C.P(f), tip2 = C.P([x + a[0] * 120, 16 + a[1] * 120, z + a[2] * 120]);
          const dx = tip2[0] - lc[0], dy = tip2[1] - lc[1], Ln = Math.hypot(dx, dy) || 1, nx = -dy / Ln, ny = dx / Ln, W0 = 5 * k, W1 = 24 * k;
          const beam = `<path d="M${f1(lc[0] + nx * W0)} ${f1(lc[1] + ny * W0)}L${f1(tip2[0] + nx * W1)} ${f1(tip2[1] + ny * W1)}L${f1(tip2[0] - nx * W1)} ${f1(tip2[1] - ny * W1)}L${f1(lc[0] - nx * W0)} ${f1(lc[1] - ny * W0)}Z" fill="url(#${id}u${b})"><animate attributeName="opacity" values="0.45;0.8;0.45" dur="3s" begin="${-b}s" repeatCount="indefinite"/></path>`;
          const lens = `<circle cx="${f1(lc[0])}" cy="${f1(lc[1])}" r="${f1(5.4 * k)}" fill="#3a1a5a"/>${rep(7, i => { const an2 = i / 7 * 2 * PI, r2 = i ? 3 : 0; return `<circle cx="${f1(lc[0] + Math.cos(an2) * r2 * k)}" cy="${f1(lc[1] + Math.sin(an2) * r2 * k * 0.8)}" r="${f1(1.1 * k)}" fill="#c89aff"/>`; }).join('')}<circle cx="${f1(lc[0])}" cy="${f1(lc[1])}" r="${f1(8 * k)}" fill="#a060ff" opacity="0.4" filter="url(#a31b1)">${an('opacity', '0.25;0.55;0.25', 3, -b)}</circle>`;
          const specks = rep(8, i => { const f = 0.2 + R() * 0.7, q = [lc[0] + dx * f + (R() - 0.5) * W1 * f * 1.6, lc[1] + dy * f + (R() - 0.5) * W1 * f]; return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.6 * k)}" fill="${['#f0ff60', '#ff6af0', '#ffffff'][i % 3]}">${an('opacity', '0;1;0', 2 + R() * 2, -R() * 3)}</circle>`; }).join('');
          const defs = `<linearGradient id="${id}u${b}" gradientUnits="userSpaceOnUse" x1="${f1(lc[0])}" y1="${f1(lc[1])}" x2="${f1(tip2[0])}" y2="${f1(tip2[1])}"><stop offset="0" stop-color="#9a60f0" stop-opacity="0.45"/><stop offset="1" stop-color="#9a60f0" stop-opacity="0"/></linearGradient>`;
          return { d: dep(C, x, z), s: shadow(C, x, z, 9, 9, 0.25) + base + head + lens, beam: beam + specks, defs }; };
        const cs = [cannon(36, -18, 0), cannon(50, 18, 1.4)].sort((a, b) => a.d - b.d);
        const s = shadow(C, CX, 0, 40, 26, 0.3) + rcase + hazer + rails + nozzle + cs[0].s + cs[0].beam + cs[1].s + cs[1].beam + haze;
        C.p(CX - 36, 0, -24); C.p(60, 0, 28); C.p(0, 60, 0); C.p(80, 30, 0);
        return { defs: DEFA + `<defs>${cs[0].defs}${cs[1].defs}</defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-070 CRYO CO2 JET BLASTERS & CONFETTI SWIRL CANNONS (T4): a low black lacquer cabinet with a champagne-gold grille, gold feet and a
    // gold-rimmed pressure gauge hides the CO2 tank; braided gold hoses run to two jet heads on slim gold columns either side, and in front a gold
    // confetti cannon with black bands sits angled up on a lacquer pedestal. Live: the jets fire tall freezing white columns in bursts (heavier
    // when on), the gauge needle twitches and the cannon swirls out metallic confetti in gold, rose gold, champagne and blush that flutters down.
    N.cryo31 = S => { const on = isOn(S), D = { w: 130, d: 76, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('c70'), R = rng('cryo31'), GD = '#d8b468', LQ = '#141217';
        const grilleF = `<rect width="52" height="30" fill="${LQ}"/><rect x="3" y="3" width="30" height="24" rx="1" fill="url(#${id}g)"/><rect x="3" y="3" width="30" height="24" rx="1" fill="none" stroke="${GD}" stroke-width="0.6"/>`
          + `<circle cx="43" cy="12" r="5.4" fill="#f4efe4" stroke="${GD}" stroke-width="1"/>${rep(9, i => { const a = (-210 + i * 30) * PI / 180; return `<path d="M${n4(43 + Math.cos(a) * 4.2)} ${n4(12 + Math.sin(a) * 4.2)}L${n4(43 + Math.cos(a) * 4.8)} ${n4(12 + Math.sin(a) * 4.8)}" stroke="#3a3530" stroke-width="0.3"/>`; }).join('')}`
          + `<g transform="translate(43 12)"><path d="M0 0L-3.4 1.4" stroke="#c83a2a" stroke-width="0.4"><animateTransform attributeName="transform" type="rotate" values="0;14;8;20;0" dur="2.6s" repeatCount="indefinite"/></path></g><circle cx="43" cy="12" r="0.6" fill="${GD}"/>`
          + `<circle cx="43" cy="23" r="1.2" fill="${on ? '#ffb040' : '#7ae89a'}">${an('opacity', '1;0.4;1', 1.4)}</circle>`;
        const cab = B10(C, { c: [0, 3, -16], w: 52, h: 30, d: 28, col: LQ, r: 1, gl: 0.3, dec: { f: grilleF, t: `<rect width="52" height="28" fill="#18161a"/><rect x="1" y="1" width="50" height="26" fill="none" stroke="${GD}" stroke-width="0.5"/>` } })
          + [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([a, b]) => cyl3(C, [a * 22, 0, -16 + b * 10], [a * 22, 3, -16 + b * 10], 1.6, GD, { mat: 'metal', r2: 1, olw: 0.15 })).join('');
        const jet = (sx, b) => { const x = sx * 40, z = 10;
          const s = cyl3(C, [x, 0, z], [x, 2.4, z], 7, LQ, { mat: 'gloss', olw: 0.25 }) + cyl3(C, [x, 2.4, z], [x, 3.4, z], 6, GD, { mat: 'metal', olw: 0.2 }) + cyl3(C, [x, 3.4, z], [x, 40, z], 1.7, GD, { mat: 'metal', olw: 0.2 })
            + cyl3(C, [x, 40, z], [x, 45.4, z], 3.4, '#1a181c', { mat: 'gloss', olw: 0.25 }) + cyl3(C, [x, 44, z], [x, 45.4, z], 3.6, GD, { mat: 'metal', olw: 0.2 }) + cyl3(C, [x, 45.4, z], [x, 47, z], 1.4, '#c8ccd4', { mat: 'chrome', r2: 0.9, olw: 0.15 });
          const n = C.P([x, 47, z]), top = [n[0], n[1] - (on ? 110 : 80) * k], W1 = (on ? 16 : 12) * k;
          const col = `<g opacity="0">${an('opacity', on ? '0;1;1;0;0;1;1;0;0;0' : '0;1;0.9;0;0;0;0;0;0;0', on ? 4 : 5, -b, on ? KT('0;0.04;0.16;0.26;0.4;0.44;0.56;0.66;0.8;1') : KT('0;0.04;0.18;0.3;0.4;0.5;0.6;0.7;0.8;1'))}<path d="M${f1(n[0] - 1.4 * k)} ${f1(n[1])}L${f1(top[0] - W1)} ${f1(top[1])}Q${f1(top[0])} ${f1(top[1] - 10 * k)} ${f1(top[0] + W1)} ${f1(top[1])}L${f1(n[0] + 1.4 * k)} ${f1(n[1])}Z" fill="url(#${id}j)" filter="url(#a31b1)"/>`
            + `<path d="M${f1(n[0])} ${f1(n[1])}L${f1(top[0])} ${f1(top[1] + 20 * k)}" stroke="#ffffff" stroke-width="${f1(2 * k)}" opacity="0.7" filter="url(#a31b1)"/></g>` + puffs([n[0], n[1] - 60 * k], 6 * k, -40 * k, 4, 5, 8 * k, 20 * k, '#ffffff', 0.35, b);
          const hose = line3(C, [[sx * 26, 6, -10], [sx * 32, 0.8, -4], [x - sx * 4, 0.8, z - 4], [x, 1.6, z]], 0.9, '#c8a050') + line3(C, [[sx * 26, 6, -10], [sx * 32, 0.8, -4], [x - sx * 4, 0.8, z - 4], [x, 1.6, z]], 0.9, '#8a6a28', `stroke-dasharray="${f1(0.4 * k)} ${f1(0.4 * k)}"`);
          return { d: dep(C, x, z), s: shadow(C, x, z, 8, 8, 0.25) + hose + s, col }; };
        const J = [jet(-1, 0), jet(1, 1.2)].sort((a, b) => a.d - b.d);
        // confetti cannon
        const P0 = [6, 22, 16], P1 = [6, 36, 24];
        const cannon = cyl3(C, [6, 0, 14], [6, 2.4, 14], 6, LQ, { mat: 'gloss', olw: 0.25 }) + cyl3(C, [6, 2.4, 14], [6, 20, 14], 1.8, LQ, { mat: 'gloss', olw: 0.2 }) + sph(C, [6, 21, 14], 2.6, GD)
          + cyl3(C, P0, P1, 3.4, GD, { mat: 'metal', r2: 4.2, olw: 0.25, capCol: '#2a2420' }) + [0.3, 0.65].map(t => { const q = P0.map((v, i) => v + (P1[i] - v) * t), q2 = P0.map((v, i) => v + (P1[i] - v) * (t + 0.08)); return cyl3(C, q, q2, 3.6 + t * 0.8, '#1a181c', { olw: 0.15 }); }).join('');
        const m = C.P(P1), CF = ['#d8b468', '#f0c8b8', '#e8d8b0', '#ffffff', '#f4b8c8', '#c8986a'];
        const conf = rep(on ? 34 : 22, i => { const T = 3.2 + R() * 1.6, b = -R() * T, ex = (R() - 0.3) * 90 * k, ey = -(60 + R() * 50) * k, fx = ex * 1.3, fy = ey + (50 + R() * 40) * k, rot = (R() - 0.5) * 900, w = (1 + R()) * k, c = CF[i % 6];
          return `<g opacity="0">${an('opacity', '0;1;1;0', T, b, KT('0;0.05;0.85;1'))}<g>${at('translate', `0 0;${f1(ex)} ${f1(ey)};${f1(fx)} ${f1(fy)}`, T, b, ' calcMode="spline" keyTimes="0;0.35;1" keySplines="0.1 0.6 0.3 1;0.4 0 0.6 1"')}<g transform="translate(${P2(m)})"><rect x="${f1(-w)}" y="${f1(-w * 0.5)}" width="${f1(w * 2)}" height="${f1(w)}" fill="${c}">${at('rotate', `0;${f1(rot)}`, T, b)}<animate attributeName="height" values="${f1(w)};${f1(w * 0.2)};${f1(w)}" dur="${n4(0.5 + R() * 0.4)}s" repeatCount="indefinite"/></rect></g></g></g>`; }).join('');
        const fr = C.v[2] >= 0;
        const s = shadow(C, 0, -14, 32, 18, 0.3) + (fr ? cab + J[0].s + J[1].s : J[0].s + J[1].s + cab) + shadow(C, 6, 14, 7, 7, 0.25) + cannon + J[0].col + J[1].col + conf;
        C.p(-50, 0, -32); C.p(50, 0, 22); C.p(-40, 47 + 60, 10); C.p(40, 47 + 60, 10);
        return { defs: DEFA + `<defs><pattern id="${id}g" width="2" height="2" patternUnits="userSpaceOnUse"><rect width="2" height="2" fill="#2a2418"/><rect width="1.2" height="1.2" fill="${GD}"/></pattern><linearGradient id="${id}j" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0.95"/><stop offset="0.6" stop-color="#f4f6f8" stop-opacity="0.6"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };
  }

  const FLOOR31 = { card: fCard, check: fCheck, disco: fDisco, rgb: fRGB, lev: fLev }, MEMO = {};
  // flat overhead tile of a club floor (RD._FLAT mode of plus13 / plus27 / plus2, trapezoid edge vignettes removed) - the Squad House lays it as a
  // small repeating CSS-3D perspective floor in the round Dance Club so tiles read at creature scale instead of 2-3 m
  const FLATM = {}, TRX = /<path d="M14 0H66L80 56H0Z"[^>]*?(\/>|>[\s\S]*?<\/path>)/g;
  const flatOf = (key, fn) => FLATM[key] || (FLATM[key] = (() => { RD._FLAT = 1; let b; try { b = fn(); } finally { RD._FLAT = 0; } return 'data:image/svg+xml,' + encodeURIComponent(RD.svgDoc('0 0 80 56', [], b.replace(TRX, '')).replace('<svg ', '<svg preserveAspectRatio="none" ')); })());
  // ===== Dance Club room floors (CSS-3D plane in the Squad House). Plane = 3000 x 1200 px, the visible floor is about x 800..2200, y 680..1200 (REG).
  // res.floorRoom = { layers: [{ url, x, y, w, h, rep }], bg } -> CSS background layers on the plane. =====
  const REG = { x: 800, y: 680, w: 1400, h: 520 }, TILE = { x: 1312.5, y: 937, w: 375, h: 263 };
  const svgURL = (vb, body) => 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${vb}" preserveAspectRatio="none">${body}</svg>`);
  const flatPart = (key, part, fn) => flatOf(key + '|' + part, () => { RD._PART = part; try { return fn(); } finally { RD._PART = 0; } });
  // CLB-114: dark wood stage floor (user pick) with ONE LED panel in the middle (~70 % of the floor), big square LEDs edge to edge, a bold steel frame, no white inner squares
  // CLB-114 surround options: 'mirror' black glass with LED reflections, 'metal' brushed steel plates, 'concrete' smooth grey terrazzo, 'wood' dark stage planks
  const ledSurr = (v, x0, y0, RW, RH) => { const W = REG.w, H = REG.h, sp = (n, a, b, c) => rep(n, i => `<circle cx="${f1((i * 211 + 37) % W)}" cy="${f1((i * 97 + 11) % H)}" r="${f1(a + (i % 3) * b)}" fill="${c[i % c.length]}"/>`).join('');
    if (v === 'metal') { let o = `<rect width="${W}" height="${H}" fill="#7d828b"/>` + rep(140, i => `<rect x="0" y="${f1(i * H / 140)}" width="${W}" height="1.6" fill="${i % 3 ? '#ffffff' : '#000000'}" opacity="${i % 3 ? 0.05 : 0.06}"/>`).join('');
      const PW = 175, PH = 130; for (let y = 0; y < H; y += PH) for (let x = 0; x < W; x += PW) o += `<rect x="${x}" y="${y}" width="${PW}" height="${PH}" fill="${(x / PW + y / PH) % 2 ? '#ffffff' : '#000000'}" opacity="0.035"/><rect x="${x + 1}" y="${y + 1}" width="${PW - 2}" height="${PH - 2}" fill="none" stroke="#3a3d44" stroke-width="2.4"/><path d="M${x + 3} ${y + 3}H${x + PW - 3}" stroke="#ffffff" stroke-width="1" opacity="0.3"/>` + [[9, 9], [PW - 9, 9], [9, PH - 9], [PW - 9, PH - 9]].map(([a, b]) => `<circle cx="${x + a}" cy="${y + b}" r="3.2" fill="#5a5e66"/><circle cx="${x + a - 0.8}" cy="${y + b - 0.8}" r="1.6" fill="#d8dce2"/>`).join('');
      return o; }
    if (v === 'concrete') return `<rect width="${W}" height="${H}" fill="#6c6a6e"/>` + sp(260, 1.2, 0.8, ['#8a878c', '#5a585c', '#9c98a0', '#4e4c50']) + rep(5, i => `<path d="M0 ${f1(60 + i * 105)}H${W}" stroke="#4a484c" stroke-width="1.6" opacity="0.5"/>`).join('') + rep(6, i => `<path d="M${f1(120 + i * 232)} 0V${H}" stroke="#4a484c" stroke-width="1.6" opacity="0.5"/>`).join('');
    if (v === 'wood') { let o = `<rect width="${W}" height="${H}" fill="#3e281c"/>`; const PH = 26; for (let j = 0, y = 0; y < H; j++, y += PH) { const off = (j * 137) % 300; for (let x = -off; x < W; x += 300) o += `<rect x="${f1(x)}" y="${y}" width="300" height="${PH}" fill="${['#412a1d', '#493120', '#3b2719', '#4c3223'][(j + Math.floor(x / 300)) & 3]}" stroke="#1c110b" stroke-width="1.6"/><path d="M${f1(x + 10)} ${f1(y + PH * 0.4)}q90 -4 180 1t100 -1" fill="none" stroke="#26180f" stroke-width="1" opacity="0.5"/>`; }
      return o + `<rect width="${W}" height="${H}" fill="#ffffff" opacity="0.03"/>`; }
    // mirror: black glass, seamless, with long soft streaks and the LED colours reflected below / round the panel
    return `<rect width="${W}" height="${H}" fill="#121218"/>` + rep(7, i => `<path d="M${f1(80 + i * 190)} 0l-60 ${H}h40l60 ${-H}z" fill="#ffffff" opacity="${(0.025 + (i % 3) * 0.012).toFixed(3)}"/>`).join('') + sp(40, 0.8, 0.4, ['#ffffff']).replace(/fill="#ffffff"/g, 'fill="#ffffff" opacity="0.18"'); };
  const led114 = () => { const NEO = ['#ff0a8c', '#b400ff', '#3a28ff', '#0090ff', '#00f0ff', '#00ff6a', '#d4ff00', '#ffb300', '#ff3c00'], RW = 816, RH = 204, x0 = (REG.w - RW) / 2, y0 = 185, NX = 24, NY = 6, cw = RW / NX, ch = RH / NY, g = 0;
    let tl = '';
    for (let j = 0; j < NY; j++) for (let i = 0; i < NX; i++) { const k = (i + j * 2) % NEO.length, seq = rep(NEO.length, m => NEO[(k + m) % NEO.length]).concat(NEO[k]).join(';'), b = -((i + j) * 0.18).toFixed(2);
      tl += `<rect x="${f1(x0 + i * cw + g)}" y="${f1(y0 + j * ch + g)}" width="${f1(cw - 2 * g)}" height="${f1(ch - 2 * g)}" fill="${NEO[k]}">${an('fill', seq, 5.6, b)}${an('opacity', '1;0.82;1', 1.4, (b * 0.5).toFixed(2))}</rect>`; }
    const body = `<defs><filter id="lb" x="-10%" y="-10%" width="120%" height="120%"><feGaussianBlur stdDeviation="5"/></filter><radialGradient id="lc" cx="50%" cy="48%" r="65%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.38"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="0.7" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.45"/></radialGradient><radialGradient id="ldg"><stop offset="0" stop-color="#ffffff" stop-opacity="0.95"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0.35"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient><pattern id="ld" x="${x0}" y="${y0}" width="${f1(cw / 3)}" height="${f1(ch / 3)}" patternUnits="userSpaceOnUse"><circle cx="${f1(cw / 6)}" cy="${f1(ch / 6)}" r="${f1(cw / 7)}" fill="url(#ldg)" opacity="0.5"/></pattern><pattern id="le" x="${x0}" y="${y0}" width="${f1(cw)}" height="${f1(ch)}" patternUnits="userSpaceOnUse"><path d="M3 ${f1(ch - 3)}V3H${f1(cw - 3)}" fill="none" stroke="#ffffff" stroke-width="1.2" opacity="0.35"/><path d="M${f1(cw - 3)} 3V${f1(ch - 3)}H3" fill="none" stroke="#000000" stroke-width="1.2" opacity="0.3"/></pattern><filter id="lsp" x="-30%" y="-60%" width="160%" height="220%"><feGaussianBlur stdDeviation="38"/></filter><radialGradient id="lsh" cx="50%" cy="45%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.07"/><stop offset="1" stop-color="#000000" stop-opacity="0.25"/></radialGradient><linearGradient id="ls" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`
      // surround: dark wood stage planks (user pick D; other variants kept for reference)
      + ledSurr(RD._LEDS || 'wood', x0, y0, RW, RH)
      + rep(60, i => `<rect x="${f1((i * 97) % REG.w)}" y="${f1((i * 53) % REG.h)}" width="${f1(30 + (i % 5) * 12)}" height="1" fill="#ffffff" opacity="0.05"/>`).join('')
      // gloss: soft sheen across the floor, and coloured LED light spilling onto the floor round the panel (slowly shifting colour)
      + `<rect width="${REG.w}" height="${REG.h}" fill="url(#lsh)"/><g filter="url(#lsp)" style="mix-blend-mode:screen"><rect x="${x0 - 30}" y="${y0 - 30}" width="${RW + 60}" height="${RH + 60}" rx="40" fill="${NEO[0]}" opacity="0.5">${an('fill', NEO.concat(NEO[0]).join(';'), 11.2, 0)}</rect></g>`
      + `<rect x="${x0 - 3}" y="${y0 - 3}" width="${RW + 6}" height="${RH + 6}" fill="#000000"/><g filter="url(#lb)" opacity="0.8" style="mix-blend-mode:screen">${tl}</g>${tl}<rect x="${x0}" y="${y0}" width="${RW}" height="${RH}" fill="url(#ls)"/>`
      // each LED reads as a lit lens: bright diffused core, darker rim, a little glass gloss
      + `<g>${rep(NX * NY, n => { const i = n % NX, j = Math.floor(n / NX); return `<rect x="${f1(x0 + i * cw)}" y="${f1(y0 + j * ch)}" width="${f1(cw)}" height="${f1(ch)}" fill="url(#lc)"/>`; }).join('')}</g>`
      // the LED chips under the frosted diffuser (3 x 3 bright points per panel) and a bevelled top-left edge on every panel
      + `<rect x="${x0}" y="${y0}" width="${RW}" height="${RH}" fill="url(#ld)"/><rect x="${x0}" y="${y0}" width="${RW}" height="${RH}" fill="url(#le)"/>`
      // bold grey steel border round every LED, same build as the outer frame (dark under-stroke, steel, thin highlight)
      + ((gd) => `<path d="${gd}" stroke="#1a1c22" stroke-width="8"/><path d="${gd}" stroke="#c4c8d0" stroke-width="4.2"/><path d="${gd}" stroke="#f2f4f8" stroke-width="0.9" opacity="0.7" transform="translate(-0.9 -0.9)"/>`)(rep(NX - 1, i => `M${f1(x0 + (i + 1) * cw)} ${y0}V${y0 + RH}`).join('') + rep(NY - 1, j => `M${x0} ${f1(y0 + (j + 1) * ch)}H${x0 + RW}`).join(''))
      + `<rect x="${x0 - 4}" y="${y0 - 4}" width="${RW + 8}" height="${RH + 8}" fill="none" stroke="#1a1c22" stroke-width="9"/><rect x="${x0 - 4}" y="${y0 - 4}" width="${RW + 8}" height="${RH + 8}" fill="none" stroke="#c4c8d0" stroke-width="4.5"/><rect x="${x0 - 5.6}" y="${y0 - 5.6}" width="${RW + 11.2}" height="${RH + 11.2}" fill="none" stroke="#f2f4f8" stroke-width="1" opacity="0.8"/>`;
    return svgURL(`0 0 ${REG.w} ${REG.h}`, body); };
  // CLB-085: ONE kinetic honeycomb across the whole floor: pearl hex pads (gold edges) over a glowing energy well, bass rings + pad ripples from the centre
  const lev085 = () => { const r = 20, dx = r * 1.5, dy = r * Math.sqrt(3), cx = REG.w / 2, cy = 300, NB = 8, bands = rep(NB, () => '');
    for (let i = -1; i * dx < REG.w + dx; i++) for (let j = -1; j * dy < REG.h + dy; j++) { const x = i * dx, y = j * dy + (i % 2 ? dy / 2 : 0), dd = Math.hypot(x - cx, (y - cy) * 1.4), b = Math.min(NB - 1, Math.floor(dd / 90));
      const hx = (rr, ox, oy) => 'M' + rep(6, k => { const a = k * PI / 3; return f1(x + ox + Math.cos(a) * rr) + ' ' + f1(y + oy + Math.sin(a) * rr); }).join('L') + 'Z';
      bands[b] += `<path d="${hx(r * 0.8, 0, 2.6)}" fill="#000000" opacity="0.45"/><path d="${hx(r * 0.8, 0, 0)}" fill="#e6ddd0" stroke="#d6b26a" stroke-width="1.3"/><path d="${hx(r * 0.55, -0.6, -1)}" fill="#f6f0e6" opacity="0.7"/><path d="${hx(r * 0.22, -4, -5)}" fill="#ffffff" opacity="0.55"/>`; }
    let pads = bands.map((s, b) => `<g>${at('translate', '0 0;0 2.4;0 -1;0 0', 2.4, -b * 0.3, ' calcMode="spline" keyTimes="0;0.2;0.5;1" keySplines="0.3 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1"')}${s}</g>`).join('');
    const rings = rep(3, i => `<ellipse cx="${cx}" cy="${cy}" rx="10" ry="7" fill="none" stroke="#ffd070" stroke-width="10" opacity="0" filter="url(#lg)">${an('rx', '10;760', 2.4, -i * 0.8)}${an('ry', '7;540', 2.4, -i * 0.8)}${an('opacity', '0;0.9;0.5;0', 2.4, -i * 0.8)}</ellipse>`).join('');
    const sparks = rep(14, i => { const a = i / 14 * 2 * PI + 0.3; return `<circle r="3" fill="#fff0b0" opacity="0">${an('cx', `${cx};${f1(cx + Math.cos(a) * 720)}`, 2.4, -i * 0.17)}${an('cy', `${cy};${f1(cy + Math.sin(a) * 420)}`, 2.4, -i * 0.17)}${an('opacity', '0;1;0', 2.4, -i * 0.17)}</circle>`; }).join('');
    const body = `<defs><filter id="lg" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="14"/></filter><radialGradient id="lw" cx="50%" cy="58%" r="55%"><stop offset="0" stop-color="#ffe0a0" stop-opacity="0.9"/><stop offset="0.35" stop-color="#ffa83a" stop-opacity="0.6"/><stop offset="1" stop-color="#ffa83a" stop-opacity="0.12"/></radialGradient></defs>`
      + `<rect width="${REG.w}" height="${REG.h}" fill="#120a04"/><rect width="${REG.w}" height="${REG.h}" fill="url(#lw)"/>${rings}${pads}<g style="mix-blend-mode:screen" opacity="0.35">${rings}</g><ellipse cx="${cx}" cy="${cy}" rx="260" ry="170" fill="#ffc060" opacity="0.16" filter="url(#lg)"/>${sparks}`;
    return svgURL(`0 0 ${REG.w} ${REG.h}`, body); };
  const ROOMF = {}, roomFloor = (r, f) => { const k = r.f31 || r.id; if (ROOMF[k]) return ROOMF[k];
    let L;
    if (r.f31 === 'card') { const ov = flatPart('card', 'over', f); // the mat once, turned so each box's long side runs parallel to the front edge of the floor (boxes stacked front to back, a little longer)
      L = { layers: [{ url: ov, x: 1260, y: 802, w: 480, h: 336 }, { url: flatPart('card', 'base', f), ...TILE, rep: 1 }], bg: '#86847e' }; }
    else if (r.f31 === 'lev') L = { layers: [{ url: lev085(), ...REG }], bg: '#120a04' };
    else if (r.id === 'CLB-114') L = { layers: [{ url: led114(), ...REG }], bg: '#3e281c' };
    else L = { layers: [{ url: flatOf(k, f || (() => '<rect width="80" height="56" fill="#08080a"/>' + RD.H2LED(r.tier))), ...TILE, rep: 1 }], bg: '#08080a' };
    return (ROOMF[k] = L); };
  const draw30 = RD.draw;
  RD.draw = (r, o) => { const res = draw30(r, o); if (!res || res._p31) return res;
    try { const f = r.f31 && FLOOR31[r.f31]; if (f && res.surf) { res._p31 = 1; res.vb = '0 0 80 56'; res.svg = MEMO[r.f31] || (MEMO[r.f31] = RD.svgDoc('0 0 80 56', [], f())); res.src = 'data:image/svg+xml,' + encodeURIComponent(res.svg); res.floorFlat = flatOf(r.f31, f); res.floorRoom = roomFloor(r, f); }
      else if (r.id === 'CLB-114' && res.surf && res.kind === 'floor' && RD.H2LED) { res.floorFlat = flatOf('led114', () => '<rect width="80" height="56" fill="#08080a"/>' + RD.H2LED(r.tier)); res.floorRoom = roomFloor(r, null); } } catch (e) { console.warn('reno plus31', r.id, e); }
    return res; };


  // ======================= CLUB MIST + GAMES (CLB-090 / 011 / 031): fx-only for 090 + 011; 031 keeps its playable pinball5 build (players, flippers,
  // ball, backglass) and is wrapped in place with realistic used-machine details =======================
  { const { box3: B10, cyl3, sph, shadow, FR, nrm, add, mul, cross } = RD.H10;
    const DEFG = '<filter id="g31b1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.8"/></filter><filter id="g31b3" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="3"/></filter>';
    const line3 = (C, P, w, col, ex) => `<path d="M${P.map(p => P2(C.P(p))).join('L')}" stroke="${col}" stroke-width="${f1(w * C.k)}" fill="none" stroke-linecap="round" stroke-linejoin="round"${ex ? ' ' + ex : ''}/>`;
    const PLN = (C, y, svg, x, z) => `<g transform="${FR(C, [x || 0, y, z || 0], [1, 0, 0], [0, 0, 1])}">${svg}</g>`;
    const VPL = (C, O, svg) => `<g transform="${FR(C, O, [1, 0, 0], [0, -1, 0])}">${svg}</g>`;
    const isOn = S => /(^|\|)(on|play)$/.test(S.st || '');
    const thV = C => Math.atan2(C.v[2], C.v[0]);
    const arcP = (r, y, a0, a1, n) => rep(n + 1, i => { const a = a0 + (a1 - a0) * i / n; return [Math.cos(a) * r, y, Math.sin(a) * r]; });
    const frontArc = (C, r, y, n, w) => { const t = thV(C), h = w || PI / 2; return arcP(r, y, t - h, t + h, n || 24); };
    const blob = (R, cx, cy, r, n) => 'M' + rep(n, i => { const a = i / n * 2 * PI, q = r * (0.6 + R() * 0.55); return f1(cx + Math.cos(a) * q) + ' ' + f1(cy + Math.sin(a) * q); }).join('L') + 'Z';
    const puffs = (o, dx, dy, n, T, r0, r1, col, op, b0) => rep(n, i => { const b = -(b0 || 0) - i * T / n, j = ((i * 37) % 10) / 10 - 0.5;
      return `<circle cx="${f1(o[0])}" cy="${f1(o[1])}" r="${f1(r0)}" fill="${col}" opacity="0" filter="url(#g31b3)">${an('r', `${f1(r0)};${f1(r1)}`, T, b)}${an('opacity', `0;${op};${n4(op * 0.6)};0`, T, b, KT('0;0.15;0.6;1'))}${at('translate', `0 0;${f1(dx * 0.55 + j * Math.abs(dy) * 0.4)} ${f1(dy * 0.55 + j * 6)};${f1(dx + j * Math.abs(dy) * 0.6)} ${f1(dy)}`, T, b, SPL(2))}</circle>`; }).join('');

    // DJ headphones lying flat on a surface at (x, y, z): cups facing down, band arcing over the desk; ang rotates them on the desk
    const phones = (C, x, y, z, col, col2, ang) => { const ca = Math.cos(ang || 0), sa = Math.sin(ang || 0), at3 = (u, h, w) => [x + u * ca - w * sa, y + h, z + u * sa + w * ca];
      const band = rep(13, i => { const a = PI * i / 12; return at3(-Math.cos(a) * 5.4, 1.4, -Math.sin(a) * 5.6); });
      return line3(C, band, 1.3, col) + line3(C, band, 0.4, col2) + [-1, 1].map(s => cyl3(C, at3(s * 5.4, 0, 0.4), at3(s * 5.4, 2.4, 0.4), 3.2, col, { olw: 0.2, capCol: col2 })).join('') + line3(C, [at3(-5.4, 0.4, 3), at3(-8, 0.2, 7), at3(-4, 0.2, 10)], 0.35, '#101012'); };

    // CLB-090 ZERO-GRAVITY BUBBLE-CLOUD & SCENT-SYNCED EUPHORIA MIST MATRIX (T5): a sculptural luxury mist fountain. A black Nero Marquina marble
    // drum with white veining and a brass inlay ring stands on a polished brass toe ring; a fluted smoked-bronze column with brass collars rises to a
    // brass mist bowl lit warm from inside. Above it three brushed-brass rings hang in the air one over another, each set with six tiny nozzle pins
    // breathing fine mist, and on top floats a hand-blown glass orb with a warm amber glow, circled by iridescent soap bubbles. Live: the rings bob
    // gently out of step and their nozzle rings turn slowly, mist curls off them, the orb glows and drifts, bubbles orbit; denser when on.
    N.mist31 = S => { const on = isOn(S), D = { w: 96, d: 96, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('m90'), R = rng('mist31'), BR = '#b8893c', BRL = '#f2d79a', BRD = '#6a4a1c', MB = '#1a191e', BZ = '#4a3a2c', th = thV(C);
        let s = '', back = '';
        s += PLN(C, 0.1, `<ellipse rx="60" ry="60" fill="url(#${id}fl)">${an('opacity', on ? '0.8;1;0.8' : '0.55;0.7;0.55', 4)}</ellipse>`) + shadow(C, 0, 0, 36, 36, 0.45);
        // ---- marble drum on a brass toe ring
        const veinT = r => { const V = rng('m90t'); let v = `<clipPath id="${id}mc"><circle r="${r}"/></clipPath><g clip-path="url(#${id}mc)">`;
          rep(7, i => { let x = -r + V() * 2 * r, y = -r, d = `M${f1(x)} ${f1(y)}`; rep(8, () => { x += (V() - 0.4) * 9; y += r / 4; d += `Q${f1(x + (V() - 0.5) * 8)} ${f1(y - r / 8)} ${f1(x)} ${f1(y)}`; });
            v += `<path d="${d}" stroke="#f2efe8" stroke-width="${n4(0.25 + V() * 0.5)}" fill="none" opacity="${n4(0.35 + V() * 0.4)}"/>`; });
          v += rep(4, () => `<path d="M${f1(-r + V() * 2 * r)} ${f1(-r + V() * 2 * r)}q${f1((V() - 0.5) * 14)} ${f1(V() * 10)} ${f1((V() - 0.5) * 20)} ${f1(6 + V() * 10)}" stroke="#d8b060" stroke-width="0.25" fill="none" opacity="0.5"/>`).join('');
          return v + `</g><circle r="${n4(r - 2)}" fill="none" stroke="${BR}" stroke-width="0.9"/><circle r="${n4(r - 2)}" fill="none" stroke="${BRL}" stroke-width="0.3" opacity="0.7"/><circle r="${r}" fill="url(#${id}gl)"/>`; };
        s += cyl3(C, [0, 0, 0], [0, 3, 0], 33, '#a07a38', { mat: 'metal', olw: 0.3 });
        s += cyl3(C, [0, 3, 0], [0, 14, 0], 30, MB, { mat: 'gloss', olw: 0.35, cap: veinT });
        rep(9, i => { const a = th - 1.3 + R() * 2.6; let P = []; let aa = a; rep(6, j => { aa += (R() - 0.5) * 0.08; P.push([Math.cos(aa) * 30.15, 3.4 + j * 2, Math.sin(aa) * 30.15]); }); s += line3(C, P, 0.18 + R() * 0.3, '#eeeae2', `opacity="${n4(0.3 + R() * 0.4)}"`); });
        s += line3(C, frontArc(C, 30.2, 8.5, 32), 0.9, BR) + line3(C, frontArc(C, 30.3, 8.8, 32, 1.1), 0.3, BRL, 'opacity="0.8"');
        // ---- fluted bronze column with brass collars and mist bowl
        s += cyl3(C, [0, 14, 0], [0, 16, 0], 13, BR, { mat: 'metal', olw: 0.25 }) + cyl3(C, [0, 16, 0], [0, 19, 0], 10, BR, { mat: 'metal', olw: 0.25, r2: 8.4 });
        s += cyl3(C, [0, 19, 0], [0, 70, 0], 7.6, BZ, { mat: 'metal', olw: 0.3, r2: 6.6 });
        rep(9, i => { const a = th - 1.25 + i * 2.5 / 8; s += line3(C, [[Math.cos(a) * 7.5, 21, Math.sin(a) * 7.5], [Math.cos(a) * 6.5, 68, Math.sin(a) * 6.5]], 0.55, '#241a12', 'opacity="0.75"')
          + line3(C, [[Math.cos(a + 0.12) * 7.55, 21, Math.sin(a + 0.12) * 7.55], [Math.cos(a + 0.12) * 6.55, 68, Math.sin(a + 0.12) * 6.55]], 0.25, '#9a7a56', 'opacity="0.6"'); });
        s += line3(C, frontArc(C, 7.25, 44, 16), 1.6, BR) + line3(C, frontArc(C, 7.3, 44.5, 16, 1), 0.4, BRL);
        s += cyl3(C, [0, 70, 0], [0, 73, 0], 8.8, BR, { mat: 'metal', olw: 0.25, r2: 10 }) + cyl3(C, [0, 73, 0], [0, 75.5, 0], 12, BR, { mat: 'metal', olw: 0.3, r2: 13.2, capCol: '#2a2014' });
        const bw = C.P([0, 75.6, 0]);
        s += PLN(C, 75.6, `<ellipse rx="11.4" ry="11.4" fill="url(#${id}bw)">${an('opacity', '0.75;1;0.75', 3.2)}</ellipse>`);
        // warm uplight glow climbing through the mist
        back += `<ellipse cx="${f1(bw[0])}" cy="${f1(bw[1] - 34 * k)}" rx="${f1(26 * k)}" ry="${f1(46 * k)}" fill="url(#${id}up)">${an('opacity', on ? '0.85;1;0.85' : '0.5;0.7;0.5', 4.4)}</ellipse>`;
        // ---- three floating brass rings with turning nozzle pins and mist
        const RINGS = [[82, 18, 0, 0.16, 0.12], [96, 14.5, 1.1, -0.2, -0.14], [109, 10.5, 2.2, 0.22, 0.18]];
        RINGS.forEach(([y, r, ph, tz, tx], j) => { const U = [Math.cos(tz), Math.sin(tz), 0], V = [0, Math.sin(tx), Math.cos(tx)], rq = (a, rr, dy) => add([0, y + (dy || 0), 0], add(mul(U, Math.cos(a) * rr), mul(V, Math.sin(a) * rr))), hl = th - 0.7, hp = (rr, a0, a1) => `M${f1(Math.cos(a0) * rr)} ${f1(Math.sin(a0) * rr)}A${rr} ${rr} 0 0 1 ${f1(Math.cos(a1) * rr)} ${f1(Math.sin(a1) * rr)}`;
          let g = `<g transform="${FR(C, [0, y, 0], U, V)}"><circle r="${r}" fill="none" stroke="${BRD}" stroke-width="2"/><circle r="${r}" fill="none" stroke="${BR}" stroke-width="1.45"/></g>`
            + `<g transform="${FR(C, [0, y + 1.1, 0], U, V)}"><circle r="${r}" fill="none" stroke="#8a6428" stroke-width="1.6"/><circle r="${r}" fill="none" stroke="#d8b066" stroke-width="1.05"/>`
            + `<path d="${hp(r, hl - 0.55, hl + 0.55)}" stroke="${BRL}" stroke-width="0.7" fill="none" stroke-linecap="round"/><path d="${hp(r, hl + PI - 0.3, hl + PI + 0.3)}" stroke="${BRL}" stroke-width="0.4" fill="none" opacity="0.5"/>`
            + `<g>${at('rotate', j % 2 ? '360;0' : '0;360', 18 + j * 5)}${rep(6, i => { const a = i * PI / 3 + ph; return `<circle cx="${f1(Math.cos(a) * r)}" cy="${f1(Math.sin(a) * r)}" r="0.75" fill="#fff4dc" stroke="${BRD}" stroke-width="0.2"/>`; }).join('')}</g></g>`;
          // mist wisps curling off the front of each ring
          const nW = on ? 5 : 3; g += rep(nW, i => { const a = th - 1.2 + i * 2.4 / Math.max(1, nW - 1), q = C.P(rq(a, r, 1.5)), ox = Math.cos(a) * 1 + (Math.sin(a) * 0.3);
            return puffs(q, ox * (on ? 22 : 14) * k, -(on ? 16 : 10) * k, on ? 3 : 2, on ? 3.2 : 4.2, 1.6 * k, (on ? 9 : 6) * k, '#fff6ea', on ? 0.6 : 0.45, i * 0.7 + j * 0.4); }).join('');
          s += `<g>${at('translate', `0 0;0 ${f1(-2.6 * k)};0 0`, 3.6 + j * 0.5, -ph, SPL(2))}${g}</g>`; C.p(-r, y, -r); C.p(r, y, r); });
        // soft mist veil around the rings
        const mv = C.P([0, 96, 0]); back += `<ellipse cx="${f1(mv[0])}" cy="${f1(mv[1])}" rx="${f1(34 * k)}" ry="${f1(26 * k)}" fill="#fff4e6" opacity="${on ? 0.32 : 0.18}" filter="url(#g31b3)">${an('rx', `${f1(30 * k)};${f1(36 * k)};${f1(30 * k)}`, 6)}</ellipse>`;
        // ---- floating hand-blown glass orb
        const oc = C.P([0, 124, 0]); let orb = `<circle cx="${f1(oc[0])}" cy="${f1(oc[1])}" r="${f1(15 * k)}" fill="url(#${id}ha)">${an('opacity', '0.6;1;0.6', 3.8)}</circle>`;
        orb += `<circle cx="${f1(oc[0])}" cy="${f1(oc[1])}" r="${f1(9 * k)}" fill="url(#${id}gs)" stroke="#f6e6c8" stroke-opacity="0.55" stroke-width="${f1(0.35 * k)}"/>`
          + `<circle cx="${f1(oc[0])}" cy="${f1(oc[1] + 0.8 * k)}" r="${f1(3.6 * k)}" fill="url(#${id}am)">${an('r', `${f1(3.2 * k)};${f1(4.2 * k)};${f1(3.2 * k)}`, 3.8)}</circle>`
          + `<path d="M${f1(oc[0] - 2.4 * k)} ${f1(oc[1] + 2 * k)}q${f1(1.2 * k)} ${f1(-3.6 * k)} ${f1(2.4 * k)} 0q${f1(1.2 * k)} ${f1(-3.6 * k)} ${f1(2.4 * k)} 0" stroke="#fff0c8" stroke-width="${f1(0.35 * k)}" fill="none" opacity="0.9"/>`
          + `<ellipse cx="${f1(oc[0] - 3.4 * k)}" cy="${f1(oc[1] - 4 * k)}" rx="${f1(2.2 * k)}" ry="${f1(1.3 * k)}" fill="#ffffff" opacity="0.75" transform="rotate(-30 ${f1(oc[0] - 3.4 * k)} ${f1(oc[1] - 4 * k)})"/>`;
        orb += line3(C, frontArc(C, 9.4, 123.4, 20, 1.35), 0.5, BR) ;
        C.p(-10, 134, 0); C.p(10, 134, 0);
        s += `<g>${at('translate', `0 0;0 ${f1(-3.4 * k)};0 0`, 4.4, 0, SPL(2))}${orb}</g>`;
        // ---- iridescent bubbles orbiting the cloud
        const nb = on ? 16 : 9; s += rep(nb, i => { const Q = rng('m90b' + i), cy = oc[1] + (6 + Q() * 34) * k, rx = (14 + Q() * 22) * k, ry = rx * 0.3, d = n4(7 + Q() * 6), b = -Q() * d, r = (1.2 + Q() * 2.2) * k;
          const path = `M${f1(oc[0] - rx)} ${f1(cy)}A${f1(rx)} ${f1(ry)} 0 1 0 ${f1(oc[0] + rx)} ${f1(cy)}A${f1(rx)} ${f1(ry)} 0 1 0 ${f1(oc[0] - rx)} ${f1(cy)}`;
          return `<g><animateMotion dur="${d}s" begin="${n4(b)}s" repeatCount="indefinite" path="${path}"/>${an('opacity', '1;1;0.2;0.2;1', d, b, KT('0;0.44;0.54;0.94;1'))}<circle r="${f1(r)}" fill="url(#${id}bb)" stroke="#ffffff" stroke-opacity="0.6" stroke-width="${f1(0.18 * k)}"/><circle cx="${f1(-r * 0.35)}" cy="${f1(-r * 0.4)}" r="${f1(r * 0.25)}" fill="#ffffff" opacity="0.8"/></g>`; }).join('');
        C.p(-36, 0, -36); C.p(36, 0, 36); C.p(-36, 0, 36); C.p(36, 0, -36); C.p(0, 150, 0); C.p(-30, 120, 0); C.p(30, 120, 0);
        const defs = DEFG + `<defs><radialGradient id="${id}fl"><stop offset="0" stop-color="#ffcf8a" stop-opacity="0.42"/><stop offset="0.6" stop-color="#e8a858" stop-opacity="0.14"/><stop offset="1" stop-color="#e8a858" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}gl" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.03"/><stop offset="1" stop-color="#000000" stop-opacity="0.2"/></radialGradient>`
          + `<radialGradient id="${id}bw"><stop offset="0" stop-color="#fff2c8"/><stop offset="0.5" stop-color="#ffc870" stop-opacity="0.85"/><stop offset="1" stop-color="#b87a2a" stop-opacity="0.6"/></radialGradient>`
          + `<radialGradient id="${id}up" cx="50%" cy="75%" r="60%"><stop offset="0" stop-color="#ffd690" stop-opacity="0.55"/><stop offset="0.5" stop-color="#ffe2b0" stop-opacity="0.18"/><stop offset="1" stop-color="#fff0d8" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}ha"><stop offset="0" stop-color="#ffd890" stop-opacity="0.5"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}gs" cx="38%" cy="32%" r="70%"><stop offset="0" stop-color="#fffaf0" stop-opacity="0.35"/><stop offset="0.7" stop-color="#f4dcb0" stop-opacity="0.22"/><stop offset="1" stop-color="#c8945a" stop-opacity="0.5"/></radialGradient>`
          + `<radialGradient id="${id}am"><stop offset="0" stop-color="#fff6d8"/><stop offset="0.45" stop-color="#ffc060"/><stop offset="1" stop-color="#e88a2a" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}bb"><stop offset="0" stop-color="#ffffff" stop-opacity="0.04"/><stop offset="0.68" stop-color="#ffe8c8" stop-opacity="0.12"/><stop offset="0.84" stop-color="#f4b8d8" stop-opacity="0.32"/><stop offset="0.93" stop-color="#d8c070" stop-opacity="0.45"/><stop offset="1" stop-color="#a8c8e0" stop-opacity="0.5"/></radialGradient></defs>`;
        return { defs, back, front: s, bb: C.bb(4) }; };
      return D; };

    // CLB-011 PEELING DARTBOARD ON THE WALL (T1): a tired bristle dartboard hung slightly crooked on a cheap painted backboard. The bristle is faded
    // and fuzzy, peppered with holes, with a frayed chunk missing near the top and one bent wire sticking out; two numbers have worn off the ring.
    // The dark green paint on the plywood backboard is flaking away in patches to bare wood, the area around the board is riddled with missed-dart
    // holes, a cracked corner is patched with masking tape, and chalk tally marks are scratched in the corner. Two darts sit in the board (one with
    // a torn flight) and a third stuck in the backboard after a miss. It hangs from a picture wire on a nail. Live: a curl of loose paint and the
    // peeled tape end sway gently in the air.
    N.dart31 = S => { const D = { w: 60, d: 8, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('d11'), R = rng('dart31'), PNT = '#2c3a31', WD = '#b48f5e', BY = 41, BH = 58, BW = 58;
        // backboard front face: bare plywood under flaking paint (evenodd holes), missed-dart holes, chalk tallies, crack + tape
        const holes = [[7, 9, 6.5], [51, 49, 5.4], [49, 7, 4], [8, 51, 3.4], [55, 27, 2.6], [3, 32, 2.2], [30, 55.5, 2.8]].map(([x, y, r]) => blob(R, x, y, r, 11));
        let ff = `<clipPath id="${id}fc"><rect width="${BW}" height="${BH}"/></clipPath><g clip-path="url(#${id}fc)"><rect width="${BW}" height="${BH}" fill="${WD}"/>` + rep(14, i => `<path d="M0 ${f1(2 + i * 4 + R() * 2)}q${f1(BW / 2)} ${f1((R() - 0.5) * 3)} ${BW} ${f1((R() - 0.5) * 2)}" stroke="#8a6a42" stroke-width="0.3" fill="none" opacity="0.6"/>`).join('');
        ff += `<path d="M0 0H${BW}V${BH}H0Z${holes.join('')}" fill="${PNT}" fill-rule="evenodd"/>` + holes.map(h => `<path d="${h}" fill="none" stroke="#5f7466" stroke-width="0.45" opacity="0.9"/><path d="${h}" fill="none" stroke="#000" stroke-width="0.2" opacity="0.35" transform="translate(0.3 0.4)"/>`).join('');
        ff += rep(8, () => `<circle cx="${f1(R() * BW)}" cy="${f1(R() * BH)}" r="${f1(4 + R() * 8)}" fill="#5a6a5c" opacity="0.12"/>`).join('');
        ff += rep(160, () => { const a = (R() - 0.5) * 1.9 * PI, rr = 23.5 + Math.pow(R(), 1.6) * 7; const x = 29 + Math.sin(a) * rr * (1 + (R() - 0.5) * 0.15), y = 29 - Math.cos(a) * rr; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${n4(0.2 + R() * 0.18)}" fill="#0e120f" opacity="0.85"/>`; }).join('');
        ff += [[4, 46], [4, 49.6]].map(([x, y], g) => rep(g ? 3 : 2, t => `<g transform="translate(${x + t * 6.4} ${y})" stroke="#ecebe2" stroke-width="0.32" opacity="0.6" stroke-linecap="round">${rep(4, i => `<path d="M${i * 1.1} 0l0.15 2.6"/>`).join('')}<path d="M-0.4 2.2l4.6 -1.8"/></g>`).join('')).join('');
        ff += `<path d="M58 4l-4 2.4l-2.6 -0.6l-3 3.4" stroke="#1a1410" stroke-width="0.35" fill="none"/><rect x="47.4" y="2.2" width="11" height="3.4" fill="#e6d7a8" opacity="0.88" transform="rotate(32 52 4)"/><path d="M47.4 2.2h11" stroke="#c8b480" stroke-width="0.2" transform="rotate(32 52 4)"/>`;
        ff += '</g>';
        const edge = (w, h) => `<rect width="${w}" height="${h}" fill="${WD}"/>` + rep(3, i => `<rect y="${f1(h * (i + 1) / 4)}" width="${w}" height="0.25" fill="#7a5a34"/>`).join('');
        const edgeV = (w, h) => `<rect width="${w}" height="${h}" fill="${WD}"/>` + rep(3, i => `<rect x="${f1(w * (i + 1) / 4)}" width="0.25" height="${h}" fill="#7a5a34"/>`).join('');
        let s = shadow(C, 0, 2, 28, 3, 0.15);
        s += line3(C, [[-19, BY + BH - 1, -3.6], [0, BY + BH + 7, -4.2], [19, BY + BH - 1, -3.6]], 0.3, '#8a8a84') + cyl3(C, [0, BY + BH + 7, -4.4], [0, BY + BH + 7, -3.2], 0.55, '#6a6a66', { mat: 'metal', olw: 0.12 });
        s += B10(C, { c: [0, BY, -3], w: BW, h: BH, d: 2, col: WD, r: 0, dec: { f: ff, b: edge(BW, BH), l: edgeV(2, BH), r: edgeV(2, BH), t: edge(BW, 2) } });
        // board: black side + face
        s += cyl3(C, [0, 70, -2], [0, 70, 1.6], 22.5, '#1c1c1c', { olw: 0.3, noCap: 1 });
        if (C.v[2] > 0) { const pa = (r, a) => f1(r * Math.sin(a)) + ' ' + f1(-r * Math.cos(a)), dg = PI / 180;
          const seg = (r0, r1, a0, a1, col) => `<path d="M${pa(r0, a0)}L${pa(r1, a0)}A${r1} ${r1} 0 0 1 ${pa(r1, a1)}L${pa(r0, a1)}A${r0} ${r0} 0 0 0 ${pa(r0, a0)}Z" fill="${col}"/>`;
          const NUMS = [20, 1, 18, 4, 13, 6, 10, 15, 2, 17, 3, 19, 7, 16, 8, 11, 14, 9, 12, 5];
          let f = `<circle r="22.5" fill="#171717"/><circle r="22.5" fill="url(#${id}rg)"/>`;
          rep(20, i => { const a0 = (i * 18 - 9) * dg, a1 = (i * 18 + 9) * dg, bk = i % 2 === 0, sc = bk ? '#2a2724' : '#d2c39c', dc = bk ? '#9c4034' : '#3c634a';
            f += seg(1.8, 9.2, a0, a1, sc) + seg(9.2, 10.4, a0, a1, dc) + seg(10.4, 15.6, a0, a1, sc) + seg(15.6, 17, a0, a1, dc); });
          f += `<circle r="1.8" fill="#3c634a"/><circle r="0.8" fill="#9c4034"/><circle r="17" fill="#efe2c2" opacity="0.13"/>`;
          f += rep(170, () => { const a = R() * 2 * PI, rr = Math.sqrt(R()) * 16.6, x = Math.cos(a) * rr, y = Math.sin(a) * rr, b = R() * PI; return `<path d="M${f1(x)} ${f1(y)}l${n4(Math.cos(b) * 0.7)} ${n4(Math.sin(b) * 0.7)}" stroke="${R() < 0.5 ? '#000' : '#fff'}" stroke-width="0.12" opacity="0.18"/>`; }).join('');
          f += `<path d="${blob(R, 0.6, -12.6, 2.4, 12)}" fill="#e2d2a8" opacity="0.75"/>` + rep(10, () => `<path d="M${f1(-1.6 + R() * 4.4)} ${f1(-14.6 + R() * 4)}l${f1((R() - 0.5) * 1.6)} ${f1((R() - 0.5) * 1.6)}" stroke="#f4ead0" stroke-width="0.15"/>`).join('');
          f += rep(120, () => { const tgt = R(), a = tgt < 0.35 ? (R() - 0.5) * 0.3 : tgt < 0.55 ? R() * 2 * PI : R() * 2 * PI, rr = tgt < 0.35 ? 9.2 + R() * 1.6 : tgt < 0.55 ? R() * 2.6 : Math.sqrt(R()) * 16.8; return `<circle cx="${pa(rr, a).split(' ')[0]}" cy="${pa(rr, a).split(' ')[1]}" r="${n4(0.12 + R() * 0.12)}" fill="#0a0a0a" opacity="0.8"/>`; }).join('');
          f += [17, 15.6, 10.4, 9.2, 1.8, 0.8].map(r => `<circle r="${r}" fill="none" stroke="#c4c6c0" stroke-width="${r < 2 ? 0.16 : 0.2}"/>`).join('') + rep(20, i => { const a = (i * 18 + 9) * dg; return `<path d="M${pa(1.8, a)}L${pa(17, a)}" stroke="#c4c6c0" stroke-width="0.18"/>`; }).join('');
          f += `<path d="M${pa(17, 279 * dg)}q-1.2 -0.8 -2.8 -0.4" stroke="#d8dad4" stroke-width="0.22" fill="none"/><circle r="21.4" fill="none" stroke="#9a9c96" stroke-width="0.25" opacity="0.7"/>`;
          f += NUMS.map((n, i) => { const q = pa(19.6, i * 18 * dg).split(' '); return `<text x="${q[0]}" y="${q[1]}" font-family="Arial, sans-serif" font-weight="700" font-size="2.6" text-anchor="middle" dominant-baseline="central" fill="#ece6d6" opacity="${i === 7 || i === 12 ? 0.18 : 0.85}">${n}</text>`; }).join('');
          f += `<circle r="22.5" fill="url(#${id}dst)"/>`;
          s += VPL(C, [0, 70, 1.62], `<g transform="rotate(-8)">${f}</g>`); }
        // darts
        const dart = (tip, dir, col, torn) => { const d = nrm(dir), e1 = nrm(cross(d, [0, 1, 0])), e2 = cross(d, e1), at3 = t => add(tip, mul(d, t)); let o = line3(C, [at3(-0.4), at3(2.6)], 0.32, '#cfcfcc');
          o += cyl3(C, at3(2.4), at3(7.6), 0.95, '#8c8f96', { mat: 'metal', olw: 0.15, r2: 0.75 }) + rep(5, i => line3(C, [add(at3(3 + i * 0.8), mul(e1, 0.95)), add(at3(3 + i * 0.8), mul(e1, -0.95))], 0.12, '#55575c')).join('');
          o += cyl3(C, at3(7.6), at3(11), 0.42, '#1b1b1e', { olw: 0.1 });
          const vanes = [e1, mul(e1, -1), e2, mul(e2, -1)].map((e, i) => { const sh = (torn && i === 0) ? [[10.4, 0], [11.6, 2.2], [12.6, 1.4], [13.4, 2.6], [15.2, 2.2], [15.2, 0]] : [[10.4, 0], [12, 3.1], [15.2, 3.5], [15.2, 0]];
            const pts = sh.map(([t, r]) => add(at3(t), mul(e, r))); return { z: (pts[2][0] * C.v[0] + pts[2][1] * C.v[1] + pts[2][2] * C.v[2]), s: `<path d="M${pts.map(p => P2(C.P(p))).join('L')}Z" fill="${col}" stroke="${shade(col, 0.6)}" stroke-width="${f1(0.15 * k)}" opacity="0.92"/>` }; }).sort((a, b) => a.z - b.z);
          C.p(...at3(16)); return vanes.map(v => v.s).join('') + o; };
        s += dart([-6.4, 65.6, 1.6], [-0.12, 0.2, 1], '#d8b84a', 1) + dart([1.8, 79.4, 1.6], [0.14, 0.16, 1], '#b8443a') + dart([23, 50.5, -2], [0.24, 0.08, 1], '#4a6a9a');
        // loose paint curl + hanging tape end (sway)
        const fa = C.P([-21.5, 92.4, -1.9]); s += `<g transform="translate(${P2(fa)}) scale(${n4(k)})"><g>${at('rotate', '0;-9;0', 5.2, 0, SPL(2))}<path d="M0 0C2.2 -1.4 5.4 -1 6.4 1.4C5.4 3.4 2.4 3.8 0 2.2Z" fill="#cdb48a"/><path d="M0 0C2.2 -1.4 5.4 -1 6.4 1.4C4.6 0.6 2 0.4 0 0Z" fill="${PNT}"/><path d="M6.4 1.4C5.4 3.4 2.4 3.8 0 2.2" stroke="#5f7466" stroke-width="0.3" fill="none"/></g></g>`;
        const ta = C.P([26.4, 95.6, -1.9]); s += `<g transform="translate(${P2(ta)}) scale(${n4(k)})"><g>${at('rotate', '0;6;0;-3;0', 4.6, 0, SPL(4))}<path d="M-1.4 0L1.4 0L1.8 7.4Q0.6 8.6 -1 7.8Z" fill="#e6d7a8" opacity="0.9"/><path d="M1.4 0L1.8 7.4" stroke="#c8b480" stroke-width="0.2"/></g></g>`;
        C.p(-30, BY, -4); C.p(30, BY + BH + 8, -4); C.p(0, 70, 18);
        const defs = DEFG + `<defs><radialGradient id="${id}rg" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.06"/><stop offset="1" stop-color="#000000" stop-opacity="0.3"/></radialGradient>`
          + `<radialGradient id="${id}dst" cx="45%" cy="40%" r="65%"><stop offset="0" stop-color="#d8cfb8" stop-opacity="0.05"/><stop offset="0.8" stop-color="#d8cfb8" stop-opacity="0.12"/><stop offset="1" stop-color="#000000" stop-opacity="0.25"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-031 NEON PINBALL MACHINE (T2): the playable pinball5 cabinet (playfield, flippers, ball, bumpers, backglass + score display, creature
    // player spot) is kept and wrapped as a second-hand machine: square black powder-coated legs bolted on with chrome leg bolts and threaded
    // levellers (one shimmed with a folded beer mat), chipped side art with bare wood showing on the corners and scratches along the side, a
    // strip of silver duct tape over a split on the backbox corner, and a cyan neon tube on the backbox that flickers like it is about to go.
    const pb5 = N.pinball5;
    if (pb5 && !pb5._w31) { const K = X.K, { box, cyl } = K, { mt, mtx } = RD.H3, CH = '#d5dde2';
      N.pinball5 = S => { const D = pb5(S), b0 = D.build, fx0 = D.fx, play = /play/.test(S.st || '');
        D.build = P => { const o = b0(P), legs = [];
          [[55, 33.1], [-55, 36.9]].forEach(([x, h]) => [-1, 1].forEach(sz => { const z = sz * 26.7, shim = x < 0 && sz < 0, y0 = shim ? 0.6 : 0;
            if (shim) legs.push(box(x, 0, z, 5.2, 0.6, 5.2, '#a8865a', mt({ r: 0.2 })));
            legs.push(cyl(x, y0, z, 2.3, 0.9, '#2a2a2e', mt({ n: 12 })), cyl(x, y0 + 0.9, z, 0.65, 2.2, '#a8aab0', mt({ n: 8, shine: 1 })), box(x, y0 + 3, z, 3.4, h + 8 - y0 - 3, 3.4, '#26262c', mt({ r: 0.3, shine: 1 })),
              box(x, y0 + 3, z, 3.8, 1.2, 3.8, '#1c1c20', mt({ r: 0.3 })));
            [h + 2.4, h + 5.8].forEach(by => legs.push(cyl(x, by, z + sz * 1.7, 0.75, 0.5, CH, mt({ n: 10, shine: 1 })))); }));
          o.splice(0, 12, ...legs); return o; };
        D.fx = c => { const r = fx0(c), p = c.p, k = c.k, R = rng('pb31'), sg = c.pbZ < 0 ? -1 : 1; surf = (O, U, V) => mtx(p(O[0], O[1], O[2]), p(O[0] + U[0], O[1] + U[1], O[2] + U[2]), p(O[0] + V[0], O[1] + V[1], O[2] + V[2]));
          const top = u => -(57 - u * 8 / 118), bot = u => -(37 - u * 4 / 118);
          let w = `<g transform="${surf([-59, 0, 25.45 * sg], [1, 0, 0], [0, -1, 0])}">`;
          [[116, 0], [116, 1], [2, 1], [2, 0], [60, 1], [88, 1]].forEach(([u, tb], i) => { const y = tb ? bot(u) - 0.4 : top(u) + 0.4, rr = 1.2 + R() * 1.4;
            w += `<path d="${blob(R, u, y, rr, 9)}" fill="#9a7a52" stroke="#5a4428" stroke-width="0.2"/>`; });
          w += rep(9, () => { const u = 10 + R() * 96, v = top(u) + 4 + R() * 10; return `<path d="M${f1(u)} ${f1(v)}l${f1(4 + R() * 9)} ${f1((R() - 0.5) * 3)}" stroke="#c8c0e0" stroke-width="${n4(0.12 + R() * 0.15)}" opacity="0.5"/>`; }).join('');
          w += `<rect x="70" y="${f1(top(70) + 8)}" width="9" height="5" rx="0.6" fill="#ffffff" opacity="0.1" transform="rotate(-3 74 ${f1(top(70) + 10)})"/></g>`;
          w += `<g transform="${surf([-61, 108.6, 27.1 * sg], [1, 0, 0], [0, -1, 0])}"><path d="M10 6.4l-2.6 2l-1.6 3" stroke="#120a20" stroke-width="0.3" fill="none"/><g transform="rotate(38 7 5)"><rect x="1" y="3" width="13" height="4" fill="#b8bcc4"/><path d="M1 3h13M1 7h13" stroke="#8a8e96" stroke-width="0.2"/>${rep(5, i => `<path d="M${2 + i * 2.6} 3.2l0.8 3.6" stroke="#ffffff" stroke-width="0.18" opacity="0.5"/>`).join('')}</g></g>`;
          if (c.pbBG === false) { w += `<g transform="${surf([-61.1, 108.6, -27], [0, 0, 1], [0, -1, 0])}"><rect x="4" y="4" width="46" height="42" rx="1" fill="#000" opacity="0.12"/>${rep(7, i => `<rect x="${17 + i * 3}" y="8" width="1.4" height="9" rx="0.6" fill="#0c0818"/>`).join('')}<rect x="8" y="36" width="9" height="5" rx="0.4" fill="#c8c4b8" opacity="0.75"/><path d="M9 38h6M9 39.6h4" stroke="#6a665e" stroke-width="0.3"/><circle cx="44" cy="44" r="1.6" fill="#0c0818"/></g>`;
            }
          const a = p(-51, 84, 27.4), b = p(-51, 107, 27.4);
          w += `<path d="M${P2(a)}L${P2(b)}" stroke="#1d1538" stroke-width="${f1(2.2 * k)}" stroke-linecap="round" opacity="0">${an('opacity', '0;0;0;0.9;0;0.9;0;0;0;0;0;0;0;0.9;0.9;0', 3.4, 0, ' calcMode="discrete"')}</path>`;
          r.front += w; return r; };
        return D; };
      N.pinball5._w31 = 1; }

    // CLB-051 2-PLAYER DANCE-MAT RHYTHM CABINET (T3): the playable danceCab (screen arrows, lit pads, 2 dancers by spec name) is kept and wrapped in
    // place: chrome safety bars behind each pad (posts on round foot plates, black foam grips) like real dance cabinets, and scuffed shoe marks on
    // the arrow panels and the step edge from heavy use.
    const dc5 = N.danceCab;
    if (dc5 && !dc5._w31) { const K = X.K, { box, cyl } = K, { mt, mtx, pt } = RD.H3, CH = '#d5dde2';
      N.danceCab = S => { const D = dc5(S), b0 = D.build, fx0 = D.fx;
        D.build = P => { const o = b0(P);
          [-42, 42].forEach(px => { [-33, 33].forEach(dx => o.push(cyl(px + dx, 5, 96, 3, 0.8, '#9aa0a8', mt({ n: 14, shine: 1 })), cyl(px + dx, 5.8, 96, 1.3, 35.4, CH, mt({ n: 12, shine: 1 }))));
            o.push(box(px, 40, 96, 68.6, 2.6, 2.6, CH, mt({ r: 1.3, shine: 1 })), box(px - 21, 39.8, 96, 16, 3, 3, '#1a1a1e', pt({ r: 1.5 })), box(px + 21, 39.8, 96, 16, 3, 3, '#1a1a1e', pt({ r: 1.5 }))); });
          return o; };
        D.fx = c => { const r = fx0(c), p = c.p, R = rng('dc31'), pl = (x, y, z) => mtx(p(x, y, z), p(x + 1, y, z), p(x, y, z + 1)); let w = '';
          [-42, 42].forEach(px => [[-1, 0], [0, 1], [0, -1], [1, 0], [0, 0]].forEach(([i, j]) => { const cx = px + i * 23, cz = 62 + j * 23;
            w += `<g transform="${pl(cx, 7.35, cz)}">${rep(i === 0 && j === 0 ? 2 : 4, () => `<ellipse cx="${f1((R() - 0.5) * 14)}" cy="${f1((R() - 0.5) * 14)}" rx="${f1(2 + R() * 3)}" ry="${f1(1 + R() * 1.6)}" fill="#1a1a1a" opacity="${n4(0.08 + R() * 0.1)}" transform="rotate(${Math.round(R() * 180)})"/>`).join('')}</g>`; }));
          w += `<g transform="${mtx(p(-89, 5, 100.1), p(-88, 5, 100.1), p(-89, 4, 100.1))}">${rep(14, () => `<path d="M${f1(R() * 176)} ${f1(0.4 + R() * 1.2)}h${f1(2 + R() * 6)}" stroke="#d8dce2" stroke-width="0.3" opacity="0.5"/>`).join('')}</g>`;
          r.front = w + r.front; return r; };
        return D; };
      N.danceCab._w31 = 1; }

    // CLB-091 FULL-BODY HOLOGRAPHIC RHYTHM-BATTLE ARENA & VR POD (T5): a round dance stage of walnut veneer on a polished brass base, its centre an
    // under-lit honey onyx disc ringed with brass inlay and four brass arrow inlays. Two slim brass columns at the back carry a brass halo ring
    // overhead with six warm spot lamps pointing in. A hologram of a dancing squish creature made of warm gold scan-lines bounces in the middle
    // while rhythm chevrons rise out of the floor around it; a cream VR headset with a tan leather strap hangs on the right column. Live: the
    // creature hologram bounces to the beat, the arrow inlays light in sequence, a beat ring ripples across the onyx, chevrons float up, the
    // spot cones breathe.
    N.arena31 = S => { const D = { w: 70, d: 70, round: 1, glow: () => ({ y: 50, r: 70, c: 'url(#gNeon)' }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('a91'), R = rng('arena31'), BR = '#c8a050', BRL = '#f2d79a', WAL = '#5a3420', BT = 0.9, RH = 112, RR = 32.8, th = thV(C);
        const dep = q => q[0] * C.v[0] + q[2] * C.v[2];
        const posts = [[-26, -20], [26, -20]].map(([x, z]) => ({ d: dep([x, 0, z]), s: cyl3(C, [x, 0, z], [x, 1.2, z], 3.2, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [x, 1.2, z], [x, RH, z], 1.5, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [x, RH - 2, z], [x, RH + 2.4, z], 2.4, BR, { mat: 'metal', olw: 0.2 }) }));
        const ringPts = (a0, a1, y) => arcP(RR, y, a0, a1, 28);
        const ringBack = line3(C, ringPts(th + PI / 2, th + 3 * PI / 2, RH), 2.4, '#8a6428') + line3(C, ringPts(th + PI / 2, th + 3 * PI / 2, RH + 0.8), 1.4, BR);
        const ringFront = line3(C, ringPts(th - PI / 2 - 0.02, th + PI / 2 + 0.02, RH), 2.4, '#8a6428') + line3(C, ringPts(th - PI / 2 - 0.02, th + PI / 2 + 0.02, RH + 0.8), 1.4, BR) + line3(C, ringPts(th - 0.8, th + 0.4, RH + 1.2), 0.5, BRL);
        // spot lamps + warm cones
        let lamps = '', cones = ''; const tc = C.P([0, 9, 0]);
        rep(6, i => { const a = i * PI / 3 + PI / 6, L = [Math.cos(a) * RR, RH - 1, Math.sin(a) * RR], q = C.P(L);
          lamps += cyl3(C, L, [L[0] * 0.92, RH - 6, L[2] * 0.92], 1.6, '#2a2018', { mat: 'metal', olw: 0.15, capCol: '#ffe6b0' });
          const dx = tc[0] - q[0], dy = tc[1] - q[1], dl = Math.hypot(dx, dy) || 1, nx = -dy / dl * 9 * k, ny = dx / dl * 9 * k;
          cones += `<path d="M${f1(q[0])} ${f1(q[1])}L${f1(tc[0] + nx)} ${f1(tc[1] + ny)}L${f1(tc[0] - nx)} ${f1(tc[1] - ny)}Z" fill="#ffe2a8" opacity="0.1" filter="url(#g31b1)">${an('opacity', '0.06;0.14;0.06', 2.6, -i * 0.43)}</path>`; });
        // stage
        const top = r => { const V = rng('a91t'); let t = `<circle r="${r}" fill="${WAL}"/>` + rep(16, i => { const a = i * PI / 8; return `<path d="M${f1(Math.cos(a) * 24.6)} ${f1(Math.sin(a) * 24.6)}L${f1(Math.cos(a) * r)} ${f1(Math.sin(a) * r)}" stroke="#3a2010" stroke-width="0.25"/>`; }).join('')
            + rep(10, () => { const rr = 25.4 + V() * 6, a0 = V() * 2 * PI; return `<path d="M${f1(Math.cos(a0) * rr)} ${f1(Math.sin(a0) * rr)}A${f1(rr)} ${f1(rr)} 0 0 1 ${f1(Math.cos(a0 + 0.5) * rr)} ${f1(Math.sin(a0 + 0.5) * rr)}" stroke="#7a4a2a" stroke-width="0.3" fill="none" opacity="0.7"/>`; }).join('');
          t += `<circle r="25" fill="none" stroke="${BR}" stroke-width="1.1"/><circle r="24.4" fill="url(#${id}ox)"/>` + rep(6, () => { const y0 = -24 + V() * 48; return `<path d="M-25 ${f1(y0)}Q${f1((V() - 0.5) * 20)} ${f1(y0 + (V() - 0.5) * 10)} 25 ${f1(y0 + (V() - 0.5) * 6)}" stroke="#fff4d8" stroke-width="${n4(0.4 + V() * 0.8)}" fill="none" opacity="0.28"/>`; }).join('');
          t += `<g clip-path="url(#${id}oc)"><circle r="8" fill="none" stroke="#fff2c8" stroke-width="0.8" opacity="0">${an('r', '8;24', BT)}${an('opacity', '0.7;0', BT)}</circle></g><clipPath id="${id}oc"><circle r="24.4"/></clipPath>`;
          t += [16, 8].map(rr => `<circle r="${rr}" fill="none" stroke="${BR}" stroke-width="0.6"/>`).join('') + `<circle r="2.4" fill="${BR}"/>`;
          rep(4, i => { const a = i * PI / 2, x = Math.cos(a) * 20, y = Math.sin(a) * 20; t += `<g transform="translate(${f1(x)} ${f1(y)}) rotate(${i * 90 + 90})"><path d="M0 -3.4L3.2 0H1.3V3H-1.3V0H-3.2Z" fill="${BR}" stroke="#6a4a1c" stroke-width="0.2"/><path d="M0 -3.4L3.2 0H1.3V3H-1.3V0H-3.2Z" fill="#fff0c0" opacity="0">${an('opacity', rep(4, j => j === i ? '0.9' : '0').join(';'), BT * 4, 0, ' calcMode="discrete"')}</path></g>`; });
          return t + `<circle r="${r}" fill="url(#${id}gl)"/>`; };
        let stage = PLN(C, 0.1, `<circle r="52" fill="url(#${id}fl)"/>`) + shadow(C, 0, 0, 36, 36, 0.45);
        stage += cyl3(C, [0, 0, 0], [0, 2, 0], 33.4, BR, { mat: 'metal', olw: 0.25 }) + cyl3(C, [0, 2, 0], [0, 9, 0], 32, WAL, { mat: 'gloss', olw: 0.3, cap: top });
        rep(18, i => { const a = th - 1.4 + i * 2.8 / 17; stage += line3(C, [[Math.cos(a) * 32.1, 2.6, Math.sin(a) * 32.1], [Math.cos(a + 0.02) * 32.1, 8.4, Math.sin(a + 0.02) * 32.1]], 0.2, '#2e1a0c', 'opacity="0.5"'); });
        stage += line3(C, frontArc(C, 32.2, 5.4, 30), 0.7, BR);
        // hologram creature
        const hb = C.P([0, 9.4, 0]), S8 = n4(k * 0.95);
        const body = 'M-13 0C-15.4 -10 -14 -24 -6 -28C-2 -29.6 2 -29.6 6 -28C14 -24 15.4 -10 13 0C8 1.6 -8 1.6 -13 0Z', ears = 'M-9.6 -25L-12 -36L-3.6 -28.4ZM9.6 -25L12 -36L3.6 -28.4Z';
        let holo = `<ellipse cx="${f1(hb[0])}" cy="${f1(hb[1])}" rx="${f1(16 * k)}" ry="${f1(16 * k * 0.5)}" fill="url(#${id}hp)">${an('opacity', '0.6;1;0.6', BT)}</ellipse>`;
        holo += `<g transform="translate(${P2(hb)}) scale(${S8})"><g>${at('translate', '0 0;0 -7;0 0;0 0', BT, 0, ' calcMode="spline" keyTimes="0;0.42;0.84;1" keySplines="0.2 0.6 0.4 1;0.6 0 0.8 0.4;0 0 1 1"')}<g>${at('scale', '1.08 0.9;0.96 1.05;1 1;1.08 0.9', BT, 0, ' keyTimes="0;0.3;0.7;1"')}`
          + `<path d="${body}${ears}" fill="#ffd27a" opacity="0.18" filter="url(#g31b1)"/><path d="${body}${ears}" fill="url(#${id}sc)" opacity="0.75"/><path d="${body}${ears}" fill="none" stroke="#fff0c0" stroke-width="0.6" opacity="0.9"/>`
          + `<ellipse cx="-4.4" cy="-17" rx="1.4" ry="2" fill="#fff6dc"/><ellipse cx="4.4" cy="-17" rx="1.4" ry="2" fill="#fff6dc"/><path d="M-3 -11.4Q0 -8.6 3 -11.4" stroke="#fff6dc" stroke-width="0.7" fill="none" stroke-linecap="round"/>`
          + `<path d="M-13 -12q-6 -6 -4 -13M13 -12q6 -6 4 -13" stroke="#ffe0a0" stroke-width="1.6" fill="none" stroke-linecap="round" opacity="0.8">${an('d', 'M-13 -12q-6 -6 -4 -13M13 -12q6 -6 4 -13;M-13 -12q-8 2 -11 -4M13 -12q8 2 11 -4;M-13 -12q-6 -6 -4 -13M13 -12q6 -6 4 -13', BT * 2)}</path>`
          + `<rect x="-16" y="-40" width="32" height="2" fill="#fff6dc" opacity="0.25">${an('y', '-40;2', 1.6)}</rect>`
          + `</g></g></g>`; C.p(0, 50, 0);
        // rhythm chevrons rising from the floor ring
        const CC = ['#ff9a8a', '#ffd070', '#ffb060', '#f6b8c8'];
        let chev = ''; rep(8, i => { const a = th - 1.3 + (i % 4) * 0.87, q = C.P([Math.cos(a) * 21, 9.4, Math.sin(a) * 21]), T = 2.4, b = -i * T / 8 - (i > 3 ? 1.2 : 0);
          chev += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><g opacity="0">${at('translate', '0 0;0 -46', T, b)}${an('opacity', '0;0.9;0.9;0', T, b, KT('0;0.15;0.7;1'))}<path d="M-3.4 1.6L0 -1.8L3.4 1.6" stroke="${CC[i % 4]}" stroke-width="1.3" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M-3.4 1.6L0 -1.8L3.4 1.6" stroke="${CC[i % 4]}" stroke-width="3" fill="none" opacity="0.3" filter="url(#g31b1)"/></g></g>`; });
        // VR headset on the right column hook
        const hk = [27.4, 66, -18.6];
        const vr = line3(C, [[26, 66, -20], hk], 0.5, BR) + line3(C, [hk, [24.2, 58, -14.6], [27, 55.6, -13.8], [33.6, 56.4, -14.8], [34.2, 59, -16.8], hk], 1.1, '#b8875a') + line3(C, [hk, [30.4, 58.6, -13]], 0.9, '#a27448')
          + B10(C, { c: [29.4, 51.6, -12.4], w: 11, h: 6, d: 6.4, col: '#e8e0d0', r: 2.2, dec: { f: `<rect width="11" height="6" rx="1.6" fill="#1a1a1e"/><rect x="0.8" y="0.8" width="9.4" height="1.4" rx="0.6" fill="#ffffff" opacity="0.18"/><rect x="0" y="4.9" width="11" height="0.5" fill="${BR}"/>` } });
        C.p(-36, 0, -36); C.p(36, 0, 36); C.p(36, 0, -36); C.p(-36, 0, 36); C.p(0, RH + 3, -RR); C.p(-RR, RH + 3, 0); C.p(RR, RH + 3, 0); C.p(0, RH + 3, RR);
        const backPosts = posts.filter(o => o.d < 0).map(o => o.s).join(''), frontPosts = posts.filter(o => o.d >= 0).map(o => o.s).join('');
        const vrFront = dep([29, 0, -14]) >= 0;
        const s = backPosts + (vrFront ? '' : vr) + ringBack + stage + cones + holo + chev + lamps + ringFront + frontPosts + (vrFront ? vr : '');
        const defs = DEFG + `<defs><radialGradient id="${id}fl"><stop offset="0" stop-color="#ffcf8a" stop-opacity="0.45"/><stop offset="0.7" stop-color="#e8a858" stop-opacity="0.12"/><stop offset="1" stop-color="#e8a858" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}ox" cx="50%" cy="50%" r="55%"><stop offset="0" stop-color="#fff0c8"/><stop offset="0.45" stop-color="#f4c87a"/><stop offset="0.85" stop-color="#c8843a"/><stop offset="1" stop-color="#8a5220"/></radialGradient>`
          + `<radialGradient id="${id}gl" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.14"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.16"/></radialGradient>`
          + `<radialGradient id="${id}hp"><stop offset="0" stop-color="#fff2c8" stop-opacity="0.8"/><stop offset="1" stop-color="#ffd27a" stop-opacity="0"/></radialGradient>`
          + `<pattern id="${id}sc" width="2" height="1.6" patternUnits="userSpaceOnUse"><rect width="2" height="1.6" fill="#ffd27a" opacity="0.35"/><rect width="2" height="0.7" fill="#ffe8b0"/></pattern></defs>`;
        return { defs, front: s, bb: C.bb(4) }; };
      return D; };

    // DJ CONSOLES CLB-015 / 035 / 055: the shared playable djBooth (gear, spinning decks, EQ, DJ creature by spec name) is kept; plus31 wraps it in place
    // with per-variant realism. table (015): a sticky soda can and a crumpled paper cup on the table, a drink-ring stain and a duct-tape patch on the
    // bed-sheet banner, an orange extension cord and a cheap power strip on the floor. plywood (035, art fixed in plus5: wordless bubble throw-up
    // instead of a word, screws, stickers, kick scuffs): gaffer-taped cable run on the floor. truss (055): zig-zag lacing between the paired truss
    // tubes on the near legs and square aluminium base plates; the acrylic is frosted warm white now (plus5).
    const dj5 = N.djBooth;
    if (dj5 && !dj5._w31) {
      N.djBooth = S => { const D = dj5(S), fx0 = D.fx, v = S.v || 'plywood'; if (!/^(table|plywood|truss|ctrl|vinyl|quad)$/.test(v)) return D;
        D.fx = c => { const r = fx0(c), C = cam(c), k = C.k, R = rng('dj31' + v), HW = 62, DD = 50, TOP = 40, mtx = RD.H3.mtx, p = c.p; let w = '', un = '';
          if (v === 'table') {
            const FZ = DD / 2 + 1.05, FP = (x0, y) => mtx(p(x0, y, FZ), p(x0 + 1, y, FZ), p(x0, y - 1, FZ));
            w += `<g transform="${FP(-HW + 3, 36)}"><circle cx="30" cy="12" r="4.2" fill="none" stroke="#a8875a" stroke-width="0.9" opacity="0.45"/><circle cx="31" cy="12.6" r="3.6" fill="#c8a878" opacity="0.12"/>`
              + `<g transform="rotate(-8 100 22)"><rect x="95" y="19" width="12" height="5" fill="#9ea2a8"/><path d="M95 20.4h12M95 22.8h12" stroke="#7a7e86" stroke-width="0.25"/>${rep(4, i => `<path d="M${97 + i * 2.6} 19.2l0.5 4.6" stroke="#ffffff" stroke-width="0.2" opacity="0.5"/>`).join('')}</g>`
              + `<path d="M60 0q2 14 -1 30M76 0q-2 14 1 30" stroke="#000" stroke-width="2.4" opacity="0.05" fill="none"/></g>`;
            w += cyl3(C, [48, 39.6, 14], [48, 45.2, 14], 2.1, '#c8322a', { olw: 0.2, capCol: '#c8ccd2' }) + cyl3(C, [48, 44.6, 14], [48, 45.2, 14], 2.1, '#c8ccd2', { mat: 'metal', olw: 0.15 });
            w += line3(C, [[52, 39.7, 6], [55.6, 39.7, 8.6], [54, 39.7, 3]], 2.6, '#f4f1ea', 'opacity="0.95"') + line3(C, [[52.4, 40.4, 5.6], [55, 40.2, 7.6]], 0.6, '#d8d2c4');
            un += line3(C, [[HW - 6, 0.3, -6], [HW + 1, 0.3, 4], [HW - 1, 0.3, 16], [HW + 3, 0.3, 26], [HW + 8, 0.3, 30]], 1.1, '#f08a28')
              + B10(C, { c: [HW + 2, 0, 33], w: 16, h: 2.4, d: 5, col: '#e8e4dc', r: 1, dec: { t: `<rect width="16" height="5" fill="#e8e4dc"/>${rep(4, i => `<rect x="${2 + i * 3.4}" y="1.4" width="1.6" height="2.2" rx="0.4" fill="#2a2a2e"/>`).join('')}<rect x="14" y="1.6" width="1.2" height="1.8" fill="#e83a2a"/>` } })
              + line3(C, [[HW + 4, 1.4, 33], [HW - 2, 0.3, 38], [HW - 14, 0.3, 37]], 0.8, '#1a1a1e');
            C.p(HW + 11, 0, 38); }
          else if (v === 'plywood') {
            un += line3(C, [[-HW + 6, 0.3, DD / 2 + 2], [-HW - 2, 0.3, DD / 2 + 8], [-HW - 8, 0.3, DD / 2 + 7]], 0.9, '#1a1a1e') + line3(C, [[-HW + 8, 0.3, DD / 2 + 2.6], [-HW - 1, 0.3, DD / 2 + 9], [-HW - 8, 0.3, DD / 2 + 8.6]], 0.7, '#2a2a30')
              + `<g transform="${mtx(p(-HW - 1, 0.35, DD / 2 + 7.6), p(-HW, 0.35, DD / 2 + 7.6), p(-HW - 1, 0.35, DD / 2 + 8.6))}"><rect x="-4" y="-2" width="9" height="5" fill="#2a2a2e" opacity="0.9" transform="rotate(20)"/></g>`;
            C.p(-HW - 10, 0, DD / 2 + 10); }
          else if (v === 'ctrl') {
            // laptop: keyboard deck on the aluminium stand + bezel, sticky note; cheap headphones + energy drink on the desk
            const kx = -HW + 14, ky = TOP + 7.05, kz = -10;
            w += PLN(C, ky, `<rect x="-8.6" y="-6.6" width="17.2" height="12.4" rx="0.8" fill="#2a2c32"/>${rep(4, j => rep(12, i => `<rect x="${f1(-7.6 + i * 1.3)}" y="${f1(-5.6 + j * 1.5)}" width="1.05" height="1.2" rx="0.2" fill="#141518"/>`).join('')).join('')}<rect x="-2.6" y="1.4" width="5.2" height="3.4" rx="0.4" fill="#34363c"/>`, kx, kz);
            w += VPL(C, [kx - 9.4, TOP + 7 + 12.6, -16.2], `<rect width="18.8" height="12.2" rx="0.8" fill="none" stroke="#1a1b20" stroke-width="1.1"/><rect x="13.4" y="8" width="4.4" height="4" fill="#f4e36a" transform="rotate(8 15.6 10)"/>`);
            w += phones(C, 50, TOP, 9, '#1c1c20', '#3a3c42', 0) + cyl3(C, [53, TOP, -13], [53, TOP + 7.4, -13], 2, '#1e8a4a', { olw: 0.2, capCol: '#c8ccd2' }) + cyl3(C, [53, TOP + 6.8, -13], [53, TOP + 7.4, -13], 2, '#c8ccd2', { mat: 'metal', olw: 0.15 })
              + line3(C, [[38, TOP + 1.6, -14], [44, TOP + 0.4, -18], [56, TOP + 0.4, -20], [60, TOP - 1, -21.6], [61, 20, -21.6]], 0.6, '#101012'); }
          else if (v === 'vinyl') {
            // a record sleeve leaning against the crate, a record half out; headphones on a hook on the right side panel
            w += `<g transform="${FR(C, [-52, 0, 16.4], [1, 0, 0], [0, -0.97, 0.24])}"><circle cx="9.6" cy="6.6" r="6" fill="#111114"/><circle cx="9.6" cy="6.6" r="1.6" fill="#d9a03a"/>`
              + `<rect width="13" height="13" fill="#e8dcc4"/><circle cx="6.5" cy="6.5" r="4.6" fill="#c8402e"/><circle cx="6.5" cy="6.5" r="2.4" fill="#2a3c6a"/><path d="M0 11h13" stroke="#2a2a2e" stroke-width="0.6"/><path d="M0.6 0.6l3 -0.2" stroke="#ffffff" stroke-width="0.3" opacity="0.6"/></g>`;
            C.p(-54, 14, 18);
            const hx = HW - 1 + 0.6; w += cyl3(C, [hx, 30, 6], [hx + 2.6, 30, 6], 0.5, '#c8ccd2', { mat: 'metal', olw: 0.1 }) + line3(C, [[hx + 2.4, 30.4, 1], [hx + 3, 34, 6], [hx + 2.4, 30.4, 11]], 1.2, '#1c1c20')
              + cyl3(C, [hx + 2.2, 26.4, 0.4], [hx + 4.4, 26.4, 0.4], 3.2, '#1c1c20', { olw: 0.2 }) + cyl3(C, [hx + 2.2, 26.4, 11.6], [hx + 4.4, 26.4, 11.6], 3.2, '#1c1c20', { olw: 0.2 })
              + line3(C, [[hx + 2.4, 30.4, 1], [hx + 2.6, 27.6, 0.4]], 0.9, '#2a2a30') + line3(C, [[hx + 2.4, 30.4, 11], [hx + 2.6, 27.6, 11.6]], 0.9, '#2a2a30'); C.p(hx + 6, 34, 6); }
          else if (v === 'quad') {
            // leather and brass headphones hung on a brass hook at the right end; a cut-crystal tumbler on the back ledge
            const hx = HW + 0.8; w += cyl3(C, [hx - 1, 33, 4], [hx + 2.6, 33, 4], 0.6, '#d8b060', { mat: 'metal', olw: 0.1 }) + line3(C, [[hx + 2.4, 33.4, -1.4], [hx + 3, 37.4, 4], [hx + 2.4, 33.4, 9.4]], 1.4, '#5a3420') + line3(C, [[hx + 2.6, 34.6, -0.6], [hx + 3.2, 37.6, 4], [hx + 2.6, 34.6, 8.6]], 0.4, '#d8b060')
              + cyl3(C, [hx + 2, 29.4, -1.8], [hx + 4.6, 29.4, -1.8], 3.4, '#6a3c22', { olw: 0.2, capCol: '#d8b060' }) + cyl3(C, [hx + 2, 29.4, 9.8], [hx + 4.6, 29.4, 9.8], 3.4, '#6a3c22', { olw: 0.2, capCol: '#d8b060' })
              + line3(C, [[hx + 2.4, 33.4, -1.4], [hx + 2.8, 31, -1.8]], 0.9, '#d8b060') + line3(C, [[hx + 2.4, 33.4, 9.4], [hx + 2.8, 31, 9.8]], 0.9, '#d8b060'); C.p(hx + 8, 38, 4); }
          else {
            [-1, 1].forEach(s => [-1, 1].forEach(t => { const z = t * (DD / 2 - 3), x1 = s * (HW - 3), x2 = s * (HW - 7);
              un += B10(C, { c: [(x1 + x2) / 2, 0, z], w: 10, h: 0.8, d: 10, col: '#a8acb2', r: 0.6, mat: 'brush' });
              if (x1 * C.v[0] + z * C.v[2] < 0) return;
              const P = []; rep(9, i => P.push([i % 2 ? x2 : x1, 1.5 + i * 4, z])); w += line3(C, P, 0.7, '#c8ccd2') + line3(C, P, 0.25, '#ffffff', 'opacity="0.6"'); }));
          }
          r.front += w; r.under = (r.under || '') + un; const b2 = C.bb(3); if (r.bb && b2) r.bb = [Math.min(r.bb[0], b2[0]), Math.min(r.bb[1], b2[1]), Math.max(r.bb[2], b2[2]), Math.max(r.bb[3], b2[3])]; return r; };
        return D; };
      N.djBooth._w31 = 1; }

    // CLB-018 SECONDHAND BOOMBOX & TANGLED AUX CORD (T1): the playable boom80 (cassette door, rolling reels, pumping woofers, notes) is kept and
    // wrapped in place as a worn thrift-store find: scratches and a scuffed patch on the fascia, a dent with a torn hole in the left woofer grille,
    // a peeling smiley sticker on the right grille, a missing tuning knob (bare shaft), a strip of grey duct tape over a cracked corner, a twist of
    // electrical tape on the antenna, and a dull yellowed tint over the chrome.
    const bx6 = N.boom80;
    if (bx6 && !bx6._w31) {
      N.boom80 = S => { const D = bx6(S), fx0 = D.fx;
        D.fx = c => { const r = fx0(c), p = c.p, k = c.k, R = rng('bx31'), mtx = RD.H3.mtx, FR3 = mtx(p(-40, 46, 11.02), p(-39, 46, 11.02), p(-40, 45, 11.02));
          let s = rep(16, () => { const u = R() * 80, v = R() * 42; return `<path d="M${f1(u)} ${f1(v)}l${f1(2 + R() * 8)} ${f1((R() - 0.5) * 2.4)}" stroke="#d8dce2" stroke-width="${n4(0.1 + R() * 0.15)}" opacity="${n4(0.25 + R() * 0.35)}"/>`; }).join('');
          s += `<path d="M18 26.4q3 -1.6 5.6 0.4q-0.8 3 -3.4 3.6q-2.6 -0.8 -2.2 -4Z" fill="#050507"/><path d="M18 26.4q3 -1.6 5.6 0.4" stroke="#8a8e96" stroke-width="0.35" fill="none"/><path d="M19.4 27.6l2.4 1.6M21.6 27l-1 2.6" stroke="#5a5e66" stroke-width="0.25"/>`
            + `<path d="M11 31q4 3 9 1" stroke="#ffffff" stroke-width="0.4" fill="none" opacity="0.2"/>`;
          s += `<g transform="rotate(14 72 33)"><circle cx="72" cy="33" r="3.2" fill="#f2c94c" opacity="0.92"/><circle cx="70.9" cy="32.2" r="0.45" fill="#2a2010"/><circle cx="73.1" cy="32.2" r="0.45" fill="#2a2010"/><path d="M70.4 33.8q1.6 1.4 3.2 0" stroke="#2a2010" stroke-width="0.4" fill="none"/><path d="M74.6 31.4q1.6 0.4 1 2.2l-1.6 -0.6Z" fill="#f4f1ea" opacity="0.9"/></g>`;
          s += `<circle cx="15" cy="5.5" r="3.4" fill="#141518"/><circle cx="15" cy="5.5" r="1.1" fill="#8a8e96" stroke="#4a4d52" stroke-width="0.3"/><path d="M14.4 5.5h1.2" stroke="#4a4d52" stroke-width="0.3"/>`;
          s += `<g transform="rotate(-38 3 3)"><rect x="-4" y="1" width="14" height="4.4" fill="#9ea2a8"/><path d="M-4 2.2h14M-4 4.2h14" stroke="#7a7e86" stroke-width="0.25"/>${rep(5, i => `<path d="M${-2 + i * 2.6} 1.2l0.6 4" stroke="#ffffff" stroke-width="0.2" opacity="0.5"/>`).join('')}</g>`;
          s += `<rect width="80" height="42" fill="#e8c890" opacity="0.06"/>`;
          let w = `<g transform="${FR3}">${s}</g>`;
          const a1 = p(45, 68, -9), a2 = p(47.4, 73.4, -9.8); w += `<path d="M${P2(a1)}L${P2(a2)}" stroke="#141418" stroke-width="${f1(1.6 * k)}" stroke-linecap="round"/><path d="M${P2(a1)}L${P2(a2)}" stroke="#3a3a40" stroke-width="${f1(0.5 * k)}" stroke-dasharray="${f1(0.6 * k)} ${f1(0.6 * k)}"/>`;
          r.front += w; return r; };
        return D; };
      N.boom80._w31 = 1; }

    // CLB-098 GESTURE-CONTROLLED NEURAL SYNTH & HOLOGRAPHIC SOUND-SCULPTING ARRAY (T5): a round walnut synth table with a brass edge on a fluted
    // walnut pedestal and a polished brass base. On it sits a walnut-cased modular synth with a slanted black panel full of brass knobs, a small
    // amber scope screen and coloured patch cables, flanked by the two brass antennas of a theremin (an upright pitch rod and a volume loop), the
    // real gesture-played instrument. Above the table a warm gold light-sculpture of the sound (a looping 3D ribbon) turns and reshapes, with
    // sparks drifting off it. Live: the ribbon morphs and turns, knob lights and the scope trace move, the cables sway slightly.
    N.synth31 = S => { const D = { w: 70, d: 70, round: 1, glow: () => ({ y: 50, r: 70, c: 'url(#gNeon)' }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('s98'), R = rng('synth31'), BR = '#c8a050', BRL = '#f2d79a', WAL = '#5a3420', TY = 40, th = thV(C);
        let s = PLN(C, 0.1, `<circle r="44" fill="url(#${id}fl)"/>`) + shadow(C, 0, 0, 30, 30, 0.45);
        s += cyl3(C, [0, 0, 0], [0, 2.4, 0], 24, BR, { mat: 'metal', olw: 0.25 }) + cyl3(C, [0, 2.4, 0], [0, 5, 0], 16, WAL, { mat: 'gloss', olw: 0.25, r2: 12 });
        s += cyl3(C, [0, 5, 0], [0, TY - 3, 0], 9.6, WAL, { mat: 'gloss', olw: 0.3, r2: 8.4 });
        rep(9, i => { const a = th - 1.25 + i * 2.5 / 8; s += line3(C, [[Math.cos(a) * 9.5, 6, Math.sin(a) * 9.5], [Math.cos(a) * 8.3, TY - 4, Math.sin(a) * 8.3]], 0.45, '#2e1a0c', 'opacity="0.7"'); });
        s += line3(C, frontArc(C, 9.2, 14, 16), 1, BR) + line3(C, frontArc(C, 8.6, TY - 6, 16), 1, BR);
        const topCap = r => `<clipPath id="${id}tc"><circle r="${r}"/></clipPath><circle r="${r}" fill="${WAL}"/><g clip-path="url(#${id}tc)">` + rep(12, i => `<path d="M${f1(-r)} ${f1(-r + i * r / 6 + (i % 3))}Q0 ${f1(-r + i * r / 6 - 2)} ${f1(r)} ${f1(-r + i * r / 6 + 1)}" stroke="#3e2210" stroke-width="0.35" fill="none" opacity="0.6"/>`).join('') + `</g><circle r="${n4(r - 0.8)}" fill="none" stroke="${BR}" stroke-width="1.2"/><circle r="${r}" fill="url(#${id}gl)"/>`;
        s += cyl3(C, [0, TY - 3, 0], [0, TY, 0], 30, BR, { mat: 'metal', olw: 0.3, cap: topCap });
        // theremin volume loop (left) + pitch rod (right back)
        const loop = () => line3(C, [[-22, TY + 2, 4], [-30, TY + 2, 4]], 0.8, BR) + line3(C, rep(17, i => { const a = i / 16 * 2 * PI; return [-34 + Math.cos(a) * 4, TY + 2, 4 + Math.sin(a) * 7]; }), 0.9, BR) + line3(C, rep(17, i => { const a = i / 16 * 2 * PI; return [-34 + Math.cos(a) * 4, TY + 2.4, 4 + Math.sin(a) * 7]; }), 0.3, BRL);
        const rod = () => cyl3(C, [20, TY, -10], [20, TY + 3, -10], 2.2, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [20, TY + 3, -10], [20, TY + 46, -10], 0.65, BR, { mat: 'metal', olw: 0.15 }) + sph(C, [20, TY + 46.6, -10], 0.9, BRL);
        // modular synth case with slanted panel
        const A = [[1, 0, 0], [0, Math.cos(-0.5), Math.sin(-0.5)], [0, -Math.sin(-0.5), Math.cos(-0.5)]];
        const knobs = rep(4, j => rep(8, i => { const x = 3.2 + i * 4.4, y = 3 + j * 3.8, lit = (i * 3 + j * 5) % 7 === 0; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="1.25" fill="${BR}" stroke="#6a4a1c" stroke-width="0.2"/><path d="M${f1(x)} ${f1(y)}l${f1(Math.cos(i + j) * 1.1)} ${f1(Math.sin(i + j) * 1.1)}" stroke="#2a1a08" stroke-width="0.3"/>`
          + (lit ? `<circle cx="${f1(x + 1.7)}" cy="${f1(y - 1.2)}" r="0.35" fill="#ffb84a">${an('opacity', '1;0.2;1', n4(0.8 + (i + j) * 0.13), -i * 0.2)}</circle>` : ''); }).join('')).join('');
        const scope = `<rect x="27" y="10.6" width="10" height="6" rx="0.6" fill="#140c04" stroke="${BR}" stroke-width="0.3"/><path d="M27.6 13.6q1.2 -2.4 2.4 0t2.4 0t2.4 0t2 0" stroke="#ffb84a" stroke-width="0.35" fill="none">${an('d', 'M27.6 13.6q1.2 -2.4 2.4 0t2.4 0t2.4 0t2 0;M27.6 13.6q1.2 2 2.4 0t2.4 0t2.4 0t2 0;M27.6 13.6q1.2 -2.4 2.4 0t2.4 0t2.4 0t2 0', 1.2)}</path>`;
        const cables = [['#d8443a', 5.4, 6.8, 18.6, 10.6], ['#e8b830', 9.8, 3, 23, 6.8], ['#3a7ac8', 14.2, 10.6, 31.4, 3], ['#e8e2d4', 22.6, 14.4, 7.6, 14.4]].map(([c, x1, y1, x2, y2]) => `<path d="M${x1} ${y1}Q${f1((x1 + x2) / 2)} ${f1(Math.max(y1, y2) + 5)} ${x2} ${y2}" stroke="#000" stroke-width="1" fill="none" opacity="0.25" transform="translate(0.4 0.6)"/><path d="M${x1} ${y1}Q${f1((x1 + x2) / 2)} ${f1(Math.max(y1, y2) + 5)} ${x2} ${y2}" stroke="${c}" stroke-width="0.8" fill="none" stroke-linecap="round"/>`).join('');
        const panel = `<rect width="40" height="18" fill="#141210"/>${knobs}${scope}${cables}<rect x="0.4" y="0.4" width="39.2" height="17.2" fill="none" stroke="${BR}" stroke-width="0.35"/>`;
        const sideW = w => `<rect width="${w}" height="9" fill="${WAL}"/>${rep(3, i => `<path d="M0 ${2 + i * 2.6}q${w / 2} -0.8 ${w} 0" stroke="#3e2210" stroke-width="0.3" fill="none"/>`).join('')}`;
        const synth = B10(C, { c: [0, TY, 6], ax: A, w: 42, h: 9, d: 18, col: WAL, r: 1, dec: { t: panel, f: sideW(42), b: sideW(42), l: sideW(18), r: sideW(18) } });
        const fr = C.v[2] >= 0, rodBack = 20 * C.v[0] - 10 * C.v[2] < 6 * C.v[2];
        s += (rodBack ? rod() : '') + (C.v[0] < 0 ? loop() : '') + synth + (rodBack ? '' : rod()) + (C.v[0] < 0 ? '' : loop());
        // gold light-sculpture of the sound
        const HY = 84, rib = ph => rep(49, i => { const t = i / 48 * 2 * PI; return C.P([13 * Math.sin(3 * t + ph), HY + 7 * Math.sin(5 * t + ph * 0.5), 13 * Math.sin(2 * t)]); });
        const dOf = q => 'M' + q.map(P2).join('L') + 'Z', F = [0, 0.7, 1.4, 0.7, 0].map(ph => dOf(rib(ph))).join(';');
        const ribbon = `<path d="${dOf(rib(0))}" fill="none" stroke="#ffd27a" stroke-width="${f1(3.4 * k)}" opacity="0.35" filter="url(#g31b1)">${an('d', F, 7)}</path><path d="${dOf(rib(0))}" fill="none" stroke="url(#${id}rb)" stroke-width="${f1(0.9 * k)}" stroke-linejoin="round">${an('d', F, 7)}</path>`;
        const hc = C.P([0, HY, 0]);
        let holo = `<circle cx="${f1(hc[0])}" cy="${f1(hc[1])}" r="${f1(22 * k)}" fill="url(#${id}ha)">${an('opacity', '0.5;0.9;0.5', 3.5)}</circle>` + ribbon;
        holo += rep(10, i => { const Q = rng('s98p' + i), a = Q() * 2 * PI, q = C.P([Math.cos(a) * 10, HY + (Q() - 0.5) * 10, Math.sin(a) * 10]), d = n4(2.4 + Q() * 2), b = -Q() * d;
          return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.7 * k)}" fill="#fff0c8" opacity="0">${at('translate', `0 0;${f1(Math.cos(a) * 12 * k)} ${f1(-14 * k)}`, d, b)}${an('opacity', '0;1;0', d, b)}</circle>`; }).join('');
        const lamp = C.P([0, TY + 2, 6]); holo = `<path d="M${f1(lamp[0] - 2 * k)} ${f1(lamp[1])}L${f1(hc[0] - 16 * k)} ${f1(hc[1])}L${f1(hc[0] + 16 * k)} ${f1(hc[1])}L${f1(lamp[0] + 2 * k)} ${f1(lamp[1])}Z" fill="url(#${id}bm)" opacity="0.5"/>` + holo;
        s += holo;
        C.p(-36, 0, -36); C.p(36, 0, 36); C.p(36, 0, -36); C.p(-36, 0, 36); C.p(0, HY + 18, 0); C.p(-16, HY, 0); C.p(16, HY, 0); C.p(20, TY + 48, -10);
        const defs = DEFG + `<defs><radialGradient id="${id}fl"><stop offset="0" stop-color="#ffcf8a" stop-opacity="0.4"/><stop offset="1" stop-color="#e8a858" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}gl" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.16"/></radialGradient>`
          + `<linearGradient id="${id}rb" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff2c8"/><stop offset="0.5" stop-color="#ffc870"/><stop offset="1" stop-color="#ff9a8a"/></linearGradient>`
          + `<radialGradient id="${id}ha"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.5"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient>`
          + `<linearGradient id="${id}bm" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.6"/><stop offset="1" stop-color="#ffe2a8" stop-opacity="0"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(4) }; };
      return D; };

    // CLB-003 SPOOL-TOP TABLE WITH NEON STICKERS (T1): an old industrial cable spool stood on end as a table: rough plywood flanges with splintered
    // edges, stencilled rings and an arrow, a black-stained central hole and four rusty hex bolts, a slatted barrel, peeling neon stickers (pink,
    // green, yellow star) on the top, drink rings, bottle caps and a dented can. Beside it an upturned red plastic crate serves as an extra stand
    // with a candle stuck in a bottle. Live: the candle flame flickers and a loose sticker corner lifts in the draft.
    N.spool31 = S => { const D = { w: 122, d: 66, round: 1, topH: 44, topW: 46, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('s03'), R = rng('spool31'), PW = '#b8946a', PD = '#8a6a44', TY = 44;
        let s = shadow(C, 0, 0, 34, 30, 0.4) + shadow(C, 44, 4, 14, 10, 0.3);
        const flangeCap = (r, top) => { const V = rng('sp' + top); let t = `<clipPath id="${id}c${top}"><circle r="${r}"/></clipPath><circle r="${r}" fill="${PW}"/><g clip-path="url(#${id}c${top})">` + rep(10, i => `<path d="M${f1(-r)} ${f1(-r + i * r / 5)}Q0 ${f1(-r + i * r / 5 + (V() - 0.5) * 4)} ${f1(r)} ${f1(-r + i * r / 5 + (V() - 0.5) * 2)}" stroke="${PD}" stroke-width="0.3" fill="none" opacity="0.6"/>`).join('') + '</g>';
          t += `<circle r="${n4(r - 0.4)}" fill="none" stroke="#6a4a2a" stroke-width="0.8" stroke-dasharray="3 1.2 6 0.8" opacity="0.6"/>`;
          if (top) { t += `<circle r="4.2" fill="#1a120a"/><circle r="5.2" fill="none" stroke="#3a2a18" stroke-width="1.4" opacity="0.6"/>` + rep(4, i => { const a = i * PI / 2 + 0.4, x = Math.cos(a) * 9, y = Math.sin(a) * 9; return `<path d="M${f1(x + 1.4)} ${f1(y)}l-0.7 1.2h-1.4l-0.7 -1.2l0.7 -1.2h1.4Z" fill="#7a5a3a" stroke="#4a3018" stroke-width="0.2"/><circle cx="${f1(x + 0.6)}" cy="${f1(y + 0.8)}" r="1.4" fill="#8a4a1a" opacity="0.35"/>`; }).join('');
            t += `<circle r="21" fill="none" stroke="#2a2a2a" stroke-width="1" opacity="0.35"/><circle r="17.6" fill="none" stroke="#2a2a2a" stroke-width="0.6" opacity="0.3"/><path d="M-6 -24l6 -4l6 4h-3v3h-6v-3Z" fill="#2a2a2a" opacity="0.35"/>`;
            t += `<circle cx="-14" cy="8" r="4.6" fill="none" stroke="#6a4a2a" stroke-width="0.7" opacity="0.4"/><circle cx="-12" cy="10" r="4.6" fill="none" stroke="#6a4a2a" stroke-width="0.5" opacity="0.3"/><circle cx="16" cy="-12" r="3.8" fill="none" stroke="#5a3a1a" stroke-width="0.6" opacity="0.35"/>`;
            t += `<g transform="rotate(-18 14 12)"><rect x="9" y="8" width="11" height="6" rx="1" fill="#ff4fb8" opacity="0.92"/><path d="M11 11h7" stroke="#ffffff" stroke-width="0.8"/></g><circle cx="-18" cy="-8" r="4" fill="#7dff6a" opacity="0.9"/><path d="M-19.6 -8l1.2 1.4l2.4 -2.8" stroke="#1a3a10" stroke-width="0.6" fill="none"/>`
              + `<path d="M4 18l1.4 3 3.2 0.3-2.4 2.1 0.8 3.1-3-1.7-2.8 1.7 0.7-3.1-2.4-2.1 3.2-0.3z" fill="#ffe14f" stroke="#a88a10" stroke-width="0.3"/>`;
            t += [[-4, 14, '#c8c8c0'], [20, 2, '#d84030']].map(([x, y, c]) => `<circle cx="${x}" cy="${y}" r="1.5" fill="${c}" stroke="#6a6a64" stroke-width="0.3"/>`).join('');
            t += rep(7, i => { const a = R() * 2 * PI; return `<path d="M${f1(Math.cos(a) * r)} ${f1(Math.sin(a) * r)}l${f1(-Math.cos(a) * 2.4)} ${f1(-Math.sin(a) * 2.4 + 0.6)}" stroke="#6a4a2a" stroke-width="0.4"/>`; }).join(''); }
          return t + `<circle r="${r}" fill="url(#${id}gl)"/>`; };
        s += cyl3(C, [0, 0, 0], [0, 3, 0], 31, PW, { mat: 'matte', olw: 0.35, cap: r => flangeCap(r, 0) });
        s += cyl3(C, [0, 3, 0], [0, TY - 3.2, 0], 17, '#9a7a52', { mat: 'matte', olw: 0.3 });
        rep(11, i => { const a = thV(C) - 1.4 + i * 2.8 / 10; s += line3(C, [[Math.cos(a) * 17.05, 3.4, Math.sin(a) * 17.05], [Math.cos(a) * 17.05, TY - 3.6, Math.sin(a) * 17.05]], 0.4, '#5a3e22', 'opacity="0.7"'); });
        s += cyl3(C, [0, TY - 3.2, 0], [0, TY, 0], 31, PW, { mat: 'matte', olw: 0.35, cap: r => flangeCap(r, 1) });
        rep(8, i => { const a = thV(C) - 1.3 + i * 2.6 / 7; s += line3(C, [[Math.cos(a) * 31.05, TY - 3, Math.sin(a) * 31.05], [Math.cos(a + 0.05) * 31.05, TY - 0.4, Math.sin(a + 0.05) * 31.05]], 0.25, '#6a4a2a', 'opacity="0.6"'); });
        // dented can + loose sticker corner
        s += cyl3(C, [-20, TY, -6], [-20, TY + 6.4, -6], 2.1, '#3a7ac8', { olw: 0.2, capCol: '#c8ccd2' }) + line3(C, [[-21.9, TY + 3, -5], [-21.2, TY + 3.6, -4.2]], 0.5, '#24508a');
        const sc = C.P([18.6, TY + 0.1, 15.4]); s += `<g transform="translate(${P2(sc)}) scale(${n4(k)})"><path d="M0 0l3 -1.2l0.6 2.2Z" fill="#ff8fd0">${an('d', 'M0 0l3 -1.2l0.6 2.2Z;M0 0l3.2 -2.6l0.8 1.8Z;M0 0l3 -1.2l0.6 2.2Z', 3.8)}</path></g>`;
        // upturned red crate with a candle in a bottle
        const holes = (w, h) => `<rect width="${w}" height="${h}" fill="#c8322a"/>` + rep(Math.floor(w / 4), i => rep(2, j => `<rect x="${f1(1.6 + i * 4)}" y="${f1(2 + j * 6)}" width="2.4" height="4.4" rx="0.8" fill="#6a1410"/>`).join('')).join('') + `<rect width="${w}" height="${h}" fill="none" stroke="#8a1a14" stroke-width="0.5"/>`;
        s += B10(C, { c: [44, 0, 4], w: 24, h: 14, d: 18, col: '#c8322a', r: 1, dec: { f: holes(24, 14), b: holes(24, 14), l: holes(18, 14), r: holes(18, 14), t: `<rect width="24" height="18" fill="#b82a22"/>${rep(5, i => `<rect x="2" y="${1.4 + i * 3.4}" width="20" height="1.4" rx="0.6" fill="#8a1a14"/>`).join('')}` } });
        s += cyl3(C, [44, 14, 4], [44, 22, 4], 2.4, '#2a6a3a', { mat: 'gloss', olw: 0.2, op: 0.85 }) + cyl3(C, [44, 22, 4], [44, 26, 4], 0.9, '#2a6a3a', { mat: 'gloss', olw: 0.15 }) + cyl3(C, [44, 26, 4], [44, 30, 4], 0.85, '#f2ead6', { olw: 0.15 })
          + line3(C, [[43.2, 26.4, 4.6], [43, 24, 4.8]], 0.5, '#f2ead6');
        const fl = C.P([44, 31.4, 4]); s += `<circle cx="${f1(fl[0])}" cy="${f1(fl[1])}" r="${f1(5 * k)}" fill="url(#${id}cg)">${an('opacity', '0.7;1;0.8;1;0.7', 1.3)}</circle><g transform="translate(${P2(fl)}) scale(${n4(k)})"><path d="M0 1.4C-1 0.4 -0.8 -1.2 0 -2.6C0.8 -1.2 1 0.4 0 1.4Z" fill="#ffc860">${an('d', 'M0 1.4C-1 0.4 -0.8 -1.2 0 -2.6C0.8 -1.2 1 0.4 0 1.4Z;M0 1.4C-1.1 0.4 -0.4 -1.4 0.4 -2.8C0.9 -1.2 1 0.4 0 1.4Z;M0 1.4C-1 0.4 -0.8 -1.2 0 -2.6C0.8 -1.2 1 0.4 0 1.4Z', 0.9)}</path><path d="M0 1.2C-0.4 0.6 -0.3 -0.2 0 -0.8C0.3 -0.2 0.4 0.6 0 1.2Z" fill="#fff6d8"/></g>`;
        C.p(-34, 0, -32); C.p(34, 0, 32); C.p(58, 0, 14); C.p(58, 0, -6); C.p(0, TY + 8, 0); C.p(44, 34, 4);
        const defs = DEFG + `<defs><radialGradient id="${id}gl" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.18"/></radialGradient>`
          + `<radialGradient id="${id}cg"><stop offset="0" stop-color="#ffd890" stop-opacity="0.7"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-023 ROUND CHROME COCKTAIL HIGH-TOP TABLE (T2): a standard bar high-top: a round white laminate top with a chrome edge band (a chip
    // in the laminate, drink rings), a chrome column with a chrome foot ring halfway up, and a heavy round chrome base plate scuffed at the rim
    // with a folded beer mat wedged under one edge to stop the wobble. A tea-light glows in a frosted glass holder and a folded paper napkin sits
    // beside it. Live: the tea-light flickers.
    N.hitop31 = S => { const D = { w: 50, d: 50, round: 1, topH: 86, topW: 30, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('h23'), R = rng('hitop31'), CHR = '#c8ccd2', TY = 86, th = thV(C);
        let s = shadow(C, 0, 0, 22, 22, 0.4);
        s += PLN(C, 0.4, `<g transform="rotate(20)"><rect x="17" y="-3.4" width="6" height="6" fill="#e8dcc0" stroke="#a89878" stroke-width="0.2"/><circle cx="20" cy="-0.4" r="1.8" fill="#c8402e" opacity="0.8"/></g>`);
        const baseCap = r => `<circle r="${r}" fill="#b8bcc4"/><circle r="${n4(r * 0.7)}" fill="none" stroke="#ffffff" stroke-width="0.6" opacity="0.4"/>` + rep(10, () => { const a = R() * 2 * PI, rr = r * (0.5 + R() * 0.45); return `<path d="M${f1(Math.cos(a) * rr)} ${f1(Math.sin(a) * rr)}l${f1((R() - 0.5) * 6)} ${f1((R() - 0.5) * 3)}" stroke="#7a7e86" stroke-width="0.2" opacity="0.6"/>`; }).join('') + `<circle r="${r}" fill="url(#${id}gl)"/>`;
        s += `<g transform="rotate(0)">` + cyl3(C, [0, 0.6, 0], [0, 2.4, 0], 19, CHR, { mat: 'chrome', olw: 0.3, cap: baseCap, r2: 17 }) + `</g>`;
        s += cyl3(C, [0, 2.4, 0], [0, 5, 0], 4.2, CHR, { mat: 'chrome', olw: 0.25, r2: 3 });
        const ringY = 36, ring = rep(29, i => { const a = i / 28 * 2 * PI; return [Math.cos(a) * 13, ringY, Math.sin(a) * 13]; });
        const ringB = ring.filter((q, i) => Math.cos(i / 28 * 2 * PI - th) < 0.02), ringF = ring.filter((q, i) => Math.cos(i / 28 * 2 * PI - th) >= -0.02);
        const arc = (a0, a1) => rep(15, i => { const a = a0 + (a1 - a0) * i / 14; return [Math.cos(a) * 13, ringY, Math.sin(a) * 13]; });
        s += line3(C, arc(th + PI / 2, th + 3 * PI / 2), 1.3, '#8a8e96');
        rep(3, i => { const a = i * 2 * PI / 3 + 0.3; s += line3(C, [[Math.cos(a) * 2.2, ringY, Math.sin(a) * 2.2], [Math.cos(a) * 13, ringY, Math.sin(a) * 13]], 0.7, '#a8acb4'); });
        s += cyl3(C, [0, 5, 0], [0, TY - 2, 0], 2.2, CHR, { mat: 'chrome', olw: 0.25 });
        s += line3(C, arc(th - PI / 2, th + PI / 2), 1.3, CHR) + line3(C, arc(th - 0.9, th + 0.2), 0.4, '#ffffff', 'opacity="0.7"');
        s += cyl3(C, [0, TY - 3, 0], [0, TY - 2, 0], 6, '#8a8e96', { mat: 'metal', olw: 0.2 });
        const topCap = r => `<circle r="${r}" fill="#f2f0ea"/><circle r="${n4(r - 0.6)}" fill="none" stroke="${CHR}" stroke-width="1.2"/>`
          + `<circle cx="-8" cy="6" r="3.4" fill="none" stroke="#c8b898" stroke-width="0.5" opacity="0.5"/><circle cx="7" cy="-9" r="3" fill="none" stroke="#c8b898" stroke-width="0.4" opacity="0.4"/><path d="M${f1(r - 1.4)} 3l-2 1.2l-0.4 2.2l2.6 -0.6Z" fill="#c8a878"/>` + `<circle r="${r}" fill="url(#${id}gl)"/>`;
        s += cyl3(C, [0, TY - 2, 0], [0, TY, 0], 24, '#e8e6e0', { mat: 'plastic', olw: 0.3, cap: topCap });
        s += line3(C, frontArc(C, 24.05, TY - 1, 30), 2.1, CHR) + line3(C, frontArc(C, 24.1, TY - 0.6, 30, 1), 0.4, '#ffffff', 'opacity="0.8"');
        // napkin + tea-light in frosted glass
        s += PLN(C, TY + 0.05, `<g transform="rotate(14)"><rect x="-14" y="2" width="8" height="8" fill="#ffffff" stroke="#d8d8d0" stroke-width="0.2"/><path d="M-14 2l8 8" stroke="#e0e0d8" stroke-width="0.3"/></g>`);
        s += cyl3(C, [4, TY, 3], [4, TY + 4.6, 3], 2.6, '#f4efe4', { mat: 'gloss', op: 0.8, olw: 0.2, capCol: '#ffe8b0' });
        const fl = C.P([4, TY + 5.4, 3]); s += `<circle cx="${f1(fl[0])}" cy="${f1(fl[1])}" r="${f1(6 * k)}" fill="url(#${id}cg)">${an('opacity', '0.7;1;0.8;1;0.7', 1.4)}</circle><g transform="translate(${P2(fl)}) scale(${n4(k)})"><path d="M0 0.8C-0.7 0.2 -0.5 -0.8 0 -1.8C0.5 -0.8 0.7 0.2 0 0.8Z" fill="#ffc860">${an('d', 'M0 0.8C-0.7 0.2 -0.5 -0.8 0 -1.8C0.5 -0.8 0.7 0.2 0 0.8Z;M0 0.8C-0.8 0.2 -0.2 -1 0.3 -2C0.6 -0.8 0.7 0.2 0 0.8Z;M0 0.8C-0.7 0.2 -0.5 -0.8 0 -1.8C0.5 -0.8 0.7 0.2 0 0.8Z', 0.8)}</path></g>`;
        C.p(-25, 0, -25); C.p(25, 0, 25); C.p(25, 0, -25); C.p(-25, 0, 25); C.p(0, TY + 8, 0); C.p(-25, TY, 0); C.p(25, TY, 0);
        const defs = DEFG + `<defs><radialGradient id="${id}gl" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.15"/></radialGradient>`
          + `<radialGradient id="${id}cg"><stop offset="0" stop-color="#ffd890" stop-opacity="0.7"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // martini / coupe glass at (x, y, z): foot, stem, open bowl with a drink
    const coupe = (C, x, y, z, drink) => cyl3(C, [x, y, z], [x, y + 0.3, z], 2, '#e8eef2', { mat: 'gloss', op: 0.7, olw: 0.12 }) + line3(C, [[x, y + 0.3, z], [x, y + 4.6, z]], 0.45, '#e8eef2', 'opacity="0.85"')
      + cyl3(C, [x, y + 4.4, z], [x, y + 6.8, z], 0.8, '#eef4f6', { mat: 'gloss', op: 0.45, olw: 0.15, r2: 3.4, capCol: drink }) ;

    // CLB-043 INFINITY-MIRROR LED COFFEE TABLE (T3): a matte black box table on a recessed plinth with a glass top over an infinity mirror: a
    // ring of warm-white LEDs reflected again and again into a tunnel that seems to drop through the floor, a thin LED line along the edge of the
    // glass, two cocktails in coupe glasses on black coasters. Live: light runs around the LED rings and the colour drifts slowly warm white to
    // soft rose and back.
    N.inf31 = S => { const D = { w: 122, d: 66, topH: 34, topW: 70, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('i43'), TW = 114, TD = 56, TY = 34;
        let s = shadow(C, 0, 0, 60, 32, 0.4);
        s += B10(C, { c: [0, 0, 0], w: 104, h: 3, d: 46, col: '#0c0c0e', r: 1 });
        const side = (w) => `<rect width="${w}" height="27" fill="#18181c"/><rect y="25.6" width="${w}" height="0.6" fill="#ffd9a0" opacity="0.8"/><rect width="${w}" height="27" fill="url(#${id}sd)"/>`;
        s += B10(C, { c: [0, 3, 0], w: TW, h: 27, d: TD, col: '#18181c', r: 1, mat: 'noise', dec: { f: side(TW), b: side(TW), l: side(TD), r: side(TD) } });
        let t = `<rect width="${TW}" height="${TD}" fill="#050507"/>`;
        rep(9, i => { const ins = 3 + i * 2.9, op = n4(Math.max(0.06, 1 - i * 0.12)), rw = TW - 2 * ins, rh = TD - 2 * ins;
          t += `<rect x="${f1(ins)}" y="${f1(ins)}" width="${f1(rw)}" height="${f1(rh)}" rx="${f1(Math.max(0.5, 3 - i * 0.3))}" fill="none" stroke="#2a2a30" stroke-width="0.4" opacity="${op}"/>`
            + `<rect x="${f1(ins)}" y="${f1(ins)}" width="${f1(rw)}" height="${f1(rh)}" rx="${f1(Math.max(0.5, 3 - i * 0.3))}" fill="none" stroke="#ffd9a0" stroke-width="${n4(1 - i * 0.08)}" stroke-dasharray="0.1 ${n4(2.2 - i * 0.18)}" stroke-linecap="round" opacity="${op}">${an('stroke-dashoffset', `0;${n4(-(2.3 - i * 0.18) * 4)}`, 2.4)}${an('stroke', '#ffd9a0;#ffb8c8;#ffe8c8;#ffd9a0', 12, -i * 0.4)}</rect>`; });
        t += `<rect width="${TW}" height="${TD}" fill="url(#${id}tn)"/><rect x="1" y="1" width="${TW - 2}" height="${TD - 2}" fill="none" stroke="#ffe8c8" stroke-width="0.5" opacity="0.7"/><path d="M8 ${TD - 4}L${TW * 0.4} 4" stroke="#ffffff" stroke-width="3" opacity="0.06"/><path d="M16 ${TD - 4}L${TW * 0.45} 4" stroke="#ffffff" stroke-width="1" opacity="0.08"/>`;
        s += B10(C, { c: [0, 30, 0], w: TW, h: 4, d: TD, col: '#1c1c22', r: 0.8, dec: { t, f: `<rect width="${TW}" height="4" fill="#20242a"/><rect y="1.6" width="${TW}" height="0.8" fill="#ffd9a0" opacity="0.6"/>`, b: `<rect width="${TW}" height="4" fill="#20242a"/>`, l: `<rect width="${TD}" height="4" fill="#20242a"/><rect y="1.6" width="${TD}" height="0.8" fill="#ffd9a0" opacity="0.6"/>`, r: `<rect width="${TD}" height="4" fill="#20242a"/><rect y="1.6" width="${TD}" height="0.8" fill="#ffd9a0" opacity="0.6"/>` } });
        s += PLN(C, TY + 0.05, `<circle cx="-34" cy="12" r="3.6" fill="#0a0a0c"/><circle cx="36" cy="-10" r="3.6" fill="#0a0a0c"/>`);
        s += coupe(C, -34, TY + 0.2, 12, '#e8a84a') + coupe(C, 36, TY + 0.2, -10, '#d8507a');
        C.p(-60, 0, -32); C.p(60, 0, 32); C.p(60, 0, -32); C.p(-60, 0, 32); C.p(0, TY + 8, 0);
        const defs = `<defs><radialGradient id="${id}tn" cx="50%" cy="50%" r="60%"><stop offset="0" stop-color="#000000" stop-opacity="0.9"/><stop offset="0.5" stop-color="#000000" stop-opacity="0.3"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></radialGradient>`
          + `<linearGradient id="${id}sd" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-063 BLACK MARBLE & GOLD CHAMPAGNE-TROUGH VIP TABLE (T4): a slab of black Nero Marquina marble with white and gold veining, a sunken
    // brass-lined trough down the middle packed with crushed ice holding three champagne bottles with gold foil necks, two crystal coupes of
    // champagne, all on a black lacquer cabinet base banded top and bottom in brushed brass. Live: the ice glints, bubbles rise in the coupes and
    // a slow warm sheen slides across the marble.
    N.trough31 = S => { const D = { w: 122, d: 66, topH: 34, topW: 70, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('t63'), R = rng('trough31'), BR = '#c8a050', TW = 116, TD = 58, TY = 34;
        let s = shadow(C, 0, 0, 60, 32, 0.45);
        const lac = w => `<rect width="${w}" height="24" fill="#141216"/><rect width="${w}" height="24" fill="url(#${id}lq)"/>`;
        s += B10(C, { c: [0, 0, 0], w: 100, h: 2.4, d: 44, col: BR, r: 0.6, mat: 'brush' });
        s += B10(C, { c: [0, 2.4, 0], w: 100, h: 24, d: 44, col: '#141216', r: 0.6, dec: { f: lac(100), b: lac(100), l: lac(44), r: lac(44) } });
        s += B10(C, { c: [0, 26.4, 0], w: 102, h: 3.6, d: 46, col: BR, r: 0.6, mat: 'brush' });
        const TRX = 36, TRZ = 7;
        let t = `<clipPath id="${id}mc"><rect width="${TW}" height="${TD}"/></clipPath><rect width="${TW}" height="${TD}" fill="#141418"/><g clip-path="url(#${id}mc)">`;
        rep(9, () => { let x = R() * TW, y = 0, d = `M${f1(x)} 0`; rep(6, () => { x += (R() - 0.45) * 22; y += TD / 5; d += `Q${f1(x + (R() - 0.5) * 12)} ${f1(y - TD / 10)} ${f1(x)} ${f1(y)}`; }); t += `<path d="${d}" stroke="#ece8e0" stroke-width="${n4(0.2 + R() * 0.5)}" fill="none" opacity="${n4(0.3 + R() * 0.45)}"/>`; });
        rep(4, () => { const x = R() * TW; t += `<path d="M${f1(x)} 0q${f1((R() - 0.5) * 30)} ${f1(TD / 2)} ${f1((R() - 0.5) * 20)} ${TD}" stroke="#d8b060" stroke-width="0.3" fill="none" opacity="0.5"/>`; });
        t += `<rect x="-40" width="30" height="${TD}" fill="url(#${id}sh)" transform="skewX(-20)">${an('x', `-40;${TW + 30}`, 9)}</rect></g>`;
        t += `<rect x="${TW / 2 - TRX}" y="${TD / 2 - TRZ}" width="${2 * TRX}" height="${2 * TRZ}" rx="2" fill="#2a2418" stroke="${BR}" stroke-width="1.4"/>`;
        t += rep(70, () => { const x = TW / 2 - TRX + 1.4 + R() * (2 * TRX - 2.8), y = TD / 2 - TRZ + 1.4 + R() * (2 * TRZ - 2.8), w = 1.2 + R() * 1.8; return `<rect x="${f1(x - w / 2)}" y="${f1(y - w / 2)}" width="${f1(w)}" height="${f1(w)}" rx="0.4" fill="#eef4f8" opacity="${n4(0.45 + R() * 0.4)}" transform="rotate(${Math.round(R() * 90)} ${f1(x)} ${f1(y)})"/>`; }).join('');
        t += rep(8, i => { const x = TW / 2 - TRX + 3 + R() * (2 * TRX - 6), y = TD / 2 - TRZ + 2 + R() * (2 * TRZ - 4); return `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.5" fill="#ffffff" opacity="0">${an('opacity', '0;1;0', n4(1.6 + R() * 2), -R() * 3)}</circle>`; }).join('');
        const edgeB = w => `<rect width="${w}" height="4" fill="#18181c"/><path d="M0 0.4H${w}" stroke="#ffffff" stroke-width="0.4" opacity="0.25"/>`;
        s += B10(C, { c: [0, 30, 0], w: TW, h: 4, d: TD, col: '#18181c', r: 0.8, dec: { t, f: edgeB(TW), b: edgeB(TW), l: edgeB(TD), r: edgeB(TD) } });
        // bottles in the ice (back to front)
        const bottles = [[-22, -2], [2, 2.4], [24, -1.6]].map(([x, z]) => ({ d: x * C.v[0] + z * C.v[2], s: cyl3(C, [x, TY, z], [x, TY + 8, z], 2.7, '#1e3a24', { mat: 'gloss', olw: 0.2 }) + cyl3(C, [x, TY + 8, z], [x, TY + 11, z], 2.7, '#1e3a24', { mat: 'gloss', olw: 0.2, r2: 1.1 })
          + cyl3(C, [x, TY + 9.4, z], [x, TY + 15, z], 1.15, '#d8b060', { mat: 'metal', olw: 0.15 }) + cyl3(C, [x, TY + 15, z], [x, TY + 15.8, z], 1.2, '#e8c878', { mat: 'metal', olw: 0.12 }) + line3(C, [[x - 1.6, TY + 1, z + 2], [x - 1.4, TY + 7, z + 2.2]], 0.4, '#ffffff', 'opacity="0.35"') })).sort((a, b) => a.d - b.d);
        s += bottles.map(b => b.s).join('');
        const glass = (x, z, b0) => { const g = coupe(C, x, TY, z, '#f2d890'), q = C.P([x, TY + 6.2, z]); return g + rep(3, i => `<circle cx="${f1(q[0] + (i - 1) * 0.8 * k)}" cy="${f1(q[1])}" r="${f1(0.25 * k)}" fill="#ffffff" opacity="0">${at('translate', `0 0;0 ${f1(-2.4 * k)}`, 1.2, -(b0 + i * 0.4))}${an('opacity', '0;0.9;0', 1.2, -(b0 + i * 0.4))}</circle>`).join(''); };
        s += glass(-40, 18, 0) + glass(42, 17, 0.6);
        C.p(-60, 0, -32); C.p(60, 0, 32); C.p(60, 0, -32); C.p(-60, 0, 32); C.p(0, TY + 17, 0);
        const defs = `<defs><linearGradient id="${id}lq" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="0.4" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.2"/></linearGradient>`
          + `<linearGradient id="${id}sh" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffe8c0" stop-opacity="0"/><stop offset="0.5" stop-color="#ffe8c0" stop-opacity="0.14"/><stop offset="1" stop-color="#ffe8c0" stop-opacity="0"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-083 INTERACTIVE TOUCH-SYNTH & HOLOGRAM-VISUALIZER VIP TABLE (T5): a racetrack-oval walnut table with a polished brass rim on an oval walnut
    // column and brass foot. Set into the top is a black glass touch panel with twelve gold-ringed pads; above its centre a warm gold visualiser
    // floats: a circle of light bars dancing like an equaliser with rings of light rising off it. Live: the pads light up in a pattern with
    // ripples, the bars pump, rings rise and fade.
    N.touch31 = S => { const D = { w: 122, d: 66, round: 1, topH: 34, topW: 70, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('t83'), R = rng('touch31'), BR = '#c8a050', WAL = '#5a3420', TW = 112, TD = 58, TY = 34;
        let s = shadow(C, 0, 0, 58, 30, 0.45) + PLN(C, 0.1, `<ellipse rx="64" ry="36" fill="url(#${id}fl)"/>`);
        const grainW = (w, h) => `<rect width="${w}" height="${h}" fill="${WAL}"/>${rep(Math.ceil(h / 2.4), i => `<path d="M0 ${f1(1 + i * 2.4)}q${w / 2} ${f1((R() - 0.5) * 1.4)} ${w} 0" stroke="#3e2210" stroke-width="0.3" fill="none" opacity="0.6"/>`).join('')}`;
        s += B10(C, { c: [0, 0, 0], w: 64, h: 3, d: 30, col: BR, r: 15, mat: 'brush' });
        s += B10(C, { c: [0, 3, 0], w: 44, h: 26, d: 16, col: WAL, r: 8, dec: { f: grainW(44, 26), b: grainW(44, 26), l: grainW(16, 26), r: grainW(16, 26) } });
        s += B10(C, { c: [0, 29, 0], w: TW + 1.6, h: 1.6, d: TD + 1.6, col: BR, r: 29.8, mat: 'brush' });
        let t = `<clipPath id="${id}tc"><rect width="${TW}" height="${TD}" rx="${TD / 2}"/></clipPath><g clip-path="url(#${id}tc)">${grainW(TW, TD)}</g>`;
        t += `<rect x="${TW / 2 - 34}" y="${TD / 2 - 15}" width="68" height="30" rx="15" fill="#0a0806" stroke="${BR}" stroke-width="0.9"/><rect x="${TW / 2 - 34}" y="${TD / 2 - 15}" width="68" height="30" rx="15" fill="url(#${id}gp)"/>`;
        const PADS = []; rep(2, j => rep(6, i => PADS.push([TW / 2 - 25 + i * 10, TD / 2 - 6 + j * 12])));
        const ORD = [0, 7, 2, 9, 4, 11, 6, 1, 8, 3, 10, 5], T = 4.8;
        PADS.forEach(([x, y], i) => { const b = -ORD.indexOf(i) * T / 12;
          t += `<circle cx="${x}" cy="${y}" r="3.2" fill="#140e08" stroke="${BR}" stroke-width="0.45"/><circle cx="${x}" cy="${y}" r="2.6" fill="#ffcf8a" opacity="0">${an('opacity', '0;0.9;0.15;0;0', T, b, KT('0;0.03;0.2;0.4;1'))}</circle>`
            + `<circle cx="${x}" cy="${y}" r="3" fill="none" stroke="#ffe2a8" stroke-width="0.4" opacity="0">${an('r', '3;9', T / 6, b)}${an('opacity', '0.8;0', T / 6, b)}</circle>`; });
        s += B10(C, { c: [0, 30.6, 0], w: TW, h: 3.4, d: TD, col: WAL, r: TD / 2, dec: { t } });
        // visualiser
        const VY = TY + 4, NB = 18, vc = C.P([0, VY, 0]); let viz = `<circle cx="${f1(vc[0])}" cy="${f1(vc[1] - 6 * k)}" r="${f1(20 * k)}" fill="url(#${id}ha)">${an('opacity', '0.5;0.85;0.5', 2.4)}</circle>`;
        viz += rep(3, i => `<g opacity="0">${at('translate', `0 0;0 ${f1(-26 * k)}`, 3, -i)}${an('opacity', '0;0.8;0', 3, -i)}${PLN(C, VY, `<ellipse rx="13" ry="13" fill="none" stroke="#ffd28a" stroke-width="0.7"/>`)}</g>`).join('');
        const bars = rep(NB, i => { const a = i / NB * 2 * PI, x = Math.cos(a) * 11, z = Math.sin(a) * 11, Q = rng('t83b' + i), hs = rep(6, () => 2 + Q() * 12), b0 = C.P([x, VY, z]);
          const ds = hs.concat(hs[0]).map(h => { const q = C.P([x, VY + h, z]); return `M${P2(b0)}L${P2(q)}`; }).join(';');
          return { d: x * C.v[0] + z * C.v[2], s: `<path d="M${P2(b0)}L${P2(C.P([x, VY + hs[0], z]))}" stroke="#ffd28a" stroke-width="${f1(1.6 * k)}" stroke-linecap="round" opacity="0.85">${an('d', ds, n4(1.4 + Q() * 0.6))}</path>` }; }).sort((a, b) => a.d - b.d);
        viz += PLN(C, VY, `<circle r="11.4" fill="none" stroke="#ffd28a" stroke-width="0.5" opacity="0.6"/><circle r="2" fill="#fff0c8" opacity="0.8"/>`) + bars.map(b => b.s).join('');
        s += viz;
        C.p(-60, 0, -32); C.p(60, 0, 32); C.p(60, 0, -32); C.p(-60, 0, 32); C.p(0, VY + 30, 0);
        const defs = DEFG + `<defs><radialGradient id="${id}fl"><stop offset="0" stop-color="#ffcf8a" stop-opacity="0.3"/><stop offset="1" stop-color="#e8a858" stop-opacity="0"/></radialGradient>`
          + `<linearGradient id="${id}gp" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.4" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.05"/></linearGradient>`
          + `<radialGradient id="${id}ha"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.45"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient>`
          + `<linearGradient id="${id}br" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffb060"/><stop offset="1" stop-color="#fff0c8"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-007 PLASTIC STACKABLE STOOL USED AS DRINK REST (T1): a faded red moulded-plastic stacking stool (round seat with a finger hole and ribbed
    // rim, four splayed ribbed legs, a square brace ring), chalky and scuffed, with a stack mark worn into the seat, a sticky drink ring and a
    // sweating beer can standing on the edge. Still a seat. Live: a drop of condensation runs down the can.
    N.pstool31 = S => { const D = { w: 40, d: 40, round: 1, act: 'sit', seats: [{ x: 0, z: 0, h: 38 }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('p07'), R = rng('pstool31'), RED = '#c24a3c', SY = 36;
        let s = shadow(C, 0, 0, 20, 20, 0.4);
        const legAx = (a, b) => { const sp = 0.13, u = nrm([a, 0, -b]), up = nrm([-a * sp, 1, -b * sp]); return [u, up, nrm(cross(u, up))]; };
        const legs = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([a, b]) => ({ d: a * C.v[0] + b * C.v[2], s: B10(C, { c: [a * 13.2, 0, b * 13.2], ax: legAx(a, b), w: 4.2, h: SY - 3, d: 3, col: RED, r: 1, mat: 'noise' }) }));
        const ring = [[-1, -1], [1, -1], [1, 1], [-1, 1], [-1, -1]].map(([a, b]) => [a * 13.9, 14, b * 13.9]);
        s += legs.filter(l => l.d < 0).map(l => l.s).join('') + line3(C, ring, 1.3, '#a83a2e') + line3(C, ring, 0.4, '#e07060', 'opacity="0.6"') + legs.filter(l => l.d >= 0).map(l => l.s).join('');
        const seat = r => `<circle r="${r}" fill="${RED}"/><circle r="${n4(r - 1.4)}" fill="none" stroke="#a83a2e" stroke-width="0.6"/><circle r="${n4(r - 4)}" fill="none" stroke="#d86a5c" stroke-width="0.5" opacity="0.6"/>`
          + `<circle cx="0" cy="-1" r="2.6" fill="#1a1414"/><circle r="${n4(r - 4.6)}" fill="none" stroke="#8a2a20" stroke-width="2" opacity="0.18"/>`
          + rep(14, () => { const a = R() * 2 * PI, rr = R() * (r - 2); return `<path d="M${f1(Math.cos(a) * rr)} ${f1(Math.sin(a) * rr)}l${f1((R() - 0.5) * 5)} ${f1((R() - 0.5) * 2)}" stroke="#f0c8c0" stroke-width="0.2" opacity="0.6"/>`; }).join('')
          + `<circle cx="6" cy="4" r="3.2" fill="none" stroke="#7a2a20" stroke-width="0.5" opacity="0.4"/><circle r="${r}" fill="url(#${id}ch)"/>`;
        s += cyl3(C, [0, SY - 5, 0], [0, SY, 0], 14.2, RED, { olw: 0.3, mat: 'matte', r2: 16 });
        s += cyl3(C, [0, SY, 0], [0, SY + 0.6, 0], 16, RED, { olw: 0.3, mat: 'matte', cap: seat });
        s += rep(10, i => { const a = thV(C) - 1.3 + i * 2.6 / 9; return line3(C, [[Math.cos(a) * 15.6, SY - 1.8, Math.sin(a) * 15.6], [Math.cos(a) * 16, SY + 0.4, Math.sin(a) * 16]], 0.3, '#a83a2e', 'opacity="0.6"'); }).join('');
        s += cyl3(C, [8, SY + 0.6, 6], [8, SY + 8, 6], 2.1, '#d8b040', { olw: 0.2, capCol: '#c8ccd2', mat: 'gloss' }) + cyl3(C, [8, SY + 7.4, 6], [8, SY + 8, 6], 2.1, '#c8ccd2', { mat: 'metal', olw: 0.12 }) + line3(C, [[6.2, SY + 3, 6.8], [9.6, SY + 3, 7.2]], 0.7, '#2a3a8a');
        const dp = C.P([7, SY + 6.6, 8]); s += `<circle cx="${f1(dp[0])}" cy="${f1(dp[1])}" r="${f1(0.45 * k)}" fill="#ffffff" opacity="0.8">${at('translate', `0 0;0 ${f1(5 * k)}`, 3.6, 0, ' keyTimes="0;1" calcMode="spline" keySplines="0.6 0 1 1"')}${an('opacity', '0.8;0.8;0', 3.6)}</circle>`;
        C.p(-17, 0, -17); C.p(17, 0, 17); C.p(17, 0, -17); C.p(-17, 0, 17); C.p(0, SY + 9, 0);
        const defs = `<defs><radialGradient id="${id}ch" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.18"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0.04"/><stop offset="1" stop-color="#000000" stop-opacity="0.15"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-027 GLOWING ACRYLIC PEDESTAL BISTRO STAND (T2): a rented party LED pedestal: a tapered frosted-plastic column with a mould seam and a
    // round frosted top, lit from inside by a cheap colour-changing LED, with a small remote and a barcode rental sticker on the base and a charge
    // cable trailing off. A drink with a straw stands on top. Live: the light fades slowly through magenta, amber, violet and pink.
    N.ledped31 = S => { const D = { w: 50, d: 50, round: 1, topH: 58, topW: 30, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('l27'), TY = 58, COLS = ['#ff6ab8', '#ffb050', '#a070ff', '#ff8fa8'], T = 12;
        let s = shadow(C, 0, 0, 20, 20, 0.35);
        const fl = C.P([0, 0, 0]); s += `<ellipse cx="${f1(fl[0])}" cy="${f1(fl[1])}" rx="${f1(30 * k)}" ry="${f1(14 * k)}" fill="${COLS[0]}" opacity="0.3" filter="url(#g31b3)">${an('fill', COLS.concat(COLS[0]).join(';'), T)}</ellipse>`;
        const col = c => cyl3(C, [0, 0, 0], [0, TY - 2.4, 0], 13, c, { mat: 'gloss', olw: 0.3, r2: 9.6, noCap: 1 });
        s += col('#f6f2f6') + COLS.map((c, i) => `<g opacity="0">${an('opacity', rep(COLS.length + 1, j => (j % COLS.length) === i ? 0.75 : 0).join(';'), T)}${col(c)}</g>`).join('');
        s += line3(C, [[Math.cos(thV(C) + 0.9) * 12.4, 0.5, Math.sin(thV(C) + 0.9) * 12.4], [Math.cos(thV(C) + 0.9) * 9.2, TY - 2.8, Math.sin(thV(C) + 0.9) * 9.2]], 0.3, '#ffffff', 'opacity="0.5"');
        const core = C.P([0, TY * 0.45, 0]); s += `<ellipse cx="${f1(core[0])}" cy="${f1(core[1])}" rx="${f1(6 * k)}" ry="${f1(20 * k)}" fill="#ffffff" opacity="0.35" filter="url(#g31b3)"/>`;
        const top = r => `<circle r="${r}" fill="#ffffff" opacity="0.5"/><circle r="${n4(r - 1)}" fill="none" stroke="#ffffff" stroke-width="0.6" opacity="0.8"/>`;
        s += cyl3(C, [0, TY - 2.4, 0], [0, TY, 0], 17, '#f6f2f6', { mat: 'gloss', olw: 0.3, cap: top }) + COLS.map((c, i) => `<g opacity="0">${an('opacity', rep(COLS.length + 1, j => (j % COLS.length) === i ? 0.6 : 0).join(';'), T)}${cyl3(C, [0, TY - 2.4, 0], [0, TY, 0], 17, c, { mat: 'gloss', olw: 0, noCap: 1 })}</g>`).join('');
        const st = thV(C); s += `<g transform="${FR(C, [Math.cos(st) * 12.9, 4, Math.sin(st) * 12.9], [-Math.sin(st), 0, Math.cos(st)], [0, -1, 0])}"><rect x="-3" y="0" width="6" height="3.6" fill="#ffffff"/>${rep(9, i => `<rect x="${f1(-2.4 + i * 0.55)}" y="0.6" width="${i % 3 ? 0.25 : 0.4}" height="2" fill="#1a1a1a"/>`).join('')}</g>`;
        s += line3(C, [[Math.cos(st - 1.2) * 12.6, 2, Math.sin(st - 1.2) * 12.6], [Math.cos(st - 1.2) * 18, 0.3, Math.sin(st - 1.2) * 18], [Math.cos(st - 1.5) * 24, 0.3, Math.sin(st - 1.5) * 24]], 0.5, '#1a1a1e');
        s += B10(C, { c: [-8, TY, 6], w: 4, h: 0.9, d: 8, col: '#f4f4f4', r: 0.8, dec: { t: `<rect width="4" height="8" fill="#f4f4f4"/>${rep(6, i => `<circle cx="${1 + (i % 2) * 2}" cy="${1.4 + Math.floor(i / 2) * 2.2}" r="0.6" fill="${COLS[i % 4]}"/>`).join('')}` } });
        s += cyl3(C, [4, TY, -2], [4, TY + 9, -2], 2.6, '#f4f0ec', { mat: 'gloss', op: 0.5, olw: 0.2, capCol: '#e86a8a', r2: 2.9 }) + cyl3(C, [4, TY, -2], [4, TY + 6.6, -2], 2.5, '#e86a8a', { op: 0.6, olw: 0, noCap: 1 }) + line3(C, [[4.6, TY + 3, -1.6], [5.6, TY + 13, -2.6]], 0.5, '#ffffff');
        C.p(-20, 0, -20); C.p(20, 0, 20); C.p(20, 0, -20); C.p(-20, 0, 20); C.p(0, TY + 14, 0); C.p(-26, 0, 6);
        return { defs: DEFG, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-047 BRUSHED BRASS HOURGLASS COCKTAIL SIDE TABLE (T3): a tall cocktail side table on an hourglass base of two brushed-brass cones meeting
    // at a slim waist ring, with a round white Carrara marble top edged in brass. A coupe cocktail with an orange twist sits on a linen napkin.
    // Live: a soft highlight slides up and down the brushed brass.
    N.hglass31 = S => { const D = { w: 50, d: 50, round: 1, topH: 87, topW: 30, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('h47'), R = rng('hglass31'), BR = '#c8a050', TY = 87, WY = 44, th = thV(C);
        let s = shadow(C, 0, 0, 18, 18, 0.4);
        s += cyl3(C, [0, 0, 0], [0, WY - 1, 0], 16, BR, { mat: 'metal', olw: 0.3, r2: 2.6, noCap: 1 }) + cyl3(C, [0, WY - 1, 0], [0, WY + 1, 0], 3.6, '#a88438', { mat: 'metal', olw: 0.2 }) + cyl3(C, [0, WY + 1, 0], [0, TY - 3, 0], 2.6, BR, { mat: 'metal', olw: 0.3, r2: 13 });
        s += rep(14, i => { const a = th - 1.35 + i * 2.7 / 13; return line3(C, [[Math.cos(a) * 15.8, 0.4, Math.sin(a) * 15.8], [Math.cos(a) * 2.7, WY - 1.2, Math.sin(a) * 2.7]], 0.15, '#7a5a20', 'opacity="0.5"') + line3(C, [[Math.cos(a) * 2.7, WY + 1.2, Math.sin(a) * 2.7], [Math.cos(a) * 12.8, TY - 3.2, Math.sin(a) * 12.8]], 0.15, '#7a5a20', 'opacity="0.5"'); }).join('');
        const hp = (y0, y1) => { const a = th - 0.55, b0 = C.P([Math.cos(a) * 15.4, y0, Math.sin(a) * 15.4]), b1 = C.P([Math.cos(a) * 3, y1, Math.sin(a) * 3]); return `M${P2(b0)}L${P2(b1)}`; };
        s += `<path d="${hp(0.5, WY - 1)}" stroke="#fff4d0" stroke-width="${f1(1.2 * k)}" opacity="0.35" stroke-linecap="round"/><path d="M${P2(C.P([Math.cos(th - 0.55) * 3, WY + 1, Math.sin(th - 0.55) * 3]))}L${P2(C.P([Math.cos(th - 0.55) * 12.6, TY - 3, Math.sin(th - 0.55) * 12.6]))}" stroke="#fff4d0" stroke-width="${f1(1.2 * k)}" opacity="0.35" stroke-linecap="round"/>`;
        const sw = C.P([0, WY, 0]); s += `<ellipse cx="${f1(sw[0])}" cy="${f1(sw[1])}" rx="${f1(7 * k)}" ry="${f1(3 * k)}" fill="#fff4d0" opacity="0">${at('translate', `0 ${f1(30 * k)};0 ${f1(-30 * k)};0 ${f1(30 * k)}`, 7, 0, SPL(2))}${an('opacity', '0;0.25;0;0.25;0', 7)}</ellipse>`;
        const top = r => { let t = `<clipPath id="${id}mc"><circle r="${r}"/></clipPath><circle r="${r}" fill="#f2f0ec"/><g clip-path="url(#${id}mc)">`;
          rep(6, () => { let x = -r + R() * 2 * r, y = -r, d = `M${f1(x)} ${f1(y)}`; rep(5, () => { x += (R() - 0.45) * 10; y += r * 2 / 5; d += `Q${f1(x + (R() - 0.5) * 6)} ${f1(y - r / 5)} ${f1(x)} ${f1(y)}`; }); t += `<path d="${d}" stroke="#9a9ea6" stroke-width="${n4(0.2 + R() * 0.4)}" fill="none" opacity="${n4(0.3 + R() * 0.35)}"/>`; });
          return t + `</g><circle r="${n4(r - 0.5)}" fill="none" stroke="${BR}" stroke-width="1"/><circle r="${r}" fill="url(#${id}gl)"/>`; };
        s += cyl3(C, [0, TY - 3, 0], [0, TY - 2.4, 0], 13.4, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [0, TY - 2.4, 0], [0, TY, 0], 22, '#e8e6e0', { mat: 'gloss', olw: 0.3, cap: top });
        s += line3(C, frontArc(C, 22.05, TY - 1.2, 30), 1.6, BR) + line3(C, frontArc(C, 22.1, TY - 0.8, 30, 0.9), 0.35, '#fff4d0', 'opacity="0.8"');
        s += PLN(C, TY + 0.05, `<rect x="-2" y="-2" width="12" height="12" fill="#f4efe4" stroke="#d8d0c0" stroke-width="0.2" transform="rotate(12)"/>`) + coupe(C, 4, TY + 0.1, 4, '#e88a3a');
        const tw = C.P([6.6, TY + 6.9, 4]); s += `<path d="M${f1(tw[0] - 1.6 * k)} ${f1(tw[1])}q${f1(1.2 * k)} ${f1(-2 * k)} ${f1(2.6 * k)} ${f1(-0.6 * k)}" stroke="#f08a20" stroke-width="${f1(0.6 * k)}" fill="none"/>`;
        C.p(-23, 0, -23); C.p(23, 0, 23); C.p(23, 0, -23); C.p(-23, 0, 23); C.p(0, TY + 8, 0); C.p(-23, TY, 0); C.p(23, TY, 0);
        const defs = `<defs><radialGradient id="${id}gl" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.12"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    const frontArc31 = (C, cx, cz, r, y) => { const t = thV(C); return rep(25, i => { const a = t - PI / 2 + PI * i / 24; return [cx + Math.cos(a) * r, y, cz + Math.sin(a) * r]; }); };

    // CLB-067 CRYSTAL & ILLUMINATED CHROME ICE-BUCKET STAND (T4): a polished-nickel champagne-bucket stand: a round weighted base with a warm
    // light ring glowing underneath, a slim column and a three-arm ring cradle holding a cut-crystal ice bucket full of ice, lit warm from inside,
    // with a champagne bottle angled in it and a white linen napkin draped over the rim. Live: the bucket glow breathes, ice glints, a drop of
    // condensation runs down the crystal.
    N.icestand31 = S => { const D = { w: 50, d: 50, round: 1, topH: 58, topW: 24, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('i67'), R = rng('icestand31'), NI = '#d8d4cc', BY = 40, BT = 58, th = thV(C);
        let s = shadow(C, 0, 0, 18, 18, 0.35) + PLN(C, 0.15, `<circle r="22" fill="url(#${id}fl)">${an('opacity', '0.7;1;0.7', 4)}</circle>`);
        s += cyl3(C, [0, 0.6, 0], [0, 2.6, 0], 15, NI, { mat: 'chrome', olw: 0.3, r2: 13.6 }) + cyl3(C, [0, 2.6, 0], [0, 3.6, 0], 5, NI, { mat: 'chrome', olw: 0.2, r2: 2.4 });
        s += line3(C, frontArc(C, 15.1, 0.4, 24), 0.8, '#ffd9a0', 'opacity="0.85"');
        s += cyl3(C, [0, 3.6, 0], [0, BY - 5.6, 0], 1.5, NI, { mat: 'chrome', olw: 0.2 }) + sph(C, [0, BY - 5.8, 0], 1.9, NI);
        const ringP = y => rep(25, i => { const a = i / 24 * 2 * PI; return [Math.cos(a) * 10.6, y, Math.sin(a) * 10.6]; });
        const arms = rep(3, i => { const a = i * 2 * PI / 3 + 0.5; return line3(C, [[0, BY - 6, 0], [Math.cos(a) * 10.6, BY, Math.sin(a) * 10.6]], 0.7, NI); }).join('');
        // crystal bucket (back wall, contents, front wall)
        const bucket = (op) => cyl3(C, [0, BY - 2, 0], [0, BT, 0], 8.4, '#eaf0f2', { mat: 'gloss', op, olw: 0.3, r2: 10, noCap: 1 });
        const facets = rep(10, i => { const a = th - 1.35 + i * 2.7 / 9; return line3(C, [[Math.cos(a) * 8.5, BY - 1.6, Math.sin(a) * 8.5], [Math.cos(a + 0.12) * 10.05, BT - 0.4, Math.sin(a + 0.12) * 10.05]], 0.25, '#ffffff', 'opacity="0.55"') + line3(C, [[Math.cos(a + 0.12) * 8.5, BY - 1.6, Math.sin(a + 0.12) * 8.5], [Math.cos(a) * 10.05, BT - 0.4, Math.sin(a) * 10.05]], 0.2, '#b8c4c8', 'opacity="0.5"'); }).join('');
        const glowC = C.P([0, BY + 8, 0]), glow = `<ellipse cx="${f1(glowC[0])}" cy="${f1(glowC[1])}" rx="${f1(9 * k)}" ry="${f1(11 * k)}" fill="url(#${id}gw)">${an('opacity', '0.6;1;0.6', 3.4)}</ellipse>`;
        const ice = PLN(C, BT - 1.2, `<circle r="9.4" fill="#e8f2f4" opacity="0.8"/>` + rep(16, () => { const a = R() * 2 * PI, r = R() * 7.6, w = 1.6 + R() * 1.6; return `<rect x="${f1(Math.cos(a) * r - w / 2)}" y="${f1(Math.sin(a) * r - w / 2)}" width="${f1(w)}" height="${f1(w)}" rx="0.4" fill="#ffffff" stroke="#c8d8dc" stroke-width="0.15" transform="rotate(${Math.round(R() * 90)} ${f1(Math.cos(a) * r)} ${f1(Math.sin(a) * r)})"/>`; }).join('')
          + rep(4, i => `<circle cx="${f1((R() - 0.5) * 12)}" cy="${f1((R() - 0.5) * 12)}" r="0.5" fill="#ffffff" opacity="0">${an('opacity', '0;1;0', n4(1.4 + R() * 2), -R() * 3)}</circle>`).join(''));
        const B0 = [-1.5, BY + 1, 1], B1 = [3.2, BT + 9, -2.4], dir = nrm([B1[0] - B0[0], B1[1] - B0[1], B1[2] - B0[2]]), at3 = t => add(B0, mul(dir, t));
        const bottle = cyl3(C, at3(10), at3(18), 2.8, '#1e3a24', { mat: 'gloss', olw: 0.2 }) + cyl3(C, at3(18), at3(21.4), 2.8, '#1e3a24', { mat: 'gloss', olw: 0.2, r2: 1.1 }) + cyl3(C, at3(20), at3(26), 1.15, '#d8b060', { mat: 'metal', olw: 0.15 }) + cyl3(C, at3(26), at3(26.8), 1.2, '#e8c878', { mat: 'metal', olw: 0.12 });
        const nap = (() => { const a = th + 0.5, p0 = C.P([Math.cos(a - 0.5) * 10, BT + 0.4, Math.sin(a - 0.5) * 10]), p1 = C.P([Math.cos(a + 0.5) * 10, BT + 0.4, Math.sin(a + 0.5) * 10]), p2 = C.P([Math.cos(a + 0.45) * 11, BT - 9, Math.sin(a + 0.45) * 11]), p3 = C.P([Math.cos(a - 0.4) * 11, BT - 11, Math.sin(a - 0.4) * 11]);
          return `<path d="M${P2(p0)}L${P2(p1)}L${P2(p2)}Q${f1((p2[0] + p3[0]) / 2)} ${f1(Math.max(p2[1], p3[1]) + 2 * k)} ${P2(p3)}Z" fill="#f8f6f0" stroke="#d8d4c8" stroke-width="${f1(0.25 * k)}"/><path d="M${P2(p0)}L${P2(p3)}" stroke="#e0dcd0" stroke-width="${f1(0.3 * k)}"/>`; })();
        const dr = C.P([Math.cos(th - 0.6) * 9.8, BT - 6, Math.sin(th - 0.6) * 9.8]);
        const drop = `<circle cx="${f1(dr[0])}" cy="${f1(dr[1])}" r="${f1(0.45 * k)}" fill="#ffffff" opacity="0.8">${at('translate', `0 0;0 ${f1(10 * k)}`, 4.2, 0, ' keyTimes="0;1" calcMode="spline" keySplines="0.6 0 1 1"')}${an('opacity', '0.8;0.8;0', 4.2)}</circle>`;
        s += line3(C, ringP(BY).filter((q, i) => Math.cos(i / 24 * 2 * PI - th) < 0.05), 0.9, NI) + arms + glow + bucket(0.3) + ice + bottle + bucket(0.22) + facets + line3(C, frontArc(C, 10.05, BT, 24), 0.6, '#ffffff', 'opacity="0.8"')
          + line3(C, frontArc(C, 10.6, BY, 24), 1, NI) + nap + drop;
        C.p(-17, 0, -17); C.p(17, 0, 17); C.p(17, 0, -17); C.p(-17, 0, 17); C.p(0, BT + 12, 0); C.p(-12, BT, 0); C.p(12, BT, 0);
        const defs = `<defs><radialGradient id="${id}fl"><stop offset="0" stop-color="#ffcf8a" stop-opacity="0.5"/><stop offset="0.7" stop-color="#ffcf8a" stop-opacity="0.15"/><stop offset="1" stop-color="#ffcf8a" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}gw"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.75"/><stop offset="1" stop-color="#ffd28a" stop-opacity="0"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-087 AUTONOMOUS FLOATING DRONE COASTER TABLE (T5): a magnetic levitation side table: a walnut-and-brass base puck holds a round walnut
    // tray top with a brass rim hovering in mid-air, a warm light glowing in the gap; two tiny brass-and-black coaster drones, each carrying a
    // drink on its back, hover beside it ready to fly glasses to guests. Live: the top bobs gently and slowly turns, the drones bob out of step
    // with their rotors spinning, the levitation glow breathes.
    N.dronetab31 = S => { const D = { w: 50, d: 50, round: 1, topH: 56, topW: 26, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('d87'), R = rng('dronetab31'), BR = '#c8a050', WAL = '#5a3420', TY = 56, th = thV(C);
        let s = shadow(C, 0, 0, 16, 16, 0.4) + shadow(C, 0, 0, 22, 22, 0.15);
        const base = r => `<circle r="${r}" fill="${WAL}"/><circle r="${n4(r - 1)}" fill="none" stroke="${BR}" stroke-width="0.9"/><circle r="5" fill="#141210"/><circle r="5" fill="url(#${id}mg)">${an('opacity', '0.6;1;0.6', 2.6)}</circle>`;
        s += cyl3(C, [0, 0, 0], [0, 1.4, 0], 15, BR, { mat: 'metal', olw: 0.25 }) + cyl3(C, [0, 1.4, 0], [0, 7, 0], 13.6, WAL, { mat: 'gloss', olw: 0.3, r2: 12.4, cap: base });
        const gap = C.P([0, 9, 0]), tp = C.P([0, TY - 3, 0]); s += `<path d="M${f1(gap[0] - 4 * k)} ${f1(gap[1])}L${f1(tp[0] - 13 * k)} ${f1(tp[1])}L${f1(tp[0] + 13 * k)} ${f1(tp[1])}L${f1(gap[0] + 4 * k)} ${f1(gap[1])}Z" fill="url(#${id}bm)">${an('opacity', '0.35;0.6;0.35', 2.6)}</path>`;
        const drone = (x, y, z, drink, b) => { const body = cyl3(C, [x, y, z], [x, y + 1.8, z], 4.2, '#1a1816', { mat: 'gloss', olw: 0.2, capCol: '#2a2420' }) + rep(4, i => { const a = i * PI / 2 + PI / 4, q = [x + Math.cos(a) * 7.8, y + 1.2, z + Math.sin(a) * 7.8];
            return line3(C, [[x, y + 0.8, z], q], 0.6, BR) + PLN(C, y + 1.6, `<ellipse rx="4.2" ry="4.2" fill="#d8d0c0" opacity="0.25"/><g>${at('rotate', '0;360', 0.25, -i * 0.05)}<path d="M-4 0H4" stroke="#3a3430" stroke-width="0.5" opacity="0.7"/></g>`, q[0], q[2]); }).join('');
          const glass = cyl3(C, [x, y + 1.8, z], [x, y + 8, z], 2.3, '#eef4f6', { mat: 'gloss', op: 0.45, olw: 0.15, capCol: drink, r2: 2.6 }) + cyl3(C, [x, y + 1.8, z], [x, y + 6, z], 2.2, drink, { op: 0.6, olw: 0, noCap: 1 });
          const led = C.P([x, y + 0.6, z + 3.2]);
          return `<g>${at('translate', `0 0;0 ${f1(-2.4 * k)};0 0`, 1.8, b, SPL(2))}${body}${glass}<circle cx="${f1(led[0])}" cy="${f1(led[1])}" r="${f1(0.45 * k)}" fill="#ffd28a">${an('opacity', '1;0.3;1', 1)}</circle></g>`; };
        const dA = [-19, 62, 12], dB = [18, 68, -14], dd = q => q[0] * C.v[0] + q[2] * C.v[2];
        const top = r => `<clipPath id="${id}tc"><circle r="${r}"/></clipPath><circle r="${r}" fill="${WAL}"/><g clip-path="url(#${id}tc)">${rep(8, i => `<path d="M${-r} ${f1(-r + i * r / 4 + 1)}Q0 ${f1(-r + i * r / 4 - 1.5)} ${r} ${f1(-r + i * r / 4 + 0.6)}" stroke="#3e2210" stroke-width="0.3" fill="none" opacity="0.6"/>`).join('')}</g><circle r="${n4(r - 0.6)}" fill="none" stroke="${BR}" stroke-width="1"/><circle r="${r}" fill="url(#${id}gl)"/>`;
        const tray = `<g>${at('translate', `0 0;0 ${f1(-2 * k)};0 0`, 3.6, 0, SPL(2))}` + cyl3(C, [0, TY - 3, 0], [0, TY - 2, 0], 6, '#141210', { mat: 'gloss', olw: 0.2 }) + cyl3(C, [0, TY - 2, 0], [0, TY, 0], 18, WAL, { mat: 'gloss', olw: 0.3, cap: top })
          + line3(C, frontArc(C, 18.05, TY - 1, 26), 1.4, BR) + line3(C, frontArc(C, 18.1, TY - 0.6, 26, 0.9), 0.35, '#fff4d0', 'opacity="0.8"') + `</g>`;
        const items = [[dd(dA), drone(...dA, '#e88a3a', 0)], [dd(dB), drone(...dB, '#d8507a', 0.9)], [0, tray]].sort((a, b) => a[0] - b[0]);
        s += items.map(q => q[1]).join('');
        C.p(-27, 0, -24); C.p(27, 0, 24); C.p(27, 0, -24); C.p(-27, 0, 24); C.p(-28, 70, 13); C.p(27, 76, -15); C.p(0, TY + 4, 0);
        const defs = `<defs><radialGradient id="${id}mg"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.9"/><stop offset="1" stop-color="#ffb060" stop-opacity="0"/></radialGradient>`
          + `<linearGradient id="${id}bm" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.5"/><stop offset="1" stop-color="#ffe2a8" stop-opacity="0.05"/></linearGradient>`
          + `<radialGradient id="${id}gl" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.15"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-008 RED PLASTIC PARTY CUPS & GLOWSTICKS (T1): the mess after a party game: three red plastic cups (white inside) in a triangle with
    // beer in them, a short stack of empties, one cup knocked over in a spilled puddle, a crumpled napkin, a bottle cap, and snapped glowsticks
    // (a green stick, a pink bracelet ring, a yellow one bent in a V). Live: the glowsticks pulse softly.
    N.cups31 = S => { const D = { w: 50, d: 40, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('c08'), R = rng('cups31'), RED = '#d8352a';
        const cup = (x, z, beer) => cyl3(C, [x, 0, z], [x, 9.6, z], 3.3, RED, { mat: 'gloss', olw: 0.25, r2: 4.3, capCol: beer ? '#e8b040' : '#f6f4ee' }) + line3(C, frontArc31(C, x, z, 4.15, 8.4), 0.3, '#a8261e', 'opacity="0.6"') + line3(C, frontArc31(C, x, z, 4.3, 9.6), 0.5, '#f6f4ee');
        const glowL3 = (P, col, w) => line3(C, P, w * 3, col, `opacity="0.25" filter="url(#g31b1)"`) + line3(C, P, w, col) + line3(C, P, w * 0.35, '#ffffff', 'opacity="0.6"');
        let s = shadow(C, 0, 0, 24, 18, 0.25);
        s += PLN(C, 0.1, `<path d="M8 4c4 -2 10 -1 12 2c2 3 -3 6 -8 5c-3 -0.6 -6 -3 -4 -7Z" fill="#e8b040" opacity="0.35"/>`);
        const ring = rep(17, i => { const a = i / 16 * 2 * PI; return [-14 + Math.cos(a) * 5, 0.5, 10 + Math.sin(a) * 5]; });
        const tipped = (() => { const a = [12, 3.4, 6], b = [20, 4.2, 9]; return cyl3(C, a, b, 3.3, RED, { mat: 'gloss', olw: 0.25, r2: 4.3, capCol: '#f6f4ee' }); })();
        const items = [
          [-6, -6, cup(-6, -6, 1)], [2, -9, cup(2, -9, 1)], [-2, 0, cup(-2, 0, 1)],
          [16, -10, cyl3(C, [16, 0, -10], [16, 9.6, -10], 3.3, RED, { mat: 'gloss', olw: 0.25, r2: 4.3, capCol: '#f6f4ee' }) + cyl3(C, [16, 1.6, -10], [16, 11.2, -10], 3.3, RED, { mat: 'gloss', olw: 0.25, r2: 4.3, capCol: '#f6f4ee' }) + cyl3(C, [16, 3.2, -10], [16, 12.8, -10], 3.3, RED, { mat: 'gloss', olw: 0.25, r2: 4.3, capCol: '#f6f4ee' })],
          [15, 6, tipped]].map(([x, z, sv]) => ({ d: x * C.v[0] + z * C.v[2], s: sv })).sort((a, b) => a.d - b.d);
        s += `<g>${an('opacity', '0.75;1;0.75', 2.2)}${glowL3(ring, '#ff4fb8', 0.9)}</g>` + `<g>${an('opacity', '1;0.75;1', 2.6)}${glowL3([[-20, 0.6, -2], [-9, 0.6, -14]], '#7dff6a', 1.1)}</g>` + `<g>${an('opacity', '0.8;1;0.8', 1.9)}${glowL3([[4, 0.6, 14], [10, 0.6, 10], [8, 0.6, 18]], '#ffe14f', 1)}</g>`;
        s += PLN(C, 0.2, `<path d="M-22 6l3 -2 4 1 1 3 -2 3 -4 0z" fill="#f4f2ec" stroke="#c8c4b8" stroke-width="0.2"/><path d="M-20 5l2 3M-18 4l1 4" stroke="#c8c4b8" stroke-width="0.2"/><circle cx="-4" cy="12" r="1.5" fill="#c8ccd2" stroke="#7a7e86" stroke-width="0.3"/>`);
        s += items.map(q => q.s).join('');
        C.p(-24, 0, -18); C.p(24, 0, 18); C.p(24, 0, -18); C.p(-24, 0, 18); C.p(16, 14, -10);
        return { defs: DEFG, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-028 COCKTAIL SHAKER SET, ICE TONGS & NEON COASTERS (T2): a budget bar set on a little stack of neon acrylic coasters: a three-piece steel
    // shaker with a small dent and water spots, a double jigger, claw ice tongs and a twisted bar spoon lying beside it, two ice cubes melting on
    // the top coaster. Live: the coasters' neon edges pulse and a bead of condensation slides down the shaker.
    N.shaker31 = S => { const D = { w: 28, d: 28, small: 1, round: 1, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('s28'), ST = '#c8ccd2';
        let s = shadow(C, 0, 0, 13, 11, 0.3);
        const coaster = (x, y, z, col, b) => `<g>${an('opacity', '0.8;1;0.8', 2.2, b)}${cyl3(C, [x, y, z], [x, y + 0.7, z], 5.4, col, { mat: 'gloss', olw: 0.2, op: 0.85, capCol: col })}</g>` + line3(C, frontArc31(C, x, z, 5.45, y + 0.35), 0.6, col, 'opacity="0.5" filter="url(#g31b1)"');
        s += coaster(5, 0, 5, '#ff4fb8', 0) + coaster(5.4, 0.7, 5.2, '#7dff6a', -0.7) + coaster(4.8, 1.4, 4.8, '#ffe14f', -1.4);
        s += PLN(C, 2.15, `<rect x="2" y="2.6" width="2" height="2" rx="0.4" fill="#ffffff" opacity="0.85"/><rect x="5" y="3.6" width="1.8" height="1.8" rx="0.4" fill="#ffffff" opacity="0.75" transform="rotate(20 6 4.5)"/><ellipse cx="4.6" cy="4.4" rx="3" ry="1.6" fill="#ffffff" opacity="0.2"/>`);
        s += line3(C, [[-11, 0.4, 7], [-2, 0.4, 10]], 0.35, ST) + line3(C, rep(8, i => [-10 + i * 1.2, 0.5, 7.3 + i * 0.4]), 0.15, '#8a8e96') + cyl3(C, [-11.4, 0.2, 6.9], [-11.4, 0.7, 6.9], 0.8, ST, { mat: 'metal', olw: 0.1 });
        s += line3(C, [[-12, 0.4, -4], [-6, 1.2, -0.6], [-3, 0.4, 1.4]], 0.45, ST) + line3(C, [[-12, 0.4, -4], [-6, 1.6, -2.2], [-2.6, 0.4, -2.6]], 0.45, ST) + line3(C, [[-3, 0.4, 1.4], [-2.2, 0.4, 2.2]], 0.35, ST) + line3(C, [[-2.6, 0.4, -2.6], [-1.8, 0.4, -3.2]], 0.35, ST);
        s += cyl3(C, [7.4, 0, -6], [7.4, 2.4, -6], 1.8, ST, { mat: 'metal', olw: 0.15, r2: 0.7 }) + cyl3(C, [7.4, 2.4, -6], [7.4, 5.4, -6], 0.7, ST, { mat: 'metal', olw: 0.15, r2: 1.6, capCol: '#4a4c52' });
        s += cyl3(C, [-2, 0, -4], [-2, 9, -4], 3.3, ST, { mat: 'metal', olw: 0.2, r2: 3.8 }) + cyl3(C, [-2, 9, -4], [-2, 12.4, -4], 3.8, ST, { mat: 'metal', olw: 0.2, r2: 2.2 }) + cyl3(C, [-2, 12.4, -4], [-2, 14.6, -4], 1.5, ST, { mat: 'metal', olw: 0.15 });
        s += line3(C, frontArc31(C, -2, -4, 3.85, 9), 0.4, '#8a8e96');
        const dn = C.P([-2 + Math.cos(thV(C) + 0.6) * 3.6, 5, -4 + Math.sin(thV(C) + 0.6) * 3.6]); s += `<ellipse cx="${f1(dn[0])}" cy="${f1(dn[1])}" rx="${f1(1 * k)}" ry="${f1(1.4 * k)}" fill="#6a6e76" opacity="0.4"/>`;
        s += rep(6, i => { const a = thV(C) - 0.9 + i * 0.35, q = C.P([-2 + Math.cos(a) * 3.55, 2 + (i * 37 % 6), -4 + Math.sin(a) * 3.55]); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.28 * k)}" fill="#ffffff" opacity="0.7"/>`; }).join('');
        const dr = C.P([-2 + Math.cos(thV(C) - 0.4) * 3.6, 8, -4 + Math.sin(thV(C) - 0.4) * 3.6]); s += `<circle cx="${f1(dr[0])}" cy="${f1(dr[1])}" r="${f1(0.35 * k)}" fill="#ffffff" opacity="0.8">${at('translate', `0 0;0 ${f1(6 * k)}`, 3.8, 0, ' keyTimes="0;1" calcMode="spline" keySplines="0.6 0 1 1"')}${an('opacity', '0.8;0.8;0', 3.8)}</circle>`;
        C.p(-13, 0, -12); C.p(13, 0, 12); C.p(13, 0, -12); C.p(-13, 0, 12); C.p(-2, 15, -4);
        return { defs: DEFG, front: s, bb: C.bb(2) }; };
      return D; };

    // CLB-048 LED FLASHING ICE CUBES & ACRYLIC CHAMPAGNE BUCKET (T3): a clear acrylic champagne bucket with moulded handles, filled with water and
    // light-up LED ice cubes that flash and cycle colours, a champagne bottle standing in it, and three more LED cubes scattered on the table.
    // Live: every cube cycles through warm white, rose, amber and violet at its own pace, lighting the water and the table around it.
    N.ledice31 = S => { const D = { w: 32, d: 22, small: 1, round: 1, glow: () => ({ y: 10, r: 22, c: 'url(#gWarm)' }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('l48'), R = rng('ledice31'), CC = ['#fff2d8', '#ff9ab8', '#ffb050', '#b080ff'], th = thV(C);
        const cyc = (i, T) => an('fill', CC.slice(i % 4).concat(CC.slice(0, i % 4)).concat(CC[i % 4]).join(';'), T, -i * 0.7);
        const cube = (x, y, z, sz, i) => { const q = C.P([x, y + sz / 2, z]); return B10(C, { c: [x, y, z], w: sz, h: sz, d: sz, col: '#ffffff', r: 0.5, op: 0.7 }) + `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(sz * 1.3 * k)}" fill="${CC[i % 4]}" opacity="0.55" filter="url(#g31b1)">${cyc(i, 4 + (i % 3))}</circle><circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(sz * 0.35 * k)}" fill="#ffffff" opacity="0.9"/>`; };
        let s = shadow(C, 0, 0, 15, 10, 0.25);
        s += PLN(C, 0.1, `<circle cx="-11" cy="4" r="5" fill="${CC[1]}" opacity="0.25">${cyc(1, 5)}</circle><circle cx="11" cy="-4" r="5" fill="${CC[2]}" opacity="0.25">${cyc(2, 4)}</circle>`);
        s += cube(-11, 0, 4, 2.6, 1) + cube(12, 0, -4, 2.4, 2) + cube(10, 0, 5, 2.2, 3);
        const BX = 0, BT = 13;
        s += cyl3(C, [BX, 0, 0], [BX, BT, 0], 6.6, '#e8f0f4', { mat: 'gloss', op: 0.22, olw: 0.3, r2: 8, noCap: 1 });
        s += rep(7, i => { const a = R() * 2 * PI, r = R() * 5, y = 1 + R() * 9; const q = C.P([BX + Math.cos(a) * r, y, Math.sin(a) * r]); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.8 * k)}" fill="${CC[i % 4]}" opacity="0.7">${cyc(i, 3 + (i % 4) * 0.7)}</circle><rect x="${f1(q[0] - 1.1 * k)}" y="${f1(q[1] - 1.1 * k)}" width="${f1(2.2 * k)}" height="${f1(2.2 * k)}" rx="${f1(0.3 * k)}" fill="#ffffff" opacity="0.85" transform="rotate(${Math.round(R() * 60)} ${f1(q[0])} ${f1(q[1])})"/>`; }).join('');
        s += PLN(C, BT - 2, `<circle r="7.6" fill="#dff0f8" opacity="0.25"/>`);
        s += cyl3(C, [BX + 1, 2, 0], [BX + 1, 12, 0], 2.5, '#1e3a24', { mat: 'gloss', olw: 0.2 }) + cyl3(C, [BX + 1, 12, 0], [BX + 1, 15, 0], 2.5, '#1e3a24', { mat: 'gloss', olw: 0.2, r2: 1 }) + cyl3(C, [BX + 1, 14, 0], [BX + 1, 19, 0], 1.05, '#d8b060', { mat: 'metal', olw: 0.12 });
        s += cyl3(C, [BX, 0, 0], [BX, BT, 0], 6.6, '#e8f0f4', { mat: 'gloss', op: 0.1, olw: 0.3, r2: 8, noCap: 1 }) + line3(C, frontArc(C, 8, BT, 24), 0.45, '#ffffff', 'opacity="0.8"');
        [-1, 1].forEach(sg => { s += line3(C, [[BX + sg * 7.6, BT - 2, 0], [BX + sg * 9.6, BT - 2.6, 0], [BX + sg * 9.4, BT - 5, 0], [BX + sg * 7.2, BT - 5.4, 0]], 0.7, '#e8f0f4', 'opacity="0.7"'); });
        C.p(-16, 0, -11); C.p(16, 0, 11); C.p(16, 0, -11); C.p(-16, 0, 11); C.p(1, 20, 0);
        return { defs: DEFG, front: s, bb: C.bb(2) }; };
      return D; };

    // CLB-068 GOLD BOTTLE SPARKLERS & CRYSTAL VAPOR CARAFE (T4): VIP bottle service: an unbranded metallic gold champagne bottle with a black neck
    // band and a lit ice-fountain sparkler clipped to its neck, beside a cut-crystal vapour carafe on a brass stem with a small brass bowl, tray
    // and a coiled tasselled hose. Live: the sparkler fountains bright sparks, the bottle catches the flicker, a thin wisp of vapour curls up.
    N.vipset31 = S => { const D = { w: 26, d: 22, small: 1, round: 1, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('v68'), R = rng('vipset31'), BR = '#c8a050', th = thV(C);
        let s = shadow(C, 0, 0, 13, 10, 0.3);
        const BXp = [-6, 0, 2], CXp = [6, 0, -2];
        const bottle = cyl3(C, [BXp[0], 0, BXp[2]], [BXp[0], 10, BXp[2]], 2.8, '#d8b050', { mat: 'metal', olw: 0.2 }) + cyl3(C, [BXp[0], 10, BXp[2]], [BXp[0], 13, BXp[2]], 2.8, '#d8b050', { mat: 'metal', olw: 0.2, r2: 1.1 })
          + cyl3(C, [BXp[0], 12.6, BXp[2]], [BXp[0], 17.6, BXp[2]], 1.15, '#d8b050', { mat: 'metal', olw: 0.15 }) + cyl3(C, [BXp[0], 14, BXp[2]], [BXp[0], 15.2, BXp[2]], 1.25, '#141210', { olw: 0.1, noCap: 1 }) + cyl3(C, [BXp[0], 17.6, BXp[2]], [BXp[0], 18.4, BXp[2]], 1.2, '#e8c878', { mat: 'metal', olw: 0.1 })
          + cyl3(C, [BXp[0], 4, BXp[2]], [BXp[0], 7, BXp[2]], 2.85, '#141210', { olw: 0.1, noCap: 1 });
        const sp0 = [BXp[0] + 1.6, 17, BXp[2] + 0.4], sp1 = [BXp[0] + 2.6, 22, BXp[2] + 0.8];
        let spark = cyl3(C, sp0, sp1, 0.55, '#e8e4dc', { olw: 0.1 }) + line3(C, [[BXp[0] + 1.2, 16, BXp[2]], sp0], 0.4, '#8a8e96');
        const tip = C.P(sp1); spark += `<circle cx="${f1(tip[0])}" cy="${f1(tip[1])}" r="${f1(6 * k)}" fill="url(#${id}sg)">${an('opacity', '0.7;1;0.6;1;0.8', 0.5)}</circle>`;
        spark += rep(14, i => { const Q = rng('v68s' + i), ang = -PI / 2 + (Q() - 0.5) * 1.2, len = (6 + Q() * 7) * k, d = n4(0.5 + Q() * 0.5), b = -Q() * d;
          return `<circle cx="${f1(tip[0])}" cy="${f1(tip[1])}" r="${f1(0.35 * k)}" fill="#fff6d0">${at('translate', `0 0;${f1(Math.cos(ang) * len)} ${f1(Math.sin(ang) * len + 3 * k)}`, d, b)}${an('opacity', '1;0', d, b)}</circle>`; }).join('');
        const tray = cyl3(C, [CXp[0], 0, CXp[2]], [CXp[0], 0.6, CXp[2]], 6.4, BR, { mat: 'metal', olw: 0.2 });
        const car = cyl3(C, [CXp[0], 0.6, CXp[2]], [CXp[0], 2, CXp[2]], 3.4, '#eaf0f2', { mat: 'gloss', op: 0.45, olw: 0.2, r2: 5.4 }) + cyl3(C, [CXp[0], 2, CXp[2]], [CXp[0], 8, CXp[2]], 5.4, '#eaf0f2', { mat: 'gloss', op: 0.4, olw: 0.25, r2: 2 })
          + cyl3(C, [CXp[0], 1, CXp[2]], [CXp[0], 4.4, CXp[2]], 4.6, '#c8dce8', { op: 0.35, olw: 0, noCap: 1 })
          + rep(8, i => { const a = th - 1.2 + i * 0.34; return line3(C, [[CXp[0] + Math.cos(a) * 5.2, 2.4, CXp[2] + Math.sin(a) * 5.2], [CXp[0] + Math.cos(a) * 2.3, 7.6, CXp[2] + Math.sin(a) * 2.3]], 0.15, '#ffffff', 'opacity="0.6"'); }).join('')
          + cyl3(C, [CXp[0], 8, CXp[2]], [CXp[0], 18, CXp[2]], 0.9, BR, { mat: 'metal', olw: 0.15 }) + cyl3(C, [CXp[0], 11, CXp[2]], [CXp[0], 11.8, CXp[2]], 2, BR, { mat: 'metal', olw: 0.12 })
          + cyl3(C, [CXp[0], 18, CXp[2]], [CXp[0], 20.4, CXp[2]], 1.2, BR, { mat: 'metal', olw: 0.15, r2: 2.6, capCol: '#3a2a1a' });
        const bz = (A, B, Cc, Dd, n) => rep(n + 1, i => { const t = i / n, u = 1 - t; return [0, 1, 2].map(m => u * u * u * A[m] + 3 * u * u * t * B[m] + 3 * u * t * t * Cc[m] + t * t * t * Dd[m]); });
        const HP = bz([CXp[0] + 1, 10, CXp[2]], [CXp[0] + 8, 9, CXp[2] + 2], [CXp[0] + 9, 0.6, CXp[2] + 10], [CXp[0] + 1, 0.6, CXp[2] + 9], 16).concat(bz([CXp[0] + 1, 0.6, CXp[2] + 9], [CXp[0] - 5, 0.6, CXp[2] + 8], [CXp[0] - 2, 0.6, CXp[2] + 3], [CXp[0] + 2, 0.6, CXp[2] + 5], 10));
        const hose = line3(C, HP, 0.8, '#5a3420') + line3(C, [[CXp[0] + 2, 0.6, CXp[2] + 5], [CXp[0] + 4.6, 0.6, CXp[2] + 4]], 0.6, BR) + line3(C, [[CXp[0] + 4.6, 0.6, CXp[2] + 4], [CXp[0] + 5.6, 0.4, CXp[2] + 2.4]], 0.5, '#c8402e');
        const vp = C.P([CXp[0], 21, CXp[2]]); const vapor = `<path d="M${P2(vp)}c${f1(-2 * k)} ${f1(-3 * k)} ${f1(2 * k)} ${f1(-5 * k)} 0 ${f1(-9 * k)}" stroke="#f4f0ec" stroke-width="${f1(1.2 * k)}" fill="none" opacity="0.4" filter="url(#g31b1)">${an('d', `M${P2(vp)}c${f1(-2 * k)} ${f1(-3 * k)} ${f1(2 * k)} ${f1(-5 * k)} 0 ${f1(-9 * k)};M${P2(vp)}c${f1(2 * k)} ${f1(-3 * k)} ${f1(-2 * k)} ${f1(-6 * k)} ${f1(1 * k)} ${f1(-9 * k)};M${P2(vp)}c${f1(-2 * k)} ${f1(-3 * k)} ${f1(2 * k)} ${f1(-5 * k)} 0 ${f1(-9 * k)}`, 4.4)}${an('opacity', '0.25;0.5;0.25', 4.4)}</path>`;
        const bc = C.P([BXp[0], 8, BXp[2]]); const flick = `<ellipse cx="${f1(bc[0] - 0.8 * k)}" cy="${f1(bc[1])}" rx="${f1(0.8 * k)}" ry="${f1(5 * k)}" fill="#fff6d8" opacity="0.4">${an('opacity', '0.2;0.6;0.3;0.55;0.2', 0.6)}</ellipse>`;
        const items = [[BXp[0] * C.v[0] + BXp[2] * C.v[2], bottle + flick + spark], [CXp[0] * C.v[0] + CXp[2] * C.v[2], tray + car + hose + vapor]].sort((a, b) => a[0] - b[0]);
        s += items.map(q => q[1]).join('');
        C.p(-13, 0, -11); C.p(13, 0, 11); C.p(13, 0, -11); C.p(-13, 0, 11); C.p(-4, 34, 2); C.p(6, 31, -2);
        const defs = DEFG + `<defs><radialGradient id="${id}sg"><stop offset="0" stop-color="#ffffff"/><stop offset="0.3" stop-color="#fff0c0" stop-opacity="0.8"/><stop offset="1" stop-color="#ffc860" stop-opacity="0"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(2) }; };
      return D; };

    // CLB-088 LEVITATING PLASMA DRINK ORBS & HOLOGRAPHIC VIP WRISTBAND DOCK (T5): a walnut-and-brass dock puck with a brass post holding woven VIP
    // wristbands (rose, gold, black) with brass tags, a soft gold light ring floating over the dock, and three blown-glass drink spheres floating
    // around it, each holding an amber or rose cocktail lit warm from inside with a gold straw. Live: the spheres bob and drift out of step,
    // their glow breathes, the light ring turns.
    N.orbs31 = S => { const D = { w: 28, d: 28, small: 1, round: 1, glow: () => ({ y: 16, r: 28, c: 'url(#gWarm)' }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('o88'), BR = '#c8a050', WAL = '#5a3420';
        let s = shadow(C, 0, 0, 12, 12, 0.3);
        s += cyl3(C, [0, 0, 0], [0, 0.6, 0], 9, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [0, 0.6, 0], [0, 2.8, 0], 8.4, WAL, { mat: 'gloss', olw: 0.25, r2: 7.6, cap: r => `<circle r="${r}" fill="${WAL}"/><circle r="${n4(r - 0.7)}" fill="none" stroke="${BR}" stroke-width="0.6"/>` });
        s += cyl3(C, [0, 2.8, 0], [0, 11, 0], 0.55, BR, { mat: 'metal', olw: 0.12 }) + line3(C, [[0, 10.6, 0], [3.4, 10.6, 0]], 0.5, BR);
        const band = (col, dz, sw) => { const P = rep(13, i => { const a = i / 12 * 2 * PI; return [1.8 + Math.cos(a) * 1.6 * 0.4, 10.4 - 3.4 + Math.cos(a) * 3.4, dz + Math.sin(a) * 1.6]; }); return line3(C, P, 0.9, col) + line3(C, P, 0.3, sw, 'opacity="0.6"') + cyl3(C, [1.8, 6.6, dz - 0.2], [1.8, 6.6, dz + 0.4], 0.8, BR, { mat: 'metal', olw: 0.1 }); };
        s += band('#2a2420', -0.8, '#5a5048') + band('#d8a848', 0, '#fff0c0') + band('#d86a7a', 0.8, '#ffd0d8');
        const rc = C.P([0, 13, 0]); s += `<g>${PLN(C, 13, `<g>${at('rotate', '0;360', 12)}<circle r="6" fill="none" stroke="#ffd28a" stroke-width="0.4" stroke-dasharray="2 1.2" opacity="0.8"/></g><circle r="4.4" fill="none" stroke="#ffe8b8" stroke-width="0.25" opacity="0.6"/>`)}</g>`;
        const orb = (x, y, z, drink, b) => { const q = C.P([x, y, z]), r = 3.2 * k, lq = C.P([x, y - 0.6, z]);
          return `<g>${at('translate', `0 0;${f1(0.8 * k)} ${f1(-2.4 * k)};0 0`, 3 + b, -b, SPL(2))}<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(r * 2.2)}" fill="${drink}" opacity="0.18" filter="url(#g31b1)">${an('opacity', '0.1;0.28;0.1', 2.6, -b)}</circle>`
            + `<clipPath id="${id}c${b}"><circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(r - 0.2 * k)}"/></clipPath><circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(r)}" fill="#fffaf0" opacity="0.18"/>`
            + `<g clip-path="url(#${id}c${b})"><rect x="${f1(q[0] - r)}" y="${f1(lq[1])}" width="${f1(2 * r)}" height="${f1(2 * r)}" fill="${drink}" opacity="0.85"/><ellipse cx="${f1(q[0])}" cy="${f1(lq[1])}" rx="${f1(r)}" ry="${f1(r * 0.3)}" fill="${shade(drink, 1.25)}"/><circle cx="${f1(q[0])}" cy="${f1(q[1] + r * 0.3)}" r="${f1(r * 0.5)}" fill="#fff4d0" opacity="0.5">${an('opacity', '0.3;0.7;0.3', 2.4, -b)}</circle></g>`
            + `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(r)}" fill="none" stroke="#fff6e8" stroke-width="${f1(0.3 * k)}" opacity="0.8"/><ellipse cx="${f1(q[0] - r * 0.4)}" cy="${f1(q[1] - r * 0.45)}" rx="${f1(r * 0.3)}" ry="${f1(r * 0.18)}" fill="#ffffff" opacity="0.85" transform="rotate(-30 ${f1(q[0] - r * 0.4)} ${f1(q[1] - r * 0.45)})"/>`
            + `<path d="M${f1(q[0] + r * 0.2)} ${f1(q[1] - r * 0.2)}l${f1(r * 0.5)} ${f1(-r * 1.3)}" stroke="#d8b060" stroke-width="${f1(0.4 * k)}" stroke-linecap="round"/></g>`; };
        const O = [[-8, 15, 4, '#e8943a', 0], [7, 19, -5, '#d8607a', 0.8], [6, 13, 7, '#f0b050', 1.6]].map(([x, y, z, c, b]) => ({ d: x * C.v[0] + z * C.v[2], s: orb(x, y, z, c, b) })).sort((a, b) => a.d - b.d);
        s += O.map(o => o.s).join('');
        C.p(-13, 0, -13); C.p(13, 0, 13); C.p(13, 0, -13); C.p(-13, 0, 13); C.p(-11, 22, 4); C.p(10, 26, -5);
        return { defs: DEFG, front: s, bb: C.bb(2) }; };
      return D; };

    // CLB-013 PLASTIC COOLER & FOLDING TABLE DRINK STATION (T1): a white plastic folding table with grey steel legs (one leg's foot cap missing)
    // holding a cheap plastic punch bowl with a ladle, a 2-litre soda bottle, a sleeve of red cups and a torn bag of ice slumped in a puddle; under
    // it a scuffed red picnic cooler with a white lid, slightly ajar. Live: a drop of condensation runs down the soda bottle.
    N.drinkst31 = S => { const D = { w: 70, d: 44, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('d13'), R = rng('drinkst31'), TY = 30, LG = '#9aa0a8';
        let s = shadow(C, 0, 0, 34, 21, 0.35);
        const legs = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([a, b]) => ({ d: a * C.v[0] * 30 + b * C.v[2] * 17, s: line3(C, [[a * 30, 0.4, b * 17], [a * 29, TY - 2, b * 16]], 1.1, LG) + (a > 0 && b > 0 ? '' : cyl3(C, [a * 30, 0, b * 17], [a * 30, 1, b * 17], 0.9, '#2a2a2e', { olw: 0.1 })) }));
        s += legs.filter(l => l.d < 0).map(l => l.s).join('');
        const lid = `<rect width="30" height="20" rx="2" fill="#f4f2ec"/><rect x="2" y="2" width="26" height="16" rx="1.4" fill="none" stroke="#d8d4cc" stroke-width="0.5"/>`;
        const side = w => `<rect width="${w}" height="13" fill="#c8322a"/><rect y="0.5" width="${w}" height="1" fill="#a82a22"/>` + rep(4, () => `<path d="M${f1(R() * w)} ${f1(3 + R() * 9)}l${f1(1 + R() * 3)} ${f1((R() - 0.5) * 1.2)}" stroke="#f0a098" stroke-width="0.25"/>`).join('');
        s += B10(C, { c: [-6, 0, -2], w: 30, h: 13, d: 20, col: '#c8322a', r: 1.6, dec: { f: side(30), b: side(30), l: side(20), r: side(20) } }) + B10(C, { c: [-6, 13.4, -2.8], ax: [[1, 0, 0], [0, Math.cos(0.12), Math.sin(0.12)], [0, -Math.sin(0.12), Math.cos(0.12)]], w: 31, h: 3, d: 21, col: '#f4f2ec', r: 1.6, dec: { t: lid } });
        s += line3(C, [[-20, 0.4, 14], [-6, 0.4, 20], [10, 0.4, 16]], 0.1, '#ffffff');
        const top = `<rect width="62" height="36" rx="1" fill="#f2f0ea"/>` + rep(8, () => `<path d="M${f1(R() * 62)} ${f1(R() * 36)}l${f1((R() - 0.5) * 8)} ${f1((R() - 0.5) * 2)}" stroke="#c8c4b8" stroke-width="0.25" opacity="0.7"/>`).join('') + `<path d="M0 18H62" stroke="#d8d4cc" stroke-width="0.4"/><ellipse cx="44" cy="26" rx="8" ry="4" fill="#d8e8f0" opacity="0.6"/>`;
        s += B10(C, { c: [0, TY - 2, 0], w: 62, h: 2, d: 36, col: '#e8e6e0', r: 0.8, dec: { t: top, f: `<rect width="62" height="2" fill="#d8d6d0"/>`, l: `<rect width="36" height="2" fill="#d8d6d0"/>`, r: `<rect width="36" height="2" fill="#d8d6d0"/>`, b: `<rect width="62" height="2" fill="#d8d6d0"/>` } });
        s += legs.filter(l => l.d >= 0).map(l => l.s).join('');
        const items = [];
        items.push([-14, -4, cyl3(C, [-14, TY, -4], [-14, TY + 2.4, -4], 3.6, '#e8eef2', { mat: 'gloss', op: 0.6, olw: 0.2, r2: 8 }) + cyl3(C, [-14, TY + 2.4, -4], [-14, TY + 6, -4], 8, '#e8eef2', { mat: 'gloss', op: 0.45, olw: 0.25, r2: 9.4, capCol: '#e84a6a' })
          + line3(C, [[-11, TY + 6, -4], [-8, TY + 11, -6], [-6.8, TY + 12.6, -6.4]], 0.5, '#f4f2ec') + cyl3(C, [-11.6, TY + 4.8, -3.6], [-11.6, TY + 6.2, -3.6], 1.8, '#f4f2ec', { olw: 0.12 })]);
        items.push([6, -6, cyl3(C, [6, TY, -6], [6, TY + 11, -6], 2.6, '#c8402e', { mat: 'gloss', op: 0.75, olw: 0.2 }) + cyl3(C, [6, TY + 11, -6], [6, TY + 14, -6], 2.6, '#c8402e', { mat: 'gloss', op: 0.75, olw: 0.2, r2: 1 }) + cyl3(C, [6, TY + 14, -6], [6, TY + 15.4, -6], 1.1, '#e8e4dc', { olw: 0.12 }) + cyl3(C, [6, TY + 4, -6], [6, TY + 7.4, -6], 2.65, '#f2ead6', { olw: 0.1, noCap: 1 })]);
        items.push([18, 4, cyl3(C, [18, TY, 4], [18, TY + 10, 4], 2.6, '#d8352a', { mat: 'gloss', olw: 0.2, r2: 3.4, capCol: '#f6f4ee' }) + line3(C, frontArc31(C, 18, 4, 3.3, TY + 8.6), 0.3, '#a8261e')]);
        items.push([14, 10, PLN(C, TY + 0.05, `<path d="M10 7c3 -2 9 -1 10 2c1 3 -4 4 -7 3c-2 -0.6 -4 -3 -3 -5Z" fill="#d8eef6" opacity="0.6"/>`) + B10(C, { c: [12, TY, 10], w: 10, h: 4, d: 7, col: '#eef4f8', r: 2, op: 0.85, dec: { t: `<rect width="10" height="7" fill="#eef4f8"/><path d="M1 1l3 2l-2 3" stroke="#3a7ac8" stroke-width="0.4" fill="none"/>${rep(4, i => `<rect x="${2 + i * 2}" y="${2 + (i % 2) * 2}" width="1.6" height="1.6" fill="#ffffff"/>`).join('')}` } })]);
        s += items.map(([x, z, sv]) => ({ d: x * C.v[0] + z * C.v[2], s: sv })).sort((a, b) => a.d - b.d).map(o => o.s).join('');
        const dr = C.P([6 + Math.cos(thV(C)) * 2.6, TY + 9.6, -6 + Math.sin(thV(C)) * 2.6]); s += `<circle cx="${f1(dr[0])}" cy="${f1(dr[1])}" r="${f1(0.4 * k)}" fill="#ffffff" opacity="0.8">${at('translate', `0 0;0 ${f1(8 * k)}`, 4, 0, ' keyTimes="0;1" calcMode="spline" keySplines="0.6 0 1 1"')}${an('opacity', '0.8;0.8;0', 4)}</circle>`;
        C.p(-33, 0, -20); C.p(33, 0, 20); C.p(33, 0, -20); C.p(-33, 0, 20); C.p(0, TY + 16, 0);
        return { defs: '', front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-033 TIKI BAMBOO HOME BAR COUNTER (T2): a budget home tiki bar: a plywood box faced with split bamboo poles (one cracked), bamboo corner
    // posts, a varnished dark wood counter top with a fringe of dry grass thatch hanging off the front and sides, a tiki mug, a coconut cup with
    // a paper umbrella and a pineapple at the ends; the back is plain plywood with a shelf of cups. Live: the thatch fringe stirs in a light breeze.
    N.tiki31 = S => { const D = { w: 140, d: 56, act: 'snack', use: { x: 0, z: 54 }, topH: 86, topW: 84, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('t33'), R = rng('tiki31'), BW = 132, BH = 80, BD = 44, TY = 86, BB = '#c8a868';
        let s = shadow(C, 0, 2, 70, 30, 0.4);
        const bamboo = (w, h, crack) => { let f = `<rect width="${w}" height="${h}" fill="#8a6a3a"/>`; const n = Math.floor(w / 4.2);
          rep(n, i => { const x = i * w / n, c = ['#d0b070', '#c8a868', '#bfa060', '#d8b878'][i % 4]; f += `<rect x="${f1(x + 0.15)}" width="${f1(w / n - 0.3)}" height="${h}" rx="1.4" fill="${c}"/><rect x="${f1(x + 0.6)}" width="0.6" height="${h}" fill="#ffffff" opacity="0.25"/>`;
            rep(3, j => { const y = 12 + j * 24 + ((i * 7) % 9); f += `<rect x="${f1(x + 0.15)}" y="${f1(y)}" width="${f1(w / n - 0.3)}" height="1.4" rx="0.6" fill="#8a6a3a" opacity="0.8"/>`; }); });
          if (crack) f += `<path d="M${f1(w * 0.62)} 20l0.6 10l-0.8 8l0.6 12" stroke="#3a2a14" stroke-width="0.6" fill="none"/>`;
          return f + `<rect width="${w}" height="${h}" fill="url(#${id}sh)"/>`; };
        const ply = (w, h) => `<rect width="${w}" height="${h}" fill="#c8a878"/>${rep(6, i => `<path d="M0 ${f1(8 + i * 12)}q${w / 2} ${f1((R() - 0.5) * 3)} ${w} 0" stroke="#a88858" stroke-width="0.4" fill="none" opacity="0.6"/>`).join('')}<rect y="${f1(h * 0.45)}" width="${w}" height="2" fill="#8a6a3a"/>`;
        s += B10(C, { c: [0, 0, 0], w: BW, h: BH, d: BD, col: BB, r: 0.6, dec: { f: bamboo(BW, BH, 1), l: bamboo(BD, BH), r: bamboo(BD, BH), b: ply(BW, BH) } });
        const posts = [[-1, 1], [1, 1], [-1, -1], [1, -1]].map(([a, b]) => ({ d: a * 66 * C.v[0] + b * 22 * C.v[2], s: cyl3(C, [a * 67, 0, b * 23], [a * 67, BH, b * 23], 2.4, '#c8a060', { mat: 'gloss', olw: 0.25 }) + rep(3, j => line3(C, frontArc31(C, a * 67, b * 23, 2.45, 18 + j * 24), 0.7, '#8a6a3a')).join('') }));
        s += posts.filter(p => p.d < 0).map(p => p.s).join('') + posts.filter(p => p.d >= 0).map(p => p.s).join('');
        const topD = `<rect width="140" height="52" fill="#4a2c18"/>` + rep(12, i => `<path d="M0 ${f1(2 + i * 4.2)}q70 ${f1((R() - 0.5) * 2)} 140 ${f1((R() - 0.5) * 1.4)}" stroke="#2e1a0c" stroke-width="0.4" fill="none" opacity="0.7"/>`).join('') + `<circle cx="40" cy="30" r="4" fill="none" stroke="#6a4a2a" stroke-width="0.5" opacity="0.6"/><rect width="140" height="52" fill="url(#${id}vn)"/>`;
        const edgeT = w => `<rect width="${w}" height="5" fill="#3a2212"/><path d="M0 0.6H${w}" stroke="#8a5a32" stroke-width="0.5"/>`;
        s += B10(C, { c: [0, BH, 1], w: 140, h: 5, d: 52, col: '#4a2c18', r: 0.8, dec: { t: topD, f: edgeT(140), b: edgeT(140), l: edgeT(52), r: edgeT(52) } });
        // thatch fringe on the visible sides
        const fringe = (O, U, L, ph) => { let f = ''; rep(Math.floor(L / 1.6), i => { const Q = rng('fr' + ph + i), x = i * 1.6 + Q() * 0.8, len = 9 + Q() * 4, sw = (Q() - 0.5) * 2;
            f += `<path d="M${f1(x)} 0q${f1(sw)} ${f1(len / 2)} ${f1(sw * 1.6)} ${f1(len)}" stroke="${['#d8b868', '#c8a050', '#e0c878', '#b89040'][i % 4]}" stroke-width="${n4(0.6 + Q() * 0.5)}" fill="none" stroke-linecap="round"/>`; });
          return `<g transform="${FR(C, O, U, [0, -1, 0])}"><g>${at('skewX', '0;3;-1;0', 5.4, -ph)}<rect width="${L}" height="2.4" fill="#b89040"/>${f}</g></g>`; };
        let fr = '';
        if (C.v[2] > 0) fr += fringe([-70, BH + 0.4, 27.2], [1, 0, 0], 140, 0);
        if (C.v[2] < 0) fr += fringe([70, BH + 0.4, -25.2], [-1, 0, 0], 140, 1);
        if (C.v[0] > 0) fr += fringe([70.2, BH + 0.4, 27], [0, 0, -1], 52, 2);
        if (C.v[0] < 0) fr += fringe([-70.2, BH + 0.4, -25], [0, 0, 1], 52, 3);
        s += fr;
        // top props at the ends
        const tiki = cyl3(C, [-56, TY - 1, 8], [-56, TY + 9, 8], 3.4, '#6a4a2a', { mat: 'gloss', olw: 0.25, r2: 3, capCol: '#e8943a' }) + VPL(C, [-56, TY + 7, 11.5], `<path d="M-2 1h4M-2.2 3.4h1.4M0.8 3.4h1.4M-1.6 6h3.2" stroke="#2a1a0c" stroke-width="0.6"/><rect x="-1.8" y="5.4" width="3.6" height="1.6" fill="#2a1a0c" opacity="0.6"/>`);
        const coco = sph(C, [52, TY + 2.6, 10], 3.6, '#6a4a2a') + PLN(C, TY + 4.6, `<ellipse rx="3.2" ry="3.2" fill="#f4ece0"/>`, 52, 10) + line3(C, [[52, TY + 4.8, 10], [54, TY + 12, 9]], 0.3, '#d8b060') + `<path d="M${P2(C.P([50, TY + 11.4, 9]))}L${P2(C.P([54, TY + 14.4, 9]))}L${P2(C.P([58, TY + 11.6, 9]))}Z" fill="#e84a6a" stroke="#a82a42" stroke-width="${f1(0.2 * k)}"/>`;
        const pine = (() => { const x = 60, z = -8; return sph(C, [x, TY + 5, z], 4.2, '#c8902a') + rep(6, i => { const a = i * PI / 3; return line3(C, [[x, TY + 8.6, z], [x + Math.cos(a) * 2.6, TY + 14, z + Math.sin(a) * 2.6]], 1.1, '#4a8a3a'); }).join('') + rep(10, i => { const q = C.P([x + (i % 3 - 1) * 2, TY + 2.6 + Math.floor(i / 3) * 1.8, z + 4]); return `<path d="M${f1(q[0] - 0.7 * k)} ${f1(q[1])}l${f1(0.7 * k)} ${f1(-0.7 * k)}l${f1(0.7 * k)} ${f1(0.7 * k)}" stroke="#8a5a1a" stroke-width="${f1(0.25 * k)}" fill="none"/>`; }).join(''); })();
        s += [[-56, 8, tiki], [52, 10, coco], [60, -8, pine]].map(([x, z, sv]) => ({ d: x * C.v[0] + z * C.v[2], s: sv })).sort((a, b) => a.d - b.d).map(o => o.s).join('');
        C.p(-71, 0, -28); C.p(71, 0, 28); C.p(71, 0, -28); C.p(-71, 0, 28); C.p(0, TY + 16, 0);
        const defs = `<defs><linearGradient id="${id}sh" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000000" stop-opacity="0.25"/><stop offset="0.25" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.15"/></linearGradient>`
          + `<linearGradient id="${id}vn" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.14"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // shared bar bits (house4 bar foot w140 d56, act snack, use z 54, topH 86): body box BW x BH x BD, counter slab, foot rail along the front
    const BARD = () => ({ w: 140, d: 56, act: 'snack', use: { x: 0, z: 54 }, topH: 86, topW: 84, build: () => [] });
    const footRail = (C, col, y, z) => cyl3(C, [-62, y, z], [62, y, z], 1.3, col, { mat: 'chrome', olw: 0.2 }) + [-50, 0, 50].map(x => line3(C, [[x, y, z], [x, y - 1, 22.2]], 0.9, col)).join('') + [-62, 62].map(x => sph(C, [x, y, z], 1.5, col)).join('');
    const bottleRow = (w, h, n, R, cols) => rep(n, i => { const x = 4 + i * (w - 8) / (n - 1), c = cols[i % cols.length], bh = 9 + R() * 4, y0 = h; return `<rect x="${f1(x - 1.6)}" y="${f1(y0 - bh)}" width="3.2" height="${f1(bh - 3)}" rx="0.8" fill="${c}"/><rect x="${f1(x - 0.6)}" y="${f1(y0 - bh - 3)}" width="1.2" height="3.4" fill="${c}"/><rect x="${f1(x - 1.2)}" y="${f1(y0 - bh + 2)}" width="0.6" height="${f1(bh - 6)}" fill="#ffffff" opacity="0.3"/>`; }).join('');

    // CLB-053 BACKLIT FROSTED ACRYLIC & CHROME NIGHTCLUB BAR (T3): a bar faced in frosted white acrylic panels on chrome standoffs, lit warm-white
    // from behind with the LED strips glowing softly through, a black quartz counter with a fine sparkle and a chrome edge, a chrome foot rail,
    // three cocktails and a straw cup on top; the bartender side is black with a speed rail of bottles. Live: the backlight breathes slowly and
    // a soft band of light sweeps across the acrylic.
    N.acrybar31 = S => { const D = BARD();
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('a53'), R = rng('acrybar31'), BW = 132, BH = 80, BD = 44, TY = 86;
        let s = shadow(C, 0, 2, 70, 30, 0.4) + PLN(C, 0.1, `<rect x="-70" y="20" width="140" height="14" rx="7" fill="url(#${id}fg)">${an('opacity', '0.6;1;0.6', 5)}</rect>`);
        const acr = (w, h) => `<rect width="${w}" height="${h}" fill="#f4f0ea"/><rect width="${w}" height="${h}" fill="url(#${id}bl)">${an('opacity', '0.75;1;0.75', 5)}</rect>`
          + rep(4, i => `<rect x="2" y="${f1(8 + i * 20)}" width="${w - 4}" height="3" fill="#fff6e0" opacity="0.5" filter="url(#g31b1)"/>`).join('')
          + rep(Math.round(w / 33) - 1, i => `<rect x="${f1((i + 1) * w / Math.round(w / 33) - 0.3)}" width="0.6" height="${h}" fill="#c8c4bc"/>`).join('')
          + rep(Math.round(w / 33), i => [[3, 3], [3, h - 3]].map(([dx, y]) => `<circle cx="${f1(i * w / Math.round(w / 33) + dx)}" cy="${y}" r="1" fill="#d8dce2" stroke="#8a8e96" stroke-width="0.3"/>`).join('') + [[-3, 3], [-3, h - 3]].map(([dx, y]) => `<circle cx="${f1((i + 1) * w / Math.round(w / 33) + dx)}" cy="${y}" r="1" fill="#d8dce2" stroke="#8a8e96" stroke-width="0.3"/>`).join('')).join('')
          + `<rect x="-30" width="24" height="${h}" fill="url(#${id}sw)" transform="skewX(-15)">${an('x', `-30;${w + 30}`, 8)}</rect>`;
        const back = (w, h) => `<rect width="${w}" height="${h}" fill="#141418"/><rect y="${h * 0.38}" width="${w}" height="1.4" fill="#3a3c44"/>${bottleRow(w, h * 0.38, 16, R, ['#3a6a3a', '#8a4a1a', '#d8d4c8', '#5a2a3a', '#c8902a'])}<rect y="${h * 0.7}" width="${w}" height="1" fill="#3a3c44"/>`;
        s += B10(C, { c: [0, 0, 0], w: BW, h: BH, d: BD, col: '#f4f0ea', r: 0.6, dec: { f: acr(BW, BH), l: acr(BD, BH), r: acr(BD, BH), b: back(BW, BH) } });
        if (C.v[2] > 0) s += footRail(C, '#c8ccd2', 8, 26);
        const topD = `<rect width="140" height="52" fill="#141418"/>` + rep(140, () => `<circle cx="${f1(R() * 140)}" cy="${f1(R() * 52)}" r="${n4(0.12 + R() * 0.2)}" fill="#ffffff" opacity="${n4(0.2 + R() * 0.5)}"/>`).join('') + `<rect width="140" height="52" fill="url(#${id}tg)"/>`;
        const edge = w => `<rect width="${w}" height="5" fill="#c8ccd2"/><rect y="0.6" width="${w}" height="0.8" fill="#ffffff" opacity="0.7"/><rect y="3.6" width="${w}" height="1.4" fill="#8a8e96"/>`;
        s += B10(C, { c: [0, BH, 1], w: 140, h: 5, d: 52, col: '#141418', r: 0.6, dec: { t: topD, f: edge(140), b: edge(140), l: edge(52), r: edge(52) } });
        const items = [[-52, 8, coupe(C, -52, TY - 1, 8, '#e8a84a')], [-44, 12, coupe(C, -44, TY - 1, 12, '#d8507a')], [48, 10, coupe(C, 48, TY - 1, 10, '#f2d890')],
          [58, -6, cyl3(C, [58, TY - 1, -6], [58, TY + 6, -6], 2.4, '#e8eef2', { mat: 'gloss', op: 0.5, olw: 0.2, capCol: '#202024' }) + rep(5, i => line3(C, [[57 + i * 0.5, TY + 4, -6], [56.4 + i * 0.7, TY + 11, -6.6 + i * 0.3]], 0.35, ['#e84a6a', '#202024', '#ffb050'][i % 3])).join('')]];
        s += items.map(([x, z, sv]) => ({ d: x * C.v[0] + z * C.v[2], s: sv })).sort((a, b) => a.d - b.d).map(o => o.s).join('');
        C.p(-71, 0, -28); C.p(71, 0, 30); C.p(71, 0, -28); C.p(-71, 0, 30); C.p(0, TY + 12, 0);
        const defs = DEFG + `<defs><radialGradient id="${id}bl" cx="50%" cy="50%" r="65%"><stop offset="0" stop-color="#fffaf0"/><stop offset="0.7" stop-color="#ffefd8"/><stop offset="1" stop-color="#e8dcc8"/></radialGradient>`
          + `<linearGradient id="${id}sw" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>`
          + `<linearGradient id="${id}tg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/></linearGradient>`
          + `<linearGradient id="${id}fg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe8c0" stop-opacity="0.5"/><stop offset="1" stop-color="#ffe8c0" stop-opacity="0"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-073 ILLUMINATED ONYX WET BAR WITH TIERED LED LIQUOR DISPLAY (T4): a bar faced in book-matched honey onyx lit from behind so the stone glows
    // amber with its bands and veins, framed in brushed brass with a brass foot rail, a black marble counter with a brass edge and a small brass bar
    // sink and gooseneck tap; at the back of the counter a three-step lit brass display of liquor bottles glowing from beneath. Live: the onyx glow
    // breathes, the display step lights warm in a slow wave up the tiers.
    N.onyxbar31 = S => { const D = BARD();
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('o73'), R = rng('onyxbar31'), BR = '#c8a050', BW = 132, BH = 80, BD = 44, TY = 86;
        let s = shadow(C, 0, 2, 70, 30, 0.4) + PLN(C, 0.1, `<rect x="-70" y="20" width="140" height="16" rx="8" fill="url(#${id}fg)">${an('opacity', '0.6;1;0.6', 6)}</rect>`);
        const onyx = (w, h, seed) => { const V = rng('onx' + seed); let f = `<rect width="${w}" height="${h}" fill="url(#${id}on)"/><g>${an('opacity', '0.7;1;0.7', 6)}<rect width="${w}" height="${h}" fill="url(#${id}ol)"/></g>`;
          const half = w / 2; rep(10, i => { const y0 = 4 + i * h / 10 + V() * 4, a = V() * 6; const d = `M0 ${f1(y0)}Q${f1(half * 0.5)} ${f1(y0 - a)} ${f1(half)} ${f1(y0 + a * 0.4)}`; f += `<path d="${d}" stroke="${['#fff0c8', '#a8601a', '#ffe0a0'][i % 3]}" stroke-width="${n4(0.4 + V() * 1.6)}" fill="none" opacity="${n4(0.25 + V() * 0.35)}"/><path d="${d}" stroke="${['#fff0c8', '#a8601a', '#ffe0a0'][i % 3]}" stroke-width="${n4(0.4 + V() * 1.6)}" fill="none" opacity="0.3" transform="translate(${w} 0) scale(-1 1)"/>`; });
          return f + `<rect x="${f1(half - 0.3)}" width="0.6" height="${h}" fill="#8a5a1a" opacity="0.5"/><rect width="${w}" height="2.4" fill="${BR}"/><rect y="${h - 3}" width="${w}" height="3" fill="${BR}"/><rect width="2" height="${h}" fill="${BR}"/><rect x="${w - 2}" width="2" height="${h}" fill="${BR}"/>`; };
        const back = (w, h) => `<rect width="${w}" height="${h}" fill="#1a1416"/><rect y="${h * 0.4}" width="${w}" height="1.4" fill="${BR}"/><rect y="${h - 3}" width="${w}" height="3" fill="${BR}"/>${rep(6, i => `<rect x="${f1(6 + i * (w - 12) / 6)}" y="${f1(h * 0.45)}" width="${f1((w - 12) / 6 - 2)}" height="${f1(h * 0.45)}" fill="#120e10" stroke="#3a2a20" stroke-width="0.5"/>`).join('')}`;
        s += B10(C, { c: [0, 0, 0], w: BW, h: BH, d: BD, col: '#e8a850', r: 0.6, dec: { f: onyx(BW, BH, 0), l: onyx(BD, BH, 1), r: onyx(BD, BH, 2), b: back(BW, BH) } });
        if (C.v[2] > 0) s += footRail(C, BR, 8, 26);
        const topD = `<clipPath id="${id}mc"><rect width="140" height="52"/></clipPath><rect width="140" height="52" fill="#141418"/><g clip-path="url(#${id}mc)">` + rep(7, () => { let x = R() * 140, y = 0, d = `M${f1(x)} 0`; rep(5, () => { x += (R() - 0.45) * 22; y += 52 / 4; d += `Q${f1(x + (R() - 0.5) * 12)} ${f1(y - 6)} ${f1(x)} ${f1(y)}`; }); return `<path d="${d}" stroke="#ece8e0" stroke-width="${n4(0.2 + R() * 0.4)}" fill="none" opacity="${n4(0.3 + R() * 0.4)}"/>`; }).join('') + `</g><rect x="96" y="20" width="16" height="10" rx="2" fill="#2a2418" stroke="${BR}" stroke-width="0.8"/><circle cx="104" cy="25" r="1" fill="#141210"/>`;
        const edge = w => `<rect width="${w}" height="5" fill="#141418"/><rect y="3.4" width="${w}" height="1.6" fill="${BR}"/>`;
        s += B10(C, { c: [0, BH, 1], w: 140, h: 5, d: 52, col: '#141418', r: 0.6, dec: { t: topD, f: edge(140), b: edge(140), l: edge(52), r: edge(52) } });
        const tap = line3(C, [[34, TY - 1, -1], [34, TY + 9, -1], [34, TY + 11, 1], [34, TY + 9, 3.4]], 0.8, BR) + cyl3(C, [34, TY - 1, -1], [34, TY, -1], 1.6, BR, { mat: 'metal', olw: 0.15 });
        // tiered lit liquor display at the back
        const tiers = rep(3, j => { const y0 = TY - 1 + j * 7, z0 = -22 + j * 0 , zz = -13 - j * 4.5, wD = 96 - j * 18;
          const step = B10(C, { c: [0, y0, zz - 2.2], w: wD, h: 7, d: 4.6, col: '#1a1416', r: 0.4, dec: { f: `<rect width="${wD}" height="7" fill="#1a1416"/><rect width="${wD}" height="1" fill="${BR}"/><rect y="5.6" width="${wD}" height="1.4" fill="#ffd9a0" opacity="0.4">${an('opacity', '0.2;0.9;0.2', 4.5, -j * 0.6)}</rect>` } });
          const nb = 9 - j * 2, bots = rep(nb, i => { const x = -wD / 2 + 5 + i * (wD - 10) / (nb - 1), c = ['#c8862a', '#3a6a3a', '#e8e4dc', '#8a3a2a', '#d8a838'][(i + j) % 5], h = 9 + ((i * 7 + j * 3) % 5);
            return cyl3(C, [x, y0 + 7, zz - 2], [x, y0 + 7 + h, zz - 2], 1.6, c, { mat: 'gloss', olw: 0.15, op: c === '#e8e4dc' ? 0.7 : 0.92 }) + cyl3(C, [x, y0 + 7 + h, zz - 2], [x, y0 + 10 + h, zz - 2], 0.6, c, { mat: 'gloss', olw: 0.1 }) + cyl3(C, [x, y0 + 10 + h, zz - 2], [x, y0 + 11 + h, zz - 2], 0.7, BR, { mat: 'metal', olw: 0.1 }); }).join('');
          const gl = C.P([0, y0 + 9, zz - 2]); return step + `<ellipse cx="${f1(gl[0])}" cy="${f1(gl[1])}" rx="${f1(wD * 0.5 * k)}" ry="${f1(5 * k)}" fill="#ffd9a0" opacity="0.15" filter="url(#g31b3)">${an('opacity', '0.08;0.3;0.08', 4.5, -j * 0.6)}</ellipse>` + bots; });
        const disp = C.v[2] >= 0 ? tiers.reverse().join('') : tiers.join('');
        s += (C.v[2] >= 0 ? disp + tap + coupe(C, -44, TY - 1, 12, '#e8943a') + coupe(C, -36, TY - 1, 14, '#f2d890') : tap + coupe(C, -44, TY - 1, 12, '#e8943a') + coupe(C, -36, TY - 1, 14, '#f2d890') + disp);
        C.p(-71, 0, -28); C.p(71, 0, 30); C.p(71, 0, -28); C.p(-71, 0, 30); C.p(0, TY + 36, -24);
        const defs = DEFG + `<defs><linearGradient id="${id}on" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6c878"/><stop offset="0.5" stop-color="#e8a040"/><stop offset="1" stop-color="#c87a28"/></linearGradient>`
          + `<radialGradient id="${id}ol" cx="50%" cy="45%" r="60%"><stop offset="0" stop-color="#fff0c8" stop-opacity="0.7"/><stop offset="1" stop-color="#fff0c8" stop-opacity="0"/></radialGradient>`
          + `<linearGradient id="${id}fg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffc870" stop-opacity="0.5"/><stop offset="1" stop-color="#ffc870" stop-opacity="0"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-093 ROBOTIC DUAL-ARM CYBER-BARTENDER & MOLECULAR LEVITATING DRINK BAR (T5): a black lacquer bar faced with vertical brass reeding and a
    // warm under-glow, a black marble counter edged in brass. Behind it a pair of ivory-and-brass articulated robot arms on a lacquered column work
    // the bar: the left arm shakes a brass cocktail shaker, the right pours from a bottle into a coupe. At one end a brass levitation pad holds a
    // sphere of cocktail floating in mid-air with tiny droplets orbiting it. Live: the left arm shakes in bursts, the right tips and pours, the
    // levitating sphere wobbles and bobs, the reeding glows.
    N.robobar31 = S => { const D = BARD();
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('r93'), R = rng('robobar31'), BR = '#c8a050', IV = '#efe8dc', BW = 132, BH = 80, BD = 44, TY = 86;
        let s = shadow(C, 0, 2, 70, 30, 0.4) + PLN(C, 0.1, `<rect x="-70" y="20" width="140" height="16" rx="8" fill="url(#${id}fg)">${an('opacity', '0.6;1;0.6', 4)}</rect>`);
        const reed = (w, h) => `<rect width="${w}" height="${h}" fill="#141216"/>` + rep(Math.floor(w / 3.2), i => `<rect x="${f1(1 + i * 3.2)}" y="4" width="2.2" height="${h - 10}" rx="1.1" fill="url(#${id}rd)"/>`).join('') + `<rect width="${w}" height="3" fill="${BR}"/><rect y="${h - 5}" width="${w}" height="5" fill="#0c0b0d"/><rect y="${h - 5}" width="${w}" height="0.8" fill="${BR}"/>`;
        const back = (w, h) => `<rect width="${w}" height="${h}" fill="#141216"/><rect y="${h * 0.4}" width="${w}" height="1.2" fill="${BR}"/>`;
        s += B10(C, { c: [0, 0, 0], w: BW, h: BH, d: BD, col: '#141216', r: 0.6, dec: { f: reed(BW, BH), l: reed(BD, BH), r: reed(BD, BH), b: back(BW, BH) } });
        const topD = `<clipPath id="${id}mc"><rect width="140" height="52"/></clipPath><rect width="140" height="52" fill="#141418"/><g clip-path="url(#${id}mc)">` + rep(7, () => { let x = R() * 140, y = 0, d = `M${f1(x)} 0`; rep(5, () => { x += (R() - 0.45) * 22; y += 52 / 4; d += `Q${f1(x + (R() - 0.5) * 12)} ${f1(y - 6)} ${f1(x)} ${f1(y)}`; }); return `<path d="${d}" stroke="#ece8e0" stroke-width="${n4(0.2 + R() * 0.4)}" fill="none" opacity="${n4(0.3 + R() * 0.4)}"/>`; }).join('') + `</g>`;
        const edge = w => `<rect width="${w}" height="5" fill="#141418"/><rect y="3.4" width="${w}" height="1.6" fill="${BR}"/>`;
        s += B10(C, { c: [0, BH, 1], w: 140, h: 5, d: 52, col: '#141418', r: 0.6, dec: { t: topD, f: edge(140), b: edge(140), l: edge(52), r: edge(52) } });
        // robot: column + two arms (screen-space groups rotating about the shoulder)
        const col = cyl3(C, [0, TY - 1, -18], [0, TY + 2, -18], 6, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [0, TY + 2, -18], [0, TY + 22, -18], 3.4, '#141216', { mat: 'gloss', olw: 0.25 }) + cyl3(C, [-9, TY + 22, -18], [9, TY + 22, -18], 3, IV, { mat: 'gloss', olw: 0.25 }) + sph(C, [0, TY + 26, -18], 3, '#141216') + PLN(C, TY + 22.1, `<circle r="1.4" fill="#ffd28a"/>`, 0, -18);
        const seg = (a, b, r, c) => cyl3(C, a, b, r, c, { mat: 'gloss', olw: 0.25 });
        const SL = [-9, TY + 22, -18], EL = [-20, TY + 14, -8], HL = [-24, TY + 22, -2];
        const armL = seg(SL, EL, 2.2, IV) + sph(C, EL, 2.4, BR) + seg(EL, HL, 1.8, IV) + sph(C, HL, 1.8, BR) + cyl3(C, [HL[0], HL[1] - 4, HL[2]], [HL[0], HL[1] + 5, HL[2]], 2.2, '#d8b060', { mat: 'metal', olw: 0.2, r2: 2.6 }) + cyl3(C, [HL[0], HL[1] + 5, HL[2]], [HL[0], HL[1] + 7.4, HL[2]], 2.6, '#d8b060', { mat: 'metal', olw: 0.2, r2: 1.2 });
        const sp = C.P(SL), elp = C.P(EL);
        s += col;
        s += `<g>${at('translate', `0 0;0 ${f1(-1.6 * k)};0 ${f1(1.2 * k)};0 ${f1(-1.6 * k)};0 ${f1(1.2 * k)};0 0;0 0`, 2.4, 0, ' keyTimes="0;0.08;0.16;0.24;0.32;0.4;1"')}${armL}</g>`;
        const SR = [9, TY + 22, -18], ER = [20, TY + 16, -8], HR = [19, TY + 20, 0];
        const bot = (() => { const b0 = [HR[0] - 1, HR[1] - 1, HR[2]], dir = nrm([-0.5, -0.5, 0.4]), at3 = t => add(b0, mul(dir, t)); return cyl3(C, at3(-8), at3(0), 2, '#3a6a3a', { mat: 'gloss', olw: 0.2 }) + cyl3(C, at3(0), at3(3), 0.7, '#3a6a3a', { mat: 'gloss', olw: 0.1 }); })();
        const armR = seg(SR, ER, 2.2, IV) + sph(C, ER, 2.4, BR) + seg(ER, HR, 1.8, IV) + sph(C, HR, 1.8, BR) + bot;
        const hp = C.P(SR); s += `<g>${at('rotate', `0 ${P2(hp)};-6 ${P2(hp)};-6 ${P2(hp)};0 ${P2(hp)}`, 5, 0, ' keyTimes="0;0.25;0.7;1"')}${armR}</g>`;
        const pour0 = C.P([16, TY + 15, 2]), pour1 = C.P([15, TY + 6, 4]); s += `<path d="M${P2(pour0)}L${P2(pour1)}" stroke="#e8a84a" stroke-width="${f1(0.5 * k)}" opacity="0">${an('opacity', '0;0;0.9;0.9;0;0', 5, 0, KT('0;0.28;0.32;0.66;0.7;1'))}</path>`;
        s += coupe(C, 15, TY - 1, 4, '#e8a84a');
        // levitation pad + floating sphere
        const LX = -50, LZ = 10; s += cyl3(C, [LX, TY - 1, LZ], [LX, TY + 1, LZ], 5, BR, { mat: 'metal', olw: 0.2, capCol: '#2a2418' }) + PLN(C, TY + 1.05, `<circle r="3.4" fill="url(#${id}lv)">${an('opacity', '0.6;1;0.6', 1.6)}</circle>`, LX, LZ);
        const sq = C.P([LX, TY + 10, LZ]), r = 3.4 * k;
        s += `<g>${at('translate', `0 0;0 ${f1(-1.8 * k)};0 0`, 2.2, 0, SPL(2))}<ellipse cx="${f1(sq[0])}" cy="${f1(sq[1])}" rx="${f1(r)}" ry="${f1(r)}" fill="url(#${id}sp)">${an('rx', `${f1(r)};${f1(r * 1.06)};${f1(r * 0.96)};${f1(r)}`, 1.1)}${an('ry', `${f1(r)};${f1(r * 0.95)};${f1(r * 1.05)};${f1(r)}`, 1.1)}</ellipse><ellipse cx="${f1(sq[0] - r * 0.35)}" cy="${f1(sq[1] - r * 0.4)}" rx="${f1(r * 0.3)}" ry="${f1(r * 0.18)}" fill="#ffffff" opacity="0.8"/>`
          + rep(5, i => { const rx = (6 + i) * k, ry = rx * 0.3, d = n4(1.6 + i * 0.4); return `<circle r="${f1(0.45 * k)}" fill="#f0b050"><animateMotion dur="${d}s" begin="${n4(-i * 0.3)}s" repeatCount="indefinite" path="M${f1(sq[0] - rx)} ${f1(sq[1])}A${f1(rx)} ${f1(ry)} 0 1 0 ${f1(sq[0] + rx)} ${f1(sq[1])}A${f1(rx)} ${f1(ry)} 0 1 0 ${f1(sq[0] - rx)} ${f1(sq[1])}"/></circle>`; }).join('') + `</g>`;
        C.p(-71, 0, -28); C.p(71, 0, 30); C.p(71, 0, -28); C.p(-71, 0, 30); C.p(0, TY + 30, -18); C.p(-28, TY + 30, -2);
        const defs = DEFG + `<defs><linearGradient id="${id}rd" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6a4a1c"/><stop offset="0.45" stop-color="#e8c878"/><stop offset="1" stop-color="#8a6428"/></linearGradient>`
          + `<linearGradient id="${id}fg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffc870" stop-opacity="0.45"/><stop offset="1" stop-color="#ffc870" stop-opacity="0"/></linearGradient>`
          + `<radialGradient id="${id}lv"><stop offset="0" stop-color="#ffe2a8"/><stop offset="1" stop-color="#ffb060" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}sp" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#fff0c8"/><stop offset="0.5" stop-color="#f0a040"/><stop offset="1" stop-color="#a85a18"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-014 SMALL CARDBOARD BREAKDANCE SQUARE FOR PET (T1): a pet-sized breakdance mat cut from a flattened box: two cardboard panels taped
    // together with silver duct tape, a printed arrow and a fold crease, a scuffed spin circle worn into the middle, one corner curling up, and a
    // chewed rubber squeaky ball and a little knotted rope toy on it. Live: the ball rocks and the curled corner lifts in a draft.
    N.petmat31 = S => { const D = { w: 36, d: 28, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('p14'), R = rng('petmat31');
        let s = shadow(C, 0, 0, 18, 14, 0.2);
        let m = `<rect x="-17" y="-13" width="34" height="26" fill="#c8a06a"/><rect x="-17" y="-13" width="17" height="26" fill="#bf9862"/>` + rep(12, i => `<path d="M${f1(-17 + i * 2.9)} -13V13" stroke="#b08a58" stroke-width="0.2" opacity="0.5"/>`).join('')
          + `<path d="M-12 -8l4 -3l4 3h-2v4h-4v-4Z" fill="#3a3a3a" opacity="0.35"/><path d="M6 6h7M6 8h5" stroke="#3a3a3a" stroke-width="0.6" opacity="0.3"/><path d="M-17 4H17" stroke="#9a7a48" stroke-width="0.4" opacity="0.6"/>`
          + `<circle r="7" fill="#7a5a34" opacity="0.18"/><circle r="4.4" fill="none" stroke="#6a4a28" stroke-width="1.6" opacity="0.18"/>` + rep(10, () => { const a = R() * 2 * PI, r = 3 + R() * 4; return `<path d="M${f1(Math.cos(a) * r)} ${f1(Math.sin(a) * r)}a${f1(r)} ${f1(r)} 0 0 1 ${f1(-Math.sin(a) * 2)} ${f1(Math.cos(a) * 2)}" stroke="#5a3a1a" stroke-width="0.3" fill="none" opacity="0.4"/>`; }).join('')
          + `<rect x="-1.4" y="-13" width="2.8" height="26" fill="#b8bcc4"/>${rep(8, i => `<path d="M-1.2 ${f1(-12 + i * 3.2)}l2.4 0.6" stroke="#ffffff" stroke-width="0.25" opacity="0.6"/>`).join('')}<rect x="-17" y="-13" width="34" height="2.2" fill="#b8bcc4" opacity="0.9"/>`;
        s += PLN(C, 0.15, m);
        const cn = C.P([17, 0.2, 13]); s += `<g transform="translate(${P2(cn)}) scale(${n4(k)})"><path d="M0 0l-5 0.4l4.6 -4Z" fill="#d8b07a" stroke="#9a7a48" stroke-width="0.25">${an('d', 'M0 0l-5 0.4l4.6 -4Z;M0 0l-5 0.4l4 -5.4Z;M0 0l-5 0.4l4.6 -4Z', 3.4)}</path></g>`;
        const bp = C.P([6, 0, -4]), bc = C.P([6, 2.2, -4]); s += `<g>${at('rotate', `-8 ${P2(bp)};8 ${P2(bp)};-8 ${P2(bp)}`, 2.2, 0, SPL(2))}${sph(C, [6, 2.2, -4], 2.2, '#e8503a')}<path d="M${f1(bc[0] - 1 * k)} ${f1(bc[1] - 0.6 * k)}l${f1(0.8 * k)} ${f1(0.3 * k)}M${f1(bc[0] + 0.4 * k)} ${f1(bc[1] + 0.8 * k)}l${f1(0.8 * k)} ${f1(-0.2 * k)}" stroke="#a82a1a" stroke-width="${f1(0.25 * k)}"/></g>`;
        s += line3(C, [[-10, 0.8, 5], [-6, 1, 7], [-2, 0.8, 6]], 1.6, '#e8dcc0') + line3(C, [[-10, 0.8, 5], [-6, 1, 7], [-2, 0.8, 6]], 0.5, '#c8402e', 'stroke-dasharray="1 1"') + sph(C, [-10.6, 1.2, 4.8], 1.4, '#d8ccb0') + sph(C, [-1.4, 1.2, 6], 1.4, '#d8ccb0');
        C.p(-18, 0, -14); C.p(18, 0, 14); C.p(18, 0, -14); C.p(-18, 0, 14); C.p(6, 5, -4);
        return { defs: '', front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-034 MINI LIGHT-UP DISCO PODIUM & PET SHADES (T2): a low pet-sized light-up disco podium: a black frame with silver edging and a grid of
    // frosted squares lit by cheap colour LEDs, two small step stools at the ends for the performers, a mini clip-on spotlight, and a pair of
    // little star-shaped pet sunglasses left on the edge. Live: the squares flash in a chasing pattern.
    N.petpod31 = S => { const D = { w: 99, d: 40, act: 'perform', seats: [{ x: -22.5, z: 0, h: 10.8, k: 'perform' }, { x: 22.5, z: 0, h: 10.8, k: 'perform' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('p34'), R = rng('petpod31'), PW = 92, PD = 34, PH = 9.6, CC = ['#ff6ab8', '#ffd050', '#7ad0ff', '#a070ff', '#ff9a50', '#7dff8a'];
        let s = shadow(C, 0, 0, 48, 19, 0.35);
        const side = w => `<rect width="${w}" height="${PH}" fill="#16161a"/><rect width="${w}" height="1" fill="#c8ccd2"/><rect y="${PH - 1.2}" width="${w}" height="1.2" fill="#2a2a30"/>${rep(Math.floor(w / 6), i => `<circle cx="${f1(3 + i * 6)}" cy="${f1(PH / 2)}" r="0.7" fill="${CC[i % 6]}">${an('opacity', '1;0.3;1', 1.2, -i * 0.2)}</circle>`).join('')}`;
        const NC = 12, NR = 5, cw = (PW - 4) / NC, ch = (PD - 4) / NR;
        let top = `<rect width="${PW}" height="${PD}" fill="#16161a"/><rect x="0.4" y="0.4" width="${PW - 0.8}" height="${PD - 0.8}" fill="none" stroke="#c8ccd2" stroke-width="0.8"/>`;
        rep(NR, j => rep(NC, i => { const c = CC[(i + j * 2) % 6], T = 2.4, b = -((i + j) % 6) * T / 6;
          top += `<rect x="${f1(2 + i * cw + 0.3)}" y="${f1(2 + j * ch + 0.3)}" width="${f1(cw - 0.6)}" height="${f1(ch - 0.6)}" rx="0.4" fill="#f0eef4" opacity="0.5"/><rect x="${f1(2 + i * cw + 0.3)}" y="${f1(2 + j * ch + 0.3)}" width="${f1(cw - 0.6)}" height="${f1(ch - 0.6)}" rx="0.4" fill="${c}" opacity="0.2">${an('opacity', '0.15;0.95;0.15;0.15', T, b, KT('0;0.12;0.4;1'))}</rect>`; }));
        s += B10(C, { c: [0, 0, 0], w: PW, h: PH, d: PD, col: '#16161a', r: 0.8, dec: { t: top, f: side(PW), b: side(PW), l: side(PD), r: side(PD) } });
        const pc = C.P([0, PH, 0]); s += `<ellipse cx="${f1(pc[0])}" cy="${f1(pc[1])}" rx="${f1(46 * k)}" ry="${f1(18 * k)}" fill="#ff9ad8" opacity="0.18" filter="url(#g31b3)">${an('fill', CC.concat(CC[0]).join(';'), 6)}</ellipse>`;
        const shades = (() => { const q = C.P([30, PH + 0.3, 11]), st = (cx) => `<path d="M${cx} -2.2l0.7 1.4 1.6 0.2-1.1 1.1 0.3 1.6-1.5-0.8-1.5 0.8 0.3-1.6-1.1-1.1 1.6-0.2z" fill="#1a1a20" stroke="#ff6ab8" stroke-width="0.35"/>`;
          return `<g transform="translate(${P2(q)}) scale(${n4(k)}) rotate(-12)">${st(-2.6)}${st(2.6)}<path d="M-0.8 -0.4h1.6" stroke="#ff6ab8" stroke-width="0.4"/><path d="M-4.6 -0.6l-2.2 -0.8M4.6 -0.6l2.2 -0.8" stroke="#1a1a20" stroke-width="0.35"/></g>`; })();
        const spot = cyl3(C, [-44, PH, -15], [-44, PH + 6, -15], 0.4, '#2a2a30', { olw: 0.1 }) + cyl3(C, [-44, PH + 6, -15], [-41, PH + 8, -13], 1.8, '#1a1a20', { olw: 0.15, capCol: '#fff6d8' });
        const sp = C.P([-41, PH + 8, -13]), tgt = C.P([-22, PH, 0]); s += spot + `<path d="M${P2(sp)}L${f1(tgt[0] - 7 * k)} ${f1(tgt[1])}L${f1(tgt[0] + 7 * k)} ${f1(tgt[1])}Z" fill="#fff6d8" opacity="0.12" filter="url(#g31b1)"/>` + shades;
        C.p(-49, 0, -20); C.p(49, 0, 20); C.p(49, 0, -20); C.p(-49, 0, 20); C.p(-44, PH + 10, -15);
        return { defs: DEFG, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-054 TINY TURNTABLE SCRATCH-PAD & PET HEADPHONE BOOTH (T3): a pet-sized DJ booth in white lacquer and birch plywood: on top a cat scratch
    // pad made like a turntable (a corrugated cardboard 'record' you can scratch, on a white deck with a little tonearm), a tiny two-knob mixer
    // and a felt toy 'record', and a pair of small padded pet headphones hanging on a hook at the side. Live: the scratch record turns slowly and
    // the mixer LED blinks.
    N.petdj31 = S => { const D = { w: 55, d: 28, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('p54'), R = rng('petdj31'), BW = 52, BH = 13, BD = 24;
        let s = shadow(C, 0, 0, 27, 14, 0.3);
        const ply = (w, h) => `<rect width="${w}" height="${h}" fill="#f4f2ee"/><rect y="${h - 2}" width="${w}" height="2" fill="#e0c89a"/>${rep(3, i => `<rect y="${f1(h - 2 + i * 0.6)}" width="${w}" height="0.25" fill="#b8a070"/>`).join('')}`;
        const top = `<rect width="${BW}" height="${BD}" fill="#e8d4a8"/>${rep(8, i => `<path d="M0 ${f1(1.5 + i * 3)}q${BW / 2} ${f1((R() - 0.5) * 1.4)} ${BW} 0" stroke="#c8ae7a" stroke-width="0.3" fill="none" opacity="0.6"/>`).join('')}`;
        s += B10(C, { c: [0, 0, 0], w: BW, h: BH, d: BD, col: '#f4f2ee', r: 1, dec: { f: ply(BW, BH), b: ply(BW, BH), l: ply(BD, BH), r: ply(BD, BH), t: top } });
        // turntable deck + corrugated scratch record
        s += B10(C, { c: [-10, BH, 0.5], w: 26, h: 2, d: 20, col: '#f8f8f6', r: 1 });
        const rec = `<g>${at('rotate', '0;360', 9)}<circle r="8.4" fill="#c89a5a"/>${rep(9, i => `<circle r="${f1(8 - i * 0.8)}" fill="none" stroke="#9a6e3a" stroke-width="0.35"/>`).join('')}${rep(14, () => { const a = R() * 2 * PI, r = 2 + R() * 6; return `<path d="M${f1(Math.cos(a) * r)} ${f1(Math.sin(a) * r)}l${f1((R() - 0.5) * 2)} ${f1((R() - 0.5) * 2)}" stroke="#7a4e22" stroke-width="0.4" opacity="0.7"/>`; }).join('')}<circle r="2.4" fill="#e84a6a"/><circle r="0.5" fill="#2a2a2e"/><path d="M0 -2.2V-8" stroke="#ffffff" stroke-width="0.4" opacity="0.4"/></g>`;
        s += PLN(C, BH + 2.05, rec, -11, 0.5);
        s += line3(C, [[1, BH + 3.4, -7], [-1, BH + 3, 2], [-4, BH + 2.6, 4]], 0.5, '#c8ccd2') + cyl3(C, [1, BH + 2, -7], [1, BH + 3.6, -7], 1.2, '#c8ccd2', { mat: 'metal', olw: 0.1 });
        // mixer
        s += B10(C, { c: [12, BH, 0], w: 12, h: 2.6, d: 16, col: '#2a2a30', r: 0.8, dec: { t: `<rect width="12" height="16" fill="#2a2a30"/><circle cx="3.6" cy="4" r="1.6" fill="#e8e6e0"/><circle cx="8.4" cy="4" r="1.6" fill="#e8e6e0"/><rect x="2" y="10" width="8" height="1.2" rx="0.6" fill="#0c0c0e"/><rect x="5" y="9.2" width="2" height="2.8" rx="0.4" fill="#f4f2ee"/><circle cx="10" cy="13.8" r="0.7" fill="#7dff8a">${an('opacity', '1;0.2;1', 0.9)}</circle>` } });
        s += PLN(C, BH + 0.05, `<circle r="3.4" fill="#5a3aa8"/><circle r="1.2" fill="#ffd050"/><circle r="0.3" fill="#2a2a2e"/>`, 21, 7);
        // headphones on the side hook
        const hx = BW / 2 + 0.6; s += cyl3(C, [hx - 0.6, 9, 0], [hx + 1.8, 9, 0], 0.35, '#c8ccd2', { mat: 'metal', olw: 0.1 }) + line3(C, rep(9, i => { const a = PI * i / 8; return [hx + 1.8, 7.8 + Math.sin(a) * 2.2, -Math.cos(a) * 3.6]; }), 0.8, '#e8e4dc')
          + cyl3(C, [hx + 1.2, 6.4, -3.8], [hx + 2.6, 6.4, -3.8], 1.8, '#ff9ab8', { olw: 0.15, capCol: '#f4f2ee' }) + cyl3(C, [hx + 1.2, 6.4, 3.8], [hx + 2.6, 6.4, 3.8], 1.8, '#ff9ab8', { olw: 0.15, capCol: '#f4f2ee' }) + line3(C, [[hx + 1.8, 9.6, -3.4], [hx + 1.9, 7.8, -3.8]], 0.5, '#e8e4dc') + line3(C, [[hx + 1.8, 9.6, 3.4], [hx + 1.9, 7.8, 3.8]], 0.5, '#e8e4dc');
        C.p(-28, 0, -14); C.p(28, 0, 14); C.p(28, 0, -14); C.p(-28, 0, 14); C.p(0, BH + 5, 0); C.p(hx + 4, 10, 0);
        return { defs: '', front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-074 VIP VELVET PET LOUNGE WITH MINI MOCKTAIL DISPENSER (T4): a round button-tufted burgundy velvet lounge pouf with brass piping and
    // turned brass feet and a low curved bolster at the back, beside it a little brass stand holding a glass mocktail dispenser with a brass tap
    // dripping into a small brass pet bowl. Still a seat. Live: a drop falls from the tap into the bowl with a ripple, a soft sheen moves on the
    // velvet.
    N.petlounge31 = S => { const D = { w: 70, d: 70, round: 1, act: 'sit', seats: [{ x: 0, z: 0, h: 36, k: 'sit' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('l74'), R = rng('petlounge31'), VEL = '#6a1a2a', BR = '#c8a050', SY = 36, th = thV(C);
        let s = shadow(C, 0, 0, 30, 30, 0.4);
        const feet = rep(4, i => { const a = i * PI / 2 + PI / 4, x = Math.cos(a) * 21, z = Math.sin(a) * 21; return { d: x * C.v[0] + z * C.v[2], s: cyl3(C, [x, 0, z], [x, 6, z], 1.4, BR, { mat: 'metal', olw: 0.15, r2: 2.4 }) }; });
        s += feet.filter(f => f.d < 0).map(f => f.s).join('');
        // dispenser stand (behind or in front by view)
        const DX = 24, DZ = -22;
        const disp = cyl3(C, [DX, 0, DZ], [DX, 1, DZ], 6, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [DX, 1, DZ], [DX, 26, DZ], 0.9, BR, { mat: 'metal', olw: 0.15 }) + cyl3(C, [DX, 26, DZ], [DX, 27, DZ], 5.4, BR, { mat: 'metal', olw: 0.2 })
          + cyl3(C, [DX, 27, DZ], [DX, 39, DZ], 4.4, '#f4eef0', { mat: 'gloss', op: 0.35, olw: 0.25, capCol: BR }) + cyl3(C, [DX, 27.4, DZ], [DX, 34, DZ], 4.2, '#e86a7a', { op: 0.65, olw: 0, noCap: 1 })
          + rep(4, i => sph(C, [DX + (i - 1.5) * 1.6, 31 + (i % 2) * 2, DZ + 1.5], 0.9, ['#f0b040', '#d8304a', '#f4e8c8', '#f0b040'][i])).join('')
          + cyl3(C, [DX, 39, DZ], [DX, 41, DZ], 2.2, BR, { mat: 'metal', olw: 0.15 }) + line3(C, [[DX, 29, DZ + 4], [DX, 29, DZ + 6.4], [DX, 28, DZ + 6.6]], 0.7, BR)
          + cyl3(C, [DX, 0, DZ + 7], [DX, 1.6, DZ + 7], 3.4, BR, { mat: 'metal', olw: 0.2, r2: 4, capCol: '#e86a7a' });
        const dt = C.P([DX, 27.6, DZ + 6.6]), db = C.P([DX, 1.8, DZ + 7]); const drip = `<circle cx="${f1(dt[0])}" cy="${f1(dt[1])}" r="${f1(0.45 * k)}" fill="#e86a7a">${at('translate', `0 0;0 0;0 ${f1(db[1] - dt[1])}`, 2.6, 0, ' keyTimes="0;0.6;1" calcMode="spline" keySplines="0 0 1 1;0.6 0 1 1"')}${an('opacity', '1;1;1;0', 2.6, 0, KT('0;0.6;0.98;1'))}</circle>`
          + PLN(C, 1.7, `<ellipse rx="1" ry="1" fill="none" stroke="#fff0f0" stroke-width="0.3" opacity="0">${an('rx', '0.5;0.5;3.4', 2.6, 0, KT('0;0.97;1'))}${an('ry', '0.5;0.5;3.4', 2.6, 0, KT('0;0.97;1'))}${an('opacity', '0;0;0.8;0', 2.6, 0, KT('0;0.96;0.97;1'))}</ellipse>`, DX, DZ + 7);
        const dispD = DX * C.v[0] + DZ * C.v[2];
        // pouf
        const tuft = r => { let t = `<circle r="${r}" fill="${VEL}"/>`; const pts = [[0, 0]]; rep(6, i => { const a = i * PI / 3; pts.push([Math.cos(a) * 11, Math.sin(a) * 11]); }); rep(10, i => { const a = i * PI / 5 + 0.3; pts.push([Math.cos(a) * 20, Math.sin(a) * 20]); });
          pts.forEach(([x, y]) => { t += `<circle cx="${f1(x)}" cy="${f1(y)}" r="4.6" fill="url(#${id}pf)"/>`; });
          pts.forEach(([x, y], i) => pts.forEach(([x2, y2], j) => { if (j > i && Math.hypot(x2 - x, y2 - y) < 12.5) t += `<path d="M${f1(x)} ${f1(y)}L${f1(x2)} ${f1(y2)}" stroke="#3a0a14" stroke-width="0.4" opacity="0.5"/>`; }));
          pts.forEach(([x, y]) => { t += `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.9" fill="${BR}"/>`; });
          return t + `<circle r="${n4(r - 0.8)}" fill="none" stroke="${BR}" stroke-width="0.8"/><circle r="${r}" fill="url(#${id}sh)"/><clipPath id="${id}cc"><circle r="${r}"/></clipPath><g clip-path="url(#${id}cc)"><rect x="${-r}" y="${-r}" width="10" height="${2 * r}" fill="url(#${id}sw)" transform="skewX(-25)">${an('x', `${-r - 10};${r + 10}`, 7)}</rect></g>`; };
        const pouf = cyl3(C, [0, 6, 0], [0, SY, 0], 27, VEL, { mat: 'matte', olw: 0.3, r2: 28, cap: tuft }) + line3(C, frontArc(C, 28.1, SY - 0.5, 30), 0.9, BR) + line3(C, frontArc(C, 27.1, 6.5, 30), 0.9, BR)
          + rep(12, i => { const a = th - 1.4 + i * 2.8 / 11; return line3(C, [[Math.cos(a) * 27.2, 8, Math.sin(a) * 27.2], [Math.cos(a) * 28.1, SY - 2, Math.sin(a) * 28.1]], 0.5, '#3a0a14', 'opacity="0.35"'); }).join('');
        const bolsterP = rep(17, i => { const a = PI + 0.4 + i * (PI - 0.8) / 16; return [Math.cos(a) * 23, SY + 4, Math.sin(a) * 23]; });
        const bolster = line3(C, bolsterP, 9, '#5a1222') + line3(C, bolsterP.map(p => [p[0], p[1] + 1.6, p[2]]), 5, VEL) + line3(C, bolsterP.map(p => [p[0], p[1] + 3, p[2]]), 1.4, '#8a3448', 'opacity="0.6"');
        const bolsterBack = th > 0 && th < PI;
        s += (dispD < 0 ? disp + drip : '') + (bolsterBack ? bolster : '') + pouf + (bolsterBack ? '' : bolster) + feet.filter(f => f.d >= 0).map(f => f.s).join('') + (dispD >= 0 ? disp + drip : '');
        C.p(-35, 0, -35); C.p(35, 0, 35); C.p(35, 0, -35); C.p(-35, 0, 35); C.p(DX, 42, DZ); C.p(0, SY + 10, -23);
        const defs = `<defs><radialGradient id="${id}pf" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#9a3448"/><stop offset="0.7" stop-color="${VEL}"/><stop offset="1" stop-color="#4a0e1c"/></radialGradient>`
          + `<radialGradient id="${id}sh" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="0.7" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.25"/></radialGradient>`
          + `<linearGradient id="${id}sw" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffd0d8" stop-opacity="0"/><stop offset="0.5" stop-color="#ffd0d8" stop-opacity="0.18"/><stop offset="1" stop-color="#ffd0d8" stop-opacity="0"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-094 FLOATING HOLO-IDOL STAGE WITH BACKUP LASER CLONES FOR PET (T5): a pet-sized walnut stage with a brass rim hovering on magnets over a
    // black lacquer base, warm footlights along the front edge and two brass arcs at the back carrying little spot lamps; on it a warm gold
    // hologram of a dancing pet with two fainter rose and amber 'clones' copying its moves a beat behind. Two pets can perform here. Live: the
    // stage hovers, the idol and its clones dance out of step, footlights chase.
    N.petholo31 = S => { const D = { w: 99, d: 40, act: 'perform', seats: [{ x: -22.5, z: 0, h: 10.8, k: 'perform' }, { x: 22.5, z: 0, h: 10.8, k: 'perform' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('h94'), R = rng('petholo31'), BR = '#c8a050', WAL = '#5a3420', PW = 92, PD = 34, TY = 10.8;
        let s = shadow(C, 0, 0, 48, 19, 0.4);
        s += B10(C, { c: [0, 0, 0], w: PW - 6, h: 3.6, d: PD - 6, col: '#141216', r: 1, dec: { f: `<rect width="${PW - 6}" height="3.6" fill="#141216"/><rect y="3" width="${PW - 6}" height="0.6" fill="${BR}"/>` } });
        const gl = C.P([0, 4.6, 0]); s += `<ellipse cx="${f1(gl[0])}" cy="${f1(gl[1])}" rx="${f1(40 * k)}" ry="${f1(10 * k)}" fill="#ffd28a" opacity="0.4" filter="url(#g31b3)">${an('opacity', '0.25;0.55;0.25', 2.6)}</ellipse>`;
        const topD = `<rect width="${PW}" height="${PD}" fill="${WAL}"/>${rep(10, i => `<path d="M0 ${f1(1.6 + i * 3.4)}q${PW / 2} ${f1((R() - 0.5) * 1.6)} ${PW} 0" stroke="#3e2210" stroke-width="0.3" fill="none" opacity="0.6"/>`).join('')}<rect x="0.5" y="0.5" width="${PW - 1}" height="${PD - 1}" fill="none" stroke="${BR}" stroke-width="0.9"/>`;
        const front = `<rect width="${PW}" height="4.8" fill="#2a1a10"/><rect width="${PW}" height="0.8" fill="${BR}"/>` + rep(15, i => `<circle cx="${f1(3 + i * (PW - 6) / 14)}" cy="2.8" r="0.8" fill="#ffd28a">${an('opacity', '1;0.25;1', 1.8, -i * 0.12)}</circle>`).join('');
        const plat = B10(C, { c: [0, 6, 0], w: PW, h: 4.8, d: PD, col: WAL, r: 0.8, dec: { t: topD, f: front, b: `<rect width="${PW}" height="4.8" fill="#2a1a10"/>`, l: `<rect width="${PD}" height="4.8" fill="#2a1a10"/>`, r: `<rect width="${PD}" height="4.8" fill="#2a1a10"/>` } });
        // brass arcs with lamps at the back
        const arc = (x0) => { const P = rep(13, i => { const a = PI * i / 12; return [x0 + Math.cos(a) * 12, TY + Math.sin(a) * 26, -15]; }); return line3(C, P, 1, BR) + [3, 6, 9].map(i => { const q = P[i]; return cyl3(C, q, [q[0] * 0.96, q[1] - 2, -12], 1.2, '#1a1612', { olw: 0.12, capCol: '#ffe8b8' }); }).join(''); };
        const arcs = arc(-28) + arc(28);
        // hologram pet + clones
        const pet = (dx, col, op, b) => `<g opacity="${op}"><g>${at('translate', `0 0;0 ${f1(-3 * k)};0 0;0 0`, 1.2, -b, ' keyTimes="0;0.35;0.7;1"')}<g>${at('rotate', '-6;6;-6', 2.4, -b, SPL(2))}<path d="M-6 0c-1 -4 0 -8 4 -9.5l-1 -4l3 2.6c1 -0.3 2 -0.3 3 0l3 -2.6l-1 4c4 1.5 5 5.5 4 9.5c-1 1.4 -3 1 -4 0l-1 -2h-4l-1 2c-1 1 -3 1.4 -5 0Z" fill="${col}" opacity="0.6"/><path d="M-6 0c-1 -4 0 -8 4 -9.5l-1 -4l3 2.6c1 -0.3 2 -0.3 3 0l3 -2.6l-1 4c4 1.5 5 5.5 4 9.5" stroke="#fff6d8" stroke-width="0.5" fill="none"/><circle cx="-1.6" cy="-6" r="0.7" fill="#fff6d8"/><circle cx="2.6" cy="-6" r="0.7" fill="#fff6d8"/><path d="M8 -4q4 -3 3 -8" stroke="${col}" stroke-width="1.4" fill="none" stroke-linecap="round">${an('d', 'M8 -4q4 -3 3 -8;M8 -4q5 0 6 -6;M8 -4q4 -3 3 -8', 1.2, -b)}</path>${rep(5, j => `<rect x="-7" y="${-14 + j * 2.8}" width="15" height="0.5" fill="#ffffff" opacity="0.25"/>`).join('')}</g></g></g>`;
        const hp = C.P([0, TY, -4]); const holo = `<path d="M${f1(hp[0] - 2 * k)} ${f1(hp[1])}L${f1(hp[0] - 10 * k)} ${f1(hp[1] - 22 * k)}L${f1(hp[0] + 10 * k)} ${f1(hp[1] - 22 * k)}L${f1(hp[0] + 2 * k)} ${f1(hp[1])}Z" fill="url(#${id}bm)" opacity="0.4"/>`
          + [[-16, '#ffa8b8', 0.45, 0.3], [16, '#ffb860', 0.45, 0.6], [0, '#ffd890', 0.95, 0]].map(([dx, c, op, b]) => { const q = C.P([dx, TY, -4]); return `<g transform="translate(${P2(q)}) scale(${n4(k * (dx ? 0.8 : 1))})">${pet(0, c, op, b)}</g>`; }).join('');
        s += `<g>${at('translate', `0 0;0 ${f1(-1.6 * k)};0 0`, 3.2, 0, SPL(2))}${C.v[2] >= 0 ? arcs + plat + holo : plat + holo + arcs}</g>`;
        C.p(-49, 0, -20); C.p(49, 0, 20); C.p(49, 0, -20); C.p(-49, 0, 20); C.p(-28, TY + 28, -15); C.p(28, TY + 28, -15); C.p(0, TY + 24, -4);
        const defs = DEFG + `<defs><linearGradient id="${id}bm" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.6"/><stop offset="1" stop-color="#ffe2a8" stop-opacity="0"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-016 TORN VINYL DINER BENCH AGAINST THE WALL (T1): a two-seat diner booth bench: cracked oxblood vinyl seat and channel-stitched tall back,
    // a dented chrome edge strip and a scuffed chrome kick plate, a long split in the seat with yellow foam bulging out, an X of silver duct tape
    // over another tear, a split seam on the back, faded wear patches where everyone sits, and a wad of gum stuck under the front edge. Still
    // seats two. Live: the loose flap of torn vinyl lifts and settles.
    N.diner31 = S => { const D = { w: 156, d: 88, act: 'sit', seats: [{ x: -29, z: 12, h: 38 }, { x: 29, z: 12, h: 38 }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('d16'), R = rng('diner31'), VY = '#8a2a24', CH = '#c8ccd2', W = 150, SY = 38;
        let s = shadow(C, 0, 0, 76, 42, 0.4);
        const kick = w => `<rect width="${w}" height="30" fill="${VY}"/><rect y="24" width="${w}" height="6" fill="${CH}"/>${rep(12, () => `<path d="M${f1(R() * w)} ${f1(25 + R() * 4)}l${f1(2 + R() * 5)} ${f1((R() - 0.5) * 1)}" stroke="#7a7e86" stroke-width="0.3"/>`).join('')}<rect y="24" width="${w}" height="0.6" fill="#ffffff" opacity="0.6"/>` + rep(6, () => `<path d="M${f1(R() * w)} ${f1(2 + R() * 18)}l${f1((R() - 0.5) * 6)} ${f1(R() * 3)}" stroke="#5a1a14" stroke-width="0.4" opacity="0.6"/>`).join('');
        s += B10(C, { c: [0, 0, 2], w: W, h: 30, d: 72, col: VY, r: 1, dec: { f: kick(W), l: kick(72), r: kick(72), b: kick(W) } });
        const seatT = `<rect width="${W}" height="72" fill="${VY}"/>` + [[-29, 0], [29, 0]].map(([x]) => `<ellipse cx="${W / 2 + x}" cy="44" rx="20" ry="16" fill="#b8584a" opacity="0.25"/>`).join('') + rep(30, () => `<path d="M${f1(R() * W)} ${f1(R() * 72)}l${f1((R() - 0.5) * 6)} ${f1((R() - 0.5) * 3)}" stroke="#4a1410" stroke-width="0.3" opacity="0.5"/>`).join('')
          + `<path d="M${W / 2} 0V72" stroke="#4a1410" stroke-width="1"/><path d="M0 70H${W}" stroke="#5a1a14" stroke-width="1.4"/><path d="M${W / 2 - 50} 38q12 -6 26 1q-3 9 -13 10q-10 -1 -13 -11Z" fill="#e8c860"/>${rep(9, i => `<circle cx="${W / 2 - 45 + i * 2.2}" cy="${41 + (i % 3)}" r="1.8" fill="#f4dc80"/>`).join('')}<path d="M${W / 2 - 50} 38q12 -6 26 1" stroke="#3a0a08" stroke-width="0.8" fill="none"/><path d="M${W / 2 - 49} 40q12 7 25 1" stroke="#3a0a08" stroke-width="0.6" fill="none"/>`
          + `<g transform="translate(${W / 2 + 30} 30) rotate(18)"><rect x="-9" y="-2" width="18" height="4" fill="#b8bcc4"/><rect x="-9" y="-2" width="18" height="4" fill="#b8bcc4" transform="rotate(-70)"/>${rep(6, i => `<path d="M${-8 + i * 3} -1.6l0.6 3.2" stroke="#ffffff" stroke-width="0.25" opacity="0.5"/>`).join('')}</g>`;
        const edge = w => `<rect width="${w}" height="8" fill="${VY}"/><rect y="7" width="${w}" height="1" fill="#5a1a14"/>`;
        s += B10(C, { c: [0, 30, 4], w: W, h: 8, d: 72, col: VY, r: 2, dec: { t: seatT, f: edge(W), l: edge(72), r: edge(72), b: edge(W) } });
        const ef = C.v[2] > 0 ? line3(C, [[-W / 2, 30.2, 40.1], [W / 2, 30.2, 40.1]], 1.4, CH) + line3(C, [[-W / 2, 30.6, 40.2], [W / 2, 30.6, 40.2]], 0.35, '#ffffff', 'opacity="0.7"') + sph(C, [-20, 29.2, 40], 1.2, '#e86aa8') : '';
        // tall channel-stitched back against the wall
        const backF = w => { let f = `<rect width="${w}" height="46" fill="${VY}"/>`; rep(Math.floor(w / 9), i => { f += `<rect x="${f1(i * 9 + 0.4)}" y="1" width="8.2" height="44" rx="3.6" fill="url(#${id}ch)"/>`; }); return f + `<path d="M${f1(w * 0.7)} 6q1 10 -0.6 18" stroke="#2a0806" stroke-width="0.8" fill="none"/><path d="M${f1(w * 0.7 + 0.8)} 8q1.4 8 0 14" stroke="#e8c860" stroke-width="0.8" fill="none"/>` + `<rect y="44" width="${w}" height="2" fill="#5a1a14"/>`; };
        const back = B10(C, { c: [0, SY, -36], w: W, h: 46, d: 14, col: VY, r: 2, dec: { f: backF(W), b: `<rect width="${W}" height="46" fill="#4a2a1a"/>`, l: `<rect width="14" height="46" fill="${VY}"/>`, r: `<rect width="14" height="46" fill="${VY}"/>`, t: `<rect width="${W}" height="14" fill="${VY}"/><rect y="0.5" width="${W}" height="1.6" fill="${CH}"/>` } });
        const flapB = C.P([-36, SY + 0.2, 12]); const flap = `<g transform="translate(${P2(flapB)}) scale(${n4(k)})"><path d="M0 0l7 -1l-2 3Z" fill="#9a3a30" stroke="#3a0a08" stroke-width="0.3">${an('d', 'M0 0l7 -1l-2 3Z;M0 0l7 -3l-1.4 2.6Z;M0 0l7 -1l-2 3Z', 4.4)}</path></g>`;
        s += (C.v[2] >= 0 ? back + ef + flap : ef + flap + back);
        C.p(-78, 0, -44); C.p(78, 0, 44); C.p(78, 0, -44); C.p(-78, 0, 44); C.p(0, SY + 46, -36);
        const defs = `<defs><linearGradient id="${id}ch" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#5a1a14"/><stop offset="0.35" stop-color="#a8423a"/><stop offset="0.6" stop-color="${VY}"/><stop offset="1" stop-color="#4a1410"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // BANQUETTE KIT: the rsofa L / U layout (SW 58, AW 20, Dp 88, ext 62, seat h 38) so seats and footprint match the old rsofa rows exactly.
    // Returns D props + parts [{ k: kind, c, w, h, d }] for the fx to style; parts are drawn depth-sorted by centre.
    const banqKit = shp => { const SW = 58, AW = 20, Dp = 88, ext = 62, by = 9, DK = 12, SH = 15, bz0 = -Dp / 2 + 2, bz1 = bz0 + 13, cz1 = bz1 + 12, fr = Dp / 2 - 3, frC = Dp / 2 + ext - 3;
      const n = shp === 'U' ? 5 : 4, cols = shp === 'U' ? n - 2 : n - 1, Wd = cols * SW + AW * 2, xs = rep(cols, i => -Wd / 2 + AW + SW * (i + 0.5)), eL = true, eR = shp === 'U', ch = i => (eL && i === 0) || (eR && i === cols - 1);
      const seats = []; xs.forEach((x, i) => { seats.push({ x, z: (cz1 + fr) / 2, h: by + DK + SH + 2 }); if (ch(i)) seats.push({ x, z: Dp / 2 + ext / 2, h: by + DK + SH + 2 }); });
      const xl = -Wd / 2 + AW, xr = Wd / 2 - AW, P = [];
      xs.forEach((x, i) => { const zf = ch(i) ? frC : fr;
        P.push({ k: 'deck', c: [x, by, (bz1 + zf) / 2], w: SW, h: DK, d: zf - bz1 }, { k: 'base', c: [x, 0, (bz0 + zf) / 2], w: SW, h: by, d: zf - bz0 });
        P.push({ k: 'seat', c: [x, by + DK, (cz1 + zf) / 2 + 0.5], w: SW - 3, h: SH, d: zf - cz1 - 1 }, { k: 'bcush', c: [x, by + DK, (bz1 + cz1) / 2], w: SW - 3, h: 45, d: cz1 - bz1 }); });
      P.push({ k: 'back', c: [0, by, (bz0 + bz1) / 2], w: xr - xl, h: 60, d: bz1 - bz0 });
      [-1, 1].forEach(sg => { const e = sg < 0 ? eL : eR, z1 = e ? Dp / 2 + ext - 2 : Dp / 2 - 2; P.push({ k: 'arm', c: [sg * (Wd / 2 - AW / 2), 0, (bz0 + z1) / 2], w: AW, h: 41, d: z1 - bz0, sg }, { k: 'abase', c: [sg * (Wd / 2 - AW / 2), 0, (bz0 + z1) / 2], w: AW, h: 0.1, d: z1 - bz0 }); });
      return { D: { w: Wd, d: Dp + ext, act: 'sit', seats, build: () => [] }, P, Wd, xs, ch, fr, frC, bz0 };
    };
    const banqDraw = (C, parts, style) => parts.map(p => ({ d: (p.c[0]) * C.v[0] + (p.c[1] + p.h / 2) * C.v[1] + (p.c[2]) * C.v[2] + (p.k === 'back' ? (C.v[2] >= 0 ? -1e4 : 1e4) : p.k === 'arm' ? 2 : 0), s: style(p) })).sort((a, b) => a.d - b.d).map(o => o.s).join('');

    // CLB-036 BLACK FAUX-LEATHER L-SHAPED CLUB BANQUETTE (T2): a budget club banquette in shiny black faux leather: channel-stitched back
    // cushions, plump seat cushions with sitting creases, rolled arms, short chrome legs, and the cheap leatherette cracking and peeling to
    // the brown fabric backing on the arm tops and front edges, with a strip of black tape over one split. Seats four. Live: a loose flake of
    // peeling vinyl lifts in the draft.
    N.faux31 = S => { const K = banqKit('L'), D = K.D;
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('b36'), R = rng('faux31'), BK = '#1e1e22';
        const sheen = (w, h) => `<rect width="${w}" height="${h}" fill="url(#${id}sh)"/>`;
        const peel = (w, h, n) => rep(n, () => { const x = 2 + R() * (w - 4), y = 1 + R() * (h - 2), r = 1.2 + R() * 2.4; return `<path d="${blob(R, x, y, r, 8)}" fill="#7a5a3e" stroke="#c8c4bc" stroke-width="0.25"/>`; }).join('');
        const style = p => { const { k: kd, c, w, h, d } = p;
          if (kd === 'base' || kd === 'abase') return '';
          if (kd === 'deck') return B10(C, { c, w, h, d, col: BK, r: 1, dec: { f: `<rect width="${w}" height="${h}" fill="${BK}"/><rect y="${h - 1.2}" width="${w}" height="1.2" fill="#0c0c0e"/>${peel(w, h, 1)}` } });
          if (kd === 'seat') { const t = `<rect width="${w}" height="${d}" fill="${BK}"/>${sheen(w, d)}` + rep(5, () => `<path d="M${f1(w * 0.2 + R() * w * 0.6)} ${f1(d * 0.3 + R() * d * 0.4)}q${f1((R() - 0.5) * 8)} ${f1(R() * 3)} ${f1((R() - 0.5) * 14)} ${f1((R() - 0.5) * 4)}" stroke="#3a3a42" stroke-width="0.5" fill="none"/>`).join('') + `<rect x="1" y="1" width="${w - 2}" height="${d - 2}" rx="4" fill="none" stroke="#0a0a0c" stroke-width="0.7"/>` + (R() < 0.5 ? peel(w, 6, 2) : '');
            return B10(C, { c, w, h, d, col: BK, r: 4, dec: { t, f: `<rect width="${w}" height="${h}" fill="${BK}"/>${sheen(w, h)}<path d="M2 1.4H${w - 2}" stroke="#3a3a42" stroke-width="0.5"/>${peel(w, h, 2)}` } }); }
          if (kd === 'bcush') { const f = `<rect width="${w}" height="${h}" fill="${BK}"/>${sheen(w, h)}${rep(4, i => `<path d="M2 ${f1(8 + i * 9.5)}H${w - 2}" stroke="#0a0a0c" stroke-width="0.9"/><path d="M2 ${f1(8.8 + i * 9.5)}H${w - 2}" stroke="#4a4a52" stroke-width="0.4"/>`).join('')}`;
            return B10(C, { c, w, h, d, col: BK, r: 4, ax: [[1, 0, 0], [0, Math.cos(-0.12), Math.sin(-0.12)], [0, -Math.sin(-0.12), Math.cos(-0.12)]], dec: { f, t: `<rect width="${w}" height="${d}" fill="${BK}"/>${sheen(w, d)}` } }); }
          if (kd === 'back') return B10(C, { c, w, h, d, col: BK, r: 3, dec: { b: `<rect width="${w}" height="${h}" fill="#141416"/>${rep(6, i => `<path d="M0 ${f1(6 + i * 9)}H${w}" stroke="#0a0a0c" stroke-width="0.6"/>`).join('')}`, t: `<rect width="${w}" height="${d}" fill="${BK}"/>${sheen(w, d)}${peel(w, d, 1)}` } });
          if (kd === 'arm') { const L = d; return B10(C, { c: [c[0], 6, c[2]], w, h: h - 6, d, col: BK, r: 6, dec: { t: `<rect width="${w}" height="${L}" fill="${BK}"/>${sheen(w, L)}${peel(w, L, 2)}<rect x="${f1(w / 2 - 1.6)}" y="${f1(L * 0.4)}" width="3.2" height="10" fill="#0c0c0e" transform="rotate(12 ${f1(w / 2)} ${f1(L * 0.4 + 5)})"/>`, f: `<rect width="${w}" height="${h - 6}" fill="${BK}"/>${sheen(w, h - 6)}${peel(w, h - 6, 1)}`, l: `<rect width="${L}" height="${h - 6}" fill="${BK}"/>${sheen(L, h - 6)}${peel(L, h - 6, 1)}`, r: `<rect width="${L}" height="${h - 6}" fill="${BK}"/>${sheen(L, h - 6)}${peel(L, h - 6, 1)}` } }); }
          return ''; };
        let s = shadow(C, 0, 30, 110, 78, 0.4);
        const legs = []; K.P.filter(p => p.k === 'base' || p.k === 'abase').forEach(p => [-1, 1].forEach(a => [-1, 1].forEach(b => { const x = p.c[0] + a * (p.w / 2 - 4), z = p.c[2] + b * (p.d / 2 - 4); legs.push(cyl3(C, [x, 0, z], [x, 9.2, z], 1.8, '#c8ccd2', { mat: 'chrome', olw: 0.15, r2: 2.4 })); })));
        s += legs.join('') + banqDraw(C, K.P, style);
        const fp = C.P([-97, 41.2, 30]); s += `<g transform="translate(${P2(fp)}) scale(${n4(k)})"><path d="M0 0l5 -0.6l-1.6 2.4Z" fill="#2a2a30" stroke="#7a5a3e" stroke-width="0.3">${an('d', 'M0 0l5 -0.6l-1.6 2.4Z;M0 0l5 -2.6l-1 2Z;M0 0l5 -0.6l-1.6 2.4Z', 3.8)}</path></g>`;
        C.p(-108, 0, -44); C.p(108, 0, 106); C.p(108, 0, -44); C.p(-108, 0, 106); C.p(0, 70, -40);
        const defs = `<defs><linearGradient id="${id}sh" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0.02"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="1" stop-color="#000000" stop-opacity="0.2"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-056 TUFTED PURPLE VELVET HORSESHOE VIP BOOTH (T3): a horseshoe booth in deep aubergine velvet: diamond button-tufted backs, piped seat
    // cushions, rolled arms, all on a black lacquer plinth with a recessed warm light line. Seats five. Live: a soft sheen drifts across the
    // velvet.
    N.velvU31 = S => { const K = banqKit('U'), D = K.D;
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('b56'), R = rng('velvU31'), VL = '#46265e', VD = '#2e1640';
        const vel = (w, h) => `<rect width="${w}" height="${h}" fill="${VL}"/><rect width="${w}" height="${h}" fill="url(#${id}vv)"/>`;
        const tuft = (w, h) => { let f = vel(w, h); const cw = 10, rh = 9; for (let j = 0; j * rh < h - 4; j++) for (let i = 0; i * cw < w; i++) { const x = i * cw + (j % 2 ? cw / 2 : 0) + 2, y = 4 + j * rh; if (x > w - 2) continue;
            f += `<path d="M${f1(x)} ${f1(y)}L${f1(x + cw / 2)} ${f1(y + rh)}M${f1(x)} ${f1(y)}L${f1(x - cw / 2)} ${f1(y + rh)}" stroke="${VD}" stroke-width="0.6" opacity="0.8"/><circle cx="${f1(x)}" cy="${f1(y)}" r="0.9" fill="#2a1238"/><circle cx="${f1(x - 0.2)}" cy="${f1(y - 0.2)}" r="0.4" fill="#8a6aa8"/>`; }
          return f; };
        const style = p => { const { k: kd, c, w, h, d } = p;
          if (kd === 'abase') return '';
          if (kd === 'base') return B10(C, { c: [c[0], 0, c[2]], w: w - 4, h, d: d - 4, col: '#121214', r: 0.5, dec: { f: `<rect width="${w - 4}" height="${h}" fill="#121214"/><rect y="${h - 2}" width="${w - 4}" height="0.8" fill="#ffd9a0" opacity="0.8"/>` } });
          if (kd === 'deck') return B10(C, { c, w, h, d, col: VL, r: 1, dec: { f: vel(w, h) } });
          if (kd === 'seat') return B10(C, { c, w, h, d, col: VL, r: 4, dec: { t: `${vel(w, d)}<rect x="1" y="1" width="${w - 2}" height="${d - 2}" rx="4" fill="none" stroke="${VD}" stroke-width="0.9"/>`, f: `${vel(w, h)}<path d="M2 1.2H${w - 2}" stroke="${VD}" stroke-width="0.9"/>` } });
          if (kd === 'bcush') return B10(C, { c, w, h, d, col: VL, r: 4, ax: [[1, 0, 0], [0, Math.cos(-0.12), Math.sin(-0.12)], [0, -Math.sin(-0.12), Math.cos(-0.12)]], dec: { f: tuft(w, h), t: vel(w, d) } });
          if (kd === 'back') return B10(C, { c, w, h, d, col: VL, r: 3, dec: { b: vel(w, h), t: `${vel(w, d)}<path d="M0 ${d / 2}H${w}" stroke="${VD}" stroke-width="0.8"/>` } });
          if (kd === 'arm') return B10(C, { c: [c[0], 9, c[2]], w, h: h - 9, d, col: VL, r: 6, dec: { t: `${vel(w, d)}<path d="M${w / 2} 0V${d}" stroke="${VD}" stroke-width="0.7"/>`, f: vel(w, h - 9), l: vel(d, h - 9), r: vel(d, h - 9) } });
          return ''; };
        let s = shadow(C, 0, 30, 110, 78, 0.4) + banqDraw(C, K.P, style);
        C.p(-108, 0, -44); C.p(108, 0, 106); C.p(108, 0, -44); C.p(-108, 0, 106); C.p(0, 70, -40);
        const defs = `<defs><linearGradient id="${id}vv" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="0.4" stop-color="#000000" stop-opacity="0.05"/><stop offset="1" stop-color="#000000" stop-opacity="0.25"/>`
          + `<animate attributeName="x1" values="0;0.6;0" dur="9s" repeatCount="indefinite"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-076 ELEVATED GOLD-VELVET & MIRROR-TRIMMED BOTTLE-SERVICE SANCTUARY (T4): a horseshoe VIP booth in champagne-gold velvet with vertical
    // channel-tufted backs and gold piping, raised on a plinth clad in warm antique-mirror panels framed in brass with a glowing toe line, and in
    // the middle of the horseshoe a brass bottle-service stand with an ice bucket and a champagne bottle. Seats five. Live: glints run across the
    // mirror panels, the ice catches the light, a sheen drifts across the velvet.
    N.goldU31 = S => { const K = banqKit('U'), D = K.D;
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('b76'), R = rng('goldU31'), GV = '#b8903e', GD = '#7a5a20', BR = '#d8b060';
        const vel = (w, h) => `<rect width="${w}" height="${h}" fill="${GV}"/><rect width="${w}" height="${h}" fill="url(#${id}vv)"/>`;
        const chan = (w, h) => vel(w, h) + rep(Math.floor(w / 7.5), i => `<rect x="${f1(1 + i * 7.5)}" y="2" width="6.6" height="${h - 4}" rx="3" fill="url(#${id}cn)"/>`).join('');
        const mir = (w, h) => `<rect width="${w}" height="${h}" fill="url(#${id}mr)"/>` + rep(Math.max(1, Math.floor(w / 18)), i => `<rect x="${f1(i * w / Math.max(1, Math.floor(w / 18)))}" width="0.8" height="${h}" fill="${BR}"/>`).join('') + `<rect width="${w}" height="1" fill="${BR}"/><rect y="${h - 1.6}" width="${w}" height="1.6" fill="#ffd9a0" opacity="0.8"/><rect x="-20" width="10" height="${h}" fill="#ffffff" opacity="0.35" transform="skewX(-30)">${an('x', `-20;${w + 20}`, 5.5, -R() * 5)}</rect>`;
        const style = p => { const { k: kd, c, w, h, d } = p;
          if (kd === 'abase') return '';
          if (kd === 'base') return B10(C, { c: [c[0], 0, c[2]], w, h, d, col: '#c8b898', r: 0.4, dec: { f: mir(w, h), l: mir(d, h), r: mir(d, h), b: mir(w, h) } });
          if (kd === 'deck') return B10(C, { c, w, h, d, col: GV, r: 1, dec: { f: `${vel(w, h)}<rect y="0.6" width="${w}" height="0.8" fill="${BR}"/>` } });
          if (kd === 'seat') return B10(C, { c, w, h, d, col: GV, r: 4, dec: { t: `${vel(w, d)}<rect x="1" y="1" width="${w - 2}" height="${d - 2}" rx="4" fill="none" stroke="${BR}" stroke-width="0.7"/>`, f: `${vel(w, h)}<path d="M2 1.2H${w - 2}" stroke="${BR}" stroke-width="0.8"/>` } });
          if (kd === 'bcush') return B10(C, { c, w, h, d, col: GV, r: 4, ax: [[1, 0, 0], [0, Math.cos(-0.12), Math.sin(-0.12)], [0, -Math.sin(-0.12), Math.cos(-0.12)]], dec: { f: chan(w, h), t: vel(w, d) } });
          if (kd === 'back') return B10(C, { c, w, h, d, col: GV, r: 3, dec: { b: chan(w, h), t: `${vel(w, d)}<path d="M0 1H${w}" stroke="${BR}" stroke-width="0.8"/>` } });
          if (kd === 'arm') return B10(C, { c: [c[0], 9, c[2]], w, h: h - 9, d, col: GV, r: 6, dec: { t: `${vel(w, d)}<path d="M${w / 2} 0V${d}" stroke="${BR}" stroke-width="0.7"/>`, f: chan(w, h - 9), l: chan(d, h - 9), r: chan(d, h - 9) } });
          return ''; };
        let s = shadow(C, 0, 30, 110, 78, 0.45) + PLN(C, 0.1, `<rect x="-108" y="-44" width="216" height="150" rx="8" fill="url(#${id}fl)"/>`);
        // bottle-service stand in the horseshoe
        const X0 = 0, Z0 = 78, stand = cyl3(C, [X0, 0, Z0], [X0, 1.4, Z0], 9, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [X0, 1.4, Z0], [X0, 26, Z0], 1.2, BR, { mat: 'metal', olw: 0.15 })
          + cyl3(C, [X0, 26, Z0], [X0, 38, Z0], 7, '#c8ccd2', { mat: 'chrome', olw: 0.25, r2: 8.4, capCol: '#eef4f8' }) + PLN(C, 38.05, rep(6, i => `<rect x="${f1(-4 + (i % 3) * 3)}" y="${f1(-3 + Math.floor(i / 3) * 3)}" width="2.4" height="2.4" rx="0.5" fill="#ffffff" opacity="0.9"/>`).join('') + `<circle cx="2" cy="1" r="0.6" fill="#ffffff" opacity="0">${an('opacity', '0;1;0', 2.2)}</circle>`, X0, Z0)
          + cyl3(C, [X0 + 1, 33, Z0], [X0 + 2.4, 46, Z0 - 1], 2.6, '#1e3a24', { mat: 'gloss', olw: 0.2 }) + cyl3(C, [X0 + 2.4, 46, Z0 - 1], [X0 + 3, 52, Z0 - 1.4], 1.1, '#d8b060', { mat: 'metal', olw: 0.12 });
        const parts = banqDraw(C, K.P, style), sd = X0 * C.v[0] + Z0 * C.v[2];
        s += sd > 30 ? parts + stand : stand + parts;
        C.p(-108, 0, -44); C.p(108, 0, 106); C.p(108, 0, -44); C.p(-108, 0, 106); C.p(0, 70, -40);
        const defs = `<defs><linearGradient id="${id}vv" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff4d8" stop-opacity="0.22"/><stop offset="0.45" stop-color="#000000" stop-opacity="0.02"/><stop offset="1" stop-color="#000000" stop-opacity="0.22"/><animate attributeName="x1" values="0;0.6;0" dur="9s" repeatCount="indefinite"/></linearGradient>`
          + `<linearGradient id="${id}cn" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${GD}" stop-opacity="0.6"/><stop offset="0.35" stop-color="#ffe8b0" stop-opacity="0.35"/><stop offset="0.7" stop-color="${GV}" stop-opacity="0"/><stop offset="1" stop-color="${GD}" stop-opacity="0.6"/></linearGradient>`
          + `<linearGradient id="${id}mr" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6eee0"/><stop offset="0.45" stop-color="#b8a888"/><stop offset="0.55" stop-color="#ece0c8"/><stop offset="1" stop-color="#8a7a5e"/></linearGradient>`
          + `<radialGradient id="${id}fl"><stop offset="0" stop-color="#ffd9a0" stop-opacity="0.3"/><stop offset="1" stop-color="#ffd9a0" stop-opacity="0"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-096 FLOATING ANTI-GRAVITY VIP CLOUD BOOTH WITH PRIVATE SOUND DOME (T5): the same floating horseshoe (5 seats, 214 x 150, lifted 14)
    // rebuilt as a cloud-soft ivory boucle booth on a brushed-brass skirt with a warm under-light line, two champagne silk pillows, hovering over a
    // polished black marble plinth with a brass edge. A translucent champagne-glass sound dome on brass ribs rises from the back, with a warm
    // pendant light hanging inside and a rim of tiny speaker lights. Live: the booth bobs, warm cloud puffs drift beneath it, the plinth glow
    // breathes with the bob, pulses of light climb the dome ribs and the rim lights ripple.
    N.cloud31 = S => { const K = banqKit('U'), D = K.D, LF = 14;
      D.seats = D.seats.map(q => ({ x: q.x, z: q.z, h: q.h + LF })); D.anim = at('translate', '0 0;0 -5;0 0', 3.2, 0, SPL(2)); D.pad = [0, 8, 0, 0];
      const PP = K.P.map(p => Object.assign({}, p, { c: [p.c[0], p.c[1] + LF, p.c[2]] }));
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('b96'), R = rng('cloud31'), IV = '#ebe2cf', BR = '#c79a4a', CH = '#d8b77e', V = C.v;
        const TILT = [[1, 0, 0], [0, Math.cos(-0.12), Math.sin(-0.12)], [0, -Math.sin(-0.12), Math.cos(-0.12)]];
        const bq = (w, h) => `<rect width="${f1(w)}" height="${f1(h)}" fill="url(#${id}bq)"/>`;
        const gl = (W, h) => `<rect y="${f1(h - 1.3)}" width="${f1(W)}" height="1.3" fill="#ffe0a0" opacity="0.9"/>`;
        const skirt = (c, w, h, d) => B10(C, { c, w, h, d, col: BR, r: 0.6, mat: 'brush', gl: 0.6, dec: { f: gl(w, h), b: gl(w, h), l: gl(d, h), r: gl(d, h) } });
        const style = p => { const { k: kd, c, w, h, d } = p;
          if (kd === 'abase') return '';
          if (kd === 'base') return skirt(c, w, h, d);
          if (kd === 'deck') return B10(C, { c, w, h, d, col: IV, r: 1, dec: { f: bq(w, h) + `<path d="M0 0.7H${f1(w)}" stroke="${CH}" stroke-width="0.8"/>` } });
          if (kd === 'seat') return B10(C, { c, w, h, d, col: IV, r: 5.5, dec: { t: bq(w, d) + `<ellipse cx="${f1(w / 2)}" cy="${f1(d * 0.42)}" rx="${f1(w * 0.42)}" ry="${f1(d * 0.36)}" fill="url(#${id}pf)"/>`, f: bq(w, h) + `<path d="M3 1.1H${f1(w - 3)}" stroke="${CH}" stroke-width="0.7"/>` } });
          if (kd === 'bcush') return B10(C, { c, w, h, d, col: IV, r: 5, ax: TILT, dec: { f: bq(w, h) + rep(3, i => `<rect x="1" y="${f1(1 + i * (h - 2) / 3)}" width="${f1(w - 2)}" height="${f1((h - 2) / 3)}" rx="5" fill="url(#${id}rl)"/>`).join(''), t: bq(w, d) } });
          if (kd === 'back') return B10(C, { c, w, h, d, col: IV, r: 3, dec: { b: bq(w, h) + rep(3, i => `<rect x="0" y="${f1(i * h / 3)}" width="${f1(w)}" height="${f1(h / 3)}" fill="url(#${id}rl)" opacity="0.6"/>`).join(''), t: bq(w, d) + `<path d="M0 1H${f1(w)}" stroke="${CH}" stroke-width="0.9"/>` } });
          if (kd === 'arm') return skirt(c, w, 9, d) + B10(C, { c: [c[0], c[1] + 9, c[2]], w, h: h - 9, d, col: IV, r: 6.5, dec: { t: bq(w, d) + `<ellipse cx="${f1(w / 2)}" cy="${f1(d / 2)}" rx="${f1(w * 0.36)}" ry="${f1(d * 0.46)}" fill="url(#${id}pf)"/>`, f: bq(w, h - 9), l: bq(d, h - 9), r: bq(d, h - 9) } });
          return ''; };

        // ---- floor (does not bob): soft shadow, black marble plinth with a brass edge, warm glow, cloud puffs under the booth
        let U = shadow(C, 0, 31, 108, 76, 0.26);
        const vein = rep(6, () => { const x0 = R() * 204, y0 = R() * 144; return `<path d="M${f1(x0)} ${f1(y0)}q${f1((R() - 0.5) * 60)} ${f1((R() - 0.5) * 30)} ${f1((R() - 0.5) * 120)} ${f1((R() - 0.5) * 50)}" stroke="#e8e0d4" stroke-width="0.35" fill="none" opacity="0.26"/>`; }).join('');
        U += B10(C, { c: [0, 0, 31], w: 204, h: 2.4, d: 144, col: '#161417', r: 12, gl: 0.7, edge: 0, dec: { t: `<g clip-path="url(#${id}cp)">${vein}</g><rect x="1.2" y="1.2" width="201.6" height="141.6" rx="11" fill="none" stroke="${BR}" stroke-width="1.1"/>`, f: `<rect width="204" height="0.7" fill="${BR}"/>`, l: `<rect width="144" height="0.7" fill="${BR}"/>`, r: `<rect width="144" height="0.7" fill="${BR}"/>`, b: `<rect width="204" height="0.7" fill="${BR}"/>` } });
        U += PLN(C, 2.5, `<rect x="-94" y="-38" width="188" height="132" rx="44" fill="url(#${id}gw)" opacity="0.7">${an('opacity', '0.7;0.35;0.7', 3.2, 0, SPL(2))}</rect><rect x="-96" y="-36" width="192" height="128" rx="9" fill="none" stroke="${BR}" stroke-width="0.5" opacity="0.8"/>`);
        const puff = (x, y, z, r, op) => { const q = C.P([x, y, z]), T = 6 + R() * 5, dx = (R() - 0.5) * 8 * k, dy = -(1 + R() * 2) * k;
          return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(r * k)}" ry="${f1(r * k * 0.6)}" fill="url(#${id}cl)" opacity="${op}">${at('translate', `0 0;${f1(dx)} ${f1(dy)};0 0`, T, -R() * T, SPL(2))}</ellipse>`; };
        const RC = [[-107, -44, 107, 41], [-107, 41, -29, 106], [29, 41, 107, 106]];
        RC.forEach(([x0, z0, x1, z1]) => { const n = Math.round((x1 - x0) * (z1 - z0) / 900); rep(n, () => { U += puff(x0 + R() * (x1 - x0), 3 + R() * 5, z0 + R() * (z1 - z0), 10 + R() * 6, 0.6); }); });
        let O = '';
        [[-107, -44, 107, -44, 0, -1], [107, -44, 107, 106, 1, 0], [-107, 106, -107, -44, -1, 0], [-107, 106, -29, 106, 0, 1], [29, 106, 107, 106, 0, 1], [-29, 106, -29, 41, 1, 0], [29, 41, 29, 106, -1, 0], [-29, 41, 29, 41, 0, 1]].forEach(([x0, z0, x1, z1, nx, nz]) => {
          if (nx * V[0] + nz * V[2] < 0.2) return; const L = Math.hypot(x1 - x0, z1 - z0), n = Math.max(2, Math.round(L / 16));
          rep(n, i => { const t = (i + 0.5) / n; O += puff(x0 + (x1 - x0) * t + nx * 2, 2 + R() * 5, z0 + (z1 - z0) * t + nz * 2, 6 + R() * 4, 0.5); }); });

        // ---- the booth (bobs with D.anim)
        let s = '';
        const pil = (x, z, yw) => { const A0 = [Math.cos(yw), 0, Math.sin(yw)], A2 = [-Math.sin(yw), 0, Math.cos(yw)], up = add(mul([0, 1, 0], Math.cos(0.35)), mul(A2, -Math.sin(0.35)));
          return B10(C, { c: [x, 50, z], ax: [A0, up, cross(A0, up)], w: 17, h: 16, d: 5, col: '#e2c48e', r: 2.4, gl: 0.8, dec: { f: `<rect width="17" height="16" fill="url(#${id}sk)"/><rect x="1" y="1" width="15" height="14" rx="2.4" fill="none" stroke="#b8945a" stroke-width="0.6"/>` } }); };
        const pills = pil(-75, -11, -0.5) + pil(75, -11, 0.5), parts = banqDraw(C, PP, style);
        s += V[2] >= 0 ? parts + pills : pills + parts;

        // ---- private sound dome: a quarter-dome of champagne glass on brass ribs, standing on the back
        const DO = [0, 83, -35.5], RX = 86, RZ = 40, H = 52, Q = (t, f) => [DO[0] + RX * Math.cos(t) * Math.cos(f), DO[1] + H * Math.sin(f), DO[2] + RZ * Math.sin(t) * Math.cos(f)];
        const pth3 = pts => 'M' + pts.map(p => P2(C.P(p))).join('L');
        const NT = 12, NF = 5, glass = [];
        for (let i = 0; i < NT; i++) for (let j = 0; j < NF; j++) { const t0 = PI * i / NT, t1 = PI * (i + 1) / NT, g0 = PI / 2 * j / NF, g1 = PI / 2 * (j + 1) / NF, tm = (t0 + t1) / 2, fm = (g0 + g1) / 2, cm = Q(tm, fm);
          const n = nrm([Math.cos(tm) * Math.cos(fm) / RX, Math.sin(fm) / H, Math.sin(tm) * Math.cos(fm) / RZ]), out = n[0] * V[0] + n[1] * V[1] + n[2] * V[2] > 0;
          glass.push({ d: cm[0] * V[0] + cm[1] * V[1] + cm[2] * V[2], s: `<path d="${pth3([Q(t0, g0), Q(t1, g0), Q(t1, g1), Q(t0, g1)])}Z" fill="${out ? '#f6e2b8' : '#d4ae70'}" opacity="${out ? 0.24 : 0.17}"/>` + (out && (i === 3 || i === 4) && j > 0 && j < 3 ? `<path d="${pth3([Q(t0, g0), Q(t1, g0), Q(t1, g1), Q(t0, g1)])}Z" fill="#ffffff" opacity="0.22"/>` : '') }); }
        let dm = glass.sort((a, b) => a.d - b.d).map(o => o.s).join('');
        const mer = t => rep(17, j => Q(t, PI / 2 * j / 16)), par = f => rep(25, j => Q(PI * j / 24, f));
        dm += rep(5, i => { const P = mer(PI * i / 4), w = i === 0 || i === 4 ? 1.8 : 1; return line3(C, P, w, BR) + line3(C, P, w * 0.3, '#ffe8b8', 'opacity="0.6"'); }).join('');
        dm += line3(C, par(0), 1.6, BR) + line3(C, par(0), 0.45, '#ffe8b8', 'opacity="0.6"') + line3(C, par(PI / 4), 0.7, BR, 'opacity="0.9"');
        dm += rep(3, i => `<path d="${pth3(mer(PI * (i + 1) / 4))}" fill="none" stroke="#ffe7b0" stroke-width="${f1(1.1 * k)}" stroke-linecap="round" pathLength="100" stroke-dasharray="6 94" opacity="0.85"><animate attributeName="stroke-dashoffset" values="0;-100" dur="2.6s" begin="${n4(-i * 0.45)}s" repeatCount="indefinite"/></path>`).join('');
        dm += rep(21, j => { const q = C.P(Q(PI * (j + 0.5) / 21, 0.04)); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.6 * k)}" fill="#ffe2a8" opacity="0.3">${an('opacity', '0.25;0.95;0.25', 1.6, -j * 0.08)}</circle>`; }).join('');
        dm += sph(C, Q(0, PI / 2), 2.4, BR) + sph(C, [DO[0], DO[1] + 1, DO[2]].map((v, i) => i === 0 ? -RX : v), 1.8, BR) + sph(C, [RX, DO[1] + 1, DO[2]], 1.8, BR);
        const pa = Q(PI / 2, PI / 4), pb = [pa[0], 104, pa[2]], pq = C.P([pb[0], pb[1] - 3, pb[2]]);
        dm += line3(C, [pa, pb], 0.35, '#3a2e20') + `<ellipse cx="${f1(pq[0])}" cy="${f1(pq[1])}" rx="${f1(16 * k)}" ry="${f1(12 * k)}" fill="#ffcf80" opacity="0.3" filter="url(#g31b3)">${an('opacity', '0.3;0.42;0.3', 3.2, 0, SPL(2))}</ellipse>`
          + cyl3(C, [pb[0], pb[1] + 1.4, pb[2]], [pb[0], pb[1] - 1, pb[2]], 1.2, BR, { mat: 'metal', olw: 0.15, r2: 2.6 }) + sph(C, [pb[0], pb[1] - 3.4, pb[2]], 2.8, '#ffd68a');
        s += dm;
        C.p(-108, 0, -45); C.p(108, 0, 107); C.p(108, 0, -45); C.p(-108, 0, 107); C.p(0, 138, -36);
        const defs = DEFG + `<defs><pattern id="${id}bq" width="2.4" height="2.2" patternUnits="userSpaceOnUse"><circle cx="0.6" cy="0.6" r="0.5" fill="none" stroke="#ffffff" stroke-opacity="0.45" stroke-width="0.25"/><circle cx="1.8" cy="1.65" r="0.5" fill="none" stroke="#8a7c62" stroke-opacity="0.3" stroke-width="0.25"/><circle cx="1.75" cy="0.5" r="0.3" fill="#ffffff" fill-opacity="0.25"/></pattern>`
          + `<radialGradient id="${id}pf" cx="45%" cy="40%" r="60%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.32"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>`
          + `<linearGradient id="${id}rl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.26"/><stop offset="0.55" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#6a5a40" stop-opacity="0.28"/></linearGradient>`
          + `<linearGradient id="${id}sk" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff4dc" stop-opacity="0.5"/><stop offset="0.4" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.6" stop-color="#fff4dc" stop-opacity="0.3"/><stop offset="1" stop-color="#5a4020" stop-opacity="0.25"/><animate attributeName="x1" values="0;0.5;0" dur="7s" repeatCount="indefinite"/></linearGradient>`
          + `<radialGradient id="${id}gw"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.6"/><stop offset="0.6" stop-color="#f0c070" stop-opacity="0.16"/><stop offset="1" stop-color="#e8a858" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}cl"><stop offset="0" stop-color="#fff6ea" stop-opacity="0.9"/><stop offset="0.55" stop-color="#fbe8d0" stop-opacity="0.4"/><stop offset="1" stop-color="#fbe8d0" stop-opacity="0"/></radialGradient>`
          + `<clipPath id="${id}cp"><rect width="204" height="144" rx="12"/></clipPath></defs>`;
        return { defs, under: U, front: s, over: O, bb: C.bb(3) }; };
      return D; };

    // CLB-019 UPENDED MILK CRATE BY THE WALL (T1): a faded blue plastic milk crate turned upside down: thick lip at the floor, the long handle
    // slots near the bottom, three rows of open holes with the dark inside showing through, white stress scuffs, a cracked top corner and a
    // half-peeled round sticker. A yellowed square of foam is strapped on top with two strips of black duct tape. Live: a loose tape end flutters.
    N.crate31 = S => { const D = { w: 46, d: 46, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('c19'), R = rng('crate31'), BL = '#4274ad', BD = '#22446e', TY = 40;
        const scuff = (w, h, n) => rep(n, () => { const x = 2 + R() * (w - 4), y = 2 + R() * (h - 4); return `<path d="M${f1(x)} ${f1(y)}l${f1((R() - 0.5) * 6)} ${f1((R() - 0.5) * 2)}" stroke="#d8e6f4" stroke-width="0.3" opacity="0.55"/>`; }).join('');
        const side = (w, h, fr) => { let f = ''; const hw = (w - 6) / 4;
          for (let r = 0; r < 3; r++) for (let c = 0; c < 4; c++) { const x = 3 + c * hw + 0.9, y = 2.6 + r * 7.6, ww = hw - 1.8, hh = 5.4;
            f += `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(ww)}" height="${hh}" rx="1" fill="#0d1520"/><rect x="${f1(x + 1.6)}" y="${f1(y + 1.1)}" width="${f1(ww - 3.2)}" height="${f1(hh - 2.6)}" rx="0.6" fill="${BD}" opacity="0.6"/><path d="M${f1(x + 0.6)} ${f1(y + hh - 0.25)}H${f1(x + ww - 0.6)}" stroke="#86b0de" stroke-width="0.5" opacity="0.75"/>`; }
          f += `<rect x="${f1(w * 0.27)}" y="${f1(h - 8.4)}" width="${f1(w * 0.46)}" height="4.2" rx="2.1" fill="#0d1520"/><path d="M${f1(w * 0.27 + 2)} ${f1(h - 4.4)}H${f1(w * 0.73 - 2)}" stroke="#86b0de" stroke-width="0.5" opacity="0.75"/>`;
          f += `<path d="M1.2 0V${h}M${f1(w - 1.2)} 0V${h}" stroke="${BD}" stroke-width="0.8" opacity="0.6"/>` + scuff(w, h, 7);
          if (fr) f += `<path d="M${f1(w - 6)} 0L${f1(w)} 0L${f1(w)} 4.6Z" fill="#0d1520"/><path d="M${f1(w - 6)} 0l-2.6 3.4l1.4 1.8" stroke="#1a2a40" stroke-width="0.35" fill="none"/>`
            + `<g transform="translate(6.5 ${f1(h - 13)})"><circle r="2.8" fill="#e89a3a" opacity="0.75"/><path d="M-2.8 0A2.8 2.8 0 0 1 1 -2.6L0.4 0.6Z" fill="${BL}"/><path d="M1 -2.6L0.4 0.6L2.6 1" stroke="#f4e8d0" stroke-width="0.3" fill="none" opacity="0.8"/></g>`;
          return f; };
        const top = w => { let f = ''; for (let i = 0; i < 7; i++) for (let j = 0; j < 7; j++) f += `<rect x="${f1(1.6 + i * 5.9)}" y="${f1(1.6 + j * 5.9)}" width="4.2" height="4.2" rx="0.5" fill="#0d1520"/>`; return f + scuff(w, w, 4); };
        let s = shadow(C, 0, 0, 26, 26, 0.45);
        s += B10(C, { c: [0, 0, 0], w: 46, h: 4, d: 46, col: BL, r: 1.6, mat: 'noise', dec: { f: scuff(46, 4, 2), r: scuff(46, 4, 2) } });
        s += B10(C, { c: [0, 4, 0], w: 44, h: TY - 4, d: 44, col: BL, r: 1.4, mat: 'noise', dec: { f: side(44, TY - 4, 1), b: side(44, TY - 4), l: side(44, TY - 4), r: side(44, TY - 4), t: top(44) } });
        // tape: two strips over the foam, running down the left and right sides of the crate
        const TZ = [[-13.5, -8.5], [5.5, 10.5]], tp = '#1c1c1e', tg = '#5a5a60';
        const strip = (a, b, len, x) => x ? `<rect x="${f1(a)}" y="0" width="${f1(b - a)}" height="${len}" fill="${tp}"/><path d="M${f1(a + 0.6)} 0V${len}" stroke="${tg}" stroke-width="0.35"/>` : `<rect x="0" y="${f1(a)}" width="${len}" height="${f1(b - a)}" fill="${tp}"/><path d="M0 ${f1(a + 0.6)}H${len}" stroke="${tg}" stroke-width="0.35"/>`;
        const sideTape = (L, x0) => TZ.map(([a, b]) => strip(L(a, b)[0], L(a, b)[1], x0, 1)).join('');
        s += B10(C, { c: [0.5, TY, -0.5], w: 39, h: 3.6, d: 38, col: '#d2c8a2', r: 1.6, mat: 'foam', dec: {
          t: TZ.map(([a, b]) => strip(a + 19, b + 19, 39)).join('') + `<path d="${blob(R, 33, 31, 3.2, 9)}" fill="#b8a874" opacity="0.6"/><circle cx="12" cy="18" r="4.6" fill="none" stroke="#8a7448" stroke-width="0.6" opacity="0.35"/><path d="M4 30l5 2.4l-1 2.2" stroke="#9a8a5a" stroke-width="0.4" fill="none"/>`,
          r: sideTape((a, b) => [19 - b, 19 - a], 3.6), l: sideTape((a, b) => [a + 19, b + 19], 3.6) } });
        // tape continues down the crate's sides (drawn on the visible one); one end has come unstuck
        const xs = V0 => V0 >= 0 ? 22.05 : -22.05, sx = xs(C.v[0]);
        TZ.forEach(([a, b]) => { s += `<path d="M${P2(C.P([sx, TY, a]))}L${P2(C.P([sx, TY, b]))}L${P2(C.P([sx, TY - 7, b]))}L${P2(C.P([sx, TY - 7, a]))}Z" fill="${tp}" opacity="0.95"/>`; });
        { const [a, b] = TZ[1], o = C.P([sx, TY - 7, a]), q = C.P([sx, TY - 7, b]), dx = (q[0] - o[0]), dy = (q[1] - o[1]), w2 = 3.2 * k;
          s += `<path fill="${tp}" stroke="${tg}" stroke-width="0.25"><animate attributeName="d" values="M${P2(o)}l${f1(dx)} ${f1(dy)}l${f1(1 * k)} ${f1(w2)}l${f1(-dx - 1 * k)} ${f1(-dy)}Z;M${P2(o)}l${f1(dx)} ${f1(dy)}l${f1(3.2 * k)} ${f1(w2 * 0.7)}l${f1(-dx - 2.6 * k)} ${f1(-dy + 0.4 * k)}Z;M${P2(o)}l${f1(dx)} ${f1(dy)}l${f1(1 * k)} ${f1(w2)}l${f1(-dx - 1 * k)} ${f1(-dy)}Z" dur="2.4s" repeatCount="indefinite"${SPL(2)}/></path>`; }
        C.p(-23, 0, -23); C.p(23, 0, 23); C.p(23, 0, -23); C.p(-23, 0, 23); C.p(0, TY + 4, 0);
        return { defs: '', front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-039 CHROME & RED VINYL SWIVEL BAR STOOL (T2): a second-hand diner bar stool: four splayed chrome tube legs with a foot ring, a swivel
    // plate and a ribbed chrome band holding a domed red vinyl cushion. The vinyl has split across the top and is patched with an X of silver duct
    // tape, with fine cracks at the edge; the chrome is pitted with rust near the floor, the foot ring is rubbed dull where feet rest, one rubber
    // foot cap is missing and there is a wad of pink gum stuck under the seat. Live: the loose seat wobbles on its swivel.
    N.dstool31 = S => { const D = { w: 44, d: 44, round: 1, act: 'sit', seats: [{ x: 0, z: 0, h: 71 }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('s39'), R = rng('dstool31'), CR = '#c8ccd2', RV = '#b8282c', TY = 60, V = C.v, tv = thV(C);
        let s = shadow(C, 0, 0, 21, 21, 0.4);
        const LA = [0.3, 0.3 + PI / 2, 0.3 + PI, 0.3 + PI * 1.5], rAt = y => 17 - 7.5 * y / TY;
        const leg = (a, i) => { const F = [Math.cos(a) * 17, 0, Math.sin(a) * 17], T = [Math.cos(a) * 9.5, TY, Math.sin(a) * 9.5], miss = i === 2;
          let l = miss ? cyl3(C, F, T, 1.5, CR, { mat: 'chrome', olw: 0.2, n: 14 }) + cyl3(C, F, [Math.cos(a) * 16.8, 0.6, Math.sin(a) * 16.8], 1.55, '#6a4a2c', { mat: 'matte', olw: 0.12 })
            : cyl3(C, [Math.cos(a) * 16.9, 2.4, Math.sin(a) * 16.9], T, 1.5, CR, { mat: 'chrome', olw: 0.2, n: 14 }) + cyl3(C, [F[0], 0, F[2]], [Math.cos(a) * 16.9, 2.4, Math.sin(a) * 16.9], 2.1, '#1a1a1c', { mat: 'matte', olw: 0.15, r2: 1.7 });
          if (Math.cos(a) * V[0] + Math.sin(a) * V[2] > -0.2) l += rep(6, () => { const t = 0.04 + R() * 0.22, y = TY * t, r = rAt(y) + 0.6, q = C.P([Math.cos(a + (R() - 0.5) * 0.08) * r, y, Math.sin(a + (R() - 0.5) * 0.08) * r]); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1((0.25 + R() * 0.3) * k)}" fill="#8a5630" opacity="0.75"/>`; }).join('');
          return { d: Math.cos(a) * V[0] + Math.sin(a) * V[2], s: l }; };
        const legs = LA.map(leg), ry = 24, rr = rAt(ry) + 0.2, ring = rep(41, i => [Math.cos(i / 40 * 2 * PI) * rr, ry, Math.sin(i / 40 * 2 * PI) * rr]);
        const worn = rep(9, i => { const a = tv - 0.5 + i * 0.125; return [Math.cos(a) * rr, ry + 0.5, Math.sin(a) * rr]; });
        s += legs.filter(l => l.d < 0).map(l => l.s).join('') + line3(C, ring, 1.5, '#9aa0a8') + line3(C, ring, 0.5, '#ffffff', 'opacity="0.55"') + line3(C, worn, 0.9, '#8a8e94', 'opacity="0.8"') + legs.filter(l => l.d >= 0).map(l => l.s).join('');
        // the seat: swivel plate, ribbed chrome band, domed red vinyl cushion
        const seat = r => `<circle r="${n4(r)}" fill="url(#${id}vn)"/><circle r="${n4(r - 1)}" fill="none" stroke="#7a1418" stroke-width="0.7"/><circle r="${n4(r - 1.6)}" fill="none" stroke="#e86a6a" stroke-width="0.25" opacity="0.5"/>`
          + `<path d="M-6 -1.5Q-1 0.5 3 -0.6T9.5 1.4" stroke="#3a0a0c" stroke-width="0.9" fill="none"/><path d="M-6 -1.5Q-1 0.5 3 -0.6T9.5 1.4" stroke="#e8c8b0" stroke-width="0.3" fill="none" opacity="0.6"/>`
          + [-35, 35].map(a => `<g transform="rotate(${a})"><rect x="-6.5" y="-1.8" width="13" height="3.6" fill="#b4b8bc"/><path d="M-6.5 -1.8H6.5M-6.5 1.8H6.5" stroke="#8a8e92" stroke-width="0.3"/>${rep(6, j => `<path d="M${f1(-5.5 + j * 2.2)} -1.8v3.6" stroke="#d4d8dc" stroke-width="0.2" opacity="0.6"/>`).join('')}<path d="M6.5 -1.8l0.6 0.9l-0.5 0.8l0.6 0.9l-0.7 1" fill="#b4b8bc"/></g>`).join('')
          + rep(9, () => { const a = R() * 2 * PI, q = r - 1.5 - R() * 3; return `<path d="M${f1(Math.cos(a) * q)} ${f1(Math.sin(a) * q)}l${f1(Math.cos(a + 1.4) * 1.6)} ${f1(Math.sin(a + 1.4) * 1.6)}" stroke="#5a0c10" stroke-width="0.25"/>`; }).join('')
          + `<circle r="${n4(r)}" fill="url(#${id}hl)"/>`;
        let g = cyl3(C, [0, TY - 1.5, 0], [0, TY + 1.5, 0], 10.5, '#8e9298', { mat: 'metal', olw: 0.2 });
        g += cyl3(C, [0, TY + 1.5, 0], [0, TY + 5.5, 0], 15.3, CR, { mat: 'chrome', olw: 0.25, r2: 15.8, noCap: 1 });
        g += rep(15, i => { const a = tv - 1.35 + i * 2.7 / 14; return line3(C, [[Math.cos(a) * 15.45, TY + 1.8, Math.sin(a) * 15.45], [Math.cos(a) * 15.9, TY + 5.2, Math.sin(a) * 15.9]], 0.3, '#7a7e84', 'opacity="0.7"'); }).join('');
        { const a = tv + 0.75, q = C.P([Math.cos(a) * 14.6, TY + 1.2, Math.sin(a) * 14.6]); g += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(1.6 * k)}" ry="${f1(0.9 * k)}" fill="#e890b0"/><ellipse cx="${f1(q[0] - 0.4 * k)}" cy="${f1(q[1] - 0.3 * k)}" rx="${f1(0.6 * k)}" ry="${f1(0.3 * k)}" fill="#ffd0e0" opacity="0.8"/>`; }
        g += cyl3(C, [0, TY + 5.5, 0], [0, TY + 10.6, 0], 15.6, RV, { mat: 'gloss', olw: 0.25, r2: 14.2, cap: seat });
        g += rep(4, i => { const a = tv - 0.6 + i * 0.4 + R() * 0.1; return line3(C, [[Math.cos(a) * 15.5, TY + 6.2, Math.sin(a) * 15.5], [Math.cos(a + 0.05) * 15, TY + 8.6, Math.sin(a + 0.05) * 15]], 0.3, '#5a0c10', 'opacity="0.7"'); }).join('');
        const sc = C.P([0, TY, 0]), pv = `${f1(sc[0])} ${f1(sc[1])}`;
        s += `<g>${at('rotate', `0 ${pv};1.3 ${pv};0 ${pv};-0.9 ${pv};0 ${pv}`, 4.6, 0, SPL(4))}${g}</g>`;
        C.p(-19, 0, -19); C.p(19, 0, 19); C.p(19, 0, -19); C.p(-19, 0, 19); C.p(-16, TY + 11, 0); C.p(16, TY + 11, 0);
        const defs = `<defs><radialGradient id="${id}vn" cx="40%" cy="35%" r="75%"><stop offset="0" stop-color="#d8484a"/><stop offset="0.6" stop-color="${RV}"/><stop offset="1" stop-color="#7e161a"/></radialGradient>`
          + `<radialGradient id="${id}hl" cx="34%" cy="28%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.38"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0.06"/><stop offset="1" stop-color="#000000" stop-opacity="0.12"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-059 ILLUMINATED LED GLOW-CUBE SEAT (T3): a rotomoulded frosted-plastic cube seat lit from inside by a colour-changing LED, with soft
    // rounded edges, a faint mould seam, a round charcoal felt pad on top and a little remote and charge cable on the floor beside it. Keeps the
    // party flag + glow. Live: the cube fades through magenta, amber, violet and coral (faster when the party is on).
    N.ledcube31 = S => { const D = { w: 46, d: 46, act: 'sit', party: 1, seats: [{ x: 0, z: 0, h: 42 }], glow: () => ({ y: 20, r: 50, c: 'url(#gNeon)' }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('g59'), R = rng('ledcube31'), on = isOn(S), T = on ? 6 : 12, COLS = ['#ff5aa8', '#ffae48', '#9a6aff', '#ff7a68'], H = 40;
        const cyc = i => an('opacity', rep(COLS.length + 1, j => (j % COLS.length) === i ? 0.8 : 0).join(';'), T, 0, SPL(COLS.length));
        let s = shadow(C, 0, 0, 24, 24, 0.25);
        const fl = C.P([0, 0, 0]); s += `<ellipse cx="${f1(fl[0])}" cy="${f1(fl[1])}" rx="${f1(40 * k)}" ry="${f1(22 * k)}" fill="${COLS[0]}" opacity="${on ? 0.42 : 0.3}" filter="url(#g31b3)">${an('fill', COLS.concat(COLS[0]).join(';'), T)}</ellipse>`;
        const face = w => `<rect width="${w}" height="${H}" fill="url(#${id}in)"/><path d="M0 ${f1(H * 0.52)}H${w}" stroke="#ffffff" stroke-width="0.4" opacity="0.35"/>` + rep(3, () => `<path d="M${f1(3 + R() * (w - 6))} ${f1(4 + R() * (H - 8))}l${f1((R() - 0.5) * 5)} ${f1((R() - 0.5) * 1.5)}" stroke="#8a8090" stroke-width="0.3" opacity="0.4"/>`).join('');
        const cube = c => B10(C, { c: [0, 0, 0], w: 44, h: H, d: 44, col: c, r: 4, gl: 0.6, f: 1.18, edge: 0.5, olw: 0.3, olo: 0.4, dec: { f: face(44), b: face(44), l: face(44), r: face(44), t: `<rect width="44" height="44" rx="4" fill="url(#${id}tp)"/>` } });
        s += cube('#f4eef4') + COLS.map((c, i) => `<g opacity="0">${cyc(i)}${cube(c)}</g>`).join('');
        s += PLN(C, H + 0.05, `<circle r="17" fill="#3a3a40"/><circle r="17" fill="url(#m10noise)"/><circle r="16.2" fill="none" stroke="#2a2a30" stroke-width="0.6" stroke-dasharray="0.8 0.8"/><circle r="17" fill="url(#${id}fp)"/>`);
        s += cyl3(C, [0, H, 0], [0, H + 1.4, 0], 17, '#3a3a40', { mat: 'matte', olw: 0.25, noCap: 1 });
        // remote + cable on the floor beside the cube
        const sd = thV(C) + 0.9, rx = Math.cos(sd) * 30, rz = Math.sin(sd) * 30;
        s += B10(C, { c: [rx, 0, rz], ax: [[Math.cos(sd + 1.2), 0, Math.sin(sd + 1.2)], [0, 1, 0], [-Math.sin(sd + 1.2), 0, Math.cos(sd + 1.2)]], w: 4.4, h: 1, d: 10, col: '#1e1e22', r: 1.4, dec: { t: rep(6, i => `<circle cx="${1.2 + (i % 2) * 2}" cy="${f1(2 + Math.floor(i / 2) * 2.4)}" r="0.55" fill="${COLS[i % 4]}" opacity="0.9"/>`).join('') } });
        const pa = Math.cos(sd - 0.5) * 22.2, pz = Math.sin(sd - 0.5) * 22.2; s += line3(C, [[pa, 3, pz], [pa * 1.12, 0.4, pz * 1.12], [pa * 1.3, 0.4, pz * 1.18], [pa * 1.45, 0.4, pz * 1.05]], 0.7, '#e8e8ec');
        C.p(-23, 0, -23); C.p(23, 0, 23); C.p(23, 0, -23); C.p(-23, 0, 23); C.p(0, H + 2, 0);
        const defs = DEFG + `<defs><radialGradient id="${id}in" cx="50%" cy="55%" r="60%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}tp" cx="50%" cy="50%" r="60%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.4"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}fp" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="1" stop-color="#000000" stop-opacity="0.15"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-079 SCULPTED GOLD-WIREFRAME & BLACK VELVET HIGH BARSTOOL (T4): a designer barstool whose base is a twisting hourglass lattice of
    // polished gold rods between a floor ring and a seat ring, with a separate gold foot ring on four short spokes, under a domed black velvet
    // seat with a gold piped edge. Live: a glint runs along the gold rods and a soft sheen drifts across the velvet.
    N.wirestool31 = S => { const D = { w: 44, d: 44, round: 1, act: 'sit', seats: [{ x: 0, z: 0, h: 71 }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('w79'), GD = '#d4a640', TY = 60, V = C.v, tv = thV(C), NW = 9;
        let s = shadow(C, 0, 0, 20, 20, 0.35);
        const rAt = y => { const t = Math.abs(y - 30) / 30; return 6.5 + (y < 30 ? 10.5 : 7.5) * Math.pow(t, 1.5); };
        const wire = (a0, tw) => rep(21, j => { const t = j / 20, y = 1 + t * (TY - 1.5), a = a0 + tw * t, r = rAt(y); return [Math.cos(a) * r, y, Math.sin(a) * r]; });
        const W = []; [1.1, -1.1].forEach(tw => rep(NW, i => { const a0 = i / NW * 2 * PI + (tw > 0 ? 0 : PI / NW), P = wire(a0, tw), m = P[10]; W.push({ d: m[0] * V[0] + m[2] * V[2], P }); }));
        const rod = (P, gl) => line3(C, P, 0.9, '#9a7420') + line3(C, P, 0.55, GD) + line3(C, P, 0.2, '#fff0c0', 'opacity="0.7"') + (gl ? `<path d="M${P.map(p => P2(C.P(p))).join('L')}" fill="none" stroke="#fffbe8" stroke-width="${f1(0.7 * k)}" stroke-linecap="round" pathLength="100" stroke-dasharray="5 95" opacity="0.9"><animate attributeName="stroke-dashoffset" values="0;-100" dur="4s" begin="${n4(-gl)}s" repeatCount="indefinite"/></path>` : '');
        const ring = (y, r, w) => { const P = rep(41, i => [Math.cos(i / 40 * 2 * PI) * r, y, Math.sin(i / 40 * 2 * PI) * r]); return line3(C, P, w, '#9a7420') + line3(C, P, w * 0.6, GD) + line3(C, P, w * 0.2, '#fff0c0', 'opacity="0.7"'); };
        const FY = 22, FR2 = 15, spokes = rep(4, i => { const a = PI / 4 + i * PI / 2, r0 = rAt(FY); return { d: Math.cos(a) * V[0] + Math.sin(a) * V[2], s: rod([[Math.cos(a) * r0, FY, Math.sin(a) * r0], [Math.cos(a) * FR2, FY, Math.sin(a) * FR2]]) }; });
        W.sort((a, b) => a.d - b.d);
        s += ring(0.6, 17, 1.6) + W.filter(w => w.d < 0).map(w => rod(w.P)).join('') + spokes.filter(q => q.d < 0).map(q => q.s).join('') + ring(FY, FR2, 1.3)
          + W.filter(w => w.d >= 0).map((w, i) => rod(w.P, i % 3 === 0 ? i * 0.7 : 0)).join('') + spokes.filter(q => q.d >= 0).map(q => q.s).join('');
        s += cyl3(C, [0, TY - 1.5, 0], [0, TY + 2.6, 0], 14.6, GD, { mat: 'metal', olw: 0.25, r2: 15.6 });
        const seat = r => `<circle r="${n4(r)}" fill="#1c1a20"/><circle r="${n4(r)}" fill="url(#${id}vv)"/><circle r="${n4(r - 0.7)}" fill="none" stroke="${GD}" stroke-width="0.7"/><circle r="${n4(r - 1.3)}" fill="none" stroke="#0c0a10" stroke-width="0.5"/>`
          + `<ellipse cx="-3" cy="-3" rx="${n4(r * 0.55)}" ry="${n4(r * 0.4)}" fill="#ffffff" opacity="0.07"><animate attributeName="cx" values="-4;3;-4" dur="8s" repeatCount="indefinite"/></ellipse>`;
        s += cyl3(C, [0, TY + 2.6, 0], [0, TY + 11, 0], 16.2, '#24222a', { mat: 'gloss', olw: 0.25, r2: 13.6, cap: seat });
        s += line3(C, rep(21, i => { const a = tv - PI / 2 + i * PI / 20; return [Math.cos(a) * 16.25, TY + 3, Math.sin(a) * 16.25]; }), 0.8, GD);
        C.p(-18, 0, -18); C.p(18, 0, 18); C.p(18, 0, -18); C.p(-18, 0, 18); C.p(-16, TY + 11, 0); C.p(16, TY + 11, 0);
        const defs = `<defs><radialGradient id="${id}vv" cx="40%" cy="35%" r="75%"><stop offset="0" stop-color="#4a4452" stop-opacity="0.6"/><stop offset="0.5" stop-color="#2a2630" stop-opacity="0.2"/><stop offset="1" stop-color="#000000" stop-opacity="0.4"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-099 SOUND-PULSING LEVITATING MAGNETIC LOUNGE POD (T5): a round lounge pod in tufted cognac leather, cradled in a polished brass bowl,
    // hovering above a walnut magnetic base with a brass ring and a black onyx top that glows warm in the gap. Keeps party + glow. Live: the pod
    // bobs, the warm gap light breathes with it, and gold sound rings ripple out across the floor from the base (faster when the party is on).
    N.magpod31 = S => { const D = { w: 46, d: 46, act: 'sit', party: 1, seats: [{ x: 0, z: 0, h: 42 }], glow: () => ({ y: 20, r: 50, c: 'url(#gNeon)' }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('m99'), on = isOn(S), BR = '#c99a48', CG = '#9a5428', T = on ? 1.6 : 2.6, BT = 3.2;
        let s = shadow(C, 0, 0, 22, 22, 0.3);
        s += PLN(C, 0.1, rep(3, i => `<circle r="19" fill="none" stroke="#e8c070" stroke-width="0.8" opacity="0">${an('r', '19;34', T * 1.5, -i * T / 2)}${an('opacity', '0.8;0', T * 1.5, -i * T / 2)}</circle>`).join(''));
        // magnetic base: walnut drum, brass band, onyx top with a warm glow
        s += cyl3(C, [0, 0, 0], [0, 4.2, 0], 19, '#5a3420', { mat: 'gloss', olw: 0.3, noCap: 1, r2: 18.4 }) + cyl3(C, [0, 4.2, 0], [0, 5.2, 0], 18.4, BR, { mat: 'metal', olw: 0.2, noCap: 1 });
        s += cyl3(C, [0, 5.2, 0], [0, 5.6, 0], 17.6, '#141216', { mat: 'gloss', olw: 0.2, capCol: '#18161a', cap: r => `<circle r="${n4(r)}" fill="url(#${id}gw)">${an('opacity', '1;0.6;1', BT, 0, SPL(2))}</circle><path d="M-12 -4q6 3 14 -1t9 5" stroke="#c8c0b8" stroke-width="0.25" fill="none" opacity="0.4"/><circle r="${n4(r - 0.6)}" fill="none" stroke="${BR}" stroke-width="0.5"/>` });
        const gq = C.P([0, 10, 0]); s += `<ellipse cx="${f1(gq[0])}" cy="${f1(gq[1])}" rx="${f1(18 * k)}" ry="${f1(9 * k)}" fill="#ffc870" opacity="0.45" filter="url(#g31b3)">${an('opacity', '0.4;0.2;0.4', BT, 0, SPL(2))}</ellipse>`;
        // the hovering pod: brass bowl + tufted cognac leather cushion
        const tuft = r => `<circle r="${n4(r)}" fill="url(#${id}lt)"/>` + rep(8, i => { const a = i / 8 * 2 * PI; return `<path d="M${f1(Math.cos(a) * 3)} ${f1(Math.sin(a) * 3)}L${f1(Math.cos(a) * (r - 1.2))} ${f1(Math.sin(a) * (r - 1.2))}" stroke="#5a2c10" stroke-width="0.6" opacity="0.7"/><circle cx="${f1(Math.cos(a + PI / 8) * r * 0.55)}" cy="${f1(Math.sin(a + PI / 8) * r * 0.55)}" r="0.7" fill="#4a220a"/>`; }).join('')
          + `<circle r="3" fill="#7a3e18"/><circle r="1" fill="#3a1a08"/><circle r="${n4(r - 0.6)}" fill="none" stroke="#e8b878" stroke-width="0.4" opacity="0.6"/><circle r="${n4(r)}" fill="url(#${id}hl)"/>`;
        let pod = cyl3(C, [0, 15, 0], [0, 17.6, 0], 7, BR, { mat: 'metal', olw: 0.25, r2: 13.5, noCap: 1 }) + cyl3(C, [0, 17.6, 0], [0, 25, 0], 13.5, BR, { mat: 'metal', olw: 0.3, r2: 18.6, noCap: 1 }) + cyl3(C, [0, 25, 0], [0, 31, 0], 18.6, BR, { mat: 'metal', olw: 0.3, r2: 19.4, noCap: 1 });
        pod += cyl3(C, [0, 30.4, 0], [0, 31.4, 0], 19.6, '#e0b866', { mat: 'metal', olw: 0.2, noCap: 1 });
        pod += cyl3(C, [0, 31.4, 0], [0, 36, 0], 19, CG, { mat: 'gloss', olw: 0.3, r2: 18.4, noCap: 1 }) + cyl3(C, [0, 36, 0], [0, 42, 0], 18.4, CG, { mat: 'gloss', olw: 0.3, r2: 15.4, cap: tuft });
        pod += line3(C, rep(21, i => { const a = thV(C) - PI / 2 + i * PI / 20; return [Math.cos(a) * 18.7, 36, Math.sin(a) * 18.7]; }), 0.7, '#5a2c10', 'opacity="0.7"');
        s += `<g>${at('translate', `0 0;0 ${f1(-2.6 * k)};0 0`, BT, 0, SPL(2))}${pod}</g>`;
        C.p(-20, 0, -20); C.p(20, 0, 20); C.p(20, 0, -20); C.p(-20, 0, 20); C.p(-19, 45, 0); C.p(19, 45, 0);
        const defs = DEFG + `<defs><radialGradient id="${id}gw"><stop offset="0" stop-color="#ffe0a0" stop-opacity="0.75"/><stop offset="0.6" stop-color="#e89a48" stop-opacity="0.25"/><stop offset="1" stop-color="#e89a48" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}lt" cx="45%" cy="40%" r="70%"><stop offset="0" stop-color="#d08a48"/><stop offset="0.7" stop-color="${CG}"/><stop offset="1" stop-color="#6a3414"/></radialGradient>`
          + `<radialGradient id="${id}hl" cx="34%" cy="28%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0.04"/><stop offset="1" stop-color="#000000" stop-opacity="0.15"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // shared: a soft ellipsoid (bean bag) as a lit hull, and a curved shell (hood) as depth-sortable quads
    const egg31 = (C, x, z, r, col, id) => { const H = RD.H10, ry = r * 0.6, rz = r * 0.9, pts = [];
      for (let i = 0; i < 24; i++) for (let j = 0; j <= 8; j++) { const a = i / 24 * 2 * PI, b = -PI / 2 + j / 8 * PI; pts.push(C.P([x + Math.cos(a) * Math.cos(b) * r, ry + Math.sin(b) * ry, z + Math.sin(a) * Math.cos(b) * rz])); }
      const hl = C.P([x - 0.35 * r, ry * 1.75, z - 0.1 * r]);
      return `<defs><radialGradient id="${id}" gradientUnits="userSpaceOnUse" cx="${f1(hl[0])}" cy="${f1(hl[1])}" r="${f1(r * 1.7 * C.k)}"><stop offset="0" stop-color="${shade(col, 1.32)}"/><stop offset="0.45" stop-color="${col}"/><stop offset="1" stop-color="${shade(col, 0.5)}"/></radialGradient></defs><path d="${H.pth(H.hull(pts))}" fill="url(#${id})" stroke="${shade(col, 0.42)}" stroke-width="0.5" stroke-linejoin="round"/>`; };
    const eggPt = (x, z, r, a, b) => [x + Math.cos(a) * Math.cos(b) * r, r * 0.6 + Math.sin(b) * r * 0.6, z + Math.sin(a) * Math.cos(b) * r * 0.9];
    const eggVis = (C, r, a, b) => { const n = nrm([Math.cos(a) * Math.cos(b) / r, Math.sin(b) / (r * 0.6), Math.sin(a) * Math.cos(b) / (r * 0.9)]); return n[0] * C.v[0] + n[1] * C.v[1] + n[2] * C.v[2]; };
    const shell31 = (C, o) => { const L = RD.H10.lit, Q = [], { r0, r1, a0, a1, n, yT, colO, colI, patI } = o, P = (r, b, y) => P2(C.P([Math.cos(b) * r, y, Math.sin(b) * r])), V = C.v;
      const quad = (p, col) => `<path d="M${p.join('L')}Z" fill="${col}" stroke="${col}" stroke-width="0.3"/>`;
      for (let i = 0; i < n; i++) { const b0 = a0 + (a1 - a0) * i / n, b1 = a0 + (a1 - a0) * (i + 1) / n, bm = (b0 + b1) / 2, no = [Math.cos(bm), 0, Math.sin(bm)], h0 = yT(b0), h1 = yT(b1), dO = no[0] * V[0] + no[2] * V[2];
        let s = '';
        if (dO > 0) s += quad([P(r1, b0, 0), P(r1, b1, 0), P(r1, b1, h1), P(r1, b0, h0)], shade(colO, L(C, no)));
        else { const pp = [P(r0, b0, 0), P(r0, b1, 0), P(r0, b1, h1), P(r0, b0, h0)]; s += quad(pp, shade(colI, L(C, [-no[0], 0, -no[2]]))) + (patI ? `<path d="M${pp.join('L')}Z" fill="url(#${patI})"/>` : ''); }
        s += quad([P(r0, b0, h0), P(r0, b1, h1), P(r1, b1, h1), P(r1, b0, h0)], shade(colO, 1.12));
        Q.push({ d: (r0 + r1) / 2 * dO, s }); }
      [a0, a1].forEach(b => { const t = [-Math.sin(b), 0, Math.cos(b)], m = (r0 + r1) / 2; Q.push({ d: m * (Math.cos(b) * V[0] + Math.sin(b) * V[2]) + 0.5, s: quad([P(r0, b, 0), P(r1, b, 0), P(r1, b, yT(b)), P(r0, b, yT(b))], shade(colO, 0.85)) }); });
      return Q; };

    // CLB-020 BEANBAG & FLOOR FAN IN THE CORNER (T1): four mismatched, slumped bean bags where the old pile sat (faded denim vinyl split along a
    // seam and leaking foam beads, brown corduroy, faded red vinyl with a silver tape patch, a small grey fleece one with a stain), a yellowed
    // plastic floor fan on its round base with a dusty guard, its cord snaking to the wall, and a crumpled can on the floor. Seats four.
    // Live: the fan blades spin, and a bead trickles out of the split now and then.
    N.beans31 = S => { const B = [[-52, -18, 32], [44, -24, 30], [-6, 20, 28], [62, 30, 24]], D = { w: 200, d: 130, act: 'sit', seats: B.map(([x, z, r]) => ({ x, z: z + 4, h: r * 0.95 })), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('b20'), R = rng('beans31'), V = C.v, tv = thV(C), L = [];
        const COL = ['#5a7092', '#7a5a3a', '#a8463c', '#8a8a86'];
        B.forEach(([x, z, r], i) => { let s = egg31(C, x, z, r, COL[i], id + 'e' + i);
          const top = r * 1.2; s += PLN(C, top - r * 0.1, `<ellipse rx="${f1(r * 0.5)}" ry="${f1(r * 0.42)}" fill="url(#${id}dn)"/>`, x + r * 0.05, z + 2);
          const seam = (a, w, col, op) => { const P = []; for (let j = 0; j <= 14; j++) { const b = -0.35 + j / 14 * (PI / 2 + 0.3); if (eggVis(C, r, a, b) > 0.06) P.push(eggPt(x, z, r, a, b)); } return P.length > 1 ? line3(C, P, w, col, `opacity="${op}"`) : ''; };
          const ring = (bb, w, col, op) => { const P = []; for (let j = 0; j <= 30; j++) { const a = tv - PI / 2 - 0.2 + j / 30 * (PI + 0.4); P.push(eggPt(x, z, r, a, bb)); } return line3(C, P, w, col, `opacity="${op}"`); };
          s += ring(0.95, 0.6, shade(COL[i], 0.5), 0.75) + ring(0.95, 0.25, shade(COL[i], 1.4), 0.4);
          if (i === 1) s += rep(9, j => seam(tv - 1.2 + j * 0.3, 0.35, shade(COL[1], 0.62), 0.45)).join('');
          s += seam(tv + 0.9, 0.5, shade(COL[i], 0.55), 0.6);
          s += rep(6, () => { const a = tv + (R() - 0.5) * 2.2, b = -0.2 + R() * 0.9; if (eggVis(C, r, a, b) < 0.15) return ''; const p = eggPt(x, z, r, a, b), q = eggPt(x, z, r, a + 0.3, b - 0.18); return line3(C, [p, [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2 + 1.2, (p[2] + q[2]) / 2], q], 0.35, shade(COL[i], 0.6), 'opacity="0.55"'); }).join('');
          if (i === 0) { const a = tv + 0.35, b = 0.15, p = eggPt(x, z, r, a, b), q = eggPt(x, z, r, a + 0.32, b + 0.08), m = [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2 - 1, (p[2] + q[2]) / 2];
            s += line3(C, [p, m, q], 1.3, '#1e2430') + rep(7, () => { const c = C.P([m[0] + (R() - 0.5) * 6, m[1] + (R() - 0.5) * 2, m[2] + (R() - 0.5) * 6]); return `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(0.55 * k)}" fill="#f4f2ee"/>`; }).join('');
            const fp = [Math.cos(a + 0.15) * (r + 6) + x, 0.15, Math.sin(a + 0.15) * (r * 0.9 + 6) + z];
            s += PLN(C, 0.15, rep(22, () => `<circle cx="${f1((R() - 0.5) * 14)}" cy="${f1((R() - 0.5) * 8)}" r="0.6" fill="#f4f2ee" stroke="#c8c4bc" stroke-width="0.12"/>`).join(''), fp[0], fp[2]);
            const mq = C.P(m), fq = C.P([fp[0], 0.6, fp[2]]); s += `<circle r="${f1(0.6 * k)}" fill="#f4f2ee" opacity="0"><animate attributeName="cx" values="${f1(mq[0])};${f1(fq[0])}" dur="3.6s" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(mq[1])};${f1(fq[1])}" dur="3.6s" repeatCount="indefinite" calcMode="spline" keyTimes="0;1" keySplines="0.5 0 1 1"/>${an('opacity', '0;1;1;0', 3.6)}</circle>`; }
          if (i === 2) { const a = tv - 0.5, b = 0.55, O = eggPt(x, z, r, a, b), U = nrm([-Math.sin(a) * r, 0, Math.cos(a) * r * 0.9]), Vd = nrm([Math.cos(a) * Math.sin(b) * r, -Math.cos(b) * r * 0.6, Math.sin(a) * Math.sin(b) * r * 0.9]);
            if (eggVis(C, r, a, b) > 0.1) s += `<g transform="${FR(C, O, U, Vd)}"><rect x="-6" y="-1.8" width="12" height="3.6" fill="#b4b8bc" transform="rotate(28)"/><rect x="-6" y="-1.8" width="12" height="3.6" fill="#c4c8cc" transform="rotate(-24)"/><path d="M-4 -0.6L4 0.6" stroke="#2a1010" stroke-width="0.5" opacity="0.5"/></g>`; }
          if (i === 3) s += PLN(C, r * 1.12, `<path d="${blob(R, 0, 0, 4, 9)}" fill="#5a5048" opacity="0.35"/>`, x - 3, z + 4);
          L.push({ d: x * V[0] + z * V[2], s: shadow(C, x, z, r * 1.05, r * 0.95, 0.35) + s }); });
        // floor fan
        { const fc = [-84, 21, 44], fa = -0.45, F = [Math.cos(fa), 0, Math.sin(fa)], U = [-Math.sin(fa), 0, Math.cos(fa)], WY = '#d8ccae', FB = (d, y) => [fc[0] - F[0] * d, y == null ? fc[1] : y, fc[2] - F[2] * d];
          const base = cyl3(C, FB(4, 0), FB(4, 2.6), 9.5, WY, { mat: 'plastic', olw: 0.3, r2: 8.6 }) + cyl3(C, FB(4, 2.6), FB(7, 15), 1.7, WY, { mat: 'plastic', olw: 0.2 });
          const motor = cyl3(C, FB(2), FB(11), 5.6, WY, { mat: 'plastic', olw: 0.3, r2: 4.4 }) + cyl3(C, FB(7, 21), FB(7, 26.5), 0.9, '#c8c0aa', { olw: 0.15 });
          const blades = `<g>${at('rotate', '0;360', 0.55)}<circle r="13.6" fill="#e8ecee" opacity="0.18"/>` + rep(5, i => `<path d="M0 -2.4C4 -6 6 -12 2 -13.4C-1.5 -13 -2.6 -8 -1.2 -2.6Z" fill="#dfe6ea" stroke="#b8c0c4" stroke-width="0.2" opacity="0.7" transform="rotate(${i * 72})"/>`).join('') + `<circle r="2.8" fill="${WY}" stroke="#a8a090" stroke-width="0.3"/></g>`;
          const guard = `<circle r="15" fill="none" stroke="#b8b09c" stroke-width="1.4"/><circle r="15" fill="none" stroke="#e8e2d0" stroke-width="0.4"/><circle r="11" fill="none" stroke="#d8d2c0" stroke-width="0.35"/><circle r="6.5" fill="none" stroke="#d8d2c0" stroke-width="0.35"/>` + rep(18, i => `<path d="M0 -3.4V-15" stroke="#b8b09c" stroke-width="0.4" transform="rotate(${i * 20})"/>`).join('') + `<circle r="3.4" fill="#d8d2c0"/><circle r="2" fill="#a8a090" opacity="0.5"/>`
            + `<path d="M-12 8.5Q-6 13 0 14.4Q6 13 12 8.5" stroke="#8a8478" stroke-width="1.4" fill="none" opacity="0.35" stroke-dasharray="0.8 0.6"/>`;
          const face = `<g transform="${FR(C, fc, U, [0, -1, 0])}">${blades}${guard}</g>`, front = F[0] * V[0] + F[2] * V[2] > 0;
          const cord = line3(C, [FB(9, 0.4), [-92, 0.4, 30], [-88, 0.4, 6], [-97, 0.4, -20], [-100, 0.4, -40]], 0.8, '#ece6d8');
          L.push({ d: fc[0] * V[0] + fc[2] * V[2], s: shadow(C, fc[0] - F[0] * 4, fc[2] - F[2] * 4, 11, 11, 0.35) + cord + base + (front ? motor + face : face + motor) }); }
        // crumpled can
        L.push({ d: 88 * V[0] + 54 * V[2], s: cyl3(C, [84, 2.1, 52], [91, 2.1, 56], 2.1, '#d87a2a', { mat: 'metal', olw: 0.2, r2: 1.6 }) + line3(C, [[87, 3.8, 53.4], [88, 2.6, 54.4]], 0.4, '#7a3a10') });
        const s = L.sort((a, b) => a.d - b.d).map(o => o.s).join('');
        C.p(-100, 0, -50); C.p(100, 0, 65); C.p(100, 0, -50); C.p(-100, 0, 65); C.p(-84, 37, 44);
        const defs = `<defs><radialGradient id="${id}dn"><stop offset="0" stop-color="#000000" stop-opacity="0.26"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-040 LAVA LAMP & BLACKLIGHT TAPESTRY ALCOVE (T2): a classic rocket-shaped lava lamp (speckled silver base and cap, violet liquid,
    // orange wax) on a cheap black pressboard cube table with a chipped corner, draped in a black-light tapestry throw with a fluorescent
    // mandala and fringe, lit by a little clip-on black-light bulb. Keeps the lamp glow. Live: wax blobs rise, stretch and sink, the tapestry
    // colours pulse under the UV, the black-light flickers now and then.
    N.lava31 = S => { const D = { w: 44, d: 44, round: 1, glow: () => ({ y: 60, r: 70 }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('l40'), R = rng('lava31'), TT = 28.6, V = C.v;
        const UV = ['#ff3ad0', '#7aff4a', '#ffb020', '#c060ff'];
        const mand = (w, h, cx, cy) => `<rect width="${w}" height="${h}" fill="#120e18"/><g transform="translate(${f1(cx)} ${f1(cy)})" opacity="0.9">${an('opacity', '0.75;1;0.75', 4.4, 0, SPL(2))}`
          + rep(4, i => `<circle r="${f1(3 + i * 3.6)}" fill="none" stroke="${UV[i]}" stroke-width="${i % 2 ? 0.6 : 1.1}" stroke-dasharray="${i === 2 ? '1.4 1' : 'none'}"/>`).join('')
          + rep(12, i => `<path d="M0 -4.2Q1.6 -7.6 0 -10.6Q-1.6 -7.6 0 -4.2Z" fill="${UV[i % 4]}" transform="rotate(${i * 30})"/>`).join('') + `<circle r="2" fill="${UV[2]}"/><circle r="0.8" fill="#120e18"/></g>`
          + rep(8, () => `<circle cx="${f1(R() * w)}" cy="${f1(R() * h)}" r="0.6" fill="${UV[Math.floor(R() * 4)]}"/>`).join('');
        const fringe = w => rep(Math.floor(w / 1.2), i => `<path d="M${f1(0.6 + i * 1.2)} 18.8v${f1(1.4 + (i % 3) * 0.5)}" stroke="#2a2232" stroke-width="0.45"/>`).join('');
        const side = w => mand(w, 18.8, w / 2, 7) + fringe(w) + `<path d="M0 0.4H${w}" stroke="#3a3048" stroke-width="0.6"/>`;
        let s = shadow(C, 0, 0, 22, 22, 0.35);
        s += B10(C, { c: [0, 0, 0], w: 30, h: 28, d: 30, col: '#1e1c20', r: 0.4, dec: { f: `<path d="M27 26l3 -3V28H26Z" fill="#c8a878"/>`, r: `<rect x="2" y="24" width="4" height="1.4" fill="#c8a878" opacity="0.8"/>` } });
        s += B10(C, { c: [0, 9.8, 0], w: 31.6, h: 18.8, d: 31.6, col: '#120e18', r: 0.6, edge: 0, dec: { f: side(31.6), b: side(31.6), l: side(31.6), r: side(31.6), t: mand(31.6, 31.6, 15.8, 15.8) } });
        // clip-on blacklight bulb at the back corner
        const bc = [-13.5, TT + 0.6, -13.5]; s += cyl3(C, bc, [bc[0] + 1.5, TT + 6, bc[2] + 1.5], 0.6, '#1a1a1c', { olw: 0.1 }) + cyl3(C, [bc[0] + 1.5, TT + 6, bc[2] + 1.5], [bc[0] + 3.2, TT + 8.4, bc[2] + 3.2], 1.2, '#1a1a1c', { olw: 0.12, r2: 3.6, noCap: 1 });
        const bq = C.P([bc[0] + 3.4, TT + 8.4, bc[2] + 3.4]);
        s += `<circle cx="${f1(bq[0])}" cy="${f1(bq[1])}" r="${f1(16 * k)}" fill="#8a40ff" opacity="0.22" filter="url(#g31b3)">${an('opacity', '0.22;0.22;0.08;0.24;0.22', 7, 0, ' keyTimes="0;0.8;0.82;0.85;1"')}</circle><circle cx="${f1(bq[0])}" cy="${f1(bq[1])}" r="${f1(2.2 * k)}" fill="#c8a0ff"/>`;
        // lava lamp
        const axis = y => C.P([0, y, 0]);
        s += cyl3(C, [0, TT, 0], [0, TT + 11, 0], 6.6, '#b8bcc4', { mat: 'metal', olw: 0.3, r2: 3.6, pat: 'm10noise' });
        s += cyl3(C, [0, TT + 11, 0], [0, TT + 19, 0], 3.8, '#6a2088', { mat: 'gloss', olw: 0.25, r2: 5.4, noCap: 1, op: 0.95 }) + cyl3(C, [0, TT + 19, 0], [0, TT + 34, 0], 5.4, '#6a2088', { mat: 'gloss', olw: 0.25, r2: 2.4, noCap: 1, op: 0.95 });
        const g0 = axis(TT + 12), g1 = axis(TT + 33), gx = g0[0], gl = (g1[1] - g0[1]);
        s += `<ellipse cx="${f1(gx)}" cy="${f1(g0[1] - 0.6 * k)}" rx="${f1(3.4 * k)}" ry="${f1(1.4 * k)}" fill="#ff8a3a"/>`;
        s += [[0.15, 0.85, 17, 0, 2.2], [0.3, 0.7, 13, -6, 1.6], [0.1, 0.55, 21, -11, 1.3]].map(([a, b, T, bg, rr]) => `<ellipse cx="${f1(gx)}" cy="${f1(g0[1] + gl * a)}" rx="${f1(rr * k)}" ry="${f1(rr * 1.2 * k)}" fill="#ff8a3a" stroke="#ffb070" stroke-width="0.3">`
          + `<animate attributeName="cy" values="${f1(g0[1] + gl * a)};${f1(g0[1] + gl * b)};${f1(g0[1] + gl * a)}" dur="${T}s" begin="${bg}s" repeatCount="indefinite"${SPL(2)}/><animate attributeName="ry" values="${f1(rr * 1.2 * k)};${f1(rr * 1.8 * k)};${f1(rr * 1.1 * k)};${f1(rr * 1.2 * k)}" dur="${T / 2}s" begin="${bg}s" repeatCount="indefinite"/></ellipse>`).join('');
        s += line3(C, [[-3.6, TT + 13, 1], [-4.8, TT + 21, 1.2], [-2.4, TT + 31, 0.6]], 0.5, '#ffffff', 'opacity="0.45"');
        s += cyl3(C, [0, TT + 34, 0], [0, TT + 39, 0], 2.4, '#b8bcc4', { mat: 'metal', olw: 0.25, r2: 1.5, pat: 'm10noise' });
        s += line3(C, [[3, TT + 2, -4], [8, TT + 0.4, -10], [14, TT - 2, -15.6], [15.2, 4, -15.6], [16, 0.4, -18], [22, 0.4, -22]], 0.6, '#1a1a1c');
        C.p(-22, 0, -22); C.p(22, 0, 22); C.p(22, 0, -22); C.p(-22, 0, 22); C.p(0, TT + 40, 0);
        return { defs: DEFG, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-060 SOUND-DAMPENED VELVET POD WITH OXYGEN BAR (T3): a round emerald-velvet drum seat on a brass ring, wrapped by a tall curved hood
    // (emerald velvet outside, charcoal acoustic felt inside, brass-piped rim). On the inside back wall, a little walnut oxygen bar: three glass
    // aroma flasks (amber, rose, mint) with clear tubes looping to a hanging nose cannula, lit by a warm strip underneath. Keeps party + glow.
    // Live: bubbles rise in the flasks and the under-shelf light breathes.
    N.vpod31 = S => { const D = { w: 46, d: 46, act: 'sit', party: 1, seats: [{ x: 0, z: 0, h: 42 }], glow: () => ({ y: 20, r: 50, c: 'url(#gNeon)' }), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('v60'), V = C.v, EM = '#1f5a44', BR = '#c99a48', a0 = PI - 0.55, a1 = 2 * PI + 0.55, yT = b => 74 + 24 * Math.max(0, -Math.sin(b));
        let s = shadow(C, 0, 0, 24, 24, 0.4);
        const Q = shell31(C, { r0: 20.4, r1: 23, a0, a1, n: 20, yT, colO: EM, colI: '#3a3a40', patI: id + 'ft' });
        // seat
        const tuft = r => `<circle r="${n4(r)}" fill="url(#${id}vv)"/>` + rep(10, i => `<path d="M0 0L${f1(Math.cos(i / 10 * 2 * PI) * (r - 1))} ${f1(Math.sin(i / 10 * 2 * PI) * (r - 1))}" stroke="#0e3a2a" stroke-width="0.5" opacity="0.7"/>`).join('') + `<circle r="1.4" fill="${BR}"/><circle r="${n4(r - 0.6)}" fill="none" stroke="${BR}" stroke-width="0.5"/>`;
        Q.push({ d: 0, s: cyl3(C, [0, 0, 0], [0, 3.5, 0], 18.2, BR, { mat: 'metal', olw: 0.25 }) + cyl3(C, [0, 3.5, 0], [0, 36, 0], 17.2, EM, { mat: 'matte', olw: 0.3 }) + cyl3(C, [0, 36, 0], [0, 42, 0], 17.8, EM, { mat: 'gloss', olw: 0.3, r2: 16.6, cap: tuft }) });
        // oxygen bar on the inside back wall
        { const zb = -17.2, LQ = ['#e8a040', '#e86a8a', '#8ad070']; let o = B10(C, { c: [0, 60, zb], w: 19, h: 1.4, d: 5, col: '#6a4024', r: 0.4 });
          const lq = C.P([0, 59.4, zb]); o = `<ellipse cx="${f1(lq[0])}" cy="${f1(lq[1])}" rx="${f1(12 * k)}" ry="${f1(4 * k)}" fill="#ffd590" opacity="0.4" filter="url(#g31b1)">${an('opacity', '0.4;0.65;0.4', 4, 0, SPL(2))}</ellipse>` + o;
          [-6, 0, 6].forEach((x, i) => { o += cyl3(C, [x, 61.4, zb], [x, 67.4, zb], 2.1, LQ[i], { mat: 'gloss', olw: 0.2, op: 0.85, r2: 2.3 }) + cyl3(C, [x, 67.4, zb], [x, 70, zb], 0.8, '#e8eef0', { mat: 'gloss', olw: 0.15, op: 0.8 });
            const b0 = C.P([x, 62.4, zb + 1.8]), b1 = C.P([x, 66.8, zb + 1.8]); o += rep(3, j => `<circle cx="${f1(b0[0] + (j - 1) * 0.6 * k)}" cy="${f1(b0[1])}" r="${f1(0.4 * k)}" fill="#ffffff" opacity="0">${an('cy', `${f1(b0[1])};${f1(b1[1])}`, 1.8, -j * 0.6 - i * 0.3)}${an('opacity', '0;0.9;0', 1.8, -j * 0.6 - i * 0.3)}</circle>`).join(''); });
          o += line3(C, [[-6, 70, zb], [-6, 71.6, zb + 1], [-2, 70, zb + 3], [0, 58, zb + 4], [-1.4, 52, zb + 4.4], [1.4, 52, zb + 4.4], [0, 58, zb + 4]], 0.45, '#e8f0f0', 'opacity="0.7"') + line3(C, [[0, 70, zb], [0, 71.4, zb + 1.4], [0.6, 68, zb + 3.4]], 0.45, '#e8f0f0', 'opacity="0.7"') + line3(C, [[6, 70, zb], [6, 71.6, zb + 1], [2, 70, zb + 3]], 0.45, '#e8f0f0', 'opacity="0.7"');
          o += cyl3(C, [8.6, 60.7, zb + 2.4], [8.6, 60.7, zb + 3.4], 0.9, BR, { mat: 'metal', olw: 0.12 });
          Q.push({ d: zb * V[2] + 0.2, s: o }); }
        s += Q.sort((a, b) => a.d - b.d).map(o => o.s).join('');
        s += line3(C, rep(41, i => { const b = a0 + (a1 - a0) * i / 40; return [Math.cos(b) * 23.1, yT(b) + 0.2, Math.sin(b) * 23.1]; }), 1, BR) + line3(C, rep(41, i => { const b = a0 + (a1 - a0) * i / 40; return [Math.cos(b) * 23.1, yT(b) + 0.4, Math.sin(b) * 23.1]; }), 0.3, '#ffe8b8', 'opacity="0.6"');
        C.p(-23, 0, -23); C.p(23, 0, 23); C.p(23, 0, -23); C.p(-23, 0, 23); C.p(0, 99, -23);
        const defs = DEFG + `<defs><pattern id="${id}ft" width="3" height="3" patternUnits="userSpaceOnUse"><path d="M0 1.5L1.5 0L3 1.5L1.5 3Z" fill="#000000" fill-opacity="0.18"/><circle cx="1.5" cy="1.5" r="0.3" fill="#ffffff" fill-opacity="0.08"/></pattern>`
          + `<radialGradient id="${id}vv" cx="40%" cy="35%" r="75%"><stop offset="0" stop-color="#3a8a6a"/><stop offset="0.6" stop-color="${EM}"/><stop offset="1" stop-color="#0e3a2a"/></radialGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-080 BACKSTAGE STAR DRESSING NOOK WITH LIGHTED MIRROR & MINI-FRIDGE (T4): a Hollywood-regency chaise longue in dusty-rose velvet
    // (channel-tufted half back, rolled arm at the head, champagne satin bolster, ivory faux-fur throw over the foot, gold tapered legs and a
    // brass base rim) where the old chaise lay (same nap spot). At the foot end a cream glass-door mini-fridge (warm-lit shelves of little
    // bottles, brass handle, gold star on the door) carries a black lacquer bulb-framed dressing mirror, a perfume bottle and a lipstick.
    // Live: the mirror bulbs glow in a slow ripple, a glint slides over the mirror and a soft sheen drifts over the velvet.
    N.dressnook31 = S => { const D = { w: 176, d: 74, act: 'nap', seats: [{ x: 14, z: 2, h: 32, k: 'nap' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('d80'), V = C.v, VR = '#c98a92', GD = '#d0a248', L = [];
        const vel = (w, h) => `<rect width="${f1(w)}" height="${f1(h)}" fill="url(#${id}sh)"/>`;
        // ---- chaise
        let ch = shadow(C, -13, 4, 80, 34, 0.35);
        const LEGS = [[-84, -24], [-84, 32], [-13, -24], [-13, 32], [58, -24], [58, 32]].sort((a, b) => (a[0] * V[0] + a[1] * V[2]) - (b[0] * V[0] + b[1] * V[2]));
        ch += LEGS.map(([x, z]) => cyl3(C, [x, 0, z], [x, 7.2, z], 1.2, GD, { mat: 'metal', olw: 0.2, r2: 2 }) + cyl3(C, [x, 0, z], [x, 0.8, z], 1.3, '#a07a30', { olw: 0.1 })).join('');
        ch += B10(C, { c: [-13, 7, 4], w: 148, h: 1.6, d: 62, col: GD, r: 1, mat: 'brush', gl: 0.5 });
        ch += B10(C, { c: [-13, 8.6, 4], w: 146, h: 12.4, d: 60, col: VR, r: 3, dec: { f: vel(146, 12.4), b: vel(146, 12.4), r: vel(60, 12.4), l: vel(60, 12.4) } });
        const back = B10(C, { c: [-56, 21, -22], w: 62, h: 25, d: 10, col: VR, r: 4, dec: { f: vel(62, 25) + rep(7, i => `<path d="M${f1(7.75 * (i + 1))} 2V25" stroke="#8a4a54" stroke-width="0.6" opacity="0.7"/>`).join(''), b: vel(62, 25), t: `<rect width="62" height="10" fill="url(#${id}sh)"/>` } });
        const cush = B10(C, { c: [-10, 21, 4], w: 140, h: 11.6, d: 58, col: VR, r: 5.5, dec: { t: vel(140, 58) + rep(10, i => `<path d="M${f1(12.7 * (i + 1))} 3V55" stroke="#8a4a54" stroke-width="0.5" opacity="0.55"/>`).join('') + `<rect x="1" y="1" width="138" height="56" rx="5" fill="none" stroke="#e8b8bc" stroke-width="0.4" opacity="0.6"/>`, f: vel(140, 11.6) + `<path d="M3 1H137" stroke="#e8b8bc" stroke-width="0.5" opacity="0.7"/>` } });
        const arm = cyl3(C, [-83, 30, -27], [-83, 30, 35], 11, VR, { mat: 'matte', olw: 0.3, cap: r => `<circle r="${n4(r)}" fill="#b47680"/>` + rep(6, i => `<path d="M0 0L${f1(Math.cos(i / 6 * 2 * PI) * r * 0.9)} ${f1(Math.sin(i / 6 * 2 * PI) * r * 0.9)}" stroke="#8a4a54" stroke-width="0.5"/>`).join('') + `<circle r="1.6" fill="${GD}"/>` });
        const bol = cyl3(C, [-67, 38.6, -18], [-67, 38.6, 26], 5.8, '#e8d2a8', { mat: 'gloss', olw: 0.3, cap: r => `<circle r="${n4(r)}" fill="#e0c690"/><circle r="1.4" fill="${GD}"/>` });
        const fur = B10(C, { c: [44, 20.8, 4], w: 24, h: 13.2, d: 60.6, col: '#f2ece2', r: 3, dec: { t: `<rect width="24" height="60.6" fill="url(#${id}fz)"/>`, f: `<rect width="24" height="13.2" fill="url(#${id}fz)"/>` + rep(16, i => `<path d="M${f1(i * 1.55)} 13.2l0.4 ${f1(1.2 + (i % 3) * 0.6)}" stroke="#f2ece2" stroke-width="0.6" stroke-linecap="round"/>`).join(''), b: `<rect width="24" height="13.2" fill="url(#${id}fz)"/>`, r: `<rect width="60.6" height="13.2" fill="url(#${id}fz)"/>`, l: `<rect width="60.6" height="13.2" fill="url(#${id}fz)"/>` } });
        const bk = V[2] >= 0, armFar = V[0] > 0;
        ch += (bk ? back : '') + (armFar ? arm : '') + cush + (bk ? '' : back) + fur + bol + (armFar ? '' : arm);
        L.push({ d: -13 * V[0] + 4 * V[2], s: ch });
        // ---- mini-fridge with mirror
        { const fx = 76, fz = -1, FH = 32; let f = shadow(C, fx, fz, 14, 18, 0.35);
          const door = `<rect width="23" height="${FH}" fill="#efe4cc"/><rect x="1.6" y="2" width="19.8" height="${FH - 5.6}" rx="1" fill="url(#${id}gl)"/>` + [10, 18].map(y => `<path d="M2.4 ${y}H20.6" stroke="#c8a060" stroke-width="0.4" opacity="0.8"/>` + rep(5, j => `<rect x="${f1(3.6 + j * 3.4)}" y="${f1(y - 5.6 - (j % 2))}" width="1.8" height="${f1(5.6 + (j % 2))}" rx="0.7" fill="${['#3a5a2a', '#e8d090', '#8a2a3a'][j % 3]}" opacity="0.85"/>`).join('')).join('')
            + `<rect x="1.6" y="2" width="19.8" height="${FH - 5.6}" rx="1" fill="url(#${id}gs)"/><rect x="1.6" y="2" width="19.8" height="${FH - 5.6}" rx="1" fill="none" stroke="${GD}" stroke-width="0.8"/><rect x="19.4" y="6" width="1.1" height="14" rx="0.5" fill="${GD}"/>`
            + `<path d="M5 6.4l0.7 1.5l1.6 0.2l-1.2 1.1l0.3 1.6l-1.4 -0.8l-1.4 0.8l0.3 -1.6l-1.2 -1.1l1.6 -0.2Z" fill="${GD}" transform="translate(0 -1.4)"/><rect y="${FH - 3}" width="23" height="3" fill="#2a2420"/>`;
          const sideF = w => `<rect width="${w}" height="${FH}" fill="url(#${id}sh)" opacity="0.4"/><rect y="${FH - 3}" width="${w}" height="3" fill="#2a2420"/>`;
          f += B10(C, { c: [fx, 0, fz], w: 23, h: FH, d: 30, col: '#efe4cc', r: 1.6, gl: 0.6, dec: { f: door, l: sideF(30), r: sideF(30), b: sideF(23) } });
          f += B10(C, { c: [fx, FH, fz], w: 24, h: 0.8, d: 31, col: GD, r: 0.6, mat: 'brush' });
          // mirror on top
          const mz = fz - 11, my = FH + 0.8, MW = 22, MH = 26;
          const mir = `<rect width="${MW}" height="${MH}" rx="1.4" fill="#1c1a1c"/><rect x="3" y="3" width="${MW - 6}" height="${MH - 6}" fill="url(#${id}mr)"/><path d="M-6 -6L4 -6L-6 20Z" fill="#ffffff" opacity="0.18"><animateTransform attributeName="transform" type="translate" values="0 0;${MW + 8} 0;${MW + 8} 0" keyTimes="0;0.4;1" dur="7s" repeatCount="indefinite"/></path>`;
          f += B10(C, { c: [fx, my, mz], w: MW, h: MH, d: 2.4, col: '#1c1a1c', r: 0.8, gl: 0.8, dec: { f: `<clipPath id="${id}mc"><rect x="3" y="3" width="${MW - 6}" height="${MH - 6}"/></clipPath>` + mir.replace(`<path d="M-6`, `<g clip-path="url(#${id}mc)"><path d="M-6`).replace('</path>', '</path></g>') } });
          f += B10(C, { c: [fx, FH + 0.8, mz + 2.6], w: 10, h: 1.4, d: 3, col: '#1c1a1c', r: 0.4, ax: [[1, 0, 0], [0, Math.cos(0.5), -Math.sin(0.5)], [0, Math.sin(0.5), Math.cos(0.5)]] });
          const BP = []; rep(4, i => BP.push([fx - 7.5 + i * 5, my + MH - 1.5])); rep(3, i => { BP.push([fx - MW / 2 + 1.5, my + MH - 7 - i * 6.5]); BP.push([fx + MW / 2 - 1.5, my + MH - 7 - i * 6.5]); });
          const front = V[2] >= 0;
          if (front) f += BP.map(([x, y], i) => { const q = C.P([x, y, mz + 1.6]); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(3 * k)}" fill="#ffd890" opacity="0.35" filter="url(#g31b1)">${an('opacity', '0.25;0.55;0.25', 3.6, -i * 0.3, SPL(2))}</circle>` + sph(C, [x, y, mz + 1.6], 1.25, '#fff2d0'); }).join('');
          f += cyl3(C, [fx - 6, FH + 0.8, fz + 9], [fx - 6, FH + 6.4, fz + 9], 2.2, '#e8a8b4', { mat: 'gloss', olw: 0.2, op: 0.85, n: 8 }) + cyl3(C, [fx - 6, FH + 6.4, fz + 9], [fx - 6, FH + 8.4, fz + 9], 1.2, GD, { mat: 'metal', olw: 0.15 });
          f += cyl3(C, [fx + 4, FH + 0.8, fz + 10], [fx + 4, FH + 4.6, fz + 10], 1, GD, { mat: 'metal', olw: 0.15 }) + cyl3(C, [fx + 4, FH + 4.6, fz + 10], [fx + 4, FH + 6.4, fz + 10], 0.7, '#b8202c', { mat: 'gloss', olw: 0.12, r2: 0.4 });
          L.push({ d: fx * V[0] + fz * V[2], s: f }); }
        const s = L.sort((a, b) => a.d - b.d).map(o => o.s).join('');
        C.p(-88, 0, -37); C.p(88, 0, 37); C.p(88, 0, -37); C.p(-88, 0, 37); C.p(76, 60, -12);
        const defs = DEFG + `<defs><linearGradient id="${id}sh" x1="0" y1="0" x2="1" y2="0.4"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.45" stop-color="#ffe8ec" stop-opacity="0.22"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#5a2a32" stop-opacity="0.18"/><animate attributeName="x1" values="-0.4;0.4;-0.4" dur="9s" repeatCount="indefinite"/></linearGradient>`
          + `<pattern id="${id}fz" width="2.4" height="2.4" patternUnits="userSpaceOnUse"><rect width="2.4" height="2.4" fill="#f2ece2"/><path d="M0.4 2L1 0.6M1.6 2.2L2.1 0.9" stroke="#d8cebe" stroke-width="0.35" stroke-linecap="round"/><path d="M1.1 1.6L1.5 0.4" stroke="#ffffff" stroke-width="0.35" stroke-linecap="round"/></pattern>`
          + `<linearGradient id="${id}gl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe6b0"/><stop offset="1" stop-color="#b8844a"/></linearGradient>`
          + `<linearGradient id="${id}gs" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.35"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>`
          + `<linearGradient id="${id}mr" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4ece0"/><stop offset="0.5" stop-color="#c8c0b4"/><stop offset="1" stop-color="#e8ddc8"/></linearGradient></defs>`;
        return { defs, front: s, bb: C.bb(3) }; };
      return D; };

    // CLB-100 ZERO-G CHILL-OUT SENSORY DEPRIVATION & HYDRATION LOUNGE (T5): an ivory lacquer float pod - a long egg-shaped shell with a brass
    // rim, filled with warm amber-lit water and a floating neck pillow - hovering over a black marble oval plinth with a brass edge, plus a slim
    // brass hydration stand at the foot holding a carafe of infused water (citrus slices and mint) and a glass. Same nap spot (on the water).
    // Live: the pod bobs, the plinth glow breathes with it, slow ripples spread across the water and light shimmers on its surface.
    N.floatpod31 = S => { const D = { w: 176, d: 74, act: 'nap', seats: [{ x: 14, z: 2, h: 32, k: 'nap' }], build: () => [] };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('z100'), R = rng('floatpod31'), V = C.v, BR = '#c99a48', IV = '#f0e8da', H = RD.H10;
        const cx = -6, cz = 2, RX = 78, RZ = 34, CY = 37, RY = 30, WY = 31;
        let U = shadow(C, cx, cz, 82, 36, 0.22);
        const vein = rep(6, () => `<path d="M${f1((R() - 0.5) * 160)} ${f1((R() - 0.5) * 60)}q${f1((R() - 0.5) * 40)} ${f1((R() - 0.5) * 20)} ${f1((R() - 0.5) * 80)} ${f1((R() - 0.5) * 30)}" stroke="#e8e0d4" stroke-width="0.35" fill="none" opacity="0.25"/>`).join('');
        U += PLN(C, 0.2, `<ellipse rx="84" ry="37" fill="#161417"/><g clip-path="url(#${id}pc)">${vein}</g><ellipse rx="83" ry="36" fill="none" stroke="${BR}" stroke-width="1.2"/><ellipse rx="70" ry="28" fill="url(#${id}gw)">${an('opacity', '1;0.55;1', 4, 0, SPL(2))}</ellipse>`, cx, cz);
        // hydration stand at the foot
        let ST = ''; { const hx = 81, hz = 10; ST += cyl3(C, [hx, 0, hz], [hx, 1, hz], 5.2, BR, { mat: 'metal', olw: 0.2 }) + cyl3(C, [hx, 1, hz], [hx, 30, hz], 1.1, BR, { mat: 'metal', olw: 0.15 }) + cyl3(C, [hx, 30, hz], [hx, 31, hz], 6.4, BR, { mat: 'metal', olw: 0.2 });
          const car = r => `<circle r="${n4(r)}" fill="#e8f0d8" opacity="0.6"/>`;
          ST += cyl3(C, [hx - 1.4, 31, hz - 1.4], [hx - 1.4, 39, hz - 1.4], 2.8, '#f4f0e0', { mat: 'gloss', olw: 0.2, op: 0.5, r2: 2.2, cap: car }) + cyl3(C, [hx - 1.4, 39, hz - 1.4], [hx - 1.4, 42, hz - 1.4], 1.2, '#f4f0e0', { mat: 'gloss', olw: 0.15, op: 0.5 });
          [[0.3, 33, '#f0c040'], [-0.6, 35.5, '#8ac850'], [0.6, 37.2, '#f0a030']].forEach(([o, y, c]) => { const q = C.P([hx - 1.4 + o, y, hz - 1.4 + 1.5]); ST += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(1.4 * k)}" ry="${f1(0.9 * k)}" fill="${c}" opacity="0.85"/>`; });
          ST += cyl3(C, [hx + 2.6, 31, hz + 2.4], [hx + 2.6, 35, hz + 2.4], 1.4, '#f4f0e0', { mat: 'gloss', olw: 0.15, op: 0.5 }); }
        // the pod (bobs)
        const PRO = [[0, 1], [-8, 0.995], [-16, 0.97], [-22, 0.9], [-26, 0.76], [-28.5, 0.55]], pts = []; for (let i = 0; i < 48; i++) PRO.forEach(([dy, sc]) => { const a = i / 48 * 2 * PI; pts.push(C.P([cx + Math.cos(a) * RX * sc, CY + dy, cz + Math.sin(a) * RZ * sc])); });
        const hl = C.P([cx - 20, CY - 4, cz + 20]);
        let s = `<radialGradient id="${id}sg" gradientUnits="userSpaceOnUse" cx="${f1(hl[0])}" cy="${f1(hl[1])}" r="${f1(110 * k)}"><stop offset="0" stop-color="#ffffff"/><stop offset="0.4" stop-color="${IV}"/><stop offset="1" stop-color="#b8ac98"/></radialGradient>`;
        s += `<path d="${H.pth(H.hull(pts))}" fill="url(#${id}sg)" stroke="#a89c88" stroke-width="0.5"/>`;
        s += line3(C, rep(37, i => { const a = i / 36 * 2 * PI; return [cx + Math.cos(a) * RX * 0.985, CY - 12, cz + Math.sin(a) * RZ * 0.985]; }).filter(p => (p[0] - cx) * V[0] / RX + (p[2] - cz) * V[2] / RZ > -0.1), 0.5, BR, 'opacity="0.8"');
        const op = PLN(C, CY, `<ellipse rx="${RX - 3}" ry="${RZ - 3}" fill="#d8ccb6"/>`, cx, cz);
        const wat = `<ellipse rx="${RX - 5}" ry="${RZ - 4.6}" fill="url(#${id}wt)"/>` + rep(3, i => `<ellipse cx="20" cy="0" rx="8" ry="5" fill="none" stroke="#fff4d8" stroke-width="0.5" opacity="0">${an('rx', '8;46', 6, -i * 2)}${an('ry', '5;24', 6, -i * 2)}${an('opacity', '0.7;0', 6, -i * 2)}</ellipse>`).join('')
          + rep(7, () => { const x = (R() - 0.5) * 120, y = (R() - 0.5) * 44; return `<path d="M${f1(x)} ${f1(y)}q3 -1.2 6 0t6 0" stroke="#fff8e0" stroke-width="0.45" fill="none" opacity="0.5">${an('opacity', '0.1;0.7;0.1', 2.4 + R() * 2, -R() * 3)}</path>`; }).join('');
        const wq = PLN(C, WY, wat, cx, cz);
        s += op + `<g clip-path="url(#${id}oc)">${wq}</g>`;
        // clip for the water = the opening outline
        const opn = rep(48, i => { const a = i / 48 * 2 * PI; return P2(C.P([cx + Math.cos(a) * (RX - 3), CY, cz + Math.sin(a) * (RZ - 3)])); });
        // floating neck pillow at the head end
        s += `<g>${at('translate', `0 0;${f1(0.8 * k)} ${f1(-0.4 * k)};0 0`, 5, 0, SPL(2))}` + PLN(C, WY + 2.4, `<ellipse rx="9" ry="13" fill="#e8e0d0" stroke="#c8bca8" stroke-width="0.4"/><ellipse rx="4.5" ry="6.5" fill="#d0c6b2"/><ellipse cx="-2" cy="-3" rx="5" ry="6" fill="#ffffff" opacity="0.4"/>`, cx - 58, cz) + '</g>';
        const rim = rep(61, i => { const a = i / 60 * 2 * PI; return [cx + Math.cos(a) * (RX - 1.2), CY + 0.2, cz + Math.sin(a) * (RZ - 1.2)]; });
        s += line3(C, rim, 2.2, '#9a7428') + line3(C, rim, 1.4, BR) + line3(C, rim, 0.4, '#ffe8b8', 'opacity="0.7"');
        const uq = C.P([cx, 4, cz]); const under = `<ellipse cx="${f1(uq[0])}" cy="${f1(uq[1])}" rx="${f1(56 * k)}" ry="${f1(20 * k)}" fill="#ffcf80" opacity="0.4" filter="url(#g31b3)">${an('opacity', '0.45;0.25;0.45', 4, 0, SPL(2))}</ellipse>`;
        U += under; const SF = V[0] > 0.05; if (!SF) U += ST;
        const front = `<g>${at('translate', `0 0;0 ${f1(-3 * k)};0 0`, 4, 0, SPL(2))}${s}</g>`;
        C.p(-90, 0, -37); C.p(88, 0, 39); C.p(88, 0, -37); C.p(-90, 0, 39); C.p(0, 42, 0); C.p(81, 43, 9);
        const defs = DEFG + `<defs><clipPath id="${id}oc"><path d="M${opn.join('L')}Z"/></clipPath><clipPath id="${id}pc"><ellipse rx="84" ry="37"/></clipPath>`
          + `<radialGradient id="${id}wt" cx="55%" cy="50%" r="60%"><stop offset="0" stop-color="#ffd890"/><stop offset="0.6" stop-color="#e8a050"/><stop offset="1" stop-color="#a86a2a"/></radialGradient>`
          + `<radialGradient id="${id}gw"><stop offset="0" stop-color="#ffd590" stop-opacity="0.5"/><stop offset="1" stop-color="#ffd590" stop-opacity="0"/></radialGradient></defs>`;
        return { defs, under: U, front, over: SF ? ST : '', bb: C.bb(3) }; };
      return D; };
  }

  RD.SET31 = {
    'CLB-005': { f31: 'card', live: 'Tape flutters, dust swirls', note: 'A bare garage slab of grey troweled concrete with saw-cut joints, a hairline crack and oil and drink stains. In the middle lies a breakdance mat of three flattened appliance boxes duct-taped together with silver tape, still printed with arrows and a fragile-glass mark, with dark circular scuffs where heads and backs spun, a sneaker skid and a water ring. One tape strip peels up at the corner, there are chalk marks, and an orange extension cord snakes along the wall. The loose tape end flutters and dust swirls over the spin spot.' },
    'CLB-025': { f31: 'check', live: 'Party lights glide over the tiles', note: 'Budget 12-inch vinyl tiles in a black-and-white checkerboard, the whites gone a little ivory, with dark seams, black heel scuffs and grey skid arcs, a chipped corner showing the grey backing, a lifted tile edge, a sticky soda spill and a glossy polish sheen. Magenta, amber and violet party-light pools glide slowly across it.' },
    'CLB-045': { f31: 'disco', live: 'Squares light up in chase patterns', note: 'A grid of frosted acrylic squares in a black frame, each lit from beneath in strong seventies colours (amber, tangerine, hot pink, violet, gold and lime), the frosting showing a soft hot spot in the middle of each square and the lights glowing over the frame. The squares light up in travelling chase patterns, a diagonal wave and then rows, while the colours swap.' },
    'CLB-065': { f31: 'rgb', live: 'Footstep ripples bloom', note: 'Big panels of smoked black glass over a dense matrix of tiny LED pixels, set in brushed-steel seams. Where feet land, rings of light ripple out pixel by pixel in magenta, amber and violet, a slow warm colour wave rolls across the whole floor, and the glass carries soft reflections.' },
    'CLB-085': { f31: 'lev', live: 'Pads ripple to the bass', note: 'A honeycomb of pearl-white hexagonal pads edged in champagne gold, hovering a hair above a dark energy well, with warm gold light glowing up through the gaps from the harvesters beneath. With every bass beat a ring of pads dips and lifts outward from the centre, golden energy pulses spread through the gaps and sparks race to the edges.' },
    'CLB-017': { spec: 'mat31a', live: 'Oily rainbow sheen shimmers', note: 'A heavy charcoal rubber garage mat with a raised coin-dot grip pattern, faded grey where it has been walked on, a big oil stain with a rainbow sheen, a muddy tyre track across one end, a torn notch in the edge, sawdust and grit, a flattened bottle cap and a scuffed sneaker print. The oily rainbow sheen shimmers.' },
    'CLB-037': { spec: 'run31a', live: 'Blacklight pulses, splatters glow', note: 'A cheap black low-pile carpet runner flicked and spattered with UV paint in hot pink, highlighter yellow, tangerine and lime: big splats with droplets, flick lines and drips, bound with a neon pink edge tape and scuffed grey down the middle. The blacklight pulses and the splatters glow brighter and dimmer with it.' },
    'CLB-057': { spec: 'run31b', live: 'Sheen glides through the plush', note: 'A deep plush faux-fur rug in a warm honey-gold leopard print, with broken black rosettes around amber centres, scattered spots and a dense soft pile with lighter tips, softly rounded corners and fur curling over the edge. A soft sheen glides through the plush.' },
    'CLB-077': { spec: 'run31c', live: 'Glint runs along the silver', note: 'A deep black velvet runner embroidered in metallic silver thread: an art-deco pattern of stepped chevrons and sunburst fans down its length, a fine double guard line, a silver-bound edge and silver tassels at both ends, with crush marks in the velvet where the nap was brushed the other way. A glint travels along the silver threads and the velvet sheen shifts.' },
    'CLB-097': { spec: 'run31d', live: 'Waveform bounces to the beat', note: 'A deep midnight-plum plush rug woven through with fibre-optic strands: a long audio waveform of glowing bars runs down its length in a warm gradient from rose to amber to gold, framed by two thin light lines, with cut fibre ends sparkling through the pile like stars. The waveform bars bounce to the beat, the frame lines pulse and the fibre tips twinkle.' },
    'CLB-001': { s12: 'cl01blk', live: 'Foil glints, a corner flutters', note: 'Grey-painted cinderblock in running bond, the paint thin over the pitted block faces, with deep mortar joints, damp tide marks and white efflorescence near the floor and rust streaks under an old bracket. Spray-paint tags and bubble throw-ups in hot pink, yellow and violet drip down the wall, sheets of crinkled kitchen foil are taped up with silver duct tape to bounce the light, and a party flyer is stapled up. The foil glints as coloured light passes and a loose foil corner flutters.' },
    'CLB-021': { s12: 'cl21foam', live: 'Light wash sweeps the foam', note: 'Walls lined edge to edge with square charcoal acoustic foam panels, each a field of soft pyramids whose faces catch the light differently, glued up a little crooked with gaps, one corner peeling off its glue dab, dust on the tips and a black rubber skirting. A pink and amber party-light wash slowly sweeps across, picking out the pyramid relief.' },
    'CLB-041': { s12: 'cl41brick', live: 'Neon hums and glows', note: 'Warm red-brown brick in running bond, every brick its own shade, with sanded mortar, a few chipped edges and soot-dark headers, the lower courses painted matt black. Two real glass neon tubes run along it on clear clips, a straight hot-pink line up high and an amber wave lower down, their cable dropping to a transformer box, each throwing a soft glow on the brick. The neon hums with a faint flicker and the glow breathes.' },
    'CLB-061': { s12: 'cl61mir', live: 'Equaliser dances, mirrors sparkle', note: 'The upper wall is clad in faceted champagne-tinted mirror tiles, triangles tilted at different angles so each catches the room differently, edged with a slim brushed-bronze rail. Below runs a band of black glass hiding an LED matrix where a sound-reactive equaliser dances in warm pixel bars. The bars bounce to the music and sparkles flash across the mirror facets.' },
    'CLB-081': { s12: 'cl81plas', live: 'Endless tunnel streams, plasma flows', note: 'A wall of deep black glass with a thin champagne-gold line at the skirting. One endless tunnel of glowing rounded frames spans the whole wall, receding to a bright vanishing point, while warm liquid-light plasma in rose, amber, violet and gold flows and merges across the glass. The tunnel frames stream toward you endlessly and the plasma blobs drift, swell and merge.' },
    'CLB-004': { spec: 'stars31', live: 'Stars charge and glow', note: 'A loose spray of cheap pale-green glow-in-the-dark plastic stars, a crescent moon, a ringed planet and a comet stuck straight onto the wall with blobs of white sticky tack, a couple peeling off and one fallen, leaving a grey tack mark. In the dark club they glow a soft yellow-green. The glow charges up under a passing light and slowly fades, and the peeling star curls in the air.' },
    'CLB-024': { spec: 'flam31', live: 'Neon breathes, a letter stutters', note: 'A hand-bent pink neon flamingo standing on one leg, with a coral beak tip and a warm white eye, and \'good vibes\' in looping script beneath in white-pink neon. The glass tubes sit off the wall on a clear acrylic backing cut to shape, fixed with four chrome standoffs, with a black cable running down to a little dimmer. The neon breathes and hums, and now and then the lettering stutters before catching.' },
    'CLB-044': { spec: 'award31', live: 'Light sweeps the grooves', note: 'Three award frames in satin black with a thin silver fillet: a big gold record in the centre and a platinum and a smaller gold either side, each record mounted over its cover-art panel on black suede with a small engraved plaque, the grooves catching the light behind glass, with a brass picture light above the centre frame. Light rings sweep round the grooves and a glint slides across the glass.' },
    'CLB-064': { spec: 'hex31', live: 'Light chases down the tunnels', note: 'A honeycomb cluster of three deep hexagonal infinity mirrors in brushed gunmetal, a big one in the middle and two smaller ones beside it. Each has a two-way mirror front over a ring of LEDs, so the light repeats into a tunnel of shrinking hexagons in warm magenta, amber and gold, with a slim chrome bezel and a glow on the wall. The light chases inward down each tunnel and the colours shift from module to module.' },
    'CLB-084': { spec: 'mascot31', live: 'Laser eyes sweep the room', note: 'A giant polished-chrome mascot head of the club\'s own robo-cat on a gunmetal wall plate: a mirror-bright dome with two angular ears lined in champagne gold, a wraparound black glass visor with two big round eyes, a grille muzzle with a little equaliser, panel seams, rivets and whisker light-bars. The eyes blaze and their warm laser beams sweep the room, the grille bounces to the beat and reflections slide across the chrome.' },
    'CLB-009': { c31: 'raft', live: 'Christmas lights twinkle', note: 'No ceiling at all, just the underside of the garage roof: rough OSB roof deck with its chip pattern and stamped grade marks between raw pine rafters running front to back, a forgotten fluorescent tube fixture, cobwebs in the corners and a cheap string of multicoloured Christmas lights swagged from rafter to rafter. The bulbs twinkle out of step and the cobwebs sway in the draught.' },
    'CLB-029': { c31: 'truss', live: 'PAR cans pulse and swap colours', note: 'The whole ceiling sprayed flat black, joists, a duct and conduit included, so it disappears. Across the middle hangs a silver aluminium box truss on short chains, its chords laced with zigzag braces, with six PAR cans clamped underneath in coloured gels and their cables taped along the top. The cans pulse and swap colours to the beat, throwing soft light cones down into the room.' },
    'CLB-049': { c31: 'coffer', live: 'Mirror balls turn, specks sweep', note: 'A grid of deep coffers between glossy black beams, every coffer lined with a mosaic of little mirror squares catching the club lights and edged with a slim warm LED line, with three mirror balls of different sizes hanging on chains. The balls turn with their facets flashing, and a scatter of light specks sweeps across the ceiling.' },
    'CLB-069': { c31: 'kin', live: 'Triangles tilt in waves', note: 'A ceiling of matte black triangular panels on hidden motors, every seam traced with a warm LED line. The panels tilt in slow waves so their faces catch more or less light, and the seams glow from rose through amber to gold as the wave passes.' },
    'CLB-089': { c31: 'dome', live: 'Nebula turns, halos fire lasers', note: 'The middle of the ceiling opens into a deep projection dome ringed in a brushed champagne-gold torus, wrapped in a slow warm nebula of rose, amber, violet and gold with a faint star field and gold meridian lines tracing its curve. Below it three slim gold halo rings float on nothing, each trimmed with a running LED band and firing fans of warm laser beams down into the room. The nebula drifts, stars twinkle, the halos bob out of step and their laser fans sweep.' },
    'CLB-006': { spec: 'foil31', s4: null, live: 'Flickers, sways, foil twists', note: 'A cracked, yellowed plastic ceiling rose with a cobweb, a white flex with a lump of electrical tape, a black bakelite lampholder with a chipped ring and a cheap painted-blue party bulb, the paint scratched off in one spot and dust on its shoulder. Beside it hangs a lumpy ball of crumpled kitchen foil on a bit of string, held to the ceiling with a strip of masking tape. The bulb flickers now and then, both sway in the draught and the foil ball twists, its glints winking.' },
    'CLB-026': { spec: 'mball31', s4: null, live: 'Ball turns, specks circle', note: 'A 12-inch glass mirror ball on a short chain under a black ceiling motor with a green power light, lit by a small black pinspot on a ceiling bracket whose warm white beam hits it from the side. The ball turns with real tiles catching the light, its rays rotate, specks of light circle the room and dust motes drift in the beam.' },
    'CLB-046': { spec: 'dmx31', live: 'Heads sweep, strobe fires', note: 'A matte black lighting stand with tripod legs and rubber feet and a telescoping brushed aluminium mast, carrying a T-bar with two compact moving heads on top and a slim LED strobe bar beneath. A DMX cable runs down the mast, held with strips of gaffer tape, to a little controller clamped halfway with blinking lights. The heads pan and sweep tight warm beams of amber, rose, white and violet, and the strobe bar fires quick white bursts.' },
    'CLB-066': { spec: 'laser31', live: 'Laser show, sphere turns', note: 'A round plinth of polished black marble with gold veins and a brushed brass band, a fluted brass column with two collars, a laser projector in a gloss black and brass housing halfway up and a giant mirror sphere turning on a brass hub at the top. The sphere throws warm specks round the room while the projector draws sweeping fans, a turning star and blinking bursts in rose, amber, gold, violet and red.' },
    'CLB-086': { spec: 'holo31', live: 'Hologram dances, lightning arcs', note: 'A stepped emitter dais in gloss black lacquer with a champagne-gold band and a glowing gold lens, throwing a warm column of light in which a rose-gold hologram dancer drawn in light grooves with scanlines and the odd glitch. Either side stands a lightning generator: a walnut and brass base, a glass tube over a copper coil and a polished brass sphere on top. The dancer dances, light motes rise, ripples spread over the floor and rose-violet lightning jumps between the spheres and crackles into the air.' },
    'CLB-002': { spec: 'pa31', live: 'Woofer pumps, crackles', note: 'A battered off-brand plastic PA box leaning a little on a cheap wobbly tripod: scuffed black plastic with a cracked top corner held together with silver duct tape, a dented perforated grille over the woofer, a peeling star sticker and a moulded top handle. On the side panel one knob is missing and the power light flickers; the tripod clamp is reinforced with zip ties, one leg has a tape repair and the power cord trails off into a tangle on the floor. The woofer pumps unevenly and the box buzzes and crackles with little static sparks.' },
    'CLB-022': { spec: 'mon31', live: 'Woofers pump, riser glows', note: 'Two matching black monitor cabinets in textured paint, toed in a little on rubber isolation pads atop a low black carpeted riser. Each has an exposed 12-inch woofer with a steel rim and screws, a flared horn above it, a bass port slot and a small amber power light; a cable runs between them and a can of soda sits on the riser. Both woofers pump to the beat, sound rings spread and a warm glow pulses along the riser edge.' },
    'CLB-042': { spec: 'bins31', live: 'Horns pump, ripples roll', note: 'In the middle a 2 x 2 stack of big folded-horn bass bins in black textured paint with steel corner protectors, each horn mouth folding back into a deep throat where the driver works. Either side stands a ground-stacked line array: a sub base and eight slim curved elements on brushed-steel hinges under a flybar, with perforated grilles and little status lights. The drivers pump deep in the horns, pressure ripples roll out of the mouths, the status lights flicker and the floor dust hops.' },
    'CLB-062': { spec: 'gold31', live: 'Horns pump, gold glints', note: 'A three-box horn stack in piano-black lacquer with champagne-gold anodised horns: a folded bass horn at the bottom, a big square mid-range flare with a bullet phase plug, and twin round treble horns either side of a slim ribbon on top, with gold edge trims and pinstripes, standing on gold spikes on a black marble plinth. The drivers pump in the throats, warm light breathes deep in the horns and a soft glint slides across the gold.' },
    'CLB-082': { spec: 'react31', live: 'Bass + haze', note: 'Two tapering towers of smoked obsidian glass ringed with champagne-gold driver bands, each band split by a warm amber light seam and capped with a polished dome and gold finial, and between them a black-gold sphere floating over a gold-ringed emitter disc. Amber light runs up the seams, pressure rings ripple out of the towers, warm sonic beams flow to the sphere as it bobs and turns, and rings roll across the floor. Tap to play: a haze ring rolls out across the floor.' },
    'CLB-010': { spec: 'bfan31', live: 'Blows bubbles', fog: { t: 1, style: 'bubble', at: [[7, 57, 15]], dir: [0.5, 0.25, 0.87] }, note: 'A cheap pedestal fan gone yellow with age: a cracked round base with a strip of tape and a row of piano-key switches (one stuck down), a scuffed pole, grey dust on the blades and a bent bit of cage taped back. Someone has wired a yellow plastic bubble wheel to the pole with a twisted coat hanger, its rings dipping into a pink tray of soapy water. The head turns side to side, the wheel turns through the soap and bubbles drift off. Tap to switch on more bubbles.' },
    'CLB-030': { spec: 'fogm31', live: 'Fog · light', note: 'A little black plastic fog box from a seasonal shop: scuffed body with vent slats, a carry handle, an orange pumpkin badge, a translucent bottle of purple fog juice half full plugged into the top and a brass nozzle with a sticky drip under it. A wired remote on a coiled cord lies on the floor beside a small puddle of fluid, and a plastic toy spider sits on top. The ready light blinks, the nozzle glows and short light puffs drift out. Tap for short, light puffs of fog.' },
    'CLB-050': { spec: 'haze31', live: 'Haze · medium', fog: { t: 3, style: 'haze', at: [[24, 23, 0]], dir: [1, 0.1, 0.35], fl: [20, 0, 20], tint: ['#f2efff', '#d6c8ff', '#f6f6fa'] }, note: 'A sleek matte black hazer with brushed aluminium carry rails, a fan grille and a small amber readout, sitting on a black road case with aluminium edging, ball corners and butterfly latches, with two compact UV cannons on floor yokes tilted up at the room. The fan turns and haze drifts out of the nozzle, and the UV cannons breathe a violet glow that picks out fluorescent specks. Tap for a medium haze.' },
    'CLB-070': { spec: 'cryo31', live: 'CO2 · heavy', note: 'A low black lacquer cabinet with a champagne-gold grille, gold feet and a gold-rimmed pressure gauge hides the CO2 tank; braided gold hoses run to two jet heads on slim gold columns either side, and in front a gold confetti cannon with black bands sits angled up on a lacquer pedestal. The jets fire tall freezing white columns in bursts, the gauge needle twitches and the cannon swirls out metallic confetti in gold, rose gold, champagne and blush. Tap for heavy CO2 blasts.' },
    'CLB-090': { spec: 'mist31', live: 'Mist · max', fog: { t: 5, style: 'mist', at: [[0, 84, 0], [0, 98, 0], [0, 110, 0]], fl: [0, 0, 0], tint: ['#fff8ee', '#f4ece2', '#fff2e0'] }, note: 'A sculptural mist fountain: a black marble drum with white veining and a brass inlay ring on a polished brass toe ring, a fluted smoked-bronze column with brass collars and a warm-lit brass mist bowl. Above it three brushed-brass rings float one over another, each set with six tiny nozzle pins breathing fine mist, and a hand-blown glass orb with an amber glow drifts on top, circled by iridescent soap bubbles. The rings bob out of step and turn slowly. Tap for the densest, longest-lasting mist in the club.' },
    'CLB-011': { spec: 'dart31', note: 'A tired bristle dartboard hung slightly crooked on a cheap plywood backboard. The bristle is faded and fuzzy, peppered with holes, with a frayed chunk missing near the top, a bent wire and two numbers worn off the ring. The dark green paint is flaking off to bare wood, missed throws have riddled the board around it, a cracked corner is patched with masking tape and chalk tally marks sit in the corner. Two darts are in the board (one with a torn flight) and a third is stuck in the backboard. It hangs from a picture wire on a nail; a curl of loose paint and the peeled tape end sway in the air.' },
    'CLB-031': { note: 'A second-hand pinball cabinet: angled playfield under glass, two flippers, three pop bumpers, slingshots, a lit backglass with a score display and neon trim. It stands on square black legs with chrome leg bolts (one leveller shimmed with a folded beer mat); the side art is chipped to bare wood at the corners and scratched, a split on the backbox corner is held with duct tape and one neon tube flickers. Tap to play a ball.' },
    'CLB-051': { note: 'An upright rhythm cabinet with a big screen, light-up marquee, speakers and two floor pads with arrow panels. Chrome safety bars with black foam grips stand behind each pad, and the arrow panels and step edge are scuffed with shoe marks from heavy use. Arrows scroll up the screen and the pad panels light on the beat. Tap and two creatures dance.' },
    'CLB-071': { note: 'A flip-top games table in walnut with brass trim: a white air-hockey surface with red and navy lines, or an emerald billiards felt with brass-rimmed leather pockets and mother-of-pearl sights. It stands on two walnut pedestals with brass bands and feet, with warm LED light glowing under the rails and a small amber score display. Tap and two creatures play a live match.' },
    'CLB-091': { spec: 'arena31', note: 'A round dance stage of walnut veneer on a polished brass base, its centre an under-lit honey onyx disc ringed with brass inlay and four brass arrow inlays. Two slim brass columns carry a brass halo ring overhead with six warm spot lamps pointing in. In the middle a hologram of a squish creature made of warm gold scan-lines bounces to the beat while the arrows light in sequence, a beat ring ripples across the onyx and rhythm chevrons float up; a cream VR headset with a tan leather strap hangs on the right column.' },
    'CLB-075': { note: 'A faceted DJ altar: a black obsidian front cut into triangular facets with antique-mirror shards, brass seams between the facets, a dark bronze top on a brass band and a black plinth with a brass line. Two CDJs and a mixer sit on top; warm gold light lines sweep across the facets and the mirror shards catch the light. Tap the booth and a creature steps up in boss shades and a studio headset: one paw holding the ear cup, the other pumping the crowd, head bobbing to the beat while the decks spin and the EQ pumps.' },
    'CLB-095': { note: 'A black lacquer DJ stage banded in brass, raised off its lacquer base on brass hydraulic cylinders with chrome rods, with a dark bronze top. Two touch decks with warm gold jog rings flank the mixer, a warm under-glow spills on the floor and a dashed gold halo circles the booth. Tap the booth and a creature steps up in boss shades and a studio headset: one paw holding the ear cup, the other pumping the crowd, head bobbing to the beat while the decks spin and the EQ pumps.' },
    'CLB-018': { note: 'A secondhand 80s chrome boombox from a thrift store: two big speaker cones, a tuner window with a VU meter and a flip-down cassette deck, but the chrome is dull and scratched, the left woofer grille is dented with a torn hole, a peeling smiley sticker sits on the right grille, one tuning knob is missing (bare shaft), a cracked corner is held with grey duct tape and the antenna has a twist of electrical tape. A tangled aux cord trails off the side. Tap to play: the door shuts, the reels roll and the woofers pump.' },
    'CLB-098': { spec: 'synth31', note: 'A round walnut synth table with a brass edge on a fluted walnut pedestal and a polished brass base. A walnut-cased modular synth with a slanted black panel of brass knobs, a small amber scope and coloured patch cables sits between the two brass antennas of a theremin, an upright pitch rod and a volume loop, played by moving your paws in the air. Above the table a warm gold light-sculpture of the sound loops, turns and reshapes, with sparks drifting off it.' },
    'CLB-003': { spec: 'spool31', note: 'An old industrial cable spool stood on end as a table: rough plywood flanges with splintered edges, stencilled rings and an arrow, a stained centre hole with four rusty bolts, a slatted barrel, peeling neon stickers, drink rings, bottle caps and a dented can. Beside it an upturned red plastic crate holds a candle stuck in a green bottle; the flame flickers and a loose sticker corner lifts in the draft.' },
    'CLB-023': { spec: 'hitop31', note: 'A standard bar high-top: a round white laminate top with a chrome edge band (a small chip, faint drink rings), a chrome column with a chrome foot ring, and a heavy round chrome base scuffed at the rim, with a folded beer mat wedged under one edge. A tea-light flickers in a frosted glass beside a folded napkin.' },
    'CLB-043': { spec: 'inf31', note: 'A matte black box coffee table on a recessed plinth with a glass top over an infinity mirror: a ring of warm-white LEDs reflected again and again into a tunnel that seems to drop through the floor, a thin LED line along the glass edge and two cocktails in coupe glasses on black coasters. Light runs around the rings and the colour drifts slowly from warm white to soft rose and back.' },
    'CLB-063': { spec: 'trough31', note: 'A slab of black marble with white and gold veining over a black lacquer cabinet base banded in brushed brass. Down the middle runs a sunken brass-lined trough packed with crushed ice holding three champagne bottles with gold foil necks, and two coupes of champagne sit at the ends. The ice glints, bubbles rise in the glasses and a slow warm sheen slides across the marble.' },
    'CLB-083': { spec: 'touch31', note: 'An oval walnut table with a polished brass rim on an oval walnut column and brass foot. Set into the top is a black glass touch panel with twelve gold-ringed pads that light up in patterns with ripples, and above its centre floats a warm gold visualiser: a circle of light bars pumping like an equaliser with rings of light rising off it.' },
    'CLB-007': { spec: 'pstool31', note: 'A faded red moulded-plastic stacking stool: a round seat with a finger hole and ribbed rim, four splayed ribbed legs and a square brace ring, chalky and scuffed with a stack mark worn into the seat and a sticky drink ring. A sweating beer can stands on the edge with a drop of condensation running down it. It still works as a seat.' },
    'CLB-027': { spec: 'ledped31', note: 'A rented party LED pedestal: a tapered frosted-plastic column with a mould seam and a round frosted top, lit from inside by a cheap colour-changing LED that fades through magenta, amber, violet and pink. A small remote and a drink with a straw sit on top, a barcode rental sticker is on the base and a charge cable trails off.' },
    'CLB-047': { spec: 'hglass31', note: 'A tall cocktail side table on an hourglass base of two brushed-brass cones meeting at a slim waist ring, with a round white Carrara marble top edged in brass. A coupe cocktail with an orange twist sits on a linen napkin, and a soft highlight slides up and down the brass.' },
    'CLB-067': { spec: 'icestand31', note: 'A polished-nickel champagne-bucket stand: a round weighted base with a warm light ring glowing underneath, a slim column and a three-arm cradle holding a cut-crystal ice bucket full of ice, lit warm from inside, with a champagne bottle angled in it and a white linen napkin draped over the rim. The glow breathes, the ice glints and condensation runs down the crystal.' },
    'CLB-087': { spec: 'dronetab31', note: 'A magnetic levitation side table: a walnut and brass base holds a round walnut tray top with a brass rim hovering in mid-air, a warm light glowing in the gap. Two tiny brass-and-black coaster drones, each carrying a drink on its back, hover beside it with their rotors spinning. The top bobs gently and the drones bob out of step.' },
    'CLB-008': { spec: 'cups31', note: 'The mess after a party game: three red plastic cups with beer in a triangle, a short stack of empties, one cup knocked over in a spilled puddle, a crumpled napkin, a bottle cap and snapped glowsticks (a green stick, a pink bracelet and a yellow one bent in a V) pulsing softly.' },
    'CLB-028': { spec: 'shaker31', note: 'A budget bar set on a little stack of neon acrylic coasters: a three-piece steel shaker with a small dent and water spots, a double jigger, claw ice tongs and a twisted bar spoon, and two ice cubes melting on the top coaster. The coaster edges pulse and condensation slides down the shaker.' },
    'CLB-048': { spec: 'ledice31', note: 'A clear acrylic champagne bucket with moulded handles, filled with water and light-up LED ice cubes, a champagne bottle standing in it and three more LED cubes scattered beside it. Every cube cycles through warm white, rose, amber and violet at its own pace, lighting the water and the table.' },
    'CLB-068': { spec: 'vipset31', note: 'VIP bottle service: a metallic gold champagne bottle with a black neck band and a lit ice-fountain sparkler clipped to its neck, beside a cut-crystal vapour carafe on a brass stem with a small brass bowl, tray and a coiled hose. The sparkler fountains bright sparks, the gold catches the flicker and a thin wisp of vapour curls up.' },
    'CLB-088': { spec: 'orbs31', note: 'A walnut and brass dock with a brass post holding woven VIP wristbands in rose, gold and black with brass tags, a soft gold light ring turning above it, and three blown-glass drink spheres floating around it, each holding an amber or rose cocktail lit warm from inside with a gold straw. The spheres bob and drift out of step and their glow breathes.' },
    'CLB-013': { spec: 'drinkst31', note: 'A white plastic folding table with grey steel legs (one foot cap missing) holding a cheap plastic punch bowl with a ladle, a 2-litre soda bottle, a red cup and a torn bag of ice slumped in a puddle; underneath sits a scuffed red picnic cooler with its white lid slightly ajar. Condensation runs down the soda bottle.' },
    'CLB-033': { spec: 'tiki31', note: 'A budget home tiki bar: a plywood box faced with split bamboo poles (one cracked), bamboo corner posts, a varnished dark wood counter with a fringe of dry grass thatch along the edges, and a tiki mug, a coconut cup with a paper umbrella and a pineapple at the ends. The back is plain plywood with a shelf. The thatch stirs in a light breeze.' },
    'CLB-053': { spec: 'acrybar31', note: 'A nightclub bar faced in frosted white acrylic panels on chrome standoffs, lit warm-white from behind so the LED strips glow softly through, with a black quartz counter with a fine sparkle and a chrome edge, a chrome foot rail, three cocktails and a cup of straws on top. The bartender side is black with shelves of bottles. The backlight breathes and a soft band of light sweeps across the acrylic.' },
    'CLB-073': { spec: 'onyxbar31', note: 'A wet bar faced in book-matched honey onyx lit from behind so the stone glows amber through its bands and veins, framed in brushed brass with a brass foot rail. The black marble counter has a brass edge, a small brass bar sink and a gooseneck tap, and at the back a three-step lit brass display of liquor bottles glowing from beneath in a slow wave.' },
    'CLB-093': { spec: 'robobar31', note: 'A black lacquer bar faced with vertical brass reeding and a warm under-glow, with a black marble counter edged in brass. Behind it a pair of ivory and brass robot arms on a lacquered column work the bar: the left shakes a brass cocktail shaker in bursts, the right tips a bottle and pours into a coupe. At one end a brass levitation pad holds a sphere of cocktail floating in mid-air, wobbling, with tiny droplets orbiting it.' },
    'CLB-014': { spec: 'petmat31', note: 'A pet-sized breakdance mat cut from a flattened box: two cardboard panels taped together with silver duct tape, a printed arrow and a fold crease, a scuffed spin circle worn into the middle and one corner curling up, with a chewed rubber squeaky ball and a little knotted rope toy on it. The ball rocks and the curled corner lifts in a draft.' },
    'CLB-034': { spec: 'petpod31', note: 'A low pet-sized light-up disco podium: a black frame with silver edging and a grid of frosted squares lit by colour LEDs that flash in a chasing pattern, a mini clip-on spotlight and a pair of little star-shaped pet sunglasses left on the edge. Two pets can perform on it.' },
    'CLB-054': { spec: 'petdj31', note: 'A pet-sized DJ booth in white lacquer and birch plywood: on top a cat scratch pad made like a turntable (a corrugated cardboard record you can scratch, on a white deck with a little tonearm), a tiny two-knob mixer with a blinking light and a felt toy record, with small padded pink pet headphones hanging on a hook at the side. The scratch record turns slowly.' },
    'CLB-074': { spec: 'petlounge31', note: 'A round button-tufted burgundy velvet lounge pouf with brass piping, turned brass feet and a low curved bolster at the back, beside a little brass stand holding a glass mocktail dispenser full of fruit with a brass tap dripping into a small brass pet bowl. A soft sheen moves across the velvet. It is a seat.' },
    'CLB-094': { spec: 'petholo31', note: 'A pet-sized walnut stage with a brass rim hovering on magnets over a black lacquer base, warm footlights chasing along the front and two brass arcs at the back carrying little spot lamps. On it a warm gold hologram of a dancing pet bounces while two fainter rose and amber clones copy its moves a beat behind. Two pets can perform here.' },
    'CLB-016': { spec: 'diner31', note: 'A two-seat diner booth bench against the wall: cracked oxblood vinyl with a channel-stitched tall back, a chrome edge strip and a scuffed chrome kick plate, a long split in the seat with yellow foam bulging out, an X of silver duct tape over another tear, a split seam on the back, faded patches where everyone sits and a wad of pink gum under the front edge. A loose flap of torn vinyl lifts and settles. Seats two.' },
    'CLB-036': { spec: 'faux31', note: 'A budget L-shaped club banquette in shiny black faux leather: channel-stitched back cushions, plump seat cushions with sitting creases, rolled arms and short chrome legs. The cheap leatherette is cracking and peeling to the brown fabric backing on the arm tops and front edges, with a strip of black tape over one split, and a loose flake lifts in the draft. Seats four.' },
    'CLB-056': { spec: 'velvU31', note: 'A horseshoe VIP booth in deep aubergine velvet: diamond button-tufted backs, piped seat cushions and rolled arms on a black lacquer plinth with a recessed warm light line. A soft sheen drifts across the velvet. Seats five.' },
    'CLB-076': { spec: 'goldU31', note: 'A horseshoe VIP booth in champagne-gold velvet with vertical channel-tufted backs and gold piping, raised on a plinth clad in warm antique-mirror panels framed in brass with a glowing toe line. In the middle of the horseshoe stands a brass bottle-service stand with an ice bucket and a champagne bottle. Glints run across the mirror and the ice catches the light. Seats five.' },
    'CLB-096': { spec: 'cloud31', note: 'A floating horseshoe VIP booth in cloud-soft ivory boucle with plump stacked back cushions and two champagne silk pillows, on a brushed-brass skirt with a warm under-light line. It hovers over a polished black marble plinth edged in brass while warm cloud puffs drift beneath it. A translucent champagne-glass sound dome on brass ribs rises from the back, with a warm pendant light inside and a rim of tiny speaker lights. Pulses of light climb the ribs and the plinth glow breathes as the booth bobs. Seats five.' },
    'CLB-019': { spec: 'crate31', note: 'A faded blue plastic milk crate turned upside down by the wall: thick lip at the floor, handle slots near the bottom, three rows of open holes, white stress scuffs, a cracked top corner and a half-peeled round sticker. A yellowed square of foam is strapped on top with two strips of black duct tape, and one loose tape end flutters.' },
    'CLB-039': { spec: 'dstool31', note: 'A second-hand diner bar stool: four splayed chrome tube legs with a foot ring rubbed dull where feet rest, a swivel plate and a ribbed chrome band holding a domed red vinyl cushion. The vinyl has split across the top and is patched with an X of silver duct tape; the chrome is pitted with rust near the floor, one rubber foot cap is missing and a wad of pink gum is stuck under the seat. The loose seat wobbles on its swivel.' },
    'CLB-059': { spec: 'ledcube31', note: 'A frosted-plastic cube seat lit from inside by a colour-changing LED, with soft rounded edges, a faint mould seam and a round charcoal felt pad on top. A little remote and a charge cable lie on the floor beside it. The cube fades slowly through magenta, amber, violet and coral, faster when the party is on.' },
    'CLB-079': { spec: 'wirestool31', note: 'A designer barstool on a twisting hourglass lattice of polished gold rods between a floor ring and a seat ring, with a separate gold foot ring on four short spokes, under a domed black velvet seat with a gold piped edge. A glint runs along the gold rods and a soft sheen drifts across the velvet.' },
    'CLB-099': { spec: 'magpod31', note: 'A round lounge pod in tufted cognac leather, cradled in a polished brass bowl and hovering above a walnut magnetic base with a brass band and a black onyx top that glows warm in the gap. The pod bobs gently while gold sound rings ripple out across the floor, faster when the party is on.' },
    'CLB-020': { spec: 'beans31', note: 'Four mismatched, slumped bean bags in the corner: faded denim vinyl split along a seam and leaking foam beads, brown corduroy, faded red vinyl with a silver tape patch, and a small grey fleece one with a stain. A yellowed plastic floor fan with a dusty guard blows at them, its cord snaking to the wall, and a crumpled can lies on the floor. The fan blades spin and a bead trickles out of the split now and then. Seats four.' },
    'CLB-040': { spec: 'lava31', note: 'A classic rocket-shaped lava lamp with a speckled silver base and cap, violet liquid and orange wax, on a cheap black pressboard cube table with a chipped corner. The table is draped in a black-light tapestry throw with a fluorescent mandala and fringe, lit by a little clip-on black-light bulb. The wax blobs rise, stretch and sink, the tapestry colours pulse and the black light flickers now and then.' },
    'CLB-060': { spec: 'vpod31', note: 'A round emerald-velvet drum seat on a brass ring, wrapped by a tall curved hood: velvet outside, charcoal acoustic felt inside, with a brass-piped rim. On the inside back wall is a little walnut oxygen bar: three glass aroma flasks in amber, rose and mint with clear tubes looping to a hanging nose cannula, lit warm from underneath. Bubbles rise in the flasks and the light breathes.' },
    'CLB-080': { spec: 'dressnook31', note: 'A Hollywood-regency chaise longue in dusty-rose velvet with a channel-tufted half back, a rolled arm at the head, a champagne satin bolster, an ivory faux-fur throw over the foot, gold tapered legs and a brass base rim. At the foot stands a cream glass-door mini-fridge with warm-lit shelves of little bottles, a brass handle and a gold star, topped by a black lacquer bulb-framed dressing mirror, a perfume bottle and a lipstick. The mirror bulbs glow in a slow ripple, a glint slides over the mirror and a sheen drifts across the velvet.' },
    'CLB-100': { spec: 'floatpod31', note: 'An ivory lacquer float pod: a long egg-shaped shell with a brass rim, filled with warm amber-lit water and a floating neck pillow, hovering over a black marble oval plinth with a brass edge. At the foot, a slim brass hydration stand holds a carafe of water with citrus slices and mint, and a glass. The pod bobs, the plinth glow breathes with it, slow ripples spread across the water and light shimmers on its surface.' },
  };
  const edit30 = RD.edit;
  // user: nothing fixed on the walls - the 15 windows (LIV / KIT / BED x 5 tiers) were wall surfaces; now each is a wall piece you can move, resize or put away.
  // The piece shows the same window picture (drawn by the old surface path: a copy of the row with no spec) flat on the wall plane.
  { const { WD } = RD.H12, { ext } = RD.H11;
    N.winw31 = S => { const r = S.row || {}, o = RD.draw(Object.assign({}, r, { spec: '' }), {}), v = String(o.vb || '-48 0 96 75').split(' ').map(Number), k = X.FS * (X.sAt ? X.sAt(101) : 1) || 1, W = v[2] / k, Hh = v[3] / k;
      const D = { w: Math.round(W), d: 6, mount: 'wall', elev: Math.max(12, Math.round(58 - Hh / 2)), build: () => [] };
      D.fx = ctx => { const C = cam(ctx), X0 = -W / 2; ext(C, [[X0, Hh, 0], [X0 + W, 0, 0], [X0 + W, 0, 1]]);
        return { front: WD(C, X0, Hh, 0.05, `<image href="${o.src || ''}" width="${f1(W)}" height="${f1(Hh)}" preserveAspectRatio="none"/>`), bb: C.bb(3) }; };
      return D; };
    ['LIV', 'KIT', 'BED'].forEach(R => ['012', '032', '052', '072', '092'].forEach(n => { const id = R + '-' + n; RD.SET31[id] = Object.assign({}, RD.SET31[id], { spec: 'winw31' }); })); }
  // user: creatures bathe in the onsen tub, the infinity pool and the royal tub, and relax at the saunas (tubs: inside = the water point, parts nearer than it go over the bather like the clawfoot tubs; saunas: seat in front of the door, noFront)
  const seatN = (k, f) => { const g = N[k]; if (g && !g._s31) { N[k] = S => f(g(S)); N[k]._s31 = 1; } };
  const BATH3 = h => [{ x: -38, z: -10, h, k: 'bath' }, { x: 0, z: 14, h, k: 'bath' }, { x: 38, z: -10, h, k: 'bath' }];
  seatN('onsen29a', D => Object.assign(D, { act: 'bath', inside: [0, 16, 0], fxF: 1, seats: BATH3(16) }));
  seatN('onsen29b', D => Object.assign(D, { act: 'bath', inside: [0, 16, 0], fxF: 1, seats: BATH3(16) }));
  seatN('luxTub', D => Object.assign(D, { act: 'bath', inside: [0, 14, 0], seats: [{ x: -18, z: 0, h: 14, k: 'bath' }, { x: 22, z: 0, h: 14, k: 'bath' }] }));
  // saunas (user Nov 7): the friend goes INSIDE (tent, barrel, cabin, pod: seat in the middle, the walls in front cover him; the bucket keeps its seat in front),
  // and while someone is in, the sauna works: thick steam billows from the top, a warm glow pulses at the front. House rStOf gives st 'play' when a friend sits in it (r.sauna31).
  ['BTH-007', 'BTH-027', 'BTH-047', 'BTH-067', 'BTH-087'].forEach(id => { RD.SET31[id] = Object.assign({}, RD.SET31[id], { sauna31: 1 }); });
  const SAUNA_IN = { therm29b: [0, 6, 0], therm29c: [0, 6, 0], therm29d: [0, 6, 0], therm29e: [0, 6, 0] };
  const steam31 = (C, top, fz, big) => { const k = C.k, R = rng('st31' + top), n = big ? 9 : 6; let s = `<g filter="url(#s31b)">`, X0 = 1e9, Y0 = 1e9, X1 = -1e9, Y1 = -1e9;
    for (let i = 0; i < n; i++) { const q = C.P([(R() - 0.5) * 40, top, (R() - 0.5) * 30]), T = 3 + R() * 1.6, b = -i * T / n, r = (7 + R() * 4) * k, up = (46 + R() * 22) * k, dx = (R() - 0.5) * 14 * k;
      X0 = Math.min(X0, q[0] - 3 * r); X1 = Math.max(X1, q[0] + 3 * r); Y0 = Math.min(Y0, q[1] - up - 3 * r); Y1 = Math.max(Y1, q[1] + r);
      s += `<g transform="translate(${f1(q[0])} ${f1(q[1])})"><g>${at('translate', `0 0;${f1(dx)} ${f1(-up)}`, T, b)}<g>${at('scale', '0.4;2.2', T, b)}<circle r="${f1(r)}" fill="#f4f2ee" opacity="0">${an('opacity', '0;0.9;0.55;0', T, b, ' keyTimes="0;0.25;0.6;1"')}</circle></g></g></g>`; }
    const g = C.P([0, top * 0.42, fz]); s += `</g><ellipse cx="${f1(g[0])}" cy="${f1(g[1])}" rx="${f1(30 * k)}" ry="${f1(22 * k)}" fill="url(#s31g)" style="mix-blend-mode:screen">${an('opacity', '0.55;1;0.55', 2.4, 0, SPL(2))}</ellipse>`;
    return { s, bb: [X0, Y0, X1, Y1] }; };
  const SDEF = '<filter id="s31b" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="1.6"/></filter><radialGradient id="s31g"><stop offset="0" stop-color="#ffb060" stop-opacity="0.75"/><stop offset="1" stop-color="#ff7a30" stop-opacity="0"/></radialGradient>';
  ['therm29a', 'therm29b', 'therm29c', 'therm29d', 'therm29e'].forEach(k => { const g0 = N[k]; if (!g0 || g0._s31) return;
    N[k] = S => { const D = g0(S), ins = SAUNA_IN[k]; Object.assign(D, { act: 'sauna', seats: [ins ? { x: 0, z: 0, h: ins[1], k: 'sauna' } : { x: 0, z: 66, h: 0, k: 'sauna' }] }); if (ins) { D.inside = ins; D.fxF = 1; } else D.noFront = 1;
      if (/(^|\|)play$/.test(S.st || '')) { let top = 0; try { D.build(X.pal(D, 0), D.v0 || '').forEach(o => o.pts.forEach(p => { if (p[1] > top) top = p[1]; })); } catch (e) { top = 100; }
        const fx0 = D.fx; D.fx = ctx => { const F = (fx0 && fx0(ctx)) || {}, C = cam(ctx), st = steam31(C, top, (D.d || 100) / 2, !!ins); F.front = (F.front || '') + st.s; F.defs = (F.defs || '') + SDEF;
          F.bb = F.bb ? [Math.min(F.bb[0], st.bb[0]), Math.min(F.bb[1], st.bb[1]), Math.max(F.bb[2], st.bb[2]), Math.max(F.bb[3], st.bb[3])] : st.bb; return F; }; }
      return D; }; N[k]._s31 = 1; });
  // bathers in the clawfoot tubs and the pet wash basins sank out of sight: the whole tub body was in the front layer. cutF = a point on the front rim:
  // reno-draw puts the part of the front layer ABOVE that point's screen line behind the bather, so only the front wall covers his lower half (cut 16 under the front rim top; checked live with Mittens + Nimbo).
  const rimF = (D, f) => { let top = 0; try { D.build(X.pal(D, 0), D.v0 || '').forEach(o => o.pts.forEach(p => { if (p[2] > (D.d || 80) * 0.2 && p[1] > top && p[1] < 80) top = p[1]; })); } catch (e) { top = 40; } D.cutF = [0, top - 16, (D.d || 80) * f]; return D; };
  ['tub29a', 'tub29b', 'tub29c', 'luxTub'].forEach(k => seatN(k, D => rimF(D, 0.42)));
  ['pet29a', 'pet29b', 'pet29c', 'pet29d', 'pet29e'].forEach(k => seatN(k, D => rimF(D, 0.4)));
  RD.DEL31 = new Set(['BTH-002', 'BTH-022', 'BTH-042', 'BTH-062', 'BTH-082', 'BTH-019', 'BTH-003', 'BTH-023', 'BTH-043']); // user: no toilets (all 5 Lavatory Throne tiers), no Soap Dish (019), no Wall Hook / Towel Rack / Ladder Towel Stand (003/023/043)
  RD.edit = rows => edit30(rows).filter(r => !RD.DEL31.has(r.id)).map(r => RD.SET31[r.id] ? Object.assign({}, r, RD.SET31[r.id]) : r);
  RD.H31 = { FLOOR31, pools, K };
  RD.PLUS31 = 1;
})();
