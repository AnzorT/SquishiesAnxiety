// Per-creature water moves (tub: tubin / tub / tubout, shower: showerin / shower / showerout, swim: swimin / swim / swimout, shake) for all house creatures.
// sw = swim style (paddle / glide / float / bob), s = his own bath signature (also used in the shower and the swim unless ss / ws are given),
// k = shake extras {a, b: the two wiggle sides, f: the fluffed-up pop}, bp / hp / wp = bath / shower / swim pose tweaks, sa / sb = extra channels on the two halves of each swim stroke.
window.HouseCreatures = window.HouseCreatures || []; window.HouseCreatures.push(function (H) {
  const { waterBuild, hand, both, o, PROF } = H;
  const sp = (t, v, d, hold) => { const b = {}; Object.keys(v).forEach(k => b[k] = t.B[k] != null ? t.B[k] : 0); t.to((d || 700) * 0.4, v, 'o').wait(hold || 300).to((d || 700) * 0.6, b, 'io'); return t; };
  const bk = (t, d) => t.back(d || 420);
  const W = (a, b) => ({ a: { wag: a }, b: { wag: -a }, f: b || {} });
  const ears = (t, n) => { for (let i = 0; i < (n || 2); i++) t.to(110, { earL: -14, earR: 14 }, 'o').to(130, { earL: 10, earR: -10 }); return t.to(140, { earL: 0, earR: 0 }); };
  const spray = (t, w, n) => t.fx('splash', w || 'body', n || 6);
  const C = {
    // ---------- Pet Shop ----------
    mittens: { k: { a: { curl: 0.6 }, b: { curl: 0.2 }, f: { curl: 0.9 } }, s: t => { t.to(400, o(hand(1, 8, -13), { armR: 32, close: 0.7 })).osc(1600, 5, { tongue: 0.6, hRy: -15 }, { tongue: 0.1, hRy: -12 }, 's').to(300, { tongue: 0 }); bk(t); } },
    biscuit: { k: W(28, { earL: -10, earR: -10 }), s: t => { t.to(200, { hap: 1, smile: 1, open: 0.4 }).osc(1500, 8, { wag: 28, lift: t.B.lift + 0.6 }, { wag: -28, lift: t.B.lift }, 'o'); spray(t, 'sideR', 8); bk(t); } },
    prickle: { k: { f: { curl: 0.3 } }, s: t => { sp(t, { curl: 1, sq: t.B.sq + 0.14, close: 1, armL: -10, armR: -10, lift: t.B.lift + 2 }, 1600, 1600); t.fx('bubble', 'head', 2); } },
    truffle: { k: W(20), s: t => { t.to(300, { hap: 1, smile: 1, open: 0.4 }).osc(1400, 6, { tilt: 4, wag: 22 }, { tilt: -4, wag: -22 }, 's'); spray(t, 'body', 6); bk(t); } },
    ribbit: { sw: 'glide', s: t => { for (let i = 0; i < 3; i++) t.to(120, { lift: t.B.lift + 3, sq: t.B.sq - 0.06, hap: 1, open: 0.4 }, 'o').to(160, { lift: t.B.lift, sq: t.B.sq + 0.04 }, 'i').fx('splash', 'body', 4); bk(t); } },
    nibbles: { k: { f: { puff: 0.7 } }, s: t => { t.to(400, { puff: 1 }).wait(400).to(200, { puff: 0, open: 0.5 }, 'o').fx('gush', 'mouth', 3).fx('bubble', 'mouth', 2); bk(t); } },
    quill: { k: { f: { blush: 0.7 } }, s: t => sp(t, o(both(10, -14), { armL: 40, armR: 40, blush: 1, sq: t.B.sq + 0.04, close: 0.6 }), 1400, 1200) },
    waffles: { k: W(22), s: t => { t.to(700, { sk: t.B.sk + 3, close: 0.9, smile: 1, sq: t.B.sq + 0.08 }, 's').osc(1600, 4, { wag: 16 }, { wag: -16 }, 's'); bk(t, 600); } },
    poppy: { k: { a: { earL: -18, earR: 16 }, b: { earL: 16, earR: -18 } }, s: t => { for (let i = 0; i < 3; i++) t.to(140, { lift: t.B.lift + 3, sq: t.B.sq - 0.06, hap: 1, open: 0.4 }, 'o').to(160, { lift: t.B.lift, sq: t.B.sq + 0.04 }, 'i').fx('splash', 'body', 4); bk(t); } },
    duchess: { k: { f: { htilt: 8 } }, s: t => { t.to(400, o(hand(1, 9, -13), { armR: 34, close: 0.7, htilt: 8, pitch: t.B.pitch + 0.12 })).wait(1200).to(300, { sqz: 0.5 }).fx('spark', 'head', 2); bk(t); } },
    mamapaws: { k: W(14), s: t => { t.to(600, o(both(12, 1), { armL: 18, armR: 18, smile: 1, close: 0.6 })).fx('heart', 'head').osc(1400, 2, { x: 0.8 }, { x: -0.8 }, 's'); bk(t, 600); } },
    // ---------- Sky & Stars ----------
    nimbo: { sw: 'float', s: t => { t.fx('drop', 'body', 4).osc(1800, 3, { sq: t.B.sq + 0.06, puff: 0.4 }, { sq: t.B.sq, puff: 0 }, 's').fx('drop', 'body', 4).fx('drop', 'head', 3); bk(t); } },
    lumi: { s: t => { t.to(500, o(hand(1, 2, -10), { armR: 80, hap: 0.6, smile: 1, ly: -0.6 }), 'io').fx('spark', 'head', 4).wait(1200); bk(t, 500); } },
    bubbly: { sw: 'float', s: t => { for (let i = 0; i < 3; i++) t.to(300, { puff: 0.6, sq: t.B.sq + 0.05 }).to(200, { puff: 0, open: 0.4 }, 'o').fx(i === 2 ? 'bigbubble' : 'bubble', 'mouth', 2); bk(t); } },
    twinkle: { sw: 'float', s: t => { t.to(300, { glow: 1, wide: 0.6, hap: 1 }, 'o').fx('spark', 'body', 6).wait(900).to(500, { glow: 0 }); bk(t); } },
    zappi: { k: { a: { zap: 0.8 }, b: { zap: 0.3 } }, s: t => { t.to(80, { zap: 1, x: 0.5, wide: 1 }, 'o').osc(420, 4, { x: -0.5 }, { x: 0.5 }, 'l').fx('spark', 'body', 6).to(300, { zap: 0, x: 0, sqz: 0.6 }).to(300, { sqz: 0 }); bk(t); } },
    plip: { sw: 'bob', s: t => { t.osc(1400, 3, { sq: t.B.sq + 0.08 }, { sq: t.B.sq - 0.03 }, 'o').fx('drop', 'head', 4); bk(t); } },
    breeze: { sw: 'float', s: t => { t.to(500, { puff: 0.8, open: 0 }).to(500, { puff: 0, open: 0.35 }, 'o').fx('gust', 'head').fx('splash', 'mouth', 6); bk(t); } },
    dusty: { s: t => { ears(t, 3).fx('dust', 'body', 4); bk(t); } },
    aurora: { sw: 'glide', k: { a: { spout: 0.6 } }, s: t => { t.to(300, { spout: 1 }, 'o').fx('gush', 'head', 4).fx('splash', 'head', 6).wait(600).to(500, { spout: 0, glow: 0.8 }).wait(700); bk(t, 600); } },
    // ---------- Snack Shack ----------
    mallow: { sw: 'bob', s: t => sp(t, { sq: t.B.sq + 0.2, sk: t.B.sk + 2, close: 0.8, smile: 1 }, 1800, 1400) },
    bao: { sw: 'bob', s: t => { t.fx('steam', 'head').osc(1600, 2, { sq: t.B.sq + 0.06 }, { sq: t.B.sq }, 's').fx('steam', 'head'); bk(t); } },
    dunkie: { sw: 'bob', s: t => { t.osc(1800, 3, { tilt: 5, turn: 0.3 }, { tilt: -5, turn: -0.3 }, 's').fx('sprinkle', 'head'); bk(t); } },
    frybo: { sw: 'bob', k: { a: { fw: 1 }, b: { fw: 0.3 } }, s: t => { sp(t, { fw: 1, smile: 1, hap: 1 }, 1200, 900); t.fx('salt', 'head'); } },
    bunbun: { sw: 'bob', k: { a: { split: 0.4 }, b: { split: 0.1 } }, s: t => sp(t, { split: 0.5, shuf: 0.4, hap: 1 }, 1400, 900) },
    choco: { sw: 'bob', s: t => sp(t, { melt: 0.5, close: 0.8, smile: 1 }, 1800, 1600) },
    scoop: { sw: 'bob', k: { a: { chb: 1 }, b: { chb: 0 } }, s: t => { t.osc(1500, 3, { chb: 0.9 }, { chb: 0 }, 'o').fx('drop', 'head', 2); bk(t); } },
    boba: { sw: 'bob', k: { a: { slurp: 0.5 } }, s: t => { t.osc(1600, 3, { slurp: 0.6, sqz: 0.4 }, { slurp: 0, sqz: 0 }, 's').fx('bubble', 'head', 3); bk(t); } },
    chefbun: { sw: 'bob', s: t => { t.to(400, o(hand(1, 10, -13), { armR: 34 })).wait(300).to(260, o(hand(1, -4, -14), { armR: 60, smile: 1 }), 'o').fx('heart', 'head').wait(500); bk(t, 600); } },
    // ---------- Ocean Pals ----------
    pip: { sw: 'glide', k: { a: { armL: 60, armR: 20 }, b: { armL: 20, armR: 60 } }, s: t => { t.osc(1400, 6, { armL: 60, armR: 60 }, { armL: 20, armR: 20 }, 'o'); spray(t, 'body', 8); bk(t); } },
    jelli: { sw: 'float', s: t => { for (let i = 0; i < 3; i++) t.to(400, { sq: t.B.sq + 0.1 }, 'i').to(500, { sq: t.B.sq - 0.05, lift: t.B.lift + 1.4 }, 'o').fx('bubble', 'body', 2).to(500, { sq: t.B.sq, lift: t.B.lift }, 's'); bk(t, 300); } },
    finn: { sw: 'glide', k: W(26), s: t => { t.osc(1600, 4, { wag: 26 }, { wag: -26 }, 's'); spray(t, 'tail', 8); bk(t); },
      ws: t => { t.to(300, { puff: 0.6 }).to(160, { puff: 0, open: 0.5 }, 'o').fx('gush', 'blow', 5).fx('splash', 'blow', 6).wait(400).to(200, { hap: 1, smile: 1, sqz: 0.6 }); bk(t); } },
    sealy: { sw: 'glide', s: t => { t.osc(900, 3, { open: 0.4 }, { open: 0.05 }, 'o').osc(1000, 4, { hLx: 2, hRx: -2, armL: 30, armR: 30 }, { hLx: 7, hRx: -7, armL: 14, armR: 14 }, 'o'); spray(t, 'body', 6); bk(t, 500); } },
    puff: { sw: 'glide', k: { f: { blo: 0.4 } }, s: t => { t.to(900, { blo: 0.9, puff: 0.8, lift: t.B.lift + 2 }, 's').wait(700).to(500, { blo: 0, puff: 0 }, 'io').fx('bubble', 'mouth', 4); bk(t); } },
    shelly: { sw: 'glide', s: t => { t.to(600, { hid: 0.8 }, 'io').fx('bubble', 'head', 2).wait(1400).to(400, { hid: 0, nk: 0.8 }, 'o').wait(500); bk(t); } },
    octo: { sw: 'glide', k: { a: { osp: 1 }, b: { osp: 0.3 } }, s: t => sp(t, { ow: 1, osp: 0.8, hap: 1 }, 1600, 1200), ws: t => { t.to(300, { ojt: 1, sq: t.B.sq - 0.12 }, 'o').to(260, { ink: 1 }, 'l').fx('bubble', 'body', 3).to(400, { ojt: 0, ink: 0, sq: t.B.sq }); bk(t); } },
    marina: { sw: 'glide', k: { a: { tsw: 0.8 }, b: { tsw: -0.8 } }, s: t => { t.to(500, { tlf: 0.8 }, 'o').osc(1000, 2, { tsw: 0.6 }, { tsw: -0.6 }, 's').fx('splash', 'tail', 7).to(500, { tlf: 0, tsw: 0 }); bk(t); } },
    pearl: { sw: 'glide', s: t => { sp(t, { glow: 1, hsw: 0.6 }, 1600, 1200); t.fx('spark', 'head', 4); }, ws: t => { t.to(300, { puff: 0.6 }).to(160, { puff: 0, open: 0.4 }, 'o').fx('gush', 'head', 4).fx('splash', 'head', 6).to(400, { glow: 1 }).wait(400).to(400, { glow: 0 }); bk(t); } },
    // ---------- Fruit Patch ----------
    pina: { sw: 'bob', k: { a: { crw: 1 }, b: { crw: 0.3 } }, s: t => { t.to(300, { crw: 0.8 }, 'o').osc(1200, 3, { crs: 0.4 }, { crs: 0 }, 's').to(400, { crw: 0 }); bk(t); } },
    avo: { sw: 'bob', s: t => { t.to(300, { prw: 0.9 }).wait(1000).to(400, { prw: 0 }).fx('bubble', 'belly', 2); bk(t); } },
    berri: { sw: 'bob', k: { a: { stw: 1 }, b: { stw: 0 } }, s: t => { t.to(120, { stw: 1 }, 'o').to(900, { stw: 0 }).fx('juice', 'head', 3); bk(t); } },
    lemmy: { sw: 'bob', s: t => sp(t, { sqz: 0.9, mw: 0.5, frown: 0.2 }, 1000, 900) },
    kiwi: { sw: 'bob', k: { a: { fzz: 1 }, b: { fzz: 0.6 }, f: { fzz: 1 } }, s: t => sp(t, { fzz: 0.8, sqz: 0.5 }, 1400, 1000) },
    melo: { sw: 'bob', k: { a: { sdj: 1 }, b: { sdj: 0 } }, s: t => { t.osc(1400, 3, { sdj: 1 }, { sdj: 0 }, 'o').fx('meloseed', 'mouth', 2); bk(t); } },
    peachy: { sw: 'bob', s: t => sp(t, { blush: 1, lfl: 0.6, smile: 1 }, 1600, 1200) },
    pitaya: { sw: 'bob', k: { a: { wfl: 1 }, b: { wfl: 0.4 } }, s: t => { sp(t, { wfl: 1, wsp: 0.6, brf: 0.5 }, 1400, 1000); spray(t, 'body', 5); } },
    tutti: { sw: 'bob', k: { a: { wfl: 1 } }, s: t => { sp(t, { wfl: 0.8 }, 1400, 1000); t.fx('dust', 'body', 3); } },
    // ---------- Forest Friends ----------
    kiko: { s: t => { ears(t, 2).fx('spark', 'head', 3); bk(t); } },
    teddy: { s: t => { t.to(500, o(both(14, -4), { armL: 26, armR: 26, smile: 1, blush: 0.5 })).osc(1600, 3, { tongue: 0.4 }, { tongue: 0 }, 's'); bk(t, 500); } },
    hoot: { k: { a: { tfl: 1, wfl: 1 }, b: { tfl: 0.4 }, f: { tfl: 1 } }, s: t => { t.to(300, { wfl: 1, armL: 70, armR: 70 }, 'o').osc(900, 6, { armL: 80, armR: 80 }, { armL: 40, armR: 40 }, 'l'); spray(t, 'sideL', 5); spray(t, 'sideR', 5); bk(t); } },
    leo: { k: { a: { msh: 1, mfl: 1 }, b: { msh: 0.4 }, f: { mfl: 1 } }, s: t => { t.to(400, { mfl: 0.8, open: 0.4, puff: 0.3 }, 'o').wait(500).to(500, { mfl: 0, open: 0, puff: 0 }); bk(t); } },
    panko: { s: t => { t.to(500, { sk: t.B.sk + 3, close: 0.9 }, 's').osc(1800, 3, { tilt: 5, x: 1 }, { tilt: -5, x: -1 }, 's'); bk(t); } },
    acorn: { k: { a: { tfl: 1 }, b: { tfl: 0.5 }, f: { tfl: 1 } }, s: t => sp(t, { tfl: 1, tsw: 0.6 }, 1400, 1000) },
    fawn: { k: { a: { earL: -18, earR: 18 }, b: { earL: 18, earR: -18 } }, s: t => { ears(t, 3); bk(t); } },
    moss: { sw: 'bob', k: { a: { cb: 1 }, b: { cb: 0 } }, s: t => { t.osc(1400, 3, { cb: 0.9 }, { cb: 0 }, 'o').fx('spore', 'head', 3); bk(t); } },
    sprout: { k: { f: { blm: 1 } }, s: t => sp(t, { blm: 1, lfl: 0.6 }, 1800, 1600) },
    // ---------- Dreamland ----------
    hana: { k: { a: { flL: 0.6, tw: 1 }, b: { flR: 0.6, tw: -1 } }, s: t => { t.to(400, { flL: 0.9, flR: 0.9 }).osc(1200, 4, { tw: 1 }, { tw: -1 }, 's').to(400, { flL: 0, flR: 0 }); bk(t); } },
    boo: { sw: 'float', s: t => sp(t, { gho: 0.5, flr: 0.6 }, 1800, 1200) },
    pixie: { sw: 'float', k: { a: { wfl: 1 } }, s: t => { sp(t, { wfl: 1, wsp: 0.5, lift: t.B.lift + 2 }, 1400, 1000); t.fx('dust', 'body', 4); } },
    floof: { k: { a: { fzz: 1 }, b: { fzz: 0.7 }, f: { fzz: 1 } }, s: t => { t.to(200, { fzz: 0.9 }, 'o').osc(700, 6, { x: 0.6 }, { x: -0.6 }, 'l').to(400, { fzz: 0 }); bk(t); } },
    unibun: { s: t => { t.fx('spark', 'head', 5); ears(t, 2); bk(t); } },
    gumdrop: { sw: 'bob', k: { a: { jig: 1 }, b: { jig: 0.4 } }, s: t => sp(t, { jig: 1, hap: 1 }, 1200, 1000) },
    ember: { k: { a: { cfl: 0.6 }, f: { cfl: 1 } }, s: t => { t.to(300, { cfl: 0, wide: 0.8, open: 0.3 }, 'o').fx('steam', 'head').fx('steam', 'body').wait(500).to(400, { cfl: 0.8, sqz: 0.6, smile: 1 }).fx('steam', 'head'); bk(t); } },
    drako: { k: { a: { wsp: 1, tsw: 0.8 }, b: { tsw: -0.8 } }, s: t => { t.to(400, { puff: 0.6 }).to(200, { puff: 0 }).fx('steam', 'head').osc(1600, 2, { tsw: 0.7 }, { tsw: -0.7 }, 's'); spray(t, 'tail', 6); bk(t); } },
    jinni: { sw: 'float', s: t => { sp(t, { glo: 0.8, gwh: 0.6 }, 1600, 1200); t.fx('spark', 'body', 3); } },
    // ---------- Sweet Bakery ----------
    cuppy: { sw: 'bob', s: t => { t.fx('sprinkle', 'head').osc(1400, 3, { sq: t.B.sq + 0.05 }, { sq: t.B.sq }, 'o'); bk(t); } },
    chip: { sw: 'bob', s: t => { t.osc(800, 4, { x: 0.5 }, { x: -0.5 }, 'l').fx('crumb', 'body', 3); bk(t, 300); } },
    twisty: { sw: 'bob', s: t => { t.osc(2000, 2, { tilt: 5 }, { tilt: -5 }, 's').fx('salt', 'head'); bk(t); } },
    crois: { sw: 'bob', s: t => sp(t, { lean: 1.4, tilt: 3, smile: 1 }, 1800, 1200) },
    maca: { sw: 'bob', s: t => { t.to(100, { sq: t.B.sq + 0.1 }, 'o').to(200, { sq: t.B.sq }).wait(300).to(100, { sq: t.B.sq + 0.08 }, 'o').to(200, { sq: t.B.sq }); bk(t, 300); } },
    puddi: { sw: 'bob', s: t => { t.osc(1600, 6, { sq: t.B.sq + 0.06, x: 0.3 }, { sq: t.B.sq - 0.02, x: -0.3 }, 'l'); bk(t); } },
    mochi: { sw: 'bob', s: t => sp(t, { sq: t.B.sq + 0.16, smile: 1, close: 0.6 }, 1800, 1400) },
    cakey: { sw: 'bob', s: t => { t.to(500, { puff: 0.7 }).to(600, { puff: 0, open: 0.2, mw: 0.5 }, 'o').fx('gust', 'head').to(300, { open: 0, mw: 1 }); bk(t); } },
    sugarplum: { s: t => { t.to(400, { armR: 70, hRy: -2, smile: 0.9 }, 'o').osc(1400, 3, { hRx: -3 }, { hRx: 3 }, 's').fx('spark', 'head', 3); bk(t, 500); } },
    // ---------- Spooky Squish ----------
    gourdy: { sw: 'bob', s: t => { t.osc(2400, 2, { tilt: 6, x: 1 }, { tilt: -6, x: -1 }, 's'); bk(t); } },
    batty: { k: { a: { armL: 80, armR: 40 }, b: { armL: 40, armR: 80 } }, s: t => sp(t, { armL: 80, armR: 80, hLx: 12, hRx: -12 }, 1200, 1200) },
    kernel: { sw: 'bob', s: t => { t.to(120, { lift: t.B.lift + 3, sq: t.B.sq - 0.06 }, 'o').to(240, { lift: t.B.lift, sq: t.B.sq + 0.04 }, 'i').fx('spark', 'head', 2); spray(t, 'body', 5); bk(t); } },
    hexie: { s: t => { sp(t, { curl: 0.7 }, 1400, 1200); t.fx('spark', 'head', 3); } },
    mumbles: { s: t => { t.to(900, { armL: 88, armR: 88, hLy: -2, hRy: -2, open: 0.2 }, 'io').wait(1000).to(900, { armL: t.B.armL, armR: t.B.armR, hLy: t.B.hLy, hRy: t.B.hRy, open: 0 }, 'io'); bk(t, 300); } },
    hocus: { s: t => { t.fx('spark', 'body', 4).wait(800).fx('spark', 'body', 3); bk(t, 300); } },
    countsquishula: { s: t => { t.to(400, o(hand(-1, 10, -14), { armL: 60, close: 0.4, smile: 0.6 })).wait(1000).fx('spark', 'head', 2); bk(t, 500); } },
  };
  Object.keys(PROF).forEach(k => waterBuild(k, C[k] || {}));
});
