// Lobby state shared by Squad Lobby + Squad Select: which squishy is selected, and which owned ones you haven't looked at yet (NEW badge).
(function () {
  if (window.SquadLobby) return;
  const KEY = 'squishsquad.lobby.v1';
  let S = null;
  const Q = () => window.SquishSquad;
  function load() {
    if (S) return S;
    try { S = JSON.parse(localStorage.getItem(KEY)); } catch (e) {}
    if (!S || !Array.isArray(S.seen)) { const own = Q() ? Q().ownedIds() : []; S = { sel: null, seen: own.filter(id => id !== 9 && id !== 13) }; save(true); }
    return S;
  }
  function save(silent) { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} if (!silent) window.dispatchEvent(new CustomEvent('squadlobby')); }
  window.SquadLobby = {
    selected() { const s = load(), q = Q(); if (!q) return 1; if (s.sel != null && q.owns(s.sel)) return s.sel; const o = q.ownedIds(); return o.includes(1) ? 1 : o[0]; },
    select(id) { const q = Q(); if (!q || !q.owns(id)) return false; load().sel = id; if (!S.seen.includes(id)) S.seen.push(id); save(); return true; },
    isNew(id) { const q = Q(); return !!(q && q.owns(id) && !load().seen.includes(id)); },
    markSeen(id) { const s = load(); if (!s.seen.includes(id) && Q() && Q().owns(id)) { s.seen.push(id); save(); } },
  };
  window.addEventListener('storage', e => { if (e.key === KEY) { S = null; window.dispatchEvent(new CustomEvent('squadlobby')); } });
})();
