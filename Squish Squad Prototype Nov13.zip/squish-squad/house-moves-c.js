// Per-creature furniture moves (sit down, sit, stand up, lounge) for all 79 house creatures (heroes left out).
// Each creature: base pose, its own way of getting on/off, its own fidgets (sig = signature move, also used when lounging).
window.HouseCreatures = window.HouseCreatures || []; window.HouseCreatures.push(function (H) {
  const { build, hand, both, o } = H;
  const sp = (t, v, d, hold) => { const ks = Object.keys(v), b = {}; ks.forEach(k => b[k] = t.B[k] != null ? t.B[k] : 0); t.to((d || 700) * 0.4, v, 'o').wait(hold || 300).to((d || 700) * 0.6, b, 'io'); return t; };
  const bk = (t, d) => t.back(d || 420);
  const FL = o({ sit: 0, lift: 1.4, sq: 0.02, pitch: 0.04 }, both(5, 1));
  const SEA = o({ sit: 0, lift: -1.8, sq: 0.13, pitch: 0.08 }, both(5, 2));
  const hop = { dn: 'hop', up: 'hop' }, flt = { dn: 'float', up: 'float', pose: FL, lpose: { sit: 0, lift: 0.4, sq: 0.06, tilt: -5 } }, sea = { dn: 'flop', up: 'flop', pose: SEA, lpose: { sit: 0 } };
  const mk = (key, base, P) => build(key, o(base, P, { pose: o(base.pose || {}, P.pose || {}), lpose: o(base.lpose || {}, P.lpose || {}) }));

  // ---------- Pet Shop ----------
  mk('mittens', hop, { lpose: { armL: 68, armR: 68 }, f: ['look', t => { t.to(320, o(both(5, 8), { close: 0.65, smile: 0.9, hap: 0.4 })).osc(2600, 6, { hLy: 11, hRy: 7, sq: t.B.sq + 0.012 }, { hLy: 7, hRy: 11, sq: t.B.sq }, 's'); bk(t); }, 'swing', 'ears', 'yawn'],
    lf: ['sigh', t => { sp(t, { curl: 0.9, wag: 14, close: 0.9, smile: 1 }, 1600, 1600); }, 'doze', 'stretch'] });
  mk('biscuit', hop, { lpose: { armL: 68, armR: 68 }, gap: [1300, 2000, 1700, 2400], f: ['look', t => { t.to(200, { hap: 0.9, smile: 1, open: 0.3 }).osc(1600, 8, { wag: 26, lift: t.B.lift + 0.7 }, { wag: -26, lift: t.B.lift }, 'o'); bk(t); },
    t => { t.to(360, { footR: 6, earR: 18, sqz: 0.8, tilt: -4, htilt: -8, open: 0.2 }, 'io').osc(1200, 6, { footR: 7.5 }, { footR: 5.5 }, 'l'); bk(t, 360); }, 'kick', 'pat'],
    lf: ['belly', t => sp(t, { armL: 70, armR: 70, hLy: -2, hRy: -2, tilt: -8, hap: 0.7, smile: 1, open: 0.3, footL: 4, footR: 4 }, 1300, 1800), 'doze', 'sigh'] });
  mk('prickle', hop, { lpose: { armL: 40, armR: 40, hLx: 2, hRx: -2, hLy: 2, hRy: 2 }, f: ['look', t => { t.to(380, { curl: 1, sq: t.B.sq + 0.14, close: 1, armL: -10, armR: -10 }, 'io').wait(1000).to(180, { curl: 0, sq: t.B.sq - 0.05, wide: 0.6 }, 'o').fx('spark', 'head', 2); bk(t); }, 'swing', 'giggle'],
    lf: ['sigh', 'doze', t => sp(t, { curl: 0.6, close: 0.9 }, 1400, 1200), 'stretch'] });
  // Nov 9: Truffle the piglet (took Prickle's slot) + Ribbit the frog (new)
  mk('truffle', hop, { lpose: { armL: 60, armR: 60 }, f: ['look', t => { t.to(260, { hap: 0.8, smile: 1, sqz: 0.4 }).osc(1500, 6, { tilt: 3, wag: 22, lift: t.B.lift + 0.5 }, { tilt: -3, wag: -22, lift: t.B.lift }, 's'); bk(t); }, 'ears', 'giggle'],
    lf: ['doze', 'belly', t => sp(t, { sq: t.B.sq + 0.12, smile: 1, close: 0.8, blush: 0.6 }, 1500, 1400), 'sigh'] });
  mk('ribbit', { dn: 'hop', up: 'hop', pose: { lift: -1.2, sq: 0.08 } }, { lpose: { armL: 30, armR: 30 }, f: ['look', t => { for (let i = 0; i < 2; i++) t.to(110, { sq: t.B.sq + 0.12 }, 'i').to(170, { lift: t.B.lift + 5, sq: t.B.sq - 0.1, hap: 1, open: 0.4 }, 'o').to(160, { lift: t.B.lift, sq: t.B.sq + 0.04 }, 'i').wait(160); bk(t); }, 'giggle', 'swing'],
    lf: ['doze', 'sigh', 'stretch'] });
  mk('nibbles', { dn: 'climb', up: 'hop' }, { f: ['look', t => { t.to(300, o(both(9, -9), { puff: 1, armL: 24, armR: 24 })).osc(1800, 6, { open: 0.25, htilt: 3 }, { open: 0, htilt: -3 }, 's').fx('crumb', 'head'); bk(t); }, 'kick', 'ears', 'swing'],
    lf: ['doze', t => sp(t, { puff: 1, smile: 1, close: 0.8 }, 1200, 1400), 'belly', 'sigh'] });
  mk('quill', hop, { lpose: { armL: 44, armR: 44, hLx: 2, hRx: -2, hLy: 2, hRy: 2 }, gap: [2200, 2800, 2000], f: ['look', t => { t.to(380, o(both(10, -14), { armL: 40, armR: 40, blush: 0.9, sq: t.B.sq + 0.04 })).wait(900).to(260, { hLx: 4, ly: 0.4, lx: -0.6 }).wait(700).to(220, { hLx: 10 }); bk(t, 480); }, 'swing', 'giggle'],
    lf: ['sigh', 'doze', 'belly', t => sp(t, { blush: 0.8, smile: 1, htilt: 7 }, 1200, 1000)] });
  mk('waffles', { dn: 'flop', up: 'hop', pose: { lift: -3.2, sq: 0.15 } }, { f: ['look', t => { t.to(500, { sq: t.B.sq + 0.1, lift: t.B.lift - 1.2, close: 0.75, smile: 0.9, footL: -1, footR: -1 }, 's').wait(1600); bk(t, 600); }, 'wag', 'bounce'],
    lf: ['doze', t => { t.to(600, { close: 1, open: 0.15, pitch: t.B.pitch - 0.1 }).osc(3000, 3, { sq: t.B.sq + 0.05 }, { sq: t.B.sq - 0.02 }, 's'); bk(t); }, 'sigh', 'belly'] });
  mk('poppy', { dn: 'spin', up: 'hop' }, { lpose: { armL: 24, armR: 24, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, gap: [1200, 2000, 1500], f: ['look', t => { for (let i = 0; i < 3; i++) t.to(110, { sq: t.B.sq + 0.1 }, 'i').to(170, { lift: t.B.lift + 4, sq: t.B.sq - 0.08, hap: 1, open: 0.5, footL: 2, footR: 2 }, 'o').to(160, { lift: t.B.lift, sq: t.B.sq, footL: 0, footR: 0 }, 'i').wait(140); bk(t); }, 'swing', 'ears'],
    lf: ['sigh', 'doze', 'stretch', t => sp(t, { lift: t.B.lift + 2, hap: 1, open: 0.4 }, 500, 100)] });
  mk('duchess', hop, { pose: { pitch: 0.16 }, lpose: { armL: 38, armR: 38, hLx: 2, hRx: -2, hLy: 2, hRy: 2 }, gap: [2400, 3000, 2600], f: ['look', t => { t.to(400, o(hand(1, 9, -13), { armR: 34, close: 0.7, htilt: 6 })).osc(1600, 5, { tongue: 0.6, hRy: -15 }, { tongue: 0.1, hRy: -12 }, 's'); bk(t); }, t => sp(t, { htilt: 9, close: 0.55, smile: 0.6, pitch: 0.28 }, 1200, 1400), 'swing'],
    lf: ['sigh', t => { t.to(400, o(hand(1, 4, -6), { armR: 46 })).osc(2400, 4, { hRx: -2, armR: 56 }, { hRx: -6, armR: 46 }, 's'); bk(t); }, 'doze', 'stretch'] });
  mk('mamapaws', hop, { lpose: o(both(9, 5), { armL: 14, armR: 14 }), f: ['look', t => { t.to(300, { close: 0.6, smile: 1, hap: 0.4 }).fx('heart', 'head').osc(3200, 4, { lean: 1.4, tilt: 2.4 }, { lean: -1.4, tilt: -2.4 }, 's'); bk(t); }, 'wag', 'pat', 'yawn'],
    lf: ['doze', 'sigh', 'belly', t => sp(t, { close: 0.8, smile: 1, htilt: -6 }, 1400, 1400).fx('heart', 'head')] });

  // ---------- Sky & Stars ----------
  mk('nimbo', { dn: 'bounce', up: 'hop', pose: { sq: 0.15, lift: -2.2 } }, { lpose: { armL: 32, armR: 32, hLx: 2, hRx: -2, hLy: 2, hRy: 2 }, gap: [2000, 2600, 2200], f: ['look', t => { t.to(400, { close: 0.6, smile: 0.5 }).fx('drop', 'body', 3).wait(700).fx('drop', 'body', 3).wait(700); bk(t); }, 'nod', 'wiggle'],
    lf: ['doze', t => { t.to(500, { close: 1 }).fx('drop', 'body', 2).wait(900).fx('drop', 'body', 2).wait(600); bk(t); }, 'sigh', 'stretch'] });
  mk('lumi', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(450, o(hand(1, 2, -10), { armR: 80, hap: 0.6, smile: 1, ly: -0.6 }), 'io').fx('spark', 'head', 3).wait(1300); bk(t, 520); }, 'swing', 'ears', 'hum'],
    lf: ['doze', t => sp(t, { armR: 40, close: 0.8, smile: 1 }, 1200, 1400).fx('spark', 'head', 2), 'sigh', 'stretch'] });
  mk('bubbly', flt, { gap: [2200, 2600], f: ['look', t => { t.osc(3000, 2, { turn: 0.5, x: 1 }, { turn: -0.5, x: -1 }, 's').fx('spark', 'body', 3); bk(t); }, 'wiggle', 'hum'], lf: ['sigh', 'doze', t => sp(t, { sq: 0.1, close: 0.8 }, 1400, 800)] });
  mk('twinkle', hop, { gap: [1800, 2400, 2000], f: ['look', 'nod', t => { t.to(260, { wide: 0.7, hap: 0.8, smile: 1 }, 'o').fx('spark', 'body', 5).wait(500).fx('spark', 'body', 4); bk(t); }, 'swing'],
    lf: ['doze', 'doze', t => sp(t, { close: 1, open: 0.15 }, 1500, 2200), 'sigh'] });
  mk('zappi', { dn: 'spin', up: 'hop' }, { gap: [1200, 1800, 1500], f: ['look', t => { t.to(80, { zap: 1, wide: 1, x: 0.8 }, 'o').osc(600, 6, { x: -0.8 }, { x: 0.8 }, 'l').fx('spark', 'body', 6).to(300, { zap: 0, wide: 0, x: 0 }); bk(t); }, 'kick', 'wiggle'],
    lf: ['sigh', t => { t.to(80, { zap: 0.6 }, 'o').fx('spark', 'body', 3).to(400, { zap: 0 }); }, 'doze', 'stretch'] });
  mk('plip', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.fx('drop', 'head', 2).osc(1200, 3, { sq: t.B.sq + 0.07 }, { sq: t.B.sq - 0.03 }, 'o'); bk(t); }, 'swing', 'hum'], lf: ['sigh', 'doze', t => sp(t, { sq: t.B.sq + 0.1, close: 0.9 }, 1400, 1000).fx('drop', 'body', 2)] });
  mk('breeze', flt, { f: ['look', t => { t.to(300, { open: 0.5, puff: 0.6, lean: -1.4 }).fx('gust', 'head').to(500, { lean: 2, open: 0.1, puff: 0 }, 'o').wait(400); bk(t); }, 'hum', 'wiggle'], lf: ['sigh', 'doze', t => sp(t, { lean: 2.4, close: 0.9 }, 1600, 900).fx('gust', 'head')] });
  mk('dusty', hop, { f: ['look', 'ears', t => { t.fx('dust', 'body', 4).osc(900, 3, { sq: t.B.sq + 0.05 }, { sq: t.B.sq }, 'o').fx('dust', 'body', 3); bk(t); }, 'swing'], lf: ['sigh', 'doze', 'ears', 'stretch'] });
  mk('aurora', sea, { gap: [2200, 2800, 2400], f: ['look', t => { t.to(300, { spout: 1, hap: 0.6 }, 'o').fx('drop', 'head', 4).wait(900).to(400, { spout: 0 }); bk(t); }, t => sp(t, { glow: 1, close: 0.6, smile: 1 }, 1600, 1600), 'hum'],
    lf: ['doze', t => sp(t, { glow: 0.8, close: 1 }, 1800, 2000), 'sigh'] });

  // ---------- Snack Shack ----------
  mk('mallow', { dn: 'bounce', up: 'hop' }, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(1200, { sq: t.B.sq + 0.2, lift: t.B.lift - 1.6, close: 0.85, smile: 1 }, 's').wait(800).to(220, { sq: t.B.sq - 0.08, lift: t.B.lift + 1, close: 0, wide: 0.4 }, 'o'); bk(t); }, 'swing', 'hum'],
    lf: ['sigh', 'doze', t => sp(t, { sq: t.B.sq + 0.14, close: 1 }, 1800, 1200), 'stretch'] });
  mk('bao', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(500, { sq: t.B.sq - 0.07, lift: t.B.lift + 1.4, hap: 0.6, smile: 1 }, 'o').fx('steam', 'head').wait(500).fx('steam', 'head'); bk(t, 600); }, 'swing', 'bounce'], lf: ['sigh', t => { t.fx('steam', 'head').wait(800).fx('steam', 'head'); }, 'doze', 'stretch'] });
  mk('dunkie', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(200, { hap: 0.8, smile: 1 }).osc(1200, 4, { x: 1.1, tilt: 3 }, { x: -1.1, tilt: -3 }, 's').fx('sprinkle', 'head'); bk(t); }, 'kick', 'yawn'], lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('frybo', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => sp(t, { fw: 1, hap: 0.7, smile: 1 }, 900, 900), t => { t.fx('salt', 'head').osc(900, 4, { x: 0.8 }, { x: -0.8 }, 'l').fx('salt', 'head'); bk(t, 300); }, 'swing'], lf: ['sigh', t => sp(t, { fw: 0.6, close: 0.8 }, 1400, 1200), 'doze', 'belly'] });
  mk('bunbun', { dn: 'spin', up: 'hop' }, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(300, { split: 0.4, hap: 0.8, smile: 1 }, 'o').osc(1000, 2, { shuf: 0.6 }, { shuf: -0.6 }, 's').to(260, { split: 0, shuf: 0 }, 'i').to(160, { sq: t.B.sq + 0.06 }, 'o'); bk(t); }, 'kick', 'giggle'],
    lf: ['sigh', 'doze', t => sp(t, { split: 0.2, close: 0.8 }, 1200, 1000), 'belly'] });
  mk('choco', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => sp(t, { melt: 0.3, close: 0.75, smile: 1 }, 1600, 1600), 'swing', 'pat'], lf: ['sigh', t => sp(t, { melt: 0.45, close: 1, smile: 1 }, 2000, 1800), 'doze', 'belly'] });
  mk('scoop', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.osc(1400, 4, { chb: 1, hap: 0.7 }, { chb: 0, hap: 0.4 }, 'o'); bk(t); }, 'swing', 'hum'], lf: ['sigh', 'doze', t => { t.osc(1600, 2, { chb: 0.6 }, { chb: 0 }, 'o'); }, 'stretch'] });
  mk('boba', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(300, { sqz: 0.6, open: 0.15, mw: 0.5, puff: -0.3 }).osc(1200, 6, { x: 0.5, sq: t.B.sq + 0.02 }, { x: -0.5, sq: t.B.sq }, 'l').to(200, { sqz: 0, hap: 1, smile: 1, mw: 1, puff: 0 }, 'o').wait(400); bk(t); }, 'kick', 'wiggle'],
    lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('chefbun', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, pose: { pitch: 0.1 }, f: ['look', t => { t.to(380, o(hand(1, 10, -14), { armR: 36, close: 0.8, smile: 1 })).wait(300).to(260, o(hand(1, -6, -16), { armR: 70, open: 0.3, hap: 1 }), 'o').fx('heart', 'head'); bk(t); }, 'swing', 'pat'],
    lf: ['sigh', 'doze', 'belly', 'stretch'] });

  // ---------- Ocean Pals ----------
  mk('pip', { dn: 'slide', up: 'hop' }, { f: ['look', t => { t.to(160, { hap: 0.8, smile: 1 }).osc(1000, 6, { armL: 42, armR: 42 }, { armL: 4, armR: 4 }, 'o'); bk(t); }, 'kick', 'wiggle'], lf: ['sigh', 'doze', t => { t.osc(1200, 3, { armL: 24, armR: 24 }, { armL: 0, armR: 0 }, 'o'); }, 'belly'] });
  mk('jelli', flt, { gap: [1800, 2400, 2000], f: ['look', t => { for (let i = 0; i < 3; i++) t.to(240, { sq: t.B.sq + 0.1, lift: t.B.lift - 0.4 }, 'i').to(420, { sq: t.B.sq - 0.08, lift: t.B.lift + 2 }, 'o').to(380, { sq: t.B.sq, lift: t.B.lift }, 's'); bk(t); }, 'hum', ['wave', 1]],
    lf: ['sigh', 'doze', t => { t.osc(2400, 2, { sq: t.B.sq + 0.06 }, { sq: t.B.sq - 0.04 }, 's'); }] });
  mk('finn', sea, { f: ['look', t => { t.to(200, { hap: 0.8, smile: 1 }).osc(900, 6, { open: 0.5 }, { open: 0.1 }, 'l').fx('note', 'head'); bk(t); }, t => { t.osc(1200, 4, { wag: 28 }, { wag: -28 }, 'io').fx('drop', 'body', 4); bk(t); }, ['wave', 1]],
    lf: ['sigh', 'doze', t => { t.osc(1600, 2, { wag: 14 }, { wag: -14 }, 's'); }, 'belly'] });
  mk('sealy', sea, { f: ['look', t => { t.to(300, o(both(1, -4), { armL: 30, armR: 30, hap: 1, smile: 1 })).osc(1200, 5, { hLx: 1, hRx: -1, open: 0.5 }, { hLx: 6, hRx: -6, open: 0.1 }, 'o'); bk(t); }, 'wiggle', 'giggle'],
    lf: ['sigh', 'doze', 'belly', t => sp(t, { tilt: -9, hap: 0.8, smile: 1 }, 1400, 1000)] });
  mk('puff', o(flt, { dn: 'float' }), { f: ['look', t => { t.to(500, { blo: 0.55, puff: 0.6, wide: 0.6 }, 'o').wait(700).fx('bubble', 'head').to(800, { blo: 0, puff: 0, wide: 0 }, 'io').fx('bubble', 'head'); bk(t); }, 'hum', 'wiggle'],
    lf: ['sigh', 'doze', t => sp(t, { blo: 0.3, close: 1 }, 1600, 1400)] });
  mk('shelly', { dn: 'climb', up: 'hop' }, { gap: [2000, 2800, 2200], f: ['look', t => { t.to(600, { nk: 1, ly: -0.3 }, 'io').to(500, { lx: -1, turn: -0.3 }).wait(500).to(600, { lx: 1, turn: 0.3 }).wait(500).to(500, { lx: 0, turn: 0, nk: 0, ly: 0 }, 'io'); bk(t); },
    t => { t.to(400, { hid: 0.75 }, 'io').wait(1200).to(260, { hid: 0 }, 'o').fx('spark', 'head', 2); bk(t); }, 'swing'], lf: ['doze', t => { t.to(700, { hid: 0.5 }).wait(2400).to(400, { hid: 0 }); }, 'sigh'] });
  mk('octo', { dn: 'bounce', up: 'hop', pose: { sit: 0 } }, { f: ['look', t => sp(t, { ow: 1, hap: 0.6, smile: 1 }, 1600, 1400), t => sp(t, { ocl: 1, close: 0.7 }, 1400, 1000), 'hum'], lf: ['sigh', 'doze', t => sp(t, { osp: 0.7, close: 0.8 }, 1600, 1600)] });
  mk('marina', { dn: 'slide', up: 'hop', pose: { sit: 0 } }, { f: ['look', t => { t.to(400, { tlf: 0.8, tsw: 0.6 }, 'o').osc(1000, 2, { tsw: -0.6 }, { tsw: 0.6 }, 's').fx('drop', 'body', 4).to(400, { tlf: 0, tsw: 0 }); bk(t); }, t => sp(t, { htilt: -10, lean: -1.4, close: 0.6, smile: 1 }, 1000, 600), 'hum'],
    lf: ['sigh', 'doze', t => sp(t, { tlf: 0.5, close: 1 }, 1600, 1600)] });
  mk('pearl', sea, { f: ['look', t => sp(t, { glow: 1, wide: 0.3, hap: 0.6 }, 1200, 1000).fx('spark', 'head', 4), t => sp(t, { fflap: 1, hap: 0.7, smile: 1 }, 1200, 900), 'hum'], lf: ['doze', t => sp(t, { glow: 0.6, close: 1 }, 1800, 1800), 'sigh'] });

  // ---------- Fruit Patch ----------
  mk('pina', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(220, { crw: 1, hap: 0.8 }, 'o').osc(1000, 4, { htilt: 6 }, { htilt: -6 }, 'l').to(300, { crw: 0 }); bk(t); }, 'swing', 'hum'], lf: ['sigh', 'doze', t => sp(t, { crs: 0.6, close: 0.9 }, 1600, 1200), 'belly'] });
  mk('avo', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(200, { prw: 1, pp: 0.35, wide: 0.4 }, 'o').wait(900).to(300, { prw: 0, pp: 0, wide: 0 }); bk(t); }, 'swing', 'pat'], lf: ['sigh', 'belly', 'doze', t => sp(t, { pr: 0.5, close: 0.9 }, 1600, 1000)] });
  mk('berri', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(120, { stw: 1, hap: 0.7 }, 'o').to(900, { stw: 0 }, 'bk'); bk(t); }, 'kick', 'swing'], lf: ['sigh', 'doze', t => sp(t, { lfl: 0.6, close: 0.8 }, 1400, 1000), 'belly'] });
  mk('lemmy', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(200, { sqz: 1, mw: 0.4, open: 0.12, frown: 0.4 }, 'o').osc(700, 7, { x: 0.6 }, { x: -0.6 }, 'l').to(200, { sqz: 0, mw: 1, open: 0, frown: 0, wide: 0.6 }, 'o').wait(300); bk(t); }, 'swing', 'pat'],
    lf: ['sigh', 'doze', t => sp(t, { lfl: 0.5, close: 0.9 }, 1400, 1000), 'belly'] });
  mk('kiwi', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(220, { fzz: 1, sqz: 0.6 }, 'o').osc(700, 6, { x: 0.7 }, { x: -0.7 }, 'l').to(400, { fzz: 0, sqz: 0, hap: 0.6 }); bk(t); }, 'kick', 'ears'], lf: ['sigh', 'doze', t => sp(t, { fzz: 0.4, close: 1 }, 1600, 1400), 'belly'] });
  mk('melo', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(300, { puff: 0.7, open: 0 }).to(120, { puff: 0, open: 0.4, pitch: t.B.pitch - 0.1 }, 'o').fx('seed', 'head').to(300, { open: 0, pitch: t.B.pitch, hap: 0.8, smile: 1 }).wait(400); bk(t); }, 'swing', t => { t.osc(1000, 3, { sdj: 1 }, { sdj: 0 }, 'o'); }],
    lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('peachy', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(400, o(both(9, -12), { armL: 30, armR: 30, blush: 1, close: 0.6, smile: 1 })).osc(1600, 2, { tilt: 3, htilt: 6 }, { tilt: -3, htilt: -6 }, 's'); bk(t); }, 'swing', 'hum'], lf: ['sigh', 'doze', t => sp(t, { blush: 0.9, lfl: 0.5, close: 0.9 }, 1600, 1200), 'belly'] });
  mk('pitaya', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => sp(t, { wfl: 1, wsp: 0.6, hap: 0.8, smile: 1 }, 1400, 1000).fx('spark', 'body', 4), 'swing', 'kick'], lf: ['sigh', 'doze', t => sp(t, { wsp: 0.8, close: 0.9 }, 1600, 1400), 'belly'] });
  mk('tutti', hop, { f: ['look', t => { t.to(300, { fL: 1, ly: -0.8, hap: 0.8 }, 'o').to(400, { fL: 0, ly: 0 }, 'i').to(300, { fR: 1, ly: -0.8 }, 'o').to(400, { fR: 0, ly: 0 }, 'i'); bk(t); }, 'swing', t => sp(t, { wfl: 1, hap: 0.6 }, 1200, 900).fx('dust', 'body', 3)],
    lf: ['sigh', 'doze', t => sp(t, { wfl: 0.5, close: 0.9 }, 1600, 1200), 'belly'] });

  // ---------- Forest Friends ----------
  mk('kiko', hop, { f: ['look', t => { t.to(300, { htilt: -10, lean: -1.4 }).to(360, { htilt: 9, lean: 1.4, close: 0.6, smile: 1 }, 'o').fx('spark', 'head', 3).wait(500); bk(t); }, 'swing', 'ears'], lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('teddy', hop, { f: ['look', t => { t.to(450, o(both(14, -6), { armL: 30, armR: 30, close: 0.8, smile: 1, hap: 0.6, blush: 0.6 })).fx('heart', 'head').osc(2000, 2, { lean: 1.2, tilt: 2 }, { lean: -1.2, tilt: -2 }, 's'); bk(t, 500); }, 'swing', 'ears', 'yawn'],
    lf: ['belly', 'doze', 'sigh', 'stretch'] });
  mk('hoot', hop, { gap: [1800, 2400, 2000], f: ['look', t => { t.to(600, { turn: 0.85, lx: 1, tfl: 0.6 }, 'io').wait(500).to(800, { turn: -0.85, lx: -1 }, 'io').wait(500).to(500, { turn: 0, lx: 0, tfl: 0 }); bk(t); }, 'nod', t => sp(t, { wfl: 1, hap: 0.5 }, 900, 500)],
    lf: ['doze', 'sigh', t => sp(t, { tfl: 0.6, close: 1 }, 1400, 1400)] });
  mk('leo', hop, { f: ['look', t => { t.to(200, { msh: 1, mfl: 0.6 }).osc(900, 4, { htilt: 7 }, { htilt: -7 }, 'l').to(300, { msh: 0, mfl: 0 }); bk(t); }, t => sp(t, { open: 0.6, wide: 0.4, mfl: 0.8, pitch: t.B.pitch + 0.15 }, 700, 400), 'swing'],
    lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('panko', hop, { pose: { sq: 0.13 }, f: ['look', t => { t.to(400, o(hand(1, 11, -14), { armR: 34 })).osc(2000, 7, { open: 0.3, puff: 0.6 }, { open: 0.05, puff: 0.3 }, 's').fx('crumb', 'head'); bk(t); }, 'swing', 'bounce'],
    lf: ['doze', 'belly', 'sigh', t => sp(t, { tilt: -10, hap: 0.6, smile: 1 }, 1500, 1200)] });
  mk('acorn', { dn: 'climb', up: 'hop' }, { f: ['look', t => { t.osc(1000, 4, { tfl: 1, tsw: 0.8 }, { tfl: 0.2, tsw: -0.8 }, 's'); bk(t); }, t => { t.to(300, o(both(9, -11), { armL: 30, armR: 30 })).osc(1400, 7, { open: 0.25 }, { open: 0 }, 'l').fx('crumb', 'head'); bk(t); }, 'swing'],
    lf: ['sigh', 'doze', t => sp(t, { tsw: 0.6, close: 1 }, 1600, 1200), 'belly'] });
  mk('fawn', hop, { f: ['look', 'ears', t => { t.osc(700, 4, { ly: -0.2, sq: t.B.sq + 0.01 }, { ly: 0, sq: t.B.sq }, 'l').to(200, { hap: 0.5, smile: 1 }); bk(t); }, 'swing'], lf: ['sigh', 'doze', 'ears', 'stretch'] });
  mk('moss', hop, { f: ['look', t => { t.osc(1200, 3, { cb: 1 }, { cb: 0 }, 'o').fx('dust', 'head', 3); bk(t); }, 'swing', 'wiggle'], lf: ['sigh', 'doze', t => sp(t, { csp: 0.5, close: 0.9 }, 1600, 1000)] });
  mk('sprout', hop, { f: ['look', t => sp(t, { blm: 1, hap: 0.7, smile: 1 }, 1600, 1600).fx('spark', 'head', 3), 'swing', t => { t.osc(1200, 3, { stw: 1 }, { stw: 0 }, 'o'); }], lf: ['sigh', 'doze', t => sp(t, { blm: 0.7, close: 1 }, 1800, 1600)] });

  // ---------- Dreamland ----------
  mk('hana', hop, { f: ['look', t => { t.to(300, { flL: 1 }, 'io').wait(700).to(300, { flL: 0, flR: 1 }, 'io').wait(700).to(300, { flR: 0 }); bk(t); }, 'kick', t => { t.osc(1000, 4, { tw: 1 }, { tw: -1 }, 's'); bk(t); }], lf: ['sigh', 'doze', t => sp(t, { flL: 0.8, flR: 0.8, close: 1 }, 1600, 1600), 'belly'] });
  mk('boo', flt, { gap: [2200, 2600, 2000], f: ['look', t => { t.to(400, o(both(10, -14), { armL: 40, armR: 40, blush: 0.9, gho: 0.45 })).wait(900).to(400, { gho: 0 }).wait(200); bk(t); }, t => sp(t, { flr: 1, hap: 0.6 }, 1200, 600), 'hum'],
    lf: ['sigh', 'doze', t => sp(t, { gho: 0.3, close: 1 }, 1800, 1400)] });
  mk('pixie', o(flt, { dn: 'float' }), { f: ['look', t => sp(t, { wfl: 1, wsp: 0.6, hap: 0.8 }, 1000, 800).fx('dust', 'body', 4), 'giggle', 'kick'], lf: ['sigh', 'doze', t => sp(t, { wfl: 0.5, close: 0.9 }, 1600, 1400)] });
  mk('floof', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, pose: { sq: 0.12 }, f: ['look', t => { t.to(200, { fzz: 1, sqz: 0.8 }, 'o').osc(900, 9, { x: 0.8 }, { x: -0.8 }, 'l').fx('dust', 'body', 4).to(400, { fzz: 0, sqz: 0, hap: 0.7 }); bk(t); }, 'swing', 'bounce'], lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('unibun', hop, { f: ['look', t => { t.to(300, { pitch: t.B.pitch - 0.12, close: 0.5 }).fx('spark', 'head', 5).wait(500).to(300, { pitch: t.B.pitch, close: 0, hap: 0.8, smile: 1 }); bk(t); }, 'ears', 'swing'], lf: ['sigh', 'doze', 'ears', 'stretch'] });
  mk('gumdrop', { dn: 'bounce', up: 'hop' }, { f: ['look', t => sp(t, { jig: 1, hap: 0.7, smile: 1 }, 1000, 900), 'bounce', 'wiggle'], lf: ['sigh', 'doze', t => sp(t, { jig: 0.5, close: 1 }, 1400, 900), 'belly'] });
  mk('ember', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => sp(t, { cfl: 1, hap: 0.6, wide: 0.3 }, 1000, 900), 'swing', t => { t.to(160, { hap: 0.8 }).osc(1000, 6, { armL: 40, armR: 40 }, { armL: 4, armR: 4 }, 'o'); bk(t); }], lf: ['sigh', 'doze', t => sp(t, { cfl: 0.4, close: 1 }, 1600, 1400), 'belly'] });
  mk('drako', hop, { f: ['look', t => { t.osc(1600, 3, { tsw: 1 }, { tsw: -1 }, 's'); bk(t); }, t => { t.to(300, { puff: 0.8 }).to(150, { puff: 0, open: 0.3 }, 'o').fx('steam', 'head').to(300, { open: 0, blush: 0.6, smile: 1 }).wait(500); bk(t); }, 'swing', t => sp(t, { wfl: 1, wsp: 0.5 }, 900, 600)],
    lf: ['sigh', 'doze', t => sp(t, { tcu: 0.5, close: 1 }, 1600, 1400), 'belly'] });
  mk('jinni', flt, { f: ['look', t => sp(t, { glo: 1, gwh: 1, hap: 0.6, smile: 1 }, 1400, 1200).fx('spark', 'body', 4), t => { t.to(400, o(both(12, -8), { armL: 40, armR: 40, close: 0.6 })).wait(1000); bk(t); }, 'hum'], lf: ['sigh', 'doze', t => sp(t, { glo: 0.6, close: 1 }, 1600, 1400)] });

  // ---------- Sweet Bakery ----------
  mk('cuppy', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(200, { hap: 0.8, smile: 1 }).fx('sprinkle', 'head').osc(900, 3, { htilt: 6 }, { htilt: -6 }, 's'); bk(t); }, 'swing', 'kick'], lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('chip', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.osc(800, 5, { x: 0.7 }, { x: -0.7 }, 'l').fx('crumb', 'body', 4); bk(t, 300); }, 'swing', 'pat'], lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('twisty', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(200, { hap: 0.7, smile: 1 }).osc(1600, 3, { tilt: 5, lean: 1.4 }, { tilt: -5, lean: -1.4 }, 's').fx('salt', 'head'); bk(t); }, 'swing', 'giggle'], lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('crois', hop, { f: ['look', t => { t.osc(2600, 2, { lean: 1.6, tilt: 3, close: 0.5 }, { lean: -1.6, tilt: -3, close: 0.2 }, 's'); bk(t); }, 'swing', 'hum'], lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('maca', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(100, { sq: t.B.sq + 0.12 }, 'o').to(140, { sq: t.B.sq - 0.06, hap: 0.8 }, 'o').to(200, { sq: t.B.sq }).wait(200).to(100, { sq: t.B.sq + 0.1 }, 'o').to(160, { sq: t.B.sq }); bk(t); }, 'swing', 'kick'], lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('puddi', { dn: 'bounce', up: 'hop' }, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.osc(1200, 8, { sq: t.B.sq + 0.06, x: 0.4 }, { sq: t.B.sq - 0.03, x: -0.4 }, 'l').to(200, { hap: 0.6, smile: 1 }); bk(t); }, 'swing', 'hum'], lf: ['sigh', 'doze', t => { t.osc(1600, 4, { sq: t.B.sq + 0.04 }, { sq: t.B.sq - 0.02 }, 's'); }] });
  mk('mochi', { dn: 'bounce', up: 'hop' }, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(700, { sq: t.B.sq - 0.16, lift: t.B.lift + 1.6, armL: 150, armR: 150, close: 0.8, open: 0.4 }, 'io').to(260, { sq: t.B.sq + 0.18, lift: t.B.lift - 0.6, armL: 0, armR: 0, close: 0, open: 0 }, 'i').to(300, { sq: t.B.sq - 0.03 }, 'o'); bk(t); }, 'swing', 'giggle'],
    lf: ['sigh', 'doze', t => sp(t, { sq: t.B.sq + 0.12, close: 1 }, 1600, 1200), 'belly'] });
  mk('cakey', hop, { lpose: { armL: 12, armR: 12, hLx: 3, hRx: -3, hLy: 3, hRy: 3 }, f: ['look', t => { t.to(400, { puff: 0.9, pitch: t.B.pitch - 0.1 }).to(500, { puff: 0, open: 0.25, mw: 0.5, pitch: t.B.pitch + 0.1 }, 'o').fx('gust', 'head').to(300, { open: 0, mw: 1, pitch: t.B.pitch, hap: 0.8, smile: 1 }).wait(400); bk(t); }, 'swing', 'kick'],
    lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('sugarplum', hop, { pose: { pitch: 0.12 }, f: ['look', t => { t.to(400, { armR: 110, hRy: -2, smile: 1, close: 0.4, htilt: 5 }, 'o').osc(1600, 3, { hRx: -3 }, { hRx: 3 }, 's').fx('spark', 'head', 3); bk(t); }, 'swing', 'pat'], lf: ['sigh', 'doze', 'belly', 'stretch'] });

  // ---------- Spooky Squish ----------
  mk('gourdy', { dn: 'bounce', up: 'hop' }, { f: ['look', t => { t.osc(2400, 2, { tilt: 7, x: 1.6 }, { tilt: -7, x: -1.6 }, 's'); bk(t); }, 'swing', 'hum'], lf: ['sigh', 'doze', 'belly', t => sp(t, { tilt: -9, close: 1 }, 1600, 1200)] });
  mk('batty', hop, { f: ['look', t => { t.to(400, o(both(14, -2), { armL: 36, armR: 36, close: 0.5, smile: 0.8 })).wait(1400); bk(t, 500); }, t => { t.to(160, { hap: 0.7 }).osc(900, 6, { armL: 60, armR: 60 }, { armL: 10, armR: 10 }, 'o'); bk(t); }, 'swing'], lf: ['doze', 'sigh', 'belly'] });
  mk('kernel', { dn: 'climb', up: 'hop' }, { f: ['look', t => { t.osc(1400, 4, { x: 1, footL: 2, footR: 0 }, { x: -1, footL: 0, footR: 2 }, 's'); bk(t); }, 'kick', 'giggle'], lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('hexie', hop, { f: ['look', t => { t.to(300, o(hand(1, 4, -18), { armR: 120, htilt: 8 }), 'o').wait(300).fx('spark', 'head', 4).to(300, { winkR: 1, smile: 1 }).wait(400); bk(t); }, 'ears', 'swing'], lf: ['sigh', 'doze', t => sp(t, { curl: 0.7, close: 1 }, 1600, 1400), 'stretch'] });
  mk('mumbles', hop, { f: ['look', t => { t.to(600, { armL: 88, armR: 88, hLy: -2, hRy: -2, close: 0.6, open: 0.25 }, 'io').osc(1400, 2, { lean: 1.2 }, { lean: -1.2 }, 's'); bk(t, 600); }, 'swing', 'giggle'], lf: ['sigh', 'doze', 'belly', 'stretch'] });
  mk('hocus', hop, { f: ['look', t => { t.to(400, o(hand(1, 8, -4), { armR: 50, ly: 0.6, close: 0.3 })).fx('spark', 'body', 4).wait(800).fx('spark', 'body', 3); bk(t); }, 'nod', 'swing'], lf: ['doze', 'sigh', 'belly'] });
  mk('countsquishula', hop, { pose: { pitch: 0.12 }, f: ['look', t => { t.to(300, o(hand(-1, -6, -10), { armL: 90, lean: -1.2, htilt: -5 }), 'o').wait(500).to(300, { smile: 1, open: 0.2, winkL: 1 }).wait(500); bk(t); }, 'swing', 'pat'], lf: ['sigh', 'doze', 'belly', 'stretch'] });
});
