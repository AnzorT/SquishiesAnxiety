// Squad House v3: 3D furniture engine (lofted solids, 3/4 camera, CP-style outlines), catalog, room shells + door graph.
(function () {
  const A = 38 * Math.PI / 180, SA = Math.sin(A), CA = Math.cos(A);
  const LN = Math.hypot(0.5, 1, 0.55), LT = [-0.5 / LN, 1 / LN, 0.55 / LN];
  const VW = 852, FY0 = 128, FY1 = 356;
  const sAt = y => 0.6 + 0.24 * (y - FY0) / (FY1 - FY0);
  const edge = y => y < 262 ? 145 - (y - 100) * 145 / 162 : 0;
  const f1 = v => Math.round(v * 10) / 10;
  const hx = h => { h = h.replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); const n = parseInt(h, 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const th = c => '#' + c.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
  const shade = (h, k) => { const c = hx(h); return th(k <= 1 ? c.map(v => v * k) : c.map(v => v + (255 - v) * (k - 1))); };
  const mix = (a, b, t) => { const x = hx(a), y = hx(b); return th(x.map((v, i) => v + (y[i] - v) * t)); };
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const pathOf = P => 'M' + P.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L') + 'Z';
  const circ = (cx, cy, r) => 'M' + f1(cx - r) + ' ' + f1(cy) + 'a' + r + ' ' + r + ' 0 1 0 ' + 2 * r + ' 0a' + r + ' ' + r + ' 0 1 0 ' + -2 * r + ' 0Z';
  const ell = (cx, cy, rx, ry) => 'M' + f1(cx - rx) + ' ' + f1(cy) + 'a' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(2 * rx) + ' 0a' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(-2 * rx) + ' 0Z';
  function hull(pts) {
    const p = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]); if (p.length < 3) return p;
    const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    const lo = [], up = [];
    for (const q of p) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); }
    for (let i = p.length - 1; i >= 0; i--) { const q = p[i]; while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], q) <= 0) up.pop(); up.push(q); }
    up.pop(); lo.pop(); return lo.concat(up);
  }
  function ring(o, ins, sc) {
    if (o.sh === 'arc') { const N = o.n || 6, out = [], inn = []; for (let i = 0; i <= N; i++) { const t = o.a0 + (o.a1 - o.a0) * i / N; out.push([o.a * Math.cos(t), o.b * Math.sin(t)]); inn.push([(o.a - o.th) * Math.cos(t), (o.b - o.th) * Math.sin(t)]); } return out.concat(inn.reverse()); }
    const Aa = Math.max(0.05, (o.a - ins) * sc), Bb = Math.max(0.05, (o.b - ins) * sc);
    if (o.sh === 'el') { const N = o.n || 16, r = []; for (let i = 0; i < N; i++) { const t = i / N * 2 * Math.PI; r.push([Aa * Math.cos(t), Bb * Math.sin(t)]); } return r; }
    const rt = Math.max(0, Math.min(((o.r || 0) - ins) * sc, Aa, Bb)), rb = Math.max(0, Math.min(((o.rb ?? o.r ?? 0) - ins) * sc, Aa, Bb)), S = 5, r = [];
    [[Aa, Bb, 0, rt], [-Aa, Bb, 90, rt], [-Aa, -Bb, 180, rb], [Aa, -Bb, 270, rb]].forEach(([cx, cy, a0, R]) => { const ox = cx - Math.sign(cx) * R, oy = cy - Math.sign(cy) * R; for (let i = 0; i <= S; i++) { const t = (a0 + 90 * i / S) * Math.PI / 180; r.push([ox + R * Math.cos(t), oy + R * Math.sin(t)]); } });
    return r;
  }
  function newell(q) { const n = [0, 0, 0]; for (let i = 0; i < q.length; i++) { const a = q[i], b = q[(i + 1) % q.length]; n[0] += (a[1] - b[1]) * (a[2] + b[2]); n[1] += (a[2] - b[2]) * (a[0] + b[0]); n[2] += (a[0] - b[0]) * (a[1] + b[1]); } return n; }
  const area2 = p => { let s = 0; for (let i = 0; i < p.length; i++) { const j = (i + 1) % p.length; s += p[i][0] * p[j][1] - p[j][0] * p[i][1]; } return Math.abs(s); };
  function solid(o) {
    const ax = o.ax || 'y', cu = o.c[0], cv = o.c[1], yw = o.yaw || 0, cy = Math.cos(yw), sy = Math.sin(yw);
    const m3 = (u, v, t) => ax === 'y' ? [cu + u * cy - v * sy, t, cv + u * sy + v * cy] : ax === 'z' ? [cu + u, cv + v, t] : [t, cv + v, cu + u];
    const n3 = (u, v) => ax === 'y' ? [u * cy - v * sy, 0, u * sy + v * cy] : ax === 'z' ? [u, v, 0] : [0, v, u];
    const axis = ax === 'y' ? [0, 1, 0] : ax === 'z' ? [0, 0, 1] : [1, 0, 0];
    const R2 = o.rings.map(r => ring(o, r[1] || 0, r[2] ?? 1)), R3 = o.rings.map((r, k) => R2[k].map(([u, v]) => m3(u, v, r[0]))), faces = [];
    for (let k = 0; k < R3.length - 1; k++) {
      const a = R3[k], b = R3[k + 1], a2 = R2[k], b2 = R2[k + 1], N = a.length;
      for (let i = 0; i < N; i++) {
        const j = (i + 1) % N, q = [a[i], a[j], b[j], b[i]]; let nn = newell(q); const L = Math.hypot(nn[0], nn[1], nn[2]); if (L < 0.02) continue;
        nn = nn.map(v => v / L);
        let du = a2[j][0] - a2[i][0], dv = a2[j][1] - a2[i][1]; if (Math.abs(du) + Math.abs(dv) < 1e-6) { du = b2[j][0] - b2[i][0]; dv = b2[j][1] - b2[i][1]; }
        if (dot(nn, n3(dv, -du)) < 0) nn = nn.map(v => -v);
        faces.push({ q, n: nn });
      }
    }
    if (area2(R2[0]) > 0.5) faces.push({ q: R3[0], n: axis.map(v => -v), cap: 1 });
    const l = R2.length - 1; if (area2(R2[l]) > 0.5) faces.push({ q: R3[l], n: axis, cap: 2 });
    return { faces, pts: [].concat(...R3), col: o.col, soft: o.soft, shine: o.shine, org: o.org, emit: o.emit, cv: (o.sh === 'arc' || o.cv === 0) ? 0 : 1, zb: o.zb || 0, noOut: o.noOut, part: o.part };
  }
  const box = (x, y, z, w, h, d, col, o = {}) => solid(Object.assign({ ax: 'y', sh: 'rr', c: [x, z], a: w / 2, b: d / 2, r: 3, rings: o.bev ? [[y, 0], [y + h - o.bev, 0], [y + h, o.bev]] : [[y, 0], [y + h, 0]], col }, o));
  const cush = (x, y, z, w, h, d, col, o = {}) => { const e = Math.min(6, h * 0.45); return solid(Object.assign({ ax: 'y', sh: 'rr', c: [x, z], a: w / 2, b: d / 2, r: 10, rings: [[y, 2.5], [y + 2.5, 0], [y + h - e, 0], [y + h, e]], col, soft: 1 }, o)); };
  const cyl = (x, y, z, rx, h, col, o = {}) => solid(Object.assign({ ax: 'y', sh: 'el', c: [x, z], a: rx, b: o.rz ?? rx, n: 16, rings: o.rg ? o.rg.map(r => [y + r[0], r[1] || 0, r[2] ?? 1]) : [[y, 0], [y + h, o.top || 0]], col }, o));
  const ball = (x, y, z, r, col, o = {}) => { const sx = o.sx || 1, sy = o.sy || 1, sz = o.sz || 1, K = o.k || 5, rg = []; for (let i = 0; i <= K; i++) { const an = -Math.PI / 2 + Math.PI * i / K; rg.push([y + r * sy * (1 + Math.sin(an)), 0, Math.max(0.04, Math.cos(an))]); } return solid(Object.assign({ ax: 'y', sh: 'el', c: [x, z], a: r * sx, b: r * sz, n: 12, rings: rg, col, shine: 1 }, o)); };
  const slab = (x, y, z, w, h, d, col, o = {}) => solid(Object.assign({ ax: 'z', sh: 'rr', c: [x, y + h / 2], a: w / 2, b: h / 2, r: 8, rb: 0, rings: o.soft ? [[z - d / 2, 2], [z - d / 2 + 2, 0], [z + d / 2 - 2, 0], [z + d / 2, 2]] : [[z - d / 2, 0], [z + d / 2, 0]], col }, o));
  const slabX = (x, y, z, w, h, d, col, o = {}) => solid(Object.assign({ ax: 'x', sh: 'rr', c: [z, y + h / 2], a: d / 2, b: h / 2, r: 3, rings: [[x - w / 2, 0], [x + w / 2, 0]], col }, o));
  const arcW = (x, y, z, a, b, t, h, a0, a1, col, o = {}) => solid(Object.assign({ ax: 'y', sh: 'arc', c: [x, z], a, b, th: t, a0, a1, n: 5, rings: [[y, 0], [y + h, 0]], col }, o));
  const disc = (x, y, z, r, d, col, o = {}) => solid(Object.assign({ ax: 'z', sh: 'el', c: [x, y], a: r, b: r, n: 14, rings: [[z, 0], [z + d, o.top || 0]], col }, o));
  const pillowY = (x, y, z, w, hh, d, col, o = {}) => solid(Object.assign({ ax: 'y', sh: 'rr', c: [x, z], a: w / 2, b: d / 2, r: Math.min(w, d) * 0.3, rings: [[y, 4, 0.9], [y + 3, 0, 0.99], [y + hh - 5, 0, 1], [y + hh - 1.5, 4, 0.95], [y + hh, 9, 0.82]], col, soft: 1 }, o));
  const pillowZ = (x, y, z, w, hh, d, col, o = {}) => solid(Object.assign({ ax: 'z', sh: 'rr', c: [x, y + hh / 2], a: w / 2, b: hh / 2, r: Math.min(w, hh) * 0.4, rings: [[z - d / 2, 5, 0.86], [z - d / 2 + 3, 0, 0.97], [z + d / 2 - 3, 0, 1], [z + d / 2, 5, 0.88]], col, soft: 1 }, o));
  const legs4 = (x, z, h, col, r = 4, y = 0) => [cyl(-x, y, -z, r, h, col, { n: 8 }), cyl(x, y, -z, r, h, col, { n: 8 }), cyl(-x, y, z, r, h, col, { n: 8 }), cyl(x, y, z, r, h, col, { n: 8 })];
  const quarters = (fn) => [0, 1, 2, 3].map(q => fn(q * Math.PI / 2, (q + 1) * Math.PI / 2));

  const CR = '#fffaf1', WH = '#ffffff', MT = '#c9d3d8', GOLD = '#ffd66b', NEON = ['#4fe0d0', '#ffd66b', '#ff9d4a', '#a6f06a', '#6ac8ff', '#8f7bff'];
  const FAB = [{ a: '#84b6c9', b: '#e3946a' }, { a: '#e3946a', b: '#f2c255' }, { a: '#9fc684', b: '#fffaf1' }, { a: '#f2c255', b: '#84b6c9' }, { a: '#8f86c9', b: '#f2c255' }];
  const WOOD = [{ w: '#d49a60', a: '#84b6c9', b: '#e3946a' }, { w: '#a86b36', a: '#f2c255', b: '#9fc684' }, { w: '#f0d2a4', a: '#9fc684', b: '#84b6c9' }, { w: '#e3946a', a: '#fffaf1', b: '#f2c255' }];
  const pal = (D, ci) => { const c = (D.cols && D.cols[ci % D.cols.length]) || {}, a = mix(c.a || '#84b6c9', '#ffffff', 0.1), b = mix(c.b || '#f2c255', '#ffffff', 0.08), w = mix(c.w || '#d49a60', '#ffffff', 0.1); return { a, b, aL: mix(a, '#ffffff', 0.22), aD: shade(a, 0.86), bL: mix(b, '#ffffff', 0.2), bD: shade(b, 0.86), w, wD: shade(w, 0.76), wL: mix(w, '#ffffff', 0.25) }; };

  const CAT = {
    sofa: { n: 'Comfy Sofa', cat: 'seat', price: 300, w: 196, d: 90, cols: FAB, act: 'sit', seats: [{ x: -36, z: 12, h: 40 }, { x: 36, z: 12, h: 40 }],
      build: P => [...legs4(86, 34, 7, '#8a5a34', 4), box(0, 7, 2, 186, 18, 80, P.aD, { r: 16, bev: 4 }), slab(0, 14, -35, 182, 58, 14, P.a, { r: 24, soft: 1 }), pillowY(-36, 23, 8, 70, 16, 66, P.aL), pillowY(36, 23, 8, 70, 16, 66, P.aL), pillowZ(-36, 34, -22, 70, 40, 18, P.aL), pillowZ(36, 34, -22, 70, 40, 18, P.aL), slab(-84, 7, 2, 24, 44, 86, P.a, { r: 12, soft: 1 }), slab(84, 7, 2, 24, 44, 86, P.a, { r: 12, soft: 1 }), pillowZ(-50, 38, -8, 32, 30, 11, P.b)] },
    armchair: { n: 'Armchair', cat: 'seat', price: 180, w: 122, d: 90, cols: FAB, act: 'sit', seats: [{ x: 0, z: 12, h: 40 }],
      build: P => [...legs4(48, 34, 7, '#8a5a34', 4), box(0, 7, 2, 112, 18, 80, P.aD, { r: 16, bev: 4 }), slab(0, 14, -35, 108, 58, 14, P.a, { r: 24, soft: 1 }), pillowY(0, 23, 8, 70, 16, 66, P.aL), pillowZ(0, 34, -22, 70, 40, 18, P.aL), slab(-48, 7, 2, 24, 44, 86, P.a, { r: 12, soft: 1 }), slab(48, 7, 2, 24, 44, 86, P.a, { r: 12, soft: 1 })] },
    chair: { n: 'Wooden Chair', cat: 'seat', price: 90, w: 48, d: 48, cols: WOOD, act: 'sit', seats: [{ x: 0, z: 3, h: 40 }],
      build: P => [...legs4(18, 18, 26, P.wD, 3), box(0, 26, 0, 48, 6, 48, P.w, { r: 8, bev: 2 }), pillowY(0, 32, 2, 40, 8, 38, P.a), cyl(-19, 32, -21, 3, 40, P.wD, { n: 10 }), cyl(19, 32, -21, 3, 40, P.wD, { n: 10 }), slab(0, 46, -21, 38, 6, 4, P.w, { r: 3 }), slab(0, 62, -21, 48, 16, 6, P.w, { r: 8 })] },
    stool: { n: 'Round Stool', cat: 'seat', price: 60, w: 40, d: 40, cols: FAB, act: 'sit', round: 1, seats: [{ x: 0, z: 0, h: 39 }],
      build: P => [0, 1, 2].map(i => cyl(12 * Math.cos(i * 2.094 + 0.5), 0, 12 * Math.sin(i * 2.094 + 0.5), 2.6, 30, '#a86b36', { n: 8 })).concat([cyl(0, 30, 0, 19, 9, P.a, { rg: [[0, 0], [5, 0], [9, 4]], soft: 1 })]) },
    bench: { n: 'Garden Bench', cat: 'seat', price: 160, w: 144, d: 50, cols: WOOD, act: 'sit', seats: [{ x: -34, z: 2, h: 30 }, { x: 34, z: 2, h: 30 }],
      build: P => [...legs4(60, 16, 22, P.wD, 3.5), box(0, 22, 0, 144, 8, 46, P.w, { r: 6, bev: 2 }), cyl(-62, 30, -21, 3, 34, P.wD, { n: 10 }), cyl(62, 30, -21, 3, 34, P.wD, { n: 10 }), slab(0, 40, -21, 138, 10, 5, P.w, { r: 5 }), slab(0, 54, -21, 138, 10, 5, P.w, { r: 5 }), slab(-70, 22, -2, 6, 22, 40, P.wD, { r: 6 }), slab(70, 22, -2, 6, 22, 40, P.wD, { r: 6 })] },
    beanbag: { n: 'Beanbag', cat: 'seat', price: 150, w: 96, d: 86, cols: FAB, act: 'nap', round: 1, seats: [{ x: 0, z: 10, h: 38, k: 'nap' }],
      build: P => [ball(0, 0, -14, 32, P.a, { sx: 1.3, sy: 1.2, sz: 0.95, k: 8, n: 20 }), ball(0, 0, 10, 36, P.a, { sx: 1.28, sy: 0.6, sz: 0.92, k: 8, n: 20 }), cyl(2, 41.5, 12, 22, 0.5, shade(P.a, 0.94), { rz: 15, n: 20, noOut: 1, org: 1 })] },
    coffeeTable: { n: 'Coffee Table', cat: 'table', price: 140, w: 122, d: 66, cols: WOOD,
      build: P => [...legs4(50, 22, 28, P.wD, 3.5), box(0, 10, 0, 104, 4, 50, P.wD, { r: 6 }), box(0, 28, 0, 122, 8, 66, P.w, { r: 10, bev: 2 }), box(-26, 36, -4, 30, 5, 22, P.b, { r: 2 }), box(-24, 41, -5, 26, 4, 18, CR, { r: 2 }), cyl(28, 36, 6, 6, 11, CR, { n: 10 })] },
    roundTable: { n: 'Round Table', cat: 'table', price: 200, w: 112, d: 112, cols: WOOD, round: 1,
      build: P => [cyl(0, 0, 0, 28, 4, P.wD), cyl(0, 4, 0, 7, 44, P.wD, { n: 10 }), cyl(0, 48, 0, 56, 8, P.w, { rg: [[0, 2], [5, 0], [8, 2]], n: 20 }), cyl(0, 56, 0, 7, 14, P.b, { rg: [[0, 2], [9, 0], [14, 3]], n: 10 }), ball(-4, 68, 0, 6, '#f2c255'), ball(5, 69, 2, 5, '#e3946a')] },
    nightstand: { n: 'Nightstand', cat: 'table', price: 110, w: 48, d: 42, cols: WOOD, act: 'lights', glow: v => v === 'on' ? { y: 72, r: 70 } : null,
      build: (P, v) => [box(0, 0, 0, 48, 46, 42, P.w, { r: 5, bev: 2 }), box(0, 26, 21, 40, 15, 1.2, P.wL, { r: 3 }), box(0, 7, 21, 40, 15, 1.2, P.wL, { r: 3 }), ball(0, 31, 21.8, 2.2, GOLD, { k: 3, n: 8 }), ball(0, 12, 21.8, 2.2, GOLD, { k: 3, n: 8 }), cyl(-6, 46, -4, 8, 3, P.b), cyl(-6, 49, -4, 2, 16, P.wD, { n: 8 }), cyl(-6, 62, -4, 14, 16, v === 'on' ? '#fff1a8' : '#fff4cc', { rg: [[0, 0], [16, 5]], emit: v === 'on' })] },
    counter: { n: 'Kitchen Counter', cat: 'kitchen', price: 170, w: 124, d: 54, cols: [{ a: '#9fd3c0', b: '#84b6c9' }, { a: '#84b6c9', b: '#f2c255' }, { a: '#f2c255', b: '#e3946a' }, { a: '#e3946a', b: '#9fc684' }],
      build: P => [box(0, 0, 0, 120, 48, 50, P.a, { r: 4 }), box(0, 48, 0, 124, 6, 54, '#f4ead8', { r: 4, bev: 1.5 }), box(-30, 6, 25, 52, 36, 1.2, P.aL, { r: 4 }), box(30, 6, 25, 52, 36, 1.2, P.aL, { r: 4 }), ball(-6, 28, 26, 2.4, GOLD, { k: 3, n: 8 }), ball(6, 28, 26, 2.4, GOLD, { k: 3, n: 8 }), cyl(-28, 54, 0, 14, 7, CR, { rg: [[0, 6], [7, 0]] }), ball(-32, 59, 0, 5, '#ffb347'), ball(-24, 59, 3, 5, '#e85a3a'), cyl(30, 54, -8, 6, 14, CR, { n: 10 }), cyl(30, 68, -8, 6, 3, P.b, { n: 10 })] },
    fridge: { n: 'Fridge', cat: 'kitchen', price: 260, w: 70, d: 60, cols: [{ a: '#a6dcc4' }, { a: '#fffaf1' }, { a: '#84b6c9' }, { a: '#f2c255' }], act: 'snack', use: { x: 0, z: 62 },
      build: (P, v) => { const op = v === 'open', t = 100 * Math.PI / 180; return [...legs4(26, 22, 4, '#5b3b22', 3), box(0, 4, 0, 70, 136, 60, P.a, { r: 14, bev: 4 }), box(0, 93, 30.2, 66, 2, 0.8, P.aD, { r: 1 }), box(24, 104, 31, 5, 24, 3, '#fbf7ee', { r: 2 })].concat(op ? [box(0, 10, 30.6, 58, 78, 1, '#fff8e2', { r: 4, emit: 1 }), box(0, 36, 31.4, 56, 2, 1, '#e6d6b4'), box(0, 60, 31.4, 56, 2, 1, '#e6d6b4'), ball(-14, 12, 32, 6, '#e85a3a'), ball(10, 12, 32, 7, '#ffb347'), box(14, 38, 32, 14, 14, 2, CR, { r: 2 }), cyl(-14, 38, 32, 5, 14, '#84b6c9', { n: 8 }), box(-35 + 33 * Math.cos(t), 8, 30 + 33 * Math.sin(t), 66, 84, 6, P.a, { r: 10, yaw: t })] : [box(24, 44, 31, 5, 40, 3, '#fbf7ee', { r: 2 }), ball(-18, 68, 30, 4, GOLD, { sz: 0.4 }), box(-8, 50, 30.4, 14, 10, 1, CR, { r: 2 })]); } },
    stove: { n: 'Stove', cat: 'kitchen', price: 240, w: 82, d: 62, cols: [{ a: '#4fa8a0' }, { a: '#e3946a' }, { a: '#84b6c9' }], act: 'cook', use: { x: 0, z: 60 },
      build: (P, v) => { const on = v === 'on'; return [box(0, 0, 0, 80, 64, 60, '#f4ead8', { r: 8, bev: 2 }), box(0, 64, 0, 82, 4, 62, '#4a3a30', { r: 4 }), slab(0, 68, -27, 80, 22, 6, '#f4ead8', { r: 6 }), cyl(-20, 68, 6, 11, 1, '#2b211b'), cyl(20, 68, 6, 11, 1, '#2b211b')].concat(on ? [cyl(-20, 69, 6, 9.5, 0.5, '#ff8a3a', { emit: 1 }), cyl(20, 69, 6, 9.5, 0.5, '#ff8a3a', { emit: 1 })] : [], [cyl(-20, 69.5, 6, 13, 18, P.a), cyl(-20, 87.5, 6, 13, 3, P.aD, { top: 5 }), ball(-20, 90, 6, 2.6, P.aD, { k: 3, n: 8 }), cyl(20, 69.5, 6, 12, 4, '#3b3b3b'), box(37, 70, 6, 16, 3, 4, '#3b3b3b', { r: 1.5 }), box(0, 10, 30.5, 64, 40, 1.2, '#3b2e28', { r: 5 }), box(0, 16, 31.4, 48, 26, 0.8, on ? '#ffb347' : '#5a4a40', { r: 4, emit: on ? 1 : 0 }), box(0, 54, 30.5, 58, 3, 1.2, '#cbbca2', { r: 1.5 })]); } },
    bowl: { n: 'Food Bowl', cat: 'kitchen', price: 40, w: 40, d: 40, round: 1, noBlock: 1, cols: [{ a: '#e08a5e' }, { a: '#84b6c9' }, { a: '#9fc684' }], act: 'feed', use: { x: 42, z: 6 },
      build: P => [cyl(0, 0, 0, 18, 12, P.a, { rg: [[0, 6], [10, 0], [12, 0]] }), cyl(0, 12, 0, 15, 0.8, '#c98a52'), ball(-5, 12, -2, 2.8, '#a86b36', { k: 3, n: 8 }), ball(4, 12, 3, 2.8, '#e2ad74', { k: 3, n: 8 }), ball(1, 12, -5, 2.6, '#c98a52', { k: 3, n: 8 })] },
    bed: { n: 'Cozy Bed', cat: 'bed', price: 350, w: 140, d: 186, cols: [{ a: '#e3946a', b: '#fffaf1' }, { a: '#84b6c9', b: '#fffaf1' }, { a: '#9fc684', b: '#fffaf1' }, { a: '#f2c255', b: '#fffaf1' }], act: 'nap', seats: [{ x: -30, z: -30, h: 46, k: 'nap' }, { x: 30, z: -30, h: 46, k: 'nap' }],
      build: P => [...legs4(62, 84, 6, '#7a4a24', 4), box(0, 6, 4, 136, 18, 172, P.w, { r: 10, bev: 3 }), pillowY(0, 20, 6, 128, 14, 164, WH), box(0, 18, 30, 134, 26, 114, P.a, { r: 14, bev: 7, soft: 1 }), pillowY(0, 41, -25, 134, 6, 16, mix(P.a, '#ffffff', 0.55)), pillowY(-30, 33, -60, 50, 12, 28, WH), pillowY(30, 33, -60, 50, 12, 28, WH), slab(0, 6, -91, 136, 60, 10, P.w, { r: 30, soft: 1 }), slab(0, 26, -85.6, 106, 32, 1.4, P.wL, { r: 16 }), cyl(-70, 0, -90, 6, 72, P.wD, { n: 12 }), cyl(70, 0, -90, 6, 72, P.wD, { n: 12 }), ball(-70, 72, -90, 7, P.wD), ball(70, 72, -90, 7, P.wD), slab(0, 6, 90, 140, 30, 8, P.w, { r: 10, soft: 1 })] },
    crib: { n: 'Baby Crib', cat: 'bed', price: 280, w: 124, d: 84, cols: [{ w: '#ecc08a', a: '#bfe8cd' }, { w: '#fffaf1', a: '#cfe6f7' }, { w: '#d49a60', a: '#f6e3a2' }], act: 'nap', inside: [0, 26, 0], seats: [{ x: 0, z: 0, h: 26, k: 'nap' }],
      build: P => { const o = [box(0, 4, 0, 120, 12, 80, P.w, { r: 4 }), cush(0, 16, 0, 112, 10, 72, P.a, { r: 8 })]; [-57, 57].forEach(x => [-37, 37].forEach(z => o.push(cyl(x, 0, z, 4, 66, P.wD, { n: 8 })))); o.push(box(0, 58, 37, 114, 5, 5, P.w, { r: 2 }), box(0, 58, -37, 114, 5, 5, P.w, { r: 2 }), box(-57, 58, 0, 5, 5, 74, P.w, { r: 2 }), box(57, 58, 0, 5, 5, 74, P.w, { r: 2 })); for (let x = -45; x <= 45; x += 15) [-37, 37].forEach(z => o.push(cyl(x, 16, z, 1.8, 42, P.w, { n: 6 }))); for (let z = -24; z <= 24; z += 16) [-57, 57].forEach(x => o.push(cyl(x, 16, z, 1.8, 42, P.w, { n: 6 }))); return o; } },
    tub: { n: 'Clawfoot Tub', cat: 'bath', price: 320, w: 172, d: 90, cols: [{ a: '#ffffff', b: '#ffd66b' }, { a: '#cfe6f7', b: '#ffd66b' }, { a: '#f4e6cc', b: '#c9d3d8' }], act: 'bath', inside: [0, 14, 0], seats: [{ x: -36, z: 0, h: 14, k: 'bath' }, { x: 36, z: 0, h: 14, k: 'bath' }],
      build: P => [ball(-64, 0, -26, 5, P.b), ball(64, 0, -26, 5, P.b), ball(-64, 0, 26, 5, P.b), ball(64, 0, 26, 5, P.b), cyl(0, 6, 0, 82, 6, P.a, { rz: 40, n: 20 }), cyl(0, 6, 0, 77, 26, '#a9def0', { rz: 35, n: 20, emit: 1 })].concat(quarters((a0, a1) => arcW(0, 6, 0, 85, 44, 8, 38, a0, a1, P.a)), [cyl(-72, 44, 0, 3, 14, MT, { n: 8 }), box(-66, 55, 0, 12, 3, 4, MT, { r: 1.5 })], [[-40, 10, 7], [-28, -14, 6], [30, 12, 8], [46, -8, 6], [0, 18, 6], [-10, -20, 5], [58, 12, 5], [-56, -4, 5]].map(([x, z, r]) => ball(x, 29, z, r, WH))) },
    sink: { n: 'Sink', cat: 'bath', price: 150, w: 60, d: 50, round: 1, cols: [{ a: '#ffffff' }, { a: '#cfe6f7' }, { a: '#f4e6cc' }], act: 'wash', use: { x: 0, z: 44 },
      build: P => [cyl(0, 0, 0, 10, 46, P.a, { rg: [[0, 0, 1.3], [46, 0, 1]], n: 12 }), cyl(0, 44, 0, 30, 14, P.a, { rz: 24, rg: [[0, 0, 0.55], [10, 0, 1], [14, 0, 1]] }), cyl(0, 58, 0, 24, 0.6, '#cfe6ee', { rz: 18 }), cyl(0, 58, -17, 3, 12, MT, { n: 8 }), box(0, 68, -12, 4, 3, 10, MT, { r: 1.5 }), cyl(18, 58, -14, 4, 8, '#f2c255', { n: 8 })] },
    horse: { n: 'Rocking Horse', cat: 'fun', price: 220, w: 124, d: 40, cols: [{ a: '#f2c255', b: '#c4651f' }, { a: '#fffaf1', b: '#84b6c9' }, { a: '#c98d58', b: '#3b2316' }, { a: '#9fd3c0', b: '#e3946a' }], act: 'ride', anim: 'rock', pivot: [0, 0, 0], seats: [{ x: 0, z: 0, h: 64, k: 'ride', f: 90 }],
      build: P => [slabX(0, 0, -12, 124, 6, 7, '#a86b36', { r: 3, part: 1 }), slabX(0, 0, 12, 124, 6, 7, '#a86b36', { r: 3, part: 1 }), ...[[-22, -9], [-22, 9], [22, -9], [22, 9]].map(([x, z]) => cyl(x, 6, z, 3.5, 28, P.aD, { n: 8, part: 1 })), ball(0, 30, 0, 20, P.a, { sx: 1.7, sy: 0.8, sz: 0.85, part: 1 }), ball(-36, 40, 0, 7, P.b, { sy: 1.6, part: 1 }), ball(28, 46, 0, 10, P.a, { sy: 1.3, sz: 0.8, part: 1 }), ball(40, 64, 0, 11, P.a, { sx: 1.15, sz: 0.85, part: 1 }), ball(51, 64, 0, 7, P.aL, { sz: 0.8, part: 1 }), cyl(36, 82, -5, 3, 9, P.a, { top: 2.6, n: 8, part: 1 }), cyl(36, 82, 5, 3, 9, P.a, { top: 2.6, n: 8, part: 1 }), ball(45, 73, -8.4, 1.8, '#3b2316', { k: 3, n: 8, part: 1 }), ball(45, 73, 8.4, 1.8, '#3b2316', { k: 3, n: 8, part: 1 }), ball(24, 62, 0, 5, P.b, { part: 1 }), ball(30, 70, 0, 5, P.b, { part: 1 }), ball(35, 78, 0, 5, P.b, { part: 1 }), box(0, 60, 0, 26, 4, 30, P.b, { r: 8, part: 1 })] },
    blocks: { n: 'ABC Blocks', cat: 'fun', price: 70, w: 70, d: 50, act: 'play', use: { x: 52, z: 14 },
      build: () => [box(-18, 0, 0, 30, 30, 30, '#7cc4e8', { r: 4, bev: 2 }), box(16, 0, 6, 30, 30, 30, '#8fd3a8', { r: 4, bev: 2, yaw: 0.3 }), box(-2, 30, 2, 30, 30, 30, '#f6d466', { r: 4, bev: 2, yaw: -0.25 })] },
    toyChest: { n: 'Toy Chest', cat: 'fun', price: 130, w: 94, d: 58, cols: WOOD,
      build: P => [box(0, 0, 0, 90, 44, 54, P.w, { r: 6, bev: 2 }), box(0, 44, 0, 94, 10, 58, P.a, { r: 8, bev: 3 }), ball(-18, 50, -8, 11, '#c98d58'), ball(-26, 68, -8, 4, '#c98d58'), ball(-10, 68, -8, 4, '#c98d58'), ball(22, 54, 0, 8, '#e3946a'), box(0, 18, 27.2, 26, 10, 1, P.b, { r: 3 })] },
    stage: { n: 'Dance Stage', cat: 'fun', price: 400, w: 220, d: 90, cols: [{ a: '#353a86' }, { a: '#a86b36' }], act: 'perform', seats: [{ x: -50, z: 0, h: 24, k: 'perform' }, { x: 50, z: 0, h: 24, k: 'perform' }],
      build: P => [box(0, 0, 0, 220, 24, 90, P.a, { r: 12, bev: 3 }), box(0, 0, 52, 70, 10, 16, P.aD, { r: 4 })].concat([0, 1, 2, 3, 4, 5, 6, 7, 8].map(i => ball(-96 + 24 * i, 8, 45.4, 3.5, NEON[i % 6], { emit: 1, k: 3, n: 8 }))) },
    jukebox: { n: 'Jukebox', cat: 'fun', price: 300, w: 64, d: 44, act: 'party', glow: v => v === 'on' ? { y: 70, r: 95, c: 'url(#gNeon)' } : null,
      build: (P, v) => [box(0, 0, 0, 64, 70, 44, '#a86b36', { r: 8, bev: 2 }), box(0, 6, 22, 52, 58, 1.5, '#ffa940', { r: 6 }), slab(0, 70, 0, 64, 36, 44, '#ffa940', { r: 32, soft: 1 }), slab(0, 74, 22.6, 46, 26, 1.5, v === 'on' ? '#fff1a8' : '#ffe2a6', { r: 23, emit: 1 }), box(0, 10, 23.4, 40, 18, 0.8, '#8a4410', { r: 3 }), disc(0, 46, 22.8, 8, 1.2, '#3b2e28'), disc(0, 46, 24, 2.5, 0.8, GOLD)] },
    speaker: { n: 'Speaker', cat: 'fun', price: 120, w: 54, d: 40, cols: [{ a: '#262a63' }, { a: '#3b3646' }],
      build: P => [box(0, 0, 0, 54, 96, 40, P.a, { r: 6, bev: 2 }), disc(0, 66, 20, 15, 2, '#5a5f96', { top: 3 }), disc(0, 66, 22, 6, 1, '#4fe0d0', { emit: 1 }), disc(0, 28, 20, 19, 2, '#5a5f96', { top: 3 }), disc(0, 28, 22, 7, 1, '#4fe0d0', { emit: 1 })] },
    swing: { n: 'Swing Set', cat: 'fun', price: 260, w: 184, d: 56, cols: FAB, act: 'swing', anim: 'swing', pivot: [0, 146, 0], seats: [{ x: 0, z: 0, h: 42, k: 'swing' }],
      build: P => [cyl(-80, 0, -20, 4, 148, '#a86b36', { n: 8 }), cyl(80, 0, -20, 4, 148, '#a86b36', { n: 8 }), cyl(-80, 0, 20, 4, 148, '#a86b36', { n: 8 }), cyl(80, 0, 20, 4, 148, '#a86b36', { n: 8 }), slabX(0, 146, -20, 172, 6, 6, '#a86b36', { r: 2 }), slabX(0, 146, 20, 172, 6, 6, '#a86b36', { r: 2 }), slabX(0, 148, 0, 184, 9, 46, '#c98d58', { r: 4 }), cyl(-18, 40, 0, 1.4, 106, '#8a6a3e', { n: 6, part: 1 }), cyl(18, 40, 0, 1.4, 106, '#8a6a3e', { n: 6, part: 1 }), box(0, 36, 0, 50, 6, 24, P.a, { r: 4, part: 1 })] },
    pool: { n: 'Kiddie Pool', cat: 'fun', price: 210, w: 150, d: 110, round: 1, cols: [{ a: '#5cc8f0' }, { a: '#9fc684' }, { a: '#f2c255' }], act: 'splash', inside: [0, 4, 0], seats: [{ x: -26, z: 0, h: 4, k: 'splash' }, { x: 26, z: 0, h: 4, k: 'splash' }],
      build: P => [cyl(0, 0, 0, 62, 13, '#8fdcf5', { rz: 42, n: 20, emit: 1 })].concat(quarters((a0, a1) => arcW(0, 0, 0, 75, 55, 16, 20, a0, a1, P.a, { n: 6 })), quarters((a0, a1) => arcW(0, 20, 0, 73, 53, 12, 4, a0, a1, CR, { n: 6 }))) },
    sandbox: { n: 'Sandbox', cat: 'fun', price: 180, w: 132, d: 100, cols: WOOD, act: 'dig', inside: [0, 10, 0], use: { x: 0, z: 0, inside: 1 },
      build: P => [box(0, 0, 0, 116, 12, 84, '#f3dca0', { r: 4 }), ball(-24, 12, -12, 18, '#e8cb85', { sy: 0.35 }), box(0, 0, -46, 132, 16, 8, P.w, { r: 2 }), box(0, 0, 46, 132, 16, 8, P.w, { r: 2 }), box(-62, 0, 0, 8, 16, 84, P.w, { r: 2 }), box(62, 0, 0, 8, 16, 84, P.w, { r: 2 }), cyl(34, 12, 10, 8, 12, '#7cc4e8', { rg: [[0, 0, 0.75], [12, 0, 1]], n: 10 }), box(16, 12, 22, 4, 2, 20, '#e3946a', { yaw: 0.6 })] },
    tree: { n: 'Orange Tree', cat: 'decor', price: 190, w: 40, d: 40, round: 1, cols: [{ a: '#8fc176' }, { a: '#7ab45c' }, { a: '#b5c95a' }],
      build: P => [cyl(0, 0, 0, 12, 112, '#a86b36', { rg: [[0, 4], [10, 0], [112, 3]], n: 10 }), ball(0, 104, 0, 46, P.a), ball(-40, 96, 10, 32, P.a), ball(40, 100, 6, 34, P.a), ball(-14, 150, -6, 30, P.aL), ball(18, 146, 10, 28, P.aL), ball(-22, 128, 40, 5, '#ffb347'), ball(26, 118, 38, 5, '#ffb347'), ball(6, 152, 32, 5, '#ffb347')] },
    bush: { n: 'Flower Bush', cat: 'decor', price: 70, w: 80, d: 60, round: 1, cols: [{ a: '#7ab45c' }, { a: '#8fc176' }],
      build: P => [ball(-22, 0, 8, 18, P.aD), ball(22, 0, 6, 18, P.aD), ball(0, 0, 0, 26, P.a, { sy: 0.9 }), ball(-8, 40, 18, 3.5, CR, { k: 3, n: 8 }), ball(10, 36, 19, 3.5, '#f2c255', { k: 3, n: 8 }), ball(-22, 26, 22, 3, CR, { k: 3, n: 8 }), ball(24, 24, 20, 3, '#f2c255', { k: 3, n: 8 })] },
    rugRound: { n: 'Round Rug', cat: 'decor', price: 100, w: 180, d: 124, round: 1, flat: 1, noBlock: 1, cols: [{ a: '#a9c497', b: '#e3946a' }, { a: '#8fa7c9', b: '#f2c255' }, { a: '#e3946a', b: '#fffaf1' }, { a: '#f2c255', b: '#84b6c9' }],
      build: P => [cyl(0, 0, 0, 90, 2, P.a, { rz: 62, n: 24 }), cyl(0, 2, 0, 72, 0.6, CR, { rz: 49, n: 24 }), cyl(0, 2.6, 0, 48, 0.6, P.b, { rz: 32, n: 20 }), cyl(0, 3.2, 0, 26, 0.6, CR, { rz: 17, n: 16 })] },
    rugRect: { n: 'Striped Rug', cat: 'decor', price: 100, w: 200, d: 130, flat: 1, noBlock: 1, cols: [{ a: '#84b6c9', b: '#fffaf1' }, { a: '#e3946a', b: '#f2c255' }, { a: '#9fc684', b: '#fffaf1' }],
      build: P => [box(0, 0, 0, 200, 2, 130, P.a, { r: 12 }), box(0, 2, -38, 186, 0.6, 16, P.b, { r: 2 }), box(0, 2, 0, 186, 0.6, 16, CR, { r: 2 }), box(0, 2, 38, 186, 0.6, 16, P.b, { r: 2 })] },
    puzzleMat: { n: 'Puzzle Mat', cat: 'decor', price: 90, w: 180, d: 136, flat: 1, noBlock: 1,
      build: () => { const C = ['#7cc4e8', '#8fd3a8', '#f6d466', '#f3a35a'], o = []; for (let i = 0; i < 4; i++) for (let j = 0; j < 3; j++) o.push(box(-66 + 44 * i, 0, -44 + 44 * j, 43, 3, 43, C[(i + j) % 4], { r: 3 })); return o; } },
    lamp: { n: 'Floor Lamp', cat: 'decor', price: 120, w: 44, d: 44, round: 1, cols: [{ a: '#fff4cc' }, { a: '#9fd3c0' }, { a: '#f2c255' }], glow: () => ({ y: 116, r: 80 }),
      build: P => [cyl(0, 0, 0, 16, 4, '#a86b36'), cyl(0, 4, 0, 2.5, 108, '#a86b36', { n: 8 }), cyl(0, 104, 0, 24, 36, P.a, { rg: [[0, 0], [36, 9]] })] },
    plant: { n: 'Potted Plant', cat: 'decor', price: 80, w: 50, d: 50, round: 1, cols: [{ a: '#e08a5e' }, { a: '#84b6c9' }, { a: '#fffaf1' }, { a: '#f2c255' }],
      build: P => [cyl(0, 0, 0, 18, 28, P.a, { rg: [[0, 4], [28, 0]] }), cyl(0, 26, 0, 21, 6, P.aL), cyl(0, 32, 0, 18, 0.6, '#6a4020'), ball(-17, 36, 6, 14, '#6fa85c'), ball(17, 38, 4, 14, '#6fa85c'), ball(0, 40, 0, 20, '#8fc176'), ball(-5, 62, -5, 13, '#a8d48a'), ball(9, 58, 8, 12, '#a8d48a')] },
    bookshelf: { n: 'Bookshelf', cat: 'decor', price: 220, w: 102, d: 36, cols: WOOD,
      build: P => { const o = [box(0, 0, -14, 86, 130, 6, P.wD, { r: 1 }), box(-46, 0, 0, 8, 130, 34, P.w, { r: 2 }), box(46, 0, 0, 8, 130, 34, P.w, { r: 2 }), box(0, 126, 0, 102, 6, 36, P.w, { r: 3, bev: 1.5 })], C = ['#e3946a', '#84b6c9', '#f2c255', '#9fc684', '#8f86c9', '#fffaf1']; [0, 42, 84].forEach((y, s) => { o.push(box(0, y, 1, 86, 4, 30, P.w, { r: 1 })); let x = -38, i = 0; while (true) { const w = 7 + ((i * 5 + s * 3) % 4), h = 24 + ((i * 7 + s) % 4) * 3; if (x + w > (s === 1 ? 14 : 38)) break; o.push(box(x + w / 2, y + 4, -1, w, h, 22, C[(i + s * 2) % 6], { r: 1 })); x += w + 1; i++; } if (s === 1) o.push(ball(28, y + 4, 0, 8, '#9fc684')); }); return o; } },
    tv: { n: 'TV Stand', cat: 'decor', price: 260, w: 110, d: 44, cols: WOOD,
      build: P => [box(0, 0, 0, 110, 32, 40, P.w, { r: 6, bev: 2 }), box(-27, 4, 20.4, 50, 24, 1, P.wL, { r: 3 }), box(27, 4, 20.4, 50, 24, 1, P.wL, { r: 3 }), box(0, 32, -6, 98, 58, 8, '#2f2f3a', { r: 6 }), box(0, 36, -1.8, 88, 50, 0.6, '#6cc6ee', { r: 3, emit: 1 }), box(18, 38, -1.1, 46, 12, 0.4, '#9fc684', { r: 6, emit: 1 }), box(-20, 62, -1.1, 26, 10, 0.4, '#e9f7fd', { r: 5, emit: 1 })] },
    wardrobe: { n: 'Wardrobe', cat: 'decor', price: 240, w: 106, d: 54, cols: WOOD,
      build: P => [...legs4(42, 18, 4, P.wD, 3), box(0, 4, 0, 100, 152, 50, P.w, { r: 6, bev: 3 }), box(0, 156, 0, 106, 8, 54, P.wD, { r: 4 }), box(-25, 12, 25.3, 46, 136, 1.2, P.wL, { r: 4 }), box(25, 12, 25.3, 46, 136, 1.2, P.wL, { r: 4 }), ball(-5, 78, 26, 2.6, GOLD, { k: 3, n: 8 }), ball(5, 78, 26, 2.6, GOLD, { k: 3, n: 8 })] },
  };
  const CATS = [['all', 'All'], ['seat', 'Seating'], ['table', 'Tables'], ['bed', 'Beds'], ['kitchen', 'Kitchen'], ['bath', 'Bath'], ['fun', 'Play'], ['decor', 'Decor']];

  const FS = 1.16, GR = new Map();
  function gref(t, col, set) { const id = 'h' + t + col.replace('#', ''); if (!GR.has(id)) GR.set(id, t === 'S' ? { id, t, c0: shade(col, 1.06), c1: shade(col, 0.76) } : t === 'T' ? { id, t, c0: shade(col, 1.2), c1: shade(col, 1.03) } : { id, t, c0: shade(col, 1.26), c1: shade(col, 0.74) }); set.add(id); return 'url(#' + id + ')'; }
  const grads = ids => { const lin = [], rad = []; ids.forEach(id => { const g = GR.get(id); if (!g) return; (g.t === 'R' ? rad : lin).push(g.t === 'T' ? Object.assign({ x2: '1', y2: '0.7' }, g) : Object.assign({ x2: '0.85', y2: '1' }, g)); }); return { lin, rad }; };
  const CACHE = new Map();
  function render(t, rot, ci, v) {
    const key = t + '|' + rot + '|' + ci + '|' + (v || ''); const hit = CACHE.get(key); if (hit) return hit;
    const D = CAT[t]; if (!D) return null;
    const sol = D.build(pal(D, ci || 0), v || ''), tr = rot * Math.PI / 180, c = Math.cos(tr), s = Math.sin(tr);
    const Rn = p => [p[0] * c + p[2] * s, p[1], -p[0] * s + p[2] * c], R = p => [(p[0] * c + p[2] * s) * FS, p[1] * FS, (-p[0] * s + p[2] * c) * FS], pr = p => [p[0], p[2] * SA - p[1] * CA], gs = new Set();
    const hi = (P, L, o) => { let a = 1e9, b = 1e9, cc = -1e9, d = -1e9; P.forEach(q => { a = Math.min(a, q[0]); cc = Math.max(cc, q[0]); b = Math.min(b, q[1]); d = Math.max(d, q[1]); }); const w = cc - a, hh = d - b; if (w < 8 || area2(P) / 2 < w * hh * 0.5) return; L.push({ d: ell(a + w * 0.36, b + hh * 0.32, w * 0.24, hh * 0.18), f: 'url(#hiW)', s: 'none', w: 0, o }); };
    let sd = null; if (D.inside) { const q = R(D.inside); sd = q[1] * SA + q[2] * CA; }
    const list = sol.map(S => { const pts = S.pts.map(R); let C0 = 0, C1 = 0, C2 = 0; pts.forEach(p => { C0 += p[0]; C1 += p[1]; C2 += p[2]; }); const n = pts.length; return { S, pts, dep: (C1 / n) * SA + (C2 / n) * CA + S.zb }; });
    list.sort((a, b) => a.dep - b.dep);
    const out = { back: [], part: [], front: [] }; let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    const grow = P => P.forEach(p => { if (p[0] < x0) x0 = p[0]; if (p[0] > x1) x1 = p[0]; if (p[1] < y0) y0 = p[1]; if (p[1] > y1) y1 = p[1]; });
    list.forEach(({ S, pts, dep }) => {
      const vis = [];
      S.faces.forEach(F => { const n = Rn(F.n), dv = n[1] * SA + n[2] * CA; if (dv <= 0.02) return; vis.push({ P2: F.q.map(p => pr(R(p))), n, cap: F.cap, k: S.emit ? 1 : 0.62 + 0.42 * Math.max(0, dot(n, LT)) + 0.05 * dv }); });
      if (!vis.length) return;
      const L = S.part ? out.part : (sd != null && dep > sd + 4 ? out.front : out.back), oc = S.noOut ? 'none' : shade(S.col, 0.66), ow = S.noOut ? 0 : 1.7;
      if (S.cv) {
        const H = hull(pts.map(pr)); grow(H);
        if (S.emit) L.push({ d: pathOf(H), f: shade(S.col, 1.04), s: oc, w: ow, o: 1 });
        else if (S.shine || S.org) { L.push({ d: pathOf(H), f: gref('R', S.col, gs), s: oc, w: ow, o: 1 }); if (!S.noOut) hi(H, L, 0.9); }
        else {
          L.push({ d: pathOf(H), f: gref('S', S.col, gs), s: oc, w: ow, o: 1 });
          const tp = []; vis.forEach(F => { if (F.n[1] > 0.42) F.P2.forEach(p => tp.push(p)); });
          if (tp.length >= 3) { const T = hull(tp); L.push({ d: pathOf(T), f: gref('T', S.col, gs), s: 'none', w: 0, o: 1 }); if (S.soft) hi(T, L, 0.75); }
          else if (S.soft) hi(H, L, 0.6);
        }
      } else {
        vis.forEach(F => { grow(F.P2); const fc = shade(S.col, F.k); L.push({ d: pathOf(F.P2), f: fc, s: fc, w: 0.8, o: 1 }); });
      }
    });
    const fpR = (k) => ring({ sh: D.round ? 'el' : 'rr', a: D.w / 2 * k, b: D.d / 2 * k, r: Math.min(D.w, D.d) * 0.22, n: 20 }, 0, 1).map(([u, v]) => pr(R([u, 0, v])));
    const shP = hull(fpR(1.04)), ftP = hull(fpR(1.14)); grow(ftP);
    let glow = null; const G = D.glow && D.glow(v || ''); if (G) { const q = pr(R([0, G.y, 0])); glow = { d: circ(q[0], q[1], G.r), f: G.c || 'url(#gWarm)' }; grow([[q[0] - G.r, q[1] - G.r], [q[0] + G.r, q[1] + G.r]]); }
    const pv = D.pivot ? pr(R(D.pivot)) : [0, 0];
    x0 -= 6; y0 -= 6; x1 += 6; y1 += 6;
    const res = { gids: [...gs], back: out.back, part: out.part, front: out.front, glow, shadow: pathOf(shP), foot: pathOf(ftP), pv, bb: { x: f1(x0), y: f1(y0), w: f1(x1 - x0), h: f1(y1 - y0) }, vb: f1(x0) + ' ' + f1(y0) + ' ' + f1(x1 - x0) + ' ' + f1(y1 - y0) };
    CACHE.set(key, res); return res;
  }
  const seatXY = (D, rot, k) => { const s = D.seats[k], tr = rot * Math.PI / 180, c = Math.cos(tr), sn = Math.sin(tr); return { x: (s.x * c + s.z * sn) * FS, z: (-s.x * sn + s.z * c) * FS, h: s.h * FS, f: s.f || 0, k: s.k || D.act }; };
  const useXY = (D, rot) => { const u = D.use, tr = rot * Math.PI / 180, c = Math.cos(tr), sn = Math.sin(tr); return { x: (u.x * c + u.z * sn) * FS, z: (-u.x * sn + u.z * c) * FS, inside: u.inside }; };
  const half = (D, rot) => { const tr = rot * Math.PI / 180, c = Math.abs(Math.cos(tr)), s = Math.abs(Math.sin(tr)); return { hx: (D.w / 2 * c + D.d / 2 * s) * FS, hz: (D.w / 2 * s + D.d / 2 * c) * FS }; };

  // ---------- room shells ----------
  const PAL = {
    living: { b0: '#f3e3cb', b1: '#faf0e1', l0: '#f7ead6', l1: '#eedcc2', r0: '#dcc3a2', r1: '#e7d2b4', w0: '#bcd0a8', w1: '#a6bf92', wr0: '#a5bb91', wr1: '#93ab80', trim: '#fffaf1', pat: '#ead6b8', f0: '#c98d52', f1: '#e0a96e', f2: '#f0c590', fl: '#a86b36', fd: '#b87a40', fli: '#fff2d8', door: '#9ab886', doorL: '#c4d8b2', edge: '#5a3418' },
    kitchen: { b0: '#f8e7b0', b1: '#fcf2d4', l0: '#fbeec6', l1: '#f3e0a8', r0: '#e8cf8e', r1: '#f0dba3', w0: '#bfe3d4', w1: '#a3d3c0', wr0: '#9fcdb9', wr1: '#8bbfa9', trim: '#fffaf1', pat: '#efd27e', f0: '#eadbbd', f1: '#f3e8d2', f2: '#faf2e2', fl: '#d9c39c', fd: '#e7a37c', fli: '#ffffff', door: '#d49a60', doorL: '#e6b884', edge: '#8a5a2e' },
    bathroom: { b0: '#d7ecf3', b1: '#e8f5f9', l0: '#e2f2f7', l1: '#d2e8f0', r0: '#bcd8e3', r1: '#cbe2eb', w0: '#ffffff', w1: '#eef6f8', wr0: '#e6f0f3', wr1: '#d9e8ec', trim: '#ffffff', pat: '#c6e1ea', f0: '#bcdce8', f1: '#d4ebf2', f2: '#e7f5f9', fl: '#ffffff', fd: '#a9d2e2', fli: '#ffffff', door: '#ffffff', doorL: '#d6e8ef', edge: '#4a7a8c' },
    bedroom: { b0: '#c4d3e9', b1: '#d8e3f2', l0: '#d3def0', l1: '#c3d1e7', r0: '#a9bcd9', r1: '#b9cae3', w0: '#8fa7c9', w1: '#7f98bd', wr0: '#7b93b8', wr1: '#6c84aa', trim: '#fffaf1', pat: '#f4f0dc', f0: '#a86b3e', f1: '#c08250', f2: '#d39660', fl: '#7a4a24', fd: '#8a5530', fli: '#e8b884', door: '#d49a60', doorL: '#e6b884', edge: '#3a2414' },
    nursery: { b0: '#d3eedf', b1: '#e6f6ec', l0: '#e0f3e8', l1: '#cfe9da', r0: '#b5dcc6', r1: '#c6e4d3', w0: '#f6e3a2', w1: '#efd58a', wr0: '#ebcf82', wr1: '#e0c070', trim: '#fffaf1', pat: '#c2e5d0', f0: '#e4d2b0', f1: '#eee0c6', f2: '#f6eedd', fl: '#cdb58c', fd: '#dcc7a0', fli: '#ffffff', door: '#9ab886', doorL: '#c4d8b2', edge: '#8a6a3e' },
    dance: { b0: '#262a63', b1: '#353a86', l0: '#2e3274', l1: '#262a63', r0: '#1e2152', r1: '#262a63', w0: '#1b1d4a', w1: '#15173d', wr0: '#15173d', wr1: '#101231', trim: '#4fe0d0', pat: '#2e3274', f0: '#1c1f4d', f1: '#22265a', f2: '#292e68', fl: '#3d4596', fd: '#2a2e66', fli: '#2a2e66', door: '#1e2152', doorL: '#3a3f86', edge: '#000000' },
    backyard: { b0: '#f6e7c4', b1: '#fbf1da', l0: '#9fd2f2', l1: '#d4ecf8', r0: '#9fd2f2', r1: '#d4ecf8', w0: '#e9d6ac', w1: '#dcc594', wr0: '#e9d6ac', wr1: '#dcc594', trim: '#fffaf1', pat: '#e3cfa2', f0: '#7fbd5e', f1: '#93cf70', f2: '#a5dc84', fl: '#6fae50', fd: '#86c466', fli: '#b2e494', door: '#84b6c9', doorL: '#b4d6e2', edge: '#2a4a1a' },
  };
  const ROOMS = {
    living: { name: 'Living Room', wall: 'stripe', floor: 'wood', doors: [{ s: 'L', to: 'kitchen' }, { s: 'R', to: 'bathroom' }, { s: 'B', x: 620, to: 'nursery', k: 'up' }], deco: [['window', 270], ['frame', 420, '#9fc684', '#ffd66b'], ['clock', 506]],
      items: [['rugRound', 426, 238, 0, 0], ['sofa', 426, 168, 0, 0], ['coffeeTable', 426, 236, 0, 0], ['armchair', 262, 214, 45, 0], ['beanbag', 652, 246, -20, 3], ['lamp', 330, 150, 0, 0], ['plant', 536, 150, 0, 0], ['bookshelf', 196, 150, 0, 0], ['bowl', 176, 300, 0, 0]], toys: [['ball', 700, 306]] },
    kitchen: { name: 'Kitchen', wall: 'dots', floor: 'checker', doors: [{ s: 'R', to: 'living' }, { s: 'B', x: 430, to: 'backyard', k: 'glass' }, { s: 'B', x: 612, to: 'bedroom', k: 'up' }], deco: [['window', 262], ['shelf', 520]],
      items: [['fridge', 176, 150, 0, 0], ['counter', 284, 150, 0, 0], ['stove', 520, 152, 0, 0], ['roundTable', 440, 256, 0, 0], ['chair', 362, 256, 90, 0], ['chair', 518, 256, -90, 0], ['plant', 724, 244, 0, 3]] },
    bathroom: { name: 'Bathroom', wall: 'tile', floor: 'tile', doors: [{ s: 'L', to: 'living' }, { s: 'B', x: 612, to: 'backyard', k: 'door' }], deco: [['window', 300, 'frost'], ['mirror', 470]],
      items: [['rugRect', 430, 270, 0, 0], ['tub', 300, 174, 0, 0], ['sink', 470, 152, 0, 0], ['plant', 704, 244, 0, 2]], toys: [['duck', 560, 302]] },
    bedroom: { name: 'Bedroom', wall: 'stars', floor: 'wood', doors: [{ s: 'R', to: 'nursery' }, { s: 'B', x: 620, to: 'kitchen', k: 'down' }], deco: [['window', 330], ['frame', 474, '#8fa7c9', '#fff1a8']],
      items: [['rugRound', 520, 264, 0, 1], ['bed', 330, 196, 0, 1], ['nightstand', 432, 150, 0, 0], ['wardrobe', 192, 154, 0, 0], ['toyChest', 612, 286, 0, 2]] },
    nursery: { name: 'Nursery', wall: 'nstripe', floor: 'wood', doors: [{ s: 'L', to: 'bedroom' }, { s: 'R', to: 'dance' }, { s: 'B', x: 426, to: 'living', k: 'down' }], deco: [['bunting'], ['rainbow', 250], ['window', 600]],
      items: [['puzzleMat', 430, 262, 0, 0], ['crib', 296, 172, 0, 0], ['horse', 624, 262, 0, 0], ['blocks', 226, 292, 0, 0], ['toyChest', 560, 160, 0, 2]] },
    dance: { name: 'Dance Room', wall: 'none', floor: 'dance', dark: 1, doors: [{ s: 'L', to: 'nursery' }, { s: 'B', x: 640, to: 'backyard', k: 'down', lab: 'BALCONY' }], deco: [['neon', 300, 'DANCE'], ['disco', 480]],
      items: [['stage', 426, 162, 0, 0], ['jukebox', 220, 196, 30, 0], ['speaker', 322, 148, 0, 0], ['speaker', 540, 148, 0, 0]] },
    backyard: { name: 'Backyard', wall: 'siding', floor: 'grass', out: 1, doors: [{ s: 'B', x: 200, to: 'dance', k: 'up', lab: 'STAIRS' }, { s: 'B', x: 360, to: 'bathroom', k: 'door' }, { s: 'B', x: 600, to: 'kitchen', k: 'glass' }], deco: [['hwin', 480], ['hwin', 676]],
      items: [['sandbox', 232, 282, 0, 0], ['swing', 470, 200, 0, 0], ['pool', 660, 284, 0, 0], ['tree', 744, 198, 0, 0], ['bush', 112, 238, 0, 0], ['bench', 396, 300, 0, 1]], toys: [['ball', 548, 308]] },
  };
  const RKEYS = ['living', 'kitchen', 'bathroom', 'bedroom', 'nursery', 'dance', 'backyard'];
  const pd = (d, f, s, w, o) => ({ d, f, s: s || 'none', w: w || 0, o: o == null ? 1 : o });
  const rr = (x, y, w, h, r) => { r = Math.min(r, w / 2, h / 2); return 'M' + f1(x + r) + ' ' + f1(y) + 'H' + f1(x + w - r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x + w) + ' ' + f1(y + r) + 'V' + f1(y + h - r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x + w - r) + ' ' + f1(y + h) + 'H' + f1(x + r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x) + ' ' + f1(y + h - r) + 'V' + f1(y + r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x + r) + ' ' + f1(y) + 'Z'; };
  const WY = y => (562 + 1.79 * (y - 100)) / 562;
  const sideB = (s, t) => s === 'L' ? [145 - 145 * t, 100 + 162 * t] : [707 + 145 * t, 100 + 162 * t];
  const NAME = { living: 'LIVING ROOM', kitchen: 'KITCHEN', bathroom: 'BATHROOM', bedroom: 'BEDROOM', nursery: 'NURSERY', dance: 'DANCE ROOM', backyard: 'BACKYARD' };
  function deco(k, a, P, o, T) {
    const [, x] = a;
    if (k === 'window' || k === 'hwin') {
      const w = k === 'hwin' ? 54 : 76, h = k === 'hwin' ? 44 : 46, y = k === 'hwin' ? 22 : 12, fr = a[2] === 'frost';
      if (k === 'hwin') { o.push(pd(rr(x - w / 2 - 16, y - 2, 13, h + 4, 3), '#84b6c9'), pd(rr(x + w / 2 + 3, y - 2, 13, h + 4, 3), '#84b6c9')); }
      o.push(pd(rr(x - w / 2 - 5, y - 5, w + 10, h + 10, 8), CR), pd(rr(x - w / 2, y, w, h, 5), fr ? 'url(#bFrost)' : 'url(#hsSky)'));
      if (!fr) o.push(pd(circ(x + w * 0.28, y + 12, 6), '#fff1a8'), pd(ell(x - w * 0.2, y + 14, 11, 4.5), WH), pd('M' + (x - w / 2) + ' ' + (y + h * 0.78) + 'Q' + f1(x - w / 6) + ' ' + f1(y + h * 0.52) + ' ' + f1(x + w / 8) + ' ' + f1(y + h * 0.7) + 'T' + (x + w / 2) + ' ' + f1(y + h * 0.64) + 'V' + (y + h - 3) + 'Q' + (x + w / 2) + ' ' + (y + h) + ' ' + (x + w / 2 - 3) + ' ' + (y + h) + 'H' + (x - w / 2 + 3) + 'Q' + (x - w / 2) + ' ' + (y + h) + ' ' + (x - w / 2) + ' ' + (y + h - 3) + 'Z', '#a8d08a'));
      o.push(pd(rr(x - 2, y, 4, h, 1), CR), pd(rr(x - w / 2, y + h / 2 - 2, w, 4, 1), CR), pd(rr(x - w / 2 - 9, y + h + 4, w + 18, 6, 3), CR), pd(rr(x - w / 2 - 9, y + h + 8, w + 18, 2, 1), P.r0));
      if (k === 'window' && !fr) { o.push(pd('M' + (x - w / 2 - 16) + ' ' + (y - 8) + 'H' + (x - w / 2 + 6) + 'Q' + (x - w / 2 - 1) + ' ' + (y + h / 2) + ' ' + (x - w / 2 + 8) + ' ' + (y + h + 10) + 'H' + (x - w / 2 - 13) + 'Q' + (x - w / 2 - 20) + ' ' + (y + h / 2) + ' ' + (x - w / 2 - 16) + ' ' + (y - 8) + 'Z', 'url(#hsCurt)'), pd('M' + (x + w / 2 + 16) + ' ' + (y - 8) + 'H' + (x + w / 2 - 6) + 'Q' + (x + w / 2 + 1) + ' ' + (y + h / 2) + ' ' + (x + w / 2 - 8) + ' ' + (y + h + 10) + 'H' + (x + w / 2 + 13) + 'Q' + (x + w / 2 + 20) + ' ' + (y + h / 2) + ' ' + (x + w / 2 + 16) + ' ' + (y - 8) + 'Z', 'url(#hsCurt)'), pd(rr(x - w / 2 - 22, y - 11, w + 44, 5, 2.5), '#b97a42')); }
    } else if (k === 'frame') { o.push(pd(rr(x - 30, 16, 60, 44, 5), 'url(#hsWood)'), pd(rr(x - 24, 22, 48, 32, 2), '#cfe8f4'), pd('M' + (x - 24) + ' 50L' + (x - 8) + ' 34L' + (x + 4) + ' 44L' + (x + 12) + ' 38L' + (x + 24) + ' 50V54H' + (x - 24) + 'Z', a[2]), pd(circ(x + 12, 30, 4.5), a[3]));
    } else if (k === 'clock') { o.push(pd(circ(x, 32, 19), 'url(#hsWood)'), pd(circ(x, 32, 15), 'url(#hsClock)'), pd('M' + x + ' 32L' + (x - 6) + ' 27', 'none', '#5b3b22', 2.6), pd('M' + x + ' 32L' + (x + 7) + ' 23', 'none', '#5b3b22', 1.8), pd(circ(x, 32, 2), '#e3946a'));
    } else if (k === 'shelf') { o.push(pd(rr(x - 40, 46, 80, 6, 2), 'url(#hsWood)')); [['#e3946a', -28, 20], ['#84b6c9', -8, 16], ['#f2c255', 12, 22], ['#9fc684', 30, 14]].forEach(([c, dx, h]) => o.push(pd(rr(x + dx - 7, 46 - h, 14, h, 4), CR), pd(rr(x + dx - 8, 46 - h - 4, 16, 6, 3), c)));
    } else if (k === 'mirror') { o.push(pd(circ(x, 36, 28), 'url(#hsWood)'), pd(circ(x, 36, 23), 'url(#bMirror)'), pd('M' + (x - 14) + ' 30L' + (x - 2) + ' 18M' + (x - 10) + ' 42L' + (x + 10) + ' 22', 'none', WH, 4, 0.8));
    } else if (k === 'rainbow') { ['#f3a35a', '#f6d466', '#8fd3a8', '#7cc4e8'].forEach((c, i) => { const r = 34 - i * 7; o.push(pd('M' + (x - r) + ' 62A' + r + ' ' + r + ' 0 0 1 ' + (x + r) + ' 62', 'none', c, 7)); }); o.push(pd(circ(x - 36, 60, 9), WH), pd(circ(x - 26, 58, 11), WH), pd(circ(x + 26, 58, 11), WH), pd(circ(x + 36, 60, 9), WH));
    } else if (k === 'bunting') { o.push(pd('M150 8Q426 40 702 8', 'none', '#b97a42', 1.6)); const C = ['#7cc4e8', '#8fd3a8', '#f6d466', '#f3a35a']; for (let n = 0; n < 20; n++) { const t = (n + 0.5) / 20, bx = (1 - t) * (1 - t) * 150 + 2 * (1 - t) * t * 426 + t * t * 702, by = (1 - t) * (1 - t) * 8 + 2 * (1 - t) * t * 40 + t * t * 8; o.push(pd('M' + f1(bx - 8) + ' ' + f1(by) + 'L' + f1(bx + 8) + ' ' + f1(by) + 'L' + f1(bx) + ' ' + f1(by + 13) + 'Z', C[n % 4])); }
    } else if (k === 'neon') { T.push({ x, y: 54, t: a[2], f: '#eafffb', s: '#4fe0d0', sz: 36, glow: 1 });
    } else if (k === 'disco') { o.push(pd('M' + x + ' 0V14', 'none', '#c9cde8', 2), pd(circ(x, 34, 22), 'url(#dBall)'), pd('M' + (x - 22) + ' 26H' + (x + 22) + 'M' + (x - 22) + ' 34H' + (x + 22) + 'M' + (x - 21) + ' 42H' + (x + 21) + 'M' + (x - 8) + ' 13V55M' + (x + 8) + ' 13V55', 'none', '#5a5f96', 1, 0.6), pd(rr(x - 13, 21, 8, 7, 1), WH, 0, 0, 0.85));
    }
  }
  function door(dd, P, o, T, R) {
    const lab = (dd.k === 'up' ? '\u2191 ' : dd.k === 'down' ? '\u2193 ' : '') + (dd.lab ? dd.lab + ' \u00b7 ' : '') + NAME[dd.to], sw = 12 + lab.length * 5.2;
    if (dd.s === 'B') {
      const x = dd.x, frame = 'M' + (x - 36) + ' 100V50Q' + (x - 36) + ' 20 ' + x + ' 20Q' + (x + 36) + ' 20 ' + (x + 36) + ' 50V100Z', inner = 'M' + (x - 31) + ' 100V52Q' + (x - 31) + ' 26 ' + x + ' 26Q' + (x + 31) + ' 26 ' + (x + 31) + ' 52V100Z';
      if (R.dark) o.push(pd(frame, '#4fe0d0', '#4fe0d0', 6, 0.35));
      o.push(pd(frame, P.trim, shade(R.dark ? '#4fe0d0' : P.trim, 0.8), 1.5));
      if (dd.k === 'up' || dd.k === 'down') {
        o.push(pd(inner, dd.k === 'up' ? '#5a3e2a' : '#2a1a10'));
        if (dd.k === 'up') for (let i = 0; i < 6; i++) o.push(pd(rr(x - 29 + i * 2.5, 100 - (i + 1) * 11, 58 - i * 5, 11, 1), i % 2 ? '#a86b36' : '#c98d58'));
        else for (let i = 0; i < 4; i++) o.push(pd(rr(x - 29 + i * 3.5, 70 + i * 7.5, 58 - i * 7, 6, 1), '#c98d58', 0, 0, 1 - i * 0.22));
        o.push(pd('M' + (x - 29) + ' 64L' + (x + (dd.k === 'up' ? 22 : -22)) + ' ' + (dd.k === 'up' ? 34 : 80), 'none', '#e2ad74', 2.5));
      } else if (dd.k === 'glass') { o.push(pd(inner, 'url(#hsSky)'), pd('M' + (x - 31) + ' 84Q' + (x - 10) + ' 72 ' + (x + 8) + ' 80T' + (x + 31) + ' 78V100H' + (x - 31) + 'Z', '#a8d08a'), pd('M' + x + ' 26V100M' + (x - 31) + ' 62H' + (x + 31), 'none', P.trim, 4), pd(circ(x + 24, 66, 3.5), 'url(#hsGold)'));
      } else { o.push(pd(inner, P.door), pd(rr(x - 22, 40, 44, 24, 7), P.doorL, 0, 0, 0.75), pd(rr(x - 22, 70, 44, 24, 7), P.doorL, 0, 0, 0.75), pd(circ(x + 23, 70, 4), 'url(#hsGold)')); }
      o.push(pd(rr(x - sw / 2, 4, sw, 13, 6.5), R.dark ? '#4fe0d0' : '#45189a')); T.push({ x, y: 13.5, t: lab, f: R.dark ? '#101231' : '#ffffff', sz: 8.5 });
      return { hit: frame, spawn: [x, 134], walk: [x, 176] };
    }
    const t0 = 0.4, t1 = 0.68, b0 = sideB(dd.s, t0), b1 = sideB(dd.s, t1), h0 = 72 * WY(b0[1]), h1 = 72 * WY(b1[1]);
    const Q = (ta, tb, ha, hb, fa, fb) => { const p = sideB(dd.s, ta), q = sideB(dd.s, tb), Ha = 72 * WY(p[1]), Hb = 72 * WY(q[1]); return 'M' + f1(p[0]) + ' ' + f1(p[1] - Ha * fa) + 'L' + f1(q[0]) + ' ' + f1(q[1] - Hb * fa) + 'L' + f1(q[0]) + ' ' + f1(q[1] - Hb * fb) + 'L' + f1(p[0]) + ' ' + f1(p[1] - Ha * fb) + 'Z'; };
    const frame = Q(t0 - 0.03, t1 + 0.03, 0, 0, 0, 1.08), inner = Q(t0, t1, 0, 0, 0, 1);
    if (R.dark) o.push(pd(frame, '#4fe0d0', '#4fe0d0', 6, 0.35));
    o.push(pd(frame, P.trim, shade(R.dark ? '#4fe0d0' : P.trim, 0.8), 1.5), pd(inner, P.door), pd(Q(t0 + 0.035, t1 - 0.035, 0, 0, 0.56, 0.9), P.doorL, 0, 0, 0.75), pd(Q(t0 + 0.035, t1 - 0.035, 0, 0, 0.1, 0.46), P.doorL, 0, 0, 0.75));
    const kn = sideB(dd.s, dd.s === 'L' ? t1 - 0.04 : t1 - 0.04); o.push(pd(circ(kn[0], kn[1] - 72 * WY(kn[1]) * 0.48, 4.2), 'url(#hsGold)'));
    const cx = (b0[0] + b1[0]) / 2, ty = Math.min(b0[1] - h0, b1[1] - h1) + 24;
    o.push(pd(rr(cx - sw / 2, ty - 13, sw, 13, 6.5), R.dark ? '#4fe0d0' : '#45189a')); T.push({ x: cx, y: ty - 3.5, t: lab, f: R.dark ? '#101231' : '#ffffff', sz: 8.5 });
    const tm = (t0 + t1) / 2, y = Math.max(FY0 + 6, 100 + 162 * tm + 10), ex = edge(y) + 30;
    return { hit: frame, spawn: [dd.s === 'L' ? ex : VW - ex, y], walk: [dd.s === 'L' ? ex + 90 : VW - ex - 90, y + 10] };
  }
  const SH = {};
  function shell(rk) {
    if (SH[rk]) return SH[rk];
    const R = ROOMS[rk], P = PAL[rk], o = [], T = [];
    if (R.out) {
      const fence = (s) => { let d = ''; for (let i = 0; i < 15; i++) { const t0 = i / 15 + 0.012, t1 = (i + 1) / 15 - 0.012, p = sideB(s, t0), q = sideB(s, t1), hp = 40 * WY(p[1]), hq = 40 * WY(q[1]); d += 'M' + f1(p[0]) + ' ' + f1(p[1]) + 'L' + f1(q[0]) + ' ' + f1(q[1]) + 'L' + f1(q[0]) + ' ' + f1(q[1] - hq) + 'L' + f1((p[0] + q[0]) / 2) + ' ' + f1((p[1] + q[1]) / 2 - (hp + hq) / 2 - 7) + 'L' + f1(p[0]) + ' ' + f1(p[1] - hp) + 'Z'; } return d; };
      const hedge = s => { let d = ''; for (let i = 0; i < 7; i++) { const p = sideB(s, (i + 0.5) / 7), r = 18 * WY(p[1]); d += circ(p[0] + (s === 'L' ? -r * 0.4 : r * 0.4), p[1] - 46 * WY(p[1]), r); } return d; };
      ['L', 'R'].forEach(s => o.push(pd(hedge(s), '#7ab45c', '#4f8a40', 2.5), pd(fence(s), CR, '#c9b48e', 1.2)));
      o.push(pd(rr(140, 0, 572, 9, 0), '#c4651f'), pd('M140 9H712', 'none', '#9a4a14', 2));
    }
    (R.deco || []).forEach(a => deco(a[0], a, P, o, T));
    const doors = R.doors.map((dd, i) => Object.assign({ id: rk + i, to: dd.to }, door(dd, P, o, T, R)));
    const fl = floor(R.floor, P);
    SH[rk] = { P, decor: o, texts: T, doors, floor: fl, wall: R.wall, out: !!R.out, dark: !!R.dark, name: R.name };
    return SH[rk];
  }
  function floor(type, P) {
    const H = 100, sp0 = 562 / 16.5, sp1 = sp0 * (562 + 1.79 * 293) / 562, xb = (j, y) => 426 + j * (sp0 + (sp1 - sp0) * (y - H) / 293);
    const quad = (j, a, b, step) => 'M' + f1(xb(j, a)) + ' ' + a + 'L' + f1(xb(j + step, a)) + ' ' + a + 'L' + f1(xb(j + step, b)) + ' ' + b + 'L' + f1(xb(j, b)) + ' ' + b + 'Z';
    let lines = '', dark = '', light = '', tiles = [];
    if (type === 'wood') {
      const rows = [100, 114, 130, 149, 171, 197, 228, 265, 310, 393];
      for (let j = -24; j <= 24; j++) lines += 'M' + f1(xb(j, H)) + ' ' + H + 'L' + f1(xb(j, 393)) + ' 393';
      for (let r = 1; r < rows.length - 1; r++) for (let j = -24; j < 24; j++) if (((j * 2 + r) % 3 + 3) % 3 === 0) lines += 'M' + f1(xb(j, rows[r])) + ' ' + rows[r] + 'L' + f1(xb(j + 1, rows[r])) + ' ' + rows[r];
      for (let r = 0; r < rows.length - 1; r++) for (let j = -24; j < 24; j++) { const m = ((j * 7 + r * 3) % 5 + 5) % 5; if (m === 0) dark += quad(j, rows[r], rows[r + 1], 1); else if (m === 2) light += quad(j, rows[r], rows[r + 1], 1); }
    } else if (type === 'checker' || type === 'dance') {
      const rows = [100, 122, 148, 180, 218, 264, 320, 393];
      for (let r = 0; r < rows.length - 1; r++) for (let j = -14; j < 14; j += 2) { const q = quad(j, rows[r], rows[r + 1], 2); if (type === 'dance') tiles.push({ i: j / 2, r, d: q }); else if ((((j / 2) + r) % 2 + 2) % 2 === 0) dark += q; }
      if (type === 'dance') for (let j = -14; j <= 14; j += 2) lines += 'M' + f1(xb(j, H)) + ' ' + H + 'L' + f1(xb(j, 393)) + ' 393';
      if (type === 'dance') rows.forEach(y => lines += 'M0 ' + y + 'H852');
    } else if (type === 'tile') {
      const rows = [100, 113, 128, 145, 165, 188, 215, 246, 283, 330, 393];
      for (let j = -24; j <= 24; j++) lines += 'M' + f1(xb(j, H)) + ' ' + H + 'L' + f1(xb(j, 393)) + ' 393';
      rows.forEach(y => lines += 'M0 ' + y + 'H852');
      for (let r = 0; r < rows.length - 1; r++) for (let j = -24; j < 24; j++) if (((j * 3 + r * 5) % 7 + 7) % 7 === 0) light += quad(j, rows[r], rows[r + 1], 1);
    } else if (type === 'grass') {
      for (let j = -14; j < 14; j += 2) if (((j / 2) % 2 + 2) % 2 === 0) light += quad(j, H, 393, 2);
      for (let n = 0; n < 70; n++) { const y = 110 + ((n * 53) % 280), x = 426 + (((n * 97) % 160) - 80) * 10 * WY(y) * 0.6; const k = WY(y) * 3; lines += 'M' + f1(x) + ' ' + y + 'l' + f1(-k) + ' ' + f1(-k * 2) + 'M' + f1(x + 3) + ' ' + y + 'l' + f1(k * 0.4) + ' ' + f1(-k * 2.4); }
    }
    return { lines, dark, light, tiles };
  }
  window.House3D = { grads, FS, SA, CA, VW, FY0, FY1, sAt, edge, CAT, CATS, ROOMS, RKEYS, PAL, render, shell, seatXY, useXY, half, NAME };
})();
