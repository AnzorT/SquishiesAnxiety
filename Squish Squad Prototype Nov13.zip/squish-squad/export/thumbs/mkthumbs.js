// Rasterize the card layers (bg/frame per rarity) + every creature's card art into PNGs (converted to WebP after).
const { chromium } = require('playwright'); const fs = require('fs'); const SA = '/tmp/claude-0/-home-claude/b71428ba-89b2-5297-bff5-1bcad18b67b9/scratchpad/standalone';
(async () => { const OUT = process.argv[2]; fs.mkdirSync(OUT, { recursive: true }); const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 800, height: 800 } });
  await p.route(/unpkg\.com/, r => { const u = r.request().url(); const f = u.includes('babel') ? 'npm/node_modules/@babel/standalone/babel.min.js' : u.includes('react-dom') ? 'npm/node_modules/react-dom/umd/react-dom.production.min.js' : 'npm/node_modules/react/umd/react.production.min.js'; r.fulfill({ path: SA + '/' + f, contentType: 'text/javascript' }); });
  await p.route(/fonts\.googleapis/, r => r.fulfill({ body: '', contentType: 'text/css' }));
  await p.goto('http://localhost:8790/' + encodeURIComponent('All Creatures Animations.dc.html')); await p.waitForTimeout(6000);
  const list = await p.evaluate(() => { const R = window.SquishSquad; return R.ROSTER.map((x, i) => ({ id: x.id, key: x.key, src: R.src(x.id) })).filter(x => x.src); });
  const jobs = [];
  for (const r of ['common', 'rare', 'epic', 'legendary', 'reward']) for (const l of ['bg', 'frame']) jobs.push({ src: 'export/cards/' + l + '-' + r + '.svg?v=1', out: l + '-' + r, w: 360, h: 499 });
  list.forEach(x => jobs.push({ src: x.src, out: 'c-' + x.key, max: 360 }));
  await p.setContent('<html><body style="margin:0;background:transparent"><img id="i" style="display:block"></body></html>');
  const man = {};
  for (const j of jobs) {
    const dim = await p.evaluate(async ([src, w, h, max]) => { const i = document.getElementById('i'); i.removeAttribute('width'); i.removeAttribute('height'); i.style.width = ''; i.style.height = '';
      await new Promise((res, rej) => { i.onload = res; i.onerror = rej; i.src = 'http://localhost:8790/' + src; }); let W = w, H = h;
      if (!W) { const nw = i.naturalWidth || 100, nh = i.naturalHeight || 100, k = max / Math.max(nw, nh); W = Math.round(nw * k); H = Math.round(nh * k); }
      i.style.width = W + 'px'; i.style.height = H + 'px'; await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))); return [W, H]; }, [j.src, j.w || 0, j.h || 0, j.max || 0]);
    await p.screenshot({ path: OUT + '/' + j.out + '.png', clip: { x: 0, y: 0, width: dim[0], height: dim[1] }, omitBackground: true });
    if (j.out.startsWith('c-')) man[j.src] = j.out;
  }
  fs.writeFileSync(OUT + '/manifest.json', JSON.stringify(man, null, 0)); console.log('done', jobs.length); await b.close(); })();
