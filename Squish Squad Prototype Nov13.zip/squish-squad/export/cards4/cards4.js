// Nov 13 cards v6 (user: 'give more room to the image of the creature and less room for the text' -> 'make the board of the text
// smaller' -> 'do it for all the rarities'): each frame re-proportioned on the same canvas (scratch tall/reshape.py): the name board
// is 300-380 px shorter and the picture window that much taller; the creature box is ~8 % wider than the window (thumbs have side
// padding) and bottom-aligned in it, so creatures show ~20-40 % bigger. frame-<rarity>.webp ?v=3.
// Nov 13 cards v5 frames (user: 'update the cards with this'): common = log + moss + mushrooms + stones, rare = driftwood + fur + blue crystals,
// epic = purple clouds + stars, legendary = cream + white wings + halo + stars, rainbow = pastel clouds + crystals + bubbles (keyed from the
// attachments by frames/key.py; frame-<rarity>.webp ?v=2, layout boxes below re-measured from each frame's window + lower panel).
// Nov 12 cards v4: the user's own rarity frames (common vines / rare bronze / epic purple / legendary gold / rainbow pastel)
// with 1-5 star pips in the name bar, the creature's group background in the picture window, and the creature's name drawn
// in the user's ABC letters for its rarity (names.js; built by make_cards4.py, see CLAUDE.md "CARDS v4").
// Layer boxes are % of the card (the frames' 1696 x 2528 canvas -> aspect-ratio 1696/2528), per rarity:
//   bg = group background (object-fit: cover; tucked under the frame's bars), art = the creature (contain, feet at the bottom),
//   nm = the name panel. Use: Object.assign(item, SQ_CARD4.of(creature)) and the card markup in the pages.
(function () {
  const FR = ['common', 'rare', 'epic', 'legendary', 'rainbow'];
  const L = {"common":{"bg":[18.28,16.22,82.96,66.61],"art":[18.24,20.48,83.0,63.92],"nm":[27.9,77.61,73.81,85.56]},"rare":{"bg":[19.58,15.19,80.48,61.55],"art":[19.69,18.15,80.37,58.86],"nm":[25.82,73.69,74.12,84.57]},"epic":{"bg":[15.8,19.94,84.14,63.13],"art":[21.9,22.78,78.04,60.44],"nm":[24.6,74.45,75.76,84.69]},"legendary":{"bg":[18.75,17.13,81.6,66.14],"art":[18.78,21.33,81.57,63.45],"nm":[25.55,76.15,75.1,86.19]},"rainbow":{"bg":[16.57,16.34,83.55,64.6],"art":[18.22,19.19,81.9,61.91],"nm":[25.6,75.36,75.99,85.76]}};
  const INK = { common: '#5a3410', rare: '#5a2a0a', epic: '#4a1d86', legendary: '#8a5208', rainbow: '#7a3ab8' };   // text fallback colours
  const pc = v => (+v).toFixed(2) + '%';
  const box = (p, b) => ({ [p + 'L']: pc(b[0]), [p + 'T']: pc(b[1]), [p + 'W']: pc(b[2] - b[0]), [p + 'H']: pc(b[3] - b[1]) });
  function of(x) {
    if (!x) x = { rar: 0, set: 'dream', name: '' };
    const rk = FR[x.rar] || 'common', l = L[rk], R = window.SquishSquad, key = x.key || (R && R.ROSTER && R.ROSTER[x.id] ? R.ROSTER[x.id].key : '');
    const n = (window.SQ_NAMES || {})[key], ok = !!(n && n[0] === x.rar);
    return Object.assign({ cdFrame: 'export/cards4/frame-' + rk + '.webp?v=3', cdBg: 'export/cards4/bg-' + (x.set || 'dream') + '.webp?v=1',
      cdName: ok ? n[1] : '', cdHasName: ok, cdNoName: !ok, cdInk: INK[rk], cdShine: x.rar >= 3, cdRar: rk }, box('cdBg', l.bg), box('cdArt', l.art), box('cdNm', l.nm));
  }
  // rarity order for every card list: common -> rare -> epic -> legendary -> rainbow, then roster order
  const byRar = (a, b) => (a.rar - b.rar) || (a.id - b.id);
  window.SQ_CARD4 = { FR, L, of, byRar, ASPECT: '1696/2528' };
})();
