// Renovation Catalog round 11 — Movie Room realism pass, part 2 (screens, projectors, speakers, concessions, drinks) on the RD.H10 per-face renderer.
// New materials (PAT.wood / marb / qz / fab), glassBox (back panes -> contents -> front panes), loopF (looping flipbook), zsort (depth sort by view vector),
// woofers that pump when the speaker plays, popcorn heaps / chips. Tap pieces: r.play 'open' (doors / lids / dome) or r.play 'show' (tap to run the machine).
// Sets RenoDraw.PLUS11; catalog edits RD.SET11.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS10 && RD.H10 && RD.H10.PAT && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS11) return;
  const K = X.K, { slab, shade } = K, N = RD.N, PI = Math.PI, H = RD.H10;
  const { PAT, cam, box3, cyl3, sph, shadow, tanF, FR, flip, KV, easeA, mist, vis, yawA, DEF10, can3, puffAt, add, sub, mul, dot, rng, isPlay, an, at, SPL, f1, n4, rep, P2, FONT, pth, hull } = H;
  Object.assign(PAT, { wood: 'm11wood', marb: 'm11marb', qz: 'm11qz', fab: 'm11fab' });
  const DEF11 = DEF10
    + '<pattern id="m11wood" width="46" height="6.4" patternUnits="userSpaceOnUse"><path d="M0 1.1C9 0.5 20 1.9 31 1S42 0.7 46 1.1" stroke="#2a1404" stroke-opacity="0.26" stroke-width="0.35" fill="none"/><path d="M0 3.4C11 4.2 23 2.8 34 3.7S43 3.2 46 3.4" stroke="#2a1404" stroke-opacity="0.16" stroke-width="0.7" fill="none"/><path d="M0 5.4C14 5 27 6 46 5.4" stroke="#ffe2b8" stroke-opacity="0.13" stroke-width="0.3" fill="none"/></pattern>'
    + '<pattern id="m11marb" width="64" height="44" patternUnits="userSpaceOnUse"><path d="M-2 20C18 24 40 16 66 22" stroke="#ddd7cc" stroke-opacity="0.55" stroke-width="2.6" fill="none"/><path d="M-2 8C10 10 16 4 26 9S44 18 52 12 62 8 66 10" stroke="#8f897f" stroke-opacity="0.4" stroke-width="0.45" fill="none"/><path d="M4 30C14 26 22 34 34 29S50 36 66 31" stroke="#a39c90" stroke-opacity="0.32" stroke-width="0.3" fill="none"/><path d="M26 9C28 16 24 22 30 29" stroke="#a39c90" stroke-opacity="0.26" stroke-width="0.25" fill="none"/><path d="M8 40C20 38 30 43 44 40" stroke="#c4a160" stroke-opacity="0.34" stroke-width="0.35" fill="none"/></pattern>'
    + '<pattern id="m11qz" width="4" height="4" patternUnits="userSpaceOnUse"><circle cx="0.8" cy="1" r="0.22" fill="#4a4a4a" fill-opacity="0.35"/><circle cx="2.9" cy="2.6" r="0.16" fill="#ffffff" fill-opacity="0.75"/><circle cx="1.9" cy="3.4" r="0.18" fill="#7a7570" fill-opacity="0.3"/><circle cx="3.4" cy="0.6" r="0.12" fill="#2a2a2a" fill-opacity="0.3"/></pattern>'
    + '<pattern id="m11fab" width="0.9" height="0.9" patternUnits="userSpaceOnUse"><rect width="0.45" height="0.45" fill="#ffffff" fill-opacity="0.07"/><rect x="0.45" y="0.45" width="0.45" height="0.45" fill="#000000" fill-opacity="0.14"/></pattern>'
    + '<pattern id="m11str" width="2.2" height="2" patternUnits="userSpaceOnUse"><rect width="1.1" height="2" fill="#d8283c" fill-opacity="0.85"/></pattern>'
    + '<pattern id="m11rib" width="4" height="1.6" patternUnits="userSpaceOnUse"><rect width="4" height="0.6" fill="#000000" fill-opacity="0.22"/><rect y="0.6" width="4" height="0.3" fill="#ffffff" fill-opacity="0.3"/></pattern>'
    + '<filter id="m11b8" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="8"/></filter><filter id="m11b4" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="4"/></filter>'
    + '<linearGradient id="m11gl" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="0.28" stop-color="#ffffff" stop-opacity="0.03"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.15"/><stop offset="0.56" stop-color="#ffffff" stop-opacity="0.02"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.1"/></linearGradient>'
    + '<radialGradient id="m11warm" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffd27a" stop-opacity="0.9"/><stop offset="0.5" stop-color="#ffab3a" stop-opacity="0.32"/><stop offset="1" stop-color="#ff8a1a" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="m11cy" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#8ff6ff" stop-opacity="0.85"/><stop offset="0.5" stop-color="#3fd0ff" stop-opacity="0.28"/><stop offset="1" stop-color="#3fd0ff" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="wfc11" cx="45%" cy="40%" r="62%"><stop offset="0" stop-color="#5c6066"/><stop offset="0.7" stop-color="#202125"/><stop offset="1" stop-color="#0c0c0e"/></radialGradient>'
    + '<radialGradient id="wfk11" cx="42%" cy="38%" r="64%"><stop offset="0" stop-color="#e0a254"/><stop offset="0.6" stop-color="#9a5a22"/><stop offset="1" stop-color="#3a1e08"/></radialGradient>'
    + '<radialGradient id="wfd11" cx="36%" cy="30%" r="70%"><stop offset="0" stop-color="#a9aeb6"/><stop offset="0.45" stop-color="#3c3f45"/><stop offset="1" stop-color="#101113"/></radialGradient>'
    + '<radialGradient id="twd11" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="#e2e4e7"/><stop offset="0.5" stop-color="#6c6f74"/><stop offset="1" stop-color="#232427"/></radialGradient>';

  // ---------- helpers ----------
  const ext = (C, P) => P.forEach(q => C.P(q));
  const zsort = (C, L) => L.sort((a, b) => dot(a.q, C.v) - dot(b.q, C.v)).map(o => o.s).join('');
  const loopF = (frames, T, b) => { const n = frames.length; if (n < 2) return frames.join(''); const bg = b ? ` begin="${n4(b)}s"` : '';
    return frames.concat([frames[0]]).map((s, i) => { const P = i === 0 ? [[0, 1], [0.5 / n, 1], [1 / n, 0], [1, 0]] : i === n ? [[0, 0], [(n - 1) / n, 0], [(n - 0.5) / n, 1], [1, 1]]
      : [[0, 0], [(i - 1) / n, 0], [(i - 0.5) / n, 1], [(i + 0.5) / n, 1], [(i + 1) / n, 0], [1, 0]];
      return `<g opacity="${i ? 0 : 1}"><animate attributeName="opacity" ${KV(P)} dur="${n4(T)}s"${bg} repeatCount="indefinite"/>${s}</g>`; }).join(''); };
  // smooth move of a rigid part: model-space offsets per key -> screen translate (exact under the orthographic camera)
  const slide = (C, s, O, keys, kt, T, o) => { const q0 = C.P(O), V = keys.map(d => { const q = C.P([O[0] + d[0], O[1] + d[1], O[2] + d[2]]); return f1(q[0] - q0[0]) + ' ' + f1(q[1] - q0[1]); });
    return `<g${o && o.once ? ` transform="translate(${V[V.length - 1]})"` : ''}><animateTransform attributeName="transform" type="translate" values="${V.join(';')}" keyTimes="${kt}" dur="${n4(T)}s" calcMode="spline" keySplines="${rep(keys.length - 1, () => '0.42 0 0.58 1').join(';')}"${o && o.once ? ' fill="freeze"' : ' repeatCount="indefinite"'}/>${s}</g>`; };
  const pane = (C, O, U, V, w, h, o) => { o = o || {}; return `<g transform="${FR(C, O, U, V)}"><rect width="${f1(w)}" height="${f1(h)}" fill="${o.tint || '#d6eef6'}" opacity="${o.t == null ? 0.1 : o.t}"/><rect width="${f1(w)}" height="${f1(h)}" fill="url(#m11gl)" opacity="${o.g == null ? 1 : o.g}"/>`
    + `<path d="M${f1(w * 0.2)} 0L${f1(w * 0.06)} ${f1(h)}H${f1(w * 0.13)}L${f1(w * 0.27)} 0Z" fill="#ffffff" opacity="${o.g == null ? 0.1 : 0.1 * o.g}"/><rect width="${f1(w)}" height="${f1(h)}" fill="none" stroke="#ffffff" stroke-opacity="${o.e == null ? 0.45 : o.e}" stroke-width="0.35"/></g>`; };
  const FACES = (c, w, h, d) => { const hw = w / 2, hd = d / 2, y = c[1] + h; return [
    { n: [0, 0, 1], O: [c[0] - hw, y, c[2] + hd], U: [1, 0, 0], W: w }, { n: [1, 0, 0], O: [c[0] + hw, y, c[2] + hd], U: [0, 0, -1], W: d },
    { n: [0, 0, -1], O: [c[0] + hw, y, c[2] - hd], U: [-1, 0, 0], W: w }, { n: [-1, 0, 0], O: [c[0] - hw, y, c[2] - hd], U: [0, 0, 1], W: d }]; };
  const glassBox = (C, c, w, h, d, o) => { let back = '', front = ''; FACES(c, w, h, d).forEach(F => { if (vis(C, F.n)) front += pane(C, F.O, F.U, [0, -1, 0], F.W, h, o); else back += pane(C, F.O, F.U, [0, -1, 0], F.W, h, Object.assign({}, o, { t: 0.05, g: 0.35, e: 0.22 })); });
    if (o && o.top) { const T = [c[0] - w / 2, c[1] + h, c[2] - d / 2]; front += pane(C, T, [1, 0, 0], [0, 0, 1], w, d, { t: 0.06, g: 0.5, e: 0.4 }); }
    ext(C, [[c[0] - w / 2, c[1], c[2] - d / 2], [c[0] + w / 2, c[1] + h, c[2] + d / 2]]); return { back, front }; };
  const woof = (cx, cy, r, on, ph, cu) => `<g transform="translate(${f1(cx)} ${f1(cy)})"><circle r="${f1(r)}" fill="#0a0a0b"/><circle r="${f1(r)}" fill="none" stroke="${cu ? '#8c6a34' : '#55585e'}" stroke-width="${f1(r * 0.07)}"/>`
    + `<g>${on ? at('scale', '1;1.07;0.97;1', 0.46, ph || 0, SPL(3)) : ''}<circle r="${f1(r * 0.86)}" fill="#26272b"/><circle r="${f1(r * 0.8)}" fill="none" stroke="#3d3f44" stroke-width="${f1(r * 0.1)}"/><circle r="${f1(r * 0.7)}" fill="url(#${cu ? 'wfk11' : 'wfc11'})"/><circle r="${f1(r * 0.28)}" fill="url(#wfd11)"/>`
    + `<path d="M${f1(-r * 0.62)} ${f1(-r * 0.42)}A${f1(r * 0.78)} ${f1(r * 0.78)} 0 0 1 ${f1(r * 0.42)} ${f1(-r * 0.64)}" stroke="#ffffff" stroke-opacity="0.2" stroke-width="${f1(r * 0.07)}" fill="none"/></g></g>`;
  const twt = (cx, cy, r, gold) => `<g transform="translate(${f1(cx)} ${f1(cy)})"><circle r="${f1(r)}" fill="#141416" stroke="${gold ? '#b8913f' : '#4a4c51'}" stroke-width="${f1(r * 0.14)}"/><circle r="${f1(r * 0.6)}" fill="url(#twd11)"/><circle cx="${f1(-r * 0.2)}" cy="${f1(-r * 0.22)}" r="${f1(r * 0.15)}" fill="#ffffff" opacity="0.75"/></g>`;
  const baffle = (w, h, c) => `<rect width="${f1(w)}" height="${f1(h)}" rx="0.8" fill="${c || '#18191c'}"/><rect width="${f1(w)}" height="${f1(h)}" rx="0.8" fill="url(#m10noise)"/><rect width="${f1(w)}" height="${f1(h)}" rx="0.8" fill="url(#m10v)"/><rect x="0.35" y="0.35" width="${f1(w - 0.7)}" height="${f1(h - 0.7)}" rx="0.6" fill="none" stroke="#000000" stroke-opacity="0.6" stroke-width="0.3"/>`;
  const byDepth = (C, L) => L.sort((a, b) => dot(a, C.v) - dot(b, C.v));
  const heap = (C, cx, cz, rx, rz, y0, hg, n, seed, sc) => { const R = rng(seed); return byDepth(C, rep(n, () => { const a = R() * 2 * PI, d = Math.sqrt(R()); return [cx + d * rx * Math.cos(a), y0 + hg * (1 - d * d) + R() * 1.1, cz + d * rz * Math.sin(a), R() * 360, (sc || 1) * (0.9 + R() * 0.3)]; })).map(q => puffAt(C, q, q[4], q[3])).join(''); };
  const CHIP = '<path d="M-1.7 1.1L1.8 0.7L0.1 -1.9Z" fill="#f0bf4c" stroke="#b9801c" stroke-width="0.2" stroke-linejoin="round"/><path d="M-0.6 0.4l0.5 -0.9" stroke="#ffe39a" stroke-width="0.3"/><circle cx="0.6" cy="0.1" r="0.18" fill="#c98a2a"/>';
  const chips = (C, cx, cz, rx, rz, y0, hg, n, seed) => { const R = rng(seed); return byDepth(C, rep(n, () => { const a = R() * 2 * PI, d = Math.sqrt(R()); return [cx + d * rx * Math.cos(a), y0 + hg * (1 - d * d) + R() * 0.8, cz + d * rz * Math.sin(a), R() * 360, 0.9 + R() * 0.4]; }))
    .map(q => { const c = C.P(q); return `<g transform="translate(${P2(c)}) rotate(${f1(q[3])}) scale(${n4(C.k * q[4])})">${CHIP}</g>`; }).join(''); };
  const planeE = (C, x, y, z, rx, rz, fill, op, ex) => `<g transform="${FR(C, [x, y, z], [1, 0, 0], [0, 0, 1])}"><ellipse rx="${f1(rx)}" ry="${f1(rz)}" fill="${fill}"${op != null ? ` opacity="${op}"` : ''}>${ex || ''}</ellipse></g>`;
  // front half of a thin vertical band (a closed cylinder's hull would fill the inside of an open ring)
  const BST = { chrome: [[0, 0.55], [0.12, 1.6], [0.25, 0.9], [0.45, 0.45], [0.6, 1.3], [0.78, 0.6], [0.9, 1.4], [1, 0.5]], gloss: [[0, 0.75], [0.2, 1.35], [0.5, 1], [1, 0.7]] };
  const band = (C, c, y0, y1, r, col, mat, back) => { const n = 40, P0 = [], P1 = []; for (let i = 0; i <= n; i++) { const t = C.thV + (back ? PI / 2 : -PI / 2) + i / n * PI, sx = Math.sin(t), sz = Math.cos(t); P1.push(C.p(c[0] + r * sx, y1, c[2] + r * sz)); P0.push(C.p(c[0] + r * sx, y0, c[2] + r * sz)); }
    const id = C.u('b'), a = P1[0], b = P1[n]; return `<defs><linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${f1(a[0])}" y1="${f1(a[1])}" x2="${f1(b[0])}" y2="${f1(b[1])}">${(BST[mat] || BST.gloss).map(([t, f]) => `<stop offset="${t}" stop-color="${shade(col, f * (back ? 0.7 : 1))}"/>`).join('')}</linearGradient></defs><path d="M${P1.map(P2).join('L')}L${P0.reverse().map(P2).join('L')}Z" fill="url(#${id})" stroke="${shade(col, 0.45)}" stroke-width="0.25" stroke-opacity="0.6"/>`; };
  const OPEN = (l, s, note, ex) => Object.assign({ play: 'open', playL: 'Open the ' + l, stopL: 'Close the ' + l, playS: s, idleS: 'Tap to open the ' + l, live: 'Opens', note }, ex || {});
  const SHOW = (pl, sl, s, idle, note, ex) => Object.assign({ play: 'show', playL: pl, stopL: sl, playS: s, idleS: idle, live: 'Tap to run', note }, ex || {});

  // ======================= MOV-042 85-INCH 4K QLED FLATSCREEN (wall, ambient backlight) =======================
  N.qled11 = S => { const TW = 190, TH = 108, TD = 2.2, ZB = 3.4, ZF = ZB + TD, BZ = 1.4, BB = 2.8, SW = TW - 2 * BZ, SH = TH - BZ - BB;
    const D = { w: 196, d: 10, mount: 'wall', elev: 30, act: 'watch', use: { x: 0, z: 160 } };
    D.build = () => [slab(0, BB, ZF + 0.05, SW, SH, 0.2, '#000000', { scr: 1, r: 0.3, emit: 1, noOut: 1, op: 0 })];
    const front = `<defs><linearGradient id="ql11s" x1="0" y1="0" x2="0.3" y2="1"><stop offset="0" stop-color="#262a31"/><stop offset="0.45" stop-color="#101216"/><stop offset="1" stop-color="#050506"/></linearGradient><linearGradient id="ql11r" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.075"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`
      + `<rect width="${TW}" height="${TH}" fill="#0c0d10"/><rect x="${BZ}" y="${BZ}" width="${f1(SW)}" height="${f1(SH)}" fill="url(#ql11s)"/>`
      + `<path d="M${f1(BZ + SW * 0.5)} ${BZ}H${f1(BZ + SW * 0.72)}L${f1(BZ + SW * 0.5)} ${f1(BZ + SH)}H${f1(BZ + SW * 0.28)}Z" fill="url(#ql11r)"/><path d="M${f1(BZ + SW * 0.76)} ${BZ}H${f1(BZ + SW * 0.8)}L${f1(BZ + SW * 0.58)} ${f1(BZ + SH)}H${f1(BZ + SW * 0.54)}Z" fill="#ffffff" opacity="0.025"/>`
      + `<rect x="${BZ}" y="${BZ}" width="${f1(SW)}" height="${f1(SH * 0.22)}" fill="#ffffff" opacity="0.018"/><path d="M${BZ} ${BZ + 0.15}H${f1(TW - BZ)}" stroke="#ffffff" stroke-opacity="0.1" stroke-width="0.3"/>`
      + `<text x="${TW / 2}" y="${f1(TH - 0.75)}" text-anchor="middle" ${FONT} font-size="1.5" letter-spacing="0.6" fill="#7d838b">QLED</text><circle cx="${TW / 2 + 60}" cy="${f1(TH - 1.3)}" r="0.32" fill="#ffffff" opacity="0.55"/>`;
    D.fx = ctx => { const C = cam(ctx);
      const QC = '#5b6cff;#b04dff;#ff5a8a;#ffb347;#33c9d6;#5b6cff';
      let s = `<g transform="${FR(C, [-TW / 2, TH, 0.1], [1, 0, 0], [0, -1, 0])}" color="#5b6cff">${an('color', QC, 18)}` + [[30, 0.07], [22, 0.1], [15, 0.14], [9, 0.2], [4, 0.26]].map(([e, op]) => `<rect x="${-e}" y="${-e}" width="${TW + 2 * e}" height="${TH + 2 * e}" rx="${e + 2}" fill="currentColor" opacity="${op}"/>`).join('') + '</g>'
        + `<g transform="${FR(C, [-TW / 2, TH, 0.15], [1, 0, 0], [0, -1, 0])}"><rect x="1" y="2.5" width="${TW + 3}" height="${TH + 3}" rx="3" fill="#000000" opacity="0.12"/><rect x="2.2" y="3.6" width="${TW}" height="${TH}" rx="2" fill="#000000" opacity="0.14"/></g>`;
      s += box3(C, { c: [0, 30, ZB / 2], w: 70, h: 44, d: ZB, r: 0.6, col: '#26282c', mat: 'brush', olw: 0.3 });
      s += box3(C, { c: [0, 0, ZB + TD / 2], w: TW, h: TH, d: TD, r: 0.5, col: '#35383e', mat: 'brush', gl: 0.6, dec: { f: front }, olc: '#050506', olw: 0.5, edge: 0.4 });
      ext(C, [[-TW / 2 - 24, TH + 24, 0], [TW / 2 + 24, -20, 0]]);
      return { defs: DEF11, front: s, bb: C.bb(2) }; };
    return D; };

  // ======================= MOV-046 4K ULTRA-SHORT-THROW LASER PROJECTOR =======================
  N.ust11 = S => { const W = 62, Hh = 13, Dd = 36;
    const D = { w: 74, d: 44, build: () => [] };
    const front = `<rect x="2.6" y="2.8" width="${W - 5.2}" height="${Hh - 4.6}" rx="1.4" fill="#34363b"/><rect x="2.6" y="2.8" width="${W - 5.2}" height="${Hh - 4.6}" rx="1.4" fill="url(#m11fab)"/><rect x="2.6" y="2.8" width="${W - 5.2}" height="${Hh - 4.6}" rx="1.4" fill="url(#m10v)"/><path d="M3.4 3.1H${W - 3.4}" stroke="#ffffff" stroke-opacity="0.14" stroke-width="0.3"/>`
      + `<rect x="${W / 2 - 4}" y="${Hh - 3.7}" width="8" height="1.2" rx="0.5" fill="#c9ccd0"/><text x="${W / 2}" y="${Hh - 2.8}" text-anchor="middle" ${FONT} font-size="0.8" fill="#3a3c40" letter-spacing="0.3">LASER TV</text>`;
    const top = `<defs><linearGradient id="us11w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a2d36"/><stop offset="0.5" stop-color="#0b0c10"/><stop offset="1" stop-color="#1a1c22"/></linearGradient></defs><rect x="7" y="3" width="${W - 14}" height="9.6" rx="3" fill="#c9c9c5"/><rect x="7.6" y="3.5" width="${W - 15.2}" height="8.6" rx="2.6" fill="url(#us11w)"/>`
      + `<rect x="${W / 2 - 13}" y="6.6" width="26" height="1.6" rx="0.8" fill="#bfe2ff" opacity="0.3">${an('opacity', '0.18;0.45;0.18', 4.5)}</rect><path d="M9 4.6H${W - 20}" stroke="#ffffff" stroke-opacity="0.35" stroke-width="0.35"/><path d="M${f1(W * 0.62)} 3.6L${f1(W * 0.55)} 12" stroke="#ffffff" stroke-opacity="0.12" stroke-width="1.6"/>`
      + `<g transform="translate(${W - 11} ${Dd - 8})">${[0, 3.4, 6.8].map(x => `<circle cx="${f1(x - 3.4)}" r="1" fill="#dcdcd8" stroke="#a9aaa6" stroke-width="0.2"/>`).join('')}<circle cx="-7" r="0.35" fill="#ffffff">${an('opacity', '1;0.3;1', 3)}</circle></g><text x="10" y="${Dd - 6.6}" ${FONT} font-size="1.6" fill="#b4b5b1" letter-spacing="0.8">LUMEN</text>`;
    const side = rep(9, i => `<rect x="${f1(8 + i * 2.2)}" y="4" width="1" height="5.4" rx="0.5" fill="#000000" fill-opacity="0.22"/>`).join('');
    D.fx = ctx => { const C = cam(ctx); let s = shadow(C, 0, 0, 36, 22, 0.85);
      [[-24, -13], [24, -13], [-24, 13], [24, 13]].forEach(([x, z]) => s += cyl3(C, [x, 0, z], [x, 1.2, z], 1.8, '#2a2b2e', { mat: 'matte', ol: 0 }));
      s += box3(C, { c: [0, 1.2, 0], w: W, h: Hh, d: Dd, r: 6.5, col: '#e8e7e3', gl: 0.25, mat: 'noise', dec: { f: front, t: top, r: side }, olw: 0.4, olo: 0.5 });
      s += shadow(C, 40, 14, 5, 9, 0.6) + box3(C, { c: [40, 0, 14], ax: yawA(0.35), w: 4.4, h: 1.3, d: 15, r: 1.8, col: '#1c1d20', gl: 0.5, dec: { t: `<circle cx="2.2" cy="2.6" r="0.7" fill="#c23a32"/>` + rep(3, i => `<circle cx="1.3" cy="${f1(5.4 + i * 1.8)}" r="0.45" fill="#45474c"/><circle cx="3.1" cy="${f1(5.4 + i * 1.8)}" r="0.45" fill="#45474c"/>`).join('') + `<circle cx="2.2" cy="11.6" r="1.1" fill="none" stroke="#55575c" stroke-width="0.35"/>` }, olw: 0.3 });
      return { defs: DEF11, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-050 5.1 SURROUND SOUND BOOKSHELF SPEAKER KIT =======================
  N.spk11 = S => { const on = isPlay(S), WAL = '#7a4724';
    const D = { w: 150, d: 70, build: () => [] };
    const fF = baffle(15, 24) + twt(7.5, 5, 2.4) + woof(7.5, 14.2, 5.4, on, 0) + `<rect x="5" y="20.8" width="5" height="1.4" rx="0.7" fill="#000000"/><text x="7.5" y="23.4" text-anchor="middle" ${FONT} font-size="0.75" fill="#9a9da2" letter-spacing="0.3">ARIA</text>`;
    const fS = baffle(10, 16) + twt(5, 4, 1.8) + woof(5, 10.6, 3.7, on, 0.3);
    const fC = baffle(36, 11) + woof(8, 5.5, 4.2, on, 0.1) + twt(18, 5.5, 2.2) + woof(28, 5.5, 4.2, on, 0.2) + `<text x="18" y="10.2" text-anchor="middle" ${FONT} font-size="0.75" fill="#9a9da2" letter-spacing="0.3">ARIA</text>`;
    const fW = baffle(24, 26, '#1b1b1e') + woof(12, 12, 9.6, on, 0.05) + `<rect x="7" y="23" width="10" height="1.6" rx="0.8" fill="#000000"/><text x="12" y="2.4" text-anchor="middle" ${FONT} font-size="1" fill="#7c7f84" letter-spacing="0.6">SUB 10</text><circle cx="21" cy="24" r="0.4" fill="${on ? '#3fa8ff' : '#2a4a6a'}"/>`;
    D.fx = ctx => { const C = cam(ctx), L = [];
      const stand = (x, z, h) => shadow(C, x, z, 10, 10, 0.7) + box3(C, { c: [x, 0, z], w: 14, h: 1.4, d: 14, r: 1, col: '#1c1c1f', gl: 0.3, olw: 0.3 }) + cyl3(C, [x, 1.4, z], [x, h - 1.2, z], 1.6, '#2c2d31', { mat: 'metal', olw: 0.3 }) + box3(C, { c: [x, h - 1.2, z], w: 12, h: 1.2, d: 14, r: 0.8, col: '#1c1c1f', olw: 0.3 });
      const wbox = (x, y, z, w, h, d, f) => box3(C, { c: [x, y, z], w, h, d, r: 1, col: WAL, mat: 'wood', gl: 0.35, dec: { f }, olc: '#2a1608', olw: 0.4 });
      [-1, 1].forEach(sg => { L.push({ q: [sg * 42, 30, -2], s: stand(sg * 42, -2, 26) + wbox(sg * 42, 26, -2, 15, 24, 18, fF) });
        L.push({ q: [sg * 64, 36, -24], s: stand(sg * 64, -24, 36) + wbox(sg * 64, 36, -24, 10, 16, 10, fS) }); });
      L.push({ q: [0, 6, 16], s: shadow(C, 0, 16, 22, 9, 0.75) + [-14, 14].map(x => cyl3(C, [x, 0, 16], [x, 1.2, 16], 1.2, '#151517', { mat: 'matte', ol: 0 })).join('') + wbox(0, 1.2, 16, 36, 11, 15, fC) });
      L.push({ q: [0, 13, -20], s: shadow(C, 0, -20, 17, 15, 0.8) + box3(C, { c: [0, 1.4, -20], w: 24, h: 26, d: 24, r: 1.6, col: '#1d1d20', mat: 'noise', gl: 0.2, dec: { f: fW }, olc: '#060607', olw: 0.45, edge: 0.2 }) });
      return { defs: DEF11, front: zsort(C, L), bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-051 KETTLE-CORN CART / MOV-102 GILDED POPCORN CARRIAGE (tap: kettle stirs + pops) =======================
  const cart11 = (S, R) => { const on = isPlay(S), W = 62, Dd = 36, Y0 = 14, BH = 30, Y1 = Y0 + BH, GH = 40, Y2 = Y1 + GH, RH = 5, GW = 58, GD = 32;
    const BODY = R ? '#6d1226' : '#c4222b', GOLD = '#d4a640', POST = R ? GOLD : '#c4222b', MET = R ? GOLD : '#c9ced3', KET = R ? '#d79a3c' : '#c9ced3';
    const D = { w: 96, d: 50, build: () => [] };
    const curl = (x, y, sx, sy, c) => `<path transform="translate(${x} ${y}) scale(${sx} ${sy})" d="M0 0c3 -0.4 5 1.2 4.6 3.4c-0.3 1.6 -2.4 1.8 -2.6 0.5c-0.1 -0.8 0.9 -1.1 1.2 -0.5" stroke="${c}" stroke-width="0.5" fill="none" stroke-linecap="round"/>`;
    const corners = (w, h, c) => curl(3.4, 3.4, 1, 1, c) + curl(w - 3.4, 3.4, -1, 1, c) + curl(3.4, h - 3.4, 1, -1, c) + curl(w - 3.4, h - 3.4, -1, -1, c);
    const crown = (cx, cy, s) => `<path transform="translate(${cx} ${cy}) scale(${s})" d="M-5 2L-6 -3L-3 0L0 -4L3 0L6 -3L5 2Z" fill="${GOLD}" stroke="#8a6420" stroke-width="0.3"/>`;
    const fK = `<rect x="2.4" y="2.4" width="57.2" height="25.2" rx="2" fill="none" stroke="#f6efe0" stroke-width="0.7"/><rect x="3.6" y="3.6" width="54.8" height="22.8" rx="1.4" fill="none" stroke="#f6efe0" stroke-opacity="0.55" stroke-width="0.3"/>` + corners(W, BH, '#f6efe0')
      + `<ellipse cx="31" cy="15" rx="19" ry="8.6" fill="#f7f0de" stroke="#d9b45a" stroke-width="0.8"/><ellipse cx="31" cy="15" rx="17.4" ry="7.1" fill="none" stroke="#c4222b" stroke-width="0.35"/><text x="31" y="9.9" text-anchor="middle" ${FONT} font-size="1.4" letter-spacing="0.5" fill="#8a6a3a">★ FRESH ★</text>`
      + `<text x="31" y="15" text-anchor="middle" font-family="Georgia,'Times New Roman',serif" font-style="italic" font-weight="700" font-size="5" fill="#b81d26">Kettle</text><text x="31" y="20.2" text-anchor="middle" ${FONT} font-size="3.6" letter-spacing="1.4" fill="#2b1a10">CORN</text>`;
    const fR = `<rect x="2" y="2" width="58" height="26" rx="1" fill="none" stroke="#e8c463" stroke-width="1"/><rect x="3.6" y="3.6" width="54.8" height="22.8" fill="none" stroke="#e8c463" stroke-opacity="0.6" stroke-width="0.35"/>` + corners(W, BH, '#e8c463')
      + crown(31, 9.6, 0.62) + `<text x="31" y="17" text-anchor="middle" font-family="Georgia,'Times New Roman',serif" font-weight="700" font-size="4.6" letter-spacing="0.8" fill="#f2d27a">ROYAL</text><text x="31" y="22.2" text-anchor="middle" ${FONT} font-size="2.6" letter-spacing="1.6" fill="#e8c463">POPCORN</text>`;
    const sideD = (w) => `<rect x="2.4" y="2.4" width="${w - 4.8}" height="25.2" rx="${R ? 1 : 2}" fill="none" stroke="${R ? '#e8c463' : '#f6efe0'}" stroke-width="${R ? 0.9 : 0.7}"/>` + corners(w, BH, R ? '#e8c463' : '#f6efe0') + (R ? crown(w / 2, 15, 0.7) : `<circle cx="${w / 2}" cy="15" r="5" fill="#f7f0de" stroke="#d9b45a" stroke-width="0.6"/><text x="${w / 2}" y="16.4" text-anchor="middle" ${FONT} font-size="3.4" fill="#b81d26">★</text>`);
    const bulbs = (w, y, n, off) => rep(n, i => { const x = f1(2 + (w - 4) * i / (n - 1)); return `<circle cx="${x}" cy="${y}" r="1.4" fill="#ffcf5a" opacity="0.35"/><circle cx="${x}" cy="${y}" r="0.75" fill="#fff6c8">${on ? an('fill-opacity', '1;0.25;1', 0.9, -((i + (off || 0)) % 6) * 0.15) : ''}</circle>`; }).join('');
    const awn = w => { const n = Math.round(w / 4), sw = w / n; return rep(n, i => i % 2 ? `<rect x="${f1(i * sw)}" width="${f1(sw)}" height="${RH}" fill="#f6efe2"/><path d="M${f1(i * sw)} ${RH}a${f1(sw / 2)} ${f1(sw / 2)} 0 0 0 ${f1(sw)} 0Z" fill="#f6efe2"/>` : `<path d="M${f1(i * sw)} ${RH}a${f1(sw / 2)} ${f1(sw / 2)} 0 0 0 ${f1(sw)} 0Z" fill="#c4222b"/>`).join('') + `<path d="M0 0.3H${w}" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.4"/>`; };
    const roofD = w => R ? `<rect width="${w}" height="${RH}" fill="url(#m10v)"/>` + bulbs(w, RH / 2, Math.round(w / 5)) : awn(w);
    const signF = R ? `<rect x="0.8" y="0.8" width="42.4" height="10.4" rx="1" fill="none" stroke="#e8c463" stroke-width="0.8"/>` + bulbs(44, 0.9, 12) + `<text x="22" y="8" text-anchor="middle" font-family="Georgia,'Times New Roman',serif" font-weight="700" font-size="4.4" letter-spacing="0.6" fill="#f2d27a">Grand Cinema</text>`
      : `<rect x="0.8" y="0.8" width="42.4" height="10.4" rx="1.6" fill="none" stroke="#c4222b" stroke-width="0.8"/><text x="22" y="7.4" text-anchor="middle" ${FONT} font-size="4.6" letter-spacing="0.8" fill="#c4222b">KETTLE CORN</text><text x="22" y="10.1" text-anchor="middle" ${FONT} font-size="1.4" letter-spacing="0.8" fill="#6a4a2a">HOT · SWEET · SALTY</text>`;
    const wheel = (C, xw, sg) => { const Rw = 17, yc = 17, zc = -5, U = [0, 0, -sg], V = [0, -1, 0], tyre = R ? '#2a1c10' : '#1d1b1a', rim = R ? GOLD : '#c4222b', ns = R ? 16 : 12;
      const spk = rep(ns, i => { const a = i / ns * 2 * PI; return `<path d="M${f1(2.6 * Math.cos(a))} ${f1(2.6 * Math.sin(a))}L${f1((Rw - 2) * Math.cos(a))} ${f1((Rw - 2) * Math.sin(a))}" stroke="${rim}" stroke-width="${R ? 0.8 : 1.05}" stroke-linecap="round"/>`; }).join('');
      const ring = (c1, c2) => `<circle r="${Rw}" fill="none" stroke="${c1}" stroke-width="2.4"/><circle r="${Rw - 1.7}" fill="none" stroke="${c2}" stroke-width="1.3"/>`;
      return `<g transform="${FR(C, [xw - sg * 1.3, yc, zc], U, V)}">${ring(shade(tyre, 0.7), shade(rim, 0.55))}</g><g transform="${FR(C, [xw + sg * 1.3, yc, zc], U, V)}">${ring(tyre, rim)}${spk}${R ? `<circle r="${Rw * 0.55}" fill="none" stroke="${GOLD}" stroke-width="0.6"/>` : ''}`
        + `<circle r="3" fill="${R ? GOLD : '#d6b04a'}" stroke="#7a5a1a" stroke-width="0.3"/><circle r="1.1" fill="${R ? '#6d1226' : '#8a6a2a'}"/><path d="M${-Rw + 0.6} -2A${Rw} ${Rw} 0 0 1 -2 ${-Rw + 0.6}" stroke="#ffffff" stroke-opacity="0.3" stroke-width="0.6" fill="none"/></g>`; };
    const kettle = (C, t) => { const P0 = [0, Y2 - 12, 0], rot = q => [q[0], P0[1] + q[1] * Math.cos(t) - q[2] * Math.sin(t), P0[2] + q[1] * Math.sin(t) + q[2] * Math.cos(t)];
      const b = rot([0, -14, 0]), a = rot([0, -3, 0]);
      return [-11.4, 11.4].map(x => cyl3(C, [x, Y2, 0], [x, Y2 - 12, 0], 0.55, MET, { mat: 'metal', olw: 0.25 })).join('') + cyl3(C, [-11.6, Y2 - 12, 0], [11.6, Y2 - 12, 0], 0.7, MET, { mat: 'metal', olw: 0.25 })
        + cyl3(C, b, a, 6.2, KET, { r2: 10.4, mat: 'metal', olw: 0.4, cap: cr => `<circle r="${f1(cr * 0.92)}" fill="#6a4a22"/><circle r="${f1(cr * 0.92)}" fill="url(#m10in)"/>` + rep(9, i => `<circle cx="${f1(Math.cos(i * 2.4) * cr * 0.55 * ((i % 3) / 3 + 0.3))}" cy="${f1(Math.sin(i * 2.4) * cr * 0.55 * ((i % 3) / 3 + 0.3))}" r="0.9" fill="${i % 2 ? '#fff4d6' : '#e8b44a'}"/>`).join('') })
        + cyl3(C, rot([0, -2.6, -4]), rot([0, -1.4, -4]), 4.6, KET, { mat: 'metal', olw: 0.3 }); };
    D.fx = ctx => { const C = cam(ctx); let s = shadow(C, 0, 0, 44, 28, 0.85);
      const after = [], wh = [-1, 1].map(sg => ({ sg, s: wheel(C, sg * (W / 2 + 2.6), sg) }));
      wh.forEach(w => { if (vis(C, [w.sg, 0, 0])) after.push(w.s); else s += w.s; });
      [-1, 1].forEach(sg => s += cyl3(C, [sg * (W / 2 - 5), 0.8, Dd / 2 - 4], [sg * (W / 2 - 5), Y0, Dd / 2 - 4], 1.1, MET, { mat: R ? 'metal' : 'chrome', olw: 0.25 }) + cyl3(C, [sg * (W / 2 - 5), 0, Dd / 2 - 4], [sg * (W / 2 - 5), 1.2, Dd / 2 - 4], 2, '#2a2a2c', { mat: 'matte', olw: 0.25 }));
      const hx = -W / 2 - 12, hy = Y1 - 2, handle = [-10, 10].map(z => cyl3(C, [-W / 2 + 0.5, Y1 - 7, z], [hx, hy, z], 0.9, MET, { mat: R ? 'metal' : 'chrome', olw: 0.25 })).join('') + cyl3(C, [hx, hy, -11.6], [hx, hy, 11.6], 1.2, R ? '#3a1a10' : '#1d1d1f', { mat: 'matte', olw: 0.3 });
      if (vis(C, [-1, 0, 0])) after.push(handle); else s += handle;
      s += box3(C, { c: [0, Y0 - 2, 0], w: W + 2, h: 2.2, d: Dd + 2, r: 1.6, col: R ? GOLD : '#d9dde0', mat: 'brush', gl: 0.8, olw: 0.3 });
      s += box3(C, { c: [0, Y0, 0], w: W, h: BH, d: Dd, r: 1.6, col: BODY, gl: R ? 0.5 : 0.85, dec: { f: R ? fR : fK, b: R ? fR : fK, r: sideD(Dd), l: sideD(Dd) }, olw: 0.45 });
      s += box3(C, { c: [0, Y1 - 0.4, 0], w: W + 1.6, h: 2, d: Dd + 1.6, r: 1.6, col: R ? GOLD : '#d9dde0', mat: 'brush', gl: 0.8, olw: 0.3 });
      s += after.join('');
      const G = glassBox(C, [0, Y1 + 1.6, 0], GW, GH - 1.6, GD), posts = [-1, 1].flatMap(sx => [-1, 1].map(sz => { const x = sx * GW / 2, z = sz * GD / 2;
        return { q: [x, Y1, z], s: cyl3(C, [x, Y1 + 1.6, z], [x, Y2, z], R ? 1.5 : 1.3, POST, { mat: R ? 'metal' : 'gloss', olw: 0.3 }) + (R ? sph(C, [x, Y1 + 2.4, z], 1.9, GOLD) : '') }; })), c0 = dot([0, Y1, 0], C.v);
      s += G.back + posts.filter(p => dot(p.q, C.v) < c0).map(p => p.s).join('');
      s += heap(C, 0, 0, GW / 2 - 3, GD / 2 - 3, Y1 + 1.6, 10, 120, R ? 'rcart' : 'kcart', 1.05);
      s += box3(C, { c: [0, Y2 - 6.5, 0], w: 10, h: 6, d: 8, r: 1.2, col: MET, mat: 'brush', gl: 0.5, olw: 0.3 });
      if (on) { s += loopF(rep(12, j => 0.23 * (1 - Math.cos(2 * PI * j / 12))).map(t => kettle(C, t)), 2.4);
        const R2 = rng('pop' + (R ? 'r' : 'k')), m0 = C.p(0, Y2 - 16, 4);
        s += rep(8, i => { const e = C.p((R2() - 0.5) * 40, Y1 + 5 + R2() * 3, (R2() - 0.5) * 20), c = [(m0[0] + e[0]) / 2 + (R2() - 0.5) * 10, Math.min(m0[1], e[1]) - 5 - R2() * 6], d = 0.9 + R2() * 0.5, b = -i * 0.3;
          return `<g opacity="0"><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;0.08;0.85;1" dur="${n4(d)}s" begin="${n4(b)}s" repeatCount="indefinite"/><animateMotion dur="${n4(d)}s" begin="${n4(b)}s" repeatCount="indefinite" path="M${P2(m0)}Q${P2(c)} ${P2(e)}"/><g transform="scale(${n4(C.k * 1.05)})"><g>${at('rotate', `0;${R2() > 0.5 ? 360 : -360}`, d * 0.9)}${PUFF0}</g></g></g>`; }).join('');
      } else s += kettle(C, 0);
      const lp = C.p(0, Y2 - 1, 0); s += `<ellipse cx="${f1(lp[0])}" cy="${f1(lp[1] + 6 * C.k)}" rx="${f1(26 * C.k)}" ry="${f1(14 * C.k)}" fill="url(#m11warm)" opacity="${on ? 0.7 : 0.32}">${on ? an('opacity', '0.55;0.85;0.6;0.8;0.55', 1.6) : ''}</ellipse>`;
      s += G.front + posts.filter(p => dot(p.q, C.v) >= c0).map(p => p.s).join('');
      s += box3(C, { c: [0, Y2, 0], w: GW + 8, h: RH, d: GD + 8, r: 1.2, col: R ? GOLD : '#c4222b', mat: R ? 'brush' : undefined, gl: 0.8, dec: { f: roofD(GW + 8), b: roofD(GW + 8), r: roofD(GD + 8), l: roofD(GD + 8) }, olw: 0.35 });
      s += box3(C, { c: [0, Y2 + RH, 0], w: 44, h: 12, d: 1.6, r: 0.4, col: R ? '#6d1226' : '#f6efe0', gl: 0.5, dec: { f: signF, b: signF }, olw: 0.35 });
      if (R) { const y = Y2 + RH + 11.4; s += sph(C, [0, y + 3.4, 0], 3.4, '#9a1530') + cyl3(C, [0, y, 0], [0, y + 3, 0], 4.6, GOLD, { mat: 'metal', olw: 0.3 })
          + zsort(C, rep(5, i => { const a = C.thV + (i - 2) * 0.62, q = [4.3 * Math.sin(a), y + 3, 4.3 * Math.cos(a)]; return { q, s: cyl3(C, q, add(q, [0, 3.6, 0]), 0.9, GOLD, { r2: 0.15, mat: 'metal', ol: 0 }) + sph(C, add(q, [0, 3.8, 0]), 0.6, '#fff1b0') }; }))
          + sph(C, [0, y + 7.6, 0], 1.1, GOLD);
        [-1, 1].forEach(sx => [-1, 1].forEach(sz => s += sph(C, [sx * (GW / 2 + 3), Y2 + RH + 1.2, sz * (GD / 2 + 3)], 1.7, GOLD))); }
      else [-1, 1].forEach(sx => [-1, 1].forEach(sz => s += sph(C, [sx * (GW / 2 + 3), Y2 + RH + 1.2, sz * (GD / 2 + 3)], 1.5, '#e8c24a')));
      if (on) s += mist(C, 0, Y2 + RH + 4, 0, 4, 1.1);
      return { defs: DEF11, front: s, bb: C.bb(8) }; };
    return D; };
  const PUFF0 = H.PUFF;
  N.kcart11 = S => cart11(S, 0);
  N.rcart11 = S => cart11(S, 1);

  // ======================= MOV-054 GLASS-FRONT RETRO COLA MINI-FRIDGE (tap: open / close) =======================
  N.cola11 = S => { const open = isPlay(S), RED = '#c41e27', W = 40, Dd = 32, H = 56, FT = 5, DT = 3.4, Z0 = -16, ZF = 13, ID = 2.8, WL = 4, WT = 15, WR = 4, WB = 5.5;
    const D = { w: 48, d: 44, build: () => [] };
    const doorF = `<rect x="${WL - 1}" y="${WT - 1}" width="${W - WL - WR + 2}" height="${H - WT - WB + 2}" rx="1" fill="none" stroke="#e6e9ec" stroke-width="1.6"/><rect x="${WL - 1.8}" y="${WT - 1.8}" width="${W - WL - WR + 3.6}" height="${H - WT - WB + 3.6}" rx="1.4" fill="none" stroke="#7d8288" stroke-width="0.3"/>`
      + `<text x="${W / 2}" y="7" text-anchor="middle" font-family="Georgia,'Times New Roman',serif" font-style="italic" font-weight="700" font-size="4.6" fill="#ffffff">Ice Cold</text><rect x="${W / 2 - 9}" y="8.4" width="18" height="4.2" rx="2.1" fill="#ffffff"/><text x="${W / 2}" y="11.65" text-anchor="middle" ${FONT} font-size="3.2" letter-spacing="1.2" fill="${RED}">COLA</text>`
      + rep(8, i => `<rect x="${f1(9 + i * 2.9)}" y="${H - 4}" width="1.7" height="2.6" rx="0.5" fill="#2a0a0c" opacity="0.65"/>`).join('');
    const liner = `<rect x="1.5" y="1.5" width="${W - 3}" height="${H - 3}" rx="2" fill="#f1f2f0"/><rect x="1.5" y="1.5" width="${W - 3}" height="${H - 3}" rx="2" fill="none" stroke="#a7aaa8" stroke-width="1.1"/>`;
    const doorAt = (C, th) => { const t = th * PI / 180, ex = [Math.cos(t), 0, Math.sin(t)], ez = [-Math.sin(t), 0, Math.cos(t)], hg = [-W / 2, FT, ZF], L = (u, y, sd) => add(add(hg, mul(ex, u)), add(mul(ez, sd), [0, y, 0]));
      const hu = W - 3.6; let s = box3(C, { c: add(hg, add(mul(ex, W / 2), mul(ez, DT / 2))), ax: [ex, [0, 1, 0], ez], w: W, h: H, d: DT, r: 2, col: RED, gl: 0.85, dec: { f: doorF, b: liner }, hole: { f: [WL, WT, WR, WB], b: [WR, WT, WL, WB] }, olw: 0.45 });
      s += pane(C, L(WL, H - WT, DT * 0.6), ex, [0, -1, 0], W - WL - WR, H - WT - WB, { t: 0.12, tint: '#cfe9f2' });
      const h1 = L(hu, 18, DT), h2 = L(hu, 40, DT), o1 = L(hu, 18, DT + 2), o2 = L(hu, 40, DT + 2);
      s += cyl3(C, h1, o1, 0.7, '#cfd4d8', { mat: 'chrome', olw: 0.2 }) + cyl3(C, h2, o2, 0.7, '#cfd4d8', { mat: 'chrome', olw: 0.2 }) + cyl3(C, add(o1, [0, -1, 0]), add(o2, [0, 1, 0]), 0.95, '#d9dde0', { mat: 'chrome', olw: 0.25 });
      return s; };
    const bottle = (C, x, y, z) => cyl3(C, [x, y, z], [x, y + 6.6, z], 2, '#4b1d0e', { mat: 'gloss', op: 0.94, olw: 0.25, noCap: 1 }) + cyl3(C, [x, y + 6.6, z], [x, y + 9.8, z], 2, '#5a2412', { r2: 0.85, mat: 'gloss', op: 0.94, olw: 0.25, noCap: 1 })
      + cyl3(C, [x, y + 9.8, z], [x, y + 11.6, z], 0.85, '#5a2412', { mat: 'gloss', op: 0.94, noCap: 1, olw: 0.2 }) + cyl3(C, [x, y + 11.6, z], [x, y + 12.4, z], 1.05, '#d8322f', { mat: 'metal', olw: 0.2 })
      + `<g transform="${tanF(C, x, z, 2.02, C.thV, y + 4.2)}"><path d="M-1.8 0q0.9 -0.8 1.8 0t1.8 0" stroke="#ffffff" stroke-width="0.55" fill="none"/></g>`;
    const shelf = (C, xi, y, zi, IW, IDp) => `<g transform="${FR(C, [xi, y, zi], [1, 0, 0], [0, 0, 1])}">` + rep(12, i => `<path d="M${f1(0.6 + i * (IW - 1.2) / 11)} 0.4V${f1(IDp - 0.6)}" stroke="#80898e" stroke-width="0.5"/><path d="M${f1(0.45 + i * (IW - 1.2) / 11)} 0.4V${f1(IDp - 0.6)}" stroke="#eef2f4" stroke-width="0.26"/>`).join('') + `<path d="M0 ${f1(IDp - 0.8)}H${f1(IW)}" stroke="#dfe5e8" stroke-width="1"/></g>`;
    D.fx = ctx => { const C = cam(ctx); let s = shadow(C, 0, -1, 26, 22, 0.85);
      [[-15, -12], [15, -12], [-15, 10], [15, 10]].forEach(([x, z]) => s += cyl3(C, [x, 0, z], [x, FT, z], 1.5, '#d5dadd', { r2: 1, mat: 'chrome', olw: 0.25 }));
      s += box3(C, { c: [0, FT - 1.2, (Z0 + ZF) / 2], w: W - 2, h: 1.4, d: ZF - Z0 - 2, r: 5, col: '#d5dadd', mat: 'brush', gl: 0.8, olw: 0.25 });
      const xi = -W / 2 + ID, yb = FT + ID, yt = FT + H - ID, zi = Z0 + ID, IW = W - 2 * ID, IH = yt - yb, IDp = ZF - zi, IN = '#f4f6f7', L = open ? 1.06 : 0.96;
      s += `<g transform="${FR(C, [xi, yt, zi], [1, 0, 0], [0, -1, 0])}"><rect width="${f1(IW)}" height="${f1(IH)}" fill="${shade(IN, 0.92 * L)}"/><rect width="${f1(IW)}" height="${f1(IH)}" fill="url(#m10in)" opacity="0.5"/><rect x="3" y="0.8" width="${f1(IW - 6)}" height="1.2" rx="0.6" fill="#fff8e0"/><ellipse cx="${f1(IW / 2)}" cy="3" rx="${f1(IW * 0.45)}" ry="10" fill="#fff6d8" opacity="0.4"/></g>`
        + `<g transform="${FR(C, [xi, yt, zi], [0, 0, 1], [0, -1, 0])}"><rect width="${f1(IDp)}" height="${f1(IH)}" fill="${shade(IN, 0.8 * L)}"/><rect width="${f1(IDp)}" height="${f1(IH)}" fill="url(#m10in)" opacity="0.5"/></g>`
        + `<g transform="${FR(C, [xi, yb, zi], [1, 0, 0], [0, 0, 1])}"><rect width="${f1(IW)}" height="${f1(IDp)}" fill="${shade(IN, 0.86 * L)}"/></g>`;
      [-11, -3.7, 3.7, 11].forEach((x, i) => s += can3(C, x, yb, -1, 3, 8, [0, 1, 0, 1][i]));
      s += shelf(C, xi, FT + 21, zi, IW, IDp); [-10.5, -3.5, 3.5, 10.5].forEach(x => s += bottle(C, x, FT + 21, -1));
      s += shelf(C, xi, FT + 34.5, zi, IW, IDp); [-10.5, -3.5, 3.5, 10.5].forEach(x => s += bottle(C, x, FT + 34.5, -1));
      if (open) s += `<g transform="${FR(C, [xi, yt, ZF], [1, 0, 0], [0, -1, 0])}"><rect width="${f1(IW)}" height="${f1(IH)}" fill="url(#m10cold)">${an('opacity', '0.8;1;0.8', 3)}</rect></g>` + mist(C, 0, FT + 10, ZF + 2, 3, 0.9);
      s += box3(C, { c: [0, FT, (Z0 + ZF) / 2], w: W, h: H, d: ZF - Z0, r: 6, col: RED, gl: 0.85, hole: { f: [ID, ID, ID, ID] }, dec: { r: rep(6, i => `<rect x="${f1(8 + i * 2.6)}" y="${H - 9}" width="1.2" height="6" rx="0.6" fill="#000000" fill-opacity="0.28"/>`).join('') + `<path d="M3 ${H - 1.2}H${ZF - Z0 - 3}" stroke="#ffffff" stroke-opacity="0.3" stroke-width="0.4"/>` }, olw: 0.45 });
      if (!open) s += doorAt(C, 0); else { const A = easeA(110, 10); s += flip(A.map((a, i) => ({ i, s: doorAt(C, a) })), A.length, 0.7); }
      return { defs: DEF11, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= MOV-066 DUAL-LENS COMMERCIAL 3D DIGITAL CINEMA RIG =======================
  N.rig11 = S => { const D = { w: 84, d: 74, build: () => [] }, GR = '#2d3036';
    const lens = cr => `<defs><radialGradient id="rg11l" cx="42%" cy="38%" r="62%"><stop offset="0" stop-color="#5a5fb0"/><stop offset="0.45" stop-color="#1b2046"/><stop offset="1" stop-color="#04050a"/></radialGradient></defs><circle r="${f1(cr)}" fill="#0f1013"/><circle r="${f1(cr * 0.8)}" fill="url(#rg11l)"/><circle r="${f1(cr * 0.8)}" fill="none" stroke="#3a3d44" stroke-width="0.35"/>`
      + `<path d="M${f1(-cr * 0.6)} ${f1(-cr * 0.12)}A${f1(cr * 0.62)} ${f1(cr * 0.62)} 0 0 1 ${f1(cr * 0.12)} ${f1(-cr * 0.6)}" stroke="#7affc8" stroke-opacity="0.45" stroke-width="0.4" fill="none"/><ellipse cx="${f1(-cr * 0.28)}" cy="${f1(-cr * 0.3)}" rx="${f1(cr * 0.22)}" ry="${f1(cr * 0.12)}" fill="#ffffff" opacity="0.75" transform="rotate(-35 ${f1(-cr * 0.28)} ${f1(-cr * 0.3)})"/><circle r="${f1(cr * 0.5)}" fill="#cfe4ff" opacity="0.12">${an('opacity', '0.06;0.2;0.08;0.16;0.06', 2.2)}</circle>`;
    const unit = (y, h, k) => `<rect x="2" y="${y}" width="50" height="${h}" rx="0.5" fill="#1a1c20" stroke="#000000" stroke-width="0.3"/><rect x="2" y="${y}" width="50" height="0.5" fill="#ffffff" opacity="0.1"/><circle cx="3.4" cy="${f1(y + 1.2)}" r="0.45" fill="#8a8f96"/><circle cx="50.6" cy="${f1(y + 1.2)}" r="0.45" fill="#8a8f96"/>`
      + (k === 0 ? `<rect x="8" y="${f1(y + 2)}" width="14" height="${f1(h - 4)}" rx="0.5" fill="#0a1a2a"/><text x="15" y="${f1(y + h / 2 + 0.8)}" text-anchor="middle" font-family="monospace" font-size="2.2" fill="#5fd0ff">48fps 4K</text>` + rep(6, i => `<circle cx="${f1(28 + i * 3)}" cy="${f1(y + h / 2)}" r="0.55" fill="${['#3fff8a', '#3fff8a', '#ffb43f', '#3fff8a', '#3fd0ff', '#ff4a4a'][i]}">${an('opacity', '1;0.3;1', 1 + i * 0.37, -i * 0.2)}</circle>`).join('')
        : rep(16, i => `<rect x="${f1(6 + i * 2.7)}" y="${f1(y + 1.5)}" width="1.4" height="${f1(h - 3)}" rx="0.5" fill="#000000" opacity="0.6"/>`).join(''));
    const rackF = unit(1.5, 8, 0) + unit(10.5, 8, 1) + unit(19.5, 6, 0) + unit(26.5, 6, 1);
    const headF = `<circle cx="20" cy="14" r="10.2" fill="#121316"/><circle cx="50" cy="14" r="10.2" fill="#121316"/><circle cx="20" cy="14" r="10.2" fill="none" stroke="#ffffff" stroke-opacity="0.2" stroke-width="0.35"/><circle cx="50" cy="14" r="10.2" fill="none" stroke="#ffffff" stroke-opacity="0.2" stroke-width="0.35"/>`
      + `<rect x="2" y="22.6" width="66" height="3.6" rx="0.6" fill="url(#m10perf)"/><text x="4" y="4.4" ${FONT} font-size="2.2" letter-spacing="0.8" fill="#d9dde2">CINEMAX</text><rect x="58" y="2" width="9" height="3.6" rx="0.6" fill="#c4262c"/><text x="62.5" y="4.8" text-anchor="middle" ${FONT} font-size="2.6" fill="#ffffff">3D</text>`;
    const headR = `<circle cx="20" cy="14" r="9.4" fill="#0d0e10"/><g transform="translate(20 14)"><g>${at('rotate', '0;360', 0.5)}${rep(7, i => `<path d="M0 0Q3.6 -2.6 2.4 -8.2L-1 -8Q0.8 -3.8 0 0Z" fill="#4a4e55" transform="rotate(${i * 51.4})"/>`).join('')}</g><circle r="2" fill="#2a2d32"/></g><circle cx="20" cy="14" r="9.4" fill="url(#m10perf)"/><circle cx="20" cy="14" r="9.4" fill="none" stroke="#5a5e65" stroke-width="0.6"/>`
      + `<rect x="36" y="5" width="20" height="9" rx="0.8" fill="#0a1626" stroke="#4a4e55" stroke-width="0.4"/><text x="46" y="9" text-anchor="middle" font-family="monospace" font-size="2.2" fill="#5fd0ff">3D ▶ READY</text><text x="46" y="12.2" text-anchor="middle" font-family="monospace" font-size="1.8" fill="#3fff8a">LAMP 98%</text>`
      + rep(8, i => `<rect x="${f1(36 + i * 2.5)}" y="17" width="1.3" height="7" rx="0.6" fill="#000000" opacity="0.55"/>`).join('');
    const headT = rep(10, i => `<path d="M4 ${f1(8 + i * 5)}H66" stroke="#000000" stroke-opacity="0.25" stroke-width="0.5"/>`).join('') + `<rect x="44" y="44" width="16" height="7" rx="0.6" fill="#f2c230"/><text x="52" y="48.6" text-anchor="middle" ${FONT} font-size="1.6" fill="#1a1a1a">⚠ HOT · UV</text>`;
    D.fx = ctx => { const C = cam(ctx); let s = shadow(C, 0, 0, 44, 38, 0.9);
      [[-28, -24], [28, -24], [-28, 24], [28, 24]].forEach(([x, z]) => s += box3(C, { c: [x, 3.5, z], w: 3.6, h: 3.6, d: 3.6, r: 0.4, col: '#3a3d42', olw: 0.25 }) + cyl3(C, [x - 1.4, 3.2, z], [x + 1.4, 3.2, z], 3.2, '#17171a', { mat: 'matte', olw: 0.3 }));
      s += box3(C, { c: [0, 7, 0], w: 64, h: 5, d: 58, r: 1, col: '#26282c', mat: 'brush', olw: 0.35 });
      s += box3(C, { c: [0, 12, -2], w: 54, h: 35, d: 48, r: 1, col: '#202226', mat: 'brush', dec: { f: rackF }, olw: 0.35 });
      s += box3(C, { c: [0, 47, 0], w: 70, h: 28, d: 62, r: 3, col: GR, gl: 0.4, mat: 'noise', dec: { f: headF, r: headR, l: headR, t: headT }, olc: '#0a0a0c', olw: 0.45, edge: 0.3 });
      [-15, 15].forEach(x => s += cyl3(C, [x, 61, 30.6], [x, 61, 37], 8.2, '#1c1d21', { mat: 'metal', olw: 0.35 }) + cyl3(C, [x, 61, 37], [x, 61, 38.4], 8.6, '#3a3d43', { mat: 'metal', olw: 0.3 }) + cyl3(C, [x, 61, 38.4], [x, 61, 41], 7.4, '#141517', { mat: 'gloss', cap: lens, olw: 0.35 }));
      s += box3(C, { c: [0, 55, 33], w: 9, h: 12, d: 5, r: 1, col: '#1b1c20', gl: 0.5, dec: { f: `<circle cx="4.5" cy="3.6" r="1.6" fill="#ff3b4a" opacity="0.85"/><circle cx="4.5" cy="8.2" r="1.6" fill="#3b7bff" opacity="0.85"/><circle cx="4" cy="3.1" r="0.5" fill="#ffffff" opacity="0.6"/><circle cx="4" cy="7.7" r="0.5" fill="#ffffff" opacity="0.6"/>` }, olw: 0.3 });
      [-18, 18].forEach(z => s += cyl3(C, [-22, 75, z], [-22, 79, z], 0.9, '#3a3d43', { mat: 'metal', olw: 0.25 }) + cyl3(C, [22, 75, z], [22, 79, z], 0.9, '#3a3d43', { mat: 'metal', olw: 0.25 }) + cyl3(C, [-22, 79, z], [22, 79, z], 1, '#4a4d53', { mat: 'metal', olw: 0.25 }));
      s += cyl3(C, [6, 75, -18], [6, 94, -18], 7, '#bfc4ca', { mat: 'metal', pat: 'm11rib', olw: 0.35 });
      const cb = [[-30, 52, -28], [-36, 40, -30], [-30, 26, -28], [-27, 18, -26]].map(q => C.p(...q)), cd = `M${P2(cb[0])}C${P2(cb[1])} ${P2(cb[2])} ${P2(cb[3])}`;
      s += `<path d="${cd}" stroke="#0e0f11" stroke-width="2.2" fill="none" stroke-linecap="round"/><path d="${cd}" stroke="#4a4d52" stroke-width="0.6" fill="none" transform="translate(-0.5 -0.3)"/>`;
      return { defs: DEF11, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-070 7.2.4 RECESSED ARCHITECTURAL TOWER ARRAY =======================
  N.tower11 = S => { const on = isPlay(S), D = { w: 124, d: 44, build: () => [] };
    const tF = baffle(16, 104, '#0f1012') + twt(8, 8.5, 2.6, 1) + woof(8, 19.5, 4.4, on, 0.05, 1) + [33, 46.5, 60, 73.5].map((y, i) => woof(8, y, 5.6, on, i * 0.06, 1)).join('') + `<rect x="5" y="86" width="6" height="1.6" rx="0.8" fill="#000000"/><rect x="5" y="91" width="6" height="1.6" rx="0.8" fill="#000000"/><rect x="4" y="98" width="8" height="2.4" rx="0.4" fill="#b9bec4"/><text x="8" y="99.8" text-anchor="middle" ${FONT} font-size="1.3" fill="#2a2c30" letter-spacing="0.4">ARRAY</text>`;
    const tS = `<rect x="0" y="0" width="1.4" height="104" fill="#c9ced3"/><rect x="18.6" y="0" width="1.4" height="104" fill="#c9ced3"/>`;
    const subF = baffle(24, 24, '#141518') + (on ? `<circle cx="12" cy="12" r="10.4" fill="none" stroke="#3fd0ff" stroke-width="0.4">${an('stroke-opacity', '0.9;0.3;0.9', 0.46)}</circle>` : '') + woof(12, 12, 9.4, on, 0, 1);
    const cF = baffle(50, 9, '#0f1012') + woof(7, 4.5, 3.4, on, 0.1, 1) + woof(15, 4.5, 3.4, on, 0.12, 1) + twt(25, 4.5, 2.2, 1) + woof(35, 4.5, 3.4, on, 0.14, 1) + woof(43, 4.5, 3.4, on, 0.16, 1);
    D.fx = ctx => { const C = cam(ctx), L = [];
      const glow = (x, z, rx, rz) => planeE(C, x, 0.06, z, rx, rz, 'url(#m11cy)', on ? 0.8 : 0.4, on ? an('opacity', '0.5;0.95;0.5', 0.46) : '');
      [-1, 1].forEach(sg => { const x = sg * 46, a = 0.34, ax = [[1, 0, 0], [0, Math.cos(a), Math.sin(a)], [0, -Math.sin(a), Math.cos(a)]];
        L.push({ q: [x, 50, 0], s: glow(x, 0, 18, 15) + shadow(C, x, 0, 13, 15, 0.8) + box3(C, { c: [x, 0, 0], w: 20, h: 3, d: 24, r: 1, col: '#b9bec4', mat: 'brush', gl: 0.8, olw: 0.3 })
          + box3(C, { c: [x, 3, 0], w: 16, h: 104, d: 20, r: 2.4, col: '#121316', gl: 0.95, dec: { f: tF, r: tS, l: tS }, olc: '#000000', olw: 0.45, edge: 0.3 })
          + box3(C, { c: [x, 106.4, -1.5], ax, w: 15, h: 6, d: 16, r: 2, col: '#141518', gl: 0.8, dec: { t: `<rect width="15" height="16" rx="2" fill="#0d0d0f"/>` + woof(7.5, 8, 5.2, on, 0.2, 1) }, olc: '#000000', olw: 0.4 }) }); });
      [-14, 14].forEach((x, i) => L.push({ q: [x, 12, -8], s: glow(x, -8, 15, 15) + shadow(C, x, -8, 14, 14, 0.8) + box3(C, { c: [x, 0, -8], w: 24, h: 24, d: 24, r: 1.6, col: '#141518', mat: 'noise', gl: 0.5, dec: { f: subF }, olc: '#000000', olw: 0.45 }) }));
      L.push({ q: [0, 28, -6], s: box3(C, { c: [0, 24, -6], w: 50, h: 9, d: 16, r: 1.6, col: '#121316', gl: 0.95, dec: { f: cF }, olc: '#000000', olw: 0.45 }) });
      return { defs: DEF11, front: zsort(C, L), bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-071 BUILT-IN MARBLE CONCESSION BAR & NACHO WARMER (tap: cheese pump + heat lamp) =======================
  N.conc11 = S => { const on = isPlay(S), W = 120, Dd = 40, Hc = 40, TY = Hc + 3.6;
    const D = { w: 134, d: 54, build: () => [] };
    const BH = Hc - 4, flute = rep(29, i => `<path d="M${f1(4 + i * 4)} 7V${BH - 3}" stroke="#000000" stroke-opacity="0.35" stroke-width="0.7"/><path d="M${f1(4.9 + i * 4)} 7V${BH - 3}" stroke="#ffd9a8" stroke-opacity="0.16" stroke-width="0.5"/>`).join('')
      + `<rect x="0" y="1.6" width="${W}" height="3.4" fill="#c99a44"/><rect x="0" y="1.6" width="${W}" height="1" fill="#fff0c0" opacity="0.4"/><text x="${W / 2}" y="4.25" text-anchor="middle" ${FONT} font-size="2.2" letter-spacing="2.4" fill="#3a2414">CONCESSIONS</text>`;
    const warmF = `<rect x="2" y="0.8" width="28" height="3.8" rx="0.8" fill="#c4262c"/><text x="16" y="3.7" text-anchor="middle" ${FONT} font-size="3" fill="#ffd34a" letter-spacing="1">NACHOS</text>`;
    const pumpAt = (C, p) => cyl3(C, [-8, TY + 17, -8], [-8, TY + 21 - p, -8], 0.9, '#d5d9dd', { mat: 'chrome', olw: 0.2 }) + box3(C, { c: [-8, TY + 21 - p, -6], w: 3.4, h: 2, d: 9, r: 0.8, col: '#1d1e21', gl: 0.5, olw: 0.25 });
    const glass = (C, x, z, col, seed) => { const R = rng(seed), b = byDepth(C, rep(36, () => { const a = R() * 2 * PI, d = Math.sqrt(R()) * 3.3; return [x + d * Math.cos(a), TY + 1 + R() * 7.5, z + d * Math.sin(a), R()]; }));
      return cyl3(C, [x, TY, z], [x, TY + 11, z], 4.2, '#e6f2f6', { op: 0.18, mat: 'gloss', noCap: 1, olc: '#8aa5b0', olw: 0.3, olo: 0.5 }) + b.map(q => { const c = C.P(q); return `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(C.k * 0.95)}" fill="${col[Math.floor(q[3] * col.length)]}"/><circle cx="${f1(c[0] - C.k * 0.3)}" cy="${f1(c[1] - C.k * 0.3)}" r="${f1(C.k * 0.3)}" fill="#ffffff" opacity="0.6"/>`; }).join('')
        + cyl3(C, [x, TY, z], [x, TY + 11, z], 4.2, '#e6f2f6', { op: 0.16, mat: 'gloss', noCap: 1, ol: 0 }) + `<g transform="${tanF(C, x, z, 4.25, C.thV - 0.6, TY + 10)}"><rect x="-0.4" width="0.8" height="8.5" rx="0.4" fill="#ffffff" opacity="0.5"/></g>`
        + cyl3(C, [x, TY + 11, z], [x, TY + 12.6, z], 4.4, '#d5d9dd', { mat: 'chrome', olw: 0.25 }) + sph(C, [x, TY + 13.4, z], 1, '#d5d9dd'); };
    D.fx = ctx => { const C = cam(ctx); let s = shadow(C, 0, 2, 70, 30, 0.85) + planeE(C, 0, 0.08, Dd / 2 + 6, 56, 7, 'url(#m11warm)', 0.5);
      s += box3(C, { c: [0, 0, 0], w: W - 2, h: 4, d: Dd - 2, r: 0.8, col: '#b88a3c', mat: 'brush', gl: 0.9, olw: 0.3 });
      s += box3(C, { c: [0, 4, 0], w: W, h: BH, d: Dd, r: 0.8, col: '#4a2c18', mat: 'wood', gl: 0.35, dec: { f: flute, r: rep(9, i => `<path d="M${f1(4 + i * 4)} 7V${BH - 3}" stroke="#000000" stroke-opacity="0.35" stroke-width="0.7"/>`).join(''), l: rep(9, i => `<path d="M${f1(4 + i * 4)} 7V${BH - 3}" stroke="#000000" stroke-opacity="0.35" stroke-width="0.7"/>`).join('') }, olc: '#1a0d04', olw: 0.45 });
      s += [-50, 0, 50].map(x => cyl3(C, [x, 8, Dd / 2], [x, 8, Dd / 2 + 4], 0.8, '#c9993f', { mat: 'metal', olw: 0.2 })).join('') + cyl3(C, [-57, 8, Dd / 2 + 4], [57, 8, Dd / 2 + 4], 1.3, '#d4a64a', { mat: 'metal', olw: 0.3 });
      s += box3(C, { c: [0, Hc, 1], w: W + 6, h: 3.6, d: Dd + 6, r: 1, col: '#f2efe9', mat: 'marb', gl: 0.5, edge: 0.6, olc: '#8f8a80', olw: 0.4 });
      const L = [];
      // nacho warmer
      { const G = glassBox(C, [-36, TY + 4, -4], 30, 17, 22); const lp = C.p(-36, TY + 18, -4);
        L.push({ q: [-36, TY + 10, -4], s: box3(C, { c: [-36, TY, -4], w: 32, h: 4, d: 24, r: 0.8, col: '#c9ced3', mat: 'brush', gl: 0.6, olw: 0.3 }) + G.back + chips(C, -36, -4, 12, 8.5, TY + 4.2, 7, 64, 'nacho')
          + `<ellipse cx="${f1(lp[0])}" cy="${f1(lp[1] + 5 * C.k)}" rx="${f1(16 * C.k)}" ry="${f1(9 * C.k)}" fill="url(#m11warm)" opacity="${on ? 0.85 : 0.45}">${on ? an('opacity', '0.65;1;0.7;0.95;0.65', 1.4) : ''}</ellipse>` + G.front
          + box3(C, { c: [-36, TY + 21, -4], w: 32, h: 5.4, d: 24, r: 0.8, col: '#c9ced3', mat: 'brush', gl: 0.6, dec: { f: warmF }, olw: 0.3 }) + (on ? mist(C, -36, TY + 26, -4, 3, 0.8) : '') }); }
      // cheese pump + tray
      { const cw = `<rect x="2.5" y="4" width="7" height="9" rx="1" fill="#2a2a2a"/><rect x="3" y="${on ? 7.8 : 6.6}" width="6" height="${on ? 4.8 : 6}" rx="0.8" fill="#f2a21c"/><rect x="3" y="${on ? 7.8 : 6.6}" width="2" height="${on ? 4.8 : 6}" fill="#ffffff" opacity="0.25"/><text x="6" y="2.8" text-anchor="middle" ${FONT} font-size="1.5" fill="#c4262c">CHEESE</text>`;
        L.push({ q: [-8, TY + 8, -8], s: box3(C, { c: [-8, TY, -8], w: 12, h: 17, d: 13, r: 1, col: '#d5d9dd', mat: 'brush', gl: 0.5, dec: { f: cw }, olw: 0.3 }) + (on ? cyl3(C, [-8, TY + 17, -8], [-8, TY + 19.2, -8], 0.9, '#d5d9dd', { mat: 'chrome', olw: 0.2 }) + slide(C, cyl3(C, [-8, TY + 19.2, -8], [-8, TY + 21, -8], 0.9, '#d5d9dd', { mat: 'chrome', olw: 0.2 }) + box3(C, { c: [-8, TY + 21, -6], w: 3.4, h: 2, d: 9, r: 0.8, col: '#1d1e21', gl: 0.5, olw: 0.25 }), [-8, TY + 21, -6], [[0, 0, 0], [0, -1.8, 0], [0, -1.8, 0], [0, 0, 0]], '0;0.3;0.62;1', 0.9) : pumpAt(C, 0))
          + cyl3(C, [-8, TY + 14, -1.6], [-8, TY + 14, 2.6], 0.85, '#d5d9dd', { mat: 'chrome', olw: 0.2 }) + cyl3(C, [-8, TY + 14, 2.6], [-8, TY + 12.4, 2.6], 0.7, '#d5d9dd', { mat: 'chrome', olw: 0.2 }) });
        const n0 = C.p(-8, TY + 12.4, 2.6), n1 = C.p(-8, TY + 2.8, 2.6);
        L.push({ q: [-8, TY + 2, 5], s: box3(C, { c: [-8, TY, 5], w: 13, h: 2.4, d: 8, r: 1, col: '#151517', gl: 0.4, hole: { t: 0.6 }, olw: 0.3 }) + chips(C, -8, 5, 5, 3, TY + 2.2, 1.6, 22, 'tray')
          + planeE(C, -8, TY + 3.4, 4.6, on ? 3.6 : 2, on ? 2.4 : 1.3, '#f5a41c', 0.95, on ? an('rx', '2;3.8;3.8', 3) + an('ry', '1.3;2.5;2.5', 3) : '')
          + (on ? `<path d="M${P2(n0)}L${P2(n1)}" stroke="#f5a41c" stroke-width="${f1(C.k * 0.9)}" stroke-linecap="round" stroke-dasharray="1.6 0.6">${an('stroke-dashoffset', '0;-4.4', 0.4)}</path>` + mist(C, -8, TY + 5, 5, 2, 0.5) : '') }); }
      // cup stacks + straws
      [[11, -13], [18, -13], [14.5, -6]].forEach(([x, z]) => L.push({ q: [x, TY + 6, z], s: cyl3(C, [x, TY, z], [x, TY + 12, z], 3.3, '#f4f2ec', { r2: 2.7, mat: 'gloss', pat: 'm11str', olw: 0.3 }) }));
      L.push({ q: [25, TY + 5, -5], s: rep(7, i => { const a = i * 0.9, p = C.p(25 + Math.cos(a) * 1.2, TY + 10, -5 + Math.sin(a) * 1.2), q = C.p(25 + Math.cos(a) * 2, TY + 15 + (i % 3), -5 + Math.sin(a) * 2); return `<path d="M${P2(p)}L${P2(q)}" stroke="${['#d8283c', '#ffffff', '#2f6fe0', '#f2c230'][i % 4]}" stroke-width="${f1(C.k * 0.5)}" stroke-linecap="round"/>`; }).join('') + cyl3(C, [25, TY, -5], [25, TY + 10, -5], 2.4, '#e6f2f6', { op: 0.3, mat: 'gloss', olw: 0.3 }) });
      // candy jars
      [[36, -11, ['#d8283c', '#f2c230', '#3fbf5a']], [47, -11, ['#ff7ac8', '#ffffff', '#8fd8ff']], [41.5, -2, ['#5a2a12', '#f5e6c8', '#c98a2a']]].forEach(([x, z, cl], i) => L.push({ q: [x, TY + 6, z], s: shadow(C, x, z, 5, 5, 0.5, TY + 0.05) + glass(C, x, z, cl, 'jar' + i) }));
      s += zsort(C, L);
      return { defs: DEF11, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= MOV-074 DUAL-ZONE UNDER-COUNTER WINE & SLUSHIE BAR (tap: open / close the glass doors) =======================
  N.wine11 = S => { const open = isPlay(S), W = 80, Hc = 42, Dd = 34, PL = 4, DT = 2.4, ZF = Dd / 2, ID = 2.2, DW = 38.8, DH = Hc - PL - 1, SS = '#c3c8cd';
    const D = { w: 92, d: 46, build: () => [] };
    const doorAt = (C, sg, th) => { const t = th * PI / 180, E = [-sg * Math.cos(t), 0, Math.sin(t)], Z = [sg * Math.sin(t), 0, Math.cos(t)], hg = [sg * W / 2, PL + 0.5, ZF];
      const L = (u, y, sd) => add(add(hg, mul(E, u)), add(mul(Z, sd), [0, y, 0]));
      let s = box3(C, { c: add(hg, add(mul(E, DW / 2), mul(Z, DT / 2))), ax: [E, [0, 1, 0], Z], w: DW, h: DH, d: DT, r: 0.8, col: SS, mat: 'brush', gl: 0.6, hole: { f: [3, 3, 3, 3], b: [3, 3, 3, 3] }, olw: 0.35 });
      s += pane(C, L(3, DH - 3, DT * 0.5), E, [0, -1, 0], DW - 6, DH - 6, { t: 0.26, tint: '#3c4a56', g: 0.8 });
      const a1 = L(DW - 3.4, 9, DT), a2 = L(DW - 3.4, 29, DT), b1 = L(DW - 3.4, 9, DT + 2), b2 = L(DW - 3.4, 29, DT + 2);
      s += cyl3(C, a1, b1, 0.6, '#d9dde0', { mat: 'chrome', olw: 0.2 }) + cyl3(C, a2, b2, 0.6, '#d9dde0', { mat: 'chrome', olw: 0.2 }) + cyl3(C, b1, b2, 0.85, '#e2e5e8', { mat: 'chrome', olw: 0.25 });
      return s; };
    const wineB = (C, x, y, z0, cap) => cyl3(C, [x, y, z0], [x, y, z0 + 16], 2.9, '#1f3a26', { mat: 'gloss', olw: 0.25 }) + cyl3(C, [x, y, z0 + 16], [x, y, z0 + 19], 2.9, '#1f3a26', { r2: 1.05, mat: 'gloss', noCap: 1, olw: 0.25 }) + cyl3(C, [x, y, z0 + 19], [x, y, z0 + 21.6], 1.15, cap, { mat: 'metal', olw: 0.2 });
    const wglass = (C, x, y, z, fill) => cyl3(C, [x, y, z], [x, y + 0.4, z], 2.2, '#e6f2f6', { op: 0.5, mat: 'gloss', olw: 0.2 }) + cyl3(C, [x, y + 0.4, z], [x, y + 5.2, z], 0.32, '#e6f2f6', { op: 0.6, mat: 'gloss', ol: 0 })
      + (fill ? cyl3(C, [x, y + 5.4, z], [x, y + 7.4, z], 1.5, '#6a0f1e', { r2: 2.05, mat: 'gloss', olw: 0.15, capCol: '#8a1626' }) : '') + cyl3(C, [x, y + 5.2, z], [x, y + 10.6, z], 1.5, '#e6f2f6', { r2: 2.7, op: 0.25, mat: 'gloss', noCap: 1, olc: '#9ab5c0', olw: 0.25, olo: 0.6 });
    const auger = (C, x, ph) => { const P = rep(40, i => { const z = -12 + i * 0.36, a = z * 1.1 + ph; return C.p(x + 3.2 * Math.cos(a), Hc + 18 + 3.2 * Math.sin(a), z); }); return `<path d="M${P.map(P2).join('L')}" stroke="#ffffff" stroke-opacity="0.6" stroke-width="${f1(C.k * 0.55)}" fill="none" stroke-linecap="round"/>`; };
    const augerA = (C, x, ph) => { const ds = rep(13, j => auger(C, x, ph + 2 * PI * j / 12).match(/d="([^"]+)"/)[1]); return `<path d="${ds[0]}" stroke="#ffffff" stroke-opacity="0.6" stroke-width="${f1(C.k * 0.55)}" fill="none" stroke-linecap="round"><animate attributeName="d" values="${ds.join(';')}" dur="0.8s" repeatCount="indefinite"/></path>`; };
    D.fx = ctx => { const C = cam(ctx); let s = shadow(C, 0, 0, 46, 24, 0.85);
      s += box3(C, { c: [0, 0, -1], w: W - 2, h: PL, d: Dd - 2, r: 0.5, col: '#111214', olw: 0.3 });
      const xl = -W / 2 + ID, yb = PL + ID, yt = Hc - ID, zi = -Dd / 2 + ID, IH = yt - yb, IDp = ZF - zi, IN = '#1b1e24';
      s += `<g transform="${FR(C, [xl, yt, zi], [1, 0, 0], [0, -1, 0])}"><rect width="${f1(W - 2 * ID)}" height="${f1(IH)}" fill="${IN}"/><rect width="${f1(W - 2 * ID)}" height="${f1(IH)}" fill="url(#m10in)"/><rect x="2" y="0.6" width="${f1(W - 2 * ID - 4)}" height="1" rx="0.5" fill="#7fd8ff" opacity="${open ? 1 : 0.8}"/><ellipse cx="${f1((W - 2 * ID) / 2)}" cy="2" rx="${f1(W * 0.45)}" ry="9" fill="#5fc8ff" opacity="0.14"/></g>`
        + `<g transform="${FR(C, [xl, yt, zi], [0, 0, 1], [0, -1, 0])}"><rect width="${f1(IDp)}" height="${f1(IH)}" fill="${shade(IN, 0.8)}"/></g><g transform="${FR(C, [xl, yb, zi], [1, 0, 0], [0, 0, 1])}"><rect width="${f1(W - 2 * ID)}" height="${f1(IDp)}" fill="${shade(IN, 1.2)}"/></g>`;
      const WB = [];
      [0, 1, 2, 3].forEach(r => { const y = yb + 1 + r * 9; WB.push({ q: [-20, y - 0.5, -2], s: box3(C, { c: [-20, y, -2], w: W / 2 - ID - 1.6, h: 0.9, d: IDp - 2, r: 0.3, col: '#d9b07a', mat: 'wood', olw: 0.2 }) });
        [-33, -25, -17, -9].forEach((x, j) => WB.push({ q: [x, y + 3.8, 2], s: wineB(C, x, y + 3.8, -12, (r + j) % 2 ? '#c9a24a' : '#7a1c2a') })); });
      s += zsort(C, WB);
      s += `<g transform="${FR(C, [ID + 1.2, yb + 18, zi], [1, 0, 0], [0, 0, 1])}"><rect width="${f1(W / 2 - 2 * ID - 1.2)}" height="${f1(IDp - 1)}" fill="#cfe6ee" opacity="0.4"/><path d="M0 ${f1(IDp - 1.2)}H${f1(W / 2 - 2 * ID - 1.2)}" stroke="#ffffff" stroke-opacity="0.7" stroke-width="0.6"/></g>`;
      [8, 15.5, 23, 30.5].forEach((x, i) => s += can3(C, x, yb, 2, 2.9, 8.5, [4, 2, 3, 5][i]));
      [10, 19, 28].forEach((x, i) => s += cyl3(C, [x, yb + 18, 2], [x, yb + 26, 2], 2.2, ['#ff8a2a', '#7ed04a', '#ff4f8a'][i], { mat: 'gloss', op: 0.85, olw: 0.25 }) + cyl3(C, [x, yb + 26, 2], [x, yb + 29, 2], 2.2, '#e8eef2', { r2: 0.9, mat: 'gloss', op: 0.6, noCap: 1, olw: 0.2 }) + cyl3(C, [x, yb + 29, 2], [x, yb + 30.4, 2], 1, '#2a2c30', { mat: 'matte', olw: 0.2 }));
      if (open) s += `<g transform="${FR(C, [xl, yt, ZF], [1, 0, 0], [0, -1, 0])}"><rect width="${f1(W - 2 * ID)}" height="${f1(IH)}" fill="url(#m10cold)">${an('opacity', '0.6;0.85;0.6', 3)}</rect></g>` + mist(C, -18, PL + 8, ZF + 2, 3, 0.8) + mist(C, 18, PL + 8, ZF + 2, 3, 0.8);
      s += box3(C, { c: [0, PL, 0], w: W, h: Hc - PL, d: Dd, r: 1, col: '#2a2d32', mat: 'brush', gl: 0.3, hole: { f: [ID, ID, ID, ID] }, olw: 0.4 });
      s += box3(C, { c: [0, PL, ZF - 1], w: 2.4, h: Hc - PL, d: 2, r: 0.3, col: '#2a2d32', mat: 'brush', olw: 0.25 });
      if (!open) s += doorAt(C, -1, 0) + doorAt(C, 1, 0); else { const A = easeA(100, 9); s += flip(A.map((a, i) => ({ i, s: doorAt(C, -1, a) + doorAt(C, 1, a) })), A.length, 0.7); }
      s += box3(C, { c: [0, Hc, 1], w: W + 4, h: 3, d: Dd + 4, r: 0.8, col: '#dcdad5', mat: 'qz', gl: 0.45, edge: 0.6, olc: '#7a7873', olw: 0.35 });
      const T = Hc + 3, L = [];
      L.push({ q: [-30, T + 8, -6], s: shadow(C, -30, -6, 4, 4, 0.5, T + 0.05) + cyl3(C, [-30, T, -6], [-30, T + 12, -6], 3, '#1f3a26', { mat: 'gloss', olw: 0.3 }) + cyl3(C, [-30, T + 12, -6], [-30, T + 15, -6], 3, '#1f3a26', { r2: 1.1, mat: 'gloss', noCap: 1, olw: 0.25 }) + cyl3(C, [-30, T + 15, -6], [-30, T + 19, -6], 1.1, '#7a1c2a', { mat: 'metal', olw: 0.2 })
        + `<g transform="${tanF(C, -30, -6, 3.02, C.thV, T + 9)}"><rect x="-2.2" width="4.4" height="5" rx="0.4" fill="#f3ead6"/><text y="2.6" text-anchor="middle" font-family="Georgia,serif" font-size="1.3" fill="#5a1a1a">Rouge</text><path d="M-1.5 3.6h3" stroke="#b8913f" stroke-width="0.3"/></g>` });
      L.push({ q: [-21, T + 5, 3], s: wglass(C, -21, T, 3, 1) }, { q: [-14, T + 5, -3], s: wglass(C, -14, T, -3, 1) });
      const tank = (x, col, ph) => box3(C, { c: [x, T + 9, -5], w: 11.4, h: 13, d: 16, r: 3, col, gl: 0.6, olw: 0.25, olc: shade(col, 0.5) }) + augerA(C, x, ph)
        + box3(C, { c: [x, T + 8, -5], w: 13, h: 19, d: 18, r: 4, col: '#eef6fa', op: 0.24, gl: 1, edge: 0.8, olc: '#8aa5b0', olw: 0.3, olo: 0.6 }) + box3(C, { c: [x, T + 27, -5], w: 13.6, h: 3.4, d: 18.6, r: 4, col: '#f4f5f6', gl: 0.5, olw: 0.3 })
        + box3(C, { c: [x, T + 3.2, 7.4], w: 2.6, h: 4, d: 1.8, r: 0.6, col, gl: 0.6, olw: 0.2 }) + cyl3(C, [x, T + 3, 6.2], [x, T + 1.6, 6.2], 0.7, '#2a2c30', { mat: 'matte', olw: 0.2 });
      L.push({ q: [18, T + 10, -4], s: shadow(C, 18, -2, 18, 14, 0.6, T + 0.05) + box3(C, { c: [18, T, -4], w: 30, h: 8, d: 22, r: 1.2, col: '#d0d4d8', mat: 'brush', gl: 0.6, dec: { f: `<text x="7.5" y="6" text-anchor="middle" ${FONT} font-size="1.6" fill="#c4262c">CHERRY</text><text x="22.5" y="6" text-anchor="middle" ${FONT} font-size="1.6" fill="#2f6fe0">BLUE RAZZ</text>` }, olw: 0.3 })
        + box3(C, { c: [18, T, 9.4], w: 26, h: 1.6, d: 5, r: 0.6, col: '#3a3c40', olw: 0.25, dec: { t: rep(9, i => `<path d="M${f1(2 + i * 2.75)} 0.8V4.2" stroke="#1a1b1d" stroke-width="0.6"/>`).join('') } }) + tank(10.5, '#d8283c', 0) + tank(25.5, '#2f7ff0', 0.8) });
      s += zsort(C, L);
      return { defs: DEF11, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= MOV-091 AUTOMATED AI GOURMET CINEMA CHEF & CANDY DISPENSARY (tap: the robot makes a snack) =======================
  N.chef11 = S => { const on = isPlay(S), W = 100, Hb = 40, Dd = 46, TY = Hb + 3;
    const D = { w: 112, d: 58, build: () => [] };
    const scr = on ? `<text x="50" y="12.4" text-anchor="middle" ${FONT} font-size="2.6" fill="#8ff6ff">Preparing your snack…</text><rect x="36" y="15.6" width="28" height="1.6" rx="0.8" fill="#1d3a48"/><rect x="36" y="15.6" width="28" height="1.6" rx="0.8" fill="#5ff0ff">${an('width', '0;28', 4.8)}</rect>`
      : `<text x="50" y="12.6" text-anchor="middle" ${FONT} font-size="3.6" letter-spacing="1.2" fill="#8ff6ff">AI CHEF</text><text x="50" y="17" text-anchor="middle" ${FONT} font-size="1.8" fill="#bfefff">Tap to order</text>`;
    const baseF = `<defs><linearGradient id="ch11s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#16202c"/><stop offset="1" stop-color="#05070a"/></linearGradient></defs><rect x="32" y="5.4" width="36" height="19" rx="2" fill="url(#ch11s)" stroke="#c9d3dc" stroke-width="0.5"/>${scr}`
      + [['#ff7ac8', 38], ['#f2c230', 46], ['#5ff0ff', 54], ['#9b7bff', 62]].map(([c, x]) => `<circle cx="${x}" cy="21.4" r="1.3" fill="${c}" opacity="0.85"/>`).join('') + `<path d="M34 6.4H66" stroke="#ffffff" stroke-opacity="0.18" stroke-width="0.4"/>`
      + `<rect x="7" y="8" width="18" height="15" rx="2" fill="#0d1218"/><rect x="7" y="8" width="18" height="15" rx="2" fill="none" stroke="#5ff0ff" stroke-opacity="0.7" stroke-width="0.5"/><text x="16" y="27" text-anchor="middle" ${FONT} font-size="1.6" letter-spacing="0.6" fill="#7d8b98">PICK UP</text>`
      + `<path d="M3 1.4H${W - 3}" stroke="#5ff0ff" stroke-width="0.9" stroke-linecap="round"${on ? ' stroke-dasharray="4 3"' : ''}>${on ? an('stroke-dashoffset', '0;-14', 0.8) : ''}</path><rect x="0" y="${Hb - 3}" width="${W}" height="3" fill="#000000" opacity="0.08"/>`
      + rep(6, i => `<rect x="${f1(76 + i * 3)}" y="10" width="1.4" height="12" rx="0.7" fill="#000000" opacity="0.12"/>`).join('');
    const backF = `<rect x="4" y="4" width="92" height="46" rx="2" fill="#0e131a"/><rect x="4" y="4" width="92" height="46" rx="2" fill="url(#m10v)"/><text x="72" y="12" text-anchor="middle" ${FONT} font-size="4" letter-spacing="1.6" fill="#ff7ac8" opacity="0.95">CANDY LAB</text><text x="72" y="12" text-anchor="middle" ${FONT} font-size="4" letter-spacing="1.6" fill="#ff7ac8" opacity="0.35" filter="url(#m10b1)">CANDY LAB</text>`
      + rep(8, i => `<path d="M4 ${f1(16 + i * 4.4)}H96" stroke="#5ff0ff" stroke-opacity="0.05" stroke-width="0.3"/>`).join('');
    const tube = (C, x, z, cl, seed) => { const R = rng(seed), y0 = TY + 20, y1 = TY + 50, b = byDepth(C, rep(64, () => { const a = R() * 2 * PI, d = Math.sqrt(R()) * 3.4; return [x + d * Math.cos(a), y0 + 0.8 + R() * (y1 - y0 - 6), z + d * Math.sin(a), R()]; }));
      return cyl3(C, [x, y0, z], [x, y1, z], 4.2, '#e6f2f6', { op: 0.16, mat: 'gloss', noCap: 1, ol: 0 }) + b.map(q => { const c = C.P(q); return `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(C.k * 1.05)}" fill="${cl[Math.floor(q[3] * cl.length)]}"/><circle cx="${f1(c[0] - C.k * 0.32)}" cy="${f1(c[1] - C.k * 0.34)}" r="${f1(C.k * 0.32)}" fill="#ffffff" opacity="0.65"/>`; }).join('')
        + cyl3(C, [x, y0, z], [x, y1, z], 4.2, '#e6f2f6', { op: 0.14, mat: 'gloss', noCap: 1, olc: '#9ab5c0', olw: 0.3, olo: 0.5 }) + `<g transform="${tanF(C, x, z, 4.25, C.thV - 0.6, y1 - 1)}"><rect x="-0.4" width="0.8" height="26" rx="0.4" fill="#ffffff" opacity="0.5"/></g>`
        + cyl3(C, [x, y1, z], [x, y1 + 2, z], 4.6, '#dfe5ea', { mat: 'chrome', olw: 0.25 }) + cyl3(C, [x, y0 - 1.6, z], [x, y0, z], 4.6, '#dfe5ea', { mat: 'chrome', olw: 0.25 }) + cyl3(C, [x, y0 - 1.6, z], [x, TY + 15, z], 2.4, '#dfe5ea', { r2: 1.1, mat: 'chrome', olw: 0.25 }); };
    const arm = (C, ps, al, be, hold) => { const B = [4, TY + 8, 2], dir = a => [Math.sin(a) * Math.sin(ps), Math.cos(a), Math.sin(a) * Math.cos(ps)], P1 = add(B, mul(dir(al), 18)), P2v = add(P1, mul(dir(al + be), 16)), P3 = add(P2v, [0, -3, 0]);
      let s = cyl3(C, B, P1, 3.2, '#f4f6f8', { mat: 'gloss', olw: 0.3 }) + sph(C, P1, 3.8, '#b7c0ca') + cyl3(C, P1, P2v, 2.6, '#f4f6f8', { mat: 'gloss', olw: 0.3 }) + sph(C, P2v, 2.8, '#b7c0ca') + cyl3(C, P2v, P3, 1.2, '#8f99a3', { mat: 'metal', olw: 0.25 });
      if (hold) s += cyl3(C, add(P3, [0, -9, 0]), add(P3, [0, -1.6, 0]), 2.6, '#f4f2ec', { r2: 3.5, mat: 'gloss', pat: 'm11str', olw: 0.3 }) + heap(C, P3[0], P3[2], 2.6, 2.6, P3[1] - 2, 2, 9, 'bk', 0.85);
      return s + [-1, 1].map(sg => cyl3(C, P3, add(P3, [sg * 1.6 * Math.cos(ps), -2.6, -sg * 1.6 * Math.sin(ps)]), 0.5, '#5a646e', { mat: 'metal', ol: 0 })).join(''); };
    const KP = [[0.25, 0.5, 1.5, 0], [-1.75, 1.15, 0.65, 0], [-1.75, 1.05, 0.75, 0], [-0.4, 0.75, 1.1, 0], [1.75, 1.0, 0.7, 0], [1.75, 1.0, 0.75, 1], [0.6, 0.85, 0.9, 1], [0.25, 0.95, 0.75, 1], [0.25, 0.5, 1.5, 0]];
    D.fx = ctx => { const C = cam(ctx); let s = shadow(C, 0, 0, 58, 32, 0.85) + planeE(C, 0, 0.06, 0, 56, 30, 'url(#m11cy)', on ? 0.6 : 0.35, on ? an('opacity', '0.4;0.7;0.4', 2) : '');
      s += box3(C, { c: [0, 0, 0], w: W, h: Hb, d: Dd, r: 5, col: '#f3f5f7', gl: 0.8, dec: { f: baseF }, olw: 0.4, olo: 0.5 });
      s += box3(C, { c: [0, Hb, 1], w: W + 4, h: 3, d: Dd + 4, r: 5.5, col: '#e3e8ed', gl: 0.9, dec: { f: `<path d="M5 2.2H${W - 1}" stroke="#5ff0ff" stroke-width="0.6" stroke-opacity="0.8"/>` }, olw: 0.35, olo: 0.5 });
      s += box3(C, { c: [0, TY, -Dd / 2 + 4], w: W, h: 54, d: 8, r: 3, col: '#f3f5f7', gl: 0.7, dec: { f: backF }, olw: 0.35, olo: 0.5 });
      const L = [];
      [[-42, ['#ff5a8a', '#ff9ac0', '#ffffff']], [-31, ['#f2c230', '#ff8a2a', '#ffe9a0']], [-20, ['#5ff0ff', '#9b7bff', '#7ed04a']]].forEach(([x, cl], i) => L.push({ q: [x, TY + 30, -12], s: tube(C, x, -12, cl, 'tb' + i) }));
      L.push({ q: [-31, TY + 3, -12], s: cyl3(C, [-31, TY, -12], [-31, TY + 7, -12], 2.4, '#f4f2ec', { r2: 3.2, mat: 'gloss', pat: 'm11str', olw: 0.3 }) + (on ? rep(4, i => { const a = C.p(-31, TY + 14.6, -12), b = C.p(-31, TY + 6.5, -12), c = ['#ff5a8a', '#f2c230', '#5ff0ff', '#7ed04a'][i];
        return `<circle r="${f1(C.k * 0.9)}" fill="${c}" opacity="0"><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;0.1;0.9;1" dur="0.6s" begin="${n4(-i * 0.15)}s" repeatCount="indefinite"/><animateMotion dur="0.6s" begin="${n4(-i * 0.15)}s" repeatCount="indefinite" path="M${P2(a)}L${P2(b)}"/></circle>`; }).join('') : '') });
      { const ring = (y, r) => rep(24, i => { const t = i / 24 * 2 * PI; return C.p(36 + r * Math.cos(t), y, -6 + r * Math.sin(t)); });
        const dome = hull([].concat(ring(TY + 5, 9.4), ...[0.3, 0.6, 0.85, 1].map(k => ring(TY + 13 + 9.4 * Math.sin(k * PI / 2), 9.4 * Math.cos(k * PI / 2 * 0.98)))));
        L.push({ q: [36, TY + 8, -6], s: cyl3(C, [36, TY, -6], [36, TY + 5, -6], 10, '#dfe5ea', { mat: 'chrome', olw: 0.3 }) + heap(C, 36, -6, 7.4, 7.4, TY + 5, 7, 46, 'dome', 1) + `<path d="${pth(dome)}" fill="#e6f2f6" opacity="0.16" stroke="#9ab5c0" stroke-opacity="0.55" stroke-width="0.35"/><path d="${pth(dome)}" fill="url(#m11gl)" opacity="0.8"/>` + sph(C, [36, TY + 23.4, -6], 1.4, '#dfe5ea') }); }
      L.push({ q: [4, TY + 2, 2], s: cyl3(C, [4, TY, 2], [4, TY + 3, 2], 6.4, '#dfe4ea', { mat: 'gloss', olw: 0.3 }) + cyl3(C, [4, TY + 3, 2], [4, TY + 8, 2], 4.2, '#f4f6f8', { mat: 'gloss', olw: 0.3 }) + planeE(C, 4, TY + 3.1, 2, 5.4, 5.4, 'none', 1).replace('fill="none"', 'fill="none" stroke="#5ff0ff" stroke-width="0.5"') + sph(C, [4, TY + 8, 2], 3.6, '#c9d0d8') });
      const fr = []; if (on) { for (let i = 0; i < KP.length - 1; i++) for (let k = 0; k < 4; k++) { const a = KP[i], b = KP[i + 1], t = k / 4; fr.push(arm(C, a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, k ? b[3] && a[3] : a[3])); } }
      L.push({ q: [4, TY + 10, 4], s: on ? loopF(fr, 6.4) : arm(C, KP[0][0], KP[0][1], KP[0][2], 0) });
      s += zsort(C, L);
      return { defs: DEF11, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= MOV-094 SELF-FILLING MOLECULAR MOCKTAIL & SODA FOUNTAIN (tap: dome opens, glass fills) =======================
  N.mock11 = S => { const open = isPlay(S), D = { w: 64, d: 64, build: () => [] }, Y = 35, RD0 = 19.5;
    const SC = [['#ff4fa0', '#ffd0e6'], ['#9bff4a', '#eaffd0'], ['#3fb6ff', '#d6f2ff']];
    D.fx = ctx => { const C = cam(ctx), th = C.thV; let s = planeE(C, 0, 0.06, 0, 34, 34, 'url(#m11cy)', 0.55, an('opacity', '0.4;0.65;0.4', 3)) + shadow(C, 0, 0, 28, 28, 0.7);
      const defs = SC.map(([a, b], i) => `<radialGradient id="mk11g${i}" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="${b}"/><stop offset="0.35" stop-color="${a}"/><stop offset="1" stop-color="${shade(a, 0.45)}"/></radialGradient>`).join('');
      s += cyl3(C, [0, 0, 0], [0, 32, 0], 24, '#f2f4f7', { r2: 20, mat: 'gloss', noCap: 1, olw: 0.4, olo: 0.5 }) + cyl3(C, [0, 27.5, 0], [0, 29.2, 0], 20.9, '#5ff0ff', { mat: 'gloss', noCap: 1, ol: 0, f: 1.2 });
      { const c = C.p(0, 28.3, 0); s += `<ellipse cx="${f1(c[0])}" cy="${f1(c[1])}" rx="${f1(24 * C.k)}" ry="${f1(9 * C.k)}" fill="url(#m11cy)" opacity="0.5">${an('opacity', '0.3;0.6;0.3', 2.4)}</ellipse>`; }
      s += cyl3(C, [0, 32, 0], [0, Y, 0], 21.5, '#d9dee3', { mat: 'chrome', olw: 0.35, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="none" stroke="#9aa3ab" stroke-width="0.5"/>` + rep(12, i => `<path d="M${f1(cr * 0.2 * Math.cos(i * PI / 6))} ${f1(cr * 0.2 * Math.sin(i * PI / 6))}L${f1(cr * 0.5 * Math.cos(i * PI / 6))} ${f1(cr * 0.5 * Math.sin(i * PI / 6))}" stroke="#aab2ba" stroke-width="0.6"/>`).join('') });
      [-0.6, 0, 0.6].forEach((da, i) => { const a = th + da, o = [20 * Math.sin(a), 31, 20 * Math.cos(a)], e = [25 * Math.sin(a), 31, 25 * Math.cos(a)];
        s += cyl3(C, o, e, 1, '#d9dee3', { mat: 'chrome', olw: 0.25 }) + cyl3(C, e, add(e, [0, -3, 0]), 0.75, '#d9dee3', { mat: 'chrome', olw: 0.2 }) + sph(C, add(o, [0, 2.6, 0]), 1.3, SC[i][0]); });
      s += cyl3(C, [0, Y, 0], [0, Y + 4, 0], 3, '#d9dee3', { mat: 'chrome', olw: 0.25 });
      const gl0 = Y + 4.6, liq = L => cyl3(C, [0, gl0, 0], [0, gl0 + L, 0], 3.1, '#ff4fa0', { r2: 3.1 + L * 0.05, mat: 'gloss', op: 0.88, olw: 0.2, capCol: '#ff86c0' });
      s += cyl3(C, [0, Y + 4, 0], [0, Y + 4.6, 0], 3.6, '#e6f2f6', { op: 0.5, mat: 'gloss', olw: 0.2 });
      if (open) { const LV = rep(10, i => 5 + i); s += flip(LV.map((l, i) => ({ i, s: liq(l) })), LV.length, 2.4);
        const g0 = C.p(0, gl0 + 1, 0); s += rep(6, i => `<circle r="${f1(C.k * 0.35)}" fill="#ffffff" opacity="0"><animate attributeName="opacity" values="0;0.8;0" dur="1.4s" begin="${n4(-i * 0.23)}s" repeatCount="indefinite"/><animateMotion dur="1.4s" begin="${n4(-i * 0.23)}s" repeatCount="indefinite" path="M${f1(g0[0] + (i % 3 - 1) * C.k * 1.4)} ${f1(g0[1])}v${f1(-11 * C.k)}"/></circle>`).join('');
      } else s += liq(4);
      s += cyl3(C, [0, Y + 4.6, 0], [0, Y + 20, 0], 3.5, '#e6f2f6', { r2: 4.3, op: 0.22, mat: 'gloss', noCap: 1, olc: '#9ab5c0', olw: 0.25, olo: 0.6 });
      const oy = open ? 58 : 52, orb = rep(32, i => { const t = i / 32 * 2 * PI; return C.p(11 * Math.cos(t), oy + 1.6 * Math.sin(t * 2), 11 * Math.sin(t)); }), op = 'M' + orb.map(P2).join('L') + 'Z';
      s += SC.map((c, i) => `<circle r="${f1(C.k * 2.7)}" fill="url(#mk11g${i})"><animateMotion dur="${open ? 2.4 : 6}s" begin="${n4(-i * (open ? 0.8 : 2))}s" repeatCount="indefinite" path="${op}"/></circle>`).join('');
      if (open) { const g = C.p(0, gl0 + 15, 0); s += rep(6, i => { const st = C.p(11 * Math.cos(i), oy, 11 * Math.sin(i)); return `<circle r="${f1(C.k * 0.9)}" fill="url(#mk11g${i % 3})" opacity="0"><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;0.1;0.85;1" dur="1.2s" begin="${n4(-i * 0.2)}s" repeatCount="indefinite"/><animateMotion dur="1.2s" begin="${n4(-i * 0.2)}s" repeatCount="indefinite" path="M${P2(st)}Q${f1((st[0] + g[0]) / 2)} ${f1(st[1] - 6)} ${P2(g)}"/></circle>`; }).join(''); }
      const dome = dy => { const ring = (y, r) => rep(28, i => { const t = i / 28 * 2 * PI; return C.p(r * Math.cos(t), y, r * Math.sin(t)); }), y0 = Y + dy, y1 = Y + 26 + dy;
        const P = hull([].concat(ring(y0, RD0), ring(y1, RD0), ...[0.25, 0.5, 0.72, 0.9, 1].map(k => ring(y1 + RD0 * 0.8 * Math.sin(k * PI / 2), RD0 * Math.cos(k * PI / 2 * 0.97)))));
        return `<path d="${pth(P)}" fill="#dff4ff" opacity="0.15"/><path d="${pth(P)}" fill="url(#m11gl)" opacity="0.75"/><path d="${pth(P)}" fill="none" stroke="#9ab5c0" stroke-opacity="0.6" stroke-width="0.35"/>`
          + `<g transform="${tanF(C, 0, 0, RD0 + 0.05, th - 0.7, y1 + 4)}"><rect x="-0.6" width="1.2" height="26" rx="0.6" fill="#ffffff" opacity="0.45"/></g>` + band(C, [0, 0, 0], y0, y0 + 2, RD0 + 0.4, '#d9dee3', 'chrome') + sph(C, [0, y1 + RD0 * 0.8 + 1.4, 0], 1.6, '#d9dee3'); };
      if (!open) s += dome(0); else { s += slide(C, dome(0), [0, Y, 0], [[0, 0, 0], [0, 26, 0]], '0;1', 0.9, { once: 1 }); }
      ext(C, [[0, Y + 26 + 26 + RD0, 0]]);
      return { defs: DEF11 + defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ---------- catalog edits ----------
  RD.SET11 = {
    'MOV-042': { spec: 'qled11', note: 'A razor-thin 85-inch QLED with a brushed-metal edge and a deep black glass screen that mirrors the room. An ambient backlight glows on the wall behind it, slowly drifting through blue, violet, pink, amber and teal.' },
    'MOV-046': { spec: 'ust11', note: 'A satin-white ultra-short-throw laser projector that sits right under the screen: charcoal fabric speaker front, glossy laser window on top with a soft light inside, touch buttons, a breathing status light and its remote beside it.' },
    'MOV-050': { spec: 'spk11', note: 'A walnut 5.1 kit: two bookshelf speakers on steel stands, two surround speakers on taller stands, a centre speaker and a black 10-inch subwoofer. Every driver has a real cone, surround and dust cap. Tap it to play music: all the cones pump to the beat.' },
    'MOV-051': SHOW('Start the kettle', 'Stop the kettle', 'Kettle stirring · corn popping… tap to stop', 'Tap to pop kettle corn', 'A glossy red kettle-corn cart with spoked wagon wheels, a push handle, pinstriped panels, a striped awning and a glass cabinet piled with popcorn. Tap it: the heat lamp glows, the steel kettle rocks and popcorn flies out into the cabinet.', { spec: 'kcart11', sx: {} }),
    'MOV-054': Object.assign({ spec: 'cola11' }, OPEN('door', 'Door open · ice cold · tap to close', 'A glossy red retro mini-fridge on chrome legs with an "Ice Cold COLA" door, a chrome-framed glass window and a chrome bar handle. Inside you can see glass cola bottles on wire shelves and cans below. Tap it: the door swings open and cold mist rolls out. Tap again to close it.')),
    'MOV-066': { spec: 'rig11', note: 'A commercial dual-lens 3D cinema projector on a rolling rack: graphite head with two big coated lenses and a red/blue 3D modulator between them, a spinning cooling fan behind the side grille, a status screen, a ribbed exhaust duct, carry rails and a rack of blinking media servers below.' },
    'MOV-070': { spec: 'tower11', note: 'Two piano-black tower speakers on brushed plinths with gold-ringed tweeters, copper cones and angled up-firing Atmos modules on top, two subwoofers and a wide centre speaker on top of them, plus a cyan floor glow. Tap it to play music: cones pump and the glow pulses.' },
    'MOV-071': SHOW('Serve nachos', 'Stop serving', 'Heat lamp on · cheese pumping… tap to stop', 'Tap to serve nachos', 'A built-in concession bar: fluted walnut front, brass CONCESSIONS band, brass footrail and kick plate, a veined white marble top, a glass nacho warmer, a cheese pump over a tray of chips, striped cup stacks, straws and three candy jars. Tap it: the heat lamp glows, the pump presses and hot cheese pours onto the nachos.', { spec: 'conc11', sx: {} }),
    'MOV-074': Object.assign({ spec: 'wine11' }, OPEN('doors', 'Doors open · cold air rolling… tap to close', 'An under-counter bar with a speckled quartz top: wine bottles on beech racks behind the left smoked-glass door, cans and juice bottles behind the right one, and a two-tank cherry / blue-razz slushie machine on top with augers always churning. Tap it: both doors swing open. Tap again to close them.')),
    'MOV-091': SHOW('Order a snack', 'Stop the chef', 'Robot chef at work… tap to stop', 'Tap to order a snack', 'A glossy white AI snack kiosk: three candy tubes, a popcorn dome, a pick-up window, a touch screen and a white robot arm with a gripper. Tap it: candy drops into the cup, the arm swings round, scoops a striped bucket of popcorn and serves it, and the screen shows the progress.', { spec: 'chef11', live: 'Tap to order' }),
    'MOV-094': Object.assign({ spec: 'mock11' }, OPEN('dome', 'Dome open · glass filling… tap to close', 'A white pedestal fountain with a cyan glow ring and three chrome taps under a glass dome. Inside, three flavour spheres float in orbit around a tall glass. Tap it: the dome rises, the spheres speed up, pearls drop into the glass and it fills with fizzy pink mocktail. Tap again to close it.')),
    'MOV-102': SHOW('Start the carriage', 'Stop the carriage', 'Bulbs chasing · kettle popping… tap to stop', 'Tap to start the carriage', 'A gilded royal popcorn carriage: burgundy panels with gold scrollwork and crowns, gold spoked wheels, twisted gold columns, a marquee roof and sign ringed with bulbs and a velvet crown on top. Tap it: the bulbs chase, the copper kettle rocks and popcorn bursts out.', { spec: 'rcart11', sx: {} }),
  };
  const edit10 = RD.edit;
  RD.edit = rows => edit10(rows).map(r => RD.SET11[r.id] ? Object.assign({}, r, RD.SET11[r.id]) : r);
  RD.H11 = { DEF11, ext, zsort, loopF, pane, glassBox, woof, twt, baffle, heap, chips, planeE, OPEN, SHOW };
  RD.PLUS11 = 1;
})();
