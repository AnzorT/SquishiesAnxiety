# Kitchen realism pass: Furniture (new chat brief)

Paste the "First message" at the bottom into a new chat. CLAUDE.md (project root) has the full history. Read its **"Sofa / multi-seat spin fix"** section and the **Kitchen electronics** progress line first.

## Where we are
- Kitchen floors, ceilings (incl. the 5 range hoods 009/029/049/069/089), island lights, walls, backsplash, windows, wall storage, wall accents: **done** (`reno-plus27.js`).
- Kitchen **Electronics (all 25): done and approved** (`reno-plus28.js`, `?v=14`): fridges, ranges, dishwashers, coffee makers, prep gadgets.
- **Next: Kitchen Furniture (47 pieces)**, 3 per batch.

## Rules (from the user, apply every time)
1. **Real 3D, round shading, rich detail, creature scale.** A creature is about 78 units tall, so compare on a sheet with one.
2. **Luxury = materials + warm light.** Tier 4–5 get marble, polished brass, gold, walnut, mirror shine and champagne/amber glow, not cyan sci-fi strips, unless the name asks for tech. The user rejected a "techy" look before.
3. **Low tiers look cheap and worn**: dents, chips, grime, rust, peeling, stickers, tape, water stains.
4. **Every piece is alive with subtle looping animation** (drips, steam, sway, flicker, turning parts, a fly, a towel swaying), never flashy. If the user calls something flashy, remove it.
5. **Nothing vanishes or overlaps when rotated.** Check at 45/90/135/225/270/315 by eye. Seats also need **nf = 0 at every 5°** (see the sofa section in CLAUDE.md).
6. **Don't move seats** (`{x, z, h}`); creatures sit there. Try every seat with a creature sitting on it.
7. Keep each piece's mount / size / kind / tap behaviour so saved houses keep working. Only enlarge when the piece is clearly too small, and say so.
8. One-off features appear once (no repeating tiles multiplying a sign or screen).
9. Timelines start on the "finished" frame so stills and thumbnails look complete.
10. **3 pieces per batch. Fix first, then show.** If the user says "do them all, report when done", do the whole section, then report once.

## How to build (what worked for electronics, in `reno-plus28.js`)
- Add new builds to `reno-plus28.js` above `// ---------- catalog edits ----------`, and register them in `RD.SET28 = { 'KIT-0xx': { spec: 'name28', live: '…', note: '…' } }`. Keep the existing `kind` / `cp` / seats when a piece has them.
- **fx-only build**: `N.x28 = S => { const D = { w, d, build: () => [] }; D.fx = ctx => { const C = cam(ctx) … return { defs, front: s, bb: C.bb(6) }; }; return D; }`. Use H10 `box3` / `cyl3` / `sph` / `shadow` / `mist`, and `PLN` for flat decals in a plane, `tanF` for decals on cylinders, and `sym` / `use` for face decals in `defs`.
- **Draw order is everything.** Use `vis(C, normal)` to decide which face looks at you: draw front parts after the body when the front faces you, before it otherwise. Sort loose items with `vsort(C, [{ q, s }])`. For handles and arms use `C.v[0] > 0`.
- **Seats (chairs, stools, tables with seats)** must keep the solid-sorted `build` path the sofas use, so creatures sort against them: real solids with no sunk-in parts, details glued (`S.par` / `on()`), small tilts. See "How to fix one piece" in CLAUDE.md.
- Helpers already in plus28: `door`, `swing`, `cavity` (interiors), `gshelf`, `bottle`, `jar`, `cup`, `mug2`, `mugH`, `plateF` / `plateZ`, `grapes`, `wrack` (wire racks), `barH` (bar handles), `knob`, `stick`, `H2`, `dent`, `scr` (scratches), `rust`, `fp` (fingerprints), `mag`, `leafS`, `wisp`, `puddle`, `grainV` / `grainH` (wood), `veins` (marble), `loopF` (looping flipbook), `pour` (liquid stream), `shim` (heat shimmer), `puff1`, `drop1`, `bub1`, `spk` (sparkle), `beanT`, and the gradients `k28brs` brass, `k28chr` chrome, `k6cu` copper, `k28amb` amber floor glow, `k28ging` gingham.
- Bump `reno-plus28.js?v=` in **reno-test.html**, **Renovation Catalog.dc.html** and **Squad House v6.dc.html** after each edit.

## Test + check
- `reno-test.html`: `show([[id, name, tier, st, rot], ...], cols, height)` renders a sheet; edit `AUTO()` to list the current batch.
- Seats: `sofa-spin.html` `scan(rows)` / `nfs(id)` / `cyc(id, deg)` (nf must be 0 every 5°), then sit a creature in Squad House v6 (`__sh.enterRoom('kitchen')`).
- After each batch, add a line to CLAUDE.md's Progress section (spec names, what's animated, sizes changed, what's verified).

## Work list (47), in order
- **Kitchen Sink:** 002 single-bowl leaky tap, 022 double-basin + sprayer, 042 fireclay farmhouse apron, 062 hammered brass workstation, 082 ultrasonic wave-clean basin
- **Base Cabinetry:** 010 chipped laminate + curtain shelves, 030 butcher-block + white shaker, 050 speckled quartz + navy, 070 walnut fluted + soapstone, 090 self-healing obsidian + lift cabinets
- **Center Table / Island:** 013 wobbly card table, 033 rolling pine prep cart, 053 round oak bistro table, 073 waterfall Calacatta island, 093 teppanyaki smart chef's island
- **Dining tables:** 102 oak + Carrara 4-seat, 103 walnut trestle + Calacatta, 104 royal ebony + Nero marble
- **Dining Chair (seats):** 016 plastic stool, 036 Windsor, 056 Thonet bentwood + cane, 076 boucle + brass armchair, 096 heated floating pod seat, 105 walnut + linen tufted, 106 brass + velvet channel-back, 107 royal ebony + gold-leaf velvet
- **Counter Stool (seats):** 019 rusty shop stool, 039 saddle barstool, 059 leather + iron tractor stool, 079 tufted velvet + brass, 099 hydraulic levitation stool
- **Utility Cart:** 003 plastic 3-tier cart, 023 wire + bamboo microwave stand, 043 brass + glass bar cart, 063 marble pastry slab + copper pan rack, 083 robotic sous-chef cart
- **Countertop Clutter:** 008 cereal + dish soap, 028 fruit basket + cookie jar, 048 mortar & pestle + oil cruet, 068 Damascus knife block + truffle cloche, 088 levitating gastronomy spheres
- **Pet Dining Spot:** 020 takeout-lid pet bowl, 040 ceramic bowls on bone mat, 060 bamboo feeder + water, 080 smart pet bistro + fountain, 100 gourmet pet chef counter

## First message to send in the new chat
> Continue the Kitchen realism pass with Furniture, following `Kitchen Furniture Brief.md` and CLAUDE.md. Start with the sinks: KIT-002, 022, 042.
