# Kitchen realism pass — Electronics + Furniture (new chat brief)

Paste this into a new chat to continue. CLAUDE.md (project root) has the full history; read its **"Kitchen realism pass"** section first, then the **"Sofa / multi-seat spin fix"** section.

## Goal
Do the same realism pass the Living Room got (plus18–26) on every Kitchen **Electronics** and **Furniture** piece: real 3D solids at creature scale, rich material detail, subtle looping animation, nothing that vanishes or overlaps when rotated.

## Where we are
- Kitchen Floors (5), Ceilings + island lights (10), Walls & Backsplash (5), Windows (5), Wall Storage (5): **done**, all in `reno-plus27.js` (now `?v=14`). User has reviewed / approved them.
- Wall Accents (004 menus27, 024 knife27, 044 copper27, 064 winemap27, 084 smart27) + Wall Sign 101 (ksign27, custom text): **built Oct 30**, user review pending. Walls are complete.

## Rules (from the user — apply every time)
1. **Real 3D solids**, rich detail, creature scale. A creature is ~78 units tall; compare on the test sheet.
2. **Luxury = materials + warm light.** Tier 4–5 pieces get marble, polished brass, gold, walnut, mirror shine and champagne/amber glow, not cyan sci-fi strips (unless the name asks for it). The user rejected a "techy" look on KIT-085.
3. **Low tiers look cheap and worn**: dents, chips, grime, rust, peeling, stickers, tape.
4. **Animation is subtle and looping** (steam, flicker, sway, drips, turning parts), never distracting. If the user calls something "flashy", remove it (they removed the copper glints on KIT-061).
5. **One-off features appear once.** Don't let a repeating tile multiply a screen or display (KIT-081 recipe screen fix: `S.one` → `res.wallOne`).
6. **nf = 0 at every 15°** for normal pieces, **every 5°** for seats / multi-seat pieces. Also check 30–70° by eye: nf 0 is not enough.
7. **Don't move seats** (`{x, z, h}`); creatures sit there. Try seats with a creature.
8. Keep each piece's mount/size unless it's needed (wall pieces stay `mount: 'wall'`, floor pieces stay floor) so saved houses keep working.
9. Keep existing tap behaviours: toaster tap-to-toast (011), dishwasher load/wash/clean states (006–086), fridge snack bonus, cooking range "on" state.
10. **3 pieces per batch.** Fix first, then show. User reviews each section.

## How to build (patterns that worked)
- New file **`reno-plus28.js`** (RD.SET28 / RD.H28), loaded after plus27 in **Renovation Catalog.dc.html**, **Squad House v6.dc.html** and **scratch/liv-wall.html**. Both pages wait for `RD.PLUS28`. Bump `?v=` on every edit.
- Catalog edits: `RD.SET28 = { 'KIT-0xx': { spec: 'name28', live: '…', note: '…' } }` + `RD.edit` wrapper (copy the end of plus27).
- **Floor pieces** = `N.<name> = S => ({ w, d, build: () => solids[], layers?, fx: c => ({defs, front}) })`, built from `House3D.K` (box, cyl, ball, slab, slabX, disc) + `RD.H16` (W_ wood, M_ metal, PL paint/plastic, em glow, rod, frame) + `RD.H22.glue` + `RD.H23` (face, qd).
  - **Glue every detail** to the part it lies on: `on(parent, [solids], [0,0,1])`, where the face normal hides it when that face turns away.
  - Parts touch, never sink into each other. Stack in y, don't put things side by side inside each other.
  - Shaker doors = slab + 4 rails glued on top. Glass and interiors go in `fx`, clipped to the opening; hide when `face(c,0,1) < 0.1`.
  - Painted surfaces use `PL(...)`, not `W_` (wood grain shows through).
- **Wall pieces** = `D.fx = ctx => { const C = H.cam(ctx) … }` using `RD.H15.box3/cyl3`, `RD.H12.WD/innerW`, `RD.H11.ext`. Draw order matters: draw an open box's carcass **after** its interior (the KIT-034 "missing parts" bug).
- Reference builds in plus27: `china27`, `butler27`, `vault27` (floor hutches with fx interiors, carousels, paternoster trays), `pine27`, `lam27` (wall pieces), carousel helper (front/back halves swap round a post).

## Test + check
- `scratch/liv-wall.html`: `zoom('KIT-0xx,KIT-0xx@rot=60', k)` same-scale sheet with a creature; `scanNF('KIT-0xx', 5)` must print `ok`; `cyc(id, deg)` shows sort cycles.
- Freeze animations for frame checks: render `RenoDraw.draw(row).svg` into a div, `svg.pauseAnimations(); svg.setCurrentTime(t)`.
- Then check in Squad House v6 kitchen (`__sh.enterRoom('kitchen')`; for seats, sit a creature).
- After each batch, update CLAUDE.md's Kitchen section ([x] built, notes, lessons) and copy edited files to `handoff/` if they're kept there.

## Work list (order: Electronics first, then Furniture; 3 per batch)

### Electronics (25)
- **Fridge:** 015 dented dorm cube, 035 white top-freezer, 055 stainless French-door + ice, 075 glass-front Sub-Zero + wine column, 095 holographic cryo-pantry mega-fridge
- **Cooking Range:** 018 single-burner hot plate, 038 4-burner electric coil, 058 5-burner gas + cast-iron grates, 078 6-burner French-top heritage brass, 098 invisible induction + laser-bake oven
- **Dishwashing** (all 5 are the old dish2 build; keep the tap-to-wash states): 006 drying rack + dishpan, 026 portable mini dishwasher, 046 built-in stainless, 066 wood-panel dual-drawer, 086 plasma-steam + robotic shelving
- **Beverage Maker:** 007 cracked drip coffee pot, 027 pod brewer, 047 chrome dual-boiler espresso + grinder, 067 plumbed latte-art barista wall, 087 AI sommelier beverage hub
- **Prep Appliance:** 011 chrome toaster (keep tap-to-toast), 031 pastel stand mixer + blender, 051 air-fryer oven + sous-vide, 071 copper pasta extruder + blast chiller, 091 holographic food synthesizer

### Furniture (47) — seats nf 0 every 5°, try with a creature sitting
- **Kitchen Sink:** 002 single-bowl leaky tap, 022 double-basin + sprayer, 042 fireclay farmhouse apron, 062 hammered brass workstation, 082 ultrasonic wave-clean basin
- **Base Cabinetry:** 010 chipped laminate + curtain shelves, 030 butcher-block + white shaker, 050 speckled quartz + navy, 070 walnut fluted + soapstone, 090 self-healing obsidian + lift cabinets
- **Center Table / Island:** 013 wobbly card table, 033 rolling pine prep cart, 053 round oak bistro table, 073 waterfall Calacatta island, 093 teppanyaki smart chef's island
- **Dining tables:** 102 oak + Carrara 4-seat, 103 walnut trestle + Calacatta, 104 royal ebony + Nero marble
- **Dining Chair:** 016 plastic stool, 036 Windsor, 056 Thonet bentwood + cane, 076 boucle + brass armchair, 096 heated floating pod seat, 105 walnut + linen tufted, 106 brass + velvet channel-back, 107 royal ebony + gold-leaf velvet
- **Counter Stool:** 019 rusty shop stool, 039 saddle barstool, 059 leather + iron tractor stool, 079 tufted velvet + brass, 099 hydraulic levitation stool
- **Utility Cart:** 003 plastic 3-tier cart, 023 wire + bamboo microwave stand, 043 brass + glass bar cart, 063 marble pastry slab + copper pan rack, 083 robotic sous-chef cart
- **Countertop Clutter:** 008 cereal + dish soap, 028 fruit basket + cookie jar, 048 mortar & pestle + oil cruet, 068 Damascus knife block + truffle cloche, 088 levitating gastronomy spheres
- **Pet Dining Spot:** 020 takeout-lid pet bowl, 040 ceramic bowls on bone mat, 060 bamboo feeder + water, 080 smart pet bistro + fountain, 100 gourmet pet chef counter

## First message to send in the new chat
> Continue the Kitchen realism pass: Electronics, then Furniture, 3 per batch, following `Kitchen Electronics + Furniture Brief.md` and CLAUDE.md. Start with the fridges 015, 035, 055.
