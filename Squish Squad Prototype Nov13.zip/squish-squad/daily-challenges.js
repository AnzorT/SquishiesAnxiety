// Shared daily challenges for Squish Squad (game) + Squad Crib. Progress lives in localStorage so both screens see the same state.
(function () {
  if (window.SquishDaily) return;
  const KEY = 'squishsquad.daily.v1';
  const CHEST = 250;
  const GAME = [
    { id: 'g_squish', ev: 'squish', goals: [50, 80, 120], title: n => 'Squish ' + n + ' times', reward: 60 },
    { id: 'g_earn', ev: 'earn', goals: [200, 300, 500], title: n => 'Earn ' + n + ' coins squishing', reward: 80 },
    { id: 'g_ad', ev: 'ad', goals: [1], title: () => 'Watch 1 bonus video', reward: 40 },
  ];
  const CRIB = [
    { id: 'c_bath', ev: 'bath', goals: [2, 3], title: n => 'Give ' + n + ' friends a bath', reward: 60 },
    { id: 'c_feed', ev: 'feed', goals: [2, 3], title: n => 'Feed ' + n + ' friends a snack', reward: 60 },
    { id: 'c_sleep', ev: 'sleep', goals: [1, 2], title: n => 'Tuck ' + n + (n > 1 ? ' friends' : ' friend') + ' into bed', reward: 50 },
    { id: 'c_dance', ev: 'dance', goals: [2, 3], title: n => 'Send ' + n + ' friends to dance', reward: 50 },
    { id: 'c_tv', ev: 'tv', goals: [2], title: n => 'Watch TV with ' + n + ' friends', reward: 40 },
    { id: 'c_play', ev: 'play', goals: [2, 3], title: n => 'Send ' + n + ' friends out to play', reward: 40 },
  ];
  const today = () => { const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); };
  const rng = seed => () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
  function build(date) {
    const r = rng(date.split('-').reduce((a, b) => a * 31 + +b, 7) % 233280);
    const crib = CRIB.slice(); for (let i = crib.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [crib[i], crib[j]] = [crib[j], crib[i]]; }
    const pick = (c, side) => ({ id: c.id, ev: c.ev, side, goal: c.goals[Math.floor(r() * c.goals.length)] });
    return { date, list: GAME.map(c => pick(c, 'game')).concat(crib.slice(0, 3).map(c => pick(c, 'crib'))), prog: {}, claimed: {}, chest: false };
  }
  function load() {
    let s = null; try { s = JSON.parse(localStorage.getItem(KEY)); } catch (e) {}
    if (!s || s.date !== today()) { s = build(today()); save(s); }
    return s;
  }
  function save(s) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {} }
  const emit = detail => window.dispatchEvent(new CustomEvent('squishdaily', { detail: detail || {} }));
  const def = id => GAME.concat(CRIB).find(c => c.id === id);
  function rows(s) {
    return s.list.map(c => {
      const d = def(c.id); const p = Math.min(c.goal, s.prog[c.ev] || 0); const claimed = !!s.claimed[c.id]; const full = p >= c.goal;
      return { id: c.id, ev: c.ev, side: c.side, title: d.title(c.goal), prog: p, goal: c.goal, pct: Math.round(p / c.goal * 100), label: p + ' / ' + c.goal, reward: d.reward, rewardLabel: '+' + d.reward, claimable: full && !claimed, claimed, open: !full };
    });
  }
  const PKEY = 'squishsquad.profile.v1';
  const PDEF = { level: 1, tut: 'start', tokens: 0, owned: [], coins: 100, logins: 0, lastLogin: null, streak: 0, lastFull: null, creates: 0, levelDay: null };
  const dayKey = d => d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  const yesterday = () => { const d = new Date(); d.setDate(d.getDate() - 1); return dayKey(d); };
  const PROF = {
    get() { let p = null; try { p = JSON.parse(localStorage.getItem(PKEY)); } catch (e) {} return Object.assign({}, PDEF, p || {}); },
    set(patch, silent) { const p = Object.assign(PROF.get(), patch); try { localStorage.setItem(PKEY, JSON.stringify(p)); } catch (e) {} if (!silent) window.dispatchEvent(new CustomEvent('squishprofile')); return p; },
    reset() { try { localStorage.removeItem(PKEY); localStorage.removeItem(KEY); } catch (e) {} },
    addTokens(n) { const p = PROF.get(); return PROF.set({ tokens: Math.max(0, p.tokens + n) }); },
    streak() { const p = PROF.get(); return p.lastFull === today() || p.lastFull === yesterday() ? p.streak : 0; },
    createPrice() { const p = PROF.get(); if (p.creates < 2) return { now: 0.99, was: 4.99, tag: 'FIRST 2 CREATIONS' }; if (PROF.streak() >= 7) return { now: 2.49, was: 4.99, tag: '7-DAY STREAK' }; return { now: 4.99, was: null, tag: '' }; },
  };
  window.SquishProfile = PROF;
  const API = {
    bump(ev, n) {
      const s = load(); const before = rows(s); s.prog[ev] = (s.prog[ev] || 0) + (n == null ? 1 : n); save(s);
      const done = rows(s).filter((r, i) => r.claimable && !before[i].claimable).map(r => r.title);
      emit({ completed: done });
    },
    claim(id) {
      const s = load(); const r = rows(s).find(x => x.id === id); if (!r || !r.claimable) return 0;
      s.claimed[id] = true; save(s); emit(); return r.reward;
    },
    claimChest() {
      const s = load(); if (s.chest || !s.list.every(c => s.claimed[c.id])) return 0;
      s.chest = true; save(s);
      const p = PROF.get(); const st = p.lastFull === yesterday() ? p.streak + 1 : p.lastFull === today() ? p.streak : 1;
      PROF.set({ tokens: p.tokens + 1, streak: st, lastFull: today(), level: p.level >= 3 && p.levelDay !== today() ? p.level + 1 : p.level, levelDay: today() });
      emit(); return CHEST;
    },
    view() {
      const s = load(); const all = rows(s); const now = new Date(); const mid = new Date(now); mid.setHours(24, 0, 0, 0);
      const mins = Math.max(0, Math.round((mid - now) / 60000));
      const claimedN = all.filter(r => r.claimed).length;
      const pr = PROF.get();
      return {
        streak: PROF.streak(), level: pr.level,
        game: all.filter(r => r.side === 'game'), crib: all.filter(r => r.side === 'crib'),
        done: all.filter(r => !r.open).length, total: all.length, claimable: all.filter(r => r.claimable).length,
        claimedN, chestPct: Math.round(claimedN / all.length * 100), chestReady: claimedN === all.length && !s.chest, chestDone: s.chest, chestReward: CHEST,
        resetIn: Math.floor(mins / 60) + 'h ' + (mins % 60) + 'm',
      };
    },
  };
  window.addEventListener('storage', e => { if (e.key === KEY) emit(); if (e.key === PKEY) window.dispatchEvent(new CustomEvent('squishprofile')); });
  window.SquishDaily = API;
  emit();
})();
