// Squish Squad currency art: gold coins stamped with a creature, gems cut in the shape of a creature.
// window.SquishCoin.coin(i) / .gem(i) -> PNG data URL ('' until built). Fires window 'squishcoin' when ready.
(function () {
  if (window.SquishCoin) return;
  const COINS = ['mittens', 'pip', 'bao', 'dunkie', 'boo', 'jelli'];
  const GEMS = ['mittens', 'jelli', 'twinkle', 'pip', 'boo', 'jinni'];
  const SZ = 160, BLANK = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
  const PAL = {
    gold: [[104, 44, 0], [178, 94, 0], [236, 154, 0], [255, 210, 70], [255, 246, 196]],
    gem: [[34, 6, 104], [86, 30, 196], [140, 58, 240], [120, 196, 255], [236, 250, 255]],
  };
  const out = { coin: [], gem: [] }, BASE = (document.currentScript && document.currentScript.src || location.href).replace(/[^/]*$/, '');
  const cv = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h || w; return c; };
  const load = k => new Promise(r => { const i = new Image(); i.onload = () => r(i); i.onerror = () => r(null); i.src = BASE + 'export/tripo/' + k + '/' + k + '-front.svg'; });
  function fit(im, box) {
    const N = 320, c = cv(N), x = c.getContext('2d'); x.drawImage(im, 0, 0, N, N);
    const d = x.getImageData(0, 0, N, N).data; let x0 = N, y0 = N, x1 = 0, y1 = 0;
    for (let y = 0; y < N; y++) for (let X = 0; X < N; X++) if (d[(y * N + X) * 4 + 3] > 40) { if (X < x0) x0 = X; if (X > x1) x1 = X; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 <= x0) return null;
    const w = x1 - x0 + 1, h = y1 - y0 + 1, s = box / Math.max(w, h), o = cv(box);
    o.getContext('2d').drawImage(c, x0, y0, w, h, (box - w * s) / 2, (box - h * s) / 2, w * s, h * s); return o;
  }
  function gmap(c, pal, gam) {
    const x = c.getContext('2d'), D = x.getImageData(0, 0, c.width, c.height), d = D.data; let lo = 1, hi = 0;
    const lum = i => (0.3 * d[i] + 0.59 * d[i + 1] + 0.11 * d[i + 2]) / 255;
    for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 40) { const l = lum(i); if (l < lo) lo = l; if (l > hi) hi = l; }
    const rg = Math.max(0.05, hi - lo), n = pal.length - 1;
    for (let i = 0; i < d.length; i += 4) {
      if (!d[i + 3]) continue; const t = Math.pow(Math.min(1, Math.max(0, (lum(i) - lo) / rg)), gam) * n, j = Math.min(n - 1, Math.floor(t)), f = t - j, A = pal[j], B = pal[j + 1];
      d[i] = A[0] + (B[0] - A[0]) * f; d[i + 1] = A[1] + (B[1] - A[1]) * f; d[i + 2] = A[2] + (B[2] - A[2]) * f;
    }
    x.putImageData(D, 0, 0); return c;
  }
  function sil(c, col) { const o = cv(c.width), x = o.getContext('2d'); x.drawImage(c, 0, 0); x.globalCompositeOperation = 'source-in'; x.fillStyle = col; x.fillRect(0, 0, o.width, o.height); return o; }
  function star(x, cx, cy, r, a) {
    x.save(); x.globalAlpha = a; x.fillStyle = '#ffffff'; x.beginPath();
    for (let i = 0; i < 8; i++) { const ang = i * Math.PI / 4 - Math.PI / 2, rr = i % 2 ? r * 0.28 : r; x.lineTo(cx + Math.cos(ang) * rr, cy + Math.sin(ang) * rr); }
    x.closePath(); x.fill(); x.restore();
  }
  function coin(im) {
    const c = cv(SZ), x = c.getContext('2d'), C = SZ / 2, R = SZ / 2 - 3, F = R - 13;
    let g = x.createLinearGradient(0, 0, 0, SZ); g.addColorStop(0, '#ffe98a'); g.addColorStop(0.5, '#f7b21a'); g.addColorStop(1, '#b45e00');
    x.beginPath(); x.arc(C, C, R, 0, 7); x.fillStyle = g; x.fill(); x.lineWidth = 3.5; x.strokeStyle = '#7a3a00'; x.stroke();
    x.save(); x.strokeStyle = 'rgba(122,58,0,0.32)'; x.lineWidth = 2.2;
    for (let i = 0; i < 64; i++) { const a = i / 64 * Math.PI * 2; x.beginPath(); x.moveTo(C + Math.cos(a) * (R - 9.5), C + Math.sin(a) * (R - 9.5)); x.lineTo(C + Math.cos(a) * (R - 3), C + Math.sin(a) * (R - 3)); x.stroke(); }
    x.restore();
    g = x.createRadialGradient(C - 18, C - 22, 6, C, C, F); g.addColorStop(0, '#ffd85a'); g.addColorStop(0.55, '#f2a20e'); g.addColorStop(1, '#c86a00');
    x.beginPath(); x.arc(C, C, F, 0, 7); x.fillStyle = g; x.fill();
    g = x.createLinearGradient(0, C - F, 0, C + F); g.addColorStop(0, '#9a4a00'); g.addColorStop(1, '#fff6c0');
    x.lineWidth = 3.5; x.strokeStyle = g; x.stroke();
    if (im) {
      const B = Math.round(F * 1.62), m = fit(im, B);
      if (m) {
        gmap(m, PAL.gold, 0.7); const ox = C - B / 2, oy = C - B / 2 + 2;
        x.save(); x.beginPath(); x.arc(C, C, F - 2, 0, 7); x.clip();
        x.drawImage(sil(m, 'rgba(96,38,0,0.75)'), ox + 3, oy + 4); x.drawImage(sil(m, 'rgba(255,250,214,0.95)'), ox - 2, oy - 2); x.drawImage(m, ox, oy);
        x.restore();
      }
    }
    x.save(); x.globalCompositeOperation = 'source-atop';
    g = x.createRadialGradient(C - 26, C - 32, 2, C - 26, C - 32, 58); g.addColorStop(0, 'rgba(255,255,255,0.75)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, SZ, SZ);
    g = x.createLinearGradient(0, C, 0, SZ); g.addColorStop(0, 'rgba(120,50,0,0)'); g.addColorStop(1, 'rgba(120,50,0,0.28)'); x.fillStyle = g; x.fillRect(0, 0, SZ, SZ);
    x.restore();
    star(x, C + R * 0.58, C - R * 0.62, 14, 0.95);
    return c.toDataURL('image/png');
  }
  function gem(im) {
    const c = cv(SZ), x = c.getContext('2d'), B = SZ - 30, m = im && fit(im, B);
    if (!m) return '';
    gmap(m, PAL.gem, 1.15);
    const f = cv(B), y = f.getContext('2d'), cx = B / 2, cy = B * 0.46, n = 12;
    const pts = Array.from({ length: n }, (_, i) => { const a = i / n * Math.PI * 2 + 0.2; return [cx + Math.cos(a) * B * 0.78, cy + Math.sin(a) * B * 0.78, a]; });
    for (let i = 0; i < n; i++) {
      const p = pts[i], q = pts[(i + 1) % n], mid = (p[2] + Math.PI / n), lit = Math.cos(mid - (-2.3));
      y.beginPath(); y.moveTo(cx, cy); y.lineTo(p[0], p[1]); y.lineTo(q[0], q[1]); y.closePath();
      y.fillStyle = lit > 0 ? 'rgba(255,255,255,' + (0.1 + lit * 0.28).toFixed(3) + ')' : 'rgba(30,0,110,' + (0.08 - lit * 0.26).toFixed(3) + ')'; y.fill();
    }
    y.strokeStyle = 'rgba(255,255,255,0.45)'; y.lineWidth = 1.3;
    pts.forEach(p => { y.beginPath(); y.moveTo(cx, cy); y.lineTo(p[0], p[1]); y.stroke(); });
    y.beginPath(); pts.forEach((p, i) => { const r = 0.42, X = cx + (p[0] - cx) * r, Y = cy + (p[1] - cy) * r; i ? y.lineTo(X, Y) : y.moveTo(X, Y); }); y.closePath(); y.stroke();
    let g = y.createLinearGradient(0, 0, B, B); g.addColorStop(0.18, 'rgba(255,255,255,0)'); g.addColorStop(0.3, 'rgba(255,255,255,0.5)'); g.addColorStop(0.4, 'rgba(255,255,255,0)'); y.fillStyle = g; y.fillRect(0, 0, B, B);
    const mx = m.getContext('2d'); mx.globalCompositeOperation = 'source-atop'; mx.drawImage(f, 0, 0);
    g = mx.createRadialGradient(B * 0.3, B * 0.22, 2, B * 0.3, B * 0.22, B * 0.5); g.addColorStop(0, 'rgba(255,255,255,0.6)'); g.addColorStop(1, 'rgba(255,255,255,0)'); mx.fillStyle = g; mx.fillRect(0, 0, B, B);
    const o = 15, dk = sil(m, '#2a0a6e'), wh = sil(m, '#ffffff');
    for (let i = 0; i < 16; i++) { const a = i / 16 * Math.PI * 2; x.drawImage(dk, o + Math.cos(a) * 5.5, o + Math.sin(a) * 5.5 + 1.5); }
    for (let i = 0; i < 16; i++) { const a = i / 16 * Math.PI * 2; x.drawImage(wh, o + Math.cos(a) * 2.8, o + Math.sin(a) * 2.8); }
    x.drawImage(m, o, o);
    star(x, SZ * 0.8, SZ * 0.2, 15, 0.95); star(x, SZ * 0.22, SZ * 0.8, 9, 0.85);
    return c.toDataURL('image/png');
  }
  const API = window.SquishCoin = {
    ready: false, BLANK, COINS, GEMS,
    coin: i => out.coin[(i || 0) % COINS.length] || out.coin[0] || '',
    gem: i => out.gem[(i || 0) % GEMS.length] || out.gem[0] || '',
  };
  const keys = [...new Set(COINS.concat(GEMS))];
  Promise.all(keys.map(load)).then(ims => {
    const by = {}; keys.forEach((k, i) => by[k] = ims[i]);
    try {
      COINS.forEach((k, i) => { out.coin[i] = coin(by[k] || by.mittens); });
      GEMS.forEach((k, i) => { out.gem[i] = gem(by[k] || by.mittens) || out.gem[0] || ''; });
    } catch (e) { console.warn('SquishCoin', e); }
    API.ready = true; window.dispatchEvent(new Event('squishcoin'));
  });
})();
