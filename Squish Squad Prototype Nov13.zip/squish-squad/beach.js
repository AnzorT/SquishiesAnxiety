// Squad House Beach: room config, live beach scene (sea on the right, pier, dunes, seasons, night), walk geometry, gates (Backyard <-> Beach).
// window.Beach. Scene = SVG markup with SMIL (waves, foam, glints, clouds, palms, rain, snow) injected into the room svg by the page.
(function boot() {
  const X = window.House3D; if (!(X && X.ROOMS && X.shell && X.RKEYS && X.K && X.edge)) { setTimeout(boot, 30); return; } if (window.Beach) return;
  const K = X.K, f1 = K.f1, mix = K.mix, shade = K.shade, VW = 852, PI = Math.PI, LV = 30;
  const WY = y => (652 + 1.235 * (y - 100)) / 652;
  const sideB = (s, t) => s === 'L' ? [100 - 100 * t, 100 + 162 * t] : [752 + 100 * t, 100 + 162 * t];
  const hash = s => { let h = 7; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) | 0; return Math.abs(h) || 1; };
  const rng = s => { let h = hash(s); return () => { h = (h * 1103515245 + 12345) | 0; return ((h >>> 8) & 0xffff) / 65536; }; };
  const rep = (n, f) => Array.from({ length: n }, (_, i) => f(i));
  const n3 = v => Math.round(v * 1000) / 1000;
  const pd = (d, f, s, w, o) => ({ d, f, s: s || 'none', w: w || 0, o: o == null ? 1 : o });
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  const P = (d, f, s, w, ex) => `<path d="${d}" fill="${f || 'none'}"${s ? ` stroke="${s}" stroke-width="${w || 1}" stroke-linejoin="round" stroke-linecap="round"` : ''}${ex || ''}/>`;
  const AT = (type, vals, d, b, ex) => `<animateTransform attributeName="transform" type="${type}" values="${vals}" dur="${n3(d)}s"${b ? ` begin="${n3(b)}s"` : ''} repeatCount="indefinite"${ex || ''}/>`;
  const AN = (a, vals, d, b, ex) => `<animate attributeName="${a}" values="${vals}" dur="${n3(d)}s"${b ? ` begin="${n3(b)}s"` : ''} repeatCount="indefinite"${ex || ''}/>`;
  const SPL = n => ` calcMode="spline" keyTimes="${rep(n + 1, i => n3(i / n)).join(';')}" keySplines="${rep(n, () => '0.45 0 0.55 1').join(';')}"`;
  const circ = (x, y, r) => `M${f1(x - r)} ${f1(y)}a${f1(r)} ${f1(r)} 0 1 0 ${f1(2 * r)} 0a${f1(r)} ${f1(r)} 0 1 0 ${f1(-2 * r)} 0Z`;
  const ell = (x, y, rx, ry) => `M${f1(x - rx)} ${f1(y)}a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(2 * rx)} 0a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(-2 * rx)} 0Z`;
  const rr = (x, y, w, h, r) => { r = Math.min(r, w / 2, h / 2); return `M${f1(x + r)} ${f1(y)}H${f1(x + w - r)}A${r} ${r} 0 0 1 ${f1(x + w)} ${f1(y + r)}V${f1(y + h - r)}A${r} ${r} 0 0 1 ${f1(x + w - r)} ${f1(y + h)}H${f1(x + r)}A${r} ${r} 0 0 1 ${f1(x)} ${f1(y + h - r)}V${f1(y + r)}A${r} ${r} 0 0 1 ${f1(x + r)} ${f1(y)}Z`; };
  const stp = s => s.map(q => `<stop offset="${q[0]}" stop-color="${q[1]}"${q[2] != null ? ` stop-opacity="${q[2]}"` : ''}/>`).join('');
  const LG = (id, s, a) => `<linearGradient id="${id}" ${a || 'x1="0" y1="0" x2="0" y2="1"'}>${stp(s)}</linearGradient>`;
  const RG = (id, s, a) => `<radialGradient id="${id}" ${a || 'cx="50%" cy="50%" r="50%"'}>${stp(s)}</radialGradient>`;

  // ---------- geometry (room px: x 0..852, floor y 100..393) ----------
  const SO = 540, BY0 = 104, BM = 22; // shore x at y 100 (was 470), beach walk top (rooms use FY0 128), side margin
  const shore = y => y >= 100 ? SO + 0.95 * (y - 100) - 0.0009 * (y - 100) * (y - 100) : SO - (100 - y) * 2.4;
  const PIER = { y0: 226, y1: 248, py0: 212, py1: 258, xe: 742, xp1: 828, face: 7 }; PIER.x0 = Math.round(shore(237) - 58);
  const FISH = [{ x: 806, y: 232, face: 90 }, { x: 770, y: 250, face: 20 }];
  const B = { season: 'sunny' };
  const ice = () => B.season === 'snowy' ? 62 : 0;
  const onPier = (x, y) => (x >= PIER.x0 + 4 && x <= PIER.xe + 2 && y >= PIER.y0 + 2 && y <= PIER.y1 - 2) || (x > PIER.xe - 6 && x <= PIER.xp1 - 6 && y >= PIER.py0 + 4 && y <= PIER.py1 - 4);
  const inSea = (x, y) => x > shore(y) + ice();
  const wet = (x, y) => inSea(x, y) && !onPier(x, y);
  const nearPier = (x, y) => (x >= PIER.x0 && x <= PIER.xe && y >= PIER.y0 - 8 && y <= PIER.y1 + 8) || (x > PIER.xe - 6 && x <= PIER.xp1 + 10 && y >= PIER.py0 - 8 && y <= PIER.py1 + 8);
  function clamp(x, y, m, o) {
    o = o || {}; y = Math.max(BY0, Math.min(X.FY1, y)); const L = X.edge(y) + (m == null ? BM : Math.min(m, BM));
    if (nearPier(x, y) && x > shore(y) - 24) { if (x > PIER.xe - 6) return [Math.min(PIER.xp1 - 10, x), Math.max(PIER.py0 + 6, Math.min(PIER.py1 - 6, y))]; return [Math.max(PIER.x0 + 8, x), Math.max(PIER.y0 + 4, Math.min(PIER.y1 - 4, y))]; }
    if (o.sea) { const xs = Math.min(834, x); if (xs > shore(y) + ice() + 10) { let yy = y; if (xs > PIER.x0 && yy > PIER.py0 - 16 && yy < PIER.py1 + 12) yy = yy < (PIER.py0 + PIER.py1) / 2 ? PIER.py0 - 16 : PIER.py1 + 12; return [xs, Math.max(BY0, Math.min(X.FY1, yy))]; } }
    return [Math.max(L, Math.min(shore(y) + ice() - 18, x)), y];
  }
  function randSand(R) { R = R || Math.random; const y = 118 + R() * (X.FY1 - 118), a = X.edge(y) + 40, b = shore(y) + ice() - 40; return [a + R() * Math.max(10, b - a), y]; }
  function randSea(R) { R = R || Math.random; for (let i = 0; i < 20; i++) { const y = 140 + R() * (X.FY1 - 140); if (y > PIER.py0 - 16 && y < PIER.py1 + 12) continue; const a = shore(y) + ice() + 34, b = 826; if (b - a < 20) continue; return [a + R() * (b - a), y]; } return [760, 300]; }
  function itemX(x, y, hx, sea) { const s = shore(y) + ice(); if (sea) return Math.max(s + hx + 8, Math.min(VW - 14, x)); return Math.min(s - hx * 0.6 - 6, x); }

  // ---------- gates ----------
  function gate(s, lk, lab) {
    const t0 = 0.42, t1 = 0.66, M = (u, v) => { const p = sideB(s, t0 + (t1 - t0) * u); return [p[0], p[1] - 72 * WY(p[1]) * v]; };
    const Q = pts => 'M' + pts.map(q => { const p = M(q[0], q[1]); return f1(p[0]) + ' ' + f1(p[1]); }).join('L') + 'Z';
    const Ln = (a, b) => { const p = M(a[0], a[1]), q = M(b[0], b[1]); return 'M' + f1(p[0]) + ' ' + f1(p[1]) + 'L' + f1(q[0]) + ' ' + f1(q[1]); };
    const W = '#b8804a', WL = '#d49a60', WD = '#5e3c1c', o = [], T = [];
    o.push(pd(Q([[-0.2, 0.02], [1.2, 0.02], [1.2, -0.08], [-0.2, -0.08]]), '#2a1608', 0, 0, 0.16));
    [[-0.07, 0.05], [0.95, 1.07]].forEach(([a, b]) => { o.push(pd(Q([[a, 0], [b, 0], [b, 1.2], [a, 1.2]]), W, WD, 1.5), pd(Ln([a + 0.04, 0.05], [a + 0.04, 1.15]), 'none', WL, 1.2, 0.8)); });
    o.push(pd(Q([[-0.18, 1.1], [1.18, 1.1], [1.18, 1.26], [-0.18, 1.26]]), WL, WD, 1.5), pd(Ln([-0.14, 1.16], [1.14, 1.16]), 'none', '#f0c48a', 1, 0.7));
    if (lk) {
      [[0.16, 0.3], [0.5, 0.64], [0.78, 0.9]].forEach(([a, b], i) => o.push(pd(Q([[-0.04, a], [1.04, b - 0.02], [1.04, b + 0.1], [-0.04, a + 0.12]]), i % 2 ? '#a07a50' : '#b08a5e', '#6b4a2a', 1)));
      const m = M(0.5, 0.56); o.push(pd('M' + f1(m[0] - 4) + ' ' + f1(m[1] - 2) + 'V' + f1(m[1] - 6) + 'a4 4 0 0 1 8 0V' + f1(m[1] - 2), 'none', '#5a5450', 2.2), pd(rr(m[0] - 6.5, m[1] - 2, 13, 10.5, 2.5), '#ffd66b', '#a87a1a', 1), pd(circ(m[0], m[1] + 3.2, 1.5), '#7a5a10'));
    } else {
      const a = M(0, 0.42), b = M(1, 0.42), c = M(0.5, 0.3); o.push(pd('M' + f1(a[0]) + ' ' + f1(a[1]) + 'Q' + f1(c[0]) + ' ' + f1(c[1] + 6) + ' ' + f1(b[0]) + ' ' + f1(b[1]), 'none', '#e8d2a0', 2.4));
      [0.25, 0.5, 0.75].forEach((u, i) => { const q = M(u, 0.34 - Math.sin(u * PI) * 0.06); o.push(pd(ell(q[0], q[1] + 3, 2.6, 3.2), ['#ffb3a0', '#fff1d8', '#9fe0e0'][i], '#8a5a2c', 0.8)); });
    }
    const top = M(0.5, 1.26), w = 16 + lab.length * 5.2, h = 15, cx = top[0], cy = top[1] - 14, ny = top[1];
    o.push(pd('M' + f1(cx - w * 0.3) + ' ' + f1(cy - h / 2) + 'L' + f1(cx - w * 0.3) + ' ' + f1(ny) + 'M' + f1(cx + w * 0.3) + ' ' + f1(cy - h / 2) + 'L' + f1(cx + w * 0.3) + ' ' + f1(ny), 'none', '#6b4426', 1.2));
    o.push(pd(rr(cx - w / 2, cy - h / 2 + 1.6, w, h, 3), 'rgba(60,30,10,0.28)'), pd(rr(cx - w / 2, cy - h / 2, w, h, 3), lk ? '#c9b896' : '#fff2cf', lk ? '#7d6248' : '#8a5a2c', 1.8));
    if (!lk) [-1, 1].forEach(sg => o.push(pd('M' + f1(cx + sg * (w / 2 - 6) - 3) + ' ' + f1(cy) + 'q1.5 -2.4 3 0t3 0', 'none', '#3fa8d8', 1.2)));
    T.push({ x: cx, y: cy + 3.6, t: lab, f: lk ? '#b23a2e' : '#5b3418', sz: 8.8 });
    const hit = Q([[-0.24, -0.04], [1.24, -0.04], [1.24, 1.5], [-0.24, 1.5]]) + rr(cx - w / 2 - 2, cy - h / 2 - 2, w + 4, h + 4, 3);
    const tm = (t0 + t1) / 2, y = Math.max(X.FY0 + 6, 100 + 162 * tm + 10), ex = X.edge(y) + 30;
    return { polys: o, texts: T, hit, spawn: [s === 'L' ? ex : VW - ex, y], walk: [s === 'L' ? ex + 90 : VW - ex - 90, y + 10] };
  }
  const polySvg = L => L.map(p => P(p.d, p.f, p.s !== 'none' ? p.s : '', p.w, p.o !== 1 ? ` opacity="${p.o}"` : '')).join('');
  const textSvg = t => `<text x="${f1(t.x)}" y="${f1(t.y)}" text-anchor="middle" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="${t.sz}" fill="${t.f}">${esc(t.t)}</text>`;

  // ---------- palettes ----------
  const SKY = { sunny: ['#68bdf0', '#d4f0fb'], rainy: ['#7d8c99', '#c4ccd2'], snowy: ['#9cbcd2', '#eaf2f6'] };
  const SEA = { sunny: ['#b4e6f2', '#1f93d2', '#3cb8e6', '#74e2e2'], rainy: ['#a6b8c0', '#285f80', '#36809e', '#5aa6b2'], snowy: ['#d8eef4', '#3f8cbc', '#5aaad2', '#94d6e6'] };
  const SAND = ['#d4c09a', '#f0cf8a', '#f6e8ca', '#f4cfbe', '#f3dca4'];
  const NIGHT = '#0f1a40';
  const PIERS = [
    { n: 'drift', a: '#a8977c', b: '#968670', e: '#6a5c48', face: '#7a6a54', post: '#5e5040', rail: 0 },
    { n: 'board', a: '#dcb880', b: '#cfa86e', e: '#8a6a3e', face: '#a8804c', post: '#7a5a34', rail: 'rope' },
    { n: 'white', a: '#f4f2ec', b: '#e8e6de', e: '#9aa4b0', face: '#3f7fc8', post: '#e8e6de', rail: 'white' },
    { n: 'teak', a: '#c27a42', b: '#b06a36', e: '#6a3a18', face: '#8a4e24', post: '#5a3418', rail: 'teak' },
    { n: 'marble', a: '#f6f2ea', b: '#ebe4d6', e: '#c9b48a', face: '#e2d6bc', post: '#e2b14a', rail: 'gold' },
  ];

  // ---------- scene ----------
  // o: { season, night, sand 1-5, pier 1-5, light 1-5, gateLock, crop }
  function scene(o) {
    o = o || {}; const sea = SKY[o.season] ? o.season : 'sunny', nt = !!o.night, st = Math.max(1, Math.min(5, o.sand || 1)), pt = Math.max(1, Math.min(5, o.pier || 1)), lt = Math.max(0, Math.min(5, o.light || 0));
    const rainy = sea === 'rainy', snowy = sea === 'snowy', sunny = sea === 'sunny', R = rng('beach' + sea + st + pt), NM = (c, k) => nt ? mix(c, NIGHT, k) : c;
    const icew = snowy ? 62 : 0, spd = rainy ? 0.62 : snowy ? 1.8 : 1;
    const sk = SKY[sea].map((c, i) => NM(c, i ? 0.72 : 0.82)), SC = SEA[sea].map(c => NM(c, 0.62));
    let sand = SAND[st - 1]; if (rainy) sand = mix(sand, '#8a7a5c', 0.22); if (snowy) sand = mix(sand, '#e6ecf0', 0.3); sand = NM(sand, 0.5);
    const sandD = shade(sand, 0.86), sandL = mix(sand, '#ffffff', 0.25), wetC = mix(sand, rainy ? '#5a4a30' : '#8a6a3a', 0.32);
    // shore polyline
    const SH = rep(36, i => { const y = 54 + (393 - 54) * i / 35; return [shore(y), y]; }), shoreD = 'M' + SH.map(q => f1(q[0]) + ' ' + f1(q[1])).join('L');
    const shoreOff = dx => 'M' + SH.map(q => f1(q[0] + dx * WY(Math.max(100, q[1]))) + ' ' + f1(q[1])).join('L');
    const seaPoly = shoreD + 'L870 393L870 54Z', sandPoly = 'M-20 54' + shoreD.replace('M', 'L') + 'L-20 400Z';
    let d = LG('bzSky', [[0, sk[0]], [1, sk[1]]], 'x1="0" y1="-60" x2="0" y2="60" gradientUnits="userSpaceOnUse"')
      + LG('bzSea', [[0, SC[0]], [0.12, SC[1]], [0.55, SC[2]], [1, mix(SC[2], SC[3], 0.4)]], 'x1="0" y1="54" x2="0" y2="393" gradientUnits="userSpaceOnUse"')
      + LG('bzSand', [[0, mix(sand, sk[1], 0.25)], [0.25, sand], [1, mix(sand, '#ffffff', nt ? 0 : 0.12)]], 'x1="0" y1="54" x2="0" y2="393" gradientUnits="userSpaceOnUse"')
      + LG('bzDune', [[0, mix(sandL, '#ffffff', 0.1)], [0.55, sand], [1, sandD]], 'x1="0" y1="10" x2="0" y2="120" gradientUnits="userSpaceOnUse"')
      + LG('bzDune2', [[0, mix(sand, sk[1], 0.45)], [1, mix(sand, sk[1], 0.2)]])
      + RG('bzGlow', [[0, '#fff2b0', 0.85], [0.4, '#ffd88a', 0.35], [1, '#ffd88a', 0]]) + RG('bzSun', [[0, '#fffbe0', 0.95], [0.5, '#fff1a8', 0.4], [1, '#fff1a8', 0]])
      + RG('bzCyan', [[0, '#bffcff', 0.9], [0.45, '#4fe0f0', 0.35], [1, '#4fe0f0', 0]])
      + `<clipPath id="bzSeaC"><path d="${seaPoly}"/></clipPath><clipPath id="bzSandC"><path d="${sandPoly}"/></clipPath>`
      + `<filter id="bzB3" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3"/></filter><filter id="bzB8" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="8"/></filter>`
      + `<pattern id="bzWv" width="54" height="22" patternUnits="userSpaceOnUse"><path d="M4 6q6-4 12 0t12 0M30 17q6-4 12 0" fill="none" stroke="#ffffff" stroke-width="1.3" stroke-linecap="round"/><animateTransform attributeName="patternTransform" type="translate" values="0 0;-54 22" dur="${n3(14 * spd)}s" repeatCount="indefinite"/></pattern>`
      + `<pattern id="bzWv2" width="90" height="34" patternUnits="userSpaceOnUse"><path d="M8 10q9-5 18 0t18 0M52 26q8-4 16 0" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round"/><animateTransform attributeName="patternTransform" type="translate" values="0 0;-90 34" dur="${n3(21 * spd)}s" repeatCount="indefinite"/></pattern>`;
    let s = '';
    // sky
    s += `<rect x="-20" y="-70" width="900" height="140" fill="url(#bzSky)"/>`;
    if (nt) { const Rs = rng('stars'); s += rep(46, i => { const x = Rs() * 860, y = -48 + Rs() * 96, r = 0.6 + Rs() * 1.1, dd = 1.6 + Rs() * 2.4; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="#fffbe6">${AN('opacity', '1;0.25;1', dd, -Rs() * dd)}</circle>`; }).join('');
      s += `<circle cx="620" cy="-16" r="46" fill="url(#bzSun)" opacity="0.5"/>` + P(circ(620, -16, 17), '#fff8dc') + P(circ(628, -21, 15), sk[0]) + P(circ(612, -12, 2.4), '#efe6c4', '', 0, ' opacity="0.7"'); }
    else if (!rainy) s += `<circle cx="630" cy="-22" r="60" fill="url(#bzSun)"/>` + P(circ(630, -22, 19), snowy ? '#fffdf2' : '#fff4b8', '#ffe07a', 1.4);
    const cloud = (x, y, k, c, op) => `<g transform="translate(${f1(x)} ${f1(y)}) scale(${n3(k)})" opacity="${op}">${P('M-34 8C-46 8-48-6-36-8C-36-22-16-26-8-16C-2-30 22-28 24-12C40-14 44 6 30 8Z', c, mix(c, '#7a9ab0', 0.35), 1.2)}${P('M-28 2C-24-6-14-6-10-2', 'none', '#ffffff', 1.4, ' opacity="0.7"')}</g>`;
    const CL = rainy ? 9 : snowy ? 6 : 4, cc = rainy ? NM('#d6dce2', 0.6) : NM('#ffffff', 0.6);
    rep(CL, i => { const y = -40 + (i * 23) % 70, k = 0.7 + (i % 3) * 0.3, dur = (90 + i * 23) / (rainy ? 1.6 : 1), x0 = -80; s += `<g>${AT('translate', `${x0} 0;${940} 0`, dur, -dur * ((i * 0.37) % 1))}${cloud(0, y, k * (rainy ? 1.4 : 1), cc, rainy ? 0.95 : 0.9)}</g>`; });
    // horizon sea + island
    s += `<g clip-path="url(#bzSeaC)"><rect x="0" y="50" width="870" height="350" fill="url(#bzSea)"/></g>`;
    s += P('M688 56C700 44 716 40 730 44C742 34 764 36 776 46C790 46 800 52 806 56Z', NM(snowy ? '#cfe0e4' : '#7fb87a', 0.6), NM('#4f7a50', 0.6), 1);
    s += `<g>${P(rr(756, 22, 8, 26, 2), NM('#fffaf1', 0.5), NM('#7a6a5a', 0.5), 1)}${P('M756 30H764M756 38H764', 'none', '#e2554a', 2.6)}${P('M754 22H766L760 15Z', NM('#e2554a', 0.4), NM('#7a2a20', 0.5), 1)}${P(circ(760, 19, 2.6), nt ? '#fff1a8' : '#fff8d8')}</g>`;
    if (nt) s += `<g>${AT('rotate', '0 760 19;360 760 19', 6)}<path d="M760 19L860 4L860 34Z" fill="#fff1a8" opacity="0.22"/></g><circle cx="760" cy="19" r="10" fill="url(#bzGlow)"/>`;
    // far sailboat
    s += `<g>${AT('translate', '400 0;900 0', 110 * spd, -40)}<g transform="translate(0 53)">${P('M-8 0H8L5 3H-5Z', NM('#c4651f', 0.5))}${P('M0 -1V-14L7 -2Z', NM('#ffffff', 0.5), NM('#b8c4cc', 0.5), 0.6)}</g></g>`;
    // sea surface detail
    s += `<g clip-path="url(#bzSeaC)">`;
    s += P(shoreOff(16), 'none', NM(SEA[sea][3], 0.6), 70, ' opacity="0.75" filter="url(#bzB8)"');
    s += `<rect x="300" y="60" width="570" height="340" fill="url(#bzWv)" opacity="${rainy ? 0.45 : 0.28}"/><rect x="300" y="120" width="570" height="280" fill="url(#bzWv2)" opacity="${rainy ? 0.4 : 0.22}"/>`;
    const NCR = rainy ? 16 : 9; rep(NCR, i => { const y = 70 + ((i * 61) % 320), xs = shore(y) + 40 + ((i * 97) % 260), k = WY(Math.max(100, y)) * (rainy ? 1.4 : 1), dur = (5 + (i % 4)) * spd; if (xs > 850) return;
      s += `<g transform="translate(${f1(xs)} ${f1(y)}) scale(${n3(k)})"><g>${AT('translate', '0 0;-26 6', dur, -i * 0.9)}${P('M-10 0Q-4 -5 2 -1Q6 1 10 -1', 'none', '#ffffff', 1.6)}${AN('opacity', '0;0.9;0', dur, -i * 0.9)}</g></g>`; });
    if (!rainy) { const Rg = rng('glint' + sea); rep(sunny ? 18 : 8, i => { const y = 70 + Rg() * 310, x = shore(y) + 30 + Rg() * 380; if (x > 850) return; const dd = 1.8 + Rg() * 2; s += `<path d="M0 -3L0.6 -0.6L3 0L0.6 0.6L0 3L-0.6 0.6L-3 0L-0.6 -0.6Z" fill="#ffffff" transform="translate(${f1(x)} ${f1(y)}) scale(${n3(0.8 + Rg())})" opacity="0">${AN('opacity', '0;0;1;0', dd, -Rg() * dd)}</path>`; }); }
    if (nt) s += rep(14, i => { const y = 70 + i * 24, x = 600 + Math.sin(i * 1.7) * 10 + (y - 60) * 0.3, w = 6 + (i % 3) * 4; return `<path d="M${f1(x - w)} ${f1(y)}H${f1(x + w)}" stroke="#fff6c8" stroke-width="2" stroke-linecap="round" opacity="0.5">${AN('opacity', '0.15;0.6;0.15', 1.4 + (i % 4) * 0.3, -i * 0.2)}</path>`; }).join('');
    // buoy
    s += `<g transform="translate(772 150)"><g>${AT('translate', '0 0;0 -2.5;0 0', 2.6 * spd, 0, SPL(2))}${P(ell(0, 4, 9, 3), 'none', '#ffffff', 1.2, ' opacity="0.6"')}${P('M-6 4L-4 -10H4L6 4Z', NM('#e2554a', 0.5), NM('#7a2a20', 0.5), 1)}${P('M-5 -3H5', 'none', NM('#ffffff', 0.5), 2.4)}${P(circ(0, -12, 2.4), nt ? '#ffd66b' : NM('#ffe9a0', 0.4))}</g></g>`;
    if (nt) s += `<circle cx="772" cy="138" r="9" fill="url(#bzGlow)">${AN('opacity', '1;0.2;1', 2)}</circle>`;
    s += `</g>`;
    // sand
    s += P(sandPoly, 'url(#bzSand)');
    s += `<g clip-path="url(#bzSandC)">` + P(shoreOff(-12), 'none', wetC, 30, ` opacity="${rainy ? 0.7 : 0.5}" filter="url(#bzB3)"`);
    // sand texture by tier
    const Rt = rng('sand' + st);
    rep(44, i => { const y = 112 + Rt() * 280, x = X.edge(y) + Rt() * (shore(y) - X.edge(y)), k = WY(y); s += P(`M${f1(x - 7 * k)} ${f1(y)}q${f1(7 * k)} ${f1(-3 * k)} ${f1(14 * k)} 0`, 'none', i % 2 ? sandL : sandD, 1.1, ' opacity="0.6"'); });
    if (st === 1) { rep(36, i => { const y = 112 + Rt() * 280, x = X.edge(y) + 20 + Rt() * (shore(y) - X.edge(y) - 30), k = WY(y); s += P(ell(x, y, 2.4 * k, 1.5 * k), NM(['#9a948a', '#b4ada0', '#7f786e'][i % 3], 0.5), NM('#5e584e', 0.5), 0.5); });
      [[230, 300], [420, 208], [150, 250]].forEach(([x, y], i) => s += P(`M${x - 12} ${y}q4 -6 8 -1t8 -2t8 1`, 'none', NM('#3f6a3a', 0.5), 2.4) + P(`M${x - 8} ${y + 2}q5 -4 10 0`, 'none', NM('#5a8a44', 0.5), 1.6));
      s += `<g transform="translate(330 330) rotate(-24)">${P(rr(-7, -4, 14, 8, 2), NM('#d84a3a', 0.5), NM('#7a2a20', 0.5), 1)}${P('M-7 -1.4H7', 'none', NM('#ffffff', 0.5), 1.4)}${P(ell(7, 0, 1.2, 4), NM('#c9cdd2', 0.5))}</g>`; }
    else if (st === 2) { for (let r = 0; r < 9; r++) { const y0 = 150 + r * 24; let dd = ''; for (let x = X.edge(y0) + 40; x < shore(y0) - 30; x += 12) dd += (dd ? 'L' : 'M') + f1(x) + ' ' + f1(y0 + Math.sin(x * 0.04 + r) * 2.2); if (dd) s += P(dd, 'none', sandD, 1.4, ' opacity="0.5"'); } }
    else if (st === 3) rep(70, i => { const y = 112 + Rt() * 280, x = X.edge(y) + Rt() * (shore(y) - X.edge(y)); s += P(circ(x, y, 0.8 + Rt() * 0.8), ['#ffffff', '#ffd8cc', '#fff4d8'][i % 3], '', 0, ' opacity="0.9"'); });
    else if (st === 4) rep(34, i => { const y = 112 + Rt() * 280, x = X.edge(y) + Rt() * (shore(y) - X.edge(y)), k = WY(y); s += P(`M${f1(x)} ${f1(y - 2 * k)}l${f1(2.6 * k)} ${f1(1.2 * k)}l${f1(-0.8 * k)} ${f1(2.2 * k)}l${f1(-2.6 * k)} ${f1(-0.6 * k)}Z`, NM(['#7fe0d0', '#a6e8f6', '#c4f0b0', '#ff9db0'][i % 4], 0.5), '#ffffff', 0.5, ' opacity="0.9"'); });
    else rep(46, i => { const y = 112 + Rt() * 280, x = X.edge(y) + Rt() * (shore(y) - X.edge(y)), dd = 1.4 + Rt() * 2; s += `<path d="M0 -2.6L0.5 -0.5L2.6 0L0.5 0.5L0 2.6L-0.5 0.5L-2.6 0L-0.5 -0.5Z" fill="${['#fff6c8', '#ffffff', '#ffe08a', '#d8f6ff'][i % 4]}" transform="translate(${f1(x)} ${f1(y)})" opacity="0">${AN('opacity', '0;1;0;0', dd, -Rt() * dd)}</path>`; });
    if (rainy) rep(6, i => { const y = 170 + i * 30, x = X.edge(y) + 70 + ((i * 131) % Math.max(40, shore(y) - X.edge(y) - 150)), k = WY(y); s += P(ell(x, y, 26 * k, 7 * k), NM('#8fb0bc', 0.5), NM('#6a8a96', 0.5), 1, ' opacity="0.85"') + P(ell(x - 6 * k, y - 2 * k, 10 * k, 2 * k), '#ffffff', '', 0, ' opacity="0.4"') + rep(2, j => `<ellipse cx="${f1(x + (j ? 8 : -6) * k)}" cy="${f1(y)}" rx="1" ry="0.4" fill="none" stroke="#ffffff" stroke-width="0.8"><animate attributeName="rx" values="1;${f1(9 * k)}" dur="1.2s" begin="${n3(-j * 0.6 - i * 0.2)}s" repeatCount="indefinite"/><animate attributeName="ry" values="0.4;${f1(3 * k)}" dur="1.2s" begin="${n3(-j * 0.6 - i * 0.2)}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.9;0" dur="1.2s" begin="${n3(-j * 0.6 - i * 0.2)}s" repeatCount="indefinite"/></ellipse>`).join(''); });
    if (snowy) { const Rn = rng('snowp'); rep(16, i => { const y = 130 + Rn() * 260, x = X.edge(y) + Rn() * (shore(y) - X.edge(y)), k = WY(y); s += P(`M${f1(x - 22 * k)} ${f1(y)}C${f1(x - 18 * k)} ${f1(y - 8 * k)} ${f1(x + 14 * k)} ${f1(y - 9 * k)} ${f1(x + 24 * k)} ${f1(y)}C${f1(x + 10 * k)} ${f1(y + 6 * k)} ${f1(x - 12 * k)} ${f1(y + 5 * k)} ${f1(x - 22 * k)} ${f1(y)}Z`, NM('#ffffff', 0.45), NM('#cfdde6', 0.5), 0.8, ' opacity="0.92"'); }); }
    s += `</g>`;
    // ice sheet (snowy)
    if (snowy) { const IC = 'M' + SH.filter(q => q[1] >= 90).map(q => f1(q[0] - 4) + ' ' + f1(q[1])).join('L') + 'L' + SH.filter(q => q[1] >= 90).reverse().map(q => f1(q[0] + icew * WY(q[1]) + Math.sin(q[1] * 0.08) * 6) + ' ' + f1(q[1])).join('L') + 'Z';
      s += P(IC, NM('#e6f6fb', 0.5), NM('#a8d8ea', 0.5), 2, ' opacity="0.95"') + rep(9, i => { const y = 120 + i * 30, x = shore(y) + 12 + (i % 3) * 12; return P(`M${f1(x)} ${f1(y)}l9 4l-3 8l10 5`, 'none', NM('#a8cfe0', 0.5), 1); }).join('') + P(shoreOff(icew), 'none', '#ffffff', 2, ' opacity="0.8"'); }
    // foam lines (waves lapping)
    const fo = snowy ? icew : 0, fd = 4.2 * spd;
    [[2, 0, 3.6, 0.95], [16, -fd / 2, 2.2, 0.6]].forEach(([dx, b, w, op]) => s += `<g>${AT('translate', `0 0;${f1(-8 * (rainy ? 1.6 : 1))} 1;0 0`, fd, b, SPL(2))}<path d="${shoreOff(fo + dx)}" fill="none" stroke="#ffffff" stroke-width="${w}" stroke-linecap="round" stroke-dasharray="${rainy ? '18 6' : '26 10'}" opacity="${op}">${AN('opacity', `${op};${n3(op * 0.4)};${op}`, fd, b)}</path></g>`);
    if (lt === 5) s += `<g>${AT('translate', '0 0;-8 1;0 0', fd, 0, SPL(2))}<path d="${shoreOff(fo + 4)}" fill="none" stroke="#7af6ff" stroke-width="${nt ? 6 : 3}" stroke-linecap="round" stroke-dasharray="3 9" opacity="${nt ? 0.95 : 0.5}">${AN('stroke-dashoffset', '0;-24', 3)}</path><path d="${shoreOff(fo + 4)}" fill="none" stroke="#4fe0f0" stroke-width="${nt ? 18 : 8}" opacity="${nt ? 0.35 : 0.15}" filter="url(#bzB3)"/></g>`;
    // back dunes + palms
    s += P('M-20 60C40 30 110 22 170 34C230 46 290 20 360 30C400 36 430 46 452 60L-20 60Z', 'url(#bzDune2)');
    const palm = (x, y, k, lean, ph) => { const tx = x + lean * 40 * k, ty = y - 90 * k; let fr = ''; rep(7, i => { const a = -PI * 0.95 + i * PI * 0.32 + (i % 2) * 0.1, L = (36 + (i % 3) * 6) * k, ex = tx + Math.cos(a) * L, ey = ty + Math.sin(a) * L * 0.62 + L * 0.28, mx = tx + Math.cos(a) * L * 0.5, my = ty + Math.sin(a) * L * 0.5 - 8 * k;
        fr += P(`M${f1(tx)} ${f1(ty)}Q${f1(mx)} ${f1(my)} ${f1(ex)} ${f1(ey)}Q${f1(mx + 4 * k)} ${f1(my + 6 * k)} ${f1(tx)} ${f1(ty + 2 * k)}Z`, NM(i % 2 ? '#3f9a42' : '#4fb04a', 0.55), NM('#22602a', 0.55), 1.1) + (snowy ? P(`M${f1(tx)} ${f1(ty)}Q${f1(mx)} ${f1(my)} ${f1(ex)} ${f1(ey)}`, 'none', '#ffffff', 2.2 * k, ' opacity="0.85"') : ''); });
      return `<g>${P(`M${f1(x - 5 * k)} ${f1(y)}Q${f1(x + lean * 10 * k)} ${f1(y - 50 * k)} ${f1(tx - 2 * k)} ${f1(ty)}L${f1(tx + 3 * k)} ${f1(ty)}Q${f1(x + lean * 14 * k + 6 * k)} ${f1(y - 50 * k)} ${f1(x + 5 * k)} ${f1(y)}Z`, NM('#b07a44', 0.55), NM('#5e3c1c', 0.55), 1.2)}${rep(6, i => { const t = (i + 1) / 7, cx = x + (tx - x) * t * t * 0.9 + lean * 4 * k * t; return P(`M${f1(cx - 4.5 * k)} ${f1(y - (y - ty) * t)}h${f1(9 * k)}`, 'none', NM('#7a4e24', 0.55), 1); }).join('')}<g>${AT('rotate', `-2.5 ${f1(tx)} ${f1(ty)};2.5 ${f1(tx)} ${f1(ty)};-2.5 ${f1(tx)} ${f1(ty)}`, 5 * (rainy ? 0.5 : 1), ph, SPL(2))}${fr}${P(circ(tx - 3 * k, ty + 4 * k, 3.4 * k), NM('#7a4e24', 0.5))}${P(circ(tx + 3 * k, ty + 5 * k, 3.4 * k), NM('#8a5a2c', 0.5))}</g></g>`; };
    s += palm(70, 50, 0.62, 0.5, 0) + palm(196, 40, 0.5, -0.4, -1.4) + palm(318, 44, 0.56, 0.6, -2.6);
    // front dune bank (left side + back)
    const DF = 'M-20 272L0 262Q44 180 96 94Q250 80 480 86Q520 80 540 64L540 54C490 42 400 40 330 46C270 54 230 30 170 40C110 50 70 30 30 46C10 54 -6 70 -20 84Z';
    s += P(DF, 'url(#bzDune)', NM(shade(sand, 0.72), 0.3), 1.6);
    s += P('M-10 250Q38 172 90 100Q240 86 470 92', 'none', NM(shade(sand, 0.8), 0.3), 10, ' opacity="0.35" filter="url(#bzB3)"');
    if (snowy) s += P('M-20 84C-6 70 10 54 30 46C70 30 110 50 170 40C230 30 270 54 330 46C380 40 430 44 470 54L466 62C420 54 380 50 330 56C270 64 230 40 170 50C110 60 70 40 34 56C14 64 0 80 -20 96Z', NM('#ffffff', 0.45), NM('#cfdde6', 0.5), 1);
    // gate back to the Backyard (left side)
    const g = gate('L', o.gateLock || 0, 'BACKYARD');
    s += P('M18 236Q60 230 110 226L140 214Q80 210 44 196Z', mix(sand, '#ffffff', 0.18), '', 0, ' opacity="0.8"') + polySvg(g.polys) + g.texts.map(textSvg).join('');
    // ---------- pier ----------
    const PR = PIERS[pt - 1], X0 = PIER.x0, Y0 = PIER.y0, Y1 = PIER.y1, XE = PIER.xe, Q0 = PIER.py0, Q1 = PIER.py1, XP = PIER.xp1, FC = PIER.face, pa = NM(PR.a, 0.5), pb = NM(PR.b, 0.5), pe = NM(PR.e, 0.5), pf = NM(PR.face, 0.5), pp = NM(PR.post, 0.5);
    s += P(`M${X0 + 30} ${Y1 + FC}H${XE}V${Q1 + FC}H${XP + 6}L${XP + 10} ${Q1 + FC + 12}H${X0 + 40}Z`, '#06324a', '', 0, ' opacity="0.22" filter="url(#bzB3)"');
    rep(Math.floor((XP - X0 - 40) / 44) + 1, i => { const x = X0 + 44 + i * 44, yb = x > XE ? Q1 : Y1; if (x > XP) return; const crook = pt === 1 ? (i % 2 ? 2 : -1.5) : 0;
      s += P(`M${f1(x - 3)} ${yb}L${f1(x - 3 + crook)} ${yb + FC + 13}H${f1(x + 3 + crook)}L${f1(x + 3)} ${yb}Z`, pp, NM('#2a1c10', 0.5), 1) + `<ellipse cx="${f1(x + crook)}" cy="${yb + FC + 13}" rx="5" ry="1.6" fill="none" stroke="#ffffff" stroke-width="1" opacity="0.7">${AN('rx', '4;8;4', 2.4 * spd, -i * 0.3)}</ellipse>`; });
    // front faces
    s += P(`M${X0} ${Y1}H${XE}V${Y1 + FC}H${X0 + 8}Z`, pf, pe, 1.2) + P(`M${XE} ${Q1}H${XP}V${Q1 + FC}H${XE}Z`, pf, pe, 1.2) + P(`M${XP} ${Q0}L${XP + 6} ${Q0 + 8}V${Q1 + FC + 6}L${XP} ${Q1 + FC}Z`, shade(pf, 0.82), pe, 1.2);
    if (snowy) s += rep(14, i => { const x = X0 + 30 + i * 21; return P(`M${x} ${x > XE ? Q1 + FC : Y1 + FC}l2 ${6 + (i % 3) * 3}l2 ${-(6 + (i % 3) * 3)}Z`, '#eaf8ff', '#b8dcec', 0.6); }).join('');
    // decks
    s += P(`M${X0 + 6} ${Y0}H${XE}V${Q0}H${XP}V${Q1}H${XE}V${Y1}H${X0}Z`, pa, pe, 1.6);
    let pl = ''; for (let x = X0 + 14; x < XP - 2; x += 9) { const top = x > XE ? Q0 : Y0, bot = x > XE ? Q1 : Y1; pl += `M${f1(x)} ${top + 1}L${f1(x)} ${bot - 1}`; } s += P(pl, 'none', pe, 0.8, ' opacity="0.55"');
    for (let x = X0 + 18, j = 0; x < XP - 4; x += 18, j++) if (j % 2) s += P(rr(x - 8, x > XE ? Q0 + 2 : Y0 + 2, 8, (x > XE ? Q1 - Q0 : Y1 - Y0) - 4, 0.5), pb, '', 0, ' opacity="0.8"');
    if (pt === 1) [[X0 + 120, 0], [X0 + 174, 1], [XE + 30, 2]].forEach(([x, j]) => { const top = x > XE ? Q0 : Y0, bot = x > XE ? Q1 : Y1; s += P(rr(x, top + (j === 1 ? 8 : 1), 8, (bot - top) - (j === 1 ? 9 : 2), 0.5), NM('#1a5a7a', 0.5), NM('#3a3020', 0.5), 0.8); });
    if (snowy) s += P(`M${X0 + 8} ${Y0 + 2}H${XE}V${Q0 + 2}H${XP - 2}`, 'none', '#ffffff', 3, ' opacity="0.85"') + rep(8, i => P(ell(X0 + 40 + i * 36, i % 2 ? Y0 + 6 : Y1 - 5, 7, 2), '#ffffff', '', 0, ' opacity="0.75"')).join('');
    // back rail
    const railPosts = []; for (let x = X0 + 24; x <= XE; x += 36) railPosts.push([x, Y0]); railPosts.push([XE, Q0], [XE + 43, Q0], [XP - 2, Q0]);
    if (PR.rail === 'rope') { railPosts.forEach(([x, y]) => s += P(rr(x - 1.8, y - 16, 3.6, 16, 1), pp, NM('#3a2614', 0.5), 0.8)); let rp = ''; for (let i = 0; i < railPosts.length - 1; i++) { const a = railPosts[i], b = railPosts[i + 1]; rp += `M${a[0]} ${a[1] - 13}Q${(a[0] + b[0]) / 2} ${(a[1] + b[1]) / 2 - 7} ${b[0]} ${b[1] - 13}`; } s += P(rp, 'none', NM('#e2c890', 0.5), 1.8);
      s += `<g transform="translate(${XP - 14} ${Q0 - 6})">${P(circ(0, 0, 7), 'none', NM('#e2554a', 0.45), 3.4)}${P('M-7 0H-4M4 0H7M0 -7V-4M0 4V7', 'none', NM('#ffffff', 0.45), 3.4)}</g>`; }
    else if (PR.rail) { const rc = NM(PR.rail === 'white' ? '#ffffff' : PR.rail === 'teak' ? '#8a4e24' : '#e2b14a', 0.45), ro = NM(PR.rail === 'white' ? '#9aa4b0' : PR.rail === 'teak' ? '#4a2810' : '#9a6a10', 0.45), ht = PR.rail === 'gold' ? 20 : 16;
      let bal = ''; railPosts.forEach(([x, y]) => bal += P(rr(x - 2, y - ht, 4, ht, 1), rc, ro, 0.8)); for (let i = 0; i < railPosts.length - 1; i++) { const a = railPosts[i], b = railPosts[i + 1]; for (let k = 1; k < 4; k++) { const x = a[0] + (b[0] - a[0]) * k / 4, y = a[1] + (b[1] - a[1]) * k / 4; bal += PR.rail === 'gold' ? P(ell(x, y - ht / 2, 1.6, ht / 2 - 1), rc, ro, 0.5) : P(`M${f1(x)} ${f1(y)}V${f1(y - ht + 3)}`, 'none', rc, 1.3); } }
      s += bal + P('M' + railPosts.map(q => q[0] + ' ' + (q[1] - ht)).join('L'), 'none', ro, 4.2) + P('M' + railPosts.map(q => q[0] + ' ' + (q[1] - ht)).join('L'), 'none', rc, 2.6);
      if (PR.rail === 'teak') { [XE + 4, XP - 4].forEach((x, j) => { s += P(`M${x} ${Q0}V${Q0 - 52}`, 'none', NM('#f4f1ea', 0.45), 2) + `<g transform="translate(${x} ${Q0 - 52})">${P('M0 0L16 4L0 9Z', NM(j ? '#3f7fc8' : '#e2554a', 0.45), NM('#2a2a40', 0.5), 0.8, '')}</g>`; }); let bn = ''; rep(9, i => { const t = (i + 0.5) / 9, x = XE + 4 + (XP - XE - 8) * t, y = Q0 - 48 + Math.sin(t * PI) * 8; bn += `<path d="M${f1(x - 3)} ${f1(y)}L${f1(x + 3)} ${f1(y)}L${f1(x)} ${f1(y + 7)}Z" fill="${NM(['#e2554a', '#ffd23f', '#3f7fc8', '#ffffff'][i % 4], 0.45)}"/>`; }); s += P(`M${XE + 4} ${Q0 - 48}Q${(XE + XP) / 2} ${Q0 - 36} ${XP - 4} ${Q0 - 48}`, 'none', NM('#3a2a20', 0.5), 0.8) + `<g>${AT('skewX', '-3;3;-3', 2.4, 0, SPL(2))}${bn}</g>`;
        [X0 + 80, X0 + 160, XE - 20].forEach(x => s += P(rr(x - 4, Y1 - 4, 8, 2.6, 1.2), NM('#e2b14a', 0.4), NM('#8a5d00', 0.4), 0.6)); }
      if (PR.rail === 'white' || PR.rail === 'gold') { const lamps = PR.rail === 'gold' ? [[X0 + 60, Y0], [XE - 10, Y0], [XE + 4, Q0], [XP - 4, Q0]] : [[X0 + 90, Y0], [XE - 40, Y0], [XP - 6, Q0]];
        lamps.forEach(([x, y]) => { const H = PR.rail === 'gold' ? 46 : 40, lc = PR.rail === 'gold' ? '#e2b14a' : '#2c2d31'; s += P(`M${x} ${y}V${y - H}`, 'none', NM(lc, 0.4), 2.6) + (PR.rail === 'gold' ? P(`M${x - 5} ${y - H}h10l-2 -10h-6Z`, NM('#fff1b8', nt ? 0 : 0.3), NM('#9a6a10', 0.4), 1) + P(`M${x - 6} ${y - H - 10}h12l-6 -6Z`, NM('#e2b14a', 0.4)) : P(circ(x, y - H - 3, 4.4), NM('#fff6c8', nt ? 0 : 0.3), NM('#2c2d31', 0.4), 1.2) + P(`M${x - 5} ${y - H - 6}h10`, 'none', NM('#2c2d31', 0.4), 2));
          if (nt) s += `<circle cx="${x}" cy="${y - H - 5}" r="26" fill="url(#bzGlow)"/>`; }); } }
    // fishing gear on the platform
    s += `<g transform="translate(${XP - 40} ${Q0 + 5})">${P('M-6 -9L-5 0H5L6 -9Z', NM('#9aa4ac', 0.45), NM('#4a5058', 0.45), 1)}${P(ell(0, -9, 6, 1.8), NM('#2a5a7a', 0.45), NM('#4a5058', 0.45), 0.8)}${P(rr(9, -6, 12, 7, 1.5), NM('#3f9a5a', 0.45), NM('#1e5a32', 0.45), 0.8)}${P('M-12 -1L-2 -34', 'none', NM('#6a4a2a', 0.45), 1.4)}${P('M-2 -34Q4 -20 2 -6', 'none', NM('#ffffff', 0.45), 0.5, ' opacity="0.8"')}</g>`;
    // ---------- lights ----------
    const glow = (x, y, r, c) => nt ? `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="url(#${c || 'bzGlow'})"/>` : '';
    if (lt === 1) { const lx = X0 + 30, ly = Y0; s += P(`M${lx} ${ly}L${lx - 2} ${ly - 32}L${lx + 4} ${ly - 32}L${lx + 5} ${ly}Z`, NM('#9a7a56', 0.5), NM('#4a3a28', 0.5), 1) + P(rr(lx - 4, ly - 36, 12, 7, 2), NM('#3a3d44', 0.5), '', 0) + P(rr(lx, ly - 30, 4, 3, 1), NM('#c9c9c9', 0.5)); if (nt) s += glow(lx + 8, ly - 33, 22); }
    else if (lt === 2) [[X0 + 40, Y0], [X0 + 110, Y0], [XE - 20, Y0], [XP - 10, Q0]].forEach(([x, y]) => { s += P(`M${x} ${y}V${y - 12}`, 'none', NM('#3a3d44', 0.5), 1.6) + P(rr(x - 3.5, y - 19, 7, 7, 1.5), NM(nt ? '#fff6c8' : '#e6eef2', 0.3), NM('#3a3d44', 0.5), 0.8) + P(rr(x - 4.5, y - 21, 9, 2.5, 1), NM('#2a5aa8', 0.4)) + glow(x, y - 15, 20); });
    else if (lt === 3) [[X0 + 10, Y0 - 2], [XE - 10, Y0 - 2], [XP - 8, Q0 - 2]].forEach(([x, y], i) => { const k = WY(y); s += P(`M${x - 1.6 * k} ${y}L${x - 1.2 * k} ${f1(y - 34 * k)}H${f1(x + 1.2 * k)}L${f1(x + 1.6 * k)} ${y}Z`, NM('#8a6a3e', 0.5), NM('#4a3018', 0.5), 0.8) + P(`M${f1(x - 4 * k)} ${f1(y - 34 * k)}L${f1(x + 4 * k)} ${f1(y - 34 * k)}L${f1(x + 3 * k)} ${f1(y - 41 * k)}L${f1(x - 3 * k)} ${f1(y - 41 * k)}Z`, NM('#c49a5a', 0.5), NM('#6a4a20', 0.5), 0.8);
      const fy = y - 41 * k; s += `<g transform="translate(${x} ${f1(fy)}) scale(${n3(k)})"><path d="M0 -12C4 -7 4 -3 0 0C-4 -3 -4 -7 0 -12Z" fill="#ff8a2a">${AN('d', 'M0 -12C4 -7 4 -3 0 0C-4 -3 -4 -7 0 -12Z;M1 -14C5 -8 4 -3 0 0C-4 -3 -3 -8 1 -14Z;M-1 -11C3 -7 4 -3 0 0C-4 -3 -4 -6 -1 -11Z;M0 -12C4 -7 4 -3 0 0C-4 -3 -4 -7 0 -12Z', 0.9, -i * 0.2)}</path><path d="M0 -7C2 -4 2 -2 0 0C-2 -2 -2 -4 0 -7Z" fill="#ffe9a0"/></g>` + glow(x, fy - 4, 22) + (nt ? '' : `<circle cx="${x}" cy="${f1(fy - 4)}" r="8" fill="url(#bzGlow)" opacity="0.5"/>`); });
    else if (lt === 4) { const C = ['#ff9d4a', '#ffd66b', '#ff7aa0', '#6ac8ff', '#a6f06a'];
      const line = (x0, y0, ym, x1, y1, n, seed) => { const xm = (x0 + x1) / 2; let t = P(`M${x0} ${y0}Q${xm} ${ym} ${x1} ${y1}`, 'none', NM('#4a3a30', 0.5), 1); rep(n, i => { const u = (i + 0.5) / n, bx = (1 - u) * (1 - u) * x0 + 2 * (1 - u) * u * xm + u * u * x1, by = (1 - u) * (1 - u) * y0 + 2 * (1 - u) * u * ym + u * u * y1, c = C[(i + seed) % 5], h = 6 + (i % 2) * 2; t += P(`M${f1(bx)} ${f1(by)}v3`, 'none', NM('#4a3a30', 0.5), 0.8) + `<g transform="translate(${f1(bx)} ${f1(by + 3)})"><g>${AT('rotate', '-6;6;-6', 2.6, -i * 0.3, SPL(2))}${P(ell(0, h, h * 0.8, h), NM(c, nt ? 0 : 0.35), NM(shade(c, 0.6), 0.4), 0.8)}${P(`M${f1(-h * 0.8)} ${h}H${f1(h * 0.8)}`, 'none', NM(shade(c, 0.7), 0.4), 0.6)}</g></g>` + glow(bx, by + 3 + h, 16); }); return t; };
      s += P(`M${X0 + 24} ${Y0}V${Y0 - 34}M${XE} ${Y0}V${Y0 - 34}M${XP - 4} ${Q0}V${Q0 - 34}`, 'none', NM('#8a6a48', 0.5), 2) + line(X0 + 24, Y0 - 32, Y0 - 16, XE, Y0 - 32, 8, 2) + line(XE, Y0 - 32, Q0 - 22, XP - 4, Q0 - 32, 3, 1); }
    else if (lt === 5) { rep(7, i => { const x = 560 + (i * 47) % 260, y = 120 + (i * 53) % 200; if (nearPier(x, y)) return; s += `<g transform="translate(${x} ${y})"><g>${AT('translate', `0 0;${(i % 2 ? 6 : -6)} -8;0 0`, 4 + i * 0.6, -i, SPL(2))}<circle r="${nt ? 14 : 8}" fill="url(#bzCyan)"/><circle r="2.4" fill="#e8ffff"/></g></g>`; }); }
    // weather
    if (rainy) { const Rr = rng('rain'); s += `<g opacity="0.55">` + rep(70, i => { const x = Rr() * 900, dd = 0.5 + Rr() * 0.35; return `<path d="M0 0l-4 12" stroke="#e6eef4" stroke-width="1.1" stroke-linecap="round"><animateTransform attributeName="transform" type="translate" values="${f1(x)} -60;${f1(x - 30)} 400" dur="${n3(dd)}s" begin="${n3(-Rr() * dd)}s" repeatCount="indefinite"/></path>`; }).join('') + `</g>`; }
    if (snowy) { const Rs = rng('snowf'); s += rep(54, i => { const x = Rs() * 870 - 10, w = 8 + Rs() * 14, dd = 7 + Rs() * 6; return `<circle r="${f1(1.2 + Rs() * 1.8)}" fill="#ffffff" opacity="0.9"><animateTransform attributeName="transform" type="translate" values="${f1(x)} -60;${f1(x + w)} 110;${f1(x - w)} 260;${f1(x + w * 0.5)} 400" dur="${n3(dd)}s" begin="${n3(-Rs() * dd)}s" repeatCount="indefinite"/></circle>`; }).join(''); }
    if (sunny && !nt) { s += rep(2, i => `<g>${`<animateMotion dur="${18 + i * 7}s" begin="${-i * 9}s" repeatCount="indefinite" path="M-40 ${10 + i * 14}C200 ${-20 + i * 10} 500 ${30 + i * 6} 900 ${-4 + i * 12}"/>`}<path d="M-6 0Q-3 -3 0 0Q3 -3 6 0" fill="none" stroke="#4a5058" stroke-width="1.4" stroke-linecap="round">${AN('d', 'M-6 0Q-3 -3 0 0Q3 -3 6 0;M-6 -2Q-3 1 0 0Q3 1 6 -2;M-6 0Q-3 -3 0 0Q3 -3 6 0', 0.6, -i * 0.2)}</path></g>`).join(''); }
    return { defs: d, body: s };
  }
  // full SVG doc (catalog thumbs): kind 'ground' | 'fence' | 'ylight'
  function thumb(kind, tier) {
    const o = { season: 'sunny', sand: kind === 'ground' ? tier : 3, pier: kind === 'fence' ? tier : 2, light: kind === 'ylight' ? tier : 0, night: kind === 'ylight' };
    const sc = scene(o), vb = kind === 'ground' ? '140 186 360 200' : kind === 'fence' ? '470 150 382 140' : tier === 5 ? '470 90 382 240' : tier === 1 ? '280 40 200 120' : tier === 4 ? '80 10 420 160' : '20 60 420 200';
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${vb}" preserveAspectRatio="xMidYMid slice"><defs>${sc.defs}</defs>${sc.body}</svg>`;
  }
  // ---------- props drawn as HTML (depth-sorted with creatures) ----------
  const SHELLK = [['#ffd2c4', '#e8907a'], ['#fff1d8', '#d8b480'], ['#ffc6dc', '#d8708e'], ['#cfeefb', '#6aa8c8'], ['#ffe9a0', '#d8a440']];
  function shellSvg(k) { const [a, b] = SHELLK[k % SHELLK.length];
    const body = k % 3 === 0 ? `${P('M-9 3C-9-6 9-6 9 3Q0 6-9 3Z', a, b, 1.2)}${P('M0 4L0-4M-4 4L-2-4M4 4L2-4M-7 3L-5-2M7 3L5-2', 'none', b, 0.8)}${P(rr(-3, 3, 6, 3, 1), a, b, 1)}`
      : k % 3 === 1 ? `${P('M-8 4Q-10-2-2-6Q8-8 9 0Q8 5 0 5Z', a, b, 1.2)}${P('M-6 2Q0-2 6 1M-4 -2Q2-4 6-2', 'none', b, 0.8)}${P('M8 0l4 3', 'none', b, 1.4)}`
      : `${P('M0-8L2.4-2.6L8-2.6L3.6 1L5.4 7L0 3.6L-5.4 7L-3.6 1L-8-2.6L-2.4-2.6Z', a, b, 1.2)}${P(circ(0, 0, 1.2), b)}`;
    return 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="-14 -12 28 22">${P(ell(0, 5, 9, 2.4), '#3a2210', '', 0, ' opacity="0.18"')}${body}${P(ell(-3, -2, 2.4, 1.2), '#ffffff', '', 0, ' opacity="0.6"')}</svg>`); }
  function snowmanSvg(i) { const sc = ['#e2554a', '#3f7fc8', '#4fae5a'][i % 3];
    return 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="-30 -84 60 92"><radialGradient id="sn" cx="38%" cy="32%" r="70%"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#cfe0ea"/></radialGradient>${P(ell(0, 4, 22, 5), '#2a3a50', '', 0, ' opacity="0.2"')}${P(circ(0, -14, 19), 'url(#sn)', '#9ab4c6', 1.5)}${P(circ(0, -44, 14), 'url(#sn)', '#9ab4c6', 1.5)}${P(circ(0, -66, 10), 'url(#sn)', '#9ab4c6', 1.5)}${P('M-12 -56Q0 -50 12 -56L13 -51Q0 -45 -13 -51Z', sc, shade(sc, 0.6), 1)}${P('M8 -52l4 14l-6 0Z', sc, shade(sc, 0.6), 1)}${P(circ(-3.5, -69, 1.4), '#2a2a30')}${P(circ(3.5, -69, 1.4), '#2a2a30')}${P('M0 -66l8 2l-8 2Z', '#ff8a2a', '#c4561c', 0.6)}${P('M-4 -61q4 3 8 0', 'none', '#2a2a30', 1.1)}${P(circ(0, -42, 1.6), '#2a2a30')}${P(circ(0, -34, 1.6), '#2a2a30')}${P('M-13 -46L-26 -54M-24 -53l-2 -5M13 -46L26 -56M24 -55l3 -4', 'none', '#7a5434', 1.6)}${P('M-10 -74H10L7 -76V-84H-7V-76Z', '#2c2d31', '#16171a', 1)}${P('M-7 -77H7', 'none', sc, 1.6)}</svg>`); }
  const SNOWMEN = [[210, 286], [120, 214]];
  function props(o) { const out = []; if (o.season === 'snowy') SNOWMEN.forEach(([x, y], i) => out.push({ id: 'sm' + i, x, y, w: 60, h: 92, ax: 30, ay: 84, src: snowmanSvg(i), kind: 'snowman' })); return out; }

  // ---------- room + shells ----------
  X.ROOMS.beach = { name: 'Beach', unlock: LV, out: 1, beach: 1, visit: 1, doors: [{ s: 'L', to: 'backyard', lab: 'BACKYARD' }], start: [['', 230, 210], ['', 330, 262], ['', 170, 300]], toys: [['ball', 380, 300]] };
  if (!X.RKEYS.includes('beach')) X.RKEYS.push('beach');
  if (X.NAME) X.NAME.beach = 'BEACH';
  const shell0 = X.shell, AUG = new WeakMap(), BSH = {};
  function beachShell() {
    if (BSH.s) return BSH.s; const g = gate('L', 0, 'BACKYARD');
    const P0 = { b0: '#9fd6f4', b1: '#e3f4fb', l0: '#e9cf98', l1: '#f1dcae', r0: '#5ec4ea', r1: '#8fd8f0', w0: '#e9cf98', w1: '#e2c48a', wr0: '#5ec4ea', wr1: '#4fb8e2', trim: '#f1dcae', pat: '#9fd6f4', f0: '#ead09a', f1: '#f1d9a6', f2: '#f6e2b6', fl: '#d8b878', fd: '#d8b878', fli: '#fbefd2', edge: '#8a6a3a', op: [0, 0, 0], door: '#84b6c9', doorL: '#b4d6e2' };
    return (BSH.s = { P: P0, decor: [], texts: [], doors: [{ id: 'g-backyard', to: 'backyard', hit: g.hit, spawn: g.spawn, walk: g.walk, lock: 0 }], floor: { lines: '', dark: '', light: '', tiles: [] }, fop: [0, 0, 0], wall: 'siding', out: true, beach: true, dark: false, rusty: false, name: 'Beach', light: null });
  }
  X.shell = function (rk, sf, lockOf) {
    if (rk === 'beach') return beachShell();
    // Nov 7 (user): no beach gate / BEACH sign in the garden any more; the Beach is reached from the map (arrivals from it use the house's default spawn)
    const sh = shell0(rk, sf, lockOf); if (rk !== 'backyard' || !sh || !window.BEACH_GATE) return sh;
    const lk = lockOf ? (lockOf('beach') || 0) : 0; let m = AUG.get(sh); if (!m) AUG.set(sh, m = {}); if (m[lk]) return m[lk];
    const g = gate('R', lk, lk ? 'Lv ' + lk + ' \u00b7 BEACH' : 'BEACH');
    return (m[lk] = Object.assign({}, sh, { decor: sh.decor.concat(g.polys), texts: sh.texts.concat(g.texts), doors: (sh.doors || []).concat([{ id: 'g-beach', to: 'beach', hit: g.hit, spawn: g.spawn, walk: g.walk, lock: lk }]) }));
  };
  window.Beach = { LV, PIER, FISH, shore, onPier, inSea, wet, clamp, randSand, randSea, itemX, nearPier, scene, thumb, props, shellSvg, SHELLK, gate, WY, rng,
    setSeason: s => { B.season = s || 'sunny'; }, season: () => B.season, ice, ready: 1 };
})();
