/* Squish Squad furniture catalogue: per-room decor with level locks, coin price, IAP price, room placement and perk. */
(function () {
  const O = 'stroke="#5b3a29"';
  const ROOMS = [
    { k: 'living', name: 'Living Room', perk: 'coins' },
    { k: 'kitchen', name: 'Kitchen', perk: 'food fill' },
    { k: 'bath', name: 'Bathroom', perk: 'cleaning speed' },
    { k: 'bed', name: 'Bedroom', perk: 'energy refill' },
    { k: 'dance', name: 'Dance Room', perk: 'slower draining' },
    { k: 'yard', name: 'Yard', perk: 'slower draining' },
  ];
  const pot = x => '<path d="M' + x + ' 16 h26 l-3 18 h-20 Z" fill="#d9774f" ' + O + ' stroke-width="2" stroke-linejoin="round"/>';
  const duck = x => '<g transform="translate(' + x + ' 0)"><ellipse cx="12" cy="27" rx="11" ry="7" fill="#ffd23a" ' + O + ' stroke-width="1.8"/><circle cx="15" cy="16" r="6.5" fill="#ffd23a" ' + O + ' stroke-width="1.8"/><path d="M21 16 l5 1.5 l-5 1.5Z" fill="#ff9a3c" ' + O + ' stroke-width="1"/><circle cx="16.5" cy="14.5" r="1.1" fill="#2a1a30"/></g>';
  const star = (x, y, c) => '<path transform="translate(' + x + ' ' + y + ')" d="M0 -7 L2 -2.2 L7 -2 L3 1.4 L4.4 6.4 L0 3.6 L-4.4 6.4 L-3 1.4 L-7 -2 L-2 -2.2Z" fill="' + c + '" ' + O + ' stroke-width="1.5" stroke-linejoin="round"/>';
  const ITEMS = [
    { id: 'l_art', room: 'living', name: 'Rainbow Art', perk: 0.08, lvl: 1, coins: 150, usd: 0.99, x: 664, y: 44, w: 100, h: 76,
      art: '<rect x="3" y="3" width="94" height="70" rx="6" fill="#c4844a" ' + O + ' stroke-width="3"/><rect x="11" y="11" width="78" height="54" rx="3" fill="#fff6e6" ' + O + ' stroke-width="2"/><path d="M22 54 A28 28 0 0 1 78 54" fill="none" stroke="#f2665a" stroke-width="6"/><path d="M29 54 A21 21 0 0 1 71 54" fill="none" stroke="#ffd66b" stroke-width="6"/><path d="M36 54 A14 14 0 0 1 64 54" fill="none" stroke="#7fae6a" stroke-width="6"/><circle cx="23" cy="56" r="6" fill="#fff" ' + O + ' stroke-width="1.5"/><circle cx="77" cy="56" r="6" fill="#fff" ' + O + ' stroke-width="1.5"/>' },
    { id: 'l_lamp', room: 'living', name: 'Cozy Lamp', perk: 0.12, lvl: 3, coins: 400, usd: 1.99, x: 800, y: 118, w: 46, h: 140,
      art: '<ellipse cx="23" cy="38" rx="22" ry="8" fill="#fff3b0" opacity=".7"/><path d="M6 34 L14 4 H32 L40 34 Z" fill="#ffd66b" ' + O + ' stroke-width="3" stroke-linejoin="round"/><rect x="21" y="34" width="4" height="96" fill="#8a5530" ' + O + ' stroke-width="1.5"/><ellipse cx="23" cy="132" rx="16" ry="5" fill="#a8693a" ' + O + ' stroke-width="2.5"/>' },
    { id: 'l_fish', room: 'living', name: 'Fishbowl', perk: 0.2, lvl: 5, coins: 900, usd: 2.99, x: 396, y: 106, w: 54, h: 44,
      art: '<ellipse cx="27" cy="25" rx="24" ry="17" fill="#bfe8f6" ' + O + ' stroke-width="2.5"/><path d="M6 30 Q27 36 48 30 Q44 41 27 42 Q10 41 6 30Z" fill="#ffd66b" opacity=".75"/><rect x="12" y="4" width="30" height="7" rx="3" fill="#e6f7fd" ' + O + ' stroke-width="2"/><path d="M20 23 q7 -6 14 0 q-7 6 -14 0Z M33 23 l6 -4 v8Z" fill="#ff9a3c" ' + O + ' stroke-width="1.2"/><circle cx="24" cy="22" r="1" fill="#2a1a30"/><circle cx="16" cy="16" r="2.2" fill="#fff" opacity=".85"/>' },
    { id: 'k_herb', room: 'kitchen', name: 'Herb Pots', perk: 0.1, lvl: 2, coins: 200, usd: 0.99, x: 176, y: 112, w: 140, h: 40,
      art: '<circle cx="18" cy="12" r="7" fill="#7fd06f" ' + O + ' stroke-width="1.8"/><circle cx="26" cy="9" r="6" fill="#5fb85a" ' + O + ' stroke-width="1.8"/><circle cx="64" cy="10" r="8" fill="#8fdc7a" ' + O + ' stroke-width="1.8"/><path d="M106 16 q-2 -12 4 -14 M113 16 q2 -12 8 -12 M118 16 q4 -8 10 -6" stroke="#5fb85a" stroke-width="3" fill="none" stroke-linecap="round"/>' + pot(9) + pot(53) + pot(100) + '<rect x="1" y="33" width="138" height="6" rx="3" fill="#a8693a" ' + O + ' stroke-width="2"/>' },
    { id: 'k_clock', room: 'kitchen', name: 'Kitty Clock', perk: 0.15, lvl: 4, coins: 450, usd: 1.99, x: 562, y: 132, w: 60, h: 70,
      art: '<path d="M12 22 L10 4 L24 14Z M48 22 L50 4 L36 14Z" fill="#ff9db0" ' + O + ' stroke-width="2.5" stroke-linejoin="round"/><circle cx="30" cy="36" r="24" fill="#fff6e6" ' + O + ' stroke-width="3"/><circle cx="30" cy="36" r="18" fill="none" stroke="#ffd66b" stroke-width="3"/><path d="M30 36 V22 M30 36 L39 41" stroke="#5b3a29" stroke-width="3" stroke-linecap="round"/><circle cx="30" cy="36" r="2.5" fill="#f2665a"/><path d="M30 60 q8 6 2 10" stroke="#5b3a29" stroke-width="2.5" fill="none" stroke-linecap="round"/>' },
    { id: 'k_plant', room: 'kitchen', name: 'Hanging Plant', perk: 0.25, lvl: 6, coins: 1000, usd: 2.99, x: 468, y: 10, w: 46, h: 104,
      art: '<path d="M23 0 V40 M23 0 L10 44 M23 0 L36 44" stroke="#8a5530" stroke-width="2"/><path d="M6 42 H40 L36 62 H10 Z" fill="#7fc8e8" ' + O + ' stroke-width="2.5" stroke-linejoin="round"/><path d="M10 60 q-6 18 -2 34 M16 62 q-2 14 2 26 M30 62 q4 16 -1 30 M37 60 q6 14 3 26" stroke="#5fb85a" stroke-width="3.2" fill="none" stroke-linecap="round"/><circle cx="8" cy="94" r="3.4" fill="#7fd06f" ' + O + ' stroke-width="1.2"/><circle cx="29" cy="92" r="3.4" fill="#7fd06f" ' + O + ' stroke-width="1.2"/><circle cx="18" cy="40" r="6" fill="#7fd06f" ' + O + ' stroke-width="1.5"/><circle cx="28" cy="39" r="6" fill="#5fb85a" ' + O + ' stroke-width="1.5"/>' },
    { id: 'b_duck', room: 'bath', name: 'Duck Shelf', perk: 0.15, lvl: 2, coins: 200, usd: 0.99, x: 266, y: 94, w: 86, h: 40,
      art: duck(2) + duck(30) + duck(58) + '<rect x="0" y="33" width="86" height="6" rx="3" fill="#e6f7fd" ' + O + ' stroke-width="2"/>' },
    { id: 'b_fern', room: 'bath', name: 'Spa Fern', perk: 0.2, lvl: 4, coins: 450, usd: 1.99, x: 486, y: 30, w: 76, h: 104,
      art: '<path d="M38 0 V30" stroke="#8a5530" stroke-width="2"/><path d="M16 30 H60 L54 56 H22 Z" fill="#fff6e6" ' + O + ' stroke-width="2.5" stroke-linejoin="round"/><path d="M20 44 H56" stroke="#9fd8f0" stroke-width="3"/><path d="M22 54 Q4 70 2 96 M30 56 Q22 76 24 102 M46 56 Q54 76 52 102 M54 54 Q72 70 74 96" stroke="#5fb85a" stroke-width="3.4" fill="none" stroke-linecap="round"/><path d="M38 30 Q30 14 22 18 M38 30 Q46 12 56 16" stroke="#7fd06f" stroke-width="3.4" fill="none" stroke-linecap="round"/>' },
    { id: 'b_bubble', room: 'bath', name: 'Bubble Machine', perk: 0.3, lvl: 7, coins: 1100, usd: 2.99, x: 774, y: 196, w: 66, h: 94,
      art: '<circle cx="18" cy="14" r="9" fill="rgba(210,244,255,0.7)" ' + O + ' stroke-width="1.5"/><circle cx="42" cy="8" r="6" fill="rgba(210,244,255,0.7)" ' + O + ' stroke-width="1.5"/><circle cx="52" cy="26" r="5" fill="rgba(210,244,255,0.7)" ' + O + ' stroke-width="1.5"/><circle cx="16" cy="11" r="2" fill="#fff"/><rect x="8" y="40" width="50" height="46" rx="10" fill="#c9b6f0" ' + O + ' stroke-width="3"/><circle cx="33" cy="58" r="10" fill="#fff6fb" ' + O + ' stroke-width="2.5"/><path d="M28 58 a5 5 0 0 1 10 0" stroke="#ff9db0" stroke-width="2" fill="none"/><rect x="14" y="84" width="10" height="8" rx="2" fill="#5b3a29"/><rect x="42" y="84" width="10" height="8" rx="2" fill="#5b3a29"/>' },
    { id: 'd_moon', room: 'bed', name: 'Moon Light', perk: 0.1, lvl: 3, coins: 250, usd: 0.99, x: 556, y: 52, w: 52, h: 60,
      art: '<path d="M26 0 V10" stroke="#5b3a29" stroke-width="2"/><circle cx="26" cy="36" r="24" fill="#fff3b0" opacity=".5"/><path d="M34 12 A22 22 0 1 0 44 50 A17 17 0 0 1 34 12Z" fill="#ffe680" ' + O + ' stroke-width="2.5" stroke-linejoin="round"/><circle cx="22" cy="32" r="1.6" fill="#5b3a29"/><path d="M20 40 q4 3 8 0" stroke="#5b3a29" stroke-width="1.8" fill="none" stroke-linecap="round"/>' },
    { id: 'd_stars', room: 'bed', name: 'Star Garland', perk: 0.15, lvl: 5, coins: 500, usd: 1.99, x: 194, y: 28, w: 124, h: 42,
      art: '<path d="M2 4 Q62 34 122 4" stroke="#5b3a29" stroke-width="2" fill="none"/>' + star(18, 16, '#ffd66b') + star(42, 25, '#ff9db0') + star(62, 28, '#9fd8f0') + star(82, 25, '#ffd66b') + star(106, 16, '#c9b6f0') },
    { id: 'd_rug', room: 'bed', name: 'Fluffy Rug', perk: 0.25, lvl: 7, coins: 1100, usd: 2.99, x: 326, y: 352, w: 200, h: 34,
      art: '<ellipse cx="100" cy="17" rx="97" ry="15" fill="#c9b6f0" ' + O + ' stroke-width="3"/><ellipse cx="100" cy="17" rx="74" ry="10" fill="#e4d9fb"/><ellipse cx="100" cy="17" rx="46" ry="6" fill="#c9b6f0"/>' },
    { id: 'n_neon', room: 'dance', name: 'Neon Sign', perk: 0.1, lvl: 4, coins: 300, usd: 0.99, x: 168, y: 22, w: 152, h: 48,
      art: '<rect x="2" y="2" width="148" height="44" rx="12" fill="#2b1d3a" ' + O + ' stroke-width="3"/><text x="76" y="33" text-anchor="middle" font-family="Fredoka, sans-serif" font-weight="700" font-size="24" fill="#fff" stroke="#ff4fbf" stroke-width="1.5" paint-order="stroke">PARTY</text><circle cx="16" cy="24" r="4" fill="#ffd66b"/><circle cx="136" cy="24" r="4" fill="#7cc8ff"/>' },
    { id: 'n_speaker', room: 'dance', name: 'Big Speaker', perk: 0.15, lvl: 6, coins: 600, usd: 1.99, x: 746, y: 112, w: 66, h: 110,
      art: '<rect x="3" y="3" width="60" height="104" rx="10" fill="#3a2a40" ' + O + ' stroke-width="3"/><circle cx="33" cy="30" r="13" fill="#5a4a60" ' + O + ' stroke-width="2.5"/><circle cx="33" cy="30" r="5" fill="#ff4fbf"/><circle cx="33" cy="74" r="20" fill="#5a4a60" ' + O + ' stroke-width="2.5"/><circle cx="33" cy="74" r="8" fill="#7cc8ff"/>' },
    { id: 'n_fog', room: 'dance', name: 'Fog Machine', perk: 0.25, lvl: 8, coins: 1200, usd: 2.99, x: 742, y: 300, w: 86, h: 60,
      art: '<ellipse cx="24" cy="14" rx="16" ry="9" fill="#fff" opacity=".85"/><ellipse cx="42" cy="10" rx="14" ry="8" fill="#fff" opacity=".7"/><rect x="6" y="24" width="74" height="30" rx="8" fill="#5a4a60" ' + O + ' stroke-width="3"/><rect x="14" y="32" width="22" height="12" rx="3" fill="#2b1d3a"/><circle cx="58" cy="38" r="5" fill="#7be495" ' + O + ' stroke-width="1.5"/><circle cx="71" cy="38" r="3" fill="#ffd66b"/>' },
    { id: 'y_flower', room: 'yard', name: 'Flower Bed', perk: 0.1, lvl: 3, coins: 250, usd: 0.99, x: 364, y: 348, w: 98, h: 40,
      art: '<path d="M14 22 v-10 M34 22 v-14 M54 22 v-12 M74 22 v-14 M88 22 v-9" stroke="#5f9a4a" stroke-width="2.5"/><circle cx="14" cy="10" r="5" fill="#ff9db0" ' + O + ' stroke-width="1.5"/><circle cx="34" cy="7" r="5" fill="#ffd66b" ' + O + ' stroke-width="1.5"/><circle cx="54" cy="9" r="5" fill="#f2665a" ' + O + ' stroke-width="1.5"/><circle cx="74" cy="7" r="5" fill="#c9b6f0" ' + O + ' stroke-width="1.5"/><circle cx="88" cy="12" r="4" fill="#ffd66b" ' + O + ' stroke-width="1.5"/><path d="M3 22 H95 V34 Q95 38 91 38 H7 Q3 38 3 34Z" fill="#a8693a" ' + O + ' stroke-width="2.5"/>' },
    { id: 'y_bird', room: 'yard', name: 'Birdhouse', perk: 0.15, lvl: 5, coins: 550, usd: 1.99, x: 792, y: 94, w: 52, h: 110,
      art: '<rect x="23" y="44" width="6" height="64" fill="#8a5530" ' + O + ' stroke-width="1.5"/><path d="M4 26 L26 6 L48 26Z" fill="#f2665a" ' + O + ' stroke-width="2.5" stroke-linejoin="round"/><rect x="9" y="24" width="34" height="26" rx="2" fill="#ffd66b" ' + O + ' stroke-width="2.5"/><circle cx="26" cy="36" r="5" fill="#5b3a29"/><rect x="24" y="44" width="4" height="4" fill="#8a5530"/>' },
    { id: 'y_lamp', room: 'yard', name: 'Garden Lamp', perk: 0.25, lvl: 8, coins: 1200, usd: 2.99, x: 192, y: 230, w: 34, h: 112,
      art: '<circle cx="17" cy="16" r="15" fill="#fff3b0" opacity=".55"/><path d="M8 8 H26 L23 26 H11 Z" fill="#ffe680" ' + O + ' stroke-width="2.5" stroke-linejoin="round"/><path d="M6 8 L17 1 L28 8Z" fill="#3a2a40" ' + O + ' stroke-width="2" stroke-linejoin="round"/><rect x="15" y="26" width="4" height="80" fill="#3a2a40"/><rect x="8" y="104" width="18" height="6" rx="2" fill="#3a2a40"/>' },
  ];
  const MAP = {};
  ITEMS.forEach(it => {
    const R = ROOMS.find(r => r.k === it.room);
    it.img = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + it.w + ' ' + it.h + '">' + it.art + '</svg>');
    it.usdLabel = '$' + it.usd.toFixed(2);
    it.perkText = '+' + Math.round(it.perk * 100) + '% ' + R.perk;
    MAP[it.id] = it;
  });
  const KEY = 'squishDecor';
  const owned = () => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { return []; } };
  const save = o => { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} };
  const perks = () => { const P = {}; owned().forEach(id => { const it = MAP[id]; if (it) P[it.room] = (P[it.room] || 0) + it.perk; }); return P; };
  window.SquishDecor = { ROOMS, ITEMS, get: id => MAP[id] || null, owned, save, perks };
})();
