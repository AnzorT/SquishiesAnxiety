// Pet Shop eating (Nov 9, user: 'now, lets do the same on the eating animations'): every Pet Shop creature eats all 20 foods its own way.
// A meal = receive the food (eyes go to it first, paws come up to take it, an eager lean) -> the creature's own ritual (sniff, snort, shy glance,
// inspect ...) -> the food's own beat (donut peek, pizza up high, fish jump) -> the food's eating style (chomp, nibble, typewriter, lick, whole,
// slurp, sip, big, gobble), built from the creature's own bite / chew / swallow -> its own after-habit (lick lips, pat belly, dab mouth ...) ->
// the food's reaction in the creature's own way (yum / love; spicy stays shared; sour + brain freeze rebuilt as natural shudders, not jitter).
// A natural bite: eyes on the food, head leans in, the mouth opens BEFORE the food arrives, snap, the head pulls back as the paws pull away (tears
// the bite off), then chewing with the jaw, cheeks and a small head bob, eyes half shut for the creatures that savour. pitch: NEGATIVE = head down.
(function boot() {
  const R = window.RiveRig; if (!R || !R.PETLIB || !R.EATLIB || !R.pokeV) { setTimeout(boot, 25); return; } if (R.eatV) return; R.eatV = 1;
  const { TL, S, hand, both, o, NOHANDS, jump, shake, swing, jelly, popcorn, croak, CARD, DESC } = R.PETLIB;
  const { FOODS, foodProp, HOLD, REACT } = R.EATLIB;
  const EAR = { biscuit: 0.45, mamapaws: 0.45, ribbit: 0, quill: 0.6, nibbles: 0.8, poppy: 0.8 };

  // ---------- the creature's own bite / chew / swallow (P = its eating card) ----------
  const prims = P => { const E = EAR[P.key] == null ? 1 : EAR[P.key], cr = P.crumbs || 1; let stash = 0;
    const C = {
      toMouth: (t, H, x, ms) => t.to(ms || P.reach || 280, o(H.mouth, { open: P.open || 0.7, pitch: -0.12, ly: 0.5, wide: 0.1, close: 0 }, x || {}), 'io'),
      snap: (t, n) => t.to(85, { open: 0, sq: 0.07, pitch: -0.07, earL: 4 * E, earR: 4 * E }, 'o').e('bite').e('emit', 'crumb', 'mouth', n || cr),
      back: (t, H, x) => t.to(260, o(H.chest, { sq: 0, earL: 0, earR: 0, pitch: 0.05, ly: 0.2, wide: 0 }, x || {}), 'io'),
      bite(t, H, last, i, q) { C.toMouth(t, H, q ? { open: 0.85 } : null, q ? 170 : null); C.snap(t); if (last) t.e('done'); return C.back(t, H); },
      chew(t, n, big) { n = Math.max(1, Math.round(n * (P.chewN || 1))); const h = P.chewMs || 135, pf = P.puff || 1; if (P.savor) t.to(140, { close: P.savor }, 'io');
        for (let i = 0; i < n; i++) t.to(h, { open: 0.22, puff: Math.max(stash, (big ? 1 : 0.65) * pf), sq: 0.025, mw: 0.85, pitch: -0.03, htilt: i % 2 ? 1.5 : -1.5 }, 'io')
          .to(h, { open: 0.02, puff: Math.max(stash, (big ? 0.85 : 0.5) * pf), sq: 0, mw: 1, pitch: 0.02 }, 'io');
        return t; },
      gulp(t) { if (P.stash) stash = Math.min(1.15, stash + P.stash); return t.to(150, { puff: stash, sq: 0.06, pitch: 0.16, open: 0, htilt: 0, close: 0 }, 'o').e('gulp').to(220, { sq: 0, pitch: 0 }, 'io'); },
      whole(t, H) { t.to(320, o(H.mouth, { open: 1, mw: 1.1, pitch: 0.08, wide: 0.3 }), 'io').to(110, { open: 0, mw: 1, puff: 1.1 * (P.puff || 1), sq: 0.08 }, 'o').e('bite').e('done')
        .to(300, o(H.chest, { sq: 0, wide: 0, hap: 1 }), 'io'); C.chew(t, 5, true); return C.gulp(t); },
      big(t, H) { t.to(380, o(H.mouth, { open: 1, mw: 1.45, pitch: 0.12, htilt: -6, wide: 0.5, sq: -0.05 }), 'io').wait(150).to(110, { open: 0, mw: 1, sq: 0.1, puff: 1.2, htilt: 0, wide: 0 }, 'o')
        .e('bite').e('emit', 'crumb', 'mouth', 5).to(300, o(H.chest, { sq: 0, pitch: 0.04 }), 'io'); C.chew(t, 6, true); C.gulp(t); C.bite(t, H, true); C.chew(t, 3); return C.gulp(t); },
    };
    ['bite', 'chew', 'gulp', 'whole', 'big', 'share'].forEach(k => { if (P[k]) C[k] = P[k](C, P); });
    C.end = () => { const v = stash; stash = 0; return v; };
    return C; };

  // ---------- the 9 eating styles (same beats as Mittens' library, built from C so each creature bites / chews / swallows its own way) ----------
  const STY = {
    chomp(t, H, f, C) { for (let i = 0; i < f.n; i++) { const last = i === f.n - 1; if (C.share && i === 1 && !last) { C.share(t, H); continue; } C.bite(t, H, last, i); C.chew(t, f.chew || 3); C.gulp(t); } },
    gobble(t, H, f, C) { for (let i = 0; i < f.n; i++) { const last = i === f.n - 1; if (C.share && i === 2 && !last) { C.share(t, H); continue; } C.bite(t, H, last, i, true); C.chew(t, 1); } C.gulp(t); },
    nibble(t, H, f, C) { t.to(320, o(H.mouth, { pitch: -0.08, ly: 0.5 }), 'io'); for (let i = 0; i < f.n; i++) t.to(85, { open: 0.3, mw: 0.6, sq: 0.02 }, 'o').to(85, { open: 0, sq: 0, puff: 0.45 }, 'io').e('bite').e('emit', 'crumb', 'mouth', 1);
      t.e('done'); C.back(t, H, { puff: 0.55, mw: 1 }); C.chew(t, 3); C.gulp(t); },
    typewriter(t, H, f, C) { const m = H.mouth; for (let row = 0; row < 2; row++) { t.to(300, o(m, { hLx: m.hLx + 6, hRx: m.hRx + 6, pitch: -0.08, ly: 0.4, hyaw: 0.15 }), 'io'); // the head follows along the corn / melon
        for (let i = 0; i < f.n; i++) { const p = 6 - (i + 1) * 12 / f.n; t.to(110, { open: 0.35, hLx: m.hLx + p, hRx: m.hRx + p, hyaw: -p / 32 }, 'io').to(90, { open: 0, sq: 0.03 }, 'o').e('bite').e('emit', 'crumb', 'mouth', 1); }
        t.to(170, { hLx: m.hLx + 6, hRx: m.hRx + 6, hyaw: 0.2, sq: 0, wide: 0.4 }, 'o').e('ding').to(120, { wide: 0 }); }
      t.e('done'); C.back(t, H, { hyaw: 0, puff: 0.7 }); C.chew(t, 3);
      if (f.seed) t.to(160, { puff: 0.3, mw: 0.45, open: 0.2, hyaw: 0.4 }, 'o').e('emit', 'seed', 'mouth').to(220, { open: 0, mw: 1, hyaw: 0 }); C.gulp(t); },
    lick(t, H, f, C) { const L = o(H.mouth); for (const q in L) if (/y$/.test(q)) L[q] += 3;
      t.to(320, o(L, { ly: 0.5, pitch: -0.05 }), 'io'); for (let i = 0; i < f.n; i++) t.to(170, { tongue: 1, pitch: 0.18, sq: -0.04, open: 0.12, close: 0.5, hyaw: f.swirl ? (i % 2 ? 0.22 : -0.22) : 0 }, 'io').e('lick').to(230, { tongue: 0.15, pitch: -0.05, sq: 0.01, open: 0 }, 'io');
      t.to(200, { tongue: 0, hyaw: 0, close: 0, hap: 1, smile: 0.8 }, 'io'); if (f.then) { C.bite(t, H, true); C.chew(t, 3); C.gulp(t); } else t.e('done').to(300, o(H.chest), 'io'); },
    whole(t, H, f, C) { C.whole(t, H); },
    big(t, H, f, C) { C.big(t, H); },
    slurp(t, H, f, C) { for (let i = 0; i < 3; i++) { t.to(220, { pitch: -0.25, ly: 0.6, mw: 0.5, open: 0.25 }, 'io'); const a = t.t; t.osc(700, 5, { sq: 0.04, open: 0.2, mw: 0.42 }, { sq: -0.01, open: 0.28, mw: 0.5 }, 's'); f.wins.push([a, t.t]);
      t.to(120, { open: 0, mw: 1, puff: 0.6, pitch: 0.05 }, 'o'); C.chew(t, 2); C.gulp(t); } t.e('done'); },
    sip(t, H, f, C) { t.to(320, o(f.mp || H.mouth, { pitch: -0.05 }), 'io').to(160, { mw: 0.42, open: 0.1, puff: -0.4 }, 'o').em(1800, 450, 'bubble', 'mouth', 1).osc(1800, 6, { puff: -0.5, sq: 0.03 }, { puff: -0.3, sq: 0 }, 's')
      .to(140, { puff: -0.6, sq: 0.06, wide: 0.4 }, 'o').e('crumple').to(260, o(H.chest, { mw: 1, open: 0, puff: 0, sq: 0, wide: 0 }), 'io').wait(300).e('done'); },
  };

  // ---------- shared beats ----------
  const recv = (t, H, P) => { const E = EAR[P.key] == null ? 1 : EAR[P.key]; return t.e('food').to(110, { ly: 0.7, wide: 0.5 }, 'o')                  // eyes on the food first ...
    .to(300, o(H.chest, { pitch: -0.18, sq: 0.05, earL: -6 * E, earR: -6 * E }), 'o').to(300, { wide: 0, smile: 0.8, sq: 0, earL: 0, earR: 0, pitch: -0.08 }, 'io').wait(150); }; // ... paws take it, an eager lean
  const sniffF = (t, n) => t.to(200, { pitch: -0.18, ly: 0.7 }, 'io').osc((n || 2) * 230, n || 2, { sq: 0.03, pitch: -0.13, mw: 0.85 }, { sq: 0, pitch: -0.18, mw: 1 }, 'o').to(200, { pitch: -0.05, hap: 1, smile: 1 }, 'io').to(150, { hap: 0 }, 'io');
  const lipLick = (t, big) => t.to(140, { tongue: big ? 1 : 0.8, open: big ? 0.3 : 0.15, hyaw: 0.12, pitch: big ? 0.08 : 0 }, 'o').to(170, { hyaw: -0.12 }, 'io').to(160, { tongue: 0, open: 0, hyaw: 0, pitch: 0 }, 'io');
  const sour = (t, P) => { t.to(130, { sqz: 1, mw: 0.4, open: 0.15, sq: 0.12, earL: 14, earR: 14, pitch: -0.15, puff: -0.3 }, 'o').wait(350);       // huge pucker ...
    shake(t, { P: 85, env: [0.5, 1, 0.9, 0.6, 0.3], head: 0.3, roll: 4, ear: 10, chest: 0.12, body: 0.6 });                                          // ... shakes it off (a real shudder, not a jitter)
    return t.to(350, { sqz: 0, mw: 1, open: 0, sq: 0, earL: 0, earR: 0, pitch: 0, puff: 0, smile: 0.6, hap: 1 }, 'io').wait(250); };
  const freeze = (t, P) => { const hy = P.headY || -22; t.to(150, { sqz: 1, sq: 0.08, frown: 0.5 }, 'o').to(300, P.armsUp ? { armL: 150, armR: 150, earL: 16, earR: 16 } : o(both(-1, hy), { armL: 30, armR: 30, earL: 16, earR: 16 }), 'io').wait(300); // brain freeze: paws to its head (snacks: arms swing up) ...
    shake(t, { P: 75, env: [0.4, 0.8, 1, 0.8, 0.5, 0.25], head: 0.16, roll: 3, ear: 8, body: 0.5 });                                                  // ... a shiver runs through it
    return t.to(400, o(NOHANDS, { sqz: 0, frown: 0, armL: 0, armR: 0, earL: 0, earR: 0, sq: 0, hap: 1, smile: 1 }), 'io').wait(300); };
  const hearts = (t, n) => t.e('emit', 'heart', 'head', n || 2);
  const wagF = (t, dur, a) => swing(t, dur, Math.max(3, Math.round(dur / 160)), { wag: a || 30 });
  const para = (t, from, fn) => { const e = t.t; t.at(from); fn(t); return t.at(Math.max(e, t.t)); };
  const pat = (t, n) => { t.to(260, both(9, 0), 'io'); for (let i = 0; i < (n || 3); i++) t.to(140, { hLy: 2, hRy: -1, sq: 0.03 }, 'io').to(140, { hLy: -1, hRy: 2, sq: 0 }, 'io'); return t.to(260, NOHANDS, 'io'); };
  const oink = t => t.to(120, { open: 0.55, mw: 0.8, pitch: 0.12 }, 'o').e('emit', 'note', 'head').to(200, { open: 0, mw: 1, pitch: 0 }, 'io');
  const wheek = t => t.to(130, { pitch: 0.2, open: 0.65, mw: 0.75, sq: -0.04 }, 'o').e('emit', 'note', 'head').to(220, { pitch: 0.16, open: 0.45 }, 'io').to(180, { pitch: 0, open: 0, mw: 1, sq: 0 }, 'io');
  const boof = t => t.to(110, { open: 0.85, mw: 0.85, sq: -0.07, pitch: 0.12 }, 'o').e('emit', 'note', 'head').to(200, { open: 0.15, mw: 1, sq: 0.03, pitch: 0 }, 'io').to(120, { sq: 0, open: 0 }, 'io');

  // ---------- each creature's eating card ----------
  const CARDS = {
    mittens: { // a neat kitten: sniffs it first, tidy bites, savours with half-shut eyes, licks his lips after
      savor: 0.5, txt: 'Sniffs it first, neat bites, savours it, licks his lips.', pre: t => sniffF(t, 2), post: t => lipLick(t), yum: t => REACT.yum(t), love: t => REACT.love(t) },
    biscuit: { // eager puppy: tail going the whole time, quick big bites, barely chews, crumbs fly, looks for more
      open: 0.85, crumbs: 3, chewN: 0.6, chewMs: 115, txt: 'Tail going the whole time, big quick bites, crumbs fly, licks his chops and looks for more.',
      recv: (t, H, P) => { const a = t.t; recv(t, H, P); para(t, a, u => wagF(u, t.t - a, 30)); },
      post: t => { lipLick(t, true); t.to(110, { lx: -0.8 }, 'o').wait(220).to(110, { lx: 0.8 }, 'o').wait(220).to(110, { lx: 0 }, 'o'); },
      yum: t => { t.to(200, { hap: 1, smile: 1, tongue: 0.7, open: 0.3 }, 'io'); const a = t.t; jump(t, { h: 7, ant: 140, up: 200, c: 0.14, arm: 30 }); para(t, a, u => wagF(u, t.t - a, 32)); },
      love: (t, P) => { CARDS.biscuit.yum(t, P); hearts(t, 2); t.to(300, { blush: 1 }, 'io'); } },
    truffle: { // messy piglet: snorts at it, big messy chomps, happy oinks, pats his belly
      crumbs: 4, puff: 1.15, open: 0.8, txt: 'Snorts at it, big messy chomps with crumbs everywhere, oinks, pats his belly.',
      pre: t => { t.to(80, { sq: 0.06, pitch: 0.1, mw: 0.75 }, 'o').to(170, { sq: 0, pitch: 0, mw: 1 }, 'io'); sniffF(t, 2); },
      post: t => { pat(t, 2); },
      yum: t => { oink(t); t.to(160, { sq: 0.12, hap: 1, smile: 1 }, 'io'); jelly(t, 0.1, 4, 230); },
      love: t => { oink(t); hearts(t, 2); t.to(160, { sq: 0.12, hap: 1, smile: 1, blush: 1 }, 'io'); jelly(t, 0.1, 4, 230); } },
    nibbles: { // hamster: quick nibbly bites and stuffs his cheeks instead of swallowing it all - they stay puffed, pats them, then swallows
      chewMs: 95, chewN: 1.4, stash: 0.35, puff: 1.1, open: 0.45, headY: -16, txt: 'Quick nibbly bites, stuffs his cheeks (they stay puffed), pats them, then swallows.',
      pre: t => { t.osc(500, 4, { sq: 0.025, pitch: -0.06, mw: 0.8 }, { sq: 0, pitch: -0.1, mw: 1 }, 'o'); },
      post: (t, P, C) => { const v = C.end(); t.to(260, o(both(1, -15), { puff: Math.max(0.9, v), hap: 1, smile: 1 }), 'io').osc(600, 2, { hLy: -16, hRy: -14 }, { hLy: -14, hRy: -16 }, 'io')
        .to(220, o(NOHANDS), 'io').to(800, { puff: 0, sq: 0.03 }, 'io').e('gulp').to(200, { sq: 0 }, 'io'); },
      yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io'); for (let i = 0; i < 3; i++) t.to(110, { sq: 0.05, lift: 1 }, 'o').to(130, { sq: 0, lift: 0 }, 'io'); },
      love: t => { hearts(t, 2); CARDS.nibbles.yum(t); t.to(200, { blush: 1 }, 'io'); } },
    quill: { // shy hedgehog: glances around first, small careful bites behind a paw, blushes
      open: 0.45, chewMs: 140, chewN: 0.9, txt: 'Glances around shyly first, small careful bites, blushes.',
      pre: t => { t.to(300, { hyaw: -0.25, lx: -0.6, blush: 0.6 }, 'io').wait(200).to(400, { hyaw: 0.25, lx: 0.6 }, 'io').wait(200).to(300, { hyaw: 0, lx: 0, ly: 0.5 }, 'io'); },
      post: t => t.to(300, { blush: 1, smile: 0.6, ly: 0.4, pitch: -0.08 }, 'io').wait(300).to(250, { ly: 0, pitch: 0 }, 'io'),
      yum: t => { t.to(200, { hap: 1, smile: 0.9, blush: 0.8 }, 'io'); swing(t, 1200, 3, { x: 1.6, bend: 2.5, htilt: -2 }); },
      love: t => { hearts(t, 1); t.to(300, o(both(2, -18), { hap: 1, blush: 1, smile: 0.7 }), 'io'); swing(t, 1200, 3, { x: 1.4, bend: 2 }); t.to(250, NOHANDS, 'io'); } },
    waffles: { // goofy corgi: a hop of excitement, wolfs it down, licks his nose, butt wiggle
      open: 0.9, crumbs: 2, chewN: 0.6, txt: 'Hops with excitement, wolfs it down, licks his nose, butt wiggle.',
      pre: t => jump(t, { h: 6, ant: 120, up: 170, c: 0.12, arm: 25 }),
      post: t => t.to(150, { tongue: 1, open: 0.35, pitch: 0.12 }, 'o').to(200, { tongue: 0.4 }, 'io').to(150, { tongue: 0, open: 0, pitch: 0 }, 'io'),
      yum: t => { t.to(150, { hap: 1, smile: 1, tongue: 0.6, open: 0.3 }, 'io'); swing(t, 1000, 9, { tilt: 5, x: 0.8, wag: 38 }); boof(t); },
      love: t => { hearts(t, 2); CARDS.waffles.yum(t); } },
    poppy: { // guinea pig: busy munching, nose twitching, wheeks for joy
      chewMs: 100, chewN: 1.6, open: 0.5, headY: -16, txt: 'Busy munching with a twitching nose, wheeks for joy.',
      pre: t => { t.osc(560, 4, { sq: 0.025, mw: 0.8 }, { sq: 0, mw: 1 }, 'o'); },
      post: t => wheek(t),
      yum: t => { popcorn(t, 10, 1, 500); },
      love: t => { hearts(t, 2); popcorn(t, 10, 1, 500); popcorn(t, 8, -1, 440); } },
    duchess: { // dignified Persian: inspects it, tiny dainty bites, savours with her eyes shut, dabs her mouth, chin up
      open: 0.4, crumbs: 0, savor: 0.85, chewMs: 145, chewN: 0.85, txt: 'Inspects it first, tiny dainty bites, savours with her eyes shut, dabs her mouth, chin up.',
      pre: t => { t.to(320, { htilt: 8, close: 0.4, ly: 0.6, pitch: -0.1 }, 'io'); sniffF(t, 1); t.to(240, { htilt: 0, close: 0, pitch: -0.12 }, 'io').to(200, { pitch: -0.04 }, 'io'); },
      post: t => { t.to(300, o(hand(1, 13, -15), { armR: 18 }), 'io').osc(500, 2, { hRy: -13 }, { hRy: -16 }, 'io').to(300, o(hand(1, 0, 0), { armR: 0, pitch: 0.15, close: 0.4 }), 'io').wait(250).to(250, { pitch: 0, close: 0 }, 'io'); },
      yum: t => { t.to(400, { pitch: 0.15, close: 1, smile: 0.9 }, 'io').to(500, { close: 0.35 }, 'io').wait(300).to(300, { pitch: 0, close: 0 }, 'io'); },
      love: t => { hearts(t, 1); CARDS.duchess.yum(t); } },
    mamapaws: { // gentle mum: shares with her pup - the pup gets a bite of everything that comes in pieces
      chewMs: 150, propZ: 12.5, txt: 'Shares with her pup: the pup gets one of the bites, then hearts.', // the food draws in front of the pup (12) so it shows when she feeds him
      share: (C, P) => (t, H) => { const L = H === HOLD.two ? both(7, 10) : hand(1, 8, 10); // just under the pup's chin
        t.to(380, o(L, { pitch: -0.28, ly: 0.9, smile: 1 }), 'io').wait(120).to(110, { sq: 0.03 }, 'o').e('bite').e('emit', 'crumb', [50, 70], 2).to(200, { sq: 0 }, 'io') // lowers it to the pup: the pup takes a bite
          .to(300, { hap: 1 }, 'io'); hearts(t, 1); t.wait(250).to(320, o(H.chest, { pitch: 0, ly: 0.2, hap: 0 }), 'io'); },
      post: t => t.to(350, { pitch: -0.25, ly: 0.8, smile: 1 }, 'io').wait(300).to(300, { pitch: 0, ly: 0 }, 'io'),
      yum: t => { hearts(t, 1); for (let i = 0; i < 2; i++) t.to(200, { sq: 0.1, hap: 1, smile: 1 }, 'io').to(240, { sq: -0.05, lift: 2 }, 'o').to(200, { sq: 0.03, lift: 0 }, 'i').to(200, { sq: 0 }, 'io'); },
      love: t => { hearts(t, 2); CARDS.mamapaws.yum(t); } },
    ribbit: { // frog: eats with his tongue - ZAP - and swallows by squeezing his eyes shut (frogs really do), throat puffs
      txt: 'Eats with his tongue - zap! - and swallows by squeezing his eyes shut, throat puffing.',
      pre: t => { t.to(250, { ly: 0.7, pitch: -0.08 }, 'io'); croak(t, 1, 380); },
      bite: (C, P) => (t, H, last) => { t.to(160, o(H.chest, { ly: 0.7, pitch: -0.08, sq: 0.06 }), 'io').to(70, { tongue: 1, open: 0.6, sq: -0.04 }, 'o').e('bite').e('emit', 'crumb', 'mouth', 1)
        .to(110, { tongue: 0, open: 0, sq: 0.07 }, 'io'); if (last) t.e('done'); return t; },
      chew: (C, P) => (t, n) => t.to(120, { close: 1, sqz: 0.6, puff: 0.6, sq: 0.06, pitch: -0.05 }, 'io').wait(Math.min(450, 110 * n)).to(160, { close: 0, sqz: 0, puff: 0, sq: 0, pitch: 0 }, 'io'),
      gulp: (C, P) => t => t.to(100, { sq: 0.04 }, 'o').e('gulp').to(140, { sq: 0 }, 'io'),
      whole: (C, P) => (t, H) => { t.to(200, o(H.chest, { ly: 0.7, sq: 0.06 }), 'io').to(80, { tongue: 1, open: 0.8, sq: -0.05 }, 'o').e('bite').e('done').to(130, { tongue: 0, open: 0, puff: 1.1, sq: 0.08 }, 'io'); return C.chew(t, 4); },
      big: (C, P) => (t, H) => { C.bite(t, H, false); C.chew(t, 3); C.bite(t, H, true); return C.chew(t, 3); },
      post: t => croak(t, 1, 400),
      yum: t => { t.to(150, { hap: 1, smile: 1 }, 'io'); jump(t, { h: 10, ant: 130, up: 210, c: 0.22, arm: 45 }); },
      love: t => { hearts(t, 2); CARDS.ribbit.yum(t); } },
  };

  // ---------- build every meal ----------
  const meal = (key, food, f0, P) => {
    const f = Object.assign({}, f0, { wins: [] }), H = HOLD[f.hold], t = TL({}, (CARD[key] && CARD[key].T) || 1), C = prims(P);
    (P.recv || recv)(t, H, P); if (P.pre) P.pre(t, H, P, C); if (f.pre) f.pre(t, H);
    STY[f.style](t, H, f, C); if (P.post) P.post(t, P, C);
    const r = f.react; if (r === 'yum' || r === 'love') P[r](t, P); else if (r === 'sour') sour(t, P); else if (r === 'freeze') freeze(t, P); else REACT[r](t);
    t.rest(450); return t.done(Object.assign({ prop: foodProp(f, food) }, P.propZ != null ? { propZ: P.propZ } : {})); };
  // every food for every creature in CARDS (also used by snack-eats.js; EAR takes the snacks' ear swing scales)
  const buildAll = CARDS => { const ST = {};
    for (const key in CARDS) { const P = Object.assign({ key }, CARDS[key]), D = DESC[key] = DESC[key] || {};
      Object.keys(FOODS).forEach(food => { const f = FOODS[food]; ST['eat_' + food + '@' + key] = meal(key, food, f, P); D['eat_' + food] = [f.label, P.txt + ' ' + f.d]; }); }
    R.add(ST); };
  R.EATKIT = { EAR, prims, STY, recv, sniffF, lipLick, sour, freeze, hearts, wagF, para, pat, meal, buildAll };
  buildAll(CARDS);
})();
