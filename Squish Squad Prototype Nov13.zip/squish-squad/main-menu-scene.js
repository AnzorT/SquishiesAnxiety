// Nov 13 MAIN MENU scene (user: 'show the character and behind him the home with his current status, like it is on the map - the genuine house,
// not looking from above, with the areas that are unlocked / locked and the status of the trees around him', reference: a Fortnite-style lobby).
// window.MainMenuScene.state(opts) -> the same numbers the house map uses (Squad House v6 mapVals): level -> tier (run-down / cozy / lovely / royal),
// rooms open by level (house4-rooms unlock levels + the Beach at 30), vitality v = (level - 1) / 29 (dead grass + bare trees at 1, lush at 30),
// season (auto by month like seasonNow, or forced). window.MainMenuScene.svg(st) -> the eye-level front view of the house as one SVG (viewBox
// 0 0 1000 460, drawn to fill a landscape phone with 'xMidYMax slice'): sky + weather, the island and the sea, the house (Kitchen + Bedroom on the
// left wing, Living Room + the Dance Room glass dome in the middle, Movie Room + Bathroom on the right wing), the fenced Backyard, the Beach, trees,
// bushes, grass, the front path and the pad the creature stands on. Locked rooms are boarded up with a padlock sign 'Lv n'.
(function () {
  if (window.MainMenuScene && window.MainMenuScene.v >= 2) return;
  const ROOMS = { living: { n: 'Living Room', lv: 1 }, kitchen: { n: 'Kitchen', lv: 2 }, bathroom: { n: 'Bathroom', lv: 4 }, bedroom: { n: 'Bedroom', lv: 6 },
    backyard: { n: 'Backyard', lv: 8 }, dance: { n: 'Dance Room', lv: 11 }, movie: { n: 'Movie Room', lv: 12 }, beach: { n: 'Beach', lv: 30 } };
  // tap areas in viewBox units (x, y, w, h) + where the lock sign hangs
  const AREAS = { bedroom: [262, 150, 156, 75], kitchen: [262, 225, 156, 75], living: [418, 198, 164, 102], dance: [452, 112, 96, 74],
    bathroom: [582, 150, 156, 75], movie: [582, 225, 156, 75], backyard: [748, 196, 158, 112], beach: [906, 176, 94, 150] };
  const RDOT = { living: '#e3946a', kitchen: '#f2c255', bathroom: '#5cc8f0', bedroom: '#8fa7c9', backyard: '#7fbd5e', dance: '#8f7bff', movie: '#c46a3e', beach: '#e8b860' };
  const SEASON = {
    sunny: { grass: ['#a2a68c', '#7fd35a'], sand: ['#d6cfb6', '#ffe39e'], sea0: ['#b7c9cf', '#a2f0ff'], sea1: ['#7e9aa8', '#2fb4e8'], tr0: ['#b2bb98', '#b4f27c'], tr1: ['#6f8262', '#3f9c32'] },
    rainy: { grass: ['#8d977e', '#62b04f'], sand: ['#bdb6a0', '#ddcb94'], sea0: ['#8fa3ab', '#86c8da'], sea1: ['#5d7684', '#2f82a8'], tr0: ['#97a283', '#8cc96e'], tr1: ['#56684c', '#2f7a32'] },
    snowy: { grass: ['#d6dade', '#f4f9fd'], sand: ['#d2d0c8', '#eef0ee'], sea0: ['#b4c4cc', '#c4ecf8'], sea1: ['#7d94a2', '#4fa6d0'], tr0: ['#dfe4e6', '#ffffff'], tr1: ['#7f9488', '#4f8a6a'] } };
  const DEAD = { grass: '#6c6746', sand: '#c4b896', sea0: '#9fb0b2', sea1: '#5f7682', tr0: '#8f7f58', tr1: '#4f4230' };
  const TIERS = ['Run-down house', 'Cozy home', 'Lovely home', 'Royal palace'];
  const OL = '#4a3a2e';
  const r1 = x => (Math.round(x * 10) / 10).toString(), clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const SS = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const hx = c => [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16));
  const mix = (a, b, t) => { const A = hx(a), B = hx(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * clamp(t, 0, 1)).toString(16).padStart(2, '0')).join(''); };
  const rnd = (i, k) => { const x = Math.sin(i * 127.1 + k * 311.7) * 43758.5453; return x - Math.floor(x); };
  const autoSeason = () => { const mo = new Date().getMonth(); return mo === 11 || mo <= 1 ? 'snowy' : mo >= 4 && mo <= 8 ? 'sunny' : 'rainy'; };

  function state(o) {
    o = o || {}; let L = o.level;
    if (!(L > 0)) { try { L = window.SquishProfile ? window.SquishProfile.get().level : 1; } catch (e) { L = 1; } }
    L = clamp((L | 0) || 1, 1, 30);
    const tier = L < 5 ? 0 : L < 15 ? 1 : L < 25 ? 2 : 3, sea = SEASON[o.season] ? o.season : autoSeason(), SP = SEASON[sea], v = clamp((L - 1) / 29, 0, 1);
    const open = {}; Object.keys(ROOMS).forEach(k => { open[k] = L >= ROOMS[k].lv; });
    const ks = Object.keys(ROOMS), nOpen = ks.filter(k => open[k]).length, f = Math.min((nOpen - 1) / (ks.length - 1), v);
    const dk = k => sea === 'snowy' ? SP[k][0] : sea === 'rainy' ? mix(DEAD[k], '#3a3c40', 0.12) : DEAD[k], mm = k => mix(dk(k), SP[k][1], v);
    const P = { grass: mm('grass'), sand: mm('sand'), sea0: mm('sea0'), sea1: mm('sea1'), tr0: mm('tr0'), tr1: mm('tr1'),
      roof0: tier === 0 ? '#b88a6e' : tier >= 3 ? '#9a2a3a' : '#e3946a', roof1: tier === 0 ? '#8a6248' : tier >= 3 ? '#6a1a28' : '#c4651f',
      wall0: tier === 0 ? '#e0d4bc' : '#fbf1e2', wall1: tier === 0 ? '#c4b496' : '#e8d4b4', shingle: tier === 0 ? '#6a4a36' : tier >= 3 ? '#3f5bb8' : '#b25a38',
      trim: tier === 0 ? '#d9cdb5' : tier >= 3 ? '#ffd66b' : '#fffaf1', trimD: tier === 0 ? '#a99c84' : tier >= 3 ? '#c9952a' : '#d9cbb4',
      shutter: ['#8a9a86', '#7fae8e', '#6aa0c8', '#3f5bb8'][tier], door: tier >= 3 ? '#7a2a3a' : tier === 0 ? '#8a6a52' : '#a0643a' };
    let s0 = tier === 0 ? '#b9cfdc' : '#7ec6f2', s1 = tier === 0 ? '#e4ecef' : '#e3f4fc';
    if (sea === 'rainy') { s0 = mix(s0, '#8e9aa6', 0.62); s1 = mix(s1, '#cfd6dc', 0.5); } else if (sea === 'snowy') { s0 = mix(s0, '#b4c4d4', 0.5); s1 = mix(s1, '#f1f5f9', 0.6); }
    P.sky0 = s0; P.sky1 = s1;
    let next = null; ks.forEach(k => { if (!open[k] && (!next || ROOMS[k].lv < ROOMS[next].lv)) next = k; });
    return { L, tier, tierName: TIERS[tier], season: sea, v, f, open, P, next: next ? { key: next, name: ROOMS[next].n, lv: ROOMS[next].lv } : null };
  }

  // ---------- pieces ----------
  const poly = pts => pts.map((p, i) => (i ? 'L' : 'M') + r1(p[0]) + ' ' + r1(p[1])).join(' ') + 'Z';
  // a tapered limb from (x, y) at angle a (deg, 0 = right, -90 = up), length l, widths w0 -> w1
  const limb = (x, y, a, l, w0, w1) => { const c = Math.cos(a * Math.PI / 180), s = Math.sin(a * Math.PI / 180), nx = -s, ny = c, X = x + c * l, Y = y + s * l;
    return { d: poly([[x + nx * w0 / 2, y + ny * w0 / 2], [X + nx * w1 / 2, Y + ny * w1 / 2], [X - nx * w1 / 2, Y - ny * w1 / 2], [x - nx * w0 / 2, y - ny * w0 / 2]]), X, Y }; };

  function tree(x, y, s, st, seed, o) {
    o = o || {}; const v = st.v, P = st.P, snow = st.season === 'snowy', k = SS(0.04, 0.8, v), lf = SS(0.03, 0.4, v);
    const bark = mix('#76685a', '#7a5434', v), barkD = mix('#4e443a', '#4f321c', v), lean = (rnd(seed, 1) - 0.5) * 10;
    let g = '<g transform="translate(' + r1(x) + ' ' + r1(y) + ') scale(' + s + ')">';
    g += '<ellipse cx="6" cy="1" rx="' + r1(30 + 18 * k) + '" ry="' + r1(6 + 2 * k) + '" fill="#1d2a16" opacity="' + r1(0.14 + 0.12 * k) + '" filter="url(#mmB2)"/>';
    let br = '', tw = '';
    const top = [lean, -60];
    br += '<path d="M-8 1 C-6 -22 ' + r1(lean * 0.4 - 5) + ' -44 ' + r1(lean - 4) + ' -62 L' + r1(lean + 4) + ' -62 C' + r1(lean * 0.4 + 6) + ' -44 6 -22 8 1 Z" fill="' + bark + '" stroke="' + OL + '" stroke-width="1.3"/>';
    br += '<path d="M-8 1 Q-13 2 -15 5 M8 1 Q13 2 15 5" stroke="' + barkD + '" stroke-width="2.4" fill="none" stroke-linecap="round"/>';
    br += '<path d="M' + r1(lean * 0.3 + 2) + ' -8 C' + r1(lean * 0.4 + 3) + ' -26 ' + r1(lean * 0.7 + 3) + ' -40 ' + r1(lean + 2) + ' -56" stroke="' + mix(bark, '#ffffff', 0.25) + '" stroke-width="1.6" fill="none" opacity="0.6"/>';
    const tips = [];
    [-152, -122, -96, -70, -34].forEach((a0, i) => { const a = a0 + (rnd(seed, i + 3) - 0.5) * 16, l = 30 + rnd(seed, i + 9) * 14, B = limb(top[0], top[1] + 4, a, l, 6.5, 2.2);
      br += '<path d="' + B.d + '" fill="' + bark + '" stroke="' + OL + '" stroke-width="1"/>'; tips.push([B.X, B.Y]);
      [0.55, 0.8].forEach((t, j) => { const bx = top[0] + (B.X - top[0]) * t, by = top[1] + 4 + (B.Y - top[1] - 4) * t, a2 = a + (j ? 28 : -30), T = limb(bx, by, a2, 12 + rnd(seed, i * 3 + j) * 8, 2.2, 0.8);
        tw += '<path d="' + T.d + '" fill="' + barkD + '"/>'; tips.push([T.X, T.Y]); }); });
    if (snow) tips.forEach(([X, Y], i) => { if (i % 3 === 0) tw += '<ellipse cx="' + r1(X) + '" cy="' + r1(Y - 1) + '" rx="3.4" ry="1.4" fill="#ffffff"/>'; });
    g += br + tw;
    // crown: an outlined union of blobs that grows + greens with v
    if (lf > 0.01) {
      const cx = lean * 1.1, cy = -86, B = [[-24, 6, 19], [24, 4, 20], [0, -16, 24], [-15, -10, 19], [15, -12, 20], [-31, 20, 14], [31, 19, 14], [0, 2, 23], [-8, 18, 16], [9, 19, 16]];
      const sc = 0.45 + 0.55 * k, op = r1(lf), C = B.map(([bx, by, r], i) => [cx + bx * (0.8 + 0.2 * k), cy + by * (0.8 + 0.2 * k), r * sc * (0.92 + rnd(seed, i + 30) * 0.16)]);
      const dark = st.P.tr1, mid = mix(st.P.tr1, st.P.tr0, 0.5), lite = st.P.tr0;
      let cr = '<g opacity="' + op + '">';
      cr += C.map(([a, b, r]) => '<circle cx="' + r1(a) + '" cy="' + r1(b) + '" r="' + r1(r + 1.2) + '" fill="' + dark + '" stroke="' + OL + '" stroke-width="2.4"/>').join('');
      cr += C.map(([a, b, r]) => '<circle cx="' + r1(a) + '" cy="' + r1(b) + '" r="' + r1(r) + '" fill="' + dark + '"/>').join('');
      cr += C.map(([a, b, r]) => '<circle cx="' + r1(a - r * 0.18) + '" cy="' + r1(b - r * 0.2) + '" r="' + r1(r * 0.78) + '" fill="' + mid + '"/>').join('');
      cr += C.filter((c, i) => i % 2 === 0 || i === 2).map(([a, b, r]) => '<circle cx="' + r1(a - r * 0.34) + '" cy="' + r1(b - r * 0.38) + '" r="' + r1(r * 0.42) + '" fill="' + lite + '"/>').join('');
      // leaf flecks
      for (let i = 0; i < 18; i++) { const c = C[i % C.length], an = rnd(seed, i + 50) * 6.28, rr = c[2] * (0.3 + rnd(seed, i + 70) * 0.6);
        cr += '<ellipse cx="' + r1(c[0] + Math.cos(an) * rr) + '" cy="' + r1(c[1] + Math.sin(an) * rr) + '" rx="2.2" ry="1.3" transform="rotate(' + Math.round(an * 57) + ' ' + r1(c[0] + Math.cos(an) * rr) + ' ' + r1(c[1] + Math.sin(an) * rr) + ')" fill="' + (i % 2 ? lite : dark) + '" opacity="0.8"/>'; }
      if (v > 0.72 && !snow) { const fc = o.fruit ? '#e8433a' : '#fff4f8', fk = SS(0.72, 0.95, v);
        for (let i = 0; i < 12; i++) { const c = C[i % C.length], an = rnd(seed, i + 90) * 6.28, rr = c[2] * 0.55;
          cr += '<circle cx="' + r1(c[0] + Math.cos(an) * rr) + '" cy="' + r1(c[1] + Math.sin(an) * rr) + '" r="' + (o.fruit ? 2.4 : 1.9) + '" fill="' + fc + '" stroke="' + (o.fruit ? '#8a1e18' : '#e6a2b8') + '" stroke-width="0.6" opacity="' + r1(fk) + '"/>'; } }
      if (snow) C.forEach(([a, b, r], i) => { if (b < cy + 8) cr += '<path d="M' + r1(a - r * 0.82) + ' ' + r1(b - r * 0.25) + ' Q' + r1(a) + ' ' + r1(b - r * 1.12) + ' ' + r1(a + r * 0.82) + ' ' + r1(b - r * 0.25) + ' Q' + r1(a) + ' ' + r1(b - r * 0.6) + ' ' + r1(a - r * 0.82) + ' ' + r1(b - r * 0.25) + 'Z" fill="#ffffff"/>'; });
      cr += '</g>';
      g += '<g>' + cr + '<animateTransform attributeName="transform" type="rotate" values="-1.1 0 0;1.1 0 0;-1.1 0 0" dur="' + (5.5 + rnd(seed, 2) * 3).toFixed(1) + 's" repeatCount="indefinite"/></g>';
    }
    // a few dead leaves when the island is lifeless
    if (v < 0.45) { const dl = r1(1 - v / 0.45);
      for (let i = 0; i < 7; i++) g += '<ellipse cx="' + r1((rnd(seed, i + 120) - 0.5) * 60) + '" cy="' + r1(2 + rnd(seed, i + 130) * 6) + '" rx="2.6" ry="1.3" fill="' + (i % 2 ? '#9a7448' : '#7a5a3a') + '" opacity="' + dl + '" transform="rotate(' + Math.round(rnd(seed, i + 140) * 180) + ' ' + r1((rnd(seed, i + 120) - 0.5) * 60) + ' ' + r1(2 + rnd(seed, i + 130) * 6) + ')"/>';
      g += '<ellipse cx="' + r1(tips[2][0]) + '" cy="' + r1(tips[2][1]) + '" rx="2.6" ry="1.4" fill="#9a7448" opacity="' + dl + '"><animate attributeName="cy" values="' + r1(tips[2][1]) + ';0" dur="7s" repeatCount="indefinite"/><animate attributeName="cx" values="' + r1(tips[2][0]) + ';' + r1(tips[2][0] + 10) + ';' + r1(tips[2][0] - 6) + ';' + r1(tips[2][0] + 4) + '" dur="7s" repeatCount="indefinite"/><animate attributeName="opacity" values="' + dl + ';' + dl + ';0" dur="7s" repeatCount="indefinite"/></ellipse>'; }
    return g + '</g>';
  }

  function bush(x, y, s, st, seed) {
    const v = st.v, k = SS(0.05, 0.75, v), snow = st.season === 'snowy', dark = st.P.tr1, mid = mix(st.P.tr1, st.P.tr0, 0.5), lite = st.P.tr0;
    let g = '<g transform="translate(' + r1(x) + ' ' + r1(y) + ') scale(' + s + ')"><ellipse cx="2" cy="1" rx="22" ry="4" fill="#1d2a16" opacity="0.18" filter="url(#mmB1)"/>';
    // twigs (always) - show when bare
    for (let i = 0; i < 7; i++) { const a = -160 + i * 23 + (rnd(seed, i) - 0.5) * 10, T = limb((i - 3) * 2, 0, a, 12 + rnd(seed, i + 5) * 8, 2, 0.6); g += '<path d="' + T.d + '" fill="' + mix('#6e5d4c', '#5a4028', v) + '"/>'; }
    if (k > 0.02) { const B = [[-11, -7, 9], [10, -7, 9.5], [0, -13, 10.5], [-4, -4, 9], [6, -3, 8.5]].map(([a, b, r]) => [a, b, r * (0.5 + 0.5 * k)]);
      g += '<g opacity="' + r1(SS(0.02, 0.35, v)) + '">' + B.map(([a, b, r]) => '<circle cx="' + a + '" cy="' + r1(b) + '" r="' + r1(r + 1) + '" fill="' + dark + '" stroke="' + OL + '" stroke-width="2"/>').join('') + B.map(([a, b, r]) => '<circle cx="' + a + '" cy="' + r1(b) + '" r="' + r1(r) + '" fill="' + dark + '"/>').join('')
        + B.map(([a, b, r]) => '<circle cx="' + r1(a - r * 0.2) + '" cy="' + r1(b - r * 0.22) + '" r="' + r1(r * 0.74) + '" fill="' + mid + '"/>').join('') + B.filter((c, i) => i !== 3).map(([a, b, r]) => '<circle cx="' + r1(a - r * 0.35) + '" cy="' + r1(b - r * 0.4) + '" r="' + r1(r * 0.36) + '" fill="' + lite + '"/>').join('');
      if (v > 0.55 && !snow) for (let i = 0; i < 6; i++) g += '<circle cx="' + r1((rnd(seed, i + 20) - 0.5) * 26) + '" cy="' + r1(-4 - rnd(seed, i + 30) * 14) + '" r="1.7" fill="' + ['#fff6a8', '#ffffff', '#ffb3c7', '#c9b8ff'][i % 4] + '" opacity="' + r1(SS(0.55, 0.85, v)) + '"/>';
      if (snow) g += '<path d="M-19 -9 Q-10 -24 0 -23 Q12 -24 19 -10 Q8 -16 0 -15 Q-9 -16 -19 -9Z" fill="#ffffff"/>';
      g += '</g>'; }
    return g + '</g>';
  }

  function palm(x, y, s, st, seed) {
    const v = Math.max(st.v, 0.15), dark = mix('#7b7a52', '#2f8a3a', v), lite = mix('#a6a07a', '#6fc65a', v);
    let g = '<g transform="translate(' + r1(x) + ' ' + r1(y) + ') scale(' + s + ')"><ellipse cx="4" cy="1" rx="18" ry="3.5" fill="#1d2a16" opacity="0.18"/>';
    let tx = 0, ty = 0; for (let i = 0; i < 9; i++) { const nx = tx + 1.6 + i * 0.5, ny = ty - 9.5, w = 7 - i * 0.35; g += '<path d="' + poly([[tx - w / 2, ty], [tx + w / 2, ty], [nx + w / 2 - 0.4, ny], [nx - w / 2 + 0.4, ny]]) + '" fill="' + (i % 2 ? '#a07a4c' : '#b88e5c') + '" stroke="' + OL + '" stroke-width="0.9"/>'; tx = nx; ty = ny; }
    const fr = [[-150, 1], [-120, 0.9], [-60, 0.95], [-28, 1], [-90, 0.7], [-185, 0.8], [5, 0.8]];
    let fg = '';
    fr.forEach(([a, l], i) => { const L = 34 * l, c = Math.cos(a * Math.PI / 180), sn = Math.sin(a * Math.PI / 180), ex = tx + c * L, ey = ty + sn * L + 12 * l, mx = tx + c * L * 0.5, my = ty + sn * L * 0.5 - 6;
      fg += '<path d="M' + r1(tx) + ' ' + r1(ty) + ' Q' + r1(mx) + ' ' + r1(my - 6) + ' ' + r1(ex) + ' ' + r1(ey) + ' Q' + r1(mx + 2) + ' ' + r1(my + 4) + ' ' + r1(tx) + ' ' + r1(ty) + 'Z" fill="' + (i % 2 ? dark : lite) + '" stroke="' + OL + '" stroke-width="1"/>'; });
    g += '<g>' + fg + '<circle cx="' + r1(tx - 2) + '" cy="' + r1(ty + 3) + '" r="3" fill="#6a4a2a"/><circle cx="' + r1(tx + 2.5) + '" cy="' + r1(ty + 4) + '" r="3" fill="#7a5632"/><animateTransform attributeName="transform" type="rotate" values="-1.5 ' + r1(tx) + ' ' + r1(ty) + ';1.5 ' + r1(tx) + ' ' + r1(ty) + ';-1.5 ' + r1(tx) + ' ' + r1(ty) + '" dur="5s" repeatCount="indefinite"/></g>';
    return g + '</g>';
  }

  // a wooden hanging sign: padlock + 'Lv n' (+ the room name under it)
  function lockSign(x, y, lv, name, sc) {
    sc = sc || 1; const w = Math.max(58, name.length * 5.6 + 18);
    return '<g transform="translate(' + r1(x) + ' ' + r1(y) + ') scale(' + sc + ')" class="mm-sign"><path d="M' + r1(-w / 2 + 8) + ' 0 L-6 -13 M' + r1(w / 2 - 8) + ' 0 L6 -13" stroke="#7a5a3a" stroke-width="1.4"/><circle cx="0" cy="-13.5" r="2" fill="#5a4636"/>'
      + '<rect x="' + r1(-w / 2) + '" y="0" width="' + r1(w) + '" height="31" rx="5" fill="url(#mmWood)" stroke="#5a3a1e" stroke-width="1.6"/><rect x="' + r1(-w / 2 + 2.5) + '" y="2.5" width="' + r1(w - 5) + '" height="26" rx="3.5" fill="none" stroke="#f3d29a" stroke-width="0.8" opacity="0.6"/>'
      + '<g transform="translate(-17 4.5)"><path d="M3 6 V4 A4 4 0 0 1 11 4 V6" fill="none" stroke="#5a4636" stroke-width="2"/><rect x="1" y="6" width="12" height="9" rx="2" fill="#ffd54a" stroke="#7a5214" stroke-width="1.1"/><circle cx="7" cy="10" r="1.3" fill="#7a5214"/></g>'
      + '<text x="8" y="15.5" text-anchor="middle" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="12.5" fill="#fff8ea" stroke="#5a3a1e" stroke-width="2.6" paint-order="stroke">Lv ' + lv + '</text>'
      + '<text x="0" y="26.5" text-anchor="middle" font-family="Fredoka, Nunito, sans-serif" font-weight="600" font-size="8.4" fill="#5a3a1e">' + name + '</text></g>';
  }
  const plank = (x1, y1, x2, y2, w, i) => { const L = limb(x1, y1, Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI, Math.hypot(x2 - x1, y2 - y1), w, w); const c = ['#c09062', '#b48256', '#c99a6a'][i % 3];
    return '<path d="' + L.d + '" fill="' + c + '" stroke="#5a3a1e" stroke-width="1.1"/><circle cx="' + r1(x1 + (x2 - x1) * 0.08) + '" cy="' + r1(y1 + (y2 - y1) * 0.08) + '" r="1" fill="#4a3a30"/><circle cx="' + r1(x1 + (x2 - x1) * 0.92) + '" cy="' + r1(y1 + (y2 - y1) * 0.92) + '" r="1" fill="#4a3a30"/>'; };
  const boards = (x, y, w, h, seed) => plank(x - 4, y + h * 0.22, x + w + 4, y + h * 0.62, 7, seed) + plank(x - 3, y + h * 0.78, x + w + 3, y + h * 0.36, 7, seed + 1);
  const web = (x, y, sx) => '<path d="M' + x + ' ' + y + ' l' + 12 * sx + ' 0 M' + x + ' ' + y + ' l0 12 M' + x + ' ' + y + ' l' + 9 * sx + ' 9 M' + r1(x + 5 * sx) + ' ' + y + ' q' + 1 * sx + ' 4 ' + -5 * sx + ' 5 M' + r1(x + 9 * sx) + ' ' + y + ' q' + 1 * sx + ' 7 ' + -9 * sx + ' 9" stroke="#e8e8ee" stroke-width="0.6" fill="none" opacity="0.8"/>';

  // a window: glass shows the room's wall colour + a warm glow when open; dark + boarded when locked
  function win(x, y, w, h, o, st) {
    const P = st.P, sh = o.shape || 'rect', open = o.open, c = o.room || '#e3946a', id = 'mmw' + Math.round(x) + '_' + Math.round(y);
    const out = sh === 'round' ? '<circle cx="' + r1(x + w / 2) + '" cy="' + r1(y + h / 2) + '" r="' + r1(w / 2 + 2.5) + '"' : sh === 'arch' ? '<path d="M' + r1(x - 2.5) + ' ' + r1(y + h + 2.5) + ' V' + r1(y + w / 2) + ' A' + r1(w / 2 + 2.5) + ' ' + r1(w / 2 + 2.5) + ' 0 0 1 ' + r1(x + w + 2.5) + ' ' + r1(y + w / 2) + ' V' + r1(y + h + 2.5) + ' Z"' : '<rect x="' + r1(x - 2.5) + '" y="' + r1(y - 2.5) + '" width="' + r1(w + 5) + '" height="' + r1(h + 5) + '" rx="2"';
    const inner = sh === 'round' ? '<circle cx="' + r1(x + w / 2) + '" cy="' + r1(y + h / 2) + '" r="' + r1(w / 2) + '"' : sh === 'arch' ? '<path d="M' + r1(x) + ' ' + r1(y + h) + ' V' + r1(y + w / 2) + ' A' + r1(w / 2) + ' ' + r1(w / 2) + ' 0 0 1 ' + r1(x + w) + ' ' + r1(y + w / 2) + ' V' + r1(y + h) + ' Z"' : '<rect x="' + r1(x) + '" y="' + r1(y) + '" width="' + r1(w) + '" height="' + r1(h) + '"';
    let g = '';
    if (o.shutters && sh === 'rect') { const sw = w * 0.42, crook = st.tier === 0 ? 7 : 0; [[x - sw - 4, 0], [x + w + 4, 1]].forEach(([sx, i]) => { g += '<g transform="rotate(' + (i && crook ? crook : 0) + ' ' + r1(sx) + ' ' + r1(y) + ')"><rect x="' + r1(sx) + '" y="' + r1(y - 1) + '" width="' + r1(sw) + '" height="' + r1(h + 2) + '" rx="1.5" fill="' + P.shutter + '" stroke="' + OL + '" stroke-width="1.1"/>' + [0.25, 0.5, 0.75].map(t => '<path d="M' + r1(sx + 2) + ' ' + r1(y + h * t) + ' H' + r1(sx + sw - 2) + '" stroke="' + mix(P.shutter, '#000000', 0.3) + '" stroke-width="0.8"/>').join('') + '</g>'; }); }
    g += out + ' fill="' + P.trim + '" stroke="' + OL + '" stroke-width="1.3"/>';
    g += '<clipPath id="' + id + '">' + inner + '/></clipPath>';
    if (open) {
      g += '<g clip-path="url(#' + id + ')"><rect x="' + r1(x - 2) + '" y="' + r1(y - 2) + '" width="' + r1(w + 4) + '" height="' + r1(h + 4) + '" fill="' + mix(c, '#fff4d8', 0.35) + '"/>'
        + '<rect x="' + r1(x - 2) + '" y="' + r1(y + h * 0.55) + '" width="' + r1(w + 4) + '" height="' + r1(h * 0.5) + '" fill="' + mix(c, '#3a2a30', 0.35) + '"/>'
        + '<ellipse cx="' + r1(x + w * 0.5) + '" cy="' + r1(y + h * 0.35) + '" rx="' + r1(w * 0.4) + '" ry="' + r1(h * 0.3) + '" fill="#fff6d0" opacity="0.55" filter="url(#mmB2)"/>'
        + (o.inside || '')
        + (o.curtain ? '<path d="M' + r1(x - 1) + ' ' + r1(y - 1) + ' H' + r1(x + w * 0.24) + ' Q' + r1(x + w * 0.12) + ' ' + r1(y + h * 0.5) + ' ' + r1(x + w * 0.2) + ' ' + r1(y + h + 1) + ' H' + r1(x - 1) + 'Z M' + r1(x + w + 1) + ' ' + r1(y - 1) + ' H' + r1(x + w * 0.76) + ' Q' + r1(x + w * 0.88) + ' ' + r1(y + h * 0.5) + ' ' + r1(x + w * 0.8) + ' ' + r1(y + h + 1) + ' H' + r1(x + w + 1) + 'Z" fill="' + o.curtain + '" stroke="' + OL + '" stroke-width="0.8"/>' : '')
        + '<path d="M' + r1(x + w * 0.15) + ' ' + r1(y + h + 2) + ' L' + r1(x + w * 0.62) + ' ' + r1(y - 2) + ' L' + r1(x + w * 0.78) + ' ' + r1(y - 2) + ' L' + r1(x + w * 0.31) + ' ' + r1(y + h + 2) + 'Z" fill="#ffffff" opacity="0.22"/>'
        + (st.tier === 0 && o.tape ? '<path d="M' + r1(x + 2) + ' ' + r1(y + 3) + ' L' + r1(x + w - 2) + ' ' + r1(y + h - 3) + ' M' + r1(x + w - 2) + ' ' + r1(y + 3) + ' L' + r1(x + 2) + ' ' + r1(y + h - 3) + '" stroke="#e8d9a8" stroke-width="3" opacity="0.85"/><path d="M' + r1(x + w * 0.3) + ' ' + r1(y + h * 0.2) + ' l5 6 l-2 5 l6 4" stroke="#ffffff" stroke-width="0.7" fill="none" opacity="0.9"/>' : '')
        + '</g>';
    } else {
      g += '<g clip-path="url(#' + id + ')"><rect x="' + r1(x - 2) + '" y="' + r1(y - 2) + '" width="' + r1(w + 4) + '" height="' + r1(h + 4) + '" fill="#352f3e"/><rect x="' + r1(x - 2) + '" y="' + r1(y - 2) + '" width="' + r1(w + 4) + '" height="' + r1(h * 0.45) + '" fill="#4a4456"/>' + web(r1(x), r1(y), 1) + '</g>';
    }
    if (sh === 'rect' && !o.noBars) g += '<path d="M' + r1(x + w / 2) + ' ' + r1(y) + ' V' + r1(y + h) + (h > 24 ? ' M' + r1(x) + ' ' + r1(y + h * 0.48) + ' H' + r1(x + w) : '') + '" stroke="' + P.trim + '" stroke-width="2.2"/><path d="M' + r1(x + w / 2) + ' ' + r1(y) + ' V' + r1(y + h) + '" stroke="' + OL + '" stroke-width="0.5" opacity="0.5"/>';
    if (sh === 'round' && !o.noBars) g += '<path d="M' + r1(x + w / 2) + ' ' + r1(y) + ' V' + r1(y + h) + ' M' + r1(x) + ' ' + r1(y + h / 2) + ' H' + r1(x + w) + '" stroke="' + P.trim + '" stroke-width="1.8"/>';
    if (sh !== 'round') g += '<rect x="' + r1(x - 5) + '" y="' + r1(y + h + 1.5) + '" width="' + r1(w + 10) + '" height="4" rx="1.2" fill="' + P.trim + '" stroke="' + OL + '" stroke-width="1.1"/>';
    if (o.box && open && st.tier >= 1) { const fk = SS(0.2, 0.6, st.v); g += '<rect x="' + r1(x - 2) + '" y="' + r1(y + h + 5) + '" width="' + r1(w + 4) + '" height="7" rx="1.5" fill="' + mix(P.door, '#ffffff', 0.15) + '" stroke="' + OL + '" stroke-width="1"/>';
      for (let i = 0; i < 6; i++) { const fx = x + 2 + (w - 4) * (i + 0.5) / 6; g += '<circle cx="' + r1(fx) + '" cy="' + r1(y + h + 3.5) + '" r="' + r1(2.6 * fk + 0.6) + '" fill="' + st.P.tr1 + '"/><circle cx="' + r1(fx) + '" cy="' + r1(y + h + 2.6) + '" r="' + r1(1.6 * fk) + '" fill="' + ['#ffd24a', '#ffffff', '#ff8a6a', '#b9a6ff'][i % 4] + '"/>'; } }
    if (!open) g += boards(x, y, w, h, Math.round(x));
    return g;
  }

  function shingles(x0, x1, y0, y1, col, id, step) { let g = '<g clip-path="url(#' + id + ')" opacity="0.55">'; step = step || 8;
    for (let y = y0 + step; y < y1 + step; y += step) { let d = 'M' + r1(x0 - 6) + ' ' + r1(y); const off = ((y / step) % 2) * 5; for (let x = x0 - 6 + off; x < x1 + 6; x += 10) d += ' q5 4 10 0'; g += '<path d="' + d + '" stroke="' + col + '" stroke-width="1.1" fill="none"/>'; }
    return g + '</g>'; }
  function snowCap(d) { return '<path d="' + d + '" fill="#ffffff" stroke="#c9d6e2" stroke-width="0.8"/>'; }

  // ---------- the house ----------
  function house(st) {
    const P = st.P, O = st.open, t = st.tier, snow = st.season === 'snowy';
    let g = '';
    const B = 300, F = 225, T = 150, LX0 = 262, LX1 = 418, RX0 = 582, RX1 = 738, CT = 198;
    // shadow on the ground
    g += '<ellipse cx="500" cy="302" rx="270" ry="12" fill="#1d2a16" opacity="0.22" filter="url(#mmB3)"/>';
    // wings: walls
    const wall = (x0, x1, y0, y1) => '<rect x="' + x0 + '" y="' + y0 + '" width="' + (x1 - x0) + '" height="' + (y1 - y0) + '" fill="url(#mmWall)" stroke="' + OL + '" stroke-width="1.4"/>'
      + Array.from({ length: Math.floor((y1 - y0) / 8) }, (_, i) => '<path d="M' + (x0 + 1) + ' ' + (y0 + 8 * (i + 1)) + ' H' + (x1 - 1) + '" stroke="' + mix(P.wall1, '#5a4636', 0.25) + '" stroke-width="0.7" opacity="0.45"/>').join('');
    g += wall(LX0, LX1, T, B) + wall(RX0, RX1, T, B);
    // floor bands + corner boards + foundation
    [[LX0, LX1], [RX0, RX1]].forEach(([a, b]) => { g += '<rect x="' + (a - 2) + '" y="' + (F - 3) + '" width="' + (b - a + 4) + '" height="6" fill="' + P.trim + '" stroke="' + OL + '" stroke-width="1.1"/>'
      + '<rect x="' + (a - 1) + '" y="' + T + '" width="6" height="' + (B - T) + '" fill="' + P.trim + '" stroke="' + OL + '" stroke-width="1"/><rect x="' + (b - 5) + '" y="' + T + '" width="6" height="' + (B - T) + '" fill="' + P.trim + '" stroke="' + OL + '" stroke-width="1"/>'; });
    // shabby wear
    if (t === 0) { [[300, 200], [360, 284], [612, 170], [700, 262], [404, 160]].forEach(([x, y], i) => { g += '<path d="M' + x + ' ' + y + ' c3 -4 7 -1 10 -5 c3 2 6 -1 9 2 c-1 4 -6 5 -9 8 c-4 0 -7 -1 -10 -5Z" fill="#c9a08a" stroke="#8a6a52" stroke-width="0.6" opacity="0.75"/>'; });
      g += '<path d="M276 160 l6 9 l-3 6 l7 11 M720 232 l-5 8 l4 7 l-6 10 M398 236 l-4 6 l3 5" stroke="#6a5a4a" stroke-width="0.9" fill="none" opacity="0.8"/>'; }
    // ---- left wing: Kitchen (ground) + Bedroom (upstairs) ----
    const kit = O.kitchen, bed = O.bedroom;
    // kitchen: awning window + round pie window
    g += win(282, 246, 62, 36, { open: kit, room: RDOT.kitchen, curtain: kit ? '#fff3d8' : null, tape: true, box: true, inside: '<rect x="290" y="268" width="46" height="5" fill="#d9a06a"/><circle cx="302" cy="266" r="3.4" fill="#ffffff" stroke="#b07a4a" stroke-width="0.6"/><path d="M318 268 q5 -8 10 0Z" fill="#e8a24a"/>' }, st);
    if (kit) { const aw = ['#7fae8e', '#fffaf1']; let a = ''; for (let i = 0; i < 8; i++) a += '<path d="M' + (276 + i * 9.25) + ' 232 h9.25 l' + (i < 4 ? -0.6 : 0.6) + ' 12 h-9.25Z" fill="' + aw[i % 2] + '"/>';
      g += '<g>' + a + '<path d="M276 232 H350 L350.6 244 H275.4Z" fill="none" stroke="' + OL + '" stroke-width="1.2"/>' + Array.from({ length: 8 }, (_, i) => '<path d="M' + (276 + i * 9.25) + ' 244 q4.6 5 9.25 0" fill="' + aw[i % 2] + '" stroke="' + OL + '" stroke-width="0.9"/>').join('') + '</g>'; }
    g += win(372, 252, 26, 26, { open: kit, room: RDOT.kitchen, shape: 'round', inside: kit ? '<path d="M378 268 q7 -9 14 0Z" fill="#d98a3a" stroke="#8a4a1a" stroke-width="0.6"/><path d="M380 266 h10" stroke="#fff4d8" stroke-width="0.8"/>' : '' }, st);
    // bedroom: arched moon window + small square
    g += win(298, 164, 42, 48, { open: bed, room: RDOT.bedroom, shape: 'arch', curtain: bed ? '#e8e2f6' : null, box: true, inside: bed ? '<path d="M316 182 a7 7 0 1 0 8 9 a5.5 5.5 0 1 1 -8 -9Z" fill="#fff3b0"/><circle cx="330" cy="178" r="1.2" fill="#fff8d0"/><circle cx="309" cy="196" r="0.9" fill="#fff8d0"/>' : '' }, st);
    g += win(366, 176, 30, 30, { open: bed, room: RDOT.bedroom, tape: true }, st);
    if (!kit) g += '<rect x="' + LX0 + '" y="' + F + '" width="' + (LX1 - LX0) + '" height="' + (B - F) + '" fill="#2a2030" opacity="0.18"/>';
    if (!bed) g += '<rect x="' + LX0 + '" y="' + T + '" width="' + (LX1 - LX0) + '" height="' + (F - T) + '" fill="#2a2030" opacity="0.18"/>';
    // left gable roof
    const lr = 'M' + (LX0 - 12) + ' ' + (T + 2) + ' L340 84 L' + (LX1 + 12) + ' ' + (T + 2) + 'Z';
    g += '<clipPath id="mmRL"><path d="' + lr + '"/></clipPath>';
    // chimney (behind the roof edge)
    g += '<g transform="' + (t === 0 ? 'rotate(-7 300 112)' : '') + '"><rect x="290" y="94" width="22" height="40" fill="#b8664a" stroke="' + OL + '" stroke-width="1.3"/><rect x="287" y="90" width="28" height="7" rx="1.5" fill="#9a5038" stroke="' + OL + '" stroke-width="1.2"/>'
      + [0, 1, 2, 3].map(i => '<path d="M290 ' + (104 + i * 7) + ' H312 M' + (i % 2 ? 301 : 296) + ' ' + (97 + i * 7) + ' V' + (104 + i * 7) + '" stroke="#8a4a32" stroke-width="0.7" opacity="0.7"/>').join('') + (snow ? snowCap('M286 91 Q301 82 316 91 Q301 88 286 91Z') : '') + '</g>';
    if (t >= 1) for (let i = 0; i < 3; i++) g += '<circle cx="301" cy="84" r="5" fill="#ffffff" opacity="0"><animate attributeName="cy" values="86;40" dur="4.5s" begin="' + (i * 1.5) + 's" repeatCount="indefinite"/><animate attributeName="cx" values="301;296;308" dur="4.5s" begin="' + (i * 1.5) + 's" repeatCount="indefinite"/><animate attributeName="r" values="4;11" dur="4.5s" begin="' + (i * 1.5) + 's" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.75;0" dur="4.5s" begin="' + (i * 1.5) + 's" repeatCount="indefinite"/></circle>';
    g += '<path d="' + lr + '" fill="url(#mmRoof)" stroke="' + OL + '" stroke-width="1.5"/>' + shingles(LX0 - 12, LX1 + 12, 84, T, P.shingle, 'mmRL', 8);
    if (t === 0) g += '<path d="M318 112 l9 -2 l2 8 l-9 2Z M360 128 l10 -1 l1 7 l-10 1Z" fill="#5a3a28" opacity="0.6"/>';
    g += '<path d="M' + (LX0 - 14) + ' ' + (T + 3) + ' L340 82 L' + (LX1 + 14) + ' ' + (T + 3) + '" fill="none" stroke="' + P.trim + '" stroke-width="4" stroke-linejoin="round"/><path d="M' + (LX0 - 14) + ' ' + (T + 3) + ' L340 82 L' + (LX1 + 14) + ' ' + (T + 3) + '" fill="none" stroke="' + OL + '" stroke-width="0.8"/>';
    g += '<circle cx="340" cy="122" r="8" fill="' + P.trim + '" stroke="' + OL + '" stroke-width="1.2"/><circle cx="340" cy="122" r="5.2" fill="' + (bed ? mix(RDOT.bedroom, '#fff4d8', 0.3) : '#352f3e') + '"/><path d="M340 117 V127 M335 122 H345" stroke="' + P.trim + '" stroke-width="1.2"/>';
    g += '<rect x="' + (LX0 - 6) + '" y="' + (T + 1) + '" width="' + (LX1 - LX0 + 12) + '" height="5" fill="#2a2030" opacity="0.18"/>';
    if (snow) g += snowCap('M' + (LX0 - 14) + ' ' + (T + 3) + ' L340 80 L' + (LX1 + 14) + ' ' + (T + 3) + ' L' + (LX1 + 6) + ' ' + (T + 2) + ' L340 88 L' + (LX0 - 6) + ' ' + (T + 2) + 'Z');
    if (t === 3) g += '<path d="M340 82 V60" stroke="#8a6a2a" stroke-width="1.6"/><path d="M340 60 L356 64 L340 69Z" fill="#3f5bb8" stroke="' + OL + '" stroke-width="0.9"><animate attributeName="d" values="M340 60 L356 64 L340 69Z;M340 60 L355 66 L340 69Z;M340 60 L356 64 L340 69Z" dur="1.6s" repeatCount="indefinite"/></path><circle cx="340" cy="59" r="1.8" fill="#ffd66b"/>';
    // gutter sag (run-down)
    if (t === 0) g += '<path d="M' + (LX0 - 8) + ' ' + (T + 6) + ' Q340 ' + (T + 12) + ' ' + (LX1 + 6) + ' ' + (T + 5) + '" stroke="#8a8478" stroke-width="2.4" fill="none"/>';
    // ---- right wing: Movie Room (ground) + Bathroom (upstairs) ----
    const mov = O.movie, bat = O.bathroom;
    g += win(604, 242, 92, 40, { open: mov, room: RDOT.movie, noBars: true, inside: mov ? '<rect x="612" y="248" width="76" height="26" rx="2" fill="#20263a"/><rect x="615" y="251" width="70" height="20" fill="#7fd2ff" opacity="0.85"><animate attributeName="fill" values="#7fd2ff;#ffd27f;#b8a6ff;#7fd2ff" dur="5s" repeatCount="indefinite"/></rect><path d="M626 266 q8 -10 16 0 q8 -8 16 0" fill="none" stroke="#ffffff" stroke-width="1.4" opacity="0.8"/><path d="M612 276 H688" stroke="#3a2a30" stroke-width="5"/>' : '' }, st);
    if (mov) { let b = ''; for (let i = 0; i < 13; i++) b += '<circle cx="' + (601 + i * 8.2) + '" cy="238" r="2" fill="#ffe27a" stroke="#a87a1a" stroke-width="0.5"><animate attributeName="opacity" values="1;0.35;1" dur="1.2s" begin="' + (i % 3) * 0.4 + 's" repeatCount="indefinite"/></circle>'; g += b; }
    g += win(712, 248, 16, 34, { open: mov, room: RDOT.movie, tape: true, noBars: true }, st);
    g += win(612, 168, 34, 34, { open: bat, room: RDOT.bathroom, shape: 'round', inside: bat ? '<path d="M624 190 q-1 -6 4 -7 q5 -1 6 3 l4 -1 l-2 3 q4 1 4 4 q0 4 -8 4 q-8 0 -8 -6Z" fill="#ffd54a" stroke="#a8781a" stroke-width="0.6"/><circle cx="630" cy="184" r="0.9" fill="#3a2a2a"/><circle cx="636" cy="182" r="2" fill="#ffffff" opacity="0.8"/><circle cx="640" cy="176" r="1.4" fill="#ffffff" opacity="0.7"/>' : '' }, st);
    g += win(668, 164, 46, 44, { open: bat, room: RDOT.bathroom, curtain: bat ? '#eaf8ff' : null, box: true, tape: true, inside: bat ? '<path d="M672 196 q5 -3 10 0 t10 0 t10 0 t10 0" stroke="#ffffff" stroke-width="1.4" fill="none" opacity="0.8"/>' : '' }, st);
    if (!mov) g += '<rect x="' + RX0 + '" y="' + F + '" width="' + (RX1 - RX0) + '" height="' + (B - F) + '" fill="#2a2030" opacity="0.18"/>';
    if (!bat) g += '<rect x="' + RX0 + '" y="' + T + '" width="' + (RX1 - RX0) + '" height="' + (F - T) + '" fill="#2a2030" opacity="0.18"/>';
    // right hip roof + vent pipe
    const rr = 'M' + (RX0 - 12) + ' ' + (T + 2) + ' L' + (RX0 + 30) + ' 98 L' + (RX1 - 30) + ' 98 L' + (RX1 + 12) + ' ' + (T + 2) + 'Z';
    g += '<rect x="702" y="80" width="9" height="26" fill="#a8b0b8" stroke="' + OL + '" stroke-width="1.2"/><rect x="699" y="76" width="15" height="6" rx="1.5" fill="#8a929a" stroke="' + OL + '" stroke-width="1.1"/>';
    if (bat) for (let i = 0; i < 3; i++) g += '<circle cx="706" cy="72" r="2.4" fill="#ffffff" stroke="#9fd8f0" stroke-width="0.6" opacity="0"><animate attributeName="cy" values="74;44" dur="3.6s" begin="' + (i * 1.2) + 's" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.9;0" dur="3.6s" begin="' + (i * 1.2) + 's" repeatCount="indefinite"/></circle>';
    g += '<clipPath id="mmRR"><path d="' + rr + '"/></clipPath><path d="' + rr + '" fill="url(#mmRoof)" stroke="' + OL + '" stroke-width="1.5"/>' + shingles(RX0 - 12, RX1 + 12, 98, T, P.shingle, 'mmRR', 8);
    if (t === 0) g += '<path d="M640 120 l11 -1 l1 8 l-11 1Z M690 136 l9 0 l0 7 l-9 0Z" fill="#5a3a28" opacity="0.6"/>';
    g += '<path d="' + 'M' + (RX0 - 14) + ' ' + (T + 3) + ' L' + (RX0 + 30) + ' 97 L' + (RX1 - 30) + ' 97 L' + (RX1 + 14) + ' ' + (T + 3) + '" fill="none" stroke="' + P.trim + '" stroke-width="4" stroke-linejoin="round"/>';
    g += '<rect x="' + (RX0 - 6) + '" y="' + (T + 1) + '" width="' + (RX1 - RX0 + 12) + '" height="5" fill="#2a2030" opacity="0.18"/>';
    // a little dormer with a round window on the right roof
    g += '<path d="M640 128 L652 112 L664 128Z" fill="' + P.wall0 + '" stroke="' + OL + '" stroke-width="1.1"/><path d="M636 129 L652 108 L668 129" fill="none" stroke="' + P.roof1 + '" stroke-width="4" stroke-linejoin="round"/><circle cx="652" cy="122" r="4" fill="' + (bat ? mix(RDOT.bathroom, '#fff4d8', 0.3) : '#352f3e') + '" stroke="' + OL + '" stroke-width="0.9"/>';
    if (snow) g += snowCap('M' + (RX0 - 14) + ' ' + (T + 3) + ' L' + (RX0 + 30) + ' 95 L' + (RX1 - 30) + ' 95 L' + (RX1 + 14) + ' ' + (T + 3) + ' L' + (RX1 + 4) + ' ' + (T + 1) + ' L' + (RX1 - 32) + ' 101 L' + (RX0 + 32) + ' 101 L' + (RX0 - 4) + ' ' + (T + 1) + 'Z');
    if (t === 3) [RX0 + 30, RX1 - 30].forEach(x => { g += '<path d="M' + x + ' 97 V76" stroke="#8a6a2a" stroke-width="1.6"/><path d="M' + x + ' 76 L' + (x + 15) + ' 80 L' + x + ' 85Z" fill="#9a2a3a" stroke="' + OL + '" stroke-width="0.9"/><circle cx="' + x + '" cy="75" r="1.8" fill="#ffd66b"/>'; });
    if (t === 0) g += '<path d="M' + (RX0 - 8) + ' ' + (T + 5) + ' Q660 ' + (T + 13) + ' ' + (RX1 + 6) + ' ' + (T + 6) + '" stroke="#8a8478" stroke-width="2.4" fill="none"/>';
    // ---- centre: Living Room + the Dance Room dome ----
    g += '<rect x="410" y="' + (CT - 10) + '" width="180" height="12" fill="#2a2030" opacity="0.12"/>';
    // dome (behind the parapet)
    const dan = O.dance, DX = 500, DY = 170, DR = 46;
    g += '<clipPath id="mmDome"><path d="M' + (DX - DR) + ' ' + DY + ' A' + DR + ' ' + DR + ' 0 0 1 ' + (DX + DR) + ' ' + DY + ' Z"/></clipPath>';
    if (dan) {
      const pc = ['#8f7bff', '#6fb8ff', '#ffc94a', '#7be0c0', '#ff9a6a', '#b48cff'];
      g += '<path d="M' + (DX - DR) + ' ' + DY + ' A' + DR + ' ' + DR + ' 0 0 1 ' + (DX + DR) + ' ' + DY + ' Z" fill="#2c2350"/><g clip-path="url(#mmDome)">';
      for (let i = 0; i < 6; i++) { const a0 = Math.PI + i * Math.PI / 6, a1 = a0 + Math.PI / 6; g += '<path d="M' + DX + ' ' + DY + ' L' + r1(DX + Math.cos(a0) * 60) + ' ' + r1(DY + Math.sin(a0) * 60) + ' L' + r1(DX + Math.cos(a1) * 60) + ' ' + r1(DY + Math.sin(a1) * 60) + 'Z" fill="' + pc[i] + '" opacity="0.5"><animate attributeName="opacity" values="0.35;0.7;0.35" dur="' + (2.4 + i * 0.3) + 's" repeatCount="indefinite"/></path>'; }
      g += '<line x1="500" y1="124" x2="500" y2="142" stroke="#c9c9d6" stroke-width="0.8"/><circle cx="500" cy="149" r="8" fill="url(#mmDisco)" stroke="#6a6a7a" stroke-width="0.8"/><path d="M492 149 H508 M500 141 V157 M494 144 Q500 147 506 144 M494 154 Q500 151 506 154" stroke="#8a8a9a" stroke-width="0.5" fill="none"/>';
      for (let i = 0; i < 6; i++) g += '<circle cx="' + (474 + i * 10) + '" cy="' + (138 + (i % 3) * 9) + '" r="1.6" fill="' + pc[(i + 2) % 6] + '"><animate attributeName="opacity" values="0;1;0" dur="1.4s" begin="' + (i * 0.23).toFixed(2) + 's" repeatCount="indefinite"/></circle>';
      g += '<ellipse cx="486" cy="140" rx="12" ry="20" fill="#ffffff" opacity="0.18" transform="rotate(30 486 140)"/></g>';
    } else {
      g += '<path d="M' + (DX - DR) + ' ' + DY + ' A' + DR + ' ' + DR + ' 0 0 1 ' + (DX + DR) + ' ' + DY + ' Z" fill="#3e3a52"/><g clip-path="url(#mmDome)"><path d="M450 120 Q470 132 486 124 Q500 140 520 128 Q534 140 552 132 V172 H450Z" fill="#8a7a62" opacity="0.92"/><path d="M450 136 Q472 146 492 138 Q506 150 528 142 Q540 150 552 146" stroke="#6a5a46" stroke-width="1" fill="none"/>' + web(458, 152, 1) + '</g>';
      g += plank(462, 152, 538, 136, 6.5, 2) + plank(466, 136, 534, 158, 6.5, 3);
    }
    for (let i = -2; i <= 2; i++) { const s = Math.sin(i * Math.PI / 6.4), rx = Math.abs(s) * DR; g += i === 0 ? '<path d="M500 ' + DY + ' V' + (DY - DR) + '" stroke="#5a4a7a" stroke-width="1.6"/>' : '<path d="M' + r1(DX + s * DR) + ' ' + DY + ' A' + r1(rx) + ' ' + DR + ' 0 0 ' + (s < 0 ? 1 : 0) + ' 500 ' + (DY - DR) + '" stroke="#5a4a7a" stroke-width="1.6" fill="none"/>'; }
    g += '<path d="M' + (DX - DR * 0.86) + ' ' + (DY - DR * 0.5) + ' Q500 ' + (DY - DR * 0.62) + ' ' + (DX + DR * 0.86) + ' ' + (DY - DR * 0.5) + '" stroke="#5a4a7a" stroke-width="1.3" fill="none"/>';
    g += '<path d="M' + (DX - DR) + ' ' + DY + ' A' + DR + ' ' + DR + ' 0 0 1 ' + (DX + DR) + ' ' + DY + '" fill="none" stroke="' + OL + '" stroke-width="1.8"/>';
    g += '<rect x="496" y="118" width="8" height="6" rx="1" fill="' + (t >= 3 ? '#ffd66b' : '#c9b8e8') + '" stroke="' + OL + '" stroke-width="1"/><path d="M500 118 V108" stroke="' + OL + '" stroke-width="1.4"/>' + (t >= 3 ? '<path d="M500 98 l2.2 4.6 5 .7 -3.6 3.5 .9 5 -4.5 -2.4 -4.5 2.4 .9 -5 -3.6 -3.5 5 -.7Z" fill="#ffd66b" stroke="#a8781a" stroke-width="0.8"/>' : '<circle cx="500" cy="107" r="2.6" fill="' + P.trim + '" stroke="' + OL + '" stroke-width="0.9"/>');
    if (snow) g += snowCap('M' + (DX - DR + 6) + ' ' + (DY - 22) + ' Q500 ' + (DY - DR - 6) + ' ' + (DX + DR - 6) + ' ' + (DY - 22) + ' Q500 ' + (DY - DR + 4) + ' ' + (DX - DR + 6) + ' ' + (DY - 22) + 'Z');
    // drum + parapet
    g += '<rect x="448" y="' + DY + '" width="104" height="16" fill="' + P.wall0 + '" stroke="' + OL + '" stroke-width="1.3"/>' + [462, 481, 500, 519, 538].map(x => '<circle cx="' + x + '" cy="' + (DY + 8) + '" r="4.2" fill="' + (dan ? '#b8a6ff' : '#352f3e') + '" stroke="' + OL + '" stroke-width="0.9"/>').join('');
    g += '<rect x="414" y="' + (CT - 12) + '" width="172" height="12" fill="' + P.trim + '" stroke="' + OL + '" stroke-width="1.3"/>' + Array.from({ length: 15 }, (_, i) => '<rect x="' + (419 + i * 11) + '" y="' + (CT - 9.5) + '" width="4" height="7" rx="1.5" fill="' + P.wall0 + '" stroke="' + OL + '" stroke-width="0.6"/>').join('');
    if (snow) g += snowCap('M412 ' + (CT - 12) + ' Q500 ' + (CT - 18) + ' 588 ' + (CT - 12) + ' L588 ' + (CT - 9) + ' Q500 ' + (CT - 13) + ' 412 ' + (CT - 9) + 'Z');
    // living walls (stone-ish plaster)
    g += '<rect x="' + LX1 + '" y="' + CT + '" width="' + (RX0 - LX1) + '" height="' + (B - CT) + '" fill="url(#mmWallC)" stroke="' + OL + '" stroke-width="1.4"/>';
    g += '<rect x="' + LX1 + '" y="' + CT + '" width="10" height="' + (B - CT) + '" fill="#2a2030" opacity="0.12"/><rect x="' + (RX0 - 10) + '" y="' + CT + '" width="10" height="' + (B - CT) + '" fill="#2a2030" opacity="0.08"/>';
    g += win(434, 218, 36, 40, { open: true, room: RDOT.living, shutters: true, curtain: '#fff3d8', box: true, tape: true }, st) + win(530, 218, 36, 40, { open: true, room: RDOT.living, shutters: true, curtain: '#fff3d8', box: true }, st);
    // porch + front door
    g += '<path d="M474 236 L500 222 L526 236Z" fill="url(#mmRoof)" stroke="' + OL + '" stroke-width="1.2"/><rect x="472" y="235" width="56" height="4" fill="' + P.trim + '" stroke="' + OL + '" stroke-width="1"/>';
    // the front door (Nov 13: its own group so the Home trip can swing it open; the warm doorway light sits behind it)
    g += '<path d="M484 300 V258 A16 16 0 0 1 516 258 V300Z" fill="' + P.trim + '" stroke="' + OL + '" stroke-width="1.3"/><path d="M488 300 V259 A12 12 0 0 1 512 259 V300Z" fill="#3a2418"/>'
      + '<path class="mm-doorlight" d="M488 300 V259 A12 12 0 0 1 512 259 V300Z" fill="url(#mmDoorL)" opacity="0"/>'
      + '<g class="mm-door"><path d="M488 300 V259 A12 12 0 0 1 512 259 V300Z" fill="' + P.door + '" stroke="' + OL + '" stroke-width="1.1"/>'
      + '<path d="M494 298 V262 M500 298 V256 M506 298 V262" stroke="' + mix(P.door, '#000000', 0.25) + '" stroke-width="0.8"/><circle cx="500" cy="263" r="4.2" fill="#fff4d0" stroke="' + OL + '" stroke-width="0.9"/><circle cx="507" cy="281" r="1.6" fill="#ffd66b" stroke="#8a6a1a" stroke-width="0.5"/></g>';
    [476, 524].forEach(x => { g += '<rect x="' + (x - 2.5) + '" y="246" width="5" height="9" rx="1.5" fill="#fff0b0" stroke="' + OL + '" stroke-width="0.9"/><circle cx="' + x + '" cy="250" r="7" fill="#fff0b0" opacity="' + (t === 0 ? 0.15 : 0.35) + '" filter="url(#mmB2)"/>'; });
    g += '<rect x="478" y="300" width="44" height="5" rx="1" fill="#b8ab98" stroke="' + OL + '" stroke-width="1"/><rect x="472" y="304" width="56" height="5" rx="1" fill="#a89a86" stroke="' + OL + '" stroke-width="1"/>';
    // foundation
    [[LX0, LX1], [LX1, RX0], [RX0, RX1]].forEach(([a, b]) => { g += '<rect x="' + (a - 1) + '" y="293" width="' + (b - a + 2) + '" height="8" fill="#b8ab98" stroke="' + OL + '" stroke-width="1"/>' + Array.from({ length: Math.floor((b - a) / 14) }, (_, i) => '<path d="M' + (a + 7 + i * 14) + ' 293 V301" stroke="#8a7c6a" stroke-width="0.7"/>').join(''); });
    // locked room signs
    if (!kit) g += lockSign(340, 252, ROOMS.kitchen.lv, 'Kitchen');
    if (!bed) g += lockSign(340, 176, ROOMS.bedroom.lv, 'Bedroom');
    if (!mov) g += lockSign(660, 252, ROOMS.movie.lv, 'Movie Room');
    if (!bat) g += lockSign(660, 176, ROOMS.bathroom.lv, 'Bathroom');
    if (!dan) g += lockSign(500, 134, ROOMS.dance.lv, 'Dance Room', 0.92);
    // royal bunting
    if (t >= 2) { const cols = t === 3 ? ['#9a2a3a', '#ffd66b', '#3f5bb8'] : ['#ffd24a', '#7fae8e', '#6aa0c8']; let b = '<path d="M418 ' + (CT + 4) + ' Q500 ' + (CT + 16) + ' 582 ' + (CT + 4) + '" stroke="#7a5a3a" stroke-width="0.8" fill="none"/>';
      for (let i = 0; i < 12; i++) { const u = (i + 0.5) / 12, x = 418 + 164 * u, y = CT + 4 + 12 * 4 * u * (1 - u); b += '<path d="M' + r1(x - 4.5) + ' ' + r1(y) + ' L' + r1(x + 4.5) + ' ' + r1(y) + ' L' + r1(x) + ' ' + r1(y + 8) + 'Z" fill="' + cols[i % 3] + '" stroke="' + OL + '" stroke-width="0.5"/>'; } g += b; }
    return g;
  }

  function backyard(st) {
    const O = st.open.backyard, t = st.tier, P = st.P, snow = st.season === 'snowy';
    let g = '';
    if (O) {
      // hoop
      g += '<path d="M790 300 V214" stroke="#5a6a7a" stroke-width="3.2"/><path d="M790 300 V214" stroke="' + OL + '" stroke-width="0.6" opacity="0.5"/><rect x="772" y="200" width="36" height="24" rx="2" fill="#ffffff" stroke="' + OL + '" stroke-width="1.2"/><rect x="783" y="208" width="14" height="10" fill="none" stroke="#e8433a" stroke-width="1.6"/>'
        + '<ellipse cx="790" cy="226" rx="8" ry="2.2" fill="none" stroke="#f08a2a" stroke-width="1.8"/><path d="M782 226 L785 236 L795 236 L798 226 M786 226 L788 236 M794 226 L792 236" stroke="#ffffff" stroke-width="0.8" fill="none"/>';
      // slide
      g += '<path d="M866 300 V230 M884 300 V230" stroke="#8a929a" stroke-width="2"/>' + [240, 252, 264, 276, 288].map(y => '<path d="M866 ' + y + ' H884" stroke="#8a929a" stroke-width="1.4"/>').join('') + '<rect x="862" y="224" width="26" height="7" rx="2" fill="#ffc94a" stroke="' + OL + '" stroke-width="1"/>'
        + '<path d="M886 228 C904 232 906 268 930 296 L922 300 C898 274 896 240 884 234Z" fill="#ff8a5a" stroke="' + OL + '" stroke-width="1.1"/>';
      // trampoline net top
      g += '<path d="M818 268 Q834 252 850 268" stroke="#4a4a5a" stroke-width="1" fill="none"/><path d="M818 268 V300 M850 268 V300" stroke="#4a4a5a" stroke-width="1.6"/><path d="M820 270 Q834 258 848 270 V292 H820Z" fill="#6fb8ff" opacity="0.18"/>';
    } else {
      for (let i = 0; i < 10; i++) { const x = 758 + i * 15 + rnd(i, 3) * 6, h = 14 + rnd(i, 4) * 16; g += '<path d="M' + r1(x) + ' 304 Q' + r1(x - 3) + ' ' + r1(304 - h * 0.6) + ' ' + r1(x + 2) + ' ' + r1(304 - h) + ' M' + r1(x + 2) + ' 304 Q' + r1(x + 6) + ' ' + r1(304 - h * 0.5) + ' ' + r1(x + 8) + ' ' + r1(304 - h * 0.8) + '" stroke="' + mix('#8a7a4a', P.tr1, 0.3) + '" stroke-width="1.6" fill="none"/>'; }
    }
    // fence (pickets) with a gate in the middle
    const pc = t === 0 ? '#b8b0a2' : '#fffaf1', pd = t === 0 ? '#8a8274' : '#c9bfae';
    g += '<path d="M752 282 H904 M752 296 H904" stroke="' + pd + '" stroke-width="3"/>';
    for (let i = 0; i < 19; i++) { const x = 752 + i * 8.2, gate = i >= 8 && i <= 10, tilt = t === 0 && i % 5 === 2 ? 6 : 0, top = 266 - (gate ? 3 : 0);
      g += '<path d="M' + r1(x) + ' 306 V' + top + ' l3 -4 l3 4 V306Z" fill="' + pc + '" stroke="' + OL + '" stroke-width="0.9" transform="rotate(' + tilt + ' ' + r1(x + 3) + ' 306)"/>';
      if (snow) g += '<ellipse cx="' + r1(x + 3) + '" cy="' + (top - 3) + '" rx="3.6" ry="1.6" fill="#ffffff"/>'; }
    g += '<rect x="750" y="262" width="5" height="46" fill="' + pd + '" stroke="' + OL + '" stroke-width="0.9"/><rect x="903" y="262" width="5" height="46" fill="' + pd + '" stroke="' + OL + '" stroke-width="0.9"/>';
    if (!O) g += '<path d="M818 282 q6 6 12 0 q6 6 12 0" stroke="#8a8a92" stroke-width="2" fill="none"/><path d="M818 282 q6 6 12 0 q6 6 12 0" stroke="#c9c9d2" stroke-width="0.8" fill="none"/>' + lockSign(830, 236, ROOMS.backyard.lv, 'Backyard', 0.95);
    return g;
  }

  function beach(st) {
    const O = st.open.beach, P = st.P;
    let g = '<path d="M900 300 Q940 268 1010 262 L1010 330 Q960 322 900 318Z" fill="' + P.sand + '" stroke="' + mix(P.sand, '#8a6a3a', 0.35) + '" stroke-width="1.2"/>';
    g += palm(948, 286, 1.15, st, 7) + palm(985, 296, 0.9, st, 8);
    if (O) g += '<path d="M922 300 L932 270" stroke="#7a5a3a" stroke-width="1.4"/><path d="M914 274 Q932 258 950 274Z" fill="#ff8a5a" stroke="' + OL + '" stroke-width="1"/><path d="M923 274 Q932 262 941 274" fill="#ffffff" opacity="0.8"/>';
    else g += '<path d="M908 306 V284 M960 312 V290" stroke="#7a5a3a" stroke-width="2"/><path d="M908 288 Q934 298 960 294" stroke="#c9a46a" stroke-width="1.6" fill="none"/>' + lockSign(934, 248, ROOMS.beach.lv, 'Beach', 0.9);
    return g;
  }

  function sky(st) {
    const P = st.P, sea = st.season;
    let g = '<rect x="-60" y="-20" width="1120" height="280" fill="url(#mmSky)"/>';
    if (sea === 'sunny') g += '<circle cx="150" cy="70" r="70" fill="url(#mmSun)" opacity="' + r1(0.55 + 0.45 * st.f) + '"/><circle cx="150" cy="70" r="24" fill="#fff6c8" opacity="' + r1(0.7 + 0.3 * st.f) + '"/>';
    if (sea === 'snowy') g += '<circle cx="160" cy="70" r="22" fill="#ffffff" opacity="0.35" filter="url(#mmB3)"/>';
    const cc = sea === 'rainy' ? '#b3bcc6' : sea === 'snowy' ? '#eef2f6' : '#ffffff', cs = sea === 'rainy' ? '#8e98a4' : '#d6e6f2';
    [[90, 40, 1.1, 0], [330, 26, 0.8, 1], [640, 48, 1.2, 2], [860, 30, 0.9, 3], [1000, 60, 1, 4]].forEach(([x, y, s, i]) => {
      const blob = '<g transform="translate(' + x + ' ' + y + ') scale(' + s + ')"><ellipse cx="0" cy="6" rx="46" ry="11" fill="' + cs + '"/><circle cx="-22" cy="0" r="14" fill="' + cc + '"/><circle cx="0" cy="-8" r="19" fill="' + cc + '"/><circle cx="22" cy="-1" r="15" fill="' + cc + '"/><ellipse cx="0" cy="4" rx="42" ry="10" fill="' + cc + '"/></g>';
      g += '<g>' + blob + '<animateTransform attributeName="transform" type="translate" values="0 0;' + (30 + i * 6) + ' 0;0 0" dur="' + (70 + i * 13) + 's" repeatCount="indefinite"/></g>'; });
    if (sea === 'rainy') g += '<rect x="-60" y="-20" width="1120" height="120" fill="#7a8692" opacity="0.18"/>';
    // the sea + far islands + the lighthouse
    g += '<rect x="-60" y="214" width="1120" height="40" fill="url(#mmSea)"/>';
    g += '<path d="M40 222 Q80 204 130 214 Q160 206 190 222Z" fill="' + mix(P.sea1, '#6a8a9a', 0.5) + '" opacity="0.55"/><path d="M820 222 Q850 210 880 222Z" fill="' + mix(P.sea1, '#6a8a9a', 0.5) + '" opacity="0.5"/>';
    g += '<g opacity="0.75"><path d="M968 222 Q980 214 994 222Z" fill="' + mix(P.sea1, '#6a8a9a', 0.4) + '"/><path d="M978 216 L979.5 196 H984.5 L986 216Z" fill="#ffffff" stroke="#8a7a8a" stroke-width="0.5"/><path d="M979.2 202 H985 M979 208 H985.4" stroke="#e8433a" stroke-width="1.6"/><rect x="979" y="192" width="6" height="4" fill="#fff4b0"/></g>';
    for (let i = 0; i < 9; i++) g += '<path d="M' + (40 + i * 112) + ' ' + (228 + (i % 3) * 6) + ' q6 -2 12 0" stroke="#ffffff" stroke-width="1" fill="none" opacity="' + r1(0.2 + 0.4 * st.f) + '"><animate attributeName="opacity" values="0.1;' + r1(0.25 + 0.5 * st.f) + ';0.1" dur="' + (3 + i % 3) + 's" repeatCount="indefinite"/></path>';
    return g;
  }

  function ground(st) {
    const P = st.P, v = st.v, snow = st.season === 'snowy', rain = st.season === 'rainy';
    let g = '<path d="M-60 240 Q120 232 300 236 Q500 240 700 234 Q860 230 1060 238 V480 H-60Z" fill="url(#mmGrass)"/>';
    g += '<path d="M-60 240 Q120 232 300 236 Q500 240 700 234 Q860 230 1060 238" stroke="' + P.sand + '" stroke-width="3" fill="none" opacity="0.8"/>';
    // dry earth + cracks when lifeless
    const dk = 1 - SS(0.05, 0.5, v);
    if (dk > 0.02 && !snow) { g += '<g opacity="' + r1(dk) + '">' + [[160, 330, 60, 12], [700, 340, 70, 13], [300, 400, 54, 10], [860, 410, 66, 12], [90, 420, 50, 9]].map(([x, y, a, b]) => '<ellipse cx="' + x + '" cy="' + y + '" rx="' + a + '" ry="' + b + '" fill="#8a7a52" opacity="0.55"/>').join('')
      + '<path d="M120 330 l14 4 l8 -6 l12 5 M150 334 l2 9 M690 344 l12 -3 l10 6 l14 -2 M712 341 l-2 8 M290 402 l10 3 l9 -4 l12 4 M850 412 l13 -4 l9 5 l12 -3" stroke="#5a4a32" stroke-width="1" fill="none"/></g>'; }
    // tufts
    let tf = ''; const bl = snow ? '#c9d6dc' : mix('#9a8a5a', '#4f9a36', v), bl2 = snow ? '#e6eef2' : mix('#b8a874', '#7cc85a', v);
    for (let i = 0; i < 150; i++) { const y = 248 + Math.pow(rnd(i, 1), 0.8) * 205, x = -20 + rnd(i, 2) * 1040, pw = 36 + (y - 300) * 0.9; if (y > 300 && Math.abs(x - 500) < pw) continue;
      const s = 0.5 + (y - 248) / 205 * 1.1, bend = (1 - v) * 3;
      tf += '<path d="M' + r1(x - 3 * s) + ' ' + r1(y) + ' q' + r1(-1 + bend) + ' ' + r1(-5 * s) + ' ' + r1(-2 * s + bend) + ' ' + r1(-8 * s) + ' M' + r1(x) + ' ' + r1(y) + ' q1 ' + r1(-6 * s) + ' ' + r1(bend) + ' ' + r1(-10 * s) + ' M' + r1(x + 3 * s) + ' ' + r1(y) + ' q2 ' + r1(-4 * s) + ' ' + r1(3 * s + bend) + ' ' + r1(-7 * s) + '" stroke="' + (i % 3 ? bl : bl2) + '" stroke-width="' + r1(0.9 * s + 0.3) + '" fill="none" stroke-linecap="round"/>'; }
    g += tf;
    if (v > 0.5 && !snow) { let fl = '', fk = SS(0.5, 0.85, v); for (let i = 0; i < 46; i++) { const y = 260 + rnd(i, 7) * 190, x = rnd(i, 8) * 1000, pw = 40 + (y - 300) * 0.9; if (y > 300 && Math.abs(x - 500) < pw) continue; const c = ['#ffffff', '#fff27a', '#ffb3c7', '#c9b8ff', '#ff9a6a'][i % 5], s = 0.6 + (y - 260) / 190;
      fl += '<g transform="translate(' + r1(x) + ' ' + r1(y) + ') scale(' + r1(s) + ')">' + [0, 72, 144, 216, 288].map(a => '<circle cx="' + r1(Math.cos(a * Math.PI / 180) * 2) + '" cy="' + r1(Math.sin(a * Math.PI / 180) * 2) + '" r="1.5" fill="' + c + '"/>').join('') + '<circle r="1" fill="#ffcf3a"/></g>'; }
      g += '<g opacity="' + r1(fk) + '">' + fl + '</g>'; }
    if (snow) g += '<path d="M-60 300 Q200 288 420 300 T1060 296 V480 H-60Z" fill="#ffffff" opacity="0.35"/>';
    if (rain) g += '<g opacity="0.55">' + [[220, 392, 30, 4], [760, 380, 26, 4], [612, 430, 22, 3.4]].map(([x, y, a, b]) => '<ellipse cx="' + x + '" cy="' + y + '" rx="' + a + '" ry="' + b + '" fill="' + mix(st.P.sky0, '#ffffff', 0.3) + '"/><ellipse cx="' + x + '" cy="' + y + '" rx="4" ry="1" fill="none" stroke="#ffffff" stroke-width="0.6"><animate attributeName="rx" values="2;' + a * 0.7 + '" dur="1.6s" repeatCount="indefinite"/><animate attributeName="ry" values="0.5;' + b * 0.7 + '" dur="1.6s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;0" dur="1.6s" repeatCount="indefinite"/></ellipse>').join('') + '</g>';
    return g;
  }

  function path(st) {
    const P = st.P, snow = st.season === 'snowy', c0 = snow ? '#e8ecef' : mix(P.sand, '#cdbb98', 0.4), c1 = mix(c0, '#7a6a52', 0.25);
    let g = '<path d="M478 309 C470 340 440 372 404 470 H596 C560 372 530 340 522 309Z" fill="' + c0 + '"/><path d="M478 309 C470 340 440 372 404 470 M522 309 C530 340 560 372 596 470" stroke="' + c1 + '" stroke-width="1.6" fill="none"/>';
    [[500, 322, 13, 3.6], [494, 342, 17, 4.6], [506, 366, 21, 5.6], [496, 394, 26, 6.4]].forEach(([x, y, a, b]) => { g += '<ellipse cx="' + x + '" cy="' + (y + 1.5) + '" rx="' + a + '" ry="' + b + '" fill="' + c1 + '"/><ellipse cx="' + x + '" cy="' + y + '" rx="' + a + '" ry="' + b + '" fill="' + mix(c0, '#ffffff', 0.35) + '" stroke="' + c1 + '" stroke-width="0.8"/>'; });
    // the pad the creature stands on (a soft lit stone)
    g += '<ellipse cx="500" cy="420" rx="118" ry="24" fill="url(#mmPadGlow)"/><ellipse cx="500" cy="424" rx="84" ry="16" fill="' + mix(c1, '#000000', 0.15) + '"/><ellipse cx="500" cy="420" rx="84" ry="16" fill="url(#mmPad)" stroke="' + OL + '" stroke-width="1.4"/><ellipse cx="500" cy="418" rx="70" ry="11" fill="none" stroke="#ffffff" stroke-width="1.4" opacity="0.6"/>';
    return g;
  }

  function weather(st) {
    if (st.season === 'rainy') { let r = ''; for (let i = 0; i < 110; i++) { const x = rnd(i, 21) * 1100 - 50, y = rnd(i, 22) * 460; r += '<path d="M' + r1(x) + ' ' + r1(y) + ' l-4 14" stroke="#e8f2ff" stroke-width="1" opacity="' + r1(0.35 + rnd(i, 23) * 0.35) + '"/>'; }
      return '<g pointer-events="none"><g>' + r + '<animateTransform attributeName="transform" type="translate" values="16 -460;0 0" dur="0.9s" repeatCount="indefinite"/></g><g>' + r + '<animateTransform attributeName="transform" type="translate" values="16 0;0 460" dur="0.9s" repeatCount="indefinite"/></g></g>'; }
    if (st.season === 'snowy') { let s = ''; for (let i = 0; i < 90; i++) { const x = rnd(i, 31) * 1000, y = rnd(i, 32) * 460, r = 1 + rnd(i, 33) * 2; s += '<circle cx="' + r1(x) + '" cy="' + r1(y) + '" r="' + r1(r) + '" fill="#ffffff" opacity="' + r1(0.6 + rnd(i, 34) * 0.4) + '"/>'; }
      return '<g>' + s + '<animateTransform attributeName="transform" type="translate" values="0 -460;14 0" dur="14s" repeatCount="indefinite"/></g><g>' + s + '<animateTransform attributeName="transform" type="translate" values="0 0;14 460" dur="14s" repeatCount="indefinite"/></g>'; }
    if (st.season === 'sunny' && st.f > 0.3) { let b = ''; for (let i = 0; i < 3; i++) b += '<path d="M0 0 q3 -3 6 0 q3 -3 6 0" stroke="#4a4a5a" stroke-width="1" fill="none"><animateMotion dur="' + (18 + i * 5) + 's" repeatCount="indefinite" path="M' + (-40 - i * 30) + ' ' + (60 + i * 18) + ' Q500 ' + (20 + i * 10) + ' 1060 ' + (80 + i * 12) + '"/></path>'; return b; }
    return '';
  }

  function svg(st) {
    const P = st.P;
    const defs = '<defs>'
      + '<linearGradient id="mmSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + P.sky0 + '"/><stop offset="1" stop-color="' + P.sky1 + '"/></linearGradient>'
      + '<radialGradient id="mmSun"><stop offset="0" stop-color="#fff6c8" stop-opacity="0.95"/><stop offset="0.35" stop-color="#fff2b0" stop-opacity="0.45"/><stop offset="1" stop-color="#fff2b0" stop-opacity="0"/></radialGradient>'
      + '<linearGradient id="mmSea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + mix(P.sea0, P.sky1, 0.35) + '"/><stop offset="1" stop-color="' + P.sea1 + '"/></linearGradient>'
      + '<linearGradient id="mmGrass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + mix(P.grass, P.sky1, 0.3) + '"/><stop offset="0.3" stop-color="' + P.grass + '"/><stop offset="1" stop-color="' + mix(P.grass, '#24361a', 0.22) + '"/></linearGradient>'
      + '<linearGradient id="mmWall" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="' + P.wall0 + '"/><stop offset="1" stop-color="' + mix(P.wall0, P.wall1, 0.55) + '"/></linearGradient>'
      + '<linearGradient id="mmWallC" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + mix(P.wall0, '#ffffff', 0.25) + '"/><stop offset="1" stop-color="' + P.wall0 + '"/></linearGradient>'
      + '<linearGradient id="mmRoof" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + P.roof0 + '"/><stop offset="1" stop-color="' + P.roof1 + '"/></linearGradient>'
      + '<linearGradient id="mmWood" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d9a86a"/><stop offset="1" stop-color="#b07a46"/></linearGradient>'
      + '<radialGradient id="mmDisco" cx="0.35" cy="0.3"><stop offset="0" stop-color="#ffffff"/><stop offset="0.6" stop-color="#c9c9d6"/><stop offset="1" stop-color="#7a7a8a"/></radialGradient>'
      + '<radialGradient id="mmDoorL" cx="0.5" cy="0.7" r="0.8"><stop offset="0" stop-color="#fffbe6"/><stop offset="0.55" stop-color="#ffe39a"/><stop offset="1" stop-color="#ffb84a"/></radialGradient>'
      + '<radialGradient id="mmPadGlow"><stop offset="0" stop-color="#ffffff" stop-opacity="0.75"/><stop offset="0.6" stop-color="#fff6d8" stop-opacity="0.35"/><stop offset="1" stop-color="#fff6d8" stop-opacity="0"/></radialGradient>'
      + '<radialGradient id="mmPad" cx="0.45" cy="0.35"><stop offset="0" stop-color="#f6efe4"/><stop offset="1" stop-color="#cbbca6"/></radialGradient>'
      + '<radialGradient id="mmVig" cx="0.5" cy="0.55" r="0.75"><stop offset="0.6" stop-color="#1c0a38" stop-opacity="0"/><stop offset="1" stop-color="#1c0a38" stop-opacity="0.32"/></radialGradient>'
      + '<filter id="mmB1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.2"/></filter><filter id="mmB2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.5"/></filter><filter id="mmB3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5"/></filter>'
      + '</defs>';
    let g = defs + sky(st) + ground(st);
    // trees behind the house, the beach, the backyard, the house, bushes at its feet
    g += tree(236, 292, 1.05, st, 3) + tree(214, 300, 0.8, st, 4, { fruit: true }) + tree(744, 270, 0.8, st, 5);
    g += beach(st) + backyard(st) + house(st);
    [[276, 302, 1], [356, 304, 0.9], [440, 306, 0.8], [560, 306, 0.8], [626, 304, 0.95], [716, 303, 1]].forEach(([x, y, s], i) => { g += bush(x, y, s, st, i + 11); });
    g += path(st);
    // front trees frame the scene
    g += tree(92, 372, 1.55, st, 9, { fruit: true }) + tree(178, 330, 0.95, st, 10) + tree(1010, 410, 1.3, st, 12);
    g += bush(40, 420, 1.4, st, 21) + bush(930, 446, 1.5, st, 22) + bush(250, 392, 1.1, st, 23) + bush(780, 396, 1.15, st, 24);
    g += weather(st) + '<rect x="-60" y="-20" width="1120" height="500" fill="url(#mmVig)" pointer-events="none"/>';
    // ids made unique per drawing (two scenes on one page, or a redraw, must not borrow each other's gradients)
    const u = 'mm' + (++UID) + '_';
    g = g.replace(/(id="|url\(#)mm/g, '$1' + u);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 460" preserveAspectRatio="xMidYMax slice" width="100%" height="100%" style="display:block">' + g + '</svg>';
  }
  let UID = 0;

  window.MainMenuScene = { v: 2, ROOMS, AREAS, TIERS, DOOR: [500, 282], state, svg, mix };
})();
