// SquishGuide — coach-mark overlay: dims the app, cuts a hole around a target, shows an animated hand + caption.
(function () {
  if (window.SquishGuide) return;
  const CSS = `
@keyframes sgTap{0%,100%{transform:translate(0,0) scale(1)}45%{transform:translate(0,9px) scale(0.9)}}
@keyframes sgRing{0%{transform:scale(0.5);opacity:0.95}100%{transform:scale(1.7);opacity:0}}
@keyframes sgHold{0%,100%{transform:translate(0,0) scale(1)}18%,82%{transform:translate(0,10px) scale(0.9)}}
@keyframes sgTwistL{0%,100%{transform:translate(0,0) rotate(-10deg)}50%{transform:translate(-14px,14px) rotate(-40deg)}}
@keyframes sgTwistR{0%,100%{transform:translate(0,0) rotate(10deg)}50%{transform:translate(14px,-14px) rotate(40deg)}}
@keyframes sgPop{0%{transform:scale(0.7);opacity:0}60%{transform:scale(1.04);opacity:1}100%{transform:scale(1);opacity:1}}
@keyframes sgGlow{0%,100%{opacity:0.55}50%{opacity:1}}
@keyframes sgSpin{to{transform:rotate(360deg)}}
@keyframes sgBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}`;
  const HAND = (fill, ink) => `<svg viewBox="0 0 72 96" width="46" height="61" style="display:block;overflow:visible;filter:drop-shadow(0 4px 6px rgba(0,0,0,0.35))"><path d="M24 17A6 6 0 0 1 36 17L36 42C37 39 41 37.5 44 39C47.4 40.4 48.4 44 47.4 47C48.4 44 51.4 42.4 54.4 43.6C57.8 45 58.8 48.4 57.8 51.6C59.4 49.4 62.6 48.8 64.8 50.6C67.4 52.6 67.8 55.8 67 59L65.4 69C63.8 81.4 54.8 90.6 42.8 90.6L35.8 90.6C23.4 90.6 15.2 81.6 13.8 69.2L12.8 60.6L5.8 50.6C2.8 46.2 9.2 41.6 12.8 46.2L19.4 55.2C20.6 56.8 22.2 57.4 24 57.4Z" fill="${fill}" stroke="${ink}" stroke-width="3.5" stroke-linejoin="round"/></svg>`;
  const el = (tag, css, html) => { const e = document.createElement(tag); if (css) e.style.cssText = css; if (html != null) e.innerHTML = html; return e; };
  const G = {
    root: null, theme: null, layer: null, mode: null, opts: null, raf: 0,
    mount(root, theme) {
      this.rootSel = root; this.theme = Object.assign({ ink: '#4a1a73', paper: '#fff8fd', acc: '#ff4fbf', accInk: '#ffffff', soft: '#9467bd', dim: 'rgba(20,6,40,0.66)', font: "'Fredoka',sans-serif", body: "'Nunito',sans-serif" }, theme || {});
      if (!document.getElementById('sg-css')) { const st = el('style'); st.id = 'sg-css'; st.textContent = CSS; document.head.appendChild(st); }
      if (!this.layer || !this.layer.isConnected) { this.layer = el('div', 'position:fixed;inset:0;z-index:99999;pointer-events:none;'); document.body.appendChild(this.layer); }
      this.root = root;
    },
    rootRect() { const r = typeof this.rootSel === 'string' ? document.querySelector(this.rootSel) : this.rootSel; return r ? r.getBoundingClientRect() : { left: 0, top: 0, width: innerWidth, height: innerHeight, right: innerWidth, bottom: innerHeight }; },
    clear() { cancelAnimationFrame(this.raf); if (this.layer) this.layer.innerHTML = ''; this.mode = null; this.opts = null; this.parts = null; },
    hide() { this.clear(); },
    btn(b, i) {
      const T = this.theme; const p = b.primary !== false && i === 0;
      const e = el('button', `border:3px solid ${T.ink};border-radius:999px;padding:9px 18px;font-family:${T.font};font-weight:700;font-size:15px;cursor:pointer;background:${p ? T.acc : '#fff'};color:${p ? T.accInk : T.ink};box-shadow:0 4px 0 ${T.ink};`, b.label);
      e.onclick = ev => { ev.stopPropagation(); b.onClick && b.onClick(); }; return e;
    },
    // Spotlight on a target element
    spot(o) {
      this.clear(); this.mode = 'spot'; this.opts = o; const T = this.theme;
      const panels = [0, 1, 2, 3].map(() => { const p = el('div', `position:fixed;background:${T.dim};pointer-events:${o.block === false ? 'none' : 'auto'};transition:all .25s ease;`); p.onclick = e => e.stopPropagation(); p.onpointerdown = e => e.stopPropagation(); this.layer.appendChild(p); return p; });
      const ring = el('div', `position:fixed;pointer-events:none;border-radius:${o.radius ?? 16}px;box-shadow:0 0 0 4px ${T.acc}, 0 0 22px 6px ${T.acc};animation:sgGlow 1.4s ease-in-out infinite;transition:all .25s ease;`);
      const hand = el('div', 'position:fixed;pointer-events:none;width:46px;height:61px;');
      if (o.hand === 'two') hand.innerHTML = `<div style="position:absolute;left:-40px;top:6px;transform-origin:18px 8px;animation:sgTwistL 1.8s ease-in-out infinite">${HAND('#fff', T.ink)}</div><div style="position:absolute;left:30px;top:-6px;transform-origin:18px 8px;animation:sgTwistR 1.8s ease-in-out infinite">${HAND('#fff', T.ink)}</div>`;
      else if (o.hand) hand.innerHTML = `<div style="position:absolute;left:4px;top:-6px;width:28px;height:28px;border-radius:50%;border:3px solid ${T.acc};animation:sgRing ${o.hand === 'hold' ? 2.4 : 1.2}s ease-out infinite"></div><div style="animation:${o.hand === 'hold' ? 'sgHold 2.4s' : 'sgTap 1.2s'} ease-in-out infinite">${HAND('#fff', T.ink)}</div>`;
      const bub = this.bubble(o);
      [ring, hand, bub].forEach(x => this.layer.appendChild(x));
      this.parts = { panels, ring, hand, bub };
      const loop = () => { this.raf = requestAnimationFrame(loop); this.place(); };
      loop();
    },
    bubble(o) {
      const T = this.theme;
      const b = el('div', `position:fixed;pointer-events:auto;box-sizing:border-box;padding:12px 14px;border-radius:20px;background:${T.paper};border:3px solid ${T.ink};box-shadow:0 5px 0 ${T.ink}, 0 14px 30px rgba(0,0,0,0.35);color:${T.ink};font-family:${T.body};animation:sgPop .35s ease-out both;display:flex;flex-direction:column;gap:6px;`);
      if (o.title) b.appendChild(el('div', `font-family:${T.font};font-weight:700;font-size:17px;line-height:1.15;`, o.title));
      if (o.text) b.appendChild(el('div', `font-size:13px;font-weight:700;line-height:1.4;color:${T.soft};text-wrap:pretty;`, o.text));
      const prog = el('div', `display:none;height:10px;border-radius:6px;border:2px solid ${T.ink};background:#fff;overflow:hidden;`); const fill = el('div', `height:100%;width:0%;background:${T.acc};transition:width .2s ease;`); prog.appendChild(fill); b.appendChild(prog);
      const note = el('div', `display:none;font-size:12px;font-weight:900;color:${T.ink};`); b.appendChild(note);
      if (o.next) { const row = el('div', 'display:flex;justify-content:flex-end;margin-top:2px;'); row.appendChild(this.btn({ label: o.next, onClick: o.onNext }, 0)); b.appendChild(row); }
      if (this.onSkip && o.skip !== false) { const sk = el('button', `align-self:flex-end;border:none;background:none;padding:2px 0 0;font-family:${T.body};font-size:11.5px;font-weight:900;color:${T.soft};text-decoration:underline;cursor:pointer;`, 'Skip the tour'); sk.onclick = ev => { ev.stopPropagation(); this.onSkip(); }; b.appendChild(sk); }
      b._prog = prog; b._fill = fill; b._note = note; return b;
    },
    update(u) {
      const b = this.parts && this.parts.bub; if (!b) return;
      if (u.progress != null) { b._prog.style.display = 'block'; b._fill.style.width = Math.round(Math.max(0, Math.min(1, u.progress)) * 100) + '%'; }
      if (u.note != null) { b._note.style.display = 'block'; b._note.textContent = u.note; }
    },
    place() {
      const o = this.opts, P = this.parts; if (!o || !P) return;
      const R = this.rootRect(); const W = innerWidth, H = innerHeight;
      const t = o.target ? document.querySelector(o.target) : null;
      const bw = Math.min(o.width || 300, R.width - 24); P.bub.style.width = bw + 'px';
      const tr = t && t.getClientRects().length ? t.getBoundingClientRect() : null;
      const tcx = tr ? tr.left + tr.width / 2 : 0, tcy = tr ? tr.top + tr.height / 2 : 0;
      const off = !tr || tcx < Math.max(0, R.left) || tcx > Math.min(W, R.right) || tcy < Math.max(0, R.top) || tcy > Math.min(H, R.bottom);
      if (off) {
        // target missing or clipped off-screen: never trap touches, just show the bubble
        P.panels.forEach(p => Object.assign(p.style, { width: '0px', height: '0px', pointerEvents: 'none' }));
        P.ring.style.display = 'none'; P.hand.style.display = 'none';
        P.bub.style.left = (R.left + (R.width - bw) / 2) + 'px'; P.bub.style.top = (R.top + (o.bannerTop || 16)) + 'px'; return;
      }
      const r = tr; const pad = o.pad ?? 8;
      P.panels.forEach(p => { p.style.pointerEvents = o.block === false ? 'none' : 'auto'; });
      const x0 = Math.max(0, r.left - pad), y0 = Math.max(0, r.top - pad), x1 = Math.min(W, r.right + pad), y1 = Math.min(H, r.bottom + pad);
      const [a, b, c, d] = P.panels; const set = (p, l, tp, w, h) => { p.style.left = l + 'px'; p.style.top = tp + 'px'; p.style.width = Math.max(0, w) + 'px'; p.style.height = Math.max(0, h) + 'px'; };
      set(a, 0, 0, W, y0); set(b, 0, y1, W, H - y1); set(c, 0, y0, x0, y1 - y0); set(d, x1, y0, W - x1, y1 - y0);
      if (o.block === false) P.panels.forEach(p => { p.style.background = 'transparent'; });
      Object.assign(P.ring.style, { display: o.ring === false ? 'none' : 'block', left: x0 + 'px', top: y0 + 'px', width: (x1 - x0) + 'px', height: (y1 - y0) + 'px' });
      P.hand.style.display = o.hand ? 'block' : 'none';
      const hx = r.left + r.width * (o.handX ?? 0.5), hy = r.top + r.height * (o.handY ?? 0.5);
      P.hand.style.left = (hx - 18) + 'px'; P.hand.style.top = (hy - 6) + 'px';
      const bh = P.bub.offsetHeight || 120; const below = R.bottom - y1, above = y0 - R.top;
      let top = o.place === 'top' || (o.place !== 'bottom' && below < bh + 70 && above > below) ? y0 - bh - 16 : y1 + (o.hand ? 64 : 16);
      top = Math.max(R.top + 8, Math.min(R.bottom - bh - 8, top));
      const left = Math.max(R.left + 12, Math.min(R.right - bw - 12, r.left + r.width / 2 - bw / 2));
      P.bub.style.left = left + 'px'; P.bub.style.top = top + 'px';
    },
    // Non-blocking banner at the top of the app
    banner(o) { this.spot(Object.assign({ block: false, target: null, hand: null }, o)); },
    // Centered card (dims everything)
    card(o) {
      this.clear(); this.mode = 'card'; const T = this.theme; const R = this.rootRect();
      const dim = el('div', `position:fixed;inset:0;background:${T.dim};pointer-events:auto;`); dim.onclick = e => e.stopPropagation(); this.layer.appendChild(dim);
      const w = Math.min(o.width || 340, R.width - 28);
      const c = el('div', `position:fixed;left:${R.left + (R.width - w) / 2}px;top:${R.top + R.height / 2}px;transform:translateY(-50%);width:${w}px;max-height:${R.height - 24}px;overflow:auto;box-sizing:border-box;pointer-events:auto;`);
      const inner = el('div', `box-sizing:border-box;padding:18px 18px 16px;border-radius:26px;background:${T.paper};border:3px solid ${T.ink};box-shadow:0 6px 0 ${T.ink}, 0 20px 40px rgba(0,0,0,0.4);color:${T.ink};font-family:${T.body};display:flex;flex-direction:column;align-items:center;gap:10px;text-align:center;animation:sgPop .4s ease-out both;`);
      if (o.level) {
        const lv = el('div', 'position:relative;width:108px;height:108px;margin-top:-4px;');
        lv.innerHTML = `<div style="position:absolute;inset:-26px;border-radius:50%;background:repeating-conic-gradient(${T.acc}33 0 12deg, transparent 12deg 24deg);animation:sgSpin 9s linear infinite"></div><div style="position:absolute;inset:0;border-radius:50%;background:${T.acc};border:4px solid ${T.ink};box-shadow:0 5px 0 ${T.ink};display:flex;flex-direction:column;align-items:center;justify-content:center;color:${T.accInk};font-family:${T.font};animation:sgBob 1.8s ease-in-out infinite"><span style="font-size:13px;font-weight:700;letter-spacing:2px">LEVEL</span><span style="font-size:46px;font-weight:700;line-height:1">${o.level}</span></div>`;
        inner.appendChild(lv);
      }
      if (o.badge) inner.appendChild(el('div', `padding:3px 12px;border-radius:999px;background:${T.acc};color:${T.accInk};border:2px solid ${T.ink};font-size:11px;font-weight:900;letter-spacing:1.5px;`, o.badge));
      if (o.title) inner.appendChild(el('div', `font-family:${T.font};font-weight:700;font-size:23px;line-height:1.1;`, o.title));
      if (o.text) inner.appendChild(el('div', `font-size:14px;font-weight:700;line-height:1.45;color:${T.soft};text-wrap:pretty;`, o.text));
      if (o.items) {
        const list = el('div', 'display:flex;flex-direction:column;gap:8px;width:100%;margin-top:2px;');
        o.items.forEach(it => {
          const row = el('div', `display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:16px;background:#fff;border:2.5px solid ${T.ink};text-align:left;`);
          row.appendChild(el('div', `flex-shrink:0;width:34px;height:34px;border-radius:50%;background:${it.color || T.acc};border:2.5px solid ${T.ink};display:flex;align-items:center;justify-content:center;color:#fff;font-family:${T.font};font-weight:700;font-size:15px;`, it.icon || ''));
          const tx = el('div', 'flex:1;min-width:0;display:flex;flex-direction:column;gap:2px;');
          tx.appendChild(el('div', `font-family:${T.font};font-weight:700;font-size:15px;line-height:1.15;`, it.title));
          if (it.desc) tx.appendChild(el('div', `font-size:12px;font-weight:700;line-height:1.35;color:${T.soft};`, it.desc));
          row.appendChild(tx);
          if (it.price) { const pb = el('button', `flex-shrink:0;border:2.5px solid ${T.ink};border-radius:999px;padding:6px 10px;background:${T.acc};color:${T.accInk};font-family:${T.font};font-weight:700;font-size:13px;cursor:pointer;box-shadow:0 3px 0 ${T.ink};white-space:nowrap;`, it.price); pb.onclick = e => { e.stopPropagation(); it.onClick && it.onClick(pb); }; row.appendChild(pb); }
          list.appendChild(row);
        });
        inner.appendChild(list);
      }
      if (o.timer) {
        const bar = el('div', `width:100%;height:14px;border-radius:8px;border:2.5px solid ${T.ink};background:#fff;overflow:hidden;`); const f = el('div', `height:100%;width:0%;background:${T.acc};transition:width ${o.timer}ms linear;`); bar.appendChild(f); inner.appendChild(bar);
        requestAnimationFrame(() => requestAnimationFrame(() => { f.style.width = '100%'; }));
      }
      if (o.buttons && o.buttons.length) { const row = el('div', 'display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:4px;'); o.buttons.forEach((b, i) => row.appendChild(this.btn(b, i))); inner.appendChild(row); }
      c.appendChild(inner); this.layer.appendChild(c);
    },
    level(o) { this.card(Object.assign({ buttons: [{ label: o.button || 'Yay!', onClick: o.onButton }] }, o)); },
  };
  window.SquishGuide = G;
})();
