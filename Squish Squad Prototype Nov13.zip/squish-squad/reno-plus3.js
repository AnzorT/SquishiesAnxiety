// Renovation Catalog round 4: cinema / entertainment overhaul. New archetypes for the listed pieces, custom surface art
// (obsidian starlight walls, clean industrial concrete, track spots, aurora halo) and a catalog edit layer (RD.SET3).
// Loaded after reno-plus2.js; sets RenoDraw.PLUS3 when ready. Plants live in reno-flora.js (sets RenoDraw.FLORA).
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS2 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS3) return;
  const K = X.K, { solid, box, cyl, ball, slab, slabX, arcW, disc, prism, prismZ, shade, mix, f1 } = K;
  const N = RD.N, em = RD.H.em, GOLD = '#e2b14a', CH = '#d5dde2', WH = '#ffffff', GL = '#cfe8f2', PI = Math.PI, SA = X.SA, CA = X.CA;
  const mt = o => Object.assign({ mat: 'metal' }, o || {}), wd = o => Object.assign({ mat: 'wood' }, o || {}), cer = o => Object.assign({ mat: 'cer' }, o || {}), fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {}), pt = o => Object.assign({ mat: 'paint' }, o || {});
  const rep = (n, f) => Array.from({ length: n }, (_, i) => f(i));
  const hash = s => { let h = 7; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) | 0; return Math.abs(h); };
  const rng = s => { let h = hash(s) || 1; return () => { h = (h * 1103515245 + 12345) | 0; return ((h >>> 8) & 0xffff) / 65536; }; };
  const n4 = v => Math.round(v * 1e4) / 1e4, P2 = q => f1(q[0]) + ' ' + f1(q[1]);
  const mtx = (o, a, b) => 'matrix(' + [a[0] - o[0], a[1] - o[1], b[0] - o[0], b[1] - o[1], o[0], o[1]].map(n4).join(' ') + ')';
  // decals on a +z (plane) / +x (planeX) face hide when that face turns away from the viewer (no change at the default view, where these faces always show)
  const plane = (p, z, y, x0) => { x0 = x0 || 0; if (p(x0, y, z + 1)[1] - p(x0, y, z)[1] <= 0.002) return 'scale(0)'; return mtx(p(x0, y, z), p(x0 + 1, y, z), p(x0, y - 1, z)); };
  const planeX = (p, x, y, z0) => p(x + 1, y, z0)[1] - p(x, y, z0)[1] <= 0.002 ? 'scale(0)' : mtx(p(x, y, z0), p(x, y, z0 + 1), p(x, y - 1, z0));
  const planeH = (p, y, x0, z0) => { x0 = x0 || 0; z0 = z0 || 0; return mtx(p(x0, y, z0), p(x0 + 1, y, z0), p(x0, y, z0 + 1)); };
  const kOf = p => (p(0, 0, 0)[1] - p(0, 1, 0)[1]) / CA;
  const kt = n => rep(n + 1, i => n4(i / n)).join(';');
  const SPL = n => ' calcMode="spline" keyTimes="' + kt(n) + '" keySplines="' + rep(n, () => '0.42 0 0.58 1').join(';') + '"';
  const B = b => b ? ' begin="' + n4(b) + 's"' : '';
  const an = (a, v, d, b, kts) => '<animate attributeName="' + a + '" values="' + v + '" dur="' + d + 's"' + (kts ? ' keyTimes="' + kts + '"' : '') + B(b) + ' repeatCount="indefinite"/>';
  const anS = (a, v, d, b) => '<animate attributeName="' + a + '" values="' + v + '" dur="' + d + 's"' + SPL(v.split(';').length - 1) + B(b) + ' repeatCount="indefinite"/>';
  const anD = (a, v, d, b) => '<animate attributeName="' + a + '" values="' + v + '" dur="' + d + 's" calcMode="discrete"' + B(b) + ' repeatCount="indefinite"/>';
  const at = (t, v, d, b) => '<animateTransform attributeName="transform" type="' + t + '" values="' + v + '" dur="' + d + 's"' + B(b) + ' repeatCount="indefinite"/>';
  const atS = (t, v, d, b) => '<animateTransform attributeName="transform" type="' + t + '" values="' + v + '" dur="' + d + 's"' + SPL(v.split(';').length - 1) + B(b) + ' repeatCount="indefinite"/>';
  const BLUR = (id, s) => '<filter id="' + id + '" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="' + s + '"/></filter>';
  const bbOf = (pts, m) => { m = m || 4; let a = 1e9, b = 1e9, c = -1e9, d = -1e9; pts.forEach(q => { a = Math.min(a, q[0]); b = Math.min(b, q[1]); c = Math.max(c, q[0]); d = Math.max(d, q[1]); }); return [a - m, b - m, c + m, d + m]; };
  // texture pass for a layer: re-fill each solid's main hull with a pattern / sheen (no z-fighting: same path, drawn right after)
  const HULL = /<path d="([^"]+)" fill="url\(#h[SR][^"]*\)"[^>]*\/>/g;
  const tex = (s, pats) => { const hs = []; s.replace(HULL, (m, d) => { hs.push(d); return m; }); if (!hs.length) return s; let o = s; pats.forEach(([id, op]) => { o += '<g opacity="' + op + '">' + hs.map(d => '<path d="' + d + '" fill="url(#' + id + ')"/>').join('') + '</g>'; }); return o; };
  const PATS = '<pattern id="p3bou" width="3.4" height="3.4" patternUnits="userSpaceOnUse"><circle cx="0.9" cy="0.9" r="0.62" fill="none" stroke="#ffffff" stroke-opacity="0.55" stroke-width="0.36"/><circle cx="2.5" cy="2.4" r="0.7" fill="none" stroke="#000000" stroke-opacity="0.16" stroke-width="0.36"/><circle cx="2.6" cy="0.8" r="0.42" fill="#ffffff" fill-opacity="0.3"/><circle cx="0.9" cy="2.6" r="0.46" fill="#000000" fill-opacity="0.09"/></pattern>'
    + '<pattern id="p3she" width="4.2" height="3.6" patternUnits="userSpaceOnUse"><path d="M0.3 1.7q0.7-1.3 1.4 0t1.4 0" fill="none" stroke="#ffffff" stroke-opacity="0.65" stroke-width="0.5" stroke-linecap="round"/><path d="M1.6 3.3q0.7-1.2 1.4 0t1.4 0" fill="none" stroke="#6a5a40" stroke-opacity="0.25" stroke-width="0.5" stroke-linecap="round"/></pattern>'
    + '<pattern id="p3lea" width="10" height="8" patternUnits="userSpaceOnUse"><path d="M0.6 2.4q2-0.7 3.8 0.3M5.2 5.8q1.9 0.5 3.6-0.4M2 6.6q0.8-0.4 1.6 0" fill="none" stroke="#000000" stroke-opacity="0.16" stroke-width="0.32"/><circle cx="7.6" cy="1.6" r="0.3" fill="#000000" fill-opacity="0.12"/><circle cx="3.2" cy="4.4" r="0.25" fill="#ffffff" fill-opacity="0.14"/></pattern>'
    + '<linearGradient id="p3vel" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="0.32" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.72" stop-color="#000000" stop-opacity="0.16"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.12"/></linearGradient>'
    + '<radialGradient id="p3puff" cx="45%" cy="40%" r="62%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.26"/><stop offset="0.55" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.3"/></radialGradient>'
    + '<linearGradient id="p3chan" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000000" stop-opacity="0.24"/><stop offset="0.42" stop-color="#ffffff" stop-opacity="0.22"/><stop offset="1" stop-color="#000000" stop-opacity="0.24"/></linearGradient>'
    + '<radialGradient id="p3nail" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="#fff4c8"/><stop offset="0.5" stop-color="#d4a548"/><stop offset="1" stop-color="#7a5a1e"/></radialGradient>'
    + '<linearGradient id="p3glass" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.45" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.55"/><stop offset="0.58" stop-color="#ffffff" stop-opacity="0.08"/><stop offset="0.66" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
    + '<radialGradient id="p3gold" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#fff6c8"/><stop offset="0.45" stop-color="#f0c24a"/><stop offset="1" stop-color="#9a6a14"/></radialGradient>';
  let CID = 0;
  const clipR = (w, h, r) => { const id = 'p3c' + (++CID); return { id, d: '<clipPath id="' + id + '"><rect x="0" y="0" width="' + f1(w) + '" height="' + f1(h) + '" rx="' + (r || 1.5) + '"/></clipPath>' }; };
  // deep diamond button tufting in a local plane (u right, v down), puffs + creases + buttons + seat pleats
  function tuft(w, h, col, btn, o) { o = o || {}; const cell = o.cell || 15, C = Math.max(2, Math.round(w / cell)), R = Math.max(1, Math.round(h / (cell * 0.8))), du = w / (2 * C), dv = h / (2 * R + 1), v0 = dv * 0.95, cl = clipR(w, h), cr = shade(col, 0.45);
    let puff = '', crs = '', bt = '', pl = ''; const odd = (i, j) => ((i + j) % 2 + 2) % 2 === 1;
    for (let j = -1; j <= 2 * R + 1; j++) for (let i = -1; i <= 2 * C + 1; i++) { const x = i * du, y = v0 + j * dv;
      if (odd(i, j)) puff += '<path d="M' + f1(x - du) + ' ' + f1(y) + 'L' + f1(x) + ' ' + f1(y - dv) + 'L' + f1(x + du) + ' ' + f1(y) + 'L' + f1(x) + ' ' + f1(y + dv) + 'Z" fill="url(#p3puff)"/>';
      else { crs += 'M' + f1(x) + ' ' + f1(y) + 'L' + f1(x + du) + ' ' + f1(y + dv) + 'M' + f1(x) + ' ' + f1(y) + 'L' + f1(x + du) + ' ' + f1(y - dv);
        if (x > 0.5 && x < w - 0.5 && y > 0.5 && y < h - 0.5) { bt += '<circle cx="' + f1(x) + '" cy="' + f1(y + 0.25) + '" r="2.2" fill="#000000" opacity="0.32"/><circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="1.35" fill="' + btn + '" stroke="' + shade(btn, 0.55) + '" stroke-width="0.3"/><circle cx="' + f1(x - 0.4) + '" cy="' + f1(y - 0.45) + '" r="0.45" fill="#ffffff" opacity="0.7"/>';
          if (o.pleat && y + dv > h - 0.5) pl += 'M' + f1(x) + ' ' + f1(y) + 'L' + f1(x - du * 0.35) + ' ' + f1(h) + 'M' + f1(x) + ' ' + f1(y) + 'L' + f1(x + du * 0.35) + ' ' + f1(h); } } }
    return '<defs>' + cl.d + '</defs><g clip-path="url(#' + cl.id + ')">' + puff + '<path d="' + crs + '" transform="translate(0 0.6)" fill="none" stroke="#ffffff" stroke-opacity="0.14" stroke-width="0.5"/><path d="' + crs + pl + '" fill="none" stroke="' + cr + '" stroke-opacity="0.9" stroke-width="0.65" stroke-linecap="round"/>' + bt + '</g>'; }
  function chan(w, h, col, cw) { const n = Math.max(3, Math.round(w / (cw || 9))), c = w / n, cl = clipR(w, h); let s = '', sm = '';
    rep(n, i => { s += '<rect x="' + f1(i * c) + '" y="0" width="' + f1(c) + '" height="' + f1(h) + '" fill="url(#p3chan)"/><ellipse cx="' + f1((i + 0.5) * c) + '" cy="2.6" rx="' + f1(c * 0.36) + '" ry="1.6" fill="#ffffff" opacity="0.2"/>'; if (i) sm += 'M' + f1(i * c) + ' 0V' + f1(h); });
    return '<defs>' + cl.d + '</defs><g clip-path="url(#' + cl.id + ')">' + s + '<path d="' + sm + '" fill="none" stroke="' + shade(col, 0.5) + '" stroke-width="0.75"/><path d="' + sm + '" transform="translate(0.7 0)" fill="none" stroke="#ffffff" stroke-opacity="0.16" stroke-width="0.4"/></g>'; }
  const pleats = (rx, ry, col, btn) => { let d = ''; rep(11, i => { const a = PI * (0.92 + i * 0.116); d += 'M0 ' + f1(ry * 0.3) + 'L' + f1(Math.cos(a) * rx * 0.94) + ' ' + f1(Math.sin(a) * ry * 0.94); });
    return '<ellipse cx="0" cy="0" rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="url(#p3puff)" opacity="0.8"/><path d="' + d + '" fill="none" stroke="' + shade(col, 0.48) + '" stroke-width="0.55" stroke-linecap="round"/><circle cx="0" cy="' + f1(ry * 0.3) + '" r="1.5" fill="' + btn + '" stroke="' + shade(btn, 0.55) + '" stroke-width="0.3"/>'; };
  const nailRow = (pts, sp) => { let s = ''; for (let i = 0; i < pts.length - 1; i++) { const a = pts[i], b = pts[i + 1], L = Math.hypot(b[0] - a[0], b[1] - a[1]), m = Math.max(1, Math.round(L / sp)); for (let k = 0; k < m; k++) { const t = k / m; s += '<circle cx="' + f1(a[0] + (b[0] - a[0]) * t) + '" cy="' + f1(a[1] + (b[1] - a[1]) * t) + '" r="0.78" fill="url(#p3nail)" stroke="#5a3e12" stroke-width="0.2"/>'; } } return s; };
  const seatC = (x, y, z, w, h, d, col, o) => solid(Object.assign({ ax: 'y', sh: 'rr', c: [x, z], a: w / 2, b: d / 2, r: Math.min(w, d) * 0.15, rings: [[y, 1.4, 0.97], [y + 1.4, 0, 1], [y + h - 3, 0, 1], [y + h - 1, 1.4, 0.99], [y + h, 4.2, 0.95], [y + h + 1.6, 10, 0.85]], col, soft: 1, mat: 'fab' }, o || {}));
  const throwP = (x, y, z, s, col, o) => solid(Object.assign({ ax: 'z', sh: 'rr', c: [x, y + s / 2], a: s / 2, b: s / 2, r: s * 0.3, rings: [[z - 4.5, 4, 0.82], [z - 2.6, 1, 0.97], [z, 0, 1], [z + 2.6, 1, 0.97], [z + 4.5, 4, 0.82]], col, soft: 1, mat: 'fab' }, o || {}));
  const veinsSVG = (R, w, h, n, col) => { let s = ''; rep(n, () => { let x = R() * w, y = R() * h, d = 'M' + f1(x) + ' ' + f1(y); rep(4, () => { const nx = x + 6 + R() * 14, ny = y + (R() - 0.4) * 6; d += 'Q' + f1((x + nx) / 2 + (R() - 0.5) * 4) + ' ' + f1((y + ny) / 2 + (R() - 0.5) * 4) + ' ' + f1(nx) + ' ' + f1(ny); x = nx; y = ny; }); s += '<path d="' + d + '" fill="none" stroke="' + (col || '#b9ae98') + '" stroke-width="' + f1(0.25 + R() * 0.35) + '" opacity="0.6"/>'; }); return s; };

  // ---------- Chesterfields (rolled arms level with the back, deep diamond tufting, pleated scrolls) ----------
  N.chester = S => { const n = S.n || 3, ch = S.st === 'channel', gold = !!S.gold, lea = !!S.leather, bou = !!S.boucle, mar = S.plinth;
    const SW = 58, AW = ch ? 21 : 24, Wd = n * SW + AW * 2, Dp = 94, B0 = mar ? 13 : 9, RT = B0 + 13, ST = RT + 9, CT = ST + 13, TOP = RT + (ch ? 50 : 46);
    const BZ0 = -Dp / 2, BZ1 = BZ0 + 18, ZF = Dp / 2, xs = rep(n, i => -Wd / 2 + AW + SW * (i + 0.5)), xl = -Wd / 2 + AW, xr = Wd / 2 - AW;
    const legc = gold ? GOLD : S.wood || '#4a2c1a', F = P => (P.c && P.c.a) || P.a, BT = P => gold ? '#f0c24a' : shade(F(P), lea ? 0.62 : 0.72);
    const pats = lea ? [['p3lea', 0.8], ['p3vel', 0.6]] : bou ? [['p3bou', 0.55], ['p3vel', 0.3]] : [['p3vel', 0.55]];
    const rollY = TOP - (ch ? 5 : 6), rA = ch ? AW / 2 : AW / 2 + 3.2, rB = ch ? 6 : 7.6, rX = sg => sg * (Wd / 2 - AW / 2 + (ch ? 0 : 3)), z0 = BZ0 + 3;
    const arm = (P, sg) => { const f = F(P), x = sg * (Wd / 2 - AW / 2); return [box(x, RT, (z0 + ZF) / 2, AW, rollY - RT, ZF - z0, f, fb({ r: 5 })), solid(fb({ ax: 'z', sh: 'el', c: [rX(sg), rollY], a: rA, b: rB, n: 18, rings: [[z0, 0, 0.9], [z0 + 2.5, 0, 1], [ZF - 0.5, 0, 1], [ZF + 2, 0, 0.9]], col: f }))]; };
    const D = { w: Wd + (ch ? 4 : 10), d: Dp + 6, act: 'sit', seats: xs.map(x => ({ x, z: (BZ1 + ZF) / 2, h: CT + 1 })) };
    const pal = () => X.pal(D, 0);
    D.layers = [
      { back: 1, build: P => { const f = F(P); return [box(0, RT, (BZ0 + BZ1) / 2, Wd - 2, TOP - RT - 4, BZ1 - BZ0, f, fb({ r: 4 })), solid(fb({ ax: 'x', sh: 'el', c: [(BZ0 + BZ1) / 2, TOP - 4], a: (BZ1 - BZ0) / 2 + 0.6, b: 5, n: 16, rings: [[-Wd / 2 + 1, 0, 0.82], [-Wd / 2 + 3, 0, 1], [Wd / 2 - 3, 0, 1], [Wd / 2 - 1, 0, 0.82]], col: f }))]; },
        wrap: (p, s) => { const P = pal(), f = F(P), w = xr - xl, h = TOP - 9.5 - (ST + 1); return tex(s, pats) + '<g transform="' + plane(p, BZ1 + 0.1, TOP - 9.5, xl) + '">' + (ch ? chan(w, h, f) : tuft(w, h, f, BT(P), { pleat: 1 })) + '</g>'; } },
      { back: 1, build: P => arm(P, -1), wrap: (p, s) => { const P = pal(), f = F(P); let o = tex(s, pats);
          if (!ch) { const h = rollY - rB - 0.6 - (ST + 1); o += '<g transform="' + planeX(p, xl + 0.1, rollY - rB - 0.6, BZ1 + 1) + '">' + tuft(ZF - BZ1 - 3, h, f, BT(P), { cell: 13 }) + '</g><g transform="' + plane(p, ZF + 2.1, rollY, rX(-1)) + '">' + pleats(rA * 0.88, rB * 0.88, f, BT(P)) + '</g>'; }
          if (lea) o += '<g transform="' + plane(p, ZF + 0.25, 0, -Wd / 2 + AW / 2) + '">' + nailRow([[-AW / 2 + 1.6, -(RT + 1.5)], [-AW / 2 + 1.6, -(rollY - rB)], [AW / 2 - 1.6, -(rollY - rB)], [AW / 2 - 1.6, -(RT + 1.5)]], 2.3) + '</g>';
          return o; } },
      { build: P => { const f = F(P), fl = mix(f, '#ffffff', lea ? 0.05 : 0.09), o = []; xs.forEach(x => o.push(seatC(x, ST, (BZ1 + ZF) / 2 + 1, SW - 2, CT - ST, ZF - BZ1 - 1, fl)));
          const pc = S.pil || (lea ? '#e9dcc0' : gold ? '#e9c66a' : bou ? '#c9a35a' : '#d8b25a'); [-1, 1].forEach(sg => o.push(throwP(sg * (Wd / 2 - AW - 16), CT - 1.5, BZ1 + 5.2, 24, sg < 0 ? pc : shade(pc, 0.9))));
          if (n >= 4) o.push(solid(fb({ ax: 'z', sh: 'rr', c: [0, CT + 7], a: 17, b: 7.5, r: 6, rings: [[BZ1 + 0.6, 3, 0.82], [BZ1 + 2.6, 0.6, 0.97], [BZ1 + 5, 0, 1], [BZ1 + 7.4, 0.6, 0.97], [BZ1 + 9.4, 3, 0.82]], col: gold ? '#1f4f3e' : shade(pc, 1.08) })));
          return o; }, wrap: (p, s) => tex(s, pats) },
      { build: P => arm(P, 1), wrap: (p, s) => { const P = pal(), f = F(P); let o = tex(s, pats);
          if (!ch) { const h = rollY - rB - 0.6 - (RT + 1.5); o += '<g transform="' + planeX(p, Wd / 2 + 0.1, rollY - rB - 0.6, z0 + 1.5) + '">' + tuft(ZF - z0 - 3, h, f, BT(P), { cell: 13 }) + '</g><g transform="' + plane(p, ZF + 2.1, rollY, rX(1)) + '">' + pleats(rA * 0.88, rB * 0.88, f, BT(P)) + '</g>'; }
          if (lea) o += '<g transform="' + plane(p, ZF + 0.25, 0, Wd / 2 - AW / 2) + '">' + nailRow([[-AW / 2 + 1.6, -(RT + 1.5)], [-AW / 2 + 1.6, -(rollY - rB)], [AW / 2 - 1.6, -(rollY - rB)], [AW / 2 - 1.6, -(RT + 1.5)]], 2.3) + '</g>';
          return o; } }];
    D.build = P => { const f = F(P), o = [];
      if (mar) o.push(box(0, 0, 0, Wd + 8, B0 - 3.2, Dp + 6, mar, cer({ r: 2 })), box(0, B0 - 3.2, 0, Wd + 1, 3, Dp - 1, GOLD, mt({ r: 1.5 })));
      else { const lx = Wd / 2 - 8, lz = Dp / 2 - 9, L = [[-lx, -lz], [lx, -lz], [-lx, lz], [lx, lz]]; if (n >= 4) L.push([0, lz], [0, -lz]);
        L.forEach(([x, z]) => o.push(ball(x, 0.6, z, 4.2, legc, Object.assign({ sy: 0.92, k: 6, n: 14 }, gold ? mt({ shine: 1 }) : wd())), cyl(x, 0, z, 2.2, 0.8, '#1d140c', { n: 10 }), cyl(x, 7.8, z, 3.4, B0 - 7.8, legc, gold ? mt({ n: 12 }) : wd({ n: 12 })))); }
      o.push(box(0, B0, 0, Wd, RT - B0, Dp, gold ? GOLD : f, gold ? mt({ r: 3 }) : fb({ r: 4 })), slabX(0, RT - 1.6, ZF + 0.35, Wd - 4, 1.6, 1.4, shade(f, 0.78), fb({ r: 0.7 })));
      o.push(box(0, RT, (BZ1 + ZF) / 2, xr - xl, ST - RT, ZF - BZ1, shade(f, 0.86), fb({ r: 3 })), slabX(0, ST - 1.2, ZF + 0.3, xr - xl - 2, 1.2, 1.2, shade(f, 0.74), fb({ r: 0.6 })));
      return o; };
    D.fx = c => { const p = c.p, R = rng(S.nm || 'ch'); let fr = '';
      if (gold) { const h = RT - B0 - 2.4, w = Wd; let s = ''; for (let u = 2; u < w - 1; u += 2.3) s += '<circle cx="' + f1(u) + '" cy="1.1" r="0.55" fill="#fff1b0"/><circle cx="' + f1(u) + '" cy="' + f1(h - 0.8) + '" r="0.55" fill="#fff1b0"/>';
        for (let u = 6; u < w - 6; u += 12) { if (Math.abs(u - w / 2) < 14) continue; s += '<path d="M' + f1(u) + ' ' + f1(h * 0.55) + 'c2 -3.2 5 -3.2 6 0s-2 3 -3 1.2" fill="none" stroke="#9a6a14" stroke-width="0.55"/>'; }
        s += '<path d="M' + f1(w / 2 - 11) + ' ' + f1(h / 2) + 'C' + f1(w / 2 - 6) + ' -0.5 ' + f1(w / 2 - 2) + ' -0.5 ' + f1(w / 2) + ' ' + f1(h / 2) + 'C' + f1(w / 2 + 2) + ' -0.5 ' + f1(w / 2 + 6) + ' -0.5 ' + f1(w / 2 + 11) + ' ' + f1(h / 2) + 'C' + f1(w / 2 + 6) + ' ' + f1(h + 0.5) + ' ' + f1(w / 2 + 2) + ' ' + f1(h + 0.5) + ' ' + f1(w / 2) + ' ' + f1(h / 2) + 'C' + f1(w / 2 - 2) + ' ' + f1(h + 0.5) + ' ' + f1(w / 2 - 6) + ' ' + f1(h + 0.5) + ' ' + f1(w / 2 - 11) + ' ' + f1(h / 2) + 'Z" fill="url(#p3gold)" stroke="#9a6a14" stroke-width="0.5"/>';
        fr += '<g transform="' + plane(p, ZF + 0.12, RT - 1.8, -Wd / 2) + '">' + s + '</g>'; }
      if (lea) fr += '<g transform="' + plane(p, ZF + 1.2, 0, 0) + '">' + nailRow([[-Wd / 2 + 2, -(RT - 3.4)], [Wd / 2 - 2, -(RT - 3.4)]], 2.4) + '</g>';
      if (mar) fr += '<g transform="' + plane(p, Dp / 2 + 3.06, B0 - 3.4, -Wd / 2 - 4) + '">' + veinsSVG(R, Wd + 8, B0 - 3.4, 9) + '<rect x="0" y="0" width="' + f1(Wd + 8) + '" height="' + f1(B0 - 3.4) + '" fill="url(#p3glass)" opacity="0.5"/></g>';
      return { defs: PATS, front: fr }; };
    return D; };

  // ---------- Curved bouclé cloud modular pit sofa: n wedge modules tiling a real circular arc (open side faces the room) ----------
  // one sorted build, stacked in y (curved parts never separate by their boxes): oak plinth 0-5, seat wedge 5-26 over the whole module,
  // back = 2 puffy wedges per module sitting ON the seat's outer rim (26-55); end pillows glued to the end backs (hide when the back turns away)
  N.cloudPit = S => { const n = S.n || 5, a0 = PI * 0.95, a1 = PI * 2.05, da = (a1 - a0) / n, RF = 54, RO = 126, RB = 104, zc = (RO - Math.sin(PI - a0) * RO) / 2, F = P => (P.c && P.c.a) || P.a;
    const Pp = (r, t) => [Math.cos(t) * r, zc + Math.sin(t) * r];
    const wedge = (r0, r1, t0, t1, rc, m) => { const tm = (t0 + t1) / 2, C = Pp((r0 + r1) / 2, tm), o = [], d1 = rc / r1, d0 = rc / r0;
      const bz = (a, k, b) => [0.25, 0.5, 0.75].forEach(s => o.push([(1 - s) * (1 - s) * a[0] + 2 * (1 - s) * s * k[0] + s * s * b[0], (1 - s) * (1 - s) * a[1] + 2 * (1 - s) * s * k[1] + s * s * b[1]]));
      const arc = (r, ta, tb) => { for (let i = 0; i <= m; i++) o.push(Pp(r, ta + (tb - ta) * i / m)); };
      o.push(Pp(r1 - rc, t0)); bz(Pp(r1 - rc, t0), Pp(r1, t0), Pp(r1, t0 + d1)); arc(r1, t0 + d1, t1 - d1); bz(Pp(r1, t1 - d1), Pp(r1, t1), Pp(r1 - rc, t1));
      o.push(Pp(r0 + rc, t1)); bz(Pp(r0 + rc, t1), Pp(r0, t1), Pp(r0, t1 - d0)); arc(r0, t1 - d0, t0 + d0); bz(Pp(r0, t0 + d0), Pp(r0, t0), Pp(r0 + rc, t0));
      return { c: C, pts: o.map(p => [p[0] - C[0], p[1] - C[1]]) }; };
    const wsol = (W, rings, col, o) => solid(Object.assign({ ax: 'y', sh: 'poly', c: W.c, pts: W.pts, rings, col }, o));
    const puffR = (y0, y1, top) => [[y0, 0, 0.95], [y0 + 3, 0, 1], [y1 - (top ? 7 : 5), 0, 1], [y1 - (top ? 3 : 2), 0, top ? 0.94 : 0.97], [y1, 0, top ? 0.8 : 0.88]];
    const mods = rep(n, i => ({ t0: a0 + da * i, t1: a0 + da * (i + 1), t: a0 + da * (i + 0.5) }));
    const D = { w: RO * 2 + 4, d: RO + Math.sin(PI - a0) * RO + 4, act: 'sit', seats: mods.map(m => { const q = Pp(80, m.t); return { x: q[0], z: q[1], h: 26, f: Math.atan2(-Math.cos(m.t), -Math.sin(m.t)) * 180 / PI }; }) };
    D.build = P => { const f = F(P), sc = mix(f, '#ffffff', 0.06), bc = shade(f, 0.97), o = [], backs = [];
      mods.forEach(m => { o.push(wsol(wedge(60, 120, m.t0 + 0.012, m.t1 - 0.012, 4, 5), [[0, 0, 0.97], [4.2, 0, 1], [5, 0, 0.98]], '#3a332c', wd()));
        o.push(wsol(wedge(RF, RO, m.t0, m.t1, 9, 6), puffR(5, 26), sc, fb()));
        [0, 1].forEach(h => { const b = wsol(wedge(RB, RO, m.t0 + da * h / 2, m.t0 + da * (h + 1) / 2, 6, 4), puffR(26.1, 55, 1), bc, fb()); backs.push(b); o.push(b); }); });
      [[a0 + da * 0.28, backs[0], '#b9a48a'], [a1 - da * 0.28, backs[backs.length - 1], '#c9a35a']].forEach(([t, par, col]) => { const q = Pp(97, t), b = ball(q[0], 26.2, q[1], 10, col, { sx: 1.1, sy: 0.92, sz: 0.62, soft: 1, mat: 'fab', yaw: t + PI / 2 });
        b.par = par; b.fn = [-Math.cos(t), 0, -Math.sin(t)]; o.push(b); });
      return o; };
    D.fx = () => ({ defs: PATS });
    return D; };

  // ---------- Zero-G D-Box VIP pods: reclined leather recliners on motion actuators, consoles between ----------
  N.vipPods = S => { const n = S.n || 3, PW = 62, CW = 13, Wd = n * PW + (n + 1) * CW, xs = rep(n, i => -Wd / 2 + CW + PW / 2 + i * (PW + CW)), cxs = rep(n + 1, i => -Wd / 2 + CW / 2 + i * (PW + CW));
    const SHL = '#e9ebee', GUN = '#2a2d34', CY = '#4fe0ff', F = P => (P.c && P.c.a) || '#2a2a30';
    const u = [-0.433, 0.9], nv = [0.9, 0.433], S0 = [-26, 34], S1 = [-52, 88], add = (a, b, k) => [a[0] + b[0] * k, a[1] + b[1] * k];
    const D = { w: Wd + 8, d: 132, act: 'sit', seats: xs.map(x => ({ x, z: 2, h: 44 })) };
    D.build = P => { const o = [box(0, 0, 4, Wd + 6, 4, 122, '#1c1d22', mt({ r: 3 })), box(0, 1.4, 65.2, Wd + 2, 1.2, 0.8, CY, em({ r: 0.3 }))];
      xs.forEach(x => { o.push(cyl(x, 4, -4, 22, 5, GUN, mt({ rz: 17, n: 24 })), cyl(x, 9, -4, 19, 0.8, CY, em({ rz: 14.6, n: 24 })));
        [[-12, -14], [12, -14], [0, 8]].forEach(([dx, dz]) => o.push(cyl(x + dx, 9.8, -4 + dz, 2.5, 11, CH, mt({ n: 10, shine: 1 })), cyl(x + dx, 12.6, -4 + dz, 3.3, 2.4, '#16171b', { n: 10 }))); });
      return o; };
    const pod = (x, i) => ({ build: P => { const L = F(P), LL = mix(L, '#ffffff', 0.08), o = [], hw = PW / 2;
        o.push(box(x, 20, -2, PW - 8, 13, 54, SHL, cer({ r: 9 })), box(x, 21, 25, PW - 12, 1, 1, CY, em({ r: 0.3 })));
        o.push(prism(x - hw + 7, x + hw - 7, [[-25, 33], [25, 36], [25, 44.5], [-25, 41.5]], LL, { soft: 1, mat: 'paint' }));
        o.push(prism(x - hw + 3, x + hw - 3, [add(S0, nv, -5), add(S1, nv, -5), S1, S0], SHL, cer()), prism(x - hw + 8, x + hw - 8, [S0, S1, add(S1, nv, 8), add(S0, nv, 8)], L, { soft: 1, mat: 'paint' }));
        [-1, 1].forEach(sg => o.push(prism(x + sg * (hw - 8) - (sg > 0 ? 0 : 3.4), x + sg * (hw - 8) + (sg > 0 ? 3.4 : 0), [add(S0, nv, 0.4), add(S1, nv, 0.4), add(S1, nv, 11), add(S0, nv, 11)], shade(L, 0.9), { soft: 1, mat: 'paint' })));
        const H = add(add(S1, nv, 11), u, -9); o.push(ball(x, H[1] - 5.5, H[0], 13, LL, { sx: 1.25, sy: 0.5, sz: 0.55, soft: 1, mat: 'paint', k: 6, n: 16 }));
        o.push(prism(x - hw + 7, x + hw - 7, [[22, 30], [60, 37], [61, 40], [22, 34]], SHL, cer()), prism(x - hw + 8, x + hw - 8, [[24, 34.5], [61, 40.5], [61, 48], [24, 43.5]], LL, { soft: 1, mat: 'paint' }), box(x, 38, 63.4, PW - 18, 2.4, 2.4, CH, mt({ r: 1 })));
        [-1, 1].forEach(sg => { const ax = x + sg * (hw - 3.5); o.push(box(ax, 30, -6, 7, 19, 54, SHL, cer({ r: 3 })), box(ax, 49, -6, 8, 3, 52, L, { r: 1.5, soft: 1, mat: 'paint' }), slab(ax, 38, 21.4, 5, 6, 0.6, '#0e1a24', { r: 1 }), slab(ax, 39, 21.9, 3.6, 4, 0.3, CY, em({ r: 0.6 }))); });
        return o; },
      wrap: (p, s) => { const L = F(X.pal(D, 0)), q = p(x, 20, -2), w = PW - 16, O = add(add(S1, nv, 8.1), u, -0.5), cl = clipR(w, 46, 3); let ch = '';
          rep(7, j => { const v = 5 + j * 6; ch += '<path d="M0 ' + v + 'H' + w + '" stroke="' + shade(L, 0.5) + '" stroke-width="0.7"/><path d="M0 ' + (v + 0.7) + 'H' + w + '" stroke="#ffffff" stroke-opacity="0.16" stroke-width="0.45"/><path d="M1 ' + (v - 1.6) + 'H' + (w - 1) + '" stroke="' + shade(L, 1.6) + '" stroke-opacity="0.35" stroke-width="0.25" stroke-dasharray="1 0.8"/>'; });
          const pm = mtx(p(x - w / 2, O[1], O[0]), p(x - w / 2 + 1, O[1], O[0]), p(x - w / 2, O[1] - u[1], O[0] - u[0]));
          return '<g>' + atS('rotate', '0 ' + P2(q) + ';-1.3 ' + P2(q) + ';0.9 ' + P2(q) + ';-0.5 ' + P2(q) + ';0 ' + P2(q), 4.6, -i * 1.3) + tex(s, [['p3lea', 0.85], ['p3vel', 0.8]]) + '<g transform="' + pm + '"><defs>' + cl.d + '</defs><g clip-path="url(#' + cl.id + ')">' + ch + '</g></g></g>'; } });
    const con = cx => ({ build: P => { const L = F(P); return [box(cx, 4, -6, CW - 1.5, 46, 70, GUN, mt({ r: 3 })), box(cx, 50, -6, CW, 3, 72, L, { r: 2, soft: 1, mat: 'paint' }), arcW(cx, 53, 16, 4.2, 4.2, 1, 0.8, 0, 2 * PI, CH, mt({ n: 16 })),
        cyl(cx, 53, 16, 3.3, 11, '#d9363b', pt({ n: 14, rg: [[0, 0, 0.8], [11, 0, 1]] })), cyl(cx, 64, 16, 3.5, 1, '#ffffff', { n: 14 }), cyl(cx + 1, 65, 16, 0.45, 6, '#ffffff', { n: 4 }),
        slab(cx, 38, 29.4, CW - 4, 8, 0.6, '#0e1a24', { r: 1 }), slab(cx, 39.2, 29.9, CW - 6, 5.6, 0.3, CY, em({ r: 1 })), box(cx, 5, 29.2, CW - 3, 1, 0.6, CY, em({ r: 0.3 }))]; } });
    D.layers = []; cxs.forEach((cx, i) => { D.layers.push(con(cx)); if (i < n) D.layers.push(pod(xs[i], i)); });
    D.fx = c => { const p = c.p; let un = ''; xs.forEach((x, i) => un += '<g transform="' + planeH(p, 4.2, x, -4) + '"><ellipse rx="34" ry="30" fill="#4fe0ff" opacity="0.12">' + anS('opacity', '0.06;0.22;0.06', 2.3, -i * 0.7) + '</ellipse></g>');
      const tick = xs.map((x, i) => { const q = p(x - 9, 40.2, 22); return '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="0.6" fill="#ffffff">' + an('opacity', '1;0.2;1', 1.2, -i * 0.4) + '</circle>'; }).join('');
      return { defs: PATS, under: un, front: tick }; };
    return D; };

  // ---------- Quantum hologram emitter: lens stack + satellite emitters on a 4DX motion platform ----------
  N.qHolo = S => { const G = '#2b2e36', CY = '#7ff0ff', NODES = [[-22, -16], [22, -16], [-22, 16], [22, 16]], SAT = rep(3, i => { const a = PI / 2 + i * 2 * PI / 3; return [Math.cos(a) * 19, Math.sin(a) * 19]; });
    const D = { w: 86, d: 80, glow: () => ({ y: 80, r: 62, c: 'url(#gNeon)' }) };
    D.build = P => { const o = [cyl(0, 0, 0, 37, 3, '#1c1d22', mt({ n: 6 })), arcW(0, 3, 0, 37, 37, 1.4, 0.8, 0, 2 * PI, CY, em({ n: 6 }))];
      NODES.forEach(([x, z]) => o.push(cyl(x, 3, z, 6, 7, G, mt({ n: 14 })), cyl(x, 10, z, 6.3, 0.9, CY, em({ n: 14 })), cyl(x, 10.9, z, 2.6, 6, CH, mt({ n: 10, shine: 1 }))));
      return o; };
    D.layers = [{ build: P => { const o = [cyl(0, 16, 0, 32, 5.6, G, mt({ n: 6 })), cyl(0, 21.6, 0, 32.8, 1, CH, mt({ n: 6 })), cyl(0, 22.6, 0, 24, 2.4, '#1a1c22', mt({ n: 24 })), arcW(0, 25, 0, 24, 24, 1.2, 0.8, 0, 2 * PI, CY, em({ n: 24 })),
          cyl(0, 25, 0, 10, 9, '#23252c', mt({ n: 20, rg: [[0, 0, 1.1], [9, 0, 0.9]] }))];
        [34, 37, 40].forEach((y, i) => o.push(cyl(0, y, 0, 8.6 - i * 1.2, 2, '#bfefff', cer({ n: 20, op: 0.55 })), cyl(0, y + 2, 0, 6.4 - i, 1, CH, mt({ n: 16 }))));
        o.push(ball(0, 43, 0, 5.4, '#dffaff', cer({ sy: 0.6, op: 0.7, n: 16 })), ball(0, 43.8, 0, 2.6, CY, em({ k: 4 })));
        SAT.forEach(([x, z]) => o.push(cyl(x, 25, z, 3.6, 8, G, mt({ n: 12 })), cyl(x, 33, z, 3.9, 1.2, CH, mt({ n: 12 })), ball(x, 34.2, z, 2.3, CY, em({ k: 3 }))));
        return o; },
      wrap: (p, s) => { const k = kOf(p), q = p(0, 16, 0), a = p(0, 47, 0), b = p(0, 112, 0), pl = p(0, 82, 0), w0 = 5 * k, w1 = 34 * k, R = 14 * k; let h = '';
        h += '<path d="M' + f1(a[0] - w0) + ' ' + f1(a[1]) + 'L' + f1(b[0] - w1) + ' ' + f1(b[1]) + 'L' + f1(b[0] + w1) + ' ' + f1(b[1]) + 'L' + f1(a[0] + w0) + ' ' + f1(a[1]) + 'Z" fill="url(#qcone)">' + an('opacity', '0.75;1;0.8;0.95;0.75', 2.2) + '</path>';
        SAT.forEach(([x, z], i) => { const e = p(x, 36.5, z); h += '<path d="M' + P2(e) + 'L' + P2(pl) + '" stroke="#bff8ff" stroke-width="' + f1(0.9 * k) + '" stroke-dasharray="' + f1(3 * k) + ' ' + f1(2 * k) + '" opacity="0.7">' + an('stroke-dashoffset', '0;-' + f1(10 * k), 0.6, -i * 0.2) + '</path>'; });
        h += '<g transform="' + planeH(p, 64) + '"><ellipse rx="27" ry="27" fill="none" stroke="#8fe8ff" stroke-width="4.4" stroke-dasharray="5 1.4" opacity="0.32">' + an('stroke-dashoffset', '0;-64', 5) + '</ellipse><ellipse rx="27" ry="27" fill="none" stroke="#ffffff" stroke-width="0.7" stroke-dasharray="1 1.6" opacity="0.6" transform="scale(1.07)">' + an('stroke-dashoffset', '0;-52', 5) + '</ellipse><ellipse rx="27" ry="27" fill="none" stroke="#ffffff" stroke-width="0.7" stroke-dasharray="1 1.6" opacity="0.6" transform="scale(0.93)">' + an('stroke-dashoffset', '0;-52', 5) + '</ellipse></g>';
        h += '<g transform="translate(' + P2(pl) + ')"><g>' + atS('translate', '0 0;0 ' + f1(-3 * k) + ';0 0', 3) + '<circle r="' + f1(R) + '" fill="url(#qpl)" stroke="#d8fbff" stroke-width="' + f1(0.5 * k) + '"/>';
        rep(3, i => h += '<ellipse rx="' + f1(R) + '" ry="' + f1(R) + '" fill="none" stroke="#d8fbff" stroke-width="' + f1(0.35 * k) + '" opacity="0.7">' + an('rx', f1(R) + ';' + f1(R * 0.05) + ';' + f1(R), 4.2, -i * 1.4) + '</ellipse>');
        [-0.5, 0, 0.5].forEach(t => h += '<ellipse cy="' + f1(t * R) + '" rx="' + f1(R * Math.sqrt(1 - t * t)) + '" ry="' + f1(R * 0.22 * Math.sqrt(1 - t * t)) + '" fill="none" stroke="#d8fbff" stroke-width="' + f1(0.3 * k) + '" opacity="0.6"/>');
        h += '<g transform="rotate(-14)"><ellipse rx="' + f1(R * 1.75) + '" ry="' + f1(R * 0.42) + '" fill="none" stroke="#e8fdff" stroke-width="' + f1(1.2 * k) + '" stroke-dasharray="' + f1(4 * k) + ' ' + f1(1.5 * k) + '" opacity="0.8">' + an('stroke-dashoffset', '0;-' + f1(40 * k), 3) + '</ellipse><circle r="' + f1(2 * k) + '" fill="#ffffff"><animateMotion dur="4s" repeatCount="indefinite" path="M' + f1(R * 1.75) + ' 0A' + f1(R * 1.75) + ' ' + f1(R * 0.42) + ' 0 1 1 ' + f1(-R * 1.75) + ' 0A' + f1(R * 1.75) + ' ' + f1(R * 0.42) + ' 0 1 1 ' + f1(R * 1.75) + ' 0"/></circle></g>';
        rep(6, i => h += '<rect x="' + f1(-R) + '" y="' + f1(-R + i * R / 3) + '" width="' + f1(2 * R) + '" height="' + f1(0.4 * k) + '" fill="#ffffff" opacity="0.25">' + an('y', f1(-R) + ';' + f1(R), 2.4, -i * 0.4) + '</rect>');
        h += '</g></g>';
        rep(10, i => { const x = (i % 5 - 2) * 9, z = i % 2 ? 6 : -6, e0 = p(x, 48, z), e1 = p(x * 1.6, 110, z), d = (2.4 + (i % 3) * 0.5).toFixed(1); h += '<circle cx="' + f1(e0[0]) + '" cy="' + f1(e0[1]) + '" r="' + f1(0.7 * k) + '" fill="#e8fdff">' + an('cy', f1(e0[1]) + ';' + f1(e1[1]), d, -i * 0.37) + an('opacity', '0;1;0', d, -i * 0.37) + '</circle>'; });
        return '<g>' + atS('rotate', '0 ' + P2(q) + ';-1.6 ' + P2(q) + ';1.2 ' + P2(q) + ';-0.8 ' + P2(q) + ';0 ' + P2(q), 3.6) + atS('translate', '0 0;0 -1.2;0 0.4;0 -0.8;0 0', 3.6) + s + h + '</g>'; } }];
    D.fx = c => { const p = c.p, k = c.k; let un = '', f = '';
      NODES.forEach(([x, z], i) => { un += '<g transform="' + planeH(p, 3.2, x, z) + '">' + rep(2, j => '<ellipse rx="6" ry="6" fill="none" stroke="#7ff0ff" stroke-width="0.8">' + an('rx', '6;18', 2, -i * 0.5 - j) + an('ry', '6;18', 2, -i * 0.5 - j) + an('opacity', '0.8;0', 2, -i * 0.5 - j) + '</ellipse>').join('') + '</g>';
        rep(2, j => { const e = p(x, 10, z); f += '<circle cx="' + f1(e[0]) + '" cy="' + f1(e[1]) + '" r="' + f1(2.2 * k) + '" fill="#ffffff" opacity="0">' + an('cy', f1(e[1]) + ';' + f1(e[1] - 22 * k), 3, -i * 0.8 - j * 1.5) + an('r', f1(1.6 * k) + ';' + f1(5 * k), 3, -i * 0.8 - j * 1.5) + an('opacity', '0;0.35;0', 3, -i * 0.8 - j * 1.5) + '</circle>'; }); });
      const top = p(0, 116, 0), l = p(-40, 60, 0), r = p(40, 60, 0);
      return { defs: '<linearGradient id="qcone" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#8fe8ff" stop-opacity="0.5"/><stop offset="1" stop-color="#8fe8ff" stop-opacity="0.02"/></linearGradient><radialGradient id="qpl" cx="38%" cy="32%" r="70%"><stop offset="0" stop-color="#e8fdff" stop-opacity="0.85"/><stop offset="0.6" stop-color="#6fd8ff" stop-opacity="0.45"/><stop offset="1" stop-color="#3a8fd8" stop-opacity="0.25"/></radialGradient>', under: un, front: f, bb: bbOf([top, l, r], 6) }; };
    return D; };

  // ---------- Floating holographic film-reel light sculptures (wall): two spinning reels + travelling film strip ----------
  N.reelSculpt = S => { const RL = [[-30, 46, 21, 7], [30, 58, 16, -5.5]];
    const D = { w: 124, d: 14, mount: 'wall', elev: 46, glow: () => ({ y: 52, r: 70, c: 'url(#gNeon)' }) };
    D.build = P => [box(0, 0, -4, 116, 5, 6, '#23252e', mt({ r: 2 })), box(0, 1.4, -0.7, 108, 1.4, 0.6, '#8fe8ff', em({ r: 0.4 })), ...[-44, 44].map(x => cyl(x, 5, -4, 2, 1.2, CH, mt({ n: 10 })))];
    D.fx = c => { const p = c.p; let f = '<g transform="' + plane(p, 2, 0) + '">';
      f += '<path d="M-56 -5L-70 -96H70L56 -5Z" fill="url(#rbeam)">' + an('opacity', '0.5;0.9;0.5', 3) + '</path>';
      RL.forEach(([x, y, r, d], i) => { const cx = x, cy = -y, ho = rep(5, j => { const a = j * 2 * PI / 5; return '<circle cx="' + f1(Math.cos(a) * r * 0.55) + '" cy="' + f1(Math.sin(a) * r * 0.55) + '" r="' + f1(r * 0.22) + '" fill="#06222e" fill-opacity="0.55" stroke="#e8fdff" stroke-width="0.6"/>'; }).join('');
        f += '<g transform="translate(' + cx + ' ' + cy + ')"><g>' + atS('translate', '0 0;0 -3;0 0', 3.4, -i * 1.2) + '<circle r="' + f1(r * 1.25) + '" fill="#8fe8ff" opacity="0.25" filter="url(#rbl)">' + anS('opacity', '0.15;0.45;0.15', 2.4, -i) + '</circle><g>' + at('rotate', d > 0 ? '0;360' : '360;0', Math.abs(d)) +
          '<circle r="' + r + '" fill="url(#rdisc)" stroke="#e8fdff" stroke-width="1.4"/><circle r="' + f1(r - 2.4) + '" fill="none" stroke="#8fe8ff" stroke-width="0.6" stroke-dasharray="1.6 1.2"/>' + ho + '<circle r="' + f1(r * 0.16) + '" fill="#e8fdff"/><circle r="' + f1(r * 0.07) + '" fill="#06222e"/></g>'
          + '<ellipse cx="' + f1(-r * 0.35) + '" cy="' + f1(-r * 0.4) + '" rx="' + f1(r * 0.35) + '" ry="' + f1(r * 0.18) + '" fill="#ffffff" opacity="0.35" transform="rotate(-30)"/></g></g>'; });
      const fs = 'M-30 -25C-6 -16 4 -84 30 -74C48 -66 52 -38 30 -42';
      f += '<path d="' + fs + '" fill="none" stroke="#8fe8ff" stroke-width="5.2" opacity="0.35"/><path d="' + fs + '" fill="none" stroke="#e8fdff" stroke-width="5.2" stroke-dasharray="4.4 1" opacity="0.28">' + an('stroke-dashoffset', '0;-21', 1.4) + '</path><path d="' + fs + '" fill="none" stroke="#06222e" stroke-width="0.9" stroke-dasharray="0.9 1.3" transform="translate(0 1.8)" opacity="0.7">' + an('stroke-dashoffset', '0;-22', 1.4) + '</path><path d="' + fs + '" fill="none" stroke="#06222e" stroke-width="0.9" stroke-dasharray="0.9 1.3" transform="translate(0 -1.8)" opacity="0.7">' + an('stroke-dashoffset', '0;-22', 1.4) + '</path>';
      rep(8, i => f += '<circle cx="' + (-50 + i * 14) + '" cy="-8" r="0.8" fill="#e8fdff">' + an('cy', '-8;-90', 3 + (i % 3) * 0.6, -i * 0.5) + an('opacity', '0;1;0', 3 + (i % 3) * 0.6, -i * 0.5) + '</circle>');
      f += '</g>';
      return { defs: BLUR('rbl', 3) + '<linearGradient id="rbeam" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#8fe8ff" stop-opacity="0.3"/><stop offset="1" stop-color="#8fe8ff" stop-opacity="0"/></linearGradient><radialGradient id="rdisc" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#e8fdff" stop-opacity="0.75"/><stop offset="1" stop-color="#3ab8e8" stop-opacity="0.35"/></radialGradient>', front: f, bb: bbOf([p(-72, 100, 2), p(72, 100, 2), p(-72, 0, 2), p(72, 0, 2)], 4) }; };
    return D; };

  // ---------- Retro neon 'Now Showing' sign: bent single-stroke glass tubes, glow, electrode gaps, flicker ----------
  const NF = { N: 'M0 10V0L6 10V0', O: 'M3 0C6.8 0 6.8 10 3 10C-0.8 10 -0.8 0 3 0Z', W: 'M0 0L1.6 10L3 3.6L4.4 10L6 0', S: 'M5.8 1.7C5 0.4 4 0 3 0C1.1 0 0.1 1.1 0.1 2.6C0.1 5.2 6 4.6 6 7.5C6 9 4.8 10 3 10C1.8 10 0.6 9.4 0 8.2', H: 'M0 0V10M6 0V10M0 5H6', I: 'M1 0V10', G: 'M5.8 1.9C5.1 0.6 4.1 0 3 0C0.8 0 0 2.4 0 5C0 7.6 0.8 10 3 10C5 10 6 8.6 6 6.6V5.8H3.4' };
  const word = (str, x, y, s, gap) => { let o = '', cx = 0; const W = ch => ch === 'I' ? 2 : 6; const tot = str.split('').reduce((a, ch) => a + W(ch) + gap, -gap); cx = -tot / 2;
    str.split('').forEach(ch => { o += '<path d="' + NF[ch] + '" transform="translate(' + f1(cx) + ' 0)"/>'; cx += W(ch) + gap; }); return { g: o, t: 'translate(' + x + ' ' + y + ') scale(' + s + ')' }; };
  const tube = (g, t, col, s, extra) => '<g transform="' + t + '" fill="none" stroke-linecap="round" stroke-linejoin="round">' + (extra || '') + '<g stroke="' + col + '" stroke-width="' + f1(3.6 / s) + '" opacity="0.55" filter="url(#nbl)">' + g + '</g><g stroke="' + col + '" stroke-width="' + f1(1.7 / s) + '">' + g + '</g><g stroke="#ffffff" stroke-width="' + f1(0.6 / s) + '" opacity="0.85">' + g + '</g></g>';
  N.neonShow = S => ({ w: 124, d: 10, mount: 'wall', elev: 50, glow: () => ({ y: 32, r: 76, c: 'url(#npink)' }), build: P => [slab(0, 0, -1.5, 116, 64, 3, '#1c1a2a', pt({ r: 6 })), slab(0, 2, 0.3, 110, 60, 0.6, '#14121e', pt({ r: 5 })), box(0, -6, -2, 22, 6, 4, '#4a4c52', mt({ r: 1 })), ...[[-50, 6], [50, 6], [-50, 58], [50, 58]].map(([x, y]) => disc(x, y, 0.6, 1.4, 1.6, CH, mt({ n: 10 })))],
    fx: c => { const p = c.p; let f = '<g transform="' + plane(p, 1.2, 64) + '">';
      f += tube('<rect x="-52" y="5" width="104" height="54" rx="7" stroke-dasharray="40 1.4 30 1.4 70 1.4 50 1.4"/>', '', '#ffb347', 1, '') ;
      const A = word('NOW', 0, 13, 1.6, 2.4), Bw = word('SHOWING', 0, 37, 1.2, 1.8);
      f += '<g>' + an('opacity', '1;1;0.25;1;0.5;1;1', 4.6, 0, '0;0.62;0.64;0.66;0.69;0.72;1') + tube(A.g, A.t, '#ff4fa3', 1.6) + '</g>';
      f += '<g>' + an('opacity', '0.92;1;0.95;1;0.92', 0.18) + tube(Bw.g, Bw.t, '#4fe8ff', 1.2) + '</g>';
      f += tube('<path d="M-40 31H-24M24 31H40M-36 28L-40 31L-36 34M36 28L40 31L36 34"/>', '', '#ffd66b', 1);
      [[-30, 22], [30, 22], [-44, 47], [44, 47], [-10, 52], [10, 52]].forEach(([x, y]) => f += '<rect x="' + (x - 1.2) + '" y="' + (y - 0.6) + '" width="2.4" height="1.2" rx="0.3" fill="#8a8d94"/>');
      f += '</g>';
      return { defs: BLUR('nbl', 1.3) + '<radialGradient id="npink" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ff6ab8" stop-opacity="0.45"/><stop offset="0.6" stop-color="#4fe8ff" stop-opacity="0.12"/><stop offset="1" stop-color="#4fe8ff" stop-opacity="0"/></radialGradient>', front: f }; } });

  // ---------- Levitating electrostatic sphere audio matrix ----------
  N.sphereAudio = S => { const SP = [[-46, 12, 13, 0.6], [0, -4, 20, 0], [46, 12, 13, 1.3]];
    const D = { w: 140, d: 70 };
    D.build = P => { const o = []; SP.forEach(([x, z, r]) => o.push(cyl(x, 0, z, r + 4, 3, '#121318', cer({ n: 22 })), cyl(x, 3, z, r + 1, 3.4, '#1d1f26', mt({ n: 22, rg: [[0, 0, 1], [3.4, 0, 0.82]] })), arcW(x, 6.4, z, r * 0.75, r * 0.75, 1.1, 0.7, 0, 2 * PI, '#6ac8ff', em({ n: 22 })), cyl(x, 6.4, z, r * 0.4, 0.6, '#2c2f38', mt({ n: 16 })))); return o; };
    const yb = r => 7 + 12 + (r > 15 ? 3 : 0);
    D.layers = SP.map(([x, z, r, ph]) => ({ build: P => { const y = yb(r); return [cyl(x, y - 1.6, z, r * 0.2, 2.2, CH, mt({ n: 12, shine: 1 })), cyl(x, y + 0.4, z, 0.7, r * 0.78, CH, mt({ n: 6 })), ball(x, y + r * 0.78, z, r * 0.22, '#c9a6ff', em({ k: 5 })), ball(x, y, z, r, '#cfeaff', cer({ op: 0.26, n: 22, k: 9, shine: 1 }))]; },
      wrap: (p, s) => { const k = kOf(p), y = yb(r), c0 = p(x, y + r, z), Rs = r * k * 0.93, R = rng('arc' + x); let a = '';
        rep(5, j => { const vs = rep(3, () => { const ph2 = j * 1.26 + R() * 0.5, e = [c0[0] + Math.cos(ph2) * Rs, c0[1] + Math.sin(ph2) * Rs * 0.98]; let d = 'M' + P2(c0); rep(4, m => { const t = (m + 1) / 5, nx = -(e[1] - c0[1]), ny = e[0] - c0[0], L = Math.hypot(nx, ny) || 1, jj = (R() - 0.5) * 0.35 * Rs; d += 'L' + f1(c0[0] + (e[0] - c0[0]) * t + nx / L * jj) + ' ' + f1(c0[1] + (e[1] - c0[1]) * t + ny / L * jj); }); return d + 'L' + P2(e); });
          a += '<path d="' + vs[0] + '" fill="none" stroke="#b48cff" stroke-width="' + f1(2.4 * k) + '" stroke-linecap="round" stroke-linejoin="round" opacity="0.28">' + anD('d', vs.join(';'), 0.36, -j * 0.07) + '</path><path d="' + vs[0] + '" fill="none" stroke="#f4ecff" stroke-width="' + f1(0.45 * k) + '">' + anD('d', vs.join(';'), 0.36, -j * 0.07) + an('opacity', '1;0.4;1;0.7;1', 0.5, -j * 0.1) + '</path>'; });
        a += '<circle cx="' + f1(c0[0]) + '" cy="' + f1(c0[1]) + '" r="' + f1(r * 0.75 * k) + '" fill="url(#sbg)" opacity="0.6">' + an('opacity', '0.2;0.45;0.25;0.4;0.2', 0.9) + '</circle>';
        return '<g>' + atS('translate', '0 0;0 ' + f1(-3.4 * k) + ';0 0', 3.4, -ph) + s + a + '</g>'; } }));
    D.fx = c => { const p = c.p; let f = ''; SP.forEach(([x, z, r], i) => { f += '<g transform="' + planeH(p, 7.4, x, z) + '">' + rep(2, j => '<ellipse rx="' + f1(r * 0.6) + '" ry="' + f1(r * 0.6) + '" fill="none" stroke="#6ac8ff" stroke-width="0.7">' + an('rx', f1(r * 0.5) + ';' + f1(r * 1.3), 1.8, -i * 0.4 - j * 0.9) + an('ry', f1(r * 0.5) + ';' + f1(r * 1.3), 1.8, -i * 0.4 - j * 0.9) + an('opacity', '0.8;0', 1.8, -i * 0.4 - j * 0.9) + '</ellipse>').join('') + '</g>'; });
      return { defs: '<radialGradient id="sbg" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#b48cff" stop-opacity="0.9"/><stop offset="0.45" stop-color="#b48cff" stop-opacity="0.4"/><stop offset="1" stop-color="#b48cff" stop-opacity="0"/></radialGradient>', under: f }; };
    return D; };

  // ---------- Suspended mid-century black steel wood-burning cone ----------
  N.coneHearth = S => { const BK = '#2a2b2e';
    return { w: 110, d: 84, build: P => { const o = [cyl(0, 0, 0, 36, 3, '#3a3c40', cer({ rz: 31, n: 28 })), cyl(0, 3, 0, 33, 0.8, '#55585e', cer({ rz: 28, n: 28 }))];
        o.push(cyl(0, 30, 0, 26, 30, BK, pt({ n: 28, rg: [[0, 0, 0.32], [5, 0, 0.75], [13, 0, 1], [22, 0, 0.94], [30, 0, 0.6]] })), cyl(0, 60, 0, 15.8, 30, BK, pt({ n: 24, rg: [[0, 0, 1], [30, 0, 0.32]] })), cyl(0, 89.6, 0, 5.2, 104, BK, pt({ n: 16 })), cyl(0, 188, 0, 9, 3.4, BK, pt({ n: 16 })), cyl(0, 120, 0, 5.7, 1.4, '#3e4045', mt({ n: 16 })));
        [[0, 0], [1, 0], [2, 0], [0.5, 1], [1.5, 1], [1, 2]].forEach(([i, j]) => { const x = 46 + i * 7.6, y = 4 + 3.8 + j * 6.8; o.push(solid({ ax: 'z', sh: 'el', c: [x, y], a: 3.8, b: 3.6, n: 12, rings: [[-14, 0], [12, 0]], col: j === 2 ? '#7a5234' : '#8a5a34', mat: 'wood' }), disc(x, y, 12, 3.2, 0.4, '#d9b48a', wd({ n: 12, noOut: 1 }))); });
        o.push(box(53.6, 0, -15, 26, 1.2, 1.4, BK, mt({ r: 0.4 })), box(53.6, 0, 13, 26, 1.2, 1.4, BK, mt({ r: 0.4 })), ...[41.8, 65.4].map(x => box(x, 0, -1, 1.2, 14, 28, BK, mt({ r: 0.4 }))));
        return o; },
      fx: c => { const p = c.p, k = c.k, q = p(0, 44, 22.6); let f = '<g transform="translate(' + P2(q) + ')"><ellipse rx="' + f1(15 * k) + '" ry="' + f1(9.5 * k) + '" fill="#141210" stroke="#4a4c52" stroke-width="' + f1(1.1 * k) + '"/><ellipse cy="' + f1(2 * k) + '" rx="' + f1(12 * k) + '" ry="' + f1(6.5 * k) + '" fill="url(#chot)">' + an('opacity', '0.6;1;0.75;0.95;0.6', 1.8) + '</ellipse>'
          + '<rect x="' + f1(-9 * k) + '" y="' + f1(3 * k) + '" width="' + f1(18 * k) + '" height="' + f1(2.6 * k) + '" rx="' + f1(1.3 * k) + '" fill="#5a3418" transform="rotate(-6)"/><rect x="' + f1(-8 * k) + '" y="' + f1(4.4 * k) + '" width="' + f1(16 * k) + '" height="' + f1(2.4 * k) + '" rx="' + f1(1.2 * k) + '" fill="#6a3e1e" transform="rotate(8)"/></g>';
        const F = RD.H.fire(c, [[-3, 40, 21, 0.55], [3.5, 40.5, 21.5, 0.48]]);
        f += '<g clip-path="url(#cclip)">' + F.over + '</g>';
        const g = p(0, 3.4, 0); f += '<ellipse cx="' + f1(g[0]) + '" cy="' + f1(g[1]) + '" rx="' + f1(30 * k) + '" ry="' + f1(14 * k) + '" fill="#ff9a3a" opacity="0.12">' + an('opacity', '0.08;0.18;0.1', 1.6) + '</ellipse>';
        return { defs: '<radialGradient id="chot" cx="50%" cy="70%" r="60%"><stop offset="0" stop-color="#ffcf6a"/><stop offset="0.5" stop-color="#ff7a22" stop-opacity="0.7"/><stop offset="1" stop-color="#3a1a0a" stop-opacity="0"/></radialGradient><clipPath id="cclip"><ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1] - 5 * k) + '" rx="' + f1(15 * k) + '" ry="' + f1(14.5 * k) + '"/></clipPath>', front: f }; } }; };

  // ---------- books ----------
  const BOOKC = ['#7f2030', '#1f4f3e', '#2b3f7a', '#c99a2e', '#5a2a5e', '#e9dfcc', '#3a2a22', '#a8592b', '#2c2d31', '#6b8fb8', '#9fb58c', '#d9483b'];
  const shelfBooks = (o, R, x0, x1, y, zb, dmax, hmax) => { let x = x0 + 0.6; while (x < x1 - 2) { const k = R(); if (k < 0.08 && x1 - x > 14) { // decor piece
        const t = R(); if (t < 0.5) o.push(cyl(x + 4, y, zb + dmax / 2, 3.2, hmax * 0.55, ['#e9e4da', '#3f6a8a', '#c8693f'][Math.floor(R() * 3)], cer({ n: 12, rg: [[0, 0, 0.7], [hmax * 0.3, 0, 1], [hmax * 0.55, 0, 0.5]] })));
        else o.push(cyl(x + 4, y, zb + dmax / 2, 2.6, 1.4, '#3a2a22', wd({ n: 10 })), ball(x + 4, y + 1.4, zb + dmax / 2, 3.6, '#6b8fb8', { k: 6, n: 12 })); x += 9; continue; }
      if (k < 0.16 && x1 - x > 14) { const w = 11 + R() * 3; rep(3 + Math.floor(R() * 3), j => o.push(box(x + w / 2, y + j * 2.6, zb + dmax / 2, w - j * 0.6, 2.4, dmax - 2 - j * 0.4, BOOKC[Math.floor(R() * 12)], pt({ r: 0.5 })))); x += w + 1; continue; }
      const w = 2.4 + R() * 2.6, h = hmax * (0.7 + R() * 0.28), d = dmax - R() * 3, col = BOOKC[Math.floor(R() * 12)], zf = zb + d;
      o.push(box(x + w / 2, y, zb + d / 2, w, h, d, col, pt({ r: 0.5 })));
      if (R() < 0.7) [0.78, 0.18].forEach(t => o.push(box(x + w / 2, y + h * t, zf + 0.15, w * 0.86, 0.7, 0.3, GOLD, mt({ r: 0, noOut: 1 }))));
      x += w + 0.2; } };

  // ---------- Floor-to-ceiling walnut library wall with rolling ladder ----------
  N.library = S => { const W = 170, H = 150, DD = 38, WAL = '#5b3820', WD = '#4a2c18', ys = [10, 38, 66, 94, 122], bays = [[-W / 2 + 6, -27], [-24.5, 24.5], [27, W / 2 - 6]], zb = -DD / 2 + 3, LX = 32, lz = y => 50 - (y / 132) * 28;
    const R = rng('lib' + (S.nm || '')), lev = ys.map((y, j) => { const o = [box(0, y - 2.4, 0, W - 10, 2.4, DD - 2, WAL, wd({ r: 0.6 })), box(0, y - 2.4, DD / 2 - 0.6, W - 10, 2.4, 0.9, shade(WAL, 1.15), wd({ r: 0.3, noOut: 1 }))], top = j < 4 ? ys[j + 1] - 2.4 : H;
      [-25.75, 25.75].forEach(x => o.push(box(x, y, 0, 2.5, top - y, DD - 2, WAL, wd({ r: 0.4 })))); bays.forEach(([a, b]) => shelfBooks(o, R, a, b, y, zb, DD - 9, Math.min(24, top - y - 3))); return o; });
    const L = [{ back: 1, build: P => [slab(0, 0, -DD / 2 + 1, W - 4, H, 2, WD, wd({ r: 1 })), box(-(W / 2 - 3), 0, 0, 6, H, DD, WAL, wd({ r: 1.5 }))] }];
    lev.forEach(o => L.push({ build: P => o }));
    L.push({ build: P => [box(0, H, 0, W + 4, 4, DD + 4, WAL, wd({ r: 1 })), box(0, H + 4, -1, W + 8, 2.6, DD + 8, shade(WAL, 1.08), wd({ r: 1 })), box(0, H - 1.2, DD / 2 - 1, W - 10, 1, 0.6, '#ffe9b0', em({ r: 0.3 }))] }, { build: P => [box(W / 2 - 3, 0, 0, 6, H, DD, WAL, wd({ r: 1.5 }))] });
    L.push({ build: P => { const o = [], ry = 134, rz = 22; o.push(solid({ ax: 'x', sh: 'el', c: [rz, ry], a: 1.4, b: 1.4, n: 10, rings: [[-W / 2 + 4, 0], [W / 2 - 4, 0]], col: '#d4a548', mat: 'metal', shine: 1 }), ...[-W / 2 + 8, 0, W / 2 - 8].map(x => box(x, ry - 1, 19.5 - 2, 2, 2.4, 5, '#b8862e', mt({ r: 0.6 }))));
        [-1, 1].forEach(sg => { const x = LX + sg * 10; o.push(prism(x - 1.3, x + 1.3, [[lz(0) + 1.6, 0], [lz(0) + 4.2, 0], [lz(132) + 2.6, 132], [lz(132), 132]], '#7a4a2a', wd()), solid({ ax: 'x', sh: 'el', c: [lz(0) + 2.9, 2.6], a: 2.6, b: 2.6, n: 12, rings: [[x - 1.6, 0], [x + 1.6, 0]], col: '#2c2d31', mat: 'metal' }), box(x, 131, lz(132) - 0.4, 2, 4, 3, '#b8862e', mt({ r: 0.6 }))); });
        rep(8, i => { const y = 14 + i * 15.5; o.push(slabX(LX, y, lz(y) + 1.6, 18.4, 1.6, 2.6, '#8a5a34', wd({ r: 0.6 }))); }); return o; } });
    return { w: W + 6, d: DD + 30, layers: L, build: P => [box(0, 0, 0, W - 6, 8, DD - 4, shade(WAL, 0.85), wd({ r: 1 }))], glow: () => ({ y: 120, r: 70, c: 'url(#gWarm)' }) }; };

  // ---------- Built-in archway alcove bookcases: painted face frame with true arches, reading-nook bench ----------
  N.archBook = S => { const W = 176, H = 148, DD = 34, PNT = '#ece4d4', OAK = '#c8925a', bays = [[-58, 25, 'b'], [0, 30, 'n'], [58, 25, 'b']], ZF = DD / 2, SPR = 106;
    return { w: W + 6, d: DD + 6, build: P => { const R = rng('arch' + (S.nm || '')), o = [], zb = -DD / 2 + 2.5;
        o.push(slab(0, 0, -DD / 2 + 1, W - 4, H, 2, '#d9cfbc', pt({ r: 1 })), box(0, 0, 0, W, 9, DD, PNT, pt({ r: 1 })));
        [-1, 1].forEach(sg => o.push(box(sg * (W / 2 - 3), 0, 0, 6, H, DD, PNT, pt({ r: 1 }))));
        o.push(box(0, H, 0, W + 4, 4, DD + 4, PNT, pt({ r: 1 })), box(0, H + 4, -1, W + 8, 3, DD + 8, mix(PNT, '#ffffff', 0.3), pt({ r: 1 })));
        bays.forEach(([x, hw, t]) => { if (t === 'b') { [36, 64, 92, 118].forEach(y => o.push(box(x, y - 2.2, -1, hw * 2, 2.2, DD - 6, OAK, wd({ r: 0.5 })))); [9, 36, 64, 92, 118].forEach(y => shelfBooks(o, R, x - hw, x + hw, y, zb, DD - 10, 24)); }
          else { o.push(box(x, 9, 0, hw * 2, 22, DD - 4, PNT, pt({ r: 1 })), solid({ ax: 'y', sh: 'rr', c: [x, 1], a: hw - 1, b: DD / 2 - 3, r: 6, rings: [[31, 1.4, 0.97], [32.4, 0, 1], [37, 0, 1], [39, 3, 0.94], [40, 7, 0.84]], col: '#6b8fb8', soft: 1, mat: 'fab' }),
              solid({ ax: 'x', sh: 'el', c: [zb + 6, 46], a: 6, b: 6, n: 14, rings: [[x - hw + 2, 0, 0.75], [x - hw + 4, 0, 1], [x + hw - 4, 0, 1], [x + hw - 2, 0, 0.75]], col: '#e9d9b0', soft: 1, mat: 'fab' }),
              throwP(x - 14, 39, zb + 13, 18, '#c99a2e'), throwP(x + 15, 39, zb + 13, 16, '#efe4cc'), box(x, 98, zb + 0.6, 2.4, 2.4, 3, GOLD, mt({ r: 0.6 })), cyl(x, 92, zb + 4, 4.2, 6, '#fff2c8', { n: 12, rg: [[0, 0, 0.7], [6, 0, 1]] }), ball(x, 93, zb + 4, 1.6, '#ffe9a0', em({ k: 3 })),
              slab(x, 56, zb + 0.3, 30, 24, 1, '#3a2a22', wd({ r: 0.6 })), slab(x, 58, zb + 1, 26, 20, 0.4, '#9fb58c', pt({ r: 0.4 }))); } });
        return o; },
      fx: c => { const p = c.p, open = bays.map(([x, hw, t]) => { const bot = t === 'n' ? 9 : 9; return 'M' + (x - hw) + ' ' + (H - bot) + 'V' + (H - SPR) + 'A' + hw + ' ' + hw + ' 0 0 1 ' + (x + hw) + ' ' + (H - SPR) + 'V' + (H - bot) + 'Z'; }).join(''), frame = 'M' + (-W / 2) + ' 0H' + (W / 2) + 'V' + H + 'H' + (-W / 2) + 'Z' + open;
        const mold = bays.map(([x, hw]) => 'M' + (x - hw - 1.6) + ' ' + (H - 9) + 'V' + (H - SPR) + 'A' + (hw + 1.6) + ' ' + (hw + 1.6) + ' 0 0 1 ' + (x + hw + 1.6) + ' ' + (H - SPR) + 'V' + (H - 9)).join(''), key = bays.map(([x, hw]) => '<path d="M' + (x - 3) + ' ' + f1(H - SPR - hw - 3.5) + 'H' + (x + 3) + 'L' + (x + 2) + ' ' + f1(H - SPR - hw + 3) + 'H' + (x - 2) + 'Z" fill="#f6f0e4" stroke="#c9bfae" stroke-width="0.4"/>').join('');
        let f = '<defs><clipPath id="abcl"><path transform="' + plane(p, ZF + 0.2, H, 0) + '" d="' + open + '"/></clipPath></defs><g clip-path="url(#abcl)"><g transform="' + plane(p, ZF - 4, H, 0) + '"><path d="' + frame + '" fill="#c9bfae" fill-rule="evenodd"/></g></g><g transform="' + plane(p, ZF + 0.2, H, 0) + '"><path d="' + frame + '" fill="' + PNT + '" fill-rule="evenodd" stroke="#a89c88" stroke-width="0.8"/><path d="' + frame + '" fill="url(#p3glass)" fill-rule="evenodd" opacity="0.35"/><path d="' + mold + '" fill="none" stroke="#ffffff" stroke-width="0.9" opacity="0.8"/><path d="' + mold + '" fill="none" stroke="#b9ad98" stroke-width="0.4" transform="translate(0.9 0.9)"/>' + key + '</g>';
        return { defs: PATS, front: f }; } }; };

  // ---------- Floor-to-ceiling glass steelbook vault ----------
  N.vault = S => { const W = 112, H = 160, DD = 36, FR = '#2b2622', ys = [10, 42, 74, 106, 138], ZF = DD / 2, STEEL = ['#aab3bb', '#7d858e', '#d4a548', '#9a3a3a', '#3f6aa8', '#c9ced3', '#5a5e66', '#b07a2a'];
    return { w: W + 6, d: DD + 6, glow: () => ({ y: 80, r: 70, c: 'url(#gWarm)' }), build: P => { const R = rng('vault'), o = [];
        o.push(slab(0, 0, -DD / 2 + 1, W - 2, H, 2, '#1a1820', fb({ r: 1 })), box(0, 0, 0, W, 6, DD, FR, mt({ r: 1 })), box(0, H - 4, 0, W, 6, DD, FR, mt({ r: 1 })));
        [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => o.push(box(a * (W / 2 - 1.8), 6, b * (DD / 2 - 1.8), 3.6, H - 10, 3.6, FR, mt({ r: 0.6 }))));
        ys.slice(1).forEach(y => o.push(box(0, y - 1.2, -1, W - 6, 1.2, DD - 6, GL, cer({ r: 0.4, op: 0.4 })), box(0, y - 2.1, ZF - 5, W - 8, 0.8, 0.8, '#fff1c8', em({ r: 0.3 }))));
        ys.forEach((y, j) => { if (j === 4) return; let x = -W / 2 + 6; const z = -4;
          o.push(box(-W / 2 + 26, y, z + 2, 12, 2, 6, '#2c2d31', mt({ r: 0.6 })), slab(-W / 2 + 26, y + 2, z + 2, 15, 21, 1.6, STEEL[(j * 3) % 8], mt({ r: 0.8, shine: 1 })), disc(-W / 2 + 26 + (j % 2 ? 3 : -3), y + 14, z + 2.9, 3.6, 0.3, ['#ffd66b', '#e8fdff', '#ff9d4a', '#a6f06a'][j], { noOut: 1, n: 14 }), box(-W / 2 + 26, y + 5, z + 2.95, 11, 1.6, 0.3, '#14151a', { r: 0.2, noOut: 1 }));
          x = -W / 2 + 36; while (x < W / 2 - 6) { const w = 1.5 + R() * 0.5, col = STEEL[Math.floor(R() * 8)]; o.push(box(x + w / 2, y, z, w, 19, 13.5, col, mt({ r: 0.3, shine: 1 })), box(x + w / 2, y + 14, z + 6.9, w * 0.7, 2.6, 0.3, R() < 0.5 ? '#ffffff' : '#14151a', { r: 0, noOut: 1 })); x += w + 0.25; } });
        ys.forEach(y => o.push(cyl(-20, y + 26.6, -6, 1.8, 0.8, '#fff6dc', em({ n: 10 })), cyl(20, y + 26.6, -6, 1.8, 0.8, '#fff6dc', em({ n: 10 }))));
        o.push(slab(-W / 4, 6, ZF - 0.4, W / 2 - 2, H - 10, 0.8, GL, cer({ r: 0.6, op: 0.14 })), slab(W / 4, 6, ZF - 0.4, W / 2 - 2, H - 10, 0.8, GL, cer({ r: 0.6, op: 0.14 })));
        [-1, 1].forEach(sg => o.push(box(sg * 0.9, 6, ZF + 0.2, 1.8, H - 10, 1.8, FR, mt({ r: 0.4 })), cyl(sg * 4, 50, ZF + 2.2, 0.7, 60, '#d4a548', mt({ n: 8, shine: 1 })), box(sg * 4, 50, ZF + 0.6, 1.2, 1.2, 2.2, '#d4a548', mt({ r: 0.3 })), box(sg * 4, 109, ZF + 0.6, 1.2, 1.2, 2.2, '#d4a548', mt({ r: 0.3 }))));
        return o; },
      fx: c => { const p = c.p, w = W / 2 - 2, h = H - 10, cl = clipR(w, h, 0.6); let f = '';
        [-1, 1].forEach((sg, i) => { const cl2 = clipR(w, h, 0.6); f += '<g transform="' + plane(p, ZF + 0.1, H - 4, sg < 0 ? -W / 2 + 1 : 1) + '"><defs>' + cl2.d + '</defs><g clip-path="url(#' + cl2.id + ')"><rect x="-40" y="0" width="' + (w + 80) + '" height="' + h + '" fill="url(#p3glass)" opacity="0.8">' + atS('translate', '-30 0;30 0;-30 0', 9, -i * 3) + '</rect><path d="M2 2V' + (h - 2) + '" stroke="#ffffff" stroke-width="0.6" opacity="0.45"/></g></g>'; });
        return { defs: PATS, front: f }; } }; };

  // ---------- 24K award trophy + crystal decanter set ----------
  N.awardSet = S => { const G = '#e8b830', gm = o => mt(Object.assign({ shine: 1 }, o || {}));
    return { w: 56, d: 36, small: 1, build: P => { const o = [];
        o.push(cyl(8, 0, 4, 15, 1.2, '#c9ced3', mt({ rz: 9, n: 24, shine: 1 })));
        o.push(box(-14, 0, -2, 16, 6, 14, '#16161a', cer({ r: 1 })), box(-14, 6, -2, 12, 3, 10, '#22222a', cer({ r: 0.8 })), slab(-14, 1.4, 5.3, 9, 3.2, 0.4, G, gm({ r: 0.3 })));
        o.push(cyl(-14, 9, -2, 2.8, 1.4, G, gm({ n: 12 })), cyl(-14, 10.4, -2, 2.4, 14, G, gm({ n: 12, rg: [[0, 0, 1.15], [8, 0, 0.75], [14, 0, 0.85]] })), cyl(-14, 24.4, -2, 2.1, 6, G, gm({ n: 12, rg: [[0, 0, 1], [3, 0, 1.2], [6, 0, 0.9]] })), ball(-14, 30.2, -2, 2.1, G, gm({ k: 6, n: 12 })));
        [-1, 1].forEach(sg => o.push(cyl(-14 + sg * 2.6, 27, -2, 0.75, 9, G, gm({ n: 6 })), ball(-14 + sg * 2.6, 35.6, -2, 0.9, G, gm({ k: 3 }))));
        o.push(disc(-14, 41, -2.6, 5.4, 1.4, G, gm({ n: 18 })), ...rep(5, i => { const a = i * 2 * PI / 5 - PI / 2; return disc(-14 + Math.cos(a) * 3, 41 + Math.sin(a) * 3, -1.15, 1.1, 0.2, '#7a5414', { n: 8, noOut: 1 }); }), disc(-14, 41, -1.1, 1, 0.3, '#fff1b0', { n: 8, noOut: 1 }));
        o.push(cyl(10, 1.2, 0, 6.2, 15, GL, cer({ n: 8, op: 0.34, rg: [[0, 0, 0.86], [2, 0, 1], [10, 0, 1], [13, 0, 0.55], [15, 0, 0.32]] })), cyl(10, 1.6, 0, 5.4, 9.4, '#c27a2a', { n: 8, op: 0.75 }), cyl(10, 16.2, 0, 1.9, 3.6, GL, cer({ n: 8, op: 0.45 })), ball(10, 19.6, 0, 2.6, '#e8f6ff', cer({ n: 8, k: 3, sy: 1.25, op: 0.65 })));
        [[2, 9], [18, 8]].forEach(([x, z]) => o.push(cyl(x, 1.2, z, 3, 5.4, GL, cer({ n: 8, op: 0.35 })), cyl(x, 1.6, z, 2.6, 1.8, '#c27a2a', { n: 8, op: 0.8 }), box(x + 0.6, 3.4, z - 0.4, 1.6, 1.4, 1.6, '#eaf6ff', cer({ op: 0.6, r: 0.3 }))));
        return o; },
      fx: c => { const p = c.p, k = c.k; let f = ''; [[10, 6, 6.1], [10, 10, 6.1]].forEach(([x, y, z], i) => { const a = p(x - 2, y, z), b = p(x - 2, y + 7, z); f += '<path d="M' + P2(a) + 'L' + P2(b) + '" stroke="#ffffff" stroke-width="' + f1(0.6 * k) + '" opacity="0.7"/>'; });
        [[-14, 44, 0], [-16, 28, 1], [10, 21, 2]].forEach(([x, y], i) => { const q = p(x, y, 2); f += '<g transform="translate(' + P2(q) + ') scale(' + f1(k * 0.7) + ')"><path d="M0 -4L1 -1L4 0L1 1L0 4L-1 1L-4 0L-1 -1Z" fill="#ffffff" opacity="0">' + an('opacity', '0;1;0;0', 2.2, -i * 0.7) + '</path></g>'; });
        return { front: f }; } }; };

  // ---------- Sculpted walnut & shearling lounge chair (no stray parts) ----------
  N.shearChair = S => { const WAL = '#5b3820', SHE = '#efe6d6', nv = [0.958, 0.29], F0 = [-22, 30], F1 = [-36, 76], add = (a, b, k) => [a[0] + b[0] * k, a[1] + b[1] * k], B0 = add(F0, nv, -9), B1 = add(F1, nv, -9);
    const side = sg => { const x0 = sg * 34, x1 = sg * 39, a = Math.min(x0, x1), b = Math.max(x0, x1); return [prism(a, b, [[-34, 0], [36, 0], [38, 4], [-36, 4]], WAL, wd()), prism(a, b, [[22, 4], [30, 4], [27, 31], [19, 31]], WAL, wd()), prism(a, b, [[-31, 4], [-23, 4], [-19, 31], [-27, 31]], WAL, wd()),
      prism(a - 0.5, b + 0.5, [[-30, 31], [34, 33], [36, 37], [34, 39], [-31, 37]], shade(WAL, 1.08), wd()), prism(a, b, [add(B0, nv, -3.4), add(B1, nv, -3.4), add(B1, nv, 0.6), add(B0, nv, 0.6)], WAL, wd())]; };
    return { w: 84, d: 92, act: 'sit', seats: [{ x: 0, z: 4, h: 34 }], build: P => [],
      layers: [{ back: 1, build: P => side(-1) },
        { back: 1, build: P => [prism(-34, 34, [[-28, 14], [32, 18], [32, 22], [-28, 18]], WAL, wd()), prism(-35, 35, [add(B0, nv, -3), add(B1, nv, -3), B1, B0], WAL, wd()),
            prism(-33, 33, [[-26, 18], [31, 22], [33, 30], [30, 33.5], [-26, 30]], SHE, fb()), solid(fb({ ax: 'x', sh: 'el', c: [30.5, 28], a: 4.2, b: 4.8, n: 14, rings: [[-33, 0, 0.8], [-31, 0, 1], [31, 0, 1], [33, 0, 0.8]], col: mix(SHE, '#ffffff', 0.15) })),
            prism(-32, 32, [F0, F1, B1, B0], SHE, fb()), solid(fb({ ax: 'x', sh: 'el', c: [F1[0] - 3, F1[1] - 3], a: 6, b: 5, n: 14, rings: [[-32, 0, 0.8], [-30, 0, 1], [30, 0, 1], [32, 0, 0.8]], col: mix(SHE, '#ffffff', 0.12) }))],
          wrap: (p, s) => tex(s, [['p3she', 1], ['p3vel', 0.3]]) },
        { build: P => side(1) }],
      fx: () => ({ defs: PATS }) }; };

  // ---------- fresh food helpers ----------
  const apple = (x, y, z, col, s) => { s = s || 1; return [ball(x, y, z, 5.2 * s, col, { sy: 0.9, k: 6, n: 14 }), cyl(x, y + 9 * s, z, 0.5, 2.6 * s, '#5a3a20', { n: 4 }), ball(x + 1.8 * s, y + 10.4 * s, z, 1.8 * s, '#5fa84a', { sx: 1.5, sy: 0.35, k: 3, n: 8 })]; };
  const orange = (x, y, z, s) => { s = s || 1; return [ball(x, y, z, 5.4 * s, '#f2932c', { k: 6, n: 14 }), ball(x, y + 10.4 * s, z, 0.9 * s, '#6a8a3a', { k: 3, n: 6 })]; };
  const straw = (x, y, z, s) => { s = s || 1; return [ball(x, y, z, 2.4 * s, '#d9283b', { sy: 1.2, k: 4, n: 10 }), ball(x, y + 5.2 * s, z, 1.9 * s, '#4f9a3a', { sy: 0.35, k: 2, n: 8, shine: 0 })]; };
  const grapes = (x, y, z, col) => { const o = []; [[0, 0, 0], [2.6, 0, 1], [-2.6, 0, 1], [1.3, 2.3, 0], [-1.3, 2.3, 0], [0, 4.4, 1], [1.4, -2.2, 1], [-1.4, -2.2, 0]].forEach(([dx, dy, dz]) => o.push(ball(x + dx, y + 6 - dy, z + dz * 1.8, 1.9, col, { k: 4, n: 10 }))); o.push(cyl(x, y + 12.4, z, 0.4, 2.4, '#6b4a20', { n: 4 })); return o; };
  const kiwi = (x, y, z) => [cyl(x, y, z, 3.8, 1.6, '#8a6a3a', { n: 14 }), cyl(x, y + 1.6, z, 3.4, 0.3, '#8fc23a', { n: 14 }), cyl(x, y + 1.9, z, 1.2, 0.2, '#f4f2d6', { n: 10, noOut: 1 })];
  const can = (x, y, z, col) => [cyl(x, y, z, 2.3, 7.6, col, mt({ n: 14, shine: 1 })), cyl(x, y + 7.6, z, 2, 0.6, '#d5dde2', mt({ n: 12 }))];
  const cakeSlice = (x, y, z, c1, c2) => [prism(x - 3, x + 3, [[z - 4, y], [z + 4, y], [z + 4, y + 3.4], [z - 4, y + 3.4]], c1, pt()), prism(x - 3, x + 3, [[z - 4, y + 3.4], [z + 4, y + 3.4], [z + 4, y + 4.4], [z - 4, y + 4.4]], '#fff6ea', pt()), prism(x - 3, x + 3, [[z - 4, y + 4.4], [z + 4, y + 4.4], [z + 4, y + 7.4], [z - 4, y + 7.4]], c1, pt()), prism(x - 3.2, x + 3.2, [[z - 4.2, y + 7.4], [z + 4.2, y + 7.4], [z + 4, y + 8.6], [z - 4, y + 8.6]], c2, pt()), ...straw(x, y + 8.6, z, 0.55)];
  RD.FOOD3 = { apple, orange, straw, grapes, kiwi, can, cakeSlice };

  // ---------- Refrigerated smart console table: chilled glass well + two lit fridge drawers full of snacks ----------
  N.smartConsole = S => { const W = 132, D2 = 62, TH = 40, BODY = '#2b2d33', TOPC = '#1d2027', FRZ = '#e8f6ff';
    return { w: W + 6, d: D2 + 6, topH: TH + 1, topW: 50, build: P => { const o = [], z0 = -D2 / 2, z1 = D2 / 2;
        o.push(box(0, 0, 0, W - 10, 4, D2 - 8, '#141519', mt({ r: 1 })), box(0, 4, -D2 / 2 + 2, W, 33, 4, BODY, mt({ r: 1.5 })));
        [-1, 1].forEach(sg => o.push(box(sg * (W / 2 - 2), 4, 0, 4, 33, D2, BODY, mt({ r: 1.5 }))));
        o.push(box(0, 4, 0, W - 4, 2, D2 - 2, BODY, mt({ r: 1 })), box(-39, 20.6, 0, 46, 1, D2 - 4, GL, cer({ op: 0.4, r: 0.4 })), box(39, 20.6, 0, 46, 1, D2 - 4, GL, cer({ op: 0.4, r: 0.4 })), box(0, 6, -D2 / 2 + 4.2, W - 8, 30, 0.4, FRZ, em({ r: 0.4, op: 0.9 })), box(0, 4, 0, 30, 21, D2 - 2, BODY, mt({ r: 1 })), box(-8.6, 25, 0, 0.8, 12, 38, FRZ, cer({ r: 0.3 })), box(8.6, 25, 0, 0.8, 12, 38, FRZ, cer({ r: 0.3 })));
        const cc = ['#d9363b', '#3f7fc8', '#4f9a4a', '#f2c14a', '#2c2d31', '#ff9d4a'];
        [-1, 1].forEach((sg, i) => { const cx = sg * 39; rep(4, j => o.push(...can(cx - 16 + j * 5.6, 6, -10 + (j % 2) * 4, cc[(j + i * 2) % 6])));
          o.push(box(cx + 13, 6, -4, 10, 8, 6, sg < 0 ? '#d9363b' : '#f2c94c', pt({ r: 0.6 })), box(cx + 13, 14, -4, 8, 4, 5, '#ffffff', pt({ r: 0.6 })));
          if (i) o.push(...cakeSlice(cx - 10, 21.6, -2, '#efc88a', '#f6c6d2'), ...cakeSlice(cx + 2, 21.6, -4, '#6b3a22', '#3a2010'), ...grapes(cx + 14, 21.6, -2, '#6b3a8a'));
          else o.push(...apple(cx - 12, 21.6, -4, '#d9363b', 0.9), ...orange(cx - 1, 21.6, -6, 0.9), ...apple(cx + 9, 21.6, -2, '#9fcf4a', 0.85), ...straw(cx + 15, 21.6, 2, 0.9), ...straw(cx + 3, 21.6, 4, 0.8));
          o.push(slab(cx, 5, z1 - 0.6, 46, 31, 1, GL, cer({ r: 1.2, op: 0.18 })), box(cx, 30, z1 + 0.3, 30, 1.6, 1.8, CH, mt({ r: 0.8, shine: 1 }))); });
        o.push(slab(0, 6, z1 - 0.6, 26, 29, 1.2, '#16181d', mt({ r: 1 })), slab(0, 24, z1 + 0.2, 16, 7, 0.4, '#0e1a24', { r: 0.8 }), slab(0, 25, z1 + 0.55, 13, 5, 0.2, '#6ac8ff', em({ r: 0.6, op: 0.85 })));
        o.push(box(-37, 37, 0, 58, 3, D2, TOPC, cer({ r: 1.5, op: 0.95 })), box(37, 37, 0, 58, 3, D2, TOPC, cer({ r: 1.5, op: 0.95 })), box(0, 37, -D2 / 2 + 6, 16, 3, 12, TOPC, cer({ r: 1 })), box(0, 37, D2 / 2 - 6, 16, 3, 12, TOPC, cer({ r: 1 })));
        o.push(box(0, 26, 0, 16, 1, 38, FRZ, cer({ r: 1 })), ...apple(-4, 27, -9, '#c42a30', 0.7), ...orange(4, 27, -8, 0.68), ...grapes(-3, 27, 4, '#7fb84a'), ...kiwi(5, 27, 6), ...straw(-5, 27, 12, 0.7), ...straw(4, 27, 13, 0.65));
        o.push(box(0, 39.6, 0, 16.4, 0.6, 38.4, GL, cer({ r: 0.4, op: 0.2 })));
        o.push(box(-46, 40, 4, 8, 0.6, 15, '#14151a', { r: 1.2 }), slab(-46, 40.1, 4, 6.6, 0.3, 13, '#3a6ac8', em({ r: 1, op: 0.5 })));
        return o; },
      fx: c => { const p = c.p; let f = '';
        [[-46, -14], [-26, 8], [26, 8], [46, -12]].forEach(([x, z], i) => f += '<g transform="' + planeH(p, 40.2, x, z) + '"><circle r="5.2" fill="none" stroke="#6ac8ff" stroke-width="0.6" opacity="0.8">' + an('opacity', '0.3;1;0.3', 2.4, -i * 0.6) + '</circle><circle r="3" fill="none" stroke="#6ac8ff" stroke-width="0.4" opacity="0.6"/></g>');
        f += '<g transform="' + planeH(p, 40.2, -60, -26) + '">' + rep(10, i => '<rect x="' + (i * 4) + '" y="0" width="2.6" height="1.2" rx="0.6" fill="#6ac8ff">' + an('opacity', '0.25;1;0.25', 1.6, -i * 0.16) + '</rect>').join('') + '</g>';
        const q = p(0, 25.6, D2 / 2 + 0.7); f += '<g transform="' + plane(p, D2 / 2 + 0.7, 30.6, -6.5) + '"><text x="6.5" y="3.6" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="3" fill="#e8fdff">4°C</text></g>';
        [-39, 39].forEach((x, i) => f += '<g transform="' + plane(p, D2 / 2 + 0.2, 36, x - 23) + '"><rect width="46" height="31" rx="1.2" fill="url(#p3glass)" opacity="0.7"/>' + rep(8, j => '<circle cx="' + (4 + (j * 13) % 40) + '" cy="' + (5 + (j * 7) % 22) + '" r="0.5" fill="#ffffff" opacity="0.6"/>').join('') + '</g>');
        rep(4, i => { const a = p(-6 + i * 4, 40, -10 + (i % 2) * 20); f += '<ellipse cx="' + f1(a[0]) + '" cy="' + f1(a[1]) + '" rx="3" ry="1.6" fill="#ffffff" opacity="0">' + an('cy', f1(a[1]) + ';' + f1(a[1] - 12), 3, -i * 0.8) + an('opacity', '0;0.4;0', 3, -i * 0.8) + an('rx', '2;6', 3, -i * 0.8) + '</ellipse>'; });
        return { defs: PATS, front: f }; } }; };

  // ---------- Robotic rolling butler: omni-wheel base, telescoping column, display head, arms holding a tray ----------
  N.robButler = S => { const WHT = '#eef0f3', CY = '#4fe0ff', CHR = '#cfd6dc';
    return { w: 64, d: 64, roam: 1, build: P => { const o = [];
        rep(3, i => { const a = i * 2 * PI / 3 + PI / 2, x = Math.cos(a) * 14, z = Math.sin(a) * 14; o.push(solid({ ax: 'x', sh: 'el', c: [z, 4], a: 4, b: 4, n: 12, rings: [[x - 1.6, 0], [x + 1.6, 0]], col: '#2c2d31', mat: 'metal' })); });
        o.push(cyl(0, 3, 0, 20.5, 3, '#2c2d31', mt({ n: 24 })), cyl(0, 6, 0, 20, 8, WHT, cer({ n: 24, rg: [[0, 0, 1], [6, 0, 0.98], [8, 0, 0.9]] })), cyl(0, 14, 0, 18, 0.9, CY, em({ n: 24 })), slab(0, 8, 19.4, 12, 3, 0.6, '#14151a', { r: 1.4 }));
        o.push(cyl(0, 14.9, 0, 7, 15, CHR, mt({ n: 16, shine: 1 })), cyl(0, 29.9, 0, 7.6, 1.4, '#2c2d31', mt({ n: 16 })), cyl(0, 31.3, 0, 5.6, 12, CHR, mt({ n: 16, shine: 1 })), cyl(0, 43.3, 0, 6.2, 1.2, '#2c2d31', mt({ n: 16 })), cyl(0, 44.5, 0, 4.3, 9, CHR, mt({ n: 14, shine: 1 })));
        o.push(ball(0, 52, 0, 13, WHT, cer({ sy: 0.8, sz: 0.85, k: 7, n: 18 })), cyl(0, 72, 0, 3, 3, '#2c2d31', mt({ n: 12 })), box(0, 74.6, 1, 20, 13, 10, '#1a1c22', mt({ r: 4 })), box(0, 74.2, 1, 21, 1, 10.6, WHT, cer({ r: 4 })), ...[-1, 1].map(sg => ball(sg * 10.8, 78, 1, 2.4, CHR, mt({ k: 4, shine: 1 }))));
        [-1, 1].forEach(sg => { const x = sg * 13.6; o.push(ball(x, 62, 0, 3.4, CHR, mt({ k: 5, shine: 1 })), solid({ ax: 'z', sh: 'el', c: [x, 64.4], a: 1.9, b: 1.9, n: 10, rings: [[1, 0], [12, 0]], col: WHT, mat: 'cer' }), ball(x, 62.2, 12.6, 2.4, CHR, mt({ k: 4, shine: 1 })), solid({ ax: 'z', sh: 'el', c: [x, 64.6], a: 1.6, b: 1.6, n: 10, rings: [[14, 0], [21, 0]], col: '#2c2d31', mat: 'metal' }), box(x - sg * 1, 63, 22.2, 3, 2.6, 3, CHR, mt({ r: 0.8 }))); });
        o.push(cyl(0, 65.6, 22, 15, 1.4, CHR, mt({ rz: 10, n: 24, shine: 1 })), arcW(0, 67, 22, 15, 10, 0.8, 1.2, 0, 2 * PI, '#9aa3a8', mt({ n: 24 })));
        o.push(cyl(-6, 67, 22, 3.6, 9, '#ffffff', pt({ n: 14, rg: [[0, 0, 0.78], [9, 0, 1]] })), ...rep(6, i => ball(-6 + (i % 3 - 1) * 2, 75.6 + (i > 2 ? 1.4 : 0), 22 + (i % 2) * 1.6, 1.4, '#fff6dc', { k: 3, n: 7, shine: 0 })), cyl(6, 67, 20, 2.6, 9, '#d9363b', pt({ n: 12, rg: [[0, 0, 0.8], [9, 0, 1]] })), cyl(6, 76, 20, 2.8, 0.8, '#ffffff', { n: 12 }), cyl(6.8, 76.8, 20, 0.4, 5, '#ffffff', { n: 4 }), box(4, 67, 27, 8, 0.6, 5, '#ffffff', { r: 0.5 }));
        return o; },
      fx: c => { const p = c.p; let f = '<g transform="' + plane(p, 6.15, 85.8, -8) + '">' + [4.6, 11.4].map(x => '<ellipse cx="' + x + '" cy="4.6" rx="1.6" ry="2" fill="#4fe0ff">' + an('ry', '2;2;0.2;2;2', 4, 0, '0;0.9;0.93;0.96;1') + '</ellipse>').join('') + '<path d="M5.4 8.2Q8 9.8 10.6 8.2" fill="none" stroke="#4fe0ff" stroke-width="0.6" stroke-linecap="round"/></g>';
        const q = p(0, 14.4, 0); f += '<g transform="' + planeH(p, 14.5) + '"><ellipse rx="18" ry="18" fill="none" stroke="#ffffff" stroke-width="1" stroke-dasharray="6 50" opacity="0.8">' + an('stroke-dashoffset', '0;-113', 2) + '</ellipse></g>';
        return { front: f }; } }; };

  // ---------- Automated robotic archive wall with dynamically lit niches + moving gantry picker ----------
  N.archiveWall = S => { const W = 172, H = 150, DD = 24, FRM = '#34363c', EDG = '#b9c0c8', COLS = 5, ROWS = 4, cw = (W - 8) / COLS, rh = (H - 14) / ROWS, x0 = -W / 2 + 4, y0 = 10, LED = ['#6ac8ff', '#ffd66b', '#b48cff', '#4fe0d0', '#ff9d4a'];
    const cell = (i, j) => ({ x: x0 + cw * (i + 0.5), y: y0 + rh * j });
    const R = rng('arch2'), zb = -DD / 2 + 3, rows = rep(ROWS, j => { const o = [], g = []; if (j) g.push(box(0, y0 + rh * j - 1.2, 0, W - 6, 2.4, DD - 1, FRM, mt({ r: 0.4 })), box(0, y0 + rh * j - 1.2, DD / 2 - 0.2, W - 6, 2.4, 0.7, EDG, mt({ r: 0.2, noOut: 1 })));
        rep(COLS - 1, i => { const hh = rh - (j ? 1.2 : 0) - (j < ROWS - 1 ? 1.2 : 0), yy = y0 + rh * j + (j ? 1.2 : 0); o.push(box(x0 + cw * (i + 1), yy, 0, 2.4, hh, DD - 1, FRM, mt({ r: 0.3 })), box(x0 + cw * (i + 1), yy, DD / 2 - 0.2, 2.4, hh, 0.7, EDG, mt({ r: 0.2, noOut: 1 }))); });
        rep(COLS, i => { const { x, y } = cell(i, j), b = y + 1.2, t = Math.floor(R() * 5), zc = zb + 7;
          o.push(box(x, b + rh - 3.4, DD / 2 - 3, cw - 6, 0.7, 0.8, '#ffffff', em({ r: 0.3 })));
          if (t === 0) rep(3, k => o.push(box(x - 8 + k * 8, b, zc, 7, 9, 12, ['#d8cdb8', '#c9bba0', '#e2d6c0'][k], pt({ r: 0.5 })), slab(x - 8 + k * 8, b + 5, zc + 6.2, 4, 2, 0.3, '#ffffff', { r: 0.2, noOut: 1 })));
          else if (t === 1) shelfBooks(o, R, x - cw / 2 + 2, x + cw / 2 - 2, b, zb + 1, 14, rh - 7);
          else if (t === 2) o.push(cyl(x - 4, b, zc, 4.6, 14, ['#2c2d31', '#e9e4da', '#3f6a8a'][Math.floor(R() * 3)], cer({ n: 16, rg: [[0, 0, 0.6], [6, 0, 1], [11, 0, 0.6], [14, 0, 0.75]] })), cyl(x + 6, b, zc + 2, 3, 8, '#c8693f', cer({ n: 12, rg: [[0, 0, 0.8], [8, 0, 1]] })));
          else if (t === 3) o.push(box(x, b, zc, 10, 4, 10, '#2c2d31', mt({ r: 0.6 })), ball(x, b + 4, zc, 6, ['#d4a548', '#d5dde2', '#e9e4da'][Math.floor(R() * 3)], mt({ k: 7, n: 16, shine: 1 })));
          else o.push(box(x, b, zc, 14, 2, 10, '#2c2d31', mt({ r: 0.5 })), box(x - 2, b + 2, zc, 6, 10, 6, '#e9e4da', cer({ r: 0.5 })), box(x + 3, b + 2, zc - 1, 4, 16, 4, '#9aa3a8', mt({ r: 0.5 }))); });
        return { g, o }; });
    return { w: W + 6, d: DD + 20, build: P => [box(0, 0, 0, W, y0, DD, '#2c2d31', mt({ r: 1 }))],
      layers: [{ back: 1, build: P => [slab(0, y0, -DD / 2 + 1, W - 4, H - 4 - y0, 2, '#1c1e24', pt({ r: 0.6 }))],
          wrap: (p, s) => { let g = '<g transform="' + plane(p, -DD / 2 + 2.1, 0, 0) + '">'; rep(ROWS, j => rep(COLS, i => { const { x, y } = cell(i, j), c0 = LED[(i + j) % 5], seq = rep(6, k => LED[(i + j + k) % 5]).join(';') + ';' + c0, b = -(i * 0.45 + j * 0.3);
              g += '<rect x="' + f1(x - cw / 2 + 2) + '" y="' + f1(-(y + rh - 1.6)) + '" width="' + f1(cw - 4) + '" height="' + f1(rh - 3.2) + '" rx="1" fill="url(#awg' + (i + j) % 5 + ')">' + an('opacity', '0.55;1;0.55', 3.2, b) + '</rect>'; }));
            return s + g + '</g>'; } }, { back: 1, build: P => [box(-(W / 2 - 2), y0, 0, 4, H - 4 - y0, DD, FRM, mt({ r: 0.8 }))] },
        ...[].concat(...rows.map((r, j) => [{ build: P => r.g, wrap: (p, s) => { let gl = ''; rep(COLS, i => { const { x, y } = cell(i, j); gl += '<g transform="' + planeH(p, y + 1.25, x, 0) + '"><rect x="' + f1(-cw / 2 + 1.4) + '" y="' + f1(-DD / 2 + 1) + '" width="' + f1(cw - 2.8) + '" height="' + f1(DD - 2) + '" fill="url(#awf' + (i + j) % 5 + ')">' + an('opacity', '0.45;0.95;0.45', 3.2, -(i * 0.45 + j * 0.3)) + '</rect></g>'; }); return s + gl; } }, { build: P => r.o }])), { build: P => [box(0, H - 4, 0, W, 4, DD, FRM, mt({ r: 1 })), box(0, H - 4, DD / 2 - 0.1, W, 4, 0.7, EDG, mt({ r: 0.3, noOut: 1 })), box(W / 2 - 2, y0, 0, 4, H - 4 - y0, DD, FRM, mt({ r: 0.8 })), box(0, H - 8, DD / 2 + 4, W - 8, 3, 3, CH, mt({ r: 0.8 }))] },
        { build: P => [box(-W / 2 + 22, H - 11, DD / 2 + 4, 6, 6, 5, '#2c2d31', mt({ r: 1 })), box(-W / 2 + 22, 12, DD / 2 + 4, 2.4, H - 22, 2.4, '#9aa3a8', mt({ r: 0.5 }))],
          wrap: (p, s) => { const e = p(1, 0, 0), o0 = p(0, 0, 0), dx = e[0] - o0[0], dy = e[1] - o0[1], T = d => f1(dx * d) + ' ' + f1(dy * d); return '<g>' + atS('translate', '0 0;' + T(0) + ';' + T(64) + ';' + T(64) + ';' + T(124) + ';' + T(124) + ';0 0', 14) + s + '</g>'; } },
        { build: P => [box(-W / 2 + 22, 70, DD / 2 + 6, 9, 6, 8, '#2c2d31', mt({ r: 1.2 })), box(-W / 2 + 22, 64, DD / 2 + 8, 7, 6, 7, '#d8cdb8', pt({ r: 0.5 })), box(-W / 2 + 22, 72.6, DD / 2 + 10.1, 4, 1, 0.4, '#4fe0ff', em({ r: 0.2 }))],
          wrap: (p, s) => { const e = p(1, 0, 0), o0 = p(0, 0, 0), dx = e[0] - o0[0], dy = e[1] - o0[1], k = kOf(p), T = d => f1(dx * d) + ' ' + f1(dy * d), Y = d => '0 ' + f1(-d * k * CA);
            return '<g>' + atS('translate', '0 0;' + T(0) + ';' + T(64) + ';' + T(64) + ';' + T(124) + ';' + T(124) + ';0 0', 14) + '<g>' + atS('translate', Y(-40) + ';' + Y(30) + ';' + Y(30) + ';' + Y(-20) + ';' + Y(-20) + ';' + Y(45) + ';' + Y(-40), 14) + s + '</g></g>'; } }],
      fx: c => ({ defs: LED.map((col, i) => '<radialGradient id="awg' + i + '" cx="50%" cy="20%" r="85%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.9"/><stop offset="0.35" stop-color="' + col + '" stop-opacity="0.85"/><stop offset="1" stop-color="' + col + '" stop-opacity="0.15"/></radialGradient><linearGradient id="awf' + i + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + col + '" stop-opacity="0.85"/><stop offset="1" stop-color="' + col + '" stop-opacity="0.1"/></linearGradient>').join('') }) }; };

  // ---------- Levitating chronometer sphere (polished armillary rings) & raw iron meteorite ----------
  N.chrono = S => ({ w: 60, d: 34, small: 1, build: P => { const o = [], R = rng('met');
      o.push(box(-12, 0, 0, 26, 5, 20, '#16161a', cer({ r: 2 })), arcW(-12, 5, 0, 7, 7, 1.2, 1.2, 0, 2 * PI, '#d4a548', mt({ n: 20 })), cyl(-12, 5, 0, 4.2, 0.6, '#6ac8ff', em({ n: 16 })));
      o.push(cyl(15, 0, 0, 8, 3, '#3a2416', wd({ n: 18 })), cyl(15, 3, 0, 1.4, 4, '#9aa3a8', mt({ n: 8 })));
      [[0, 0, 0, 5.4], [-3, 1.6, 2, 3.8], [3.4, 2.4, -1.6, 3.6], [1, 4.4, 1.6, 3.4], [-2, 3.8, -2.4, 3], [2.6, 0.4, 3, 2.8]].forEach(([dx, dy, dz, r]) => o.push(ball(15 + dx, 6 + dy, dz, r, '#4b4a4c', mt({ k: 4, n: 9, sy: 0.85 }))));
      rep(7, () => o.push(ball(15 + (R() - 0.5) * 9, 8 + R() * 6, 3.4 + R() * 1.6, 0.9 + R() * 0.8, '#2e2d30', { sy: 0.4, k: 2, n: 8, noOut: 1, shine: 0 })));
      return o; },
    layers: [{ build: P => [ball(-12, 14, 0, 5.4, '#d5dde2', mt({ k: 8, n: 18, shine: 1 })), disc(-12, 19.4, 5, 3.2, 0.3, '#fffaf1', { n: 18, noOut: 1 })],
      wrap: (p, s) => { const k = kOf(p), q = p(-12, 19.4, 0), R = 9 * k; const ring = (rx, ry, rot, col, w, d) => '<g transform="rotate(' + rot + ')"><ellipse rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="none" stroke="#6a4a12" stroke-width="' + f1(w + 0.5) + '"/><ellipse rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="none" stroke="' + col + '" stroke-width="' + f1(w) + '"/><ellipse rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="none" stroke="#ffffff" stroke-width="' + f1(w * 0.3) + '" stroke-dasharray="' + f1(rx * 0.8) + ' ' + f1(rx * 5) + '" opacity="0.8">' + an('stroke-dashoffset', '0;-' + f1(rx * 6.3), d) + '</ellipse></g>';
        let r2 = '<g transform="translate(' + P2(q) + ')">' + ring(R, R * 0.32, -18, '#e8c25a', 0.9 * k, 3) + '<g>' + '<ellipse rx="' + f1(R * 0.86) + '" ry="' + f1(R * 0.86) + '" fill="none" stroke="#c9ced3" stroke-width="' + f1(0.7 * k) + '">' + anS('rx', f1(R * 0.86) + ';' + f1(R * 0.08) + ';' + f1(R * 0.86), 5) + '</ellipse></g>' + ring(R * 1.12, R * 0.42, 24, '#d4a548', 0.7 * k, 4.4)
          + '<g transform="rotate(-18)"><ellipse rx="' + f1(R) + '" ry="' + f1(R * 0.32) + '" fill="none" stroke="#3a2a10" stroke-width="' + f1(0.25 * k) + '" stroke-dasharray="' + f1(0.25 * k) + ' ' + f1(1.6 * k) + '"/></g>'
          + '<line x1="0" y1="0" x2="0" y2="' + f1(-2.4 * k) + '" stroke="#2c2d31" stroke-width="' + f1(0.35 * k) + '" transform="translate(' + f1(0) + ' ' + f1(0) + ')">' + at('rotate', '0;360', 6) + '</line><line x1="0" y1="0" x2="' + f1(1.6 * k) + '" y2="0" stroke="#2c2d31" stroke-width="' + f1(0.45 * k) + '">' + at('rotate', '0;360', 40) + '</line></g>';
        return '<g>' + atS('translate', '0 0;0 ' + f1(-2.6 * k) + ';0 0', 3.2) + s + r2 + '</g>'; } }],
    fx: c => { const p = c.p, q = p(15, 9, 5.4), k = c.k; let f = '<g transform="translate(' + P2(q) + ') scale(' + f1(k) + ')"><path d="M-2.6 -2.4L2.8 -3L3.2 2.2L-2.2 2.8Z" fill="#c9ced3" stroke="#6b6f7a" stroke-width="0.3"/><path d="M-2 -2L2.6 2M-1 -2.6L3 1M-2.4 0L0.6 2.6M-2.2 1.6L2.6 -2.2M-0.6 2.6L3 -0.6M-2.6 -1L0.6 -2.8" stroke="#8a8f96" stroke-width="0.22"/></g>';
      const g = p(-12, 5.6, 0); f += '<g transform="' + planeH(p, 5.6, -12, 0) + '"><ellipse rx="5" ry="5" fill="none" stroke="#6ac8ff" stroke-width="0.5">' + an('rx', '3;8', 1.8) + an('ry', '3;8', 1.8) + an('opacity', '0.8;0', 1.8) + '</ellipse></g>';
      rep(3, i => { const s = p(15 + (i - 1) * 3, 10 + i * 1.6, 4); f += '<circle cx="' + f1(s[0]) + '" cy="' + f1(s[1]) + '" r="' + f1(0.5 * k) + '" fill="#ffffff" opacity="0">' + an('opacity', '0;1;0;0', 2.4, -i * 0.8) + '</circle>'; });
      return { front: f }; } });

  // ---------- Stacked hardcover art books + polished brass magnifying glass ----------
  N.artBooks = S => { const BKS = [[0, 0, 36, 5.2, 30, '#2f4870', 'MODERN ART'], [-1.6, 5.2, 31, 4.6, 26, '#7f2030', 'BAUHAUS'], [1.2, 9.8, 27, 4, 22, '#1f4f3e', 'MATISSE']];
    return { w: 52, d: 40, small: 1, topH: 14, build: P => { const o = [];
        BKS.forEach(([dx, y, w, t, d, col]) => { o.push(box(dx, y, 0, w, 0.9, d, col, fb({ r: 0.6, soft: 0 })), box(dx + 0.6, y + 0.9, -0.4, w - 2.4, t - 1.8, d - 2.4, '#f6efe0', pt({ r: 0.3 })), box(dx, y + t - 0.9, 0, w, 0.9, d, col, fb({ r: 0.6, soft: 0 })), box(dx, y, d / 2 - 0.7, w, t, 1.4, shade(col, 0.92), fb({ r: 0.7, soft: 0 }))); });
        const y = 13.8, mx = -2, mz = -3; o.push(arcW(mx, y, mz, 6.4, 6.4, 1.3, 1.4, 0, 2 * PI, '#d4a548', mt({ n: 24, shine: 1 })), cyl(mx, y + 0.3, mz, 5.2, 0.7, '#dff2fb', cer({ n: 22, op: 0.4 })), solid({ ax: 'x', sh: 'el', c: [mz + 1.6, y + 0.9], a: 1.1, b: 1.1, n: 10, rings: [[mx + 6.2, 0, 0.9], [mx + 9, 0, 1]], col: '#d4a548', mat: 'metal', shine: 1 }), solid({ ax: 'x', sh: 'el', c: [mz + 2.4, y + 1], a: 1.5, b: 1.5, n: 12, rings: [[mx + 9, 0, 1], [mx + 19, 0, 1.1], [mx + 20, 0, 0.7]], col: '#3a2416', mat: 'wood', shine: 1 }));
        o.push(box(-8, 9.6, 12.9, 1.6, 0.3, 4, '#c8303a', { r: 0, noOut: 1 }), box(-8, 5.2, 14.6, 1.6, 4.6, 0.3, '#c8303a', { r: 0, noOut: 1 }));
        return o; },
      fx: c => { const p = c.p; let f = '';
        BKS.forEach(([dx, y, w, t, d, col, title]) => { f += '<g transform="' + plane(p, d / 2 + 0.75, y + t, dx - w / 2) + '"><rect x="1" y="0.5" width="' + f1(w - 2) + '" height="0.35" fill="#e2b14a"/><rect x="1" y="' + f1(t - 0.85) + '" width="' + f1(w - 2) + '" height="0.35" fill="#e2b14a"/><text x="' + f1(w / 2) + '" y="' + f1(t / 2 + 1.05) + '" text-anchor="middle" font-family="Georgia, \'Times New Roman\', serif" font-weight="700" font-size="' + f1(Math.min(2.8, t * 0.62)) + '" letter-spacing="0.4" fill="#f2d27a">' + title + '</text></g>';
          let pl = ''; rep(5, j => pl += '<path d="M0 ' + f1(1.1 + j * (t - 2.2) / 4) + 'H' + f1(d - 3) + '" stroke="#d8ccb2" stroke-width="0.18"/>'); f += '<g transform="' + planeX(p, dx + w / 2 - 1.15, y + t - 0.9, -d / 2 + 1) + '">' + pl + '</g>'; });
        const q = p(-3.5, 14.6, -4); f += '<g transform="translate(' + P2(q) + ')"><path d="M' + f1(-3 * c.k) + ' ' + f1(-0.6 * c.k) + 'Q' + f1(-1 * c.k) + ' ' + f1(-2.6 * c.k) + ' ' + f1(2.4 * c.k) + ' ' + f1(-1.8 * c.k) + '" fill="none" stroke="#ffffff" stroke-width="' + f1(0.6 * c.k) + '" opacity="0.8"/></g>';
        return { front: f }; } }; };

  // ---------- Clean compact microwave on a sturdy wooden stool ----------
  N.microClean = S => ({ w: 56, d: 48, build: P => { const o = [], BEE = '#d6a46a', SS = '#c9cdd2';
      [[-13, -10], [13, -10], [-13, 10], [13, 10]].forEach(([x, z]) => o.push(cyl(x, 0, z, 1.9, 38, BEE, wd({ n: 10, rg: [[0, 0, 0.9], [38, 0, 1.1]] }))));
      o.push(slabX(0, 12, -10, 26, 2.2, 2.2, BEE, wd({ r: 0.8 })), slabX(0, 12, 10, 26, 2.2, 2.2, BEE, wd({ r: 0.8 })), box(-13, 16, 0, 2.2, 2.2, 20, BEE, wd({ r: 0.8 })), box(13, 16, 0, 2.2, 2.2, 20, BEE, wd({ r: 0.8 })));
      o.push(cyl(0, 38, 0, 20, 3.4, BEE, wd({ rz: 16, n: 26, rg: [[0, 0, 0.97], [2.4, 0, 1], [3.4, 0, 0.96]] })));
      [[-17, -11], [17, -11], [-17, 11], [17, 11]].forEach(([x, z]) => o.push(cyl(x, 41.4, z, 1.4, 1, '#1d1d20', { n: 8 })));
      o.push(box(0, 42.4, 0, 44, 25, 30, SS, mt({ r: 2.5, shine: 0 })), slab(-6, 44.6, 15.3, 29, 20.6, 0.6, '#16181c', cer({ r: 2 })), slab(-7, 47, 15.75, 22, 15, 0.3, '#2a2010', { r: 1.4, noOut: 1 }), slab(14.6, 44.6, 15.3, 10.4, 20.6, 0.6, '#1d1f24', cer({ r: 1.4 })), box(8, 46, 16.4, 1.4, 16, 1.4, '#e3e7eb', mt({ r: 0.6, shine: 1 })), box(8, 46, 15.6, 1, 1, 1, '#9aa3a8', mt({ r: 0.2 })), box(8, 61, 15.6, 1, 1, 1, '#9aa3a8', mt({ r: 0.2 })));
      o.push(slab(14.6, 59, 15.7, 8, 3.6, 0.3, '#0a1a14', { r: 0.6, noOut: 1 }));
      rep(9, i => o.push(slab(12 + (i % 3) * 2.6, 47.6 + Math.floor(i / 3) * 3, 15.75, 1.8, 1.8, 0.3, i === 8 ? '#4fc86a' : '#3a3d44', { r: 0.6, noOut: 1 })));
      o.push(cyl(14.6, 56.6, 15.6, 1.6, 0.4, '#9aa3a8', mt({ n: 12 })));
      return o; },
    fx: c => { const p = c.p; let f = '<g transform="' + plane(p, 15.95, 62, -18) + '"><rect width="22" height="15" rx="1.4" fill="url(#mwin)">' + anS('opacity', '0.75;1;0.75', 2) + '</rect><g transform="translate(11 9.6)"><ellipse rx="6.5" ry="1.4" fill="#ffffff" opacity="0.35"/><g>' + atS('scale', '1 1;0.55 1;1 1', 2.6) + '<path d="M-3.2 0L-2.6 -5.2Q0 -6.4 2.6 -5.2L3.2 0Z" fill="#f4ecd8" stroke="#c8b48a" stroke-width="0.3"/><rect x="-2.4" y="-3.6" width="4.8" height="1.4" fill="#d9363b"/></g></g><rect width="22" height="15" rx="1.4" fill="url(#p3glass)" opacity="0.6"/></g>';
      f += '<g transform="' + plane(p, 15.9, 62.6, 10.6) + '"><text x="4" y="2.6" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="2.6" fill="#7fe8a0">1:30' + anD('opacity', '1;0.4', 1) + '</text></g>';
      let v = ''; rep(6, i => v += '<path d="M' + (3 + i * 3.6) + ' 3V14" stroke="#8a9096" stroke-width="0.7"/>'); f += '<g transform="' + planeX(p, 22.1, 64, -10) + '">' + v + '</g>';
      return { defs: PATS + '<radialGradient id="mwin" cx="50%" cy="55%" r="70%"><stop offset="0" stop-color="#ffe6a0"/><stop offset="0.7" stop-color="#e8a84a"/><stop offset="1" stop-color="#5a3a14"/></radialGradient>', front: f }; } });

  // ---------- surfaces (custom art, drawn in an 80 x 56 frame and fitted to the swatch viewBox) ----------
  const px = (u, v) => [14 - 14 * v + (52 + 28 * v) * u, v * 56], PU = (u, v) => P2(px(u, v));
  function concreteFloor() { const R = rng('concrete5'), T = 'M14 0H66L80 56H0Z';
    let s = '<defs><linearGradient id="cf0" x1="0" y1="0" x2="0.3" y2="1"><stop offset="0" stop-color="#aba79f"/><stop offset="1" stop-color="#8f8b84"/></linearGradient><clipPath id="cfc"><path d="' + T + '"/></clipPath>' + BLUR('cfb', 2) + '</defs><g clip-path="url(#cfc)"><path d="' + T + '" fill="url(#cf0)"/>';
    s += '<g filter="url(#cfb)">'; rep(18, i => { const q = px(R(), R()); s += '<ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + f1(4 + R() * 9) + '" ry="' + f1(2 + R() * 4) + '" fill="' + (i % 2 ? '#bdb9b0' : '#7f7b74') + '" opacity="0.35"/>'; }); s += '</g>';
    rep(90, i => { const q = px(R(), R()); s += '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(0.12 + R() * 0.25) + '" fill="' + (i % 3 ? '#6f6b65' : '#d4d0c8') + '" opacity="0.5"/>'; });
    const J = (a, b) => '<path d="M' + a + 'L' + b + '" stroke="#6b675f" stroke-width="0.5"/><path d="M' + a + 'L' + b + '" stroke="#cfcbc2" stroke-width="0.3" transform="translate(0.45 0.35)"/>';
    s += J(PU(1 / 3, 0), PU(1 / 3, 1)) + J(PU(2 / 3, 0), PU(2 / 3, 1)) + J(PU(0, 0.45), PU(1, 0.45));
    let cr = 'M' + PU(0.55, 0.12), u = 0.55, v = 0.12; rep(6, () => { u += (R() - 0.45) * 0.05; v += 0.035 + R() * 0.02; cr += 'L' + PU(u, v); }); s += '<path d="' + cr + '" fill="none" stroke="#5f5b55" stroke-width="0.32" opacity="0.8"/><path d="' + cr + '" fill="none" stroke="#d8d4cc" stroke-width="0.2" transform="translate(0.3 0.25)" opacity="0.6"/>';
    const cable = (pts, col, w) => { let d = 'M' + PU(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length - 1; i++) { const m = [(pts[i][0] + pts[i + 1][0]) / 2, (pts[i][1] + pts[i + 1][1]) / 2]; d += 'Q' + PU(pts[i][0], pts[i][1]) + ' ' + PU(m[0], m[1]); } d += 'L' + PU(pts[pts.length - 1][0], pts[pts.length - 1][1]);
      return '<path d="' + d + '" fill="none" stroke="#000000" stroke-opacity="0.28" stroke-width="' + (w + 0.6) + '" transform="translate(0.4 0.5)" stroke-linecap="round"/><path d="' + d + '" fill="none" stroke="' + col + '" stroke-width="' + w + '" stroke-linecap="round"/><path d="' + d + '" fill="none" stroke="#ffffff" stroke-opacity="0.3" stroke-width="' + f1(w * 0.3) + '" transform="translate(-0.2 -0.25)" stroke-linecap="round"/>'; };
    const tape = (u, v, du, dv) => { const L = Math.hypot(du, dv) || 1, tu = du / L, tv = dv / L, nu = -tv, nv = tu, a = 0.05, b = 0.022, C = [[u + nu * a - tu * b, v + nv * a * 1.4 - tv * b], [u + nu * a + tu * b, v + nv * a * 1.4 + tv * b], [u - nu * a + tu * b, v - nv * a * 1.4 + tv * b], [u - nu * a - tu * b, v - nv * a * 1.4 - tv * b]];
      return '<path d="M' + C.map(q => PU(q[0], q[1])).join('L') + 'Z" fill="#c3c6c9" stroke="#8f9297" stroke-width="0.25" opacity="0.95"/><path d="M' + PU((C[0][0] + C[1][0]) / 2, (C[0][1] + C[1][1]) / 2) + 'L' + PU((C[2][0] + C[3][0]) / 2, (C[2][1] + C[3][1]) / 2) + '" stroke="#e4e6e8" stroke-width="0.3" opacity="0.8"/>'; };
    const c1 = [[0.08, -0.05], [0.1, 0.35], [0.12, 0.62], [0.22, 0.78], [0.5, 0.82], [1.05, 0.84]], c2 = [[0.7, -0.05], [0.74, 0.3], [0.78, 0.55], [0.9, 0.62], [1.05, 0.64]];
    s += cable(c1, '#1e1f22', 1.15) + cable(c2, '#e8742a', 0.95);
    [[0.1, 0.18, 0.02, 1], [0.12, 0.52, 0.02, 1], [0.36, 0.81, 1, 0.05], [0.74, 0.83, 1, 0.02], [0.745, 0.15, 0.04, 1], [0.86, 0.61, 1, 0.2]].forEach(([u, v, du, dv]) => s += tape(u, v, du, dv));
    return s + '</g>'; }
  function obsidianWall() { const R = rng('obsidian'); let s = '<defs><linearGradient id="og0" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1d1b24"/><stop offset="1" stop-color="#0c0b10"/></linearGradient><pattern id="ofab" width="1.6" height="1.6" patternUnits="userSpaceOnUse"><circle cx="0.4" cy="0.4" r="0.22" fill="#ffffff" fill-opacity="0.035"/><circle cx="1.2" cy="1.2" r="0.22" fill="#000000" fill-opacity="0.3"/></pattern><linearGradient id="osh" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="1"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>';
    s += '<rect width="80" height="56" fill="#08070b"/>';
    for (let j = 0; j < 4; j++) for (let i = 0; i < 5; i++) { const x = i * 16 + 0.5, y = j * 14 + 0.5, w = 15, h = 13; s += '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="0.9" fill="url(#og0)"/><path d="M' + (x + 0.5) + ' ' + (y + h - 0.6) + 'V' + (y + 0.5) + 'H' + (x + w - 0.6) + '" fill="none" stroke="#3a3842" stroke-width="0.45"/><path d="M' + (x + 0.6) + ' ' + (y + h - 0.4) + 'H' + (x + w - 0.4) + 'V' + (y + 0.6) + '" fill="none" stroke="#020203" stroke-width="0.55"/>';
      const a = R() * 0.8 - 0.4, gx = x + 2 + R() * 9; s += '<path d="M' + f1(gx) + ' ' + (y + 1) + 'L' + f1(gx + 3) + ' ' + (y + 1) + 'L' + f1(gx + 3 + h * a) + ' ' + (y + h - 1) + 'L' + f1(gx + h * a) + ' ' + (y + h - 1) + 'Z" fill="#ffffff" opacity="' + f1(0.012 + R() * 0.022) + '"/>'; }
    s += '<rect width="80" height="56" fill="url(#ofab)"/>';
    rep(78, i => { const x = R() * 80, y = R() * 56, r = 0.16 + R() * 0.3, col = ['#ffffff', '#d6e8ff', '#fff2d6', '#cfe0ff'][i % 4], d = (1.6 + R() * 2.8).toFixed(2), b = -(R() * 4); if (r > 0.38) s += '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(r * 3) + '" fill="' + col + '" opacity="0.15">' + an('opacity', '0.04;0.22;0.04', d, b) + '</circle>'; s += '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(r) + '" fill="' + col + '">' + an('opacity', '0.25;1;0.25', d, b) + '</circle>'; });
    s += '<g opacity="0"><rect x="-6" y="-0.3" width="12" height="0.6" rx="0.3" fill="url(#osh)" transform="translate(14 8) rotate(24)"/>' + an('opacity', '0;0;1;0;0', 9, 0, '0;0.78;0.82;0.88;1') + at('translate', '0 0;0 0;14 7;24 12;24 12', 9) + '</g>';
    return s; }
  function trackLight() { let s = '<defs><linearGradient id="tcone" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff3cf" stop-opacity="0.75"/><stop offset="1" stop-color="#fff3cf" stop-opacity="0"/></linearGradient><linearGradient id="tcan" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#4a4d55"/><stop offset="0.35" stop-color="#2a2c32"/><stop offset="1" stop-color="#121316"/></linearGradient><radialGradient id="tlens" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#ffd98a"/></radialGradient></defs>';
    [14, 66].forEach(x => s += '<path d="M' + x + ' 0V8" stroke="#6a6d75" stroke-width="0.6"/><rect x="' + (x - 2) + '" y="-0.2" width="4" height="1.4" rx="0.4" fill="#2a2c32"/>');
    s += '<path d="M8 9L11 7.3H75L72 9Z" fill="#3a3c42" stroke="#121316" stroke-width="0.3"/><rect x="8" y="9" width="64" height="3.6" fill="#1d1e22" stroke="#0a0a0c" stroke-width="0.3"/><path d="M8.4 9.3H71.6" stroke="#6a6d75" stroke-width="0.35"/><path d="M72 9L75 7.3V10.9L72 12.6Z" fill="#141518"/>';
    [[18, -16], [33, 8], [48, -8], [63, 15]].forEach(([x, a], i) => { const b = -(i * 1.4);
      s += '<rect x="' + (x - 1.6) + '" y="12.6" width="3.2" height="2" fill="#2a2b30"/><g transform="rotate(' + a + ' ' + x + ' 19)"><path d="M' + (x - 2.4) + ' 26.4L' + (x - 12) + ' 60H' + (x + 12) + 'L' + (x + 2.4) + ' 26.4Z" fill="url(#tcone)">' + anS('opacity', '0.15;0.7;0.15', 6.4, b) + '</path>'
        + '<path d="M' + (x - 4.4) + ' 14.6V20M' + (x + 4.4) + ' 14.6V20M' + (x - 4.4) + ' 14.6H' + (x + 4.4) + '" fill="none" stroke="#2a2b30" stroke-width="1.1" stroke-linecap="round"/><rect x="' + (x - 3.6) + '" y="15.6" width="7.2" height="10.5" rx="1.6" fill="url(#tcan)" stroke="#0a0a0c" stroke-width="0.3"/>'
        + [16.8, 17.9, 19, 20.1].map(y => '<path d="M' + (x - 3.2) + ' ' + y + 'H' + (x + 3.2) + '" stroke="#5a5d64" stroke-width="0.35"/>').join('') + '<circle cx="' + (x - 4.4) + '" cy="19.6" r="0.7" fill="#6a6d75"/><circle cx="' + (x + 4.4) + '" cy="19.6" r="0.7" fill="#6a6d75"/>'
        + '<ellipse cx="' + x + '" cy="26.1" rx="3.7" ry="1.25" fill="#0e0f12" stroke="#6a6d75" stroke-width="0.35"/><ellipse cx="' + x + '" cy="26.1" rx="2.7" ry="0.9" fill="url(#tlens)">' + anS('opacity', '0.35;1;0.35', 6.4, b) + '</ellipse></g>'; });
    s += '<circle cx="74" cy="10.8" r="0.5" fill="#ffd66b">' + anS('opacity', '0.3;1;0.3', 6.4) + '</circle>';
    return s; }
  function auroraHalo() { const cx = 40, cy = 17, rx = 27, ry = 7, CS = ['#5effb0', '#4fe0d0', '#8f7bff', '#ff6ad5', '#6ac8ff', '#5effb0'], pt2 = a => [cx + rx * Math.cos(a), cy + ry * Math.sin(a)];
    let s = '<defs>' + BLUR('ab', 1.2) + rep(5, i => '<linearGradient id="au' + i + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + CS[i] + '" stop-opacity="0.85">' + an('stop-color', CS.slice(i).concat(CS.slice(0, i + 1)).join(';'), 9, -i) + '</stop><stop offset="0.55" stop-color="' + CS[i + 1] + '" stop-opacity="0.35">' + an('stop-color', CS.slice(i + 1).concat(CS.slice(0, i + 2)).join(';'), 9, -i) + '</stop><stop offset="1" stop-color="' + CS[i + 1] + '" stop-opacity="0"/></linearGradient>').join('') + '<pattern id="aur" width="1.6" height="30" patternUnits="userSpaceOnUse"><rect width="0.5" height="30" fill="#ffffff" opacity="0.22"/></pattern></defs>';
    [[22, 0, 17, 15], [58, 0, 63, 15], [40, 0, 40, 10]].forEach(([a, b, c, d]) => s += '<path d="M' + a + ' ' + b + 'L' + c + ' ' + d + '" stroke="#9aa3a8" stroke-width="0.35"/>');
    const rib = (a0, a1, h, i, front) => { const fr = ph => { const top = rep(9, k => pt2(a0 + (a1 - a0) * k / 8)), bot = top.map(([x, y], k) => [x + Math.sin(k * 0.8 + ph) * 2.4, y + h * (0.75 + 0.25 * Math.sin(k * 1.1 + ph * 1.3))]); return 'M' + top.map(P2).join('L') + 'L' + bot.reverse().map(P2).join('L') + 'Z'; };
      const v = [0, 1.6, 3.2, 0].map(fr).join(';'); return '<path d="' + fr(0) + '" fill="url(#au' + i + ')" opacity="' + (front ? 0.75 : 0.55) + '">' + anS('d', v, 6 + i * 0.7, -i) + '</path><path d="' + fr(0) + '" fill="url(#aur)" opacity="0.35">' + anS('d', v, 6 + i * 0.7, -i) + '</path>'; };
    s += rib(PI * 1.05, PI * 1.6, 20, 0) + rib(PI * 1.45, PI * 1.95, 24, 1);
    s += '<path d="M' + P2(pt2(PI)) + 'A' + rx + ' ' + ry + ' 0 0 1 ' + P2(pt2(0)) + '" fill="none" stroke="#7d858e" stroke-width="2"/><path d="M' + P2(pt2(PI)) + 'A' + rx + ' ' + ry + ' 0 0 1 ' + P2(pt2(0)) + '" fill="none" stroke="#e8fdff" stroke-width="0.7" stroke-dasharray="3 2" filter="url(#ab)">' + an('stroke-dashoffset', '0;-30', 2.4) + an('opacity', '0.5;1;0.6;0.95;0.45;1;0.5', 1.4) + '</path>';
    s += rib(PI * 0.02, PI * 0.5, 26, 2, 1) + rib(PI * 0.45, PI * 0.98, 23, 3, 1) + rib(PI * 0.25, PI * 0.75, 30, 4, 1);
    s += '<path d="M' + P2(pt2(0)) + 'A' + rx + ' ' + ry + ' 0 0 1 ' + P2(pt2(PI)) + '" fill="none" stroke="#c9d0d6" stroke-width="2.2"/><path d="M' + P2(pt2(0)) + 'A' + rx + ' ' + ry + ' 0 0 1 ' + P2(pt2(PI)) + '" fill="none" stroke="#ffffff" stroke-width="0.5" transform="translate(0 -0.7)" opacity="0.8"/><path d="M' + P2(pt2(0)) + 'A' + rx + ' ' + ry + ' 0 0 1 ' + P2(pt2(PI)) + '" fill="none" stroke="#5effb0" stroke-width="0.8" stroke-dasharray="2 1.6" transform="translate(0 0.9)" filter="url(#ab)">' + an('stroke', CS.join(';'), 8) + an('stroke-dashoffset', '0;30', 2) + an('opacity', '0.6;1;0.5;1;0.7;0.6', 1.1) + '</path>';
    rep(8, i => s += '<circle cx="' + f1(16 + i * 6.6) + '" cy="' + f1(28 + (i % 3) * 6) + '" r="0.45" fill="#ffffff">' + an('opacity', '0;1;0', 2 + (i % 3) * 0.5, -i * 0.4) + '</circle>');
    return s; }
  // Dance Room black surfaces, drawn in the same 80 x 56 swatch frame (and floor perspective) as every other wall / floor
  const NEO = ['#ff3fb4', '#a64dff', '#3f8cff', '#2fe0ff', '#3fff9a', '#ffe23f', '#ff8a2f'];
  function blackWall() { let s = '<defs><linearGradient id="bw0" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1c1c21"/><stop offset="1" stop-color="#0b0b0d"/></linearGradient><pattern id="bwt" width="1.4" height="1.4" patternUnits="userSpaceOnUse"><circle cx="0.35" cy="0.35" r="0.2" fill="#ffffff" fill-opacity="0.03"/><circle cx="1.05" cy="1.05" r="0.2" fill="#000000" fill-opacity="0.35"/></pattern><linearGradient id="bwsh" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient><clipPath id="bwc"><rect width="80" height="56" rx="4"/></clipPath></defs><g clip-path="url(#bwc)"><rect width="80" height="56" fill="url(#bw0)"/>';
    for (let i = 0; i < 6; i++) { const x = i * 80 / 6; s += '<rect x="' + f1(x + 0.4) + '" y="0.4" width="' + f1(80 / 6 - 0.8) + '" height="51" rx="0.5" fill="url(#bwsh)"/><path d="M' + f1(x) + ' 0V52" stroke="#000000" stroke-width="0.7"/><path d="M' + f1(x + 0.5) + ' 0V52" stroke="#2c2c33" stroke-width="0.25"/>'; }
    return s + '<rect width="80" height="56" fill="url(#bwt)"/><rect y="52" width="80" height="4" fill="#050506"/><path d="M0 52H80" stroke="#30303a" stroke-width="0.4"/></g>'; }
  // the test room shows x 15..65 of the swatch (bg 160% wide, centred) and hides ~3 units under the wall trim;
  // 1 unit = 17 room px across, 4.5 room px down. LED area = inner trapezoid on the same perspective slope, 10 room px in from the visible edges.
  function blackLedFloor() { const T = 'M14 0H66L80 56H0Z', C = 12, R = 6, Y0 = 5.4, Y1 = 53.8, XB = 15.6, SL = 0.25;
    const q = (u, v) => { const y = Y0 + (Y1 - Y0) * v, L = XB + (Y1 - y) * SL, Rr = 80 - L; return f1(L + (Rr - L) * u) + ' ' + f1(y); };
    const quad = (a, b, c, d) => 'M' + q(a, b) + 'L' + q(c, b) + 'L' + q(c, d) + 'L' + q(a, d) + 'Z';
    let s = '<defs>' + BLUR('blf', 1.2) + '<clipPath id="blc"><path d="' + T + '"/></clipPath><linearGradient id="bl0" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0d0d10"/><stop offset="1" stop-color="#050506"/></linearGradient><linearGradient id="blsh" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="0.55" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs><g clip-path="url(#blc)"><path d="' + T + '" fill="url(#bl0)"/>';
    let t = ''; for (let j = 0; j < R; j++) for (let i = 0; i < C; i++) { const k = (i + j * 2) % NEO.length, seq = rep(NEO.length, m => NEO[(k + m) % NEO.length]).concat(NEO[k]).join(';'), b = -((i + j) * 0.18).toFixed(2), gu = 0.09 / C, gv = 0.1 / R;
      t += '<path d="' + quad(i / C + gu, j / R + gv, (i + 1) / C - gu, (j + 1) / R - gv) + '" fill="' + NEO[k] + '">' + an('fill', seq, 5.6, b) + an('opacity', '1;0.3;1', 1.4, (b * 0.5).toFixed(2)) + '</path>'; }
    s += '<path d="' + quad(0, 0, 1, 1) + '" fill="#000000"/><g filter="url(#blf)" opacity="0.5">' + t + '</g>' + t + '<path d="' + quad(0, 0, 1, 1) + '" fill="url(#blsh)"/><path d="' + quad(0, 0, 1, 1) + '" fill="none" stroke="#000000" stroke-width="0.35"/>';
    return s + '</g>'; }
  const SURF3 = { concrete: concreteFloor, obsidian: obsidianWall, track: trackLight, aurora: auroraHalo, blackWall, blackLed: blackLedFloor };
  const draw2 = RD.draw;
  RD.draw = (r, o) => { const res = draw2(r, o); if (!res || res._p3) return res; res._p3 = 1;
    try { const f = r.s3 && SURF3[r.s3]; if (f && res.surf && res.vb) { const v = res.vb.split(' ').map(Number), k = Math.min(v[2] / 80, v[3] / 56), tx = v[0] + (v[2] - 80 * k) / 2, ty = v[1] + (v[3] - 56 * k) / 2;
        res.svg = RD.svgDoc(res.vb, [], '<g transform="translate(' + n4(tx) + ' ' + n4(ty) + ') scale(' + n4(k) + ')">' + f() + '</g>'); res.src = 'data:image/svg+xml,' + encodeURIComponent(res.svg); } } catch (e) { console.warn('reno plus3', r.id, e); }
    return res; };

  // ---------- catalog edits ----------
  const LEATHER = [{ n: 'Midnight Black', c: '#2a2a30' }, { n: 'Cognac', c: '#9a4f26' }, { n: 'Oxblood', c: '#6e2a24' }, { n: 'Ivory', c: '#e4dccb' }];
  const BOUC = [{ n: 'Cream Bouclé', c: '#ece5d6' }, { n: 'Oat Bouclé', c: '#d9cbb0' }, { n: 'Sage Bouclé', c: '#b8c4a8' }, { n: 'Taupe Bouclé', c: '#c2b4a4' }];
  RD.SET3 = {
    'MOV-086': { spec: 'qHolo', live: 'Live hologram', note: 'A lens stack and three satellite emitters project a spinning planet and a film-strip ring. The platform rocks on four 4DX motion nodes.' },
    'MOV-098': { spec: 'reelSculpt', live: 'Spinning reels', note: 'Two holographic film reels float and spin above a wall emitter, with film running between them.' },
    'MOV-081': { s3: 'obsidian', live: 'Twinkling stars' },
    'MOV-038': { spec: 'neonShow', live: 'Flickering neon' },
    'MOV-095': { s3: 'aurora', live: 'Live aurora' },
    'MOV-035': { s3: 'track', live: 'Dimming spots' },
    'MOV-090': { spec: 'sphereAudio', live: 'Plasma arcs', note: 'Three glass spheres float over magnetic bases, with plasma arcs crackling inside.' },
    'MOV-093': { spec: 'vipPods', colors: LEATHER, live: 'Motion sync', note: 'Three reclining leather pods on motion actuators, with lit consoles and cup holders between them.' },
    'MOV-077': { spec: 'vault' }, 'MOV-068': { spec: 'awardSet' }, 'MOV-063': { spec: 'smartConsole', live: 'Chilled' }, 'MOV-087': { spec: 'robButler', live: 'Rolls around' }, 'MOV-011': { spec: 'microClean' }, 'MOV-005': { s3: 'concrete' },
    'LIV-107': { spec: 'chester', sx: { n: 3, wood: '#4a2c1a' } }, 'LIV-110': { spec: 'chester', sx: { n: 4, gold: 1 } }, 'LIV-108': { spec: 'chester', sx: { n: 3, leather: 1, wood: '#3a2416' } },
    'LIV-109': { spec: 'chester', sx: { n: 3, st: 'channel', boucle: 1, plinth: '#f2efea', pil: '#c9a35a' } }, 'LIV-066': { spec: 'cloudPit', sx: { n: 5 }, colors: BOUC },
    'LIV-067': { spec: 'library' }, 'LIV-047': { spec: 'archBook' }, 'LIV-075': { spec: 'coneHearth' }, 'LIV-070': { spec: 'shearChair', sx: {} },
    'LIV-087': { spec: 'archiveWall', live: 'Robot arm' }, 'LIV-088': { spec: 'chrono', live: 'Levitating' }, 'LIV-048': { spec: 'artBooks' },
  };
  const edit2 = RD.edit;
  const ADD3 = [[113, 1, 'Wall Surface', 'Matte Black Club Walls', 'blackWall', 'A deep matte black wall that makes every light in the room pop.'], [114, 2, 'Floor Surface', 'Black LED Light-Up Dance Floor', 'blackLed', 'A black floor with a light-up LED tile grid set 10 px in from every edge. The tiles cycle through neon colours in a wave.']];
  RD.edit = rows => { const R = edit2(rows).map(r => RD.SET3[r.id] ? Object.assign({}, r, RD.SET3[r.id]) : r);
    ADD3.forEach(([num, slot, slotName, name, s3, note]) => { const b = rows.find(r => r.room === 'CLB' && r.tier === 3 && r.slot === slot); if (b) R.push(Object.assign({}, b, { id: 'CLB-' + num, slotName, name, s3, note, add: 1 }, s3 === 'blackLed' ? { live: 'Live LED' } : {})); });
    return R; };
  Object.assign(RD, { PLUS3: 1, H3: { rep, rng, n4, P2, mtx, plane, planeX, planeH, kOf, an, anS, at, atS, BLUR, bbOf, tex, PATS, mt, wd, cer, fb, pt, throwP, seatC } });
})();
