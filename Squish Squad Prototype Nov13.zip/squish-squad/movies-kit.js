// Movie kit: shared building blocks for the tier 2-5 movies (movies.js owns the list, look and record).
// A movie = shots [{a, b, mk(L) -> upd(lt, t)}] on a 320 x 180 stage; everything is a pure function of time.
(function () {
  if (window.MK) return;
  if (!document.querySelector('link[data-mk-font]')) { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'https://fonts.googleapis.com/css2?family=Creepster&family=Fredoka:wght@500;600;700&display=swap'; l.setAttribute('data-mk-font', '1'); document.head.appendChild(l); }
  const cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v)), lerp = (a, b, u) => a + (b - a) * u;
  const E = { lin: x => x, in: x => x * x, out: x => 1 - Math.pow(1 - x, 3), io: x => x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2, back: x => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); } };
  const P = (t, a, b, e = E.out) => e(cl((t - a) / (b - a)));
  const kf = (t, K, e = E.io) => { if (t <= K[0][0]) return K[0][1]; for (let i = 1; i < K.length; i++) if (t <= K[i][0]) { const a = K[i - 1], b = K[i]; return lerp(a[1], b[1], e((t - a[0]) / ((b[0] - a[0]) || 1))); } return K[K.length - 1][1]; };
  const win = (t, a, b, f = 0.3) => cl(Math.min((t - a) / f, (b - t) / f));
  function el(tag, css, p, html) { const n = document.createElement(tag); if (css) n.style.cssText = css; if (html != null) n.innerHTML = html; if (p) p.appendChild(n); return n; }
  const D = (p, css, html) => el('div', 'position:absolute;' + css, p, html);
  const show = (n, on) => { const d = on ? 'block' : 'none'; if (n.style.display !== d) n.style.display = d; };
  const put = (n, x, y, k = 1, r = 0, o = 1) => { if (o <= 0.002) { show(n, false); return; } show(n, true); n.style.opacity = o.toFixed(3); n.style.transform = 'translate(' + x.toFixed(2) + 'px,' + y.toFixed(2) + 'px) translate(-50%,-50%) rotate(' + r.toFixed(2) + 'deg) scale(' + k.toFixed(3) + ')'; };
  const rnd = s => () => { s |= 0; s = (s + 0x6D2B79F5) | 0; let x = Math.imul(s ^ (s >>> 15), 1 | s); x = (x + Math.imul(x ^ (x >>> 7), 61 | x)) ^ x; return ((x ^ (x >>> 14)) >>> 0) / 4294967296; };
  const art = (k, v) => 'export/tripo/' + k + '/' + k + '-' + v + '.svg';
  const SPIN = ['front', 'right', 'back', 'left'];

  // actor: creature art + ground shadow. pose s = {x, y (feet), v, r, sx, sy, k, o, f (filter), gy (shadow y), sh:false}
  function actor(p, k, w = 58) { const sd = D(p, 'left:0;top:0;width:' + (w * 0.72) + 'px;height:' + (w * 0.12) + 'px;border-radius:50%;background:rgba(10,8,30,0.3);display:none;');
    const n = el('img', 'position:absolute;left:0;top:0;width:' + w + 'px;height:' + w + 'px;transform-origin:50% 94%;display:none;', p); n.alt = ''; n.draggable = false; n._k = k; n._w = w; n._v = ''; n._sd = sd;
    SPIN.forEach(v => { const i = new Image(); i.src = art(k, v); }); return n; }
  function pose(n, s) {
    if (!s) { show(n, false); show(n._sd, false); return; }
    const v = s.v || 'front'; if (n._v !== v) { n._v = v; n.src = art(n._k, v); } const w = n._w, k = s.k || 1, ra = Math.min(90, Math.abs(s.r || 0)) * Math.PI / 180, ly = Math.pow(Math.sin(ra), 2) * w * 0.4 * k;
    show(n, true); n.style.opacity = s.o == null ? '1' : s.o.toFixed(3); n.style.filter = s.f || '';
    n.style.transform = 'translate(' + (s.x - w / 2).toFixed(2) + 'px,' + (s.y - ly - w * 0.94).toFixed(2) + 'px) rotate(' + (s.r || 0).toFixed(2) + 'deg) scale(' + ((s.sx || 1) * k).toFixed(3) + ',' + ((s.sy || 1) * k).toFixed(3) + ')';
    if (s.sh === false) { show(n._sd, false); return; } const gy = s.gy == null ? s.y : s.gy, q = 1 - cl((gy - s.y) / 50) * 0.6; put(n._sd, s.x, gy + 1, k * q, 0, (s.o == null ? 1 : s.o) * 0.9 * q); }
  // path through keys [[t, x, y, {m, v, h, r, k, o}]]: m = walk | run | hop | float | still. Returns a pose (or null before the first key / after O.gone).
  function go(t, K, O = {}) {
    if (t < K[0][0] || (O.gone != null && t >= O.gone)) return null; let i = 0; while (i < K.length - 1 && t >= K[i + 1][0]) i++;
    const A = K[i], B = K[i + 1] || A, o = Object.assign({}, O, A[3] || {}), u = B === A ? 1 : cl((t - A[0]) / (B[0] - A[0])), m = o.m || 'walk';
    const ya = A[2] == null ? (O.y ?? 150) : A[2], yb = B[2] == null ? (O.y ?? 150) : B[2], mv = Math.abs(B[1] - A[1]) > 1 && u < 1, dir = B[1] > A[1] ? 1 : -1;
    const e = m === 'walk' || m === 'run' ? u : E.io(u); let x = lerp(A[1], B[1], e), y = lerp(ya, yb, e), r = o.r || 0, sx = 1, sy = 1;
    const v = o.v || (mv && m !== 'still' ? (dir > 0 ? 'right' : 'left') : (O.f || 'front')), ph = t * (m === 'run' ? 19 : 10) + (O.ph || 0);
    if (mv && m === 'walk') { y -= Math.abs(Math.sin(ph)) * 2.4; r += Math.sin(ph) * 3; }
    else if (mv && m === 'run') { y -= Math.abs(Math.sin(ph)) * 5; r += dir * 8 + Math.sin(ph) * 2; }
    else if (m === 'hop' && B !== A) { const h = o.h || 14; y -= Math.sin(Math.PI * u) * h; const q = u < 0.12 ? 1 - u / 0.12 : u > 0.88 ? (u - 0.88) / 0.12 : 0; sx = 1 + 0.08 * q; sy = 1 - 0.1 * q; }
    if (m === 'float') { y += Math.sin(t * 2.4 + (O.ph || 0)) * 3; r += Math.sin(t * 1.7 + (O.ph || 0)) * 3 + (mv ? dir * 6 : 0); }
    else if (!mv) { const b = Math.sin(t * 3 + (O.ph || 0)); sy = sy * (1 + 0.014 * b); sx = sx * (1 - 0.01 * b); }
    return { x, y, v, r, sx, sy, k: o.k, o: o.o, gy: m === 'float' || m === 'hop' ? (o.gy ?? (O.gy ?? Math.max(ya, yb))) : undefined }; }
  // dance moves on a beat B: bounce, sway, spin, shuffle, twirl, jump, wave
  function dance(t, x, y, st, B = 0.5, ph = 0) { const b = (t / B) + ph, n = Math.floor(b), f = b - n, hp = Math.sin(Math.PI * f), sq = Math.exp(-f * 8), s = n % 2 ? 1 : -1;
    switch (st) {
      case 'sway': return { x: x + Math.sin(b * Math.PI / 2) * 6, y: y - hp * 2, v: 'front', r: Math.sin(b * Math.PI / 2) * 10, sx: 1 + 0.05 * sq, sy: 1 - 0.05 * sq };
      case 'spin': return { x, y: y - hp * 10, v: SPIN[n % 4], r: 0, sx: 1 + 0.06 * sq, sy: 1 - 0.07 * sq };
      case 'shuffle': { const q = Math.floor(n / 2) % 2 ? 1 : -1; return { x: x + q * 10 * Math.sin(Math.PI * ((b / 2) % 1)), y: y - hp * 3, v: q > 0 ? 'right' : 'left', r: q * 5 }; }
      case 'twirl': return { x, y: y - hp * 4, v: SPIN[Math.floor(b * 2) % 4], r: Math.sin(b * Math.PI) * 6 };
      case 'jump': return { x, y: y - (n % 2 ? hp * 20 : hp * 4), v: 'front', r: n % 2 ? s * 10 * hp : 0, sx: 1 + 0.1 * sq, sy: 1 - 0.12 * sq };
      case 'wave': return { x: x + Math.sin(b * Math.PI) * 3, y: y - Math.abs(Math.sin(b * Math.PI)) * 6, v: 'front', r: Math.sin(b * Math.PI) * 14 };
      default: return { x, y: y - hp * 8, v: 'front', r: s * 4 * hp, sx: 1 + 0.08 * sq, sy: 1 - 0.09 * sq }; } }
  // speech bubble: fn(text, x, y, o) (x, y = tail tip)
  function bub(p, z = 30) { const b = D(p, "left:0;top:0;display:none;max-width:168px;padding:4px 8px;border-radius:10px;background:#fffdf6;border:1.5px solid #2a1d3a;font-family:'Fredoka',sans-serif;font-weight:600;font-size:9.5px;line-height:1.2;color:#2a1d3a;text-align:center;white-space:nowrap;z-index:" + z + ";transform-origin:50% 100%;");
    const tl = D(b, 'left:50%;bottom:-6px;width:8px;height:8px;margin-left:-4px;background:#fffdf6;border-right:1.5px solid #2a1d3a;border-bottom:1.5px solid #2a1d3a;transform:rotate(45deg);');
    let cur = null; return (tx, x, y, o = 1) => { if (!tx || o <= 0.01) { show(b, false); return; } if (cur !== tx) { cur = tx; b.style.whiteSpace = tx.length > 30 ? 'normal' : 'nowrap'; b.style.width = tx.length > 30 ? '150px' : ''; b.firstChild.nodeType === 3 ? (b.firstChild.nodeValue = tx) : b.insertBefore(document.createTextNode(tx), tl); } show(b, true);
      const w = b.offsetWidth || 60, h = b.offsetHeight || 18, xx = cl(x, w / 2 + 4, 316 - w / 2); tl.style.left = (50 + (x - xx) / w * 100) + '%';
      b.style.opacity = o.toFixed(3); b.style.transform = 'translate(' + (xx - w / 2).toFixed(1) + 'px,' + (y - h - 7).toFixed(1) + 'px) scale(' + (0.6 + 0.4 * Math.min(1, o * 1.6)).toFixed(3) + ')'; }; }
  // timed lines: [[t0, t1, text, who]] -> who(t) gives the speaker's pose
  const lines = (fn, t, L, at) => { const q = L.find(l => t >= l[0] && t < l[1]); if (!q) { fn(null); return; } const p = at[q[3]] || [160, 60]; fn(q[2], p[0], p[1], win(t, q[0], q[1], 0.18)); };
  // particles: n nodes, f(i, t) -> {x, y, k, r, o} | null
  function parts(p, n, css, html, f) { const N = Array.from({ length: n }, () => D(p, 'left:0;top:0;display:none;' + css, html)); return t => N.forEach((m, i) => { const s = f(i, t); if (!s) show(m, false); else put(m, s.x, s.y, s.k || 1, s.r || 0, s.o == null ? 1 : s.o); }); }
  // a field of stars in one node (box-shadow dots), w x h, tiled
  function stars(p, n, w, h, seed, col = '#ffffff', sz = 1.2) { const r = rnd(seed), sh = Array.from({ length: n }, () => (r() * w).toFixed(0) + 'px ' + (r() * h).toFixed(0) + 'px 0 ' + (r() < 0.15 ? sz * 0.6 : 0).toFixed(1) + 'px ' + col).join(',');
    return D(p, 'left:0;top:0;width:' + sz + 'px;height:' + sz + 'px;border-radius:50%;box-shadow:' + sh + ';'); }
  function rain(p, n, seed, col = 'rgba(200,220,255,0.5)') { const r = rnd(seed), q = Array.from({ length: n }, () => [r() * 360, r(), 0.7 + r() * 0.6]);
    return parts(p, n, 'width:1px;height:10px;background:' + col + ';', null, (i, t) => { const [x, o, s] = q[i], y = ((t * 260 * s + o * 220) % 220) - 20; return { x: (x - y * 0.25) % 330, y, r: 14 }; }); }
  const lightning = (t, T) => { let v = 0; T.forEach(a => { const d = t - a; if (d >= 0 && d < 0.6) v = Math.max(v, (d < 0.06 ? 1 : d < 0.12 ? 0.2 : d < 0.18 ? 0.9 : 0) + Math.max(0, 0.5 - d) * 0.6); }); return v; };
  const glow = (p, c, r, css = '') => D(p, 'left:0;top:0;width:' + (2 * r) + 'px;height:' + (2 * r) + 'px;border-radius:50%;background:radial-gradient(circle,' + c + ' 0%,rgba(0,0,0,0) 68%);display:none;pointer-events:none;' + css);
  // the film: shots + a fade through black at shot edges (shot.cut = hard cut)
  function film(S, o = {}) {
    const root = el('div', "position:absolute;left:0;top:0;width:320px;height:180px;overflow:hidden;background:" + (o.bg || '#000') + ";font-family:'Fredoka',sans-serif;font-weight:600;");
    const blk = D(root, 'inset:0;background:#000;opacity:0;z-index:90;pointer-events:none;');
    S.forEach(s => { s.L = null; s.u = null; });
    function upd(t) { let act = null;
      S.forEach(s => { const on = t >= s.a && t < s.b; if (on && !s.L) { s.L = D(root, 'inset:0;overflow:hidden;'); s.u = s.mk(s.L) || (() => {}); } if (s.L) show(s.L, on); if (on) act = s; });
      if (act) { act.u(t - act.a, t); const f = act.fade ?? 0.4, d = Math.min(t - act.a + (act.inF === false ? 9 : 0), act.b - t + (act.outF === false ? 9 : 0)); blk.style.opacity = (f > 0 ? 1 - cl(d / f) : 0).toFixed(3); }
      else blk.style.opacity = '1';
      const r = act && act.lit ? act.lit(t - act.a) : null; return { rgb: (act && act.rgb) || o.rgb || '200,210,255', lit: (r == null ? 0.8 : r) * (1 - +blk.style.opacity) }; }
    return { root, upd }; }

  // ---------- sound kit (writes records into Q) ----------
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
  function snd(Q) { const I = {
    tone: (t, f, d, o) => Q.tone(t, f, d, o), noise: (t, d, o) => Q.noise(t, d, o),
    pluck: (t, m, d = 0.25, v = 0.08) => { Q.tone(t, mtof(m), d, { type: 'triangle', vol: v, at: 0.003 }); Q.tone(t, mtof(m) * 2, d * 0.4, { vol: v * 0.2, at: 0.002 }); },
    piano: (t, m, d = 0.5, v = 0.08) => { Q.tone(t, mtof(m), d, { type: 'triangle', vol: v, at: 0.003 }); Q.tone(t, mtof(m) * 1.003, d * 0.8, { vol: v * 0.5, at: 0.003 }); },
    pad: (t, ms, d, v = 0.03, ty = 'sawtooth', lp = 900) => ms.forEach((m, i) => Q.tone(t, mtof(m) * (1 + (i % 2 ? 0.003 : -0.003)), d, { type: ty, lp, vol: v, at: Math.min(0.6, d * 0.3), sus: 1, vib: [4.5, 1.5] })),
    str: (t, m, d, v = 0.05) => Q.tone(t, mtof(m), d, { type: 'sawtooth', lp: 1700, vol: v, at: Math.min(0.25, d * 0.3), sus: 1, vib: [5.5, mtof(m) * 0.006] }),
    brass: (t, m, d, v = 0.06) => Q.tone(t, mtof(m), d, { type: 'square', lp: 1300, vol: v, at: 0.04, sus: 1, vib: [5, mtof(m) * 0.004] }),
    lead: (t, m, d, v = 0.07) => { Q.tone(t, mtof(m), d, { type: 'square', lp: 2400, vol: v, at: 0.01, sus: 1, vib: [5.5, mtof(m) * 0.005] }); Q.tone(t, mtof(m + 12), d * 0.8, { type: 'triangle', vol: v * 0.3, at: 0.01 }); },
    voice: (t, m, d, v = 0.07) => { Q.tone(t, mtof(m), d, { type: 'triangle', lp: 2000, vol: v, at: 0.04, sus: 1, vib: [5.8, mtof(m) * 0.012] }); Q.tone(t, mtof(m) * 2.01, d, { vol: v * 0.25, at: 0.05, sus: 1 }); },
    theremin: (t, f0, f1, d, v = 0.06) => Q.tone(t, f0, d, { to: f1, slide: d, vol: v, at: 0.15, sus: 1, vib: [6, f0 * 0.02] }),
    bell: (t, m, d = 0.8, v = 0.07) => { Q.tone(t, mtof(m), d, { vol: v }); Q.tone(t, mtof(m) * 2.76, d * 0.4, { vol: v * 0.25 }); },
    bass: (t, m, d = 0.25, v = 0.16) => Q.tone(t, mtof(m), d, { type: 'sawtooth', lp: 480, vol: v, at: 0.008 }),
    sub: (t, m, d = 0.5, v = 0.2) => Q.tone(t, mtof(m), d, { vol: v, at: 0.01 }),
    kick: (t, v = 0.7) => Q.tone(t, 150, 0.3, { to: 42, slide: 0.12, vol: v, at: 0.002 }),
    snare: (t, v = 0.25) => { Q.noise(t, 0.15, { ft: 'bandpass', f: 1800, q: 0.8, vol: v }); Q.tone(t, 220, 0.08, { to: 160, vol: v * 0.5, type: 'triangle' }); },
    hat: (t, v = 0.05) => Q.noise(t, 0.04, { f: 7500, vol: v }),
    clap: (t, v = 0.2) => [0, 0.012, 0.024].forEach(d => Q.noise(t + d, 0.06, { ft: 'bandpass', f: 1400, q: 1.2, vol: v })),
    crash: (t, v = 0.13) => Q.noise(t, 1.4, { f: 4200, vol: v }),
    timp: (t, v = 0.4) => Q.tone(t, 90, 0.9, { to: 70, slide: 0.6, vol: v, at: 0.004 }),
    boom: (t, v = 0.5) => { Q.tone(t, 70, 1.2, { to: 30, slide: 1, vol: v, at: 0.01 }); Q.noise(t, 1, { ft: 'lowpass', f: 600, fTo: 80, vol: v * 0.5 }); },
    thunder: (t, v = 0.35) => { Q.noise(t, 2.2, { ft: 'lowpass', f: 900, fTo: 90, vol: v, at: 0.02 }); Q.noise(t + 0.05, 0.25, { ft: 'bandpass', f: 2400, vol: v * 0.5 }); },
    whoosh: (t, d = 0.5, v = 0.08) => Q.noise(t, d, { ft: 'bandpass', f: 600, fTo: 3000, q: 1.1, vol: v, at: d * 0.45 }),
    poof: (t, v = 0.2) => { Q.noise(t, 0.5, { ft: 'lowpass', f: 3000, fTo: 300, vol: v, at: 0.01 }); Q.tone(t, 300, 0.3, { to: 900, slide: 0.2, vol: v * 0.3, type: 'triangle' }); },
    sparkle: (t, m = 84, v = 0.04) => [0, 4, 7, 12, 16].forEach((d, i) => I.bell(t + i * 0.05, m + d, 0.5, v)),
    zap: (t, v = 0.08) => Q.tone(t, 1800, 0.18, { to: 220, slide: 0.16, type: 'square', lp: 3000, vol: v, at: 0.002 }),
    boing: (t, v = 0.1) => Q.tone(t, 180, 0.4, { to: 520, slide: 0.12, type: 'triangle', vol: v, vib: [14, 40] }),
    pop: (t, v = 0.12) => Q.tone(t, 600, 0.08, { to: 1400, slide: 0.05, vol: v, at: 0.002 }),
    splash: (t, v = 0.2) => { Q.noise(t, 0.6, { ft: 'bandpass', f: 1200, fTo: 400, q: 0.7, vol: v, at: 0.01 }); for (let k = 0; k < 4; k++) Q.tone(t + 0.1 + k * 0.07, 900 + k * 260, 0.06, { to: 1400 + k * 200, slide: 0.05, vol: 0.04 }); },
    hoot: (t, v = 0.08) => { Q.tone(t, 380, 0.3, { to: 330, slide: 0.3, vol: v, at: 0.04 }); Q.tone(t + 0.38, 360, 0.45, { to: 300, slide: 0.4, vol: v, at: 0.04 }); },
    rumble: (t, d, v = 0.1) => Q.noise(t, d, { ft: 'lowpass', f: 220, vol: v, at: d * 0.3, sus: 1 }),
    steam: (t, d = 0.8, v = 0.08) => Q.noise(t, d, { f: 3500, vol: v, at: 0.02 }),
    alarm: (t, n = 4, v = 0.05) => { for (let k = 0; k < n; k++) Q.tone(t + k * 0.5, 880, 0.45, { to: 620, slide: 0.45, type: 'square', lp: 1800, vol: v }); },
    chirp: (t, v = 0.04) => Q.tone(t, 2400, 0.08, { to: 3400, slide: 0.06, vol: v }),
    bee: (t, d, v = 0.025) => Q.tone(t, 220, d, { type: 'sawtooth', lp: 900, vol: v, at: 0.05, sus: 1, vib: [22, 18] }),
    sneeze: t => { Q.tone(t, 500, 0.3, { to: 800, slide: 0.3, type: 'triangle', vol: 0.05, at: 0.1 }); Q.noise(t + 0.55, 0.3, { ft: 'bandpass', f: 2500, fTo: 900, vol: 0.3 }); },
    beat: (t0, t1, B, fn) => { for (let i = 0, t = t0; t < t1 - 0.001; i++, t += B) fn(t, i); },
  }; return I; }
  window.MK = { cl, lerp, E, P, kf, win, el, D, show, put, rnd, art, SPIN, actor, pose, go, dance, bub, lines, parts, stars, rain, lightning, glow, film, snd, mtof };
})();
