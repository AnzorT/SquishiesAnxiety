// Squad House stand idle: every creature's own fidgets while he stands about (breathing + blinking come from the rig idle loop).
// HouseIdle.build(key, list): list entries = beat name, [beat name, arg], or fn(t) on a TL from the rest pose. Each one becomes state hf<i>@key and
// is added to RiveRig.FIDK[key] (+ the shared look / yawn / wave unless X.skip). The rig only uses FIDK when the house sets I.hfid, so other pages keep the old fidgets.
(function boot() {
  const R = window.RiveRig; if (!R || !R.HOUSE || !R.FIDK) { setTimeout(boot, 30); return; } if (R.idleV) return; R.idleV = 1;
  const H = R.HOUSE, { TL, hand, both, SIDE, BEAT, o } = H, REST = R.REST;
  const sp = (t, v, d, hold) => { const b = {}; Object.keys(v).forEach(k => b[k] = REST[k] != null ? REST[k] : 0); t.to((d || 700) * 0.4, v, 'o').wait(hold || 300).to((d || 700) * 0.6, b, 'io'); return t; };
  // standing beats (all end on the rest pose)
  const SB = {
    scratch(t, s) { s = s || 1; const K = SIDE(s); t.to(380, o(hand(s, -6, -26), { [K.arm]: 35, htilt: s * 10, lean: s * 1.2, [K.wink]: 1, tongue: 0.3, [K.foot]: 1.2 }), 'io')
      .osc(1300, 7, { [K.hy]: -30, [K.ear]: 8 }, { [K.hy]: -24, [K.ear]: -2 }, 'l').to(280, o(hand(s, 0, 0), { [K.arm]: 0, [K.wink]: 0, tongue: 0, [K.foot]: 0, htilt: 0, lean: 0, hap: 0.6, smile: 1 }), 'io')
      .osc(500, 3, { htilt: 4 }, { htilt: -4 }, 's'); return t; },
    groom(t) { t.to(380, o(hand(1, 12, -14), { armR: 32, close: 0.6, pitch: -0.08 }), 'io').osc(1100, 5, { tongue: 0.7, hRy: -16 }, { tongue: 0.15, hRy: -13 }, 'l')
      .to(300, o(hand(1, 4, -24), { tongue: 0, close: 0.8, htilt: 7 }), 'io').osc(1000, 3, { hRx: 2, hRy: -26 }, { hRx: -6, hRy: -20 }, 's').to(260, { hap: 0.5, smile: 0.8 }); return t; },
    stretch(t) { t.to(620, { armL: 160, armR: 160, hLy: -4, hRy: -4, sq: -0.1, lift: 1.6, close: 0.85, pitch: 0.3, open: 0.3 }, 'io').wait(350).osc(560, 2, { tilt: 1.6 }, { tilt: -1.6 }, 's')
      .to(420, { armL: 0, armR: 0, hLy: 0, hRy: 0, sq: 0.06, lift: 0, pitch: 0, open: 0, close: 0.3, tilt: 0 }, 'io').to(260, { sq: 0, close: 0, hap: 0.5, smile: 0.8 }, 'o').e('blink2'); return t; },
    hops(t, n) { n = n || 3; t.to(160, { hap: 0.9, smile: 1, open: 0.35 }); for (let i = 0; i < n; i++) t.to(110, { sq: 0.1, lift: 0 }, 'i').to(190, { sq: -0.07, lift: 5, footL: 1.5, footR: 1.5, armL: 30, armR: 30 }, 'o').to(170, { sq: 0, lift: 0, footL: 0, footR: 0, armL: 0, armR: 0 }, 'i'); t.to(140, { sq: 0.06 }, 'o'); return t; },
    twirl(t, d) { d = d || 1; t.to(160, { sq: 0.07, hap: 1, smile: 1, open: 0.3, armL: 40, armR: 40 }, 'io').to(760, { spin: d * 360, lift: 3, sq: -0.05 }, 'io').to(1, { spin: 0 }, 'l').to(170, { lift: 0, sq: 0.07, armL: 0, armR: 0 }, 'i').to(200, { sq: 0 }, 'o').e('blink'); return t; },
    sniff(t) { t.to(420, { pitch: -0.28, ly: 0.9, lean: 0.8, sq: 0.03 }, 'io').osc(1000, 7, { mw: 0.55, sq: 0.05, puff: 0.2 }, { mw: 1, sq: 0.03, puff: 0 }, 'l').to(300, { lx: 0.7, turn: 0.2 }, 'io').osc(700, 5, { mw: 0.55 }, { mw: 1 }, 'l')
      .to(220, { ly: -0.2, pitch: 0.08, lx: 0, turn: 0, wide: 0.5, lean: 0, sq: 0 }, 'o').wait(200).to(240, { wide: 0, hap: 0.6, smile: 0.8 }); return t; },
    shake(t) { t.to(360, { sq: 0.1, close: 0.6, earL: 6, earR: 6 }, 'io').osc(1200, 8, { spin: 24, htilt: -8, sqz: 1 }, { spin: -24, htilt: 8 }, 'io').to(240, { spin: 0, htilt: 0, sqz: 0, close: 0, sq: -0.05, wide: 0.6, earL: 0, earR: 0 }, 'o').to(300, { wide: 0, sq: 0, hap: 1, smile: 1 }); return t; },
    tap(t) { t.to(320, { lx: 0.9, turn: 0.25, htilt: 5, mw: 0.6 }, 'io'); for (let i = 0; i < 4; i++) t.to(130, { footR: 2.4 }, 'o').to(150, { footR: 0, sq: 0.02 }, 'i').to(60, { sq: 0 }); t.to(300, { lx: -0.6, turn: -0.15, htilt: -3 }, 'io').wait(300); return t; },
    ponder(t) { t.to(420, o(hand(1, 10, -12), { armR: 30, ly: -1, lx: 0.5, htilt: 7, mw: 0.5, pitch: 0.12 }), 'io').wait(1100).to(200, { wide: 0.7, open: 0.3, ly: -0.4 }, 'o').to(220, { armR: 90, hRy: -6, hRx: 0 }, 'o').wait(400).to(260, { hap: 1, smile: 1 }); return t; },
    sneeze(t) { t.to(500, { pitch: 0.35, open: 0.45, close: 0.7, sq: -0.06 }, 'io').to(160, { pitch: 0.45, open: 0.6 }).to(90, { pitch: -0.4, open: 0.9, sqz: 1, close: 0, sq: 0.2, lean: 0.4 }, 'o').fx('sneeze', 'nose')
      .to(260, { pitch: 0, open: 0.1, sq: 0, lean: 0 }, 'io').to(240, { sqz: 0, open: 0, blush: 0.7 }).wait(300).to(300, { blush: 0, hap: 0.6, smile: 0.8 }); return t; },
    rub(t) { t.to(380, o(both(6, -18), { armL: 24, armR: 24, close: 1, mw: 0.6 }), 'io').osc(1100, 4, { hLy: -21, hRy: -16 }, { hLy: -16, hRy: -21 }, 's').to(300, o(both(0, 0), { armL: 0, armR: 0 }), 'io').to(160, { close: 0, wide: 0.5 }, 'o').e('blink2').to(260, { wide: 0 }); return t; },
    shimmy(t) { t.to(200, { hap: 1, smile: 1, open: 0.3 }).fx('note', 'head').osc(1600, 4, { x: 1.4, tilt: 4, armL: 60, armR: 10, htilt: 4 }, { x: -1.4, tilt: -4, armL: 10, armR: 60, htilt: -4 }, 's').fx('note', 'head'); return t; },
    clap(t) { t.to(300, o(both(4, -8), { armL: 40, armR: 40, hap: 1, smile: 1, open: 0.35 }), 'io').osc(1100, 5, o(both(13, -9), { sq: 0.02 }), o(both(4, -8), { sq: 0 }), 'o').fx('spark', 'pawR', 3); return t; },
    rock(t) { t.osc(1800, 3, { pitch: 0.12, lift: 0.8, footL: 0.6, footR: 0.6 }, { pitch: -0.08, lift: 0, footL: 0, footR: 0 }, 's').to(220, { smile: 0.8, close: 0.4 }); return t; },
    behind(t, s) { s = s || 1; t.to(500, { spin: s * 120, turn: s * 0.3, lean: -s * 0.8, [SIDE(s).foot]: 1.6 }, 'io').to(200, { [SIDE(s).foot]: 0 }).wait(700).to(160, { wide: 0.6 }).to(520, { spin: 0, turn: 0, lean: 0 }, 'io').to(220, { wide: 0, hap: 0.5, smile: 0.8 }); return t; },
    shy(t) { t.to(420, o(both(10, -14), { armL: 40, armR: 40, blush: 1, sq: 0.05, close: 0.5, htilt: 6 }), 'io').wait(800).to(260, { hLx: 4, ly: 0.4, lx: -0.6, close: 0 }).wait(600).to(220, { hLx: 10 }).wait(300); return t; },
    kiss(t) { t.to(360, o(hand(1, 11, -13), { armR: 30, mw: 0.35, open: 0.12, close: 0.6 }), 'io').wait(300).to(260, o(hand(1, -4, -6), { armR: 80, mw: 1, open: 0.3, hap: 1, smile: 1, winkR: 1 }), 'o').fx('heart', 'mouth', 2).wait(600); return t; },
    peekaboo(t) { t.to(380, o(both(6, -20), { armL: 34, armR: 34, close: 1, sq: 0.04 }), 'io').wait(900).to(180, o(both(-6, -12), { armL: 70, armR: 70, close: 0, wide: 1, open: 0.5, hap: 1, smile: 1, sq: -0.06, lift: 2 }), 'o').wait(500); return t; },
    stomp(t) { [1, -1, 1].forEach(s => { const K = SIDE(s); t.to(240, { [K.foot]: 3.6, tilt: s * 4, lift: 1.4 }, 'o').to(130, { [K.foot]: 0, tilt: 0, lift: 0, sq: 0.1 }, 'i').fx('dust', s < 0 ? 'footL' : 'footR', 3).to(160, { sq: 0 }, 'o'); }); t.to(220, { hap: 0.8, smile: 1 }); return t; },
    flap(t) { t.to(160, { hap: 0.8, smile: 1 }).osc(1100, 6, { armL: 48, armR: 48, lift: 1.2 }, { armL: 6, armR: 6, lift: 0 }, 'o'); return t; },
    bow(t) { t.to(500, { pitch: -0.4, lean: 0.6, close: 0.8, armL: 20, armR: 20, sq: 0.04 }, 'io').wait(500).to(400, { pitch: 0.05, lean: 0, close: 0, armL: 0, armR: 0, sq: 0, hap: 0.8, smile: 1 }, 'io').to(200, { winkR: 1 }).wait(300); return t; },
    curtsy(t) { t.to(500, { sq: 0.1, lift: -1.2, pitch: -0.15, htilt: 6, close: 0.6, smile: 1, armL: 26, armR: 26, footR: 1 }, 'io').wait(500).to(400, { sq: 0, lift: 0, pitch: 0, htilt: 0, close: 0, armL: 0, armR: 0, footR: 0, hap: 0.8 }, 'io').to(200, { winkL: 1 }).wait(300); return t; },
    belly(t) { t.to(400, o(both(6, 6), { armL: 10, armR: 10, close: 0.5, smile: 1 }), 'io').osc(1200, 4, { hLy: 9, hRy: 5, sq: 0.02 }, { hLy: 5, hRy: 9, sq: 0 }, 's').to(200, { hap: 0.7 }); return t; },
    jump(t) { t.to(260, { sq: 0.14, lift: -1, armL: -10, armR: -10 }, 'io').to(260, { sq: -0.12, lift: 10, armL: 150, armR: 150, footL: 2, footR: 2, hap: 1, smile: 1, open: 0.5, wide: 0.6 }, 'o').to(240, { lift: 0, sq: 0.1, armL: 0, armR: 0, footL: 0, footR: 0, wide: 0 }, 'i').fx('spark', 'head', 4).to(220, { sq: 0 }, 'o'); return t; },
  };
  ['look', 'wiggle', 'hum', 'ears', 'wag', 'giggle', 'bounce', 'wave', 'nod'].forEach(n => { if (!SB[n]) SB[n] = BEAT[n]; });
  const FID = R.FIDK, SHARED = ['idle_look', 'idle_yawn', 'idle_waveR'];
  // setState needs a plain (keyless) state of the same name; per-creature hf<i>@key override it
  ['wiggle', 'hum', 'nod', 'ears', 'giggle', 'bounce'].forEach((n, i) => { const t = TL(REST); SB[n](t); t.back(320); R.STATES['hf' + (i + 1)] = t.out({ next: 'idle', blend: 220 }); });
  const W = window.HouseIdle = {
    SB, sp, PROF: {},
    build(key, list, X) { X = X || {}; const S = {}, names = [];
      list.forEach((b, i) => { const t = TL(REST); t.e('blink'); if (typeof b === 'function') b(t); else { const [n, a] = Array.isArray(b) ? b : [b]; (SB[n] || SB.look)(t, a); } t.back(320);
        const nm = 'hf' + (i + 1); S[nm + '@' + key] = t.out({ next: 'idle', blend: 220 }); names.push(nm); });
      R.add(S); R.HS = Object.assign(R.HS || {}, S); FID[key] = names.concat(X.skip ? SHARED.filter(n => !X.skip.includes(n)) : SHARED); W.PROF[key] = list.length; },
  };
  (window.HouseIdleC || []).forEach(f => f(W)); window.HouseIdleC = { push: f => f(W) };
})();
