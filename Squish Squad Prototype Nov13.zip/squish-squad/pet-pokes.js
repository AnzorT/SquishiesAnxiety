// Pet Shop pokes (Nov 9, user: 'now lets move to the poking animations'): every Pet Shop creature reacts to a poke on each of the 14 spots in its own way.
// Every poke follows the natural recipe in four beats:
//   1. contact  - the poked part moves first (head / ear / foot / tail / side), the body follows a beat later, a small overshoot (the rig adds the dent);
//   2. notice   - the eyes go to the spot first, then the head turns / tips to look at it;
//   3. reaction - the creature's own response (see the tables below), built from shared verbs (rub, giggle, hmph, sneeze, lean in, shake ...);
//   4. settle   - everything eases back to the idle pose.
// L / R spots are mirror images (s = -1 left, +1 right as seen on screen). Each creature plays at its own tempo (CARD.T).
// pitch: NEGATIVE = head down, POSITIVE = head up (the rig's convention).
(function boot() {
  const R = window.RiveRig; if (!R || !R.PETLIB || !R.STATES.poke_head) { setTimeout(boot, 25); return; } if (R.pokeV) return; R.pokeV = 1;
  const { TL, S, hand, both, o, NOHANDS, jump, shake, swing, steps, jelly, popcorn, croak, CARD, DESC } = R.PETLIB;
  // body facts that change the contact: ear swing scale (flop ears flare sideways, so they swing less; Ribbit has eye domes, no ears), a real tail
  const BODY = { mittens: { ear: 1, tail: 1 }, biscuit: { ear: 0.45, tail: 1 }, truffle: { ear: 1, tail: 1 }, nibbles: { ear: 0.8 }, quill: { ear: 0.6 },
    waffles: { ear: 1, tail: 1 }, poppy: { ear: 0.8 }, duchess: { ear: 0.9, tail: 1 }, mamapaws: { ear: 0.45 }, ribbit: { ear: 0, noWalk: 1, earTap: [33, 24], lbl: { ear: 'eye dome' } } };

  // ---------- 1. contact: how each spot takes the poke ----------
  const HIT = {
    head(t, s, B) { const e = 10 * B.ear; return t.to(70, { sq: 0.22, pitch: -0.2, sqz: 1, earL: e, earR: e }, 'o').to(150, { sq: -0.08, pitch: 0.08, earL: -e * 0.4, earR: -e * 0.4 }, 'o').to(180, { sq: 0.03, pitch: -0.02, earL: 0, earR: 0, sqz: 0 }, 'io'); },
    ear(t, s, B) { const k = S(s), e = B.ear; return t.to(60, { [k.ear]: -22 * e, [k.wink]: 1, htilt: -s * 7, hyaw: -s * 0.12, sq: 0.04 }, 'o').to(140, { [k.ear]: 12 * e, htilt: -s * 4, sq: 0 }, 'o')
      .to(160, { [k.ear]: -5 * e, htilt: -s * 5 }, 'io').to(160, { [k.ear]: 0, [k.wink]: 0 }, 'io'); },
    nose(t) { return t.to(70, { pitch: 0.2, sq: 0.06, close: 0.7, mw: 0.85 }, 'o').to(200, { pitch: -0.06, sq: 0, close: 0, cross: 1, ly: 0.6, mw: 1 }, 'io'); },
    eye(t, s) { const k = S(s); return t.to(55, { [k.wink]: 1, pitch: 0.12, hyaw: -s * 0.15, htilt: -s * 4, sq: 0.06 }, 'o').to(220, { pitch: 0.04, hyaw: -s * 0.08, sq: 0 }, 'io'); },
    cheek(t, s) { const k = S(s); return t.to(80, { htilt: -s * 8, hyaw: -s * 0.1, [k.wink]: 0.7, sq: 0.04, puff: 0.3 }, 'o').to(220, { htilt: -s * 5, sq: 0, puff: 0.1, [k.wink]: 0 }, 'io'); },
    belly(t) { return t.to(80, { sq: 0.16, pitch: -0.2, sqz: 0.8, armL: 14, armR: 14 }, 'o').to(220, { sq: 0.03, pitch: -0.16, sqz: 0, ly: 0.7, armL: 6, armR: 6 }, 'io'); },
    side(t, s) { const d = -s, j = S(-s); return t.to(80, { bend: d * 6, x: d * 1.2, sq: 0.05, wide: 0.6, armL: 30, armR: 30, [j.foot]: 2.5 }, 'o')   // caves in, body bends away, far foot lifts ...
      .to(200, { bend: d * 2, x: d * 3, [j.foot]: 0, armL: 12, armR: 12 }, 'io').to(180, { bend: -d * 1, sq: 0.02, armL: 0, armR: 0 }, 'io'); },                // ... steps out to catch the balance, overshoot
    foot(t, s) { const k = S(s); return t.to(70, { [k.foot]: 5, sq: -0.04, wide: 0.7, bend: s * 2, x: -s * 0.6, armL: 22, armR: 22 }, 'o').to(220, { [k.foot]: 3, sq: 0, bend: s * 1, armL: 10, armR: 10 }, 'io'); },
    tail(t, s, B) { return t.to(70, B.tail ? { curl: 0.9, wag: 28, sq: 0.08, wide: 0.8 } : { sq: 0.08, wide: 0.8 }, 'o').to(240, { lift: 5, sq: -0.08, curl: B.tail ? 0.5 : 0, wag: B.tail ? -12 : 0, armL: 30, armR: 30 }, 'o')
      .to(220, { lift: 0, sq: 0.08, wag: 0, armL: 0, armR: 0 }, 'i').to(150, { sq: 0 }, 'io'); },
  };
  // ---------- 2. notice: eyes first, then the head goes to look at the spot ----------
  const SEE = { head: () => ({ ly: -0.9, pitch: 0.1 }), ear: s => ({ lx: s * 0.8, ly: -0.7, hyaw: s * 0.2, htilt: s * 4 }), cheek: s => ({ lx: s * 0.6, ly: 0.3, hyaw: s * 0.1 }),
    belly: () => ({ ly: 0.9, pitch: -0.25 }), side: s => ({ lx: s * 0.9, ly: 0.5, hyaw: s * 0.3, pitch: -0.1, twist: s * 0.1 }), foot: s => ({ lx: s * 0.5, ly: 1, pitch: -0.3, hyaw: s * 0.15 }),
    tail: () => ({ lx: 0.9, ly: 0.3, hyaw: 0.6, twist: 0.25 }), nose: () => ({ ly: 0.6, cross: 1 }), eye: () => ({}) };
  const see = (t, spot, s, hold) => { const v = SEE[spot](s), ey = {}, hd = {}; for (const p in v) (p === 'lx' || p === 'ly' || p === 'cross' ? ey : hd)[p] = v[p];
    t.to(110, ey, 'o').e('blink').to(320, hd, 'io'); return hold ? t.wait(hold) : t; };
  const unsee = (t, d) => t.to(d || 320, { lx: 0, ly: 0, hyaw: 0, pitch: 0, htilt: 0, twist: 0, cross: 0 }, 'io');

  // ---------- 3. reaction verbs ----------
  const SPOT = { head: s => hand(s, -2, -30), ear: s => hand(s, -6, -31), eye: s => hand(s, 6, -27), cheek: s => hand(s, 2, -18), nose: () => hand(1, 13, -18), side: s => hand(s, -3, -2), mouth: s => hand(s, 13, -15) };
  // rubs the spot with that side's paw: reach (arm swings up as the paw travels), 2-3 slow strokes, back down
  const rub = (t, s, where, n, x) => { s = s || 1; const h = SPOT[where](s), k = S(s); t.to(300, o(h, { [k.arm]: where === 'side' ? 0 : 22 }, x || {}), 'io');
    for (let i = 0; i < (n || 3); i++) t.to(170, { [k.hx]: h[k.hx] + (s < 0 ? 3 : -3), [k.hy]: h[k.hy] - 1.5 }, 'io').to(170, { [k.hx]: h[k.hx], [k.hy]: h[k.hy] }, 'io');
    return t.to(280, { [k.hx]: 0, [k.hy]: 0, [k.arm]: 0, winkL: 0, winkR: 0 }, 'io'); };
  // walks back to where it stood (steps, never a slide)
  const walkBack = (t, dur) => { const a = t.t; t.to(dur || 450, { x: 0, lean: 0 }, 'io'); return para(t, a, u => steps(u, dur || 450, 2, 2.2)); };
  const giggle = (t, n, a) => { a = a || 1; t.to(160, { hap: 1, smile: 1, open: 0.35, sqz: 0, close: 0 }, 'o');
    for (let i = 0; i < (n || 3); i++) t.to(130, { sq: 0.05 * a, armL: 8 * a, armR: 8 * a, htilt: (i % 2 ? 2 : -2) * a }, 'o').to(150, { sq: 0, armL: 0, armR: 0 }, 'io');
    return t.to(200, { open: 0.1, htilt: 0 }, 'io'); };
  const hmph = (t, away) => t.to(250, { frown: 0.55, puff: 0.35, close: 0.35 }, 'io').to(380, { hyaw: away * 0.38, lx: away * 0.6, pitch: 0.12, htilt: -away * 3 }, 'io').wait(500)
    .to(350, { hyaw: 0, lx: 0, pitch: 0, htilt: 0, frown: 0, puff: 0, close: 0 }, 'io');
  const sneeze = (t, a) => { a = a || 1; return t.to(260, { pitch: 0.3 * a, open: 0.4, close: 0.6, sq: -0.06 * a, cross: 0, ly: 0 }, 'io').to(150, { pitch: 0.22 * a, open: 0.3, sq: -0.03 }, 'io')
    .to(240, { pitch: 0.4 * a, open: 0.55, close: 0.85, sq: -0.1 * a }, 'io').to(80, { pitch: -0.3 * a, open: 0.9 * a, sqz: 1, close: 0, sq: 0.2 * a }, 'o').e('emit', 'sneeze', 'nose', Math.round(9 * a))
    .to(260, { pitch: -0.02, open: 0.1, sq: 0 }, 'io').to(220, { sqz: 0, open: 0 }, 'io'); };
  const sniff = (t, n) => t.osc((n || 3) * 240, n || 3, { sq: 0.03, pitch: 0.05, mw: 0.85 }, { sq: 0, pitch: 0, mw: 1 }, 'o');
  const lick = (t, n) => { for (let i = 0; i < (n || 2); i++) t.to(150, { tongue: 1, open: 0.3, pitch: 0.06 }, 'o').to(200, { tongue: 0.15, open: 0.05, pitch: 0 }, 'io'); return t.to(150, { tongue: 0, open: 0 }, 'io'); };
  const wag = (t, dur, a, n) => { const e = t.t + dur * 0; return swing(t, dur, n || Math.max(3, Math.round(dur / 160)), { wag: a || 28 }); };   // sequential (use para() to layer)
  const para = (t, from, fn) => { const e = t.t; t.at(from); fn(t); return t.at(Math.max(e, t.t)); };            // run fn on other channels starting at 'from', then continue at the later end
  const leanIn = (t, s, x) => t.to(320, o({ htilt: s * 10, hyaw: s * 0.12, close: 0.85, hap: 1, smile: 1, blush: 0.6, pitch: -0.05 }, x || {}), 'io')                 // presses its cheek into your finger ...
    .osc(1000, 2, { htilt: s * 12, x: s * 0.6 }, { htilt: s * 7, x: s * 0.2 }, 'io').e('emit', 'heart', 'head', 1).to(300, { htilt: 0, hyaw: 0, x: 0, close: 0 }, 'io'); // ... and rubs against it slowly
  const swat = (t, s, n) => { const k = S(s); for (let i = 0; i < (n || 2); i++) t.to(90, { [k.arm]: 78, [k.hx]: s < 0 ? -4 : 4, [k.hy]: -6, sq: -0.03, frown: 0.4 }, 'o').to(200, { [k.arm]: 10, [k.hx]: 0, [k.hy]: 0, sq: 0 }, 'io'); return t; };
  const pawShake = (t, s, a) => { const k = S(s); a = a || 1; t.to(160, { [k.foot]: 4 * a, bend: s * 1.5 }, 'io'); [1, 0.75, 0.5, 0.25].forEach((m, i) => t.to(110, { [k.foot]: (i % 2 ? 4 : 2) * a + (1 - m), htilt: (i % 2 ? 2 : -2) * m }, 'io'));
    return t.to(220, { [k.foot]: 0, bend: 0, htilt: 0 }, 'i'); };
  const headShake = (t, a, P) => shake(t, { P: P || 95, env: [0.6, 1, 0.8, 0.5, 0.25], head: 0.32 * (a || 1), roll: 4, ear: 12, chest: 0.08 });
  const snort = (t, n) => { for (let i = 0; i < (n || 2); i++) t.to(80, { sq: 0.06, pitch: 0.1, mw: 0.75, close: 0.5 }, 'o').to(170, { sq: 0, pitch: 0, mw: 1, close: 0 }, 'io'); return t; };
  const boof = t => t.to(110, { open: 0.85, mw: 0.85, sq: -0.07, pitch: 0.12, earL: -6, earR: -6 }, 'o').e('emit', 'note', 'head').to(200, { open: 0.15, mw: 1, sq: 0.03, pitch: 0, earL: 0, earR: 0 }, 'io').to(120, { sq: 0, open: 0 }, 'io');
  const wheek = t => t.to(130, { pitch: 0.2, open: 0.65, mw: 0.75, sq: -0.04 }, 'o').e('emit', 'note', 'head').to(220, { pitch: 0.16, open: 0.45 }, 'io').to(180, { pitch: 0, open: 0, mw: 1, sq: 0 }, 'io');
  const freeze = (t, ms) => t.to(70, { wide: 1, sq: 0.05 }, 'o').wait(ms || 500).to(90, { lx: -0.7 }, 'o').wait(260).to(90, { lx: 0.7 }, 'o').wait(260).to(120, { lx: 0, wide: 0.3, sq: 0 }, 'io');
  const curl = (t, hold, tremble) => { t.to(220, o(both(4, 2), { sq: 0.17, pitch: -0.6, close: 1, armL: -10, armR: -10 }), 'o'); if (tremble) t.osc(hold, Math.round(hold / 90), { x: 0.4 }, { x: -0.4 }, 'io').to(60, { x: 0 }); else t.wait(hold);
    return t.to(500, o(NOHANDS, { sq: 0, pitch: 0, close: 0, armL: 0, armR: 0, blush: 0.9, smile: 0.6 }), 'io'); };
  const blushy = (t, away) => t.to(350, o(both(2, -18), { blush: 1, smile: 0.6, hyaw: away * 0.25, lx: away * 0.5, ly: 0.5, pitch: -0.08 }), 'io').wait(700).to(350, o(NOHANDS, { hyaw: 0, lx: 0, ly: 0, pitch: 0 }), 'io');
  const happy = (t, n) => { t.to(180, { hap: 1, smile: 1 }, 'io'); for (let i = 0; i < (n || 2); i++) t.to(150, { sq: 0.08 }, 'io').to(170, { sq: -0.04, lift: 1.5 }, 'o').to(160, { sq: 0, lift: 0 }, 'i'); return t; };
  const pat = (t, n) => { t.to(260, both(9, 0), 'io'); for (let i = 0; i < (n || 3); i++) t.to(140, { hLy: 2, hRy: -1, sq: 0.03 }, 'io').to(140, { hLy: -1, hRy: 2, sq: 0 }, 'io'); return t.to(260, NOHANDS, 'io'); };
  const smooth = (t, s, where) => { const h = SPOT[where](s), k = S(s); return t.to(320, o(h, { [k.arm]: 20, close: 0.5 }), 'io').to(420, { [k.hy]: h[k.hy] + 9, [k.hx]: h[k.hx] + (s < 0 ? -2 : 2) }, 'io').to(300, { [k.hx]: 0, [k.hy]: 0, [k.arm]: 0, close: 0 }, 'io'); };

  // ---------- 4. each creature's reactions, spot by spot (t is just after the contact; s = side) ----------
  const RE = {
    mittens: { // playful kitten
      head: (t, s) => { see(t, 'head', s, 150); rub(t, 1, 'head', 3, { frown: 0.4, puff: 0.3 }); t.to(200, { frown: 0, puff: 0, smile: 0.5 }, 'io'); },
      ear: (t, s) => { headShake(t); giggle(t, 2); },
      nose: (t, s) => { t.wait(350); sneeze(t); rub(t, 1, 'nose', 2); },
      eye: (t, s) => { rub(t, s, 'eye', 3); t.e('blink2').to(250, { frown: 0.35 }, 'io'); },
      cheek: (t, s) => { leanIn(t, s); },
      belly: (t, s) => { giggle(t, 2, 1.3); swat(t, -1, 1); swat(t, 1, 1); giggle(t, 2); },
      side: (t, s) => { see(t, 'side', s, 200); rub(t, s, 'side', 2, { frown: 0.35 }); },
      foot: (t, s) => { see(t, 'foot', s); pawShake(t, s); unsee(t); },
      tail: (t, s, B) => { see(t, 'tail', s, 100); t.to(200, { frown: 0.5, puff: 0.2 }, 'io'); wag(t, 900, 20, 3); },
    },
    biscuit: { // eager puppy: every poke is a game
      head: (t, s) => { t.to(320, { pitch: 0.15, close: 0.85, hap: 1, smile: 1, tongue: 0.7, open: 0.3 }, 'io'); wag(t, 1100, 32, 7); t.to(200, { pitch: 0, close: 0 }, 'io'); },
      ear: (t, s) => { t.to(380, { htilt: s * 12, lx: s * 0.3 }, 'io').wait(250); headShake(t, 1, 100); t.to(200, { hap: 1, smile: 1 }, 'io'); wag(t, 700, 28); },
      nose: (t, s) => { t.to(150, { cross: 0, ly: 0.2 }, 'io'); sniff(t, 4); lick(t, 2); t.to(150, { hap: 1, smile: 1 }, 'io'); wag(t, 700, 30); },
      eye: (t, s) => { t.e('blink2'); rub(t, s, 'eye', 2); t.to(160, { hap: 1, smile: 1, tongue: 0.6 }, 'io'); wag(t, 700, 30); },
      cheek: (t, s) => { leanIn(t, s, { tongue: 0.7, open: 0.25 }); wag(t, 600, 30); },
      belly: (t, s) => { const k = S(1); t.to(300, { pitch: 0.2, sq: -0.03, close: 0.9, hap: 1, smile: 1, tongue: 0.8, open: 0.35, ly: 0 }, 'io');         // belly-rub bliss ...
        const a = t.t; t.osc(1200, 5, { [k.foot]: 3.5 }, { [k.foot]: 0.5 }, 'io').to(120, { [k.foot]: 0 }, 'i'); para(t, a, u => wag(u, 1320, 34, 9)); t.to(250, { pitch: 0, close: 0, sq: 0 }, 'io'); }, // ... his back leg kicks
      side: (t, s) => { t.to(300, { pitch: -0.3, sq: 0.1, armL: -12, armR: -12, hap: 1, smile: 1, open: 0.3 }, 'io'); wag(t, 800, 34, 5); boof(t); t.to(250, { pitch: 0, sq: 0, armL: 0, armR: 0 }, 'io'); }, // play bow
      foot: (t, s) => { const k = S(s); t.to(260, o(hand(s, -6, -8), { [k.arm]: 55, [k.foot]: 0, hap: 1, smile: 1 }), 'io').wait(450); wag(t, 600, 30); t.to(260, { [k.arm]: 0, [k.hx]: 0, [k.hy]: 0 }, 'io'); }, // offers his paw
      tail: (t, s) => { see(t, 'tail', s, 0); t.to(500, { spin: 200, twist: 0, hyaw: 0.3, tongue: 0.7, open: 0.3, hap: 1 }, 'io').to(450, { spin: 360, hyaw: 0, lx: 0 }, 'io').to(1, { spin: 0 }, 'l'); wag(t, 600, 30); },
    },
    truffle: { // round, jiggly piglet
      head: (t, s) => { jelly(t, 0.1, 4, 220); snort(t, 2); },
      ear: (t, s) => { headShake(t, 0.9, 105); snort(t, 1); },
      nose: (t, s) => { t.to(120, { cross: 0, ly: 0.3 }, 'io'); snort(t, 2); sniff(t, 3); t.to(200, { hap: 1, smile: 1 }, 'io'); },
      eye: (t, s) => { t.e('blink2'); rub(t, s, 'eye', 2); snort(t, 1); },
      cheek: (t, s) => { t.to(180, { puff: 0.6, hap: 1, smile: 1 }, 'o'); jelly(t, 0.3, 3, 220, 'puff'); giggle(t, 3); },
      belly: (t, s) => { t.to(160, { sq: 0.12 }, 'io'); jelly(t, 0.14, 5, 240); giggle(t, 2); pat(t, 2); },
      side: (t, s) => { jelly(t, 4, 4, 260, 'bend'); snort(t, 1); },
      foot: (t, s) => { const k = S(s); t.to(200, { [k.foot]: 5, frown: 0.3 }, 'io').to(110, { [k.foot]: 0, sq: 0.1 }, 'i').e('emit', 'dust', k.foot, 3).to(200, { sq: 0 }, 'io'); snort(t, 2); },
      tail: (t, s) => { see(t, 'tail', s, 100); t.osc(600, 3, { curl: 0.9 }, { curl: 0.2 }, 'io'); t.to(160, { open: 0.5, mw: 0.8 }, 'o').e('emit', 'note', 'head').to(220, { open: 0, mw: 1, curl: 0 }, 'io'); },
    },
    nibbles: { // quick, twitchy hamster
      head: (t, s) => { freeze(t, 450); sniff(t, 3); },
      ear: (t, s) => { const k = S(s); t.osc(700, 4, { [k.ear]: -14 }, { [k.ear]: 3 }, 'io').to(140, { [k.ear]: 0 }, 'io'); headShake(t, 0.7, 75); }, // his paws are too short to reach: quick ear twitches
      nose: (t, s) => { t.to(100, { cross: 0, ly: 0.2 }, 'io'); t.osc(900, 7, { sq: 0.025, pitch: 0.05, mw: 0.8 }, { sq: 0, pitch: 0, mw: 1 }, 'o'); t.to(200, { puff: 0.7 }, 'o').wait(200).to(250, { puff: 0 }, 'io'); },
      eye: (t, s) => { t.to(260, o(both(4, -18), { close: 1 }), 'io'); t.osc(1000, 4, { hLy: -20, hRy: -16, pitch: -0.05 }, { hLy: -16, hRy: -20, pitch: 0.03 }, 'io'); t.to(260, o(NOHANDS, { close: 0, pitch: 0, winkL: 0, winkR: 0 }), 'io'); }, // hamster face-wash
      cheek: (t, s) => { t.to(200, { puff: 1, wide: 0.5 }, 'o').wait(200).to(70, { puff: 0, open: 0.4 }, 'o').e('emit', 'seed', 'mouth', 2).to(160, { open: 0, wide: 0 }, 'io'); giggle(t, 3, 0.8); },
      belly: (t, s) => { t.to(180, both(6, -8), 'io'); giggle(t, 4, 0.8); t.to(200, NOHANDS, 'io'); },
      side: (t, s) => { t.to(200, { x: -s * 5, lean: -s * 1.5 }, 'o'); steps(t, 200, 2, 2.5); freeze(t, 300); },
      foot: (t, s) => { jump(t, { h: 5, ant: 80, up: 140, c: 0.1, arm: 20 }); steps(t, 700, 6, 3); },
      tail: (t, s) => { t.to(420, { spin: 150, hyaw: 0.3, lx: 0.8 }, 'io').wait(300).to(420, { spin: 360, hyaw: 0, lx: 0 }, 'io').to(1, { spin: 0 }, 'l'); sniff(t, 2); },
    },
    quill: { // shy hedgehog
      head: (t, s) => { t.to(180, { sq: 0.14, pitch: -0.35, close: 1 }, 'io').wait(350).to(300, { close: 0.4, ly: -0.5 }, 'io').wait(250); t.to(400, { sq: 0, pitch: 0, close: 0, ly: 0, blush: 0.9, smile: 0.5 }, 'io'); },
      ear: (t, s) => { t.to(250, { armL: 25, armR: 25, htilt: s * 5, sq: 0.04 }, 'io'); blushy(t, -s); t.to(200, { armL: 0, armR: 0, htilt: 0, sq: 0 }, 'io'); },
      nose: (t, s) => { t.to(150, { cross: 0, ly: 0.3 }, 'io'); t.osc(500, 3, { mw: 0.8, sq: 0.02 }, { mw: 1, sq: 0 }, 'io'); t.to(300, o(hand(1, 13, -18), hand(-1, 13, -18), { blush: 1 }), 'io').wait(500).to(300, NOHANDS, 'io'); },
      eye: (t, s) => { t.to(280, o(both(6, -27), { [S(s).wink]: 0 }), 'io').wait(400).to(260, o(hand(-s, -1, -19), { lx: -s * 0.4 }), 'io').wait(400).to(300, o(NOHANDS, { lx: 0, blush: 0.8 }), 'io'); },
      cheek: (t, s) => { blushy(t, -s); },
      belly: (t, s) => { curl(t, 700, true); giggle(t, 2, 0.7); },
      side: (t, s) => { t.to(220, o(both(4, 2), { sq: 0.17, pitch: -0.6, close: 1, armL: -10, armR: -10 }), 'o'); const a = t.t; t.to(700, { spin: -s * 360, x: -s * 3 }, 'io').to(1, { spin: 0 }, 'l'); t.at(a + 701).wait(150);
        t.to(500, o(NOHANDS, { sq: 0, pitch: 0, close: 0, armL: 0, armR: 0, blush: 0.9 }), 'io'); },
      foot: (t, s) => { see(t, 'foot', s); t.osc(500, 2, { [S(s).foot]: 2 }, { [S(s).foot]: 0.5 }, 'io').to(150, { [S(s).foot]: 0 }); t.to(250, { blush: 1 }, 'io'); unsee(t); },
      tail: (t, s) => { curl(t, 400, false); see(t, 'tail', s, 300); unsee(t); },
    },
    waffles: { // goofy corgi
      head: (t, s) => { t.to(150, { hap: 1, smile: 1 }, 'io'); boof(t); t.to(350, { htilt: 12, earL: 4, earR: -6 }, 'io').wait(350).to(300, { htilt: 0, earL: 0, earR: 0 }, 'io'); },
      ear: (t, s) => { shake(t, { P: 105, env: [0.6, 1, 1, 0.7, 0.4, 0.15], head: 0.36, roll: 5, ear: 14, chest: 0.22, body: 0.8, tail: 30 }); t.to(200, { tongue: 0.6, open: 0.3, hap: 1, smile: 1 }, 'io'); },
      nose: (t, s) => { t.to(120, { cross: 0, ly: 0.2 }, 'io'); sniff(t, 3); sneeze(t, 0.7); t.to(200, { tongue: 0.6, open: 0.3, hap: 1 }, 'io'); },
      eye: (t, s) => { t.e('blink2'); t.to(200, { [S(s).wink]: 0, [S(-s).wink]: 1, tongue: 0.7, open: 0.3, htilt: -s * 6 }, 'io').wait(400).to(250, { [S(-s).wink]: 0, htilt: 0 }, 'io'); },
      cheek: (t, s) => { leanIn(t, s, { tongue: 0.7, open: 0.25 }); },
      belly: (t, s) => { t.to(260, { sq: 0.3, armL: 34, armR: 34, hap: 1, smile: 1, tongue: 0.8, open: 0.35, pitch: 0.1 }, 'i'); const a = t.t; t.osc(900, 4, { footL: 3, footR: 0.5 }, { footL: 0.5, footR: 3 }, 'io').to(120, { footL: 0, footR: 0 });
        para(t, a, u => wag(u, 1020, 36, 9)); t.to(300, { sq: 0, armL: 0, armR: 0, pitch: 0 }, 'io'); },
      side: (t, s) => { t.to(280, { pitch: -0.3, sq: 0.1, armL: -12, armR: -12, hap: 1, smile: 1 }, 'io'); swing(t, 800, 5, { tilt: 4, wag: 36 }); boof(t); t.to(250, { pitch: 0, sq: 0, armL: 0, armR: 0 }, 'io'); },
      foot: (t, s) => { const k = S(s); t.to(220, { [k.foot]: 4, [k.arm]: 30 }, 'io'); t.osc(600, 3, { [k.foot]: 5.5 }, { [k.foot]: 3.5 }, 'io'); t.to(220, { [k.foot]: 0, [k.arm]: 0, hap: 1, smile: 1 }, 'i'); },
      tail: (t, s) => { see(t, 'tail', s, 0); swing(t, 1000, 9, { tilt: 5, x: 0.8, wag: 38 }); unsee(t); },
    },
    poppy: { // guinea pig: freezes, wheeks, popcorns
      head: (t, s) => { freeze(t, 400); wheek(t); },
      ear: (t, s) => { popcorn(t, 9, -s, 480); },
      nose: (t, s) => { t.to(100, { cross: 0, ly: 0.2 }, 'io'); t.osc(700, 5, { sq: 0.025, mw: 0.8 }, { sq: 0, mw: 1 }, 'o'); wheek(t); },
      eye: (t, s) => { t.e('blink2'); const a = t.t; t.to(300, { x: -s * 4, winkL: 0, winkR: 0 }, 'o'); para(t, a, u => steps(u, 300, 3, 1.8)); t.wait(300); walkBack(t, 500); },
      cheek: (t, s) => { t.to(350, { close: 0.85, hap: 1, smile: 1, htilt: s * 6 }, 'io'); t.osc(1200, 4, { sq: 0.02 }, { sq: 0 }, 'io'); t.to(300, { close: 0, htilt: 0 }, 'io'); },
      belly: (t, s) => { popcorn(t, 12, 1, 520); popcorn(t, 9, -1, 460); },
      side: (t, s) => { const a = t.t; t.to(380, { x: -s * 6, lean: -s * 2 }, 'o'); para(t, a, u => steps(u, 380, 5, 2)); wheek(t); },
      foot: (t, s) => { steps(t, 500, 4, 2); popcorn(t, 10, s, 500); },
      tail: (t, s) => { popcorn(t, 11, 1, 520); see(t, 'tail', s, 200); unsee(t); wheek(t); },
    },
    duchess: { // dignified Persian
      head: (t, s) => { t.to(180, { wide: 1, pitch: 0.12, open: 0.3, mw: 0.6 }, 'o').wait(400).to(200, { wide: 0, open: 0, mw: 1 }, 'io'); smooth(t, 1, 'head'); t.to(300, { pitch: 0.15, close: 0.4 }, 'io').wait(300); },
      ear: (t, s) => { hmph(t, -s); },
      nose: (t, s) => { t.to(120, { cross: 0, ly: 0.2 }, 'io'); sniff(t, 2); t.to(250, o(hand(1, 13, -18)), 'io'); sneeze(t, 0.45); t.to(250, NOHANDS, 'io'); },
      eye: (t, s) => { t.to(500, { close: 1 }, 'io').to(500, { close: 0.4, frown: 0.45, winkL: 0, winkR: 0 }, 'io').wait(500).to(300, { close: 0, frown: 0 }, 'io'); },
      cheek: (t, s) => { leanIn(t, s, { pitch: 0.08 }); },
      belly: (t, s) => { t.to(150, { wide: 0.6, frown: 0.5, ly: 0.6 }, 'o'); swat(t, 1, 2); hmph(t, -1); },
      side: (t, s) => { t.to(200, { frown: 0.4, pitch: 0.12 }, 'io'); smooth(t, s, 'side'); t.to(250, { frown: 0, pitch: 0 }, 'io'); },
      foot: (t, s) => { pawShake(t, s, 0.6); t.to(300, { pitch: 0.15, close: 0.4 }, 'io').wait(300); },
      tail: (t, s) => { see(t, 'tail', s, 0); t.to(300, { close: 0.45, frown: 0.5 }, 'io'); swing(t, 1100, 3, { wag: 26, curl: 0.3 }); unsee(t); },
    },
    mamapaws: { // gentle mum with her pup
      head: (t, s) => { t.to(300, { hap: 1, smile: 1 }, 'io'); t.to(400, { pitch: -0.28, ly: 0.8, htilt: -5 }, 'io').osc(800, 1, { htilt: -9 }, { htilt: -5 }, 'io').e('emit', 'heart', 'head', 1); unsee(t, 400); },
      ear: (t, s) => { headShake(t, 0.7, 110); giggle(t, 2, 0.7); },
      nose: (t, s) => { t.to(120, { cross: 0, ly: 0.2 }, 'io'); sniff(t, 2); lick(t, 1); t.to(200, { hap: 1, smile: 1 }, 'io'); },
      eye: (t, s) => { t.e('blink2').wait(200); t.to(400, { pitch: -0.25, ly: 0.8, winkL: 0, winkR: 0 }, 'io').wait(500); unsee(t, 400); },
      cheek: (t, s) => { leanIn(t, s); t.e('emit', 'heart', 'head', 1); },
      belly: (t, s) => { t.to(250, o(both(8, -5), { hap: 1, smile: 1 }), 'io'); giggle(t, 3, 0.8); t.to(300, { pitch: -0.2, ly: 0.7 }, 'io').e('emit', 'heart', 'head', 1); unsee(t, 300); t.to(200, both(6, -6), 'io'); },
      side: (t, s) => { jelly(t, 3, 3, 300, 'bend'); t.to(400, { pitch: -0.25, ly: 0.8 }, 'io').wait(300); unsee(t, 350); },
      foot: (t, s) => { see(t, 'foot', s, 200); t.to(300, { [S(s).foot]: 0 }, 'io'); unsee(t); t.to(200, { hap: 1, smile: 1 }, 'io'); },
      tail: (t, s) => { see(t, 'tail', s, 200); unsee(t); t.to(400, { pitch: -0.25, ly: 0.8 }, 'io').wait(300); unsee(t, 300); },
    },
    ribbit: { // springy frog
      head: (t, s) => { t.to(120, { sq: 0.3 }, 'io').wait(200); jump(t, { h: 10, ant: 60, up: 220, c: 0.3, arm: 50, st: 1.1 }); },
      ear: (t, s) => { t.e('blink'); t.to(300, { [S(s).wink]: 0 }, 'io'); croak(t, 1, 420); },
      nose: (t, s) => { t.to(120, { cross: 0, ly: 0.1 }, 'io'); t.to(80, { tongue: 1, open: 0.5, pitch: 0.12, sq: -0.05 }, 'o').to(140, { tongue: 0, open: 0, sq: 0.06, pitch: -0.05 }, 'io').to(160, { sq: 0.06, puff: 0.5 }, 'o').to(200, { sq: 0, puff: 0, pitch: 0, hap: 1, smile: 1 }, 'io'); },
      eye: (t, s) => { t.e('blink2').to(250, { winkL: 0, winkR: 0 }, 'io'); croak(t, 1, 400); },
      cheek: (t, s) => { croak(t, 2, 420); },
      belly: (t, s) => { t.to(150, { hap: 1, smile: 1 }, 'io'); const a = t.t; croak(t, 3, 330); para(t, a, u => jelly(u, 0.1, 4, 250)); },
      side: (t, s) => { jump(t, { h: 9, ant: 120, up: 200, c: 0.22, arm: 45, x: -s * 6 }); t.wait(200); jump(t, { h: 8, ant: 120, up: 200, c: 0.2, arm: 40, x: 0 }); },
      foot: (t, s) => { jump(t, { h: 14, ant: 100, up: 250, c: 0.26, arm: 60, st: 1.1 }); },
      tail: (t, s) => { const a = t.t; t.osc(500, 2, { footR: 4 }, { footR: 0.5 }, 'io').to(100, { footR: 0 }); jump(t, { h: 10, ant: 100, up: 220, c: 0.22, arm: 45 }); },
    },
  };

  // ---------- page labels + descriptions (what each creature does) ----------
  const TXT = {
    mittens: { head: 'Bonk: rubs his head with a little pout.', ear: 'Ear flicks, a quick cat head shake, giggles.', nose: 'Cross-eyed, sneezes, rubs his nose.', eye: 'Flinches, rubs his eye, blinks it clear.',
      cheek: 'Leans into your finger and rubs against it, purring.', belly: 'Ticklish: giggles and bats at your finger.', side: 'Steps to catch his balance, looks, rubs the spot, walks back.', foot: 'Shakes his paw like a cat stepping in water.', tail: 'Tail puffs up, he hops, glares back at it, tail lashes.' },
    biscuit: { head: 'Thinks it is a pat: pushes up into it, tongue out, tail wagging.', ear: 'Ear flips, puppy head tilt, then a shake.', nose: 'Sniffs your finger and licks it.', eye: 'Blinks, paw rub, wags it off.',
      cheek: 'Leans in with his tongue out.', belly: 'Belly-rub bliss: eyes shut, his back leg kicks, tail thumping.', side: 'Stumbles into a play bow and a happy boof.', foot: 'Offers you his paw to shake.', tail: 'Spins round after his tail.' },
    truffle: { head: 'His whole round body jiggles, two snorts.', ear: 'A piggy head shake and a snort.', nose: 'Snorts at your finger and sniffs it.', eye: 'Blinks, rubs it with a hoof, snorts.',
      cheek: 'His cheeks wobble and he giggles.', belly: 'Belly jiggles like jelly, he giggles and pats it.', side: 'Wobbles side to side like jelly.', foot: 'Stomps his hoof, dust puffs up, snorts.', tail: 'Curly tail springs, looks back, oinks.' },
    nibbles: { head: 'The hamster freeze, eyes dart, nose twitches.', ear: 'Quick ear twitches, little head shake.', nose: 'Nose twitches like crazy, cheeks puff.', eye: 'Hamster face-wash with both paws.',
      cheek: 'Cheek balloons and pops a seed out, giggles.', belly: 'Quick ticklish giggles, paws clasped.', side: 'Zips sideways, freezes, eyes dart.', foot: 'Tiny jump, runs on the spot.', tail: 'Spins round to see what touched him, sniffs.' },
    quill: { head: 'Ducks with his eyes shut, peeks up, blushes.', ear: 'Shy shrug, hides his face, blushes.', nose: 'Nose wiggles, covers it with both paws.', eye: 'Covers his eyes, peeks through one side.',
      cheek: 'Blushes deep and looks away shyly.', belly: 'Curls into a ball and trembles, then giggles.', side: 'Curls up and rolls away, uncurls blushing.', foot: 'Wiggles his foot, looks down, blushes.', tail: 'Curls up, then peeks back over his shoulder.' },
    waffles: { head: 'Happy boof and a head tilt.', ear: 'A full dog shake, tongue out.', nose: 'Sniffs, a little play-sneeze.', eye: 'Goofy wink with his tongue out.',
      cheek: 'Leans in, tongue out.', belly: 'Flops flat, legs kicking, stub tail going.', side: 'Play bow, butt wiggle, boof.', foot: 'Lifts his paw and waves it.', tail: 'Frantic butt wiggle, looks back.' },
    poppy: { head: 'Freezes, then wheeks.', ear: 'A sudden popcorn hop.', nose: 'Nose twitches, wheeks.', eye: 'Blinks and scoots back on pattering feet.',
      cheek: 'Leans in with her eyes shut, content.', belly: 'Two popcorn hops.', side: 'Zips sideways, wheeks, creeps back.', foot: 'Pitter-pats, then pops.', tail: 'Pops straight up, looks back, wheeks.' },
    duchess: { head: 'Appalled, then smooths her fur and lifts her chin.', ear: 'Hmph: frowns and turns her head away.', nose: 'Dainty sniff, a tiny sneeze behind her paw.', eye: 'A slow blink, then a glare.',
      cheek: 'Leans into it, purring - she likes that one.', belly: 'NOT the belly: swats at your finger, hmph.', side: 'Smooths her fur where you poked.', foot: 'Shakes her paw daintily, chin up.', tail: 'Tail lashes, glares back over her shoulder.' },
    mamapaws: { head: 'Warm smile, nuzzles her pup.', ear: 'Gentle head shake and a soft laugh.', nose: 'Sniffs your finger, a gentle lick.', eye: 'Blinks, then checks her pup.',
      cheek: 'Leans in, hearts.', belly: 'Hugs her pup closer, giggles.', side: 'Wobbles like jelly, checks her pup.', foot: 'Looks down at her paw, smiles.', tail: 'Looks back, then checks her pup.' },
    ribbit: { head: 'Squashed flat, springs back up.', ear: 'That eye blinks, a croak.', nose: 'Zaps your finger with his tongue, gulps.', eye: 'Double blink, a croak.',
      cheek: 'Two big throat-puffing croaks.', belly: 'Giggly croaks, belly jiggles.', side: 'Hops away to the side and back.', foot: 'Springs straight up.', tail: 'Kicks his back leg, hops.' },
  };
  const NAME = { head: 'Top of head', ear: 'ear', nose: 'Nose', eye: 'eye', cheek: 'cheek', belly: 'Belly', side: 'side', foot: 'foot', tail: 'Tail' };
  const SPOTS = [['head', 0], ['earL', -1], ['earR', 1], ['nose', 0], ['eyeL', -1], ['eyeR', 1], ['cheekL', -1], ['cheekR', 1], ['belly', 0], ['sideL', -1], ['sideR', 1], ['footL', -1], ['footR', 1], ['tail', 1]];
  // builds poke_<spot>@key for every creature in RE (also used by snack-pokes.js). B (BODY) options: ear swing scale, tail (has a real tail),
  // noWalk (side poke: no walk back), hopBack (no feet: hops back instead of stepping), earTap / tailTap (where the finger lands),
  // lbl { spot: name } (sided spots get 'Left ' / 'Right ' in front; a function gets s)
  const build = (RE, TXT, BODY) => { const ST = {};
    for (const key in RE) { const B = BODY[key] || {}, T = (CARD[key] && CARD[key].T) || 1, D = DESC[key] = DESC[key] || {};
      SPOTS.forEach(([nm, s]) => { const spot = nm.replace(/[LR]$/, ''), t = TL({}, T);
        HIT[spot](t, s, B); RE[key][spot](t, s, B);
        if (spot === 'side' && !B.noWalk) { if (B.hopBack) jump(t, { h: 4, ant: 120, up: 170, c: 0.1, arm: 20, x: 0 }); else walkBack(t, 480); } t.rest(420);
        const tap = (R.STATES['poke_' + nm] || {}).tap; let tp = tap;
        if (B.earTap && spot === 'ear') tp = [s < 0 ? B.earTap[0] : 100 - B.earTap[0], B.earTap[1]]; if (spot === 'tail' && !B.tail) tp = B.tailTap || [78, 72];
        ST['poke_' + nm + '@' + key] = t.done({ tap: tp, stretch: 0.5 });
        const side = s < 0 ? 'Left ' : s > 0 && spot !== 'tail' ? 'Right ' : '', L = B.lbl && B.lbl[spot];
        let label = L ? (typeof L === 'function' ? L(s) : (spot === 'head' || spot === 'nose' || spot === 'belly' || spot === 'tail' ? '' : side) + L)
          : spot === 'head' || spot === 'nose' || spot === 'belly' ? NAME[spot] : spot === 'tail' ? (B.tail ? 'Tail' : 'Back end') : side + NAME[spot];
        const tx = TXT[key][spot]; D['poke_' + nm] = [label, typeof tx === 'function' ? tx(s) : tx]; }); }
    R.add(ST); };
  R.POKELIB = { HIT, SEE, see, unsee, SPOT, rub, walkBack, giggle, hmph, sneeze, sniff, lick, para, leanIn, swat, pawShake, headShake, snort, freeze, curl, blushy, happy, pat, smooth, build };
  build(RE, TXT, BODY);
})();
