// Fruit Patch personalities (Nov 10, user: 'add 11 more new characters for fruit patch, and after that do the modification for their animations just like
// we did with petshop and snack shack'). All 20 fruits get the same layers as the Pet Shop / Snack Shack: the natural look (natF: the face leads, the whole
// fruit follows along a dipping arc), a personality card that flavours the shared moves, a hand-made happy / surprised / squish / habit / squeeze reaction
// made of each fruit's own parts, 9 poke spots and all 20 foods each their own way. The 11 new fruits also get a signature dance made of what only their
// body can do (the 9 older ones keep their own dances from rive-generic: Tropical Sway, Pit Hop, Berry Bop, Sour Shuffle, Kiwi Bird Strut, Summer Surf,
// Orchard Drop, Dragon Leap, Fruit Salad Sway). pitch: NEGATIVE = head down.
// Parts (channels): old fruits (rive-generic): crw / crs (Pina's crown flare / whirl), pp / pt / pr / prw / lfl / lsp (Avo's pit pop / toss / roll / wobble,
// leaf flap / spin), lfl / lsp / stw (Berri, Lemmy, Peachy: leaves flap / whirl, stem boing), fzz (Kiwi's fuzz), sdj (Melo's seeds), brf / crw / wfl / wsp / spk
// (Pitaya's bracts, crown, wings, sparkle), fL / fR / cb / wfl (Tutti's cherry / pear toss, crown bounce, wings); new fruits (fruit-3d.js): lf (leaves
// flutter), stw (stem / crown twirl), crf (crown flare), jig (Razzy's drupelets jiggle), pol (Plummy's dusty bloom polished off), cv (Nana's curve),
// fz (Coco's fibres stand on end), rl (Blueby rolls, degrees).
(function () {
  const CH = { lf: 0, stw: 0, crf: 0, jig: 0, pol: 0, cv: 0, fz: 0, rl: 0, rig: 0 };
  const OLD = ['pina', 'avo', 'berri', 'lemmy', 'kiwi', 'melo', 'peachy', 'pitaya', 'tutti'];
  const NEW = ['nana', 'bing', 'plummy', 'clemmy', 'appy', 'blueby', 'coco', 'perry', 'grana', 'mangie', 'razzy'];
  const KEYS = OLD.concat(NEW);
  const drop = (c, x) => Object.assign({ n: 5, sp: 22, vy: -20, g: 90, life: 800, r: [0.8, 1.3], col: c, kind: 'drop' }, x || {});
  const preset = R => { const P = R.PRE; if (!P || P.zest) return; Object.assign(P, {
    pinjuice: drop(['#ffd84a', '#fff3a0', '#f2b81c']), guac: drop(['#a8d86a', '#d6f0a0', '#6aa83a'], { kind: 'dot', r: [0.7, 1.2] }),
    banjuice: drop(['#fff3a0', '#ffe14a', '#f2c41c']), chjuice: drop(['#e3263a', '#ff6a7a', '#9c0f26']), pljuice: drop(['#8e2a6e', '#d070b0', '#5a1050']),
    zest: { n: 6, sp: 28, vy: -18, g: 50, life: 700, r: [0.45, 0.8], col: ['#ff9a26', '#ffd9a0', '#ffb84a', '#ffffff'], kind: 'dot' },
    apjuice: drop(['#b8f070', '#e8ffb0', '#8ed84a']), bljuice: drop(['#5866d6', '#9aa6ff', '#2a3482']), cocomilk: drop(['#ffffff', '#f4efe6', '#fffaf0']),
    fibre: { n: 4, sp: 18, vy: -14, g: 70, life: 900, r: [0.5, 0.8], col: ['#5a3820', '#8a5a30', '#3e2614'], kind: 'seed' },
    pearjuice: drop(['#e8f59a', '#c6de4a', '#fffbd0']), arils: { n: 6, sp: 24, vy: -24, g: 90, life: 900, r: [0.8, 1.1], col: ['#d42a3a', '#ff6a7a', '#a8102a'], kind: 'seed' },
    mjuice: drop(['#ffa83a', '#ffd27a', '#e45a2a']), rzjuice: drop(['#ec3a6c', '#ff8fb0', '#a81846']),
    knock: { n: 1, sp: 6, vy: -12, g: -2, life: 1100, r: [1, 1], col: ['#8a5a30', '#5a3820'], kind: 'note' } }); };
  const JUICE = { pina: 'pinjuice', avo: 'guac', berri: 'juice', lemmy: 'lemjuice', kiwi: 'kiwijuice', melo: 'melojuice', peachy: 'peachjuice', pitaya: 'pitjuice', tutti: 'fruitjuice',
    nana: 'banjuice', bing: 'chjuice', plummy: 'pljuice', clemmy: 'zest', appy: 'apjuice', blueby: 'bljuice', coco: 'cocomilk', perry: 'pearjuice', grana: 'arils', mangie: 'mjuice', razzy: 'rzjuice' };

  // =====================================================================================================================================
  // personalities, moves, dances
  (function boot() {
    const R = window.RiveRig; if (!R || !R.PETLIB || !R.PETLIB.install || !R.SOFT || !R.SNACKLIB) { setTimeout(boot, 25); return; } if (R.fruitV) return; R.fruitV = 1;
    Object.keys(CH).forEach(k => { if (R.REST[k] == null) R.REST[k] = 0; }); preset(R); R.FRUITLIB = { KEYS, OLD, NEW, JUICE };
    const { TL, hand, both, o, NOHANDS, jump, shake, swing, steps, jelly, land, install } = R.PETLIB, natF = R.SNACKLIB.natF;
    KEYS.forEach(k => R.SOFT.add(k)); if (R.SNACKLIB.KEYS) KEYS.forEach(k => { if (!R.SNACKLIB.KEYS.includes(k)) R.SNACKLIB.KEYS.push(k); });
    const loopN = (t, n) => Object.assign(t.loop(), { dur: t.t * (n || 3) });
    const hopC = (t, h, x) => jump(t, o({ h: h || 7, ant: 150, up: 210, c: 0.16, arm: 46 }, x || {}));
    const J = (t, k, w, n) => t.e('emit', JUICE[k], w || 'head', n || 3);
    const sparkle = (t, n) => t.e('emit', 'spark', 'head', n || 2);
    // a squeeze let-go: the body bounces back (sq) and the part springs (ch: [value at press, overshoot ...]) + an emit
    const relK = (ch, a, em, x) => ({ __rel: [ch, a, em, x] });                                                // resolved after MOVES (starts from the squeeze pose)
    const spinR = (t, dur, deg, x) => { const a = t.t; t.to(dur, o({ spin: deg }, x || {}), 'io').to(1, { spin: 0 }, 'l'); return a; };

    // ---------- personality cards (T tempo, b bounce = squash + lift, s sway) ----------
    const CARDS = {
      pina: { T: 0.95, b: 1.1, s: 1.25 },    // pineapple: tropical, swaying party guy
      avo: { T: 1.05, b: 1.1, s: 1 },        // avocado: chill, buttery, proud of his pit
      berri: { T: 0.9, b: 1.2, s: 1.05 },    // strawberry: sweet and bouncy
      lemmy: { T: 0.85, b: 0.95, s: 1 },     // lemon: zesty, twitchy, a bit sour
      kiwi: { T: 0.85, b: 1.05, s: 0.95 },   // kiwi: quick and bird-like
      melo: { T: 1.1, b: 1.15, s: 1.15 },    // watermelon: laid-back summer surfer
      peachy: { T: 1.1, b: 1.15, s: 1.1 },   // peach: soft, gentle, blushing
      pitaya: { T: 0.9, b: 1.05, s: 1.1 },   // dragonfruit: a fierce little dragon
      tutti: { T: 1.05, b: 1, s: 1.15 },     // fruit-basket fairy: floaty
      nana: { T: 1.05, b: 1, s: 1.3 },       // banana: curvy, swaying, goofy
      bing: { T: 0.9, b: 1.25, s: 1 },       // cherry: bouncy and glossy
      plummy: { T: 1.1, b: 0.95, s: 1.15 },  // plum: a dainty, dreamy little sugar-plum ballet dancer (replaced Grapey, Nov 10)
      clemmy: { T: 0.85, b: 1.1, s: 1 },     // clementine: zippy, zesty
      appy: { T: 1, b: 1.05, s: 1 },         // apple: crisp, cheerful, tidy
      blueby: { T: 0.95, b: 1.2, s: 1.05 },  // blueberry: a little round roller
      coco: { T: 1.1, b: 0.85, s: 1.1 },     // coconut: solid, chill island guy
      perry: { T: 1.1, b: 1, s: 1.25 },      // pear: bottom-heavy, wobbly
      grana: { T: 1.15, b: 0.95, s: 0.95 },  // pomegranate: regal, dignified
      mangie: { T: 1.05, b: 1.1, s: 1.2 },   // mango: sunny, dramatic
      razzy: { T: 0.9, b: 1.2, s: 1.05 },    // raspberry: sparkly, bubbly
    };

    const MOVES = {
      // ================================================== the nine older fruits ==================================================
      pina: { // pineapple: crown flares (crw) and whirls (crs)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          swing(t, 1400, 3, { tilt: 6, x: 2, armL: 30, armR: -20 }, 'io');                                                                                          // a hula sway ...
          t.to(160, { crw: 1, sq: -0.05 }, 'o').e('emit', 'pinjuice', 'head', 2).to(360, { crw: 0, sq: 0 }, 'io'); hopC(t, 7, { air: { crs: 0.5 }, fall: { crs: 0 } }); // ... crown pops, a hop
          return loopN(t.rest(300)); })(), 'Happy', 'A happy hula sway, his crown pops open, then a hop that whirls his crown.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, crw: 1.3, sq: -0.08, lift: 2 }, 'o').to(300, { lift: 0, sq: 0.04, x: -2 }, 'i')                         // crown shoots up like hair standing on end
            .to(500, { crw: 0.6, sq: 0 }, 'io').to(320, { lx: 0.8, ly: -0.8 }, 'io').wait(200);
          t.to(320, { armL: 150, armR: 150, crs: 0.4 }, 'io').to(300, { crw: 0, crs: 0 }, 'io').to(300, o(NOHANDS, { armL: 0, armR: 0, lx: 0, ly: 0, x: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }), 'io');
          return t.rest(400).done(); })(), 'Surprised', 'His crown leaves shoot up like hair standing on end - he looks up and pats them back down.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.26, crw: 0.9, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'pinjuice', 'head', 3).wait(220);
          t.to(130, { sq: -0.15, crw: -0.3, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.6, 3, 280, 'crw'); jelly(t, 0.07, 2, 240); t.to(220, { sq: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed, his crown flares out with a squirt of juice, then he springs back and it wobbles.'],
        quirk: [(() => { const t = TL();
          t.to(320, { armL: 150, armR: 150, ly: -0.8 }, 'io').osc(1200, 3, { crs: 0.4, crw: 0.4 }, { crs: -0.2, crw: 0.1 }, 'io').to(300, { crs: 0, crw: 0 }, 'io')    // fluffs his crown like hair
            .to(300, { armL: 0, armR: 0, ly: 0, hap: 1, smile: 1 }, 'io'); swing(t, 1200, 3, { tilt: 5, x: 1.5 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Crown fluff', 'Reaches up and fluffs his crown leaves like a hairdo, then a little hula sway.'],
        press: { crw: 0.6 }, rel: relK('crw', 0.6, ['pinjuice', 'head', 3]),
      },
      avo: { // avocado: the pit (pp pops out, prw wobbles, pr rolls, pt toss), leaves (lfl, lsp)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(240, { prw: 1, lfl: 0.6 }, 'io').to(240, { prw: -0.6, lfl: 0 }, 'io').to(200, { prw: 0 }, 'io');                                                    // pit wiggles, leaves flap
          hopC(t, 7, { chain: true, air: { pp: 0.4, lfl: 0.8 }, fall: { pp: 0, lfl: 0 } }); land(t, 0.06, 2, 220); hopC(t, 8, { air: { lsp: 0.5 }, fall: { lsp: 1 } });
          t.to(1, { lsp: 0 }, 'l'); return loopN(t.rest(300)); })(), 'Happy', 'His pit wiggles in his belly, two hops - the pit bobs out and his leaves spin.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, pp: 1, sq: -0.08 }, 'o').to(250, { sq: 0 }, 'io');                                                    // his pit pops out!
          t.to(300, { ly: 0.9, pitch: -0.12 }, 'io').wait(250).to(340, o(both(6, 8), { armL: 22, armR: 22 }), 'io').to(260, { pp: 0 }, 'i').e('emit', 'guac', 'body', 2) // pushes it back in
            .to(320, o(NOHANDS, { armL: 0, armR: 0, ly: 0, pitch: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }), 'io').to(200, { prw: 0.6 }, 'io').to(200, { prw: 0 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'His pit pops out of his belly - he stares at it and pushes it back in with both paws.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.26, pp: 0.7, hap: 0.9, armL: 22, armR: 22 }, 'io').wait(220);
          t.to(130, { sq: -0.15, pp: 0, hap: 0, smile: 1, open: 0.3 }, 'o').e('emit', 'guac', 'body', 3); jelly(t, 0.8, 3, 300, 'prw'); t.to(220, { sq: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed, his pit squeezes out a little - he springs back and it wobbles in its socket.'],
        quirk: [(() => { const t = TL();
          t.to(320, o(both(6, 8), { armL: 22, armR: 22, ly: 0.8, pitch: -0.1 }), 'io').to(1400, { pr: 1 }, 'io').to(1, { pr: 0 }, 'l');                          // polishes his pit (it rolls round)
          t.to(300, o(NOHANDS, { armL: 0, armR: 0, ly: 0, pitch: 0, hap: 1, smile: 1 }), 'io').e('emit', 'spark', 'body', 2).to(300, { lfl: 0.7 }, 'io').to(300, { lfl: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Pit polish', 'Rubs his pit with both paws so it rolls round and shines, then a proud leaf flap.'],
        press: { pp: 0.4 }, rel: relK('prw', 1, ['guac', 'body', 2], { k: { sq: [[0, 0], [110, -0.15, 'o'], [250, 0.07, 'io'], [410, 0, 'io']], pp: [[0, 0.4], [150, 0, 'i']], prw: [[0, 0], [200, 1, 'o'], [450, -0.5, 'io'], [700, 0, 'io']] } }),
      },
      berri: { // strawberry: calyx (lfl flap, lsp twirl), stem boing (stw)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          hopC(t, 7, { chain: true, air: { lfl: 0.8, stw: 0.6 }, fall: { lfl: 0, stw: 0 } }); land(t, 0.06, 2, 220); hopC(t, 8, { air: { lsp: 0.5, lfl: 0.6 }, fall: { lsp: 1, lfl: 0 } });
          t.to(1, { lsp: 0 }, 'l').to(160, { sq: -0.05 }, 'o').e('emit', 'juice', 'head', 2).to(220, { sq: 0 }, 'io'); return loopN(t.rest(300)); })(), 'Happy', 'Juicy bounces - his leafy top flaps and twirls, a happy squirt of juice.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, lfl: 1.3, stw: 1, sq: -0.08, lift: 2 }, 'o').to(300, { lift: 0, sq: 0.03 }, 'i').e('emit', 'juice', 'head', 2);
          t.to(500, { lfl: 0, stw: 0, sq: 0 }, 'io').to(300, { ly: -0.8 }, 'io').wait(300).to(300, { ly: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'His leaves fly up and his stem boings, a drop of juice - he looks up at them settling.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.27, lfl: -0.4, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'juice', 'body', 4).wait(220);
          t.to(130, { sq: -0.15, lfl: 1, stw: 0.8, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.8, 3, 280, 'stw'); t.to(260, { sq: 0, lfl: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed so the juice runs, then he springs back - leaves up, stem boinging.'],
        quirk: [(() => { const t = TL();
          t.to(320, { armL: 150, armR: 150, ly: -0.8 }, 'io').osc(1000, 3, { lfl: 0.7 }, { lfl: 0.1 }, 'io').to(200, { lfl: 0 }, 'io')                              // fluffs his leaves
            .to(300, { armL: 0, armR: 0, ly: 0 }, 'io').to(700, { lsp: 1, hap: 1, smile: 1 }, 'io').to(1, { lsp: 0 }, 'l').to(200, { stw: 0.6 }, 'o').to(300, { stw: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Leaf fluff', 'Fluffs up his leafy top with both paws, gives it a twirl and a stem boing.'],
        press: { lfl: 0.6 }, rel: relK('stw', 0.9, ['juice', 'head', 3]),
      },
      lemmy: { // lemon: sour pucker (close + small mouth), leaf (lfl / lsp), stem boing
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.osc(900, 6, { tilt: 4, lfl: 0.5 }, { tilt: -4, lfl: 0 }, 'io').to(150, { tilt: 0 }, 'io');                                                             // a zesty shimmy ...
          hopC(t, 8, { air: { stw: 0.8 }, fall: { stw: 0 }, ev: [['emit', 'lemjuice', 'head', 2]] }); return loopN(t.rest(300)); })(), 'Happy', 'A quick zesty shimmy with his leaf flapping, then a hop that sprays a little lemon juice.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(90, { close: 0.85, mw: 0.35, puff: -0.3, sq: 0.05 }, 'o'); shake(t, { P: 70, head: 0.2, roll: 3, body: 0.6, env: [0.5, 1, 1, 0.8, 0.5, 0.25] });     // sour shiver ...
          t.to(80, { close: 0, wide: 1, open: 0.5, mw: 0.7, puff: 0, lift: 3, sq: -0.08, lfl: 1, stw: 1 }, 'o').e('emit', 'lemjuice', 'head', 3).to(320, { lift: 0, sq: 0 }, 'i') // ... zing!
            .to(400, { lfl: 0, stw: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'A sour pucker shiver, then a wide-eyed zing that pops him up and sprays juice.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.18, close: 0.8, mw: 0.4, armL: 22, armR: 22 }, 'io').e('emit', 'lemjuice', 'head', 5).wait(250);              // squeezed lemon: juice sprays
          t.to(120, { sq: -0.1, close: 0, mw: 1, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.05, 2, 220); t.to(220, { sq: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squeezed like a real lemon - juice sprays, he puckers, then springs back.'],
        quirk: [(() => { const t = TL();
          t.to(300, { lx: 0.8, hyaw: 0.15 }, 'io').wait(300).to(120, { close: 0.85, mw: 0.35, puff: -0.3 }, 'o'); shake(t, { P: 75, head: 0.15, roll: 2, env: [0.6, 1, 0.7, 0.3] });
          t.to(300, { close: 0, mw: 1, puff: 0, lx: 0, hyaw: 0, hap: 1, smile: 1 }, 'io').to(300, { lfl: 0.6 }, 'io').to(300, { lfl: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Sour face', 'Catches a whiff of something sour, puckers up and shivers, then grins and flaps his leaf.'],
        press: { mw: 0.5, close: 0.4 }, rel: relK('stw', 0.9, ['lemjuice', 'head', 4]),
      },
      kiwi: { // kiwi: fuzz (fzz), stem bob (stw), bird-like head bobs
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          for (let i = 0; i < 4; i++) t.to(170, { pitch: 0.12, x: (i % 2 ? 1 : -1) * 1.5, [i % 2 ? 'footR' : 'footL']: 2.2 }, 'o').to(170, { pitch: -0.05, footL: 0, footR: 0 }, 'i'); // bird strut + head bobs
          t.to(200, { x: 0, pitch: 0 }, 'io').to(220, { fzz: 1 }, 'o').e('emit', 'kiwifuzz', 'head', 3).to(400, { fzz: 0 }, 'io'); hopC(t, 6);
          return loopN(t.rest(300)); })(), 'Happy', 'A bird-like strut with head bobs, a fluff-up of his fuzz, then a little hop.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(70, { wide: 1, open: 0.4, mw: 0.6, fzz: 1.3, sq: -0.06 }, 'o').e('emit', 'kiwifuzz', 'head', 4).wait(500);                                      // fuzz bristles, he freezes
          t.to(200, { lx: -0.9, hyaw: -0.2 }, 'o').to(200, { lx: 0.9, hyaw: 0.2 }, 'o').to(240, { lx: 0, hyaw: 0, fzz: 0, wide: 0, open: 0, mw: 1, sq: 0, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'His fuzz bristles all over and he freezes like a startled bird, then darts a look both ways.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.24, fzz: 0.6, hap: 0.9, armL: 22, armR: 22 }, 'io').wait(220);
          t.to(120, { sq: -0.14, fzz: 1.1, hap: 0, smile: 1, open: 0.3 }, 'o').e('emit', 'kiwifuzz', 'head', 4).e('emit', 'kiwijuice', 'body', 2); jelly(t, 0.07, 3, 240); t.to(300, { sq: 0, fzz: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed, then he springs back with his fuzz puffed up and bits of fuzz floating.'],
        quirk: [(() => { const t = TL();
          for (let i = 0; i < 3; i++) { const d = i % 2 ? 1 : -1; t.to(220, { hyaw: d * 0.3, pitch: -0.22, ly: 0.8, lx: d * 0.6 }, 'io').to(120, { fzz: 0.5 }, 'o').to(160, { fzz: 0.1 }, 'io'); } // preens his fuzz
          t.to(300, { hyaw: 0, pitch: 0, ly: 0, lx: 0, fzz: 0, hap: 1, smile: 1 }, 'io').to(200, { stw: 0.6 }, 'o').to(300, { stw: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Preen', 'Preens his fuzz like a little bird - left, right, left - then a proud stem bob.'],
        press: { fzz: 0.6 }, rel: relK('fzz', 0.8, ['kiwifuzz', 'head', 3]),
      },
      melo: { // watermelon slice: seeds jiggle (sdj)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          swing(t, 1500, 3, { tilt: 7, x: 2.5, armL: 40, armR: -10, sdj: 0.6 }, 'io');                                                                              // surfs the swell ...
          hopC(t, 8, { air: { sdj: 1 }, fall: { sdj: 0 }, ev: [['emit', 'melojuice', 'head', 3]] }); return loopN(t.rest(300)); })(), 'Happy', 'Surfs a little swell with his arms out, then a juicy hop that jiggles all his seeds.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, sdj: 1.4, sq: -0.08, lift: 2 }, 'o').e('emit', 'meloseed', 'head', 2).to(320, { lift: 0, sq: 0.04 }, 'i');
          t.to(500, { sdj: 0, sq: 0 }, 'io').to(300, { ly: 0.8 }, 'io').wait(250).to(300, { ly: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'His seeds jump in his flesh (two pop out!) - he checks the rest are still there.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.24, sdj: 0.8, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'melojuice', 'body', 5).wait(220);
          t.to(130, { sq: -0.14, sdj: 1.2, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.07, 3, 260); t.to(300, { sq: 0, sdj: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed so the juice splashes, then he springs back and his seeds jiggle.'],
        quirk: [(() => { const t = TL();
          t.to(300, { puff: 0.7, sq: 0.03 }, 'io').wait(250).to(80, { puff: -0.2, open: 0.3, mw: 0.4, sq: -0.04 }, 'o').e('emit', 'seed', 'mouth', 1).to(200, { puff: 0, open: 0, mw: 1, sq: 0 }, 'io'); // spits a seed
          t.to(400, { lx: 0.9, hyaw: 0.2 }, 'io').wait(400).to(300, { lx: 0, hyaw: 0, hap: 1, smile: 1 }, 'io').osc(600, 2, { sdj: 0.5 }, { sdj: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Seed spit', 'Puffs his cheeks and spits a seed - watches how far it went, very proud.'],
        press: { sdj: 0.6 }, rel: relK('sdj', 1, ['melojuice', 'head', 3]),
      },
      peachy: { // peach: blush, leaf (lfl / lsp)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.2 });
          t.to(400, { blush: 1, close: 0.5 }, 'io'); swing(t, 1600, 3, { tilt: 5, x: 1.5, lfl: 0.5 }, 'io'); t.to(300, { close: 0 }, 'io');                          // blushes, a soft sway
          hopC(t, 5, { air: { lfl: 0.8 }, fall: { lfl: 0 } }); t.to(300, { blush: 0 }, 'io'); return loopN(t.rest(300)); })(), 'Happy', 'Blushes with her eyes half shut, a soft sway, then a gentle hop that lifts her leaf.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(100, { wide: 1, open: 0.5, mw: 0.6, lfl: 1, sq: -0.05 }, 'o').to(320, o(both(10, -12), { armL: 30, armR: 30, blush: 1 }), 'io')            // gasps, paws to her cheeks
            .wait(400).to(400, o(NOHANDS, { armL: 0, armR: 0, lfl: 0, sq: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }), 'io').to(400, { blush: 0.3 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'A little gasp with her paws to her cheeks, blushing pink all over.'],
        squish: [(() => { const t = TL();
          t.to(200, { sq: -0.03 }, 'o').to(625, { sq: 0.27, blush: 0.8, close: 0.7, armL: 22, armR: 22 }, 'io').e('emit', 'peachjuice', 'body', 3).wait(300);             // soft and slow
          t.to(900, { sq: 0, close: 0, smile: 1 }, 'o').to(300, { lfl: 0.6 }, 'io').to(300, { lfl: 0, blush: 0, armL: 0, armR: 0, smile: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Sinks down soft and slow like a ripe peach (a little juice), blushing, and slowly rises.'],
        quirk: [(() => { const t = TL();
          t.to(320, o(hand(-1, 10, -12), { armL: 30, close: 0.5, blush: 0.6 }), 'io').osc(900, 3, { hLy: -10 }, { hLy: -13 }, 'io')                                    // rubs her fuzzy cheek
            .to(300, o(NOHANDS, { armL: 0, close: 0 }), 'io').to(800, { lsp: 1, hap: 1, smile: 1 }, 'io').to(1, { lsp: 0 }, 'l').to(400, { blush: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Fuzzy cheek', 'Rubs her fuzzy cheek, blushes, and her leaf gives a happy whirl.'],
        press: { blush: 0.8, close: 0.4 }, rel: relK('lfl', 0.8, ['peachjuice', 'head', 2]),
      },
      pitaya: { // dragonfruit: wings (wfl / wsp), bracts (brf), crown (crw), sparkle (spk)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(240, { wsp: 1, wfl: 1.2 }, 'o'); hopC(t, 9, { air: { brf: 0.8, crw: 0.8 }, fall: { brf: 0, crw: 0 } }); t.to(260, { spk: 1 }, 'io').e('emit', 'spark', 'head', 2)
            .to(300, { wsp: 0, wfl: 0, spk: 0 }, 'io'); return loopN(t.rest(300)); })(), 'Happy', 'Spreads his leafy wings and flaps up in a little hop, bracts flaring, sparkling.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.6, mw: 0.6, brf: 1.2, crw: 1.2, wsp: 1.3, sq: -0.1, x: -2 }, 'o').e('emit', 'pitseed', 'head', 4).wait(400);           // everything flares
          t.to(400, { brf: 0, crw: 0, wsp: 0, sq: 0, x: 0 }, 'io').to(300, { wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Every bract, his crown and both wings flare out at once like a startled dragon, then fold back.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.24, brf: 0.6, hap: 0.9, armL: 22, armR: 22 }, 'io').wait(220);
          t.to(120, { sq: -0.14, brf: 1.1, crw: 0.8, hap: 0, smile: 1, open: 0.3 }, 'o').e('emit', 'pitseed', 'body', 5); jelly(t, 0.07, 3, 240); t.to(300, { sq: 0, brf: 0, crw: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed, then his bracts burst open and a shower of little seeds flies out.'],
        quirk: [(() => { const t = TL();
          t.to(500, { wsp: 1.2, armL: 60, armR: 60, pitch: 0.08, close: 0.4 }, 'io').osc(700, 2, { wfl: 1.4 }, { wfl: 0.3 }, 'io').to(400, { wsp: 0, wfl: 0, armL: 0, armR: 0, pitch: 0, close: 0 }, 'io'); // wing stretch
          t.to(300, { spk: 1, hap: 1, smile: 1 }, 'io').e('emit', 'spark', 'head', 2).to(300, { spk: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Wing stretch', 'Stretches his leafy wings out wide, two big flaps, folds them and sparkles.'],
        press: { brf: 0.6, wsp: 0.4 }, rel: relK('brf', 0.9, ['pitseed', 'head', 3]),
      },
      tutti: { // fruit-basket fairy: wings (wfl), cherry / pear toss (fL / fR), crown bounce (cb)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(400, { wfl: 1.4, lift: 4, sq: -0.04 }, 'o').e('emit', 'fairydust', 'head', 3).to(1000, { spin: 360 }, 'io').to(1, { spin: 0 }, 'l').to(400, { lift: 0, wfl: 0, sq: 0 }, 'i'); // a fairy twirl
          t.to(160, { cb: 1 }, 'o').to(300, { cb: 0 }, 'io'); return loopN(t.rest(300)); })(), 'Happy', 'Flutters up off the ground in a sparkly fairy twirl, lands and her fruit crown bounces.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, sq: -0.08 }, 'o').to(520, { fR: 1 }, 'l').to(1, { fR: 0 }, 'l');                                          // her pear jumps out of the basket ...
          t.to(160, { armR: 60, wfl: 1.2 }, 'o').to(300, { armR: 0, wfl: 0, wide: 0, open: 0, mw: 1, sq: 0, hap: 1, smile: 1 }, 'io').e('emit', 'fairydust', 'body', 2); // ... she catches it
          return t.rest(400).done(); })(), 'Surprised', 'Her pear jumps out of the basket in fright - she catches it with a flutter of her wings.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.24, cb: -0.6, hap: 0.9, armL: 22, armR: 22 }, 'io').wait(220);
          t.to(130, { sq: -0.14, cb: 1, hap: 0, smile: 1, open: 0.3 }, 'o').e('emit', 'fairydust', 'head', 3); jelly(t, 0.7, 3, 260, 'cb'); t.to(220, { sq: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed into her basket, then she springs back up in a puff of fairy dust, crown bouncing.'],
        quirk: [(() => { const t = TL();
          t.to(300, { ly: 0.9, pitch: -0.12 }, 'io').wait(300).to(700, { fL: 1 }, 'l').to(1, { fL: 0 }, 'l').to(300, { ly: 0, pitch: 0, hap: 1, smile: 1 }, 'io')       // juggles her cherry
            .to(250, { wfl: 1 }, 'io').e('emit', 'fairydust', 'head', 2).to(300, { wfl: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Basket check', 'Peeks into her basket, tosses her cherry up and catches it, then a happy flutter.'],
        press: { cb: -0.4, wfl: 0.6 }, rel: relK('cb', 1, ['fairydust', 'head', 3]),
      },
      // ================================================== the eleven new fruits ==================================================
      nana: { // banana: her curve (cv: 1 = deep C, -1 = straight), the stalk sways with her
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          for (let i = 0; i < 2; i++) t.to(380, { cv: 0.8, tilt: -4, x: -1.5, armL: 40, armR: -6 }, 'io').to(380, { cv: -0.6, tilt: 4, x: 1.5, armL: -6, armR: 40 }, 'io'); // her curve flips side to side
          t.to(300, { cv: 0, tilt: 0, x: 0, armL: 0, armR: 0 }, 'io'); hopC(t, 7, { air: { cv: -0.5 }, fall: { cv: 0.3 } }); jelly(t, 0.4, 2, 260, 'cv');
          return loopN(t.rest(300)); })(), 'Happy', 'Flips her curve from side to side like a wiggly smile, then a hop that straightens her out.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, cv: -1, lift: 3, sq: -0.08, armL: 40, armR: 40 }, 'o').to(300, { lift: 0, sq: 0 }, 'i')                      // goes stiff as a stick
            .wait(400).to(500, { cv: 0.3, armL: 0, armR: 0 }, 'io').to(300, { cv: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'She goes stiff and straight as a stick in fright, then slowly curves back into her smile.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.22, cv: 0.9, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'banjuice', 'body', 2).wait(220);                   // folds into a deep C
          t.to(130, { sq: -0.14, cv: -0.6, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.5, 3, 300, 'cv'); t.to(220, { sq: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed, she folds into a deep C, then springs back and her curve wobbles.'],
        quirk: [(() => { const t = TL();
          t.to(600, { cv: -0.9, lift: 2, sq: -0.05, armL: 150, armR: 150, close: 0.6 }, 'io').wait(400)                                                                     // stretches tall and straight ...
            .to(600, { cv: 1, lift: 0, sq: 0.04, armL: 0, armR: 0, close: 0, tilt: -3 }, 'io').wait(300).to(500, { cv: 0, sq: 0, tilt: 0, hap: 1, smile: 1 }, 'io');  // ... then curls into a big C
          return t.wait(200).rest(450).done(); })(), 'Banana stretch', 'Stretches up tall and straight, then curls into a big lazy C and back.'],
        press: { cv: 0.5 }, rel: relK('cv', 0.8, ['banjuice', 'head', 2]),
      },
      bing: { // cherry: the long stem twirls (stw), the leaf flutters (lf)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          hopC(t, 8, { chain: true, air: { stw: 0.5, lf: 1 }, fall: { stw: 0, lf: 0.3 } }); land(t, 0.07, 2, 220); hopC(t, 9, { air: { stw: -0.5, lf: 1 }, fall: { stw: 0, lf: 0 } });
          t.to(160, { sq: -0.05 }, 'o').e('emit', 'chjuice', 'head', 2).to(200, { sq: 0 }, 'io'); return loopN(t.rest(300)); })(), 'Happy', 'Two bouncy hops - her stem twirls one way, then the other, the leaf fluttering.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, lf: 1.2, sq: -0.1, lift: 4 }, 'o').to(340, { lift: 0, sq: 0.05 }, 'i').to(220, { sq: 0 }, 'io');
          t.to(300, { ly: -0.9 }, 'io').osc(700, 2, { stw: 0.4 }, { stw: -0.4 }, 'io').to(300, { stw: 0, lf: 0, ly: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Bounces straight up in fright, then looks up as her stem sways to a stop.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.27, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'chjuice', 'body', 4).wait(220);
          t.to(120, { sq: -0.16, lf: 1, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.4, 3, 260, 'stw'); jelly(t, 0.07, 2, 240); t.to(240, { sq: 0, lf: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed so the cherry juice runs, then she bounces back and her stem wobbles.'],
        quirk: [(() => { const t = TL();
          t.to(340, { armR: 160, ly: -0.9, pitch: 0.06 }, 'io').to(1400, { stw: 1, lf: 0.6 }, 'io').to(1, { stw: -1 }, 'l').to(600, { stw: 0, lf: 0 }, 'io')                // twirls her stem round
            .to(300, { armR: 0, ly: 0, pitch: 0, hap: 1, smile: 1 }, 'io'); hopC(t, 5);
          return t.wait(200).rest(450).done(); })(), 'Stem twirl', 'Reaches up and twirls her stem all the way round, then a happy little hop.'],
        press: { lf: 0.6 }, rel: relK('stw', 0.5, ['chjuice', 'head', 3]),
      },
      plummy: { // plum (replaced Grapey, Nov 10): a little sugar-plum ballet dancer - tiptoe rises, pirouettes, bows; leaf (lf), stem twirl (stw) and his dusty
        // bloom (pol: 1 = polished off, glossy; it comes back as pol returns to 0)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(320, { lift: 2, sq: -0.05, armL: 150, armR: 150 }, 'io');                                                                                         // up on tiptoe, arms over his head
          spinR(t, 1100, 360, { lf: 1, footR: 1.6 }); t.to(300, { lift: 0, sq: 0.04, armL: 60, armR: 60, footR: 0, lf: 0 }, 'io').to(200, { sq: 0 }, 'io');   // a pirouette
          t.to(320, { pitch: -0.12, ly: 0.4, armL: 20, armR: 90, close: 0.5 }, 'io').e('emit', 'heart', 'head', 1).wait(260).to(320, { pitch: 0, ly: 0, armL: 0, armR: 0, close: 0 }, 'io'); // a little bow
          return loopN(t.rest(300)); })(), 'Happy', 'Rises on tiptoe with his arms over his head, a pirouette and a little bow.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, lf: 1.2, sq: -0.1, lift: 4, armL: 140, armR: 140, footL: 1.2, footR: 1.2 }, 'o')              // leaps up like a startled ballerina
            .to(340, { lift: 0, sq: 0.05, footL: 0, footR: 0 }, 'i').to(220, { sq: 0 }, 'io');
          t.to(320, o(both(7, 8), { armL: 24, armR: 24, ly: 0.5, pitch: -0.08 }), 'io');                                                                       // hands to his tummy ...
          t.osc(700, 2, { hLx: 9, hRx: -9, pol: 0.4 }, { hLx: 5, hRx: -5, pol: 0.15 }, 'io');                                                                  // ... smooths his bloom
          t.to(320, o(NOHANDS, { armL: 0, armR: 0, ly: 0, pitch: 0, lf: 0, pol: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }), 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Leaps up with his arms over his head like a startled ballerina, then smooths his tummy and smiles.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.26, pol: 0.5, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'pljuice', 'body', 4).wait(220);       // squashed shiny, plum juice
          t.to(120, { sq: -0.15, lf: 1, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.4, 3, 260, 'stw'); jelly(t, 0.07, 2, 240);
          t.to(260, { sq: 0, lf: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io').to(700, { pol: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed so the plum juice runs and his dusty bloom rubs shiny, then he springs back and his stem wobbles.'],
        quirk: [(() => { const t = TL();
          t.to(320, o(hand(1, 7, 8), { armR: 26, ly: 0.6, pitch: -0.1 }), 'io');                                                                              // looks down, a hand on his tummy
          for (let i = 0; i < 3; i++) t.to(230, { hRx: -10, hRy: 10, pol: 0.3 + i * 0.25 }, 'io').to(230, { hRx: -5, hRy: 6 }, 'io');                         // polishes his bloom off in little circles
          t.to(320, o(NOHANDS, { armR: 0, ly: 0, pitch: 0, pol: 1, hap: 1, smile: 1 }), 'io').e('emit', 'spark', 'head', 3).wait(300)                           // shiny!
            .to(340, { armL: 60, armR: 150, tilt: -4, winkR: 1 }, 'io').wait(450).to(320, { armL: 0, armR: 0, tilt: 0, winkR: 0 }, 'io')                       // admires himself, a pose
            .to(1500, { pol: 0 }, 'io');                                                                                                                        // the dusty bloom slowly comes back
          return t.wait(200).rest(450).done(); })(), 'Polish', 'Rubs the dusty bloom off his tummy in little circles until he shines, strikes a pose, and the bloom slowly comes back.'],
        press: { lf: 0.6, pol: 0.3 }, rel: relK('stw', 0.5, ['pljuice', 'head', 3]),
      },
      clemmy: { // clementine: zest spritz, leaves (lf flutter, stw twirl)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          let a = spinR(t, 700, 360, { armL: 50, armR: 50, lf: 1 }); t.at(a + 701).e('emit', 'zest', 'head', 4).to(200, { armL: 0, armR: 0, lf: 0 }, 'io');               // a zippy spin
          hopC(t, 8, { air: { stw: 0.4 }, fall: { stw: 0 }, ev: [['emit', 'zest', 'head', 3]] }); return loopN(t.rest(300)); })(), 'Happy', 'A zippy spin that sprays zesty mist, then a quick hop.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(70, { wide: 1, open: 0.5, mw: 0.7, sq: -0.1, lift: 3, lf: 1.2 }, 'o').e('emit', 'zest', 'head', 6).to(300, { lift: 0, sq: 0.04 }, 'i');        // a burst of zest
          t.to(240, { sq: 0 }, 'io').to(300, { lx: -0.8 }, 'io').to(300, { lx: 0.8 }, 'io').to(300, { lx: 0, lf: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Jumps with a burst of zesty spray, her leaves flapping, and looks around.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.24, hap: 0.9, armL: 22, armR: 22, close: 0.4 }, 'io').e('emit', 'zest', 'head', 6).wait(220);
          t.to(120, { sq: -0.15, lf: 1, close: 0, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.08, 3, 240); t.to(240, { sq: 0, lf: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squeezed so her peel spritzes zesty mist, then she pops back.'],
        quirk: [(() => { const t = TL();
          t.to(1200, { stw: 1, lf: 0.8 }, 'io').to(1, { stw: -1 }, 'l').to(400, { stw: 0, lf: 0 }, 'io');                                                              // twirls her leaves
          t.to(300, { pitch: 0.08, close: 0.6, puff: 0.3 }, 'io').e('emit', 'zest', 'head', 2).wait(300).to(300, { pitch: 0, close: 0, puff: 0, hap: 1, smile: 1 }, 'io'); // breathes in her own zest
          return t.wait(200).rest(450).done(); })(), 'Zesty sniff', 'Twirls her leaves round, then breathes in her own zesty smell with a happy sigh.'],
        press: { lf: 0.6, close: 0.3 }, rel: relK('lf', 1, ['zest', 'head', 5]),
      },
      appy: { // green apple: leaf (lf / stw), crisp + shiny
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(140, { sq: 0.06 }, 'o').to(160, { sq: -0.04 }, 'o').e('emit', 'spark', 'head', 2).to(200, { sq: 0 }, 'io');                                            // crisp little bounce
          hopC(t, 8, { chain: true, air: { lf: 1 }, fall: { lf: 0 } }); land(t, 0.06, 2, 220); swing(t, 900, 2, { tilt: 4, lf: 0.6 }, 'io');
          return loopN(t.rest(300)); })(), 'Happy', 'A crisp little bounce with a sparkle, a hop and a cheerful sway of her leaf.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, lf: 1, sq: -0.06 }, 'o').wait(300);
          t.to(260, { lx: -0.9, hyaw: -0.2 }, 'io').wait(200).to(260, { lx: 0.9, hyaw: 0.2 }, 'io').wait(200).to(300, { lx: 0, hyaw: 0, ly: 0.8, pitch: -0.12 }, 'io')     // a worm?! looks all round herself
            .wait(250).to(300, { ly: 0, pitch: 0, lf: 0, sq: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Freezes, then checks herself all over for worms - none, phew.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.2, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'apjuice', 'body', 3).wait(200);                              // a firm, crisp apple
          t.to(110, { sq: -0.12, lf: 1, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.05, 2, 220); t.to(240, { sq: 0, lf: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'A crisp apple squashes less - a little juice and a quick bounce back.'],
        quirk: [(() => { const t = TL();
          t.to(320, o(both(6, 8), { armL: 22, armR: 22, ly: 0.6, pitch: -0.08 }), 'io').osc(1200, 4, { hLy: 6, hRy: 10 }, { hLy: 10, hRy: 6 }, 'io')               // polishes herself shiny
            .to(300, o(NOHANDS, { armL: 0, armR: 0, ly: 0, pitch: 0, hap: 1, smile: 1 }), 'io').e('emit', 'spark', 'head', 3).to(200, { lf: 0.6 }, 'io').to(300, { lf: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Polish', 'Polishes herself with both paws until she shines and sparkles.'],
        press: { lf: 0.5 }, rel: relK('lf', 1, ['apjuice', 'head', 2]),
      },
      blueby: { // blueberry: she rolls (rl, degrees) like a ball, her star crown spins (stw)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(400, { rl: -28, x: -4, armR: 40 }, 'io').to(500, { rl: 28, x: 4, armR: 0, armL: 40 }, 'io').to(400, { rl: 0, x: 0, armL: 0 }, 'io');                   // rocks and rolls
          hopC(t, 7, { air: { stw: 0.6 }, fall: { stw: 0 } }); return loopN(t.rest(300)); })(), 'Happy', 'Rocks and rolls on her round tummy from side to side, then a hop that spins her crown.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, sq: -0.06 }, 'o').to(700, { rl: -360, x: -10 }, 'io').to(1, { rl: 0 }, 'l')                                   // rolls right over backwards
            .to(300, { sq: 0.05 }, 'o').to(400, { x: 0, sq: 0 }, 'io').e('blink').to(300, { wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Startled, she rolls right over and back onto her feet, blinking.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.27, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'bljuice', 'body', 3).wait(220);
          t.to(120, { sq: -0.16, crf: 0.8, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.08, 3, 240); t.to(260, { sq: 0, crf: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed like a squishy berry, then she pops back and her crown flares.'],
        quirk: [(() => { const t = TL();
          t.to(900, { rl: 360, x: 10, lx: 0.6 }, 'io').to(1, { rl: 0 }, 'l').wait(300).to(900, { rl: -360, x: 0, lx: -0.4 }, 'io').to(1, { rl: 0 }, 'l')                    // rolls away and back
            .to(300, { lx: 0, hap: 1, smile: 1 }, 'io').to(500, { stw: 0.8 }, 'io').to(400, { stw: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Roll about', 'Rolls away a little, rolls back again and spins her crown.'],
        press: { crf: 0.5 }, rel: relK('crf', 0.8, ['bljuice', 'head', 2]),
      },
      coco: { // coconut: his fibres stand on end (fz), the sprout (lf), a hollow knock
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(300, o(both(6, 8), { armL: 22, armR: 22 }), 'io'); for (let i = 0; i < 4; i++) t.to(120, { [i % 2 ? 'hRy' : 'hLy']: 12, sq: 0.03 }, 'o').e('emit', 'knock', 'body', 1).to(160, { hLy: 8, hRy: 8, sq: 0 }, 'io'); // bongo on his belly
          t.to(300, o(NOHANDS, { armL: 0, armR: 0 }), 'io'); swing(t, 1200, 3, { tilt: 5, x: 1.5, lf: 0.6 }, 'io'); return loopN(t.rest(300)); })(), 'Happy', 'Drums a little bongo beat on his hollow belly, then sways like a palm tree.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(70, { wide: 1, open: 0.5, mw: 0.7, fz: 1.2, lf: 1, sq: -0.06 }, 'o').e('emit', 'fibre', 'head', 4).wait(500);                                  // every hair stands on end
          t.to(400, { fz: 0, lf: 0, sq: 0 }, 'io').to(300, { wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Every hair on him stands on end and a few fibres fly, then it all lies back down.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.04 }, 'o').to(325, { sq: 0.14, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'knock', 'head', 1).wait(200);                                   // a hard nut: hardly squashes
          t.to(110, { sq: -0.08, fz: 0.8, hap: 0, smile: 1, open: 0.3 }, 'o').e('emit', 'cocomilk', 'head', 2); jelly(t, 0.04, 2, 200); t.to(300, { sq: 0, fz: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'A hard nut hardly squashes - knock! - his hair puffs and a drop of coconut milk splashes.'],
        quirk: [(() => { const t = TL();
          t.to(500, { rl: 24, x: 3 }, 'io').to(400, { rl: 0, x: 0 }, 'io');                                                                                               // rocks on his round bottom
          t.to(320, { armR: 150, hyaw: 0.15 }, 'io'); for (let i = 0; i < 3; i++) t.to(110, { armR: 138, sq: 0.03 }, 'o').e('emit', 'knock', 'head', 1).to(180, { armR: 150, sq: 0 }, 'io'); // knocks on his own head
          t.to(400, { lx: 0.9, hyaw: 0.25, close: 0.3 }, 'io').wait(300).to(300, { armR: 0, lx: 0, hyaw: 0, close: 0, hap: 1, smile: 1 }, 'io');                       // listens: hollow!
          return t.wait(200).rest(450).done(); })(), 'Knock knock', 'Knocks on his own head three times and listens - hollow! He grins.'],
        press: { fz: 0.6 }, rel: relK('fz', 0.9, ['fibre', 'head', 3]),
      },
      perry: { // pear: bottom-heavy - he wobbles like a roly-poly (tilt springs back about his round bottom)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(300, { tilt: 9, x: 1.2, armL: 40 }, 'o'); jelly(t, 9, 4, 420, 'tilt'); t.to(200, { armL: 0, x: 0 }, 'io'); hopC(t, 6, { air: { lf: 1 }, fall: { lf: 0 } });
          return loopN(t.rest(300)); })(), 'Happy', 'Tips over on his round bottom and wobbles back like a roly-poly, then a happy hop.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, armL: 60, armR: 60 }, 'o').to(260, { tilt: -16, x: -2 }, 'o').to(300, { tilt: 14, x: 2 }, 'io')               // nearly topples
            .to(260, { tilt: -8, x: -1 }, 'io').to(240, { tilt: 4, x: 0 }, 'io').to(200, { tilt: 0 }, 'io').to(300, { armL: 0, armR: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Wobbles wildly, arms out, nearly topples over - and rights himself.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(400, { sq: 0.24, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'pearjuice', 'body', 3).wait(220);
          t.to(120, { sq: -0.14, hap: 0, smile: 1, open: 0.3, lf: 1 }, 'o'); jelly(t, 6, 3, 360, 'tilt'); t.to(240, { sq: 0, lf: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed (a little pear juice), then he springs back and wobbles on his bottom.'],
        quirk: [(() => { const t = TL();
          t.to(700, { tilt: 15, x: 2, close: 0.4 }, 'io').wait(200).to(200, { tilt: -6, x: -1, close: 0, wide: 0.5 }, 'o'); jelly(t, 6, 3, 400, 'tilt');                     // leans way over, springs back
          t.to(300, { x: 0, wide: 0, hap: 1, smile: 1 }, 'io'); return t.wait(200).rest(450).done(); })(), 'Wobble', 'Leans further and further over... and springs back upright with a wobble.'],
        press: { lf: 0.5 }, rel: relK('tilt', 8, ['pearjuice', 'head', 2]),
      },
      grana: { // pomegranate: regal crown (stw spin, crf flare), arils (seeds) burst
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.2 });
          t.to(400, { pitch: -0.16, close: 0.6, armL: 40, armR: -10 }, 'io').wait(200).to(400, { pitch: 0, close: 0, armL: 0, armR: 0 }, 'io');                          // a royal nod
          t.to(200, { crf: 1 }, 'o').e('emit', 'arils', 'head', 4).to(400, { crf: 0 }, 'io').to(800, { stw: 0.8 }, 'io').to(500, { stw: 0 }, 'io');
          return loopN(t.rest(300)); })(), 'Happy', 'A dignified royal nod, then his crown flares and a shower of ruby seeds sparkles out.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, crf: 1.1, sq: -0.06 }, 'o').e('emit', 'arils', 'head', 5).wait(300);
          t.to(320, { armL: 150, armR: 150, ly: -0.8 }, 'io').to(400, { crf: 0, stw: 0.3 }, 'io').to(300, { stw: 0 }, 'io')                                             // straightens his crown
            .to(300, { armL: 0, armR: 0, ly: 0, sq: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'His crown flares and seeds burst out - he composes himself and straightens his crown.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(400, { sq: 0.23, hap: 0.9, armL: 22, armR: 22 }, 'io').wait(220);
          t.to(120, { sq: -0.13, crf: 1, hap: 0, smile: 1, open: 0.3 }, 'o').e('emit', 'arils', 'head', 6); jelly(t, 0.06, 2, 260); t.to(300, { sq: 0, crf: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed, then he springs back and his crown sprays ruby seeds.'],
        quirk: [(() => { const t = TL();
          t.to(340, { armL: 150, armR: 150, ly: -0.9 }, 'io').osc(900, 2, { stw: 0.3 }, { stw: -0.2 }, 'io').to(300, { stw: 0 }, 'io')                                // adjusts his crown just so
            .to(300, { armL: 0, armR: 0, ly: 0 }, 'io').to(400, { pitch: 0.08, close: 0.6, hap: 1, smile: 1 }, 'io').wait(400).to(300, { pitch: 0, close: 0 }, 'io');   // chin up
          return t.wait(200).rest(450).done(); })(), 'Crown adjust', 'Straightens his crown just so with both paws, then lifts his chin like a king.'],
        press: { crf: 0.5 }, rel: relK('crf', 1, ['arils', 'head', 4]),
      },
      mangie: { // mango: dramatic, sunny; leaf flick (lf / stw)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(300, { tilt: -6, lean: -3, armL: 150, armR: 20, lf: 1 }, 'io').to(240, { stw: 0.5 }, 'o').to(300, { stw: 0 }, 'io')                                       // a dramatic hair flip
            .to(300, { tilt: 0, lean: 0, armL: 0, armR: 0, lf: 0 }, 'io'); hopC(t, 7, { ev: [['emit', 'mjuice', 'head', 2]] }); return loopN(t.rest(300)); })(), 'Happy', 'A dramatic leaf flip like tossing her hair, then a sunny hop.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(100, { wide: 1, open: 0.6, mw: 0.6, lf: 1 }, 'o').to(320, o(hand(1, 10, -12), { armR: 30, lean: 3, tilt: 3 }), 'io').wait(500)                  // a dramatic gasp
            .to(400, o(NOHANDS, { armR: 0, lean: 0, tilt: 0, lf: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }), 'io');
          return t.rest(400).done(); })(), 'Surprised', 'A big dramatic gasp with a paw to her cheek - then she smiles as if nothing happened.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(400, { sq: 0.27, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'mjuice', 'body', 4).wait(220);
          t.to(130, { sq: -0.15, lf: 1, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.08, 3, 260); t.to(240, { sq: 0, lf: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed so the mango juice runs, then she bounces back.'],
        quirk: [(() => { const t = TL();
          t.to(600, { lean: -4, tilt: -4, pitch: 0.1, close: 1, armL: 120, armR: 120, blush: 0.8 }, 'io').osc(1600, 2, { lf: 0.6 }, { lf: 0.1 }, 'io')                // sunbathes, ripening
            .to(500, { lean: 0, tilt: 0, pitch: 0, close: 0, armL: 0, armR: 0, lf: 0, hap: 1, smile: 1 }, 'io').to(400, { blush: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Sunbathe', 'Leans back with her paws behind her head and sunbathes, ripening to a blush.'],
        press: { lf: 0.6, blush: 0.5 }, rel: relK('lf', 1, ['mjuice', 'head', 3]),
      },
      razzy: { // raspberry: the drupelets jiggle (jig), sparkles, calyx spin (stw)
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(200, { jig: 1 }, 'io').osc(800, 4, { tilt: 4 }, { tilt: -4 }, 'io').to(150, { tilt: 0 }, 'io'); let a = spinR(t, 800, 360, { armL: 120, armR: 120, stw: 0.6 });  // jiggle shimmy + jazz-hands spin
          t.at(a + 801).e('emit', 'spark', 'head', 3).to(260, { armL: 0, armR: 0, stw: 0, jig: 0 }, 'io'); return loopN(t.rest(300)); })(), 'Happy', 'A jiggly shimmy (every bead wobbles), then a jazz-hands spin with sparkles.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(70, { wide: 1, open: 0.5, mw: 0.7, jig: 1.5, sq: -0.1, lift: 4 }, 'o').e('emit', 'spark', 'head', 3).to(320, { lift: 0, sq: 0.05 }, 'i');
          t.to(700, { jig: 0, sq: 0 }, 'io').to(300, { wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Jumps with every bead on her jiggling and a burst of sparkles.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(375, { sq: 0.27, jig: 0.6, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'rzjuice', 'body', 4).wait(220);
          t.to(130, { sq: -0.15, jig: 1.4, hap: 0, smile: 1, open: 0.3 }, 'o').to(800, { jig: 0 }, 'io'); t.to(240, { sq: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed so the raspberry juice runs, then all her beads wobble back.'],
        quirk: [(() => { const t = TL();
          t.to(300, { armL: 120, armR: 120, close: 0.5 }, 'io').osc(800, 4, { hLx: 2, hRx: -2, jig: 0.6 }, { hLx: -1, hRx: 1, jig: 0.2 }, 'io')                        // jazz hands, jiggling
            .to(300, o(NOHANDS, { armL: 0, armR: 0, close: 0, jig: 0, hap: 1, smile: 1 }), 'io').e('emit', 'spark', 'head', 3).to(600, { stw: 0.8 }, 'io').to(400, { stw: 0 }, 'io');
          return t.wait(200).rest(450).done(); })(), 'Sparkle', 'Jazz hands with a jiggle, a burst of sparkles and a twirl of her leafy top.'],
        press: { jig: 0.6 }, rel: relK('jig', 1.2, ['rzjuice', 'head', 3], { k: { sq: [[0, 0], [110, -0.15, 'o'], [250, 0.07, 'io'], [410, 0, 'io']], jig: [[0, 0.6], [150, 1.4, 'o'], [900, 0, 'io']], smile: [[0, 0], [150, 1, 'o'], [800, 1], [1100, 0, 'io']] } }),
      },
    };
    // a squeeze let-go per fruit: the body bounces back and its part springs from where the squeeze left it (or kicks out from rest)
    KEYS.forEach(k => { const M = MOVES[k], r = M.rel; if (!r || !r.__rel) return; const [ch, a, em, x] = r.__rel, from = (M.press || {})[ch] || 0;
      const kk = { sq: [[0, 0], [110, -0.15, 'o'], [250, 0.07, 'io'], [410, -0.02, 'io'], [560, 0, 'io']], smile: [[0, 0], [150, 1, 'o'], [800, 1], [1100, 0, 'io']] };
      kk[ch] = from ? [[0, from], [160, -from * 0.7, 'o'], [380, from * 0.35, 'io'], [600, -from * 0.12, 'io'], [800, 0, 'io']] : [[0, 0], [160, a, 'o'], [380, -a * 0.4, 'io'], [600, a * 0.15, 'io'], [800, 0, 'io']];
      M.rel = Object.assign({ dur: 1100, k: kk, em: em ? [em] : [] }, x || {}); });

    // ---------- signature dances for the 11 new fruits (each made of what only that body can do) ----------
    const DANCES = {
      // Nana: her curve is the dance - flips side to side on the beat, a hula of the hips (the bottom swings while her face stays), stretch straight to the sky,
      // a spin that whips her curve round, a 'banana split' (squats into a deep C, arms wide) and a curvy pose + wink
      nana: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 460;
        for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; t.to(B, { cv: d * 0.9, tilt: -d * 4, x: -d * 1.5, [d < 0 ? 'armL' : 'armR']: 60, [d < 0 ? 'armR' : 'armL']: -6, footL: d < 0 ? 2 : 0, footR: d > 0 ? 2 : 0 }, 'io'); }
        t.to(300, { cv: 0, tilt: 0, x: 0, armL: 0, armR: 0, footL: 0, footR: 0 }, 'io');
        t.osc(1600, 4, { cv: 0.6, x: 2.5, lean: 2 }, { cv: -0.4, x: -2.5, lean: -2 }, 'io').to(250, { cv: 0, x: 0, lean: 0 }, 'io');                                      // hip hula (the curve swings)
        t.to(500, { cv: -1, lift: 3, sq: -0.06, armL: 165, armR: 165 }, 'io').wait(250).to(400, { cv: 0.3, lift: 0, sq: 0.03, armL: 60, armR: 60 }, 'io');              // straight up to the sky
        let a = spinR(t, 1100, 360, { armL: 80, armR: 80 }); t.at(a).to(500, { cv: 0.8 }, 'o').to(600, { cv: 0 }, 'io'); t.at(a + 1101);                                 // spin whips the curve
        t.to(400, { cv: 1, sq: 0.1, armL: 100, armR: 100, footL: 1.5, footR: 1.5 }, 'io').e('emit', 'banjuice', 'head', 2).wait(300).to(400, { cv: 0, sq: 0, armL: 0, armR: 0, footL: 0, footR: 0 }, 'io'); // banana split
        t.to(300, { cv: 0.6, tilt: -5, armR: 150, winkR: 1 }, 'io').e('emit', 'heart', 'head', 1).wait(500).to(300, { cv: 0, tilt: 0, armR: 0, winkR: 0 }, 'io');
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Banana Boogie', 'Her curve flips from side to side on the beat, a hip hula, stretches straight up to the sky, a spin that whips her curve round, a banana-split squat and a curvy pose with a wink.'],
      // Bing: hops with her stem twirling like a propeller, a helicopter lift-off (spinning stem lifts her), bounce-bounce-bounce, a stem pirouette, juicy finale
      bing: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 420;
        for (let i = 0; i < 3; i++) hopC(t, 7, { chain: i < 2, air: { stw: (i % 2 ? -1 : 1) * 0.5, lf: 1 }, fall: { stw: 0, lf: 0.3 } }); land(t, 0.07, 2, 220);
        t.to(600, { stw: 1, lf: 1, armL: 80, armR: 80 }, 'i').to(1, { stw: -1 }, 'l').to(700, { stw: 1, lift: 9, sq: -0.06 }, 'l').to(1, { stw: -1 }, 'l')                      // the stem spins up ...
          .to(700, { stw: 1, lift: 9 }, 'l').to(1, { stw: -1 }, 'l').to(800, { stw: 0, lift: 0, sq: 0.05, armL: 20, armR: 20, lf: 0 }, 'io').to(200, { sq: 0 }, 'io');   // ... helicopter lift-off
        for (let i = 0; i < 3; i++) t.to(B / 2, { sq: 0.1, x: (i - 1) * 2 }, 'o').to(B / 2, { sq: -0.04, lift: 2.5 }, 'o').to(B / 3, { lift: 0, sq: 0 }, 'i');
        let a = spinR(t, 1200, 720, { armL: 90, armR: 90 }); t.at(a).to(600, { stw: 0.6 }, 'io').to(600, { stw: 0 }, 'io'); t.at(a + 1201).to(200, { x: 0, armL: 0, armR: 0 }, 'io');
        t.to(300, { armL: 150, armR: 150, sq: -0.06, lift: 2 }, 'o').e('emit', 'chjuice', 'head', 4).to(200, { lift: 0, sq: 0.06 }, 'i').to(300, { armL: 0, armR: 0, sq: 0 }, 'io').e('emit', 'heart', 'head', 1).wait(300);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Stem Twirl', 'Hops with her stem twirling, then spins it up like a propeller for a helicopter lift-off, three bouncy bounces, a double pirouette and a juicy finale.'],
      // Plummy (replaced Grapey, Nov 10): a little ballet - up on tiptoe with his arms over his head, two plies (bend low, arms out - rise), a double
      // pirouette on one foot, an arabesque (leans out on one foot, arm long, the back foot up), tiny tiptoe steps there and back (bourree), a grand leap,
      // a shiny polish and a deep bow
      plummy: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 480;
        t.to(B, { armL: 150, armR: 150, lift: 2, sq: -0.05, close: 0.4 }, 'io').wait(200).to(B, { armL: 60, armR: 60, lift: 0, sq: 0, close: 0 }, 'io');       // en couronne, on tiptoe
        for (let i = 0; i < 2; i++) t.to(B, { sq: 0.12, armL: 90, armR: 90, pitch: -0.05 }, 'io').to(B, { sq: -0.05, lift: 2, armL: 150, armR: 150, pitch: 0.04 }, 'io'); // plies
        t.to(260, { sq: 0, lift: 0, armL: 90, armR: 90, pitch: 0 }, 'io');
        spinR(t, 1300, 720, { armL: 150, armR: 150, footR: 2, lift: 1.5, lf: 1 }); t.to(300, { footR: 0, lift: 0, lf: 0, armL: 60, armR: 60 }, 'io');         // double pirouette
        t.to(600, { pitch: 0.08, lean: 3, tilt: -6, armL: 40, armR: 140, footL: 2.4, stw: 0.4 }, 'io').wait(500)                                                // arabesque
          .to(500, { pitch: 0, lean: 0, tilt: 0, armL: 60, armR: 60, footL: 0, stw: 0 }, 'io');
        t.to(200, { lift: 1.5 }, 'io'); for (let i = 0; i < 8; i++) t.to(115, { x: (i < 4 ? i + 1 : 7 - i) * 1.4, footL: i % 2 ? 0.9 : 0, footR: i % 2 ? 0 : 0.9 }, 'io'); // bourree
        t.to(160, { footL: 0, footR: 0, lift: 0, x: 0 }, 'io');
        jump(t, { h: 9, ant: 170, up: 240, c: 0.12, arm: 30, air: { footL: 2.2, footR: 2.2, armL: 150, armR: 70, lf: 1 }, fall: { footL: 0, footR: 0, armL: 60, armR: 60, lf: 0 } }); land(t, 0.06, 2, 220); // grand leap
        t.to(300, { pol: 1, armL: 0, armR: 0 }, 'io').e('emit', 'spark', 'head', 3).wait(300);                                                                 // shiny
        t.to(600, { pitch: -0.2, ly: 0.6, armR: 100, armL: 20, sq: 0.06, close: 0.6 }, 'io').e('emit', 'heart', 'head', 1).wait(400)                           // a deep bow
          .to(500, { pitch: 0, ly: 0, armR: 0, armL: 0, sq: 0, close: 0 }, 'io').to(700, { pol: 0 }, 'io');
        return t.rest(300).loop({ stretch: 0.5 }); })(), 'Sugar Plum Twirl', 'A little ballet: up on tiptoe with his arms over his head, two plies, a double pirouette, an arabesque, tiny tiptoe steps there and back, a grand leap, a shiny polish and a deep bow.'],
      // Clemmy: spins like a top (fast, a wobble as she slows), zesty spritz bursts on the beat, leaf twirls, little zippy hops, a peel-pop finale
      clemmy: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 380;
        for (let i = 0; i < 4; i++) t.to(B / 2, { sq: 0.06, [i % 2 ? 'footR' : 'footL']: 2.2, x: (i % 2 ? 1 : -1) * 1.2 }, 'o').e('emit', 'zest', 'head', 2).to(B / 2, { sq: 0, footL: 0, footR: 0 }, 'i');
        t.to(200, { x: 0, armL: 60, armR: 60 }, 'io'); let a = spinR(t, 2200, 1440, { lf: 1 }); t.at(a + 1500).osc(700, 3, { tilt: 4 }, { tilt: -4 }, 'io'); t.at(a + 2201)  // spinning top
          .to(200, { tilt: 0, lf: 0, armL: 0, armR: 0 }, 'io').e('emit', 'zest', 'head', 5);
        t.to(1000, { stw: 1, lf: 0.8 }, 'io').to(1, { stw: -1 }, 'l').to(400, { stw: 0, lf: 0 }, 'io');                                                                    // leaf twirl
        for (let i = 0; i < 2; i++) hopC(t, 8, { chain: i < 1, air: { lf: 1 }, fall: { lf: 0 }, ev: [['emit', 'zest', 'head', 2]] });
        t.to(240, { armL: 150, armR: 150, sq: -0.08, lift: 2 }, 'o').e('emit', 'zest', 'head', 6).to(200, { lift: 0, sq: 0.05 }, 'i').to(300, { armL: 0, armR: 0, sq: 0 }, 'io').wait(300);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Peel Spin', 'Zippy steps that spritz zest, then she spins like a top (wobbling as she slows), twirls her leaves, two quick hops and a zesty finale.'],
      // Appy: bobbing for apples - she floats on the water and bobs (lift dips + pitch rocks), a dunk under and pop up, a polish spin, a crunch-beat stomp, shiny pose
      appy: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 520;
        for (let i = 0; i < 4; i++) t.to(B, { lift: i % 2 ? 1 : -2.5, tilt: i % 2 ? -4 : 4, sq: i % 2 ? -0.02 : 0.04, lf: i % 2 ? 0.2 : 0.6 }, 'io');                     // bobbing on the water
        t.to(300, { lift: 0, tilt: 0, sq: 0 }, 'io').to(260, { sq: 0.14, pitch: -0.1, close: 1 }, 'io').to(140, { lift: -4, sq: 0.06 }, 'i').e('emit', 'drop', 'body', 5)  // dunk ...
          .to(260, { lift: 6, sq: -0.08, close: 0, wide: 0.6, pitch: 0.08 }, 'o').to(300, { lift: 0, sq: 0.04, wide: 0, pitch: 0 }, 'i').e('emit', 'splash', 'body', 1).to(200, { sq: 0 }, 'io'); // ... and pops up
        let a = spinR(t, 1000, 360, { armL: 30, armR: 30 }); t.at(a + 1001).e('emit', 'spark', 'head', 3).to(200, { armL: 0, armR: 0 }, 'io');                          // polish spin
        for (let i = 0; i < 4; i++) t.to(B / 2, { sq: 0.08, [i % 2 ? 'footR' : 'footL']: 2.4, armL: i % 2 ? 40 : 10, armR: i % 2 ? 10 : 40 }, 'o').to(B / 2, { sq: 0, footL: 0, footR: 0 }, 'i');
        t.to(300, { armL: 0, armR: 0 }, 'io').to(300, { armR: 150, tilt: -4, winkR: 1, lf: 1 }, 'io').e('emit', 'spark', 'head', 2).wait(450).to(300, { armR: 0, tilt: 0, winkR: 0, lf: 0 }, 'io');
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Apple Bob', 'Bobs like an apple floating in a tub, dunks under and pops back up with a splash, a polishing spin, crunchy stomps and a shiny wink.'],
      // Blueby: she ROLLS - rock and roll on her round tummy, rolls a full turn one way and back, a roly-poly somersault, crown spin, roll-away bow
      blueby: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 480;
        for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; t.to(B, { rl: d * 26, x: d * 4, [d < 0 ? 'armR' : 'armL']: 60, [d < 0 ? 'armL' : 'armR']: 0 }, 'io'); }   // rock and roll
        t.to(300, { rl: 0, x: 0, armL: 0, armR: 0 }, 'io');
        t.to(1000, { rl: 360, x: 14 }, 'io').to(1, { rl: 0 }, 'l').wait(150).to(1000, { rl: -360, x: 0 }, 'io').to(1, { rl: 0 }, 'l');                                // a full roll there and back
        jump(t, { h: 12, ant: 180, up: 280, c: 0.2, arm: 90, air: { rl: -360, stw: 0.6 }, fall: { stw: 0 } }); t.to(1, { rl: 0 }, 'l');                                     // somersault
        t.to(900, { stw: 1, crf: 0.6, armL: 120, armR: 120 }, 'io').to(1, { stw: -1 }, 'l').to(500, { stw: 0, crf: 0, armL: 0, armR: 0 }, 'io');                          // crown spin
        t.to(500, { rl: -20, x: -3, pitch: -0.12, close: 0.6 }, 'io').wait(300).to(400, { rl: 0, x: 0, pitch: 0, close: 0 }, 'io').e('emit', 'heart', 'head', 1).wait(200);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Blueberry Roll', 'Rock and roll on her round tummy, a full roll away and back, a roly-poly somersault, her star crown spinning and a rolling bow.'],
      // Coco (no legs): island drummer - bongo beats on his hollow belly (knocks), a palm-tree sway, hair-raising shake (fibres stand on end), a coconut
      // drop (jumps high, lands with a heavy thud, no bounce), rolls away and back like a coconut does, knock-knock on his head to the beat, chill pose
      coco: [(() => { const t = TL({ smile: 0.9, hap: 1, rig: 1 }), B = 400;                                                                                      // rig 1: a hard nut keeps his shape all dance (user)
        t.to(250, o(both(6, 8), { armL: 22, armR: 22 }), 'io'); for (let i = 0; i < 8; i++) t.to(B / 2, { [i % 2 ? 'hRy' : 'hLy']: 12, sq: 0.03, tilt: i % 2 ? 2 : -2 }, 'o').e('emit', 'knock', 'body', 1).to(B / 2, { hLy: 8, hRy: 8, sq: 0 }, 'io');
        t.to(250, o(NOHANDS, { armL: 0, armR: 0, tilt: 0 }), 'io');
        swing(t, 2000, 3, { tilt: 7, x: 2, armL: 50, armR: -20, lf: 0.8 }, 'io');                                                                                         // palm-tree sway
        t.to(200, { fz: 1.2, wide: 0.5 }, 'o'); shake(t, { P: 85, head: 0.25, roll: 3, body: 0.8, env: [0.5, 0.9, 1, 1, 0.8, 0.5, 0.25] }); t.to(300, { fz: 0, wide: 0 }, 'io').e('emit', 'fibre', 'head', 4); // hair-raising shake
        jump(t, { h: 14, ant: 200, up: 300, dn: 220, c: 0.2, arm: 100, st: 0.4 }); t.e('emit', 'knock', 'body', 1).e('emit', 'dust', 'body', 4);                            // coconut drop: a heavy thud
        t.to(900, { rl: 360, x: 12, armL: 30, armR: 30 }, 'io').to(1, { rl: 0 }, 'l').wait(150).to(900, { rl: -360, x: 0 }, 'io').to(1, { rl: 0 }, 'l').to(200, { armL: 0, armR: 0 }, 'io'); // rolls away and back (no legs)
        t.to(300, { armR: 150, hyaw: 0.15 }, 'io'); for (let i = 0; i < 3; i++) t.to(110, { armR: 138, sq: 0.03 }, 'o').e('emit', 'knock', 'head', 1).to(170, { armR: 150, sq: 0 }, 'io');
        t.to(300, { armR: 0, hyaw: 0 }, 'io').to(400, { lean: -3, close: 0.6, armL: 120, armR: 120 }, 'io').wait(500).to(400, { lean: 0, close: 0, armL: 0, armR: 0 }, 'io');
        return t.rest(300).loop({ stretch: 0, soft: 0 }); })(), 'Coconut Knock', 'Bongo beats on his hollow belly, a palm-tree sway, a hair-raising shake, a coconut drop that lands with a thud, a roll away and back, knock-knock on his head and a chill pose.'],
      // Perry: the weeble wobble - tips far over on his round bottom and springs back on the beat (arms out for balance), a wobble circle (tilt + lean going round),
      // nearly falls, a spin on his bottom, a heavy little hop, wobbly pose
      perry: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 520;
        for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; t.to(B, { tilt: d * 14, x: d * 1.5, armL: d > 0 ? 70 : 10, armR: d < 0 ? 70 : 10 }, 'io'); }                // tips side to side
        t.to(300, { tilt: 0, x: 0, armL: 30, armR: 30 }, 'io');
        for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; t.to(200, { tilt: 8 * Math.cos(a), lean: 3 * Math.sin(a) }, 'l'); } t.to(200, { tilt: 0, lean: 0 }, 'io'); // wobble circle
        t.to(600, { tilt: -20, x: -2, wide: 0.6, armL: 80, armR: 80 }, 'i').to(160, { tilt: -14 }, 'o'); jelly(t, 8, 3, 380, 'tilt'); t.to(300, { x: 0, wide: 0, armL: 0, armR: 0 }, 'io'); // nearly falls
        let a = spinR(t, 1300, 360, { armL: 60, armR: 60, lf: 1 }); t.at(a).osc(1300, 3, { tilt: 4 }, { tilt: -4 }, 'io'); t.at(a + 1301).to(200, { tilt: 0, armL: 0, armR: 0, lf: 0 }, 'io');
        jump(t, { h: 6, ant: 200, up: 220, c: 0.2, arm: 40 }); t.e('emit', 'pearjuice', 'head', 2);
        t.to(300, { tilt: 8, armR: 150, winkR: 1 }, 'io'); jelly(t, 6, 3, 400, 'tilt'); t.to(300, { armR: 0, winkR: 0 }, 'io');
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Pear Wobble', 'Tips side to side on his round bottom like a roly-poly toy, wobbles round in a circle, nearly falls over, spins on his bottom, a heavy little hop and a wobbly wink.'],
      // Grana: a royal waltz (1-2-3 with turns), a slow regal bow, his crown spins and flares, seeds burst out like confetti, a royal wave, a proud pose
      grana: [(() => { const t = TL({ smile: 0.8, hap: 1 }), B = 520;
        for (let i = 0; i < 2; i++) { const d = i % 2 ? -1 : 1; t.to(B, { x: d * 3, tilt: d * 3, sq: 0.04, lift: 0 }, 'io').to(B * 0.7, { lift: 2, sq: -0.03 }, 'o').to(B * 0.7, { lift: 0, sq: 0 }, 'i');
          let a = spinR(t, 1100, d * 360, { armL: 40, armR: 40 }); t.at(a + 1101); }                                                                                       // waltz 1-2-3 + turn
        t.to(300, { x: 0, tilt: 0, armL: 0, armR: 0 }, 'io').to(600, { pitch: -0.25, close: 0.7, armL: 60, armR: -10 }, 'io').wait(300).to(500, { pitch: 0, close: 0, armL: 0, armR: 0 }, 'io'); // regal bow
        t.to(1200, { stw: 1, crf: 0.7 }, 'io').to(1, { stw: -1 }, 'l').to(500, { stw: 0, crf: 0 }, 'io');                                                                 // crown spin
        for (let i = 0; i < 3; i++) t.to(140, { crf: 1, sq: -0.05 }, 'o').e('emit', 'arils', 'head', 4).to(300, { crf: 0, sq: 0 }, 'io');                                 // seed confetti
        t.to(300, { armR: 150 }, 'io').osc(1000, 3, { armR: 135 }, { armR: 155 }, 'io').to(300, { armR: 0 }, 'io');                                                         // royal wave
        t.to(400, { pitch: 0.1, close: 0.5, armL: 30, armR: 30 }, 'io').e('emit', 'spark', 'head', 3).wait(500).to(400, { pitch: 0, close: 0, armL: 0, armR: 0 }, 'io');
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Seed Shower', 'A royal waltz with turns, a slow regal bow, his crown spins and flares, ruby seeds burst out like confetti, a royal wave and a proud chin-up pose.'],
      // Mangie: the mango tango - slow-slow-quick-quick steps with sharp head snaps, a dramatic dip (leans far back), a leaf flick, a promenade spin, a rose
      // in her teeth (a heart) and a sunny pose
      mangie: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 500;
        const tango = d => { t.to(B, { x: d * 2.5, lean: d * 2, armL: 90, armR: 40, footL: 2, hyaw: d * 0.2 }, 'io').to(B, { x: d * 5, footL: 0, footR: 2 }, 'io')        // slow, slow ...
          .to(B / 2, { x: d * 6, footR: 0, footL: 1.5 }, 'o').to(B / 2, { x: d * 6.5, footL: 0, hyaw: -d * 0.25 }, 'o').to(160, { hyaw: d * 0.15 }, 'o'); };           // ... quick, quick, head snap
        tango(1); tango(-1); t.to(400, { x: 0, lean: 0, hyaw: 0, armL: 0, armR: 0 }, 'io');
        t.to(700, { lean: -5, tilt: -10, pitch: 0.15, armL: 150, armR: 60, close: 0.6, lf: 1 }, 'io').wait(400).to(500, { lean: 0, tilt: 0, pitch: 0, armL: 0, armR: 0, close: 0, lf: 0 }, 'io'); // the dip
        t.to(200, { stw: 0.6, lf: 1 }, 'o').to(300, { stw: 0, lf: 0 }, 'io');                                                                                              // leaf flick
        let a = spinR(t, 1300, 360, { armL: 150, armR: 20 }); t.at(a + 1301).to(200, { armL: 0, armR: 0 }, 'io');                                                         // promenade
        t.to(300, { armR: 40, armL: 120, tilt: -4, winkL: 1 }, 'io').e('emit', 'heart', 'mouth', 1).wait(500).to(300, { armR: 0, armL: 0, tilt: 0, winkL: 0 }, 'io').e('emit', 'mjuice', 'head', 2);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Mango Tango', 'A tango both ways - slow, slow, quick-quick with sharp head snaps - a dramatic dip, a leaf flick, a promenade spin and a heart-on-the-lips wink.'],
      // Razzy: razzle-dazzle - a jiggle shimmy so every bead wobbles, jazz hands, a sparkle spin, a jiggle bounce on the beat, a shimmy-shake and a star pose
      razzy: [(() => { const t = TL({ smile: 0.9, hap: 1, jig: 0.2 }), B = 400;
        t.osc(1600, 8, { tilt: 4, jig: 1.2, x: 1 }, { tilt: -4, jig: 0.5, x: -1 }, 'io').to(200, { tilt: 0, x: 0, jig: 0.2 }, 'io');                                   // jiggle shimmy
        t.to(300, { armL: 130, armR: 130 }, 'io').osc(1000, 5, { hLx: 2, hRx: -2, jig: 0.8 }, { hLx: -1, hRx: 1, jig: 0.3 }, 'io').to(200, o(NOHANDS, { armL: 0, armR: 0 }), 'io'); // jazz hands
        let a = spinR(t, 1200, 720, { armL: 100, armR: 100, jig: 1.2, stw: 0.6 }); t.at(a + 1201).e('emit', 'spark', 'head', 4).to(250, { armL: 0, armR: 0, jig: 0.2, stw: 0 }, 'io');
        for (let i = 0; i < 4; i++) t.to(B / 2, { sq: 0.1, jig: 1 }, 'o').to(B / 2, { sq: -0.03, lift: 2, jig: 0.4 }, 'o').to(B / 3, { lift: 0, sq: 0 }, 'i');           // bead-bouncing beats
        t.to(200, { jig: 1.4 }, 'o'); shake(t, { P: 80, head: 0.2, roll: 3, body: 0.7, env: [0.5, 1, 1, 0.8, 0.5, 0.2] }); t.to(300, { jig: 0.2 }, 'io').e('emit', 'rzjuice', 'head', 2);
        t.to(300, { armL: 150, armR: 150, sq: -0.06, winkR: 1 }, 'o').e('emit', 'spark', 'head', 3).wait(450).to(300, { armL: 0, armR: 0, sq: 0, winkR: 0 }, 'io');
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Razzle Dazzle', 'A jiggle shimmy that wobbles every bead, jazz hands, a sparkling double spin, bead-bouncing beats, a shimmy-shake and a starry wink.'],
    };
    KEYS.forEach(k => { if (DANCES[k]) MOVES[k].dance = DANCES[k]; MOVES[k].look = natF(1); });
    install(MOVES, CARDS);
  })();

  // =====================================================================================================================================
  // pokes (the 14 spots, left / right where it matters): contact -> notice -> each fruit's own reaction with its own parts -> settle
  (function boot() {
    const R = window.RiveRig; if (!R || !R.POKELIB || !R.fruitV || !R.STATES.poke_head) { setTimeout(boot, 25); return; } if (R.fruitPokeV) return; R.fruitPokeV = 1;
    const { S, hand, both, o, NOHANDS, jump, shake, jelly } = R.PETLIB;
    const { see, unsee, giggle, sniff, lick, para, leanIn, happy, build } = R.POKELIB;
    const eyeRub = (t, s) => { const k = S(s), h = hand(s, 12, -20); t.e('blink2').to(300, o(h, { [k.arm]: 20, [k.wink]: 1 }), 'io');
      for (let i = 0; i < 2; i++) t.to(170, { [k.hx]: h[k.hx] + (s < 0 ? 3 : -3), [k.hy]: h[k.hy] - 1.5 }, 'io').to(170, { [k.hx]: h[k.hx], [k.hy]: h[k.hy] }, 'io');
      return t.to(300, { [k.hx]: 0, [k.hy]: 0, [k.arm]: 0, [k.wink]: 0 }, 'io').e('blink'); };
    const lookBack = (t, hold) => { see(t, 'tail', 1, hold || 350); return unsee(t, 380); };
    const hop = (t, h, ev, x) => jump(t, o({ h: h || 6, ant: 140, up: 190, c: 0.14, arm: 40, ev }, x || {}));
    const tickle = (t, extra) => { t.to(220, o(both(8, -4), { hap: 1, smile: 1 }), 'io'); const a = t.t; giggle(t, 3, 0.9); if (extra) para(t, a, extra); return t.to(260, NOHANDS, 'io'); };
    const tasteHeart = t => { lick(t, 2); return t.to(220, { hap: 1, smile: 1 }, 'io').e('emit', 'heart', 'head', 1).wait(320).to(220, { hap: 0, smile: 0 }, 'io'); };
    const nose = (t, k) => { t.to(150, { cross: 0, ly: 0.2 }, 'io'); if (k) k(t); return t.to(200, { ly: 0 }, 'io'); };
    const pulse = (t, v, d1, d2) => { const z = {}; for (const p in v) z[p] = 0; return t.to(d1 || 140, v, 'o').to(d2 || 340, z, 'io'); };
    const JU = R.FRUITLIB.JUICE, J = (t, k, w, n) => t.e('emit', JU[k], w || 'head', n || 2);

    // each fruit: part(t, a) = its own little part reaction; plus spot overrides
    const P = {
      pina: { part: (t, a) => pulse(t, { crw: a }), tick: u => u.osc(900, 3, { crs: 0.3, crw: 0.4 }, { crs: -0.2, crw: 0 }, 'io').to(150, { crs: 0 }, 'io'),
        side: (t, s) => { t.to(300, { tilt: -s * 7, x: -s * 2, crs: s * 0.3 }, 'o').to(400, { tilt: s * 2, crs: 0 }, 'io').to(300, { tilt: 0, x: 0 }, 'io'); } },
      avo: { part: (t, a) => { pulse(t, { pp: 0.6 * a }); t.to(200, { prw: a }, 'io').to(300, { prw: 0 }, 'io'); }, tick: u => u.to(800, { pr: 1 }, 'io').to(1, { pr: 0 }, 'l'),
        head: (t, s) => { t.to(150, { lfl: 1, sq: 0.06 }, 'o').to(400, { lfl: 0, sq: 0 }, 'io').to(600, { lsp: 1 }, 'io').to(1, { lsp: 0 }, 'l'); giggle(t, 2); } },
      berri: { part: (t, a) => pulse(t, { lfl: a, stw: 0.7 * a }), tick: u => u.osc(900, 3, { stw: 0.6 }, { stw: -0.3 }, 'io').to(150, { stw: 0 }, 'io'),
        head: (t, s) => { t.to(140, { lfl: 1, stw: 1, sq: 0.06 }, 'o').e('emit', 'juice', 'head', 2).to(300, { lfl: 0, sq: 0 }, 'io'); jelly(t, 0.7, 3, 260, 'stw'); giggle(t, 2); } },
      lemmy: { part: (t, a) => { t.to(110, { close: 0.85 * a, mw: 1 - 0.6 * a, puff: -0.3 * a }, 'o').wait(250).to(260, { close: 0, mw: 1, puff: 0 }, 'io'); },
        nose: u => { sniff(u, 2); u.to(110, { close: 0.85, mw: 0.35 }, 'o'); shake(u, { P: 70, head: 0.14, roll: 2, env: [0.6, 1, 0.6, 0.3] }); u.to(250, { close: 0, mw: 1, hap: 1, smile: 1 }, 'io').wait(250).to(200, { hap: 0, smile: 0 }, 'io'); },
        belly: (t, s) => { tickle(t, u => u.osc(900, 6, { tilt: 3 }, { tilt: -3 }, 'io').to(100, { tilt: 0 }, 'io')); J(t, 'lemmy', 'head', 2); } },
      kiwi: { part: (t, a) => pulse(t, { fzz: a }, 120, 420), tick: u => u.osc(900, 3, { fzz: 0.7 }, { fzz: 0.2 }, 'io').to(150, { fzz: 0 }, 'io').e('emit', 'kiwifuzz', 'head', 2),
        head: (t, s) => { for (let i = 0; i < 3; i++) t.to(130, { pitch: 0.12 }, 'o').to(130, { pitch: -0.05 }, 'i'); t.to(150, { pitch: 0, stw: 0.7 }, 'o').to(300, { stw: 0 }, 'io'); giggle(t, 2); } },
      melo: { part: (t, a) => pulse(t, { sdj: a }, 120, 500), tick: u => u.osc(900, 3, { sdj: 0.9 }, { sdj: 0.2 }, 'io').to(150, { sdj: 0 }, 'io'),
        foot: (t, s) => { hop(t, 6, [['emit', 'melojuice', 'head', 3]], { air: { sdj: 1 }, fall: { sdj: 0 } }); } },
      peachy: { part: (t, a) => { t.to(200, { blush: a, lfl: 0.6 * a }, 'io').wait(200).to(400, { lfl: 0 }, 'io').to(300, { blush: 0 }, 'io'); },
        cheekX: { blush: 1, lfl: 0.4 }, tick: u => u.to(300, { blush: 1 }, 'io').wait(500).to(300, { blush: 0 }, 'io') },
      pitaya: { part: (t, a) => pulse(t, { brf: a, wsp: 0.6 * a }), tick: u => u.osc(900, 3, { wfl: 1.2 }, { wfl: 0.2 }, 'io').to(150, { wfl: 0 }, 'io'),
        ear: (t, s) => { t.to(150, { wsp: 1, wfl: 1.4 }, 'o').wait(300).to(300, { wsp: 0, wfl: 0 }, 'io'); },
        head: (t, s) => { t.to(130, { crw: 1, spk: 1, sq: 0.06 }, 'o').e('emit', 'spark', 'head', 2).to(400, { crw: 0, spk: 0, sq: 0 }, 'io'); giggle(t, 2); } },
      tutti: { part: (t, a) => pulse(t, { cb: a, wfl: a }, 140, 400), tick: u => u.osc(900, 3, { wfl: 1.4 }, { wfl: 0.4 }, 'io').to(150, { wfl: 0 }, 'io').e('emit', 'fairydust', 'head', 2),
        ear: (t, s) => { t.to(150, { wfl: 1.5 }, 'o').e('emit', 'fairydust', 'head', 2).wait(300).to(300, { wfl: 0 }, 'io'); },
        belly: (t, s) => { tickle(t, u => u.to(600, { [s < 0 ? 'fL' : 'fR']: 1 }, 'l').to(1, { fL: 0, fR: 0 }, 'l')); } },
      nana: { part: (t, a) => { jelly(t, 0.6 * a, 3, 280, 'cv'); }, tick: u => u.osc(900, 3, { cv: 0.7 }, { cv: -0.4 }, 'io').to(150, { cv: 0 }, 'io'),
        side: (t, s) => { t.to(200, { cv: s * 0.9, tilt: -s * 3 }, 'o').to(300, { cv: -s * 0.4, tilt: 0 }, 'io'); jelly(t, 0.3, 2, 260, 'cv'); } },
      bing: { part: (t, a) => { t.to(120, { lf: a }, 'o'); jelly(t, 0.5 * a, 3, 260, 'stw'); t.to(200, { lf: 0 }, 'io'); }, tick: u => u.osc(900, 3, { stw: 0.4, lf: 0.8 }, { stw: -0.4, lf: 0.2 }, 'io').to(150, { stw: 0, lf: 0 }, 'io'),
        head: (t, s) => { t.to(600, { stw: 1, lf: 1 }, 'io').to(1, { stw: -1 }, 'l').to(500, { stw: 0, lf: 0 }, 'io'); giggle(t, 2); } },
      plummy: { part: (t, a) => { t.to(120, { lf: a }, 'o'); jelly(t, 0.4 * a, 3, 260, 'stw'); t.to(200, { lf: 0 }, 'io'); },
        tick: u => u.osc(900, 3, { pol: 0.7, lf: 0.8 }, { pol: 0.3, lf: 0.2 }, 'io').to(400, { pol: 0, lf: 0 }, 'io'),                                 // the tickle rubs his bloom shiny
        head: (t, s) => { t.to(600, { stw: 1, lf: 1 }, 'io').to(1, { stw: -1 }, 'l').to(500, { stw: 0, lf: 0 }, 'io'); giggle(t, 2); },
        foot: (t, s) => { t.to(260, { lift: 1.5, sq: -0.04, armL: 150, armR: 150 }, 'io').to(750, { spin: 360, lf: 1 }, 'io').to(1, { spin: 0 }, 'l')        // a little pirouette on tiptoe
          .to(260, { lift: 0, sq: 0, armL: 0, armR: 0, lf: 0 }, 'io'); giggle(t, 2); },
        cheekX: { blush: 0.7 } },
      clemmy: { part: (t, a) => { t.to(120, { lf: a }, 'o').e('emit', 'zest', 'head', Math.round(2 + 3 * a)).to(300, { lf: 0 }, 'io'); }, tick: u => u.osc(900, 3, { lf: 0.9 }, { lf: 0.2 }, 'io').to(150, { lf: 0 }, 'io').e('emit', 'zest', 'head', 3),
        head: (t, s) => { t.to(700, { stw: 1, lf: 1 }, 'io').to(1, { stw: -1 }, 'l').to(400, { stw: 0, lf: 0 }, 'io').e('emit', 'zest', 'head', 3); giggle(t, 2); } },
      appy: { part: (t, a) => { t.to(120, { lf: a }, 'o').to(300, { lf: 0 }, 'io'); }, tick: u => u.osc(900, 3, { lf: 0.8 }, { lf: 0.2 }, 'io').to(150, { lf: 0 }, 'io'),
        head: (t, s) => { t.to(120, { sq: 0.05, lf: 1 }, 'o').e('emit', 'spark', 'head', 2).to(300, { sq: 0, lf: 0 }, 'io'); giggle(t, 2); } },
      blueby: { part: (t, a) => pulse(t, { crf: a }), tick: u => u.osc(1000, 3, { rl: 14, x: 2 }, { rl: -14, x: -2 }, 'io').to(150, { rl: 0, x: 0 }, 'io'),
        side: (t, s) => { t.to(300, { rl: -s * 40, x: -s * 5 }, 'o').to(400, { rl: s * 8, x: -s * 2 }, 'io').to(300, { rl: 0, x: 0 }, 'io'); },
        foot: (t, s) => { t.to(700, { rl: -s * 360, x: -s * 6 }, 'io').to(1, { rl: 0 }, 'l').to(400, { x: 0 }, 'io'); giggle(t, 2); } },
      coco: { part: (t, a) => { t.to(120, { fz: a }, 'o').to(500, { fz: 0 }, 'io'); },
        foot: (t, s) => { t.to(800, { rl: -s * 360, x: -s * 7 }, 'io').to(1, { rl: 0 }, 'l').to(400, { x: 0 }, 'io'); giggle(t, 2); },
        head: (t, s) => { t.to(80, { sq: 0.03 }, 'o').e('emit', 'knock', 'head', 1).to(200, { sq: 0 }, 'io').to(300, { lx: 0.8, hyaw: 0.2, close: 0.3 }, 'io').wait(250).to(300, { lx: 0, hyaw: 0, close: 0 }, 'io'); giggle(t, 2); },
        belly: (t, s) => { tickle(t, u => { for (let i = 0; i < 3; i++) u.to(120, { fz: 0.8 }, 'o').e('emit', 'knock', 'body', 1).to(200, { fz: 0.2 }, 'io'); u.to(150, { fz: 0 }, 'io'); }); } },
      perry: { part: (t, a) => { t.to(200, { tilt: 7 * a }, 'o'); jelly(t, 6 * a, 3, 380, 'tilt'); },
        side: (t, s) => { t.to(260, { tilt: -s * 15, x: -s * 1.5, armL: 50, armR: 50 }, 'o'); jelly(t, -s * 10, 4, 420, 'tilt'); t.to(260, { x: 0, armL: 0, armR: 0 }, 'io'); },
        foot: (t, s) => { t.to(220, { tilt: s * 10 }, 'o'); jelly(t, s * 8, 4, 400, 'tilt'); giggle(t, 2); } },
      grana: { part: (t, a) => { t.to(120, { crf: a }, 'o').e('emit', 'arils', 'head', Math.round(1 + 3 * a)).to(400, { crf: 0 }, 'io'); },
        head: (t, s) => { t.to(800, { stw: 1, crf: 0.6 }, 'io').to(1, { stw: -1 }, 'l').to(400, { stw: 0, crf: 0 }, 'io'); t.to(300, { pitch: 0.08, close: 0.5, hap: 1, smile: 1 }, 'io').wait(300).to(300, { pitch: 0, close: 0, hap: 0, smile: 0 }, 'io'); },
        cheekX: { close: 0.6 } },
      mangie: { part: (t, a) => { t.to(150, { lf: a, stw: 0.4 * a }, 'o').to(400, { lf: 0, stw: 0 }, 'io'); }, tick: u => u.osc(900, 3, { lf: 0.9, tilt: 3 }, { lf: 0.2, tilt: -3 }, 'io').to(150, { lf: 0, tilt: 0 }, 'io'),
        cheekX: { blush: 0.9 } },
      razzy: { part: (t, a) => { t.to(120, { jig: 1.3 * a }, 'o').e('emit', 'spark', 'head', 1).to(700, { jig: 0 }, 'io'); }, tick: u => u.to(200, { jig: 1.4 }, 'o').wait(500).to(400, { jig: 0 }, 'io') },
    };
    const RE = {};
    R.FRUITLIB.KEYS.forEach(k => { const F = P[k], part = F.part;
      RE[k] = {
        head: F.head || ((t, s) => { part(t, 1); giggle(t, 2); }),
        ear: (t, s) => { see(t, 'ear', s, 120); (F.ear || ((u, s) => part(u, 0.7)))(t, s); unsee(t); },
        nose: (t, s) => nose(t, F.nose || (u => { sniff(u, 2); tasteHeart(u); })),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s, F.cheekX); if (F.cheekX) { const z = {}; for (const p in F.cheekX) z[p] = 0; t.to(220, z, 'io'); } },
        belly: F.belly || ((t, s) => { tickle(t, F.tick || (u => part(u, 0.7))); }),
        side: (t, s) => { (F.side || ((u, s) => jelly(u, 3, 3, 320, 'bend')))(t, s); see(t, 'side', s, 200); unsee(t, 300); },
        foot: F.foot || ((t, s) => { hop(t, 6, [['emit', JU[k], 'head', 2]]); }),
        tail: (t, s) => { part(t, 0.5); lookBack(t); },
      }; });
    const BODY = {
      pina: { ear: 0.6, lbl: { ear: 'crown', head: 'Crown', nose: 'Mouth', belly: 'Tummy', tail: 'Back' } },
      avo: { ear: 0.6, lbl: { ear: 'leaf', head: 'Sprout leaves', nose: 'Mouth', belly: 'Pit', tail: 'Back' } },
      berri: { ear: 0.6, lbl: { ear: 'leaf', head: 'Leafy top', nose: 'Mouth', belly: 'Seeds', tail: 'Back' } },
      lemmy: { ear: 0.6, lbl: { ear: s => s > 0 ? 'Right tip' : 'Left tip', head: 'Stem', nose: 'Mouth', belly: 'Tummy', tail: 'Back' } },
      kiwi: { ear: 0.6, lbl: { ear: 'fuzz', head: 'Stem', nose: 'Mouth', belly: 'Kiwi slice', tail: 'Back' } },
      melo: { ear: 0.6, lbl: { ear: 'rind corner', head: 'Top', nose: 'Mouth', belly: 'Seeds', tail: 'Rind (back)' } },
      peachy: { ear: 0.6, lbl: { ear: 'leaf', head: 'Stem', nose: 'Mouth', belly: 'Tummy', tail: 'Back' } },
      pitaya: { ear: 0.6, lbl: { ear: s => s > 0 ? 'Right wing' : 'Left wing', head: 'Crown', nose: 'Mouth', belly: 'Bracts', tail: 'Back' } },
      tutti: { ear: 0.6, lbl: { ear: s => s > 0 ? 'Right wing' : 'Left wing', head: 'Fruit crown', nose: 'Mouth', belly: 'Basket', tail: 'Basket (back)' } },
      nana: { ear: 0.6, lbl: { ear: s => s > 0 ? 'Stalk' : 'Peel (top left)', head: 'Stalk', nose: 'Mouth', belly: 'Tummy', tail: 'Back' } },
      bing: { ear: 0.6, lbl: { ear: s => s > 0 ? 'Leaf' : 'Top left', head: 'Stem', nose: 'Mouth', belly: 'Tummy', tail: 'Back' } },
      plummy: { ear: 0.6, lbl: { ear: s => s > 0 ? 'Leaf' : 'Top left', head: 'Stem', nose: 'Mouth', belly: 'Tummy', tail: 'Back' } },
      clemmy: { ear: 0.6, lbl: { ear: 'leaf', head: 'Leaves', nose: 'Mouth', belly: 'Peel', tail: 'Back' } },
      appy: { ear: 0.6, lbl: { ear: s => s > 0 ? 'Leaf' : 'Top left', head: 'Stem', nose: 'Mouth', belly: 'Tummy', tail: 'Back' } },
      blueby: { ear: 0.6, lbl: { ear: 'crown', head: 'Star crown', nose: 'Mouth', belly: 'Tummy', tail: 'Back' } },
      coco: { ear: 0.6, hopBack: 1, lbl: { ear: 'top', head: 'Coconut eyes', nose: 'Mouth', belly: 'Hairy tummy', foot: 'bottom', tail: 'Back' } },
      perry: { ear: 0.6, hopBack: 1, lbl: { ear: 'neck', head: 'Stem', nose: 'Mouth', belly: 'Tummy', foot: 'bottom', tail: 'Back' } },
      grana: { ear: 0.6, lbl: { ear: 'crown', head: 'Crown', nose: 'Mouth', belly: 'Tummy', tail: 'Back' } },
      mangie: { ear: 0.6, lbl: { ear: s => s > 0 ? 'Leaf' : 'Top left', head: 'Stem', nose: 'Mouth', belly: 'Tummy', tail: 'Back' } },
      razzy: { ear: 0.6, lbl: { ear: 'leafy top', head: 'Leafy top', nose: 'Mouth', belly: 'Beads', tail: 'Back' } },
    };
    const he = { pina: 1, avo: 1, berri: 1, lemmy: 1, kiwi: 1, melo: 1, pitaya: 1, plummy: 1, coco: 1, perry: 1, grana: 1 }, pr = k => he[k] ? ['he', 'his', 'him'] : ['she', 'her', 'her'];
    const T0 = k => { const [a, b] = pr(k), A = a[0].toUpperCase() + a.slice(1); return { nose: 'Sniffs your finger and licks it: a heart.', eye: 'Blinks hard and rubs ' + b + ' eye.', cheek: 'Leans into your finger, eyes closed.', side: 'Wobbles away from the poke and looks at the spot.', A, b }; };
    const TX = {
      pina: { head: 'His crown pops open, he giggles.', ear: 'His crown leaves flare at the touch.', belly: 'Ticklish tummy: giggles while his crown whirls.', side: 'Sways away like a palm tree and back, crown whirling.', foot: 'A hop with a squirt of pineapple juice.', tail: 'His crown flares, he looks back.' },
      avo: { head: 'His sprout leaves flap and spin like a propeller, he giggles.', ear: 'His pit pops out a little and wobbles back in.', belly: 'Ticklish pit: it rolls round in its socket while he giggles.', foot: 'A hop - a bit of guac flies.', tail: 'His pit bobs, he looks back.' },
      berri: { head: 'His leaves fly up and his stem boings, a drop of juice, a giggle.', ear: 'His leafy top flaps at the touch.', belly: 'Ticklish seeds: giggles while his stem boings.', foot: 'A juicy hop.', tail: 'His leaves flap, he looks back.' },
      lemmy: { head: 'Puckers up sour, then grins.', ear: 'A sour little pucker at the touch.', nose: 'Sniffs your finger - so sour! - shivers, then grins.', belly: 'Ticklish: a zesty shimmy and a spray of juice.', foot: 'A hop with a squirt of lemon juice.', tail: 'Puckers, looks back.' },
      kiwi: { head: 'Bobs his head like a little bird, his stem bobs, a giggle.', ear: 'His fuzz bristles at the touch.', belly: 'Ticklish slice: giggles, fuzz puffing up.', foot: 'A hop - kiwi juice drips.', tail: 'His fuzz ruffles, he looks back.' },
      melo: { head: 'All his seeds jiggle, he giggles.', ear: 'His seeds jiggle at the touch.', belly: 'Ticklish seeds: giggles while they jiggle.', foot: 'A hop - his seeds jump and juice splashes.', tail: 'His seeds wobble, he looks back.' },
      peachy: { head: 'Blushes pink and her leaf flaps, she giggles.', ear: 'Blushes at the touch, her leaf fluttering.', cheek: 'Leans her fuzzy cheek into your finger and blushes.', belly: 'Ticklish: giggles and blushes all over.', foot: 'A gentle hop - a drop of peach juice.', tail: 'Blushes, looks back.' },
      pitaya: { head: 'His crown flares and he sparkles, a giggle.', ear: s => 'His ' + (s > 0 ? 'right' : 'left') + ' wing spreads and flaps.', belly: 'Ticklish bracts: giggles, wings flapping.', foot: 'A hop - dragonfruit juice drips.', tail: 'His bracts flare, he looks back.' },
      tutti: { head: 'Her fruit crown bounces and her wings flutter, a giggle.', ear: s => 'Her ' + (s > 0 ? 'right' : 'left') + ' wing flutters fast, fairy dust falls.', belly: s => 'Ticklish basket: giggles - her ' + (s < 0 ? 'cherry' : 'pear') + ' hops out and back in.', foot: 'A hop - fairy juice drips.', tail: 'Her crown bounces, she looks back.' },
      nana: { head: 'Her curve wobbles like jelly, she giggles.', ear: s => s > 0 ? 'Her stalk gets a tap - her curve wobbles.' : 'Her peel gets a tap - her curve wobbles.', belly: 'Ticklish: her curve flips side to side while she giggles.', side: 'Bends away from the poke like a reed and springs back.', foot: 'A hop - a drop of banana.', tail: 'Her curve wobbles, she looks back.' },
      bing: { head: 'Her stem spins right round, she giggles.', ear: s => s > 0 ? 'Her leaf flutters and the stem wobbles.' : 'Her stem wobbles at the touch.', belly: 'Ticklish: giggles while her stem sways.', foot: 'A bouncy hop - cherry juice drips.', tail: 'Her stem wobbles, she looks back.' },
      plummy: { head: 'His stem spins right round, he giggles.', ear: s => s > 0 ? 'His leaf flutters at the touch.' : 'His stem wobbles at the touch.', cheek: 'Leans into your finger and blushes.', belly: 'Ticklish: giggles - the tickle rubs a shiny spot in his dusty bloom.', foot: 'Rises on tiptoe and does a little pirouette, giggling.', tail: 'His leaf flutters, he looks back.' },
      clemmy: { head: 'Her leaves twirl round and she spritzes zest, a giggle.', ear: 'Her leaf flaps and a little zest sprays.', belly: 'Ticklish peel: giggles, spritzing zest.', foot: 'A zippy hop - zest sprays.', tail: 'A spritz of zest, she looks back.' },
      appy: { head: 'A crisp little bounce with a sparkle, she giggles.', ear: s => s > 0 ? 'Her leaf flutters at the touch.' : 'Looks up at the touch, her leaf flutters.', belly: 'Ticklish: giggles, leaf fluttering.', foot: 'A crisp hop - apple juice drips.', tail: 'Her leaf flutters, she looks back.' },
      blueby: { head: 'Her star crown flares, she giggles.', ear: 'Her crown flares at the touch.', belly: 'Ticklish tummy: rocks and rolls with giggles.', side: s => 'Rolls away from the poke and rocks back onto her feet.', foot: s => 'Rolls right over ' + (s < 0 ? 'to the right' : 'to the left') + ' and back up, giggling.', tail: 'Her crown flares, she looks back.' },
      coco: { head: 'Knock! Hollow - he listens, then grins.', ear: 'His hair stands up at the touch.', belly: 'Ticklish hairy tummy: knock, knock, knock - giggles.', foot: s => 'Rolls right over ' + (s < 0 ? 'to the right' : 'to the left') + ' and back, giggling.', tail: 'His hair bristles, he looks back.' },
      perry: { head: 'Wobbles on his round bottom, he giggles.', ear: 'Wobbles at the touch on his neck.', belly: 'Ticklish tummy: giggles, wobbling.', side: 'Tips far over away from the poke and wobbles back like a roly-poly.', foot: 'Tips over on his round bottom and wobbles back up, giggling.', tail: 'A wobble, he looks back.' },
      grana: { head: 'His crown spins and flares - he lifts his chin proudly.', ear: 'His crown flares and a few ruby seeds fall.', cheek: 'Leans into your finger with royal dignity.', belly: 'Ticklish: giggles, ruby seeds falling.', foot: 'A royal hop - ruby seeds bounce.', tail: 'His crown flares, he looks back.' },
      mangie: { head: 'Her leaf flicks like a hair toss, she giggles.', ear: s => s > 0 ? 'Her leaf flicks at the touch.' : 'Her leaf flicks from the touch.', cheek: 'Leans into your finger, blushing like a sunset.', belly: 'Ticklish: giggles, leaf flicking.', foot: 'A sunny hop - mango juice drips.', tail: 'Her leaf flicks, she looks back.' },
      razzy: { head: 'Every bead on her jiggles and sparkles, she giggles.', ear: 'Her beads jiggle at the touch.', belly: 'Ticklish beads: giggles, wobbling all over.', foot: 'A hop - raspberry juice drips.', tail: 'Her beads jiggle, she looks back.' },
    };
    const TXT = {}; R.FRUITLIB.KEYS.forEach(k => { const d = T0(k); TXT[k] = Object.assign({ nose: d.nose, eye: d.eye, cheek: d.cheek, side: d.side }, TX[k]); });
    build(RE, TXT, BODY);
  })();

  // =====================================================================================================================================
  // eating (all 20 foods, each fruit its own way: a ritual before, how it bites and chews, a habit after, its own yum / love)
  (function boot() {
    const R = window.RiveRig; if (!R || !R.EATKIT || !R.fruitV || !R.EATLIB) { setTimeout(boot, 25); return; } if (R.fruitEatV) return; R.fruitEatV = 1;
    const { hand, both, o, NOHANDS, jump, swing, jelly, shake } = R.PETLIB;
    const { EAR, sniffF, lipLick, hearts, pat, buildAll } = R.EATKIT, JU = R.FRUITLIB.JUICE;
    R.FRUITLIB.KEYS.forEach(k => { if (EAR[k] == null) EAR[k] = 0.6; });
    const hop = (t, h, x) => jump(t, o({ h: h || 6, ant: 140, up: 190, c: 0.14, arm: 40 }, x || {}));
    const yay = t => t.to(160, { hap: 1, smile: 1 }, 'io');
    const C = {
      pina: { chewMs: 125, crumbs: 2, open: 0.8, armsUp: 1, txt: 'A happy hula wiggle first, big tropical bites, his crown pops open when he likes it.',
        pre: t => swing(t, 700, 2, { tilt: 4, x: 1 }, 'io'), post: t => lipLick(t),
        yum: t => { yay(t); t.to(140, { crw: 1 }, 'o').e('emit', 'pinjuice', 'head', 2).to(360, { crw: 0 }, 'io'); swing(t, 900, 2, { tilt: 5, x: 1.5 }, 'io'); } },
      avo: { savor: 0.5, chewMs: 140, crumbs: 1, open: 0.7, armsUp: 1, txt: 'Calm, buttery bites, pats his pit when he is full, his leaves flap when he likes it.',
        pre: t => sniffF(t, 1), post: t => { t.to(300, o(both(6, 8), { armL: 22, armR: 22 }), 'io').to(200, { prw: 0.6 }, 'io').to(200, { prw: 0 }, 'io').to(260, o(NOHANDS, { armL: 0, armR: 0 }), 'io'); },
        yum: t => { yay(t); t.to(200, { lfl: 0.9, pp: 0.4 }, 'o').to(400, { lfl: 0, pp: 0 }, 'io'); } },
      berri: { chewMs: 120, crumbs: 1, open: 0.7, armsUp: 1, txt: 'Quick sweet bites, a happy squirt of juice, his leaves flap and his stem boings when he likes it.',
        pre: t => sniffF(t, 1), post: t => lipLick(t),
        yum: t => { yay(t); t.to(140, { lfl: 1, stw: 0.8 }, 'o').e('emit', 'juice', 'head', 2).to(300, { lfl: 0 }, 'io'); jelly(t, 0.6, 3, 240, 'stw'); } },
      lemmy: { chewMs: 110, chewN: 0.9, crumbs: 1, open: 0.6, armsUp: 1, txt: 'Sniffs it suspiciously, quick zesty bites - a sour pucker shiver - then he grins and flaps his leaf.',
        pre: t => { sniffF(t, 1); t.to(120, { close: 0.6, mw: 0.5 }, 'io').to(200, { close: 0, mw: 1 }, 'io'); }, post: t => { t.to(110, { close: 0.85, mw: 0.35 }, 'o'); shake(t, { P: 70, head: 0.14, roll: 2, env: [0.6, 1, 0.6, 0.3] }); t.to(200, { close: 0, mw: 1 }, 'io'); },
        yum: t => { yay(t); t.to(200, { lfl: 1 }, 'o').to(300, { lfl: 0 }, 'io').e('emit', 'lemjuice', 'head', 2); } },
      kiwi: { chewMs: 100, chewN: 1.2, crumbs: 2, open: 0.55, armsUp: 1, txt: 'Pecks at it like a little bird - lots of quick small bites - and fluffs his fuzz when he likes it.',
        pre: t => { for (let i = 0; i < 2; i++) t.to(130, { pitch: -0.12 }, 'o').to(130, { pitch: 0 }, 'i'); }, post: t => t.to(200, { fzz: 0.5 }, 'o').to(300, { fzz: 0 }, 'io'),
        yum: t => { yay(t); t.to(200, { fzz: 1 }, 'o').e('emit', 'kiwifuzz', 'head', 2).to(400, { fzz: 0 }, 'io'); } },
      melo: { savor: 0.4, chewMs: 135, crumbs: 2, open: 0.85, armsUp: 1, txt: 'Big juicy summer bites, spits a seed after, his seeds jiggle when he likes it.',
        pre: t => sniffF(t, 1), post: t => { t.to(250, { puff: 0.6 }, 'io').to(80, { puff: -0.2, open: 0.3, mw: 0.4 }, 'o').e('emit', 'seed', 'mouth', 1).to(200, { puff: 0, open: 0, mw: 1 }, 'io'); },
        yum: t => { yay(t); t.to(150, { sdj: 1 }, 'o').e('emit', 'melojuice', 'head', 2).to(500, { sdj: 0 }, 'io'); } },
      peachy: { savor: 0.7, chewMs: 150, chewN: 1, crumbs: 1, open: 0.55, armsUp: 1, txt: 'Dainty little bites with her eyes closed, blushing - her leaf whirls when she likes it.',
        pre: t => t.to(260, { blush: 0.6 }, 'io'), post: t => t.to(300, { close: 0.6, smile: 0.8 }, 'io').wait(250).to(250, { close: 0, blush: 0 }, 'io'),
        yum: t => { yay(t); t.to(700, { lsp: 1, blush: 1 }, 'io').to(1, { lsp: 0 }, 'l').to(300, { blush: 0 }, 'io'); } },
      pitaya: { chewMs: 115, crumbs: 2, open: 0.9, armsUp: 1, txt: 'Fierce dragon chomps, bracts bristling, then his wings flap and he sparkles when he likes it.',
        pre: t => t.to(200, { brf: 0.6, wsp: 0.5 }, 'o').to(300, { brf: 0, wsp: 0 }, 'io'), post: t => lipLick(t, true),
        yum: t => { yay(t); t.to(200, { wsp: 1, wfl: 1.3, spk: 1 }, 'o').e('emit', 'spark', 'head', 2).to(400, { wsp: 0, wfl: 0, spk: 0 }, 'io'); } },
      tutti: { savor: 0.6, chewMs: 140, crumbs: 1, open: 0.55, armsUp: 1, txt: 'Flutters up to it, dainty fairy bites, her crown bounces and fairy dust falls when she likes it.',
        pre: t => t.to(260, { wfl: 1, lift: 2 }, 'io').to(260, { wfl: 0, lift: 0 }, 'io'), post: t => lipLick(t),
        yum: t => { yay(t); t.to(150, { cb: 1, wfl: 1.2 }, 'o').e('emit', 'fairydust', 'head', 3).to(400, { cb: 0, wfl: 0 }, 'io'); } },
      nana: { chewMs: 130, crumbs: 1, open: 0.7, armsUp: 1, txt: 'Curls round the food to look at it, happy bites, and her curve wiggles when she likes it.',
        pre: t => t.to(320, { cv: 0.7, pitch: -0.1 }, 'io').to(300, { cv: 0, pitch: 0 }, 'io'), post: t => lipLick(t),
        yum: t => { yay(t); t.osc(900, 3, { cv: 0.7 }, { cv: -0.4 }, 'io').to(200, { cv: 0 }, 'io'); } },
      bing: { chewMs: 115, crumbs: 1, open: 0.65, armsUp: 1, txt: 'Bouncy little bites, a squirt of cherry juice, her stem twirls when she likes it.',
        pre: t => sniffF(t, 1), post: t => lipLick(t),
        yum: t => { yay(t); t.to(600, { stw: 1, lf: 1 }, 'io').to(1, { stw: -1 }, 'l').to(400, { stw: 0, lf: 0 }, 'io'); hop(t, 5); } },
      plummy: { savor: 0.6, chewMs: 135, crumbs: 1, open: 0.6, armsUp: 1, txt: 'Dainty ballet bites with his eyes closed, then a twirl on tiptoe when he likes it.',
        pre: t => sniffF(t, 1), post: t => lipLick(t),
        yum: t => { yay(t); t.to(260, { lift: 1.5, armL: 150, armR: 150 }, 'io').to(750, { spin: 360, lf: 1 }, 'io').to(1, { spin: 0 }, 'l').to(260, { lift: 0, armL: 0, armR: 0, lf: 0 }, 'io'); } },
      clemmy: { chewMs: 105, chewN: 1.1, crumbs: 2, open: 0.65, armsUp: 1, txt: 'Zippy quick bites, a spritz of zest after every few, a spin when she likes it.',
        pre: t => sniffF(t, 1), post: t => t.e('emit', 'zest', 'head', 3),
        yum: t => { yay(t); t.to(600, { spin: 360, lf: 1 }, 'io').to(1, { spin: 0 }, 'l').e('emit', 'zest', 'head', 4).to(200, { lf: 0 }, 'io'); } },
      appy: { chewMs: 120, crumbs: 2, open: 0.7, armsUp: 1, txt: 'Crisp crunchy bites, wipes her mouth neatly, a shiny sparkle when she likes it.',
        pre: t => sniffF(t, 1), post: t => { t.to(260, o(hand(1, 10, -14), { armR: 30 }), 'io').to(200, { hRx: -14 }, 'io').to(260, o(NOHANDS, { armR: 0 }), 'io'); },
        yum: t => { yay(t); t.to(150, { lf: 1, sq: -0.04 }, 'o').e('emit', 'spark', 'head', 3).to(300, { lf: 0, sq: 0 }, 'io'); } },
      blueby: { chewMs: 120, crumbs: 1, open: 0.6, armsUp: 1, txt: 'Rolls up to it, small round bites, rocks and rolls happily when she likes it.',
        pre: t => t.to(400, { rl: 20, x: 3 }, 'io').to(300, { rl: 0, x: 0 }, 'io'), post: t => lipLick(t),
        yum: t => { yay(t); t.to(350, { rl: -24, x: -3 }, 'io').to(400, { rl: 24, x: 3 }, 'io').to(300, { rl: 0, x: 0 }, 'io').to(300, { stw: 0.6 }, 'io').to(300, { stw: 0 }, 'io'); } },
      coco: { savor: 0.5, chewMs: 145, crumbs: 2, open: 0.8, armsUp: 1, txt: 'Chill, slow island bites, knocks on his belly when he is full, his hair fluffs when he likes it.',
        pre: t => sniffF(t, 1), post: t => { t.to(250, o(both(6, 8), { armL: 22, armR: 22 }), 'io').to(110, { hLy: 12, hRy: 12 }, 'o').e('emit', 'knock', 'body', 1).to(200, o(NOHANDS, { armL: 0, armR: 0 }), 'io'); },
        yum: t => { yay(t); t.to(150, { fz: 0.9, lf: 1 }, 'o').to(500, { fz: 0, lf: 0 }, 'io'); swing(t, 900, 2, { tilt: 4, x: 1 }, 'io'); } },
      perry: { savor: 0.5, chewMs: 140, crumbs: 1, open: 0.65, armsUp: 1, txt: 'Leans forward to each bite and wobbles back, juicy bites, a happy roly-poly wobble when he likes it.',
        pre: t => { t.to(300, { tilt: 5 }, 'io'); jelly(t, 4, 2, 360, 'tilt'); }, post: t => lipLick(t),
        yum: t => { yay(t); t.to(200, { tilt: 8 }, 'o'); jelly(t, 7, 3, 380, 'tilt'); } },
      grana: { savor: 0.6, chewMs: 150, chewN: 1, crumbs: 1, open: 0.55, armsUp: 1, txt: 'Inspects it like a king, small royal bites, his crown flares and ruby seeds sparkle when he likes it.',
        pre: t => t.to(300, { pitch: 0.08, close: 0.5, htilt: 4 }, 'io').wait(250).to(260, { pitch: 0, close: 0, htilt: 0 }, 'io'), post: t => lipLick(t),
        yum: t => { yay(t); t.to(150, { crf: 1 }, 'o').e('emit', 'arils', 'head', 4).to(400, { crf: 0 }, 'io'); } },
      mangie: { savor: 0.6, chewMs: 135, crumbs: 1, open: 0.7, armsUp: 1, txt: 'Dramatic first bite with her eyes closed - mmm! - her leaf flicks and she blushes when she likes it.',
        pre: t => t.to(260, { close: 0.6, pitch: 0.06 }, 'io').to(200, { close: 0, pitch: 0 }, 'io'), post: t => t.to(300, { close: 0.7, smile: 1, blush: 0.6 }, 'io').wait(300).to(300, { close: 0, blush: 0 }, 'io'),
        yum: t => { yay(t); t.to(200, { lf: 1, stw: 0.5, tilt: -4 }, 'o').e('emit', 'mjuice', 'head', 2).to(400, { lf: 0, stw: 0, tilt: 0 }, 'io'); } },
      razzy: { chewMs: 110, chewN: 1.1, crumbs: 1, open: 0.6, armsUp: 1, txt: 'Bubbly quick bites with her beads jiggling, then a sparkly jiggle when she likes it.',
        pre: t => sniffF(t, 1), post: t => lipLick(t),
        yum: t => { yay(t); t.to(150, { jig: 1.4 }, 'o').e('emit', 'spark', 'head', 3).to(600, { jig: 0 }, 'io'); } },
    };
    R.FRUITLIB.KEYS.forEach(k => { const c = C[k]; if (!c.love) c.love = t => { hearts(t, 2); c.yum(t); }; });
    buildAll(C);
  })();
})();
