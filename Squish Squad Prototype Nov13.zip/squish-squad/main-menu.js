// Nov 13 MAIN MENU (landscape, user picked): the player's creature stands on a lit stone pad in front of their real house (main-menu-scene.js draws
// the house from the front with the map's state: locked rooms boarded up with 'Lv n' signs, trees / grass dead -> lush by level, season + weather).
// v3 (user: 'not good, I don't want it from the png, create our own - same for the text style; PLAY opens a full screen with the mini games;
// a button that takes us to the home with a really nice animation into the house behind us; the character 12% smaller'):
//  - our own UI kit, all CSS + inline SVG (no images): gold-rimmed royal-purple velvet plaques with diamond tips, gold gem buttons, jewel orbs,
//    a winged gold crest drawn in SVG for the level, and our own title lettering (SVG text: gradient fill + dark outline + white sticker edge)
//    for the logo, PLAY, headings and the creature's nameplate (colours per rarity: wood / bronze / amethyst / gold / rainbow).
//  - PLAY (and the GAMES tab) opens a full-screen Mini Games page: Squish Time + the 7 yard games as cards (locked until the Backyard opens);
//    a yard game plays right there (YardGames, portrait stage in the middle, how-to + best score at the sides).
//  - MY HOUSE (tab, the level crest, or tapping an open room): the HUD fades, the creature turns round, walks up the path to the front door,
//    the door swings open with warm light, the camera flies in through the doorway -> opts.onHome(room, rect) (the page shows the house);
//    back() plays it in reverse (camera pulls back out of the door, the creature walks out and turns to face you).
// window.MainMenu.mount(host, { bare, preview, season, onPlay(mode, id), onHome(room, rect), onShop(), onSettings() }) -> { destroy(), back() }.
(function () {
  if (window.MainMenu && window.MainMenu.v >= 3) return;
  const SQUISH = { id: 'squish', name: 'Squish Time', item: 'The classic squish', color: '#ff6fc8', how: ['Squeeze, poke and stretch your creature.', 'Every squish pays coins.', 'Fill the combo bar for a bonus!'] };
  const fmt = n => n == null ? '' : Number(n).toLocaleString('en-US');
  const BL = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
  const LS = { get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} } };
  const KEY = 'squishsquad.menu.v1';
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  let UID = 0;

  // ---------- our lettering: SVG text = gradient fill + dark outline (+ optional white sticker edge) ----------
  const FT = {
    gold: { f: ['#fffbe6', '#ffe57e', '#ffbe2e', '#f08c10'], o: '#3d1268', w: 1 },
    goldB: { f: ['#fffbe6', '#ffe57e', '#ffbe2e', '#f08c10'], o: '#4a1f04' },
    white: { f: ['#ffffff', '#ffffff', '#f6eeff', '#e4d4ff'], o: '#3d1268' },
    whiteB: { f: ['#ffffff', '#ffffff', '#fff6e2', '#ffe6b8'], o: '#6a2c00' },
    wood: { f: ['#fffbea', '#ffe9b8', '#f2c27a', '#d08a3c'], o: '#3a1e0a' },
    bronze: { f: ['#ffffff', '#ffe9d4', '#ffc392', '#ef8f50'], o: '#4a1a06' },
    amethyst: { f: ['#ffffff', '#f5e6ff', '#dcb0ff', '#b273ff'], o: '#2a0a5c' },
    rainbow: { f: ['#ff8fd0', '#ffcf5a', '#7fe9b8', '#7fc4ff', '#c39bff'], o: '#4a1a7a', h: 1 } };
  function ft(text, st, size, cls) {
    const S = FT[st] || FT.white, id = 'mmft' + (++UID), sw = Math.max(2.4, size * 0.19), w = Math.ceil(String(text).length * size * 0.62 + sw * 2 + 6), h = Math.ceil(size * 1.32 + sw);
    const stops = S.f.map((c, i) => '<stop offset="' + (i / (S.f.length - 1)).toFixed(2) + '" stop-color="' + c + '"/>').join('');
    const T = (extra, body) => '<text x="50%" y="' + (size * 0.98 + sw / 2).toFixed(1) + '" text-anchor="middle" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="' + size + '" letter-spacing="' + (size * 0.02).toFixed(1) + '" stroke-linejoin="round" paint-order="stroke" ' + extra + '>' + body + '</text>';
    const t = esc(text);
    return '<svg class="mm-ft ' + (cls || '') + '" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" overflow="visible" aria-label="' + t + '" role="img"><defs><linearGradient id="' + id + '" ' + (S.h ? 'x1="0" y1="0" x2="1" y2="0"' : 'x1="0" y1="0" x2="0" y2="1"') + '>' + stops + '</linearGradient></defs>'
      + (S.w ? T('fill="#ffffff" stroke="#ffffff" stroke-width="' + (sw * 2.1).toFixed(1) + '"', t) : '')
      + T('fill="' + S.o + '" stroke="' + S.o + '" stroke-width="' + (sw * 1.25).toFixed(1) + '" transform="translate(0 ' + (size * 0.06).toFixed(1) + ')"', t)
      + T('fill="url(#' + id + ')" stroke="' + S.o + '" stroke-width="' + sw.toFixed(1) + '"', t)
      + T('fill="none" stroke="rgba(255,255,255,0.55)" stroke-width="' + (size * 0.035).toFixed(2) + '" transform="translate(0 ' + (-size * 0.03).toFixed(2) + ')"', t) + '</svg>';
  }
  // after layout, size each lettering SVG to its real text width (the estimate above is only a first guess)
  function fitFT(root) { root.querySelectorAll('svg.mm-ft').forEach(s => { try { const ts = s.querySelectorAll('text'), t = ts[ts.length - 2], b = t.getBBox(); if (b.width > 0) { const sw = parseFloat(t.getAttribute('stroke-width')) || 4, w = Math.ceil(b.width + sw * 2.4 + 4); s.setAttribute('width', w); s.setAttribute('viewBox', '0 0 ' + w + ' ' + s.getAttribute('height')); } } catch (e) {} }); }

  // ---------- the winged gold crest (level badge), drawn in SVG ----------
  function crest(lv) {
    const id = 'mmcr' + (++UID);
    const wing = s => '<g transform="translate(60 0) scale(' + s + ' 1) translate(-60 0)"><path d="M40 52 C30 46 14 44 4 30 C8 30 13 31 16 30 C10 26 6 21 4 15 C12 19 20 21 26 22 C22 18 20 14 20 9 C28 15 36 22 42 30 C46 36 47 44 44 52 Z" fill="url(#' + id + 'w)" stroke="#3d1268" stroke-width="2.2" stroke-linejoin="round"/>'
      + '<path d="M38 46 C30 42 20 40 12 33 M40 40 C32 34 24 30 16 26 M42 34 C36 28 30 22 26 16" stroke="#b9a2e8" stroke-width="1.4" fill="none" stroke-linecap="round"/></g>';
    return '<svg class="mm-crest" viewBox="0 0 120 104" aria-label="Level ' + lv + '"><defs>'
      + '<linearGradient id="' + id + 'g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fffbe0"/><stop offset="0.35" stop-color="#ffd85a"/><stop offset="0.7" stop-color="#f0a21c"/><stop offset="1" stop-color="#b8640a"/></linearGradient>'
      + '<radialGradient id="' + id + 'p" cx="0.38" cy="0.32" r="0.75"><stop offset="0" stop-color="#f3e2ff"/><stop offset="0.3" stop-color="#b783ff"/><stop offset="0.7" stop-color="#6a26d0"/><stop offset="1" stop-color="#36107a"/></radialGradient>'
      + '<linearGradient id="' + id + 'w" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="0.6" stop-color="#f1e8ff"/><stop offset="1" stop-color="#cdb8f4"/></linearGradient></defs>'
      + wing(1) + wing(-1)
      + '<path d="M60 4 l4.4 9.2 10.1 1.4 -7.3 7.1 1.7 10 -8.9 -4.8 -8.9 4.8 1.7 -10 -7.3 -7.1 10.1 -1.4Z" fill="url(#' + id + 'g)" stroke="#3d1268" stroke-width="2" stroke-linejoin="round"/>'
      + '<circle cx="60" cy="58" r="31" fill="url(#' + id + 'g)" stroke="#3d1268" stroke-width="2.6"/>'
      + [0, 1, 2, 3, 4, 5, 6, 7].map(i => { const a = i * Math.PI / 4, x = 60 + Math.cos(a) * 27.5, y = 58 + Math.sin(a) * 27.5; return '<circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="1.7" fill="#fff6c8" stroke="#a86010" stroke-width="0.7"/>'; }).join('')
      + '<circle cx="60" cy="58" r="23" fill="url(#' + id + 'p)" stroke="#3d1268" stroke-width="2"/><ellipse cx="52" cy="48" rx="9" ry="5" fill="#ffffff" opacity="0.35" transform="rotate(-25 52 48)"/>'
      + '<path d="M38 88 L60 80 L82 88 L78 98 L60 92 L42 98Z" fill="url(#' + id + 'g)" stroke="#3d1268" stroke-width="2" stroke-linejoin="round"/>'
      + '<text x="60" y="95" text-anchor="middle" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="8" fill="#3d1268" letter-spacing="1">LEVEL</text>'
      + '<text x="60" y="67.5" text-anchor="middle" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="' + (lv > 9 ? 24 : 27) + '" fill="#3d1268" stroke="#3d1268" stroke-width="6" stroke-linejoin="round" paint-order="stroke">' + lv + '</text>'
      + '<text x="60" y="66" text-anchor="middle" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="' + (lv > 9 ? 24 : 27) + '" fill="url(#' + id + 'g)" stroke="#3d1268" stroke-width="3" stroke-linejoin="round" paint-order="stroke">' + lv + '</text></svg>';
  }

  let css = false;
  function addCss() {
    if (css) return; css = true; const s = document.createElement('style'); s.textContent = `
.mm-root{position:relative;font-family:'Nunito',sans-serif;-webkit-user-select:none;user-select:none;--ink:#3d1268;
  --rimG:linear-gradient(180deg,#fffbe2 0%,#ffdd6e 24%,#f2ac2c 55%,#b8680c 82%,#ffd474 100%);
  --vel:radial-gradient(130% 160% at 50% -20%,#b07cff 0%,#7a36dc 38%,#4a149a 76%,#320b74 100%);
  --dia:repeating-linear-gradient(45deg,rgba(255,255,255,.055) 0 6px,transparent 6px 12px),repeating-linear-gradient(-45deg,rgba(255,255,255,.055) 0 6px,transparent 6px 12px);
  --spk:radial-gradient(circle at 14% 28%,rgba(255,255,255,.95) 0 .9px,transparent 1.6px),radial-gradient(circle at 63% 72%,rgba(255,255,255,.85) 0 .8px,transparent 1.5px),radial-gradient(circle at 86% 22%,rgba(255,246,200,.9) 0 1px,transparent 1.7px),radial-gradient(circle at 36% 80%,rgba(255,255,255,.7) 0 .7px,transparent 1.4px);}
.mm-test{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;margin:0 auto 12px;padding:10px 14px;border-radius:14px;background:#3b2414;color:#ffe7c2;font:800 12px Nunito,sans-serif;box-shadow:inset 0 0 0 2px #6b4426;}
.mm-test b{font-family:Fredoka,sans-serif;font-weight:700;letter-spacing:1px;font-size:11px;color:#f2b866;}
.mm-test button{font:800 12px Nunito,sans-serif;border:0;border-radius:999px;padding:5px 10px;background:#f6e3c6;color:#5a3a1e;cursor:pointer;box-shadow:0 2px 0 #a8794a;}
.mm-test button.on{background:#ffcf3a;color:#5a3a00;}
.mm-test input{width:42px;font:800 13px Nunito,sans-serif;text-align:center;border:0;border-radius:8px;padding:4px;background:#fff8ee;color:#3b2414;}
.mm-test .nm{min-width:96px;text-align:center;color:#fff;}
.mm-frame{position:relative;overflow:hidden;margin:0 auto;background:#2a0d4f;}
.mm-world{position:absolute;inset:0;will-change:transform;}
.mm-scene{position:absolute;inset:0;}
.mm-stage{position:absolute;pointer-events:none;transform-origin:50% 95.5%;}
.mm-stage.walk > div{animation:mmBob .32s ease-in-out infinite;}
@keyframes mmBob{0%,100%{transform:translateY(0) rotate(-2deg);}50%{transform:translateY(-5%) rotate(2deg);}}
.mm-hit{position:absolute;left:22%;right:22%;top:20%;bottom:2%;border-radius:50%;pointer-events:auto;cursor:grab;}
.mm-veil{position:absolute;inset:0;opacity:0;pointer-events:none;}
.mm-fade{transition:opacity .35s ease;}
.mm-gone{opacity:0 !important;pointer-events:none !important;}
.mm-gone *{pointer-events:none !important;}
.mm-hud{position:absolute;left:0;top:0;width:852px;height:393px;transform-origin:0 0;pointer-events:none;}
.mm-hud > *{pointer-events:auto;}
/* ---- our plaques: velvet / gold / bronze / jewel fills inside a gold rim, dark outline, 3D lip, diamond tips ---- */
.mm-p{position:relative;box-sizing:border-box;border:2.5px solid transparent;border-radius:999px;cursor:pointer;font:700 12.5px Fredoka,sans-serif;letter-spacing:.6px;
  box-shadow:0 0 0 1.6px var(--ink),0 3px 0 1.6px var(--ink),0 6px 12px rgba(20,0,50,.38),inset 0 1.5px 0 rgba(255,255,255,.55),inset 0 -3px 6px rgba(20,0,60,.35);}
.mm-p.tip::before,.mm-p.tip::after{content:'';position:absolute;top:50%;width:8px;height:8px;margin-top:-4px;transform:rotate(45deg);background:linear-gradient(135deg,#fff6c8,#f2ac2c 55%,#a8600a);box-shadow:0 0 0 1.5px var(--ink),inset 1px 1px 0 rgba(255,255,255,.8);pointer-events:none;}
.mm-p.tip::before{left:-7px;}.mm-p.tip::after{right:-7px;}
.v-vel{background:var(--spk) padding-box,var(--dia) padding-box,var(--vel) padding-box,var(--rimG) border-box;color:#fff;}
.v-gold{background:linear-gradient(180deg,rgba(255,255,255,.6) 0,rgba(255,255,255,0) 46%) padding-box,var(--spk) padding-box,linear-gradient(180deg,#fff1b0 0%,#ffd650 40%,#f6a524 76%,#ffc84a 100%) padding-box,linear-gradient(180deg,#fffbe8,#e9a530 60%,#8a4a06) border-box;color:var(--ink);}
.v-bronze{background:linear-gradient(180deg,rgba(255,255,255,.45) 0,rgba(255,255,255,0) 46%) padding-box,linear-gradient(180deg,#ffd7b4 0%,#ea9a64 42%,#b45e2c 78%,#d98a52 100%) padding-box,var(--rimG) border-box;color:#fff;}
.v-wood{background:repeating-linear-gradient(90deg,rgba(80,40,10,.10) 0 2px,transparent 2px 11px) padding-box,linear-gradient(180deg,#e9b97c 0%,#c4874a 45%,#8c5426 100%) padding-box,linear-gradient(180deg,#ffe3b0,#a8692e 60%,#5a3010) border-box;color:#fff;}
.v-amy{background:var(--spk) padding-box,radial-gradient(120% 140% at 50% 0%,#e6c8ff 0%,#a565ff 40%,#6420c8 80%,#4a148e 100%) padding-box,var(--rimG) border-box;color:#fff;}
.v-pearl{background:var(--spk) padding-box,radial-gradient(130% 150% at 30% 0%,#ffffff 0%,#fbf4ff 35%,#ecdcff 70%,#dcc6f6 100%) padding-box,var(--rimG) border-box;color:var(--ink);}
.v-rainbow{background:var(--spk) padding-box,linear-gradient(100deg,#ffc1e6 0%,#ffe7a0 25%,#b9f6d8 50%,#b6e2ff 75%,#e2c8ff 100%) padding-box,linear-gradient(180deg,#ffffff,#d9c4ff 50%,#9a78e8) border-box;color:var(--ink);}
.tx-w{color:#fff;text-shadow:0 1.6px 0 var(--ink),1.2px 0 0 var(--ink),-1.2px 0 0 var(--ink),0 -1.2px 0 var(--ink),1px 1px 0 var(--ink),-1px 1px 0 var(--ink);}
.tx-d{color:var(--ink);text-shadow:0 1px 0 rgba(255,255,255,.7);}
.mm-orb{position:relative;width:40px;height:40px;padding:0;border:3px solid transparent;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;
  background:radial-gradient(circle at 34% 28%,#ffffff 0 7%,#d6b4ff 16%,#9a5cf0 38%,#5a1cb8 70%,#330a78 100%) padding-box,var(--rimG) border-box;box-shadow:0 0 0 1.6px var(--ink),0 3px 0 1.6px var(--ink),0 6px 12px rgba(20,0,50,.4);}
.mm-orb svg{width:20px;height:20px;filter:drop-shadow(0 1.4px 0 var(--ink));}
.mm-gem{position:absolute;width:15px;height:15px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff 0 12%,#ffd77a 28%,#f08a12 62%,#9a4a04 100%);box-shadow:0 0 0 1.5px var(--ink),0 0 0 3.5px #ffd76a,0 0 0 5px var(--ink);pointer-events:none;}
.mm-hot{position:absolute;border-radius:10px;cursor:pointer;-webkit-tap-highlight-color:transparent;}
.mm-hot:hover,.mm-hot.on{box-shadow:0 0 0 2.5px rgba(255,236,160,0.95),0 0 18px 5px rgba(255,214,110,0.75);background:rgba(255,240,190,0.12);}
.mm-hot .lab{position:absolute;left:50%;bottom:calc(100% + 8px);white-space:nowrap;padding:3px 12px;opacity:0;pointer-events:none;transition:opacity .15s;cursor:default;}
.mm-hot:hover .lab,.mm-hot.on .lab{opacity:1;}
/* ---- top bar ---- */
.mm-top{position:absolute;left:14px;right:14px;top:9px;display:flex;align-items:center;gap:7px;pointer-events:none;}
.mm-top > *{pointer-events:auto;}
.mm-logo{margin:-6px 4px -6px -2px;filter:drop-shadow(0 3px 3px rgba(30,0,60,.45));}
.mm-narrow .mm-logo{display:none;}
.mm-tabs{display:flex;gap:10px;padding:0 6px;}
.mm-tab{height:30px;padding:0 13px;display:flex;align-items:center;gap:5px;}
.mm-tab svg{width:14px;height:14px;}
.mm-tab.v-gold{box-shadow:0 0 0 1.6px var(--ink),0 3px 0 1.6px var(--ink),0 0 14px 4px rgba(255,222,120,.8),inset 0 1.5px 0 rgba(255,255,255,.7),inset 0 -3px 5px rgba(80,30,0,.3);}
.mm-narrow .mm-tab{padding:0 9px;}.mm-narrow .mm-tabs{gap:8px;padding:0 4px;}
.mm-sp{flex:1;}
.mm-pill{height:30px;display:flex;align-items:center;gap:4px;padding:0 11px 0 4px;font-size:13.5px;}
.mm-pill img{width:28px;height:28px;margin:-6px 0 -6px -10px;filter:drop-shadow(0 2px 2px rgba(30,0,40,.45));}
/* ---- the Play card ---- */
.mm-card{position:absolute;left:16px;bottom:16px;width:204px;padding:14px 11px 11px;border-radius:20px;border-width:3.5px;cursor:default;text-align:center;}
.mm-card.mm-p{box-shadow:0 0 0 2px var(--ink),0 4px 0 2px var(--ink),0 12px 24px rgba(20,0,50,.5),inset 0 0 0 1.5px rgba(255,214,120,.55),inset 0 0 18px rgba(20,0,60,.45);}
.mm-card .star{position:absolute;left:50%;top:-17px;width:34px;height:34px;margin-left:-17px;filter:drop-shadow(0 2px 2px rgba(20,0,50,.5));}
.mm-card .k{font:800 9px Nunito,sans-serif;letter-spacing:1.6px;color:#ffd77a;}
.mm-card .ttl{margin:0 0 2px;}
.mm-card .sub{font:700 11px Nunito,sans-serif;color:#eadcff;margin-bottom:6px;}
.mm-card .icons{display:flex;justify-content:center;gap:4px;margin-bottom:9px;}
.mm-card .icons i{width:22px;height:22px;border-radius:50%;overflow:hidden;box-shadow:0 0 0 1.5px var(--ink),0 0 0 3px #ffd76a;display:block;}
.mm-card .icons i svg{width:100%;height:100%;display:block;}
.mm-card .icons i.lk{filter:grayscale(1) brightness(.7);}
.mm-play{width:100%;height:54px;border-radius:16px;border-width:3px;display:flex;align-items:center;justify-content:center;gap:4px;animation:mmGlow 2.4s ease-in-out infinite;}
.mm-play:hover .mm-ft{transform:scale(1.05);}
.mm-play .mm-ft{transition:transform .12s;}
.mm-play:active{transform:translateY(3px);}
@keyframes mmGlow{0%,100%{box-shadow:0 0 0 1.8px #4a1f04,0 4px 0 1.8px #4a1f04,0 0 6px 1px rgba(255,214,110,.45),inset 0 1.5px 0 rgba(255,255,255,.6),inset 0 -4px 8px rgba(120,50,0,.35);}50%{box-shadow:0 0 0 1.8px #4a1f04,0 4px 0 1.8px #4a1f04,0 0 20px 7px rgba(255,214,110,.9),inset 0 1.5px 0 rgba(255,255,255,.6),inset 0 -4px 8px rgba(120,50,0,.35);}}
/* ---- level: the crest + tier + next room ---- */
.mm-lv{position:absolute;right:10px;bottom:6px;display:flex;align-items:flex-end;gap:0;cursor:pointer;}
.mm-lv .tag{display:flex;flex-direction:column;align-items:flex-end;gap:8px;margin-bottom:14px;}
.mm-lv .h{height:24px;padding:0 13px;display:flex;align-items:center;font-size:12px;cursor:pointer;}
.mm-lv .n{height:22px;padding:0 11px;display:flex;align-items:center;gap:4px;font-size:11px;cursor:pointer;}
.mm-crest{width:112px;height:97px;filter:drop-shadow(0 4px 4px rgba(20,0,50,.45));}
/* ---- nameplate ---- */
.mm-name{position:absolute;transform:translateX(-50%);pointer-events:none;}
.mm-name .mm-p{height:30px;padding:0 18px;display:flex;align-items:center;justify-content:center;cursor:default;}
.mm-name .mm-ft{margin:-6px 0 -5px;}
.mm-name .pips{position:absolute;left:50%;top:-9px;transform:translateX(-50%);display:flex;gap:1px;}
.mm-name .pips svg{width:12px;height:12px;filter:drop-shadow(0 1px 0 var(--ink));}
/* ---- full-screen pages (mini games, game, creature picker) ---- */
.mm-page2{position:absolute;inset:0;pointer-events:auto;overflow:hidden;background:var(--dia),radial-gradient(120% 120% at 50% 0%,#8a46ec 0%,#5a1cb8 40%,#2e0a6e 80%,#1e0650 100%);animation:mmPage .42s cubic-bezier(.2,.9,.25,1);}
.mm-page2::before{content:'';position:absolute;inset:0;background:repeating-conic-gradient(from 0deg at 50% -10%,rgba(255,230,160,.07) 0 6deg,transparent 6deg 18deg);pointer-events:none;}
@keyframes mmPage{from{opacity:0;transform:scale(1.06);}to{opacity:1;transform:none;}}
.mm-pg{position:absolute;left:0;top:0;width:852px;height:393px;transform-origin:0 0;}
.mm-pgh{position:absolute;left:16px;right:16px;top:12px;height:46px;display:flex;align-items:center;gap:12px;}
.mm-pgh .s{font:700 11.5px Nunito,sans-serif;color:#e4d4ff;}
.mm-gr{position:absolute;left:0;right:0;top:70px;bottom:0;display:flex;gap:16px;overflow-x:auto;overflow-y:hidden;padding:14px 22px 22px;scroll-snap-type:x proximity;scrollbar-width:none;}
.mm-gr::-webkit-scrollbar{display:none;}
.mm-gc{flex:none;width:162px;height:276px;scroll-snap-align:start;position:relative;display:flex;flex-direction:column;align-items:center;padding:8px 8px 10px;border-radius:22px;border-width:3.5px;cursor:pointer;transition:transform .15s;}
.mm-gc:hover{transform:translateY(-4px);}
.mm-gc.mm-p{background:var(--spk) padding-box,var(--dia) padding-box,linear-gradient(180deg,var(--gcl) 0%,var(--gc) 45%,var(--gcd) 100%) padding-box,var(--rimG) border-box;box-shadow:0 0 0 2px var(--ink),0 5px 0 2px var(--ink),0 12px 22px rgba(10,0,40,.5),inset 0 0 0 1.5px rgba(255,236,170,.6);}
.mm-gc .win{width:100%;height:104px;border-radius:14px;overflow:hidden;position:relative;box-shadow:0 0 0 2px var(--ink),0 0 0 4.5px #ffd76a,0 0 0 6px var(--ink),inset 0 -6px 10px rgba(0,0,0,.2);background:#cfeaff;}
.mm-gc .win svg,.mm-gc .win img{width:100%;height:100%;display:block;object-fit:cover;}
.mm-gc .nm{margin:12px 0 0;}
.mm-gc .it{font:700 10.5px Nunito,sans-serif;color:#fff;opacity:.9;text-shadow:0 1px 1px rgba(0,0,0,.35);}
.mm-gc .best{margin-top:7px;padding:2px 9px;border-radius:999px;background:rgba(30,0,60,.35);box-shadow:inset 0 0 0 1px rgba(255,236,170,.6);font:800 10px Nunito,sans-serif;color:#ffe9a8;}
.mm-gc .go{margin-top:auto;width:84%;height:34px;border-radius:12px;display:flex;align-items:center;justify-content:center;}
.mm-gc.lock{filter:saturate(.25) brightness(.8);}
.mm-gc .lockv{position:absolute;inset:0;border-radius:18px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;background:rgba(30,6,70,.55);font:700 12px Fredoka,sans-serif;color:#fff;text-align:center;padding:0 10px;}
.mm-gc .lockv svg{width:34px;height:34px;}
.mm-gc.feat{width:196px;}
.mm-gp{position:absolute;inset:0;display:flex;align-items:stretch;justify-content:center;}
.mm-gp .side{flex:1;min-width:0;display:flex;flex-direction:column;padding:14px 16px;gap:10px;color:#fff;}
.mm-gp .side.r{align-items:flex-start;}
.mm-gp .mid{flex:none;height:100%;aspect-ratio:360/640;padding:8px 0;box-sizing:border-box;}
.mm-gp .mid .yg-root{min-height:0;height:100%;padding:0;background:none;display:flex;align-items:center;justify-content:center;}
.mm-gp .mid .yg-frame{height:100%;width:auto;max-width:none;box-shadow:0 0 0 4px #ffd76a,0 0 0 6px #3d1268,0 14px 30px rgba(0,0,0,.45);}
.mm-gp .how{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:7px;font:700 11.5px Nunito,sans-serif;color:#efe6ff;}
.mm-gp .how li{padding:7px 10px;border-radius:12px;background:rgba(255,255,255,.08);box-shadow:inset 0 0 0 1px rgba(255,236,170,.35);}
.mm-gp .bst{padding:4px 12px;border-radius:999px;font-size:12px;}
.mm-pick .box{width:720px;height:340px;border-radius:24px;border-width:4px;display:flex;flex-direction:column;overflow:visible;cursor:default;}
.mm-pick{position:absolute;inset:0;background:rgba(24,8,40,.6);display:flex;align-items:center;justify-content:center;animation:mmIn .18s ease-out;pointer-events:auto;}
.mm-pick .hd{display:flex;align-items:center;gap:10px;padding:10px 16px 8px;}
.mm-pick .hd small{font:700 11.5px Nunito,sans-serif;color:#e8dcff;}
.mm-pick .hd .mm-orb{margin-left:auto;width:34px;height:34px;}
.mm-pick .gr{flex:1;overflow:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(82px,1fr));gap:10px 8px;padding:6px 16px 16px;scrollbar-width:thin;}
.mm-pick .it{position:relative;width:100%;aspect-ratio:1696/2528;border:0;padding:0;background:none;cursor:pointer;container-type:inline-size;}
.mm-pick .it img{position:absolute;pointer-events:none;}
.mm-pick .it .nmT{position:absolute;display:flex;align-items:center;justify-content:center;text-align:center;font:700 9cqw/1 Fredoka,sans-serif;}
.mm-pick .it.on::before{content:'';position:absolute;left:7%;right:7%;top:3%;bottom:2.5%;border-radius:10% / 7%;background:#ffd24a;box-shadow:0 0 0 3px #ffd24a,0 0 18px 6px rgba(255,210,74,.75);}
.mm-pick .it:hover{transform:translateY(-2px);}
.mm-toast{position:absolute;left:50%;top:60px;transform:translateX(-50%);max-width:70%;padding:5px 18px;font:700 13px Fredoka,sans-serif;text-align:center;animation:mmToast 2.4s ease forwards;pointer-events:none;cursor:default;}
@keyframes mmIn{from{opacity:0;transform:translateY(8px) scale(.98);}to{opacity:1;transform:none;}}
@keyframes mmToast{0%{opacity:0;transform:translate(-50%,-8px);}10%,85%{opacity:1;transform:translate(-50%,0);}100%{opacity:0;}}
@media (prefers-reduced-motion: reduce){.mm-play{animation:none;}.mm-page2{animation:none;}}
`; document.head.appendChild(s);
  }
  const ic = (d, c, w) => '<svg viewBox="0 0 24 24" fill="none" stroke="' + (c || 'currentColor') + '" stroke-width="' + (w || 2.2) + '" stroke-linecap="round" stroke-linejoin="round"><path d="' + d + '"/></svg>';
  const LOCK = '<svg viewBox="0 0 16 16" width="11" height="11"><path d="M4.5 7V5a3.5 3.5 0 0 1 7 0v2" stroke="#3d1268" stroke-width="1.8" fill="none"/><rect x="2.5" y="7" width="11" height="8" rx="2" fill="#ffd54a" stroke="#3d1268" stroke-width="1.2"/></svg>';
  const STAR = '<svg viewBox="0 0 24 24"><path d="M12 2.5l2.9 6 6.6.8-4.9 4.5 1.3 6.5L12 17l-5.9 3.3 1.3-6.5L2.5 9.3l6.6-.8Z" fill="#ffc928" stroke="#5a2a06" stroke-width="1.6" stroke-linejoin="round"/><path d="M9.4 8.6 12 4.6l1.4 2.9" stroke="#fff6c0" stroke-width="1.4" fill="none" stroke-linecap="round"/></svg>';
  const GEAR = 'M12 8.5a3.5 3.5 0 1 0 .01 0Z M19.4 13a7.6 7.6 0 0 0 0-2l2-1.6-2-3.4-2.4 1a7.4 7.4 0 0 0-1.7-1L15 3.5h-4l-.4 2.5a7.4 7.4 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.6a7.6 7.6 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7.4 7.4 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.4 7.4 0 0 0 1.7-1l2.4 1 2-3.4Z';
  const HOUSE = 'M3 11.5 12 4l9 7.5 M5.5 10.5V20h13v-9.5 M10 20v-5h4v5';
  const BACK = 'M15 5L8 12L15 19';
  const PLQ = ['v-wood', 'v-bronze', 'v-amy', 'v-gold', 'v-rainbow'], NFT = ['wood', 'bronze', 'amethyst', 'whiteB', 'white'];   // nameplate plaque + lettering per rarity (common .. rainbow)
  const gems = () => '<i class="mm-gem" style="left:-9px;top:-9px"></i><i class="mm-gem" style="right:-9px;top:-9px"></i><i class="mm-gem" style="left:-9px;bottom:-9px"></i><i class="mm-gem" style="right:-9px;bottom:-9px"></i>';
  const STARG = '<svg class="star" viewBox="0 0 40 40"><defs><linearGradient id="mmsg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fffbe0"/><stop offset="0.45" stop-color="#ffd24a"/><stop offset="1" stop-color="#e08a10"/></linearGradient></defs><path d="M20 2 l5.4 11.2 12.3 1.7 -8.9 8.6 2.1 12.2 -10.9 -5.9 -10.9 5.9 2.1 -12.2 -8.9 -8.6 12.3 -1.7Z" fill="url(#mmsg)" stroke="#3d1268" stroke-width="2.4" stroke-linejoin="round"/><path d="M15 15 l5 -8 2.6 5.2" stroke="#fffbe6" stroke-width="2" fill="none" stroke-linecap="round"/></svg>';
  const shade = (c, k) => { const n = parseInt(c.slice(1), 16), f = v => Math.max(0, Math.min(255, Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k))); return '#' + [n >> 16 & 255, n >> 8 & 255, n & 255].map(v => f(v).toString(16).padStart(2, '0')).join(''); };
  const tween = (ms, fn, ease) => new Promise(res => { const t0 = performance.now(), E = ease || (t => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2); const step = () => { const t = Math.min(1, (performance.now() - t0) / ms); fn(E(t), t); if (t < 1) requestAnimationFrame(step); else res(); }; requestAnimationFrame(step); });
  const easeIn = t => t * t * t, easeOut = t => 1 - Math.pow(1 - t, 3);

  function mount(host, opts) {
    opts = opts || {}; addCss(); const Sc = window.MainMenuScene, Q = window.SquishSquad, Lb = window.SquadLobby;
    const saved = LS.get(KEY) || {}; let season = opts.season || saved.season || 'auto', preview = opts.preview != null ? opts.preview : null, ctrl = null, sh = null, curKey = null, toastT = 0, st = null, k = 1, busy = false, inside = false, page = null, ygApp = null;
    const root = document.createElement('div'); root.className = 'mm-root'; host.innerHTML = ''; host.appendChild(root);
    let test = null;
    if (!opts.bare) { test = document.createElement('div'); test.className = 'mm-test'; root.appendChild(test); }
    const frame = document.createElement('div'); frame.className = 'mm-frame'; root.appendChild(frame);
    if (opts.bare) frame.style.cssText = 'width:100%;height:100%;'; else frame.style.cssText = 'width:min(852px, calc(100vw - 24px));aspect-ratio:852/393;border-radius:34px;box-shadow:0 0 0 9px #1c0a38,0 30px 80px rgba(60,20,120,.35);';
    if (opts.bare) root.style.cssText = 'width:100%;height:100%;';
    const world = document.createElement('div'); world.className = 'mm-world'; frame.appendChild(world);
    const scene = document.createElement('div'); scene.className = 'mm-scene'; world.appendChild(scene);
    const hots = document.createElement('div'); hots.className = 'mm-fade'; hots.style.cssText = 'position:absolute;inset:0;'; world.appendChild(hots);
    const stage = document.createElement('div'); stage.className = 'mm-stage'; world.appendChild(stage);
    const name = document.createElement('div'); name.className = 'mm-name mm-fade'; world.appendChild(name);
    const veil = document.createElement('div'); veil.className = 'mm-veil'; frame.appendChild(veil);
    const hud = document.createElement('div'); hud.className = 'mm-hud mm-fade'; frame.appendChild(hud);
    const ov = document.createElement('div'); ov.style.cssText = 'position:absolute;inset:0;pointer-events:none;'; frame.appendChild(ov);

    const level = () => { try { return window.SquishProfile ? window.SquishProfile.get().level || 1 : 1; } catch (e) { return 1; } };
    const selId = () => preview != null ? preview : Lb ? Lb.selected() : 1;
    const cre = () => Q && Q.ROSTER[selId()];
    const save = () => LS.set(KEY, { season });
    const games = () => [SQUISH].concat((window.YardGames && window.YardGames.GAMES) || []);
    const open = G => G.id === 'squish' || !!(st && st.open.backyard);
    const yb = () => { try { return (JSON.parse(localStorage.getItem('yardgames.v1') || '{}').best) || {}; } catch (e) { return {}; } };
    function toast(t) { const d = document.createElement('div'); d.className = 'mm-toast mm-p tip v-gold'; d.textContent = t; hud.appendChild(d); clearTimeout(toastT); toastT = setTimeout(() => d.remove(), 2400); }

    // ---- layout: viewBox (1000 x 460, xMidYMax slice) -> frame px ----
    let geo = null;
    function layout() {
      const W = frame.clientWidth, H = frame.clientHeight; if (!W || !H) return; const s = Math.max(W / 1000, H / 460), ox = (W - 1000 * s) / 2, oy = H - 460 * s; geo = { W, H, s, ox, oy, X: x => ox + x * s, Y: y => oy + y * s };
      k = H / 393; [hud, ...ov.querySelectorAll('.mm-pg')].forEach(e => { e.style.transform = 'scale(' + k + ')'; e.style.width = (W / k) + 'px'; }); hud.classList.toggle('mm-narrow', W / k < 770);
      // the creature: 12% smaller than before (0.5 -> 0.44 of the frame height), feet on the pad centre (500, 421)
      const S = H * 0.44, fx = geo.X(500), fy = geo.Y(421);
      if (!busy && !inside) stage.style.cssText = 'left:' + (fx - S / 2) + 'px;top:' + (fy - S * 0.955) + 'px;width:' + S + 'px;height:' + S + 'px;';
      name.style.left = fx + 'px'; name.style.top = (H - 38 * k) + 'px'; name.style.transform = 'translateX(-50%) scale(' + k + ')'; name.style.transformOrigin = '50% 0';
      world.style.transformOrigin = geo.X(Sc.DOOR[0]) + 'px ' + geo.Y(Sc.DOOR[1]) + 'px';
      veil.style.background = 'radial-gradient(circle at ' + geo.X(Sc.DOOR[0]) + 'px ' + geo.Y(Sc.DOOR[1]) + 'px, #fffdf0 0%, #ffe9a8 40%, #ffc25e 100%)';
      placeHots();
    }
    function placeHots() {
      if (!geo || !st) return; hots.innerHTML = '';
      Object.keys(Sc.AREAS).forEach(rk => { const [x, y, w, h] = Sc.AREAS[rk], R = Sc.ROOMS[rk], op = st.open[rk], b = document.createElement('div'); b.className = 'mm-hot';
        b.style.cssText = 'left:' + geo.X(x) + 'px;top:' + geo.Y(y) + 'px;width:' + w * geo.s + 'px;height:' + h * geo.s + 'px;';
        const cx = geo.X(x + w / 2), side = cx > geo.W - 150 * k ? 'right:0;left:auto;transform:scale(' + k + ');transform-origin:100% 100%' : cx < 150 * k ? 'left:0;transform:scale(' + k + ');transform-origin:0 100%' : 'transform:translateX(-50%) scale(' + k + ');transform-origin:50% 100%'; // labels near an edge stay on screen
        b.innerHTML = '<div class="lab mm-p tip ' + (op ? 'v-gold' : 'v-vel tx-w') + '" style="' + side + '">' + (op ? R.n + ' · tap to go in' : R.n + ' · opens at Lv ' + R.lv) + '</div>';
        b.onclick = () => { [...hots.children].forEach(c => c.classList.remove('on')); b.classList.add('on'); setTimeout(() => b.classList.remove('on'), 1600);
          if (!op) toast(R.n + ' opens at level ' + R.lv); else goHome(rk); };
        hots.appendChild(b); });
    }

    // ---- the scene ----
    function draw() { st = Sc.state({ level: level(), season: season === 'auto' ? null : season }); scene.innerHTML = Sc.svg(st); placeHots(); hudDraw(); testDraw(); }

    // ---- the creature ----
    function mountRig() {
      const c = cre(); if (!c || !window.RiveRig) return; if (c.key === curKey && ctrl) { nameDraw(); return; }
      if (sh) sh.stop(); if (ctrl) ctrl.destroy(); curKey = c.key;
      if (!sh && window.RigShuffle) sh = window.RigShuffle();
      const me = window.RiveRig.mount(stage, c.key, { onState: a => { if (sh && ctrl === me && !busy && !inside) sh.onState(a); } }); ctrl = me; if (sh) sh.attach(ctrl);
      const wrap = stage.firstChild; if (wrap) { wrap.style.pointerEvents = 'none'; const hit = document.createElement('div'); hit.className = 'mm-hit'; wrap.appendChild(hit); }
      nameDraw();
    }
    function nameDraw() {
      const c = cre(); if (!c) { name.innerHTML = ''; return; } const r = Math.max(0, Math.min(4, c.rar | 0));
      name.innerHTML = '<div class="mm-p tip ' + PLQ[r] + '"><div class="pips">' + STAR.repeat(r + 1) + '</div>' + ft(c.name, NFT[r], 19) + '</div>'; fitFT(name);
    }

    // ---- HUD ----
    function hudDraw() {
      if (!st) return; const W = Q ? Q.wallet() : { coins: 0, gems: 0 }, SC = window.SquishCoin, G = games(), nOpen = G.filter(open).length;
      const tab = (id, label, d, cls) => '<button class="mm-tab mm-p tip ' + cls + '" data-tab="' + id + '">' + ic(d, cls === 'v-gold' ? '#3d1268' : '#fff', 2.5) + '<span' + (cls === 'v-gold' ? '' : ' class="tx-w"') + '>' + label + '</span></button>';
      hud.innerHTML = '<div class="mm-top">' + ft('SQUAD', 'gold', 30, 'mm-logo') + '<div class="mm-tabs">'
        + tab('house', 'MY HOUSE', HOUSE, 'v-gold') + tab('creatures', 'CREATURES', 'M4 4h7v7H4Z M13 4h7v7h-7Z M4 13h7v7H4Z M13 13h7v7h-7Z', 'v-vel') + tab('shop', 'SHOP', 'M4 9h16l-1.5 11h-13Z M8 9V7a4 4 0 0 1 8 0v2', 'v-vel') + tab('games', 'GAMES', 'M6 9h12a3 3 0 0 1 3 3v2a3 3 0 0 1-5.4 1.8L14.5 14h-5l-1.1 1.8A3 3 0 0 1 3 14v-2a3 3 0 0 1 3-3Z M8 11v3 M6.5 12.5h3', 'v-vel')
        + '</div><div class="mm-sp"></div>'
        + '<div class="mm-pill mm-p tip v-vel" data-act="shop"><img alt="" src="' + ((SC && SC.coin(0)) || BL) + '"><span class="tx-w">' + fmt(W.coins) + '</span></div>'
        + '<div class="mm-pill mm-p tip v-vel" data-act="shop"><img alt="" src="' + ((SC && SC.gem(0)) || BL) + '"><span class="tx-w">' + fmt(W.gems) + '</span></div>'
        + '<button class="mm-orb" data-act="settings" aria-label="Settings">' + ic(GEAR, '#fff', 2.2) + '</button></div>'
        + '<div class="mm-card mm-p v-vel">' + STARG + gems() + '<div class="k">LET\'S PLAY</div><div class="ttl">' + ft('Mini Games', 'gold', 21) + '</div>'
        + '<div class="sub">' + (nOpen === G.length ? 'All ' + G.length + ' games ready!' : nOpen + ' ready · ' + (G.length - nOpen) + ' open at Lv ' + Sc.ROOMS.backyard.lv) + '</div>'
        + '<div class="icons">' + G.slice(0, 8).map(g => '<i class="' + (open(g) ? '' : 'lk') + '" title="' + esc(g.name) + '">' + (g.icon || squishIcon()) + '</i>').join('') + '</div>'
        + '<button class="mm-play mm-p tip v-gold" data-act="play" aria-label="Play">' + ft('PLAY', 'whiteB', 30) + '</button></div>'
        + '<div class="mm-lv"><div class="tag"><div class="h mm-p tip v-gold" data-act="house">' + st.tierName + '</div>' + (st.next ? '<div class="n mm-p tip v-vel" data-act="house"><span class="tx-w" style="display:flex;align-items:center;gap:4px">' + LOCK + 'Next: ' + st.next.name + ' · Lv ' + st.next.lv + '</span></div>' : '<div class="n mm-p tip v-vel" data-act="house"><span class="tx-w">Every room is open!</span></div>') + '</div><div data-act="house">' + crest(st.L) + '</div></div>';
      fitFT(hud);
      hud.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { const t = b.dataset.tab; if (t === 'creatures') openPicker(); else if (t === 'games') openGames(); else if (t === 'house') goHome('living'); else if (t === 'shop') { if (opts.onShop) opts.onShop(); else toast('The shop opens in the full app'); } });
      hud.querySelectorAll('[data-act]').forEach(b => b.onclick = () => { const a = b.dataset.act;
        if (a === 'play') openGames();
        else if (a === 'shop') { if (opts.onShop) opts.onShop(); else toast('The shop opens in the full app'); }
        else if (a === 'settings') { if (opts.onSettings) opts.onSettings(); else toast('Settings open in the full app'); }
        else if (a === 'house') goHome('living'); });
    }
    function squishIcon() { const c = cre(), s = c && Q.src(c.id), T = window.SQ_THUMBS || {}; return '<svg viewBox="0 0 120 84"><defs><radialGradient id="mmsq' + (++UID) + '" cx="0.5" cy="0.4"><stop offset="0" stop-color="#ffe3f6"/><stop offset="1" stop-color="#ff8fd6"/></radialGradient></defs><rect width="120" height="84" fill="url(#mmsq' + UID + ')"/>' + (s ? '<image href="' + (T[s] || s) + '" x="22" y="6" width="76" height="76" preserveAspectRatio="xMidYMid meet"/>' : '') + '<path d="M14 30 q-6 12 0 24 M106 30 q6 12 0 24 M20 36 q-3 6 0 12 M100 36 q3 6 0 12" stroke="#ffffff" stroke-width="3" fill="none" stroke-linecap="round"/></svg>'; }

    // ---- full-screen pages ----
    function pageOpen(html) { closePage(); page = document.createElement('div'); page.className = 'mm-page2'; page.innerHTML = '<div class="mm-pg" style="transform:scale(' + k + ');width:' + (geo.W / k) + 'px">' + html + '</div>'; ov.appendChild(page); fitFT(page); return page; }
    function closePage() { if (ygApp) { try { const ex = ygApp.root && ygApp.root.parentNode; ygApp.hub && ygApp.hub(); if (ex) ex.innerHTML = ''; } catch (e) {} ygApp = null; } if (page) { page.remove(); page = null; } }
    function openGames() {
      if (busy || inside) return; const G = games(), B = yb(), c = cre();
      const card = g => { const op = open(g), col = g.color || '#ff8a3d', feat = g.id === 'squish';
        return '<div class="mm-gc mm-p' + (feat ? ' feat' : '') + (op ? '' : ' lock') + '" data-g="' + g.id + '" style="--gc:' + col + ';--gcl:' + shade(col, 0.35) + ';--gcd:' + shade(col, -0.42) + '">'
          + '<div class="win">' + (feat ? squishIcon() : g.icon || '') + '</div><div class="nm">' + ft(g.name, 'white', 17) + '</div><div class="it">' + esc(g.item || '') + '</div>'
          + (feat ? '<div class="best">Playing as ' + esc(c ? c.name : '') + '</div>' : '<div class="best">' + (B[g.id] ? '★ Best ' + B[g.id] : 'New!') + '</div>')
          + '<button class="go mm-p tip v-gold">' + ft('PLAY', 'whiteB', 17) + '</button>'
          + (op ? '' : '<div class="lockv">' + LOCK.replace('width="11" height="11"', 'width="34" height="34"') + '<span>Opens with the Backyard<br>at level ' + Sc.ROOMS.backyard.lv + '</span></div>') + '</div>'; };
      const p = pageOpen('<div class="mm-pgh"><button class="mm-orb" data-x aria-label="Back">' + ic(BACK, '#fff', 3) + '</button>' + ft('Mini Games', 'gold', 30) + '<div class="s">' + G.filter(open).length + ' of ' + G.length + ' ready · your creature plays every game</div><div class="mm-sp"></div>'
        + '<div class="mm-pill mm-p tip v-vel"><img alt="" src="' + ((window.SquishCoin && window.SquishCoin.coin(0)) || BL) + '"><span class="tx-w">' + fmt(Q ? Q.wallet().coins : 0) + '</span></div></div>'
        + '<div class="mm-gr">' + G.map(card).join('') + '</div>');
      p.querySelector('[data-x]').onclick = () => closePage();
      p.querySelectorAll('[data-g]').forEach(el => el.onclick = () => { const g = G.find(x => x.id === el.dataset.g); if (!open(g)) { toast(g.name + ' opens with the Backyard at level ' + Sc.ROOMS.backyard.lv); return; } playGame(g); });
      const gr = p.querySelector('.mm-gr'); gr.addEventListener('wheel', e => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { gr.scrollLeft += e.deltaY; e.preventDefault(); } }, { passive: false });
    }
    function playGame(g) {
      if (g.id === 'squish') { if (opts.onPlay) opts.onPlay('squish', selId()); else toast('Starting Squish Time with ' + (cre() || {}).name + '…'); return; }
      if (opts.onPlay && opts.yardExternal) { opts.onPlay(g.id, selId()); return; }
      const YG = window.YardGames; if (!YG || !YG.mount) { toast('The yard games are still loading…'); return; }
      const c = cre(), B = yb();
      const p = pageOpen('<div class="mm-gp"><div class="side"><div style="display:flex;align-items:center;gap:10px"><button class="mm-orb" data-x aria-label="Back to the games">' + ic(BACK, '#fff', 3) + '</button>' + ft(g.name, 'gold', 22) + '</div>'
        + '<div class="bst mm-p v-vel tx-w" style="align-self:flex-start;cursor:default">' + (B[g.id] ? '★ Best ' + B[g.id] : 'First game!') + '</div><div class="bst mm-p v-gold" style="align-self:flex-start;cursor:default">Playing as ' + esc(c ? c.name : '') + '</div></div>'
        + '<div class="mid"></div><div class="side r">' + ft('How to play', 'white', 16) + '<ul class="how">' + (g.how || [g.hint || '']).map(t => '<li>' + esc(t) + '</li>').join('') + '</ul></div></div>');
      p.querySelector('[data-x]').onclick = () => openGames();
      const mid = p.querySelector('.mid');
      try { ygApp = YG.mount(mid); const pick = c && [...mid.querySelectorAll('.yg-pick')].find(b => b.title === c.name); if (pick) pick.click(); const hub0 = ygApp.hub; ygApp.hub = () => { hub0(); setTimeout(() => { if (page && page.contains(mid)) openGames(); }, 0); }; ygApp.play(g); }
      catch (e) { toast('Could not start ' + g.name); }
    }
    function openPicker() {
      if (!Q || busy || inside) return; const own = Q.ownedIds(), cur = selId(), T = window.SQ_THUMBS || {};
      const box = document.createElement('div'); box.className = 'mm-pick';
      const C4 = window.SQ_CARD4, list = own.slice().sort((a, b) => C4 ? C4.byRar(Q.ROSTER[a], Q.ROSTER[b]) : a - b);
      const card = id => { const c = Q.ROSTER[id], s = Q.src(id), d = C4 ? C4.of(c) : null; if (!d) return '<button class="it' + (id === cur ? ' on' : '') + '" data-id="' + id + '"><img alt="" style="inset:0;width:100%;height:100%;object-fit:contain" src="' + (T[s] || s) + '"></button>';
        const bx = p => 'left:' + d[p + 'L'] + ';top:' + d[p + 'T'] + ';width:' + d[p + 'W'] + ';height:' + d[p + 'H'];
        return '<button class="it' + (id === cur ? ' on' : '') + '" data-id="' + id + '" aria-label="' + esc(c.name) + '" title="' + esc(c.name) + '"><img alt="" loading="lazy" src="' + d.cdBg + '" style="' + bx('cdBg') + ';object-fit:cover;object-position:center bottom"><img alt="" loading="lazy" src="' + (T[s] || s) + '" style="' + bx('cdArt') + ';object-fit:contain;object-position:center bottom"><img alt="" loading="lazy" src="' + d.cdFrame + '" style="inset:0;width:100%;height:100%">'
          + (d.cdHasName ? '<img alt="" loading="lazy" src="' + d.cdName + '" style="' + bx('cdNm') + ';object-fit:contain">' : '<span class="nmT" style="' + bx('cdNm') + ';color:' + d.cdInk + '">' + esc(c.name) + '</span>') + '</button>'; };
      box.innerHTML = '<div class="box mm-p v-vel" style="transform:scale(' + k + ')">' + gems() + '<div class="hd">' + ft('Your creatures', 'gold', 22) + ' <small>' + own.length + ' owned · pick who stands in front of your house</small><button class="mm-orb" data-x aria-label="Close">' + ic('M7 7l10 10M17 7L7 17', '#fff', 3) + '</button></div><div class="gr">'
        + list.map(card).join('') + '</div></div>';
      box.onclick = e => { if (e.target === box || e.target.closest('[data-x]')) box.remove(); const b = e.target.closest('[data-id]'); if (b) { preview = null; if (Lb) Lb.select(+b.dataset.id); box.remove(); mountRig(); hudDraw(); testDraw(); } };
      ov.appendChild(box); fitFT(box);
    }

    // ---- the trip home: turn round, walk up the path, the door opens, the camera flies in through the doorway ----
    const door = () => scene.querySelector('.mm-door'), dlight = () => scene.querySelector('.mm-doorlight');
    function doorOpen(t) { const d = door(), l = dlight(); if (d) { d.style.transformBox = 'fill-box'; d.style.transformOrigin = '0% 50%'; d.style.transform = 'scaleX(' + (1 - 0.82 * t).toFixed(3) + ') skewY(' + (-6 * t).toFixed(2) + 'deg)'; } if (l) l.setAttribute('opacity', t.toFixed(3)); }
    const fade = on => [hud, hots, name].forEach(e => e.classList.toggle('mm-gone', !on));
    function stageAt(t) { // 0 = on the pad, 1 = in the doorway (smaller, further away)
      if (!geo) return; const x0 = geo.X(500), y0 = geo.Y(421), x1 = geo.X(Sc.DOOR[0]), y1 = geo.Y(300), sc = 1 - 0.74 * t;
      stage.style.transform = 'translate(' + ((x1 - x0) * t).toFixed(1) + 'px,' + ((y1 - y0) * t).toFixed(1) + 'px) scale(' + sc.toFixed(3) + ')';
    }
    async function goHome(room) {
      if (busy || inside || !geo) return; busy = true; closePage(); ov.querySelectorAll('.mm-pick').forEach(e => e.remove()); fade(false);
      if (sh) sh.stop(); if (ctrl) ctrl.play('idle'); const I = ctrl && ctrl._I, s0 = I ? I.spinOff || 0 : 0;
      await tween(430, e => { if (I) I.spinOff = s0 + 180 * e; });
      stage.classList.add('walk');
      await tween(1250, (e, t) => { stageAt(e); doorOpen(Math.max(0, Math.min(1, (t - 0.35) / 0.45))); stage.style.opacity = t > 0.84 ? Math.max(0, 1 - (t - 0.84) / 0.16) : 1; });
      stage.classList.remove('walk');
      await tween(900, (e, t) => { world.style.transform = 'scale(' + (1 + 5.2 * e).toFixed(3) + ')'; veil.style.opacity = t > 0.45 ? Math.min(1, (t - 0.45) / 0.5).toFixed(3) : 0; }, easeIn);
      veil.style.pointerEvents = 'auto'; inside = true; busy = false;
      const r = frame.getBoundingClientRect();
      if (opts.onHome) opts.onHome(room || 'living', r); else { toast('Welcome home! (the house opens here in the full app)'); setTimeout(back, 1400); }
    }
    async function back() {
      if (!inside || busy) return; busy = true; inside = false; veil.style.pointerEvents = 'none'; const I = ctrl && ctrl._I;
      await tween(850, (e, t) => { world.style.transform = 'scale(' + (1 + 5.2 * (1 - e)).toFixed(3) + ')'; veil.style.opacity = Math.max(0, 1 - t / 0.55).toFixed(3); }, easeOut);
      world.style.transform = ''; stage.classList.add('walk');
      await tween(1100, (e, t) => { stageAt(1 - e); stage.style.opacity = Math.min(1, t / 0.16).toFixed(3); doorOpen(Math.max(0, 1 - t / 0.7)); });
      stage.classList.remove('walk'); doorOpen(0); stage.style.transform = ''; stage.style.opacity = '';
      const s0 = I ? I.spinOff || 0 : 0; await tween(430, e => { if (I) I.spinOff = s0 + 180 * e; }); if (I) I.spinOff = 0;
      fade(true); busy = false; if (sh && ctrl) sh.attach(ctrl); if (ctrl) ctrl.play('happy');
    }

    // ---- test controls (design view only) ----
    function testDraw() {
      if (!test || !st) return; const c = cre();
      test.innerHTML = '<b>TEST CONTROLS</b><span>Level</span><button data-l="-1">−</button><input value="' + st.L + '"><button data-l="1">+</button>'
        + '<span>Season</span>' + ['auto', 'sunny', 'rainy', 'snowy'].map(s => '<button data-s="' + s + '" class="' + (season === s ? 'on' : '') + '">' + s[0].toUpperCase() + s.slice(1) + '</button>').join('')
        + '<span>Creature</span><button data-c="-1">◀</button><span class="nm">' + (c ? esc(c.name) : '') + (preview != null ? ' (preview)' : '') + '</span><button data-c="1">▶</button>';
      const setL = n => { n = Math.max(1, Math.min(30, n | 0)); try { window.SquishProfile && window.SquishProfile.set({ level: n }); } catch (e) {} draw(); };
      test.querySelectorAll('[data-l]').forEach(b => b.onclick = () => setL(st.L + +b.dataset.l));
      const inp = test.querySelector('input'); inp.onchange = () => setL(+inp.value); inp.onkeydown = e => { if (e.key === 'Enter') setL(+inp.value); };
      test.querySelectorAll('[data-s]').forEach(b => b.onclick = () => { season = b.dataset.s; save(); draw(); });
      test.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { const n = Q.ROSTER.length; preview = ((selId() + +b.dataset.c) % n + n) % n; mountRig(); hudDraw(); testDraw(); });
    }

    const onWallet = () => { if (!busy && !inside) hudDraw(); }, onProf = () => { if (!busy && !inside) draw(); }, onSel = () => { if (preview == null && !busy && !inside) mountRig(); hudDraw(); };
    window.addEventListener('squishsquad', onWallet); window.addEventListener('squishcoin', onWallet); window.addEventListener('squishprofile', onProf); window.addEventListener('squadlobby', onSel);
    let ro = null; if (window.ResizeObserver) { ro = new ResizeObserver(() => layout()); ro.observe(frame); } else window.addEventListener('resize', layout);
    draw(); layout(); mountRig();
    const iv = setInterval(() => { if (season === 'auto' && !busy && !inside) { const s0 = st && st.season; const s1 = Sc.state({ level: level() }).season; if (s0 !== s1) draw(); } }, 60000);
    return { destroy() { clearInterval(iv); closePage(); if (sh) sh.stop(); if (ctrl) ctrl.destroy(); if (ro) ro.disconnect(); window.removeEventListener('squishsquad', onWallet); window.removeEventListener('squishcoin', onWallet); window.removeEventListener('squishprofile', onProf); window.removeEventListener('squadlobby', onSel); host.innerHTML = ''; },
      back, home: goHome, games: openGames, frame: () => frame, _st: () => st, _ctrl: () => ctrl, _geo: () => geo, _busy: () => busy, _inside: () => inside };
  }
  window.MainMenu = { v: 3, mount, ft, crest };
})();
