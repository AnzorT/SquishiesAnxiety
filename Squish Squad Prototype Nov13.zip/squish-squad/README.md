# Squish Squad: playable prototype

All the game's screens, creatures and art as of Nov 13, 2026. Everything runs in the browser, with no build step.

## Run

```
cd squish-squad
python3 -m http.server 8000
```

Open http://localhost:8000/Main%20Menu.dc.html (the new home screen). Other screens:

- http://localhost:8000/Squad%20House%20v6.dc.html (the house)
- http://localhost:8000/All%20Creatures%20Animations.dc.html (every creature and every animation, plus the cards)
- http://localhost:8000/Yard%20Mini%20Games.dc.html (mini games)
- http://localhost:8000/Shop%20Screen%20v5.dc.html (shop)
- http://localhost:8000/Chest%20Smash%20v2.dc.html (chest opening)

You need an internet connection: React, Babel, three.js and the fonts come from public CDNs.

## Use with Claude Code

Open this folder in Claude Code (`cd squish-squad && claude`). `CLAUDE.md` is the start-here guide: how the pages work, which files do what, what's new and what's left. `docs/HISTORY.md` is the full build log, so search it rather than reading it all.

## Folders

- `*.dc.html`: one screen per page (runtime in `support.js`)
- `*.js`: shared engines (creature rigs, house, furniture, cards, chests, games, menu)
- `export/`: art and sound: creature pictures (`tripo/`), card frames and names (`cards4/`), thumbs, sounds
- `music/`, `assets/`, `uploads/` (the renovation catalog CSV the house reads)
- `tools/`: build tools (`tools/cards/` = card frames + names)
- `docs/`: build history, the to-do list
