// Movie Room size fit (ratio pass vs creatures, creature = 107.5 model units = 1).
// Per renovation item scale, applied on top of the drawn size in Squad House (rnReg) and the Renovation Catalog room view.
// Targets: sofas ~0.9-1 creature wide per seat (like the Living Room 2-seater), seat ~0.4; popcorn carts ~1.3 tall;
// floor speakers / players no longer toy-sized; screens step up by tier; sconces, lightbox, tabletop pieces trimmed.
window.RenoFit = Object.assign(window.RenoFit || {}, {
  // primary sofa / row
  'MOV-013': 1.25, 'MOV-033': 1.25, 'MOV-053': 1.18, 'MOV-073': 1.15, 'MOV-093': 1.5, 'MOV-101': 1.12,
  // single seats + pet bed (were smaller than the creatures: ~0.9-1 creature wide now)
  'MOV-016': 1.5, 'MOV-019': 1.6, 'MOV-056': 1.55, 'MOV-076': 1.4, 'MOV-096': 1.35,
  // snack station
  'MOV-031': 1.6, 'MOV-051': 1.35, 'MOV-071': 1.1, 'MOV-091': 1.2, 'MOV-102': 1.3,
  // main screen
  'MOV-002': 1.1, 'MOV-022': 1.15, 'MOV-042': 1.15, 'MOV-082': 0.85,
  // projector / player
  'MOV-006': 1.4, 'MOV-046': 1.3,
  // speakers (v3: bookshelf kit + tower array bigger)
  'MOV-010': 1.6, 'MOV-030': 1.5, 'MOV-050': 1.75, 'MOV-070': 1.55, 'MOV-090': 1.2,
  // drinks coolers (v3: styrofoam cooler + mini soda fridge were toy-sized)
  'MOV-014': 1.6, 'MOV-034': 1.7,
  // media rack (v4: DVD tower was toy-sized)
  'MOV-037': 1.6, 'MOV-077': 1.5,
  // decor: sconces, lightbox poster, tabletop clutter
  'MOV-058': 0.65, 'MOV-078': 0.75, 'MOV-098': 0.85, 'MOV-044': 0.8, 'MOV-028': 0.75, 'MOV-068': 1.05
});
