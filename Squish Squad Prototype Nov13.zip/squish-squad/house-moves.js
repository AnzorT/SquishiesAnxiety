// Squad House moves: furniture animations per creature. Hold states (sit, lounge) loop until the house sends the creature elsewhere;
// sitdown / standup are the short moves in and out. Every creature gets its own version: build(key, profile) below.
(function boot() {
  const R = window.RiveRig; if (!R || !R.REST || !R.movesV) { setTimeout(boot, 30); return; } if (R.houseV) return; R.houseV = 1;
  const REST = R.REST, o = (...a) => Object.assign({}, ...a);
  function TL(base) {
    const k = {}, ev = [], em = []; let t = 0; base = base || {};
    const bv = p => base[p] != null ? base[p] : (REST[p] || 0);
    const T = {
      B: base, get t() { return t; },
      to(dt, v, ez) { for (const p in v) { const L = k[p] || (k[p] = [[0, bv(p)]]); if (L[L.length - 1][0] < t) L.push([t, L[L.length - 1][1], 'l']); } t += dt; for (const p in v) k[p].push([t, v[p], ez || 'io']); return T; },
      wait(dt) { t += dt; return T; }, at(x) { t = x; return T; },
      e(...a) { ev.push([t, ...a]); return T; }, fx(n, w, c) { ev.push([t, 'emit', n, w || 'body', c]); return T; },
      osc(dt, n, A, Bv, ez) { const h = dt / n / 2; for (let i = 0; i < n; i++) T.to(h, A, ez || 'io').to(h, Bv, ez || 'io'); return T; },
      back(dt, keys, ez) { const v = {}; (keys || Object.keys(k)).forEach(p => v[p] = bv(p)); return T.to(dt || 400, v, ez); },
      out(x, loop) { for (const p in k) { k[p].sort((a, b) => a[0] - b[0]); if (loop) { const L = k[p]; if (L[L.length - 1][0] < t) L.push([t, L[0][1], 'io']); } } ev.sort((a, b) => a[0] - b[0]); return Object.assign(loop ? { loop: t } : { dur: t }, { k, ev, emit: em }, x || {}); },
    };
    return T;
  }
  const hand = (s, inX, y) => s < 0 ? { hLx: inX, hLy: y } : { hRx: -inX, hRy: y };
  const both = (inX, y) => o(hand(-1, inX, y), hand(1, inX, y));
  const SIDE = s => s < 0 ? { arm: 'armL', hx: 'hLx', hy: 'hLy', ear: 'earL', foot: 'footL', wink: 'winkL' } : { arm: 'armR', hx: 'hRx', hy: 'hRy', ear: 'earR', foot: 'footR', wink: 'winkR' };
  const keysOf = v => Object.keys(v);

  // ---------- beats: small seated actions; each one ends back on the base pose ----------
  const BEAT = {
    swing(t) { const B = t.B, a = B.footL || 0; t.osc(2600, 4, { footL: a + 1.8, footR: a - 0.6, lean: 0.5 }, { footL: a - 0.6, footR: a + 1.8, lean: -0.5 }, 's'); return t.back(380, ['footL', 'footR', 'lean']); },
    look(t) { t.e('blink').to(420, { lx: -0.9, turn: -0.22, htilt: -4 }, 'io').wait(1000).to(560, { lx: 0.9, turn: 0.22, htilt: 4 }, 'io').wait(1000); return t.back(480, ['lx', 'turn', 'htilt']); },
    pat(t, s) { s = s || 1; const K = SIDE(s), B = t.B; t.to(380, o(hand(s, -11, 9), { [K.arm]: 18, turn: s * 0.12, lx: s * 0.6, ly: 0.4 }), 'io');
      t.osc(1200, 3, { [K.hy]: 11, sq: (B.sq || 0) + 0.012 }, { [K.hy]: 7, sq: B.sq || 0 }, 'o'); return t.back(420, [K.hx, K.hy, K.arm, 'turn', 'lx', 'ly', 'sq']); },
    yawn(t) { const B = t.B; t.to(320, { sq: (B.sq || 0) + 0.03, close: 0.35 }).to(620, { sq: (B.sq || 0) - 0.06, pitch: 0.4, open: 0.9, mw: 0.8, close: 0.85, armL: 120, armR: 120, hLy: -3, hRy: -3, tongue: 0.2 }, 'io')
      .osc(700, 2, { tilt: 1.4 }, { tilt: -1.4 }, 's').to(520, { sq: B.sq || 0, pitch: B.pitch || 0, open: 0, mw: 1, close: 0.3, armL: B.armL || 0, armR: B.armR || 0, hLy: B.hLy || 0, hRy: B.hRy || 0, tongue: 0, tilt: 0 }, 'io').e('blink2'); return t.back(300, ['close']); },
    kick(t) { const a = t.B.footL || 0; t.to(200, { hap: 0.8, smile: 1 }).osc(1100, 3, { footL: a + 3, footR: a + 3, sq: (t.B.sq || 0) - 0.02 }, { footL: a, footR: a, sq: t.B.sq || 0 }, 'o'); return t.back(360, ['hap', 'smile', 'footL', 'footR', 'sq']); },
    wiggle(t) { t.to(200, { hap: 0.6, smile: 0.8 }).osc(1500, 3, { x: 1.2, tilt: 2.4 }, { x: -1.2, tilt: -2.4 }, 's'); return t.back(360, ['x', 'tilt', 'hap', 'smile']); },
    hum(t) { t.to(260, { smile: 0.9, close: 0.5, hap: 0.5 }).fx('note', 'head').osc(2400, 4, { htilt: 6, lean: 0.6 }, { htilt: -6, lean: -0.6 }, 's').fx('note', 'head'); return t.back(400, ['smile', 'close', 'hap', 'htilt', 'lean']); },
    ears(t) { t.to(90, { earR: -10 }, 'o').to(160, { earR: 4 }).to(140, { earR: 0 }).wait(500).to(90, { earL: -10 }, 'o').to(160, { earL: 4 }); return t.back(160, ['earL', 'earR']); },
    wag(t) { t.to(200, { hap: 0.5, smile: 0.7 }).osc(1800, 5, { wag: 20 }, { wag: -20 }, 'io'); return t.back(300, ['wag', 'hap', 'smile']); },
    giggle(t, s) { s = s || 1; const K = SIDE(s); t.to(300, o(hand(s, 9, -12), { [K.arm]: 30, blush: 0.8, hap: 1, sqz: 0.6, smile: 1, htilt: s * 4 }), 'io').osc(900, 4, { sq: (t.B.sq || 0) + 0.025 }, { sq: t.B.sq || 0 }, 'o'); return t.back(420, [K.hx, K.hy, K.arm, 'blush', 'hap', 'sqz', 'smile', 'htilt', 'sq']); },
    bounce(t) { const L = t.B.lift || 0, Q = t.B.sq || 0; t.to(180, { hap: 0.8, smile: 1, open: 0.3 }); for (let i = 0; i < 3; i++) t.to(130, { sq: Q + 0.08, lift: L }, 'i').to(200, { sq: Q - 0.05, lift: L + 2.6 }, 'o').to(170, { sq: Q, lift: L }, 'i'); return t.back(300, ['hap', 'smile', 'open', 'sq', 'lift']); },
    wave(t, s) { s = s || 1; const K = SIDE(s); t.to(380, { [K.arm]: 145, [K.hy]: -3, hap: 1, smile: 1, open: 0.3, htilt: s * 4 }, 'o').osc(1400, 3, { [K.arm]: 118 }, { [K.arm]: 160 }, 'io'); return t.back(420, [K.arm, K.hy, 'hap', 'smile', 'open', 'htilt']); },
    nod(t) { t.to(600, { close: 0.75, pitch: -0.18 }, 'io').wait(500).to(140, { pitch: 0.05, close: 0, wide: 0.5 }, 'o').e('blink2'); return t.back(380, ['close', 'pitch', 'wide']); },
    // lounge beats
    stretch(t) { const B = t.B; t.to(700, { armL: 165, armR: 165, hLy: -5, hRy: -5, sq: (B.sq || 0) - 0.09, close: 0.9, open: 0.45, pitch: 0.35, footL: (B.footL || 0) + 2, footR: (B.footR || 0) + 2 }, 'io').wait(500).osc(500, 2, { tilt: 1.2 }, { tilt: -1.2 }, 's'); return t.back(650, ['armL', 'armR', 'hLy', 'hRy', 'sq', 'close', 'open', 'pitch', 'footL', 'footR', 'tilt']); },
    sigh(t) { const B = t.B; t.to(900, { sq: (B.sq || 0) - 0.05, lift: (B.lift || 0) + 0.8, close: 0.6, open: 0.2 }, 's').to(1300, { sq: (B.sq || 0) + 0.07, lift: B.lift || 0, close: 0.8, open: 0.1, smile: 0.9 }, 's').wait(400); return t.back(700, ['sq', 'lift', 'close', 'open', 'smile']); },
    doze(t) { t.to(900, { close: 1, pitch: (t.B.pitch || 0) - 0.2, htilt: 5 }, 's').osc(2400, 2, { pitch: (t.B.pitch || 0) - 0.3 }, { pitch: (t.B.pitch || 0) - 0.16 }, 's').to(160, { close: 0, wide: 0.6, pitch: t.B.pitch || 0, htilt: 0 }, 'o').e('blink2'); return t.back(420, ['close', 'pitch', 'htilt', 'wide']); },
    belly(t, s) { s = s || -1; const K = SIDE(s); t.to(420, o(hand(s, 6, 6), { [K.arm]: 10 }), 'io').osc(1200, 3, { [K.hy]: 8 }, { [K.hy]: 5 }, 'o').to(200, { smile: 1, hap: 0.6 }); return t.back(460, [K.hx, K.hy, K.arm, 'smile', 'hap']); },
  };

  // ---------- default poses ----------
  const SIT0 = o({ sit: 1, sq: 0.1, lift: -2.6, pitch: 0.06 }, both(6, 3));
  // lounge: leans back with both arms resting out along the sofa (34; short-armed creatures override higher) (paws behind the head would cover the face in front view)
  const LNG0 = o({ sit: 1, sq: 0.14, lift: -3.6, pitch: 0.3, close: 0.5, smile: 0.9, hap: 0.25, armL: 34, armR: 34, footL: 2, footR: 0.3, tilt: -3.5, htilt: 6, lean: -0.7 }, both(-2, -1));

  function seq(t, list, gap) { list.forEach((b, i) => { t.wait(gap[i % gap.length]); if (typeof b === 'function') b(t); else { const [n, a] = Array.isArray(b) ? b : [b]; BEAT[n](t, a); } }); return t; }

  // sit down: from standing, into the seated base pose (dn = style)
  function sitdown(B, P) {
    const t = TL(REST), all = keysOf(B);
    enterMove(t, B, P.dn || 'hop');
    if (P.dnX) P.dnX(t, B);
    const v = {}; all.forEach(p => v[p] = B[p]); t.to(140, v, 'io');
    return t.out({ next: 'sit', blend: 220, look: true });
  }
  function enterMove(t, B, st) {
    const L = B.lift || 0, Q = B.sq || 0;
    if (st === 'float') { t.to(260, { lift: 3, sq: -0.04, hap: 0.4 }, 'o').to(900, o(B, { lift: L + 0.6 }), 's').to(320, { lift: L, sq: Q }, 'io'); }
    else if (st === 'flop') { t.to(200, { sq: 0.1, tilt: -4 }).to(260, { lift: 6, sq: -0.08, tilt: 6, open: 0.4 }, 'o').to(220, o(B, { lift: L - 1, sq: Q + 0.16, tilt: 0 }), 'i').to(200, { sq: Q - 0.03, lift: L + 0.6 }, 'o').to(240, { sq: Q, lift: L, open: B.open || 0 }, 'io'); }
    else if (st === 'bounce') { t.to(160, { sq: 0.14 }).to(240, { lift: 8, sq: -0.14 }, 'o').to(200, o(B, { lift: L, sq: Q + 0.2 }), 'i').to(180, { lift: L + 3, sq: Q - 0.08 }, 'o').to(170, { lift: L, sq: Q + 0.1 }, 'i').to(160, { lift: L + 0.8, sq: Q - 0.02 }, 'o').to(160, { lift: L, sq: Q }, 'io'); }
    else if (st === 'spin') { t.to(160, { sq: 0.12 }).to(380, { lift: 9, sq: -0.12, spin: 360, footL: 2, footR: 2 }, 'o').to(220, o(B, { lift: L - 0.4, sq: Q + 0.12, spin: 360 }), 'i').to(200, { sq: Q - 0.02 }, 'o').to(180, { sq: Q, spin: 360, lift: L }, 'io'); }
    else if (st === 'climb') { t.to(220, { footL: 3, lift: 1.5, tilt: 2, armL: 30 }, 'io').to(220, { footL: 0, footR: 3, lift: 4, tilt: -2, armL: 0, armR: 30 }, 'io').to(200, { footR: 0, lift: 5.5, tilt: 0, armR: 0, sq: -0.04 }, 'o').to(240, o(B, { lift: L - 0.4, sq: Q + 0.1 }), 'i').to(200, { sq: Q, lift: L }, 'io'); }
    else if (st === 'slide') { t.to(200, { sq: 0.08, lean: 2 }).to(420, o(B, { lift: L + 2, lean: -1.5, sq: Q - 0.03 }), 'o').to(300, { lift: L, lean: 0, sq: Q + 0.05 }, 'io').to(220, { sq: Q }, 'io'); }
    else { t.to(160, { sq: 0.12, footL: 0, footR: 0, armL: -8, armR: -8 }, 'io').to(240, { lift: 7, sq: -0.12, footL: 2.2, footR: 2.2, armL: 40, armR: 40 }, 'o').to(200, o(B, { lift: L - 0.6, sq: Q + 0.12 }), 'i').to(200, { sq: Q - 0.025, lift: L + 0.4 }, 'o').to(200, { sq: Q, lift: L }, 'io'); }
    return t;
  }
  function exitMove(t, B, st) {
    const z = {}; keysOf(B).forEach(p => z[p] = REST[p] || 0);
    if (st === 'float') t.to(260, { lift: (B.lift || 0) + 1, sq: (B.sq || 0) + 0.04 }, 'io').to(360, o(z, { lift: 3, sq: -0.03 }), 'o');
    else if (st === 'flop') t.to(180, { sq: (B.sq || 0) + 0.06, tilt: 4 }, 'io').to(240, o(z, { lift: 5, sq: -0.1, tilt: -3 }), 'o').to(200, { lift: 0, sq: 0.08, tilt: 0 }, 'i');
    else t.to(200, { sq: (B.sq || 0) + 0.05, pitch: -0.12, lean: 0.8, sit: 0.6 }, 'io').to(220, o(z, { lift: 5, sq: -0.1, footL: 2, footR: 2, armL: 30, armR: 30 }), 'o').to(200, { lift: 0, sq: 0.09, footL: 0, footR: 0, armL: 0, armR: 0 }, 'i');
    return t;
  }
  // stand up: from the seated pose, back to standing (house waits ~620 ms before walking)
  function standup(B, P) {
    const t = TL(B), st = P.up || 'hop', z = {}; keysOf(B).forEach(p => z[p] = REST[p] || 0);
    if (st === 'float') t.to(260, { lift: (B.lift || 0) + 1, sq: (B.sq || 0) + 0.04 }, 'io').to(360, o(z, { lift: 3, sq: -0.03 }), 'o');
    else if (st === 'flop') t.to(180, { sq: (B.sq || 0) + 0.06, tilt: 4 }, 'io').to(240, o(z, { lift: 5, sq: -0.1, tilt: -3 }), 'o').to(200, { lift: 0, sq: 0.08, tilt: 0 }, 'i');
    else t.to(200, { sq: (B.sq || 0) + 0.05, pitch: -0.12, lean: 0.8, sit: 0.6 }, 'io').to(220, o(z, { lift: 5, sq: -0.1, footL: 2, footR: 2, armL: 30, armR: 30 }), 'o').to(200, { lift: 0, sq: 0.09, footL: 0, footR: 0, armL: 0, armR: 0 }, 'i');
    if (P.upX) P.upX(t, B);
    t.to(160, { sq: 0, lift: 0 }, 'io');
    return t.out({ next: 'idle', blend: 160 });
  }
  function hold(B, beats, gaps, extra) { const t = TL(B), v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(10, v); seq(t, beats, gaps); t.wait(1400); return t.out(o({ breathe: 1, look: true, blend: 520 }, extra || {}), true); }

  // ---------- watch TV (seated hold, eyes on the screen) + snuggle (two friends on one sofa) ----------
  const ss = x => x <= 0 ? 0 : x >= 1 ? 1 : x * x * (3 - 2 * x);
  const TWO = { pip: 1, puff: 1, pearl: 1 }; // food sits between both flippers
  const LAP = { bubbly: 1, twinkle: 1, jelli: 1, finn: 1, aurora: 1, sealy: 1, shelly: 1, batty: 1 }; // fins / wings / no paws: bucket sits in the lap, he dips his face in
  const RIGID = { puddi: 1, cakey: 1, maca: 1, melo: 1, choco: 1, chip: 1, twisty: 1, crois: 1, mochi: 1, frybo: 1, boba: 1, bunbun: 1, mallow: 1, dunkie: 1, scoop: 1, cuppy: 1, kernel: 1, bao: 1, chefbun: 1 }; // stiff foods lean less
  // per-creature reactions: extra channels merged into the shared beats (lean, laugh, gasp, clap, aww, cheer) + snuggle (snug pose, nz nuzzle channels)
  const WX = {
    mittens: { laughA: { curl: 0.5 }, nz: { curl: 0.7 } }, biscuit: { laughA: { wag: 26 }, laughB: { wag: -26 }, cheer: { earL: -14, earR: -14 }, nz: { wag: 18 } }, prickle: { gasp: { curl: 1, sq: 0.24, close: 1, armL: -10, armR: -10, hLy: 0, hRy: 0, hLx: 0, hRx: 0 } },
    nibbles: { laugh: { puff: 0.8 }, gasp: { puff: 1 } }, quill: { gasp: { blush: 1 } }, poppy: { cheer: { earL: -16, earR: -16 } }, duchess: { laugh: { sqz: 0.3, close: 0.5, open: 0.25 }, aww: { tongue: 0 } }, mamapaws: { aww: { close: 0.7 }, nz: { wag: 12 } },
    nimbo: { awwFx: ['drop', 'body', 4], gasp: { sq: 0.24 } }, lumi: { cheerFx: ['spark', 'head', 5] }, bubbly: { cheerFx: ['spark', 'body', 4] }, twinkle: { cheerFx: ['spark', 'body', 6] }, zappi: { gasp: { zap: 1 }, cheer: { zap: 0.7 }, cheerFx: ['spark', 'body', 6] }, plip: { awwFx: ['drop', 'head', 2] },
    breeze: { gasp: { puff: 0.6 }, cheerFx: ['gust', 'head'] }, dusty: { cheerFx: ['dust', 'body', 4] }, aurora: { cheer: { spout: 1 }, cheerFx: ['drop', 'head', 4] },
    mallow: { aww: { sq: 0.26 } }, bao: { cheerFx: ['steam', 'head'] }, dunkie: { cheerFx: ['sprinkle', 'head'] }, frybo: { cheer: { fw: 1 }, gasp: { fw: 0.6 } }, bunbun: { gasp: { split: 0.5 }, cheer: { split: 0.3 } }, choco: { aww: { melt: 0.4 } }, scoop: { laughA: { chb: 1 }, laughB: { chb: 0 } }, boba: { cheer: { slurp: 0.6 } }, chefbun: {},
    pip: {}, jelli: { laughA: { sq: 0.2 }, laughB: { sq: 0.02 } }, finn: { laughA: { wag: 24 }, laughB: { wag: -24 }, cheerFx: ['drop', 'body', 4] }, sealy: { clap: { open: 0.5 } }, puff: { gasp: { blo: 0.8, puff: 0.8 } }, shelly: { gasp: { hid: 0.85 } },
    octo: { gasp: { ocl: 1 }, cheer: { osp: 1 } }, marina: { cheer: { tlf: 0.7 } }, pearl: { cheer: { glow: 1 }, cheerFx: ['spark', 'head', 4] },
    pina: { cheer: { crw: 1 } }, avo: { gasp: { pp: 0.4 } }, berri: { gasp: { stw: 1 } }, lemmy: { aww: { sqz: 1 } }, kiwi: { gasp: { fzz: 1 } }, melo: { laughA: { sdj: 1 }, laughB: { sdj: 0 } }, peachy: { aww: { blush: 1 } }, pitaya: { gasp: { brf: 1, wsp: 0.8 } }, tutti: { cheer: { wfl: 1 }, cheerFx: ['dust', 'body', 3] },
    kiko: { cheerFx: ['spark', 'head', 3] }, teddy: { aww: { close: 0.6 } }, hoot: { gasp: { tfl: 1, wide: 1 } }, leo: { gasp: { mfl: 1 }, cheer: { mfl: 0.7 } }, panko: {}, acorn: { gasp: { tfl: 1 } }, fawn: { gasp: { earL: -14, earR: -14 } }, moss: { laughA: { cb: 1 }, laughB: { cb: 0 } }, sprout: { cheer: { blm: 1 } },
    hana: { gasp: { flL: 1, flR: 1 } }, boo: { gasp: { gho: 0.5 } }, pixie: { cheer: { wfl: 1 }, cheerFx: ['dust', 'body', 4] }, floof: { gasp: { fzz: 1 } }, unibun: { cheerFx: ['spark', 'head', 5] }, gumdrop: { laughA: { jig: 1 }, laughB: { jig: 0.3 } }, ember: { gasp: { cfl: 1 }, cheer: { cfl: 1 } }, drako: { gasp: { wsp: 1 }, cheer: { wsp: 1, wfl: 1 } }, jinni: { cheer: { glo: 1, gwh: 1 } },
    cuppy: { cheerFx: ['sprinkle', 'head'] }, chip: {}, twisty: {}, crois: {}, maca: {}, puddi: { laughA: { sq: 0.2 } }, mochi: { aww: { sq: 0.24 } }, cakey: {}, sugarplum: { cheerFx: ['spark', 'head', 3] },
    gourdy: {}, batty: { gasp: { armL: 70, armR: 70 } }, kernel: {}, hexie: { cheerFx: ['spark', 'head', 4] }, mumbles: {}, hocus: { cheerFx: ['spark', 'body', 4] }, countsquishula: { gasp: { armL: 90, hLy: -10, hLx: 6 } },
  };
  const WBEAT = {
    leanin(t, X) { const B = t.B; t.to(700, o({ pitch: (B.pitch || 0) - 0.14, sq: (B.sq || 0) + 0.03, wide: 0.5, mw: 0.6, open: 0.12, ly: 0.1 }, X.lean), 'io').wait(1300).to(240, { wide: 0.9, open: 0.3 }, 'o').wait(500); return t.back(600); },
    laugh(t, X) { const B = t.B, L = B.lift || 0, Q = B.sq || 0; t.to(220, o(both(7, 5), { hap: 1, smile: 1, open: 0.55, sqz: 0.8 }, X.laugh), 'o').osc(1500, 7, o({ sq: Q + 0.045, lift: L + 0.6, htilt: 4 }, X.laughA), o({ sq: Q - 0.01, lift: L, htilt: -4 }, X.laughB), 'o'); return t.back(450); },
    gasp(t, X) { const B = t.B, L = B.lift || 0, Q = B.sq || 0; t.to(170, o(both(10, -12), { armL: 34, armR: 34, wide: 1, open: 0.6, mw: 0.5, lift: L + 1.4, sq: Q - 0.05, pitch: (B.pitch || 0) + 0.1 }, X.gasp), 'o').wait(1000).to(500, { wide: 0.4, open: 0.2, lift: L }, 'io').wait(300); return t.back(520); },
    popcorn(t, X, two) { const B = t.B, p0 = B.pitch || 0;
      if (two === 'lap') { for (let i = 0; i < 3; i++) t.to(340, { pitch: p0 - 0.24, ly: 0.7, open: 0.3, sq: (B.sq || 0) + 0.03 }, 'io').osc(600, 3, { open: 0.25, puff: 0.5 }, { open: 0, puff: 0.2 }, 'l').fx('crumb', 'mouth').to(320, { pitch: p0, ly: 0, open: 0, puff: 0, sq: B.sq || 0 }, 'io').wait(300); }
      else if (two) { t.to(320, both(7, -1)); for (let i = 0; i < 3; i++) t.to(320, o(both(9, -12), { armL: 30, armR: 30, open: 0.35, pitch: p0 - 0.05 }), 'io').osc(600, 3, { open: 0.25, puff: 0.5 }, { open: 0, puff: 0.2 }, 'l').fx('crumb', 'mouth').to(300, o(both(7, -1), { armL: 0, armR: 0, open: 0, puff: 0, pitch: p0 }), 'io').wait(240); }
      else { t.to(320, o(hand(-1, 5, 1), { armL: 8 })); for (let i = 0; i < 3; i++) t.to(240, o(hand(1, 13, 1), { armR: 6, ly: 0.5 }), 'io').to(300, o(hand(1, 10, -14), { armR: 36, open: 0.35, ly: 0 }), 'io').osc(600, 3, { open: 0.25, puff: 0.5 }, { open: 0, puff: 0.2 }, 'l').fx('crumb', 'mouth').to(260, o(hand(1, 6, 3), { armR: 0, puff: 0, open: 0 }), 'io').wait(200); }
      t.to(200, { smile: 1, hap: 0.5 }); return t.back(420); },
    clap(t, X) { t.to(260, o(both(11, -5), { armL: 28, armR: 28, hap: 1, smile: 1, open: 0.4 }, X.clap), 'o').osc(1300, 6, { hLx: 14, hRx: -14 }, { hLx: 8, hRx: -8 }, 'io').fx('spark', 'head', 3); return t.back(420); },
    aww(t, X) { t.to(600, o(both(8, -5), { armL: 18, armR: 18, close: 0.35, frown: 0.5, teary: 0.6, htilt: 7, mw: 0.6 }, X.aww), 'io').wait(700); if (X.awwFx) t.fx(...X.awwFx); t.wait(600).to(400, { teary: 0.2, frown: 0, smile: 0.6 }, 'io'); return t.back(600); },
    cheer(t, X) { const B = t.B, L = B.lift || 0, Q = B.sq || 0; t.to(260, o({ armL: 160, armR: 160, hLx: -6, hRx: 6, hLy: -6, hRy: -6, hap: 1, smile: 1, open: 0.55, wide: 0.3 }, X.cheer), 'o'); if (X.cheerFx) t.fx(...X.cheerFx);
      for (let i = 0; i < 2; i++) t.to(140, { sq: Q + 0.08, lift: L }, 'i').to(200, { sq: Q - 0.05, lift: L + 2.6 }, 'o').to(170, { sq: Q, lift: L }, 'i'); return t.back(450); },
  };
  const BUCKET = '<path d="M-4.6 -2.4L4.6 -2.4L3.5 5.2L-3.5 5.2Z" fill="#fffaf0" stroke="#c9b9a0" stroke-width="0.35"/><path d="M-2.6 -2.4L-1.2 -2.4L-1 5.2L-2.1 5.2Z M1.2 -2.4L2.6 -2.4L2.1 5.2L1 5.2Z" fill="#e8483c"/><path d="M1.6 -2.4L4.6 -2.4L3.5 5.2L1.3 5.2Z" fill="#3a1d10" opacity="0.12"/>' +
    [[-3, -3, 1.6], [-0.8, -3.9, 1.8], [1.6, -3.2, 1.6], [3.4, -2.7, 1.2], [0.6, -5.2, 1.3], [-2.2, -4.7, 1.2]].map(([x, y, r]) => '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="#fff4cf" stroke="#e2b85e" stroke-width="0.3"/>').join('') + '<path d="M-4.9 -2.6L4.9 -2.6L4.7 -1.6L-4.7 -1.6Z" fill="#e8483c"/>';
  const popProp = (win, loop, two) => (I, tt) => { const W = I.W; if (!W || !W.pawL || !win.length) return ''; const tl = tt % loop; let k = 0; win.forEach(([a, b]) => { if (tl > a && tl < b) k = Math.max(k, Math.min(ss((tl - a) / 260), ss((b - tl) / 260))); }); if (k < 0.01) return '';
    const mid = two || I.foodMid, x = mid ? (W.pawL[0] + W.pawR[0]) / 2 : W.pawL[0], y = (mid ? (W.pawL[1] + W.pawR[1]) / 2 : W.pawL[1]) + (two === 'lap' ? 5 : 0);
    return '<g transform="translate(' + x.toFixed(2) + ' ' + (y - 4).toFixed(2) + ') scale(' + (k * 2.3).toFixed(3) + ')">' + BUCKET + '</g>'; };
  function watchHold(B, P, key) {
    const X = WX[key] || {}, two = LAP[key] ? 'lap' : TWO[key], t = TL(B), v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(10, v);
    const sig = (P.f || []).find(f => typeof f === 'function'), win = [], bt = [], gaps = P.gap || [1600, 2400, 1900, 2600, 2100];
    (X.order || ['leanin', 'laugh', 'popcorn', 'gasp', 'sig', 'clap', 'popcorn', 'aww', 'cheer']).forEach((n, i) => { t.wait(gaps[i % gaps.length]); if (n === 'sig') { if (sig) sig(t); return; } const a = t.t; WBEAT[n](t, X, two); bt.push([n, a, t.t]); if (n === 'popcorn') win.push([a, t.t]); });
    t.wait(1400); const st = t.out({ breathe: 1, look: false, blend: 520 }, true); st.prop = popProp(win, st.loop, two); st.beats = bt; return st;
  }
  function snug(B, P, s, key) {
    const X = WX[key] || {}, K = SIDE(s), J = SIDE(-s), la = (P.lpose && P.lpose.armL) || 34, short = la <= 14;
    const rg = RIGID[key] ? 0.45 : 1, SB = o(B, { tilt: (B.tilt || 0) + s * 5 * rg, lean: s * 2.4 * rg, x: s * 1.8, htilt: s * 11 * (rg < 1 ? 0.6 : 1), close: 0.5, smile: 1, hap: 0.35, blush: 0.55 }, short ? hand(s, 3, 2) : hand(s, 0, -3), { [K.arm]: short ? 12 : Math.min(la, 30) }, hand(-s, 7, 4), { [J.arm]: 6 }, X.snug || {});
    const t = TL(SB), v = {}; keysOf(SB).forEach(p => v[p] = SB[p]); t.to(10, v);
    const NB = {
      nuzzle(t) { t.to(300, { close: 0.8 }).osc(1800, 4, o({ htilt: SB.htilt + s * 6, x: s * 2.6, sq: SB.sq + 0.015 }, X.nz), o({ htilt: SB.htilt - s * 2, x: s * 1.5, sq: SB.sq }, X.nz ? Object.fromEntries(Object.keys(X.nz).map(k => [k, -X.nz[k] * (k === 'wag' ? 1 : 0)])) : {}), 's'); return t.back(500); },
      heart(t) { t.to(300, { blush: 1, sqz: 0.6, hap: 1, close: 0 }, 'o').fx('heart', 'head', 2).wait(900); return t.back(500); },
      pat(t) { t.osc(1500, 3, { [K.hy]: SB[K.hy] - 5, [K.arm]: SB[K.arm] + 6 }, { [K.hy]: SB[K.hy], [K.arm]: SB[K.arm] }, 'o'); return t.back(400); },
      squeeze(t) { t.to(320, { sq: SB.sq + 0.06, x: s * 3.2, close: 1, hap: 1, [K.arm]: SB[K.arm] + 10 }, 'o').wait(700); return t.back(520); },
      giggle(t) { BEAT.giggle(t, -s); return t; }, sigh(t) { BEAT.sigh(t); return t; }, doze(t) { BEAT.doze(t); return t; }, ears(t) { BEAT.ears(t); return t; },
    };
    const bt = []; (X.snugOrder || ['nuzzle', 'sigh', 'heart', 'pat', 'doze', 'ears', 'squeeze', 'giggle']).forEach((n, i) => { const g = P.lgap || [1800, 2600, 2200, 3000]; t.wait(g[i % g.length]); const a = t.t; NB[n](t); bt.push([n, a, t.t]); });
    t.wait(1400); const st = t.out({ breathe: 1, look: false, blend: 620 }, true); st.beats = bt; return st;
  }

  // ---------- per-creature build ----------
  const PROF = {};
  function build(key, P) {
    P = P || {}; const B = o(SIT0, P.pose || {}), LB = o(B, LNG0, P.lpose || {});
    const fid = P.f || ['look', 'swing', 'pat', 'yawn'], lf = P.lf || ['sigh', 'stretch', 'doze', 'belly'];
    const S = {};
    S[key ? 'sitdown@' + key : 'sitdown'] = sitdown(B, P);
    S[key ? 'sit@' + key : 'sit'] = hold(B, fid, P.gap || [1600, 2400, 1900, 2600, 2100]);
    S[key ? 'standup@' + key : 'standup'] = standup(B, P);
    S[key ? 'lounge@' + key : 'lounge'] = hold(LB, lf, P.lgap || [1800, 2600, 2200, 3000]);
    const dl = sitdown(LB, o(P, { dnX: P.ldnX || P.dnX })); dl.next = 'lounge';
    S[key ? 'sitdown_lounge@' + key : 'sitdown_lounge'] = dl;
    const WB = o(B, { pitch: (B.pitch || 0) - 0.03 }, P.wpose || {}), nm = n => key ? n + '@' + key : n;
    S[nm('watch')] = watchHold(WB, P, key); const dw = sitdown(WB, P); dw.next = 'watch'; S[nm('sitdown_watch')] = dw;
    S[nm('snuggleL')] = snug(B, P, -1, key); S[nm('snuggleR')] = snug(B, P, 1, key);
    R.add(S); R.HS = Object.assign(R.HS || {}, S); if (key) PROF[key] = P;
  }
  // ---------- bedtime: bed (quilt), lie (hammock / chaise / towel, no quilt), bean (beanbag, curled up) ----------
  // channels read by the sleep fx: qk = quilt cover (0-1), zz = Zzz (1 sleep, ~1.8 snore), drm = dream bubble (0-1)
  const TAU = Math.PI * 2, r2 = v => Math.round(v * 100) / 100, cl = (v, a, b) => v < a ? a : v > b ? b : v;
  const LIE0 = o({ sit: 1, sq: 0.15, lift: -2.6, pitch: 0.34, close: 1, mw: 0.7, smile: 0.2, htilt: 7, tilt: -3, armL: 6, armR: 6, footL: 0.6, footR: 0.6, lean: 0, hap: 0, open: 0, qk: 1, zz: 1, drm: 0 }, both(5, -2));
  const CURL0 = o({ sit: 1, sq: 0.24, lift: -5.2, pitch: -0.26, close: 1, mw: 0.7, smile: 0.25, htilt: 12, tilt: 6, turn: 0.26, curl: 0.9, lean: 0.6, armL: -4, armR: -4, footL: 2, footR: 2, hap: 0, open: 0, zz: 1, drm: 0 }, both(7, 4));
  const shade = (h, k) => { if (!/^#[0-9a-f]{6}$/i.test(h || '')) return k < 1 ? '#56709a' : '#a9c2e8'; const n = parseInt(h.slice(1), 16); return '#' + [n >> 16, (n >> 8) & 255, n & 255].map(c => Math.round(cl(k < 1 ? c * k : c + (255 - c) * (k - 1), 0, 255)).toString(16).padStart(2, '0')).join(''); };
  const ci = (x, y, r, f, s) => '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + f + '"' + (s ? ' stroke="' + s + '" stroke-width="0.4"' : '') + '/>';
  const pa = (d, f, s, w) => '<path d="' + d + '" fill="' + (f || 'none') + '"' + (s ? ' stroke="' + s + '" stroke-width="' + (w || 0.4) + '" stroke-linecap="round" stroke-linejoin="round"' : '') + '/>';
  const ICON = {
    fish: pa('M-4 0Q-1-3.2 2.4 0Q-1 3.2-4 0Z', '#f2924a', '#c96a2a') + pa('M2 0L4.6-2.2V2.2Z', '#f2924a', '#c96a2a') + ci(-2.2, -0.5, 0.5, '#3a2a20'),
    bone: pa('M-2.6-0.9H2.6V0.9H-2.6Z', '#fff4dc') + [[-3, -0.9], [-3, 0.9], [3, -0.9], [3, 0.9]].map(([x, y]) => ci(x, y, 1.2, '#fff4dc', '#c9b48a')).join('') + pa('M-2.6-0.9H2.6M-2.6 0.9H2.6', null, '#c9b48a'),
    apple: ci(0, 0.8, 3.2, '#e8483c', '#b8302a') + pa('M0-2.2Q0.4-3.6 1-4', null, '#6a4a2a', 0.6) + pa('M0.4-3Q2.4-4.2 3-2.6Q1.6-2 0.4-3Z', '#7cc35a') + ci(-1.2, -0.4, 0.8, '#fff') ,
    nut: pa('M-3-0.4Q0-3.4 3-0.4Z', '#8a5a2c') + pa('M-2.6-0.4Q-2.4 3.6 0 4Q2.4 3.6 2.6-0.4Z', '#d39a5a', '#a86b36') + pa('M0-2.4V-3.6', null, '#6a4a2a', 0.6),
    flower: [0, 1, 2, 3, 4].map(i => ci(r2(Math.cos(i * 1.2566 - 1.57) * 2.3), r2(Math.sin(i * 1.2566 - 1.57) * 2.3), 1.6, '#f7a8c4', '#d9789a')).join('') + ci(0, 0, 1.3, '#ffd84a', '#d9a62a'),
    carrot: pa('M-1.9-1.6L1.9-1.6L0 4.4Z', '#f28a1e', '#c96a10') + pa('M0-1.6L-1.4-4.2M0-1.6L0-4.6M0-1.6L1.4-4.2', null, '#5fae4a', 0.9),
    crown: pa('M-4 2.4L-4-1.6L-2-0.2L0-2.8L2-0.2L4-1.6L4 2.4Z', '#ffd24a', '#c9962a') + ci(0, 0.8, 0.8, '#e8483c'),
    heart: pa('M0 3.4C-4.6 0.4-4-3.6-1.6-3.2C-0.6-3 0-2.2 0-1.6C0-2.2 0.6-3 1.6-3.2C4-3.6 4.6 0.4 0 3.4Z', '#ff6f86', '#d9485e'),
    sun: pa([0, 1, 2, 3, 4, 5, 6, 7].map(i => { const a = i * 0.785; return 'M' + r2(Math.cos(a) * 3) + ' ' + r2(Math.sin(a) * 3) + 'L' + r2(Math.cos(a) * 4.4) + ' ' + r2(Math.sin(a) * 4.4); }).join(''), null, '#f2a81e', 0.8) + ci(0, 0, 2.3, '#ffcc3a', '#e2961e'),
    star: pa('M0-4.2L1.2-1.4L4.2-1.2L1.9 0.8L2.6 3.8L0 2.2L-2.6 3.8L-1.9 0.8L-4.2-1.2L-1.2-1.4Z', '#ffd24a', '#d9a22a'),
    bubble: ci(-1, 0.6, 2.6, 'rgba(160,220,255,0.35)', '#5ab4f0') + ci(2.4, -2, 1.3, 'rgba(160,220,255,0.35)', '#5ab4f0') + ci(-1.9, -0.4, 0.6, '#fff'),
    moon: pa('M1.2-3.6A3.8 3.8 0 1 0 1.2 3.6A3 3 0 1 1 1.2-3.6Z', '#ffe08a', '#d9b24a'),
    bolt: pa('M0.8-4.2L-2.4 0.6H-0.2L-1 4.2L2.4-0.8H0.2Z', '#ffd42a', '#c9962a'),
    rainbow: pa('M-4 2.4A4 4 0 0 1 4 2.4', null, '#ff6a5a', 1.1) + pa('M-2.9 2.4A2.9 2.9 0 0 1 2.9 2.4', null, '#ffd24a', 1.1) + pa('M-1.8 2.4A1.8 1.8 0 0 1 1.8 2.4', null, '#5ab4f0', 1.1),
    cloud: ci(-1.8, 0.8, 1.9, '#fff', '#a9b9d0') + ci(1.8, 0.8, 1.9, '#fff', '#a9b9d0') + ci(0, -0.4, 2.4, '#fff', '#a9b9d0') + pa('M-3.2 1.4Q0 3.2 3.2 1.4', '#fff'),
    cup: pa('M-2.8-1.2H2L1.6 3.2H-2.4Z', '#c98a52', '#8a5a2c') + pa('M2-0.4Q3.6-0.4 3.4 1Q3.2 2 1.8 2', null, '#8a5a2c', 0.7) + pa('M-1.2-2.2Q-1.8-3.2-1.1-4M0.6-2.2Q0-3.2 0.7-4', null, '#b9a6c9', 0.5),
    ketchup: pa('M-1.8-1.2H1.8V3.8Q0 4.4-1.8 3.8Z', '#e8483c', '#b8302a') + pa('M-0.8-3.8H0.8V-1.2H-0.8Z', '#fffaf0', '#c9b9a0') + pa('M-1.8 0.6H1.8V1.8H-1.8Z', '#ffd24a'),
    cheese: pa('M-4 2.6L3.8 2.6L3.8-1.4L-4 0.4Z', '#ffd24a', '#d9a22a') + ci(-1, 1.4, 0.6, '#e8b22a') + ci(1.8, 0.2, 0.8, '#e8b22a'),
    cherry: pa('M-1.6 0.6Q-0.6-2.8 1-4M1.8 1Q1.6-2 1-4', null, '#5fae4a', 0.6) + ci(-1.8, 1.6, 1.8, '#e8283c', '#a81a2a') + ci(2, 1.8, 1.8, '#e8283c', '#a81a2a') + ci(-2.4, 1, 0.5, '#fff'),
    pearl: ci(0, 0, 3, '#fff8f0', '#c9b8d8') + ci(-1, -1, 0.9, '#ffffff') + pa('M1.2 1.6Q2.2 0.6 2 -0.6', null, '#e6d6ee', 0.5),
    cake: pa('M-3.8 3V-0.4L3.6-2.2V3Z', '#f6dca8', '#c9a46a') + pa('M-3.8-0.4L3.6-2.2V-0.8L-3.8 1Z', '#ff9fb6') + ci(1.6, -2.8, 0.9, '#e8283c'),
    shell: pa('M0 3.2L-3.8-1Q0-4.8 3.8-1Z', '#ffc9a8', '#d98a6a') + pa('M0 3.2L-1.6-3.4M0 3.2L0-3.6M0 3.2L1.6-3.4', null, '#d98a6a', 0.35),
    leaf: pa('M-3.6 3Q-3.6-3.6 3.6-3.6Q3.6 3-3.6 3Z', '#7cc35a', '#4f8f3a') + pa('M-3.6 3L2.4-2.4', null, '#4f8f3a'),
    honey: pa('M-2.8-1.4H2.8V2.6Q2.8 3.8 1.6 3.8H-1.6Q-2.8 3.8-2.8 2.6Z', '#f2b43a', '#c9861a') + pa('M-3-2.8H3V-1.4H-3Z', '#a86b36') + pa('M-1.6 0.6H1.6', null, '#fff2c0', 0.6),
    bamboo: pa('M-0.9-4.2H0.9V4.2H-0.9Z', '#8fc86a', '#5f9a4a') + pa('M-0.9-1.2H0.9M-0.9 1.8H0.9', null, '#5f9a4a', 0.5) + pa('M0.9-1.2Q3.4-2.6 3.8-0.8Q2.2-0.2 0.9-1.2Z', '#7cc35a'),
    acorn: pa('M-3-0.6Q0-3.6 3-0.6Z', '#8a5a2c', '#6a4220') + pa('M-2.6-0.6Q-2.6 3.4 0 4Q2.6 3.4 2.6-0.6Z', '#d39a5a', '#a86b36') + pa('M0-2.4L0.6-3.8', null, '#6a4220', 0.6),
    drop: pa('M0-4Q3 0.2 2.4 1.6A2.6 2.6 0 0 1-2.4 1.6Q-3 0.2 0-4Z', '#5ab4f0', '#2e86c8') + ci(-0.9, 0.8, 0.6, '#fff'),
    snow: pa('M0-4V4M-3.5-2L3.5 2M-3.5 2L3.5-2M-0.9-3.2L0-2.3L0.9-3.2M-0.9 3.2L0 2.3L0.9 3.2', null, '#6aaee6', 0.7),
    candy: pa('M-2.2 0L-4.2-1.8V1.8Z M2.2 0L4.2-1.8V1.8Z', '#ffb84a', '#d9861a') + ci(0, 0, 2.2, '#ff8a4a', '#d95a2a') + pa('M-1.4-1Q0 0.4 1.4-1', null, '#fff2d8', 0.5),
    fire: pa('M0 4Q-3.4 3.4-3 0Q-2.6-2 -1-2.6Q-1.4-1 0-0.6Q0.2-3 1.8-4.2Q1.6-2 2.8-0.8Q3.6 3.2 0 4Z', '#ff8a2a', '#d95a10') + pa('M0 3.4Q-1.6 3-1.3 1.2Q-1 0.4 0 0.2Q0.4 1 1.2 1.2Q1.6 3 0 3.4Z', '#ffd24a'),
    berry: pa('M-3-1Q0-2 3-1Q2.4 3 0 4.2Q-2.4 3-3-1Z', '#e8483c', '#b8302a') + pa('M-2.4-1.2L-1-2.6L0-1.6L1-2.6L2.4-1.2Q0-0.4-2.4-1.2Z', '#5fae4a') + [[-1.2, 0.6], [1, 0.4], [0, 2], [-1.4, 2.2], [1.3, 2]].map(([x, y]) => ci(x, y, 0.3, '#ffe9a0')).join(''),
  };
  function quilt(I, P, W, qk) {
    const ok = p => p && isFinite(p[0]) && isFinite(p[1]), hx = I.hq || {}, a = (P.tilt || 0) * Math.PI / 180, ux = [Math.cos(a), Math.sin(a)], uy = [-Math.sin(a), Math.cos(a)];
    let L = W.sideL, Rr = W.sideR;
    if (!ok(L) || !ok(Rr)) { const fl = W.footL, fr = W.footR, c = ok(fl) && ok(fr) ? [(fl[0] + fr[0]) / 2 - uy[0] * 11, (fl[1] + fr[1]) / 2 - uy[1] * 11] : ok(W.belly) ? W.belly : ok(W.body) ? W.body : null; if (!c) return '';
      const hs = ok(fl) && ok(fr) ? Math.max(Math.hypot(fr[0] - fl[0], fr[1] - fl[1]) * 1.15 + 9, 18) : 20; L = [c[0] - ux[0] * hs, c[1] - ux[1] * hs]; Rr = [c[0] + ux[0] * hs, c[1] + ux[1] * hs]; }
    const sp = Math.hypot(Rr[0] - L[0], Rr[1] - L[1]) || 30; I._qs = Math.max(I._qs || 0, sp);
    const hw = Math.min(I._qs * 0.56 + 4, 40), mx = (L[0] + Rr[0]) / 2, my = (L[1] + Rr[1]) / 2;
    const M = W.mouth, mz = ok(M) ? (M[0] - mx) * uy[0] + (M[1] - my) * uy[1] : -16, tg = cl(mz + 6.5, -24, 2) + (I._qy || 0); I._qt = I._qt == null ? tg : I._qt + (tg - I._qt) * 0.12;
    const y1 = 17, y0 = y1 - (y1 - I._qt) * cl(qk, 0, 1); if (y1 - y0 < 1.2) return '';
    const col = hx.quilt || '#7f9fd0', dk = shade(col, 0.7), lt = shade(col, 1.35), hh = y1 - y0, w2 = hw / 2;
    const top = 'M' + r2(-hw) + ' ' + r2(y0) + 'Q' + r2(-w2) + ' ' + r2(y0 - 1.6) + ' 0 ' + r2(y0 - 0.4) + 'Q' + r2(w2) + ' ' + r2(y0 - 1.6) + ' ' + r2(hw) + ' ' + r2(y0);
    const body = top + 'L' + r2(hw + 1.5) + ' ' + r2(y1 - 3) + 'Q' + r2(hw + 1.5) + ' ' + r2(y1 + 1) + ' ' + r2(hw - 3) + ' ' + r2(y1 + 1) + 'L' + r2(-hw + 3) + ' ' + r2(y1 + 1) + 'Q' + r2(-hw - 1.5) + ' ' + r2(y1 + 1) + ' ' + r2(-hw - 1.5) + ' ' + r2(y1 - 3) + 'Z';
    let h = '<g transform="matrix(' + r2(ux[0]) + ' ' + r2(ux[1]) + ' ' + r2(uy[0]) + ' ' + r2(uy[1]) + ' ' + r2(mx) + ' ' + r2(my) + ')">' + pa(body, col, dk, 0.7);
    h += '<ellipse cx="' + r2(-hw * 0.38) + '" cy="' + r2(y0 + hh * 0.34) + '" rx="' + r2(hw * 0.42) + '" ry="' + r2(hh * 0.22) + '" fill="' + lt + '" opacity="0.45"/>';
    h += pa('M' + r2(-hw - 1.5) + ' ' + r2(y1 - 3) + 'Q0 ' + r2(y1 - 5.5) + ' ' + r2(hw + 1.5) + ' ' + r2(y1 - 3) + 'Q' + r2(hw + 1.5) + ' ' + r2(y1 + 1) + ' ' + r2(hw - 3) + ' ' + r2(y1 + 1) + 'L' + r2(-hw + 3) + ' ' + r2(y1 + 1) + 'Q' + r2(-hw - 1.5) + ' ' + r2(y1 + 1) + ' ' + r2(-hw - 1.5) + ' ' + r2(y1 - 3) + 'Z', dk) .replace('/>', ' opacity="0.35"/>');
    if (hh > 7) { const ym = r2(y0 + hh * 0.55); h += '<path d="M' + r2(-hw / 3) + ' ' + r2(y0 + 3.4) + 'V' + r2(y1 - 0.6) + 'M' + r2(hw / 3) + ' ' + r2(y0 + 3.4) + 'V' + r2(y1 - 0.6) + 'M' + r2(-hw + 1) + ' ' + ym + 'H' + r2(hw - 1) + '" stroke="' + dk + '" stroke-width="0.45" stroke-dasharray="1.2 1" opacity="0.7" fill="none"/>'; }
    h += pa('M' + r2(-hw - 0.8) + ' ' + r2(y0 - 0.2) + 'Q' + r2(-w2) + ' ' + r2(y0 - 1.8) + ' 0 ' + r2(y0 - 0.6) + 'Q' + r2(w2) + ' ' + r2(y0 - 1.8) + ' ' + r2(hw + 0.8) + ' ' + r2(y0 - 0.2) + 'L' + r2(hw + 0.6) + ' ' + r2(y0 + 2.6) + 'Q' + r2(w2) + ' ' + r2(y0 + 1.4) + ' 0 ' + r2(y0 + 2.2) + 'Q' + r2(-w2) + ' ' + r2(y0 + 1.4) + ' ' + r2(-hw - 0.6) + ' ' + r2(y0 + 2.6) + 'Z', '#fffaf1', '#d6cbb8', 0.45);
    h += pa('M' + r2(-hw * 0.7) + ' ' + r2(y0 + 0.4) + 'Q' + r2(-w2) + ' ' + r2(y0 - 0.6) + ' ' + r2(-hw * 0.2) + ' ' + r2(y0 - 0.1), null, '#ffffff', 0.6);
    return h + '</g>';
  }
  function sleepFx(icon, zc, qy) {
    const IC = ICON[icon] || ICON.star;
    return (I, tt) => { const P = I.lastP || {}, W = I.W || {}; let h = ''; I._qy = qy || 0;
      const qk = P.qk || 0; if (qk > 0.02) h += quilt(I, P, W, qk);
      const H = W.head || I.topW; if (!H || !isFinite(H[0]) || !isFinite(H[1])) return h;
      const zz = P.zz || 0;
      if (zz > 0.03) for (let i = 0; i < 3; i++) { const u = ((tt / 2600) + i / 3) % 1, big = cl(zz - 1, 0, 1), x = H[0] + 11 + u * 13 + Math.sin(u * TAU) * 2, y = H[1] + 3 - u * 21 - big * 2;
        h += '<text x="' + r2(x) + '" y="' + r2(y) + '" font-family="Fredoka,sans-serif" font-weight="700" font-size="' + r2((4.5 + u * 4.8) * (1 + big * 0.55)) + '" fill="' + (zc || '#8f3cf2') + '" stroke="#ffffff" stroke-width="0.6" paint-order="stroke" opacity="' + r2(Math.sin(Math.PI * u) * cl(zz, 0, 1)) + '">' + (big > 0.4 ? 'Z' : 'z') + '</text>'; }
      const dm = cl(P.drm || 0, 0, 1);
      if (dm > 0.02) { const s = 0.55 + 0.45 * dm, bx = H[0] - 15, by = H[1] - 13 + Math.sin(tt / 700) * 1.2;
        h += '<g opacity="' + r2(dm) + '">' + ci(r2(H[0] - 5), r2(H[1] - 2), 1.1, '#ffffff', '#b9a6e0') + ci(r2(H[0] - 9), r2(H[1] - 6.5), 1.7, '#ffffff', '#b9a6e0') +
          '<g transform="translate(' + r2(bx) + ' ' + r2(by) + ') scale(' + r2(s) + ')"><circle r="8" fill="#ffffff" stroke="#b9a6e0" stroke-width="0.7"/><circle cx="-3" cy="-4" r="2.2" fill="#f2ecff"/><g transform="scale(1.05) rotate(' + r2(Math.sin(tt / 520) * 8) + ')">' + IC + '</g></g></g>'; }
      return h; };
  }
  // sleeping beats: each ends back on the lying pose
  const ZB = {
    breathe(t) { const B = t.B; t.osc(5600, 2, { sq: B.sq + 0.05, lift: B.lift + 0.5 }, { sq: B.sq - 0.015, lift: B.lift }, 's'); return t.back(300, ['sq', 'lift']); },
    snore(t, a, X) { const B = t.B; t.to(300, { zz: 1.8 }); for (let i = 0; i < 3; i++) t.to(1000, { sq: B.sq - 0.03, lift: B.lift + 0.6, open: 0.08, puff: 0 }, 's').to(700, o({ sq: B.sq + 0.08, lift: B.lift, open: 0.45, mw: 0.55, puff: 0.5 }, X.snore), 'o'); t.to(400, { zz: 1 }); return t.back(500); },
    dream(t, a, X) { t.to(700, o({ drm: 1, smile: 0.9, hap: 0.3, htilt: (t.B.htilt || 0) + 3 }, X.dream), 's').osc(1800, 3, { open: 0.14 }, { open: 0 }, 's').wait(1600).to(600, { drm: 0 }, 'io'); return t.back(600); },
    roll(t, s) { const B = t.B; s = s || 1; t.to(1000, { turn: (B.turn || 0) + s * 0.5, tilt: (B.tilt || 0) + s * 12, x: s * 2.2, htilt: s * 12, sq: B.sq + 0.03, [s < 0 ? 'armL' : 'armR']: (B.armL || 0) + 12 }, 's').osc(4400, 2, { sq: B.sq + 0.07 }, { sq: B.sq + 0.02 }, 's').to(260, { sqz: 0.4 }, 'o').to(300, { sqz: 0 }); return t.back(1000); },
    twitch(t) { const B = t.B; t.to(90, { earR: -10 }, 'o').to(160, { earR: 4 }).to(140, { earR: 0 }).wait(400).to(110, { footL: (B.footL || 0) + 2.4 }, 'o').to(300, { footL: B.footL || 0 }).wait(300).to(200, { sqz: 0.35 }, 'o').to(300, { sqz: 0 }); return t.back(300); },
    nuzzle(t) { const B = t.B; t.to(600, { htilt: (B.htilt || 0) + 6, pitch: (B.pitch || 0) + 0.08, sq: B.sq + 0.04, smile: 0.7 }, 's').osc(1500, 3, { x: 0.8 }, { x: -0.8 }, 's'); return t.back(700); },
    curl(t) { const B = t.B; t.to(1000, { curl: 1, sq: B.sq + 0.05, pitch: (B.pitch || 0) - 0.08, htilt: (B.htilt || 0) + 3, footL: (B.footL || 0) + 0.6, footR: (B.footR || 0) + 0.6 }, 's').wait(2000); return t.back(900); },
    peek(t) { t.to(300, { close: 0, winkL: 1, lx: 0.5, ly: 0.3, zz: 0 }, 'o').wait(1300).to(500, { close: 1, winkL: 0, lx: 0, ly: 0 }, 'io').to(500, { zz: 1 }); return t.back(300); },
    knead(t) { const B = t.B; t.to(300, { smile: 0.7 }).osc(2400, 6, { hLy: B.hLy + 3, hRy: B.hRy, sq: B.sq + 0.01 }, { hLy: B.hLy, hRy: B.hRy + 3, sq: B.sq }, 's'); return t.back(400); },
    shift(t) { const B = t.B; t.to(1100, { turn: -(B.turn || 0), tilt: -(B.tilt || 0), htilt: -(B.htilt || 0), lean: -(B.lean || 0), sq: B.sq + 0.05 }, 's').osc(4000, 2, { sq: B.sq + 0.07 }, { sq: B.sq + 0.03 }, 's'); return t.back(1100); },
  };
  const SORD = { bed: ['breathe', 'dream', 'snore', ['roll', 1], 'twitch', 'sig', 'breathe', ['roll', -1], 'snore', 'nuzzle'], lie: ['breathe', 'dream', ['roll', -1], 'snore', 'sig', 'twitch', ['roll', 1], 'nuzzle'], bean: ['breathe', 'dream', 'curl', 'peek', 'sig', 'snore', 'knead', 'shift'] };
  function sleepHold(LB, X, kind, fx) {
    const t = TL(LB), v = {}; keysOf(LB).forEach(p => v[p] = LB[p]); t.to(10, v); const bt = [], g = X.gap || [2200, 3000, 2600, 3400];
    (X[kind + 'Ord'] || SORD[kind]).forEach((b, i) => { t.wait(g[i % g.length]); const [n, a] = Array.isArray(b) ? b : [b], a0 = t.t; if (n === 'sig') { if (!X.s) return; X.s(t); } else ZB[n](t, a, X); bt.push([n, a0, t.t]); });
    t.wait(1600); const st = t.out({ breathe: 0.6, look: false, blend: 650, noBlink: true, fx }, true); st.beats = bt; return st;
  }
  // climb in: hop up (own style), fluff the pillow, lie back, pull the quilt up, drift off
  function bedIn(B, LB, P, X, kind, fx) {
    const t = TL(REST), dn = X.dn || (kind === 'bean' ? (P.dn === 'float' ? 'float' : 'flop') : P.dn || 'hop'); enterMove(t, B, dn); if (P.dnX) P.dnX(t, B);
    const v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(140, v, 'io');
    if (kind === 'bean') {
      t.to(240, { sq: B.sq + 0.2, lift: B.lift - 2.4 }, 'i').to(320, { sq: B.sq + 0.07, lift: B.lift - 1.2 }, 'o');
      t.to(700, { spin: 180, footL: (B.footL || 0) + 1.6, footR: B.footR || 0, x: 0.8 }, 'io').to(700, { spin: 360, footL: B.footL || 0, footR: (B.footR || 0) + 1.6, x: 0 }, 'io');
      t.to(1000, o(LB, { spin: 360, close: 0.6, zz: 0, smile: 0.6 }), 's').to(10, { spin: 0 }).to(900, { close: 1, zz: 1, smile: LB.smile }, 's');
    } else {
      t.to(300, { lx: -0.5, ly: 0.6, turn: -0.2 }, 'io').osc(900, 3, { hLy: (B.hLy || 0) + 6, armL: 16, sq: B.sq + 0.015 }, { hLy: (B.hLy || 0) + 2, armL: 10, sq: B.sq }, 'o').to(300, { lx: 0, ly: 0, turn: 0, hLy: B.hLy || 0, armL: B.armL || 0 }, 'io');
      t.to(900, o(LB, { qk: 0, zz: 0, drm: 0, close: 0.3, smile: 0.5 }), 's').to(260, { sq: LB.sq + 0.06 }, 'o').to(320, { sq: LB.sq }, 'io');
      if (kind === 'bed') t.to(320, { hLy: 9, hRy: 9, armL: -2, armR: -2, ly: 0.7 }, 'io').to(900, { hLy: LB.hLy, hRy: LB.hRy, armL: LB.armL, armR: LB.armR, qk: 1, ly: 0 }, 'io').to(240, { sq: LB.sq + 0.05, smile: 0.8 }, 'o').to(400, { sq: LB.sq }, 'io');
      else t.osc(900, 2, { x: 0.8, tilt: LB.tilt + 2 }, { x: -0.8, tilt: LB.tilt - 2 }, 's');
      t.to(700, { close: 0.75 }, 's').to(260, { close: 0.45 }).to(1000, { close: 1, zz: 1, smile: LB.smile }, 's');
    }
    const v2 = {}; keysOf(LB).forEach(p => v2[p] = LB[p]); t.to(220, v2, 'io');
    return t.out({ next: kind, blend: 220, fx });
  }
  // wake up (once): eyes flutter, sit up, big stretch + yawn, rub eyes, smile
  function wakeUp(LB, SB, P, X, kind, fx) {
    const t = TL(LB); t.wait(120).to(200, { close: 0.5, zz: 0, drm: 0 }).to(220, { close: 1 }).wait(160).to(180, { close: 0.25, wide: 0.2 });
    const up = { pitch: SB.pitch || 0, sq: SB.sq || 0, lift: SB.lift || 0, tilt: 0, htilt: 0, turn: 0, curl: SB.curl || 0, lean: 0, x: 0, footL: SB.footL || 0, footR: SB.footR || 0, qk: kind === 'bed' ? 0.55 : 0, close: 0.2, smile: 0.3, mw: 1, winkL: 0 };
    t.to(650, up, 'io');
    const W = o({ armL: 165, armR: 165, hLy: -5, hRy: -5, hLx: 0, hRx: 0, sq: (SB.sq || 0) - 0.08, close: 0.9, open: 0.9, mw: 0.8, tongue: 0.18, pitch: (SB.pitch || 0) + 0.3, wide: 0 }, X.wk || {});
    t.to(700, W, 'io'); if (X.wfx) t.fx(...X.wfx); t.osc(560, 2, { tilt: 1.6 }, { tilt: -1.6 }, 's');
    const rs = { armL: SB.armL || 0, armR: SB.armR || 0, hLy: SB.hLy || 0, hRy: SB.hRy || 0, hLx: SB.hLx || 0, hRx: SB.hRx || 0, sq: SB.sq || 0, open: 0, mw: 1, tongue: 0, pitch: SB.pitch || 0, close: 0.4, tilt: 0 }; keysOf(X.wk || {}).forEach(p => { if (rs[p] == null) rs[p] = SB[p] != null ? SB[p] : REST[p] || 0; });
    t.to(520, rs, 'io').e('blink');
    t.to(320, o(both(9, -15), { armL: 36, armR: 36, close: 1 }), 'io').osc(720, 3, { hLx: 11, hRx: -11, hLy: -14, hRy: -14 }, { hLx: 8, hRx: -8, hLy: -16, hRy: -16 }, 's').to(360, { hLx: SB.hLx || 0, hRx: SB.hRx || 0, hLy: SB.hLy || 0, hRy: SB.hRy || 0, armL: SB.armL || 0, armR: SB.armR || 0, close: 0 }, 'io').e('blink2');
    t.to(240, { smile: 1, hap: 0.6 }, 'o').wait(160);
    return t.out({ next: kind + 'out', blend: 320, fx });
  }
  // climb out: kick the quilt off (bed), wriggle out of the sink (beanbag), then hop down like standing up
  function bedOut(SB, P, X, kind, fx) {
    const B = o(SB, { qk: kind === 'bed' ? 0.55 : 0, smile: 1, hap: 0.6 }), t = TL(B), fL = SB.footL || 0, fR = SB.footR || 0;
    if (kind === 'bed') t.osc(660, 3, { footL: fL + 3, footR: fR, qk: 0.42 }, { footL: fL, footR: fR + 3, qk: 0.32 }, 'o').to(240, { qk: 0, footL: fL + 3.6, footR: fR + 3.6, open: 0.3 }, 'o').to(220, { footL: fL, footR: fR, open: 0 });
    else if (kind === 'bean') t.to(300, { sq: (SB.sq || 0) + 0.12, lift: (SB.lift || 0) - 1 }, 'io').osc(640, 3, { x: 1, tilt: 3 }, { x: -1, tilt: -3 }, 's').to(200, { x: 0, tilt: 0, sq: SB.sq || 0, lift: SB.lift || 0 }, 'io');
    else t.osc(600, 2, { x: 0.8 }, { x: -0.8 }, 's');
    const hop = t.t; exitMove(t, B, P.up || 'hop'); t.to(160, { sq: 0, lift: 0 }, 'io');
    const st = t.out({ next: 'idle', blend: 200, fx }); st.hop = hop; return st;
  }
  const BED = {};
  function bedBuild(key, X) {
    X = X || {}; const P = PROF[key] || {}, SB = o(SIT0, P.pose || {}), nm = n => key ? n + '@' + key : n, fx = sleepFx(X.dr, X.zc, X.qy);
    const fl = P.dn === 'float', sea = P.dn === 'flop' && (P.pose || {}).sit === 0, adj = fl ? { sit: 0, lift: 1.2 } : sea ? { sit: 0, pitch: -0.1, htilt: 4, lift: -1.6 } : {};
    const LB = o(SB, LIE0, adj, X.lp || {}), LN = o(LB, { qk: 0 }, X.np || {}), CB = o(SB, CURL0, fl ? { sit: 0, lift: 0.4 } : {}, X.bp || {}), S = {};
    [['bed', LB], ['lie', LN], ['bean', CB]].forEach(([k, base]) => {
      S[nm(k + 'in')] = bedIn(SB, base, P, X, k, fx); S[nm(k)] = sleepHold(base, X, k, fx); S[nm(k + 'wake')] = wakeUp(base, SB, P, X, k, fx); S[nm(k + 'out')] = bedOut(SB, P, X, k, fx);
    });
    R.add(S); R.HS = Object.assign(R.HS || {}, S); if (key) BED[key] = X;
  }
  // ---------- water: tub (bath), shower, swim (pool / sea), shake dry ----------
  // channels read by the rig water layer (rive-rig water()): wd depth (1 = up to his chin), sk sink, dv dive, fm foam, fh foam hat, dk duck (dkx), spg sponge, shw spray, stm steam, wet drips
  const BATH0 = o({ sit: 1, sq: 0.08, lift: 0, sk: 9, wd: 0.74, fm: 1, dk: 1, dkx: 0, smile: 0.85, hap: 0.35, close: 0.2, pitch: 0.05, armL: 26, armR: 26, wet: 0, fh: 0, spg: 0, dv: 0 }, both(3, -3));
  const SHOW0 = { sq: 0, lift: 0, sk: 0, tilt: 0, armL: 0, armR: 0, hLx: 0, hRx: 0, hLy: 0, hRy: 0, shw: 1, stm: 0.7, wet: 1, close: 0.5, smile: 0.9, hap: 0.4, pitch: -0.1, fh: 0, spg: 0 };
  const SWIM0 = o({ sit: 0, sq: 0.03, lift: 0, sk: 7, wd: 0.8, pitch: -0.1, smile: 0.7, hap: 0.3, armL: 38, armR: 38, wet: 0, dv: 0, fm: 0, dk: 0 }, both(1, -4));
  // swim styles: paddle (doggy paddle), glide (sea creatures: smooth with tail sweeps), float (floaters ride high), bob (round foods bob like a cork)
  const SWS = { paddle: {}, glide: { sk: 9, wd: 0.86, armL: 24, armR: 24, pitch: -0.04 }, float: { sk: 2, wd: 0.55, armL: 30, armR: 30 }, bob: { sk: 5, wd: 0.7, armL: 20, armR: 20, sq: 0.05 } };
  function stroke(t, d, B, sw, X) { const n = Math.max(1, Math.round(d / (sw === 'glide' ? 1400 : sw === 'float' ? 1600 : sw === 'bob' ? 1300 : 900))), h = d / n / 2, L = B.lift || 0, Q = B.sq || 0, xa = X.ka || {}, xb = X.kb || {};
    for (let i = 0; i < n; i++) {
      if (sw === 'glide') t.to(h, o({ wag: 18, tilt: 1.6, x: 0.6, lift: L + 0.6, htilt: -1.5 }, X.sa), 's').to(h, o({ wag: -18, tilt: -1.6, x: -0.6, lift: L - 0.3, htilt: 1.5 }, X.sb), 's');
      else if (sw === 'float') t.to(h, o({ lift: L + 1.6, sq: Q - 0.03, tilt: 2, armL: (B.armL || 0) + 14, armR: (B.armR || 0) - 6 }, X.sa), 's').to(h, o({ lift: L - 0.4, sq: Q + 0.03, tilt: -2, armL: (B.armL || 0) - 6, armR: (B.armR || 0) + 14 }, X.sb), 's');
      else if (sw === 'bob') t.to(h, o({ lift: L + 1.3, sq: Q - 0.04, turn: 0.14, tilt: 1.5 }, X.sa), 's').to(h, o({ lift: L - 0.5, sq: Q + 0.04, turn: -0.14, tilt: -1.5 }, X.sb), 's');
      else t.to(h, o({ armL: (B.armL || 0) + 26, armR: (B.armR || 0) - 16, tilt: 2.6, x: 0.5, lift: L + 0.8, htilt: -2.2, footL: 1.4, footR: 0 }, X.sa), 's').to(h, o({ armL: (B.armL || 0) - 16, armR: (B.armR || 0) + 26, tilt: -2.6, x: -0.5, lift: L - 0.3, htilt: 2.2, footL: 0, footR: 1.4 }, X.sb), 's');
      if (i % 2) t.fx('drop', i % 4 === 1 ? 'sideL' : 'sideR', 2);
    }
    return t.back(260, ['armL', 'armR', 'tilt', 'x', 'lift', 'htilt', 'footL', 'footR', 'wag', 'sq', 'turn']);
  }
  // shake dry (once, also the end of every water out move): quick wiggles side to side, drops fly off, fur fluffs up
  function shakeDry(t, X) { const k = X.k || {}, A = o({ x: 1.7, tilt: 8, htilt: -7, earL: -14, earR: 12, sq: 0.03, close: 0.7, open: 0.2 }, k.a), Bv = o({ x: -1.7, tilt: -8, htilt: 7, earL: 12, earR: -14, sq: -0.02, close: 0.7, open: 0.2 }, k.b);
    t.to(220, { sq: 0.08, close: 0.5, wet: 1, lift: 0 }, 'io');
    for (let j = 0; j < 3; j++) { t.osc(340, 3, A, Bv, 'l'); t.fx('splash', j === 1 ? 'head' : 'body', j === 1 ? 5 : 7).fx('drop', j % 2 ? 'sideL' : 'sideR', 4); }
    t.to(160, { x: 0, tilt: 0, htilt: 0, earL: 0, earR: 0, wet: 0.2 }, 'io').to(220, o({ sq: -0.09, lift: 2, wide: 0.6, hap: 1, smile: 1, open: 0.35, close: 0, wet: 0 }, k.f), 'o').to(240, { sq: 0.03, lift: 0 }, 'i').e('blink2');
    const z = { wide: 0, hap: 0, smile: 0, open: 0, sq: 0, lift: 0, close: 0 }; Object.keys(o(k.a, k.f)).forEach(p => z[p] = REST[p] || 0); return t.to(320, z, 'io'); }
  // tub beats (each ends back on the bath pose)
  const TB = {
    soak(t) { const B = t.B; t.to(900, { sk: B.sk + 2.5, close: 0.85, smile: 1, open: 0.15, sq: B.sq + 0.04 }, 's').wait(1300).to(700, { open: 0 }).wait(400); return t.back(700); },
    scrub(t) { const B = t.B; t.to(300, { spg: 1 }, 'o').to(420, o(hand(1, 2, -17), { armR: 118, htilt: 5, close: 0.6 }), 'io').osc(1500, 6, { hRx: 2, htilt: 7, fh: 0.5 }, { hRx: -4, htilt: 3, fh: 0.8 }, 's').fx('foam', 'head', 2)
      .to(380, o(hand(1, 9, -9), { armR: 40, fh: 1 }), 'io').osc(1000, 4, { hRy: -7, sqz: 0.5 }, { hRy: -10, sqz: 0.2 }, 's').to(260, { spg: 0, sqz: 0 }); return t.back(500, ['armR', 'hRx', 'hRy', 'htilt', 'close', 'sqz']); },
    bubbles(t) { for (let i = 0; i < 2; i++) t.to(320, { puff: 0.75, open: 0, close: 0.2 }, 'io').to(260, { puff: 0, open: 0.3, mw: 0.45 }, 'o').fx(i ? 'bigbubble' : 'bubble', 'mouth', 2).to(700, { ly: -0.9, lx: 0.5, wide: 0.5, open: 0.1, mw: 1 }, 's');
      t.to(300, { hap: 1, sqz: 0.6, smile: 1, open: 0.3 }, 'o').wait(400); return t.back(500); },
    duck(t) { t.to(500, { lx: 0.9, ly: 0.5, turn: 0.22, htilt: 4 }, 'io').to(300, o(hand(1, 13, 0), { armR: 30 }), 'io').to(160, { dkx: -0.25 }, 'o').to(500, { dkx: 0.35, hRx: -8, wide: 0.7, open: 0.45, hap: 1 }, 'o').fx('note', 'head')
      .to(400, { sqz: 0.7, smile: 1 }).wait(500).to(900, { dkx: 0 }, 's'); return t.back(500, ['lx', 'ly', 'turn', 'htilt', 'armR', 'hRx', 'hRy', 'wide', 'open', 'hap', 'sqz', 'smile']); },
    splash(t) { const B = t.B; t.to(200, { hap: 1, smile: 1, open: 0.4 }); for (let i = 0; i < 3; i++) t.to(220, { armL: 75, armR: 75, hLy: -8, hRy: -8, lift: 0.8 }, 'o').to(150, { armL: 18, armR: 18, hLy: B.hLy, hRy: B.hRy, lift: 0, sqz: 0.8 }, 'i').fx('splash', 'sideL', 5).fx('splash', 'sideR', 5).to(180, { sqz: 0.3 });
      return t.back(420); },
    foamhat(t) { t.to(1400, { fh: 1.7, ly: -1, pitch: 0.18, wide: 0.5 }, 's').to(300, { sqz: 0.7, hap: 1, smile: 1, open: 0.3 }, 'o').wait(400).to(320, { puff: 0.8, ly: -0.6, open: 0 }, 'io').to(260, { puff: 0, open: 0.35, fh: 0, pitch: -0.05 }, 'o').fx('foam', 'head', 4).fx('bubble', 'head', 3).wait(300); return t.back(500); },
    sing(t) { t.to(300, { close: 0.6, smile: 0.9, open: 0.35, mw: 0.6 }).fx('note', 'head').osc(2400, 4, { htilt: 7, x: 0.8, open: 0.45 }, { htilt: -7, x: -0.8, open: 0.25 }, 's').fx('note', 'head'); return t.back(450); },
  };
  // shower beats
  const SB0 = {
    lather(t) { t.to(380, o(both(4, -18), { armL: 120, armR: 120, close: 0.9, smile: 1 }), 'io').osc(1800, 6, { hLx: 6, hRx: -1, fh: 0.6, htilt: 4 }, { hLx: 1, hRx: -6, fh: 1, htilt: -4 }, 's').fx('foam', 'head', 3).to(420, { armL: t.B.armL || 0, armR: t.B.armR || 0, hLx: t.B.hLx || 0, hRx: t.B.hRx || 0, hLy: t.B.hLy || 0, hRy: t.B.hRy || 0, fh: 1.1 }, 'io'); return t.back(300, ['close', 'smile', 'htilt']); },
    rinse(t) { t.to(500, { pitch: -0.32, close: 1, open: 0.3, mw: 0.6 }, 'io').osc(1200, 4, { open: 0.45, puff: 0.3 }, { open: 0.15, puff: 0 }, 's').to(900, { fh: 0 }, 'io').fx('drop', 'head', 5).to(240, { pitch: -0.05, close: 0, wide: 0.5, open: 0.2 }, 'o').e('blink2'); return t.back(500); },
    sing(t) { t.to(380, o(hand(1, 9, -12), { armR: 34, close: 0.55, open: 0.45, mw: 0.6 }), 'io').fx('note', 'head').osc(2600, 4, { htilt: 8, lean: 0.8, open: 0.55 }, { htilt: -8, lean: -0.8, open: 0.3 }, 's').fx('note', 'head').fx('note', 'head'); return t.back(500); },
    turn(t) { t.to(1800, { spin: 360, close: 0.8 }, 'io').to(10, { spin: 0 }); return t.back(300, ['close']); },
    shiver(t) { t.to(120, { wide: 1, sq: (t.B.sq || 0) - 0.05, open: 0.4, mw: 0.5, armL: 30, armR: 30 }, 'o').osc(600, 6, { x: 0.6 }, { x: -0.6 }, 'l').to(240, { sqz: 0.6, wide: 0 }).to(300, { sqz: 0, smile: 1 }); return t.back(420); },
  };
  // swim beats
  const WB0 = {
    back(t) { const B = t.B; t.to(800, { pitch: 0.45, sk: B.sk - 2.5, wd: B.wd * 0.85, close: 0.75, smile: 1, armL: 96, armR: 96, hLy: -2, hRy: -2, tilt: 0 }, 's').osc(2600, 2, { lift: (B.lift || 0) + 0.8, tilt: 2 }, { lift: B.lift || 0, tilt: -2 }, 's'); return t.back(800); },
    dive(t) { t.to(300, { puff: 0.7, close: 1, wide: 0 }, 'io').to(420, { dv: 1, sq: (t.B.sq || 0) - 0.05 }, 'i').fx('splash', 'head', 5).wait(300).fx('bubble', 'head', 3).wait(600).fx('bubble', 'head', 2).wait(300)
      .to(240, { dv: 0, puff: 0, lift: (t.B.lift || 0) + 3, sq: (t.B.sq || 0) - 0.08, close: 0, wide: 0.8, open: 0.4 }, 'o').fx('splash', 'head', 7).to(240, { lift: t.B.lift || 0, sq: t.B.sq || 0 }, 'i').osc(500, 4, { htilt: 9 }, { htilt: -9 }, 'l').fx('drop', 'head', 4); return t.back(400); },
    splash(t) { TB.splash(t); return t; },
    spout(t) { t.to(300, { puff: 0.8, open: 0 }, 'io').to(160, { puff: 0, open: 0.45, mw: 0.5 }, 'o').fx('gush', 'mouth', 4).fx('splash', 'mouth', 4).wait(260).to(200, { hap: 1, sqz: 0.6, smile: 1 }).wait(300); return t.back(400); },
    wave(t) { BEAT.wave(t, 1); return t; },
  };
  const WORD = { tub: ['soak', 'scrub', 'bubbles', 'duck', 'sig', 'splash', 'foamhat', 'sing'], shower: ['lather', 'rinse', 'sing', 'sig', 'turn', 'shiver'], swim: ['back', 'splash', 'dive', 'sig', 'spout', 'wave'] };
  function wHold(B, X, kind, sw) {
    const t = TL(B), v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(10, v); const bt = [], g = X.gap || (kind === 'swim' ? [1800, 2400, 2000, 2600] : [1700, 2300, 1900, 2500]), L = X[kind + 'Ord'] || WORD[kind], BK = kind === 'tub' ? TB : kind === 'shower' ? SB0 : WB0;
    const sig = kind === 'swim' ? X.ws || X.s : kind === 'shower' ? X.ss || X.s : X.s;
    L.forEach((n, i) => { if (kind === 'swim') stroke(t, g[i % g.length], B, sw, X); else t.wait(g[i % g.length]); const a = t.t; if (n === 'sig') { if (!sig) return; sig(t); } else BK[n](t); bt.push([n, a, t.t]); });
    if (kind === 'swim') stroke(t, 1600, B, sw, X); else t.wait(1400);
    const st = t.out({ breathe: kind === 'swim' ? 0.4 : 0.8, look: kind !== 'shower', blend: 520 }, true); st.beats = bt; return st;
  }
  // tub: hop in over the rim (splash), sink in with a happy sigh, the duck pops up / rise, hop out, shake dry
  function tubIn(B, P, X) { const t = TL(REST), fl = P.dn === 'float';
    if (fl) t.to(300, { lift: 6, sq: -0.04, hap: 0.4 }, 'o').to(500, { lift: 9, wd: 0.25, fm: 1 }, 's');
    else t.to(160, { sq: 0.12, armL: -8, armR: -8 }, 'io').to(260, { lift: 9, sq: -0.12, footL: 2.4, footR: 2.4, armL: 50, armR: 50, open: 0.3 }, 'o').to(10, { wd: 0.25, fm: 1 });
    t.to(230, { lift: 0, sq: 0.14, footL: 0, footR: 0, sit: 1, wd: 0.45, armL: 40, armR: 40 }, 'i').fx('splash', 'belly', 9).fx('drop', 'sideL', 3).fx('drop', 'sideR', 3);
    t.to(220, { sq: 0.02, wide: 0.6, open: 0.4 }, 'o').to(1000, o(B, { close: 0.65, open: 0.3, smile: 1, dk: 0 }), 's').to(450, { dk: 1, close: B.close, open: 0 }, 'o').fx('bubble', 'belly', 2);
    if (X.inX) X.inX(t, B); const v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(200, v, 'io');
    return t.out({ next: 'tub', blend: 240 }); }
  function tubOut(B, P, X) { const t = TL(B);
    t.to(400, { dk: 0, fh: 0, spg: 0 }, 'io').to(520, { sk: 0, wd: 0.5, lift: 1.5, sq: -0.03, open: 0.15, armL: 30, armR: 30 }, 'io');
    t.to(160, { sq: 0.1, armL: -6, armR: -6 }, 'io').to(250, { lift: 9, sq: -0.12, wd: 0.12, sit: 0, footL: 2.4, footR: 2.4, armL: 40, armR: 40 }, 'o').to(10, { wd: 0, fm: 0, wet: 1 });
    const hop = t.t; t.to(210, { lift: 0, sq: 0.1, footL: 0, footR: 0, armL: 0, armR: 0 }, 'i'); shakeDry(t, X);
    const z = {}; keysOf(B).forEach(p => z[p] = REST[p] || 0); t.to(200, z, 'io'); const st = t.out({ next: 'idle', blend: 200 }); st.hop = hop; return st; }
  // shower: step in, spray on, first cold drops make him flinch, then he relaxes / spray off, shake, step out
  function showerIn(B, X) { const t = TL(REST);
    t.to(220, { footL: 2, lift: 1.2, tilt: 2 }, 'io').to(220, { footL: 0, footR: 2, lift: 0.4, tilt: -2 }, 'io').to(200, { footR: 0, lift: 0, tilt: 0, ly: -0.9, pitch: -0.1 }, 'io').to(300, { shw: 1 }, 'o');
    t.to(110, { wide: 1, sq: -0.07, open: 0.45, mw: 0.5, armL: 34, armR: 34, wet: 1 }, 'o').osc(560, 6, { x: 0.7 }, { x: -0.7 }, 'l').to(260, { sqz: 0.7, wide: 0 }).fx('splash', 'head', 4);
    const v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(700, o(v, { sqz: 0, ly: 0, x: 0, open: 0.2 }), 'io').to(300, { stm: B.stm, open: 0 }, 's');
    if (X.inX) X.inX(t, B); return t.out({ next: 'shower', blend: 220 }); }
  function showerOut(B, X) { const t = TL(B); t.to(320, { shw: 0, fh: 0 }, 'io').to(300, { stm: 0, close: 0, pitch: 0 }, 'io'); shakeDry(t, X);
    t.to(220, { footL: 2, lift: 1.2 }, 'io').to(220, { footL: 0, footR: 2, lift: 0.4 }, 'io').to(180, { footR: 0, lift: 0 }, 'io'); const z = {}; keysOf(B).forEach(p => z[p] = REST[p] || 0); t.to(200, z, 'io'); return t.out({ next: 'idle', blend: 200 }); }
  // swim: wade in step by step as the water rises, a little brr, then off he paddles / wade back out, shake dry
  function swimIn(B, X) { const t = TL(REST), n = 4;
    for (let i = 0; i < n; i++) { const u = (i + 1) / n; t.to(300, { footL: i % 2 ? 0 : 2.2, footR: i % 2 ? 2.2 : 0, tilt: i % 2 ? -2 : 2, wd: B.wd * u, sk: B.sk * u, armL: 22 + 20 * u, armR: 22 + 20 * u, sit: B.sit * u, open: 0.2 }, 'io').fx('drop', i % 2 ? 'sideR' : 'sideL', 3); }
    t.to(120, { wide: 0.9, sq: -0.05, footL: 0, footR: 0, tilt: 0 }, 'o').osc(500, 5, { x: 0.6 }, { x: -0.6 }, 'l').to(240, { wide: 0, sqz: 0.5, smile: 1, hap: 0.8 }).fx('splash', 'sideL', 4).fx('splash', 'sideR', 4);
    const v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(500, o(v, { sqz: 0, x: 0 }), 'io'); if (X.inX) X.inX(t, B); return t.out({ next: 'swim', blend: 220 }); }
  function swimOut(B, X) { const t = TL(B), n = 4;
    for (let i = 0; i < n; i++) { const u = 1 - (i + 1) / n; t.to(300, { footL: i % 2 ? 0 : 2.2, footR: i % 2 ? 2.2 : 0, tilt: i % 2 ? -2 : 2, wd: B.wd * u, sk: B.sk * u, dv: 0, armL: 10 + 20 * u, armR: 10 + 20 * u, sit: (B.sit || 0) * u, pitch: 0, wet: 1 }, 'io').fx('drop', i % 2 ? 'sideR' : 'sideL', 3); }
    t.to(160, { footL: 0, footR: 0, tilt: 0, wd: 0 }, 'io'); shakeDry(t, X); const z = {}; keysOf(B).forEach(p => z[p] = REST[p] || 0); t.to(200, z, 'io'); return t.out({ next: 'idle', blend: 200 }); }
  const WAT = {};
  function waterBuild(key, X) {
    X = X || {}; const P = PROF[key] || {}, nm = n => key ? n + '@' + key : n, sw = X.sw || (P.dn === 'float' ? 'float' : 'paddle'), S = {};
    const TBp = o(BATH0, P.dn === 'float' ? { sit: 0, sk: 4 } : {}, X.bp || {}), SHp = o(SHOW0, X.hp || {}), SWp = o(SWIM0, SWS[sw] || {}, X.wp || {});
    S[nm('tubin')] = tubIn(TBp, P, X); S[nm('tub')] = wHold(TBp, X, 'tub', sw); S[nm('tubout')] = tubOut(TBp, P, X);
    S[nm('showerin')] = showerIn(SHp, X); S[nm('shower')] = wHold(SHp, X, 'shower', sw); S[nm('showerout')] = showerOut(SHp, X);
    S[nm('swimin')] = swimIn(SWp, X); S[nm('swim')] = wHold(SWp, X, 'swim', sw); S[nm('swimout')] = swimOut(SWp, X);
    const sk = TL(o(REST, { wet: 1 })); shakeDry(sk, X); S[nm('shake')] = sk.out({ next: 'idle', blend: 200 });
    R.add(S); R.HS = Object.assign(R.HS || {}, S); if (key) WAT[key] = X;
  }
  // ---------- play (swing, rocking horse) + kitchen (cook, fridge rummage) ----------
  // swing / ride: the house rotates the rider with the seat and adds the leg pump + ear / tail lag in sync with it (ext, st.sync); these states hold the grip pose and the beats
  ICON.cookie = ci(0, 0, 3.6, '#e2a85a', '#a8702e') + ci(-1.2, -1.1, 0.6, '#5a3420') + ci(1.4, -0.3, 0.7, '#5a3420') + ci(-0.3, 1.5, 0.6, '#5a3420') + ci(1.7, 1.9, 0.4, '#5a3420') + ci(-1.9, 0.9, 0.4, '#5a3420');
  const SWG0 = { armL: 118, armR: 118, hLx: -1, hRx: 1, hLy: -3, hRy: -3, smile: 0.9, hap: 0.4 };
  const RID0 = o({ armL: 26, armR: 26, smile: 0.85, hap: 0.4, footL: 0.8, footR: 0.8 }, both(10, -3));
  const CK0 = o({ sq: 0, lift: 0, pitch: -0.12, ly: 0.6, smile: 0.6, hap: 0.2, armR: 40, armL: 14 }, hand(1, 12, -3), hand(-1, 6, 2));
  const PB = {
    wheee(t, X) { const B = t.B; t.to(300, o({ open: 0.6, mw: 0.6, wide: 0.8, hap: 1, smile: 1, pitch: (B.pitch || 0) + 0.16, footL: (B.footL || 0) + 3, footR: (B.footR || 0) + 3 }, X.cheer), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('spark', 'head', 3); t.wait(1300); return t.back(500); },
    breeze(t) { const B = t.B; t.to(800, { pitch: (B.pitch || 0) + 0.3, close: 0.85, smile: 1, open: 0.15, footL: (B.footL || 0) + 2.4, footR: (B.footR || 0) + 2.4, htilt: 5 }, 's').wait(1800); return t.back(700); },
    peek(t) { const B = t.B; t.to(380, { pitch: (B.pitch || 0) - 0.24, ly: 0.9, wide: 1, open: 0.3, mw: 0.5, sq: (B.sq || 0) - 0.03 }, 'io').wait(700).to(220, { sqz: 0.8, hap: 1, smile: 1, wide: 0, ly: 0.3, open: 0.35 }, 'o').osc(700, 4, { sq: (B.sq || 0) + 0.03 }, { sq: B.sq || 0 }, 'o'); return t.back(450); },
    onehand(t) { t.to(380, { armR: 152, hRx: 3, hRy: -5, hap: 1, smile: 1, open: 0.35, htilt: 5 }, 'o').osc(1300, 3, { armR: 136 }, { armR: 168 }, 'io'); return t.back(480); },
    higher(t) { const B = t.B, f = B.footL || 0, g = B.footR || 0, p0 = B.pitch || 0; t.to(260, { sqz: 0.3, smile: 1, mw: 0.7, open: 0.2 }).osc(1800, 4, { footL: f + 3.4, footR: g + 3.4, lean: 1.2, pitch: p0 + 0.12 }, { footL: f - 0.4, footR: g - 0.4, lean: -1.2, pitch: p0 - 0.06 }, 's').to(260, { sqz: 0, wide: 0.6, hap: 1, open: 0.45 }, 'o').fx('spark', 'head', 3).wait(400); return t.back(500); },
    giggle(t) { const B = t.B; t.to(260, { hap: 1, sqz: 0.7, smile: 1, open: 0.4, blush: 0.5 }, 'o').osc(1000, 5, { sq: (B.sq || 0) + 0.03, htilt: 4 }, { sq: B.sq || 0, htilt: -4 }, 'o'); return t.back(450); },
  };
  const RB = {
    gallop(t) { const B = t.B, L = B.lift || 0, Q = B.sq || 0, f = B.footL || 0, g = B.footR || 0; t.to(200, { hap: 1, smile: 1, open: 0.35 }).osc(1500, 6, { footL: f + 2.6, footR: g + 2.6, sq: Q + 0.05, lift: L }, { footL: f, footR: g, sq: Q - 0.02, lift: L + 1.4 }, 'o'); return t.back(400); },
    yeehaw(t, X) { t.to(320, o({ armR: 158, hRx: 0, hRy: -8, open: 0.55, mw: 0.7, hap: 1, smile: 1, wide: 0.4, htilt: -4 }, X.cheer), 'o'); for (let i = 0; i < 3; i++) t.to(150, { hRx: 4, hRy: -10 }, 'l').to(150, { hRx: 0, hRy: -13 }, 'l').to(150, { hRx: -4, hRy: -10 }, 'l').to(150, { hRx: 0, hRy: -7 }, 'l'); t.fx('note', 'head'); return t.back(450); },
    race(t) { const B = t.B; t.to(500, { pitch: (B.pitch || 0) - 0.2, sq: (B.sq || 0) + 0.03, wide: 0.6, sqz: 0.25, smile: 1, mw: 0.7, hLy: (B.hLy || 0) + 3, hRy: (B.hRy || 0) + 3 }, 'io').osc(1400, 4, { lean: 0.8 }, { lean: -0.4 }, 's'); return t.back(500); },
    whoa(t) { const B = t.B; t.to(300, { pitch: (B.pitch || 0) + 0.26, hLy: (B.hLy || 0) + 5, hRy: (B.hRy || 0) + 5, hLx: (B.hLx || 0) - 3, hRx: (B.hRx || 0) + 3, wide: 0.8, open: 0.45, mw: 0.5 }, 'o').wait(700).to(240, { sqz: 0.6, hap: 1, smile: 1, open: 0.3, wide: 0 }, 'o').wait(300); return t.back(500); },
    pat(t) { t.to(380, o(hand(1, 14, 4), { armR: 16, htilt: 5, lx: 0.4, ly: 0.5, smile: 1, close: 0.3 }), 'io').osc(1100, 3, { hRy: 7 }, { hRy: 3 }, 'o').fx('heart', 'head'); return t.back(450); },
    cheer(t, X) { WBEAT.cheer(t, X); return t; },
  };
  const PORD = { swing: ['wheee', 'peek', 'sig', 'breeze', 'onehand', 'higher', 'giggle', 'kick'], ride: ['gallop', 'yeehaw', 'pat', 'sig', 'race', 'whoa', 'cheer'] };
  function playHold(B, X, kind, sig) {
    const t = TL(B), v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(10, v); const bt = [], g = X.pgap || [1500, 2100, 1700, 2300], BK = kind === 'swing' ? PB : RB;
    (X[kind + 'Ord'] || PORD[kind]).forEach((n, i) => { t.wait(g[i % g.length]); const a = t.t; if (n === 'sig') { if (!sig) return; sig(t); } else if (n === 'kick') BEAT.kick(t); else BK[n](t, X); bt.push([n, a, t.t]); });
    t.wait(1200); const st = t.out({ breathe: 0.6, look: kind === 'swing', blend: 520 }, true); st.beats = bt; st.sync = o({ ear: 14, wag: 20 }, X.sy || {}); return st;
  }
  // get on: hop up (swing) / climb on (horse), grab the ropes / handles, first push
  function playIn(B, P, kind) {
    const t = TL(REST), dn = kind === 'ride' ? (P.dn === 'float' || P.dn === 'flop' ? P.dn : 'climb') : (P.dn || 'hop'); enterMove(t, B, dn);
    const v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(160, v, 'io');
    if (kind === 'swing') t.to(260, { ly: -0.8, pitch: (B.pitch || 0) + 0.12 }, 'io').to(200, { sq: (B.sq || 0) + 0.05, sqz: 0.5, hLy: B.hLy + 1, hRy: B.hRy + 1 }, 'o').to(280, { ly: 0, pitch: B.pitch || 0, sq: B.sq || 0, sqz: 0, hLy: B.hLy, hRy: B.hRy, hap: 1, smile: 1 }, 'io')
      .to(360, { footL: (B.footL || 0) - 0.6, footR: (B.footR || 0) - 0.6, lean: 1 }, 'io').to(300, { footL: B.footL || 0, footR: B.footR || 0, lean: 0, hap: B.hap }, 'io');
    else t.to(240, { sqz: 0.4, hLx: B.hLx + 1.5, hRx: B.hRx - 1.5 }, 'o').to(300, { sqz: 0, hLx: B.hLx, hRx: B.hRx, hap: 1, open: 0.4, smile: 1 }, 'io').osc(700, 2, { lean: 1, sq: (B.sq || 0) + 0.03 }, { lean: -0.5, sq: B.sq || 0 }, 's').to(260, { open: 0, hap: B.hap, lean: 0 }, 'io');
    return t.out({ next: kind, blend: 220 });
  }
  // get off: drag the feet to slow the swing / whoa the horse, then hop down (house keeps the seat height until st.hop)
  function playOut(B, P, kind) {
    const t = TL(B), f = B.footL || 0, g = B.footR || 0;
    if (kind === 'swing') t.to(360, { footL: f - 0.8, footR: g - 0.8, sq: (B.sq || 0) + 0.04, pitch: (B.pitch || 0) - 0.1, wide: 0.3 }, 'io').osc(700, 4, { x: 0.4 }, { x: -0.4 }, 'l').to(200, { x: 0, wide: 0 });
    else t.to(400, { pitch: (B.pitch || 0) + 0.18, hLy: B.hLy + 4, hRy: B.hRy + 4, open: 0.3 }, 'io').wait(500).to(200, { open: 0, pitch: B.pitch || 0 });
    const hop = t.t; exitMove(t, B, P.up === 'float' || P.up === 'flop' ? P.up : 'hop'); t.to(160, { sq: 0, lift: 0 }, 'io').to(200, { hap: 0.8, smile: 1 }, 'o').to(240, { hap: REST.hap || 0, smile: REST.smile || 0 }, 'io');
    const st = t.out({ next: 'idle', blend: 200 }); st.hop = hop; return st;
  }
  // cook beats (standing at the stove, facing it; the spoon / pan props follow the right paw)
  const CB = {
    stir(t) { const B = t.B, x0 = B.hRx || 0, y0 = B.hRy || 0; t.to(200, { ly: 0.8 }); for (let i = 0; i < 4; i++) t.to(170, { hRx: x0 - 3, hRy: y0 + 1.5, htilt: 3 }, 'l').to(170, { hRx: x0, hRy: y0 + 3 }, 'l').to(170, { hRx: x0 + 3, hRy: y0 + 1.5, htilt: -3 }, 'l').to(170, { hRx: x0, hRy: y0 }, 'l'); t.fx('steam', 'pawR'); return t.back(300); },
    season(t) { t.to(340, o(hand(-1, 12, -10), { armL: 44, htilt: -5, close: 0.3 }), 'io').osc(450, 3, { hLy: -12, hLx: 13 }, { hLy: -9, hLx: 11 }, 'l').fx('salt', 'pawL', 3).osc(450, 3, { hLy: -12, hLx: 13 }, { hLy: -9, hLx: 11 }, 'l').fx('salt', 'pawL', 3); return t.back(400); },
    shake(t) { t.to(300, o(hand(1, 2, -2), { armR: 44, ly: 0.7, lx: 0.5 }), 'io').osc(600, 4, { hRx: -4, hRy: -3 }, { hRx: 0, hRy: -1 }, 'l').fx('steam', 'pawR').osc(600, 4, { hRx: -4, hRy: -3 }, { hRx: 0, hRy: -1 }, 'l').fx('steam', 'pawR'); return t.back(350); },
    flip(t, X, rec) { const B = t.B, Q = B.sq || 0, p0 = B.pitch || 0; t.to(300, o(hand(1, 2, -1), { armR: 42, lx: 0.5 }), 'io').to(200, { hRy: 2, sq: Q + 0.04 }, 'io'); rec.push(t.t);
      t.to(160, { armR: 66, hRy: -6, sq: Q - 0.04, lx: 0.6, ly: -0.9, pitch: p0 + 0.24, wide: 0.7, open: 0.35 }, 'o').to(520, { armR: 48, hRy: -2, ly: -1 }, 'io').to(320, { ly: 0.7, pitch: p0 - 0.06 }, 'i').to(140, { sq: Q + 0.05, hRy: 1 }, 'o').to(260, { sq: Q, sqz: 0.7, hap: 1, smile: 1, open: 0.3, wide: 0 }, 'o').wait(400); return t.back(450); },
    taste(t, X) { const B = t.B; t.to(420, o(hand(1, 8, -13), { armR: 36, ly: 0, lx: 0, pitch: (B.pitch || 0) + 0.04 }), 'io').to(300, { puff: 0.6, open: 0 }).to(260, { puff: 0, open: 0.3, mw: 0.5 }, 'o').fx('steam', 'pawR')
      .to(300, { open: 0.25, close: 0.7, mw: 0.8 }).osc(600, 3, { open: 0.15 }, { open: 0 }, 'l').to(400, { lx: 0.6, ly: -0.6, htilt: 7, close: 0, hRy: -6, armR: 24 }, 'io').wait(500)
      .to(260, o({ hap: 1, smile: 1, sqz: 0.7, open: 0.4, htilt: 0 }, X.cheer), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('heart', 'head'); t.wait(500); return t.back(500); },
    kiss(t) { t.to(360, o(hand(1, 7, -14), { armR: 38, puff: 0.3, mw: 0.4, close: 0.6, lx: 0, ly: 0 }), 'io').wait(200).to(200, { armR: 118, hRx: 4, hRy: -6, open: 0.35, mw: 0.6, puff: 0, sqz: 0.8, hap: 1, smile: 1, close: 0 }, 'o').fx('heart', 'head', 2).fx('spark', 'pawR', 3).wait(600); return t.back(500); },
  };
  const SPOON = '<path d="M-0.55 -3L0.55 -3L0.5 9.5L-0.5 9.5Z" fill="#c98a52" stroke="#8a5a2c" stroke-width="0.3"/><ellipse cx="0" cy="12" rx="2" ry="2.8" fill="#d9a066" stroke="#8a5a2c" stroke-width="0.35"/><ellipse cx="-0.5" cy="11.2" rx="0.7" ry="1.1" fill="#f2c890" opacity="0.8"/>';
  const PAN = '<path d="M1 -0.9L7.5 -0.4L7.5 1.2L1 1.4Z" fill="#3b2a24" stroke="#1e1410" stroke-width="0.3"/><ellipse cx="13" cy="1.6" rx="7" ry="3.6" fill="#55556a" stroke="#24242c" stroke-width="0.45"/><ellipse cx="13" cy="1" rx="6" ry="2.8" fill="#34343f"/><path d="M7.6 0.4Q10 -0.8 13 -0.9" stroke="#8a8a9a" stroke-width="0.4" fill="none" opacity="0.7"/>';
  const facing = I => { const s = ((I.lastP && I.lastP.spin) || 0) * Math.PI / 180; return ss((Math.cos(s) + 0.15) / 0.4); };
  const win = (tl, a, b, e) => Math.min(ss((tl - a) / e), ss((b - tl) / e));
  function cookProp(bt, rec, loop) {
    return (I, tt) => { const W = I.W; if (!W || !W.pawR || !isFinite(W.pawR[0])) return ''; const tl = tt % loop, f = facing(I); if (f < 0.02) return ''; const x = W.pawR[0], y = W.pawR[1];
      for (const [n, a, b] of bt) { if (tl < a || tl > b) continue; const k = win(tl, a, b, 220) * f; if (k < 0.02) return '';
        if (n === 'stir' || n === 'taste') return '<g transform="translate(' + r2(x) + ' ' + r2(y) + ') rotate(' + r2(n === 'stir' ? 18 + Math.sin(tl / 110) * 8 : 150) + ') scale(' + r2(k * 1.5) + ')">' + SPOON + '</g>';
        if (n === 'shake' || n === 'flip') { let cake = '<ellipse cx="13" cy="0.9" rx="4.3" ry="2" fill="#f2c26a" stroke="#c98a3a" stroke-width="0.35"/><ellipse cx="11.8" cy="0.4" rx="1.6" ry="0.6" fill="#fff0c0" opacity="0.7"/>'; const r0 = rec.find(q => q >= a && q <= b);
          if (n === 'flip' && r0 != null) { const u = (tl - r0) / 980; if (u > 0 && u < 1) { const th = Math.PI * u, ry = Math.max(0.35, Math.abs(1.5 * Math.cos(th) + 4.3 * Math.sin(th)));
            cake = '<ellipse cx="13" cy="' + r2(0.4 - 22 * Math.sin(Math.PI * u)) + '" rx="4.3" ry="' + r2(ry) + '" fill="' + (u > 0.5 ? '#e0a24a' : '#f2c26a') + '" stroke="#c98a3a" stroke-width="0.35"/>'; } }
          return '<g transform="translate(' + r2(x) + ' ' + r2(y) + ') scale(' + r2(k * 1.45) + ')">' + PAN + cake + '</g>'; }
        return ''; }
      return ''; };
  }
  function cookIn(B) {
    const t = TL(REST); t.to(220, { footL: 2, lift: 1 }, 'io').to(220, { footL: 0, footR: 2 }, 'io').to(180, { footR: 0, lift: 0 }, 'io');
    t.to(260, o(both(11, -2), { armL: 24, armR: 24, hap: 0.8, smile: 1, sqz: 0.5 }), 'io').osc(800, 4, { hLx: 13, hRx: -13 }, { hLx: 9, hRx: -9 }, 'l');
    const v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(420, o(v, { sqz: 0 }), 'io'); return t.out({ next: 'cook', blend: 200 });
  }
  function cookHold(B, X, sig) {
    const t = TL(B), v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(10, v); const bt = [], rec = [], g = X.cgap || [500, 700, 600, 800];
    (X.cOrd || ['stir', 'season', 'shake', 'flip', 'sig', 'stir', 'taste', 'kiss']).forEach((n, i) => { t.wait(g[i % g.length]); const a = t.t; if (n === 'sig') { if (!sig) return; sig(t); } else CB[n](t, X, rec); bt.push([n, a, t.t]); });
    t.wait(900); const st = t.out({ breathe: 0.6, look: false, blend: 420 }, true); st.beats = bt; st.prop = cookProp(bt, rec, st.loop); return st;
  }
  // fridge rummage (once, then the house plays eat): pull the door open, cold blast, lean in and dig, found it, turn round holding the snack up, hip-bump the door shut
  function fridgeMove(X, icon) {
    const t = TL(REST), IC = ICON[icon] || ICON.cookie;
    t.to(320, o(hand(1, -2, -6), { armR: 62, lx: 0.3, ly: -0.2 }), 'io').to(260, { lean: -1, tilt: -3, sq: 0.04, armR: 46, pitch: 0.06 }, 'o').to(240, { lean: 0, tilt: 0, sq: 0, armR: 30 }, 'io');
    t.to(110, { wide: 1, sq: -0.05, open: 0.4, mw: 0.5, armR: 20 }, 'o').fx('gust', 'head').osc(520, 6, { x: 0.6 }, { x: -0.6 }, 'l').to(200, { wide: 0, sqz: 0.5, open: 0, x: 0 });
    t.to(360, o(both(6, -6), { pitch: -0.22, ly: 0.5, sq: 0.05, armL: 58, armR: 58, sqz: 0, mw: 1 }), 'io');
    for (let i = 0; i < 4; i++) { t.to(170, { armL: 74, armR: 44, htilt: 5, x: 0.6 }, 'io').to(170, { armL: 44, armR: 74, htilt: -5, x: -0.6 }, 'io'); if (i === 1) t.fx('crumb', 'head', 3); }
    t.to(220, { armL: 58, armR: 58, htilt: 0, x: 0, lx: -0.6, ly: 0.3 }, 'io').wait(260).to(220, { lx: 0.6 }, 'io').wait(240);
    const found = t.t; t.to(200, { wide: 0.9, open: 0.35, mw: 0.6, armL: 22, armR: 40, pitch: 0, ly: 0, lx: 0, sq: 0 }, 'o').wait(320);
    const turn = t.t; t.to(380, o({ armR: 150, hRx: 1, hRy: -4, armL: 20, hLx: 0, hLy: 0, lift: 2.4, sq: -0.06, hap: 1, smile: 1, open: 0.5, wide: 0.5 }, X.cheer), 'o');
    if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('spark', 'pawR', 4); t.to(200, { lift: 0, sq: 0.04 }, 'i').to(200, { sq: 0 }).wait(500);
    t.to(220, { x: -1.4, tilt: -6, armR: 110, open: 0.3 }, 'o').to(260, { x: 0, tilt: 0 }, 'io').wait(200); const a = found + 150, b = t.t + 200; t.back(320);
    const st = t.out({ next: 'idle', blend: 180 }); st.turn = turn;
    st.prop = (I, tt) => { const W = I.W; if (!W || !W.pawR || !isFinite(W.pawR[0])) return ''; const k = win(tt, a, b, 200) * facing(I); if (k < 0.02) return ''; return '<g transform="translate(' + r2(W.pawR[0]) + ' ' + r2(W.pawR[1] - 3) + ') scale(' + r2(k * 3.2) + ')">' + IC + '</g>'; };
    return st;
  }
  const PLY = {};
  function playBuild(key, X) {
    X = o(WX[key] || {}, X || {}); const P = PROF[key] || {}, nm = n => key ? n + '@' + key : n, S = {}, SB = o(SIT0, P.pose || {});
    const sig = X.p || (P.f || []).find(f => typeof f === 'function'), ksig = X.k || sig;
    const SW = o(SB, SWG0, X.sp || {}), RD = o(SB, RID0, X.rp || {}), CK = o(CK0, X.cp || {});
    [['swing', SW], ['ride', RD]].forEach(([k, B]) => { S[nm(k + 'in')] = playIn(B, P, k); S[nm(k)] = playHold(B, X, k, sig); S[nm(k + 'out')] = playOut(B, P, k); });
    S[nm('cookin')] = cookIn(CK); S[nm('cook')] = cookHold(CK, X, ksig); S[nm('fridge')] = fridgeMove(X, X.sn || 'cookie');
    R.add(S); R.HS = Object.assign(R.HS || {}, S); if (key) PLY[key] = X;
  }
  // ---------- [B] list: wash at the sink, brush teeth, sit + eat at the table, surf, fish, sunbathe, slide, trampoline, dig sand, stack blocks, water plants, roast marshmallows ----------
  // holds loop until the house sends him elsewhere; props are drawn per frame from the beat windows (st.beats) + recorded moments (st.rec)
  if (R.PRE) { R.PRE.sand = { n: 4, sp: 12, vy: -16, g: 85, life: 700, r: [0.5, 0.95], col: ['#e9cf94', '#d8b874', '#f3e2b0'], kind: 'dot' }; }
  ICON.boot = pa('M-2.6-4H1V0.6L4 1.4Q4.6 1.8 4.4 3.2H-2.6Z', '#8a6a4a', '#5a4028') + pa('M-2.6 2.4H4.4', null, '#5a4028', 0.5) + pa('M-1.4-2.4L0.2-2.4M-1.4-1L0.2-1', null, '#d9c8a8', 0.45) + ci(3.6, -2.6, 0.7, 'rgba(160,220,255,0.6)', '#5ab4f0');
  ICON.crab = pa('M-3.4 0.6Q-3.4-2.6 0-2.6Q3.4-2.6 3.4 0.6Q3.4 2.4 0 2.4Q-3.4 2.4-3.4 0.6Z', '#f2604a', '#b8382a') + pa('M-3.2-1Q-5-2.4-4.4-4M3.2-1Q5-2.4 4.4-4', null, '#b8382a', 0.7) + ci(-4.4, -4.2, 0.9, '#f2604a', '#b8382a') + ci(4.4, -4.2, 0.9, '#f2604a', '#b8382a') + ci(-1.1, -1.2, 0.45, '#2a1a10') + ci(1.1, -1.2, 0.45, '#2a1a10');
  const okp = p => p && isFinite(p[0]) && isFinite(p[1]);
  const gnd = I => { const W = I.W || {}, a = W.footL, b = W.footR; if (okp(a) && okp(b)) return [(a[0] + b[0]) / 2, Math.max(a[1], b[1]) + 2.5]; const B = okp(W.belly) ? W.belly : [50, 83]; return [B[0], B[1] + 13]; };
  const rside = (I, gx) => { const s = I.W && I.W.sideR; return okp(s) ? Math.max(gx + 18, s[0] + 6) : gx + 24; }; // just outside his right side, on the ground
  const cnt = (L, a, b) => (L || []).filter(x => x >= a && x <= b).length;
  const lerp = (a, b, u) => a + (b - a) * u;
  const G = (x, y, r, s, body, op) => '<g transform="translate(' + r2(x) + ' ' + r2(y) + ')' + (r ? ' rotate(' + r2(r) + ')' : '') + (s != null && s !== 1 ? ' scale(' + r2(s) + ')' : '') + '"' + (op != null && op < 0.99 ? ' opacity="' + r2(Math.max(0, op)) + '"' : '') + '>' + body + '</g>';
  function bHold(B, ord, BK, X, sig, gaps, ex) {
    const t = TL(B), v = {}; keysOf(B).forEach(p => v[p] = B[p]); t.to(10, v); const bt = [], rec = {};
    ord.forEach((n, i) => { t.wait(gaps[i % gaps.length]); const a = t.t; if (n === 'sig') { if (!sig) return; sig(t); } else if (BK[n]) BK[n](t, X, rec); else BEAT[n](t); bt.push([n, a, t.t]); });
    t.wait(900); const st = t.out(o({ breathe: 0.6, look: false, blend: 460 }, ex || {}), true); st.beats = bt; st.rec = rec; return st;
  }
  // wash at the sink (standing at the basin): scrub paws, rinse, splash face, shake paws dry, smile in the mirror
  const SK0 = o({ sq: 0, lift: 0, pitch: -0.14, ly: 0.7, lx: 0, smile: 0.5, hap: 0.2, armL: 30, armR: 30, footL: 0, footR: 0, lean: 0, tilt: 0 }, both(9, -2));
  const SKB = {
    scrub(t) { const B = t.B; t.to(220, { sqz: 0.3, smile: 0.8 }); for (let i = 0; i < 6; i++) { t.to(140, { hLx: B.hLx + 2.6, hRx: B.hRx - 2.6, hLy: B.hLy - 1.4, hRy: B.hRy + 1.4 }, 'l').to(140, { hLx: B.hLx - 0.6, hRx: B.hRx + 0.6, hLy: B.hLy + 1.4, hRy: B.hRy - 1.4 }, 'l'); if (i % 2 === 0) t.fx('foam', i % 4 ? 'pawL' : 'pawR', 2); } return t.back(300); },
    rinse(t) { const B = t.B; t.to(300, { hLy: B.hLy - 2, hRy: B.hRy - 2, armL: 38, armR: 38, ly: 0.5 }, 'io'); for (let i = 0; i < 3; i++) t.to(200, { hLx: B.hLx + 1.5, hRx: B.hRx + 1.5 }, 'io').fx('drop', 'pawL', 3).to(200, { hLx: B.hLx - 1.5, hRx: B.hRx - 1.5 }, 'io').fx('drop', 'pawR', 3); return t.back(300); },
    splash(t, X) { const B = t.B; t.to(320, o(both(9, -13), { armL: 44, armR: 44, pitch: B.pitch + 0.12, ly: 0.2, close: 0.5 }), 'io').to(110, { close: 1, sqz: 1, open: 0.25, sq: B.sq - 0.05 }, 'o').fx('splash', 'head', 6).osc(560, 4, { htilt: 7, x: 0.4 }, { htilt: -7, x: -0.4 }, 'l').fx('drop', 'head', 4)
      .to(220, o({ sqz: 0, close: 0, wide: 0.7, hap: 1, smile: 1, open: 0.35, sq: B.sq, htilt: 0, x: 0 }, X.wash), 'o').wait(400); return t.back(420); },
    shake(t) { const B = t.B; t.to(200, { hLy: B.hLy + 2, hRy: B.hRy + 2, armL: 22, armR: 22 }, 'io').osc(720, 6, { armL: 36, armR: 12, hLx: B.hLx + 2, hRx: B.hRx }, { armL: 12, armR: 36, hLx: B.hLx, hRx: B.hRx - 2 }, 'l').fx('drop', 'pawL', 3).fx('drop', 'pawR', 3); return t.back(300); },
    mirror(t) { const B = t.B; t.to(420, { pitch: B.pitch + 0.22, ly: -0.5, smile: 1, hap: 0.6, htilt: 4 }, 'io').wait(350).to(150, { winkR: 1, sqz: 0.3 }, 'o').fx('spark', 'head', 3).wait(380).to(200, { winkR: 0, sqz: 0 }).e('blink').wait(200); return t.back(420); },
    dry(t) { const B = t.B; t.to(320, o(both(7, 5), { armL: 12, armR: 12, ly: 0.8, pitch: B.pitch - 0.04 }), 'io').osc(1100, 5, { hLy: 8, hRy: 2 }, { hLy: 2, hRy: 8 }, 'o').to(200, { smile: 1, hap: 0.6 }); return t.back(380); },
  };
  // brush teeth: toothbrush in the right paw at the mouth, foam builds up, gargle, spit, sparkly grin
  const BR0 = o({ sq: 0, lift: 0, pitch: -0.04, ly: 0.2, lx: 0, armR: 36, armL: 16, open: 0.28, mw: 1.35, smile: 0.9, hap: 0.2, footL: 0, footR: 0, lean: 0, tilt: 0, puff: 0 }, hand(1, 8, -13), hand(-1, 5, 3));
  const BRB = {
    brush(t) { const B = t.B; t.to(160, { sqz: 0.25 }); for (let i = 0; i < 9; i++) { t.to(110, { hRx: B.hRx - 2.4, htilt: 2.5 }, 'l').to(110, { hRx: B.hRx + 2.4, htilt: -2.5 }, 'l'); if (i % 3 === 1) t.fx('foam', 'mouth', 1); } return t.back(260); },
    side(t) { const B = t.B; t.to(300, { lx: -0.6, htilt: -7, armR: B.armR + 8, hRy: B.hRy - 1, hRx: B.hRx + 2, mw: 1.1 }, 'io'); for (let i = 0; i < 7; i++) t.to(110, { hRy: B.hRy - 3.4 }, 'l').to(110, { hRy: B.hRy - 0.4 }, 'l'); t.fx('foam', 'mouth', 2); return t.back(300); },
    gargle(t) { const B = t.B; t.to(340, o(hand(1, 6, 1), { armR: 16, pitch: B.pitch + 0.34, ly: -0.8, open: 0.38, mw: 0.7, close: 0.6 }), 'io').osc(1000, 9, { sq: B.sq + 0.025, puff: 0.5 }, { sq: B.sq, puff: 0.2 }, 'l').fx('bubble', 'mouth', 3).to(200, { puff: 0.7, open: 0 }); return t; },
    spit(t) { const B = t.B; t.to(320, { pitch: B.pitch - 0.3, ly: 0.9, puff: 0.9, open: 0, close: 0.3 }, 'io').to(120, { puff: 0, open: 0.5, mw: 0.45, sq: B.sq + 0.04 }, 'o').fx('drop', 'mouth', 5).wait(260).to(200, { open: 0.1, sq: B.sq }); return t.back(380); },
    grin(t, X) { const B = t.B; t.to(300, o({ smile: 1, hap: 0.7, open: 0.3, mw: 1.55, wide: 0.4, pitch: B.pitch + 0.06, ly: 0 }, X.cheer), 'o').fx('spark', 'mouth', 4).wait(900); return t.back(420); },
  };
  function brushProp(st, col) {
    const BRU = (L) => '<rect x="-3" y="-1.2" width="' + r2(L + 3) + '" height="2.4" rx="1.2" fill="' + col + '" stroke="' + shade(col, 0.7) + '" stroke-width="0.45"/><path d="M-1.6-0.5H' + r2(L - 6) + '" stroke="#ffffff" stroke-width="0.6" opacity="0.45" stroke-linecap="round"/><rect x="' + r2(L - 4.6) + '" y="-4.4" width="4.6" height="3.4" rx="0.8" fill="#ffffff" stroke="#b9c6d6" stroke-width="0.45"/><path d="M' + r2(L - 3.6) + ' -4.2V-1.4M' + r2(L - 2.3) + ' -4.2V-1.4M' + r2(L - 1) + ' -4.2V-1.4" stroke="#d6e2ee" stroke-width="0.4"/>';
    return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const f0 = facing(I); if (f0 < 0.02) return ''; const tl = tt % st.loop, p = W.pawR, M = okp(W.mouth) ? W.mouth : [p[0] - 8, p[1]];
      let fm = 0; for (const [n, a, b] of st.beats) { if (tl < a) break; const u = Math.min(1, (Math.min(tl, b) - a) / 900); if (n === 'brush' || n === 'side') fm = Math.max(fm, u); else if (n === 'spit') fm *= 1 - ss((tl - a - 300) / 180); }
      const dx = M[0] - p[0], dy = M[1] - p[1], d = Math.hypot(dx, dy) || 1; let h = G(p[0], p[1], Math.atan2(dy, dx) * 180 / Math.PI, 1, BRU(cl(d + 2, 9, 17)), f0);
      if (fm > 0.03) { let fo = ''; [[0, 0, 1.6], [-1.8, 0.7, 1.2], [1.9, 0.5, 1.3], [-0.6, 1.6, 1], [0.9, -0.9, 0.9]].forEach(([x, y, r], i) => { const rr = 1.8 * r * fm * (0.9 + 0.12 * Math.sin(tt / 90 + i * 2)); if (rr > 0.2) fo += ci(r2(M[0] + 1.8 * x * (0.6 + fm * 0.5)), r2(M[1] + 1.4 + 1.6 * y), r2(rr), '#ffffff', '#cfe6f6'); }); h += '<g opacity="' + r2(0.95 * f0) + '">' + fo + '</g>'; }
      return h; };
  }
  // sit + eat at the table: snack in the paws (between both flippers / in the lap for finned friends), bites shrink it, sips, crumbs, belly rub
  const DNB = {
    bite(t, X, rec) { const B = t.B, p0 = B.pitch || 0, Q = B.sq || 0, md = X._dm;
      if (md === 'lap') t.to(340, { pitch: p0 - 0.24, ly: 0.7, open: 0.3, sq: Q + 0.03 }, 'io');
      else if (md === 'two') t.to(340, o(both(9, -12), { armL: 30, armR: 30, open: 0.35, pitch: p0 + 0.02, ly: 0 }), 'io');
      else t.to(340, o(hand(1, 9, -13), { armR: 34, open: 0.35, pitch: p0 + 0.02, ly: 0 }), 'io');
      t.to(120, { open: 0, puff: 0.55, sq: Q + 0.02 }, 'o'); (rec.bite = rec.bite || []).push(t.t); t.fx('crumb', 'mouth', 3).osc(900, 5, { puff: 0.6, open: 0.12 }, { puff: 0.2, open: 0 }, 'l'); return t.back(320); },
    chew(t) { BEAT.hum(t); return t; },
    sip(t) { const B = t.B; t.to(340, o(hand(-1, 9, -13), { armL: 34, pitch: B.pitch + 0.12, ly: -0.2 }), 'io').osc(900, 3, { puff: 0.3, close: 0.5 }, { puff: 0, close: 0.3 }, 'l').to(240, { close: 0, smile: 1, open: 0.3, mw: 0.6 }, 'o').wait(300); return t.back(380); },
    crumbs(t) { const B = t.B; t.to(300, o(hand(-1, 6, 7), { armL: 10, ly: 0.8, pitch: B.pitch - 0.08 }), 'io').osc(800, 4, { hLx: 9 }, { hLx: 4 }, 'l').fx('crumb', 'belly', 4); return t.back(320); },
    lick(t) { t.to(360, o(hand(-1, 8, -12), { armL: 32, close: 0.5 }), 'io').osc(1100, 5, { tongue: 0.6 }, { tongue: 0.1 }, 's').to(160, { tongue: 0 }); return t.back(380); },
    yum(t, X) { BEAT.belly(t, -1); t.to(240, o({ smile: 1, hap: 1, sqz: 0.6 }, X.cheer), 'o').fx('heart', 'head', 2).wait(400); return t.back(400); },
  };
  function dineProp(st, icon, md) { const IC = ICON[icon] || ICON.cookie;
    return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR) || !okp(W.pawL)) return ''; const f0 = facing(I); if (f0 < 0.02) return ''; const tl = tt % st.loop, k = Math.max(0.35, 1 - cnt(st.rec.bite, 0, tl) * 0.2); let x, y;
      if (md === 'lap') { const B = okp(W.belly) ? W.belly : W.body || [50, 80]; x = B[0]; y = B[1] + 3; } else if (md === 'two' || I.foodMid) { x = (W.pawL[0] + W.pawR[0]) / 2; y = (W.pawL[1] + W.pawR[1]) / 2 - 2; } else { x = W.pawR[0]; y = W.pawR[1] - 2.5; }
      let h = G(x, y - 2, 0, 4 * k, IC, f0); const sb = st.beats.find(b => b[0] === 'sip' && tl >= b[1] && tl <= b[2]); if (sb) { const u = win(tl, sb[1], sb[2], 220); if (u > 0.02) h += G(W.pawL[0], W.pawL[1] - 4, -10, 3.8 * u, ICON.cup, f0); }
      return h; }; }
  // surf (the house draws the board + carries him along the wave): low stance, arms out, wobble, carve, wave bump, hang ten, wipe-out save
  const SF0 = { sq: 0.08, lift: -1.2, pitch: 0.04, armL: 82, armR: 82, hLx: -9, hRx: 9, hLy: -1, hRy: -1, footL: 0, footR: 0, lean: 0, tilt: 0, x: 0, smile: 0.9, hap: 0.4, wide: 0.2 };
  const SFB = {
    wobble(t) { const B = t.B; t.to(160, { wide: 0.6 }).osc(1600, 3, { tilt: 7, armL: 98, armR: 58, x: 0.8 }, { tilt: -7, armL: 58, armR: 98, x: -0.8 }, 's'); return t.back(400); },
    crouch(t) { const B = t.B; t.to(400, { sq: B.sq + 0.1, lift: B.lift - 1.6, armL: 50, armR: 50, hLy: 2, hRy: 2, pitch: B.pitch - 0.08, sqz: 0.3 }, 'io').wait(600).to(300, { sq: B.sq - 0.06, lift: B.lift + 1.5, sqz: 0, open: 0.4 }, 'o'); return t.back(400); },
    carve(t) { t.to(500, { tilt: 9, lean: 1.4, armL: 110, armR: 40, htilt: -6, smile: 1 }, 's').fx('gust', 'head').wait(700).to(600, { tilt: -9, lean: -1.4, armL: 40, armR: 110, htilt: 6 }, 's').fx('splash', 'belly', 4).wait(500); return t.back(500); },
    bump(t) { const B = t.B; t.to(200, { sq: B.sq + 0.08, lift: B.lift - 1 }, 'i').to(260, { sq: B.sq - 0.08, lift: B.lift + 5, armL: 110, armR: 110, open: 0.4, hap: 1 }, 'o').fx('splash', 'belly', 6).to(260, { sq: B.sq + 0.1, lift: B.lift }, 'i').to(200, { sq: B.sq }, 'io'); return t.back(300); },
    hang10(t, X) { t.to(320, o({ armR: 158, hRy: -6, open: 0.5, mw: 0.7, hap: 1, wide: 0.4 }, X.cheer), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('spark', 'head', 3); t.osc(1000, 3, { armR: 140 }, { armR: 165 }, 'io'); return t.back(420); },
    wipe(t) { t.to(150, { wide: 1, open: 0.6, mw: 0.5, tilt: 12, x: 1.5 }, 'o').osc(900, 6, { armL: 150, armR: 30 }, { armL: 30, armR: 150 }, 'l').to(300, { tilt: -4, x: -0.5 }).to(300, { tilt: 0, x: 0, wide: 0.3 }).fx('sweat', 'head').to(300, { sqz: 0.6, hap: 1, smile: 1, open: 0.3 }, 'o'); return t.back(420); },
  };
  // fishing (beach pier): rod in both paws; cast, wait, nibble, reel in, show off the catch
  const FS0 = o({ sq: 0, lift: 0, pitch: 0.02, armL: 24, armR: 30, footL: 0, footR: 0, lean: 0, tilt: 0, smile: 0.6, hap: 0.2 }, hand(1, 6, -4), hand(-1, 9, -2));
  const FB = {
    cast(t, X, rec) { const B = t.B; t.to(160, { sqz: 0.3, ly: -0.2 }); const a = t.t; t.to(420, o(hand(1, 4, -10), { armR: 128, armL: 60, lean: -1, tilt: -4, pitch: B.pitch + 0.1 }), 'io'); const f = t.t;
      t.to(180, { armR: 44, hRy: -5, armL: 32, lean: 1.2, tilt: 3, sqz: 0, open: 0.35, pitch: B.pitch - 0.04 }, 'o'); (rec.cast = rec.cast || []).push([a, f]); t.to(420, { lean: 0, tilt: 0, open: 0 }, 'io').wait(400); return t.back(400); },
    nibble(t, X, rec) { const B = t.B; t.to(200, { wide: 0.8, pitch: B.pitch - 0.1, ly: 0.7, lean: 0.6, earL: -8, earR: -8 }, 'o'); (rec.nib = rec.nib || []).push(t.t); t.osc(700, 2, { hRy: B.hRy + 1.5 }, { hRy: B.hRy }, 'l').wait(400); return t.back(380); },
    reel(t, X, rec) { const B = t.B, a = t.t; t.to(150, { armR: 66, hRy: B.hRy - 4, lean: -1, tilt: -3, wide: 1, open: 0.5, mw: 0.5 }, 'o');
      for (let i = 0; i < 6; i++) t.to(140, { hLx: B.hLx + 2, hLy: B.hLy - 2, tilt: -4 }, 'l').to(140, { hLx: B.hLx, hLy: B.hLy - 4 }, 'l').to(140, { hLx: B.hLx - 2, hLy: B.hLy - 2, tilt: -2 }, 'l').to(140, { hLx: B.hLx, hLy: B.hLy }, 'l');
      t.fx('sweat', 'head'); (rec.reel = rec.reel || []).push([a, t.t]); return t; },
    catch(t, X, rec) { const a = t.t; t.to(240, o({ armR: 150, hRy: -10, hRx: 0, armL: 124, hLy: -8, hLx: 0, lift: 2.4, sq: -0.06, lean: 0, tilt: 0, hap: 1, smile: 1, open: 0.5, wide: 0.5 }, X.cheer), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('spark', 'head', 4);
      t.to(200, { lift: 0, sq: 0.04 }, 'i').to(200, { sq: 0 }).wait(600).to(400, { htilt: 8, lx: 0.6, ly: -0.6, armR: 128, open: 0.2 }, 'io').wait(800); (rec.catch = rec.catch || []).push([a, t.t]); return t.back(450); },
  };
  function fishProp(st, icon) { const IC = ICON[icon] || ICON.fish, R0 = st.rec;
    return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const tl = tt % st.loop, p = W.pawR, [gx, gy] = gnd(I), Wp = [rside(I, gx) + 22, gy - 2 + Math.sin(tt / 420) * 0.6];
      let ang = -40, bend = 0, mode = 'tip', E = null, fly = 0, cat = 0;
      const C = (R0.cast || [])[0], Rl = (R0.reel || [])[0], Ct = (R0.catch || [])[0];
      if (C && tl >= C[0]) { if (tl < C[1]) ang = lerp(-40, -122, ss((tl - C[0]) / (C[1] - C[0]))); else { ang = lerp(-122, -30, ss((tl - C[1]) / 180)); fly = cl((tl - C[1]) / 650, 0, 1); mode = fly < 1 ? 'fly' : 'water'; } }
      if (Rl && tl >= Rl[0]) { const u = cl((tl - Rl[0]) / (Rl[1] - Rl[0]), 0, 1); ang = -52 + Math.sin(tl / 90) * 3; bend = 4 + Math.sin(tl / 70); mode = 'reel'; fly = u; }
      if (Rl && tl > Rl[1]) { ang = -60; bend = 3; mode = 'tip'; }
      if (Ct && tl >= Ct[0]) { ang = lerp(-60, -84, ss((tl - Ct[0]) / 300)); bend = 1.5; mode = tl < Ct[1] ? 'catch' : 'tip'; cat = win(tl, Ct[0] + 120, Ct[1], 260); if (tl > Ct[1]) ang = lerp(-84, -40, ss((tl - Ct[1]) / 400)); }
      const an = ang * Math.PI / 180, Ln = 42, tip = [p[0] + Math.cos(an) * Ln, p[1] + Math.sin(an) * Ln], nx = -Math.sin(an), ny = Math.cos(an), cp = [(p[0] + tip[0]) / 2 + nx * bend, (p[1] + tip[1]) / 2 + ny * bend];
      const hang = [tip[0], tip[1] + 10];
      if (mode === 'fly') E = [lerp(tip[0], Wp[0], fly), lerp(tip[1], Wp[1], fly) - Math.sin(Math.PI * fly) * 22];
      else if (mode === 'water') { E = [Wp[0], Wp[1]]; const nb = (R0.nib || []).find(n => tl >= n && tl < n + 700); if (nb != null) E[1] += 3 * Math.abs(Math.sin((tl - nb) / 115)); }
      else if (mode === 'reel') E = [lerp(Wp[0], hang[0], fly), lerp(Wp[1], hang[1], fly)];
      else E = hang;
      let h = '<path d="M' + r2(p[0]) + ' ' + r2(p[1]) + 'Q' + r2(cp[0]) + ' ' + r2(cp[1]) + ' ' + r2(tip[0]) + ' ' + r2(tip[1]) + '" stroke="#8a5a2c" stroke-width="1.7" fill="none" stroke-linecap="round"/><path d="M' + r2(p[0] + Math.cos(an) * 30) + ' ' + r2(p[1] + Math.sin(an) * 30) + 'L' + r2(tip[0]) + ' ' + r2(tip[1]) + '" stroke="#b07a42" stroke-width="1" fill="none" stroke-linecap="round"/>';
      h += ci(r2(p[0] + Math.cos(an) * 4 + nx * 2.6), r2(p[1] + Math.sin(an) * 4 + ny * 2.6), 2.2, '#c9c9d6', '#6a6a80');
      const sag = mode === 'water' ? 8 : 2; h += '<path d="M' + r2(tip[0]) + ' ' + r2(tip[1]) + 'Q' + r2((tip[0] + E[0]) / 2) + ' ' + r2((tip[1] + E[1]) / 2 + sag) + ' ' + r2(E[0]) + ' ' + r2(E[1]) + '" stroke="#5a6a7a" stroke-width="0.45" fill="none" opacity="0.85"/>';
      if (mode === 'water') h += '<ellipse cx="' + r2(E[0]) + '" cy="' + r2(Wp[1] + 2) + '" rx="' + r2(5 + Math.sin(tt / 300) * 1.5) + '" ry="1.5" fill="none" stroke="#8fd3ff" stroke-width="0.6" opacity="0.9"/>';
      if (cat > 0.02) h += G(E[0], E[1] + 5, Math.sin(tt / 110) * 18 + 70, 4 * cat, IC);
      if (mode !== 'catch' || cat < 0.5) h += '<path d="M' + r2(E[0] - 2.1) + ' ' + r2(E[1]) + 'A2.1 2.1 0 0 1 ' + r2(E[0] + 2.1) + ' ' + r2(E[1]) + 'Z" fill="#e8483c" stroke="#b8302a" stroke-width="0.35"/><path d="M' + r2(E[0] - 2.1) + ' ' + r2(E[1]) + 'A2.1 2.1 0 0 0 ' + r2(E[0] + 2.1) + ' ' + r2(E[1]) + 'Z" fill="#ffffff" stroke="#c9c9d6" stroke-width="0.35"/>';
      return h; }; }
  // sunbathe (towel / lounger): lies back with shades on; sigh, wiggle toes, sip a drink, sunscreen, peek over the shades, doze
  // channels read by the prop: shd = shades on (0-1), shu = shades slid down the nose (0-1)
  const SUNB = {
    sigh(t) { BEAT.sigh(t); return t; }, doze(t) { BEAT.doze(t); return t; },
    toes(t) { const B = t.B; t.osc(1600, 4, { footL: B.footL + 1.6, footR: B.footR - 0.4 }, { footL: B.footL - 0.4, footR: B.footR + 1.6 }, 's').to(200, { smile: 1 }); return t.back(360); },
    sip(t) { const B = t.B; t.to(400, o(hand(1, 9, -12), { armR: 40, pitch: B.pitch - 0.06 }), 'io').osc(900, 3, { puff: 0.35 }, { puff: 0 }, 'l').to(240, { smile: 1, open: 0.3, mw: 0.6 }, 'o').wait(300); return t.back(420); },
    lotion(t) { t.to(360, o(hand(-1, 6, 6), { armL: 10 }), 'io').osc(1400, 4, { hLx: 9, hLy: 4 }, { hLx: 4, hLy: 8 }, 's').fx('spark', 'belly', 2); return t.back(380); },
    peek(t) { const B = t.B; t.to(300, { shu: 1, wide: 0.7, lx: 0.6, ly: -0.3, pitch: B.pitch - 0.1, htilt: B.htilt - 3, close: 0 }, 'io').wait(900).to(200, { sqz: 0.5, smile: 1, hap: 0.6 }, 'o').wait(300).to(300, { shu: 0, wide: 0, lx: 0, ly: 0, sqz: 0, hap: B.hap }, 'io'); return t.back(300); },
  };
  const SHADES = '<path d="M-9.4-1.2L-12.8-2.6M9.4-1.2L12.8-2.6" stroke="#2a1a30" stroke-width="0.7" stroke-linecap="round"/><path d="M-1.4-0.6Q0-1.8 1.4-0.6" stroke="#2a1a30" stroke-width="0.8" fill="none"/>' +
    [-5, 5].map(x => '<ellipse cx="' + x + '" cy="0" rx="4.1" ry="3.2" fill="#2a2440" stroke="#e8483c" stroke-width="0.6"/><path d="M' + (x - 2.4) + ' -1.2Q' + (x - 1) + ' -2.4 ' + (x + 1) + ' -2" stroke="#ffffff" stroke-width="0.7" fill="none" opacity="0.7" stroke-linecap="round"/>').join('');
  function sunProp(st) {
    return (I, tt) => { const P = I.lastP || {}, W = I.W || {}, k = cl(P.shd || 0, 0, 1); let h = ''; const f0 = facing(I);
      if (k > 0.02 && f0 > 0.05) { let a = W.eyeL, b = W.eyeR; if (okp(a) || okp(b)) { if (!okp(a)) a = b; if (!okp(b)) b = a;
        const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2, d = Math.max(Math.hypot(b[0] - a[0], b[1] - a[1]), 5), s = d / 10, dn = cl(P.shu || 0, 0, 1) * 2.8;
        h += G(mx, my + dn * s, Math.atan2(b[1] - a[1], b[0] - a[0]) * 180 / Math.PI, s * (0.6 + 0.4 * k), SHADES, k * Math.min(1, f0 * 1.3)); } }
      if (st && okp(W.pawR)) { const tl = tt % st.loop, sb = st.beats.find(q => q[0] === 'sip' && tl >= q[1] && tl <= q[2]); if (sb) { const u = win(tl, sb[1], sb[2], 220); if (u > 0.02) h += G(W.pawR[0], W.pawR[1] - 4, 0, 3.8 * u, ICON.cup, f0); } }
      return h; }; }
  function sunIn(SB, SN, P) { const t = TL(REST); enterMove(t, SB, P.dn || 'hop'); const v = {}; keysOf(SB).forEach(p => v[p] = SB[p]); t.to(140, v, 'io');
    t.to(320, o(hand(1, 9, -14), { armR: 40, shd: 0, smile: 0.8 }), 'io').to(220, { shd: 1, sqz: 0.5, smile: 1 }, 'o').wait(200).to(240, { sqz: 0 }).to(900, o(SN, { shd: 1 }), 's').to(260, { sq: SN.sq + 0.05 }, 'o');
    const v2 = {}; keysOf(SN).forEach(p => v2[p] = SN[p]); t.to(300, v2, 'io'); return t.out({ next: 'sun', blend: 220 }); }
  function sunOut(SN, SB, P) { const t = TL(SN); t.to(550, o(SB, { shd: 1, shu: 0, close: 0.2 }), 'io').to(300, o(hand(1, 9, -16), { armR: 44 }), 'io').to(200, { shd: 0, wide: 0.4 }, 'o');
    t.to(600, { armL: 160, armR: 160, hLy: -5, hRy: -5, hLx: 0, hRx: 0, sq: (SB.sq || 0) - 0.08, close: 0.9, open: 0.6, pitch: (SB.pitch || 0) + 0.3, wide: 0 }, 'io').to(420, { armL: SB.armL || 0, armR: SB.armR || 0, hLy: SB.hLy, hRy: SB.hRy, hLx: SB.hLx, hRx: SB.hRx, sq: SB.sq || 0, close: 0, open: 0, pitch: SB.pitch || 0, smile: 1 }, 'io');
    const hop = t.t; exitMove(t, SB, P.up || 'hop'); t.to(160, { sq: 0, lift: 0 }, 'io'); const st = t.out({ next: 'idle', blend: 200 }); st.hop = hop; return st; }
  // slide (once): climb the ladder, sit at the top, peek down, arms up, wheee down, land, giggle
  function slideMove(P, X) { const t = TL(REST);
    for (let i = 0; i < 4; i++) { const s = i % 2 ? -1 : 1; t.to(230, { footL: s > 0 ? 3 : 0, footR: s > 0 ? 0 : 3, lift: 1.5 + i * 3.4, tilt: s * 2, armL: s > 0 ? 64 : 22, armR: s > 0 ? 22 : 64, pitch: 0.12, ly: -0.4 }, 'io'); }
    t.to(260, o(both(6, 3), { sit: 1, sq: 0.1, lift: 13.5, footL: 2, footR: 2, tilt: 0, armL: 0, armR: 0, pitch: 0, ly: 0 }), 'io');
    t.to(320, { pitch: -0.2, ly: 0.9, wide: 0.7, open: 0.25, mw: 0.5 }, 'io').wait(420).e('blink');
    t.to(260, o({ armL: 160, armR: 160, hLx: -6, hRx: 6, hLy: -6, hRy: -6, hap: 1, smile: 1, open: 0.6, mw: 0.8, pitch: 0.12, ly: -0.3, wide: 0.5 }, X.cheer), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('spark', 'head', 3);
    const w0 = t.t; t.to(720, { lift: 0.6, x: 5, lean: -1.6, pitch: 0.28, earL: 16, earR: -16, footL: 3.4, footR: 3.4, sq: 0.04 }, 'i');
    t.to(140, { lift: 0, sq: 0.16, x: 6, lean: 0 }, 'o').fx('dust', 'belly', 4);
    t.to(220, { sit: 0, sq: -0.06, lift: 3.2, armL: 110, armR: 110, earL: 0, earR: 0, footL: 0, footR: 0, pitch: 0 }, 'o').to(200, { lift: 0, sq: 0.06 }, 'i');
    t.to(260, { sqz: 0.8, hap: 1, smile: 1, open: 0.4, armL: 30, armR: 30, hLx: 0, hRx: 0, hLy: 0, hRy: 0, wide: 0, mw: 1 }, 'o').osc(700, 4, { sq: 0.03 }, { sq: 0 }, 'o');
    t.back(500); const st = t.out({ next: 'idle', blend: 180 }); st.whee = w0; return st; }
  // trampoline: small hops between tricks (big jumps, star jump with his own trick, tuck, seat drop, spin)
  const TB0 = { sq: 0, lift: 0, pitch: 0, armL: 30, armR: 30, hLx: 0, hRx: 0, hLy: 0, hRy: 0, footL: 0, footR: 0, smile: 0.9, hap: 0.5, open: 0.1 };
  const TBB = {
    hop(t) { const B = t.B; for (let i = 0; i < 2; i++) t.to(110, { sq: B.sq + 0.1, lift: B.lift - 1 }, 'i').to(200, { sq: B.sq - 0.05, lift: B.lift + 5, armL: 50, armR: 50 }, 'o').to(200, { sq: B.sq, lift: B.lift, armL: B.armL, armR: B.armR }, 'i'); return t; },
    jumps(t) { const B = t.B; t.to(160, { hap: 1, open: 0.4 }); for (let i = 0; i < 3; i++) t.to(120, { sq: B.sq + 0.16, lift: B.lift - 1.6, armL: 12, armR: 12 }, 'i').to(300, { sq: B.sq - 0.1, lift: B.lift + 11 + i * 2, armL: 112, armR: 112, footL: 1.4, footR: 1.4 }, 'o').to(300, { sq: B.sq + 0.02, lift: B.lift, armL: 40, armR: 40, footL: 0, footR: 0 }, 'i'); return t.back(200); },
    star(t, X) { const B = t.B; t.to(140, { sq: B.sq + 0.18, lift: B.lift - 2 }, 'i').to(340, { sq: B.sq - 0.12, lift: B.lift + 16 }, 'o').to(180, o({ lift: B.lift + 18, armL: 160, armR: 160, hLx: -7, hRx: 7, hLy: -4, hRy: -4, footL: 3, footR: 3, open: 0.6, wide: 0.6, hap: 1, smile: 1 }, X.tk || X.cheer), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('spark', 'body', 4);
      t.to(200, { lift: B.lift + 15, armL: 60, armR: 60, hLx: 0, hRx: 0, hLy: 0, hRy: 0, footL: 0, footR: 0, wide: 0 }, 'io').to(280, { lift: B.lift, sq: B.sq + 0.14 }, 'i').to(200, { sq: B.sq }, 'o'); return t.back(250); },
    tuck(t) { const B = t.B; t.to(140, { sq: B.sq + 0.18, lift: B.lift - 2 }, 'i').to(320, { sq: B.sq - 0.1, lift: B.lift + 15, armL: 120, armR: 120 }, 'o').to(180, o(both(7, 6), { lift: B.lift + 17, sq: B.sq + 0.12, armL: -4, armR: -4, footL: 4, footR: 4, close: 1, sqz: 0.8 }), 'io')
      .to(180, { lift: B.lift + 14, sq: B.sq - 0.06, hLx: 0, hRx: 0, hLy: 0, hRy: 0, armL: 70, armR: 70, footL: 0, footR: 0, close: 0, sqz: 0, wide: 0.6, open: 0.45 }, 'io').to(280, { lift: B.lift, sq: B.sq + 0.14 }, 'i').to(200, { sq: B.sq, wide: 0 }, 'o'); return t.back(250); },
    seat(t) { const B = t.B; t.to(130, { sq: B.sq + 0.14, lift: B.lift - 1.4 }, 'i').to(280, { sq: B.sq - 0.08, lift: B.lift + 10, armL: 90, armR: 90 }, 'o').to(260, o(both(4, 2), { sit: 1, sq: B.sq + 0.06, lift: B.lift + 4, footL: 2.4, footR: 2.4, armL: 20, armR: 20, open: 0.4 }), 'io')
      .to(160, { lift: B.lift - 1.5, sq: B.sq + 0.2 }, 'i').to(300, { sit: 0, lift: B.lift + 9, sq: B.sq - 0.08, footL: 0, footR: 0, armL: 110, armR: 110, hLx: 0, hRx: 0, hLy: 0, hRy: 0, hap: 1, sqz: 0.6 }, 'o').to(280, { lift: B.lift, sq: B.sq + 0.1 }, 'i').to(200, { sq: B.sq, sqz: 0 }, 'o'); return t.back(250); },
    spin(t) { const B = t.B; t.to(140, { sq: B.sq + 0.16, lift: B.lift - 1.8 }, 'i').to(380, { sq: B.sq - 0.12, lift: B.lift + 16, spin: 180, armL: 150, armR: 150, hap: 1, open: 0.5 }, 'o').to(380, { spin: 360, lift: B.lift, sq: B.sq + 0.12, armL: 60, armR: 60 }, 'i').to(10, { spin: 0 }).to(200, { sq: B.sq }, 'o'); return t.back(250); },
  };
  function bounceIn(TB, P) { const t = TL(REST); enterMove(t, TB, P.dn === 'float' ? 'float' : 'hop'); const v = {}; keysOf(TB).forEach(p => v[p] = TB[p]); t.to(160, v, 'io'); for (let i = 0; i < 2; i++) t.to(110, { sq: 0.1, lift: -1 }, 'i').to(200, { sq: -0.05, lift: 5, armL: 50, armR: 50 }, 'o').to(200, { sq: 0, lift: 0, armL: TB.armL, armR: TB.armR }, 'i'); return t.out({ next: 'bounce', blend: 200 }); }
  function bounceOut(TB, P) { const t = TL(TB); t.to(130, { sq: 0.15, lift: -1.4 }, 'i').to(300, { sq: -0.1, lift: 12, armL: 110, armR: 110 }, 'o').to(300, { sq: 0.1, lift: 0, armL: 40, armR: 40 }, 'i').to(200, { sq: 0 }, 'o');
    const hop = t.t; exitMove(t, TB, P.up === 'float' ? 'float' : 'hop'); t.to(160, { sq: 0, lift: 0 }, 'io').to(200, { hap: 0.8, smile: 1 }, 'o'); const st = t.out({ next: 'idle', blend: 200 }); st.hop = hop; return st; }
  // dig in the sand (sandbox / beach): sits on the ground, castle in front: scoop, pat the pile, bucket towers x2, flag, admire, it slumps, giggle
  const DGB = {
    scoop(t) { const B = t.B; for (let i = 0; i < 3; i++) t.to(240, o(hand(1, -5, 9), { armR: 14, lean: 0.4, tilt: 2, lx: 0.6, ly: 0.8 }), 'i').to(260, o(hand(1, 6, 2), { armR: 26, lean: 0, tilt: 0, lx: 0, ly: 0.7 }), 'o').fx('sand', 'pawR', 4).wait(100); return t.back(300); },
    pile(t) { const B = t.B; t.to(300, o(both(8, 7), { armL: 18, armR: 18, ly: 0.8 }), 'io').osc(1200, 4, { hLy: 10, hRy: 10, sq: B.sq + 0.02 }, { hLy: 6, hRy: 6, sq: B.sq }, 'o').fx('sand', 'pawL', 3); return t.back(320); },
    bucket(t, X, rec) { const B = t.B; t.to(300, o(hand(1, -9, 7), { armR: 20, lx: 0.7, ly: 0.7, tilt: 2 }), 'io'); const g = t.t; t.to(360, o(hand(1, 4, -4), { armR: 44, lx: 0, ly: 0.4, tilt: 0 }), 'io'); t.to(260, o(hand(1, 6, 5), { armR: 22, sq: B.sq + 0.04 }), 'i'); const s = t.t; t.fx('sand', 'pawR', 5).wait(300);
      t.to(320, o(hand(1, 4, -6), { armR: 48, wide: 0.6, open: 0.3, sq: B.sq }), 'o'); const l = t.t; t.to(200, { sqz: 0.6, hap: 1, smile: 1, open: 0.3, wide: 0 }, 'o').to(380, o(hand(1, -9, 7), { armR: 20, lx: 0.7 }), 'io'); const e = t.t; (rec.bk = rec.bk || []).push([g, s, l, e]); return t.back(380); },
    pat(t) { t.to(280, o(both(8, 2), { armL: 22, armR: 22, ly: 0.6 }), 'io').osc(900, 5, { hLy: 3, hRy: 3 }, { hLy: 0, hRy: 0 }, 'o').fx('sand', 'pawR', 2); return t.back(300); },
    flag(t, X, rec) { t.to(340, o(hand(1, 5, -6), { armR: 40, ly: 0.3 }), 'io').to(200, { hRy: -2 }, 'i'); (rec.flag = rec.flag || []).push(t.t); t.to(260, o({ hRy: -7, armR: 60, hap: 1, smile: 1, open: 0.4 }, X.cheer), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('spark', 'head', 3); t.wait(500); return t.back(400); },
    admire(t) { const B = t.B; t.to(400, o(both(10, -6), { armL: 28, armR: 28, pitch: B.pitch + 0.14, ly: 0.2, smile: 1, hap: 0.6, close: 0.4, htilt: 6 }), 'io').fx('heart', 'head').wait(900); return t.back(420); },
    crumble(t, X, rec) { const B = t.B; (rec.cr = rec.cr || []).push(t.t); t.to(200, { wide: 1, open: 0.55, mw: 0.5, pitch: B.pitch - 0.08, lean: -0.6, frown: 0.4 }, 'o').wait(700).to(240, { frown: 0, sqz: 0.8, hap: 1, smile: 1, open: 0.4, wide: 0, lean: 0 }, 'o').osc(900, 4, { sq: B.sq + 0.03 }, { sq: B.sq }, 'o'); return t.back(420); },
  };
  const SAND = '#e6c682', SANDK = '#b8954e', SANDL = '#f5e0b0';
  const PAIL = '<path d="M-3-2.6H3L2.3 3H-2.3Z" fill="#5ab4f0" stroke="#2e86c8" stroke-width="0.4"/><path d="M-3-2.6H3V-1.6H-3Z" fill="#ffd24a" stroke="#d9a22a" stroke-width="0.3"/><path d="M-2.6-2.6Q0-6 2.6-2.6" stroke="#2e86c8" stroke-width="0.4" fill="none"/>';
  const SPADE = '<path d="M-0.45 0H0.45V7H-0.45Z" fill="#ffd24a" stroke="#d9a22a" stroke-width="0.25"/><path d="M-2 7H2V9.6Q0 12-2 9.6Z" fill="#e8483c" stroke="#b8302a" stroke-width="0.35"/>';
  function digProp(st) { const R0 = st.rec, K = 2;
    return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const tl = tt % st.loop, [gx, gy] = gnd(I), cx = gx + 2, cy = gy + 5, f0 = facing(I);
      let pile = 0, tw = 0, fl = 0, sl = 0; for (const [n, a, b] of st.beats) { if (tl < a) break; const u = cl((tl - a) / Math.max(1, b - a), 0, 1);
        if (n === 'scoop') pile = Math.max(pile, 0.25 + 0.3 * u); else if (n === 'pile') pile = Math.max(pile, 0.55 + 0.45 * u); else if (n === 'crumble') sl = ss((tl - a - 120) / 700); }
      (R0.bk || []).forEach(q => { if (tl >= q[2]) tw++; }); (R0.flag || []).forEach(q => { if (tl >= q) fl = 1; });
      const pk = pile * (1 + sl * 0.25), ph = 3.6 * pile * (1 - sl * 0.4); let c = '';
      if (pile > 0.02) c += '<ellipse cx="0" cy="0" rx="' + r2(10 * pk) + '" ry="' + r2(Math.max(0.6, ph)) + '" fill="' + SAND + '" stroke="' + SANDK + '" stroke-width="0.35"/><ellipse cx="' + r2(-2.4 * pk) + '" cy="' + r2(-ph * 0.45) + '" rx="' + r2(4 * pk) + '" ry="' + r2(Math.max(0.3, ph * 0.35)) + '" fill="' + SANDL + '" opacity="0.7"/>' + [[-6, 0.4], [4, -0.6], [7, 0.8]].map(([x, y]) => ci(r2(x * pk), r2(y * ph * 0.4), r2(0.35 * pk), SANDK)).join('');
      const tower = (x, hh) => { const y0 = -ph * 0.6, y1 = y0 - hh; if (hh < 0.4) return ''; return '<path d="M' + r2(x - 2.8) + ' ' + r2(y0) + 'L' + r2(x - 2.4) + ' ' + r2(y1) + 'H' + r2(x - 1.4) + 'V' + r2(y1 - 1.1) + 'H' + r2(x - 0.5) + 'V' + r2(y1) + 'H' + r2(x + 0.5) + 'V' + r2(y1 - 1.1) + 'H' + r2(x + 1.4) + 'V' + r2(y1) + 'H' + r2(x + 2.4) + 'L' + r2(x + 2.8) + ' ' + r2(y0) + 'Z" fill="' + SAND + '" stroke="' + SANDK + '" stroke-width="0.35"/><path d="M' + r2(x + 1.2) + ' ' + r2(y0 - 0.2) + 'L' + r2(x + 1.2) + ' ' + r2(y1 + 0.4) + 'H' + r2(x + 2.3) + 'L' + r2(x + 2.7) + ' ' + r2(y0 - 0.2) + 'Z" fill="' + SANDK + '" opacity="0.35"/><path d="M' + r2(x - 0.7) + ' ' + r2(y0 - hh * 0.35) + 'h1.4v-1.6a0.7 0.7 0 0 0-1.4 0Z" fill="' + SANDK + '" opacity="0.6"/>'; };
      const th = 6.5 * (1 - sl); if (tw > 0) c += tower(-3.2, th); if (tw > 1) c += tower(3.4, th * 0.82);
      if (fl && sl < 0.6) { const fy0 = -ph * 0.6 - th - 1, wv = Math.sin(tt / 160) * 0.8; c += '<g opacity="' + r2(1 - sl / 0.6) + '"><path d="M-3.2 ' + r2(fy0) + 'V' + r2(fy0 - 6) + '" stroke="#8a5a2c" stroke-width="0.4"/><path d="M-3.2 ' + r2(fy0 - 6) + 'Q-1.2 ' + r2(fy0 - 5.6 + wv) + ' 0.6 ' + r2(fy0 - 4.9 + wv) + 'L-3.2 ' + r2(fy0 - 3.8) + 'Z" fill="#e8483c"/></g>'; }
      let h = G(cx, cy, 0, K, c);
      // bucket: on the ground at his right, carried + flipped over the castle, lifted off to show a tower
      const B0 = [rside(I, gx) + 6, gy + 2], cur = (R0.bk || []).find(q => tl >= q[0] && tl < q[3]), PK = 2.3;
      if (cur) { const [g, s, l, e] = cur; if (tl < s) { const u = ss((tl - g) / (s - g)); h += G(W.pawR[0], W.pawR[1] + 4, 180 * u, PK, PAIL); } else if (tl < l) h += G(cx + K * (tw ? 3.4 : -3.2), cy - K * (ph * 0.6 + 3.4), 180, PK, PAIL); else { const u = ss((tl - l) / (e - l)); h += G(W.pawR[0], W.pawR[1] + 4, 180 * (1 - u), PK, PAIL); } }
      else h += G(B0[0], B0[1] - 6, 0, PK, PAIL);
      if (!cur) h += G(W.pawR[0], W.pawR[1], (st.beats.some(b => b[0] === 'scoop' && tl >= b[1] && tl <= b[2]) ? 20 + Math.sin(tl / 130) * 26 : 18), 2, SPADE, Math.max(0.3, f0)); else h += G(gx - 26, gy + 2, 80, 2, SPADE);
      return h; }; }
  // stack blocks (sits on the floor, tower at his right): pick a block from the pile, place it on top x3, wobble, steady, x2 more, topple, giggle, tidy back
  const BLC = ['#ff6f6f', '#ffcc3a', '#5ab4f0', '#7cc35a', '#b98ae8'], BLL = 'ABCDE';
  const BLK = i => '<rect x="-2.8" y="-2.8" width="5.6" height="5.6" rx="0.9" fill="' + BLC[i] + '" stroke="' + shade(BLC[i], 0.7) + '" stroke-width="0.4"/><path d="M-2.2-2.2H2.2" stroke="#ffffff" stroke-width="0.6" opacity="0.5" stroke-linecap="round"/><text x="0" y="1.6" text-anchor="middle" font-family="Fredoka,sans-serif" font-weight="700" font-size="4.3" fill="#ffffff" stroke="' + shade(BLC[i], 0.6) + '" stroke-width="0.45" paint-order="stroke">' + BLL[i] + '</text>';
  const BLB = {
    stack(t, X, rec) { const n = (rec.n = (rec.n || 0) + 1) - 1, top = 4 + n * 8.1;
      t.to(320, o(hand(1, -6, 8), { armR: 22, lean: 0.5, lx: 0.6, ly: 0.8 }), 'io'); (rec.pick = rec.pick || []).push(t.t);
      t.to(420, o(hand(1, -14, -top), { armR: cl(34 + n * 19, 34, 118), lean: 0, ly: -0.2 - n * 0.12 }), 'io').osc(300, 2, { hRy: -top - 0.6 }, { hRy: -top }, 'l'); (rec.place = rec.place || []).push(t.t); t.to(200, { sqz: 0.4, smile: 1 }, 'o'); return t.back(380); },
    wobble(t, X, rec) { (rec.wob = rec.wob || []).push(t.t); t.to(200, o(both(10, -9), { armL: 34, armR: 34, wide: 1, open: 0.45, mw: 0.5, lean: -0.8 }), 'o').osc(900, 3, { tilt: 2 }, { tilt: -2 }, 's').fx('sweat', 'head').to(400, { wide: 0.3, open: 0.1, tilt: 0 }).to(200, { sqz: 0.5, smile: 1, hap: 0.6 }, 'o'); return t.back(380); },
    topple(t, X, rec) { const B = t.B; (rec.top = rec.top || []).push(t.t); t.wait(250).to(220, o(both(10, -13), { armL: 40, armR: 40, wide: 1, open: 0.6, mw: 0.5, pitch: B.pitch + 0.1 }), 'o').wait(700); return t.back(400); },
    giggle(t) { BEAT.giggle(t, -1); return t; },
    tidy(t, X, rec) { const B = t.B; (rec.tidy = rec.tidy || []).push(t.t); t.to(300, o(hand(1, -12, 8), { armR: 22, lean: 0.6, lx: 0.8, ly: 0.7 }), 'io').osc(1200, 3, { hRx: B.hRx + 4 }, { hRx: B.hRx - 1 }, 's'); rec.tidyE = t.t; t.to(200, { smile: 1, hap: 0.5 }); return t.back(380); },
  };
  function blocksProp(st) { const R0 = st.rec, BS = 1.45, Z = 5.6 * BS;
    return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const tl = tt % st.loop, [gx, gy] = gnd(I), tx = rside(I, gx) + 10, ty = gy - Z / 2;
      const PL = [[tx - 19, gy - 2], [tx - 11, gy - 2], [tx - 23, gy + 6], [tx - 15, gy + 6], [tx - 7, gy + 6]], SC = [[tx - 2, gy + 3, 20], [tx + 8, gy + 1, -35], [tx - 10, gy + 8, 60], [tx + 15, gy + 6, 15], [tx - 20, gy + 9, -50]];
      const pk = R0.pick || [], pl = R0.place || [], T0 = (R0.top || [])[0], Td = (R0.tidy || [])[0], TdE = R0.tidyE || 0, Wb = (R0.wob || [])[0];
      let rot = 0; if (Wb != null && tl > Wb && tl < Wb + 1500) rot = 7 * Math.sin((tl - Wb) / 110) * (1 - (tl - Wb) / 1500);
      if (T0 != null && tl > T0 && tl < T0 + 260) rot = 14 * ss((tl - T0) / 260);
      const cs = Math.cos(rot * Math.PI / 180), sn = Math.sin(rot * Math.PI / 180); let h = '';
      for (let i = 0; i < 5; i++) { let x, y, r = 0; const slot = [tx, ty - i * Z], tow = () => { const dy = slot[1] - gy; return [tx - dy * sn, gy + dy * cs, rot]; };
        if (T0 != null && tl >= T0 + 260 && (Td == null || tl < Td)) { const u = ss((tl - T0 - 260) / 520), q = tow(); x = lerp(q[0], SC[i][0], u); y = lerp(q[1], SC[i][1], u) - Math.sin(Math.PI * u) * (6 + i * 2.5); r = lerp(q[2], SC[i][2], u); }
        else if (Td != null && tl >= Td) { const u = ss((tl - Td) / Math.max(1, TdE - Td)); x = lerp(SC[i][0], PL[i][0], u); y = lerp(SC[i][1], PL[i][1], u) - Math.sin(Math.PI * u) * 3; r = lerp(SC[i][2], 0, u); }
        else if (pl[i] != null && tl >= pl[i]) { [x, y, r] = tow(); }
        else if (pk[i] != null && tl >= pk[i]) { const pw = [W.pawR[0], W.pawR[1] - 4], u = ss((tl - (pl[i] - 320)) / 320); x = lerp(pw[0], slot[0], u); y = lerp(pw[1], slot[1], u); }
        else { x = PL[i][0]; y = PL[i][1]; }
        h += G(x, y, r, BS, BLK(i)); }
      return h; }; }
  // water the plants (once): lift the can, tip it, water arcs onto a sprout that grows, put the can down, clasp paws, admire it blooming
  const CAN = '<path d="M-1.2 0H6.8L6.2 6.4Q2.8 7.4-0.6 6.4Z" fill="#7cc35a" stroke="#4f8f3a" stroke-width="0.45"/><path d="M0 0Q2.8-3.6 5.6 0" stroke="#4f8f3a" stroke-width="0.7" fill="none"/><path d="M6.6 2.2L11.6-1.2L12.2-0.2L7 3.6Z" fill="#7cc35a" stroke="#4f8f3a" stroke-width="0.4"/><ellipse cx="12.1" cy="-0.9" rx="0.9" ry="1.4" transform="rotate(-35 12.1 -0.9)" fill="#a8d88a" stroke="#4f8f3a" stroke-width="0.35"/><path d="M0.4 1.4H5.8" stroke="#ffffff" stroke-width="0.6" opacity="0.4"/>';
  function waterMove(X) { const t = TL(REST);
    t.to(380, o(hand(1, -3, -1), { armR: 46, lx: 0.6, ly: 0.5, pitch: -0.08, smile: 0.8 }), 'io'); const a = t.t;
    t.to(420, { armR: 64, hRy: -5, tilt: 3, lean: 0.5 }, 'io'); const p0 = t.t; t.osc(1800, 4, { hRy: -4, htilt: 3 }, { hRy: -6, htilt: -3 }, 's'); const p1 = t.t;
    t.to(380, o(hand(1, 4, 2), { armR: 18, tilt: 0, lean: 0 }), 'io'); const b = t.t;
    t.to(320, o(both(10, -7), { armL: 30, armR: 30, hap: 1, smile: 1, sqz: 0.6, htilt: 6, ly: 0.4 }, X.cheer), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); t.fx('heart', 'head', 2).wait(900).to(300, { sqz: 0, close: 0.5 }).wait(300);
    t.back(420); const st = t.out({ next: 'idle', blend: 180 }); const e = st.dur;
    st.prop = (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const [gx, gy] = gnd(I), sx = rside(I, gx) + 10, sy = gy + 1, f0 = facing(I), CK = 1.9; let h = '';
      const gr = ss((tt - p0) / (p1 - p0)), bl = ss((tt - b - 200) / 500), fade = 1 - ss((tt - e + 500) / 500), sh = (3 + 13 * gr) * fade;
      if (sh > 0.3) { const lf = (0.4 + gr * 0.8) * fade; h += '<path d="M' + r2(sx) + ' ' + r2(sy) + 'Q' + r2(sx - 0.8) + ' ' + r2(sy - sh * 0.5) + ' ' + r2(sx) + ' ' + r2(sy - sh) + '" stroke="#4f8f3a" stroke-width="1.3" fill="none"/>' + G(sx, sy - sh * 0.55, -30 + Math.sin(tt / 400) * 6, lf * 1.8, '<path d="M0 0Q-4-0.6-5-3Q-1.6-3.2 0 0Z" fill="#7cc35a" stroke="#4f8f3a" stroke-width="0.35"/>') + G(sx, sy - sh * 0.75, 20 - Math.sin(tt / 400) * 6, lf * 1.8, '<path d="M0 0Q4-0.6 5-3Q1.6-3.2 0 0Z" fill="#8fd06a" stroke="#4f8f3a" stroke-width="0.35"/>');
        if (bl > 0.02) h += G(sx, sy - sh, 0, bl * fade, ICON.flower);
        h += '<ellipse cx="' + r2(sx) + '" cy="' + r2(sy + 0.4) + '" rx="6" ry="1.6" fill="#8a6a4a" opacity="' + r2(0.5 * fade) + '"/>'; }
      const ang = tt < a ? 0 : tt < p0 ? 45 * ss((tt - a) / (p0 - a)) : tt < p1 ? 45 + Math.sin(tt / 200) * 5 : 45 * (1 - ss((tt - p1) / (b - p1))), vis = 1 - ss((tt - b) / 300);
      if (vis > 0.02) { const p = W.pawR, an = ang * Math.PI / 180, lx = 12.4 * CK, ly = -1.2 * CK, sp = [p[0] + lx * Math.cos(an) - ly * Math.sin(an), p[1] + 2 + lx * Math.sin(an) + ly * Math.cos(an)];
        if (tt > p0 - 80 && tt < p1 + 80) for (let i = 0; i < 7; i++) { const u = ((tt / 260) + i / 7) % 1, x = lerp(sp[0], sx, u), y = lerp(sp[1], sy - sh, u) - Math.sin(Math.PI * u) * 2.6 + u * u * 2; h += '<ellipse cx="' + r2(x) + '" cy="' + r2(y) + '" rx="0.9" ry="1.3" fill="#8fd3ff" stroke="#5ab4f0" stroke-width="0.2" opacity="0.9"/>'; }
        h = G(p[0], p[1] + 2, ang, CK, CAN, vis * Math.max(0.35, f0)) + h; }
      return h; };
    return st; }
  // roast marshmallows (seated at the fire): stick out to the flames, turn it, toast golden, eat it; second one catches fire, blow it out, eat it anyway, new one
  const RSB = {
    hold(t) { const B = t.B; t.to(300, { lx: 0.8, ly: 0.2, wide: 0.3, smile: 0.8 }, 'io').osc(1800, 3, { hRy: B.hRy - 0.8, htilt: 2 }, { hRy: B.hRy + 0.4, htilt: -2 }, 's'); return t.back(300); },
    turn(t) { const B = t.B; t.to(200, { sqz: 0.3, smile: 1 }).osc(1400, 4, { hRx: B.hRx - 1.2, tilt: 1 }, { hRx: B.hRx + 0.6, tilt: -1 }, 's'); return t.back(300); },
    fire(t) { const B = t.B; t.to(160, { armR: 74, hRy: B.hRy - 5, wide: 1, open: 0.6, mw: 0.5, lean: -0.8, sq: B.sq - 0.04 }, 'o').osc(600, 4, { x: 0.6 }, { x: -0.6 }, 'l').to(100, { x: 0 }).wait(200); return t; },
    blow(t) { t.to(260, { puff: 0.9, open: 0, lx: 0.8 }).to(160, { puff: 0, open: 0.4, mw: 0.45 }, 'o').fx('gust', 'mouth').to(200, { puff: 0.8, open: 0 }).to(160, { puff: 0, open: 0.4 }, 'o').fx('gust', 'mouth').wait(300).to(240, { sqz: 0.6, hap: 1, smile: 1, open: 0.2, wide: 0 }, 'o').fx('sweat', 'head').wait(300); return t.back(420); },
    eat(t, X) { const B = t.B; t.to(420, o(hand(1, 8, -13), { armR: 36, pitch: (B.pitch || 0) + 0.02, lx: 0, ly: 0, open: 0.4 }), 'io').to(160, { open: 0, puff: 0.6 }, 'o').osc(900, 5, { puff: 0.6, open: 0.1 }, { puff: 0.2, open: 0 }, 'l').to(260, o({ smile: 1, hap: 1, sqz: 0.7, puff: 0 }, X.cheer), 'o').fx('heart', 'head').wait(300); return t.back(420); },
    new(t) { t.to(360, o(hand(-1, -10, -3), { armL: 54, lx: 0.6 }), 'io').wait(200).to(160, { sqz: 0.4 }, 'o').to(300, { sqz: 0 }); return t.back(380); },
  };
  function roastProp(st) {
    return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const tl = tt % st.loop, p = W.pawR, M = okp(W.mouth) ? W.mouth : [p[0] - 8, p[1] - 4], f0 = Math.max(0.3, facing(I));
      let tst = 0, burnt = 0, fire = 0, gone = 0, eat = 0, smk = -1, nw = 1; for (const [n, a, b] of st.beats) { if (tl < a) break; const u = cl((tl - a) / Math.max(1, b - a), 0, 1);
        if (n === 'hold' || n === 'turn') tst = Math.min(1, tst + 0.5 * u); else if (n === 'fire') { fire = ss(u / 0.15); burnt = u; } else if (n === 'blow') { fire = 1 - ss((tl - a - 350) / 250); if (tl > a + 400) smk = tl - a - 400; burnt = 1; }
        else if (n === 'eat') { eat = win(tl, a, b, 380); if (u > 0.3) gone = 1; } else if (n === 'new') { nw = ss((u - 0.35) / 0.25); if (u > 0.35) { tst = 0; burnt = 0; gone = 0; fire = 0; smk = -1; } } }
      const d = Math.hypot(M[0] - p[0], M[1] - p[1]), a0 = -22 * Math.PI / 180, a1 = Math.atan2(M[1] - p[1], M[0] - p[0]), an = lerp(a0, a1, eat), L = lerp(32, Math.max(7, d), eat), tip = [p[0] + Math.cos(an) * L, p[1] + Math.sin(an) * L];
      let h = '<path d="M' + r2(p[0] - Math.cos(an) * 2) + ' ' + r2(p[1] - Math.sin(an) * 2) + 'L' + r2(tip[0]) + ' ' + r2(tip[1]) + '" stroke="#9a6a3a" stroke-width="1.4" stroke-linecap="round" opacity="' + r2(f0) + '"/>';
      if (!gone) { const c0 = [246, 241, 230], c1 = [224, 162, 74], c2 = [70, 46, 34], mix = (x, y, u) => x.map((v, i) => Math.round(lerp(v, y[i], u))), c = burnt > 0 ? mix(mix(c0, c1, tst), c2, ss(burnt / 0.6)) : mix(c0, c1, tst), col = 'rgb(' + c.join(',') + ')', k = (0.4 + 0.6 * nw) * 1.8;
        h += G(tip[0], tip[1], an * 180 / Math.PI, k, '<rect x="-0.6" y="-2.2" width="5.2" height="4.4" rx="1.8" fill="' + col + '" stroke="' + (burnt > 0.3 ? '#2a1a10' : '#c9a46a') + '" stroke-width="0.35"/><ellipse cx="1.4" cy="-1" rx="1.4" ry="0.6" fill="#ffffff" opacity="' + r2(0.6 * (1 - burnt)) + '"/>' + (burnt > 0.5 ? '<path d="M0.4 1.6Q2 0.4 3.8 1.4" stroke="#ff8a2a" stroke-width="0.4" fill="none" opacity="0.7"/>' : ''), f0);
        if (fire > 0.02) h += G(tip[0] + 3, tip[1] - 6, Math.sin(tt / 80) * 6, fire * (2 + Math.sin(tt / 60) * 0.15), ICON.fire);
        if (smk >= 0 && smk < 1800) for (let i = 0; i < 3; i++) { const u = cl((smk - i * 280) / 1300, 0, 1); if (u > 0 && u < 1) h += ci(r2(tip[0] + 3 + Math.sin(u * 5 + i) * 2.4), r2(tip[1] - 5 - u * 18), r2(2 + u * 3.6), 'rgba(150,150,150,' + r2(0.55 * (1 - u)) + ')'); } }
      return h; }; }
  const BB = {};
  function bBuild(key, X) {
    X = o(WX[key] || {}, PLY[key] || {}, X || {}); const P = PROF[key] || {}, nm = n => key ? n + '@' + key : n, S = {}, SB = o(SIT0, P.pose || {}), BX = BED[key] || {};
    const sig = X.b || X.p || (P.f || []).find(f => typeof f === 'function'), md = LAP[key] ? 'lap' : TWO[key] ? 'two' : ''; X._dm = md;
    // bathroom sink: wash + brush teeth
    S[nm('sinkwash')] = bHold(o(SK0, X.skp || {}), X.skOrd || ['scrub', 'rinse', 'splash', 'sig', 'shake', 'mirror', 'scrub', 'dry'], SKB, X, sig, [400, 600, 500, 700]);
    { const st = bHold(o(BR0, X.brp || {}), X.brOrd || ['brush', 'side', 'brush', 'gargle', 'spit', 'grin', 'sig'], BRB, X, sig, [300, 500, 400, 600]); st.prop = brushProp(st, X.tb || '#5fb8e8'); S[nm('brush')] = st; }
    // sit + eat at the table
    { const DN = o(SB, both(8, -3), { armL: 22, armR: 22, pitch: (SB.pitch || 0) - 0.06, ly: 0.5, smile: 0.6, puff: 0 }, X.dnp || {});
      const st = bHold(DN, X.dnOrd || (md ? ['bite', 'chew', 'bite', 'crumbs', 'bite', 'sig', 'yum'] : ['bite', 'chew', 'bite', 'sip', 'crumbs', 'bite', 'lick', 'sig', 'yum']), DNB, X, sig, [700, 1100, 900, 1300]); st.prop = dineProp(st, X.sn || 'cookie', md); S[nm('dine')] = st;
      const di = sitdown(DN, P); di.next = 'dine'; S[nm('dinein')] = di; S[nm('dineout')] = standup(DN, P); }
    // beach: surf + fishing
    S[nm('surf')] = bHold(o(SF0, X.sfp || {}), X.sfOrd || ['wobble', 'carve', 'bump', 'hang10', 'sig', 'crouch', 'wipe'], SFB, X, sig, [500, 800, 600, 900], { breathe: 0.3 });
    { const st = bHold(o(FS0, X.fsp || {}), X.fsOrd || ['cast', 'look', 'nibble', 'hum', 'nibble', 'reel', 'catch', 'sig'], FB, X, sig, [600, 900, 700, 1000]); st.prop = fishProp(st, X.fc || 'fish'); st.catchEnd = ((st.rec.catch || [])[0] || [0, st.loop])[1]; S[nm('fishing')] = st; }
    // sunbathe on the towel / lounger (his own lie pose from the bedtime table)
    { const fl = P.dn === 'float', sea = P.dn === 'flop' && (P.pose || {}).sit === 0, adj = fl ? { sit: 0, lift: 1.2 } : sea ? { sit: 0, pitch: -0.1, htilt: 4, lift: -1.6 } : {};
      const SN = o(SB, LIE0, adj, BX.lp || {}, BX.np || {}, { qk: 0, zz: 0, drm: 0, close: 0.3, mw: 1, smile: 0.9, hap: 0.3, open: 0, shd: 1, shu: 0, puff: 0 }, X.snp || {});
      const a = sunIn(SB, SN, P); a.prop = sunProp(null); S[nm('sunin')] = a;
      const st = bHold(SN, X.snOrd || ['sigh', 'toes', 'sip', 'sig', 'lotion', 'peek', 'doze'], SUNB, X, X.ss || BX.s, [1400, 2000, 1700, 2300], { breathe: 0.6, noBlink: false }); st.prop = sunProp(st); S[nm('sun')] = st;
      const b = sunOut(SN, SB, P); b.prop = sunProp(null); S[nm('sunout')] = b; }
    // play: slide (once) + trampoline
    S[nm('slide')] = slideMove(P, X);
    { const TB = o(TB0, X.tbp || {}); S[nm('bouncein')] = bounceIn(TB, P); S[nm('bounce')] = bHold(TB, X.tbOrd || ['hop', 'jumps', 'star', 'hop', 'tuck', 'seat', 'hop', 'spin', 'sig', 'jumps'], TBB, X, sig, [150, 250, 200], { breathe: 0.2 }); S[nm('bounceout')] = bounceOut(TB, P); }
    // sitting on the ground: dig sand + stack blocks
    { const DG = o(SB, hand(1, 10, 3), hand(-1, 8, 4), { armL: 20, armR: 26, pitch: (SB.pitch || 0) - 0.16, ly: 0.6, smile: 0.7, hap: 0.3 }, X.dgp || {});
      const din = (nx) => { const t = TL(REST); t.to(200, { sq: 0.12, footL: 0, footR: 0 }, 'io'); const v = {}; keysOf(DG).forEach(p => v[p] = DG[p]); t.to(320, o(v, { sq: DG.sq + 0.1 }), 'i').to(180, { sq: DG.sq - 0.02 }, 'o').to(200, { sq: DG.sq }, 'io'); return t.out({ next: nx, blend: 200 }); };
      { const st = bHold(DG, X.dgOrd || ['scoop', 'pile', 'bucket', 'pat', 'scoop', 'bucket', 'flag', 'admire', 'sig', 'crumble'], DGB, X, sig, [400, 600, 500, 700]); st.prop = digProp(st); S[nm('dig')] = st; S[nm('digin')] = din('dig'); S[nm('digout')] = standup(DG, P); }
      { const st = bHold(DG, X.blOrd || ['stack', 'stack', 'stack', 'wobble', 'stack', 'stack', 'topple', 'giggle', 'sig', 'tidy'], BLB, X, sig, [500, 700, 600]); st.prop = blocksProp(st); S[nm('blocks')] = st; S[nm('blocksin')] = din('blocks'); S[nm('blocksout')] = standup(DG, P); } }
    // water the plants (once)
    S[nm('water')] = waterMove(X);
    // roast marshmallows at the fire (seated)
    { const RS = o(SB, hand(1, 1, -2), hand(-1, 6, 3), { armR: 42, armL: 16, pitch: (SB.pitch || 0) - 0.02, ly: 0.2, lx: 0.5, smile: 0.7, puff: 0 }, X.rsp || {});
      const st = bHold(RS, X.rsOrd || ['hold', 'turn', 'hold', 'eat', 'new', 'hold', 'turn', 'fire', 'blow', 'eat', 'new', 'sig'], RSB, X, sig, [600, 900, 700, 1000]); st.prop = roastProp(st); S[nm('roast')] = st;
      const ri = sitdown(RS, P); ri.next = 'roast'; S[nm('roastin')] = ri; S[nm('roastout')] = standup(RS, P); }
    R.add(S); R.HS = Object.assign(R.HS || {}, S); if (key) BB[key] = X;
  }
  build(null, {}); bedBuild(null, {}); waterBuild(null, {}); playBuild(null, {}); bBuild(null, {});
  R.HOUSE = { TL, BEAT, ZB, TB, SB0, WB0, PB, RB, CB, build, bedBuild, waterBuild, playBuild, bBuild, hand, both, SIDE, SIT0, LNG0, LIE0, CURL0, PROF, BED, WAT, PLY, BB, ICON, o, sitdown, standup, enterMove, exitMove, bHold, gnd, rside, G, facing, win, ss, cl, r2, shade, ci, pa, lerp, okp, LAP, TWO, BATH0 };
  if (window.HouseCreatures) window.HouseCreatures.forEach(f => f(R.HOUSE));
  window.HouseCreatures = { push: f => f(R.HOUSE) };
})();
