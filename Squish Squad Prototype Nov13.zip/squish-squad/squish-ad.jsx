// Squish Squad 30s commercial (9:16 master). Built on animations-v3.jsx.
const W = 1080, H = 1920, CW = 900, CH = 1400;
const SRC = k => 'export/tripo/' + k + '/' + k + '-front.svg';
const cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const mix = (a, b, k) => a + (b - a) * k;
const MOTION = { enter: Easing.easeOutCubic, pop: Easing.easeOutBack, spring: Easing.easeOutElastic };
const P = (T, a, b, e = MOTION.enter) => e(cl((T - a) / (b - a)));
const PIN = (T, a, b) => 1 - MOTION.enter(1 - cl((T - a) / (b - a)));
const ring = (c, r, n = 16) => Array.from({ length: n }, (_, i) => { const a = i / n * Math.PI * 2; return (Math.cos(a) * r).toFixed(1) + 'px ' + (Math.sin(a) * r).toFixed(1) + 'px 0 ' + c; }).join(',');
const INK = '#3a1a5c';
const OUT_XL = ring(INK, 11) + ',' + ring(INK, 6, 12) + ',0 16px 0 ' + INK + ',0 26px 36px rgba(0,0,0,0.35)';
const OUT_L = ring(INK, 7) + ',' + ring(INK, 4, 12) + ',0 9px 0 ' + INK + ',0 16px 24px rgba(0,0,0,0.3)';
const OUT_S = ring(INK, 4, 12) + ',0 5px 0 ' + INK;
const STICKER = 'drop-shadow(5px 0 0 #fff) drop-shadow(-5px 0 0 #fff) drop-shadow(0 5px 0 #fff) drop-shadow(0 -5px 0 #fff) drop-shadow(0 14px 18px rgba(40,10,70,0.4))';
const SOFT = 'drop-shadow(0 10px 14px rgba(40,10,70,0.28))';
const FD = "'Fredoka', sans-serif", NU = "'Nunito', sans-serif";
const home = id => (window.SquishHome && window.SquishHome.itemImg(id)) || '';
const decor = id => { const d = window.SquishDecor && window.SquishDecor.get(id); return d ? d.img : ''; };
const food = k => { const f = window.SquishFoods && window.SquishFoods.get(k); return f ? f.img : ''; };

// press curve: 0 → 1 (squashed) → springs back through 0 with overshoot
function press(t, list) {
  let last = null; for (const p of list) if (t >= p) last = p;
  if (last === null) return { sq: 0, n: 0, d: 99 };
  const d = t - last, n = list.filter(p => t >= p).length;
  const sq = d < 0.1 ? MOTION.enter(d / 0.1) : d < 0.18 ? 1 : 1 - MOTION.spring(cl((d - 0.18) / 0.7));
  return { sq, n, d };
}

function Cr({ k, x, y, w, sx = 1, sy = 1, rot = 0, o = 1, f = SOFT, z }) {
  return <img src={SRC(k)} alt="" style={{ position: 'absolute', left: x - w / 2, top: y - w, width: w, height: w, transform: `rotate(${rot}deg) scale(${sx},${sy})`, transformOrigin: '50% 94%', opacity: o, filter: f, zIndex: z }} />;
}
function Star({ x, y, s = 1, c = '#fff', o = 1, rot = 0 }) {
  return <svg viewBox="-10 -10 20 20" style={{ position: 'absolute', left: x - 30 * s, top: y - 30 * s, width: 60 * s, height: 60 * s, opacity: o, transform: `rotate(${rot}deg)` }}><path d="M0 -10 L2.6 -2.6 L10 0 L2.6 2.6 L0 10 L-2.6 2.6 L-10 0 L-2.6 -2.6Z" fill={c} /></svg>;
}
function Rays({ cx, cy, size, rot, a, b, o = 1, s = 1, n = 16 }) {
  const step = 360 / n / 2;
  return <div style={{ position: 'absolute', left: cx - size / 2, top: cy - size / 2, width: size, height: size, borderRadius: '50%', opacity: o, transform: `scale(${s}) rotate(${rot}deg)`, background: `repeating-conic-gradient(${a} 0deg ${step}deg, ${b} ${step}deg ${step * 2}deg)`, WebkitMaskImage: 'radial-gradient(circle, #000 18%, transparent 68%)', maskImage: 'radial-gradient(circle, #000 18%, transparent 68%)' }} />;
}
function Coin({ x, y, s = 1, o = 1, rot = 0 }) {
  return <div style={{ position: 'absolute', left: x - 30 * s, top: y - 30 * s, width: 60 * s, height: 60 * s, borderRadius: '50%', opacity: o, transform: `rotate(${rot}deg) scaleX(${Math.abs(Math.cos(rot / 40)) * 0.5 + 0.5})`, background: 'radial-gradient(circle at 35% 30%, #fff3b0 0%, #ffd23a 40%, #e8a020 100%)', boxShadow: `inset 0 0 0 ${5 * s}px #f0b429, 0 0 0 ${3 * s}px #b9741a` }} />;
}
function Finger({ x, y, s = 1, o = 1, rot = -12 }) {
  // tip at (x, y), pointing up
  return <svg viewBox="-60 -6 120 260" style={{ position: 'absolute', left: x - 60 * s, top: y - 6 * s, width: 120 * s, height: 260 * s, opacity: o, transform: `rotate(${rot}deg)`, transformOrigin: '50% 2%', overflow: 'visible', filter: 'drop-shadow(0 12px 14px rgba(40,10,70,0.35))' }}>
    <path d="M-18 0 Q-18 -4 0 -4 Q18 -4 18 0 L18 120 L-18 120Z" fill="#ffd2b0" stroke="#5b3a29" strokeWidth="5" strokeLinejoin="round" />
    <path d="M-48 104 Q-50 86 -30 86 L30 86 Q52 86 52 110 L52 200 Q52 252 0 252 Q-48 252 -48 200Z" fill="#ffd2b0" stroke="#5b3a29" strokeWidth="5" strokeLinejoin="round" />
    <path d="M-18 70 L18 70 L18 110 L-18 110Z" fill="#ffd2b0" />
    <path d="M-11 4 Q0 -1 11 4 L11 26 Q0 30 -11 26Z" fill="#fff1ea" stroke="#e8a888" strokeWidth="2" />
    <path d="M-12 56 Q0 60 12 56 M-12 64 Q0 68 12 64" stroke="#e0a080" strokeWidth="2.4" fill="none" strokeLinecap="round" />
    <path d="M-30 128 Q-8 136 14 128 M-30 160 Q-8 168 14 160" stroke="#e0a080" strokeWidth="2.6" fill="none" strokeLinecap="round" />
  </svg>;
}
function Pill({ children, bg = '#fff', c = INK, style }) {
  return <div style={Object.assign({ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 28px', borderRadius: 999, background: bg, color: c, fontFamily: FD, fontWeight: 700, fontSize: 40, boxShadow: '0 0 0 5px ' + INK + ', 0 8px 0 5px ' + INK }, style)}>{children}</div>;
}

function Logo({ x, y, s, o, rot = -4 }) {
  return <div style={{ position: 'absolute', left: x - 500, top: y - 230, width: 1000, height: 460, opacity: o, transform: `scale(${s}) rotate(${rot}deg)`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', fontFamily: FD, fontWeight: 700, lineHeight: 0.92 }}>
    <div style={{ fontSize: 210, color: '#fff', textShadow: OUT_XL, letterSpacing: 2 }}>Squish</div>
    <div style={{ fontSize: 230, color: '#ffd66b', textShadow: OUT_XL, letterSpacing: 2, marginLeft: 60 }}>Squad</div>
  </div>;
}

function Background({ T, C }) {
  const endGlow = P(T, C.End, C.End + 0.8);
  return <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: 'radial-gradient(circle at 50% 40%, #7a34c4 0%, #43187e 42%, #1a0c2e 100%)' }}>
    <Rays cx={540} cy={820} size={3000} rot={T * 5} a="rgba(255,255,255,0.075)" b="rgba(255,255,255,0)" n={20} />
    <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(rgba(255,255,255,0.35) 2.5px, transparent 3.4px) 0 0/72px 72px', backgroundPosition: `0px ${-T * 18}px`, opacity: 0.35 }} />
    <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 45%, rgba(255,111,190,0.55), rgba(255,111,190,0) 60%)', opacity: endGlow }} />
  </div>;
}

function Super({ T, C }) {
  const items = [
    { at: 0.2, until: C.Unbox + 1.85, text: "WHAT'S INSIDE?" },
    { at: C.Squish + 0.15, text: 'SQUISH THEM ALL' },
    { at: C.Collect + 0.1, text: 'COLLECT ALL 30' },
    { at: C.Home + 0.1, text: 'UPGRADE YOUR CRIB' },
    { at: C.Feed + 0.1, text: 'FEED THE SQUAD' },
    { at: C.Dance + 0.1, text: 'DANCE PARTY!' },
    { at: C.Daily + 0.1, until: C.End - 0.15, text: 'DAILY REWARDS' },
  ];
  let a = null, end = 0;
  items.forEach((it, i) => { if (T >= it.at) { a = it; end = it.until != null ? it.until : (items[i + 1] ? items[i + 1].at - 0.12 : 99); } });
  if (!a || T >= end) return null;
  const k = P(T, a.at, a.at + 0.4, MOTION.pop), out = cl((end - T) / 0.12);
  const wob = Math.sin((T - a.at) * 2.2) * 1.5;
  return <div style={{ position: 'absolute', left: 40, right: 40, top: 110, height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center', fontFamily: FD, fontWeight: 700, fontSize: 104, lineHeight: 1, color: '#fff', textShadow: OUT_L, opacity: Math.min(cl((T - a.at) / 0.08), out), transform: `scale(${mix(0.4, 1, k)}) rotate(${wob - 2}deg)` }}>{a.text}</div>;
}

/* ---------- 1 + 2: unbox → title (full frame) ---------- */
function Box({ T, C }) {
  const t = T - C.Unbox;
  const drop = P(t, 0, 0.6, MOTION.pop);
  const shake = t > 0.7 && t < 1.9 ? Math.sin(t * 46) * (2 + 9 * (t - 0.7) / 1.2) : 0;
  const hop = t > 0.7 && t < 1.9 ? Math.abs(Math.sin(t * 23)) * (t - 0.7) * 30 : 0;
  const lid = P(t, 1.9, 2.5);
  const gone = PIN(t, 3.3, 3.9);
  const y = (1 - drop) * -1500 + gone * 1100;
  if (t > 4) return null;
  return <div style={{ position: 'absolute', left: 540 - 310, top: 1000 + y, width: 620, height: 520, transform: `rotate(${shake}deg)`, transformOrigin: '50% 100%' }}>
    <div style={{ position: 'absolute', left: 30, top: 120, width: 560, height: 400, borderRadius: 34, background: 'linear-gradient(180deg,#ff8fd0,#ff5cb0)', boxShadow: 'inset 0 -24px 0 rgba(160,30,110,0.25), 0 0 0 8px ' + INK + ', 0 24px 40px rgba(0,0,0,0.4)' }}>
      <div style={{ position: 'absolute', left: 240, top: 0, width: 80, height: 400, background: 'linear-gradient(90deg,#ffd66b,#ffc24a)', boxShadow: 'inset 0 0 0 4px rgba(180,110,20,0.35)' }} />
      <div style={{ position: 'absolute', left: 0, right: 0, top: 110, textAlign: 'center', fontFamily: FD, fontWeight: 700, fontSize: 200, color: '#fff', textShadow: OUT_L, lineHeight: 1 }}>?</div>
    </div>
    <div style={{ position: 'absolute', left: 0, top: 60 - hop, width: 620, height: 130, borderRadius: 30, transform: `translate(${lid * 460}px, ${-lid * 1100}px) rotate(${lid * 70}deg)`, background: 'linear-gradient(180deg,#ffa3da,#ff6fbe)', boxShadow: 'inset 0 -14px 0 rgba(160,30,110,0.22), 0 0 0 8px ' + INK }}>
      <div style={{ position: 'absolute', left: 270, top: 0, width: 80, height: 130, background: 'linear-gradient(90deg,#ffd66b,#ffc24a)' }} />
      <div style={{ position: 'absolute', left: 200, top: -86, width: 100, height: 90, borderRadius: '60% 20% 60% 20%', background: '#ffd66b', boxShadow: '0 0 0 7px ' + INK, transform: 'rotate(-20deg)' }} />
      <div style={{ position: 'absolute', left: 320, top: -86, width: 100, height: 90, borderRadius: '20% 60% 20% 60%', background: '#ffd66b', boxShadow: '0 0 0 7px ' + INK, transform: 'rotate(20deg)' }} />
    </div>
  </div>;
}

function Burst({ T, C }) {
  const t = T - C.Unbox;
  const k = P(t, 1.9, 2.5, MOTION.pop), o = 1 - P(t, 3.5, 4.1);
  const flash = t < 1.82 ? 0 : t < 1.92 ? (t - 1.82) / 0.1 : 1 - P(t, 1.92, 2.45);
  const sparks = Array.from({ length: 10 }, (_, i) => {
    const a = i / 10 * Math.PI * 2 + 0.3, d = P(t, 1.95, 2.9) * (360 + (i % 3) * 90);
    return <Star key={i} x={540 + Math.cos(a) * d} y={880 + Math.sin(a) * d} s={0.9 + (i % 2) * 0.5} c={i % 2 ? '#fff6b8' : '#fff'} o={(1 - P(t, 2.6, 3.4)) * (t > 1.95 ? 1 : 0)} rot={t * 90} />;
  });
  return <React.Fragment>
    {t > 1.85 && t < 4.2 && <Rays cx={540} cy={880} size={1900} rot={T * 22} s={k} o={o} a="rgba(255,226,120,0.75)" b="rgba(255,226,120,0)" n={14} />}
    {t > 1.85 && t < 4.2 && <div style={{ position: 'absolute', left: 540 - 520, top: 880 - 520, width: 1040, height: 1040, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,250,220,0.95), rgba(255,250,220,0) 62%)', opacity: o, transform: `scale(${k})` }} />}
    {sparks}
    {flash > 0 && <div style={{ position: 'absolute', inset: 0, background: '#fff', opacity: flash * 0.9 }} />}
  </React.Fragment>;
}

function Legendary({ T, C }) {
  const t = T - C.Unbox;
  const k = P(t, 2.6, 3.0, MOTION.pop), o = 1 - P(t, 3.55, 3.85);
  if (t < 2.6 || t > 3.9) return null;
  return <div style={{ position: 'absolute', left: 540 - 380, top: 1170, width: 760, height: 170, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 999, opacity: o, transform: `scale(${k}) rotate(-3deg)`, background: 'linear-gradient(90deg,#ff6fbe,#ffb35c 55%,#ffd66b)', boxShadow: '0 0 0 10px #fff, 0 0 0 18px ' + INK + ', 0 18px 0 18px ' + INK, fontFamily: FD, fontWeight: 700, fontSize: 104, color: '#fff', textShadow: OUT_L, letterSpacing: 4 }}>LEGENDARY!</div>;
}

// Hana: rises from the box, then becomes the centre of the title squad
function Hana({ T, C }) {
  const t = T - C.Unbox;
  if (t < 1.95 || T > C.Squish + 0.4) return null;
  const rise = P(t, 2.0, 2.75, MOTION.pop);
  const toSquad = P(T, C.Title - 0.4, C.Title + 0.3);
  const leave = PIN(T, C.Title + 1.4, C.Title + 1.9);
  const bob = Math.sin(T * 4) * 10;
  const y = mix(mix(1260, 1110, rise) + bob, 1560, toSquad) + leave * 900;
  const w = mix(mix(220, 660, rise), 400, toSquad);
  const spin = (1 - rise) * -25;
  return <Cr k="hana" x={540} y={y} w={w} rot={spin} f={STICKER} />;
}

function Title({ T, C }) {
  const t = T - C.Title;
  if (t < -0.1 || t > 2.4) return null;
  const k = P(t, 0, 0.5, MOTION.pop), leave = PIN(t, 1.4, 1.85);
  const squad = [['mittens', 150, 1640, 300], ['nimbo', 330, 1520, 320], ['bunbun', 750, 1520, 320], ['leo', 930, 1640, 300]];
  return <React.Fragment>
    {squad.map(([kk, x, y, w], i) => {
      const s = P(t, 0.15 + i * 0.08, 0.6 + i * 0.08, MOTION.pop);
      const bob = Math.sin(T * 5 + i) * 8;
      return <Cr key={kk} k={kk} x={x} y={y + (1 - s) * 500 + bob + leave * 900} w={w} rot={(i < 2 ? -8 : 8) + Math.sin(T * 3 + i) * 3} f={STICKER} z={i === 1 || i === 2 ? 0 : 1} />;
    })}
    <Logo x={540} y={mix(700, 300, leave)} s={mix(2.6, 1, k) * (1 - leave * 0.4)} o={cl(t / 0.08) * (1 - leave)} />
  </React.Fragment>;
}

/* ---------- phone card + gameplay screens ---------- */
function Screen({ x, bg, children }) {
  if (Math.abs(x) >= CW) return null;
  return <div style={{ position: 'absolute', left: x, top: 0, width: CW, height: CH, overflow: 'hidden', background: bg }}>{children}</div>;
}
const DOTS = c => 'radial-gradient(' + c + ' 3px, transparent 3.8px) 0 0/48px 48px';

function SquishScreen({ T, C }) {
  const t = T - C.Squish;
  const A = [0.8, 1.45, 2.05], B = [3.0, 3.38, 3.74, 4.08, 4.4, 4.7];
  const swap = P(t, 2.4, 2.85);
  const pa = press(t, A), pb = press(t, B), cur = t < 2.6 ? pa : pb;
  const all = A.concat(B), n = all.filter(p => t >= p).length;
  const tip = { x: 450 + (cur.sq > 0 ? 0 : 0) - Math.sin(Math.PI * swap) * 260, y: 700 + 110 * (1 - Math.max(0, cur.sq)) };
  const handIn = P(t, 0.25, 0.7), handOut = PIN(t, 4.95, 5.3);
  const pops = all.map((p, i) => {
    const d = t - p; if (d < 0 || d > 0.9) return null;
    return <div key={i} style={{ position: 'absolute', left: 450 + (i % 2 ? 170 : -330), top: 520 - 170 * MOTION.enter(d / 0.9), width: 160, fontFamily: FD, fontWeight: 700, fontSize: 84, color: '#ffd66b', textShadow: OUT_S, opacity: 1 - cl((d - 0.5) / 0.4), transform: `scale(${P(d, 0, 0.2, MOTION.pop)})` }}>+5</div>;
  });
  const sparks = all.map((p, i) => {
    const d = t - p; if (d < 0 || d > 0.55) return null;
    return Array.from({ length: 6 }, (_, j) => { const a = j / 6 * Math.PI * 2 + i; const r = MOTION.enter(d / 0.55) * 300; return <Star key={i + '-' + j} x={450 + Math.cos(a) * r} y={760 + Math.sin(a) * r * 0.8} s={0.7} c={j % 2 ? '#fff' : '#fff6b8'} o={1 - d / 0.55} />; });
  });
  const combo = t > B[1] ? n : 0, ck = press(t, B).d;
  const sq = (k, pr, x) => <Cr k={k} x={450 + x} y={1090} w={640} sx={1 + 0.24 * pr.sq} sy={1 - 0.26 * pr.sq} f={SOFT} />;
  const zoom = 1 + 0.05 * cl(t / 5);
  return <Screen x={0} bg="radial-gradient(circle at 50% 45%, #fff0fa 0%, #ffc2e6 55%, #d29af2 100%)">
    <div style={{ position: 'absolute', inset: 0, background: DOTS('rgba(255,255,255,0.7)'), opacity: 0.6 }} />
    <div style={{ position: 'absolute', inset: 0, transform: `scale(${zoom})`, transformOrigin: '50% 55%' }}>
      <div style={{ position: 'absolute', left: 160, top: 1050, width: 580, height: 80, borderRadius: '50%', background: 'rgba(90,30,120,0.2)' }} />
      {swap < 1 && sq('nimbo', pa, -swap * 900)}
      {swap > 0 && sq('mittens', pb, (1 - swap) * 900)}
      {sparks}{pops}
    </div>
    <div style={{ position: 'absolute', left: 36, top: 40, right: 36, display: 'flex', justifyContent: 'space-between' }}>
      <Pill><div style={{ width: 46, height: 46, borderRadius: '50%', background: 'radial-gradient(circle at 35% 30%, #fff3b0, #ffd23a 45%, #e8a020)', boxShadow: 'inset 0 0 0 4px #f0b429' }} />{(1280 + n * 5).toLocaleString()}</Pill>
      <Pill bg="#b38cff" c="#fff">Lv 7</Pill>
    </div>
    <div style={{ position: 'absolute', left: 0, right: 0, top: 1150, display: 'flex', justifyContent: 'center' }}>
      <Pill style={{ fontSize: 48 }}>{t < 2.6 ? 'Nimbo' : 'Mittens'}</Pill>
    </div>
    {combo > 0 && <div style={{ position: 'absolute', left: 0, right: 0, top: 200, display: 'flex', justifyContent: 'center', transform: `scale(${1 + 0.18 * (1 - P(ck, 0, 0.25))}) rotate(-4deg)` }}>
      <Pill bg="linear-gradient(90deg,#ff6fbe,#ffb35c)" c="#fff" style={{ fontSize: 60, textShadow: OUT_S }}>COMBO x{combo}</Pill>
    </div>}
    <Finger x={tip.x + 40} y={tip.y + (1 - handIn) * 700 + handOut * 800} s={1.5} rot={-14} />
  </Screen>;
}

const ROSTER = ['avo', 'bao', 'biscuit', 'boba', 'bubbly', 'bunbun', 'choco', 'dunkie', 'finn', 'frybo', 'hana', 'hoot', 'jelli', 'kiko', 'leo', 'lumi', 'mallow', 'mittens', 'nibbles', 'nimbo', 'panko', 'pina', 'pip', 'prickle', 'quill', 'scoop', 'sealy', 'teddy', 'twinkle', 'zappi'];
const TILE = ['#dff1ff', '#e2f6d9', '#efe2ff', '#fff1c4', '#ffe1f0'];
function CollectScreen({ T, C }) {
  const t = T - C.Collect;
  const zoom = 1 + 0.05 * cl(t / 3.5);
  const count = ROSTER.filter((_, i) => t > 0.15 + i * 0.03).length;
  return <Screen x={0} bg="#fff3fb">
    <div style={{ position: 'absolute', inset: 0, background: DOTS('rgba(255,143,208,0.35)') }} />
    <div style={{ position: 'absolute', left: 40, right: 40, top: 46, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <div style={{ fontFamily: FD, fontWeight: 700, fontSize: 70, color: INK }}>My Squad</div>
      <Pill bg="#ff6fbe" c="#fff">{count} / 30</Pill>
    </div>
    <div style={{ position: 'absolute', left: 0, top: 0, width: CW, height: CH, transform: `scale(${zoom})`, transformOrigin: '50% 30%' }}>
      {ROSTER.map((k, i) => {
        const col = i % 5, row = Math.floor(i / 5), s = P(t, 0.05 + i * 0.03, 0.45 + i * 0.03, MOTION.pop);
        const leg = k === 'hana';
        return <div key={k} style={{ position: 'absolute', left: 26 + col * 176, top: 176 + row * 204, width: 164, height: 192, borderRadius: 30, background: leg ? 'linear-gradient(160deg,#ffe1f0,#ffd66b)' : TILE[(i * 3) % 5], boxShadow: leg ? '0 0 0 6px #fff, 0 0 0 11px #ff6fbe, 0 0 30px 10px rgba(255,214,107,' + (0.5 + 0.4 * Math.sin(T * 6)) + ')' : '0 0 0 6px #fff, 0 6px 0 6px rgba(58,26,92,0.18)', transform: `scale(${s})`, opacity: cl(s * 3) }}>
          <img src={SRC(k)} alt="" style={{ position: 'absolute', left: 8, top: 8 + Math.sin(T * 4 + i) * 4, width: 148, height: 148 }} />
          {leg && <div style={{ position: 'absolute', left: 6, right: 6, bottom: 8, textAlign: 'center', fontFamily: FD, fontWeight: 700, fontSize: 22, color: '#fff', textShadow: OUT_S, letterSpacing: 1 }}>LEGENDARY</div>}
        </div>;
      })}
    </div>
  </Screen>;
}

const SOFA_N = [232, 296, 360, 424, 488], SEATS = [2, 3, 4, 5, 6], SOFA_NAME = ['Tiny Loveseat', 'Comfy Sofa', 'Big Sofa', 'Sectional', 'Royal Lounge'], COST = [300, 800, 1600, 3000];
function HomeScreen({ T, C }) {
  const t = T - C.Home;
  const ups = [0.75, 1.35, 1.95, 2.55];
  const tier = ups.filter(u => t >= u).length;
  const last = tier ? ups[tier - 1] : -9;
  const pop = 1 + 0.16 * (1 - P(t, last, last + 0.55, MOTION.spring));
  const taps = ups.map(u => u - 0.14), tp = press(t, taps);
  const handIn = P(t, 0.2, 0.6), handOut = PIN(t, 3.0, 3.4);
  const sitters = ['mittens', 'teddy', 'leo', 'finn', 'hoot', 'kiko'];
  const sw = SOFA_N[tier] * 1.75, n = SEATS[tier];
  return <Screen x={0} bg="repeating-linear-gradient(90deg,#ffeedd 0 46px,#fff6ea 46px 92px)">
    <div style={{ position: 'absolute', left: 640, top: 150, width: 200, height: 250, borderRadius: '100px 100px 16px 16px', background: 'linear-gradient(180deg,#9fd8ff,#d9f2ff)', boxShadow: '0 0 0 14px #fff, 0 0 0 19px #e2c79f' }} />
    <img src={decor('l_art')} alt="" style={{ position: 'absolute', left: 60, top: 190, width: 200 }} />
    <div style={{ position: 'absolute', left: 450 - 190, bottom: CH - 640, width: 380 }}><img src={home('tv2')} alt="" style={{ width: '100%', display: 'block' }} /></div>
    <div style={{ position: 'absolute', left: 0, right: 0, top: 780, bottom: 0, background: 'repeating-linear-gradient(0deg,#e8b47c 0 70px,#dca56c 70px 74px)' }} />
    <div style={{ position: 'absolute', left: 0, right: 0, top: 766, height: 28, background: '#fff', boxShadow: '0 4px 0 #e2c79f' }} />
    <div style={{ position: 'absolute', left: 450 - sw / 2, top: 1130 - 116 * 1.75, width: sw, height: 116 * 1.75, transform: `scale(${pop})`, transformOrigin: '50% 100%' }}>
      <img src={home('sofa' + tier)} alt="" style={{ width: '100%', height: '100%' }} />
    </div>
    {sitters.slice(0, n).map((k, j) => {
      const bornAt = j < 2 ? 0 : ups[j - 2];
      const s = j < 2 ? 1 : P(t, bornAt, bornAt + 0.4, MOTION.pop);
      return <Cr key={k} k={k} x={450 + (j - (n - 1) / 2) * 112} y={1080 + (1 - s) * -200 + Math.sin(T * 5 + j) * 4} w={200} o={cl(s * 4)} rot={Math.sin(T * 3 + j) * 4} />;
    })}
    {tier > 0 && t - last < 0.6 && Array.from({ length: 8 }, (_, j) => { const a = j / 8 * Math.PI * 2, r = P(t, last, last + 0.6) * 380; return <Star key={j} x={450 + Math.cos(a) * r} y={1000 + Math.sin(a) * r * 0.6} c="#ffd66b" s={0.9} o={1 - (t - last) / 0.6} />; })}
    <div style={{ position: 'absolute', left: 40, top: 40 }}><Pill>Living Room</Pill></div>
    <div style={{ position: 'absolute', left: 30, right: 30, top: 1180, height: 190, borderRadius: 44, background: '#fff', boxShadow: '0 0 0 6px ' + INK + ', 0 10px 0 6px ' + INK, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 36px', boxSizing: 'border-box' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={{ fontFamily: FD, fontWeight: 700, fontSize: 48, color: INK }}>{SOFA_NAME[tier]}</div>
        <div style={{ display: 'flex', gap: 12 }}>{[0, 1, 2, 3, 4].map(i => <div key={i} style={{ width: 34, height: 34, borderRadius: '50%', background: i <= tier ? '#ffd66b' : '#eadff5', boxShadow: '0 0 0 4px ' + INK }} />)}</div>
      </div>
      <div style={{ transform: `scale(${1 - 0.1 * Math.max(0, tp.sq)})` }}>
        <Pill bg={tier < 4 ? 'linear-gradient(180deg,#ffe27a,#ffbf3a)' : '#c8f0d0'} style={{ fontSize: 44 }}>{tier < 4 ? <React.Fragment><div style={{ width: 40, height: 40, borderRadius: '50%', background: 'radial-gradient(circle at 35% 30%, #fff3b0, #ffd23a 45%, #e8a020)', boxShadow: 'inset 0 0 0 4px #f0b429, 0 0 0 3px #b9741a' }} />{COST[tier].toLocaleString()}</React.Fragment> : 'MAX ✓'}</Pill>
      </div>
    </div>
    <Finger x={640} y={1285 + 90 * (1 - Math.max(0, tp.sq)) + (1 - handIn) * 500 + handOut * 600} s={1.3} rot={-18} />
  </Screen>;
}

const MENU = ['donut', 'pizza', 'burger', 'cookie'];
function FeedScreen({ T, C }) {
  const t = T - C.Feed;
  const feeds = [0.35, 1.05, 1.75], dur = 0.45;
  const mouth = { x: 600, y: 860 };
  const arrivals = feeds.map(f => f + dur);
  const ch = press(t, arrivals);
  const fill = mix(0.22, 1, P(t, arrivals[0], arrivals[0] + 0.3) * 0.33 + P(t, arrivals[1], arrivals[1] + 0.3) * 0.33 + P(t, arrivals[2], arrivals[2] + 0.3) * 0.34);
  const full = t > arrivals[2] + 0.1;
  let finger = { x: 150, y: 1265, o: 1 };
  const flying = feeds.map((f, i) => {
    const k = cl((t - f) / dur); if (t < f || t > f + dur) return null;
    const e = MOTION.enter(k), sx = 150 + i * 200, sy = 1250;
    const x = mix(sx, mouth.x, e), y = mix(sy, mouth.y, e) - Math.sin(Math.PI * e) * 280;
    finger = { x: x + 20, y: y + 60, o: 1 };
    return <img key={i} src={food(MENU[i])} alt="" style={{ position: 'absolute', left: x - 75, top: y - 75, width: 150, height: 150, transform: `scale(${mix(1.1, 0.7, e)}) rotate(${e * 30}deg)`, filter: SOFT }} />;
  });
  const idle = feeds.findIndex(f => t < f);
  if (idle >= 0 && !flying.some(Boolean)) finger = { x: 150 + idle * 200, y: 1300, o: 1 };
  if (idle < 0 && !flying.some(Boolean)) finger = { x: 720, y: 1500, o: 1 };
  const crumbs = arrivals.map((a, i) => { const d = t - a; if (d < 0 || d > 0.6) return null; return Array.from({ length: 7 }, (_, j) => { const an = -Math.PI * (0.1 + j / 7.5), r = 160 * MOTION.enter(d / 0.6); return <div key={i + '-' + j} style={{ position: 'absolute', left: mouth.x + Math.cos(an) * r - 9, top: mouth.y + Math.sin(an) * r + 400 * d * d - 9, width: 18, height: 18, borderRadius: 6, background: ['#e8963c', '#ff8fb8', '#ffd23a'][j % 3], opacity: 1 - d / 0.6 }} />; }); });
  const hearts = full ? [0, 1, 2].map(j => { const d = t - arrivals[2] - 0.1 - j * 0.18; if (d < 0) return null; return <div key={j} style={{ position: 'absolute', left: 470 + j * 120, top: 560 - d * 260, fontSize: 90, color: '#ff5c8a', textShadow: OUT_S, opacity: 1 - cl((d - 0.6) / 0.5), transform: `scale(${P(d, 0, 0.3, MOTION.pop)})` }}>♥</div>; }) : null;
  return <Screen x={0} bg="repeating-linear-gradient(90deg,#d9f2e3 0 34px,#eafaf0 34px 68px)">
    <img src={decor('k_clock')} alt="" style={{ position: 'absolute', left: 640, top: 150, width: 150 }} />
    <img src={decor('k_plant')} alt="" style={{ position: 'absolute', left: 380, top: 0, width: 130 }} />
    <div style={{ position: 'absolute', left: 0, right: 0, top: 900, bottom: 0, background: 'conic-gradient(#fff6e6 90deg,#ffd9c2 90deg 180deg,#fff6e6 180deg 270deg,#ffd9c2 270deg) 0 0/120px 120px' }} />
    <div style={{ position: 'absolute', left: 20, bottom: CH - 1010, width: 330 }}><img src={home('fridge4')} alt="" style={{ width: '100%', display: 'block' }} /></div>
    <div style={{ position: 'absolute', left: 340, top: 1050, width: 520, height: 70, borderRadius: '50%', background: 'rgba(60,90,70,0.18)' }} />
    <Cr k="biscuit" x={600} y={1090} w={480} sx={1 + 0.14 * ch.sq} sy={1 - 0.14 * ch.sq} rot={full ? Math.sin(T * 8) * 4 : 0} />
    {crumbs}{hearts}
    <div style={{ position: 'absolute', left: 40, right: 40, top: 40, display: 'flex', alignItems: 'center', gap: 20 }}>
      <Pill>Kitchen</Pill>
      <div style={{ flex: 1, height: 44, borderRadius: 999, background: '#fff', boxShadow: '0 0 0 5px ' + INK, overflow: 'hidden' }}>
        <div style={{ width: (fill * 100) + '%', height: '100%', background: full ? '#7fd88f' : 'linear-gradient(90deg,#ffb35c,#ff6fbe)', borderRadius: 999 }} />
      </div>
      <div style={{ fontFamily: FD, fontWeight: 700, fontSize: 40, color: INK, width: 110 }}>{full ? 'Full!' : Math.round(fill * 100) + '%'}</div>
    </div>
    <div style={{ position: 'absolute', left: 30, right: 30, top: 1170, height: 200, borderRadius: 44, background: '#fff', boxShadow: '0 0 0 6px ' + INK + ', 0 10px 0 6px ' + INK }}>
      {MENU.map((m, i) => { const used = i < 3 && t >= feeds[i]; return <div key={m} style={{ position: 'absolute', left: 60 + i * 200, top: 25, width: 150, height: 150, borderRadius: '50%', background: '#fff3e0', boxShadow: '0 0 0 4px #ffd9a8' }}>
        {!used && <img src={food(m)} alt="" style={{ position: 'absolute', left: 10, top: 10, width: 130, height: 130 }} />}
      </div>; })}
    </div>
    <Finger x={finger.x} y={finger.y} s={1.3} rot={-14} o={P(t, 0.1, 0.35)} />
  </Screen>;
}

function DanceScreen({ T, C }) {
  const t = T - C.Dance, BEAT = 0.46;
  const pulse = 1 - ((t / BEAT) % 1);
  const crew = ['kiko', 'sealy', 'leo', 'jelli', 'hoot'];
  const beams = [['rgba(255,92,198,0.42)', -1], ['rgba(92,242,200,0.4)', 1], ['rgba(255,214,107,0.38)', 0.5]];
  return <Screen x={0} bg="linear-gradient(90deg, rgba(255,92,198,0.28) 2px, transparent 2px) 0 0/64px 64px, linear-gradient(0deg, rgba(92,242,200,0.24) 2px, transparent 2px) 0 0/64px 64px, #1a0c26">
    <div style={{ position: 'absolute', left: 0, right: 0, top: 960, bottom: 0, background: 'conic-gradient(#ff5cc6 90deg,#5cf2c8 90deg 180deg,#ff5cc6 180deg 270deg,#5cf2c8 270deg) 0 0/150px 150px', opacity: 0.55 + 0.35 * pulse }} />
    <div style={{ position: 'absolute', left: 0, right: 0, top: 960, height: 120, background: 'linear-gradient(180deg,#1a0c26,rgba(26,12,38,0))' }} />
    {beams.map(([c, dir], i) => <div key={i} style={{ position: 'absolute', left: 450 - 110, top: 170, width: 220, height: 1500, transformOrigin: '50% 0%', transform: `rotate(${Math.sin(T * 1.6 * Math.abs(dir) + i * 2) * 38 * Math.sign(dir)}deg)`, background: `linear-gradient(180deg, ${c}, rgba(0,0,0,0))`, clipPath: 'polygon(45% 0, 55% 0, 100% 100%, 0 100%)', mixBlendMode: 'screen' }} />)}
    <div style={{ position: 'absolute', left: 448, top: 0, width: 4, height: 80, background: '#c9b6f0' }} />
    <div style={{ position: 'absolute', left: 360, top: 80, width: 180, height: 180, borderRadius: '50%', background: `linear-gradient(90deg, rgba(255,255,255,0.5) 3px, transparent 3px) ${T * 40}px 0/26px 26px, linear-gradient(0deg, rgba(255,255,255,0.5) 3px, transparent 3px) 0 0/26px 26px, radial-gradient(circle at 35% 30%, #ffffff, #c9b6f0 45%, #6a4fa0)`, boxShadow: '0 0 60px 10px rgba(201,182,240,' + (0.3 + 0.4 * pulse) + ')' }} />
    <Cr k="pip" x={450} y={720} w={260} rot={Math.sin(T * 6.8) * 8} f="none" />
    <div style={{ position: 'absolute', left: 450 - 240, bottom: CH - 820, width: 480 }}><img src={home('dj3')} alt="" style={{ width: '100%', display: 'block' }} /></div>
    {crew.map((k, i) => {
      const ph = ((t + (i % 2) * BEAT / 2) / BEAT) % 1, hop = Math.sin(Math.PI * ph), s = Math.pow(1 - hop, 6);
      return <Cr key={k} k={k} x={110 + i * 170} y={1240 - hop * 90 - (i % 2 ? 0 : 60)} w={230} sx={1 + 0.16 * s} sy={1 - 0.16 * s} rot={Math.sin((t / BEAT) * Math.PI + i) * 9} />;
    })}
    {[0, 1, 2, 3].map(i => { const d = ((t + i * 0.8) % 3.2) / 3.2; return <div key={i} style={{ position: 'absolute', left: [120, 700, 260, 600][i] + Math.sin(d * 8) * 20, top: 880 - d * 600, fontSize: 80, color: ['#ff8fd0', '#7ff2d8', '#ffd66b', '#fff'][i], opacity: Math.sin(Math.PI * d), fontFamily: FD }}>♪</div>; })}
    <div style={{ position: 'absolute', left: 0, right: 0, top: 1290, display: 'flex', justifyContent: 'center' }}>
      <Pill bg="#2a1640" c="#fff" style={{ boxShadow: '0 0 0 5px #ff5cc6, 0 0 30px rgba(255,92,198,0.6)', fontSize: 38 }}>Now playing · Squish Groove</Pill>
    </div>
  </Screen>;
}

const TASKS = [['nimbo', 'Squish 50 times', 50, 60], ['biscuit', 'Feed 2 friends a snack', 2, 60], ['kiko', 'Send 2 friends to dance', 2, 50]];
function DailyScreen({ T, C }) {
  const t = T - C.Daily;
  const open = P(t, 2.0, 2.35), glow = P(t, 2.0, 2.5, MOTION.pop);
  const coins = Array.from({ length: 16 }, (_, i) => {
    const d = t - 2.05 - (i % 4) * 0.03; if (d < 0 || d > 1.1) return null;
    const a = -Math.PI / 2 + (i / 15 - 0.5) * 2.2, v = 900 + (i % 3) * 200;
    return <Coin key={i} x={450 + Math.cos(a) * v * d} y={1020 + Math.sin(a) * v * d + 1400 * d * d} s={1.1} rot={d * 400 + i * 30} o={1 - cl((d - 0.8) / 0.3)} />;
  });
  return <Screen x={0} bg="#efe7ff">
    <div style={{ position: 'absolute', inset: 0, background: DOTS('rgba(155,132,216,0.35)') }} />
    <div style={{ position: 'absolute', left: 40, right: 40, top: 46, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <div style={{ fontFamily: FD, fontWeight: 700, fontSize: 64, color: INK }}>Today</div>
      <Pill bg="#b38cff" c="#fff" style={{ fontSize: 36 }}>Resets in 12h</Pill>
    </div>
    {TASKS.map(([k, title, goal, rw], i) => {
      const fillK = P(t, 0.2 + i * 0.5, 0.75 + i * 0.5), done = fillK >= 1, chk = P(t, 0.75 + i * 0.5, 1.1 + i * 0.5, MOTION.pop);
      const enter = P(t, i * 0.08, 0.4 + i * 0.08);
      return <div key={k} style={{ position: 'absolute', left: 30, top: 180 + i * 220, width: 840, height: 190, borderRadius: 40, background: done ? '#e2f6d9' : '#fff', boxShadow: '0 0 0 6px ' + INK + ', 0 10px 0 6px ' + INK, transform: `translateX(${(1 - enter) * 900}px)` }}>
        <div style={{ position: 'absolute', left: 24, top: 24, width: 142, height: 142, borderRadius: '50%', background: '#fff3fb', boxShadow: '0 0 0 4px #ffc2e6', overflow: 'hidden' }}><img src={SRC(k)} alt="" style={{ width: 142, height: 142 }} /></div>
        <div style={{ position: 'absolute', left: 196, top: 30, right: 170, fontFamily: FD, fontWeight: 700, fontSize: 42, color: INK, lineHeight: 1.1 }}>{title}</div>
        <div style={{ position: 'absolute', left: 196, top: 112, width: 470, height: 40, borderRadius: 999, background: '#eadff5', boxShadow: 'inset 0 0 0 4px ' + INK, overflow: 'hidden' }}>
          <div style={{ width: (fillK * 100) + '%', height: '100%', background: done ? '#7fd88f' : 'linear-gradient(90deg,#ff6fbe,#ffb35c)', borderRadius: 999 }} />
        </div>
        <div style={{ position: 'absolute', right: 30, top: 50 }}>
          {done ? <div style={{ width: 96, height: 96, borderRadius: '50%', background: '#7fd88f', boxShadow: '0 0 0 6px ' + INK, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 64, color: '#fff', fontWeight: 900, fontFamily: NU, transform: `scale(${chk})` }}>✓</div>
            : <div style={{ fontFamily: FD, fontWeight: 700, fontSize: 40, color: '#c25e00', marginTop: 24 }}>+{rw}</div>}
        </div>
      </div>;
    })}
    {t > 1.9 && <Rays cx={450} cy={1040} size={1100} rot={T * 30} s={glow} a="rgba(255,214,107,0.7)" b="rgba(255,214,107,0)" n={12} />}
    <div style={{ position: 'absolute', left: 450 - 200, top: 1040, width: 400, height: 240, borderRadius: 34, background: 'linear-gradient(180deg,#c4844a,#9a5a2c)', boxShadow: '0 0 0 8px ' + INK + ', 0 20px 30px rgba(0,0,0,0.25)' }}>
      <div style={{ position: 'absolute', left: 170, top: -10, width: 60, height: 250, background: '#ffd23a', boxShadow: 'inset 0 0 0 4px #e8a020' }} />
      <div style={{ position: 'absolute', left: 168, top: 20, width: 64, height: 70, borderRadius: 14, background: '#ffe680', boxShadow: '0 0 0 5px ' + INK }} />
    </div>
    <div style={{ position: 'absolute', left: 450 - 215, top: 920, width: 430, height: 140, borderRadius: '60px 60px 20px 20px', background: 'linear-gradient(180deg,#d9955a,#b06a34)', boxShadow: '0 0 0 8px ' + INK, transform: `translate(${-open * 120}px, ${-open * 170}px) rotate(${-open * 28}deg)`, transformOrigin: '0% 100%' }}>
      <div style={{ position: 'absolute', left: 185, top: 0, width: 60, height: 140, background: '#ffd23a', boxShadow: 'inset 0 0 0 4px #e8a020' }} />
    </div>
    {coins}
    {t > 2.2 && <div style={{ position: 'absolute', left: 0, right: 0, top: 700, textAlign: 'center', fontFamily: FD, fontWeight: 700, fontSize: 150, color: '#ffd66b', textShadow: OUT_L, transform: `scale(${P(t, 2.2, 2.55, MOTION.pop)})` }}>+250</div>}
  </Screen>;
}

function Card({ T, C }) {
  const rise = P(T, C.Squish - 0.35, C.Squish + 0.3), drop = PIN(T, C.End - 0.2, C.End + 0.35);
  if (rise <= 0 || drop >= 1) return null;
  const order = [['Squish', SquishScreen], ['Collect', CollectScreen], ['Home', HomeScreen], ['Feed', FeedScreen], ['Dance', DanceScreen], ['Daily', DailyScreen]];
  const y = mix(H + 60, 360, rise) + drop * 1700;
  return <div style={{ position: 'absolute', left: 80, top: y, width: CW, height: CH, borderRadius: 72, overflow: 'hidden', boxShadow: '0 0 0 10px #fff, 0 0 0 16px ' + INK + ', 0 40px 80px rgba(0,0,0,0.5)', transform: `rotate(${(1 - rise) * 6 - drop * 8}deg)`, background: '#fff' }}>
    {order.map(([name, Comp], i) => {
      const c0 = C[name], c1 = i < order.length - 1 ? C[order[i + 1][0]] : C.End + 9;
      const inK = i === 0 ? 1 : P(T, c0 - 0.22, c0 + 0.22), outK = i < order.length - 1 ? P(T, c1 - 0.22, c1 + 0.22) : 0;
      const x = (1 - inK) * CW - outK * CW;
      if (Math.abs(x) >= CW) return null;
      return <div key={name} style={{ position: 'absolute', left: x, top: 0, width: CW, height: CH }}><Comp T={T} C={C} /></div>;
    })}
  </div>;
}

/* ---------- end card ---------- */
function IconTile({ x, y, s, o }) {
  return <div style={{ position: 'absolute', left: x - 160, top: y - 160, width: 320, height: 320, borderRadius: 76, overflow: 'hidden', opacity: o, transform: `scale(${s}) rotate(-4deg)`, background: 'repeating-conic-gradient(from 0deg at 50% 70%, #ff8fd0 0deg 11.25deg, #ff6fbe 11.25deg 22.5deg)', boxShadow: '0 0 0 10px #fff, 0 0 0 16px ' + INK + ', 0 24px 40px rgba(0,0,0,0.4)' }}>
    <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 70%, rgba(255,240,250,0.85), rgba(255,240,250,0) 55%)' }} />
    <img src={SRC('mittens')} alt="" style={{ position: 'absolute', left: -40, top: 130, width: 200, height: 200, transform: 'rotate(-12deg)' }} />
    <img src={SRC('leo')} alt="" style={{ position: 'absolute', left: 160, top: 130, width: 200, height: 200, transform: 'rotate(12deg)' }} />
    <img src={SRC('nimbo')} alt="" style={{ position: 'absolute', left: 50, top: 50, width: 220, height: 220, filter: SOFT }} />
  </div>;
}
function StoreBtn({ x, y, s, small, big }) {
  return <div style={{ position: 'absolute', left: x - 210, top: y - 70, width: 420, height: 140, borderRadius: 36, background: '#111', boxShadow: '0 0 0 5px #fff', transform: `scale(${s})`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: NU }}>
    <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: 1 }}>{small}</div>
    <div style={{ fontSize: 50, fontWeight: 900, lineHeight: 1 }}>{big}</div>
  </div>;
}
function End({ T, C, total }) {
  const t = T - C.End;
  if (t < 0) return null;
  const fade = 1 - P(T, total - 0.35, total - 0.02);
  const back = [['hoot', 230, 1600, 250], ['bunbun', 430, 1580, 250], ['sealy', 650, 1580, 250], ['teddy', 850, 1600, 250]];
  const front = [['mittens', 130, 1810, 280], ['nimbo', 390, 1790, 290], ['leo', 690, 1790, 290], ['finn', 950, 1810, 280]];
  return <div style={{ position: 'absolute', inset: 0, opacity: fade }}>
    <IconTile x={540} y={330} s={P(t, 0.15, 0.55, MOTION.pop)} o={cl((t - 0.15) / 0.1)} />
    <Logo x={540} y={720} s={mix(2.4, 1, P(t, 0.35, 0.85, MOTION.pop)) * 0.82} o={cl((t - 0.35) / 0.08)} />
    <div style={{ position: 'absolute', left: 0, right: 0, top: 960, display: 'flex', justifyContent: 'center', transform: `scale(${P(t, 0.8, 1.15, MOTION.pop)}) rotate(-2deg)` }}>
      <Pill bg="linear-gradient(90deg,#ffd66b,#ffb35c)" style={{ fontSize: 64, padding: '18px 48px' }}>FREE TO PLAY</Pill>
    </div>
    <StoreBtn x={310} y={1200} s={P(t, 1.05, 1.4, MOTION.pop)} small="Download on the" big="App Store" />
    <StoreBtn x={770} y={1200} s={P(t, 1.15, 1.5, MOTION.pop)} small="GET IT ON" big="Google Play" />
    {back.concat(front).map(([k, x, y, w], i) => {
      const s = P(t, 0.5 + i * 0.07, 0.95 + i * 0.07, MOTION.pop), ph = (T * 2.2 + i * 0.37) % 1, hop = Math.sin(Math.PI * ph) * 26;
      return <Cr key={k} k={k} x={x} y={y + (1 - s) * 500 - hop} w={w} rot={Math.sin(T * 3 + i) * 5} f={STICKER} />;
    })}
  </div>;
}

function VOCues({ C }) {
  const tag = txt => <span style={{ display: 'inline-flex', alignItems: 'center', gap: 16, padding: '12px 26px', borderRadius: 24, background: 'rgba(20,8,36,0.86)', fontFamily: NU, fontWeight: 800, fontSize: 32, color: '#fff' }}><span style={{ padding: '2px 12px', borderRadius: 10, background: '#ffd66b', color: INK, fontSize: 24, fontWeight: 900 }}>VO</span>{txt}</span>;
  const L = [[0.3, "What's inside…?"], [C.Unbox + 2.3, 'A Legendary!'], [C.Title + 0.2, 'Meet Squish Squad!'], [C.Squish + 0.3, 'Squish, squeeze and squash your plush friends.'], [C.Collect + 0.2, 'Collect all 30.'], [C.Home + 0.2, 'Build them a cosy home and upgrade every room.'], [C.Feed + 0.2, 'Feed them their favourite snacks…'], [C.Dance + 0.2, '…and throw a dance party!'], [C.Daily + 0.2, 'New challenges and rewards every day.'], [C.End + 0.3, 'Squish Squad. Download free today.']];
  return <Captions items={L.map(([at, txt]) => ({ at, text: tag(txt) }))} style={{ bottom: 26, left: 30, right: 30, font: 'inherit', textShadow: 'none' }} />;
}

function Piece({ showVO }) {
  const { T, CUES: C, authoredTotal } = useComposition();
  return <div data-screen-label={'t=' + Math.floor(T) + 's'} style={{ position: 'absolute', inset: 0, overflow: 'hidden', fontFamily: NU }}>
    <Background T={T} C={C} />
    <Burst T={T} C={C} />
    <Box T={T} C={C} />
    <Title T={T} C={C} />
    <Hana T={T} C={C} />
    <Legendary T={T} C={C} />
    <Card T={T} C={C} />
    <End T={T} C={C} total={authoredTotal} />
    <Super T={T} C={C} />
    {showVO && <VOCues C={C} />}
  </div>;
}

function SquishAd() {
  const [tw, setTweak] = useTweaks(window.TWEAK_DEFAULTS || { motionEditor: true, showVO: true });
  return <React.Fragment>
    <CompositionStage width={W} height={H} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#1a0c2e">
      <Piece showVO={tw.showVO} />
    </CompositionStage>
    <TweaksPanel>
      <TweakSection label="Playback" />
      <TweakToggle label="Motion editor" value={tw.motionEditor} onChange={v => setTweak('motionEditor', v)} />
      <TweakToggle label="Voiceover cue captions" value={tw.showVO} onChange={v => setTweak('showVO', v)} />
    </TweaksPanel>
  </React.Fragment>;
}
window.SquishAd = SquishAd;
