// Renovation Catalog round 28 — Kitchen realism pass, Electronics. Batch 1 = fridges (per-face renderer RD.H10 in fx, like MOV-034 mfr10):
// KIT-015 dented dorm cube, KIT-035 white top-freezer, KIT-055 brushed stainless French-door + ice dispenser.
// Fridges: r.kind 'fridge' -> st 'play' = door open (Squad House v6: while a friend snacks, vars[id] === 'open'; catalog: r.cp = OPEN-style play buttons).
// Draw order is view-safe: door / handles / bins swap before-after the body by which face looks at you; interiors only drawn while the front faces you.
// Sets RenoDraw.PLUS28; catalog edits RD.SET28; helpers RD.H28.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS27 && RD.H10 && RD.H15 && RD.N && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS28) return;
  const shade = X.K.shade, N = RD.N, PI = Math.PI, H = RD.H10;
  const { cam, box3, cyl3, sph, shadow, FR, flip, easeA, mist, lit, vis, yawA, DEF10, can3, add, mul, dot, rng, isPlay, an, at, SPL, f1, n4, rep, P2, FONT, tanF } = H;
  const curve = RD.H15.curve;
  const HANDW = `font-family="'Comic Sans MS','Chalkboard SE',cursive" font-weight="700"`;
  const G = (s, x, y, r, sc) => `<g transform="translate(${f1(x)} ${f1(y)})${r ? ` rotate(${f1(r)})` : ''}${sc ? ` scale(${sc})` : ''}">${s}</g>`;
  const PLN = (C, O, U, V, s) => `<g transform="${FR(C, O, U, V)}">${s}</g>`;
  const KT = k => ` keyTimes="${k}"`, HUMK = '0;0.82;0.85;0.88;0.91;0.94;1';
  const use = id => `<use href="#${id}"/>`, sym = (id, s) => `<g id="${id}">${s}</g>`;

  const DEF28 = DEF10
    + '<linearGradient id="k28gr" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6a5232" stop-opacity="0"/><stop offset="0.55" stop-color="#6a5232" stop-opacity="0.1"/><stop offset="1" stop-color="#4a3820" stop-opacity="0.26"/></linearGradient>'
    + '<linearGradient id="k28chr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f6f8fa"/><stop offset="0.45" stop-color="#b3b9be"/><stop offset="0.55" stop-color="#7f878e"/><stop offset="1" stop-color="#e2e6e9"/></linearGradient>'
    + '<linearGradient id="k28tape" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d6d9dc"/><stop offset="0.5" stop-color="#b2b6ba"/><stop offset="1" stop-color="#9a9ea2"/></linearGradient>'
    + '<pattern id="k28wv" width="0.8" height="0.8" patternUnits="userSpaceOnUse"><path d="M0 0.2H0.8M0.2 0V0.8" stroke="#ffffff" stroke-opacity="0.28" stroke-width="0.12"/></pattern>'
    + '<pattern id="k28br" width="44" height="0.8" patternUnits="userSpaceOnUse"><path d="M0 0.15H27M9 0.55H44" stroke="#ffffff" stroke-opacity="0.2" stroke-width="0.12"/><path d="M15 0.35H38" stroke="#000000" stroke-opacity="0.09" stroke-width="0.1"/></pattern>'
    + '<pattern id="k28ging" width="2" height="2" patternUnits="userSpaceOnUse"><rect width="2" height="2" fill="#fbf4ec"/><rect width="1" height="2" fill="#d8453a" opacity="0.55"/><rect width="2" height="1" fill="#d8453a" opacity="0.55"/></pattern>'
    + '<linearGradient id="k28ss" x1="0" y1="0" x2="1" y2="0.18"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.28" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.38" stop-color="#ffffff" stop-opacity="0.26"/><stop offset="0.46" stop-color="#ffffff" stop-opacity="0.06"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.08"/></linearGradient>'
    + '<radialGradient id="k28bulb" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff4c8" stop-opacity="0.85"/><stop offset="0.4" stop-color="#ffe9a8" stop-opacity="0.3"/><stop offset="1" stop-color="#ffe9a8" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="k28led" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.9"/><stop offset="0.4" stop-color="#eef6ff" stop-opacity="0.35"/><stop offset="1" stop-color="#eef6ff" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="k28spW" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff2c8" stop-opacity="0.6"/><stop offset="1" stop-color="#fff2c8" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="k28spC" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#f0f8ff" stop-opacity="0.75"/><stop offset="1" stop-color="#f0f8ff" stop-opacity="0"/></radialGradient>'
    + '<linearGradient id="k28rec" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#121417"/><stop offset="0.25" stop-color="#2a2e33"/><stop offset="1" stop-color="#3a3f44"/></linearGradient>'
    + '<linearGradient id="k28pad" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6c7278"/><stop offset="0.4" stop-color="#a2a9af"/><stop offset="1" stop-color="#585e64"/></linearGradient>'
    + '<linearGradient id="k28lin" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.25"/><stop offset="1" stop-color="#000000" stop-opacity="0.12"/></linearGradient>'
    + '<linearGradient id="k28haze" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.45"/></linearGradient>'
    + '<radialGradient id="k28amb" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffb24a" stop-opacity="0.55"/><stop offset="0.6" stop-color="#e8822a" stop-opacity="0.18"/><stop offset="1" stop-color="#e8822a" stop-opacity="0"/></radialGradient>'
    + '<linearGradient id="k28brs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f4dc9a"/><stop offset="0.45" stop-color="#c9a256"/><stop offset="1" stop-color="#8a6a2a"/></linearGradient>'
    + '<linearGradient id="k28hg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd8c8" stop-opacity="0.5"/><stop offset="0.5" stop-color="#e8d0f0" stop-opacity="0.32"/><stop offset="1" stop-color="#c8ece0" stop-opacity="0.45"/></linearGradient>'
    + '<linearGradient id="k28hsc" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0d0" stop-opacity="0"/><stop offset="0.5" stop-color="#fff0d0" stop-opacity="0.9"/><stop offset="1" stop-color="#fff0d0" stop-opacity="0"/></linearGradient>'
    + '<radialGradient id="k28cg" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ff8a3a" stop-opacity="0.7"/><stop offset="0.55" stop-color="#ff6a2a" stop-opacity="0.25"/><stop offset="1" stop-color="#ff6a2a" stop-opacity="0"/></radialGradient>';

  // ---------- face decal sprites (face-local units, v down) ----------
  const dent = (x, y, rx, ry, rot, k) => { k = k || 1; return G(`<ellipse cx="${f1(-rx * 0.2)}" cy="${f1(-ry * 0.22)}" rx="${f1(rx)}" ry="${f1(ry)}" fill="#3a3020" opacity="${n4(0.2 * k)}" filter="url(#m10b1)"/><ellipse cx="${f1(rx * 0.22)}" cy="${f1(ry * 0.26)}" rx="${f1(rx * 0.78)}" ry="${f1(ry * 0.7)}" fill="#ffffff" opacity="${n4(0.36 * k)}" filter="url(#m10b1)"/>`
    + `<path d="M${f1(-rx * 0.8)} ${f1(ry * 0.35)}Q${f1(rx * 0.1)} ${f1(ry * 1.05)} ${f1(rx * 0.85)} ${f1(-ry * 0.1)}" stroke="#ffffff" stroke-opacity="${n4(0.55 * k)}" stroke-width="0.3" fill="none"/><path d="M${f1(-rx * 0.75)} ${f1(-ry * 0.2)}Q${f1(-rx * 0.1)} ${f1(-ry * 0.95)} ${f1(rx * 0.7)} ${f1(-ry * 0.45)}" stroke="#2a2418" stroke-opacity="${n4(0.24 * k)}" stroke-width="0.35" fill="none"/>`, x, y, rot); };
  const scr = (R, n, x0, y0, w, h, col, op) => rep(n, () => { const x = x0 + R() * w, y = y0 + R() * h, l = 0.8 + R() * 3.4, a = (R() - 0.5) * 0.9;
    return `<path d="M${f1(x)} ${f1(y)}l${f1(l * Math.cos(a))} ${f1(l * Math.sin(a))}" stroke="${col}" stroke-opacity="${n4(op * (0.4 + R() * 0.6))}" stroke-width="${f1(0.12 + R() * 0.16)}" stroke-linecap="round"/>`; }).join('');
  const rust = (R, n, x0, x1, y) => rep(n, () => { const x = x0 + R() * (x1 - x0), yy = y - 0.4 - R() * 2.6, r = 0.2 + R() * 0.6, c = R() < 0.5 ? '#8a4a22' : '#a8642e';
    return `<circle cx="${f1(x)}" cy="${f1(yy)}" r="${f1(r)}" fill="${c}" opacity="${n4(0.45 + R() * 0.4)}"/>` + (R() < 0.6 ? `<path d="M${f1(x)} ${f1(yy)}V${f1(y)}" stroke="#8a4a22" stroke-opacity="0.3" stroke-width="${f1(0.25 + R() * 0.35)}" stroke-linecap="round"/>` : ''); }).join('');
  const fp = (x, y, s, rot, op) => G(rep(4, i => `<ellipse rx="${f1((0.45 + i * 0.32) * s)}" ry="${f1((0.65 + i * 0.42) * s)}" fill="none" stroke="#5a4a38" stroke-opacity="${op}" stroke-width="0.12"/>`).join(''), x, y, rot);
  const mag = (x, y, r, c) => `<circle cx="${f1(x + 0.25)}" cy="${f1(y + 0.35)}" r="${f1(r)}" fill="#000000" opacity="0.18"/><circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="${c}"/><circle cx="${f1(x - r * 0.3)}" cy="${f1(y - r * 0.35)}" r="${f1(r * 0.35)}" fill="#ffffff" opacity="0.55"/>`;
  const leafS = (C, q, sc, rot, col) => { const p = C.P(q); return `<g transform="translate(${P2(p)}) rotate(${f1(rot)}) scale(${n4(C.k * sc)})"><path d="M0 0C-1.7 -1.2 -2.1 -3.3 0 -3.9C2.1 -3.3 1.7 -1.2 0 0Z" fill="${col}"/><path d="M0 -0.3V-3.4" stroke="#b8dc70" stroke-width="0.2"/><path d="M-0.7 -2.4Q0 -2 0.9 -2.9" stroke="#f0e880" stroke-opacity="0.6" stroke-width="0.28" fill="none"/></g>`; };
  // cold mist that spills out of a door seal and sinks to the floor
  const wisp = (C, q, sz, d, b, dx, dy) => { const p = C.P(q); return `<g transform="translate(${P2(p)}) scale(${n4(C.k * sz)})"><ellipse rx="5" ry="2.4" fill="url(#m10mst)" opacity="0"><animate attributeName="opacity" values="0;0.36;0.12;0;0" keyTimes="0;0.2;0.45;0.6;1" dur="${d}s" begin="${b}s" repeatCount="indefinite"/><animateTransform attributeName="transform" type="translate" values="0 0;${dx} ${dy};${dx} ${dy}" keyTimes="0;0.6;1" dur="${d}s" begin="${b}s" repeatCount="indefinite"/></ellipse></g>`; };
  // a little puddle on the floor; a drop forms on the door edge above it, falls, ripples (9 s)
  const puddle = (C, x, z, rx, rz, dy) => { let s = PLN(C, [x, 0.06, z], [1, 0, 0], [0, 0, 1], `<ellipse rx="${rx}" ry="${rz}" fill="#9fc4d8" opacity="0.3"/><ellipse cx="${f1(-rx * 0.25)}" cy="${f1(-rz * 0.3)}" rx="${f1(rx * 0.45)}" ry="${f1(rz * 0.22)}" fill="#ffffff" opacity="0.35"/>`
      + `<ellipse rx="0.4" ry="0.4" fill="none" stroke="#ffffff" stroke-width="0.25" opacity="0"><animate attributeName="rx" values="0.4;0.4;${f1(rx * 0.7)};${f1(rx * 0.7)}" keyTimes="0;0.9;0.99;1" dur="9s" repeatCount="indefinite"/><animate attributeName="ry" values="0.4;0.4;${f1(rz * 0.7)};${f1(rz * 0.7)}" keyTimes="0;0.9;0.99;1" dur="9s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0;0.8;0;0" keyTimes="0;0.9;0.91;0.99;1" dur="9s" repeatCount="indefinite"/></ellipse>`);
    if (dy) { const a = C.P([x, dy, z]), b = C.P([x, 0.1, z]);
      s += `<ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="${f1(0.45 * C.k)}" ry="${f1(0.65 * C.k)}" fill="#d6ecf6" stroke="#8ab4c8" stroke-width="0.15" opacity="0"><animate attributeName="cy" values="${f1(a[1])};${f1(a[1])};${f1(a[1] + 0.5 * C.k)};${f1(b[1])};${f1(b[1])}" keyTimes="0;0.7;0.84;0.9;1" dur="9s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.9;0.9;0;0" keyTimes="0;0.7;0.89;0.9;1" dur="9s" repeatCount="indefinite"/></ellipse>`; }
    return s; };

  // ---------- doors on a vertical hinge ----------
  // hx = x of the hinge edge, zb = z of the door's back face when shut, sg 1 = hinged on its left edge, -1 = on its right edge, th = degrees open.
  // P(u, y, s): u from the door's left edge, y world height, s out from the back face
  const hingeD = (hx, zb, sg, w, t, th) => { const a = th * PI / 180, ex = sg > 0 ? [Math.cos(a), 0, Math.sin(a)] : [Math.cos(a), 0, -Math.sin(a)], ez = sg > 0 ? [-Math.sin(a), 0, Math.cos(a)] : [Math.sin(a), 0, Math.cos(a)];
    const L0 = sg > 0 ? [hx, 0, zb] : add([hx, 0, zb], mul(ex, -w));
    return { ex, ez, A: [ex, [0, 1, 0], ez], P: (u, y, s) => add(add(L0, mul(ex, u)), add([0, y, 0], mul(ez, s))), c: y => add(add(L0, mul(ex, w / 2)), add([0, y, 0], mul(ez, t / 2))) }; };
  // o: { hx, zb, sg, w, h, t, y0, col, gl, mat, r, dec, front(Dh, C) handles etc., back(Dh, C) bins on the inner side }
  const door = (C, o, th) => { const Dh = hingeD(o.hx, o.zb, o.sg, o.w, o.t, th), fv = vis(C, Dh.ez), fr = o.front ? o.front(Dh, C) : '', bk = o.back ? o.back(Dh, C) : '';
    const B = o.glass ? gframe(C, o, Dh) : box3(C, { c: Dh.c(o.y0), ax: Dh.A, w: o.w, h: o.h, d: o.t, r: o.r == null ? 1.2 : o.r, col: o.col, gl: o.gl, mat: o.mat, dec: o.dec, f: o.f, olw: 0.45, olo: 0.6 });
    return fv ? bk + B + fr : fr + B + bk; };
  // glass door: 2 stiles + 2 rails (real bars, nearest drawn last) round a tinted pane at mid thickness; o.fw / ft / fb frame sizes, o.tint / gop glass, o.gdec(gw, gh) decals on the pane
  const gframe = (C, o, Dh) => { const w = o.w, h = o.h, t = o.t, y0 = o.y0, fw = o.fw || 3.2, ft = o.ft || 4, fb = o.fb || 5, gw = w - 2 * fw, gh = h - ft - fb;
    const bar = (u0, u1, ya, yb) => ({ q: Dh.P((u0 + u1) / 2, (ya + yb) / 2, t / 2), s: box3(C, { c: Dh.P((u0 + u1) / 2, ya, t / 2), ax: Dh.A, w: u1 - u0, h: yb - ya, d: t, r: 0.35, col: o.col, gl: o.gl, mat: o.mat, olw: 0.35, olo: 0.6 }) });
    const B = [bar(0, fw, y0, y0 + h), bar(w - fw, w, y0, y0 + h), bar(fw, w - fw, y0 + h - ft, y0 + h), bar(fw, w - fw, y0, y0 + fb)].sort((a, b) => dot(a.q, C.v) - dot(b.q, C.v));
    return PLN(C, Dh.P(fw, y0 + h - ft, t * 0.55), Dh.ex, [0, -1, 0], `<rect width="${f1(gw)}" height="${f1(gh)}" fill="${o.tint}" opacity="${o.gop}"/>` + (o.gdec ? o.gdec(gw, gh) : '')) + B.map(b => b.s).join(''); };
  const refl = (gw, gh) => `<path d="M${f1(gw * 0.12)} 0H${f1(gw * 0.36)}L${f1(gw * 0.04)} ${f1(gh * 0.42)}H0V${f1(gh * 0.2)}Z" fill="#ffffff" opacity="0.07"/><path d="M${f1(gw * 0.64)} 0H${f1(gw * 0.7)}L${f1(gw * 0.3)} ${f1(gh * 0.62)}H${f1(gw * 0.24)}Z" fill="#ffffff" opacity="0.05"/><rect x="0.4" y="0.4" width="${f1(gw - 0.8)}" height="${f1(gh - 0.8)}" fill="none" stroke="#ffffff" stroke-opacity="0.22" stroke-width="0.35"/>`;
  // vertical wood grain + soft marble veins (face decals)
  const grainV = (R, w, h, n, c1, c2) => rep(n, () => { const x = R() * w, a = (R() - 0.5) * 4, b = (R() - 0.5) * 4; return `<path d="M${f1(x)} 0C${f1(x + a)} ${f1(h * 0.33)} ${f1(x + b)} ${f1(h * 0.66)} ${f1(x + (a + b) * 0.4)} ${f1(h)}" stroke="${R() < 0.6 ? c1 : c2}" stroke-opacity="${n4(0.15 + R() * 0.3)}" stroke-width="${f1(0.2 + R() * 0.8)}" fill="none"/>`; }).join('');
  const veins = (R, w, h) => { let s = ''; const vp = () => { const dx = (0.15 + R() * 0.35) * w, e = (R() - 0.5) * w * 0.08, x = w * 0.06 + R() * (w * 0.88 - dx), p = [[x + dx * 0.3 + e, h * 0.33], [x + dx * 0.66 - e, h * 0.66], [x + dx, h]]; return `M${f1(x)} 0C${p.map(q => f1(q[0]) + ' ' + f1(q[1])).join(' ')}`; };
    rep(6, () => { const d = vp(); s += `<path d="${d}" stroke="#8e8678" stroke-opacity="0.2" stroke-width="${f1(1 + R() * 2)}" fill="none" filter="url(#m10b1)"/><path d="${d}" stroke="#7a7266" stroke-opacity="0.32" stroke-width="0.25" fill="none"/>`; });
    rep(2, () => s += `<path d="${vp()}" stroke="#c9a256" stroke-opacity="0.6" stroke-width="0.35" fill="none"/>`); return s; };
  const swing = (C, o, a1, n, T, last) => { if (RD.H28 && RD.H28.still) return door(C, o, a1); const ANG = easeA(a1, n); return flip(ANG.map((a, i) => ({ i, s: door(C, i >= n - (last || 3) ? o : Object.assign({}, o, { back: null }), a) })), n, T); };

  // ---------- interior box seen through an open door (back wall, the side wall that faces you, floor) ----------
  const cavity = (C, x0, x1, y0, y1, z0, z1, col, o) => { o = o || {}; const IW = x1 - x0, IH = y1 - y0, ID = z1 - z0, sh = (n, f) => shade(col, lit(C, n) * (f || 1)), dk = o.dk || 0.5;
    let s = PLN(C, [x0, y1, z0], [1, 0, 0], [0, -1, 0], `<rect width="${f1(IW)}" height="${f1(IH)}" fill="${sh([0, 0, 1], 0.94)}"/><rect width="${f1(IW)}" height="${f1(IH)}" fill="url(#m10in)" opacity="${dk}"/>${o.back || ''}`);
    if (vis(C, [1, 0, 0])) s += PLN(C, [x0, y1, z0], [0, 0, 1], [0, -1, 0], `<rect width="${f1(ID)}" height="${f1(IH)}" fill="${sh([1, 0, 0], 0.9)}"/><rect width="${f1(ID)}" height="${f1(IH)}" fill="url(#m10in)" opacity="${dk}"/>${o.left || ''}`);
    if (vis(C, [-1, 0, 0])) s += PLN(C, [x1, y1, z1], [0, 0, -1], [0, -1, 0], `<rect width="${f1(ID)}" height="${f1(IH)}" fill="${sh([-1, 0, 0], 0.9)}"/><rect width="${f1(ID)}" height="${f1(IH)}" fill="url(#m10in)" opacity="${dk}"/>${o.right || ''}`);
    s += PLN(C, [x0, y0, z0], [1, 0, 0], [0, 0, 1], `<rect width="${f1(IW)}" height="${f1(ID)}" fill="${sh([0, 1, 0], 0.88)}"/><rect width="${f1(IW)}" height="${f1(ID)}" fill="url(#m10t)"/>${o.floor || ''}`);
    return s; };
  const gshelf = (C, x0, x1, y, z0, z1, trim) => box3(C, { c: [(x0 + x1) / 2, y, (z0 + z1) / 2], w: x1 - x0, h: 0.8, d: z1 - z0, r: 0, col: '#d4ecee', op: 0.3, olw: 0.3, olc: '#8ab4b8', edge: 0.8 })
    + box3(C, { c: [(x0 + x1) / 2, y - 0.5, z1 - 0.5], w: x1 - x0, h: 1.8, d: 1, r: 0.2, col: trim, gl: 0.4, olw: 0.3 });

  // ---------- food + containers (world-vertical) ----------
  const bottle = (C, x, y, z, r, h, col, cap, o) => { o = o || {}; const m = o.mat || 'gloss', op = o.op, sh = y + h * 0.62, nk = y + h * 0.8;
    return cyl3(C, [x, y, z], [x, sh, z], r, col, { mat: m, n: 18, op, olw: 0.3, noCap: 1 }) + cyl3(C, [x, sh, z], [x, nk, z], r, col, { r2: r * 0.42, mat: m, n: 18, op, olw: 0.3, noCap: 1 })
      + cyl3(C, [x, nk, z], [x, y + h, z], r * 0.42, col, { mat: m, n: 14, op, olw: 0.3 }) + cyl3(C, [x, y + h - 0.2, z], [x, y + h + Math.max(0.8, r * 0.5), z], r * 0.48, cap, { n: 14, olw: 0.3 })
      + (o.lbl ? `<g transform="${tanF(C, x, z, r + 0.03, C.thV, y + h * 0.34)}">${o.lbl}</g>` : ''); };
  const jar = (C, x, y, z, r, h, fill, lid, fl, lbl) => cyl3(C, [x, y + 0.3, z], [x, y + h * (fl || 0.82), z], r * 0.9, fill, { n: 18, olw: 0.2, mat: 'matte' })
    + cyl3(C, [x, y, z], [x, y + h, z], r, '#e8f4f4', { n: 18, op: 0.35, mat: 'gloss', olw: 0.3, olc: '#8aa0a4' }) + cyl3(C, [x, y + h, z], [x, y + h + 1.6, z], r * 1.03, lid, { n: 18, mat: 'gloss', olw: 0.3 })
    + (lbl ? `<g transform="${tanF(C, x, z, r + 0.03, C.thV, y + h * 0.45)}">${lbl}</g>` : '');
  const cup = (C, x, y, z, r, h, col, top, lbl) => cyl3(C, [x, y, z], [x, y + h, z], r * 0.88, col, { r2: r, n: 18, olw: 0.3, capCol: top }) + (lbl ? `<g transform="${tanF(C, x, z, r * 0.95, C.thV, y + h * 0.5)}">${lbl}</g>` : '');
  const grapes = (C, x, y, z, col) => { const R = rng('gr' + x + z); let s = ''; rep(16, i => { const a = i * 2.4, rr = 1.2 + (i % 5) * 0.7, q = [x + Math.cos(a) * rr * 0.8, y + 1 + (i % 4) * 0.9 - rr * 0.15, z + Math.sin(a) * rr * 0.6]; return { q, d: q[2] + q[1] * 0.3 }; }).sort((a, b) => a.d - b.d).forEach(g => s += sph(C, g.q, 1.15 + R() * 0.2, col)); return s; };

  // ======================= KIT-015 TINY DENTED DORM CUBE MINI-FRIDGE =======================
  // yellowed dorm cube on 3 feet + a cardboard shim, dented door, takeout menu under a pizza magnet, photo strip, peeling smiley + EnergyGuide stickers,
  // band sticker, "my YOGURT!!" note, duct tape holding the door shut, rust along the bottom, grime by the grip; ramen cup + mug on top; it rattles
  // every 12 s (note flutters, spoon rattles), cold mist seeps out of the bad seal, a drip falls into a puddle. Open: frosted freezer box, wire shelf, sad leftovers, flickering bulb.
  N.dorm28 = S => { const open = isPlay(S), BC = '#e9e1cc', W = 50, HB = 62, FT = 3, Z0 = -21, ZF = 18, DT = 3, IN = 2.4, TY = FT + HB, PF = 'k28d_';
    const D = { w: 56, d: 50, arch: 'minifridge', act: 'snack', use: { x: 0, z: 52 }, build: () => [] };
    const R = rng('dorm28');
    let dF = `<rect x="40" y="6" width="10" height="50" fill="url(#k28gr)"/>`;
    dF += rep(5, i => fp(44.5 + R() * 3, 16 + i * 6 + R() * 3, 0.9 + R() * 0.4, R() * 40 - 20, 0.14)).join('');
    dF += `<rect x="46.8" y="13" width="2" height="30" rx="1" fill="#3a3226" opacity="0.5"/><rect x="46.8" y="13" width="2" height="1.6" rx="0.8" fill="#000000" opacity="0.35"/><path d="M48.95 14V42" stroke="#ffffff" stroke-opacity="0.7" stroke-width="0.3"/>`;
    dF += dent(26, 41, 6.5, 4.2, -18, 1.1) + dent(14.5, 56, 2.8, 1.8, 10, 0.8) + dent(40, 52, 1.8, 1.4, 0, 0.7) + `<path d="M2 3.5Q6 5 9 4.2" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.3" fill="none"/><path d="M2 3.9Q6 5.5 9 4.7" stroke="#3a3020" stroke-opacity="0.18" stroke-width="0.35" fill="none"/>`;
    // takeout menu under a pizza magnet
    dF += G(`<rect x="0.4" y="0.5" width="14" height="20" fill="#000000" opacity="0.12"/><rect width="14" height="20" fill="#f7f1e2"/><rect width="14" height="20" fill="url(#m10noise)"/><rect width="14" height="4.2" fill="#c8352a"/><text x="7" y="3.1" text-anchor="middle" ${FONT} font-size="2.4" fill="#fff3d8">TONY'S</text>`
      + rep(7, i => `<path d="M1.4 ${f1(6.4 + i * 1.9)}h${f1(5 + (i * 37) % 5)}" stroke="#6a625a" stroke-width="0.35" opacity="0.7"/><path d="M10.6 ${f1(6.4 + i * 1.9)}h2" stroke="#c8352a" stroke-width="0.35"/>`).join('')
      + `<circle cx="10.2" cy="14.5" r="2.3" fill="#d8b070" opacity="0.35"/><circle cx="3.6" cy="17.4" r="1.2" fill="#d8b070" opacity="0.25"/>`
      + G(`<ellipse cx="0.3" cy="1.8" rx="2.6" ry="2.6" fill="#000000" opacity="0.15"/><path d="M-2.6 -1.2L2.6 -1.2L0 4Z" fill="#f2c25a"/><path d="M-2.6 -1.2L2.6 -1.2" stroke="#c88a3a" stroke-width="0.9" stroke-linecap="round"/><circle cx="-0.8" cy="0.4" r="0.6" fill="#c8352a"/><circle cx="0.9" cy="0.2" r="0.55" fill="#c8352a"/><circle cx="0" cy="2" r="0.5" fill="#c8352a"/><path d="M-2.2 -1.7L2.2 -1.7" stroke="#ffffff" stroke-opacity="0.55" stroke-width="0.25"/>`, 7, 0.9), 4, 13, -4);
    // photo strip
    dF += G(`<rect x="0.4" y="0.5" width="6" height="17" fill="#000000" opacity="0.15"/><rect width="6" height="17" fill="#f8f6f0"/>` + [0, 1, 2].map(i => `<rect x="0.7" y="${f1(0.7 + i * 5.4)}" width="4.6" height="4.8" fill="${['#e8b4c0', '#b4d4e8', '#f0dca0'][i]}"/><circle cx="2.2" cy="${f1(3.6 + i * 5.4)}" r="1.1" fill="#f6d8bc"/><circle cx="3.9" cy="${f1(3.3 + i * 5.4)}" r="1" fill="#e0c09a"/><path d="M1.6 ${f1(4.1 + i * 5.4)}q0.6 0.5 1.2 0" stroke="#5a3a2a" stroke-width="0.2" fill="none"/>`).join('') + mag(3, 0.3, 1.2, '#d83a3a'), 21, 5, 6);
    // peeling smiley sticker
    dF += G(`<circle r="4" fill="#f6d23a"/><circle r="4" fill="none" stroke="#c89a1a" stroke-width="0.25"/><circle cx="-1.4" cy="-1" r="0.55" fill="#2a2418"/><circle cx="1.4" cy="-1" r="0.55" fill="#2a2418"/><path d="M-2.2 0.8Q0 3.2 2.2 0.8" stroke="#2a2418" stroke-width="0.45" fill="none" stroke-linecap="round"/><path d="M2.1 2.5Q3.8 1.9 3.9 3.7Q3.1 4.5 2 4Z" fill="#fbf6e6"/><path d="M2.1 2.5Q2.6 3.6 2 4" stroke="#b8a888" stroke-width="0.2" fill="none"/>`, 37, 9);
    // band sticker (scratched)
    dF += G(`<rect width="15" height="5" rx="0.6" fill="#1e1c22"/><text x="7.5" y="3.6" text-anchor="middle" ${FONT} font-size="2.9" fill="#ff6fae" letter-spacing="0.2">SQUISH FM</text>${scr(R, 6, 0.5, 0.5, 12, 4, '#ffffff', 0.5)}`, 29, 20, -7);
    // EnergyGuide label, top-right corner peeling
    dF += G(`<rect width="12" height="14" fill="#f2d84a"/><rect width="12" height="3" fill="#1e1c18"/><text x="6" y="2.2" text-anchor="middle" ${FONT} font-size="1.6" fill="#f2d84a">ENERGYGUIDE</text><text x="6" y="7" text-anchor="middle" ${FONT} font-size="2.6" fill="#1e1c18">$39</text><rect x="1.4" y="9.2" width="9.2" height="1" fill="#1e1c18"/><path d="M4.6 8.6l0.8 1 0.8 -1Z" fill="#1e1c18"/>`
      + rep(3, i => `<path d="M1.4 ${f1(11.4 + i * 0.8)}h${f1(5 + i * 1.3)}" stroke="#1e1c18" stroke-width="0.25"/>`).join('') + `<path d="M8.4 0L12 0L12 3.6Z" fill="${BC}"/><path d="M8.4 0L12 3.6L9.4 4Z" fill="#fbf8ee"/><path d="M8.4 0L9.4 4" stroke="#000000" stroke-opacity="0.18" stroke-width="0.25"/>`, 5, 38, 2);
    dF += scr(R, 18, 3, 50, 42, 9, '#4a4238', 0.55) + rust(R, 14, 2, 48, 61.7);
    // "my YOGURT!!" note: flutters when the compressor kicks in
    dF += G(`<g>${at('rotate', '0;0;-3;2;-2;1;0', 12, -2, KT(HUMK))}<rect x="-4.6" y="0.5" width="10" height="9" fill="#000000" opacity="0.12"/><rect x="-5" width="10" height="9" fill="#ff9ec4"/><path d="M-5 9h10" stroke="#e07aa0" stroke-width="0.3"/><text x="0" y="3.6" text-anchor="middle" ${HANDW} font-size="2.1" fill="#3a2a6a">my</text><text x="0" y="6.2" text-anchor="middle" ${HANDW} font-size="2.1" fill="#3a2a6a">YOGURT!!</text><text x="2.6" y="8.4" text-anchor="middle" ${HANDW} font-size="1.5" fill="#3a2a6a">- B</text><rect x="-3" y="-1" width="6" height="2" fill="#f4f2e6" opacity="0.65"/></g>`, 37.5, 36, 3);
    // duct tape over the gap (door front -> door edge -> body side)
    const tp = 'M43.4 26.6L44.2 26.2L43.6 27.4L44.4 28.4L43.5 29.6L44.3 30.8L50 31.2V26Z';
    dF += `<path d="${tp}" fill="url(#k28tape)"/><path d="${tp}" fill="url(#k28wv)"/><path d="M45 27.5l3 0.4M45.5 29.8l3.4 -0.3" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.25"/><path d="M44.5 31L50 31.2" stroke="#000000" stroke-opacity="0.18" stroke-width="0.3"/>`;
    // door badge with a missing letter
    dF += `<rect x="17" y="55.4" width="16" height="3.4" rx="0.6" fill="url(#k28chr)"/><rect x="17" y="55.4" width="16" height="3.4" rx="0.6" fill="none" stroke="#7a8086" stroke-width="0.2"/><text x="25" y="58" text-anchor="middle" ${FONT} font-size="2.2" fill="#4a4c50" letter-spacing="0.5">K  OL CUBE</text><text x="21.1" y="58" text-anchor="middle" ${FONT} font-size="2.2" fill="#4a4c50" opacity="0.18">O</text>`;
    const dR = `<rect x="-0.1" y="26.1" width="3.2" height="5" fill="url(#k28tape)"/><rect x="-0.1" y="26.1" width="3.2" height="5" fill="url(#k28wv)"/>`;
    // door liner: gasket, butter flap, two door bins (moulded, flat)
    let dB = `<rect x="1.4" y="1.4" width="47.2" height="59.2" rx="1.6" fill="#e6e1d2"/><rect x="1.4" y="1.4" width="47.2" height="59.2" rx="1.6" fill="url(#k28lin)"/><rect x="1.4" y="1.4" width="47.2" height="59.2" rx="1.6" fill="none" stroke="#85827a" stroke-width="1.5"/><rect x="2.4" y="2.4" width="45.2" height="57.2" rx="1.2" fill="none" stroke="#ffffff" stroke-opacity="0.35" stroke-width="0.4"/>`
      + `<rect x="10" y="5" width="30" height="7" rx="1" fill="#f0ece0" stroke="#b9b4a6" stroke-width="0.35"/><text x="25" y="9.6" text-anchor="middle" ${FONT} font-size="1.8" fill="#a8a294">BUTTER</text>`
      + `<rect x="13" y="15" width="3.6" height="9" rx="1.4" fill="#f2c62a"/><rect x="13.8" y="12.6" width="2" height="2.6" fill="#c8302a"/><rect x="21" y="17.4" width="3" height="6.6" rx="0.8" fill="#b8241e"/><rect x="21.6" y="15.6" width="1.8" height="2" fill="#2e6a2a"/><text x="22.5" y="21.6" text-anchor="middle" ${FONT} font-size="0.9" fill="#ffffff">HOT</text>`
      + rep(6, i => `<rect x="${f1(29 + (i % 3) * 3.4)}" y="${f1(20.4 + Math.floor(i / 3) * 1.6)}" width="3" height="1.6" rx="0.3" fill="${i % 2 ? '#3a2a1a' : '#c8302a'}" transform="rotate(${(i * 23) % 17 - 8} ${f1(30.5 + (i % 3) * 3.4)} 21)"/>`).join('')
      + `<rect x="5" y="23" width="40" height="5" rx="0.8" fill="#f4f1e8"/><rect x="5" y="23" width="40" height="5" rx="0.8" fill="url(#k28lin)"/><path d="M5.4 23.4H44.6" stroke="#ffffff" stroke-width="0.4"/>`
      + `<rect x="11" y="35" width="7" height="13" fill="#ffffff"/><path d="M11 35L14.5 32.6L18 35Z" fill="#eef0f2"/><rect x="11" y="38" width="7" height="4.5" fill="#3a7ac8"/><text x="14.5" y="41.4" text-anchor="middle" ${FONT} font-size="1.7" fill="#ffffff">MILK</text><text x="14.5" y="46" text-anchor="middle" ${HANDW} font-size="1" fill="#c8302a">EXP 3/12</text>`
      + `<ellipse cx="26" cy="46.4" rx="2.6" ry="1.4" fill="#f6f4ee" stroke="#c8c2b4" stroke-width="0.25"/><ellipse cx="32" cy="46.6" rx="2.6" ry="1.4" fill="#f6f4ee" stroke="#c8c2b4" stroke-width="0.25"/><circle cx="26" cy="45.4" r="1.4" fill="#d84a2a"/>`
      + `<rect x="5" y="46" width="40" height="5" rx="0.8" fill="#f4f1e8"/><rect x="5" y="46" width="40" height="5" rx="0.8" fill="url(#k28lin)"/><path d="M5.4 46.4H44.6" stroke="#ffffff" stroke-width="0.4"/>`
      + rep(10, () => `<circle cx="${f1(4 + R() * 42)}" cy="${f1(52 + R() * 7)}" r="${f1(0.2 + R() * 0.5)}" fill="#7a6a4a" opacity="0.3"/>`).join('');
    // body sides / back / top
    let sR = `<path d="M0 26H4.2L3.6 27.2L4.6 28.6L3.8 29.8L4.5 31.2H0Z" fill="url(#k28tape)"/><path d="M0 26H4.2L3.6 27.2L4.6 28.6L3.8 29.8L4.5 31.2H0Z" fill="url(#k28wv)"/>` + dent(24, 22, 4.6, 6.5, 8, 1);
    sR += G(`<path d="M0 0L13 2.4L0 5Z" fill="#6a3aa8"/><path d="M0 0L13 2.4" stroke="#ffffff" stroke-opacity="0.4" stroke-width="0.2"/><text x="1.2" y="3.2" ${FONT} font-size="1.7" fill="#f6d23a" transform="rotate(5)">GO SQUIDS!</text>`, 6, 38, -6);
    sR += G(`<rect width="9.4" height="4.6" rx="0.5" fill="#ff8a2a"/><text x="4.7" y="3.2" text-anchor="middle" ${HANDW} font-size="2" fill="#1e1c18">$40 OBO</text><path d="M7.6 4.6L9.4 4.6L9.4 3Z" fill="${BC}"/>`, 24, 45, 5);
    sR += scr(R, 12, 2, 8, 32, 48, '#5a5046', 0.4) + rust(R, 10, 1, 38, 61.7) + rep(6, i => `<rect x="${f1(26 + i * 1.6)}" y="51" width="0.75" height="6.5" rx="0.37" fill="#000000" opacity="0.3"/>`).join('');
    let sL = dent(14, 30, 5, 3.4, -30, 0.9) + `<text x="20" y="20" text-anchor="middle" ${FONT} font-size="2.6" fill="#3a3a3a" opacity="0.24" letter-spacing="0.5">PROPERTY OF DORM B</text>` + rep(7, i => `<path d="M${f1(6 + i * 4.2)} ${f1(17 + (i % 3) * 1.1)}h${f1(2 + (i % 2) * 2.4)}" stroke="${BC}" stroke-width="1.3" opacity="0.8"/>`).join('') + scr(R, 10, 3, 6, 32, 50, '#5a5046', 0.35) + rust(R, 8, 1, 38, 61.7);
    let sB = `<rect x="6" y="5" width="38" height="44" rx="1" fill="#24221e"/><path d="M9 9H41V13H9V17H41V21H9V25H41V29H9V33H41V37H9V41H41V45H9" stroke="#46423a" stroke-width="1.5" fill="none"/><path d="M9 8.6H41M9 16.6H41M9 24.6H41M9 32.6H41M9 40.6H41" stroke="#7a756a" stroke-width="0.3" fill="none"/>`
      + rep(9, i => `<path d="M${f1(10 + i * 3.8)} 7V47" stroke="#2e2b26" stroke-width="0.35"/>`).join('') + rep(16, () => `<circle cx="${f1(7 + R() * 36)}" cy="${f1(30 + R() * 19)}" r="${f1(0.6 + R() * 1.6)}" fill="#a8a296" opacity="${n4(0.25 + R() * 0.3)}"/>`).join('')
      + `<rect x="15" y="51.5" width="20" height="6.6" rx="0.4" fill="url(#k28chr)"/><text x="25" y="54.2" text-anchor="middle" font-family="Arial" font-size="1.5" fill="#3a3c40">MODEL KC-17 · 115V 60Hz</text><text x="25" y="56.6" text-anchor="middle" font-family="Arial" font-size="1.5" fill="#3a3c40">1.7 CU FT · MADE 1998</text>`;
    let sT = `<rect width="50" height="39" fill="url(#m10noise)"/>` + rep(30, () => `<circle cx="${f1(R() * 50)}" cy="${f1(R() * 39)}" r="${f1(0.15 + R() * 0.35)}" fill="#8a7e66" opacity="0.35"/>`).join('')
      + `<circle cx="36" cy="12" r="3.4" fill="none" stroke="#7a4a22" stroke-opacity="0.35" stroke-width="0.5"/><circle cx="37.2" cy="13" r="3.2" fill="none" stroke="#7a4a22" stroke-opacity="0.2" stroke-width="0.35"/><circle cx="20" cy="30" r="2.6" fill="none" stroke="#7a4a22" stroke-opacity="0.22" stroke-width="0.4"/>`
      + `<path d="M6 8l1 2.2 2.4 0.2 -1.8 1.5 0.6 2.3 -2.2 -1.3 -2.1 1.3 0.6 -2.3 -1.8 -1.5 2.4 -0.2Z" fill="none" stroke="#2a2a6a" stroke-width="0.35" opacity="0.6"/><text x="44" y="34" text-anchor="middle" ${HANDW} font-size="2.6" fill="#2a2a6a" opacity="0.5">B+K</text>`;
    const defs = DEF28 + `<defs>${sym(PF + 'f', dF)}${sym(PF + 'b', dB)}${sym(PF + 'r', sR)}</defs>`;
    const DO = { hx: -W / 2, zb: ZF, sg: 1, w: W, h: HB, t: DT, y0: FT, col: shade(BC, 1.03), gl: 0.25, r: 1.6, f: 1.08, dec: { f: use(PF + 'f'), b: use(PF + 'b'), r: dR } };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), bv = vis(C, [0, 0, -1]), rv = vis(C, [1, 0, 0]);
      const body = o => box3(C, Object.assign({ c: [0, FT, (Z0 + ZF) / 2], w: W, h: HB, d: ZF - Z0, r: 3, col: BC, gl: 0.2, f: 1.08, dec: { r: use(PF + 'r'), l: sL, b: sB, t: sT }, olw: 0.5, olo: 0.65 }, o));
      const cord = curve(C, [[14, 9, Z0 - 0.3], [16, 1, Z0 - 5], [22, 0.6, Z0 - 8], [28, 0.7, Z0 - 11]], '#2a2826', 0.9) + box3(C, { c: [29.5, 0, Z0 - 12], ax: yawA(-0.6), w: 3, h: 2.2, d: 3.6, r: 0.5, col: '#2a2826', olw: 0.3 });
      const feet = [[-21, -17], [21, -17], [-21, 14], [21, 14]].map(([x, z], i) => i === 0 ? box3(C, { c: [x, 0, z], ax: yawA(0.3), w: 5.4, h: 1.5, d: 4.6, r: 0.2, col: '#c49a5a', olw: 0.3, dec: { f: '<path d="M0 0.75H5.4" stroke="#8a6a3a" stroke-width="0.2"/>', r: '<path d="M0 0.5H4.6M0 1H4.6" stroke="#8a6a3a" stroke-width="0.15"/>' } }) + cyl3(C, [x, 1.5, z], [x, FT, z], 1.4, '#2c2a28', { mat: 'matte', olw: 0.3 })
        : cyl3(C, [x, 0, z], [x, FT, z], 1.5, '#2c2a28', { mat: 'matte', olw: 0.3 })).join('');
      // top: ramen cup with a fork + peeled lid, mug with a rattling spoon
      const top = (() => { const nx = -13, nz = 4, mx = 11, mz = 8; let s = shadow(C, nx, nz, 5, 5, 0.5, TY + 0.05) + shadow(C, mx, mz, 4.4, 4.4, 0.5, TY + 0.05);
        const lid = `<path d="M${[[nx - 3.2, TY + 8, nz - 2.6], [nx + 3.2, TY + 8, nz - 2.6], [nx + 3.6, TY + 11.6, nz - 4.8], [nx - 2.8, TY + 11.9, nz - 4.4]].map(q => P2(C.P(q))).join('L')}Z" fill="#c9ced2" stroke="#8a9096" stroke-width="0.25"/><path d="M${P2(C.P([nx - 1.6, TY + 9.4, nz - 3.4]))}L${P2(C.P([nx + 2, TY + 9.3, nz - 3.5]))}" stroke="#d8352a" stroke-width="${f1(0.9 * C.k)}"/>`;
        const cupS = cyl3(C, [nx, TY, nz], [nx, TY + 8, nz], 3.3, '#f4efe2', { r2: 4.3, n: 24, olw: 0.35, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#e8d6a8"/><circle r="${f1(cr * 0.9)}" fill="url(#m10cap)"/><path d="M${f1(-cr * 0.7)} ${f1(-cr * 0.2)}q${f1(cr * 0.3)} ${f1(cr * 0.35)} ${f1(cr * 0.6)} 0t${f1(cr * 0.6)} 0M${f1(-cr * 0.6)} ${f1(cr * 0.25)}q${f1(cr * 0.3)} ${f1(cr * 0.35)} ${f1(cr * 0.6)} 0t${f1(cr * 0.6)} 0" stroke="#d8b46a" stroke-width="0.5" fill="none"/>` })
          + `<g transform="${tanF(C, nx, nz, 3.85, C.thV, TY + 4.6)}"><rect x="-3.4" y="-1.4" width="6.8" height="2.6" fill="#d8352a"/><text x="0" y="0.6" text-anchor="middle" ${FONT} font-size="1.6" fill="#fff2c8">RAMEN</text></g>`;
        const fa = C.P([nx + 0.8, TY + 6.5, nz + 0.5]), fb = C.P([nx + 2.6, TY + 12.6, nz + 1.5]);
        const fork = `<path d="M${P2(fa)}L${P2(fb)}" stroke="#c8ccd2" stroke-width="${f1(0.6 * C.k)}" stroke-linecap="round"/><path d="M${P2(fb)}l${f1(-0.4 * C.k)} ${f1(-1.6 * C.k)}M${P2(fb)}l${f1(0.4 * C.k)} ${f1(-1.6 * C.k)}" stroke="#c8ccd2" stroke-width="${f1(0.3 * C.k)}"/>`;
        s += fv ? lid + cupS + fork : cupS + fork + lid;
        const hdl = PLN(C, [mx + 2.9, TY + 5.4, mz], [1, 0, 0], [0, -1, 0], `<path d="M-0.2 0Q2.6 0 2.6 2Q2.6 4 -0.2 4" stroke="#3f6eb0" stroke-width="1" fill="none"/><path d="M-0.2 0.3Q2.2 0.3 2.2 2" stroke="#ffffff" stroke-opacity="0.4" stroke-width="0.3" fill="none"/>`);
        const mug = cyl3(C, [mx, TY, mz], [mx, TY + 6.5, mz], 3, '#4a7cc0', { mat: 'gloss', n: 22, olw: 0.35, cap: cr => `<circle r="${f1(cr * 0.86)}" fill="#3a2414"/><ellipse cx="${f1(-cr * 0.25)}" cy="${f1(-cr * 0.25)}" rx="${f1(cr * 0.3)}" ry="${f1(cr * 0.15)}" fill="#ffffff" opacity="0.25"/>` })
          + `<g transform="${tanF(C, mx, mz, 3.02, C.thV, TY + 3.4)}"><text x="0" y="0.5" text-anchor="middle" ${FONT} font-size="1.25" fill="#ffffff">I ♥ NAPS</text></g>`;
        const sa = C.P([mx - 0.6, TY + 5.4, mz + 0.4]), sb = C.P([mx - 2.2, TY + 10.6, mz + 1.6]), rv0 = `0 ${P2(sa)}`;
        const spoon = `<g>${at('rotate', [0, 0, 5, -4, 3, -1, 0].map(a => a + ' ' + P2(sa)).join(';'), 12, -2, KT(HUMK))}<path d="M${P2(sa)}L${P2(sb)}" stroke="#c8ccd2" stroke-width="${f1(0.55 * C.k)}" stroke-linecap="round"/><path d="M${P2(sa)}L${P2(sb)}" stroke="#ffffff" stroke-opacity="0.5" stroke-width="${f1(0.18 * C.k)}"/></g>`;
        s += (rv ? mug + hdl : hdl + mug) + spoon; return s; })();
      let s = shadow(C, 0, -1, 31, 27, 0.9);
      if (!bv) s += cord;
      if (!open) { const dr = door(C, DO, 0);
        s += puddle(C, 18, ZF + DT + 2.2, 5, 2.6, FT + 0.2);
        s += `<g>${at('translate', '0 0;0 0;0.22 0;-0.22 0;0.16 0;-0.1 0;0 0', 12, -2, KT(HUMK))}${feet}${fv ? body() + dr : dr + body()}${top}</g>`;
        if (fv) s += wisp(C, [W / 2 - 3, FT + 1, ZF + DT + 0.6], 0.5, 8, 0, 3, 5) + wisp(C, [W / 2 - 4, FT + 4, ZF + DT + 0.6], 0.42, 8, -4.5, 4, 6);
      } else {
        const x0 = -W / 2 + IN, x1 = W / 2 - IN, y0 = FT + IN, y1 = TY - IN, z0 = Z0 + IN, z1 = ZF; let o = '';
        if (fv) { const Rb = rng('dorm28in');
          o += cavity(C, x0, x1, y0, y1, z0, z1, '#e4dfcf', { dk: 0.6,
            back: `<ellipse cx="30" cy="40" rx="4" ry="2.6" fill="#c8a84a" opacity="0.22"/><path d="M14 13Q14.4 20 13.6 27" stroke="#c8b888" stroke-opacity="0.4" stroke-width="0.5" fill="none"/>` + rep(14, () => `<circle cx="${f1(R() * 6 + 1)}" cy="${f1(50 + Rb() * 6)}" r="${f1(0.2 + Rb() * 0.35)}" fill="#4a5a3a" opacity="0.4"/>`).join(''),
            left: rep(3, i => `<path d="M1 ${f1(34.6 + i * 0.6)}H36" stroke="#ffffff" stroke-opacity="${0.5 - i * 0.15}" stroke-width="0.35"/>`).join(''),
            floor: `<ellipse cx="30" cy="20" rx="6" ry="3.4" fill="#c87a3a" opacity="0.18"/><ellipse cx="12" cy="10" rx="3" ry="2" fill="#b8a040" opacity="0.2"/>` });
          // floor: old lemon, takeout box with a wire handle, ketchup, 2 sodas
          o += sph(C, [-15, y0 + 2.3, -12], 2.4, '#c4b040');
          o += box3(C, { c: [11, y0, -9], w: 11, h: 9, d: 9, r: 0.3, col: '#f6f2e8', olw: 0.35, dec: { f: `<path d="M3.2 6.4L5.5 3.6L7.8 6.4ZM3.8 6.4V8H7.2V6.4" fill="none" stroke="#c8302a" stroke-width="0.35"/><text x="5.5" y="2.6" text-anchor="middle" ${FONT} font-size="1.3" fill="#c8302a">THANK YOU</text>`, t: '<path d="M0 4.5H11" stroke="#d8d2c4" stroke-width="0.3"/>' } })
            + PLN(C, [5.5, y0 + 9, -9], [1, 0, 0], [0, -1, 0], `<path d="M0.6 0Q5.5 -5.4 10.4 0" stroke="#9aa0a6" stroke-width="0.35" fill="none"/>`);
          o += bottle(C, -14, y0, 7, 2.4, 9, '#c8281e', '#f4f2ec', { lbl: `<rect x="-2" y="-1.4" width="4" height="2.8" fill="#f4f2ec"/><circle cx="-0.9" cy="0" r="0.8" fill="#c8281e"/><text x="0.7" y="0.4" text-anchor="middle" ${FONT} font-size="0.7" fill="#c8281e">HEINZ</text>` });
          o += can3(C, 2, y0, 4, 2.6, 9, 2) + can3(C, -5, y0, 9, 2.6, 9, 0);
          // wire shelf + its items
          const SY = 27; o += PLN(C, [x0, SY, z0], [1, 0, 0], [0, 0, 1], rep(12, i => `<path d="M${f1(1 + i * 3.9)} 0.4V${f1(z1 - z0 - 0.6)}" stroke="#7d868c" stroke-width="0.5"/><path d="M${f1(0.86 + i * 3.9)} 0.4V${f1(z1 - z0 - 0.6)}" stroke="#e8eef1" stroke-width="0.22"/>`).join('') + `<path d="M0 1H${f1(x1 - x0)}M0 ${f1(z1 - z0 - 1)}H${f1(x1 - x0)}" stroke="#d5dde2" stroke-width="0.9"/>`);
          o += cup(C, -12, SY + 0.4, -8, 3, 5, '#f8f6f0', '#d8dde0', `<rect x="-2.4" y="-1.2" width="4.8" height="2.4" fill="#f28ab0"/><text x="0" y="0.5" text-anchor="middle" ${HANDW} font-size="1.2" fill="#ffffff">B's</text>`);
          o += box3(C, { c: [14, SY + 0.4, -6], w: 5, h: 9, d: 5, r: 0.2, col: '#f6f4ee', olw: 0.3, dec: { f: `<rect y="2.4" width="5" height="3.4" fill="#3a7ac8"/><text x="2.5" y="4.8" text-anchor="middle" ${FONT} font-size="1.3" fill="#ffffff">MILK</text>`, r: `<rect y="2.4" width="5" height="3.4" fill="#3a7ac8"/>` } }) + box3(C, { c: [14, SY + 9.4, -6], w: 4.8, h: 1.3, d: 0.6, r: 0.1, col: '#eeece4', olw: 0.25 });
          o += cyl3(C, [3, SY + 0.4, 2], [3, SY + 1.1, 2], 7, '#f4f0e6', { n: 28, olw: 0.3, cap: () => `<circle r="5.6" fill="none" stroke="#e2dccc" stroke-width="0.5"/><path d="M-3.6 -2.6L4 -2.4L0.6 4.6Z" fill="#f0b048"/><path d="M-3.6 -2.6L4 -2.4" stroke="#c07a2a" stroke-width="1.2" stroke-linecap="round"/><path d="M-2.6 -1.6L3 -1.5L0.6 3.4Z" fill="#d8502a" opacity="0.8"/><circle cx="-0.6" cy="-0.4" r="0.8" fill="#a8241e"/><circle cx="1.4" cy="0.2" r="0.7" fill="#a8241e"/><circle cx="0.4" cy="2" r="0.6" fill="#a8241e"/><path d="M-1.4 -0.8l0.8 0.5M1.6 1.2l0.6 0.4" stroke="#fff2c0" stroke-width="0.3"/>` });
          // freezer box: frost crust, icicles, ice tray + peas; drip tray under it
          o += box3(C, { c: [0, 45.4, -5.5], w: 36, h: 1.6, d: 23, r: 0.4, col: '#b9bec2', olw: 0.3, dec: { t: '<rect x="2" y="2" width="32" height="19" rx="1" fill="#9fc4d8" opacity="0.4"/><ellipse cx="12" cy="8" rx="5" ry="1.4" fill="#ffffff" opacity="0.4"/>' } });
          const frost = (w, h) => rep(28, i => { const t = i / 28, e = i % 4; const x = e === 0 ? t * w * 4 % w : e === 1 ? w - 0.6 : e === 2 ? (t * w * 4) % w : 0.6, y = e === 0 ? 0.6 : e === 2 ? h - 0.6 : (t * h * 4) % h; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(0.5 + ((i * 7) % 5) * 0.25)}" fill="#f4fbff" opacity="0.92"/>`; }).join('');
          o += box3(C, { c: [0, 47.4, -5.5], w: 40, h: 13, d: 25, r: 0.6, col: '#cdd5da', gl: 0.3, olw: 0.35, dec: {
            f: `<rect x="1.4" y="1.4" width="37.2" height="10.2" rx="0.8" fill="#4f5c66"/><rect x="1.4" y="1.4" width="37.2" height="10.2" rx="0.8" fill="url(#m10in)"/><rect x="4" y="6.8" width="13" height="4" fill="#bfe4f4" opacity="0.9"/>${rep(4, i => `<path d="M${f1(4 + (i + 1) * 2.6)} 6.8V10.8" stroke="#8ab8cc" stroke-width="0.3"/>`).join('')}<path d="M21 11.4Q20.4 6.8 22.6 5.6L30 5.2Q32 7 31.4 11.4Z" fill="#3fa046"/><text x="26.2" y="9.4" text-anchor="middle" ${FONT} font-size="1.6" fill="#f4f8e0">PEAS</text>${frost(40, 13)}<path d="M6 13l0.6 2.4l0.6 -2.4ZM14 13l0.5 1.8l0.5 -1.8ZM27 13l0.7 3l0.7 -3ZM34 13l0.4 1.6l0.4 -1.6Z" fill="#eef8fc"/>`,
            t: `<rect width="40" height="25" fill="#f4fbff" opacity="0.55"/>${frost(40, 25)}`, r: frost(25, 13) } });
          // dim bulb (flickers)
          const bq = C.P([16, 41.5, -13]); o += sph(C, [16, 41.5, -13], 1.3, '#fff2c0') + `<circle cx="${f1(bq[0])}" cy="${f1(bq[1])}" r="${f1(16 * C.k)}" fill="url(#k28bulb)" opacity="0.6"><animate attributeName="opacity" values="0.6;0.6;0.22;0.6;0.6;0.32;0.6" keyTimes="0;0.7;0.71;0.73;0.86;0.87;1" dur="7s" repeatCount="indefinite"/></circle>`;
        }
        const gasket = `<rect x="${IN - 0.7}" y="${IN - 0.7}" width="${W - 2 * IN + 1.4}" height="${HB - 2 * IN + 1.4}" rx="1.4" fill="none" stroke="#7a7a72" stroke-width="1.3"/>` + rep(12, i => `<circle cx="${f1(IN + (i % 2 ? 1 : W - 2 * IN - 1))}" cy="${f1(HB - IN - 1 - (i >> 1) * 0.7)}" r="0.3" fill="#2a2a24" opacity="0.6"/>`).join('');
        const bod = body({ hole: { f: [IN, IN, IN, IN] }, dec: { r: use(PF + 'r'), l: sL, b: sB, t: sT, f: gasket } }), fr = swing(C, DO, 128, 11, 0.8, 11);
        s += feet + (fv ? o + bod + fr : fr + bod) + top;
        if (fv) s += PLN(C, [0, 0.06, ZF + 14], [1, 0, 0], [0, 0, 1], `<ellipse rx="22" ry="11" fill="url(#k28spW)" opacity="0.5"/>`) + mist(C, 0, FT + 24, ZF + 2, 3, 0.6);
      }
      if (bv) s += cord;
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-035 COMPACT WHITE TOP-FREEZER APARTMENT FRIDGE =======================
  // warm white enamel, chrome "Chillmate" script, crayon drawing + letter magnets on the freezer, grocery list with a swinging pencil, beach postcard, coupons in a clip,
  // fruit magnets, gold-star certificate, gingham towel swaying on the handle, oven mitt on a side hook, calendar; cereal box, bread rolls in a basket and a pothos
  // trailing over the front on top. Open: clean white liner, crisper drawers (lettuce, carrots, tomatoes), 3 glass shelves of food, warm bulb, door bins with bottles + eggs.
  N.topf28 = S => { const open = isPlay(S), BC = '#f4f1e9', W = 68, HB = 140, Z0 = -29, ZF = 25, DT = 4, PF = 'k28t_', FY = 7, FH = 88.6, ZY = 97, ZH = 42.4;
    const D = { w: 70, d: 60, arch: 'fridge', act: 'snack', use: { x: 0, z: 62 }, build: () => [] };
    const R = rng('topf28');
    // freezer door
    let zF = `<text x="5" y="8" font-family="'Brush Script MT','Segoe Script','Snell Roundhand',cursive" font-style="italic" font-size="5" fill="url(#k28chr)" stroke="#8a9096" stroke-width="0.15">Chillmate</text>`;
    zF += G(`<rect x="0.5" y="0.6" width="20" height="15" fill="#000000" opacity="0.12"/><rect width="20" height="15" fill="#fdfcf8"/><circle cx="16" cy="3.6" r="2.2" fill="#f6c83a"/>${rep(8, i => { const a = i * PI / 4; return `<path d="M${f1(16 + Math.cos(a) * 2.8)} ${f1(3.6 + Math.sin(a) * 2.8)}l${f1(Math.cos(a) * 1.3)} ${f1(Math.sin(a) * 1.3)}" stroke="#f0a830" stroke-width="0.4" stroke-linecap="round"/>`; }).join('')}`
      + `<path d="M0.4 12.6Q5 11.6 10 12.4T19.6 12.2V14.6H0.4Z" fill="#6ac04a"/><path d="M3 12.4V7.6L6.2 5L9.4 7.6V12.4Z" fill="#e86a5a" stroke="#a83a2a" stroke-width="0.25"/><rect x="5.4" y="9.4" width="1.6" height="3" fill="#7a4a2a"/><path d="M11.6 12.6Q11 8.6 13.6 8.4Q16.4 8.4 15.8 12.6Z" fill="#f2a0c8"/><circle cx="13" cy="10" r="0.4" fill="#2a2a3a"/><circle cx="14.6" cy="10" r="0.4" fill="#2a2a3a"/><path d="M13.2 11.1q0.6 0.5 1.2 0" stroke="#2a2a3a" stroke-width="0.25" fill="none"/>`
      + `<text x="6" y="3.6" text-anchor="middle" ${HANDW} font-size="2.2" fill="#8a4ac8">I ♥ MOM</text>${mag(2, 1, 1.3, '#d83a3a')}${mag(18.4, 1.2, 1.3, '#3a6ad8')}`, 31, 9, 4);
    zF += [['H', '#e84a3a', 8], ['I', '#3a9ad8', 12.4], ['!', '#f2c030', 15.4]].map(([c, col, x], i) => `<text x="${x + 0.3}" y="${f1(28.4 + i * 0.6)}" ${FONT} font-size="5" fill="#000000" opacity="0.15">${c}</text><text x="${x}" y="${f1(28 + i * 0.6)}" ${FONT} font-size="5" fill="${col}" transform="rotate(${[-8, 5, 12][i]} ${x + 1} 26)">${c}</text>`).join('');
    zF += G(`<circle cx="0.3" cy="0.4" r="3.6" fill="#000000" opacity="0.15"/><circle r="3.6" fill="#c8302a"/><circle r="2.9" fill="#f8f2e2"/><text x="0" y="-0.3" text-anchor="middle" ${FONT} font-size="1.3" fill="#c8302a">PIZZA</text><text x="0" y="1.2" text-anchor="middle" ${FONT} font-size="1.3" fill="#c8302a">PAL</text><text x="0" y="2.4" text-anchor="middle" font-family="Arial" font-size="0.7" fill="#5a5a5a">555-0123</text>`, 56, 31);
    zF += rep(4, i => fp(60 + R() * 4, 22 + i * 4.4, 0.9, R() * 30, 0.08)).join('') + `<path d="M0.4 41.6Q2.6 40.6 3.4 42.4" stroke="#3a3a3a" stroke-width="0.4" fill="none" opacity="0.5"/><circle cx="1.6" cy="41.4" r="0.6" fill="#6a4a2a" opacity="0.5"/>`;
    // fridge door
    let fF = G(`<rect x="0.5" y="0.6" width="13" height="19" fill="#000000" opacity="0.12"/><rect width="13" height="3" rx="0.5" fill="#4aa86a"/><text x="6.5" y="2.2" text-anchor="middle" ${FONT} font-size="1.6" fill="#ffffff">GROCERIES</text><rect y="3" width="13" height="16" fill="#fdfbf2"/>`
      + rep(6, i => `<path d="M0.6 ${f1(5.4 + i * 2.4)}H12.4" stroke="#9ac0e0" stroke-width="0.2"/>`).join('') + ['milk', 'eggs', 'bread', 'honey ✓', 'CAKE!!'].map((t, i) => `<text x="1.2" y="${f1(5 + i * 2.4)}" ${HANDW} font-size="1.7" fill="${i === 4 ? '#d83a6a' : '#2a3a7a'}">${t}</text>`).join('') + `<path d="M1 12.4H8" stroke="#2a3a7a" stroke-width="0.25"/>`
      + `<g>${at('rotate', '-7 1.4 19;7 1.4 19;-7 1.4 19', 5, 0, SPL(2))}<path d="M1.4 19V29" stroke="#ece4d0" stroke-width="0.25"/><g transform="translate(1.4 29) rotate(8)"><rect x="-0.55" y="0" width="1.1" height="8" fill="#f2c62a"/><path d="M-0.55 8L0 9.6L0.55 8Z" fill="#e8c8a0"/><path d="M-0.2 9.1L0 9.6L0.2 9.1Z" fill="#3a3a3a"/><rect x="-0.55" y="-1.2" width="1.1" height="1.2" fill="#f28aa0"/><rect x="-0.55" y="-0.2" width="1.1" height="0.4" fill="#c8ccd0"/></g></g>`, 6, 8);
    fF += G(`<rect x="0.5" y="0.6" width="17" height="11" fill="#000000" opacity="0.13"/><rect width="17" height="11" fill="#fdfcf6"/><rect x="0.6" y="0.6" width="15.8" height="5.8" fill="#7ac8f0"/><rect x="0.6" y="6.4" width="15.8" height="2" fill="#3a8ac8"/><rect x="0.6" y="8.4" width="15.8" height="2" fill="#f2dca0"/><circle cx="13" cy="2.6" r="1.4" fill="#fff2a0"/><path d="M4 8.6Q4.4 5 5.6 3.4M5.6 3.4Q3.6 3 2.6 4M5.6 3.4Q7.4 2.8 8 4.2M5.6 3.4Q5 1.8 3.8 1.8" stroke="#4a7a2a" stroke-width="0.4" fill="none"/><text x="8.5" y="10.1" text-anchor="middle" ${HANDW} font-size="1.2" fill="#c8402a">Greetings from Squish Bay</text>`
      + `<path d="M8.5 -1.8l0.6 1.2 1.3 0.1 -1 0.9 0.4 1.3 -1.3 -0.7 -1.2 0.7 0.4 -1.3 -1 -0.9 1.3 -0.1Z" fill="#f28a5a" stroke="#c8603a" stroke-width="0.15"/>`, 27, 7, -4);
    fF += G(`<path d="M0 0L6 0L6 2.4L0 2.4Z" fill="url(#k28chr)"/><path d="M0.6 2.4L5.4 2.4L5 3.4L1 3.4Z" fill="#9aa0a6"/>` + [[-7, '#fff6d0'], [6, '#e8f4ff']].map(([r, c]) => `<g transform="rotate(${r} 3 3)"><rect x="-2" y="2.6" width="10" height="14" fill="${c}" stroke="#9a9a8a" stroke-width="0.25" stroke-dasharray="0.8 0.5"/><text x="3" y="7" text-anchor="middle" ${FONT} font-size="2.4" fill="#c8302a">50¢</text><text x="3" y="9.4" text-anchor="middle" ${FONT} font-size="1.2" fill="#3a3a3a">OFF</text><rect x="-0.6" y="11" width="7.2" height="3" fill="#3a3a3a" opacity="0.5"/></g>`).join(''), 47, 12);
    fF += G(`<path d="M0 -2C-2 -2 -2.6 0.6 -1.4 2.6Q0 4.4 1.4 2.6C2.6 0.6 2 -2 0 -2Z" fill="#e83a4a"/><path d="M-1.4 -2.2Q0 -3.4 1.4 -2.2Q0 -1.6 -1.4 -2.2Z" fill="#4aa83a"/>${rep(6, i => `<circle cx="${f1(-1 + (i % 3) * 1)}" cy="${f1(-0.4 + Math.floor(i / 3) * 1.6)}" r="0.18" fill="#f8e070"/>`).join('')}`, 24, 31, -10)
      + G(`<path d="M-3 0Q0 3.6 3.4 -0.6Q0 1.6 -3 0Z" fill="#f2d040" stroke="#b8962a" stroke-width="0.2"/><path d="M3.4 -0.6l0.6 -0.5" stroke="#6a4a2a" stroke-width="0.4"/>`, 37, 34, 15)
      + G(`<ellipse rx="2.2" ry="1.6" fill="#f6e040"/><ellipse cx="-0.6" cy="-0.5" rx="0.7" ry="0.4" fill="#ffffff" opacity="0.6"/>`, 13, 37);
    fF += G(`<rect x="0.5" y="0.6" width="17" height="12" fill="#000000" opacity="0.12"/><rect width="17" height="12" fill="#fffdf4"/><rect x="0.6" y="0.6" width="15.8" height="10.8" fill="none" stroke="#3a7ac8" stroke-width="0.5"/><text x="8.5" y="4" text-anchor="middle" font-family="Georgia,serif" font-weight="700" font-size="2" fill="#3a5a9a">STAR READER</text><text x="8.5" y="6.6" text-anchor="middle" ${HANDW} font-size="1.6" fill="#2a2a3a">Kiko Squish</text><path d="M3 9H8" stroke="#3a3a3a" stroke-width="0.2"/>`
      + `<path d="M13 6.6l0.9 1.9 2 0.2 -1.5 1.3 0.5 2 -1.9 -1.1 -1.8 1.1 0.5 -2 -1.5 -1.3 2 -0.2Z" fill="#f2c030" stroke="#c8902a" stroke-width="0.2"/>${mag(8.5, 0.3, 1.2, '#4ab06a')}`, 6, 45, 3);
    fF += rep(5, i => fp(59 + R() * 5, 4 + i * 5, 0.9, R() * 30, 0.08)).join('') + scr(R, 8, 4, 80, 60, 7, '#8a8678', 0.35) + `<path d="M1.2 85.6Q2.4 84.6 3.6 86.2Q2.6 87.4 1.4 86.8Z" fill="#3a3a38" opacity="0.7"/><circle cx="2.4" cy="85.9" r="1.6" fill="#a8642e" opacity="0.18"/>`;
    // door liner (fridge door back; u from the free edge)
    const lin = (w, h) => `<rect x="1.6" y="1.6" width="${f1(w - 3.2)}" height="${f1(h - 3.2)}" rx="1.6" fill="#f2f1ec"/><rect x="1.6" y="1.6" width="${f1(w - 3.2)}" height="${f1(h - 3.2)}" rx="1.6" fill="url(#k28lin)"/><rect x="1.6" y="1.6" width="${f1(w - 3.2)}" height="${f1(h - 3.2)}" rx="1.6" fill="none" stroke="#d8d4c8" stroke-width="1.8"/><rect x="2.8" y="2.8" width="${f1(w - 5.6)}" height="${f1(h - 5.6)}" rx="1.2" fill="none" stroke="#ffffff" stroke-opacity="0.6" stroke-width="0.4"/><path d="M2 ${f1(h - 2.4)}H${f1(w - 2)}" stroke="#d8c890" stroke-opacity="0.5" stroke-width="0.8"/>`;
    let sR = G(`<path d="M-1.6 0A1.6 1.6 0 0 1 1.6 0" stroke="#9aa0a6" stroke-width="0.6" fill="none"/><rect x="-1.4" y="-1.6" width="2.8" height="1.2" rx="0.4" fill="url(#k28chr)"/><g>${at('rotate', '-4 0 0.6;4 0 0.6;-4 0 0.6', 6.5, -1, SPL(2))}<path d="M0 0.6V2.4" stroke="#e8d8b8" stroke-width="0.4"/><path d="M-4 2.4H4V12Q4 17 0 17Q-4 17 -4 12Z" fill="#d84a3a"/><path d="M-4 2.4H4V12Q4 17 0 17Q-4 17 -4 12Z" fill="url(#k28wv)"/>${rep(5, i => `<path d="M-4 ${f1(4.4 + i * 2.6)}H4" stroke="#a8302a" stroke-width="0.25"/>`).join('')}<path d="M4 8Q7 8 6.6 11.4Q6.2 13.4 4 13" fill="#d84a3a" stroke="#a8302a" stroke-width="0.25"/><rect x="-4.3" y="1.6" width="8.6" height="2.4" rx="0.6" fill="#f6f0e4"/></g>`, 15, 44);
    sR += G(`<rect x="0.5" y="0.6" width="22" height="30" fill="#000000" opacity="0.1"/><rect width="22" height="30" fill="#fdfcf6"/><rect x="1" y="1" width="20" height="11" fill="#bfe0f0"/><circle cx="7" cy="8" r="3" fill="#f2a0c8"/><circle cx="6" cy="7.4" r="0.4" fill="#2a2a3a"/><circle cx="8" cy="7.4" r="0.4" fill="#2a2a3a"/><circle cx="14.6" cy="8.4" r="2.6" fill="#f6d050"/><path d="M1 10Q11 8 21 10.4V12H1Z" fill="#8ad06a"/><text x="11" y="14.8" text-anchor="middle" ${FONT} font-size="1.8" fill="#3a3a3a">NOVEMBER</text>`
      + rep(35, i => `<rect x="${f1(1.4 + (i % 7) * 2.75)}" y="${f1(16 + Math.floor(i / 7) * 2.6)}" width="2.5" height="2.3" fill="none" stroke="#c8c4b8" stroke-width="0.15"/>`).join('') + [3, 9, 17].map(i => `<path d="M${f1(1.6 + (i % 7) * 2.75)} ${f1(16.3 + Math.floor(i / 7) * 2.6)}l2 1.7M${f1(3.6 + (i % 7) * 2.75)} ${f1(16.3 + Math.floor(i / 7) * 2.6)}l-2 1.7" stroke="#d83a3a" stroke-width="0.3"/>`).join('') + `<circle cx="${f1(1.4 + 4 * 2.75 + 1.2)}" cy="${f1(16 + 3 * 2.6 + 1.1)}" r="1.4" fill="none" stroke="#3a6ad8" stroke-width="0.3"/>`, 26, 62, 1);
    sR += G(`<rect x="0.4" y="0.5" width="12" height="16" fill="#000000" opacity="0.1"/><rect width="12" height="16" fill="#f6efe0"/><rect width="12" height="3.4" fill="#2a7a3a"/><text x="6" y="2.5" text-anchor="middle" ${FONT} font-size="1.8" fill="#ffffff">GOLDEN WOK</text>${rep(6, i => `<path d="M1.2 ${f1(5.4 + i * 1.7)}h${f1(6 + (i % 3))}" stroke="#7a6a5a" stroke-width="0.3"/>`).join('')}${mag(6, 0.4, 1.1, '#f2c030')}`, 6, 92, -3);
    sR += scr(R, 10, 2, 120, 48, 18, '#9a9488', 0.3);
    let sL = scr(R, 8, 3, 110, 48, 28, '#9a9488', 0.25) + `<rect x="0" y="126" width="54" height="14" fill="url(#m10in)" opacity="0.25"/>`;
    let sB = `<rect x="8" y="10" width="52" height="110" rx="1" fill="#26241f"/>` + rep(13, i => `<path d="M11 ${18 + i * 8}H57" stroke="#46423a" stroke-width="1.6"/><path d="M11 ${17.4 + i * 8}H57" stroke="#7a756a" stroke-width="0.3"/>`).join('') + rep(11, i => `<path d="M${f1(12 + i * 4.4)} 12V118" stroke="#2e2b26" stroke-width="0.35"/>`).join('')
      + `<rect x="22" y="124" width="24" height="8" rx="0.4" fill="url(#k28chr)"/><text x="34" y="127.4" text-anchor="middle" font-family="Arial" font-size="1.7" fill="#3a3c40">CHILLMATE TF-10 · 115V</text><text x="34" y="130.2" text-anchor="middle" font-family="Arial" font-size="1.7" fill="#3a3c40">10.1 CU FT · FROST FREE</text>`;
    let sT = `<rect width="68" height="54" fill="url(#m10noise)"/>` + rep(26, () => `<circle cx="${f1(R() * 68)}" cy="${f1(R() * 54)}" r="${f1(0.15 + R() * 0.3)}" fill="#8a7e66" opacity="0.3"/>`).join('');
    let bF = `<rect x="6" y="133.4" width="56" height="5" rx="0.6" fill="#2a2a28"/>` + rep(14, i => `<rect x="${f1(7.4 + i * 3.9)}" y="134.2" width="2.4" height="3.4" rx="0.4" fill="#0e0e0c"/>`).join('') + `<rect x="0" y="${f1(HB - 97)}" width="${W}" height="1.4" fill="#2a2a26" opacity="0.55"/>`;
    const defs = DEF28 + `<defs>${sym(PF + 'z', zF)}${sym(PF + 'f', fF)}${sym(PF + 'r', sR)}${sym(PF + 'bk', sB)}</defs>`;
    const HU = 62.5, handle = (y1, y2) => (Dh, C) => box3(C, { c: Dh.P(HU, y1 + 0.6, DT + 0.8), ax: Dh.A, w: 2.4, h: 2.4, d: 1.6, r: 0.4, col: '#e8e4da', olw: 0.3 }) + box3(C, { c: Dh.P(HU, y2 - 3, DT + 0.8), ax: Dh.A, w: 2.4, h: 2.4, d: 1.6, r: 0.4, col: '#e8e4da', olw: 0.3 })
      + box3(C, { c: Dh.P(HU, y1, DT + 2.4), ax: Dh.A, w: 3.2, h: y2 - y1, d: 2.4, r: 1, col: '#f6f3ec', gl: 0.5, olw: 0.35, dec: { f: `<rect x="0.9" y="2" width="1.4" height="${f1(y2 - y1 - 4)}" rx="0.7" fill="#c9c4b6"/>` } });
    const towel = (Dh, C) => PLN(C, Dh.P(HU - 4.5, 73, DT + 4.9), Dh.ex, [0, -1, 0], `<g>${at('rotate', '-2.5 4.5 0;2.5 4.5 0;-2.5 4.5 0', 5.5, 0, SPL(2))}<path d="M0 0H9V14.6Q4.5 15.6 0 14.6Z" fill="url(#k28ging)"/><path d="M0 0H9V14.6Q4.5 15.6 0 14.6Z" fill="url(#m10v)"/><path d="M0 1.2H9" stroke="#a8302a" stroke-opacity="0.4" stroke-width="0.3"/><path d="M0 13.4Q4.5 14.4 9 13.4" stroke="#ffffff" stroke-width="0.4" fill="none"/><path d="M2.6 0.4Q3 7 2.2 14.6M6.4 0.4Q6.2 8 6.8 14.8" stroke="#000000" stroke-opacity="0.08" stroke-width="0.8" fill="none"/></g>`);
    const bins = (Dh, C) => { let s = ''; const bin = yb => box3(C, { c: Dh.P(34, yb, -3.4), ax: Dh.A, w: 58, h: 7, d: 6.6, r: 0.6, col: '#f1f1ec', op: 0.82, skip: { t: 1 }, olw: 0.35, dec: { b: '<path d="M1 0.6H57" stroke="#ffffff" stroke-width="0.5"/>' } }), q = (u, y) => Dh.P(u, y, -3.4);
      s += box3(C, { c: q(52, 15.4), ax: Dh.A, w: 6, h: 13, d: 5.6, r: 0.2, col: '#f2a030', olw: 0.3, dec: { b: `<rect width="6" height="13" fill="#f2a030"/><circle cx="3" cy="5" r="2" fill="#f6c050"/><text x="3" y="10" text-anchor="middle" ${FONT} font-size="1.3" fill="#ffffff">OJ</text>` } });
      const b1 = q(36, 15.4), b2 = q(28, 15.4), b3 = q(16, 15.4); s += bottle(C, b1[0], b1[1], b1[2], 2.2, 9, '#c8281e', '#f4f2ec') + bottle(C, b2[0], b2[1], b2[2], 2, 8, '#f2c62a', '#c8281e') + bottle(C, b3[0], b3[1], b3[2], 3, 16, '#3a9a4a', '#e8402e', { op: 0.85 });
      s += bin(15);
      [44, 32, 20].forEach((u, i) => { const p = q(u, 39.4); s += jar(C, p[0], p[1], p[2], 2.4, 6, ['#e8d6a0', '#a8202a', '#c8d8a0'][i], ['#f2f0e8', '#d8d0c0', '#3a7a3a'][i]); });
      s += bin(39);
      s += box3(C, { c: q(34, 63.4), ax: Dh.A, w: 22, h: 1.6, d: 5.4, r: 0.4, col: '#f6f4ee', olw: 0.3 }); rep(6, i => { const p = q(25 + i * 3.6, 65.6); s += sph(C, [p[0], p[1] + 0.6, p[2]], 1.5, '#f2e6d2'); });
      s += bin(63); return s; };
    const ZD = { hx: -W / 2, zb: ZF, sg: 1, w: W, h: ZH, t: DT, y0: ZY, col: shade(BC, 1.01), gl: 0.45, r: 2.6, f: 1.16, dec: { f: use(PF + 'z'), b: lin(W, ZH) }, front: handle(99.4, 118) };
    const FD = { hx: -W / 2, zb: ZF, sg: 1, w: W, h: FH, t: DT, y0: FY, col: shade(BC, 1.01), gl: 0.45, r: 2.6, f: 1.16, dec: { f: use(PF + 'f'), b: lin(W, FH) }, front: (Dh, C) => handle(68, 93.4)(Dh, C) + towel(Dh, C), back: bins };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), bv = vis(C, [0, 0, -1]), rv = vis(C, [1, 0, 0]);
      const body = o => box3(C, Object.assign({ c: [0, 0, (Z0 + ZF) / 2], w: W, h: HB, d: ZF - Z0, r: 5, col: BC, gl: 0.35, f: 1.16, dec: { r: use(PF + 'r'), l: sL, b: use(PF + 'bk'), t: sT, f: bF }, olw: 0.55, olo: 0.6 }, o));
      const cord = curve(C, [[20, 12, Z0 - 0.3], [22, 2, Z0 - 4], [30, 0.6, Z0 - 6], [36, 0.7, Z0 - 9]], '#2a2826', 1);
      const TY = HB; let top = shadow(C, -20, -8, 10, 6, 0.4, TY + 0.05) + shadow(C, 2, -2, 11, 8, 0.4, TY + 0.05) + shadow(C, 24, 10, 6, 6, 0.45, TY + 0.05);
      top += box3(C, { c: [-20, TY, -8], ax: yawA(0.22), w: 13, h: 19, d: 5, r: 0.2, col: '#e8402e', olw: 0.35, dec: {
        f: `<rect width="13" height="19" fill="#e8402e"/>${rep(10, i => `<path d="M6.5 13L${f1(6.5 + Math.cos(i * 0.63) * 12)} ${f1(13 + Math.sin(i * 0.63) * 12)}" stroke="#f6c040" stroke-width="0.9" opacity="0.5"/>`).join('')}<text x="6.5" y="4.6" text-anchor="middle" ${FONT} font-size="2.8" fill="#fff4c0" stroke="#a8241e" stroke-width="0.2">SQUISH</text><text x="6.5" y="7.8" text-anchor="middle" ${FONT} font-size="3.2" fill="#f6d040" stroke="#a8241e" stroke-width="0.2">O's</text><path d="M2.4 13.4H10.6Q10 17.4 6.5 17.4Q3 17.4 2.4 13.4Z" fill="#3a7ac8"/>${rep(7, i => `<circle cx="${f1(3.6 + i * 1.0)}" cy="${f1(12.8 - (i % 2) * 0.7)}" r="0.55" fill="none" stroke="#e8a030" stroke-width="0.4"/>`).join('')}`,
        r: `<rect width="5" height="19" fill="#e8402e"/><rect x="0.6" y="3" width="3.8" height="11" fill="#ffffff"/>${rep(8, i => `<path d="M1 ${f1(4.4 + i * 1.2)}H4" stroke="#3a3a3a" stroke-width="0.2"/>`).join('')}`, t: '<rect width="13" height="5" fill="#d8352a"/><path d="M0 2.5H13" stroke="#a8241e" stroke-width="0.3"/>' } });
      top += box3(C, { c: [2, TY, -2], w: 17, h: 5, d: 11, r: 1.6, col: '#c8a060', olw: 0.35, dec: { f: rep(5, i => `<path d="M0 ${f1(0.6 + i)}H17" stroke="#8a6430" stroke-width="0.3"/>`).join('') + rep(12, i => `<path d="M${f1(i * 1.45 + 0.7)} 0V5" stroke="#a87e44" stroke-width="0.25"/>`).join(''), r: rep(5, i => `<path d="M0 ${f1(0.6 + i)}H11" stroke="#8a6430" stroke-width="0.3"/>`).join(''), t: '<rect x="1.4" y="1.4" width="14.2" height="8.2" rx="1" fill="#6a4a22" opacity="0.6"/>' } });
      [[-3, -4.4], [3.6, -1], [8, -4.6], [-1.6, 1.6]].map(([x, z]) => ({ x: x + 2, z: z - 0.4 })).sort((a, b) => a.z - b.z).forEach(b => top += sph(C, [b.x, TY + 5.6, b.z], 2.9, '#d8a058') + PLN(C, [b.x - 1.4, TY + 8.3, b.z], [1, 0, 0], [0, 0, 1], '<path d="M0 -0.5L2.8 0.5M0.4 0.6L2.6 1.3" stroke="#a86a2a" stroke-width="0.3"/>'));
      // pothos: pot + leaves, 2 vines trailing over the front edge (sway)
      const PX = 24, PZ = 10; top += cyl3(C, [PX, TY, PZ], [PX, TY + 5.4, PZ], 4.2, '#c46a3a', { r2: 4.8, mat: 'matte', n: 22, olw: 0.35, noCap: 1 }) + cyl3(C, [PX, TY + 5.4, PZ], [PX, TY + 6.8, PZ], 5.2, '#d0784a', { mat: 'matte', n: 22, olw: 0.35, cap: cr => `<circle r="${f1(cr * 0.85)}" fill="#4a3220"/><circle r="${f1(cr * 0.85)}" fill="url(#m10cap)" opacity="0.5"/>` });
      top += [[-2, 8.6, -1, -30], [2.2, 9.2, 0.6, 25], [0, 10.4, -2, 0], [-2.6, 7.8, 2.4, -60], [2.8, 8, 2.6, 60], [0.4, 9, 3, 10], [-0.6, 11.4, 0.6, -15]].map(([dx, dy, dz, r], i) => leafS(C, [PX + dx, TY + dy, PZ + dz], 1.5, r, i % 2 ? '#4e9a3a' : '#5aa844')).join('');
      const vine = (P, ph) => { const pp = P.map(q => C.P(q)), a0 = pp[0]; let s = `<path d="M${P2(pp[0])}C${P2(pp[1])} ${P2(pp[1])} ${P2(pp[2])}S${P2(pp[3])} ${P2(pp[4])}" stroke="#4a7a2a" stroke-width="${f1(0.4 * C.k)}" fill="none"/>`;
        P.slice(1).forEach((q, i) => s += leafS(C, q, 1.25, (i % 2 ? 30 : -30) + 180, i % 2 ? '#4e9a3a' : '#62b04a'));
        return `<g>${at('rotate', [-1.6, 1.6, -1.6].map(a => a + ' ' + P2(a0)).join(';'), 6 + ph, -ph, SPL(2))}${s}</g>`; };
      const vines = vine([[25, 146, 13], [26.5, 141, 24], [27, 138, 29.6], [27.5, 129, 29.8], [26.8, 120, 29.9]], 0) + vine([[21, 146, 12], [19.6, 140.6, 25], [18.6, 136, 29.6], [17.8, 130.4, 29.8], [18.4, 125, 29.9]], 1.3);
      let s = shadow(C, 0, -1, 40, 34, 0.9);
      if (!bv) s += cord;
      if (!open) { const dz = door(C, ZD, 0), df = door(C, FD, 0); s += fv ? body() + df + dz + top + vines : vines + dz + df + body() + top; }
      else {
        const x0 = -W / 2 + 3, x1 = W / 2 - 3, y0 = 9.4, y1 = 93.6, z0 = Z0 + 3, z1 = ZF; let o = '';
        if (fv) {
          o += cavity(C, x0, x1, y0, y1, z0, z1, '#f6f6f1', { dk: 0.35, back: `<rect x="4" y="2" width="${f1(x1 - x0 - 8)}" height="3" rx="1.4" fill="#e8e8e2"/>${rep(3, i => `<path d="M1 ${f1(22 + i * 23)}H${f1(x1 - x0 - 1)}" stroke="#e0e0da" stroke-width="0.5"/>`).join('')}`,
            left: [22.4, 45.4, 68.4].map(v => `<path d="M2 ${v}H${f1(z1 - z0 - 2)}" stroke="#ffffff" stroke-width="0.6"/><path d="M2 ${v + 0.6}H${f1(z1 - z0 - 2)}" stroke="#d8d8d0" stroke-width="0.4"/>`).join('') });
          // crisper: veg, then the clear drawers
          o += sph(C, [-20, 15, -4], 5.4, '#7ac04a') + sph(C, [-17, 14.4, 2], 4.4, '#8ad05a') + sph(C, [-11, 13.6, 8], 4, '#6ab03a');
          [[-25, 11.2, 10, -15, 11.6, 16], [-26, 11, 4, -16, 11.4, 9]].forEach(([ax, ay, az, bx, by, bz]) => o += cyl3(C, [ax, ay, az], [bx, by, bz], 1.5, '#f0802a', { r2: 0.3, n: 12, olw: 0.25 }) + `<path d="M${P2(C.P([ax, ay, az]))}l${f1(-1.6 * C.k)} ${f1(-1.2 * C.k)}m${f1(1.6 * C.k)} ${f1(1.2 * C.k)}l${f1(-0.6 * C.k)} ${f1(-2 * C.k)}" stroke="#4a9a2a" stroke-width="${f1(0.4 * C.k)}"/>`);
          [[14, 12.2, -10, 2.7, '#d8382a'], [19, 12.4, -2, 2.9, '#e8402e'], [10, 12.6, 6, 3, '#d8382a'], [22, 12.4, 10, 2.8, '#8ac040']].forEach(([x, y, z, r, c]) => o += sph(C, [x, y, z], r, c) + `<circle cx="${f1(C.P([x, y + r * 0.9, z])[0])}" cy="${f1(C.P([x, y + r * 0.9, z])[1])}" r="${f1(0.6 * C.k)}" fill="#3a7a2a"/>`);
          [-1, 1].forEach(sg => o += box3(C, { c: [sg * 15.4, y0 + 0.1, -0.5], w: 29.4, h: 14.2, d: 49, r: 1, col: '#e6f2f4', op: 0.42, olw: 0.35, olc: '#9ab8c0', skip: { t: 1 }, dec: { f: `<rect x="2" y="0.8" width="25.4" height="2.4" rx="1.2" fill="#ffffff" opacity="0.85"/><text x="14.7" y="8.4" text-anchor="middle" ${FONT} font-size="1.8" fill="#7aa0a8" opacity="0.8">CRISPER</text><rect x="${sg > 0 ? 20 : 4}" y="10.6" width="5" height="1.4" rx="0.7" fill="#c8d8dc"/><circle cx="${sg > 0 ? 21.6 : 6.6}" cy="11.3" r="0.8" fill="#7aa0a8"/>` } }));
          o += gshelf(C, x0, x1, 24, z0 + 0.4, z1 - 0.4, '#f8f8f4');
          o += box3(C, { c: [-14, 24.8, -6], w: 18, h: 5.4, d: 13, r: 1.4, col: '#f0ece2', gl: 0.4, olw: 0.35, dec: { t: `<rect x="0.6" y="0.6" width="16.8" height="11.8" rx="1" fill="#c8ced4"/>${rep(9, () => `<path d="M${f1(1 + R() * 15)} ${f1(1 + R() * 10)}l${f1(R() * 4 - 2)} ${f1(R() * 3)}" stroke="#ffffff" stroke-width="0.4" opacity="0.8"/><path d="M${f1(1 + R() * 15)} ${f1(1 + R() * 10)}l${f1(R() * 4 - 2)} ${f1(R() * 3)}" stroke="#8a9298" stroke-width="0.3" opacity="0.6"/>`).join('')}` , f: '<rect x="1" y="0.6" width="16" height="1.4" fill="#c8ced4"/>' } });
          o += cyl3(C, [12, 25.2, -4], [12, 34.6, -4], 3.9, '#f2a030', { n: 22, mat: 'matte', olw: 0.2 }) + cyl3(C, [12, 24.8, -4], [12, 38.8, -4], 4.4, '#eaf6f6', { n: 22, op: 0.35, mat: 'gloss', olw: 0.35, olc: '#8aa0a4' }) + PLN(C, [16.4, 36, -4], [1, 0, 0], [0, -1, 0], '<path d="M0 0Q3.2 0 3.2 3.6Q3.2 7.4 0 7.4" stroke="#dceeee" stroke-width="1" fill="none" opacity="0.8"/>');
          o += box3(C, { c: [22, 24.8, 12], w: 7, h: 3.4, d: 6, r: 0.8, col: '#eef2f2', op: 0.9, olw: 0.3 }) + box3(C, { c: [22, 28.2, 12], w: 7.4, h: 0.9, d: 6.4, r: 0.8, col: '#d8402e', olw: 0.3 });
          o += gshelf(C, x0, x1, 49, z0 + 0.4, z1 - 0.4, '#f8f8f4');
          o += box3(C, { c: [-20, 49.8, -8], w: 8, h: 14, d: 8, r: 2.4, col: '#f8f8f6', gl: 0.4, olw: 0.35, dec: { f: `<rect x="1" y="4" width="6" height="5" rx="0.6" fill="#3a7ac8"/><text x="4" y="7.4" text-anchor="middle" ${FONT} font-size="1.7" fill="#ffffff">MILK</text><ellipse cx="2.4" cy="10.6" rx="1" ry="0.7" fill="#2a2a2a" opacity="0.6"/><ellipse cx="5.4" cy="11.6" rx="0.8" ry="0.6" fill="#2a2a2a" opacity="0.6"/>` } }) + cyl3(C, [-18.6, 63.8, -8], [-18.6, 65.4, -8], 1.5, '#2a6ac8', { n: 14, olw: 0.3 });
          o += cyl3(C, [4, 49.8, -2], [4, 50.5, -2], 8, '#ffffff', { n: 28, olw: 0.3 }) + cyl3(C, [4, 50.5, -2], [4, 56.5, -2], 6, '#f2a6b8', { n: 28, olw: 0.35, capCol: '#fdf6f4', cap: cr => rep(8, i => `<circle cx="${f1(Math.cos(i * 0.785) * cr * 0.8)}" cy="${f1(Math.sin(i * 0.785) * cr * 0.8)}" r="${f1(cr * 0.12)}" fill="#ffffff" stroke="#f0d0d8" stroke-width="0.15"/>`).join('') })
            + `<g transform="${tanF(C, 4, -2, 6.02, C.thV, 53.5)}"><path d="M-6 0Q-4.5 1 -3 0T0 0T3 0T6 0" stroke="#ffffff" stroke-width="0.7" fill="none"/></g>` + sph(C, [4, 58, -2], 1.6, '#d8283a');
          o += box3(C, { c: [20, 49.8, 6], w: 10, h: 4, d: 8, r: 0.8, col: '#eef2f2', op: 0.9, olw: 0.3 }) + box3(C, { c: [20, 53.8, 6], w: 10.4, h: 1, d: 8.4, r: 0.8, col: '#d8402e', olw: 0.3 }) + box3(C, { c: [20, 54.8, 6], w: 9, h: 3.4, d: 7, r: 0.8, col: '#eef2f2', op: 0.9, olw: 0.3 }) + box3(C, { c: [20, 58.2, 6], w: 9.4, h: 0.9, d: 7.4, r: 0.8, col: '#3a7ac8', olw: 0.3 });
          // light housing + thermostat + warm bulb
          o += box3(C, { c: [0, 87.4, -19], w: 18, h: 5, d: 9, r: 1, col: '#f2f2ee', gl: 0.3, olw: 0.35, dec: { f: '<rect x="1.4" y="1.4" width="8" height="2.2" rx="1" fill="#fff8dc" opacity="0.9"/>' } }) + cyl3(C, [5.4, 89.9, -14.5], [5.4, 89.9, -13.4], 1.6, '#e8e6e0', { n: 18, olw: 0.3, cap: cr => rep(7, i => `<path d="M0 ${f1(-cr * 0.7)}V${f1(-cr * 0.95)}" stroke="#7a7a72" stroke-width="0.15" transform="rotate(${i * 40 - 120})"/>`).join('') + `<path d="M0 0L0 ${f1(-cr * 0.6)}" stroke="#c8302a" stroke-width="0.35" transform="rotate(40)"/>` });
          { const bq = C.P([-4, 86.4, -17]); o += sph(C, [-4, 86.4, -17], 1.4, '#fff4cc') + `<circle cx="${f1(bq[0])}" cy="${f1(bq[1])}" r="${f1(26 * C.k)}" fill="url(#k28bulb)" opacity="0.55"/>`; }
          o += gshelf(C, x0, x1, 72, z0 + 0.4, z1 - 0.4, '#f8f8f4');
          o += jar(C, -19, 72.8, -10, 4, 10, '#7aa040', '#c8a040', 0.86, `<rect x="-2.8" y="-1.6" width="5.6" height="3.2" fill="#f6eed0"/><text x="0" y="0.6" text-anchor="middle" ${FONT} font-size="1.1" fill="#4a7a2a">PICKLES</text>`);
          o += jar(C, 16, 72.8, -6, 3, 7, '#a8202a', '#e8dcc8', 0.8, `<rect x="-2" y="-1.2" width="4" height="2.4" fill="#ffffff"/><text x="0" y="0.5" text-anchor="middle" ${HANDW} font-size="1" fill="#a8202a">jam</text>`);
          [[-6, '#f28ab0'], [-1, '#f6d040'], [4, '#a88ad8']].forEach(([x, c]) => o += cup(C, x, 72.8, 2, 2.6, 4.6, '#f8f6f0', c));
          o += box3(C, { c: [24, 72.8, 8], w: 7, h: 3, d: 5, r: 0.6, col: '#f2c84a', gl: 0.3, olw: 0.3, dec: { f: '<rect width="7" height="3" fill="#f2c84a"/><circle cx="2" cy="1.5" r="0.5" fill="#d8a830"/><circle cx="4.6" cy="1" r="0.4" fill="#d8a830"/>' } });
          o += PLN(C, [x0 + 0.2, y1 - 0.2, z1 - 0.1], [1, 0, 0], [0, -1, 0], `<rect width="${f1(x1 - x0 - 0.4)}" height="${f1(y1 - y0)}" fill="url(#k28spW)" opacity="0.25"/>`);
        }
        const gasket = `<rect x="2.3" y="${f1(HB - 93.6 - 0.7)}" width="${W - 4.6}" height="${f1(93.6 - 9.4 + 1.4)}" rx="1.6" fill="none" stroke="#e2ded2" stroke-width="1.6"/>`;
        const bod = body({ hole: { f: [3, HB - 93.6, 3, 9.4] }, dec: { r: use(PF + 'r'), l: sL, b: use(PF + 'bk'), t: sT, f: bF + gasket } }), fr = swing(C, FD, 128, 11, 0.85), dz = door(C, ZD, 0);
        s += fv ? o + bod + dz + fr + top + vines : vines + fr + dz + bod + top;
        if (fv) s += PLN(C, [0, 0.06, ZF + 18], [1, 0, 0], [0, 0, 1], `<ellipse rx="32" ry="16" fill="url(#k28spW)" opacity="0.6"/>`) + mist(C, 0, 30, ZF + 3, 3, 0.8);
      }
      if (bv) s += cord;
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-055 BRUSHED STAINLESS FRENCH-DOOR FRIDGE WITH ICE DISPENSER =======================
  // brushed stainless with soft reflections, 2 French doors over a freezer drawer, long tubular bar pulls on standoffs, recessed ice + water dispenser with an LED
  // tray light and a display (37° / 0°), an ice cube drops every 15 s, a drip falls from the paddle; glass canisters + a eucalyptus vase on top.
  // Open: the right door swings out, bright LED interior, deli drawer, glass shelves with stainless trims, grapes, cheesecake, sparkling water, lemon water, door bins.
  N.french28 = S => { const open = isPlay(S), SS = '#c3c7cb', SD = '#b6babe', W = 82, HB = 150, Z0 = -31, ZF = 27, DT = 4, PF = 'k28f_', DY = 56, DH = 93.6, DW = 40.7, ZY0 = 6.5, ZH = 48.5;
    const D = { w: 84, d: 60, arch: 'fridge', act: 'snack', use: { x: 0, z: 62 }, build: () => [] };
    const R = rng('french28');
    const brushed = (w, h, refl) => `<rect width="${f1(w)}" height="${f1(h)}" fill="url(#k28br)"/>` + (refl ? `<rect width="${f1(w)}" height="${f1(h)}" fill="url(#k28ss)"/>` : '');
    // left door: display + dispenser recess
    let lF = brushed(DW, DH, 1);
    lF += `<rect x="8" y="13.4" width="24" height="7.6" rx="1.2" fill="#0e1013"/><rect x="8" y="13.4" width="24" height="3" rx="1.2" fill="#ffffff" opacity="0.06"/><text x="15" y="19" text-anchor="middle" ${FONT} font-size="4" fill="#e8f4ff">37°</text><text x="27" y="19" text-anchor="middle" ${FONT} font-size="3" fill="#e8f4ff">0°</text>`
      + `<text x="15" y="15.4" text-anchor="middle" font-family="Arial" font-size="0.9" fill="#7aa8c8">FRIDGE</text><text x="27" y="15.4" text-anchor="middle" font-family="Arial" font-size="0.9" fill="#7aa8c8">FREEZER</text><rect x="20.6" y="15.8" width="1.4" height="1.4" fill="none" stroke="#9ad0f0" stroke-width="0.2"/><rect x="21.2" y="17.2" width="1.4" height="1.4" fill="none" stroke="#9ad0f0" stroke-width="0.2"/>`
      + `<path d="M21.4 19.2q0.5 0.8 0 1.3q-0.5 -0.5 0 -1.3Z" fill="#7ac8f0"><animate attributeName="opacity" values="0.5;1;0.5" dur="6s" repeatCount="indefinite"/></path>`;
    lF += `<rect x="9" y="25" width="22" height="41" rx="2.4" fill="url(#k28rec)"/><rect x="9" y="25" width="22" height="41" rx="2.4" fill="none" stroke="#8a9096" stroke-width="0.5"/><rect x="9.5" y="25.5" width="21" height="3" rx="2" fill="#000000" opacity="0.4"/>`
      + `<ellipse cx="20" cy="27.4" rx="8" ry="2.4" fill="url(#k28led)" opacity="0.7"/><rect x="16.4" y="27.4" width="7.2" height="2.6" rx="0.8" fill="#050607"/><rect x="14" y="31" width="12" height="13" rx="2" fill="url(#k28pad)"/><rect x="14" y="31" width="12" height="2" rx="1" fill="#ffffff" opacity="0.25"/><path d="M15 43.4H25" stroke="#3a3e42" stroke-width="0.4"/>`
      + `<rect x="11" y="60" width="18" height="4.6" rx="1" fill="#2a2d31"/>${rep(9, i => `<path d="M${f1(12.2 + i * 1.95)} 60.6V64" stroke="#6a7076" stroke-width="0.5"/>`).join('')}<ellipse cx="17" cy="62.2" rx="2.4" ry="0.5" fill="#9ac4d8" opacity="0.3"/>`
      + `<rect x="19.2" y="0" width="1.6" height="1.6" rx="0.3" fill="#eaf6fc" stroke="#9ac4d8" stroke-width="0.15" opacity="0"><animate attributeName="y" values="28.4;28.4;58.4;58.4" keyTimes="0;0.9;0.96;1" calcMode="spline" keySplines="0 0 1 1;0.5 0 1 1;0 0 1 1" dur="15s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0;1;1;0;0" keyTimes="0;0.9;0.902;0.97;0.99;1" dur="15s" repeatCount="indefinite"/></rect>`
      + `<ellipse cx="20" cy="44" rx="0.45" ry="0.6" fill="#cfe8f4" opacity="0"><animate attributeName="cy" values="44;44;44.4;59.6;59.6" keyTimes="0;0.6;0.72;0.78;1" dur="11s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.9;0.9;0;0" keyTimes="0;0.6;0.77;0.78;1" dur="11s" repeatCount="indefinite"/></ellipse>`;
    lF += rep(4, i => fp(34 + R() * 3, 30 + i * 9, 0.9, R() * 30, 0.06)).join('');
    let rF = brushed(DW, DH, 1) + rep(3, i => fp(5 + R() * 3, 36 + i * 9, 0.9, R() * 30, 0.05)).join('');
    let dF = brushed(W, ZH, 1) + `<text x="41" y="44" text-anchor="middle" ${FONT} font-size="2.2" fill="#5a6066" letter-spacing="1.2">POLAR·PRO</text>`;
    let bF = `<rect x="8" y="${f1(HB - 6.3)}" width="66" height="5.6" rx="0.6" fill="#1e2022"/>` + rep(16, i => `<rect x="${f1(9.4 + i * 4)}" y="${f1(HB - 5.6)}" width="2.6" height="4.2" rx="0.4" fill="#0a0b0c"/>`).join('')
      + `<rect x="0" y="${f1(HB - DY - 0.6)}" width="${W}" height="1.6" fill="#1a1c1e" opacity="0.7"/>`; const bMid = `<rect x="${f1(W / 2 - 0.5)}" y="0" width="1" height="${f1(HB - DY)}" fill="#1a1c1e" opacity="0.7"/>`;
    let sR = brushed(58, HB, 0) + `<rect width="58" height="${HB}" fill="url(#m10v)"/>`, sL = sR;
    let sB = `<rect x="10" y="10" width="62" height="118" rx="1" fill="#26241f"/>` + rep(14, i => `<path d="M13 ${18 + i * 8}H69" stroke="#46423a" stroke-width="1.6"/>`).join('') + `<rect x="28" y="132" width="26" height="8" rx="0.4" fill="url(#k28chr)"/><text x="41" y="135.4" text-anchor="middle" font-family="Arial" font-size="1.7" fill="#3a3c40">POLAR·PRO FD-25 · 115V</text><text x="41" y="138.2" text-anchor="middle" font-family="Arial" font-size="1.7" fill="#3a3c40">25 CU FT · ICE + WATER</text>`;
    let sT = `<rect width="82" height="58" fill="#b9bdc1" opacity="0.4"/>` + rep(20, () => `<circle cx="${f1(R() * 82)}" cy="${f1(R() * 58)}" r="${f1(0.15 + R() * 0.3)}" fill="#7a7e82" opacity="0.3"/>`).join('');
    const lin = (w, h) => `<rect x="1.4" y="1.4" width="${f1(w - 2.8)}" height="${f1(h - 2.8)}" rx="1.4" fill="#eef0f1"/><rect x="1.4" y="1.4" width="${f1(w - 2.8)}" height="${f1(h - 2.8)}" rx="1.4" fill="url(#k28lin)"/><rect x="1.4" y="1.4" width="${f1(w - 2.8)}" height="${f1(h - 2.8)}" rx="1.4" fill="none" stroke="#c8ccd0" stroke-width="1.6"/>`;
    const defs = DEF28 + `<defs>${sym(PF + 'l', lF)}${sym(PF + 'r', rF)}${sym(PF + 'd', dF)}${sym(PF + 'sr', sR)}</defs>`;
    const bar = (C, a, b) => cyl3(C, a, b, 1.3, '#d8dcdf', { mat: 'chrome', n: 16, olw: 0.3 });
    const pull = u => (Dh, C) => { const s0 = cyl3(C, Dh.P(u, 74, DT), Dh.P(u, 74, DT + 4.4), 0.9, '#c8ccd0', { mat: 'chrome', n: 12, olw: 0.3 }) + cyl3(C, Dh.P(u, 134, DT), Dh.P(u, 134, DT + 4.4), 0.9, '#c8ccd0', { mat: 'chrome', n: 12, olw: 0.3 }); return s0 + bar(C, Dh.P(u, 71, DT + 4.6), Dh.P(u, 137, DT + 4.6)); };
    const bins = (Dh, C) => { let s = ''; const q = (u, y) => Dh.P(u, y, -3.4), bin = yb => box3(C, { c: Dh.P(DW / 2, yb, -3.4), ax: Dh.A, w: DW - 7, h: 6.4, d: 6.4, r: 0.5, col: '#e8f2f4', op: 0.55, skip: { t: 1 }, olw: 0.35, olc: '#8aa8b0', dec: { b: `<rect x="0.6" y="0.4" width="${f1(DW - 8.2)}" height="1.4" fill="#c8ccd0"/>` } });
      s += box3(C, { c: q(10, 66.4), ax: Dh.A, w: 6, h: 13, d: 5.6, r: 0.2, col: '#f2a030', olw: 0.3, dec: { b: `<rect width="6" height="13" fill="#f2a030"/><circle cx="3" cy="5" r="2" fill="#f6c050"/><text x="3" y="10" text-anchor="middle" ${FONT} font-size="1.2" fill="#ffffff">OJ</text>` } });
      { const p = q(20, 66.4), p2 = q(30, 66.4); s += bottle(C, p[0], p[1], p[2], 2.6, 15, '#f6f6f2', '#2a6ac8', { op: 0.9 }) + bottle(C, p2[0], p2[1], p2[2], 2.6, 19, '#2a4a2a', '#c8a040', { lbl: `<rect x="-2" y="-1.6" width="4" height="3.2" fill="#f2ead0"/><text x="0" y="0.4" text-anchor="middle" font-family="Georgia,serif" font-size="0.9" fill="#5a2a2a">Rosé</text>` }); }
      s += bin(66);
      { const p = q(13, 92.4); s += box3(C, { c: p, ax: Dh.A, w: 9, h: 3.6, d: 5, r: 0.6, col: '#f6f4ee', olw: 0.3 }) + box3(C, { c: add(p, [0, 3.6, 0]), ax: Dh.A, w: 9.4, h: 1.4, d: 5.4, r: 0.6, col: '#f2e6c0', olw: 0.3 }); }
      [24, 30].forEach((u, i) => { const p = q(u, 92.4); s += bottle(C, p[0], p[1], p[2], 1.8, 9, ['#e8d6a0', '#8a3a2a'][i], '#2a2a2a'); });
      s += bin(92);
      [10, 17, 24, 31].forEach((u, i) => { const p = q(u, 118.4); s += jar(C, p[0], p[1], p[2], 2.2, 6, ['#f2c030', '#c8402a', '#6a8a3a', '#e8a8b8'][i], '#2a2a2a'); });
      s += bin(118); return s; };
    const LD = { hx: -W / 2, zb: ZF, sg: 1, w: DW, h: DH, t: DT, y0: DY, col: SS, gl: 0.2, mat: 'brush', r: 1.4, dec: { f: use(PF + 'l'), b: lin(DW, DH) }, front: pull(DW - 4.2), back: bins };
    const RDo = { hx: W / 2, zb: ZF, sg: -1, w: DW, h: DH, t: DT, y0: DY, col: SS, gl: 0.2, mat: 'brush', r: 1.4, dec: { f: use(PF + 'r'), b: lin(DW, DH) }, front: pull(4.2) };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), bv = vis(C, [0, 0, -1]);
      const body = o => box3(C, Object.assign({ c: [0, 0, (Z0 + ZF) / 2], w: W, h: HB, d: ZF - Z0, r: 2.4, col: SD, gl: 0.2, mat: 'brush', dec: { r: use(PF + 'sr'), l: sL, b: sB, t: sT, f: bF + bMid }, olw: 0.55, olo: 0.6 }, o));
      const drawer = () => { const B = box3(C, { c: [0, ZY0, ZF + DT / 2], w: W, h: ZH, d: DT, r: 1.4, col: SS, gl: 0.2, mat: 'brush', olw: 0.45, olo: 0.6, dec: { f: use(PF + 'd') } }), y = ZY0 + ZH - 6.4, z = ZF + DT;
        const hd = cyl3(C, [-28, y, z], [-28, y, z + 4.4], 0.9, '#c8ccd0', { mat: 'chrome', n: 12, olw: 0.3 }) + cyl3(C, [28, y, z], [28, y, z + 4.4], 0.9, '#c8ccd0', { mat: 'chrome', n: 12, olw: 0.3 }) + bar(C, [-31, y, z + 4.6], [31, y, z + 4.6]);
        return fv ? B + hd : hd + B; };
      const cord = curve(C, [[26, 12, Z0 - 0.3], [28, 2, Z0 - 4], [34, 0.6, Z0 - 6], [40, 0.7, Z0 - 9]], '#2a2826', 1) + curve(C, [[-24, 8, Z0 - 0.3], [-25, 1, Z0 - 3], [-30, 0.5, Z0 - 6], [-38, 0.5, Z0 - 7]], '#eef0f2', 0.6);
      const TY = HB; let top = box3(C, { c: [-36, TY, 22], w: 8, h: 1.2, d: 6, r: 0.6, col: '#2a2c2e', olw: 0.3 }) + box3(C, { c: [36, TY, 22], w: 8, h: 1.2, d: 6, r: 0.6, col: '#2a2c2e', olw: 0.3 });
      top += shadow(C, -22, -6, 6, 6, 0.4, TY + 0.05) + shadow(C, -11, -9, 5, 5, 0.4, TY + 0.05) + shadow(C, 18, -4, 5, 5, 0.45, TY + 0.05);
      [[-11, -9, 3.6, 10, '#f2d890'], [-22, -6, 4.4, 13, '#e8c070']].forEach(([x, z, r, h, fl]) => { top += cyl3(C, [x, TY + 0.4, z], [x, TY + h * 0.72, z], r * 0.9, fl, { n: 20, mat: 'matte', olw: 0.2, cap: cr => rep(10, i => `<rect x="${f1(Math.cos(i * 2.1) * cr * 0.6 - 0.9)}" y="${f1(Math.sin(i * 1.3) * cr * 0.6 - 0.3)}" width="1.8" height="0.6" rx="0.3" fill="${shade(fl, 0.85)}" transform="rotate(${i * 37})"/>`).join('') })
        + cyl3(C, [x, TY, z], [x, TY + h, z], r, '#eaf6f6', { n: 20, op: 0.32, mat: 'gloss', olw: 0.3, olc: '#8aa0a4' }) + cyl3(C, [x, TY + h, z], [x, TY + h + 1.8, z], r * 1.04, '#b8865a', { n: 20, olw: 0.3, mat: 'matte' }) + sph(C, [x, TY + h + 2.6, z], 0.9, '#a8764a'); });
      { const vx = 18, vz = -4; top += cyl3(C, [vx, TY, vz], [vx, TY + 7, vz], 3.4, '#f2efe8', { r2: 3.8, mat: 'matte', n: 22, olw: 0.35, noCap: 1 }) + cyl3(C, [vx, TY + 7, vz], [vx, TY + 9, vz], 3.8, '#f2efe8', { r2: 2.2, mat: 'matte', n: 22, olw: 0.35, noCap: 1 }) + cyl3(C, [vx, TY + 9, vz], [vx, TY + 11, vz], 1.8, '#f2efe8', { mat: 'matte', n: 18, olw: 0.35, capCol: '#4a4234' });
        const base = C.P([vx, TY + 11, vz]); top += [[-5, 24, -2], [4, 26, 1], [-1, 28, 0.5], [7, 20, 2]].map(([dx, h, dz], i) => { const a = C.P([vx + dx * 0.3, TY + 11 + h * 0.5, vz + dz]), b = C.P([vx + dx, TY + 11 + h, vz + dz]); let s = `<path d="M${P2(base)}Q${P2(a)} ${P2(b)}" stroke="#6a7a5a" stroke-width="${f1(0.3 * C.k)}" fill="none"/>`;
          rep(7, j => { const t = 0.3 + j * 0.1, px = (1 - t) * (1 - t) * base[0] + 2 * (1 - t) * t * a[0] + t * t * b[0], py = (1 - t) * (1 - t) * base[1] + 2 * (1 - t) * t * a[1] + t * t * b[1]; s += `<ellipse cx="${f1(px + (j % 2 ? 1 : -1) * 1.1 * C.k)}" cy="${f1(py)}" rx="${f1(1.2 * C.k)}" ry="${f1(0.9 * C.k)}" fill="${j % 2 ? '#9ab4a4' : '#a8c0b0'}" stroke="#7a948a" stroke-width="0.15"/>`; });
          return `<g>${at('rotate', [-1.8, 1.8, -1.8].map(r => r + ' ' + P2(base)).join(';'), 7 + i, -i * 1.7, SPL(2))}${s}</g>`; }).join(''); }
      let s = shadow(C, 0, -1, 46, 35, 0.9);
      if (!bv) s += cord;
      if (!open) { const dl = door(C, LD, 0), dr = door(C, RDo, 0); s += fv ? body() + drawer() + dl + dr + top : dl + dr + drawer() + body() + top; }
      else {
        const x0 = -W / 2 + 3, x1 = W / 2 - 3, y0 = 58, y1 = HB - 3, z0 = Z0 + 3, z1 = ZF; let o = '';
        if (fv) {
          const led = (n) => `<rect x="${f1(n - 3)}" y="3" width="1.4" height="${f1(y1 - y0 - 8)}" rx="0.7" fill="#ffffff"/><rect x="${f1(n - 4.2)}" y="3" width="3.8" height="${f1(y1 - y0 - 8)}" rx="1.9" fill="#eef6ff" opacity="0.45"/>`;
          o += cavity(C, x0, x1, y0, y1, z0, z1, '#f3f5f6', { dk: 0.22, back: `<rect x="3" y="2" width="${f1(x1 - x0 - 6)}" height="4" rx="2" fill="#ffffff"/><ellipse cx="${f1((x1 - x0) / 2)}" cy="4" rx="${f1((x1 - x0) * 0.45)}" ry="10" fill="url(#k28led)" opacity="0.7"/>${rep(4, i => `<path d="M2 ${f1(14 + i * 23)}H${f1(x1 - x0 - 2)}" stroke="#dfe4e7" stroke-width="0.5"/>`).join('')}`, left: led(z1 - z0), right: led(z1 - z0) });
          // deli drawer + cheese
          o += box3(C, { c: [-6, y0 + 0.6, -4], ax: yawA(0.3), w: 8, h: 4.4, d: 6, r: 0.2, col: '#f2d050', olw: 0.3, dec: { f: '<circle cx="2" cy="2" r="0.6" fill="#d8b030"/><circle cx="5" cy="1.4" r="0.5" fill="#d8b030"/>', t: '<circle cx="3" cy="3" r="0.7" fill="#d8b030"/>' } }) + box3(C, { c: [10, y0 + 0.6, -2], w: 9, h: 3, d: 6, r: 0.6, col: '#c8584a', olw: 0.3, dec: { t: rep(6, i => `<circle cx="${f1(1.4 + (i % 3) * 3)}" cy="${f1(1.6 + Math.floor(i / 3) * 2.8)}" r="1.1" fill="#e88a7a" stroke="#f4d8c8" stroke-width="0.2"/>`).join('') } });
          o += box3(C, { c: [0, y0 + 0.2, -0.5], w: x1 - x0 - 1, h: 10, d: z1 - z0 - 2, r: 1, col: '#e6f2f4', op: 0.4, skip: { t: 1 }, olw: 0.35, olc: '#9ab8c0', dec: { f: `<rect x="2" y="0.8" width="${f1(x1 - x0 - 5)}" height="2" rx="1" fill="#c8ccd0"/><text x="${f1((x1 - x0) / 2)}" y="7" text-anchor="middle" ${FONT} font-size="1.8" fill="#7aa0a8" opacity="0.8">DELI · 34°</text>` } });
          o += gshelf(C, x0, x1, 69, z0 + 0.4, z1 - 0.4, '#c8ccd0');
          o += box3(C, { c: [-16, 69.8, -6], w: 14, h: 6, d: 11, r: 1, col: '#eef4f4', op: 0.75, olw: 0.3, dec: { t: rep(10, () => `<ellipse cx="${f1(2 + R() * 10)}" cy="${f1(2 + R() * 7)}" rx="${f1(1.4 + R())}" ry="${f1(0.9 + R() * 0.6)}" fill="${R() < 0.5 ? '#6ab04a' : '#8ac860'}" transform="rotate(${f1(R() * 180)} 7 5.5)"/>`).join('') } }) + box3(C, { c: [-16, 75.8, -6], w: 14.4, h: 0.8, d: 11.4, r: 1, col: '#dfe8e8', op: 0.6, olw: 0.25 });
          o += bottle(C, 28, 69.8, -14, 2.8, 19, '#3a7a4a', '#c8ccd0', { op: 0.8 }) + bottle(C, 32, 69.8, -6, 2.8, 19, '#3a7a4a', '#c8ccd0', { op: 0.8, lbl: `<rect x="-2.4" y="-1.6" width="4.8" height="3.2" fill="#f4f4ee"/><text x="0" y="0.5" text-anchor="middle" ${FONT} font-size="0.9" fill="#3a6a4a">SPARKLING</text>` });
          o += cyl3(C, [16, 69.8, -2], [16, 73.8, -2], 4.2, '#f6f6f2', { r2: 6.4, n: 26, olw: 0.3, capCol: '#e8ecec' }) + grapes(C, 16, 73.2, -2, '#7a3a8a');
          o += gshelf(C, x0, x1, 92, z0 + 0.4, z1 - 0.4, '#c8ccd0');
          o += box3(C, { c: [-18, 92.8, -8], w: 14, h: 3.4, d: 7, r: 0.4, col: '#e8e0d0', olw: 0.3 }) + rep(6, i => sph(C, [-22.4 + (i % 3) * 4.4, 97.2, -9.6 + Math.floor(i / 3) * 3.2], 1.6, '#f4ecdc')).join('');
          o += cyl3(C, [8, 92.8, -6], [8, 96.4, -6], 2, '#f4f4f2', { n: 18, olw: 0.3 }) + cyl3(C, [8, 96.4, -6], [8, 97, -6], 7, '#f4f4f2', { n: 26, olw: 0.3 }) + cyl3(C, [8, 97, -6], [8, 101.4, -6], 5.4, '#f6ecd4', { n: 26, olw: 0.3, capCol: '#c8283a', cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#c8283a"/><ellipse cx="${f1(-cr * 0.3)}" cy="${f1(-cr * 0.3)}" rx="${f1(cr * 0.3)}" ry="${f1(cr * 0.15)}" fill="#ffffff" opacity="0.4"/>` }) + `<g transform="${tanF(C, 8, -6, 5.42, C.thV, 99.6)}"><rect x="-5.4" y="1" width="10.8" height="1.2" fill="#c89a5a"/></g>`;
          o += cyl3(C, [26, 92.8, 4], [26, 103, 4], 3.6, '#f8f6d8', { n: 22, mat: 'matte', olw: 0.2 }) + cyl3(C, [26, 92.8, 4], [26, 107, 4], 4, '#eaf6f6', { n: 22, op: 0.32, mat: 'gloss', olw: 0.35, olc: '#8aa0a4' }) + [98, 101.4].map((y, i) => `<g transform="${tanF(C, 26, 4, 3.2, C.thV + (i ? 0.4 : -0.3), y)}"><circle r="1.6" fill="#f6e040" stroke="#e8c020" stroke-width="0.3"/>${rep(6, j => `<path d="M0 0L${f1(Math.cos(j) * 1.3)} ${f1(Math.sin(j) * 1.3)}" stroke="#f8f0a0" stroke-width="0.15"/>`).join('')}</g>`).join('');
          o += gshelf(C, x0, x1, 116, z0 + 0.4, z1 - 0.4, '#c8ccd0');
          [[-24, -10, '#c8402a'], [-15, -10, '#e8a020'], [-6, -9, '#6a3a2a']].forEach(([x, z, c]) => o += jar(C, x, 116.8, z, 3, 7.4, c, '#2a2a2a', 0.8));
          [[8, '#f28ab0'], [13.6, '#f6d040'], [19.2, '#a88ad8']].forEach(([x, c]) => o += cup(C, x, 116.8, 2, 2.6, 4.6, '#f8f6f0', c));
          o += box3(C, { c: [26, 116.8, -8], ax: yawA(-0.2), w: 10, h: 5, d: 8, r: 1.2, col: '#f6f4ee', op: 0.9, olw: 0.3 }) + box3(C, { c: [26, 121.8, -8], ax: yawA(-0.2), w: 10.4, h: 1, d: 8.4, r: 1.2, col: '#3a8a6a', olw: 0.3 });
          o += PLN(C, [x0 + 0.2, y1 - 0.2, z1 - 0.1], [1, 0, 0], [0, -1, 0], `<rect width="${f1(x1 - x0 - 0.4)}" height="${f1(y1 - y0)}" fill="url(#k28spC)" opacity="0.3"/>`);
        }
        const gasket = `<rect x="2.3" y="2.3" width="${W - 4.6}" height="${f1(y1 - y0 + 1.4)}" rx="1.4" fill="none" stroke="#c8ccd0" stroke-width="1.4"/>`;
        const bod = body({ hole: { f: [3, 3, 3, y0] }, dec: { r: use(PF + 'sr'), l: sL, b: sB, t: sT, f: bF + gasket } }), fr = swing(C, LD, 122, 11, 0.85), dr = swing(C, RDo, 118, 11, 0.85);
        s += fv ? o + bod + drawer() + dr + fr + top : fr + dr + drawer() + bod + top;
        if (fv) s += PLN(C, [0, 0.06, ZF + 22], [1, 0, 0], [0, 0, 1], `<ellipse rx="34" ry="17" fill="url(#k28spC)" opacity="0.7"/>`) + mist(C, 0, 64, ZF + 3, 4, 0.9);
      }
      if (bv) s += cord;
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-075 BUILT-IN GLASS-FRONT CHEF'S REFRIGERATOR & WINE COLUMN =======================
  // walnut-clad built-in with brass edge strips, stainless face frame, brass louvred grille + "SOUS·ZÉRO" plaque, glowing toe-kick line. Left: glass-door chef's
  // fridge (warm LED, brass-trimmed glass shelves, crisper of lemons/leeks, parmesan wheel, dry-aged parcel, berry punnets, milk bottle, preserves, lemon tart,
  // champagne, basil in water; chill haze breathes on the glass). Right: bronze-glass wine column, 7 walnut racks of bottles necks-out with brass tags, amber light
  // breathing, decanter + bottle on top, 12° display. Open: the fridge door swings out.
  N.subz28 = S => { const open = isPlay(S), W = 70, HB = 160, Z0 = -30, ZF = 26, DT = 3.6, KH = 8, SS = '#c6cacd', WAL = '#6a4329', BR = '#c9a256', OY0 = 12, OY1 = 138, DW = 34.6, BD = ZF - Z0, BH = HB - KH;
    const D = { w: 70, d: 60, arch: 'fridge', act: 'snack', use: { x: 0, z: 62 }, build: () => [] };
    const R = rng('subz28');
    const sR = grainV(R, BD, BH, 34, '#2e1a0c', '#9a6a40') + `<rect width="1.3" height="${BH}" fill="${BR}"/>`, sL = grainV(R, BD, BH, 34, '#2e1a0c', '#9a6a40') + `<rect x="${f1(BD - 1.3)}" width="1.3" height="${BH}" fill="${BR}"/>`;
    const sT = rep(18, () => { const y = R() * BD; return `<path d="M0 ${f1(y)}C${f1(W * 0.3)} ${f1(y + (R() - 0.5) * 3)} ${f1(W * 0.6)} ${f1(y + (R() - 0.5) * 3)} ${W} ${f1(y + (R() - 0.5) * 2)}" stroke="#2e1a0c" stroke-opacity="${n4(0.15 + R() * 0.25)}" stroke-width="${f1(0.2 + R() * 0.6)}" fill="none"/>`; }).join('') + `<rect y="${f1(BD - 1.2)}" width="${W}" height="1.2" fill="${BR}"/>`;
    const sB = `<rect x="5" y="6" width="60" height="${BH - 14}" rx="1" fill="#1e1a16"/>` + rep(16, i => `<path d="M9 ${12 + i * 8}H61" stroke="#3a342c" stroke-width="1.6"/>`).join('') + `<rect x="23" y="${BH - 6}" width="24" height="5" rx="0.4" fill="url(#k28chr)"/><text x="35" y="${BH - 2.8}" text-anchor="middle" font-family="Arial" font-size="1.6" fill="#3a3c40">SOUS·ZÉRO BI-36 · 115V · 60Hz</text>`;
    const plate = C => { const hl = (a, b) => `M${f1(a)} ${HB - OY1}V${HB - OY0}H${f1(b)}V${HB - OY1}Z`, d = `M0 0H${W}V${BH}H0Z` + hl(3, 33.4) + hl(36.6, 67), fc = shade(SS, lit(C, [0, 0, 1]));
      return PLN(C, [-W / 2, HB, ZF], [1, 0, 0], [0, -1, 0], `<path d="${d}" fill="${fc}" fill-rule="evenodd"/><path d="${d}" fill="url(#k28br)" fill-rule="evenodd"/><path d="${d}" fill="url(#m10v)" fill-rule="evenodd"/><path d="${hl(3, 33.4) + hl(36.6, 67)}" fill="none" stroke="#000000" stroke-opacity="0.3" stroke-width="0.6"/>`
        + `<rect x="8" y="3.6" width="54" height="11.4" rx="1.2" fill="#15171a"/>` + rep(5, i => `<rect x="9" y="${f1(4.5 + i * 2.1)}" width="52" height="1.25" rx="0.6" fill="url(#k28brs)"/>`).join('')
        + `<rect x="24" y="16.2" width="22" height="3.8" rx="0.6" fill="url(#k28brs)"/><text x="35" y="19.1" text-anchor="middle" font-family="Georgia,serif" font-size="2.3" letter-spacing="0.6" fill="#5a4214">SOUS·ZÉRO</text>`); };
    const handleV = (u, y1, y2) => (Dh, C) => { const so = y => cyl3(C, Dh.P(u, y, DT), Dh.P(u, y, DT + 3.4), 0.8, BR, { mat: 'metal', n: 12, olw: 0.3 }); return so(y1 + 3) + so(y2 - 3) + cyl3(C, Dh.P(u, y1, DT + 3.6), Dh.P(u, y2, DT + 3.6), 1.15, BR, { mat: 'metal', n: 16, olw: 0.3 }); };
    const gl1 = (gw, gh) => refl(gw, gh) + `<rect y="${f1(gh - 22)}" width="${f1(gw)}" height="22" fill="url(#k28haze)"><animate attributeName="opacity" values="0.35;0.7;0.35" dur="9s" repeatCount="indefinite"/></rect>`;
    const gl2 = (gw, gh) => refl(gw, gh) + `<rect x="${f1(gw / 2 - 6)}" y="2.6" width="12" height="4.6" rx="0.8" fill="#0c0906" opacity="0.88"/><text x="${f1(gw / 2 - 1.4)}" y="6" text-anchor="middle" ${FONT} font-size="2.7" fill="#ffc46a">12°</text><text x="${f1(gw / 2 + 3.4)}" y="6" text-anchor="middle" font-family="Arial" font-size="1.1" fill="#c8955a">C</text><circle cx="${f1(gw / 2 + 4.4)}" cy="3.8" r="0.4" fill="#ffc46a">${an('opacity', '1;0.25;1', 4)}</circle>`;
    const LDo = { hx: -W / 2, zb: ZF, sg: 1, w: DW, h: 130, t: DT, y0: 9, glass: 1, fw: 3.4, ft: 4.4, fb: 6, col: SS, mat: 'brush', gl: 0.35, tint: '#e4eeec', gop: 0.12, gdec: gl1, front: handleV(DW - 3.4, 30, 118) };
    const RDo = { hx: W / 2, zb: ZF, sg: -1, w: DW, h: 130, t: DT, y0: 9, glass: 1, fw: 3.4, ft: 4.4, fb: 6, col: SS, mat: 'brush', gl: 0.35, tint: '#5a3a20', gop: 0.24, gdec: gl2, front: handleV(3.4, 30, 118) };
    const lbl = t => `<rect x="-2.3" y="-1.2" width="4.6" height="2.4" fill="#f6efdc"/><text x="0" y="0.45" text-anchor="middle" font-family="Georgia,serif" font-size="0.7" fill="#5a4a2a">${t}</text>`;
    // chef's fridge column
    const iL = C => { const x0 = -32, x1 = -1.6, y0 = OY0, y1 = OY1, z0 = Z0 + 2.5, z1 = ZF, IW = x1 - x0, ID = z1 - z0, IH = y1 - y0, mx = (x0 + x1) / 2; let o = '';
      const led = u => `<rect x="${f1(u)}" y="3" width="1.4" height="${f1(IH - 6)}" rx="0.7" fill="#fff7e8"/><rect x="${f1(u - 1.2)}" y="3" width="3.8" height="${f1(IH - 6)}" rx="1.9" fill="#fff3dc" opacity="0.4"/>`;
      o += cavity(C, x0, x1, y0, y1, z0, z1, '#dde1e4', { dk: 0.16, back: `<rect width="${f1(IW)}" height="${f1(IH)}" fill="url(#k28br)"/><rect x="2" y="1.4" width="${f1(IW - 4)}" height="2.6" rx="1.3" fill="#fff8ea"/><ellipse cx="${f1(IW / 2)}" cy="4" rx="${f1(IW * 0.5)}" ry="16" fill="url(#k28spW)" opacity="0.7"/>`, left: led(ID - 3.4), right: led(2) });
      o += sph(C, [-26, 15.2, -10], 3, '#f2d23a') + sph(C, [-20, 15.2, -6], 3, '#f6d840') + sph(C, [-9, 15.6, -10], 3.4, '#d8302a') + sph(C, [-25, 15.2, 2], 3, '#f2d23a');
      o += cyl3(C, [-29, 14.2, 10], [-12, 14.6, 6], 1.8, '#eef0dc', { n: 14, olw: 0.25 }) + cyl3(C, [-12, 14.6, 6], [-5, 15.2, 4.5], 1.9, '#5a9a3a', { r2: 2.4, n: 14, olw: 0.25 }) + sph(C, [-8, 15.6, 13], 3.2, '#6a8a4a');
      o += box3(C, { c: [mx, y0 + 0.2, -1.5], w: IW - 1, h: 14, d: ID - 4, r: 0.8, col: '#eef4f4', op: 0.4, skip: { t: 1 }, olw: 0.35, olc: '#9ab0b4', dec: { f: `<rect x="${f1(IW / 2 - 6)}" y="1.6" width="11" height="1.6" rx="0.8" fill="${BR}"/><text x="${f1((IW - 1) / 2)}" y="8" text-anchor="middle" font-family="Georgia,serif" font-size="1.7" fill="#8a9a9c" letter-spacing="0.4">CRISPER</text>` } });
      // shelf 1: parmesan wheel, dry-aged parcel, butter
      o += gshelf(C, x0, x1, 30, z0 + 0.4, z1 - 0.4, BR); let y = 30.8;
      o += cyl3(C, [-22, y, -2], [-22, y + 6, -2], 6.2, '#e2bf72', { n: 26, mat: 'matte', olw: 0.3, capCol: '#f0d490', cap: cr => `<circle r="${f1(cr * 0.88)}" fill="none" stroke="#c89a4a" stroke-width="0.6"/>` + rep(10, i => `<circle cx="${f1(Math.cos(i * 1.9) * cr * 0.5)}" cy="${f1(Math.sin(i * 2.3) * cr * 0.5)}" r="0.25" fill="#c89a4a" opacity="0.5"/>`).join('') })
        + `<g transform="${tanF(C, -22, -2, 6.22, C.thV, y + 3)}"><text x="0" y="0.5" text-anchor="middle" ${FONT} font-size="1.1" fill="#9a6a2a" letter-spacing="0.3">PARMIGIANO</text><path d="M-5 -1.4H5M-5 1.4H5" stroke="#9a6a2a" stroke-width="0.15" stroke-dasharray="0.4 0.3"/></g>`;
      o += box3(C, { c: [-10, y, 9], w: 10, h: 4.6, d: 8, r: 0.4, col: '#e8dcc2', olw: 0.3, dec: { t: '<path d="M5 0V8M0 4H10" stroke="#b08a5a" stroke-width="0.35"/><path d="M4 3.4Q5 2.4 6 3.4M4 4.6Q5 5.6 6 4.6" stroke="#b08a5a" stroke-width="0.3" fill="none"/>', f: `<path d="M5 0V4.6" stroke="#b08a5a" stroke-width="0.35"/><text x="2.6" y="3" text-anchor="middle" ${FONT} font-size="0.9" fill="#a8302a" opacity="0.7">28 D</text>` } });
      o += box3(C, { c: [-26, y, 14], w: 7, h: 2.2, d: 5, r: 0.6, col: '#f6f0e4', olw: 0.3 }) + box3(C, { c: [-26, y + 2.2, 14], w: 5.4, h: 2, d: 3.4, r: 0.4, col: '#f6e098', olw: 0.25 });
      // shelf 2: berry punnets, glass milk bottle
      o += gshelf(C, x0, x1, 56, z0 + 0.4, z1 - 0.4, BR); y = 56.8;
      o += bottle(C, -11, y, 1, 2.6, 15, '#f8f6f0', BR, { lbl: `<rect x="-2" y="-1.4" width="4" height="2.8" fill="#2a4a7a"/><text x="0" y="0.5" text-anchor="middle" font-family="Georgia,serif" font-size="0.85" fill="#f4ead0">Laiterie</text>` });
      [[-28, '#c8283a', 1.15], [-21.5, '#3a4a8a', 1], [-15, '#d8302a', 1.4]].forEach(([x, c, br]) => { o += box3(C, { c: [x, y, 11], w: 6, h: 3, d: 6, r: 0.3, col: '#c49a64', olw: 0.3, dec: { f: '<path d="M0 1H6M0 2H6" stroke="#9a7040" stroke-width="0.2"/>' } });
        [[-1.4, -1.4], [1.4, -1.2], [0, 0], [-1.3, 1.4], [1.4, 1.4]].forEach(([dx, dz]) => o += sph(C, [x + dx, y + 3 + br * 0.7, 11 + dz], br, c)); });
      // shelf 3: preserves, crème brûlées
      o += gshelf(C, x0, x1, 82, z0 + 0.4, z1 - 0.4, BR); y = 82.8;
      o += jar(C, -20, y, -2, 2.6, 7.4, '#6a8a2a', BR, 0.82, lbl('CORNICHONS')) + jar(C, -27, y, 2, 3, 9, '#f2d040', BR, 0.85, lbl('CITRONS')) + jar(C, -12, y, 1, 2.8, 6.6, '#4a3a4a', BR, 0.8, lbl('OLIVES'));
      [[-22, 14], [-9, 13]].forEach(([x, z]) => o += cyl3(C, [x, y, z], [x, y + 2.2, z], 2.6, '#f6f4ee', { n: 20, olw: 0.3, capCol: '#c88a3a', cap: cr => `<ellipse cx="${f1(-cr * 0.3)}" cy="${f1(-cr * 0.25)}" rx="${f1(cr * 0.35)}" ry="${f1(cr * 0.18)}" fill="#f8d890" opacity="0.6"/>` }));
      // shelf 4: lemon tart on a stand, champagne, basil in water
      o += gshelf(C, x0, x1, 108, z0 + 0.4, z1 - 0.4, BR); y = 108.8;
      o += cyl3(C, [-28, y, 10], [-28, y + 4, 10], 1.9, '#9ac8e0', { n: 16, op: 0.3, olw: 0.2 }) + cyl3(C, [-28, y, 10], [-28, y + 6.6, 10], 2.1, '#e8f4f4', { n: 16, op: 0.32, mat: 'gloss', olw: 0.3, olc: '#8aa0a4' });
      [[-28.6, 7.8, 9.4], [-27, 8.6, 10.6], [-29.4, 9.6, 10.2], [-27.6, 10.4, 9.2], [-28.4, 11.4, 10.8], [-26.6, 9.8, 11.2]].forEach(([x, dy, z], i) => o += sph(C, [x, y + dy, z], 1.35 - i * 0.05, i % 2 ? '#4e9a3a' : '#5aaa44'));
      o += cyl3(C, [-17, y, 5], [-17, y + 3.6, 5], 1.3, '#f6f4ee', { n: 14, olw: 0.25 }) + cyl3(C, [-17, y + 3.6, 5], [-17, y + 4.2, 5], 7.4, '#f6f4ee', { n: 28, olw: 0.3 })
        + cyl3(C, [-17, y + 4.2, 5], [-17, y + 6.4, 5], 6.4, '#d8a860', { n: 28, olw: 0.3, capCol: '#f6d84a', cap: cr => rep(9, i => `<circle cx="${f1(Math.cos(i * 0.7) * cr * 0.72)}" cy="${f1(Math.sin(i * 0.7) * cr * 0.72)}" r="${f1(cr * 0.1)}" fill="#fff8ec" stroke="#e8c890" stroke-width="0.15"/>`).join('') + `<ellipse cx="${f1(-cr * 0.3)}" cy="${f1(-cr * 0.3)}" rx="${f1(cr * 0.3)}" ry="${f1(cr * 0.14)}" fill="#ffffff" opacity="0.4"/>` });
      o += bottle(C, -8, y, -4, 2.8, 20, '#1e3a24', '#d8b860', { lbl: `<rect x="-2.2" y="-1.8" width="4.4" height="3.6" fill="#f2e6c4"/><text x="0" y="0.4" text-anchor="middle" font-family="Georgia,serif" font-size="0.8" fill="#5a3a14">BRUT</text>` });
      o += PLN(C, [x0 + 0.2, y1 - 0.2, z1 - 0.1], [1, 0, 0], [0, -1, 0], `<rect width="${f1(IW - 0.4)}" height="${f1(IH)}" fill="url(#k28spW)" opacity="0.22"/>`);
      return o; };
    // wine column: walnut racks, bottles necks-out, amber light breathing
    const TAGS = ['CHAMPAGNE', 'BOURGOGNE', 'BORDEAUX', 'RIOJA', 'BAROLO', 'NAPA', 'PORTO'];
    const iR = C => { const x0 = 1.6, x1 = 32, y0 = OY0, y1 = OY1, z0 = Z0 + 2.5, z1 = ZF, IW = x1 - x0, ID = z1 - z0, IH = y1 - y0, mx = (x0 + x1) / 2, zf = z1 - 2; let o = '';
      const led = u => `<rect x="${f1(u)}" y="3" width="1.2" height="${f1(IH - 6)}" rx="0.6" fill="#ffcf8a"/><rect x="${f1(u - 1.4)}" y="3" width="4" height="${f1(IH - 6)}" rx="2" fill="#ffb860" opacity="0.35">${an('opacity', '0.22;0.45;0.22', 8)}</rect>`;
      o += cavity(C, x0, x1, y0, y1, z0, z1, '#4a3222', { dk: 0.3, back: `<rect width="${f1(IW)}" height="${f1(IH)}" fill="#120c08" opacity="0.5"/><ellipse cx="${f1(IW / 2)}" cy="${f1(IH / 2)}" rx="${f1(IW * 0.62)}" ry="${f1(IH * 0.56)}" fill="url(#k28amb)">${an('opacity', '0.45;0.75;0.45', 8)}</ellipse>`, left: led(ID - 3), right: led(1.8) });
      const caps = ['#6a1a24', '#c9a256', '#1e1a18', '#e8dcc0', '#8a2a2a', '#b8bcc0'], glass = ['#1f2c1c', '#2a1c12', '#22301e', '#3a2414'];
      const rack = (y, k) => { o += box3(C, { c: [mx, y, (z0 + zf) / 2], w: IW - 0.4, h: 1.4, d: zf - z0, r: 0.2, col: WAL, olw: 0.3, dec: { t: rep(4, i => `<path d="M0 ${f1(3 + i * 11)}H${f1(IW)}" stroke="#3a2212" stroke-opacity="0.3" stroke-width="0.3"/>`).join('') } }); };
      const lip = (y, k) => box3(C, { c: [mx, y - 0.4, zf + 0.5], w: IW - 0.4, h: 2, d: 1, r: 0.2, col: BR, gl: 0.5, olw: 0.25, dec: { f: TAGS[k] ? `<rect x="${f1(IW / 2 - 4.4)}" y="0.35" width="8.8" height="1.3" fill="#f4ead0"/><text x="${f1(IW / 2 - 0.2)}" y="1.35" text-anchor="middle" font-family="Georgia,serif" font-size="0.9" fill="#4a2a14">${TAGS[k]}</text>` : '' } });
      [12, 29, 46, 63, 80, 97, 114].forEach((y, k) => { rack(y, k);
        rep(4, i => { const x = x0 + 3.8 + i * 7.6, cp = caps[(k * 3 + i * 5) % caps.length], gc = glass[(k + i) % glass.length], yc = y + 4.6, zb = zf - 20.5;
          o += cyl3(C, [x, yc, zb], [x, yc, zb + 12.5], 3.2, gc, { mat: 'gloss', n: 18, olw: 0.25 }) + cyl3(C, [x, yc, zb + 12.5], [x, yc, zb + 15.5], 3.2, gc, { r2: 1.25, mat: 'gloss', n: 16, olw: 0.25, noCap: 1 }) + cyl3(C, [x, yc, zb + 15.5], [x, yc, zb + 20], 1.25, cp, { mat: 'metal', n: 12, olw: 0.25 }); });
        o += lip(y, k); });
      rack(122.6); const yt = 124;
      o += bottle(C, 10, yt, -6, 2.8, 11, '#3a1414', '#6a1a24', { lbl: `<rect x="-2.2" y="-1.6" width="4.4" height="3.2" fill="#f4ead0"/><text x="0" y="0.4" text-anchor="middle" font-family="Georgia,serif" font-size="0.75" fill="#5a1a1a">Grand Cru</text>` });
      o += sph(C, [23, yt + 3.9, -4], 3.4, '#5a1020', { op: 0.92 }) + sph(C, [23, yt + 4.2, -4], 4.2, '#eef4f4', { op: 0.25 }) + cyl3(C, [23, yt + 7.8, -4], [23, yt + 11.6, -4], 1.1, '#eef4f4', { n: 14, op: 0.35, olw: 0.25, olc: '#8aa0a4' }) + sph(C, [23, yt + 12.3, -4], 1.2, '#e8f0f0', { op: 0.6 });
      o += lip(122.6, 7);
      return o; };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const body = box3(C, { c: [0, KH, (Z0 + ZF) / 2], w: W, h: BH, d: BD, r: 0.8, col: WAL, gl: 0.3, skip: { f: 1 }, dec: { r: sR, l: sL, t: sT, b: sB }, olw: 0.5, olo: 0.6 });
      const kick = box3(C, { c: [0, 0, (Z0 + ZF) / 2 - 1.5], w: W - 3, h: KH, d: BD - 3, r: 0.3, col: '#1c1713', olw: 0.3, dec: { f: `<rect x="3" y="${KH - 1.4}" width="${W - 9}" height="0.7" rx="0.35" fill="#ffe0a0">${an('opacity', '0.7;1;0.7', 8)}</rect>` } });
      let s = shadow(C, 0, -2, 40, 34, 0.9) + (fv ? PLN(C, [0, 0.06, ZF + 5], [1, 0, 0], [0, 0, 1], `<ellipse rx="32" ry="6" fill="url(#k28spW)">${an('opacity', '0.3;0.55;0.3', 8)}</ellipse>`) : '');
      const dl = open ? swing(C, LDo, 112, 11, 0.85) : door(C, LDo, 0), dr = door(C, RDo, 0);
      s += fv ? kick + iL(C) + iR(C) + body + plate(C) + dr + dl : dl + dr + kick + body;
      if (fv && open) s += PLN(C, [-17, 0.06, ZF + 18], [1, 0, 0], [0, 0, 1], `<ellipse rx="22" ry="12" fill="url(#k28spW)" opacity="0.55"/>`) + mist(C, -17, 40, ZF + 2, 3, 0.8);
      return { defs: DEF28, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-095 AI HOLOGRAPHIC CRYO-PANTRY & AUTO-INVENTORY SMART MEGA-FRIDGE =======================
  // ivory ceramic-glass body with Calacatta veins + champagne-gold trims, floats on a recessed plinth over a breathing champagne glow. Two smoked obsidian-glass
  // doors show a warm-lit pantry (sushi on slate, juices, figs + grapes, caviar on ice, strawberry shortcake, macaron tower under a cloche, champagne, cheese board,
  // eggs, preserves); an inventory scan line sweeps down it. A pearl hologram floats in front of the right door (turning apple, stock bars, 42 ITEMS) from an emitter.
  // Cryo drawer below: frosted window with gelato pints and drifting frost, −18°. Open: the left door swings out and cryo fog pours to the floor.
  N.cryo28 = S => { const open = isPlay(S), W = 70, HB = 162, Z0 = -30, ZF = 26, DT = 3.6, PY = 10, IV = '#efe9df', CG = '#d8bc82', DW = 34.6, DY = 53, DH = 106, BD = ZF - Z0, BH = HB - PY;
    const D = { w: 70, d: 60, arch: 'fridge', act: 'snack', use: { x: 0, z: 62 }, build: () => [] };
    const R = rng('cryo28');
    const sR = veins(R, BD, BH) + `<rect width="1.4" height="${BH}" fill="${CG}"/>`, sL = veins(R, BD, BH) + `<rect x="${f1(BD - 1.4)}" width="1.4" height="${BH}" fill="${CG}"/>`;
    const sT = veins(R, W, BD) + `<rect y="${f1(BD - 1.2)}" width="${W}" height="1.2" fill="${CG}"/>`;
    const sB = `<rect x="6" y="8" width="58" height="${BH - 18}" rx="1" fill="#2a2622"/>` + rep(15, i => `<path d="M10 ${14 + i * 8}H60" stroke="#463e36" stroke-width="1.6"/>`).join('') + `<rect x="21" y="${BH - 7}" width="28" height="5" rx="0.4" fill="url(#k28brs)"/><text x="35" y="${BH - 3.8}" text-anchor="middle" font-family="Arial" font-size="1.5" fill="#4a3a1a">AURUM CRYO-PANTRY AI-9 · 115V</text>`;
    const plate = C => { const hl = `M3 ${HB - 156}V${HB - 54}H67V${HB - 156}Z`, d = `M0 0H${W}V${BH}H0Z` + hl, fc = shade(CG, lit(C, [0, 0, 1]));
      return PLN(C, [-W / 2, HB, ZF], [1, 0, 0], [0, -1, 0], `<path d="${d}" fill="${fc}" fill-rule="evenodd"/><path d="${d}" fill="url(#k28br)" fill-rule="evenodd"/><path d="${d}" fill="url(#m10v)" fill-rule="evenodd"/><path d="${hl}" fill="none" stroke="#5a4520" stroke-opacity="0.35" stroke-width="0.6"/>`
        + `<rect x="4" y="${HB - 52.2}" width="62" height="0.8" rx="0.4" fill="#fff0c8">${an('opacity', '0.55;1;0.55', 9)}</rect>`); };
    const hdl = (u, y1, y2) => (Dh, C) => { const so = y => cyl3(C, Dh.P(u, y, DT), Dh.P(u, y, DT + 2.8), 0.7, CG, { mat: 'metal', n: 12, olw: 0.3 }); return so(y1 + 2.5) + so(y2 - 2.5) + cyl3(C, Dh.P(u, y1, DT + 3), Dh.P(u, y2, DT + 3), 0.95, CG, { mat: 'metal', n: 16, olw: 0.3 }); };
    const frost = (gw, gh) => refl(gw, gh) + `<rect y="${f1(gh - 26)}" width="${f1(gw)}" height="26" fill="url(#k28haze)" opacity="0.3">${an('opacity', '0.18;0.36;0.18', 10)}</rect>`
      + [[0.6, gh - 0.6, 1], [gw - 0.6, gh - 0.6, -1]].map(([x, y, sx]) => rep(7, i => { const a = -PI / 2 + sx * (0.15 + i * 0.2), l = 2 + (i * 7) % 5; return `<path d="M${f1(x)} ${f1(y)}l${f1(Math.cos(a) * l * sx)} ${f1(Math.sin(a) * l)}" stroke="#ffffff" stroke-opacity="0.4" stroke-width="0.2"/>`; }).join('')).join('');
    const emit = (Dh, C) => cyl3(C, Dh.P(DW / 2, DY + 2, DT), Dh.P(DW / 2, DY + 2, DT + 1), 1.4, CG, { mat: 'metal', n: 16, olw: 0.3, capCol: '#fff2d0' });
    const LDo = { hx: -W / 2, zb: ZF, sg: 1, w: DW, h: DH, t: DT, y0: DY, glass: 1, fw: 2.6, ft: 3.4, fb: 4, col: CG, mat: 'brush', gl: 0.5, tint: '#16141a', gop: 0.3, gdec: frost, front: hdl(DW - 3, 78, 134) };
    const RDo = { hx: W / 2, zb: ZF, sg: -1, w: DW, h: DH, t: DT, y0: DY, glass: 1, fw: 2.6, ft: 3.4, fb: 4, col: CG, mat: 'brush', gl: 0.5, tint: '#16141a', gop: 0.3, gdec: frost, front: (Dh, C) => hdl(3, 78, 134)(Dh, C) + emit(Dh, C) };
    const lbl = (t, c) => `<rect x="-1.8" y="-1.2" width="3.6" height="2.4" fill="#fbf6ec"/><text x="0" y="0.45" text-anchor="middle" font-family="Georgia,serif" font-size="0.6" fill="${c || '#5a4a2a'}">${t}</text>`;
    // cryo drawer front: frosted window (gelato pints, drifting frost), −18°
    const dwF = C => { const id = C.u('cw'), wx = 6, wy = 7.4, ww = 57.4, wh = 25, GC = ['#f6c6d0', '#d8f0c8', '#f6e6b0', '#e0d0f6', '#c8e6f6', '#f6d6b8'];
      return `<defs><clipPath id="${id}"><rect x="${wx}" y="${wy}" width="${ww}" height="${wh}" rx="2"/></clipPath></defs><rect x="${wx}" y="${wy}" width="${ww}" height="${wh}" rx="2" fill="#1c232a"/>`
        + `<g clip-path="url(#${id})">` + rep(6, i => `<rect x="${f1(wx + 3 + i * 9.2)}" y="${f1(wy + 9)}" width="7.2" height="13" rx="1.6" fill="#e6eef2" opacity="0.6"/><rect x="${f1(wx + 3 + i * 9.2)}" y="${f1(wy + 9)}" width="7.2" height="3" rx="1.4" fill="${GC[i]}" opacity="0.85"/><rect x="${f1(wx + 3.6 + i * 9.2)}" y="${f1(wy + 14.4)}" width="6" height="2.4" fill="#ffffff" opacity="0.4"/>`).join('')
        + rep(4, i => `<ellipse cx="${f1(wx + 8 + i * 14)}" cy="${f1(wy + wh * (0.45 + (i % 2) * 0.25))}" rx="13" ry="5" fill="url(#m10mst)" opacity="0.38"><animateTransform attributeName="transform" type="translate" values="-6 0;6 -1.6;-6 0" dur="${11 + i * 2.5}s" begin="-${i * 3}s" repeatCount="indefinite"/></ellipse>`).join('')
        + `<rect x="${wx}" y="${wy}" width="${ww}" height="${wh}" fill="url(#k28haze)" opacity="0.5"/></g><rect x="${wx}" y="${wy}" width="${ww}" height="${wh}" rx="2" fill="none" stroke="${CG}" stroke-width="0.8"/>`
        + `<rect x="${f1(W / 2 - 6.5)}" y="${f1(wy + 1.6)}" width="13" height="5" rx="1" fill="#0c0e10" opacity="0.7"/><text x="${f1(W / 2)}" y="${f1(wy + 5.4)}" text-anchor="middle" font-family="Georgia,serif" font-size="3.4" fill="#f6dca0">−18°</text>`
        + `<text x="${f1(W / 2)}" y="${f1(wy + wh + 3.6)}" text-anchor="middle" font-family="Georgia,serif" font-size="1.9" letter-spacing="1" fill="#a8884a">CRYO · PANTRY</text>`; };
    const holo = () => { const w = 27, h = 36; let g = `<rect width="${w}" height="${h}" rx="2" fill="url(#k28hg)" opacity="0.55"/><rect width="${w}" height="${h}" rx="2" fill="none" stroke="#ffe8c4" stroke-opacity="0.8" stroke-width="0.3"/>`;
      g += `<text x="2" y="3.6" font-family="Georgia,serif" font-size="2" fill="#fff0d8" letter-spacing="0.4">PANTRY · AI</text><circle cx="${w - 3.4}" cy="2.8" r="1.6" fill="none" stroke="#fff0d8" stroke-opacity="0.35" stroke-width="0.4"/><circle cx="${w - 3.4}" cy="2.8" r="1.6" fill="none" stroke="#ffd890" stroke-width="0.4" stroke-dasharray="8 2.1" transform="rotate(-90 ${w - 3.4} 2.8)"/><path d="M1.6 5.4H${w - 1.6}" stroke="#ffe8c4" stroke-opacity="0.4" stroke-width="0.2"/>`;
      g += `<g transform="translate(6.4 11.4)"><circle r="3.8" fill="#ffd8d0" opacity="0.14"/><circle r="3.8" fill="none" stroke="#ffe0d4" stroke-width="0.3"/>` + [0, 2, 4].map(b => `<ellipse rx="3.8" ry="3.8" fill="none" stroke="#fff0e0" stroke-opacity="0.6" stroke-width="0.2"><animate attributeName="rx" values="3.8;0.3;3.8" dur="6s" begin="-${b}s" repeatCount="indefinite"/></ellipse>`).join('')
        + `<ellipse rx="3.8" ry="1" fill="none" stroke="#fff0e0" stroke-opacity="0.45" stroke-width="0.2"/><path d="M0 -3.8Q0.4 -5.2 1.4 -5.6" stroke="#d8f0c8" stroke-width="0.35" fill="none"/><path d="M0.5 -4.6Q2.2 -5.8 2.8 -4.4Q1.6 -4 0.5 -4.6Z" fill="#c8f0d0" opacity="0.7"/></g>`;
      g += `<text x="12" y="10.4" font-family="Arial" font-weight="700" font-size="1.6" fill="#fff4e4">Honeycrisp ×6</text><text x="12" y="12.9" font-family="Arial" font-size="1.3" fill="#f6d8a8">ripe · eat by Fri</text><rect x="12" y="14.2" width="12" height="0.7" rx="0.35" fill="#ffffff" opacity="0.18"/><rect x="12" y="14.2" width="10.4" height="0.7" rx="0.35" fill="#bfe8d8"/>`;
      [['Oat milk', 0.72, '#f2e6d0'], ['Eggs', 0.83, '#ffd890'], ['Berries', 0.4, '#f6a6c0'], ['Gruyère', 0.6, '#f6d878'], ['Caviar', 1, '#c8d8f6']].forEach(([n, f, c], i) => { const y = 19.4 + i * 3.2;
        g += `<circle cx="2.6" cy="${f1(y - 0.5)}" r="0.7" fill="${c}"/><text x="4.2" y="${f1(y)}" font-family="Arial" font-size="1.35" fill="#fff4e4">${n}</text><rect x="12.6" y="${f1(y - 1.1)}" width="9" height="0.9" rx="0.45" fill="#ffffff" opacity="0.16"/><rect x="12.6" y="${f1(y - 1.1)}" width="${f1(9 * f)}" height="0.9" rx="0.45" fill="${c}"><animate attributeName="width" values="${f1(9 * f)};${f1(9 * Math.max(0.15, f - 0.12))};${f1(9 * f)}" dur="${16 + i * 3}s" repeatCount="indefinite"/></rect><text x="${w - 1.4}" y="${f1(y)}" text-anchor="end" font-family="Arial" font-size="1.15" fill="#f6d8a8">${Math.round(f * 100)}%</text>`; });
      g += `<text x="${w / 2}" y="${h - 1.6}" text-anchor="middle" font-family="Arial" font-size="1.2" fill="#f6dca8" letter-spacing="0.3">42 ITEMS · ALL FRESH</text>`;
      g += `<rect width="${w}" height="1.6" fill="url(#k28hsc)" opacity="0.6"><animate attributeName="y" values="0;${h - 1.6};${h - 1.6}" keyTimes="0;0.4;1" dur="9s" repeatCount="indefinite"/></rect>`;
      return `<g opacity="0.92">${an('opacity', '0.86;0.96;0.9;0.96;0.86', 7)}${g}</g>`; };
    const inner = C => { const x0 = -32, x1 = 32, y0 = 54, y1 = 156, z0 = Z0 + 2.5, z1 = ZF, IW = 64, ID = z1 - z0, IH = 102; let o = '', y = y0;
      const led = u => `<rect x="${f1(u)}" y="3" width="1.2" height="${IH - 6}" rx="0.6" fill="#fff0cc"/><rect x="${f1(u - 1.4)}" y="3" width="4" height="${IH - 6}" rx="2" fill="#ffe2a8" opacity="0.4"/>`;
      o += cavity(C, x0, x1, y0, y1, z0, z1, '#ece4d6', { dk: 0.18, back: `<rect width="${IW}" height="${IH}" fill="url(#k28br)" opacity="0.6"/>${[16, 32, 48].map(x => `<path d="M${x} 0V${IH}" stroke="#c8b890" stroke-opacity="0.35" stroke-width="0.3"/>`).join('')}<rect x="3" y="1.4" width="${IW - 6}" height="2.4" rx="1.2" fill="#fff2d0"/><ellipse cx="${IW / 2}" cy="4" rx="${IW * 0.48}" ry="18" fill="url(#k28spW)" opacity="0.8"/>`, left: led(ID - 3), right: led(1.8) });
      // floor: sushi on slate, figs + grapes in crystal, cold-pressed juices
      o += box3(C, { c: [-21, y, 6], w: 17, h: 1.2, d: 9, r: 0.4, col: '#2c2c30', olw: 0.3 });
      [3.8, 8.2].forEach((z, j) => rep(3, i => { const x = -26.4 + i * 5.4, c = (i + j) % 2 ? '#f28a5a' : '#c8283a'; o += box3(C, { c: [x, y + 1.2, z], w: 3.6, h: 1.4, d: 2.4, r: 0.5, col: '#f8f4ea', olw: 0.25 }) + box3(C, { c: [x, y + 2.6, z], w: 3.9, h: 0.7, d: 2.6, r: 0.5, col: c, olw: 0.25, dec: { t: c === '#f28a5a' ? '<path d="M0.8 0.4L1.4 2.2M1.8 0.4L2.4 2.2M2.8 0.4L3.4 2.2" stroke="#ffffff" stroke-opacity="0.6" stroke-width="0.2"/>' : '' } }); }));
      o += cyl3(C, [-4, y, 13], [-4, y + 4, 13], 3.6, '#eef6f6', { r2: 6, n: 26, op: 0.4, mat: 'gloss', olw: 0.3, olc: '#8aa0a4', noCap: 1 }) + grapes(C, -5.4, y + 3, 12, '#6a2a6a') + sph(C, [-0.8, y + 5.4, 14.4], 2, '#6a3a5a') + sph(C, [-2.4, y + 5.8, 10.6], 1.8, '#7a4a62');
      [[12, '#7ab040', 'GREEN'], [18, '#f29a30', 'CITRUS'], [24, '#e86a8a', 'BEET']].forEach(([x, c, t]) => o += bottle(C, x, y, 0, 2.3, 13.6, c, CG, { op: 0.92, lbl: lbl(t) }));
      // shelf 1: caviar on ice, strawberry shortcake, macaron tower under a cloche
      o += gshelf(C, x0, x1, 78, z0 + 0.4, z1 - 0.4, CG); y = 78.8;
      o += cyl3(C, [-22, y, 6], [-22, y + 2.8, 6], 5, '#d8dcdf', { r2: 6, mat: 'metal', n: 26, olw: 0.3, capCol: '#f4fbff', cap: cr => rep(18, i => `<circle cx="${f1(Math.cos(i * 2.4) * cr * (0.3 + (i % 4) * 0.17))}" cy="${f1(Math.sin(i * 2.4) * cr * (0.3 + (i % 4) * 0.17))}" r="0.5" fill="#ffffff" stroke="#c8dce6" stroke-width="0.12"/>`).join('') })
        + cyl3(C, [-22, y + 2.8, 6], [-22, y + 4.8, 6], 3.4, '#2a4a7a', { n: 24, mat: 'gloss', olw: 0.3, capCol: '#2e5288', cap: cr => `<circle r="${f1(cr * 0.86)}" fill="none" stroke="${CG}" stroke-width="0.5"/><text x="0" y="0.4" text-anchor="middle" font-family="Georgia,serif" font-size="0.95" fill="${CG}">OSCIÈTRE</text>` });
      o += cyl3(C, [-5, y, 4], [-5, y + 0.6, 4], 7.6, '#ffffff', { n: 28, olw: 0.3 }) + cyl3(C, [-5, y + 0.6, 4], [-5, y + 7, 4], 6, '#fbf2e4', { n: 28, olw: 0.3, capCol: '#fff8f0' })
        + `<g transform="${tanF(C, -5, 4, 6.02, C.thV, y + 3.8)}"><path d="M-6 0Q-4.5 1 -3 0T0 0T3 0T6 0" stroke="#e8586a" stroke-width="0.8" fill="none"/></g>`;
      rep(7, i => ({ a: i * 0.9, q: [-5 + Math.cos(i * 0.9) * 4, y + 7.8, 4 + Math.sin(i * 0.9) * 4] })).sort((a, b) => a.q[2] - b.q[2]).forEach(b => o += sph(C, b.q, 1.2, '#d8283a')); o += sph(C, [-5, y + 8.2, 4], 1.4, '#e8303e');
      o += cyl3(C, [16, y, 2], [16, y + 0.6, 2], 6.4, '#ffffff', { n: 26, olw: 0.3, capCol: '#fbf8f2' });
      const MC = ['#f6c6d0', '#d8f0c8', '#f6e6b0', '#e0d0f6', '#f6d6b8', '#c8e6f6'];
      rep(6, j => { const rr = 4.2 - j * 0.65, n = 8 - j; rep(n, i => ({ q: [16 + Math.cos(i / n * 2 * PI + j) * rr, y + 1.8 + j * 1.9, 2 + Math.sin(i / n * 2 * PI + j) * rr], c: MC[(i + j) % 6] })).sort((a, b) => a.q[2] - b.q[2]).forEach(m => o += sph(C, m.q, 1.2, m.c)); });
      o += cyl3(C, [16, y + 0.6, 2], [16, y + 13, 2], 5.6, '#eef6f6', { n: 26, op: 0.2, mat: 'gloss', olw: 0.3, olc: '#8aa0a4', noCap: 1 }) + sph(C, [16, y + 13, 2], 5.6, '#eef6f6', { op: 0.16 }) + sph(C, [16, y + 19.2, 2], 0.9, CG);
      // shelf 2: champagne, cheese board, eggs
      o += gshelf(C, x0, x1, 102, z0 + 0.4, z1 - 0.4, CG); y = 102.8;
      o += bottle(C, -25, y, -2, 2.8, 20, '#1e3a24', CG, { lbl: `<rect x="-2.2" y="-1.8" width="4.4" height="3.6" fill="#f2e6c4"/><text x="0" y="0.4" text-anchor="middle" font-family="Georgia,serif" font-size="0.75" fill="#5a3a14">Millésime</text>` });
      o += box3(C, { c: [-9, y, 8], ax: yawA(0.15), w: 16, h: 1.4, d: 9, r: 1, col: '#c8935a', olw: 0.3, dec: { t: rep(5, i => `<path d="M0 ${f1(1.5 + i * 1.6)}H16" stroke="#8a5a2a" stroke-opacity="0.35" stroke-width="0.2"/>`).join('') } })
        + box3(C, { c: [-13.5, y + 1.4, 6.6], ax: yawA(0.5), w: 4, h: 2.6, d: 3, r: 0.2, col: '#f2d070', olw: 0.25, dec: { f: '<circle cx="1.2" cy="1.2" r="0.4" fill="#d8b040"/><circle cx="2.8" cy="1.8" r="0.3" fill="#d8b040"/>' } })
        + box3(C, { c: [-8.6, y + 1.4, 8.8], w: 3.8, h: 2.2, d: 3, r: 0.8, col: '#f6efe0', olw: 0.25 }) + grapes(C, -3.4, y + 1.4, 8, '#a8c060');
      o += box3(C, { c: [14, y, 4], w: 13, h: 2, d: 7, r: 0.8, col: '#f6f2ea', olw: 0.3 }); [2.2, 5.8].forEach(z => [10, 14, 18].forEach(x => o += sph(C, [x, y + 3.2, z], 1.6, '#f2e2cc')));
      // shelf 3: preserves with gold lids, butter bell, lemon water carafe
      o += gshelf(C, x0, x1, 128, z0 + 0.4, z1 - 0.4, CG); y = 128.8;
      [[-25, '#c8283a', 'CERISE'], [-17.6, '#f2a030', 'ABRICOT'], [-10.2, '#6a3a8a', 'FIGUE'], [-2.8, '#f6e6a0', 'MIEL']].forEach(([x, c, t]) => o += jar(C, x, y, 2, 3, 8, c, CG, 0.85, lbl(t)));
      o += cyl3(C, [8, y, 6], [8, y + 0.6, 6], 4.4, '#f6f2ea', { n: 22, olw: 0.3 }) + cyl3(C, [8, y + 0.6, 6], [8, y + 5.4, 6], 3.4, '#f6f2ea', { r2: 2.8, n: 22, olw: 0.3, mat: 'gloss' }) + sph(C, [8, y + 6, 6], 0.9, CG);
      o += cyl3(C, [20, y, 2], [20, y + 9, 2], 3.4, '#f8f6d8', { n: 22, mat: 'matte', olw: 0.2 }) + cyl3(C, [20, y, 2], [20, y + 12, 2], 3.8, '#eaf6f6', { r2: 2.4, n: 22, op: 0.3, mat: 'gloss', olw: 0.35, olc: '#8aa0a4' })
        + [y + 3, y + 6.4].map((yy, i) => `<g transform="${tanF(C, 20, 2, 3.1, C.thV + (i ? 0.4 : -0.3), yy)}"><circle r="1.5" fill="#f6e040" stroke="#e8c020" stroke-width="0.3"/>${rep(6, j => `<path d="M0 0L${f1(Math.cos(j) * 1.2)} ${f1(Math.sin(j) * 1.2)}" stroke="#f8f0a0" stroke-width="0.15"/>`).join('')}</g>`).join('');
      // inventory scan line sweeps down every 12 s
      o += PLN(C, [x0, y1 - 2, z1 - 0.6], [1, 0, 0], [0, -1, 0], `<g opacity="0"><animate attributeName="opacity" values="0;0.75;0.75;0;0" keyTimes="0;0.03;0.27;0.3;1" dur="12s" repeatCount="indefinite"/><animateTransform attributeName="transform" type="translate" values="0 0;0 98;0 98" keyTimes="0;0.3;1" dur="12s" repeatCount="indefinite"/><rect y="-2" width="${IW}" height="4.4" fill="url(#k28hsc)" opacity="0.45"/><rect width="${IW}" height="0.4" fill="#fff0d0"/></g>`);
      o += PLN(C, [x0 + 0.2, y1 - 0.2, z1 - 0.1], [1, 0, 0], [0, -1, 0], `<rect width="${IW - 0.4}" height="${IH}" fill="url(#k28spW)" opacity="0.25"/>`);
      return o; };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const body = box3(C, { c: [0, PY, (Z0 + ZF) / 2], w: W, h: BH, d: BD, r: 1.2, col: IV, gl: 0.55, f: 1.04, skip: { f: 1 }, dec: { r: sR, l: sL, t: sT, b: sB }, olw: 0.5, olo: 0.55 });
      const plin = box3(C, { c: [0, 0, (Z0 + ZF) / 2 - 3], w: W - 8, h: PY, d: BD - 8, r: 0.6, col: '#2a221a', olw: 0.3 });
      const drw = box3(C, { c: [0, PY + 0.4, ZF + DT / 2], w: W - 0.6, h: 39.4, d: DT, r: 1.4, col: IV, gl: 0.6, f: 1.04, olw: 0.45, olo: 0.6, dec: { f: fv ? dwF(C) : '' } }), hy = PY + 35.2, hz = ZF + DT;
      const dh = cyl3(C, [-25, hy, hz], [-25, hy, hz + 2.8], 0.7, CG, { mat: 'metal', n: 12, olw: 0.3 }) + cyl3(C, [25, hy, hz], [25, hy, hz + 2.8], 0.7, CG, { mat: 'metal', n: 12, olw: 0.3 }) + cyl3(C, [-28, hy, hz + 3], [28, hy, hz + 3], 0.95, CG, { mat: 'metal', n: 16, olw: 0.3 });
      let s = shadow(C, 0, -2, 40, 34, 0.75) + PLN(C, [0, 0.06, -2], [1, 0, 0], [0, 0, 1], `<ellipse rx="34" ry="28" fill="url(#k28spW)">${an('opacity', '0.25;0.45;0.25', 9)}</ellipse>`) + plin;
      const dl = open ? swing(C, LDo, 118, 11, 0.85) : door(C, LDo, 0), dr = door(C, RDo, 0);
      if (fv) { const zp = ZF + DT + 6, e = C.P([17.3, DY + 2, ZF + DT + 1]), bl = C.P([3.8, 98, zp]), br = C.P([30.8, 98, zp]), gid = C.u('hb');
        const beam = `<defs><linearGradient id="${gid}" gradientUnits="userSpaceOnUse" x1="${f1(e[0])}" y1="${f1(e[1])}" x2="${f1(e[0])}" y2="${f1(bl[1])}"><stop offset="0" stop-color="#fff0d8" stop-opacity="0.4"/><stop offset="1" stop-color="#ffe8f0" stop-opacity="0.06"/></linearGradient></defs><path d="M${P2(e)}L${P2(bl)}L${P2(br)}Z" fill="url(#${gid})">${an('opacity', '0.7;1;0.7', 7)}</path>`;
        s += inner(C) + body + plate(C) + drw + dh + dr + dl + beam + PLN(C, [3.8, 134, zp], [1, 0, 0], [0, -1, 0], holo()); }
      else s += dl + dr + dh + drw + body;
      if (fv && open) s += PLN(C, [-14, 0.08, ZF + 16], [1, 0, 0], [0, 0, 1], `<ellipse rx="26" ry="12" fill="url(#m10mst)" opacity="0.4">${an('opacity', '0.3;0.55;0.3', 4)}</ellipse>`) + wisp(C, [-20, 52, ZF + 4], 0.9, 6, 0, 2, 30) + wisp(C, [-10, 52, ZF + 4], 0.8, 6, -3, -2, 34) + mist(C, -16, 80, ZF + 3, 4, 1.1);
      return { defs: DEF28, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-018 SINGLE-BURNER PLUG-IN COIL HOT PLATE =======================
  // a yellowed "HEAT-O-MATIC" hot plate on an upside-down blue milk crate (embossed text upside down, cracked corner, scuffs), greasy chrome drip pan with a heat-tinted
  // ring, black spiral coil, dented aluminium saucepan of ramen (egg half, scallions) with a wooden spoon, salt shaker; frayed cord with electrical tape (sparks now
  // and then) into a cheap power strip. On (cooking): the coil glows and breathes red-orange, the pilot + strip switch light up, the broth bubbles and steams.
  N.hotp28 = S => { const on = isPlay(S), CH = 26, PZ = -2.5, PY = 34.4, BY = 27.2;
    const D = { w: 44, d: 40, arch: 'hotplate', act: 'cook', use: { x: 0, z: 46 }, build: () => [] };
    const R = rng('hotp28');
    const holes = (W, H, top, slot) => { const cols = Math.max(2, Math.floor((W - 3) / 4.4)), cw = (W - 3) / cols, rows = 4, rh = (H - 7.4) / rows; let s = '';
      rep(rows, j => { if (slot && j === 0) { s += `<rect x="${f1(W * 0.3)}" y="${f1(top + 0.4)}" width="${f1(W * 0.4)}" height="${f1(rh - 0.8)}" rx="${f1((rh - 0.8) / 2)}" fill="#0f1822" opacity="0.9"/>`; return; }
        rep(cols, i => s += `<rect x="${f1(1.5 + i * cw + 0.6)}" y="${f1(top + j * rh + 0.6)}" width="${f1(cw - 1.2)}" height="${f1(rh - 1.2)}" rx="0.7" fill="#0f1822" opacity="0.88"/>`); }); return s; };
    const cF = holes(40, CH, 3.6) + `<text x="20" y="${CH - 1.1}" text-anchor="middle" ${FONT} font-size="1.9" fill="#2a5a94" opacity="0.85" letter-spacing="0.3" transform="rotate(180 20 ${CH - 1.7})">DAIRYLAND · DO NOT REMOVE</text>`
      + scr(R, 10, 1, 1, 38, 24, '#ffffff', 0.35) + '<path d="M37.6 0l-1.3 2.8 0.9 1.4 -1.5 2.4" stroke="#14243a" stroke-width="0.4" fill="none"/>';
    const cS = holes(34, CH, 3.6, 1) + scr(R, 8, 1, 1, 32, 24, '#ffffff', 0.3), cB = holes(40, CH, 3.6) + scr(R, 6, 1, 1, 38, 24, '#ffffff', 0.3);
    const cT = rep(6, j => rep(8, i => `<rect x="${f1(2 + i * 4.6)}" y="${f1(2 + j * 5.1)}" width="3.4" height="3.8" rx="0.5" fill="#0f1822" opacity="0.85"/>`).join('')).join('');
    const bF = `<text x="2" y="3.8" ${FONT} font-size="1.65" fill="#8a2a1e" opacity="0.65" letter-spacing="0.3">HEAT-O-MATIC</text>` + rep(4, i => { const a = (-150 + i * 60) * PI / 180; return `<circle cx="${f1(25 + Math.cos(a) * 2.7)}" cy="${f1(3 + Math.sin(a) * 2.7)}" r="0.22" fill="#3a3a3a"/>`; }).join('')
      + `<circle cx="20" cy="3" r="0.8" fill="${on ? '#ff5a3a' : '#5a1a14'}"/>` + (on ? `<circle cx="20" cy="3" r="1.8" fill="#ff6a3a" opacity="0.5" filter="url(#m10b1)">${an('opacity', '0.4;0.7;0.4', 2.4)}</circle>` : '')
      + '<path d="M0 4.2Q1.4 4 2 6H0Z" fill="#2a2a2a"/><circle cx="1" cy="5.4" r="0.3" fill="#8a4a22"/><path d="M8 0.2q0.3 1.6 0 2.4M16.6 0.2q0.2 1 0 1.4" stroke="#8a6a3a" stroke-opacity="0.35" stroke-width="0.5"/>';
    const bT = `<circle cx="15" cy="12.5" r="12.6" fill="none" stroke="#6a4a2a" stroke-opacity="0.32" stroke-width="1.8" filter="url(#m10b1)"/>` + rep(9, () => `<ellipse cx="${f1(2 + R() * 26)}" cy="${f1(1 + R() * 24)}" rx="${f1(0.3 + R() * 0.8)}" ry="${f1(0.2 + R() * 0.5)}" fill="#8a6a3a" opacity="${n4(0.2 + R() * 0.3)}"/>`).join('')
      + [[1.6, 1.6], [28.4, 1.6], [1.6, 24.4], [28.4, 24.4]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="0.5" fill="#9a9488"/><path d="M${x - 0.4} ${y}h0.8" stroke="#5a564e" stroke-width="0.15"/>`).join('');
    const bSd = scr(R, 4, 1, 1, 24, 4, '#6a5a44', 0.4) + '<path d="M0 5.4H26" stroke="#000000" stroke-opacity="0.15" stroke-width="0.4"/>';
    const coilD = (() => { let d = ''; const NP = 90; for (let i = 0; i <= NP; i++) { const t = i / NP, a = t * 2.75 * 2 * PI, r = 2 + 8.8 * t; d += (i ? 'L' : 'M') + f1(Math.cos(a) * r) + ' ' + f1(Math.sin(a) * r); } return d + 'L0 -13'; })();
    const coilS = on ? `<path d="${coilD}" stroke="#ff8a3a" stroke-width="3.2" fill="none" stroke-linejoin="round" filter="url(#m10b1)" opacity="0.5">${an('opacity', '0.35;0.7;0.35', 2.6)}</path><path d="${coilD}" stroke="#d8401e" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${coilD}" stroke="#ffc070" stroke-width="0.45" fill="none" stroke-linejoin="round" opacity="0.85">${an('opacity', '0.6;1;0.6', 2.6)}</path>`
      : `<path d="${coilD}" stroke="#2a2a2c" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${coilD}" stroke="#9a9a9a" stroke-opacity="0.45" stroke-width="0.35" fill="none" stroke-linejoin="round" transform="translate(-0.25 -0.3)"/>`;
    const broth = cr => { let s = `<circle r="${f1(cr * 0.9)}" fill="${on ? '#dca452' : '#cfa058'}"/><circle r="${f1(cr * 0.9)}" fill="none" stroke="#9a9ea2" stroke-width="${f1(cr * 0.1)}"/>`;
      s += rep(7, i => `<path d="M${f1(-cr * 0.62)} ${f1(-cr * 0.5 + i * cr * 0.16)}q${f1(cr * 0.1)} ${f1(-cr * 0.1)} ${f1(cr * 0.2)} 0t${f1(cr * 0.2)} 0t${f1(cr * 0.2)} 0t${f1(cr * 0.2)} 0t${f1(cr * 0.2)} 0" stroke="#f6e2a0" stroke-width="0.45" fill="none"/>`).join('');
      s += `<ellipse cx="${f1(cr * 0.3)}" cy="${f1(-cr * 0.2)}" rx="${f1(cr * 0.28)}" ry="${f1(cr * 0.2)}" fill="#fbf8f0"/><circle cx="${f1(cr * 0.32)}" cy="${f1(-cr * 0.19)}" r="${f1(cr * 0.12)}" fill="#f2a830"/>` + rep(6, i => `<circle cx="${f1(Math.cos(i * 2.1) * cr * 0.55)}" cy="${f1(Math.sin(i * 1.7) * cr * 0.5)}" r="0.45" fill="none" stroke="#5aa83a" stroke-width="0.3"/>`).join('');
      if (on) s += rep(9, i => { const x = Math.cos(i * 2.6) * cr * 0.6, y = Math.sin(i * 1.9) * cr * 0.55, d = 1.1 + (i % 4) * 0.35; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.1" fill="none" stroke="#fff4d8" stroke-width="0.25"><animate attributeName="r" values="0.1;0.75;0.1" dur="${n4(d)}s" begin="-${n4(i * 0.3)}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.9;0.6;0" dur="${n4(d)}s" begin="-${n4(i * 0.3)}s" repeatCount="indefinite"/></circle>`; }).join('');
      return s; };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), rv = vis(C, [1, 0, 0]);
      const crate = box3(C, { c: [0, 0, -1], w: 40, h: CH, d: 34, r: 1.4, col: '#4277b8', gl: 0.3, olw: 0.45, olo: 0.65, dec: { f: cF, b: cB, r: cS, l: cS, t: cT } });
      const tp = [20.8, 14.2, -2.2], cord = curve(C, [[13.6, 29.6, -8], [21, 27, -7], [20.6, 20, -4], tp], '#2a2826', 0.8) + curve(C, [tp, [21, 6, 0], [21, 0.8, 9], [13.4, 4.6, 17.6]], '#2a2826', 0.8)
        + cyl3(C, [20.7, 15.8, -2.6], [20.9, 12.6, -1.9], 0.85, '#141414', { mat: 'gloss', n: 12, olw: 0.25 });
      const sp = C.P([21.8, 14.6, -1.4]), spark = `<g transform="translate(${P2(sp)}) scale(${n4(C.k)})" opacity="0"><animate attributeName="opacity" values="0;0;1;0;0.8;0;0" keyTimes="0;0.9;0.905;0.92;0.93;0.95;1" dur="14s" repeatCount="indefinite"/><path d="M0 0l1.6 -1.2M0 0l1.8 0.4M0 0l0.6 -1.9M0 0l1.1 1.3" stroke="#ffe27a" stroke-width="0.3" stroke-linecap="round"/><circle r="0.6" fill="#fff6c0"/></g>`;
      const strip = box3(C, { c: [10, 0, 18], ax: yawA(0.25), w: 11, h: 2.6, d: 4.2, r: 0.8, col: '#ece4d2', olw: 0.35, dec: { t: rep(3, i => `<rect x="${f1(1.2 + i * 2.4)}" y="1.2" width="1.4" height="1.8" rx="0.3" fill="#3a3632"/>`).join('') + `<rect x="8.6" y="1" width="1.8" height="2.2" rx="0.4" fill="${on ? '#ff7a2a' : '#c85a2a'}"/>` + (on ? `<rect x="8.1" y="0.5" width="2.8" height="3.2" rx="0.8" fill="#ffaa5a" opacity="0.55" filter="url(#m10b1)"/>` : ''), f: scr(R, 4, 0.5, 0.5, 10, 1.6, '#6a5a44', 0.4) } })
        + box3(C, { c: [13.2, 2.4, 17.6], ax: yawA(0.25), w: 2.4, h: 2.2, d: 2.2, r: 0.4, col: '#1e1c1c', olw: 0.3 });
      const feet = [[-12, -12], [12, -12], [-12, 8], [12, 8]].map(([x, z]) => cyl3(C, [x, CH, z], [x, BY, z], 1.3, '#222222', { mat: 'matte', n: 12, olw: 0.25 })).join('');
      const body = box3(C, { c: [0, BY, -2], w: 30, h: 6, d: 26, r: 2.6, col: '#e4dac4', gl: 0.25, f: 1.04, olw: 0.45, olo: 0.7, dec: { f: bF, t: bT, r: bSd, l: bSd, b: bSd } });
      const knob = cyl3(C, [10, 30.2, 11], [10, 30.2, 12.8], 2.1, '#1e1e20', { mat: 'gloss', n: 18, olw: 0.3, cap: cr => rep(10, i => `<path d="M0 ${f1(-cr * 0.78)}V${f1(-cr * 0.95)}" stroke="#5a5a5a" stroke-width="0.2" transform="rotate(${i * 36})"/>`).join('') + `<path d="M0 0V${f1(-cr * 0.8)}" stroke="#f4f0e4" stroke-width="0.5" stroke-linecap="round" transform="rotate(${on ? 120 : 0})"/>` });
      const pan = cyl3(C, [0, BY + 6, PZ], [0, BY + 6.5, PZ], 11.4, '#c4c8cc', { mat: 'chrome', n: 30, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.72)}" fill="none" stroke="#c8a05a" stroke-opacity="0.3" stroke-width="2"/><circle r="${f1(cr * 0.88)}" fill="none" stroke="#6a8ac8" stroke-opacity="0.16" stroke-width="1.2"/><circle r="${f1(cr * 0.9)}" fill="none" stroke="#7a5a2a" stroke-opacity="0.3" stroke-width="0.8"/>` + rep(6, i => `<ellipse cx="${f1(Math.cos(i * 1.7) * cr * 0.8)}" cy="${f1(Math.sin(i * 1.7) * cr * 0.8)}" rx="0.9" ry="0.5" fill="#6a4a22" opacity="0.35"/>`).join('') });
      const coil = PLN(C, [0, PY, PZ], [1, 0, 0], [0, 0, 1], coilS), glow = on ? PLN(C, [0, PY - 0.2, PZ], [1, 0, 0], [0, 0, 1], `<ellipse rx="15" ry="15" fill="url(#k28cg)">${an('opacity', '0.55;0.9;0.55', 2.6)}</ellipse>`) : '';
      const pot = cyl3(C, [0, PY + 0.8, PZ], [0, PY + 8.8, PZ], 7.2, '#b9bdc0', { r2: 8, mat: 'metal', n: 28, olw: 0.35, capCol: '#9a9ea2', cap: broth })
        + `<g transform="${tanF(C, 0, PZ, 7.75, C.thV - 0.5, PY + 4.6)}"><ellipse rx="1.8" ry="1.2" fill="#000000" opacity="0.2" filter="url(#m10b1)"/><path d="M-1.4 -0.6Q0 0.8 1.4 -0.4" stroke="#ffffff" stroke-opacity="0.4" stroke-width="0.2" fill="none"/></g>`
        + (on ? `<g transform="${tanF(C, 0, PZ, 7.3, C.thV, PY + 1.6)}"><ellipse rx="6" ry="1.2" fill="#ff7a3a" opacity="0.35" filter="url(#m10b1)">${an('opacity', '0.2;0.45;0.2', 2.6)}</ellipse></g>` : '');
      const ex = [Math.cos(0.55), 0, -Math.sin(0.55)], hv = dot(ex, C.v) > 0, hc = d => [ex[0] * d, PY + 5.2, PZ + ex[2] * d];
      const hdl = box3(C, { c: hc(9.2), ax: yawA(0.55), w: 3, h: 2.6, d: 3, r: 0.3, col: '#a8acb0', olw: 0.3 }) + box3(C, { c: [hc(15.6)[0], PY + 5.6, hc(15.6)[2]], ax: yawA(0.55), w: 10, h: 1.8, d: 2.3, r: 0.8, col: '#1e1c1c', gl: 0.3, olw: 0.3 });
      const sa = C.P([-2.6, PY + 7.8, PZ + 1]), sb = C.P([-10.4, PY + 18.4, PZ + 4.6]), spoon = `<path d="M${P2(sa)}L${P2(sb)}" stroke="#b88a52" stroke-width="${f1(0.95 * C.k)}" stroke-linecap="round"/><path d="M${P2(sa)}L${P2(sb)}" stroke="#e0b880" stroke-opacity="0.6" stroke-width="${f1(0.3 * C.k)}"/>`;
      const salt = cyl3(C, [-16.4, CH, 11], [-16.4, CH + 4.4, 11], 1.5, '#f4f4f0', { mat: 'gloss', op: 0.75, n: 16, olw: 0.25, olc: '#8a8a86' }) + cyl3(C, [-16.4, CH + 4.4, 11], [-16.4, CH + 5.8, 11], 1.5, '#c8ccd0', { r2: 1.1, mat: 'chrome', n: 16, olw: 0.25 });
      let s = shadow(C, 0, 0, 26, 22, 0.85);
      if (!rv) s += cord + spark; if (!fv) s += strip;
      s += crate;
      if (rv) s += cord + spark; if (fv) s += strip;
      s += feet + (fv ? '' : salt) + (fv ? body + knob : knob + body) + pan + glow + coil + (hv ? pot + hdl : hdl + pot) + spoon + (fv ? salt : '');
      if (on) s += mist(C, 0, PY + 11, PZ, 4, 0.7);
      return { defs: DEF28, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= COOKING RANGES (038 / 058 / 078): shared bits =======================
  // fx-only like the fridges; D keeps the old ARCH.stove size (w 82 d 62, use z 60), arch 'stove', act 'cook', r.kind 'stove' (st 'play' = on).
  // Draw order: front parts (doors, handles, knobs, towel) after the body when the front faces you; cooktop items sorted by depth; the backguard goes before
  // the cooktop items when the front faces you, after them from behind. Flames split into a back half (under the pot) and a front half (over the pot).
  const DEFR = DEF28
    + '<linearGradient id="k28ov" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe09a"/><stop offset="0.35" stop-color="#f2a04a"/><stop offset="1" stop-color="#7a3418"/></linearGradient>'
    + '<linearGradient id="k28ovd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a2724"/><stop offset="1" stop-color="#0e0d0c"/></linearGradient>'
    + '<radialGradient id="k28ft" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ff5a24" stop-opacity="0.75"/><stop offset="0.45" stop-color="#c8301a" stop-opacity="0.35"/><stop offset="1" stop-color="#8a1a10" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="k28bf" cx="50%" cy="50%" r="50%"><stop offset="0.5" stop-color="#4a7aff" stop-opacity="0.45"/><stop offset="1" stop-color="#4a7aff" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="k28wok" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#141210"/><stop offset="0.7" stop-color="#2a2624"/><stop offset="1" stop-color="#4a4440"/></radialGradient>';
  const vsort = (C, L) => L.sort((a, b) => dot(a.q, C.v) - dot(b.q, C.v)).map(o => o.s).join('');
  const H2 = (C, a, b, w, col, op) => `<path d="M${P2(C.P(a))}L${P2(C.P(b))}" stroke="${col}" stroke-width="${f1(w * C.k)}" stroke-linecap="round"${op ? ` opacity="${op}"` : ''}/>`;
  // electric spiral coil (PLN svg, v = +z): radius R1, turns = n + 0.75 so the terminal leaves toward the back
  const coilD = (R1, turns) => { let d = ''; const NP = Math.round(34 * turns); for (let i = 0; i <= NP; i++) { const t = i / NP, a = t * turns * 2 * PI, r = 1.4 + (R1 - 1.4) * t; d += (i ? 'L' : 'M') + f1(Math.cos(a) * r) + ' ' + f1(Math.sin(a) * r); } return d + 'L0 ' + f1(-R1 - 2.6); };
  const coilG = (d, on, sw) => on ? `<path d="${d}" stroke="#ff8a3a" stroke-width="${f1(sw * 2.4)}" fill="none" stroke-linejoin="round" filter="url(#m10b1)" opacity="0.5">${an('opacity', '0.35;0.7;0.35', 2.6)}</path><path d="${d}" stroke="#d8401e" stroke-width="${sw}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" stroke="#ffc070" stroke-width="${f1(sw * 0.32)}" fill="none" stroke-linejoin="round" opacity="0.85">${an('opacity', '0.6;1;0.6', 2.6)}</path>`
    : `<path d="${d}" stroke="#26262a" stroke-width="${sw}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" stroke="#a8a8a8" stroke-opacity="0.5" stroke-width="${f1(sw * 0.26)}" fill="none" stroke-linejoin="round" transform="translate(-0.2 -0.25)"/>`;
  const coilB = (C, x, z, y, R1, on, R) => cyl3(C, [x, y - 0.9, z], [x, y + 0.1, z], R1 + 2.4, '#d4d8dc', { mat: 'chrome', n: 28, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.62)}" fill="#3a3a3c" opacity="0.5"/><circle r="${f1(cr * 0.8)}" fill="none" stroke="#c8a05a" stroke-opacity="0.3" stroke-width="1.6"/><circle r="${f1(cr * 0.93)}" fill="none" stroke="#6a8ac8" stroke-opacity="0.16" stroke-width="0.9"/>`
      + rep(4, () => `<ellipse cx="${f1((R() - 0.5) * cr * 1.5)}" cy="${f1((R() - 0.5) * cr * 1.5)}" rx="0.7" ry="0.4" fill="#6a4a22" opacity="${n4(0.18 + R() * 0.2)}"/>`).join('') })
    + (on ? PLN(C, [x, y + 0.2, z], [1, 0, 0], [0, 0, 1], `<circle r="${f1(R1 + 6)}" fill="url(#k28cg)">${an('opacity', '0.55;0.9;0.55', 2.6)}</circle>`) : '')
    + PLN(C, [x, y + 0.7, z], [1, 0, 0], [0, 0, 1], coilG(coilD(R1, R1 > 7 ? 3.75 : 2.75), on, R1 > 7 ? 1.25 : 1.1));
  // gas burner: spreader ring with ports + cap
  const gasB = (C, x, z, y, rr, capCol, capMat) => cyl3(C, [x, y, z], [x, y + 0.8, z], rr * 1.4, '#2a2b2f', { mat: 'metal', n: 24, olw: 0.25, cap: cr => rep(18, i => `<rect x="-0.25" y="${f1(-cr * 0.88)}" width="0.5" height="${f1(cr * 0.14)}" fill="#0c0c0e" transform="rotate(${i * 20})"/>`).join('') })
    + cyl3(C, [x, y + 0.8, z], [x, y + 1.7, z], rr, capCol, { mat: capMat || 'gloss', n: 22, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.62)}" fill="none" stroke="#ffffff" stroke-opacity="0.14" stroke-width="0.4"/><circle r="${f1(cr * 0.3)}" fill="#ffffff" opacity="0.07"/>` });
  // ring of blue gas flames (each licks/flickers); returns { b: behind the pot, f: in front of it }
  const flames = (C, x, y, z, r, n, sz, ph) => { const b = [], f = [];
    for (let i = 0; i < n; i++) { const a = i / n * 2 * PI, dir = [Math.cos(a), 0, Math.sin(a)], p = C.P([x + dir[0] * r, y, z + dir[2] * r]), d = 0.38 + ((i * 7 + (ph || 0)) % 5) * 0.07;
      const g = `<g transform="translate(${P2(p)}) scale(${n4(C.k * sz)})"><g>${at('scale', '1 1;0.9 1.32;1.06 0.8;1 1', d, -n4((i * 0.13) % d), SPL(3))}<path d="M0 0.2C-0.85 -0.3 -0.75 -1.7 0 -3.1C0.75 -1.7 0.85 -0.3 0 0.2Z" fill="#2f62ff" opacity="0.72"/><path d="M0 0.1C-0.42 -0.2 -0.36 -0.9 0 -1.6C0.36 -0.9 0.42 -0.2 0 0.1Z" fill="#c8e4ff" opacity="0.9"/></g></g>`;
      (dot(dir, C.v) > 0 ? f : b).push(g); }
    C.p(x, y + 3.6 * sz, z);
    return { b: PLN(C, [x, y - 0.2, z], [1, 0, 0], [0, 0, 1], `<circle r="${f1(r * 1.4)}" fill="url(#k28bf)">${an('opacity', '0.6;1;0.6', 1.6)}</circle>`) + b.join(''), f: f.join('') }; };
  // cast-iron grate: perimeter + optional mid rails (z) + 4 fingers per burner stopping short of the cap (rr)
  const gbar = (C, x0, x1, z0, z1, y0, y1, col) => ({ q: [(x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2], s: box3(C, { c: [(x0 + x1) / 2, y0, (z0 + z1) / 2], w: x1 - x0, h: y1 - y0, d: z1 - z0, r: 0, col, gl: 0.3, olw: 0.22, olo: 0.7, edge: 0.16 }) });
  const grate = (C, g, y0, y1, col, th) => { th = th || 1.5; const h = th / 2, L = [gbar(C, g.x0, g.x1, g.z0, g.z0 + th, y0, y1, col), gbar(C, g.x0, g.x1, g.z1 - th, g.z1, y0, y1, col), gbar(C, g.x0, g.x0 + th, g.z0 + th, g.z1 - th, y0, y1, col), gbar(C, g.x1 - th, g.x1, g.z0 + th, g.z1 - th, y0, y1, col)];
    (g.mid || []).forEach(zm => L.push(gbar(C, g.x0 + th, g.x1 - th, zm - h, zm + h, y0, y1, col)));
    g.b.forEach(b => { const zb = Math.max(g.z0 + th, ...(g.mid || []).filter(v => v < b.z).map(v => v + h)), zf = Math.min(g.z1 - th, ...(g.mid || []).filter(v => v > b.z).map(v => v - h)), rr = b.rr;
      L.push(gbar(C, g.x0 + th, b.x - rr, b.z - h, b.z + h, y0, y1, col), gbar(C, b.x + rr, g.x1 - th, b.z - h, b.z + h, y0, y1, col), gbar(C, b.x - h, b.x + h, zb, b.z - rr, y0, y1, col), gbar(C, b.x - h, b.x + h, b.z + rr, zf, y0, y1, col)); });
    return L; };
  const knob = (C, x, y, z, dz, r, col, rot, o) => { o = o || {}; return cyl3(C, [x, y, z], [x, y, z + dz], r, col, { mat: o.mat || 'gloss', n: 20, olw: 0.3, r2: o.r2, capCol: o.capCol, cap: cr => (o.fl ? rep(12, i => `<path d="M0 ${f1(-cr * 0.72)}V${f1(-cr * 0.97)}" stroke="${o.fl}" stroke-width="0.24" transform="rotate(${i * 30})"/>`).join('') : '') + `<path d="M0 ${f1(-cr * 0.18)}V${f1(-cr * 0.84)}" stroke="${o.mk || '#2a2a2a'}" stroke-width="${f1(cr * 0.17)}" stroke-linecap="round" transform="rotate(${rot})"/>` }); };
  // a horizontal bar handle on two standoffs in front of a face at z, from x0 to x1
  const barH = (C, x0, x1, y, z, out, r, col, mat, so) => { so = so == null ? 2.6 : so; return [x0 + so, x1 - so].map(x => cyl3(C, [x, y, z], [x, y, z + out], r * 0.72, col, { mat, n: 12, olw: 0.25 })).join('') + cyl3(C, [x0, y, z + out], [x1, y, z + out], r, col, { mat, n: 16, olw: 0.3 }); };
  // pot handle stick from a to b (sorted by facing in the caller)
  const stick = (C, a, b, r, col, mat) => cyl3(C, a, b, r, col, { mat: mat || 'gloss', n: 12, olw: 0.25 });
  const LBL = (x, y, t, sz, col, ex) => `<text x="${x}" y="${y}" text-anchor="middle" ${FONT} font-size="${sz}" fill="${col}"${ex || ''}>${t}</text>`;

  // ======================= KIT-038 4-BURNER FREESTANDING ELECTRIC COIL RANGE =======================
  // warm white enamel with chrome lip + trims, 4 coils in chrome drip bowls (2 big, 2 small), backguard with chrome-skirted white knobs, an analog clock (second hand
  // ticks) and SURFACE / OVEN lamps, black-glass oven door with a chrome handle + a quilted red mitt swaying on it, storage drawer. Cast-iron skillet of pancakes
  // (front left), red enamel kettle (back right), ceramic spoon rest with a wooden turner. On: the two coils under the pans glow, lamps light, the oven window glows
  // with a tray of cookies, a pancake flips every 6 s, the kettle steams and whistles.
  N.coil28 = S => { const on = isPlay(S), BC = '#f6f2ea', W = 80, TY = 62, ZB = -29, ZF = 27, BGZ = ZB + 6, DY = 9.5, DH = 43, PF = 'k28e_';
    const D = { w: 82, d: 62, arch: 'stove', act: 'cook', use: { x: 0, z: 60 }, build: () => [] };
    const R = rng('coil28');
    let bF = `<rect width="${W}" height="2.4" fill="url(#k28chr)"/><text x="40" y="7.4" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-weight="700" font-size="3.6" fill="#9aa0a6" stroke="#5a6066" stroke-width="0.12">Hearthmate</text>`
      + `<rect x="1.4" y="${f1(TY - DY - DH - 0.5)}" width="${W - 2.8}" height="${DH + 1}" rx="1.2" fill="#2a2620" opacity="0.4"/><rect x="1.4" y="${f1(TY - 8.4)}" width="${W - 2.8}" height="7.6" rx="0.8" fill="#2a2620" opacity="0.4"/><rect y="${TY - 0.8}" width="${W}" height="0.8" fill="#1a1814"/>`;
    const sD = `<rect width="56" height="2.4" fill="url(#k28chr)"/>` + scr(R, 7, 2, 10, 50, 46, '#8a8478', 0.25) + `<rect y="${TY - 3}" width="56" height="3" fill="#000000" opacity="0.12"/>`;
    const bB = `<rect x="14" y="14" width="52" height="34" rx="1" fill="#d8d2c4"/>${rep(10, i => `<path d="M18 ${18 + i * 3}H62" stroke="#a8a294" stroke-width="1"/>`).join('')}<rect x="28" y="52" width="24" height="6" rx="0.4" fill="url(#k28chr)"/><text x="40" y="55.8" text-anchor="middle" font-family="Arial" font-size="1.6" fill="#3a3c40">HEARTHMATE ER-30 · 240V</text>`;
    const tD = `<rect x="1" y="7" width="78" height="48" rx="1.4" fill="none" stroke="#c8ccd0" stroke-width="0.8"/>` + rep(10, () => `<ellipse cx="${f1(4 + R() * 72)}" cy="${f1(9 + R() * 44)}" rx="${f1(0.3 + R() * 0.7)}" ry="${f1(0.2 + R() * 0.4)}" fill="#a8865a" opacity="${n4(0.12 + R() * 0.2)}"/>`).join('');
    // oven door: chrome-framed black glass window; on = warm light, rack, tray of cookies
    const WX = 12, WY = 9, WW = 52, WH = 22;
    const cookies = rep(8, i => { const cx = 22 + (i % 4) * 9.6 + (i > 3 ? 4.6 : 0), cy = i > 3 ? 24.6 : 22.2; return `<ellipse cx="${f1(cx)}" cy="${f1(cy)}" rx="3" ry="1.1" fill="#c8843a"/><ellipse cx="${f1(cx - 0.4)}" cy="${f1(cy - 0.3)}" rx="2" ry="0.6" fill="#e0a45a"/><circle cx="${f1(cx + 0.8)}" cy="${f1(cy - 0.2)}" r="0.35" fill="#4a2a1a"/><circle cx="${f1(cx - 1.2)}" cy="${f1(cy)}" r="0.3" fill="#4a2a1a"/>`; }).join('');
    const win = `<rect x="${WX - 1.4}" y="${WY - 1.4}" width="${WW + 2.8}" height="${WH + 2.8}" rx="1.6" fill="url(#k28chr)"/><rect x="${WX}" y="${WY}" width="${WW}" height="${WH}" rx="1" fill="url(#k28ovd)"/>`
      + (on ? `<rect x="${WX}" y="${WY}" width="${WW}" height="${WH}" rx="1" fill="url(#k28ov)">${an('opacity', '0.85;1;0.85', 3)}</rect><ellipse cx="${WX + 8}" cy="${WY + 3}" rx="5" ry="3" fill="#fff4c8" opacity="0.7" filter="url(#m10b1)"/>` : '')
      + `<path d="M${WX + 1} ${WY + 8}H${WX + WW - 1}M${WX + 1} ${WY + 17}H${WX + WW - 1}" stroke="${on ? '#8a4a24' : '#3a3630'}" stroke-width="0.5"/>` + (on ? `<rect x="19" y="25.4" width="38" height="1.2" rx="0.4" fill="#6a5a4a"/>` + cookies + rep(5, i => `<path d="M${22 + i * 8} 21Q${23 + i * 8} 18 ${22 + i * 8} 15" stroke="#fff2d0" stroke-opacity="0" stroke-width="0.5" fill="none">${an('stroke-opacity', '0;0.5;0', 3.4, -i * 0.7)}</path>`).join('') : `<rect x="19" y="25.4" width="38" height="1.2" rx="0.4" fill="#2a2622"/>`)
      + `<g transform="translate(${WX} ${WY})">${refl(WW, WH)}</g>`;
    const dDec = `<rect x="2" y="1" width="72" height="0.8" fill="#ffffff" opacity="0.55"/>` + win + LBL(38, 37.4, 'BAKE · BROIL · CLEAN', 1.5, '#a8a49a', ' letter-spacing="0.4"') + fp(60, 14, 1, 20, 0.08) + fp(18, 30, 0.9, -10, 0.07);
    // backguard face (80 x 19): knob bezels, clock, lamps
    const KX = [-33, -24, -13, 13, 24, 33], KL = ['LR', 'LF', 'OVEN', 'TIMER', 'RF', 'RR'], KON = [0, 1, 1, 0, 0, 1];
    let bgF = `<rect width="${W}" height="1.6" fill="url(#k28chr)"/><rect y="17.6" width="${W}" height="1.4" fill="url(#k28chr)"/>` + KX.map((x, i) => `<circle cx="${x + 40}" cy="10.5" r="3.4" fill="#000000" opacity="0.08"/>` + LBL(x + 40, 16.4, KL[i], 1.3, '#7a766c')).join('');
    bgF += `<circle cx="40" cy="8.8" r="5.8" fill="url(#k28chr)"/><circle cx="40" cy="8.8" r="5" fill="#fbf8ee"/>` + rep(12, i => `<path d="M40 4.2V${i % 3 ? 4.8 : 5.3}" stroke="#3a3a3a" stroke-width="${i % 3 ? 0.18 : 0.32}" transform="rotate(${i * 30} 40 8.8)"/>`).join('')
      + `<path d="M40 8.8V6.2" stroke="#2a2a2a" stroke-width="0.45" stroke-linecap="round" transform="rotate(250 40 8.8)"/><path d="M40 8.8V5" stroke="#2a2a2a" stroke-width="0.3" stroke-linecap="round" transform="rotate(48 40 8.8)"/>`
      + `<path d="M40 9.8V4.6" stroke="#c8352a" stroke-width="0.16"><animateTransform attributeName="transform" type="rotate" values="${rep(60, i => `${i * 6} 40 8.8`).join(';')}" calcMode="discrete" dur="60s" repeatCount="indefinite"/></path><circle cx="40" cy="8.8" r="0.4" fill="#c8352a"/><path d="M36.4 6Q38 4.6 40.4 4.4" stroke="#ffffff" stroke-width="0.5" fill="none" opacity="0.8"/>`;
    [[36.6, '#ff4a2a', '#6a1e14', 'SURFACE'], [43.4, '#ffb02a', '#6a4a14', 'OVEN']].forEach(([x, c1, c0, t]) => bgF += `<circle cx="${x}" cy="16" r="0.75" fill="${on ? c1 : c0}"/>` + (on ? `<circle cx="${x}" cy="16" r="1.8" fill="${c1}" opacity="0.45" filter="url(#m10b1)"/>` : '') + LBL(x + (x < 40 ? -3.8 : 3.4), 16.5, t, 0.9, '#7a766c'));
    const defs = DEFR + `<defs>${sym(PF + 'd', dDec)}${sym(PF + 'bg', bgF)}</defs>`;
    // quilted oven mitt hanging off the handle
    const mitt = `<g>${at('rotate', '-3.5 3.6 -1;3.5 3.6 -1;-3.5 3.6 -1', 5.2, 0, SPL(2))}<path d="M3 -1.6Q3.6 -3.2 4.4 -1.6" stroke="#efe6d4" stroke-width="0.5" fill="none"/><path d="M0.6 0H7.2V9.4Q7.2 13.4 4 13.4Q0.6 13.4 0.6 10Z" fill="#c8352a"/><path d="M0.8 5.6Q-1.8 5.8 -1.6 3.2Q-1.3 1.4 0.8 1.8Z" fill="#b82e24"/>`
      + `<clipPath id="${PF}mc"><path d="M0.6 0H7.2V9.4Q7.2 13.4 4 13.4Q0.6 13.4 0.6 10Z"/></clipPath><g clip-path="url(#${PF}mc)">${rep(7, i => `<path d="M${-6 + i * 2.6} 0L${i * 2.6 + 4} 14M${i * 2.6 + 4} 0L${-6 + i * 2.6} 14" stroke="#8a1e18" stroke-width="0.2" opacity="0.6"/>`).join('')}<rect x="0" y="0" width="8" height="14" fill="url(#m10v)"/></g><rect x="0.4" y="-0.2" width="7" height="2.6" rx="0.7" fill="#f2ece0"/><path d="M0.6 1.2H7.2" stroke="#c8c0b0" stroke-width="0.2"/></g>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const body = box3(C, { c: [0, 0, (ZB + ZF) / 2], w: W, h: TY, d: ZF - ZB, r: 1.8, col: BC, gl: 0.45, f: 1.12, olw: 0.55, olo: 0.6, dec: { f: bF, r: sD, l: sD, b: bB, t: tD } });
      const door = box3(C, { c: [0, DY, ZF + 1], w: 76, h: DH, d: 2, r: 0.8, col: BC, gl: 0.5, f: 1.12, olw: 0.4, olo: 0.6, dec: { f: use(PF + 'd') } });
      const drawer = box3(C, { c: [0, 1.6, ZF + 0.8], w: 76, h: 6.4, d: 1.6, r: 0.6, col: BC, gl: 0.45, f: 1.1, olw: 0.35, olo: 0.6, dec: { f: `<rect x="28" y="1.4" width="20" height="1.8" rx="0.9" fill="#3a3630" opacity="0.55"/><rect x="28" y="2.9" width="20" height="0.4" fill="#ffffff" opacity="0.6"/>` } });
      const hy = DY + DH - 3.6, handle = barH(C, -30, 30, hy, ZF + 2, 3.2, 1.2, '#d8dcdf', 'chrome', 3);
      const mt = PLN(C, [12, hy + 0.6, ZF + 6.6], [1, 0, 0], [0, -1, 0], mitt);
      const front = fv ? body + drawer + door + handle + mt : mt + handle + door + drawer + body;
      const burners = coilB(C, -19, 10, TY, 8.2, on, R) + coilB(C, 19, 12, TY, 6, false, R) + coilB(C, -19, -14, TY, 6, false, R) + coilB(C, 19, -12, TY, 8.2, on, R);
      // backguard + knobs
      const bgB = box3(C, { c: [0, TY, ZB + 3], w: W, h: 19, d: 6, r: 1.2, col: BC, gl: 0.45, f: 1.12, olw: 0.45, olo: 0.6, dec: { f: use(PF + 'bg'), t: '<rect x="6" y="2" width="68" height="2" rx="1" fill="#3a3630" opacity="0.4"/>' } });
      const knobs = KX.map((x, i) => cyl3(C, [x + 0, TY + 8.5, BGZ], [x, TY + 8.5, BGZ + 0.7], 3, '#d8dcdf', { mat: 'chrome', n: 20, olw: 0.25 }) + knob(C, x, TY + 8.5, BGZ + 0.7, 2.4, 2.3, '#f4f2ec', on && KON[i] ? 140 : i === 3 ? 60 : 0, { fl: '#c8c4b8', mk: '#c8352a' })).join('');
      const bg = fv ? bgB + knobs : knobs + bgB;
      // skillet of pancakes (front left)
      const SX = -19, SZ = 10, ST = TY + 3.6, sdir = [-0.94, 0, 0.34];
      const pk = (cx, cy, r) => `<circle cx="${cx}" cy="${cy}" r="${r}" fill="#c88a3e"/><circle cx="${cx}" cy="${cy}" r="${f1(r * 0.8)}" fill="#e0aa5a"/><circle cx="${f1(cx - r * 0.2)}" cy="${f1(cy - r * 0.2)}" r="${f1(r * 0.4)}" fill="#f0c878" opacity="0.7"/>` + rep(5, i => `<circle cx="${f1(cx + Math.cos(i * 2.3) * r * 0.5)}" cy="${f1(cy + Math.sin(i * 2.3) * r * 0.5)}" r="0.22" fill="#a8702a" opacity="0.7"/>`).join('');
      const pan = cyl3(C, [SX, TY + 0.4, SZ], [SX, ST, SZ], 9, '#34312e', { r2: 9.8, mat: 'metal', n: 30, olw: 0.35, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#1c1a18"/><circle r="${f1(cr * 0.9)}" fill="none" stroke="#4a4642" stroke-width="0.5"/>` + pk(-3, 1.4, 4.2) + `<rect x="-4.4" y="0.2" width="2.2" height="1.6" rx="0.4" fill="#f8e48a" transform="rotate(14)"/>` + (on ? '' : pk(3, -2.8, 3.8)) + (on ? rep(6, i => `<circle cx="${f1(Math.cos(i * 1.9) * 6)}" cy="${f1(Math.sin(i * 1.9) * 6)}" r="0.2" fill="none" stroke="#f8e8b0" stroke-width="0.2">${an('r', '0.2;0.8;0.2', 0.7 + i * 0.13, -i * 0.2)}</circle>`).join('') : '') });
      const sh0 = add([SX, TY + 3, SZ], mul(sdir, 9.4)), sh1 = add([SX, TY + 3.8, SZ], mul(sdir, 18.4)), shd = stick(C, sh0, sh1, 1.15, '#2e2b28', 'metal') + sph(C, sh1, 1.3, '#2e2b28');
      const KT2 = ' keyTimes="0;0.6;0.7;0.8;1"';
      const flipP = on ? `<g>${at('translate', `0 0;0 0;0 ${f1(-13 * C.k)};0 0;0 0`, 6, 0, KT2)}${PLN(C, [SX + 3, ST + 0.15, SZ - 2.8], [1, 0, 0], [0, 0, 1], `<g>${at('scale', '1 1;1 1;1 -1;1 1;1 1', 6, 0, KT2)}${pk(0, 0, 3.8)}</g>`)}</g>` : '';
      const skillet = { q: [SX, TY + 2, SZ], s: (dot(sdir, C.v) > 0 ? pan + shd : shd + pan) + flipP };
      // red enamel kettle (back right)
      const KXX = 19, KZ = -12, kdir = [-0.8, 0, 0.6], kb = cyl3(C, [KXX, TY + 0.3, KZ], [KXX, TY + 1.4, KZ], 7.1, '#c8ccd0', { mat: 'chrome', n: 28, olw: 0.25, noCap: 1 }) + cyl3(C, [KXX, TY + 1.4, KZ], [KXX, TY + 7.6, KZ], 6.9, '#d8453a', { r2: 6, mat: 'gloss', n: 28, olw: 0.35, noCap: 1 }) + cyl3(C, [KXX, TY + 7.6, KZ], [KXX, TY + 10.4, KZ], 6, '#d8453a', { r2: 2.6, mat: 'gloss', n: 28, olw: 0.35, capCol: '#c83a30' })
        + `<g transform="${tanF(C, KXX, KZ, 6.6, C.thV, TY + 4.4)}"><path d="M-3 0Q0 -1.4 3 0" stroke="#ffffff" stroke-width="0.5" fill="none" opacity="0.7"/><circle r="1" fill="#ffffff" opacity="0.8"/></g>`;
      const lid = sph(C, [KXX, TY + 11.2, KZ], 1.2, '#f4f0e4');
      const sp0 = add([KXX, TY + 4, KZ], mul(kdir, 5.2)), sp1 = add([KXX, TY + 9.6, KZ], mul(kdir, 11)), spout = cyl3(C, sp0, sp1, 1.7, '#d8453a', { r2: 0.7, mat: 'gloss', n: 14, olw: 0.3 }) + cyl3(C, sp1, add(sp1, [kdir[0] * 1.2, 0.8, kdir[2] * 1.2]), 0.75, '#c8ccd0', { mat: 'chrome', n: 10, olw: 0.25 });
      const kh = curve(C, [[KXX + 4.2, TY + 9.4, KZ - 3], [KXX + 3, TY + 17, KZ - 2], [KXX - 3, TY + 17, KZ + 2], [KXX - 4.2, TY + 9.4, KZ + 3]], '#1e1c1c', 1.4) + curve(C, [[KXX + 3, TY + 13.6, KZ - 2.2], [KXX + 2, TY + 15.8, KZ - 1.4], [KXX - 2, TY + 15.8, KZ + 1.4], [KXX - 3, TY + 13.6, KZ + 2.2]], '#5a5450', 0.3);
      const tip = C.P(add(sp1, [kdir[0] * 1.6, 1.2, kdir[2] * 1.6]));
      const whistle = on ? `<g transform="translate(${P2(tip)}) scale(${n4(C.k)})">${rep(3, i => `<path d="M${-1 - i * 1.6} ${-1 - i * 1.4}q-1 -1 0 -2" stroke="#6a7a8a" stroke-width="0.3" fill="none" opacity="0">${an('opacity', '0;0.8;0', 1.2, -i * 0.3)}</path>`).join('')}</g>` + mist(C, sp1[0] + kdir[0] * 2, sp1[1] + 2, sp1[2] + kdir[2] * 2, 4, 0.55) : '';
      const kettle = { q: [KXX, TY + 5, KZ], s: (dot(kdir, C.v) > 0 ? kb + lid + kh + spout : spout + kb + lid + kh) + whistle };
      // ceramic spoon rest + wooden turner (flat on the deck)
      const rest = PLN(C, [0.5, TY + 0.15, 16], [1, 0, 0], [0, 0, 1], `<ellipse cx="0.3" cy="0.4" rx="3.8" ry="6.6" fill="#000000" opacity="0.12"/><path d="M0 -6.4C3.4 -6.4 3.8 -2 2.4 0.8C1.6 2.6 1.6 4.6 1 6.2Q0 7 -1 6.2C-1.6 4.6 -1.6 2.6 -2.4 0.8C-3.8 -2 -3.4 -6.4 0 -6.4Z" fill="#f2ead6" stroke="#c8b890" stroke-width="0.3"/><path d="M0 -5.2C2.2 -5.2 2.6 -2 1.6 0.2Q0 1.4 -1.6 0.2C-2.6 -2 -2.2 -5.2 0 -5.2Z" fill="#e2d6b8"/>`
        + `<g transform="rotate(-8)"><rect x="-1.8" y="-6" width="3.6" height="5" rx="0.8" fill="#c89a62"/><path d="M-1 -5.2V-1.6M0 -5.2V-1.6M1 -5.2V-1.6" stroke="#a87a44" stroke-width="0.25"/><rect x="-0.5" y="-1.2" width="1" height="11" rx="0.5" fill="#b8884e"/><path d="M0.1 -0.8V9.4" stroke="#e0b880" stroke-width="0.25"/></g>`);
      const items = vsort(C, [skillet, kettle]);
      let s = shadow(C, 0, -1, 46, 34, 0.9) + front + burners + rest + (fv ? bg + items : items + bg);
      if (on) { s += mist(C, SX, ST + 2, SZ, 3, 0.7); C.p(SX, ST + 18, SZ); }
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-058 5-BURNER CONVECTION GAS RANGE WITH CAST-IRON GRATES =======================
  // brushed stainless pro range: island trim, black porcelain deck, 5 sealed burners (centre = dual-ring wok burner) under 3 continuous matte cast-iron grates,
  // control strip with stainless knobs in red bezels + a blue LED display, big black-glass convection door (rear fan + racks), tubular bar handle on standoffs, kick vents.
  // Orange enamel Dutch oven (back left), carbon-steel wok of stir-fry with a wooden handle (centre), stainless pasta pot (front right). On: blue flame rings flicker under
  // the three pots, bezels glow, the fan spins behind the glass and a chicken roasts, stir-fry hops out of the wok, the Dutch oven lid rattles, pasta water boils.
  N.gas28 = S => { const on = isPlay(S), SS = '#c6cacd', W = 80, TY = 62, ZB = -29, ZF = 27, GY = TY + 4.2, DY = 7.4, DH = 42, PF = 'k28g_';
    const D = { w: 82, d: 62, arch: 'stove', act: 'cook', use: { x: 0, z: 60 }, build: () => [] };
    const R = rng('gas28');
    const brushed = (w, h) => `<rect width="${f1(w)}" height="${f1(h)}" fill="url(#k28br)"/><rect width="${f1(w)}" height="${f1(h)}" fill="url(#k28ss)"/>`;
    const KX = [-34, -24, -14, 14, 24, 34], KL = ['LR', 'LF', 'WOK', 'RF', 'RR', 'OVEN'], KON = [1, 0, 1, 1, 0, 1];
    let bF = brushed(W, TY) + `<rect y="1.6" width="${W}" height="10" fill="#000000" opacity="0.06"/><path d="M0 11.6H${W}" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.3"/><path d="M0 1.6H${W}" stroke="#6a7076" stroke-opacity="0.5" stroke-width="0.3"/>`;
    bF += KX.map((x, i) => `<circle cx="${x + 40}" cy="6.6" r="3.5" fill="none" stroke="#b8262a" stroke-width="0.9"/>` + (on && KON[i] ? `<circle cx="${x + 40}" cy="6.6" r="3.6" fill="none" stroke="#ff8a3a" stroke-width="1.6" opacity="0.7" filter="url(#m10b1)">${an('opacity', '0.5;0.85;0.5', 2.2, -i * 0.3)}</circle>` : '') + LBL(x + 40, 11.2, KL[i], 1, '#5a6066')).join('');
    bF += `<rect x="31" y="3.4" width="18" height="6.4" rx="1" fill="#0c0e10"/><rect x="31" y="3.4" width="18" height="2" rx="1" fill="#ffffff" opacity="0.07"/>`
      + (on ? `<text x="40" y="8.2" text-anchor="middle" ${FONT} font-size="3" fill="#7ad0ff">375°</text><text x="34.4" y="5.6" text-anchor="middle" font-family="Arial" font-size="0.9" fill="#7ad0ff">CONV</text><g transform="translate(45.8 6.6)"><g>${at('rotate', '0;360', 1.2)}${rep(4, i => `<path d="M0 0Q0.6 -0.6 0 -1.4" stroke="#7ad0ff" stroke-width="0.3" fill="none" transform="rotate(${i * 90})"/>`).join('')}</g></g>`
        : `<text x="40" y="8.2" text-anchor="middle" ${FONT} font-size="3" fill="#3a6a8a">12<tspan>${an('fill-opacity', '1;1;0;0', 2, 0, ' calcMode="discrete"')}:</tspan>00</text>`);
    bF += `<rect x="1.4" y="${f1(TY - DY - DH - 0.5)}" width="${W - 2.8}" height="${DH + 1}" rx="1" fill="#1a1c1e" opacity="0.45"/><rect y="${f1(TY - 6.6)}" width="${W}" height="6.6" fill="#1e2022"/>` + rep(18, i => `<rect x="${f1(4 + i * 4)}" y="${f1(TY - 5)}" width="2.4" height="3.4" rx="0.4" fill="#08090a"/>`).join('');
    const sD = brushed(56, TY) + `<rect width="56" height="${TY}" fill="url(#m10v)"/><rect y="${TY - 6.6}" width="56" height="6.6" fill="#1e2022"/>`;
    const bB = brushed(W, TY) + `<rect x="30" y="40" width="20" height="6" rx="0.4" fill="url(#k28chr)"/><text x="40" y="43.8" text-anchor="middle" font-family="Arial" font-size="1.5" fill="#3a3c40">FORGE·PRO GR-305 · NAT GAS</text><circle cx="20" cy="52" r="2.2" fill="#c8a040"/><circle cx="20" cy="52" r="1.2" fill="#8a6a2a"/>`;
    const tD = brushed(W, 56) + `<rect x="1.2" y="3.6" width="77.6" height="51.2" rx="1.4" fill="#222327"/><rect x="1.2" y="3.6" width="77.6" height="51.2" rx="1.4" fill="url(#m10noise)"/><rect x="1.2" y="3.6" width="77.6" height="51.2" rx="1.4" fill="none" stroke="#8a9096" stroke-width="0.4"/>`;
    // door: big black glass, rear convection fan (spins when on), racks, roast chicken when on
    const WX = 6, WY = 5, WW = 64, WH = 26, FX = 38, FY = 16.6;
    const chick = `<rect x="21" y="25.6" width="34" height="3.4" rx="0.8" fill="#3a3a3e"/><rect x="21" y="25.6" width="34" height="0.8" fill="#6a6a70"/><ellipse cx="38" cy="22.6" rx="9.4" ry="4.6" fill="#c8782a"/><ellipse cx="36.4" cy="21.2" rx="6" ry="2.4" fill="#e8a24a"/><ellipse cx="35" cy="20.6" rx="2.6" ry="0.9" fill="#fff0c0" opacity="0.6"/>`
      + `<ellipse cx="28.6" cy="24.4" rx="3.2" ry="1.8" fill="#b86a24" transform="rotate(-20 28.6 24.4)"/><ellipse cx="47.4" cy="24.4" rx="3.2" ry="1.8" fill="#b86a24" transform="rotate(20 47.4 24.4)"/><circle cx="26" cy="25.4" r="0.9" fill="#f2e6d0"/><circle cx="50" cy="25.4" r="0.9" fill="#f2e6d0"/>`
      + `<circle cx="52" cy="25" r="1.6" fill="#f2d040"/><circle cx="24" cy="24.4" r="1.4" fill="#d8a838"/>` + rep(5, i => `<path d="M${30 + i * 4} 25.4l1.4 -1.6" stroke="#4a7a2a" stroke-width="0.4"/>`).join('');
    const fan = `<g transform="translate(${FX} ${FY})"><circle r="7" fill="${on ? '#6a3a1a' : '#16171a'}" opacity="0.8"/><g>${on ? at('rotate', '0;360', 0.9) : ''}${rep(6, i => `<path d="M0 0Q2.4 -1.6 1.6 -5.6Q0.4 -3.2 0 0Z" fill="${on ? '#a86a3a' : '#2a2c30'}" transform="rotate(${i * 60})"/>`).join('')}</g>${rep(4, i => `<circle r="${2 + i * 1.6}" fill="none" stroke="${on ? '#c88a5a' : '#3a3c40'}" stroke-width="0.3"/>`).join('')}<circle r="1" fill="${on ? '#d8a070' : '#3a3c40'}"/></g>`;
    const dDec = brushed(76, DH) + `<rect x="${WX - 0.8}" y="${WY - 0.8}" width="${WW + 1.6}" height="${WH + 1.6}" rx="1.6" fill="#0a0b0c"/><rect x="${WX}" y="${WY}" width="${WW}" height="${WH}" rx="1.2" fill="url(#k28ovd)"/>`
      + (on ? `<rect x="${WX}" y="${WY}" width="${WW}" height="${WH}" rx="1.2" fill="url(#k28ov)" opacity="0.85">${an('opacity', '0.75;0.95;0.75', 3)}</rect>` : '') + fan
      + `<path d="M${WX + 1} ${WY + 8}H${WX + WW - 1}M${WX + 1} ${WY + 20.6}H${WX + WW - 1}" stroke="${on ? '#5a3418' : '#2e3034'}" stroke-width="0.5"/>` + (on ? chick : '') + `<g transform="translate(${WX} ${WY})">${refl(WW, WH)}</g>`
      + LBL(38, 36.6, 'CONVECTION', 1.9, '#6a7076', ' letter-spacing="1.2"') + LBL(38, 2.6, 'FORGE &amp; FLAME', 1.3, '#7a8086', ' letter-spacing="0.8"');
    const defs = DEFR + `<defs>${sym(PF + 'f', bF)}${sym(PF + 'd', dDec)}${sym(PF + 's', sD)}</defs>`;
    const BU = [{ x: -26, z: -12, r: 4.2 }, { x: -26, z: 11, r: 5 }, { x: 0, z: -0.5, r: 6, wok: 1 }, { x: 26, z: -12, r: 4.2 }, { x: 26, z: 11, r: 5 }];
    const GR = [{ x0: -39.4, x1: -12.8, z0: -25.4, z1: 24.6, mid: [-0.5], b: [BU[0], BU[1]] }, { x0: -12.4, x1: 12.4, z0: -25.4, z1: 24.6, b: [BU[2]] }, { x0: 12.8, x1: 39.4, z0: -25.4, z1: 24.6, mid: [-0.5], b: [BU[3], BU[4]] }];
    GR.forEach(g => g.b.forEach(b => b.rr = b.r * 1.4 + 1.2));
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const body = box3(C, { c: [0, 0, (ZB + ZF) / 2], w: W, h: TY, d: ZF - ZB, r: 1.6, col: SS, gl: 0.2, mat: 'brush', olw: 0.55, olo: 0.6, dec: { f: use(PF + 'f'), r: use(PF + 's'), l: use(PF + 's'), b: bB, t: tD } });
      const door = box3(C, { c: [0, DY, ZF + 1.2], w: 76, h: DH, d: 2.4, r: 0.8, col: SS, gl: 0.2, mat: 'brush', olw: 0.4, olo: 0.6, dec: { f: use(PF + 'd') } });
      const handle = barH(C, -32, 32, DY + DH - 4, ZF + 2.4, 3.6, 1.35, '#d8dcdf', 'chrome', 2.6);
      const knobs = KX.map((x, i) => knob(C, x, TY - 6.6, ZF, 3.4, 2.7, '#cdd1d4', on && KON[i] ? 150 : 0, { mat: 'chrome', r2: 2.4, fl: '#8a9096', mk: '#1e2022' })).join('');
      const front = fv ? body + door + handle + knobs : knobs + handle + door + body;
      const trim = box3(C, { c: [0, TY, ZB + 1.6], w: W, h: 5.4, d: 3.2, r: 0.6, col: SS, gl: 0.2, mat: 'brush', olw: 0.4, olo: 0.6, dec: { f: '<rect width="80" height="5.4" fill="url(#k28br)"/>' } });
      // burners, flames (lit ones are all under pots), grates
      let caps = ''; BU.forEach(b => { caps += gasB(C, b.x, b.z, TY, b.r, '#1c1c1e'); if (b.wok) caps += cyl3(C, [b.x, TY + 1.7, b.z], [b.x, TY + 2.3, b.z], b.r * 0.45, '#1c1c1e', { mat: 'gloss', n: 16, olw: 0.2 }); });
      const FL = on ? [flames(C, BU[0].x, TY + 1.4, BU[0].z, BU[0].r * 1.3, 12, 0.7, 1), flames(C, BU[2].x, TY + 1.4, BU[2].z, BU[2].r * 1.32, 20, 1.45, 2), flames(C, BU[2].x, TY + 2.2, BU[2].z, BU[2].r * 0.6, 10, 0.9, 3), flames(C, BU[4].x, TY + 1.4, BU[4].z, BU[4].r * 1.3, 14, 1.05, 4)] : [];
      const flB = FL.map(f => f.b).join(''), flF = i => on ? (i === 2 ? FL[1].f + FL[2].f : FL[i === 0 ? 0 : 3].f) : '';
      const bars = vsort(C, [].concat(...GR.map(g => grate(C, g, TY + 0.5, GY, '#232325', 1.5))));
      // Dutch oven (back left)
      const OX = BU[0].x, OZ = BU[0].z, OC = '#d8542a';
      const lidS = cyl3(C, [OX, GY + 8.4, OZ], [OX, GY + 9.6, OZ], 8.9, OC, { r2: 8.2, mat: 'gloss', n: 28, olw: 0.3, noCap: 1 }) + cyl3(C, [OX, GY + 9.6, OZ], [OX, GY + 10.6, OZ], 8.2, OC, { r2: 5.2, mat: 'gloss', n: 28, olw: 0.3, capCol: shade(OC, 1.1) }) + cyl3(C, [OX, GY + 10.6, OZ], [OX, GY + 12.2, OZ], 1.6, '#c8ccd0', { r2: 1.9, mat: 'chrome', n: 14, olw: 0.25 });
      const lid = on ? `<g>${at('translate', `0 0;0 ${f1(-0.6 * C.k)};0 0;0 ${f1(-0.4 * C.k)};0 0;0 0`, 1.3, 0, ' keyTimes="0;0.08;0.16;0.24;0.32;1"')}${lidS}</g>` : lidS;
      const oH = sg => box3(C, { c: [OX + sg * 9.4, GY + 5.6, OZ], w: 2.2, h: 1.8, d: 5.4, r: 0.6, col: shade(OC, 0.92), gl: 0.4, olw: 0.3 });
      const dutch = { q: [OX, GY + 5, OZ], s: (C.v[0] > 0 ? oH(-1) : oH(1)) + cyl3(C, [OX, GY, OZ], [OX, GY + 8.4, OZ], 8.6, OC, { r2: 8.8, mat: 'gloss', n: 28, olw: 0.35, noCap: 1 }) + `<g transform="${tanF(C, OX, OZ, 8.75, C.thV, GY + 4.6)}"><text y="0.6" text-anchor="middle" font-family="Georgia,serif" font-size="1.5" fill="#a83a1a">· COCOTTE ·</text></g>` + lid + (C.v[0] > 0 ? oH(1) : oH(-1)) + flF(0) };
      // wok of stir-fry (centre) with a wooden handle toward the front left
      const WK = BU[2], wdir = [-0.5, 0, 0.866];
      const fry = cr => `<circle r="${f1(cr)}" fill="url(#k28wok)"/>` + rep(16, i => { const a = i * 2.4, rr = (0.12 + (i % 5) * 0.09) * cr, x = f1(Math.cos(a) * rr), y = f1(Math.sin(a) * rr); return [`<circle cx="${x}" cy="${y}" r="1.3" fill="#3a8a2a"/><circle cx="${x}" cy="${y}" r="0.6" fill="#5aaa3a"/>`, `<rect x="${x}" y="${y}" width="2.6" height="0.9" rx="0.4" fill="#d83a2a" transform="rotate(${i * 40} ${x} ${y})"/>`, `<circle cx="${x}" cy="${y}" r="0.9" fill="#f08a2a"/>`, `<ellipse cx="${x}" cy="${y}" rx="1.8" ry="0.7" fill="#8ac84a" transform="rotate(${i * 25} ${x} ${y})"/>`][i % 4]; }).join('') + `<circle r="${f1(cr * 0.55)}" fill="#a8582a" opacity="0.18"/>`;
      const wb = cyl3(C, [WK.x, GY, WK.z], [WK.x, GY + 6.6, WK.z], 4, '#3a3634', { r2: 12, mat: 'metal', n: 32, olw: 0.35, cap: fry });
      const wh0 = add([WK.x, GY + 6, WK.z], mul(wdir, 11.4)), wh1 = add([WK.x, GY + 7, WK.z], mul(wdir, 15.4)), wh2 = add([WK.x, GY + 8.2, WK.z], mul(wdir, 23.4));
      const whd = stick(C, wh0, wh1, 0.8, '#3a3634', 'metal') + stick(C, wh1, wh2, 1.3, '#a87848', 'gloss');
      const toss = on ? (() => { const p = C.P([WK.x, GY + 6, WK.z]); return `<g transform="translate(${P2(p)}) scale(${n4(C.k)})">` + [['#3a8a2a', -3, 1.3], ['#d83a2a', 2.4, 0.9], ['#f08a2a', 0.6, 0.9], ['#8ac84a', -1.4, 1], ['#3a8a2a', 3.6, 1.1]].map(([c, dx, r], i) => `<circle r="${r}" fill="${c}" opacity="0">${at('translate', `${dx} 0;${dx * 1.4} ${-9 - i * 1.6};${dx * 1.6} 0;${dx * 1.6} 0`, 1.8, -i * 0.36, ' keyTimes="0;0.3;0.6;1"')}${an('opacity', '0;1;1;0;0', 1.8, -i * 0.36, ' keyTimes="0;0.05;0.55;0.6;1"')}</circle>`).join('') + '</g>'; })() : '';
      const wok = { q: [WK.x, GY + 4, WK.z], s: (dot(wdir, C.v) > 0 ? wb + toss + whd : whd + wb + toss) + flF(2) };
      // stainless pasta pot (front right)
      const PXX = BU[4].x, PZZ = BU[4].z, pdir = [0.8, 0, 0.6];
      const water = cr => `<circle r="${f1(cr * 0.92)}" fill="#cfdde2"/><circle r="${f1(cr * 0.92)}" fill="none" stroke="#9aa4a8" stroke-width="0.5"/>` + rep(6, i => `<path d="M${f1(-cr * 0.5)} ${f1(-cr * 0.4 + i * cr * 0.16)}q${f1(cr * 0.3)} ${f1(cr * 0.08)} ${f1(cr * 0.8)} 0" stroke="#e8d6a0" stroke-width="0.4" fill="none"/>`).join('')
        + (on ? rep(10, i => { const x = Math.cos(i * 2.6) * cr * 0.6, y = Math.sin(i * 1.9) * cr * 0.55, d = 0.7 + (i % 4) * 0.2; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.1" fill="none" stroke="#ffffff" stroke-width="0.3">${an('r', '0.1;1;0.1', d, -i * 0.2)}${an('opacity', '1;0.6;0', d, -i * 0.2)}</circle>`; }).join('') : '');
      const pb = cyl3(C, [PXX, GY, PZZ], [PXX, GY + 7.6, PZZ], 6.4, '#cfd3d6', { mat: 'chrome', n: 28, olw: 0.35, cap: water });
      const pasta = [[-2, 0, 4, 9, -2], [-0.6, 1.2, 5.4, 10.4, -3], [1, -0.8, 6.4, 8.6, -1.4]].map(([dx, dz, ex, ey, ez]) => H2(C, [PXX + dx, GY + 6.6, PZZ + dz], [PXX + dx + ex * 0.5, GY + 6.6 + ey, PZZ + dz + ez], 0.4, '#e8d08a')).join('');
      const ph0 = add([PXX, GY + 6.8, PZZ], mul(pdir, 6.6)), ph1 = add([PXX, GY + 7.4, PZZ], mul(pdir, 14)), phd = stick(C, ph0, ph1, 0.9, '#c8ccd0', 'chrome');
      const pot = { q: [PXX, GY + 4, PZZ], s: (dot(pdir, C.v) > 0 ? pb + pasta + phd : phd + pb + pasta) + flF(4) };
      const items = vsort(C, [dutch, wok, pot]);
      let s = shadow(C, 0, -1, 46, 34, 0.9) + front + (fv ? trim : '') + caps + flB + bars + items + (fv ? '' : trim);
      if (on) { s += mist(C, OX, GY + 10, OZ, 3, 0.6) + mist(C, WK.x, GY + 8, WK.z, 4, 0.9) + mist(C, PXX, GY + 8, PZZ, 4, 0.7); C.p(0, GY + 26, 0); }
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-078 6-BURNER FRENCH-TOP DUAL-FUEL HERITAGE BRASS RANGE =======================
  // deep "bleu nuit" enamel with polished brass everywhere: bun feet, top lip, trims, 8 fluted brass knobs, "MAISON DORÉE" medallion between 2 jewel pilot lamps,
  // full-width brass towel rail (a glint slides along it) with a striped linen towel swaying, gas oven + narrow electric oven, each with a brass-framed panel,
  // a brass bar pull and a round thermometer. Black enamel deck: 4 burners in the back row + 2 in front (brass caps, individual cast-iron grates) around a
  // cast-iron French-top plaque with concentric rings. Copper stockpot of stock with a bouquet garni (back), copper saucier of béarnaise + wooden spoon on the
  // French top; brass-trimmed rear shelf with a utensil crock, salt pig, olive oil and a pepper mill. On: flames under the stockpot, the French top glows red from
  // the centre with a heat shimmer, the lamps light, both thermometers climb to 220°, stock steams and the sauce bubbles.
  N.herit28 = S => { const on = isPlay(S), BL = '#24315e', BR = '#c9a256', W = 80, TY = 62, Y0 = 4.4, ZB = -29, ZF = 27, GY = TY + 3.8, PF = 'k28h_';
    const D = { w: 82, d: 62, arch: 'stove', act: 'cook', use: { x: 0, z: 60 }, build: () => [] };
    const still = RD.H28 && RD.H28.still, HB = TY - Y0, DY = 7, DH = 38.6, RY = 50.4;
    const DOORS = [{ x0: -38, x1: 5, t: 'GAZ' }, { x0: 7, x1: 38, t: 'ÉLECTRIQUE' }];
    const KX = [-34, -27, -20, -13, 13, 20, 27, 34], KON = [0, 0, 1, 1, 0, 0, 1, 1];
    let bF = `<rect width="${W}" height="1.4" fill="url(#k28brs)"/><rect y="11" width="${W}" height="0.7" fill="url(#k28brs)"/><rect y="${f1(HB - 1.6)}" width="${W}" height="1.6" fill="url(#k28brs)"/>`
      + KX.map(x => `<circle cx="${x + 40}" cy="6.2" r="3.1" fill="none" stroke="url(#k28brs)" stroke-width="0.6"/>`).join('')
      + `<ellipse cx="40" cy="6.2" rx="7.2" ry="3.8" fill="url(#k28brs)"/><ellipse cx="40" cy="6.2" rx="6.4" ry="3.1" fill="none" stroke="#8a6a2a" stroke-width="0.25"/><text x="40" y="6.3" text-anchor="middle" font-family="Georgia,serif" font-size="1.35" font-weight="700" fill="#5a3e14" letter-spacing="0.2">MAISON DORÉE</text><text x="40" y="8.1" text-anchor="middle" font-family="Georgia,serif" font-size="0.8" fill="#5a3e14" letter-spacing="0.3">PARIS · 1908</text><path d="M37 4.2H43" stroke="#5a3e14" stroke-width="0.15"/>`
      + [31.4, 48.6].map((x, i) => `<circle cx="${x}" cy="6.2" r="1.5" fill="url(#k28brs)"/><circle cx="${x}" cy="6.2" r="1" fill="${on ? '#ffb43a' : '#6a4618'}"/><circle cx="${x - 0.3}" cy="5.9" r="0.35" fill="#ffffff" opacity="0.6"/>` + (on ? `<circle cx="${x}" cy="6.2" r="2.4" fill="#ffb43a" opacity="0.5" filter="url(#m10b1)">${an('opacity', '0.4;0.7;0.4', 2.6, -i)}</circle>` : '')).join('')
      + DOORS.map(d => `<rect x="${d.x0 + 40 - 0.5}" y="${f1(TY - DY - DH - 0.5)}" width="${d.x1 - d.x0 + 1}" height="${DH + 1}" rx="1" fill="#0c1226" opacity="0.5"/>`).join('');
    const sD = `<rect width="56" height="1.4" fill="url(#k28brs)"/><rect y="${f1(HB - 1.6)}" width="56" height="1.6" fill="url(#k28brs)"/><rect x="3" y="5" width="50" height="${f1(HB - 10)}" rx="1.4" fill="none" stroke="url(#k28brs)" stroke-width="0.6"/><circle cx="28" cy="${f1(HB / 2)}" r="3.4" fill="url(#k28brs)"/><path d="M26.2 ${f1(HB / 2 + 1.4)}V${f1(HB / 2 - 1.4)}L28 ${f1(HB / 2 + 0.6)}L29.8 ${f1(HB / 2 - 1.4)}V${f1(HB / 2 + 1.4)}" stroke="#5a3e14" stroke-width="0.35" fill="none"/>`;
    const tD = `<rect width="${W}" height="56" fill="#18181b"/><rect width="${W}" height="56" fill="url(#m10noise)"/><rect x="0.5" y="0.5" width="${W - 1}" height="55" fill="none" stroke="url(#k28brs)" stroke-width="1"/>`;
    const dDec = (d) => { const w = d.x1 - d.x0, c = w / 2; return `<rect x="2.6" y="2.6" width="${f1(w - 5.2)}" height="${f1(DH - 5.2)}" rx="1.2" fill="#000000" opacity="0.1"/><rect x="2.6" y="2.6" width="${f1(w - 5.2)}" height="${f1(DH - 5.2)}" rx="1.2" fill="none" stroke="url(#k28brs)" stroke-width="0.9"/><rect x="3.6" y="3.6" width="${f1(w - 7.2)}" height="${f1(DH - 7.2)}" rx="0.8" fill="none" stroke="#0c1226" stroke-opacity="0.5" stroke-width="0.3"/>`
      + `<circle cx="${f1(c)}" cy="16" r="4.8" fill="url(#k28brs)"/><circle cx="${f1(c)}" cy="16" r="4" fill="#f8f2e2"/>` + rep(11, i => `<path d="M${f1(c)} 12.4V${i % 2 ? 13 : 13.4}" stroke="#3a3226" stroke-width="${i % 2 ? 0.15 : 0.25}" transform="rotate(${-125 + i * 25} ${f1(c)} 16)"/>`).join('')
      + `<path d="M${f1(c - 2.4)} 18.6A3.4 3.4 0 0 1 ${f1(c + 2.4)} 18.6" stroke="#c8302a" stroke-width="0.3" fill="none" opacity="0"/><text x="${f1(c)}" y="18.8" text-anchor="middle" font-family="Georgia,serif" font-size="0.9" fill="#3a3226">°C</text>`
      + `<path d="M${f1(c)} 16.6V12.6" stroke="#a8241e" stroke-width="0.3" stroke-linecap="round" transform="rotate(${on && still ? 70 : -125} ${f1(c)} 16)">${on && !still ? `<animateTransform attributeName="transform" type="rotate" values="-125 ${f1(c)} 16;70 ${f1(c)} 16" dur="6s" calcMode="spline" keyTimes="0;1" keySplines="0.3 0 0.4 1" fill="freeze"/>` : ''}</path><circle cx="${f1(c)}" cy="16" r="0.5" fill="#3a3226"/><path d="M${f1(c - 2.6)} 13.6Q${f1(c)} 12.2 ${f1(c + 2)} 13" stroke="#ffffff" stroke-width="0.5" fill="none" opacity="0.7"/>`
      + `<rect x="${f1(c - 6)}" y="22.6" width="12" height="2.6" rx="0.4" fill="url(#k28brs)"/>` + `<text x="${f1(c)}" y="24.5" text-anchor="middle" font-family="Georgia,serif" font-weight="700" font-size="1.2" fill="#5a3e14" letter-spacing="0.4">${d.t}</text>`; };
    const defs = DEFR + `<defs>${sym(PF + 'f', bF)}${sym(PF + 's', sD)}${DOORS.map((d, i) => sym(PF + 'd' + i, dDec(d))).join('')}</defs>`;
    // linen towel over the rail
    const towel = `<g>${at('rotate', '-2.4 4.5 0;2.4 4.5 0;-2.4 4.5 0', 6, 0, SPL(2))}<path d="M0 0H9V15.2Q4.5 16 0 15.2Z" fill="#efe8d8"/><path d="M0 0H9V15.2Q4.5 16 0 15.2Z" fill="url(#m10v)"/><rect y="9.6" width="9" height="0.9" fill="#2a4a8a"/><rect y="11.2" width="9" height="0.4" fill="#2a4a8a"/><rect y="2.2" width="9" height="0.4" fill="#2a4a8a" opacity="0.7"/>${rep(12, i => `<path d="M${f1(0.4 + i * 0.74)} ${f1(15.2 + (i % 2) * 0.2)}v1.2" stroke="#d8d0bc" stroke-width="0.25"/>`).join('')}<path d="M2.4 0.4Q2.8 8 2.2 15M6.6 0.4Q6.4 8 6.9 15.2" stroke="#000000" stroke-opacity="0.07" stroke-width="0.9" fill="none"/><path d="M0 0H9V1.6Q4.5 2.4 0 1.6Z" fill="#ded6c4"/></g>`;
    // burners: back row of 4, front pair, French top in the front middle
    const BU = [{ x: -30, z: -14, r: 3.6 }, { x: -10, z: -14, r: 4.4 }, { x: 10, z: -14, r: 3.6 }, { x: 30, z: -14, r: 3.6 }, { x: -28, z: 11, r: 4.4 }, { x: 28, z: 11, r: 3.8 }];
    const GR = [[-39.6, -20.4, -25.4, -3.2, 0], [-19.8, -0.4, -25.4, -3.2, 1], [0.4, 19.8, -25.4, -3.2, 2], [20.4, 39.6, -25.4, -3.2, 3], [-39.6, -16.6, -2.2, 24.6, 4], [16.6, 39.6, -2.2, 24.6, 5]].map(([x0, x1, z0, z1, i]) => ({ x0, x1, z0, z1, b: [Object.assign({ rr: BU[i].r * 1.4 + 1.4 }, BU[i])] }));
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const feet = [[-36, -25], [36, -25], [-36, 23], [36, 23]].sort((a, b) => dot([a[0], 0, a[1]], C.v) - dot([b[0], 0, b[1]], C.v)).map(([x, z]) => cyl3(C, [x, 0, z], [x, Y0, z], 2, BR, { r2: 2.8, mat: 'metal', n: 18, olw: 0.3 })).join('');
      const body = box3(C, { c: [0, Y0, (ZB + ZF) / 2], w: W, h: HB, d: ZF - ZB, r: 2.2, col: BL, gl: 0.6, olw: 0.55, olo: 0.7, dec: { f: use(PF + 'f'), r: use(PF + 's'), l: use(PF + 's'), t: tD } });
      const doors = DOORS.map((d, i) => box3(C, { c: [(d.x0 + d.x1) / 2, DY, ZF + 0.9], w: d.x1 - d.x0, h: DH, d: 1.8, r: 0.8, col: BL, gl: 0.65, olw: 0.4, olo: 0.7, dec: { f: use(PF + 'd' + i) } })).join('');
      const pulls = DOORS.map(d => { const w = d.x1 - d.x0, c = (d.x0 + d.x1) / 2; return barH(C, c - w * 0.32, c + w * 0.32, DY + DH - 5.4, ZF + 1.8, 2.4, 0.85, BR, 'metal', 1.6) + sph(C, [c - w * 0.32, DY + DH - 5.4, ZF + 4.2], 1.05, BR) + sph(C, [c + w * 0.32, DY + DH - 5.4, ZF + 4.2], 1.05, BR); }).join('');
      const rail = barH(C, -38.4, 38.4, RY, ZF, 3.6, 0.95, BR, 'metal', 1.6) + sph(C, [-38.4, RY, ZF + 3.6], 1.25, BR) + sph(C, [38.4, RY, ZF + 3.6], 1.25, BR);
      const ga = C.P([-36, RY + 0.5, ZF + 4.4]), gb = C.P([36, RY + 0.5, ZF + 4.4]), glint = `<ellipse rx="${f1(2.4 * C.k)}" ry="${f1(0.35 * C.k)}" fill="#fffbe8" opacity="0"><animate attributeName="cx" values="${f1(ga[0])};${f1(ga[0])};${f1(gb[0])};${f1(gb[0])}" keyTimes="0;0.7;0.9;1" dur="9s" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(ga[1])};${f1(ga[1])};${f1(gb[1])};${f1(gb[1])}" keyTimes="0;0.7;0.9;1" dur="9s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0;0.9;0.9;0;0" keyTimes="0;0.7;0.74;0.86;0.9;1" dur="9s" repeatCount="indefinite"/></ellipse>`;
      const tw = PLN(C, [-33, RY + 0.9, ZF + 4.8], [1, 0, 0], [0, -1, 0], towel);
      const knobs = KX.map((x, i) => knob(C, x, TY - 6.2, ZF, 3, 2.2, BR, on && KON[i] ? 135 : 0, { mat: 'metal', r2: 2.5, fl: '#8a6a2a', mk: '#3a2a10' })).join('');
      const front = fv ? feet + body + doors + pulls + knobs + rail + glint + tw : tw + rail + knobs + pulls + doors + feet + body;
      // deck: burners with brass caps, cast-iron grates, French top
      let caps = ''; BU.forEach(b => caps += gasB(C, b.x, b.z, TY, b.r, BR, 'metal'));
      const ftop = box3(C, { c: [0, TY, 11], w: 30, h: 1.6, d: 25, r: 0, col: '#2c2c2e', gl: 0.25, mat: 'noise', olw: 0.35, olo: 0.8, dec: { t: rep(4, i => `<circle cx="15" cy="12.5" r="${f1(2.6 + i * 3.2)}" fill="none" stroke="#0e0e10" stroke-width="0.5"/><circle cx="15" cy="12.7" r="${f1(2.6 + i * 3.2)}" fill="none" stroke="#6a6a6e" stroke-opacity="0.4" stroke-width="0.25"/>`).join('') + `<circle cx="15" cy="12.5" r="2.4" fill="#1e1e20"/>` + (on ? `<circle cx="15" cy="12.5" r="12.4" fill="url(#k28ft)">${an('opacity', '0.7;1;0.7', 3.2)}</circle>` : '') + `<rect x="0.4" y="0.4" width="29.2" height="24.2" fill="none" stroke="url(#k28brs)" stroke-width="0.5"/>` } });
      const shim = on ? (() => { const p = C.P([0, TY + 2, 11]); return `<g transform="translate(${P2(p)}) scale(${n4(C.k)})">` + rep(4, i => `<path d="M${-9 + i * 6} 0q1.4 -2 0 -4t0 -4t0 -4" stroke="#ffd8b0" stroke-width="0.5" fill="none" opacity="0">${at('translate', '0 0;0 -6', 2.4, -i * 0.6)}${an('opacity', '0;0.35;0', 2.4, -i * 0.6)}</path>`).join('') + '</g>'; })() : '';
      const FL = on ? flames(C, BU[1].x, TY + 1.4, BU[1].z, BU[1].r * 1.3, 14, 0.95, 2) : null;
      const bars = vsort(C, [].concat(...GR.map(g => grate(C, g, TY + 0.4, GY, '#1e1e20', 1.3))));
      // copper stockpot (back, on burner 1)
      const CU = '#c8784a', SX = BU[1].x, SZ = BU[1].z;
      const stock = cr => `<circle r="${f1(cr * 0.93)}" fill="#c4964a"/><circle r="${f1(cr * 0.93)}" fill="none" stroke="#d8d8d0" stroke-width="0.6"/>` + rep(8, i => `<circle cx="${f1(Math.cos(i * 2.2) * cr * 0.6)}" cy="${f1(Math.sin(i * 1.7) * cr * 0.55)}" r="0.35" fill="#2a1a10"/>`).join('')
        + `<g transform="rotate(-25)"><ellipse cx="1" cy="0" rx="3.6" ry="1.6" fill="#3a7a2a"/><ellipse cx="-1" cy="0.6" rx="3" ry="1.2" fill="#5a9a3a"/><ellipse cx="2.4" cy="-0.6" rx="1.8" ry="0.9" fill="#7ab04a"/><path d="M-0.4 -1.6V1.8M1 -1.6V1.8" stroke="#e8dcc0" stroke-width="0.35"/><path d="M1 1.8Q3 4 5.6 4.4" stroke="#e8dcc0" stroke-width="0.25" fill="none"/></g>`
        + `<circle cx="-3.4" cy="-2.4" r="1.2" fill="#e8892a"/><circle cx="3.6" cy="2.6" r="1" fill="#e8892a"/>` + (on ? rep(6, i => `<circle cx="${f1(Math.cos(i * 1.9) * cr * 0.5)}" cy="${f1(Math.sin(i * 1.9) * cr * 0.5)}" r="0.1" fill="none" stroke="#f8e8c0" stroke-width="0.25">${an('r', '0.1;0.8;0.1', 1.3 + i * 0.2, -i * 0.3)}</circle>`).join('') : '');
      const sH = sg => cyl3(C, [SX + sg * 8.2, GY + 9.6, SZ - 1.6], [SX + sg * 10.4, GY + 10.6, SZ - 1.6], 0.55, BR, { mat: 'metal', n: 10, olw: 0.2 }) + cyl3(C, [SX + sg * 10.4, GY + 10.6, SZ - 1.6], [SX + sg * 10.4, GY + 10.6, SZ + 1.6], 0.55, BR, { mat: 'metal', n: 10, olw: 0.2 }) + cyl3(C, [SX + sg * 8.2, GY + 9.6, SZ + 1.6], [SX + sg * 10.4, GY + 10.6, SZ + 1.6], 0.55, BR, { mat: 'metal', n: 10, olw: 0.2 });
      const spot = { q: [SX, GY + 6, SZ], s: (C.v[0] > 0 ? sH(-1) : sH(1)) + cyl3(C, [SX, GY, SZ], [SX, GY + 12, SZ], 8, CU, { mat: 'metal', n: 30, olw: 0.35, cap: stock }) + cyl3(C, [SX, GY + 11.4, SZ], [SX, GY + 12.2, SZ], 8.25, '#d8885a', { mat: 'metal', n: 30, olw: 0.25, noCap: 1 }) + (C.v[0] > 0 ? sH(1) : sH(-1)) + (FL ? FL.f : '') };
      // copper saucier of béarnaise on the French top + wooden spoon, long brass handle to the front right
      const QX = 4, QZ = 9.6, QT = TY + 1.6, qdir = [0.7, 0, 0.714];
      const sauce = cr => `<circle r="${f1(cr * 0.92)}" fill="#d8dcd8"/><circle r="${f1(cr * 0.84)}" fill="#f2d27a"/>` + rep(14, i => `<circle cx="${f1(Math.cos(i * 2.4) * cr * (0.15 + (i % 4) * 0.15))}" cy="${f1(Math.sin(i * 2.4) * cr * (0.15 + (i % 4) * 0.15))}" r="0.22" fill="#4a7a2a"/>`).join('') + `<path d="M${f1(-cr * 0.5)} 0Q0 ${f1(-cr * 0.3)} ${f1(cr * 0.5)} 0" stroke="#fff0c0" stroke-width="0.5" fill="none"/>` + (on ? rep(4, i => `<circle cx="${f1(Math.cos(i * 1.6) * cr * 0.45)}" cy="${f1(Math.sin(i * 1.6) * cr * 0.45)}" r="0.1" fill="none" stroke="#fff4d0" stroke-width="0.25">${an('r', '0.1;0.7;0.1', 1.8 + i * 0.3, -i * 0.5)}</circle>`).join('') : '');
      const qb = cyl3(C, [QX, QT, QZ], [QX, QT + 5, QZ], 5.4, CU, { r2: 6.4, mat: 'metal', n: 28, olw: 0.35, cap: sauce }) + cyl3(C, [QX, QT + 4.4, QZ], [QX, QT + 5.2, QZ], 6.5, '#d8885a', { mat: 'metal', n: 28, olw: 0.25, noCap: 1 });
      const qh0 = add([QX, QT + 4.6, QZ], mul(qdir, 6.2)), qh1 = add([QX, QT + 6.4, QZ], mul(qdir, 15)), qhd = stick(C, qh0, qh1, 0.75, BR, 'metal') + sph(C, qh1, 0.9, BR);
      const wsp = H2(C, [QX - 1.4, QT + 4.2, QZ + 0.6], [QX - 8.4, QT + 9.4, QZ + 3.4], 0.9, '#b88a52') + H2(C, [QX - 1.4, QT + 4.2, QZ + 0.6], [QX - 8.4, QT + 9.4, QZ + 3.4], 0.3, '#e0b880', 0.6);
      const sauc = { q: [QX, QT + 3, QZ], s: dot(qdir, C.v) > 0 ? qb + wsp + qhd : qhd + qb + wsp };
      // rear shelf + things on it
      const SH = 15, shelfB = box3(C, { c: [0, TY, ZB + 3], w: W, h: SH, d: 6, r: 1, col: BL, gl: 0.6, olw: 0.45, olo: 0.7, dec: { f: `<rect width="${W}" height="1.2" fill="url(#k28brs)"/><rect y="${SH - 0.9}" width="${W}" height="0.9" fill="url(#k28brs)"/>` + rep(14, i => `<rect x="${f1(12 + i * 4)}" y="5" width="1.4" height="5" rx="0.7" fill="#0c1226"/><rect x="${f1(12 + i * 4)}" y="5" width="1.4" height="5" rx="0.7" fill="none" stroke="url(#k28brs)" stroke-width="0.2"/>`).join(''), t: `<rect x="0.4" y="0.4" width="79.2" height="5.2" fill="none" stroke="url(#k28brs)" stroke-width="0.5"/>` } });
      const sy = TY + SH, sz = ZB + 3;
      const crock = { q: [-26, sy + 3, sz], s: [[-1, 12, -0.6, '#b88a52'], [0.8, 13, 0.4, '#a87848'], [0.2, 11, 0.8, '#c8a060']].map(([dx, h, dz, c]) => H2(C, [-26 + dx * 0.3, sy + 4, sz + dz * 0.3], [-26 + dx * 1.8, sy + h, sz + dz], 0.7, c) + sph(C, [-26 + dx * 1.8, sy + h + 0.6, sz + dz], 0.9, c)).join('') + H2(C, [-25.4, sy + 4, sz], [-24.2, sy + 10, sz + 0.4], 0.35, BR) + PLN(C, [-24.2, sy + 11.6, sz + 0.4], [1, 0, 0], [0, -1, 0], `<ellipse rx="1.2" ry="1.8" fill="none" stroke="${BR}" stroke-width="0.3"/><path d="M0 -1.8V1.8" stroke="${BR}" stroke-width="0.2"/>`) + cyl3(C, [-26, sy, sz], [-26, sy + 6, sz], 2.6, '#f2eee4', { r2: 2.3, mat: 'gloss', n: 20, olw: 0.3, capCol: '#3a3026' }) + `<g transform="${tanF(C, -26, sz, 2.5, C.thV, sy + 3)}"><path d="M-1.6 0H1.6" stroke="#2a4a8a" stroke-width="0.4"/></g>` };
      const pig = { q: [-8, sy + 2, sz], s: cyl3(C, [-8, sy, sz], [-8, sy + 4.4, sz], 2.4, '#e8dcc4', { r2: 2.6, mat: 'gloss', n: 20, olw: 0.3 }) + cyl3(C, [-8, sy + 4.4, sz], [-8, sy + 5.6, sz], 2.6, '#e8dcc4', { r2: 1.6, mat: 'gloss', n: 20, olw: 0.3, capCol: '#f8f8f4' }) + `<g transform="${tanF(C, -8, sz, 2.5, C.thV, sy + 3)}"><ellipse rx="1.4" ry="0.9" fill="#3a2a1a"/><ellipse cy="-0.2" rx="1.2" ry="0.6" fill="#f8f6f0"/></g>` };
      const oil = { q: [16, sy + 5, sz], s: bottle(C, 16, sy, sz, 1.8, 11, '#6a7a2a', '#2a2a26', { op: 0.9, lbl: `<rect x="-1.4" y="-1.6" width="2.8" height="3.2" fill="#f2ead0"/><text x="0" y="0.5" text-anchor="middle" font-family="Georgia,serif" font-size="0.7" fill="#3a4a1a">HUILE</text>` }) };
      const mill = { q: [27, sy + 4, sz], s: cyl3(C, [27, sy, sz], [27, sy + 2.4, sz], 1.5, '#6a3a1e', { r2: 1.2, mat: 'gloss', n: 16, olw: 0.25, noCap: 1 }) + cyl3(C, [27, sy + 2.4, sz], [27, sy + 7, sz], 1.2, '#6a3a1e', { r2: 1.5, mat: 'gloss', n: 16, olw: 0.25, noCap: 1 }) + cyl3(C, [27, sy + 7, sz], [27, sy + 7.6, sz], 1.5, BR, { mat: 'metal', n: 16, olw: 0.25 }) + sph(C, [27, sy + 8.2, sz], 0.6, BR) };
      const shelf = fv ? shelfB + vsort(C, [crock, pig, oil, mill]) : vsort(C, [crock, pig, oil, mill]) + shelfB;
      const items = vsort(C, [spot, sauc]);
      let s = shadow(C, 0, -1, 46, 34, 0.9) + front + (fv ? shelf : '') + caps + ftop + (FL ? FL.b : '') + bars + shim + items + (fv ? '' : shelf);
      if (on) { s += mist(C, SX, GY + 12, SZ, 4, 0.8) + mist(C, QX, QT + 6, QZ, 2, 0.5); C.p(SX, GY + 30, SZ); }
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-098 INVISIBLE INDUCTION COUNTERTOP & MOLECULAR LASER-BAKE SMART OVEN =======================
  // a polished ivory quartz block veined in grey + gold, champagne-gold edge trims, floating on a dark recessed plinth over a soft floor glow. The top is one
  // seamless slab: the 4 induction zones are only hinted by faint etched rings + gold corner ticks. Front: black-glass touch band (zone map, AURA display with a
  // breathing standby dot, power slider), a handle-less black-glass oven door with a gold groove: inside, a gold laser rail over a glass tray and a soufflé.
  // Matte black sauté pan with a gold rim of seared scallops (front left), borosilicate glass pot with eggs in water (back right), marble salt cellar + gold spoon.
  // On: cyan halos + ripples + turning dot rings light up in the stone under the two pans, floating holo readouts (SEAR 210° / SIMMER 98°), scallops sizzle, eggs
  // bob and bubbles rise through the glass pot; the oven lights violet, 7 laser beams flicker onto the soufflé, a scan line sweeps, the tray levitates and the soufflé rises.
  N.ind28 = S => { const on = isPlay(S), ST = '#eee8de', BR = '#c9a256', W = 80, TY = 62, Y0 = 4.4, ZB = -29, ZF = 27, HB = TY - Y0, DY = 7.6, DH = 37.8, PF = 'k28n_';
    const D = { w: 82, d: 62, arch: 'stove', act: 'cook', use: { x: 0, z: 60 }, build: () => [] };
    const R = rng('ind28'), still = RD.H28 && RD.H28.still, CY = '#7ae8ff', CYL = '#bff4ff';
    const DEFN = DEFR
      + `<radialGradient id="k28ih" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="${CY}" stop-opacity="0"/><stop offset="0.62" stop-color="${CY}" stop-opacity="0.06"/><stop offset="0.8" stop-color="${CY}" stop-opacity="0.6"/><stop offset="0.9" stop-color="${CYL}" stop-opacity="0.35"/><stop offset="1" stop-color="${CY}" stop-opacity="0"/></radialGradient>`
      + '<linearGradient id="k28lc" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0a0912"/><stop offset="1" stop-color="#1e1a32"/></linearGradient>'
      + '<radialGradient id="k28lg" cx="50%" cy="62%" r="60%"><stop offset="0" stop-color="#ffc8e8" stop-opacity="0.55"/><stop offset="0.5" stop-color="#a060ff" stop-opacity="0.25"/><stop offset="1" stop-color="#6030c0" stop-opacity="0"/></radialGradient>'
      + `<linearGradient id="k28scan" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${CY}" stop-opacity="0"/><stop offset="0.5" stop-color="${CY}" stop-opacity="0.4"/><stop offset="1" stop-color="${CY}" stop-opacity="0"/></linearGradient>`
      + '<radialGradient id="k28fg" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffe6b0" stop-opacity="0.6"/><stop offset="1" stop-color="#ffe6b0" stop-opacity="0"/></radialGradient>';
    const Z = [{ x: -20, z: 9, r: 11, a: 1, t: 'SEAR', v: '210°' }, { x: 20, z: -11, r: 8, a: 1, t: 'SIMMER', v: '98°' }, { x: -20, z: -13, r: 7 }, { x: 21, z: 12, r: 9 }];
    const gold = (w, y, h) => `<rect y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="url(#k28brs)"/>`;
    // front: veins, gold trims, black-glass touch band
    let bF = veins(R, W, HB) + gold(W, 0, 0.9) + gold(W, HB - 0.9, 0.9) + `<rect x="2.6" y="${f1(TY - DY - DH - 0.5)}" width="74.8" height="${f1(DH + 1)}" rx="1.2" fill="#2a2620" opacity="0.35"/>`
      + `<rect x="4" y="3.4" width="72" height="9.4" rx="1.8" fill="#0e0d12"/><rect x="5" y="3.9" width="70" height="2.2" rx="1" fill="#ffffff" opacity="0.07"/><rect x="4" y="3.4" width="72" height="9.4" rx="1.8" fill="none" stroke="url(#k28brs)" stroke-width="0.4"/>`;
    bF += [[11.4, 10, 1], [16.6, 6.2, 1], [11.4, 6.2, 0], [16.6, 10, 0]].map(([x, y, a], i) => `<circle cx="${x}" cy="${y}" r="1.5" fill="none" stroke="${on && a ? CY : '#4a4656'}" stroke-width="0.35"/>`
      + (on && a ? `<circle cx="${x}" cy="${y}" r="1.7" fill="${CY}" opacity="0.35" filter="url(#m10b1)">${an('opacity', '0.2;0.6;0.2', 1.8, -i * 0.4)}</circle><circle cx="${x}" cy="${y}" r="0.55" fill="${CYL}"/>` : '')).join('');
    bF += on ? `<text x="40" y="6.9" text-anchor="middle" ${FONT} font-size="1.2" fill="#d8a8ff" letter-spacing="0.5">MOLECULAR LASER-BAKE</text><text x="40" y="10.7" text-anchor="middle" ${FONT} font-size="3.2" fill="${CYL}">03<tspan>${an('fill-opacity', '1;1;0;0', 2, 0, ' calcMode="discrete"')}:</tspan>12</text>`
        + `<rect x="30" y="11.3" width="20" height="0.45" rx="0.2" fill="#2a2838"/><rect x="30" y="11.3" width="20" height="0.45" rx="0.2" fill="#d8a8ff">${still ? '' : an('width', '0;20', 12)}</rect>`
      : `<text x="40" y="9.4" text-anchor="middle" font-family="Georgia,serif" font-size="3" fill="${BR}" letter-spacing="1.6">AURA</text><circle cx="49.6" cy="8.2" r="0.5" fill="${CY}">${an('opacity', '0.15;0.9;0.15', 3.6)}</circle><circle cx="49.6" cy="8.2" r="1.4" fill="${CY}" filter="url(#m10b1)">${an('opacity', '0;0.4;0', 3.6)}</circle>`;
    bF += rep(9, i => `<circle cx="${f1(58 + i * 1.9)}" cy="8.1" r="0.45" fill="${on && i < 6 ? CY : '#3a3848'}"/>`).join('') + (on ? `<circle cx="${f1(58 + 5 * 1.9)}" cy="8.1" r="1.2" fill="none" stroke="${CYL}" stroke-width="0.3"/>` : '');
    const sD = veins(R, 56, HB) + gold(56, 0, 0.9) + gold(56, HB - 0.9, 0.9);
    const bB = veins(R, W, HB) + gold(W, 0, 0.9) + gold(W, HB - 0.9, 0.9) + `<rect x="31" y="40" width="18" height="5" rx="0.4" fill="url(#k28brs)"/><text x="40" y="43.2" text-anchor="middle" font-family="Arial" font-size="1.3" fill="#5a3e14">AURA·LUX IND-900 · 230V</text>`;
    // top: one seamless slab, zones only hinted (faint ring + 4 gold ticks), a thyme sprig
    const tD = veins(R, W, 56) + `<rect x="0.5" y="0.5" width="79" height="55" rx="1.8" fill="none" stroke="url(#k28brs)" stroke-width="0.7"/>`
      + Z.map(z => { const cx = z.x + 40, cy = z.z - ZB, r = z.r + 1.5, q = PI * r / 2; return `<circle cx="${cx}" cy="${cy}" r="${f1(r)}" fill="none" stroke="#8a8478" stroke-opacity="0.14" stroke-width="0.25"/><circle cx="${cx}" cy="${cy}" r="${f1(r)}" fill="none" stroke="${BR}" stroke-opacity="0.6" stroke-width="0.35" stroke-dasharray="1.4 ${f1(q - 1.4)}" transform="rotate(-50 ${cx} ${cy})"/>`; }).join('')
      + G(`<path d="M0 0Q3 -1 7 -0.4" stroke="#6a7a4a" stroke-width="0.25" fill="none"/>` + rep(7, i => `<ellipse cx="${f1(1 + i * 0.9)}" cy="${f1(-0.6 + (i % 2) * 1.1)}" rx="0.55" ry="0.3" fill="${i % 3 ? '#7a9a5a' : '#5a7a3a'}" transform="rotate(${i % 2 ? 30 : -30} ${f1(1 + i * 0.9)} ${f1(-0.6 + (i % 2) * 1.1)})"/>`).join(''), 40, 50, -14);
    // oven door: black glass window, gold laser rail, glass tray, soufflé
    const WX = 4, WY = 3.6, WW = 66, WH = 26.6, TYc = on ? 21.4 : 23.6;
    const dome = `<path d="M-6 0C-6 -3.4 -3.6 -6 0 -6.2C3.6 -6 6 -3.4 6 0Z" fill="#e2a850"/><path d="M-6 0C-6 -1.6 -4 -2.4 0 -2.4C4 -2.4 6 -1.6 6 0Z" fill="#f2d08a" opacity="0.6"/><path d="M-4.4 -2.8C-3 -4.9 -0.4 -5.6 2 -5.1" stroke="#fff0c0" stroke-width="0.5" fill="none" opacity="0.7"/>` + rep(6, i => `<circle cx="${f1(-3 + i * 1.2)}" cy="${f1(-5 + Math.abs(i - 2.5) * 0.5)}" r="0.2" fill="#ffffff" opacity="0.8"/>`).join('');
    const souf = on ? `<g transform="translate(33 ${f1(TYc - 5.6)})"><g transform="scale(1 ${still ? 1 : 0.2})">${still ? '' : '<animateTransform attributeName="transform" type="scale" values="1 0.2;1 1.06;1 1" keyTimes="0;0.85;1" dur="7s" fill="freeze"/>'}${dome}</g></g>`
      : `<ellipse cx="33" cy="${f1(TYc - 5.6)}" rx="5.5" ry="0.6" fill="#f0deb0"/>`;
    const ram = `<rect x="27.4" y="${f1(TYc - 5.6)}" width="11.2" height="5.4" rx="0.6" fill="#f6f2ea"/>` + rep(7, i => `<path d="M${f1(28.6 + i * 1.5)} ${f1(TYc - 5.2)}V${f1(TYc - 0.6)}" stroke="#d8d0c4" stroke-width="0.3"/>`).join('') + `<path d="M27.6 ${f1(TYc - 5.5)}H38.4" stroke="#ffffff" stroke-width="0.4"/>`;
    const tray = `<ellipse cx="33" cy="${TYc}" rx="15" ry="2" fill="#d8f0f6" opacity="0.28" stroke="#ffffff" stroke-opacity="0.55" stroke-width="0.3"/>` + ram + souf;
    const LX = rep(7, i => 13 + i * 6.67);
    let win = `<rect width="${WW}" height="${WH}" rx="1.2" fill="url(#k28lc)"/><rect x="7" y="4" width="52" height="19" fill="#000000" opacity="0.18" stroke="#3a3450" stroke-width="0.3"/><path d="M0 0L7 4M66 0L59 4M0 26.6L7 23M66 26.6L59 23" stroke="#3a3450" stroke-width="0.3"/>`;
    if (on) win += rep(9, i => `<path d="M${f1(7 + i * 6.5)} 4V23" stroke="#8a5ad8" stroke-opacity="0.2" stroke-width="0.15"/>`).join('') + rep(5, i => `<path d="M7 ${f1(4 + i * 4.75)}H59" stroke="#8a5ad8" stroke-opacity="0.2" stroke-width="0.15"/>`).join('')
      + `<rect width="${WW}" height="${WH}" rx="1.2" fill="url(#k28lg)">${an('opacity', '0.75;1;0.75', 3)}</rect>`;
    else win += `<path d="M8 ${f1(TYc + 1.2)}H58" stroke="#4a4458" stroke-width="0.5"/>`;
    win += `<rect x="10" y="1.2" width="46" height="1.6" rx="0.6" fill="url(#k28brs)"/>` + LX.map((x, i) => `<circle cx="${f1(x)}" cy="2.9" r="0.75" fill="${on ? '#f0c8ff' : '#2a2440'}" stroke="#8a6a2a" stroke-width="0.2"/>` + (on ? `<circle cx="${f1(x)}" cy="2.9" r="1.6" fill="#d890ff" opacity="0.5" filter="url(#m10b1)"/>` : '')).join('');
    win += on ? `<g>${still ? '' : at('translate', '0 0;0 -0.6;0 0', 3, 0, SPL(2))}<ellipse cx="33" cy="${f1(TYc + 1.6)}" rx="12" ry="1.6" fill="${CY}" opacity="0.5" filter="url(#m10b1)">${an('opacity', '0.35;0.6;0.35', 3)}</ellipse>${tray}</g>` : tray;
    if (on) win += LX.map((x, i) => { const tx = 33 + (i - 3) * 1.5, ty = TYc - 9.4, d = `M${f1(x)} 3.4L${f1(tx)} ${f1(ty)}`, du = 0.3 + i * 0.07;
        return `<path d="${d}" stroke="#e090ff" stroke-width="1" opacity="0.25" filter="url(#m10b1)"/><path d="${d}" stroke="#fbe8ff" stroke-width="0.18">${an('opacity', '0.5;1;0.6;1', du, -i * 0.05)}</path><circle cx="${f1(tx)}" cy="${f1(ty)}" r="0.45" fill="#ffffff">${an('r', '0.3;0.7;0.3', du * 1.3, -i * 0.1)}</circle>`; }).join('')
      + `<g>${still ? '' : at('translate', '0 0;0 17;0 0', 3.4, 0, SPL(2))}<rect x="7" y="4" width="52" height="1.6" fill="url(#k28scan)"/><path d="M7 4.8H59" stroke="${CY}" stroke-width="0.2" opacity="0.8"/></g>`;
    win += refl(WW, WH);
    const dDec = `<rect x="0.4" y="0.4" width="74.2" height="${f1(DH - 0.8)}" rx="0.8" fill="none" stroke="url(#k28brs)" stroke-width="0.35"/><rect x="20" y="1" width="35" height="0.9" rx="0.45" fill="url(#k28brs)"/>`
      + `<rect x="${WX - 0.8}" y="${WY - 0.8}" width="${WW + 1.6}" height="${WH + 1.6}" rx="1.8" fill="#060608"/><g transform="translate(${WX} ${WY})">${win}</g>`
      + LBL(37.5, 34.4, 'MOLECULAR · LASER-BAKE', 1.4, '#8a8478', ' letter-spacing="1"') + (on ? LBL(63, 34.4, 'LEVITATE', 1.1, CY, ' letter-spacing="0.4"') : '');
    const defs = DEFN + `<defs>${sym(PF + 'f', bF)}${sym(PF + 'd', dDec)}${sym(PF + 's', sD)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const glow = PLN(C, [0, 0.04, -1], [1, 0, 0], [0, 0, 1], `<ellipse rx="46" ry="36" fill="url(#k28fg)" opacity="${on ? 0.9 : 0.5}">${on ? '' : an('opacity', '0.35;0.6;0.35', 5)}</ellipse>`);
      const plinth = box3(C, { c: [0, 0, -1], w: 70, h: Y0, d: 48, r: 1.2, col: '#1c1b20', gl: 0.3, olw: 0.35, olo: 0.6 });
      const body = box3(C, { c: [0, Y0, (ZB + ZF) / 2], w: W, h: HB, d: ZF - ZB, r: 2, col: ST, gl: 0.55, olw: 0.5, olo: 0.6, dec: { f: use(PF + 'f'), r: use(PF + 's'), l: use(PF + 's'), b: bB, t: tD } });
      const door = box3(C, { c: [0, DY, ZF + 0.9], w: 75, h: DH, d: 1.8, r: 0.8, col: '#16151a', gl: 0.8, olw: 0.4, olo: 0.7, dec: { f: use(PF + 'd') } });
      const front = fv ? plinth + body + door : door + plinth + body;
      // induction halos in the stone under the two pans
      const halos = on ? Z.filter(z => z.a).map((z, i) => PLN(C, [z.x, TY + 0.05, z.z], [1, 0, 0], [0, 0, 1], `<circle r="${z.r + 3}" fill="url(#k28ih)">${an('opacity', '0.7;1;0.7', 2.4, -i)}</circle>`
        + `<circle r="${z.r}" fill="none" stroke="${CYL}" stroke-width="0.3">${an('r', `${z.r};${z.r + 4.5}`, 2.2, -i * 0.7)}${an('opacity', '0.8;0', 2.2, -i * 0.7)}</circle>`
        + `<circle r="${f1(z.r + 1.6)}" fill="none" stroke="${CY}" stroke-width="0.5" stroke-dasharray="0.5 1.2" opacity="0.8">${still ? '' : at('rotate', i ? '360;0' : '0;360', 14)}</circle>`)).join('') : '';
      // sauté pan of scallops (front left)
      const PX = Z[0].x, PZ = Z[0].z, pdir = [-0.55, 0, 0.835];
      const scal = cr => `<circle r="${f1(cr * 0.9)}" fill="#1c1b1e"/><ellipse cx="${f1(-cr * 0.25)}" cy="${f1(-cr * 0.3)}" rx="${f1(cr * 0.4)}" ry="${f1(cr * 0.18)}" fill="#f8e0a0" opacity="0.14"/>`
        + rep(5, i => { const a = (i * 72 + 18) * PI / 180, x = f1(Math.cos(a) * cr * 0.5), y = f1(Math.sin(a) * cr * 0.5);
          return `<g transform="translate(${x} ${y})"><g>${on && !still ? at('translate', '0 0;0.12 -0.1;-0.1 0.08;0 0', 0.5 + i * 0.07) : ''}<circle r="2.3" fill="#f4e8d2"/><circle r="1.8" fill="#d08c3c"/><circle r="1.15" fill="#e8b468"/><path d="M-1 -0.6Q0 -1.2 1 -0.5" stroke="#fff4d8" stroke-width="0.3" fill="none"/></g></g>`; }).join('')
        + rep(5, i => `<ellipse cx="${f1((i - 2) * 0.6)}" cy="${f1((i % 2) * 0.7 - 0.3)}" rx="0.9" ry="0.4" fill="${i % 2 ? '#7ab84a' : '#5a9a3a'}" transform="rotate(${i * 37} ${f1((i - 2) * 0.6)} ${f1((i % 2) * 0.7 - 0.3)})"/>`).join('')
        + `<rect x="${f1(cr * 0.55)}" y="${f1(cr * 0.1)}" width="1.8" height="1.5" rx="0.4" fill="#f8e6a0" transform="rotate(20)"/>`
        + (on ? rep(9, i => { const x = f1(Math.cos(i * 2.3) * cr * 0.72), y = f1(Math.sin(i * 2.3) * cr * 0.72), d = 0.5 + (i % 4) * 0.13; return `<circle cx="${x}" cy="${y}" r="0.1" fill="#fff8e0">${an('r', '0.1;0.55;0.1', d, -i * 0.17)}${an('opacity', '1;0.7;0', d, -i * 0.17)}</circle>`; }).join('') : '');
      const pb = cyl3(C, [PX, TY, PZ], [PX, TY + 0.7, PZ], 8.6, '#9aa0a6', { mat: 'chrome', n: 28, olw: 0.25, noCap: 1 })
        + cyl3(C, [PX, TY + 0.7, PZ], [PX, TY + 4.6, PZ], 9.2, '#2a292e', { r2: 10.6, mat: 'matte', n: 30, olw: 0.35, cap: scal })
        + PLN(C, [PX, TY + 4.6, PZ], [1, 0, 0], [0, 0, 1], `<circle r="10.45" fill="none" stroke="#8a6a2a" stroke-width="0.9"/><circle r="10.45" fill="none" stroke="url(#k28brs)" stroke-width="0.6"/><path d="M-7.4 -7.4A10.45 10.45 0 0 1 4 -9.65" stroke="#fff6d8" stroke-width="0.3" fill="none" opacity="0.8"/>`);
      const h0 = add([PX, TY + 4, PZ], mul(pdir, 10.2)), h1 = add([PX, TY + 5.4, PZ], mul(pdir, 13)), h2 = add([PX, TY + 6.6, PZ], mul(pdir, 21.5));
      const phd = stick(C, h0, h1, 0.8, BR, 'metal') + stick(C, h1, h2, 1.15, '#2a292e', 'matte') + sph(C, h2, 1.2, BR);
      const pan = { q: [PX, TY + 3, PZ], s: dot(pdir, C.v) > 0 ? pb + phd : phd + pb };
      // borosilicate glass pot of eggs (back right)
      const GX = Z[1].x, GZ = Z[1].z;
      const water = cr => `<circle r="${f1(cr)}" fill="#e2f6fa" opacity="0.35"/>` + (on ? rep(8, i => { const x = Math.cos(i * 2.6) * cr * 0.6, y = Math.sin(i * 1.9) * cr * 0.55, d = 0.8 + (i % 4) * 0.2; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.1" fill="none" stroke="#ffffff" stroke-width="0.3">${an('r', '0.1;1;0.1', d, -i * 0.2)}${an('opacity', '1;0.6;0', d, -i * 0.2)}</circle>`; }).join('') : '');
      const egg = (dx, y, dz, i) => { const e = sph(C, [GX + dx, TY + y, GZ + dz], 2, '#f6efe2'); return on && !still ? `<g>${at('translate', `0 0;0 ${f1(-0.4 * C.k)};0 0`, 0.9 + i * 0.2, -i * 0.3)}${e}</g>` : e; };
      const p0 = C.P([GX, TY + 1.4, GZ]), p1 = C.P([GX, TY + 7.6, GZ]);
      const bub = on ? rep(10, i => { const ox = p0[0] + ((i * 0.37) % 1 - 0.5) * 10 * C.k, d = 1 + (i % 3) * 0.35; return `<circle cx="${f1(ox)}" cy="${f1(p0[1])}" r="${f1((0.25 + (i % 3) * 0.12) * C.k)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.12 * C.k)}" opacity="0">${an('cy', `${f1(p0[1])};${f1(p1[1])}`, d, -i * 0.23)}${an('opacity', '0;0.9;0.9;0', d, -i * 0.23)}</circle>`; }).join('') : '';
      const gH = sg => cyl3(C, [GX + sg * 7.2, TY + 9.4, GZ], [GX + sg * 10, TY + 9.8, GZ], 0.75, '#e6f6fa', { mat: 'gloss', n: 12, op: 0.4, olc: '#8ab4c0', olw: 0.25 });
      const gp = cyl3(C, [GX, TY, GZ], [GX, TY + 0.6, GZ], 6.6, '#a8aeb4', { mat: 'chrome', n: 24, olw: 0.25 })
        + egg(-2.6, 2.3, 1, 0) + egg(2.4, 2.3, -1.4, 1) + egg(0.4, 4.6, 0.8, 2)
        + cyl3(C, [GX, TY + 0.6, GZ], [GX, TY + 8, GZ], 6.9, '#9fd4e4', { mat: 'gloss', n: 28, op: 0.36, olw: 0.15, olc: '#6aa8bc', cap: water }) + bub
        + cyl3(C, [GX, TY + 0.1, GZ], [GX, TY + 11, GZ], 7.4, '#e6f6fa', { mat: 'chrome', n: 30, op: 0.2, noCap: 1, olc: '#8ab4c0', olw: 0.3 })
        + PLN(C, [GX, TY + 11, GZ], [1, 0, 0], [0, 0, 1], `<circle r="7.4" fill="none" stroke="#ffffff" stroke-opacity="0.75" stroke-width="0.45"/><circle r="7.4" fill="none" stroke="#8ab4c0" stroke-opacity="0.6" stroke-width="0.15"/>`);
      const pot = { q: [GX, TY + 5, GZ], s: (C.v[0] > 0 ? gH(-1) : gH(1)) + gp + (C.v[0] > 0 ? gH(1) : gH(-1)) };
      // marble salt cellar + gold spoon (back middle)
      const SX = -1, SZ = -19;
      const salt = cr => `<circle r="${f1(cr * 0.86)}" fill="#fbfaf6"/><circle r="${f1(cr)}" fill="none" stroke="${BR}" stroke-width="0.3"/>` + rep(12, i => `<rect x="${f1(Math.cos(i * 2.4) * cr * 0.5)}" y="${f1(Math.sin(i * 2.4) * cr * 0.5)}" width="0.6" height="0.6" fill="#e8e4dc" transform="rotate(${i * 33} ${f1(Math.cos(i * 2.4) * cr * 0.5)} ${f1(Math.sin(i * 2.4) * cr * 0.5)})"/>`).join('');
      const sc = { q: [SX, TY + 1.5, SZ], s: cyl3(C, [SX, TY, SZ], [SX, TY + 2.8, SZ], 2.6, '#efe9e0', { r2: 3.4, mat: 'gloss', n: 24, olw: 0.3, cap: salt }) + stick(C, [SX + 0.6, TY + 2.2, SZ + 0.3], [SX + 4.6, TY + 4.2, SZ + 1.6], 0.28, BR, 'metal') + sph(C, [SX + 0.4, TY + 2.3, SZ + 0.2], 0.8, BR) };
      const items = vsort(C, [pan, pot, sc]);
      // floating holo readouts (always face you)
      const holo = (z, y, yb, i) => { C.p(z.x, y + 4, z.z); return PLN(C, [z.x, y, z.z], C.rt, [0, -1, 0], `<g>${an('opacity', '0.85;1;0.9;1', 0.9, -i * 0.3)}${still ? '' : at('translate', '0 0;0 -0.8;0 0', 3, -i, SPL(2))}<path d="M0 2.4V${f1(y - yb)}" stroke="${CY}" stroke-opacity="0.35" stroke-width="0.25" stroke-dasharray="0.6 0.6"/>`
        + `<rect x="-8" y="-4.4" width="16" height="7.4" rx="1.4" fill="#0e2a3a" fill-opacity="0.78" stroke="${CY}" stroke-opacity="0.85" stroke-width="0.3"/><rect x="-8" y="-4.4" width="16" height="7.4" rx="1.4" fill="${CY}" opacity="0.25" filter="url(#m10b1)"/><text y="-1.6" text-anchor="middle" ${FONT} font-size="1.5" fill="${CYL}" letter-spacing="0.5">${z.t}</text><text y="2.1" text-anchor="middle" ${FONT} font-size="3.2" fill="#f0fcff">${z.v}</text></g>`); };
      const holos = on ? holo(Z[0], TY + 14, TY + 5, 0) + holo(Z[1], TY + 19, TY + 11, 1) : '';
      let s = shadow(C, 0, -1, 46, 34, 0.7) + glow + front + halos + items + holos;
      if (on) { s += mist(C, PX, TY + 6, PZ, 3, 0.6) + mist(C, GX, TY + 11, GZ, 4, 0.7); C.p(0, TY + 26, 0); }
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= DISHWASHERS (r.kind 'dish') =======================
  // st: '' dirty dishes waiting | 'load' door down, rack out with dirty dishes | 'wash' door shut, running | 'clean' door down, rack out, sparkling dishes.
  // Open door = a flat box lying forward from the hinge (inner face = its top); the body gets a front hole + cavity() so the tub shows. Racks are wire panels
  // (base + 4 sides) sorted with the dishes by depth.
  const DEFD = DEFR + '<radialGradient id="k28fl" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ff5a44" stop-opacity="0.95"/><stop offset="0.45" stop-color="#ff3020" stop-opacity="0.35"/><stop offset="1" stop-color="#ff3020" stop-opacity="0"/></radialGradient>';
  const spk = (C, q, s, b) => { const p = C.P(q); return `<g transform="translate(${P2(p)}) scale(${n4(C.k * s)})"><path d="M0 -2.6Q0.3 -0.3 2.6 0Q0.3 0.3 0 2.6Q-0.3 0.3 -2.6 0Q-0.3 -0.3 0 -2.6Z" fill="#ffffff" opacity="0">${an('opacity', '0;1;0;0', 1.8, b, ' keyTimes="0;0.15;0.4;1"')}${at('scale', '0.3;1.2;0.3;0.3', 1.8, b, ' keyTimes="0;0.15;0.4;1"')}</path></g>`; };
  const smear = (cr, i) => `<g transform="rotate(${(i * 67) % 360})"><path d="M${f1(-cr * 0.42)} ${f1(cr * 0.12)}Q${f1(-cr * 0.05)} ${f1(-cr * 0.38)} ${f1(cr * 0.38)} ${f1(-cr * 0.05)}" stroke="#a8682a" stroke-opacity="0.5" stroke-width="${f1(cr * 0.16)}" stroke-linecap="round" fill="none"/><circle cx="${f1(cr * 0.2)}" cy="${f1(cr * 0.3)}" r="${f1(cr * 0.07)}" fill="#6a9a3a"/><circle cx="${f1(-cr * 0.25)}" cy="${f1(cr * 0.32)}" r="${f1(cr * 0.06)}" fill="#c84a2a" opacity="0.8"/></g>`;
  const dface = (dirty, i, rim) => cr => `<circle r="${f1(cr * 0.62)}" fill="#000000" opacity="0.035"/><circle r="${f1(cr * 0.64)}" fill="none" stroke="#000000" stroke-opacity="0.1" stroke-width="0.22"/><circle r="${f1(cr * 0.86)}" fill="none" stroke="${rim || '#5a8ab4'}" stroke-opacity="0.55" stroke-width="0.3"/>`
    + (dirty ? smear(cr, i) : `<path d="M${f1(-cr * 0.56)} ${f1(-cr * 0.26)}A${f1(cr * 0.62)} ${f1(cr * 0.62)} 0 0 1 ${f1(-cr * 0.12)} ${f1(-cr * 0.6)}" stroke="#ffffff" stroke-width="0.5" fill="none"/>`);
  // plate standing on its rim, face toward +z / lying flat
  const plateZ = (C, x, y, z, r, col, dirty, i, rim) => cyl3(C, [x, y + r, z - 0.4], [x, y + r, z + 0.4], r, col, { mat: 'gloss', n: 24, olw: 0.22, cap: dface(dirty, i, rim) });
  const plateF = (C, x, y, z, r, col, dirty, i, rim) => cyl3(C, [x, y, z], [x, y + 0.8, z], r * 0.82, col, { r2: r, mat: 'gloss', n: 24, olw: 0.22, cap: dface(dirty, i, rim) });
  // mug with a handle toward +x (inv = upside down)
  const mugH = (C, x, y, z, r, h, col, inv, fill) => { const b = cyl3(C, [x, y, z], [x, y + h, z], r, col, { mat: 'gloss', n: 18, olw: 0.25, capCol: inv ? shade(col, 1.05) : undefined, cap: inv ? null : cr => `<circle r="${f1(cr * 0.82)}" fill="${fill || shade(col, 0.55)}"/>` });
    const hd = `<path d="M${P2(C.P([x + r * 0.9, y + h * 0.78, z]))}C${P2(C.P([x + r + 2.6, y + h * 0.8, z]))} ${P2(C.P([x + r + 2.6, y + h * 0.22, z]))} ${P2(C.P([x + r * 0.9, y + h * 0.24, z]))}" stroke="${shade(col, 0.8)}" stroke-width="${f1(0.9 * C.k)}" fill="none" stroke-linecap="round"/>`;
    return C.v[0] > 0 ? b + hd : hd + b; };
  // wire rack: base grid + 4 side panels as sortable items
  const wrack = (C, x0, x1, y, z0, z1, h, col) => { const W2 = x1 - x0, D2 = z1 - z0;
    const base = PLN(C, [x0, y, z0], [1, 0, 0], [0, 0, 1], `<rect width="${f1(W2)}" height="${f1(D2)}" fill="none" stroke="${col}" stroke-width="0.55"/>` + rep(Math.floor(W2 / 3), i => `<path d="M${f1(1.5 + i * 3)} 0V${f1(D2)}" stroke="${col}" stroke-width="0.25"/>`).join('') + rep(Math.floor(D2 / 3), i => `<path d="M0 ${f1(1.5 + i * 3)}H${f1(W2)}" stroke="${col}" stroke-width="0.25"/>`).join(''));
    const side = (O, U, L) => PLN(C, O, U, [0, -1, 0], `<rect width="${f1(L)}" height="${f1(h)}" fill="none" stroke="${col}" stroke-width="0.45"/><path d="M0 0.1H${f1(L)}" stroke="#000000" stroke-opacity="0.25" stroke-width="0.2"/>` + rep(Math.floor(L / 2.4), i => `<path d="M${f1(1.2 + i * 2.4)} 0V${f1(h)}" stroke="${col}" stroke-width="0.22"/>`).join(''));
    return { base, S: [{ q: [(x0 + x1) / 2, y + h / 2, z0], s: side([x0, y + h, z0], [1, 0, 0], W2) }, { q: [(x0 + x1) / 2, y + h / 2, z1], s: side([x0, y + h, z1], [1, 0, 0], W2) }, { q: [x0, y + h / 2, (z0 + z1) / 2], s: side([x0, y + h, z0], [0, 0, 1], D2) }, { q: [x1, y + h / 2, (z0 + z1) / 2], s: side([x1, y + h, z0], [0, 0, 1], D2) }] }; };
  const bubl = (C, x, y, z, w, n, hg, b0) => rep(n, i => { const p = C.P([x + ((i * 0.618) % 1 - 0.5) * w, y, z + (((i * 0.37) % 1) - 0.5) * w * 0.5]), d = 1.6 + (i % 3) * 0.5, bb = -((i * 0.37 + (b0 || 0)) % d);
    return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1((0.5 + (i % 3) * 0.35) * C.k)}" fill="#ffffff" fill-opacity="0.25" stroke="#ffffff" stroke-width="${f1(0.15 * C.k)}" opacity="0">${an('cy', `${f1(p[1])};${f1(p[1] - hg * C.k)}`, d, bb)}${an('opacity', '0;0.9;0.8;0', d, bb)}</circle>`; }).join('');
  const grainH = (R, w, h, n, c) => rep(n, () => { const y = R() * h, a = (R() - 0.5) * 1.6; return `<path d="M0 ${f1(y)}C${f1(w * 0.33)} ${f1(y + a)} ${f1(w * 0.66)} ${f1(y - a)} ${f1(w)} ${f1(y + a * 0.4)}" stroke="${c}" stroke-opacity="${n4(0.15 + R() * 0.25)}" stroke-width="${f1(0.15 + R() * 0.4)}" fill="none"/>`; }).join('');

  // ======================= KIT-006 PLASTIC DISH DRYING RACK & DISHPAN =======================
  // an old "FARM FRESH" produce crate used as a counter: blue plastic dishpan of water (plates under the surface), white wire drying rack on a drip tray,
  // squeezy green dish soap, a little stack of side plates + fork, gingham towel on the crate front. '' greasy water, sponge on the rim, a fly buzzing |
  // load foam growing, sponge in | wash foam, bubbles, sponge scrubbing | clean clear water, plates + bowls standing in the rack, drips falling, sparkles.
  N.pan28 = S => { const st = S.st || '', load = st === 'load', wash = st === 'wash', clean = st === 'clean', CW = '#c8a06a', CT = 22, TX = -24, TZ = 0, TW = 32, TD = 28, TH = 12, WY = CT + TH - 1.4;
    const D = { w: 92, d: 40, build: () => [] };
    const R = rng('pan28');
    const crF = L => grainH(R, L, 22, 14, '#6a4a28') + [7.2, 14.6].map(y => `<rect y="${y}" width="${L}" height="0.8" fill="#3a2a18" opacity="0.75"/>`).join('') + rep(6, i => `<circle cx="${f1(i % 2 ? L - 2 : 2)}" cy="${f1(3.4 + Math.floor(i / 2) * 7.4)}" r="0.35" fill="#4a4a4a"/>`).join('');
    const fF = crF(84) + `<text x="58" y="12.6" text-anchor="middle" font-family="Georgia,serif" font-weight="700" font-size="4.2" fill="#7a2a1a" opacity="0.5" letter-spacing="0.6">FARM FRESH</text><text x="58" y="17.4" text-anchor="middle" ${FONT} font-size="2" fill="#7a2a1a" opacity="0.45">APPLES · No.6</text>`;
    const sF = crF(36) + `<rect x="12" y="3" width="12" height="3.4" rx="1.7" fill="#2a1c10"/>`;
    const tD = grainH(R, 84, 36, 16, '#6a4a28') + [12, 24].map(z => `<rect y="${z - 0.4}" width="84" height="0.8" fill="#3a2a18" opacity="0.7"/>`).join('') + `<ellipse cx="45" cy="26" rx="3" ry="1.8" fill="#3a2a18" opacity="0.15"/>`;
    const towel = `<g>${at('rotate', '-2 5 0;2 5 0;-2 5 0', 5, 0, SPL(2))}<path d="M0 0H10V13Q5 13.8 0 13Z" fill="url(#k28ging)"/><path d="M0 0H10V13Q5 13.8 0 13Z" fill="url(#m10v)"/><path d="M0 0H10V1.6Q5 2.4 0 1.6Z" fill="#e8ddd0"/><path d="M3 0.6Q3.4 7 2.8 12.8" stroke="#000000" stroke-opacity="0.08" stroke-width="0.8" fill="none"/></g>`;
    // water surface (cavity floor decal, u along x, v along z)
    const wW = TW - 2.8, wD = TD - 2.8, wcol = clean ? '#cfe2ea' : load || wash ? '#d8e6ea' : '#b4beac';
    let wat = `<rect width="${f1(wW)}" height="${f1(wD)}" fill="${wcol}" opacity="0.85"/>` + [[8, 9, 0], [18, 15, 1], [11, 18, 2]].map(([x, y, i]) => `<g transform="translate(${x} ${y})" opacity="0.4"><circle r="7" fill="#ffffff"/><circle r="5.4" fill="none" stroke="#5a8ab4" stroke-width="0.3"/>${clean ? '' : smear(7, i)}</g>`).join('')
      + `<rect width="${f1(wW)}" height="${f1(wD)}" fill="${wcol}" opacity="0.35"/>`;
    if (!st) wat += `<path d="M4 6Q10 3 15 7T26 6" stroke="#c8a0e0" stroke-opacity="0.4" stroke-width="0.6" fill="none"/><path d="M6 19Q12 16 18 20" stroke="#a0d0a0" stroke-opacity="0.4" stroke-width="0.5" fill="none"/><circle cx="20" cy="8" r="0.7" fill="#6a9a3a"/><circle cx="9" cy="15" r="0.5" fill="#c84a2a"/>`;
    if (load || wash) { const nF = wash ? 30 : 14; wat += `<g>${wash ? at('translate', '0 0;0.4 -0.3;-0.3 0.2;0 0', 1.6) : ''}` + rep(nF, i => { const x = 2 + ((i * 0.618) % 1) * (wW - 4), y = 2 + ((i * 0.41) % 1) * (wD - 4), r = 1.4 + (i % 4) * 0.7; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="#ffffff" opacity="0.85"/><circle cx="${f1(x - r * 0.3)}" cy="${f1(y - r * 0.3)}" r="${f1(r * 0.3)}" fill="#e0f0ff"/>`; }).join('') + '</g>'; }
    if (clean) wat += rep(5, i => `<circle cx="${f1(4 + i * 5.2)}" cy="${f1(5 + (i % 2) * 12)}" r="0.8" fill="none" stroke="#ffffff" stroke-width="0.3"/>`).join('');
    const defs = DEFD + `<defs>${sym('k28p_f', fF)}${sym('k28p_s', sF)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const crate = box3(C, { c: [0, 0, 0], w: 84, h: CT, d: 36, r: 0.6, col: CW, olw: 0.5, olo: 0.7, dec: { f: use('k28p_f'), b: use('k28p_f'), l: use('k28p_s'), r: use('k28p_s'), t: tD } });
      const tw = PLN(C, [-36, CT - 0.4, 18.05], [1, 0, 0], [0, -1, 0], towel);
      // dishpan: inner walls + water, then the tub shell with a top hole
      const tub = cavity(C, TX - TW / 2 + 1.4, TX + TW / 2 - 1.4, WY, CT + TH, TZ - TD / 2 + 1.4, TZ + TD / 2 - 1.4, '#5a9ac0', { dk: 0.3, floor: wat })
        + box3(C, { c: [TX, CT, TZ], w: TW, h: TH, d: TD, r: 4, col: '#6fb0d4', gl: 0.5, olw: 0.4, olo: 0.7, hole: { t: 1.4 } });
      let tubX = '';
      if (!st) tubX += box3(C, { c: [TX + 10, CT + TH, TZ + TD / 2 - 2.2], w: 7, h: 2.6, d: 4.4, r: 0.6, col: '#f2d24a', olw: 0.3, dec: { t: '<rect width="7" height="4.4" fill="#4a9a4a" opacity="0.9"/>' } });
      if (load || wash) { const sp = box3(C, { c: [TX + 4, WY - 0.6, TZ + 2], w: 7, h: 2.6, d: 4.4, r: 0.6, col: '#f2d24a', olw: 0.3, dec: { t: '<rect width="7" height="4.4" fill="#4a9a4a" opacity="0.9"/>' } });
        tubX += wash ? `<g>${at('translate', `0 0;${f1(3 * C.k)} ${f1(-0.6 * C.k)};${f1(-2 * C.k)} ${f1(0.4 * C.k)};0 0`, 0.7)}${sp}</g>` + bubl(C, TX, WY + 1, TZ, 24, 9, 14) : sp; }
      // drying rack on a drip tray
      const RX0 = 6, RX1 = 40, RZ0 = -13, RZ1 = 11, RY = CT + 1.4;
      const tray = box3(C, { c: [23, CT, -1], w: 38, h: 1.4, d: 28, r: 1.6, col: '#e8e6e0', gl: 0.4, olw: 0.3, dec: { t: clean ? rep(6, i => `<ellipse cx="${f1(6 + i * 5)}" cy="${f1(8 + (i % 3) * 5)}" rx="1.2" ry="0.7" fill="#a8d0e0" opacity="0.6"/>`).join('') : '' } });
      const rk = wrack(C, RX0, RX1, RY, RZ0, RZ1, 9, '#f4f4f0');
      const L = rk.S.slice();
      if (clean) { rep(5, i => L.push({ q: [14, RY + 6, RZ0 + 3 + i * 4.4], s: plateZ(C, 14, RY, RZ0 + 3 + i * 4.4, 7.6, '#ffffff', 0, i) }));
        rep(3, i => L.push({ q: [30, RY + 5, RZ0 + 4 + i * 6.6], s: plateZ(C, 30, RY, RZ0 + 4 + i * 6.6, 5.6, '#e8f0f6', 0, i, '#c8784a') })); }
      else L.push({ q: [32, RY + 4, -2], s: mugH(C, 32, RY, -2, 2.8, 6.4, '#d8784a', 1) }, { q: [24, RY + 4, 4], s: mugH(C, 24, RY, 4, 2.6, 6, '#7ab0a0', 1) });
      const caddy = cyl3(C, [43.4, RY + 2, 6], [43.4, RY + 10, 6], 2.4, '#f4f4f0', { mat: 'gloss', n: 16, olw: 0.3, capCol: '#3a3a3a' }) + [[-0.8, 13, '#c8ccd0'], [0.6, 12.4, '#c8ccd0'], [0, 13.6, '#b88a52']].map(([dx, h, c]) => H2(C, [43.4 + dx, RY + 9, 6], [43.4 + dx * 1.6, RY + h, 6], 0.5, c)).join('');
      L.push({ q: [43.4, RY + 6, 6], s: caddy });
      let rack = tray + rk.base + vsort(C, L);
      if (clean) { rack += rep(4, i => { const a = C.P([14 + (i % 2 ? 4 : -4), RY + 0.6, RZ0 + 3 + i * 4.4]); return `<ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="${f1(0.35 * C.k)}" ry="${f1(0.5 * C.k)}" fill="#cfe8f4" opacity="0">${an('cy', `${f1(a[1])};${f1(a[1] + 1.6 * C.k)}`, 2.2, -i * 0.55)}${an('opacity', '0;0.9;0', 2.2, -i * 0.55)}</ellipse>`; }).join('')
          + [[14, 16, -7], [14, 16, 2], [30, 12, 0], [14, 16, 10]].map(([x, y, z], i) => spk(C, [x, RY + y, z], 0.6, -i * 0.45)).join(''); }
      // soap + little stack of side plates
      const soap = bottle(C, -2, CT, -9, 2.3, 9, '#5ac85a', '#f2d24a', { op: 0.88, lbl: `<rect x="-1.4" y="-1.4" width="2.8" height="2.8" fill="#ffffff" opacity="0.8"/><circle r="0.8" fill="#f2d24a"/>` });
      const stack = clean ? '' : rep(3, i => plateF(C, -2, CT + i * 1, 8, 5.2, '#f4f2ee', i === 2, i)).join('') + H2(C, [-4, CT + 3.2, 7], [2.4, CT + 3.6, 11], 0.45, '#c8ccd0');
      const items = vsort(C, [{ q: [TX, CT + 6, TZ], s: tub + tubX }, { q: [23, CT + 4, -1], s: rack }, { q: [-2, CT + 4, -9], s: soap }, { q: [-2, CT + 2, 8], s: stack }]);
      let s = shadow(C, 0, 0, 48, 24, 0.8) + (fv ? crate + tw : tw + crate) + items;
      if (!st) { const p = C.P([TX, CT + 22, TZ]); s += `<g transform="translate(${P2(p)}) scale(${n4(C.k)})"><g>${at('translate', '0 0;5 -2.6;0 -5;-5 -2.4;0 0', 2.6, 0, SPL(4))}<ellipse cx="-0.7" cy="-0.6" rx="1" ry="0.5" fill="#e8f0f8" opacity="0.7" transform="rotate(-30 -0.7 -0.6)">${an('ry', '0.5;0.1;0.5', 0.08)}</ellipse><ellipse cx="0.7" cy="-0.6" rx="1" ry="0.5" fill="#e8f0f8" opacity="0.7" transform="rotate(30 0.7 -0.6)">${an('ry', '0.5;0.1;0.5', 0.08)}</ellipse><ellipse rx="0.8" ry="0.6" fill="#1a1a1a"/></g></g>`; C.p(TX, CT + 30, TZ); }
      if (wash) s += mist(C, TX, WY + 2, TZ, 2, 0.4);
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-026 COUNTERTOP PORTABLE MINI DISHWASHER =======================
  // glossy white 6-place countertop unit on a white rolling cart (rolled towels + a box of pods on the lower shelf), grey faucet hose looping off the back,
  // drop-down door with a smoky window, dark control strip (display + 4 buttons), tub of pods on top. '' dirty stack on top, ECO light breathing |
  // load door down, rack out with dirty plates + mugs | wash window lit blue: spray arm spinning, jets, drips on the glass, suds; countdown, steam puff, water
  // running through the hose | clean rack out with sparkling dishes, steam rising, DONE.
  N.mini28 = S => { const st = S.st || '', open = st === 'load' || st === 'clean', wash = st === 'wash', clean = st === 'clean', WH2 = '#f4f2ee', CY0 = 27, W = 46, H = 40, Z0 = -20, ZF = 20, DY = CY0 + 2.4, DH = 28, DT = 2.4, PF = 'k28m_';
    const D = { w: 56, d: 48 + (open ? 30 : 0), build: () => [] };
    const DSP = { '': ['ECO', '#7ad87a'], load: ['OPEN', '#ffc84a'], wash: ['0:42', '#7ad0ff'], clean: ['DONE', '#7ad87a'] }[st] || ['ECO', '#7ad87a'];
    let bF = `<rect x="3" y="1.8" width="40" height="6.4" rx="1.6" fill="#24282c"/><rect x="3.6" y="2.1" width="38.8" height="1.6" rx="0.8" fill="#ffffff" opacity="0.08"/><rect x="5.6" y="3" width="11" height="4" rx="0.6" fill="#0a0c0e"/>`
      + `<text x="11.1" y="6.1" text-anchor="middle" ${FONT} font-size="2.6" fill="${DSP[1]}">${st === 'wash' ? `0<tspan>${an('fill-opacity', '1;1;0;0', 2, 0, ' calcMode="discrete"')}:</tspan>42` : DSP[0]}</text>`
      + [24, 29.5, 35, 40.5].map((x, i) => `<circle cx="${x}" cy="5" r="1.7" fill="#3a3e44" stroke="#5a6068" stroke-width="0.25"/><circle cx="${x - 0.4}" cy="4.5" r="0.6" fill="#ffffff" opacity="0.15"/>` + [`<path d="M${x - 0.7} 5.6V4.4H${x + 0.7}V5.6" stroke="#c8ccd0" stroke-width="0.25" fill="none"/>`, `<path d="M${x - 0.8} 5L${x} 4.2L${x + 0.8} 5" stroke="#c8ccd0" stroke-width="0.25" fill="none"/>`, `<circle cx="${x}" cy="5" r="0.7" fill="none" stroke="#c8ccd0" stroke-width="0.25"/>`, `<path d="M${x - 0.5} 4.2L${x + 0.7} 5L${x - 0.5} 5.8Z" fill="#c8ccd0"/>`][i]).join('')
      + `<circle cx="19.8" cy="5" r="0.55" fill="${DSP[1]}">${!st || wash ? an('opacity', '1;0.2;1', wash ? 0.8 : 2.6) : ''}</circle><rect x="1.6" y="9.1" width="42.8" height="29" rx="1.4" fill="#000000" opacity="0.12"/>`;
    const sD = `<rect x="8" y="10" width="24" height="14" rx="1" fill="#000000" opacity="0.04"/>` + rep(6, i => `<rect x="10" y="${f1(12 + i * 2)}" width="20" height="0.9" rx="0.45" fill="#c8c6c0"/>`).join('') + `<rect x="26" y="28" width="9" height="5" rx="0.4" fill="#ffffff"/><rect x="26" y="28" width="9" height="1.4" fill="#3a8ac8"/><text x="30.5" y="32.2" text-anchor="middle" font-family="Arial" font-size="1" fill="#3a3a3a">6 PLACE</text>`;
    const tD = rep(8, i => `<rect x="${f1(16 + i * 2)}" y="4" width="0.9" height="7" rx="0.45" fill="#c8c6c0"/>`).join('') + `<text x="23" y="36" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-size="2.2" fill="#b8b6b0">QuickClean</text>`;
    // door window content (32 x 18)
    let win = `<rect width="32" height="18" rx="2" fill="${wash ? '#0e2a3e' : '#1a2028'}"/>`;
    const sil = rep(4, i => `<ellipse cx="${f1(7 + i * 5)}" cy="11" rx="1.2" ry="5.4" fill="#c8d0d8" opacity="${wash ? 0.35 : 0.22}"/>`).join('') + `<rect x="24" y="9" width="4.6" height="5.6" rx="0.8" fill="#d8784a" opacity="${wash ? 0.4 : 0.25}"/>`;
    if (wash) win += `<rect width="32" height="18" rx="2" fill="#3a8ac8" opacity="0.35">${an('opacity', '0.25;0.45;0.25', 1.4)}</rect>` + sil
      + rep(7, i => { const x0 = 16 + (i - 3) * 2.6, x1 = 16 + (i - 3) * 4.4; return `<path d="M${f1(x0)} 15Q${f1((x0 + x1) / 2)} 4 ${f1(x1)} 2" stroke="#cfeeff" stroke-width="0.45" fill="none" stroke-dasharray="1 1.4" opacity="0.85">${an('stroke-dashoffset', '0;-4.8', 0.4)}</path>`; }).join('')
      + `<g transform="translate(16 15.4)"><g>${at('scale', '1 1;0.1 1;-1 1;0.1 1;1 1', 0.8)}<rect x="-11" y="-0.6" width="22" height="1.2" rx="0.6" fill="#9ab8c8"/></g><circle r="1" fill="#6a8898"/></g>`
      + `<path d="M0 16.4Q4 15.4 8 16.4T16 16.4T24 16.4T32 16.4V18H0Z" fill="#ffffff" opacity="0.6">${at('translate', '0 0;-4 0;0 0', 1.2)}</path>`
      + rep(6, i => { const x = 3 + i * 5.1, y0 = 1.5 + (i % 3) * 2; return `<ellipse cx="${f1(x)}" cy="${f1(y0)}" rx="0.35" ry="0.55" fill="#e8f8ff" opacity="0.7">${an('cy', `${f1(y0)};${f1(y0 + 7)}`, 2.4 + i * 0.3, -i * 0.5)}</ellipse>`; }).join('');
    else win += sil;
    win += refl(32, 18);
    const dF = `<rect x="13" y="0.8" width="16" height="1.8" rx="0.9" fill="#3a3e44"/><rect x="4.4" y="3" width="33.2" height="19.2" rx="2.4" fill="#d8d6d0"/><g transform="translate(5 3.6)">${win}</g>`
      + `<text x="21" y="25.2" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-size="2" fill="#8a9098">QuickClean</text><text x="21" y="27" text-anchor="middle" ${FONT} font-size="0.9" fill="#a8aeb4" letter-spacing="0.6">MINI · 6 PLACE</text>`;
    const dI = `<rect x="2" y="2" width="38" height="24" rx="1.6" fill="none" stroke="#9aa0a6" stroke-width="0.5"/><rect x="14" y="21.4" width="14" height="4" rx="0.6" fill="#d8dce0" stroke="#9aa0a6" stroke-width="0.3"/>` + (clean ? '' : `<circle cx="21" cy="23.4" r="1.3" fill="#3a8ac8"/><circle cx="20.6" cy="23" r="0.5" fill="#ffffff" opacity="0.6"/>`);
    const defs = DEFD + `<defs>${sym(PF + 'f', bF)}${sym(PF + 'd', dF)}${sym(PF + 's', sD)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      // cart
      const legs = [[-25, -21], [25, -21], [-25, 21], [25, 21]].map(([x, z]) => ({ q: [x, 12, z], s: cyl3(C, [x, 3.2, z], [x, CY0 - 1.6, z], 0.9, '#e8e8e4', { mat: 'gloss', n: 10, olw: 0.25 }) + sph(C, [x, 1.6, z], 1.6, '#3a3a3e') }));
      const sh1 = box3(C, { c: [0, 6, 0], w: 52, h: 1.4, d: 44, r: 1.2, col: '#f2f0ea', gl: 0.4, olw: 0.3 });
      const towels = [-14, -6].map(x => cyl3(C, [x, 10.8, -12], [x, 10.8, 12], 3.4, x < -10 ? '#9ac8d8' : '#f0d8a8', { mat: 'matte', n: 16, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.7)}" fill="none" stroke="#000000" stroke-opacity="0.15" stroke-width="0.3"/><circle r="${f1(cr * 0.35)}" fill="none" stroke="#000000" stroke-opacity="0.15" stroke-width="0.3"/>` })).join('');
      const pods = box3(C, { c: [12, 7.4, 0], w: 16, h: 11, d: 12, r: 0.6, col: '#f08a2a', gl: 0.3, olw: 0.35, dec: { f: `<rect y="2" width="16" height="4.4" fill="#ffffff"/><text x="8" y="5.4" text-anchor="middle" ${FONT} font-size="2.6" fill="#2a6ac8">SPARKL</text><circle cx="5" cy="8.6" r="1.4" fill="#3a8ac8"/><circle cx="8" cy="8.6" r="1.4" fill="#f2d24a"/><circle cx="11" cy="8.6" r="1.4" fill="#5ac85a"/>` } });
      const lb = legs.filter(l => dot(l.q, C.v) < 0).map(l => l.s).join(''), lf = legs.filter(l => dot(l.q, C.v) >= 0).map(l => l.s).join('');
      const sh2 = box3(C, { c: [0, CY0 - 1.6, 0], w: 54, h: 1.6, d: 46, r: 1.2, col: '#f2f0ea', gl: 0.4, olw: 0.3 });
      const cart = lb + sh1 + (C.v[2] > 0 ? towels + pods : pods + towels) + lf + sh2;
      // unit
      const body = box3(C, { c: [0, CY0, 0], w: W, h: H, d: ZF - Z0, r: 3, col: WH2, gl: 0.6, olw: 0.45, olo: 0.6, hole: open ? { f: [2, 9.6, 2, 2.4] } : null, dec: { f: use(PF + 'f'), r: use(PF + 's'), l: use(PF + 's'), t: tD } });
      const cav = open && fv ? cavity(C, -21, 21, DY, DY + DH - 0.4, Z0 + 2.4, ZF, '#b8c0c8', { dk: 0.45, floor: `<rect x="6" y="16" width="30" height="2.2" rx="1.1" fill="#8a9298"/>` + rep(8, i => `<circle cx="${f1(8 + i * 3.7)}" cy="17.1" r="0.35" fill="#3a3e44"/>`).join('') + `<circle cx="21" cy="17.1" r="2" fill="#6a7278"/>` }) : '';
      let door = '', rack = '';
      if (!open) door = box3(C, { c: [0, DY, ZF + DT / 2], w: 42, h: DH, d: DT, r: 1.4, col: WH2, gl: 0.6, olw: 0.4, olo: 0.6, dec: { f: use(PF + 'd') } });
      else { door = box3(C, { c: [0, DY, ZF + DH / 2], w: 42, h: DT, d: DH, r: 1.4, col: WH2, gl: 0.6, olw: 0.4, olo: 0.6, dec: { t: dI } });
        const ry = DY + DT + 0.6, rk = wrack(C, -17, 17, ry, ZF + 2, ZF + DH - 3, 6.4, '#d8dce0'), L = rk.S.slice();
        rep(4, i => L.push({ q: [-8, ry + 5, ZF + 5 + i * 4.6], s: plateZ(C, -8, ry, ZF + 5 + i * 4.6, 6.2, '#ffffff', !clean, i) }));
        L.push({ q: [8, ry + 3, ZF + 8], s: mugH(C, 8, ry, ZF + 8, 2.6, 5.6, '#d8784a', 0, clean ? '#e8e0d8' : '#5a3a20') }, { q: [8, ry + 3, ZF + 16], s: mugH(C, 8, ry, ZF + 16, 2.6, 5.6, '#7ab0a0', 0, clean ? '#e8f0ec' : '#5a3a20') });
        rack = rk.base + vsort(C, L);
        if (clean) rack += [[-8, 12, ZF + 6], [-8, 12, ZF + 15], [8, 7, ZF + 8], [-8, 12, ZF + 20]].map(([x, y, z], i) => spk(C, [x, ry + y, z], 0.55, -i * 0.45)).join(''); }
      // faucet hose off the back right
      const hp = rep(17, i => { const t = i / 16, u = 1 - t, P0 = [15, CY0 + 8, Z0], P1 = [15, CY0 + 8, Z0 - 12], P2 = [27, CY0 - 6, Z0 - 10], P3 = [26, 7.4, Z0 - 2];
        return C.P([0, 1, 2].map(k => u * u * u * P0[k] + 3 * u * u * t * P1[k] + 3 * u * t * t * P2[k] + t * t * t * P3[k])); }), hd = 'M' + hp.map(P2).join('L');
      const hose = `<path d="${hd}" stroke="#8a9096" stroke-width="${f1(1.6 * C.k)}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${hd}" stroke="#5a6066" stroke-width="${f1(1.6 * C.k)}" fill="none" stroke-dasharray="${f1(0.25 * C.k)} ${f1(0.7 * C.k)}"/><path d="${hd}" stroke="#c8ccd0" stroke-width="${f1(0.4 * C.k)}" fill="none" opacity="0.6"/>`
        + (wash ? `<path d="${hd}" stroke="#9ad8ff" stroke-width="${f1(0.7 * C.k)}" fill="none" stroke-linecap="round" stroke-dasharray="${f1(0.6 * C.k)} ${f1(5 * C.k)}">${an('stroke-dashoffset', `0;${f1(-5.6 * C.k)}`, 0.7)}</path>` : '') + cyl3(C, [15, CY0 + 6.6, Z0 + 0.6], [15, CY0 + 9.4, Z0 + 0.6], 1.6, '#c8ccd0', { mat: 'chrome', n: 12, olw: 0.2 });
      // on top: pods tub + dirty stack or a folded cloth
      const UT = CY0 + H, tub = { q: [-12, UT + 2, -8], s: cyl3(C, [-12, UT, -8], [-12, UT + 4.6, -8], 3.4, '#ffffff', { mat: 'gloss', n: 20, olw: 0.3, noCap: 1 }) + cyl3(C, [-12, UT + 4.6, -8], [-12, UT + 5.8, -8], 3.6, '#5ac85a', { mat: 'gloss', n: 20, olw: 0.3 }) + `<g transform="${tanF(C, -12, -8, 3.42, C.thV, UT + 2.4)}"><rect x="-2" y="-1.2" width="4" height="2.4" fill="#2a6ac8"/><text y="0.5" text-anchor="middle" ${FONT} font-size="0.9" fill="#ffffff">PODS</text></g>` };
      const top = !st ? { q: [8, UT + 2, 2], s: rep(3, i => plateF(C, 8, UT + i, 2, 8, '#f4f2ee', 1, i + 3)).join('') + cyl3(C, [6, UT + 3, 0], [6, UT + 6.4, 0], 3.6, '#ffffff', { r2: 5, mat: 'gloss', n: 20, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.8)}" fill="#d8b070" opacity="0.6"/>` }) + H2(C, [6, UT + 6, 0], [12, UT + 8.4, 4], 0.5, '#c8ccd0') }
        : { q: [8, UT + 1, 2], s: box3(C, { c: [8, UT, 2], w: 13, h: 1.6, d: 11, r: 0.8, col: '#7ab8d8', olw: 0.3, dec: { t: rep(3, i => `<rect x="${f1(2 + i * 4)}" width="1" height="11" fill="#ffffff" opacity="0.7"/>`).join(''), f: '<rect y="0.6" width="13" height="0.4" fill="#ffffff" opacity="0.6"/>' } }) };
      const topS = vsort(C, [tub, top]);
      const unit = fv ? hose + cav + body + door + rack + topS : door + rack + body + topS + hose;
      let s = shadow(C, 0, 0, 32, 28, 0.8) + cart + unit;
      if (wash) { s += mist(C, 0, UT + 1, -2, 2, 0.45); C.p(0, UT + 14, 0); }
      if (clean) { s += mist(C, 0, DY + DH - 2, ZF + 2, 3, 0.6); C.p(0, UT + 12, 0); }
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-046 BUILT-IN STAINLESS QUIET-WASH DISHWASHER =======================
  // brushed stainless built-in under a quartz counter: black toe kick, full-width door with a black-glass control strip (display, programme icons, start),
  // "QUIETWASH 42 dB", tubular bar handle with a sage linen towel swaying. Counter: amber soap pump + potted basil. '' dirty stack on the counter, READY |
  // load door down: stainless tub, upper rack of glasses + mugs, lower rack rolled out onto the door (6 plates, 4 bowls, cutlery basket), detergent pod in the
  // dispenser | wash so quiet only the red floor light + time on the floor shows it is running | clean door down, sparkling dishes, steam, dispenser open.
  N.qw28 = S => { const st = S.st || '', open = st === 'load' || st === 'clean', wash = st === 'wash', clean = st === 'clean', SS = '#c6cacd', W = 60, Y0 = 6, HB = 70, TOP = Y0 + HB, ZB = -28, ZF = 26, DY = Y0 + 1, DH = 68, DT = 2.6, PF = 'k28q_';
    const D = { w: 66, d: 62 + (open ? 40 : 0), build: () => [] };
    const brushed = (w, h) => `<rect width="${f1(w)}" height="${f1(h)}" fill="url(#k28br)"/><rect width="${f1(w)}" height="${f1(h)}" fill="url(#k28ss)"/>`;
    const R = rng('qw28');
    const dF = brushed(59.4, DH) + `<rect x="3" y="1.4" width="53.4" height="5.2" rx="1" fill="#0e0f11"/><rect x="3.4" y="1.6" width="52.6" height="1.4" rx="0.7" fill="#ffffff" opacity="0.07"/>`
      + rep(4, i => `<circle cx="${f1(8 + i * 4.4)}" cy="4" r="1.2" fill="none" stroke="${wash && i === 1 ? '#7ad0ff' : '#5a6066'}" stroke-width="0.3"/>`).join('') + `<path d="M49.6 3L51.8 4L49.6 5Z" fill="${wash ? '#7ad0ff' : '#8a9096'}"/>`
      + (wash ? `<text x="35" y="5.2" text-anchor="middle" ${FONT} font-size="2.8" fill="#7ad0ff">0<tspan>${an('fill-opacity', '1;1;0;0', 2, 0, ' calcMode="discrete"')}:</tspan>58</text><text x="43" y="5" text-anchor="middle" ${FONT} font-size="0.9" fill="#7ad0ff">QUIET</text>`
        : `<text x="35" y="5.1" text-anchor="middle" ${FONT} font-size="2.2" fill="#d8dce0" letter-spacing="0.4">READY</text><circle cx="43" cy="4" r="0.6" fill="#ffb43a">${an('opacity', '1;0.2;1', 2.4)}</circle>`)
      + LBL(29.7, 12.6, 'QUIETWASH', 1.7, '#6a7076', ' letter-spacing="1.4"') + LBL(29.7, 64.6, 'STAINLESS · 42 dB', 1.1, '#7a8086', ' letter-spacing="0.8"');
    const sD = brushed(54, HB) + `<rect width="54" height="${HB}" fill="url(#m10v)"/>`;
    const cT = rep(90, () => `<circle cx="${f1(R() * 64)}" cy="${f1(R() * 60)}" r="${f1(0.15 + R() * 0.3)}" fill="${R() < 0.5 ? '#9a948a' : '#ffffff'}" opacity="${n4(0.3 + R() * 0.4)}"/>`).join('') + rep(3, () => { const x = R() * 64; return `<path d="M${f1(x)} 0Q${f1(x + 6)} 30 ${f1(x - 4)} 60" stroke="#b8b2a8" stroke-opacity="0.25" stroke-width="0.5" fill="none"/>`; }).join('');
    const cF = rep(20, () => `<circle cx="${f1(R() * 64)}" cy="${f1(R() * 3.6)}" r="0.2" fill="#9a948a" opacity="0.5"/>`).join('');
    const dI = `<rect x="2" y="1" width="55.4" height="66" rx="1.6" fill="none" stroke="#3a3e44" stroke-opacity="0.5" stroke-width="0.8"/>` + `<rect x="18" y="55" width="16" height="9" rx="0.8" fill="#a8aeb4" stroke="#6a7076" stroke-width="0.3"/>`
      + (clean ? `<rect x="18" y="64.2" width="16" height="3" rx="0.6" fill="#d8dce0" stroke="#6a7076" stroke-width="0.3"/><rect x="19.4" y="56.2" width="13.2" height="6.6" rx="0.6" fill="#6a7076"/>` : `<rect x="19.4" y="56.2" width="13.2" height="6.6" rx="0.6" fill="#c8ccd0"/><rect x="22.6" y="57.6" width="6.8" height="3.8" rx="1.2" fill="#3a8ac8"/><rect x="26" y="57.6" width="3.4" height="3.8" rx="1.2" fill="#f2f2f2"/>`)
      + `<circle cx="42" cy="59.4" r="2.6" fill="#c8ccd0" stroke="#6a7076" stroke-width="0.3"/><path d="M42 57.4V59.4" stroke="#3a3e44" stroke-width="0.3"/>`;
    const towel = `<g>${at('rotate', '-2.6 6 0;2.6 6 0;-2.6 6 0', 5.4, 0, SPL(2))}<path d="M0 0H12V17.6Q6 18.4 0 17.6Z" fill="#a8c0a0"/><path d="M0 0H12V17.6Q6 18.4 0 17.6Z" fill="url(#m10v)"/><rect y="12.4" width="12" height="0.8" fill="#f2ece0"/><rect y="14" width="12" height="0.4" fill="#f2ece0"/>${rep(14, i => `<path d="M${f1(0.4 + i * 0.8)} ${f1(17.6 + (i % 2) * 0.2)}v1" stroke="#98b090" stroke-width="0.25"/>`).join('')}<path d="M0 0H12V2Q6 3 0 2Z" fill="#98b090"/><path d="M3.6 0.6Q4 8 3.2 17.4M8.6 0.6Q8.4 9 8.9 17.6" stroke="#000000" stroke-opacity="0.07" stroke-width="1" fill="none"/></g>`;
    const defs = DEFD + `<defs>${sym(PF + 'd', dF)}${sym(PF + 's', sD)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const kick = box3(C, { c: [0, 0, -3], w: 58, h: Y0, d: 48, r: 0.4, col: '#1c1d20', gl: 0.2, olw: 0.3 });
      const body = box3(C, { c: [0, Y0, (ZB + ZF) / 2], w: W, h: HB, d: ZF - ZB, r: 0.8, col: SS, gl: 0.2, mat: 'brush', olw: 0.5, olo: 0.6, hole: open ? { f: [2.5, 3, 2.5, 2] } : null, dec: { r: use(PF + 's'), l: use(PF + 's'), b: brushed(W, HB) } });
      const counter = box3(C, { c: [0, TOP, 0], w: 64, h: 3.6, d: 60, r: 1, col: '#ece8e2', gl: 0.5, olw: 0.45, olo: 0.6, dec: { t: cT, f: cF, l: cF, r: cF } });
      // counter things
      const pump = { q: [22, TOP + 5, -16], s: cyl3(C, [22, TOP + 3.6, -16], [22, TOP + 12, -16], 2.6, '#c8782a', { mat: 'gloss', n: 20, op: 0.88, olw: 0.3, noCap: 1 }) + cyl3(C, [22, TOP + 12, -16], [22, TOP + 13.4, -16], 1.6, '#d8dce0', { mat: 'chrome', n: 14, olw: 0.2 }) + cyl3(C, [22, TOP + 13.4, -16], [22, TOP + 16, -16], 0.5, '#d8dce0', { mat: 'chrome', n: 10, olw: 0.2 }) + stick(C, [22, TOP + 16, -16], [22, TOP + 16, -12.4], 0.55, '#d8dce0', 'chrome') + `<g transform="${tanF(C, 22, -16, 2.62, C.thV, TOP + 8)}"><rect x="-1.6" y="-1.6" width="3.2" height="3.2" fill="#f2ece0"/><text y="0.4" text-anchor="middle" font-family="Georgia,serif" font-size="0.7" fill="#3a2a1a">savon</text></g>` };
      const basil = { q: [-20, TOP + 5, -18], s: cyl3(C, [-20, TOP + 3.6, -18], [-20, TOP + 9.6, -18], 3.4, '#c8683a', { r2: 4.2, mat: 'matte', n: 20, olw: 0.3, capCol: '#4a3020' }) + [[-1.6, 12.4, -0.6, 2.6], [1.8, 12, 0.4, 2.4], [0, 14.4, -0.4, 2.4], [-0.4, 11.6, 1.8, 2.2], [1.2, 15, -1.2, 1.8]].map(([dx, y, dz, r]) => sph(C, [-20 + dx, TOP + y, -18 + dz], r, '#4a9a3a')).join('') };
      const dirty = !st ? { q: [2, TOP + 6, 4], s: rep(3, i => plateF(C, 2, TOP + 3.6 + i, 4, 9, '#f4f2ee', 1, i)).join('') + cyl3(C, [0, TOP + 6.6, 3], [0, TOP + 10, 3], 3.8, '#ffffff', { r2: 5.6, mat: 'gloss', n: 20, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.8)}" fill="#e0b468" opacity="0.55"/>` }) + H2(C, [0, TOP + 9.4, 3], [6, TOP + 12, 7], 0.6, '#c8ccd0') + mugH(C, 16, TOP + 3.6, 10, 2.8, 6.6, '#3a5a8a', 0, '#5a3a20') } : null;
      const ctop = vsort(C, [pump, basil].concat(dirty ? [dirty] : []));
      // closed door, handle, towel / open door, racks, tub
      let front = '', cav = '', rack = '';
      if (!open) { const door = box3(C, { c: [0, DY, ZF + DT / 2], w: 59.4, h: DH, d: DT, r: 0.8, col: SS, gl: 0.25, mat: 'brush', olw: 0.45, olo: 0.6, dec: { f: use(PF + 'd') } });
        const hy = DY + DH - 14, hd = barH(C, -24, 24, hy, ZF + DT, 3.4, 1.1, '#d8dcdf', 'chrome', 2.4), tw = PLN(C, [-8, hy + 1, ZF + DT + 4.6], [1, 0, 0], [0, -1, 0], towel);
        front = fv ? door + hd + tw : tw + hd + door; }
      else { const door = box3(C, { c: [0, DY, ZF + DH / 2], w: 59.4, h: DT, d: DH, r: 0.8, col: '#b4bac0', gl: 0.3, mat: 'brush', olw: 0.45, olo: 0.6, dec: { t: dI } });
        if (fv) { const TR = Y0 + 40;
          cav = cavity(C, -27.5, 27.5, Y0 + 2, TOP - 3, ZB + 2, ZF, '#b4bac0', { dk: 0.4, floor: `<rect x="8" y="24" width="39" height="2.4" rx="1.2" fill="#8a9298"/><circle cx="27.5" cy="25.2" r="2.6" fill="#6a7278"/><circle cx="27.5" cy="40" r="4" fill="#5a6268" stroke="#3a3e44" stroke-width="0.3"/>`, back: `<path d="M0 ${f1(TOP - 3 - TR)}H55" stroke="#8a9298" stroke-width="0.8"/><path d="M24 ${f1(TOP - 3 - TR - 4)}H31" stroke="#8a9298" stroke-width="1.4"/>` });
          const rk = wrack(C, -26, 26, TR, ZB + 4, ZF - 2, 6, '#dfe2e4'), L = rk.S.slice();
          [-19, -12, -5].forEach((x, i) => L.push({ q: [x, TR + 4, 2], s: cyl3(C, [x, TR + 0.4, 2], [x, TR + 8.4, 2], 2.4, '#d4ecf2', { r2: 2.8, mat: 'chrome', n: 16, op: 0.7, olc: '#5a8a9a', olw: 0.3, capCol: '#f4fbfd' }) }));
          [[6, '#c8683a'], [13.6, '#9ab890'], [21, '#f2ece0']].forEach(([x, c]) => L.push({ q: [x, TR + 3, 4], s: mugH(C, x, TR + 0.4, 4, 2.8, 6.4, c, 1) }));
          cav += rk.base + vsort(C, L); }
        const ry = DY + DT + 0.8, rk = wrack(C, -26, 26, ry, ZF + 4, ZF + 52, 9, '#e8eaec'), L = rk.S.slice();
        rep(6, i => L.push({ q: [-12, ry + 7, ZF + 8 + i * 6.4], s: plateZ(C, -12, ry, ZF + 8 + i * 6.4, 10, '#ffffff', !clean, i) }));
        rep(4, i => L.push({ q: [11, ry + 5, ZF + 9 + i * 7], s: plateZ(C, 11, ry, ZF + 9 + i * 7, 7, '#dce8f0', !clean, i + 2, '#4a6a9a') }));
        const cb = box3(C, { c: [16, ry, ZF + 44], w: 16, h: 8, d: 7, r: 1, col: '#d8dade', gl: 0.3, op: 0.9, olw: 0.3 }) + rep(6, i => { const x = 10 + i * 2.4, h = 10.4 + (i % 3) * 1.2, c = i % 3 === 1 ? '#3a3a3e' : '#c8ccd0'; return H2(C, [x, ry + 7, ZF + 44], [x + 0.3, ry + h, ZF + 44 + (i % 2) * 0.8], 0.5, c) + (i % 3 === 0 ? sph(C, [x + 0.3, ry + h + 0.4, ZF + 44 + (i % 2) * 0.8], 0.8, '#c8ccd0') : ''); }).join('');
        L.push({ q: [16, ry + 4, ZF + 44], s: cb });
        rack = rk.base + vsort(C, L);
        if (clean) rack += [[-12, 18, ZF + 10], [-12, 18, ZF + 30], [11, 13, ZF + 16], [-12, 18, ZF + 42], [11, 13, ZF + 30]].map(([x, y, z], i) => spk(C, [x, ry + y, z], 0.7, -i * 0.4)).join('');
        front = fv ? door + rack : rack + door; }
      let s = shadow(C, 0, -1, 36, 34, 0.85);
      if (wash) s += PLN(C, [0, 0.06, ZF + 10], [1, 0, 0], [0, 0, 1], `<ellipse rx="9" ry="6" fill="url(#k28fl)">${an('opacity', '0.7;1;0.7', 2.4)}</ellipse><circle r="1.1" fill="#ffd0c8"/><text y="5.6" text-anchor="middle" ${FONT} font-size="2.6" fill="#ff6a54" opacity="0.85">0:58</text>`);
      s += fv ? kick + cav + body + counter + ctop + front : front + kick + body + counter + ctop;
      if (clean) { s += mist(C, 0, DY + 12, ZF + 20, 4, 0.8) + mist(C, 0, TOP - 6, ZF + 2, 2, 0.6); C.p(0, TOP + 16, 0); }
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-066 DUAL-DRAWER WOOD-PANEL INTEGRATED SMART DISHWASHER =======================
  // two walnut drawer fronts (book-matched grain, slim brass edge lips) under a honed soapstone counter, recessed black toe kick. Light lines glow in the gaps
  // between the fronts: warm amber breathing at rest, cyan shimmer running along them while washing (+ a steam puff from the top slot). Counter: wooden bowl
  // of lemons, linen napkin, dirty plates + a wine glass with dregs. load / clean: both drawers glide out (upper 22, lower 44): stainless tubs, upper = glasses +
  // mugs + a cutlery tray, lower = plates + bowls + cutlery basket; a smart strip on the upper drawer's top edge; clean = sparkles + steam.
  N.dd28 = S => { const st = S.st || '', open = st === 'load' || st === 'clean', wash = st === 'wash', clean = st === 'clean', WD = '#7a4a2c', BR = '#c9a256', W = 60, Y0 = 5, ZB = -28, ZF = 26, PF = 'k28w_';
    const DR = [{ y: Y0 + 1, h: 34, out: 52, th: 20 }, { y: Y0 + 36, h: 32, out: 18, th: 17 }], TOP = Y0 + 70;
    const D = { w: 66, d: 62 + (open ? 54 : 0), build: () => [] };
    const R = rng('dd28');
    const pan = (h, sd) => { const r = rng('dd28p' + sd); return `<rect width="59.4" height="${h}" fill="#000000" opacity="0.04"/>` + grainH(r, 59.4, h, 22, '#3a2210') + grainH(r, 59.4, h, 8, '#c08a5a') + `<path d="M29.7 0V${h}" stroke="#3a2210" stroke-opacity="0.12" stroke-width="0.3"/>`; };
    const lineL = (y, i) => `<rect x="1" y="${f1(y - 0.5)}" width="${W - 2}" height="1" fill="${wash ? '#7ae8ff' : '#ffb24a'}" opacity="${open ? 0.15 : 0.9}"/>`;
    const bF = `<rect width="${W}" height="70" fill="#1a1614"/>` + (open ? DR.map(d => `<rect x="1.5" y="${f1(70 - (d.y - Y0) - d.h + 0.5)}" width="${W - 3}" height="${d.h - 1}" rx="0.6" fill="#0c0a08"/>`).join('') : '') + lineL(34.5, 0) + lineL(1, 1);
    const sD = grainV(R, 54, 70, 18, '#3a2210', '#c08a5a') + `<rect width="54" height="70" fill="url(#m10v)"/>`;
    const cT = `<rect width="64" height="60" fill="url(#m10noise)"/>` + rep(4, () => { const x = R() * 64; return `<path d="M${f1(x)} 0Q${f1(x + 8)} 26 ${f1(x - 3)} 60" stroke="#ffffff" stroke-opacity="0.12" stroke-width="0.4" fill="none"/>`; }).join('');
    const smart = `<rect x="18" y="0.4" width="23.4" height="1.6" rx="0.6" fill="#0e0f11"/>` + rep(4, i => `<circle cx="${f1(21 + i * 2.6)}" cy="1.2" r="0.45" fill="${i === 1 ? '#7ae8ff' : '#5a6066'}"/>`).join('') + `<text x="36" y="1.7" text-anchor="middle" ${FONT} font-size="1.2" fill="${clean ? '#7ad87a' : '#ffc84a'}">${clean ? 'CLEAN' : '38 min'}</text>`;
    const defs = DEFD + `<defs>${sym(PF + 'f', bF)}${sym(PF + 's', sD)}${DR.map((d, i) => sym(PF + 'p' + i, pan(d.h, i))).join('')}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const kick = box3(C, { c: [0, 0, -4], w: 58, h: Y0, d: 46, r: 0.4, col: '#141416', gl: 0.2, olw: 0.3 });
      const body = box3(C, { c: [0, Y0, (ZB + ZF) / 2], w: W, h: 70, d: ZF - ZB, r: 0.6, col: WD, gl: 0.3, olw: 0.5, olo: 0.65, dec: { f: use(PF + 'f'), r: use(PF + 's'), l: use(PF + 's'), b: use(PF + 's') } });
      const counter = box3(C, { c: [0, TOP, -1], w: 64, h: 3.6, d: 60, r: 1.2, col: '#4c4e50', gl: 0.3, olw: 0.45, olo: 0.7, dec: { t: cT } });
      const front = (d, i, z) => box3(C, { c: [0, d.y, z], w: 59.4, h: d.h, d: 2.4, r: 0.6, col: WD, gl: 0.35, olw: 0.4, olo: 0.7, dec: { f: use(PF + 'p' + i), t: open && i === 1 ? smart : '' } })
        + box3(C, { c: [0, d.y + d.h - 1.3, z + 1.3], w: 44, h: 1.3, d: 1.4, r: 0.4, col: BR, gl: 0.7, olw: 0.25, olc: '#6a4a1a' });
      // drawers
      let drw = '';
      if (open) DR.forEach((d, i) => { const z0 = ZF, z1 = ZF + d.out - 2.4, iy = d.y + 2.4, top = d.y + 1 + d.th;
        let s = cavity(C, -27, 27, iy, top, z0, z1, '#c4c8cc', { dk: 0.35 });
        const rk = wrack(C, -25.5, 25.5, iy + 0.4, z0 + 1.2, z1 - 1.2, 5, '#dfe2e4'), L = rk.S.slice(), ry = iy + 0.4;
        if (i === 0) { rep(6, k => L.push({ q: [-12, ry + 8, z0 + 20 + k * 4.4], s: plateZ(C, -12, ry, z0 + 20 + k * 4.4, 10.2, '#ffffff', !clean, k) }));
          rep(3, k => L.push({ q: [10, ry + 5, z0 + 22 + k * 6.4], s: plateZ(C, 10, ry, z0 + 22 + k * 6.4, 8, '#e8e0d4', !clean, k + 3, '#7a4a2c') }));
          const cb = box3(C, { c: [20, ry, z1 - 5], w: 9, h: 7, d: 6, r: 0.8, col: '#d8dade', gl: 0.3, olw: 0.3 }) + rep(5, k => { const x = 17 + k * 1.6, c = k % 2 ? BR : '#c8ccd0'; return H2(C, [x, ry + 6, z1 - 5], [x + 0.2, ry + 9.6 + (k % 3), z1 - 5 + (k % 2) * 0.6], 0.45, c); }).join('');
          L.push({ q: [20, ry + 4, z1 - 5], s: cb }); }
        else { [[-19, 0], [-12, 1], [-5, 2]].forEach(([x, k]) => L.push({ q: [x, ry + 4, z0 + 7], s: cyl3(C, [x, ry + 0.3, z0 + 7], [x, ry + 7.4, z0 + 7], 2.2, '#d4ecf2', { r2: 2.6, mat: 'chrome', n: 16, op: 0.7, olc: '#5a8a9a', olw: 0.3, capCol: '#f4fbfd' }) }));
          L.push({ q: [6, ry + 3, z0 + 7], s: mugH(C, 6, ry, z0 + 7, 2.6, 5.6, '#e8e2d6', 1) }, { q: [14, ry + 3, z0 + 7], s: mugH(C, 14, ry, z0 + 7, 2.6, 5.6, '#3a5a5a', 1) });
          L.push({ q: [0, ry + 1, z1 - 3.5], s: box3(C, { c: [0, ry, z1 - 3.5], w: 44, h: 1.6, d: 5, r: 0.6, col: '#b8bec4', gl: 0.3, olw: 0.25, dec: { t: rep(9, k => `<rect x="${f1(3 + k * 4.4)}" y="1" width="${k % 3 === 1 ? 0.9 : 0.6}" height="3" rx="0.3" fill="${k % 3 === 2 ? BR : '#e8eaec'}"/>`).join('') } }) }); }
        s += rk.base + vsort(C, L) + box3(C, { c: [0, d.y + 1, (z0 + z1) / 2], w: 56, h: d.th, d: z1 - z0, r: 0.6, col: '#b8bec4', mat: 'brush', gl: 0.2, olw: 0.35, olo: 0.6, hole: { t: 1.2 } });
        if (clean) s += [[-12, 18, z1 - 10], [-12, 18, z1 - 20], [10, 12, z1 - 12], [-16, 9, z0 + 8]].filter((q, k) => i === 0 ? k < 3 : k === 3).map((q, k) => spk(C, [q[0], ry + q[1], q[2]], 0.7, -k * 0.45 - i * 0.3)).join('');
        drw += s + front(d, i, ZF + d.out - 1.2); });
      const fronts = open ? '' : DR.map((d, i) => front(d, i, ZF + 1.2)).join('');
      // gap light lines (rest: amber breathing, wash: cyan shimmer)
      let glow = '';
      if (!open) [Y0 + 35.5, Y0 + 69].forEach((y, i) => { const a = C.P([-28, y, ZF + 0.4]), b = C.P([28, y, ZF + 0.4]), d = `M${P2(a)}L${P2(b)}`, gid = C.u('gl');
        glow += `<path d="${d}" stroke="${wash ? '#7ae8ff' : '#ffb24a'}" stroke-width="${f1(2.6 * C.k)}" filter="url(#m10b1)" opacity="0.6">${an('opacity', wash ? '0.6;1;0.6' : '0.3;0.75;0.3', wash ? 1.2 : 4, -i)}</path><path d="${d}" stroke="${wash ? '#d8f8ff' : '#ffe0a8'}" stroke-width="${f1(0.5 * C.k)}" opacity="0.8"/>`;
        if (wash) glow += `<defs><linearGradient id="${gid}" gradientUnits="userSpaceOnUse" x1="${f1(a[0])}" y1="${f1(a[1])}" x2="${f1(b[0])}" y2="${f1(b[1])}"><stop offset="0" stop-color="#ffffff" stop-opacity="0"><animate attributeName="offset" values="-0.3;1" dur="1.6s" begin="${-i * 0.5}s" repeatCount="indefinite"/></stop><stop offset="0.15" stop-color="#ffffff" stop-opacity="1"><animate attributeName="offset" values="-0.15;1.15" dur="1.6s" begin="${-i * 0.5}s" repeatCount="indefinite"/></stop><stop offset="0.3" stop-color="#ffffff" stop-opacity="0"><animate attributeName="offset" values="0;1.3" dur="1.6s" begin="${-i * 0.5}s" repeatCount="indefinite"/></stop></linearGradient></defs><path d="${d}" stroke="url(#${gid})" stroke-width="${f1(0.7 * C.k)}"/>`; });
      // counter things
      const bowl = { q: [-18, TOP + 6, -14], s: cyl3(C, [-18, TOP + 3.6, -14], [-18, TOP + 8, -14], 4.4, '#a8784a', { r2: 7.4, mat: 'gloss', n: 24, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.88)}" fill="#6a4424"/>` })
        + [[-2, 8.4, -1], [2.2, 8.2, 0.6], [0, 9.6, 2], [-1.4, 10.6, 0.2], [2.6, 9.4, -2.2]].sort((a, b) => a[2] - b[2]).map(([dx, y, dz]) => sph(C, [-18 + dx, TOP + y, -14 + dz], 2.4, '#f2d23a')).join('') + sph(C, [-15, TOP + 11.4, -14.4], 0.7, '#4a8a2a') };
      const nap = { q: [18, TOP + 4.6, -16], s: cyl3(C, [12, TOP + 5.2, -16], [24, TOP + 5.2, -16], 1.6, '#e8e2d6', { mat: 'matte', n: 14, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.5)}" fill="none" stroke="#b8b0a0" stroke-width="0.25"/>` }) + cyl3(C, [18, TOP + 3.5, -16], [18, TOP + 7, -16], 1.9, BR, { mat: 'metal', n: 14, olw: 0.2, noCap: 1 }) };
      const L2 = [bowl, nap];
      if (!st) L2.push({ q: [4, TOP + 6, 6], s: rep(3, i => plateF(C, 4, TOP + 3.6 + i, 6, 9.4, '#f4f2ee', 1, i)).join('') + H2(C, [0, TOP + 6.8, 4], [9, TOP + 7.4, 9], 0.5, '#c8ccd0') + H2(C, [1, TOP + 6.8, 2], [10, TOP + 7.4, 6], 0.5, BR) },
        { q: [20, TOP + 8, 8], s: cyl3(C, [20, TOP + 3.6, 8], [20, TOP + 4.2, 8], 2.6, '#e4f2f6', { mat: 'chrome', n: 16, op: 0.7, olw: 0.25, olc: '#5a8a9a' }) + cyl3(C, [20, TOP + 4.2, 8], [20, TOP + 9.6, 8], 0.35, '#e4f2f6', { mat: 'chrome', n: 8, op: 0.8, olw: 0.2, olc: '#5a8a9a' }) + cyl3(C, [20, TOP + 9.6, 8], [20, TOP + 15, 8], 1.4, '#e4f2f6', { r2: 3, mat: 'chrome', n: 18, op: 0.5, olw: 0.25, olc: '#5a8a9a', cap: cr => `<circle r="${f1(cr * 0.55)}" fill="#6a1a2a" opacity="0.6"/>` }) });
      const ctop = vsort(C, L2);
      let s = shadow(C, 0, -1, 36, 34, 0.85);
      s += fv ? kick + body + drw + fronts + glow + counter + ctop : drw + fronts + kick + body + counter + ctop;
      if (wash) s += mist(C, 0, Y0 + 69, ZF + 2, 3, 0.6);
      if (clean && fv) { s += mist(C, 0, DR[0].y + 20, ZF + 36, 3, 0.7) + mist(C, 0, DR[1].y + 20, ZF + 14, 2, 0.5); C.p(0, TOP + 16, 0); }
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-086 30-SECOND PLASMA-STEAM SANITIZING & ROBOTIC DISH-SHELVING UNIT =======================
  // a low graphite cabinet with iridescent edge strips floating on a dark plinth over a violet floor glow; black-glass front with a ring timer + status, dish
  // vault seam below. On top: a glass plasma chamber (chrome base + lid with a violet emitter ring), a white-and-graphite robot arm with a cyan eye on its
  // wrist, and a hovering glass plate rack. '' 4 dirty plates in the rack, arm resting (breathing) | load the arm lifts a dirty plate over the chamber, two
  // already inside | wash chamber full of violet plasma: flickering arcs, a glow sweep down the glass, the ring timer fills in 30 s style | clean the rack is
  // full of gleaming plates, the arm sets the last one in, steam curls out of the empty chamber.
  N.plas28 = S => { const st = S.st || '', load = st === 'load', wash = st === 'wash', clean = st === 'clean', GR = '#26242c', W = 64, Y0 = 4.4, HB = 48, TOP = Y0 + HB, ZB = -27, ZF = 27, PF = 'k28z_';
    const CX = -13, CZ = 2, CR = 14, CH = 24, AX = 22, AZ = -16, RX = 20, RZ = 12;
    const D = { w: 68, d: 60, build: () => [] };
    const DEFP = DEFD + '<linearGradient id="k28ir" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ff8ad8"/><stop offset="0.5" stop-color="#b48cff"/><stop offset="1" stop-color="#7ae8ff"/></linearGradient>'
      + '<radialGradient id="k28pl" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.9"/><stop offset="0.35" stop-color="#e0a0ff" stop-opacity="0.7"/><stop offset="0.75" stop-color="#8a40ff" stop-opacity="0.35"/><stop offset="1" stop-color="#6a30e0" stop-opacity="0"/></radialGradient>'
      + '<radialGradient id="k28vg" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#b07aff" stop-opacity="0.6"/><stop offset="1" stop-color="#b07aff" stop-opacity="0"/></radialGradient>';
    const RC = 2 * PI * 7.4, SL = { '': ['READY', 'Dishes waiting · 4'], load: ['LOAD', 'Robot loading…'], wash: ['PLASMA', 'Sanitizing · 30 s'], clean: ['100%', 'Sterile · shelved'] }[st] || ['READY', ''];
    const ring = `<circle cx="15" cy="15.5" r="7.4" fill="none" stroke="#2e2c3a" stroke-width="1.4"/><circle cx="15" cy="15.5" r="7.4" fill="none" stroke="url(#k28ir)" stroke-width="1.4" stroke-linecap="round" stroke-dasharray="${f1(RC)}" stroke-dashoffset="${clean ? 0 : f1(RC)}" transform="rotate(-90 15 15.5)">`
      + (wash ? `<animate attributeName="stroke-dashoffset" values="${f1(RC)};0" dur="4.5s" fill="freeze"/>` : '') + `</circle><text x="15" y="16.5" text-anchor="middle" ${FONT} font-size="2.4" fill="${clean ? '#9af0c8' : '#e8d8ff'}">${SL[0]}</text>`;
    const bF = `<rect width="${W}" height="0.8" fill="url(#k28ir)"/><rect y="${HB - 0.8}" width="${W}" height="0.8" fill="url(#k28ir)"/><rect x="4" y="4" width="56" height="23" rx="2.4" fill="#0c0b10"/><rect x="4.6" y="4.4" width="54.8" height="5" rx="2" fill="#ffffff" opacity="0.06"/>` + ring
      + `<text x="27" y="13" ${FONT} font-size="2.6" fill="#e8d8ff" letter-spacing="0.6">PLASMA·STEAM</text><text x="27" y="17.4" font-family="Arial" font-size="1.8" fill="#a89ac8">${SL[1]}</text>`
      + rep(6, i => `<circle cx="${f1(28 + i * 3)}" cy="21.6" r="0.6" fill="${wash ? '#d890ff' : clean ? '#9af0c8' : i < (load ? 3 : 1) ? '#7ae8ff' : '#3a3848'}">${wash ? an('opacity', '0.3;1;0.3', 0.6, -i * 0.1) : ''}</circle>`).join('')
      + `<rect x="4" y="31" width="56" height="13.4" rx="1.6" fill="none" stroke="#3a3644" stroke-width="0.5"/><rect x="22" y="33" width="20" height="0.8" rx="0.4" fill="url(#k28ir)" opacity="0.8"/><text x="32" y="42" text-anchor="middle" ${FONT} font-size="1.3" fill="#5a5668" letter-spacing="1.2">DISH VAULT</text>`;
    const sD = `<rect width="54" height="0.8" fill="url(#k28ir)"/><rect y="${HB - 0.8}" width="54" height="0.8" fill="url(#k28ir)"/>` + rep(7, i => `<rect x="${f1(10 + i * 5)}" y="14" width="1" height="20" rx="0.5" fill="#141218"/><rect x="${f1(10.2 + i * 5)}" y="14" width="0.4" height="20" fill="url(#k28ir)" opacity="0.35"/>`).join('');
    const tD = `<rect x="0.6" y="0.6" width="${W - 1.2}" height="52.8" rx="1.6" fill="none" stroke="url(#k28ir)" stroke-width="0.6" opacity="0.8"/>`;
    const defs = DEFP + `<defs>${sym(PF + 'f', bF)}${sym(PF + 's', sD)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), R = rng('plas28arc');
      const glow = PLN(C, [0, 0.04, 0], [1, 0, 0], [0, 0, 1], `<ellipse rx="44" ry="34" fill="url(#k28vg)">${an('opacity', wash ? '0.7;1;0.7' : '0.35;0.6;0.35', wash ? 0.8 : 5)}</ellipse>`);
      const plinth = box3(C, { c: [0, 0, 0], w: 52, h: Y0, d: 42, r: 1.2, col: '#141218', gl: 0.3, olw: 0.3, olo: 0.6 });
      const body = box3(C, { c: [0, Y0, 0], w: W, h: HB, d: ZF - ZB, r: 2.4, col: GR, gl: 0.7, olw: 0.5, olo: 0.7, dec: { f: use(PF + 'f'), r: use(PF + 's'), l: use(PF + 's'), b: use(PF + 's'), t: tD } });
      // chamber
      const nIn = load ? 2 : wash ? 4 : 0;
      let ch = cyl3(C, [CX, TOP, CZ], [CX, TOP + 2.2, CZ], CR + 1.2, '#c8ccd4', { mat: 'chrome', n: 32, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.86)}" fill="#1a1822"/><circle r="${f1(cr * 0.7)}" fill="none" stroke="url(#k28ir)" stroke-width="0.5" opacity="0.8"/>` + (wash ? `<g>${at('rotate', '0;360', 2)}${rep(8, i => `<path d="M0 0L${f1(cr * 0.68)} 0" stroke="#d890ff" stroke-width="0.3" opacity="0.6" transform="rotate(${i * 45})"/>`).join('')}</g>` : '') });
      if (wash) { const p = C.P([CX, TOP + 12, CZ]); ch += `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(CR * 0.95 * C.k)}" ry="${f1(CH * 0.62 * C.k)}" fill="url(#k28pl)">${an('opacity', '0.6;1;0.75;1;0.6', 0.9)}</ellipse>`; }
      const PL = []; rep(nIn, i => { const a = (i / Math.max(nIn, 1)) * 2 * PI + 0.4, x = CX + Math.cos(a) * 4.4, z = CZ + Math.sin(a) * 3; PL.push({ q: [x, TOP + 8, z], s: plateZ(C, x, TOP + 2.4, z, 7, wash ? '#f0e4ff' : '#f4f2ee', !wash, i) }); });
      ch += vsort(C, PL);
      if (wash) { const p0 = C.P([CX, TOP + CH - 0.6, CZ]); ch += rep(6, i => { const e = C.P([CX + (R() - 0.5) * 20, TOP + 5 + R() * 9, CZ + (R() - 0.5) * 14]); let d = `M${P2(p0)}`; for (let k = 1; k <= 5; k++) { const t = k / 5, x = p0[0] + (e[0] - p0[0]) * t + (k < 5 ? (R() - 0.5) * 3 * C.k : 0), y = p0[1] + (e[1] - p0[1]) * t + (k < 5 ? (R() - 0.5) * 2 * C.k : 0); d += `L${f1(x)} ${f1(y)}`; }
          const fl = an('opacity', '0;1;0;0;1;0', 0.5 + i * 0.13, -i * 0.21, ' calcMode="discrete"'); return `<path d="${d}" stroke="#c070ff" stroke-width="${f1(1.2 * C.k)}" fill="none" opacity="0.4" filter="url(#m10b1)">${fl}</path><path d="${d}" stroke="#fbefff" stroke-width="${f1(0.28 * C.k)}" fill="none">${fl}</path>`; }).join('');
        const a = C.P([CX, TOP + CH - 1, CZ]), b = C.P([CX, TOP + 3, CZ]); ch += `<ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="${f1(CR * C.k)}" ry="${f1(CR * 0.35 * C.k)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.5 * C.k)}" opacity="0">${an('cy', `${f1(a[1])};${f1(b[1])}`, 1.5)}${an('opacity', '0;0.9;0', 1.5)}</ellipse>`; }
      ch += cyl3(C, [CX, TOP + 2.2, CZ], [CX, TOP + CH, CZ], CR, wash ? '#e8d0ff' : '#cfe4f4', { mat: 'chrome', n: 36, op: wash ? 0.3 : 0.2, noCap: 1, olc: '#8a8ab4', olw: 0.35 })
        + cyl3(C, [CX, TOP + CH, CZ], [CX, TOP + CH + 2.4, CZ], CR + 0.8, '#c8ccd4', { r2: CR - 1, mat: 'chrome', n: 32, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.5)}" fill="#16141c"/><circle r="${f1(cr * 0.4)}" fill="none" stroke="#d890ff" stroke-width="0.8" opacity="${wash ? 1 : 0.55}">${an('opacity', wash ? '0.6;1;0.6' : '0.3;0.7;0.3', wash ? 0.5 : 3)}</circle><circle r="${f1(cr * 0.15)}" fill="#f0d8ff"/>` });
      // rack
      const rkS = [], nR = !st ? 4 : load ? 1 : clean ? 4 : 0;
      rep(4, i => { const z = RZ - 6 + i * 4; rkS.push({ q: [RX, Y0 + HB + 5, z], s: H2(C, [RX - 7.4, TOP + 4.2, z], [RX - 7.4, TOP + 7.6, z], 0.35, '#c9a256') + H2(C, [RX + 7.4, TOP + 4.2, z], [RX + 7.4, TOP + 7.6, z], 0.35, '#c9a256') + (i < nR ? plateZ(C, RX, TOP + 4.2, z, 6.6, '#f4f2ee', !clean, i + 1) : '') }); });
      const rack = PLN(C, [RX, TOP + 0.08, RZ], [1, 0, 0], [0, 0, 1], `<ellipse rx="11" ry="11" fill="url(#k28vg)">${an('opacity', '0.5;0.9;0.5', 2.4)}</ellipse>`)
        + box3(C, { c: [RX, TOP + 2.8, RZ], w: 18, h: 1.4, d: 18, r: 1.4, col: '#d8e4ff', gl: 0.6, op: 0.55, olw: 0.3, olc: '#8a8ab4', dec: { t: `<rect x="0.5" y="0.5" width="17" height="17" rx="1.2" fill="none" stroke="url(#k28ir)" stroke-width="0.4"/>` } }) + vsort(C, rkS)
        + (clean ? rep(4, i => spk(C, [RX + (i % 2 ? 3 : -3), TOP + 13 + (i % 2) * 2, RZ - 6 + i * 4], 0.6, -i * 0.4)).join('') : '');
      // arm
      const SH = [AX, TOP + 6.5, AZ], P = load ? { e: [AX - 6, TOP + 40, AZ + 4], w: [CX + 3, TOP + 44, CZ] } : clean ? { e: [AX + 4, TOP + 32, AZ + 6], w: [RX, TOP + 31, RZ + 6] } : { e: [AX - 2, TOP + 20, AZ + 2], w: [AX - 6, TOP + 14, AZ + 10] };
      const W2 = P.w, held = load ? plateZ(C, W2[0], W2[1] - 16.4, W2[2], 6.6, '#f4f2ee', 1, 4) : clean ? plateZ(C, W2[0], W2[1] - 16.4, W2[2], 6.6, '#ffffff', 0, 4) + spk(C, [W2[0] + 2, W2[1] - 8, W2[2] + 1], 0.7, 0) : '';
      const grip = [-1.6, 1.6].map(dx => stick(C, [W2[0] + dx, W2[1] - 1, W2[2]], [W2[0] + dx * 1.2, W2[1] - (held ? 4.4 : 4), W2[2]], 0.45, '#3a3844', 'gloss') + sph(C, [W2[0] + dx * 1.2, W2[1] - (held ? 4.4 : 4), W2[2]], 0.55, '#d890ff')).join('');
      const armS = cyl3(C, [AX, TOP, AZ], [AX, TOP + 3, AZ], 5, GR, { r2: 4.2, mat: 'gloss', n: 24, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.8)}" fill="none" stroke="url(#k28ir)" stroke-width="0.5"/>` }) + cyl3(C, [AX, TOP + 3, AZ], SH, 2.6, '#e8e6f0', { mat: 'gloss', n: 16, olw: 0.3 })
        + sph(C, SH, 3, '#3a3844') + cyl3(C, SH, P.e, 2.2, '#eeecf4', { mat: 'gloss', n: 16, olw: 0.3 }) + sph(C, P.e, 2.6, '#3a3844') + cyl3(C, P.e, W2, 1.7, '#eeecf4', { mat: 'gloss', n: 16, olw: 0.3 })
        + (held && !clean ? held : '') + sph(C, W2, 2.1, '#3a3844') + (() => { const q = C.P(W2); return `<circle cx="${f1(q[0] + 0.4 * C.k)}" cy="${f1(q[1] - 0.2 * C.k)}" r="${f1(0.7 * C.k)}" fill="#7ae8ff">${an('opacity', '0.5;1;0.5', 1.6)}</circle>`; })() + grip + (clean ? held : '');
      const arm = `<g>${at('translate', `0 0;0 ${f1((st ? -0.8 : -0.4) * C.k)};0 0`, st ? 1.7 : 3.4, 0, SPL(2))}${armS}</g>`;
      const topS = load || clean ? vsort(C, [{ q: [CX, TOP + 12, CZ], s: ch }, { q: [RX, TOP + 6, RZ], s: rack }]) + arm : vsort(C, [{ q: [CX, TOP + 12, CZ], s: ch }, { q: [RX, TOP + 6, RZ], s: rack }, { q: [AX, TOP + 12, AZ], s: arm }]);
      let s = shadow(C, 0, 0, 40, 32, 0.6) + glow + plinth + body + topS;
      if (wash) s += mist(C, CX, TOP + CH + 2, CZ, 2, 0.5);
      if (clean) s += mist(C, CX, TOP + CH, CZ, 4, 0.8);
      C.p(CX, TOP + CH + 10, CZ); C.p(AX, TOP + 48, AZ);
      return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-007 CRACKED GLASS DRIP COFFEE POT =======================
  // a yellowed "BREW-RITE" 12-cup drip maker: tower with a cloudy reservoir window (water low, cup marks), head with a used filter peeking out of the lid,
  // a coffee drip streak down the front, stain rings on the base; the glass carafe has a crack held with masking tape and a dark ring above the old coffee.
  // Always alive: the red ON light glows, a drip falls from the basket every 2.2 s, the crack weeps a drop that sizzles on the warming plate, steam rises from
  // the carafe and every 7 s the machine gurgles (little puff from the back vent + a shudder). A chipped MONDAY mug of coffee steams beside it.
  N.drip28 = S => { const YW = '#e6dcc2', BK = '#28282c', PF = 'k28c_';
    const D = { w: 48, d: 42, build: () => [] };
    const R = rng('drip28');
    const bF = `<rect width="32" height="4.5" fill="url(#m10noise)"/><rect x="20" y="1.2" width="5" height="2.4" rx="0.4" fill="#3a1a14"/><rect x="20.4" y="1.5" width="2.2" height="1.8" rx="0.3" fill="#ff3a2a"><animate attributeName="fill-opacity" values="0.75;1;0.75" dur="3s" repeatCount="indefinite"/></rect><circle cx="21.5" cy="2.4" r="2.4" fill="#ff4a2a" opacity="0.35" filter="url(#m10b1)"/><text x="27" y="3.2" ${FONT} font-size="1.2" fill="#8a7a5a">ON</text>`
      + `<path d="M4 0.4Q5 2.4 4.4 4.2" stroke="#6a3a1a" stroke-opacity="0.4" stroke-width="0.6" fill="none"/>`;
    const hF = `<rect width="32" height="10.5" fill="url(#m10noise)"/><path d="M0 2.2H32" stroke="#a89c80" stroke-width="0.3"/><text x="16" y="7.4" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-weight="700" font-size="3" fill="#8a6a3a" opacity="0.55">Brew-Rite</text><path d="M24 2.4Q24.6 6 24 10.5" stroke="#6a3a1a" stroke-opacity="0.45" stroke-width="0.8" fill="none" stroke-linecap="round"/><circle cx="24" cy="9.8" r="0.6" fill="#6a3a1a" opacity="0.5"/>`;
    const win = L => `<rect x="${L ? 2 : 4}" y="4" width="4" height="32" rx="1.2" fill="#cfe2e8" opacity="0.55"/><rect x="${L ? 2 : 4}" y="29" width="4" height="7" rx="1" fill="#8ab8d0" opacity="0.8"/><path d="M${L ? 2 : 4} 29.4h4" stroke="#ffffff" stroke-width="0.3"/>` + rep(4, i => `<path d="M${L ? 6 : 4} ${f1(8 + i * 6.4)}h-1.2" stroke="#6a5a3a" stroke-width="0.25"/><text x="${L ? 7.2 : 2.6}" y="${f1(8.5 + i * 6.4)}" text-anchor="middle" font-family="Arial" font-size="1" fill="#6a5a3a">${12 - i * 3}</text>`).join('') + `<rect x="${L ? 2 : 4}" y="4" width="4" height="32" rx="1.2" fill="none" stroke="#a89c80" stroke-width="0.3"/>`;
    const tS = `<rect width="10" height="40" fill="url(#m10noise)"/>` + win(1), tSr = `<rect width="10" height="40" fill="url(#m10noise)"/>` + win(0);
    const hT = `<rect width="32" height="25" fill="url(#m10noise)"/><path d="M2 13H30" stroke="#a89c80" stroke-width="0.35"/><rect x="10" y="4" width="12" height="3" rx="1.5" fill="#a89c80" opacity="0.5"/>` + rep(6, i => `<rect x="${f1(12 + i * 1.4)}" y="20" width="0.6" height="3" rx="0.3" fill="#6a6250"/>`).join('')
      + `<path d="M6 13.2Q7.4 11.6 9 13Q10.6 11.4 12 13Q13.6 11.6 15 13.2Q16.6 11.8 18 13.2L18 14H6Z" fill="#f2ead6" stroke="#b8a888" stroke-width="0.2"/><path d="M7 13.4Q8 12.8 9.4 13.4" stroke="#6a3a1a" stroke-opacity="0.5" stroke-width="0.4" fill="none"/>`;
    const bT = `<rect width="32" height="30" fill="url(#m10noise)"/>` + [[24, 22, 4.2], [7, 8, 3.4], [26, 6, 2.6]].map(([x, y, r]) => `<circle cx="${x}" cy="${y}" r="${r}" fill="none" stroke="#8a5a2a" stroke-opacity="0.35" stroke-width="0.5"/>`).join('') + `<ellipse cx="6" cy="24" rx="2" ry="1" fill="#6a3a1a" opacity="0.3"/>`;
    const crack = `<path d="M-2.6 -2.2L-0.8 -0.6L-1.6 0.8L0.6 2.2L0.2 3.4M-0.8 -0.6L1.2 -1.4L2.4 -0.6M-1.6 0.8L-3 1.4" stroke="#ffffff" stroke-width="0.25" fill="none" opacity="0.9"/><path d="M-2.6 -2.2L-0.8 -0.6L-1.6 0.8L0.6 2.2" stroke="#3a3026" stroke-width="0.12" fill="none" opacity="0.6"/>`
      + `<g transform="rotate(-28)"><rect x="-3.2" y="-1" width="6.4" height="2" fill="#e8d8a8" opacity="0.82"/><path d="M-3.2 -1l0.3 0.5l-0.3 0.5l0.3 0.5l-0.3 0.5M3.2 -1l-0.3 0.5l0.3 0.5l-0.3 0.5l0.3 0.5" stroke="#c8b888" stroke-width="0.15" fill="none"/></g>`
      + `<ellipse cx="0.4" cy="3.4" rx="0.4" ry="0.6" fill="#6a3a1a" opacity="0"><animate attributeName="cy" values="3.4;3.4;9.6;9.6" keyTimes="0;0.6;0.92;1" dur="5s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.85;0.85;0" keyTimes="0;0.6;0.92;1" dur="5s" repeatCount="indefinite"/></ellipse>`;
    const defs = DEFD + `<defs>${sym(PF + 'b', bF)}${sym(PF + 'h', hF)}${sym(PF + 'l', tS)}${sym(PF + 'r', tSr)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), KX = 0, KZ = 4;
      const base = box3(C, { c: [0, 0, 1], w: 32, h: 4.5, d: 30, r: 3, col: YW, gl: 0.3, olw: 0.4, olo: 0.7, dec: { f: use(PF + 'b'), t: bT } });
      const tower = box3(C, { c: [0, 4.5, -10], w: 32, h: 30, d: 10, r: 2.6, col: YW, gl: 0.3, olw: 0.4, olo: 0.7, dec: { l: `<g transform="scale(1 0.75)">${use(PF + 'l')}</g>`, r: `<g transform="scale(1 0.75)">${use(PF + 'r')}</g>` } });
      const head = box3(C, { c: [0, 34.5, -3], w: 32, h: 10.5, d: 25, r: 3, col: YW, gl: 0.3, olw: 0.4, olo: 0.7, dec: { f: use(PF + 'h'), t: hT } });
      const nozzle = cyl3(C, [KX, 33.4, KZ], [KX, 34.6, KZ], 2.2, BK, { mat: 'gloss', n: 14, olw: 0.2 });
      const plate = cyl3(C, [KX, 4.5, KZ], [KX, 5.3, KZ], 9, '#1e1e22', { mat: 'metal', n: 26, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.8)}" fill="none" stroke="#ff6a2a" stroke-opacity="0.25" stroke-width="0.4"/>` });
      const coffee = cr => `<circle r="${f1(cr)}" fill="#2a160a"/><ellipse cx="${f1(-cr * 0.3)}" cy="${f1(-cr * 0.3)}" rx="${f1(cr * 0.4)}" ry="${f1(cr * 0.15)}" fill="#a87a4a" opacity="0.3"/>` + `<circle r="0.1" fill="none" stroke="#8a5a2a" stroke-width="0.25">${an('r', `0.1;${f1(cr * 0.6)}`, 2.2, 0.15)}${an('opacity', '0.9;0', 2.2, 0.15)}</circle>`;
      const liq = cyl3(C, [KX, 5.6, KZ], [KX, 13, KZ], 7.1, '#3a1e0e', { mat: 'gloss', n: 24, olw: 0.2, cap: coffee });
      const glass = cyl3(C, [KX, 5.3, KZ], [KX, 24, KZ], 7.6, '#dcecef', { r2: 6.6, mat: 'chrome', n: 28, op: 0.32, noCap: 1, olc: '#7a9aa0', olw: 0.35 })
        + `<g transform="${tanF(C, KX, KZ, 7.4, C.thV, 15)}"><rect x="-6" y="-0.6" width="12" height="1.6" fill="#5a3a1a" opacity="0.28"/></g>` + `<g transform="${tanF(C, KX, KZ, 7.2, C.thV - 0.35, 19)}">${crack}</g>`
        + `<g transform="${tanF(C, KX, KZ, 7.3, C.thV + 0.55, 14)}"><path d="M0 -7V7" stroke="#ffffff" stroke-width="0.7" opacity="0.5"/></g>`;
      const collar = cyl3(C, [KX, 23.4, KZ], [KX, 27.4, KZ], 7, BK, { r2: 7.4, mat: 'gloss', n: 26, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.82)}" fill="#1a1a1c"/><circle r="${f1(cr * 0.25)}" fill="#0a0a0a"/>` });
      const hd = (() => { const a = C.P([KX + 7.2, 26, KZ]), b = C.P([KX + 12, 25, KZ]), c = C.P([KX + 12, 12, KZ]), d = C.P([KX + 7.2, 11, KZ]); return `<path d="M${P2(a)}C${P2(b)} ${P2(c)} ${P2(d)}" stroke="${BK}" stroke-width="${f1(1.8 * C.k)}" fill="none" stroke-linecap="round"/><path d="M${P2(a)}C${P2(b)} ${P2(c)} ${P2(d)}" stroke="#6a6a70" stroke-width="${f1(0.35 * C.k)}" fill="none" opacity="0.6"/>`; })();
      const pot = plate + (C.v[0] > 0 ? '' : hd) + liq + glass + collar + (C.v[0] > 0 ? hd : '');
      const dp = C.P([KX, 33.2, KZ]), db = C.P([KX, 27.6, KZ]), drop = `<ellipse cx="${f1(dp[0])}" cy="${f1(dp[1])}" rx="${f1(0.45 * C.k)}" ry="${f1(0.7 * C.k)}" fill="#4a2a12" opacity="0"><animate attributeName="cy" values="${f1(dp[1])};${f1(dp[1])};${f1(db[1])};${f1(db[1])}" keyTimes="0;0.6;0.8;1" dur="2.2s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.9;0.9;0;0" keyTimes="0;0.6;0.79;0.8;1" dur="2.2s" repeatCount="indefinite"/></ellipse>`;
      const sz = C.P([KX + Math.sin(C.thV - 0.35) * 7.6, 5.6, KZ + Math.cos(C.thV - 0.35) * 7.6]), sizzle = `<g transform="translate(${P2(sz)}) scale(${n4(C.k)})"><path d="M0 0q-0.8 -1.2 0 -2.4t0 -2.4" stroke="#ffffff" stroke-width="0.3" fill="none" opacity="0">${an('opacity', '0;0;0.7;0', 5, 0, ' keyTimes="0;0.92;0.96;1"')}</path></g>`;
      const machine = (fv ? base + tower + head + nozzle + drop + pot + sizzle : base + pot + nozzle + tower + head);
      const shud = `<g>${at('translate', `0 0;0 0;${f1(0.3 * C.k)} 0;${f1(-0.3 * C.k)} 0;0 0;0 0`, 7, 0, ' keyTimes="0;0.86;0.89;0.92;0.95;1"')}${machine}</g>`;
      // MONDAY mug
      const MX = 19.6, MZ = 12, mug = cyl3(C, [MX, 0, MZ], [MX, 7.6, MZ], 3.6, '#f6f2ea', { mat: 'gloss', n: 20, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.84)}" fill="#5a3418"/><path d="M${f1(cr * 0.55)} ${f1(-cr * 0.7)}l${f1(cr * 0.25)} ${f1(cr * 0.18)}l-0.2 0.5z" fill="#d8d0c0"/>` })
        + `<g transform="${tanF(C, MX, MZ, 3.62, C.thV, 4)}"><text y="0.5" text-anchor="middle" ${FONT} font-size="1.3" fill="#3a3a3a">MONDAY</text><path d="M-1.6 1.2h3.2" stroke="#3a3a3a" stroke-width="0.15"/></g>`;
      const mh = (() => { const a = C.P([MX - 3.4, 6.2, MZ]), b = C.P([MX - 6.4, 6, MZ]), c = C.P([MX - 6.4, 2, MZ]), d = C.P([MX - 3.4, 1.8, MZ]); return `<path d="M${P2(a)}C${P2(b)} ${P2(c)} ${P2(d)}" stroke="#ece6da" stroke-width="${f1(1 * C.k)}" fill="none" stroke-linecap="round"/>`; })();
      const mugS = (C.v[0] < 0 ? mug + mh : mh + mug) + PLN(C, [MX, 0.05, MZ], [1, 0, 0], [0, 0, 1], `<circle r="4.8" fill="none" stroke="#6a3a1a" stroke-opacity="0.25" stroke-width="0.5"/>`);
      const sug = PLN(C, [-20, 0.1, 13], [1, 0, 0], [0, 0, 1], `<g transform="rotate(-18)"><rect x="-2.4" y="-1.4" width="4.8" height="2.8" fill="#f4f0e6" stroke="#c8c0b0" stroke-width="0.15"/><text y="0.5" text-anchor="middle" ${FONT} font-size="0.9" fill="#c8352a">SUGAR</text></g><path d="M-2 4L6 2.4" stroke="#c8a070" stroke-width="0.5" stroke-linecap="round"/>`);
      const L = vsort(C, [{ q: [0, 20, -2], s: shud }, { q: [MX, 4, MZ], s: mugS }]);
      let s = shadow(C, 0, 2, 26, 22, 0.8) + sug + L + mist(C, KX, 28, KZ, 3, 0.45) + mist(C, MX, 8, MZ, 2, 0.3);
      const vp = C.P([0, 44, -12]); s += `<g transform="translate(${P2(vp)}) scale(${n4(C.k)})"><ellipse rx="4" ry="2.2" fill="url(#m10mst)" opacity="0">${an('opacity', '0;0;0.7;0', 7, 0, ' keyTimes="0;0.86;0.92;1"')}${at('translate', '0 0;0 0;0 -8', 7, 0, ' keyTimes="0;0.86;1"')}</ellipse></g>`;
      C.p(0, 52, -10); return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= batch 6 helpers (coffee makers 027-087, prep gadgets 011-091) =======================
  // All always alive (no states) except the toaster ('' bread on the plate | 'in' toasting | 'pop' toast up).
  const pth = H.pth;
  const DEFK = DEFD + '<radialGradient id="k6wl" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffd890" stop-opacity="0.7"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient>'
    + '<linearGradient id="k6cu" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f8c8a0"/><stop offset="0.45" stop-color="#c87a46"/><stop offset="1" stop-color="#8a4a26"/></linearGradient>'
    + '<linearGradient id="k6fr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.75"/><stop offset="0.25" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.8" stop-color="#ffffff" stop-opacity="0.18"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.7"/></linearGradient>'
    + '<linearGradient id="k6led" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffc870" stop-opacity="0.55"/><stop offset="1" stop-color="#ffc870" stop-opacity="0"/></linearGradient>'
    + '<linearGradient id="k6hb" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffe8f4" stop-opacity="0.5"/><stop offset="1" stop-color="#e0f0ff" stop-opacity="0"/></linearGradient>'
    + '<radialGradient id="k6ov" cx="50%" cy="35%" r="70%"><stop offset="0" stop-color="#ffd890"/><stop offset="0.55" stop-color="#e07a2a"/><stop offset="1" stop-color="#4a1a08"/></radialGradient>'
    + '<linearGradient id="k6ts" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a85a20"/><stop offset="0.35" stop-color="#d89448"/><stop offset="1" stop-color="#e8b068"/></linearGradient>';
  // looping flipbook (discrete): frames in turn, T s per loop or per-frame durations ds
  const loopF = (fr, T, b, ds) => { const n = fr.length, cum = [0]; for (let i = 0; i < n; i++) cum.push(cum[i] + (ds ? ds[i] : 1)); const tot = cum[n];
    return fr.map((s, i) => { const t0 = n4(cum[i] / tot), t1 = n4(cum[i + 1] / tot); return `<g opacity="${i ? 0 : 1}"><animate attributeName="opacity" values="${i ? '0;1;0' : '1;0'}" keyTimes="${i ? `0;${t0};${t1}` : `0;${t1}`}" dur="${n4(ds ? tot : T)}s"${b ? ` begin="${n4(b)}s"` : ''} repeatCount="indefinite" calcMode="discrete"/>${s}</g>`; }).join(''); };
  // liquid stream a -> b: runs down at k0, leaves at k1 (cycle T)
  const pour = (C, a, b, w, col, T, k0, k1, b0) => { const p = C.P(a), q = C.P(b), L = Math.hypot(q[0] - p[0], q[1] - p[1]) + 0.5, d = `M${P2(p)}L${P2(q)}`, x = ` keyTimes="0;${n4(k0)};${n4(k0 + 0.06)};${n4(k1)};${n4(k1 + 0.06)};1"`, v = `${f1(L)};${f1(L)};0;0;${f1(-L)};${f1(-L)}`;
    return [[w, col, 1], [w * 0.32, '#ffffff', 0.35]].map(([sw, c, o]) => `<path d="${d}" stroke="${c}" stroke-opacity="${o}" stroke-width="${f1(sw * C.k)}" stroke-linecap="round" fill="none" stroke-dasharray="${f1(L)} ${f1(L * 2)}" stroke-dashoffset="${f1(L)}">${an('stroke-dashoffset', v, T, b0, x)}</path>`).join(''); };
  // heat shimmer rising from a point
  const shim = (C, x, y, z, w, n, op) => { const p = C.P([x, y, z]); C.p(x, y + 12, z); return `<g transform="translate(${P2(p)}) scale(${n4(C.k)})">` + rep(n, i => { const dx = n > 1 ? (i / (n - 1) - 0.5) * w : 0, d = 2.2 + (i % 3) * 0.3, b = -i * 0.7;
    return `<path d="M${f1(dx)} 0q-0.9 -1.8 0 -3.6t0 -3.6" stroke="#ffffff" stroke-width="0.35" fill="none" opacity="0">${an('opacity', `0;${op || 0.4};0`, d, b)}${at('translate', '0 0;0 -8', d, b)}</path>`; }).join('') + '</g>'; };
  // one steam puff on a cycle (k0 -> k1)
  const puff1 = (C, q, s, T, k0, k1, b0) => { const p = C.P(q); C.p(q[0], q[1] + 10 * s, q[2]); const x = ` keyTimes="0;${n4(k0)};${n4((k0 + k1) / 2)};${n4(k1)};1"`;
    return `<g transform="translate(${P2(p)}) scale(${n4(C.k * s)})"><ellipse rx="4.5" ry="2.6" fill="url(#m10mst)" opacity="0">${an('opacity', '0;0;0.7;0;0', T, b0, x)}${at('translate', '0 0;0 0;0 -5;0 -10;0 -10', T, b0, x)}</ellipse></g>`; };
  // a drop falling a -> b between k0 and k1
  const drop1 = (C, a, b, r, col, T, k0, k1, b0) => { const p = C.P(a), q = C.P(b), x = ` keyTimes="0;${n4(k0 - 0.04)};${n4(k0)};${n4(k1)};${n4(k1 + 0.01)};1"`;
    return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(r * C.k)}" ry="${f1(r * 1.4 * C.k)}" fill="${col}" opacity="0">${an('cy', `${f1(p[1])};${f1(p[1])};${f1(p[1])};${f1(q[1])};${f1(q[1])};${f1(q[1])}`, T, b0, x)}${an('cx', `${f1(p[0])};${f1(p[0])};${f1(p[0])};${f1(q[0])};${f1(q[0])};${f1(q[0])}`, T, b0, x)}${an('opacity', '0;0;0.9;0.9;0;0', T, b0, x)}</ellipse>`; };
  // a bubble rising a -> b between k0 and k0 + 0.22
  const bub1 = (C, a, b, r, T, k0) => { const p = C.P(a), q = C.P(b), x = ` keyTimes="0;${n4(k0)};${n4(k0 + 0.02)};${n4(k0 + 0.2)};${n4(k0 + 0.22)};1"`;
    return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(r * C.k)}" fill="#ffffff" fill-opacity="0.3" stroke="#ffffff" stroke-width="${f1(0.15 * C.k)}" opacity="0">${an('cy', `${f1(p[1])};${f1(p[1])};${f1(p[1])};${f1(q[1])};${f1(q[1])};${f1(q[1])}`, T, 0, x)}${an('cx', `${f1(p[0])};${f1(p[0])};${f1(p[0])};${f1(q[0])};${f1(q[0])};${f1(q[0])}`, T, 0, x)}${an('opacity', '0;0;0.9;0.9;0;0', T, 0, x)}</circle>`; };
  // mug with a handle toward +x, contents colour fill, optional label on the facing side, capX(cr) extra on the surface
  const mug2 = (C, x, y, z, r, h, col, fill, lbl, hc, capX) => { const b = cyl3(C, [x, y, z], [x, y + h, z], r, col, { r2: r * 1.04, mat: 'gloss', n: 20, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.88)}" fill="${shade(col, 0.82)}"/><circle r="${f1(cr * 0.8)}" fill="${fill}"/>${capX ? capX(cr * 0.8) : ''}<ellipse cx="${f1(-cr * 0.25)}" cy="${f1(-cr * 0.3)}" rx="${f1(cr * 0.3)}" ry="${f1(cr * 0.12)}" fill="#ffffff" opacity="0.16"/>` })
      + (lbl ? `<g transform="${tanF(C, x, z, r * 1.02 + 0.03, C.thV, y + h * 0.5)}">${lbl}</g>` : ''), o = r * 0.7 + 0.6;
    const hd = `<path d="M${P2(C.P([x + r * 0.95, y + h * 0.78, z]))}C${P2(C.P([x + r + o, y + h * 0.82, z]))} ${P2(C.P([x + r + o, y + h * 0.2, z]))} ${P2(C.P([x + r * 0.95, y + h * 0.24, z]))}" stroke="${hc || shade(col, 0.85)}" stroke-width="${f1(Math.max(0.6, r * 0.2) * C.k)}" fill="none" stroke-linecap="round"/>`;
    return C.v[0] > 0 ? b + hd : hd + b; };
  // coffee beans on a round surface (cap svg)
  const beanT = (cr, col) => { const R = rng('bean' + f1(cr)); return `<circle r="${f1(cr)}" fill="${shade(col, 0.75)}"/>` + rep(Math.round(cr * cr * 0.9), () => { const a = R() * 2 * PI, rr = Math.sqrt(R()) * cr * 0.86, x = Math.cos(a) * rr, y = Math.sin(a) * rr, t = R() * 180;
    return `<g transform="translate(${f1(x)} ${f1(y)}) rotate(${f1(t)})"><ellipse rx="0.85" ry="0.58" fill="${shade(col, 0.85 + R() * 0.4)}"/><path d="M-0.6 0Q0 0.2 0.6 0" stroke="${shade(col, 0.5)}" stroke-width="0.14" fill="none"/></g>`; }).join(''); };
  const GD = '#d8bf86';

  // ======================= KIT-027 SINGLE-SERVE POD COFFEE BREWER =======================
  // a glossy cherry-red pod brewer: black base + slotted drip tray, a clear water tank on the back, a head with three cup-size buttons (the middle one ringed in
  // breathing blue) and a blinking amber DESCALE light, lid handle on top. Every 12 s it brews: a little shudder, glug bubbles in the tank, a hiss puff from
  // the lid vents, a thin coffee stream into a polka-dot mug, then two last drips. A wire caddy of pods and a spent pod with a coffee puddle beside it.
  N.pod28 = S => { const RC = '#b8323a', BK = '#232326', PF = 'k28p_', T = 12, MZ = 8;
    const D = { w: 42, d: 50, build: () => [] };
    const R = rng('pod28');
    const hF = `<rect width="30" height="11" fill="url(#m10noise)"/><rect x="3" y="1.8" width="24" height="6.8" rx="3.4" fill="#1c1c20"/><rect x="3.6" y="2.1" width="22.8" height="2" rx="1" fill="#ffffff" opacity="0.08"/>`
      + [8.4, 15, 21.6].map((x, i) => { const s = 0.62 + i * 0.2; return `<circle cx="${x}" cy="5.2" r="2.3" fill="#2e2e34"/><circle cx="${x}" cy="5.2" r="2.3" fill="none" stroke="${i === 1 ? '#4ab8ff' : '#5a5a62'}" stroke-width="${i === 1 ? 0.5 : 0.25}">${i === 1 ? an('stroke-opacity', '0.4;1;0.4', 3.2) : ''}</circle><path d="M${f1(x - 0.9 * s)} ${f1(5.2 - 1.1 * s)}h${f1(1.8 * s)}l${f1(-0.3 * s)} ${f1(2.2 * s)}h${f1(-1.2 * s)}Z" fill="${i === 1 ? '#a8dcff' : '#c8c8cc'}"/>`; }).join('')
      + `<circle cx="15" cy="5.2" r="3.6" fill="#4ab8ff" opacity="0.2" filter="url(#m10b1)">${an('opacity', '0.08;0.32;0.08', 3.2)}</circle>`
      + `<circle cx="26" cy="9.9" r="0.55" fill="#ffa02a">${an('opacity', '1;0.15;1', 1.6)}</circle><circle cx="26" cy="9.9" r="1.4" fill="#ffa02a" opacity="0.3" filter="url(#m10b1)">${an('opacity', '0.4;0;0.4', 1.6)}</circle><text x="24.8" y="10.3" text-anchor="end" ${FONT} font-size="0.95" fill="#f2c8c0">DESCALE</text>`;
    const brand = `<text x="17" y="7.2" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-weight="700" font-size="3.4" fill="#ffe8e4" opacity="0.85">brew·bud</text>`;
    const hT = `<rect width="30" height="34" fill="url(#m10noise)"/><rect x="5" y="19" width="20" height="13" rx="3" fill="none" stroke="#7a1a22" stroke-width="0.4"/><path d="M5.6 19.4H24.4" stroke="#ffffff" stroke-opacity="0.25" stroke-width="0.3"/><path d="M7 17.6H23" stroke="#7a1a22" stroke-width="0.6" stroke-linecap="round"/>`
      + rep(5, i => `<rect x="${f1(9 + i * 2.6)}" y="4" width="1.2" height="5" rx="0.6" fill="#5a1218"/>`).join('') + `<circle cx="22" cy="28" r="1.4" fill="#5a3418" opacity="0.25"/>`;
    const wF = `<rect width="30" height="46" fill="url(#m10noise)"/><rect width="30" height="7" fill="#000000" opacity="0.22"/><path d="M15 0V4Q15.4 9 14.8 13" stroke="#4a2410" stroke-opacity="0.45" stroke-width="0.7" fill="none" stroke-linecap="round"/><circle cx="14.8" cy="13.4" r="0.6" fill="#4a2410" opacity="0.5"/>`
      + rep(7, () => `<circle cx="${f1(4 + R() * 22)}" cy="${f1(36 + R() * 9)}" r="${f1(0.3 + R() * 0.5)}" fill="#ffffff" opacity="${n4(0.15 + R() * 0.2)}"/>`).join('');
    const tkF = W => `<path d="M1.5 6H${f1(W - 1.5)}" stroke="#ffffff" stroke-width="0.4"/><text x="${f1(W / 2)}" y="5.2" text-anchor="middle" ${FONT} font-size="1.5" fill="#ffffff">MAX</text>` + rep(4, i => `<path d="M1.5 ${f1(14 + i * 6)}h3" stroke="#ffffff" stroke-width="0.35"/>`).join('') + `<rect x="1" y="1" width="1.6" height="38" rx="0.8" fill="#ffffff" opacity="0.5"/>`;
    const trT = `<rect width="24" height="14" fill="#2a2a30"/>` + rep(5, i => `<rect x="2" y="${f1(1.8 + i * 2.4)}" width="20" height="1" rx="0.5" fill="#121216"/>`).join('') + `<ellipse cx="9" cy="7" rx="4" ry="2.4" fill="none" stroke="#6a3a1a" stroke-opacity="0.4" stroke-width="0.4"/>` + rep(6, () => `<circle cx="${f1(2 + R() * 20)}" cy="${f1(1 + R() * 12)}" r="${f1(0.25 + R() * 0.4)}" fill="#ffffff" opacity="0.3"/>`).join('');
    const dots = [[-2.8, -2.4], [1.2, -3.2], [3.2, 0.4], [-0.8, 1.6], [-3.4, 1.8], [1.8, 3.2]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="0.75" fill="#ffffff" opacity="0.92"/>`).join('');
    const defs = DEFK + `<defs>${sym(PF + 'h', hF)}${sym(PF + 't', hT)}${sym(PF + 'w', wF)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const base = box3(C, { c: [0, 0, -6], w: 30, h: 3, d: 48, r: 3, col: BK, gl: 0.3, olw: 0.35 });
      const tank = box3(C, { c: [0, 3.6, -25], w: 24.4, h: 21, d: 8, r: 2.6, col: '#5aa8d8', op: 0.45, ol: 0, edge: 0 }) + rep(3, i => bub1(C, [-5 + i * 5, 5, -25], [-4 + i * 5, 23.5, -25], 0.7 + (i % 2) * 0.4, T, 0.24 + i * 0.07)).join('')
        + box3(C, { c: [0, 3, -25], w: 26, h: 42, d: 9.6, r: 3, col: '#d4ecf6', op: 0.32, gl: 0.9, olw: 0.3, olc: '#5a7a8a', dec: { b: tkF(26), l: tkF(9.6), r: tkF(9.6) } })
        + box3(C, { c: [0, 45, -25], w: 27, h: 2, d: 10.4, r: 3, col: BK, gl: 0.4, olw: 0.3 });
      const tray = box3(C, { c: [0, 3, 10], w: 24, h: 1.4, d: 14, r: 1.4, col: '#36363c', gl: 0.3, olw: 0.3, dec: { t: trT } });
      const tower = box3(C, { c: [0, 3, -9], w: 30, h: 46, d: 22, r: 4, col: RC, gl: 0.55, olw: 0.45, olo: 0.7, dec: { f: use(PF + 'w') } });
      const head = box3(C, { c: [0, 49, -3], w: 30, h: 11, d: 34, r: 5, col: RC, gl: 0.6, olw: 0.45, olo: 0.7, dec: { f: use(PF + 'h'), t: use(PF + 't'), r: brand, l: brand } })
        + box3(C, { c: [0, 60, 8], w: 12, h: 1.6, d: 5, r: 0.8, col: BK, gl: 0.5, olw: 0.3 });
      const spout = cyl3(C, [0, 49, MZ], [0, 47.2, MZ], 2, BK, { mat: 'gloss', n: 16, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.4)}" fill="#0a0a0a"/>` });
      const mug = mug2(C, 0, 4.4, MZ, 5, 10.4, '#7fb4d8', '#3a1e0e', dots, '#6a9cc0') + mist(C, 0, 15, MZ, 2, 0.28);
      const str = pour(C, [0, 47.2, MZ], [0, 14.6, MZ], 0.9, '#5a2e12', T, 0.25, 0.58) + drop1(C, [0, 47, MZ], [0, 14.8, MZ], 0.42, '#5a2e12', T, 0.72, 0.77) + drop1(C, [0, 47, MZ], [0, 14.8, MZ], 0.42, '#5a2e12', T, 0.85, 0.9);
      const mach = fv ? base + tank + tray + tower + spout + mug + str + head : base + tray + mug + str + spout + tower + head + tank;
      const shud = `<g>${at('translate', `0 0;0 0;${f1(0.25 * C.k)} 0;${f1(-0.25 * C.k)} 0;0 0;0 0`, T, 0, ' keyTimes="0;0.2;0.215;0.23;0.245;1"')}${mach}</g>`;
      const pod = (x, y, z, c) => cyl3(C, [x, y, z], [x, y + 3.2, z], 2, '#2a2a2e', { r2: 2.5, mat: 'gloss', n: 16, olw: 0.25, cap: cr => `<circle r="${f1(cr)}" fill="${c}"/><circle r="${f1(cr * 0.62)}" fill="none" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.2"/><circle cx="${f1(-cr * 0.3)}" cy="${f1(-cr * 0.3)}" r="${f1(cr * 0.18)}" fill="#ffffff" opacity="0.5"/>` });
      const PL = [[17.6, 9, '#c8a040'], [22.4, 9, '#c8352a'], [17.6, 15, '#3a8a5a'], [22.4, 15, '#6a4aa0']].map(([x, z, c]) => ({ q: [x, 2, z], s: pod(x, 1.2, z, c) }));
      const pods = { q: [20, 2, 12], s: box3(C, { c: [20, 0, 12], w: 11, h: 1.2, d: 12.4, r: 1, col: '#2a2a2e', gl: 0.4, olw: 0.3 }) + vsort(C, PL) };
      const spent = { q: [-19, 2, 15], s: PLN(C, [-17, 0.05, 17], [1, 0, 0], [0, 0, 1], `<ellipse rx="3.4" ry="1.8" fill="#4a2410" opacity="0.35"/>`) + cyl3(C, [-22, 2.5, 14], [-18.8, 2.5, 15.2], 2, '#2a2a2e', { r2: 2.5, mat: 'gloss', n: 16, olw: 0.25, cap: cr => `<circle r="${f1(cr)}" fill="#c8a040"/><circle r="${f1(cr * 0.62)}" fill="none" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.2"/><path d="M-0.6 -0.5L0.7 0.4M0.6 -0.6L-0.5 0.5" stroke="#4a2410" stroke-width="0.4"/>` }) };
      let s = shadow(C, 0, -4, 24, 30, 0.8) + vsort(C, [{ q: [0, 30, -6], s: shud }, pods, spent]) + puff1(C, [0, 60.6, -14], 0.8, T, 0.2, 0.5);
      C.p(0, 72, -14); return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-047 ITALIAN CHROME DUAL-BOILER ESPRESSO MACHINE & BURR GRINDER =======================
  // a brushed-chrome dual-boiler box: two E61 group heads with lever paddles and walnut-handled portafilters, boiler + pump gauges (the pump needle swings up
  // to 9 bar on every pull), red pilot lamp, steam + hot-water knobs, cup-warmer rail with upside-down cups, slotted drip tray. Every 8 s it pulls two
  // double shots (mouse-tail streams into crema cups), the steam wand stretches milk in a pitcher (steam curls up). Beside it a black conical burr grinder
  // (bean hopper, grind dial, chute + dosing cup: grounds trickle every 9 s while the beans jiggle) and a walnut tamper on a rubber mat.
  N.esp28 = S => { const X0 = -18, G = 36, CH = '#cfd5da', WD = '#6b4226', BK = '#1e1e22', PF = 'k28e_', T = 8;
    const D = { w: 112, d: 54, build: () => [] };
    const R = rng('esp28');
    const gauge = (cx, cy, lbl, vals, kt) => `<circle cx="${cx}" cy="${cy}" r="5.4" fill="url(#k28chr)" stroke="#6a7076" stroke-width="0.3"/><circle cx="${cx}" cy="${cy}" r="4.5" fill="#f8f2e4"/>`
      + rep(11, i => { const a = (-135 + i * 27) * PI / 180; return `<path d="M${f1(cx + Math.sin(a) * 3.5)} ${f1(cy - Math.cos(a) * 3.5)}L${f1(cx + Math.sin(a) * 4.1)} ${f1(cy - Math.cos(a) * 4.1)}" stroke="#2a2a2a" stroke-width="${i % 5 ? 0.15 : 0.3}"/>`; }).join('')
      + `<path d="M${f1(cx + Math.sin(0.8) * 3.9)} ${f1(cy - Math.cos(0.8) * 3.9)}A3.9 3.9 0 0 1 ${f1(cx + Math.sin(2.35) * 3.9)} ${f1(cy - Math.cos(2.35) * 3.9)}" stroke="#c83a2a" stroke-width="0.45" fill="none"/><text x="${cx}" y="${f1(cy + 2.7)}" text-anchor="middle" font-family="Georgia,serif" font-size="0.9" fill="#3a3a3a">${lbl}</text>`
      + `<g transform="translate(${cx} ${cy})"><g>${at('rotate', vals, lbl === 'POMPA' ? T : 3.2, lbl === 'POMPA' ? -2 : 0, kt || '')}<path d="M0 0.8L0 -3.5" stroke="#1a1a1a" stroke-width="0.35" stroke-linecap="round"/></g><circle r="0.6" fill="#2a2a2a"/></g><ellipse cx="${f1(cx - 1.6)}" cy="${f1(cy - 2.4)}" rx="2.2" ry="0.9" fill="#ffffff" opacity="0.4"/>`;
    const bF = `<rect width="62" height="42" fill="#000000" opacity="0.03"/>` + gauge(6.4, 9, 'CALDAIA', '-12;-8;-13;-9;-12') + gauge(55.6, 9, 'POMPA', '-130;-130;8;3;9;5;-130;-130', ' keyTimes="0;0.1;0.16;0.3;0.45;0.58;0.64;1"')
      + `<circle cx="31" cy="5.4" r="1.1" fill="#c8301e"/><circle cx="31" cy="5.4" r="2.6" fill="#ff4a2a" opacity="0.35" filter="url(#m10b1)">${an('opacity', '0.25;0.45;0.25', 4)}</circle><circle cx="30.6" cy="5" r="0.35" fill="#ffffff" opacity="0.8"/>`
      + `<text x="31" y="11.4" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-weight="700" font-size="2.6" fill="#5a6066">Doppia Caldaia</text><text x="31" y="14" text-anchor="middle" ${FONT} font-size="0.9" fill="#6a7076" letter-spacing="0.6">MILANO · 1961</text>`
      + `<path d="M0 26.4H62" stroke="#8a9096" stroke-width="0.35"/><path d="M0 26.8H62" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.25"/>` + rep(9, i => `<rect x="${f1(13 + i * 4)}" y="35" width="2" height="4.6" rx="1" fill="#5a6066" opacity="0.6"/>`).join('');
    const sF = W => `<rect x="2" y="2" width="${W - 4}" height="22" rx="1.6" fill="none" stroke="#8a9096" stroke-width="0.35"/><path d="M2.4 2.6H${W - 2.4}" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.25"/>`;
    const tT = `<rect x="3" y="3" width="56" height="34" rx="1.5" fill="#9aa2a8" opacity="0.35"/>` + rep(16, i => `<rect x="${f1(4 + i * 3.4)}" y="4" width="1.6" height="32" rx="0.8" fill="#6a7076" opacity="0.55"/>`).join('');
    const gF = `<rect x="2" y="2" width="13" height="10" rx="2" fill="#141418"/><circle cx="8.5" cy="7" r="3.8" fill="url(#k28chr)"/><circle cx="8.5" cy="7" r="2.4" fill="#2a2b30"/><path d="M8.5 7L8.5 4.9" stroke="#ff6a3a" stroke-width="0.4" stroke-linecap="round"/>`
      + rep(9, i => { const a = (-120 + i * 30) * PI / 180; return `<text x="${f1(8.5 + Math.sin(a) * 4.7)}" y="${f1(7.35 - Math.cos(a) * 4.7)}" text-anchor="middle" ${FONT} font-size="0.75" fill="#c8ccd0">${i + 1}</text>`; }).join('')
      + `<text x="8.5" y="22" text-anchor="middle" font-family="Georgia,serif" font-size="1.8" fill="#c9a256" letter-spacing="0.4">MACINA</text><rect x="12.4" y="23.6" width="2" height="2.8" rx="0.5" fill="#c8301e"/>`;
    const trT = `<rect width="58" height="9" fill="#9aa2a8" opacity="0.3"/>` + rep(4, i => `<rect x="2" y="${f1(1.4 + i * 1.8)}" width="54" height="0.8" rx="0.4" fill="#3a3e44"/>`).join('') + `<circle cx="18" cy="5" r="0.6" fill="#6a3414" opacity="0.6"/><circle cx="44" cy="3.6" r="0.5" fill="#6a3414" opacity="0.5"/>`;
    const defs = DEFK + `<defs>${sym(PF + 'f', bF)}${sym(PF + 'g', gF)}${sym(PF + 't', tT)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const feet = [[-27, -19], [27, -19], [-27, 13], [27, 13]].map(([x, z]) => cyl3(C, [X0 + x, 0, z], [X0 + x, 4, z], 1.8, BK, { mat: 'gloss', n: 12, olw: 0.25 })).join('');
      const body = box3(C, { c: [X0, 4, -3], w: 62, h: 42, d: 40, r: 3, col: CH, mat: 'brush', gl: 0.7, olw: 0.5, olo: 0.7, dec: { f: use(PF + 'f'), t: use(PF + 't'), l: sF(40), r: sF(40), b: sF(62) } });
      // cup warmer: rail + upside-down cups
      const TL = [], pst = [[-29, -21], [29, -21], [29, 15], [-29, 15]];
      pst.forEach(([x, z], i) => { const [x2, z2] = pst[(i + 1) % 4]; TL.push({ q: [X0 + x, 48, z], s: cyl3(C, [X0 + x, 46, z], [X0 + x, 50.4, z], 0.55, CH, { mat: 'chrome', n: 10, olw: 0.2 }) }, { q: [X0 + (x + x2) / 2, 50, (z + z2) / 2], s: cyl3(C, [X0 + x, 50, z], [X0 + x2, 50, z2], 0.42, CH, { mat: 'chrome', n: 10, olw: 0.2 }) }); });
      [-15, 0, 15].forEach(dx => [-12, 2].forEach(z => TL.push({ q: [X0 + dx, 48, z], s: cyl3(C, [X0 + dx, 46, z], [X0 + dx, 49.4, z], 2.9, '#f6f4ee', { r2: 2.2, mat: 'gloss', n: 18, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.75)}" fill="none" stroke="#d8d4c8" stroke-width="0.3"/>` }) })));
      const top = vsort(C, TL);
      // group heads, cups + shots
      const grp = (gx, i) => { const cup = cyl3(C, [gx, 7.4, 21], [gx, 8, 21], 4.2, '#f6f4ee', { mat: 'gloss', n: 22, olw: 0.25 }) + mug2(C, gx, 8, 21, 2.5, 3.6, '#f6f4ee', '#8a4a1e', '', '#e4e0d4', cr => `<circle r="${f1(cr)}" fill="#c08040"/><path d="M${f1(-cr * 0.5)} 0q${f1(cr * 0.3)} ${f1(-cr * 0.5)} ${f1(cr * 0.9)} ${f1(cr * 0.1)}" stroke="#e8c090" stroke-width="0.35" fill="none"/>`);
        const strm = [-1, 1].map((dx, k) => pour(C, [gx + dx, 23.8, 20.5], [gx + dx * 0.35, 11.2, 21], 0.55, '#6a3414', T, 0.12 + k * 0.02 + i * 0.03, 0.56 + k * 0.02, -2)).join('');
        const pf = cyl3(C, [gx, 28.4, 20.5], [gx, 25.6, 20.5], 3.8, '#3a3c40', { r2: 3.4, mat: 'chrome', n: 22, olw: 0.3 }) + [-1, 1].map(dx => cyl3(C, [gx + dx, 25.6, 20.5], [gx + dx, 23.8, 20.5], 0.55, '#3a3c40', { mat: 'chrome', n: 10, olw: 0.2 })).join('');
        const coll = cyl3(C, [gx, 33, 17], [gx, 33, 23], 4.6, CH, { mat: 'chrome', n: 24, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.7)}" fill="none" stroke="#8a9096" stroke-width="0.3"/><circle r="${f1(cr * 0.25)}" fill="#9aa2a8"/>` });
        const hdl = cyl3(C, [gx, 27.1, 23], [gx + 0.4, 26.95, 24.8], 1.25, CH, { mat: 'chrome', n: 12, olw: 0.2 }) + cyl3(C, [gx + 0.4, 26.95, 24.8], [gx + 2.4, 26, 33], 1.3, WD, { r2: 1.6, mat: 'gloss', n: 14, olw: 0.3 });
        const lev = cyl3(C, [gx, 37.4, 20], [gx + 1.4, 43, 22], 0.55, CH, { mat: 'chrome', n: 10, olw: 0.2 }) + sph(C, [gx + 1.4, 43.4, 22], 1.3, BK);
        return { q: [gx, 25, 21], s: cup + strm + pf + coll + hdl + lev }; };
      const PX = X0 + 25, PZ = 22.6;
      const wand = { q: [PX, 12, PZ], s: cyl3(C, [PX, 7.4, PZ], [PX, 14.4, PZ], 3.3, '#d8dde2', { r2: 2.9, mat: 'chrome', n: 22, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.86)}" fill="#f6efe2"/><g>${at('rotate', '0;360', 1.3)}<path d="M${f1(-cr * 0.5)} 0A${f1(cr * 0.5)} ${f1(cr * 0.5)} 0 0 1 ${f1(cr * 0.5)} 0" stroke="#e0d4c0" stroke-width="0.4" fill="none"/></g>` })
          + sph(C, [X0 + 24, 19.5, 18.4], 1.2, CH) + cyl3(C, [X0 + 24, 19.5, 18.4], [PX, 14.6, PZ], 0.6, CH, { mat: 'chrome', n: 10, olw: 0.2 })
          + cyl3(C, [X0 + 24, 24, 17], [X0 + 24, 24, 19.4], 2.4, BK, { mat: 'gloss', n: 18, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.4)}" fill="#c8ccd0"/>` }) + mist(C, PX, 15, PZ, 3, 0.32) };
      const hw = { q: [X0 - 24, 20, 19], s: cyl3(C, [X0 - 24, 24, 17], [X0 - 24, 24, 19.4], 2.4, BK, { mat: 'gloss', n: 18, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.4)}" fill="#c8ccd0"/>` })
          + cyl3(C, [X0 - 24, 19.5, 17], [X0 - 24, 19.5, 20.4], 0.8, CH, { mat: 'chrome', n: 10, olw: 0.2 }) + cyl3(C, [X0 - 24, 19.8, 20.4], [X0 - 24, 16.6, 20.4], 0.7, CH, { mat: 'chrome', n: 10, olw: 0.2 }) };
      const tray = box3(C, { c: [X0, 4, 21.5], w: 58, h: 3.4, d: 9, r: 1.2, col: CH, gl: 0.8, olw: 0.35, dec: { t: trT } });
      const front = tray + vsort(C, [grp(X0 - 14, 0), grp(X0 + 14, 1), wand, hw]);
      const mach = feet + (fv ? body + top + front : front + body + top);
      // grinder
      const gb = box3(C, { c: [G, 0, 0], w: 20, h: 5, d: 24, r: 2.4, col: BK, gl: 0.5, olw: 0.35 });
      const gbody = box3(C, { c: [G, 5, -3], w: 17, h: 28, d: 18, r: 3, col: '#2c2d32', gl: 0.6, olw: 0.4, dec: { f: use(PF + 'g') } });
      const chute = box3(C, { c: [G, 16.4, 8], w: 5, h: 3.4, d: 4.2, r: 1, col: CH, gl: 0.8, olw: 0.3 });
      const dcup = cyl3(C, [G, 5, 9.6], [G, 10, 9.6], 2.8, CH, { mat: 'chrome', n: 18, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.85)}" fill="#3a1e0c"/>` + rep(6, i => `<circle cx="${f1(Math.cos(i) * cr * 0.4)}" cy="${f1(Math.sin(i * 2) * cr * 0.4)}" r="0.25" fill="#6a3a1a"/>`).join('') });
      const trk = pour(C, [G, 16.4, 9.6], [G, 9.8, 9.6], 1.1, '#4a2410', 9, 0.1, 0.4) + pour(C, [G + 0.5, 16.4, 9.4], [G + 0.4, 9.9, 9.6], 0.5, '#6a3a1a', 9, 0.12, 0.38);
      const coll = cyl3(C, [G, 33, -3], [G, 36, -3], 7.4, CH, { mat: 'chrome', n: 24, olw: 0.3 });
      const beans = `<g>${at('translate', `0 0;0 0;${f1(0.22 * C.k)} ${f1(-0.15 * C.k)};${f1(-0.22 * C.k)} 0;${f1(0.15 * C.k)} ${f1(-0.1 * C.k)};0 0;0 0`, 9, 0, ' keyTimes="0;0.1;0.16;0.22;0.3;0.4;1"')}${cyl3(C, [G, 36.4, -3], [G, 46, -3], 5, '#3a1e0c', { r2: 7.4, mat: 'matte', n: 22, ol: 0, cap: cr => beanT(cr, '#5a3418') })}</g>`;
      const hop = cyl3(C, [G, 36, -3], [G, 54, -3], 5.4, '#a87a5a', { r2: 8.8, mat: 'chrome', n: 26, op: 0.32, noCap: 1, olc: '#5a3a2a', olw: 0.3 }) + cyl3(C, [G, 54, -3], [G, 55.8, -3], 9.1, BK, { mat: 'gloss', n: 26, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.25)}" fill="#3a3a40"/>` });
      const grind = fv ? gb + gbody + coll + beans + hop + dcup + trk + chute : gb + dcup + trk + chute + gbody + coll + beans + hop;
      // tamper on a rubber mat
      const tmp = PLN(C, [21, 0.05, 14], [1, 0, 0], [0, 0, 1], `<rect x="-4.6" y="-4" width="9.2" height="8" rx="1.4" fill="#2a2a2e"/><rect x="-4" y="-3.4" width="8" height="6.8" rx="1" fill="none" stroke="#3e3e44" stroke-width="0.3"/>`)
        + cyl3(C, [21, 0.1, 14], [21, 1.6, 14], 2.8, CH, { mat: 'chrome', n: 20, olw: 0.25 }) + cyl3(C, [21, 1.6, 14], [21, 5.6, 14], 1, WD, { r2: 1.5, mat: 'gloss', n: 14, olw: 0.25 }) + sph(C, [21, 6.4, 14], 1.7, WD);
      let s = shadow(C, X0, 0, 40, 30, 0.7) + shadow(C, G, 0, 14, 16, 0.6) + vsort(C, [{ q: [X0, 25, -3], s: mach }, { q: [G, 25, -2], s: grind }, { q: [21, 3, 14], s: tmp }]);
      C.p(X0, 56, -3); C.p(G, 58, -3); return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-067 BUILT-IN PLUMBED LATTE-ART BARISTA WALL SYSTEM =======================
  // a walnut base cabinet (brass pulls) under a Calacatta counter, a fluted walnut back wall with a brass top trim and a floating walnut shelf (glass bean jars,
  // stacked cups, amber syrup) washing the wall in warm LED light. Built into the wall: a black-enamel machine with a brass bezel, amber display and ATELIER
  // engraving, two brass group heads with walnut portafilters over two cups. Plumbed: brass pipe up through the counter with a red hand-wheel valve on the
  // right, a glass water-filter canister on the left. Every 10 s it pulls two shots while a brass arm tilts a steel pitcher and pours latte art (a heart
  // grows in the cup, then it fades and the next one starts); steam curls off the latte.
  N.bar28 = S => { const WD = '#6e4428', BR = '#c9a256', BK = '#1e1c1b', PF = 'k28b_', T = 10;
    const D = { w: 56, d: 36, build: () => [] };
    const R = rng('bar28');
    const cabF = grainV(R, 56, 27, 16, '#3a2210', '#c08a5a') + `<rect width="56" height="27" fill="url(#m10v)"/><path d="M28 1V26" stroke="#2a1608" stroke-width="0.5"/><rect x="1" y="1" width="54" height="25" fill="none" stroke="#2a1608" stroke-opacity="0.45" stroke-width="0.4"/>` + [24.6, 31.4].map(x => `<rect x="${f1(x - 0.6)}" y="5" width="1.2" height="9" rx="0.6" fill="url(#k28brs)"/>`).join('');
    const cabS = W => grainV(R, W, 27, 10, '#3a2210', '#c08a5a');
    const panF = grainV(R, 56, 52, 12, '#3a2210', '#c08a5a') + rep(28, i => `<rect x="${i * 2}" width="2" height="52" fill="url(#k28lin)"/><path d="M${i * 2 + 0.2} 0V52" stroke="#2a1608" stroke-opacity="0.35" stroke-width="0.25"/>`).join('')
      + `<rect width="56" height="0.9" fill="url(#k28brs)"/><rect y="14.6" width="56" height="16" fill="url(#k6led)"/>`;
    const cT = veins(R, 58, 34) + `<rect width="58" height="34" fill="url(#m10noise)"/>`;
    const mF = `<rect width="34" height="16" fill="url(#m10noise)"/><rect x="1" y="1" width="32" height="14" rx="1.2" fill="none" stroke="url(#k28brs)" stroke-width="0.55"/>`
      + `<circle cx="5.6" cy="7" r="3.2" fill="url(#k28brs)"/><circle cx="5.6" cy="7" r="2.5" fill="#f8f2e4"/><path d="M5.6 7L6.9 5.4" stroke="#1a1a1a" stroke-width="0.3" stroke-linecap="round"/><circle cx="5.6" cy="7" r="0.4" fill="#2a2a2a"/>`
      + `<rect x="11" y="3" width="12" height="6.4" rx="0.8" fill="#0e0c0a"/><text x="17" y="6.2" text-anchor="middle" ${FONT} font-size="2" fill="#ffb24a">93°</text><text x="17" y="8.4" text-anchor="middle" ${FONT} font-size="1" fill="#c88a3a">9 BAR · LATTE</text>`
      + `<text x="17" y="13" text-anchor="middle" font-family="Georgia,serif" font-size="1.5" fill="#c9a256" letter-spacing="0.9">ATELIER</text>` + [5, 10].map(y => `<circle cx="28.6" cy="${y}" r="1.3" fill="url(#k28brs)"/><circle cx="28.6" cy="${y}" r="0.6" fill="#1a1816"/>`).join('');
    const defs = DEFK + `<defs>${sym(PF + 'c', cabF)}${sym(PF + 'p', panF)}${sym(PF + 'm', mF)}${sym(PF + 't', cT)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const kick = box3(C, { c: [0, 0, 1], w: 52, h: 3, d: 28, r: 0.4, col: '#141414', olw: 0.3 });
      const cab = box3(C, { c: [0, 3, 0], w: 56, h: 27, d: 32, r: 0.6, col: WD, gl: 0.35, olw: 0.45, olo: 0.7, dec: { f: use(PF + 'c'), l: cabS(32), r: cabS(32) } });
      const ctr = box3(C, { c: [0, 30, 1], w: 58, h: 2.6, d: 34, r: 0.6, col: '#f0ece6', gl: 0.6, olw: 0.4, olo: 0.6, dec: { t: use(PF + 't'), f: `<rect y="2" width="58" height="0.6" fill="url(#k28brs)"/>` } });
      const pan = box3(C, { c: [0, 32.6, -14], w: 56, h: 52, d: 4, r: 0.4, col: WD, gl: 0.3, olw: 0.4, olo: 0.6, dec: { f: use(PF + 'p'), t: `<rect width="56" height="4" fill="url(#k28brs)"/>` } });
      const shelf = box3(C, { c: [0, 70, -8], w: 50, h: 1.8, d: 8, r: 0.4, col: WD, gl: 0.4, olw: 0.35, dec: { f: `<rect y="1.2" width="50" height="0.6" fill="url(#k28brs)"/>` } });
      const SI = [{ q: [-18, 75, -8], s: jar(C, -18, 71.8, -8, 2.6, 7, '#4a2a14', BR, 0.8) }, { q: [-11, 75, -8], s: jar(C, -11, 71.8, -8, 2.6, 6, '#8a5a2a', BR, 0.7) },
        { q: [-2, 74, -8], s: cyl3(C, [-2, 71.8, -8], [-2, 74.6, -8], 2.6, '#f4f0e8', { r2: 2.1, mat: 'gloss', n: 18, olw: 0.25 }) + cyl3(C, [-2, 74.6, -8], [-2, 77.4, -8], 2.6, '#f4f0e8', { r2: 2.1, mat: 'gloss', n: 18, olw: 0.25 }) },
        { q: [9, 76, -8], s: bottle(C, 9, 71.8, -8, 1.7, 8.6, '#c87a2a', BR, { op: 0.85 }) }, { q: [16, 74, -8], s: cyl3(C, [16, 71.8, -8], [16, 75.4, -8], 2.2, BR, { mat: 'metal', n: 18, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.8)}" fill="#f4f0e6"/>` }) }];
      const glw = PLN(C, [0, 32.7, -8], [1, 0, 0], [0, 0, 1], `<ellipse rx="24" ry="6" fill="url(#k6wl)" opacity="0.6"/>`);
      const back = pan + shelf + vsort(C, SI);
      // machine + groups + shots
      const gp = (gx, i) => cyl3(C, [gx, 32.6, -6], [gx, 36.4, -6], 2.6, '#f4f0e8', { r2: 3, mat: 'gloss', n: 18, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.86)}" fill="#b8763a"/><circle r="${f1(cr * 0.4)}" fill="#d8a060" opacity="0.6"/>` })
        + [-0.9, 0.9].map((dx, k) => pour(C, [gx + dx, 42.6, -6], [gx + dx * 0.3, 36, -6], 0.45, '#6a3414', T, 0.06 + k * 0.02 + i * 0.03, 0.46, -1.2)).join('')
        + cyl3(C, [gx, 45.4, -6], [gx, 43, -6], 3.4, '#2a2624', { mat: 'chrome', n: 20, olw: 0.25 }) + [-0.9, 0.9].map(dx => cyl3(C, [gx + dx, 43, -6], [gx + dx, 42.4, -6], 0.45, BR, { mat: 'metal', n: 8, olw: 0.2 })).join('')
        + cyl3(C, [gx, 48, -6], [gx, 45.4, -6], 3.8, BR, { mat: 'metal', n: 22, olw: 0.25 }) + cyl3(C, [gx, 44.2, -2.8], [gx + 1, 43.4, 5], 1, WD, { r2: 1.3, mat: 'gloss', n: 12, olw: 0.25 });
      const mach = gp(-9, 0) + gp(9, 1) + box3(C, { c: [0, 48, -7], w: 34, h: 16, d: 10, r: 1.4, col: BK, gl: 0.8, olw: 0.45, olo: 0.7, dec: { f: use(PF + 'm'), t: `<rect x="1" y="1" width="32" height="8" rx="1" fill="none" stroke="url(#k28brs)" stroke-width="0.4"/>` } });
      // plumbing
      const pipe = (a, b) => cyl3(C, a, b, 0.9, BR, { mat: 'metal', n: 12, olw: 0.2 });
      const rgt = { q: [22, 44, -10], s: pipe([22, 32.6, -10], [22, 56, -10]) + sph(C, [22, 56, -10], 1.25, BR) + pipe([22, 56, -10], [17, 56, -10])
          + cyl3(C, [22, 40, -10], [22, 40, -7.2], 0.5, BR, { mat: 'metal', n: 8, olw: 0.2 }) + cyl3(C, [22, 40, -7.2], [22, 40, -6.4], 2.4, '#a8322a', { mat: 'gloss', n: 20, olw: 0.25, cap: cr => rep(4, i => `<path d="M0 0L${f1(Math.cos(i * PI / 2 + 0.4) * cr * 0.8)} ${f1(Math.sin(i * PI / 2 + 0.4) * cr * 0.8)}" stroke="#7a1a14" stroke-width="0.4"/>`).join('') + `<circle r="${f1(cr * 0.3)}" fill="${BR}"/>` }) };
      const lft = { q: [-22, 42, -10], s: cyl3(C, [-22, 32.6, -10], [-22, 34, -10], 3.4, BR, { mat: 'metal', n: 20, olw: 0.25 }) + cyl3(C, [-22, 34.4, -10], [-22, 46, -10], 1.9, '#6ab4d8', { mat: 'matte', n: 16, ol: 0 })
          + cyl3(C, [-22, 34, -10], [-22, 47, -10], 3, '#e8f4f8', { mat: 'chrome', n: 22, op: 0.35, noCap: 1, olw: 0.3, olc: '#6a8a9a' }) + cyl3(C, [-22, 47, -10], [-22, 48.6, -10], 3.4, BR, { mat: 'metal', n: 20, olw: 0.25 })
          + pipe([-22, 48.6, -10], [-22, 54, -10]) + sph(C, [-22, 54, -10], 1.25, BR) + pipe([-22, 54, -10], [-17, 54, -10]) };
      // latte station: brass arm tilts a pitcher over a cup; a heart grows in the foam
      const LX = 13, LZ = 8, pv = C.P([18, 47, LZ]), sp = C.P([14.4, 45.6, LZ]), sg = sp[0] < pv[0] ? -1 : 1, A = 30 * sg, th = A * PI / 180, ox = sp[0] - pv[0], oy = sp[1] - pv[1], rsp = [pv[0] + ox * Math.cos(th) - oy * Math.sin(th), pv[1] + ox * Math.sin(th) + oy * Math.cos(th)], cs = C.P([LX, 37.2, LZ]);
      const art = cr => `<circle r="${f1(cr * 0.9)}" fill="#b0703a"/><circle r="${f1(cr * 0.9)}" fill="url(#m10cap)" opacity="0.5"/><g>${an('opacity', '1;1;0;0;1;1', T, 0, ' keyTimes="0;0.15;0.22;0.3;0.31;1"')}<g>${at('scale', '1;1;0.05;0.05;1;1', T, 0, ' keyTimes="0;0.22;0.23;0.34;0.76;1"')}`
        + `<path d="M0 ${f1(cr * 0.62)}C${f1(-cr * 0.95)} ${f1(-cr * 0.02)} ${f1(-cr * 0.55)} ${f1(-cr * 0.62)} 0 ${f1(-cr * 0.24)}C${f1(cr * 0.55)} ${f1(-cr * 0.62)} ${f1(cr * 0.95)} ${f1(-cr * 0.02)} 0 ${f1(cr * 0.62)}Z" fill="#fbf3e6"/>`
        + [0.62, 0.38].map(k => `<path d="M${f1(-cr * k * 0.75)} ${f1(-cr * k * 0.3)}Q0 ${f1(cr * k * 0.35)} ${f1(cr * k * 0.75)} ${f1(-cr * k * 0.3)}" stroke="#c88a50" stroke-width="0.3" fill="none"/>`).join('') + `<path d="M0 ${f1(-cr * 0.4)}V${f1(cr * 0.55)}" stroke="#c88a50" stroke-width="0.25"/></g></g>`;
      const lcup = cyl3(C, [LX, 32.6, LZ], [LX, 33.2, LZ], 5.6, '#f4f0e8', { mat: 'gloss', n: 24, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.85)}" fill="none" stroke="${BR}" stroke-width="0.25"/>` }) + mug2(C, LX, 33.2, LZ, 3.6, 4, '#f4f0e8', '#b0703a', '', '#e4e0d4', art);
      const arm = sph(C, [17.4, 58, -6], 1.4, BR) + cyl3(C, [17.4, 58, -6], [20, 54, 2], 0.9, BR, { mat: 'metal', n: 12, olw: 0.2 }) + sph(C, [20, 54, 2], 1.2, BR) + cyl3(C, [20, 54, 2], [18, 47.6, LZ], 0.8, BR, { mat: 'metal', n: 12, olw: 0.2 });
      const pit = cyl3(C, [16.6, 40, LZ], [16.6, 46, LZ], 2.8, '#d4d9de', { r2: 2.4, mat: 'chrome', n: 22, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.85)}" fill="#f6efe2"/>` })
        + `<path d="M${P2(sp)}l${f1(-sg * 1.2 * C.k)} ${f1(-0.5 * C.k)}l${f1(sg * 0.8 * C.k)} ${f1(1.1 * C.k)}Z" fill="#c8ced4" stroke="#6a7076" stroke-width="0.2"/>` + sph(C, [18, 47, LZ], 1.1, BR);
      const KR = ' keyTimes="0;0.26;0.34;0.45;0.56;0.68;0.76;0.86;1"', pvs = `${f1(pv[0])} ${f1(pv[1])}`;
      const tilt = `<g>${at('rotate', [0, 0, A, A + 4 * sg, A - 3 * sg, A + 3 * sg, A, 0, 0].map(a => `${f1(a)} ${pvs}`).join(';'), T, 0, KR)}${pit}</g>`;
      const strm = (() => { const L = Math.hypot(cs[0] - rsp[0], cs[1] - rsp[1]) + 0.5, d = `M${f1(rsp[0])} ${f1(rsp[1])}L${f1(cs[0])} ${f1(cs[1])}`; return [[1.1, '#f4ead8', 1], [0.4, '#ffffff', 0.6]].map(([w, c, o]) => `<path d="${d}" stroke="${c}" stroke-opacity="${o}" stroke-width="${f1(w * C.k)}" stroke-linecap="round" fill="none" stroke-dasharray="${f1(L)} ${f1(L * 2)}" stroke-dashoffset="${f1(L)}">${an('stroke-dashoffset', `${f1(L)};${f1(L)};0;0;${f1(-L)};${f1(-L)}`, T, 0, ' keyTimes="0;0.33;0.37;0.74;0.79;1"')}</path>`).join(''); })();
      const latte = { q: [15, 38, LZ], s: lcup + strm + arm + tilt + mist(C, LX, 37.6, LZ, 2, 0.3) };
      const front = vsort(C, [{ q: [0, 45, -6], s: mach }, lft, rgt, latte]);
      let s = shadow(C, 0, 1, 36, 24, 0.85) + kick + cab + ctr + glw + (fv ? back + front : front + back);
      C.p(0, 86, -14); return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-087 3D-PRINTED FOAM & BEAN-TO-CUP AI SOMMELIER BEVERAGE HUB =======================
  // an ivory ceramic tower with champagne-gold trims on a dark plinth over a warm glow. Smoked-glass display in champagne type: SOMMELIER, a flavour wheel whose
  // shape breathes, tasting notes that cycle through three origins and a match bar. A pearl AI orb in a gold ring with a breathing amber iris. In the arched
  // brew bay a glass cup sits on a gold plate under a gold print head: every 10 s the head prints a little squish-bear face into the foam (cocoa line drawn
  // stroke by stroke, a warm dot tracing it), holds, fades. On top a gold carousel of three glass bean hoppers (light / medium / dark roast) indexes round
  // every few seconds. A marble tasting paddle with three small glasses (espresso, cold brew, nitro) in front.
  N.som28 = S => { const IV = '#f2ece2', PF = 'k28s_', T = 10;
    const D = { w: 64, d: 48, build: () => [] };
    const R = rng('som28');
    const wheel = (() => { const cx = 15.5, cy = 22, rr = 6.4, sp = rep(6, i => { const a = i * PI / 3 - PI / 2; return `<path d="M${cx} ${cy}L${f1(cx + Math.cos(a) * rr)} ${f1(cy + Math.sin(a) * rr)}" stroke="#6a5a40" stroke-width="0.2"/>`; }).join('');
      const poly = ks => rep(6, i => { const a = i * PI / 3 - PI / 2; return `${f1(cx + Math.cos(a) * rr * ks[i])},${f1(cy + Math.sin(a) * rr * ks[i])}`; }).join(' ');
      const P = [[0.8, 0.5, 0.7, 0.4, 0.9, 0.6], [0.5, 0.85, 0.45, 0.7, 0.5, 0.8], [0.65, 0.6, 0.9, 0.55, 0.4, 0.75]].map(poly);
      return [1, 0.66, 0.33].map(k => `<circle cx="${cx}" cy="${cy}" r="${f1(rr * k)}" fill="none" stroke="#6a5a40" stroke-width="0.2"/>`).join('') + sp
        + `<polygon points="${P[0]}" fill="#e8b060" fill-opacity="0.35" stroke="#f0c878" stroke-width="0.35">${an('points', P.concat([P[0]]).join(';'), 12)}</polygon>`
        + ['body', 'acid', 'sweet', 'fruit', 'floral', 'nutty'].map((t, i) => { const a = i * PI / 3 - PI / 2; return `<text x="${f1(cx + Math.cos(a) * (rr + 1.4))}" y="${f1(cy + Math.sin(a) * (rr + 1.4) + 0.35)}" text-anchor="middle" font-family="Georgia,serif" font-size="0.85" fill="#b8a07a">${t}</text>`; }).join(''); })();
    const NOTES = [['ETHIOPIA · GUJI', 'jasmine · bergamot', 'peach · honey', 97], ['COLOMBIA · HUILA', 'cocoa · red apple', 'caramel', 92], ['KENYA · NYERI', 'blackcurrant', 'grapefruit · wine', 95]];
    const notes = NOTES.map(([o, a, b, m], i) => { const k0 = i / 3, kv = i === 0 ? '1;1;0;0;1' : '0;0;1;1;0;0', kt = i === 0 ? `0;0.3;0.333;0.967;1` : `0;${n4(k0 - 0.033)};${n4(k0)};${n4(k0 + 0.3)};${n4(k0 + 0.333)};1`;
      return `<g opacity="${i ? 0 : 1}"><animate attributeName="opacity" values="${kv}" keyTimes="${kt}" dur="12s" repeatCount="indefinite"/><text x="25" y="17" ${FONT} font-size="1.5" fill="#f0d8a8" letter-spacing="0.3">${o}</text><text x="25" y="20" font-family="Georgia,serif" font-style="italic" font-size="1.3" fill="#d8c098">${a}</text><text x="25" y="22.4" font-family="Georgia,serif" font-style="italic" font-size="1.3" fill="#d8c098">${b}</text>`
        + `<text x="25" y="26.2" ${FONT} font-size="1" fill="#a8906a">MATCH</text><rect x="31" y="25.3" width="13" height="1" rx="0.5" fill="#3a3026"/><rect x="31" y="25.3" width="${f1(13 * m / 100)}" height="1" rx="0.5" fill="url(#k28brs)"/><text x="44.6" y="29" text-anchor="end" ${FONT} font-size="1.2" fill="#f0d8a8">${m}%</text></g>`; }).join('');
    const fF = `<rect width="52" height="78" fill="url(#m10noise)"/>` + rep(3, () => { const x = R() * 52; return `<path d="M${f1(x)} 0Q${f1(x + 10)} 30 ${f1(x - 4)} 78" stroke="#c8b898" stroke-opacity="0.25" stroke-width="0.4" fill="none"/>`; }).join('')
      + `<rect width="52" height="0.9" fill="url(#k28brs)"/><rect y="77.1" width="52" height="0.9" fill="url(#k28brs)"/><rect x="6" y="6" width="40" height="28" rx="3" fill="#161210"/><rect x="6" y="6" width="40" height="28" rx="3" fill="none" stroke="url(#k28brs)" stroke-width="0.5"/><rect x="6.6" y="6.4" width="38.8" height="5" rx="2.4" fill="#ffffff" opacity="0.05"/>`
      + `<text x="26" y="11.4" text-anchor="middle" font-family="Georgia,serif" font-size="2" fill="#e8d2a0" letter-spacing="1.2">SOMMELIER</text>` + wheel + notes
      + `<circle cx="26" cy="40" r="4.2" fill="none" stroke="url(#k28brs)" stroke-width="0.6"/><circle cx="26" cy="40" r="6" fill="#ffc870" opacity="0.18" filter="url(#m10b1)">${an('opacity', '0.08;0.28;0.08', 4)}</circle>`
      + `<path d="M13 74V50Q13 44 19 44H33Q39 44 39 50V74Z" fill="#1c1814"/><path d="M13 74V50Q13 44 19 44H33Q39 44 39 50V74Z" fill="none" stroke="url(#k28brs)" stroke-width="0.6"/><rect x="16" y="45" width="20" height="14" fill="url(#k6led)"/><rect x="17" y="44.8" width="18" height="0.7" rx="0.35" fill="#ffe4b0"/>`;
    const sdF = W => `<rect width="${W}" height="0.9" fill="url(#k28brs)"/><rect y="77.1" width="${W}" height="0.9" fill="url(#k28brs)"/><rect x="${f1(W / 2 - 0.3)}" y="0.9" width="0.6" height="76.2" fill="url(#k28brs)" opacity="0.8"/>`;
    const defs = DEFK + `<defs>${sym(PF + 'f', fF)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const glow = PLN(C, [0, 0.04, -2], [1, 0, 0], [0, 0, 1], `<ellipse rx="36" ry="28" fill="url(#k28amb)">${an('opacity', '0.55;0.85;0.55', 5)}</ellipse>`);
      const plinth = box3(C, { c: [0, 0, -2], w: 48, h: 3, d: 36, r: 2, col: '#1a1816', gl: 0.3, olw: 0.3 });
      const tower = box3(C, { c: [0, 3, -3], w: 52, h: 78, d: 38, r: 9, col: IV, gl: 0.6, olw: 0.45, olo: 0.6, dec: { f: use(PF + 'f'), l: sdF(38), r: sdF(38), b: sdF(52), t: `<circle cx="26" cy="19" r="16" fill="none" stroke="url(#k28brs)" stroke-width="0.5"/>` } });
      const plate = box3(C, { c: [0, 6, 19.2], w: 18, h: 1.2, d: 6.4, r: 1, col: GD, gl: 0.9, olw: 0.3, dec: { t: rep(5, i => `<rect x="2" y="${f1(0.8 + i * 1)}" width="14" height="0.4" fill="#8a7040" opacity="0.6"/>`).join('') } });
      // printed foam art (cap of the coffee)
      const art = cr => { const f = cr * 0.52, ST = (d, k0, k1) => `<path d="${d}" pathLength="1" stroke="#7a4a26" stroke-width="0.32" fill="none" stroke-linecap="round" stroke-dasharray="1 1" stroke-dashoffset="0">${an('stroke-dashoffset', '0;0;1;1;0;0', T, 0, ` keyTimes="0;0.3;0.31;${k0};${k1};1"`)}</path>`;
        const face = `M0 ${f1(-f)}A${f1(f)} ${f1(f)} 0 1 1 0 ${f1(f)}A${f1(f)} ${f1(f)} 0 1 1 0 ${f1(-f)}`, ears = `M${f1(-f * 0.75)} ${f1(-f * 0.62)}a${f1(f * 0.28)} ${f1(f * 0.28)} 0 1 1 ${f1(f * 0.42)} ${f1(-f * 0.3)}M${f1(f * 0.33)} ${f1(-f * 0.92)}a${f1(f * 0.28)} ${f1(f * 0.28)} 0 1 1 ${f1(f * 0.42)} ${f1(f * 0.3)}`, smile = `M${f1(-f * 0.35)} ${f1(f * 0.25)}Q0 ${f1(f * 0.6)} ${f1(f * 0.35)} ${f1(f * 0.25)}`;
        return `<circle r="${f1(cr * 0.95)}" fill="#efe0c8"/><circle r="${f1(cr * 0.95)}" fill="url(#m10cap)" opacity="0.4"/><g>${an('opacity', '1;1;0;0;1;1', T, 0, ' keyTimes="0;0.25;0.3;0.31;0.32;1"')}` + ST(face, 0.35, 0.6) + ST(ears, 0.6, 0.7) + ST(smile, 0.75, 0.87)
          + [-1, 1].map(s => `<circle cx="${f1(s * f * 0.35)}" cy="${f1(-f * 0.12)}" r="0.32" fill="#7a4a26">${an('opacity', '1;1;0;0;1;1', T, 0, ' keyTimes="0;0.3;0.31;0.71;0.72;1"')}</circle><circle cx="${f1(s * f * 0.6)}" cy="${f1(f * 0.15)}" r="0.45" fill="#e8a890" opacity="0.7">${an('opacity', '0.7;0.7;0;0;0.7;0.7', T, 0, ' keyTimes="0;0.3;0.31;0.87;0.9;1"')}</circle>`).join('') + '</g>'
          + `<circle r="0.35" fill="#ffd890" opacity="0"><animateMotion dur="${T}s" repeatCount="indefinite" path="${face}${smile}" keyPoints="0;0;1;1" keyTimes="0;0.35;0.87;1" calcMode="linear"/>${an('opacity', '0;0;1;1;0;0', T, 0, ' keyTimes="0;0.34;0.35;0.87;0.88;1"')}</circle>`; };
      const cup = cyl3(C, [0, 7.4, 19.5], [0, 14.8, 19.5], 3.3, '#5a3218', { r2: 3.9, mat: 'gloss', n: 22, olw: 0, cap: art }) + cyl3(C, [0, 7.2, 19.5], [0, 15.4, 19.5], 3.8, '#f0f4f8', { r2: 4.4, mat: 'chrome', n: 24, op: 0.3, noCap: 1, olw: 0.3, olc: '#8a9aa4' });
      const tip = C.P([0, 22.8, 20.2]), sf = C.P([0, 14.9, 19.5]);
      const head = box3(C, { c: [0, 24.6, 19], w: 14, h: 2.2, d: 6.4, r: 1, col: GD, gl: 0.9, olw: 0.3 }) + cyl3(C, [0, 24.6, 20.2], [0, 22.8, 20.2], 0.7, '#3a3026', { mat: 'gloss', n: 12, olw: 0.2 })
        + `<path d="M${P2(tip)}L${P2(sf)}" stroke="#ffd890" stroke-width="${f1(0.5 * C.k)}" opacity="0" filter="url(#m10b1)">${an('opacity', '0;0;0.6;0.6;0;0', T, 0, ' keyTimes="0;0.35;0.37;0.87;0.89;1"')}</path><circle cx="${f1(tip[0])}" cy="${f1(tip[1])}" r="${f1(0.5 * C.k)}" fill="#ffd890">${an('opacity', '0.3;1;0.3', 1)}</circle>`;
      const oq = C.P([0, 41, 17.6]), orb = sph(C, [0, 41, 17.6], 2.6, '#f6efe6') + `<circle cx="${f1(oq[0])}" cy="${f1(oq[1])}" r="${f1(0.9 * C.k)}" fill="#ffb24a">${an('r', `${f1(0.6 * C.k)};${f1(1.1 * C.k)};${f1(0.6 * C.k)}`, 4)}${an('opacity', '0.6;1;0.6', 4)}</circle><circle cx="${f1(oq[0] - 0.8 * C.k)}" cy="${f1(oq[1] - 0.9 * C.k)}" r="${f1(0.5 * C.k)}" fill="#ffffff" opacity="0.8"/>`;
      // bean carousel (indexes 120 deg every ~2.9 s)
      const hopS = a => vsort(C, [0, 1, 2].map(k => { const t = a + k * 2 * PI / 3, x = Math.sin(t) * 9.6, z = -3 + Math.cos(t) * 9.6, HC = ['#c8925a', '#7a4824', '#3a1e0e'][k];
          return { q: [x, 90, z], s: cyl3(C, [x, 83.4, z], [x, 91.6, z], 4.2, HC, { mat: 'matte', n: 18, ol: 0, cap: cr => beanT(cr, HC) }) + cyl3(C, [x, 83, z], [x, 96.4, z], 4.6, '#f4f0ea', { mat: 'chrome', n: 20, op: 0.3, noCap: 1, olw: 0.3, olc: '#8a7a5a' }) + cyl3(C, [x, 96.4, z], [x, 97.8, z], 4.9, GD, { mat: 'metal', n: 20, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.3)}" fill="${shade(GD, 0.7)}"/>` }) }; })
        .concat([{ q: [0, 88, -3], s: cyl3(C, [0, 83, -3], [0, 92, -3], 1.2, GD, { mat: 'metal', n: 12, olw: 0.2 }) }]));
      const AN = [0, 40, 80, 120, 160, 200, 240, 280, 320].map(d => d * PI / 180);
      const car = cyl3(C, [0, 81, -3], [0, 83, -3], 15, GD, { mat: 'metal', n: 36, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#f2ece2"/><circle r="${f1(cr * 0.9)}" fill="url(#m10cap)" opacity="0.5"/>` }) + loopF(AN.map(hopS), 0, 0, [2.6, 0.12, 0.12, 2.6, 0.12, 0.12, 2.6, 0.12, 0.12]);
      // tasting paddle
      const FL = [['#2a160a', '#c08040'], ['#5a3418', '#6a3a1a'], ['#1e120a', '#efe0c8']].map(([c, t], i) => { const x = -24 + i * 7; return { q: [x, 3, 27], s: cyl3(C, [x, 1.4, 27], [x, 5, 27], 1.5, c, { r2: 1.85, mat: 'gloss', n: 16, olw: 0, capCol: t }) + cyl3(C, [x, 1.2, 27], [x, 6, 27], 1.6, '#eef4f8', { r2: 2, mat: 'chrome', n: 18, op: 0.35, noCap: 1, olw: 0.25, olc: '#8a9aa4' }) }; });
      const flight = { q: [-17, 2, 27], s: box3(C, { c: [-17, 0, 27], w: 22, h: 1.2, d: 7, r: 1, col: '#f2eee8', gl: 0.5, olw: 0.3, dec: { t: veins(R, 22, 7) + `<rect width="22" height="7" rx="1" fill="none" stroke="url(#k28brs)" stroke-width="0.4"/>`, f: `<rect y="0.5" width="22" height="0.4" fill="url(#k28brs)"/>` } }) + vsort(C, FL) };
      const fr = plate + cup + head + orb;
      const mach = plinth + (fv ? tower + fr : fr + tower) + car;
      let s = glow + vsort(C, [{ q: [0, 40, -3], s: mach }, flight]);
      C.p(0, 100, -3); return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-011 POP-UP 2-SLICE CHROME TOASTER =======================
  // a worn chrome toaster on black feet: scratches, a dent, fingerprints, rust freckles along the bottom, a black "Toasty" badge, a burn smudge by a slot,
  // crumb tray poking out, bakelite lever + browning dial on the right side, a frayed cord with a tape patch running to a plug. A glint slides over the
  // chrome every 7 s. '' two slices of bread on a chipped plate with a butter knife | 'in' lever down, bread tops glow in the slots, the dial ticks round,
  // heat shimmer + a wisp of smoke | 'pop' two toasted slices spring up (one with a burnt corner), steam + crumbs glint; butter on the plate.
  N.toast28 = S => { const st = S.st || '', tin = st === 'in', pop = st === 'pop', CR = '#c9cfd4', BK = '#1a1a1c', PF = 'k28o_';
    const D = { w: 54, d: 36, build: () => [] };
    const R = rng('toast28');
    const chF = (W, h) => `<rect width="${W}" height="${h}" fill="url(#k28chr)" opacity="0.5"/><path d="M${f1(W * 0.1)} ${f1(h * 0.16)}h${f1(W * 0.16)}l${f1(-W * 0.05)} ${f1(h * 0.5)}h${f1(-W * 0.16)}Z" fill="#ffffff" opacity="0.3"/><path d="M${f1(W * 0.32)} ${f1(h * 0.16)}h${f1(W * 0.05)}l${f1(-W * 0.05)} ${f1(h * 0.5)}h${f1(-W * 0.05)}Z" fill="#ffffff" opacity="0.22"/>` + scr(R, 8, 1, 1, W - 2, h - 3, '#ffffff', 0.45) + rust(R, 6, 1, W - 1, h - 0.2);
    const fF = chF(40, 22) + dent(30, 14, 3.6, 2.6, -15, 1) + fp(9, 15, 0.8, 20, 0.12) + fp(11.5, 16.6, 0.7, -10, 0.1)
      + `<ellipse cx="20" cy="8.6" rx="7" ry="2.6" fill="#1a1a1c"/><ellipse cx="20" cy="8.6" rx="7" ry="2.6" fill="none" stroke="#e8ecef" stroke-width="0.35"/><text x="20" y="9.6" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-weight="700" font-size="2.6" fill="#e8dcc0">Toasty</text>`
      + `<clipPath id="${PF}gc"><rect width="40" height="22"/></clipPath><g clip-path="url(#${PF}gc)"><rect x="-12" y="-2" width="4" height="26" fill="#ffffff" opacity="0.35" transform="skewX(-20)"><animate attributeName="x" values="-12;-12;56" keyTimes="0;0.82;1" dur="7s" repeatCount="indefinite"/></rect></g>`;
    const rF = chF(22, 22) + `<rect x="9.8" y="2.6" width="2.4" height="15" rx="1.2" fill="#121214"/>` + rep(6, i => { const a = (-150 + i * 60) * PI / 180; return `<path d="M${f1(5 + Math.sin(a) * 3)} ${f1(15.4 - Math.cos(a) * 3)}L${f1(5 + Math.sin(a) * 3.6)} ${f1(15.4 - Math.cos(a) * 3.6)}" stroke="#3a3e42" stroke-width="0.3"/>`; }).join('')
      + `<text x="5" y="20.6" text-anchor="middle" ${FONT} font-size="0.8" fill="#3a3e42">LIGHT · DARK</text>`;
    const slot = v => `<rect x="5.2" y="${f1(v - 1.6)}" width="28" height="3.2" rx="1.6" fill="#0c0c0e"/><rect x="5.2" y="${f1(v - 1.6)}" width="28" height="3.2" rx="1.6" fill="none" stroke="#f4f6f8" stroke-width="0.3"/>`
      + (tin ? `<rect x="6.4" y="${f1(v - 0.75)}" width="25.6" height="1.5" rx="0.75" fill="#9a5a24"/><rect x="5.6" y="${f1(v - 1.3)}" width="27.2" height="2.6" rx="1.3" fill="#ff7a2a" opacity="0.6">${an('opacity', '0.35;0.75;0.35', 1.4)}</rect>` : '');
    const tT = `<rect width="38.4" height="20.4" fill="url(#k28chr)" opacity="0.3"/>` + slot(5.8) + slot(14.6) + `<ellipse cx="8.4" cy="3.2" rx="3.2" ry="1" fill="#5a3010" opacity="0.32"/><ellipse cx="30" cy="17.6" rx="2.4" ry="0.8" fill="#5a3010" opacity="0.22"/>` + rep(8, () => `<circle cx="${f1(4 + R() * 30)}" cy="${f1(1 + R() * 18)}" r="${f1(0.2 + R() * 0.25)}" fill="#c88a46"/>`).join('');
    const defs = DEFK + `<defs>${sym(PF + 'f', fF)}${sym(PF + 'b', chF(40, 22))}${sym(PF + 'l', chF(22, 22))}${sym(PF + 'r', rF)}${sym(PF + 't', tT)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), rv = vis(C, [1, 0, 0]);
      const feet = [[-14, -7], [14, -7], [-14, 7], [14, 7]].map(([x, z]) => cyl3(C, [x, 0, z], [x, 2.4, z], 1.6, BK, { mat: 'gloss', n: 12, olw: 0.25 })).join('');
      const body = box3(C, { c: [0, 2.4, 0], w: 40, h: 22, d: 22, r: 7.5, col: CR, gl: 1, olw: 0.45, olo: 0.7, dec: { f: use(PF + 'f'), b: use(PF + 'b'), l: use(PF + 'l'), r: use(PF + 'r') } });
      const top = box3(C, { c: [0, 24.4, 0], w: 38.4, h: 1.4, d: 20.4, r: 7, col: '#d4d9dd', gl: 1, olw: 0.35, dec: { t: use(PF + 't') } });
      const tray = box3(C, { c: [0, 2.6, 11.6], w: 18, h: 0.9, d: 1.4, r: 0.4, col: CR, gl: 1, olw: 0.25 });
      const side = box3(C, { c: [21.6, tin ? 7 : 17.6, 0], w: 3.2, h: 2.8, d: 6, r: 1.2, col: BK, gl: 0.6, olw: 0.3 })
        + cyl3(C, [20, 9, 6], [22.2, 9, 6], 2.1, BK, { mat: 'gloss', n: 18, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.75)}" fill="#2a2a2e"/><g>${tin ? '<animateTransform attributeName="transform" type="rotate" values="0;-150" dur="5s" fill="freeze"/>' : ''}<path d="M0 0L0 ${f1(-cr * 0.85)}" stroke="#f4f0e6" stroke-width="0.4" stroke-linecap="round"/></g>` });
      // toast slices standing in the slots (two faces 2.2 apart)
      const SH = 'M-11.5 0V-8Q-12.4 -11.8 -8.6 -12Q-6.4 -14.4 -2.2 -13.2Q0 -14 2.2 -13.2Q6.4 -14.4 8.6 -12Q12.4 -11.8 11.5 -8V0Z';
      const slice = (z, burnt) => { const nz = C.v[2] >= 0 ? 1 : -1, f = (dz, s) => PLN(C, [0, 25.8, z + dz], [1, 0, 0], [0, -1, 0], s), b = C.P([0, 25.8, z]);
        const s = f(-1.1 * nz, `<path d="${SH}" fill="#6a3410"/>`) + box3(C, { c: [0, 25.8, z], w: 21, h: 9.5, d: 2.2, r: 0, col: '#8a4a1a', olw: 0.2, edge: 0, skip: { t: 1 } }) + f(1.1 * nz, `<path d="${SH}" fill="#7a3e14"/><path d="${SH}" transform="translate(0 -0.7) scale(0.88)" fill="url(#k6ts)"/><path d="${SH}" transform="translate(0 -0.7) scale(0.88)" fill="url(#m10noise)"/>`
          + rep(4, i => `<ellipse cx="${f1(-6 + i * 4)}" cy="${f1(-4 - (i % 2) * 4)}" rx="1.6" ry="0.9" fill="#a8622a" opacity="0.4"/>`).join('') + (burnt ? `<ellipse cx="8" cy="-11.2" rx="3" ry="1.8" fill="#3a1a08" opacity="0.65"/>` : ''));
        return `<g transform="translate(${P2(b)})"><g><animateTransform attributeName="transform" type="scale" values="1 1;1 1.25;1 0.94;1 1" keyTimes="0;0.4;0.75;1" dur="0.5s" fill="freeze"/><g transform="translate(${f1(-b[0])} ${f1(-b[1])})">${s}</g></g></g>`; };
      const slices = pop ? [-4.4, 4.4].sort((a, b) => a * C.v[2] - b * C.v[2]).map(z => slice(z, z > 0)).join('') : '';
      let fx = '';
      if (tin) fx = PLN(C, [0, 25.9, 0], [1, 0, 0], [0, 0, 1], [-4.4, 4.4].map(z => `<rect x="-14" y="${f1(z - 1.6)}" width="28" height="3.2" rx="1.6" fill="#ff8a3a" filter="url(#m10b1)" opacity="0.5">${an('opacity', '0.3;0.65;0.3', 1.4)}</rect>`).join('')) + shim(C, 0, 26.5, 0, 22, 5, 0.45) + puff1(C, [7, 29, -4], 0.6, 5, 0.5, 0.9);
      if (pop) fx = mist(C, 0, 38, 0, 3, 0.45) + spk(C, [-8, 42, 0], 0.6, 0) + spk(C, [9, 44, 2], 0.5, -0.6);
      const toaster = (rv ? '' : side) + feet + (fv ? '' : tray) + body + (fv ? tray : '') + (rv ? side : '') + top + slices + fx;
      // plate: bread ('') or butter (in / pop) + butter knife
      const PX = 14, PZ = 18, BRD = 'M-5 4V-1.6Q-5.6 -4.2 -3.4 -4.4Q-2.6 -5.8 0 -5.2Q2.6 -5.8 3.4 -4.4Q5.6 -4.2 5 -1.6V4Z';
      const flat = (y, rot, dx, dz) => PLN(C, [PX + dx, y, PZ + dz], [1, 0, 0], [0, 0, 1], `<g transform="rotate(${rot})"><path d="${BRD}" fill="#c88a46"/><path d="${BRD}" transform="translate(0 0.3) scale(0.86)" fill="#f6e2b6"/><path d="${BRD}" transform="translate(0 0.3) scale(0.86)" fill="url(#m10noise)"/></g>`);
      const plate = cyl3(C, [PX, 0, PZ], [PX, 0.9, PZ], 6, '#f2ede2', { r2: 7.6, mat: 'gloss', n: 28, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.75)}" fill="none" stroke="#d8d0c0" stroke-width="0.3"/><circle r="${f1(cr * 0.93)}" fill="none" stroke="#5a8ab4" stroke-opacity="0.5" stroke-width="0.25"/><path d="M${f1(cr * 0.84)} -1.3L${f1(cr)} -1.8L${f1(cr)} 0.5Z" fill="#d0c6b4"/>` })
        + (st ? box3(C, { c: [PX - 2.5, 0.9, PZ - 2], w: 3.4, h: 1.3, d: 2.4, r: 0.3, col: '#f6e08a', gl: 0.5, olw: 0.2 }) : flat(1, 8, 0, 0) + flat(1.9, -14, 0.6, -0.4))
        + PLN(C, [PX + 1, st ? 1 : 2.9, PZ + 2.4], [1, 0, 0], [0, 0, 1], `<g transform="rotate(-28)"><rect x="-1" y="-0.55" width="8.5" height="1.1" rx="0.55" fill="#dfe3e6"/><rect x="-6.5" y="-0.7" width="5.6" height="1.4" rx="0.7" fill="#4a3220"/>${st ? '<ellipse cx="5" cy="0" rx="2" ry="0.6" fill="#f6e08a"/>' : ''}</g>`);
      const cd = [[-6, 5, -11], [-6, 1.2, -17], [-14, 0.8, -21], [-20, 0.8, -16], [-26, 0.8, -11], [-27, 0.8, -6], [-24, 0.8, -1]].map(q => C.P(q));
      const cord = `<path d="M${P2(cd[0])}C${P2(cd[1])} ${P2(cd[2])} ${P2(cd[3])}C${P2(cd[4])} ${P2(cd[5])} ${P2(cd[6])}" stroke="#2a2a2c" stroke-width="${f1(1.1 * C.k)}" fill="none" stroke-linecap="round"/>`
        + cyl3(C, [-19.2, 0.9, -16.4], [-21.4, 0.9, -15], 0.8, '#d8cfa8', { mat: 'matte', n: 10, olw: 0.2 }) + box3(C, { c: [-24, 0, 0.6], w: 3.4, h: 2.4, d: 3.6, r: 0.6, col: '#2a2a2c', olw: 0.25 });
      const crumbs = PLN(C, [0, 0.05, 15], [1, 0, 0], [0, 0, 1], rep(9, () => `<circle cx="${f1((R() - 0.5) * 30)}" cy="${f1((R() - 0.5) * 6)}" r="${f1(0.25 + R() * 0.3)}" fill="#b87a3a" opacity="0.8"/>`).join(''));
      let s = shadow(C, 0, 0, 26, 16, 0.8) + crumbs + vsort(C, [{ q: [0, 13, -1], s: toaster }, { q: [PX, 1, PZ], s: plate }, { q: [-16, 1, -12], s: cord }]);
      C.p(0, 44, 0); return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-031 RETRO PASTEL STAND MIXER & BLENDER DUO =======================
  // in the chosen pastel: a tilt-head stand mixer (chrome hub + band, "Kitchenette" script, speed lever with ticks) whisking cake batter in a stainless bowl
  // (the balloon whisk really spins, batter swirls, splatters on the bowl), and a matching blender whose glass jar whirls a strawberry smoothie (vortex,
  // rising bubbles, a fine buzz) with a little LED chase on its chrome button panel. A bowl of strawberries on a gingham towel between them.
  N.mix28 = S => { const cl = (S.row && S.row.colors) || [], cv = cl[S.ci || 0], PC = (cv && (Array.isArray(cv.c) ? cv.c[0] : cv.c)) || '#9fdcc4', CH = '#d5dbe0', MX = -24, BX = 26, PF = 'k28m' + PC.replace('#', '') + '_';
    const D = { w: 100, d: 52, build: () => [] };
    const colR = `<rect x="3.6" y="2" width="1.8" height="10" rx="0.9" fill="${shade(PC, 0.65)}"/>` + rep(5, i => `<path d="M6.2 ${f1(3 + i * 2)}h1.4" stroke="${shade(PC, 0.5)}" stroke-width="0.3"/><text x="8.2" y="${f1(3.35 + i * 2)}" ${FONT} font-size="0.9" fill="${shade(PC, 0.5)}">${i * 2 + 1}</text>`).join('');
    const bF = `<rect x="2.5" y="3.5" width="17" height="7.6" rx="2" fill="url(#k28chr)"/><rect x="2.5" y="3.5" width="17" height="7.6" rx="2" fill="none" stroke="#8a9298" stroke-width="0.3"/>`
      + [6, 9.4, 12.6, 16].map((x, i) => `<circle cx="${x}" cy="8.2" r="1.25" fill="#f4f4f2" stroke="#8a9298" stroke-width="0.2"/><circle cx="${x}" cy="5.3" r="0.45" fill="#b8bcc0"/><circle cx="${x}" cy="5.3" r="0.45" fill="#ffb24a" opacity="0"><animate attributeName="opacity" values="0;1;0" keyTimes="0;${n4(i / 4)};${n4((i + 1) / 4)}" dur="1.2s" repeatCount="indefinite" calcMode="discrete"/></circle>`).join('')
      + `<text x="11" y="13" text-anchor="middle" ${FONT} font-size="0.95" fill="${shade(PC, 0.45)}" letter-spacing="0.4">BLEND · PULSE</text>`;
    const defs = DEFK + `<defs>${sym(PF + 'b', bF)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), rv = vis(C, [1, 0, 0]), hx = C.v[0] > 0;
      // stand mixer
      const base = box3(C, { c: [MX, 0, 1], w: 26, h: 5, d: 38, r: 8, col: PC, gl: 0.7, olw: 0.45, olo: 0.65, dec: { f: `<rect y="2" width="26" height="0.9" fill="url(#k28chr)"/>` } });
      const colm = box3(C, { c: [MX, 5, -11], w: 13, h: 31, d: 12, r: 5.5, col: PC, gl: 0.7, olw: 0.45, olo: 0.65, dec: { r: colR } });
      const lev = cyl3(C, [MX + 6.5, 33, -10], [MX + 9.2, 34, -10], 0.5, CH, { mat: 'chrome', n: 10, olw: 0.2 }) + sph(C, [MX + 9.5, 34.1, -10], 1, '#f4f0e6');
      const clamp = cyl3(C, [MX, 5, 6], [MX, 6.2, 6], 7.4, CH, { mat: 'chrome', n: 26, olw: 0.3 });
      const bowl = cyl3(C, [MX, 6.2, 6], [MX, 22, 6], 6.6, '#dfe4e8', { r2: 10.6, mat: 'chrome', n: 32, noCap: 1, olw: 0.35 }) + cyl3(C, [MX, 21.6, 6], [MX, 22.4, 6], 10.9, '#e8ecef', { mat: 'chrome', n: 32, noCap: 1, olw: 0.3 })
        + [[-0.5, 19], [0.7, 15], [0.2, 17.5]].map(([a, y]) => `<g transform="${tanF(C, MX, 6, 6.65 + (y - 6.2) * 0.253, C.thV + a, y)}"><ellipse rx="0.7" ry="0.5" fill="#f4dca4"/><path d="M0 0.4V1.6" stroke="#f4dca4" stroke-width="0.4" stroke-linecap="round"/></g>`).join('');
      const rim = rep(32, i => { const t = i / 32 * 2 * PI; return C.P([MX + Math.cos(t) * 10.5, 22, 6 + Math.sin(t) * 10.5]); }), cc = C.P([MX, 22, 6]), cA = C.u('bwA'), cB = C.u('bwB');
      const clip = `<defs><clipPath id="${cA}"><path d="${pth(rim)}"/></clipPath><clipPath id="${cB}"><path d="${pth(rim)}"/><rect x="-3000" y="-3000" width="6000" height="${f1(cc[1] + 3000)}"/></clipPath></defs>`;
      const inner = `<g clip-path="url(#${cA})"><path d="${pth(rim)}" fill="#7a8288"/>` + PLN(C, [MX, 17.5, 6], [1, 0, 0], [0, 0, 1], `<circle r="9.4" fill="#f4dca4"/><circle r="9.4" fill="url(#m10cap)" opacity="0.5"/><g>${at('rotate', '0;360', 1.1)}${rep(3, i => `<path d="M0 0Q${f1(3 + i)} ${f1(-2 - i)} ${f1(6.5 + i)} ${f1(1 + i * 0.6)}" stroke="#e0c080" stroke-width="0.5" fill="none" transform="rotate(${i * 120})"/>`).join('')}</g><circle r="5" fill="none" stroke="#fff4d8" stroke-width="0.4" opacity="0.7"/>`) + '</g>';
      const wf = rep(6, f => rep(4, k => { const a = k * PI / 4 + f / 6 * PI / 4, pts = rep(23, j => { const th = -1.9 + j / 22 * 3.8, sr = 4.4 * Math.sin(th); return C.P([MX + sr * Math.cos(a), 19.6 + 6.4 * Math.cos(th), 6 + sr * Math.sin(a)]); }), d = 'M' + pts.map(P2).join('L');
        return `<path d="${d}" stroke="#7a8288" stroke-width="${f1(0.6 * C.k)}" fill="none"/><path d="${d}" stroke="#f4f6f8" stroke-width="${f1(0.25 * C.k)}" fill="none"/>`; }).join(''));
      const whisk = `<g clip-path="url(#${cB})">${loopF(wf, 0.3)}</g>` + cyl3(C, [MX, 32.4, 6], [MX, 25.6, 6], 0.9, CH, { mat: 'chrome', n: 10, olw: 0.2 }) + cyl3(C, [MX, 26.8, 6], [MX, 24.8, 6], 1.4, CH, { mat: 'chrome', n: 12, olw: 0.2 });
      const bh = (() => { const p = [[MX + 10.4, 20, 6], [MX + 14, 19.4, 6], [MX + 13.4, 11, 6], [MX + 8.4, 10.6, 6]].map(q => C.P(q)), d = `M${P2(p[0])}C${P2(p[1])} ${P2(p[2])} ${P2(p[3])}`; return `<path d="${d}" stroke="#aab2b8" stroke-width="${f1(1.4 * C.k)}" fill="none" stroke-linecap="round"/><path d="${d}" stroke="#ffffff" stroke-opacity="0.6" stroke-width="${f1(0.4 * C.k)}" fill="none"/>`; })();
      const head = cyl3(C, [MX, 40, -18], [MX, 40, 15], 8.4, PC, { r2: 6.6, mat: 'gloss', n: 30, olw: 0.45, olo: 0.65, cap: cr => `<circle r="${f1(cr * 0.62)}" fill="url(#k28chr)"/><circle r="${f1(cr * 0.62)}" fill="none" stroke="#8a9298" stroke-width="0.3"/><circle r="${f1(cr * 0.25)}" fill="#aab2b8"/>` })
        + cyl3(C, [MX, 40, 3.4], [MX, 40, 5.2], 7.5, CH, { r2: 7.4, mat: 'chrome', n: 30, noCap: 1, olw: 0.3 })
        + [1, -1].filter(s => vis(C, [s, 0, 0])).map(s => PLN(C, [MX + s * 7.75, 41.4, -3], [0, 0, -s], [0, -1, 0], `<text text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-weight="700" font-size="2.4" fill="#ffffff" opacity="0.85">Kitchenette</text>`)).join('');
      const bowlS = clamp + (hx ? '' : bh) + bowl + clip + inner + whisk + (hx ? bh : ''), levS = rv ? colm + lev : lev + colm;
      const mixer = base + (fv ? levS + bowlS : bowlS + levS) + head;
      // blender
      const vort = cr => `<circle r="${f1(cr * 0.96)}" fill="#f48aa0"/><g>${at('rotate', '0;-360', 0.45)}${rep(4, i => `<path d="M0 0Q${f1(cr * 0.4)} ${f1(-cr * 0.5)} ${f1(cr * 0.9)} ${f1(-cr * 0.1)}" stroke="#ffc0cc" stroke-width="0.45" fill="none" transform="rotate(${i * 90})"/>`).join('')}</g><circle r="${f1(cr * 0.18)}" fill="#c84a64"/>`;
      const smo = cyl3(C, [BX, 16.6, 0], [BX, 33, 0], 7, '#ef7d93', { r2: 8.4, mat: 'gloss', n: 26, ol: 0, cap: vort }) + rep(4, i => bub1(C, [BX - 3 + i * 2, 18, 4], [BX - 3.4 + i * 2, 31, 5], 0.4, 3, i * 0.2)).join('');
      const jar = cyl3(C, [BX, 16.4, 0], [BX, 44, 0], 7.6, '#eaf6fa', { r2: 9.6, mat: 'chrome', n: 28, op: 0.26, noCap: 1, olw: 0.35, olc: '#7aa0aa' })
        + `<g transform="${tanF(C, BX, 0, 8.7, C.thV - 0.55, 30)}">${rep(4, i => `<path d="M0 ${f1(-7 + i * 4)}h1.4" stroke="#ffffff" stroke-width="0.3" opacity="0.7"/>`).join('')}</g>`
        + cyl3(C, [BX, 44, 0], [BX, 46.4, 0], 9.9, PC, { r2: 9.6, mat: 'gloss', n: 28, olw: 0.35, cap: cr => `<circle r="${f1(cr * 0.75)}" fill="none" stroke="${shade(PC, 0.7)}" stroke-width="0.3"/>` }) + cyl3(C, [BX, 46.4, 0], [BX, 48.2, 0], 3, CH, { mat: 'chrome', n: 18, olw: 0.25 });
      const jh = (() => { const p = [[BX + 9.4, 41.6, 0], [BX + 14.6, 40.6, 0], [BX + 14, 21.6, 0], [BX + 7.9, 19.6, 0]].map(q => C.P(q)), d = `M${P2(p[0])}C${P2(p[1])} ${P2(p[2])} ${P2(p[3])}`; return `<path d="${d}" stroke="${shade(PC, 0.7)}" stroke-width="${f1(2.2 * C.k)}" fill="none" stroke-linecap="round"/><path d="${d}" stroke="${PC}" stroke-width="${f1(1.6 * C.k)}" fill="none" stroke-linecap="round"/>`; })();
      const blender = box3(C, { c: [BX, 0, 0], w: 22, h: 14, d: 22, r: 6, col: PC, gl: 0.7, olw: 0.45, olo: 0.65, dec: { f: use(PF + 'b') } }) + cyl3(C, [BX, 14, 0], [BX, 16.4, 0], 8.4, CH, { mat: 'chrome', n: 28, olw: 0.3 })
        + `<g>${at('translate', `0 0;${f1(0.15 * C.k)} 0;${f1(-0.15 * C.k)} 0;0 0`, 0.14)}${hx ? smo + jar + jh : jh + smo + jar}</g>`;
      // strawberries on a gingham towel
      const BRs = [[0, 5.6, 0], [-2.6, 5.4, -1.4], [2.4, 5.4, -1], [-1.4, 5.2, 2.2], [1.8, 5.3, 2.4], [0.4, 7.4, -0.4]].map(([x, y, z]) => { const q = [2 + x, y, 17 + z], p = C.P([q[0], y + 1.7, q[2]]), c = C.P(q), k = C.k;
        return { q, s: sph(C, q, 2, '#e0303a') + [[-0.7, 0.3], [0.6, 0.7], [0, -0.3], [0.8, -0.5]].map(([a, b]) => `<ellipse cx="${f1(c[0] + a * k)}" cy="${f1(c[1] + b * k)}" rx="${f1(0.14 * k)}" ry="${f1(0.22 * k)}" fill="#f6d86a"/>`).join('') + `<path d="M${f1(p[0] - 1.2 * k)} ${f1(p[1])}l${f1(1.2 * k)} ${f1(-0.6 * k)}l${f1(1.2 * k)} ${f1(0.6 * k)}l${f1(-1.2 * k)} ${f1(0.5 * k)}Z" fill="#4a9a3a"/>` }; });
      const berries = cyl3(C, [2, 0, 17], [2, 5, 17], 4.4, '#f4efe6', { r2: 6.8, mat: 'gloss', n: 26, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.88)}" fill="#c8bfae"/>` }) + vsort(C, BRs);
      const towel = PLN(C, [2, 0.05, 17], [1, 0, 0], [0, 0, 1], `<g transform="rotate(10)"><rect x="-11" y="-7.5" width="22" height="15" fill="url(#k28ging)"/><rect x="-11" y="-7.5" width="22" height="15" fill="url(#m10noise)"/>${rep(10, i => `<path d="M11 ${f1(-7 + i * 1.5)}h1.2" stroke="#e8d8c8" stroke-width="0.35"/>`).join('')}</g>`);
      let s = shadow(C, MX, 1, 18, 22, 0.7) + shadow(C, BX, 0, 14, 14, 0.6) + towel + vsort(C, [{ q: [MX, 22, 0], s: mixer }, { q: [BX, 24, 0], s: blender }, { q: [2, 4, 17], s: berries }]);
      C.p(MX, 50, 0); C.p(BX, 50, 0); return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-051 DIGITAL AIR-FRYER TOASTER OVEN & SOUS-VIDE CIRCULATOR =======================
  // a matte black air-fryer oven: through the smoked glass door, warm orange light, a glowing zigzag element, the convection fan spinning behind a mesh
  // basket of fries and wings; a side panel with AIR FRY 200° and a timer counting down, a dial and buttons; chrome bar handle; heat shimmer off the top
  // vents. Beside it a clear sous-vide tub: a black circulator clipped to the back (steel lower half, 57.0° display), water swirling with rising bubbles and
  // ripples, a vacuum bag with a peppered steak and rosemary swaying gently in the water.
  N.af28 = S => { const AX = -13, SX = 21, BK = '#262729', PF = 'k28a_';
    const D = { w: 62, d: 36, build: () => [] };
    const R = rng('af28');
    const fries = rep(8, i => { const x = 5 + (i % 4) * 2.4 + R() * 0.8, y = 15.4 + Math.floor(i / 4) * 1.5 + R() * 0.5, a = (R() - 0.5) * 60; return `<rect x="${f1(x)}" y="${f1(y)}" width="4" height="1" rx="0.5" fill="#f2c050" transform="rotate(${f1(a)} ${f1(x + 2)} ${f1(y + 0.5)})"/>`; }).join('');
    const wings = [[17, 15.8], [21.4, 16], [19.2, 17.6]].map(([x, y]) => `<ellipse cx="${x}" cy="${y}" rx="2.2" ry="1.3" fill="#b8642a"/><ellipse cx="${f1(x - 0.6)}" cy="${f1(y - 0.4)}" rx="0.9" ry="0.4" fill="#e8a060" opacity="0.7"/>`).join('');
    const el = 'M3 4.6' + rep(23, i => `l1 ${i % 2 ? -0.7 : 0.7}`).join('');
    const fF = `<clipPath id="${PF}cl"><rect x="2.5" y="3" width="24" height="19" rx="1.6"/></clipPath><g clip-path="url(#${PF}cl)"><rect x="2.5" y="3" width="24" height="19" fill="url(#k6ov)"/>`
      + `<g transform="translate(14.5 10.4)"><circle r="5.6" fill="#3a1a0a" opacity="0.5"/><g>${at('rotate', '0;360', 0.9)}${rep(6, i => `<path d="M0 0Q2.6 -1.4 4.8 0.6" stroke="#1a0a04" stroke-width="1" fill="none" opacity="0.5" transform="rotate(${i * 60})"/>`).join('')}</g><circle r="1" fill="#5a3a20"/></g>`
      + `<path d="${el}" stroke="#ff8a3a" stroke-width="1.4" fill="none" filter="url(#m10b1)" opacity="0.6">${an('opacity', '0.4;0.8;0.4', 2.2)}</path><path d="${el}" stroke="#ffd080" stroke-width="0.45" fill="none"/>`
      + `<path d="M2.5 14.4H26.5" stroke="#8a8a8a" stroke-width="0.4"/><rect x="4" y="15" width="21" height="4.4" rx="0.8" fill="#2a2a2c"/><rect x="4" y="15" width="21" height="4.4" rx="0.8" fill="url(#m10mesh)"/><g>${an('opacity', '0.85;1;0.9;1;0.85', 1.3)}${fries}${wings}</g></g>`
      + `<path d="M3 3h7L3 13Z" fill="#ffffff" opacity="0.08"/><rect x="2.5" y="3" width="24" height="19" rx="1.6" fill="none" stroke="#4a4b4e" stroke-width="0.6"/>`
      + `<rect x="28.5" y="3" width="7" height="7.6" rx="0.8" fill="#0c0c0e"/><text x="32" y="4.9" text-anchor="middle" ${FONT} font-size="0.8" fill="#ffb24a">AIR FRY</text><text x="32" y="7.4" text-anchor="middle" ${FONT} font-size="1.9" fill="#ffb24a">200°</text>`
      + loopF(['12:00', '11:59', '11:58', '11:57'].map(t => `<text x="32" y="9.7" text-anchor="middle" ${FONT} font-size="1.1" fill="#ffd27a">${t}</text>`), 4)
      + `<circle cx="32" cy="14.6" r="2.6" fill="#3a3b3e" stroke="#5a5b5e" stroke-width="0.3"/><path d="M32 14.6L32 12.4" stroke="#ffb24a" stroke-width="0.4" stroke-linecap="round"/><rect x="29" y="19" width="2.6" height="1.6" rx="0.5" fill="#3a3b3e"/><rect x="32.4" y="19" width="2.6" height="1.6" rx="0.5" fill="#3a3b3e"/>`
      + `<text x="3" y="24.2" font-family="Georgia,serif" font-style="italic" font-size="1.3" fill="#a8a8ac">crispé</text>`;
    const tT = `<rect width="38" height="28" fill="url(#m10noise)"/>` + rep(8, i => `<rect x="${f1(11 + i * 2.2)}" y="4" width="1" height="7" rx="0.5" fill="#121214"/>`).join('');
    const svF = W => `<text x="1.4" y="3" ${FONT} font-size="1.2" fill="#3a5a64">6L</text>` + rep(4, i => `<path d="M0.6 ${f1(4 + i * 3.6)}h2" stroke="#3a5a64" stroke-width="0.25"/>`).join('');
    const defs = DEFK + `<defs>${sym(PF + 'f', fF)}${sym(PF + 't', tT)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const feet = [[-16, -11], [16, -11], [-16, 11], [16, 11]].map(([x, z]) => cyl3(C, [AX + x, 0, z], [AX + x, 2.4, z], 1.4, '#121214', { mat: 'gloss', n: 12, olw: 0.25 })).join('');
      const body = box3(C, { c: [AX, 2.4, 0], w: 38, h: 25, d: 28, r: 3, col: BK, gl: 0.35, olw: 0.45, olo: 0.7, dec: { f: use(PF + 'f'), t: use(PF + 't') } });
      const hdl = barH(C, AX - 15, AX + 9, 23.6, 14, 2, 0.8, '#c8ced4', 'chrome');
      const oven = feet + (fv ? body + hdl : hdl + body) + shim(C, AX + 1, 27.6, -3, 14, 4, 0.35);
      // sous-vide
      const sx = SX + 4.4, sz = -6, stb = sz + 9.5, stu = sx - SX + 8.5;
      const low = cyl3(C, [sx, 3, sz], [sx, 15.6, sz], 1.9, '#c8ced4', { mat: 'chrome', n: 16, olw: 0.25 });
      const bag = PLN(C, [SX - 3, 3, 1.5], [1, 0, 0], [0, -1, 0], `<g>${at('rotate', '-3 0 -11;3 0 -11;-3 0 -11', 4, 0, SPL(2))}<rect x="-4.6" y="-12" width="9.2" height="11" rx="1.2" fill="#f4f8f8" opacity="0.35" stroke="#ffffff" stroke-width="0.25"/><rect x="-4.6" y="-12" width="9.2" height="1.4" fill="#ffffff" opacity="0.4"/>`
        + `<path d="M-3.4 -4.4Q-3.8 -9 -0.4 -9.8Q3.6 -10.2 3.4 -6.4Q3.2 -2.6 0 -2.4Q-3 -2.2 -3.4 -4.4Z" fill="#a8423a"/><path d="M-2.6 -7.4Q0 -6 2.4 -8" stroke="#f4e0d0" stroke-width="0.4" fill="none"/>` + rep(6, () => `<circle cx="${f1((R() - 0.5) * 5)}" cy="${f1(-4 - R() * 5)}" r="0.22" fill="#2a1a14"/>`).join('')
        + `<path d="M-2 -3.4L2.4 -8.6" stroke="#4a7a3a" stroke-width="0.3"/>${rep(5, i => `<path d="M${f1(-1.6 + i * 0.9)} ${f1(-3.9 - i * 1.05)}l0.7 -0.2M${f1(-1.6 + i * 0.9)} ${f1(-3.9 - i * 1.05)}l-0.3 -0.6" stroke="#5a8a4a" stroke-width="0.25"/>`).join('')}</g>`);
      const bubs = rep(3, i => bub1(C, [sx - 1, 4, sz + 1.5], [sx - 1.8 - i, 15, sz + 2 + i], 0.35, 2.4, i * 0.25)).join('');
      const water = box3(C, { c: [SX, 0.4, 0], w: 17, h: 15, d: 19, r: 1.2, col: '#8ccce0', op: 0.34, ol: 0, edge: 0, dec: { t: rep(2, i => `<circle cx="${f1(stu)}" cy="${f1(stb)}" r="2.4" fill="none" stroke="#ffffff" stroke-width="0.25" opacity="0">${an('r', '2.4;8', 2.2, -i * 1.1)}${an('opacity', '0.7;0', 2.2, -i * 1.1)}</circle>`).join('') } });
      const high = cyl3(C, [sx, 15.6, sz], [sx, 30, sz], 2.3, '#1e1f22', { mat: 'gloss', n: 18, olw: 0.3 }) + cyl3(C, [sx, 30, sz], [sx, 31.4, sz], 2.5, '#2a2b2e', { mat: 'gloss', n: 18, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.82)}" fill="#0c0c0e"/><text y="0.45" text-anchor="middle" ${FONT} font-size="1.15" fill="#ffd8a0">57.0°</text><circle r="${f1(cr * 0.92)}" fill="none" stroke="#ffb24a" stroke-width="0.25">${an('opacity', '0.3;1;0.3', 2.6)}</circle>` });
      const tub = box3(C, { c: [SX, 0, 0], w: 18, h: 19, d: 20, r: 1.6, col: '#e0f2f6', op: 0.28, gl: 1, skip: { t: 1 }, olw: 0.35, olc: '#7a9aa4', dec: { f: svF(18), r: svF(20), l: svF(20) } })
        + box3(C, { c: [sx, 17, -8.4], w: 2.6, h: 2.4, d: 4.2, r: 0.4, col: '#1e1f22', gl: 0.5, olw: 0.25 });
      const sv = shadow(C, SX, 0, 12, 12, 0.5) + low + bag + bubs + water + high + tub;
      let s = shadow(C, AX, 0, 24, 18, 0.8) + vsort(C, [{ q: [AX, 14, 0], s: oven }, { q: [SX, 12, 0], s: sv }]);
      C.p(AX, 40, -3); return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-071 COPPER COMMERCIAL PASTA EXTRUDER & BLAST CHILLER =======================
  // a brushed stainless blast chiller with copper trims: a frosted glass door (frost on the edges) over two shelves of pasta nests, an amber -18° BLAST
  // display, a copper dial, a copper bar handle; cold mist sinks from the door seal. On top a hammered-copper extruder with a brass PASTAIO plate: a
  // stainless hopper of dough crumbs with a turning paddle and a bronze die. Every 5 s bucatini strands push out of the die, the cutter sweeps round and
  // the pieces drop onto a semolina-dusted wooden tray. A walnut drying rack of tagliatelle sways beside it.
  N.pasta28 = S => { const SS = '#c4cad0', CU = '#c87a46', BZ = '#b08440', EX = -10, DX = 17, PF = 'k28x_', T = 5;
    const D = { w: 62, d: 36, build: () => [] };
    const R = rng('pasta28');
    const nests = rep(6, i => { const x = 9 + (i % 3) * 12, y = 12.6 + Math.floor(i / 3) * 10; return `<ellipse cx="${x}" cy="${f1(y)}" rx="4" ry="1.9" fill="#e8c060"/>` + rep(4, k => `<path d="M${x - 3.4} ${f1(y - 0.8 + k * 0.5)}q3.4 ${k % 2 ? -1.2 : 1.2} 6.8 0" stroke="#c89a3a" stroke-width="0.3" fill="none"/>`).join(''); }).join('');
    const frost = rep(16, () => { const e = R(), t = R(), x = e < 0.5 ? 3.6 + t * 38.8 : (R() < 0.5 ? 4 : 42), y = e < 0.5 ? (R() < 0.5 ? 4.6 : 28.4) : 4.6 + t * 23.8; return `<g transform="translate(${f1(x)} ${f1(y)}) scale(${f1(0.4 + R() * 0.5)})" stroke="#ffffff" stroke-width="0.3" opacity="0.75">${rep(3, k => `<path d="M-1.4 0H1.4" transform="rotate(${k * 60})"/>`).join('')}</g>`; }).join('');
    const cF = `<rect width="58" height="1.4" fill="url(#k6cu)"/><rect y="30.6" width="58" height="1.4" fill="url(#k6cu)"/><rect x="3" y="4" width="40" height="25" rx="1.4" fill="#26303a"/>` + rep(2, i => `<rect x="4" y="${f1(13.6 + i * 10)}" width="38" height="0.8" fill="#8a9298"/>`).join('') + nests
      + `<rect x="3" y="4" width="40" height="25" rx="1.4" fill="url(#k6fr)" opacity="0.8"/>` + frost + `<rect x="3" y="4" width="40" height="25" rx="1.4" fill="none" stroke="#9aa2a8" stroke-width="0.8"/>`
      + `<rect x="46" y="4" width="9" height="12" rx="1" fill="#141618"/><text x="50.5" y="9" text-anchor="middle" ${FONT} font-size="2.2" fill="#ffb24a">-18°</text><text x="50.5" y="11.6" text-anchor="middle" ${FONT} font-size="0.9" fill="#c88a3a" letter-spacing="0.3">BLAST</text><circle cx="48.2" cy="14" r="0.5" fill="#7ad8ff">${an('opacity', '1;0.2;1', 2)}</circle><text x="52" y="14.4" text-anchor="middle" ${FONT} font-size="0.8" fill="#8a9298">ON</text>`
      + `<circle cx="50.5" cy="21" r="2.8" fill="url(#k6cu)"/><circle cx="50.5" cy="21" r="2.8" fill="none" stroke="#6a3a1a" stroke-width="0.3"/><path d="M50.5 21L50.5 18.8" stroke="#3a1a0a" stroke-width="0.4"/>` + rep(5, i => `<rect x="${f1(47 + i * 1.6)}" y="26" width="0.8" height="3" rx="0.4" fill="#5a6066"/>`).join('');
    const ham = W => `<rect width="${W}" height="20" fill="url(#k6cu)" opacity="0.35"/>` + rep(Math.round(W * 0.9), () => `<circle cx="${f1(R() * W)}" cy="${f1(R() * 17)}" r="${f1(0.5 + R() * 0.7)}" fill="${R() < 0.5 ? '#ffffff' : '#5a2a10'}" opacity="${n4(0.08 + R() * 0.12)}"/>`).join('');
    const eF = ham(24) + `<rect x="3" y="12.2" width="18" height="3.6" rx="0.8" fill="url(#k28brs)"/><text x="12" y="14.8" text-anchor="middle" font-family="Georgia,serif" font-size="1.6" fill="#4a3210" letter-spacing="0.6">PASTAIO</text>`
      + `<rect x="2.6" y="2.4" width="2.4" height="3.4" rx="0.6" fill="#2a2a2a"/><rect x="3.2" y="2" width="1.2" height="2.2" rx="0.5" fill="#d8dce0"/><circle cx="20.4" cy="4" r="0.8" fill="#ffb24a"/><circle cx="20.4" cy="4" r="1.8" fill="#ffb24a" opacity="0.35" filter="url(#m10b1)">${an('opacity', '0.2;0.45;0.2', 3)}</circle>`;
    const tT = `<rect width="20" height="8.4" fill="url(#m10noise)"/>` + rep(30, () => `<circle cx="${f1(R() * 20)}" cy="${f1(R() * 8.4)}" r="${f1(0.15 + R() * 0.2)}" fill="#f4ead0" opacity="0.8"/>`).join('')
      + rep(12, () => { const x = 2 + R() * 15, y = 1 + R() * 6, a = R() * 180; return `<g transform="translate(${f1(x)} ${f1(y)}) rotate(${f1(a)})"><rect x="-1.2" y="-0.45" width="2.4" height="0.9" rx="0.3" fill="#f2d27a"/><ellipse cx="1.2" rx="0.2" ry="0.4" fill="#c89a3a"/></g>`; }).join('');
    const defs = DEFK + `<defs>${sym(PF + 'c', cF)}${sym(PF + 'e', eF)}${sym(PF + 't', tT)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const feet = [[-26, -14], [26, -14], [-26, 14], [26, 14]].map(([x, z]) => cyl3(C, [x, 0, z], [x, 2, z], 1.4, '#3a3e42', { mat: 'chrome', n: 12, olw: 0.25 })).join('');
      const chill = box3(C, { c: [0, 2, 0], w: 58, h: 32, d: 32, r: 2, col: SS, mat: 'brush', gl: 0.5, olw: 0.5, olo: 0.7, dec: { f: use(PF + 'c'), t: `<rect x="0.5" y="0.5" width="57" height="31" rx="1.6" fill="none" stroke="url(#k6cu)" stroke-width="0.8"/>` } });
      const hd = [10, 28].map(y => cyl3(C, [15, y, 16], [15, y, 18.2], 0.5, CU, { mat: 'metal', n: 8, olw: 0.2 })).join('') + cyl3(C, [15, 9, 18.2], [15, 29, 18.2], 0.9, CU, { mat: 'metal', n: 12, olw: 0.25 });
      const base = feet + (fv ? chill + hd : hd + chill);
      // extruder
      const body = box3(C, { c: [EX, 34, -5], w: 24, h: 17, d: 20, r: 2.4, col: CU, mat: 'brush', gl: 0.9, olw: 0.45, olo: 0.7, dec: { f: use(PF + 'e'), l: ham(20), r: ham(20), b: ham(24) } });
      const hop = cyl3(C, [EX, 51, -6], [EX, 52.6, -6], 7, SS, { mat: 'chrome', n: 26, olw: 0.3 }) + cyl3(C, [EX, 52.6, -6], [EX, 60, -6], 7.4, SS, { r2: 8, mat: 'chrome', n: 28, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#9aa2a8"/><circle r="${f1(cr * 0.82)}" fill="#e8c870"/>` + rep(14, i => `<circle cx="${f1(Math.cos(i * 2.4) * cr * (0.2 + (i % 4) * 0.17))}" cy="${f1(Math.sin(i * 2.4) * cr * (0.2 + (i % 4) * 0.17))}" r="${f1(0.6 + (i % 3) * 0.3)}" fill="#f2d890"/>`).join('') + `<g>${at('rotate', '0;360', 3)}<rect x="${f1(-cr * 0.78)}" y="-0.5" width="${f1(cr * 1.56)}" height="1" rx="0.5" fill="#aab2b8"/></g><circle r="1" fill="#6a7076"/>` });
      const die = cyl3(C, [EX, 44, 5], [EX, 44, 8], 4.6, BZ, { mat: 'metal', n: 26, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.88)}" fill="#8a6a30"/><circle r="${f1(cr * 0.88)}" fill="url(#m10cap)" opacity="0.5"/>` });
      const HO = rep(6, k => { const a = (k * 60 + 30) * PI / 180; return [EX + Math.cos(a) * 2.4, 44 + Math.sin(a) * 2.4, 8.1]; });
      const holes = HO.map(h => { const p = C.P(h); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.6 * C.k)}" fill="#1a1208"/>`; }).join('') + (() => { const p = C.P([EX, 44, 8.1]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.7 * C.k)}" fill="#d8b860"/>`; })();
      const strands = `<g>${at('translate', `0 0;0 0;0 ${f1(2.4 * C.k)};0 ${f1(2.4 * C.k)}`, T, -3, ' keyTimes="0;0.8;0.9;1"')}${an('opacity', '1;1;0;0', T, -3, ' keyTimes="0;0.8;0.9;1"')}` + HO.map(h => { const a = C.P(h), b = C.P([h[0], 35.8, h[2] + 0.4]), L = Math.hypot(b[0] - a[0], b[1] - a[1]) + 0.5, d = `M${P2(a)}L${P2(b)}`, x = ' keyTimes="0;0.7;1"';
        return [[1, '#f2d27a'], [0.3, '#c89a3a']].map(([w, c]) => `<path d="${d}" stroke="${c}" stroke-width="${f1(w * C.k)}" stroke-linecap="round" fill="none" stroke-dasharray="${f1(L)} ${f1(L * 2)}" stroke-dashoffset="${f1(L)}">${an('stroke-dashoffset', `${f1(L)};0;0`, T, -3, x)}</path>`).join(''); }).join('') + '</g>';
      const dc = C.P([EX, 44, 8.3]), cut = `<g>${at('rotate', `0 ${P2(dc)};0 ${P2(dc)};360 ${P2(dc)};360 ${P2(dc)}`, T, -3, ' keyTimes="0;0.74;0.8;1"')}<path d="M${P2(dc)}l0 ${f1(-5.2 * C.k)}" stroke="#e8ecef" stroke-width="${f1(0.6 * C.k)}" stroke-linecap="round"/></g>`;
      const ext = fv ? body + hop + die + holes + strands + cut : die + strands + body + hop;
      const tray = box3(C, { c: [EX, 34, 11.4], w: 20, h: 1.4, d: 8.4, r: 0.6, col: '#c89a5a', gl: 0.3, olw: 0.3, dec: { t: use(PF + 't') } });
      // drying rack
      const RL = [{ q: [DX, 45, -4], s: cyl3(C, [DX, 34, -4], [DX, 35.4, -4], 5, '#6b4226', { mat: 'gloss', n: 22, olw: 0.3 }) + cyl3(C, [DX, 35.4, -4], [DX, 57, -4], 0.9, '#7a4e2c', { mat: 'gloss', n: 12, olw: 0.25 }) + sph(C, [DX, 57.6, -4], 1.2, '#7a4e2c') },
        { q: [DX, 56, -4], s: cyl3(C, [DX - 9, 56, -4], [DX + 9, 56, -4], 0.5, '#8a5a34', { mat: 'gloss', n: 10, olw: 0.2 }) + cyl3(C, [DX, 56, -13], [DX, 56, 5], 0.5, '#8a5a34', { mat: 'gloss', n: 10, olw: 0.2 }) }];
      const rib = `<path d="M0 0H1.3V9.6Q0.9 10.6 1.1 11.4H0.2Q0.4 10.4 0 9.6Z" fill="#f0cf78"/><path d="M0.65 0V10" stroke="#d8b050" stroke-width="0.2"/>`;
      [[-7, 0, 'x'], [-3.6, 0, 'x'], [3.6, 0, 'x'], [7, 0, 'x'], [0, -7.4, 'z'], [0, -3.6, 'z'], [0, 3.6, 'z']].forEach(([dx, dz, ax], i) => [-1, 1].forEach(sd => {
        const O = ax === 'x' ? [DX + dx - 0.65, 55.6, -4 + dz + sd * 0.6] : [DX + dx + sd * 0.6, 55.6, -4 + dz - 0.65], U = ax === 'x' ? [1, 0, 0] : [0, 0, 1];
        RL.push({ q: [O[0], 50, O[2]], s: PLN(C, O, U, [0, -1, 0], `<g>${at('rotate', '-5 0.65 0;5 0.65 0;-5 0.65 0', 3 + (i % 3) * 0.4, -i * 0.5, SPL(2))}${rib}</g>`) }); }));
      const rack = vsort(C, RL);
      const top = tray + vsort(C, [{ q: [EX, 45, -5], s: ext }, { q: [DX, 46, -4], s: rack }]);
      let s = shadow(C, 0, 0, 36, 22, 0.85) + base + top + (fv ? wisp(C, [-12, 3, 16.6], 0.8, 6, 0, -3, 4) + wisp(C, [4, 3, 16.6], 0.7, 7, -3, 3, 5) : '');
      C.p(EX, 62, -6); C.p(DX, 60, -4); return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KIT-091 HOLOGRAPHIC 3D FOOD SYNTHESIZER & INSTANT PASTRY PRINTER =======================
  // an ivory Calacatta block with champagne-gold trims floating on a dark plinth over a warm glow. Black-glass panel: PÂTISSERIE · SYNTH, FRAISIER and a gold
  // progress bar. Left: a glass cloche on a gold base where a gold gantry rises every 12 s and prints a fraisier layer by layer (sponge, cream with
  // strawberry halves, sponge, pink glaze, berries), holds, fades, starts again. Right: a gold emitter projects a pearl hologram of a macaron tower in a
  // soft light cone (scan ring rising, sparkles orbiting, gentle bob and flicker). Finished pastries wait on a gold tray sliding out of the front slot:
  // a croissant and three macarons.
  N.syn28 = S => { const IV = '#efe9e0', PX = -20, PZ = -2, HX = 22, HZ = -2, PF = 'k28y_', T = 12;
    const D = { w: 92, d: 62, build: () => [] };
    const R = rng('syn28');
    const trim = (W, h) => `<rect width="${W}" height="0.9" fill="url(#k28brs)"/><rect y="${f1(h - 0.9)}" width="${W}" height="0.9" fill="url(#k28brs)"/>`;
    const fF = veins(R, 84, 24) + `<rect width="84" height="24" fill="url(#m10noise)"/>` + trim(84, 24)
      + `<rect x="50" y="4" width="30" height="9" rx="1.4" fill="#141210"/><rect x="50" y="4" width="30" height="9" rx="1.4" fill="none" stroke="url(#k28brs)" stroke-width="0.4"/><text x="65" y="6.8" text-anchor="middle" ${FONT} font-size="1.2" fill="#e8d2a0" letter-spacing="0.4">PÂTISSERIE · SYNTH</text>`
      + `<text x="65" y="9.6" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-size="1.6" fill="#f4dcb0">Fraisier</text><rect x="53" y="10.9" width="24" height="0.8" rx="0.4" fill="#3a3026"/><rect x="53" y="10.9" width="0" height="0.8" rx="0.4" fill="url(#k28brs)"><animate attributeName="width" values="24;24;0;0;24;24" keyTimes="0;0.26;0.27;0.3;0.94;1" dur="${T}s" repeatCount="indefinite"/></rect>`
      + `<rect x="8" y="9" width="32" height="3.2" rx="1.6" fill="#1a1612"/><rect x="8" y="9" width="32" height="3.2" rx="1.6" fill="none" stroke="url(#k28brs)" stroke-width="0.4"/>`;
    const sF = W => veins(R, W, 24) + trim(W, 24);
    const tT = veins(R, 84, 56) + `<circle cx="22" cy="30" r="16.4" fill="none" stroke="url(#k28brs)" stroke-width="0.5"/><circle cx="64" cy="30" r="12.4" fill="none" stroke="url(#k28brs)" stroke-width="0.5"/>`;
    const defs = DEFK + `<defs>${sym(PF + 'f', fF)}${sym(PF + 's', sF(56))}${sym(PF + 't', tT)}</defs>`;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const glow = PLN(C, [0, 0.04, 0], [1, 0, 0], [0, 0, 1], `<ellipse rx="50" ry="36" fill="url(#k28amb)">${an('opacity', '0.55;0.85;0.55', 5)}</ellipse>`);
      const plinth = box3(C, { c: [0, 0, 0], w: 76, h: 3, d: 48, r: 3, col: '#141210', gl: 0.3, olw: 0.3 });
      const body = box3(C, { c: [0, 3, 0], w: 84, h: 24, d: 56, r: 6, col: IV, gl: 0.6, olw: 0.45, olo: 0.6, dec: { f: use(PF + 'f'), t: use(PF + 't'), l: use(PF + 's'), r: use(PF + 's'), b: trim(84, 24) } });
      // front tray with pastries
      const cro = [[-27, 16.6, 31.2, 1.1], [-25.2, 17.3, 30.7, 1.6], [-23, 17.6, 30.6, 1.9], [-20.8, 17.3, 30.8, 1.6], [-19.2, 16.6, 31.4, 1.1]].map(([x, y, z, r]) => ({ q: [x, y, z], s: sph(C, [x, y, z], r, '#d89448') + (() => { const p = C.P([x, y, z]); return `<path d="M${f1(p[0] - r * 0.5 * C.k)} ${f1(p[1] - r * 0.7 * C.k)}q${f1(r * 0.3 * C.k)} ${f1(r * 0.6 * C.k)} 0 ${f1(r * 1.3 * C.k)}" stroke="#a8622a" stroke-width="${f1(0.2 * C.k)}" fill="none"/>`; })() }));
      const mac = [[-14, '#f4b8c8'], [-10.4, '#c8e8d0'], [-6.8, '#e0d0f4']].map(([x, c]) => ({ q: [x, 17, 30.8], s: cyl3(C, [x, 15.8, 30.8], [x, 17, 30.8], 1.7, c, { mat: 'matte', n: 18, olw: 0.25 }) + cyl3(C, [x, 17, 30.8], [x, 17.5, 30.8], 1.5, '#fff6ea', { mat: 'matte', n: 16, olw: 0.15 }) + cyl3(C, [x, 17.5, 30.8], [x, 18.7, 30.8], 1.7, c, { mat: 'gloss', n: 18, olw: 0.25 }) }));
      const tray = box3(C, { c: [-18, 14.8, 30.7], w: 26, h: 1, d: 5.4, r: 0.8, col: GD, gl: 0.9, olw: 0.3 }) + vsort(C, cro.concat(mac));
      // printer
      const pb = cyl3(C, [PX, 27, PZ], [PX, 29, PZ], 15, GD, { mat: 'metal', n: 36, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.88)}" fill="#f4f0ea"/><circle r="${f1(cr * 0.88)}" fill="url(#m10cap)" opacity="0.5"/>` });
      const halves = [-0.9, -0.45, 0, 0.45, 0.9].map(a => `<g transform="${tanF(C, PX, PZ, 9.25, C.thV + a, 33.7)}"><path d="M0 0.8C-1.4 0.2 -1.2 -0.9 0 -0.6C1.2 -0.9 1.4 0.2 0 0.8Z" fill="#e0303a"/><path d="M0 0.5C-0.7 0 -0.6 -0.4 0 -0.3" stroke="#ffd0d0" stroke-width="0.15" fill="none"/></g>`).join('');
      const berries = vsort(C, [[0, 0], [4.6, 0], [-4.6, 0], [0, 4.6], [0, -4.6], [3.3, 3.3], [-3.3, -3.3]].map(([x, z], i) => ({ q: [PX + x, 41, PZ + z], s: sph(C, [PX + x, i ? 41.2 : 41.8, PZ + z], i ? 1.3 : 1.7, '#e0303a') })));
      const cake = cyl3(C, [PX, 29, PZ], [PX, 33, PZ], 9, '#f2d49a', { mat: 'matte', n: 30, olw: 0.25, noCap: 1 }) + cyl3(C, [PX, 33, PZ], [PX, 34.4, PZ], 9.2, '#fff6ea', { mat: 'matte', n: 30, olw: 0.2, noCap: 1 }) + halves
        + cyl3(C, [PX, 34.4, PZ], [PX, 38.4, PZ], 9, '#f2d49a', { mat: 'matte', n: 30, olw: 0.25, noCap: 1 }) + cyl3(C, [PX, 38.4, PZ], [PX, 40.2, PZ], 9.4, '#ffd8e4', { mat: 'gloss', n: 30, olw: 0.25, cap: cr => rep(12, i => { const a = i / 12 * 2 * PI; return `<circle cx="${f1(Math.cos(a) * cr * 0.84)}" cy="${f1(Math.sin(a) * cr * 0.84)}" r="0.8" fill="#fff6ea"/>`; }).join('') }) + berries;
      const yb = C.P([PX, 29, PZ + 9.4])[1] + 2 * C.k, yt = C.P([PX, 44, PZ - 9.4])[1] - 2 * C.k, ck = C.u('pc');
      const cakeS = `<defs><clipPath id="${ck}"><rect x="-3000" y="${f1(yt)}" width="6000" height="3000"><animate attributeName="y" values="${f1(yt)};${f1(yt)};${f1(yb)};${f1(yb)};${f1(yt)};${f1(yt)}" keyTimes="0;0.26;0.27;0.3;0.94;1" dur="${T}s" repeatCount="indefinite"/></rect></clipPath></defs><g clip-path="url(#${ck})"><g>${an('opacity', '1;1;0;0;1;1', T, 0, ' keyTimes="0;0.2;0.26;0.27;0.28;1"')}${cake}</g></g>`;
      const dS = f1(C.P([PX, 43, PZ])[1] - C.P([PX, 30, PZ])[1]), np = C.P([PX, 29.2, PZ]);
      const gantry = `<g>${at('translate', `0 ${dS};0 ${dS};0 0;0 0;0 ${dS};0 ${dS}`, T, 0, ' keyTimes="0;0.26;0.3;0.31;0.94;1"')}${cyl3(C, [PX - 12.6, 30, PZ], [PX + 12.6, 30, PZ], 0.7, GD, { mat: 'metal', n: 12, olw: 0.2 })}${box3(C, { c: [PX, 29.4, PZ], w: 4, h: 2.2, d: 4, r: 0.8, col: GD, gl: 0.9, olw: 0.25 })}<circle cx="${f1(np[0])}" cy="${f1(np[1])}" r="${f1(1.4 * C.k)}" fill="#ffd890" opacity="0.6" filter="url(#m10b1)">${an('opacity', '0.3;0.8;0.3', 0.7)}</circle></g>`;
      const post = sx => cyl3(C, [PX + sx * 12.6, 29, PZ], [PX + sx * 12.6, 57.6, PZ], 0.7, GD, { mat: 'metal', n: 12, olw: 0.2 }), near = C.v[0] > 0 ? 1 : -1;
      const printer = pb + post(-near) + cakeS + gantry + post(near) + cyl3(C, [PX, 29, PZ], [PX, 58, PZ], 14, '#f4f0ff', { mat: 'chrome', n: 36, op: 0.14, noCap: 1, olw: 0.3, olc: '#b8a8c8' })
        + cyl3(C, [PX, 58, PZ], [PX, 59.2, PZ], 14.3, GD, { mat: 'metal', n: 36, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.94)}" fill="#f4f0ff" opacity="0.18"/>` }) + sph(C, [PX, 60.6, PZ], 1.5, GD);
      // hologram
      const hb = cyl3(C, [HX, 27, HZ], [HX, 29, HZ], 11, GD, { mat: 'metal', n: 32, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.82)}" fill="#141218"/>` + [0.7, 0.5, 0.3].map((k, i) => `<circle r="${f1(cr * k)}" fill="none" stroke="#f0d8ff" stroke-width="0.35" opacity="0.6">${an('opacity', '0.2;0.8;0.2', 2, -i * 0.5)}</circle>`).join('') + `<circle r="${f1(cr * 0.12)}" fill="#ffffff"/>` });
      const rt = C.rt, cp = (dx, y) => C.P([HX + rt[0] * dx, y, HZ + rt[2] * dx]), cg = C.u('hc'), c0 = cp(-8, 29.2), c1 = cp(8, 29.2), c2 = cp(7, 58), c3 = cp(-7, 58);
      const cone = `<defs><linearGradient id="${cg}" gradientUnits="userSpaceOnUse" x1="0" y1="${f1(c0[1])}" x2="0" y2="${f1(c3[1])}"><stop offset="0" stop-color="#ffe8f4" stop-opacity="0.5"/><stop offset="1" stop-color="#e0f0ff" stop-opacity="0"/></linearGradient></defs><path d="M${P2(c0)}L${P2(c1)}L${P2(c2)}L${P2(c3)}Z" fill="url(#${cg})">${an('opacity', '0.7;1;0.8;1;0.7', 2.4)}</path>`;
      const MC = ['#ffc8dc', '#c8f4e4', '#e4d4ff', '#fff0c4'];
      const tower = MC.map((c, i) => { const y = 38 + i * 4.6, r = 5.6 - i * 0.7; return cyl3(C, [HX, y, HZ], [HX, y + 1.6, HZ], r, c, { mat: 'gloss', n: 24, op: 0.55, olw: 0.25, olc: '#ffffff' }) + cyl3(C, [HX, y + 1.6, HZ], [HX, y + 2.2, HZ], r * 0.9, '#ffffff', { mat: 'matte', n: 20, op: 0.5, ol: 0 }) + cyl3(C, [HX, y + 2.2, HZ], [HX, y + 3.8, HZ], r, c, { mat: 'gloss', n: 24, op: 0.55, olw: 0.25, olc: '#ffffff' }); }).join('') + sph(C, [HX, 56.6, HZ], 1, '#ffe0a0', { op: 0.8 });
      const s0 = C.P([HX, 37, HZ]), s1 = C.P([HX, 57, HZ]), sr = 7 * C.k, sry = f1(Math.max(0.6, 7 * C.k * Math.abs(C.v[1])));
      const scan = `<ellipse cx="${f1(s0[0])}" cy="${f1(s0[1])}" rx="${f1(sr)}" ry="${sry}" fill="none" stroke="#ffffff" stroke-width="${f1(0.35 * C.k)}" opacity="0">${an('cy', `${f1(s0[1])};${f1(s1[1])}`, 3)}${an('opacity', '0;0.8;0', 3)}</ellipse>`;
      const orbit = 'M' + rep(25, j => { const a = j / 24 * 2 * PI; return P2(C.P([HX + Math.cos(a) * 10, 47, HZ + Math.sin(a) * 10])); }).join('L') + 'Z';
      const spkO = rep(4, i => `<circle r="${f1(0.45 * C.k)}" fill="#ffffff"><animateMotion dur="6s" begin="${-i * 1.5}s" repeatCount="indefinite" path="${orbit}"/>${an('opacity', '0.3;1;0.3', 1.5, -i * 0.4)}</circle>`).join('');
      const holo = hb + cone + `<g>${at('translate', `0 0;0 ${f1(-1 * C.k)};0 0`, 3.4, 0, SPL(2))}<g>${an('opacity', '0.85;1;0.7;1;0.9', 1.7, 0, ' calcMode="discrete"')}${tower}</g>${scan}</g>` + spkO;
      let s = glow + plinth + (fv ? body + tray : tray + body) + vsort(C, [{ q: [PX, 40, PZ], s: printer }, { q: [HX, 40, HZ], s: holo }]);
      C.p(PX, 62, PZ); C.p(HX, 60, HZ); return { defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= KITCHEN SINKS (Furniture batch 1: KIT-002 / 022 / 042) =======================
  // Same footprint + use as the old 'counter+sink' piece (124 x 54, act wash, use { x: 0, z: 54 }, arch counter); counter top at y 62 like the ranges.
  // View-safe draw order: basin interior (floor + the inner walls that face you + whatever sits in it + water below the rim) -> cabinet (no top) ->
  // knobs / towels when the front faces you -> slab edges -> counter top with the sink hole clipped out -> sink rim -> backsplash (before the counter
  // things when its front faces you, after them from behind) -> faucet + counter things (depth sorted) -> water above the rim.
  const SKT = 62;
  const rrP = (x, y, w, h, r) => { r = Math.min(r || 0, w / 2, h / 2); return r > 0.05 ? `M${f1(x + r)} ${f1(y)}H${f1(x + w - r)}Q${f1(x + w)} ${f1(y)} ${f1(x + w)} ${f1(y + r)}V${f1(y + h - r)}Q${f1(x + w)} ${f1(y + h)} ${f1(x + w - r)} ${f1(y + h)}H${f1(x + r)}Q${f1(x)} ${f1(y + h)} ${f1(x)} ${f1(y + h - r)}V${f1(y + r)}Q${f1(x)} ${f1(y)} ${f1(x + r)} ${f1(y)}Z` : `M${f1(x)} ${f1(y)}H${f1(x + w)}V${f1(y + h)}H${f1(x)}Z`; };
  // basin interior [x0, x1] x [z0, z1], rim at yT, dep deep: floor (o.floor: u = x, v = z from the back-left corner) + the inner walls that face you (o.wd(k, L, dep))
  const basin = (C, x0, x1, z0, z1, yT, dep, col, o) => { o = o || {}; const y0 = yT - dep, W = x1 - x0, Dd = z1 - z0, dk = o.dk == null ? 0.42 : o.dk, F = o.f || 1;
    const wall = (n, O, U, L, k) => vis(C, n) ? PLN(C, O, U, [0, -1, 0], `<rect width="${f1(L)}" height="${f1(dep)}" fill="${shade(col, lit(C, n) * 0.9 * F)}"/><rect width="${f1(L)}" height="${f1(dep)}" fill="url(#m10in)" opacity="${dk}"/>${o.wd ? o.wd(k, L, dep) : ''}`) : '';
    return PLN(C, [x0, y0, z0], [1, 0, 0], [0, 0, 1], `<rect width="${f1(W)}" height="${f1(Dd)}" fill="${shade(col, lit(C, [0, 1, 0]) * 0.78 * F)}"/><rect width="${f1(W)}" height="${f1(Dd)}" fill="url(#m10t)"/>${o.floor || ''}`)
      + wall([0, 0, 1], [x0, yT, z0], [1, 0, 0], W, 'b') + wall([0, 0, -1], [x1, yT, z1], [-1, 0, 0], W, 'f') + wall([1, 0, 0], [x0, yT, z1], [0, 0, -1], Dd, 'l') + wall([-1, 0, 0], [x1, yT, z0], [0, 0, 1], Dd, 'r'); };
  // flat counter top with holes [x0, z0, x1, z1, r] cut out (decal clipped too)
  const ctopH = (C, x0, x1, z0, z1, y, col, holes, dec) => { const W = x1 - x0, Dd = z1 - z0, id = C.u('ct'), d = `M0 0H${f1(W)}V${f1(Dd)}H0Z` + holes.map(h => rrP(h[0] - x0, h[1] - z0, h[2] - h[0], h[3] - h[1], h[4])).join('');
    return PLN(C, [x0, y, z0], [1, 0, 0], [0, 0, 1], `<clipPath id="${id}"><path d="${d}" clip-rule="evenodd"/></clipPath><g clip-path="url(#${id})"><rect width="${f1(W)}" height="${f1(Dd)}" fill="${shade(col, lit(C, [0, 1, 0]))}"/><rect width="${f1(W)}" height="${f1(Dd)}" fill="url(#m10t)"/>${dec || ''}</g>`); };
  // flat ring: outer [x0, z0, x1, z1, r] minus inner holes; ex = decal clipped to the ring (u, v from the outer back-left corner)
  const ringP = (C, y, O, ins, col, ex) => { const W = O[2] - O[0], Dd = O[3] - O[1], d = rrP(0, 0, W, Dd, O[4]) + ins.map(h => rrP(h[0] - O[0], h[1] - O[1], h[2] - h[0], h[3] - h[1], h[4])).join(''), id = C.u('rg');
    return PLN(C, [O[0], y, O[1]], [1, 0, 0], [0, 0, 1], `<clipPath id="${id}"><path d="${d}" clip-rule="evenodd"/></clipPath><path d="${d}" fill="${shade(col, lit(C, [0, 1, 0]))}" fill-rule="evenodd"/><g clip-path="url(#${id})">${ex || ''}</g><path d="${d}" fill="none" stroke="${shade(col, 0.45)}" stroke-opacity="0.6" stroke-width="0.3"/>`); };
  // bent pipe through pts (sortable segments), arc points for a spout rising from (bx, by, bz) and reaching 2R along dir [dx, dz]
  const pipe = (C, pts, r, col, mat) => pts.slice(1).map((b, i) => { const a = pts[i]; return { q: mul(add(a, b), 0.5), s: cyl3(C, a, b, r, col, { mat: mat || 'chrome', n: 14, olw: 0.25, noCap: i < pts.length - 2 ? 1 : 0 }) }; });
  const arcP = (bx, by, bz, dir, R, a1, n) => rep(n + 1, i => { const a = PI + (a1 - PI) * i / n, k = R + R * Math.cos(a); return [bx + dir[0] * k, by + R * Math.sin(a), bz + dir[1] * k]; });
  // running water a -> b, a falling drop (sharp start), a drop swelling on a tip, synced ripples (PLN space)
  const strm = (C, a, b, w, sp) => { const p = C.P(a), q = C.P(b), d = `M${P2(p)}L${P2(q)}`, L = 3.2 * C.k;
    return `<path d="${d}" stroke="#cfe6f0" stroke-opacity="0.6" stroke-width="${f1(w * C.k)}" stroke-linecap="round"/><path d="${d}" stroke="#ffffff" stroke-opacity="0.8" stroke-width="${f1(w * 0.3 * C.k)}" stroke-linecap="round" stroke-dasharray="${f1(L * 0.4)} ${f1(L * 0.6)}">${an('stroke-dashoffset', `0;${f1(-L * 2)}`, sp || 0.4)}</path>`; };
  const dropS = (C, a, b, r, T, k0, k1) => { const p = C.P(a), q = C.P(b), x = KT(`0;${n4(k0)};${n4(k0 + 0.001)};${n4(k1)};${n4(k1 + 0.001)};1`);
    return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(r * C.k)}" ry="${f1(r * 1.4 * C.k)}" fill="#dceef6" stroke="#8ab4c8" stroke-width="${f1(0.1 * C.k)}" opacity="0">${an('cy', `${f1(p[1])};${f1(p[1])};${f1(p[1])};${f1(q[1])};${f1(q[1])};${f1(q[1])}`, T, 0, x)}${an('cx', `${f1(p[0])};${f1(p[0])};${f1(p[0])};${f1(q[0])};${f1(q[0])};${f1(q[0])}`, T, 0, x)}${an('opacity', '0;0;0.95;0.95;0;0', T, 0, x)}</ellipse>`; };
  const hangD = (C, a, r, T, k0) => { const p = C.P(a), x = KT(`0;${n4(k0)};${n4(k0 + 0.001)};1`), rr = r * C.k;
    return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1] + rr)}" rx="${f1(rr)}" ry="${f1(rr * 1.3)}" fill="#dceef6" stroke="#8ab4c8" stroke-width="${f1(0.1 * C.k)}">${an('rx', `${f1(rr * 0.3)};${f1(rr)};0;0`, T, 0, x)}${an('ry', `${f1(rr * 0.3)};${f1(rr * 1.4)};0;0`, T, 0, x)}${an('cy', `${f1(p[1] + rr * 0.3)};${f1(p[1] + rr * 1.3)};${f1(p[1])};${f1(p[1])}`, T, 0, x)}</ellipse>`; };
  const ripS = (r, T, k, n, col) => rep(n || 2, i => { const k0 = Math.min(0.97, k + i * 0.06), x1 = KT(`0;${n4(k0)};${n4(Math.min(0.999, k0 + 0.2))};1`), x2 = KT(`0;${n4(k0)};${n4(k0 + 0.005)};${n4(Math.min(0.999, k0 + 0.22))};1`);
    return `<circle r="0.2" fill="none" stroke="${col || '#ffffff'}" stroke-width="0.22" opacity="0">${an('r', `0.2;0.2;${f1(r)};${f1(r)}`, T, 0, x1)}${an('opacity', '0;0;0.85;0;0', T, 0, x2)}</circle>`; }).join('');
  // hanging cloth (face-local, top edge at 0, sways round its top middle); ex = pattern drawn under the shading
  const towS = (w, h, fill, ex, T, b) => { const P0 = `M0 0H${f1(w)}V${f1(h)}Q${f1(w / 2)} ${f1(h + 0.8)} 0 ${f1(h)}Z`, id = 'k28tw' + (UIDT++);
    return `<g>${at('rotate', `-2.4 ${f1(w / 2)} 0;2.4 ${f1(w / 2)} 0;-2.4 ${f1(w / 2)} 0`, T, b || 0, SPL(2))}<clipPath id="${id}"><path d="${P0}"/></clipPath><path d="${P0}" fill="${fill}"/><g clip-path="url(#${id})">${ex || ''}</g><path d="${P0}" fill="url(#m10v)"/><path d="M0 0H${f1(w)}V2Q${f1(w / 2)} 3 0 2Z" fill="#000000" opacity="0.12"/><path d="M${f1(w * 0.3)} 0.6Q${f1(w * 0.34)} ${f1(h * 0.5)} ${f1(w * 0.27)} ${f1(h - 0.2)}M${f1(w * 0.72)} 0.6Q${f1(w * 0.7)} ${f1(h * 0.5)} ${f1(w * 0.74)} ${f1(h)}" stroke="#000000" stroke-opacity="0.08" stroke-width="1" fill="none"/></g>`; };
  let UIDT = 0;
  const knobB = (C, x, y, z, r, col, mat) => cyl3(C, [x, y, z], [x, y, z + r * 0.9], r * 0.42, col, { mat: mat || 'gloss', n: 10, olw: 0.2 }) + sph(C, [x, y, z + r * 1.3], r, col);
  const specks = (R, n, w, h, cs, r0, r1, op) => rep(n, () => `<circle cx="${f1(R() * w)}" cy="${f1(R() * h)}" r="${f1(r0 + R() * (r1 - r0))}" fill="${cs[Math.floor(R() * cs.length)]}" opacity="${n4(op * (0.5 + R() * 0.5))}"/>`).join('');
  const sway = (C, q, s, a, T, b) => { const p = C.P(q); return `<g>${at('rotate', `${-a} ${P2(p)};${a} ${P2(p)};${-a} ${P2(p)}`, T, b || 0, SPL(2))}${s}</g>`; };

  // KIT-002 SHALLOW SINGLE-BOWL STAINLESS SINK WITH LEAKY TAP (T1): water-swollen off-white laminate base cabinet (left door sagging off a broken hinge, right
  // door missing its knob, peeling edge banding, an ironic "SAVE WATER!" raindrop sticker, kick scuffs); chipped beige laminate top with a cigarette burn, cup
  // rings, knife cuts and a lifted seam; yellowed caulk on a 4" backsplash. Dull stainless bowl: rust halo + streak round a crusty drain, water spots, scratches.
  // Old two-handle chrome faucet (cold cap missing), a rag + duct tape round the leaking spout base. Always: a drop swells on the limescaled aerator and plinks
  // into a chipped "#1 DAD" mug every 2.6 s (ripples), the rag weeps into a puddle, a dingy dishcloth sways on the door. Counter: toothbrush cup + toothpaste,
  // crumpled paper towel, almost-empty LEMMO soap, crusty sponge in a puddle, a saucepan of dried mac & cheese with a wooden spoon.
  N.leak28 = S => { const TY = SKT, CB = '#e4d9c2', LM = '#d8caa2', SS = '#b4b9bd', CH = '#ccd1d5', BX0 = -30, BX1 = 14, BZ0 = -15, BZ1 = 15, DEP = 10, FX = -8, FZ = -21.5, SZ = -7.4, ZF = 25.6, T = 2.6, Y0 = TY - DEP;
    const D = { w: 124, d: 54, arch: 'counter', act: 'wash', use: { x: 0, z: 54 }, topH: TY, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), lf = lit(C, [0, 0, 1]), R = rng('leak28');
      // cabinet front (u 0..122 from x -61, v 0..55 down from y 59)
      const grv = (x, y, w, h) => `<rect x="${f1(x + 4)}" y="${f1(y + 4)}" width="${f1(w - 8)}" height="${f1(h - 8)}" rx="1.6" fill="none" stroke="#000000" stroke-opacity="0.16" stroke-width="0.55"/><rect x="${f1(x + 4.4)}" y="${f1(y + 4.5)}" width="${f1(w - 8)}" height="${f1(h - 8)}" rx="1.6" fill="none" stroke="#ffffff" stroke-opacity="0.22" stroke-width="0.35"/>`;
      const dmg = (x, w) => `<rect x="${f1(x)}" y="48.6" width="${f1(w)}" height="5.8" fill="#7a5a30" opacity="0.22"/>` + rep(6, () => { const cx = x + 3 + R() * (w - 6), cy = 50 + R() * 3.4, r = 0.6 + R() * 1.1; return `<ellipse cx="${f1(cx)}" cy="${f1(cy)}" rx="${f1(r)}" ry="${f1(r * 0.7)}" fill="#ffffff" opacity="0.22"/><ellipse cx="${f1(cx + 0.2)}" cy="${f1(cy + 0.3)}" rx="${f1(r)}" ry="${f1(r * 0.7)}" fill="none" stroke="#5a4020" stroke-opacity="0.35" stroke-width="0.2"/>`; }).join('')
        + `<path d="M${f1(x)} 48.6Q${f1(x + w * 0.3)} 47.8 ${f1(x + w * 0.55)} 48.9T${f1(x + w)} 48.4" stroke="#6a4a24" stroke-opacity="0.3" stroke-width="0.35" fill="none"/>`;
      const doorR = `<rect x="61.6" y="12.6" width="58.4" height="41.8" fill="none" stroke="#4a3a24" stroke-opacity="0.5" stroke-width="0.4"/>${grv(61.6, 12.6, 58.4, 41.8)}${dmg(61.6, 58.4)}`
        + `<circle cx="66" cy="21" r="2.4" fill="#6a5030" opacity="0.14"/><circle cx="66" cy="21" r="0.55" fill="#2a2016"/><circle cx="66.2" cy="24.4" r="0.35" fill="#2a2016" opacity="0.7"/>`
        + `<path d="M107 54.4H120V46.6" fill="none" stroke="#b08a58" stroke-width="1.1"/>` + rep(8, i => `<circle cx="${f1(108 + i * 1.5)}" cy="54" r="0.2" fill="#6a4a24"/>`).join('') + `<path d="M107 54.2Q112 52.2 116.6 53.6" stroke="${shade(CB, lf * 1.12)}" stroke-width="1" fill="none"/><path d="M107.4 54.6Q112 52.8 116 54.2" stroke="#000000" stroke-opacity="0.2" stroke-width="0.3" fill="none"/>`
        + `<g transform="translate(99 30) rotate(-8)" opacity="0.8"><path d="M0 -4.4C2.6 -1 3.4 0.6 3.4 2Q3.4 4.6 0 4.6Q-3.4 4.6 -3.4 2C-3.4 0.6 -2.6 -1 0 -4.4Z" fill="#9ccfe8" stroke="#ffffff" stroke-width="0.6"/><circle cx="-1.1" cy="1.4" r="0.4" fill="#2a3a4a"/><circle cx="1.1" cy="1.4" r="0.4" fill="#2a3a4a"/><path d="M-1.2 2.8Q0 3.8 1.2 2.8" stroke="#2a3a4a" stroke-width="0.3" fill="none"/><path d="M2.4 -1.6L4.4 -2.6L3.4 0.2Z" fill="#f4f0e6"/><text y="7.6" text-anchor="middle" ${HANDW} font-size="1.5" fill="#3a7ab0">SAVE WATER!</text></g>`;
      const doorL = `<rect x="2" y="12.6" width="58.8" height="42.4" fill="#1a140c" opacity="0.85"/><g transform="rotate(1.7 2 12.6)"><rect x="2" y="12.6" width="58.4" height="41.8" fill="${shade(CB, lf * 1.02)}" stroke="#4a3a24" stroke-opacity="0.5" stroke-width="0.4"/><rect x="2" y="12.6" width="58.4" height="41.8" fill="url(#m10v)"/>${grv(2, 12.6, 58.4, 41.8)}${dmg(2, 58.4)}${fp(55, 22, 1, 20, 0.2)}${fp(52.6, 25, 0.9, -10, 0.16)}<ellipse cx="54" cy="21" rx="4" ry="5" fill="#6a5030" opacity="0.1" filter="url(#m10b1)"/></g>`;
      const cabF = `<path d="M1 12H121M61.1 12V55" stroke="#1a140c" stroke-opacity="0.55" stroke-width="0.6"/><rect x="2" y="1.4" width="118" height="9.6" fill="none" stroke="#4a3a24" stroke-opacity="0.45" stroke-width="0.4"/><path d="M2.4 1.8H119.6" stroke="#ffffff" stroke-opacity="0.25" stroke-width="0.3"/><ellipse cx="30" cy="7" rx="8" ry="2.4" fill="#6a5030" opacity="0.08" filter="url(#m10b1)"/>`
        + doorR + doorL + scr(R, 12, 4, 50, 114, 4.4, '#2a2016', 0.45);
      const cabS = `<rect y="48.6" width="52.6" height="6.4" fill="#7a5a30" opacity="0.2"/><path d="M0 48.6Q20 47.6 52.6 48.8" stroke="#6a4a24" stroke-opacity="0.3" stroke-width="0.35" fill="none"/>`;
      const ragX = `<rect width="11" height="15" fill="url(#k28wv)"/><path d="M0 9.6H11M0 10.6H11" stroke="#6a7a88" stroke-opacity="0.5" stroke-width="0.4"/><ellipse cx="6.6" cy="5.4" rx="2.4" ry="1.6" fill="#8a7a4a" opacity="0.25"/><ellipse cx="3.2" cy="12.4" rx="0.9" ry="0.6" fill="#1a140c" opacity="0.75"/>` + rep(12, i => `<path d="M${f1(0.5 + i * 0.9)} ${f1(14.6 + (i % 3) * 0.3)}v${f1(0.8 + (i % 2) * 0.6)}" stroke="#a3adb3" stroke-width="0.3"/>`).join('');
      const kick = box3(C, { c: [0, 0, -2.5], w: 118, h: 4, d: 47, r: 0.3, col: '#3a3228', olw: 0.3, skip: { t: 1 }, dec: { f: scr(rng('leak28k'), 14, 2, 0.5, 114, 3, '#c8b898', 0.5) } });
      const cab = box3(C, { c: [0, 4, -0.7], w: 122, h: TY - 7, d: 52.6, r: 0.4, col: CB, olw: 0.45, olo: 0.7, skip: { t: 1 }, dec: { f: cabF, l: cabS, r: cabS } });
      const fr = knobB(C, -5.8, 38.4, ZF, 1.5, '#d8c49a') + PLN(C, [-36, 46.2, ZF + 0.7], [1, 0, 0], [0, -1, 0], towS(11, 15, '#a3adb3', ragX, 6.4));
      // laminate slab + top (u 0..124 from x -62, v 0..55 from z -27)
      const chips = [[18, 2.2], [47, 3.4], [73, 1.6], [104, 2.6]];
      const edgeF = `<path d="M0 2.85H124" stroke="#000000" stroke-opacity="0.25" stroke-width="0.3"/>` + chips.map(([x, w]) => `<path d="M${x} 0L${f1(x + w * 0.3)} 1.4L${f1(x + w * 0.7)} 1.1L${f1(x + w)} 0Z" fill="#b48a52"/><path d="M${x} 0L${f1(x + w * 0.3)} 1.4L${f1(x + w * 0.7)} 1.1L${f1(x + w)} 0" fill="none" stroke="#5a3a1a" stroke-opacity="0.5" stroke-width="0.15"/>`).join('') + specks(rng('leak28e'), 30, 124, 3, ['#a8946a', '#f4ecd8'], 0.1, 0.25, 0.5);
      const slab = box3(C, { c: [0, TY - 3, 0.5], w: 124, h: 3, d: 55, r: 0.5, col: LM, olw: 0.4, skip: { t: 1 }, dec: { f: edgeF } });
      const Rt = rng('leak28t');
      const topD = specks(Rt, 240, 124, 55, ['#a8946a', '#f4ecd8', '#8a7650'], 0.12, 0.32, 0.4)
        + `<rect x="34" y="44" width="40" height="10" rx="4" fill="#ffffff" opacity="0.12" filter="url(#m10b1)"/>`
        + `<g transform="translate(100 22)"><ellipse rx="3.4" ry="2.6" fill="#5a3a1a" opacity="0.28" filter="url(#m10b1)"/><ellipse rx="1.6" ry="1.2" fill="#3a2410" opacity="0.4"/><ellipse rx="1.6" ry="1.2" fill="none" stroke="#1a0e04" stroke-opacity="0.5" stroke-width="0.35"/></g>`
        + [[14, 36, 3], [19.6, 39, 3]].map(([x, y, r]) => `<path d="M${f1(x - r)} ${y}A${r} ${r} 0 1 1 ${f1(x + r * 0.7)} ${f1(y + r * 0.7)}" stroke="#7a5a30" stroke-opacity="0.2" stroke-width="0.45" fill="none"/>`).join('')
        + scr(Rt, 14, 84, 30, 30, 20, '#6a5434', 0.5) + `<path d="M108 0V55" stroke="#6a5434" stroke-opacity="0.35" stroke-width="0.35"/><path d="M108.3 0V55" stroke="#ffffff" stroke-opacity="0.25" stroke-width="0.2"/>`
        + rep(9, () => `<ellipse cx="${f1(76 + Rt() * 10)}" cy="${f1(14 + Rt() * 26)}" rx="${f1(0.8 + Rt() * 1.6)}" ry="${f1(0.6 + Rt() * 1)}" fill="#ffffff" opacity="0.18"/>`).join('')
        + chips.map(([x, w]) => `<path d="M${x} 55L${f1(x + w * 0.4)} 54.1L${f1(x + w)} 55Z" fill="#b48a52"/>`).join('') + rep(10, () => `<circle cx="${f1(96 + Rt() * 22)}" cy="${f1(24 + Rt() * 10)}" r="0.25" fill="#e8b048" opacity="0.6"/>`).join('');
      const top = ctopH(C, -62, 62, -27, 28, TY, LM, [[BX0, BZ0, BX1, BZ1, 2.4]], topD);
      const pud = PLN(C, [24, TY + 0.04, 6], [1, 0, 0], [0, 0, 1], `<ellipse rx="5.6" ry="3.6" fill="#9fc4d8" opacity="0.3"/><ellipse cx="-1.6" cy="-1.2" rx="2" ry="0.7" fill="#ffffff" opacity="0.35"/>`) + PLN(C, [FX + 1.6, TY + 0.04, FZ + 4.2], [1, 0, 0], [0, 0, 1], `<ellipse rx="3.2" ry="1.6" fill="#9fc4d8" opacity="0.32"/><ellipse cx="-0.8" cy="-0.4" rx="1.2" ry="0.4" fill="#ffffff" opacity="0.4"/>${ripS(2.4, 4.4, 0.67, 1)}`);
      const rimX = `<rect width="49.2" height="35.2" fill="url(#k28br)"/><path d="${rrP(2.6, 2.6, 44, 30, 2.4)}" fill="none" stroke="#ffffff" stroke-opacity="0.45" stroke-width="0.5"/><path d="${rrP(0.6, 0.6, 48, 34, 3)}" fill="none" stroke="#000000" stroke-opacity="0.2" stroke-width="0.4"/>` + specks(rng('leak28r'), 26, 49.2, 35.2, ['#ffffff', '#e8e4d4'], 0.2, 0.5, 0.5);
      const rim = ringP(C, TY + 0.06, [BX0 - 2.6, BZ0 - 2.6, BX1 + 2.6, BZ1 + 2.6, 3.4], [[BX0, BZ0, BX1, BZ1, 2.4]], SS, rimX);
      const bsF = specks(rng('leak28b'), 50, 124, 7, ['#a8946a', '#f4ecd8'], 0.12, 0.3, 0.4) + `<path d="M0 6.5H124" stroke="#e8d890" stroke-width="1"/>` + rep(16, i => `<circle cx="${f1(4 + i * 7.6 + (i % 3))}" cy="6.4" r="0.3" fill="#3a3a20" opacity="0.5"/>`).join('') + rep(5, i => `<path d="M${f1(48 + i * 2.6)} ${f1(2 + (i % 2))}v${f1(1.4 + (i % 3) * 0.6)}" stroke="#8a7a5a" stroke-opacity="0.3" stroke-width="0.5" stroke-linecap="round"/>`).join('');
      const bs = box3(C, { c: [0, TY, -26], w: 124, h: 7, d: 2, r: 0.3, col: LM, olw: 0.35, dec: { f: bsF } });
      // basin: floor (44 x 30, drain at the middle), walls, the drip-catching mug
      const Rf = rng('leak28f');
      const flD = `<ellipse cx="22" cy="15" rx="9" ry="7" fill="#b06a2a" opacity="0.2" filter="url(#m10b2)"/><path d="M22 18Q23 24 21.4 30" stroke="#a8642e" stroke-opacity="0.3" stroke-width="1.4" fill="none" filter="url(#m10b1)"/>`
        + scr(Rf, 26, 2, 2, 40, 26, '#ffffff', 0.5) + scr(Rf, 12, 2, 2, 40, 26, '#4a4e52', 0.4) + rep(16, () => `<circle cx="${f1(2 + Rf() * 40)}" cy="${f1(2 + Rf() * 26)}" r="${f1(0.4 + Rf() * 0.8)}" fill="none" stroke="#ffffff" stroke-opacity="0.45" stroke-width="0.15"/>`).join('')
        + `<ellipse cx="25" cy="19" rx="6" ry="3.6" fill="#8ab0c0" opacity="0.25"/><ellipse cx="23.6" cy="18.2" rx="2.4" ry="0.8" fill="#ffffff" opacity="0.35"/>`
        + `<circle cx="22" cy="15" r="3.4" fill="#8a8f93"/><circle cx="22" cy="15" r="2.6" fill="#2a2b2c"/>` + rep(6, i => { const a = i * PI / 3; return `<path d="M${f1(22 + Math.cos(a) * 0.9)} ${f1(15 + Math.sin(a) * 0.9)}L${f1(22 + Math.cos(a) * 2.5)} ${f1(15 + Math.sin(a) * 2.5)}" stroke="#7a7e82" stroke-width="0.45"/>`; }).join('')
        + `<circle cx="22" cy="15" r="0.8" fill="#8a8f93"/><circle cx="22" cy="15" r="3.6" fill="none" stroke="#e8e2cc" stroke-opacity="0.55" stroke-width="0.5" stroke-dasharray="0.8 0.6"/><circle cx="27.4" cy="22" r="0.5" fill="#6a9a3a"/><ellipse cx="17" cy="21" rx="0.5" ry="0.25" fill="#f4ecd8"/><ellipse cx="18" cy="21.6" rx="0.5" ry="0.25" fill="#f4ecd8" transform="rotate(30 18 21.6)"/>`;
      const wd = (k, L, dp) => { const Rk = rng('leak28w' + k); return rep(10, () => `<circle cx="${f1(Rk() * L)}" cy="${f1(dp * 0.3 + Rk() * dp * 0.62)}" r="${f1(0.3 + Rk() * 0.5)}" fill="none" stroke="#ffffff" stroke-opacity="0.45" stroke-width="0.15"/>`).join('') + `<path d="M0 ${f1(dp - 1.6)}H${f1(L)}" stroke="#ece6d2" stroke-opacity="0.32" stroke-width="0.7"/>` + scr(Rk, 6, 0, 1, L, dp - 2, '#ffffff', 0.4); };
      const K0 = 0.72, KM = 0.81, K1 = 0.84, MH = 6.2, MW = Y0 + MH - 0.6;
      const mugL = `<g opacity="0.75"><text y="0.6" text-anchor="middle" ${FONT} font-size="1.5" fill="#8a5a1a">#1 DAD</text></g><path d="M0.4 ${f1(-MH / 2)}L1.2 ${f1(-MH / 2 + 0.9)}L2 ${f1(-MH / 2)}Z" fill="#f4ecd8"/>`;
      const mug = mug2(C, FX, Y0, SZ, 2.6, MH, '#f2c84a', '#a8b8b8', mugL, null, cr => ripS(cr * 0.95, T, K1, 2));
      const bas = basin(C, BX0, BX1, BZ0, BZ1, TY, DEP, SS, { floor: flD, wd, dk: 0.4 }) + mug + dropS(C, [FX, TY, SZ], [FX, MW, SZ], 0.5, T, KM, K1);
      // faucet
      const hd = (hx, cap) => { const arms = rep(4, i => { const a = PI / 4 + i * PI / 2, e = [hx + Math.cos(a) * 2.8, TY + 4.1, FZ + Math.sin(a) * 2.8]; return { q: e, s: cyl3(C, [hx, TY + 4.1, FZ], e, 0.42, CH, { mat: 'chrome', n: 10, olw: 0.2, noCap: 1 }) + sph(C, e, 0.72, CH) }; });
        return cyl3(C, [hx, TY + 1.2, FZ], [hx, TY + 3.6, FZ], 1.5, CH, { r2: 1.05, mat: 'chrome', n: 16, olw: 0.25 }) + vsort(C, arms.concat([{ q: [hx, TY + 4.1, FZ], s: cyl3(C, [hx, TY + 3.4, FZ], [hx, TY + 4.8, FZ], 1.05, CH, { mat: 'chrome', n: 14, olw: 0.25, cap }) }])); };
      const plT = specks(rng('leak28p'), 16, 21, 5.4, ['#f2f0e4', '#d8e8d0'], 0.2, 0.5, 0.7);
      const plate = box3(C, { c: [FX, TY, FZ], w: 21, h: 1.2, d: 5.4, r: 2.4, col: CH, gl: 0.6, olw: 0.3, dec: { t: plT } });
      const tail = H2(C, [FX + 1.2, TY + 4, FZ + 1.9], [FX + 2.4, TY + 1.8, FZ + 2.8], 1.1, '#8f9aa2') + H2(C, [FX + 0.4, TY + 4, FZ + 2.1], [FX + 0.6, TY + 2.2, FZ + 3.1], 0.9, '#7f8a92');
      const ragC = cyl3(C, [FX, TY + 1.2, FZ], [FX, TY + 5.4, FZ], 2.2, '#9aa5ac', { mat: 'matte', n: 18, olw: 0.3, olc: '#4a5258', cap: cr => `<circle r="${f1(cr * 0.66)}" fill="${CH}"/><path d="M${f1(-cr)} 0Q0 ${f1(cr * 0.3)} ${f1(cr)} 0" stroke="#6a767e" stroke-width="0.3" fill="none"/>` })
        + cyl3(C, [FX, TY + 3, FZ], [FX, TY + 4.1, FZ], 2.32, '#a9adb1', { mat: 'gloss', n: 18, olw: 0.25, noCap: 1 });
      const riser = (C.v[2] > 0 ? ragC + tail : tail + ragC) + cyl3(C, [FX, TY + 5.2, FZ], [FX, TY + 8.4, FZ], 1.45, CH, { mat: 'chrome', n: 18, olw: 0.25, noCap: 1 });
      const noz = cyl3(C, [FX, TY + 9.2, SZ], [FX, TY + 6.4, SZ], 1.2, CH, { mat: 'chrome', n: 16, olw: 0.25 }) + cyl3(C, [FX, TY + 6.5, SZ], [FX, TY + 5.8, SZ], 1.28, '#a4aaae', { mat: 'metal', n: 16, olw: 0.25, noCap: 1 }) + [[0.9, 0.2], [-0.7, 0.8], [0.2, -1]].map(([dx, dz]) => sph(C, [FX + dx, TY + 5.8, SZ + dz], 0.36, '#e8e4d2')).join('');
      const fau = plate + vsort(C, [{ q: [FX, TY + 4, FZ], s: riser }, { q: [FX, TY + 8.3, FZ], s: sph(C, [FX, TY + 8.3, FZ], 1.5, CH) }, { q: [FX, TY + 8.3, (FZ + SZ) / 2], s: cyl3(C, [FX, TY + 8.3, FZ + 0.6], [FX, TY + 8.3, SZ - 0.4], 1.0, CH, { mat: 'chrome', n: 14, olw: 0.22, noCap: 1 }) },
        { q: [FX, TY + 7, SZ], s: noz }, { q: [FX - 7.5, TY + 3, FZ], s: hd(FX - 7.5, cr => `<circle r="${f1(cr * 0.78)}" fill="#c84a3a"/><circle r="${f1(cr * 0.78)}" fill="url(#m10cap)"/>`) }, { q: [FX + 7.5, TY + 3, FZ], s: hd(FX + 7.5, cr => `<circle r="${f1(cr * 0.7)}" fill="#3a3c3e"/><circle r="${f1(cr * 0.3)}" fill="#8a8e92"/><path d="M-0.3 0H0.3" stroke="#2a2a2a" stroke-width="0.15"/>`) }]);
      // counter things
      const brush = H2(C, [-48, TY + 5, -16], [-46.6, TY + 13.2, -15.2], 0.9, '#f2803a') + H2(C, [-46.7, TY + 11.6, -15.3], [-46.5, TY + 13.4, -15.1], 1.3, '#e8f0f4');
      const cupT = cup(C, -48, TY, -16, 2.6, 7, '#7ab8d8', '#4a88a8');
      const paste = cyl3(C, [-43, TY + 1.15, -12], [-36.6, TY + 0.7, -10.6], 1.15, '#f4f2ee', { r2: 0.6, mat: 'gloss', n: 14, olw: 0.25 }) + cyl3(C, [-44.4, TY + 1.15, -12.3], [-43, TY + 1.15, -12], 0.8, '#d83a3a', { mat: 'gloss', n: 12, olw: 0.2 });
      const ball = vsort(C, [[-40, 1.5, 7, 1.7], [-38.4, 1.3, 8, 1.4], [-41.4, 1.2, 8.2, 1.3], [-39.6, 2.6, 7.8, 1.3], [-41, 2.4, 6.4, 1.1]].map(([x, y, z, r]) => ({ q: [x, TY + y, z], s: sph(C, [x, TY + y, z], r, '#f4f2ec') })));
      const soap = cyl3(C, [30, TY + 0.3, -16], [30, TY + 2.4, -16], 2.1, '#5ac85a', { mat: 'gloss', n: 18, olw: 0.2 }) + cyl3(C, [30, TY, -16], [30, TY + 9, -16], 2.4, '#bfe8c4', { mat: 'gloss', n: 18, op: 0.42, olw: 0.3, olc: '#4a8a4a', noCap: 1 })
        + cyl3(C, [30, TY + 9, -16], [30, TY + 10.4, -16], 2.4, '#bfe8c4', { r2: 1.2, mat: 'gloss', n: 18, op: 0.5, olw: 0.25, olc: '#4a8a4a', noCap: 1 }) + cyl3(C, [30, TY + 10.3, -16], [30, TY + 12, -16], 1.2, '#e83a3a', { mat: 'gloss', n: 14, olw: 0.25 })
        + `<g transform="${tanF(C, 30, -16, 2.45, C.thV, TY + 5.6)}"><rect x="-1.7" y="-1.9" width="3.4" height="3.4" fill="#f2e27a" opacity="0.8"/><text y="0.3" text-anchor="middle" ${FONT} font-size="0.8" fill="#3a7a2a">LEMMO</text><path d="M1.7 1.5L0.7 1.5L1.7 0.5Z" fill="#ffffff" opacity="0.7"/></g>`;
      const spg = box3(C, { c: [24, TY, 6], w: 7.4, h: 1.8, d: 4.6, r: 0.8, col: '#e8c84a', mat: 'foam', olw: 0.3, f: 0.92 }) + box3(C, { c: [24, TY + 1.8, 6], w: 7.4, h: 0.7, d: 4.6, r: 0.8, col: '#3a7a3a', olw: 0.3, dec: { t: `<path d="M5.6 0L7.4 0L7.4 1.8Z" fill="#e8c84a"/>` + specks(rng('leak28s'), 10, 7.4, 4.6, ['#d8a848', '#8a5a2a'], 0.15, 0.35, 0.8) } });
      const dentOK = Math.cos(0.6 - C.thV) > 0.25;
      const pot = cyl3(C, [46, TY, 1], [46, TY + 6.2, 1], 6.4, '#b4b8bc', { mat: 'metal', n: 28, olw: 0.35, cap: cr => `<circle r="${f1(cr * 0.94)}" fill="#5a5e62"/><circle r="${f1(cr * 0.86)}" fill="#d8a848" opacity="0.8"/>` + rep(9, i => `<ellipse cx="${f1(Math.cos(i * 2.1) * cr * 0.5)}" cy="${f1(Math.sin(i * 2.1) * cr * 0.45)}" rx="${f1(cr * 0.12)}" ry="${f1(cr * 0.06)}" fill="#e8b850" transform="rotate(${i * 40} ${f1(Math.cos(i * 2.1) * cr * 0.5)} ${f1(Math.sin(i * 2.1) * cr * 0.45)})"/>`).join('') + `<circle r="${f1(cr * 0.86)}" fill="none" stroke="#8a5a1a" stroke-opacity="0.5" stroke-width="0.6"/>` })
        + (dentOK ? `<g transform="${tanF(C, 46, 1, 6.45, 0.6, TY + 3.2)}">${dent(0, 0, 1.8, 1.2, 10, 1.3)}</g>` : '') + H2(C, [44.4, TY + 5.6, 0.4], [39.6, TY + 13, 5], 1.1, '#b88a52');
      const ph = stick(C, [52.4, TY + 5, 1], [60, TY + 5.6, 1], 0.75, '#1e1e1e');
      const potG = C.v[0] > 0 ? pot + ph : ph + pot;
      const items = vsort(C, [{ q: [FX, TY + 3, FZ], s: fau }, { q: [-48, TY + 4, -16], s: cupT + brush }, { q: [-39.7, TY + 1, -11.3], s: paste }, { q: [-40, TY + 1.5, 7], s: ball }, { q: [30, TY + 5, -16], s: soap }, { q: [24, TY + 1.5, 6], s: spg }, { q: [46, TY + 3, 1], s: potG }]);
      let s = shadow(C, 0, 0, 66, 32, 0.8) + bas + kick + cab + (fv ? fr : '') + slab + top + pud + rim + (fv ? bs + items : items + bs);
      s += hangD(C, [FX, TY + 5.7, SZ], 0.5, T, K0) + dropS(C, [FX, TY + 5.6, SZ], [FX, TY, SZ], 0.5, T, K0, KM);
      if (fv) s += dropS(C, [FX + 0.6, TY + 1.6, FZ + 2.3], [FX + 0.6, TY + 0.1, FZ + 2.6], 0.35, 4.4, 0.6, 0.66);
      C.p(0, TY + 16, 0);
      return { defs: DEFD, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-022 DOUBLE-BASIN DROP-IN SINK WITH PULL-OUT SPRAYER (T2): light oak base cabinet (raised-panel doors, two drawers + a false front, brushed nickel bar pulls
  // and knobs, a couple of scuffs), speckled faux-granite laminate top + backsplash, brushed stainless double bowl. Left bowl: soapy water over two plates and a
  // fork, suds drifting, bubbles popping; right bowl: an upside-down mug and a dish brush. Chrome pull-down faucet swung over the left bowl; every 10 s the
  // spray head rinses for ~2.5 s (fan of jets, ripples, suds swell) then drips. Blue-striped tea towel sways on the drawer pull. Counter: utensil crock, white
  // ceramic soap pump, sponge on a dish, drying mat with two upside-down glasses, potted rosemary swaying.
  N.dbl28 = S => { const TY = SKT, OK = '#d6ac74', LM = '#d3ccbf', SS = '#c3c8cc', CH = '#d5dbe0', NI = '#b9bdc1', L0 = -36, L1 = -6, R0 = -2, R1 = 24, BZ0 = -15, BZ1 = 15, DEP = 13, Y0 = TY - DEP, WY = TY - 6.5, FX = -4, FZ = -22, ZF = 25.6, T = 10;
    const D = { w: 124, d: 54, arch: 'counter', act: 'wash', use: { x: 0, z: 54 }, topH: TY, build: () => [] };
    const dir = [-0.6114, 0.7913], HX = FX + dir[0] * 13, HZ = FZ + dir[1] * 13, HB = TY + 8.2;
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), lf = lit(C, [0, 0, 1]);
      // cabinet front (u 0..122 from x -61, v 0..55 down from y 59)
      const pan = (x, y, w, h, i, rp) => { const Rg = rng('dbl28p' + i), b = 3.4; return `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="${shade(OK, lf * (i % 2 ? 1.03 : 0.98))}"/><g transform="translate(${f1(x)} ${f1(y)})">${grainV(Rg, w, h, Math.round(w / 2.4), '#9a6a34', '#f0cf98')}</g>`
        + (rp ? `<rect x="${f1(x + b)}" y="${f1(y + b)}" width="${f1(w - 2 * b)}" height="${f1(h - 2 * b)}" rx="0.8" fill="#ffffff" opacity="0.05"/><path d="M${f1(x + b)} ${f1(y + h - b)}V${f1(y + b)}H${f1(x + w - b)}" stroke="#ffffff" stroke-opacity="0.3" stroke-width="0.45" fill="none"/><path d="M${f1(x + b)} ${f1(y + h - b)}H${f1(x + w - b)}V${f1(y + b)}" stroke="#5a3a1a" stroke-opacity="0.35" stroke-width="0.45" fill="none"/>` : '')
        + `<path d="M${f1(x)} ${f1(y + h)}H${f1(x + w)}V${f1(y)}" stroke="#3a2414" stroke-opacity="0.45" stroke-width="0.4" fill="none"/><path d="M${f1(x)} ${f1(y + h)}V${f1(y)}H${f1(x + w)}" stroke="#ffffff" stroke-opacity="0.3" stroke-width="0.3" fill="none"/>`; };
      const cabF = `<rect width="122" height="55" fill="#4a2c14" opacity="0.35"/>` + [[2, 1.5, 38, 10], [42, 1.5, 38, 10], [84, 1.5, 36, 10]].map((p, i) => pan(...p, i, 0)).join('')
        + [[2, 13, 38, 40.5], [42, 13, 18.6, 40.5], [61.4, 13, 18.6, 40.5], [84, 13, 36, 40.5]].map((p, i) => pan(...p, i + 3, 1)).join('')
        + scr(rng('dbl28c'), 8, 44, 46, 34, 6, '#3a2414', 0.4) + `<path d="M118.6 53.5L120 52.2V53.5Z" fill="#c89a62"/>`;
      const cabS = `<g>${grainV(rng('dbl28sd'), 52.6, 55, 20, '#9a6a34', '#f0cf98')}</g>`;
      const kick = box3(C, { c: [0, 0, -2.5], w: 118, h: 4, d: 47, r: 0.3, col: '#3a2a1e', olw: 0.3, skip: { t: 1 } });
      const cab = box3(C, { c: [0, 4, -0.7], w: 122, h: TY - 7, d: 52.6, r: 0.4, col: OK, olw: 0.45, olo: 0.7, skip: { t: 1 }, dec: { f: cabF, l: cabS, r: cabS } });
      const towX = `<rect width="13" height="17" fill="url(#k28wv)"/>` + [[2.4, 0.5], [11.4, 1.2], [13.2, 0.5], [14.4, 0.5]].map(([y, h]) => `<rect y="${y}" width="13" height="${h}" fill="#3a6aa8" opacity="0.85"/>`).join('');
      const fr = vsort(C, [{ q: [-40, 52.5, ZF + 1.4], s: barH(C, -47, -33, 52.5, ZF, 2.6, 0.75, NI, 'metal', 1.6) }, { q: [41, 52.5, ZF + 1.4], s: barH(C, 34, 48, 52.5, ZF, 2.6, 0.75, NI, 'metal', 1.6) }].concat([-25, -3.4, 2.8, 27].map(x => ({ q: [x, 40, ZF + 1], s: knobB(C, x, 40, ZF, 1.3, NI, 'metal') }))))
        + PLN(C, [34.5, 53.4, ZF + 3.5], [1, 0, 0], [0, -1, 0], towS(13, 17, '#f4f1ea', towX, 5.8));
      // laminate slab + top (u 0..124 from x -62, v 0..55 from z -27)
      const GR = ['#5a5248', '#2a2620', '#f4f0ea', '#a08a78', '#8a7a6a'];
      const slab = box3(C, { c: [0, TY - 3, 0.5], w: 124, h: 3, d: 55, r: 1, col: LM, olw: 0.4, skip: { t: 1 }, dec: { f: specks(rng('dbl28e'), 60, 124, 3, GR, 0.1, 0.28, 0.6) + `<path d="M0 0.5H124" stroke="#ffffff" stroke-opacity="0.35" stroke-width="0.4"/>` } });
      const topD = specks(rng('dbl28t'), 460, 124, 55, GR, 0.12, 0.38, 0.55) + `<path d="M${f1(94.6)} 11.4A2.6 2.6 0 1 1 ${f1(99)} 10" stroke="#6a6258" stroke-opacity="0.16" stroke-width="0.4" fill="none"/>`;
      const top = ctopH(C, -62, 62, -27, 28, TY, LM, [[L0, BZ0, R1, BZ1, 2.6]], topD);
      const rimX = `<rect width="66" height="36" fill="url(#k28br)"/>` + [[3, 3, 30, 30], [37, 3, 26, 30]].map(([x, y, w, h]) => `<path d="${rrP(x, y, w, h, 2.6)}" fill="none" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.5"/>`).join('') + `<path d="${rrP(0.6, 0.6, 64.8, 34.8, 3)}" fill="none" stroke="#000000" stroke-opacity="0.18" stroke-width="0.4"/>`;
      const rim = ringP(C, TY + 0.06, [L0 - 3, BZ0 - 3, R1 + 3, BZ1 + 3, 3.4], [[L0, BZ0, L1, BZ1, 2.6], [R0, BZ0, R1, BZ1, 2.6]], SS, rimX);
      const bs = box3(C, { c: [0, TY, -26], w: 124, h: 6, d: 2, r: 0.3, col: LM, olw: 0.35, dec: { f: specks(rng('dbl28b'), 110, 124, 6, GR, 0.12, 0.34, 0.55) + `<path d="M0 5.6H124" stroke="#f4f0e8" stroke-width="0.7"/>` } });
      // basins
      const drn = (cx, cy) => `<circle cx="${cx}" cy="${cy}" r="3.4" fill="#9aa0a4"/><circle cx="${cx}" cy="${cy}" r="2.7" fill="#c8ccd0"/>` + rep(8, i => `<circle cx="${f1(cx + Math.cos(i * PI / 4) * 1.6)}" cy="${f1(cy + Math.sin(i * PI / 4) * 1.6)}" r="0.32" fill="#3a3c3e"/>`).join('') + `<circle cx="${cx}" cy="${cy}" r="0.5" fill="#3a3c3e"/>`;
      const wd = (k, L, dp) => `<rect width="${f1(L)}" height="${f1(dp)}" fill="url(#k28br)" opacity="0.7"/>` + `<path d="M0 0.6H${f1(L)}" stroke="#ffffff" stroke-opacity="0.35" stroke-width="0.4"/>`;
      const lb = basin(C, L0, L1, BZ0, BZ1, TY, DEP, SS, { floor: `<rect width="30" height="30" fill="url(#k28br)"/>` + drn(15, 15), wd, dk: 0.36 });
      const rb = basin(C, R0, R1, BZ0, BZ1, TY, DEP, SS, { floor: `<rect width="26" height="30" fill="url(#k28br)"/>` + drn(13, 15) + `<ellipse cx="9" cy="20" rx="4" ry="2.4" fill="#a8c8d8" opacity="0.25"/>`, wd, dk: 0.36 });
      const plates = vsort(C, [{ q: [-24, Y0, 2], s: plateF(C, -24, Y0, 2, 8.4, '#f4f2ee', 1, 0) }, { q: [-15.6, Y0 + 0.9, -5], s: plateF(C, -15.6, Y0 + 0.9, -5, 7.2, '#e8eef4', 1, 1, '#4a6a9a') }]) + H2(C, [-30, Y0 + 1.1, 9], [-21, Y0 + 1.3, 11.6], 0.5, '#c8ccd0');
      const fm = rep(26, i => { const a = i * 2.39996, rr = 9 + (i % 5) * 1.3, x = 15 + Math.cos(a) * rr * 0.95, y = 15 + Math.sin(a) * rr * 0.95, r = 1.2 + (i % 4) * 0.55; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="#ffffff" opacity="0.88"/><circle cx="${f1(x - r * 0.3)}" cy="${f1(y - r * 0.35)}" r="${f1(r * 0.32)}" fill="#eef8ff"/>`; }).join('');
      const pops = rep(6, i => { const x = 6 + ((i * 0.618) % 1) * 18, y = 6 + ((i * 0.41) % 1) * 18, d = 2.6 + (i % 3) * 0.7; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.2" fill="#ffffff" fill-opacity="0.25" stroke="#ffffff" stroke-width="0.15">${an('r', '0.2;1;1.1;0.2', d, -i * 0.9, KT('0;0.7;0.72;1'))}${an('opacity', '0.9;0.9;0;0', d, -i * 0.9, KT('0;0.7;0.72;1'))}</circle>`; }).join('');
      const spX = HX - L0, spZ = HZ + 1 - BZ0, on = KT('0;0.12;0.14;0.38;0.41;1');
      const water = PLN(C, [L0, WY, BZ0], [1, 0, 0], [0, 0, 1], `<rect width="30" height="30" rx="2.6" fill="#d6e6e8" opacity="0.55"/><g>${at('translate', '0 0;0.7 0.4;-0.4 0.2;0 0', 7, 0, SPL(3))}<g>${at('scale', '1;1;1.06;1.06;1;1', T, 0, KT('0;0.14;0.24;0.38;0.6;1'))}${fm}</g></g>${pops}`
        + `<g transform="translate(${f1(spX)} ${f1(spZ)})"><g opacity="0">${an('opacity', '0;0;1;1;0;0', T, 0, on)}${rep(3, i => `<circle r="0.3" fill="none" stroke="#ffffff" stroke-width="0.25">${an('r', '0.3;4.6', 0.7, -i * 0.23)}${an('opacity', '0.9;0', 0.7, -i * 0.23)}</circle>`).join('')}<circle r="2.6" fill="#ffffff" opacity="0.4"/></g></g>`
        + `<path d="M3 4Q9 2 14 4" stroke="#ffffff" stroke-opacity="0.4" stroke-width="0.4" fill="none"/>`);
      // spray: jets from the head down to the water, split at the rim
      const jets = (top) => rep(9, i => { const a = i * 2 * PI / 9, e = [HX + Math.cos(a) * 3.6, WY, HZ + 1 + Math.sin(a) * 3.2], s0 = [HX + Math.cos(a) * 1.1, HB, HZ + Math.sin(a) * 1.1], t = (HB - TY) / (HB - WY), m = add(s0, mul(sub3(e, s0), t)), A = top ? s0 : m, B = top ? m : e, p = C.P(A), q = C.P(B), L = 1.6 * C.k;
        return `<path d="M${P2(p)}L${P2(q)}" stroke="#eaf6fc" stroke-opacity="0.75" stroke-width="${f1(0.28 * C.k)}" stroke-dasharray="${f1(L * 0.5)} ${f1(L * 0.5)}" stroke-linecap="round">${an('stroke-dashoffset', `0;${f1(-L * 2)}`, 0.3, -i * 0.05)}</path>`; }).join('');
      const jg = top => `<g opacity="0">${an('opacity', '0;0;1;1;0;0', T, 0, on)}${jets(top)}</g>`;
      const brushR = cyl3(C, [2, Y0 + 1, -8], [11, Y0 + 1.3, -1], 0.75, '#c89a5a', { mat: 'gloss', n: 12, olw: 0.25 }) + cyl3(C, [11, Y0 + 1.6, -1], [13.4, Y0 + 1.8, 0.8], 2, '#eee6d0', { mat: 'matte', n: 16, olw: 0.25, cap: cr => rep(7, i => `<circle cx="${f1(Math.cos(i) * cr * 0.5)}" cy="${f1(Math.sin(i * 1.3) * cr * 0.5)}" r="0.3" fill="#a89a7a"/>`).join('') });
      const rIn = vsort(C, [{ q: [16, Y0 + 3, 6], s: mugH(C, 16, Y0, 6, 2.7, 6.2, '#e8a84a', 1) }, { q: [7, Y0 + 1, -4], s: brushR }]);
      const bas = lb + plates + water + jg(0) + rb + rIn;
      // faucet (chrome pull-down, head over the left bowl)
      const arc = pipe(C, [[FX, TY + 12, FZ]].concat(arcP(FX, TY + 13, FZ, dir, 6.5, 0, 12)), 1.25, CH);
      const head = cyl3(C, [HX, TY + 13.8, HZ], [HX, HB, HZ], 1.75, CH, { r2: 1.6, mat: 'chrome', n: 18, olw: 0.28 }) + cyl3(C, [HX, TY + 9.6, HZ], [HX, TY + 10.1, HZ], 1.78, '#2a2c2e', { mat: 'gloss', n: 18, olw: 0.2, noCap: 1 });
      const lever = cyl3(C, [FX + 1.7, TY + 9.5, FZ], [FX + 2.8, TY + 9.5, FZ], 1, CH, { mat: 'chrome', n: 12, olw: 0.22 }) + cyl3(C, [FX + 2.6, TY + 9.7, FZ], [FX + 6.6, TY + 11.4, FZ], 0.42, CH, { r2: 0.62, mat: 'chrome', n: 10, olw: 0.2 });
      const body = cyl3(C, [FX, TY, FZ], [FX, TY + 0.9, FZ], 2.9, CH, { mat: 'chrome', n: 22, olw: 0.3 }) + cyl3(C, [FX, TY + 0.9, FZ], [FX, TY + 12.2, FZ], 1.9, CH, { mat: 'chrome', n: 20, olw: 0.3, noCap: 1 });
      const fau = vsort(C, [{ q: [FX, TY + 4, FZ], s: C.v[0] > 0 ? body + lever : lever + body }, ...arc, { q: [HX, TY + 11, HZ], s: head }]);
      // counter things
      const crock = cyl3(C, [-50, TY, -16], [-50, TY + 8, -16], 3.2, '#4a78b0', { r2: 3.5, mat: 'gloss', n: 22, olw: 0.3, capCol: '#22344a' }) + vsort(C, [
        { q: [-52, TY + 12, -17], s: H2(C, [-51, TY + 7, -16.5], [-53.4, TY + 17, -18], 0.9, '#c8945a') + sph(C, [-53.6, TY + 18.2, -18.1], 1.4, '#c8945a') },
        { q: [-48.6, TY + 12, -15], s: H2(C, [-49.4, TY + 7, -15.4], [-48.2, TY + 16, -15], 0.8, '#2a2a2c') + H2(C, [-48.2, TY + 15.6, -15], [-47.8, TY + 19.6, -14.8], 2.6, '#2a2a2c') },
        { q: [-50.4, TY + 12, -14], s: H2(C, [-50, TY + 7, -15], [-50.8, TY + 18.4, -14], 0.7, '#c0c6ca') + sph(C, [-50.9, TY + 19.4, -14], 1.5, '#c0c6ca') }]);
      const pump = cyl3(C, [36, TY, -19], [36, TY + 7, -19], 2.4, '#f4f1ea', { mat: 'gloss', n: 20, olw: 0.3 }) + cyl3(C, [36, TY + 7, -19], [36, TY + 7.8, -19], 1.3, CH, { mat: 'chrome', n: 14, olw: 0.2 }) + cyl3(C, [36, TY + 7.8, -19], [36, TY + 10, -19], 0.45, CH, { mat: 'chrome', n: 10, olw: 0.2 })
        + (C.v[2] > 0 ? '' : stick(C, [36, TY + 10.2, -19], [36, TY + 10.2, -16.2], 0.6, CH, 'chrome')) + cyl3(C, [36, TY + 9.8, -19], [36, TY + 10.8, -19], 1, CH, { mat: 'chrome', n: 12, olw: 0.2 }) + (C.v[2] > 0 ? stick(C, [36, TY + 10.2, -19], [36, TY + 10.2, -16.2], 0.6, CH, 'chrome') : '');
      const rose = cyl3(C, [52, TY, -18], [52, TY + 6, -18], 3.4, '#c8683a', { r2: 4, mat: 'matte', n: 20, olw: 0.3, capCol: '#4a3020' }) + sway(C, [52, TY + 6, -18], vsort(C, [[-1.6, -0.6, 0.6], [0.4, 0.8, 0.9], [1.8, 0.2, 0.7], [-0.4, -1.4, 1], [1, -1, 0.8], [-1.2, 1.2, 0.7], [0, 0, 1.1]].map(([dx, dz, s]) => { const b = [52 + dx * 0.6, TY + 6, -18 + dz * 0.6], t = [52 + dx * 1.8, TY + 6 + 9 * s, -18 + dz * 1.8];
        return { q: t, s: H2(C, b, t, 0.35, '#6a5a3a') + rep(5, k => { const f = 0.3 + k * 0.16; return sph(C, [b[0] + (t[0] - b[0]) * f, b[1] + (t[1] - b[1]) * f, b[2] + (t[2] - b[2]) * f], 0.6 - k * 0.05, k % 2 ? '#4a6a48' : '#5a7a52'); }).join('') }; })), 2, 6.2);
      const sdish = cyl3(C, [30, TY, 6], [30, TY + 0.8, 6], 3.8, '#f4f1ea', { r2: 4.2, mat: 'gloss', n: 22, olw: 0.3 }) + box3(C, { c: [30, TY + 0.8, 6], w: 6.4, h: 1.6, d: 4, r: 0.8, col: '#f2d24a', mat: 'foam', olw: 0.3 }) + box3(C, { c: [30, TY + 2.4, 6], w: 6.4, h: 0.6, d: 4, r: 0.8, col: '#3a7ab8', olw: 0.3 });
      const mat = PLN(C, [40, TY + 0.05, -3], [1, 0, 0], [0, 0, 1], `<rect width="16" height="13" rx="1.2" fill="${shade('#7aa0b8', lit(C, [0, 1, 0]))}"/>` + rep(7, i => `<path d="M${f1(1.6 + i * 2.1)} 1V12" stroke="#ffffff" stroke-opacity="0.25" stroke-width="0.4"/>`).join('') + `<ellipse cx="5" cy="8" rx="1.4" ry="0.8" fill="#ffffff" opacity="0.35"/><ellipse cx="11" cy="4" rx="1" ry="0.6" fill="#ffffff" opacity="0.3"/>`);
      const gl2 = (x, z) => cyl3(C, [x, TY + 0.1, z], [x, TY + 6.2, z], 2, '#dff0f4', { r2: 1.7, mat: 'chrome', n: 18, op: 0.42, olw: 0.3, olc: '#7a9aa4' });
      const items = vsort(C, [{ q: [FX, TY + 6, FZ + 4], s: fau }, { q: [-50, TY + 6, -16], s: crock }, { q: [36, TY + 5, -19], s: pump }, { q: [52, TY + 6, -18], s: rose }, { q: [30, TY + 1.5, 6], s: sdish }, { q: [44, TY + 3, 2], s: gl2(44, 2) }, { q: [51, TY + 3, 6], s: gl2(51, 6) }]);
      let s = shadow(C, 0, 0, 66, 32, 0.8) + bas + kick + cab + (fv ? fr : '') + slab + top + mat + rim + (fv ? bs + items : items + bs) + jg(1);
      s += dropS(C, [HX + 0.4, HB, HZ], [HX + 0.4, TY, HZ], 0.45, T, 0.5, 0.53) + dropS(C, [HX + 0.4, TY, HZ], [HX + 0.4, WY, HZ], 0.45, T, 0.53, 0.55);
      C.p(0, TY + 22, 0);
      return { defs: DEFD, front: s, bb: C.bb(6) }; };
    return D; };
  const sub3 = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];

  // KIT-042 DEEP WHITE FIRECLAY FARMHOUSE APRON SINK & GOOSENECK FAUCET (T3): sage-green shaker base cabinets (two drawers + doors, two doors under the apron,
  // matte black cup pulls + knobs), an oiled oak butcher-block top (staves with finger joints, end grain on the sides), a deep glossy white fireclay sink whose
  // apron stands proud of the cabinet front. Tall matte black gooseneck with a side lever runs a thin steady stream over a navy-rimmed enamel colander of cherry
  // tomatoes and radishes (splashes, wet sheen). Always: the stream runs, droplets bounce, a sunlight glint slides across the apron every 8 s, a cream linen
  // towel sways on the drawer pull, the basil sways. Counter: amber glass soap pump, basil in a white pot, an oak board with a halved lemon, a lemon + paring knife.
  N.apron28 = S => { const TY = SKT, SG = '#9db09a', OAK = '#c8975e', FC = '#f6f4ef', MB = '#2c2c2f', SX0 = -24, SX1 = 24, SZ0 = -18, SZF = 28.6, IX0 = -21.6, IX1 = 21.6, IZ0 = -15.6, IZ1 = 26.2, DEP = 20, Y0 = TY - DEP, AY = TY - 24, FZ = -22.5, ZF = 27, T = 8, CZ = -5.5;
    const D = { w: 124, d: 54, arch: 'counter', act: 'wash', use: { x: 0, z: 54 }, topH: TY, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), lt = lit(C, [0, 1, 0]);
      // cabinet front (u 0..124 from x -62, v 0..55 down from y 59)
      const shk = (x, y, w, h) => { const b = Math.min(4.2, w * 0.16); return `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="none" stroke="#000000" stroke-opacity="0.38" stroke-width="0.45"/><path d="M${f1(x + 0.3)} ${f1(y + h)}V${f1(y + 0.3)}H${f1(x + w)}" stroke="#ffffff" stroke-opacity="0.22" stroke-width="0.35" fill="none"/>`
        + `<rect x="${f1(x + b)}" y="${f1(y + b)}" width="${f1(w - 2 * b)}" height="${f1(h - 2 * b)}" fill="#000000" opacity="0.05"/><path d="M${f1(x + b)} ${f1(y + h - b)}V${f1(y + b)}H${f1(x + w - b)}" stroke="#000000" stroke-opacity="0.28" stroke-width="0.55" fill="none"/><path d="M${f1(x + b)} ${f1(y + h - b)}H${f1(x + w - b)}V${f1(y + b)}" stroke="#ffffff" stroke-opacity="0.3" stroke-width="0.45" fill="none"/>`; };
      const cabF = [[1, 1, 36, 11], [1, 13, 36, 41], [38.4, 22.6, 23, 31.4], [62.6, 22.6, 23, 31.4], [87, 1, 36, 11], [87, 13, 36, 41]].map(p => shk(...p)).join('') + `<rect x="37.6" y="0" width="48.8" height="22" fill="#000000" opacity="0.18"/>`;
      const kick = box3(C, { c: [0, 0, -2.5], w: 120, h: 4, d: 49, r: 0.3, col: '#262624', olw: 0.3, skip: { t: 1 } });
      const cab = box3(C, { c: [0, 4, 0], w: 124, h: TY - 7, d: 54, r: 0.4, col: SG, olw: 0.45, olo: 0.7, skip: { t: 1 }, dec: { f: cabF } });
      const cupP = x => cyl3(C, [x - 3, 52.6, ZF + 0.9], [x + 3, 52.6, ZF + 0.9], 0.9, MB, { mat: 'matte', n: 14, olw: 0.2 }) + [x - 3.2, x + 3.2].map(xx => box3(C, { c: [xx, 52, ZF + 0.6], w: 1.2, h: 1.6, d: 1.2, r: 0.3, col: MB, olw: 0.2 })).join('');
      const towX = `<rect width="12" height="17" fill="url(#k28wv)" opacity="0.6"/>` + [[1.6, 0.4], [2.4, 0.4], [13.6, 0.4], [14.4, 0.4]].map(([y, h]) => `<rect y="${y}" width="12" height="${h}" fill="#4a5f8a" opacity="0.8"/>`).join('') + rep(12, i => `<path d="M${f1(0.5 + i)} ${f1(16.8 + (i % 2) * 0.2)}v0.9" stroke="#e6dccb" stroke-width="0.25"/>`).join('');
      const fr = vsort(C, [{ q: [-43, 52.6, ZF], s: cupP(-43) }, { q: [43, 52.6, ZF], s: cupP(43) }].concat([[-29, 41], [29, 41], [-3.6, 32], [4.6, 32]].map(([x, y]) => ({ q: [x, y, ZF + 1], s: knobB(C, x, y, ZF, 1.2, MB, 'matte') }))))
        + PLN(C, [-49, 53.4, ZF + 2], [1, 0, 0], [0, -1, 0], towS(12, 17, '#efe8da', towX, 6));
      // butcher block: staves along x; slab edges in three pieces round the sink block
      const Rb = rng('apron28b'), sv = [];
      for (let v = 0, k = 0; v < 55; v += 3.6, k++) { let u = -Rb() * 30; while (u < 124) { const L = 26 + Rb() * 40; sv.push([u, v, L, 0.9 + Rb() * 0.2]); u += L; } }
      const topD = sv.map(([u, v, L, f]) => `<rect x="${f1(u)}" y="${f1(v)}" width="${f1(L)}" height="3.6" fill="${shade(OAK, lt * f)}"/><path d="M${f1(u)} ${f1(v + 1.2 + Rb() * 1.2)}Q${f1(u + L / 2)} ${f1(v + 0.6 + Rb() * 2.4)} ${f1(u + L)} ${f1(v + 1.4 + Rb())}" stroke="#7a4a22" stroke-opacity="0.22" stroke-width="0.25" fill="none"/><path d="M${f1(u)} ${f1(v)}V${f1(v + 3.6)}" stroke="#5a3418" stroke-opacity="0.35" stroke-width="0.25"/>`).join('')
        + rep(16, i => `<path d="M0 ${f1(i * 3.6)}H124" stroke="#5a3418" stroke-opacity="0.18" stroke-width="0.2"/>`).join('') + `<rect width="124" height="55" fill="url(#m10s)" opacity="0.5"/>` + scr(Rb, 12, 96, 30, 22, 16, '#5a3418', 0.4) + `<circle cx="94" cy="5" r="2.6" fill="none" stroke="#5a3418" stroke-opacity="0.14" stroke-width="0.6"/>`;
      const edF = L => rep(4, i => `<path d="M0 ${f1(0.6 + i * 0.6)}Q${f1(L / 2)} ${f1(0.3 + i * 0.7)} ${f1(L)} ${f1(0.7 + i * 0.6)}" stroke="#7a4a22" stroke-opacity="0.25" stroke-width="0.2" fill="none"/>`).join('');
      const edS = rep(16, i => `<rect x="${f1(i * 3.6)}" width="3.6" height="3" fill="#000000" opacity="${i % 2 ? 0.04 : 0.1}"/><path d="M${f1(i * 3.6 + 0.6)} 3Q${f1(i * 3.6 + 1.8)} 0.6 ${f1(i * 3.6 + 3)} 3" stroke="#5a3418" stroke-opacity="0.3" stroke-width="0.2" fill="none"/>`).join('');
      const slab = box3(C, { c: [-43, TY - 3, 0.5], w: 38, h: 3, d: 55, r: 0.3, col: OAK, olw: 0.35, skip: { t: 1, r: 1 }, dec: { f: edF(38), l: edS, b: edF(38) } }) + box3(C, { c: [43, TY - 3, 0.5], w: 38, h: 3, d: 55, r: 0.3, col: OAK, olw: 0.35, skip: { t: 1, l: 1 }, dec: { f: edF(38), r: edS, b: edF(38) } })
        + box3(C, { c: [0, TY - 3, -22.5], w: 48, h: 3, d: 9, r: 0, col: OAK, olw: 0.35, skip: { t: 1, f: 1, l: 1, r: 1 }, dec: { b: edF(48) } });
      const top = ctopH(C, -62, 62, -27, 28, TY, OAK, [[SX0, SZ0, SX1, 29, 0]], topD);
      const ringX = `<path d="${rrP(2.4, 2.4, 43.2, 41.8, 3.2)}" fill="none" stroke="#ffffff" stroke-opacity="0.9" stroke-width="0.6"/><path d="M4 1.2H44" stroke="#ffffff" stroke-opacity="0.8" stroke-width="0.5"/><path d="${rrP(0.2, 0.2, 47.6, 46.2, 2.2)}" fill="none" stroke="#000000" stroke-opacity="0.12" stroke-width="0.4"/>`;
      const ring = ringP(C, TY + 0.03, [SX0, SZ0, SX1, SZF, 2.2], [[IX0, IZ0, IX1, IZ1, 3.2]], '#fffefb', ringX);
      const gid = C.u('ap');
      const apF = `<clipPath id="${gid}"><rect width="48" height="24"/></clipPath><g clip-path="url(#${gid})"><rect x="6" width="6" height="24" fill="#ffffff" opacity="0.18"/><rect x="14" width="2" height="24" fill="#ffffff" opacity="0.12"/><path d="M0 23.4H48" stroke="#8a867c" stroke-opacity="0.3" stroke-width="0.6"/>`
        + `<path d="M-14 0H-8L-16 24H-22Z" fill="#ffffff" opacity="0.4">${at('translate', '0 0;0 0;84 0;84 0', T, 0, KT('0;0.62;0.86;1'))}</path></g>`;
      const apron = box3(C, { c: [0, AY, 27.8], w: 48, h: 24, d: 1.6, r: 0.6, col: FC, gl: 0.8, f: 1.1, olw: 0.35, olc: '#a8a49a', skip: { t: 1 }, dec: { f: apF } });
      // basin: deep glossy fireclay, drain forward of the colander, wet sheen
      const flD = `<ellipse cx="21.6" cy="12" rx="13" ry="10" fill="#b8c8d0" opacity="0.18" filter="url(#m10b2)"/><circle cx="21.6" cy="31" r="3.4" fill="#2c2c2f"/><circle cx="21.6" cy="31" r="2.6" fill="#3e3e42"/>` + rep(8, i => `<circle cx="${f1(21.6 + Math.cos(i * PI / 4) * 1.5)}" cy="${f1(31 + Math.sin(i * PI / 4) * 1.5)}" r="0.3" fill="#141416"/>`).join('') + `<path d="M15 33Q21 36 28 33" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.4" fill="none"/><ellipse cx="14" cy="24" rx="3" ry="1.4" fill="#ffffff" opacity="0.35"/>`;
      const wd = (k, L, dp) => `<path d="M${f1(L * 0.08)} 1.2H${f1(L * 0.92)}" stroke="#ffffff" stroke-opacity="0.8" stroke-width="0.5"/><rect x="${f1(L * 0.18)}" y="2" width="${f1(L * 0.08)}" height="${f1(dp - 4)}" fill="#ffffff" opacity="0.22"/><rect width="${f1(L)}" height="${f1(dp)}" fill="url(#m10s)" opacity="0.5"/>`;
      const bas0 = basin(C, IX0, IX1, IZ0, IZ1, TY, DEP, FC, { floor: flD, wd, dk: 0.14, f: 1.12 });
      const col = cyl3(C, [0, Y0, CZ], [0, Y0 + 1, CZ], 5, '#fbfaf6', { mat: 'gloss', n: 22, olw: 0.25 }) + cyl3(C, [0, Y0 + 1, CZ], [0, Y0 + 7.4, CZ], 6.4, '#fbfaf6', { r2: 9, mat: 'gloss', n: 28, olw: 0.3, pat: 'm10perf', capCol: '#e4e0d8' })
        + cyl3(C, [0, Y0 + 7.2, CZ], [0, Y0 + 7.9, CZ], 9.3, '#2a3a5e', { mat: 'gloss', n: 28, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.96)}" fill="#e4e0d8"/><circle r="${f1(cr * 0.9)}" fill="#cfcac0"/>` })
        + [-1, 1].map(sg => sph(C, [sg * 9.8, Y0 + 7.4, CZ], 1, '#2a3a5e')).join('');
      const PR = [[0, 0, 2, '#d8382a'], [-3.6, -1.6, 1.9, '#e0402e'], [3.4, -2, 1.9, '#d8382a'], [-2, 3, 1.8, '#c83a5a'], [2.6, 2.8, 1.9, '#e0402e'], [-5.4, 1.6, 1.7, '#d8382a'], [5.4, 0.8, 1.7, '#c83a5a'], [0.4, -4.6, 1.8, '#e0402e'], [-0.8, 5, 1.6, '#d8382a'], [0.8, 1.6, 1.6, '#e64a30', 1]];
      const prod = vsort(C, PR.map(([dx, dz, r, c, up]) => { const q = [dx, Y0 + 7.4 + r * 0.7 + (up ? 1.6 : 0), CZ + dz]; return { q, s: sph(C, q, r, c) + (c === '#c83a5a' ? H2(C, [q[0], q[1] + r * 0.8, q[2]], [q[0] + 0.6, q[1] + r + 1.4, q[2] - 0.4], 0.35, '#5a8a3a') : `<path d="M${P2(C.P([q[0] - 0.5, q[1] + r * 0.92, q[2]]))}L${P2(C.P([q[0] + 0.5, q[1] + r * 0.92, q[2]]))}" stroke="#4a7a2a" stroke-width="${f1(0.3 * C.k)}"/>`) }; }));
      const HIT = [0, Y0 + 10.6, CZ - 0.3], NZ = [0, TY + 14.4, CZ - 0.26];
      const splash = (() => { const p = C.P(HIT); return `<g transform="translate(${P2(p)}) scale(${n4(C.k)})">` + rep(5, i => { const dx = [-1.6, 1.4, -0.6, 2, -2.2][i], dy = [-2.2, -1.8, -2.8, -1.2, -1.4][i], d = 0.6 + (i % 3) * 0.12, b = -i * 0.17;
        return `<circle r="0.3" fill="#e8f6fc" opacity="0">${at('translate', `0 0;${f1(dx * 0.6)} ${f1(dy)};${f1(dx)} 0.6`, d, b)}${an('opacity', '0.9;0.7;0', d, b)}</circle>`; }).join('') + `<ellipse rx="1.6" ry="0.7" fill="#ffffff" opacity="0.5">${an('rx', '1.2;1.9;1.2', 0.5)}</ellipse></g>`; })();
      const bas = bas0 + col + prod + strm(C, [0, TY, NZ[2]], HIT, 1.05) + splash;
      // faucet (matte black gooseneck + side lever)
      const gn = pipe(C, arcP(0, TY + 18, FZ, [0, 1], 8.5, -0.25, 14), 1.15, MB, 'matte'), tip = gn.length ? arcP(0, TY + 18, FZ, [0, 1], 8.5, -0.25, 14)[14] : [0, TY + 16, CZ];
      const noz = cyl3(C, tip, [tip[0], TY + 14.4, tip[2]], 1.3, MB, { mat: 'matte', n: 16, olw: 0.25 });
      const riser = cyl3(C, [0, TY, FZ], [0, TY + 0.8, FZ], 2.8, MB, { mat: 'matte', n: 22, olw: 0.3 }) + cyl3(C, [0, TY + 0.8, FZ], [0, TY + 18.2, FZ], 1.5, MB, { mat: 'matte', n: 18, olw: 0.3, noCap: 1 });
      const lev = cyl3(C, [1.4, TY + 6, FZ], [2.6, TY + 6, FZ], 1.1, MB, { mat: 'matte', n: 14, olw: 0.22 }) + cyl3(C, [2.5, TY + 6.2, FZ], [7, TY + 7.4, FZ], 0.45, MB, { r2: 0.55, mat: 'matte', n: 10, olw: 0.2 });
      const fau = vsort(C, [{ q: [0, TY + 8, FZ], s: C.v[0] > 0 ? riser + lev : lev + riser }, ...gn, { q: [0, TY + 15, tip[2]], s: noz }, { q: [0, TY + 7, NZ[2]], s: strm(C, NZ, [0, TY, NZ[2]], 1.05) }]);
      // counter things
      const pump = cyl3(C, [32, TY, -22], [32, TY + 7.6, -22], 2.3, '#b8661e', { mat: 'gloss', n: 20, op: 0.88, olw: 0.3, noCap: 1 }) + cyl3(C, [32, TY + 7.6, -22], [32, TY + 8.8, -22], 2.3, '#b8661e', { r2: 1.2, mat: 'gloss', n: 20, op: 0.9, olw: 0.25, noCap: 1 })
        + cyl3(C, [32, TY + 8.6, -22], [32, TY + 9.6, -22], 1.25, MB, { mat: 'matte', n: 14, olw: 0.2 }) + cyl3(C, [32, TY + 9.6, -22], [32, TY + 11.4, -22], 0.42, MB, { mat: 'matte', n: 10, olw: 0.2 }) + cyl3(C, [32, TY + 11.2, -22], [32, TY + 12.2, -22], 0.95, MB, { mat: 'matte', n: 12, olw: 0.2 })
        + stick(C, [32, TY + 11.8, -22], [32, TY + 11.6, -19.2], 0.5, MB, 'matte') + `<g transform="${tanF(C, 32, -22, 2.33, C.thV, TY + 4.2)}"><rect x="-1.5" y="-1.3" width="3" height="2.6" fill="#f2ece0" opacity="0.9"/><text y="0.4" text-anchor="middle" font-family="Georgia,serif" font-size="0.75" fill="#3a2a1a">savon</text></g>`;
      const basil = cyl3(C, [-36, TY, -21], [-36, TY + 6.4, -21], 3.8, '#f2efe8', { r2: 4.2, mat: 'matte', n: 22, olw: 0.3, capCol: '#4a3424' }) + sway(C, [-36, TY + 6.4, -21], vsort(C, [[-1.8, 9, -0.6, 2.6], [1.8, 8.6, 0.4, 2.4], [0, 11.4, -0.4, 2.4], [-0.6, 8.2, 2, 2.2], [1.4, 11.8, -1.4, 1.8], [-2.2, 11, 1, 1.8], [0.6, 13.6, 0.4, 1.6]].map(([dx, y, dz, r], i) => ({ q: [-36 + dx, TY + y, -21 + dz], s: sph(C, [-36 + dx, TY + y, -21 + dz], r, i % 2 ? '#5aaa44' : '#4a9a3a') }))), 2.2, 5.2);
      const board = box3(C, { c: [45, TY, 4], w: 20, h: 1.6, d: 13, r: 2, col: '#a8743e', olw: 0.3, dec: { t: grainH(rng('apron28g'), 20, 13, 9, '#6a4220') + `<circle cx="17" cy="6.5" r="1" fill="#5a3418" opacity="0.6"/><ellipse cx="6" cy="9" rx="2.6" ry="1.2" fill="#f2e27a" opacity="0.18"/>` } });
      const lemH = cyl3(C, [40, TY + 1.6, 6], [40, TY + 3.6, 6], 2.6, '#f2d23a', { mat: 'gloss', n: 22, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#fff4b8"/>` + rep(8, i => `<path d="M0 0L${f1(Math.cos(i * PI / 4) * cr * 0.84)} ${f1(Math.sin(i * PI / 4) * cr * 0.84)}" stroke="#f8f0d0" stroke-width="0.3"/>`).join('') + `<circle r="${f1(cr * 0.86)}" fill="none" stroke="#f0d860" stroke-width="0.35"/><circle r="0.35" fill="#f8f0d0"/>` });
      const knife = H2(C, [43.4, TY + 1.8, 8.6], [50.4, TY + 1.8, 9.6], 0.9, '#d0d6da') + H2(C, [50.4, TY + 1.9, 9.6], [54.6, TY + 1.9, 10.2], 1.3, '#3a2a1e');
      const lemW = sph(C, [49, TY + 4, 1], 2.5, '#f2d23a') + sph(C, [51.4, TY + 4.2, 1], 0.6, '#d8b82a');
      const onB = vsort(C, [{ q: [40, TY + 2.6, 6], s: lemH }, { q: [49, TY + 4, 1], s: lemW }, { q: [49, TY + 1.8, 9.4], s: knife }]);
      const items = vsort(C, [{ q: [0, TY + 9, FZ + 6], s: fau }, { q: [32, TY + 5, -22], s: pump }, { q: [-36, TY + 6, -21], s: basil }, { q: [45, TY + 1, 4], s: board + onB }]);
      let s = shadow(C, 0, 0, 66, 32, 0.8) + bas + kick + cab + (fv ? fr : '') + slab + top + (fv ? apron : '') + ring + items;
      C.p(0, TY + 30, 0);
      return { defs: DEFD, front: s, bb: C.bb(6) }; };
    return D; };

  // ---------- Furniture batch 2 shared defs: hammered metal dimples, flutes, faded 70s floral, curtain folds ----------
  const DEFF = DEFK + '<pattern id="k28ham" width="3.4" height="3" patternUnits="userSpaceOnUse">' + [[0.9, 0.8, 0.8], [2.6, 2.3, 0.7], [2.5, 0.6, 0.5], [0.8, 2.4, 0.55], [1.8, 1.5, 0.45]].map(([x, y, r]) => `<ellipse cx="${f1(x - 0.15)}" cy="${f1(y - 0.15)}" rx="${r}" ry="${f1(r * 0.85)}" fill="#ffffff" opacity="0.26"/><ellipse cx="${f1(x + 0.15)}" cy="${f1(y + 0.18)}" rx="${f1(r * 0.9)}" ry="${f1(r * 0.75)}" fill="#4a3008" opacity="0.2"/>`).join('') + '</pattern>'
    + '<linearGradient id="k28fg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000000" stop-opacity="0.16"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="0.7" stop-color="#000000" stop-opacity="0.03"/><stop offset="1" stop-color="#000000" stop-opacity="0.2"/></linearGradient><pattern id="k28flt" width="2.2" height="60" patternUnits="userSpaceOnUse"><rect width="2.2" height="60" fill="url(#k28fg)"/></pattern>'
    + '<pattern id="k28flr" width="9" height="9" patternUnits="userSpaceOnUse"><rect width="9" height="9" fill="#efe0bb"/>' + [[2.2, 2.4, '#efbf52', 1], [6.6, 6.4, '#e2843a', 0.8]].map(([x, y, c, s]) => rep(6, i => `<ellipse cx="${f1(x + Math.cos(i * PI / 3) * 1.1 * s)}" cy="${f1(y + Math.sin(i * PI / 3) * 1.1 * s)}" rx="${f1(0.75 * s)}" ry="${f1(0.42 * s)}" fill="${c}" opacity="0.7" transform="rotate(${i * 60} ${f1(x + Math.cos(i * PI / 3) * 1.1 * s)} ${f1(y + Math.sin(i * PI / 3) * 1.1 * s)})"/>`).join('') + `<circle cx="${x}" cy="${y}" r="${f1(0.55 * s)}" fill="#a8582a" opacity="0.75"/>`).join('') + '<path d="M3.8 3.6Q5 4.4 4.6 5.6M7.8 4.8Q8.6 3.6 8 2.6M0.8 6.4Q1.8 7 1.6 8.2" stroke="#7a8a4a" stroke-opacity="0.55" stroke-width="0.4" fill="none"/></pattern>'
    + '<linearGradient id="k28fg2" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000000" stop-opacity="0.22"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.55" stop-color="#000000" stop-opacity="0"/><stop offset="0.85" stop-color="#000000" stop-opacity="0.12"/><stop offset="1" stop-color="#000000" stop-opacity="0.22"/></linearGradient><pattern id="k28fold" width="5" height="60" patternUnits="userSpaceOnUse"><rect width="5" height="60" fill="url(#k28fg2)"/></pattern>';
  const SPLK = n => ` calcMode="spline" keySplines="${rep(n, () => '0.45 0 0.55 1').join(';')}"`;

  // KIT-062 WORKSTATION HAMMERED BRASS SINK WITH POT-FILLER & GLASS RINSER (T4): bottle-green lacquer inset-shaker cabinets with polished brass cup pulls, knobs and
  // a towel bar (striped linen towel swaying), warm amber toe-kick glow; cream Taj Mahal quartzite top + tall backsplash with soft taupe/gold veins. Deep hammered
  // brass workstation basin with ledge rails: a walnut board with rainbow carrots and a chef's knife glides along the ledges (18 s). Brass gooseneck (a drop now
  // and then), deck soap pump, a glass rinser that presses an upside-down wine glass and jets it clean every 9 s, a brass wall pot-filler that fills a hammered
  // copper stockpot every 14 s (steam always), a brass bowl of pears. A light glint slides round the polished brass rim every 8 s.
  N.ham28 = S => { const TY = SKT, GN = '#2f4a3c', ST = '#ece3d2', BR = '#c9a256', BL = '#dcb866', X0 = -34, X1 = 18, Z0 = -16, Z1 = 16, DEP = 15, Y0 = TY - DEP, LY = TY - 2.6, FX = -8, FZ = -21.5, ZF = 25.6, RX = 30, RZ = -18, PX = 42, PZ = -6;
    const D = { w: 124, d: 54, arch: 'counter', act: 'wash', use: { x: 0, z: 54 }, topH: TY, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), R = rng('ham28');
      const pnl = (x, y, w, h, flat) => { const b = Math.min(4, w * 0.15); return `<rect x="${f1(x - 0.4)}" y="${f1(y - 0.4)}" width="${f1(w + 0.8)}" height="${f1(h + 0.8)}" fill="none" stroke="#0c1410" stroke-opacity="0.8" stroke-width="0.55"/><path d="M${f1(x)} ${f1(y + h)}V${f1(y)}H${f1(x + w)}" stroke="#ffffff" stroke-opacity="0.2" stroke-width="0.35" fill="none"/>`
        + (flat ? '' : `<rect x="${f1(x + b)}" y="${f1(y + b)}" width="${f1(w - 2 * b)}" height="${f1(h - 2 * b)}" fill="#000000" opacity="0.06"/><path d="M${f1(x + b)} ${f1(y + h - b)}V${f1(y + b)}H${f1(x + w - b)}" stroke="#000000" stroke-opacity="0.35" stroke-width="0.6" fill="none"/><path d="M${f1(x + b)} ${f1(y + h - b)}H${f1(x + w - b)}V${f1(y + b)}" stroke="#ffffff" stroke-opacity="0.24" stroke-width="0.45" fill="none"/>`); };
      const cabF = [[1, 1, 36, 11, 1], [1, 13, 36, 41], [38, 1, 46, 11, 1], [38, 13, 22.6, 41], [61.4, 13, 22.6, 41], [85, 1, 36, 11, 1], [85, 13, 36, 41]].map(p => pnl(...p)).join('') + `<rect width="122" height="55" fill="url(#m10s)" opacity="0.5"/>`;
      const cabS = pnl(2, 2, 48.6, 51) + `<rect width="52.6" height="55" fill="url(#m10s)" opacity="0.4"/>`;
      const glow = PLN(C, [0, 0.06, ZF + 4], [1, 0, 0], [0, 0, 1], `<ellipse rx="58" ry="7" fill="url(#k28amb)">${an('opacity', '0.8;1;0.8', 5)}</ellipse>`);
      const kick = box3(C, { c: [0, 0, -2.5], w: 118, h: 4, d: 47, r: 0.3, col: '#1e1e1c', olw: 0.3, skip: { t: 1 }, dec: { f: `<rect y="0.2" width="118" height="0.5" fill="#c9a256" opacity="0.8"/>` } });
      const cab = box3(C, { c: [0, 4, -0.7], w: 122, h: TY - 7, d: 52.6, r: 0.4, col: GN, gl: 0.45, olw: 0.45, olo: 0.7, skip: { t: 1 }, dec: { f: cabF, l: cabS, r: cabS } });
      const cupP = x => cyl3(C, [x - 3, 53, ZF + 0.9], [x + 3, 53, ZF + 0.9], 0.95, BL, { mat: 'chrome', n: 14, olw: 0.2 }) + [x - 3.4, x + 3.4].map(xx => box3(C, { c: [xx, 52.3, ZF + 0.6], w: 1.2, h: 1.6, d: 1.2, r: 0.3, col: BL, olw: 0.2 })).join('');
      const towX = `<rect width="12" height="16" fill="url(#k28wv)" opacity="0.6"/>` + [[1.8, 0.5], [2.8, 0.5], [12.6, 0.5], [13.6, 0.5]].map(([y, h]) => `<rect y="${y}" width="12" height="${h}" fill="#4a6a52" opacity="0.85"/>`).join('') + rep(12, i => `<path d="M${f1(0.5 + i)} ${f1(15.8 + (i % 2) * 0.2)}v0.9" stroke="#e6dccb" stroke-width="0.25"/>`).join('');
      const fr = vsort(C, [{ q: [-42, 53, ZF], s: cupP(-42) }, { q: [42, 53, ZF], s: cupP(42) }, { q: [0, 53, ZF + 1.2], s: barH(C, -14, 14, 53, ZF, 2.4, 0.75, BL, 'chrome', 1.6) }].concat([[-28, 30], [-3.5, 34], [3.5, 34], [28, 30]].map(([x, y]) => ({ q: [x, y, ZF + 1], s: knobB(C, x, y, ZF, 1.25, BL, 'chrome') }))))
        + PLN(C, [-6, 53.6, ZF + 2.4], [1, 0, 0], [0, -1, 0], towS(12, 16, '#efe8da', towX, 6.2));
      // quartzite slab, top, backsplash
      const edF = L => `<rect width="${L}" height="3.6" fill="url(#m10s)" opacity="0.35"/>` + rep(5, () => { const x = R() * L; return `<path d="M${f1(x)} 0Q${f1(x + 1)} 1.8 ${f1(x + 0.4)} 3.6" stroke="#a89878" stroke-opacity="0.35" stroke-width="0.3" fill="none"/>`; }).join('');
      const slab = box3(C, { c: [0, TY - 3.6, 0.5], w: 124, h: 3.6, d: 55, r: 0.6, col: ST, gl: 0.3, olw: 0.4, skip: { t: 1 }, dec: { f: edF(124), l: edF(55), r: edF(55) } });
      const topD = veins(rng('ham28v'), 124, 55) + `<rect width="124" height="55" fill="url(#m10s)" opacity="0.35"/>`;
      const top = ctopH(C, -62, 62, -27, 28, TY, ST, [[X0, Z0, X1, Z1, 1.6]], topD);
      const bs = box3(C, { c: [0, TY, -26], w: 124, h: 22, d: 2, r: 0.3, col: ST, gl: 0.3, olw: 0.35, dec: { f: veins(rng('ham28b'), 124, 22) + `<path d="M0 0.4H124" stroke="#c9a256" stroke-width="0.6"/>` } });
      const rimX = `<rect width="56.4" height="36.4" fill="url(#k28ham)"/><path d="${rrP(2.2, 2.2, 52, 32, 1.6)}" fill="none" stroke="#fff4d0" stroke-opacity="0.8" stroke-width="0.45"/><path d="M-8 0H-4L-14 40H-18Z" fill="#fff8e0" opacity="0.75">${at('translate', '0 0;0 0;84 0;84 0', 8, 0, KT('0;0.55;0.82;1'))}</path>`;
      const rim = ringP(C, TY + 0.06, [X0 - 2.2, Z0 - 2.2, X1 + 2.2, Z1 + 2.2, 2.6], [[X0, Z0, X1, Z1, 1.6]], BL, rimX);
      // basin: hammered brass, ledge rails, sliding walnut board
      const flD = `<rect width="52" height="32" fill="url(#k28ham)"/><rect width="52" height="32" fill="url(#m10s)" opacity="0.45"/><circle cx="42" cy="23" r="3.2" fill="#8a6a2a"/><circle cx="42" cy="23" r="2.5" fill="#2a2016"/>` + rep(8, i => `<circle cx="${f1(42 + Math.cos(i * PI / 4) * 1.4)}" cy="${f1(23 + Math.sin(i * PI / 4) * 1.4)}" r="0.3" fill="#c9a256"/>`).join('')
        + rep(9, () => `<circle cx="${f1(4 + R() * 44)}" cy="${f1(3 + R() * 26)}" r="${f1(0.3 + R() * 0.5)}" fill="#ffffff" opacity="0.4"/>`).join('');
      const wd = (k, L, dp) => `<rect width="${f1(L)}" height="${f1(dp)}" fill="url(#k28ham)"/><path d="M0 3.2H${f1(L)}" stroke="#5a3a10" stroke-opacity="0.35" stroke-width="0.4"/><path d="M0 0.5H${f1(L)}" stroke="#fff4d0" stroke-opacity="0.6" stroke-width="0.4"/>`;
      const bas0 = basin(C, X0, X1, Z0, Z1, TY, DEP, BR, { floor: flD, wd, dk: 0.3, f: 1.05 });
      const led = [Z0 + 0.6, Z1 - 0.6].map(z => box3(C, { c: [(X0 + X1) / 2, LY - 0.6, z], w: X1 - X0, h: 0.6, d: 1.2, r: 0, col: BL, olw: 0.2, edge: 0 })), ledg = C.v[2] > 0 ? led[0] + led[1] : led[1] + led[0];
      const BX = -25, bt = LY + 1.6;
      const board = box3(C, { c: [BX, LY, 0], w: 15, h: 1.6, d: Z1 - Z0 - 0.4, r: 0.6, col: '#6a4228', olw: 0.3, dec: { t: grainV(rng('ham28g'), 15, 31.6, 7, '#3a2414', '#9a6a44') + `<rect x="1.2" y="1.2" width="12.6" height="29.2" rx="1" fill="none" stroke="#3a2414" stroke-opacity="0.4" stroke-width="0.35"/>` } });
      const CC = ['#e8792a', '#7a2a5a', '#f2c43a', '#e8792a'];
      const onB = vsort(C, CC.map((c, i) => { const x = BX - 5 + i * 2.9; return { q: [x, bt + 1, 0], s: cyl3(C, [x, bt + 1.1, -7], [x + 0.4, bt + 1.1, 7], 1.1, c, { r2: 0.25, mat: 'gloss', n: 14, olw: 0.25 }) + [-0.8, 0, 0.8].map(d => H2(C, [x, bt + 1.2, -7], [x + d, bt + 1.8, -12.6], 0.3, '#5a9a3a')).join('') }; })
        .concat([{ q: [BX + 5, bt + 0.3, -4], s: H2(C, [BX + 5.4, bt + 0.3, -13], [BX + 5.4, bt + 0.3, -1], 1.5, '#d8dde0') + H2(C, [BX + 5.4, bt + 0.5, -1], [BX + 5.4, bt + 0.5, 5], 1.2, '#2a1a10') }]));
      const e0 = C.P([0, LY, 0]), e1 = C.P([34, LY, 0]), dx = e1[0] - e0[0], dy = e1[1] - e0[1];
      const slide = `<g>${at('translate', `0 0;0 0;${f1(dx)} ${f1(dy)};${f1(dx)} ${f1(dy)};0 0;0 0`, 18, 0, KT('0;0.1;0.4;0.6;0.9;1') + SPLK(5))}${board + onB}</g>`;
      const nT = arcP(FX, TY + 16, FZ, [0, 1], 7, -0.25, 14), tip = nT[14];
      const bas = bas0 + dropS(C, [tip[0], TY, tip[2]], [tip[0], Y0, tip[2]], 0.45, 6, 0.665, 0.69) + ledg + slide;
      // faucet (polished brass gooseneck + side lever), deck pump
      const riser = cyl3(C, [FX, TY, FZ], [FX, TY + 0.9, FZ], 2.8, BL, { mat: 'chrome', n: 22, olw: 0.3 }) + cyl3(C, [FX, TY + 0.9, FZ], [FX, TY + 16.2, FZ], 1.4, BL, { mat: 'chrome', n: 18, olw: 0.3, noCap: 1 });
      const lev = cyl3(C, [FX + 1.3, TY + 7, FZ], [FX + 2.6, TY + 7, FZ], 1.05, BL, { mat: 'chrome', n: 14, olw: 0.22 }) + cyl3(C, [FX + 2.5, TY + 7.2, FZ], [FX + 6.8, TY + 8.6, FZ], 0.42, BL, { r2: 0.55, mat: 'chrome', n: 10, olw: 0.2 });
      const fau = vsort(C, [{ q: [FX, TY + 8, FZ], s: C.v[0] > 0 ? riser + lev : lev + riser }, ...pipe(C, nT, 1.1, BL), { q: [tip[0], TY + 14.5, tip[2]], s: cyl3(C, tip, [tip[0], TY + 13.2, tip[2]], 1.25, BL, { mat: 'chrome', n: 16, olw: 0.25 }) }]);
      const pump = cyl3(C, [8, TY, -21.5], [8, TY + 0.6, -21.5], 1.7, BL, { mat: 'chrome', n: 16, olw: 0.25 }) + cyl3(C, [8, TY + 0.6, -21.5], [8, TY + 4.4, -21.5], 0.55, BL, { mat: 'chrome', n: 10, olw: 0.2, noCap: 1 }) + sph(C, [8, TY + 4.6, -21.5], 1, BL) + stick(C, [8, TY + 4.4, -21.5], [8, TY + 4.2, -18.8], 0.4, BL, 'chrome');
      // glass rinser: plate, jets, upside-down wine glass pressing down
      const T9 = 9, rOn = KT('0;0.14;0.16;0.34;0.36;1');
      const plate = cyl3(C, [RX, TY, RZ], [RX, TY + 0.7, RZ], 3.4, BL, { mat: 'chrome', n: 24, olw: 0.3, cap: cr => rep(8, i => `<circle cx="${f1(Math.cos(i * PI / 4) * cr * 0.5)}" cy="${f1(Math.sin(i * PI / 4) * cr * 0.5)}" r="0.3" fill="#3a2a10"/>`).join('') + `<circle r="0.5" fill="#3a2a10"/><circle r="${f1(cr * 0.82)}" fill="none" stroke="#8a6a2a" stroke-width="0.25"/>` });
      const jets = `<g opacity="0">${an('opacity', '0;0;0.9;0.9;0;0', T9, 0, rOn)}` + rep(7, i => { const a = i * 2 * PI / 7, p = C.P([RX + Math.cos(a) * 0.5, TY + 0.8, RZ + Math.sin(a) * 0.5]), q = C.P([RX + Math.cos(a) * 1.9, TY + 5.4, RZ + Math.sin(a) * 1.9]), L = 1.2 * C.k;
        return `<path d="M${P2(p)}L${P2(q)}" stroke="#ffffff" stroke-opacity="0.85" stroke-width="${f1(0.25 * C.k)}" stroke-dasharray="${f1(L * 0.5)} ${f1(L * 0.5)}" stroke-linecap="round">${an('stroke-dashoffset', `0;${f1(L * 2)}`, 0.25)}</path>`; }).join('') + '</g>';
      const gy = C.P([RX, TY, RZ])[1] - C.P([RX, TY + 0.5, RZ])[1];
      const glass = cyl3(C, [RX, TY + 0.8, RZ], [RX, TY + 5.6, RZ], 2.5, '#e6f2f4', { r2: 1.6, mat: 'chrome', n: 22, op: 0.3, olw: 0.3, olc: '#7a9aa2' }) + sph(C, [RX, TY + 5.8, RZ], 1.6, '#e6f2f4', { op: 0.3 })
        + cyl3(C, [RX, TY + 6.6, RZ], [RX, TY + 10.6, RZ], 0.3, '#e6f2f4', { mat: 'chrome', n: 10, op: 0.6, olw: 0.2, olc: '#7a9aa2' }) + cyl3(C, [RX, TY + 10.6, RZ], [RX, TY + 11, RZ], 2.3, '#e6f2f4', { mat: 'chrome', n: 22, op: 0.45, olw: 0.25, olc: '#7a9aa2' });
      const gside = [RX + Math.sin(C.thV) * 2.55, RZ + Math.cos(C.thV) * 2.55];
      const rinser = plate + jets + `<g>${at('translate', `0 0;0 0;0 ${f1(gy)};0 ${f1(gy)};0 0;0 0`, T9, 0, KT('0;0.1;0.14;0.36;0.4;1'))}${glass}</g>` + dropS(C, [gside[0], TY + 4.6, gside[1]], [gside[0], TY + 0.9, gside[1]], 0.35, T9, 0.42, 0.5) + dropS(C, [gside[0] - 0.8, TY + 3.6, gside[1]], [gside[0] - 0.8, TY + 0.9, gside[1]], 0.3, T9, 0.48, 0.55);
      // hammered copper stockpot + brass wall pot-filler
      const T14 = 14, pOn = KT('0;0.2;0.22;0.5;0.52;1');
      const pot = cyl3(C, [PX, TY, PZ], [PX, TY + 10, PZ], 7.2, '#c87a46', { mat: 'metal', n: 30, olw: 0.35, pat: 'k28ham', cap: cr => `<circle r="${f1(cr * 0.95)}" fill="#7a4a2a"/><circle r="${f1(cr * 0.86)}" fill="#a8bcc0"/><circle r="${f1(cr * 0.86)}" fill="url(#m10cap)"/><g transform="translate(${f1(cr * 0.2)} ${f1(-cr * 0.1)})"><path d="M-1.4 -0.6Q0 -1.6 1.6 -0.4Q0 0.6 -1.4 -0.6Z" fill="#5a8a3a"/><path d="M-0.4 0.8Q1 0.2 2 1.2" stroke="#4a7a2a" stroke-width="0.35" fill="none"/></g>`
        + `<g opacity="0">${an('opacity', '0;0;1;1;0;0', T14, 0, pOn)}${rep(3, i => `<circle r="0.3" fill="none" stroke="#ffffff" stroke-width="0.25">${an('r', `0.3;${f1(cr * 0.7)}`, 0.8, -i * 0.27)}${an('opacity', '0.9;0', 0.8, -i * 0.27)}</circle>`).join('')}</g>` });
      const ph = [-1, 1].map(sg => cyl3(C, [PX + sg * 7.1, TY + 8, PZ], [PX + sg * 9.4, TY + 8, PZ], 0.7, BL, { mat: 'chrome', n: 12, olw: 0.2 }) + sph(C, [PX + sg * 9.6, TY + 8, PZ], 1, BL));
      const potB = (C.v[0] > 0 ? ph[0] + pot + ph[1] : ph[1] + pot + ph[0]);
      const FY = TY + 17, fil = vsort(C, [{ q: [PX, FY, -24.3], s: cyl3(C, [PX, FY, -25], [PX, FY, -23.6], 2.4, BL, { mat: 'chrome', n: 22, olw: 0.3 }) },
        { q: [PX, FY, -19.3], s: cyl3(C, [PX, FY, -23.6], [PX, FY, -15], 0.95, BL, { mat: 'chrome', n: 14, olw: 0.25 }) + H2(C, [PX, FY + 0.8, -21], [PX, FY + 3.6, -21], 0.6, BL) + sph(C, [PX, FY + 3.8, -21], 0.8, BL) },
        { q: [PX, FY, -15], s: sph(C, [PX, FY, -15], 1.5, BL) }, { q: [PX, FY, -10.7], s: cyl3(C, [PX, FY, -15], [PX, FY, -6.4], 0.95, BL, { mat: 'chrome', n: 14, olw: 0.25 }) },
        { q: [PX, FY - 1.6, PZ], s: sph(C, [PX, FY, -6.4], 1.2, BL) + cyl3(C, [PX, FY, -6.4], [PX, TY + 14, -6.4], 0.9, BL, { r2: 1.1, mat: 'chrome', n: 14, olw: 0.25 }) + H2(C, [PX + 0.9, FY - 0.6, -6.4], [PX + 3.4, FY + 0.4, -6.4], 0.5, BL) }]);
      const potG = potB + fil + `<g opacity="0">${an('opacity', '0;0;1;1;0;0', T14, 0, pOn)}${strm(C, [PX, TY + 14, -6.4], [PX, TY + 10.1, -6.4], 0.9)}</g>` + mist(C, PX, TY + 10, PZ, 3, 0.55);
      // brass bowl of pears
      const bowl = cyl3(C, [-48, TY, -10], [-48, TY + 1.2, -10], 2.6, BL, { mat: 'chrome', n: 18, olw: 0.25 }) + cyl3(C, [-48, TY + 1.2, -10], [-48, TY + 5, -10], 3.6, BL, { r2: 6.4, mat: 'chrome', n: 26, olw: 0.3, pat: 'k28ham', capCol: '#5a4218' })
        + vsort(C, [[-2, 0.6, '#b8c84a'], [2.2, -0.4, '#c8b84a'], [0, -2.6, '#a8c050'], [0.2, 2.4, '#c8c050']].map(([dx, dz, c]) => { const q = [-48 + dx, TY + 6, -10 + dz]; return { q, s: sph(C, q, 2.2, c) + sph(C, [q[0] + 0.2, q[1] + 1.9, q[2]], 1.5, c) + H2(C, [q[0] + 0.2, q[1] + 3.2, q[2]], [q[0] + 0.7, q[1] + 4.4, q[2]], 0.3, '#5a3a1a') }; }));
      const items = vsort(C, [{ q: [FX, TY + 8, FZ + 4], s: fau }, { q: [8, TY + 2, -21.5], s: pump }, { q: [RX, TY + 5, RZ], s: rinser }, { q: [PX, TY + 5, PZ], s: potG }, { q: [-48, TY + 4, -10], s: bowl }]);
      let s = shadow(C, 0, 0, 66, 32, 0.8) + glow + bas + kick + cab + (fv ? fr : '') + slab + top + rim + (fv ? bs + items : items + bs);
      s += hangD(C, [tip[0], TY + 13.2, tip[2]], 0.45, 6, 0.6) + dropS(C, [tip[0], TY + 13.1, tip[2]], [tip[0], TY, tip[2]], 0.45, 6, 0.6, 0.665);
      C.p(0, TY + 24, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-082 ULTRASONIC WAVE-CLEAN BASIN WITH INSTANT BOILING / SPARKLING / BROTH TAP (T5): keeps the Royal Calacatta L-kitchen footprint (242 x 154, topH 59.2).
  // Fluted ivory lacquer runs with champagne-gold reveals and finger pulls, floating on a recessed plinth over a breathing amber glow; book-matched Calacatta top,
  // waterfall end and low backsplashes. Integrated marble basin with a gold inlay rim: soft ultrasonic rings ripple across the water from a glowing gold
  // transducer ring while fine bubbles rise round a crystal wine glass and a bowl of strawberries. Sculptural gold arc faucet. The instant tap cycles every 5 s:
  // 100° boiling water into a gold-rimmed teacup (steam), sparkling into a coupe (bubbles), golden broth into a celadon bowl (steam). Lemons, hydrangeas, oil + salt.
  N.wave28 = S => { const TY = 59.2, IV = '#f1ece3', CG = '#d6b878', MB = '#f6f3ee', SX0 = 7, SX1 = 53, SZ0 = -58, SZ1 = -30, DEP = 15, Y0 = TY - DEP, WY = TY - 3, IX = 64, IZ = -63, VZ = -53;
    const D = { w: 242, d: 154, act: 'wash', use: { x: 30, z: 10 }, topH: TY, topZ: -42, topW: 110, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('wave28');
      const edge = L => `<rect width="${f1(L)}" height="4" fill="url(#m10s)" opacity="0.4"/><path d="M0 3.5H${f1(L)}" stroke="${CG}" stroke-width="0.8"/>`;
      const doors = (L, n, u0) => { const pw = (L - u0) / n; let s = ''; rep(n, i => { const x = u0 + i * pw + 0.6, w = pw - 1.2;
        s += `<rect x="${f1(x)}" y="1" width="${f1(w)}" height="8.4" fill="#ffffff" opacity="0.06"/><path d="M${f1(x + w / 2 - 6)} 1.4H${f1(x + w / 2 + 6)}" stroke="${CG}" stroke-width="0.9" stroke-linecap="round"/>`
          + `<rect x="${f1(x + 1.2)}" y="11.6" width="${f1(w - 2.4)}" height="36.6" fill="url(#k28flt)"/><path d="M${f1(x + w / 2 - 5)} 10.8H${f1(x + w / 2 + 5)}" stroke="${CG}" stroke-width="0.9" stroke-linecap="round"/>`; });
        return s + rep(n + 1, i => `<path d="M${f1(u0 + i * pw)} 0V50.2" stroke="${CG}" stroke-width="0.6"/>`).join('') + `<path d="M${f1(u0)} 9.9H${f1(L)}" stroke="${CG}" stroke-width="0.5"/><rect width="${f1(L)}" height="50.2" fill="url(#m10s)" opacity="0.4"/>`; };
      const unit = (cx, cz, w, d, dec) => box3(C, { c: [cx, 0, cz], w: w - 6, h: 5, d: d - 6, r: 0.3, col: '#1c1b1a', olw: 0.3, skip: { t: 1 } }) + box3(C, { c: [cx, 5, cz], w, h: TY - 9, d, r: 0.3, col: IV, gl: 0.35, olw: 0.4, olo: 0.6, skip: { t: 1 }, dec })
        + box3(C, { c: [cx, TY - 4, cz], w, h: 4, d, r: 0.3, col: MB, gl: 0.3, olw: 0.35, skip: { t: 1 }, dec: { f: edge(w), r: edge(d), l: edge(d), b: edge(w) } });
      const runU = unit(25, -42, 190, 52, { f: doors(190, 5, 0) }), legU = unit(-96, 9, 52, 154, { r: doors(102, 3, 0) });
      const wf = box3(C, { c: [-96, 0, 88.4], w: 52, h: TY, d: 4.8, r: 0.3, col: MB, gl: 0.4, olw: 0.4, skip: { t: 1 }, dec: { f: veins(rng('wave28w'), 52, TY) + `<rect width="52" height="${TY}" fill="url(#m10s)" opacity="0.4"/>`, l: veins(rng('wave28x'), 4.8, TY), r: veins(rng('wave28x'), 4.8, TY) } });
      const v0 = C.v[0] > 0, v2 = C.v[2] > 0;
      const units = v0 ? (v2 ? legU + wf + runU : wf + legU + runU) : (v2 ? runU + legU + wf : runU + wf + legU);
      const glow = PLN(C, [25, 0.06, -14], [1, 0, 0], [0, 0, 1], `<ellipse rx="98" ry="8" fill="url(#k28amb)">${an('opacity', '0.75;1;0.75', 6)}</ellipse>`) + PLN(C, [-68, 0.06, 35], [0, 0, 1], [1, 0, 0], `<ellipse rx="54" ry="7" fill="url(#k28amb)">${an('opacity', '0.75;1;0.75', 6)}</ellipse>`);
      // L top with the basin hole
      const Ld = `M0 0H242V52H52V158.8H0Z` + rrP(129, 10, 46, 28, 5), tid = C.u('lt');
      const top = PLN(C, [-122, TY, -68], [1, 0, 0], [0, 0, 1], `<clipPath id="${tid}"><path d="${Ld}" clip-rule="evenodd"/></clipPath><g clip-path="url(#${tid})"><rect width="242" height="159" fill="${shade(MB, lit(C, [0, 1, 0]))}"/><rect width="242" height="159" fill="url(#m10t)"/>${veins(R, 242, 159)}<rect width="242" height="159" fill="url(#m10s)" opacity="0.3"/></g>`);
      const rim = ringP(C, TY + 0.04, [SX0 - 1.2, SZ0 - 1.2, SX1 + 1.2, SZ1 + 1.2, 6], [[SX0, SZ0, SX1, SZ1, 5]], CG, '');
      const bsB = box3(C, { c: [-1, TY, -67], w: 242, h: 12, d: 2, r: 0.3, col: MB, gl: 0.3, olw: 0.35, dec: { f: veins(rng('wave28b'), 242, 12) + `<path d="M0 0.4H242" stroke="${CG}" stroke-width="0.6"/>` } });
      const bsL = box3(C, { c: [-121, TY, 10], w: 2, h: 12, d: 152, r: 0.3, col: MB, gl: 0.3, olw: 0.35, dec: { r: veins(rng('wave28l'), 152, 12) + `<path d="M0 0.4H152" stroke="${CG}" stroke-width="0.6"/>` } });
      // basin: marble interior, gold transducer ring + drain slot, crystal glass + strawberry bowl, water surface with ultrasonic rings and bubbles
      const flD = veins(rng('wave28f'), 46, 28) + `<ellipse cx="23" cy="14" rx="15" ry="9" fill="none" stroke="${CG}" stroke-width="0.8"/><ellipse cx="23" cy="14" rx="15" ry="9" fill="url(#k28amb)" opacity="0.6">${an('opacity', '0.4;0.75;0.4', 2.4)}</ellipse><rect x="12" y="24.4" width="22" height="1.4" rx="0.7" fill="#3a3226"/><rect x="12" y="24.4" width="22" height="1.4" rx="0.7" fill="none" stroke="${CG}" stroke-width="0.3"/>`;
      const wd = (k, L, dp) => veins(rng('wave28' + k), L, dp) + `<path d="M0 0.5H${f1(L)}" stroke="#ffffff" stroke-opacity="0.7" stroke-width="0.4"/>`;
      const bas0 = basin(C, SX0, SX1, SZ0, SZ1, TY, DEP, MB, { floor: flD, wd, dk: 0.2, f: 1.06 });
      const wg = (x, z) => cyl3(C, [x, Y0, z], [x, Y0 + 0.4, z], 2.2, '#e8f4f6', { mat: 'chrome', n: 18, op: 0.45, olw: 0.2, olc: '#8aa4aa' }) + cyl3(C, [x, Y0 + 0.4, z], [x, Y0 + 4, z], 0.3, '#e8f4f6', { mat: 'chrome', n: 10, op: 0.6, olw: 0.2, olc: '#8aa4aa' })
        + cyl3(C, [x, Y0 + 4, z], [x, Y0 + 9.4, z], 1.6, '#e8f4f6', { r2: 2.7, mat: 'chrome', n: 20, op: 0.32, olw: 0.3, olc: '#8aa4aa', capCol: '#f4fbfc' });
      const sbowl = cyl3(C, [38, Y0, -42], [38, Y0 + 3.6, -42], 3.6, '#fbfaf6', { r2: 5.4, mat: 'gloss', n: 24, olw: 0.3, capCol: '#e8e2d8' }) + vsort(C, [[-1.8, 0], [1.6, 0.8], [0, -1.8], [0.4, 1.8], [-0.4, 0.2, 1]].map(([dx, dz, up]) => { const q = [38 + dx, Y0 + 4.4 + (up ? 1.2 : 0), -42 + dz]; return { q, s: sph(C, q, 1.5, '#d8283a') + `<path d="M${P2(C.P([q[0] - 0.6, q[1] + 1.3, q[2]]))}L${P2(C.P([q[0] + 0.6, q[1] + 1.3, q[2]]))}" stroke="#4a8a2a" stroke-width="${f1(0.5 * C.k)}" stroke-linecap="round"/>` }; }));
      const inW = vsort(C, [{ q: [20, Y0 + 4, -46], s: wg(20, -46) }, { q: [38, Y0 + 3, -42], s: sbowl }]);
      const wid = C.u('wc'), rings = [[14, 14], [33, 13]].map(([x, y], j) => rep(4, i => `<ellipse cx="${x}" cy="${y}" rx="0.5" ry="0.4" fill="none" stroke="#ffffff" stroke-width="0.3">${an('rx', '0.5;16', 2.4, -i * 0.6 - j * 0.3)}${an('ry', '0.4;11', 2.4, -i * 0.6 - j * 0.3)}${an('opacity', '0.8;0', 2.4, -i * 0.6 - j * 0.3)}</ellipse>`).join('')).join('');
      const water = PLN(C, [SX0, WY, SZ0], [1, 0, 0], [0, 0, 1], `<clipPath id="${wid}"><path d="${rrP(0, 0, 46, 28, 5)}"/></clipPath><g clip-path="url(#${wid})"><rect width="46" height="28" fill="#e6f0ee" opacity="0.26"/>${rings}<path d="M4 4Q16 1 30 4" stroke="#fff4d8" stroke-opacity="0.5" stroke-width="0.6" fill="none"/></g>`);
      const bas = bas0 + inW + bubl(C, 30, Y0 + 1, -44, 34, 14, DEP - 4) + water;
      // gold arc faucet
      const aP = arcP(30, TY + 20, IZ, [0, 1], 8.5, -0.2, 14), atip = aP[14];
      const fau = vsort(C, [{ q: [30, TY + 10, IZ], s: cyl3(C, [30, TY, IZ], [30, TY + 0.8, IZ], 2.8, CG, { mat: 'chrome', n: 22, olw: 0.3 }) + cyl3(C, [30, TY + 0.8, IZ], [30, TY + 20.2, IZ], 1.5, CG, { r2: 1.2, mat: 'chrome', n: 18, olw: 0.3, noCap: 1 }) + cyl3(C, [31.2, TY + 8, IZ], [35.6, TY + 9.4, IZ], 0.42, CG, { r2: 0.55, mat: 'chrome', n: 10, olw: 0.2 }) },
        ...pipe(C, aP, 1.15, CG), { q: [atip[0], TY + 16, atip[2]], s: cyl3(C, atip, [atip[0], TY + 16.4, atip[2]], 1.3, CG, { mat: 'chrome', n: 16, olw: 0.25 }) }]);
      // instant tap: column, mode puck, short spout; vessels cycle with the mode
      const seg = (i, s) => { const kt = i === 0 ? '0;0.313;0.333;0.98;1' : i === 1 ? '0;0.313;0.333;0.647;0.667;1' : '0;0.647;0.667;0.98;1', v = i === 0 ? '1;1;0;0;1' : i === 1 ? '0;0;1;1;0;0' : '0;0;1;1;0'; return `<g opacity="${i ? 0 : 1}">${an('opacity', v, 15, 0, KT(kt))}${s}</g>`; };
      const MODES = [['100°', 'BOIL'], ['✦', 'SPARKLING'], ['85°', 'BROTH']];
      const puck = cyl3(C, [IX, TY + 16, IZ], [IX, TY + 17.6, IZ], 2.3, '#1c1a18', { mat: 'gloss', n: 22, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="none" stroke="${CG}" stroke-width="0.3"/>` + MODES.map((m, i) => seg(i, `<text y="0.3" text-anchor="middle" ${FONT} font-size="1.4" fill="${CG}">${m[0]}</text><text y="1.4" text-anchor="middle" ${FONT} font-size="0.45" fill="${CG}" opacity="0.8" letter-spacing="0.1">${m[1]}</text>`)).join('') }) + cyl3(C, [IX, TY + 15.6, IZ], [IX, TY + 16, IZ], 2.4, CG, { mat: 'chrome', n: 22, olw: 0.25, noCap: 1 });
      const sP = arcP(IX, TY + 13, IZ, [0, 1], 5, 0, 10), stip = sP[10];
      const tapP = vsort(C, [{ q: [IX, TY + 8, IZ], s: cyl3(C, [IX, TY, IZ], [IX, TY + 0.8, IZ], 2.2, CG, { mat: 'chrome', n: 20, olw: 0.3 }) + cyl3(C, [IX, TY + 0.8, IZ], [IX, TY + 15.6, IZ], 1.25, CG, { mat: 'chrome', n: 16, olw: 0.3, noCap: 1 }) + puck },
        ...pipe(C, sP, 0.8, CG), { q: [stip[0], TY + 12, stip[2]], s: cyl3(C, stip, [stip[0], TY + 11.6, stip[2]], 0.9, CG, { mat: 'chrome', n: 14, olw: 0.25 }) }]);
      const grate = cyl3(C, [IX, TY, VZ], [IX, TY + 0.4, VZ], 4.4, CG, { mat: 'chrome', n: 24, olw: 0.3, cap: cr => rep(5, i => `<path d="M${f1(-cr * 0.8)} ${f1(-cr * 0.6 + i * cr * 0.3)}H${f1(cr * 0.8)}" stroke="#7a6230" stroke-width="0.3"/>`).join('') });
      const VB = TY + 0.4, tea = cyl3(C, [IX, VB, VZ], [IX, VB + 4, VZ], 2.4, '#fbfaf6', { r2: 3.2, mat: 'gloss', n: 22, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.92)}" fill="${CG}"/><circle r="${f1(cr * 0.84)}" fill="#e2ecec"/><path d="M${f1(cr * 0.3)} ${f1(-cr * 0.5)}l0.8 -1.6" stroke="#e8e0d0" stroke-width="0.15"/>` })
        + `<path d="${(() => { const a = C.P([IX + 3, VB + 3.2, VZ]), b = C.P([IX + 5, VB + 2.4, VZ]), c = C.P([IX + 3, VB + 1.2, VZ]); return `M${P2(a)}Q${P2(b)} ${P2(c)}`; })()}" stroke="#fbfaf6" stroke-width="${f1(0.6 * C.k)}" fill="none"/>`;
      const coupe = cyl3(C, [IX, VB, VZ], [IX, VB + 0.3, VZ], 2, '#e8f4f6', { mat: 'chrome', n: 18, op: 0.5, olw: 0.2, olc: '#8aa4aa' }) + cyl3(C, [IX, VB + 0.3, VZ], [IX, VB + 3.4, VZ], 0.25, '#e8f4f6', { mat: 'chrome', n: 10, op: 0.6, olw: 0.2, olc: '#8aa4aa' })
        + cyl3(C, [IX, VB + 3.4, VZ], [IX, VB + 5.4, VZ], 1, '#f4ecc8', { r2: 3.4, mat: 'chrome', n: 22, op: 0.55, olw: 0.3, olc: '#8aa4aa', cap: cr => `<circle r="${f1(cr * 0.96)}" fill="#f6eecc"/>` + rep(5, i => `<circle cx="${f1(Math.cos(i * 1.3) * cr * 0.5)}" cy="${f1(Math.sin(i * 1.9) * cr * 0.4)}" r="0.2" fill="#ffffff"/>`).join('') });
      const broth = cyl3(C, [IX, VB, VZ], [IX, VB + 3, VZ], 2.6, '#a8c8b0', { r2: 3.8, mat: 'gloss', n: 24, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#d8a040"/><circle r="${f1(cr * 0.9)}" fill="url(#m10cap)"/>` + rep(6, i => `<circle cx="${f1(Math.cos(i * 1.1) * cr * 0.5)}" cy="${f1(Math.sin(i * 1.7) * cr * 0.42)}" r="0.45" fill="none" stroke="#6aa04a" stroke-width="0.3"/>`).join('') + rep(4, i => `<circle cx="${f1(Math.cos(i * 2.3) * cr * 0.4)}" cy="${f1(Math.sin(i * 2.9) * cr * 0.3)}" r="0.35" fill="#f4d878" opacity="0.8"/>`).join('') });
      const NB = [stip[0], TY + 11.6, stip[2]];
      const ves = seg(0, tea + pour(C, NB, [IX, VB + 4, VZ], 0.55, '#eef8fa', 5, 0.1, 0.45) + puff1(C, [IX, VB + 4.6, VZ], 0.5, 5, 0.3, 0.9))
        + seg(1, coupe + pour(C, NB, [IX, VB + 5.4, VZ], 0.55, '#f6eecc', 5, 0.1, 0.45) + rep(5, i => bub1(C, [IX + (i - 2) * 0.6, VB + 3.8, VZ], [IX + (i - 2) * 0.7, VB + 5.6, VZ], 0.25, 2.2, i * 0.16)).join(''))
        + seg(2, broth + pour(C, NB, [IX, VB + 3, VZ], 0.6, '#d8a040', 5, 0.1, 0.45) + puff1(C, [IX, VB + 3.6, VZ], 0.55, 5, 0.35, 0.95));
      const instant = C.v[2] > 0 ? tapP + grate + ves : grate + ves + tapP;
      // decor: lemon bowl (leg), hydrangeas (corner), marble tray with oil + salt (run right)
      const lem = cyl3(C, [-96, TY, 40], [-96, TY + 5, 40], 5, '#fbfaf6', { r2: 8, mat: 'gloss', n: 28, olw: 0.3, capCol: '#ece6dc' }) + vsort(C, [[-2.6, 0], [2.4, -1], [0, 2.8], [0.4, -3], [0, 0, 1]].map(([dx, dz, up]) => { const q = [-96 + dx, TY + 6.6 + (up ? 1.8 : 0), 40 + dz]; return { q, s: sph(C, q, 2.5, '#f2d23a') + sph(C, [q[0] + 2.3, q[1], q[2]], 0.6, '#d8b82a') }; }));
      const hyd = cyl3(C, [-104, TY, -52], [-104, TY + 12, -52], 3, IV, { r2: 2.2, mat: 'gloss', n: 22, olw: 0.3, capCol: '#4a5a3a' }) + sway(C, [-104, TY + 12, -52], vsort(C, [[-3, 16, -1], [2.6, 17, 1], [0, 19.6, -0.6]].map(([dx, y, dz], j) => { const R2 = rng('hyd' + j), L = rep(18, i => { const a = i * 2.4, rr = Math.sqrt(i / 18) * 3; return [-104 + dx + Math.cos(a) * rr, TY + y + Math.sin(i * 1.7) * 1.4 + (1 - rr / 3) * 1.2, -52 + dz + Math.sin(a) * rr]; });
        return { q: [-104 + dx, TY + y, -52 + dz], s: H2(C, [-104 + dx * 0.3, TY + 12, -52], [-104 + dx, TY + y - 1, -52 + dz], 0.4, '#5a7a3a') + vsort(C, L.map(q => ({ q, s: sph(C, q, 1.05 + R2() * 0.2, R2() < 0.3 ? '#e8eef0' : '#fbfaf4') }))) }; })), 1.6, 6.4);
      const tray = box3(C, { c: [100, TY, -50], w: 18, h: 1, d: 10, r: 1.4, col: MB, gl: 0.4, olw: 0.3, dec: { t: veins(rng('wave28t'), 18, 10) } }) + vsort(C, [{ q: [96, TY + 6, -50], s: bottle(C, 96, TY + 1, -50, 1.9, 11, '#b8b030', CG, { op: 0.75, mat: 'chrome' }) }, { q: [104, TY + 2, -50], s: cyl3(C, [104, TY + 1, -50], [104, TY + 3.2, -50], 2.2, '#ece6dc', { r2: 2.8, mat: 'gloss', n: 20, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.82)}" fill="#f8f6f2"/>` + rep(10, i => `<rect x="${f1(Math.cos(i * 1.7) * cr * 0.5)}" y="${f1(Math.sin(i * 2.3) * cr * 0.4)}" width="0.4" height="0.4" fill="#ffffff" stroke="#d8d4cc" stroke-width="0.05"/>`).join('') + `<path d="M0 0L${f1(cr * 1.2)} ${f1(-cr * 0.3)}" stroke="${CG}" stroke-width="0.5"/>` }) }]);
      const items = vsort(C, [{ q: [30, TY + 10, -58], s: fau }, { q: [IX, TY + 6, -58], s: instant }, { q: [-96, TY + 5, 40], s: lem }, { q: [-104, TY + 8, -52], s: hyd }, { q: [100, TY + 3, -50], s: tray }]);
      const bsK = (v2 ? bsB : '') + (v0 ? bsL : ''), bsN = (v2 ? '' : bsB) + (v0 ? '' : bsL);
      let s = shadow(C, 25, -40, 104, 34, 0.7) + shadow(C, -96, 12, 34, 86, 0.6) + glow + bas + units + top + rim + bsK + items + bsN;
      C.p(30, TY + 28, -60);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-010 CHIPPED LAMINATE COUNTER OVER CURTAIN-SKIRTED SHELVES (T1): a yellowed painted plywood carcass with no doors, just a faded 70s daisy curtain on a
  // sagging tension rod (left panel loose and swaying, right panel tied back with a gingham ribbon). Behind it: a peeling contact-paper floor and one plywood
  // shelf of cleaning stuff (bucket + sponge, bleach jug, mousetrap with cheese, dented nested pots, spray bottle, a box of steel wool). Aqua boomerang
  // laminate top with a ribbed aluminium edge strip (one length missing, chipped particleboard), a burn ring, cuts, a lifted seam; bread bag with a twist tie,
  // red FLOUR / SUGAR tins, a stack of bills. Alive: the curtain sways, a trail of ants marches to the bread, a mouse peeks out from behind the curtain every 14 s.
  N.curt28 = S => { const TY = SKT, PW = '#e8dcbc', LA = '#9fd0c4', AL = '#c4c9cc', ZF = 25.6;
    const D = { w: 124, d: 54, arch: 'counter', topH: TY, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), R = rng('curt28');
      // carcass (front frame round a full-width opening y 5..55, x -58..58)
      const frF = specks(R, 30, 122, 4, ['#b8a070', '#8a6a40'], 0.2, 0.6, 0.5) + rep(6, () => { const x = R() < 0.5 ? R() * 3 : 119 + R() * 3, y = 6 + R() * 44; return `<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(0.4 + R() * 0.6)}" ry="${f1(0.6 + R())}" fill="#b08a58" opacity="0.6"/>`; }).join('') + `<path d="M0 3.9H122" stroke="#000000" stroke-opacity="0.15" stroke-width="0.3"/>`;
      const sdF = specks(R, 30, 52.6, 55, ['#b8a070', '#ffffff'], 0.2, 0.6, 0.4) + rep(3, () => { const x = 6 + R() * 40; return `<path d="M${f1(x)} 2Q${f1(x + 0.4)} 8 ${f1(x)} ${f1(10 + R() * 8)}" stroke="#d8c8a0" stroke-width="0.7" stroke-linecap="round" fill="none"/>`; }).join('') + scr(R, 10, 2, 44, 48, 9, '#5a4a30', 0.5);
      const kick = box3(C, { c: [0, 0, -2.5], w: 118, h: 4, d: 47, r: 0.3, col: '#4a4034', olw: 0.3, skip: { t: 1 }, dec: { f: scr(rng('curt28k'), 16, 2, 0.4, 114, 3, '#d8c8a8', 0.6) } });
      const cab = box3(C, { c: [0, 4, -0.7], w: 122, h: TY - 7, d: 52.6, r: 0.4, col: PW, olw: 0.45, olo: 0.7, skip: { t: 1 }, hole: { f: [3, 4, 3, 1] }, dec: { f: frF, l: sdF, r: sdF } });
      let inside = '';
      if (fv) { const flr = `<rect width="116" height="49.6" fill="url(#k28ging)" opacity="0.35"/><path d="M98 49.6L116 49.6L116 38Q108 44 98 49.6Z" fill="#c8a878"/><path d="M98 49.6Q108 44 116 38" stroke="#ffffff" stroke-opacity="0.6" stroke-width="0.5" fill="none"/>` + rep(5, () => `<circle cx="${f1(R() * 116)}" cy="${f1(R() * 49)}" r="${f1(0.3 + R() * 0.4)}" fill="#3a2a1a" opacity="0.5"/>`).join('');
        const bk = `<ellipse cx="70" cy="40" rx="14" ry="6" fill="#8a6a3a" opacity="0.2" filter="url(#m10b1)"/><path d="M58 50Q66 42 80 50" stroke="#8a6a3a" stroke-opacity="0.25" stroke-width="0.8" fill="none"/><circle cx="34" cy="10" r="0.5" fill="#5a5a5a"/>`;
        inside = cavity(C, -58, 58, 5, 55, -24, ZF, '#d4c49c', { dk: 0.55, floor: flr, back: bk });
        const B = 5, M = 30.4;
        const bucket = cyl3(C, [30, B, 12], [30, B + 9, 12], 5, '#3a7ac8', { r2: 6, mat: 'plastic', n: 24, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#1a3a68"/><g transform="rotate(-20)"><rect x="${f1(-cr * 0.5)}" y="${f1(-cr * 0.3)}" width="${f1(cr * 0.7)}" height="${f1(cr * 0.42)}" rx="0.5" fill="#f2d24a"/><rect x="${f1(-cr * 0.5)}" y="${f1(-cr * 0.3)}" width="${f1(cr * 0.7)}" height="${f1(cr * 0.14)}" fill="#3a8a3a"/></g>` });
        const bleach = box3(C, { c: [16, B, 8], w: 5.4, h: 11, d: 4.4, r: 1.6, col: '#f4f4f0', gl: 0.3, olw: 0.3, dec: { f: `<rect x="0.6" y="3" width="4.2" height="4" fill="#3a6ac8" opacity="0.8"/><text x="2.7" y="5.6" text-anchor="middle" ${FONT} font-size="0.9" fill="#ffffff">BLEACH</text>` } }) + cyl3(C, [16, B + 11, 8], [16, B + 12.6, 8], 1.2, '#3a6ac8', { mat: 'gloss', n: 14, olw: 0.25 });
        const trap = box3(C, { c: [41, B, 20], w: 7, h: 0.6, d: 3.4, r: 0.2, col: '#d8b47a', olw: 0.25, dec: { t: `<rect x="1" y="0.5" width="5" height="2.4" fill="none" stroke="#9aa0a4" stroke-width="0.25"/>` } }) + box3(C, { c: [42.6, B + 0.6, 20], w: 1.8, h: 1.2, d: 1.6, r: 0.2, col: '#f2c84a', olw: 0.2 });
        const low = vsort(C, [{ q: [30, B + 4, 12], s: bucket }, { q: [16, B + 5, 8], s: bleach }, { q: [41, B + 0.5, 20], s: trap }]);
        const shelf = box3(C, { c: [0, M - 1.4, -0.5], w: 116, h: 1.4, d: 47, r: 0, col: '#c8a878', olw: 0.3, dec: { f: specks(R, 30, 116, 1.4, ['#8a6a40', '#e8d0a0'], 0.15, 0.3, 0.7) } });
        const pots = cyl3(C, [18, M, 14], [18, M + 5, 14], 6, '#b8bcc0', { mat: 'metal', n: 26, olw: 0.3, noCap: 1 }) + cyl3(C, [18, M + 2.6, 14], [18, M + 7.2, 14], 4.8, '#a8acb0', { mat: 'metal', n: 24, olw: 0.3, capCol: '#4a4e52' }) + `<g transform="${tanF(C, 18, 14, 6.05, C.thV + 0.4, M + 2.4)}">${dent(0, 0, 1.6, 1, 0, 1.4)}</g>`;
        const spray = cyl3(C, [32, M, 17], [32, M + 7, 17], 2, '#cfe8c4', { mat: 'gloss', n: 18, op: 0.75, olw: 0.3, olc: '#5a8a4a' }) + box3(C, { c: [32, M + 7, 17], w: 2.6, h: 2.4, d: 3.4, r: 0.6, col: '#f4f4f0', olw: 0.25 }) + stick(C, [32, M + 8.8, 18.6], [32, M + 8.8, 20], 0.4, '#f4f4f0');
        const wool = box3(C, { c: [40, M, 12], w: 6, h: 3, d: 4, r: 0.3, col: '#e8c24a', olw: 0.3, dec: { f: `<text x="3" y="2" text-anchor="middle" ${FONT} font-size="1" fill="#c83a2a">SCRUB-O</text>` } });
        const up = vsort(C, [{ q: [18, M + 3, 14], s: pots }, { q: [32, M + 4, 17], s: spray }, { q: [40, M + 1.5, 12], s: wool }]);
        const mouse = `<g>${at('translate', '-8 0;-8 0;0 0;0 0;-8 0;-8 0', 14, 0, KT('0;0.62;0.66;0.82;0.86;1'))}<ellipse cx="-4" cy="-2" rx="4" ry="2.4" fill="#8a8a8e"/><path d="M-2.4 -4.2Q1.6 -4.4 3 -2.4Q1.4 -0.6 -2.2 -0.6Z" fill="#9a9a9e"/><circle cx="-1.2" cy="-4.6" r="1.3" fill="#8a8a8e"/><circle cx="-1.2" cy="-4.6" r="0.75" fill="#e8a8b0"/><circle cx="0.8" cy="-2.9" r="0.4" fill="#1a1a1a"/><circle cx="0.9" cy="-3" r="0.12" fill="#ffffff"/><circle cx="3" cy="-2.4" r="0.38" fill="#e88a9a"/><path d="M2.6 -2.2L5 -1.6M2.6 -2.5L5 -2.8M2.6 -2.3L4.6 -0.9" stroke="#3a3a3a" stroke-width="0.12"/></g>`;
        inside += low + shelf + up + PLN(C, [8, B + 0.05, ZF - 7], [1, 0, 0], [0, -1, 0], mouse); }
      // curtain on a sagging rod
      let curt = '';
      if (fv) { const H0 = 48.6; let hem = 'M0 0H66V47.6'; for (let i = 0; i < 10; i++) { const x = 66 - i * 6.6; hem += `Q${f1(x - 3.3)} 49.2 ${f1(x - 6.6)} 47.6`; } hem += 'Z';
        const lp = `<g>${at('skewX', '0;1.4;-1;0', 7, 0, SPL(3))}<path d="${hem}" fill="url(#k28flr)"/><path d="${hem}" fill="url(#k28fold)"/><path d="${hem}" fill="url(#m10v)"/><rect width="66" height="3" fill="#000000" opacity="0.1"/>` + rep(22, i => `<path d="M${f1(1.5 + i * 3)} 0.2V2.8" stroke="#5a4a30" stroke-opacity="0.3" stroke-width="0.35"/>`).join('')
          + `<ellipse cx="18" cy="44" rx="7" ry="3.4" fill="#8a6a3a" opacity="0.22" filter="url(#m10b1)"/><path d="M50 47.8L53 44.6L55.4 48.2Z" fill="#2a2018" opacity="0.55"/><path d="M51 44.2h3.4" stroke="#c8ccd0" stroke-width="0.4"/><circle cx="51" cy="44.2" r="0.4" fill="none" stroke="#c8ccd0" stroke-width="0.25"/></g>`;
        const tp = 'M0 0H12V3Q11 14 9.4 22Q11.8 34 12 47.4Q6 48.8 0.4 47.4Q2.6 34 5.4 22Q3 12 0 3Z';
        const rp = `<g>${at('rotate', '-0.8 6 0;0.8 6 0;-0.8 6 0', 6, 0, SPL(2))}<path d="${tp}" fill="url(#k28flr)"/><path d="${tp}" fill="url(#k28fold)"/><path d="${tp}" fill="url(#m10v)"/><g transform="rotate(-8 7.4 22)"><rect x="4.4" y="20.8" width="6.4" height="2.4" fill="url(#k28ging)"/><path d="M4.6 22Q2 19.6 2.6 23Q4 24 4.6 22ZM10.6 22Q13 19.8 12.4 23.2Q11 24 10.6 22Z" fill="url(#k28ging)" stroke="#a8362a" stroke-width="0.2"/><path d="M7 23.2L5.6 27.6M8 23.2L9.2 27.8" stroke="#c8453a" stroke-width="0.9"/></g></g>`;
        const rod = cyl3(C, [-59, 55, ZF + 1.2], [0, 54.3, ZF + 1.2], 0.45, AL, { mat: 'chrome', n: 10, olw: 0.2 }) + cyl3(C, [0, 54.3, ZF + 1.2], [59, 55, ZF + 1.2], 0.45, AL, { mat: 'chrome', n: 10, olw: 0.2 });
        curt = rod + PLN(C, [-58, 54.8, ZF + 1.4], [1, 0, 0], [0, -1, 0], lp) + PLN(C, [46, 54.9, ZF + 1.4], [1, 0, 0], [0, -1, 0], rp); }
      // aluminium-edged laminate slab + top + backsplash
      const rib = L => rep(3, i => `<path d="M0 ${f1(0.6 + i * 0.9)}H${f1(L)}" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.25"/><path d="M0 ${f1(1 + i * 0.9)}H${f1(L)}" stroke="#5a6064" stroke-opacity="0.4" stroke-width="0.2"/>`).join('');
      const slab = box3(C, { c: [0, TY - 3, 0.5], w: 124, h: 3, d: 55, r: 0.4, col: AL, gl: 0.3, olw: 0.4, skip: { t: 1 }, dec: { f: rib(124) + `<rect x="70" width="14" height="3" fill="#c8a878"/>` + `<g transform="translate(70 0)">${specks(R, 18, 14, 3, ['#8a6a40', '#e8d0a0'], 0.15, 0.35, 0.8)}</g>` + `<path d="M70 0V3M84 0V3" stroke="#3a3a3a" stroke-opacity="0.5" stroke-width="0.3"/><path d="M84 0.2Q86 -0.6 87 0.6" stroke="#ffffff" stroke-opacity="0.6" stroke-width="0.4" fill="none"/>`, l: rib(55), r: rib(55) } });
      const Rt = rng('curt28t'), boom = (x, y, r, c) => `<path transform="translate(${f1(x)} ${f1(y)}) rotate(${f1(r)})" d="M-2.2 0.4Q0 -1.8 2.2 0.4Q0 -0.6 -2.2 0.4Z" fill="${c}" opacity="0.55"/>`;
      const topD = rep(70, () => boom(Rt() * 124, Rt() * 55, Rt() * 360, Rt() < 0.5 ? '#6ab0a4' : '#d8f0ea')).join('') + rep(40, () => `<path transform="translate(${f1(Rt() * 124)} ${f1(Rt() * 55)})" d="M0 -0.7V0.7M-0.7 0H0.7" stroke="#e8c24a" stroke-opacity="0.6" stroke-width="0.25"/>`).join('')
        + `<rect x="30" y="36" width="56" height="18" rx="6" fill="#ffffff" opacity="0.14" filter="url(#m10b2)"/><g transform="translate(58 30)"><ellipse rx="3.4" ry="2.6" fill="#5a3a1a" opacity="0.3" filter="url(#m10b1)"/><ellipse rx="2.8" ry="2.2" fill="none" stroke="#3a2010" stroke-opacity="0.45" stroke-width="0.5"/></g>`
        + scr(Rt, 18, 66, 18, 30, 20, '#3a5a54', 0.5) + `<path d="M92 0V55" stroke="#3a5a54" stroke-opacity="0.4" stroke-width="0.35"/><path d="M92.4 30V55" stroke="#ffffff" stroke-opacity="0.35" stroke-width="0.3"/>`
        + [[70, 14, 2.4], [20, 3, 1.6], [104, 3.4, 1.8]].map(([x, w, d]) => `<path d="M${x} 55Q${f1(x + w * 0.3)} ${f1(55 - d)} ${f1(x + w * 0.6)} ${f1(55 - d * 0.6)}T${f1(x + w)} 55Z" fill="#c8a878"/><g transform="translate(${x} ${f1(55 - d * 0.6)})">${specks(Rt, 5, w, d * 0.6, ['#8a6a40'], 0.12, 0.25, 0.8)}</g>`).join('')
        + `<path d="M104 1.5C90 4 80 2 70 6S50 10 44 14S32 18 28 20" stroke="#2a1a10" stroke-opacity="0.8" stroke-width="0.45" stroke-linecap="round" stroke-dasharray="0.01 1.6" fill="none">${an('stroke-dashoffset', '0;-16.1', 8)}</path>`
        + rep(8, () => `<circle cx="${f1(24 + Rt() * 8)}" cy="${f1(18 + Rt() * 6)}" r="${f1(0.2 + Rt() * 0.3)}" fill="#d8b070"/>`).join('');
      const top = ctopH(C, -62, 62, -27, 28, TY, LA, [], topD);
      const bs = box3(C, { c: [0, TY, -26], w: 124, h: 5, d: 2, r: 0.3, col: LA, olw: 0.35, dec: { f: rep(14, () => boom(Rt() * 124, 0.8 + Rt() * 3.4, Rt() * 360, '#6ab0a4')).join('') + `<rect width="124" height="0.8" fill="${AL}"/><path d="M0 4.6H124" stroke="#e8d890" stroke-width="0.9"/>` + rep(12, i => `<circle cx="${f1(5 + i * 10 + Rt() * 3)}" cy="4.5" r="0.3" fill="#3a3a20" opacity="0.55"/>`).join(''), t: `<rect width="124" height="2" fill="${AL}"/>` } });
      // counter things
      const bag = box3(C, { c: [-40, TY, -8], w: 10, h: 6.4, d: 15, r: 3, col: '#f4efe4', gl: 0.5, olw: 0.3, dec: { t: rep(14, i => `<circle cx="${f1(1.5 + (i % 4) * 2.4)}" cy="${f1(1.6 + Math.floor(i / 4) * 3.6)}" r="0.7" fill="${['#d8382e', '#f2c43a', '#3a7ac8'][i % 3]}" opacity="0.8"/>`).join(''), l: `<text x="7.5" y="4" text-anchor="middle" font-family="Georgia,serif" font-weight="700" font-size="2" fill="#d8382e">Sunny</text>`, r: `<text x="7.5" y="4" text-anchor="middle" font-family="Georgia,serif" font-weight="700" font-size="2" fill="#d8382e">Sunny</text>`, f: rep(5, i => `<circle cx="${f1(1.5 + i * 1.8)}" cy="3" r="0.6" fill="${['#d8382e', '#f2c43a', '#3a7ac8'][i % 3]}" opacity="0.8"/>`).join('') } })
        + cyl3(C, [-40, TY + 3.2, -15.4], [-40, TY + 3.4, -19], 2.8, '#f4efe4', { r2: 0.9, mat: 'gloss', n: 16, olw: 0.25 }) + cyl3(C, [-40, TY + 3.4, -18.8], [-40, TY + 3.4, -19.6], 1.1, '#d8382e', { n: 12, olw: 0.2 }) + H2(C, [-40, TY + 3.4, -19.2], [-41.4, TY + 1.6, -20], 0.35, '#d8382e') + H2(C, [-40, TY + 3.4, -19.2], [-38.6, TY + 2, -20.4], 0.35, '#d8382e')
        + cyl3(C, [-40, TY + 3.4, -19.6], [-40.4, TY + 3, -22], 1, '#f4efe4', { r2: 1.6, mat: 'gloss', n: 12, olw: 0.2 });
      const tin = (x, z, r, h, t) => cyl3(C, [x, TY, z], [x, TY + h, z], r, '#c8382e', { mat: 'gloss', n: 24, olw: 0.3, noCap: 1 }) + cyl3(C, [x, TY + h, z], [x, TY + h + 1.2, z], r + 0.15, '#b83228', { mat: 'gloss', n: 24, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.82)}" fill="none" stroke="#8a2a20" stroke-width="0.3"/>` + rep(4, i => `<circle cx="${f1(Math.cos(i * 1.9) * cr * 0.88)}" cy="${f1(Math.sin(i * 1.9) * cr * 0.88)}" r="0.35" fill="#8a4a22" opacity="0.7"/>`).join('') }) + sph(C, [x, TY + h + 1.8, z], 0.8, '#f4f0e6')
        + `<g transform="${tanF(C, x, z, r + 0.03, C.thV, TY + h * 0.5)}"><text y="0.6" text-anchor="middle" font-family="Georgia,serif" font-weight="700" font-size="${f1(r * 0.42)}" fill="#f8f2e4">${t}</text><path d="M${f1(-r * 0.8)} ${f1(-h * 0.3)}H${f1(r * 0.8)}M${f1(-r * 0.8)} ${f1(h * 0.28)}H${f1(r * 0.8)}" stroke="#f8f2e4" stroke-width="0.25"/></g>`
        + (Math.cos(C.thV - 0.3) > 0.3 ? `<g transform="${tanF(C, x, z, r + 0.05, 0.3, TY + h * 0.75)}">${dent(0, 0, 1.2, 0.8, 0, 1.2)}</g>` : '');
      const mail = rep(4, i => box3(C, { c: [42 + (i % 2) * 0.6, TY + i * 0.36, 6 - i * 0.3], ax: yawA((i - 1.5) * 0.12), w: 9.4, h: 0.36, d: 5.6, r: 0.1, col: ['#f4f2ee', '#e8d8b0', '#f8d8e0', '#f4f2ee'][i], olw: 0.2, edge: 0, dec: i === 3 ? { t: `<rect x="7.2" y="0.6" width="1.6" height="1.8" fill="#c84a3a"/><path d="M2 2.6H6M2 3.4H6.6M2 4.2H5.4" stroke="#3a3a3a" stroke-opacity="0.5" stroke-width="0.3"/><text x="2" y="1.4" ${FONT} font-size="0.8" fill="#c82a2a">PAST DUE</text>` } : {} })).join('');
      const items = vsort(C, [{ q: [-40, TY + 3, -10], s: bag }, { q: [18, TY + 5, -18], s: tin(18, -18, 3.8, 10, 'FLOUR') }, { q: [27.4, TY + 4, -19], s: tin(27.4, -19, 3.1, 7.8, 'SUGAR') }, { q: [42, TY + 1, 6], s: mail }]);
      let s = shadow(C, 0, 0, 66, 32, 0.8) + inside + kick + cab + curt + slab + top + (fv ? bs + items : items + bs);
      C.p(0, TY + 16, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // ---------- Base Cabinetry batch (KIT-030 / 050 / 070): 124 x 54 counters, top at y 62 like the sinks; front face u 0..122 from x -61, v 0..55 down from y 59 ----------
  const shkP = (x, y, w, h, bw, dk) => { const b = Math.min(bw || 4.2, w * 0.16); return `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="none" stroke="#000000" stroke-opacity="${dk || 0.38}" stroke-width="0.45"/><path d="M${f1(x + 0.3)} ${f1(y + h)}V${f1(y + 0.3)}H${f1(x + w)}" stroke="#ffffff" stroke-opacity="0.22" stroke-width="0.35" fill="none"/>`
    + `<rect x="${f1(x + b)}" y="${f1(y + b)}" width="${f1(w - 2 * b)}" height="${f1(h - 2 * b)}" fill="#000000" opacity="0.05"/><path d="M${f1(x + b)} ${f1(y + h - b)}V${f1(y + b)}H${f1(x + w - b)}" stroke="#000000" stroke-opacity="0.28" stroke-width="0.55" fill="none"/><path d="M${f1(x + b)} ${f1(y + h - b)}H${f1(x + w - b)}V${f1(y + b)}" stroke="#ffffff" stroke-opacity="0.3" stroke-width="0.45" fill="none"/>`; };
  const cupPl = (C, x, y, z, col, mat) => cyl3(C, [x - 3, y + 0.1, z + 0.9], [x + 3, y + 0.1, z + 0.9], 0.9, col, { mat, n: 14, olw: 0.2 }) + [x - 3.2, x + 3.2].map(xx => box3(C, { c: [xx, y - 0.5, z + 0.6], w: 1.2, h: 1.6, d: 1.2, r: 0.3, col, olw: 0.2 })).join('');
  const vbar = (C, x, y0, y1, z, out, r, col, mat) => [y0 + 1.6, y1 - 1.6].map(y => cyl3(C, [x, y, z], [x, y, z + out], r * 0.7, col, { mat, n: 10, olw: 0.2 })).join('') + cyl3(C, [x, y0, z + out], [x, y1, z + out], r, col, { mat, n: 12, olw: 0.22 });
  const butcher = (R, lt, OAK) => { const sv = []; for (let v = 0; v < 55; v += 3.6) { let u = -R() * 30; while (u < 124) { const L = 26 + R() * 40; sv.push([u, v, L, 0.9 + R() * 0.2]); u += L; } }
    return sv.map(([u, v, L, f]) => `<rect x="${f1(u)}" y="${f1(v)}" width="${f1(L)}" height="3.6" fill="${shade(OAK, lt * f)}"/><path d="M${f1(u)} ${f1(v + 1.2 + R() * 1.2)}Q${f1(u + L / 2)} ${f1(v + 0.6 + R() * 2.4)} ${f1(u + L)} ${f1(v + 1.4 + R())}" stroke="#7a4a22" stroke-opacity="0.22" stroke-width="0.25" fill="none"/><path d="M${f1(u)} ${f1(v)}V${f1(v + 3.6)}" stroke="#5a3418" stroke-opacity="0.35" stroke-width="0.25"/>`).join('')
      + rep(16, i => `<path d="M0 ${f1(i * 3.6)}H124" stroke="#5a3418" stroke-opacity="0.18" stroke-width="0.2"/>`).join('') + `<rect width="124" height="55" fill="url(#m10s)" opacity="0.5"/>`; };
  const ssV = (R, w, h) => rep(7, () => { const e = R() < 0.5, a = R() * w, b = R() * h; return `<ellipse cx="${f1(a)}" cy="${f1(b)}" rx="${f1(4 + R() * 10)}" ry="${f1(2 + R() * 5)}" fill="${e ? '#5a605e' : '#30353a'}" opacity="0.13" filter="url(#m10b2)"/>`; }).join('')
    + rep(9, () => { const x = R() * w, y = R() * h, dx = (R() - 0.5) * w * 0.4, dy = (R() - 0.5) * h * 0.8; return `<path d="M${f1(x)} ${f1(y)}C${f1(x + dx * 0.3 + 3)} ${f1(y + dy * 0.4)} ${f1(x + dx * 0.7 - 3)} ${f1(y + dy * 0.6)} ${f1(x + dx)} ${f1(y + dy)}" stroke="#d8e2dc" stroke-opacity="${n4(0.12 + R() * 0.2)}" stroke-width="${f1(0.15 + R() * 0.3)}" fill="none"/>`; }).join('');
  const subway = (W, H, col) => { let s = `<rect width="${W}" height="${H}" fill="#d8d2c6"/>`; for (let r = 0; r * 3 < H; r++) for (let x = r % 2 ? -3.8 : 0; x < W; x += 7.6) s += `<rect x="${f1(x + 0.2)}" y="${f1(r * 3 + 0.2)}" width="7.2" height="2.6" rx="0.4" fill="${col}"/><path d="M${f1(x + 0.8)} ${f1(r * 3 + 0.7)}H${f1(x + 5.6)}" stroke="#ffffff" stroke-opacity="0.75" stroke-width="0.3"/>`; return s; };
  const baseUnit = (C, col, kc, cabF, cabS, gl, kdec) => box3(C, { c: [0, 0, -2.5], w: 118, h: 4, d: 47, r: 0.3, col: kc, olw: 0.3, skip: { t: 1 }, dec: { f: kdec || '' } }) + box3(C, { c: [0, 4, -0.7], w: 122, h: SKT - 7, d: 52.6, r: 0.4, col, gl: gl || 0.25, olw: 0.45, olo: 0.7, skip: { t: 1 }, dec: { f: cabF, l: cabS, r: cabS } });

  // KIT-030 BUTCHER-BLOCK COUNTER WITH WHITE SHAKER BASE CABINETS (T2): warm white shaker drawers + doors, brushed nickel cup pulls + knobs (a few scuffs by the kick,
  // one chip), oiled oak butcher block (staves, end grain on the sides), white subway-tile splash. Counter: a crusty loaf + two slices + bread knife on a board,
  // a glass jar of wooden spoons, a bowl of apples, a mug of tea (steam), an open cookbook on a wooden stand (a page lifts now and then). Red gingham towel sways.
  N.shk28 = S => { const TY = SKT, WH = '#f1eee6', OAK = '#c8975e', NI = '#b9bdc1', ZF = 25.6;
    const D = { w: 124, d: 54, arch: 'counter', topH: TY, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), R = rng('shk28'), lt = lit(C, [0, 1, 0]);
      const cabF = [[1, 1, 39.6, 11], [41.2, 1, 39.6, 11], [82.4, 1, 38.6, 11], [1, 13, 39.6, 41], [41.2, 13, 19.4, 41], [61.4, 13, 19.4, 41], [82.4, 13, 38.6, 41]].map(p => shkP(...p)).join('')
        + scr(R, 10, 3, 50, 116, 4, '#6a6458', 0.4) + `<path d="M58 54.4l1.2 -1l1.4 1Z" fill="#c8b898"/>` + fp(57.6, 20, 0.9, 10, 0.12) + fp(64.6, 21, 0.9, -10, 0.12);
      const cabS = `<rect width="52.6" height="55" fill="url(#m10s)" opacity="0.3"/>`;
      const unit = baseUnit(C, WH, '#ddd8cc', cabF, cabS, 0.25, scr(rng('shk28k'), 12, 2, 0.4, 114, 3, '#7a7466', 0.5));
      const towX = `<rect width="12" height="16" fill="url(#k28ging)"/><rect y="13.6" width="12" height="0.6" fill="#ffffff" opacity="0.6"/>` + rep(12, i => `<path d="M${f1(0.5 + i)} ${f1(15.8 + (i % 2) * 0.2)}v0.9" stroke="#d8453a" stroke-width="0.25"/>`).join('');
      const fr = vsort(C, [-40.2, 0, 40.7].map(x => ({ q: [x, 52.5, ZF], s: cupPl(C, x, 52.5, ZF, NI, 'metal') })).concat([[-25, 39], [-4, 39], [4, 39], [25, 39]].map(([x, y]) => ({ q: [x, y, ZF + 1], s: knobB(C, x, y, ZF, 1.2, NI, 'metal') }))))
        + PLN(C, [-46.2, 53.4, ZF + 2], [1, 0, 0], [0, -1, 0], towS(12, 16, '#fbf4ec', towX, 5.6));
      const edF = rep(5, i => `<path d="M0 ${f1(0.6 + i * 0.7)}Q62 ${f1(0.3 + i * 0.8)} 124 ${f1(0.7 + i * 0.7)}" stroke="#7a4a22" stroke-opacity="0.25" stroke-width="0.2" fill="none"/>`).join('');
      const edS = rep(16, i => `<rect x="${f1(i * 3.6)}" width="3.6" height="4" fill="#000000" opacity="${i % 2 ? 0.04 : 0.1}"/><path d="M${f1(i * 3.6 + 0.6)} 4Q${f1(i * 3.6 + 1.8)} 0.8 ${f1(i * 3.6 + 3)} 4" stroke="#5a3418" stroke-opacity="0.3" stroke-width="0.2" fill="none"/>`).join('');
      const slab = box3(C, { c: [0, TY - 4, 0.5], w: 124, h: 4, d: 55, r: 0.4, col: OAK, olw: 0.4, skip: { t: 1 }, dec: { f: edF, b: edF, l: edS, r: edS } });
      const top = ctopH(C, -62, 62, -27, 28, TY, OAK, [], butcher(rng('shk28b'), lt, OAK) + scr(R, 10, 20, 30, 30, 18, '#5a3418', 0.35) + `<circle cx="74" cy="34" r="2.6" fill="none" stroke="#5a3418" stroke-opacity="0.12" stroke-width="0.6"/>`);
      const bs = box3(C, { c: [0, TY, -26], w: 124, h: 9, d: 2, r: 0.3, col: '#f6f4ee', gl: 0.5, olw: 0.35, dec: { f: subway(124, 9, '#f8f6f0') } });
      // counter things
      const crumb = cr => `<circle r="${f1(cr * 0.86)}" fill="#f2e0b4"/>` + rep(9, i => `<circle cx="${f1(Math.cos(i * 2.3) * cr * 0.5)}" cy="${f1(Math.sin(i * 1.7) * cr * 0.5)}" r="${f1(0.2 + (i % 3) * 0.12)}" fill="#c8a868"/>`).join('');
      const board = box3(C, { c: [-31, TY, -4], w: 24, h: 1.6, d: 14, r: 1.6, col: '#b07a44', olw: 0.3, dec: { t: grainH(rng('shk28g'), 24, 14, 9, '#6a4220') + `<circle cx="21.4" cy="7" r="0.9" fill="#4a2a10" opacity="0.6"/>` } });
      const loaf = cyl3(C, [-39, TY + 4.8, -6], [-29, TY + 4.8, -6], 3.4, '#c08440', { mat: 'matte', n: 22, olw: 0.3, cap: C.v[0] > 0 ? crumb : undefined, capCol: C.v[0] > 0 ? undefined : '#a8682e' })
        + [-37, -34.4, -31.8].map(x => `<path d="M${P2(C.P([x, TY + 8, -8.4]))}Q${P2(C.P([x + 1, TY + 8.4, -6]))} ${P2(C.P([x + 0.4, TY + 8, -3.6]))}" stroke="#f2d8a0" stroke-width="${f1(0.5 * C.k)}" fill="none"/>`).join('');
      const slices = [[-24, 0], [-22.4, -3]].map(([x, z], i) => cyl3(C, [x, TY + 1.6 + i * 0.7, z], [x, TY + 2.3 + i * 0.7, z], 3, '#c08440', { mat: 'matte', n: 20, olw: 0.25, cap: crumb })).join('');
      const knife = H2(C, [-31, TY + 1.8, 3.6], [-22, TY + 1.8, 5.4], 1, '#d0d6da') + H2(C, [-22, TY + 1.9, 5.4], [-17.4, TY + 1.9, 6.2], 1.3, '#3a2a1e');
      const onB = vsort(C, [{ q: [-34, TY + 4, -6], s: loaf }, { q: [-23, TY + 2, -1.5], s: slices }, { q: [-26, TY + 2, 4.6], s: knife }]);
      const jarS = cyl3(C, [-50, TY, -18], [-50, TY + 8, -18], 3, '#e8f4f4', { mat: 'gloss', n: 20, op: 0.35, olw: 0.3, olc: '#8aa0a4', noCap: 1 })
        + vsort(C, [[-1.2, -0.4, -1.6, 14], [1, 0.2, 1.4, 15.4], [0, 0.8, 0.2, 13.4]].map(([dx, dz, tx, h]) => { const t = [-50 + tx * 1.6, TY + h, -18 + dz]; return { q: t, s: H2(C, [-50 + dx, TY + 1, -18 + dz], t, 0.65, '#c8945a') + sph(C, [t[0], t[1] + 1.2, t[2]], 1.3, '#c8945a') }; }));
      const bowl = cyl3(C, [28, TY, -8], [28, TY + 4, -8], 4, '#e8e2d6', { r2: 7, mat: 'gloss', n: 26, olw: 0.3, capCol: '#cfc8b8' }) + vsort(C, [[-2.4, 0, '#c8382a'], [2.6, -0.8, '#a8c040'], [0, -3, '#d84a30'], [0.4, 2.8, '#c8382a'], [0, 0, '#d84a30', 1]].map(([dx, dz, c, up]) => { const q = [28 + dx, TY + 5 + (up ? 1.6 : 0), -8 + dz]; return { q, s: sph(C, q, 2.3, c) + H2(C, [q[0], q[1] + 2, q[2]], [q[0] + 0.4, q[1] + 2.9, q[2]], 0.3, '#5a3a1a') }; }));
      const mug = mug2(C, 8, TY, 8, 2.6, 6, '#7a9ab8', '#a8642a') + H2(C, [8.8, TY + 5.8, 8.6], [10.4, TY + 3, 9.6], 0.12, '#f4f0e6') + PLN(C, [10.4, TY + 3, 10.2], [1, 0, 0], [0, -1, 0], `<rect x="-0.8" width="1.6" height="1.8" fill="#f2c84a"/>`) + shim(C, 8, TY + 6.4, 8, 1.8, 3, 0.55);
      const tt = 65 * PI / 180, bn = [0, Math.cos(tt), Math.sin(tt)], BO = [36, TY + 1.6 + 12 * Math.sin(tt), -14 - 12 * Math.cos(tt)], BV = [0, -Math.sin(tt), Math.cos(tt)];
      const pages = `<rect width="20" height="12" fill="#fbf6ea"/><rect x="8.6" width="2.8" height="12" fill="#000000" opacity="0.08"/><text x="5" y="2.2" text-anchor="middle" font-family="Georgia,serif" font-size="1.3" fill="#7a2a1a">Apple Crumble</text>` + rep(7, i => `<path d="M1.4 ${f1(3.6 + i * 1.1)}H${f1(i % 3 === 2 ? 6 : 8.4)}" stroke="#6a6458" stroke-opacity="0.45" stroke-width="0.3"/>`).join('')
        + `<rect x="11.4" y="1.2" width="7.4" height="5.4" fill="#e8c890"/><ellipse cx="15.1" cy="4.6" rx="2.8" ry="1.3" fill="#c87a3a"/><ellipse cx="15.1" cy="4" rx="2.6" ry="0.9" fill="#e8b060"/>` + rep(4, i => `<path d="M11.6 ${f1(8 + i * 1)}H${f1(18.4 - (i % 2) * 2)}" stroke="#6a6458" stroke-opacity="0.45" stroke-width="0.3"/>`).join('')
        + `<path d="M10 0H20V12H10Z" fill="#fbf6ea" opacity="0">${an('d', 'M10 0H20V12H10Z;M10 0H20V12H10Z;M10 0H16Q18 6 16.4 12H10Z;M10 0H20V12H10Z;M10 0H20V12H10Z', 10, 0, KT('0;0.7;0.78;0.88;1'))}${an('opacity', '0;0;1;0;0', 10, 0, KT('0;0.7;0.78;0.88;1'))}</path><rect width="20" height="12" fill="none" stroke="#c8b898" stroke-width="0.25"/>`;
      const book = vis(C, bn) ? PLN(C, BO, [1, 0, 0], BV, pages) : PLN(C, add(BO, [20, 0, 0]), [-1, 0, 0], BV, `<rect width="20" height="12" rx="0.4" fill="#8a3a2a"/><rect x="9.4" width="1.2" height="12" fill="#6a2a1a"/>`);
      const leg = H2(C, [46, TY + 7, -18], [46, TY, -22.4], 0.9, '#9a6838'), lip = box3(C, { c: [46, TY, -13.4], w: 22, h: 1.6, d: 1.8, r: 0.3, col: '#b07a44', olw: 0.25 }), bookG = C.v[2] > 0 ? leg + book + lip : lip + book + leg;
      const items = vsort(C, [{ q: [-31, TY + 1, -4], s: board + onB }, { q: [-50, TY + 5, -18], s: jarS }, { q: [28, TY + 3, -8], s: bowl }, { q: [8, TY + 3, 8], s: mug }, { q: [46, TY + 4, -17], s: bookG }]);
      let s = shadow(C, 0, 0, 66, 32, 0.8) + unit + (fv ? fr : '') + slab + top + (fv ? bs + items : items + bs);
      C.p(0, TY + 20, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-050 SPECKLED WHITE QUARTZ COUNTER WITH NAVY SOFT-CLOSE CABINETS (T3): deep navy slim-shaker drawers + doors, brushed brass bar pulls (horizontal on the
  // drawers, vertical on the doors), speckled white quartz top + low splash. The top-left cutlery drawer glides open every 14 s (bamboo organizer of forks,
  // spoons, knives + a whisk) and soft-closes slowly. Counter: glass canisters of pasta + coffee beans with bamboo lids, a sourdough boule on a round board,
  // a white bowl of oranges, eucalyptus in a slim white vase swaying.
  N.navy28 = S => { const TY = SKT, NV = '#26344f', QZ = '#f3f1ec', BR = '#c9a256', ZF = 25.6;
    const D = { w: 124, d: 54, arch: 'counter', topH: TY, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), R = rng('navy28');
      const cabF = `<rect x="0.6" y="0.6" width="40.4" height="11.8" fill="#0c1220"/>` + [[1, 13, 39.6, 19.6], [1, 34, 39.6, 20], [41.2, 1, 39.6, 11], [41.2, 13, 19.4, 41], [61.4, 13, 19.4, 41], [82.4, 1, 38.6, 11], [82.4, 13, 38.6, 41]].map(p => shkP(...p, 2.6, 0.55)).join('') + `<rect width="122" height="55" fill="url(#m10s)" opacity="0.35"/>`;
      const cabS = `<rect width="52.6" height="55" fill="url(#m10s)" opacity="0.3"/>`;
      const unit = baseUnit(C, NV, '#141a26', cabF, cabS, 0.35);
      const hb = (x, y) => barH(C, x - 7, x + 7, y, ZF, 2.4, 0.7, BR, 'chrome', 1.4);
      const frS = vsort(C, [[-40.2, 36.2], [-40.2, 21], [0, 52.5], [40.7, 52.5]].map(([x, y]) => ({ q: [x, y, ZF + 1], s: hb(x, y) })).concat([[-3.4], [3.4], [25]].map(([x]) => ({ q: [x, 35, ZF + 1], s: vbar(C, x, 28, 42, ZF, 2.2, 0.6, BR, 'chrome') }))));
      // the soft-close cutlery drawer
      const dFront = box3(C, { c: [-40.2, 47, ZF + 0.9], w: 39.6, h: 11, d: 1.8, r: 0.3, col: NV, gl: 0.35, olw: 0.35, dec: { f: shkP(0, 0, 39.6, 11, 2.6, 0.55) } }) + hb(-40.2, 52.5);
      let drawer = dFront;
      if (C.v[2] > 0.5) { const org = `<rect width="35.6" height="16" fill="#d8b47e"/>` + [7, 14, 21.6, 28.6].map(x => `<path d="M${x} 0V16" stroke="#a8804a" stroke-width="0.7"/>`).join('') + `<path d="M0 8H7" stroke="#a8804a" stroke-width="0.7"/>`
          + rep(3, i => `<g transform="translate(${f1(9 + i * 1.8)} 1.6)"><rect x="-0.25" y="4" width="0.5" height="9" rx="0.25" fill="#c8ced2"/><path d="M-0.8 0V3.2Q0 4.6 0.8 3.2V0M0 0V3" stroke="#c8ced2" stroke-width="0.3" fill="none"/></g>`).join('')
          + rep(3, i => `<g transform="translate(${f1(16.4 + i * 1.8)} 1.6)"><ellipse cy="1.6" rx="0.9" ry="1.6" fill="#d4dade"/><rect x="-0.25" y="3" width="0.5" height="10" rx="0.25" fill="#c8ced2"/></g>`).join('')
          + rep(2, i => `<g transform="translate(${f1(24 + i * 2)} 1.4)"><path d="M-0.5 0H0.5L0.6 7H-0.6Z" fill="#dfe4e8"/><rect x="-0.5" y="7" width="1" height="6" rx="0.4" fill="#2a2a2c"/></g>`).join('')
          + `<g transform="translate(32 1.4)"><path d="M0 4C-2 2 -2 -0.4 0 -0.6C2 -0.4 2 2 0 4ZM0 4C-1 2 -1 0 0 -0.6C1 0 1 2 0 4Z" fill="none" stroke="#c8ced2" stroke-width="0.25"/><rect x="-0.4" y="4" width="0.8" height="8" rx="0.4" fill="#c8ced2"/></g><g transform="translate(3.5 2)"><rect x="-1.6" width="3.2" height="4.6" rx="0.4" fill="#f4f2ee"/><rect x="-1.6" y="6" width="3.2" height="4.6" rx="0.4" fill="#e8c24a"/></g>`;
        const tray = basin(C, -58, -22.4, ZF - 18, ZF - 2, 57, 8, '#ece8e0', { floor: org, dk: 0.3 }) + box3(C, { c: [-40.2, 48.4, ZF - 10], w: 36.4, h: 8.6, d: 16.6, r: 0.3, col: '#ece8e0', olw: 0.3, hole: { t: 0.6 } });
        const p0 = C.P([0, 0, 0]), p1 = C.P([0, 0, 16]), dx = p1[0] - p0[0], dy = p1[1] - p0[1];
        drawer = `<g>${at('translate', `0 0;0 0;${f1(dx)} ${f1(dy)};${f1(dx)} ${f1(dy)};0 0;0 0`, 14, 0, KT('0;0.3;0.42;0.58;0.84;1') + ' calcMode="spline" keySplines="0 0 1 1;0.3 0 0.2 1;0 0 1 1;0.12 0.75 0.2 1;0 0 1 1"')}${tray + dFront}</g>`; }
      const fr = drawer + frS;
      const QS = ['#9a948a', '#6a665e', '#c8c2b8', '#ffffff', '#b8a890'];
      const slab = box3(C, { c: [0, TY - 3, 0.5], w: 124, h: 3, d: 55, r: 0.6, col: QZ, gl: 0.35, olw: 0.4, skip: { t: 1 }, dec: { f: specks(rng('navy28e'), 70, 124, 3, QS, 0.1, 0.25, 0.7), l: specks(rng('navy28l'), 30, 55, 3, QS, 0.1, 0.25, 0.7), r: specks(rng('navy28l'), 30, 55, 3, QS, 0.1, 0.25, 0.7) } });
      const top = ctopH(C, -62, 62, -27, 28, TY, QZ, [], specks(rng('navy28t'), 520, 124, 55, QS, 0.1, 0.36, 0.6) + `<rect width="124" height="55" fill="url(#m10s)" opacity="0.4"/>`);
      const bs = box3(C, { c: [0, TY, -26], w: 124, h: 6, d: 2, r: 0.3, col: QZ, gl: 0.35, olw: 0.35, dec: { f: specks(rng('navy28b'), 70, 124, 6, QS, 0.1, 0.32, 0.6) } });
      // counter things
      const jars = jar(C, -50, TY, -18, 3, 10, '#f2d48a', '#c8a070', 0.8) + jar(C, -42.5, TY, -19.4, 2.6, 7.6, '#4a2a14', '#c8a070', 0.78);
      const brd = cyl3(C, [6, TY, -8], [6, TY + 1.4, -8], 7.2, '#c8945a', { mat: 'gloss', n: 30, olw: 0.3, cap: cr => `<g transform="translate(${f1(-cr)} ${f1(-cr)})" opacity="0.6">${grainH(rng('navy28g'), cr * 2, cr * 2, 6, '#7a5028')}</g>` });
      const boule = cyl3(C, [6, TY + 1.4, -8], [6, TY + 5.6, -8], 5.4, '#b8783a', { r2: 3.4, mat: 'matte', n: 26, olw: 0.3, cap: cr => `<circle r="${f1(cr)}" fill="#c08440"/><path d="M${f1(-cr * 1.3)} ${f1(-cr * 0.2)}Q0 ${f1(-cr * 0.8)} ${f1(cr * 1.3)} ${f1(-cr * 0.1)}" stroke="#f2dcae" stroke-width="0.7" fill="none"/><path d="M${f1(-cr * 1.2)} ${f1(-cr * 0.05)}Q0 ${f1(-cr * 0.55)} ${f1(cr * 1.2)} ${f1(cr * 0.05)}" stroke="#7a4a1a" stroke-width="0.35" fill="none"/>` + rep(10, i => `<circle cx="${f1(Math.cos(i * 2.4) * cr * 0.8)}" cy="${f1(Math.sin(i * 1.9) * cr * 0.8)}" r="0.22" fill="#f4ecd8" opacity="0.8"/>`).join('') });
      const bowl = cyl3(C, [32, TY, -4], [32, TY + 3.6, -4], 3.6, '#fbfaf6', { r2: 6.4, mat: 'gloss', n: 26, olw: 0.3, capCol: '#e4ded2' }) + vsort(C, [[-2.2, 0], [2.4, -0.6], [0, -2.6], [0.4, 2.6], [0, 0, 1]].map(([dx, dz, up]) => { const q = [32 + dx, TY + 4.6 + (up ? 1.6 : 0), -4 + dz]; return { q, s: sph(C, q, 2.2, '#f2932c') + `<circle cx="${f1(C.P(q)[0])}" cy="${f1(C.P([q[0], q[1] + 2, q[2]])[1])}" r="${f1(0.25 * C.k)}" fill="#5a7a2a"/>` }; }));
      const euc = cyl3(C, [50, TY, -18], [50, TY + 11, -18], 2.2, '#f4f2ee', { r2: 1.6, mat: 'gloss', n: 20, olw: 0.3, capCol: '#3a4a40' }) + sway(C, [50, TY + 11, -18], vsort(C, [[-4, 24, -1], [3.6, 26, 1], [0.4, 29, -0.4], [-1.6, 22, 2]].map(([dx, h, dz], j) => { const t = [50 + dx, TY + h, -18 + dz], b = [50, TY + 10.4, -18];
        return { q: t, s: H2(C, b, t, 0.3, '#6a7a64') + rep(7, k => { const f = 0.25 + k * 0.11, q = [b[0] + (t[0] - b[0]) * f + (k % 2 ? 0.9 : -0.9), b[1] + (t[1] - b[1]) * f, b[2] + (t[2] - b[2]) * f]; return sph(C, q, 0.95 - k * 0.04, k % 2 ? '#94aea2' : '#a8beb2'); }).join('') }; })), 1.8, 6.8);
      const items = vsort(C, [{ q: [-46, TY + 5, -18.6], s: jars }, { q: [6, TY + 3, -8], s: brd + boule }, { q: [32, TY + 3, -4], s: bowl }, { q: [50, TY + 6, -18], s: euc }]);
      let s = shadow(C, 0, 0, 66, 32, 0.8) + unit + (fv ? fr : '') + slab + top + (fv ? bs + items : items + bs);
      C.p(0, TY + 30, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-070 WALNUT FLUTED CABINETRY WITH HONED SOAPSTONE COUNTERS (T4): book-matched walnut drawers with polished brass finger-pull strips (a glint runs along
  // them every 9 s), fluted walnut doors with round brass knobs, a recessed plinth over a breathing amber glow, a thick honed soapstone slab + tall splash
  // (soft grey-green mottling, thin pale veins). Counter: a beeswax pillar candle (flame flickers, warm glow), a cream stoneware vase of olive branches
  // swaying, a brass tray with a crystal decanter of whisky and two tumblers, a walnut bowl of figs.
  N.wal28 = S => { const TY = SKT, WN = '#6a4229', SP = '#40464a', BR = '#c9a256', ZF = 25.6;
    const D = { w: 124, d: 54, arch: 'counter', topH: TY, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]), R = rng('wal28'), lf = lit(C, [0, 0, 1]);
      const gid = C.u('wg'), DR = [[1, 1, 39.6, 11], [41.2, 1, 39.6, 11], [82.4, 1, 38.6, 11]], DO = [[1, 13, 39.6, 41], [41.2, 13, 19.4, 41], [61.4, 13, 19.4, 41], [82.4, 13, 38.6, 41]];
      const cabF = `<rect width="122" height="55" fill="#1a100a"/>` + DR.map(([x, y, w, h], i) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${shade(WN, lf * (i % 2 ? 1.04 : 0.98))}"/><g transform="translate(${x} ${y})">${grainH(rng('wal28d' + i), w, h, 7, '#3a2414')}</g>`).join('')
        + DO.map(([x, y, w, h], i) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${shade(WN, lf * (i % 2 ? 1.03 : 0.97))}"/><g transform="translate(${x} ${y})">${grainV(rng('wal28o' + i), w, h, Math.round(w / 3), '#3a2414', '#9a6a44')}<rect width="${w}" height="${h}" fill="url(#k28flt)"/></g>`).join('')
        + `<clipPath id="${gid}">${DR.map(([x, y, w]) => `<rect x="${x}" y="${y}" width="${w}" height="0.9"/>`).join('')}</clipPath>` + DR.map(([x, y, w]) => `<rect x="${x}" y="${y}" width="${w}" height="0.9" fill="url(#k28brs)"/>`).join('')
        + `<g clip-path="url(#${gid})"><rect x="-10" width="6" height="2" fill="#fff8e0" opacity="0.9">${at('translate', '0 0;0 0;136 0;136 0', 9, 0, KT('0;0.55;0.85;1'))}</rect></g><rect width="122" height="55" fill="url(#m10s)" opacity="0.3"/>`;
      const cabS = grainV(rng('wal28s'), 52.6, 55, 14, '#3a2414', '#9a6a44') + `<rect width="52.6" height="55" fill="url(#m10s)" opacity="0.3"/>`;
      const glow = PLN(C, [0, 0.06, ZF + 4], [1, 0, 0], [0, 0, 1], `<ellipse rx="58" ry="7" fill="url(#k28amb)">${an('opacity', '0.75;1;0.75', 5.6)}</ellipse>`);
      const unit = baseUnit(C, WN, '#16110c', cabF, cabS, 0.3);
      const fr = vsort(C, [[-25, 39], [-4, 39], [4, 39], [25, 39]].map(([x, y]) => ({ q: [x, y, ZF + 1], s: knobB(C, x, y, ZF, 1.3, BR, 'chrome') })));
      const slab = box3(C, { c: [0, TY - 4.4, 0.5], w: 124, h: 4.4, d: 55, r: 0.8, col: SP, olw: 0.4, olc: '#1a1c1e', skip: { t: 1 }, dec: { f: ssV(rng('wal28e'), 124, 4.4), l: ssV(rng('wal28f'), 55, 4.4), r: ssV(rng('wal28f'), 55, 4.4) } });
      const top = ctopH(C, -62, 62, -27, 28, TY, SP, [], ssV(rng('wal28t'), 124, 55) + ssV(rng('wal28u'), 124, 55));
      const bs = box3(C, { c: [0, TY, -26], w: 124, h: 16, d: 2, r: 0.3, col: SP, olw: 0.35, olc: '#1a1c1e', dec: { f: ssV(rng('wal28b'), 124, 16) } });
      // counter things
      const vase = cyl3(C, [-48, TY, -18], [-48, TY + 6, -18], 3.6, '#e8e0d0', { r2: 4, mat: 'matte', n: 22, olw: 0.3, noCap: 1 }) + cyl3(C, [-48, TY + 6, -18], [-48, TY + 9, -18], 4, '#e8e0d0', { r2: 2, mat: 'matte', n: 22, olw: 0.3, noCap: 1 }) + cyl3(C, [-48, TY + 9, -18], [-48, TY + 10, -18], 2, '#e8e0d0', { r2: 2.3, mat: 'matte', n: 18, olw: 0.3, capCol: '#3a3020' });
      const leafE = (q, a, c) => { const p = C.P(q); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(1.5 * C.k)}" ry="${f1(0.42 * C.k)}" fill="${c}" transform="rotate(${f1(a)} ${f1(p[0])} ${f1(p[1])})"/>`; };
      const olive = sway(C, [-48, TY + 10, -18], [[-5, 26, -1], [4, 24, 1.4], [0.6, 29, -0.6]].map(([dx, h, dz], j) => { const b = [-48, TY + 9.6, -18], t = [-48 + dx, TY + h, -18 + dz];
        return H2(C, b, t, 0.3, '#6a5a44') + rep(9, k => { const f = 0.2 + k * 0.09, q = [b[0] + (t[0] - b[0]) * f, b[1] + (t[1] - b[1]) * f, b[2] + (t[2] - b[2]) * f], sg = k % 2 ? 1 : -1; return leafE(add(q, [sg * 1.2, 0.3, 0]), sg * 30 + (j - 1) * 12, k % 3 ? '#7d8c62' : '#b4bca0'); }).join('') + (j === 1 ? sph(C, add(t, [-1, -4, 0]), 0.6, '#3a3a24') + sph(C, add(t, [0.4, -5, 0.6]), 0.6, '#4a4a2a') : ''); }).join(''), 1.6, 7);
      const candle = cyl3(C, [8, TY, -20], [8, TY + 7, -20], 2.2, '#f0d48a', { mat: 'matte', n: 20, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.82)}" fill="#e2c272"/><circle r="0.3" fill="#2a2018"/>` });
      const fp0 = C.P([8, TY + 7.4, -20]); C.p(8, TY + 14, -20);
      const flame = `<g transform="translate(${P2(fp0)}) scale(${n4(C.k)})"><circle cy="-2" r="8" fill="url(#k28bulb)">${an('opacity', '0.7;0.9;0.6;0.85;0.7', 1.6)}</circle><path d="M0 0V-0.8" stroke="#2a2018" stroke-width="0.25"/><ellipse cy="-2" rx="0.9" ry="1.9" fill="#ffc860">${an('ry', '1.9;2.3;1.7;2.1;1.9', 0.9)}${an('cy', '-2;-2.3;-1.9;-2.2;-2', 0.9)}</ellipse><ellipse cy="-1.6" rx="0.45" ry="1" fill="#fff4d0"/></g>`;
      const tray = box3(C, { c: [30, TY, -13], w: 20, h: 0.8, d: 12, r: 1.6, col: BR, gl: 0.6, olw: 0.3, dec: { t: `<rect width="20" height="12" fill="url(#k28ham)" opacity="0.5"/>` } });
      const dec = cyl3(C, [27, TY + 0.8, -14], [27, TY + 3.6, -14], 2.8, '#a8501a', { mat: 'gloss', n: 22, olw: 0, op: 0.85 }) + cyl3(C, [27, TY + 0.8, -14], [27, TY + 6.6, -14], 3.2, '#eef6f6', { r2: 2.8, mat: 'chrome', n: 24, op: 0.32, olw: 0.3, olc: '#8aa0a4', noCap: 1 })
        + cyl3(C, [27, TY + 6.6, -14], [27, TY + 10, -14], 2.8, '#eef6f6', { r2: 1, mat: 'chrome', n: 20, op: 0.35, olw: 0.3, olc: '#8aa0a4', noCap: 1 }) + sph(C, [27, TY + 11, -14], 1.4, '#eef6f6', { op: 0.55 });
      const tum = (x, z) => cyl3(C, [x, TY + 0.8, z], [x, TY + 2, z], 1.6, '#a8501a', { mat: 'gloss', n: 16, olw: 0, op: 0.85 }) + cyl3(C, [x, TY + 0.8, z], [x, TY + 4.4, z], 1.8, '#eef6f6', { mat: 'chrome', n: 18, op: 0.35, olw: 0.3, olc: '#8aa0a4', capCol: '#c8783a' });
      const onT = vsort(C, [{ q: [27, TY + 4, -14], s: dec }, { q: [34, TY + 2, -10], s: tum(34, -10) }, { q: [35.6, TY + 2, -15], s: tum(35.6, -15) }]);
      const figs = cyl3(C, [-16, TY, 2], [-16, TY + 3.6, 2], 3.4, WN, { r2: 6, mat: 'gloss', n: 26, olw: 0.3, capCol: '#3a2214' }) + vsort(C, [[-2.2, 0], [2.2, -0.6], [0, -2.4], [0.4, 2.4], [0, 0, 1]].map(([dx, dz, up]) => { const q = [-16 + dx, TY + 4.6 + (up ? 1.4 : 0), 2 + dz]; return { q, s: sph(C, q, 1.9, '#5a2c46') + H2(C, [q[0], q[1] + 1.6, q[2]], [q[0] + 0.3, q[1] + 2.6, q[2]], 0.5, '#6a4a3a') }; }));
      const items = vsort(C, [{ q: [-48, TY + 6, -18], s: vase + olive }, { q: [8, TY + 4, -20], s: candle + flame }, { q: [30, TY + 1, -13], s: tray + onT }, { q: [-16, TY + 3, 2], s: figs }]);
      let s = shadow(C, 0, 0, 66, 32, 0.8) + glow + unit + (fv ? fr : '') + slab + top + (fv ? bs + items : items + bs);
      C.p(0, TY + 30, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // ---------- batch 4: KIT-090 obsidian U-kitchen, KIT-013 card table, KIT-033 prep cart ----------
  const hull2 = P => { P = P.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]); const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]), lo = [], up = [];
    P.forEach(p => { while (lo.length > 1 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= 0) lo.pop(); lo.push(p); }); P.slice().reverse().forEach(p => { while (up.length > 1 && cr(up[up.length - 2], up[up.length - 1], p) <= 0) up.pop(); up.push(p); }); return lo.slice(0, -1).concat(up.slice(0, -1)); };
  // obsidian surface: smoky clouds + fine champagne-gold veins
  const obsV = (R, w, h, nv) => `<svg width="${f1(w)}" height="${f1(h)}" overflow="hidden">` + rep(Math.min(14, 2 + Math.round(w * h / 1500)), () => `<ellipse cx="${f1(R() * w)}" cy="${f1(R() * h)}" rx="${f1(Math.min(w, 6 + R() * 22))}" ry="${f1(Math.min(h, 2 + R() * 7))}" fill="${R() < 0.55 ? '#463f52' : '#000000'}" opacity="${n4(0.18 + R() * 0.2)}" filter="url(#m10b2)"/>`).join('')
    + rep(nv, () => { let x = R() * w, y = R() * h * 0.3, d = `M${f1(x)} ${f1(y)}`; for (let k = 0; k < 4; k++) { const nx = x + (R() - 0.3) * w * 0.18, ny = y + h * (0.12 + R() * 0.2); d += `Q${f1((x + nx) / 2 + (R() - 0.5) * 8)} ${f1((y + ny) / 2)} ${f1(nx)} ${f1(ny)}`; x = nx; y = ny; }
      return `<path d="${d}" stroke="#d8b46a" stroke-opacity="${n4(0.22 + R() * 0.35)}" stroke-width="${f1(0.15 + R() * 0.35)}" fill="none"/>`; }).join('') + '</svg>';

  // KIT-090 SEAMLESS SELF-HEALING OBSIDIAN U-KITCHEN WITH MOTORIZED LIFT CABINET (T5): keeps the old U footprint (328 x 146, top 59.2; back run x -112..112
  // z -68..-16, legs x -164..-112 / 112..164 z -68..78, waterfall ends z 78..82.8). Polished obsidian top + waterfalls with smoky depth and fine gold veins,
  // a slow reflection band; handle-less smoked-obsidian lacquer fronts with champagne-gold reveals and finger channels, floating over a breathing amber glow.
  // Motorized lift cabinet: a glass-fronted, warm-lit obsidian cabinet (wine glasses, plates, cups, spice jars) glides down into a slot in the counter until its
  // cap is flush, waits, then rises again (18 s, starts up). Self-healing: now and then a knife scratch appears, a thread of molten gold runs along it and it
  // fades back into seamless stone (14 s, starts healed). Counter: white orchid in a gold pot (sways), chocolate cake under a glass dome, hammered-gold bowl
  // of pomegranates (one halved), espresso for two on a gold tray (steam).
  N.obs28 = S => { const TY = 59.2, OB = '#17151b', OBL = '#24212a', CG = '#d6b878', LH = 44;
    const D = { w: 328, d: 146, topH: TY, topZ: -42, topW: 110, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('obs28'), v0 = C.v[0] > 0, v2 = C.v[2] > 0;
      const edge = L => `<rect width="${f1(L)}" height="4" fill="url(#m10s)" opacity="0.6"/><path d="M0 3.6H${f1(L)}" stroke="${CG}" stroke-width="0.7"/>`;
      const plain = L => `<rect width="${f1(L)}" height="50.2" fill="url(#m10s)" opacity="0.45"/><path d="M0 0.4H${f1(L)}" stroke="${CG}" stroke-width="0.4"/>`;
      const doors = (L, n, u0) => { const pw = (L - u0) / n; let s = `<rect x="${f1(u0)}" width="${f1(L - u0)}" height="50.2" fill="url(#m10s)" opacity="0.45"/>`; rep(n, i => { const x = u0 + i * pw + 0.5, w = pw - 1;
        s += `<rect x="${f1(x)}" y="0.6" width="${f1(w)}" height="9" fill="#ffffff" opacity="0.05"/><rect x="${f1(x)}" y="10.6" width="${f1(w)}" height="38.8" fill="#ffffff" opacity="0.03"/><path d="M${f1(x + 2)} 1H${f1(x + w - 2)}M${f1(x + 2)} 11H${f1(x + w - 2)}" stroke="${CG}" stroke-width="0.7" stroke-linecap="round"/>`
          + `<path d="M${f1(x + w * 0.18)} 49L${f1(x + w * 0.42)} 11H${f1(x + w * 0.52)}L${f1(x + w * 0.28)} 49Z" fill="#ffffff" opacity="0.05"/>`; });
        return s + rep(n + 1, i => `<path d="M${f1(u0 + i * pw)} 0V50.2" stroke="${CG}" stroke-width="0.45"/>`).join('') + `<path d="M${f1(u0)} 10H${f1(L)}" stroke="${CG}" stroke-width="0.45"/>`; };
      const unit = (cx, cz, w, d, dec) => box3(C, { c: [cx, 0, cz], w: w - 6, h: 5, d: d - 6, r: 0.3, col: '#0b0a0d', olw: 0.3, skip: { t: 1 } }) + box3(C, { c: [cx, 5, cz], w, h: TY - 9, d, r: 0.3, col: OBL, gl: 0.55, olw: 0.4, olo: 0.6, skip: { t: 1 }, dec })
        + box3(C, { c: [cx, TY - 4, cz], w, h: 4, d, r: 0.3, col: OB, gl: 0.7, olw: 0.35, skip: { t: 1 }, dec: { f: edge(w), r: edge(d), l: edge(d), b: edge(w) } });
      const runU = unit(0, -42, 224, 52, { f: doors(224, 6, 0), b: plain(224) });
      const legL = unit(-138, 5, 52, 146, { r: doors(94, 2, 0), l: plain(146), b: plain(52) }), legR = unit(138, 5, 52, 146, { l: doors(146, 2, 52), r: plain(146), b: plain(52) });
      const wf = x => box3(C, { c: [x, 0, 80.4], w: 52, h: TY, d: 4.8, r: 0.3, col: OB, gl: 0.7, olw: 0.4, skip: { t: 1 }, dec: { f: obsV(rng('obsw' + x), 52, TY, 3) + `<rect width="52" height="${TY}" fill="url(#m10s)" opacity="0.5"/><path d="M0 0.5H52" stroke="${CG}" stroke-width="0.5"/>`, l: obsV(rng('obsx'), 4.8, TY, 0), r: obsV(rng('obsx'), 4.8, TY, 0) } });
      const gL = v2 ? legL + wf(-138) : wf(-138) + legL, gR = v2 ? legR + wf(138) : wf(138) + legR;
      const units = v0 ? gL + runU + gR : gR + runU + gL;
      const amb = (O, U, V, rx) => PLN(C, O, U, V, `<ellipse rx="${rx}" ry="7" fill="url(#k28amb)">${an('opacity', '0.75;1;0.75', 6)}</ellipse>`);
      const glow = amb([0, 0.06, -14], [1, 0, 0], [0, 0, 1], 104) + amb([-110, 0.06, 30], [0, 0, 1], [1, 0, 0], 46) + amb([110, 0.06, 30], [0, 0, 1], [1, 0, 0], 46);
      // U top: reflection band, slot rim, self-healing scratch
      const hd = 'M70 38.4l3.4 -1l2.6 0.6l4.4 -1.6l3.6 0.4l4.2 -1.3l3.2 0.5l3.8 -0.9', HL = 28;
      const heal = `<path d="${hd}" stroke="#9a94a2" stroke-width="0.5" fill="none" stroke-linecap="round" opacity="0">${an('opacity', '0;0;0.9;0.9;0;0', 14, 0, KT('0;0.25;0.26;0.5;0.66;1'))}</path>`
        + `<path d="${hd}" stroke="#ffcf7a" stroke-width="2.6" fill="none" stroke-linecap="round" filter="url(#m10b1)" opacity="0">${an('opacity', '0;0;0.6;0.6;0;0', 14, 0, KT('0;0.42;0.46;0.6;0.76;1'))}</path>`
        + `<path d="${hd}" stroke="#f2d494" stroke-width="0.6" fill="none" stroke-linecap="round" stroke-dasharray="${HL} ${HL}" stroke-dashoffset="${HL}" opacity="0">${an('stroke-dashoffset', `${HL};${HL};0;0`, 14, 0, KT('0;0.44;0.6;1'))}${an('opacity', '0;0;1;1;0;0', 14, 0, KT('0;0.43;0.45;0.62;0.8;1'))}</path>`;
      const Ud = 'M0 0H328V150.8H276V52H52V150.8H0Z', tid = C.u('ot'), gid = C.u('og');
      const top = PLN(C, [-164, TY, -68], [1, 0, 0], [0, 0, 1], `<defs><linearGradient id="${gid}" x1="0" y1="0" x2="1" y2="0.5"><stop offset="0.3" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.42" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.02"/><stop offset="0.58" stop-color="#ffffff" stop-opacity="0.08"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/></linearGradient><clipPath id="${tid}"><path d="${Ud}"/></clipPath></defs>`
        + `<g clip-path="url(#${tid})"><rect width="328" height="151" fill="${shade(OB, lit(C, [0, 1, 0]))}"/>${obsV(R, 328, 151, 16)}<rect width="328" height="151" fill="url(#${gid})"/><rect x="103" y="3" width="102" height="14" rx="0.8" fill="none" stroke="${CG}" stroke-width="0.6"/>${heal}</g>`);
      const bsD = L => obsV(rng('obsb' + L), L, 10, 2) + `<rect width="${L}" height="10" fill="url(#m10s)" opacity="0.5"/><path d="M0 0.4H${L}" stroke="${CG}" stroke-width="0.6"/>`;
      const bsB = box3(C, { c: [0, TY, -67], w: 328, h: 10, d: 2, r: 0.3, col: OB, gl: 0.6, olw: 0.35, dec: { f: bsD(328) } });
      const bsL = box3(C, { c: [-163, TY, 6], w: 2, h: 10, d: 144, r: 0.3, col: OB, gl: 0.6, olw: 0.35, dec: { r: bsD(144) } }), bsR = box3(C, { c: [163, TY, 6], w: 2, h: 10, d: 144, r: 0.3, col: OB, gl: 0.6, olw: 0.35, dec: { l: bsD(144) } });
      // lift cabinet: glass front (3 doors, warm light, glassware), clipped to the prism above its slot so it sinks into the counter
      const lg = C.u('lg');
      const glassF = `<defs><linearGradient id="${lg}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe2a8"/><stop offset="0.5" stop-color="#c88a40"/><stop offset="1" stop-color="#4a2a12"/></linearGradient></defs><rect width="100" height="44" fill="#0e0b08"/><rect x="1" y="1" width="98" height="42" fill="url(#${lg})" opacity="0.55">${an('opacity', '0.5;0.62;0.5', 5)}</rect>`
        + [15, 29.5].map(y => `<rect x="1" y="${y}" width="98" height="1" fill="#fff2d0" opacity="0.6"/><path d="M1 ${y + 1}H99" stroke="${CG}" stroke-width="0.3"/>`).join('')
        + rep(8, i => `<g transform="translate(${f1(6 + i * 12.4)} 14.6)"><path d="M-2.4 -12.2Q-2.6 -7.4 0 -6.6Q2.6 -7.4 2.4 -12.2Z" fill="#ffffff" fill-opacity="0.14" stroke="#fff6e0" stroke-width="0.3"/><path d="M0 -6.6V-0.3M-1.8 0H1.8" stroke="#fff6e0" stroke-width="0.35"/><path d="M-1.8 -11.4Q-1.9 -9 -1 -8" stroke="#ffffff" stroke-width="0.3" fill="none" opacity="0.7"/></g>`).join('')
        + rep(6, k => `<ellipse cx="14" cy="${f1(28.6 - k * 1.1)}" rx="8.4" ry="1.2" fill="#f4efe6" stroke="${k === 5 ? CG : '#c8b8a0'}" stroke-width="0.2"/>`).join('')
        + `<path d="M40 29.4Q34.6 29 35 24.6Q35.6 21.4 38.8 20.6V17.4H41.2V20.6Q44.4 21.4 45 24.6Q45.4 29 40 29.4Z" fill="#ffffff" fill-opacity="0.16" stroke="#fff6e0" stroke-width="0.3"/><path d="M35.6 26Q40 27.2 44.4 26V27.6Q40 29.6 35.6 27.6Z" fill="#6a1a1a" opacity="0.8"/><rect x="38.6" y="16.6" width="2.8" height="1.1" rx="0.3" fill="${CG}"/>`
        + rep(4, i => `<g transform="translate(${f1(58 + i * 9.6)} 29.4)"><path d="M-2.6 0V-4.6Q0 -4.3 2.6 -4.6V0Q0 0.6 -2.6 0Z" fill="#f6f0e6"/><path d="M-2.6 -4.6H2.6" stroke="${CG}" stroke-width="0.4"/><path d="M2.6 -3.6Q4.4 -3 2.6 -1.4" stroke="#f6f0e6" stroke-width="0.5" fill="none"/></g>`).join('')
        + rep(10, i => { const c = ['#c8482a', '#e0a82a', '#5a7a3a', '#2a2420', '#d8c8a0'][i % 5]; return `<g transform="translate(${f1(6 + i * 9.6)} 43)"><rect x="-2.4" y="-8.4" width="4.8" height="8.4" rx="0.6" fill="#ffffff" fill-opacity="0.16" stroke="#fff6e0" stroke-width="0.25"/><rect x="-2" y="-5.4" width="4" height="5" rx="0.4" fill="${c}" opacity="0.85"/><rect x="-2.6" y="-10" width="5.2" height="1.8" rx="0.5" fill="${CG}"/></g>`; }).join('')
        + `<rect x="1" y="1" width="98" height="0.6" fill="#fff4d8"/><rect width="100" height="44" fill="#2a2018" opacity="0.18"/>` + rep(3, i => `<rect x="${f1(0.6 + i * 33.1)}" y="0.6" width="32.4" height="42.8" fill="none" stroke="${CG}" stroke-width="0.7"/>`).join('')
        + `<path d="M8 44L30 0H38L16 44Z" fill="#ffffff" opacity="0.06"/><path d="M58 44L80 0H83L61 44Z" fill="#ffffff" opacity="0.05"/>`;
      const ed = (L, h) => `<rect width="${L}" height="${h}" fill="url(#m10s)" opacity="0.5"/><path d="M0 ${f1(h - 0.4)}H${L}" stroke="${CG}" stroke-width="0.4"/>`;
      const cabB = box3(C, { c: [-10, TY, -58], w: 100, h: LH, d: 12, r: 0.5, col: OBL, gl: 0.55, olw: 0.35, dec: { f: glassF, b: `<rect width="100" height="${LH}" fill="url(#k28flt)" opacity="0.55"/>` + ed(100, LH) + `<rect x="0.6" y="0.6" width="98.8" height="${LH - 1.2}" fill="none" stroke="${CG}" stroke-width="0.6"/>`, l: ed(12, LH) + `<rect x="0.5" y="0.5" width="11" height="${LH - 1}" fill="none" stroke="${CG}" stroke-width="0.5"/>`, r: ed(12, LH) + `<rect x="0.5" y="0.5" width="11" height="${LH - 1}" fill="none" stroke="${CG}" stroke-width="0.5"/>` } })
        + box3(C, { c: [-10, TY + LH, -58], w: 101, h: 1.4, d: 13, r: 0.6, col: OB, gl: 0.7, olw: 0.3, dec: { f: ed(101, 1.4), b: ed(101, 1.4), l: ed(13, 1.4), r: ed(13, 1.4), t: obsV(rng('obsc'), 101, 13, 2) + `<rect x="0.4" y="0.4" width="100.2" height="12.2" rx="0.6" fill="none" stroke="${CG}" stroke-width="0.35"/>` } });
      const p0 = C.P([0, 0, 0]), p1 = C.P([0, -(LH + 1.4), 0]), ldx = f1(p1[0] - p0[0]), ldy = f1(p1[1] - p0[1]), cid = C.u('lc');
      const hp = hull2([[-60.5, -64.5], [40.5, -64.5], [40.5, -51.5], [-60.5, -51.5]].flatMap(([x, z]) => [C.P([x, TY, z]), C.P([x, TY + LH + 8, z])]));
      const lift = `<clipPath id="${cid}"><path d="M${hp.map(P2).join('L')}Z"/></clipPath><g clip-path="url(#${cid})"><g>${at('translate', `0 0;0 0;${ldx} ${ldy};${ldx} ${ldy};0 0;0 0`, 18, 0, KT('0;0.42;0.56;0.8;0.94;1') + ' calcMode="spline" keySplines="0 0 1 1;0.45 0 0.4 1;0 0 1 1;0.45 0 0.4 1;0 0 1 1"')}${cabB}</g></g>`;
      // orchid in a gold pot
      const OX = -140, OZ = -46;
      const pot = cyl3(C, [OX, TY, OZ], [OX, TY + 7, OZ], 3.4, CG, { r2: 4.4, mat: 'chrome', n: 24, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#5a6a34"/>` + rep(9, i => `<circle cx="${f1(Math.cos(i * 2.3) * cr * 0.55)}" cy="${f1(Math.sin(i * 1.7) * cr * 0.5)}" r="0.45" fill="#7a8a4a"/>`).join('') });
      const lvs = [[6.4, -1, 2], [-6, -0.6, 1.4], [1, -0.4, -5.6]].map(([dx, dy, dz]) => { const a = [OX, TY + 7.2, OZ], b = [OX + dx, TY + 7.2 + dy, OZ + dz]; return H2(C, a, b, 2.8, '#3f6a2e') + H2(C, a, b, 0.4, '#6a9a4a'); }).join('');
      const SP = [[0.5, 7, 0], [1, 16, 0], [2, 24, 0.5], [5, 29, 1], [9, 30.4, 1.5], [12.6, 28.6, 2], [14.6, 26, 2.4]].map(([dx, y, dz]) => [OX + dx, TY + y, OZ + dz]);
      const bloom = (q, s) => { const p = C.P(q); return `<g transform="translate(${P2(p)}) scale(${n4(C.k * s)})"><g fill="#fbf8fa" stroke="#e2d2de" stroke-width="0.15"><ellipse cy="-1.8" rx="0.9" ry="1.8"/><ellipse cx="-1.4" cy="1.4" rx="0.8" ry="1.6" transform="rotate(35 -1.4 1.4)"/><ellipse cx="1.4" cy="1.4" rx="0.8" ry="1.6" transform="rotate(-35 1.4 1.4)"/><ellipse cx="-1.7" rx="1.8" ry="1.5"/><ellipse cx="1.7" rx="1.8" ry="1.5"/></g><path d="M-0.9 0.3Q0 2.8 0.9 0.3Q0 -0.3 -0.9 0.3Z" fill="#c8407a"/><circle cy="-0.2" r="0.38" fill="#f2d24a"/></g>`; };
      const spike = SP.slice(1).map((q, i) => H2(C, SP[i], q, 0.35, '#4a6a3a')).join('') + bloom(SP[3], 1.2) + bloom(SP[4], 1.3) + bloom(SP[5], 1.15) + sph(C, SP[6], 0.8, '#f2e6ee');
      const orchid = pot + lvs + sway(C, [OX, TY + 7, OZ], spike, 1.4, 7);
      // chocolate cake under a glass dome
      const KX = 138, KZ = 44;
      const stand = cyl3(C, [KX, TY, KZ], [KX, TY + 0.8, KZ], 4.2, CG, { mat: 'chrome', n: 24, olw: 0.3 }) + cyl3(C, [KX, TY + 0.8, KZ], [KX, TY + 5, KZ], 0.9, CG, { mat: 'chrome', n: 14, olw: 0.25, noCap: 1 }) + cyl3(C, [KX, TY + 5, KZ], [KX, TY + 5.8, KZ], 9.6, '#eef6f6', { mat: 'chrome', n: 30, op: 0.6, olw: 0.3, olc: '#8aa0a4', capCol: '#f4fafa' });
      const cake = cyl3(C, [KX, TY + 5.8, KZ], [KX, TY + 12, KZ], 6.4, '#3a1c12', { mat: 'gloss', n: 30, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.92)}" fill="#4a2416"/><circle r="${f1(cr * 0.92)}" fill="url(#m10cap)"/>` + rep(7, i => `<path transform="translate(${f1(Math.cos(i * 2.1) * cr * 0.45)} ${f1(Math.sin(i * 1.6) * cr * 0.4)}) rotate(${i * 47})" d="M-0.8 -0.4L0.6 -0.7L0.9 0.5L-0.5 0.6Z" fill="#e8c870"/>`).join('') })
        + vsort(C, rep(5, i => { const a = i * 1.26, q = [KX + Math.cos(a) * 4.2, TY + 12.7, KZ + Math.sin(a) * 4.2]; return { q, s: sph(C, q, 0.95, '#c8283a') }; }));
      const dome = cyl3(C, [KX, TY + 5.8, KZ], [KX, TY + 15.4, KZ], 8.8, '#eef6f8', { r2: 7.6, mat: 'chrome', n: 30, op: 0.2, olw: 0.3, olc: '#9ab0b4', noCap: 1 }) + sph(C, [KX, TY + 15.4, KZ], 7.6, '#eef6f8', { op: 0.18 }) + sph(C, [KX, TY + 23.4, KZ], 1.1, CG)
        + (() => { const a = C.P([KX - 5.4, TY + 20, KZ + 3]), b = C.P([KX - 7.6, TY + 12, KZ + 4]); return `<path d="M${P2(a)}Q${P2(add(C.P([KX - 8.4, TY + 17, KZ + 4]), [0, 0]))} ${P2(b)}" stroke="#ffffff" stroke-width="${f1(0.6 * C.k)}" fill="none" stroke-linecap="round" opacity="0.5">${an('opacity', '0.35;0.65;0.35', 6)}</path>`; })();
      // hammered gold bowl of pomegranates + a halved one
      const BX = 70, BZ = -34;
      const bowl = cyl3(C, [BX, TY, BZ], [BX, TY + 4.4, BZ], 4, CG, { r2: 7.4, mat: 'chrome', n: 28, olw: 0.3, pat: 'k28ham', capCol: '#6a5228' }) + vsort(C, [[-2.6, 0], [2.6, -0.8], [0, -2.8], [0.4, 2.8], [0, 0, 1]].map(([dx, dz, up]) => { const q = [BX + dx, TY + 5.4 + (up ? 1.8 : 0), BZ + dz]; return { q, s: sph(C, q, 2.7, '#a8202e') + cyl3(C, [q[0], q[1] + 2.3, q[2]], [q[0], q[1] + 3.2, q[2]], 0.7, '#6a1420', { r2: 0.9, n: 10, olw: 0.2 }) }; }));
      const half = cyl3(C, [BX + 10, TY, BZ + 4], [BX + 10, TY + 2.6, BZ + 4], 2.8, '#a8202e', { r2: 2.6, mat: 'gloss', n: 22, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.94)}" fill="#f2e2c8"/>` + rep(26, i => `<circle cx="${f1(Math.cos(i * 2.4) * cr * (0.2 + (i % 5) * 0.15))}" cy="${f1(Math.sin(i * 2.4) * cr * (0.2 + (i % 5) * 0.15))}" r="0.42" fill="#c8183a"/>`).join('') });
      // espresso for two on a gold tray
      const EX = -138, EZ = 34;
      const tray = box3(C, { c: [EX, TY, EZ], w: 18, h: 0.8, d: 11, r: 1.6, col: CG, gl: 0.6, olw: 0.3, dec: { t: `<rect width="18" height="11" fill="url(#k28ham)" opacity="0.4"/>` } });
      const esp = (x, z, b) => cyl3(C, [x, TY + 0.8, z], [x, TY + 1.2, z], 2.4, '#fbfaf6', { mat: 'gloss', n: 20, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.95)}" fill="none" stroke="${CG}" stroke-width="0.25"/>` }) + cyl3(C, [x, TY + 1.2, z], [x, TY + 3.8, z], 1.3, '#fbfaf6', { r2: 1.7, mat: 'gloss', n: 20, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.96)}" fill="${CG}"/><circle r="${f1(cr * 0.84)}" fill="#5a2e14"/><circle r="${f1(cr * 0.62)}" fill="#c8945a" opacity="0.7"/>` }) + puff1(C, [x, TY + 4.2, z], 0.35, 5, 0.1, 0.8, b);
      const onT = vsort(C, [{ q: [EX - 4, TY + 2, EZ], s: esp(EX - 4, EZ, 0) }, { q: [EX + 4, TY + 2, EZ + 1], s: esp(EX + 4, EZ + 1, -2.5) }]);
      const items = vsort(C, [{ q: [-10, TY + 22, -58], s: lift }, { q: [OX, TY + 6, OZ], s: orchid }, { q: [KX, TY + 8, KZ], s: stand + cake + dome }, { q: [BX, TY + 4, BZ], s: bowl }, { q: [BX + 10, TY + 1, BZ + 4], s: half }, { q: [EX, TY + 1, EZ], s: tray + onT }]);
      const bsK = (v2 ? bsB : '') + (v0 ? bsL : bsR), bsN = (v2 ? '' : bsB) + (v0 ? bsR : bsL);
      let s = shadow(C, 0, -42, 120, 32, 0.7) + shadow(C, -138, 2, 27, 66, 0.5) + shadow(C, 138, 2, 27, 66, 0.5) + glow + units + top + bsK + items + bsN;
      C.p(-10, TY + LH + 8, -58);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-013 WOBBLY FOLDING CARD TABLE WITH VINYL CLOTH (T1): narrowed to card-table proportions (84 x 80, was 120 x 76), top y 52 as before. Black enamel
  // folding legs chipped to bare steel, braces + rivets, one rubber foot missing so that leg stands on a folded cardboard wedge. Red gingham vinyl cloth with
  // fold creases, a coffee ring, a ketchup smear, a cigarette burn and a taped tear. The whole table rocks every 7 s. Takeout box of noodles + chopsticks
  // (steaming), a paper plate with a pizza crust, a dented soda can with a straw.
  N.card28 = S => { const TY = 52, ST = '#3c3836';
    const D = { w: 84, d: 80, topH: TY, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('card28'), v2 = C.v[2] > 0;
      const chip = () => rep(3, () => `<rect x="${f1(0.2 + R() * 0.8)}" y="${f1(R() * 36)}" width="${f1(0.4 + R() * 0.6)}" height="${f1(0.4 + R() * 1.2)}" rx="0.2" fill="#a8acae"/>`).join('');
      const cbd = `<path d="M0 0.75H6M0 1.5H6" stroke="#8a6a42" stroke-width="0.2"/>`;
      const legs = [[-35, -33], [35, -33], [-35, 33], [35, 33]].map(([x, z], i) => { const sh = i === 3, y0 = sh ? 2.2 : 1.4;
        const foot = sh ? box3(C, { c: [x, 0, z], w: 5.4, h: 2.2, d: 4.4, r: 0.2, col: '#c49a62', olw: 0.25, dec: { f: cbd, b: cbd, l: cbd, r: cbd } }) : cyl3(C, [x, 0, z], [x, 1.5, z], 1.25, '#1e1c1a', { mat: 'gloss', n: 12, olw: 0.2 });
        const s = foot + box3(C, { c: [x, y0, z], w: 1.8, h: TY - 3 - y0, d: 1.8, r: 0.3, col: ST, gl: 0.45, olw: 0.25, dec: { f: chip(), r: chip(), l: chip(), b: chip() } })
          + H2(C, [x, 30, z], [x * 0.6, TY - 3, z * 0.6], 0.7, '#55504c') + sph(C, [x, 30, z], 0.55, '#8a8684');
        return { q: [x, 20, z], s }; });
      const side = (L, n) => `<rect width="${L}" height="10.4" fill="url(#k28ging)"/>` + rep(Math.round(L / 9), i => `<rect x="${f1(i * 9 + 2 + R() * 3)}" width="${f1(2.4 + R() * 2)}" height="10.4" fill="#000000" opacity="0.08"/>`).join('')
        + `<rect width="${L}" height="10.4" fill="#000000" opacity="${n4(Math.max(0, 1.1 - lit(C, n)) * 0.55)}"/><path d="M0 9.8H${L}" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.3" stroke-dasharray="0.8 0.6"/><rect y="9.6" width="${L}" height="0.8" fill="#000000" opacity="0.14"/>`;
      const topD = `<rect width="80" height="76" fill="url(#k28ging)"/><rect width="80" height="76" fill="url(#m10s)" opacity="0.5"/><path d="M40 0V76M0 38H80" stroke="#ffffff" stroke-opacity="0.35" stroke-width="0.5"/><path d="M40.6 0V76M0 38.6H80" stroke="#000000" stroke-opacity="0.12" stroke-width="0.4"/>`
        + `<circle cx="22" cy="56" r="3.4" fill="none" stroke="#6a3a1a" stroke-opacity="0.4" stroke-width="0.7"/><path d="M58 54q4 -2 7 1q-2 2.4 -6 1.2Z" fill="#b8241c" opacity="0.65"/><path d="M65 55.4l2.6 0.8" stroke="#b8241c" stroke-width="0.5" opacity="0.6"/>`
        + `<ellipse cx="62" cy="20" rx="2.2" ry="1.8" fill="#5a3418" opacity="0.5" filter="url(#m10b1)"/><ellipse cx="62" cy="20" rx="1.1" ry="0.9" fill="#2a1a10"/><ellipse cx="62" cy="20" rx="0.7" ry="0.55" fill="#8a7a5a"/>`
        + `<path d="M8 20l3 1.4l2 -1l3 1.6" stroke="#4a2a1a" stroke-width="0.4" fill="none"/><rect x="6.6" y="18.6" width="11" height="3.4" rx="0.3" fill="#f2ead0" opacity="0.7" transform="rotate(-6 12 20)"/><path d="M17.4 18.4l0.4 3.6" stroke="#c8bc98" stroke-width="0.2"/>`
        + `<g transform="translate(34 44)">${specks(R, 14, 26, 12, ['#c8a060', '#8a5a2a'], 0.15, 0.35, 0.8)}</g>`;
      const cloth = box3(C, { c: [0, TY - 10.4, 0], w: 80, h: 10.4, d: 76, r: 3.2, col: '#e2b4ac', olw: 0.35, olc: '#8a2a20', dec: { f: side(80, [0, 0, 1]), b: side(80, [0, 0, -1]), l: side(76, [-1, 0, 0]), r: side(76, [1, 0, 0]), t: topD } });
      // takeout box of noodles
      const X1 = -16, Z1 = 2, WH = '#f8f4ec';
      const pag = `<path d="M3.5 1.2l-1.6 1.3h3.2Z" fill="#c8281e"/><path d="M2.2 3.4h2.6M2.5 4.4h2M2.8 5.3h1.4" stroke="#c8281e" stroke-width="0.35"/><text x="3.5" y="6.9" text-anchor="middle" ${FONT} font-size="0.7" fill="#c8281e">THANK YOU</text><ellipse cx="5.6" cy="5.6" rx="0.9" ry="0.7" fill="#d8a858" opacity="0.35"/>`;
      const noo = `<rect width="7" height="6" fill="#cf9a4a"/>` + rep(7, i => `<path d="M${f1(0.4 + i * 0.9)} 0.6q0.9 1.2 0 2.4t0 2.4" stroke="#f0c870" stroke-width="0.35" fill="none"/>`).join('') + `<rect x="0.2" y="0.2" width="6.6" height="5.6" fill="none" stroke="#e8e2d6" stroke-width="0.4"/><circle cx="5" cy="2" r="0.6" fill="#4a8a3a"/>`;
      const box = box3(C, { c: [X1, TY, Z1], w: 7, h: 7.4, d: 6, r: 0.3, col: WH, olw: 0.3, dec: { f: pag, b: pag, t: noo } });
      const flap = sg => PLN(C, [X1 - 3.5, TY + 7.4, Z1 + 3 * sg], [1, 0, 0], [0, 0.5, 0.87 * sg], `<rect width="7" height="3.2" fill="${shade(WH, 0.93)}" stroke="#b8b0a0" stroke-width="0.15"/><path d="M0 0.4H7" stroke="#000000" stroke-opacity="0.1" stroke-width="0.3"/>`);
      const tk = (v2 ? flap(-1) + box + flap(1) : flap(1) + box + flap(-1)) + H2(C, [X1 - 3.3, TY + 7.4, Z1], [X1 - 1.6, TY + 10.4, Z1], 0.22, '#a8acb0') + H2(C, [X1 - 1.6, TY + 10.4, Z1], [X1 + 1.6, TY + 10.4, Z1], 0.22, '#a8acb0') + H2(C, [X1 + 1.6, TY + 10.4, Z1], [X1 + 3.3, TY + 7.4, Z1], 0.22, '#a8acb0')
        + H2(C, [X1 + 0.6, TY + 6.8, Z1 + 0.6], [X1 + 4.6, TY + 15, Z1 - 1.4], 0.5, '#d8b47c') + H2(C, [X1 + 1.4, TY + 6.8, Z1 + 0.2], [X1 + 5.6, TY + 14.4, Z1 - 0.6], 0.5, '#cfa870')
        + puff1(C, [X1, TY + 8.4, Z1], 0.45, 4.2, 0.15, 0.85) + puff1(C, [X1 + 1, TY + 8.4, Z1 - 0.6], 0.4, 4.2, 0.15, 0.85, -2.1);
      // paper plate + crust, soda can
      const plate = cyl3(C, [14, TY, -10], [14, TY + 0.8, -10], 6.2, '#f8f6f0', { r2: 7.4, mat: 'matte', n: 28, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.8)}" fill="none" stroke="#ddd8ce" stroke-width="0.3"/>` + rep(24, i => { const a = i * PI / 12; return `<path d="M${f1(Math.cos(a) * cr * 0.84)} ${f1(Math.sin(a) * cr * 0.84)}L${f1(Math.cos(a) * cr * 0.98)} ${f1(Math.sin(a) * cr * 0.98)}" stroke="#e2ddd2" stroke-width="0.25"/>`; }).join('')
        + `<circle cx="-1" cy="1" r="1.4" fill="#e89a3a" opacity="0.3"/><circle cx="1.6" cy="-1.2" r="0.9" fill="#e89a3a" opacity="0.25"/><path d="M${f1(-cr * 0.5)} ${f1(cr * 0.15)}Q0 ${f1(-cr * 0.55)} ${f1(cr * 0.52)} ${f1(cr * 0.05)}" stroke="#b87a34" stroke-width="1.5" stroke-linecap="round" fill="none"/><path d="M${f1(-cr * 0.45)} ${f1(cr * 0.05)}Q0 ${f1(-cr * 0.6)} ${f1(cr * 0.48)} ${f1(-cr * 0.05)}" stroke="#d89a4a" stroke-width="0.5" fill="none"/>` });
      const CX = 24, CZ = 16, can = cyl3(C, [CX, TY, CZ], [CX, TY + 8.4, CZ], 2.2, '#c8322e', { mat: 'gloss', n: 20, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.86)}" fill="#c8ccd0"/><ellipse cx="${f1(cr * 0.3)}" rx="${f1(cr * 0.32)}" ry="${f1(cr * 0.22)}" fill="#5a5e62"/>` })
        + `<g transform="${tanF(C, CX, CZ, 2.22, C.thV, TY + 4.2)}"><text y="0.5" text-anchor="middle" ${FONT} font-size="1.4" fill="#ffffff">FIZZ</text><path d="M-2 -2.4H2M-2 2.2H2" stroke="#ffffff" stroke-width="0.25"/></g>` + (Math.cos(C.thV - 0.5) > 0.4 ? `<g transform="${tanF(C, CX, CZ, 2.24, 0.5, TY + 6.4)}">${dent(0, 0, 1, 0.6, 0, 1)}</g>` : '')
        + H2(C, [CX + 0.4, TY + 7.6, CZ], [CX + 1.2, TY + 12, CZ - 0.6], 0.5, '#f4f2ee') + H2(C, [CX + 1.2, TY + 12, CZ - 0.6], [CX + 2.8, TY + 12.8, CZ - 1.2], 0.5, '#f4f2ee');
      const items = vsort(C, [{ q: [X1, TY + 4, Z1], s: tk }, { q: [14, TY + 0.5, -10], s: plate }, { q: [CX, TY + 4, CZ], s: can }]);
      const pv = C.P([0, 0, 0]), wob = at('rotate', [0, 0, 0.9, -0.7, 0.45, -0.2, 0, 0].map(a => `${a} ${P2(pv)}`).join(';'), 7, 0, KT('0;0.55;0.6;0.66;0.72;0.78;0.84;1'));
      let s = shadow(C, 0, 0, 44, 40, 0.75) + `<g>${wob}${vsort(C, legs)}${cloth}${items}</g>`;
      C.p(0, TY + 18, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-033 ROLLING PINE BUTCHER-BLOCK PREP CART (T2): now 64 x 42 at counter height (top y 62; was 60 x 42 with a top at 79). Pine legs on 4 rubber casters
  // (2 with red brake tabs), thick edge-grain butcher-block top (knife marks, a water ring), a drawer with a white knob, slatted lower shelf with wicker baskets
  // of potatoes and onions. Chrome towel bar on the +x end with a green-striped towel (sways); S-hooks on the -x end with a ladle, whisk and wooden spoon (swing).
  // Top: a rolling pin rolls back and forth over floury dough (6 s), blue bowl of brown eggs, carrots + coins + paring knife.
  N.cart28 = S => { const TY = 62, PN = '#e0bb84', CH = '#c4c8cc';
    const D = { w: 64, d: 42, topH: TY, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('cart28'), v0 = C.v[0] > 0, v2 = C.v[2] > 0, LX = 28.4, LZ = 17.4, Y0 = 5.6, SY = 14;
      const gr = (w, h, n, k) => grainV(rng('c28g' + k), w, h, n, '#a87a44', '#f4dcae');
      const caster = (x, z, lk) => { const pl = sx => box3(C, { c: [x + sx * 1.1, 1.4, z], w: 0.35, h: 3.4, d: 2.4, r: 0.1, col: CH, gl: 0.6, olw: 0.2 });
        const wh = cyl3(C, [x - 0.8, 2.3, z], [x + 0.8, 2.3, z], 2.3, '#2a2826', { mat: 'gloss', n: 18, olw: 0.25, capCol: '#4a4846', cap: cr => `<circle r="${f1(cr * 0.4)}" fill="${CH}"/>` });
        return (v0 ? pl(-1) + wh + pl(1) : pl(1) + wh + pl(-1)) + box3(C, { c: [x, 4.6, z], w: 3.4, h: 1, d: 3.4, r: 0.3, col: CH, gl: 0.6, olw: 0.2 }) + (lk ? box3(C, { c: [x, 3.4, z + 2.4], w: 1.6, h: 0.6, d: 2, r: 0.2, col: '#c8382e', olw: 0.2 }) : ''); };
      const leg = (x, z, i) => caster(x, z, z > 0) + box3(C, { c: [x, Y0, z], w: 3.2, h: TY - 4.4 - Y0, d: 3.2, r: 0.35, col: PN, olw: 0.3, dec: { f: gr(3.2, 52, 3, i), r: gr(3.2, 52, 3, i + 4), l: gr(3.2, 52, 3, i + 8), b: gr(3.2, 52, 3, i + 12) } });
      const LG = [[-LX, -LZ], [LX, -LZ], [-LX, LZ], [LX, LZ]], nearX = x => (x > 0) === v0;
      const legsF = vsort(C, LG.filter(([x]) => !nearX(x)).map(([x, z], i) => ({ q: [x, 20, z], s: leg(x, z, i) }))), legsN = vsort(C, LG.filter(([x]) => nearX(x)).map(([x, z], i) => ({ q: [x, 20, z], s: leg(x, z, i + 2) })));
      // lower shelf: rails + slats + wicker baskets
      const rails = [-LZ, LZ].map(z => ({ q: [0, SY - 1, z], s: box3(C, { c: [0, SY - 2.8, z], w: 53.6, h: 2.8, d: 1.4, r: 0.2, col: PN, olw: 0.25, dec: { f: gr(53.6, 2.8, 4, z), b: gr(53.6, 2.8, 4, z + 1) } }) }));
      const slats = [-14, -7, 0, 7, 14].map(z => ({ q: [0, SY, z], s: box3(C, { c: [0, SY - 1.3, z], w: 53.6, h: 1.3, d: 5.2, r: 0.3, col: shade(PN, 0.95 + R() * 0.1), olw: 0.25, dec: { t: grainH(rng('cs' + z), 53.6, 5.2, 4, '#a87a44') } }) }));
      const weave = (L, h) => { let s = `<rect width="${L}" height="${h}" fill="#000000" opacity="0.08"/>`; for (let r = 0; r * 1.5 < h; r++) for (let x = r % 2 ? -1.2 : 0; x < L; x += 2.4) s += `<rect x="${f1(x + 0.2)}" y="${f1(r * 1.5 + 0.15)}" width="2" height="1.2" rx="0.55" fill="#d8a868" opacity="0.65"/>`; return s + `<rect width="${L}" height="1" fill="#8a5a2a" opacity="0.5"/>`; };
      const basket = (x, fill, fruit) => { const q0 = [x, SY, -1]; let s = box3(C, { c: q0, w: 21, h: 7.5, d: 17, r: 2.2, col: '#b98a4e', olw: 0.3, olc: '#6a4a24', dec: { f: weave(16.6, 7.5), b: weave(16.6, 7.5), l: weave(12.6, 7.5), r: weave(12.6, 7.5), t: `<rect width="21" height="17" fill="#8a5a2a"/><rect x="1" y="1" width="19" height="15" rx="1.8" fill="${fill}"/>` } });
        return s + vsort(C, [[-5, -3], [0, -4], [5, -2.6], [-3, 3], [3, 3.4], [0, 0, 1]].map(([dx, dz, up]) => { const q = [x + dx, SY + 7.9 + (up ? 1.4 : 0), -1 + dz]; return { q, s: fruit(q) }; })); };
      const pot = q => sph(C, q, 2.4, '#b88a54') + `<circle cx="${f1(C.P(q)[0] + 0.6 * C.k)}" cy="${f1(C.P(q)[1] - 0.4 * C.k)}" r="${f1(0.25 * C.k)}" fill="#6a4a24"/>`;
      const oni = q => sph(C, q, 2.5, '#c89048') + H2(C, add(q, [0, 2.2, 0]), add(q, [0.4, 3.6, 0]), 0.45, '#9a6a30') + H2(C, add(q, [-1.2, 1.6, 0]), add(q, [-0.6, -1.8, 0]), 0.2, '#f0d8a0', 0.6);
      const shelf = vsort(C, rails.concat(slats)) + vsort(C, [{ q: [-12, SY + 4, -1], s: basket(-12, '#4a3018', pot) }, { q: [12, SY + 4, -1], s: basket(12, '#4a3018', oni) }]);
      // apron + drawer
      const drwF = gr(53.6, 7, 6, 30) + `<rect x="6" y="0.8" width="41.6" height="5.4" rx="0.4" fill="none" stroke="#7a5228" stroke-opacity="0.55" stroke-width="0.4"/><path d="M6.3 6H47.3" stroke="#ffffff" stroke-opacity="0.25" stroke-width="0.3"/>`;
      const apron = box3(C, { c: [0, TY - 11.4, 0], w: 53.6, h: 7, d: 31.6, r: 0.2, col: PN, olw: 0.3, dec: { f: drwF, b: gr(53.6, 7, 6, 31), l: gr(31.6, 7, 4, 32), r: gr(31.6, 7, 4, 33) } }) + (v2 ? knobB(C, 0, TY - 7.9, 15.8, 1.1, '#f4f0e8', 'gloss') : '');
      // butcher-block top
      const lt = lit(C, [0, 1, 0]), staves = (() => { let s = ''; for (let v = 0; v < 42; v += 3.5) { let u = -R() * 20; while (u < 64) { const L0 = 18 + R() * 30, ua = Math.max(0, u), L = Math.min(64, u + L0) - ua; u = ua; s += `<rect x="${f1(u)}" y="${f1(v)}" width="${f1(L)}" height="3.5" fill="${shade(PN, lt * (0.9 + R() * 0.18))}"/><path d="M${f1(u)} ${f1(v + 1 + R() * 1.4)}Q${f1(u + L / 2)} ${f1(v + 0.6 + R() * 2.2)} ${f1(u + L)} ${f1(v + 1.2 + R())}" stroke="#9a6a38" stroke-opacity="0.25" stroke-width="0.25" fill="none"/><path d="M${f1(u)} ${f1(v)}V${f1(v + 3.5)}" stroke="#7a4a22" stroke-opacity="0.3" stroke-width="0.25"/>`; u += L; } }
        return s + rep(12, i => `<path d="M0 ${f1(i * 3.5)}H64" stroke="#7a4a22" stroke-opacity="0.16" stroke-width="0.2"/>`).join('') + `<rect width="64" height="42" fill="url(#m10s)" opacity="0.4"/>`; })();
      const topD = staves + scr(R, 14, 32, 14, 28, 22, '#7a4a22', 0.35) + `<circle cx="50" cy="9" r="3" fill="none" stroke="#7a4a22" stroke-opacity="0.18" stroke-width="0.6"/><ellipse cx="22" cy="23" rx="16" ry="10" fill="#ffffff" opacity="0.35" filter="url(#m10b2)"/>` + `<g transform="translate(8 14)">${specks(R, 30, 28, 18, ['#ffffff', '#f8f0e0'], 0.15, 0.45, 0.8)}</g>`;
      const edF = rep(5, i => `<path d="M0 ${f1(0.6 + i * 0.75)}Q32 ${f1(0.3 + i * 0.8)} 64 ${f1(0.7 + i * 0.75)}" stroke="#9a6a38" stroke-opacity="0.3" stroke-width="0.2" fill="none"/>`).join('') + `<path d="M44 0.2q1.4 1 2.6 0" stroke="#7a4a22" stroke-opacity="0.5" stroke-width="0.35" fill="none"/>`;
      const edS = rep(12, i => `<rect x="${f1(i * 3.5)}" width="3.5" height="4.4" fill="#000000" opacity="${i % 2 ? 0.04 : 0.1}"/><path d="M${f1(i * 3.5 + 0.6)} 4.4Q${f1(i * 3.5 + 1.75)} 1 ${f1(i * 3.5 + 2.9)} 4.4" stroke="#7a4a22" stroke-opacity="0.3" stroke-width="0.2" fill="none"/>`).join('');
      const slab = box3(C, { c: [0, TY - 4.4, 0], w: 64, h: 4.4, d: 42, r: 0.8, col: PN, olw: 0.4, dec: { f: edF, b: edF, l: edS, r: edS, t: topD } });
      // +x end: chrome towel bar + towel; -x end: rail with S-hooks + utensils
      const BX = LX + 3.6, towX = `<rect width="12" height="18" fill="#f6efe6"/><rect y="12.6" width="12" height="1.4" fill="#5a8a5a"/><rect y="14.8" width="12" height="0.6" fill="#5a8a5a"/>` + rep(12, i => `<path d="M${f1(0.5 + i)} ${f1(17.8 + (i % 2) * 0.2)}v0.8" stroke="#5a8a5a" stroke-width="0.25"/>`).join('');
      const endP = [-12, 12].map(z => cyl3(C, [LX + 1.6, 47, z], [BX, 47, z], 0.45, CH, { mat: 'chrome', n: 10, olw: 0.2 })).join('') + cyl3(C, [BX, 47, -13.6], [BX, 47, 13.6], 0.55, CH, { mat: 'chrome', n: 12, olw: 0.2 }) + PLN(C, [BX + 0.6, 47.6, 6], [0, 0, -1], [0, -1, 0], towS(12, 18, '#f6efe6', towX, 5.2));
      const HX = -LX - 3.4, hook = (z, s) => sway(C, [HX, 50, z], H2(C, [HX, 50.4, z], [HX, 48.8, z], 0.25, CH) + s, 2.4, 4.6, -z * 0.12);
      const uten = vsort(C, [{ q: [HX, 42, -8], s: hook(-8, H2(C, [HX, 48.8, -8], [HX, 38.6, -8], 0.5, CH) + sph(C, [HX, 37, -8], 1.9, CH)) },
        { q: [HX, 42, 0], s: hook(0, H2(C, [HX, 48.8, 0], [HX, 44, 0], 1.1, '#c8945a') + (() => { const p = C.P([HX, 40, 0]); return [2, 1.3, 0.5].map(rx => `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(rx * C.k)}" ry="${f1(4 * C.k)}" fill="none" stroke="${CH}" stroke-width="${f1(0.22 * C.k)}"/>`).join(''); })()) },
        { q: [HX, 42, 8], s: hook(8, H2(C, [HX, 48.8, 8], [HX, 39.4, 8], 0.7, '#b8844a') + (() => { const p = C.P([HX, 37.6, 8]); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(1.4 * C.k)}" ry="${f1(2.2 * C.k)}" fill="#b8844a"/>`; })()) }]);
      const endM = [-12, 12].map(z => cyl3(C, [-LX - 1.6, 50, z], [HX, 50, z], 0.45, CH, { mat: 'chrome', n: 10, olw: 0.2 })).join('') + cyl3(C, [HX, 50, -13.6], [HX, 50, 13.6], 0.5, CH, { mat: 'chrome', n: 12, olw: 0.2 }) + uten;
      const endN = v0 ? endP : endM, endF = v0 ? endM : endP;
      // top things
      const p0 = C.P([0, 0, 0]), p1 = C.P([0, 0, 3.4]), rdx = f1(p1[0] - p0[0]), rdy = f1(p1[1] - p0[1]);
      const dough = PLN(C, [-8, TY + 0.06, 2], [1, 0, 0], [0, 0, 1], `<ellipse rx="11" ry="7.6" fill="#f1e0bc"/><ellipse rx="11" ry="7.6" fill="url(#m10s)" opacity="0.3"/>` + `<g transform="translate(-9 -6)">${specks(R, 26, 18, 12, ['#ffffff'], 0.15, 0.4, 0.8)}</g>`);
      const pin = cyl3(C, [-18, TY + 2.4, 2], [2, TY + 2.4, 2], 2, '#d8b07a', { mat: 'matte', n: 20, olw: 0.3 }), hdl = (a, b) => cyl3(C, a, b, 0.75, '#c89a5c', { mat: 'gloss', n: 12, olw: 0.25 });
      const hL = hdl([-22.4, TY + 2.4, 2], [-18, TY + 2.4, 2]), hR = hdl([2, TY + 2.4, 2], [6.4, TY + 2.4, 2]);
      const pinG = `<g>${at('translate', `0 0;${rdx} ${rdy};0 0;-${rdx} -${rdy};0 0`.replace(/--/g, ''), 6, 0, SPL(4))}${v0 ? hL + pin + hR : hR + pin + hL}</g>`;
      const eggs = cyl3(C, [17, TY, -10], [17, TY + 3.8, -10], 3.4, '#5a7ea8', { r2: 5.8, mat: 'gloss', n: 26, olw: 0.3, capCol: '#3e5e86' }) + vsort(C, [[-2, 0.4], [2, -0.6], [0, -2.4], [0.4, 2.2], [0, 0, 1]].map(([dx, dz, up]) => { const q = [17 + dx, TY + 4.4 + (up ? 1.3 : 0), -10 + dz]; return { q, s: sph(C, q, 1.7, '#d6a878') }; }));
      const carrots = H2(C, [12, TY + 1, 13], [23, TY + 1, 10.4], 1.7, '#e8782a') + H2(C, [12, TY + 1, 13], [23, TY + 1, 10.4], 0.5, '#f8a050', 0.6) + H2(C, [23, TY + 1, 10.4], [26, TY + 1.6, 9], 0.4, '#5a8a3a') + H2(C, [23, TY + 1, 10.4], [26, TY + 0.8, 11.4], 0.4, '#6a9a3a')
        + vsort(C, [[20, 15.6], [22.4, 16.4], [24.6, 15.2], [26.4, 16.6]].map(([x, z]) => ({ q: [x, TY + 0.3, z], s: cyl3(C, [x, TY, z], [x, TY + 0.6, z], 1, '#e8782a', { mat: 'gloss', n: 14, olw: 0.2, cap: cr => `<circle r="${f1(cr * 0.45)}" fill="#f8a050"/>` }) })))
        + H2(C, [8, TY + 0.5, 17], [13.4, TY + 0.5, 18], 0.9, '#d0d6da') + H2(C, [13.4, TY + 0.6, 18], [17.6, TY + 0.6, 18.8], 1.2, '#4a3426');
      const items = vsort(C, [{ q: [-8, TY + 2, 2], s: dough + pinG }, { q: [17, TY + 3, -10], s: eggs }, { q: [19, TY + 1, 13], s: carrots }]);
      let s = shadow(C, 0, 0, 36, 24, 0.75) + endF + legsF + shelf + apron + legsN + slab + endN + items;
      C.p(0, TY + 8, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // ---------- batch 5: KIT-053 round oak bistro table, KIT-073 waterfall Calacatta island, KIT-093 teppanyaki chef's island ----------
  // KIT-053 4-PERSON ROUND OAK BISTRO DINING TABLE (T3): now round, 96 across (was a 120 x 76 rectangle), top y 52 as before. Oiled white-oak plank top with a
  // soft bevel, turned oak pedestal on four splayed feet with black pads. Four woven rattan placemats; one place set with a croissant and a cup of coffee
  // (steam), a folded linen napkin + fork at another, salt + pepper mills, a speckled vase of yellow tulips (sway). Dappled sunlight drifts across the top.
  N.bist28 = S => { const TY = 52, OAK = '#d2a46c';
    const D = { w: 96, d: 96, round: 1, topH: TY, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('bist28'), lt = lit(C, [0, 1, 0]);
      const gr = (w, h, n, k) => grainH(rng('b28g' + k), w, h, n, '#7a4a22');
      const feet = rep(4, i => { const a = PI / 4 + i * PI / 2, ca = Math.cos(a), sa = Math.sin(a), rc = 18;
        return { q: [ca * rc, 2, sa * rc], s: cyl3(C, [ca * 27.4, 0, sa * 27.4], [ca * 27.4, 0.9, sa * 27.4], 2.2, '#2a2420', { mat: 'gloss', n: 14, olw: 0.2 })
          + box3(C, { c: [ca * rc, 0.9, sa * rc], ax: yawA(-a), w: 22, h: 4.2, d: 5, r: 1.2, col: OAK, olw: 0.3, dec: { f: gr(22, 4.2, 3, i), b: gr(22, 4.2, 3, i + 4), t: gr(22, 5, 3, i + 8) } }) }; });
      const col = cyl3(C, [0, 0.9, 0], [0, 6.4, 0], 7.4, OAK, { r2: 6, mat: 'gloss', n: 26, olw: 0.3, noCap: 1 }) + cyl3(C, [0, 6.4, 0], [0, 8, 0], 6.4, OAK, { r2: 5.4, mat: 'gloss', n: 24, olw: 0.3, noCap: 1 })
        + cyl3(C, [0, 8, 0], [0, 38, 0], 4.4, OAK, { r2: 3.8, mat: 'gloss', n: 22, olw: 0.3, noCap: 1 }) + cyl3(C, [0, 37.6, 0], [0, 39.4, 0], 4.9, OAK, { mat: 'gloss', n: 22, olw: 0.3, noCap: 1 })
        + cyl3(C, [0, 39.4, 0], [0, TY - 6.6, 0], 3.8, OAK, { r2: 8, mat: 'gloss', n: 24, olw: 0.3, noCap: 1 }) + cyl3(C, [0, TY - 6.6, 0], [0, TY - 4.4, 0], 20, '#b88a52', { mat: 'gloss', n: 32, olw: 0.3 });
      const base = vsort(C, feet.concat([{ q: [0, 20, 0], s: col }]));
      const bev = cyl3(C, [0, TY - 4.4, 0], [0, TY - 3.4, 0], 44.2, OAK, { r2: 46, mat: 'gloss', n: 48, olw: 0.3, noCap: 1, f: 0.85 });
      const top = cyl3(C, [0, TY - 3.4, 0], [0, TY, 0], 46, OAK, { mat: 'gloss', n: 48, olw: 0.35, capCol: shade(OAK, lt) });
      const tid = C.u('bt'), pw = 92 / 6;
      const mat = a => { const x = Math.cos(a) * 31, y = Math.sin(a) * 31; return `<g transform="translate(${f1(x)} ${f1(y)})"><circle r="9.6" fill="#c8a062"/>` + rep(6, i => `<circle r="${f1(1.4 + i * 1.4)}" fill="none" stroke="#9a7038" stroke-width="0.35" stroke-dasharray="0.9 0.5"/>`).join('') + `<circle r="9.6" fill="none" stroke="#8a6030" stroke-width="0.6"/><circle r="9.6" fill="url(#m10s)" opacity="0.3"/></g>`; };
      const topD = `<clipPath id="${tid}"><circle r="45.7"/></clipPath><g clip-path="url(#${tid})">` + rep(6, i => `<rect x="${f1(-46 + i * pw)}" y="-46" width="${f1(pw)}" height="92" fill="${shade(OAK, lt * (0.93 + R() * 0.12))}"/><g transform="translate(${f1(-46 + i * pw)} -46)">${grainV(rng('b28t' + i), pw, 92, 9, '#9a6a38', '#f0d4a4')}</g><path d="M${f1(-46 + i * pw)} -46V46" stroke="#7a4a22" stroke-opacity="0.3" stroke-width="0.3"/>`).join('')
        + `<rect x="-46" y="-46" width="92" height="92" fill="url(#m10s)" opacity="0.35"/>` + [1, 3, 5, 7].map(k => mat(k * PI / 4)).join('')
        + `<g><ellipse cx="-14" cy="-6" rx="14" ry="9" fill="#fff6dc" opacity="0.2" filter="url(#m10b2)"/><ellipse cx="6" cy="10" rx="8" ry="5" fill="#fff6dc" opacity="0.16" filter="url(#m10b2)"/>${at('translate', '-6 -3;8 4;-6 -3', 16, 0, SPL(2))}</g>`
        + `<circle r="45.4" fill="none" stroke="#ffffff" stroke-opacity="0.3" stroke-width="0.5"/></g>`;
      const topP = PLN(C, [0, TY + 0.02, 0], [1, 0, 0], [0, 0, 1], topD);
      // tulips in a speckled vase
      const VS = '#efe6d4', vase = cyl3(C, [0, TY, 0], [0, TY + 6, 0], 3.2, VS, { r2: 3.9, mat: 'gloss', n: 24, olw: 0.3, noCap: 1 }) + cyl3(C, [0, TY + 6, 0], [0, TY + 8.6, 0], 3.9, VS, { r2: 2.5, mat: 'gloss', n: 24, olw: 0.3, capCol: '#3a4a2a' })
        + `<g transform="${tanF(C, 0, 0, 3.6, C.thV, TY + 4)}">${specks(rng('b28v'), 14, 6, 6, ['#8a7a60', '#5a6a8a'], 0.12, 0.25, 0.8).replace(/cx="/g, 'transform="translate(-3 -3)" cx="')}<path d="M-3.4 -1.4H3.4" stroke="#5a7aa8" stroke-width="0.5"/></g>`;
      const TL = [[-3, 17, -1, '#f2c62e'], [2.6, 18.4, 0.6, '#f0b82a'], [0.4, 20.6, -0.4, '#f2c62e'], [-1.4, 16, 2.6, '#e8a028'], [3.4, 15.6, -2.4, '#f2c62e'], [-4.2, 14.6, -2.8, '#f0b82a'], [1, 14.4, 3.4, '#f2d040']];
      const lvs = [[-1.6, 0, -6.4, 11.6, 1], [1.6, 0.4, 6, 12, -0.6], [0, -1.6, 1, 12.4, -5.4]].map(([x0, z0, x1, y1, z1]) => H2(C, [x0, TY + 8.4, z0], [x1, TY + y1, z1], 1.1, '#4a7a34') + H2(C, [x0, TY + 8.4, z0], [x1, TY + y1, z1], 0.3, '#7aaa5a')).join('');
      const tul = sway(C, [0, TY + 8, 0], lvs + vsort(C, TL.map(([dx, y, dz, c]) => { const t = [dx, TY + y, dz], b = [dx * 0.2, TY + 8, dz * 0.2];
        return { q: t, s: H2(C, b, t, 0.35, '#5a8a3a') + cyl3(C, t, [t[0], t[1] + 2.6, t[2]], 1.15, c, { r2: 1.6, mat: 'gloss', n: 14, olw: 0.2, capCol: shade(c, 0.78) }) + [[-0.9, 0], [0.9, 0], [0, 0.9]].map(([ox, oz]) => H2(C, [t[0] + ox, t[1] + 2.2, t[2] + oz], [t[0] + ox * 0.8, t[1] + 3.3, t[2] + oz * 0.8], 0.7, shade(c, 1.08))).join('') }; })), 1.4, 6.4);
      // place with croissant + coffee
      const a1 = PI / 4, PX = Math.cos(a1) * 31, PZ = Math.sin(a1) * 31;
      const plate = cyl3(C, [PX, TY, PZ], [PX, TY + 0.9, PZ], 5.4, '#fbfaf6', { r2: 7, mat: 'gloss', n: 28, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.74)}" fill="none" stroke="#e2ddd2" stroke-width="0.35"/>` });
      const cro = vsort(C, [-2, -1, 0, 1, 2].map(k => { const a = PI * 0.75 + k * 0.42, q = [PX + 1.6 + Math.cos(a) * 3.2, TY + 1.9, PZ - 0.8 + Math.sin(a) * 3.2], r = [1.1, 1.6, 2, 1.6, 1.1][k + 2]; return { q, s: sph(C, [q[0], TY + 0.9 + r * 0.8, q[2]], r, k % 2 ? '#c88434' : '#d8963e') }; }));
      const CX = PX - 6, CZ = PZ + 5;
      const cup = cyl3(C, [CX, TY, CZ], [CX, TY + 0.6, CZ], 3.4, '#fbfaf6', { mat: 'gloss', n: 22, olw: 0.25 }) + mug2(C, CX, TY + 0.6, CZ, 1.9, 3.6, '#fbfaf6', '#6a3a1a') + puff1(C, [CX, TY + 4.6, CZ], 0.4, 5, 0.1, 0.8);
      // napkin + fork, mills
      const a2 = 5 * PI / 4, NX = Math.cos(a2) * 31, NZ = Math.sin(a2) * 31;
      const nap = box3(C, { c: [NX, TY, NZ], ax: yawA(0.5), w: 7, h: 0.9, d: 9, r: 0.3, col: '#e8e2d4', olw: 0.25, dec: { t: `<path d="M0 3H7M0 6H7" stroke="#b8b0a0" stroke-width="0.25"/><rect y="7.6" width="7" height="0.5" fill="#6a8aa8"/>` } }) + H2(C, [NX + 5, TY + 0.4, NZ - 4], [NX + 7, TY + 0.4, NZ + 4], 0.6, '#c8ccd0') + H2(C, [NX + 4.6, TY + 0.4, NZ - 5.6], [NX + 5.2, TY + 0.4, NZ - 3.2], 1, '#c8ccd0');
      const mill = (x, z, c) => cyl3(C, [x, TY, z], [x, TY + 5, z], 1.3, c, { r2: 1.1, mat: 'gloss', n: 16, olw: 0.25, noCap: 1 }) + sph(C, [x, TY + 5.2, z], 1.3, c);
      const mills = vsort(C, [{ q: [10, TY + 3, -10], s: mill(10, -10, '#3a2a1e') }, { q: [13, TY + 3, -8], s: mill(13, -8, '#e8e0d0') }]);
      const items = vsort(C, [{ q: [0, TY + 6, 0], s: vase + tul }, { q: [PX, TY + 1, PZ], s: plate + cro }, { q: [CX, TY + 2, CZ], s: cup }, { q: [NX, TY + 0.5, NZ], s: nap }, { q: [11.5, TY + 3, -9], s: mills }]);
      let s = shadow(C, 0, 0, 48, 48, 0.7) + base + bev + top + topP + items;
      C.p(0, TY + 24, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-073 WATERFALL CALACATTA MARBLE KITCHEN ISLAND WITH PREP SINK (T4): keeps the island footprint (184 x 76, top 59.2). Book-matched Calacatta slab with
  // waterfall ends on both sides, deep emerald lacquer slim-shaker drawers + doors with polished brass bar pulls, panelled back. Undermount marble prep sink
  // with a brass gooseneck: every 12 s the tap runs over a brass colander of grapes (splashes), a glint slides along the marble edge, a warm pendant pool
  // breathes on the top. White peonies in a glass vase (sway), a walnut board with cheese, figs + grapes, a carafe of lemon water and two tumblers.
  N.cal28 = S => { const TY = 59.2, EM = '#1d4639', MB = '#f6f3ee', BR = '#c9a256', ZF = 36, SX0 = 36, SX1 = 58, SZ0 = -11, SZ1 = 9, DEP = 12, Y0 = TY - DEP, FZ = -17, T = 12;
    const D = { w: 184, d: 76, topH: TY, topW: 120, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('cal28'), fv = vis(C, [0, 0, 1]), v0 = C.v[0] > 0;
      const CU = [0, 46, 92, 138], CXs = [-69, -23, 23, 69];
      const frD = `<rect width="184" height="49.8" fill="url(#m10s)" opacity="0.4"/>` + CU.map(u => shkP(u + 0.8, 0.8, 44.4, 9.6, 2.2, 0.5) + shkP(u + 0.8, 11.6, 44.4, 37.4, 3.2, 0.5)).join('');
      const bkD = `<rect width="184" height="49.8" fill="url(#m10s)" opacity="0.4"/>` + CU.map(u => shkP(u + 0.8, 0.8, 44.4, 48.2, 3.2, 0.5)).join('');
      const kick = box3(C, { c: [0, 0, 0], w: 178, h: 5, d: 64, r: 0.3, col: '#121412', olw: 0.3, skip: { t: 1 } });
      const cab = box3(C, { c: [0, 5, 0], w: 184, h: 49.8, d: 72, r: 0.4, col: EM, gl: 0.45, olw: 0.4, olo: 0.6, skip: { t: 1, l: 1, r: 1 }, dec: { f: frD, b: bkD } });
      const pulls = vsort(C, CXs.map(x => ({ q: [x, 49.3, ZF + 1], s: barH(C, x - 8, x + 8, 49.3, ZF, 2, 0.6, BR, 'chrome', 1.4) })).concat(CXs.map((x, i) => { const px = x + (i % 2 ? -17 : 17); return { q: [px, 36, ZF + 1], s: vbar(C, px, 29, 43, ZF, 2, 0.55, BR, 'chrome') }; })));
      const wfD = (k, L, h) => veins(rng('cal28' + k), L, h) + `<rect width="${L}" height="${h}" fill="url(#m10s)" opacity="0.4"/>`;
      const wf = sg => box3(C, { c: [sg * 94.4, 0, 0], w: 4.8, h: 54.8, d: 80, r: 0.3, col: MB, gl: 0.4, olw: 0.35, olc: '#a8a296', skip: { t: 1 }, dec: { l: wfD('l' + sg, 80, 54.8), r: wfD('r' + sg, 80, 54.8), f: wfD('f' + sg, 4.8, 54.8), b: wfD('b' + sg, 4.8, 54.8) } });
      const eF = v0 ? wf(-1) : wf(1), eN = v0 ? wf(1) : wf(-1);
      const gid = C.u('cg');
      const slab = box3(C, { c: [0, TY - 4.4, 0], w: 193.6, h: 4.4, d: 80, r: 0.4, col: MB, gl: 0.4, olw: 0.35, olc: '#a8a296', skip: { t: 1 }, dec: { f: wfD('sf', 193.6, 4.4) + `<clipPath id="${gid}"><rect width="193.6" height="4.4"/></clipPath><g clip-path="url(#${gid})"><rect x="-14" width="9" height="4.4" fill="#ffffff" opacity="0.55">${at('translate', '0 0;0 0;222 0;222 0', 10, 0, KT('0;0.6;0.86;1'))}</rect></g>`, b: wfD('sb', 193.6, 4.4), l: wfD('sl', 80, 4.4), r: wfD('sr', 80, 4.4) } });
      const top = ctopH(C, -96.8, 96.8, -40, 40, TY, MB, [[SX0, SZ0, SX1, SZ1, 2.4]], veins(R, 193.6, 80) + `<rect width="193.6" height="80" fill="url(#m10s)" opacity="0.35"/><ellipse cx="80" cy="40" rx="44" ry="26" fill="#fff2d6" opacity="0.2" filter="url(#m10b2)">${an('opacity', '0.14;0.26;0.14', 7)}</ellipse>`);
      const rim = ringP(C, TY + 0.03, [SX0 - 1, SZ0 - 1, SX1 + 1, SZ1 + 1, 3.2], [[SX0, SZ0, SX1, SZ1, 2.4]], BR, '');
      // prep sink + colander of grapes + timed tap
      const aP = arcP(47, TY + 15, FZ, [0, 1], 6, -0.25, 12), tip = aP[12], TX = tip[0], TZ = tip[2], NB = [TX, TY + 11.8, TZ], HIT = [TX, Y0 + 7.4, TZ];
      const flD = veins(rng('cal28f'), 22, 20) + `<circle cx="11" cy="15.4" r="1.9" fill="${BR}"/><circle cx="11" cy="15.4" r="1.3" fill="#3a3226"/><ellipse cx="7" cy="6" rx="3" ry="1.4" fill="#ffffff" opacity="0.35"/>`;
      const wd = (k, L, dp) => veins(rng('cal28w' + k), L, dp) + `<path d="M0 0.5H${f1(L)}" stroke="#ffffff" stroke-opacity="0.7" stroke-width="0.4"/>`;
      const colr = cyl3(C, [TX, Y0, TZ], [TX, Y0 + 0.8, TZ], 3, BR, { mat: 'chrome', n: 20, olw: 0.25 }) + cyl3(C, [TX, Y0 + 0.8, TZ], [TX, Y0 + 5.4, TZ], 4.2, BR, { r2: 6.2, mat: 'chrome', n: 26, olw: 0.3, pat: 'm10perf', capCol: '#4a3c22' })
        + grapes(C, TX - 1.8, Y0 + 4.6, TZ - 0.6, '#6a2a58') + grapes(C, TX + 2, Y0 + 4.4, TZ + 1, '#a8c050');
      const gate = (s, k0, k1) => `<g opacity="0">${an('opacity', '0;0;1;1;0;0', T, 0, KT(`0;${k0};${n4(k0 + 0.03)};${k1};${n4(k1 + 0.05)};1`))}${s}</g>`;
      const splash = (() => { const p = C.P(HIT); return `<g transform="translate(${P2(p)}) scale(${n4(C.k)})">` + rep(6, i => { const dx = [-1.6, 1.4, -0.6, 2, -2.2, 0.8][i], dy = [-2.2, -1.8, -2.8, -1.2, -1.4, -2.4][i], d = 0.6 + (i % 3) * 0.12, b = -i * 0.15;
        return `<circle r="0.3" fill="#e8f6fc" opacity="0">${at('translate', `0 0;${f1(dx * 0.6)} ${f1(dy)};${f1(dx)} 0.6`, d, b)}${an('opacity', '0.9;0.7;0', d, b)}</circle>`; }).join('') + `<ellipse rx="1.6" ry="0.7" fill="#ffffff" opacity="0.5">${an('rx', '1.2;1.9;1.2', 0.5)}</ellipse></g>`; })();
      const bas = basin(C, SX0, SX1, SZ0, SZ1, TY, DEP, MB, { floor: flD, wd, dk: 0.22, f: 1.04 }) + colr + pour(C, [TX, TY, TZ], HIT, 0.85, '#dceef6', T, 0.12, 0.45) + gate(splash, 0.14, 0.46);
      const riser = cyl3(C, [47, TY, FZ], [47, TY + 0.8, FZ], 2.4, BR, { mat: 'chrome', n: 20, olw: 0.3 }) + cyl3(C, [47, TY + 0.8, FZ], [47, TY + 15.2, FZ], 1.3, BR, { mat: 'chrome', n: 16, olw: 0.3, noCap: 1 });
      const lev = cyl3(C, [48.2, TY + 6, FZ], [49.4, TY + 6, FZ], 1, BR, { mat: 'chrome', n: 12, olw: 0.2 }) + cyl3(C, [49.3, TY + 6.2, FZ], [53, TY + 7.2, FZ], 0.4, BR, { r2: 0.5, mat: 'chrome', n: 10, olw: 0.2 });
      const fau = vsort(C, [{ q: [47, TY + 8, FZ], s: v0 ? riser + lev : lev + riser }, ...pipe(C, aP, 1, BR, 'chrome'), { q: [TX, TY + 12.6, TZ], s: cyl3(C, tip, NB, 1.1, BR, { mat: 'chrome', n: 14, olw: 0.25 }) }, { q: [TX, TY + 6, TZ + 0.2], s: pour(C, NB, [TX, TY, TZ], 0.85, '#dceef6', T, 0.1, 0.43) }]);
      // peonies in a glass vase
      const VX = -66, VZ = -10;
      const vase = cyl3(C, [VX, TY, VZ], [VX, TY + 6, VZ], 2.8, '#d4ece6', { mat: 'gloss', n: 20, op: 0.35, olw: 0, noCap: 1 }) + cyl3(C, [VX, TY, VZ], [VX, TY + 10, VZ], 3.2, '#e8f4f2', { r2: 3.8, mat: 'chrome', n: 24, op: 0.32, olw: 0.3, olc: '#8aa0a0', capCol: '#d8ece8' });
      const PE = [[-3.6, 19, -1], [3, 20, 1], [0, 23, -0.4], [-1, 17, 3], [4, 16.6, -2.6]];
      const peo = sway(C, [VX, TY + 10, VZ], [[-2, 0, -7, 13, 1], [2, 0.4, 6.4, 14, -1]].map(([x0, z0, x1, y1, z1]) => H2(C, [VX + x0, TY + 10, VZ + z0], [VX + x1, TY + y1, VZ + z1], 1.2, '#4a7a3a')).join('') + vsort(C, PE.map(([dx, y, dz], j) => { const t = [VX + dx, TY + y, VZ + dz];
        return { q: t, s: H2(C, [VX + dx * 0.2, TY + 9, VZ + dz * 0.2], t, 0.35, '#5a8a3a') + sph(C, t, 2.7, '#f2cdd4') + vsort(C, rep(5, k => { const a = k * 1.26 + j, q = [t[0] + Math.cos(a) * 1.4, t[1] + 1.2, t[2] + Math.sin(a) * 1.4]; return { q, s: sph(C, q, 1.3, k % 2 ? '#f8dde2' : '#f6d2da') }; })) + sph(C, [t[0], t[1] + 1.9, t[2]], 0.9, '#eeb4c2') }; })), 1.2, 7);
      // walnut board: cheese, figs, grapes, knife
      const BX = -24, BZ = 10;
      const board = box3(C, { c: [BX, TY, BZ], w: 24, h: 1.6, d: 14, r: 2, col: '#6a4229', olw: 0.3, dec: { t: grainH(rng('cal28g'), 24, 14, 9, '#3a2414') } });
      const cheese = cyl3(C, [BX - 6, TY + 1.6, BZ - 1], [BX - 6, TY + 4.4, BZ - 1], 3.6, '#f2d48a', { mat: 'gloss', n: 24, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#f6e0a0"/>` + rep(5, i => `<circle cx="${f1(Math.cos(i * 2.1) * cr * 0.5)}" cy="${f1(Math.sin(i * 1.7) * cr * 0.45)}" r="0.35" fill="#e0c070"/>`).join('') });
      const figs = vsort(C, [[BX + 1, BZ - 3], [BX + 3.6, BZ - 1.6]].map(([x, z]) => ({ q: [x, TY + 3, z], s: sph(C, [x, TY + 3.4, z], 1.8, '#5a2c46') + H2(C, [x, TY + 5, z], [x + 0.3, TY + 5.9, z], 0.5, '#6a4a3a') }))
        .concat([{ q: [BX + 2, TY + 2, BZ + 3], s: cyl3(C, [BX + 2, TY + 1.6, BZ + 3], [BX + 2, TY + 2.6, BZ + 3], 1.7, '#6a2c4a', { mat: 'gloss', n: 18, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#e8b4a0"/><circle r="${f1(cr * 0.55)}" fill="#c8506a"/>` + rep(8, i => `<circle cx="${f1(Math.cos(i * 0.8) * cr * 0.35)}" cy="${f1(Math.sin(i * 0.8) * cr * 0.35)}" r="0.15" fill="#f4e0c0"/>`).join('') }) }, { q: [BX + 7.4, TY + 3, BZ], s: grapes(C, BX + 7.4, TY + 1.6, BZ, '#7a3060') }]));
      const knife = H2(C, [BX - 9, TY + 1.8, BZ + 5], [BX - 2, TY + 1.8, BZ + 5.8], 0.8, '#d0d6da') + H2(C, [BX - 2, TY + 1.9, BZ + 5.8], [BX + 2.4, TY + 1.9, BZ + 6.2], 1.2, '#2a1c14');
      // carafe of lemon water + two tumblers
      const KX = 6, KZ = -20;
      const lem = (x, y, z) => cyl3(C, [x, y, z - 0.25], [x, y, z + 0.25], 1.4, '#f2d23a', { mat: 'gloss', n: 16, olw: 0, op: 0.85, cap: cr => `<circle r="${f1(cr * 0.85)}" fill="#fff2a0"/>` + rep(6, i => `<path d="M0 0L${f1(Math.cos(i * PI / 3) * cr * 0.8)} ${f1(Math.sin(i * PI / 3) * cr * 0.8)}" stroke="#f4e8b0" stroke-width="0.2"/>`).join('') });
      const car = cyl3(C, [KX, TY, KZ], [KX, TY + 7, KZ], 2.9, '#e2f2f4', { mat: 'gloss', n: 20, olw: 0, op: 0.4, noCap: 1 }) + lem(KX - 0.6, TY + 3, KZ + 0.6) + lem(KX + 0.8, TY + 5, KZ - 0.4)
        + cyl3(C, [KX, TY, KZ], [KX, TY + 8, KZ], 3.2, '#eef8f8', { r2: 2.6, mat: 'chrome', n: 24, op: 0.3, olw: 0.3, olc: '#8aa0a4', noCap: 1 }) + cyl3(C, [KX, TY + 8, KZ], [KX, TY + 11, KZ], 2.6, '#eef8f8', { r2: 1.6, mat: 'chrome', n: 20, op: 0.32, olw: 0.3, olc: '#8aa0a4', capCol: '#e4f2f2' });
      const tmb = (x, z) => cyl3(C, [x, TY, z], [x, TY + 2.6, z], 1.6, '#e2f2f4', { mat: 'gloss', n: 16, olw: 0, op: 0.4 }) + cyl3(C, [x, TY, z], [x, TY + 4.2, z], 1.8, '#eef8f8', { mat: 'chrome', n: 18, op: 0.32, olw: 0.3, olc: '#8aa0a4', capCol: '#e4f2f2' });
      const items = vsort(C, [{ q: [47, TY + 9, FZ + 4], s: fau }, { q: [VX, TY + 6, VZ], s: vase + peo }, { q: [BX, TY + 1, BZ], s: board + cheese + figs + knife }, { q: [KX, TY + 5, KZ], s: car }, { q: [KX + 6, TY + 2, KZ + 2], s: tmb(KX + 6, KZ + 2) }, { q: [KX + 10, TY + 2, KZ - 1], s: tmb(KX + 10, KZ - 1) }]);
      let s = shadow(C, 0, 0, 100, 44, 0.7) + bas + kick + eF + cab + eN + (fv ? pulls : '') + slab + top + rim + items;
      C.p(VX, TY + 28, VZ);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-093 CANTILEVERED TEPPANYAKI & INTERACTIVE SMART-SCALE CHEF'S ISLAND (T5): keeps the island footprint (184 x 76, top 59.2). Fluted walnut base with
  // champagne-gold reveals over a breathing amber glow carries a thick Nero Marquina slab (black, white veins, gold underline) that cantilevers 56 out past
  // the base; the floating end holds a brushed-steel teppanyaki plate in a gold rim (heat tint, shimmer): shrimp, scallops and zucchini sizzle and hop,
  // steam curls, a gold-handled spatula scrapes. The smart scale is a flush black-glass square in a gold rim with an amber readout under a slate of wagyu.
  // Black bowl of yuzu, a sake set on a walnut tray.
  N.tep28 = S => { const TY = 59.2, NM = '#1c1b1e', WN = '#5e3b24', CG = '#d6b878', ST = '#8e949a';
    const D = { w: 184, d: 76, topH: TY, topW: 120, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('tep28'), v0 = C.v[0] > 0, lt = lit(C, [0, 1, 0]);
      const mqV = (R2, w, h, n) => rep(n, () => { let x = R2() * w, y = 0, d = `M${f1(x)} 0`; const k = 3 + Math.floor(R2() * 3); for (let j = 0; j < k; j++) { const nx = x + (R2() - 0.35) * w * 0.25, ny = y + h / k; d += `Q${f1((x + nx) / 2 + (R2() - 0.5) * w * 0.08)} ${f1((y + ny) / 2)} ${f1(nx)} ${f1(ny)}`; x = nx; y = ny; }
        return `<path d="${d}" stroke="#f4f2ee" stroke-opacity="${n4(0.22 + R2() * 0.45)}" stroke-width="${f1(0.15 + R2() * 0.5)}" fill="none"/>`; }).join('');
      const flt = (L, k) => grainV(rng('t28' + k), L, 48.2, Math.round(L / 3), '#3a2414', '#9a6a44') + `<rect width="${L}" height="48.2" fill="url(#k28flt)"/><rect width="${L}" height="48.2" fill="url(#m10s)" opacity="0.35"/>` + rep(Math.floor(L / 33) + 1, i => `<path d="M${f1(i * 33)} 0V48.2" stroke="${CG}" stroke-width="0.55"/>`).join('') + `<path d="M0 0.4H${L}" stroke="${CG}" stroke-width="0.6"/>`;
      const glow = PLN(C, [-26, 0.06, 32], [1, 0, 0], [0, 0, 1], `<ellipse rx="66" ry="7" fill="url(#k28amb)">${an('opacity', '0.75;1;0.75', 6)}</ellipse>`) + PLN(C, [68, 0.06, 0], [1, 0, 0], [0, 0, 1], `<ellipse rx="24" ry="30" fill="url(#k28amb)" opacity="0.45">${an('opacity', '0.35;0.55;0.35', 6)}</ellipse>`);
      const kick = box3(C, { c: [-26, 0, 0], w: 126, h: 5, d: 64, r: 0.3, col: '#0e0d0c', olw: 0.3, skip: { t: 1 } });
      const body = box3(C, { c: [-26, 5, 0], w: 132, h: 48.2, d: 72, r: 0.4, col: WN, gl: 0.3, olw: 0.4, olo: 0.6, skip: { t: 1 }, dec: { f: flt(132, 'f'), b: flt(132, 'b'), l: flt(72, 'l'), r: flt(72, 'r') } });
      const sd = (L, k) => mqV(rng('tps' + k), L, 6, Math.round(L / 14)) + `<rect width="${L}" height="6" fill="url(#m10s)" opacity="0.5"/><path d="M0 5.6H${L}" stroke="${CG}" stroke-width="0.7"/>`;
      const slab = box3(C, { c: [0, TY - 6, 0], w: 192, h: 6, d: 80, r: 0.5, col: NM, gl: 0.6, olw: 0.4, olc: '#000000', skip: { t: 1 }, dec: { f: sd(192, 'f'), b: sd(192, 'b'), l: sd(80, 'l'), r: sd(80, 'r') } });
      const top = ctopH(C, -96, 96, -40, 40, TY, NM, [], rep(8, () => `<ellipse cx="${f1(R() * 192)}" cy="${f1(R() * 80)}" rx="${f1(10 + R() * 22)}" ry="${f1(4 + R() * 8)}" fill="#3a3640" opacity="0.25" filter="url(#m10b2)"/>`).join('') + mqV(R, 192, 80, 14) + `<rect width="192" height="80" fill="url(#m10s)" opacity="0.4"/>`);
      // teppanyaki plate (x 46..90, z -26..26)
      const gd = C.u('gd'), gx = Array.from({ length: 12 }, () => [R() * 44, R() * 52]);
      const grid = PLN(C, [46, TY + 0.04, -26], [1, 0, 0], [0, 0, 1], `<defs><radialGradient id="${gd}" cx="0.5" cy="0.5" r="0.6"><stop offset="0" stop-color="#e0a860" stop-opacity="0.4"/><stop offset="0.45" stop-color="#6a7ab8" stop-opacity="0.22"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></radialGradient></defs>`
        + `<rect width="44" height="52" rx="1.2" fill="${shade(ST, lt * 0.78)}"/><rect width="44" height="52" rx="1.2" fill="url(#m10brush)" opacity="0.8"/><rect width="44" height="52" rx="1.2" fill="#2a2420" opacity="0.18"/><rect width="44" height="52" rx="1.2" fill="url(#${gd})">${an('opacity', '0.7;1;0.7', 4)}</rect>`
        + `<rect width="44" height="52" rx="1.2" fill="url(#m10s)" opacity="0.4"/><rect x="0.6" y="0.6" width="42.8" height="50.8" rx="1" fill="none" stroke="#000000" stroke-opacity="0.25" stroke-width="0.5"/>`
        + gx.map(([x, y], i) => `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.35" fill="#fff6e0" opacity="0">${an('opacity', '0;0;0.9;0', 1.6 + (i % 4) * 0.3, -i * 0.37, KT('0;0.7;0.78;1'))}</circle>`).join('')
        + `<ellipse cx="22" cy="30" rx="9" ry="6" fill="#e8c060" opacity="0.18"/>`);
      const rimG = ringP(C, TY + 0.06, [45, -27, 91, 27, 1.8], [[46, -26, 90, 26, 1.2]], CG, '');
      const guard = box3(C, { c: [68, TY, -26.6], w: 44, h: 3.2, d: 1, r: 0.2, col: ST, gl: 0.5, olw: 0.25, mat: 'brush', dec: { t: `<rect width="44" height="1" fill="${CG}"/>` } });
      const hop = (s, b, T) => `<g>${at('translate', `0 0;0 ${f1(-1.1 * C.k)};0 0;0 0`, T || 2.6, b, KT('0;0.06;0.13;1'))}${s}</g>`;
      const shrimp = (x, z, r0, b) => hop(vsort(C, [1.3, 1.2, 1, 0.7].map((r, k) => { const a = r0 + k * 0.85, q = [x + Math.cos(a) * 2.2, TY + 0.05 + r, z + Math.sin(a) * 2.2]; return { q, s: sph(C, q, r, k % 2 ? '#f29a6a' : '#ee8656') }; }))
        + (() => { const a = r0 + 3.3, q = [x + Math.cos(a) * 2.4, TY + 0.7, z + Math.sin(a) * 2.4]; return H2(C, q, [q[0] + Math.cos(a + 1.6) * 1.4, q[1], q[2] + Math.sin(a + 1.6) * 1.4], 1.1, '#d8582e'); })(), b);
      const scal = (x, z, b) => hop(cyl3(C, [x, TY + 0.05, z], [x, TY + 1.6, z], 1.9, '#f4e6cc', { mat: 'gloss', n: 18, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.92)}" fill="#c8843a"/><circle r="${f1(cr * 0.55)}" fill="#e0a860"/><circle cx="${f1(-cr * 0.3)}" cy="${f1(-cr * 0.3)}" r="${f1(cr * 0.2)}" fill="#ffffff" opacity="0.3"/>` }), b, 3.1);
      const zuc = (x, z, b) => hop(cyl3(C, [x, TY + 0.05, z], [x, TY + 0.8, z], 1.35, '#3e6e26', { mat: 'gloss', n: 16, olw: 0.2, cap: cr => `<circle r="${f1(cr * 0.82)}" fill="#e2ecb8"/><circle r="${f1(cr * 0.4)}" fill="#c8d890"/>` + rep(5, i => `<circle cx="${f1(Math.cos(i * 1.26) * cr * 0.4)}" cy="${f1(Math.sin(i * 1.26) * cr * 0.4)}" r="0.12" fill="#f4f4d8"/>`).join('') }), b, 3.6);
      const FD = [[54, -14, 'sh', 0.4], [60, -8, 'sh', 2.2], [52, -3, 'sh', 4], [61, -18, 'sh', 1.2], [74, -12, 'sc'], [79, -6, 'sc'], [72, -3, 'sc'], [56, 10, 'zu'], [60, 13, 'zu'], [64, 9, 'zu'], [58, 16, 'zu'], [66, 15, 'zu']];
      const food = FD.map(([x, z, k, r0], i) => ({ q: [x, TY + 1, z], s: k === 'sh' ? shrimp(x, z, r0, -i * 0.43) : k === 'sc' ? scal(x, z, -i * 0.61) : zuc(x, z, -i * 0.29) }));
      const butter = { q: [80, TY + 0.6, 10], s: box3(C, { c: [80, TY + 0.05, 10], w: 3.4, h: 1.2, d: 2.6, r: 0.6, col: '#f6dc80', gl: 0.6, olw: 0.2 }) + PLN(C, [80, TY + 0.07, 10], [1, 0, 0], [0, 0, 1], `<ellipse rx="3.6" ry="2.8" fill="#f2d070" opacity="0.4"/>`) };
      const p0 = C.P([0, 0, 0]), p1 = C.P([7, 0, 0]), sdx = f1(p1[0] - p0[0]), sdy = f1(p1[1] - p0[1]);
      const spat = (x, anim) => { const bl = PLN(C, [x - 2.6, TY + 0.3, 15.4], [1, 0, 0], [0, 0, 1], `<rect width="5.2" height="6.4" rx="0.4" fill="#a4aab0"/><rect width="5.2" height="6.4" rx="0.4" fill="none" stroke="#5a6066" stroke-width="0.3"/><rect width="5.2" height="6.4" rx="0.4" fill="url(#m10s)" opacity="0.5"/><path d="M0.2 0.3H5" stroke="#ffffff" stroke-width="0.25"/>`)
        + H2(C, [x, TY + 0.4, 21.6], [x, TY + 1.2, 24.6], 0.5, '#c8ccd0') + H2(C, [x, TY + 1.2, 24.6], [x, TY + 1.8, 31], 1.2, CG); return anim ? `<g>${at('translate', `0 0;-${sdx} -${sdy};0 0;0 0`.replace(/--/g, ''), 5, 0, KT('0;0.2;0.4;1') + ' calcMode="spline" keySplines="0.45 0 0.55 1;0.45 0 0.55 1;0 0 1 1"')}${bl}</g>` : bl; };
      const steam = [[56, -10, 0], [76, -8, -1.6], [60, 13, -3.1]].map(([x, z, b]) => puff1(C, [x, TY + 3, z], 0.55, 4.4, 0.1, 0.85, b)).join('');
      const shm = (() => { const p = C.P([68, TY + 1, 0]); return `<g transform="translate(${P2(p)}) scale(${n4(C.k)})">` + rep(5, i => `<path d="M${-12 + i * 6} 0q1.4 -2 0 -4t0 -4t0 -4" stroke="#ffe0b8" stroke-width="0.45" fill="none" opacity="0">${at('translate', '0 0;0 -7', 2.6, -i * 0.52)}${an('opacity', '0;0.3;0', 2.6, -i * 0.52)}</path>`).join('') + '</g>'; })();
      // smart scale (x -78..-52, z -13..13): black glass, gold rim, amber readout; slate of wagyu on it
      const scl = PLN(C, [-78, TY + 0.04, -13], [1, 0, 0], [0, 0, 1], `<rect width="26" height="26" rx="1.4" fill="#0a0a0d"/><rect width="26" height="26" rx="1.4" fill="url(#m10s)" opacity="0.5"/><path d="M2 24L12 2H15L5 24Z" fill="#ffffff" opacity="0.05"/>`
        + `<text x="13" y="23.4" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="3" fill="#ffb84a">412 g${an('opacity', '1;1;0;1', 3.2, 0, KT('0;0.6;0.62;1'))}</text><text x="13" y="23.4" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="3" fill="#ffb84a" opacity="0">413 g${an('opacity', '0;0;1;0', 3.2, 0, KT('0;0.6;0.62;1'))}</text>`
        + `<circle cx="3" cy="22.4" r="0.7" fill="none" stroke="${CG}" stroke-width="0.25"/><circle cx="23" cy="22.4" r="0.7" fill="none" stroke="${CG}" stroke-width="0.25"/><text x="3" y="24.8" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="0.8" fill="${CG}">TARE</text><text x="23" y="24.8" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="0.8" fill="${CG}">g/oz</text>`)
        + ringP(C, TY + 0.06, [-79, -14, -51, 14, 2], [[-78, -13, -52, 13, 1.4]], CG, '');
      const mb = (L, h, k) => rep(Math.round(L * h / 5), () => { const x = R() * L, y = R() * h; return `<path d="M${f1(x)} ${f1(y)}q${f1(0.6 + R())} ${f1((R() - 0.5) * 1.4)} ${f1(1.2 + R() * 1.4)} ${f1((R() - 0.5) * 0.8)}" stroke="#fbe8e4" stroke-opacity="0.75" stroke-width="${f1(0.15 + R() * 0.3)}" fill="none"/>`; }).join('');
      const slate = box3(C, { c: [-65, TY + 0.06, -3], w: 17, h: 0.8, d: 12, r: 0.5, col: '#3a3e42', olw: 0.25, dec: { t: specks(rng('t28s'), 30, 17, 12, ['#5a5e62', '#2a2e32'], 0.2, 0.6, 0.6) } });
      const wag = box3(C, { c: [-65, TY + 0.86, -3], w: 9, h: 3, d: 6, r: 0.8, col: '#b8323a', gl: 0.3, olw: 0.25, olc: '#6a1a1e', dec: { t: mb(9, 6), f: mb(9, 3), b: mb(9, 3), l: mb(6, 3), r: mb(6, 3) } }) + PLN(C, [-60.4, TY + 0.9, 1.6], [1, 0, 0], [0, 0, 1], `<path d="M0 0l0.6 0.6l0.4 -0.3l0.5 0.5" stroke="#f4f2ee" stroke-width="0.25" fill="none"/>`);
      // yuzu bowl, sake set
      const yz = cyl3(C, [-30, TY, -20], [-30, TY + 3.4, -20], 3.4, '#1c1a1a', { r2: 6.2, mat: 'gloss', n: 26, olw: 0.3, capCol: '#0c0b0b' }) + vsort(C, [[-2.2, 0], [2.4, -0.6], [0, -2.6], [0.4, 2.4], [0, 0, 1]].map(([dx, dz, up]) => { const q = [-30 + dx, TY + 4.2 + (up ? 1.6 : 0), -20 + dz]; return { q, s: sph(C, q, 2.2, '#f2c41e') + `<circle cx="${f1(C.P(q)[0])}" cy="${f1(C.P([q[0], q[1] + 2, q[2]])[1])}" r="${f1(0.25 * C.k)}" fill="#6a7a2a"/>` }; }))
        + H2(C, [-30, TY + 7.6, -20], [-27, TY + 8.4, -21], 1.2, '#4a7a34');
      const tray = box3(C, { c: [-4, TY, 18], w: 15, h: 0.8, d: 8, r: 0.6, col: WN, olw: 0.25, dec: { t: grainH(rng('t28t'), 15, 8, 5, '#3a2414') } });
      const tok = cyl3(C, [-8, TY + 0.8, 18], [-8, TY + 4, 18], 1.7, '#f4f2ec', { r2: 2.3, mat: 'gloss', n: 18, olw: 0.25, noCap: 1 }) + cyl3(C, [-8, TY + 4, 18], [-8, TY + 7, 18], 2.3, '#f4f2ec', { r2: 0.9, mat: 'gloss', n: 18, olw: 0.25, noCap: 1 }) + cyl3(C, [-8, TY + 7, 18], [-8, TY + 8, 18], 0.9, '#f4f2ec', { r2: 1.1, mat: 'gloss', n: 14, olw: 0.25, capCol: '#2a2a2a' })
        + `<g transform="${tanF(C, -8, 18, 2.2, C.thV, TY + 4)}"><path d="M-1.6 -0.6H1.6M-1.4 0.3H1.4" stroke="#3a5a9a" stroke-width="0.35"/></g>`;
      const och = (x, z) => cyl3(C, [x, TY + 0.8, z], [x, TY + 2.4, z], 1.1, '#f4f2ec', { r2: 1.5, mat: 'gloss', n: 16, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.86)}" fill="#e8e6dc"/><circle r="${f1(cr * 0.5)}" fill="none" stroke="#3a5a9a" stroke-width="0.25"/>` });
      const sake = tray + vsort(C, [{ q: [-8, TY + 4, 18], s: tok }, { q: [-2, TY + 1.6, 17], s: och(-2, 17) }, { q: [2, TY + 1.6, 19.6], s: och(2, 19.6) }]);
      const items = vsort(C, food.concat([butter, { q: [68, TY + 1.6, -26.6], s: guard }, { q: [58, TY + 1, 24], s: spat(58, 0) }, { q: [72, TY + 1, 24], s: spat(72, 1) }, { q: [-65, TY + 2, -3], s: slate + wag }, { q: [-30, TY + 3, -20], s: yz }, { q: [-4, TY + 2, 18], s: sake }]));
      let s = shadow(C, -26, 0, 74, 42, 0.7) + shadow(C, 68, 0, 26, 34, 0.25) + glow + kick + body + slab + top + grid + rimG + scl + items + steam + shm;
      C.p(-8, TY + 12, 18);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // ---------- batch 6: dining tables KIT-102 / 103 / 104 (table only; footprints, topH 65 + topW kept) ----------
  const flm = (C, q, s, b) => { const p = C.P(q); C.p(q[0], q[1] + 5 * s, q[2]); return `<g transform="translate(${P2(p)}) scale(${n4(C.k * s)})"><circle cy="-2" r="6" fill="url(#k28bulb)">${an('opacity', '0.55;0.85;0.5;0.8;0.55', 1.6, b)}</circle><path d="M0 0V-0.8" stroke="#2a2018" stroke-width="0.25"/><ellipse cy="-2" rx="0.9" ry="1.9" fill="#ffc860">${an('ry', '1.9;2.3;1.7;2.1;1.9', 0.9, b)}${an('cy', '-2;-2.3;-1.9;-2.2;-2', 0.9, b)}</ellipse><ellipse cy="-1.6" rx="0.45" ry="1" fill="#fff4d0"/></g>`; };
  const taper = (C, x, y, z, h, col, b) => cyl3(C, [x, y, z], [x, y + h, z], 0.75, col, { r2: 0.6, mat: 'matte', n: 12, olw: 0.2, capCol: shade(col, 0.85) }) + flm(C, [x, y + h + 0.1, z], 0.75, b);
  const bstick = (C, x, y, z, hh, col, b, wax) => cyl3(C, [x, y, z], [x, y + 0.8, z], 2.4, col, { mat: 'chrome', n: 18, olw: 0.25 }) + cyl3(C, [x, y + 0.8, z], [x, y + hh, z], 0.5, col, { r2: 0.4, mat: 'chrome', n: 10, olw: 0.2, noCap: 1 }) + sph(C, [x, y + hh * 0.45, z], 0.9, col)
    + cyl3(C, [x, y + hh, z], [x, y + hh + 1, z], 1.1, col, { mat: 'chrome', n: 14, olw: 0.2 }) + taper(C, x, y + hh + 1, z, 9, wax || '#f4ecd8', b);
  const wglass = (C, x, y, z, wine) => cyl3(C, [x, y, z], [x, y + 0.3, z], 1.6, '#eef6f6', { mat: 'chrome', n: 16, op: 0.45, olw: 0.2, olc: '#8aa4aa' }) + cyl3(C, [x, y + 0.3, z], [x, y + 3.6, z], 0.22, '#eef6f6', { mat: 'chrome', n: 8, op: 0.6, olw: 0.15, olc: '#8aa4aa' })
    + (wine ? cyl3(C, [x, y + 3.9, z], [x, y + 5.4, z], 1.05, wine, { r2: 1.45, mat: 'gloss', n: 16, olw: 0, op: 0.88 }) : '') + cyl3(C, [x, y + 3.6, z], [x, y + 7.6, z], 0.9, '#eef6f6', { r2: 1.75, mat: 'chrome', n: 18, op: 0.3, olw: 0.25, olc: '#8aa4aa', noCap: 1 });
  const glintT = (C, w, h, T, bw) => { const id = C.u('gl'); return `<clipPath id="${id}"><rect width="${w}" height="${h}"/></clipPath><g clip-path="url(#${id})"><path d="M${-bw * 2} 0H${-bw}L${-bw * 2} ${h}H${-bw * 3}Z" fill="#ffffff" opacity="0.18">${at('translate', `0 0;0 0;${f1(w + bw * 4)} 0;${f1(w + bw * 4)} 0`, T, 0, KT('0;0.55;0.85;1'))}</path></g>`; };

  // KIT-102 SOLID OAK & CARRARA MARBLE 4-SEAT ROUND DINING TABLE (T3): 136 footprint kept (top r 60, y 60..65). Turned oak pedestal on four sabre feet with
  // brass toe caps, oak apron, thin brass inlay ring under a bullnosed Carrara top. Four places set (gold-rimmed chargers, white plates, linen napkins,
  // cutlery, wine glasses), a ceramic bowl of clementines in the middle between two brass candlesticks with flickering tapers; a slow light sweep on the marble.
  N.oak28 = S => { const TY = 65, OAK = '#c8925a', MB = '#f4f1ec', BR = '#c9a256';
    const D = { w: 136, d: 136, round: 1, topH: TY, topW: 84, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('oak28'), lt = lit(C, [0, 1, 0]);
      const gr = (w, h, n, k) => grainH(rng('o28g' + k), w, h, n, '#7a4a22');
      const feet = rep(4, i => { const a = PI / 4 + i * PI / 2, ca = Math.cos(a), sa = Math.sin(a);
        return { q: [ca * 20, 2, sa * 20], s: box3(C, { c: [ca * 20, 0, sa * 20], ax: yawA(-a), w: 26, h: 5, d: 6.4, r: 1.6, col: OAK, olw: 0.3, dec: { f: gr(26, 5, 3, i), b: gr(26, 5, 3, i + 4), t: gr(26, 6.4, 3, i + 8) } })
          + cyl3(C, [ca * 33.6, 0, sa * 33.6], [ca * 33.6, 3.6, sa * 33.6], 1.9, BR, { mat: 'chrome', n: 14, olw: 0.2 }) }; });
      const col = cyl3(C, [0, 5, 0], [0, 11, 0], 9.6, OAK, { r2: 7.6, mat: 'gloss', n: 26, olw: 0.3, noCap: 1 }) + cyl3(C, [0, 11, 0], [0, 12.8, 0], 7.8, OAK, { mat: 'gloss', n: 24, olw: 0.3, noCap: 1 })
        + cyl3(C, [0, 12.8, 0], [0, 40, 0], 5.4, OAK, { r2: 4.6, mat: 'gloss', n: 22, olw: 0.3, noCap: 1 }) + cyl3(C, [0, 40, 0], [0, 42, 0], 6, OAK, { mat: 'gloss', n: 22, olw: 0.3, noCap: 1 })
        + cyl3(C, [0, 42, 0], [0, 54, 0], 4.6, OAK, { r2: 13, mat: 'gloss', n: 26, olw: 0.3, noCap: 1 });
      const base = vsort(C, feet.concat([{ q: [0, 22, 0], s: col }]));
      const apron = cyl3(C, [0, 54, 0], [0, 59.4, 0], 50, OAK, { mat: 'gloss', n: 48, olw: 0.3, noCap: 1 }), ring = cyl3(C, [0, 59.4, 0], [0, 60, 0], 60.6, BR, { mat: 'chrome', n: 48, olw: 0.25, noCap: 1 });
      const top = cyl3(C, [0, 60, 0], [0, TY, 0], 60, MB, { mat: 'gloss', n: 52, olw: 0.35, olc: '#a8a296', capCol: shade(MB, lt) });
      const tid = C.u('ot');
      const topP = PLN(C, [-60, TY + 0.02, -60], [1, 0, 0], [0, 0, 1], `<clipPath id="${tid}"><circle cx="60" cy="60" r="59.7"/></clipPath><g clip-path="url(#${tid})">${veins(R, 120, 120)}<rect width="120" height="120" fill="url(#m10s)" opacity="0.35"/>${glintT(C, 120, 120, 20, 12)}</g><circle cx="60" cy="60" r="59.2" fill="none" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.6"/>`);
      // place settings
      const setting = (a, k) => { const u = [Math.cos(a), 0, Math.sin(a)], t = [-Math.sin(a), 0, Math.cos(a)], r = 44, P = (dr, dt, y) => [u[0] * (r + dr) + t[0] * dt, TY + (y || 0), u[2] * (r + dr) + t[2] * dt];
        const c = P(0, 0), ch = cyl3(C, c, add(c, [0, 0.4, 0]), 7.6, BR, { mat: 'chrome', n: 30, olw: 0.25 }), pl = cyl3(C, add(c, [0, 0.4, 0]), add(c, [0, 1.2, 0]), 5, '#fbfaf6', { r2: 6.4, mat: 'gloss', n: 28, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.74)}" fill="none" stroke="#e2ddd2" stroke-width="0.35"/><circle r="${f1(cr * 0.95)}" fill="none" stroke="${BR}" stroke-width="0.3"/>` });
        const nap = box3(C, { c: add(c, [0, 1.2, 0]), ax: yawA(-a), w: 7, h: 1, d: 3.6, r: 0.9, col: '#e6e0d2', olw: 0.25, dec: { t: `<path d="M0 1.8H7" stroke="#b8b0a0" stroke-width="0.25"/>` } });
        const fork = H2(C, P(-5, 9.6, 0.2), P(5, 9.6, 0.2), 0.55, '#c8ccd0') + H2(C, P(3.6, 9.6, 0.25), P(5.6, 9.6, 0.25), 1.1, '#c8ccd0'), knife = H2(C, P(-5, -9.6, 0.2), P(5.4, -9.6, 0.2), 0.65, '#d0d6da');
        return [{ q: c, s: ch + pl + nap }, { q: P(0, 9.6), s: fork }, { q: P(0, -9.6), s: knife }, { q: P(-9, -7, 3), s: wglass(C, ...P(-9, -7), '#e8d890') }]; };
      const sets = [0, 1, 2, 3].flatMap(k => setting(PI / 4 + k * PI / 2, k));
      const bowl = cyl3(C, [0, TY, 0], [0, TY + 1, 0], 4, '#e8e0d0', { mat: 'gloss', n: 22, olw: 0.25 }) + cyl3(C, [0, TY + 1, 0], [0, TY + 5, 0], 5, '#ece4d4', { r2: 9, mat: 'gloss', n: 30, olw: 0.3, capCol: '#cfc6b4' })
        + vsort(C, [[-3.4, 0], [3.4, -1], [0, -3.6], [0.6, 3.6], [-3, 3.4], [3.2, 3], [0, 0, 1]].map(([dx, dz, up]) => { const q = [dx, TY + 6.2 + (up ? 1.8 : 0), dz]; return { q, s: sph(C, q, 2.3, '#f08a24') + `<circle cx="${f1(C.P(q)[0])}" cy="${f1(C.P([q[0], q[1] + 2.1, q[2]])[1])}" r="${f1(0.25 * C.k)}" fill="#5a7a2a"/>` }; }))
        + H2(C, [1, TY + 9.6, 0.4], [4, TY + 10.6, -1.4], 1.3, '#3f7a34') + H2(C, [1, TY + 9.6, 0.4], [-2.4, TY + 10.4, 1.6], 1.2, '#4a8a3a');
      const items = vsort(C, sets.concat([{ q: [0, TY + 4, 0], s: bowl }, { q: [-17, TY + 8, -6], s: bstick(C, -17, TY, -6, 7, BR, 0) }, { q: [17, TY + 8, 6], s: bstick(C, 17, TY, 6, 7, BR, -0.7) }]));
      let s = shadow(C, 0, 0, 62, 62, 0.7) + base + apron + ring + top + topP + items;
      C.p(0, TY + 22, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-103 WALNUT TRESTLE & CALACATTA MARBLE 6-SEAT DINING TABLE (T4): 200 x 112 footprint kept (top 184 x 96, y 60..65). Two walnut trestles (wide foot,
  // thick upright, cleat) joined by a stretcher with through-tenons + wedges, walnut apron, book-matched Calacatta slab. Sage linen runner, a long walnut dough
  // bowl of lemons, olive branches swaying in a stoneware jug, three brass candlesticks (tapers flicker), a bottle of red with two glasses; light sweeps the marble.
  N.trest28 = S => { const TY = 65, WN = '#6b4226', MB = '#f2efea', BR = '#c9a256';
    const D = { w: 200, d: 112, topH: TY, topW: 128.8, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('trest28');
      const gv = (w, h, k) => grainV(rng('t3g' + k), w, h, Math.max(3, Math.round(w / 2.5)), '#3a2414', '#9a6a44'), gh = (w, h, k) => grainH(rng('t3h' + k), w, h, Math.max(3, Math.round(h / 2)), '#3a2414');
      const trestle = sg => { const x = sg * 66, ov = vis(C, [sg, 0, 0]);
        const foot = box3(C, { c: [x, 0, 0], w: 12, h: 6, d: 76, r: 2, col: WN, olw: 0.3, dec: { f: gh(12, 6, 'f' + sg), b: gh(12, 6, 'b' + sg), l: gh(76, 6, 'l' + sg), r: gh(76, 6, 'r' + sg), t: gh(12, 76, 't' + sg) } });
        const up = box3(C, { c: [x, 6, 0], w: 7, h: 44, d: 22, r: 1, col: WN, olw: 0.3, dec: { f: gv(7, 44, 'uf' + sg), b: gv(7, 44, 'ub' + sg), l: gv(22, 44, 'ul' + sg), r: gv(22, 44, 'ur' + sg) } });
        const cl = box3(C, { c: [x, 50, 0], w: 12, h: 4, d: 76, r: 1.6, col: WN, olw: 0.3, dec: { l: gh(76, 4, 'cl' + sg), r: gh(76, 4, 'cr' + sg), f: gh(12, 4, 'cf' + sg), b: gh(12, 4, 'cb' + sg) } });
        const ten = box3(C, { c: [x + sg * 5.5, 17, 0], w: 4, h: 8, d: 5, r: 0.4, col: shade(WN, 1.12), olw: 0.25, dec: { l: `<rect width="5" height="8" fill="#000000" opacity="0.1"/>`, r: `<rect width="5" height="8" fill="#000000" opacity="0.1"/>` } }) + box3(C, { c: [x + sg * 6.2, 15.4, 0], w: 1.4, h: 10.8, d: 2.2, r: 0.2, col: '#3a2414', olw: 0.2 });
        return ov ? foot + up + cl + ten : ten + foot + up + cl; };
      const str = box3(C, { c: [0, 16, 0], w: 125, h: 9, d: 5, r: 0.6, col: WN, olw: 0.3, dec: { f: gh(125, 9, 'sf'), b: gh(125, 9, 'sb') } });
      const base = C.v[0] > 0 ? trestle(-1) + str + trestle(1) : trestle(1) + str + trestle(-1);
      const apron = box3(C, { c: [0, 54, 0], w: 172, h: 6, d: 84, r: 1, col: WN, olw: 0.3, skip: { t: 1 }, dec: { f: gh(172, 6, 'af'), b: gh(172, 6, 'ab'), l: gh(84, 6, 'al'), r: gh(84, 6, 'ar') } });
      const vd = (k, w, h) => veins(rng('t3v' + k), w, h) + `<rect width="${w}" height="${h}" fill="url(#m10s)" opacity="0.4"/>`;
      const slab = box3(C, { c: [0, 60, 0], w: 184, h: 5, d: 96, r: 1.2, col: MB, gl: 0.4, olw: 0.35, olc: '#a8a296', dec: { f: vd('f', 184, 5), b: vd('b', 184, 5), l: vd('l', 96, 5), r: vd('r', 96, 5), t: veins(R, 184, 96) + `<rect width="184" height="96" fill="url(#m10s)" opacity="0.35"/>` + glintT(C, 184, 96, 22, 14) } });
      const runD = `<rect width="132" height="26" fill="url(#m10s)" opacity="0.3"/>` + [2, 3.2, 22.8, 24].map(y => `<path d="M6 ${y}H126" stroke="#8a9070" stroke-width="0.4"/>`).join('') + rep(30, i => `<path d="M${f1(1 + i * 0.85)} 0.6V25.4M${f1(131 - i * 0.85)} 0.6V25.4" stroke="#ffffff" stroke-opacity="0.12" stroke-width="0.25"/>`).join('').slice(0, 0)
        + [0, 132].map(x => rep(26, i => `<path d="M${x} ${f1(0.5 + i)}h${x ? -2.4 : 2.4}" stroke="#a8ac90" stroke-width="0.3"/>`).join('')).join('');
      const runner = box3(C, { c: [0, TY, 0], w: 132, h: 0.35, d: 26, r: 0, col: '#c4c8ae', olw: 0.2, edge: 0, dec: { t: runD } }), RY = TY + 0.35;
      // dough bowl of lemons
      const db = box3(C, { c: [-2, RY, 0], w: 40, h: 4.4, d: 13, r: 6, col: '#5a3420', gl: 0.35, olw: 0.3, dec: { t: `<rect x="1.4" y="1.4" width="37.2" height="10.2" rx="5" fill="#2a1a10"/>`, f: gh(40, 4.4, 'df'), b: gh(40, 4.4, 'db') } })
        + vsort(C, [[-13, 0], [-7.6, -2], [-2.4, 1.6], [3, -1.4], [8.4, 1], [13, -0.6], [-4.8, -0.4, 1], [5.4, 0.2, 1]].map(([dx, dz, up]) => { const q = [-2 + dx, RY + 5.4 + (up ? 1.8 : 0), dz]; return { q, s: sph(C, q, 2.5, '#f2d23a') + sph(C, add(q, [2.3, 0, 0]), 0.6, '#d8b82a') }; }))
        + H2(C, [-6, RY + 8, 0], [-2, RY + 9, -2.4], 1.4, '#3f7a34') + H2(C, [6, RY + 7.8, 0.4], [9.4, RY + 8.6, 2.2], 1.3, '#4a8a3a');
      // olive branches in a stoneware jug
      const JX = 34, JZ = -5, leafE = (q, a, c) => { const p = C.P(q); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(1.5 * C.k)}" ry="${f1(0.42 * C.k)}" fill="${c}" transform="rotate(${f1(a)} ${f1(p[0])} ${f1(p[1])})"/>`; };
      const jug = cyl3(C, [JX, RY, JZ], [JX, RY + 7, JZ], 3.4, '#ddd2bc', { r2: 3.9, mat: 'matte', n: 22, olw: 0.3, noCap: 1 }) + cyl3(C, [JX, RY + 7, JZ], [JX, RY + 10, JZ], 3.9, '#ddd2bc', { r2: 2.6, mat: 'matte', n: 22, olw: 0.3, capCol: '#3a3020' })
        + `<g transform="${tanF(C, JX, JZ, 3.6, C.thV, RY + 4)}">${specks(rng('t3j'), 12, 6, 6, ['#7a6a50'], 0.12, 0.25, 0.8).replace(/cx="/g, 'transform="translate(-3 -3)" cx="')}</g>`;
      const olive = sway(C, [JX, RY + 10, JZ], [[-6, 27, -1], [5, 25, 1.4], [0.6, 30, -0.6]].map(([dx, h, dz], j) => { const b = [JX, RY + 9.6, JZ], t = [JX + dx, RY + h, JZ + dz];
        return H2(C, b, t, 0.3, '#6a5a44') + rep(9, k => { const f = 0.2 + k * 0.09, q = [b[0] + (t[0] - b[0]) * f, b[1] + (t[1] - b[1]) * f, b[2] + (t[2] - b[2]) * f], sg = k % 2 ? 1 : -1; return leafE(add(q, [sg * 1.2, 0.3, 0]), sg * 30 + (j - 1) * 12, k % 3 ? '#7d8c62' : '#b4bca0'); }).join(''); }).join(''), 1.6, 7);
      // bottle of red + two glasses
      const bot = cyl3(C, [52, TY, 14], [52, TY + 10, 14], 2.3, '#1e2e1c', { mat: 'gloss', n: 20, olw: 0.3, noCap: 1 }) + cyl3(C, [52, TY + 10, 14], [52, TY + 12.6, 14], 2.3, '#1e2e1c', { r2: 0.85, mat: 'gloss', n: 18, olw: 0.3, noCap: 1 }) + cyl3(C, [52, TY + 12.6, 14], [52, TY + 15.4, 14], 0.85, '#1e2e1c', { mat: 'gloss', n: 12, olw: 0.25, noCap: 1 })
        + cyl3(C, [52, TY + 15.2, 14], [52, TY + 17.2, 14], 0.95, '#6a1420', { mat: 'gloss', n: 12, olw: 0.25 }) + `<g transform="${tanF(C, 52, 14, 2.32, C.thV, TY + 5.6)}"><rect x="-1.9" y="-2.4" width="3.8" height="4.4" fill="#efe6d2"/><text y="-0.6" text-anchor="middle" font-family="Georgia,serif" font-size="0.8" fill="#6a1420">Rosso</text><path d="M-1.2 0.6H1.2M-0.9 1.2H0.9" stroke="#8a7a60" stroke-width="0.2"/></g>`;
      const sticks = [[-52, 8, 7, 0], [-45, 11, 9, -0.6], [-38, 8, 6, -1.1]];
      const items = vsort(C, [{ q: [-2, RY + 4, 0], s: db }, { q: [JX, RY + 8, JZ], s: jug + olive }, { q: [52, TY + 7, 14], s: bot }, { q: [58, TY + 3, 4], s: wglass(C, 58, TY, 4, '#6a1424') }, { q: [56, TY + 3, 22], s: wglass(C, 56, TY, 22, '#6a1424') }]
        .concat(sticks.map(([x, z, h, b]) => ({ q: [x, RY + 6, z], s: bstick(C, x, RY, z, h, BR, b) }))));
      let s = shadow(C, 0, 0, 96, 50, 0.7) + base + apron + slab + runner + items;
      C.p(0, TY + 30, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-104 ROYAL EBONY & GOLD-VEINED NERO MARBLE 8-SEAT BANQUET TABLE (T5): 252 x 112 footprint kept (top 236 x 96, y 60..65). Two gloss-ebony pedestals
  // (gold bun feet, plinth with a gold edge, turned baluster with a fluted shaft + gold rings, block with gold rosettes) joined by a low stretcher with a gold
  // urn finial; ebony apron with gold beading + rosettes, a gold band under a Nero Marquina slab with smoky depth and gold veins. Burgundy velvet runner with
  // gold borders, two five-light gold candelabra (flicker) casting breathing warm pools, red roses in a gold urn, champagne in a silver bucket + two coupes.
  N.ebon28 = S => { const TY = 65, EB = '#221c1a', NM = '#1c1a1e', CG = '#d6b878';
    const D = { w: 252, d: 112, topH: TY, topW: 165.2, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('ebon28');
      const ros = (cx, cy, r) => `<g transform="translate(${f1(cx)} ${f1(cy)})"><circle r="${f1(r)}" fill="${CG}"/>` + rep(8, i => `<ellipse cx="${f1(Math.cos(i * PI / 4) * r * 0.62)}" cy="${f1(Math.sin(i * PI / 4) * r * 0.62)}" rx="${f1(r * 0.34)}" ry="${f1(r * 0.2)}" transform="rotate(${i * 45} ${f1(Math.cos(i * PI / 4) * r * 0.62)} ${f1(Math.sin(i * PI / 4) * r * 0.62)})" fill="#f4dc98"/>`).join('') + `<circle r="${f1(r * 0.3)}" fill="#a8823a"/></g>`;
      const egl = (L, h) => `<rect width="${L}" height="${h}" fill="url(#m10s)" opacity="0.55"/>`;
      const ped = sg => { const x = sg * 80, o = [];
        const feet = [[-13, -20], [13, -20], [-13, 20], [13, 20]].map(([dx, dz]) => ({ q: [x + dx, 1.5, dz], s: cyl3(C, [x + dx, 0, dz], [x + dx, 3, dz], 2.4, CG, { r2: 2.8, mat: 'chrome', n: 14, olw: 0.2 }) }));
        const pl = box3(C, { c: [x, 3, 0], w: 34, h: 6, d: 50, r: 3, col: EB, gl: 0.6, olw: 0.3, dec: { f: egl(28, 6) + `<path d="M0 0.5H28" stroke="${CG}" stroke-width="0.6"/>`, b: egl(28, 6) + `<path d="M0 0.5H28" stroke="${CG}" stroke-width="0.6"/>`, l: egl(44, 6) + `<path d="M0 0.5H44" stroke="${CG}" stroke-width="0.6"/>`, r: egl(44, 6) + `<path d="M0 0.5H44" stroke="${CG}" stroke-width="0.6"/>` } });
        const fl = rep(7, k => { const th = C.thV + (k - 3) * 0.42; return H2(C, [x + Math.sin(th) * 5.95, 27.6, Math.cos(th) * 5.95], [x + Math.sin(th) * 6.35, 45, Math.cos(th) * 6.35], 0.28, CG, 0.85); }).join('');
        const colm = cyl3(C, [x, 9, 0], [x, 11, 0], 10, CG, { r2: 9, mat: 'chrome', n: 26, olw: 0.25, noCap: 1 }) + cyl3(C, [x, 11, 0], [x, 18, 0], 8, EB, { r2: 11, mat: 'gloss', n: 26, olw: 0.3, noCap: 1 }) + cyl3(C, [x, 18, 0], [x, 25, 0], 11, EB, { r2: 6.4, mat: 'gloss', n: 26, olw: 0.3, noCap: 1 })
          + cyl3(C, [x, 25, 0], [x, 26.6, 0], 6.6, CG, { mat: 'chrome', n: 22, olw: 0.25, noCap: 1 }) + cyl3(C, [x, 26.6, 0], [x, 46, 0], 5.8, EB, { r2: 6.4, mat: 'gloss', n: 24, olw: 0.3, noCap: 1 }) + fl + cyl3(C, [x, 46, 0], [x, 48.4, 0], 6.4, CG, { r2: 8.6, mat: 'chrome', n: 24, olw: 0.25, noCap: 1 });
        const blk = box3(C, { c: [x, 48.4, 0], w: 20, h: 5.6, d: 40, r: 1, col: EB, gl: 0.6, olw: 0.3, skip: { t: 1 }, dec: { f: egl(18, 5.6) + ros(9, 2.8, 2), b: egl(18, 5.6) + ros(9, 2.8, 2), l: egl(38, 5.6) + ros(10, 2.8, 2) + ros(28, 2.8, 2), r: egl(38, 5.6) + ros(10, 2.8, 2) + ros(28, 2.8, 2) } });
        return vsort(C, feet) + pl + colm + blk; };
      const str = box3(C, { c: [0, 9, 0], w: 126, h: 5, d: 8, r: 1, col: EB, gl: 0.6, olw: 0.3, dec: { f: egl(124, 5) + `<path d="M0 0.5H124M0 4.5H124" stroke="${CG}" stroke-width="0.5"/>`, b: egl(124, 5) + `<path d="M0 0.5H124M0 4.5H124" stroke="${CG}" stroke-width="0.5"/>` } })
        + cyl3(C, [0, 14, 0], [0, 15, 0], 3.4, CG, { mat: 'chrome', n: 18, olw: 0.2 }) + cyl3(C, [0, 15, 0], [0, 19, 0], 2.2, CG, { r2: 4.2, mat: 'chrome', n: 20, olw: 0.25 }) + sph(C, [0, 20.4, 0], 2.6, CG) + sph(C, [0, 23.6, 0], 1, CG);
      const base = C.v[0] > 0 ? ped(-1) + str + ped(1) : ped(1) + str + ped(-1);
      const apD = L => egl(L, 6) + `<path d="M0 5.3H${L}" stroke="${CG}" stroke-width="0.9" stroke-dasharray="0.7 0.5"/><path d="M0 0.5H${L}" stroke="${CG}" stroke-width="0.4"/>` + rep(Math.floor(L / 22), i => ros(11 + i * 22, 2.8, 1.6)).join('');
      const apron = box3(C, { c: [0, 54, 0], w: 220, h: 6, d: 84, r: 1.2, col: EB, gl: 0.6, olw: 0.3, skip: { t: 1 }, dec: { f: apD(218), b: apD(218), l: apD(82), r: apD(82) } });
      const band = box3(C, { c: [0, 59.4, 0], w: 237.4, h: 0.6, d: 97.4, r: 1.4, col: CG, gl: 0.7, olw: 0.2, edge: 0, skip: { t: 1 } });
      const clipD = (w, h, s) => { const id = C.u('cd'); return `<clipPath id="${id}"><rect width="${w}" height="${h}"/></clipPath><g clip-path="url(#${id})">${s}</g>`; };
      const sd = (L, k) => clipD(L, 5, obsV(rng('e4' + k), L, 5, 2)) + `<rect width="${L}" height="5" fill="url(#m10s)" opacity="0.55"/><path d="M0 4.6H${L}" stroke="${CG}" stroke-width="0.6"/>`;
      const pool = cx => `<ellipse cx="${cx}" cy="48" rx="30" ry="20" fill="url(#k28amb)" opacity="0.55">${an('opacity', '0.4;0.6;0.45;0.58;0.4', 3.2)}</ellipse>`;
      const slab = box3(C, { c: [0, 60, 0], w: 236, h: 5, d: 96, r: 1.2, col: NM, gl: 0.65, olw: 0.4, olc: '#000000', dec: { f: sd(236, 'f') + glintT(C, 236, 5, 12, 8), b: sd(236, 'b'), l: sd(96, 'l'), r: sd(96, 'r'), t: clipD(236, 96, obsV(R, 236, 96, 18) + pool(66) + pool(170)) + `<rect width="236" height="96" fill="url(#m10s)" opacity="0.4"/>` } });
      const runD = `<rect width="190" height="30" fill="#000000" opacity="0.12"/><rect y="9" width="190" height="12" fill="#ffffff" opacity="0.06"/>` + [1.6, 2.6, 27.4, 28.4].map(y => `<path d="M0 ${y}H190" stroke="${CG}" stroke-width="0.45"/>`).join('')
        + rep(16, i => `<path d="M${f1(8 + i * 11.6)} 15l3 -4.4l3 4.4l-3 4.4Z" fill="none" stroke="${CG}" stroke-opacity="0.45" stroke-width="0.3"/>`).join('') + [0, 190].map(x => rep(15, i => `<path d="M${x} ${f1(1 + i * 2)}h${x ? -1.8 : 1.8}" stroke="${CG}" stroke-width="0.7"/>`).join('')).join('');
      const runner = box3(C, { c: [0, TY, 0], w: 190, h: 0.4, d: 30, r: 0, col: '#6a1424', olw: 0.2, olc: '#3a0a12', edge: 0, dec: { t: runD } }), RY = TY + 0.4;
      // candelabra
      const cand = (x, b0) => { const base = cyl3(C, [x, RY, 0], [x, RY + 1.2, 0], 4.2, CG, { r2: 3, mat: 'chrome', n: 22, olw: 0.25 }) + cyl3(C, [x, RY + 1.2, 0], [x, RY + 15.6, 0], 0.85, CG, { r2: 0.6, mat: 'chrome', n: 12, olw: 0.2, noCap: 1 }) + sph(C, [x, RY + 7, 0], 1.5, CG) + sph(C, [x, RY + 12.4, 0], 1.1, CG);
        const arms = [[5.4, 0], [-5.4, 0], [0, 5.4], [0, -5.4]].map(([dx, dz], i) => { const tip = [x + dx, RY + 13.4, dz]; return { q: tip, s: H2(C, [x, RY + 11.6, 0], [x + dx * 0.72, RY + 10.8, dz * 0.72], 0.6, CG) + H2(C, [x + dx * 0.72, RY + 10.8, dz * 0.72], tip, 0.6, CG) + cyl3(C, tip, add(tip, [0, 1, 0]), 1.05, CG, { mat: 'chrome', n: 14, olw: 0.2 }) + taper(C, tip[0], tip[1] + 1, tip[2], 8, '#f6eedc', b0 - i * 0.37) }; });
        return vsort(C, arms.concat([{ q: [x, RY + 8, 0], s: base + cyl3(C, [x, RY + 15.6, 0], [x, RY + 16.6, 0], 1.15, CG, { mat: 'chrome', n: 14, olw: 0.2 }) + taper(C, x, RY + 16.6, 0, 9.6, '#f6eedc', b0 - 1.6) }])); };
      // roses in a gold urn
      const urn = cyl3(C, [0, RY, 0], [0, RY + 0.8, 0], 3.6, CG, { mat: 'chrome', n: 20, olw: 0.25 }) + cyl3(C, [0, RY + 0.8, 0], [0, RY + 2.6, 0], 1.6, CG, { mat: 'chrome', n: 16, olw: 0.2, noCap: 1 }) + cyl3(C, [0, RY + 2.6, 0], [0, RY + 8, 0], 2.8, CG, { r2: 6, mat: 'chrome', n: 26, olw: 0.3, capCol: '#2a1414' });
      const RS = rep(15, i => { const a = i * 2.4, rr = i ? 1.6 + (i % 3) * 1.6 : 0; return [Math.cos(a) * rr, RY + 10.4 - rr * 0.32, Math.sin(a) * rr]; });
      const roses = sway(C, [0, RY + 8, 0], vsort(C, RS.map((q, i) => ({ q, s: sph(C, q, 1.85, i % 4 ? '#a8142a' : '#8a0f22') + `<path d="M${P2(C.P([q[0] - 0.7, q[1] + 0.9, q[2]]))}q${f1(0.7 * C.k)} ${f1(-0.6 * C.k)} ${f1(1.3 * C.k)} 0" stroke="#d83a50" stroke-width="${f1(0.25 * C.k)}" fill="none"/>` }))
        .concat([[-6.2, 0.6], [6, -1], [0.6, 6.2], [-1, -6]].map(([dx, dz]) => ({ q: [dx, RY + 8.4, dz], s: sph(C, [dx, RY + 8.4, dz], 1.5, '#2e5a2a') })))), 0.8, 8);
      // champagne in a silver bucket + two coupes
      const KX = 100, KZ = -16;
      const buck = cyl3(C, [KX, TY, KZ], [KX, TY + 7.4, KZ], 3.6, '#d4d8dc', { r2: 4.6, mat: 'chrome', n: 24, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#cfe2ea"/>` + rep(7, i => `<rect x="${f1(Math.cos(i * 1.9) * cr * 0.5 - 0.9)}" y="${f1(Math.sin(i * 2.3) * cr * 0.5 - 0.9)}" width="1.8" height="1.8" rx="0.3" fill="#f4fafc" stroke="#a8c4d0" stroke-width="0.12"/>`).join('') })
        + [-1, 1].map(sg => sph(C, [KX + sg * 4.4, TY + 6, KZ], 0.7, '#c8ccd0')).join('') + cyl3(C, [KX, TY + 5, KZ], [KX + 2.6, TY + 13.4, KZ - 2.2], 1.7, '#1a2018', { r2: 1.5, mat: 'gloss', n: 16, olw: 0.25, noCap: 1 }) + cyl3(C, [KX + 2.6, TY + 13.4, KZ - 2.2], [KX + 3.6, TY + 16.6, KZ - 3], 0.75, CG, { r2: 0.9, mat: 'chrome', n: 12, olw: 0.2 });
      const coupe = (x, z, b) => cyl3(C, [x, TY, z], [x, TY + 0.3, z], 1.7, '#eef6f6', { mat: 'chrome', n: 16, op: 0.5, olw: 0.2, olc: '#8aa4aa' }) + cyl3(C, [x, TY + 0.3, z], [x, TY + 3.6, z], 0.24, '#eef6f6', { mat: 'chrome', n: 8, op: 0.6, olw: 0.15, olc: '#8aa4aa' })
        + cyl3(C, [x, TY + 3.6, z], [x, TY + 5.4, z], 0.9, '#f4ecc8', { r2: 3, mat: 'chrome', n: 20, op: 0.55, olw: 0.25, olc: '#8aa4aa', cap: cr => `<circle r="${f1(cr * 0.96)}" fill="#f6eecc"/>` }) + rep(4, i => bub1(C, [x + (i - 1.5) * 0.6, TY + 4, z], [x + (i - 1.5) * 0.7, TY + 5.4, z], 0.22, 2.4, (i * 0.23 + b) % 0.7)).join('');
      const items = vsort(C, [{ q: [-52, RY + 10, 0], s: cand(-52, 0) }, { q: [52, RY + 10, 0], s: cand(52, -0.8) }, { q: [0, RY + 6, 0], s: urn + roses }, { q: [KX, TY + 6, KZ], s: buck }, { q: [106, TY + 3, -4], s: coupe(106, -4, 0) }, { q: [100, TY + 3, 2], s: coupe(100, 2, 0.3) }]);
      let s = shadow(C, 0, 0, 124, 52, 0.65) + base + apron + band + slab + runner + items;
      C.p(0, TY + 30, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // ---------- batch 7: dining chairs KIT-016 / 036 / 056 (seats: solid-sorted build, seats + footprints kept; fx only for decals / swaying bits) ----------
  // parts sit clear of each other (touching only), details glued with par (+ fn for faces that turn away), S.tex = screen-space texture over the top faces
  const CHK = () => { const K = X.K, H16 = RD.H16; return { box: K.box, cyl: K.cyl, ball: K.ball, solid: K.solid, arcW: K.arcW, pillowY: K.pillowY, pillowZ: K.pillowZ, rod: H16.rod, tiltAll: H16.tiltAll }; };
  const glue = o => (p, L) => L.map(k => { k.par = p; o.push(k); return k; });
  // swaying strand (PLN-free: projected polyline) from a, length L straight down, ending in a pompom / tassel
  const dangle = (C, a, L, w, col, end, T, b, amp) => { const p = C.P(a), q = C.P([a[0], a[1] - L, a[2]]); return `<g>${at('rotate', `${-amp} ${P2(p)};${amp} ${P2(p)};${-amp} ${P2(p)}`, T, b, SPL(2))}<path d="M${P2(p)}Q${f1(p[0] + 0.6 * C.k)} ${f1((p[1] + q[1]) / 2)} ${P2(q)}" stroke="${col}" stroke-width="${f1(w * C.k)}" stroke-linecap="round" fill="none"/>${end ? end(q) : ''}</g>`; };
  const fly = (C, q, r) => { const p = C.P(q), k = C.k, R0 = r * k; return `<g transform="translate(${P2(p)})"><g>${at('rotate', '0;360', 3.4)}<g transform="translate(${f1(R0)} 0)"><g>${at('translate', `0 0;0 ${f1(-1.2 * k)};0 ${f1(0.6 * k)};0 0`, 1.1)}<ellipse rx="${f1(0.55 * k)}" ry="${f1(0.4 * k)}" fill="#1a1a1c"/><ellipse cx="${f1(-0.3 * k)}" cy="${f1(-0.45 * k)}" rx="${f1(0.5 * k)}" ry="${f1(0.25 * k)}" fill="#dfe8ee" opacity="0.7">${an('ry', `${f1(0.25 * k)};${f1(0.05 * k)};${f1(0.25 * k)}`, 0.08)}</ellipse><ellipse cx="${f1(0.3 * k)}" cy="${f1(-0.45 * k)}" rx="${f1(0.5 * k)}" ry="${f1(0.25 * k)}" fill="#dfe8ee" opacity="0.7">${an('ry', `${f1(0.25 * k)};${f1(0.05 * k)};${f1(0.25 * k)}`, 0.08)}</ellipse></g></g></g></g>`; };

  // KIT-016 MISMATCHED PLASTIC STACKABLE STOOL (T1): 40 x 40, seat 38 kept. Faded turquoise molded stool (four tapered legs, stacking skirt, rounded seat)
  // with a hand-knit pink + orange seat cozy that doesn't match, its two pompom ties swaying. A cracked leg wrapped in grey duct tape, three black rubber feet
  // and one red bottle cap standing in for the lost one, a half-peeled $2.99 sticker and scuffs on the skirt. A fly circles lazily above it.
  N.plst28 = S => { const PT = '#5fb8b4', PD = shade('#5fb8b4', 0.86);
    const D = { w: 40, d: 40, arch: 'stool', act: 'sit', seats: [{ x: 0, z: 0, h: 38 }], build: () => { const { box, cyl, solid } = CHK(), o = [], on = glue(o), LG = {};
        [[-10.5, -10.5], [10.5, -10.5], [-10.5, 10.5], [10.5, 10.5]].forEach(([x, z], i) => { o.push(LG[i] = solid({ ax: 'y', sh: 'rr', c: [x, z], a: 2.3, b: 2.3, r: 1.3, rings: [[0, 0, 0.72], [30, 0, 1]], col: PT, mat: 'pl' }));
          on(LG[i], [i === 2 ? cyl(x, -0.2, z, 2.1, 1.9, '#d23a2e', { n: 12, mat: 'pl', rg: [[0, 0, 1], [1.4, 0, 1], [1.9, 0.5, 0.9]] }) : cyl(x, -0.2, z, 1.9, 1.5, '#2a2a2c', { n: 12 })]); });
        on(LG[3], [box(10.5, 12, 10.5, 4.25, 3.4, 4.25, '#a4a9ae', { r: 1.5, mat: 'fab', noOut: 1 }), box(10.5, 15.2, 10.5, 4.3, 0.9, 4.3, '#b4b9be', { r: 1.5, noOut: 1, mat: 'fab' })]);
        const SK = box(0, 30, 0, 27, 4, 27, PD, { r: 7, mat: 'pl' }); o.push(SK);
        const ST = cyl(0, 34, 0, 15.5, 4, PT, { n: 28, mat: 'pl', rg: [[0, 0, 0.9], [2.6, 0, 1], [4, 1, 0.97]] }); o.push(ST);
        on(ST, [cyl(0, 38, 0, 13.6, 1.4, '#ec8fb0', { n: 26, mat: 'fab', soft: 1, tex: 'url(#k28knit) none', texTop: 1, rg: [[0, 0, 1], [0.9, 0, 1], [1.4, 0.5, 0.98]] })]);
        return o; } };
    D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('plst28');
      const knit = `<pattern id="k28knit" width="${f1(1.6 * k)}" height="${f1(1.3 * k)}" patternUnits="userSpaceOnUse"><path d="M0 0L${f1(0.8 * k)} ${f1(1.3 * k)}L${f1(1.6 * k)} 0" fill="none" stroke="#ffffff" stroke-opacity="0.35" stroke-width="${f1(0.28 * k)}"/><path d="M0 ${f1(0.4 * k)}L${f1(0.8 * k)} ${f1(1.7 * k)}L${f1(1.6 * k)} ${f1(0.4 * k)}" fill="none" stroke="#a83a5a" stroke-opacity="0.3" stroke-width="${f1(0.2 * k)}"/></pattern>`
        + `<pattern id="k28knitO" width="${f1(14 * k)}" height="${f1(3.2 * k)}" patternUnits="userSpaceOnUse"><rect y="${f1(1.6 * k)}" width="${f1(14 * k)}" height="${f1(1.6 * k)}" fill="#f2a23a" opacity="0.7"/></pattern>`;
      // skirt decals on whichever two skirt faces look at you (sticker + crack on the front, scuffs elsewhere)
      let dec = '';
      [[0, 0, 1], [1, 0, 0], [0, 0, -1], [-1, 0, 0]].forEach((n, i) => { if (!vis(C, n)) return; const U = [n[2], 0, -n[0]], O = [n[0] * 13.55 - U[0] * 9, 33.6, n[2] * 13.55 - U[2] * 9];
        dec += PLN(C, O, U, [0, -1, 0], i === 0 ? `<g transform="rotate(-4 5 1.6)"><rect x="2" y="0.6" width="6" height="2.6" rx="0.3" fill="#f6f2e2"/><rect x="2" y="0.6" width="6" height="0.7" fill="#e8503a"/><text x="5" y="2.8" text-anchor="middle" ${FONT} font-size="1.3" fill="#c8281e">$2.99</text><path d="M8 0.6l-1.6 1.2l1.6 0.6Z" fill="#d8d2c0"/></g><path d="M12 0.4l0.8 1l-0.5 0.8l0.9 1.2" stroke="#2a5a58" stroke-width="0.25" fill="none"/>`
          : scr(R, 6, 1, 0.6, 16, 2.8, '#2a5a58', 0.5)); });
      // cozy edge stripe (front half) + ties with pompoms
      const cz = PLN(C, [0, 39.42, 0], [1, 0, 0], [0, 0, 1], `<circle r="13.2" fill="none" stroke="#f2a23a" stroke-width="0.8" stroke-dasharray="1.2 0.8" opacity="0.8"/><circle r="9" fill="none" stroke="#f2a23a" stroke-width="0.5" opacity="0.6"/><circle r="5" fill="none" stroke="#f2a23a" stroke-width="0.5" stroke-dasharray="0.8 0.6" opacity="0.6"/><circle r="1.4" fill="#f2a23a" opacity="0.8"/>`);
      const pom = c => q => `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.3 * k)}" fill="${c}"/><circle cx="${f1(q[0] - 0.4 * k)}" cy="${f1(q[1] - 0.4 * k)}" r="${f1(0.5 * k)}" fill="#ffffff" opacity="0.35"/>`;
      const ties = dangle(C, [-11.2, 38.6, 9.6], 7, 0.35, '#ec8fb0', pom('#f2a23a'), 3.6, 0, 6) + dangle(C, [-9.6, 38.6, 11.2], 9, 0.35, '#ec8fb0', pom('#ec8fb0'), 4.1, -1.3, 7);
      const tF = vis(C, [-0.7, 0, 0.7]);
      const fl = fly(C, [0, 58, 0], 7); C.p(-9, 60, 0); C.p(9, 56, 0);
      return { defs: knit, front: dec + cz + (tF ? ties : ''), back: tF ? '' : ties, over: fl, bb: C.bb(2) }; };
    return D; };

  // KIT-036 SPINDLE-BACK PAINTED WOODEN WINDSOR CHAIR (T2): 50 x 50, seat {0, 3, 44} kept. Sage milk-paint comb-back Windsor: turned legs on an H-stretcher,
  // a saddle seat, six spindles + two posts into a crest rail with scrolled ears, the paint rubbed back to warm maple on the seat front, the ears and the
  // stretchers. A red gingham tie-on cushion; its ties sway at the back posts.
  N.wind28 = S => { const PA = '#93a98e', WD = '#c08c56', SH = 38, ST = 42.2, BZ = -13;
    const D = { w: 50, d: 50, arch: 'rchair', act: 'sit', seats: [{ x: 0, z: 3, h: 44 }], build: () => { const { box, cyl, solid, rod, pillowY, tiltAll } = CHK(), o = [], on = glue(o);
        const LP = [[0, 0, 0.75], [5, 0, 0.92], [12, 0, 1.2], [16, 0, 0.8], [27, 0, 1.06], [SH, 0, 0.86]];
        const LG = [[-15, -12], [15, -12], [-15, 15], [15, 15]].map(([x, z]) => { const L = cyl(x, 0, z, 2.2, SH, PA, { n: 12, rg: LP, mat: 'paint' }); o.push(L); on(L, [cyl(x, 0, z, 1.7, 1.2, WD, { n: 10, mat: 'wood' })]); return L; });
        const sS = [-1, 1].map(sg => { const R0 = rod([sg * 15, 14, -12 + 2.5], [sg * 15, 14, 15 - 2.5], 1.15, PA, { n: 8, mat: 'paint' }); o.push(R0); on(R0, [box(sg * 15, 14.9, 1.5, 1.6, 0.5, 6, WD, { r: 0.6, noOut: 1, mat: 'wood' })]); return R0; });
        const xS = rod([-13.85, 14, 1.5], [13.85, 14, 1.5], 1.1, PA, { n: 8, mat: 'paint' }); o.push(xS); on(xS, [box(0, 14.8, 1.5, 7, 0.5, 1.6, WD, { r: 0.6, noOut: 1, mat: 'wood' })]);
        const SEAT = solid({ ax: 'y', sh: 'el', c: [0, 1], a: 21, b: 19.5, n: 26, rings: [[SH, 0, 0.95], [SH + 2.8, 0, 1], [ST, 1, 0.98]], col: PA, mat: 'paint' }); o.push(SEAT);
        on(SEAT, [box(0, SH + 1.2, 20.1, 18, 2.4, 0.5, WD, { r: 0.4, noOut: 1, mat: 'wood' }), box(-6, SH + 2.6, 20.2, 4, 1, 0.4, shade(WD, 1.1), { r: 0.3, noOut: 1 })]).forEach(s => s.fn = [0, 0, 1]);
        const CU = pillowY(0, ST, 4, 33, 2.6, 30, '#d64a3c', { mat: 'fab', soft: 1, tex: 'url(#k28gng) none', texTop: 1 }); o.push(CU);
        const BK = [], xs = [-12, -7.2, -2.4, 2.4, 7.2, 12];
        xs.forEach((x, i) => BK.push(cyl(x, ST, BZ, i === 0 || i === 5 ? 1.6 : 1.05, 74 - ST, PA, { n: 8, mat: 'paint', rg: i === 0 || i === 5 ? [[0, 0, 1.1], [8, 0, 0.85], [74 - ST, 0, 1]] : [[0, 0, 0.9], [74 - ST, 0, 1.05]] })));
        const CR = box(0, 74, BZ, 30, 5, 3.6, PA, { r: 1.6, mat: 'paint' }); BK.push(CR);
        const ears = [-1, 1].map(sg => solid({ ax: 'z', sh: 'el', c: [sg * 16.2, 76.5], a: 2.2, b: 2.6, n: 12, rings: [[BZ - 1.8, 0], [BZ + 1.8, 0]], col: WD, mat: 'wood' }));
        const crW = box(0, 79, BZ, 22, 0.5, 2.6, WD, { r: 1, noOut: 1, mat: 'wood' });
        tiltAll(BK.concat(ears, [crW]), [1, 0, 0], -0.07, [0, ST, BZ]); BK.forEach(s => o.push(s)); on(CR, ears.concat([crW]));
        return o; } };
    D.fx = ctx => { const C = cam(ctx), k = C.k;
      const g = 2.2 * k, defs = `<pattern id="k28gng" width="${f1(g * 2)}" height="${f1(g * 2)}" patternUnits="userSpaceOnUse"><rect width="${f1(g * 2)}" height="${f1(g * 2)}" fill="#f6efe6"/><rect width="${f1(g)}" height="${f1(g * 2)}" fill="#d8453a" opacity="0.55"/><rect width="${f1(g * 2)}" height="${f1(g)}" fill="#d8453a" opacity="0.55"/><rect width="${f1(g)}" height="${f1(g)}" fill="#a82a22" opacity="0.6"/></pattern>`;
      const tie = (x, b) => dangle(C, [x, ST + 1.6, BZ + 1.8], 7.5, 0.45, '#c8382e', q => `<path d="M${f1(q[0] - 0.8 * k)} ${f1(q[1])}l${f1(0.8 * k)} ${f1(1.6 * k)}l${f1(0.8 * k)} ${f1(-1.6 * k)}" fill="#c8382e"/>`, 4.2, b, 6)
        + dangle(C, [x, ST + 1.6, BZ + 1.8], 5.6, 0.45, '#e8e0d4', null, 3.6, b - 0.9, 8);
      const ties = tie(-13.8, 0) + tie(13.8, -1.7), tF = C.v[2] < 0.35;
      return { defs, front: tF ? ties : '', back: tF ? '' : ties }; };
    return D; };

  // KIT-056 BENTWOOD THONET BISTRO CHAIR WITH WOVEN CANE SEAT (T3): 50 x 50, seat {0, 2, 44} kept. Classic No. 14: dark walnut-stained steam-bent beech,
  // four tapered legs with felt pads, a leg ring in four bent segments with brass screws, a round seat with a woven cane insert in a bent rim, back posts that
  // rise into a big loop with a smaller inner loop and a cross rail, leaning gently back. A mustard knit scarf is draped over the top loop, its fringe swaying.
  N.thon28 = S => { const WD = '#4a2a1a', SY = 40, ST = 42.6, BZ = -11, CG = '#c9a256';
    const D = { w: 50, d: 50, arch: 'rchair', act: 'sit', seats: [{ x: 0, z: 2, h: 44 }], build: () => { const { box, cyl, ball, solid, rod, arcW, tiltAll } = CHK(), o = [], on = glue(o);
        [[-12, -11], [12, -11], [-12, 13], [12, 13]].forEach(([x, z]) => { const L = cyl(x, 0, z, 1.95, SY, WD, { n: 12, rg: [[0, 0, 0.78], [SY, 0, 1.08]], mat: 'wood' }); o.push(L); on(L, [cyl(x, -0.3, z, 1.6, 0.8, '#2a2a28', { n: 10 })]); });
        [[-42, 42], [48, 132], [138, 222], [228, 312]].forEach(([a0, a1]) => { const A = arcW(0, 13.2, 1, 14.6, 14.6, 1.6, 2, a0 * PI / 180, a1 * PI / 180, WD, { n: 10, mat: 'wood' }); o.push(A);
          on(A, [a0, a1].map(a => { const t = a * PI / 180; return ball(Math.cos(t) * 14.2, 13.6, 1 + Math.sin(t) * 14.2, 0.6, CG, { k: 3, n: 8, shine: 1 }); })); });
        const SEAT = cyl(0, SY, 1, 20, ST - SY, WD, { n: 32, mat: 'wood', tex: 'url(#k28cane) none', texTop: 1, rg: [[0, 0, 0.97], [ST - SY - 0.6, 0, 1], [ST - SY, 0.4, 0.99]] }); o.push(SEAT);
        on(SEAT, [arcW(0, ST, 1, 19.8, 19.8, 3, 0.5, 0, 2 * PI, WD, { n: 32, mat: 'wood' }), arcW(0, ST, 1, 16.9, 16.9, 0.35, 0.55, 0, 2 * PI, '#2e1a10', { n: 32, noOut: 1 })]);
        const BK = [], post = sg => cyl(sg * 12, ST, BZ, 1.9, 74 - ST, WD, { n: 10, mat: 'wood', rg: [[0, 0, 1.05], [74 - ST, 0, 0.95]] });
        BK.push(post(-1), post(1));
        BK.push(solid({ ax: 'z', sh: 'arc', c: [0, 74], a: 12, b: 13, th: 2.4, a0: 0, a1: PI, n: 14, rings: [[BZ - 1.4, 0], [BZ + 1.4, 0]], col: WD, mat: 'wood' }));
        [-1, 1].forEach(sg => BK.push(cyl(sg * 7.4, ST, BZ, 1.1, 8, WD, { n: 8, mat: 'wood' })));
        BK.push(solid({ ax: 'z', sh: 'arc', c: [0, ST + 8], a: 7.4, b: 10.6, th: 2, a0: 0, a1: PI, n: 12, rings: [[BZ - 1.1, 0], [BZ + 1.1, 0]], col: WD, mat: 'wood' }));
        const RL = box(0, 62.8, BZ, 20.2, 2.4, 2.4, WD, { r: 1, mat: 'wood' }); BK.push(RL);
        tiltAll(BK, [1, 0, 0], -0.08, [0, ST, BZ]); BK.forEach(s => o.push(s));
        return o; } };
    D.fx = ctx => { const C = cam(ctx), k = C.k;
      const c = 1.7 * k, defs = `<pattern id="k28cane" width="${f1(c)}" height="${f1(c)}" patternUnits="userSpaceOnUse"><rect width="${f1(c)}" height="${f1(c)}" fill="#d8b278"/><path d="M0 ${f1(c * 0.5)}H${f1(c)}M${f1(c * 0.5)} 0V${f1(c)}" stroke="#b88a4a" stroke-width="${f1(c * 0.16)}"/><path d="M0 0L${f1(c)} ${f1(c)}M${f1(c)} 0L0 ${f1(c)}" stroke="#e8c890" stroke-width="${f1(c * 0.14)}"/><circle cx="${f1(c * 0.25)}" cy="${f1(c * 0.25)}" r="${f1(c * 0.12)}" fill="#3a2410"/><circle cx="${f1(c * 0.75)}" cy="${f1(c * 0.75)}" r="${f1(c * 0.12)}" fill="#3a2410"/><circle cx="${f1(c * 0.75)}" cy="${f1(c * 0.25)}" r="${f1(c * 0.12)}" fill="#3a2410"/><circle cx="${f1(c * 0.25)}" cy="${f1(c * 0.75)}" r="${f1(c * 0.12)}" fill="#3a2410"/></pattern>`;
      // scarf over the top loop at x 3..9: back flap (z BZ - 1.7) and front flap (z BZ + 1.7), drawn before / after the chair by which side faces you
      const tl = -0.08, ty = y => ST + (y - ST) * Math.cos(tl), tz = (y, z) => z + (y - ST) * Math.sin(tl);
      const flap = (zs, L, b) => { const y0 = 87.2, zz = BZ + zs * 1.8, O = [-3.2, ty(y0), tz(y0, zz)], V = [0, -Math.cos(tl), -Math.sin(tl)];
        const fr = rep(9, i => `<path d="M${f1(0.4 + i * 0.7)} ${L}v2.4" stroke="#c8902a" stroke-width="0.35" stroke-linecap="round">${at('rotate', `-6 ${f1(0.4 + i * 0.7)} ${L};6 ${f1(0.4 + i * 0.7)} ${L};-6 ${f1(0.4 + i * 0.7)} ${L}`, 2.8, b - i * 0.12, SPL(2))}</path>`).join('');
        return PLN(C, O, [1, 0, 0], V, `<g>${at('skewX', '-1.6;1.6;-1.6', 5, b, SPL(2))}<rect width="6.4" height="${L}" rx="0.6" fill="#d8a23a"/>` + rep(Math.floor(L / 1.4), i => `<path d="M0 ${f1(0.7 + i * 1.4)}H6.4" stroke="#b8821e" stroke-width="0.3" stroke-dasharray="0.5 0.3"/>`).join('') + `<rect width="6.4" height="${L}" rx="0.6" fill="url(#m10v)"/><rect y="${f1(L - 2.6)}" width="6.4" height="1" fill="#8a5a2a" opacity="0.5"/>${fr}</g>`); };
      const top = PLN(C, [-3.2, ty(88.3), tz(88.3, BZ - 1.8)], [1, 0, 0], [0, -Math.sin(tl), Math.cos(tl)], `<rect width="6.4" height="3.6" rx="0.8" fill="#e0ac46"/><rect width="6.4" height="3.6" rx="0.8" fill="url(#m10s)" opacity="0.4"/>`);
      const fF = flap(1, 16, 0), fB = flap(-1, 22, -1.4), fv = C.v[2] > 0;
      return fv ? { defs, back: fB, front: fF + top } : { defs, back: fF, front: fB + top }; };
    return D; };

  // ---------- batch 8: dining chairs KIT-076 / 096 / 105 (seats, solid-sorted; seats + footprints + arch kept) ----------
  // curved walls (sh 'arc' / cv:0 'poly') are drawn face by face: inFirst puts their inner faces first, so the near outer wall always paints over the far inner one
  const inFirst = (S, cx, cz) => { const cap = [], inn = [], out = []; S.faces.forEach(F => { if (F.cap) { cap.push(F); return; } const q = F.q, mx = q.reduce((s, p) => s + p[0], 0) / q.length, mz = q.reduce((s, p) => s + p[2], 0) / q.length, L = Math.hypot(mx - cx, mz - cz) || 1;
    ((F.n[0] * (mx - cx) + F.n[2] * (mz - cz)) / L < -0.3 ? inn : out).push(F); }); S.faces = inn.concat(out, cap); return S; };
  const sector = (A, B, th, a0, a1, n) => { const o = [], i = []; for (let k = 0; k <= n; k++) { const t = a0 + (a1 - a0) * k / n; o.push([A * Math.cos(t), B * Math.sin(t)]); i.push([(A - th) * Math.cos(t), (B - th) * Math.sin(t)]); } return o.concat(i.reverse()); };
  const legGlint = (C, L, T) => L.map(([x, z, y0, y1, r]) => ({ d: dot([x, 0, z], C.v), x, z, y0, y1, r })).sort((a, b) => b.d - a.d).slice(0, 2).map((l, i) => { const a = C.P([l.x - l.r * 0.35, l.y1 - 1, l.z + l.r * 0.5]), b = C.P([l.x - l.r * 0.25, l.y0 + 1, l.z + l.r * 0.5]), Ln = Math.hypot(b[0] - a[0], b[1] - a[1]);
    return `<path d="M${P2(a)}L${P2(b)}" stroke="#fff8e0" stroke-width="${f1(0.5 * C.k)}" stroke-linecap="round" stroke-dasharray="${f1(Ln * 0.22)} ${f1(Ln * 2)}" stroke-dashoffset="${f1(Ln * 0.22)}" opacity="0.85">${an('stroke-dashoffset', `${f1(Ln * 0.22)};${f1(Ln * 0.22)};${f1(-Ln)};${f1(-Ln)}`, T, -i * 0.6, KT('0;0.6;0.85;1'))}</path>`; }).join('');

  // KIT-076 UPHOLSTERED BOUCLÉ & BRUSHED BRASS DINING ARMCHAIR (T4): 56 x 54, seat {0, 4, 44} kept. A nubbly ivory bouclé tub: a plump round seat drum on a
  // brushed-brass plinth and four tapered brass legs, low curved arms capped by a brass band, a rounded back rising behind them. A caramel cashmere throw lies
  // over the right arm, its fringe swaying; a glint slides down the brass legs now and then.
  N.bcl28 = S => { const IV = '#ece4d6', BR = '#c9a256', CZ = 2, LG = [[-15, -12], [15, -12], [-15, 16], [15, 16]];
    const D = { w: 56, d: 54, arch: 'rchair', act: 'sit', seats: [{ x: 0, z: 4, h: 44 }], build: () => { const { cyl, solid } = CHK(), o = [], on = glue(o);
        LG.forEach(([x, z]) => { const L = cyl(x, 0, z, 1.7, 28, BR, { n: 12, mat: 'metal', rg: [[0, 0, 0.62], [28, 0, 1]] }); o.push(L); on(L, [cyl(x, -0.2, z, 1.25, 1.6, '#9a7a3a', { n: 10, mat: 'metal' })]); });
        o.push(solid({ ax: 'y', sh: 'el', c: [0, CZ], a: 21, b: 20, n: 28, rings: [[28, 0], [30, 0]], col: BR, mat: 'metal' }));
        o.push(solid({ ax: 'y', sh: 'el', c: [0, CZ], a: 24, b: 23, n: 30, rings: [[30, 0, 0.9], [31.6, 0, 0.98], [34, 0, 1], [42, 0, 1], [44, 0, 0.97]], col: IV, mat: 'fab', soft: 1, tex: 'url(#k28bcl) none', texO: 0.9 }));
        const wall = (rg, a0, a1, col, mat) => inFirst(solid({ ax: 'y', sh: 'poly', cv: 0, c: [0, CZ], pts: sector(24, 23, 6, a0, a1, 22), rings: rg, col, mat }), 0, CZ);
        const ARM = wall([[44, 0, 1], [53, 0, 1.01], [55.8, 0, 0.985], [57, 0, 0.955]], PI * 0.94, PI * 2.06, IV, 'fab'); o.push(ARM);
        [PI * 0.94, PI * 2.06].forEach((a, i) => { const x = 21 * Math.cos(a), z = CZ + 20 * Math.sin(a), sg = i ? 1 : -1; on(ARM, [solid({ ax: 'y', sh: 'el', c: [x, z], a: 3.1, b: 3.1, n: 14, rings: [[44, 0, 1], [55.4, 0, 1], [56.6, 0, 0.8], [57.2, 0, 0.45]], col: IV, mat: 'fab', soft: 1 })]).forEach(s => s.fn = [sg * 0.72, 0, 0.7]); });
        o.push(wall([[57, 0, 0.955], [58.2, 0, 0.955]], PI * 0.94, PI * 2.06, BR, 'metal'),
          wall([[58.2, 0, 0.955], [66, 0, 0.965], [70.6, 0, 0.945], [72.4, 0, 0.9]], PI * 1.17, PI * 1.83, IV, 'fab'));
        return o; } };
    D.fx = ctx => { const C = cam(ctx), k = C.k;
      const defs = `<pattern id="k28bcl" width="${f1(1.5 * k)}" height="${f1(1.4 * k)}" patternUnits="userSpaceOnUse"><circle cx="${f1(0.4 * k)}" cy="${f1(0.4 * k)}" r="${f1(0.32 * k)}" fill="none" stroke="#ffffff" stroke-opacity="0.55" stroke-width="${f1(0.16 * k)}"/><circle cx="${f1(1.1 * k)}" cy="${f1(1.05 * k)}" r="${f1(0.3 * k)}" fill="none" stroke="#8a7a62" stroke-opacity="0.35" stroke-width="${f1(0.16 * k)}"/></pattern>`;
      const TH = '#c08a58', fr = (L, b) => rep(14, i => `<path d="M${f1(0.4 + i * 0.85)} ${L}v2.2" stroke="#a8743e" stroke-width="0.35" stroke-linecap="round">${at('rotate', `-7 ${f1(0.4 + i * 0.85)} ${L};7 ${f1(0.4 + i * 0.85)} ${L};-7 ${f1(0.4 + i * 0.85)} ${L}`, 3, b - i * 0.1, SPL(2))}</path>`).join('');
      const knitT = (W, H) => `<rect width="${W}" height="${H}" rx="0.6" fill="${TH}"/>` + rep(Math.floor(W / 1.4), i => `<path d="M${f1(0.7 + i * 1.4)} 0V${H}" stroke="#d8a876" stroke-opacity="0.5" stroke-width="0.4"/>`).join('') + `<rect width="${W}" height="${H}" rx="0.6" fill="url(#m10v)"/>`;
      const topF = PLN(C, [17.6, 58.25, -4], [1, 0, 0], [0, 0, 1], knitT(7, 12.6));
      const flap = PLN(C, [24.5, 58.25, 8.6], [0, 0, -1], [0, -1, 0], `<g>${at('skewX', '-1.4;1.4;-1.4', 5.4, 0, SPL(2))}${knitT(12.6, 21)}<rect y="18.6" width="12.6" height="0.8" fill="#8a5a2a" opacity="0.5"/>${fr(21, 0)}</g>`);
      const fF = vis(C, [1, 0, 0]);
      return { defs, front: (fF ? flap + topF : '') + legGlint(C, LG.map(([x, z]) => [x, z, 0, 28, 1.7]), 9), back: fF ? '' : topF + flap }; };
    return D; };

  // KIT-096 ERGONOMIC HEATED FLOATING DINING POD SEAT (T5): round 62, seat {0, 10, 36} kept. A polished ivory ceramic egg floats a hand's width above a
  // black-glass disc in a champagne-gold rim: a rounded bowl, a cognac leather seat band and a hood that curves up round the back and closes in like an egg,
  // with a tufted leather back pad inside. Heated: the seat glows and breathes warm amber, heat shimmer rises, a warm light pools under the pod and a ring of
  // gold ticks turns slowly in the glass.
  N.pod28 = S => { const CER = '#f3efe8', LEA = '#a8582a', CG = '#d6b878', GL = '#141216', CZ = 2;
    const D = { w: 62, d: 62, round: 1, arch: 'podSeat', act: 'sit', seats: [{ x: 0, z: 10, h: 36 }], build: () => { const { cyl, ball, solid, pillowY } = CHK(), o = [], on = glue(o);
        o.push(cyl(0, 0, 0, 21, 1.2, CG, { n: 32, mat: 'metal' }), cyl(0, 1.2, 0, 19.6, 2.2, GL, { n: 32, mat: 'cer' }));
        o.push(solid({ ax: 'y', sh: 'el', c: [0, CZ], a: 26, b: 25, n: 32, rings: [[9, 0, 0.42], [11, 0, 0.7], [15, 0, 0.88], [22, 0, 1], [29, 0, 0.99], [32, 0, 0.95]], col: CER, mat: 'cer' }));
        o.push(solid({ ax: 'y', sh: 'el', c: [0, CZ], a: 24.7, b: 23.75, n: 32, rings: [[32, 0, 0.99], [34, 0, 1], [36, 1.6, 0.98]], col: LEA, mat: 'lea', soft: 1, tex: 'url(#k28heat) none', texTop: 1 }));
        const HD = inFirst(solid({ ax: 'y', sh: 'poly', cv: 0, c: [0, CZ], pts: sector(24.7, 23.75, 4.6, PI * 1.08, PI * 1.92, 22), rings: [[36, 0, 1], [47, 0, 1.03], [59, 0, 0.98], [68, 0, 0.84], [74.6, 0, 0.66]], col: CER, mat: 'cer' }), 0, CZ); o.push(HD);
        const PAD = solid({ ax: 'z', sh: 'rr', c: [0, 52], a: 11, b: 13, r: 6, rings: [[-15.6, 2, 0.9], [-14.4, 0, 1], [-12.6, 0, 1], [-11.6, 2.6, 0.92]], col: LEA, mat: 'lea', soft: 1 });
        on(HD, [PAD]).forEach(s => s.fn = [0, 0, 1]);
        on(PAD, [[-4, 46], [4, 46], [0, 52], [-4, 58], [4, 58]].map(([x, y]) => ball(x, y, -11.5, 0.75, shade(LEA, 0.6), { k: 3, n: 8, sz: 0.4, noOut: 1, shine: 0 }))).forEach(s => s.fn = [0, 0, 1]);
        return o; } };
    D.fx = ctx => { const C = cam(ctx), k = C.k;
      const defs = `<radialGradient id="k28heat" cx="50%" cy="58%" r="62%"><stop offset="0" stop-color="#ffb868" stop-opacity="0.5">${an('stop-opacity', '0.3;0.6;0.3', 4.2)}</stop><stop offset="0.7" stop-color="#ff8a3a" stop-opacity="0.12"/><stop offset="1" stop-color="#ff8a3a" stop-opacity="0"/></radialGradient>`;
      const floor = PLN(C, [0, 0.05, 0], [1, 0, 0], [0, 0, 1], `<ellipse rx="30" ry="30" fill="url(#k28amb)" opacity="0.6">${an('opacity', '0.45;0.75;0.45', 4.2)}</ellipse>`);
      const glass = PLN(C, [0, 3.45, 0], [1, 0, 0], [0, 0, 1], `<circle r="18.8" fill="url(#k28amb)" opacity="0.8">${an('opacity', '0.6;0.95;0.6', 4.2)}</circle><g><circle r="16.4" fill="none" stroke="${CG}" stroke-width="0.6" stroke-dasharray="0.5 2.1" opacity="0.9"/>${at('rotate', '0;360', 40)}</g><circle r="19.2" fill="none" stroke="${CG}" stroke-width="0.35" opacity="0.6"/><path d="M-12 -10Q0 -16 12 -10" stroke="#ffffff" stroke-opacity="0.12" stroke-width="2" fill="none"/>`);
      const beam = (() => { const a = C.P([0, 3.4, 0]), b = C.P([0, 10, 0]), w = 11 * k; return `<path d="M${f1(a[0] - w)} ${f1(a[1])}L${f1(b[0] - w * 0.7)} ${f1(b[1])}H${f1(b[0] + w * 0.7)}L${f1(a[0] + w)} ${f1(a[1])}Z" fill="#ffc890" opacity="0.18">${an('opacity', '0.1;0.24;0.1', 4.2)}</path>`; })();
      const shm = (() => { const p = C.P([0, 37, 8]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})">` + rep(4, i => `<path d="M${-7.5 + i * 5} 0q1.2 -1.8 0 -3.6t0 -3.6t0 -3.6" stroke="#ffd2a0" stroke-width="0.45" fill="none" opacity="0">${at('translate', '0 0;0 -6', 2.8, -i * 0.7)}${an('opacity', '0;0.4;0', 2.8, -i * 0.7)}</path>`).join('') + '</g>'; })();
      C.p(0, 80, 0);
      return { defs, under: floor + glass + beam, front: shm, bb: C.bb(4) }; };
    return D; };

  // KIT-105 WALNUT & LINEN BUTTON-TUFTED DINING CHAIR (T3): 52 x 54, seat {0, 4, 46} kept, linen colour from the picker (row colours). Oiled walnut frame:
  // tapered front legs with brass caps, back legs that rise as posts to turned finials, a seat rail, a lower back rail and a crest rail. A thick linen seat
  // with brass nailheads along the front, a button-tufted linen back panel with diamond pleats. A sage silk ribbon bow with a eucalyptus sprig is tied to the
  // back of the crest, its tails swaying.
  N.lin28 = S => { const WN = '#6b4226', BR = '#c9a256';
    const D = { w: 52, d: 54, arch: 'luxDChair', act: 'sit', seats: [{ x: 0, z: 4, h: 46 }], build: P => { const { box, cyl, ball, solid, pillowZ } = CHK(), o = [], on = glue(o), FA = (P && P.a) || '#d8ccb4';
        [-17, 17].forEach(x => { const L = cyl(x, 0, 17, 1.9, 32, WN, { n: 12, mat: 'wood', rg: [[0, 0, 0.66], [32, 0, 1]] }); o.push(L); on(L, [cyl(x, -0.2, 17, 1.45, 1.8, BR, { n: 10, mat: 'metal' })]); });
        [-18, 18].forEach(x => { o.push(cyl(x, 0, -19.5, 2, 88, WN, { n: 12, mat: 'wood', rg: [[0, 0, 0.72], [34, 0, 1], [62, 0, 0.95], [88, 0, 0.9]] }), ball(x, 88, -19.5, 2.2, WN, { k: 4, n: 10, mat: 'wood', shine: 0 })); });
        o.push(box(0, 32, 2, 42, 3.4, 37, WN, { r: 2, mat: 'wood' }));
        const SE = solid({ ax: 'y', sh: 'rr', c: [0, 2], a: 21, b: 18.5, r: 6, rings: [[35.4, 1.5, 0.97], [37, 0, 1], [44, 0, 1], [46, 3, 0.97]], col: FA, mat: 'fab', soft: 1, tex: 'url(#k28lin) none', texO: 0.85 }); o.push(SE);
        on(SE, rep(15, i => ball(-16.8 + i * 2.4, 37.6, 20.55, 0.55, BR, { k: 3, n: 8, sz: 0.5, noOut: 1 }))).forEach(s => s.fn = [0, 0, 1]);
        o.push(box(0, 47.5, -15.6, 34, 3.5, 3.2, WN, { r: 1, mat: 'wood' }), box(0, 84, -15.6, 34, 4, 3.4, WN, { r: 1.2, mat: 'wood' }));
        const BK = solid({ ax: 'z', sh: 'rr', c: [0, 67.7], a: 16, b: 15.7, r: 3, rings: [[-17.4, 1, 0.98], [-16.4, 0, 1], [-14.2, 0, 1], [-13, 1.6, 0.96]], col: FA, mat: 'fab', soft: 1, tex: 'url(#k28lin) none', texO: 0.85 }); o.push(BK);
        on(BK, [[-8, 76], [0, 76], [8, 76], [-4, 68], [4, 68], [-8, 60], [0, 60], [8, 60]].map(([x, y]) => ball(x, y, -12.85, 0.9, shade(FA, 0.62), { k: 3, n: 8, sz: 0.45, noOut: 1, shine: 0 }))).forEach(s => s.fn = [0, 0, 1]);
        return o; } };
    D.fx = ctx => { const C = cam(ctx), k = C.k, P = ctx.P || {}, FA = P.a || '#d8ccb4';
      const defs = `<pattern id="k28lin" width="${f1(0.9 * k)}" height="${f1(0.9 * k)}" patternUnits="userSpaceOnUse"><path d="M0 ${f1(0.22 * k)}H${f1(0.9 * k)}" stroke="#ffffff" stroke-opacity="0.2" stroke-width="${f1(0.2 * k)}"/><path d="M${f1(0.22 * k)} 0V${f1(0.9 * k)}" stroke="#000000" stroke-opacity="0.08" stroke-width="${f1(0.2 * k)}"/></pattern>`;
      let s = '';
      if (vis(C, [0, 0, 1])) { const dk = shade(FA, 0.55);
        s += PLN(C, [-16, 84, -12.82], [1, 0, 0], [0, -1, 0], (() => { const L = 'M8 8L12 16L16 8L20 16L24 8M8 24L12 16L16 24L20 16L24 24M8 8L5 1.6M16 8V1.6M24 8L27 1.6M8 24L5 30.4M16 24V30.4M24 24L27 30.4M8 8L2 16L8 24M24 8L30 16L24 24'; return `<path d="${L}" stroke="${dk}" stroke-opacity="0.5" stroke-width="0.4" fill="none" stroke-linecap="round"/><path d="${L}" stroke="#ffffff" stroke-opacity="0.25" stroke-width="0.3" fill="none" transform="translate(0.35 0.35)"/>`; })()); }
      // ribbon bow + eucalyptus sprig on the back of the crest
      const q0 = [0, 86, -17.5], p0 = C.P(q0), SG = '#a8b89a';
      const bow = `<g transform="translate(${P2(p0)}) scale(${n4(k)})"><path d="M0 0C-3 -2.4 -5 -1 -4.4 0.6C-3.8 2 -1.6 1.2 0 0ZM0 0C3 -2.4 5 -1 4.4 0.6C3.8 2 1.6 1.2 0 0Z" fill="${SG}" stroke="#7a8a6a" stroke-width="0.2"/><ellipse rx="0.9" ry="1" fill="#94a684"/></g>`;
      const tails = dangle(C, add(q0, [-0.4, -0.6, 0]), 9, 0.7, SG, null, 4.4, 0, 6) + dangle(C, add(q0, [0.4, -0.6, 0]), 11, 0.7, SG, null, 4.9, -1.6, 7);
      const st0 = [-7, 84.6, -17.9], st1 = [8, 90.4, -17.9], lf = (q, r, c) => { const p = C.P(q); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(r * C.k)}" ry="${f1(r * 0.86 * C.k)}" fill="${c}" stroke="#6a7e70" stroke-width="${f1(0.12 * C.k)}"/>`; };
      const sprig = sway(C, q0, H2(C, st0, st1, 0.28, '#6a7a64') + rep(8, i => { const f = 0.08 + i * 0.12, q = [st0[0] + (st1[0] - st0[0]) * f, st0[1] + (st1[1] - st0[1]) * f + (i % 2 ? 1.2 : -1.1), -17.95]; return lf(q, 1.35 - i * 0.06, i % 2 ? '#93ab9f' : '#a9bdb3'); }).join(''), 1.4, 6.2);
      const bk = tails + sprig + bow, bF = C.v[2] < 0;
      return { defs, front: s + (bF ? bk : ''), back: bF ? '' : bk }; };
    return D; };

  // ---------- batch 9: KIT-106 / 107 dining chairs + KIT-019 shop stool (seats, solid-sorted) ----------
  // velvet sheen: a soft highlight band that drifts across the fabric (tex over the solid, objectBoundingBox gradient)
  const velD = (id, T) => `<linearGradient id="${id}" x1="0" y1="0" x2="1" y2="0.4"><stop offset="0.25" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.45" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="0.52" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-0.5 0;0.5 0;-0.5 0" dur="${T}s" repeatCount="indefinite" calcMode="spline" keyTimes="0;0.5;1" keySplines="0.45 0 0.55 1;0.45 0 0.55 1"/></linearGradient>`;

  // KIT-106 BRUSHED BRASS & VELVET CHANNEL-BACK DINING CHAIR (T4): 52 x 54, seat {0, 4, 46} kept, velvet colour from the picker. Slim tapered square brass
  // legs and seat frame, a plump velvet seat, a tall rounded velvet back with vertical channels in a brushed-brass shell. The velvet sheen drifts slowly
  // across the seat and back; a glint slides down the brass legs now and then.
  N.chan28 = S => { const BR = '#c9a256', LG = [[-17, -16], [17, -16], [-17, 17], [17, 17]];
    const D = { w: 52, d: 54, arch: 'luxDChair', act: 'sit', seats: [{ x: 0, z: 4, h: 46 }], build: P => { const { solid } = CHK(), o = [], on = glue(o), FA = (P && P.a) || '#1f6a4c', VT = { mat: 'fab', soft: 1, tex: 'url(#k28vel) none' };
        LG.forEach(([x, z]) => { const L = solid({ ax: 'y', sh: 'rr', c: [x, z], a: 1.7, b: 1.7, r: 0.5, rings: [[0, 0, 0.62], [33, 0, 1]], col: BR, mat: 'metal' }); o.push(L); on(L, [solid({ ax: 'y', sh: 'rr', c: [x, z], a: 1.25, b: 1.25, r: 0.4, rings: [[-0.3, 0], [0.9, 0]], col: '#8a6a2e', mat: 'metal' })]); });
        o.push(solid({ ax: 'y', sh: 'rr', c: [0, 1], a: 21, b: 20, r: 3, rings: [[33, 0], [35.4, 0]], col: BR, mat: 'metal' }));
        o.push(solid(Object.assign({ ax: 'y', sh: 'rr', c: [0, 4], a: 20, b: 17, r: 7, rings: [[35.4, 1.4, 0.97], [37, 0, 1], [43.8, 0, 1], [46, 3.4, 0.95]], col: FA }, VT)));
        o.push(solid({ ax: 'z', sh: 'rr', c: [0, 59.3], a: 20.8, b: 26.3, r: 10, rings: [[-21, 0], [-19.4, 0]], col: BR, mat: 'metal' }));
        const BK = solid(Object.assign({ ax: 'z', sh: 'rr', c: [0, 60], a: 19.2, b: 24.6, r: 9, rings: [[-19.4, 0, 1], [-15.4, 0, 1], [-13.4, 1.6, 0.95]], col: FA }, VT)); o.push(BK);
        on(BK, [-11.6, -3.9, 3.9, 11.6].map(x => solid({ ax: 'z', sh: 'rr', c: [x, 59], a: 0.55, b: 21.4, r: 0.5, rings: [[-13.4, 0], [-12.95, 0]], col: shade(FA, 0.55), noOut: 1 }))).forEach(s => s.fn = [0, 0, 1]);
        return o; } };
    D.fx = ctx => { const C = cam(ctx);
      return { defs: velD('k28vel', 9), front: legGlint(C, LG.map(([x, z]) => [x, z, 0, 33, 1.7]), 8) }; };
    return D; };

  // KIT-107 ROYAL EBONY & GOLD-LEAF TUFTED VELVET DINING CHAIR (T5): 52 x 54, seat {0, 4, 46} kept, velvet colour from the picker. Gloss ebony frame: turned
  // legs with gold-leaf bands and gold ball feet, a seat rail with a gold-leaf bead and rosettes, a medallion (oval) back in an ebony frame with a gold-leaf
  // ring and a gold crown finial; deep button-tufted velvet seat + back with gold buttons. The velvet sheen drifts, the crown and rosettes twinkle.
  N.royal28 = S => { const EB = '#221c1a', GD = '#d9b45a', LG = [[-17, -16], [17, -16], [-17, 17], [17, 17]], PY = 70;
    const D = { w: 52, d: 54, arch: 'luxDChair', act: 'sit', seats: [{ x: 0, z: 4, h: 46 }], build: P => { const { cyl, ball, solid, pillowY } = CHK(), o = [], on = glue(o), FA = (P && P.a) || '#7f2030';
        LG.forEach(([x, z]) => { const L = cyl(x, 2.4, z, 2.2, 29.6, EB, { n: 14, mat: 'gloss', shine: 1, rg: [[0, 0, 0.62], [3, 0, 0.85], [13, 0, 1.25], [22, 0, 0.82], [29.6, 0, 1.08]] }); o.push(L);
          on(L, [ball(x, 0, z, 1.9, GD, { k: 4, n: 12, sy: 0.65 }), cyl(x, 14.6, z, 2.85, 1.3, GD, { n: 14, mat: 'metal' }), cyl(x, 28.4, z, 2.55, 1.1, GD, { n: 14, mat: 'metal' })]); });
        const FR = solid({ ax: 'y', sh: 'rr', c: [0, 1], a: 23, b: 21, r: 3, rings: [[32, 0, 0.97], [33, 0, 1], [36, 0, 1]], col: EB, shine: 1 }); o.push(FR);
        on(FR, [solid({ ax: 'z', sh: 'rr', c: [0, 34.3], a: 21, b: 0.6, r: 0.5, rings: [[22, 0], [22.45, 0]], col: GD, noOut: 1 })].concat([-19.5, 0, 19.5].map(x => solid({ ax: 'z', sh: 'el', c: [x, 34.2], a: 1.5, b: 1.5, n: 12, rings: [[22, 0], [22.7, 0.5]], col: GD, mat: 'metal' })))).forEach(s => s.fn = [0, 0, 1]);
        const SE = pillowY(0, 36, 4, 42, 10, 34, FA, { mat: 'fab', tex: 'url(#k28vel2) none' }); o.push(SE);
        on(SE, [[-12, -4], [0, -4], [12, -4], [-6, 5], [6, 5], [-12, 14], [0, 14], [12, 14]].map(([x, z]) => ball(x, 45.4, 4 + z, 0.95, GD, { k: 3, n: 8, sy: 0.55, noOut: 1 })));
        o.push(solid({ ax: 'y', sh: 'rr', c: [0, -16.5], a: 10, b: 2.5, r: 1, rings: [[36, 0], [46, 0, 0.82], [48, 0, 0.7]], col: EB, shine: 1 }));
        const PL = solid({ ax: 'z', sh: 'el', c: [0, PY], a: 18, b: 22, n: 30, rings: [[-19.6, 0], [-16.8, 0]], col: EB, shine: 1 }); o.push(PL);
        on(PL, [solid({ ax: 'z', sh: 'el', c: [0, PY], a: 17.1, b: 21.1, n: 30, rings: [[-16.8, 0], [-16.3, 0]], col: GD, mat: 'metal' })]).forEach(s => s.fn = [0, 0, 1]);
        on(PL, [solid({ ax: 'z', sh: 'el', c: [0, PY], a: 15.6, b: 19.6, n: 30, rings: [[-20.1, 0], [-19.6, 0]], col: GD, mat: 'metal' })]).forEach(s => s.fn = [0, 0, -1]);
        on(PL, [ball(0, PY + 21.4, -18.2, 1.9, GD, { k: 4, n: 12 }), cyl(0, PY + 24.8, -18.2, 1.4, 2.6, GD, { n: 10, mat: 'metal', rg: [[0, 0, 1], [1.2, 0, 0.5], [2.6, 0, 0.15]] })]);
        const PD = solid({ ax: 'z', sh: 'el', c: [0, PY], a: 15.2, b: 19.2, n: 30, rings: [[-16.2, 1.2, 0.96], [-15, 0, 1], [-13.8, 0, 1], [-12.4, 2.4, 0.92]], col: FA, mat: 'fab', soft: 1, tex: 'url(#k28vel2) none' }); o.push(PD);
        on(PD, [[0, 13], [-7, 6.5], [7, 6.5], [0, 0], [-10, 0], [10, 0], [-7, -6.5], [7, -6.5], [0, -13]].map(([x, y]) => ball(x, PY + y - 0.9, -12.4 + (1 - (x / 15) ** 2 - (y / 19) ** 2) * 0.9, 0.9, GD, { k: 3, n: 8, sz: 0.5, noOut: 1 }))).forEach(s => s.fn = [0, 0, 1]);
        return o; } };
    D.fx = ctx => { const C = cam(ctx), fv = vis(C, [0, 0, 1]);
      const tw = spk(C, [0, PY + 27.6, -18.2], 0.5, 0) + (fv ? spk(C, [-19.5, 34.2, 22.8], 0.35, -0.9) + spk(C, [19.5, 34.2, 22.8], 0.35, -2.1) + spk(C, [12, PY + 8, -12], 0.4, -1.4) : spk(C, [-10, PY + 10, -20.3], 0.4, -1.4));
      return { defs: velD('k28vel2', 10), front: tw }; };
    return D; };

  // KIT-019 RUSTY METAL GARAGE SHOP STOOL (T1): round 44, seat {0, 0, 71} kept (arch barstool). A tall steel shop stool gone orange with rust: four splayed
  // legs, a foot ring bent in four pieces, a threaded height screw under the seat pan, a cracked black vinyl pad patched with duct tape, three rubber feet
  // (the fourth leg bare and scraped). A greasy red shop rag hangs over the foot ring and sways; now and then a flake of rust drops to the floor.
  N.shop28 = S => { const ST = '#6e6a66', RT = { tex: 'url(#k28rst) none', texO: 0.95 }, SH = 62, R0 = 17, R1 = 10.5, LA = [PI / 4, PI * 3 / 4, PI * 5 / 4, PI * 7 / 4];
    const D = { w: 44, d: 44, round: 1, arch: 'barstool', act: 'sit', seats: [{ x: 0, z: 0, h: 71 }], build: () => { const { cyl, ball, solid, rod, arcW } = CHK(), o = [], on = glue(o);
        LA.forEach((a, i) => { const c = Math.cos(a), s = Math.sin(a), L = rod([c * R0, 0.8, s * R0], [c * R1, SH, s * R1], 1.55, ST, Object.assign({ n: 10, mat: 'metal' }, RT)); o.push(L);
          if (i !== 1) on(L, [cyl(c * R0, 0, s * R0, 2.1, 2.2, '#1e1e20', { n: 10, rg: [[0, 0, 1], [2.2, 0, 0.85]] })]); });
        const rr = R0 - (R0 - R1) * 22 / SH;
        [[-38, 38], [52, 128], [142, 218], [232, 308]].forEach(([a0, a1]) => { const A = arcW(0, 21, 0, rr, rr, 1.3, 1.8, a0 * PI / 180, a1 * PI / 180, ST, Object.assign({ n: 10, mat: 'metal' }, RT)); o.push(A); });
        o.push(cyl(0, 40, 0, 2.3, SH - 40, '#8a8680', Object.assign({ n: 12, mat: 'metal' }, RT)), cyl(0, 50, 0, 4.4, 2.4, ST, Object.assign({ n: 12, mat: 'metal' }, RT)));
        const PAN = cyl(0, SH, 0, 15, 3.4, ST, Object.assign({ n: 28, mat: 'metal', rg: [[0, 0, 0.92], [1, 0, 1], [3.4, 0, 1]] }, RT)); o.push(PAN);
        const PADS = cyl(0, SH + 3.4, 0, 14.4, 5.4, '#26252a', { n: 28, mat: 'lea', soft: 1, rg: [[0, 0, 0.98], [3.6, 0, 1], [5.4, 0.8, 0.9]] }); o.push(PADS);
        on(PADS, [solid({ ax: 'y', sh: 'rr', c: [4, 3], a: 6, b: 2, r: 0.4, yaw: 0.5, rings: [[SH + 8.82, 0], [SH + 9.05, 0]], col: '#b4b9be', noOut: 1, mat: 'fab' }), solid({ ax: 'y', sh: 'rr', c: [4, 3], a: 2, b: 5.6, r: 0.4, yaw: 0.5, rings: [[SH + 9.05, 0], [SH + 9.25, 0]], col: '#a4a9ae', noOut: 1, mat: 'fab' }),
          solid({ ax: 'y', sh: 'rr', c: [-6, -4], a: 0.25, b: 4, r: 0.2, yaw: -0.7, rings: [[SH + 8.82, 0], [SH + 8.95, 0]], col: '#5a5a60', noOut: 1 })]);
        return o; } };
    D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('shop28');
      const defs = `<pattern id="k28rst" width="${f1(7 * k)}" height="${f1(6 * k)}" patternUnits="userSpaceOnUse">` + rep(9, () => `<ellipse cx="${f1(R() * 7 * k)}" cy="${f1(R() * 6 * k)}" rx="${f1((0.5 + R() * 1.4) * k)}" ry="${f1((0.4 + R() * 0.9) * k)}" fill="${R() < 0.55 ? '#b8582a' : '#8a3a1a'}" opacity="${n4(0.45 + R() * 0.4)}"/>`).join('') + rep(5, () => `<circle cx="${f1(R() * 7 * k)}" cy="${f1(R() * 6 * k)}" r="${f1(0.25 * k)}" fill="#d8783a"/>`).join('') + '</pattern>';
      const rr = R0 - (R0 - R1) * 22 / SH;
      const ragX = `<rect width="8" height="13" fill="#b8322a"/>` + rep(6, i => `<path d="M0 ${f1(1 + i * 2.2)}H8" stroke="#8a2018" stroke-width="0.25"/>`).join('') + `<ellipse cx="4" cy="8" rx="3" ry="2.2" fill="#2a1a14" opacity="0.35"/><ellipse cx="2.4" cy="3" rx="1.4" ry="1" fill="#2a1a14" opacity="0.3"/>`;
      const rag = PLN(C, [-4, 22.8, rr + 0.4], [1, 0, 0], [0, -1, 0], towS(8, 13, '#b8322a', ragX, 5.2));
      const fl = drop1(C, [10.8, SH, 10.8], [11.4, 0.4, 11.6], 0.28, '#a8482a', 7, 0.3, 0.42) + drop1(C, [-12, SH + 1, -8], [-12.6, 0.4, -8.6], 0.24, '#8a3a1a', 11, 0.6, 0.7);
      const flr = PLN(C, [0, 0.05, 0], [1, 0, 0], [0, 0, 1], `<ellipse cx="11" cy="11.4" rx="2.4" ry="1.4" fill="#a8482a" opacity="0.35"/><circle cx="-12.4" cy="-8.4" r="0.6" fill="#8a3a1a" opacity="0.5"/><circle cx="9" cy="13" r="0.4" fill="#8a3a1a" opacity="0.5"/>`);
      const rF = vis(C, [0, 0, 1]);
      return { defs, under: flr, front: (rF ? rag : '') + fl, back: rF ? '' : rag }; };
    return D; };

  // ---------- batch 10: counter stools KIT-039 / 059 / 079 (round 44, seat {0, 0, 71}, arch barstool kept) ----------
  // straight rung between two splayed legs at height y (ends stop short of the legs so the parts only touch)
  const rungXZ = (R0, R1, SH, y, a0, a1, gap) => { const r = R0 - (R0 - R1) * y / SH, A = [Math.cos(a0) * r, y, Math.sin(a0) * r], B = [Math.cos(a1) * r, y, Math.sin(a1) * r], d = [B[0] - A[0], 0, B[2] - A[2]], L = Math.hypot(d[0], d[2]), u = [d[0] / L, 0, d[2] / L];
    return [[A[0] + u[0] * gap, y, A[2] + u[2] * gap], [B[0] - u[0] * gap, y, B[2] - u[2] * gap]]; };

  // KIT-039 BACKLESS WOODEN SADDLE BARSTOOL (T2): honey oak saddle seat (carved dip, raised pommel, end grain at the edge) on four splayed oak legs with
  // a square of rungs; the front rung is worn pale and scuffed by feet. A blue-striped tea towel is draped over one side of the seat and sways.
  N.sad28 = S => { const OK = '#c89458', SH = 66, R0 = 17.5, R1 = 9.5, LA = [PI / 4, PI * 3 / 4, PI * 5 / 4, PI * 7 / 4];
    const D = { w: 44, d: 44, round: 1, arch: 'barstool', act: 'sit', seats: [{ x: 0, z: 0, h: 71 }], build: () => { const { solid, rod } = CHK(), o = [], on = glue(o);
        LA.forEach(a => o.push(rod([Math.cos(a) * R0, 0, Math.sin(a) * R0], [Math.cos(a) * R1, SH, Math.sin(a) * R1], 1.75, OK, { n: 10, mat: 'wood' })));
        [[0, 1, 24], [1, 2, 17], [2, 3, 24], [3, 0, 17]].forEach(([i, j, y]) => { const [a, b] = rungXZ(R0, R1, SH, y, LA[i], LA[j], 2.4), R = rod(a, b, 1.05, shade(OK, 0.95), { n: 8, mat: 'wood' }); o.push(R);
          if (i === 0) on(R, [rod([a[0] - 0.2, y + 0.75, a[2] + 3], [b[0] - 0.2, y + 0.75, b[2] - 3], 0.5, '#e8c890', { n: 6, noOut: 1 })]); });
        o.push(solid({ ax: 'y', sh: 'el', c: [0, 0], a: 17, b: 15.5, n: 28, rings: [[SH, 0, 0.94], [SH + 1.4, 0, 1], [SH + 3.6, 0, 1], [SH + 5, 1.5, 0.96]], col: OK, mat: 'wood' }));
        return o; } };
    D.fx = ctx => { const C = cam(ctx), TY = SH + 5;
      const top = PLN(C, [0, TY + 0.03, 0], [1, 0, 0], [0, 0, 1], `<defs><radialGradient id="k28sd" cx="50%" cy="55%" r="55%"><stop offset="0" stop-color="#5a3414" stop-opacity="0.32"/><stop offset="0.6" stop-color="#5a3414" stop-opacity="0.1"/><stop offset="1" stop-color="#5a3414" stop-opacity="0"/></radialGradient></defs>`
        + `<ellipse cx="0" cy="-2" rx="11" ry="9" fill="url(#k28sd)"/><ellipse cx="0" cy="11" rx="5" ry="2.6" fill="#ffffff" opacity="0.22"/><path d="M-12 -4Q0 -10 12 -4M-13 1Q0 -5 13 1M-12 6Q0 0 12 6" stroke="#7a4a22" stroke-opacity="0.22" stroke-width="0.3" fill="none"/><path d="M-5 -1Q-3 4 -5 9M5 -1Q3 4 5 9" stroke="#ffffff" stroke-opacity="0.2" stroke-width="0.5" fill="none"/>`);
      const TW = '#f2ede2', twX = `<rect width="11" height="17" fill="${TW}"/>` + [2, 3.4, 13.4, 14.8].map(y => `<rect y="${y}" width="11" height="0.8" fill="#3a5a8a" opacity="0.85"/>`).join('') + rep(11, i => `<path d="M${f1(0.5 + i)} ${f1(16.8 + (i % 2) * 0.2)}v0.9" stroke="#3a5a8a" stroke-width="0.25"/>`).join('');
      const flapT = PLN(C, [8, TY + 0.06, -5.5], [1, 0, 0], [0, 0, 1], `<path d="M0 0H9Q10.4 5.5 9 11H0Z" fill="${TW}"/><path d="M0 0H9Q10.4 5.5 9 11H0Z" fill="url(#m10v)"/>` + [1.6, 2.8, 8.2, 9.4].map(y => `<rect y="${y}" width="9.4" height="0.7" fill="#3a5a8a" opacity="0.85"/>`).join(''));
      const flap = PLN(C, [16.6, TY - 0.6, 5.5], [0, 0, -1], [0, -1, 0], towS(11, 17, TW, twX, 5.4));
      const fF = vis(C, [1, 0, 0]);
      return { front: top + flapT + (fF ? flap : ''), back: fF ? '' : flap }; };
    return D; };

  // KIT-059 INDUSTRIAL SWIVEL LEATHER & IRON TRACTOR STOOL (T3): black cast-iron base (four splayed legs on wide pads, rivets, a foot ring in four pieces),
  // a threaded swivel column with a steel collar, a pressed-iron tractor seat pan (drain slots round the rim) and a cognac leather pad with stitching and
  // a ring of brass nailheads. A leather strap with a brass buckle hangs from the pan and sways; the leather has a slow warm sheen.
  N.trac28 = S => { const IR = '#2c2c2e', LE = '#a8582a', BR = '#c9a256', SH = 58, R0 = 17, R1 = 8, LA = [PI / 4, PI * 3 / 4, PI * 5 / 4, PI * 7 / 4];
    const D = { w: 44, d: 44, round: 1, arch: 'barstool', act: 'sit', seats: [{ x: 0, z: 0, h: 71 }], build: () => { const { cyl, ball, solid, rod, arcW } = CHK(), o = [], on = glue(o);
        LA.forEach(a => { const c = Math.cos(a), s = Math.sin(a), L = rod([c * R0, 1.4, s * R0], [c * R1, 42, s * R1], 1.6, IR, { n: 10, mat: 'metal' }); o.push(L);
          on(L, [solid({ ax: 'y', sh: 'el', c: [c * (R0 + 0.6), s * (R0 + 0.6)], a: 3.2, b: 3.2, n: 14, rings: [[0, 0], [1.4, 0, 0.8]], col: IR, mat: 'metal' }), ball(c * (R0 - 2.6), 9.6, s * (R0 - 2.6), 0.55, '#6a6a6e', { k: 3, n: 8, noOut: 1 })]); });
        const rr = R0 - (R0 - R1) * 20 / 42;
        [[-36, 36], [54, 126], [144, 216], [234, 306]].forEach(([a0, a1]) => o.push(arcW(0, 19.2, 0, rr, rr, 1.2, 1.6, a0 * PI / 180, a1 * PI / 180, IR, { n: 10, mat: 'metal' })));
        o.push(cyl(0, 42, 0, 8.6, 3, IR, { n: 20, mat: 'metal', rg: [[0, 0, 1], [3, 0, 0.7]] }), cyl(0, 45, 0, 2.2, SH - 47, '#7a7a7e', { n: 12, mat: 'metal' }), cyl(0, SH - 2, 0, 5, 2, '#9a9a9e', { n: 16, mat: 'metal' }));
        const PAN = solid({ ax: 'y', sh: 'el', c: [0, 0], a: 16.5, b: 15.5, n: 30, rings: [[SH, 0, 0.6], [SH + 2.2, 0, 0.92], [SH + 4.6, 0, 1]], col: '#3a3a3c', mat: 'metal' }); o.push(PAN);
        const PAD = solid({ ax: 'y', sh: 'el', c: [0, 0], a: 15.8, b: 14.8, n: 30, rings: [[SH + 4.6, 0, 0.98], [SH + 7.6, 0, 1], [SH + 9.4, 0, 0.94], [SH + 10.4, 0, 0.78]], col: LE, mat: 'lea', soft: 1, tex: 'url(#k28lea) none', texTop: 1 }); o.push(PAD);
        on(PAD, rep(18, i => { const a = i * PI / 9, c = Math.cos(a), s = Math.sin(a), b = ball(c * 16.05, SH + 5.6, s * 15.05, 0.5, BR, { k: 3, n: 8, noOut: 1 }); b.fn = [c, 0, s]; return b; }));
        return o; } };
    D.fx = ctx => { const C = cam(ctx), TY = SH + 10.4;
      const defs = `<radialGradient id="k28lea" cx="40%" cy="40%" r="60%"><stop offset="0" stop-color="#ffd8a8" stop-opacity="0.28"><animate attributeName="stop-opacity" values="0.18;0.34;0.18" dur="7s" repeatCount="indefinite"/></stop><stop offset="0.6" stop-color="#ffd8a8" stop-opacity="0.04"/><stop offset="1" stop-color="#3a1a08" stop-opacity="0.18"/></radialGradient>`;
      const top = PLN(C, [0, TY + 0.03, 0], [1, 0, 0], [0, 0, 1], `<ellipse rx="10.6" ry="9.8" fill="none" stroke="#f2d8b0" stroke-width="0.35" stroke-dasharray="0.9 0.6" opacity="0.8"/><path d="M-6 -2Q0 -5 6 -2" stroke="#6a2e10" stroke-opacity="0.3" stroke-width="0.5" fill="none"/>`);
      const slots = Math.cos(C.thV) > -2 ? `<g transform="${tanF(C, 0, 0, 15.6, C.thV, SH + 2.6)}">` + [-6, -2, 2, 6].map(x => `<rect x="${x - 0.7}" y="-0.6" width="1.4" height="1.4" rx="0.6" fill="#0e0e10"/>`).join('') + `</g>` : '';
      const strap = dangle(C, [-11.6, SH + 1.4, 11], 9, 1.1, '#8a4418', q => `<rect x="${f1(q[0] - 1.1 * C.k)}" y="${f1(q[1] - 2.6 * C.k)}" width="${f1(2.2 * C.k)}" height="${f1(1.8 * C.k)}" rx="${f1(0.3 * C.k)}" fill="none" stroke="${BR}" stroke-width="${f1(0.4 * C.k)}"/>`, 4.6, 0, 6);
      const sF = vis(C, [-0.7, 0, 0.7]);
      return { defs, front: top + slots + (sF ? strap : ''), back: sF ? '' : strap }; };
    return D; };

  // KIT-079 TUFTED VELVET COUNTER STOOL WITH BRASS FOOTREST (T4): emerald velvet: a plump round button-tufted seat (gold buttons) on a brushed-brass seat
  // ring, a low curved velvet back with a brass band, four slim brass legs and a brass foot ring between them. Velvet sheen drifts; glints slide down the legs.
  N.vel28 = S => { const BR = '#c9a256', VE = '#1f6a4c', SH = 60, R0 = 15.5, R1 = 12, LA = [PI / 4, PI * 3 / 4, PI * 5 / 4, PI * 7 / 4];
    const D = { w: 44, d: 44, round: 1, arch: 'barstool', act: 'sit', seats: [{ x: 0, z: 0, h: 71 }], build: () => { const { cyl, ball, solid, rod, arcW } = CHK(), o = [], on = glue(o), VT = { mat: 'fab', soft: 1, tex: 'url(#k28vel3) none' };
        LA.forEach(a => { const c = Math.cos(a), s = Math.sin(a), L = rod([c * R0, 0.9, s * R0], [c * R1, SH, s * R1], 1.15, BR, { n: 10, mat: 'metal' }); o.push(L); on(L, [cyl(c * R0, 0, s * R0, 1.5, 1.2, '#8a6a2e', { n: 10, mat: 'metal' })]); });
        const rr = R0 - (R0 - R1) * 22 / SH;
        [[-36, 36], [54, 126], [144, 216], [234, 306]].forEach(([a0, a1]) => o.push(arcW(0, 21.4, 0, rr + 0.2, rr + 0.2, 1.5, 1.5, a0 * PI / 180, a1 * PI / 180, BR, { n: 10, mat: 'metal' })));
        o.push(solid({ ax: 'y', sh: 'el', c: [0, 0], a: 16, b: 16, n: 30, rings: [[SH, 0], [SH + 2, 0]], col: BR, mat: 'metal' }));
        const SE = solid(Object.assign({ ax: 'y', sh: 'el', c: [0, 0], a: 17.4, b: 17.4, n: 30, rings: [[SH + 2, 0, 0.92], [SH + 3.6, 0, 1], [SH + 7.6, 0, 1], [SH + 10, 0, 0.9], [SH + 11, 0, 0.7]], col: VE }, VT)); o.push(SE);
        on(SE, [[0, 0], [7, 0], [-7, 0], [3.5, 6.1], [-3.5, 6.1], [3.5, -6.1], [-3.5, -6.1]].map(([x, z]) => ball(x, SH + 10.4, z, 0.85, BR, { k: 3, n: 8, sy: 0.55, noOut: 1 })));
        const wall = (rg, col, mat, ex) => inFirst(solid(Object.assign({ ax: 'y', sh: 'poly', cv: 0, c: [0, 0], pts: sector(17.2, 17.2, 4.2, PI * 1.12, PI * 1.88, 18), rings: rg, col, mat }, ex || {})), 0, 0);
        o.push(wall([[SH + 11, 0, 1], [SH + 20, 0, 1.01], [SH + 22.6, 0, 0.99]], VE, 'fab', VT), wall([[SH + 22.6, 0, 0.99], [SH + 23.8, 0, 0.99]], BR, 'metal'));
        return o; } };
    D.fx = ctx => { const C = cam(ctx);
      const pl = PLN(C, [0, SH + 11.03, 0], [1, 0, 0], [0, 0, 1], `<g stroke="#0e3a28" stroke-opacity="0.45" stroke-width="0.3" fill="none"><path d="M0 0L7 0M0 0L-7 0M0 0L3.5 6.1M0 0L-3.5 6.1M0 0L3.5 -6.1M0 0L-3.5 -6.1"/><path d="M7 0L3.5 6.1L-3.5 6.1L-7 0L-3.5 -6.1L3.5 -6.1Z"/></g>`);
      return { defs: velD('k28vel3', 9), front: legGlint(C, LA.map(a => [Math.cos(a) * 14, Math.sin(a) * 14, 1, SH, 1.15]), 8) }; };
    return D; };

  // ---------- batch 11: KIT-099 levitation stool (seat), KIT-003 plastic utility cart, KIT-023 wire + bamboo microwave stand ----------
  // decal clipped to the half of a horizontal disc that faces the viewer (PLN local u = x, v = z): the far half sits behind posts / columns
  const nearHalf = (C, R0, s) => { const L = Math.hypot(C.v[0], C.v[2]) || 1, nx = C.v[0] / L, nz = C.v[2] / L, tx = -nz, tz = nx, id = 'k28nh' + (UIDT++), E = R0 + 2;
    const pts = [[tx * E, tz * E], [tx * E + nx * E, tz * E + nz * E], [-tx * E + nx * E, -tz * E + nz * E], [-tx * E, -tz * E]].map(p => f1(p[0]) + ' ' + f1(p[1]));
    return `<clipPath id="${id}"><path d="M${pts.join('L')}Z"/></clipPath><g clip-path="url(#${id})">${s}</g>`; };

  // clip box3 face decals to their face (top: w x d with rounded corners; sides: the flat part between the corner radii) so nothing pokes past a corner
  const clipF = (C, o) => { const D = o.dec || {}, r = Math.min(o.r || 0, o.w / 2, o.d / 2), cl = (w, h, rx, s) => { if (!s) return s; const id = C.u('cf'); return `<clipPath id="${id}"><rect width="${f1(w)}" height="${f1(h)}" rx="${f1(rx)}"/></clipPath><g clip-path="url(#${id})">${s}</g>`; };
    return Object.assign({}, o, { dec: { t: cl(o.w, o.d, r, D.t), f: cl(o.w - 2 * r, o.h, 0, D.f), b: cl(o.w - 2 * r, o.h, 0, D.b), l: cl(o.d - 2 * r, o.h, 0, D.l), r: cl(o.d - 2 * r, o.h, 0, D.r) } }); };
  // KIT-099 AUTO-HEIGHT ADJUSTING HYDRAULIC LEVITATION BAR STOOL (T5): round 44, seat {0, 0, 78} kept, arch barstool. A black-glass disc in a champagne-gold
  // plinth on the floor; the whole stool hovers a hand's width above it on a warm amber beam: a gold hover bell, a fluted gold hydraulic sleeve with a
  // little height readout, a gold collar, a mirror-chrome piston, a gold spider plate and pan, an ivory nappa seat with champagne nailheads and a low
  // curved nappa back capped in gold. The gold foot ring floats on its own round the sleeve. Alive: the beam and the floor glow breathe, a gold halo
  // turns in the hover gap with motes rising through it, gold ticks turn in the glass, the readout's arrows pulse and a glint slides down the sleeve.
  N.lev28 = S => { const CG = '#d6b878', GL = '#141216', IV = '#efe6d6', CH = '#dfe3e6', HB = 10, SL0 = 16, SL1 = 37;
    const D = { w: 44, d: 44, round: 1, arch: 'barstool', act: 'sit', seats: [{ x: 0, z: 0, h: 78 }], build: () => { const { cyl, ball, solid, arcW } = CHK(), o = [], on = glue(o), NT = { mat: 'lea', soft: 1, tex: 'url(#k28nap) none', texTop: 1 };
        o.push(cyl(0, 0, 0, 17, 1.2, CG, { n: 32, mat: 'metal' }), cyl(0, 1.2, 0, 15.8, 2, GL, { n: 32, mat: 'cer' }));
        o.push(solid({ ax: 'y', sh: 'el', c: [0, 0], a: 6.4, b: 6.4, n: 22, rings: [[HB, 0, 0.78], [HB + 0.8, 0, 0.96], [HB + 2.4, 0, 1], [HB + 4.4, 0, 0.8], [SL0, 0, 0.66]], col: CG, mat: 'metal' }));
        o.push(cyl(0, SL0, 0, 3.8, SL1 - SL0, CG, { n: 18, mat: 'metal', rg: [[0, 0, 1.1], [2.4, 0, 1], [SL1 - SL0, 0, 0.94]] }));
        o.push(cyl(0, SL1, 0, 4.5, 1.6, CG, { n: 18, mat: 'metal' }), cyl(0, SL1 + 1.6, 0, 2.3, 60 - SL1 - 1.6, CH, { n: 14, mat: 'metal' }), cyl(0, 60, 0, 4.2, 1.6, CG, { n: 18, mat: 'metal' }));
        o.push(solid({ ax: 'y', sh: 'el', c: [0, 0], a: 9.5, b: 9.5, n: 24, rings: [[61.6, 0, 0.5], [63, 0, 0.86], [64, 0, 1]], col: CG, mat: 'metal' }));
        o.push(solid({ ax: 'y', sh: 'el', c: [0, 0], a: 16.6, b: 16.6, n: 30, rings: [[64, 0, 0.86], [65.4, 0, 1], [67, 0, 1]], col: CG, mat: 'metal' }));
        const SE = solid(Object.assign({ ax: 'y', sh: 'el', c: [0, 0], a: 16.4, b: 16.4, n: 30, rings: [[67, 0, 0.96], [68.4, 0, 1], [75.6, 0, 1], [77.4, 0, 0.9], [78, 0, 0.72]], col: IV }, NT)); o.push(SE);
        on(SE, rep(16, i => { const a = i * PI / 8, c = Math.cos(a), s = Math.sin(a), b = ball(c * 16.45, 69.6, s * 16.45, 0.45, CG, { k: 3, n: 8, noOut: 1 }); b.fn = [c, 0, s]; return b; }));
        [[-44, 44], [46, 134], [136, 224], [226, 314]].forEach(([a0, a1]) => o.push(arcW(0, 25.2, 0, 13.6, 13.6, 1.4, 1.5, a0 * PI / 180, a1 * PI / 180, CG, { n: 10, mat: 'metal' })));
        const wall = (rg, col, mat, ex) => inFirst(solid(Object.assign({ ax: 'y', sh: 'poly', cv: 0, c: [0, 0], pts: sector(16.2, 16.2, 3.6, PI * 1.12, PI * 1.88, 18), rings: rg, col, mat }, ex || {})), 0, 0);
        o.push(wall([[78, 0, 1], [85.6, 0, 1.01], [87.6, 0, 0.99]], IV, 'lea', NT), wall([[87.6, 0, 0.99], [88.8, 0, 0.99]], CG, 'metal'));
        return o; } };
    D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('lev28');
      const defs = `<radialGradient id="k28nap" cx="38%" cy="36%" r="64%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.3">${an('stop-opacity', '0.16;0.34;0.16', 7)}</stop><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.04"/><stop offset="1" stop-color="#6a4a2a" stop-opacity="0.18"/></radialGradient>`
        + `<linearGradient id="k28lvb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe6b0" stop-opacity="0.85"/><stop offset="1" stop-color="#ffb05a" stop-opacity="0.25"/></linearGradient>`;
      const floor = PLN(C, [0, 0.05, 0], [1, 0, 0], [0, 0, 1], `<ellipse rx="28" ry="28" fill="url(#k28amb)" opacity="0.55">${an('opacity', '0.38;0.7;0.38', 4.8)}</ellipse>`);
      // glass top (front half only: the far half sits behind the bell and the foot ring)
      const glass = PLN(C, [0, 3.24, 0], [1, 0, 0], [0, 0, 1], nearHalf(C, 16, `<circle r="15.2" fill="url(#k28amb)" opacity="0.5">${an('opacity', '0.35;0.65;0.35', 4.8)}</circle><g><circle r="12.8" fill="none" stroke="${CG}" stroke-width="0.55" stroke-dasharray="0.45 1.9" opacity="0.95"/>${at('rotate', '0;360', 36)}</g><circle r="15.3" fill="none" stroke="${CG}" stroke-width="0.3" opacity="0.6"/><circle r="8.6" fill="none" stroke="#ffd890" stroke-width="0.35" opacity="0.5"/>`));
      // hover gap: amber beam from the glass to the bell, a turning gold halo, motes drifting up
      const beam = (() => { const a = C.P([0, 3.3, 0]), b = C.P([0, HB + 0.3, 0]), w0 = 6.4 * k, w1 = 4.6 * k; return `<path d="M${f1(a[0] - w0)} ${f1(a[1])}L${f1(b[0] - w1)} ${f1(b[1])}H${f1(b[0] + w1)}L${f1(a[0] + w0)} ${f1(a[1])}Z" fill="url(#k28lvb)" opacity="0.7">${an('opacity', '0.5;0.85;0.5', 2.4)}</path>`; })()
        + PLN(C, [0, 3.26, 0], [1, 0, 0], [0, 0, 1], `<ellipse rx="6.2" ry="6.2" fill="#ffe6b0" opacity="0.55" filter="url(#m10b1)">${an('opacity', '0.35;0.7;0.35', 2.4)}</ellipse>`);
      const halo = PLN(C, [0, 6.6, 0], [1, 0, 0], [0, 0, 1], nearHalf(C, 9, `<g><circle r="7.4" fill="none" stroke="#ffe2a0" stroke-width="0.5" stroke-dasharray="3 1.4" opacity="0.85">${an('opacity', '0.5;0.95;0.5', 2.4)}</circle>${at('rotate', '0;-360', 9)}</g>`));
      const motes = rep(4, i => { const a = i * 1.9, r = 2.6 + (i % 2) * 2, p = C.P([Math.cos(a) * r, 3.6, Math.sin(a) * r]), q = C.P([Math.cos(a) * r * 0.7, HB - 0.4, Math.sin(a) * r * 0.7]);
        return `<circle r="${f1(0.32 * k)}" fill="#fff0c8" opacity="0"><animate attributeName="cx" values="${f1(p[0])};${f1(q[0])}" dur="2.6s" begin="${-i * 0.65}s" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(p[1])};${f1(q[1])}" dur="2.6s" begin="${-i * 0.65}s" repeatCount="indefinite"/>${an('opacity', '0;0.9;0', 2.6, -i * 0.65)}</circle>`; }).join('');
      // height readout on the sleeve (faces the viewer: the stool is round)
      const rd = `<g transform="${tanF(C, 0, 0, 3.95, C.thV, 27)}"><rect x="-2.6" y="-1.5" width="5.2" height="3" rx="1.2" fill="#141216"/><rect x="-2.6" y="-1.5" width="5.2" height="3" rx="1.2" fill="none" stroke="#f4dc9a" stroke-width="0.18"/>`
        + `<text x="0.7" y="0.62" text-anchor="middle" ${FONT} font-size="1.5" fill="#ffc870">78</text><path d="M-1.6 -0.25L-1.15 -0.85L-0.7 -0.25M-1.6 0.25L-1.15 0.85L-0.7 0.25" stroke="#ffc870" stroke-width="0.22" fill="none" stroke-linecap="round">${an('opacity', '1;0.25;1', 1.6)}</path></g>`;
      // nappa top: channel stitching ring + soft sheen; gold nailhead line is solid
      const top = PLN(C, [0, 78.03, 0], [1, 0, 0], [0, 0, 1], `<circle r="9.4" fill="none" stroke="#c9b48e" stroke-width="0.3" stroke-dasharray="0.8 0.55" opacity="0.8"/><circle r="5" fill="none" stroke="#c9b48e" stroke-width="0.25" stroke-dasharray="0.7 0.5" opacity="0.6"/>`
        + rep(8, i => { const a = i * PI / 4; return `<path d="M${f1(Math.cos(a) * 5.4)} ${f1(Math.sin(a) * 5.4)}L${f1(Math.cos(a) * 9)} ${f1(Math.sin(a) * 9)}" stroke="#c9b48e" stroke-width="0.22" stroke-dasharray="0.6 0.45" opacity="0.6"/>`; }).join('') + `<ellipse cx="-3" cy="-3.6" rx="5.4" ry="3" fill="#ffffff" opacity="0.22"/>`);
      const gl = legGlint(C, [[0, 0, SL0 + 1, SL1 - 1, 3.8]], 7);
      C.p(0, 90, 0); C.p(0, 0, 18); C.p(0, 0, -18); C.p(18, 0, 0); C.p(-18, 0, 0);
      return { defs: DEFF + defs, under: floor, front: glass + beam + halo + motes + rd + top + gl, bb: C.bb(4) }; };
    return D; };

  // KIT-003 3-TIER PLASTIC ROLLING UTILITY CART (T1): 60 x 42 kept. Three yellowed off-white molded trays with raised lips on round plastic posts, four grey
  // swivel casters (one wheel swapped for a black one that doesn't match), a push handle on the +x end. Worn: scuffs, grime in the corners, a cracked lip held
  // with clear tape, a half-peeled $9.99 sticker whose corner flutters. Top: a paper towel roll, a ketchup bottle stored upside down on its cap, three
  // speckled bananas and a jar of peanut butter. Middle: canned soup stacked on canned beans, a box of Crunch-O's and two instant noodle cups. Bottom: a
  // bleach jug, a blue spray bottle and a red mesh bag of onions. A white "THANK YOU" grocery bag hangs from the handle and sways.
  N.pcart28 = S => { const TP = '#ece6d4', PT = '#ddd6c2', CA = '#8e9094';
    const D = { w: 60, d: 42, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('pcart28'), PX = 24.6, PZ = 16.4, TW = 54, TD = 38, TH = 4.4, LV = [6, 27.6, 49.2], v0 = C.v[0] > 0;
      const near = (x, z) => x * C.v[0] + z * C.v[2] > 0, PS = [[-PX, -PZ], [PX, -PZ], [-PX, PZ], [PX, PZ]];
      const post = (x, z, y0, y1) => cyl3(C, [x, y0, z], [x, y1, z], 1.5, PT, { mat: 'plastic', n: 14, olw: 0.3, noCap: 1 })
        + cyl3(C, [x, y1 - 1.1, z], [x, y1, z], 2.1, shade(PT, 0.94), { mat: 'plastic', n: 14, olw: 0.25 });
      const caster = (x, z, odd) => { const W = odd ? '#1c1c1e' : '#5a5c60';
        const fk = sx => box3(C, { c: [x + sx * 1.15, 1.6, z], w: 0.4, h: 3.6, d: 2.6, r: 0.1, col: CA, olw: 0.2 });
        const wh = cyl3(C, [x - 0.8, 2.4, z], [x + 0.8, 2.4, z], 2.4, W, { mat: odd ? 'gloss' : 'plastic', n: 18, olw: 0.25, capCol: shade(W, 1.2), cap: cr => `<circle r="${f1(cr * 0.36)}" fill="${CA}"/>` });
        return (v0 ? fk(-1) + wh + fk(1) : fk(1) + wh + fk(-1)) + cyl3(C, [x, 5, z], [x, 6, z], 2.2, CA, { mat: 'plastic', n: 14, olw: 0.2 }); };
      // molded tray: recessed floor with ribs and grime, rolled lip, mould line on the sides
      const ribs = rep(5, i => `<path d="M${f1(8 + i * 9.5)} 4V34" stroke="#ffffff" stroke-opacity="0.35" stroke-width="0.5"/><path d="M${f1(8.5 + i * 9.5)} 4V34" stroke="#8a7e60" stroke-opacity="0.16" stroke-width="0.4"/>`).join('');
      const grime = (k0) => { const r = rng('pcg' + k0); return rep(4, () => `<circle cx="${f1(3 + r() * 48)}" cy="${f1(3 + r() * 32)}" r="${f1(1 + r() * 2.6)}" fill="#a89a70" opacity="${n4(0.1 + r() * 0.12)}" filter="url(#m10b1)"/>`).join('')
        + `<path d="M3 3.4Q3 2.6 4 2.6M51 2.6Q51.8 2.6 51.8 3.6M3 34.6Q3 35.4 4 35.4" stroke="#6a5a3a" stroke-opacity="0.35" stroke-width="0.8" fill="none"/>`; };
      const trayT = k0 => `<rect x="2.4" y="2.4" width="49.2" height="33.2" rx="2.2" fill="${shade(TP, 0.88)}"/><rect x="2.4" y="2.4" width="49.2" height="1.6" fill="#5a4a2a" opacity="0.12"/><rect x="2.4" y="2.4" width="1.4" height="33.2" fill="#5a4a2a" opacity="0.08"/>`
        + ribs + grime(k0) + `<rect x="0.4" y="0.4" width="53.2" height="37.2" rx="2.8" fill="none" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.5"/>` + scr(rng('pcs' + k0), 10, 4, 4, 46, 30, '#7a6e50', 0.3);
      const side = (w, k0) => scr(rng('pcf' + k0), 4, 3, 0.8, w - 8, 3, '#5a5040', 0.35);
      const crack = `<path d="M27 0L28.2 1.6L27.4 2.6L28.4 4.4" stroke="#4a3e28" stroke-width="0.25" fill="none"/><rect x="24.6" y="0.2" width="6" height="3.6" fill="#e8f4f8" opacity="0.32"/><rect x="24.6" y="0.2" width="6" height="3.6" fill="none" stroke="#ffffff" stroke-opacity="0.6" stroke-width="0.15"/><path d="M25 0.8H30.2" stroke="#ffffff" stroke-opacity="0.7" stroke-width="0.2"/>`;
      const stk = `<g transform="translate(9 0.6)"><path d="M0 0H6.2V3.2H0Z" fill="#ffe24a"/><text x="3.1" y="2.3" text-anchor="middle" ${FONT} font-size="1.7" fill="#d8322f">$9.99</text>`
        + `<g><path d="M6.2 0L8.2 0.4L7.4 2.6L6.2 3.2Z" fill="#f2d040"/><path d="M6.2 0L8.2 0.4L7.4 2.6L6.2 3.2Z" fill="#ffffff" opacity="0.25"/>${at('rotate', '0 6.2 1.6;-12 6.2 1.6;3 6.2 1.6;0 6.2 1.6', 3.8, 0, KT('0;0.3;0.55;1'))}</g></g>`;
      const tray = (y, k0) => box3(C, clipF(C, { c: [0, y, 0], w: TW, h: TH, d: TD, r: 3, col: TP, olw: 0.35, olc: '#8a8068', dec: { t: trayT(k0), f: side(TW - 6, k0) + (k0 === 2 ? crack : '') + (k0 === 1 ? stk : ''), b: side(TW - 6, k0 + 3), l: side(TD - 6, k0 + 6), r: side(TD - 6, k0 + 9) } }));
      // items
      const L1 = LV[0] + TH, L2 = LV[1] + TH, L3 = LV[2] + TH;
      const jug = (x, z) => box3(C, { c: [x, L1, z], w: 8.4, h: 12, d: 8.4, r: 1.2, col: '#f4f4f0', olw: 0.3, dec: { f: `<rect x="0.2" y="3.6" width="5.6" height="5.4" rx="0.6" fill="#2a6ac8"/><text x="3" y="6.9" text-anchor="middle" ${FONT} font-size="1.4" fill="#ffffff">BLEACH</text><path d="M0.2 9.6H5.8" stroke="#d8d8d0" stroke-width="0.3"/>` } })
        + cyl3(C, [x + 1.6, L1 + 12, z], [x + 1.6, L1 + 13.6, z], 1.5, '#2a6ac8', { mat: 'gloss', n: 14, olw: 0.25 }) + H2(C, [x - 2.4, L1 + 11.6, z], [x - 2.4, L1 + 8, z], 1.4, '#f4f4f0');
      const spray = (x, z) => cyl3(C, [x, L1, z], [x, L1 + 9, z], 2.1, '#5ab0e8', { mat: 'gloss', n: 16, olw: 0.25, op: 0.85 }) + cyl3(C, [x, L1 + 9, z], [x, L1 + 10.4, z], 1.1, '#f4f4f0', { n: 12, olw: 0.2 })
        + box3(C, { c: [x, L1 + 10.4, z], w: 2.4, h: 2.4, d: 5, r: 0.6, col: '#f4f4f0', olw: 0.25 }) + box3(C, { c: [x, L1 + 8.4, z + 1.8], w: 1, h: 2.2, d: 1, r: 0.3, col: '#d8d8d0', olw: 0.2 });
      const onions = (x, z) => { const B = [[0, 0, 0], [-2.6, 0, 1], [2.6, 0, -0.6], [-1.2, 0, -2.4], [1.4, 0, 2.2], [0, 2.4, 0.2], [-1.4, 2.2, -1], [1.2, 2.3, 1]];
        return vsort(C, B.map(([dx, dy, dz]) => { const q = [x + dx, L1 + 2.2 + dy, z + dz]; return { q, s: sph(C, q, 2.3, '#c88a44') + (() => { const p = C.P(q); return `<path d="M${f1(p[0] - 2 * C.k)} ${f1(p[1] - 1.4 * C.k)}L${f1(p[0] + 2 * C.k)} ${f1(p[1] + 1.4 * C.k)}M${f1(p[0] + 2 * C.k)} ${f1(p[1] - 1.4 * C.k)}L${f1(p[0] - 2 * C.k)} ${f1(p[1] + 1.4 * C.k)}" stroke="#d8302a" stroke-width="${f1(0.28 * C.k)}" opacity="0.85"/>`; })() }; }))
          + H2(C, [x, L1 + 6.4, z], [x + 0.6, L1 + 8.2, z], 0.9, '#e8c02a'); };
      const cans = (x, z) => can3(C, x, L2, z, 2.6, 6.2, 2) + can3(C, x, L2 + 6.7, z, 2.6, 5.4, 0) + can3(C, x + 6, L2, z + 1, 2.6, 6.2, 4);
      const cereal = (x, z) => box3(C, { c: [x, L2, z], w: 11, h: 15, d: 4.2, r: 0.2, col: '#f2a62a', olw: 0.3, dec: { f: `<rect width="10.6" height="15" fill="#f2a62a"/><text x="5.3" y="3.8" text-anchor="middle" ${FONT} font-size="2.2" fill="#c8241e">CRUNCH</text><text x="5.5" y="6.4" text-anchor="middle" ${FONT} font-size="2.2" fill="#2a5ac8">O's</text><ellipse cx="5.5" cy="10.6" rx="3.6" ry="2.4" fill="#ffffff"/><g fill="#e8a83a">${[[4.2, 10], [6, 9.6], [5.4, 11.2], [7, 10.8]].map(([a, b]) => `<circle cx="${a}" cy="${b}" r="0.75"/>`).join('')}</g><path d="M0 14.6H11" stroke="#8a5a1a" stroke-opacity="0.3" stroke-width="0.4"/>`, b: `<rect width="11" height="15" fill="#e89a22"/><rect x="1.4" y="2" width="8.2" height="8" fill="#ffffff" opacity="0.85"/><path d="M2.2 3.4H8.8M2.2 4.8H8.8M2.2 6.2H7" stroke="#8a8a8a" stroke-width="0.3"/>`, t: `<rect width="11" height="4.2" fill="#e09a26"/><path d="M0 2.1H11" stroke="#8a5a1a" stroke-opacity="0.35" stroke-width="0.3"/>` } });
      const noodle = (x, z, ci) => cup(C, x, L2, z, 2.7, 5.2, ci ? '#f4f0e6' : '#fbf6ec', '#e8d8b0', `<rect x="-2" y="-1.2" width="4" height="2.4" fill="${ci ? '#d8322f' : '#2a8a4a'}"/><text x="0" y="0.5" text-anchor="middle" ${FONT} font-size="1.1" fill="#ffffff">RAMEN</text>`);
      const towel = (x, z) => cyl3(C, [x - 8.5, L3 + 4.2, z], [x + 8.5, L3 + 4.2, z], 4.2, '#f6f4ee', { mat: 'matte', n: 22, olw: 0.3, cap: cr => `<circle r="${f1(cr)}" fill="#f2efe6"/><circle r="${f1(cr * 0.36)}" fill="#c8a06a"/><circle r="${f1(cr * 0.28)}" fill="#6a4a2a"/><circle r="${f1(cr * 0.7)}" fill="none" stroke="#e0dccf" stroke-width="0.2"/>` })
        + (() => { const p = C.P([x + 1, L3 + 8.3, z]); return `<g transform="translate(${P2(p)}) scale(${n4(C.k)})">${rep(4, i => `<circle cx="${-6 + i * 4}" cy="0" r="0.5" fill="#e0dccf"/>`).join('')}</g>`; })();
      const ketch = (x, z) => cyl3(C, [x, L3, z], [x, L3 + 1.6, z], 1.5, '#f4f0e6', { n: 14, olw: 0.25 }) + cyl3(C, [x, L3 + 1.6, z], [x, L3 + 3.8, z], 1.2, '#c8302a', { r2: 2.4, mat: 'gloss', n: 16, olw: 0.25, noCap: 1 })
        + cyl3(C, [x, L3 + 3.8, z], [x, L3 + 11, z], 2.4, '#c8302a', { mat: 'gloss', n: 18, olw: 0.3 }) + `<g transform="${tanF(C, x, z, 2.43, C.thV, L3 + 7.6)}"><rect x="-1.9" y="-1.4" width="3.8" height="2.8" fill="#f4f0e6"/><text x="0" y="0.5" text-anchor="middle" ${FONT} font-size="0.85" fill="#c8302a">KETCHUP</text></g>`;
      const nana = (x, z, a, i) => { const c = Math.cos(a), s = Math.sin(a), Q = [-5, -1.8, 1.8, 5].map((u, j) => [x + c * u - s * (j === 1 || j === 2 ? 0.9 : 0), L3 + 1.3, z + s * u + c * (j === 1 || j === 2 ? 0.9 : 0)]);
        let o = ''; for (let j = 0; j < 3; j++) o += cyl3(C, Q[j], Q[j + 1], j === 1 ? 1.35 : 1.15, '#f2d04a', { r2: j === 0 ? 1.35 : j === 2 ? 0.9 : 1.35, mat: 'gloss', n: 14, olw: 0.25, olc: '#a8862a' });
        o += H2(C, Q[3], [Q[3][0] + c * 1.3, L3 + 1.6, Q[3][2] + s * 1.3], 0.6, '#5a4a2a') + H2(C, Q[0], [Q[0][0] - c * 0.6, L3 + 1.3, Q[0][2] - s * 0.6], 0.7, '#3a2a1a');
        const r = rng('nn' + i); return o + rep(5, () => { const q = Q[1 + Math.floor(r() * 2)], p = C.P([q[0] + (r() - 0.5) * 2, L3 + 2.5, q[2] + (r() - 0.5) * 1.2]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1((0.18 + r() * 0.2) * C.k)}" fill="#6a4a1a" opacity="0.8"/>`; }).join(''); };
      const pb = (x, z) => jar(C, x, L3, z, 2.8, 5.6, '#b8803a', '#d8322f', 0.9, `<rect x="-2.2" y="-1.4" width="4.4" height="2.8" fill="#f4e8c8"/><text x="0" y="0.5" text-anchor="middle" ${FONT} font-size="0.95" fill="#8a4a1a">PEANUT</text>`);
      const items1 = vsort(C, [{ q: [-15, L1 + 6, 6], s: jug(-15, 6) }, { q: [1, L1 + 5, 9], s: spray(1, 9) }, { q: [15, L1 + 3, 4], s: onions(15, 4) }]);
      const items2 = vsort(C, [{ q: [-16, L2 + 6, 5], s: cans(-16, 5) }, { q: [2, L2 + 7, -6], s: cereal(2, -6) }, { q: [14, L2 + 3, 9], s: noodle(14, 9, 0) }, { q: [19, L2 + 3, 2], s: noodle(19, 2, 1) }]);
      const items3 = vsort(C, [{ q: [-12, L3 + 4, -8], s: towel(-12, -8) }, { q: [9, L3 + 5, -9], s: ketch(9, -9) }, { q: [-6, L3 + 1.5, 7], s: nana(-6, 7, 0.35, 0) + nana(-5.4, 9, 0.2, 1) + nana(-6.6, 4.8, 0.5, 2) }, { q: [16, L3 + 3, 5], s: pb(16, 5) }]);
      const stain = PLN(C, [9, L3 + 0.04, -9], [1, 0, 0], [0, 0, 1], `<ellipse rx="3.2" ry="2.6" fill="#8a1a14" opacity="0.28"/><ellipse cx="1.4" cy="1.6" rx="1" ry="0.7" fill="#8a1a14" opacity="0.3"/>`);
      // push handle on the +x end + grocery bag
      const HX = PX + 1.2, handle = cyl3(C, [HX, L3, -12], [HX, L3 + 7, -12], 1.2, PT, { n: 12, olw: 0.25 }) + cyl3(C, [HX, L3, 12], [HX, L3 + 7, 12], 1.2, PT, { n: 12, olw: 0.25 }) + cyl3(C, [HX, L3 + 7, -12.6], [HX, L3 + 7, 12.6], 1.25, PT, { n: 12, olw: 0.25 });
      const bagX = `<rect width="12" height="15" fill="#f4f4f0"/><path d="M1.5 2Q3 4 2 7M9 1.6Q10.4 5 9.6 9M4 10Q6 11.4 8 10.2" stroke="#c8c8c0" stroke-width="0.35" fill="none"/><text x="6" y="7.2" text-anchor="middle" ${FONT} font-size="1.7" fill="#d8302a">THANK</text><text x="6" y="9.2" text-anchor="middle" ${FONT} font-size="1.7" fill="#d8302a">YOU</text><path d="M3.2 10.6Q6 12 8.8 10.6" stroke="#d8302a" stroke-width="0.4" fill="none"/><rect width="12" height="15" fill="#ffffff" opacity="0.18"/>`;
      const bF = vis(C, [1, 0, 0]), bagB = `<rect width="12" height="15" fill="#ecece6"/><path d="M1.5 2Q3 4 2 7M9 1.6Q10.4 5 9.6 9" stroke="#c8c8c0" stroke-width="0.35" fill="none"/><text x="6" y="8.2" text-anchor="middle" ${FONT} font-size="1.7" fill="#d8302a" opacity="0.12" transform="translate(12 0) scale(-1 1)">THANK</text>`;
      const bag = PLN(C, [HX + 1.3, L3 + 7.8, 8.8], [0, 0, -1], [0, -1, 0], `<path d="M2.2 0Q3.4 -2.4 4.6 0M7.4 0Q8.6 -2.4 9.8 0" stroke="#e8e8e2" stroke-width="0.9" fill="none"/>` + towS(12, 15, bF ? '#f4f4f0' : '#ecece6', bF ? bagX : bagB, 4.6));
      const endS = handle + bag;
      // assemble: far posts / casters, then per level: tray, far post segments, items, near segments
      const seg = (y0, y1, nr) => PS.filter(([x, z]) => near(x, z) === nr).map(([x, z]) => ({ q: [x, (y0 + y1) / 2, z], s: post(x, z, y0, y1) }));
      const casters = vsort(C, PS.map(([x, z], i) => ({ q: [x, 2, z], s: caster(x, z, i === 1) })));
      let s = shadow(C, 0, 0, 34, 24, 0.7) + (bF ? '' : endS) + casters + tray(LV[0], 0)
        + vsort(C, seg(L1, LV[1], false)) + items1 + vsort(C, seg(L1, LV[1], true)) + tray(LV[1], 1)
        + vsort(C, seg(L2, LV[2], false)) + items2 + vsort(C, seg(L2, LV[2], true)) + tray(LV[2], 2) + stain + items3 + (bF ? endS : '');
      C.p(0, L3 + 14, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-023 WIRE & BAMBOO MICROWAVE STAND (T2): 60 x 42 kept. Matte black powder-coated wire frame (four legs on levelling feet, side and back gallery
  // rails, S-hooks on the -x end) with a carbonised bamboo top and a bamboo slat middle shelf, and a wire-grid bottom shelf. A white microwave with a smoky
  // mesh window, a keypad and a clock that blinks 12:00 (nobody ever set it), a sticky note on the door. Beside it a speckled crock of wooden spoons and a
  // dish of lemons; a pothos on top of the microwave trails its vines down the side and sways. Middle: nested mixing bowls, a jar of pasta and a basket of
  // tea boxes. Bottom: two big water bottles and a twin pack of paper towels. An oven mitt and a striped tea towel hang from the S-hooks and sway.
  N.wire28 = S => { const WR = '#2a2a2c', BM = '#d8b274', BD = '#b8904e';
    const D = { w: 60, d: 42, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('wire28'), LX = 27, LZ = 18, YB = 6.4, YM = 27, YT = 47.6, v0 = C.v[0] > 0;
      const near = (x, z) => x * C.v[0] + z * C.v[2] > 0, LG = [[-LX, -LZ], [LX, -LZ], [-LX, LZ], [LX, LZ]];
      const rod = (a, b, r) => cyl3(C, a, b, r || 0.45, WR, { mat: 'metal', n: 10, olw: 0.2 });
      const leg = (x, z, y0, y1, ft) => (ft ? cyl3(C, [x, 0, z], [x, 1.2, z], 1.6, '#1a1a1c', { n: 12, olw: 0.2 }) : '') + cyl3(C, [x, y0, z], [x, y1, z], 1.05, WR, { mat: 'metal', n: 12, olw: 0.25, noCap: !ft });
      const bam = (w, d, k0) => { const r = rng('bm' + k0); let s = `<rect width="${w}" height="${d}" fill="${BM}"/>`; for (let v = 0; v < d; v += 2.2) { s += `<rect y="${f1(v)}" width="${w}" height="2.2" fill="${shade(BM, 0.92 + r() * 0.14)}"/><path d="M0 ${f1(v)}H${w}" stroke="#8a6230" stroke-opacity="0.35" stroke-width="0.15"/>`;
          for (let u = r() * 9; u < w; u += 7 + r() * 5) s += `<path d="M${f1(u)} ${f1(v + 0.2)}V${f1(v + 2)}" stroke="#8a6230" stroke-opacity="0.5" stroke-width="0.35"/><path d="M${f1(u + 0.4)} ${f1(v + 0.3)}V${f1(v + 1.9)}" stroke="#ffffff" stroke-opacity="0.25" stroke-width="0.2"/>`; }
        return s + `<rect width="${w}" height="${d}" fill="url(#m10s)" opacity="0.25"/>`; };
      const edgeB = w => `<rect width="${w}" height="2.4" fill="${BD}"/>` + rep(Math.floor(w / 2.2), i => `<path d="M${f1(i * 2.2)} 0V2.4" stroke="#6a4a22" stroke-opacity="0.4" stroke-width="0.2"/>`).join('');
      // bottom: wire grid shelf
      const grid = PLN(C, [0, YB + 0.5, 0], [1, 0, 0], [0, 0, 1], `<g stroke="${WR}" stroke-width="0.45">${rep(13, i => `<path d="M${f1(-25 + i * 25 / 6)} -16V16"/>`).join('')}${rep(5, i => `<path d="M-26 ${f1(-14 + i * 7)}H26"/>`).join('')}</g><g stroke="#ffffff" stroke-opacity="0.18" stroke-width="0.15">${rep(13, i => `<path d="M${f1(-25.2 + i * 25 / 6)} -16V16"/>`).join('')}</g>`);
      const frame = y => [rod([-LX + 1, y, -LZ], [LX - 1, y, -LZ], 0.6), rod([-LX + 1, y, LZ], [LX - 1, y, LZ], 0.6), rod([-LX, y, -LZ + 1], [-LX, y, LZ - 1], 0.6), rod([LX, y, -LZ + 1], [LX, y, LZ - 1], 0.6)];
      // middle: bamboo slats on a wire frame + back gallery
      const slats = [-14, -7, 0, 7, 14].map(z => ({ q: [0, YM + 1, z], s: box3(C, clipF(C, { c: [0, YM + 0.6, z], w: 52, h: 1.4, d: 5.6, r: 0.4, col: BM, olw: 0.25, olc: '#8a6230', dec: { t: bam(52, 5.6, z), f: edgeB(51.2), b: edgeB(51.2) } })) }));
      const gal = [rod([-LX + 1, YM + 6, -LZ], [LX - 1, YM + 6, -LZ], 0.45)].concat(rep(7, i => rod([-LX + 4 + i * 7.6, YM + 2, -LZ], [-LX + 4 + i * 7.6, YM + 6, -LZ], 0.35)));
      // top: carbonised bamboo board
      const top = box3(C, clipF(C, { c: [0, YT, 0], w: 58, h: 2.6, d: 40, r: 0.8, col: BM, olw: 0.35, olc: '#7a5428', dec: { t: bam(58, 40, 'top') + `<circle cx="47" cy="30" r="3.4" fill="none" stroke="#7a5428" stroke-opacity="0.2" stroke-width="0.6"/>` + scr(R, 6, 30, 6, 26, 30, '#7a5428', 0.3), f: edgeB(56.4), b: edgeB(56.4), l: edgeB(38.4), r: edgeB(38.4) } }));
      // microwave
      const TY = YT + 2.6, MX = -7, MZ = -3, MW = 32, MH = 17.6, MD = 24;
      const blink = `<rect x="23" y="2.2" width="6.2" height="2.6" rx="0.3" fill="#141a18"/><text x="26.1" y="4.1" text-anchor="middle" ${FONT} font-size="2" fill="#5af07a" letter-spacing="0.1">12:00${an('opacity', '1;1;0;0', 1.2, 0, ' calcMode="discrete" keyTimes="0;0.5;0.5;1"')}</text>`;
      const door = `<rect x="0.6" y="0.6" width="21.6" height="16.4" rx="0.8" fill="#e4e0d8"/><rect x="2.4" y="2.4" width="16" height="12.4" rx="0.8" fill="#1e2224"/><rect x="2.4" y="2.4" width="16" height="12.4" rx="0.8" fill="url(#m10perf)" opacity="0.7"/>`
        + `<path d="M3 3H8L4.4 14.2H3Z" fill="#ffffff" opacity="0.08"/><ellipse cx="10.4" cy="12.6" rx="5.6" ry="1.2" fill="#ffffff" opacity="0.06"/><rect x="19.6" y="2.4" width="1.6" height="12.4" rx="0.6" fill="#cfcac0"/>`
        + `<g transform="translate(4 5.4) rotate(-6)"><path d="M0 0H5.4V4.6Q3 5.4 0 4.8Z" fill="#fff07a"/><text x="2.6" y="2.2" text-anchor="middle" font-family="'Comic Sans MS',cursive" font-size="1.3" fill="#2a4ab8">2 MIN</text><text x="2.6" y="3.8" text-anchor="middle" font-family="'Comic Sans MS',cursive" font-size="1.2" fill="#2a4ab8">STIR!</text></g>`;
      const pad = blink + rep(12, i => `<rect x="${f1(23.2 + (i % 3) * 2)}" y="${f1(6.2 + Math.floor(i / 3) * 1.8)}" width="1.6" height="1.3" rx="0.3" fill="#d8d4cc" stroke="#a8a49c" stroke-width="0.12"/>`).join('') + `<rect x="23" y="13.8" width="6.2" height="2" rx="0.4" fill="#5aa86a"/><text x="26.1" y="15.3" text-anchor="middle" ${FONT} font-size="1.2" fill="#ffffff">START</text>`;
      const vent = w => rep(6, i => `<rect x="${f1(w - 7 + i * 1)}" y="4" width="0.45" height="9" rx="0.2" fill="#9a968e"/>`).join('');
      const mw = box3(C, clipF(C, { c: [MX, TY, MZ], w: MW, h: MH, d: MD, r: 1.4, col: '#f2efe8', olw: 0.35, olc: '#8a8680', dec: { f: door + pad + `<rect x="22.6" y="0.6" width="0.3" height="16.4" fill="#b8b4ac"/>`, r: vent(MD - 2.8), l: vent(MD - 2.8), t: `<rect width="${MW}" height="${MD}" fill="#ffffff" opacity="0.15"/>` + scr(R, 4, 4, 4, 24, 16, '#9a968e', 0.3) } }));
      // pothos on top of the microwave, vines trailing down the +x side of it
      const PX0 = MX + 9, PZ0 = MZ - 4, PY = TY + MH;
      const pot = cyl3(C, [PX0, PY, PZ0], [PX0, PY + 4.4, PZ0], 2.6, '#e8e0d0', { r2: 3.2, mat: 'gloss', n: 18, olw: 0.3, capCol: '#4a3420' });
      const leaf = (q, sc, rot, i) => leafS(C, q, sc, rot, i % 2 ? '#4a9a3a' : '#5aaa48');
      const tuft = vsort(C, [[-1.6, 0], [1.4, 0.6], [0, -1.6], [0.4, 1.6], [-0.6, 0.4]].map(([dx, dz], i) => { const q = [PX0 + dx, PY + 5.6 + (i % 2) * 1.2, PZ0 + dz]; return { q, s: leaf(q, 1.25, (i - 2) * 30, i) }; }));
      const vine = (z0, L, b) => { const a = [MX + MW / 2 + 0.6, PY + 3.6, z0]; let v = H2(C, [PX0 + 2.4, PY + 4, PZ0], a, 0.35, '#4a7a2a'); const pts = rep(L, i => [a[0] + 0.3 + (i % 2) * 0.6, a[1] - 2.6 - i * 2.4, z0 + (i % 2 ? 0.8 : -0.6)]);
        pts.forEach((p, i) => { v += H2(C, i ? pts[i - 1] : a, p, 0.3, '#4a7a2a') + leaf(p, 1.05, i % 2 ? 60 : -60, i); }); return sway(C, a, v, 4, 5.2, b); };
      const plant = pot + tuft, vF = C.v[0] > 0;
      const vines = vine(MZ + 6, 5, 0) + vine(MZ - 2, 4, -1.7);
      // beside the microwave: crock of wooden spoons + dish of lemons
      const CKX = 20, CKZ = 10, crock = cyl3(C, [CKX, TY, CKZ], [CKX, TY + 7.6, CKZ], 3, '#d8d2c4', { mat: 'gloss', n: 18, olw: 0.3, capCol: '#3a2a1a' })
        + `<g transform="${tanF(C, CKX, CKZ, 3.02, C.thV, TY + 4)}">${rep(14, i => `<circle cx="${f1(-2.4 + (i % 7) * 0.8)}" cy="${f1(-1 + Math.floor(i / 7) * 1.6)}" r="0.22" fill="#6a5a48" opacity="0.6"/>`).join('')}</g>`
        + [[-1, -0.6, 11], [0.8, 0.4, 12.4], [0.2, 1, 10]].map(([dx, dz, h], i) => H2(C, [CKX + dx * 0.5, TY + 6, CKZ + dz * 0.5], [CKX + dx * 1.6, TY + h + 2, CKZ + dz * 1.4], 0.7, i === 1 ? '#c8945a' : '#b8844a') + sph(C, [CKX + dx * 1.7, TY + h + 3.2, CKZ + dz * 1.5], 1.3, i === 1 ? '#c8945a' : '#b8844a')).join('');
      const DSZ = -10, dish = cyl3(C, [19, TY, DSZ], [19, TY + 1.8, DSZ], 3.8, '#5a8ab8', { r2: 5.4, mat: 'gloss', n: 24, olw: 0.3, capCol: '#4a7aa8' }) + vsort(C, [[-1.8, 0], [1.8, 0.4], [0, -1.8], [0, 0, 1]].map(([dx, dz, up]) => { const q = [19 + dx, TY + 3 + (up ? 1.6 : 0), DSZ + dz]; return { q, s: sph(C, q, 2, '#f2d03a') }; }));
      // middle shelf things: nested mixing bowls, jar of pasta, basket of tea boxes
      const bowls = cyl3(C, [-15, YM + 2, -4], [-15, YM + 6.4, -4], 4.6, '#f2f0ea', { r2: 7.2, mat: 'gloss', n: 26, olw: 0.3, capCol: '#e8e4dc' }) + cyl3(C, [-15, YM + 4.6, -4], [-15, YM + 7.6, -4], 3.4, '#8ac0a8', { r2: 5.4, mat: 'gloss', n: 24, olw: 0.3, capCol: '#6aa890' }) + cyl3(C, [-15, YM + 6.4, -4], [-15, YM + 8.6, -4], 2.4, '#e8a07a', { r2: 3.8, mat: 'gloss', n: 22, olw: 0.3, capCol: '#d8886a' });
      const pasta = jar(C, 2, YM + 2, -6, 3, 11, '#f0d090', '#b8904e', 0.85) + `<g transform="${tanF(C, 2, -6, 3.05, C.thV, YM + 7)}">${rep(9, i => `<path d="M${f1(-2 + (i % 3) * 1.6)} ${f1(-2.6 + Math.floor(i / 3) * 2)}l0.9 0.5" stroke="#d8a850" stroke-width="0.5" stroke-linecap="round"/>`).join('')}</g>`;
      const tea = box3(C, { c: [15, YM + 2, -3], w: 12, h: 5.4, d: 9, r: 1.2, col: '#b98a4e', olw: 0.3, olc: '#6a4a24', dec: { t: `<rect width="12" height="9" fill="#5a3a18"/>` } })
        + vsort(C, [[-3.4, '#2a7a5a', 'MINT'], [0, '#c8302a', 'CHAI'], [3.4, '#e8b02a', 'CHAMOMILE']].map(([dx, col, t]) => ({ q: [15 + dx, YM + 7, -3], s: box3(C, { c: [15 + dx, YM + 4, -3.4], w: 3, h: 6.4, d: 6, r: 0.2, col, olw: 0.25, dec: { f: `<rect x="0.3" y="1" width="2.4" height="2.2" fill="#ffffff" opacity="0.85"/><text x="1.5" y="2.5" text-anchor="middle" ${FONT} font-size="0.5" fill="${col}">${t}</text>` } }) })));
      // bottom shelf things: two water bottles lying, a twin pack of paper towels
      const wat = z => cyl3(C, [-22, YB + 4.2, z], [-6, YB + 4.2, z], 3.6, '#bfe0f0', { mat: 'gloss', n: 20, op: 0.6, olw: 0.3, olc: '#6a9ab0' }) + cyl3(C, [-6, YB + 4.2, z], [-3, YB + 4.2, z], 3.6, '#bfe0f0', { r2: 1.4, mat: 'gloss', n: 18, op: 0.6, olw: 0.3, olc: '#6a9ab0', noCap: 1 }) + cyl3(C, [-3, YB + 4.2, z], [-1.6, YB + 4.2, z], 1.4, '#2a6ac8', { n: 12, olw: 0.25 })
        + `<g transform="${FR(C, [-15, YB + 4.2, z + 3.62], [1, 0, 0], [0, -1, 0])}"><rect x="-3" y="-2" width="6" height="4" fill="#2a8ad8" opacity="0.85"/><text x="0" y="0.6" text-anchor="middle" ${FONT} font-size="1.3" fill="#ffffff">SPRING</text></g>`;
      const ptw = vsort(C, [-4, 4].map(dz => ({ q: [13, YB + 6, -2 + dz], s: cyl3(C, [13, YB + 0.6, -2 + dz], [13, YB + 12, -2 + dz], 4, '#f8f6f0', { mat: 'matte', n: 20, olw: 0.3, cap: cr => `<circle r="${f1(cr * 0.34)}" fill="#c8a06a"/><circle r="${f1(cr * 0.26)}" fill="#6a4a2a"/>` }) }))) + `<g transform="${FR(C, [13, YB + 7, 6.1], [1, 0, 0], [0, -1, 0])}"><rect x="-3.4" y="-2" width="6.8" height="3.4" fill="#4aa8d8" opacity="0.8"/><text x="0" y="0.4" text-anchor="middle" ${FONT} font-size="1.2" fill="#ffffff">2 ROLLS</text></g>`;
      // S-hooks on the -x end: oven mitt + tea towel
      const HX = -LX - 0.4, hookRail = rod([HX, YT - 3, -LZ + 1], [HX, YT - 3, LZ - 1], 0.5);
      const mittX = `<path d="M1 0H9V7Q11.6 6 12 8.4Q12.2 10.6 9.6 11.6V16Q5 18 0.8 16Z" fill="#c8402e"/><path d="M1 0H9V3H1Z" fill="#f4ece0"/><path d="M1.6 5L8.4 9M1.6 9L8.4 13M1.6 13L6 15.6M3 4.4L8.4 7.4" stroke="#a8301e" stroke-width="0.35" fill="none"/>`;
      const mitt = PLN(C, [HX - 0.6, YT - 4, -5], [0, 0, -1], [0, -1, 0], `<g>${at('rotate', '-3 5 0;3 5 0;-3 5 0', 4.4, 0, SPL(2))}${mittX}</g>`);
      const twX = `<rect width="10" height="16" fill="#f4efe4"/>` + [2, 3.2, 12.4, 13.6].map(y => `<rect y="${y}" width="10" height="0.7" fill="#3a6aa8" opacity="0.85"/>`).join('');
      const towl = PLN(C, [HX - 0.6, YT - 3.6, 12], [0, 0, -1], [0, -1, 0], towS(10, 16, '#f4efe4', twX, 5.6, -1.8));
      const hooks = [-10, 7].map(z => H2(C, [HX, YT - 3, z], [HX - 0.4, YT - 4.4, z], 0.35, '#8a8a8e')).join('');
      const mF = vis(C, [-1, 0, 0]), endS = hookRail + hooks + mitt + towl;
      // assemble
      const segs = (y0, y1, nr) => LG.filter(([x, z]) => near(x, z) === nr).map(([x, z]) => ({ q: [x, (y0 + y1) / 2, z], s: leg(x, z, y0, y1, y0 === 1.2) }));
      const bottom = vsort(C, frame(YB).map((s, i) => ({ q: [[0, 0, -LZ], [0, 0, LZ], [-LX, 0, 0], [LX, 0, 0]][i], s }))) + grid;
      const midFrame = vsort(C, frame(YM).map((s, i) => ({ q: [[0, 0, -LZ], [0, 0, LZ], [-LX, 0, 0], [LX, 0, 0]][i], s })));
      const items1 = vsort(C, [{ q: [-12, YB + 4, -5], s: wat(-5) }, { q: [-12, YB + 4, 4], s: wat(4) }, { q: [13, YB + 6, -2], s: ptw }]);
      const items2 = vsort(C, [{ q: [-15, YM + 5, -4], s: bowls }, { q: [2, YM + 6, -6], s: pasta }, { q: [15, YM + 5, -3], s: tea }]);
      const topItems = vsort(C, [{ q: [MX, TY + 8, MZ], s: (vF ? '' : vines) + mw }, { q: [MX + MW / 2 + 1, TY + 8, MZ + 1], s: vF ? vines : '' }, { q: [CKX, TY + 4, CKZ], s: crock }, { q: [19, TY + 2, DSZ], s: dish }]);
      let s = shadow(C, 0, 0, 34, 24, 0.7) + (mF ? '' : endS) + vsort(C, segs(1.2, YB, false)) + bottom + vsort(C, segs(YB, YM, false)) + items1 + vsort(C, segs(1.2, YB, true)) + vsort(C, segs(YB, YM, true))
        + midFrame + vsort(C, slats) + (C.v[2] > 0 ? gal.join('') : '') + vsort(C, segs(YM, YT, false)) + items2 + (C.v[2] > 0 ? '' : gal.join('')) + vsort(C, segs(YM, YT, true)) + top + topItems + plant + (mF ? endS : '');
      C.p(0, PY + 9, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // ---------- batch 12: utility carts KIT-043 brass + glass bar cart, KIT-063 marble pastry slab + copper pan rack, KIT-083 robot sous-chef cart ----------
  // KIT-043 VINTAGE BRASS & GLASS TEA / BAR CART (T3): 60 x 42 kept. Polished brass tube frame with two tempered-glass shelves in brass rails, a low gallery
  // rail round the top, two big spoked brass wheels on the -x end, brass ball feet on the +x end and a curved push handle over them. Top: a cut-crystal decanter
  // of whisky, two tumblers (one with ice), a hammered cocktail shaker, a G&T with a lime wedge and rising bubbles, a bowl of lemons and limes, a bud vase
  // of pink ranunculus. Lower shelf (seen through the glass): gin, a bottle of red, a brass ice bucket with tongs and a stack of linen napkins.
  // Alive: bubbles rise in the G&T, a glint slides across each glass shelf, the ranunculus nods.
  N.bar28 = S => { const BR = '#c9a256', GLC = '#d8eef0';
    const D = { w: 60, d: 42, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('bar28'), PX = 25, PZ = 16.5, Y1 = 18, Y2 = 52, near = (x, z) => x * C.v[0] + z * C.v[2] > 0, PS = [[-PX, -PZ], [PX, -PZ], [-PX, PZ], [PX, PZ]];
      const tube = (a, b, r) => cyl3(C, a, b, r || 0.8, BR, { mat: 'chrome', n: 12, olw: 0.22 });
      const post = (x, z, y0, y1) => tube([x, y0, z], [x, y1, z], 0.95) + (y1 === Y2 ? sph(C, [x, Y2 + 4.6, z], 1.3, BR) + tube([x, Y2, z], [x, Y2 + 3.6, z], 0.7) : '');
      const rails = y => [[[-PX, y, -PZ], [PX, y, -PZ]], [[-PX, y, PZ], [PX, y, PZ]], [[-PX, y, -PZ], [-PX, y, PZ]], [[PX, y, -PZ], [PX, y, PZ]]].map(([a, b]) => ({ q: [(a[0] + b[0]) / 2, y, (a[2] + b[2]) / 2], s: tube(a, b, 0.75) }));
      const glass = (y, k0) => box3(C, { c: [0, y + 0.1, 0], w: 2 * PX - 1, h: 0.9, d: 2 * PZ - 1, r: 0.6, col: GLC, op: 0.32, olw: 0.25, olc: '#7aa8a8', dec: { t: glintT(C, 2 * PX - 1, 2 * PZ - 1, 7 + k0, 3) + `<rect x="0.4" y="0.4" width="${2 * PX - 1.8}" height="${2 * PZ - 1.8}" fill="none" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.3"/>`, f: `<rect width="${2 * PX - 2.2}" height="0.9" fill="#5aa89a" opacity="0.5"/>`, b: `<rect width="${2 * PX - 2.2}" height="0.9" fill="#5aa89a" opacity="0.5"/>`, l: `<rect width="${2 * PZ - 2.2}" height="0.9" fill="#5aa89a" opacity="0.5"/>`, r: `<rect width="${2 * PZ - 2.2}" height="0.9" fill="#5aa89a" opacity="0.5"/>` } });
      // spoked wheels (-x end, outside the frame), ball feet (+x end)
      const wheel = z => { const sg = z > 0 ? 1 : -1, W = (dz, op) => PLN(C, [-PX, 9.4, z + dz], [1, 0, 0], [0, -1, 0], `<circle r="9" fill="none" stroke="${shade(BR, 0.7)}" stroke-width="1.6" opacity="${op}"/>`), F = PLN(C, [-PX, 9.4, z + sg * 0.5], [1, 0, 0], [0, -1, 0], `<circle r="9" fill="none" stroke="url(#k28brs)" stroke-width="1.5"/><circle r="9.6" fill="none" stroke="#2a2420" stroke-width="0.5"/><g>${rep(8, i => { const a = i * PI / 4; return `<path d="M${f1(Math.cos(a) * 1.4)} ${f1(Math.sin(a) * 1.4)}L${f1(Math.cos(a) * 8.3)} ${f1(Math.sin(a) * 8.3)}" stroke="url(#k28brs)" stroke-width="0.6"/>`; }).join('')}</g><circle r="1.8" fill="url(#k28brs)"/><circle r="0.7" fill="#7a5a22"/>`);
        return W(-sg * 0.5, 0.9) + F; };
      const wheels = [-PZ - 3, PZ + 3].map(z => ({ q: [-PX, 9.4, z], s: wheel(z) })), axle = tube([-PX, 9.4, -PZ - 2.6], [-PX, 9.4, PZ + 2.6], 0.55);
      const feet = [-PZ, PZ].map(z => ({ q: [PX, 2, z], s: sph(C, [PX, 1.5, z], 1.5, BR) + tube([PX, 3, z], [PX, Y1, z], 0.95) }));
      const legsW = [-PZ, PZ].map(z => ({ q: [-PX, 6, z], s: tube([-PX, 9.4, z], [-PX, Y1, z], 0.95) }));
      // push handle over the +x end
      const HX = PX + 5, handle = [-PZ + 2, PZ - 2].map(z => tube([PX, Y2 + 3, z], [HX, Y2 + 6, z], 0.7)).join('') + tube([HX, Y2 + 6, -PZ + 1.4], [HX, Y2 + 6, PZ - 1.4], 0.85) + [-PZ + 1, PZ - 1].map(z => sph(C, [HX, Y2 + 6, z], 1.2, BR)).join('');
      const gal = [[[-PX + 1, Y2 + 3.6, -PZ], [PX - 1, Y2 + 3.6, -PZ]], [[-PX + 1, Y2 + 3.6, PZ], [PX - 1, Y2 + 3.6, PZ]]].map(([a, b]) => ({ q: [0, Y2 + 3, a[2]], s: tube(a, b, 0.5) }));
      // lower shelf things
      const L1 = Y1 + 1;
      const gin = bottle(C, -15, L1, -4, 2.6, 15, '#d6eef0', '#2a4a6a', { op: 0.55, mat: 'chrome', lbl: `<rect x="-2.2" y="-2" width="4.4" height="4" fill="#f4f0e4"/><text x="0" y="0.2" text-anchor="middle" font-family="Georgia,serif" font-size="1.1" fill="#2a4a6a">GIN</text><path d="M-1.4 1.2H1.4" stroke="#2a4a6a" stroke-width="0.2"/>` });
      const red = bottle(C, -8, L1, 6, 2.3, 16, '#3a1a20', '#7a1a20', { lbl: `<rect x="-1.9" y="-1.6" width="3.8" height="3.4" fill="#f2ead8"/><text x="0" y="0.4" text-anchor="middle" font-family="Georgia,serif" font-size="0.8" fill="#5a1a1a">ROUGE</text>` });
      const buck = cyl3(C, [8, L1, -3], [8, L1 + 8, -3], 3.6, BR, { r2: 4.2, mat: 'chrome', n: 22, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.92)}" fill="#5a4a2a"/>` + rep(5, i => `<rect x="${f1(-2.6 + (i % 3) * 1.8)}" y="${f1(-1.6 + Math.floor(i / 3) * 1.8)}" width="1.6" height="1.4" rx="0.3" fill="#eaf6fa" opacity="0.85"/>`).join('') })
        + H2(C, [9.6, L1 + 8.6, -3], [11.6, L1 + 12, -3.4], 0.4, BR);
      const nap = box3(C, { c: [17, L1, 6], w: 9, h: 3.4, d: 9, r: 0.6, col: '#ece6da', olw: 0.25, dec: { f: rep(4, i => `<path d="M0 ${f1(0.8 + i * 0.8)}H7.8" stroke="#c8c0b0" stroke-width="0.2"/>`).join(''), l: rep(4, i => `<path d="M0 ${f1(0.8 + i * 0.8)}H7.8" stroke="#c8c0b0" stroke-width="0.2"/>`).join('') } });
      const lowI = vsort(C, [{ q: [-15, L1 + 6, -4], s: gin }, { q: [-8, L1 + 6, 6], s: red }, { q: [8, L1 + 4, -3], s: buck }, { q: [17, L1 + 2, 6], s: nap }]);
      // top things
      const T = Y2 + 1;
      const dec = cyl3(C, [-14, T, -5], [-14, T + 6.4, -5], 3.4, '#e8f2f2', { mat: 'chrome', n: 8, op: 0.45, olw: 0.3, olc: '#8aa4aa', noCap: 1 }) + cyl3(C, [-14, T + 0.4, -5], [-14, T + 4.4, -5], 3.1, '#b8641e', { mat: 'gloss', n: 8, op: 0.85, olw: 0, capCol: '#c8742a' })
        + cyl3(C, [-14, T + 6.4, -5], [-14, T + 9, -5], 3.4, '#e8f2f2', { r2: 1.1, mat: 'chrome', n: 8, op: 0.45, olw: 0.3, olc: '#8aa4aa', noCap: 1 }) + sph(C, [-14, T + 10.6, -5], 1.8, '#eef6f6', { op: 0.7 });
      const tumb = (x, z, ice) => cyl3(C, [x, T, z], [x, T + 3.8, z], 1.9, '#eef6f6', { mat: 'chrome', n: 8, op: 0.4, olw: 0.25, olc: '#8aa4aa', capCol: '#f4fafa' }) + cyl3(C, [x, T + 0.4, z], [x, T + 1.8, z], 1.7, '#c8742a', { mat: 'gloss', n: 8, op: 0.8, olw: 0 })
        + (ice ? box3(C, { c: [x - 0.3, T + 1.6, z], w: 1.6, h: 1.4, d: 1.6, r: 0.3, col: '#eaf6fa', op: 0.85, olw: 0.15, olc: '#9ac4d0' }) : '');
      const shaker = cyl3(C, [-4, T, -9], [-4, T + 7.6, -9], 2.4, '#d8dde0', { r2: 2.1, mat: 'chrome', n: 18, olw: 0.25, noCap: 1 }) + cyl3(C, [-4, T + 7.6, -9], [-4, T + 9.6, -9], 2.1, '#d8dde0', { r2: 0.9, mat: 'chrome', n: 18, olw: 0.25, noCap: 1 }) + cyl3(C, [-4, T + 9.6, -9], [-4, T + 10.8, -9], 0.9, BR, { mat: 'chrome', n: 12, olw: 0.2 })
        + `<g transform="${tanF(C, -4, -9, 2.3, C.thV, T + 4)}">${rep(10, i => `<circle cx="${f1(-1.6 + (i % 5) * 0.8)}" cy="${f1(-1.2 + Math.floor(i / 5) * 2)}" r="0.32" fill="#ffffff" opacity="0.35"/>`).join('')}</g>`;
      const gt = (() => { const x = 3, z = 5, b = cyl3(C, [x, T, z], [x, T + 6.4, z], 1.8, '#eef8f6', { mat: 'chrome', n: 8, op: 0.35, olw: 0.25, olc: '#8aa4aa', capCol: '#f6fcfa' }) + cyl3(C, [x, T + 0.3, z], [x, T + 5.2, z], 1.6, '#dff4ea', { mat: 'gloss', n: 8, op: 0.5, olw: 0, capCol: '#e8f8f0' });
        const lime = (() => { const p = C.P([x + 1.4, T + 6.2, z]); return `<g transform="translate(${P2(p)}) scale(${n4(C.k)})"><path d="M-1.6 0A1.6 1.6 0 0 1 1.6 0Z" fill="#7ac040" stroke="#4a8a2a" stroke-width="0.2"/><path d="M-1.2 -0.1A1.2 1.2 0 0 1 1.2 -0.1Z" fill="#d8f0a0"/></g>`; })();
        return b + rep(4, i => bub1(C, [x + (i - 1.5) * 0.6, T + 0.6, z], [x + (i - 1.5) * 0.5, T + 5, z], 0.2, 2.2, (i * 0.21) % 0.7)).join('') + lime; })();
      const bowl = cyl3(C, [13, T, -6], [13, T + 2.4, -6], 3.6, '#f4f0e8', { r2: 5, mat: 'gloss', n: 24, olw: 0.3, capCol: '#e8e2d6' }) + vsort(C, [[-1.8, 0, '#f2d03a'], [1.8, 0.4, '#7ac040'], [0, -1.8, '#f2d03a'], [0, 1.6, '#7ac040'], [0, 0, '#f2d03a', 1]].map(([dx, dz, c, up]) => { const q = [13 + dx, T + 3.6 + (up ? 1.6 : 0), -6 + dz]; return { q, s: sph(C, q, 2, c) }; }));
      const vase = (() => { const x = 17, z = 6, v = cyl3(C, [x, T, z], [x, T + 5, z], 1.4, '#eef6f6', { r2: 0.8, mat: 'chrome', n: 14, op: 0.45, olw: 0.25, olc: '#8aa4aa' }), st = H2(C, [x, T + 4.6, z], [x + 0.6, T + 11, z], 0.3, '#5a8a3a') + H2(C, [x, T + 4.6, z], [x - 1.4, T + 9.6, z], 0.3, '#5a8a3a');
        const fl = (q, s) => { const p = C.P(q); return `<g transform="translate(${P2(p)}) scale(${n4(C.k * s)})">${rep(5, i => `<circle cx="${f1(Math.cos(i * 1.26) * 0.9)}" cy="${f1(Math.sin(i * 1.26) * 0.7)}" r="1.1" fill="${i % 2 ? '#f49ab0' : '#f8b8c8'}"/>`).join('')}<circle r="0.7" fill="#e8768e"/></g>`; };
        return v + sway(C, [x, T + 4.6, z], st + fl([x + 0.6, T + 11.2, z], 1) + fl([x - 1.4, T + 9.8, z], 0.8), 2.4, 5.2) ; })();
      const topI = vsort(C, [{ q: [-14, T + 5, -5], s: dec }, { q: [-8, T + 2, 3], s: tumb(-8, 3, 1) }, { q: [-11, T + 2, 8], s: tumb(-11, 8, 0) }, { q: [-4, T + 5, -9], s: shaker }, { q: [3, T + 3, 5], s: gt }, { q: [13, T + 2, -6], s: bowl }, { q: [17, T + 4, 6], s: vase }]);
      const vF = vis(C, [1, 0, 0]), endH = handle;
      const seg = (y0, y1, nr) => PS.filter(([x, z]) => near(x, z) === nr && x > 0).map(([x, z]) => ({ q: [x, (y0 + y1) / 2, z], s: post(x, z, y0, y1) })).concat(PS.filter(([x, z]) => near(x, z) === nr && x < 0).map(([x, z]) => ({ q: [x, (y0 + y1) / 2, z], s: post(x, z, y0, y1) })));
      const r1s = rails(Y1), r2s = rails(Y2), farR = L => L.filter(o => !near(o.q[0], o.q[2])), nearR = L => L.filter(o => near(o.q[0], o.q[2]));
      let s = shadow(C, 0, 0, 34, 24, 0.6) + (vF ? '' : endH) + vsort(C, wheels.filter(o => !near(o.q[0], o.q[2]))) + vsort(C, feet.concat(legsW).filter(o => !near(o.q[0], o.q[2]))) + axle
        + vsort(C, farR(r1s)) + vsort(C, seg(Y1, Y2, false)) + lowI + glass(Y1, 0) + vsort(C, nearR(r1s)) + vsort(C, feet.concat(legsW).filter(o => near(o.q[0], o.q[2])))
        + vsort(C, seg(Y1, Y2, true)) + vsort(C, farR(r2s)) + vsort(C, gal.filter(o => !near(0, o.q[2]))) + topI + glass(Y2, 1) + vsort(C, nearR(r2s)) + vsort(C, gal.filter(o => near(0, o.q[2])))
        + vsort(C, wheels.filter(o => near(o.q[0], o.q[2]))) + (vF ? endH : '');
      C.p(0, Y2 + 14, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-063 MARBLE-TOP PASTRY SLAB & COPPER PAN RACK (T4): 60 x 42 kept, top y 62. An oiled walnut baker's cart (tapered legs on brass casters, a slatted
  // lower shelf) under a thick honed Calacatta pastry slab with an eased edge. Two polished brass uprights rise from the back corners to a brass rail with
  // S-hooks: a copper saucepan, a sauté pan and a little butter warmer hang from it and sway, glints sliding round them. On the marble: a laminated dough
  // block dusted with flour, a brass-handled French rolling pin, a bench scraper, a tray of golden croissants that steam, a jar of flour with a brass scoop
  // and a stoneware jug of lavender. Below: a linen-lined basket of flour sacks and a stack of copper-bottomed baking tins. Flour motes drift over the slab.
  N.pastry28 = S => { const WN = '#6b4226', BR = '#c9a256', CU = '#c8703a', MB = '#f4f1ec', TY = 62;
    const D = { w: 60, d: 42, topH: TY, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('pastry28'), LX = 25, LZ = 16.5, SY = 14, near = (x, z) => x * C.v[0] + z * C.v[2] > 0, LG = [[-LX, -LZ], [LX, -LZ], [-LX, LZ], [LX, LZ]];
      const gr = (w, h, k) => grainV(rng('p63' + k), w, h, 4, '#3a2210', '#9a6a40');
      const caster = (x, z) => cyl3(C, [x, 3.4, z], [x, 4.6, z], 1.8, BR, { mat: 'chrome', n: 14, olw: 0.2 }) + cyl3(C, [x - 0.7, 1.9, z], [x + 0.7, 1.9, z], 1.9, '#2a2420', { mat: 'gloss', n: 16, olw: 0.2, capCol: '#4a4038', cap: cr => `<circle r="${f1(cr * 0.4)}" fill="${BR}"/>` });
      const leg = (x, z, i) => caster(x, z) + box3(C, { c: [x, 4.6, z], w: 3.2, h: TY - 5 - 4.6, d: 3.2, r: 0.4, col: WN, olw: 0.3, dec: { f: gr(2.4, 52, i), b: gr(2.4, 52, i + 4), l: gr(2.4, 52, i + 8), r: gr(2.4, 52, i + 12) } });
      // lower slatted shelf
      const slats = [-12, -6, 0, 6, 12].map(z => ({ q: [0, SY, z], s: box3(C, clipF(C, { c: [0, SY - 1.4, z], w: 47, h: 1.4, d: 4.8, r: 0.3, col: shade(WN, 0.96 + R() * 0.08), olw: 0.25, dec: { t: grainH(rng('ps' + z), 47, 4.8, 4, '#2a1608') } })) }));
      const srails = [-LZ, LZ].map(z => ({ q: [0, SY - 1.5, z], s: box3(C, clipF(C, { c: [0, SY - 3.2, z], w: 47, h: 3.2, d: 1.6, r: 0.2, col: WN, olw: 0.25, dec: { f: gr(46.6, 3.2, z), b: gr(46.6, 3.2, z + 1) } })) }));
      const sack = (x, z, t, c) => box3(C, clipF(C, { c: [x, SY, z], w: 7, h: 9, d: 5, r: 1.8, col: '#ece2cc', olw: 0.3, olc: '#9a8a6a', dec: { f: `<rect x="0.6" y="2.6" width="2.2" height="3" fill="${c}" opacity="0.85"/><text x="1.7" y="4.6" text-anchor="middle" font-family="Georgia,serif" font-size="0.9" fill="#ffffff">${t}</text><path d="M0 1H3.4" stroke="#b8a888" stroke-width="0.3"/>` } }));
      const basket = box3(C, clipF(C, { c: [-11, SY, 0], w: 20, h: 6, d: 15, r: 2, col: '#b98a4e', olw: 0.3, olc: '#6a4a24', dec: { t: `<rect width="20" height="15" fill="#f2ece0"/><rect x="1.4" y="1.4" width="17.2" height="12.2" rx="1.4" fill="#5a3a18" opacity="0.35"/>`, f: rep(4, r => rep(8, c => `<rect x="${f1(c * 2 + (r % 2))}" y="${f1(r * 1.5)}" width="1.6" height="1.2" rx="0.5" fill="#d8a868" opacity="0.6"/>`).join('')).join('') } }));
      const sacks = vsort(C, [{ q: [-15, SY + 9, -2], s: sack(-15, -2, 'FARINE', '#2a4a8a') }, { q: [-7, SY + 9, 2], s: sack(-7, 2, 'T55', '#8a2a2a') }]);
      const tins = rep(3, i => cyl3(C, [11, SY + i * 2.2, -1], [11, SY + i * 2.2 + 2, -1], 7 - i * 0.6, i % 2 ? '#c8cdd0' : '#b8bec2', { mat: 'chrome', n: 24, olw: 0.25, capCol: i === 2 ? '#8a9095' : undefined })).join('') + cyl3(C, [11, SY - 0.2, -1], [11, SY + 0.4, -1], 7.1, CU, { mat: 'chrome', n: 24, olw: 0.2, noCap: 1 });
      const shelf = vsort(C, srails.concat(slats)) + vsort(C, [{ q: [-11, SY + 3, 0], s: basket + sacks }, { q: [11, SY + 3, -1], s: tins }]);
      // apron + marble slab
      const apron = box3(C, clipF(C, { c: [0, TY - 9, 0], w: 47, h: 4, d: 30, r: 0.3, col: WN, olw: 0.3, dec: { f: gr(46.4, 4, 40), b: gr(46.4, 4, 41), l: gr(29.4, 4, 42), r: gr(29.4, 4, 43) } }));
      const mbT = `<rect width="60" height="42" fill="${MB}"/>` + veins(rng('mb63'), 60, 42) + `<rect width="60" height="42" fill="url(#m10s)" opacity="0.18"/>`;
      const slab = box3(C, clipF(C, { c: [0, TY - 5, 0], w: 60, h: 5, d: 42, r: 1.6, col: MB, olw: 0.4, olc: '#9a948a', dec: { t: mbT, f: veins(rng('mbf'), 56.8, 5), b: veins(rng('mbb'), 56.8, 5), l: veins(rng('mbl'), 38.8, 5), r: veins(rng('mbr'), 38.8, 5) } }));
      // brass uprights + rail + hanging copper pans (back edge, -z)
      const UZ = -LZ - 2, UY = TY + 34, up = [-LX, LX].map(x => cyl3(C, [x, TY, UZ], [x, UY, UZ], 0.95, BR, { mat: 'chrome', n: 12, olw: 0.22 }) + sph(C, [x, UY + 1.2, UZ], 1.4, BR)).join('') + cyl3(C, [-LX, UY - 1.6, UZ], [LX, UY - 1.6, UZ], 0.8, BR, { mat: 'chrome', n: 12, olw: 0.22 });
      const pan = (x, r, dep, hl, b, kind) => { const hy = UY - 1.6, top = hy - 1.6 - hl, cy = top - r, hook = H2(C, [x, hy + 0.8, UZ], [x, hy - 1.6, UZ], 0.35, '#8a8a8e');
        const body = cyl3(C, [x, cy, UZ - dep / 2], [x, cy, UZ + dep / 2], r, CU, { mat: 'chrome', n: 26, olw: 0.3, olc: '#6a3a1a', cap: cr => `<circle r="${f1(cr * 0.82)}" fill="${C.v[2] > 0 ? shade(CU, 1.15) : '#d8d0c4'}"/><circle r="${f1(cr * 0.82)}" fill="none" stroke="#8a4a22" stroke-width="0.3"/><ellipse cx="${f1(-cr * 0.35)}" cy="${f1(-cr * 0.35)}" rx="${f1(cr * 0.3)}" ry="${f1(cr * 0.15)}" fill="#ffffff" opacity="0.35"/>` })
          + cyl3(C, [x, cy + r, UZ], [x, top + 0.4, UZ], kind ? 0.7 : 0.55, kind ? BR : '#9a9ea2', { mat: 'chrome', n: 10, olw: 0.2 }) + `<circle cx="${f1(C.P([x, top + 0.6, UZ])[0])}" cy="${f1(C.P([x, top + 0.6, UZ])[1])}" r="${f1(0.8 * C.k)}" fill="none" stroke="${BR}" stroke-width="${f1(0.35 * C.k)}"/>`;
        const gl = (() => { const p = C.P([x, cy, UZ + dep / 2 + 0.05]), rr = r * C.k * 0.92; return `<path d="M${f1(p[0] - rr)} ${f1(p[1])}A${f1(rr)} ${f1(rr)} 0 0 1 ${f1(p[0])} ${f1(p[1] - rr)}" stroke="#fff4d8" stroke-width="${f1(0.5 * C.k)}" fill="none" stroke-linecap="round" stroke-dasharray="${f1(rr * 0.5)} ${f1(rr * 6)}" opacity="0.8">${an('stroke-dashoffset', `${f1(rr * 0.5)};${f1(rr * 0.5)};${f1(-rr * 2)};${f1(-rr * 2)}`, 6, b, KT('0;0.5;0.8;1'))}</path>`; })();
        return hook + sway(C, [x, hy - 1.6, UZ], body + gl, 2.2, 4.6 + b * 0.3, -b); };
      const pans = [pan(-14, 6.6, 3.2, 3.6, 0, 1), pan(0, 5, 3, 5.4, 1.3, 0), pan(13, 3.6, 2.6, 7.6, 2.4, 1)].join('');
      const rack = up + pans;
      // marble things
      const T = TY;
      const dough = box3(C, { c: [-10, T, 4], w: 14, h: 2.2, d: 10, r: 1.6, col: '#f2e2bc', olw: 0.3, olc: '#c8a878', dec: { t: `<rect width="14" height="10" fill="#f4e6c6"/>` + specks(rng('dgh'), 40, 14, 10, ['#ffffff', '#fbf6ec'], 0.15, 0.45, 0.9) } })
        + PLN(C, [-10, T + 0.04, 4], [1, 0, 0], [0, 0, 1], `<g transform="translate(-10 -7)">${specks(rng('fl63'), 46, 22, 14, ['#ffffff'], 0.15, 0.5, 0.7)}</g>`);
      const pin = cyl3(C, [-20, T + 4.4, 12], [2, T + 4.4, 9], 1.6, '#e0b884', { r2: 1.6, mat: 'matte', n: 18, olw: 0.3 }) + cyl3(C, [-23, T + 4.4, 12.4], [-20, T + 4.4, 12], 0.7, BR, { mat: 'chrome', n: 10, olw: 0.2 }) + cyl3(C, [2, T + 4.4, 9], [5, T + 4.4, 8.6], 0.7, BR, { mat: 'chrome', n: 10, olw: 0.2 });
      const scraper = box3(C, { c: [4, T, 13], w: 9, h: 0.3, d: 5, r: 0.4, col: '#d8dde0', olw: 0.2 }) + box3(C, { c: [4, T + 0.3, 11], w: 9, h: 1.8, d: 1.6, r: 0.6, col: WN, olw: 0.2 });
      const tray = box3(C, { c: [10, T, -7], w: 18, h: 1, d: 12, r: 0.8, col: '#2a2826', olw: 0.25, dec: { t: `<rect width="18" height="12" fill="#3a3632"/><rect width="18" height="12" fill="url(#m10s)" opacity="0.2"/>` } });
      const croi = (x, z, a) => { const p = C.P([x, T + 2, z]); return `<g transform="translate(${P2(p)}) rotate(${a}) scale(${n4(C.k)})"><path d="M-4.2 0.8Q-3 -2.6 0 -2.8Q3 -2.6 4.2 0.8Q2 0 0 0.4Q-2 0 -4.2 0.8Z" fill="#d89a4a" stroke="#8a5420" stroke-width="0.3"/><path d="M-2.2 -1.8Q-1.4 0 -1.6 0.3M0 -2.6V0.3M2.2 -1.8Q1.4 0 1.6 0.3" stroke="#8a5420" stroke-width="0.35" fill="none"/><path d="M-3 -0.6Q-1.6 -2 0 -2.2" stroke="#f8d8a0" stroke-width="0.45" fill="none" opacity="0.8"/></g>`; };
      const croissants = croi(6, -9, -8) + croi(13, -8, 10) + croi(7, -4, 4) + croi(14, -4, -6) + puff1(C, [9, T + 4, -7], 0.6, 5, 0.1, 0.7, 0) + puff1(C, [13, T + 4, -5], 0.5, 5, 0.1, 0.7, -2.4);
      const fjar = jar(C, 22, T, -9, 3.2, 9, '#fbf8f2', BR, 0.8) + H2(C, [22.6, T + 7, -9], [24.4, T + 12, -9.6], 0.6, BR);
      const jug = (() => { const x = 21, z = 9, j = cyl3(C, [x, T, z], [x, T + 6.6, z], 2.6, '#8aa0b0', { r2: 2.1, mat: 'gloss', n: 18, olw: 0.3, capCol: '#4a3a2a' }), st = rep(5, i => { const a = -0.5 + i * 0.25, q = [x + Math.sin(a) * 4, T + 13.4 + (i % 2) * 1.4, z]; return H2(C, [x + Math.sin(a) * 0.6, T + 6.2, z], q, 0.25, '#7a9a6a') + rep(4, k => sph(C, [q[0] - Math.sin(a) * k * 0.9, q[1] - k * 1.2, z], 0.55, k % 2 ? '#8a6ac8' : '#9a7ad8')).join(''); }).join('');
        return j + sway(C, [x, T + 6.2, z], st, 2, 5.4); })();
      const motes = rep(6, i => { const p = C.P([-16 + i * 6, T + 1, 4 - (i % 3) * 4]), q = C.P([-14 + i * 6, T + 9, 2 - (i % 3) * 4]); return `<circle r="${f1(0.28 * C.k)}" fill="#ffffff" opacity="0"><animate attributeName="cx" values="${f1(p[0])};${f1(q[0])}" dur="6s" begin="${-i}s" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(p[1])};${f1(q[1])}" dur="6s" begin="${-i}s" repeatCount="indefinite"/>${an('opacity', '0;0.8;0', 6, -i)}</circle>`; }).join('');
      const items = vsort(C, [{ q: [-10, T + 1, 4], s: dough }, { q: [-9, T + 4, 11], s: pin }, { q: [4, T + 1, 12], s: scraper }, { q: [10, T + 1, -7], s: tray + croissants }, { q: [22, T + 5, -9], s: fjar }, { q: [21, T + 4, 9], s: jug }]);
      const legsF = vsort(C, LG.filter(([x, z]) => !near(x, z)).map(([x, z], i) => ({ q: [x, 20, z], s: leg(x, z, i) }))), legsN = vsort(C, LG.filter(([x, z]) => near(x, z)).map(([x, z], i) => ({ q: [x, 20, z], s: leg(x, z, i + 2) })));
      const rF = C.v[2] > 0;
      let s = shadow(C, 0, 0, 34, 24, 0.7) + legsF + shelf + apron + legsN + slab + (rF ? rack + items : items + rack) + motes;
      C.p(0, UY + 3, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-083 AUTONOMOUS ROBOTIC SOUS-CHEF DELIVERY CART (T5): 56 x 42 kept, still roams (rolls back and forth delivering). A polished ivory ceramic body with
  // champagne-gold trims floating on a recessed dark base over a warm amber glow line: a rounded lower cabinet with a black-glass status strip (TABLE 4 ·
  // 0:42), a gold gallery tray on top with a silver cloche over a plate of seared scallops, a dish of macarons and a flute of champagne, and at the back a
  // slim neck with a friendly black-glass face whose amber eyes blink. A jointed gold arm lifts the cloche every few seconds (steam curls out), the head
  // tilts and nods, and a little light chases round the base.
  N.robo28 = S => { const IV = '#f3efe8', CG = '#d6b878', GL = '#141216';
    const D = { w: 56, d: 42, roam: 1, pad: [44, 6, 44, 0], build: () => [],
      wrap: (p, s) => { const v = p(36, 0, 0), o = p(0, 0, 0), dx = f1(v[0] - o[0]), dy = f1(v[1] - o[1]); return '<g>' + at('translate', '-' + dx + ' -' + dy + ';' + dx + ' ' + dy + ';' + dx + ' ' + dy + ';-' + dx + ' -' + dy + ';-' + dx + ' -' + dy, 8, 0, KT('0;0.42;0.5;0.92;1')) + s + '</g>'; } };
    D.fx = ctx => { const C = cam(ctx), k = C.k, BY = 5, CY = 30, TY2 = CY + 2.2, HZ = -11;
      const base = box3(C, clipF(C, { c: [0, 0.8, 0], w: 44, h: BY - 0.8, d: 32, r: 6, col: '#1e1c22', olw: 0.3, gl: 0.3 }));
      const glow = PLN(C, [0, 0.05, 0], [1, 0, 0], [0, 0, 1], `<rect x="-26" y="-19" width="52" height="38" rx="10" fill="url(#k28amb)" opacity="0.6">${an('opacity', '0.4;0.7;0.4', 4)}</rect>`);
      const chase = (() => { const RR = 7, Q = []; [[22 - RR, 16 - RR, 0], [-22 + RR, 16 - RR, 1], [-22 + RR, -16 + RR, 2], [22 - RR, -16 + RR, 3]].forEach(([cx, cz, q]) => { for (let i = 0; i <= 6; i++) { const a = (q + i / 6) * PI / 2; Q.push([cx + Math.cos(a) * RR, cz + Math.sin(a) * RR]); } });
        const P = Q.map(([x, z]) => C.P([x, BY - 0.6, z])), d = 'M' + P.map(P2).join('L') + 'Z'; let L = 0; P.forEach((p, i) => { const q = P[(i + 1) % P.length]; L += Math.hypot(q[0] - p[0], q[1] - p[1]); });
        return `<path d="${d}" fill="none" stroke="#ffc870" stroke-width="${f1(0.5 * k)}" stroke-linejoin="round" opacity="0.5"/><path d="${d}" fill="none" stroke="#fff0c8" stroke-width="${f1(0.8 * k)}" stroke-linecap="round" stroke-dasharray="${f1(L * 0.08)} ${f1(L)}">${an('stroke-dashoffset', `0;${f1(-L * 1.08)}`, 3.6)}</path>`; })();
      const cab = box3(C, clipF(C, { c: [0, BY, 0], w: 46, h: CY - BY, d: 34, r: 8, col: IV, olw: 0.35, olc: '#a8a094', gl: 0.6,
        dec: { f: `<rect x="1" y="2.2" width="28" height="0.5" fill="${CG}"/><rect x="5" y="6" width="20" height="5" rx="2.4" fill="${GL}"/><text x="15" y="9.3" text-anchor="middle" ${FONT} font-size="1.9" fill="#ffc870">TABLE 4 · 0:42</text><circle cx="7.2" cy="8.5" r="0.7" fill="#ffc870">${an('opacity', '1;0.3;1', 1.6)}</circle><path d="M1 15.5H29" stroke="#c8beb0" stroke-width="0.25"/><rect x="12" y="17.5" width="6" height="0.8" rx="0.4" fill="${CG}"/>`,
          b: `<rect x="1" y="2.2" width="28" height="0.5" fill="${CG}"/>`, l: `<rect x="1" y="2.2" width="16" height="0.5" fill="${CG}"/><path d="M1 15.5H17" stroke="#c8beb0" stroke-width="0.25"/>`, r: `<rect x="1" y="2.2" width="16" height="0.5" fill="${CG}"/><path d="M1 15.5H17" stroke="#c8beb0" stroke-width="0.25"/>`, t: `<rect width="46" height="34" rx="8" fill="${shade(IV, 0.96)}"/>` } }));
      const tray = box3(C, clipF(C, { c: [0, CY, 2], w: 42, h: 2.2, d: 26, r: 5, col: CG, olw: 0.3, gl: 0.6, dec: { t: `<rect x="1.2" y="1.2" width="39.6" height="23.6" rx="4" fill="#2a2420"/><rect x="1.2" y="1.2" width="39.6" height="23.6" rx="4" fill="url(#m10s)" opacity="0.25"/>` } }));
      const gal = [[[-15, TY2, -10], [15, TY2, -10]], [[-15, TY2, 14], [15, TY2, 14]], [[-20, TY2, -5], [-20, TY2, 9]], [[20, TY2, -5], [20, TY2, 9]]].map(([a, b]) => ({ q: [(a[0] + b[0]) / 2, TY2, (a[2] + b[2]) / 2], s: cyl3(C, [a[0], TY2 + 1.6, a[2]], [b[0], TY2 + 1.6, b[2]], 0.45, CG, { mat: 'chrome', n: 10, olw: 0.2 }) }));
      // food: scallops under the cloche, macarons, champagne flute
      const CX = -4, CZ = 6, plate = cyl3(C, [CX, TY2, CZ], [CX, TY2 + 0.8, CZ], 6, '#fbfaf6', { r2: 7.2, mat: 'gloss', n: 28, olw: 0.25, cap: cr => `<circle r="${f1(cr * 0.75)}" fill="none" stroke="${CG}" stroke-width="0.3"/>` });
      const scal = vsort(C, [[-2.2, -1], [2, -1.2], [0, 2]].map(([dx, dz]) => { const q = [CX + dx, TY2 + 0.8, CZ + dz]; return { q, s: cyl3(C, q, [q[0], q[1] + 1.6, q[2]], 1.6, '#f4e6d0', { mat: 'gloss', n: 16, olw: 0.2, cap: cr => `<circle r="${f1(cr)}" fill="#c8823a"/><circle r="${f1(cr * 0.55)}" fill="#e0a050"/>` }) }; })) + rep(5, i => sph(C, [CX - 3 + i * 1.5, TY2 + 1, CZ + 3.4 - (i % 2)], 0.4, '#5a8a3a')).join('');
      const lid = (() => { const b = cyl3(C, [CX, TY2 + 0.8, CZ], [CX, TY2 + 5.4, CZ], 6.6, '#dfe3e6', { r2: 4.4, mat: 'chrome', n: 28, olw: 0.3, noCap: 1 }) + cyl3(C, [CX, TY2 + 5.4, CZ], [CX, TY2 + 6.8, CZ], 4.4, '#dfe3e6', { r2: 1.6, mat: 'chrome', n: 24, olw: 0.3, noCap: 1 }) + sph(C, [CX, TY2 + 7.6, CZ], 1.2, CG); return b; })();
      const steam = rep(3, i => puff1(C, [CX + (i - 1) * 2.4, TY2 + 2.4, CZ], 0.55, 6, 0.32 + i * 0.04, 0.72, 0)).join('');
      const SH = [CX + 9.6, TY2 + 0.6, CZ - 9], sp = C.P(SH), kp = C.P([CX, TY2 + 7.6, CZ]), mp = C.P([CX + 6, TY2 + 12, CZ - 5]);
      const armS = `<path d="M${P2(sp)}L${P2(mp)}L${P2(kp)}" stroke="#8a6a2a" stroke-width="${f1(1.7 * k)}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M${P2(sp)}L${P2(mp)}L${P2(kp)}" stroke="url(#k28brs)" stroke-width="${f1(1.2 * k)}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${f1(mp[0])}" cy="${f1(mp[1])}" r="${f1(1.3 * k)}" fill="${CG}" stroke="#8a6a2a" stroke-width="${f1(0.25 * k)}"/><circle cx="${f1(sp[0])}" cy="${f1(sp[1])}" r="${f1(1.7 * k)}" fill="${CG}" stroke="#8a6a2a" stroke-width="${f1(0.25 * k)}"/>`;
      const lift = `<g>${at('rotate', `0 ${P2(sp)};0 ${P2(sp)};-16 ${P2(sp)};-16 ${P2(sp)};0 ${P2(sp)};0 ${P2(sp)}`, 6, 0, KT('0;0.25;0.35;0.65;0.75;1'))}${lid + armS}</g>`;
      const mac = (x, z, c) => cyl3(C, [x, TY2, z], [x, TY2 + 0.8, z], 1.3, c, { mat: 'matte', n: 14, olw: 0.2 }) + cyl3(C, [x, TY2 + 0.8, z], [x, TY2 + 1.2, z], 1.15, '#fbf4e4', { n: 14, olw: 0.15 }) + cyl3(C, [x, TY2 + 1.2, z], [x, TY2 + 2, z], 1.3, c, { mat: 'matte', n: 14, olw: 0.2 });
      const dish = cyl3(C, [11, TY2, 7], [11, TY2 + 0.6, 7], 4, '#fbfaf6', { r2: 4.6, mat: 'gloss', n: 22, olw: 0.25 }) + vsort(C, [[-1.8, -1, '#f4b8c8'], [1.8, -0.8, '#b8d8a0'], [0, 1.6, '#c8b0e8']].map(([dx, dz, c]) => ({ q: [11 + dx, TY2 + 1, 7 + dz], s: mac(11 + dx, 7 + dz, c) })));
      const flute = (() => { const x = 14, z = -3; return cyl3(C, [x, TY2, z], [x, TY2 + 0.3, z], 1.4, '#eef6f6', { mat: 'chrome', n: 14, op: 0.45, olw: 0.2, olc: '#8aa4aa' }) + cyl3(C, [x, TY2 + 0.3, z], [x, TY2 + 3.4, z], 0.2, '#eef6f6', { n: 8, op: 0.6, olw: 0.15 })
        + cyl3(C, [x, TY2 + 3.6, z], [x, TY2 + 8, z], 0.8, '#f4dc8a', { r2: 1.05, mat: 'gloss', n: 14, op: 0.8, olw: 0 }) + cyl3(C, [x, TY2 + 3.4, z], [x, TY2 + 9.4, z], 0.9, '#eef6f6', { r2: 1.15, mat: 'chrome', n: 14, op: 0.3, olw: 0.2, olc: '#8aa4aa', noCap: 1 }) + rep(3, i => bub1(C, [x + (i - 1) * 0.3, TY2 + 4, z], [x + (i - 1) * 0.3, TY2 + 7.8, z], 0.15, 1.8, i * 0.27)).join(''); })();
      // neck + head at the back
      const neck = cyl3(C, [0, TY2, HZ], [0, TY2 + 14, HZ], 1.6, CG, { mat: 'chrome', n: 14, olw: 0.25 }) + cyl3(C, [0, TY2, HZ], [0, TY2 + 1.4, HZ], 3.2, CG, { mat: 'chrome', n: 18, olw: 0.25 });
      const HY = TY2 + 14, eyes = `<g>${rep(2, i => `<ellipse cx="${i ? 5.2 : 2.8}" cy="4" rx="0.85" ry="1.1" fill="#ffc870">${an('ry', '1.1;1.1;0.12;1.1;1.1', 4.2, -i * 0.02, KT('0;0.9;0.93;0.96;1'))}</ellipse>`).join('')}<path d="M3 6.2Q4 7 5 6.2" stroke="#ffc870" stroke-width="0.35" fill="none" stroke-linecap="round"/></g>`;
      const head = box3(C, clipF(C, { c: [0, HY, HZ], w: 14, h: 9.4, d: 9, r: 3.4, col: IV, olw: 0.3, olc: '#a8a094', gl: 0.6, dec: { f: `<rect x="0.3" y="1.4" width="6.6" height="6.6" rx="2" fill="${GL}"/><rect x="0.3" y="1.4" width="6.6" height="6.6" rx="2" fill="url(#k28gls)" opacity="0.4"/>` + `<g transform="translate(-0.4 0)">${eyes}</g>`, t: `<rect width="14" height="9" rx="3.4" fill="${shade(IV, 1.02)}"/><rect x="5" y="3.8" width="4" height="1.4" rx="0.7" fill="${CG}"/>`, b: `<rect x="1" y="3" width="5.2" height="0.5" fill="${CG}"/>` } })) + cyl3(C, [0, HY + 9.4, HZ], [0, HY + 11.6, HZ], 0.35, CG, { mat: 'chrome', n: 8, olw: 0.15 }) + sph(C, [0, HY + 12, HZ], 0.8, '#ffc870');
      const hp = C.P([0, HY, HZ]), headG = `<g>${at('rotate', `0 ${P2(hp)};0 ${P2(hp)};-5 ${P2(hp)};4 ${P2(hp)};0 ${P2(hp)}`, 7, 0, KT('0;0.4;0.55;0.75;1'))}${head}</g>`;
      const defs = `<linearGradient id="k28gls" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="0.4" stop-color="#ffffff" stop-opacity="0"/></linearGradient>`;
      const fF = C.v[2] > 0, nearG = gal.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] > 0), farG = gal.filter(o => o.q[0] * C.v[0] + o.q[2] * C.v[2] <= 0);
      const back = neck + headG, food = vsort(C, [{ q: [CX, TY2 + 3, CZ], s: plate + scal + steam + lift }, { q: [11, TY2 + 1, 7], s: dish }, { q: [14, TY2 + 4, -3], s: flute }]);
      let s = glow + shadow(C, 0, 0, 30, 22, 0.55) + base + chase + cab + tray + vsort(C, farG) + (fF ? back + food : food + back) + vsort(C, nearG);
      C.p(0, HY + 13, 0); C.p(-36, 0, 0); C.p(36, 0, 0);
      return { defs: DEFF + defs, front: s, bb: C.bb(6) }; };
    return D; };

  // ---------- batch 13: countertop clutter KIT-008 cereal + dish soap, KIT-028 wire fruit basket + glass cookie jar, KIT-048 mortar, cruet + salt pig ----------
  // KIT-008 BOX OF CEREAL & DISH SOAP BOTTLE (T1): 66 x 50 kept. A battered box of "Frooty Rings" (crushed corner, torn top flap folded back, the crinkly
  // liner bag poking out, a coupon cut out of the side), a bowl of soggy rings in milk with a spoon, rings spilled on the floor, a half-empty green dish soap
  // bottle with a crusty flip cap and a peeling label, and a grimy two-tone sponge. Alive: soap bubbles drift up from the cap and pop.
  N.cer28 = S => { const BX = '#e8b23a';
    const D = { w: 66, d: 50, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('cer28');
      const ring = (x, y, z, c, s) => { const p = C.P([x, y, z]); return `<g transform="translate(${P2(p)}) scale(${n4(C.k * (s || 1))})"><ellipse rx="1.3" ry="0.8" fill="${c}"/><ellipse rx="0.45" ry="0.28" fill="#5a3a1a" opacity="0.55"/><ellipse cx="-0.4" cy="-0.35" rx="0.45" ry="0.2" fill="#ffffff" opacity="0.4"/></g>`; };
      const RC = ['#e8443a', '#f2a62a', '#f2d83a', '#5ab84a', '#4a8ad8', '#a85ad8'];
      const boxF = `<rect width="22" height="34" fill="${BX}"/><rect y="3" width="22" height="7" fill="#d8302a"/><text x="11" y="7.2" text-anchor="middle" ${FONT} font-size="3" fill="#fff4c8">FROOTY</text><text x="11" y="13.6" text-anchor="middle" ${FONT} font-size="3.2" fill="#d8302a">RINGS</text>`
        + `<ellipse cx="11" cy="23" rx="8" ry="5.4" fill="#ffffff"/><ellipse cx="11" cy="23.6" rx="6.6" ry="3.6" fill="#f4f0e4"/>` + [[8, 22], [10.4, 21.4], [13, 22.4], [9.4, 24.2], [12, 24.4], [14.2, 23.4]].map(([x, y], i) => `<circle cx="${x}" cy="${y}" r="1" fill="${RC[i]}"/><circle cx="${x}" cy="${y}" r="0.35" fill="#f4f0e4"/>`).join('')
        + `<path d="M14 31l4 -4" stroke="#ffffff" stroke-width="0.6"/><rect x="15.6" y="28.4" width="5" height="3.6" rx="0.6" fill="#ffffff" opacity="0.85" transform="rotate(-8 18 30)"/><text x="18" y="31" text-anchor="middle" ${FONT} font-size="1.2" fill="#d8302a" transform="rotate(-8 18 30)">NEW!</text>`
        + `<path d="M0 0L3.4 0L0 4.2Z" fill="#000000" opacity="0.15"/><path d="M0.8 0.6Q2 2.6 0.4 3.6" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.4" fill="none"/>` + scr(R, 8, 1, 14, 20, 18, '#8a5a1a', 0.35);
      const boxS = `<rect width="8.6" height="34" fill="${shade(BX, 0.94)}"/><rect x="1" y="12" width="6.6" height="9" fill="none" stroke="#8a5a1a" stroke-width="0.25" stroke-dasharray="0.8 0.5"/><rect x="1.2" y="12.2" width="6.2" height="8.6" fill="#f4ead0"/><text x="4.3" y="6" text-anchor="middle" ${FONT} font-size="1.2" fill="#8a3a1a">NUTRITION</text>` + rep(6, i => `<path d="M1 ${f1(7.4 + i * 0.7)}H7.6" stroke="#8a5a1a" stroke-width="0.15"/>`).join('');
      const bx = box3(C, clipF(C, { c: [-16, 0, -8], w: 22, h: 34, d: 9, r: 0.3, col: BX, olw: 0.35, olc: '#8a5a1a', dec: { f: boxF, b: boxF, l: boxS, r: boxS, t: `<rect width="22" height="9" fill="#c8901a"/><path d="M1 4.5H21" stroke="#8a5a1a" stroke-width="0.3"/>` } }))
        + PLN(C, [-27, 34, -3.6], [1, 0, 0], [0, 0.55, 0.83], `<path d="M0 0H22L21.4 6H0.6Z" fill="${shade(BX, 1.05)}" stroke="#8a5a1a" stroke-width="0.25"/><path d="M14 0L18 3.4L22 0" fill="#ffffff" opacity="0.4"/>`)
        + (() => { const a = C.P([-24, 34, -10]), b = C.P([-9, 34, -10]), c = C.P([-10, 38, -8]), d = C.P([-22, 38.6, -9]); return `<path d="M${P2(a)}L${P2(b)}L${P2(c)}Q${f1((c[0] + d[0]) / 2)} ${f1(c[1] - 2 * C.k)} ${P2(d)}Z" fill="#eef0f2" opacity="0.85" stroke="#b8bec4" stroke-width="${f1(0.25 * C.k)}"/><path d="M${P2(d)}L${f1((a[0] + b[0]) / 2)} ${f1((a[1] + b[1]) / 2)}" stroke="#ffffff" stroke-width="${f1(0.3 * C.k)}" opacity="0.7"/>`; })();
      // bowl of soggy rings + spoon
      const BXZ = [13, 11], bowl = cyl3(C, [BXZ[0], 0, BXZ[1]], [BXZ[0], 7, BXZ[1]], 7, '#5aa8d8', { r2: 10, mat: 'gloss', n: 30, olw: 0.35, cap: cr => `<circle r="${f1(cr * 0.9)}" fill="#f6f2e6"/>` + rep(16, i => { const a = i * 2.4, r = 1.6 + (i % 5) * 1.5; return `<g transform="translate(${f1(Math.cos(a) * r)} ${f1(Math.sin(a) * r)})"><circle r="1.1" fill="${RC[i % 6]}" opacity="0.85"/><circle r="0.4" fill="#f6f2e6"/></g>`; }).join('') + `<circle r="${f1(cr * 0.9)}" fill="none" stroke="#ffffff" stroke-width="0.5" opacity="0.6"/>` })
        + H2(C, [BXZ[0] + 3, 7.6, BXZ[1] - 2], [BXZ[0] + 10, 12, BXZ[1] - 6], 0.9, '#c4c8cc') + sph(C, [BXZ[0] + 2.4, 7.4, BXZ[1] - 1.6], 1.4, '#c4c8cc');
      const milk = PLN(C, [BXZ[0] - 9, 0.05, BXZ[1] + 7], [1, 0, 0], [0, 0, 1], `<ellipse rx="4.6" ry="2.4" fill="#f6f4ee" opacity="0.85"/><ellipse cx="-1.4" cy="-0.8" rx="1.8" ry="0.6" fill="#ffffff"/>`);
      const spill = vsort(C, [[-4, 6], [-2, 9], [1, 4], [-6, 12], [3, 15], [-9, 2]].map(([x, z], i) => ({ q: [x, 0.4, z], s: ring(x, 0.5, z, RC[i % 6], 1) })));
      // dish soap, sponge, bubbles
      const SX = 20, SZ = -11, soap = cyl3(C, [SX, 0, SZ], [SX, 18, SZ], 5, '#5ac87a', { r2: 4.4, mat: 'gloss', n: 22, op: 0.75, olw: 0.3, olc: '#2a7a4a', noCap: 1 }) + cyl3(C, [SX, 0.2, SZ], [SX, 7.6, SZ], 4.8, '#2a9a5a', { mat: 'gloss', n: 22, op: 0.8, olw: 0, capCol: '#4ab86a' })
        + cyl3(C, [SX, 18, SZ], [SX, 21, SZ], 4.4, '#5ac87a', { r2: 1.8, mat: 'gloss', n: 20, op: 0.75, olw: 0.3, olc: '#2a7a4a', noCap: 1 }) + cyl3(C, [SX, 21, SZ], [SX, 24, SZ], 1.9, '#f2f2ec', { n: 14, olw: 0.25 }) + box3(C, { c: [SX + 1.2, 24, SZ], w: 1.6, h: 1.2, d: 1.6, r: 0.4, col: '#f2f2ec', olw: 0.2 })
        + PLN(C, [SX + 1, 24.4, SZ], [1, 0, 0], [0, 0, 1], `<circle r="0.7" fill="#7ad89a" opacity="0.7"/>`) + `<g transform="${tanF(C, SX, SZ, 4.75, C.thV, 11)}"><path d="M-3.6 -3.4H3.4L3.6 2.8L1 3.6L-3.4 3.2Z" fill="#fbfaf4"/><path d="M3.4 -3.4L5 -1.4L3.5 0" fill="#f0eee4"/><text x="0" y="-0.8" text-anchor="middle" ${FONT} font-size="1.5" fill="#2a7a4a">LEMON</text><text x="0" y="1.2" text-anchor="middle" ${FONT} font-size="1.1" fill="#2a7a4a">FRESH</text><circle cx="2.4" cy="2" r="0.8" fill="#f2d83a"/></g>`;
      const sponge = box3(C, { c: [-2, 0, -14], w: 9, h: 2.2, d: 6, r: 1, col: '#f2d84a', olw: 0.3, olc: '#a88a2a', dec: { t: `<rect width="9" height="6" fill="#f2d84a"/>` + specks(R, 18, 9, 6, ['#8a7a3a', '#b8a050'], 0.15, 0.4, 0.6) } }) + box3(C, { c: [-2, 2.2, -14], w: 9, h: 1.6, d: 6, r: 0.8, col: '#3a8a4a', olw: 0.3, olc: '#1a4a2a', dec: { t: `<rect width="9" height="6" fill="#3a8a4a"/>` + specks(R, 12, 9, 6, ['#6a5a3a'], 0.2, 0.6, 0.6) } });
      const bubs = rep(3, i => { const p = C.P([SX + 1, 25, SZ]), q = C.P([SX + 3 - i * 3, 40 + i * 4, SZ + 2]), T = 4.2, b = -i * 1.4; return `<circle r="${f1((0.9 + i * 0.3) * C.k)}" fill="#e8f8ff" fill-opacity="0.2" stroke="#ffffff" stroke-opacity="0.8" stroke-width="${f1(0.15 * C.k)}" opacity="0"><animate attributeName="cx" values="${f1(p[0])};${f1(q[0])}" dur="${T}s" begin="${b}s" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(p[1])};${f1(q[1])}" dur="${T}s" begin="${b}s" repeatCount="indefinite"/>${an('opacity', '0;1;1;0', T, b, KT('0;0.1;0.85;0.9'))}</circle>`; }).join('');
      let s = shadow(C, 0, 0, 36, 26, 0.6) + milk + vsort(C, [{ q: [-16, 17, -8], s: bx }, { q: [BXZ[0], 4, BXZ[1]], s: bowl }, { q: [SX, 12, SZ], s: soap }, { q: [-2, 2, -14], s: sponge }, { q: [-3, 0.5, 8], s: spill }]) + bubs;
      C.p(0, 46, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-028 WIRE FRUIT BASKET & GLASS COOKIE JAR (T2): 96 x 46 kept. A round black wire basket on little ball feet with a curly wire banana hook rising from
  // it: red and green apples, oranges, a pear and a bunch of grapes, a hand of ripe bananas hanging from the hook and swaying. Beside it a big glass cookie
  // jar with a pale wood lid and a ceramic knob, half full of chocolate-chip cookies, a kraft tag on twine round its neck and a cookie and crumbs on a little
  // plate in front. Alive: the bananas sway, a glint slides across the jar.
  N.fruit28 = S => { const WR = '#2a2a2c';
    const D = { w: 96, d: 46, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('fruit28'), BXc = -22, BR = 17, BY = 2.4;
      // basket: floor ring + wall rings + uprights (back half before the fruit, front half after)
      const ringP = (y, r, a0, a1) => { const n = 18; let d = ''; for (let i = 0; i <= n; i++) { const a = a0 + (a1 - a0) * i / n, p = C.P([BXc + Math.cos(a) * r, y, Math.sin(a) * r]); d += (i ? 'L' : 'M') + P2(p); } return d; };
      const L = Math.hypot(C.v[0], C.v[2]) || 1, va = Math.atan2(C.v[2] / L, C.v[0] / L), half = (front) => { const a0 = front ? va - PI / 2 : va + PI / 2, a1 = a0 + PI; let s = '';
        [[BY, BR * 0.62], [BY + 4, BR * 0.86], [BY + 9, BR], [BY + 12.5, BR * 1.04]].forEach(([y, r], i) => { const d = ringP(y, r, a0, a1); s += `<path d="${d}" stroke="${WR}" stroke-width="${f1((i === 3 ? 0.9 : 0.6) * C.k)}" fill="none"/><path d="${d}" stroke="#ffffff" stroke-opacity="0.2" stroke-width="${f1(0.2 * C.k)}" fill="none" transform="translate(0 ${f1(-0.3 * C.k)})"/>`; });
        rep(12, i => i * PI / 6).filter(a => { const c = Math.cos(a - va); return front ? c > 0 : c <= 0; }).forEach(a => { const p = C.P([BXc + Math.cos(a) * BR * 0.62, BY, Math.sin(a) * BR * 0.62]), q = C.P([BXc + Math.cos(a) * BR * 1.04, BY + 12.5, Math.sin(a) * BR * 1.04]); s += `<path d="M${P2(p)}Q${f1((p[0] + q[0]) / 2 + (q[0] - p[0]) * 0.2)} ${f1((p[1] + q[1]) / 2)} ${P2(q)}" stroke="${WR}" stroke-width="${f1(0.5 * C.k)}" fill="none"/>`; });
        return s; };
      const feet = vsort(C, [0, 2.1, 4.2].map(a => ({ q: [BXc + Math.cos(a) * BR * 0.5, 1, Math.sin(a) * BR * 0.5], s: sph(C, [BXc + Math.cos(a) * BR * 0.5, 1.2, Math.sin(a) * BR * 0.5], 1.2, WR) })));
      const floorP = PLN(C, [BXc, BY + 0.05, 0], [1, 0, 0], [0, 0, 1], `<circle r="${f1(BR * 0.62)}" fill="#1a1a1c" opacity="0.25"/>` + rep(6, i => `<path d="M0 0L${f1(Math.cos(i * PI / 3) * BR * 0.62)} ${f1(Math.sin(i * PI / 3) * BR * 0.62)}" stroke="${WR}" stroke-width="0.6"/>`).join(''));
      const FR = [[-6, 6.6, -4, '#d8302a', 4.4], [5, 6.4, -5, '#7ab83a', 4.2], [-1, 6, 5, '#f28a2a', 4.6], [8, 6.2, 5, '#f28a2a', 4.4], [-9, 6.2, 5, '#d8302a', 4.3], [0, 11, -1, '#c8382a', 4.2], [-5, 10.6, 2, '#a8c84a', 3.8, 'pear'], [5, 10.6, 1, '#7ab83a', 4]];
      const fruit = vsort(C, FR.map(([dx, y, z, c, r, k]) => { const q = [BXc + dx, BY + y, z]; let s = sph(C, q, r, c) + H2(C, [q[0], q[1] + r * 0.85, q[2]], [q[0] + 0.4, q[1] + r + 1.4, q[2]], 0.4, '#5a3a1a');
        if (k === 'pear') s = sph(C, [q[0], q[1] + r * 0.9, q[2]], r * 0.62, c) + s; if (c === '#f28a2a') s += (() => { const p = C.P([q[0] - r * 0.3, q[1] + r * 0.4, q[2] + r * 0.6]); return `<g fill="#c86a1a" opacity="0.45">${rep(5, i => `<circle cx="${f1(p[0] + (i - 2) * 0.6 * C.k)}" cy="${f1(p[1] + (i % 2) * 0.5 * C.k)}" r="${f1(0.14 * C.k)}"/>`).join('')}</g>`; })();
        return { q, s }; }));
      const grapes = (() => { const x = BXc + 9, z = -6, y = BY + 9; let s = ''; rep(14, i => { const a = i * 2.4, rr = 0.8 + (i % 4) * 0.7; return { q: [x + Math.cos(a) * rr, y + (i % 3) * 1.2, z + Math.sin(a) * rr * 0.7] }; }).sort((a, b) => dot(a.q, C.v) - dot(b.q, C.v)).forEach(g => s += sph(C, g.q, 1.15, '#6a3a7a')); return s + H2(C, [x, y + 3.4, z], [x - 1, y + 5.6, z], 0.35, '#5a7a3a'); })();
      // banana hook: post from the basket centre up, curl over, bananas hanging
      const HX = BXc + 2, HY = BY + 30, post = cyl3(C, [HX, BY + 4, -2], [HX, HY, -2], 0.55, WR, { mat: 'metal', n: 10, olw: 0.2 }), curl = (() => { const pts = [[HX, HY, -2], [HX + 2, HY + 2.6, -2], [HX + 5, HY + 2.2, -2], [HX + 6.4, HY, -2], [HX + 6.4, HY - 1.6, -2]].map(q => P2(C.P(q))); return `<path d="M${pts.join('L')}" stroke="${WR}" stroke-width="${f1(1.1 * C.k)}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`; })();
      const bananas = (() => { const top = [HX + 6.4, HY - 2.4, -2]; let s = H2(C, [HX + 6.4, HY - 1.6, -2], top, 0.8, '#6a4a1a');
        [-3, -1, 1, 3].forEach((dz, i) => { const P = [top, [top[0] + 1 + i * 0.3, top[1] - 4, -2 + dz], [top[0] + 2.6 + i * 0.4, top[1] - 10, -2 + dz * 1.4], [top[0] + 1.4 + i * 0.6, top[1] - 15, -2 + dz * 1.6]];
          for (let j = 0; j < 3; j++) s += cyl3(C, P[j], P[j + 1], j === 0 ? 0.8 : 1.5, '#f2d03a', { r2: j === 2 ? 0.7 : 1.5, mat: 'gloss', n: 12, olw: 0.25, olc: '#a8862a', noCap: 1 }); s += sph(C, P[3], 0.6, '#3a2a1a'); });
        return sway(C, [HX + 6.4, HY - 1.6, -2], s + `<g fill="#6a4a1a" opacity="0.7">${rep(6, i => { const p = C.P([top[0] + 2 + R() * 2, top[1] - 6 - R() * 7, -2 + (R() - 0.5) * 5]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.2 * C.k)}"/>`; }).join('')}</g>`, 3, 4.8); })();
      const basket = half(false) + floorP + fruit + grapes + post + curl + bananas + half(true);
      // glass cookie jar
      const JX = 26, JZ = -2, JR = 11, JH = 22, jarBody = cyl3(C, [JX, 0, JZ], [JX, JH, JZ], JR, '#eaf4f4', { mat: 'chrome', n: 30, op: 0.28, olw: 0.35, olc: '#8aa4aa', noCap: 1 });
      const cookie = (q, a) => { const p = C.P(q); return `<g transform="translate(${P2(p)}) rotate(${a}) scale(${n4(C.k)})"><ellipse rx="4.4" ry="${f1(1.4 + Math.abs(Math.sin(a * PI / 180)) * 2)}" fill="#d89a4a" stroke="#8a5420" stroke-width="0.3"/><circle cx="-1.6" cy="-0.3" r="0.6" fill="#4a2a14"/><circle cx="1.2" cy="0.4" r="0.55" fill="#4a2a14"/><circle cx="0" cy="-0.6" r="0.45" fill="#4a2a14"/><ellipse cx="-1" cy="-0.8" rx="1.6" ry="0.4" fill="#f8d8a0" opacity="0.6"/></g>`; };
      const stack = rep(7, i => cookie([JX + (i % 2 ? 1.6 : -1.4) + (i % 3) - 1, 1.6 + i * 1.6, JZ + (i % 2 ? -2 : 2)], (i * 47) % 40 - 20)).join('');
      const jarIn = cyl3(C, [JX, 0.3, JZ], [JX, 1.2, JZ], JR - 0.6, '#d8ecec', { mat: 'gloss', n: 28, op: 0.3, olw: 0 }) + stack;
      const neck = cyl3(C, [JX, JH, JZ], [JX, JH + 2.4, JZ], JR - 1.4, '#eaf4f4', { mat: 'chrome', n: 28, op: 0.3, olw: 0.3, olc: '#8aa4aa', noCap: 1 });
      const lid = cyl3(C, [JX, JH + 2, JZ], [JX, JH + 4.6, JZ], JR - 0.4, '#e2c89a', { mat: 'matte', n: 28, olw: 0.35, olc: '#8a6a3a', cap: cr => `<circle r="${f1(cr)}" fill="#e8d0a4"/>` + rep(5, i => `<circle r="${f1(cr * (0.3 + i * 0.14))}" fill="none" stroke="#b8945a" stroke-opacity="0.35" stroke-width="0.25"/>`).join('') }) + sph(C, [JX, JH + 6.4, JZ], 2.2, '#f4f0e6');
      const tag = (() => { const a = C.P([JX + JR * 0.7, JH + 1.6, JZ + JR * 0.7]), b = C.P([JX + JR * 0.9, JH - 6, JZ + JR * 0.6]); return `<path d="M${P2(a)}L${P2(b)}" stroke="#b8945a" stroke-width="${f1(0.25 * C.k)}"/><g transform="translate(${P2(b)}) rotate(-12) scale(${n4(C.k)})"><path d="M-2.4 0H2.4V5H-2.4Z" fill="#c8a06a"/><circle cy="0.8" r="0.4" fill="#ffffff"/><text y="3.4" text-anchor="middle" font-family="'Comic Sans MS',cursive" font-size="1.3" fill="#4a2a14">yum</text></g>`; })();
      const glint = (() => { const p = C.P([JX, JH * 0.85, JZ]), w = JR * C.k; return `<g><rect x="${f1(p[0] - w)}" y="${f1(p[1])}" width="${f1(w * 0.18)}" height="${f1(JH * 0.75 * C.k)}" rx="${f1(0.5 * C.k)}" fill="#ffffff" opacity="0.3">${an('x', `${f1(p[0] - w * 0.8)};${f1(p[0] - w * 0.8)};${f1(p[0] + w * 0.6)};${f1(p[0] + w * 0.6)}`, 7, 0, KT('0;0.55;0.85;1'))}${an('opacity', '0.15;0.15;0.45;0', 7, 0, KT('0;0.55;0.7;0.85'))}</rect></g>`; })();
      const jar = jarIn + jarBody + neck + lid + glint + tag;
      const plate = cyl3(C, [JX + 2, 0, JZ + 15], [JX + 2, 0.8, JZ + 15], 4.6, '#f4f0e8', { r2: 5.4, mat: 'gloss', n: 24, olw: 0.25 }) + cookie([JX + 2, 1.4, JZ + 15], 0) + PLN(C, [JX + 2, 0.86, JZ + 15], [1, 0, 0], [0, 0, 1], specks(R, 9, 0, 0, ['#c88a3a'], 0.15, 0.35, 0.9).replace(/cx="0(\.0)?" cy="0(\.0)?"/g, () => `cx="${f1((R() - 0.5) * 7)}" cy="${f1((R() - 0.5) * 6)}"`));
      let s = shadow(C, BXc, 0, 22, 18, 0.55) + shadow(C, JX, JZ, 14, 13, 0.5) + vsort(C, [{ q: [BXc, 8, 0], s: feet + basket }, { q: [JX, 11, JZ], s: jar }, { q: [JX + 2, 1, JZ + 15], s: plate }]);
      C.p(0, HY + 4, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-048 MARBLE MORTAR & PESTLE, OLIVE OIL CRUET & SALT PIG (T3): 36 x 26 kept (small). A heavy Carrara marble mortar with grey veins holding crushed
  // peppercorns, rosemary and garlic, its pestle grinding in slow circles. A glass cruet of golden-green olive oil with a slim steel pourer (a light glint
  // drifts through the oil) and a glazed terracotta salt pig of flaky salt with a little olive-wood spoon. A sprig of rosemary and a garlic bulb on the side.
  N.mort28 = S => { const MB = '#f2efe9';
    const D = { w: 36, d: 26, small: 1, round: 1, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('mort28'), MX = -7, MZ = 2;
      const mv = cr => `<circle r="${f1(cr)}" fill="${MB}"/>` + veins(rng('mv48'), cr * 2, cr * 2).replace(/<path /g, `<path transform="translate(${f1(-cr)} ${f1(-cr)})" `);
      const mortar = cyl3(C, [MX, 0, MZ], [MX, 2, MZ], 7, MB, { r2: 8.6, mat: 'gloss', n: 30, olw: 0.35, olc: '#9a948a', noCap: 1 }) + cyl3(C, [MX, 2, MZ], [MX, 9.4, MZ], 8.6, MB, { r2: 9.4, mat: 'gloss', n: 30, olw: 0.35, olc: '#9a948a',
        cap: cr => `<circle r="${f1(cr)}" fill="${MB}"/><circle r="${f1(cr * 0.74)}" fill="#d8d2c8"/><circle r="${f1(cr * 0.74)}" fill="url(#m10s)" opacity="0.3"/>` + rep(26, i => { const a = i * 2.39, r = (i % 6) * cr * 0.1; return `<circle cx="${f1(Math.cos(a) * r)}" cy="${f1(Math.sin(a) * r * 0.9 + cr * 0.12)}" r="${f1(0.35 + (i % 3) * 0.2)}" fill="${['#3a2a1a', '#5a3a2a', '#e8dcc0', '#5a7a3a'][i % 4]}"/>`; }).join('') + `<path d="M${f1(-cr * 0.5)} ${f1(cr * 0.3)}l1.6 -0.4l1.4 0.5" stroke="#5a7a3a" stroke-width="0.4" fill="none"/>` })
        + `<g transform="${tanF(C, MX, MZ, 9.0, C.thV, 6)}" opacity="0.35">${veins(rng('mvs'), 14, 6).replace(/<path /g, '<path transform="translate(-7 -3)" ')}</g>`;
      const pc = C.P([MX, 8, MZ]), k = C.k, path = `0 0;${f1(1.6 * k)} ${f1(0.5 * k)};0 ${f1(1 * k)};${f1(-1.6 * k)} ${f1(0.5 * k)};0 0`;
      const pestle = `<g>${at('translate', path, 3.2)}${cyl3(C, [MX + 1, 7, MZ - 1], [MX + 5, 21, MZ - 4], 1.9, MB, { r2: 1.3, mat: 'gloss', n: 18, olw: 0.3, olc: '#9a948a' }) + sph(C, [MX + 1, 7.2, MZ - 1], 2, MB)}</g>`;
      const flecks = rep(3, i => { const p = C.P([MX + (i - 1) * 3, 9.6, MZ + 2]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.3 * k)}" fill="#3a2a1a" opacity="0">${an('cy', `${f1(p[1])};${f1(p[1] - 2.6 * k)};${f1(p[1] - 0.4 * k)}`, 3.2, -i * 1.05)}${an('opacity', '0;0.9;0', 3.2, -i * 1.05)}</circle>`; }).join('');
      // cruet
      const CX = 9, CZ = -5, cr0 = cyl3(C, [CX, 0, CZ], [CX, 11, CZ], 3.6, '#eef6f2', { r2: 3.2, mat: 'chrome', n: 22, op: 0.32, olw: 0.3, olc: '#8aa4aa', noCap: 1 }) + cyl3(C, [CX, 0.4, CZ], [CX, 8.4, CZ], 3.3, '#b8b040', { r2: 3, mat: 'gloss', n: 22, op: 0.78, olw: 0, capCol: '#c8c050' })
        + cyl3(C, [CX, 11, CZ], [CX, 15.4, CZ], 3.2, '#eef6f2', { r2: 1.1, mat: 'chrome', n: 20, op: 0.32, olw: 0.3, olc: '#8aa4aa', noCap: 1 }) + cyl3(C, [CX, 15.4, CZ], [CX, 17, CZ], 1.2, '#2a2a2c', { n: 12, olw: 0.2 }) + H2(C, [CX, 17, CZ], [CX + 2.6, 21, CZ + 0.6], 0.5, '#c8cdd0') + H2(C, [CX + 2.6, 21, CZ + 0.6], [CX + 3.6, 20.6, CZ + 0.8], 0.4, '#c8cdd0');
      const og = (() => { const p = C.P([CX, 4.4, CZ]); return `<ellipse cx="${f1(p[0] - 1.4 * k)}" cy="${f1(p[1])}" rx="${f1(0.6 * k)}" ry="${f1(2.6 * k)}" fill="#fff8c8" opacity="0.4">${an('cx', `${f1(p[0] - 1.8 * k)};${f1(p[0] + 1.8 * k)};${f1(p[0] - 1.8 * k)}`, 6)}${an('opacity', '0.2;0.55;0.2', 6)}</ellipse>`; })();
      // salt pig
      const PX = 11, PZ = 7, pig = cyl3(C, [PX, 0, PZ], [PX, 6.4, PZ], 4.4, '#b8582a', { r2: 4.8, mat: 'gloss', n: 24, olw: 0.3, olc: '#6a2a10', noCap: 1 })
        + cyl3(C, [PX, 6.4, PZ], [PX, 9, PZ], 4.8, '#c86a3a', { r2: 3.4, mat: 'gloss', n: 24, olw: 0.3, olc: '#6a2a10', cap: cr => `<circle r="${f1(cr)}" fill="#c86a3a"/>` })
        + (() => { const n = C.v[0] * 0.3 + C.v[2], th = Math.atan2(C.v[0], C.v[2]), p = C.P([PX + Math.sin(th) * 4.4, 6.2, PZ + Math.cos(th) * 4.4]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><ellipse rx="2.8" ry="2" fill="#2a1408"/><ellipse cy="0.6" rx="2.4" ry="1.2" fill="#f8f6f0"/>${specks(R, 8, 0, 0, ['#ffffff'], 0.2, 0.4, 1).replace(/cx="0(\.0)?" cy="0(\.0)?"/g, () => `cx="${f1((R() - 0.5) * 4)}" cy="${f1(0.4 + R() * 0.8)}"`)}</g>`; })()
        + H2(C, [PX + 1, 5, PZ + 2], [PX + 4.6, 9.4, PZ + 4.4], 0.6, '#a8844a');
      const bulb = sph(C, [-3, 2.4, 11], 2.6, '#f4ecdc') + H2(C, [-3, 4.6, 11], [-2.6, 6.2, 11], 0.6, '#d8c8a8');
      const ros = (() => { const a = [3, 0.4, 10], b = [-8, 0.4, 13]; let s = H2(C, a, b, 0.4, '#6a5a3a'); rep(10, i => { const t = i / 9, q = [a[0] + (b[0] - a[0]) * t, 0.6, a[2] + (b[2] - a[2]) * t]; s += H2(C, q, [q[0] + 0.4, 0.8, q[2] - 1.2], 0.35, '#4a6a3a') + H2(C, q, [q[0] - 0.4, 0.8, q[2] + 1.2], 0.35, '#5a7a4a'); }); return s; })();
      const boardP = PLN(C, [0, 0.05, 0], [1, 0, 0], [0, 0, 1], `<ellipse cx="${MX}" cy="${MZ + 1}" rx="10" ry="8" fill="#000000" opacity="0.06"/>` + `<g transform="translate(-6 6)">${specks(R, 14, 10, 6, ['#3a2a1a', '#e8dcc0'], 0.15, 0.35, 0.7)}</g>`);
      let s = shadow(C, 0, 0, 20, 15, 0.55) + boardP + vsort(C, [{ q: [MX, 5, MZ], s: mortar + pestle + flecks }, { q: [CX, 8, CZ], s: cr0 + og }, { q: [PX, 4, PZ], s: pig }, { q: [-3, 2, 11], s: bulb }, { q: [-2, 0.5, 11.5], s: ros }]);
      C.p(0, 24, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // ---------- batch 14: KIT-068 glass cloche cookie jar, KIT-108 royal patisserie display case ----------
  const ccookie = (C, q, a, s, dark) => { const p = C.P(q); return `<g transform="translate(${P2(p)}) rotate(${f1(a)}) scale(${n4(C.k * (s || 1))})"><ellipse rx="4.4" ry="${f1(1.5 + Math.abs(Math.sin(a * PI / 180)) * 1.8)}" fill="${dark ? '#8a5a2a' : '#d8a050'}" stroke="#7a4a1a" stroke-width="0.3"/><ellipse cy="-0.4" rx="3.6" ry="${f1(1 + Math.abs(Math.sin(a * PI / 180)) * 1.2)}" fill="${dark ? '#9a6a3a' : '#e4b468'}"/>`
    + `<path d="M-2.2 -0.6l0.9 -0.3l0.3 0.7l-0.8 0.3Z M1 0.2l0.9 -0.2l0.2 0.8l-0.9 0.2Z M-0.2 -1.2l0.7 -0.2l0.3 0.6l-0.7 0.2Z M2.4 -0.9l0.6 0l0.1 0.5l-0.6 0.1Z" fill="#3a1e0e"/><ellipse cx="-1.2" cy="-1" rx="1.4" ry="0.35" fill="#fbe0a8" opacity="0.6"/><path d="M-3.6 0.6Q-2 1.2 -0.4 0.8" stroke="#a8702a" stroke-width="0.25" fill="none" opacity="0.6"/></g>`; };

  // KIT-068 GLASS CLOCHE COOKIE JAR WITH CHOC-CHIP COOKIES (T4): 74 x 52 kept. A tall hand-blown crystal cloche with a polished brass knob on a round
  // Calacatta marble board with a brass rim, over a warm stack of chunky chocolate-chip cookies; a gold-rimmed plate with two more beside it, a glass bottle
  // of milk with a striped paper straw and a folded linen napkin. Alive: every few seconds the cloche lifts a little and a breath of warm steam escapes,
  // a glint slides round the crystal and a soft warm light glows under the dome.
  N.cloche28 = S => { const BR = '#c9a256', MB = '#f4f1ec';
    const D = { w: 74, d: 52, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('cloche28'), BXc = -10, BZ = -1, BRd = 21, k = C.k;
      const board = cyl3(C, [BXc, 0, BZ], [BXc, 1, BZ], BRd + 0.6, BR, { mat: 'chrome', n: 36, olw: 0.3, noCap: 1 }) + cyl3(C, [BXc, 1, BZ], [BXc, 3.4, BZ], BRd, MB, { mat: 'gloss', n: 36, olw: 0.35, olc: '#9a948a', cap: cr => { const id = C.u('vc'); return `<circle r="${f1(cr)}" fill="${MB}"/><clipPath id="${id}"><circle r="${f1(cr)}"/></clipPath><g clip-path="url(#${id})">` + veins(rng('cl68'), cr * 2, cr * 2).replace(/<path /g, `<path transform="translate(${f1(-cr)} ${f1(-cr)})" `) + `</g><circle r="${f1(cr - 0.4)}" fill="none" stroke="${BR}" stroke-width="0.5"/>`; } });
      const TY = 3.4, CR = 15, CH = 30;
      const glow = PLN(C, [BXc, TY + 0.05, BZ], [1, 0, 0], [0, 0, 1], `<circle r="${CR - 1}" fill="url(#k28amb)" opacity="0.55">${an('opacity', '0.4;0.7;0.4', 5)}</circle>`);
      const stack = rep(8, i => ccookie(C, [BXc + (i % 2 ? 1.2 : -1) + ((i * 37) % 5 - 2) * 0.4, TY + 1.4 + i * 2.1, BZ + (i % 3 - 1) * 0.8], (i * 53) % 36 - 18, 1.35, i % 4 === 3)).join('') + ccookie(C, [BXc + 8, TY + 1.4, BZ + 6], 12, 1.2) + ccookie(C, [BXc - 8, TY + 1.4, BZ + 5], -16, 1.15, 1);
      const crumbs = PLN(C, [BXc, TY + 0.06, BZ], [1, 0, 0], [0, 0, 1], `<g transform="translate(-8 -6)">${specks(R, 16, 16, 12, ['#c88a3a', '#e4b468', '#3a1e0e'], 0.2, 0.5, 0.9)}</g>`);
      // cloche: tall bell (body + shoulder + dome) with a brass knob; lifts 2.4 now and then
      const bell = cyl3(C, [BXc, TY, BZ], [BXc, TY + CH * 0.66, BZ], CR, '#eef6f6', { r2: CR * 0.94, mat: 'chrome', n: 32, op: 0.24, olw: 0.35, olc: '#8aa4aa', noCap: 1 })
        + cyl3(C, [BXc, TY + CH * 0.66, BZ], [BXc, TY + CH * 0.9, BZ], CR * 0.94, '#eef6f6', { r2: CR * 0.6, mat: 'chrome', n: 32, op: 0.24, olw: 0.35, olc: '#8aa4aa', noCap: 1 })
        + cyl3(C, [BXc, TY + CH * 0.9, BZ], [BXc, TY + CH, BZ], CR * 0.6, '#eef6f6', { r2: 1.6, mat: 'chrome', n: 28, op: 0.24, olw: 0.35, olc: '#8aa4aa', noCap: 1 })
        + cyl3(C, [BXc, TY + CH - 0.2, BZ], [BXc, TY + CH + 1.4, BZ], 1.6, BR, { mat: 'chrome', n: 14, olw: 0.25 }) + sph(C, [BXc, TY + CH + 3.2, BZ], 2.4, BR)
        + (() => { const p = C.P([BXc, TY, BZ]), w = CR * k; return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(w)}" ry="${f1(w * 0.616)}" fill="none" stroke="#ffffff" stroke-opacity="0.55" stroke-width="${f1(0.5 * k)}"/>`; })();
      const gl = (() => { const p = C.P([BXc, TY + CH * 0.5, BZ]), w = CR * k, h = CH * 0.7 * k; return `<rect x="${f1(p[0] - w * 0.8)}" y="${f1(p[1] - h / 2)}" width="${f1(w * 0.16)}" height="${f1(h)}" rx="${f1(w * 0.08)}" fill="#ffffff" opacity="0.3">${an('x', `${f1(p[0] - w * 0.8)};${f1(p[0] - w * 0.8)};${f1(p[0] + w * 0.55)};${f1(p[0] + w * 0.55)}`, 8, 0, KT('0;0.5;0.8;1'))}${an('opacity', '0.15;0.15;0.45;0', 8, 0, KT('0;0.5;0.65;0.8'))}</rect><rect x="${f1(p[0] - w * 0.62)}" y="${f1(p[1] - h * 0.35)}" width="${f1(w * 0.07)}" height="${f1(h * 0.7)}" rx="${f1(w * 0.04)}" fill="#ffffff" opacity="0.35"/>`; })();
      const lift = `<g>${at('translate', `0 0;0 0;0 ${f1(-2.6 * k)};0 ${f1(-2.6 * k)};0 0;0 0`, 9, 0, KT('0;0.6;0.66;0.8;0.86;1'))}${bell + gl}</g>`;
      const steam = rep(3, i => { const p = C.P([BXc - 8 + i * 8, TY + 1, BZ + CR * 0.7]); return `<g transform="translate(${P2(p)}) scale(${n4(k * 0.7)})"><ellipse rx="4" ry="2.4" fill="url(#m10mst)" opacity="0">${an('opacity', '0;0;0.7;0;0', 9, 0, KT('0;0.64;0.72;0.86;1'))}${at('translate', '0 0;0 0;0 -4;0 -10;0 -10', 9, 0, KT('0;0.64;0.72;0.86;1'))}</ellipse></g>`; }).join('');
      // plate of cookies, milk bottle, napkin
      const PX = 24, PZ = 13, plate = cyl3(C, [PX, 0, PZ], [PX, 1, PZ], 6.4, '#fbfaf6', { r2: 8, mat: 'gloss', n: 30, olw: 0.3, cap: cr => `<circle r="${f1(cr - 0.5)}" fill="none" stroke="${BR}" stroke-width="0.6"/>` }) + ccookie(C, [PX - 1.4, 1.6, PZ], -10, 1.25) + ccookie(C, [PX + 1.6, 2.8, PZ - 1], 18, 1.25, 1);
      const MX = 25, MZ = -11, milk = cyl3(C, [MX, 0, MZ], [MX, 15, MZ], 4, '#eef6f6', { r2: 4, mat: 'chrome', n: 24, op: 0.4, olw: 0.3, olc: '#8aa4aa', noCap: 1 }) + cyl3(C, [MX, 0.3, MZ], [MX, 12.4, MZ], 3.7, '#fbfaf4', { mat: 'gloss', n: 24, olw: 0, capCol: '#ffffff' })
        + cyl3(C, [MX, 15, MZ], [MX, 19, MZ], 4, '#eef6f6', { r2: 2, mat: 'chrome', n: 22, op: 0.4, olw: 0.3, olc: '#8aa4aa', noCap: 1 }) + H2(C, [MX + 0.4, 12, MZ], [MX + 2.6, 26, MZ - 1.4], 0.8, '#ffffff') + H2(C, [MX + 0.4, 12, MZ], [MX + 2.6, 26, MZ - 1.4], 0.8, '#d8302a', 0.0)
        + (() => { const a = C.P([MX + 0.9, 15, MZ - 0.3]), b = C.P([MX + 2.6, 26, MZ - 1.4]), L = Math.hypot(b[0] - a[0], b[1] - a[1]); return `<path d="M${P2(a)}L${P2(b)}" stroke="#d8302a" stroke-width="${f1(0.8 * k)}" stroke-dasharray="${f1(k * 0.9)} ${f1(k * 0.9)}"/>`; })()
        + `<g transform="${tanF(C, MX, MZ, 4.03, C.thV, 8)}"><rect x="-3" y="-2" width="6" height="4" fill="#3a6aa8"/><text x="0" y="0.6" text-anchor="middle" font-family="Georgia,serif" font-size="1.3" fill="#ffffff">MILK</text></g>`;
      const nap = box3(C, { c: [10, 0, 19], w: 13, h: 1.4, d: 8, r: 0.6, col: '#efe8da', olw: 0.25, olc: '#a89a80', dec: { t: `<rect width="13" height="8" fill="#efe8da"/><path d="M0 4H13M6.5 0V8" stroke="#c8bca4" stroke-width="0.3"/><rect x="0.6" y="0.6" width="11.8" height="6.8" fill="none" stroke="#b8a888" stroke-width="0.2" stroke-dasharray="0.6 0.4"/>` } });
      const dome = glow + crumbs + stack + lift + steam;
      let s = shadow(C, BXc, BZ, 24, 22, 0.55) + shadow(C, PX, PZ, 9, 8, 0.4) + vsort(C, [{ q: [BXc, 10, BZ], s: board + dome }, { q: [PX, 1, PZ], s: plate }, { q: [MX, 9, MZ], s: milk }, { q: [10, 0.5, 19], s: nap }]);
      C.p(0, TY + CH + 8, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // KIT-108 ROYAL PATISSERIE DISPLAY CASE (T5, Royal Collection): 128 x 60 kept, warm glow kept. An ivory lacquer cabinet with fluted doors, champagne-gold
  // knobs, a gold band and gold bun feet carries a glass display case with slim gold corner posts, a mirrored back, warm lights and a glass shelf. Inside:
  // a strawberry fraisier, a chocolate opera cake with a gold leaf, a lemon meringue tart and a raspberry dome below; a pyramid of pastel macarons, eclairs
  // and fruit tartlets on the shelf. On the Calacatta top: a three-tier cake on a gold stand under a crystal dome, a gold crowned "Pâtisserie Royale" crest,
  // a basket of warm croissants and a gold service bell. Alive: the case lights breathe, a glint sweeps the glass, the crest twinkles, the croissants steam.
  N.patis28 = S => { const IV = '#f3efe6', CG = '#d6b878', MB = '#f4f1ec';
    const veinsT = (R, w, h, tw) => rep(Math.ceil(w / tw), i => `<g transform="translate(${f1(i * tw)} 0)" opacity="0.75">${veins(R, tw, h)}</g>`).join('');
    const D = { w: 128, d: 60, glow: () => ({ y: 74, r: 64, c: 'url(#gWarm)' }), build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('patis28'), W = 120, Dp = 50, CY = 38, GY = 72, k = C.k, PXs = W / 2 - 1.2, PZs = Dp / 2 - 1.2;
      const feet = vsort(C, [[-W / 2 + 4, -Dp / 2 + 4], [W / 2 - 4, -Dp / 2 + 4], [-W / 2 + 4, Dp / 2 - 4], [W / 2 - 4, Dp / 2 - 4]].map(([x, z]) => ({ q: [x, 2, z], s: sph(C, [x, 2.2, z], 2.4, CG) })));
      const fl = (w, h, n) => rep(n, i => `<rect x="${f1(2 + i * (w - 4) / n)}" y="2.4" width="${f1((w - 4) / n * 0.62)}" height="${f1(h - 4.8)}" rx="${f1((w - 4) / n * 0.31)}" fill="#ffffff" opacity="0.28"/><rect x="${f1(2 + i * (w - 4) / n + (w - 4) / n * 0.62)}" y="2.4" width="0.25" height="${f1(h - 4.8)}" fill="#a89e8a" opacity="0.5"/>`).join('');
      const doorF = (w, h, nd) => { let s = `<rect width="${w}" height="1.6" fill="${CG}"/><rect y="${h - 1.4}" width="${w}" height="1.4" fill="${CG}"/>`; const dw = w / nd; for (let i = 0; i < nd; i++) s += `<g transform="translate(${f1(i * dw + 1.2)} 3.4)"><rect width="${f1(dw - 2.4)}" height="${f1(h - 7)}" rx="1" fill="none" stroke="${CG}" stroke-width="0.4"/>${fl(dw - 2.4, h - 7, 7)}</g><circle cx="${f1(i * dw + dw / 2)}" cy="${f1(h * 0.5)}" r="0.9" fill="${CG}"/><circle cx="${f1(i * dw + dw / 2 - 0.3)}" cy="${f1(h * 0.5 - 0.3)}" r="0.35" fill="#fff4d0"/>`; return s; };
      const cab = box3(C, clipF(C, { c: [0, 4.4, 0], w: W, h: CY - 4.4, d: Dp, r: 2, col: IV, olw: 0.4, olc: '#a89e8a', gl: 0.5, dec: { f: doorF(W - 4, CY - 4.4, 4), b: doorF(W - 4, CY - 4.4, 4), l: doorF(Dp - 4, CY - 4.4, 1), r: doorF(Dp - 4, CY - 4.4, 1), t: `<rect width="${W}" height="${Dp}" fill="${shade(IV, 0.97)}"/>` } }));
      const deck = box3(C, clipF(C, { c: [0, CY, 0], w: W, h: 1.6, d: Dp, r: 2, col: CG, olw: 0.3, gl: 0.6, dec: { t: `<rect width="${W}" height="${Dp}" fill="${MB}"/>` + veinsT(rng('pd108'), W, Dp, 30) + `<rect x="1.4" y="1.4" width="${W - 2.8}" height="${Dp - 2.8}" fill="none" stroke="${CG}" stroke-width="0.5"/>` } }));
      // mirrored back panel (drawn before the pastries when it faces away, after them from behind)
      const back = box3(C, clipF(C, { c: [0, CY + 1.6, -Dp / 2 + 1], w: W - 4, h: GY - CY - 1.6, d: 1.2, r: 0.2, col: '#b8b0a4', olw: 0.3, dec: { f: `<rect width="${W - 4.4}" height="${GY - CY - 1.6}" fill="#cfc8bc"/><rect width="${W - 4.4}" height="${GY - CY - 1.6}" fill="url(#k28ss)" opacity="0.8"/>` + rep(5, i => `<path d="M${f1(10 + i * 24)} 0L${f1(4 + i * 24)} ${GY - CY}" stroke="#ffffff" stroke-opacity="0.25" stroke-width="2"/>`).join(''), b: `<rect width="${W - 4.4}" height="${GY - CY - 1.6}" fill="${IV}"/>${fl(W - 4.4, GY - CY - 1.6, 14)}` } }));
      const light = (y) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], `<rect x="${-W / 2 + 4}" y="${-Dp / 2 + 3}" width="${W - 8}" height="${Dp - 6}" rx="6" fill="url(#k28amb)" opacity="0.55">${an('opacity', '0.4;0.7;0.4', 5)}</rect>`);
      const IY = CY + 1.6, SHY = 52;
      // lower tier: cakes on gold stands
      const cake = (x, z, r, h, c1, c2, top) => cyl3(C, [x, IY, z], [x, IY + 1.4, z], r * 0.5, CG, { r2: r * 0.9, mat: 'chrome', n: 24, olw: 0.25 }) + cyl3(C, [x, IY + 1.4, z], [x, IY + 1.4 + h, z], r, c1, { mat: 'matte', n: 28, olw: 0.3, olc: shade(c1, 0.5), cap: cr => `<circle r="${f1(cr)}" fill="${c2}"/>` + (top || '') })
        + `<g transform="${tanF(C, x, z, r + 0.03, C.thV, IY + 1.4 + h * 0.5)}">` + (c1 === '#f6efe2' ? rep(9, i => `<path d="M${f1(-r + 0.6 + i * r * 0.22)} -0.8a0.9 1.1 0 1 0 0.01 0Z" fill="#d8303a"/>`).join('') + `<rect x="${-r}" y="${f1(-h * 0.5)}" width="${2 * r}" height="${f1(h * 0.18)}" fill="#e8c0a0"/>` : c1 === '#3a2014' ? rep(4, i => `<rect x="${-r}" y="${f1(-h * 0.5 + i * h * 0.25)}" width="${2 * r}" height="${f1(h * 0.08)}" fill="${i % 2 ? '#c8945a' : '#5a3420'}"/>`).join('') : '') + `</g>`;
      const strw = cr => rep(7, i => { const a = i * 0.9; return `<path d="M${f1(Math.cos(a) * cr * 0.55)} ${f1(Math.sin(a) * cr * 0.55)}m-1 0a1 1.2 0 1 0 2 0a1 1.2 0 1 0 -2 0" fill="#d8303a"/><path d="M${f1(Math.cos(a) * cr * 0.55 - 0.4)} ${f1(Math.sin(a) * cr * 0.55 - 1.1)}l0.4 -0.6l0.4 0.6" fill="#4a8a3a"/>`; }).join('');
      const lowI = vsort(C, [{ q: [-38, IY + 5, 8], s: cake(-38, 8, 8.4, 7.4, '#f6efe2', '#f4c8c8', strw(8.4)) }, { q: [-14, IY + 5, 8], s: cake(-14, 8, 7.6, 6.6, '#3a2014', '#2a160e', `<path d="M-2 -1l2.4 -1l1 2l-2.6 1Z" fill="#f2c84a"/><path d="M-5 3Q0 1 5 3" stroke="#c8945a" stroke-width="0.4" fill="none"/>`) }, { q: [12, IY + 4, 9], s: cake(12, 9, 8, 3.4, '#e8c070', '#f6f0e0', rep(10, i => `<path d="M${f1(Math.cos(i * 0.63) * 4.6)} ${f1(Math.sin(i * 0.63) * 4.6)}m-1.2 0q1.2 -2.2 2.4 0z" fill="#f8f0e0" stroke="#d8a868" stroke-width="0.2"/>`).join('')) },
        { q: [36, IY + 5, 9], s: cyl3(C, [36, IY, 9], [36, IY + 1, 9], 6, CG, { r2: 6.4, mat: 'chrome', n: 24, olw: 0.25 }) + cyl3(C, [36, IY + 1, 9], [36, IY + 6.4, 9], 5.4, '#d8304a', { r2: 1.6, mat: 'gloss', n: 24, olw: 0.3, olc: '#7a1020' }) + sph(C, [36, IY + 7, 9], 1, '#d8303a') }]);
      // glass shelf + upper tier: macaron pyramid, eclairs, tartlets
      const shelfG = box3(C, { c: [0, SHY, 3], w: W - 6, h: 0.8, d: Dp - 14, r: 0.4, col: '#d8eef0', op: 0.35, olw: 0.25, olc: '#7aa8a8' });
      const MC = ['#f4b8c8', '#b8d8a0', '#c8b0e8', '#f8d890', '#a8d0f0', '#f4c8a0'];
      const mac = (x, y, z, c) => cyl3(C, [x, y, z], [x, y + 0.9, z], 1.6, c, { mat: 'matte', n: 14, olw: 0.2, olc: shade(c, 0.6) }) + cyl3(C, [x, y + 0.9, z], [x, y + 1.3, z], 1.4, '#fbf4e4', { n: 12, olw: 0.12 }) + cyl3(C, [x, y + 1.3, z], [x, y + 2.2, z], 1.6, c, { mat: 'matte', n: 14, olw: 0.2, olc: shade(c, 0.6) });
      const pyr = (() => { const L = [], x0 = -30, z0 = 9; [[5, 0], [4, 1], [3, 2], [2, 3], [1, 4]].forEach(([n, lv]) => { for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) L.push({ q: [x0 + (i - (n - 1) / 2) * 3.3, SHY + 0.8 + lv * 2.3, z0 + (j - (n - 1) / 2) * 3.3], c: MC[(i + j + lv) % 6] }); });
        return L.sort((a, b) => a.q[1] - b.q[1] || dot(a.q, C.v) - dot(b.q, C.v)).map(o => mac(o.q[0], o.q[1], o.q[2], o.c)).join(''); })();
      const ecl = (x, z) => cyl3(C, [x - 4.4, SHY + 2.1, z], [x + 4.4, SHY + 2.1, z], 1.3, '#d8a050', { mat: 'gloss', n: 14, olw: 0.25, olc: '#8a5420' }) + H2(C, [x - 4.2, SHY + 3.3, z], [x + 4.2, SHY + 3.3, z], 1.6, '#4a2414');
      const tart = (x, z, c) => cyl3(C, [x, SHY + 0.8, z], [x, SHY + 2.4, z], 2.6, '#e0b070', { r2: 2.8, mat: 'matte', n: 18, olw: 0.25, olc: '#8a5a2a', cap: cr => `<circle r="${f1(cr * 0.8)}" fill="#f8ecc8"/>` + rep(5, i => `<circle cx="${f1(Math.cos(i * 1.26) * cr * 0.45)}" cy="${f1(Math.sin(i * 1.26) * cr * 0.45)}" r="${f1(cr * 0.24)}" fill="${c}"/>`).join('') });
      const upI = vsort(C, [{ q: [-30, SHY + 4, 9], s: pyr }, { q: [-6, SHY + 2, 6], s: ecl(-6, 6) }, { q: [-6, SHY + 2, 13], s: ecl(-6, 13) }, { q: [12, SHY + 2, 6], s: tart(12, 6, '#d8303a') }, { q: [19, SHY + 2, 6], s: tart(19, 6, '#4a5ac8') }, { q: [12, SHY + 2, 13], s: tart(12, 13, '#f2a62a') }, { q: [19, SHY + 2, 13], s: tart(19, 13, '#7ab83a') }, { q: [33, SHY + 2, 9], s: mac(31, SHY + 0.8, 7, MC[0]) + mac(35, SHY + 0.8, 7, MC[2]) + mac(31, SHY + 0.8, 11, MC[4]) + mac(35, SHY + 0.8, 11, MC[1]) + mac(33, SHY + 3, 9, MC[3]) }]);
      // glass skin (near faces only, drawn over the pastries) + corner posts + top
      const glass = box3(C, { c: [0, CY + 1.6, 0], w: W - 1.6, h: GY - CY - 1.6, d: Dp - 1.6, r: 0.4, col: '#e2f2f2', op: 0.16, olw: 0.3, olc: '#9ac0c0', dec: { f: glintT(C, W - 2.4, GY - CY - 1.6, 9, 6), l: glintT(C, Dp - 2.4, GY - CY - 1.6, 9.6, 4), r: glintT(C, Dp - 2.4, GY - CY - 1.6, 10.2, 4) } });
      const PS = [[-PXs, -PZs], [PXs, -PZs], [-PXs, PZs], [PXs, PZs]], near = (x, z) => x * C.v[0] + z * C.v[2] > 0, post = ([x, z]) => ({ q: [x, 55, z], s: cyl3(C, [x, CY + 1.6, z], [x, GY, z], 1, CG, { mat: 'chrome', n: 12, olw: 0.22 }) });
      const top = box3(C, clipF(C, { c: [0, GY, 0], w: W + 2, h: 1.2, d: Dp + 2, r: 2, col: CG, olw: 0.3, gl: 0.6 })) + box3(C, clipF(C, { c: [0, GY + 1.2, 0], w: W + 1, h: 3.2, d: Dp + 1, r: 2, col: MB, olw: 0.35, olc: '#9a948a', dec: { t: `<rect width="${W + 1}" height="${Dp + 1}" fill="${MB}"/>` + veinsT(rng('pt108'), W + 1, Dp + 1, 30), f: veins(rng('pf108'), W - 3, 3.2), b: veins(rng('pb108'), W - 3, 3.2), l: veins(rng('pl108'), Dp - 3, 3.2), r: veins(rng('pr108'), Dp - 3, 3.2) } }));
      const TT = GY + 4.4;
      // top things: tiered cake under a crystal dome, crest, croissant basket, service bell
      const tc = (() => { const x = -34, z = -2; let s = cyl3(C, [x, TT, z], [x, TT + 1, z], 7, CG, { r2: 9, mat: 'chrome', n: 26, olw: 0.25 }) + cyl3(C, [x, TT + 1, z], [x, TT + 4, z], 1.4, CG, { mat: 'chrome', n: 14, olw: 0.2 }) + cyl3(C, [x, TT + 4, z], [x, TT + 4.8, z], 10, CG, { mat: 'chrome', n: 30, olw: 0.25 });
        [[8.4, 5], [6.2, 4.4], [4, 4]].reduce((y, [r, h], i) => { s += cyl3(C, [x, y, z], [x, y + h, z], r, '#fbf6ee', { mat: 'matte', n: 28, olw: 0.3, olc: '#b8a890', cap: cr => `<circle r="${f1(cr * 0.85)}" fill="none" stroke="#e8c8a0" stroke-width="0.4"/>` }) + `<g transform="${tanF(C, x, z, r + 0.03, C.thV, y + h * 0.5)}">${rep(Math.round(r * 1.4), j => `<circle cx="${f1(-r + 0.8 + j * 1.4)}" cy="${f1(h * 0.3)}" r="0.45" fill="#f4ecd8" stroke="#d8c8a8" stroke-width="0.12"/>`).join('')}<path d="M${-r} ${f1(-h * 0.2)}H${r}" stroke="${CG}" stroke-width="0.35"/></g>`; return y + h; }, TT + 4.8);
        s += sph(C, [x - 2, TT + 18.6, z + 1], 1.3, '#f4b8c8') + sph(C, [x + 1, TT + 18.8, z], 1.2, '#f8f0f0') + sph(C, [x, TT + 18.4, z + 2], 1, '#d8303a');
        s += cyl3(C, [x, TT + 4.8, z], [x, TT + 20, z], 10.4, '#eef6f6', { r2: 9.4, mat: 'chrome', n: 30, op: 0.22, olw: 0.3, olc: '#8aa4aa', noCap: 1 }) + cyl3(C, [x, TT + 20, z], [x, TT + 24.6, z], 9.4, '#eef6f6', { r2: 1.6, mat: 'chrome', n: 28, op: 0.22, olw: 0.3, olc: '#8aa4aa', noCap: 1 }) + sph(C, [x, TT + 25.6, z], 1.8, CG);
        return s; })();
      const crest = (() => { const q = [0, TT, -Dp / 2 + 4], s = PLN(C, [q[0] - 15, TT + 13, q[2]], [1, 0, 0], [0, -1, 0], `<path d="M0 4Q15 -2 30 4V12Q15 10 0 12Z" fill="url(#k28brs)" stroke="#8a6a2a" stroke-width="0.4"/><path d="M1.4 5Q15 0 28.6 5" stroke="#fff4d0" stroke-width="0.3" fill="none" opacity="0.7"/>` + (vis(C, [0, 0, 1]) ? `<text x="15" y="9.2" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-size="3" fill="#5a3a12">Pâtisserie Royale</text>` : `<path d="M3 8H27" stroke="#8a6a2a" stroke-width="0.3" opacity="0.6"/>`)
          + `<g transform="translate(15 1.4)"><path d="M-4 0L-4.6 -4L-2 -2L0 -5L2 -2L4.6 -4L4 0Z" fill="url(#k28brs)" stroke="#8a6a2a" stroke-width="0.3"/><circle cy="-5.2" r="0.6" fill="#d8303a"/><circle cx="-4.6" cy="-4.2" r="0.45" fill="#f4f0e6"/><circle cx="4.6" cy="-4.2" r="0.45" fill="#f4f0e6"/></g>`
          + [[4, 6], [26, 5], [15, -4.6], [9, 10]].map(([x, y], i) => `<path d="M${x} ${f1(y - 1.4)}Q${x + 0.15} ${f1(y - 0.15)} ${x + 1.4} ${y}Q${x + 0.15} ${f1(y + 0.15)} ${x} ${f1(y + 1.4)}Q${f1(x - 0.15)} ${f1(y + 0.15)} ${x - 1.4} ${y}Q${f1(x - 0.15)} ${f1(y - 0.15)} ${x} ${f1(y - 1.4)}Z" fill="#ffffff" opacity="0">${an('opacity', '0;1;0;0', 2.6, -i * 0.7, KT('0;0.15;0.3;1'))}</path>`).join(''));
        return [-8, 8].map(x => cyl3(C, [x, TT, q[2]], [x, TT + 3, q[2]], 0.6, CG, { mat: 'chrome', n: 10, olw: 0.2 })).join('') + s; })();
      const crois = (() => { const x = 20, z = 2; let s = box3(C, { c: [x, TT, z], w: 18, h: 4, d: 11, r: 3, col: '#b98a4e', olw: 0.3, olc: '#6a4a24', dec: { t: `<rect width="18" height="11" fill="#f2ece0"/>`, f: rep(3, r => rep(8, c => `<rect x="${f1(c * 1.6 + (r % 2) * 0.8)}" y="${f1(r * 1.3)}" width="1.3" height="1" rx="0.4" fill="#d8a868" opacity="0.6"/>`).join('')).join('') } });
        const cr = (q, a) => { const p = C.P(q); return `<g transform="translate(${P2(p)}) rotate(${a}) scale(${n4(k * 1.1)})"><path d="M-4.2 0.8Q-3 -2.6 0 -2.8Q3 -2.6 4.2 0.8Q2 0 0 0.4Q-2 0 -4.2 0.8Z" fill="#d89a4a" stroke="#8a5420" stroke-width="0.3"/><path d="M-2.2 -1.8Q-1.4 0 -1.6 0.3M0 -2.6V0.3M2.2 -1.8Q1.4 0 1.6 0.3" stroke="#8a5420" stroke-width="0.35" fill="none"/><path d="M-3 -0.6Q-1.6 -2 0 -2.2" stroke="#f8d8a0" stroke-width="0.45" fill="none" opacity="0.8"/></g>`; };
        return s + cr([x - 4, TT + 6, z - 1], -10) + cr([x + 4, TT + 6, z - 1.4], 12) + cr([x, TT + 6.4, z + 2], 3) + puff1(C, [x - 2, TT + 8, z], 0.6, 5.4, 0.1, 0.7, 0) + puff1(C, [x + 3, TT + 8, z], 0.5, 5.4, 0.1, 0.7, -2.7); })();
      const bell = (() => { const x = 44, z = 8; return cyl3(C, [x, TT, z], [x, TT + 0.8, z], 3.4, '#3a2a1a', { mat: 'gloss', n: 20, olw: 0.25 }) + cyl3(C, [x, TT + 0.8, z], [x, TT + 3.6, z], 3, CG, { r2: 1.4, mat: 'chrome', n: 22, olw: 0.25, noCap: 1 }) + cyl3(C, [x, TT + 3.6, z], [x, TT + 4.6, z], 1.4, CG, { r2: 0.5, mat: 'chrome', n: 16, olw: 0.2, noCap: 1 }) + sph(C, [x, TT + 5, z], 0.7, CG); })();
      const topI = vsort(C, [{ q: [-34, TT + 10, -2], s: tc }, { q: [0, TT + 6, -Dp / 2 + 4], s: crest }, { q: [20, TT + 3, 2], s: crois }, { q: [44, TT + 2, 8], s: bell }]);
      const bF = vis(C, [0, 0, 1]);
      let s = shadow(C, 0, 0, 66, 32, 0.6) + feet + cab + deck + light(IY + 0.05) + vsort(C, PS.filter(p => !near(p[0], p[1])).map(post)) + (bF ? back : '') + lowI + shelfG + light(SHY + 0.85) + upI + (bF ? '' : back) + glass + vsort(C, PS.filter(p => near(p[0], p[1])).map(post)) + top + topI;
      C.p(0, TT + 28, 0);
      return { defs: DEFF, front: s, bb: C.bb(6) }; };
    return D; };

  // ---------- catalog edits ----------
  const CP = { play: 'open', playL: 'Open the door', stopL: 'Close the door', playS: 'Door open · light on · tap to close', idleS: 'Tap to open the door' };
  RD.SET28 = {
    'KIT-068': { spec: 'cloche28', live: 'Warm cookie steam', note: 'A tall hand-blown crystal cloche with a polished brass knob on a round Calacatta marble board with a brass rim, over a warm stack of chunky chocolate-chip cookies glowing softly underneath. Every few seconds the cloche lifts a little and a breath of warm steam escapes, and a glint slides round the crystal. Beside it a gold-rimmed plate with two more cookies, a glass bottle of milk with a striped paper straw and a folded linen napkin.' },
    'KIT-108': { spec: 'patis28', live: 'Royal Collection', note: 'Royal Collection: the most expensive piece in this room. An ivory lacquer cabinet with fluted doors, champagne-gold knobs and gold bun feet under a glass case with slim gold posts, a mirrored back and warm lights that breathe. Inside: a strawberry fraisier, a chocolate opera cake with gold leaf, a lemon meringue tart and a raspberry dome below, and a pyramid of pastel macarons, eclairs and fruit tartlets on the glass shelf. On the Calacatta top: a three-tier cake on a gold stand under a crystal dome, a twinkling gold crowned Pâtisserie Royale crest, a basket of steaming croissants and a gold service bell.' },
    'KIT-008': { spec: 'cer28', live: 'Soap bubbles', note: 'A battered box of Frooty Rings with a crushed corner, the top flap torn open and the crinkly liner bag poking out, next to a bowl of soggy rings in milk with a spoon, a few rings and a splash of milk on the floor. A half-empty green Lemon Fresh dish soap bottle with a crusty flip cap and a peeling label, and a grimy two-tone sponge. Every so often a soap bubble drifts up from the cap and pops.' },
    'KIT-028': { spec: 'fruit28', live: 'Swaying bananas', note: 'A round black wire fruit basket on little ball feet piled with red and green apples, oranges, a pear and a bunch of grapes, with a curly wire hook holding a hand of ripe bananas that sways gently. Beside it a big glass cookie jar with a pale wood lid and a ceramic knob, half full of chocolate-chip cookies, a kraft "yum" tag on twine round its neck, and one cookie with crumbs on a little plate in front. A glint slides across the glass now and then.' },
    'KIT-048': { spec: 'mort28', live: 'Grinding pestle', note: 'A heavy Carrara marble mortar with grey veins full of crushed peppercorns, rosemary and garlic, its pestle grinding in slow circles and flicking up a fleck now and then. A glass cruet of golden-green olive oil with a slim steel pourer, a soft light drifting through the oil, and a glazed terracotta salt pig of flaky salt with an olive-wood spoon. A sprig of rosemary and a garlic bulb lie beside them.' },
    'KIT-043': { spec: 'bar28', live: 'Fizzing G&T', note: 'A vintage bar cart in polished brass tube with two tempered-glass shelves in brass rails, a low gallery rail round the top, two big spoked brass wheels at one end and brass ball feet under a curved push handle at the other. On top: a cut-crystal decanter of whisky, two tumblers (one with ice), a hammered cocktail shaker, a gin and tonic with a lime wedge and rising bubbles, a bowl of lemons and limes and a bud vase of pink ranunculus that nod. Through the glass below: gin, a bottle of red, a brass ice bucket with tongs and a stack of linen napkins. A glint slides across each glass shelf now and then.' },
    'KIT-063': { spec: 'pastry28', live: 'Swaying copper pans', note: 'An oiled walnut baker\'s cart on brass casters under a thick honed Calacatta pastry slab, with a slatted lower shelf holding a linen-lined basket of flour sacks and a stack of baking tins. Two polished brass uprights rise from the back to a rail where a copper saucepan, a sauté pan and a little butter warmer hang from S-hooks and sway, glints sliding round their rims. On the marble: a block of laminated dough dusted with flour, a brass-handled French rolling pin, a bench scraper, a tray of golden croissants still steaming, a jar of flour with a brass scoop and a jug of lavender. Flour motes drift over the slab.' },
    'KIT-083': { spec: 'robo28', live: 'Lifting the cloche', note: 'Rolls back and forth delivering. A polished ivory ceramic robot cart with champagne-gold trims, floating on a dark base over a warm amber glow while a light chases round it. A black-glass strip reads TABLE 4 · 0:42. On its gold gallery tray: seared scallops under a silver cloche, a dish of macarons and a flute of champagne with rising bubbles. At the back a slim gold neck carries a friendly black-glass face with amber eyes that blink; the head tilts now and then, and every few seconds a jointed gold arm lifts the cloche and steam curls out.' },
    'KIT-099': { spec: 'lev28', live: 'Levitating', note: 'A bar stool that hovers a hand\'s width above a black-glass disc in a champagne-gold plinth, held up by a warm amber beam. A gold hover bell, a fluted gold hydraulic sleeve with a little 78 height readout whose arrows pulse, a gold collar and a mirror-chrome piston carry an ivory nappa seat with channel stitching and champagne nailheads and a low curved nappa back capped in gold. The gold foot ring floats on its own round the sleeve. A gold halo turns in the hover gap as motes drift up through it, gold ticks circle in the glass and the glow underneath breathes slowly.' },
    'KIT-003': { spec: 'pcart28', live: 'Swaying grocery bag', note: 'A cheap three-tier rolling cart in off-white plastic gone yellow, on four grey swivel casters (one wheel swapped for a black one that doesn\'t match). Scuffs, grime in the corners, a cracked top lip patched with clear tape and a half-peeled $9.99 sticker whose corner flutters. On top: a paper towel roll, a ketchup bottle stored upside down on its cap over a crusty red stain, three speckled bananas and a jar of peanut butter. Middle: a stack of canned soup and beans, a box of Crunch-O\'s and two ramen cups. Bottom: a bleach jug, a blue spray bottle and a red mesh bag of onions. A white THANK YOU grocery bag hangs from the push handle and sways.' },
    'KIT-023': { spec: 'wire28', live: 'Blinking 12:00', note: 'A matte black wire stand on levelling feet with a carbonised bamboo top, a bamboo slat middle shelf with a back rail and a wire-grid bottom shelf. A white microwave with a smoky mesh window and a sticky note that says 2 MIN STIR!, its clock still blinking 12:00. A pothos on top of the microwave trails vines down the side that sway, next to a speckled crock of wooden spoons and a blue dish of lemons. Middle: nested mixing bowls, a jar of pasta and a basket of mint, chai and chamomile tea. Bottom: two big bottles of spring water and a twin pack of paper towels. An oven mitt and a striped tea towel hang from S-hooks on the side and sway.' },
    'KIT-030': { spec: 'shk28', live: 'Steaming tea', note: 'Warm white shaker drawers and doors with brushed nickel cup pulls and knobs (a couple of scuffs down by the kick) under a thick oiled oak butcher block, with a white subway-tile splash. A crusty loaf and two slices wait on a board with a bread knife, beside a jar of wooden spoons, a bowl of apples and a mug of tea that steams. An open cookbook on a wooden stand shows Apple Crumble, its page lifting now and then. A red gingham towel sways on the drawer pull.' },
    'KIT-050': { spec: 'navy28', live: 'Soft-close drawer', note: 'Deep navy slim-shaker cabinets with brushed brass bar pulls under a speckled white quartz top and splash. Every so often the cutlery drawer glides open on a bamboo organizer of forks, spoons, knives and a whisk, then closes slowly and silently. On top: glass canisters of pasta and coffee beans with bamboo lids, a sourdough boule on a round board, a white bowl of oranges and eucalyptus swaying in a slim white vase.' },
    'KIT-070': { spec: 'wal28', live: 'Candlelight', note: 'Book-matched walnut drawers with polished brass finger-pull strips (a glint runs along them now and then) over fluted walnut doors with round brass knobs, floating on a recessed plinth above a warm amber glow. A thick honed soapstone top and tall splash in soft grey-green with pale veins. A beeswax pillar candle flickers beside a cream stoneware vase of swaying olive branches, a brass tray with a crystal decanter of whisky and two tumblers, and a walnut bowl of figs.' },
    'KIT-090': { spec: 'obs28', live: 'Lift cabinet & self-healing stone', note: 'A U-shaped kitchen in seamless polished obsidian: deep black stone with smoky depths, fine champagne-gold veins and a slow reflection across the top, waterfall ends on both runs, handle-less smoked-obsidian fronts with gold reveals and finger channels floating over a warm amber glow. A glass-fronted lift cabinet of crystal wine glasses, plates, gold-rimmed cups and spice jars glides silently down into the counter until its cap is flush, then rises again. Now and then a knife scratch appears in the stone, a thread of molten gold runs along it and it fades back into seamless obsidian. A white orchid in a gold pot, a chocolate cake under a glass dome, a hammered-gold bowl of pomegranates and espresso for two on a gold tray.' },
    'KIT-013': { spec: 'card28', live: 'Wobbly table', note: 'A wobbly folding card table under a red gingham vinyl cloth with fold creases, a coffee ring, a ketchup smear, a cigarette burn and a taped-up tear. The black enamel legs are chipped down to bare steel, and one has lost its rubber foot and stands on a folded piece of cardboard. Every few seconds the whole table rocks. On top: a steaming takeout box of noodles with chopsticks, a paper plate with a leftover pizza crust and a dented can of soda with a straw.' },
    'KIT-033': { spec: 'cart28', live: 'Rolling pin', note: 'A rolling pine prep cart with a thick edge-grain butcher-block top (knife marks and a water ring), a drawer with a white knob, a slatted lower shelf with wicker baskets of potatoes and onions, and four rubber casters, two with red brake tabs. A green-striped towel sways on the chrome bar at one end; a ladle, a whisk and a wooden spoon swing from S-hooks at the other. On top a rolling pin rolls back and forth over a floury sheet of dough, next to a blue bowl of brown eggs and carrots with a paring knife.' },
    'KIT-053': { spec: 'bist28', live: 'Morning coffee', note: 'A round four-person bistro table in oiled white oak: a plank top with a soft bevelled edge on a turned oak pedestal with four splayed feet. Four woven rattan placemats; one is set with a croissant and a cup of coffee that steams, another with a folded linen napkin and a fork. Salt and pepper mills and a speckled vase of yellow tulips swaying in the middle, with dappled sunlight drifting slowly across the top.' },
    'KIT-073': { spec: 'cal28', live: 'Prep-sink rinse', note: 'A waterfall Calacatta island: a book-matched marble slab that falls to the floor at both ends, over deep emerald lacquer slim-shaker drawers and doors with polished brass bar pulls. An undermount marble prep sink with a brass gooseneck: every so often the tap runs over a brass colander of grapes, and a glint slides along the marble edge under a warm pendant glow. White peonies in a glass vase, a walnut board with cheese, figs and grapes, and a carafe of lemon water with two tumblers.' },
    'KIT-093': { spec: 'tep28', live: 'Sizzling teppanyaki', note: 'A chef\'s island in fluted walnut with champagne-gold reveals over a warm amber glow, under a thick Nero Marquina slab that cantilevers far out past the base. The floating end holds a brushed-steel teppanyaki plate in a gold rim: shrimp, scallops and zucchini sizzle and hop, steam curls up, heat shimmers and a gold-handled spatula scrapes the plate. The smart scale is a flush black-glass square in a gold rim, its amber readout weighing a slate of marbled wagyu. A black bowl of yuzu and a sake set on a walnut tray.' },
    'KIT-102': { spec: 'oak28', live: 'Candlelight', note: 'Table only - fits 4 dining chairs (sold separately). A round table with a bullnosed Carrara marble top over a thin brass inlay ring and an oak apron, on a turned oak pedestal with four sabre feet in brass toe caps. Four places are set with gold-rimmed chargers, white plates, linen napkins, cutlery and wine glasses around a ceramic bowl of clementines between two brass candlesticks whose tapers flicker, while a soft sweep of light crosses the marble.' },
    'KIT-103': { spec: 'trest28', live: 'Candlelight', note: 'Table only - fits 6 dining chairs (sold separately). A book-matched Calacatta marble slab on a walnut apron over two solid walnut trestles joined by a stretcher with wedged through-tenons. A sage linen runner carries a long walnut dough bowl of lemons, olive branches swaying in a stoneware jug, three brass candlesticks with flickering tapers, and a bottle of red with two glasses.' },
    'KIT-104': { spec: 'ebon28', live: 'Candelabra glow', note: 'Table only - fits 8 dining chairs (sold separately). A banquet table in gloss ebony: two turned pedestals on gold bun feet with fluted shafts, gold rings and rosettes, joined by a stretcher with a gold urn finial, under an apron with gold beading and a gold band. The Nero Marquina top glows with smoky depth and fine gold veins. A burgundy velvet runner with gold borders holds two five-light gold candelabra flickering over warm pools of light, red roses in a gold urn, and champagne on ice in a silver bucket beside two coupes with rising bubbles.' },
    'KIT-016': { spec: 'plst28', live: 'Buzzing fly', note: 'A faded turquoise plastic stacking stool with a hand-knit pink and orange seat cozy that doesn\'t match at all; its two pompom ties sway. One cracked leg is wrapped in grey duct tape, three legs still have black rubber feet and the fourth stands on a red bottle cap. A half-peeled $2.99 sticker and scuffs on the skirt, and a fly that circles lazily above it.' },
    'KIT-036': { spec: 'wind28', live: 'Swaying cushion ties', note: 'A comb-back Windsor chair in sage milk paint: turned legs on an H-stretcher, a carved saddle seat and six spindles between two posts up to a crest rail with scrolled ears. The paint is rubbed back to warm maple on the seat front, the ears and the stretchers where feet rest. A red gingham tie-on cushion, its ties swaying at the back posts.' },
    'KIT-056': { spec: 'thon28', live: 'Swaying scarf fringe', note: 'A classic bentwood bistro chair in dark walnut-stained beech: four tapered legs with felt pads, a bent leg ring fixed with little brass screws, and a round seat with a woven cane insert in a bent rim. The back posts rise into a big loop with a smaller loop and a cross rail inside, leaning gently back. A mustard knit scarf is draped over the top, its fringe swaying.' },
    'KIT-076': { spec: 'bcl28', live: 'Swaying throw', note: 'A nubbly ivory bouclé dining armchair: a plump round seat on a brushed-brass plinth and four tapered brass legs, low curved arms capped with a brass band and a rounded back rising behind them. A caramel cashmere throw lies over one arm, its fringe swaying, and now and then a glint slides down the brass legs.' },
    'KIT-096': { spec: 'pod28', live: 'Warm heated glow', note: 'A polished ivory ceramic egg pod floating a hand\'s width above a black-glass disc in a champagne-gold rim: a rounded bowl, a cognac leather seat and a hood that curves up round the back like an egg, with a tufted leather back pad inside. The seat breathes a warm amber glow, heat shimmers above it, warm light pools under the pod and a ring of gold ticks turns slowly in the glass.' },
    'KIT-105': { spec: 'lin28', live: 'Swaying ribbon', note: 'An oiled walnut dining chair with tapered front legs in brass caps and back legs that rise into posts with turned finials. A thick linen seat with brass nailheads along the front and a button-tufted linen back with diamond pleats, in your colour. A sage silk ribbon bow with a sprig of eucalyptus is tied to the back of the top rail, its tails swaying.' },
    'KIT-106': { spec: 'chan28', live: 'Velvet sheen', note: 'A dining chair on slim tapered brushed-brass legs and a brass seat frame, with a plump velvet seat and a tall rounded channel-back in velvet, wrapped in a brushed-brass shell. The sheen drifts slowly across the velvet as the light moves, and a glint slides down the brass legs now and then. Pick the velvet colour.' },
    'KIT-107': { spec: 'royal28', live: 'Twinkling gold leaf', note: 'A royal dining chair in gloss ebony: turned legs with gold-leaf bands and gold ball feet, a seat rail with a gold-leaf bead and rosettes, and an oval medallion back in an ebony frame with a gold-leaf ring and a little gold crown on top. The deep button-tufted velvet seat and back have gold buttons. The velvet sheen drifts and the gold leaf twinkles. Pick the velvet colour.' },
    'KIT-019': { spec: 'shop28', live: 'Swaying shop rag', note: 'A tall steel garage shop stool gone orange with rust: four splayed legs, a foot ring bent in four pieces, a threaded height screw under the seat and a cracked black vinyl pad patched with duct tape. Three legs still have rubber feet; the fourth is bare and scraped. A greasy red shop rag hangs over the foot ring and sways, and every so often a flake of rust drops to the floor.' },
    'KIT-039': { spec: 'sad28', live: 'Swaying tea towel', note: 'A backless honey-oak saddle barstool: a carved seat with a gentle dip and a raised front, on four splayed oak legs joined by a square of rungs; the front rung is worn pale where feet rest. A blue-striped tea towel is draped over one side of the seat and sways.' },
    'KIT-059': { spec: 'trac28', live: 'Swinging leather strap', note: 'An industrial swivel stool: a black cast-iron base with four splayed legs on wide pads, rivets and a foot ring, a threaded swivel column and a pressed-iron tractor seat with drain slots round the rim. On top, a cognac leather pad with stitching and a ring of brass nailheads, its warm sheen shifting slowly. A leather strap with a brass buckle hangs from the seat and swings.' },
    'KIT-079': { spec: 'vel28', live: 'Velvet sheen', note: 'A counter stool in emerald velvet: a plump round button-tufted seat with gold buttons on a brushed-brass ring, a low curved velvet back with a brass band, four slim brass legs and a brass footrest ring. The velvet sheen drifts slowly and glints slide down the brass legs.' },
    'KIT-062': { spec: 'ham28', live: 'Glass rinser & pot-filler', note: 'A deep hammered-brass workstation sink in a cream Taj Mahal quartzite top, over bottle-green lacquered shaker cabinets with polished brass cup pulls and knobs and a warm glow under the toe kick. A walnut board of rainbow carrots and a chef\'s knife glides along the brass ledges inside the basin, and a glint of light slides round the polished rim. Beside the brass gooseneck, a glass rinser presses an upside-down wine glass and jets it clean, and a brass wall pot-filler swings out over a hammered copper stockpot, fills it and lets it steam. A striped linen towel sways on the brass bar, next to a brass bowl of pears.' },
    'KIT-082': { spec: 'wave28', live: 'Ultrasonic ripples & instant tap', note: 'A Royal Calacatta L-kitchen: fluted ivory lacquer runs with champagne-gold reveals floating over a soft amber glow, a book-matched marble top with a waterfall end and low marble backsplashes. The integrated marble basin is trimmed with a gold inlay; soft ultrasonic rings ripple across the water from a glowing gold ring while fine bubbles rise round a crystal glass and a bowl of strawberries. A sculptural gold arc faucet stands over it. Beside it the instant tap cycles its modes: boiling water into a gold-rimmed teacup, sparkling water into a coupe and golden broth into a celadon bowl. A bowl of lemons, white hydrangeas and a marble tray with olive oil and salt.' },
    'KIT-010': { spec: 'curt28', live: 'Swaying curtain', note: 'A yellowed plywood counter with no doors, just a faded 70s daisy curtain on a sagging tension rod; one side is tied back with a gingham ribbon to show the shelves: a bucket and sponge, a bleach jug, a mousetrap with cheese, dented pots, a spray bottle and steel wool. The aqua boomerang laminate top has a ribbed aluminium edge with one length missing over chipped particleboard, a burn ring, knife cuts and a lifted seam. A bag of bread with a twist tie, red FLOUR and SUGAR tins and a stack of bills sit on top. The curtain sways, a line of ants marches to the bread and now and then a little mouse peeks out from behind the curtain.' },
    'KIT-002': { spec: 'leak28', live: 'Leaky tap drip', note: 'A shallow, dull stainless single bowl dropped into chipped beige laminate, with a rust halo round the crusty drain, water spots and scratches. The old two-handle chrome faucet has lost its cold cap, and a rag and duct tape are wrapped round its leaking base. Every couple of seconds a drop swells on the limescaled tap and plinks into a chipped "#1 DAD" mug. Below, a water-swollen laminate cabinet: the left door sags off a broken hinge, the right one has lost its knob, the edge banding is peeling and a "SAVE WATER!" sticker smiles on. A dingy dishcloth sways on the door. On the counter: a toothbrush cup, toothpaste, an almost-empty bottle of dish soap, a crusty sponge in a puddle and a pan of dried mac and cheese.' },
    'KIT-022': { spec: 'dbl28', live: 'Sprayer rinse', note: 'A brushed stainless double-bowl drop-in sink in speckled faux-granite laminate, over a light oak cabinet with raised-panel doors and brushed nickel pulls. The left bowl is full of soapy water over a couple of plates, suds drifting and bubbles popping; the right one holds a mug and a dish brush. A chrome pull-down faucet swings over the soapy side, and every few seconds its spray head gives the dishes a quick rinse. A blue-striped tea towel sways on the drawer pull. On the counter: a blue crock of spoons, a white soap pump, a sponge on a dish, two glasses drying on a mat and a pot of rosemary.' },
    'KIT-042': { spec: 'apron28', live: 'Running water', note: 'A deep, glossy white fireclay farmhouse sink with its apron standing proud of sage-green shaker cabinets with matte black cup pulls, under an oiled oak butcher-block top. A tall matte black gooseneck runs a thin, steady stream over an enamel colander of cherry tomatoes and radishes, droplets bouncing off. Now and then a glint of sunlight slides across the apron. A cream linen towel sways on the drawer pull. On the counter: an amber glass soap pump, basil in a white pot and an oak board with a halved lemon, a lemon and a paring knife.' },
    'KIT-015': { spec: 'dorm28', kind: 'fridge', cp: CP, live: 'Rattling compressor', note: 'A yellowed second-hand dorm cube on three wobbly feet and a folded cardboard shim. Dented door, a takeout menu under a pizza magnet, a photo strip, peeling smiley and EnergyGuide stickers, a scratched band sticker and a "my YOGURT!!" note. Duct tape holds the door shut, rust creeps along the bottom and cold mist seeps out of the tired seal into a little puddle. Every few seconds the compressor rattles the note and the spoon in the mug on top. Inside: a frosted-up freezer box, a wire shelf and some sad leftovers under a flickering bulb.' },
    'KIT-035': { spec: 'topf28', kind: 'fridge', cp: CP, live: 'Swaying towel', note: 'A compact warm-white top-freezer fridge with a chrome "Chillmate" script. The freezer holds a crayon drawing and letter magnets; the fridge door has a grocery list with a pencil swinging on a string, a beach postcard, coupons in a clip, fruit magnets and a gold-star certificate. A gingham towel sways on the handle, an oven mitt hangs on the side and a pothos trails over the top next to the cereal and a basket of rolls. Inside: crisper drawers of veg, three glass shelves of food, a warm bulb and door bins with bottles and eggs.' },
    'KIT-055': { spec: 'french28', kind: 'fridge', cp: Object.assign({}, CP, { playL: 'Open the doors', stopL: 'Close the doors', playS: 'Doors open · LED on · tap to close', idleS: 'Tap to open the doors' }), live: 'Ice drops', note: 'Brushed stainless French doors over a freezer drawer, long tubular bar pulls on standoffs and a recessed ice and water dispenser with a soft LED light and a 37° / 0° display. Now and then an ice cube drops into the tray. Glass canisters of pasta and a vase of eucalyptus stand on top. Inside: bright LED light, a deli drawer, glass shelves with stainless trims (grapes, cheesecake, sparkling water, lemon water) and clear door bins.' },
    'KIT-075': { spec: 'subz28', kind: 'fridge', cp: CP, live: 'Breathing wine light', note: 'A built-in chef\'s refrigerator and wine column clad in walnut with brass edge strips, a stainless face frame, a brass louvred grille and a little "SOUS·ZÉRO" plaque over a glowing toe-kick line. Through the glass door: warm LED light, brass-trimmed glass shelves, a parmesan wheel, a dry-aged parcel, berry punnets, a glass milk bottle, preserves, a lemon tart on a stand, champagne and basil in a glass of water. Next to it, behind bronze-tinted glass, seven walnut racks of wine lie necks-out under breathing amber light, with a decanter on top and a 12° display.' },
    'KIT-095': { spec: 'cryo28', kind: 'fridge', cp: CP, live: 'Inventory hologram', note: 'An ivory ceramic-glass mega-fridge veined like Calacatta marble and trimmed in champagne gold, floating on a recessed plinth over a soft glow. Smoked obsidian glass doors show a warm-lit pantry of sushi on slate, cold-pressed juices, figs and grapes, caviar on ice, strawberry shortcake, a macaron tower under a cloche, champagne, a cheese board and preserves, while a scan line quietly sweeps the shelves. A pearl hologram floats in front of the right door with a turning apple and live stock levels. Below, the frosted cryo drawer holds gelato pints in drifting frost at −18°; open the door and cryo fog spills to the floor.' },
    'KIT-038': { spec: 'coil28', kind: 'stove', cp: { play: 'cook', playL: 'Turn on', stopL: 'Turn off', playS: 'Coils glowing · pancakes flipping · tap to turn off', idleS: 'Tap to turn on' }, live: 'Ticking clock', note: 'A warm white enamel freestanding range with a chrome lip and "Hearthmate" script. Four coils sit in chrome drip bowls (two big, two small) under a backguard of chrome-skirted knobs, a little analog clock that ticks the seconds and SURFACE / OVEN lamps. A quilted red oven mitt sways on the chrome door handle over a black glass window, with a storage drawer below. A cast-iron skillet of pancakes, a red enamel kettle and a spoon rest with a wooden turner sit on top. Turn it on and the coils glow, the oven window lights up on a tray of cookies, a pancake flips and the kettle steams and whistles.' },
    'KIT-058': { spec: 'gas28', kind: 'stove', cp: { play: 'cook', playL: 'Light the burners', stopL: 'Turn off', playS: 'Flames on · fan spinning · tap to turn off', idleS: 'Tap to light the burners' }, live: 'Blinking clock', note: 'A brushed stainless pro range with an island trim and three continuous matte cast-iron grates over five sealed burners, the middle one a dual-ring wok burner. Stainless knobs sit in red bezels around a blue LED display, and a big black glass convection door shows the rear fan and racks above vented kick plates. An orange enamel cocotte, a carbon-steel wok of stir-fry and a stainless pasta pot sit on the grates. Light it and blue flame rings flicker under all three, the bezels glow, the fan spins behind the glass with a chicken roasting, stir-fry hops out of the wok, the cocotte lid rattles and the pasta water boils.' },
    'KIT-078': { spec: 'herit28', kind: 'stove', cp: { play: 'cook', playL: 'Light the range', stopL: 'Turn off', playS: 'French top glowing · ovens heating · tap to turn off', idleS: 'Tap to light the range' }, live: 'Brass glints', note: 'A heritage French range in deep bleu nuit enamel with polished brass everywhere: bun feet, trims, eight fluted knobs and a MAISON DORÉE medallion between two jewel pilot lamps. A striped linen towel sways on the full-width brass rail as a glint slides along it. Below are a gas oven and a narrow electric oven, each with a brass-framed panel, a bar pull and a round thermometer. The black enamel deck has six brass-capped burners on cast-iron grates around a cast-iron French-top plaque. A copper stockpot with a bouquet garni and a copper saucier of béarnaise sit on top, and the brass-trimmed back shelf holds a utensil crock, a salt pig, olive oil and a pepper mill. Light it and flames lick the stockpot, the French top glows red from the centre with a heat shimmer, the lamps light and both thermometers climb.' },
    'KIT-098': { spec: 'ind28', kind: 'stove', cp: { play: 'cook', playL: 'Start cooking', stopL: 'Turn off', playS: 'Halos on · laser-bake running · tap to turn off', idleS: 'Tap to start cooking' }, live: 'Standby glow', note: 'A polished ivory quartz block veined in grey and gold with champagne-gold trims, floating on a dark recessed plinth over a soft glow. The top is one seamless slab: the four induction zones are only hinted by faint etched rings and tiny gold ticks. A black-glass touch band holds a zone map, an AURA display with a breathing standby light and a power slider, over a handle-less black-glass oven with a gold laser rail, a glass tray and a soufflé inside. A matte black sauté pan of seared scallops, a borosilicate glass pot of eggs and a marble salt cellar with a gold spoon sit on top. Start cooking and cyan halos ripple up through the stone under both pans with floating SEAR 210° / SIMMER 98° readouts, the scallops sizzle and bubbles rise through the glass pot; in the oven seven violet lasers flicker onto the soufflé, a scan line sweeps, the tray levitates and the soufflé rises.' },
    'KIT-006': { spec: 'pan28', kind: 'dish', live: 'Buzzing fly', note: 'An old "FARM FRESH" apple crate standing in as a counter, with a gingham towel hanging off the front. A blue plastic dishpan of greasy water hides a few plates under the surface, a sponge waits on the rim and a fly buzzes overhead. Beside it, a white wire drying rack sits on a drip tray with two mismatched mugs and a cutlery caddy, next to a squeezy bottle of green dish soap and a little stack of side plates. Wash up and the foam builds while the sponge scrubs and bubbles rise; when it\'s done, clean plates and bowls stand in the rack, dripping into the tray and sparkling.' },
    'KIT-026': { spec: 'mini28', kind: 'dish', live: 'Breathing ECO light', note: 'A glossy white 6-place countertop dishwasher on a little white rolling cart, with rolled towels and a box of SPARKL pods on the lower shelf. A grey faucet hose loops off the back. It has a drop-down door with a smoky window, a dark control strip with a display and four buttons, and a tub of pods on top next to a stack of dirty plates. Load it and the door drops with the rack rolled out; while it washes, the window glows blue with a spinning spray arm, water jets, drips running down the glass and suds, water runs through the hose and a puff of steam escapes. Then the rack comes out sparkling and steaming, and the display reads DONE.' },
    'KIT-046': { spec: 'qw28', kind: 'dish', live: 'Swaying towel', note: 'A brushed stainless built-in under a speckled quartz counter, with a black toe kick, a black-glass control strip (display, programme icons, start) and a QUIETWASH 42 dB door. A sage linen towel sways on the tubular bar handle, and an amber soap pump and a pot of basil sit on the counter beside the dirty dishes. Open it to see the stainless tub, an upper rack of glasses and mugs, and the lower rack rolled out onto the door with plates, bowls and a cutlery basket. It washes so quietly that only a red light and the time projected on the floor show it is running; at the end the door drops on sparkling, steaming dishes.' },
    'KIT-066': { spec: 'dd28', kind: 'dish', live: 'Breathing light lines', note: 'Two walnut drawer fronts with book-matched grain and slim brass edge lips, built in under a honed soapstone counter over a recessed black toe kick. Soft light lines glow in the gaps between the fronts: warm amber breathing at rest, a cyan shimmer running along them while it washes, with a puff of steam from the top slot. A wooden bowl of lemons, a linen napkin in a brass ring and the dirty plates with a wine glass sit on the counter. Load it and both drawers glide out: stainless tubs, glasses, mugs and a cutlery tray on top, plates, bowls and a cutlery basket below, and a little smart strip on the top drawer\'s edge. When it\'s done the drawers open on sparkling, steaming dishes.' },
    'KIT-086': { spec: 'plas28', kind: 'dish', live: 'Robot arm idling', note: 'A low graphite cabinet with iridescent edge strips, floating on a dark plinth over a violet glow, with a black-glass ring timer and a dish vault below. On top stand a glass plasma chamber with a violet emitter ring, a white-and-graphite robot arm with a cyan eye on its wrist, and a hovering glass plate rack. The arm lifts each dirty plate from the rack into the chamber; then violet plasma fills the glass with flickering arcs and a glow sweep while the ring timer fills, 30 seconds and done. Finally the arm shelves the gleaming plates back in the rack while steam curls out of the empty chamber.' },
    'KIT-007': { spec: 'drip28', live: 'Dripping & gurgling', note: 'A yellowed Brew-Rite 12-cup drip coffee maker with a cloudy reservoir window (running low), a used filter peeking out from under the lid, a coffee streak down the front and old stain rings on the base. The glass carafe is cracked and held together with masking tape, with a dark ring above the old coffee. The red ON light glows, a drip falls from the basket every couple of seconds, the crack weeps a drop that sizzles on the warming plate, steam rises from the pot and every few seconds the machine gurgles and puffs from its back vent. A chipped MONDAY mug of coffee steams beside it next to a sugar packet and a stirrer.' },
    'KIT-027': { spec: 'pod28', live: 'Brewing every few seconds', note: 'A glossy cherry-red Brew·Bud pod brewer with a clear water tank on the back, three cup-size buttons (the middle one ringed in breathing blue), a blinking amber DESCALE light and a slotted drip tray with old water spots. Every few seconds it brews: a little shudder, bubbles glug up the tank, a hiss of steam from the lid and a thin coffee stream into a polka-dot mug, then two last drips. A wire caddy of pods and a spent pod with a coffee puddle sit beside it.' },
    'KIT-047': { spec: 'esp28', live: 'Pulling shots', note: 'A brushed-chrome Italian dual-boiler espresso machine with two E61 group heads, lever paddles and walnut-handled portafilters, boiler and pump gauges, a red pilot lamp and a railed cup warmer of upside-down cups. Every few seconds it pulls two double shots into crema cups while the pump needle swings up to 9 bar, and the steam wand stretches milk in a steel pitcher. Beside it a black conical burr grinder with a bean hopper and grind dial trickles grounds into a dosing cup, next to a walnut tamper on a rubber mat.' },
    'KIT-067': { spec: 'bar28', live: 'Pouring latte art', note: 'A built-in barista wall: walnut cabinet under a Calacatta counter, a fluted walnut back wall with a floating shelf of bean jars, cups and syrup washing it in warm light. The black-enamel machine with a brass bezel and amber display is plumbed in with brass pipes, a red hand-wheel valve and a glass water filter. Every few seconds it pulls two shots while a brass arm tilts a steel pitcher and pours a latte-art heart that grows in the cup.' },
    'KIT-087': { spec: 'som28', live: 'Printing foam art', note: 'An ivory ceramic tower with champagne-gold trims floating over a warm glow. Its smoked-glass display shows a breathing flavour wheel and tasting notes cycling through Ethiopia, Colombia and Kenya, next to a pearl AI orb with an amber iris. In the arched brew bay a gold print head draws a little bear face into the foam of a glass cup, line by line. On top, a gold carousel of three bean hoppers (light, medium, dark) clicks round; a marble tasting paddle holds espresso, cold brew and nitro.' },
    'KIT-011': { spec: 'toast28', kind: 'toast', live: 'Chrome glint', note: 'A worn chrome two-slice toaster with scratches, a dent, fingerprints, rust freckles and a black "Toasty" badge, a burn smudge by the slot, a bakelite lever and browning dial, and a frayed cord with a tape patch. Two slices of bread wait on a chipped plate with a butter knife. Tap to pop the bread in: the lever goes down, the slots glow, the dial ticks round and heat shimmers up; after 5 seconds the toast springs up golden (one corner a bit burnt) and steams.' },
    'KIT-031': { spec: 'mix28', live: 'Whisking & blending', note: 'A retro tilt-head stand mixer and matching blender in your pastel: chrome hub and band, "Kitchenette" script and a speed lever. The balloon whisk spins through cake batter in a stainless bowl with splatters on the side, while the blender whirls a strawberry smoothie with a vortex and rising bubbles, its button lights running along the chrome panel. A bowl of strawberries sits on a gingham towel between them.' },
    'KIT-051': { spec: 'af28', live: 'Fan spinning', note: 'A matte black air-fryer oven: through the smoked glass the element glows and the convection fan spins behind a basket of fries and wings, with AIR FRY 200° and a timer counting down. Heat shimmers off the top vents. Next to it a clear sous-vide tub with a black circulator clipped on (57.0°), rising bubbles and ripples, and a vacuum-bagged steak with rosemary swaying in the water.' },
    'KIT-071': { spec: 'pasta28', live: 'Extruding bucatini', note: 'A brushed stainless blast chiller with copper trims, a frosted glass door over shelves of pasta nests, an amber -18° display and a copper dial, with cold mist sinking from the door. On top a hammered-copper PASTAIO extruder with a dough hopper and turning paddle pushes bucatini out of its bronze die; the cutter sweeps round and the pieces drop onto a semolina-dusted tray. A walnut drying rack of tagliatelle sways beside it.' },
    'KIT-091': { spec: 'syn28', live: 'Printing a fraisier', note: 'An ivory Calacatta block with champagne-gold trims floating over a warm glow. Under a glass cloche a gold gantry prints a fraisier layer by layer (sponge, cream with strawberry halves, pink glaze and berries) while the panel\'s progress bar fills. Beside it a gold emitter projects a pearl hologram of a macaron tower with a rising scan ring and orbiting sparkles. A croissant and three macarons wait on a gold tray sliding out of the front.' },
    'KIT-018': { spec: 'hotp28', kind: 'stove', cp: { play: 'cook', playL: 'Switch on', stopL: 'Switch off', playS: 'Coil glowing · noodles bubbling · tap to switch off', idleS: 'Tap to switch on' }, live: 'Sparking cord', note: 'A yellowed "HEAT-O-MATIC" single-burner hot plate balanced on an upside-down blue milk crate (the embossed DAIRYLAND letters read upside down). Greasy chrome drip pan with a heat-tinted ring, a black spiral coil, a dented saucepan of ramen with a wooden spoon and a salt shaker on the side. The frayed cord is patched with electrical tape (it sparks now and then) and runs into a cheap power strip. Switch it on and the coil glows red, the pilot light comes on and the noodles bubble and steam.' },
  };
  const edit27 = RD.edit;
  RD.edit = rows => edit27(rows).map(r => RD.SET28[r.id] ? Object.assign({}, r, RD.SET28[r.id]) : r);
  RD.H28 = { DEF28, DEFR, dent, scr, rust, fp, mag, leafS, wisp, puddle, hingeD, door, swing, cavity, gshelf, bottle, jar, cup, grapes, G, PLN, coilB, gasB, flames, grate, knob, barH, vsort };
  RD.PLUS28 = 1;
})();
