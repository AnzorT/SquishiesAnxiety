// Yard Mini Games: HOPSCOTCH (the backyard's Chalk Hopscotch Court). A rhythm game: your creature hops up the court on the beat.
// Press the right move as the ring closes on the next square: Hop (one square), Split (the double squares, two feet) or Leap (jump over the
// square with the stone). Perfect / Good / OK by timing; a wrong move or a missed beat costs a heart (3). Each lap the stone moves on and the beat speeds up.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add || !YG.cam) return setTimeout(go, 30); const { S, D, cl, lerp, r2, SFX } = YG;
  const ICON = '<svg viewBox="0 0 120 84" aria-hidden="true"><rect width="120" height="84" fill="#9fdc6e"/><path d="M30 84L44 6H76L90 84Z" fill="#d9d4cc"/>' +
    '<g stroke="#fff" stroke-width="1.6"><path d="M50 74H70V84H50Z" fill="#ffd1e8"/><path d="M51 62H69V74H51Z" fill="#fff3a8"/><path d="M52 51H68V62H52Z" fill="#c8f0b6"/><path d="M45 41H60V51H45ZM60 41H75V51H60Z" fill="#cfe6ff"/><path d="M53 32H67V41H53Z" fill="#ffd9b8"/><path d="M47 23H60V32H47ZM60 23H73V32H60Z" fill="#e4d4ff"/><path d="M54 15H66V23H54Z" fill="#ffd1e8"/><path d="M53 15Q60 4 67 15Z" fill="#fff3a8"/></g>' +
    '<ellipse cx="60" cy="57" rx="4" ry="2" fill="#8a8f99"/></svg>';
  const ROWS = [[1], [2], [3], [4, 5], [6], [7, 8], [9], ['HOME']], COL = ['#ffd1e8', '#fff3a8', '#c8f0b6', '#cfe6ff', '#ffd9b8', '#e4d4ff', '#ffd1e8', '#fff3a8'];
  const ACT = { hop: { c: '#ff5cae', t: 'Hop', k: ['ArrowLeft', 'a', 'A'] }, split: { c: '#3d9bff', t: 'Split', k: ['ArrowDown', 's', 'S'] }, leap: { c: '#ffb020', t: 'Leap', k: ['ArrowUp', 'w', 'W', ' '] } };
  YG.add({ id: 'hop', name: 'Hopscotch', item: 'Hopscotch Court', color: '#ff7fc0', icon: ICON, stars: [180, 420, 700], coinK: 0.08,
    hint: 'Pink = Hop · Blue = Split · Yellow = Leap over the stone',
    how: ['Press the move as the ring closes on the next square.', 'Pink Hop for one square, blue Split for the double squares, yellow Leap over the stone.', 'Keys: ← hop · ↓ split · ↑ leap. 3 hearts, the beat speeds up each lap.'],
    make(ctx) {
      const { bg, fg, W, H } = ctx, P = YG.cam(2.0, 2.2, 54, 245.7), Z0 = 0.35, RL = 0.5, SW = 0.5;
      YG.yard(bg, { hz: 54, trees: false });
      const rowZ = i => Z0 + RL * (i + 0.5), quad = (pts, a, p) => S('path', Object.assign({ d: 'M' + pts.map(q => { const s = P(q[0], 0, q[1]); return r2(s[0]) + ' ' + r2(s[1]); }).join('L') + 'Z' }, a), p || bg);
      // the sidewalk the court is chalked on
      quad([[-0.95, -0.4], [0.95, -0.4], [0.95, 5.2], [-0.95, 5.2]], { fill: '#dcd6cc' }); for (let z = -0.4; z < 5.2; z += 0.6) quad([[-0.95, z], [0.95, z], [0.95, z + 0.012], [-0.95, z + 0.012]], { fill: '#c7c0b4' });
      quad([[-0.95, -0.4], [-0.9, -0.4], [-0.9, 5.2], [-0.95, 5.2]], { fill: '#c2bbae' }); quad([[0.9, -0.4], [0.95, -0.4], [0.95, 5.2], [0.9, 5.2]], { fill: '#c2bbae' });
      const court = S('g', {}, bg), chalk = { fill: 'none', stroke: '#ffffff', 'stroke-width': 2.2, 'stroke-linejoin': 'round', opacity: 0.92 }, cells = [];
      ROWS.forEach((r, i) => { const z0 = Z0 + RL * i, z1 = z0 + RL;
        if (r[0] === 'HOME') { let d = ''; const n = 20; for (let k = 0; k <= n; k++) { const a = Math.PI * k / n, s = P(-Math.cos(a) * SW * 0.9, 0, z0 + Math.sin(a) * RL * 1.3); d += (k ? 'L' : 'M') + r2(s[0]) + ' ' + r2(s[1]); }
          S('path', { d: d + 'Z', fill: COL[i], opacity: 0.75 }, court); S('path', Object.assign({ d: d + 'Z' }, chalk), court); cells.push([{ x: 0, z: z0 + RL * 0.55 }]); }
        else { const xs = r.length === 2 ? [[-SW, 0], [0, SW]] : [[-SW / 2, SW / 2]]; cells.push(xs.map(([a, b]) => { quad([[a, z0], [b, z0], [b, z1], [a, z1]], { fill: COL[i], opacity: 0.75 }, court); quad([[a, z0], [b, z0], [b, z1], [a, z1]], chalk, court); return { x: (a + b) / 2, z: (z0 + z1) / 2 }; })); }
        r.forEach((lb, j) => { const c = cells[i][j] || cells[i][0], s = P(c.x, 0, c.z), k = s[2] / 245.7; S('text', { x: 0, y: 0, transform: 'translate(' + r2(s[0]) + ' ' + r2(s[1] + 6 * k) + ') scale(' + r2(k * 1.1) + ' ' + r2(k * 0.62) + ')', 'text-anchor': 'middle', 'font-family': 'Fredoka, sans-serif', 'font-weight': 700, 'font-size': lb === 'HOME' ? 20 : 30, fill: '#ffffff', opacity: 0.9 }, court).textContent = lb; }); });
      // chalk dust smudges + a chalk piece
      for (let i = 0; i < 8; i++) { const s = P((i % 2 ? 1 : -1) * (0.62 + (i * 0.07) % 0.2), 0, 0.5 + i * 0.55); S('ellipse', { cx: r2(s[0]), cy: r2(s[1]), rx: r2(9 * s[2] / 245.7), ry: r2(3 * s[2] / 245.7), fill: COL[i], opacity: 0.4 }, court); }
      { const s = P(0.7, 0, 0.15); S('rect', { x: r2(s[0] - 9), y: r2(s[1] - 3), width: 18, height: 6, rx: 3, fill: '#ff8fc8', transform: 'rotate(-20 ' + r2(s[0]) + ' ' + r2(s[1]) + ')' }, court); }
      const stoneG = S('g', {}, bg), ringG = S('g', {}, bg), shG = S('g', {}, bg);
      const me = ctx.creature(ctx.playerKey, { yaw: 180 }), meSh = YG.shadow(shG, 0, 0, 30, 0.2);
      // buttons
      const bar = D('div', { style: 'position:absolute;left:4%;right:4%;bottom:2.2%;display:flex;gap:3%;justify-content:center;pointer-events:none;z-index:6;' }, ctx.crl.parentNode.querySelector('.yg-hud')), btn = {}; ctx.hint('');
      Object.keys(ACT).forEach(k => { const b = D('button', { 'aria-label': ACT[k].t, style: 'pointer-events:auto;flex:1;max-width:30%;aspect-ratio:1.65;border:0;border-radius:22%;background:#ffffff;color:' + ACT[k].c + ';font:700 clamp(12px,4.6cqw,20px)/1 Fredoka,sans-serif;box-shadow:0 1.2cqw 0 ' + ACT[k].c + ';cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4%;touch-action:none;' }, bar);
        const ic = D('div', { style: 'width:46%;height:46%;' }, b); ic.innerHTML = k === 'hop' ? '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="13" rx="4.5" ry="6.5" fill="currentColor"/><circle cx="9" cy="4.5" r="1.6" fill="currentColor"/><circle cx="12.5" cy="3.6" r="1.6" fill="currentColor"/><circle cx="15.6" cy="4.8" r="1.5" fill="currentColor"/></svg>'
          : k === 'split' ? '<svg viewBox="0 0 24 24"><ellipse cx="6.5" cy="14" rx="3.6" ry="5.6" fill="currentColor"/><ellipse cx="17.5" cy="14" rx="3.6" ry="5.6" fill="currentColor"/><circle cx="5" cy="6.2" r="1.3" fill="currentColor"/><circle cx="8" cy="5.6" r="1.3" fill="currentColor"/><circle cx="16" cy="5.6" r="1.3" fill="currentColor"/><circle cx="19" cy="6.2" r="1.3" fill="currentColor"/></svg>'
          : '<svg viewBox="0 0 24 24"><path d="M3 19Q12 -2 21 19" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/><path d="M17.5 16.5L21 19.5L22 15" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/><ellipse cx="12" cy="20" rx="4" ry="2" fill="#8a8f99"/></svg>';
        D('div', {}, b, ACT[k].t); b.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); press(k); b.style.transform = 'translateY(3px)'; setTimeout(() => b.style.transform = '', 90); }); btn[k] = b; });
      let lap = 0, beat = 760, hearts = 3, moves = [], mi = 0, t0 = 0, tNow = 0, cur = { z: 0.2, row: -1 }, hopA = null, phase = 'idle', ph0 = 0, stone = 0, combo = 0, stumbles = 0, perfect = 0;
      const STONES = [0, 1, 2, 4, 6];
      function plan() { stone = STONES[lap % STONES.length]; moves = []; let r = -1; while (r < 7) { let nx = r + 1, a; if (nx === stone) { nx++; a = 'leap'; } else a = ROWS[nx].length === 2 ? 'split' : 'hop'; moves.push({ row: nx, act: a, due: 0, done: 0 }); r = nx; }
        beat = Math.max(430, 760 * Math.pow(0.92, lap)); t0 = tNow + beat * 2; moves.forEach((m, i) => m.due = t0 + beat * i); mi = 0; drawStone(); ctx.timer('♥'.repeat(hearts) + '♡'.repeat(3 - hearts)); }
      function drawStone() { stoneG.innerHTML = ''; const c = cells[stone][0], s = P(c.x, 0, c.z), k = s[2] / 245.7; S('ellipse', { cx: r2(s[0]), cy: r2(s[1] + 2 * k), rx: r2(11 * k), ry: r2(4.2 * k), fill: '#6f7480' }, stoneG); S('ellipse', { cx: r2(s[0]), cy: r2(s[1]), rx: r2(10 * k), ry: r2(4.6 * k), fill: '#9aa0ab' }, stoneG); S('ellipse', { cx: r2(s[0] - 3 * k), cy: r2(s[1] - 1.4 * k), rx: r2(4 * k), ry: r2(1.6 * k), fill: '#c9ced6' }, stoneG); }
      function judge(m, act, dt) { m.done = 1; mi++; const ok = act === m.act, a = Math.abs(dt);
        let txt, col, pts = 0; if (!ok) { txt = act ? 'Oops!' : 'Miss!'; col = '#ff7a8a'; hearts--; combo = 0; stumbles = 1; SFX.miss(); } else if (a < 85) { txt = 'Perfect!'; col = '#ffe36e'; pts = 30; perfect++; } else if (a < 165) { txt = 'Good'; col = '#8fe0ff'; pts = 15; } else { txt = 'OK'; col = '#ffffff'; pts = 5; }
        if (ok) { combo++; pts += Math.min(20, Math.floor(combo / 4) * 5); SFX.pop(); } const c = cells[m.row][0], s = P(c.x, 0, c.z); if (pts) ctx.add(pts, s[0], s[1] - 50, txt + (combo >= 8 ? ' x' + combo : ''), col); else ctx.toast(txt, s[0], s[1] - 50, col);
        ctx.timer('♥'.repeat(Math.max(0, hearts)) + '♡'.repeat(3 - Math.max(0, hearts)));
        // the hop itself
        hopA = { from: cur.z, to: cells[m.row][0].z, row: m.row, act: m.act, t0: tNow, dur: Math.min(400, beat * 0.72) * (m.act === 'leap' ? 1.25 : 1), bad: !ok }; cur.row = m.row;
        if (hearts <= 0) { phase = 'over'; ph0 = tNow; } }
      function press(k) { if (!ctx.playing || phase !== 'run') return; const m = moves[mi]; if (!m) return; const dt = tNow - m.due; if (dt < -230) { SFX.tap(); return; } judge(m, k, dt); }
      const api = {
        start() { lap = 0; hearts = 3; combo = 0; perfect = 0; cur = { z: 0.2, row: -1 }; hopA = null; phase = 'run'; plan(); me.yaw(180); },
        key(k, dn) { if (!dn) return; for (const a in ACT) if (ACT[a].k.includes(k)) { press(a); return true; } },
        down() {}, _press: press, _state: () => ({ lap, hearts, mi, phase, due: moves[mi] && Math.round(moves[mi].due - tNow), act: moves[mi] && moves[mi].act }),
        celebrate(st) { me.yaw(0); me.play(st >= 2 ? 'happy' : 'idle'); },
        update(dt, t) { tNow = t;
          if (phase === 'run') { const m = moves[mi]; if (m && t > m.due + 230) judge(m, null, 999);
            // a metronome tick on each beat
            const bi = Math.floor((t - t0) / beat); if (bi !== api._bi && bi >= -2) { api._bi = bi; if (bi < 0) SFX.tick(); }
            if (mi >= moves.length && !hopA) { phase = 'lap'; ph0 = t; lap++; ctx.add(50 + lap * 10, W / 2, 250, 'Lap ' + lap + '! +' + (50 + lap * 10), '#ffe36e'); SFX.score(); me.yaw(0); me.play('happy'); } }
          if (phase === 'lap') { const u = (t - ph0) / 1000; if (u > 1.1 && u < 2.1) { cur.z = lerp(cells[7][0].z, 0.2, YG.SM((u - 1.1) / 1)); me.yaw(0); me.walk(dt, 1, 0); } if (u >= 2.1) { me.yaw(180); me.play('idle'); cur.z = 0.2; cur.row = -1; if (lap >= 6) { phase = 'over'; ctx.finish({ sub: '6 laps! ' + perfect + ' perfect', title: 'Champion!' }); } else { phase = 'run'; plan(); ctx.toast('Faster!', W / 2, 260, '#ffffff'); } } }
          if (phase === 'over' && t - ph0 > 300 && !api._fin) { api._fin = 1; if (hearts <= 0) { me.yaw(0); me.play('surprised'); ctx.finish({ sub: lap + ' lap' + (lap === 1 ? '' : 's') + ' · ' + perfect + ' perfect' }); } }
          // creature: where it stands + the hop arc
          let z = cur.z, lift = 0, E = {};
          if (hopA) { const u = cl((t - hopA.t0) / hopA.dur, 0, 1); z = lerp(hopA.from, hopA.to, YG.SM(u)); const hh = hopA.act === 'leap' ? 0.42 : 0.22; lift = Math.sin(u * Math.PI) * hh;
            E = hopA.act === 'split' ? { armL: 100 * Math.sin(u * Math.PI) + 30, armR: 100 * Math.sin(u * Math.PI) + 30, footL: 2 * Math.sin(u * Math.PI), footR: 2 * Math.sin(u * Math.PI), sq: u > 0.85 ? 0.12 : -0.05 } : hopA.act === 'leap' ? { armL: 150 * Math.sin(u * Math.PI), armR: 150 * Math.sin(u * Math.PI), spin: 360 * YG.SM(u), sq: u > 0.85 ? 0.1 : -0.06 } : { armL: 40, armR: 40, footR: 3 * Math.sin(u * Math.PI), sq: u > 0.85 ? 0.08 : -0.04 };
            if (hopA.bad) E.tilt = Math.sin(u * 20) * 6 * (1 - u * 0.5); if (u >= 1) { cur.z = hopA.to; hopA = null; } }
          else if (phase === 'run') { const m = moves[mi]; const pre = m ? cl(1 - (m.due - t) / beat, 0, 1) : 0; E = { sq: 0.06 * pre, armL: 20 + 25 * pre, armR: 20 + 25 * pre }; }
          if (phase === 'run' || phase === 'lap') me.pose(E);
          const s = P(0, lift, z), g = P(0, 0, z); me.set(s[0], s[1], 1.0 * s[2]); meSh.setAttribute('cx', r2(g[0])); meSh.setAttribute('cy', r2(g[1])); meSh.setAttribute('rx', r2(0.3 * g[2] * (1 - lift))); meSh.setAttribute('ry', r2(0.08 * g[2] * (1 - lift)));
          // ring on the next landing square(s), closing on the beat
          ringG.innerHTML = ''; const m = phase === 'run' && moves[mi];
          if (m) { const u = cl(1 - (m.due - t) / beat, 0, 1.2), A = ACT[m.act], rad = lerp(0.62, 0.27, Math.min(1, u)), cs = cells[m.row];
            cs.forEach(c => { let d = ''; for (let i = 0; i <= 28; i++) { const a = i / 28 * Math.PI * 2, q = P(c.x + Math.cos(a) * rad * (cs.length === 2 ? 0.55 : 1), 0, c.z + Math.sin(a) * rad * 0.8); d += (i ? 'L' : 'M') + r2(q[0]) + ' ' + r2(q[1]); }
              S('path', { d: d + 'Z', fill: A.c, 'fill-opacity': 0.12 + 0.2 * u, stroke: A.c, 'stroke-width': 3.2, opacity: cl(u * 2, 0, 1) }, ringG); });
            const c = cs.length === 2 ? { x: 0, z: cs[0].z } : cs[0], q = P(c.x, 0, c.z); const tag = S('g', { transform: 'translate(' + r2(q[0]) + ' ' + r2(q[1] - 22 * q[2] / 245.7 - 8) + ')', opacity: cl(u * 2, 0, 1) }, ringG);
            S('rect', { x: -22, y: -11, width: 44, height: 20, rx: 10, fill: A.c }, tag); S('text', { y: 4, 'text-anchor': 'middle', 'font-family': 'Fredoka, sans-serif', 'font-weight': 700, 'font-size': 12, fill: '#ffffff' }, tag).textContent = A.t;
            Object.keys(btn).forEach(k => { btn[k].style.background = k === m.act && u > 0.5 ? A.c + '22' : '#ffffff'; }); }
        } };
      plan(); return api;
    } });
  }; go();
})();
