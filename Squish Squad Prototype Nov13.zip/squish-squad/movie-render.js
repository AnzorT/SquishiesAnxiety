// Makes an MP4 of a Squad movie in the browser: movie DOM -> SVG foreignObject -> canvas -> H.264 (WebCodecs),
// soundtrack = pre-rendered AAC in scraps/mv/<id>-aac.*, muxed as fragmented MP4 into Blob parts (low memory).
window.MovieRender = (function () {
  const JS = ['movies.js?v=4', 'movies-kit.js', 'movie-t2.js', 'movie-t3.js', 'movie-t4.js', 'movie-t5.js'];
  const FPS = 30, TAIL = 15, BASE = 'scraps/mv/';
  const Q = { '4k': { w: 3840, h: 2160, codec: 'avc1.640033', br: 35e6 }, '1440p': { w: 2560, h: 1440, codec: 'avc1.640032', br: 18e6 }, '1080p': { w: 1920, h: 1080, codec: 'avc1.640028', br: 12e6 } };
  const unb64 = s => { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
  const b64txt = t => btoa(unescape(encodeURIComponent(t)));
  const yieldNow = () => new Promise(r => { const ch = new MessageChannel(); ch.port1.onmessage = () => r(); ch.port2.postMessage(0); });
  const loadJs = src => new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('could not load ' + src)); document.head.appendChild(s); });
  let FF = null, ready = null;
  function init() {
    if (ready) return ready;
    ready = (async () => {
      if (!window.SquadMovies) for (const s of JS) await loadJs(s);
      FF = (await (await fetch(BASE + 'core.json')).json()).ff;
      const st = document.createElement('style'); st.textContent = FF; document.head.appendChild(st);
      for (const f of ['500 10px Fredoka', '600 10px Fredoka', '700 10px Fredoka', '10px Limelight', '10px Creepster']) { try { await document.fonts.load(f); } catch (e) {} }
    })();
    return ready;
  }
  async function setup(id, S) {
    await init();
    const mv = window.SquadMovies.list.find(m => m.id === id);
    const hold = document.createElement('div'); hold.style.cssText = 'position:fixed;left:-20000px;top:0;width:320px;height:180px;overflow:hidden;pointer-events:none;'; document.body.appendChild(hold);
    const st = document.createElement('div'); st.style.cssText = 'position:absolute;left:0;top:0;width:320px;height:180px;overflow:hidden;background:#05030a;'; hold.appendChild(st);
    const F = mv.mk({}); st.appendChild(F.root);
    const srcs = new Set(); for (let t = 0; t <= mv.dur; t += 0.25) { F.upd(t); st.querySelectorAll('img').forEach(i => { const s = i.getAttribute('src'); if (s && !/^data:/.test(s)) srcs.add(s); }); }
    const DU = {}; await Promise.all([...srcs].map(async s => { try { const r = await fetch(s); if (r.ok) DU[s] = 'data:image/svg+xml;base64,' + b64txt(await r.text()); } catch (e) {} }));
    const cv = document.createElement('canvas'); cv.width = 320 * S; cv.height = 180 * S;
    return { mv, hold, st, F, DU, S, cv, g: cv.getContext('2d'), XS: new XMLSerializer(), N: mv.dur * FPS + TAIL };
  }
  async function frame(M, f) {
    const t = Math.min(M.mv.dur, f / FPS); M.F.upd(t);
    const c = M.st.cloneNode(true), W = M.cv.width, H = M.cv.height;
    c.querySelectorAll('*').forEach(n => { if (n.style && n.style.display === 'none') n.remove(); });
    c.querySelectorAll('img').forEach(i => { const s = i.getAttribute('src'); if (M.DU[s]) i.setAttribute('src', M.DU[s]); });
    c.style.transform = 'scale(' + M.S + ')'; c.style.transformOrigin = '0 0';
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + W + '" height="' + H + '"><foreignObject x="0" y="0" width="' + W + '" height="' + H + '"><div xmlns="http://www.w3.org/1999/xhtml" style="width:' + W + 'px;height:' + H + 'px;position:relative;overflow:hidden;background:#05030a">' + (c.textContent.trim() ? '<style>' + FF + '</style>' : '') + M.XS.serializeToString(c).replace(/^<div xmlns="http:\/\/www.w3.org\/1999\/xhtml"/, '<div') + '</div></foreignObject></svg>';
    const im = new Image(); im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg); await im.decode();
    M.g.fillStyle = '#05030a'; M.g.fillRect(0, 0, W, H); M.g.drawImage(im, 0, 0);
  }
  async function make(id, qk, onP, stop, maxF) {
    const q = Q[qk] || Q['4k'], S = q.w / 320;
    const [MX, M, AU, AB] = await Promise.all([import('https://cdn.jsdelivr.net/npm/mp4-muxer@5.1.3/build/mp4-muxer.mjs'), setup(id, S), fetch(BASE + id + '-aac.json').then(r => r.json()), fetch(BASE + id + '-aac.bin').then(r => r.arrayBuffer())]);
    const ab = new Uint8Array(AB), parts = [], patches = []; let written = 0;
    const target = new MX.StreamTarget({ onData: (data, pos) => {
      if (pos === written) { parts.push([pos, new Blob([data])]); written += data.byteLength; }
      else if (pos > written) { parts.push([written, new Blob([new Uint8Array(pos - written)])]); parts.push([pos, new Blob([data])]); written = pos + data.byteLength; }
      else { const end = pos + data.byteLength; if (end > written) { const k = written - pos; patches.push([pos, data.slice(0, k)]); parts.push([written, new Blob([data.slice(k)])]); written = end; } else patches.push([pos, data.slice()]); }
    }, chunked: true, chunkSize: 8 * 1024 * 1024 });
    const mx = new MX.Muxer({ target, video: { codec: 'avc', width: q.w, height: q.h, frameRate: FPS }, audio: { codec: 'aac', numberOfChannels: 2, sampleRate: 48000 }, fastStart: false, firstTimestampBehavior: 'offset' });
    let ai = 0, ao = 0; const aMeta = { decoderConfig: { codec: AU.codec, sampleRate: AU.sampleRate, numberOfChannels: AU.numberOfChannels, description: AU.desc ? unb64(AU.desc) : undefined } };
    const audioUpTo = ts => { while (ai < AU.idx.length && AU.idx[ai][0] <= ts) { const e = AU.idx[ai]; mx.addAudioChunkRaw(ab.subarray(ao, ao + e[2]), 'key', e[0], e[1], ai === 0 ? aMeta : undefined); ao += e[2]; ai++; } };
    let err = null;
    const enc = new VideoEncoder({ output: (ch, meta) => { try { audioUpTo(ch.timestamp); mx.addVideoChunk(ch, meta); } catch (e) { err = e; } }, error: e => { err = e; } });
    enc.configure({ codec: q.codec, width: q.w, height: q.h, bitrate: q.br, bitrateMode: 'variable', framerate: FPS, latencyMode: 'quality', avc: { format: 'avc' } });
    const t0 = performance.now();
    try {
      const NN = maxF ? Math.min(maxF, M.N) : M.N;
      for (let f = 0; f < NN; f++) {
        if (stop && stop()) throw new Error('stopped'); if (err) throw err;
        await frame(M, f);
        const vf = new VideoFrame(M.cv, { timestamp: Math.round(f * 1e6 / FPS), duration: Math.round(1e6 / FPS) });
        enc.encode(vf, { keyFrame: f % 60 === 0 }); vf.close();
        while (enc.encodeQueueSize > 4) await yieldNow();
        if (onP && f % 3 === 0) { const el = (performance.now() - t0) / 1000, k = (f + 1) / M.N; onP(k, el / k - el); }
      }
      await enc.flush(); if (err) throw err;
      audioUpTo(maxF ? NN * 1e6 / FPS : Infinity); mx.finalize();
    } finally { try { enc.close(); } catch (e) {} M.hold.remove(); }
    for (const [pos, data] of patches) {
      let o = 0;
      while (o < data.byteLength) { const p = pos + o, i = parts.findIndex(([s, b]) => p >= s && p < s + b.size); if (i < 0) break;
        const [s, b] = parts[i], u = new Uint8Array(await b.arrayBuffer()), n = Math.min(data.byteLength - o, s + b.size - p);
        u.set(data.subarray(o, o + n), p - s); parts[i] = [s, new Blob([u])]; o += n; }
    }
    return new Blob(parts.map(x => x[1]), { type: 'video/mp4' });
  }
  return { make, Q, ver: 3 };
})();
