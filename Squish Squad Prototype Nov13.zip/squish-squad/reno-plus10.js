// Renovation Catalog round 10 — Movie Room realism pass. A small per-face renderer drawn in fx (the engine's convex solids fill one hull per part,
// which reads as "painted"): every face gets its own light (top brightest, front lit, side darker), material textures in the face's own plane
// (styrofoam beads, speaker cloth, brushed metal, satin plastic), gloss streaks, catch-light edges, thin dark outlines and soft contact shadows.
// Toolkit RD.H10: cam(ctx) -> C, box3(C, o) oriented rounded box with face decals (local u right, v down), cyl3(C, a, b, r, col, o) any-axis
// cylinder / cone with cap decals, sph, shadow, tanF (tangent plane on a vertical cylinder), FR (any plane frame), flip (door / lid flipbook).
// Open / close pieces use r.play = 'open' (st 'play' = open); the catalog reads r.playL / r.stopL / r.playS / r.idleS for button + status text.
// Sets RenoDraw.PLUS10; catalog edit layer RD.SET10.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS9 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS10) return;
  const K = X.K, { slab, shade, mix } = K, N = RD.N, PI = Math.PI;
  const f1 = v => Math.round(v * 100) / 100, n4 = v => Math.round(v * 1e4) / 1e4, rep = (n, f) => Array.from({ length: n }, (_, i) => f(i));
  const P2 = q => f1(q[0]) + ' ' + f1(q[1]);
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const nrm = a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
  const mtx = (o, a, b) => 'matrix(' + [a[0] - o[0], a[1] - o[1], b[0] - o[0], b[1] - o[1], o[0], o[1]].map(n4).join(' ') + ')';
  const hull = P => { const a = P.slice().sort((p, q) => p[0] - q[0] || p[1] - q[1]); if (a.length < 3) return a; const cr = (o, p, q) => (p[0] - o[0]) * (q[1] - o[1]) - (p[1] - o[1]) * (q[0] - o[0]); const lo = [], up = [];
    for (const q of a) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); }
    for (let i = a.length - 1; i >= 0; i--) { const q = a[i]; while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], q) <= 0) up.pop(); up.push(q); } return lo.slice(0, -1).concat(up.slice(0, -1)); };
  const pth = P => 'M' + P.map(P2).join('L') + 'Z';
  const hash = s => { let h = 7; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) | 0; return Math.abs(h); };
  const rng = s => { let h = hash(s) || 1; return () => { h = (h * 1103515245 + 12345) | 0; return ((h >>> 8) & 0xffff) / 65536; }; };
  const isPlay = S => /play/.test(S.st || '');
  const B = b => b ? ` begin="${n4(b)}s"` : '';
  const an = (a, v, d, b, x) => `<animate attributeName="${a}" values="${v}" dur="${n4(d)}s"${B(b)} repeatCount="indefinite"${x || ''}/>`;
  const at = (t, v, d, b, x) => `<animateTransform attributeName="transform" type="${t}" values="${v}" dur="${n4(d)}s"${B(b)} repeatCount="indefinite"${x || ''}/>`;
  const SPL = n => ` calcMode="spline" keyTimes="${rep(n + 1, i => n4(i / n)).join(';')}" keySplines="${rep(n, () => '0.45 0 0.55 1').join(';')}"`;
  const FONT = 'font-family="Arial,Helvetica,sans-serif" font-weight="700"';

  // ---------- shared defs ----------
  const DEF10 = '<linearGradient id="m10v" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.13"/><stop offset="0.45" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.22"/></linearGradient>'
    + '<linearGradient id="m10t" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="0.55" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.1"/></linearGradient>'
    + '<linearGradient id="m10s" x1="0" y1="0" x2="1" y2="0.6"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.36" stop-color="#ffffff" stop-opacity="0.34"/><stop offset="0.44" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="0.52" stop-color="#ffffff" stop-opacity="0.17"/><stop offset="0.58" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
    + '<linearGradient id="m10in" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000000" stop-opacity="0.04"/><stop offset="1" stop-color="#000000" stop-opacity="0.38"/></linearGradient>'
    + '<radialGradient id="m10sh" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#000000" stop-opacity="0.45"/><stop offset="0.55" stop-color="#000000" stop-opacity="0.18"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="m10cap" cx="38%" cy="32%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.32"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.16"/></radialGradient>'
    + '<radialGradient id="m10cold" cx="45%" cy="25%" r="80%"><stop offset="0" stop-color="#e8f8ff" stop-opacity="0.75"/><stop offset="0.5" stop-color="#bfe8ff" stop-opacity="0.2"/><stop offset="1" stop-color="#bfe8ff" stop-opacity="0"/></radialGradient>'
    + '<pattern id="m10foam" width="2.6" height="2.3" patternUnits="userSpaceOnUse"><circle cx="0.7" cy="0.6" r="0.62" fill="none" stroke="#6a6250" stroke-opacity="0.16" stroke-width="0.18"/><circle cx="2" cy="1.75" r="0.6" fill="none" stroke="#6a6250" stroke-opacity="0.13" stroke-width="0.18"/><circle cx="0.55" cy="0.45" r="0.22" fill="#ffffff" fill-opacity="0.7"/><circle cx="1.85" cy="1.6" r="0.2" fill="#ffffff" fill-opacity="0.6"/></pattern>'
    + '<pattern id="m10mesh" width="1.1" height="1.1" patternUnits="userSpaceOnUse"><path d="M0 0.28H1.1M0 0.83H1.1" stroke="#000000" stroke-opacity="0.35" stroke-width="0.22"/><path d="M0.28 0V1.1M0.83 0V1.1" stroke="#ffffff" stroke-opacity="0.07" stroke-width="0.22"/></pattern>'
    + '<pattern id="m10perf" width="1.7" height="1.5" patternUnits="userSpaceOnUse"><circle cx="0.85" cy="0.75" r="0.42" fill="#0a0a0c" fill-opacity="0.8"/><circle cx="0.7" cy="0.62" r="0.14" fill="#ffffff" fill-opacity="0.25"/></pattern>'
    + '<pattern id="m10brush" width="30" height="1.6" patternUnits="userSpaceOnUse"><path d="M0 0.4H18M6 1.2H30" stroke="#ffffff" stroke-opacity="0.2" stroke-width="0.25"/><path d="M12 0.8H28" stroke="#000000" stroke-opacity="0.08" stroke-width="0.25"/></pattern>'
    + '<pattern id="m10noise" width="5" height="5" patternUnits="userSpaceOnUse"><circle cx="1" cy="1.4" r="0.25" fill="#000000" fill-opacity="0.07"/><circle cx="3.6" cy="0.8" r="0.2" fill="#ffffff" fill-opacity="0.12"/><circle cx="2.6" cy="3.5" r="0.28" fill="#000000" fill-opacity="0.06"/><circle cx="4.4" cy="4.1" r="0.18" fill="#ffffff" fill-opacity="0.1"/><circle cx="0.6" cy="4.2" r="0.2" fill="#000000" fill-opacity="0.05"/></pattern>'
    + '<radialGradient id="m10mst" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.9"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.45"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>'
    + '<filter id="m10b1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.9"/></filter><filter id="m10b2" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="2.2"/></filter><filter id="m10b3" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3.2"/></filter>';

  // ---------- camera + light (works for any piece rotation: derived from the projection itself) ----------
  let UID = 0;
  function cam(ctx) { const p0 = ctx.p, o = p0(0, 0, 0), e1 = p0(1, 0, 0), e2 = p0(0, 1, 0), e3 = p0(0, 0, 1);
    const Xr = [e1[0] - o[0], e2[0] - o[0], e3[0] - o[0]], Yr = [e1[1] - o[1], e2[1] - o[1], e3[1] - o[1]];
    let v = nrm(cross(Xr, Yr)); if (v[1] < 0) v = mul(v, -1);
    const rt = nrm([Xr[0], 0, Xr[2]]), L = nrm(add(add(mul(rt, -0.7), [0, 1.2, 0]), mul(v, 0.55)));
    const C = { v, rt, L, k: Math.hypot(Xr[0], Xr[2]), id: 'q' + (++UID) + '_', n: 0, b: [1e9, 1e9, -1e9, -1e9], S: ctx.S };
    C.p = (x, y, z) => { const q = p0(x, y, z); if (q[0] < C.b[0]) C.b[0] = q[0]; if (q[1] < C.b[1]) C.b[1] = q[1]; if (q[0] > C.b[2]) C.b[2] = q[0]; if (q[1] > C.b[3]) C.b[3] = q[1]; return q; };
    C.P = q => C.p(q[0], q[1], q[2]); C.bb = m => [C.b[0] - m, C.b[1] - m, C.b[2] + m, C.b[3] + m]; C.u = s => C.id + s + (++C.n);
    C.thV = Math.atan2(v[0], v[2]); // angle (from +z toward +x) of the side of a vertical cylinder that faces the viewer
    return C; }
  const lit = (C, n) => Math.max(0.4, Math.min(1.22, 0.5 + 0.56 * Math.max(0, dot(n, C.L)) + 0.12 * Math.max(0, dot(n, C.v))));
  const vis = (C, n) => dot(n, C.v) > 0.004;
  const FR = (C, O, U, V) => mtx(C.P(O), C.P(add(O, U)), C.P(add(O, V)));
  const tanF = (C, cx, cz, R, th, y) => { const s = Math.sin(th), c = Math.cos(th); return FR(C, [cx + R * s, y, cz + R * c], [c, 0, -s], [0, -1, 0]); };
  const shadow = (C, x, z, rx, rz, op, y) => `<g transform="${FR(C, [x, y || 0.05, z], [1, 0, 0], [0, 0, 1])}"><ellipse rx="${rx}" ry="${rz}" fill="url(#m10sh)" opacity="${op || 1}"/></g>`;
  const yawA = t => [[Math.cos(t), 0, -Math.sin(t)], [0, 1, 0], [Math.sin(t), 0, Math.cos(t)]];

  // ---------- oriented rounded box ----------
  // o: c bottom-centre, ax [ex, ey, ez], w h d, col, r (vertical-edge radius), mat (foam|mesh|brush|noise), tpat (top pattern), gl gloss 0..1, f light factor,
  //    dec {f, r, b, l, t, u} svg in face-local units (u right, v down; vertical faces span 0..W x 0..h, top 0..w x 0..d from the back edge),
  //    hole {f:[l,t,r,b], t: inset} cut-outs, skip {k: 1}, op, ol 0 = no outline, olc / olw / olo, edge (catch-light opacity, 0 = none)
  const PAT = { foam: 'm10foam', mesh: 'm10mesh', brush: 'm10brush', noise: 'm10noise' }, I3 = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  function box3(C, o) {
    const A = o.ax || I3, c = o.c, w = o.w, h = o.h, d = o.d, hw = w / 2, hd = d / 2, r = Math.max(0, Math.min(o.r || 0, hw - 0.05, hd - 0.05)), col = o.col, dec = o.dec || {}, skip = o.skip || {}, F0 = o.f || 1;
    const P = (u, v, s) => add(c, add(add(mul(A[0], u), mul(A[1], v)), mul(A[2], s))), Vd = mul(A[1], -1), pat = PAT[o.mat], tp = o.tpat === undefined ? pat : PAT[o.tpat], op = o.op == null ? '' : ` opacity="${o.op}"`, gl = o.gl || 0;
    let s = '';
    if (r > 0.05) [[1, 1, 0], [1, -1, 1], [-1, -1, 2], [-1, 1, 3]].forEach(([su, ss, qd]) => { const cu = su * (hw - r), cs = ss * (hd - r);
      for (let i = 0; i < 4; i++) { const a0 = (qd + i / 4) * PI / 2, a1 = (qd + (i + 1) / 4) * PI / 2, am = (a0 + a1) / 2, n = nrm(add(mul(A[0], Math.sin(am)), mul(A[2], Math.cos(am)))); if (!vis(C, n)) continue;
        const q0 = [cu + r * Math.sin(a0), cs + r * Math.cos(a0)], q1 = [cu + r * Math.sin(a1), cs + r * Math.cos(a1)], fc = shade(col, lit(C, n) * F0);
        s += `<path d="${pth([P(q0[0], h, q0[1]), P(q1[0], h, q1[1]), P(q1[0], 0, q1[1]), P(q0[0], 0, q0[1])].map(C.P))}" fill="${fc}" stroke="${fc}" stroke-width="0.3"${op}/>`; } });
    [{ k: 'f', n: A[2], O: P(-hw, h, hd), U: A[0], W: w }, { k: 'r', n: A[0], O: P(hw, h, hd), U: mul(A[2], -1), W: d }, { k: 'b', n: mul(A[2], -1), O: P(hw, h, -hd), U: mul(A[0], -1), W: w }, { k: 'l', n: mul(A[0], -1), O: P(-hw, h, -hd), U: A[2], W: d }].forEach(F => {
      if (skip[F.k] || !vis(C, F.n)) return; const fc = shade(col, lit(C, F.n) * F0), x0 = r, W = F.W - 2 * r, ho = o.hole && o.hole[F.k];
      const shp = `M${f1(x0)} 0H${f1(x0 + W)}V${f1(h)}H${f1(x0)}Z` + (ho ? `M${f1(ho[0])} ${f1(ho[1])}V${f1(h - ho[3])}H${f1(F.W - ho[2])}V${f1(ho[1])}Z` : ''), fl = u => `<path d="${shp}" fill="${u}" fill-rule="evenodd"/>`;
      s += `<g transform="${FR(C, F.O, F.U, Vd)}"${op}><path d="${shp}" fill="${fc}" fill-rule="evenodd"${ho ? '' : ` stroke="${fc}" stroke-width="0.25"`}/>` + fl('url(#m10v)') + (pat ? fl(`url(#${pat})`) : '') + (gl ? `<g opacity="${gl}">${fl('url(#m10s)')}</g>` : '')
        + (o.edge !== 0 ? `<path d="M${f1(x0)} 0.3H${f1(x0 + W)}" stroke="#ffffff" stroke-opacity="${o.edge || 0.35}" stroke-width="0.45"/>` : '') + (dec[F.k] || '') + '</g>'; });
    const rrp = (W, Dd, th) => `M${f1(r)} 0H${f1(W - r)}Q${f1(W)} 0 ${f1(W)} ${f1(r)}V${f1(Dd - r)}Q${f1(W)} ${f1(Dd)} ${f1(W - r)} ${f1(Dd)}H${f1(r)}Q0 ${f1(Dd)} 0 ${f1(Dd - r)}V${f1(r)}Q0 0 ${f1(r)} 0Z` + (th ? `M${th} ${th}V${f1(Dd - th)}H${f1(W - th)}V${th}Z` : '');
    const cap = (n, M, k, th) => { const fc = shade(col, lit(C, n) * F0), sh = rrp(w, d, th), fl = u => `<path d="${sh}" fill="${u}" fill-rule="evenodd"/>`;
      return `<g transform="${M}"${op}>` + fl(fc) + fl('url(#m10t)') + (tp ? fl(`url(#${tp})`) : '') + (gl ? `<g opacity="${gl}">${fl('url(#m10s)')}</g>` : '') + (dec[k] || '') + '</g>'; };
    if (!skip.t && vis(C, A[1])) s += cap(A[1], FR(C, P(-hw, h, -hd), A[0], A[2]), 't', o.hole && o.hole.t);
    if (!skip.u && vis(C, mul(A[1], -1))) s += cap(mul(A[1], -1), FR(C, P(-hw, 0, hd), A[0], mul(A[2], -1)), 'u');
    if (o.ol !== 0) { const sec = r > 0.05 ? rep(16, i => { const qd = Math.floor(i / 4), a = (qd + (i % 4) / 3) * PI / 2; return [[1, 1, -1, -1][qd] * (hw - r) + r * Math.sin(a), [1, -1, -1, 1][qd] * (hd - r) + r * Math.cos(a)]; }) : [[hw, hd], [hw, -hd], [-hw, -hd], [-hw, hd]], pts = [];
      [0, h].forEach(v => sec.forEach(q => pts.push(C.P(P(q[0], v, q[1]))))); s += `<path d="${pth(hull(pts))}" fill="none" stroke="${o.olc || shade(col, 0.4)}" stroke-width="${o.olw || 0.5}" stroke-opacity="${o.olo || 0.75}" stroke-linejoin="round"/>`; }
    return s; }

  // ---------- any-axis cylinder / cone ----------
  const CYS = { plastic: [[0, 0.95], [0.2, 1.12], [0.45, 1], [0.78, 0.76], [1, 0.6]], gloss: [[0, 0.82], [0.14, 1.5], [0.22, 1.1], [0.5, 0.9], [0.85, 0.6], [0.95, 0.74], [1, 0.62]],
    metal: [[0, 0.72], [0.12, 1.55], [0.26, 0.95], [0.45, 1.2], [0.64, 0.68], [0.84, 1.08], [1, 0.55]], chrome: [[0, 0.5], [0.1, 1.75], [0.2, 0.95], [0.36, 0.42], [0.52, 1.35], [0.7, 0.62], [0.86, 1.45], [1, 0.5]], matte: [[0, 1], [0.3, 1.04], [0.7, 0.82], [1, 0.64]] };
  function cyl3(C, a, b, r, col, o) { o = o || {}; const r2 = o.r2 == null ? r : o.r2, dz = nrm(sub(b, a)), ref = Math.abs(dz[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0], e1 = nrm(cross(dz, ref)), e2 = cross(dz, e1), n = o.n || 28;
    const ring = (q, rr) => rep(n, i => { const t = i / n * 2 * PI; return C.P(add(q, add(mul(e1, Math.cos(t) * rr), mul(e2, Math.sin(t) * rr)))); });
    const RA = ring(a, r), RB = ring(b, r2), A2 = C.P(a), B2 = C.P(b), dx = B2[0] - A2[0], dy = B2[1] - A2[1], dl = Math.hypot(dx, dy); let nx = -0.6, ny = -0.8;
    if (dl > 0.05) { nx = -dy / dl; ny = dx / dl; if (nx * -0.6 + ny * -0.8 < 0) { nx = -nx; ny = -ny; } }
    const cx = (A2[0] + B2[0]) / 2, cy = (A2[1] + B2[1]) / 2, H = hull(RA.concat(RB)); let m = 0.2; H.forEach(q => m = Math.max(m, Math.abs((q[0] - cx) * nx + (q[1] - cy) * ny)));
    const id = C.u('c'), f0 = o.f || 1, op = o.op == null ? '' : ` opacity="${o.op}"`;
    let s = `<defs><linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${f1(cx + nx * m)}" y1="${f1(cy + ny * m)}" x2="${f1(cx - nx * m)}" y2="${f1(cy - ny * m)}">${(CYS[o.mat] || CYS.plastic).map(([t, f]) => `<stop offset="${t}" stop-color="${shade(col, f * f0)}"/>`).join('')}</linearGradient></defs>`;
    if (!o.noSide) s += `<path d="${pth(H)}" fill="url(#${id})"${op}/>` + (o.pat ? `<path d="${pth(H)}" fill="url(#${o.pat})"${op}/>` : '');
    const dv = dot(dz, C.v), capB = dv > 0, cn = capB ? dz : mul(dz, -1), cq = capB ? b : a, cr = capB ? r2 : r, CR = capB ? RB : RA;
    if (Math.abs(dv) > 0.02 && !o.noCap) { s += `<path d="${pth(CR)}" fill="${o.capCol || shade(col, lit(C, cn) * f0)}"${op}/><path d="${pth(CR)}" fill="url(#m10cap)"${op}/>`;
      if (o.cap) { let u = sub(C.rt, mul(cn, dot(C.rt, cn))); if (Math.hypot(u[0], u[1], u[2]) < 0.2) u = e1; u = nrm(u); let w = nrm(cross(cn, u)); if (C.P(add(cq, w))[1] < C.P(cq)[1]) w = mul(w, -1); s += `<g transform="${FR(C, cq, u, w)}">${o.cap(cr)}</g>`; } }
    if (o.ol !== 0) s += `<path d="${pth(H)}" fill="none" stroke="${o.olc || shade(col, 0.4)}" stroke-width="${o.olw || 0.45}" stroke-opacity="${o.olo || 0.7}" stroke-linejoin="round"/>`;
    return s; }
  function sph(C, q, r, col, o) { o = o || {}; const c = C.P(q), R = r * C.k, id = C.u('s'); C.p(q[0] - r, q[1] - r, q[2]); C.p(q[0] + r, q[1] + r, q[2]);
    return `<defs><radialGradient id="${id}" cx="36%" cy="30%" r="72%"><stop offset="0" stop-color="${shade(col, 1.55)}"/><stop offset="0.3" stop-color="${shade(col, 1.08)}"/><stop offset="0.75" stop-color="${shade(col, 0.72)}"/><stop offset="1" stop-color="${shade(col, 0.5)}"/></radialGradient></defs><circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(R)}" fill="url(#${id})"${o.op != null ? ` opacity="${o.op}"` : ''}/>`; }
  // flipbook: frames [{ i, s }] out of n total frames, shown one after another over T seconds, last frame holds
  // once-through flipbook, blended: each frame fades in on top during the first half of its step, the one under it fades out in the second half (no hard cuts)
  const KV = P => { const Q = P.filter((p, k) => !(k > 0 && p[0] === P[k - 1][0] && p[1] === P[k - 1][1])); return `values="${Q.map(p => p[1]).join(';')}" keyTimes="${Q.map(p => n4(p[0])).join(';')}"`; };
  const flip = (frames, n, T, b0) => { const m = Math.max(1, n - 1); return frames.map(({ i, s }) => { const last = i === n - 1;
    const P = i === 0 ? [[0, 1], [0.5 / m, 1], [1 / m, 0], [1, 0]] : last ? [[0, 0], [(m - 1) / m, 0], [(m - 0.5) / m, 1], [1, 1]] : [[0, 0], [(i - 1) / m, 0], [(i - 0.5) / m, 1], [(i + 0.5) / m, 1], [(i + 1) / m, 0], [1, 0]];
    return `<g opacity="${last ? 1 : 0}"><animate attributeName="opacity" ${KV(P)} dur="${T}s"${B(b0)} fill="freeze"/>${s}</g>`; }).join(''); };
  const easeA = (a1, n, a0) => rep(n, k => { const t = (k + 1) / n; return (a0 || 0) + (a1 - (a0 || 0)) * (1 - (1 - t) * (1 - t)); });
  const mist = (C, x, y, z, n, sz) => { const q = C.p(x, y, z); return `<g transform="translate(${P2(q)}) scale(${n4(C.k * (sz || 1))})" >` + rep(n || 4, i => { const d = 2.6 + i * 0.4, b = -i * d / (n || 4), dx = (i % 2 ? 1 : -1) * (3 + i * 2);
    return `<ellipse rx="7.5" ry="4" fill="url(#m10mst)" opacity="0">${an('opacity', '0;0.5;0', d, b)}<animateTransform attributeName="transform" type="translate" values="${dx * 0.3} 0;${dx} -16" dur="${d}s"${B(b)} repeatCount="indefinite"/></ellipse>`; }).join('') + '</g>'; };

  // ---------- small reusable sprites ----------
  const CANS = [['#d8322f', '#ffffff'], ['#e6ebee', '#d8322f'], ['#2f9d4a', '#f6e24a'], ['#f08a24', '#ffffff'], ['#2b5fc4', '#ffffff'], ['#7a2a8f', '#f5c542']];
  const canTop = cr => `<circle r="${f1(cr)}" fill="#c3c9cd"/><circle r="${f1(cr * 0.84)}" fill="#d9dee1" stroke="#8d949a" stroke-width="0.28"/><circle r="${f1(cr * 0.62)}" fill="none" stroke="#ffffff" stroke-opacity="0.6" stroke-width="0.2"/><path d="M${f1(-cr * 0.3)} ${f1(-cr * 0.55)}h${f1(cr * 0.6)}v${f1(cr * 0.5)}a${f1(cr * 0.3)} ${f1(cr * 0.3)} 0 0 1 ${f1(-cr * 0.6)} 0z" fill="#a9b0b5" stroke="#7d848a" stroke-width="0.2"/><ellipse cx="${f1(cr * 0.2)}" cy="${f1(cr * 0.35)}" rx="${f1(cr * 0.26)}" ry="${f1(cr * 0.15)}" fill="#5a6066"/>`;
  function can3(C, x, y, z, r, h, ci) { const [c, b] = CANS[ci % CANS.length], th = C.thV;
    return cyl3(C, [x, y, z], [x, y + h, z], r, c, { mat: 'gloss', cap: canTop, olw: 0.35 }) + cyl3(C, [x, y + h - 0.2, z], [x, y + h + 0.5, z], r * 0.86, '#c9ced2', { mat: 'chrome', noCap: 1, olw: 0.25 })
      + `<g transform="${tanF(C, x, z, r, th, y + h * 0.62)}"><path d="M${f1(-r * 0.9)} 0q${f1(r * 0.45)} -1.2 ${f1(r * 0.9)} 0t${f1(r * 0.9)} 0" stroke="${b}" stroke-width="${f1(h * 0.08)}" fill="none" opacity="0.9"/></g>`; }
  const PUFF = '<circle cx="-1" cy="0.3" r="1.25" fill="#fff8e4"/><circle cx="0.9" cy="0.1" r="1.15" fill="#fffaf0"/><circle cx="0" cy="-0.9" r="1.1" fill="#fff4d6"/><circle cx="0.25" cy="0.95" r="0.85" fill="#efd696"/><circle cx="-0.55" cy="-1.15" r="0.42" fill="#ffffff"/><path d="M-1.7 0.7q1.7 1 3.4 0" stroke="#c99a48" stroke-width="0.32" fill="none" opacity="0.7"/>';
  const puffAt = (C, q, s, rot) => { const c = C.P(q); return `<g transform="translate(${P2(c)}) rotate(${f1(rot || 0)}) scale(${n4(C.k * (s || 1))})">${PUFF}</g>`; };

  // ======================= MOV-014 STYROFOAM COOLER WITH ICE PACKS (tap: open / close the lid) =======================
  N.cool10 = S => { const open = isPlay(S), FO = '#f3f1ea', W = 60, Dd = 38, H = 32, LH = 6.5, T = 3.2;
    const D = { w: 66, d: 46, build: () => [] };
    const bandF = W => `<path d="M2 4.3H${W - 2}" stroke="#000000" stroke-opacity="0.1" stroke-width="0.6"/><path d="M2 4.9H${W - 2}" stroke="#ffffff" stroke-opacity="0.85" stroke-width="0.4"/><path d="M1.5 28.7H${W - 1.5}" stroke="#000000" stroke-opacity="0.1" stroke-width="0.6"/><path d="M1.5 29.3H${W - 1.5}" stroke="#ffffff" stroke-opacity="0.7" stroke-width="0.35"/>`;
    const bodyF = bandF(W) + `<g transform="translate(30 16.5)"><ellipse rx="11.5" ry="5.2" fill="none" stroke="#000000" stroke-opacity="0.09" stroke-width="0.7"/><ellipse rx="11.5" ry="5.2" fill="none" stroke="#ffffff" stroke-opacity="0.8" stroke-width="0.4" transform="translate(-0.35 -0.35)"/><text y="1.5" text-anchor="middle" ${FONT} font-size="4.2" fill="#2f6fb0" fill-opacity="0.78" letter-spacing="0.3">COOL·PAK</text></g><path d="M45 21.5l3.4 1.6M47 20.6l1.2 2.6" stroke="#8a7f66" stroke-opacity="0.28" stroke-width="0.35"/>`;
    const bodyR = bandF(Dd) + `<rect x="11" y="7" width="16" height="4.6" rx="2.3" fill="#000000" fill-opacity="0.14"/><rect x="11" y="7" width="16" height="2" rx="1" fill="#000000" fill-opacity="0.12"/><path d="M11.8 11.4H26.2" stroke="#ffffff" stroke-opacity="0.85" stroke-width="0.4"/>`;
    const lidTop = `<rect x="7" y="6" width="48" height="28" rx="3" fill="#000000" fill-opacity="0.03" stroke="#000000" stroke-opacity="0.09" stroke-width="0.8"/><rect x="7.5" y="6.5" width="47" height="27" rx="2.6" fill="none" stroke="#ffffff" stroke-opacity="0.85" stroke-width="0.45"/><text x="31" y="22" text-anchor="middle" ${FONT} font-size="3.4" fill="#000000" fill-opacity="0.07" letter-spacing="1">KEEP COLD</text>`;
    const lidU = `<rect x="3.6" y="3.6" width="54.8" height="32.8" rx="2.4" fill="#000000" fill-opacity="0.07"/><rect x="4" y="4" width="54" height="32" rx="2.2" fill="none" stroke="#ffffff" stroke-opacity="0.7" stroke-width="0.4"/><rect x="9" y="9" width="44" height="22" rx="2" fill="#000000" fill-opacity="0.04"/>`;
    const lidE = W => `<path d="M0.5 3.5H${W - 0.5}" stroke="#000000" stroke-opacity="0.13" stroke-width="0.5"/>`;
    const lidAt = (C, th) => { const t = th * PI / 180, ey = [0, Math.cos(t), -Math.sin(t)], ez = [0, Math.sin(t), Math.cos(t)], hinge = [0, H, -Dd / 2 - 1];
      return box3(C, { c: add(hinge, mul(ez, Dd / 2 + 1)), ax: [[1, 0, 0], ey, ez], w: W + 2, h: LH, d: Dd + 2, r: 4.6, col: FO, mat: 'foam', dec: { t: lidTop, u: lidU, f: lidE(W + 2), r: lidE(Dd + 2) }, olw: 0.4, olo: 0.55 }); };
    D.fx = ctx => { const C = cam(ctx); let s = shadow(C, 1, 3, 40, 26, 0.85);
      const body = o => box3(C, Object.assign({ c: [0, 0, 0], w: W, h: H, d: Dd, r: 4, col: FO, mat: 'foam', dec: { f: bodyF, r: bodyR }, olw: 0.45, olo: 0.55 }, o));
      if (!open) return { defs: DEF10, front: s + body() + `<g transform="${FR(C, [-W / 2, H, Dd / 2], [1, 0, 0], [0, -1, 0])}"><rect x="2" y="-0.2" width="${W - 4}" height="1.4" fill="#000000" opacity="0.12"/></g>` + lidAt(C, 0), bb: C.bb(4) };
      const ANG = easeA(106, 11), bk = [], fr = []; ANG.forEach((a, i) => (a >= 72 ? bk : fr).push({ i, s: lidAt(C, a) }));
      s += flip(bk, ANG.length, 0.85);
      const x0 = -W / 2 + T, z0 = -Dd / 2 + T, IW = W - 2 * T, ID = Dd - 2 * T, IY = 19.5, IN = '#ebe8df';
      s += `<g transform="${FR(C, [x0, H, z0], [1, 0, 0], [0, -1, 0])}"><rect width="${IW}" height="${H - 2}" fill="${shade(IN, lit(C, [0, 0, 1]))}"/><rect width="${IW}" height="${H - 2}" fill="url(#m10foam)"/><rect width="${IW}" height="${H - 2}" fill="url(#m10in)"/></g>`
        + `<g transform="${FR(C, [x0, H, z0], [0, 0, 1], [0, -1, 0])}"><rect width="${ID}" height="${H - 2}" fill="${shade(IN, lit(C, [1, 0, 0]) * 0.92)}"/><rect width="${ID}" height="${H - 2}" fill="url(#m10foam)"/><rect width="${ID}" height="${H - 2}" fill="url(#m10in)"/></g>`;
      // ice bed + contents, back to front
      const R = rng('cool10'), its = [];
      s += `<g transform="${FR(C, [x0, IY, z0], [1, 0, 0], [0, 0, 1])}"><rect width="${IW}" height="${ID}" fill="#d6ebf2"/><rect width="${IW}" height="${ID}" fill="url(#m10t)"/>` + rep(26, () => `<circle cx="${f1(R() * IW)}" cy="${f1(R() * ID)}" r="${f1(0.8 + R() * 1.6)}" fill="#ffffff" opacity="${n4(0.35 + R() * 0.4)}"/>`).join('') + '</g>';
      rep(18, i => { const x = x0 + 3 + R() * (IW - 6), z = z0 + 3 + R() * (ID - 6), sz = 3.4 + R() * 2.4; its.push({ z: z + x * 0.02, s: box3(C, { c: [x, IY - 1.2 + R() * 1.4, z], ax: yawA(R() * PI), w: sz, h: sz * 0.8, d: sz * 0.9, r: 0.8, col: '#e6f5fb', gl: 0.8, op: 0.92, olc: '#8fb7c8', olw: 0.3, olo: 0.8, edge: 0.7 }) }); });
      [[-17, -9, 0], [-7.5, -10, 1], [-19, 3, 2], [4, -9.5, 3]].forEach(([x, z, ci]) => its.push({ z, s: can3(C, x, IY - 6, z, 3.2, 12.5, ci) }));
      const pack = (x, y, z, yw, tl) => { const A = yawA(yw), ax = [A[0], add(mul(A[1], Math.cos(tl)), mul(A[2], Math.sin(tl))), sub(mul(A[2], Math.cos(tl)), mul(A[1], Math.sin(tl)))];
        return box3(C, { c: [x, y, z], ax, w: 17, h: 3.4, d: 11, r: 2.4, col: '#2470d0', gl: 0.85, dec: { t: `<text x="8.5" y="6.4" text-anchor="middle" ${FONT} font-size="2.6" fill="#ffffff" fill-opacity="0.92">ICE PACK</text><text x="8.5" y="8.6" text-anchor="middle" font-family="Arial" font-size="1.4" fill="#cfe4ff">reusable gel</text>` }, olw: 0.35 }); };
      its.push({ z: -6, s: pack(14, IY - 0.6, -7, 0.25, 0.18) }, { z: 7, s: pack(9, IY - 0.2, 7, -0.35, -0.12) });
      its.sort((a, b) => a.z - b.z).forEach(q => s += q.s);
      s += mist(C, 0, IY + 4, 0, 4, 1.2);
      s += body({ hole: { t: T } }) + flip(fr, ANG.length, 0.85);
      return { defs: DEF10, front: s, bb: C.bb(8) }; };
    return D; };

  // ======================= MOV-034 6-CAN MINI THERMOELECTRIC SODA FRIDGE (tap: open / close the door) =======================
  N.mfr10 = S => { const open = isPlay(S), BC = '#cfe8db', W = 34, Dd = 28, H = 40, FT = 1.6, DT = 3, Z0 = -15, ZF = 13, ID = 2.6;
    const D = { w: 40, d: 40, build: () => [] };
    const doorF = `<rect x="0.7" y="0.7" width="${W - 1.4}" height="${H - 1.4}" rx="1.6" fill="none" stroke="#000000" stroke-opacity="0.07" stroke-width="0.5"/><rect x="8" y="2.4" width="18" height="2.8" rx="1.4" fill="#000000" fill-opacity="0.24"/><rect x="8" y="2.4" width="18" height="1.2" rx="0.6" fill="#000000" fill-opacity="0.2"/><path d="M8.6 5H25.4" stroke="#ffffff" stroke-opacity="0.75" stroke-width="0.4"/>`
      + `<rect x="20.5" y="8.5" width="9.5" height="5.2" rx="1.1" fill="#12161a" stroke="#6f8a80" stroke-width="0.3"/><text x="25.25" y="12.35" text-anchor="middle" ${FONT} font-size="3.3" fill="#7fd6ff">4°C</text><rect x="20.5" y="8.5" width="9.5" height="2.2" rx="1" fill="#ffffff" opacity="0.08"/>`
      + `<text x="17" y="36.4" text-anchor="middle" ${FONT} font-size="2.9" fill="#5d8475" letter-spacing="0.7">chill·6</text>`;
    const sideR = rep(7, i => `<rect x="${f1(16 + i * 1.6)}" y="30" width="0.75" height="6.5" rx="0.37" fill="#000000" fill-opacity="0.3"/>`).join('') + `<path d="M1 0.6H${Dd - 1}" stroke="#ffffff" stroke-opacity="0.4" stroke-width="0.4"/>`;
    const liner = `<rect x="2" y="2" width="${W - 4}" height="${H - 4}" rx="2" fill="#eef4f2"/><rect x="2" y="2" width="${W - 4}" height="${H - 4}" rx="2" fill="none" stroke="#9aaba5" stroke-width="1.2"/><rect x="5" y="5" width="${W - 10}" height="${H - 10}" rx="1.6" fill="#000000" fill-opacity="0.05"/>`
      + `<rect x="6" y="28" width="${W - 12}" height="5" rx="1" fill="#dfe8e5" stroke="#b5c2bd" stroke-width="0.4"/><rect x="14" y="19.5" width="6.4" height="11" rx="1.2" fill="#2f9d4a"/><rect x="14" y="19.5" width="6.4" height="1.4" rx="0.6" fill="#c9ced2"/><rect x="15" y="21" width="1.2" height="9" fill="#ffffff" opacity="0.35"/><rect x="6" y="28" width="${W - 12}" height="1.2" fill="#ffffff" opacity="0.5"/>`;
    const doorAt = (C, th) => { const t = th * PI / 180, ex = [Math.cos(t), 0, Math.sin(t)], ez = [-Math.sin(t), 0, Math.cos(t)];
      return box3(C, { c: add([-W / 2, FT, ZF], add(mul(ex, W / 2), mul(ez, DT / 2))), ax: [ex, [0, 1, 0], ez], w: W, h: H, d: DT, r: 1.2, col: shade(BC, 1.04), gl: 0.55, dec: { f: doorF, b: liner }, olw: 0.45 }); };
    D.fx = ctx => { const C = cam(ctx); let s = shadow(C, 0, 1, 24, 22, 0.85);
      [[-13, -11], [13, -11], [-13, 13], [13, 13]].forEach(([x, z]) => s += cyl3(C, [x, 0, z], [x, FT, z], 1.6, '#2c2e31', { mat: 'matte', olw: 0.3 }));
      const body = o => box3(C, Object.assign({ c: [0, FT, (Z0 + ZF) / 2], w: W, h: H, d: ZF - Z0, r: 3.2, col: BC, gl: 0.3, dec: { r: sideR }, olw: 0.45 }, o));
      if (!open) return { defs: DEF10, front: s + body() + doorAt(C, 0), bb: C.bb(4) };
      const xi = -W / 2 + ID, yb = FT + ID, yt = FT + H - ID, zi = Z0 + ID, IW = W - 2 * ID, IH = yt - yb, IDp = ZF - zi, IN = '#eef4f6', SY = FT + 19.5;
      s += `<g transform="${FR(C, [xi, yt, zi], [1, 0, 0], [0, -1, 0])}"><rect width="${IW}" height="${IH}" fill="${shade(IN, lit(C, [0, 0, 1]))}"/><rect width="${IW}" height="${IH}" fill="url(#m10in)" opacity="0.6"/><rect x="2" y="0.8" width="${IW - 4}" height="1" rx="0.5" fill="#bfeaff"/>`
        + `<g transform="translate(${IW / 2} ${IH * 0.3})"><circle r="5.2" fill="#dfe6e9" stroke="#a9b4b9" stroke-width="0.5"/><g>${at('rotate', '0;360', 0.6)}${rep(5, i => `<path d="M0 0Q2 -1.6 1.2 -4.4L-0.6 -4.2Q0.4 -2 0 0Z" fill="#8f9aa0" transform="rotate(${i * 72})"/>`).join('')}</g><circle r="1.1" fill="#6f7a80"/>${rep(3, i => `<circle r="${f1(1.9 + i * 1.3)}" fill="none" stroke="#7d888e" stroke-width="0.35"/>`).join('')}</g></g>`
        + `<g transform="${FR(C, [xi, yt, zi], [0, 0, 1], [0, -1, 0])}"><rect width="${IDp}" height="${IH}" fill="${shade(IN, lit(C, [1, 0, 0]) * 0.94)}"/><rect width="${IDp}" height="${IH}" fill="url(#m10in)" opacity="0.6"/><path d="M0 ${f1(yt - SY)}H${IDp}" stroke="#b9c6cc" stroke-width="0.8"/></g>`
        + `<g transform="${FR(C, [xi, yb, zi], [1, 0, 0], [0, 0, 1])}"><rect width="${IW}" height="${IDp}" fill="${shade(IN, lit(C, [0, 1, 0]) * 0.9)}"/><rect width="${IW}" height="${IDp}" fill="url(#m10t)"/></g>`;
      [-9.5, 0, 9.5].forEach((x, i) => s += can3(C, x, yb, -2, 4, 13.5, [0, 1, 0][i]));
      s += `<g transform="${FR(C, [xi, SY, zi], [1, 0, 0], [0, 0, 1])}">` + rep(13, i => `<path d="M${f1(0.6 + i * 2.33)} 0.4V${f1(IDp - 0.6)}" stroke="#7d868c" stroke-width="0.55"/><path d="M${f1(0.45 + i * 2.33)} 0.4V${f1(IDp - 0.6)}" stroke="#e8eef1" stroke-width="0.28"/>`).join('') + `<path d="M0 1H${IW}M0 ${f1(IDp - 1)}H${IW}" stroke="#d5dde2" stroke-width="0.9"/></g>`;
      [-9.5, 0, 9.5].forEach((x, i) => s += can3(C, x, SY, -2, 4, 13.5, [2, 3, 4][i]));
      s += `<g transform="${FR(C, [xi, yt, ZF], [1, 0, 0], [0, -1, 0])}"><rect width="${IW}" height="${IH}" fill="url(#m10cold)">${an('opacity', '0.85;1;0.85', 3)}</rect></g>` + mist(C, 0, FT + 8, ZF + 2, 3, 0.8);
      s += body({ hole: { f: [ID, ID, ID, ID] }, dec: { r: sideR, f: `<rect x="${ID}" y="${ID}" width="${IW}" height="${IH}" fill="none" stroke="#a9b8b2" stroke-width="0.9"/>` } });
      const ANG = easeA(108, 10); s += flip(ANG.map((a, i) => ({ i, s: doorAt(C, a) })), ANG.length, 0.7);
      return { defs: DEF10, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= MOV-022 42-INCH THRIFTED PLASMA TV ON BRACKETS (wall) =======================
  N.plas10 = S => { const TW = 140, TH = 84, TD = 7, ZB = 4.5, ZF = ZB + TD;
    const D = { w: 150, d: 14, mount: 'wall', elev: 40, act: 'watch', use: { x: 0, z: 150 } };
    D.build = () => [slab(0, TH - 75, ZF + 0.05, 124, 70, 0.2, '#000000', { scr: 1, r: 0.5, emit: 1, noOut: 1, op: 0 })];
    const front = `<defs><linearGradient id="pl10s" x1="0" y1="0" x2="0.9" y2="1"><stop offset="0" stop-color="#2b3036"/><stop offset="0.55" stop-color="#15181c"/><stop offset="1" stop-color="#0b0c0f"/></linearGradient><linearGradient id="pl10k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e3e6e8"/><stop offset="0.5" stop-color="#b9bec2"/><stop offset="1" stop-color="#8e9499"/></linearGradient></defs>`
      + `<rect x="7.4" y="4.4" width="125.2" height="71.2" rx="0.6" fill="#050506"/><rect x="8" y="5" width="124" height="70" fill="url(#pl10s)"/><path d="M71 5H101L79 75H49Z" fill="#ffffff" opacity="0.045"/><path d="M104 5H112L90 75H82Z" fill="#ffffff" opacity="0.03"/><rect x="8" y="5" width="124" height="16" fill="#ffffff" opacity="0.025"/>`
      + `<path d="M8 5.3H132" stroke="#ffffff" stroke-opacity="0.12" stroke-width="0.4"/><rect x="0" y="76.4" width="${TW}" height="${TH - 76.4}" fill="url(#pl10k)"/><rect x="4" y="77.6" width="52" height="5.2" fill="url(#m10perf)"/><rect x="84" y="77.6" width="52" height="5.2" fill="url(#m10perf)"/><path d="M0 76.5H${TW}" stroke="#ffffff" stroke-opacity="0.8" stroke-width="0.35"/>`
      + `<rect x="61" y="78.2" width="18" height="4" rx="0.6" fill="#ced3d6" stroke="#8e9499" stroke-width="0.25"/><text x="70" y="81.2" text-anchor="middle" ${FONT} font-size="2.6" letter-spacing="1" fill="#3b3f44">PLASMA</text><circle cx="58.4" cy="80.2" r="0.62" fill="#ff4a3a"/><circle cx="58.4" cy="80.2" r="1.6" fill="#ff4a3a" opacity="0.25"/>`;
    const top = rep(34, i => `<rect x="${f1(8 + i * 3.6)}" y="2.2" width="2.2" height="2.6" rx="0.4" fill="#000000" fill-opacity="0.55"/>`).join('');
    const side = rep(4, i => `<rect x="2.3" y="${f1(18 + i * 4.6)}" width="2.4" height="2.8" rx="0.6" fill="#2c2f34" stroke="#000000" stroke-width="0.2"/>`).join('');
    D.fx = ctx => { const C = cam(ctx); let s = `<g transform="${FR(C, [-TW / 2, TH, 0.2], [1, 0, 0], [0, -1, 0])}"><rect x="3" y="5" width="${TW}" height="${TH}" rx="3" fill="#000000" opacity="0.3" filter="url(#m10b3)"/></g>`;
      s += box3(C, { c: [62, 18, ZB / 2], w: 3, h: 44, d: ZB, r: 0.6, col: '#2a2c30', mat: 'brush', olw: 0.35 });
      [-34, 34].forEach(x => { s += box3(C, { c: [x, -7, 2.4], w: 3.2, h: 22, d: 3, r: 0.5, col: '#26282c', mat: 'brush', olw: 0.35 }) + cyl3(C, [x, -5.5, 3.9], [x, -5.5, 6.4], 1.3, '#3b3e43', { mat: 'metal', olw: 0.3 }); });
      const cb = [[54, 1, 6], [55, -8, 6.5], [57.5, -16, 4.5], [56, -26, 2]].map(q => C.p(...q)), cd = `M${P2(cb[0])}C${P2(cb[1])} ${P2(cb[2])} ${P2(cb[3])}`;
      s += `<path d="${cd}" stroke="#0e0f11" stroke-width="2.1" fill="none" stroke-linecap="round"/><path d="${cd}" stroke="#4a4d52" stroke-width="0.6" fill="none" stroke-linecap="round" transform="translate(-0.5 -0.3)"/>`;
      s += box3(C, { c: [0, 0, ZB + TD / 2], w: TW, h: TH, d: TD, r: 1.4, col: '#17181c', gl: 0.9, dec: { f: front, t: top, r: side }, olc: '#050506', olw: 0.6, edge: 0.25 });
      return { defs: DEF10, front: s, bb: C.bb(6) }; };
    return D; };

  // ======================= MOV-026 1080p DIGITAL HOME PROJECTOR ON CEILING MOUNT =======================
  N.cproj10 = S => { const PW = 42, PH = 13, PD = 34, LX = -10, LY = 6.6;
    const D = { w: 50, d: 40, mount: 'ceil', build: () => [] };
    const lens = cr => `<defs><radialGradient id="cp10g" cx="42%" cy="38%" r="62%"><stop offset="0" stop-color="#4b4f9a"/><stop offset="0.45" stop-color="#1d2244"/><stop offset="1" stop-color="#05060a"/></radialGradient></defs><circle r="${f1(cr)}" fill="#111215"/><circle r="${f1(cr * 0.8)}" fill="url(#cp10g)"/><circle r="${f1(cr * 0.8)}" fill="none" stroke="#3a3d44" stroke-width="0.3"/><path d="M${f1(-cr * 0.62)} ${f1(-cr * 0.1)}A${f1(cr * 0.64)} ${f1(cr * 0.64)} 0 0 1 ${f1(cr * 0.1)} ${f1(-cr * 0.62)}" stroke="#7affc8" stroke-opacity="0.45" stroke-width="0.35" fill="none"/><path d="M${f1(cr * 0.5)} ${f1(cr * 0.2)}A${f1(cr * 0.55)} ${f1(cr * 0.55)} 0 0 1 ${f1(-cr * 0.1)} ${f1(cr * 0.55)}" stroke="#ff7ae0" stroke-opacity="0.35" stroke-width="0.3" fill="none"/><ellipse cx="${f1(-cr * 0.28)}" cy="${f1(-cr * 0.3)}" rx="${f1(cr * 0.22)}" ry="${f1(cr * 0.13)}" fill="#ffffff" opacity="0.75" transform="rotate(-35 ${f1(-cr * 0.28)} ${f1(-cr * 0.3)})"/>`;
    const front = `<circle cx="${PW / 2 + LX}" cy="${PH - LY}" r="6.6" fill="#1b1d20"/><circle cx="${PW / 2 + LX}" cy="${PH - LY}" r="6.6" fill="none" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.35"/>` + rep(9, i => `<rect x="${f1(24 + i * 1.65)}" y="2.6" width="0.8" height="7.8" rx="0.4" fill="#000000" fill-opacity="0.42"/>`).join('') + `<text x="31" y="12.1" text-anchor="middle" ${FONT} font-size="1.5" fill="#9aa1a6" letter-spacing="0.3">FULL HD 1080p</text>`;
    const top = `<circle cx="31" cy="23" r="4.2" fill="#e2e5e5" stroke="#b9bfc1" stroke-width="0.35"/><circle cx="31" cy="23" r="1.5" fill="#f4f5f5" stroke="#aab0b3" stroke-width="0.3"/>${[0, 90, 180, 270].map(a => `<path d="M31 19.6l0.9 1.1h-1.8z" fill="#8f979b" transform="rotate(${a} 31 23)"/>`).join('')}<circle cx="37" cy="29.5" r="1.3" fill="#e7eaea" stroke="#aab0b3" stroke-width="0.3"/><circle cx="37" cy="27.3" r="0.45" fill="#3fd0ff">${an('opacity', '1;0.25;1', 2.4)}</circle>`
      + `<rect x="5.5" y="24" width="10" height="2" rx="1" fill="#c9cecf"/><rect x="9" y="23.6" width="2.4" height="2.8" rx="0.6" fill="#8f979b"/><text x="21" y="9" text-anchor="middle" ${FONT} font-size="2.6" fill="#b5bbbd" letter-spacing="1.2">LUMINA</text>`;
    const side = rep(11, i => `<rect x="${f1(5 + i * 2.2)}" y="2.4" width="1.1" height="8.4" rx="0.55" fill="#000000" fill-opacity="0.4"/>`).join('');
    D.fx = ctx => { const C = cam(ctx); let s = '';
      s += box3(C, { c: [0, 0, 0], w: PW, h: PH, d: PD, r: 5, col: '#eceeed', gl: 0.35, mat: 'noise', dec: { f: front, t: top, r: side }, olw: 0.45 });
      s += cyl3(C, [LX, LY, PD / 2 - 0.3], [LX, LY, PD / 2 + 2.2], 5.9, '#2b2d31', { mat: 'metal', olw: 0.35 }) + cyl3(C, [LX, LY, PD / 2 + 2.2], [LX, LY, PD / 2 + 4.2], 5.3, '#1a1b1e', { mat: 'gloss', cap: lens, olw: 0.35 });
      [[-14, -11], [14, -11], [-14, 11], [14, 11]].sort((a, b) => a[1] - b[1]).forEach(([x, z]) => s += cyl3(C, [x * 0.4, PH + 2.6, z * 0.4], [x, PH + 0.2, z], 0.75, '#2b2d31', { mat: 'metal', olw: 0.25 }) + cyl3(C, [x, PH, z], [x, PH + 0.8, z], 1.5, '#2b2d31', { mat: 'metal', olw: 0.25 }));
      s += cyl3(C, [0, PH + 1.6, 0], [0, PH + 4, 0], 3.4, '#232428', { mat: 'metal', olw: 0.35 }) + cyl3(C, [0, PH + 4, 0], [0, 34, 0], 1.25, '#cdd3d7', { mat: 'chrome', olw: 0.3 });
      s += cyl3(C, [0, 32.5, 0], [0, 35.5, 0], 2.3, '#232428', { mat: 'metal', olw: 0.3 }) + cyl3(C, [2.1, 34, 0], [4.6, 34, 0], 0.7, '#3b3e43', { mat: 'metal', olw: 0.25 }) + cyl3(C, [0, 35.5, 0], [0, 49, 0], 1.75, '#cdd3d7', { mat: 'chrome', olw: 0.3 });
      s += cyl3(C, [0, 49, 0], [0, 51, 0], 8.5, '#eceeed', { cap: cr => [0, 120, 240].map(a => `<circle cx="${f1(cr * 0.68 * Math.cos(a * PI / 180))}" cy="${f1(cr * 0.68 * Math.sin(a * PI / 180))}" r="0.7" fill="#b9bfc1" stroke="#8f979b" stroke-width="0.2"/>`).join(''), olw: 0.35 });
      return { defs: DEF10, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-030 2.1 BLUETOOTH SOUNDBAR & MINI WOOFER =======================
  N.sbar10 = S => { const on = isPlay(S), BW = 86, BH = 7.2, BD = 9, WW = 24, WH = 30, WD = 27;
    const D = { w: 116, d: 46, build: () => [] };
    const pump = on ? at('scale', '1;1.07;0.98;1', 0.42, 0, SPL(3)) : '';
    const wF = `<defs><radialGradient id="sb10c" cx="45%" cy="40%" r="60%"><stop offset="0" stop-color="#4a4d53"/><stop offset="0.7" stop-color="#1c1d21"/><stop offset="1" stop-color="#0c0c0e"/></radialGradient><radialGradient id="sb10d" cx="38%" cy="32%" r="70%"><stop offset="0" stop-color="#9aa0a8"/><stop offset="0.45" stop-color="#3a3d43"/><stop offset="1" stop-color="#101113"/></radialGradient></defs>`
      + `<circle cx="12" cy="12.5" r="9.9" fill="#070708"/><circle cx="12" cy="12.5" r="9.9" fill="none" stroke="#ffffff" stroke-opacity="0.18" stroke-width="0.35"/><g transform="translate(12 12.5)"><g>${pump}<circle r="9.1" fill="#26272b"/><circle r="9.1" fill="none" stroke="#3d3f44" stroke-width="1.2"/><path d="M-6.5 -6.5A9.2 9.2 0 0 1 6.5 -6.5" stroke="#ffffff" stroke-opacity="0.22" stroke-width="0.7" fill="none"/><circle r="7.6" fill="url(#sb10c)"/><circle r="7.6" fill="none" stroke="#000000" stroke-opacity="0.5" stroke-width="0.4"/>${rep(3, i => `<circle r="${f1(3.8 + i * 1.2)}" fill="none" stroke="#000000" stroke-opacity="0.18" stroke-width="0.25"/>`).join('')}<circle r="2.9" fill="url(#sb10d)"/></g></g>`
      + `<rect x="6" y="25" width="12" height="2.8" rx="1.4" fill="#040405"/><path d="M6.8 27.6H17.2" stroke="#ffffff" stroke-opacity="0.2" stroke-width="0.3"/><text x="12" y="1.9" text-anchor="middle" ${FONT} font-size="1.3" fill="#8f949a" letter-spacing="0.6">SUB·2.1</text>`;
    const bF = `<text x="${BW / 2}" y="3.6" text-anchor="middle" ${FONT} font-size="1.6" fill="#a9aeb3" letter-spacing="0.8">SOUNDBAR</text>` + rep(5, i => `<circle cx="${f1(BW / 2 - 4 + i * 2)}" cy="5.6" r="0.36" fill="#ffffff" opacity="${on ? 0.9 : 0.25}">${on ? an('opacity', ['0.2;0.95;0.4;0.9;0.2', '0.6;0.2;0.95;0.3;0.6', '0.9;0.4;0.2;0.95;0.9'][i % 3], 0.9 + i * 0.07, -i * 0.13) : ''}</circle>`).join('');
    const bT = [['⏻', 62], ['–', 67], ['+', 72], ['◦', 77]].map(([g, x]) => `<circle cx="${x}" cy="4.5" r="1.5" fill="#17181b" stroke="#3a3c41" stroke-width="0.3"/><circle cx="${x - 0.3}" cy="4.2" r="1.1" fill="#ffffff" opacity="0.06"/><text x="${x}" y="5.15" text-anchor="middle" font-family="Arial" font-size="1.7" fill="#9aa0a6">${g}</text>`).join('') + `<circle cx="10" cy="4.5" r="0.55" fill="${on ? '#3fa8ff' : '#2a4a6a'}"/>`;
    D.fx = ctx => { const C = cam(ctx); let s = shadow(C, 34, -6, 20, 20, 0.8) + shadow(C, -16, 13, 48, 9, 0.7);
      [[24, -17], [44, -17], [24, 5], [44, 5]].forEach(([x, z]) => s += cyl3(C, [x, 0, z], [x, 1.2, z], 1.5, '#151517', { mat: 'matte', ol: 0 }));
      s += box3(C, { c: [34, 1.2, -6], w: WW, h: WH, d: WD, r: 1.8, col: '#1d1e22', mat: 'noise', gl: 0.15, dec: { f: wF, t: `<text x="12" y="25" text-anchor="middle" ${FONT} font-size="1.6" fill="#55585e" letter-spacing="1">BASS</text>` }, olc: '#060607', olw: 0.5, edge: 0.18 });
      s += box3(C, { c: [-16, 0.6, 13], w: BW, h: BH, d: BD, r: 3.6, col: '#232428', mat: 'mesh', tpat: 'noise', gl: 0.1, dec: { f: bF, t: bT }, olc: '#060607', olw: 0.5, edge: 0.2 });
      return { defs: DEF10, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-031 COUNTERTOP HOT-AIR POPCORN POPPER (pops live) =======================
  N.popr10 = S => { const BZ = -4, BR = 12, HR = 10.6, BX = 0, BWZ = 24;
    const D = { w: 44, d: 62, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), th = C.thV, R = rng('popr10'); let s = shadow(C, 0, BZ, 17, 15, 0.85) + shadow(C, BX, BWZ, 17, 13, 0.8);
      s += cyl3(C, [0, 0, BZ], [0, 1.6, BZ], BR + 0.4, '#3a3b3f', { mat: 'matte', olw: 0.35 }) + cyl3(C, [0, 1.6, BZ], [0, 12.6, BZ], BR, '#f4f1ea', { mat: 'gloss', noCap: 1, olw: 0.4 }) + cyl3(C, [0, 12.4, BZ], [0, 15.2, BZ], BR + 0.15, '#cf2f2a', { mat: 'gloss', olw: 0.4 });
      [-0.95, -0.7, -0.45, 0.45, 0.7, 0.95].forEach(dt => s += `<g transform="${tanF(C, 0, BZ, BR + 0.05, th + dt, 11.4)}"><rect x="-0.45" width="0.9" height="6.4" rx="0.45" fill="#000000" opacity="0.4"/><path d="M0.35 0.4V6" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.2"/></g>`);
      s += `<g transform="${tanF(C, 0, BZ, BR + 0.05, th, 8.6)}"><rect x="-3" y="0" width="6" height="4.2" rx="1" fill="#2a2b2e"/><rect x="-2.4" y="0.5" width="4.8" height="3.2" rx="0.8" fill="#d8322f"/><rect x="-2.4" y="0.5" width="4.8" height="1.4" rx="0.6" fill="#ffffff" opacity="0.3"/><text y="6.2" text-anchor="middle" ${FONT} font-size="1.3" fill="#8a857c">ON · OFF</text></g>`
        + `<g transform="${tanF(C, 0, BZ, BR + 0.05, th - 0.12, 3.6)}"><text text-anchor="middle" ${FONT} font-size="1.8" fill="#cf2f2a" letter-spacing="0.6">POP·AIR</text></g>`;
      // clear amber chute hood with kernels swirling inside
      s += cyl3(C, [0, 15.2, BZ], [0, 26, BZ], HR, '#f2c142', { r2: 9.3, mat: 'gloss', op: 0.34, noCap: 1, olc: '#a8781c', olw: 0.4, olo: 0.6 });
      const kc = C.p(0, 18.5, BZ), rx = HR * C.k * 0.8, ry = HR * C.k * 0.3, ring = `M${f1(kc[0] - rx)} ${f1(kc[1])}a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(2 * rx)} 0a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(-2 * rx)} 0`;
      s += rep(9, i => `<ellipse rx="${f1(0.9 * C.k)}" ry="${f1(0.65 * C.k)}" fill="${i % 3 ? '#e8a73a' : '#fff4d6'}" stroke="#9a6a1c" stroke-width="0.2"><animateMotion dur="${n4(0.5 + (i % 4) * 0.08)}s" begin="${n4(-i * 0.13)}s" repeatCount="indefinite" path="${ring}"/>${an('cy', `0;${f1(-3 - (i % 3) * 2)};0`, 0.31 + (i % 3) * 0.07, -i * 0.05)}</ellipse>`).join('');
      // chute spout (tilted clear box) + butter cup
      const tl = 0.42, ey = [0, Math.cos(tl), Math.sin(tl)], ez = [0, -Math.sin(tl), Math.cos(tl)];
      s += box3(C, { c: [0, 18.4, BZ + 9.4], ax: [[1, 0, 0], ey, ez], w: 12, h: 5.6, d: 11, r: 2, col: '#f2c142', op: 0.38, gl: 0.9, olc: '#a8781c', olw: 0.4, olo: 0.6, edge: 0.6 });
      const H = C.p(0, 26, BZ), hx = 9.3 * C.k; s += `<path d="M${f1(H[0] - hx + 1.2)} ${f1(H[1] + 1)}Q${f1(H[0] - hx - 0.6)} ${f1(H[1] + 14)} ${f1(H[0] - hx + 1.6)} ${f1(H[1] + 22)}" stroke="#ffffff" stroke-opacity="0.6" stroke-width="1.1" fill="none" stroke-linecap="round"/>`;
      s += cyl3(C, [0, 26, BZ], [0, 30.2, BZ], 7.3, '#f2c230', { r2: 8.2, mat: 'gloss', olw: 0.4, cap: cr => `<circle r="${f1(cr * 0.86)}" fill="#c98f12"/><circle r="${f1(cr * 0.86)}" fill="url(#m10in)"/><rect x="-2.2" y="-1.4" width="4.4" height="3" rx="0.6" fill="#fff1a8" transform="rotate(-12)"/><path d="M${f1(-cr * 0.6)} ${f1(cr * 0.6)}h3" stroke="#a8761a" stroke-width="0.35"/>` });
      // popcorn bowl: tapered red bowl, dark inside, heaped popcorn, rim on top
      s += cyl3(C, [BX, 0, BWZ], [BX, 9.5, BWZ], 7.5, '#c8392f', { r2: 13.5, mat: 'gloss', noCap: 1, olw: 0.45 });
      const rimP = rep(40, i => { const t = i / 40 * 2 * PI; return C.p(BX + 13.5 * Math.cos(t), 9.5, BWZ + 13.5 * Math.sin(t)); });
      s += `<path d="${pth(rimP)}" fill="#6e1a14"/><path d="${pth(rimP)}" fill="url(#m10in)"/>`;
      const heap = rep(46, () => { const a = R() * 2 * PI, d = Math.sqrt(R()) * 11.6, x = BX + d * Math.cos(a), z = BWZ + d * Math.sin(a); return { x, z, y: 9.4 + 4.6 * (1 - (d / 12.5) ** 2) + R() * 1.2, r: R() * 360 }; }).sort((a, b) => (a.z + a.y * 0.3) - (b.z + b.y * 0.3));
      heap.forEach(q => s += puffAt(C, [q.x, q.y, q.z], 0.95 + R() * 0.25, q.r));
      const rimF = rep(21, i => { const t = i / 20 * PI; return C.p(BX + 13.5 * Math.cos(t), 9.5, BWZ + 13.5 * Math.sin(t)); });
      s += `<path d="M${rimF.map(P2).join('L')}" stroke="#e45a4e" stroke-width="1.1" fill="none" stroke-linecap="round"/><path d="M${rimF.map(P2).join('L')}" stroke="#ffffff" stroke-opacity="0.35" stroke-width="0.4" fill="none" transform="translate(0 -0.4)"/>`;
      // live: popcorn shooting out of the spout into the bowl
      const m0 = C.p(0, 17.8, BZ + 14.4);
      s += rep(6, i => { const e = C.p(BX + (R() - 0.5) * 14, 13.5 + R() * 2, BWZ + (R() - 0.5) * 12), c = [(m0[0] + e[0]) / 2 + (R() - 0.5) * 6, Math.min(m0[1], e[1]) - 6 - R() * 5], d = 0.9 + R() * 0.5, b = -i * 0.27;
        return `<g opacity="0"><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;0.08;0.85;1" dur="${n4(d)}s" begin="${n4(b)}s" repeatCount="indefinite"/><animateMotion dur="${n4(d)}s" begin="${n4(b)}s" repeatCount="indefinite" path="M${P2(m0)}Q${P2(c)} ${P2(e)}"/><g transform="scale(${n4(C.k)})"><g>${at('rotate', `0;${R() > 0.5 ? 360 : -360}`, d * 0.9)}${PUFF}</g></g></g>`; }).join('');
      return { defs: DEF10, front: s, bb: C.bb(8) }; };
    return D; };

  // ---------- catalog edits ----------
  const OPEN = (l, s, note, ex) => Object.assign({ play: 'open', playL: 'Open the ' + l, stopL: 'Close the ' + l, playS: s, idleS: 'Tap to open the ' + l, live: 'Opens', note }, ex || {});
  RD.SET10 = {
    'MOV-002': { name: 'Wrinkled Bedsheet Projector Screen Tacked to Wall' },
    'MOV-014': Object.assign({ spec: 'cool10' }, OPEN('lid', 'Lid open · ice cold · tap to close', 'A beaded white styrofoam cooler with molded bands, hand grips and a fitted lid. Tap it: the lid swings back onto its hinge edge, showing cans of soda buried in ice with two blue gel ice packs, and cold mist rolls out. Tap again to close it.')),
    'MOV-022': { spec: 'plas10', note: 'A thick 42-inch piano-black plasma with a silver speaker strip, perforated grilles, a red standby light and a glossy glass screen. It hangs on a steel tilt bracket (rails and safety knobs peek out underneath) with its power cable dangling down the wall.' },
    'MOV-026': { spec: 'cproj10', note: 'A satin-white 1080p home projector hanging from a telescoping chrome ceiling pole on a spider cradle. Coated glass lens with focus ring, exhaust louvres, a control pad on top and a blinking status light.' },
    'MOV-030': { spec: 'sbar10', note: 'A fabric-wrapped 2.1 soundbar with top touch buttons and a row of status lights, plus a compact black subwoofer with an exposed driver and bass port. Tap it to play music: the woofer cone pumps and the lights dance.' },
    'MOV-031': { spec: 'popr10', live: 'Pops live', note: 'A red-and-white hot-air popper with a clear amber chute, a yellow butter cup on top and an ON/OFF rocker. Kernels whirl inside the chute and fluffy popcorn shoots out into a red bowl heaped with popcorn.' },
    'MOV-034': Object.assign({ spec: 'mfr10' }, OPEN('door', 'Door open · cold light on · tap to close', 'A glossy mint 6-can thermoelectric mini fridge with a recessed handle and a blue 4°C display. Tap it: the door swings open on its hinge to show two rows of three cans on a wire shelf, a spinning cooling fan and a cool blue glow. Tap again to close it.')),
  };
  const edit9 = RD.edit;
  RD.edit = rows => edit9(rows).map(r => RD.SET10[r.id] ? Object.assign({}, r, RD.SET10[r.id]) : r);
  RD.H10 = { PAT, cam, box3, cyl3, sph, shadow, tanF, FR, flip, KV, easeA, mist, lit, vis, yawA, DEF10, can3, puffAt, PUFF, hull, pth, add, sub, mul, dot, cross, nrm, rng, isPlay, an, at, SPL, f1, n4, rep, P2, FONT };
  RD.PLUS10 = 1;
})();
