// Tier 2 movie: "Who Ate the Moon Pie?" (2 min spooky-cute mystery). Needs movies.js + movies-kit.js.
(function () {
  const SM = window.SquadMovies, K = window.MK; if (!SM || !K || !SM.def) return;
  const { D, P, E, kf, win, put, show, actor, pose, go, dance, bub, lines, parts, rain, lightning, glow, film, snd, rnd, cl, lerp } = K;
  const FY = 160, W = 58;
  const HAT = '<svg viewBox="0 0 30 14" width="30" height="14"><path d="M3 11 Q15 15 27 11 L27 12.6 Q15 16.6 3 12.6Z" fill="#3a2a22"></path><path d="M8 11 L9.5 3 Q15 0 20.5 3 L22 11Z" fill="#5a4030"></path><path d="M8.6 8.4 L21.4 8.4 L21.8 10.6 L8.2 10.6Z" fill="#2a1a12"></path><path d="M12 3.5 Q15 5 18 3.5" stroke="#3a2a22" stroke-width="1" fill="none"></path></svg>';
  const LENS = '<svg viewBox="0 0 30 30" width="30" height="30"><path d="M19 19 L28 28" stroke="#6a4a2a" stroke-width="4" stroke-linecap="round"></path><circle cx="12" cy="12" r="9" fill="rgba(200,230,255,0.35)" stroke="#c9a24a" stroke-width="3"></circle><path d="M7 9 Q9 6 12 6" stroke="#ffffff" stroke-width="1.5" fill="none" opacity="0.8"></path></svg>';
  const LANT = '<svg viewBox="0 0 16 22" width="16" height="22"><path d="M5 3 Q8 0 11 3" stroke="#3a2a22" stroke-width="1.4" fill="none"></path><rect x="3" y="4" width="10" height="3" rx="1" fill="#5a4030"></rect><rect x="4" y="7" width="8" height="10" rx="2" fill="#ffe28a" stroke="#5a4030" stroke-width="1.2"></rect><rect x="3" y="17" width="10" height="3" rx="1" fill="#5a4030"></rect></svg>';
  const LAMP = '<svg viewBox="0 0 60 30" width="60" height="30"><path d="M8 18 Q4 10 12 10 L40 10 Q50 10 58 4 Q54 14 46 18 Q46 26 30 27 Q14 26 14 20Z" fill="#e2b14a" stroke="#7a5414" stroke-width="1.4"></path><ellipse cx="27" cy="10" rx="10" ry="3" fill="#f6d36a" stroke="#7a5414" stroke-width="1.2"></ellipse><circle cx="27" cy="6" r="2.6" fill="#f6d36a" stroke="#7a5414" stroke-width="1"></circle><path d="M8 18 Q2 18 3 13 Q4 10 9 12" fill="none" stroke="#7a5414" stroke-width="2"></path><path d="M18 18 Q28 22 40 17" stroke="#fff3c0" stroke-width="1.6" fill="none" opacity="0.8"></path></svg>';
  const PIE = '<svg viewBox="0 0 80 40" width="80" height="40"><ellipse cx="40" cy="30" rx="38" ry="9" fill="#c98a4a"></ellipse><path d="M2 30 L2 22 Q40 4 78 22 L78 30 Q40 40 2 30Z" fill="#b8763a"></path><ellipse cx="40" cy="21" rx="36" ry="12" fill="#5a3420"></ellipse><path d="M34 12 A10 10 0 1 0 50 26 A8 8 0 1 1 34 12Z" fill="#fff2b8"></path><circle cx="22" cy="20" r="1.6" fill="#ffffff" opacity="0.8"></circle><circle cx="58" cy="17" r="1.3" fill="#ffffff" opacity="0.8"></circle><circle cx="27" cy="26" r="1" fill="#ffffff" opacity="0.8"></circle></svg>';
  // the bakery at night (spot = dark overlay with a hole of light)
  function bakery(L, seed) {
    const cam = D(L, 'left:0;top:0;width:320px;height:180px;transform-origin:160px 110px;');
    D(cam, 'left:-40px;top:0;width:800px;height:142px;background:linear-gradient(#141a42,#26306a 70%,#2e3a78);');
    D(cam, 'left:-40px;top:96px;width:800px;height:46px;background:repeating-linear-gradient(90deg,#3a2f5e 0 18px,#342a56 18px 20px);border-top:3px solid #4b3f78;');
    const w = D(cam, 'left:228px;top:18px;width:66px;height:54px;overflow:hidden;border:4px solid #4b3f78;background:linear-gradient(#0b1030,#1c2a62);'); const moon = D(w, 'left:38px;top:6px;width:16px;height:16px;border-radius:50%;background:#fff6c8;box-shadow:0 0 12px 4px rgba(255,246,200,0.5);');
    D(w, 'left:31px;top:0;width:3px;height:100%;background:#4b3f78;'); D(w, 'left:0;top:24px;width:100%;height:3px;background:#4b3f78;'); const rn = rain(w, 26, seed); const wf = D(w, 'inset:0;background:#dfe8ff;opacity:0;');
    [[20, 26], [20, 58]].forEach(([x, y]) => { D(cam, 'left:' + x + 'px;top:' + y + 'px;width:70px;height:4px;background:#5a4a86;'); [0, 1, 2].forEach(k => D(cam, 'left:' + (x + 6 + k * 22) + 'px;top:' + (y - 14 + (k % 2) * 3) + 'px;width:13px;height:' + (14 - (k % 2) * 3) + 'px;border-radius:3px 3px 2px 2px;background:' + ['#6a5aa6', '#8a6ab6', '#5a7ab6'][k] + ';border:1px solid #2a2050;')); });
    D(cam, 'left:-40px;top:142px;width:800px;height:40px;background:repeating-conic-gradient(#1e1a40 0% 25%,#2c2856 0% 50%) 0 0/28px 14px;');
    const ctr = D(cam, 'left:96px;top:106px;width:128px;height:44px;'); D(ctr, 'left:0;top:6px;width:128px;height:38px;border-radius:2px;background:linear-gradient(#5a4a8a,#3e3270);'); D(ctr, 'left:-4px;top:0;width:136px;height:7px;border-radius:3px;background:#8a7ac0;');
    D(ctr, 'left:10px;top:16px;width:50px;height:20px;border:2px solid #6a5aa0;border-radius:2px;box-sizing:border-box;'); D(ctr, 'left:68px;top:16px;width:50px;height:20px;border:2px solid #6a5aa0;border-radius:2px;box-sizing:border-box;');
    const plate = D(cam, 'left:140px;top:96px;width:40px;height:12px;', '<svg viewBox="0 0 40 12" width="40" height="12"><ellipse cx="20" cy="8" rx="19" ry="3.6" fill="#dfe6ff" stroke="#8a90c0" stroke-width="0.8"></ellipse><path d="M17 11 L23 11 L22 6 L18 6Z" fill="#c2c8ee"></path><circle cx="14" cy="7" r="0.9" fill="#a8743a"></circle><circle cx="25" cy="7.6" r="0.8" fill="#a8743a"></circle><circle cx="20" cy="6.6" r="0.7" fill="#a8743a"></circle></svg>');
    D(cam, 'left:186px;top:91px;width:26px;height:16px;border-radius:2px;background:#fff6dc;border:1px solid #8a7050;font-size:5.2px;line-height:7px;color:#5a3420;text-align:center;padding-top:1px;box-sizing:border-box;', 'MOON<br>PIE');
    const lamp = D(cam, 'left:150px;top:0;width:20px;height:26px;', '<svg viewBox="0 0 20 26" width="20" height="26"><path d="M10 0 L10 12" stroke="#4b3f78" stroke-width="1.5"></path><path d="M3 20 L6 12 L14 12 L17 20Z" fill="#6a5aa6"></path></svg>');
    const act = D(cam, 'left:0;top:0;width:320px;height:180px;');
    const dark = D(L, 'inset:0;pointer-events:none;'), fl = D(L, 'inset:0;background:#e6eeff;opacity:0;pointer-events:none;');
    return { cam, act, ctr, plate, lamp, upd(t, o = {}) { rn(t); const l = o.flash || 0; wf.style.opacity = (l * 0.8).toFixed(3); fl.style.opacity = (l * 0.55).toFixed(3); const d = o.dark ?? 0.55, sp = o.spot;
      dark.style.background = sp ? 'radial-gradient(circle at ' + sp[0] + 'px ' + sp[1] + 'px, rgba(6,8,28,0) ' + sp[2] + 'px, rgba(6,8,28,' + d + ') ' + (sp[2] * 1.8) + 'px)' : 'rgba(6,8,28,' + d + ')';
      if (o.cam) cam.style.transform = 'translate(' + (o.cam[0] || 0).toFixed(1) + 'px,' + (o.cam[1] || 0).toFixed(1) + 'px) scale(' + (o.cam[2] || 1).toFixed(3) + ')'; } };
  }
  const boo = (p) => { const a = actor(p, 'boo', W), h = D(p, 'left:0;top:0;display:none;z-index:6;', HAT), g = D(p, 'left:0;top:0;display:none;z-index:6;', LENS); return { a, put(s, o = {}) { pose(a, s); if (!s) { show(h, false); show(g, false); return; } put(h, s.x + 1 + (s.r || 0) * 0.5, s.y - W * 0.86 - (o.tip || 0), 1, (s.r || 0) + (o.tip ? -14 : -6), 1); if (o.lens) put(g, o.lens[0], o.lens[1], 1, o.lens[2] || 0, 1); else show(g, false); } }; };
  const hoot = (p) => { const a = actor(p, 'hoot', W - 4), l = D(p, 'left:0;top:0;display:none;z-index:6;', LANT), gl = glow(p, 'rgba(255,226,140,0.55)', 40, 'z-index:2;'); return { a, put(s, on = 1) { pose(a, s); if (!s) { show(l, false); show(gl, false); return; } const x = s.x + 19, y = s.y - 24 + Math.sin(s.r || 0) * 2; put(l, x, y, 1, Math.sin(Date.now() / 300) * 4, 1); put(gl, x, y, 1, 0, on); } }; };

  function mk() {
    const S = [];
    S.push({ a: 0, b: 14, rgb: '120,140,255', lit: t => 0.4 + lightning(t, [8.5, 11.2]) * 0.8, mk(L) { const B = bakery(L, 3), ti = D(L, "left:0;top:34px;width:320px;text-align:center;font-family:'Creepster',cursive;font-size:30px;line-height:1.05;color:#c8f08a;text-shadow:0 0 10px rgba(150,255,120,0.6),0 3px 0 #1a1040;letter-spacing:1px;z-index:40;", 'WHO ATE THE<br>MOON PIE?');
      return t => { const l = lightning(t, [8.5, 11.2]); ti.style.opacity = (P(t, 0.6, 2) * (1 - P(t, 6, 7))).toFixed(3); ti.style.transform = 'translateY(' + (Math.sin(t * 2) * 2).toFixed(1) + 'px)';
        const z = kf(t, [[6.5, 1], [12, 1.9]]), cx = (1 - z) * 0; B.upd(t, { flash: l, dark: 0.5 + 0.2 * P(t, 6, 8), spot: [160, 100, 30 + 25 * l], cam: [cx, (z - 1) * 10, z] }); B.cam.style.transformOrigin = '160px 102px'; }; } });
    S.push({ a: 14, b: 26, rgb: '120,140,255', mk(L) { const B = bakery(L, 5), b = boo(B.act), h = hoot(B.act), sp = bub(L);
      return t => { const bs = go(t, [[0, -30, 150, { m: 'float' }], [3, 118, 150]], { m: 'float', gy: FY, f: 'front' }), hs = go(t, [[0.8, 350], [1.3, 320, null, { m: 'hop' }], [1.8, 290, null, { m: 'hop' }], [2.3, 260, null, { m: 'hop' }], [2.8, 232, null, { m: 'hop' }], [3.3, 206]], { y: FY, m: 'hop', f: 'front' });
        b.put(bs, { lens: bs && t > 3 ? [bs.x + 22, bs.y - 30 + Math.sin(t * 3) * 2, -10] : null }); h.put(hs); B.upd(t, { dark: 0.42, spot: hs ? [hs.x + 19, hs.y - 24, 50] : null });
        lines(sp, t, [[2.6, 5.4, 'A crime... at the bakery!', 'b'], [5.8, 8.6, 'Hoo... who did this?', 'h'], [9, 11.8, 'Line up the suspects!', 'b']], { b: bs && [bs.x, bs.y - 60], h: hs && [hs.x, hs.y - 54] }); }; } });
    S.push({ a: 26, b: 46, rgb: '150,160,255', mk(L) { const B = bakery(L, 7), b = boo(B.act), h = hoot(B.act), m = actor(B.act, 'mochi', W), sp = bub(L), cone = D(B.act, 'left:118px;top:20px;width:84px;height:140px;background:linear-gradient(rgba(255,240,180,0.35),rgba(255,240,180,0.04));clip-path:polygon(40% 0,60% 0,100% 100%,0 100%);');
      const fl = parts(B.act, 22, 'width:10px;height:10px;border-radius:50%;background:#ffffff;z-index:8;', null, (i, t) => { const d = t - 10.2; if (d < 0 || d > 2.6) return null; const r = rnd(i * 7 + 1), a = Math.PI * (0.65 + r() * 0.7), s = 40 + r() * 70, e = 1 - Math.exp(-d * 3); return { x: 160 + Math.cos(a) * s * e, y: 128 + Math.sin(a) * s * 0.5 * e - d * 6, k: 0.8 + d * 1.2, o: 0.9 * (1 - d / 2.6) }; });
      return t => { const blow = P(t, 10.2, 10.5) * (1 - P(t, 12, 13.5)), bs = go(t, [[0, 100, 150, { m: 'float' }]], { m: 'float', gy: FY }), sn = t > 8.5 && t < 10.2 ? P(t, 8.5, 10.1, E.in) : t >= 10.2 && t < 10.6 ? 1 - P(t, 10.2, 10.45) : 0;
        if (bs) { bs.x -= blow * 34; bs.r += blow * -30; }
        const lx = t < 9 ? 140 + Math.sin(t * 1.6) * 14 : 120 - blow * 30, lens = [lx, 118 + Math.cos(t * 1.3) * 6, -20];
        b.put(bs, { lens }); h.put({ x: 250, y: FY, v: 'front', r: Math.sin(t * 2) * 2 }); pose(m, { x: 160, y: FY, v: 'front', sx: 1 - 0.1 * sn + 0.14 * (t >= 10.2 && t < 10.5 ? 1 : 0), sy: 1 + 0.14 * sn - 0.2 * (t >= 10.2 && t < 10.5 ? 1 : 0), r: t > 10.5 && t < 12 ? Math.sin(t * 20) * 4 : 0 }); fl(t);
        B.upd(t, { dark: 0.6, spot: [160, 120, 38] }); cone.style.opacity = '1';
        lines(sp, t, [[2, 5, 'Powder on your face, Mochi?', 'b'], [5.5, 8, 'I... I...', 'm'], [8.4, 10.1, 'A... a... a...', 'm'], [10.2, 11.4, 'ACHOO!', 'm'], [11.8, 14.6, 'Just flour! Sorry!', 'm'], [15, 18.6, 'Not our pie thief.', 'h']], { b: bs && [bs.x, bs.y - 60], m: [160, 104], h: [250, 104] }); }; } });
    S.push({ a: 46, b: 62, rgb: '150,160,255', mk(L) { const B = bakery(L, 9), b = boo(B.act), h = hoot(B.act), pu = actor(B.act, 'puddi', W - 6), sp = bub(L), tray = D(B.act, 'left:198px;top:101px;width:60px;height:7px;border-radius:3px;background:linear-gradient(#cfd4ee,#8a90c0);');
      const zz = parts(B.act, 3, "font-family:'Fredoka',sans-serif;font-weight:700;font-size:11px;color:#c9d4ff;z-index:8;", 'z', (i, t) => { if (t > 7) return null; const a = (t * 0.45 + i / 3) % 1; return { x: 236 + a * 16 + Math.sin(a * 6) * 3, y: 70 - a * 30, k: 0.7 + a * 0.8, o: Math.sin(Math.PI * a) }; });
      const gl = parts(B.act, 2, 'width:6px;height:6px;border-radius:50%;background:#ffd88a;box-shadow:0 0 6px 2px #ffb84a;z-index:8;', null, (i, t) => t < 5.5 ? { x: 222 + i * 9, y: 86 + i * 2, k: 0.6 + 0.4 * Math.abs(Math.sin(t * 4 + i)), o: 0.8 } : null);
      return t => { const up = P(t, 7, 7.35, E.back); b.put(go(t, [[0, 118, 150, { m: 'float' }]], { m: 'float', gy: FY }), { lens: t > 2 && t < 6 ? [226, 92, -10] : null });
        const hs = go(t, [[0, 290], [1.5, 290, null, { m: 'hop' }], [2.2, 262, null, { m: 'hop' }], [2.9, 252]], { y: FY, m: 'hop', f: 'left' }); if (hs && t > 5.6 && t < 7) { hs.v = 'left'; hs.r = Math.sin((t - 5.6) * 14) * 12; } h.put(hs);
        pose(pu, { x: 228, y: 103 - up * 6 - (t > 7 && t < 7.6 ? Math.sin((t - 7) * Math.PI / 0.6) * 14 : 0), v: 'front', r: t < 7 ? -8 + Math.sin(t * 1.5) * 2 : 0, sx: 1 + 0.03 * Math.sin(t * 2.5) * (1 - up), sy: 1 - 0.05 * Math.sin(t * 2.5) * (1 - up), sh: false }); zz(t); gl(t);
        B.upd(t, { dark: 0.5, spot: [228, 100, 40] }); show(tray, true);
        lines(sp, t, [[1, 3.8, 'Caramel on the counter...', 'b'], [7.4, 11, 'Huh?! I was only napping!', 'p'], [11.4, 15.4, 'Hmm... not him either.', 'b']], { b: [118, 92], p: [228, 52] }); }; } });
    S.push({ a: 62, b: 72, rgb: '60,70,160', lit: t => 0.08, mk(L) { const B = bakery(L, 11), b = boo(B.act), h = hoot(B.act), sp = bub(L), eyes = D(L, 'left:0;top:0;width:30px;height:10px;display:none;z-index:50;', '<svg viewBox="0 0 30 10" width="30" height="10"><ellipse cx="6" cy="5" rx="4.5" ry="3.4" fill="#f6ff8a"></ellipse><ellipse cx="24" cy="5" rx="4.5" ry="3.4" fill="#f6ff8a"></ellipse><circle cx="7" cy="5" r="1.6" fill="#1a1040"></circle><circle cx="25" cy="5" r="1.6" fill="#1a1040"></circle></svg>');
      return t => { const sh = t > 4 ? Math.sin(t * 50) * 1.5 : 0, bs = go(t, [[0, 120, 150, { m: 'float' }]], { m: 'float', gy: FY }); if (bs) bs.x += sh; b.put(bs); const hs = { x: 214 + sh, y: FY, v: 'front' }; h.put(hs, t < 1.4 ? (Math.random() < 0.5 ? 1 : 0.2) : 0);
        const dk = P(t, 0.2, 0.6); B.upd(t, { dark: 0.55 + 0.4 * dk, spot: t < 1.4 ? [233, 136, 40] : null });
        const bl = (t % 2.4) > 2.25 ? 0.15 : 1; if (t > 2.8) { put(eyes, 168 + Math.sin(t * 0.9) * 26, 128 + Math.sin(t * 1.4) * 4, 1, 0, P(t, 2.8, 3.4)); eyes.style.transform += ' scaleY(' + bl + ')'; } else show(eyes, false);
        lines(sp, t, [[1, 2.8, 'Uh-oh...', 'h'], [4.6, 8.6, 'W-w-who\u2019s there?!', 'b']], { b: bs && [bs.x, bs.y - 60], h: [214, 104] }); }; } });
    S.push({ a: 72, b: 86, rgb: '150,160,255', inF: false, mk(L) { const B = bakery(L, 13), b = boo(B.act), h = hoot(B.act), ch = actor(B.act, 'chip', W), sp = bub(L);
      const sp2 = parts(B.act, 6, 'width:7px;height:7px;z-index:8;', '<svg viewBox="0 0 10 10" width="7" height="7"><path d="M5 0 L6 4 L10 5 L6 6 L5 10 L4 6 L0 5 L4 4Z" fill="#fff3b0"></path></svg>', (i, t) => { const a = (t * 0.8 + i / 6) % 1; return t < 9 ? { x: 160 + Math.cos(i * 1.7) * 18, y: 128 + Math.sin(i * 2.3) * 14, k: Math.sin(Math.PI * a) * 1.3, r: a * 90, o: 1 } : null; });
      return t => { const cs = go(t, [[0, 160, 172, { m: 'still' }], [1, 160, 172], [1.5, 160, FY, { m: 'hop', h: 10 }], [2.0, 160, FY]], { y: FY, f: 'front' }); pose(ch, cs); sp2(t);
        const bs = go(t, [[0, 112, 150, { m: 'float' }], [10, 112, 150], [12, 92, 150]], { m: 'float', gy: FY }); b.put(bs, { lens: t > 10.4 ? [80, 150, 40] : null }); h.put({ x: 222, y: FY - (t > 6 && t < 6.4 ? Math.sin((t - 6) * Math.PI / 0.4) * 8 : 0), v: 'front' }, 1);
        B.upd(t, { flash: 1 - P(t, 0, 0.5), dark: 0.38 });
        lines(sp, t, [[2.2, 5.6, 'Hi! It\u2019s just my chips!', 'c'], [6, 9.4, 'Phew!', 'h'], [10, 13.6, 'Wait... crumbs!', 'b']], { c: [160, 104], h: [222, 104], b: bs && [bs.x, bs.y - 60] }); }; } });
    S.push({ a: 86, b: 100, rgb: '150,160,255', mk(L) { const B = bakery(L, 15), b = boo(B.act), h = hoot(B.act), sp = bub(L), lamp = D(B.act, 'left:0;top:0;display:none;z-index:5;', LAMP);
      const cr = Array.from({ length: 14 }, (_, i) => D(B.act, 'left:' + (60 + i * 26 + (i % 2) * 5) + 'px;top:' + (163 + (i % 3) * 2) + 'px;width:3.5px;height:3px;border-radius:50%;background:#c98a4a;'));
      return t => { const px = kf(t, [[0, 0], [10, -190]], E.io); const bs = go(t, [[0, 70, 150, { m: 'float' }], [10, 270, 150]], { m: 'float', gy: FY }); if (bs) { bs.v = 'right'; } b.put(bs, { lens: bs ? [bs.x + 26, 156, 30] : null });
        const hs = go(t, [[0, 30], [10, 236]], { y: FY, m: 'walk', f: 'right' }); h.put(hs); const sh = t > 8 ? Math.sin(t * 46) * 2.5 * (0.5 + 0.5 * Math.sin(t * 3)) : 0; put(lamp, 420 + sh, 152, 1.2, sh * 2, 1);
        B.upd(t, { dark: 0.6, spot: hs ? [hs.x + 19 + px, hs.y - 24, 60] : null, cam: [px, 0, 1] }); B.cam.style.transformOrigin = '0 0';
        lines(sp, t, [[3, 6.6, 'Follow the crumbs...', 'b'], [8.2, 12, 'It ends at... a lamp?', 'h']], { b: bs && [bs.x + px, bs.y - 60], h: hs && [hs.x + px, hs.y - 54] }); }; } });
    S.push({ a: 100, b: 110, rgb: '190,140,255', inF: false, mk(L) { const B = bakery(L, 17), b = boo(B.act), h = hoot(B.act), j = actor(B.act, 'jinni', W + 6), sp = bub(L), lamp = D(B.act, 'left:0;top:0;z-index:5;', LAMP);
      const sm = parts(B.act, 16, 'width:22px;height:22px;border-radius:50%;background:#b98aff;z-index:7;', null, (i, t) => { if (t > 2.4) return null; const r = rnd(i + 40), a = r() * Math.PI * 2, d = P(t, 0, 1.4) * (14 + r() * 26); return { x: 208 + Math.cos(a) * d, y: 120 + Math.sin(a) * d * 0.7 - t * 8, k: 0.6 + t * 0.7, o: 0.85 * (1 - P(t, 1, 2.4, E.lin)) }; });
      const cb = parts(B.act, 3, 'width:3px;height:3px;border-radius:50%;background:#c98a4a;z-index:9;', null, (i, t, s) => null);
      return t => { put(lamp, 230, 152, 1.2, 0, 1); const js = t > 0.4 ? go(t, [[0.4, 210, 150, { m: 'float' }], [1.2, 210, 118]], { m: 'float', gy: 150, f: 'front' }) : null; if (js) { js.k = P(t, 0.4, 1, E.back); } pose(j, js); sm(t);
        b.put({ x: 80, y: 150 - Math.sin(t * 2.4) * 3 - (t < 1.2 ? P(t, 0.2, 0.5) * 10 : 0), v: 'front', gy: FY, r: t > 3 && t < 5 ? Math.sin(t * 14) * 5 : 0 }); h.put({ x: 46, y: FY - (t > 0.3 && t < 0.7 ? 8 : 0), v: 'front' });
        B.upd(t, { flash: (1 - P(t, 0, 0.4)) * 0.6, dark: 0.32 });
        lines(sp, t, [[2, 6, 'Oops! I wished for a snack!', 'j'], [6.4, 9.6, 'You?!', 'b']], { j: js && [js.x, js.y - 66], b: [80, 92] }); }; } });
    S.push({ a: 110, b: 120, rgb: '255,210,150', outF: false, mk(L) { const B = bakery(L, 19), sp = bub(L), pie = D(B.act, 'left:0;top:0;display:none;z-index:4;', PIE), b = boo(B.act), h = hoot(B.act), cast = ['mochi', 'puddi', 'chip'].map(k => actor(B.act, k, W - 8)), j = actor(B.act, 'jinni', W);
      const swirl = parts(B.act, 12, 'width:8px;height:8px;z-index:9;', '<svg viewBox="0 0 10 10" width="8" height="8"><path d="M5 0 L6 4 L10 5 L6 6 L5 10 L4 6 L0 5 L4 4Z" fill="#fff3b0"></path></svg>', (i, t) => { if (t > 3.5) return null; const a = t * 5 + i * 0.52, r = 40 * (1 - P(t, 0, 3)); return { x: 160 + Math.cos(a) * r, y: 104 + Math.sin(a) * r * 0.5, k: 1, r: a * 50, o: 1 - P(t, 2.6, 3.5) }; });
      const end = D(L, "left:0;top:16px;width:320px;text-align:center;font-family:'Creepster',cursive;font-size:22px;color:#c8f08a;text-shadow:0 2px 0 #1a1040;z-index:60;", 'THE END');
      return t => { const pk = P(t, 1.4, 2.2, E.back); put(pie, 160, 108, 1.05 * pk, 0, pk > 0.01 ? 1 : 0); swirl(t);
        const tip = t > 6 && t < 9 ? 8 * Math.sin(Math.PI * P(t, 6, 9, E.lin)) : 0;
        b.put({ ...dance(t, 60, 150, 'bounce', 0.5, 0.2), gy: FY }, { tip }); h.put({ ...dance(t, 280, FY, 'bounce', 0.5, 0.5) });
        cast.forEach((n, i) => pose(n, dance(t, [96, 128, 200][i], FY + 4, i === 1 ? 'sway' : 'bounce', 0.5, i * 0.3))); pose(j, { x: 240, y: 140 + Math.sin(t * 2.4) * 3, v: 'front', gy: FY + 4 });
        B.upd(t, { dark: 0.2 }); end.style.opacity = P(t, 8, 8.8).toFixed(3);
        lines(sp, t, [[2.4, 5.6, 'A new Moon Pie for everyone!', 'j'], [6, 9.2, 'Case closed!', 'b']], { j: [240, 76], b: [60, 90] }); }; } });
    return film(S, { rgb: '120,140,255' });
  }

  function score(Q) { const I = snd(Q), B = 0.5;
    I.thunder(0.1, 0.25); I.pad(0, [38, 45, 50], 7, 0.025, 'sawtooth', 500); I.theremin(1, 440, 660, 2.4); I.theremin(3.6, 620, 415, 2.6); I.thunder(8.5); I.thunder(11.2, 0.3); I.pad(7, [37, 44, 49], 7, 0.025, 'sawtooth', 500); I.theremin(9.2, 330, 523, 3.2, 0.07);
    const WALK = [50, 53, 57, 56, 55, 53, 52, 49, 50, 57, 53, 50, 45, 48, 49, 52];
    const walk = (t0, t1, up = 0, v = 0.09) => I.beat(t0, t1, B, (t, i) => { I.pluck(t, WALK[i % 16] - 12 + up, 0.22, v); if (i % 2) I.hat(t + B / 2, 0.025); if (i % 8 === 0) I.pad(t, [62 + up, 65 + up, 69 + up], B * 8, 0.012, 'triangle', 1200); });
    walk(14, 36); I.bell(16.5, 86, 1, 0.04); I.bell(16.8, 81, 1, 0.04); I.hoot(20.2);
    I.sneeze(34.4); I.poof(36.2, 0.25); I.boing(36.7); walk(37, 62); I.chirp(53.1, 0.06); I.boing(53, 0.08);
    I.tone(62.2, 240, 0.4, { to: 60, slide: 0.35, vol: 0.12, type: 'triangle' }); I.pad(62.4, [34, 41], 9.5, 0.03, 'sawtooth', 300);
    I.beat(63, 72, 0.75, (t, i) => { I.kick(t, 0.25); I.kick(t + 0.18, 0.18); }); I.theremin(65, 300, 390, 2.5, 0.06); I.theremin(67.6, 390, 280, 3.4, 0.06);
    I.tone(72, 400, 0.2, { to: 1200, slide: 0.15, vol: 0.06 }); I.sparkle(72.1, 79); I.pluck(74.2, 72, 0.2); I.pluck(74.4, 76, 0.2); I.pluck(74.6, 79, 0.3);
    walk(76, 86, 5, 0.08);
    I.beat(86, 100, B, (t, i) => { I.pluck(t, WALK[i % 16] - 7, 0.2, 0.08); if (i % 2) I.hat(t + B / 2, 0.02); }); I.theremin(88, 392, 466, 3, 0.05);
    I.beat(94, 100, 0.07, (t, i) => I.noise(t, 0.03, { ft: 'bandpass', f: 2600, q: 2, vol: 0.02 + 0.02 * ((t - 94) / 6) }));
    I.poof(100.3, 0.3); I.crash(100.3, 0.08); [72, 76, 79, 83, 86, 91].forEach((m, k) => I.bell(100.5 + k * 0.07, m, 0.7, 0.05)); I.pluck(102, 64, 0.2); I.pluck(102.25, 67, 0.2); I.pluck(102.5, 71, 0.4);
    I.timp(106.4, 0.3); I.brass(106.4, 57, 1.2, 0.04);
    I.sparkle(110.4, 79); I.sparkle(111.2, 84); I.crash(111.4, 0.1);
    I.beat(111.4, 119.4, B, (t, i) => { if (i % 2 === 0) I.kick(t, 0.4); else I.snare(t, 0.12); I.hat(t + B / 2, 0.03); I.bass(t, [50, 50, 55, 55, 57, 57, 50, 50][i % 8] - 12); if (i % 4 === 0) { const c = [[62, 66, 69], [67, 71, 74], [69, 73, 76], [62, 66, 69]][(i / 4) % 4]; c.forEach(m => I.brass(t, m, B * 3.6, 0.025)); } });
    [74, 78, 81, 86].forEach((m, k) => I.lead(111.4 + k * 2, m, 1.6, 0.04)); I.crash(119.4, 0.12); I.brass(119.4, 62, 0.6, 0.05);
  }
  SM.def('moonpie', { mk, score, beat: t => { const on = (t >= 14 && t < 62) || (t >= 76 && t < 100) || (t >= 111.4 && t < 119.4); if (!on) return null; const x = t / 0.5; return { n: Math.floor(x), ph: x - Math.floor(x), amp: 0.6 }; },
    cues: [[9, 'gasp'], [36.6, 'laugh'], [54, 'laugh'], [66, 'hide'], [74.5, 'laugh'], [95, 'hide'], [100.6, 'gasp'], [103, 'laugh'], [112.5, 'cheer'], [117, 'cheer']] });
})();
