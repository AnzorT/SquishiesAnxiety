// Renovation Catalog round 15 — Movie Room: the last screens + playback tech, game style (same wrappers as plus12-14).
// MOV-006 VHS deck + boxy mini projector on a moving box, MOV-010 buzzing beige PC speakers on phone books,
// MOV-062 motorized drop-down screen (housing, tab-tension cables, weight bar), MOV-082 curved MicroLED holo-screen
// (flat centre carries the movie quad, angled holo wings flow with colour, floating emitter, sparkles).
// Sets RenoDraw.PLUS15; catalog edits RD.SET15.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS14 && RD.H12 && RD.H11 && RD.H10 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS15) return;
  const K = X.K, shade = K.shade, slab = K.slab, N = RD.N, H = RD.H10;
  const { cam, FR, an, at, SPL, f1, n4, rep, P2, FONT, shadow, isPlay, yawA } = H;
  const { DEF11, ext, zsort } = RD.H11;
  const { WD } = RD.H12;
  const box3 = (C, o) => H.box3(C, Object.assign({}, o, { mat: null, tpat: null, gl: o.gl ? Math.min(o.gl, 0.2) : 0, olw: 1, olo: 0.95, olc: shade(o.col, 0.32), edge: 0.5 }));
  const cyl3 = (C, a, b, r, col, o) => H.cyl3(C, a, b, r, col, Object.assign({}, o || {}, { mat: o && o.mat === 'gloss' ? 'gloss' : 'plastic', pat: null, olw: 0.8, olo: 0.95 }));
  const DEF15 = DEF11 + '<radialGradient id="p15cn" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#7a6e60"/><stop offset="1" stop-color="#2a241e"/></radialGradient>'
    + '<radialGradient id="p15lens" cx="40%" cy="36%" r="65%"><stop offset="0" stop-color="#6a74c8"/><stop offset="0.5" stop-color="#1d2246"/><stop offset="1" stop-color="#06070c"/></radialGradient>'
    + '<radialGradient id="p15glow" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.95"/><stop offset="0.35" stop-color="#dff0ff" stop-opacity="0.6"/><stop offset="1" stop-color="#bfe0ff" stop-opacity="0"/></radialGradient>'
    + '<linearGradient id="p15scr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fdfdfb"/><stop offset="0.6" stop-color="#f2f2ed"/><stop offset="1" stop-color="#e2e2dc"/></linearGradient>'
    + '<linearGradient id="p15shn" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.6"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
    + '<linearGradient id="p15gls" x1="0" y1="0" x2="0.4" y2="1"><stop offset="0" stop-color="#262a40"/><stop offset="0.5" stop-color="#0d0e18"/><stop offset="1" stop-color="#05060a"/></linearGradient>'
    + '<linearGradient id="p15bm" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#8ff6ff" stop-opacity="0.5"/><stop offset="1" stop-color="#8ff6ff" stop-opacity="0"/></linearGradient>'
    + '<pattern id="p15px" width="2.4" height="2.4" patternUnits="userSpaceOnUse"><path d="M0 0.1H2.4M0.1 0V2.4" stroke="#000000" stroke-opacity="0.35" stroke-width="0.25"/></pattern>'
    + ['#3fd0ff', '#9a5bff', '#ff5fb4', '#5bffc8'].map((c, i) => '<radialGradient id="p15o' + i + '" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="' + c + '" stop-opacity="1"/><stop offset="0.55" stop-color="' + c + '" stop-opacity="0.75"/><stop offset="1" stop-color="' + c + '" stop-opacity="0"/></radialGradient>').join('')
    + '<radialGradient id="p15em" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#3fd0ff" stop-opacity="0.6"/><stop offset="1" stop-color="#3fd0ff" stop-opacity="0"/></radialGradient>'
    + '<filter id="p15b1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.8"/></filter><filter id="p15b2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.4"/></filter>'
    + '<filter id="p15b3" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="6"/></filter><filter id="p15b4" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="12"/></filter>';
  const HAND = `font-family="'Comic Sans MS','Chalkboard SE',cursive" font-weight="700"`;
  const cone = (cx, cy, r, on, ph) => `<g transform="translate(${f1(cx)} ${f1(cy)})"><circle r="${f1(r)}" fill="#2b2622"/><g>${on ? at('scale', '1;1.12;0.95;1', 0.46, ph || 0, SPL(3)) : ''}<circle r="${f1(r * 0.84)}" fill="url(#p15cn)"/><circle r="${f1(r * 0.62)}" fill="none" stroke="#1c1916" stroke-opacity="0.5" stroke-width="${f1(r * 0.08)}"/><circle r="${f1(r * 0.3)}" fill="#1c1916"/><circle cx="${f1(-r * 0.12)}" cy="${f1(-r * 0.12)}" r="${f1(r * 0.1)}" fill="#ffffff" opacity="0.5"/></g></g>`;
  const curve = (C, P, col, w) => { const q = P.map(C.P); return `<path d="M${P2(q[0])}C${P2(q[1])} ${P2(q[2])} ${P2(q[3])}" stroke="${col}" stroke-width="${f1(w * C.k)}" fill="none" stroke-linecap="round"/>`; };

  // ======================= MOV-006 HAND-ME-DOWN VHS PLAYER & BOXY MINI PROJECTOR =======================
  N.vhs15 = S => { const on = isPlay(S), CB = '#c9995a', DK = '#3a3b41', PJ = '#e8dec6', BX = -8, PX = BX - 1, LX = PX + 4, LY = 26.5, LZ = 10;
    const D = { w: 70, d: 34, build: () => [] };
    const boxF = `<rect x="18.4" width="3.2" height="14" fill="#e6cf9c" opacity="0.9"/><path d="M4 9.6l2 -2.4 2 2.4M6 7.3v4.4M31 9.6l2 -2.4 2 2.4M33 7.3v4.4" stroke="#5a3e1c" stroke-width="0.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`
      + `<g transform="rotate(-8 29 4.4)"><rect x="23.2" y="2.4" width="11.6" height="3.8" rx="0.4" fill="none" stroke="#c0392b" stroke-width="0.5"/><text x="29" y="5.25" text-anchor="middle" ${FONT} font-size="2.4" fill="#c0392b">FRAGILE</text></g>`;
    const boxT = `<rect x="18.4" width="3.2" height="28" fill="#e6cf9c" opacity="0.9"/><path d="M0 14H40" stroke="#8a6334" stroke-width="0.45"/>`;
    const boxR = `<path d="M4 4H24" stroke="#8a6334" stroke-width="0.4" stroke-dasharray="1.2 0.8"/><text x="14" y="10" text-anchor="middle" ${HAND} font-size="2.2" fill="#5a3e1c">MOVIES</text>`;
    const disp = on ? `<text x="25.8" y="3.95" text-anchor="middle" ${FONT} font-size="2.4" fill="#7dff9e">▶ 0:12</text>`
      : `<text x="25.8" y="3.95" text-anchor="middle" ${FONT} font-size="2.6" fill="#7dff9e">12:00<animate attributeName="opacity" values="1;0" dur="1.1s" calcMode="discrete" repeatCount="indefinite"/></text>`;
    const deckF = `<rect x="2.4" y="1.2" width="15" height="3.5" rx="0.5" fill="#141418"/><path d="M2.9 2H16.9" stroke="#5a5b63" stroke-width="0.4"/>`
      + `<rect x="20" y="1.1" width="11.6" height="3.7" rx="0.5" fill="#0b1310"/>${disp}`
      + rep(5, i => `<rect x="${f1(2.6 + i * 3)}" y="5.35" width="2.4" height="0.9" rx="0.3" fill="#9a9ca4"/>`).join('') + `<circle cx="18.6" cy="5.8" r="0.55" fill="#d03a30"/>`
      + `<text x="33.4" y="6.35" text-anchor="middle" ${FONT} font-size="1.4" fill="#b9bcc4">VHS</text><circle cx="33.4" cy="2.6" r="0.6" fill="${on ? '#5dff7a' : '#ff5a4a'}"/>`;
    const deckT = rep(8, i => `<rect x="${f1(20 + i * 1.6)}" y="3" width="0.8" height="7" rx="0.4" fill="#000000" fill-opacity="0.35"/>`).join('') + `<path d="M2 21H34" stroke="#55565e" stroke-width="0.4"/>`;
    const pjF = rep(5, i => `<rect x="1.6" y="${f1(1.8 + i * 1.5)}" width="6.4" height="0.75" rx="0.35" fill="#8a826e"/>`).join('') + `<text x="4.8" y="10.2" text-anchor="middle" ${FONT} font-size="1.2" fill="#8a826e">MINI·PRO</text>`;
    const pjT = `<rect x="11.5" y="3" width="4.6" height="2.2" rx="0.6" fill="#b5ab92"/>` + rep(5, i => `<path d="M${f1(12.2 + i * 0.8)} 3.2v1.8" stroke="#8a826e" stroke-width="0.25"/>`).join('')
      + `<g transform="rotate(-10 6 10)"><rect x="1.8" y="8.2" width="8.6" height="3.8" fill="#fff6a8" stroke="#d8c860" stroke-width="0.25"/><text x="6.1" y="10.9" text-anchor="middle" ${HAND} font-size="2.1" fill="#3a2a7a">MOM'S</text></g>`;
    const pjR = rep(4, i => `<circle cx="${f1(4 + i * 2.6)}" cy="5.5" r="0.75" fill="#8a826e"/>`).join('');
    D.fx = ctx => { const C = cam(ctx), L = [];
      let st = shadow(C, BX, 0, 27, 19, 0.85);
      st += box3(C, { c: [BX, 0, 0], w: 40, h: 14, d: 28, r: 1, col: CB, dec: { f: boxF, t: boxT, r: boxR } });
      st += box3(C, { c: [BX, 14, 0], w: 36, h: 7, d: 24, r: 1.2, col: DK, dec: { f: deckF, t: deckT } });
      st += box3(C, { c: [PX, 21, 2], w: 18, h: 11, d: 16, r: 2.2, col: PJ, dec: { f: pjF, t: pjT, r: pjR } });
      st += cyl3(C, [LX, LY, LZ], [LX, LY, LZ + 2.6], 3.5, '#2b2b30') + cyl3(C, [LX, LY, LZ + 2.6], [LX, LY, LZ + 3.1], 3.2, '#4a4b52');
      const G = `<g transform="${FR(C, [LX, LY, LZ + 3.15], [1, 0, 0], [0, -1, 0])}"><circle r="2.7" fill="url(#p15lens)"/><circle r="2.7" fill="none" stroke="#6a6c75" stroke-width="0.35"/><ellipse cx="-0.9" cy="-0.95" rx="0.9" ry="0.55" fill="#ffffff" opacity="0.8" transform="rotate(-35 -0.9 -0.95)"/>`
        + (on ? `<circle r="8" fill="url(#p15glow)">${an('opacity', '0.75;1;0.8;0.95;0.75', 1.6)}</circle><circle r="2.4" fill="#ffffff" opacity="0.9"/>` : '') + '</g>';
      st += G; L.push({ q: [BX, 14, 0], s: st });
      const tape = (y, yaw, lab, col) => box3(C, { c: [24, y, 6], ax: yawA(yaw), w: 19.5, h: 2.6, d: 11, r: 0.4, col: '#1d1d21', dec: { f: `<rect x="2" y="0.45" width="15.5" height="1.7" fill="${col}"/><text x="9.75" y="1.75" text-anchor="middle" ${HAND} font-size="1.3" fill="#222222">${lab}</text>`, t: `<rect x="4" y="2.5" width="11.5" height="6" rx="0.6" fill="#2a2a30"/><circle cx="7" cy="5.5" r="1.4" fill="#111114"/><circle cx="12.5" cy="5.5" r="1.4" fill="#111114"/>` } });
      L.push({ q: [24, 2, 6], s: shadow(C, 24, 6, 13, 8, 0.7) + tape(0, 0.18, 'HOME MOVIES', '#f4f1e6') + tape(2.6, -0.08, 'SQUISH TOONS', '#ffe27a') });
      L.push({ q: [-30, 3, -6], s: curve(C, [[BX - 16, 17, -10], [-36, 8, -10], [-36, 0.3, 4], [-26, 0.3, 14]], '#1a1a1d', 1.5) });
      return { defs: DEF15, front: zsort(C, L), bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-010 BUZZING PC DESKTOP SPEAKERS =======================
  N.pcspk15 = S => { const on = isPlay(S), BG = '#dcd2b9';
    const D = { w: 62, d: 26, build: () => [] };
    const led = `<circle cx="2.8" cy="14.6" r="0.6" fill="#5dff7a">${on ? '' : `<animate attributeName="opacity" values="1;1;0.2;1;0.3;1;1" keyTimes="0;0.56;0.6;0.64;0.68;0.72;1" dur="2.6s" repeatCount="indefinite"/>`}</circle><circle cx="2.8" cy="14.6" r="1.4" fill="#5dff7a" opacity="0.25"/>`;
    const knob = `<circle cx="7.9" cy="14.4" r="1.3" fill="#8a8270"/><circle cx="7.9" cy="14.4" r="1" fill="#c4baa2"/><path d="M7.9 14.4l-0.6 -0.75" stroke="#3a342a" stroke-width="0.4" stroke-linecap="round"/>`;
    const stk = `<g transform="rotate(-7 5.5 15)"><rect x="2.3" y="13.8" width="6.4" height="1.9" fill="#c8ccd4"/><text x="5.5" y="15.2" text-anchor="middle" ${FONT} font-size="1.05" fill="#2a2a7a">MEGA BASS</text><path d="M8.7 13.8h-1.1l1.1 1.1z" fill="#f4f4f4"/></g>`;
    const fr = left => `<rect x="1" y="1" width="9" height="15.2" rx="1.3" fill="${shade(BG, 0.9)}"/><circle cx="5.5" cy="3.8" r="1.6" fill="#2b2622"/><circle cx="5.5" cy="3.8" r="0.9" fill="#6a6052"/><circle cx="5.2" cy="3.5" r="0.3" fill="#ffffff" opacity="0.6"/>`
      + cone(5.5, 9.3, 3.7, on, left ? 0 : 0.23) + (left ? led + knob : stk);
    const top = `<path d="M1 5H10" stroke="#000000" stroke-opacity="0.12" stroke-width="0.4"/>`;
    const side = rep(3, i => `<path d="M2.5 ${f1(4 + i * 1.3)}H7.5" stroke="#000000" stroke-opacity="0.18" stroke-width="0.5" stroke-linecap="round"/>`).join('');
    const book = (C, x, y, yaw, col, lab) => box3(C, { c: [x, y, 0], ax: yawA(yaw), w: 15, h: 2.8, d: 13, r: 0.5, col, dec: { f: `<rect x="0.6" y="0.45" width="13.8" height="1.9" fill="#f3ecd8"/><path d="M0.8 1H14.2M0.8 1.5H14.2M0.8 2H14.2" stroke="#c9bfa4" stroke-width="0.15"/>`, t: lab ? `<text x="7.5" y="11.6" text-anchor="middle" ${FONT} font-size="1.6" fill="#3a2a10">${lab}</text>` : '' } });
    D.fx = ctx => { const C = cam(ctx), L = []; let s = '';
      s += curve(C, [[-12, 9, -5], [-8, 0.3, -13], [8, 0.3, -13], [12, 9, -5]], '#8a8270', 1.6) + curve(C, [[-12, 9, -5], [-8, 0.3, -13], [8, 0.3, -13], [12, 9, -5]], '#d6ccb2', 0.9);
      [-1, 1].forEach(sg => { const x = sg * 14, yaw = -sg * 0.22;
        let g = shadow(C, x, 0, 10, 8.5, 0.8) + book(C, x, 0, yaw * 0.5 + 0.06 * sg, '#f0cd45', 'PHONE BOOK') + book(C, x + sg * 0.5, 2.8, yaw - 0.1 * sg, '#5a9fd6', '')
          + box3(C, { c: [x, 5.6, 0], ax: yawA(yaw), w: 11, h: 17, d: 10, r: 1.8, col: BG, dec: { f: fr(sg < 0), t: top, r: side, l: side } });
        if (sg > 0 && !on) g = `<g>${at('translate', '0 0;0 0;0.35 0;-0.35 0;0.3 -0.1;0 0;0 0', 2.6, 0, ' keyTimes="0;0.56;0.6;0.64;0.68;0.72;1"')}${g}</g>`;
        L.push({ q: [x, 8, 0], s: g }); });
      s += zsort(C, L);
      const pe = C.p(-24, 0.3, 13), pa = C.p(-21, 0.3, 16.5);
      s += curve(C, [[-19, 7, -2], [-26, 2, -3], [-30, 0.3, 8], [-24, 0.3, 13]], '#8a8270', 1.4) + curve(C, [[-19, 7, -2], [-26, 2, -3], [-30, 0.3, 8], [-24, 0.3, 13]], '#d6ccb2', 0.75)
        + `<path d="M${P2(pe)}L${P2(pa)}" stroke="#5a5550" stroke-width="${f1(1.8 * C.k)}" stroke-linecap="round"/><path d="M${P2(pe)}L${P2(pa)}" stroke="#d9dce2" stroke-width="${f1(0.9 * C.k)}" stroke-linecap="round"/>`;
      if (!on) { const b = C.p(21, 21, 2), k = C.k, z = `l${f1(0.9 * k)} ${f1(-1.1 * k)} ${f1(0.9 * k)} ${f1(1.1 * k)} ${f1(0.9 * k)} ${f1(-1.1 * k)} ${f1(0.9 * k)} ${f1(1.1 * k)}`;
        s += `<g fill="none" stroke="#5a4a2a" stroke-width="${f1(0.5 * k)}" stroke-linecap="round" stroke-linejoin="round" opacity="0"><animate attributeName="opacity" values="0;0;1;1;0;0" keyTimes="0;0.55;0.58;0.72;0.76;1" dur="2.6s" repeatCount="indefinite"/>`
          + `<path d="M${f1(b[0])} ${f1(b[1] - 2 * k)}${z}" transform="rotate(-25 ${f1(b[0])} ${f1(b[1])})"/><path d="M${f1(b[0] + 1 * k)} ${f1(b[1] + 1.2 * k)}${z}"/><path d="M${f1(b[0])} ${f1(b[1] + 4.6 * k)}${z}" transform="rotate(22 ${f1(b[0])} ${f1(b[1] + 4.6 * k)})"/>`
          + `<text x="${f1(b[0] + 5.4 * k)}" y="${f1(b[1] - 2.2 * k)}" ${FONT} font-size="${f1(2.2 * k)}" fill="#5a4a2a" stroke="none">bzz</text></g>`;
        ext(C, [[30, 26, 2]]); }
      return { defs: DEF15, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-062 150-INCH MOTORIZED DROP-DOWN LASER PROJECTION SCREEN =======================
  N.drop15 = S => { const SW = 252, SH = 141.75, BD = 4, DR = 12, FW = SW + 2 * BD, FH = BD + SH + DR, Y0 = 4, YH = Y0 + FH, HH = 9, HW = FW + 14, ZS = 6;
    const D = { w: HW + 12, d: 12, mount: 'wall', elev: 22, act: 'watch', use: { x: 0, z: 180 } };
    D.build = () => [slab(0, Y0 + BD, ZS + 0.4, SW, SH, 0.2, '#000000', { scr: 1, r: 0.3, emit: 1, noOut: 1, op: 0 })];
    const fab = `<rect width="${FW}" height="${FH}" fill="#16171b"/><rect x="${BD}" y="${DR}" width="${SW}" height="${f1(SH)}" fill="url(#p15scr)"/>`
      + `<rect x="${BD}" y="${DR}" width="${SW}" height="${f1(SH)}" fill="none" stroke="#000000" stroke-opacity="0.2" stroke-width="0.6"/>`
      + `<defs><clipPath id="dp15c"><rect x="${BD}" y="${DR}" width="${SW}" height="${f1(SH)}"/></clipPath></defs><g clip-path="url(#dp15c)"><rect x="-60" y="${DR}" width="40" height="${f1(SH)}" fill="url(#p15shn)" opacity="0.45" transform="skewX(-14)">${an('x', `-60;${FW + 80}`, 9)}</rect></g>`
      + `<path d="M${BD} ${DR + 0.4}H${BD + SW}" stroke="#ffffff" stroke-opacity="0.6" stroke-width="0.4"/>`;
    const hsF = `<rect x="6" y="${HH - 1.4}" width="${HW - 12}" height="1" rx="0.5" fill="#08080a"/><path d="M3 0.6H${HW - 3}" stroke="#ffffff" stroke-opacity="0.2" stroke-width="0.4"/><text x="${HW - 22}" y="5.4" text-anchor="middle" ${FONT} font-size="2.4" letter-spacing="0.8" fill="#8a8e98">LUMA 150</text>`;
    const capF = `<circle cx="2.5" cy="3" r="0.7" fill="#4ab8ff">${an('opacity', '1;0.35;1', 2.4)}</circle><circle cx="2.5" cy="3" r="1.6" fill="#4ab8ff" opacity="0.25"/><rect x="1.4" y="5.6" width="2.2" height="2.2" rx="0.4" fill="#3a1414"/>`;
    D.fx = ctx => { const C = cam(ctx); let s = '';
      s += WD(C, -FW / 2 + 1, YH - 3, 0.1, `<rect width="${FW + 4}" height="${FH + 4}" rx="3" fill="#000000" opacity="0.1"/><rect x="2" y="1.5" width="${FW}" height="${FH + 1}" rx="2" fill="#000000" opacity="0.14"/>`, FW, FH);
      [-1, 1].forEach(sg => s += box3(C, { c: [sg * (HW / 2 - 24), YH - 2, 0.6], w: 6, h: 13, d: 1.2, r: 0.3, col: '#3a3c42' }));
      [-1, 1].forEach(sg => s += cyl3(C, [sg * (FW / 2 + 1.4), Y0, ZS + 0.4], [sg * (FW / 2 + 1.4), YH, ZS + 0.4], 0.35, '#4a4c52'));
      s += box3(C, { c: [0, Y0, ZS], w: FW, h: FH, d: 0.6, r: 0.1, col: '#eeeee8', dec: { f: fab } });
      s += cyl3(C, [-FW / 2 - 2, Y0, ZS + 0.4], [FW / 2 + 2, Y0, ZS + 0.4], 2, '#1d1e22', { mat: 'gloss' });
      s += box3(C, { c: [0, YH, 5], w: HW, h: HH, d: 10, r: 2, col: '#2a2c31', dec: { f: hsF } });
      [-1, 1].forEach(sg => s += box3(C, { c: [sg * (HW / 2 + 2.4), YH - 0.5, 5], w: 5, h: 10, d: 11, r: 1.4, col: '#1c1d21', dec: sg > 0 ? { f: capF } : null }));
      return { defs: DEF15, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-082 CURVED WALL-TO-WALL 16K MicroLED HOLO-SCREEN =======================
  N.holo15 = S => { const SW = 300, SH = 168.75, BZ = 1.6, PW = SW + 2 * BZ, PH = SH + 2 * BZ, WW = 84, A = 0.8, NS = 3, SL = WW / NS, Y0 = 18, ZC = 10;
    const D = { w: PW + 2 * WW * 0.8 + 24, d: 14, mount: 'wall', elev: 16, act: 'watch', use: { x: 0, z: 200 } };
    D.build = () => [slab(0, Y0 + BZ, ZC + 1.55, SW, SH, 0.2, '#000000', { scr: 1, r: 0.3, emit: 1, noOut: 1, op: 0 })];
    const top = (w, d) => `<path d="M0 0.5H${f1(w)}" stroke="#8ff6ff" stroke-width="0.7" stroke-dasharray="7 11" stroke-linecap="round">${an('stroke-dashoffset', '0;-36', 3)}</path>`;
    const panF = `<rect width="${f1(PW)}" height="${f1(PH)}" fill="#0b0c12"/><rect x="${BZ}" y="${BZ}" width="${SW}" height="${f1(SH)}" fill="url(#p15gls)"/>`
      + `<path d="M${f1(PW * 0.52)} ${BZ}H${f1(PW * 0.7)}L${f1(PW * 0.5)} ${f1(PH - BZ)}H${f1(PW * 0.32)}Z" fill="#ffffff" opacity="0.045"/>`
      + `<rect x="0.3" y="0.3" width="${f1(PW - 0.6)}" height="${f1(PH - 0.6)}" fill="none" stroke="#8ff6ff" stroke-opacity="0.5" stroke-width="0.5">${an('stroke-opacity', '0.3;0.7;0.3', 3.6)}</rect>`;
    const BLOB = [['#3fd0ff', 9], ['#9a5bff', 11], ['#ff5fb4', 8], ['#5bffc8', 12.5]];
    // wing content is one strip WW wide (u 0 = outer end on the left wing, inner end on the right); each curved segment shows its slice
    const wingC = (right, uid) => { const W = WW, Hh = PH, fd = uid + 'f';
      return `<defs><linearGradient id="${fd}" x1="${right ? 1 : 0}" y1="0" x2="${right ? 0 : 1}" y2="0"><stop offset="0" stop-color="#05060c" stop-opacity="0.9"/><stop offset="1" stop-color="#05060c" stop-opacity="0"/></linearGradient></defs>`
        + `<rect width="${W}" height="${f1(Hh)}" fill="#0a0c1c"/><g>`
        + BLOB.map(([c, T], i) => { const y0 = Hh * (0.2 + 0.22 * i), x0 = W * (right ? 0.3 : 0.7); return `<ellipse cx="${f1(x0)}" cy="${f1(y0)}" rx="36" ry="46" fill="url(#p15o${i})">${an('cy', `${f1(y0)};${f1((y0 + Hh * 0.45) % Hh)};${f1(y0)}`, T, -i * 1.7, SPL(2))}${an('cx', `${f1(x0)};${f1(W - x0)};${f1(x0)}`, T * 1.3, -i, SPL(2))}</ellipse>`; }).join('')
        + `</g><rect width="${W}" height="${f1(Hh)}" fill="url(#p15px)"/><rect width="${W}" height="${f1(Hh)}" fill="url(#${fd})"/>`
        + `<rect x="-24" width="16" height="${f1(Hh)}" fill="url(#p15shn)" opacity="0.35">${an('x', `-24;${W + 24}`, 5.5, right ? -2.75 : 0)}</rect>`; };
    const seg = (cnt, off, cl) => `<defs><clipPath id="${cl}"><rect width="${f1(SL)}" height="${f1(PH)}"/></clipPath></defs><g clip-path="url(#${cl})"><g transform="translate(${f1(-off)} 0)">${cnt}</g></g><rect x="0.3" y="0.3" width="${f1(SL - 0.6)}" height="${f1(PH - 0.6)}" fill="none" stroke="#8ff6ff" stroke-opacity="0.3" stroke-width="0.4"/>`;
    D.fx = ctx => { const C = cam(ctx); let s = '';
      const GC = '#5b6cff;#b04dff;#ff5a8a;#33c9d6;#5b6cff', gs = (o, op) => `<stop offset="${o}" stop-color="#5b6cff" stop-opacity="${op}">${an('stop-color', GC, 16)}</stop>`;
      s += WD(C, -PW / 2 - 70, Y0 + PH + 34, 0.05, `<defs><radialGradient id="hl15g" cx="50%" cy="50%" r="50%">${gs(0, 0.8)}${gs(0.66, 0.6)}${gs(1, 0)}</radialGradient></defs><rect width="${f1(PW + 140)}" height="${f1(PH + 64)}" fill="url(#hl15g)"/>`, PW + 140, PH + 64);
      s += WD(C, -PW / 2 + 1, Y0 + PH - 2, 0.1, `<rect width="${f1(PW + 4)}" height="${f1(PH + 4)}" rx="3" fill="#000000" opacity="0.12"/><rect x="2" y="1.5" width="${f1(PW)}" height="${f1(PH + 1)}" rx="2" fill="#000000" opacity="0.16"/>`);
      s += box3(C, { c: [0, Y0, ZC], w: PW, h: PH, d: 3, r: 0.4, col: '#15161c', dec: { f: panF, t: top(PW) } });
      [-1, 1].forEach(sg => { const cnt = wingC(sg > 0, C.u('hw')); let px = sg * PW / 2, pz = ZC;
        for (let i = 0; i < NS; i++) { const a = A * (i + 1) / NS, dx = sg * Math.cos(a), dz = Math.sin(a), c = [px + dx * SL / 2, Y0, pz + dz * SL / 2], off = sg < 0 ? WW - (i + 1) * SL : i * SL;
          s += box3(C, { c, ax: yawA(sg < 0 ? a : -a), w: SL + 0.4, h: PH, d: 3, r: 0.2, col: '#15161c', dec: { f: seg(cnt, off, C.u('hs')), t: top(SL) } }); px += dx * SL; pz += dz * SL; } });
      const k = C.k, ty = Y0 + PH + 1;
      s += rep(12, i => { const x = -PW / 2 + PW * (i + 0.5) / 12 + (i % 2 ? 6 : -4), p = C.p(x, ty, ZC + 1.5), d = 3 + (i * 7) % 5 * 0.6;
        return `<circle r="${f1(0.8 * k)}" fill="#dffcff" opacity="0"><animate attributeName="opacity" values="0;0.95;0" dur="${n4(d)}s" begin="${n4(-i * 0.37)}s" repeatCount="indefinite"/><animateMotion dur="${n4(d)}s" begin="${n4(-i * 0.37)}s" repeatCount="indefinite" path="M${P2(p)}l${f1((i % 3 - 1) * 2 * k)} ${f1(-18 * k)}"/></circle>`; }).join('');
      ext(C, [[0, ty + 20, ZC]]);
      const ey = Y0 - 15, b0 = C.p(-80, ey + 4.4, ZC), b1 = C.p(80, ey + 4.4, ZC), t0 = C.p(-SW / 2, Y0, ZC + 1.5), t1 = C.p(SW / 2, Y0, ZC + 1.5);
      s += `<path d="M${P2(b0)}L${P2(t0)}L${P2(t1)}L${P2(b1)}Z" fill="url(#p15bm)">${an('opacity', '0.5;0.9;0.6;0.85;0.5', 2.8)}</path>`;
      const emF = `<rect x="6" y="1.6" width="148" height="1.2" rx="0.6" fill="#8ff6ff">${an('opacity', '0.55;1;0.55', 2.2)}</rect><text x="80" y="4.1" text-anchor="middle" ${FONT} font-size="1.1" letter-spacing="0.8" fill="#6a7088">16K MicroLED</text>`;
      s += `<g>${at('translate', `0 0;0 ${f1(-1.2 * k)};0 0`, 3.4, 0, SPL(2))}${WD(C, -60, ey - 6, 0.05, `<ellipse cx="60" cy="3" rx="70" ry="6" fill="url(#p15em)"/>`)}${box3(C, { c: [0, ey, ZC], w: 160, h: 4.4, d: 7, r: 2, col: '#1c1e28', dec: { f: emF } })}</g>`;
      return { defs: DEF15, front: s, bb: C.bb(4) }; };
    return D; };

  // ---------- catalog edits ----------
  RD.SET15 = {
    'MOV-006': { spec: 'vhs15', note: 'A chunky old VHS deck with its clock stuck blinking 12:00, a boxy beige mini projector on top with a hand-written "MOM\'S" sticker, all stacked on a FRAGILE moving box. Two labelled tapes lie beside it and the cable trails off to the wall.' },
    'MOV-010': { spec: 'pcspk15', live: 'Buzzing', note: 'Two yellowed beige PC speakers propped up on old phone books, toed in toward the sofa: little tweeters, a volume knob with a green power light and a peeling MEGA BASS sticker. Every few seconds the right one buzzes and shakes. Tap it to play music: the cones pump.' },
    'MOV-062': { spec: 'drop15', live: 'Sheen sweeps', note: 'A 150-inch matte white screen hanging from a black motor housing with a blue status light, black masking borders, tab-tension side cables and a weighted bottom bar that keeps it perfectly flat.' },
    'MOV-082': { spec: 'holo15', live: 'Holo wings', note: 'A curved wall-to-wall MicroLED screen: the black glass centre shows the movie while the two wings curve toward you, flowing with holographic colour. Light sparkles rise off the top edge and a floating 16K emitter beams up from below, with a colour glow on the wall behind.' },
  };
  const edit14 = RD.edit;
  RD.edit = rows => edit14(rows).map(r => RD.SET15[r.id] ? Object.assign({}, r, RD.SET15[r.id]) : r);
  RD.H15 = { DEF15, cone, curve, box3, cyl3 };
  RD.PLUS15 = 1;
})();
