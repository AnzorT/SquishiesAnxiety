/* Squish Squad plush animation engine: moods, part rigs, faces, props. Used by Creature Plush.dc.html */
(function () {
  const TAU = Math.PI * 2, NS = 'http://www.w3.org/2000/svg';
  const num = (e, a) => parseFloat(e.getAttribute(a) || '0');
  const cap = k => k[0].toUpperCase() + k.slice(1);
  const ease = { back: x => { const c = 1.9; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); }, out: x => 1 - Math.pow(1 - x, 3) };
  const MOODS = ['idle', 'spin', 'reveal', 'eat', 'full', 'dance', 'unlock', 'happy', 'sad', 'clean', 'dirty', 'bath', 'tv', 'sleep', 'groove', 'wave', 'cheer'];
  const ALIAS = { ready: 'idle', jump: 'happy', celebrate: 'unlock', wobble: 'dance' };
  const FACE = { idle: null, eat: 'eating', full: 'content', dance: 'happy', unlock: 'happy', spin: 'happy', reveal: 'party', happy: 'party', sad: 'sad', clean: 'content', dirty: 'smelly', bath: 'content', tv: null, sleep: 'sleep', groove: 'party', wave: 'happy', cheer: 'party' };
  const MOVEKEY = { idle: 'idle', eat: 'eat', dance: 'dance', unlock: 'happy', happy: 'happy', sleep: 'sleep' };
  const FOODS = { nimbo: 'drop', mittens: 'fish', mallow: 'cocoa', bao: 'dumpling', dunkie: 'sprinkle', frybo: 'ketchup', pip: 'shrimp', bunbun: 'pickle', jelli: 'plankton', pina: 'coconut', finn: 'fish', sealy: 'fish', biscuit: 'bone', hana: 'carrot', choco: 'strawberry', prickle: 'apple', lumi: 'mooncake', kiko: 'honey', bubbly: 'soap', twinkle: 'starcandy', zappi: 'battery' };
  const FOOD = {
    drop: '<path d="M0 -7 Q6 1 0 7 Q-6 1 0 -7Z" fill="#8fd3ff"/><ellipse cx="-1.5" cy="1" rx="1.2" ry="2" fill="#fff" opacity=".8"/>',
    fish: '<path d="M-7 0 Q-2 -5 4 0 Q-2 5 -7 0Z" fill="#ff9a5a"/><path d="M4 0 L8 -4 L8 4Z" fill="#ff9a5a"/><circle cx="-4" cy="-1" r="0.9" fill="#2a1a30"/>',
    cocoa: '<rect x="-5" y="-4" width="9" height="9" rx="2" fill="#f2a6c6"/><path d="M4 -1 q3 0 3 2.5 q0 2.5 -3 2.5" stroke="#f2a6c6" stroke-width="1.6" fill="none"/><ellipse cx="-0.5" cy="-4" rx="4.5" ry="1.4" fill="#7a4a2a"/><circle cx="-2" cy="-5" r="1.2" fill="#fff"/><circle cx="1" cy="-5.4" r="1.1" fill="#fff"/>',
    dumpling: '<path d="M-7 3 Q-6 -6 0 -6 Q6 -6 7 3Z" fill="#fff6e8"/><path d="M-3 -5 Q0 -2 3 -5" stroke="#e2cfb6" stroke-width="0.8" fill="none"/>',
    sprinkle: '<rect x="-5" y="-5" width="10" height="11" rx="3" fill="#fff" stroke="#f0d6e2" stroke-width="0.8"/><rect x="-3" y="-2" width="2.6" height="1" fill="#ff5c8a" transform="rotate(30 -2 -1.5)"/><rect x="0.5" y="0" width="2.6" height="1" fill="#7cc8ff"/><rect x="-2.5" y="2.5" width="2.6" height="1" fill="#ffd84a" transform="rotate(-25 -1 3)"/>',
    ketchup: '<rect x="-3.5" y="-3" width="7" height="10" rx="2" fill="#f2665a"/><rect x="-1.5" y="-7" width="3" height="4" rx="1" fill="#fff"/>',
    shrimp: '<path d="M-5 -3 Q2 -7 6 0 Q4 6 -2 5 Q2 2 0 -1 Q-3 -1 -5 -3Z" fill="#ff9f80"/>',
    pickle: '<ellipse rx="3.6" ry="7" fill="#8bc34a" transform="rotate(25)"/><circle cx="-1" cy="-2" r="0.6" fill="#5f8a2a"/><circle cx="1" cy="2" r="0.6" fill="#5f8a2a"/>',
    plankton: '<circle r="5.5" fill="#bfefff" opacity=".85"/><circle cx="-2" cy="-1" r="1.2" fill="#7fd06f"/><circle cx="2" cy="1.5" r="1" fill="#ffd84a"/>',
    coconut: '<circle r="6" fill="#8a5a3a"/><circle r="4.2" fill="#fff8ee"/><path d="M1 -6 L4 -10" stroke="#ff7fb0" stroke-width="1.2"/>',
    bone: '<rect x="-5" y="-1.6" width="10" height="3.2" rx="1.6" fill="#f3dcb6"/><circle cx="-5.5" cy="-1.8" r="2" fill="#f3dcb6"/><circle cx="-5.5" cy="1.8" r="2" fill="#f3dcb6"/><circle cx="5.5" cy="-1.8" r="2" fill="#f3dcb6"/><circle cx="5.5" cy="1.8" r="2" fill="#f3dcb6"/>',
    carrot: '<path d="M-2.4 -4 L2.4 -4 L0 8Z" fill="#ff9a3c"/><path d="M0 -4 L-3 -9 M0 -4 L0 -10 M0 -4 L3 -9" stroke="#7fd06f" stroke-width="1.4" stroke-linecap="round"/>',
    strawberry: '<path d="M-5 -2 Q0 -5 5 -2 Q4 6 0 8 Q-4 6 -5 -2Z" fill="#ff5c7a"/><path d="M-3 -3 L0 -6 L3 -3Z" fill="#7fd06f"/><circle cx="-1.5" cy="1" r="0.5" fill="#fff3b0"/><circle cx="1.5" cy="3" r="0.5" fill="#fff3b0"/>',
    apple: '<circle r="5.5" fill="#ff6f6f"/><path d="M0 -5 L1 -8" stroke="#7a4a2a" stroke-width="1.2"/><ellipse cx="3" cy="-7" rx="2" ry="1" fill="#7fd06f"/>',
    mooncake: '<circle r="6" fill="#e9a85e"/><circle r="4" fill="none" stroke="#c98a40" stroke-width="0.8"/><path d="M-2 0 H2 M0 -2 V2" stroke="#c98a40" stroke-width="0.8"/>',
    honey: '<rect x="-5" y="-3" width="10" height="9" rx="3" fill="#ffc23a"/><rect x="-5.5" y="-5" width="11" height="3" rx="1.2" fill="#c98a40"/><path d="M-3 -2 q0 3 1 4" stroke="#fff3b0" stroke-width="1" fill="none"/>',
    soap: '<circle r="5.5" fill="rgba(210,244,255,0.5)" stroke="#fff" stroke-width="0.8"/><path d="M-3 -1 a3 3 0 0 1 2 -3" stroke="#fff" stroke-width="1" fill="none"/>',
    starcandy: '<path d="M0 -6 L1.8 -1.8 L6 -1.5 L2.8 1.3 L3.8 5.6 L0 3.3 L-3.8 5.6 L-2.8 1.3 L-6 -1.5 L-1.8 -1.8Z" fill="#ffd84a" stroke="#fff" stroke-width="0.6"/>',
    battery: '<rect x="-4" y="-6" width="8" height="12" rx="2" fill="#7cc8ff"/><rect x="-1.5" y="-7.5" width="3" height="1.6" fill="#555"/><path d="M1 -3 L-1.5 0.5 H1 L-1 4" stroke="#fff" stroke-width="1.2" fill="none"/>',
  };
  const TV = ['#7cc8ff', '#ff9fcb', '#ffe14a', '#9be38a'];

  function scan(k, root) {
    const eyes = [];
    root.querySelectorAll('[fill^="url(#ey"]').forEach(e => { eyes.push(e); let n = e.nextElementSibling; for (let i = 0; i < 2 && n; i++, n = n.nextElementSibling) if ((n.getAttribute('fill') || '') === '#fff') eyes.push(n); });
    eyes.forEach(e => { e.style.transformBox = 'fill-box'; e.style.transformOrigin = 'center'; });
    const mouth = Array.from(root.querySelectorAll('path[stroke="#6a3a3a"]'));
    const used = new Set([...eyes, ...mouth]);
    const arms = [], feet = [], circles = Array.from(root.querySelectorAll('circle'));
    root.querySelectorAll('ellipse').forEach(e => {
      const fill = e.getAttribute('fill') || '', tr = e.getAttribute('transform') || '';
      const cx = num(e, 'cx'), cy = num(e, 'cy'), rx = num(e, 'rx'), ry = num(e, 'ry');
      if (/^#ff8fa3|^#ff9a3c/.test(fill)) { used.add(e); return; }
      if (/rotate/.test(tr) && fill.indexOf('#fff') !== 0 && !e.getAttribute('opacity')) {
        const r0 = parseFloat((tr.match(/rotate\(([-\d.]+)/) || [0, 0])[1]) * Math.PI / 180;
        const sx = cx + Math.sin(r0) * ry, sy = cy - Math.cos(r0) * ry, bx = cx - Math.sin(r0) * ry, by = cy + Math.cos(r0) * ry;
        const hands = circles.filter(c => Math.hypot(num(c, 'cx') - bx, num(c, 'cy') - by) < 7);
        arms.push({ els: [e, ...hands], base: [tr, ...hands.map(h => h.getAttribute('transform') || '')], side: cx < 50 ? -1 : 1, sx, sy, bx, by }); used.add(e); hands.forEach(h => used.add(h));
      } else if (!tr && cy >= 84 && cy <= 93 && rx >= 4 && fill !== '#3a2340') { feet.push({ el: e, side: cx < 50 ? -1 : 1 }); used.add(e); }
    });
    const c = (window.CREATURES_V2 || []).find(x => x.name.toLowerCase() === k) || null;
    const eyeY0 = c ? c.eyes[0].y : 50;
    let bb = { x: 14, y: 14, width: 72, height: 78 }; try { const b = root.getBBox(); if (b.width > 10) bb = b; } catch (e) {}
    const eyeY = eyeY0; const area = bb.width * bb.height;
    const parts = [];
    root.querySelectorAll('path, ellipse, circle, rect, polygon').forEach(e => {
      if (used.has(e) || e.closest('defs,clipPath,mask')) return;
      if ((e.getAttribute('fill') || '').indexOf('#fff') === 0 && e.getAttribute('opacity')) return;
      let b; try { b = e.getBBox(); } catch (x) { return; } if (!b || b.width * b.height < 3) return;
      const ccx = b.x + b.width / 2, ccy = b.y + b.height / 2, a = b.width * b.height;
      if (a > area * 0.22) return;
      const strokeOnly = (e.getAttribute('fill') === 'none' || e.closest('g[fill="none"]')) && (e.getAttribute('stroke') || (e.closest('g[stroke]') || { getAttribute: () => null }).getAttribute('stroke'));
      if (k === 'bao' && strokeOnly && ccy < eyeY - 20) { parts.push({ el: e, kind: 'steam', side: ccx < 50 ? -1 : 1, px: ccx, py: b.y, base: e.getAttribute('transform') || '' }); return; }
      if (k === 'jelli' && strokeOnly && ccy > eyeY + 5) { parts.push({ el: e, kind: 'tent', side: ccx < 50 ? -1 : 1, px: ccx, py: b.y, base: e.getAttribute('transform') || '' }); return; }
      if (ccy < eyeY - 12) parts.push({ el: e, kind: 'top', side: ccx < 50 ? -1 : 1, px: ccx, py: b.y + b.height, a, base: e.getAttribute('transform') || '' });
      else if (ccy > eyeY - 4 && (ccx < bb.x + bb.width * 0.2 || ccx > bb.x + bb.width * 0.8) && a < area * 0.12) { const s = ccx < 50 ? -1 : 1; if (k === 'pip') parts.push({ el: e, kind: 'wing', side: s, px: s < 0 ? b.x + b.width : b.x, py: b.y + 2, base: e.getAttribute('transform') || '' }); else parts.push({ el: e, kind: 'tail', side: s, px: s < 0 ? b.x + b.width : b.x, py: ccy, base: e.getAttribute('transform') || '' }); }
    });
    [-1, 1].forEach(sd => { const tops = parts.filter(q => q.kind === 'top' && q.side === sd); if (tops.length < 2) return; const big = tops.reduce((m, q) => q.a > m.a ? q : m); tops.forEach(q => { if (q !== big && Math.hypot(q.px - big.px, q.py - big.py) < 26) { q.px = big.px; q.py = big.py; } }); });
    return { eyes, mouth, arms, feet, parts, c, bb, hash: k.split('').reduce((a, ch) => a + ch.charCodeAt(0), 0), food: FOOD[FOODS[k]] || FOOD.apple };
  }

  function extras(P, mood, F, BS) {
    const c = P.c, bb = P.bb; if (!c) return '';
    const head = c.head, m = c.mouth; let h = '';
    if ((mood === 'eat' || mood === 'full') && F) {
      h += '<path data-strand pathLength="1" d="M0 0" stroke="#ffe08a" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-dasharray="0 2"/>';
      h += '<g data-food>' + F.art + '</g>';
      h += [0, 1, 2, 3].map(i => '<circle data-crumb="' + i + '" r="' + (0.8 + (i % 2) * 0.4) + '" fill="' + (F.crumb || '#e9b26a') + '" opacity="0"/>').join('');
      h += [0, 1].map(i => '<path data-steam="' + i + '" d="M0 0 q-2 -3 0 -6 q2 -3 0 -6" stroke="#fff" stroke-width="1.3" fill="none" stroke-linecap="round" opacity="0"/>').join('');
      h += [0, 1].map(i => '<ellipse data-juice="' + i + '" rx="0.9" ry="1.3" fill="#ffe14a" opacity="0"/>').join('');
      h += '<circle data-burp r="2" fill="#fff" stroke="#e8d6f0" stroke-width="0.6" opacity="0"/>';
      h += [0, 1].map(i => '<path data-h="' + i + '" d="M0 2.6c-1.6-1.4-4-2.6-4-4.6a2 2 0 0 1 4-0.6a2 2 0 0 1 4 0.6c0 2-2.4 3.2-4 4.6z" fill="#ff6fae" stroke="#fff" stroke-width="0.6" opacity="0"/>').join('');
    }
    if (mood === 'sad') c.eyes.forEach((e, i) => { const s = i ? 1 : -1; h += '<path data-tear d="M' + e.x + ' ' + (e.y + e.r) + ' Q' + (e.x + s * 3) + ' ' + (e.y + e.r + 10) + ' ' + (e.x + s) + ' ' + (e.y + e.r + 22) + '" stroke="#8fd3ff" stroke-width="2.4" stroke-linecap="round" fill="none" opacity="0.85" stroke-dasharray="4 3"/><circle data-drop="' + i + '" r="1.4" fill="#8fd3ff"/>'; });
    if (mood === 'dirty') { [[0.25, 0.72, 5], [0.72, 0.56, 4], [0.6, 0.86, 4.5], [0.34, 0.4, 3.2], [0.8, 0.8, 2.6]].forEach(([fx, fy, r]) => { h += '<ellipse cx="' + (bb.x + bb.width * fx).toFixed(1) + '" cy="' + (bb.y + bb.height * fy).toFixed(1) + '" rx="' + r + '" ry="' + (r * 0.7).toFixed(1) + '" fill="#6e6a75" opacity="0.32"/>'; }); [38, 50, 62].forEach((x, i) => { h += '<path data-stink="' + i + '" d="M0 0 q-3 -3 0 -6 q3 -3 0 -6 q-3 -3 0 -6" transform="translate(' + x + ' ' + head + ')" stroke="#a3b38c" stroke-width="1.6" stroke-linecap="round" fill="none"/>'; }); }
    if (mood === 'bath') {
      const st = BS || 'tub', ex = c.eyes, ecx = ex.reduce((a, e) => a + e.x, 0) / ex.length, ecy = ex.reduce((a, e) => a + e.y, 0) / ex.length, er = ex[0].r;
      const bub = n => Array.from({ length: n }, (_, i) => '<circle data-bub="' + i + '" r="2" fill="rgba(210,244,255,0.35)" stroke="#fff" stroke-width="0.6"/>').join('');
      const steam = n => Array.from({ length: n }, (_, i) => '<path data-bst="' + i + '" d="M0 0 q-2.5 -3.5 0 -7 q2.5 -3.5 0 -7" stroke="#fff" stroke-width="1.6" fill="none" stroke-linecap="round" opacity="0"/>').join('');
      const crownH = big => [36, 42, 48, 54, 60, 64, 45, 55].concat(big ? [32, 68, 50] : []).map((x, i) => '<circle cx="' + x + '" cy="' + (head - (i > 5 ? 5 : 1) + (i % 2) - (i > 7 ? 7 : 0)).toFixed(1) + '" r="' + ((i > 5 ? 4.5 : 3.8) * (big ? 1.25 : 1)).toFixed(1) + '" fill="#fff" stroke="#d6f2fc" stroke-width="0.6"/>').join('');
      const towel = c2 => '<ellipse cx="50" cy="' + (head + 1) + '" rx="17" ry="7" fill="' + c2 + '" stroke="#5b3a29" stroke-width="0.9"/><circle cx="62" cy="' + (head - 4) + '" r="4.5" fill="' + c2 + '" stroke="#5b3a29" stroke-width="0.9"/>';
      if (st === 'tub') h += crownH(false) + bub(5);
      if (st === 'bubble') { let f = ''; const fx = ecx, fy = ex[0].y; for (let yy = bb.y + 4; yy <= bb.y + bb.height + 2; yy += 7) for (let xx = bb.x + 2; xx <= bb.x + bb.width; xx += 7.5) { const jx = xx + ((yy * 7) % 4) - 2, jy = yy + ((xx * 3) % 3) - 1; if (Math.pow((jx - fx) / 19, 2) + Math.pow((jy - fy - 2) / 11, 2) < 1) continue; f += '<circle cx="' + jx.toFixed(1) + '" cy="' + jy.toFixed(1) + '" r="' + (4.2 + ((xx + yy) % 3) * 0.7).toFixed(1) + '" fill="#fff" stroke="#d6f2fc" stroke-width="0.6"/>'; } h += f + crownH(true) + bub(9); }
      if (st === 'hottub') h += steam(3) + bub(6);
      if (st === 'spa') h += '<ellipse cx="' + ecx.toFixed(1) + '" cy="' + (ecy + 2).toFixed(1) + '" rx="' + (Math.abs(ex[ex.length - 1].x - ex[0].x) / 2 + er + 7).toFixed(1) + '" ry="' + (er + 8).toFixed(1) + '" fill="#a8d98a" opacity="0.75"/>' + ex.map(e => '<circle cx="' + e.x + '" cy="' + e.y + '" r="' + (er + 1.6).toFixed(1) + '" fill="#d4f5b8" stroke="#5fb85a" stroke-width="1.3"/><circle cx="' + e.x + '" cy="' + e.y + '" r="' + (er * 0.55).toFixed(1) + '" fill="none" stroke="#a8d98a" stroke-width="0.8" stroke-dasharray="1 1.2"/>').join('') + towel('#ff9db0') + steam(2);
      if (st === 'duck') h += crownH(false) + [1, 2, 3].map(n => '<g data-duck2="' + n + '"><ellipse cx="0" cy="3" rx="5" ry="3.4" fill="' + ['#ffd23a', '#ff9db0', '#7cc8ff'][n - 1] + '" stroke="#5b3a29" stroke-width="0.8"/><circle cx="2.2" cy="-1.6" r="2.9" fill="' + ['#ffd23a', '#ff9db0', '#7cc8ff'][n - 1] + '" stroke="#5b3a29" stroke-width="0.8"/><path d="M4.8 -1.6 l2.6 0.7 l-2.6 0.7z" fill="#ff9a3c"/><circle cx="2.6" cy="-2.3" r="0.6" fill="#2a1a30"/></g>').join('') + '<g data-duck><ellipse cx="0" cy="3" rx="6" ry="4" fill="#ffd23a" stroke="#5b3a29" stroke-width="0.8"/><circle cx="2.5" cy="-2" r="3.4" fill="#ffd23a" stroke="#5b3a29" stroke-width="0.8"/><path d="M5.6 -2 l3 0.8 l-3 0.8z" fill="#ff9a3c"/><circle cx="3" cy="-2.8" r="0.7" fill="#2a1a30"/></g>' + [0, 1, 2].map(i => '<circle data-spl="' + i + '" r="1.3" fill="#8fd3ff" opacity="0"/>').join('');
      if (st === 'shower') h += crownH(false) + Array.from({ length: 7 }, (_, i) => '<path data-rain="' + i + '" d="M0 0 v6" stroke="#8fd3ff" stroke-width="1.3" stroke-linecap="round" opacity="0"/>').join('');
      if (st === 'mud') { [[0.28, 0.7, 7], [0.7, 0.62, 6], [0.5, 0.86, 8], [0.22, 0.44, 4.5], [0.8, 0.82, 5], [0.62, 0.3, 4], [0.4, 0.25, 3.6]].forEach(([fx, fy, r], i) => { h += '<ellipse data-mud="' + i + '" cx="' + (bb.x + bb.width * fx).toFixed(1) + '" cy="' + (bb.y + bb.height * fy).toFixed(1) + '" rx="' + r + '" ry="' + (r * 0.75).toFixed(1) + '" fill="#8a5a38" opacity="0"/>'; }); h += '<path d="M' + (bb.x + 6) + ' ' + (head - 2) + ' q8 6 16 0 q8 6 16 0 q8 6 16 0 q8 6 16 0" stroke="#8a5a38" stroke-width="5" fill="none" stroke-linecap="round" opacity="0.9"/>' + Array.from({ length: 7 }, (_, i) => '<path data-rain="' + i + '" d="M0 0 v6" stroke="#8a5a38" stroke-width="2" stroke-linecap="round" opacity="0"/>').join('') + [0, 1, 2].map(i => '<ellipse data-mdrop="' + i + '" rx="1.4" ry="2" fill="#7a4a2a" opacity="0"/>').join(''); }
      if (st === 'sauna') h += '<ellipse data-blush cx="' + (bb.x + bb.width / 2).toFixed(1) + '" cy="' + (bb.y + bb.height * 0.55).toFixed(1) + '" rx="' + (bb.width / 2.2).toFixed(1) + '" ry="' + (bb.height / 2.4).toFixed(1) + '" fill="#ff7a7a" opacity="0.16"/>' + towel('#fff6e6') + steam(4) + [0, 1].map(i => '<ellipse data-sw="' + i + '" rx="0.9" ry="1.4" fill="#9fdcff" opacity="0"/>').join('');
    }
    if (mood === 'clean') h += [0, 1, 2, 3].map(i => '<path data-spk="' + i + '" d="M0 -4 Q0.6 -0.6 4 0 Q0.6 0.6 0 4 Q-0.6 0.6 -4 0 Q-0.6 -0.6 0 -4Z" fill="#fff6b8"/>').join('');
    if (mood === 'tv') h += c.eyes.map(e => '<circle data-eyeglow cx="' + e.x + '" cy="' + e.y + '" r="' + (e.r * 1.05).toFixed(2) + '" fill="#7cc8ff" opacity="0" style="mix-blend-mode:screen"/>').join('');
    if (false) h += '<ellipse data-glow cx="' + (bb.x + bb.width / 2).toFixed(1) + '" cy="' + (bb.y + bb.height / 2).toFixed(1) + '" rx="' + (bb.width / 2).toFixed(1) + '" ry="' + (bb.height / 2).toFixed(1) + '" fill="#7cc8ff" opacity="0.14" style="mix-blend-mode:screen"/>';
    if (mood === 'sleep') h += [0, 1, 2].map(i => '<text data-z="' + i + '" font-family="Fredoka, sans-serif" font-weight="700" font-size="9" fill="#ece6ff" stroke="#6b5bd6" stroke-width="0.8" paint-order="stroke">z</text>').join('');
    if (mood === 'reveal') h += Array.from({ length: 10 }, (_, i) => i % 2 ? '<path data-rv="' + i + '" d="M0 2.6c-1.6-1.4-4-2.6-4-4.6a2 2 0 0 1 4-0.6a2 2 0 0 1 4 0.6c0 2-2.4 3.2-4 4.6z" fill="#ff6fae" stroke="#fff" stroke-width="0.6" opacity="0"/>' : '<path data-rv="' + i + '" d="M0 -4 Q0.6 -0.6 4 0 Q0.6 0.6 0 4 Q-0.6 0.6 -4 0 Q-0.6 -0.6 0 -4Z" fill="#ffe680" opacity="0"/>').join('');
    if (mood === 'happy') h += [0, 1].map(i => '<path data-h="' + i + '" d="M0 2.6c-1.6-1.4-4-2.6-4-4.6a2 2 0 0 1 4-0.6a2 2 0 0 1 4 0.6c0 2-2.4 3.2-4 4.6z" fill="#ff6fae" stroke="#fff" stroke-width="0.6"/>').join('');
    if (mood === 'dance') h += [0, 1].map(i => '<text data-note="' + i + '" font-size="9" font-weight="900" fill="' + (i ? '#b38cff' : '#ff5cc6') + '" stroke="#fff" stroke-width="0.8" paint-order="stroke">♪</text>').join('');
    return h;
  }
  function fxHtml(mood, BS, inRoom) {
    if (mood === 'unlock') return '<g data-box><rect x="28" y="68" width="44" height="26" rx="4" fill="#ff7fd0"/><rect x="47" y="68" width="6" height="26" fill="#ffd84a"/></g><g data-lid><rect x="25" y="60" width="50" height="10" rx="3" fill="#ff5cc6"/><rect x="47" y="60" width="6" height="10" fill="#ffd84a"/><path d="M50 60 q-8 -8 -12 -2 q4 4 12 2 q8 -8 12 -2 q-4 4 -12 2" fill="#ffd84a"/></g>' +
      Array.from({ length: 24 }, (_, i) => '<rect data-cf="' + i + '" width="2.4" height="3.6" rx="0.6" fill="' + ['#ff5cc6', '#ffcd3c', '#3fd7f6', '#7be495', '#b38cff'][i % 5] + '"/>').join('');
    if (false) return '<path d="M12 76 H88 Q86 98 50 98 Q14 98 12 76Z" fill="#9fd8f5"/><rect x="10" y="72" width="80" height="6" rx="3" fill="#e6f7fd"/>' + [18, 28, 40, 60, 72, 82].map((x, i) => '<circle cx="' + x + '" cy="' + (72 + (i % 2)) + '" r="' + (4 + (i % 3)) + '" fill="#fff"/>').join('');
    return '';
  }

  const clamp01 = x => x < 0 ? 0 : x > 1 ? 1 : x;
  const ss = x => { x = clamp01(x); return x * x * (3 - 2 * x); };
  const bump = x => x <= 0 || x >= 1 ? 0 : Math.pow(Math.sin(Math.PI * x), 2);
  const backOut = x => { x = clamp01(x); const c = 1.7; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); };
  const noise = (t, s) => (Math.sin(t * 0.00071 + s) + 0.6 * Math.sin(t * 0.00117 + s * 1.7) + 0.4 * Math.sin(t * 0.00029 + s * 2.3)) / 2;
  const breath = q => q < 0.42 ? ss(q / 0.42) : 1 - ss((q - 0.42) / 0.58);
  // anticipation crouch -> stretched takeoff -> arc -> squash landing with damped overshoot
  function hop(ms, P, o) {
    const p = (ms % P) / P, a = o.ant, b = a + o.air;
    if (p < a) return { y: 0, sy: 1 - o.sq * 0.75 * ss(p / a), air: 0 };
    if (p < b) { const q = (p - a) / o.air; return { y: o.h * 4 * q * (1 - q), sy: 1 + o.st * Math.pow(Math.abs(1 - 2 * q), 2), air: Math.sin(Math.PI * q) }; }
    const tl = (p - b) * P; return { y: 0, sy: 1 - o.sq * Math.exp(-tl / 70) * Math.cos(tl / 46), air: 0 };
  }
  const pose = (t, B, ease, hold) => { const n = Math.floor(t / B), q = (t % B) / B, side = m => (m & 1) ? 1 : -1; const a = side(n - 1), b = side(n); return { x: a + (b - a) * ease(q / hold), q, n }; };
  function spring(sp, f, k, c, dt) { sp.v += (f - k * sp.x - c * sp.v) * dt; sp.x += sp.v * dt; if (sp.x > 35) { sp.x = 35; sp.v = 0; } if (sp.x < -35) { sp.x = -35; sp.v = 0; } }

  function foodOf(I, P) { const S = window.SquishFoods; if (!S) return null; return S.get(I.props.food) || S.LIST[P.hash % S.LIST.length]; }
  function eatState(I, P, now, T, t, forceFull) {
    const F = foodOf(I, P); if (!F) return null; const c = P.c; const m = c ? c.mouth : { x: 50, y: 60 };
    const ms = Math.max(2000, Number(I.props.eatMs) || F.sec * 1000), st0 = Number(I.props.eatStart) || 0;
    const el = forceFull ? ms + (T % 3400) : st0 ? now - st0 : T % (ms + 3400);
    const R = { v: { sx: 1, sy: 1, rot: 0, tx: 0, ty: 0 }, puff: 0, arm: () => -36, mo: 0, food: null, strand: 0, crumb: -1, burp: -1, steam: true, juice: -1, heart: false, F, m, face: 'eating' };
    const hx = m.x, HY = sc => Math.min(70, m.y + 1 + 6 * sc), hy = HY(1.7); R.reach = true;
    if (el >= ms) {
      const f = el - ms; R.face = 'content'; R.steam = false; R.reach = false;
      const b = breath((f % 2400) / 2400); R.v.sy = 1 + 0.03 * b; R.v.rot = -4 + 1.5 * b;
      const bu = (f - 700) / 650; if (bu > 0 && bu < 1) { R.burp = bu; const hk = bump(bu / 0.35); R.v.sy *= 1 - 0.07 * hk; R.v.ty -= 2.5 * hk; }
      R.arm = s => -60 + 10 * (0.5 - 0.5 * Math.cos(f / 140 + (s > 0 ? Math.PI : 0)));
      R.heart = f > 1300; return R;
    }
    const n = F.bites, w = ms / n, bi = Math.floor(el / w), q = (el % w) / w;
    const qb = { nibble: 0.16, chomp: 0.3, savor: 0.26, gulp: 0.6, slurp: 0.7 }[F.style];
    const rem = 1 - (bi + ss((q - qb) / 0.05)) / n, aB = clamp01((q - qb) / (1 - qb));
    if (F.fx === 'crumbs' && q >= qb && q < qb + 0.32) R.crumb = (q - qb) / 0.32;
    switch (F.style) {
      case 'nibble': {
        const lean = bump(q / (qb * 2.2)), ch = q > qb ? (0.5 - 0.5 * Math.cos(TAU * aB * 4)) * (1 - aB * 0.5) : 0;
        R.mo = q < qb ? ss(q / qb) * 0.7 : ch * 0.8; R.v.ty = ch + lean; R.v.rot = 3 * lean + 1.2 * Math.sin(t / 300); R.v.sy = 1 - 0.03 * ch;
        { const sc = 1.8 * (0.6 + 0.4 * rem); R.food = { x: hx, y: HY(sc) - 6 * lean, s: sc, r: F.k === 'carrot' ? 180 : 0 }; }
        R.arm = () => -38 + 6 * lean; break; }
      case 'chomp': {
        const wind = q < 0.24 ? ss(q / 0.24) : 0, snap = q < 0.24 ? 0 : q < 0.34 ? ss((q - 0.24) / 0.1) : 1 - ss((q - 0.34) / 0.22);
        const ch = q > qb ? 0.5 - 0.5 * Math.cos(TAU * aB * 3) : 0, imp = q > qb ? Math.exp(-(q - qb) * w / 90) : 0;
        R.mo = q < 0.24 ? wind : q < qb ? 1 : ch * 0.8; R.puff = q > qb ? 0.07 * (1 - ss(aB)) : 0;
        R.v.rot = -3 * wind + 6 * snap; R.v.ty = 2 * snap + ch; R.v.sy = 1 + 0.03 * wind - 0.08 * imp - 0.03 * ch;
        { const sc = 2.0 * (0.6 + 0.4 * rem); R.food = { x: hx, y: HY(sc) + 2 * wind - 8 * snap, s: sc, r: F.k === 'pizza' ? 180 : 0 }; }
        R.arm = () => -30 - 10 * wind + 14 * snap; break; }
      case 'savor': {
        const lean = bump(q / (qb * 2.2)), ch = q > qb ? (0.5 - 0.5 * Math.cos(TAU * aB * 3)) * 0.7 : 0, sway = q > qb ? Math.sin(TAU * aB * 1.5) * bump(aB) : 0;
        R.mo = q < qb ? ss(q / qb) * 0.8 : ch; R.face = q > qb + 0.08 && q < 0.9 ? 'content' : 'eating';
        R.v.rot = 2 * lean + 5 * sway; R.v.ty = lean; R.v.sy = 1 - 0.02 * ch;
        R.heart = F.fx === 'hearts' && q > qb; if (F.fx === 'juice' && q >= qb && q < qb + 0.5) R.juice = (q - qb) / 0.5;
        { const sc = 1.8 * (0.6 + 0.4 * rem); R.food = { x: hx, y: HY(sc) - 6 * lean, s: sc, r: 0 }; }
        R.arm = () => -38 + 5 * lean; break; }
      case 'gulp': {
        const crouch = q < 0.25 ? ss(q / 0.25) : q < 0.32 ? 1 - ss((q - 0.25) / 0.07) : 0, u = clamp01((q - 0.27) / (qb - 0.27));
        const look = q > 0.25 && q < 0.8 ? bump((q - 0.25) / 0.55) : 0, sw = q >= qb ? Math.exp(-(q - qb) * w / 110) : 0, ch = q > qb ? (0.5 - 0.5 * Math.cos(TAU * aB * 2)) * 0.6 : 0;
        R.v.sy = 1 - 0.07 * crouch - 0.09 * sw + 0.04 * look; R.v.rot = -8 * look; R.v.ty = 1.5 * crouch; R.mo = q > 0.3 && q < qb ? 1 : ch;
        if (q < 0.27) R.food = { x: hx, y: hy + 1.5 * crouch, s: 1.7 * (F.k === 'marshmallow' ? 1 - 0.18 * crouch : 1), r: 0 };
        else if (q < qb) { R.reach = false; R.food = { x: hx + 5 * Math.sin(Math.PI * u), y: hy + (m.y - 1 - hy) * u - 30 * Math.sin(Math.PI * u), s: 1.7 * (1 - 0.4 * ss((u - 0.8) / 0.2)), r: 360 * u }; }
        else if (bi < n - 1 && q > 0.82) R.food = { x: hx, y: hy, s: 1.7 * backOut((q - 0.82) / 0.18), r: 0 };
        else R.reach = false;
        R.arm = s => -36 + (s > 0 ? 80 * bump(clamp01((q - 0.16) / 0.22)) : 0) - 8 * crouch; break; }
      case 'slurp': {
        const on = q > 0.1 && q < qb, su = clamp01((q - 0.1) / (qb - 0.1)), pop = q >= qb ? Math.exp(-(q - qb) * w / 80) : 0, ch = q > qb ? (0.5 - 0.5 * Math.cos(TAU * aB * 3)) * 0.6 : 0;
        R.v.sy = 1 + 0.05 * (on ? ss(su / 0.15) : 0) - 0.08 * pop - 0.02 * ch; R.v.rot = 4 * ss(q / 0.1) * (1 - ss((q - qb) / 0.15)); R.v.tx = on ? 0.35 * Math.sin(t / 28) : 0;
        R.mo = on ? 0.45 : ch; R.strand = on ? 1 - su : 0;
        R.food = { x: m.x, y: Math.min(82, m.y + 20), s: 1.8, r: 0 };
        R.arm = () => -46; break; }
    }
    return R;
  }
  const lerp = (a, b, u) => a + (b - a) * u;
  function groove(D, T) {
    const B = 500, ph = T / B, k = Math.floor(ph), f = ph - k, g = Math.exp(-f * 6), alt = (k & 1) ? 1 : -1, hy = 4 * f * (1 - f), S1 = Math.sin(ph * Math.PI), S2 = Math.sin(ph * TAU);
    const o = { v: { rot: 0, tx: 0, ty: 0, sy: 1 }, arm: () => 60, foot: () => 0, ear: 0, air: 0 };
    const snapPose = (P, sh) => { const a = P[(k + P.length - 1) % P.length], b = P[k % P.length], e = backOut(Math.min(1, f / (sh || 0.22))); return a.map((x, i) => lerp(x, b[i], e)); };
    switch (D) {
      case 'sway': Object.assign(o.v, { rot: 11 * S1, tx: 7 * S1, ty: -3 * Math.abs(S1), sy: 1 - 0.05 * g }); o.arm = s => 128 + 26 * Math.sin(ph * TAU + (s > 0 ? Math.PI : 0)); o.foot = s => 3.5 * Math.max(0, -S1 * s); o.ear = 10 * S1; break;
      case 'wiggle': Object.assign(o.v, { rot: 8 * S2, tx: 6 * S2, sy: 1 - 0.05 * g }); o.arm = s => 80 + 30 * Math.sin(ph * TAU * 2 + (s > 0 ? Math.PI : 0)); o.foot = s => 3.5 * Math.max(0, S2 * s); o.ear = 12 * S2; break;
      case 'jelly': Object.assign(o.v, { sy: 1 - 0.17 * g * Math.cos(f * 11), rot: 5 * alt * g, ty: 2 * g }); o.arm = s => 40 + 95 * (1 - g); o.foot = () => 2 * (1 - g); o.ear = 14 * g * alt; break;
      case 'bounce': Object.assign(o.v, { ty: -20 * hy, sy: f < 0.12 ? 1 - 0.16 * (1 - f / 0.12) : 1 + 0.06 * hy }); o.arm = s => 20 + 130 * hy; o.foot = () => 3.5 * hy; o.ear = 14 * (g - 0.45); o.air = hy; break;
      case 'shuffle': { const e = backOut(Math.min(1, f / 0.2)); Object.assign(o.v, { tx: 9 * Math.sin(ph * Math.PI), rot: 7 * alt * e, sy: 1 - 0.06 * g }); o.arm = s => s === alt ? lerp(-10, 155, e) : lerp(155, -10, e); o.foot = s => s === alt ? 4 * Math.sin(f * Math.PI) : 0; o.ear = 8 * alt * e; break; }
      case 'pop': { const p = snapPose([[150, -15, -7, 0], [-15, 150, 7, 0], [95, 95, 0, -3], [150, 150, 0, -6]]); Object.assign(o.v, { rot: p[2], ty: p[3], sy: 1 - 0.09 * g }); o.arm = s => s < 0 ? p[0] : p[1]; o.foot = s => (k % 4 === 0 && s < 0) || (k % 4 === 1 && s > 0) ? 3 * g : 0; o.ear = 10 * g * alt; break; }
      case 'hop': Object.assign(o.v, { tx: lerp(-alt * 11, alt * 11, ss(f)), ty: -15 * hy, rot: 8 * alt * hy, sy: f < 0.1 ? 1 - 0.14 * (1 - f / 0.1) : 1 + 0.05 * hy }); o.arm = s => 120 + 30 * hy; o.foot = () => 3.5 * hy; o.ear = 12 * (g - 0.4) * alt; o.air = hy; break;
      case 'twist': Object.assign(o.v, { rot: 16 * S1, ty: 3 * Math.abs(S1), sy: 1 - 0.05 * g }); o.arm = s => 65 - 60 * S1 * s; o.foot = s => 3.5 * Math.max(0, -S1 * s); o.ear = -12 * S1; break;
      case 'robot': { const p = snapPose([[95, 0, 0, 0], [0, 95, 8, 3], [95, 95, 0, 0], [155, -10, -8, -3]], 0.08); Object.assign(o.v, { rot: p[2], tx: p[3], sy: 1 - 0.07 * g }); o.arm = s => s < 0 ? p[0] : p[1]; o.ear = 5 * g; break; }
      case 'slide': { const S4 = Math.sin(ph * Math.PI / 2); Object.assign(o.v, { tx: 13 * S4, rot: -7 * Math.cos(ph * Math.PI / 2), sy: 1 - 0.05 * g }); o.arm = s => s * Math.cos(ph * Math.PI / 2) > 0 ? 120 + 30 * S2 : -35 + 20 * g; o.foot = s => s === alt ? 3.5 * Math.sin(f * Math.PI) : 0; o.ear = 8 * S2; break; }
      case 'leap': { const q = (ph / 2) % 1; let ty = 0, sy = 1, arm = 50, air = 0;
        if (q < 0.25) { const c = ss(q / 0.25); sy = 1 - 0.15 * c; ty = 2 * c; arm = 50 - 70 * c; }
        else if (q < 0.85) { const u = (q - 0.25) / 0.6; air = 4 * u * (1 - u); ty = -36 * air; sy = 1 + 0.08 * air; arm = 160; }
        else { const u = (q - 0.85) / 0.15; sy = 1 - 0.17 * Math.sin(u * Math.PI); arm = lerp(160, 50, u); }
        Object.assign(o.v, { ty, sy, rot: 6 * Math.sin(ph * Math.PI) }); o.arm = () => arm; o.foot = () => 3.5 * air; o.ear = -14 * air + 6 * (q > 0.85 ? 1 : 0); o.air = air; break; }
      default: return groove('sway', T);
    }
    return o;
  }
  function bbx(I, i) { const b = I.parts.bb; return b.x + b.width * [0.3, 0.55, 0.75][i % 3]; }
  function frame(I, now) {
    const P = I.parts, el = I.bodyRef.current; if (!P || !el) return;
    const G = window.SquishRig; if (!G) return;
    let mood = I.props.mood || 'idle'; mood = ALIAS[mood] || mood;
    if (mood === 'cycle') { const SEQ = [['idle', 3000], ['dance', 3000], ['idle', 3000], ['happy', 3000], ['idle', 3000], ['clean', 3000], ['idle', 3000], ['spin', 3000]]; const tot = SEQ.reduce((a, q) => a + q[1], 0); let u = (now + I.seed * 7) % tot; mood = 'idle'; for (const [m, d] of SEQ) { if (u < d) { mood = m; break; } u -= d; } } if (MOODS.indexOf(mood) < 0) mood = 'idle';
    if (I.props.still) { el.style.transform = ''; return; }
    const fk = I.props.food || ''; if (mood !== I._mood || fk !== I._food) { I._snap = I._out || null; I._mood = mood; I._food = fk; I._t0 = now; I._built = null; }
    const dt = Math.min(0.033, Math.max(0.001, (now - (I._lt || now - 16)) / 1000)); I._lt = now;
    const t = now + I.seed, T = now - I._t0, h = P.hash, per = 0.88 + (h % 7) * 0.04, hopH = 13 + (h % 5) * 1.5;
    const v = { sx: 1, sy: 1, rot: 0, tx: 0, ty: 0 };
    let Gv = null, E = null, scale = 1, hidden = false, laugh = false, faceKey = FACE[mood], air = 0, X = 0, chew = 0, itch = 0, lift = null, look = true;
    const setHop = o => { const r = hop(t, o.P, o); v.ty -= r.y; v.sy *= r.sy; air = r.air; };
    switch (mood) {
      case 'idle': {
        const b = breath((t % (2800 * per)) / (2800 * per)); v.sy = 1 + 0.022 * b; v.rot = 2.4 * noise(t, h); v.tx = 1.1 * noise(t * 0.7, h + 5);
        const q = (t % 7400) / 7400; if (q < 0.11) { const r = hop(q * 7400, 814, { ant: 0.24, air: 0.4, h: 6, st: 0.06, sq: 0.09 }); v.ty -= r.y; v.sy *= r.sy; air = r.air; }
        break; }
      case 'happy': setHop({ P: 780 * per, ant: 0.2, air: 0.46, h: hopH, st: 0.1, sq: 0.15 }); v.rot = 5 * air * ((Math.floor(t / (780 * per)) & 1) ? 1 : -1); break;
      case 'unlock': break;
      case 'groove': { Gv = groove(I.props.dance || 'sway', T); v.rot = Gv.v.rot; v.tx = Gv.v.tx; v.ty = Gv.v.ty; v.sy = Gv.v.sy; air = Gv.air; break; }
      case 'wave': { const b = breath((t % 1600) / 1600); v.rot = -5 + 2 * Math.sin(t / 220); v.sy = 1 + 0.03 * b; v.ty = -2 * b; break; }
      case 'cheer': setHop({ P: 480, ant: 0.18, air: 0.5, h: hopH * 1.2, st: 0.1, sq: 0.17 }); v.rot = 6 * Math.sin(t / 240); break;
      case 'spin': { const u = Math.min(1, T / 1150); v.rot = 360 * (u < 0.15 ? 0 : ss((u - 0.15) / 0.75)); const hq = clamp01((u - 0.1) / 0.8); v.ty -= 16 * Math.sin(Math.PI * hq); v.sy *= u < 0.15 ? 1 - 0.12 * ss(u / 0.15) : u > 0.9 ? 1 - 0.1 * bump((u - 0.9) / 0.1) : 1 + 0.06 * Math.sin(Math.PI * hq); break; }
      case 'reveal': { const ts = T / 1000; if (ts < 0.42) { const e = ts / 0.42, eo = ease.out(e); scale = 0.35 + 0.65 * eo; v.ty += 46 - 104 * eo; v.sy *= 1 + 0.22 * (1 - e); v.sx = 1; v.rot = 10 * Math.sin(e * 7) * (1 - e); } else if (ts < 0.78) { const e = (ts - 0.42) / 0.36; v.ty += -58 + 58 * e * e; v.sy *= 1 + 0.08 * e; } else if (ts < 1.4) { const e = (ts - 0.78) / 0.62; v.sy *= 1 - 0.18 * Math.exp(-e * 4.5) * Math.cos(e * 13); } else { setHop({ P: 900 * per, ant: 0.22, air: 0.42, h: hopH * 0.8, st: 0.08, sq: 0.13 }); v.rot = 4 * Math.sin(t / 600); } break; }
      case 'dance': {
        const B = 540 * per, p = pose(t, B, backOut, 0.42); X = p.x; const g = Math.exp(-p.q * B / 95);
        v.rot = 9 * X; v.tx = 3.5 * X; v.sy = 1 - 0.075 * g; v.ty = 2.6 * g - 3 * bump(p.q); break; }
      case 'eat': case 'full': { E = eatState(I, P, now, T, t, mood === 'full'); if (E) { Object.assign(v, E.v); faceKey = I.key() === 'pip' ? null : E.face; chew = E.mo; } break; }
      case 'sleep': { look = false; const b = breath((t % (3800 * per)) / (3800 * per)); v.sy = 1 + 0.035 * b; v.rot = -5 + 1.2 * b; v.ty = 3; break; }
      case 'sad': { look = false; const q = (t % 2600) / 2600, env = bump(q / 0.38), hic = env * Math.abs(Math.sin(q / 0.38 * 3 * Math.PI));
        v.sy = 0.95 + 0.02 * hic; v.rot = -4 + 1.6 * noise(t, h); v.ty = 4 - 2.2 * hic; break; }
      case 'clean': { const B = 1100 * per, p = pose(t, B, ss, 0.5); X = p.x; v.rot = 6 * X; v.ty = -3 * bump(p.q / 0.5); v.sy = 1 + 0.02 * bump(p.q / 0.5); break; }
      case 'dirty': { const q = (t % 3000) / 3000, env = bump(q / 0.22); itch = env * (0.5 - 0.5 * Math.cos(t / 55));
        v.sy = 0.96; v.rot = 3 * noise(t, h); v.tx = 1.4 * env * Math.sin(t / 28); break; }
      case 'bath': { const st = I.props.bathStyle || 'tub';
        if (st === 'hottub') { const b = breath((t % 3200) / 3200); v.ty = 6; v.rot = -5 + 1.5 * b; v.sy = 1 + 0.02 * b; faceKey = 'content'; }
        else if (st === 'spa') { const b = breath((t % 4000) / 4000); v.ty = 4; v.rot = 1.5 * noise(t, h); v.sy = 1 + 0.018 * b; faceKey = 'content'; }
        else if (st === 'duck') { v.ty = 6 + 2.2 * Math.sin(t / 400); v.rot = 6 * Math.sin(t / 520); v.sy = 1 - 0.02 * Math.sin(t / 260); faceKey = 'party'; }
        else if (st === 'mud') { v.ty = 0; v.rot = 5 * Math.sin(t / 280); v.sy = 1 - 0.025 * Math.abs(Math.sin(t / 140)); faceKey = 'party'; }
        else if (st === 'shower') { v.ty = 0; v.rot = 4 * Math.sin(t / 320); v.sy = 1 - 0.02 * Math.abs(Math.sin(t / 160)); faceKey = 'happy'; }
        else if (st === 'sauna') { const b = breath((t % 3600) / 3600); v.ty = 3; v.rot = -2 + noise(t, h); v.sy = 1 + 0.03 * b; faceKey = 'content'; }
        else { const f = st === 'bubble' ? 0.8 : 1; v.ty = 6 + 1.8 * Math.sin(t / (700 * f)); v.rot = 4 * Math.sin(t / (1100 * f)) + 1.5 * Math.sin(t / 530 + 1); v.sy = 1 - 0.015 * Math.sin(t / 350); if (st === 'bubble') faceKey = 'happy'; }
        break; }
      case 'tv': { const b = breath((t % 3600) / 3600); v.rot = 0.8 * noise(t, h); v.sy = 1 + 0.012 * b; const ph = (t % 9000) / 9000; faceKey = ph < 0.45 ? null : ph < 0.7 ? 'happy' : ph < 0.82 ? 'party' : 'content'; break; }
    }
    let U = 0;
    if (mood === 'unlock') { U = (T % 3400) / 3400;
      if (U < 0.22) { hidden = true; scale = 0.001; }
      else if (U < 0.34) { const e = (U - 0.22) / 0.12; scale = Math.max(0.001, ease.back(e)); v.ty += 18 * (1 - ease.out(e)); v.sy *= 1 + 0.12 * (1 - e); }
      else setHop({ P: 780 * per, ant: 0.2, air: 0.46, h: hopH, st: 0.1, sq: 0.15 }); }
    v.sx = 1 + (1 - v.sy) * 0.85 + (E ? E.puff : 0);
    // follow-through springs driven by body motion
    const S = I._sp || (I._sp = { V: { x: 0, v: 0 }, L: { x: 0, v: 0 }, Tl: { x: 0, v: 0 }, ty: v.ty, vy: 0, rot: v.rot, vr: 0 });
    const vy = (v.ty - S.ty) / dt, vr = (v.rot - S.rot) / dt; let ay = (vy - S.vy) / dt, ar = (vr - S.vr) / dt;
    ay = Math.max(-16000, Math.min(16000, ay)); ar = Math.max(-9000, Math.min(9000, ar)); S.ty = v.ty; S.vy = vy; S.rot = v.rot; S.vr = vr;
    spring(S.V, ay * 1.6, 260, 13, dt); spring(S.L, -ar * 1.3, 220, 11, dt); spring(S.Tl, -ar * 1.6 - vr * 0.5, 120, 7, dt);
    // arms
    const armR = P.arms.map((a, i) => {
      const s = a.side; let r = 0;
      switch (mood) {
        case 'idle': r = 7 + 5 * noise(t * 1.3, i * 2 + h); break;
        case 'happy': r = 112 + 6 * noise(t * 2, i + h); break;
        case 'unlock': r = U < 0.34 ? 150 : 112; break;
        case 'spin': r = 95 + 25 * Math.sin(t / 120 + (s > 0 ? Math.PI : 0)); break;
        case 'reveal': r = T < 1050 ? 140 - 40 * ss(T / 1050) : 110 + 28 * Math.sin(t / 170 + (s > 0 ? Math.PI : 0)); break;
        case 'dance': r = 62 + 52 * X * s; break;
        case 'eat': case 'full': {
          if (E && E.reach && E.food && a.bx != null) { const fx = E.food.x + s * 4 * E.food.s, fy = E.food.y + 2; let d = (Math.atan2(fy - a.sy, fx - a.sx) - Math.atan2(a.by - a.sy, a.bx - a.sx)) * 180 / Math.PI; d = ((d + 540) % 360) - 180; r = -s * d; }
          else r = E ? E.arm(s) : -36; break; }
        case 'groove': r = Gv ? Gv.arm(s) : 60; break;
        case 'wave': r = s > 0 ? 145 + 28 * Math.sin(t / 95) : 12 + 4 * noise(t, i); break;
        case 'cheer': r = 125 + 30 * Math.sin(t / 120 + (s > 0 ? Math.PI : 0)) + 15 * air; break;
        case 'sad': r = -70 + 3 * noise(t, i); break;
        case 'clean': r = 34 + 16 * X * s; break;
        case 'dirty': r = s < 0 ? 8 : 70 + 26 * itch; break;
        case 'bath': { const st = I.props.bathStyle || 'tub', q = ((t / 900) + (s > 0 ? 0.5 : 0)) % 1;
          if (st === 'hottub') r = 70 + 6 * breath((t % 3200) / 3200); else if (st === 'spa') r = -20 + 3 * noise(t, i); else if (st === 'sauna') r = -14 + 4 * breath((t % 3600) / 3600);
          else if (st === 'shower' || st === 'mud') r = 105 + 28 * Math.sin(t / 110 + (s > 0 ? Math.PI : 0)); else if (st === 'duck') r = 60 + 50 * breath(((t / 520) + (s > 0 ? 0.5 : 0)) % 1); else r = 45 + 34 * breath(q); break; }
        case 'tv': r = 4 + 2 * noise(t, i); break;
        case 'sleep': r = -6 + 2 * breath((t % 3800) / 3800); break;
      }
      const rr = r + S.V.x * (mood === 'sleep' ? 0.3 : 1.1) + s * S.L.x * 0.5; const hi = mood === 'eat' || mood === 'full' ? 120 : (mood === 'groove' || mood === 'wave' || mood === 'cheer') ? 168 : 78; return rr > hi - 12 ? hi - 12 * Math.exp(-(rr - hi + 12) / 12) : Math.max(-75, rr);
    });
    const partR = P.parts.map((p, i) => {
      const s = p.side;
      if (p.kind === 'steam') return 0;
      if (p.kind === 'wing') { const amp = { groove: 18, cheer: 18, wave: 10, dance: 14, happy: 16, unlock: 14, spin: 12, reveal: 14, clean: 8, bath: 8 }[mood] || 4; const sp = mood === 'dance' || mood === 'happy' || mood === 'reveal' || mood === 'spin' || mood === 'groove' || mood === 'cheer' ? 160 : 700; return -p.side * (amp * (0.5 + 0.5 * Math.sin(t / sp + (p.side > 0 ? 0.6 : 0)))) + p.side * S.V.x * 0.3; }
      if (p.kind === 'tent') { const sp = 520 + (i * 137) % 260, ph = i * 1.9 + (i * i) % 3; return (11 + (i % 2) * 4) * Math.sin(t / sp + ph) + 5 * noise(t * 2, i + 3) + S.Tl.x * 0.8 + p.side * S.V.x * 0.5; }
      if (p.kind === 'top') {
        const amp = { groove: 4, wave: 3, cheer: 5, idle: 3, spin: 4, reveal: 4, eat: 2, full: 2, dance: 4, unlock: 4, happy: 3, sad: 0, clean: 3, dirty: 2, bath: 3, tv: 1.5, sleep: 0 }[mood];
        const droop = mood === 'full' ? 4 : mood === 'sleep' ? 16 : mood === 'sad' ? 14 : mood === 'dirty' ? 6 : 0;
        let r = s * droop + amp * noise(t * 1.6, s * 1.3 + 2) - s * S.V.x * 0.9 + S.L.x;
        if (mood === 'idle') r += s * 9 * bump(((t + (s > 0 ? 90 : 0)) % 3900) / 320);
        if (Gv) r += Gv.ear * (s < 0 ? 1 : 0.8);
        return r;
      }
      const amp = { groove: 18, wave: 9, cheer: 16, idle: 7, spin: 12, reveal: 14, eat: 6, full: 5, dance: 10, unlock: 12, happy: 14, sad: 2, clean: 9, dirty: 4, bath: 8, tv: 4, sleep: 1.5 }[mood];
      const wp = mood === 'groove' ? 250 : mood === 'happy' || mood === 'dance' || mood === 'unlock' || mood === 'cheer' ? 300 : 900;
      return amp * Math.sin(TAU * (t / wp) + i) + S.Tl.x * 1.3 + s * S.V.x * 0.4;
    });
    // smooth blend from previous mood
    if (I._snap && T < 340) { const w = ss(T / 340), sn = I._snap;
      for (const kk in v) v[kk] = sn.v[kk] + (v[kk] - sn.v[kk]) * w;
      armR.forEach((r, i) => { if (sn.a[i] != null) armR[i] = sn.a[i] + (r - sn.a[i]) * w; });
      partR.forEach((r, i) => { if (sn.p[i] != null) partR[i] = sn.p[i] + (r - sn.p[i]) * w; }); }
    if (E) { I._armS = I._armS || []; armR.forEach((r, i) => { const p = I._armS[i]; armR[i] = p == null ? r : p + (r - p) * Math.min(1, dt * 13); }); } I._armS = E ? armR.slice() : null;
    I._out = { v: { ...v }, a: armR.slice(), p: partR.slice() };
    const u = (Number(I.props.size) || 150) / 150;
    el.style.transform = 'translate(' + (v.tx * u).toFixed(2) + 'px,' + (v.ty * u).toFixed(2) + 'px) rotate(' + v.rot.toFixed(2) + 'deg) scale(' + (v.sx * scale).toFixed(4) + ',' + (v.sy * scale).toFixed(4) + ')';
    el.style.opacity = hidden ? '0' : '1';
    if (faceKey && !G.FACES[faceKey]) faceKey = faceKey === 'smelly' ? 'sad' : 'happy';
    const FD = E ? E.F : null; const BS = mood === 'bath' ? (I.props.bathStyle || 'tub') : '', inRoom = !!I.props.bathStyle; const sig = mood + '|' + faceKey + '|' + (FD ? FD.k : '') + '|' + BS;
    if (sig !== I._built) {
      I._built = sig; const hide = !!faceKey && !!P.c;
      P.eyes.forEach(e => { e.style.display = hide ? 'none' : ''; e.style.transform = ''; }); P.mouth.forEach(e => e.style.display = hide ? 'none' : '');
      const F = I.faceRef.current; if (F) { F.innerHTML = (hide ? G.faceInner({ ...P.c, cheeks: [] }, faceKey, 0) : '') + extras(P, mood, FD, BS); I.q = s => F.querySelectorAll(s); I.chomp = F.querySelector('[data-chomp]'); I.food = F.querySelector('[data-food]'); I.strand = F.querySelector('[data-strand]'); I.burpEl = F.querySelector('[data-burp]'); I.glow = F.querySelector('[data-glow]'); }
      const Xf = I.fxRef && I.fxRef.current; if (Xf && Xf._m !== mood + BS + inRoom) { Xf._m = mood + BS + inRoom; Xf.innerHTML = fxHtml(mood, BS, inRoom); I.box = Xf.querySelector('[data-box]'); I.lid = Xf.querySelector('[data-lid]'); I.cf = Xf.querySelectorAll('[data-cf]'); }
    }
    P.arms.forEach((a, i) => { const R = (-a.side * armR[i]).toFixed(2); a.els.forEach((e, j) => e.setAttribute('transform', 'rotate(' + R + ' ' + a.sx.toFixed(1) + ' ' + a.sy.toFixed(1) + ') ' + a.base[j])); });
    const seat = !!I.props.seated; if (seat !== I._seat) { I._seat = seat; P.feet.forEach(f => f.el.style.display = seat ? 'none' : ''); }
    P.feet.forEach(f => { const s = f.side; let l = 0;
      if (Gv) l = Gv.foot(s); else if (mood === 'cheer') l = 3.5 * air; else if (mood === 'dance') l = 3.5 * ss(-X * s); else if (mood === 'happy' || (mood === 'unlock' && U > 0.34) || mood === 'idle') l = 3 * air; else if (mood === 'clean') l = 1.6 * ss(X * s);
      f.el.setAttribute('transform', l > 0.01 ? 'translate(0 ' + (-l).toFixed(2) + ')' : ''); });
    P.parts.forEach((p, i) => { if (p.kind === 'steam') { const u = ((t / 1800) + (p.side > 0 ? 0.5 : 0)) % 1; p.el.setAttribute('transform', 'translate(' + (1.5 * Math.sin(u * TAU)).toFixed(2) + ' ' + (-7 * u + 2).toFixed(2) + ') ' + p.base); p.el.style.opacity = (bump(u) * 0.95).toFixed(2); return; } p.el.setAttribute('transform', 'rotate(' + partR[i].toFixed(2) + ' ' + p.px.toFixed(1) + ' ' + p.py.toFixed(1) + ') ' + p.base); });
    if (!faceKey && P.eyes.length) {
      if (!I.blinkAt || now > I.blinkAt) { I.blinkT = now; I.dbl = Math.random() < 0.22; I.blinkAt = now + 2400 + Math.random() * 3200; }
      const bt = now - (I.blinkT || -1e9); const one = x => x < 70 ? ss(x / 70) : x < 200 ? 1 - ss((x - 70) / 130) : 0;
      const cl = Math.max(one(bt), I.dbl ? one(bt - 240) : 0);
      if (look) { if (!I.lookAt || now > I.lookAt) { I.lookAt = now + 1600 + Math.random() * 2800; I.lookTo = [-1.6, 0, 0, 1.6][Math.floor(Math.random() * 4)]; } I.lookX = (I.lookX || 0) + ((I.lookTo || 0) - (I.lookX || 0)) * Math.min(1, dt * 14); } else I.lookX = (I.lookX || 0) * 0.9;
      const tr = (Math.abs(I.lookX) > 0.02 ? 'translate(' + I.lookX.toFixed(2) + 'px,0) ' : '') + (cl > 0.01 ? 'scaleY(' + (1 - 0.92 * cl).toFixed(3) + ')' : '');
      P.eyes.forEach(e => e.style.transform = tr);
    }
    if (P.mouth.length && (I._mouthAnim || (E && !faceKey))) { const on = !!(E && !faceKey); I._mouthAnim = on; P.mouth.forEach(e => { e.style.transformBox = 'fill-box'; e.style.transformOrigin = 'center'; e.style.transform = on ? 'scale(' + (1 + 0.12 * E.mo).toFixed(3) + ',' + (1 + 0.45 * E.mo).toFixed(3) + ')' : ''; }); }
    const c = P.c; if (!c || !I.q) return; const m = c.mouth;
    if (I.chomp) { const o = E ? 0.35 + 0.65 * E.mo : 1; I.chomp.setAttribute('transform', 'translate(' + m.x + ' ' + m.y + ') scale(1 ' + o.toFixed(3) + ') translate(' + (-m.x) + ' ' + (-m.y) + ')'); }
    if (E) {
      const fo = E.food;
      if (I.food) { if (fo) { I.food.style.display = ''; I.food.setAttribute('transform', 'translate(' + fo.x.toFixed(2) + ' ' + fo.y.toFixed(2) + ') rotate(' + fo.r.toFixed(1) + ') scale(' + Math.max(0.001, fo.s).toFixed(3) + ')'); } else I.food.style.display = 'none'; }
      if (I.strand) { if (E.strand > 0.01) { const x0 = m.x, y0 = m.y + 1, x1 = m.x + 1, y1 = Math.min(82, m.y + 20) - 2, wg = 1.6 * Math.sin(t / 60); I.strand.setAttribute('d', 'M' + x0 + ' ' + y0 + ' Q' + (x0 + 3 + wg).toFixed(2) + ' ' + ((y0 + y1) / 2).toFixed(2) + ' ' + x1 + ' ' + y1); I.strand.setAttribute('stroke-dasharray', E.strand.toFixed(3) + ' 2'); I.strand.style.display = ''; } else I.strand.style.display = 'none'; }
      I.q('[data-crumb]').forEach((cr, i) => { const p = E.crumb; if (p < 0 || p >= 1) { cr.setAttribute('opacity', '0'); return; } const dir = i - 1.5; cr.setAttribute('cx', (m.x + dir * 6 * ease.out(p)).toFixed(2)); cr.setAttribute('cy', (m.y + 3 - 3 * p + 14 * p * p).toFixed(2)); cr.setAttribute('opacity', (1 - ss(p)).toFixed(2)); });
      I.q('[data-steam]').forEach((st, i) => { const p = ((t / 1800) + i * 0.5) % 1, base = fo || { x: m.x + 9, y: m.y + 4 }; st.setAttribute('transform', 'translate(' + (base.x - 2 + i * 4 + Math.sin(p * TAU) * 1.5).toFixed(2) + ' ' + (base.y - 4 - p * 9).toFixed(2) + ') scale(' + (0.5 + 0.4 * p).toFixed(2) + ')'); st.setAttribute('opacity', (E.steam && E.F.fx === 'steam' ? 0.75 * bump(p) : 0).toFixed(2)); });
      I.q('[data-juice]').forEach((d, i) => { const p = E.juice >= 0 ? clamp01(E.juice * 1.4 - i * 0.4) : -1; if (p <= 0 || p >= 1) { d.setAttribute('opacity', '0'); return; } d.setAttribute('cx', (m.x + 5 + i * 3).toFixed(2)); d.setAttribute('cy', (m.y + 6 + 16 * p * p).toFixed(2)); d.setAttribute('opacity', (1 - ss(p)).toFixed(2)); });
      if (I.burpEl) { const p = E.burp; if (p < 0) I.burpEl.setAttribute('opacity', '0'); else { I.burpEl.setAttribute('cx', (m.x + 4 + 7 * ease.out(p)).toFixed(2)); I.burpEl.setAttribute('cy', (m.y - 2 - 6 * ease.out(p)).toFixed(2)); I.burpEl.setAttribute('r', (1.5 + 4.5 * ease.out(p)).toFixed(2)); I.burpEl.setAttribute('opacity', (0.95 * (1 - ss(p))).toFixed(2)); } }
    }
    I.q('[data-tear]').forEach(e => e.setAttribute('stroke-dashoffset', (-(t / 40) % 7).toFixed(2)));
    I.q('[data-drop]').forEach((d, i) => { const e = c.eyes[i] || c.eyes[0]; const p = ((t / 900) + i * 0.5) % 1, f = p * p; d.setAttribute('cx', (e.x + (i ? 1 : -1) * (1 + p * 2)).toFixed(2)); d.setAttribute('cy', (e.y + e.r + 22 + f * 10).toFixed(2)); d.setAttribute('opacity', (1 - ss(p)).toFixed(2)); });
    I.q('[data-stink]').forEach((s, i) => { const p = ((t / 2000) + i / 3) % 1; s.setAttribute('transform', 'translate(' + ([38, 50, 62][i] + Math.sin(p * TAU) * 2).toFixed(2) + ' ' + (c.head - 2 - ease.out(p) * 12).toFixed(2) + ')'); s.setAttribute('opacity', bump(p).toFixed(2)); });
    I.q('[data-bub]').forEach((b, i) => { const p = ((t / 2400) + i / 5) % 1; b.setAttribute('cx', (26 + i * 12 + Math.sin(p * TAU + i) * 3).toFixed(2)); b.setAttribute('cy', (80 - p * 60).toFixed(2)); b.setAttribute('r', (1.5 + p * 2).toFixed(2)); b.setAttribute('opacity', (p > 0.88 ? 1 - ss((p - 0.88) / 0.12) : ss(p / 0.08)).toFixed(2)); });
    if (BS) {
      I.q('[data-bst]').forEach((b, i) => { const p = ((t / 2200) + i / 3) % 1; b.setAttribute('transform', 'translate(' + (32 + i * 13 + Math.sin(p * TAU + i) * 2).toFixed(2) + ' ' + (c.head - 2 - p * 18).toFixed(2) + ') scale(' + (0.6 + 0.5 * p).toFixed(2) + ')'); b.setAttribute('opacity', (0.8 * bump(p)).toFixed(2)); });
      const dk = I.q('[data-duck]')[0]; if (dk) dk.setAttribute('transform', 'translate(' + (78 + 3 * Math.sin(t / 900)).toFixed(2) + ' ' + (72 + 1.6 * Math.sin(t / 380)).toFixed(2) + ') rotate(' + (8 * Math.sin(t / 600)).toFixed(1) + ')');
      I.q('[data-spl]').forEach((d, i) => { const p = ((t / 700) + i / 3) % 1; d.setAttribute('cx', (30 + i * 20 + (i - 1) * 8 * p).toFixed(2)); d.setAttribute('cy', (74 - 16 * p + 22 * p * p).toFixed(2)); d.setAttribute('opacity', (p < 0.8 ? 0.9 : (1 - p) * 4.5).toFixed(2)); });
      I.q('[data-rain]').forEach((d, i) => { const p = ((t / 520) + i / 7) % 1; d.setAttribute('transform', 'translate(' + (24 + i * 8.5).toFixed(2) + ' ' + (c.head - 22 + p * 60).toFixed(2) + ')'); d.setAttribute('opacity', (0.85 * bump(p)).toFixed(2)); });
      I.q('[data-duck2]').forEach((d, i) => { const a = t / (1600 + i * 300) + i * 2.1; d.setAttribute('transform', 'translate(' + (50 + Math.cos(a) * 34).toFixed(2) + ' ' + (74 + Math.sin(a) * 4 + 1.4 * Math.sin(t / 300 + i)).toFixed(2) + ') scale(' + (Math.cos(a) < 0 ? -1 : 1) + ' 1) rotate(' + (6 * Math.sin(t / 400 + i)).toFixed(1) + ')'); });
      I.q('[data-mud]').forEach((m, i) => { const p = ((t / 6000) + i * 0.13) % 1; m.setAttribute('opacity', (0.85 * Math.min(1, p * 3) * (p > 0.92 ? (1 - p) / 0.08 : 1)).toFixed(2)); });
      I.q('[data-mdrop]').forEach((d, i) => { const p = ((t / 1100) + i / 3) % 1; d.setAttribute('cx', (bbx(I, i)).toFixed(2)); d.setAttribute('cy', (P.bb.y + P.bb.height * 0.55 + p * 30).toFixed(2)); d.setAttribute('opacity', (bump(p) * 0.9).toFixed(2)); });
      I.q('[data-sw]').forEach((d, i) => { const e = c.eyes[i] || c.eyes[0]; const p = ((t / 1600) + i / 2) % 1; d.setAttribute('cx', (e.x + (i ? 6 : -6)).toFixed(2)); d.setAttribute('cy', (e.y - 6 + p * 14).toFixed(2)); d.setAttribute('opacity', (bump(p) * 0.9).toFixed(2)); });
    }
    if (mood === 'reveal') I.q('[data-rv]').forEach((e, i) => { const ts = (T - 300) / 1300; if (ts < 0 || ts > 1) { e.setAttribute('opacity', '0'); return; } const a = i / 10 * TAU - Math.PI / 2, d = 14 + 40 * ease.out(ts); e.setAttribute('transform', 'translate(' + (50 + Math.cos(a) * d).toFixed(2) + ' ' + (52 + Math.sin(a) * d * 0.9).toFixed(2) + ') scale(' + (1.1 - 0.4 * ts).toFixed(2) + ') rotate(' + (ts * 120).toFixed(0) + ')'); e.setAttribute('opacity', (1 - ss((ts - 0.5) / 0.5)).toFixed(2)); });
    I.q('[data-spk]').forEach((s, i) => { const p = ((t / 1100) + i / 4) % 1; const a = i * 1.7 + 0.6; s.setAttribute('transform', 'translate(' + (50 + Math.cos(a) * 34).toFixed(2) + ' ' + (52 + Math.sin(a) * 32).toFixed(2) + ') scale(' + (p < 0.35 ? backOut(p / 0.35) : 1 - ss((p - 0.35) / 0.65)).toFixed(3) + ') rotate(' + (p * 90).toFixed(1) + ')'); });
    I.q('[data-eyeglow]').forEach((g, i) => { g.setAttribute('fill', TV[Math.floor(t / 900) % 4]); g.setAttribute('opacity', (0.38 + 0.18 * noise(t * 9, i + 1)).toFixed(3)); });
    if (I.glow) { I.glow.setAttribute('fill', TV[Math.floor(t / 900) % 4]); I.glow.setAttribute('opacity', (0.12 + 0.04 * noise(t * 8, 1)).toFixed(3)); }
    I.q('[data-z]').forEach((z, i) => { const p = ((t / 2600) + i / 3) % 1; z.setAttribute('x', (60 + ease.out(p) * 18 + Math.sin(p * TAU) * 3).toFixed(2)); z.setAttribute('y', (c.head + 4 - p * 22).toFixed(2)); z.setAttribute('font-size', (6 + p * 6).toFixed(2)); z.setAttribute('opacity', (p < 0.15 ? ss(p / 0.15) : 1 - ss((p - 0.15) / 0.85)).toFixed(2)); });
    I.q('[data-h]').forEach((hh, i) => { const p = ((t / 1700) + i / 2) % 1; hh.setAttribute('transform', 'translate(' + ((i ? 74 : 26) + 2 * Math.sin(p * TAU)).toFixed(2) + ' ' + (c.head + 8 - ease.out(p) * 24).toFixed(2) + ') scale(' + (p < 0.2 ? 0.8 * backOut(p / 0.2) : 0.8 + (p - 0.2) * 0.5).toFixed(3) + ')'); hh.setAttribute('opacity', (E && !E.heart ? 0 : 1 - ss((p - 0.4) / 0.6)).toFixed(2)); });
    I.q('[data-note]').forEach((nn, i) => { const p = ((t / 1500) + i / 2) % 1; nn.setAttribute('x', (i ? 76 + p * 8 : 18 - p * 8).toFixed(2)); nn.setAttribute('y', (c.head + 10 - ease.out(p) * 22).toFixed(2)); nn.setAttribute('opacity', bump(p).toFixed(2)); });
    if (mood === 'unlock' && I.box) {
      const pre = U < 0.22, e = ease.out(Math.max(0, (U - 0.22) / 0.3)), shk = pre ? 4 * Math.sin(t / 40) * ss(U / 0.22) : 0;
      I.box.setAttribute('transform', pre ? 'rotate(' + shk.toFixed(2) + ' 50 94)' : ''); I.box.setAttribute('opacity', (U < 0.5 ? 1 : Math.max(0, 1 - (U - 0.5) / 0.15)).toFixed(2));
      I.lid.setAttribute('transform', pre ? 'rotate(' + shk.toFixed(2) + ' 50 94)' : 'translate(' + (e * 18).toFixed(2) + ' ' + (-e * 50).toFixed(2) + ') rotate(' + (e * 40).toFixed(2) + ' 50 65)'); I.lid.setAttribute('opacity', pre ? '1' : Math.max(0, 1 - e * 1.4).toFixed(2));
      I.cf.forEach((r, i) => { if (pre || U > 0.8) { r.setAttribute('opacity', '0'); return; } const tau = (U - 0.22) * 3.4, a = -Math.PI / 2 + ((i * 37) % 24 - 12) / 12 * 1.2, sp2 = 40 + (i * 13) % 30, drag = 1 - Math.exp(-tau * 3); r.setAttribute('x', (50 + Math.cos(a) * sp2 * drag / 3).toFixed(2)); r.setAttribute('y', (66 + Math.sin(a) * sp2 * drag / 3 + 30 * tau * tau).toFixed(2)); r.setAttribute('opacity', Math.max(0, 1 - (U - 0.22) / 0.58).toFixed(2)); r.setAttribute('transform', 'rotate(' + (i * 40 + tau * 300).toFixed(1) + ' ' + r.getAttribute('x') + ' ' + r.getAttribute('y') + ')'); });
    }
  }
  window.PlushAnim = { scan, frame, MOODS, FOODS };
})();
