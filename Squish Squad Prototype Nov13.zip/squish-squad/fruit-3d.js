// Fruit Patch 3D kit (Nov 10, user: 'add 11 more new characters for fruit patch'). Real 3D bodies for the 11 new fruits, built on the Snack Shack kit
// (snack-3d.js: SN3D.MODELS[key] = { setup(S), draw(B, D) }, hooked into rive-generic by the sn ROUND flag; I.bk = B, B.d = the 3D silhouette).
// Most fruits are bodies of revolution made from their own art outline (REV): the silhouette keeps the art's dips (cherry / apple top, pear neck)
// because every outline point is carried to the extreme point of its ring for the current view (SIL). On the body: art decals re-projected onto the
// surface (data-k="dc", with optional copies round the back), procedural speckles / fibres / ridges that cover the WHOLE fruit (so the back is never
// blank), the stem + leaves (data-k="top") as one rigid 3D piece that sways a beat behind the moves (leaves cupped so they have depth edge-on), crowns
// (data-k="cr") rebuilt as rings of 3D sepals, and grapes / drupelets (data-k="gr") as depth-sorted 3D balls. Round fruits keep their white shine where
// the light is (it does not turn with the fruit), which is what makes a turning ball read as round. Nana (banana) is a curved tube.
// Channels: lf (0..1 leaves flutter), jig (0..1.5 grapes / drupelets jiggle), stw (-1..1 stem / crown twirl), crf (-0.5..1 crown sepals flare), cv (-1..1.2 Nana's curve:
// 0 = the art, 1 = a deep C, -1 = straight; her face height stays put), pol (0..1 Plummy's dusty bloom polished off), fz (0..1.2 Coco's fibres stand on end), rl (Blueby / Coco roll, degrees), rig (0..1 Coco keeps his shape: no squash / stretch / bend).
(function () {
  const SN = window.SN3D; if (!SN || SN.FRUIT) return; SN.FRUIT = 1;
  const M = SN.MODELS, { el, pt, polyD, polyW, circD, runs, clamp, SM, r2, rnd, subs, decD } = SN.h, TAU = Math.PI * 2;
  const SA = (e, k, v) => { if (e['_' + k] !== v) { e['_' + k] = v; e.setAttribute(k, v); } };

  // ---- body of revolution from the art outline. o.kz = depth / width, o.cx = axis x (number, or 'mid' = middle of the outline at each height) ----
  const REV = (S, o) => { const O = S.outline(S.sk, o.n || 96); let yT = 1e9, yB = -1e9; O.forEach(p => { if (p[1] < yT) yT = p[1]; if (p[1] > yB) yB = p[1]; });
    const ext = y => { let lo = 1e9, hi = -1e9; for (let i = 0; i < O.length; i++) { const a = O[i], b = O[(i + 1) % O.length]; if ((a[1] - y) * (b[1] - y) <= 0 && a[1] !== b[1]) { const x = a[0] + (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]); if (x < lo) lo = x; if (x > hi) hi = x; } } return hi < lo ? [50, 50] : [lo, hi]; };
    const N = Math.ceil((yB - yT) / 0.5), RR = [], CX = []; for (let i = 0; i <= N; i++) { const e = ext(Math.min(yB, yT + i * 0.5)); RR.push((e[1] - e[0]) / 2); CX.push((e[0] + e[1]) / 2); }
    const look = (A, y) => { const u = clamp((y - yT) / 0.5, 0, N), i = Math.min(N - 1, Math.floor(u)), f = u - i; return A[i] + (A[i + 1] - A[i]) * f; };
    const kz = o.kz || 1, cx = o.cx === 'mid' ? y => look(CX, y) : () => o.cx || 50, rT = y => look(RR, y), dr = y => rT(y + 0.5) - rT(y - 0.5);
    let rmax = 0; RR.forEach(r => { if (r > rmax) rmax = r; });
    const zAt = (x, y) => { const r = rT(y), d = x - cx(y); return d * d < r * r ? kz * Math.sqrt(r * r - d * d) : 0; };
    // point on the surface: f = angle round the axis (0 = facing you, + = to the right); returns [x, y, z, nx, ny, nz] with a unit normal
    const at = (f, y, lift) => { const r = rT(y) + (lift || 0), s = Math.sin(f), c = Math.cos(f), nx = s, nz = c / kz, ny = -dr(y), L = Math.hypot(nx, ny, nz) || 1; return [cx(y) + r * s, y, kz * r * c, nx / L, ny / L, nz / L]; };
    const fOf = (x, y) => { const r = rT(y); return Math.asin(clamp((x - cx(y)) / (r || 1), -1, 1)); };
    return { O, yT, yB, rT, cx, kz, zAt, at, fOf, rmax };
  };
  // silhouette: each outline point goes to the extreme point of its ring for the current view (exact for turning, keeps the art's dips)
  const SIL = (D, R) => { const P3 = D.P3, n = Math.max(2, Math.ceil((R.yB - R.yT) / 2.5)), st = (R.yB - R.yT) / n, G = [];
    for (let i = 0; i <= n; i++) { const y = R.yT + i * st, cx = R.cx(y), c = P3(cx, y, 0), e1 = P3(cx + 1, y, 0), e2 = P3(cx, y, R.kz), a = P3(cx, y + 1, 0);
      const E1x = e1[0] - c[0], E1y = e1[1] - c[1], E2x = e2[0] - c[0], E2y = e2[1] - c[1], Ax = a[0] - c[0], Ay = a[1] - c[1], L = Math.hypot(Ax, Ay) || 1, nx = Ay / L, ny = -Ax / L;
      const an = Math.atan2(nx * E2x + ny * E2y, nx * E1x + ny * E1y), ca = Math.cos(an), sa = Math.sin(an); G.push([c[0], c[1], E1x * ca + E2x * sa, E1y * ca + E2y * sa]); }
    return polyD(R.O.map(p => { const u = clamp((p[1] - R.yT) / st, 0, n), i = Math.min(n - 1, Math.floor(u)), f = u - i, A = G[i], B = G[i + 1], d = p[0] - R.cx(p[1]), q = k => A[k] + (B[k] - A[k]) * f;
      return [q(0) + d * q(2), q(1) + d * q(3)]; })); };
  // "seen a touch from above" for flat parts on top (crowns): nearer points sit lower, measured from the axis
  const PEL = (D, EL, ax, ay) => (x, y, z) => { const p = D.P3(x, y, z); return [p[0], p[1] + EL * (D.Z3(x, y, z) - D.Z3(ax, ay, 0))]; };
  const fade = (f, a, w) => SM((f - a) / w);
  // rolling (rl, degrees; Blueby, Coco): rive-generic turns the whole drawing about the middle (cy) and lifts / drops it so the lowest point stays on the
  // ground (same maths as Sunny's)
  const ROLLF = (R, cy0) => { const OS = R.O.filter((p, i) => i % 3 === 0); return (a, P, G, sy) => { const c = Math.cos(a), s = Math.sin(a), lf = +P.lift || 0, px = +P.x || 0, cx = 50 + px, cy = G - lf - (G - cy0) * sy; let my = -1e9;
    OS.forEach(p => { const gx = p[0] + px, gy = G - lf - (G - p[1]) * sy, y = cy + (gx - cx) * s + (gy - cy) * c; if (y > my) my = y; }); return { c, s, cx, cy, up: my - (G - lf) }; }; };

  // ---- art decals on the surface (front, plus copies turned round the axis by dA, e.g. [0, PI] = a matching mark on the back) ----
  const DECS = (S, R, pred, copies, par) => { const out = []; S.decals(pred, par).forEach(o => { let sx = 0, sy = 0, n = 0; o.L.forEach(L => L.forEach(p => { sx += p[0]; sy += p[1]; n++; }));
      const c = [sx / (n || 1), sy / (n || 1)], op = +(o.e.getAttribute('opacity') || 1), line = (o.e.getAttribute('fill') || '') === 'none';
      (copies || [0]).forEach((dA, i) => { const e = i ? o.e.parentNode.insertBefore(o.e.cloneNode(), o.e.nextSibling) : o.e; out.push({ e, L: o.L, c, op, dA, line }); }); }); return out; };
  const decDraw = (D, R, list) => list.forEach(o => { const f0 = R.fOf(o.c[0], o.c[1]) + o.dA, s = R.at(f0, o.c[1]), v = fade(D.facing(s[0], s[1], s[2], s[3], s[4], s[5]), 0.02, 0.28);
    if (v < 0.01) { if (o.on !== 0) { o.on = 0; o.e.setAttribute('opacity', 0); } return; } o.on = 1; SA(o.e, 'opacity', r2(o.op * v));
    const map = (x, y) => { const p = R.at(R.fOf(x, y) + o.dA, y, 0.12); return D.P3(p[0], p[1], p[2]); };
    if (o.line) { let d = ''; o.L.forEach(L => { const Q = [], ok = []; L.forEach(([x, y]) => { const p = R.at(R.fOf(x, y) + o.dA, y, 0.12); Q.push(D.P3(p[0], p[1], p[2])); ok.push(D.facing(p[0], p[1], p[2], p[3], p[4], p[5]) > 0.03); }); d += runs(Q, ok); }); o.e.setAttribute('d', d || 'M0 0'); }
    else o.e.setAttribute('d', decD(o, map)); });
  // a decal that stays where the light is (soft bloom / shine): mapped with the body's 2D motion only, never turned
  const FIX = (S, pred, par) => S.decals(pred, par).map(o => o);
  const fixDraw = (D, list) => list.forEach(o => o.e.setAttribute('d', decD(o, (x, y) => D.glob(x, y))));
  const SHINE = S => S.hide(q => q.role === 'shine' && !q.inBody).map(q => { const e = el('path', { fill: q.e.getAttribute('fill') || '#fff', opacity: q.e.getAttribute('opacity') || 0.85 }, q.e.parentNode, q.e); return { e, L: subs(q.segs, 8) }; });

  // ---- procedural marks all round the fruit (never under the face): dots, fibres, ridges ----
  const SCAT = (R, n, seed, min, avoid) => { const out = []; for (let k = 0; out.length < n && k < n * 60; k++) { const y = R.yT + 2.5 + rnd(seed + k * 1.31) * (R.yB - R.yT - 5), f = (rnd(seed + k * 2.77) * 2 - 1) * Math.PI;
      if (rnd(seed + k * 5.13) > R.rT(y) / R.rmax) continue; if (avoid && avoid(f, y)) continue; const p = R.at(f, y); if (out.some(q => Math.hypot(q.p[0] - p[0], q.p[1] - p[1], q.p[2] - p[2]) < min)) continue; out.push({ f, y, p, k: rnd(seed + k * 7.7) }); } return out; };
  const faceAvoid = (y0, y1, fw) => (f, y) => Math.abs(f) < (fw || 0.72) && y > y0 && y < y1;
  const dotsDraw = (D, R, o) => { let d = ''; const r = o.r * D.kS; o.P.forEach(s => { const p = R.at(s.f, s.y, 0.1); if (D.facing(p[0], p[1], p[2], p[3], p[4], p[5]) < 0.1) return; d += circD(D.P3(p[0], p[1], p[2]), r * (0.8 + s.k * 0.4)); }); SA(o.e, 'd', d || 'M0 0'); };
  const fibDraw = (D, R, o) => { let d = ''; const fz = clamp(D.bv('fz'), 0, 1.3); o.P.forEach(s => { const p = R.at(s.f, s.y, 0.1); if (D.facing(p[0], p[1], p[2], p[3], p[4], p[5]) < 0.12) return; const a = s.k * TAU, L = (1.8 + s.k * 1.2) * (1 - fz * 0.25), q = R.at(s.f + Math.cos(a) * L / Math.max(4, R.rT(s.y)), s.y + Math.sin(a) * L, 0.1 + fz * (1.6 + s.k * 1.4));
      d += 'M' + pt(D.P3(p[0], p[1], p[2])) + 'L' + pt(D.P3(q[0], q[1], q[2])); }); SA(o.e, 'd', d || 'M0 0'); };
  const ridgeDraw = (D, R, o) => { let d = ''; o.F.forEach(f => { const Q = [], ok = []; for (let y = o.y0; y <= o.y1; y += 1.5) { const p = R.at(f, y, 0.05); Q.push(D.P3(p[0], p[1], p[2])); ok.push(D.facing(p[0], p[1], p[2], p[3], p[4], p[5]) > 0.12); } d += runs(Q, ok); }); SA(o.e, 'd', d || 'M0 0'); };

  // ---- stem + leaves: one rigid piece in 3D, pivoting at its base (ax, ay); leaves cupped (z = curl * across^2) so they keep some width edge-on ----
  const TOPS = (S, o) => { const G = S.g(), L = S.decals(q => S.dk(q, 'top'), G).map(d => { if (/^url\(#l/.test(d.e.getAttribute('fill') || '')) { const b = d.L[0][0]; let tp = b, md = 0; d.L.forEach(Q => Q.forEach(p => { const m = Math.hypot(p[0] - b[0], p[1] - b[1]); if (m > md) { md = m; tp = p; } })); d.leaf = { b, tp, L: md || 1 }; } return d; }); let n = 0; L.forEach(d => { if (d.leaf) d.leaf.ro = (o.roll == null ? 0.5 : o.roll) * (n++ % 2 ? -1 : 1) * (d.leaf.tp[0] < d.leaf.b[0] ? -1 : 1); }); return { G, L, o }; };
  const topDraw = (D, T) => { const o = T.o, lf = clamp(D.bv('lf'), 0, 1.2), tw = clamp(D.bv('stw'), -1, 1), th = clamp(-D.ox * 0.045, -0.5, 0.5) + (o.wob == null ? 0.035 : o.wob) * Math.sin(D.ts * 1.6) + lf * 0.2 * Math.sin(D.ts * 14), c = Math.cos(th), s = Math.sin(th), tc = Math.cos(tw * Math.PI), ts = Math.sin(tw * Math.PI);
    T.L.forEach(d => { const lv = d.leaf, fl = lv ? lf * 0.6 * Math.sin(D.ts * 17 + lv.b[0]) : 0; d.e.setAttribute('d', decD(d, (x, y) => { let z = 0;
      if (lv) { const vx = lv.tp[0] - lv.b[0], vy = lv.tp[1] - lv.b[1], w = ((x - lv.b[0]) * vy - (y - lv.b[1]) * vx) / lv.L, u = ((x - lv.b[0]) * vx + (y - lv.b[1]) * vy) / (lv.L * lv.L), ro = lv.ro, k = 1 - Math.cos(ro);
        x -= w * vy / lv.L * k; y += w * vx / lv.L * k; z = w * Math.sin(ro) + (o.curl || 0.12) * w * w + (o.lz || 0) * u + fl * u * u * 3; }
      let dx = x - o.ax, dy = y - o.ay; const X = dx * c - dy * s, Y = dx * s + dy * c, xx = X * tc - z * ts, zz = X * ts + z * tc; return D.P3(o.ax + xx, o.ay + Y, zz + (o.z || 0)); })); }); };

  // ---- the fruit model: a REV body + any of the pieces above, plus own extra(setup / draw) ----
  const FRUIT = cfg => ({
    setup(S) { const R = REV(S, cfg), B = { R, cfg, rT: R.rT, zAt: R.zAt, rx: cfg.rx || 30, ya: R.yT + 5, yb: R.yB - 2, zE: (dx, dy) => { const y = S.HY + dy, fy = cfg.fy || y, d = y - fy; return R.zAt(S.HX + dx, fy) - d * d / 60 + 0.3; } };
      if (cfg.hide) S.hide(cfg.hide);
      B.dc = cfg.dc ? DECS(S, R, q => S.dk(q, 'dc') && cfg.dc.pred(q), cfg.dc.copies) : [];
      if (cfg.dc && cfg.dc.drop) S.hide(q => S.dk(q, 'dc'));
      B.fx = cfg.fix ? FIX(S, q => S.dk(q, 'dc') && cfg.fix(q)) : [];
      if (cfg.spk) B.spk = { P: SCAT(R, cfg.spk.n, cfg.spk.seed || 3, cfg.spk.min || 4, cfg.face && faceAvoid(cfg.face[0], cfg.face[1])), r: cfg.spk.r || 0.55, e: S.path({ fill: cfg.spk.c, opacity: cfg.spk.op || 0.7 }) };
      if (cfg.fib) B.fib = { P: SCAT(R, cfg.fib.n, cfg.fib.seed || 7, cfg.fib.min || 3.6, cfg.face && faceAvoid(cfg.face[0], cfg.face[1])), e: S.path({ fill: 'none', stroke: cfg.fib.c, 'stroke-width': cfg.fib.w || 0.55, 'stroke-linecap': 'round', opacity: cfg.fib.op || 0.6 }) };
      if (cfg.ridge) B.rdg = Object.assign({ e: S.path({ fill: 'none', stroke: cfg.ridge.c, 'stroke-width': cfg.ridge.w || 1.1, 'stroke-linecap': 'round', opacity: cfg.ridge.op || 0.3 }) }, cfg.ridge);
      if (cfg.extra) cfg.extra.setup(S, B, R);
      B.top = cfg.top ? TOPS(S, cfg.top) : (S.hide(q => S.dk(q, 'top')), null);
      B.sh = cfg.shine === 'fix' ? SHINE(S) : null;
      return B; },
    draw(B, D) { const R = B.R; B.d = SIL(D, R);
      decDraw(D, R, B.dc); if (B.fx.length) fixDraw(D, B.fx); if (B.spk) dotsDraw(D, R, B.spk); if (B.fib) fibDraw(D, R, B.fib); if (B.rdg) ridgeDraw(D, R, B.rdg);
      if (B.cfg.extra) B.cfg.extra.draw(B, D, R); if (B.top) topDraw(D, B.top); if (B.sh) fixDraw(D, B.sh); }
  });
  const isTag = t => q => q.tag === t;

  // ---- crowns ----
  // sepal ring: n sepals round the axis at height y, each a kite from the centre out to its tip (radius R, raised by up), seen a touch from above
  const SEPALS = (S, fill, n, ph, par) => Array.from({ length: n }, (_, i) => ({ a: ph + i * TAU / n, id: 's' + i, e: el('path', { fill }, par) }));
  const sepalDraw = (D, list, P, o) => { const cf = clamp(D.bv('crf'), -0.5, 1.2), up0 = o.up; o = Object.assign({}, o, { R: o.R * (1 + 0.28 * cf), up: up0 * (1 - 0.55 * cf) + (cf < 0 ? -cf * 3 : 0) }); const L = list.map(s => { const a = s.a + o.spin, w = o.w, R = o.R, tip = [50 + R * Math.cos(a), o.y - o.up, R * Math.sin(a)], c1 = [50 + o.r0 * Math.cos(a - w), o.y, o.r0 * Math.sin(a - w)], c2 = [50 + o.r0 * Math.cos(a + w), o.y, o.r0 * Math.sin(a + w)],
      m = o.mid || 0.5, s1 = [50 + R * m * Math.cos(a - w * 0.55), o.y - o.up * m * 0.6, R * m * Math.sin(a - w * 0.55)], s2 = [50 + R * m * Math.cos(a + w * 0.55), o.y - o.up * m * 0.6, R * m * Math.sin(a + w * 0.55)], C = [50, o.y + (o.dip || 0), 0];
      s.e.setAttribute('d', polyW([C, c1, s1, tip, s2, c2].map(p => P(p[0], p[1], p[2])))); return { id: s.id, e: s.e, z: D.Z3(tip[0], tip[1], tip[2]) }; }).sort((a, b) => a.z - b.z); return L; };

  // ================= Bing: a glossy cherry. Round body from the art (the dip at the stem stays from every side), the long stem + leaf in 3D, the faint
  // suture line down his front turns with him, the shine stays where the light is.
  M.bing = FRUIT({ fy: 62, shine: 'fix', rx: 32, top: { ax: 50, ay: 34.8, curl: 0.14 } });   // Nov 10: stem grows out of the dip, the root-like suture line is gone (user)

  // ================= Clemmy: a clementine, peel pores all round (never on her face), the nub + two leaves in 3D.
  M.clemmy = FRUIT({ fy: 63, shine: 'fix', rx: 33, dc: { pred: () => false, drop: 1 }, face: [52, 73], spk: { n: 120, c: '#e2701a', op: 0.6, r: 0.55, min: 4.2, seed: 4 }, top: { ax: 50, ay: 36.4, curl: 0.14 } });   // Nov 10: leaves sit on her top (they floated)

  // ================= Appy: a crisp green apple. Rosy blush on her right cheek side and a matching one round the back, pale lenticels all round,
  // the cavity at the stem drawn as the near rim of a ring seen a touch from above (the same from every side), stem + leaf in 3D.
  M.appy = FRUIT({ fy: 62, shine: 'fix', rx: 33, dc: { pred: isTag('ellipse'), copies: [0, 2.6] }, hide: q => inDc(q) && q.tag !== 'ellipse', face: [51, 71], spk: { n: 26, c: '#f2ffd0', op: 0.8, r: 0.5, min: 7, seed: 5 },
    top: { ax: 50, ay: 33, curl: 0.14 },
    extra: { setup(S, B) { B.cav = S.path({ fill: 'none', stroke: '#4e8a26', 'stroke-width': 1.2, 'stroke-linecap': 'round', opacity: 0.45 }); },
      draw(B, D, R) { const P = PEL(D, 0.3, 50, 34.5), Q = SN.h.frontArc(D, 6, 34.5, 48).map(f => P(50 + 6 * Math.sin(f), 34.5, 6 * Math.cos(f))); SA(B.cav, 'd', Q.length > 1 ? runs(Q, Q.map(() => true)) : 'M0 0'); } } });

  // ================= Blueby: a blueberry with its little star crown: 5 sepals in a ring on her flat top (3D, seen a touch from above like the art) round the
  // dark centre; the waxy bloom stays where the light is.
  M.blueby = FRUIT({ fy: 63, shine: 'fix', rx: 33, fix: () => true,
    extra: { setup(S, B, R) { const cr = S.hide(q => S.dk(q, 'cr')), st = cr.find(q => q.tag === 'path'), F = st ? S.f(st) : '#3a4296'; B.CG = S.g(); B.sep = SEPALS(S, F, 5, -Math.PI / 2, B.CG); B.hole = el('path', { fill: '#26296a' }, B.CG);
        B.roll = ROLLF(R, 61); },
      draw(B, D) { const spin = clamp(D.bv('stw'), -1, 1) * Math.PI * 0.4, P = PEL(D, 0.45, 50, 38.3), L = sepalDraw(D, B.sep, P, { y: 38.3, R: 12.5, r0: 4.6, w: 0.62, up: 1.6, spin, mid: 0.45 }); // Nov 10: on her top (it floated at 34.2)
        SN.order(B.CG, L.concat([{ id: 'h', e: B.hole }])); B.hole.setAttribute('d', polyW(Array.from({ length: 20 }, (_, k) => { const f = k / 20 * TAU; return P(50 + 4.2 * Math.cos(f), 38, 4.2 * Math.sin(f)); }))); } } });

  // ================= Coco: a hairy coconut. Fibres all round (short strokes in every direction, never on his face), the three dark eyes near the top turn with
  // him. (The little sprout on top was removed, user: 'why does coco have a green leaf on top of him?')
  M.coco = FRUIT({ fy: 61, shine: 'fix', rx: 33, dc: { pred: isTag('circle') }, hide: q => inDc(q) && q.tag === 'path', face: [50, 71], fib: { n: 150, c: '#5a3820', op: 0.6, w: 0.55, min: 3.4, seed: 7 },
    extra: { setup(S, B, R) { B.roll = ROLLF(R, 59);
        // rig (0..1, user: 'in the dance, the coconut shape should not change'): a hard nut - no squash / stretch / bend / shear (the soft-body jelly and the
        // motion stretch included); a lean becomes a rigid tilt. rive-generic calls I.bk.pre(P) before it builds the frame.
        B.pre = P => { const k = clamp(+P.rig || 0, 0, 1); if (k < 0.01) return P; if (k > 0.5) S.I.ms = null;
          return Object.assign({}, P, { sq: (+P.sq || 0) * (1 - k), bend: (+P.bend || 0) * (1 - k), lean: (+P.lean || 0) * (1 - k), tilt: (+P.tilt || 0) + (+P.lean || 0) * 0.8 * k }); }; },
      draw() {} } }); // v2: no sprout, v3: no legs - he rolls, rigid in his dance (user)

  // ================= Perry v2 (user: 'perry looks terrible' - v1 was a bell with a flat skirt): a chubby plush pear, a big round bulb + a smaller round top joined by
  // a soft waist (the art outline, kept by SIL), freckles all round, a soft blush on the right + one round the back, stem + leaf in 3D.
  M.perry = FRUIT({ fy: 65, shine: 'fix', rx: 30, dc: { pred: isTag('ellipse'), copies: [0, 2.8] }, hide: q => inDc(q) && q.tag === 'circle', face: [54, 74], spk: { n: 70, c: '#8a9a3a', op: 0.65, r: 0.5, min: 5, seed: 9 },
    top: { ax: 50, ay: 27, curl: 0.14 } });

  // ================= Grana: a pomegranate. Six soft ridges run down him (lines where they face you), the royal crown is a short neck with a dark opening
  // and six pointed sepals round its rim (3D, the back ones behind the neck).
  M.grana = FRUIT({ fy: 63, shine: 'fix', rx: 33, dc: { pred: () => false, drop: 1 }, ridge: { F: [-5, -3, -1, 1, 3, 5].map(k => k * Math.PI / 6), y0: 40, y1: 84, c: '#a81e2e', op: 0.3, w: 1.1 },
    extra: { setup(S, B) { const cr = S.hide(q => S.dk(q, 'cr')), F = cr.length ? S.f(cr[0]) : '#b02a34'; B.CG = S.g(); B.neck = el('path', { fill: F }, B.CG); B.open = el('path', { fill: '#5a0e18' }, B.CG); B.rim = el('path', { fill: 'none', stroke: '#e86a6a', 'stroke-width': 0.6, opacity: 0.6 }, B.CG); B.sep = SEPALS(S, F, 6, -Math.PI / 2 + Math.PI / 6, B.CG); },
      draw(B, D) { const P = PEL(D, 0.3, 50, 31), ring = (r, y) => Array.from({ length: 24 }, (_, k) => { const f = k / 24 * TAU; return P(50 + r * Math.cos(f), y, r * Math.sin(f)); }), spin = clamp(D.bv('stw'), -1, 1) * Math.PI * 0.35;
        B.neck.setAttribute('d', D.hull(ring(7.4, 36).concat(ring(6.1, 31)))); B.open.setAttribute('d', polyW(ring(4.6, 30.9))); B.rim.setAttribute('d', polyW(ring(6.1, 31)));
        const L = sepalDraw(D, B.sep, P, { y: 31, R: 9.6, r0: 4.2, w: 0.42, up: 7, spin, mid: 0.5, dip: 0 }), bk = L.filter(o => o.z < 0), fr = L.filter(o => o.z >= 0);
        SN.order(B.CG, bk.concat([{ id: 'n', e: B.neck }, { id: 'o', e: B.open }, { id: 'r', e: B.rim }], fr)); } } });

  // ================= Mangie: a ripe mango (kidney-shaped: its axis follows the middle of the outline, a touch flatter front to back). Her sunset blush and
  // green shoulder are on the front and again round the back, sun freckles all round, stem + leaf in 3D.
  // v2 (user: 'mangie doesn't look like a mango' - v1 was a round orange ball): a tall kidney-shaped mango leaning a touch to the right (cx 'mid' = a curved
  // axis), a little flatter front to back (kz .85); green round the stem + down her left side and a red blush on the right shoulder (both turn with her, a
  // copy round the back), pale lenticel dots all round; a short stem + one long mango leaf.
  M.mangie = FRUIT({ fy: 61, shine: 'fix', rx: 30, kz: 0.85, cx: 'mid', dc: { pred: isTag('ellipse'), copies: [0, Math.PI] }, hide: q => inDc(q) && q.tag === 'circle', face: [50, 70], spk: { n: 30, c: '#fff6c8', op: 0.7, r: 0.5, min: 6.5, seed: 13 },
    top: { ax: 47.6, ay: 30.6, curl: 0.12 } });

  // ================= Razzy: a raspberry. Every drupelet is a 3D ball sitting on the berry all the way round (depth-sorted pool, lit from the upper left), so her
  // outline is bumpy from every side; the calyx is a ring of six sepals on top with a little stalk.
  // v2 (user: 'what is razzy supposed to be? he does not look like a raspberry'): the berry is a rounded thimble (broad domed top, tapering to a round tip)
  // and the drupelets are BIG (r 4.25, rows 6.3 apart, ~8.2 round) and deep raspberry red, sunk 1.6 into the berry so the outline is bumpy; they keep clear
  // of the eyes + mouth (tested where they land seen from the front); the calyx sits on the top (y 31).
  M.razzy = FRUIT({ fy: 59, shine: 'fix', rx: 30, dc: { pred: () => false, drop: 1 },
    extra: { setup(S, B, R) { const gr = S.hide(q => S.dk(q, 'gr')), GF = gr.length ? S.f(gr[0]) : '#ec3a6c', cr = S.hide(q => S.dk(q, 'cr')), CF = (cr.find(q => q.tag === 'path') || {}).e ? S.f(cr.find(q => q.tag === 'path')) : '#6ab83a';
        const DR = [], nf = (f, y) => { if (Math.cos(f) < 0.3) return false; const x = 50 + (R.rT(y) - 1.6) * Math.sin(f); return Math.hypot(x - 40, y - 56) < 5.6 || Math.hypot(x - 60, y - 56) < 5.6 || Math.hypot(x - 50, y - 63.5) < 4.2; };
        let row = 0; for (let y = 34.5; y < 87; y += 6.3, row++) { const r = Math.max(0, R.rT(y) - 1.6), n = Math.max(1, Math.round(TAU * r / 8.2)); for (let i = 0; i < n; i++) { const f = (i + (row % 2) * 0.5 + (rnd(y * 3 + i) - 0.5) * 0.2) / n * TAU, yy = y + (rnd(y * 5 + i) - 0.5) * 1.2; if (!nf(f, yy)) DR.push({ f, y: yy, s: (0.93 + rnd(y + i * 1.7) * 0.12) * (y > 82 ? 0.8 : 1) }); } }
        B.DR = DR; B.DG = S.g(); B.pool = DR.map(() => el('path', { fill: GF, d: 'M0 0' }, B.DG)); B.CG = S.g(); B.stalk = el('path', { fill: '#5a9a2a' }, B.CG); B.sep = SEPALS(S, CF, 6, -Math.PI / 2, B.CG); },
      draw(B, D, R) { const jg = clamp(D.bv('jig'), 0, 1.5), L = [], rr = 4.25 * D.kS;
        B.DR.forEach((o, i) => { const j = jg * 0.5 * Math.sin(D.ts * 19 + i * 1.3), p = R.at(o.f, o.y, -1.6 + j); const fz = D.facing(p[0], p[1], p[2], p[3], p[4], p[5]); if (fz < -0.15) return; L.push({ c: D.P3(p[0], p[1], p[2]), z: D.Z3(p[0], p[1], p[2]), s: o.s }); });
        L.sort((a, b) => a.z - b.z); B.pool.forEach((e, i) => { const o = L[i]; SA(e, 'd', o ? circD(o.c, rr * o.s) : 'M0 0'); });
        const P = PEL(D, 0.38, 50, 31), spin = clamp(D.bv('stw'), -1, 1) * Math.PI * 0.4; B.stalk.setAttribute('d', SN.h.tubeD(D, [[50, 31.1, 0], [50, 27.3, 0], [50.3, 23.6, 0]], [1.05, 1, 0.95]));
        SN.order(B.CG, sepalDraw(D, B.sep, P, { y: 31, R: 12, r0: 2.6, w: 0.5, up: 1.4, spin, mid: 0.5 }).concat([{ id: 'st', e: B.stalk }])); } } });

  // ================= Nana: a banana standing up - a curved tube (rings square to its own centre line, so it keeps its curve and thickness from every side),
  // five ridges round it (lines where they face you), the brown stalk on top and the dark blossom tip at the bottom are 3D too.
  const NTF = Math.sin(Math.PI * 0.553), NC = (t, cv) => [63 - 8 * t - 12 * (1 + (cv || 0)) * Math.sin(Math.PI * t) + 12 * (cv || 0) * NTF, 12 + 76 * t], NW = t => 3 + 15.5 * Math.pow(Math.sin(Math.PI * clamp((t - 0.02) / 0.96, 0, 1)), 0.55);
  const NT = (t, cv) => { const dx = -8 - 12 * (1 + (cv || 0)) * Math.PI * Math.cos(Math.PI * t), dy = 76, L = Math.hypot(dx, dy); return [dx / L, dy / L]; };
  M.nana = {
    setup(S) { const KZ = 0.9; S.hide(q => S.dk(q)); const ST = S.rgrad('nst', [[0, '#b8905a'], [0.6, '#7a5a2a'], [1, '#4a3418']]);
      const zAt = (x, y) => { const t = clamp((y - 12) / 76, 0, 1), c = NC(t), T = NT(t), w = NW(t), d = (x - c[0]) * T[1]; return d * d < w * w ? KZ * Math.sqrt(w * w - d * d) : 0; };
      const rd = S.path({ fill: 'none', stroke: '#d9a820', 'stroke-width': 0.9, 'stroke-linecap': 'round', opacity: 0.6 }), sk = el('path', { fill: ST }, S.LG), skC = el('path', { fill: '#4a3418' }, S.LG), tip = S.path({ fill: '#6a4a24' });
      return { KZ, rd, sk, skC, tip, rx: 24, ya: 20, yb: 86, rT: y => { const t = clamp((y - 12) / 76, 0, 1); return NW(t) / Math.max(0.5, NT(t)[1]); }, zAt, zE: (dx, dy) => zAt(S.HX + dx, S.HY + dy) + 0.3 }; },
    draw(B, D) { const { P3 } = D, KZ = B.KZ, n = 30, Rt = [], Lt = [], cv = clamp(D.bv('cv'), -1, 1.2), ring = t => { const c = NC(t, cv), T = NT(t, cv), N = [T[1], -T[0]], w = NW(t); return { c: [c[0], c[1], 0], N: [N[0], N[1], 0], T: [T[0], T[1], 0], w }; };
      const ext = g => { const c = P3(g.c[0], g.c[1], 0), e1 = P3(g.c[0] + g.N[0], g.c[1] + g.N[1], 0), e2 = P3(g.c[0], g.c[1], KZ), a = P3(g.c[0] + g.T[0], g.c[1] + g.T[1], 0), E1 = [e1[0] - c[0], e1[1] - c[1]], E2 = [e2[0] - c[0], e2[1] - c[1]], A = [a[0] - c[0], a[1] - c[1]], L = Math.hypot(A[0], A[1]) || 1, nx = A[1] / L, ny = -A[0] / L;
        const an = Math.atan2(nx * E2[0] + ny * E2[1], nx * E1[0] + ny * E1[1]), V = [E1[0] * Math.cos(an) + E2[0] * Math.sin(an), E1[1] * Math.cos(an) + E2[1] * Math.sin(an)]; return { c, V, A: [A[0] / L, A[1] / L] }; };
      const G = []; for (let i = 0; i <= n; i++) G.push(ext(ring(i / n)));
      G.forEach((g, i) => { const w = NW(i / n); Rt.push([g.c[0] + g.V[0] * w, g.c[1] + g.V[1] * w]); Lt.push([g.c[0] - g.V[0] * w, g.c[1] - g.V[1] * w]); });
      // round end caps: half circles of the ring's screen size, bulging along the tube (up at the stalk end, down at the tip)
      const cap = (g, w, sg, rev) => { const vl = Math.hypot(g.V[0], g.V[1]) || 1, r = vl * w, vx = g.V[0] / vl, vy = g.V[1] / vl, o = []; for (let k = 1; k < 8; k++) { const a = (rev ? 8 - k : k) / 8 * Math.PI; o.push([g.c[0] + r * (vx * Math.cos(a) + sg * g.A[0] * Math.sin(a)), g.c[1] + r * (vy * Math.cos(a) + sg * g.A[1] * Math.sin(a))]); } return o; };
      B.d = polyD(Rt.concat(cap(G[n], NW(1), 1, 0), Lt.reverse(), cap(G[0], NW(0), -1, 1)));
      // ridges: five round the tube (front pair, back pair, straight back)
      let rd = ''; [-0.63, 0.63, -1.9, 1.9, Math.PI].forEach(f => { const Q = [], ok = []; for (let i = 2; i <= 27; i++) { const g = ring(i / n), sf = Math.sin(f), cf = Math.cos(f), x = g.c[0] + g.w * g.N[0] * sf, y = g.c[1] + g.w * g.N[1] * sf, z = g.w * KZ * cf;
        Q.push(P3(x, y, z)); ok.push(D.facing(x, y, z, g.N[0] * sf, g.N[1] * sf, cf / KZ) > 0.1); } rd += runs(Q, ok); }); SA(B.rd, 'd', rd || 'M0 0');
      // stalk (a tapered tube a beat behind the moves) + the dark blossom tip
      const sw = clamp(-D.ox * 0.08, -0.6, 0.6) + (NT(0, cv)[0] - NT(0, 0)[0]) * 0.6, dx0 = NC(0.033, cv)[0] - NC(0.033, 0)[0], C0 = [63.1 + dx0, 14.6, 0], C1 = [63.6 + dx0 + sw * 2, 9.6, 0], C2 = [64.4 + dx0 + sw * 4.5, 5, 0];
      B.sk.setAttribute('d', SN.h.tubeD(D, [C0, C1, C2], [2.5, 2.2, 1.95])); B.skC.setAttribute('d', circD(P3(C2[0], C2[1] - 0.6, 0), 1.75 * D.kS));
      const e = NC(0.985, cv); B.tip.setAttribute('d', circD(P3(e[0], e[1], 0), 2.7 * D.kS)); }
  };

  // ================= Plummy (Nov 10, user: 'he looks strange, please change the character' -> a plum replaced Grapey, same id 109): a round deep-purple plum.
  // The seam (suture) down his right side turns with him; pale lenticel dots all round (never on his face); the dusty BLOOM is a pale haze that stays where
  // the light is, and 'pol' (0..1) polishes it off - he goes glossy deep purple - and it comes back as pol returns to 0. Stem + leaf in 3D.
  M.plummy = FRUIT({ fy: 62, shine: 'fix', rx: 31, dc: { pred: isTag('path') }, fix: isTag('ellipse'), hide: q => inDc(q) && q.tag === 'circle', face: [51, 72],
    spk: { n: 55, c: '#ead0f0', op: 0.5, r: 0.45, min: 5.5, seed: 11 }, top: { ax: 50, ay: 32, curl: 0.14 },
    extra: { setup(S, B) { B.bloom = B.fx.map(o => ({ e: o.e, op: +(o.e.getAttribute('opacity') || 1) })); B.gl = S.path({ fill: '#ffffff', opacity: 0 }); },
      draw(B, D) { const p = clamp(D.bv('pol'), 0, 1); B.bloom.forEach(b => b.e.setAttribute('opacity', r2(b.op * (1 - 0.92 * p))));
        if (p < 0.02) { if (B.glOn !== 0) { B.glOn = 0; SA(B.gl, 'opacity', 0); } return; } B.glOn = 1;
        // polished: a glossy glint along his upper right rim (stays where the light is, like the shine)
        const Q = [], N = 14, A = u => (40 + 62 * u) * Math.PI / 180;
        for (let i = 0; i <= N; i++) { const a = A(i / N); Q.push(D.glob(50 + 28 * Math.sin(a), 60 - 27 * Math.cos(a))); }
        for (let i = N; i >= 0; i--) { const u = i / N, a = A(u), k = 28 - 3 * Math.sin(Math.PI * u); Q.push(D.glob(50 + k * Math.sin(a), 60 - (k - 1) * Math.cos(a))); }
        SA(B.gl, 'd', polyW(Q)); SA(B.gl, 'opacity', r2(0.6 * p)); } } });
  // 'in the dc decal group' test usable inside a config (before S exists)
  function inDc(q) { return !!(q.e.closest && q.e.closest('[data-k="dc"]')); }
})();
