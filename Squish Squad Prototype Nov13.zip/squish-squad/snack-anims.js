// Snack Shack personalities (Nov 9, user: 'now, i want us to do what we did with petshop to the snack shack').
// The nine snacks are solid 3D foods with the face on them (head = body: the rig's 'whole' flag), so the Pet Shop recipe is translated:
//   - a head turn = the FACE leads a little (hyaw slides it round the surface first), then the WHOLE snack turns after it (turn), along a dipping
//     arc (a soft squash = the dip, a small rise at the overshoot), settles; the weight shifts (bend toward the look side), the paws trail, the
//     soft-body layer (SOFT) adds the jelly follow-through;
//   - personality cards flavour the shared moves; hand-made happy / surprised / squish / habit / squeeze reaction use each snack's own parts
//     (melt, split, slurp, swirl ...). Their signature dances already exist (rive-generic) and are kept.
// pitch: NEGATIVE = head down (the rig's convention).
(function boot() {
  const R = window.RiveRig; if (!R || !R.PETLIB || !R.PETLIB.install || !R.SOFT) { setTimeout(boot, 25); return; } if (R.snackV) return; R.snackV = 1;
  const { TL, S, hand, both, o, NOHANDS, jump, shake, swing, steps, jelly, land, install } = R.PETLIB;
  const KEYS = ['mallow', 'bao', 'dunkie', 'frybo', 'bunbun', 'choco', 'scoop', 'boba', 'chefbun'];
  KEYS.forEach(k => R.SOFT.add(k)); // soft-body follow-through for every snack

  // ---------- the natural look, snack version ----------
  // k = how far the snack turns (1 = 24 deg + a 7 deg face lead), d = the dip (squash), b = the weight shift (bend degrees)
  const natF = (k, J) => { J = J || {}; const t = TL(), dip = J.dip == null ? 0.045 : J.dip, bw = J.bend == null ? 5 : J.bend, lead = 0.18 * k;
    const turn = (T, from, to, d1, d2) => { const s = Math.sign(to - from) || 1, dir = Math.sign(to), bendTo = dir * bw * Math.abs(to) / 0.6;
      t.at(T).to(110, { lx: dir * 0.9 }, 'o').e('blink').to(d1 + d2, { hyaw: dir * lead + s * 0.04 }, 'o').to(420, { hyaw: dir * lead * 0.35 }, 'io');          // eyes, then the face slides ahead ...
      const e1 = t.t; t.at(T + 150).to(d1, { turn: (from + to) / 2, sq: dip, tilt: s * 1.5 }, 'i')                                                           // ... the whole snack follows: dips ...
        .to(d2, { turn: to + s * 0.07, sq: -dip * 0.5, tilt: -s * 0.8 }, 'o').to(330, { turn: to, sq: 0, tilt: 0 }, 'io');                                   // ... rises past, settles
      const e2 = t.t; t.at(T + 260).to(d1 + d2, { bend: bendTo + s * 1.5, armL: s * 8, armR: -s * 8 }, 'io').to(380, { bend: bendTo, armL: 0, armR: 0 }, 'io'); // weight shift, paws trail
      return Math.max(e1, e2, t.t); };
    t.to(1, { lean: 0 });
    let e = turn(250, 0, -0.6 * k, 170, 220); e = turn(e + 900, -0.6 * k, 0.6 * k, 210, 250); e = turn(e + 900, 0.6 * k, 0, 170, 210);
    t.at(e + 200).to(300, { lx: 0, hyaw: 0 }, 'io');
    return t.rest(300).done({ soft: 0.6, stretch: 0 }); };

  // ---------- personality cards (T tempo, b bounce, s sway, e = fries / ears) ----------
  const CARDS = {
    mallow: { T: 1.15, b: 1.4, s: 1.1 },   // marshmallow: slow, the squishiest of all (memory foam)
    bao: { T: 1, b: 1.25, s: 1 },          // steamed bun: soft, pillowy, warm
    dunkie: { T: 0.92, b: 1.1, s: 1.25 },  // donut: playful, rolls and rocks
    frybo: { T: 0.85, b: 1, s: 1, e: 1.3 }, // fries: quick and crispy, the fries flick
    bunbun: { T: 0.95, b: 1.15, s: 1.05 }, // burger: bouncy stack
    choco: { T: 1, b: 0.85, s: 0.9 },      // chocolate bar: firm, snappy
    scoop: { T: 1.05, b: 1.15, s: 1.1 },   // ice cream: soft, swaying
    boba: { T: 0.95, b: 1.05, s: 1 },      // bubble tea: bubbly
    chefbun: { T: 1, b: 1.1, s: 1 },       // tiny chef: proud, precise
  };
  const para = (t, from, fn) => { const e = t.t; t.at(from); fn(t); return t.at(Math.max(e, t.t)); };
  const loopN = (t, n) => Object.assign(t.loop(), { dur: t.t * (n || 3) });
  const blink2 = t => t.e('blink2');

  // ---------- hand-made moves ----------
  const MOVES = {
    // ===== Mallow (marshmallow, slow-rise memory foam) =====
    mallow: {
      happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
        t.to(420, { sq: -0.16, lift: 2, armL: 70, armR: 70, wide: 0.3 }, 'o').e('emit', 'spark', 'head', 3).wait(200);                      // puffs up tall and fluffy ...
        t.to(260, { sq: 0.2, lift: 0, armL: 10, armR: 10, wide: 0 }, 'i'); land(t, 0.12, 4, 300);                                           // ... sinks back, wobbling
        return loopN(t); })(), 'Happy', 'Puffs up tall and fluffy with sparkles, then sinks back into a soft wobble.'],
      surprised: [(() => { const t = TL();
        t.wait(150).to(100, { wide: 1, open: 0.5, mw: 0.7 }, 'o').to(220, { sq: -0.24, lift: 4, armL: 60, armR: 60 }, 'o')                  // puffs up big ...
          .wait(500).to(1400, { sq: 0.04, lift: 0, armL: 10, armR: 10, wide: 0.3, open: 0.1, mw: 1 }, 'io')                                    // ... and slowly deflates (memory foam)
          .to(300, { sq: 0, armL: 0, armR: 0 }, 'io').e('blink').to(300, { wide: 0, hap: 1, smile: 1 }, 'io').wait(300);
        return t.rest(400).done(); })(), 'Surprised', 'Puffs up big in surprise, then slowly deflates like memory foam.'],
      squish: [(() => { const t = TL();
        t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.44, hap: 0.9, armL: 24, armR: 24 }, 'io').wait(300);
        t.to(1500, { sq: 0, hap: 0, smile: 1, armL: 0, armR: 0 }, 'o').to(300, { smile: 0 }, 'io');                                         // slow rise back (no bounce: memory foam)
        return loopN(t); })(), 'Squish', 'Squashed flat, then rises back slowly like memory foam.'],
      quirk: [(() => { const t = TL();
        t.to(500, { sq: -0.12, armL: 150, armR: 150, close: 0.8, open: 0.6, mw: 0.9 }, 'io').wait(400)                                        // a big stretch and yawn
          .to(300, { open: 0, mw: 1 }, 'io').to(900, { sq: 0.08, armL: 0, armR: 0, close: 0.4, hap: 0.0 }, 'io');                            // sinks down cosy ...
        t.osc(1200, 2, { sq: 0.1, close: 0.6 }, { sq: 0.07, close: 0.4 }, 's').to(400, { sq: 0, close: 0, hap: 1, smile: 1 }, 'io');         // ... breathing slowly
        return t.wait(300).rest(450).done(); })(), 'Cosy stretch', 'A big tall stretch and yawn, then sinks down cosy and breathes slowly.'],
      press: { hap: 0.5 }, rel: { dur: 1700, k: { sq: [[0, 0], [150, 0.22, 'o'], [1500, 0.02, 'o'], [1700, 0, 'io']], smile: [[0, 0], [200, 1, 'io'], [1300, 1], [1700, 0, 'io']] } },
    },
    // ===== Bao (steamed bun, pillowy thump) =====
    bao: {
      happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
        jump(t, { h: 7, ant: 180, up: 220, c: 0.2, arm: 40, chain: true, ev: [['emit', 'steam', 'head', 2]] }); land(t, 0.08, 2, 240);
        jump(t, { h: 8, ant: 160, up: 230, c: 0.2, arm: 46, ev: [['emit', 'steam', 'head', 2]] });
        return loopN(t); })(), 'Happy', 'Pillowy hops with little puffs of steam from his knot.'],
      surprised: [(() => { const t = TL();
        t.wait(150).to(80, { wide: 1, sq: 0.1, open: 0.4 }, 'o').to(160, { sq: -0.18, lift: 6, armL: 50, armR: 50 }, 'o').e('emit', 'steam', 'head', 6) // whoosh: steam bursts out the top
          .to(220, { lift: 0, sq: 0.14 }, 'i').to(200, { sq: 0 }, 'io');
        t.wait(300).to(300, { lx: -0.8 }, 'o').wait(300).to(300, { lx: 0.8 }, 'o').wait(300).to(300, { lx: 0, wide: 0, open: 0, hap: 1, smile: 1, armL: 0, armR: 0 }, 'io');
        return t.rest(450).done(); })(), 'Surprised', 'Steam bursts out of his knot like a kettle, a little hop, then he looks around.'],
      squish: [(() => { const t = TL();
        t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.4, hap: 0.9, armL: 20, armR: 20 }, 'io').e('emit', 'steam', 'head', 4).wait(300);    // squeezed: steam puffs out
        t.to(120, { sq: -0.18, armL: -4, armR: -4, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.1, 3, 260); t.to(200, { armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
        return loopN(t); })(), 'Squish', 'A pillowy squash that puffs steam out of his knot, then a soft bounce back.'],
      quirk: [(() => { const t = TL();
        t.to(300, { pitch: 0.1, ly: -0.9, lx: 0.1 }, 'io').e('emit', 'steam', 'head', 2).wait(500);                                           // looks up at the steam rising from his knot
        t.to(250, { sq: 0.05, puff: 0.5 }, 'io').to(140, { puff: -0.3, open: 0.4, mw: 0.5, sq: -0.03 }, 'o').e('emit', 'steam', 'head', 3)   // blows a puff ...
          .to(300, { puff: 0, open: 0, mw: 1, sq: 0 }, 'io').to(400, { pitch: 0, ly: 0, lx: 0, hap: 1, smile: 1 }, 'io');                    // ... pleased
        t.osc(800, 2, { tilt: 3 }, { tilt: -3 }, 'io');
        return t.wait(300).rest(450).done(); })(), 'Steam puff', 'Looks up at the steam rising from his knot and blows a little puff, pleased with himself.'],
      press: { puff: 0.3 }, rel: { dur: 1100, k: { sq: [[0, 0], [110, -0.18, 'o'], [250, 0.09, 'io'], [390, -0.03, 'io'], [540, 0, 'io']], smile: [[0, 0], [150, 1, 'o'], [800, 1], [1100, 0, 'io']] }, em: [['steam', 'head', 4]] },
    },
    // ===== Dunkie (donut, sugary crunch) =====
    dunkie: {
      happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
        swing(t, 1400, 3, { tilt: 12, x: 3, lean: 2 }, 'io');                                                                                  // rocks side to side like a rolling wheel
        jump(t, { h: 7, ant: 150, up: 210, c: 0.16, arm: 40, ev: [['emit', 'sprinkle', 'head', 3]] });
        return loopN(t); })(), 'Happy', 'Rocks side to side like a rolling wheel, then hops with sprinkles flying.'],
      surprised: [(() => { const t = TL();
        t.wait(150).to(80, { wide: 1, sq: 0.1, open: 0.45, mw: 0.7 }, 'o');
        jump(t, { h: 8, ant: 60, up: 210, c: 0.08, arm: 50, x: -5, air: { tilt: -10 }, fall: { tilt: 0 }, ev: [['emit', 'sprinkle', 'head', 5]] }); // sprinkles fly off
        t.wait(200).to(400, { lx: 0.7, ly: -0.6, htilt: 6 }, 'io').wait(400).to(400, { htilt: -4 }, 'io');                                     // checks his bite mark
        t.to(500, { x: 0, lx: 0, ly: 0, htilt: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
        return t.rest(450).done(); })(), 'Surprised', 'Jumps back with sprinkles flying off, then checks his bite mark.'],
      squish: [(() => { const t = TL();
        t.to(150, { sq: -0.05 }, 'o').to(300, { sq: 0.38, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'crumb', 'body', 4).wait(300);  // crunch: crumbs
        t.to(120, { sq: -0.18, armL: -4, armR: -4, hap: 0, smile: 1, open: 0.4 }, 'o').e('emit', 'sprinkle', 'head', 4); jelly(t, 0.08, 3, 230);
        t.to(200, { armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
        return loopN(t); })(), 'Squish', 'A crunchy squash with crumbs, springs back and sprinkles fly.'],
      quirk: [(() => { const t = TL();
        t.to(400, { lx: 0.8, ly: -0.7, htilt: 8, hyaw: 0.2 }, 'io').wait(400).e('blink');                                                      // looks up at his bite mark ...
        t.to(300, { frown: 0.3, puff: 0.3 }, 'io').to(320, { armR: 138, bend: -2 }, 'io').osc(560, 2, { armR: 122 }, { armR: 138 }, 'io') // ... reaches up and pats it (arms swing, generic paws can't reach that high by hand offsets) ...
          .to(320, { armR: 0, bend: 0, frown: 0, puff: 0, lx: 0, ly: 0, htilt: 0, hyaw: 0 }, 'io');
        t.to(250, { armL: 30, armR: 30, sq: 0.04, hap: 1, smile: 1 }, 'io').to(300, { armL: 0, armR: 0, sq: 0 }, 'io');                         // ... shrugs, still a donut
        return t.wait(300).rest(450).done(); })(), 'Bite check', 'Looks up at his bite mark, pats it, then shrugs and smiles.'],
      press: { hap: 0.4 }, rel: { dur: 1000, k: { sq: [[0, 0], [110, -0.2, 'o'], [250, 0.1, 'io'], [390, -0.04, 'io'], [540, 0, 'io']], lift: [[0, 0], [120, 3, 'o'], [270, 0, 'i']], smile: [[0, 0], [150, 1, 'o'], [700, 1], [1000, 0, 'io']] }, em: [['sprinkle', 'head', 4]] },
    },
    // ===== Frybo (box of fries, crispy rustle) - the fries move like ears (earL / earR) and wave (fw) =====
    frybo: {
      happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.35 });
        const a = t.t; jump(t, { h: 8, ant: 130, up: 180, c: 0.14, arm: 50, chain: true, air: { earL: -14, earR: -14 }, fall: { earL: 6, earR: 6 } });
        jump(t, { h: 8, ant: 110, up: 180, c: 0.14, arm: 50, air: { earL: -14, earR: -14 }, fall: { earL: 0, earR: 0 }, ev: [['emit', 'salt', 'head', 4]] });
        para(t, a, u => u.to(t.t - a, { fw: 1.2 }, 'io')); t.to(300, { fw: 0 }, 'io');
        return loopN(t); })(), 'Happy', 'Two quick hops with his fries fanning up and waving, a sprinkle of salt.'],
      surprised: [(() => { const t = TL();
        t.wait(150).to(70, { wide: 1, sq: 0.08, earL: -22, earR: -22, open: 0.5, mw: 0.7 }, 'o')                                             // fries shoot straight up like hair standing on end
          .to(200, { lift: 5, sq: -0.12 }, 'o').to(200, { lift: 0, sq: 0.08 }, 'i').to(150, { sq: 0 }, 'io').wait(600);
        t.to(500, { earL: 8, earR: 8, open: 0.1, mw: 1 }, 'io').to(300, { earL: 0, earR: 0, wide: 0.3 }, 'io');                                 // ... and flop back down
        t.to(400, { lx: -0.7 }, 'o').wait(250).to(400, { lx: 0.7 }, 'o').wait(250).to(300, { lx: 0, wide: 0, hap: 1, smile: 1 }, 'io');
        return t.rest(450).done(); })(), 'Surprised', 'His fries shoot straight up like hair standing on end, then flop back down.'],
      squish: [(() => { const t = TL();
        t.to(150, { sq: -0.05 }, 'o').to(300, { sq: 0.36, hap: 0.9, armL: 22, armR: 22, earL: 12, earR: 12, fw: 0.8 }, 'io').wait(300);       // fries squeeze together, rustle
        t.to(110, { sq: -0.2, earL: -16, earR: -16, armL: -4, armR: -4, hap: 0, smile: 1, open: 0.4 }, 'o').e('emit', 'salt', 'head', 4)       // pop up!
          .to(160, { sq: 0.07, earL: 4, earR: 4 }, 'io').to(160, { sq: -0.02, earL: -2, earR: -2 }, 'io').to(200, { sq: 0, earL: 0, earR: 0, armL: 0, armR: 0, fw: 0, smile: 0, open: 0 }, 'io');
        return loopN(t); })(), 'Squish', 'His fries squeeze together with a crispy rustle, then pop back up with a sprinkle of salt.'],
      quirk: [(() => { const t = TL();
        t.to(200, { sq: 0.06, close: 0.6 }, 'io'); shake(t, { P: 85, env: [0.6, 1, 0.9, 0.6, 0.3], head: 0.1, roll: 3, ear: 16, chest: 0.05, body: 0.8 }); // shakes the box: the fries rustle ...
        t.e('emit', 'salt', 'head', 3).to(300, { sq: 0, close: 0 }, 'io');
        t.to(400, { armL: 142, armR: 142, ly: -0.8, sq: -0.04 }, 'io').osc(640, 2, { armL: 124, armR: 124, earL: -7, earR: -7, fw: 0.8 }, { armL: 142, armR: 142, earL: 2, earR: 2, fw: 0.3 }, 'io') // ... and fluffs his fries with both paws
          .to(380, { armL: 0, armR: 0, ly: 0, sq: 0, earL: 0, earR: 0, fw: 0, hap: 1, smile: 1 }, 'io');
        return t.wait(300).rest(450).done(); })(), 'Fry fluff', 'Shakes his box so the fries rustle and settle, a sprinkle of salt, then fluffs his fries with both paws.'],
      press: { earL: 10, earR: 10, fw: 0.6 }, rel: { dur: 1000, k: { sq: [[0, 0], [100, -0.2, 'o'], [240, 0.08, 'io'], [380, -0.03, 'io'], [520, 0, 'io']], earL: [[0, 0], [100, -16, 'o'], [280, 6, 'io'], [460, -2, 'io'], [620, 0, 'io']], earR: [[0, 0], [100, -16, 'o'], [280, 6, 'io'], [460, -2, 'io'], [620, 0, 'io']] }, em: [['salt', 'head', 3]] },
    },
    // ===== Bunbun (burger stack, squeaky cheese) - layers split (split), fan out (fan), shuffle (shuf) =====
    bunbun: {
      happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.35 });
        jump(t, { h: 9, ant: 150, up: 220, c: 0.16, arm: 45, air: { split: 0.5 }, fall: { split: 0 } });                                       // the layers lift apart in the air and stack back
        swing(t, 1000, 3, { fan: 0.6, tilt: 4 }, 'io');                                                                                          // a happy fan sway
        return loopN(t); })(), 'Happy', 'A hop where his layers lift apart in the air and stack back, then a happy fan sway.'],
      surprised: [(() => { const t = TL();
        t.wait(150).to(70, { wide: 1, open: 0.45, mw: 0.7, sq: 0.06 }, 'o').to(180, { split: 1.1, lift: 4, sq: -0.08 }, 'o')                    // the layers jump apart ...
          .wait(350).to(140, { split: 0, lift: 0, sq: 0.16 }, 'i').e('emit', 'dust', 'body', 3).to(200, { sq: 0 }, 'io');                     // ... and slam back together
        t.wait(200).to(300, { lx: -0.7 }, 'o').wait(250).to(300, { lx: 0.7 }, 'o').wait(250).to(300, { lx: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
        return t.rest(450).done(); })(), 'Surprised', 'His layers jump apart in fright and slam back together into a stack.'],
      squish: [(() => { const t = TL();
        t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.4, hap: 0.9, armL: 22, armR: 22, fan: 0.4 }, 'io').e('emit', 'note', 'head', 1).wait(300); // squeaky cheese!
        t.to(120, { sq: -0.18, fan: -0.3, armL: -4, armR: -4, hap: 0, smile: 1, open: 0.4 }, 'o'); jelly(t, 0.1, 3, 230); t.to(220, { fan: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
        return loopN(t); })(), 'Squish', 'His stack squashes with a squeaky-cheese squeak, the layers fan out and wobble back.'],
      quirk: [(() => { const t = TL();
        t.to(400, { ly: 0.8, pitch: -0.2 }, 'io');                                                                                                  // looks down at his stack ...
        t.to(300, { shuf: 0.8 }, 'io').to(300, { shuf: -0.8 }, 'io').to(300, { shuf: 0.5 }, 'io').to(300, { shuf: 0 }, 'io');                // ... the layers shuffle like cards
        t.to(260, o(both(10, 2), { armL: 10, armR: 10 }), 'io').osc(500, 2, { hLy: 0, hRy: 0 }, { hLy: 3, hRy: 3 }, 'io')                       // ... pats them straight
          .to(300, o(NOHANDS, { armL: 0, armR: 0, ly: 0, pitch: 0, hap: 1, smile: 1 }), 'io');
        return t.wait(300).rest(450).done(); })(), 'Restack', 'Looks down at his stack, the layers shuffle like cards, and he pats them back into a neat burger.'],
      press: { fan: 0.3 }, rel: { dur: 1100, k: { sq: [[0, 0], [110, -0.18, 'o'], [250, 0.1, 'io'], [390, -0.04, 'io'], [540, 0, 'io']], split: [[0, 0], [120, 0.5, 'o'], [400, 0, 'i']], smile: [[0, 0], [150, 1, 'o'], [800, 1], [1100, 0, 'io']] }, em: [['note', 'head', 1]] },
    },
    // ===== Choco (chocolate bar, snap then gooey) - melt (0-1.2), tw (segments twinkle), wrap (foil peel) =====
    choco: {
      happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
        t.to(200, { tw: 1.2 }, 'o').e('emit', 'spark', 'head', 3);                                                                              // his segments twinkle ...
        jump(t, { h: 7, ant: 140, up: 200, c: 0.1, arm: 50 }); t.to(400, { tw: 0 }, 'io');                                                     // ... a crisp little hop
        return loopN(t); })(), 'Happy', 'His segments twinkle and he does a crisp little hop.'],
      surprised: [(() => { const t = TL();
        t.wait(150).to(60, { wide: 1, open: 0.45, mw: 0.7, sq: -0.06, tw: 1.4, lift: 2 }, 'o').e('emit', 'spark', 'head', 2)                  // SNAP: stiff as a board, segments flash
          .wait(500).to(200, { lift: 0, tw: 0 }, 'io');
        t.to(900, { melt: 0.5, sq: 0.08, wide: 0.4, frown: 0.3 }, 'io').wait(300).to(300, { melt: 0, sq: 0, frown: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'o'); // goes a bit gooey, then pulls himself together
        return t.rest(450).done(); })(), 'Surprised', 'Snaps stiff with his segments flashing, goes a little gooey, then pulls himself together.'],
      squish: [(() => { const t = TL();
        t.to(150, { sq: -0.04 }, 'o').to(400, { sq: 0.3, melt: 0.8, hap: 0.9 }, 'io').wait(350);                                                 // squeezed: he melts ...
        t.to(120, { sq: -0.12, melt: 0, tw: 1, hap: 0, smile: 1, open: 0.4 }, 'o').e('emit', 'spark', 'head', 2).to(200, { sq: 0.04 }, 'io')   // ... and SNAPS back into shape
          .to(260, { sq: 0, tw: 0, smile: 0, open: 0 }, 'io');
        return loopN(t); })(), 'Squish', 'Melts into a gooey puddle when squashed, then snaps back into shape.'],
      quirk: [(() => { const t = TL();
        t.to(1200, { melt: 0.45, sq: 0.06, close: 0.5, hap: 0.0 }, 'io').wait(300);                                                            // slowly starts to melt in the warmth ...
        t.to(150, { wide: 0.8, close: 0 }, 'o'); shake(t, { P: 80, env: [0.5, 1, 0.8, 0.4], head: 0.12, roll: 3, ear: 0, body: 0.6 });          // ... notices, shakes it off ...
        t.to(200, { melt: 0, sq: -0.04, tw: 1 }, 'o').to(300, { sq: 0, tw: 0, wide: 0, hap: 1, smile: 1 }, 'io');                              // ... and firms back up
        return t.wait(300).rest(450).done(); })(), 'Melty moment', 'Slowly starts to melt in the warmth, notices, shakes it off and firms back up.'],
      press: { melt: 0.6 }, rel: { dur: 900, k: { melt: [[0, 0.4], [180, 0, 'o']], sq: [[0, 0], [100, -0.14, 'o'], [240, 0.05, 'io'], [380, 0, 'io']], tw: [[0, 0], [100, 1.1, 'o'], [600, 0, 'io']] }, em: [['spark', 'head', 2]] },
    },
    // ===== Scoop (strawberry ice cream, cold crackle) - chb (cherry bob), chy (cherry pops up) =====
    scoop: {
      happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
        const a = t.t; swing(t, 1400, 3, { tilt: 6, x: 1.5, bend: 3 }, 'io'); para(t, a, u => u.osc(1400, 4, { chb: 1 }, { chb: 0 }, 'io'));    // sways, the cherry bopping
        t.to(150, { chy: 1 }, 'o').to(260, { chy: 0 }, 'i').e('emit', 'heart', 'head', 1);                                                    // the cherry pops up and lands
        return loopN(t); })(), 'Happy', 'Sways side to side with his cherry bopping, then the cherry pops up and lands with a heart.'],
      surprised: [(() => { const t = TL();
        t.wait(150).to(80, { wide: 1, open: 0.45, mw: 0.7, sq: 0.08 }, 'o').to(180, { chy: 1.2, sq: -0.1 }, 'o').wait(150).to(300, { chy: 0, sq: 0.06 }, 'i') // the cherry jumps off his head and lands back
          .to(200, { sq: 0 }, 'io');
        t.to(200, { close: 0.4 }, 'io'); shake(t, { P: 70, env: [0.4, 0.8, 1, 0.8, 0.5, 0.25], head: 0.1, roll: 2, ear: 0, body: 0.6 });         // a cold shiver
        t.to(400, { close: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
        return t.rest(450).done(); })(), 'Surprised', 'His cherry jumps up off his head and lands back, then a cold little shiver.'],
      squish: [(() => { const t = TL();
        t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.4, hap: 0.9, armL: 22, armR: 22 }, 'io').wait(300);
        t.to(110, { sq: -0.18, chy: 0.8, armL: -4, armR: -4, hap: 0, smile: 1, open: 0.4 }, 'o').to(240, { chy: 0 }, 'i'); jelly(t, 0.1, 3, 240); // scoop springs, cherry pops
        t.to(200, { armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
        return loopN(t); })(), 'Squish', 'His soft scoop squishes on the cone, then springs back and the cherry pops up.'],
      quirk: [(() => { const t = TL();
        t.to(400, { lx: 0.2, ly: -0.9, pitch: 0.15 }, 'io').wait(200);                                                                          // looks up at his cherry ...
        t.osc(900, 3, { chb: 1.2, htilt: 3 }, { chb: 0, htilt: -3 }, 'io');                                                                      // ... wiggles it ...
        t.to(150, { chy: 1 }, 'o').to(300, { chy: 0 }, 'i').to(300, { pitch: 0, ly: 0, lx: 0, htilt: 0, hap: 1, smile: 1 }, 'io');            // ... flips it up and catches it
        return t.wait(300).rest(450).done(); })(), 'Cherry flip', 'Looks up at his cherry, wiggles it, then flips it up and catches it.'],
      press: { chb: 0.6 }, rel: { dur: 1000, k: { sq: [[0, 0], [110, -0.18, 'o'], [250, 0.09, 'io'], [390, -0.03, 'io'], [540, 0, 'io']], chy: [[0, 0], [120, 0.9, 'o'], [380, 0, 'i']] } },
    },
    // ===== Boba (bubble tea, pearls popping) - pop (pearls), stw (straw wiggle), swirl (pearls), slurp, sup (straw up) =====
    boba: {
      happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
        const a = t.t; jump(t, { h: 8, ant: 140, up: 200, c: 0.14, arm: 45, chain: true }); jump(t, { h: 8, ant: 120, up: 200, c: 0.14, arm: 45 });
        para(t, a, u => u.to(300, { pop: 1.5, swirl: 1.5, stw: 1 }, 'o').to(t.t - a - 300, { pop: 0.4 }, 'io')); t.to(400, { pop: 0, swirl: 0, stw: 0 }, 'io'); // pearls bounce + swirl
        return loopN(t); })(), 'Happy', 'Bouncy hops with his pearls popping and swirling and his straw wiggling.'],
      surprised: [(() => { const t = TL();
        t.wait(150).to(70, { wide: 1, open: 0.45, mw: 0.7, sq: 0.08, sup: 1.4, pop: 2 }, 'o')                                                 // the straw shoots up, the pearls jump
          .to(200, { lift: 4, sq: -0.1 }, 'o').to(200, { lift: 0, sq: 0.06 }, 'i').to(200, { sq: 0, pop: 0.3 }, 'io').wait(400);
        t.to(500, { sup: 0, pop: 0, wide: 0.3 }, 'io').to(300, { lx: -0.7 }, 'o').wait(250).to(300, { lx: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io');
        return t.rest(450).done(); })(), 'Surprised', 'His straw shoots up and the pearls jump, then everything settles back down.'],
      squish: [(() => { const t = TL();
        t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.36, hap: 0.9, armL: 22, armR: 22, slurp: 1 }, 'io').wait(400);                          // squeezed: a pearl rides up the straw ...
        t.to(110, { sq: -0.16, slurp: 0, sup: 0.8, pop: 1.5, hap: 0, smile: 1, open: 0.4 }, 'o').e('emit', 'bubble', 'head', 3)                // ... and pops out the top
          .to(300, { sup: 0, sq: 0.05 }, 'io').to(300, { sq: 0, pop: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
        return loopN(t); })(), 'Squish', 'Squeezed, a pearl rides up his straw and pops out the top with bubbles.'],
      quirk: [(() => { const t = TL();
        t.to(350, { lx: 0.3, ly: -0.8, pitch: 0.1 }, 'io').to(300, { slurp: 1, mw: 0.5, open: 0.1 }, 'io').wait(900)                            // sips from his own straw ...
          .to(200, { slurp: 0, mw: 1, open: 0, puff: 0.6 }, 'io').to(300, { puff: 0, sq: 0.05 }, 'io').e('gulp');                              // ... gulp
        t.to(300, { sq: 0, pitch: 0, ly: 0, lx: 0, hap: 1, smile: 1, swirl: 1.5 }, 'io').wait(600).to(400, { swirl: 0 }, 'io');               // ... happy pearls swirl
        return t.wait(200).rest(450).done(); })(), 'Slurp', 'Sips from his own straw (a pearl rides up), gulps, and his pearls swirl happily.'],
      press: { slurp: 0.8, pop: 0.6 }, rel: { dur: 1000, k: { sq: [[0, 0], [110, -0.16, 'o'], [250, 0.07, 'io'], [390, -0.02, 'io'], [540, 0, 'io']], sup: [[0, 0], [120, 0.8, 'o'], [500, 0, 'io']], pop: [[0, 0], [100, 1.5, 'o'], [700, 0, 'io']] }, em: [['bubble', 'head', 2]] },
    },
    // ===== Chef Bun (tiny chef, dough pat) =====
    chefbun: {
      happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.25 });
        t.to(300, o(hand(1, 13, -15), { armR: 20, close: 0.9 }), 'io').to(140, { open: 0.3, mw: 0.5, puff: -0.2 }, 'o')                          // the chef's kiss: fingers to his lips ...
          .to(220, o(hand(1, -4, -10), { armR: 80, open: 0.25, mw: 1, puff: 0 }), 'o').e('emit', 'spark', 'pawR', 3).e('emit', 'heart', 'head', 1) // ... and flung open - perfection!
          .wait(300).to(300, o(hand(1, 0, 0), { armR: 0, close: 0 }), 'io');
        jump(t, { h: 5, ant: 140, up: 180, c: 0.12, arm: 30 });
        return loopN(t); })(), "Happy", "A chef's kiss - fingers to his lips and flung open with sparkles - then a proud little hop."],
      surprised: [(() => { const t = TL();
        t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, sq: 0.08 }, 'o').to(180, { lift: 5, sq: -0.12, armL: 60, armR: 60 }, 'o').to(200, { lift: 0, sq: 0.06 }, 'i');
        t.to(300, o(both(-4, -30), { sq: 0, armL: 150, armR: 150, htilt: 4 }), 'io').osc(500, 2, { htilt: 6, armL: 142, armR: 142 }, { htilt: 2, armL: 150, armR: 150 }, 'io') // grabs his hat to keep it on (arms swing up)
          .to(350, o(NOHANDS, { armL: 0, armR: 0, htilt: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }), 'io');
        return t.rest(450).done(); })(), 'Surprised', 'Jumps and grabs his chef hat with both paws to keep it on, then straightens it.'],
      squish: [(() => { const t = TL();
        t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.42, hap: 0.9, armL: 24, armR: 24 }, 'io').e('emit', 'dust', 'body', 3).wait(300);       // flattened like dough (a puff of flour)
        t.to(300, { sq: 0.1, hap: 0, armL: 0, armR: 0 }, 'io');
        for (let i = 0; i < 2; i++) t.to(150, o(both(8, 4), { sq: 0.12 }), 'io').to(180, o(NOHANDS, { sq: 0.04 * (1 - i) }), 'io');             // pats himself back into shape
        t.to(200, { sq: 0, hap: 1, smile: 1 }, 'io').to(200, { hap: 0, smile: 0 }, 'io');
        return loopN(t); })(), 'Squish', 'Flattened like dough with a puff of flour, then pats himself back into shape.'],
      quirk: [(() => { const t = TL();
        t.to(350, o(hand(1, 13, -15), { armR: 20, pitch: -0.05, ly: 0.4 }), 'io').osc(500, 2, { open: 0.2, tongue: 0.6 }, { open: 0, tongue: 0 }, 'io'); // tastes from his paw ...
        t.to(400, { close: 0.85, htilt: 6, pitch: 0.1 }, 'io').wait(400);                                                                       // ... considers ...
        t.to(140, { open: 0.3, mw: 0.5, puff: -0.2 }, 'o').to(220, o(hand(1, -4, -10), { armR: 80, open: 0.25, mw: 1, puff: 0, close: 0, htilt: 0, pitch: 0 }), 'o') // ... chef's kiss
          .e('emit', 'spark', 'pawR', 3).wait(300).to(300, o(hand(1, 0, 0), { armR: 0, hap: 1, smile: 1, ly: 0 }), 'io');
        return t.wait(200).rest(450).done(); })(), 'Taste test', "Tastes something from his paw, thinks about it, then a proud chef's kiss."],
      press: { hap: 0.4 }, rel: { dur: 1100, k: { sq: [[0, 0], [110, -0.18, 'o'], [250, 0.08, 'io'], [390, -0.03, 'io'], [540, 0, 'io']], smile: [[0, 0], [150, 1, 'o'], [800, 1], [1100, 0, 'io']] }, em: [['dust', 'body', 2]] },
    },
  };
  // ---------- signature dances (Nov 9, user: 'use each one's unique body shape to add signature dance moves that can be done only using their bodies') ----------
  // Replaces the older 10 s dances in rive-generic (their builders skip a dance@key that already exists). Every big move: eyes first, anticipation,
  // overshoot + settle, the arms / parts trail. Each loop ends on its first pose. B = one beat.
  const eyes = (t, d) => t.to(110, { lx: d * 0.9 }, 'o').e('blink');
  const DANCES = {
    // Mallow: the squishiest body - memory-foam steps down, ONE long slow rise (only she rises that slowly), a taffy stretch, a pillow flop,
    // turning on the roasting stick, squashed into a s'more and the slow rise again
    mallow: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 520;
      [0.12, 0.24, 0.36].forEach((v, i) => t.to(200, { sq: v, armL: 20 - i * 10, armR: 20 - i * 10, close: i === 2 ? 0.6 : 0 }, 'o').wait(B - 200));   // memory-foam steps down ...
      t.to(1400, { sq: -0.2, lift: 2, armL: 150, armR: 150, close: 0, wide: 0.3 }, 'o').e('emit', 'spark', 'head', 3)                                     // ... one long slow rise, tall
        .to(240, { sq: -0.24 }, 'io').to(300, { sq: -0.19 }, 'io');
      swing(t, 2000, 3, { bend: 7, x: 1.4, htilt: -3, armL: 12, armR: -12 }, 'io');                                                                      // taffy stretch sway (the body bends, the arms trail)
      t.to(320, { sq: 0.14, lift: 0, armL: 30, armR: 30, wide: 0 }, 'i'); land(t, 0.16, 4, 360);                                                          // pillow flop: a big soft wobble
      eyes(t, 1); let a = t.t; t.to(1800, { spin: 360, armL: 60, armR: 60 }, 'io').to(1, { spin: 0 }, 'l');                                              // turns on the roasting stick ...
      t.at(a); steps(t, 1800, 4, 2); [0, 600, 1200].forEach(d => t.at(a + d).e('emit', 'steam', 'head', 2)); t.at(a + 1801).to(250, { armL: 0, armR: 0, lx: 0 }, 'io');
      t.to(300, { sq: -0.1, lift: 2, armL: 165, armR: 165 }, 'o').to(160, { sq: 0.45, lift: 0, armL: 10, armR: 10, close: 1 }, 'i')                    // ... squashed into a s'more ...
        .e('emit', 'dust', 'footL', 3).e('emit', 'dust', 'footR', 3).wait(400);
      t.to(1500, { sq: 0, armL: 0, armR: 0, close: 0 }, 'o').e('emit', 'heart', 'head', 2).wait(250);                                                     // ... and the slow rise again
      return t.rest(300).loop({ stretch: 0.6 }); })(), 'Marshmallow Mellow', 'Memory-foam steps down, one long slow rise to tall, a taffy stretch sway, a pillow flop, turns on the roasting stick in a puff of steam, gets squashed into a s\'more and slowly rises again.'],
    // Bao: a dough bun - proofs (rises in two breaths with steam), steamer-basket bounces, the pinch-and-twist of his pleats, the kettle whistle,
    // a pillowy plop
    bao: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 500;
      t.to(300, { sq: 0.22, armL: -6, armR: -6, close: 0.5 }, 'io').wait(200);
      t.to(700, { sq: 0.08, armL: 20, armR: 20 }, 'o').e('emit', 'steam', 'head', 2).wait(150).to(800, { sq: -0.12, lift: 1, armL: 60, armR: 60, close: 0, wide: 0.3 }, 'o') // proofing: rises in two breaths
        .e('emit', 'steam', 'head', 3).to(300, { sq: -0.08, wide: 0 }, 'io');
      for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; jump(t, { h: 5, ant: 120, up: 170, c: 0.14, arm: 50, chain: i < 3, air: { tilt: d * 5, htilt: -d * 3 }, fall: { tilt: 0, htilt: 0 }, ev: [['emit', 'steam', 'head', 2]] }); } // steamer bounces
      swing(t, 2000, 3, { twist: 0.55, htilt: 5, bend: -2, armL: 25, armR: -25 }, 'io');                                                                  // pinch-and-twist: his pleats wring one way, then the other
      t.to(500, { puff: 1, sq: -0.05, lift: 1, close: 0.4 }, 'io').to(150, { puff: -0.2, open: 0.3, mw: 0.45, close: 0.8 }, 'o')                       // the kettle: cheeks fill ...
        .em(1000, 140, 'steam', 'head', 1).e('emit', 'note', 'head').osc(1000, 5, { lift: 2.2, sq: -0.08 }, { lift: 1, sq: -0.04 }, 'io')               // ... and he whistles, steam streaming
        .e('emit', 'note', 'head').to(300, { puff: 0, open: 0, mw: 1, close: 0, lift: 0, sq: 0 }, 'io');
      t.to(260, { sq: 0.18, bend: -6, x: -1.5, armL: 30, armR: 30 }, 'i'); jelly(t, 0.12, 3, 320); t.to(300, { bend: 0, x: 0, armL: 0, armR: 0 }, 'io');   // pillowy plop
      jump(t, { h: 8, ant: 200, up: 240, c: 0.2, arm: 70, ev: [['emit', 'heart', 'head', 2], ['emit', 'steam', 'head', 3]] });
      return t.rest(300).loop({ stretch: 0.6 }); })(), 'Steamer Proof', 'Rises like proofing dough in two steamy breaths, bounces in the steamer basket, wrings his pleats in a pinch-and-twist, whistles like a kettle with steam streaming out, a pillowy plop and a proud hop.'],
    // Dunkie: a ring - rolls like a wheel, spins like a coin on a table (front -> thin edge -> back) and wobbles down like one, hula-hoops with
    // his whole body, dunks and shakes off the coffee
    dunkie: [(() => { const t = TL({ smile: 0.9 }), B = 500;
      eyes(t, -1); t.to(200, { tilt: 6, sq: 0.06 }, 'io').to(900, { x: -6, tilt: -32, footL: 2 }, 'io').to(250, { tilt: -28, footL: 0 }, 'io');           // rolls away like a wheel ...
      eyes(t, 1); t.to(1200, { x: 6, tilt: 32, footR: 2 }, 'io').to(250, { tilt: 28, footR: 0 }, 'io').to(800, { x: 0, tilt: -4, lx: 0 }, 'io').to(250, { tilt: 0 }, 'io'); // ... and back past home
      t.to(260, { twist: -0.4, sq: 0.1, armL: 40, armR: 40 }, 'io');                                                                                      // wind-up ...
      let a = t.t; t.to(1500, { spin: 1080, lift: 2, twist: 0, sq: -0.04 }, 'o').to(1, { spin: 0 }, 'l');                                               // ... spins like a coin
      t.at(a + 1300); [10, -8, 6, -4, 2, 0].forEach(v => t.to(140, { tilt: v, lift: v ? 1 : 0, cross: v ? 0.6 : 0 }, 'io'));                                                // and wobbles down like one
      t.to(200, { sq: 0, armL: 0, armR: 0 }, 'io').e('emit', 'sprinkle', 'head', 3);
      for (let i = 0; i < 8; i++) { const an = (i + 1) * Math.PI / 2; t.to(B / 2, { x: 3 * Math.sin(an), bend: 5 * Math.cos(an), htilt: -2 * Math.sin(an), armL: 50, armR: 50 }, 'io'); } // hula-hoops with his whole ring
      t.to(250, { x: 0, bend: 0, htilt: 0, armL: 0, armR: 0 }, 'io');
      t.to(300, { sq: 0.28, pitch: -0.25, lift: -1 }, 'io').e('emit', 'coffee', 'body', 4).wait(200).to(240, { sq: -0.08, pitch: 0.05, lift: 1 }, 'o'); // dunk ...
      shake(t, { P: 85, env: [0.6, 1, 0.8, 0.5, 0.25], head: 0.2, roll: 4, body: 1, chest: 0.1 }); t.e('emit', 'coffee', 'body', 3).e('emit', 'sprinkle', 'head', 3); // ... and shakes it off
      t.to(200, { sq: 0, pitch: 0, lift: 0 }, 'io').to(160, { winkR: 1, smile: 1 }, 'io').e('emit', 'heart', 'head', 1).wait(300).to(200, { winkR: 0 }, 'io');
      return t.rest(300).loop({ stretch: 0.6 }); })(), 'Coin Spin Roll', 'Rolls away like a wheel and back, spins like a coin on a table (front, thin edge, back) and wobbles down like one, a bit dizzy, hula-hoops with his whole ring, dunks in coffee, shakes it off and winks.'],
    // Frybo: the fries move as one: they fan open / bunch shut on the beat, flip like a hair flip, ripple in a fry wave, the box tips to pour,
    // a salt-shaker shimmy and a fan-open ta-da
    frybo: [(() => { const t = TL({ smile: 0.9 }), B = 480;
      for (let i = 0; i < 4; i++) t.to(150, { earL: 22, earR: 22, sq: -0.06, lift: 1.2, armL: 50, armR: 50 }, 'o').to(B - 150, { earL: -14, earR: -14, sq: 0.08, lift: 0, armL: 10, armR: 10 }, 'io'); // fan open, bunch shut
      t.to(200, { earL: 0, earR: 0, sq: 0 }, 'io');
      [1, -1].forEach(d => { eyes(t, d); t.to(200, { earL: d * 8, earR: -d * 8, htilt: -d * 3, tilt: -d * 2 }, 'io')                                // anticipation the other way ...
        .to(220, { earL: -d * 24, earR: d * 24, htilt: d * 7, tilt: d * 4, armL: d < 0 ? 70 : 10, armR: d > 0 ? 70 : 10 }, 'o')                        // ... hair flip!
        .to(300, { earL: -d * 18, earR: d * 18, htilt: d * 5, tilt: d * 3 }, 'io').wait(200); });
      t.to(300, { earL: 0, earR: 0, htilt: 0, tilt: 0, lx: 0, armL: 0, armR: 0 }, 'io');
      t.to(300, { armL: 140, armR: 140, fw: 1.5, earL: 8, earR: 8, hap: 1 }, 'o').osc(1400, 7, { armL: 128, armR: 152 }, { armL: 152, armR: 128 }, 'io') // the fry wave with jazz hands
        .to(300, { armL: 0, armR: 0, fw: 0, earL: 0, earR: 0, hap: 0 }, 'io');
      eyes(t, 1); t.to(260, { tilt: -4, sq: 0.06 }, 'io').to(400, { tilt: 28, x: 3, earL: -20, earR: 20, lift: 1 }, 'o').e('emit', 'salt', 'head', 4).wait(250) // tips the box to pour ...
        .to(380, { tilt: -5, x: 0, earL: 8, earR: -8, lift: 0 }, 'io').to(280, { tilt: 0, earL: 0, earR: 0, lx: 0, sq: 0 }, 'io');                       // ... and rights it, the fries swinging back
      t.to(150, { sq: 0.05 }, 'io'); shake(t, { P: 80, env: [0.5, 0.9, 1, 0.9, 0.6, 0.3], head: 0.12, roll: 3, ear: 14, body: 1, chest: 0.06 }); t.e('emit', 'salt', 'head', 5); // salt-shaker shimmy
      t.to(200, { earL: -16, earR: -16, sq: 0.12 }, 'io'); jump(t, { h: 8, ant: 140, up: 220, c: 0.16, arm: 80, air: { earL: 24, earR: 24 }, fall: { earL: 10, earR: 10 }, ev: [['emit', 'spark', 'head', 3]] }); // ta-da: fries fan open
      t.to(300, { earL: 0, earR: 0 }, 'io');
      return t.rest(300).loop({ stretch: 0.6 }); })(), 'Fry Fan Flip', 'His fries fan open and bunch shut on the beat, a hair flip one way then the other, a fry wave with jazz hands, he tips his box to pour and rights it, a salt-shaker shimmy and a fan-open ta-da.'],
    // Bunbun: a stack - squeezes like an accordion (the layers open and shut), fans his layers like a hand of cards, riffles them, flips like a
    // patty (layers apart, spinning in the air), slams the stack back
    bunbun: [(() => { const t = TL({ smile: 0.9 }), B = 500;
      for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; t.to(B / 2, { split: 0.8, sq: -0.08, tilt: d * 4, armL: 55, armR: 55, open: 0.4, hap: 1 }, 'o').e('emit', 'note', 'head', 1) // accordion: open ...
        .to(B / 2, { split: 0, sq: 0.1, tilt: 0, armL: 5, armR: 5, open: 0 }, 'io'); }                                                                     // ... and squeeze
      t.to(200, { sq: 0, hap: 0 }, 'io'); eyes(t, -1);
      t.to(500, { fan: -1.2, htilt: -5, tilt: -3 }, 'io').wait(150); eyes(t, 1); t.to(700, { fan: 1.2, htilt: 5, tilt: 3 }, 'io').wait(150).to(450, { fan: 0, htilt: 0, tilt: 0, lx: 0 }, 'io'); // fans his layers like cards
      for (let i = 0; i < 4; i++) t.to(110, { shuf: i % 2 ? -0.9 : 0.9, sq: 0.03 }, 'o').to(110, { shuf: 0, sq: 0 }, 'io');                          // riffle
      t.e('emit', 'crumb', 'body', 2);
      eyes(t, 1); jump(t, { h: 14, ant: 240, up: 330, c: 0.24, arm: 90, spin: 360, air: { split: 1.2 }, fall: { split: 0.3 } });                       // patty flip: layers apart, spinning
      t.to(80, { split: 0, sq: 0.25 }, 'o').e('emit', 'crumb', 'body', 4).e('emit', 'dust', 'body', 3).to(160, { sq: -0.06, lx: 0 }, 'io');           // slam!
      jelly(t, 0.08, 3, 260); t.to(220, { fan: 0.35 }, 'io').to(300, { fan: -0.2 }, 'io').to(250, { fan: 0 }, 'io');
      t.to(160, { winkR: 1, smile: 1 }, 'io').e('emit', 'heart', 'head', 1).wait(300).to(200, { winkR: 0 }, 'io');
      return t.rest(300).loop({ stretch: 0.6 }); })(), 'Burger Accordion', 'Squeezes his stack like an accordion (the layers open and shut, notes fly), fans his layers like a hand of cards, riffles them, flips like a patty with his layers spinning apart, slams the stack back and winks.'],
    // Choco: a stiff bar that can melt - robot snaps (no bending, sharp stops, the segments flash), a light-up segment show, melts into a gooey
    // sway, SNAPS back into a bar, a foil twirl (wrapper slips, he tugs it up, blushing)
    choco: [(() => { const t = TL({ smile: 0.85 }), B = 450;
      const pops = [{ tilt: 6, armL: 90, armR: 0 }, { tilt: -6, armL: 0, armR: 90 }, { tilt: 0, armL: 90, armR: 90, lift: 1 }, { tilt: 0, armL: 0, armR: 0, lift: 0 }];
      for (let r = 0; r < 2; r++) pops.forEach(p => t.to(70, o(p, { tw: 1.3, sq: -0.03 }), 'l').e('emit', 'spark', 'head', 1).to(B - 70, { tw: 0.2, sq: 0 }, 'o')); // robot snaps: sharp, stiff, the segments flash
      t.osc(1800, 6, { tw: 1.5, sq: -0.02 }, { tw: 0, sq: 0.02 }, 'io').to(150, { sq: 0 }, 'io');                                                        // segment light show
      t.to(1400, { melt: 1, sq: 0.2, close: 0.6, armL: 20, armR: 20 }, 'io');                                                                            // melts ...
      swing(t, 1600, 3, { bend: 8, x: 1.5, htilt: -4 }, 'io');                                                                                           // ... a gooey sway
      t.to(90, { melt: 0, sq: -0.1, tw: 1.5, close: 0, wide: 0.6, armL: 80, armR: 80 }, 'o').e('emit', 'spark', 'head', 3).to(180, { sq: 0.04, tw: 0.5 }, 'io') // SNAP back into a bar
        .to(200, { sq: 0, tw: 0, wide: 0, armL: 0, armR: 0 }, 'io');
      eyes(t, 1); let a = t.t; t.to(1600, { spin: 360 }, 'io').to(1, { spin: 0 }, 'l'); t.at(a).to(700, { wrap: 0.7 }, 'io');                          // foil twirl: the wrapper slips ...
      t.at(a + 1601).to(250, { blush: 0.9, wide: 0.5, lx: 0 }, 'o').to(500, { wrap: 0, armL: 30, armR: 30 }, 'io').to(300, { armL: 0, armR: 0, wide: 0 }, 'io'); // ... he tugs it back up, blushing
      t.to(70, { tw: 1.2, tilt: 4, armR: 90 }, 'l').to(200, { tw: 0, winkR: 1 }, 'o').wait(300).to(250, { tilt: 0, armR: 0, winkR: 0, blush: 0 }, 'io');
      return t.rest(300).loop({ stretch: 0.6 }); })(), 'Snap and Melt', 'Stiff robot snaps with his segments flashing (a bar can\'t bend), a segment light show, melts into a gooey sway, SNAPS back into a bar, a foil twirl where his wrapper slips and he tugs it back up blushing, then a snap pose and a wink.'],
    // Scoop: balanced on the point of his cone - rocks on the tip, spins like a spinning top and wobbles down, swirls up tall like soft-serve,
    // juggles his cherry, a brr shiver
    scoop: [(() => { const t = TL({ smile: 0.9 }), B = 500;
      for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; eyes(t, d); t.to(B - 110, { tilt: d * 13, armL: d > 0 ? 70 : 10, armR: d < 0 ? 70 : 10, chb: 1, htilt: -d * 4 }, 'io'); } // rocks on the tip, arms out for balance
      t.to(350, { tilt: 0, armL: 0, armR: 0, chb: 0, htilt: 0, lx: 0 }, 'io');
      t.to(260, { twist: -0.4, sq: 0.08 }, 'io'); let a = t.t; t.to(1800, { spin: 1080, twist: 0, sq: 0, armL: 60, armR: 60 }, 'o').to(1, { spin: 0 }, 'l'); // spinning top ...
      t.at(a).osc(1800, 6, { tilt: 5, chb: 1 }, { tilt: -5, chb: 0 }, 'io'); t.at(a + 1801); [8, -6, 4, -2, 0].forEach(v => t.to(150, { tilt: v }, 'io')); // ... the precession wobble, wobbling down
      t.to(200, { armL: 0, armR: 0 }, 'io');
      a = t.t; t.to(1400, { sq: -0.16, lift: 3, spin: 360, armL: 140, armR: 140, hap: 1 }, 'io').to(1, { spin: 0 }, 'l').to(400, { sq: 0.06, lift: 0, armL: 20, armR: 20 }, 'i').to(250, { sq: 0, armL: 0, armR: 0, hap: 0 }, 'io'); // swirls up tall like soft-serve
      for (let i = 0; i < 3; i++) t.to(140, { chy: 1.1, ly: -0.9, pitch: 0.12, sq: 0.04 }, 'o').to(300, { chy: 0, ly: -0.2, pitch: 0, sq: 0 }, 'i');      // cherry juggle, eyes up with it
      t.to(150, { ly: 0, close: 0.4 }, 'io'); shake(t, { P: 70, env: [0.4, 0.8, 1, 0.7, 0.4, 0.2], head: 0.1, roll: 2, body: 0.5 });                     // brr
      t.to(160, { close: 0, winkR: 1 }, 'io').e('emit', 'heart', 'head', 1).wait(300).to(200, { winkR: 0 }, 'io');
      return t.rest(300).loop({ stretch: 0.6 }); })(), 'Spinning Top Swirl', 'Rocks on the point of his cone with his arms out for balance, spins like a spinning top and wobbles down, swirls up tall like soft-serve, juggles his cherry, a cold shiver and a wink.'],
    // Boba: a cup - the cocktail-shaker shake (pearls flying), the straw goes up like a periscope and looks around, slurps a pearl up the straw
    // and pops it out, a whirlpool twirl (the pearls swirl), pearl drums
    boba: [(() => { const t = TL({ smile: 0.9 }), B = 500;
      t.to(200, { sq: 0.1, armL: 120, armR: 120, hap: 1 }, 'io'); t.osc(1600, 8, { lift: 4, sq: -0.08, pop: 2, swirl: 1.5 }, { lift: 0, sq: 0.06, pop: 0.5, swirl: -1.5 }, 'io'); // cocktail shaker
      t.to(250, { lift: 0, sq: 0, pop: 0, swirl: 0, armL: 0, armR: 0, hap: 0 }, 'io');
      t.to(300, { sup: 1.4, ly: -0.6 }, 'o'); eyes(t, -1); t.to(400, { stw: 1, hyaw: -0.15 }, 'io').wait(300); eyes(t, 1); t.to(500, { stw: -1, hyaw: 0.15 }, 'io').wait(300) // periscope: the straw goes up and looks around
        .to(400, { sup: 0, stw: 0, hyaw: 0, lx: 0, ly: 0 }, 'io');
      t.to(300, { slurp: 1, mw: 0.5, sq: 0.06 }, 'io').wait(500).to(100, { slurp: 0, sup: 0.9, pop: 1.5, sq: -0.08, mw: 1, open: 0.3 }, 'o').e('emit', 'bubble', 'head', 4) // slurp - POP
        .to(350, { sup: 0, pop: 0, sq: 0, open: 0 }, 'io');
      eyes(t, 1); let a = t.t; t.to(1500, { spin: 360, swirl: 3 }, 'io').to(1, { spin: 0 }, 'l').to(500, { swirl: 0, lx: 0 }, 'io');                 // whirlpool twirl, pearls swirling
      for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; t.to(120, { pop: 2, sq: 0.08, tilt: d * 3, armL: d < 0 ? 60 : 0, armR: d > 0 ? 60 : 0 }, 'o').to(B - 120, { pop: 0.2, sq: 0, tilt: 0 }, 'io'); } // pearl drums
      t.to(200, { armL: 0, armR: 0, pop: 0 }, 'io'); jump(t, { h: 7, ant: 150, up: 200, c: 0.14, arm: 70, air: { pop: 1.6, stw: 1 }, fall: { pop: 0, stw: 0 }, ev: [['emit', 'heart', 'head', 1]] });
      return t.rest(300).loop({ stretch: 0.6 }); })(), 'Bubble Tea Shaker', 'Shakes himself like a cocktail shaker with his pearls flying, his straw rises like a periscope and looks around, slurps a pearl up the straw and pops it out, a whirlpool twirl with the pearls swirling, pearl drums and a hop.'],
    // Chef Bun: he IS the dough - kneads himself, gets tossed and spins flat like pizza dough in the air, pops back into a bun, his hat tips on the
    // beat, a whisk, a chef's kiss and a hat-tip bow
    chefbun: [(() => { const t = TL({ smile: 0.9 }), B = 500;
      for (let i = 0; i < 4; i++) t.to(180, { armL: 120, armR: 120, sq: -0.04, hap: 1 }, 'io').to(B - 180, { armL: 15, armR: 15, sq: 0.24, close: 0.5 }, 'i').e('emit', 'dust', 'body', 1); // kneads himself
      t.to(250, { sq: 0.1, close: 0, hap: 0 }, 'io');
      eyes(t, 1); t.to(260, { sq: 0.26, pitch: -0.1, armL: -8, armR: -8, lx: 0 }, 'io');                                                                // crouch ...
      let a = t.t; t.to(380, { lift: 10 }, 'o').to(380, { lift: 0 }, 'i');                                                                               // ... tossed up in an arc ...
      t.at(a).to(70, { sq: -0.14 }, 'o').to(230, { sq: 0.32, armL: 165, armR: 165, wide: 0.5 }, 'io').to(460, { sq: 0.26, armL: 120, armR: 120 }, 'io'); // ... spinning FLAT like pizza dough
      t.at(a).to(760, { spin: 720 }, 'io'); t.at(a + 760).to(1, { spin: 0 }, 'l');
      t.to(80, { sq: 0.36, armL: 10, armR: 10 }, 'o').e('emit', 'dust', 'body', 4).to(150, { sq: -0.12, pitch: 0, wide: 0, armL: 30, armR: 30 }, 'o'); jelly(t, 0.09, 3, 260); // ... pops back into a bun
      t.to(200, { armL: 0, armR: 0 }, 'io');
      for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; t.to(140, { earL: -d * 26, earR: d * 26, htilt: d * 4, lx: d * 0.7, ly: -0.6 }, 'o').to(B - 140, { earL: -d * 18, earR: d * 18 }, 'io'); } // his hat tips on the beat, eyes up on it
      t.to(250, { earL: 0, earR: 0, htilt: 0, lx: 0, ly: 0 }, 'io');
      t.to(250, { armR: 70, armL: 40 }, 'io'); a = t.t; t.osc(1400, 7, { armR: 100, twist: 0.12 }, { armR: 45, twist: -0.12 }, 'io'); t.at(a); steps(t, 1400, 4, 1.8); // whisk + stir steps
      t.to(250, { armR: 0, armL: 0, twist: 0 }, 'io');
      t.to(300, o(hand(1, 13, -15), { armR: 20, close: 0.9 }), 'io').to(140, { open: 0.3, mw: 0.5, puff: -0.2 }, 'o')                                   // chef's kiss ...
        .to(220, o(hand(1, -4, -10), { armR: 80, open: 0.2, mw: 1, puff: 0 }), 'o').e('emit', 'spark', 'pawR', 3).wait(250).to(300, o(hand(1, 0, 0), { armR: 0, close: 0, open: 0 }), 'io');
      t.to(400, { pitch: -0.25, sq: 0.06, earL: 20, earR: -20, armL: 40 }, 'io').wait(300).to(400, { pitch: 0, sq: 0, earL: 0, earR: 0, armL: 0 }, 'io'); // ... and a hat-tip bow
      return t.rest(300).loop({ stretch: 0.6 }); })(), 'Pizza Dough Twirl', 'Kneads himself, gets tossed and spins flat like pizza dough in the air, pops back into a bun, his chef hat tips side to side on the beat, whisks and stirs, a chef\'s kiss and a hat-tip bow.'],
  };
  KEYS.forEach(k => { MOVES[k].dance = DANCES[k]; });
  KEYS.forEach(k => { MOVES[k].look = natF(1); });
  R.SNACKLIB = { natF, KEYS };
  install(MOVES, CARDS);
})();
