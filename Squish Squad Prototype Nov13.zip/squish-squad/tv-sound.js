// TvSound: little looping WebAudio soundtracks for the Living Room TV channels (only played when speakers are in the room).
// play(key, ch) ch 1 Squish Toons (bouncy cartoon tune), 2 Squish Cup (crowd, drums, whistle + goal cheer every 8 s), 3 Space Trip (echoing arpeggio + pad).
// stop(key), stopAll(), isOn(key)
(function () {
  if (window.TvSound) return;
  let AC = null, M = null, NB = null; const P = new Map();
  const ctx = () => { if (!AC) { const A = window.AudioContext || window.webkitAudioContext; if (!A) return null; AC = new A(); M = AC.createGain(); M.gain.value = 0.2; M.connect(AC.destination); } if (AC.state === 'suspended') AC.resume(); return AC; };
  const mid = n => 440 * Math.pow(2, (n - 69) / 12);
  const tone = (dest, t, f, d, type, v) => { const os = AC.createOscillator(), g = AC.createGain(); os.type = type; os.frequency.setValueAtTime(f, t); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    os.connect(g); (Array.isArray(dest) ? dest : [dest]).forEach(x => g.connect(x)); os.start(t); os.stop(t + d + 0.05); };
  const thump = (dest, t, v) => { const os = AC.createOscillator(), g = AC.createGain(); os.type = 'sine'; os.frequency.setValueAtTime(140, t); os.frequency.exponentialRampToValueAtTime(48, t + 0.18); g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.25); os.connect(g); g.connect(dest); os.start(t); os.stop(t + 0.3); };
  const noiseBuf = () => { if (NB) return NB; NB = AC.createBuffer(1, AC.sampleRate * 2, AC.sampleRate); const d = NB.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; return NB; };
  const clap = (dest, t, v) => { const s = AC.createBufferSource(), f = AC.createBiquadFilter(), g = AC.createGain(); s.buffer = noiseBuf(); f.type = 'bandpass'; f.frequency.value = 1500; g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12); s.connect(f); f.connect(g); g.connect(dest); s.start(t, Math.random()); s.stop(t + 0.15); };
  const SONG = {
    1: { st: 60 / 132 / 2, lead: [72, 76, 79, 76, 74, 77, 81, 77, 76, 79, 84, 79, 77, 74, 72, 0, 72, 72, 76, 79, 81, 79, 77, 76, 74, 77, 76, 74, 72, 0, 67, 0], bass: [48, 0, 55, 0, 50, 0, 57, 0, 52, 0, 55, 0, 53, 0, 48, 0], lt: 'triangle', bt: 'square', lv: 0.35, bv: 0.1 },
    3: { st: 60 / 96 / 2, lead: [64, 71, 76, 79, 76, 71, 67, 74, 79, 83, 79, 74, 64, 71, 76, 79, 62, 69, 74, 78, 74, 69, 66, 73, 78, 81, 78, 73, 62, 69, 74, 0], bass: [40, 0, 0, 0, 43, 0, 0, 0, 47, 0, 0, 0, 45, 0, 0, 0], lt: 'sine', bt: 'sine', lv: 0.28, bv: 0.22 },
  };
  function step(o) { const t = o.next, i = o.i;
    if (o.ch === 2) { const k = i % 64; // 0.125 s steps, 8 s loop; goal at ~5 s
      if (k % 8 === 0 || k % 8 === 3) thump(o.out, t, 0.5); if (k % 8 === 6) clap(o.out, t, 0.35);
      if (k === 2 || k === 48) [0, 0.09, 0.18].forEach(d => tone(o.out, t + d, 2900, 0.07, 'sine', 0.12));
      if (k === 40) { const g = o.cg.gain; g.cancelScheduledValues(t); g.setValueAtTime(g.value, t); g.linearRampToValueAtTime(0.75, t + 0.25); g.linearRampToValueAtTime(0.75, t + 1.6); g.linearRampToValueAtTime(0.22, t + 2.6); [72, 76, 79, 84].forEach((n, j) => tone(o.out, t + 0.1 + j * 0.12, mid(n), 0.3, 'square', 0.08)); }
      o.next += 0.125; }
    else { const S = SONG[o.ch] || SONG[1], n = S.lead[i % S.lead.length], b = S.bass[(i >> 1) % S.bass.length];
      if (n) tone(o.fx ? [o.out, o.fx] : o.out, t, mid(n), S.st * (o.ch === 3 ? 2.2 : 0.9), S.lt, S.lv);
      if (b && i % 2 === 0) tone(o.out, t, mid(b), S.st * (o.ch === 3 ? 7 : 1.6), S.bt, S.bv);
      if (o.ch === 1 && i % 4 === 2) clap(o.out, t, 0.12);
      o.next += S.st; }
    o.i++; }
  function play(key, ch) { if (!ctx()) return; const cur = P.get(key); if (cur && cur.ch === ch) return; if (cur) stop(key);
    const out = AC.createGain(); out.gain.setValueAtTime(0.0001, AC.currentTime); out.gain.exponentialRampToValueAtTime(1, AC.currentTime + 0.3); out.connect(M);
    const o = { ch, out, i: 0, next: AC.currentTime + 0.08, nodes: [] };
    if (ch === 2) { const s = AC.createBufferSource(), f = AC.createBiquadFilter(), g = AC.createGain(); s.buffer = noiseBuf(); s.loop = true; f.type = 'bandpass'; f.frequency.value = 900; f.Q.value = 0.6; g.gain.value = 0.22; s.connect(f); f.connect(g); g.connect(out); s.start(); o.cg = g; o.nodes.push(s); }
    if (ch === 3) { const d = AC.createDelay(1), fb = AC.createGain(); d.delayTime.value = 0.33; fb.gain.value = 0.38; d.connect(fb); fb.connect(d); d.connect(out); o.fx = d; }
    o.tm = setInterval(() => { while (o.next < AC.currentTime + 0.2) step(o); }, 40); P.set(key, o); }
  function stop(key) { const o = P.get(key); if (!o) return; P.delete(key); clearInterval(o.tm); const t = AC.currentTime; o.out.gain.cancelScheduledValues(t); o.out.gain.setValueAtTime(o.out.gain.value, t); o.out.gain.linearRampToValueAtTime(0.0001, t + 0.25);
    setTimeout(() => { o.nodes.forEach(n => { try { n.stop(); } catch (e) {} }); try { o.out.disconnect(); } catch (e) {} }, 400); }
  window.TvSound = { play, stop, isOn: k => P.has(k), stopAll: () => [...P.keys()].forEach(stop), keys: () => [...P.keys()] };
})();
