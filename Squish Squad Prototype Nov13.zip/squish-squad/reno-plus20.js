// Renovation Catalog round 20 — Living Room FLOORS remodel (same game style as the Movie Room floors in plus13).
// Floors = r.f20: 80 x 56 perspective trapezoid (the room stretches it over the floor). Details are laid out in flat floor space (u across, y depth)
// and mapped through W(u, y) = px(u, gv(y)) so rows shorten toward the back wall; creature scale (front edge ~ 4.7 m, a creature ~ 1 plank long).
// Rugs (LIV-017/037/057/077/097) = flat 3D floor pieces like the plus13 rugs (RD.H13 slab/top/face): N.mat20, jute20, pers20, silk20, fiber20.
// Sets RenoDraw.PLUS20; catalog edits RD.SET20.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS19 && RD.H13 && RD.H10 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS20) return;
  const shade = X.K.shade, PI = Math.PI, H = RD.H10;
  const { rng, an, SPL, f1, n4, rep } = H;
  const { px, crv, fblot, FL } = RD.H13;
  const TR = 'M14 0H66L80 56H0Z';
  const wk = v => (52 + 28 * v) / 80, gv = t => t * (0.7 + 0.3 * t);
  const W = (u, y) => px(u, gv(y)), WP = (u, y) => { const p = W(u, y); return f1(p[0]) + ' ' + f1(p[1]); };
  const polyW = pts => 'M' + pts.map(([u, y]) => WP(u, y)).join('L') + 'Z';
  const lineW = pts => 'M' + pts.map(([u, y]) => WP(u, y)).join('L');
  const crvW = pts => crv(pts.map(([u, y]) => [u, gv(y)]));
  // irregular flat chip at floor point (u, y); r = radius at the front edge, shrinks + squashes toward the back
  const chip = (R, u, y, r, n) => { const p = W(u, y), v = gv(y), k = r * wk(v), sq = 0.5 + 0.2 * v, a0 = R() * 6.3; let d = '';
    for (let i = 0; i < n; i++) { const a = a0 + i * 2 * PI / n + (R() - 0.5) * 0.8, rr = k * (0.6 + R() * 0.55); d += (i ? 'L' : 'M') + f1(p[0] + rr * Math.cos(a)) + ' ' + f1(p[1] + rr * Math.sin(a) * sq); } return d + 'Z'; };
  const ell = (u, y, rx, ry, ex) => { const p = W(u, y), k = wk(gv(y)); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(rx * k)}" ry="${f1(ry * k)}" ${ex}/>`; };
  // soft reflection of the back-wall window (left of centre) + the ceiling light, for shiny floors
  const refl = (op, col) => `<g filter="url(#fb3)"><path d="${polyW([[0.17, 0], [0.33, 0], [0.37, 0.5], [0.14, 0.5]])}" fill="${col || '#ffffff'}" opacity="${op}"/><path d="${polyW([[0.2, 0], [0.3, 0], [0.32, 0.3], [0.18, 0.3]])}" fill="${col || '#ffffff'}" opacity="${f1(op * 0.8)}"/>${ell(0.55, 0.22, 7, 2, `fill="${col || '#ffffff'}" opacity="${f1(op * 0.7)}"`)}</g>`;

  // LIV-005 scuffed linoleum sheet: beige faux-stone squares with little brown diamonds, a worn path, heel scuffs, a lifting seam, a burn and a torn spot
  function fLino() { const R = rng('lino20'), NU = 14, NV = 9, T = ['#dacfae', '#d2c5a1', '#ded4b6', '#cdbf99'];
    let s = '<rect width="80" height="56" fill="#b6a77f"/>', hi = '', lo = '', dia = '';
    for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const u0 = i / NU + 0.005, u1 = (i + 1) / NU - 0.005, y0 = j / NV + 0.008, y1 = (j + 1) / NV - 0.008;
      s += `<path d="${polyW([[u0, y0], [u1, y0], [u1, y1], [u0, y1]])}" fill="${T[(i * 7 + j * 3 + ((R() * 3) | 0)) % 4]}"/>`;
      hi += lineW([[u0, y1], [u0, y0], [u1, y0]]); lo += lineW([[u1, y0], [u1, y1], [u0, y1]]); }
    s += fblot('lino', 30, ['#e6dcc0', '#bfb08a', '#d8cba6'], 0.42, 6);
    s += `<path d="${hi}" stroke="#f4ecd6" stroke-width="0.28" fill="none" opacity="0.8"/><path d="${lo}" stroke="#a6976f" stroke-width="0.28" fill="none" opacity="0.7"/>`;
    for (let j = 1; j < NV; j++) for (let i = 1; i < NU; i++) { const u = i / NU, y = j / NV, a = 0.011, b = 0.017; dia += polyW([[u, y - b], [u + a, y], [u, y + b], [u - a, y]]); }
    s += `<path d="${dia}" fill="#8c7a54"/><path d="${dia}" fill="none" stroke="#c9b88e" stroke-width="0.12"/>`;
    s += rep(320, () => { const u = R(), y = R(), p = W(u, y); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1((0.1 + R() * 0.16) * wk(gv(y)))}" fill="${R() < 0.55 ? '#9a8b66' : '#efe7cf'}" opacity="0.7"/>`; }).join('');
    // yellowed edges + grime in the back corners
    s += `<path d="${TR}" fill="none" stroke="#b8974e" stroke-width="7" opacity="0.22" filter="url(#fb3)"/>` + '<g filter="url(#fb3)">' + ell(0.02, 0.05, 6, 3, 'fill="#6e5c3a" opacity="0.3"') + ell(0.98, 0.05, 6, 3, 'fill="#6e5c3a" opacity="0.3"') + '</g>';
    // worn traffic path from the front to the back-right
    const path = crvW([[0.4, 1.08], [0.44, 0.78], [0.54, 0.48], [0.62, 0.18], [0.64, -0.05]]);
    s += `<g filter="url(#fb3)"><path d="${path}" stroke="#8f805e" stroke-width="15" fill="none" opacity="0.13"/><path d="${path}" stroke="#f4eed9" stroke-width="9" fill="none" opacity="0.45"/></g>`;
    s += rep(20, () => { const y = R(), u = 0.36 + 0.26 * (1 - y) + (R() - 0.5) * 0.2, p = W(u, y), k = wk(gv(y)), l = (1 + R() * 2.4) * k, a = (R() - 0.5) * 1.4;
      return `<path d="M${f1(p[0])} ${f1(p[1])}q${f1(l * 0.5 * Math.cos(a))} ${f1(-0.4 * k)} ${f1(l * Math.cos(a))} ${f1(l * Math.sin(a) * 0.5)}" stroke="#36302a" stroke-width="${f1((0.16 + R() * 0.26) * k)}" stroke-linecap="round" fill="none" opacity="${f1(0.35 + R() * 0.35)}"/>`; }).join('');
    // sheet seam with the right sheet's edge lifting and curling up near the front
    s += `<path d="${lineW([[0.71, 0], [0.71, 1]])}" stroke="#f2ead2" stroke-width="0.2" opacity="0.8" transform="translate(0.18 0)"/><path d="${lineW([[0.71, 0], [0.71, 1]])}" stroke="#8a7b58" stroke-width="0.18" opacity="0.8"/>`;
    s += `<path d="${polyW([[0.703, 0.9], [0.71, 0.9], [0.71, 1.02], [0.698, 1.02]])}" fill="#000000" opacity="0.2" filter="url(#fb1)"/><path d="${polyW([[0.71, 0.88], [0.713, 0.92], [0.716, 1.02], [0.71, 1.02]])}" fill="#3e3326"/>`;
    s += `<path d="${polyW([[0.711, 0.88], [0.715, 0.92], [0.719, 1.02], [0.714, 1.02], [0.711, 0.92]])}" fill="#e4d9bb" transform="translate(0 -0.45)"/><path d="${lineW([[0.711, 0.88], [0.715, 0.93], [0.718, 1.02]])}" stroke="#fbf6e8" stroke-width="0.28" fill="none" transform="translate(0 -0.5)"/>`;
    // iron burn mark
    s += ell(0.27, 0.42, 1.9, 0.85, 'fill="#8a5a32" opacity="0.4" filter="url(#fb1)"') + ell(0.27, 0.42, 0.9, 0.42, 'fill="#3a2416" opacity="0.7"') + ell(0.27, 0.42, 1.25, 0.58, 'fill="none" stroke="#5a3a20" stroke-width="0.2" opacity="0.6"');
    // torn spot showing plywood + a curled flap
    { const p = W(0.17, 0.87), k = wk(gv(0.87)), Q = rng('tear20'), pts = rep(11, i => { const a = i / 11 * 2 * PI, r = (0.75 + Q() * 0.45); return [p[0] + 2.6 * k * r * Math.cos(a), p[1] + 1.25 * k * r * Math.sin(a)]; }), d = 'M' + pts.map(q => f1(q[0]) + ' ' + f1(q[1])).join('L') + 'Z';
      s += `<path d="${d}" fill="#b08a58"/><path d="M${f1(p[0] - 2 * k)} ${f1(p[1] - 0.3 * k)}q${f1(2 * k)} ${f1(0.3 * k)} ${f1(4 * k)} 0M${f1(p[0] - 1.6 * k)} ${f1(p[1] + 0.5 * k)}q${f1(1.6 * k)} ${f1(-0.3 * k)} ${f1(3.4 * k)} 0" stroke="#7d5c38" stroke-width="0.18" fill="none"/>`
        + `<path d="${d}" fill="none" stroke="#f1ead4" stroke-width="0.35"/><path d="M${f1(pts[2][0])} ${f1(pts[2][1])}L${f1(p[0] + 3.6 * k)} ${f1(p[1] + 2.2 * k)}L${f1(pts[0][0])} ${f1(pts[0][1])}Z" fill="#000000" opacity="0.25" filter="url(#fb1)"/>`
        + `<path d="M${f1(pts[2][0])} ${f1(pts[2][1])}Q${f1(p[0] + 3.4 * k)} ${f1(p[1] + 0.4 * k)} ${f1(p[0] + 3.2 * k)} ${f1(p[1] + 1.8 * k)}L${f1(pts[0][0])} ${f1(pts[0][1])}Z" fill="#8f897d" stroke="#efe6cc" stroke-width="0.2"/>`; }
    return FL(s); }

  // LIV-025 click-lock oak laminate: honey planks, bevelled joints, staggered ends, the wood print repeats every 4 planks, satin sheen, light scratches
  function fLam() { const NP = 22, R = rng('lam20'), PC = ['#c99560', '#d4a36c', '#bf8b56', '#dbad78', '#c6915b', '#cf9c64'], L = 0.46;
    let s = '<rect width="80" height="56" fill="#5a3a1e"/>', gr = '', cat = '', ends = '', kn = '', jn = '';
    const PR = rep(4, k => { const Q = rng('lp20' + k); return { tone: k, lines: rep(4, () => ({ f: 0.1 + Q() * 0.8, a: 0.05 + Q() * 0.1, ph: Q() * 6, w: 1 + Q() * 2 })), cat: k % 2 ? null : { f: 0.35 + Q() * 0.3, y: 0.2 + Q() * 0.4 }, knot: k === 3 ? { f: 0.3 + Q() * 0.4, y: 0.3 + Q() * 0.4 } : null }; });
    let pi = 0;
    for (let i = 0; i < NP; i++) { const u0 = i / NP, u1 = (i + 1) / NP, cw = u1 - u0; let y = -((i * 0.37 + R() * 0.08) % L);
      jn += lineW([[u0, 0], [u0, 1]]);
      while (y < 1) { const P = PR[pi % 4], ya = Math.max(y, -0.02), yb = Math.min(y + L, 1.02); pi++;
        s += `<path d="${polyW([[u0, ya], [u1, ya], [u1, yb], [u0, yb]])}" fill="${shade(PC[(P.tone * 2 + i) % 6], 0.96 + R() * 0.08)}"/>`;
        P.lines.forEach(g => { gr += crvW(rep(7, j => { const t = j / 6; return [u0 + cw * Math.min(0.95, Math.max(0.05, g.f + g.a * Math.sin(t * g.w * 3 + g.ph))), y + t * L]; })); });
        if (P.cat) { const uc = u0 + cw * P.cat.f, yc = y + L * P.cat.y; for (let n = 1; n <= 3; n++) { const w = cw * 0.1 * n, h = L * 0.13 * n; cat += crvW([[uc - w, yc + h], [uc - w * 0.6, yc + h * 0.35], [uc, yc], [uc + w * 0.6, yc + h * 0.35], [uc + w, yc + h]]); } }
        if (P.knot) kn += ell(u0 + cw * P.knot.f, y + L * P.knot.y, 0.42, 0.2, 'fill="#6a4222" opacity="0.7"');
        if (y > 0) ends += lineW([[u0, y], [u1, y]]);
        y += L; } }
    s += `<path d="${gr}" stroke="#7a4c26" stroke-width="0.17" fill="none" opacity="0.22"/><path d="${cat}" stroke="#7a4c26" stroke-width="0.2" fill="none" opacity="0.32"/>${kn}`;
    s += fblot('lam', 16, ['#e6b884', '#9c6a3a'], 0.22, 8);
    s += `<path d="${jn}" stroke="#f3cf98" stroke-width="0.14" opacity="0.4" transform="translate(0.24 0)"/><path d="${jn}" stroke="#5e3a1c" stroke-width="0.2" opacity="0.85"/><path d="${ends}" stroke="#f3cf98" stroke-width="0.12" opacity="0.35" transform="translate(0 0.18)"/><path d="${ends}" stroke="#5e3a1c" stroke-width="0.2" opacity="0.85"/>`;
    s += rep(10, () => { const u = R(), y = 0.2 + R() * 0.8, p = W(u, y), k = wk(gv(y)), l = (1.5 + R() * 3) * k, a = (R() - 0.5) * 2.4; return `<path d="M${f1(p[0])} ${f1(p[1])}l${f1(l * Math.cos(a))} ${f1(l * Math.sin(a) * 0.5)}" stroke="#f7e2c0" stroke-width="0.1" opacity="0.45"/>`; }).join('');
    s += refl(0.16, '#fff3dc');
    return FL(s); }

  // LIV-045 solid white oak chevron parquet: pale oiled boards in a zigzag, straight border boards and a thin walnut inlay round the edge
  function fChev() { const R = rng('chev20'), PC = ['#dcc6a2', '#d0b58d', '#e4d1b0', '#c9ad84', '#d7be97', '#c2a47b'];
    const bu = 0.024, by = 0.04, ua = bu + 0.006, ub = 1 - bu - 0.006, ya = by + 0.009, NC = 12, cw = (ub - ua) / NC, d = cw * 1.7, p = 0.044;
    const tone = PC.map(() => ''); let grain = '', fleck = '', joints = '';
    for (let c = 0; c < NC; c++) { const u0 = ua + c * cw, u1 = u0 + cw, dl = c % 2 ? 0 : d, dr = c % 2 ? d : 0;
      for (let k = -Math.ceil(d / p) - 1; ya + k * p < 1.05; k++) { const y = ya + k * p; if (y + d + p < ya - 0.01) continue;
        const P = [[u0, y + dl], [u1, y + dr], [u1, y + dr + p], [u0, y + dl + p]], d0 = polyW(P); tone[(R() * 6) | 0] += d0; joints += d0;
        [0.28 + R() * 0.14, 0.62 + R() * 0.16].forEach(f => { const m = (R() - 0.5) * p * 0.18; grain += lineW([[u0, y + dl + p * f], [u0 + cw / 2, y + (dl + dr) / 2 + p * f + m], [u1, y + dr + p * f]]); });
        if (R() < 0.3) { const t0 = R() * 0.7, f = 0.35 + R() * 0.3, at = t => [u0 + cw * t, y + dl + (dr - dl) * t + p * f]; fleck += lineW([at(t0), at(t0 + 0.12 + R() * 0.1)]); } } }
    let s = `<defs><clipPath id="cvf"><path d="${polyW([[ua, ya], [ub, ya], [ub, 1.05], [ua, 1.05]])}"/></clipPath><clipPath id="cvb"><path d="${polyW([[0, -0.02], [1, -0.02], [1 - bu, by], [bu, by]])}"/></clipPath>`
      + `<clipPath id="cvl"><path d="${polyW([[0, -0.02], [bu, by], [bu, 1.05], [0, 1.05]])}"/></clipPath><clipPath id="cvr"><path d="${polyW([[1, -0.02], [1, 1.05], [1 - bu, 1.05], [1 - bu, by]])}"/></clipPath></defs><rect width="80" height="56" fill="#5e3f24"/>`;
    s += `<g clip-path="url(#cvf)">${tone.map((t, i) => `<path d="${t}" fill="${PC[i]}"/>`).join('')}<path d="${grain}" stroke="#9a7a52" stroke-width="0.14" fill="none" opacity="0.4"/><path d="${fleck}" stroke="#8a6a44" stroke-width="0.22" fill="none" opacity="0.45"/>`
      + `<path d="${joints}" fill="none" stroke="#8c6c48" stroke-width="0.18" opacity="0.85"/></g>`;
    // border boards: along the back (across) and down both sides, mitred in the back corners
    let bb = '', bj = '', bg = ''; for (let u = -0.05, n = 0; u < 1; u += 0.11, n++) { bb += `<path d="${polyW([[u, -0.02], [u + 0.11, -0.02], [u + 0.11, by], [u, by]])}" fill="${PC[(n * 2 + 1) % 6]}"/>`; bj += lineW([[u, -0.02], [u, by]]); }
    bg += lineW([[0, by * 0.35], [1, by * 0.35]]) + lineW([[0, by * 0.7], [1, by * 0.7]]);
    let sb = '', sj = '', sg = ''; [[0, bu], [1 - bu, 1]].forEach(([a, b], side) => { for (let y = -0.1 + side * 0.07, n = 0; y < 1.05; y += 0.2, n++) { sb += `<path d="${polyW([[a, y], [b, y], [b, y + 0.2], [a, y + 0.2]])}" fill="${PC[(n * 3 + side) % 6]}"/>`; sj += lineW([[a, y], [b, y]]); } sg += lineW([[a + (b - a) * 0.4, 0], [a + (b - a) * 0.4, 1.05]]); });
    s += `<g clip-path="url(#cvb)">${bb}<path d="${bg}" stroke="#9a7a52" stroke-width="0.14" opacity="0.4" fill="none"/><path d="${bj}" stroke="#8c6c48" stroke-width="0.18"/></g>`;
    ['cvl', 'cvr'].forEach(c => s += `<g clip-path="url(#${c})">${sb}<path d="${sg}" stroke="#9a7a52" stroke-width="0.14" opacity="0.4" fill="none"/><path d="${sj}" stroke="#8c6c48" stroke-width="0.18"/></g>`);
    s += `<path d="${lineW([[0, -0.02], [bu, by], [bu, 1.05]])}M${WP(1, -0.02)}L${WP(1 - bu, by)}L${WP(1 - bu, 1.05)}" stroke="#8c6c48" stroke-width="0.18" fill="none"/>`;
    s += fblot('chev', 18, ['#f2e4c8', '#b8986c'], 0.2, 8) + refl(0.12, '#fff8e8');
    return FL(s); }

  // LIV-065 polished terrazzo with radiant underfloor heating: cream base full of marble chips, brass divider strips, glossy reflections, a slow warm glow
  function fTerr() { const R = rng('terr20'), CH = [['#9b9a95', 25], ['#fbf8f2', 18], ['#c76f4c', 14], ['#93a88c', 12], ['#e2b39f', 12], ['#3f3e42', 10], ['#d6a647', 3], ['#b9c3c9', 6]], tot = CH.reduce((a, c) => a + c[1], 0), dd = CH.map(() => '');
    let s = '<defs><radialGradient id="t20h" cx="50%" cy="62%" r="65%"><stop offset="0" stop-color="#ff9a4a" stop-opacity="0.2"/><stop offset="1" stop-color="#ff9a4a" stop-opacity="0"/></radialGradient></defs><rect width="80" height="56" fill="#ece6da"/>' + fblot('terr', 26, ['#f4efe5', '#ddd4c4', '#ebe3d2'], 0.5, 8);
    // chips live in one 20 x 14 tile; the floor is cut into depth bands, each band repeats the tile scaled for its distance (smaller + flatter toward the back)
    const TW = 20, TH = 14; let fine = ['', ''];
    for (let i = 0; i < 520; i++) { const x = R() * TW, y = R() * TH, z = 0.12 + R() * 0.1; fine[i % 2] += `M${f1(x)} ${f1(y)}h${f1(z)}v${f1(z * 0.8)}h${f1(-z)}Z`; }
    for (let i = 0; i < 300; i++) { let q = R() * tot, c = 0; while (q > CH[c][1]) { q -= CH[c][1]; c++; } const z = R(), r = z < 0.14 ? 0.5 + R() * 0.3 : z < 0.5 ? 0.3 + R() * 0.2 : 0.15 + R() * 0.15, x = r + R() * (TW - 2 * r), y = r + R() * (TH - 2 * r), n = 5 + ((R() * 2) | 0), a0 = R() * 6.3;
      dd[c] += rep(n, j => { const a = a0 + j * 2 * PI / n + (R() - 0.5) * 0.8, rr = r * (0.6 + R() * 0.5); return (j ? 'L' : 'M') + f1(x + rr * Math.cos(a)) + ' ' + f1(y + rr * Math.sin(a)); }).join('') + 'Z'; }
    let pat = `<g id="tzc"><path d="${fine[0]}" fill="#a9a59c" opacity="0.6"/><path d="${fine[1]}" fill="#d9a88e" opacity="0.5"/>${dd.map((d, i) => `<path d="${d}" fill="${CH[i][0]}"/>`).join('')}</g>`, bandS = '';
    for (let b = 0; b < 10; b++) { const y0 = b / 10, y1 = (b + 1) / 10, vm = gv((y0 + y1) / 2), k = wk(vm) * 0.95, sq = 0.55 + 0.2 * vm;
      pat += `<pattern id="tz${b}" width="${TW}" height="${TH}" patternUnits="userSpaceOnUse" patternTransform="translate(${f1(b * 7.3)} ${f1(b * 3.1)}) scale(${n4(k)} ${n4(k * sq)})"><use href="#tzc"/></pattern>`;
      bandS += `<path d="${polyW([[-0.03, y0 - 0.002], [1.03, y0 - 0.002], [1.03, b === 9 ? 1.05 : y1], [-0.03, b === 9 ? 1.05 : y1]])}" fill="url(#tz${b})"/>`; }
    s += `<defs>${pat}</defs>${bandS}`;
    // underfloor heating: the pipe loops warm the stone in a slow pulse
    const loop = []; for (let j = 0, y = 0.08; y < 1.02; j++, y += 0.13) { const a = j % 2 ? 0.94 : 0.06, b = j % 2 ? 0.06 : 0.94; loop.push([a, y], [b, y], [b, y + 0.065]); }
    s += `<path d="${TR}" fill="url(#t20h)">${an('opacity', '0.35;1;0.35', 8, 0, SPL(2))}</path><path d="${crvW(loop)}" stroke="#ff8a3a" stroke-width="2.6" fill="none" opacity="0.04" filter="url(#fb3)">${an('opacity', '0.03;0.13;0.03', 8, 0, SPL(2))}</path>`;
    // brass divider strips: big panels
    let br = ''; [0.25, 0.5, 0.75].forEach(u => br += lineW([[u, 0], [u, 1.02]])); [1 / 3, 2 / 3].forEach(y => br += lineW([[0, y], [1, y]]));
    s += `<path d="${br}" stroke="#9a7024" stroke-width="0.48" fill="none"/><path d="${br}" stroke="#e8c472" stroke-width="0.22" fill="none"/><path d="${br}" stroke="#fff0b8" stroke-width="0.1" fill="none" transform="translate(-0.08 -0.1)"/>`;
    s += refl(0.3);
    return FL(s); }

  // LIV-085 seamless heated onyx: one honey-coloured slab with cloudy translucent bands, lit from below, thin gold veins with pulses of light running along them
  function fOnyx() { const R = rng('onyx20'), BC = ['#f6e2b4', '#d9a85e', '#f2d49a', '#c98f48', '#fbefd2', '#e3b56c', '#b8783a'];
    let s = '<defs><radialGradient id="ox20" cx="50%" cy="62%" r="62%"><stop offset="0" stop-color="#ffe0a0" stop-opacity="0.55"/><stop offset="1" stop-color="#ffe0a0" stop-opacity="0"/></radialGradient></defs><rect width="80" height="56" fill="#e3bb78"/>';
    let bands = '<g filter="url(#fb2)">', lines = '';
    const band = (c, ph, ph2, o) => rep(13, j => { const x = -0.05 + j * 0.1; return [x, c + 0.42 * x - 0.18 * x * x + 0.035 * Math.sin(2 * PI * 1.2 * x + ph) + 0.015 * Math.sin(2 * PI * 3.3 * x + ph2) + (o || 0)]; });
    for (let c = -0.6; c < 1.25; c += 0.04 + R() * 0.05) { const ph = R() * 6, ph2 = R() * 6, d = crvW(band(c, ph, ph2));
      bands += `<path d="${d}" stroke="${BC[(R() * BC.length) | 0]}" stroke-width="${f1(1 + R() * 3.4)}" fill="none" opacity="${f1(0.5 + R() * 0.4)}"/>`;
      if (R() < 0.6) { const o = R() < 0.5, w = f1(0.08 + R() * 0.12); lines += `<path d="${d}" stroke="${o ? '#9a5e26' : '#fff6e2'}" stroke-width="${w}" fill="none" opacity="0.5"/>`; if (R() < 0.5) lines += `<path d="${crvW(band(c, ph, ph2, 0.006))}" stroke="${o ? '#9a5e26' : '#fff6e2'}" stroke-width="${w}" fill="none" opacity="0.35"/>`; } }
    s += bands + '</g>' + `<g filter="url(#fb3)">${rep(3, () => `<path d="${crvW(band(R() * 1.1 - 0.2, R() * 6, R() * 6))}" stroke="#a4602a" stroke-width="${f1(4 + R() * 4)}" fill="none" opacity="0.28"/>`).join('')}</g>` + lines + fblot('onyx', 20, ['#fff6e2', '#f9e0a8', '#c98a44'], 0.36, 7);
    s += `<path d="${TR}" fill="url(#ox20)">${an('opacity', '0.45;1;0.45', 7, 0, SPL(2))}</path>`;
    // gold veins: thin jagged cracks (not smooth lines), a soft glow that breathes and a small spark of light running along each
    const vein = (pts, i, w) => { const d = lineW(pts);
      return `<path d="${d}" stroke="#ffc94a" stroke-width="${f1(1.3 * w)}" fill="none" opacity="0.3" stroke-linejoin="round" filter="url(#fb2)">${an('opacity', '0.15;0.55;0.15', 4, -i * 0.9, SPL(2))}</path><path d="${d}" stroke="#a8761f" stroke-width="${f1(0.32 * w)}" fill="none" stroke-linejoin="round"/><path d="${d}" stroke="#ffe08a" stroke-width="${f1(0.15 * w)}" fill="none" stroke-linejoin="round"/>`
        + `<path d="${d}" pathLength="100" stroke="#fff3c0" stroke-width="${f1(1.1 * w)}" stroke-linecap="round" stroke-dasharray="2.5 97.5" fill="none" filter="url(#fb1)"><animate attributeName="stroke-dashoffset" values="0;-100" dur="${n4(6 + i * 0.8)}s" begin="${n4(-i * 1.7)}s" repeatCount="indefinite"/></path>`; };
    const walk = (u, y, y1, du, jit, st) => { const pts = [[u, y]]; while (y < y1) { y += st * (0.5 + R()); u += (R() - 0.5) * jit + du; pts.push([u, y]); } return pts; };
    [[0.16, 0.02], [0.52, -0.03], [0.83, 0.01]].forEach(([u0, du], k) => { const pts = walk(u0, -0.06, 1.05, du * 0.3, 0.035, 0.035); s += vein(pts, k, 1);
      rep(3, j => { const q = pts[3 + ((R() * (pts.length - 6)) | 0)]; s += vein(walk(q[0], q[1], q[1] + 0.1 + R() * 0.12, (R() < 0.5 ? -1 : 1) * 0.012, 0.025, 0.025), k * 3 + j + 3, 0.6); }); });
    s += refl(0.24, '#fff8e4');
    return FL(s); }

  const FLOOR20 = { lino: fLino, lam: fLam, chev: fChev, terr: fTerr, onyx: fOnyx }, MEMO = {};
  const draw19 = RD.draw;
  RD.draw = (r, o) => { const res = draw19(r, o); if (!res || res._p20) return res;
    try { const f = r.f20 && FLOOR20[r.f20]; if (f && res.surf) { res._p20 = 1; res.vb = '0 0 80 56'; res.svg = MEMO[r.f20] || (MEMO[r.f20] = RD.svgDoc('0 0 80 56', [], f())); res.src = 'data:image/svg+xml,' + encodeURIComponent(res.svg); } } catch (e) { console.warn('reno plus20', r.id, e); }
    return res; };


  // ======================= RUGS (flat floor pieces, same build as the plus13 Movie Room rugs) =======================
  const N = RD.N, { cam } = H, { slab, top, face, rrP, dP, ellP } = RD.H13;
  const DEF20 = '<filter id="r13b" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="1.6"/></filter><filter id="r13s" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="0.5"/></filter><filter id="r20g" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.1"/></filter>';
  const RUG = (w, d, o) => Object.assign({ w, d, flat: 1, noBlock: 1, build: () => [] }, o || {});
  const smooth = P => { const m = (a, b) => f1((a[0] + b[0]) / 2) + ' ' + f1((a[1] + b[1]) / 2), n = P.length; let d = 'M' + m(P[n - 1], P[0]); for (let i = 0; i < n; i++) d += 'Q' + f1(P[i][0]) + ' ' + f1(P[i][1]) + ' ' + m(P[i], P[(i + 1) % n]); return d + 'Z'; };
  const blob = (R, cx, cz, rx, rz, k) => { const p1 = R() * 6, p2 = R() * 6, a = k || 0.2; return smooth(rep(22, i => { const t = i / 22 * 2 * PI, r = 1 + a * Math.sin(2 * t + p1) + a * 0.5 * Math.sin(3 * t + p2); return [cx + rx * r * Math.cos(t), cz + rz * r * Math.sin(t)]; })); };
  // fringe along both short ends (x = +-W/2): wavy strands, knotted in bunches
  const fringe = (R, W, Dd, col, n, L) => { let s = ''; [-1, 1].forEach(sx => { for (let z = -Dd / 2 + 2; z <= Dd / 2 - 2; z += n) { const l = L * (0.8 + R() * 0.4), x0 = sx * W / 2, w = (R() - 0.5) * 1.6;
      s += '<path d="M' + f1(x0) + ' ' + f1(z) + 'q' + f1(sx * l * 0.5) + ' ' + f1(w) + ' ' + f1(sx * l) + ' ' + f1(w * 0.4) + '" stroke="' + shade(col, 0.72) + '" stroke-width="0.75" fill="none" stroke-linecap="round"/><path d="M' + f1(x0) + ' ' + f1(z) + 'q' + f1(sx * l * 0.5) + ' ' + f1(w) + ' ' + f1(sx * l) + ' ' + f1(w * 0.4) + '" stroke="' + col + '" stroke-width="0.45" fill="none" stroke-linecap="round"/>'; } }); return s; };

  // LIV-017 thin synthetic coir-look welcome mat used as a rug: needle-punched ribs, rubber edge, worn WELCOME letters, a bald patch, a corner folded over, crumbs
  N.mat20 = S => { const W = 118, Dd = 70, T = 0.8, c = 13, P = [[-W / 2, -Dd / 2], [W / 2, -Dd / 2], [W / 2, Dd / 2 - c], [W / 2 - c, Dd / 2], [-W / 2, Dd / 2]];
    const D = RUG(124, 76);
    D.fx = ctx => { const C = cam(ctx), R = rng('mat20'), id = C.u('wm');
      let art = '<rect x="' + (-W / 2) + '" y="' + (-Dd / 2) + '" width="' + W + '" height="' + Dd + '" fill="#2d2b29"/><rect x="' + (-W / 2 + 3.4) + '" y="' + (-Dd / 2 + 3.4) + '" width="' + (W - 6.8) + '" height="' + (Dd - 6.8) + '" rx="1.4" fill="#b98b55"/>';
      let rb = '', rd = ''; for (let z = -Dd / 2 + 4; z < Dd / 2 - 3.4; z += 1.25) { rb += 'M' + (-W / 2 + 3.4) + ' ' + f1(z) + 'H' + (W / 2 - 3.4); rd += 'M' + (-W / 2 + 3.4) + ' ' + f1(z + 0.55) + 'H' + (W / 2 - 3.4); }
      art += '<path d="' + rb + '" stroke="#8e6538" stroke-width="0.42"/><path d="' + rd + '" stroke="#d8ad74" stroke-width="0.28" opacity="0.7"/>';
      art += '<g filter="url(#r13b)">' + rep(10, i => '<ellipse cx="' + f1((R() - 0.5) * W * 0.8) + '" cy="' + f1((R() - 0.5) * Dd * 0.7) + '" rx="' + f1(6 + R() * 8) + '" ry="' + f1(3 + R() * 5) + '" fill="' + (i % 2 ? '#d2a46a' : '#8a5f34') + '" opacity="0.35"/>').join('') + '</g>';
      const tx = st => '<text x="0" y="6" text-anchor="middle" font-family="\'Arial Black\',Arial,sans-serif" font-weight="900" font-size="15" letter-spacing="1.2" textLength="84" lengthAdjust="spacingAndGlyphs" ' + st + '>WELCOME</text>';
      art += '<defs><mask id="' + id + 'm"><rect x="-60" y="-40" width="120" height="80" fill="#ffffff"/>' + rep(140, () => '<circle cx="' + f1((R() - 0.5) * 90) + '" cy="' + f1((R() - 0.5) * 22) + '" r="' + f1(0.25 + R() * 0.7) + '" fill="#000000"/>').join('') + '<ellipse cx="-12" cy="2" rx="13" ry="7" fill="#000000" opacity="0.7" filter="url(#r13b)"/></mask></defs>';
      art += '<g mask="url(#' + id + 'm)">' + tx('fill="#3d2410" opacity="0.88"') + '</g>';
      [[-46, -20], [46, 20]].forEach(([x, z], i) => art += '<g transform="translate(' + x + ' ' + z + ') rotate(' + (i ? 160 : -20) + ')" fill="#3d2410" opacity="0.55"><ellipse cx="0" cy="2" rx="3" ry="2.4"/><circle cx="-3" cy="-1.6" r="1"/><circle cx="-1" cy="-3" r="1"/><circle cx="1.4" cy="-3" r="1"/><circle cx="3.2" cy="-1.4" r="1"/></g>');
      art += '<ellipse cx="-14" cy="3" rx="15" ry="9" fill="#d8b27e" opacity="0.5" filter="url(#r13b)"/>';
      art += rep(16, () => { const x = (R() - 0.5) * (W - 12), z = (R() - 0.5) * (Dd - 12); return '<circle cx="' + f1(x) + '" cy="' + f1(z) + '" r="' + f1(0.3 + R() * 0.45) + '" fill="' + (R() < 0.5 ? '#e8c890' : '#5a3a1e') + '"/>'; }).join('');
      art += rep(3, () => { const x = (R() - 0.5) * (W - 16), z = (R() - 0.5) * (Dd - 16); return '<path d="M' + f1(x) + ' ' + f1(z) + 'q3 -2 6 0.4" stroke="#f4efe6" stroke-width="0.3" fill="none" opacity="0.8"/>'; }).join('');
      // folded-over corner: rubber backing with its grip nubs shows, soft shadow under the flap
      const a = [W / 2, Dd / 2 - c], b = [W / 2 - c, Dd / 2], f = [W / 2 - c, Dd / 2 - c], fl = 'M' + a.join(' ') + 'L' + f.join(' ') + 'L' + b.join(' ') + 'Z';
      let flap = '<path d="' + fl + '" fill="#000000" opacity="0.35" transform="translate(-1.2 -0.6)" filter="url(#r13s)"/><path d="' + fl + '" fill="#2a2827"/>';
      for (let i = 1; i < 6; i++) for (let k = 1; k < 6 - i; k++) flap += '<circle cx="' + f1(W / 2 - c + k * c / 6) + '" cy="' + f1(Dd / 2 - c + i * c / 6) + '" r="0.45" fill="#474442"/>';
      flap += '<path d="M' + a.join(' ') + 'L' + b.join(' ') + '" stroke="#5a5552" stroke-width="0.7"/><path d="M' + f1(a[0] - 1.2) + ' ' + f1(a[1] - 0.4) + 'L' + f1(f[0] + 0.6) + ' ' + f1(f[1] + 0.6) + '" stroke="#5a5552" stroke-width="0.4"/>';
      const s = slab(C, P, T, '#2a2827') + top(C, T, face(id, P, art, 0.25) + flap);
      return { defs: DEF20, front: s, bb: C.bb(4) }; };
    return D; };

  // LIV-037 oval braided jute: chunky rope coils (each a lit braid), a wide black band with a cream zigzag, cream + black rings, a woven star in the middle, bobbing pompom trim
  N.jute20 = S => { const A = 94, B = 64, T = 2.4, P = ellP(A, B, 72);
    const D = RUG(204, 140, { round: 1 });
    D.fx = ctx => { const C = cam(ctx), id = C.u('jt'), JT = '#c9a46a', BK = '#2f2720', CR = '#f1e6cc', RW = 4.2;
      const PAT = [JT, JT, BK, BK, BK, JT, CR, JT, JT, BK, JT, JT, CR, CR, JT, BK, JT, JT, CR, JT];
      const rr = k => [A - RW / 2 - 0.4 - k * RW, B - RW / 2 - 0.4 - k * RW];
      let art = `<ellipse rx="${A}" ry="${B}" fill="#5a4428"/>`, k = 0;
      for (; ; k++) { const [rx, ry] = rr(k); if (ry < 12) break; const c = PAT[k % PAT.length], E = (dx, w, ex) => `<ellipse rx="${f1(rx + dx)}" ry="${f1(ry + dx)}" fill="none" stroke-width="${f1(w)}" ${ex}/>`;
        art += E(0.5, RW, 'stroke="#000000" stroke-opacity="0.35"') + E(0, RW - 0.5, `stroke="${c}"`)
          + E(RW * 0.22, RW * 0.42, `stroke="${shade(c, 0.66)}" stroke-dasharray="1.1 1.3" stroke-dashoffset="${f1(k * 0.7)}" opacity="0.75"`)
          + E(-RW * 0.22, RW * 0.42, `stroke="${shade(c, 0.66)}" stroke-dasharray="1.1 1.3" stroke-dashoffset="${f1(k * 0.7 + 1.2)}" opacity="0.75"`)
          + E(-RW * 0.3, 0.5, `stroke="${c === BK ? '#6a5a4a' : shade(c, 1.3)}" stroke-dasharray="1.4 1" opacity="0.85"`); }
      { const [rx, ry] = rr(k); art += `<ellipse rx="${f1(rx + RW / 2)}" ry="${f1(ry + RW / 2)}" fill="${JT}"/><ellipse rx="${f1(rx + RW / 2)}" ry="${f1(ry + RW / 2)}" fill="none" stroke="${shade(JT, 0.66)}" stroke-width="${f1(ry * 2)}" stroke-dasharray="1.1 1.3" opacity="0.35"/>`; }
      const star = (r, col) => `<path d="${rep(16, i => { const a = i * PI / 8, q = i % 2 ? r * 0.45 : r; return (i ? 'L' : 'M') + f1(q * Math.cos(a)) + ' ' + f1(q * Math.sin(a) * 0.72); }).join('')}Z" fill="${col}"/>`;
      art += star(15, BK) + star(10.5, CR) + star(5, '#b5482f') + `<circle r="1.4" fill="${BK}"/>`;
      { const o = rr(2), i = rr(4), ro = [o[0] + RW / 2 - 0.8, o[1] + RW / 2 - 0.8], ri = [i[0] - RW / 2 + 0.8, i[1] - RW / 2 + 0.8], n = 64;
        const d = 'M' + rep(n + 1, q => { const t = q / n * 2 * PI, z = q % 2 ? ri : ro; return f1(z[0] * Math.cos(t)) + ' ' + f1(z[1] * Math.sin(t)); }).join('L');
        art += `<path d="${d}" fill="none" stroke="${CR}" stroke-width="1.5"/><path d="${d}" fill="none" stroke="#ffffff" stroke-width="0.4" opacity="0.5" transform="translate(-0.2 -0.3)"/>`; }
      { const q = rr(12.5); art += rep(52, i => { const t = i / 52 * 2 * PI; return `<circle cx="${f1(q[0] * Math.cos(t))}" cy="${f1(q[1] * Math.sin(t))}" r="0.75" fill="${BK}"/>`; }).join(''); }
      const pom = []; for (let i = 0; i < 28; i++) { const t = i / 28 * 2 * PI, q = [A * 1.035 * Math.cos(t), 2.2, B * 1.05 * Math.sin(t)]; pom.push([C.P(q)[1], i % 2 ? CR : BK, q, i]); }
      pom.sort((p, q) => p[0] - q[0]);
      const c0 = C.P([0, 0, 0])[1], pm = ([, col, q, i]) => `<g>${H.at('translate', '0 0;0 -0.7;0 0', 1.5 + (i % 3) * 0.3, -i * 0.23, SPL(2))}${H.sph(C, q, 2.5, col)}</g>`;
      const s = pom.filter(p => p[0] < c0).map(pm).join('') + slab(C, P, T, '#6e5432') + top(C, T, face(id, P, art, 0.2)) + pom.filter(p => p[0] >= c0).map(pm).join('');
      return { defs: DEF20, front: s, bb: C.bb(6) }; };
    return D; };

  // LIV-057 vintage Persian, overdyed crimson: gold-thread herati lattice, a big lobed navy + ivory medallion with pendants and arabesque curls, corner spandrels,
  // rosette vine border between reciprocal-triangle guards; the gold threads catch a moving shimmer, the velvet pile sheen drifts, knotted ivory tassels
  N.pers20 = S => { const W = 196, Dd = 128, T = 1.4, P = rrP(W, Dd, 1);
    const D = RUG(212, 132);
    D.fx = ctx => { const C = cam(ctx), R = rng('pers20'), id = C.u('ps'), FLD = '#a01f36', NV = '#1d2848', IV = '#f1e0bd', GD = 'GOLDX', TL = '#2d7a76', RS = '#e47b8f', FI = 18.4;
      const rect = (i, col) => `<rect x="${f1(-W / 2 + i)}" y="${f1(-Dd / 2 + i)}" width="${f1(W - 2 * i)}" height="${f1(Dd - 2 * i)}" fill="${col}"/>`;
      const along = (inset, step, fn) => { const L = [[-W / 2 + inset, -Dd / 2 + inset], [W / 2 - inset, -Dd / 2 + inset], [W / 2 - inset, Dd / 2 - inset], [-W / 2 + inset, Dd / 2 - inset]]; let o = '';
        L.forEach((a, i) => { const b = L[(i + 1) % 4], len = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.round(len / step), ux = (b[0] - a[0]) / len, uz = (b[1] - a[1]) / len, sl = len / n; for (let k = 0; k < n; k++) o += fn(a[0] + ux * (k + 0.5) * sl, a[1] + uz * (k + 0.5) * sl, ux, uz, k, sl); }); return o; };
      let defs = `<defs><linearGradient id="${id}s" gradientUnits="userSpaceOnUse" x1="-50" y1="-40" x2="-10" y2="40"><stop offset="0" stop-color="#fff4c8" stop-opacity="0"/><stop offset="0.5" stop-color="#fff4c8" stop-opacity="1"/><stop offset="1" stop-color="#fff4c8" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-140 0;-140 0;260 0" keyTimes="0;0.3;1" dur="6s" repeatCount="indefinite"/></linearGradient>`
        + `<linearGradient id="${id}v" gradientUnits="userSpaceOnUse" x1="-100" y1="0" x2="100" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffd8e0" stop-opacity="0.2"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-160 0;160 0;-160 0" dur="14s" repeatCount="indefinite"/></linearGradient>`
        + `<clipPath id="${id}f"><rect x="${f1(-W / 2 + FI)}" y="${f1(-Dd / 2 + FI)}" width="${f1(W - 2 * FI)}" height="${f1(Dd - 2 * FI)}"/></clipPath><pattern id="${id}k" width="1.2" height="1.2" patternUnits="userSpaceOnUse"><rect width="0.6" height="1" fill="#000000" opacity="0.07"/></pattern></defs>`;
      let art = rect(0, NV) + rect(2, IV) + rect(5.2, NV) + rect(15.6, IV) + rect(17.4, NV) + rect(FI, FLD), gold = '';
      art += `<path d="${along(2, 4, (x, z, ux, uz, k, s) => `M${f1(x - ux * s / 2)} ${f1(z - uz * s / 2)}L${f1(x + ux * s / 2)} ${f1(z + uz * s / 2)}L${f1(x - uz * 3.2)} ${f1(z + ux * 3.2)}Z`)}" fill="${FLD}"/>`;
      art += `<path d="${along(10.4, 5.5, (x, z, ux, uz, k, s) => { const sg = k % 2 ? 1 : -1; return `M${f1(x - ux * s / 2)} ${f1(z - uz * s / 2)}Q${f1(x - uz * 3 * sg)} ${f1(z + ux * 3 * sg)} ${f1(x + ux * s / 2)} ${f1(z + uz * s / 2)}`; })}" stroke="${TL}" stroke-width="0.9" fill="none"/>`;
      art += along(10.4, 11, (x, z) => `<g transform="translate(${f1(x)} ${f1(z)})">${rep(8, q => `<ellipse cy="-2.2" rx="1.1" ry="2.2" fill="${q % 2 ? RS : '#c9465e'}" transform="rotate(${q * 45})"/>`).join('')}<circle r="1.4" fill="${IV}"/></g>`);
      gold += along(10.4, 11, (x, z) => `<circle cx="${f1(x)}" cy="${f1(z)}" r="0.8" fill="${GD}"/>`) + along(10.4, 11, (x, z, ux, uz, k, s) => `<path d="M${f1(x + ux * s / 2)} ${f1(z + uz * s / 2 - 1.6)}l1.3 1.6l-1.3 1.6l-1.3 -1.6Z" fill="${GD}"/>`);
      art += `<path d="${along(16.5, 2.6, (x, z) => `M${f1(x - 0.5)} ${f1(z)}a0.5 0.5 0 1 0 1 0a0.5 0.5 0 1 0 -1 0Z`)}" fill="${NV}"/>`;
      // field: herati lattice of gold threads + little ivory flowers at the crossings
      let lat = '', fl = ''; for (let c = -18; c <= 18; c++) lat += `M${c * 12} ${-Dd / 2}l${f1(Dd * 1.2)} ${Dd}M${c * 12} ${-Dd / 2}l${f1(-Dd * 1.2)} ${Dd}`;
      for (let i = -16; i <= 16; i++) for (let j = -7; j <= 7; j++) { if ((i + j) % 2) continue; const x = 6 * i, z = 5 * j + Dd / 2 - Math.floor(Dd / 10) * 5; if (Math.abs(x) > W / 2 - FI || Math.abs(z) > Dd / 2 - FI || (x / 70) ** 2 + (z / 40) ** 2 < 1) continue;
        fl += `<g transform="translate(${f1(x)} ${f1(z)})">${rep(4, q => `<ellipse cy="-1.3" rx="0.7" ry="1.3" fill="${IV}" transform="rotate(${q * 90 + 45})"/>`).join('')}<circle r="0.6" fill="${TL}"/></g>`; }
      gold += `<g clip-path="url(#${id}f)"><path d="${lat}" stroke="${GD}" stroke-width="0.45" fill="none" opacity="0.8"/></g>`;
      // corner spandrels
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => { const cx = sx * (W / 2 - FI), cz = sz * (Dd / 2 - FI), lob = k => smooth(rep(11, i => { const t = i / 10 * PI / 2, r = k * (1 + 0.1 * Math.cos(8 * t)); return [cx - sx * r * 32 * Math.cos(t), cz - sz * r * 22 * Math.sin(t)]; }).concat([[cx, cz]]));
        art += `<path d="${lob(1)}" fill="${NV}"/><path d="${lob(0.78)}" fill="${IV}"/><path d="${lob(0.62)}" fill="${TL}"/>`; gold += `<path d="${lob(0.4)}" fill="${GD}"/>`; });
      art += gold.replace(/GOLDX/g, '#e3b24c') + fl; gold = '';
      // medallion with pendants
      const lobe = (k, n, a, col) => `<path d="${smooth(rep(n * 4, i => { const t = i / (n * 4) * 2 * PI, r = k * (1 - a + a * Math.abs(Math.cos(n * t / 2))); return [54 * r * Math.cos(t), 35 * r * Math.sin(t)]; }))}" fill="${col}"/>`;
      [-1, 1].forEach(sx => { art += `<path d="M${sx * 46} -8L${sx * 60} -4.5L${sx * 67} 0L${sx * 60} 4.5L${sx * 46} 8Z" fill="${NV}"/><path d="M${sx * 50} -4L${sx * 59} -2.2L${sx * 63} 0L${sx * 59} 2.2L${sx * 50} 4Z" fill="${IV}"/>`; gold += `<circle cx="${sx * 70}" cy="0" r="2.2" fill="${GD}"/><path d="M${sx * 52} 0H${sx * 61}" stroke="${GD}" stroke-width="0.9"/>`; });
      art += lobe(1, 16, 0.12, NV) + lobe(0.9, 16, 0.12, IV) + lobe(0.8, 16, 0.1, FLD);
      art += rep(12, i => { const a = i * PI / 6, x = 54 * 0.68 * Math.cos(a), z = 35 * 0.68 * Math.sin(a); return `<path d="M${f1(x)} ${f1(z)}q1.6 -2.2 3.2 -0.4q0.8 1.4 -0.6 1.8" stroke="${IV}" stroke-width="0.6" fill="none" transform="rotate(${f1(a * 180 / PI)} ${f1(x)} ${f1(z)})"/>`; }).join('');
      gold += `<path d="${rep(16, i => { const a = i * PI / 8, q = i % 2 ? 0.34 : 0.58; return (i ? 'L' : 'M') + f1(54 * q * Math.cos(a)) + ' ' + f1(35 * q * Math.sin(a)); }).join('')}Z" fill="${GD}"/>`;
      const med = lobe(0.36, 8, 0.2, NV) + lobe(0.24, 8, 0.2, TL) + lobe(0.12, 8, 0.2, RS);
      art += gold.replace(/GOLDX/g, '#e3b24c') + med;
      // shimmer over every gold thread
      const shine = gold.replace(/GOLDX/g, `url(#${id}s)`);
      art += shine + `<circle r="1.6" fill="#e3b24c"/>`;
      art += `<rect x="${-W / 2}" y="${-Dd / 2}" width="${W}" height="${Dd}" fill="url(#${id}k)"/><rect x="${-W / 2}" y="${-Dd / 2}" width="${W}" height="${Dd}" fill="url(#${id}v)"/>`;
      art += rep(5, () => { const x = (R() - 0.5) * W, w = 4 + R() * 10; return `<rect x="${f1(x)}" y="${-Dd / 2}" width="${f1(w)}" height="${Dd}" fill="${R() < 0.5 ? '#ffffff' : '#3a0a1c'}" opacity="0.05"/>`; }).join('');
      let tas = ''; [-1, 1].forEach(sx => { for (let z = -Dd / 2 + 2.6; z <= Dd / 2 - 2.6; z += 3.6) { const x0 = sx * W / 2, L = 5.4 + R() * 1.8, w = (R() - 0.5) * 1.2;
        rep(3, q => { const dz = (q - 1) * 0.55, d = `M${f1(x0 + sx * 1.4)} ${f1(z)}q${f1(sx * L * 0.5)} ${f1(dz + w)} ${f1(sx * L)} ${f1(dz * 1.8 + w * 0.5)}`; tas += `<path d="${d}" stroke="#c9b48e" stroke-width="0.7" fill="none" stroke-linecap="round"/><path d="${d}" stroke="${IV}" stroke-width="0.38" fill="none" stroke-linecap="round"/>`; });
        tas += `<ellipse cx="${f1(x0 + sx * 1.3)}" cy="${f1(z)}" rx="1.1" ry="0.95" fill="#e6d3ab" stroke="#b39d74" stroke-width="0.2"/>`; } });
      const s = slab(C, P, T, '#1a2140') + top(C, T * 0.5, tas) + top(C, T, defs + face(id, P, art, 0.24));
      return { defs: DEF20, front: s, bb: C.bb(6) }; };
    return D; };

  // LIV-077 hand-knotted silk + wool abstract: a free-form pebble-shaped rug, deep teal / rust / mustard / blush / charcoal islands in raised high pile
  // with carved grooves and contour channels, crossed by iridescent silk rivers whose colour flows and a glint that runs along them
  N.silk20 = S => { const A = 104, B = 68, T = 2.6, rO = t => 1 + 0.05 * Math.sin(2 * t + 0.7) + 0.035 * Math.sin(3 * t + 2.1) + 0.02 * Math.sin(5 * t + 4.4), P = rep(72, i => { const t = i / 72 * 2 * PI, r = rO(t); return [A * r * Math.cos(t), B * r * Math.sin(t)]; });
    const D = RUG(226, 152, { round: 1 });
    D.fx = ctx => { const C = cam(ctx), R = rng('silk20'), id = C.u('sk');
      let art = `<defs><linearGradient id="${id}i" gradientUnits="userSpaceOnUse" x1="-100" y1="0" x2="100" y2="0" spreadMethod="repeat"><stop offset="0" stop-color="#ffd27a"/><stop offset="0.33" stop-color="#ff9ec4"/><stop offset="0.66" stop-color="#8fe4ff"/><stop offset="1" stop-color="#ffd27a"/><animateTransform attributeName="gradientTransform" type="translate" values="0 0;200 0" dur="7s" repeatCount="indefinite"/></linearGradient>`
        + `<pattern id="${id}p" width="1.3" height="1.3" patternUnits="userSpaceOnUse"><circle cx="0.4" cy="0.4" r="0.32" fill="#000000" opacity="0.07"/><circle cx="1" cy="1" r="0.28" fill="#ffffff" opacity="0.1"/></pattern></defs>`;
      art += `<path d="${dP(P)}" fill="#efe7d8"/>` + '<g filter="url(#r13b)">' + rep(10, i => `<ellipse cx="${f1((R() - 0.5) * A * 1.6)}" cy="${f1((R() - 0.5) * B * 1.6)}" rx="${f1(12 + R() * 14)}" ry="${f1(8 + R() * 9)}" fill="${i % 2 ? '#f6f0e4' : '#ddd2bf'}" opacity="0.5"/>`).join('') + '</g>';
      const isl = (cx, cz, rx, rz, sd) => { const Q = rng(sd), p1 = Q() * 6, p2 = Q() * 6; return k => smooth(rep(24, i => { const t = i / 24 * 2 * PI, r = k * (1 + 0.18 * Math.sin(2 * t + p1) + 0.09 * Math.sin(3 * t + p2)); return [cx + rx * r * Math.cos(t), cz + rz * r * Math.sin(t)]; })); };
      [[-50, -6, 40, 30, '#1f6066'], [42, 18, 42, 26, '#c3592f'], [64, -32, 22, 15, '#e3a83a'], [-58, 40, 22, 12, '#e8b4a4'], [-4, -36, 18, 11, '#3b3a3c'], [4, 34, 12, 8, '#e3a83a']].forEach(([x, z, rx, rz, col], i) => { const f = isl(x, z, rx, rz, 'sk' + i), d = f(1);
        art += `<path d="${d}" fill="#000000" opacity="0.34" transform="translate(0.7 1.1)" filter="url(#r13s)"/><path d="${d}" fill="${shade(col, 0.78)}"/><path d="${f(0.97)}" fill="${col}" transform="translate(-0.2 -0.3)"/>`
          + [0.74, 0.5, 0.27].map(k => `<path d="${f(k)}" fill="none" stroke="${shade(col, 0.7)}" stroke-width="0.6"/><path d="${f(k)}" fill="none" stroke="${shade(col, 1.3)}" stroke-width="0.35" transform="translate(-0.3 -0.4)" opacity="0.8"/>`).join('')
          + `<path d="${f(0.97)}" fill="none" stroke="#ffffff" stroke-width="0.55" opacity="0.4" transform="translate(-0.5 -0.6)"/>`; });
      art += `<path d="${dP(P)}" fill="url(#${id}p)"/>`;
      rep(4, k => { const z0 = -B * 0.7 + k * B * 0.46 + (R() - 0.5) * 6, a = 5 + R() * 6, ph = R() * 6, fq = 1.2 + R() * 0.8, d = 'M' + rep(23, i => { const x = -A * 1.1 + i * A * 2.2 / 22; return f1(x) + ' ' + f1(z0 + a * Math.sin(x / A * PI * fq + ph)); }).join('L'), w = k % 2 ? 1.3 : 2;
        art += `<path d="${d}" stroke="#000000" stroke-width="${w + 0.6}" fill="none" opacity="0.2" stroke-linejoin="round" transform="translate(0.4 0.6)"/><path d="${d}" stroke="#fbf6ec" stroke-width="${w}" fill="none" stroke-linejoin="round"/><path d="${d}" stroke="url(#${id}i)" stroke-width="${f1(w * 0.75)}" fill="none" stroke-linejoin="round" opacity="0.85"/>`
          + `<path d="${d}" pathLength="100" stroke="#ffffff" stroke-width="${f1(w * 1.1)}" stroke-linecap="round" stroke-dasharray="3 97" fill="none" filter="url(#r13s)"><animate attributeName="stroke-dashoffset" values="0;-100" dur="${n4(5 + k * 1.3)}s" begin="${n4(-k * 1.9)}s" repeatCount="indefinite"/></path>`; });
      art += `<path d="${dP(P.map(q => [q[0] * 0.965, q[1] * 0.95]))}" fill="none" stroke="#a89a84" stroke-width="0.6" opacity="0.8"/><path d="${dP(P)}" fill="none" stroke="#b9ad9b" stroke-width="2.2"/>`;
      const s = slab(C, P, T, '#cbbfad') + top(C, T, face(id, P, art, 0.2));
      return { defs: DEF20, front: s, bb: C.bb(5) }; };
    return D; };

  // LIV-097 fibre-optic galaxy rug: an oval dark tapestry with a slowly turning spiral galaxy of fibre-optic points, colours that drift through moods,
  // colour ripples that ring out from the glowing core, a chasing light ring round the rim and a mood-coloured glow on the floor
  N.fiber20 = S => { const A = 100, B = 68, T = 2.2, P = ellP(A, B, 80);
    const D = RUG(214, 146, { round: 1 });
    D.fx = ctx => { const C = cam(ctx), R = rng('fib20'), id = C.u('fo'), MOOD = '#ff4fa0;#a66bff;#4fd8ff;#5affb0;#ffd36a;#ff7a4f;#ff4fa0', NG = 8, gp = rep(NG, () => ''), wt = ['', ''];
      const dot = (x, z, r) => `M${f1(x - r)} ${f1(z)}a${f1(r)} ${f1(r)} 0 1 0 ${f1(2 * r)} 0a${f1(r)} ${f1(r)} 0 1 0 ${f1(-2 * r)} 0Z`, fa = (g, d) => `<animate attributeName="${d || 'fill'}" values="${MOOD}" dur="12s" begin="${n4(-g * 1.5)}s" repeatCount="indefinite"/>`;
      for (let arm = 0; arm < 3; arm++) for (let i = 0; i < 300; i++) { const t = i / 300, th = arm * 2 * PI / 3 + t * 2.6 * PI + (R() - 0.5) * (0.5 + t * 0.4), r = 5 + Math.pow(t, 0.8) * 92 + (R() - 0.5) * 7 * (0.4 + t); gp[(arm * 3 + ((t * 4) | 0)) % NG] += dot(r * Math.cos(th), r * Math.sin(th), 0.55 + (1 - t) * 0.6 + R() * 0.3); if (R() < 0.08) wt[i % 2] += dot(r * Math.cos(th), r * Math.sin(th), 0.4); }
      for (let i = 0; i < 240; i++) { const r = 8 + Math.sqrt(R()) * 92, th = R() * 2 * PI; gp[i % NG] += dot(r * Math.cos(th), r * Math.sin(th), 0.28 + R() * 0.22); }
      let art = `<defs><pattern id="${id}w" width="2" height="1.6" patternUnits="userSpaceOnUse"><rect width="2" height="1.6" fill="#141224"/><rect width="0.9" height="0.7" fill="#1d1a30"/><rect x="1" y="0.8" width="0.9" height="0.7" fill="#1d1a30"/></pattern><radialGradient id="${id}c"><stop offset="0" stop-color="#ffffff" stop-opacity="1"/><stop offset="0.25" stop-color="#ffd6f2" stop-opacity="0.7"/><stop offset="1" stop-color="#a66bff" stop-opacity="0"/></radialGradient></defs>`;
      art += `<ellipse rx="${A}" ry="${B}" fill="url(#${id}w)"/>`;
      let gal = '<g filter="url(#r13b)" opacity="0.28">' + rep(3, a => { const th = a * 2 * PI / 3 + 2.2; return `<ellipse cx="${f1(40 * Math.cos(th))}" cy="${f1(40 * Math.sin(th))}" rx="38" ry="10" transform="rotate(${f1(th * 180 / PI + 70)} ${f1(40 * Math.cos(th))} ${f1(40 * Math.sin(th))})" fill="#a66bff">${fa(a * 2)}</ellipse>`; }).join('') + '</g>';
      gal += `<g filter="url(#r20g)" opacity="0.8">${gp.map((d, g) => `<path d="${d}" fill="#ff4fa0">${fa(g)}</path>`).join('')}</g>` + gp.map((d, g) => `<path d="${d}" fill="#ff4fa0">${fa(g)}${an('opacity', '0.7;1;0.7', 2.4, -g * 0.3)}</path>`).join('');
      gal += wt.map((d, i) => `<path d="${d}" fill="#ffffff">${an('opacity', '0.2;1;0.2', 1.6 + i * 0.7, -i * 0.5)}</path>`).join('');
      const rip = rep(3, i => `<circle r="4" fill="none" stroke="#ffffff" stroke-width="1" opacity="0"><animate attributeName="r" values="4;98" dur="4.5s" begin="${n4(-i * 1.5)}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.8;0" dur="4.5s" begin="${n4(-i * 1.5)}s" repeatCount="indefinite"/>${fa(i * 2, 'stroke')}</circle>`).join('');
      art += `<g transform="scale(1 ${n4(B / A)})"><g>${H.at('rotate', '0;360', 60)}${gal}</g>${rip}<circle r="16" fill="url(#${id}c)">${an('r', '12;18;12', 3, 0, SPL(2))}</circle></g>`;
      art += `<ellipse rx="${A - 2.4}" ry="${B - 2.4}" fill="none" stroke="#ff4fa0" stroke-width="1.6">${fa(0, 'stroke')}</ellipse><ellipse rx="${A - 2.4}" ry="${B - 2.4}" fill="none" stroke="#ffffff" stroke-width="1.1" stroke-dasharray="2.5 9.5" stroke-linecap="round"><animate attributeName="stroke-dashoffset" values="0;-48" dur="1.4s" repeatCount="indefinite"/></ellipse>`;
      const glow = `<g transform="${H.FR(C, [0, 0.05, 0], [1, 0, 0], [0, 0, 1])}"><ellipse rx="${A * 1.05}" ry="${B * 1.07}" fill="none" stroke="#ff4fa0" stroke-width="8" opacity="0.35" filter="url(#r13b)">${fa(0, 'stroke')}</ellipse></g>`;
      const s = glow + slab(C, P, T, '#141220') + top(C, T, face(id, P, art, 0.3));
      return { defs: DEF20, front: s, bb: C.bb(8) }; };
    return D; };

  RD.SET20 = {
    'LIV-005': { f20: 'lino', note: 'Old beige sheet linoleum printed to look like stone squares with little brown diamonds. A worn path runs across it, with black heel scuffs, a seam that curls up at the edge, an iron burn and a torn spot showing the plywood underneath.' },
    'LIV-025': { f20: 'lam', note: 'Honey oak laminate planks with bevelled edges and staggered joints. The wood print repeats every few planks like real laminate, with a soft satin sheen and a few light scratches.' },
    'LIV-045': { f20: 'chev', note: 'Pale white oak boards laid in a chevron zigzag, with straight oak border boards and a thin walnut inlay line round the edge. Oiled to a soft matte sheen.' },
    'LIV-065': { f20: 'terr', live: 'Warm glow', note: 'Polished cream terrazzo full of marble chips in grey, terracotta, sage, blush and black, split into big panels by brass strips. Heating pipes under the floor make it glow softly warm.' },
    'LIV-037': { spec: 'jute20', live: 'Bobbing pompoms', note: 'An oval rug braided from chunky jute rope, with a wide black band and a cream zigzag, cream and black rings, a woven star in the middle and a trim of cream and black pompoms that bob.' },
    'LIV-057': { spec: 'pers20', live: 'Gold threads shimmer', note: 'A vintage Persian wool carpet overdyed deep crimson: a big lobed navy and ivory medallion with a gold star, a gold-thread lattice full of little flowers, teal corner pieces and a rosette border. The gold threads shimmer and the velvet pile catches the light.' },
    'LIV-077': { spec: 'silk20', live: 'Flowing silk', note: 'A free-form pebble-shaped designer rug: deep teal, rust, mustard, blush and charcoal islands in raised wool with carved grooves and contour lines, crossed by iridescent silk rivers whose colours flow and glint.' },
    'LIV-097': { spec: 'fiber20', live: 'Turning galaxy', note: 'An oval fibre-optic rug with a spiral galaxy of light points that slowly turns. Its colours drift through moods, rings of colour pulse out from the glowing core and a chasing light runs round the rim.' },
    'LIV-085': { f20: 'onyx', live: 'Glowing gold veins', note: 'One seamless slab of honey onyx with soft cloudy bands, lit from below. Thin gold veins glow and little pulses of light run along them.' },
  };
  const edit19 = RD.edit;
  RD.edit = rows => edit19(rows).map(r => RD.SET20[r.id] ? Object.assign({}, r, RD.SET20[r.id]) : r);
  RD.H20 = { FLOOR20, W, polyW, lineW, crvW, chip };
  RD.PLUS20 = 1;
})();
