// Renovation Catalog round 8c — Yard section 3 (tables with food, decor & gadgets) + section 4 (games & pet zones with player counts).
// Games: r.play = 'game', r.need = players needed to start, r.loop = match length (s, loops). Players come from PL9[spec] (projected like plus5).
// r.play 'tip' = tap to tip over / set back. Sets RenoDraw.PLUS9; catalog edits RD.SET9.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS8 && RD.H8 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS9) return;
  const K = X.K, { solid, box, cyl, ball, arcW, prism, prismZ, f1 } = K;
  const { rep, rng, n4, P2, planeH, plane, planeX, an, BLUR, bbOf, mt, wd, cer, pt, tex } = RD.H3;
  const { atV, once, onceT, G, L, ellPts, lp, sp, quad, planeT, facing, tube, curve, water, WP, WDEF, FDEF, smoke, glowE, isPlay, stream, flames } = RD.H7;
  const { fb, kOf, LEAF, LEAFT, sprinkle, sway, flower5 } = RD.H8;
  const N = RD.N, PI = Math.PI, GOLD = '#e2b14a', CH = '#d5dde2', B = b => b ? ` begin="${n4(b)}s"` : '';
  const amo = (path, d, b, rot) => `<animateMotion dur="${n4(d)}s"${B(b)} repeatCount="indefinite"${rot ? ' rotate="auto"' : ''} path="${path}"/>`;
  const amoK = (path, d, kt, b) => `<animateMotion dur="${n4(d)}s"${B(b)} repeatCount="indefinite" keyPoints="${kt[0]}" keyTimes="${kt[1]}" calcMode="linear" path="${path}"/>`;
  const pathOf = (p, pts) => 'M' + pts.map(q => P2(p(...q))).join('L');
  const arc3 = (a, b, h, n) => rep(n + 1, i => { const t = i / n; return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t + h * 4 * t * (1 - t), a[2] + (b[2] - a[2]) * t]; });

  // ---------- food & tableware (k-scaled sprites at projected points) ----------
  const at = (p, k, x, y, z, s, body) => `<g transform="translate(${P2(p(x, y, z))}) scale(${n4(k * (s || 1))})">${body}</g>`;
  const PLATE = (r, inner) => `<ellipse cy="0.3" rx="${r + 0.6}" ry="${f1((r + 0.6) * 0.5)}" fill="#000000" opacity="0.15"/><ellipse rx="${r}" ry="${f1(r * 0.5)}" fill="#fbfaf6" stroke="#c9c3b6" stroke-width="0.3"/><ellipse rx="${f1(r * 0.72)}" ry="${f1(r * 0.36)}" fill="#f1eee6"/>${inner || ''}`;
  const GLASS = (col, h) => { h = h || 6; return `<ellipse cy="0.2" rx="2" ry="0.8" fill="#000000" opacity="0.15"/><path d="M-1.8 ${-h}H1.8L1.5 0H-1.5Z" fill="${col}" opacity="0.85"/><path d="M-1.8 ${-h}H1.8L1.5 0H-1.5Z" fill="none" stroke="#ffffff" stroke-width="0.3" opacity="0.8"/><ellipse cy="${-h}" rx="1.8" ry="0.6" fill="#ffffff" opacity="0.5"/><path d="M-1 ${-h + 1}V-1" stroke="#ffffff" stroke-width="0.4" opacity="0.6"/>`; };
  const WINE = col => `<ellipse cy="0.2" rx="1.6" ry="0.6" fill="#000000" opacity="0.15"/><path d="M-1.4 0H1.4M0 0V-3.4" stroke="#e8f4f8" stroke-width="0.5"/><path d="M-1.8 -7.6Q-1.8 -3.4 0 -3.4Q1.8 -3.4 1.8 -7.6Z" fill="#e8f4f8" opacity="0.5"/><path d="M-1.6 -6Q-1.4 -3.8 0 -3.8Q1.4 -3.8 1.6 -6Z" fill="${col}"/>`;
  const BOTTLE = (col, lab) => `<ellipse cy="0.2" rx="1.8" ry="0.7" fill="#000000" opacity="0.18"/><path d="M-1.6 0V-6Q-1.6 -7.6 -0.6 -8.4V-11H0.6V-8.4Q1.6 -7.6 1.6 -6V0Z" fill="${col}"/><rect x="-1.6" y="-5" width="3.2" height="2.6" fill="${lab || '#f4efe6'}"/><path d="M-0.9 -7.6V-1" stroke="#ffffff" stroke-width="0.4" opacity="0.5"/><rect x="-0.7" y="-11.6" width="1.4" height="0.8" fill="#c9a24a"/>`;
  const CANDLE = (b) => `<rect x="-1" y="-5" width="2" height="5" rx="0.4" fill="#fbf6e8"/><ellipse cy="-6.4" rx="0.7" ry="1.4" fill="#ffd27a">${an('ry', '1.2;1.6;1.3;1.5;1.2', 0.9, b)}</ellipse><ellipse cy="-6.2" rx="0.3" ry="0.6" fill="#ffffff"/><circle cy="-6" r="3" fill="url(#f7g)" opacity="0.7"/>`;
  const BOWL = (r, cols) => `<ellipse cy="0.4" rx="${r + 0.5}" ry="${f1(r * 0.42)}" fill="#000000" opacity="0.15"/><path d="M${-r} -1Q${-r} ${f1(r * 0.55)} 0 ${f1(r * 0.55)}Q${r} ${f1(r * 0.55)} ${r} -1Z" fill="#f4efe6" stroke="#c9c3b6" stroke-width="0.3"/>${cols.map((c, i) => `<circle cx="${f1((i % 3 - 1) * r * 0.42)}" cy="${f1(-1.6 - Math.floor(i / 3) * 1.4)}" r="${f1(r * 0.32)}" fill="${c}"/><circle cx="${f1((i % 3 - 1) * r * 0.42 - r * 0.1)}" cy="${f1(-1.9 - Math.floor(i / 3) * 1.4)}" r="${f1(r * 0.1)}" fill="#ffffff" opacity="0.5"/>`).join('')}`;
  const SALAD = r => BOWL(r, ['#7ac050', '#9ad86a', '#e8343c', '#5aa844', '#f2c14a', '#7ac050']);
  const BURGERS = `${PLATE(6, [[-2.4, -0.6], [2.2, 0.4], [0, -1.6]].map(([x, y]) => `<g transform="translate(${x} ${y})"><ellipse rx="2.2" ry="1.1" fill="#7a4a2a"/><ellipse cy="-0.6" rx="2.3" ry="1.2" fill="#d89a4a"/><ellipse cy="-0.9" rx="1.2" ry="0.4" fill="#f2c47a" opacity="0.7"/><path d="M-2.1 0H2.1" stroke="#5aa844" stroke-width="0.4"/></g>`).join(''))}`;
  const MELON = `${PLATE(6, [-2.4, 0, 2.4].map((x, i) => `<path d="M${x - 2} 0.6Q${x} -3.2 ${x + 2} 0.6Z" fill="#e8344a" transform="rotate(${(i - 1) * 8} ${x} 0)"/><path d="M${x - 2} 0.6Q${x} 1.1 ${x + 2} 0.6" stroke="#3f8a34" stroke-width="0.7" fill="none"/><circle cx="${x - 0.4}" cy="-0.6" r="0.18" fill="#1d1e22"/><circle cx="${x + 0.5}" cy="-0.2" r="0.18" fill="#1d1e22"/>`).join(''))}`;
  const CHICKEN = `${PLATE(7, '<ellipse cy="-1.2" rx="4.4" ry="2.4" fill="#c8782e"/><ellipse cx="-1" cy="-2" rx="2.4" ry="1" fill="#e8a24a" opacity="0.8"/><path d="M3.6 -1.4Q6 -2 6 -0.6" stroke="#c8782e" stroke-width="1.2" stroke-linecap="round" fill="none"/><circle cx="6.2" cy="-0.6" r="0.6" fill="#fbf6e8"/><circle cx="-3" cy="0.6" r="0.7" fill="#5aa844"/><circle cx="3" cy="0.8" r="0.6" fill="#e8343c"/>')}`;
  const BREAD = `<ellipse cy="0.3" rx="5" ry="1.4" fill="#000000" opacity="0.15"/><rect x="-5.4" y="-0.4" width="10.8" height="1.2" rx="0.4" fill="#a8743a"/><path d="M-4.4 -0.4Q-4.4 -3.4 0 -3.6Q4.4 -3.4 4.4 -0.4Z" fill="#d8954a"/>${[-2.4, 0, 2.4].map(x => `<path d="M${x - 0.8} -2.6L${x + 0.8} -1.4" stroke="#f2c47a" stroke-width="0.4"/>`).join('')}`;
  const SUSHI = `${PLATE(6.4, [-3, -1, 1, 3].map((x, i) => `<g transform="translate(${x} ${i % 2 ? 0.6 : -0.6})"><ellipse rx="1.1" ry="0.7" fill="#1d2a1d"/><ellipse cy="-0.4" rx="0.9" ry="0.5" fill="#fbfaf6"/><ellipse cy="-0.5" rx="0.5" ry="0.3" fill="${['#ff7a5a', '#ffb347', '#e8344a', '#7ac050'][i]}"/></g>`).join(''))}`;
  const CHEESE = `<ellipse cy="0.3" rx="6" ry="2.6" fill="#000000" opacity="0.15"/><rect x="-6" y="-2.2" width="12" height="4.4" rx="1" fill="#b98a52" stroke="#7a5430" stroke-width="0.3"/><path d="M-4.4 -1L-1.4 -1.6L-2 0.6Z" fill="#f2c14a"/><path d="M-0.6 0.6L2 -1.4L2.6 0.4Z" fill="#f6e6b0"/><circle cx="3.6" cy="-0.6" r="0.6" fill="#7a2a5a"/><circle cx="4.4" cy="0.2" r="0.6" fill="#7a2a5a"/><circle cx="3.8" cy="0.6" r="0.6" fill="#9a3a6a"/>`;
  const CROISS = `${PLATE(4.6, [-1.6, 1.6].map(x => `<path d="M${x - 2} 0.2Q${x} -2.6 ${x + 2} 0.2Q${x} -0.6 ${x - 2} 0.2Z" fill="#d8954a" stroke="#a8743a" stroke-width="0.2"/>`).join(''))}`;
  const COOKIES = `${PLATE(4.4, [[-1.6, -0.4], [1.4, -0.2], [0, -1.4]].map(([x, y]) => `<ellipse cx="${x}" cy="${y}" rx="1.5" ry="0.8" fill="#c88a4a"/><circle cx="${x - 0.4}" cy="${y - 0.2}" r="0.25" fill="#4a2a18"/><circle cx="${x + 0.5}" cy="${y + 0.1}" r="0.25" fill="#4a2a18"/>`).join(''))}`;
  const PITCHER = `<ellipse cy="0.3" rx="2.8" ry="1" fill="#000000" opacity="0.15"/><path d="M-2.4 0V-7Q-2.4 -8.4 -1.6 -8.6H2L2.6 -9.4V-8Q2.4 -7 2.4 -6V0Z" fill="#fff2a0" opacity="0.85"/><path d="M-2.4 -8.6H2" stroke="#ffffff" stroke-width="0.4"/><path d="M2.4 -6.6Q4.6 -6 4 -3Q3.6 -1.6 2.4 -1.6" stroke="#e8f4f8" stroke-width="0.7" fill="none"/><circle cx="-0.8" cy="-4" r="0.9" fill="#ffd23a"/><circle cx="0.8" cy="-6" r="0.8" fill="#ffffff" opacity="0.6"/>`;

  // ======================= ROUGH-CUT TREE STUMP SIDE TABLE =======================
  N.stump8 = S => { const H = 22, R0 = 13;
    const D = { w: 40, d: 40, round: 1, topH: H, topW: 16 };
    D.build = P => [cyl(0, 0, 0, R0, H, '#6a4a30', wd({ n: 22, rg: [[0, 0, 1.4], [2, 0, 1.15], [6, 0, 1], [H - 1, 0, 1], [H, 0, 0.97]] })), ...[0.4, 2.2, 4.1, 5.5].map((a, i) => ball(Math.sin(a) * R0 * 1.2, 0, Math.cos(a) * R0 * 1.2, 4 - (i % 2), '#5a3e28', wd({ sx: 1.4, sy: 0.6, k: 3, n: 8, yaw: -a })))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      rep(20, i => { const th = i / 20 * 2 * PI; if (facing(th) < 0.05) return; const pts = rep(6, j => p((R0 + 0.15) * Math.sin(th + Math.sin(j + i) * 0.03), 1.5 + j * (H - 3) / 5, (R0 + 0.15) * Math.cos(th + Math.sin(j + i) * 0.03))); f += `<path d="M${pts.map(P2).join('L')}" fill="none" stroke="${i % 2 ? '#3a2818' : '#8a6a4a'}" stroke-width="${f1((i % 2 ? 0.7 : 0.4) * k)}" opacity="0.75"/>`; });
      f += `<g transform="${planeH(p, H + 0.05)}"><circle r="${R0 * 0.97}" fill="#d8b07a"/><circle r="${R0 * 0.97}" fill="none" stroke="#7a5030" stroke-width="1.2"/>${rep(6, i => `<circle r="${f1(1.4 + i * 1.8)}" fill="none" stroke="#b08050" stroke-width="0.35" opacity="0.8"/>`).join('')}<path d="M0 0L9 -4M0 0L-6 7" stroke="#7a5030" stroke-width="0.4"/></g>`;
      f += at(p, k, -3, H, 2, 1, COOKIES) + at(p, k, 4.6, H, -2.4, 1, GLASS('#ffd86a', 6) + '<circle cx="1" cy="-6.2" r="0.9" fill="#ffd23a"/>');
      return { defs: FDEF, front: f, bb: bbOf([p(-20, 0, -20), p(20, 0, 20), p(-20, 0, 20), p(20, 0, -20), p(0, H + 10, 0)], 3) }; };
    return D; };

  // ======================= MOSAIC TILE & WROUGHT-IRON BISTRO TABLE =======================
  N.mosaic8 = S => { const H = 30, R0 = 20, IR = '#1f2124';
    const D = { w: 50, d: 50, round: 1, topH: H + 1.4, topW: 26 };
    D.build = P => [cyl(0, H, 0, R0, 1.6, '#e8e2d4', cer({ n: 30 })), arcW(0, H - 0.4, 0, R0 + 0.8, R0 + 0.8, 1.6, 2.4, 4.4, 4.4 + 2 * PI, IR, mt({ n: 30 })), cyl(0, 6, 0, 1.6, H - 6, IR, mt({ n: 10 })), cyl(0, 18, 0, 2.6, 3, IR, mt({ n: 10 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      rep(3, i => { const th = i / 3 * 2 * PI + 0.3, pts = curve([0, 8, 0], [Math.sin(th) * 10, 4, Math.cos(th) * 10], [Math.sin(th) * 16, 0.6, Math.cos(th) * 16], 6).map(q => p(...q)); const s = tube(pts, 1.4, k, IR, '#6a6e76') + tube(rep(8, j => { const a = j / 7 * 1.6 * PI; return [Math.sin(th) * (16 + Math.cos(a) * 1.6), 2.6 + Math.sin(a) * 1.6, Math.cos(th) * (16 + Math.cos(a) * 1.6)]; }).map(q => p(...q)), 0.6, k, IR, '#6a6e76'); if (facing(th) > 0) f += s; else bk += s; });
      // radial mosaic top: rings of tesserae in cobalt / terracotta / saffron / white
      let m = `<circle r="${R0}" fill="#efe8da"/>`; const C = ['#2a5aa8', '#c4683a', '#f2c14a', '#fbfaf6', '#2fa89a'];
      [[3, 6, 0], [7.4, 12, 1], [11.6, 18, 2], [15.8, 24, 3]].forEach(([r, n, ri]) => rep(n, i => { const a = i / n * 2 * PI; m += `<rect x="-1.4" y="-1.4" width="2.8" height="2.8" rx="0.4" fill="${C[(i + ri) % (ri === 3 ? 2 : 5)]}" transform="translate(${f1(r * Math.cos(a))} ${f1(r * Math.sin(a))}) rotate(${f1(a * 180 / PI + 45)})"/>`; }));
      m += `<circle r="1.8" fill="#c4683a"/><circle r="${R0 - 0.3}" fill="none" stroke="#2a5aa8" stroke-width="0.8"/>`;
      f += `<g transform="${planeH(p, H + 1.65)}">${m}</g>` + at(p, k, -6, H + 1.6, 3, 1, CHEESE) + at(p, k, 6, H + 1.6, -4, 1, CROISS) + at(p, k, 2, H + 1.6, 9, 1, GLASS('#d8b46a', 6)) + at(p, k, -2, H + 1.6, -9, 1, GLASS('#ffd86a', 6));
      return { defs: FDEF, back: bk, front: f, bb: bbOf([p(-24, 0, -24), p(24, 0, 24), p(-24, 0, 24), p(24, 0, -24), p(0, H + 12, 0)], 3) }; };
    return D; };

  // ======================= CURVED ENGLISH LIMESTONE GARDEN BENCH =======================
  N.limeBench = S => { const LS = '#ddd3bf', R0 = 60, A0 = -PI / 2 - 0.62, A1 = -PI / 2 + 0.62;
    const D = { w: 90, d: 40, seats: [{ x: -18, z: -50, h: 18 }, { x: 0, z: -54, h: 18 }, { x: 18, z: -50, h: 18 }].map(s => ({ x: s.x, z: s.z + 52, h: s.h })) };
    D.build = P => [arcW(0, 14, 60, R0 + 6, R0 + 6, 14, 4, A0, A1, LS, pt({ n: 10 })), ...[-0.42, 0, 0.42].map(a => { const t = -PI / 2 + a; return box((R0 - 1) * Math.cos(t), 0, 60 + (R0 - 1) * Math.sin(t), 9, 14, 11, '#cfc4ae', pt({ r: 1.2, yaw: -t - PI / 2 })); })];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      [-0.42, 0.42].forEach(a => { const t = -PI / 2 + a, q = p((R0 + 4.6) * Math.cos(t), 7, 60 + (R0 + 4.6) * Math.sin(t)); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><path d="M-2.6 -4C-3.6 -1 -1 1 0 -1C1 1 3.6 -1 2.6 -4" stroke="#a89a80" stroke-width="0.5" fill="none"/><circle cy="2" r="1" fill="none" stroke="#a89a80" stroke-width="0.4"/></g>`; });
      const R = rng('lich'); rep(10, i => { const t = A0 + R() * (A1 - A0), q = p((R0 + 6.1) * Math.cos(t), 14.6 + R() * 3, 60 + (R0 + 6.1) * Math.sin(t)); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((1 + R()) * k)}" ry="${f1(0.6 * k)}" fill="${i % 2 ? '#9aa86a' : '#c8b86a'}" opacity="0.6"/>`; });
      // picnic basket + tea tray on the bench
      f += at(p, k, -22, 18, -1, 1, '<ellipse cy="0.3" rx="6" ry="1.6" fill="#000000" opacity="0.15"/><path d="M-5 -5H5L4.2 0H-4.2Z" fill="#c9965a" stroke="#7a5430" stroke-width="0.3"/>' + rep(3, j => `<path d="M-4.8 ${-3.8 + j * 1.4}H4.8" stroke="#9a6a3a" stroke-width="0.35"/>`).join('') + '<path d="M-5 -5H5" stroke="#e8343c" stroke-width="0.8"/><rect x="-5" y="-5.6" width="10" height="1.4" fill="url(#lb8g)"/><path d="M-3.4 -5Q0 -11 3.4 -5" stroke="#9a6a3a" stroke-width="0.8" fill="none"/>')
        + at(p, k, 12, 18, -1, 1, '<ellipse cy="0.3" rx="6" ry="2" fill="#000000" opacity="0.15"/><rect x="-6" y="-2" width="12" height="3.6" rx="0.8" fill="#c9a24a"/><path d="M-3.4 0V-4Q-3.4 -6 -1 -6H0.6Q2 -6 2 -4V0Z" fill="#fbfaf6" stroke="#c9c3b6" stroke-width="0.3"/><path d="M2 -4.4Q4 -4.4 3.4 -2.4" stroke="#fbfaf6" stroke-width="0.8" fill="none"/><path d="M-3.4 -3H2" stroke="#2a5aa8" stroke-width="0.5"/>' + GLASS('#c8782e', 3).replace(/<ellipse cy="0.2"[^>]*\/>/, '').split('').join('').replace('M-1.8', 'M2.6').replace('H1.8L1.5 0H-1.5Z', 'H6.2L5.9 0H3Z'));
      return { defs: L('lb8g', [[0, '#e8343c'], [0.5, '#ffffff'], [1, '#e8343c']], 'x1="0" y1="0" x2="0.2" y2="0"').replace('<linearGradient', '<linearGradient spreadMethod="repeat"'), front: f, bb: bbOf([p(-44, 0, -16), p(44, 0, -16), p(-48, 0, 16), p(48, 0, 16), p(0, 30, 0), p(-22, 30, 0)], 3) }; };
    return D; };

  // ======================= REDWOOD A-FRAME PICNIC TABLE (with a feast) =======================
  N.picnic8 = S => { const RW = '#9a4a32', RW2 = '#b45a3c', W = 46, TY = 28;
    const D = { w: 110, d: 76, topH: TY + 2.6, topW: 70, seats: [{ x: -16, z: 24, h: 17 }, { x: 16, z: 24, h: 17 }, { x: -16, z: -24, h: 17 }, { x: 16, z: -24, h: 17 }] };
    D.build = P => { const o = []; rep(5, i => o.push(box(0, TY, -12 + i * 6, 2 * W, 2.6, 5.4, i % 2 ? RW : RW2, wd({ r: 0.5 }))));
      [-1, 1].forEach(s => rep(2, i => o.push(box(0, 15, s * (22 + i * 5.6), 2 * W - 4, 2.4, 5, i ? RW : RW2, wd({ r: 0.5 })))));
      [-W + 8, W - 8].forEach(x => { o.push(prism(x - 1.6, x + 1.6, [[-30, 0], [-26, 0], [-1.6, TY], [1.6, TY], [26, 0], [30, 0], [3, TY + 0.4], [-3, TY + 0.4]], RW, wd({})), box(x, 12.6, 0, 3.4, 2.4, 60, RW, wd({ r: 0.4 })), box(x, 20, 0, 3, 2, 30, RW, wd({ r: 0.3 }))); });
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      f += `<g transform="${planeH(p, TY + 2.65)}"><rect x="-26" y="-11" width="52" height="22" fill="url(#pc8g)" opacity="0.92"/><path d="M-26 -11H26M-26 11H26" stroke="#ffffff" stroke-width="0.4" opacity="0.6"/></g>`;
      f += at(p, k, -16, TY + 2.6, -3, 1, MELON) + at(p, k, 6, TY + 2.6, -4, 1, BURGERS) + at(p, k, 22, TY + 2.6, 4, 1, PITCHER) + at(p, k, -2, TY + 2.6, 6, 1, BOWL(4, ['#f2c14a', '#f2c14a', '#e8b03a'])) + at(p, k, -24, TY + 2.6, 7, 1, GLASS('#fff2a0', 5)) + at(p, k, 14, TY + 2.6, 9, 1, GLASS('#fff2a0', 5)) + at(p, k, 30, TY + 2.6, -6, 1, '<rect x="-1.2" y="-8" width="2.4" height="8" rx="0.8" fill="#d8242c"/><rect x="-0.5" y="-9.6" width="1" height="1.6" fill="#ffffff"/><rect x="-1.2" y="-5" width="2.4" height="1.6" fill="#ffffff"/>');
      return { defs: FDEF + `<pattern id="pc8g" width="4" height="4" patternUnits="userSpaceOnUse"><rect width="4" height="4" fill="#fbfaf6"/><rect width="2" height="4" fill="#e8343c" opacity="0.55"/><rect width="4" height="2" fill="#e8343c" opacity="0.55"/></pattern>`, front: f, bb: bbOf([p(-W - 2, 0, -34), p(W + 2, 0, 34), p(-W - 2, 0, 34), p(W + 2, 0, -34), p(0, TY + 16, 0)], 3) }; };
    return D; };

  // ======================= 10-FOOT RECLAIMED TEAK HARVEST TABLE (feast) =======================
  N.teak8 = S => { const TK = '#8a5a34', TK2 = '#a46e40', W = 78, DZ = 20, TY = 30;
    const D = { w: 170, d: 56, topH: TY + 4, topW: 140 };
    D.build = P => [box(0, TY, 0, 2 * W, 4, 2 * DZ, TK2, wd({ r: 0.8 })), ...[-W + 10, W - 10].map(x => box(x, 0, 0, 7, TY, 7, TK, wd({ r: 0.6 }))), ...[-W + 10, W - 10].map(x => box(x, 0, 0, 7, 3, 2 * DZ - 6, TK, wd({ r: 0.6 }))), box(0, 9, 0, 2 * W - 26, 4, 4, TK, wd({ r: 0.5 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      f += `<g transform="${planeH(p, TY + 4.05)}">${[-10, 0, 10].map(z => `<path d="M${-W} ${z}H${W}" stroke="#5a3a1e" stroke-width="0.4" opacity="0.7"/>`).join('')}${rep(9, i => `<path d="M${-W + 6 + i * 18} ${-DZ + 2 + (i % 3) * 5}q4 -0.6 8 0" stroke="#6a4424" stroke-width="0.3" fill="none" opacity="0.6"/>`).join('')}<rect x="${-W + 6}" y="-5" width="${2 * W - 12}" height="10" fill="#e8dcc0" opacity="0.92"/><path d="M${-W + 6} -5H${W - 6}M${-W + 6} 5H${W - 6}" stroke="#8a7a5a" stroke-width="0.4"/></g>`;
      const items = [[-56, 2, CHICKEN, 1.1], [-34, -8, SALAD(4.4), 1], [-14, 3, BREAD, 1.1], [8, -6, BOWL(4.4, ['#e8343c', '#ff8a2a', '#9ad86a', '#7a2a5a', '#f2c14a']), 1], [28, 4, CHEESE, 1], [50, -4, CHICKEN, 1]];
      const deco = [[-44, 10, BOTTLE('#3a1a24')], [-24, 11, WINE('#7a1a2a')], [-4, -12, WINE('#7a1a2a')], [18, 12, WINE('#f2d27a')], [38, -12, BOTTLE('#2f5a2a')], [62, 10, WINE('#7a1a2a')]];
      const cand = [[-46, -10], [-2, 10], [40, 12]];
      items.concat(deco).concat(cand.map(([x, z], i) => [x, z, CANDLE(-i * 0.3), 1])).sort((a, b) => (a[0] * 0.5 + a[1] * 0.866) - (b[0] * 0.5 + b[1] * 0.866)).forEach(([x, z, body, s]) => f += at(p, k, x, TY + 4, z, s || 1, body));
      return { defs: FDEF, front: f, bb: bbOf([p(-W - 2, 0, -DZ - 2), p(W + 2, 0, DZ + 2), p(-W - 2, 0, DZ + 2), p(W + 2, 0, -DZ - 2), p(0, TY + 18, 0), p(-W, TY + 18, 0), p(W, TY + 18, 0)], 3) }; };
    return D; };

  // ======================= ILLUMINATED ONYX & WATERFALL-CHANNEL BANQUET TABLE =======================
  N.onyx8 = S => { const W = 74, DZ = 22, TY = 30, BR = '#8a6a3a';
    const D = { w: 170, d: 60, topH: TY + 4, topW: 130, glow: () => ({ y: 30, r: 90 }) };
    D.build = P => [box(0, TY, 0, 2 * W, 4, 2 * DZ, '#f2c47a', { mat: 'cer', shine: 1, emit: 1, r: 1 }), ...[-W + 16, W - 16].map(x => box(x, 0, 0, 10, TY, 2 * DZ - 12, BR, mt({ r: 1, shine: 1 }))), cyl(W + 8, 0, 0, 10, 8, '#2a2b30', mt({ n: 24, shine: 1 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      // backlit onyx: honey glow + flowing veins; water channel down the middle, spilling off the end into a basin
      let o = `<rect x="${-W}" y="${-DZ}" width="${2 * W}" height="${2 * DZ}" fill="url(#ox8)"/>`; const R = rng('onx'); rep(9, i => { const z = -DZ + 3 + R() * (2 * DZ - 6); o += `<path d="M${-W} ${f1(z)}Q${f1(-W / 2)} ${f1(z + (R() - 0.5) * 10)} 0 ${f1(z + (R() - 0.5) * 6)}T${W} ${f1(z + (R() - 0.5) * 8)}" stroke="${i % 2 ? '#fff6dc' : '#c8862e'}" stroke-width="${f1(0.4 + R())}" fill="none" opacity="0.6"/>`; });
      f += `<g transform="${planeH(p, TY + 4.05)}">${o}<rect x="${-W}" y="-3.4" width="${2 * W}" height="6.8" fill="#2a2b30"/></g>`;
      const Wt = water(p, { sh: { pts: [[-W + 2, -2.6], [W + 1, -2.6], [W + 1, 2.6], [-W + 2, 2.6]] }, y: TY + 3.4, pal: ['#1a6a7a', '#2ab4c8', '#9af0f8', '#ffffff'], flow: 1, gl: 6, wave: 0.8 }); f += Wt.svg;
      f += RD.H7.fall(p, k, [[W + 1, TY + 3.4, -2.4], [W + 1, TY + 3.4, 0], [W + 1, TY + 3.4, 2.4]], [[W + 6, TY - 4, -2.4], [W + 6, TY - 4, 0], [W + 6, TY - 4, 2.4]], [[W + 8, 8, -3], [W + 8, 8, 0], [W + 8, 8, 3]], { streaks: 6, mw: 8 });
      const Wb = water(p, { sh: { cx: W + 8, rx: 8.6 }, y: 7.6, rim: { y: 8, sh: { cx: W + 8, rx: 8.6 } }, pal: WP.lagoon, rip: [[W + 8, 0, 6, 1.3, 0]], gl: 2 }); f += Wb.svg;
      const items = [[-54, -12, SUSHI], [-30, 12, BOWL(5, ['#ff8a2a', '#e8343c', '#9ad86a', '#7a2a5a', '#f2c14a', '#ff8a2a'])], [-8, -13, CHEESE], [16, 12, SUSHI], [40, -12, BOWL(4.6, ['#f2c14a', '#e8343c', '#7a2a5a'])], [-44, 13, WINE('#f2d27a')], [-20, -11, WINE('#f2d27a')], [4, 13, WINE('#f2d27a')], [28, -13, WINE('#f2d27a')], [56, 12, CANDLE(0)], [-62, 10, CANDLE(-0.5)]];
      items.sort((a, b) => (a[0] * 0.5 + a[1] * 0.866) - (b[0] * 0.5 + b[1] * 0.866)).forEach(([x, z, body]) => f += at(p, k, x, TY + 4, z, 1, body));
      un += glowE(p, 0, 0, 0, W + 10, DZ + 14, '#ffc870', 0.4, 1);
      return { defs: WDEF + FDEF + Wt.defs + Wb.defs + G('ox8', [[0, '#fff2c8'], [0.45, '#f8c870'], [1, '#d8862e']], 'cx="50%" cy="50%" r="70%"'), under: un, front: f, bb: bbOf([p(-W - 2, 0, -DZ - 2), p(W + 20, 0, DZ + 2), p(-W - 2, 0, DZ + 2), p(W + 20, 0, -DZ - 2), p(0, TY + 18, 0), p(-W, TY + 16, 0)], 3) }; };
    return D; };

  // ======================= SKY GARDEN HOLO STAR-MAP GLOBE & FLOATING CARAFE =======================
  N.globe8 = S => { const GY = 50, GR = 16;
    const D = { w: 50, d: 50, round: 1, glow: () => ({ y: 50, r: 40 }) };
    D.build = P => [cyl(0, 0, 0, 13, 4, '#2a2b30', mt({ n: 24, shine: 1, rg: [[0, 0, 1], [4, 0, 0.86]] })), cyl(0, 4, 0, 3, 22, '#c9d0d6', mt({ n: 12, shine: 1, rg: [[0, 0, 1.2], [22, 0, 0.8]] })), cyl(0, 26, 0, 7, 3, '#2a2b30', mt({ n: 18, shine: 1 })), cyl(0, 29, 0, 5, 1.2, '#7ef6ff', { emit: 1, n: 16 })];
    D.fx = c => { const p = c.p, k = c.k; let f = '', g = '';
      const C = p(0, GY, 0), r = GR * k;
      g += `<circle r="${f1(r)}" fill="url(#gb8)"/>`; rep(5, i => { const ry = r * (0.15 + i * 0.2); g += `<ellipse rx="${f1(Math.sqrt(Math.max(0, r * r - (r * (i - 2) * 0.36) ** 2)))}" ry="${f1(ry * 0.25)}" cy="${f1(r * (i - 2) * 0.36)}" fill="none" stroke="#7ef6ff" stroke-width="${f1(0.25 * k)}" opacity="0.7"/>`; });
      rep(6, i => g += `<ellipse rx="${f1(r)}" ry="${f1(r)}" fill="none" stroke="#7ef6ff" stroke-width="${f1(0.25 * k)}" opacity="0.6"><animate attributeName="rx" values="${f1(r)};${f1(r * 0.02)};${f1(r)}" dur="8s"${B(-i * 8 / 6)} repeatCount="indefinite"/></ellipse>`);
      const R = rng('gst'); let stars = ''; rep(18, i => { const a = R() * 2 * PI, e = (R() - 0.5) * PI * 0.9, x = Math.cos(e) * Math.cos(a) * r, y = Math.sin(e) * r; stars += `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1((0.4 + R() * 0.5) * k)}" fill="#ffffff">${an('opacity', '0.4;1;0.4', n4(1.4 + R() * 2), -R() * 2)}</circle>`; });
      g += `<g>${atV('translate', ['0 0', `${f1(r * 0.3)} 0`, '0 0'], 8)}${stars}<path d="M${f1(-r * 0.5)} ${f1(-r * 0.3)}L${f1(-r * 0.1)} ${f1(-r * 0.5)}L${f1(r * 0.3)} ${f1(-r * 0.2)}L${f1(r * 0.5)} ${f1(r * 0.2)}" stroke="#bff8ff" stroke-width="${f1(0.3 * k)}" fill="none" opacity="0.8"/></g>`;
      g += `<rect x="${f1(-r)}" y="${f1(-r)}" width="${f1(2 * r)}" height="${f1(1.2 * k)}" fill="#bff8ff" opacity="0.35">${an('y', `${f1(-r)};${f1(r)}`, 2.4)}</rect>`;
      f += `<path d="M${P2(p(-4, 30, 0))}L${P2(p(-GR * 0.9, GY, 0))}L${P2(p(GR * 0.9, GY, 0))}L${P2(p(4, 30, 0))}Z" fill="#7ef6ff" opacity="0.14"/>`;
      f += `<g transform="translate(${P2(C)})"><g>${atV('translate', ['0 0', `0 ${f1(-2 * k)}`, '0 0'], 4)}<g clip-path="url(#gb8c)">${g}</g><circle r="${f1(r)}" fill="none" stroke="#bff8ff" stroke-width="${f1(0.5 * k)}" opacity="0.8"/>${an('opacity', '0.85;1;0.7;1;0.85', 3)}</g></g>`;
      // floating crystal carafe + glass
      f += `<g transform="translate(${P2(p(20, 36, 10))}) scale(${n4(k)})"><g>${atV('translate', ['0 0', '0 -2.4', '0 0'], 3.2, -1)}<ellipse cy="5" rx="4" ry="1.2" fill="#7ef6ff" opacity="0.3"/><path d="M-3.6 0Q-4.6 -6 -1.4 -8V-12H1.4V-8Q4.6 -6 3.6 0Z" fill="#e8fbff" opacity="0.45" stroke="#ffffff" stroke-width="0.3"/><path d="M-3.4 -1Q-3.8 -4 -2 -5.4H2Q3.8 -4 3.4 -1Z" fill="#b48aff" opacity="0.7"/><path d="M-1.8 -7V-2" stroke="#ffffff" stroke-width="0.5" opacity="0.7"/></g></g>`;
      f += `<g transform="translate(${P2(p(-18, 32, 14))}) scale(${n4(k)})"><g>${atV('translate', ['0 -1', '0 1', '0 -1'], 2.6)}${GLASS('#b48aff', 5)}</g></g>`;
      return { defs: FDEF + G('gb8', [[0, '#7ef6ff', 0.15], [0.7, '#2a8aff', 0.18], [1, '#7ef6ff', 0.45]], 'cx="45%" cy="40%" r="60%"') + `<clipPath id="gb8c"><circle r="${f1(r + 0.2)}"/></clipPath>`, front: f, bb: bbOf([p(-24, 0, -24), p(24, 0, 24), p(-24, 0, 24), p(24, 0, -24), p(0, GY + GR + 6, 0), p(-GR - 4, GY, 0), p(GR + 4, GY, 0)], 3) }; };
    return D; };

  // ======================= SOLAR-CHARGING LEVITATING DRINK PEDESTAL =======================
  N.pedestal8 = S => { const TY = 34;
    const D = { w: 46, d: 46, round: 1, glow: () => ({ y: 30, r: 40 }) };
    D.build = P => [cyl(0, 0, 0, 16, 4, '#26272b', mt({ n: 28, shine: 1, rg: [[0, 0, 1], [4, 0, 0.9]] })), cyl(0, 4, 0, 6, 10, '#2f3136', mt({ n: 16, shine: 1, rg: [[0, 0, 1.2], [10, 0, 0.8]] }))];
    D.layers = [{ build: P => [cyl(0, TY - 3, 0, 14, 3, '#e8ecf0', mt({ n: 28, shine: 1, rg: [[0, 0, 0.8], [3, 0, 1]] })), cyl(0, TY - 3.6, 0, 8, 0.6, '#7ef6ff', { emit: 1, n: 20 })],
      wrap: (p, s) => { const k = kOf(p); const items = at(p, k, -4, TY, 2, 1, GLASS('#ff9a3a', 7) + '<path d="M0.6 -7L2.4 -11" stroke="#ff4fb8" stroke-width="0.4"/><circle cx="-1" cy="-7.2" r="0.9" fill="#ff5a3a"/>') + at(p, k, 5, TY, -3, 1, WINE('#7ef6ff'));
        return `<g>${atV('translate', ['0 0', `0 ${f1(-3 * k)}`, '0 0'], 3.6)}${s}${items}</g>`; } }];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      f += `<g transform="${planeH(p, 4.05)}"><circle r="14.6" fill="#1a2a4a"/>${rep(6, i => `<path d="M${-12 + i * 4.8} -12V12M-12 ${-12 + i * 4.8}H12" stroke="#4a7ad8" stroke-width="0.4" opacity="0.8"/>`).join('')}<circle r="14.6" fill="url(#pd8)"/><circle r="6.4" fill="#2f3136"/></g>`;
      rep(3, i => { const y = 16 + i * 5; f += `<path d="${sp(p, ellPts(0, 0, 9, 9, 30), y)}" fill="none" stroke="#7ef6ff" stroke-width="${f1(0.5 * k)}" opacity="0"><animate attributeName="opacity" values="0;0.8;0" dur="1.8s"${B(-i * 0.6)} repeatCount="indefinite"/></path>`; });
      f += glowE(p, 0, 14, 0, 10, 10, '#7ef6ff', 0.5, 1);
      return { defs: FDEF + G('pd8', [[0, '#ffffff', 0], [0.7, '#ffffff', 0], [0.9, '#ffffff', 0.25], [1, '#ffffff', 0]], 'cx="40%" cy="35%" r="65%"'), back: bk, front: f, bb: bbOf([p(-20, 0, -20), p(20, 0, 20), p(-20, 0, 20), p(20, 0, -20), p(0, TY + 16, 0)], 3) }; };
    return D; };

  // ======================= GALVANIZED DRINKS TUB (ice, condensation, cold mist) =======================
  N.tub8 = S => { const RX = 24, RZ = 15, H = 18, GV = '#b8c0c6';
    const D = { w: 70, d: 44 };
    D.build = P => [cyl(0, 0, 0, RX, H, GV, mt({ rz: RZ, n: 32, shine: 1, rg: [[0, 0, 0.9], [H, 0, 1]] })), arcW(0, H - 1, 0, RX + 0.8, RZ + 0.8, 1.4, 1.6, 4.4, 4.4 + 2 * PI, '#d5dde2', mt({ n: 32, shine: 1 })), ...[4, 10].map(y => arcW(0, y, 0, RX * (0.9 + y / H * 0.1) + 0.5, RZ * (0.9 + y / H * 0.1) + 0.5, 0.8, 1.2, 4.4, 4.4 + 2 * PI, '#9aa3a8', mt({ n: 32 })))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      let ice = `<ellipse rx="${RX - 1.4}" ry="${RZ - 1.2}" fill="#d8eef4"/>`; const R = rng('ice'); rep(26, i => { const a = R() * 2 * PI, r = Math.sqrt(R()), x = Math.cos(a) * r * (RX - 4), z = Math.sin(a) * r * (RZ - 3); ice += `<rect x="${f1(x - 1.6)}" y="${f1(z - 1.4)}" width="3.2" height="2.8" rx="0.7" fill="#f4fbff" stroke="#a8d4e4" stroke-width="0.25" transform="rotate(${f1(R() * 90)} ${f1(x)} ${f1(z)})" opacity="0.92"/>`; });
      f += `<g clip-path="url(#tb8c)"><g transform="${planeH(p, H - 2)}">${ice}</g></g>`;
      [[-12, -4, BOTTLE('#3f7a34', '#f2c14a'), -12], [-4, -6, BOTTLE('#7a4a26', '#f4efe6'), 6], [6, -3, BOTTLE('#2f86c8', '#ffffff'), -8], [14, -5, BOTTLE('#3f7a34', '#e8343c'), 14], [-8, 4, '<rect x="-1.8" y="-6" width="3.6" height="6" rx="0.6" fill="#e8343c"/><rect x="-1.8" y="-4.4" width="3.6" height="1.6" fill="#ffffff"/>', 0], [8, 5, '<rect x="-1.8" y="-6" width="3.6" height="6" rx="0.6" fill="#2fa89a"/><rect x="-1.8" y="-4.6" width="3.6" height="2" fill="#f2c14a"/>', 10]]
        .forEach(([x, z, body, rot]) => f += `<g transform="translate(${P2(p(x, H - 2.6, z))}) scale(${n4(k * 1.25)}) rotate(${rot})">${body}</g>`);
      // condensation drops sliding down the front + cold mist spilling over the rim
      rep(9, i => { const th = PI / 6 - 1 + i * 0.25, q0 = p(RX * Math.sin(th) * 1.01, H - 2, RZ * Math.cos(th) * 1.01), q1 = p(RX * Math.sin(th) * 0.92, 2, RZ * Math.cos(th) * 0.92), d = 2.4 + (i % 3) * 0.7; f += `<ellipse rx="${f1(0.5 * k)}" ry="${f1(0.7 * k)}" fill="#ffffff" opacity="0.8"><animate attributeName="cx" values="${f1(q0[0])};${f1(q1[0])}" dur="${d}s"${B(-i * 0.5)} repeatCount="indefinite"/><animate attributeName="cy" values="${f1(q0[1])};${f1(q1[1])}" dur="${d}s"${B(-i * 0.5)} repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.85;0.85;0" dur="${d}s"${B(-i * 0.5)} repeatCount="indefinite"/></ellipse>`; });
      rep(5, i => { const th = PI / 6 - 0.8 + i * 0.4, q = p(RX * Math.sin(th), H, RZ * Math.cos(th)); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(5 * k)}" ry="${f1(2 * k)}" fill="#ffffff" filter="url(#f7s)" opacity="0"><animate attributeName="cy" values="${f1(q[1])};${f1(q[1] + 10 * k)}" dur="3.4s"${B(-i * 0.7)} repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.5;0" dur="3.4s"${B(-i * 0.7)} repeatCount="indefinite"/></ellipse>`; });
      [-1, 1].forEach(s => f += tube([p(s * (RX + 0.6), H - 4, 0), p(s * (RX + 4), H - 2, 0), p(s * (RX + 0.6), H, 0)], 0.9, k, '#c9d0d6'));
      const nq = p(34, 0, 10); f += `<g transform="translate(${P2(nq)}) scale(${n4(k)})"><rect x="-4" y="-6" width="8" height="6" rx="0.6" fill="#c9d0d6" stroke="#7a8088" stroke-width="0.3"/><path d="M-3.4 -6Q-3 -11 0 -10Q3 -11 3.4 -6Z" fill="url(#tbg)"/></g>`;
      return { defs: FDEF + `<clipPath id="tb8c"><path d="${sp(p, ellPts(0, 0, RX - 0.6, RZ - 0.6, 40), H)}"/></clipPath><pattern id="tbg" width="2" height="2" patternUnits="userSpaceOnUse"><rect width="2" height="2" fill="#fbfaf6"/><rect width="1" height="2" fill="#e8343c" opacity="0.5"/><rect width="2" height="1" fill="#e8343c" opacity="0.5"/></pattern>`, front: f, bb: bbOf([p(-RX - 6, 0, -RZ), p(RX + 6, 0, RZ), p(-RX - 6, 0, RZ), p(RX + 6, 0, -RZ), p(0, H + 14, 0), p(40, 0, 12)], 3) }; };
    return D; };

  // ======================= COPPER WIND CHIME & BIRDHOUSE =======================
  N.chime8 = S => { const CU = '#c8783e', HY = 92;
    const D = { w: 70, d: 40 };
    D.build = P => [box(-20, 0, 0, 3, 64, 3, '#7a5a3a', wd({ r: 0.4 })), box(-20, 64, 0, 16, 12, 14, '#e8dcc0', wd({ r: 0.6 })), prism(-29, -11, [[-9, 75], [9, 75], [0, 84]], '#3a6a8a', wd({})), box(-20, 0, 0, 10, 1.2, 10, '#5a4632', wd({ r: 0.4 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      f += `<g transform="${plane(p, 7.05, 74, -28)}"><circle cx="8" cy="5" r="2.2" fill="#2a1c12"/><rect x="7.4" y="7.6" width="1.2" height="3" fill="#7a5a3a"/><path d="M3 2H13" stroke="#c8b898" stroke-width="0.4"/></g>`;
      // little bird peeking in and out
      f += `<g transform="translate(${P2(p(-20, 69, 7.3))}) scale(${n4(k)})"><g>${atV('translate', ['0 3', '0 3', '0 0', '0 0', '0 3'], 7)}<circle r="1.8" fill="#e8743a"/><circle cx="-0.6" cy="-0.4" r="0.35" fill="#1d1e22"/><path d="M1.4 0L3 0.4L1.4 0.8Z" fill="#f2c14a"/></g></g>`;
      // shepherd hook + chime: top disc, six tubes swinging on their own, clapper + sail, ring arcs when they touch
      bk += tube(curve([18, 0, 0], [18, 70, 0], [18, 94, 0], 6).concat(curve([18, 94, 0], [18, 102, 0], [8, 98, 0], 5).slice(1)).map(q => p(...q)), 1.2, k, '#2a2b30', '#8a8f98');
      const hk = p(8, HY, 0); let ch = `<path d="M${P2(hk)}L${P2(p(8, HY - 6, 0))}" stroke="#4a4e56" stroke-width="${f1(0.3 * k)}"/>`;
      const top = p(8, HY - 6, 0); ch += `<ellipse cx="${f1(top[0])}" cy="${f1(top[1])}" rx="${f1(6 * k)}" ry="${f1(2.2 * k)}" fill="${CU}" stroke="#7a3a1a" stroke-width="${f1(0.3 * k)}"/>`;
      rep(6, i => { const a = i / 6 * 2 * PI, x = 8 + Math.cos(a) * 4.6, z = Math.sin(a) * 4.6, L0 = 14 + (i % 3) * 5, a0 = p(x, HY - 6.6, z), a1 = p(x, HY - 10, z), b1 = p(x, HY - 10 - L0, z);
        ch += `<g><animateTransform attributeName="transform" type="rotate" values="${[-6, 7, -4, 5, -6].map(v => (v * (1 + (i % 2) * 0.4)) + ' ' + P2(a0)).join(';')}" dur="${n4(2.6 + i * 0.37)}s" repeatCount="indefinite" calcMode="spline" keyTimes="0;0.25;0.5;0.75;1" keySplines="0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1"/><path d="M${P2(a0)}L${P2(a1)}" stroke="#4a4e56" stroke-width="${f1(0.25 * k)}"/><path d="M${P2(a1)}L${P2(b1)}" stroke="#7a3a1a" stroke-width="${f1(1.9 * k)}" stroke-linecap="round"/><path d="M${P2(a1)}L${P2(b1)}" stroke="${CU}" stroke-width="${f1(1.4 * k)}" stroke-linecap="round"/><path d="M${P2(a1)}L${P2(b1)}" stroke="#ffd0a0" stroke-width="${f1(0.4 * k)}" stroke-linecap="round" transform="translate(${f1(-0.4 * k)} 0)"/></g>`; });
      const cl = p(8, HY - 22, 0), sl = p(8, HY - 34, 0); ch += `<g><animateTransform attributeName="transform" type="rotate" values="-10 ${P2(top)};12 ${P2(top)};-10 ${P2(top)}" dur="2.2s" repeatCount="indefinite" calcMode="spline" keyTimes="0;0.5;1" keySplines="0.45 0 0.55 1;0.45 0 0.55 1"/><path d="M${P2(top)}L${P2(sl)}" stroke="#4a4e56" stroke-width="${f1(0.25 * k)}"/><ellipse cx="${f1(cl[0])}" cy="${f1(cl[1])}" rx="${f1(2.4 * k)}" ry="${f1(0.9 * k)}" fill="#a85a2a"/><path d="M${f1(sl[0] - 2.6 * k)} ${f1(sl[1])}L${f1(sl[0] + 2.6 * k)} ${f1(sl[1])}L${f1(sl[0])} ${f1(sl[1] + 6 * k)}Z" fill="${CU}" stroke="#7a3a1a" stroke-width="${f1(0.3 * k)}"/></g>`;
      ch += rep(3, i => `<circle cx="${f1(cl[0])}" cy="${f1(cl[1])}" r="${f1(3 * k)}" fill="none" stroke="#ffd0a0" stroke-width="${f1(0.4 * k)}" opacity="0"><animate attributeName="r" values="${f1(3 * k)};${f1(14 * k)}" dur="1.1s"${B(i * 0.73)} repeatCount="indefinite"/><animate attributeName="opacity" values="0.8;0" dur="1.1s"${B(i * 0.73)} repeatCount="indefinite"/></circle>`).join('');
      f += ch;
      return { defs: '', back: bk, front: f, bb: bbOf([p(-30, 0, -10), p(24, 0, 10), p(-30, 86, 0), p(24, 104, 0), p(8, 40, 10)], 4) }; };
    return D; };

  // ======================= UPENDED 5-GALLON BUCKET (tap to tip & spill) =======================
  N.bucket8 = S => { const tip = isPlay(S), OR = '#f27a1a', H = 30, R0 = 13;
    const D = { w: 60, d: 40, round: 1 };
    const body = () => [cyl(0, 0, 0, R0 + 1.2, 3, '#e86a10', pt({ n: 24, shine: 1 })), cyl(0, 3, 0, R0, H - 3, OR, pt({ n: 24, shine: 1, rg: [[0, 0, 1], [H - 3, 0, 0.84]] })), ...[6, 9].map(y => arcW(0, y, 0, R0 + 0.6, R0 + 0.6, 0.8, 1.2, 4.4, 4.4 + 2 * PI, '#e86a10', pt({ n: 24 })))];
    D.build = P => tip ? [] : body(); if (tip) D.build = P => [box(0, 0, 0, 1, 0.1, 1, '#000000', { op: 0 })];
    D.layers = tip ? [{ build: body, wrap: (p, s) => { const piv = p(R0, 0, 0), k = kOf(p), end = `90 ${P2(piv)}`; return `<g>${onceT('rotate', `0 ${P2(piv)};-12 ${P2(piv)};95 ${P2(piv)};86 ${P2(piv)};90 ${P2(piv)}`, '0;0.2;0.62;0.8;1', 1.1)}<g transform="translate(0 0)">${s}</g></g>`.replace('<g transform="translate(0 0)">', `<g>`) + ''; } }] : [];
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      if (!tip) { const q = p(0, H, 0); f += `<g transform="${planeH(p, H + 0.05)}"><circle r="${f1(R0 * 0.84)}" fill="#f8923a"/><circle r="${f1(R0 * 0.6)}" fill="none" stroke="#d85a08" stroke-width="0.6"/><text x="0" y="1.6" text-anchor="middle" font-family="Arial Black, Arial" font-size="4" font-weight="900" fill="#d85a08">5 GAL</text></g>`;
        void q; }
      else { // spill: water gushes out and spreads into a puddle, sponge rolls out
        un += `<g transform="${planeH(p, 0.3)}"><ellipse cx="-14" cy="6" rx="2" ry="1.4" fill="#7ac8e8" opacity="0.7">${once('rx', '2;30;34', '0;0.7;1', 1.6, 0.6)}${once('ry', '1.4;14;16', '0;0.7;1', 1.6, 0.6)}</ellipse><ellipse cx="-14" cy="6" rx="1" ry="1" fill="none" stroke="#ffffff" stroke-width="0.6" opacity="0">${once('opacity', '0;0.8;0.3', '0;0.3;1', 1.8, 0.7)}${once('rx', '1;24', '0;1', 1.8, 0.7)}${once('ry', '1;11', '0;1', 1.8, 0.7)}</ellipse></g>`;
        rep(6, i => { const a = p(-2, 6 + i * 1.2, 0), b = p(-18 - i * 3, 0.3, 4 + (i % 3) * 3), cc = [(a[0] + b[0]) / 2, a[1] - 6 * k]; f += `<circle r="${f1((0.8 + (i % 3) * 0.3) * k)}" fill="#bfe8f8" opacity="0"><animateMotion dur="0.7s" begin="${n4(0.55 + i * 0.08)}s" fill="freeze" path="M${P2(a)}Q${f1(cc[0])} ${f1(cc[1])} ${P2(b)}"/>${once('opacity', '0;1;0', '0;0.3;1', 0.7, 0.55 + i * 0.08)}</circle>`; });
        f += `<g transform="translate(${P2(p(-26, 0, 12))}) scale(${n4(k)})"><g opacity="0">${once('opacity', '0;1', '0;1', 0.2, 0.9)}<g>${onceT('translate', '18 -4;0 0', '0;1', 0.8, 0.9)}<rect x="-3.4" y="-3" width="6.8" height="3.4" rx="0.8" fill="#f2d23a"/><rect x="-3.4" y="-3.6" width="6.8" height="1.2" rx="0.5" fill="#3f8a34"/></g></g></g>`; }
      return { defs: '', under: un, front: f, bb: bbOf([p(-40, 0, -14), p(40, 0, 20), p(-40, 0, 20), p(16, H + 6, 0), p(H + 14, 18, 0)], 3) }; };
    return D; };

  // ======================= SINGLE BUG-ZAPPER BULB ON A POST =======================
  N.zapper8 = S => { const BY = 70;
    const D = { w: 30, d: 30, round: 1, glow: () => ({ y: BY, r: 40 }) };
    D.build = P => [cyl(0, 0, 0, 7, 2, '#6a6a6a', pt({ n: 12 })), cyl(0, 2, 0, 1.8, BY - 8, '#7a5a3a', wd({ n: 10 })), box(4, BY - 8, 0, 9, 2, 2, '#2a2b30', mt({ r: 0.4 })), cyl(10, BY - 10, 0, 2.6, 4, '#2a2b30', mt({ n: 12 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      const q = p(10, BY - 13, 0), u = k;
      // cage + UV coil + the bulb glow, periodic zap flash with sparks and a bug puff
      f += `<g transform="translate(${P2(q)}) scale(${n4(u)})"><circle cy="7" r="16" fill="#7a5aff" opacity="0.18" filter="url(#f7s)">${an('opacity', '0.14;0.24;0.14', 1.6)}</circle><path d="M-5 0Q-6.4 7 -4 13Q0 16 4 13Q6.4 7 5 0Z" fill="#cfe0ff" opacity="0.55"/><path d="M-4 2Q-5 7 -3 12Q0 14.4 3 12Q5 7 4 2Z" fill="#8a7aff">${an('opacity', '0.75;1;0.8', 0.4)}</path>`
        + rep(5, i => `<path d="M-4 ${2.6 + i * 2.2}Q0 ${3.6 + i * 2.2} 4 ${2.6 + i * 2.2}" stroke="#e8e0ff" stroke-width="0.35" fill="none"/>`).join('') + rep(7, i => `<path d="M${-5 + i * 1.66} 0V13" stroke="#3a3c42" stroke-width="0.4"/>`).join('') + '<rect x="-5.2" y="-1" width="10.4" height="1.6" rx="0.4" fill="#2a2b30"/><circle cy="15.6" r="1" fill="#2a2b30"/>'
        + `<g opacity="0"><animate attributeName="opacity" values="0;0;1;0;0.8;0;0" keyTimes="0;0.6;0.62;0.66;0.68;0.72;1" dur="3.2s" repeatCount="indefinite"/><circle cy="7" r="9" fill="#ffffff" filter="url(#f7b)"/>${rep(6, i => { const a = i / 6 * 2 * PI; return `<path d="M${f1(Math.cos(a) * 3)} ${f1(7 + Math.sin(a) * 3)}L${f1(Math.cos(a + 0.3) * 7)} ${f1(7 + Math.sin(a + 0.3) * 6)}L${f1(Math.cos(a) * 10)} ${f1(7 + Math.sin(a) * 9)}" stroke="#ffffff" stroke-width="0.6" fill="none"/>`; }).join('')}<circle cx="3" cy="4" r="2.4" fill="#4a4a4a" opacity="0.5" filter="url(#f7b)"/></g></g>`;
      // moths circling the light
      rep(4, i => { const rx = (12 + i * 3) * k, ry = (6 + i * 1.6) * k, d = 2.6 + i * 0.7, pth = `M${f1(q[0] - rx)} ${f1(q[1] + 7 * k)}a${f1(rx)} ${f1(ry)} 0 1 ${i % 2} ${f1(2 * rx)} 0a${f1(rx)} ${f1(ry)} 0 1 ${i % 2} ${f1(-2 * rx)} 0`;
        f += `<g>${`<animateMotion dur="${d}s" repeatCount="indefinite" path="${pth}"/>`}<g transform="scale(${n4(k)})"><ellipse rx="0.8" ry="0.5" fill="#5a4a3a"/><path d="M0 0L-1.6 -1.4L-0.6 0L-1.6 1.4Z" fill="#cbb89a" opacity="0.85">${an('opacity', '0.9;0.3;0.9', 0.12)}</path><path d="M0 0L1.6 -1.4L0.6 0L1.6 1.4Z" fill="#cbb89a" opacity="0.85">${an('opacity', '0.3;0.9;0.3', 0.12)}</path></g></g>`; });
      return { defs: FDEF, front: f, bb: bbOf([p(-12, 0, -10), p(12, 0, 10), p(-20, BY + 10, 0), p(36, BY + 10, 0), p(10, BY - 30, 0)], 4) }; };
    return D; };

  // ======================= FIREFLY-SWARM MICRO-DRONE LIGHT CHOREOGRAPHY =======================
  N.drones8 = S => {
    const D = { w: 80, d: 80, round: 1, glow: () => ({ y: 30, r: 60 }) };
    D.build = P => [cyl(0, 0, 0, 12, 3, '#26272b', mt({ n: 24, shine: 1, rg: [[0, 0, 1], [3, 0, 0.85]] })), cyl(0, 3, 0, 8, 1, '#c9ff7a', { emit: 1, n: 20 })];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      const R = rng('drn'); rep(18, i => { const g = i % 3, cx = 0, cy = 34 + g * 10, ph = i / 18 * 2 * PI, rr = 18 + g * 8, d = 9 + g * 3;
        const pts = rep(25, j => { const t = j / 24 * 2 * PI; return p(cx + Math.cos(t + ph) * rr, cy + Math.sin(2 * t + ph) * (6 + g * 2), Math.sin(t + ph) * rr * 0.9 * (g === 1 ? -1 : 1)); });
        const pth = 'M' + pts.map(P2).join('L') + 'Z', col = ['#c9ff7a', '#ffe66a', '#9af0ff'][g];
        f += `<g>${amo(pth, d, -i * d / 18)}<circle r="${f1(4 * k)}" fill="${col}" opacity="0.25" filter="url(#f7b)"/><g transform="scale(${n4(k)})"><ellipse rx="2.2" ry="0.5" fill="#9aa1ad" opacity="0.5">${an('rx', '2.2;1.2;2.2', 0.1)}</ellipse><circle r="0.9" fill="#2a2b30"/><circle cy="0.6" r="0.6" fill="${col}">${an('opacity', '1;0.5;1', n4(1 + R()), -R())}</circle></g></g>`; });
      f += `<path d="${sp(p, ellPts(0, 0, 11, 11, 30), 3)}" fill="none" stroke="#c9ff7a" stroke-width="${f1(0.6 * k)}">${an('opacity', '0.4;1;0.4', 2)}</path>`;
      return { defs: FDEF, front: f, bb: bbOf([p(-40, 0, -40), p(40, 0, 40), p(-40, 70, 0), p(40, 70, 0), p(0, 80, 0)], 4) }; };
    return D; };

  // =========================================================== GAMES (section 4) ===========================================================
  const PL9 = {};
  const BALL = (r, kind) => kind === 'soccer' ? `<circle r="${r}" fill="#fbfbf6" stroke="#1d1e22" stroke-width="${f1(r * 0.08)}"/><path d="M0 ${f1(-r * 0.38)}L${f1(r * 0.36)} ${f1(-r * 0.12)}L${f1(r * 0.22)} ${f1(r * 0.3)}L${f1(-r * 0.22)} ${f1(r * 0.3)}L${f1(-r * 0.36)} ${f1(-r * 0.12)}Z" fill="#1d1e22"/><circle cx="${f1(-r * 0.35)}" cy="${f1(-r * 0.4)}" r="${f1(r * 0.25)}" fill="#ffffff" opacity="0.5"/>`
    : kind === 'bball' ? `<circle r="${r}" fill="#e8742a" stroke="#5a2a10" stroke-width="${f1(r * 0.08)}"/><path d="M${-r} 0H${r}M0 ${-r}V${r}M${f1(-r * 0.7)} ${f1(-r * 0.7)}Q0 0 ${f1(-r * 0.7)} ${f1(r * 0.7)}M${f1(r * 0.7)} ${f1(-r * 0.7)}Q0 0 ${f1(r * 0.7)} ${f1(r * 0.7)}" stroke="#5a2a10" stroke-width="${f1(r * 0.08)}" fill="none"/>`
    : kind === 'tennis' ? `<circle r="${r}" fill="#d8f23a" stroke="#8aa81a" stroke-width="${f1(r * 0.08)}"/><path d="M${f1(-r * 0.8)} ${f1(-r * 0.5)}Q0 ${f1(r * 0.2)} ${f1(r * 0.8)} ${f1(-r * 0.5)}" stroke="#ffffff" stroke-width="${f1(r * 0.12)}" fill="none"/>`
    : `<circle r="${r}" fill="${kind || '#ffffff'}" stroke="#4a4a4a" stroke-width="${f1(r * 0.08)}"/><circle cx="${f1(-r * 0.35)}" cy="${f1(-r * 0.35)}" r="${f1(r * 0.3)}" fill="#ffffff" opacity="0.55"/>`;
  const turf = (p, x, z, hx, hz, c1, c2) => `<g transform="${planeH(p, 0.3)}"><rect x="${x - hx}" y="${z - hz}" width="${2 * hx}" height="${2 * hz}" rx="3" fill="${c1}"/>${rep(Math.floor(hx / 6), i => i % 2 ? '' : `<rect x="${x - hx + i * 12}" y="${z - hz}" width="12" height="${2 * hz}" fill="${c2}" opacity="0.5"/>`).join('')}</g>`;
  const ballFly = (p, k, pts, d, body, s, b) => `<g>${amo('M' + pts.map(q => P2(p(...q))).join('L'), d, b)}<g transform="scale(${n4(k * (s || 1))})">${body}</g></g>`;

  // ---------- Backyard Soccer Goal (3 players: keeper + 2 strikers) ----------
  N.goal8 = S => { const W = 44, H = 32, DP = 22, pl = isPlay(S);
    const D = { w: 140, d: 120 };
    D.build = P => [box(0, 0, 0, 2, 0.1, 2, '#ffffff', { op: 0 })];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      const un = turf(p, 0, 22, 66, 46, '#5aa844', '#6fbf54') + `<g transform="${planeH(p, 0.35)}" fill="none" stroke="#ffffff" stroke-width="1"><path d="M${-W - 12} 0V22H${W + 12}V0M${-W + 8} 0V9H${W - 8}V0"/><path d="M-14 22A14 10 0 0 0 14 22"/><circle cx="0" cy="16" r="0.9" fill="#ffffff"/></g>`;
      // net: posts, crossbar, back stanchions and mesh
      const post = [[-W, 0, 0], [-W, H, 0], [W, H, 0], [W, 0, 0]], bx = [[-W, H - 6, -DP], [W, H - 6, -DP]];
      let net = ''; const NET = '#f4f4f0';
      rep(12, i => { const x = -W + i * (2 * W / 11); net += `<path d="M${P2(p(x, H, 0))}L${P2(p(x, H - 6, -DP))}L${P2(p(x, 0, -DP - 4))}" stroke="${NET}" stroke-width="${f1(0.3 * k)}" fill="none" opacity="0.8"/>`; });
      rep(7, i => { const t = i / 6; net += `<path d="M${P2(p(-W, H * (1 - t), -DP * (t < 0.2 ? t * 5 : 1) - 4 * t))}L${P2(p(W, H * (1 - t), -DP * (t < 0.2 ? t * 5 : 1) - 4 * t))}" stroke="${NET}" stroke-width="${f1(0.3 * k)}" opacity="0.8"/>`; });
      [-W, W].forEach(x => { rep(6, i => { const t = i / 5; net += `<path d="M${P2(p(x, H * t, 0))}L${P2(p(x, (H - 6) * t, -DP - 4 * (1 - t)))}" stroke="${NET}" stroke-width="${f1(0.3 * k)}" opacity="0.7"/>`; }); });
      bk += `<g>${pl ? atV('translate', ['0 0', '0 0', `${f1(-1 * k)} ${f1(-2 * k)}`, '0 0', '0 0'], 4) : ''}${net}</g>` + tube(bx.map(q => p(...q)), 0.8, k, '#d8d8d4') + tube([p(-W, 0, -DP - 4), p(-W, H - 6, -DP), p(-W, H, 0)], 0.8, k, '#d8d8d4') + tube([p(W, 0, -DP - 4), p(W, H - 6, -DP), p(W, H, 0)], 0.8, k, '#d8d8d4');
      f += tube(post.map(q => p(...q)), 1.8, k, '#ffffff', '#ffffff', '#6a6a60');
      // the match: dribble, pass, shot into the net, reset (4 s loop); idle ball on the spot
      if (pl) f += ballFly(p, k, [[-30, 2.2, 54], [-10, 2.2, 46], [-10, 2.2, 46], [18, 2.2, 40], [18, 2.2, 40], [8, 12, 18], [6, 18, -4], [4, 3, -16], [0, 2.2, 54], [-30, 2.2, 54]], 4, BALL(2.6, 'soccer'));
      else f += at(p, k, 0, 2.6, 16, 1, BALL(2.6, 'soccer'));
      return { defs: '', under: un, back: bk, front: f, bb: bbOf([p(-66, 0, -26), p(66, 0, 70), p(-66, 0, 70), p(66, 0, -26), p(-W, H + 8, 0), p(W, H + 8, 0)], 3) }; };
    return D; };
  PL9.goal8 = () => [{ x: 0, z: 6, v: 'front', a: 'gkeep' }, { x: -24, z: 52, v: 'back', a: 'grun' }, { x: 20, z: 42, v: 'back', a: 'gkick', d: 0.3 }];

  // ---------- Driveway Basketball Hoop (3 players) ----------
  N.hoop8 = S => { const pl = isPlay(S), RY = 64, BZ = -30;
    const D = { w: 110, d: 110 };
    D.build = P => [cyl(0, 0, BZ - 8, 4, 2, '#3a3c42', mt({ n: 12 })), cyl(0, 2, BZ - 8, 1.8, RY + 14, '#3a3c42', mt({ n: 12, shine: 1 })), box(0, RY - 2, BZ + 0.6, 34, 22, 1.2, '#e8f4f8', { op: 0.55, mat: 'metal', shine: 1, r: 1 }), box(0, RY + 2, BZ - 4, 6, 2, 8, '#3a3c42', mt({ r: 0.4 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      const un = `<g transform="${planeH(p, 0.3)}"><rect x="-50" y="-36" width="100" height="90" rx="2" fill="#bdb8ae"/>${rep(8, i => `<path d="M-50 ${-36 + i * 12}H50" stroke="#a8a398" stroke-width="0.4"/>`).join('')}<path d="M-14 -34V8H14V-34M-14 8A14 14 0 0 0 14 8M-44 -34V-10A44 44 0 0 0 44 -10V-34" fill="none" stroke="#ffffff" stroke-width="1"/></g>`;
      f += `<g transform="${plane(p, BZ + 1.25, RY + 20, -17)}"><rect x="0.6" y="0.6" width="32.8" height="20.8" rx="1" fill="none" stroke="#e8343c" stroke-width="1.2"/><rect x="11" y="9" width="12" height="9" fill="none" stroke="#e8343c" stroke-width="0.9"/></g>`;
      const rim = ellPts(0, BZ + 9, 7, 7, 24).map(([x, z]) => p(x, RY, z));
      let net = ''; rep(12, i => { const a = i / 12 * 2 * PI, t0 = p(7 * Math.cos(a), RY, BZ + 9 + 7 * Math.sin(a)), t1 = p(4 * Math.cos(a + 0.4), RY - 10, BZ + 9 + 4 * Math.sin(a + 0.4)); net += `<path d="M${P2(t0)}L${P2(t1)}" stroke="#ffffff" stroke-width="${f1(0.3 * k)}" opacity="0.9"/>`; });
      net += [3.4, 6.8].map(dy => `<path d="${sp(p, ellPts(0, BZ + 9, 7 - dy * 0.3, 7 - dy * 0.3, 20), RY - dy)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.3 * k)}" opacity="0.8"/>`).join('');
      f += `<g>${pl ? atV('scale', ['1 1', '1 1', '1 1.08', '1 1', '1 1'], 3.2) : ''}${net}</g><path d="M${rim.map(P2).join('L')}Z" fill="none" stroke="#e8642a" stroke-width="${f1(1 * k)}"/>`;
      if (pl) { const sh = [[-24, 34, 30], [-12, 70, 8], [0, RY + 4, BZ + 9], [0, RY - 8, BZ + 9], [0, 2.6, BZ + 14], [4, 10, BZ + 24], [12, 2.6, 6], [18, 12, 18], [22, 2.6, 26], [-10, 20, 30], [-24, 34, 30]];
        f += ballFly(p, k, sh, 3.2, BALL(2.6, 'bball')); }
      else f += at(p, k, 10, 2.6, 6, 1, BALL(2.6, 'bball'));
      return { defs: '', under: un, front: f, bb: bbOf([p(-50, 0, -36), p(50, 0, 54), p(-50, 0, 54), p(50, 0, -36), p(0, RY + 24, BZ), p(-17, RY + 22, BZ)], 3) }; };
    return D; };
  PL9.hoop8 = () => [{ x: -24, z: 30, v: 'back', a: 'gjump' }, { x: 16, z: 22, v: 'back', a: 'grun', d: 0.4 }, { x: 0, z: -6, v: 'front', a: 'gjump', d: 0.6 }];

  // ---------- Private 3-Hole Putting Green & Outdoor Cinema Screen (2 players) ----------
  N.golf8 = S => { const pl = isPlay(S);
    const D = { w: 160, d: 110 };
    D.build = P => [box(46, 0, -40, 4, 44, 4, '#2a2b30', mt({ r: 0.6 })), box(46 + 48, 0, -40, 4, 44, 4, '#2a2b30', mt({ r: 0.6 })), box(70, 18, -40, 52, 28, 2, '#2a2b30', mt({ r: 0.6 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      const blob = rep(20, i => { const a = i / 20 * 2 * PI; return [-10 + Math.cos(a) * (62 + Math.sin(a * 3) * 6), 4 + Math.sin(a) * (40 + Math.cos(a * 2) * 5)]; });
      const un = `<g transform="${planeH(p, 0.3)}"><path d="${lp(blob.map(([x, z]) => [x * 1.08, z * 1.1]))}" fill="#4f9a3e"/><path d="${lp(blob)}" fill="#6fbf54"/><path d="${lp(blob)}" fill="url(#gf8)"/>${[[-48, 20], [-10, -18], [26, 24]].map(([x, z]) => `<ellipse cx="${x}" cy="${z}" rx="2.2" ry="2.2" fill="#1d2a1d"/><ellipse cx="${x}" cy="${z}" rx="2.2" ry="2.2" fill="none" stroke="#ffffff" stroke-width="0.4"/>`).join('')}</g>`;
      [[-48, 20, 1], [-10, -18, 2], [26, 24, 3]].forEach(([x, z, n], i) => { const b = p(x, 0, z), t = p(x, 24, z); f += `<path d="M${P2(b)}L${P2(t)}" stroke="#f4f4f0" stroke-width="${f1(0.6 * k)}"/><g transform="translate(${P2(t)}) scale(${n4(k)})"><path d="M0 0L9 2L0 5Z" fill="${['#e8343c', '#f2c14a', '#2f86c8'][i]}">${atV('skewY', ['0', '-8', '4', '0'], 1.6, -i * 0.4)}</path><text x="3" y="3.6" font-family="Arial" font-size="2.8" font-weight="800" fill="#ffffff">${n}</text></g>`; });
      // cinema screen on its frame, looping a cartoon
      const sc = `<rect x="0" y="0" width="48" height="25" fill="#0e1018"/><rect x="1" y="1" width="46" height="23" fill="url(#gf8s)"/><circle cx="12" cy="14" r="5" fill="#ffd23a">${an('cx', '8;40;8', 6)}</circle><rect x="1" y="19" width="46" height="5" fill="#5aa844"/><path d="M30 19L36 9L42 19Z" fill="#3f7a34"/>`;
      f += `<g transform="${plane(p, -38.9, 45.5, 46)}">${sc}</g>`;
      if (pl) { f += ballFly(p, k, [[-30, 1.2, 36], [-38, 1.2, 30], [-46, 1.2, 22], [-48, 0, 20], [-48, 0, 20], [-30, 1.2, 36]], 5, BALL(1.2, '#ffffff')) + ballFly(p, k, [[6, 1.2, 6], [-2, 1.2, -6], [-8, 1.2, -14], [-10, 0, -18], [-10, 0, -18], [6, 1.2, 6]], 5, BALL(1.2, '#ffffff'), 1, -2.4); }
      else f += at(p, k, -30, 1.2, 36, 1, BALL(1.2, '#ffffff'));
      return { defs: G('gf8', [[0, '#ffffff', 0.18], [1, '#000000', 0.1]], 'cx="40%" cy="40%" r="70%"') + L('gf8s', [[0, '#7ac8ff'], [1, '#d8f2ff']]), under: un, front: f, bb: bbOf([p(-80, 0, -50), p(70, 0, 52), p(-80, 0, 52), p(98, 48, -40), p(44, 48, -40)], 3) }; };
    return D; };
  PL9.golf8 = () => [{ x: -30, z: 42, v: 'left', a: 'gswing' }, { x: 8, z: 12, v: 'left', a: 'gswing', d: 0.5 }];

  // ---------- Climbing Dome Jungle Gym (4 players) ----------
  N.dome8 = S => { const R0 = 40;
    const D = { w: 100, d: 100, round: 1 };
    D.build = P => [cyl(0, 0, 0, R0 + 8, 1.2, '#b86a3a', pt({ n: 36 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      // geodesic hemisphere: 5 rings of nodes, struts between neighbours; back struts behind, front struts in front
      const RG = [[0, 10], [18, 10], [36, 10], [56, 5], [90, 1]].map(([e, n], i) => rep(n, j => { const a = j / n * 2 * PI + (i % 2) * PI / n, el = e * PI / 180; return [R0 * Math.cos(el) * Math.cos(a), R0 * Math.sin(el), R0 * Math.cos(el) * Math.sin(a)]; }));
      const E = []; RG.forEach((ring, i) => ring.forEach((q, j) => { if (ring.length > 1) E.push([q, ring[(j + 1) % ring.length]]); const nx = RG[i + 1]; if (nx) { const near = nx.map(v => [v, Math.hypot(v[0] - q[0], v[1] - q[1], v[2] - q[2])]).sort((a, b) => a[1] - b[1]).slice(0, nx.length > 2 ? 2 : 1); near.forEach(([v]) => E.push([q, v])); } }));
      const COL = ['#e8343c', '#2f86e6', '#f2c14a', '#3faa5a'];
      E.forEach(([a, b], i) => { const m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2], fr = (m[0] * 0.5 + m[2] * 0.866) / R0; const t = tube([p(...a), p(...b)], 1.3, k, COL[i % 4], '#ffffff', '#2a2b30'); if (fr < -0.05) bk += `<g opacity="0.85">${t}</g>`; else f += t; });
      RG.flat().forEach(q => { const s = p(...q), fr = (q[0] * 0.5 + q[2] * 0.866) / R0; const n = `<circle cx="${f1(s[0])}" cy="${f1(s[1])}" r="${f1(1.4 * k)}" fill="#3a3c42"/>`; if (fr < -0.05) bk += n; else f += n; });
      return { defs: '', back: bk, front: f, bb: bbOf([p(-R0 - 8, 0, -R0 - 8), p(R0 + 8, 0, R0 + 8), p(-R0 - 8, 0, R0 + 8), p(R0 + 8, 0, -R0 - 8), p(0, R0 + 4, 0)], 3) }; };
    return D; };
  PL9.dome8 = () => [{ x: 0, y: 40, z: 0, v: 'front', a: 'gclimb' }, { x: -24, y: 20, z: 22, v: 'front', a: 'gclimb', d: 0.3 }, { x: 26, y: 14, z: 26, v: 'right', a: 'gclimb', d: 0.6 }, { x: 34, y: 0, z: 34, v: 'front', a: 'gjump', d: 0.2 }];

  // ---------- Anti-Gravity Pet Bounce-Dome & Fetch Launcher (1 player) ----------
  N.bounce8 = S => { const pl = isPlay(S), R0 = 34;
    const D = { w: 110, d: 90, glow: () => ({ y: 20, r: 60 }) };
    D.build = P => [cyl(0, 0, 0, R0 + 4, 4, '#26272b', mt({ n: 36, shine: 1, rg: [[0, 0, 1], [4, 0, 0.95]] })), cyl(0, 4, 0, R0, 0.8, '#7ef6ff', { emit: 1, n: 36 }), cyl(52, 0, 18, 7, 10, '#e8ecf0', mt({ n: 18, shine: 1, rg: [[0, 0, 1], [10, 0, 0.8]] })), cyl(52, 10, 18, 4, 6, '#2a2b30', mt({ n: 14, shine: 1 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      const C = p(0, 4, 0), Rr = R0 * k, top = p(0, 4 + R0, 0);
      const dome = `M${f1(C[0] - Rr)} ${f1(C[1])}A${f1(Rr)} ${f1(Rr * 1.05)} 0 0 1 ${f1(C[0] + Rr)} ${f1(C[1])}A${f1(Rr)} ${f1(Rr * X.SA)} 0 0 1 ${f1(C[0] - Rr)} ${f1(C[1])}Z`; void top;
      f += `<path d="${dome}" fill="url(#bd8)"/><path d="${dome}" fill="url(#bd8h)" opacity="0.9"/><path d="${dome}" fill="none" stroke="#bff8ff" stroke-width="${f1(0.6 * k)}" opacity="0.8"/><path d="M${f1(C[0] - Rr * 0.7)} ${f1(C[1] - Rr * 0.5)}Q${f1(C[0] - Rr * 0.4)} ${f1(C[1] - Rr * 0.95)} ${f1(C[0])} ${f1(C[1] - Rr)}" stroke="#ffffff" stroke-width="${f1(1.4 * k)}" fill="none" opacity="0.5"/>`;
      // floating orbs inside + launcher lobbing a glowing ball through the field
      rep(3, i => f += `<g transform="translate(${P2(p(-12 + i * 12, 22 + i * 4, -6 + i * 4))}) scale(${n4(k)})"><g>${atV('translate', ['0 0', '0 -5', '0 0'], 2.4 + i * 0.5, -i)}${BALL(2.4, ['#ff4fb8', '#7ef6ff', '#ffe66a'][i])}</g></g>`);
      if (pl) f += ballFly(p, k, arc3([52, 18, 18], [0, 6, 0], 40, 14).concat(arc3([0, 6, 0], [52, 18, 18], 30, 10).slice(1)), 3, `<circle r="4" fill="#7ef6ff" opacity="0.4" filter="url(#f7b)"/>${BALL(2.2, '#c9ff7a')}`);
      return { defs: FDEF + G('bd8', [[0, '#bff8ff', 0.12], [0.7, '#3a9aff', 0.22], [1, '#7ef6ff', 0.55]], 'cx="42%" cy="62%" r="62%"') + `<pattern id="bd8h" width="8" height="7" patternUnits="userSpaceOnUse"><path d="M2 0L6 0L8 3.5L6 7L2 7L0 3.5Z" fill="none" stroke="#7ef6ff" stroke-width="0.3" opacity="0.6"/></pattern>`, back: bk, front: f, bb: bbOf([p(-R0 - 6, 0, -R0 - 6), p(R0 + 6, 0, R0 + 6), p(-R0 - 6, 0, R0 + 6), p(60, 0, 26), p(0, R0 + 10, 0), p(30, 50, 10)], 3) }; };
    return D; };
  PL9.bounce8 = () => [{ x: 0, y: 8, z: 4, v: 'front', a: 'gbounce' }];

  // ---------- Pet Agility Course: tire jump + endless seesaw (2 players) ----------
  N.agility8 = S => { const pl = isPlay(S);
    const D = { w: 150, d: 90 };
    D.build = P => [box(-36, 0, -12, 3, 40, 3, '#3f8ad8', pt({ r: 0.6 })), box(-36, 0, 16, 3, 40, 3, '#3f8ad8', pt({ r: 0.6 })), box(-36, 40, 2, 3, 3, 31, '#3f8ad8', pt({ r: 0.6 })), box(-36, 0, 2, 16, 1.6, 34, '#3f8ad8', pt({ r: 0.6 })),
      prism(26, 34, [[-6, 0], [6, 0], [0, 10]], '#f2c14a', pt({})), ...rep(5, i => cyl(-4 + i * 7, 0, 30, 1, 26, i % 2 ? '#e8343c' : '#ffffff', pt({ n: 8 })))];
    D.layers = [{ build: P => [box(30, 10, 0, 76, 2.2, 12, '#e8343c', pt({ r: 0.8 })), box(30, 12.2, 0, 76, 0.4, 10, '#f4f4f0', pt({ r: 0.4 }))], wrap: (p, s) => { const pv = p(30, 10, 0); return `<g>${atV('rotate', [`-7 ${P2(pv)}`, `7 ${P2(pv)}`, `-7 ${P2(pv)}`], 2.6)}${s}</g>`; } }];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      const un = turf(p, 0, 6, 74, 44, '#5aa844', '#6fbf54');
      const tc = p(-36, 24, 2); f += `<path d="M${P2(p(-36, 40, -6))}L${P2(p(-36, 34, -6))}M${P2(p(-36, 40, 10))}L${P2(p(-36, 34, 10))}" stroke="#2a2b30" stroke-width="${f1(0.6 * k)}"/><g transform="translate(${P2(tc)}) scale(${n4(k)})"><ellipse rx="4.6" ry="11" fill="none" stroke="#1d1e22" stroke-width="4"/><ellipse rx="4.6" ry="11" fill="none" stroke="#3a3c42" stroke-width="1.2"/><ellipse cx="-0.6" rx="3.6" ry="9.6" fill="none" stroke="#e8343c" stroke-width="0.5" stroke-dasharray="2 2"/></g>`;
      if (pl) f += ballFly(p, k, [[-60, 2, 2], [-36, 24, 2], [-12, 2, 2], [-12, 2, 2], [-60, 2, 2]], 5, BALL(2, 'tennis'));
      return { defs: '', under: un, front: f, bb: bbOf([p(-74, 0, -40), p(74, 0, 50), p(-74, 0, 50), p(74, 0, -40), p(-36, 48, 2), p(68, 20, 0)], 3) }; };
    return D; };
  PL9.agility8 = () => [{ x: 52, y: 14, z: 0, v: 'front', a: 'gsee' }, { x: -52, z: 2, v: 'right', a: 'gjump', d: 0.4 }];

  // ---------- Cedar Bocce Court & Ping-Pong Table (2 players) ----------
  N.bocce8 = S => { const pl = isPlay(S), CED = '#b9733e';
    const D = { w: 170, d: 110 };
    D.build = P => [box(-30, 0, 30, 110, 4, 4, CED, wd({ r: 0.5 })), box(-30, 0, 60, 110, 4, 4, CED, wd({ r: 0.5 })), box(-85, 0, 45, 4, 4, 34, CED, wd({ r: 0.5 })), box(25, 0, 45, 4, 4, 34, CED, wd({ r: 0.5 })), box(-30, 0, 45, 106, 1.6, 26, '#d8c49a', pt({ r: 0.5 })),
      box(10, 22, -22, 76, 2, 40, '#1f5a8a', pt({ r: 0.6 })), ...[[-24, -38], [44, -38], [-24, -6], [44, -6]].map(([x, z]) => box(x, 0, z, 2.6, 22, 2.6, '#2a2b30', mt({ r: 0.4 }))), box(10, 24, -22, 0.8, 6, 42, '#f4f4f0', { op: 0.75, mat: 'fab' })];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      f += `<g transform="${planeH(p, 24.05)}"><rect x="-27.6" y="-41.6" width="75.2" height="39.2" fill="none" stroke="#ffffff" stroke-width="0.7"/><path d="M-27.6 -22H47.6" stroke="#ffffff" stroke-width="0.4"/></g>`;
      f += [[-70, 40, '#c81e2a'], [-64, 50, '#c81e2a'], [-6, 42, '#2f6a3a'], [4, 52, '#2f6a3a']].map(([x, z, c2]) => at(p, k, x, 4.6, z, 1, BALL(3.2, c2))).join('') + at(p, k, -20, 2.4, 46, 1, BALL(1.4, '#fbfbf6'));
      if (pl) { f += ballFly(p, k, [[-20, 25, -26], [-2, 32, -24], [10, 30, -22], [24, 25, -20], [38, 31, -18], [44, 26, -18], [30, 31, -20], [10, 30, -22], [-6, 25, -24], [-20, 25, -26]], 1.6, BALL(1, '#ffffff'));
        f += ballFly(p, k, [[-80, 4.6, 45], [-50, 4.6, 46], [-24, 4.6, 46], [-22, 4.6, 46], [-22, 4.6, 46], [-80, 4.6, 45]], 6, BALL(3.2, '#c81e2a')); }
      return { defs: '', front: f, bb: bbOf([p(-88, 0, 64), p(28, 0, 64), p(-88, 0, 26), p(48, 0, -40), p(-26, 34, -40), p(48, 34, -4)], 3) }; };
    return D; };
  PL9.bocce8 = () => [{ x: -38, z: -22, v: 'right', a: 'gswing' }, { x: 58, z: -22, v: 'left', a: 'gswing', d: 0.5 }];

  // ---------- Tetherball Pole (2 players) ----------
  N.tether8 = S => { const pl = isPlay(S), TOP = 78;
    const D = { w: 90, d: 90, round: 1 };
    D.build = P => [cyl(0, 0, 0, 10, 4, '#a9a8a2', pt({ n: 18 })), cyl(0, 4, 0, 1.6, TOP - 4, '#e8e4dc', mt({ n: 10, shine: 1 })), cyl(0, TOP, 0, 2.2, 1.4, '#e8343c', mt({ n: 10 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      f += `<g transform="${planeH(p, 0.3)}"><circle r="36" fill="none" stroke="#f4f4f0" stroke-width="1" stroke-dasharray="3 2"/><path d="M-36 0H36" stroke="#f4f4f0" stroke-width="0.8" stroke-dasharray="3 2"/></g>`;
      const tp = p(0, TOP - 2, 0);
      if (pl) { const pts = rep(25, i => { const a = i / 24 * 2 * PI; return p(Math.cos(a) * 26, 46 + Math.sin(a * 2) * 3, Math.sin(a) * 26); }), pth = 'M' + pts.map(P2).join('L') + 'Z';
        // ball orbits, the rope follows from the top of the pole
        f += `<path d="M${P2(tp)}L${P2(pts[0])}" stroke="#f4efe6" stroke-width="${f1(0.6 * k)}"><animate attributeName="d" values="${pts.map(q => `M${P2(tp)}L${P2(q)}`).join(';')}" dur="2.4s" repeatCount="indefinite"/></path>` + `<g>${amo(pth, 2.4, 0)}<g transform="scale(${n4(k)})">${BALL(4.4, '#f2d23a')}<path d="M-3 -1Q0 -3 3 -1" stroke="#c8a81a" stroke-width="0.5" fill="none"/></g></g>`; }
      else { const b = p(4, 30, 4); f += `<path d="M${P2(tp)}Q${P2(p(2, 50, 2))} ${P2(b)}" stroke="#f4efe6" stroke-width="${f1(0.6 * k)}" fill="none"/>` + at(p, k, 4, 30, 4, 1, BALL(4.4, '#f2d23a')); }
      return { defs: '', front: f, bb: bbOf([p(-38, 0, -38), p(38, 0, 38), p(-38, 0, 38), p(38, 0, -38), p(0, TOP + 4, 0), p(-30, 52, 0), p(30, 52, 0)], 3) }; };
    return D; };
  PL9.tether8 = () => [{ x: -24, z: 18, v: 'right', a: 'gteth' }, { x: 26, z: -16, v: 'left', a: 'gteth', d: 0.5 }];

  // ---------- Luxury Mini-Mansion Pet Villa with Splash Pad (up to 3) ----------
  N.villa8 = S => { const pl = isPlay(S), WT = '#f6f2ea', RF = '#2f5a8a';
    const D = { w: 160, d: 110 };
    D.build = P => [box(-34, 0, -20, 60, 40, 36, WT, pt({ r: 1 })), box(-34, 40, -20, 64, 3, 40, '#e8e2d4', pt({ r: 0.6 })), prism(-68, 0, [[-42, 43], [2, 43], [-20, 62]], RF, pt({})), box(-34, 0, -1.4, 18, 26, 2, '#e8e2d4', pt({ r: 0.6 })),
      ...[-58, -46, -22, -10].map(x => cyl(x, 0, 0, 1.8, 40, WT, pt({ n: 10 }))), box(-34, 40, 2, 30, 1.6, 8, '#e8e2d4', pt({ r: 0.4 })), box(-34, 0, 2, 70, 1.6, 10, '#d8cfbe', cer({ r: 0.4 })), box(36, 0, 16, 80, 1, 70, '#7ac8e8', cer({ r: 3, shine: 1 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      f += `<g transform="${plane(p, -1.75, 26, -43)}"><rect x="3" y="4" width="12" height="22" rx="6" fill="#1d2a3a"/><rect x="3" y="4" width="12" height="22" rx="6" fill="none" stroke="${GOLD}" stroke-width="0.8"/><circle cx="9" cy="13" r="1.4" fill="#ffe8a0"/></g>`;
      [[-62, 30], [-14, 30], [-62, 12], [-14, 12]].forEach(([x, y]) => f += `<g transform="${plane(p, -1.95, y, x)}"><rect x="0" y="0" width="8" height="9" rx="4" fill="#9ad8f2"/><path d="M4 0V9M0 4.5H8" stroke="${WT}" stroke-width="0.8"/><rect x="-0.6" y="9" width="9.2" height="1.4" fill="#e8e2d4"/></g>`);
      f += `<g transform="${plane(p, 2.05, 56, -34)}"><circle r="3" fill="${GOLD}"/><path d="M-1.6 0.4Q0 2 1.6 0.4" stroke="#ffffff" stroke-width="0.5" fill="none"/></g>`;
      // splash pad: wet sheen, jets rising and falling, ripples
      const Wp = water(p, { sh: { cx: 36, cz: 16, hx: 39, hz: 34, r: 3 }, y: 1.1, pal: ['#4fb8e0', '#7ad8f2', '#c8f4ff', '#ffffff'], caust: 0.5, gl: 8, rip: [[20, 0, 6, 1.4, 0], [52, 0, 6, 1.6, -0.5], [20, 30, 6, 1.5, -1], [52, 30, 6, 1.3, -0.3], [36, 16, 8, 1.8, -0.8]] }); f += Wp.svg;
      [[20, 0], [52, 0], [20, 30], [52, 30], [36, 16]].forEach(([x, z], i) => { const h = (i === 4 ? 30 : 18) * (pl ? 1 : 0.55); rep(4, j => { const a = j / 4 * 2 * PI + i; f += stream(p, k, [x, 1.2, z], [x + Math.cos(a) * 3, h + 6, z + Math.sin(a) * 3], [x + Math.cos(a) * 8, 1.2, z + Math.sin(a) * 8], 0.8, 0.7, -j * 0.17 - i * 0.1); }); f += `<circle cx="${f1(p(x, 1.2, z)[0])}" cy="${f1(p(x, 1.2, z)[1])}" r="${f1(1.2 * k)}" fill="#c9d0d6"/>`; });
      return { defs: WDEF + Wp.defs, front: f, bb: bbOf([p(-70, 0, -40), p(78, 0, 52), p(-70, 0, 52), p(78, 0, -20), p(-20, 66, -20), p(36, 36, 16)], 3) }; };
    return D; };
  PL9.villa8 = () => [{ x: 30, y: 1, z: 10, v: 'front', a: 'gsplash' }, { x: 48, y: 1, z: 26, v: 'front', a: 'gsplash', d: 0.4 }, { x: -34, y: 0, z: 10, v: 'front', a: 'grest' }];

  // ---------- Cornhole Boards & Beanbags (2 players) ----------
  N.cornhole8 = S => { const pl = isPlay(S);
    const D = { w: 170, d: 60 };
    const board = (o, x, dir) => { o.push(prism(x - 12 * dir, x + 12 * dir, [[-11, 0], [11, 0], [11, 1.6], [-11, 1.6]].map(q => q), '#e8dcc0', wd({})));
      o.push(solid({ ax: 'z', sh: 'poly', c: [0, 0], pts: [[x - 24 * dir, 2], [x + 24 * dir, 12], [x + 24 * dir, 14], [x - 24 * dir, 4]].map(q => q), rings: [[-12, 0], [12, 0]], col: dir > 0 ? '#2f6fb0' : '#c81e2a', mat: 'paint' })); };
    D.build = P => { const o = []; [[-56, 1], [56, -1]].forEach(([x, d]) => { o.push(solid({ ax: 'z', sh: 'poly', c: [0, 0], pts: d > 0 ? [[x - 24, 0], [x + 24, 10], [x + 24, 12.4], [x - 24, 2.4]] : [[x - 24, 10], [x + 24, 0], [x + 24, 2.4], [x - 24, 12.4]], rings: [[-12, 0], [12, 0]], col: d > 0 ? '#2f6fb0' : '#c81e2a', mat: 'paint' }), box(x + d * 22, 0, -10, 2, 10, 2, '#a8875a', wd({ r: 0.3 })), box(x + d * 22, 0, 10, 2, 10, 2, '#a8875a', wd({ r: 0.3 }))); }); void board; return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      [[-56, 1], [56, -1]].forEach(([x, d]) => { const hx = x + d * 12, y = d > 0 ? 2.4 + (36 / 48) * 10 + 0.1 : 2.4 + (12 / 48) * 10 + 0.1; void y; const yy = (xx) => d > 0 ? 2.4 + (xx - (x - 24)) / 48 * 10 : 2.4 + ((x + 24) - xx) / 48 * 10;
        const h = p(hx, yy(hx) + 0.05, 0); f += `<ellipse cx="${f1(h[0])}" cy="${f1(h[1])}" rx="${f1(3.4 * k)}" ry="${f1(2.6 * k)}" fill="#1d1e22"/><path d="M${P2(p(x - 24, yy(x - 24) + 0.05, -9))}L${P2(p(x + 24, yy(x + 24) + 0.05, -9))}M${P2(p(x - 24, yy(x - 24) + 0.05, 9))}L${P2(p(x + 24, yy(x + 24) + 0.05, 9))}" stroke="#ffffff" stroke-width="${f1(0.7 * k)}" opacity="0.8"/>`;
        [[x - d * 6, 3], [x + d * 4, -4]].forEach(([bx, bz], j) => f += `<g transform="translate(${P2(p(bx, yy(bx) + 0.6, bz))}) scale(${n4(k)})"><rect x="-2.4" y="-1.2" width="4.8" height="2.4" rx="0.9" fill="${(j + (d > 0 ? 0 : 1)) % 2 ? '#c81e2a' : '#2f6fb0'}"/></g>`); });
      if (pl) [[[-34, 18, 0], [40, 3, 0]], [[34, 18, 0], [-44, 3, 2]]].forEach(([a, b], i) => f += ballFly(p, k, arc3(a, b, 26, 12).concat([b, b, b]), 2.6, `<rect x="-2.4" y="-1.2" width="4.8" height="2.4" rx="0.9" fill="${i ? '#2f6fb0' : '#c81e2a'}"/>`, 1, -i * 1.3));
      return { defs: '', front: f, bb: bbOf([p(-84, 0, -14), p(84, 0, 14), p(-84, 0, 14), p(84, 0, -14), p(0, 40, 0)], 3) }; };
    return D; };
  PL9.cornhole8 = () => [{ x: -36, z: 18, v: 'right', a: 'gtoss' }, { x: 36, z: -18, v: 'left', a: 'gtoss', d: 0.5 }];

  // ---------- Chalk Hopscotch Court (3 players) ----------
  N.hop8 = S => { const pl = isPlay(S);
    const D = { w: 150, d: 70 };
    D.build = P => [box(0, 0, 0, 148, 0.8, 66, '#a9a8a2', pt({ r: 1 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      const SQ = [[-50, 0, 1], [-34, 0, 2], [-18, -8, 3], [-18, 8, 4], [-2, 0, 5], [14, -8, 6], [14, 8, 7], [30, 0, 8], [46, -8, 9], [46, 8, 10]], CC = ['#ff6a8a', '#ffd23a', '#6ad8ff', '#9af06a', '#c89aff'];
      let g = `<rect x="-74" y="-33" width="148" height="66" fill="url(#hp8)" opacity="0.5"/>`;
      SQ.forEach(([x, z, n], i) => { const w = 15, h = SQ.filter(q => q[0] === x).length > 1 ? 15 : 15; g += `<rect x="${x - w / 2}" y="${z - h / 2}" width="${w}" height="${h}" fill="${CC[i % 5]}" opacity="0.18"/><rect x="${x - w / 2}" y="${z - h / 2}" width="${w}" height="${h}" fill="none" stroke="#fbfbf6" stroke-width="1.1" stroke-dasharray="6 0.6 3 0.4" opacity="0.92"/><text x="${x}" y="${z + 2.4}" text-anchor="middle" font-family="Comic Sans MS, Marker Felt, cursive" font-size="7" font-weight="700" fill="${CC[i % 5]}" opacity="0.95">${n}</text>`; });
      g += `<path d="M58 -8A10 10 0 0 1 58 8" fill="none" stroke="#fbfbf6" stroke-width="1.1"/><text x="64" y="2.4" text-anchor="middle" font-family="Comic Sans MS, Marker Felt, cursive" font-size="5" fill="#ffd23a">HOME</text>`;
      f += `<g transform="${planeH(p, 0.85)}">${g}</g>`;
      // chalk sticks + the lagging stone (tossed to a square each round)
      f += at(p, k, -66, 0.9, 26, 1, '<rect x="-3" y="-0.8" width="6" height="1.6" rx="0.8" fill="#ff6a8a"/><rect x="1" y="1" width="5" height="1.4" rx="0.7" fill="#6ad8ff"/>');
      if (pl) f += ballFly(p, k, arc3([-64, 1.4, 20], [-18, 1.4, 8], 14, 10).concat([[-18, 1.4, 8], [-18, 1.4, 8], [-18, 1.4, 8], [-18, 1.4, 8], [-64, 1.4, 20]]), 6, '<ellipse rx="1.8" ry="1" fill="#6a6a64"/><ellipse cx="-0.4" cy="-0.3" rx="0.7" ry="0.35" fill="#9a9a94"/>');
      else f += at(p, k, -18, 1.4, 8, 1, '<ellipse rx="1.8" ry="1" fill="#6a6a64"/>');
      return { defs: `<pattern id="hp8" width="5" height="5" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="0.4" fill="#8a8984"/><circle cx="3.4" cy="3" r="0.3" fill="#c8c7c0"/></pattern>`, front: f, bb: bbOf([p(-76, 0, -35), p(76, 0, 35), p(-76, 0, 35), p(76, 0, -35)], 3) }; };
    return D; };
  PL9.hop8 = () => [{ x: -52, z: 2, v: 'right', a: 'ghop' }, { x: -66, z: 24, v: 'front', a: 'grest', d: 0.3 }, { x: -64, z: -22, v: 'front', a: 'gjump', d: 0.6 }];

  // ---------- Horseshoe Pits (2 players) ----------
  N.shoe8 = S => { const pl = isPlay(S);
    const D = { w: 170, d: 50 };
    D.build = P => [...[-60, 60].map(x => box(x, 0, 0, 30, 2.4, 22, '#c8a878', pt({ r: 0.8 }))), ...[-60, 60].map(x => box(x, 0, 0, 34, 3, 2, '#8a5a34', wd({ r: 0.4 }))), ...[-60, 60].map(x => cyl(x, 2.4, 0, 0.7, 12, '#5a5e66', mt({ n: 8, shine: 1 })))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      const SHOE = '<path d="M-2.6 1.6V-0.6A2.6 2.6 0 0 1 2.6 -0.6V1.6" fill="none" stroke="#3a3c42" stroke-width="1.3" stroke-linecap="round"/><path d="M-2.6 1.6V-0.6A2.6 2.6 0 0 1 2.6 -0.6V1.6" fill="none" stroke="#9aa1ad" stroke-width="0.4"/>';
      [[-60, 6, 4], [-54, -5, 40], [62, 3, 120], [56, -6, 200]].forEach(([x, z, r]) => f += `<g transform="translate(${P2(p(x, 2.6, z))}) scale(${n4(k * 1.3)}) rotate(${r}) scale(1 0.55)">${SHOE}</g>`);
      if (pl) [[[-48, 18, 4], [60, 6, 0]], [[48, 18, -4], [-60, 6, 0]]].forEach(([a, b], i) => { f += ballFly(p, k * 1.3, arc3(a, b, 34, 14).concat([b, b, b, b]), 3, `<g>${atV('rotate', ['0', '360'], 0.6)}${SHOE}</g>`, 1, -i * 1.5); f += `<circle cx="${f1(p(...b)[0])}" cy="${f1(p(...b)[1])}" r="${f1(2 * k)}" fill="#ffe8a0" opacity="0"><animate attributeName="opacity" values="0;0;0;1;0;0" keyTimes="0;0.6;0.62;0.66;0.75;1" dur="3s"${B(-i * 1.5)} repeatCount="indefinite"/></circle>`; });
      return { defs: '', front: f, bb: bbOf([p(-80, 0, -14), p(80, 0, 14), p(-80, 0, 14), p(80, 0, -14), p(0, 44, 0)], 3) }; };
    return D; };
  PL9.shoe8 = () => [{ x: -38, z: 18, v: 'right', a: 'gtoss' }, { x: 38, z: -18, v: 'left', a: 'gtoss', d: 0.5 }];

  // ---------- Pop-up Pet Tunnel & Tennis Ball (2 players) ----------
  N.tunnel8 = S => { const pl = isPlay(S), L0 = 90, R0 = 13;
    const D = { w: 120, d: 50 };
    D.build = P => [solid({ ax: 'x', sh: 'el', c: [0, R0], a: R0, b: R0, n: 22, rings: rep(9, i => [-L0 / 2 + i * L0 / 8, 0, i % 2 ? 0.94 : 1]), col: '#3f8ad8', mat: 'fab', soft: 1 })];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      rep(9, i => { const x = -L0 / 2 + i * L0 / 8, pts = rep(13, j => { const a = -PI * 0.15 + j / 12 * PI * 1.1; return p(x, R0 + Math.sin(a + PI / 2) * R0 * (i % 2 ? 0.94 : 1) * 0 + R0 * Math.cos(a) * 0 + R0 * Math.sin(-a + PI) * 0 + (R0 * (i % 2 ? 0.94 : 1)) * Math.cos(a - PI / 2) * 0 + R0 * Math.sin(a) * (i % 2 ? 0.94 : 1), R0 * Math.cos(a) * (i % 2 ? 0.94 : 1)); }); if (!(i % 2)) f += `<path d="M${pts.map(P2).join('L')}" fill="none" stroke="#1f4a8a" stroke-width="${f1(0.9 * k)}" opacity="0.7"/>`; });
      f += `<g transform="${planeX(p, L0 / 2 + 0.05, R0, 0)}"><ellipse rx="${R0}" ry="${R0}" fill="#1a2a4a"/><ellipse rx="${R0 * 0.8}" ry="${R0 * 0.8}" fill="#0e1830"/><ellipse rx="${R0}" ry="${R0}" fill="none" stroke="#f2c14a" stroke-width="1.6"/></g>`;
      rep(3, i => { const x = -L0 / 2 + 12 + i * 32; f += `<g transform="translate(${P2(p(x, R0 * 1.6, R0 * 0.8))}) scale(${n4(k)})"><circle r="2" fill="#f2c14a" opacity="0.9"/><circle r="1" fill="#ffffff"/></g>`; });
      if (pl) f += ballFly(p, k, [[L0 / 2 + 20, 2, 10], [L0 / 2 + 4, 2, 4], [L0 / 2 - 4, 2, 0], [L0 / 2 + 20, 2, 10]], 3.4, BALL(2.2, 'tennis'));
      else f += at(p, k, L0 / 2 + 14, 2.2, 10, 1, BALL(2.2, 'tennis'));
      return { defs: '', front: f, bb: bbOf([p(-L0 / 2 - 4, 0, -R0), p(L0 / 2 + 24, 0, R0 + 10), p(-L0 / 2, 2 * R0 + 4, 0), p(L0 / 2, 2 * R0 + 4, 0)], 3) }; };
    return D; };
  PL9.tunnel8 = () => [{ x: 54, z: 14, v: 'left', a: 'gcrawl' }, { x: -56, z: 10, v: 'right', a: 'gcrawl', d: 0.5 }];

  // ---------- Wooden A-Frame Pet House & Frisbee Turf (1 player) ----------
  N.aframe8 = S => { const pl = isPlay(S), WD = '#c08a52';
    const D = { w: 140, d: 90 };
    D.build = P => [box(-26, 0, 0, 44, 1.4, 44, '#a8683a', wd({ r: 0.4 })), prismZ(-18, 18, [[-44, 1.4], [-8, 1.4], [-26, 33]], WD, wd({})), prismZ(-20, 20, [[-46.4, 0.6], [-43, 0.6], [-24.4, 35], [-27.6, 35]], '#7a4a2a', wd({})), prismZ(-20, 20, [[-9, 0.6], [-5.6, 0.6], [-24.4, 35], [-27.6, 35]], '#7a4a2a', wd({}))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      const un = turf(p, 26, 6, 40, 40, '#5aa844', '#6fbf54');
      f += `<g transform="${plane(p, 18.05, 33, -44)}"><path d="M9 31.6V20A9 9 0 0 1 27 20V31.6Z" fill="#2a1a10"/><path d="M9 31.6V20A9 9 0 0 1 27 20V31.6" fill="none" stroke="#7a4a2a" stroke-width="0.8"/><rect x="11" y="9" width="14" height="5" rx="1" fill="#f4efe6" stroke="#7a4a2a" stroke-width="0.4"/><text x="18" y="12.9" text-anchor="middle" font-family="Georgia, serif" font-size="3.4" font-weight="700" fill="#7a4a2a">SQUISH</text>${rep(5, i => `<path d="M${5 + i * 6.5} ${31 - i * 0} L18 ${0.6}" stroke="#8a5a30" stroke-width="0.3" opacity="0.45"/>`).join('')}</g>`;
      const FR = '<ellipse rx="4" ry="1.6" fill="#ff4fb8"/><ellipse rx="2.6" ry="0.9" fill="#ff8ad0"/>';
      if (pl) f += ballFly(p, k, arc3([0, 6, 10], [56, 6, 0], 16, 12).concat(arc3([56, 6, 0], [0, 6, 10], 10, 10).slice(1)), 4, `<g>${atV('scale', ['1 1', '1 0.7', '1 1'], 0.3)}${FR}</g>`);
      else f += at(p, k, 30, 0.6, 14, 1, FR);
      return { defs: '', under: un, front: f, bb: bbOf([p(-50, 0, -22), p(66, 0, 46), p(-50, 0, 22), p(66, 0, -34), p(-26, 36, 0), p(30, 26, 0)], 3) }; };
    return D; };
  PL9.aframe8 = () => [{ x: 50, z: 6, v: 'left', a: 'gfetch' }];

  // ---------- draw hook: game players ----------
  const draw8 = RD.draw;
  RD.draw = (r, o) => { const res = draw8(r, o); if (!res || res._p9) return res; res._p9 = 1;
    try { const sp0 = r.spec ? r.spec.split(/[.@*+]/)[0] : ''; if (PL9[sp0] && res.bb) { const p = RD.projOf(1); res.players = PL9[sp0](o && o.st).map(q => { const s = p(q.x, q.y || 0, q.z); return { x: s[0], y: s[1], v: q.v, a: q.a, b: !!q.b, d: q.d || 0 }; }); } } catch (e) { console.warn('reno plus9', r.id, e); }
    return res; };

  // ---------- catalog edits ----------
  const GAME = (spec, need, loop, live, note, extra) => Object.assign({ spec, play: 'game', need, loop, live, note }, extra || {});
  RD.SET9 = {
    'YRD-039': { spec: 'stump8', note: 'A rough-cut stump with flared roots, deep bark ridges and a sanded top that shows its growth rings. Set with a plate of cookies and a glass of lemonade.' },
    'YRD-056': { spec: 'mosaic8', note: 'A round bistro table with a hand-laid mosaic top (cobalt, terracotta, saffron and white tesserae in rings) on a scrolled wrought-iron base. Set with a cheese board, croissants and iced tea.' },
    'YRD-053': { spec: 'limeBench', note: 'A curved English limestone bench on three carved pedestals, with lichen spots and scroll detail. A picnic basket and a tea tray sit on it. Seats 3.' },
    'YRD-036': { spec: 'picnic8', note: 'A redwood A-frame picnic table with attached benches, set with a red gingham runner, watermelon slices, a burger platter, corn, a lemonade pitcher, glasses and ketchup. Seats 4.' },
    'YRD-076': { spec: 'teak8', note: 'A 10-foot reclaimed teak harvest table on chunky trestle legs, with a linen runner and a full feast: two roast chickens, salad, a bread loaf, a fruit bowl, cheese board, wine and candles.' },
    'YRD-096': { spec: 'onyx8', live: 'Glowing · water flowing', note: 'A backlit honey-onyx banquet slab on bronze plinths. A water channel runs down the middle and spills off the end into a small basin. Set with sushi platters, fruit, cheese, champagne flutes and candles.' },
    'YRD-088': { spec: 'globe8', live: 'Hologram spinning', note: 'A chrome pedestal projecting a spinning holographic star-map globe (meridians turning, twinkling stars, constellation line, scan line) next to a floating crystal carafe and glass that bob in the air.' },
    'YRD-099': { spec: 'pedestal8', live: 'Floating', note: 'A solar-cell base that levitates a round drinks tray on a cyan magnetic field: pulsing field rings, a glow underneath, and two drinks riding the floating tray as it bobs.' },
    'YRD-028': { spec: 'tub8', live: 'Ice cold', note: 'A ribbed galvanized drinks tub packed with ice cubes, bottles and cans. Condensation drops slide down the outside and cold mist spills over the rim. A gingham napkin holder sits beside it.' },
    'YRD-024': { spec: 'chime8', live: 'Swaying · ringing', note: 'Six copper chime tubes on a shepherd hook, each swinging on its own string, with a clapper and wind sail that ring them (sound rings ripple out). Beside it a painted birdhouse on a post with a little bird peeking out.' },
    'YRD-019': { spec: 'bucket8', play: 'tip', live: 'Tap to tip', note: 'An orange 5-gallon bucket turned upside down as a stool. Tap it: it tips over and rolls onto its side, trapped water gushes out into a spreading puddle and a sponge rolls out. Tap again to stand it back up.' },
    'YRD-003': { spec: 'zapper8', live: 'Zapping', note: 'A UV bug-zapper bulb on a post: violet glow behind a steel cage, moths circling the light, and every few seconds a bright zap flash with sparks.' },
    'YRD-083': { spec: 'drones8', live: 'Swarm flying', note: 'A docking hub that sends out a swarm of tiny glowing micro-drones. They fly smooth figure-eight loops in three colour layers, lights pulsing like fireflies.' },
    'YRD-104': GAME('goal8', 3, 120, 'Needs 3 players', 'A regulation-style white goal with a full net, back stanchions and painted box lines on striped turf. Needs 3 players (a keeper and two strikers): they dribble, pass and shoot into the net in a 2-minute match that loops.'),
    'YRD-102': GAME('hoop8', 3, 120, 'Needs 3 players', 'A driveway hoop: steel pole, glass backboard with the red square, orange rim and white net over a concrete court with a key. Needs 3 players for a 2-minute pickup game that loops.'),
    'YRD-077': GAME('golf8', 2, 60, 'Needs 2 players', 'A three-hole putting green (fringe, cups, numbered flags) with an outdoor cinema screen on a black frame playing a cartoon. Needs 2 players: they putt while the movie plays, looping every minute.'),
    'YRD-105': GAME('dome8', 4, 60, 'Needs 4 players', 'A sturdy geodesic climbing dome in four colours on a rubber mulch pad. Fits 4 players who climb and play on it in a 1-minute loop.'),
    'YRD-094': GAME('bounce8', 1, 60, '1 player', 'A glass anti-gravity dome with a glowing ring base and floating orbs inside, plus an automated fetch launcher that lobs a glowing ball. 1 player bounces and fetches in a 1-minute loop.'),
    'YRD-054': GAME('agility8', 2, 60, 'Needs 2 players', 'An agility course: a tire jump in a blue frame, a red seesaw on a yellow fulcrum that rocks without stopping, and weave poles on turf. Needs 2 players.'),
    'YRD-057': GAME('bocce8', 2, 120, 'Needs 2 players', 'A cedar-framed bocce court with red and green balls and a pallino, next to a blue ping-pong table with net. Needs 2 players for a 2-minute rally + bocce match that loops.'),
    'YRD-103': GAME('tether8', 2, 120, 'Needs 2 players', 'A tetherball pole in a concrete base with a chalk circle. Needs 2 players: the yellow ball whips round the pole on its rope as they strike it, round after round.'),
    'YRD-074': GAME('villa8', 1, 120, 'Up to 3 players', 'A white mini-mansion for pets: columns, a blue roof with a gold crest, arched door, windows and a balcony, beside a splash pad of rising water jets and ripples. Fits up to 3 for a 2-minute splash-and-play loop.', { max: 3 }),
    'YRD-037': GAME('cornhole8', 2, 120, 'Needs 2 players', 'Two angled cornhole boards (blue and red) with holes and edge lines, and beanbags. Needs 2 players: beanbags arc across and land on the boards in a 2-minute match that loops.'),
    'YRD-101': GAME('hop8', 3, 120, 'Needs 3 players', 'A clean chalk hopscotch court on concrete: numbered squares 1 to 10 in bright chalk colours and a HOME arc. Needs 3 players: one hops, one tosses the stone, one waits, in a 2-minute loop.'),
    'YRD-017': GAME('shoe8', 2, 120, 'Needs 2 players', 'Two horseshoe pits with sand boxes, wooden backstops and steel stakes. Needs 2 players: horseshoes spin through the air and ring the stakes in a 2-minute match that loops.', { name: 'Horseshoe Pits with Steel Stakes' }),
    'YRD-014': GAME('tunnel8', 2, 60, 'Needs 2 players', 'A blue pop-up pet tunnel with wire rings and a tennis ball. Needs 2 players who crawl through after the ball in a 1-minute loop.', { name: 'Pop-Up Pet Tunnel & Tennis Ball' }),
    'YRD-034': GAME('aframe8', 1, 60, '1 player', 'A cedar A-frame pet house with an arched door and name plate, on a frisbee turf patch. 1 player catches the frisbee and rests in a 1-minute loop.'),
  };
  const edit8 = RD.edit;
  RD.edit = rows => edit8(rows).map(r => RD.SET9[r.id] ? Object.assign({}, r, RD.SET9[r.id]) : r);
  RD.PLUS9 = 1;
})();
