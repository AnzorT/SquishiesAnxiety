// Yard Mini Games: CORNHOLE (the backyard's Cornhole Boards & Beanbags). 8 bean bags. Pull back (like a slingshot) and let go to toss:
// pull further = farther, pull sideways to aim (you throw the other way). Mind the wind flag. A bag on the board = 1, in the hole = 3
// (bags slide on the board and can knock others in, or off). Final tally counts where the bags end up.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add || !YG.cam) return setTimeout(go, 30); const { S, D, cl, lerp, r2, track, SFX } = YG;
  const ICON = '<svg viewBox="0 0 120 84" aria-hidden="true"><rect width="120" height="84" fill="#cfeaff"/><rect y="34" width="120" height="50" fill="#9fdc6e"/>' +
    '<path d="M38 72L50 30H70L82 72Z" fill="#3b7fe0"/><path d="M38 72H82V77H38Z" fill="#2a5fb0"/><path d="M44 52H76" stroke="#fff" stroke-width="3" opacity="0.8"/><ellipse cx="60" cy="38" rx="6" ry="2.6" fill="#1b2a44"/>' +
    '<rect x="51" y="58" width="12" height="9" rx="3" fill="#e8483c" transform="rotate(-8 57 62)"/><rect x="88" y="16" width="12" height="9" rx="3" fill="#e8483c" transform="rotate(20 94 20)"/><path d="M92 28Q80 30 72 40" stroke="#fff" stroke-width="1.6" stroke-dasharray="2 3" fill="none"/></svg>';
  YG.add({ id: 'corn', name: 'Cornhole', item: 'Cornhole Boards', color: '#4f8fff', icon: ICON, stars: [8, 13, 18], coinK: 2,
    hint: 'Pull back and let go to toss · mind the wind',
    how: ['Pull back from anywhere and let go to toss your bean bag.', 'Pull further to throw farther; pull to one side to aim the other way.', '8 bags. On the board = 1, in the hole = 3. Watch the wind flag!'],
    make(ctx) {
      const { bg, fg, W, H } = ctx, P = YG.cam(2.4, 1.45, 210, 269), G = 9.8, BW = 0.86, ZF = 3.0, ZB = 4.6, YF = 0.08, YB = 0.34, HZ = 4.3, HR = 0.115, BS = 0.075;
      YG.yard(bg, { hz: 210 });
      const yb = (x, z) => Math.abs(x) <= BW / 2 && z >= ZF && z <= ZB ? lerp(YF, YB, (z - ZF) / (ZB - ZF)) : null, quad = (pts, a, p) => S('path', Object.assign({ d: 'M' + pts.map(q => { const s = P(q[0], q[1], q[2]); return r2(s[0]) + ' ' + r2(s[1]); }).join('L') + 'Z' }, a), p || bg);
      // the board
      const boardG = S('g', {}, bg); { const g0 = P(0, 0, (ZF + ZB) / 2); YG.shadow(boardG, g0[0], g0[1] + 6, 0.62 * g0[2], 0.2);
        [[-BW / 2 + 0.06], [BW / 2 - 0.06]].forEach(([x]) => quad([[x - 0.025, 0, ZB - 0.05], [x + 0.025, 0, ZB - 0.05], [x + 0.025, YB, ZB - 0.05], [x - 0.025, YB, ZB - 0.05]], { fill: '#1d4fa0' }, boardG));
        quad([[-BW / 2, YF - 0.06, ZF], [BW / 2, YF - 0.06, ZF], [BW / 2, YF, ZF], [-BW / 2, YF, ZF]], { fill: '#2a5fb0' }, boardG);
        quad([[-BW / 2, YF, ZF], [BW / 2, YF, ZF], [BW / 2, YB, ZB], [-BW / 2, YB, ZB]], { fill: '#3b7fe0' }, boardG);
        quad([[-BW / 2 + 0.04, YF + 0.003, ZF + 0.04], [BW / 2 - 0.04, YF + 0.003, ZF + 0.04], [BW / 2 - 0.04, YB + 0.003, ZB - 0.04], [-BW / 2 + 0.04, YB + 0.003, ZB - 0.04]], { fill: 'none', stroke: '#ffffff', 'stroke-width': 1.6, opacity: 0.55 }, boardG);
        const zm = ZF + 0.55; quad([[-BW / 2, lerp(YF, YB, (zm - ZF) / 1.6), zm], [BW / 2, lerp(YF, YB, (zm - ZF) / 1.6), zm], [BW / 2, lerp(YF, YB, (zm + 0.08 - ZF) / 1.6), zm + 0.08], [-BW / 2, lerp(YF, YB, (zm + 0.08 - ZF) / 1.6), zm + 0.08]], { fill: '#ffffff', opacity: 0.8 }, boardG);
        let d = ''; for (let i = 0; i <= 24; i++) { const a = i / 24 * Math.PI * 2, x = Math.cos(a) * HR, z = HZ + Math.sin(a) * HR, s = P(x, lerp(YF, YB, (z - ZF) / 1.6) + 0.002, z); d += (i ? 'L' : 'M') + r2(s[0]) + ' ' + r2(s[1]); }
        S('path', { d: d + 'Z', fill: '#14213a', stroke: '#2a5fb0', 'stroke-width': 1.5 }, boardG); }
            const restG = S('g', {}, bg), shG = S('g', {}, bg), flyG = S('g', {}, fg), guideG = S('g', {}, fg);
      // wind flag (pole by the board)
      const flag = S('g', {}, bg), fp = P(BW / 2 + 0.45, 0, ZB - 0.1), fp2 = P(BW / 2 + 0.45, 1.25, ZB - 0.1); S('path', { d: 'M' + r2(fp[0]) + ' ' + r2(fp[1]) + 'L' + r2(fp2[0]) + ' ' + r2(fp2[1]), stroke: '#ffffff', 'stroke-width': 2.4 }, flag);
      const cloth = S('path', { fill: '#ffcf3a', stroke: '#e09a14', 'stroke-width': 1 }, flag); const windTx = D('div', { cls: 'yg-pill', style: 'position:absolute;right:3%;top:12.5%;font-size:13px;padding:5px 9px;' }, ctx.crl.parentNode.querySelector('.yg-hud'));
      const me = ctx.creature(ctx.playerKey, { yaw: 198 }), mz = 0.42, mx = -0.42, mp = P(mx, 0, mz); me.set(mp[0], mp[1], 0.78 * mp[2]); YG.shadow(shG, mp[0], mp[1] - 2, 0.3 * mp[2], 0.2);
      const REL = [mx + 0.2, 0.72, mz + 0.18];
      let bags = [], left = 8, cur = null, drag = null, wind = 0, tNow = 0, throwT = -9, settleT = 0, phase = 'aim', inHole = 0;
      function mkBag() { const g = S('g', {}, flyG), sh = S('ellipse', { fill: '#3a2a55', opacity: 0.18 }, shG), b = S('path', { fill: '#e8483c', stroke: '#b5322a', 'stroke-width': 1 }, g), st = S('path', { fill: 'none', stroke: '#ffd2cc', 'stroke-width': 0.9, 'stroke-dasharray': '1.6 1.6' }, g);
        return { g, sh, b, st, x: REL[0], y: REL[1], z: REL[2], vx: 0, vy: 0, vz: 0, rot: 0, vr: 0, st8: 'hand', sp: 0, dir: [0, 1] }; }
      function newWind() { wind = Math.round((Math.random() - 0.5) * 2 * 6) / 10; windTx.textContent = wind === 0 ? 'No wind' : 'Wind ' + (wind < 0 ? '← ' : '→ ') + Math.abs(wind).toFixed(1); }
      function toss(px, py) { if (!cur || phase !== 'aim') return; const len = Math.hypot(px, py); if (py < 18 || len < 30) { cur.st8 = 'hand'; return; }
        const p = cl(len / 220, 0.05, 1.3), a = Math.atan2(-px, py), th = 38 * Math.PI / 180, v = 3.6 + p * 4.2, ph = Math.atan2(-REL[0], HZ - REL[2]) + a * 0.42;
        Object.assign(cur, { st8: 'fly', vx: Math.sin(ph) * v * Math.cos(th), vz: Math.cos(ph) * v * Math.cos(th), vy: v * Math.sin(th), vr: (Math.random() - 0.5) * 700 }); bags.push(cur); cur = null; left--; phase = 'fly'; throwT = tNow; SFX.whoosh(); ctx.timer('Bags ' + left); }
      function tally() { let s = 0; inHole = 0; bags.forEach(b => { if (b.st8 === 'hole') { s += 3; inHole++; } else if ((b.st8 === 'board' || b.st8 === 'slide') && yb(b.x, b.z) != null) s += 1; }); return s; }
      function settle() { const before = ctx.score, now = tally(); if (now !== before) ctx.setScore(now); }
      const api = {
        start() { bags.forEach(b => { b.g.remove(); b.sh.remove(); }); bags = []; left = 8; cur = mkBag(); phase = 'aim'; ctx.setScore(0); ctx.timer('Bags 8'); newWind(); },
        down(p) { if (phase === 'aim' && cur) drag = { x0: p.x, y0: p.y, x: p.x, y: p.y }; },
        move(p) { if (drag) { drag.x = p.x; drag.y = p.y; } },
        up(p) { if (!drag) return; const d = drag; drag = null; toss(p.x - d.x0, p.y - d.y0); },
        key(k, dn) { if (dn && (k === ' ' || k === 'ArrowUp')) { toss(0, 112); return true; } },
        _toss: (px, py) => toss(px, py), _state: () => ({ phase, left, score: tally(), wind, bags: bags.map(b => b.st8 + '@' + b.x.toFixed(2) + ',' + b.z.toFixed(2)) }), _wind: w => { wind = w; },
        celebrate(st) { me.yaw(0); me.play(st >= 2 ? 'happy' : 'idle'); },
        update(dt, t) { tNow = t;
          // physics
          for (const b of bags) { const n = 4; for (let i = 0; i < n; i++) { const h = dt / n;
              if (b.st8 === 'fly') { b.vy -= G * h; b.vx += wind * h; b.x += b.vx * h; b.y += b.vy * h; b.z += b.vz * h; b.rot += b.vr * h; const y0 = yb(b.x, b.z);
                if (y0 != null && b.y <= y0 + 0.02) { if (Math.hypot(b.x, b.z - HZ) < HR - 0.02) { b.st8 = 'hole'; b.ht = t; SFX.swish(); setTimeout(SFX.score, 60); const s = P(0, YB, HZ); ctx.toast('Airmail! +3', s[0], s[1] - 40, '#ffe36e'); ctx.burst(s[0], s[1], 'confetti', 14); }
                  else { b.st8 = 'slide'; b.y = y0 + 0.02; const hs = Math.hypot(b.vx, b.vz) * 0.5; b.sp = hs; b.dir = [b.vx / (Math.hypot(b.vx, b.vz) || 1), b.vz / (Math.hypot(b.vx, b.vz) || 1)]; b.vr *= 0.2; SFX.thud(); } }
                else if (b.y <= 0.03) { b.st8 = 'grass'; b.y = 0.03; SFX.thud(); } }
              else if (b.st8 === 'slide') { b.sp = Math.max(0, b.sp - 3.2 * h); b.x += b.dir[0] * b.sp * h; b.z += b.dir[1] * b.sp * h; b.rot += b.vr * h * 0.2; const y0 = yb(b.x, b.z);
                if (y0 == null) { b.st8 = 'fall'; b.vy = 0; b.vx = b.dir[0] * b.sp; b.vz = b.dir[1] * b.sp; } else { b.y = y0 + 0.02;
                  if (Math.hypot(b.x, b.z - HZ) < HR - 0.035) { b.st8 = 'hole'; b.ht = t; SFX.swish(); setTimeout(SFX.score, 60); const s = P(0, YB, HZ); ctx.toast('In the hole! +3', s[0], s[1] - 40, '#ffe36e'); ctx.burst(s[0], s[1], 'confetti', 12); }
                  // knock other bags
                  for (const o of bags) if (o !== b && (o.st8 === 'board' || o.st8 === 'slide') && Math.hypot(o.x - b.x, o.z - b.z) < BS * 2) { const nx = o.x - b.x, nz = o.z - b.z, nl = Math.hypot(nx, nz) || 1;
                    o.st8 = 'slide'; o.dir = [nx / nl, nz / nl]; o.sp = Math.max(o.sp || 0, b.sp * 0.75); b.sp *= 0.3; o.x = b.x + o.dir[0] * BS * 2.02; o.z = b.z + o.dir[1] * BS * 2.02; SFX.tap(); }
                  if (b.sp <= 0) b.st8 = 'board'; } }
              else if (b.st8 === 'fall') { b.vy -= G * h; b.x += b.vx * h; b.z += b.vz * h; b.y += b.vy * h; if (b.y <= 0.03) { b.y = 0.03; b.st8 = 'grass'; } } } }
          // a throw is done when nothing moves any more
          if (phase === 'fly' && !bags.some(b => b.st8 === 'fly' || b.st8 === 'slide' || b.st8 === 'fall') && t - throwT > 500) { settle(); phase = 'wait'; settleT = t;
            const last = bags[bags.length - 1]; if (last.st8 === 'board') ctx.toast('On the board +1', W / 2, 250, '#ffffff'); else if (last.st8 === 'grass') ctx.toast(last.z < ZF ? 'Short' : 'Missed', W / 2, 250, '#ffffff'); }
          if (phase === 'wait' && t - settleT > 650) { if (left > 0) { cur = mkBag(); phase = 'aim'; newWind(); } else { phase = 'done'; settle(); ctx.finish({ sub: inHole + ' in the hole · ' + bags.filter(b => b.st8 === 'board').length + ' on the board' }); } }
          // thrower: lean back while you pull, swing through on the throw
          const pull = drag ? cl(Math.hypot(drag.x - drag.x0, drag.y - drag.y0) / 200, 0, 1) : 0, ts = t - throwT;
          const E = ts < 600 ? track([[0, { armR: -40, lean: -4, sq: 0.04 }], [120, { armR: 165, lean: 6, sq: -0.06, lift: 2 }], [600, { armR: 20, lean: 0, sq: 0, lift: 0 }]], ts) : { armR: lerp(30, -60, pull), lean: -6 * pull, sq: 0.06 * pull, armL: 20 + 30 * pull };
          me.pose(E); me.yaw(198 + Math.sin(t / 1100) * 4);
          // flag
          { const k = wind, base = fp2, w = 22 * (k === 0 ? 0.25 : Math.min(1, Math.abs(k) / 0.6 + 0.3)), sg = k === 0 ? 1 : Math.sign(k), wv = Math.sin(t / 120) * 3; cloth.setAttribute('d', 'M' + r2(base[0]) + ' ' + r2(base[1]) + 'Q' + r2(base[0] + sg * w * 0.5) + ' ' + r2(base[1] + wv + (k === 0 ? 8 : 0)) + ' ' + r2(base[0] + sg * w) + ' ' + r2(base[1] + 5 + wv * 0.5 + (k === 0 ? 10 : 0)) + 'L' + r2(base[0]) + ' ' + r2(base[1] + 13) + 'Z'); }
          // bags: the one in hand rides with the swing; landed ones move to the board layer
          if (cur) { const k = drag ? cl(Math.hypot(drag.x - drag.x0, drag.y - drag.y0) / 200, 0, 1) : 0; cur.x = REL[0] - 0.08 * k; cur.y = REL[1] - 0.12 * k + Math.sin(t / 380) * 0.01; cur.z = REL[2] - 0.1 * k; }
          for (const b of [cur, ...bags]) { if (!b) continue; const onB = b.st8 === 'board' || b.st8 === 'slide' || b.st8 === 'grass' || b.st8 === 'hole';
            if (onB && b.g.parentNode !== restG) restG.appendChild(b.g); const s = P(b.x, b.y, b.z), sc = s[2] * BS;
            let o = 1, sq = onB ? 0.42 : 0.9; if (b.st8 === 'hole') { const u = cl((t - b.ht) / 260, 0, 1); o = 1 - u; sq = 0.42 * (1 - u * 0.5); }
            const rr = b.rot || 0, c = Math.cos(rr * Math.PI / 180), sn = Math.sin(rr * Math.PI / 180), pts = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => { const X = u * c - v * sn, Y = (u * sn + v * c) * sq; return [s[0] + X * sc, s[1] + Y * sc]; });
            const m = (a, bb) => [(a[0] + bb[0]) / 2, (a[1] + bb[1]) / 2]; let d = 'M' + r2(m(pts[3], pts[0])[0]) + ' ' + r2(m(pts[3], pts[0])[1]); for (let i = 0; i < 4; i++) { const a = pts[i], nb = pts[(i + 1) % 4], mm = m(a, nb); d += 'Q' + r2(a[0]) + ' ' + r2(a[1]) + ' ' + r2(mm[0]) + ' ' + r2(mm[1]); }
            b.b.setAttribute('d', d + 'Z'); b.st.setAttribute('d', d.replace(/[-\d.]+/g, v => v)); b.st.setAttribute('transform', 'translate(' + r2(s[0] * 0.18) + ' ' + r2(s[1] * 0.18) + ') scale(0.82)'); b.g.setAttribute('opacity', r2(o));
            const g0y = yb(b.x, b.z), gy = g0y != null && b.st8 !== 'grass' && b.st8 !== 'fall' ? g0y : 0, gs = P(b.x, gy, b.z), hk = cl(1 - (b.y - gy) / 1.5, 0.3, 1);
            b.sh.setAttribute('cx', r2(gs[0])); b.sh.setAttribute('cy', r2(gs[1])); b.sh.setAttribute('rx', r2(sc * 1.1 * hk)); b.sh.setAttribute('ry', r2(sc * 0.35 * hk)); b.sh.setAttribute('opacity', b.st8 === 'hole' ? 0 : r2(0.22 * hk)); }
          // aim preview: the first part of the arc while you pull
          guideG.innerHTML = ''; if (drag && cur) { const px = drag.x - drag.x0, py = drag.y - drag.y0, len = Math.hypot(px, py); if (py > 18) { const p = cl(len / 220, 0.05, 1.3), a = Math.atan2(-px, py), th = 38 * Math.PI / 180, v = 3.6 + p * 4.2, ph = Math.atan2(-REL[0], HZ - REL[2]) + a * 0.42;
              let x = cur.x, y = cur.y, z = cur.z, vx = Math.sin(ph) * v * Math.cos(th), vz = Math.cos(ph) * v * Math.cos(th), vy = v * Math.sin(th); for (let i = 0; i < 9; i++) { const h = 0.045; vy -= G * h; x += vx * h; y += vy * h; z += vz * h; const s = P(x, y, z); S('circle', { cx: r2(s[0]), cy: r2(s[1]), r: r2(Math.max(1.5, 3.4 - i * 0.2)), fill: '#ffffff', opacity: r2(0.9 - i * 0.08) }, guideG); } } }
        } };
      newWind(); cur = mkBag(); return api;
    } });
  }; go();
})();
