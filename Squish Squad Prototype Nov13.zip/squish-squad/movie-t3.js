// Tier 3 movie: "The Lantern of Lost Woods" (3 min adventure). Needs movies.js + movies-kit.js.
(function () {
  const SM = window.SquadMovies, K = window.MK; if (!SM || !K || !SM.def) return;
  const { D, P, E, kf, win, put, show, actor, pose, go, dance, bub, lines, parts, rain, lightning, glow, film, snd, rnd, cl, lerp, stars } = K;
  const FY = 152, W = 54;
  // forest: sky (day -> night with n), far hills, two tree layers (parallax with px), ground
  function forest(L, seed, o = {}) {
    const r = rnd(seed), sky = D(L, 'inset:0;'), st = stars(L, 70, 320, 110, seed + 1, '#fffbe0', 1.2), moon = D(L, 'left:250px;top:18px;width:18px;height:18px;border-radius:50%;background:#fff8d8;box-shadow:0 0 14px 5px rgba(255,248,216,0.4);display:none;');
    const lay = (n, f, y, hh, col, sz) => { const g = D(L, 'left:0;top:0;width:1280px;height:180px;'); for (let i = 0; i < n; i++) { const x = i * (1280 / n) + r() * 40, s = sz * (0.8 + r() * 0.5); D(g, 'left:' + (x + s * 0.42) + 'px;top:' + (y - 4) + 'px;width:' + (s * 0.16) + 'px;height:' + (hh + 6) + 'px;background:' + col[1] + ';');
        [[0, 0, 1], [-0.28, 0.22, 0.75], [0.3, 0.2, 0.72]].forEach(([dx, dy, k]) => D(g, 'left:' + (x + s * (0.5 + dx) - s * k / 2) + 'px;top:' + (y - s * 0.9 + s * dy) + 'px;width:' + (s * k) + 'px;height:' + (s * k * 0.95) + 'px;border-radius:50%;background:' + col[0] + ';')); } g._f = f; return g; };
    const hills = D(L, 'left:0;top:84px;width:1280px;height:60px;background:radial-gradient(ellipse 120px 40px at 80px 60px,#6b9a7a 98%,transparent 100%) 0 0/260px 60px repeat-x;'); hills._f = 0.15;
    const L1 = lay(10, 0.35, 118, 22, ['#4f8a5a', '#5a4030'], 46), L2 = lay(7, 0.8, 140, 18, ['#3d7a48', '#4a3424'], 62);
    const gr = D(L, 'left:0;top:' + (FY - 4) + 'px;width:320px;height:' + (184 - FY) + 'px;background:linear-gradient(#5aa05a,#3f7a42);'); D(gr, 'left:0;top:0;width:320px;height:3px;background:#7ec46e;');
    const act = D(L, 'inset:0;'), nite = D(L, 'inset:0;pointer-events:none;background:#0a1440;opacity:0;'), fl = D(L, 'inset:0;pointer-events:none;background:#eef4ff;opacity:0;');
    return { act, gr, upd(t, q = {}) { const n = q.n ?? 0, px = q.px || 0, w = q.warm || 0;
      sky.style.background = 'linear-gradient(' + ['hsl(' + lerp(205, 232, n) + ',' + lerp(70, 55, n) + '%,' + lerp(68, 14, n) + '%)', 'hsl(' + lerp(195, 260, n) + ',' + lerp(70, 40, n) + '%,' + lerp(84, 24, n) + '%)'].join(',') + ')';
      if (w) sky.style.background = 'linear-gradient(hsl(' + lerp(232, 280, w) + ',60%,' + lerp(14, 30, w) + '%),hsl(' + lerp(260, 40, w) + ',80%,' + lerp(24, 62, w) + '%))';
      st.style.opacity = cl((n - 0.4) * 2).toFixed(2); show(moon, n > 0.5); [hills, L1, L2].forEach(g => { g.style.transform = 'translateX(' + (-((px * g._f) % 640)).toFixed(1) + 'px)'; });
      nite.style.opacity = (n * 0.5 * (1 - w * 0.8)).toFixed(3); fl.style.opacity = ((q.flash || 0) * 0.6).toFixed(3); } };
  }
  const aura = (p, c = 'rgba(255,236,150,0.75)', r = 46) => glow(p, c, r, 'z-index:3;mix-blend-mode:screen;');
  const walkers = (t, keys, ns, gap = 34, o = {}) => ns.map((n, i) => pose(n, go(t - i * 0.12, keys.map(k => [k[0], k[1] - i * gap, k[2], k[3]]), Object.assign({ y: FY, ph: i * 1.3 }, o))));

  function mk() {
    const S = [];
    S.push({ a: 0, b: 20, rgb: '255,220,150', lit: t => 0.9 - P(t, 6, 13) * 0.6, mk(L) { const F = forest(L, 3), lu = actor(F.act, 'lumi', W), au = aura(F.act), sp = bub(L), ti = D(L, "left:0;top:30px;width:320px;text-align:center;font-family:Georgia,serif;font-style:italic;font-weight:700;font-size:24px;line-height:1.1;color:#fffbe8;text-shadow:0 0 12px rgba(255,220,120,0.8),0 2px 0 #3a2a10;z-index:40;", 'The Lantern of<br>Lost Woods');
      const ff = parts(F.act, 8, 'width:3px;height:3px;border-radius:50%;background:#fff6a0;box-shadow:0 0 5px 2px #ffe060;', null, (i, t) => t > 7 && t < 13 ? { x: 40 + i * 34 + Math.sin(t * 0.8 + i) * 14, y: 60 + (i % 3) * 22 + Math.cos(t * 1.1 + i) * 10, o: 0.4 + 0.6 * Math.abs(Math.sin(t * 2 + i)) } : null);
      return t => { const n = P(t, 5, 12, E.io), out = t < 11 ? 1 : t < 13 ? (Math.sin(t * 40) > 0.2 ? 0.8 : 0.15) * (1 - P(t, 12.4, 13)) : 0; F.upd(t, { n }); ti.style.opacity = (P(t, 0.8, 2.2) * (1 - P(t, 5.5, 6.6))).toFixed(3);
        const s = { x: 160, y: FY, v: t > 13.4 && t < 15 ? 'left' : 'front', r: t > 13 ? -4 : 0, sy: 1 + 0.01 * Math.sin(t * 3) }; pose(lu, s); put(au, 160, FY - 26, 1 + 0.06 * Math.sin(t * 5), 0, out); ff(t);
        lines(sp, t, [[15, 19.4, 'My lantern... it went out!', 'l']], { l: [160, FY - 58] }); }; } });
    S.push({ a: 20, b: 40, rgb: '150,170,255', lit: t => 0.35, mk(L) { const F = forest(L, 5), lu = actor(F.act, 'lumi', W), ac = actor(F.act, 'acorn', W - 6), fa = actor(F.act, 'fawn', W), sp = bub(L);
      const map = D(L, 'left:60px;top:22px;width:200px;height:118px;transform-origin:50% 50%;display:none;z-index:30;border-radius:4px;background:linear-gradient(135deg,#f4e2b4,#e6c98a);box-shadow:0 4px 10px rgba(0,0,0,0.4);', '<svg viewBox="0 0 200 118" width="200" height="118"><path d="M10 10 L190 10 L190 108 L10 108Z" fill="none" stroke="#a07a3a" stroke-width="2" stroke-dasharray="1 0"></path><path d="M120 86 L150 26 L180 86Z" fill="#8a9a6a" stroke="#5a4a2a" stroke-width="1.4"></path><path d="M142 42 L150 26 L158 42 Q150 46 142 42Z" fill="#ffffff"></path><circle cx="150" cy="34" r="5" fill="#8fe8ff" stroke="#3a7aa0" stroke-width="1"></circle><path d="M22 92 Q50 60 70 84 T112 70 T146 40" stroke="#a0402a" stroke-width="2" stroke-dasharray="4 4" fill="none"></path><path d="M54 70 Q66 74 78 66" stroke="#4a8ac8" stroke-width="5" fill="none" opacity="0.7"></path><circle cx="92" cy="80" r="6" fill="#d9a03a"></circle><circle cx="108" cy="58" r="5" fill="#c84a4a"></circle><circle cx="108" cy="58" r="1.4" fill="#ffffff"></circle><text x="150" y="100" font-size="9" text-anchor="middle" fill="#5a3a1a" font-family="Georgia" font-style="italic">Glow Spring</text><circle cx="22" cy="92" r="3" fill="#5a3a1a"></circle></svg>');
      return t => { F.upd(t, { n: 0.72, px: P(t, 17, 20, E.in) * 120 }); const ms = P(t, 5, 6.2, E.out) * (1 - P(t, 11.4, 12.2)); if (ms > 0.01) { show(map, true); map.style.transform = 'scaleX(' + ms.toFixed(3) + ') rotate(' + (-2 + Math.sin(t) * 0.8).toFixed(2) + 'deg)'; } else show(map, false);
        pose(lu, go(t, [[0, 160], [17, 160], [20, 360]], { y: FY, f: 'front' })); pose(ac, go(t, [[0, -30], [3, 110], [17, 110], [20, 300]], { y: FY, f: 'front' })); pose(fa, go(t, [[0, 360], [3.4, 214], [17, 214], [20, 420]], { y: FY, f: 'front' }));
        lines(sp, t, [[3.6, 5.2, 'Look, an old map!', 'f'], [12.4, 14.6, 'We\u2019ll help you, Lumi!', 'a'], [14.8, 17, 'To Mossy Mountain!', 'f']], { a: [110, FY - 54], f: [214, FY - 58] }); }; } });
    S.push({ a: 40, b: 65, rgb: '150,190,255', lit: t => 0.4, mk(L) { const F = forest(L, 7), ns = ['lumi', 'acorn', 'fawn'].map((k, i) => actor(F.act, k, i === 1 ? W - 6 : W)), sp = bub(L);
      const rv = D(F.act, 'left:96px;top:' + (FY - 6) + 'px;width:150px;height:40px;background:repeating-linear-gradient(90deg,#4a9ad8 0 14px,#5aaae6 14px 22px);', ''); const rw = D(rv, 'inset:0;background:repeating-linear-gradient(90deg,rgba(255,255,255,0.35) 0 4px,rgba(255,255,255,0) 4px 26px);');
      const SX = [118, 148, 178, 208, 238]; SX.forEach(x => D(F.act, 'left:' + (x - 11) + 'px;top:' + (FY - 4) + 'px;width:22px;height:9px;border-radius:50%;background:#8a8a90;box-shadow:inset 0 2px 0 #b0b0b6;'));
      const spl = parts(F.act, 10, 'width:4px;height:4px;border-radius:50%;background:#cfeaff;z-index:7;', null, (i, t) => { const d = t - 10.4; if (d < 0 || d > 0.9) return null; const a = -Math.PI * (0.2 + 0.6 * (i / 9)); return { x: 178 + Math.cos(a) * 40 * d, y: FY + 4 + Math.sin(a) * 60 * d + 60 * d * d, o: 1 - d / 0.9 }; });
      return t => { F.upd(t, { n: 0.72, px: 300 + Math.min(t, 4) * 30 }); rw.style.backgroundPosition = (t * 30).toFixed(1) + 'px 0';
        ns.forEach((n, i) => { const a = 4 + i * 1.6, hk = [[0, -30 - i * 34], [a, 92]]; SX.forEach((x, k) => hk.push([a + 0.6 + k * 0.6, x, null, { m: 'hop' }])); hk.push([a + 0.6 + 5 * 0.6, 270 + i * 10, null, { m: 'hop' }]); hk.push([25, 270 + i * 10]);
          let s = go(t, hk, { y: FY, m: 'walk', ph: i, f: 'front' });
          if (i === 1 && t > 9.6 && t < 13.6) { const sl = P(t, 9.6, 10.3, E.in) * (1 - P(t, 12, 12.8, E.back)); s = { x: 178 + 6 * sl, y: FY + 10 * sl, v: t < 12 ? 'right' : 'front', r: 40 * sl * (1 + 0.1 * Math.sin(t * 20)) }; }
          if (i === 2 && t > 10 && t < 12.8) s = { x: 160, y: FY, v: 'right', r: 18 * P(t, 10, 10.5) * (1 - P(t, 12, 12.8)) };
          pose(n, s); }); spl(t);
        lines(sp, t, [[9.6, 11.2, 'Whoa-whoa-whoa!', 'a'], [12, 14.6, 'Got you!', 'f'], [17.5, 21, 'Thank you, Fawn!', 'a']], { a: t < 15 ? [178, FY - 52] : [280, FY - 52], f: [160, FY - 58] }); }; } });
    S.push({ a: 65, b: 90, rgb: '255,210,120', lit: t => 0.45, mk(L) { const F = forest(L, 9), tr = D(F.act, 'left:176px;top:20px;width:70px;height:' + (FY - 16) + 'px;border-radius:30px 30px 4px 4px;background:linear-gradient(90deg,#6a4a2a,#8a6038 50%,#5a3a20);');
      D(F.act, 'left:150px;top:-10px;width:120px;height:60px;border-radius:50%;background:#3d7a48;'); const hole = D(F.act, 'left:193px;top:72px;width:36px;height:42px;border-radius:50%;background:#2a1a0c;');
      const te = actor(F.act, 'teddy', W + 4), tc = D(F.act, 'left:186px;top:96px;width:50px;height:60px;border-radius:40% 40% 0 0/14px 14px 0 0;background:linear-gradient(90deg,#6a4a2a,#8a6038 50%,#5a3a20) -10px 0/70px 100%;z-index:4;'), drip = D(F.act, 'left:196px;top:110px;width:6px;height:18px;border-radius:0 0 4px 4px;background:#f2b630;z-index:5;');
      const ns = ['lumi', 'acorn', 'fawn'].map((k, i) => actor(F.act, k, i === 1 ? W - 6 : W)), sp = bub(L);
      const bees = parts(F.act, 4, 'width:8px;height:6px;border-radius:50%;background:repeating-linear-gradient(90deg,#f2c030 0 2px,#2a1a0c 2px 4px);z-index:8;', null, (i, t) => ({ x: 211 + Math.cos(t * 3 + i * 1.6) * (26 + i * 4), y: 70 + Math.sin(t * 4.2 + i) * 14, r: Math.sin(t * 9 + i) * 20 }));
      return t => { F.upd(t, { n: 0.72, px: 420 }); bees(t); const pop = P(t, 15, 17.4, E.lin), heave = t > 7 && t < 15 ? Math.max(0, Math.sin((t - 7) * Math.PI / 2.6)) : 0;
        if (t < 15) { pose(te, { x: 211 + Math.sin(t * 7) * 2 * (1 - heave), y: 114 - heave * 6, v: 'front', r: Math.sin(t * 5) * 6 + heave * -8, sh: false }); show(tc, true); }
        else { show(tc, false); const h = Math.sin(Math.PI * Math.min(1, pop)) * 50; pose(te, { x: lerp(211, 150, pop), y: lerp(114, FY, pop) - h, v: 'front', r: pop < 1 ? pop * 360 : 0, gy: FY }); }
        drip.style.height = (12 + 6 * Math.sin(t * 2)).toFixed(1) + 'px';
        ns.forEach((n, i) => { const s = go(t, [[0, 40 + i * 30], [6.5, 140 - i * 26], [17.4, 140 - i * 26], [19, 110 - i * 26]], { y: FY, f: 'right', ph: i }); if (s && t > 7 && t < 15) { s.v = 'right'; s.r = -14 * heave; s.x -= heave * 6; } if (s && t > 15 && t < 17.8) s.v = 'front'; pose(n, s); });
        lines(sp, t, [[1, 4.6, 'Help! I\u2019m stuck in the honey tree!', 't'], [7, 9, 'Heave...', 'f'], [9.6, 11.6, 'Ho...', 'a'], [12.2, 14.6, 'HEAVE!', 'l'], [18, 22, 'Thanks! I\u2019ll come too!', 'T']], { t: [211, 74], f: [88, FY - 58], a: [114, FY - 52], l: [140, FY - 58], T: [150, FY - 60] }); }; } });
    S.push({ a: 90, b: 115, rgb: '255,140,160', lit: t => 0.5, mk(L) { const F = forest(L, 11), sp = bub(L);
      const shroom = (x, w, h, c) => { D(F.act, 'left:' + (x - w * 0.14) + 'px;top:' + (FY - h) + 'px;width:' + (w * 0.28) + 'px;height:' + h + 'px;border-radius:8px 8px 2px 2px;background:#f4ead2;'); D(F.act, 'left:' + (x - w / 2) + 'px;top:' + (FY - h - w * 0.38) + 'px;width:' + w + 'px;height:' + (w * 0.5) + 'px;border-radius:' + w + 'px ' + w + 'px 6px 6px;background:radial-gradient(circle at 30% 40%,#fff 0 5%,transparent 6%),radial-gradient(circle at 66% 30%,#fff 0 6%,transparent 7%),radial-gradient(circle at 50% 70%,#fff 0 4%,transparent 5%),' + c + ';'); };
      shroom(196, 70, 54, '#d8443a'); shroom(250, 54, 34, '#e0603a'); shroom(36, 50, 30, '#c8443a');
      const mo = actor(F.act, 'moss', W - 4), ns = ['lumi', 'acorn', 'fawn', 'teddy'].map((k, i) => actor(F.act, k, i === 1 ? W - 6 : W));
      return t => { F.upd(t, { n: 0.72, px: 600 }); const mb = Math.abs(Math.sin(t * 5)) * (t < 6 ? 10 : 0); pose(mo, go(t, [[0, 150, FY - mb, { m: 'still' }]], { y: FY }));
        ns.forEach((n, i) => { const a = 7 + i * 2.6, k = [[0, 40 - i * 26], [a - 1, 110], [a - 0.2, 150, FY - 22, { m: 'hop', h: 8 }], [a + 0.9, 280 - i * 18, FY, { m: 'hop', h: 92 }], [25, 280 - i * 18]]; let s = go(t, k, { y: FY, f: 'front', ph: i });
          if (s && t > a && t < a + 0.9) s.r = (P(t, a, a + 0.9) * 360) % 360; pose(n, s); });
        const bo = ns.some((n, i) => { const a = 7 + i * 2.6; return t > a - 0.3 && t < a + 0.1; }); if (bo) { const m = mo; } pose(mo, { x: 150, y: FY - mb, v: 'front', sx: bo ? 1.15 : 1, sy: bo ? 0.82 : 1 });
        if (t > 18.4) pose(mo, go(t, [[18.4, 150], [19, 220, null, { m: 'hop', h: 30 }], [19.6, 270, null, { m: 'hop', h: 30 }], [25, 270]], { y: FY, m: 'hop', f: 'front' }));
        lines(sp, t, [[1.2, 3.8, 'The mushroom maze!', 'a'], [4, 6.6, 'Need a lift? Boing!', 'm'], [20, 23.4, 'Moss, come with us!', 'l']], { a: [40, FY - 52], m: [150, FY - 56], l: [280, FY - 58] }); }; } });
    S.push({ a: 115, b: 140, rgb: '120,130,220', lit: t => 0.25 + lightning(t, [3, 9.2, 18]) * 0.8, mk(L) { const F = forest(L, 13), rn = rain(L, 60, 4), sp = bub(L);
      F.gr.style.background = 'linear-gradient(#6a6a7a,#4a4a5a)'; D(F.act, 'left:0;top:' + (FY + 8) + 'px;width:320px;height:30px;background:linear-gradient(#3a3a4a,#20202c);');
      const sh = actor(F.act, 'leo', 150); sh.style.zIndex = '1'; const ns = ['lumi', 'acorn', 'fawn', 'teddy', 'moss'].map((k, i) => actor(F.act, k, i === 1 ? W - 6 : W - 2));
      return t => { const l = lightning(t, [3, 9.2, 18]); F.upd(t, { n: 1, px: 800 + Math.min(t, 7) * 25, flash: l }); rn(t);
        pose(sh, t > 8.6 ? { x: 220 + Math.sin(t * 0.7) * 6, y: FY - 8, v: 'front', f: 'brightness(0) blur(1px)', o: 0.82 * P(t, 8.6, 10), k: 1 + 0.06 * Math.sin(t * 1.3), sh: false } : null);
        const sc = t > 9.6, cw = sc ? Math.sin(t * 40) * 1.4 : 0;
        ns.forEach((n, i) => { let s = go(t, [[0, -20 - i * 30], [7, 170 - i * 30]], { y: FY, f: 'right', ph: i }); if (s) { s.r += t < 7 ? -6 : 0; if (sc) { s.x = 150 - i * 28 - P(t, 9.6, 10.4) * 14 + cw; s.v = 'front'; s.sy = 0.92; s.sx = 1.06; } } pose(n, s); });
        lines(sp, t, [[1, 4, 'Hold on tight!', 't'], [12.4, 15.6, 'W-what IS that?!', 'a'], [19, 23, 'ROAAAR!', 'x']], { t: [80, FY - 58], a: [122, FY - 52], x: [220, 40] }); }; } });
    S.push({ a: 140, b: 150, rgb: '255,220,150', lit: t => 0.45, mk(L) { const F = forest(L, 15), le = actor(F.act, 'leo', W + 4), lu = actor(F.act, 'lumi', W), sp = bub(L), bug = glow(F.act, 'rgba(255,240,120,0.95)', 7, 'z-index:9;'), bg2 = glow(F.act, 'rgba(255,240,120,0.4)', 20, 'z-index:8;');
      return t => { F.upd(t, { n: 1, px: 980 }); const sm = P(t, 8.4, 9); pose(le, { x: 214 + (t < 7 ? Math.sin(t * 40) * 1.2 : 0), y: FY - (t > 8.4 && t < 9 ? Math.sin((t - 8.4) * Math.PI / 0.6) * 10 : 0), v: 'front', sy: t < 7 ? 0.94 : 1 }); pose(lu, { x: 116, y: FY, v: 'right' });
        const u = P(t, 6, 8.2, E.io), bx = lerp(134, 204, u), by = lerp(FY - 30, FY - 34, u) - Math.sin(Math.PI * u) * 24 + Math.sin(t * 6) * 2; put(bug, bx, by, 1, 0, t > 5.6 ? 1 : 0); put(bg2, bx, by, 1 + 0.2 * Math.sin(t * 7), 0, t > 5.6 ? 1 : 0);
        lines(sp, t, [[0.4, 5, 'I only roar because... I\u2019m scared of the dark too.', 'L'], [5.4, 8.2, 'Here, share my glow-bug!', 'l']], { L: [214, FY - 60], l: [116, FY - 58] }); }; } });
    S.push({ a: 150, b: 170, rgb: '255,230,150', lit: t => t > 8.5 ? 1.2 : 0.5, mk(L) { const F = forest(L, 17), sp = bub(L);
      const pool = D(F.act, 'left:110px;top:' + (FY - 8) + 'px;width:100px;height:22px;border-radius:50%;background:radial-gradient(ellipse at 50% 40%,#e8fbff,#8fe8ff 50%,#3a8ac0);box-shadow:0 0 20px 8px rgba(143,232,255,0.6);'), big = glow(L, 'rgba(255,240,170,0.9)', 160, 'z-index:20;mix-blend-mode:screen;');
      const ns = ['acorn', 'fawn', 'teddy', 'moss', 'leo'].map((k, i) => actor(F.act, k, i === 0 ? W - 6 : W - 2)), lu = actor(F.act, 'lumi', W), au = aura(F.act, 'rgba(255,236,150,0.85)', 50);
      const rings = parts(L, 3, 'width:40px;height:40px;border-radius:50%;border:3px solid #fff6c8;box-sizing:border-box;z-index:21;', null, (i, t) => { const d = t - 8.5 - i * 0.25; return d > 0 && d < 1.6 ? { x: 160, y: FY - 20, k: 1 + d * 6, o: 1 - d / 1.6 } : null; });
      const sp2 = parts(L, 16, 'width:4px;height:4px;border-radius:50%;background:#fff6a0;box-shadow:0 0 6px 2px #ffd860;z-index:22;', null, (i, t) => t > 8.6 ? { x: (i * 41 + t * 8 * (i % 3 + 1)) % 330, y: 150 - ((t - 8.6) * 18 * (1 + i % 4) + i * 13) % 150, o: 0.8 } : null);
      return t => { const w = P(t, 8.5, 12, E.io); F.upd(t, { n: 1, px: 1200, warm: w }); pool.style.filter = 'brightness(' + (1 + w * 0.6).toFixed(2) + ')';
        ns.forEach((n, i) => pose(n, t > 10 ? dance(t, [44, 74, 246, 276, 216][i], FY, i % 2 ? 'jump' : 'bounce', 0.45, i * 0.2) : go(t, [[0, -20 - i * 30], [4.5, [44, 74, 246, 276, 216][i] - (i > 1 ? 0 : 0)]], { y: FY, ph: i, f: 'front' })));
        const ls = go(t, [[0, -60], [4.5, 100], [6, 100], [7.4, 128], [10, 128]], { y: FY, f: 'right' }); if (ls && t > 7.4 && t < 8.6) ls.r = 16 * Math.sin(Math.PI * P(t, 7.4, 8.6, E.lin)); pose(lu, ls); if (ls) put(au, ls.x, ls.y - 26, 1 + w * 0.8 + 0.06 * Math.sin(t * 5), 0, w);
        put(big, 160, FY - 20, 0.2 + w * 1.6, 0, Math.max(0, 1 - Math.abs(t - 9.2) / 3) * 0.9); rings(t); sp2(t);
        lines(sp, t, [[1.5, 4.5, 'The Glow Spring!', 'a'], [12, 16, 'The whole forest is glowing!', 'l'], [16.4, 19.6, 'Hooray!', 'T']], { a: [44, FY - 52], l: [128, FY - 58], T: [246, FY - 58] }); }; } });
    S.push({ a: 170, b: 180, rgb: '255,220,150', lit: t => 0.6, outF: false, mk(L) { const F = forest(L, 19), ns = ['leo', 'moss', 'teddy', 'fawn', 'acorn', 'lumi'].map(k => actor(F.act, k, W - 10)), gl = ns.map(() => aura(F.act, 'rgba(255,236,150,0.55)', 22));
      const cr = D(L, "left:0;top:22px;width:320px;text-align:center;font-family:Georgia,serif;font-style:italic;color:#fffbe8;text-shadow:0 0 8px rgba(255,220,120,0.8);z-index:40;", '<div style="font-size:22px;font-weight:700;">The End</div><div style="font-size:8px;margin-top:5px;letter-spacing:1px;font-style:normal;">STARRING LUMI \u00b7 ACORN \u00b7 FAWN \u00b7 TEDDY \u00b7 MOSS \u00b7 LEO</div>');
      const ff = parts(F.act, 10, 'width:3px;height:3px;border-radius:50%;background:#fff6a0;box-shadow:0 0 5px 2px #ffe060;', null, (i, t) => ({ x: (i * 37 + Math.sin(t + i) * 12) % 320, y: 40 + (i % 4) * 22 + Math.cos(t * 1.2 + i) * 8, o: 0.4 + 0.6 * Math.abs(Math.sin(t * 2 + i)) }));
      return t => { F.upd(t, { n: 1, px: 1400 + t * 30, warm: 0.25 }); ff(t); cr.style.opacity = P(t, 2, 3.5).toFixed(3);
        ns.forEach((n, i) => { const s = go(t, [[0, -20 - i * 34], [10, 300 - i * 34]], { y: FY, ph: i }); s.f = 'brightness(0.4) saturate(0.7)'; pose(n, s); put(gl[i], s.x, s.y - 20, 1, 0, 1); }); }; } });
    return film(S, { rgb: '200,210,255' });
  }

  function score(Q) { const I = snd(Q);
    const TH = [[0, 74, 1], [1, 76, .5], [1.5, 78, .5], [2, 81, 1.5], [3.5, 79, .5], [4, 78, 1], [5, 76, 1], [6, 74, 2]], TH2 = [[0, 71, 1], [1, 74, .5], [1.5, 76, .5], [2, 78, 1.5], [3.5, 76, .5], [4, 74, 1], [5, 73, 1], [6, 74, 2]];
    const theme = (t0, B, f = I.str, v = 0.05, tr = 0) => { TH.forEach(([o, m, d]) => f(t0 + o * B, m + tr, d * B * 1.05, v)); TH2.forEach(([o, m, d]) => f(t0 + (8 + o) * B, m + tr, d * B * 1.05, v)); };
    const chords = (t0, B, n, P0, v = 0.02) => { for (let k = 0; k < n; k++) I.pad(t0 + k * 4 * B, P0[k % P0.length], 4 * B * 1.02, v, 'sawtooth', 1100); };
    const DM = [[50, 54, 57, 62], [47, 54, 59, 62], [43, 50, 55, 59], [45, 52, 57, 61]];
    chords(0, 0.75, 4, DM, 0.018); [86, 81, 78, 74, 78, 81].forEach((m, k) => I.bell(1 + k * 0.6, m, 1.2, 0.035)); theme(4.5, 0.4, I.str, 0.035);
    I.pad(11, [50, 53, 57], 3, 0.02, 'triangle', 900); I.tone(12.4, 880, 0.6, { to: 220, slide: 0.6, vol: 0.04, type: 'triangle' }); I.pad(13.2, [46, 50, 53], 6.5, 0.022, 'sawtooth', 700); [69, 67, 65, 62].forEach((m, k) => I.voice(15 + k * 1.1, m, 1.1, 0.05));
    I.pad(20, [50, 55, 59], 5, 0.018); I.tone(25, 300, 1, { to: 900, slide: 0.9, type: 'triangle', vol: 0.02 }); I.noise(25, 1, { ft: 'bandpass', f: 1500, vol: 0.03 });
    const march = (t0, t1, B, tr = 0) => I.beat(t0, t1, B, (t, i) => { I.pluck(t, [50, 57, 54, 57][i % 4] - 12 + tr, 0.2, 0.08); if (i % 4 === 0) I.timp(t, 0.12); if (i % 2) I.hat(t, 0.02); if (i % 16 === 0) I.pad(t, DM[(i / 16) % 4].map(m => m + tr), 16 * B, 0.014); });
    march(28, 40, 0.375); theme(32, 0.375, I.brass, 0.035);
    I.beat(40, 49.6, 0.1875, (t, i) => I.pluck(t, [62, 66, 69, 74, 69, 66][i % 6], 0.15, 0.04)); I.noise(40, 25, { ft: 'bandpass', f: 900, q: 0.5, vol: 0.02, at: 2, sus: 1 });
    [44.6, 45.2, 45.8, 46.4, 47, 47.6, 48.2].forEach(t => I.boing(t, 0.04));
    I.beat(49.6, 52.6, 0.07, (t, i) => I.str(t, 74 + (i % 2), 0.08, 0.025)); I.splash(50.4); I.brass(52.6, 62, 0.4, 0.05); I.brass(52.6, 66, 0.4, 0.05); I.brass(53, 69, 1.6, 0.05); I.crash(53, 0.08); theme(54, 0.42, I.str, 0.04);
    I.beat(65, 72, 0.5, (t, i) => I.tone(t, [110, 130.8, 146.8, 130.8][i % 4], 0.3, { type: 'square', lp: 700, vol: 0.05 })); I.bee(65, 25, 0.018);
    [72, 74.6, 77.2].forEach(t => { I.timp(t, 0.35); I.str(t, 50, 1.2, 0.05); I.str(t + 0.6, 57, 0.8, 0.04); }); I.boing(80, 0.12); I.pop(80.2, 0.15); I.crash(80.3, 0.08); march(82, 90, 0.375, 2);
    I.beat(90, 115, 0.375, (t, i) => { I.pluck(t, [55, 59, 62, 67][i % 4], 0.15, 0.06); if (i % 2 === 0) I.hat(t, 0.02); }); [96, 98.6, 101.2, 103.8].forEach(t => { I.boing(t, 0.12); I.whoosh(t, 0.5, 0.05); }); I.crash(108.5, 0.08); theme(108.5, 0.4, I.brass, 0.035, 5);
    I.rumble(115, 25, 0.06); I.thunder(118); I.thunder(124.2, 0.4); I.thunder(133, 0.4); I.beat(115, 140, 0.75, (t, i) => { I.str(t, [38, 38, 39, 38][i % 4], 0.7, 0.035); if (i % 4 === 3) I.timp(t, 0.18); });
    I.tone(123.6, 90, 2.4, { to: 60, slide: 2, type: 'sawtooth', lp: 500, vol: 0.16, at: 0.1 }); I.noise(123.6, 2.2, { ft: 'lowpass', f: 700, fTo: 200, vol: 0.18, at: 0.1 }); I.tone(134, 110, 1.8, { to: 70, slide: 1.6, type: 'sawtooth', lp: 600, vol: 0.12, at: 0.1 });
    I.pad(140, [50, 54, 57, 62], 10, 0.02, 'triangle', 1400); theme(141, 0.5, I.piano, 0.05); I.sparkle(146, 86);
    I.beat(150, 158.5, 0.25, (t, i) => I.str(t, 50 + Math.floor(i / 4), 0.24, 0.02 + i * 0.0008)); I.timp(157.8, 0.4); I.timp(158.1, 0.45);
    I.crash(158.5, 0.15); I.boom(158.5, 0.25); chords(158.5, 0.5, 5, DM, 0.03); theme(158.5, 0.5, I.brass, 0.05); theme(158.5, 0.5, I.str, 0.04, 12); [74, 78, 81, 86, 90].forEach((m, k) => I.bell(158.6 + k * 0.08, m, 1.4, 0.05)); [62, 66, 69].forEach(m => I.voice(158.5, m, 8, 0.025));
    theme(170, 0.55, I.piano, 0.05); chords(170, 0.55, 4, DM, 0.014); I.bell(179, 86, 1.2, 0.04);
  }
  SM.def('lantern', { mk, score, beat: t => { const on = (t >= 28 && t < 40) || (t >= 82 && t < 115) || (t >= 160 && t < 170); if (!on) return null; const x = t / 0.375; return { n: Math.floor(x), ph: x - Math.floor(x), amp: 0.6 }; },
    cues: [[13.3, 'gasp'], [33, 'cheer'], [50.2, 'gasp'], [53, 'cheer'], [80.3, 'laugh'], [96.2, 'laugh'], [108.5, 'cheer'], [119, 'doze'], [125, 'hide'], [133.2, 'hide'], [146.5, 'cheer'], [158.3, 'wake'], [159, 'cheer'], [164, 'cheer']] });
})();
