// Shared chest catalogue + loot rolls for the v3 shop and Chest Smash. Stars are not used: duplicates pay out coins.
(function () {
  const GROUPS = [{"key":"snack","label":"SNACK SHACK","names":["Paper Bag","Lunchbox Chest","Tin Lunchbox","Glass Bento","Rainbow Candy Box"],"bg":"radial-gradient(circle at 50% 46%, rgba(255,250,232,0.95) 0, rgba(255,250,232,0) 48%), repeating-conic-gradient(#ffb59a 0 25%, #fff0e2 0 50%) 0 0/56px 56px","ink":"#c4651f","dark":"#7a3a10","tint":"#fff0e2","lip":"#f2c7a0"},{"key":"fruit","label":"FRUIT PATCH","names":["Wooden Crate","Fruit Basket","Picnic Hamper","Crystal Fruit Bowl","Rainbow Harvest"],"bg":"radial-gradient(circle at 50% 44%, #fffbe0 0, rgba(255,251,224,0) 50%), radial-gradient(circle at 12% 88%, #b8f08a 0, rgba(184,240,138,0) 42%), radial-gradient(circle at 88% 12%, #ffd27a 0, rgba(255,210,122,0) 42%), linear-gradient(180deg,#fff6c8,#ffe08a 60%,#a8e07a)","ink":"#b88a00","dark":"#6a4a00","tint":"#fff6d6","lip":"#ecd078"},{"key":"ocean","label":"OCEAN PALS","names":["Pebble Shell","Clam Chest","Pearl Clam","Crystal Clam","Rainbow Pearl Clam"],"bg":"radial-gradient(rgba(255,255,255,0.45) 1.5px, transparent 2.5px) 0 0/34px 34px, radial-gradient(circle at 50% 0%, #c9f6ff 0, rgba(201,246,255,0) 58%), linear-gradient(180deg,#7ad8f0 0%,#3aa0d8 55%,#1f5fa8 100%)","ink":"#2f7fd6","dark":"#13457e","tint":"#e4f3ff","lip":"#a9d2f2"},{"key":"pet","label":"PET SHOP","names":["Cardboard Box","Kitty Chest","Velvet Kitty Chest","Crystal Kitty Palace","Rainbow Kitty Throne"],"bg":"radial-gradient(circle at 50% 44%, #fff4fa 0, rgba(255,244,250,0) 50%), radial-gradient(#ffd0e8 3px, transparent 4px) 0 0/30px 30px, linear-gradient(180deg,#ffe9f6,#ffbfde)","ink":"#c0268f","dark":"#7a1058","tint":"#ffe9f6","lip":"#f0a8d8"},{"key":"forest","label":"FOREST FRIENDS","names":["Mossy Stump","Stump Chest","Iron-Bound Stump","Crystal Heartwood","Rainbow Fairy Stump"],"bg":"radial-gradient(circle at 50% 40%, #f4ffd6 0, rgba(244,255,214,0) 46%), radial-gradient(circle at 10% 20%, #7fd86a 0, rgba(127,216,106,0) 36%), radial-gradient(circle at 90% 28%, #5fbf5a 0, rgba(95,191,90,0) 36%), linear-gradient(180deg,#c8f0a8,#7cc870 60%,#4a9a4a)","ink":"#16a86a","dark":"#0e5a38","tint":"#e2fbef","lip":"#98dcbc"},{"key":"sky","label":"SKY & STARS","names":["Rain Cloud","Cloud Chest","Silver-Lined Cloud","Starlight Cloud","Rainbow Cloud"],"bg":"radial-gradient(#ffffff 1.2px, transparent 2px) 0 0/46px 46px, radial-gradient(circle at 50% 42%, #a8a0ff 0, rgba(168,160,255,0) 52%), linear-gradient(180deg,#2a2a8a,#4a3ab8 50%,#7a5ae0)","ink":"#5a3ad0","dark":"#2e1a7a","tint":"#ece6ff","lip":"#c3b0f2"},{"key":"dream","label":"DREAMLAND","names":["Stone Tower","Castle Chest","Royal Castle","Crystal Palace","Rainbow Castle"],"bg":"radial-gradient(circle at 50% 42%, #fff0fb 0, rgba(255,240,251,0) 46%), radial-gradient(circle at 15% 15%, #ffc2e8 0, rgba(255,194,232,0) 42%), radial-gradient(circle at 85% 82%, #c8a8ff 0, rgba(200,168,255,0) 46%), linear-gradient(180deg,#f6d8ff,#d9a8f0 60%,#a874e0)","ink":"#9a2fc8","dark":"#5a1078","tint":"#f6e3ff","lip":"#d9a8f0"},{"key":"bakery","label":"SWEET BAKERY","names":["Plain Muffin","Cupcake Chest","Fancy Cupcake","Sugar Crystal Cake","Rainbow Party Cake"],"bg":"radial-gradient(circle at 50% 44%, #fffaf2 0, rgba(255,250,242,0) 46%), repeating-linear-gradient(90deg, rgba(255,170,200,0.35) 0 20px, transparent 20px 40px), repeating-linear-gradient(0deg, rgba(255,170,200,0.35) 0 20px, transparent 20px 40px), #fff3ea","ink":"#c2502a","dark":"#7a2a12","tint":"#fff0e6","lip":"#f2b8a0"},{"key":"heroes","label":"MASKED HEROES","names":["Cardboard Hero Box","Hero Chest","Iron Hero Chest","Legend Vault","Rainbow Hero Vault"],"bg":"radial-gradient(circle at 50% 44%, #fff6c8 0, rgba(255,246,200,0) 34%), radial-gradient(rgba(192,24,46,0.22) 3px, transparent 3.5px) 0 0/14px 14px, repeating-conic-gradient(from 0deg at 50% 44%, #ffd84a 0 10deg, #ff8a6a 10deg 20deg)","ink":"#c0182e","dark":"#6a0a1a","tint":"#ffe4e6","lip":"#f2a0aa"},{"key":"elemental","label":"ELEMENTAL HEROES","names":["Rock Core","Power Core","Charged Core","Crystal Core","Rainbow Omni-Core"],"bg":"radial-gradient(circle at 50% 42%, #e8eeff 0, rgba(232,238,255,0) 34%), radial-gradient(circle at 8% 8%, rgba(95,208,106,0.85) 0, rgba(95,208,106,0) 36%), radial-gradient(circle at 92% 8%, rgba(159,240,240,0.85) 0, rgba(159,240,240,0) 36%), radial-gradient(circle at 8% 96%, rgba(255,138,58,0.85) 0, rgba(255,138,58,0) 36%), radial-gradient(circle at 92% 96%, rgba(200,160,255,0.85) 0, rgba(200,160,255,0) 36%), linear-gradient(180deg,#3a3ab0,#22226a)","ink":"#3a3ab0","dark":"#1a1a6a","tint":"#e8eeff","lip":"#a9b8f0"},{"key":"spooky","label":"SPOOKY SQUISH","names":["Pine Coffin","Coffin Chest","Iron Coffin","Crystal Coffin","Rainbow Phantom Coffin"],"bg":"radial-gradient(circle at 80% 16%, #fff3c4 0, #ffe27a 30px, rgba(255,226,122,0) 32px), radial-gradient(circle at 50% 100%, rgba(255,138,40,0.75) 0, rgba(255,138,40,0) 58%), linear-gradient(180deg,#2a1240,#4a1f6a 60%,#6a2a5a)","ink":"#7a2a00","dark":"#3a1040","tint":"#ffe6cc","lip":"#e0a070"}];
  const GK = {}; GROUPS.forEach(g => GK[g.key] = g);
  const TIERS = [
    { k:'common', n:'Common', c:'#b8744a', bg:'linear-gradient(180deg,#ffe2c4,#e0a070)', odds:[72,22,5,1,0], coins:[40,120], price:{ cur:'coins', n:300 } },
    { k:'rare', n:'Rare', c:'#5a6c90', bg:'linear-gradient(180deg,#f1f5fc,#a2b2ce)', odds:[55,33,9.5,2.5,0], coins:[80,220], price:{ cur:'coins', n:1200 } },
    { k:'epic', n:'Epic', c:'#c27a00', bg:'linear-gradient(180deg,#fff3a0,#ffc23a)', odds:[30,44,20,5,1], coins:[150,400], price:{ cur:'gems', n:120 } },
    { k:'legendary', n:'Legendary', c:'#2a7fb8', bg:'linear-gradient(180deg,#dcfdff,#9fb8ff)', odds:[0,48,36,12,4], coins:[300,700], price:{ cur:'gems', n:320 } },
    { k:'set', n:'Rainbow', c:'#b05ae0', bg:'linear-gradient(90deg,#ffb3dd,#ffe38a,#9ff7c8,#9fd8ff,#d6b3ff)', odds:[0,0,62,28,10], coins:[600,1400], price:{ cur:'gems', n:680 } },
  ];
  const TI = {}; TIERS.forEach((t, i) => TI[t.k] = i);
  const RARN = ['Common', 'Rare', 'Epic', 'Legendary', 'Rainbow'];   // Nov 12: rainbow (rar 4) is a droppable rarity now (odds: 5th number per tier)
  const DUPE = [60, 180, 500, 1500, 3000];
  const PITY_N = 10;
  const KEY = 'ssShop3';
  const st = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } };
  const put = o => { try { localStorage.setItem(KEY, JSON.stringify({ ...st(), ...o })); } catch (e) {} };
  const Q = () => window.SquishSquad;
  function pick(gk, r) {
    const R = Q() ? Q().ROSTER : [];
    const ok = c => c.set === gk && c.art && !c.reward && !c.pass;
    for (let d = 0; d < 4; d++) for (const rr of [r - d, r + d]) {
      const pool = R.filter(c => ok(c) && c.rar === rr);
      if (pool.length) { const w = pool.map(c => Q().owns(c.id) ? 1 : 3); let y = Math.random() * w.reduce((a, b) => a + b, 0), k = 0; for (; k < pool.length - 1; k++) { if (y < w[k]) break; y -= w[k]; } return pool[k]; }
    }
    return null;
  }
  function info(id) {
    const q = Q(); const c = q && q.ROSTER[id]; if (!c) return null; const R = q.RAR[c.rar] || {};
    return { id, name: c.name, concept: c.concept, set: c.set, rar: c.rar, rarLabel: R.label || RARN[c.rar], rarBg: R.bg || '#fff', rarInk: R.ink || '#45107a', src: q.src(id) || '', move: c.move };
  }
  const API = {
    GROUPS, GK, TIERS, TI, PITY_N, state: st, save: put,
    pity() { return st().pity || 0; },
    // roll + grant: returns a reward the opening screen can show
    open(gk, tierKey, opts) {
      const T = TIERS[TI[tierKey] || 0], s = st(); let pity = (s.pity || 0) + 1;
      let x = Math.random() * T.odds.reduce((a, b) => a + b, 0), r = 0;
      for (; r < T.odds.length - 1; r++) { if (x < T.odds[r]) break; x -= T.odds[r]; }
      if (r < 2 && pity >= PITY_N) r = 2;
      if (r >= 2) pity = 0;
      put({ pity, opened: (s.opened || 0) + 1 });
      const c = pick(gk, r), lo = T.coins[0], hi = T.coins[1];
      const coins = Math.round((lo + Math.random() * (hi - lo)) / 10) * 10;
      const out = { group: gk, tier: tierKey, coins, isNew: false, dupeCoins: 0, creature: null, pityHit: r >= 2 && (s.pity || 0) + 1 >= PITY_N };
      if (c && Q()) {
        const g = Q().grant(c.id, 'n');
        if (g && g.stars) Q().add('stars', -g.stars);
        out.isNew = !!(g && g.isNew); out.dupeCoins = out.isNew ? 0 : DUPE[c.rar] || 60;
        out.creature = info(c.id);
      }
      if (Q() && !(opts && opts.noCoins)) Q().add('coins', coins + out.dupeCoins);
      return out;
    },
    info,
  };
  window.ChestLoot = API;
})();
