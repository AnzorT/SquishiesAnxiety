# Squish Squad: game prototype (start here)

Squish Squad is a cute plush-creature game: you squish creatures, collect them from chests, keep them in a house you renovate, and play mini games with them. This folder is the playable prototype exactly as it was on Nov 13, 2026: every screen, creature, animation and asset. It was built as browser pages, so it runs in any browser with no build step.

The full day-by-day build log (567 KB) is in `docs/HISTORY.md`. **Don't read it whole.** Grep it for the thing you are touching, e.g. `grep -n "Duchess" docs/HISTORY.md` or `grep -n "CARDS v6" docs/HISTORY.md`. The open to-do list is `docs/What's Left.md` plus "Known gaps" below.

## Run it

```
python3 -m http.server 8000        # or: npm start  (npx http-server, caching off)
```

Then open `http://localhost:8000/Main%20Menu.dc.html`. The pages load React 18, Babel and three.js from unpkg.com and the fonts from Google Fonts, so they need internet. Everything else is local.

When you edit a script, bump its `?v=` in every page that loads it. Each page lists its scripts in `<helmet>`, so grep the pages for the file name. Phones and browsers cache hard, and the version tag is how changes get through.

## How a page works (the "dc" page format)

Every `*.dc.html` page is one screen. `support.js` is the small runtime that renders it.
- `<x-dc>` holds the markup template. `{{ name }}` binds a value, `<sc-if value="{{ x }}">` shows or hides, `<sc-for list="{{ xs }}" as="x">` repeats. `ref="{{ fooRef }}"` gives a DOM ref. Event props like `onClick="{{ fn }}"` take functions.
- `<helmet>` holds the page's `<script src>`, `<link>` and `<style>` tags. Shared engines are plain JS files on `window.*`.
- `<script type="text/x-dc" data-dc-script data-props="...">` holds `class Component extends DCLogic { state; componentDidMount(); renderVals() { return {...template values} } }`. It works like a React class component: `renderVals()` returns everything the template binds. `data-props` declares the page's props (editor type, default).
- `<dc-import name="Other Page" some-prop="{{ v }}" hint-size="852px,393px">` embeds another page by its title. Props pass through as kebab-case. Pages often take `bare` (no test chrome, for embedding) and `on-*` callbacks.
- Pages without `.dc` (e.g. `sit-check.html`) are plain test sheets.

## The screens

| Page | What it is |
|---|---|
| **Main Menu.dc.html** | NEW home screen (landscape 852x393). The player's creature stands in front of their real house. The scene shows each room locked or open and the tree state, matching the house map. Tabs: MY HOUSE, CREATURES, SHOP, GAMES. PLAY opens the full-screen Mini Games page. MY HOUSE (or an open room, or the level badge) plays the "walk home" animation into the real house. Code: `main-menu.js`, `main-menu-scene.js`. |
| **Squad House v6.dc.html** | The house (landscape 852x393): rooms, renovation catalog, creatures walking, sitting, sleeping, bathing and playing. Prop `bare` hides the test bar and phone frame for embedding (the Main Menu uses it). |
| **All Creatures Animations.dc.html** | Every creature in every animation, grouped by family, plus the card list. The best page for checking characters. |
| **Yard Mini Games.dc.html** | 7 yard games (Hoop Shot, Penalty Kick, Hopscotch, Bounce Up, Slide & Splash, Cornhole, Ping-Pong). Portrait 360x640 stage. Engine `yard-games.js` + `yg-*.js`. |
| **Shop Screen v5**, **Chest Smash v2**, **Squad Select v2**, **Squad Lobby v2**, **Squad Intro** | Shop + chests, chest opening, creature picker, the older portrait lobby, first-run intro. |
| **Squish Squad App v4.dc.html** | The app shell (portrait, bottom nav). It still opens the portrait lobby, not the new Main Menu (see Known gaps). |
| **ASMR Creature Squash v5.dc.html** | The original squish game screen (three.js). |
| **Renovation Catalog.dc.html** | Dev view of every furniture / room piece. |
| **Map Locked Styles.dc.html** | Locked / unlocked room styles for the house map. |

Older versions (Squad House v2-v5, Shop v3/v4, App v3, Chest Smash, Group Chest Art...) are kept for reference. Build on the pages in the table.

## Main engines (all `window.*` globals, plain JS)

- **Roster + save:** `squad-store.js` → `window.SquishSquad` (`ROSTER` = every creature `{id, key, name, set, rar}`, `src(i)` = card art, `ownedIds()`), `window.SquishProfile` (level etc., defined in `daily-challenges.js`), `squish-currency.js`. Rarity `rar`: 0 common, 1 rare, 2 epic, 3 legendary, 4 rainbow.
- **Creatures (rigs):** `rive-rig.js` (`RiveRig.mount(el, key, opts)`: shared soft-body rig, states, springs, poke/squeeze), `rive-generic.js` (rigs generated from each creature's front art), `plush-rig25.js`, `pet-defs.js` / `pet2-defs.js` (Pet Shop built-in rigs on Mittens' skeleton), `snack-3d.js`, `fruit-3d.js`, family personality files `*-anims.js`, `mittens-moves.js`, `creatures-v2.js` (roster art).
- **House life:** `house-moves.js` + `house-*-c.js` (per-creature tables: sit, lounge, TV, bed, water, play, kitchen...), `house-walk.js` (gaits), `house-idle.js` (fidgets), `house-cx.js` (batch 7: ball, bowl, games...).
- **House drawing:** `house4.js` (3D furniture engine), `house4-rooms.js`, `house4-cat*.js`, `reno-draw.js` + `reno-plus*.js` (renovation pieces, room by room), `beach.js` + `beach-items.js`, `movies*.js` (Movie Room cartoons).
- **Cards:** `export/cards4/cards4.js` (`SQ_CARD4.of(creature)` gives the frame, background and name for a card, and the layer boxes in `L`), `names.js` (each creature's name image), `frame-<rarity>.webp`. Tools in `tools/cards/` (see its README).
- **Chests:** `chest-models.js` + `chest-<group>.js`, `chest-loot.js`, `chest-sfx.js`.
- **Main Menu:** `main-menu.js` (`MainMenu.mount(el, {onPlay, onHome, onShop, ...})`: HUD, games page, walk-home trip), `main-menu-scene.js` (`MainMenuScene.svg(...)`: the house exterior, rooms, trees, seasons, door).

Art: `export/tripo/<key>/<key>-front.svg` is each creature's picture. The back, left and right views (svg/jpg) are reference art for rig work. `export/thumbs/` has small card thumbs. `export/creature-sounds/` has the squish sounds.

## Latest work (Nov 13), what's new

- **Main Menu v3:** its own CSS/SVG style, with no image crops. Velvet plaques with gold rims, jewel buttons, a winged level badge, and gradient + outline lettering via `ft()`. The creature is 0.44 x the frame height. PLAY / GAMES opens the full-screen games page, and yard games play inside it (still portrait in the middle). The walk-home trip: the creature turns and walks to the door, the door opens, and the camera flies in. Then the page fades in the real `Squad House v6` with `bare` (first open is slow: ~78 house scripts load). Back reverses it.
- **Cards v6:** your 5 card frames (common / rare / epic / legendary / rainbow) were reshaped: a shorter name board and a taller picture window, with the card size unchanged. Creatures show ~20-40 % bigger. Every name was re-made to fit its board. Details: grep "CARDS v6" in `docs/HISTORY.md`.
- **Rarity changes:** Berri, Kiwi and Clemmy are legendary.
- **Duchess tail:** fixed like Mittens' (`pet-defs.js` tail3, `rive-rig.js`).

## Creature review rules (from the user's feedback; apply to every creature, in every animation)

1. Match the creature's original picture: paws, ears, patches and props sit where they do in the source art.
2. Shapes look round and 3D, with shading (highlight top-left, darker edges). Nothing looks like a flat cutout.
3. Ears, patches, babies and props stay attached to the body. When the body turns, spins or leans they move with it, and they hide when they go behind it.
4. Second characters (babies, pets, sidekicks) move on their own all the time: breathing, head tilt, blinking, ears. Motion is smooth, never jittery or sliding.
5. Faces match the animation: dancing = happy eyes and an open smile, including on the baby/sidekick.
6. Don't break other creatures: rig code is shared, so new behaviour must be scoped to the creature that needs it.
7. The whole creature is rounded/3D, so spins and turns never look flat.
8. In motion, every body part moves with the body. Nothing stays frozen in place.
9. Special parts are alive: Lumi's lantern swings and glows, Nimbo drizzles while moving, Bubbly shimmers as it turns, Breeze's kite tail trails, Zappi's sparks crackle, Aurora shifts colour, Dusty's wings flutter.

How the user likes to work: fix first, then show (screenshots / short videos). Work in batches of 3 creatures. Never draw real brands or known characters. Use natural animations and a cute plush style.

## Testing

Playwright with Chromium is the usual check. Serve the folder, open a page, wait ~6-8 s (the house ~30 s), collect `pageerror`s and 404s, and take screenshots. Useful hooks: `window.__sh` (Squad House instance: `enterRoom('living')`, `findItem(id)`), `SquishProfile.set({level})`, `RiveRig.HS` (house states). The `*-check.html` pages are frame-by-frame test sheets for animations (`stripM(...)` helpers inside).

## Known gaps

- The app shell (`Squish Squad App v4`) still starts on the portrait lobby. The new landscape Main Menu is its own page and isn't wired in as the first screen yet.
- Yard games are portrait (360x640), shown in the middle of the landscape games page. The next step is landscape versions.
- The first walk into the house is slow (dc-import loads the house scripts on demand). It could preload them while the menu is idle.
- `ASMR Creature Squash v5` embeds a `Creature Plush` page that doesn't exist (it was never in the project). That part shows nothing.
- Tap-to-poke on a creature is commented out in `rive-rig.js`. Hold-to-squeeze and drag-to-spin work.
- Waffles' base rig is broken (see `docs/HISTORY.md`, "Waffles"). The Spooky Squish family has no 3D rebuild yet. More in `docs/What's Left.md`.
- Open question: whether Bean / Poppy / Blueby's duplicate rarity tiers should change.
