// Squad House v4 extra catalog, part 2: wall items, bookshelves, tabletop pieces + registers every new piece (cat2 + cat3) by level and room.
(function boot() {
  const X = window.House3D; if (!(X && X.A2 && X.ITEMS && X.bandOf && X.pal)) { setTimeout(boot, 20); return; } if (X.EXT) return;
  const K = X.K, H2 = X.H2, { solid, box, cyl, ball, slab, disc, prism, prismZ, shade, mix } = K;
  const { NE, GOLD, CH, CR, WH, DK, TIN, OLD, INK, LEAF, LEAF2, RB6, MT, starP, jewel, spr, drips } = H2;
  const PI = Math.PI, GL = '#cfeaf5';
  // flat layers for wall art: layer n sits n*0.5 in front of the wall plate, zb keeps the stacking order
  const zr = n => [[n * 0.5 - 0.25, 0], [n * 0.5 + 0.25, 0]];
  const P_ = (x, y, w, h, n, col, o = {}) => slab(x, y, n * 0.5, w, h, 0.5, col, Object.assign({ r: 2, zb: n * 140 }, o));
  const D_ = (x, y, r, n, col, o = {}) => disc(x, y, n * 0.5 - 0.25, r, 0.5, col, Object.assign({ zb: n * 140 }, o));
  const E_ = (x, y, a, b, n, col, o = {}) => solid(Object.assign({ ax: 'z', sh: 'el', c: [x, y], a, b, n: 20, rings: zr(n), col, zb: n * 140 }, o));
  const T_ = (pts, n, col, o = {}) => prismZ(n * 0.5 - 0.25, n * 0.5 + 0.25, pts, col, Object.assign({ zb: n * 140 }, o));
  const A_ = (x, y, r, th, a0, a1, n, col) => solid({ ax: 'z', sh: 'arc', c: [x, y], a: r, b: r, th, a0, a1, n: 18, rings: zr(n), col, zb: n * 140 });
  const star = (x, y, R, n, col) => T_(starP(5, R, R * 0.45, 1, PI / 2).map(([a, b]) => [x + a, y + b]), n, col);
  const bar = (x0, y0, x1, y1, t, n, col, o) => { const dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy) || 1, nx = -dy / L * t / 2, ny = dx / L * t / 2; return T_([[x0 + nx, y0 + ny], [x1 + nx, y1 + ny], [x1 - nx, y1 - ny], [x0 - nx, y0 - ny]], n, col, o); };
  const rnd = s => { let v = s; return () => (v = (v * 9301 + 49297) % 233280) / 233280; };
  const FC = (k, P) => k === 'junk' ? OLD : k === 'cot' ? P.w : k === 'retro' ? CH : k === 'mod' ? DK : k === 'candy' ? P.b : GOLD;

  // ---------- frames (wall plate behind z 0, paper on layer 1) ----------
  const frame = (k, P, W, H, y0 = 0) => { const o = [], fc = FC(k, P);
    if (k === 'junk') { o.push(slab(0, y0, -1, W, H, 2, '#f3ead2', { r: 1 }), ...[[-1, 1], [1, 1], [-1, -1], [1, -1]].map(([a, b]) => P_(a * (W / 2 - 4), y0 + (b > 0 ? H - 7 : -1), 12, 8, 9, '#f6e7a8', { r: 1 }))); return o; }
    const t = k === 'cot' || k === 'royal' ? 5 : 3;
    o.push(slab(0, y0 - t, -2, W + t * 2, H + t * 2, 4, fc, { r: k === 'retro' ? 8 : k === 'candy' ? 10 : 2 }));
    if (k === 'mod') o.push(P_(0, y0, W, H, 0.6, WH, { r: 0 }));
    if (k === 'candy') { const n = Math.round((W + H) / 7); for (let i = 0; i < n; i++) { const u = i / n, p = u * 2 * (W + H), x = p < W ? -W / 2 + p : p < W + H ? W / 2 : p < 2 * W + H ? W / 2 - (p - W - H) : -W / 2, y = p < W ? y0 - t : p < W + H ? y0 - t + (p - W) : p < 2 * W + H ? y0 + H + t : y0 + H + t - (p - 2 * W - H); o.push(ball(x, y - 3, 1, 3.4, NE[i % 6], { k: 3, n: 8, zb: 1400 })); } }
    if (k === 'royal') o.push(...[[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([a, b]) => ball(a * (W / 2 + 2), y0 + (b > 0 ? H + 2 : -2) - 3, 1, 4, GOLD, { zb: 1400 })), ball(0, y0 + H + 4, 1, 4.5, '#7a1e2c', { zb: 1500 }));
    return o; };
  // poster art in a W x H box starting at y0 (layers 1..8)
  const art = (v, P, W, H, y0) => { const o = [], cx = 0, Y = f => y0 + H * f, X_ = f => W * f;
    if (v === 'pal') { o.push(P_(0, y0, W, H, 1, P.aL), D_(X_(-0.22), Y(0.62), W * 0.11, 2, P.b), D_(X_(0.22), Y(0.62), W * 0.11, 2, P.b), D_(0, Y(0.44), W * 0.32, 3, P.b), D_(X_(-0.11), Y(0.48), 2.6, 4, INK), D_(X_(0.11), Y(0.48), 2.6, 4, INK), D_(X_(-0.1), Y(0.5), 0.9, 5, WH), D_(X_(0.12), Y(0.5), 0.9, 5, WH), D_(X_(-0.2), Y(0.4), 3, 4, '#ffa36a'), D_(X_(0.2), Y(0.4), 3, 4, '#ffa36a'), A_(0, Y(0.42), 4, 1.4, PI * 1.15, PI * 1.85, 4, INK), P_(0, Y(0.06), W * 0.7, H * 0.1, 2, P.a)); return o; }
    if (v === 'stars') { o.push(P_(0, y0, W, H, 1, '#2b3a6a'), D_(X_(0.22), Y(0.76), W * 0.15, 2, '#ffe9a8'), D_(X_(0.29), Y(0.8), W * 0.13, 3, '#2b3a6a'));
      [[-0.25, 0.7, 5], [-0.05, 0.5, 3.5], [0.2, 0.36, 4.5], [-0.28, 0.24, 3], [0.02, 0.16, 2.6], [0.3, 0.12, 2.6]].forEach(([a, b, r]) => o.push(star(X_(a), Y(b), r, 2, '#ffd23f')));
      o.push(P_(0, y0, W, H * 0.12, 2, '#3e5a3a', { r: 0 })); return o; }
    if (v === 'rainbow') { o.push(P_(0, y0, W, H, 1, CR)); RB6.forEach((c, i) => o.push(A_(0, Y(0.34), W * 0.42 - i * 3.2, 3.2, 0, PI, 2, c))); [-1, 1].forEach(s => o.push(D_(s * W * 0.32, Y(0.32), 5, 3, WH), D_(s * W * 0.22, Y(0.3), 4, 3, WH))); return o; }
    if (v === 'music') { o.push(P_(0, y0, W, H, 1, '#3b2e5a'), D_(X_(-0.08), Y(0.42), W * 0.13, 2, '#ffd23f'), P_(X_(0.03), Y(0.42), 3, H * 0.4, 2, '#ffd23f', { r: 1 }), T_([[X_(0.03), Y(0.82)], [X_(0.25), Y(0.72)], [X_(0.25), Y(0.64)], [X_(0.03), Y(0.72)]], 2, '#ffd23f'), star(X_(-0.3), Y(0.82), 3.4, 2, '#4fe0d0'), star(X_(0.3), Y(0.36), 2.8, 2, '#ff9d4a'));
      [0, 1, 2].forEach(i => o.push(P_(0, Y(0.08) + i * 4, W * (0.7 - i * 0.15), 2.4, 2, NE[i * 2], { r: 1 }))); return o; }
    if (v === 'sunset') { ['#ffcf6a', '#ffa94a', '#ff8a5a'].forEach((c, i) => o.push(P_(0, y0 + H * (0.45 + i * 0.18), W, H * (0.55 - i * 0.18), 1 + i * 0.3, c, { r: 1 }))); o.push(D_(0, Y(0.48), W * 0.2, 2.2, '#fff1a0'), P_(0, y0, W, H * 0.46, 3, '#4a8ad6', { r: 1 }), P_(0, Y(0.3), W * 0.6, 1.6, 4, '#9fd0ff'), P_(X_(-0.1), Y(0.18), W * 0.4, 1.6, 4, '#9fd0ff')); return o; }
    if (v === 'fruit') { o.push(P_(0, y0, W, H, 1, CR), D_(X_(-0.16), Y(0.62), W * 0.17, 2, '#ffa940'), T_([[X_(-0.16), Y(0.75)], [X_(-0.02), Y(0.83)], [X_(-0.1), Y(0.74)]], 3, LEAF), D_(X_(0.16), Y(0.36), W * 0.17, 2, '#e2554a'), P_(X_(0.16), Y(0.46), 1.6, 6, 3, '#8a5a34'), D_(X_(-0.18), Y(0.26), W * 0.12, 2, '#a6d65a'), D_(X_(-0.18), Y(0.35), W * 0.08, 2, '#a6d65a')); return o; }
    if (v === 'movie') { o.push(P_(0, y0, W, H, 1, INK)); for (let i = 0; i < 7; i++) [-1, 1].forEach(s => o.push(P_(s * (W / 2 - 4), y0 + 4 + i * (H - 10) / 6, 4, 3, 2, WH, { r: 0.5 }))); o.push(P_(0, Y(0.22), W - 18, H * 0.62, 2, '#ffa940'), D_(0, Y(0.44), W * 0.17, 3, INK), D_(X_(-0.12), Y(0.6), W * 0.07, 3, INK), D_(X_(0.12), Y(0.6), W * 0.07, 3, INK), P_(0, Y(0.06), W * 0.56, H * 0.08, 2, '#ffd23f')); return o; }
    if (v === 'map') { o.push(P_(0, y0, W, H, 1, '#f1e3c0'), D_(X_(-0.18), Y(0.66), W * 0.18, 2, '#9fc684'), D_(X_(0.2), Y(0.3), W * 0.16, 2, '#9fc684')); for (let i = 0; i < 5; i++) { const u = i / 4; o.push(P_(X_(-0.12 + u * 0.3), Y(0.56 - u * 0.24), 3.4, 1.6, 3, '#b8714a', { r: 0.5 })); }
      o.push(bar(X_(0.14), Y(0.24), X_(0.26), Y(0.36), 2.4, 4, '#e2554a'), bar(X_(0.14), Y(0.36), X_(0.26), Y(0.24), 2.4, 4, '#e2554a'), star(X_(-0.3), Y(0.16), 4, 3, '#4a6fd6')); return o; }
    return [P_(0, y0, W, H, 1, P.aL)]; };
  const poster = S => { const k = S.k, W = 62, Hh = 82; return { w: 76, d: 8, mount: 'wall', elev: 36, build: P => [...frame(k, P, W, Hh, 6), ...art(S.v, P, W, Hh, 6)] }; };
  const gallery = S => ({ w: 110, d: 8, mount: 'wall', elev: 44, build: P => { const k = S.k, o = [];
    [[-36, 12, 26, 32, 'sun'], [2, 4, 34, 44, 'pal'], [38, 18, 24, 28, 'heart']].forEach(([x, y, w, h, v]) => { const fr = frame(k, P, w, h, y); fr.forEach(s => { const U = new Set(s.pts); s.faces.forEach(F => F.q.forEach(p => U.add(p))); U.forEach(p => p[0] += x); }); o.push(...fr);
      if (v === 'sun') o.push(P_(x, y, w, h, 1, '#bfe4ff'), D_(x, y + h * 0.6, w * 0.2, 2, '#ffd23f'), P_(x, y, w, h * 0.3, 2, LEAF2, { r: 1 }));
      else if (v === 'pal') o.push(P_(x, y, w, h, 1, P.aL), D_(x, y + h * 0.42, w * 0.3, 2, P.b), D_(x - 4, y + h * 0.46, 1.8, 3, INK), D_(x + 4, y + h * 0.46, 1.8, 3, INK), A_(x, y + h * 0.4, 3, 1.1, PI * 1.15, PI * 1.85, 3, INK));
      else o.push(P_(x, y, w, h, 1, CR), D_(x - 3.6, y + h * 0.56, 4.4, 2, '#e2554a'), D_(x + 3.6, y + h * 0.56, 4.4, 2, '#e2554a'), T_([[x - 8, y + h * 0.53], [x + 8, y + h * 0.53], [x, y + h * 0.26]], 2, '#e2554a')); });
    return o; } });

  // ---------- clocks (hands turn: anim clock) ----------
  const handsAt = (cy, R, z) => [bar(0, cy, 0, cy + R * 0.5, 2.6, z, INK, { part: 1 }), bar(0, cy, R * 0.62, cy + R * 0.36, 1.8, z + 1, INK, { part: 1 }), D_(0, cy, 2.2, z + 2, '#e2554a', { part: 1 })];
  const wallClock = S => { const k = S.k, cy = k === 'cot' ? 60 : 26, R = k === 'cot' ? 13 : 22;
    return { w: k === 'retro' || k === 'royal' ? 76 : 54, d: 8, mount: 'wall', elev: k === 'cot' ? 16 : 64, anim: 'clock', pivot: [0, cy, 4], build: P => { const o = [];
      if (k === 'cot') { o.push(prismZ(-4, 0, [[-24, 36], [24, 36], [24, 72], [0, 92], [-24, 72]], P.w), T_([[-28, 70], [0, 96], [0, 90], [-24, 68]], 1, P.b), T_([[28, 70], [0, 96], [0, 90], [24, 68]], 1, P.b), P_(0, 76, 10, 9, 1, shade(P.w, 0.7), { r: 1 }), D_(0, 82, 2.6, 2, '#ffd23f'));
        [[-8, 8], [8, 14]].forEach(([x, y]) => o.push(P_(x, y, 1.2, 36 - y, 0.5, '#8a8f94', { r: 0 }), E_(x, y, 3.4, 6, 1, '#8a5a34')));
        for (let i = 0; i < 4; i++) [-1, 1].forEach(s => o.push(T_([[s * 22, 40 + i * 6], [s * 28, 43 + i * 6], [s * 22, 46 + i * 6]], 1, LEAF2)));
        o.push(D_(0, cy, R, 1, CR)); }
      else if (k === 'retro' || k === 'royal') { const rc = k === 'royal' ? GOLD : CH; for (let i = 0; i < 12; i++) { const a = i / 12 * PI * 2, L = i % 2 ? 30 : 36; o.push(bar(Math.cos(a) * 12, cy + Math.sin(a) * 12, Math.cos(a) * L, cy + Math.sin(a) * L, 3, 0, rc), ball(Math.cos(a) * L, cy + Math.sin(a) * L - 3, 0, 3, i % 2 ? rc : k === 'royal' ? '#7a1e2c' : '#e2554a', { k: 3, n: 8, zb: 100 })); }
        o.push(disc(0, cy, -4, 17, 4, rc), D_(0, cy, 14, 1, k === 'royal' ? '#f4f1ea' : '#5cc8c0')); }
      else { const rim = k === 'junk' ? TIN : k === 'mod' ? DK : '#c98d52'; o.push(disc(0, cy, -4, R, 4, rim), D_(0, cy, R - 3, 1, k === 'candy' ? '#d9a066' : k === 'mod' ? WH : '#f3ead2'));
        if (k === 'candy') { o.push(A_(0, cy, R - 2, 3.4, 0, PI * 2, 2, P.a)); [[-8, 6], [9, 4], [-4, -9], [8, -8], [-11, -3]].forEach(([x, y]) => o.push(D_(x, cy + y, 1.8, 2, '#6b3f22'))); o.push(...spr(0, cy + R, 1, R, 1, 5)); }
        if (k === 'junk') o.push(bar(-10, cy + 14, -2, cy + 4, 0.8, 2, '#8a8f94'), ball(0, cy + R - 2, 0, 3, TIN, { k: 3, n: 8 })); }
      for (let i = 0; i < 12; i++) { const a = i / 12 * PI * 2, rr = (k === 'retro' || k === 'royal' ? 11 : R - 6.5); o.push(k === 'mod' && i % 3 ? null : D_(Math.cos(a) * rr, cy + Math.sin(a) * rr, i % 3 ? 0.9 : 1.5, 2, INK)); }
      o.push(...handsAt(cy, k === 'retro' || k === 'royal' ? 14 : R - 3, 3)); return o.filter(Boolean); } }; };

  // ---------- wall shelf (host: small pieces sit on it) ----------
  const wallShelf = S => ({ w: 98, d: 26, mount: 'wall', elev: 46, top: 19, build: P => { const k = S.k, c = k === 'junk' ? OLD : k === 'cot' ? P.w : k === 'retro' ? CH : k === 'mod' ? '#e0bb86' : k === 'candy' ? P.a : '#f4f1ea', o = [];
    if (k === 'candy') { for (let i = 0; i < 6; i++) o.push(ball(-40 + i * 16, 8 + (i % 2) * 2, 0, 10, i % 2 ? WH : P.aL, { sy: 0.6, k: 4, n: 12 })); o.push(box(0, 14, 0, 96, 5, 24, WH, { r: 8 })); return o; }
    o.push(box(0, 14, 0, 94, k === 'mod' ? 6 : 5, 24, c, { r: k === 'retro' ? 6 : 2, bev: 1 }));
    if (k !== 'mod') [-34, 34].forEach(x => o.push(prism(x - 1.6, x + 1.6, [[-12, 14], [8, 14], [-12, k === 'royal' ? -4 : 0]], k === 'royal' ? GOLD : k === 'retro' ? CH : k === 'junk' ? '#8a8f94' : shade(c, 0.8))));
    if (k === 'royal') o.push(box(0, 13, 0, 98, 2, 26, GOLD, { r: 3 }), jewel(0, 15, 12, 2.6));
    if (k === 'cot') for (let i = 0; i < 9; i++) o.push(D_(-40 + i * 10, 11.5, 2.6, 12 * 2 + 1, shade(c, 0.9)));
    return o; } });

  // ---------- mirrors ----------
  const glass = (o, x, y, a, b, n) => { o.push(E_(x, y, a, b, n, GL, { emit: 1 }), bar(x - a * 0.5, y - b * 0.1, x - a * 0.05, y + b * 0.55, Math.max(2, a * 0.14), n + 1, WH), bar(x - a * 0.15, y - b * 0.35, x + a * 0.18, y + b * 0.2, Math.max(1.2, a * 0.07), n + 1, WH)); return o; };
  const mirror = S => { const k = S.k; return { w: k === 'retro' ? 80 : 60, d: 8, mount: 'wall', elev: k === 'mod' ? 16 : 36, build: P => { const o = [];
    if (k === 'junk') { o.push(disc(0, 26, -4, 24, 4, TIN)); glass(o, 0, 26, 21, 21, 1); o.push(bar(-6, 40, 4, 22, 0.9, 3, '#7a8a94'), bar(4, 22, -2, 12, 0.9, 3, '#7a8a94'), P_(14, 38, 12, 4, 4, '#f6e7a8', { r: 1 })); return o; }
    if (k === 'cot') { o.push(solid({ ax: 'z', sh: 'el', c: [0, 32], a: 24, b: 32, n: 22, rings: [[-4, 0], [0, 0]], col: P.w })); glass(o, 0, 32, 19, 27, 1); o.push(D_(0, 66, 3.4, 2, P.b)); return o; }
    if (k === 'retro') { o.push(slab(0, 0, -2, 76, 64, 4, CH, { r: 12 }), P_(0, 6, 60, 52, 1, GL, { r: 8, emit: 1 }), bar(-20, 14, -6, 48, 5, 2, WH), bar(-6, 16, 2, 34, 2.4, 2, WH)); for (let i = 0; i < 12; i++) { const p = i / 12, x = p < 0.25 ? -34 : p < 0.5 ? -30 + (p - 0.25) * 4 * 60 : p < 0.75 ? 34 : 30 - (p - 0.75) * 4 * 60, y = p < 0.25 ? 6 + p * 4 * 52 : p < 0.5 ? 60 : p < 0.75 ? 60 - (p - 0.5) * 4 * 52 : 3; o.push(ball(x, y - 3, 1, 3.2, '#fff3c4', { emit: 1, k: 3, n: 8, zb: 600 })); } return o; }
    if (k === 'mod') { o.push(slab(0, 0, -2, 46, 96, 4, DK, { r: 22 }), P_(0, 3, 40, 90, 1, GL, { r: 19, emit: 1 }), bar(-12, 16, 0, 70, 4, 2, WH), bar(-2, 30, 6, 52, 2, 2, WH)); return o; }
    if (k === 'candy') { for (let i = 0; i < 10; i++) { const a = i / 10 * PI * 2; o.push(ball(Math.cos(a) * 24, 30 + Math.sin(a) * 24 - 8, -1, 9, i % 2 ? WH : P.aL, { k: 4, n: 12 })); } glass(o, 0, 30, 20, 20, 3); return o; }
    o.push(solid({ ax: 'z', sh: 'el', c: [0, 32], a: 26, b: 34, n: 22, rings: [[-4, 0], [0, 0]], col: GOLD })); glass(o, 0, 32, 20, 28, 1);
    o.push(T_([[-12, 64], [-12, 76], [-6, 70], [0, 80], [6, 70], [12, 76], [12, 64]], 2, GOLD), D_(0, 72, 2.6, 3, '#7a1e2c'), D_(-26, 32, 3, 2, '#7a1e2c'), D_(26, 32, 3, 2, '#7a1e2c')); return o; } }; };

  // ---------- bookshelves ----------
  const BC = ['#e2554a', '#4a6fd6', '#ffd23f', '#7fc66a', '#8f7bff', '#ffa940', '#5cc8c0', '#f4f1ea'];
  const books = (o, x0, x1, y, z, hMax, r, cols) => { let x = x0; while (x < x1 - 4) { const w = 4 + Math.floor(r() * 5), h = hMax * (0.72 + r() * 0.28); if (x + w > x1) break; if (r() < 0.12 && x + 12 < x1) { o.push(box(x + 6, y, z, 12, 5, h * 0.7, cols[Math.floor(r() * cols.length)], { r: 1 })); x += 14; continue; } o.push(box(x + w / 2, y, z, w, h, 18, cols[Math.floor(r() * cols.length)], { r: 1 })); x += w + 0.6; } };
  const bookcase = S => { const k = S.k, Hh = k === 'royal' ? 166 : k === 'mod' ? 132 : 150, W = k === 'mod' ? 120 : 96;
    return { w: W + 8, d: 36, top: Hh + 1, build: P => { const c = k === 'junk' ? OLD : k === 'cot' ? P.w : k === 'retro' ? P.a : k === 'mod' ? '#e0bb86' : k === 'candy' ? P.a : '#f4f1ea', r = rnd(7 + Hh), cols = k === 'candy' ? NE.concat([WH]) : k === 'royal' ? ['#7a1e2c', '#1f5a44', '#4b2763', GOLD, '#f3ead6'] : BC, o = [];
      if (k === 'mod') { o.push(box(0, 0, -15, W, Hh, 4, shade(c, 0.88))); for (let i = 0; i <= 3; i++) o.push(box(0, i * (Hh - 4) / 3, 0, W, 4, 32, c, { r: 1 }), box(-W / 2 + 2 + i * (W - 4) / 3, 0, 0, 4, Hh, 32, c));
        [[0, 0], [2, 1], [1, 2]].forEach(([a, b]) => books(o, -W / 2 + 6 + a * (W - 4) / 3, -W / 2 + (a + 1) * (W - 4) / 3, 4 + b * (Hh - 4) / 3, 2, 30, r, ['#c46a4a', '#d9d5cd', '#2c2d31', WH, '#8e9a84']));
        o.push(ball(-W / 2 + 2 + (W - 4) / 6, 4 + (Hh - 4) / 3, 0, 9, '#d8d4cc', { sy: 1 }), ball(-W / 2 + 2 + (W - 4) / 6, 20 + (Hh - 4) / 3, 0, 9, LEAF, { sy: 0.8 }), ball(W / 2 - (W - 4) / 6, 4, 0, 10, '#e8b04a', { sy: 0.9 })); return o; }
      o.push(box(0, 0, -15, W, Hh, 4, shade(c, 0.85)), box(-W / 2 - 2, 0, 0, 6, Hh, 34, c, { r: 1 }), box(W / 2 + 2, 0, 0, 6, Hh, 34, c, { r: 1 }), box(0, Hh - 5, 0, W + 10, 6, 36, c, { r: 2, bev: 1 }), box(0, 0, 0, W + 8, 8, 34, shade(c, 0.9), { r: 1 }));
      const n = 4, gap = (Hh - 13) / n; for (let i = 0; i < n; i++) { const y = 8 + i * gap; if (i) o.push(box(0, y - 3, 0, W, 3, 32, c)); books(o, -W / 2 + 2, W / 2 - 2, y, 2, gap - 8, r, cols); }
      if (k === 'junk') o.push(box(-20, Hh + 1, 2, 14, 10, 1, '#c9a85a', { r: 1 }));
      if (k === 'cot') for (let i = 0; i < 7; i++) o.push(D_(-W / 2 + 8 + i * (W - 16) / 6, Hh - 9, 3, 37, shade(c, 0.92)));
      if (k === 'retro') o.push(box(0, Hh, 0, W + 12, 3, 38, CH, { r: 4 }));
      if (k === 'candy') o.push(...drips(0, Hh, 18, W, P.b, 6), ...spr(0, Hh + 1, 0, W - 10, 26, 7));
      if (k === 'royal') o.push(prismZ(-4, 4, [[-30, Hh], [-20, Hh + 14], [-8, Hh + 6], [0, Hh + 20], [8, Hh + 6], [20, Hh + 14], [30, Hh]], GOLD), jewel(0, Hh + 20, 0, 4), box(0, Hh - 6, 0, W + 12, 2, 38, GOLD, { r: 2 }));
      return o; } }; };
  const lowShelf = S => ({ w: 128, d: 40, top: 56, build: P => { const k = S.k, c = k === 'cot' ? P.w : k === 'mod' ? '#e9e5dc' : k === 'candy' ? WH : P.w, o = [box(0, 0, 0, 124, 56, 38, c, { r: 4, bev: 2 })];
    for (let i = 0; i < 4; i++) for (let j = 0; j < 2; j++) { const x = -45 + i * 30, y = 5 + j * 25; o.push(box(x, y, 17.4, 26, 21, 1, shade(c, 0.72), { r: 2 }));
      if ((i + j) % 2) o.push(box(x, y, 14.4, 24, 16, 9, k === 'candy' ? NE[(i + j * 4) % 6] : [P.a, P.b, '#7fc66a', '#ffa940'][(i + j) % 4], { r: 3 }), box(x, y + 10, 19.2, 10, 3, 0.6, WH, { r: 1 }));
      else o.push(ball(x - 4, y, 12, 6, NE[(i * 2 + j) % 6], { k: 4, n: 10 }), box(x + 6, y, 12, 8, 8, 8, RB6[(i + j * 3) % 6], { r: 1 })); }
    if (k === 'candy') o.push(...drips(0, 56, 19, 110, P.a, 7)); return o; } });

  // ---------- tabletop pieces (small: sit on tables, counters, shelves) ----------
  const T = (w, d, b, o = {}) => Object.assign({ w, d, small: 1, round: 1, build: b }, o);
  const vaseFlw = (o, y, cols) => [[-5, 12, 2], [5, 14, -2], [0, 18, 3]].forEach(([x, h, z], i) => o.push(cyl(x * 0.4, y, z * 0.4, 0.9, h, '#4a8a46', { n: 4 }), ball(x, y + h, z, 4, cols[i % cols.length], { k: 3, n: 8 }), ball(x, y + h + 1, z + 2, 1.6, '#ffd23f', { k: 3, n: 6 })));
  const tbVase = S => T(26, 26, P => { const k = S.k, o = [cyl(0, 0, 0, 8, 22, k === 'royal' ? '#f4f1ea' : P.a, { n: 14, rg: [[0, 0, 0.7], [8, 0, 1], [18, 0, 0.5], [22, 0, 0.7]] })]; if (k === 'royal') o.push(cyl(0, 10, 0, 8.2, 3, '#7a1e2c', { n: 14 }), cyl(0, 20, 0, 4.4, 2, GOLD, { n: 12 })); vaseFlw(o, 20, k === 'royal' ? ['#7a1e2c', WH, '#e2b14a'] : [P.b, '#ffa940', '#e2554a']); return o; });
  const tbBooks = S => T(32, 24, P => { const c = S.k === 'royal' ? ['#7a2a3a', '#2f6a4a', '#7a1e2c'] : [P.a, P.b, '#ffa940']; return [box(0, 0, 0, 28, 5, 20, c[0], { r: 1 }), box(1, 5, 0, 26, 5, 19, c[1], { r: 1 }), box(-1, 10, 0, 24, 4, 18, c[2], { r: 1 }), ...(S.k === 'royal' ? [box(0, 0.5, 10.2, 22, 4, 0.4, GOLD), box(1, 5.5, 9.7, 20, 4, 0.4, GOLD)] : []), ball(4, 14, 2, 4, P.b, { sy: 0.6 })]; }, { round: 0 });
  const tbFruit = S => T(40, 40, P => { const k = S.k, o = [cyl(0, 0, 0, 7, 3, k === 'mod' ? '#d8eef4' : P.a, { n: 12 }), cyl(0, 3, 0, 18, 9, k === 'mod' ? '#d8eef4' : P.a, { n: 18, rg: [[0, 0, 0.45], [5, 0, 0.85], [9, 0, 1]] })];
    [[-7, 0, '#e2554a'], [6, -3, '#ffa940'], [0, 6, '#a6d65a'], [-2, -6, '#ffd23f']].forEach(([x, z, c]) => o.push(ball(x, 7, z, 6, c, { k: 4, n: 10 }))); o.push(ball(2, 13, 0, 4, '#8f7bff', { sy: 1.4, k: 4, n: 10 }), cyl(-7, 18, 0, 0.6, 3, '#6b4a2a', { n: 4 })); return o; });
  const tbCake = S => T(40, 40, P => { const k = S.k, o = [cyl(0, 0, 0, 5, 12, k === 'royal' ? GOLD : CR, { n: 10, rg: [[0, 0, 1.4], [6, 0, 0.6], [12, 0, 1]] }), cyl(0, 12, 0, 18, 2, k === 'royal' ? GOLD : CR, { n: 18 })];
    if (k === 'candy') { [[-8, 0], [8, 0], [0, 8], [0, -8]].forEach(([x, z], i) => o.push(cyl(x, 14, z, 5, 5, '#d9a066', { n: 10, rg: [[0, 0, 0.8], [5, 0, 1]] }), ball(x, 18, z, 5.5, NE[i], { sy: 0.8, k: 4, n: 10 }))); o.push(cyl(0, 22, 0, 5, 5, '#d9a066', { n: 10 }), ball(0, 26, 0, 6, NE[4], { sy: 0.8 }), ball(0, 32, 0, 2.4, '#e2554a', { k: 3, n: 8 })); return o; }
    o.push(cyl(0, 14, 0, 14, 10, '#f3d9a6', { n: 18 }), cyl(0, 22, 0, 14.4, 3, k === 'retro' ? '#e2554a' : P.b, { n: 18 }), ...drips(0, 24, 13, 20, k === 'retro' ? '#e2554a' : P.b, 4), cyl(0, 24, 0, 9, 7, '#f3d9a6', { n: 16 }), cyl(0, 30, 0, 9.4, 2, CR, { n: 16 }), ball(0, 32, 0, 2.6, '#e2554a', { k: 3, n: 8 }));
    if (k === 'royal') o.push(cyl(0, 12, 0, 18.4, 1.4, '#7a1e2c', { n: 18 }), jewel(0, 35, 0, 3));
    return o; });
  const tbTeapot = S => T(36, 26, P => { const k = S.k, c = k === 'royal' ? '#f4f1ea' : k === 'junk' ? '#b7c9c4' : P.a, o = [ball(0, 0, 0, 11, c, { sy: 0.85 }), prism(9, 18, [[-1.5, 6], [1.5, 6], [1, 16], [-1, 16]], c), solid({ ax: 'z', sh: 'arc', c: [-11, 9], a: 6, b: 6, th: 2, a0: PI * 0.5, a1: PI * 1.5, n: 10, rings: [[-1.2, 0], [1.2, 0]], col: c }), cyl(0, 17, 0, 5, 2, c, { n: 12 }), ball(0, 19, 0, 2.4, k === 'royal' ? GOLD : P.b, { k: 3, n: 8 })];
    if (k === 'royal') o.push(cyl(0, 7, 0, 10.4, 1.6, GOLD, { n: 16 })); if (k === 'junk') o.push(D_(4, 6, 2, 25, '#8a9a96')); if (k !== 'junk') o.push(cyl(14, 0, 8, 4, 5, c, { n: 10, rg: [[0, 0, 0.7], [5, 0, 1]] })); return o; }, { round: 0 });
  const tbToaster = S => T(34, 22, (P, v) => { const k = S.k, c = k === 'junk' ? TIN : k === 'retro' ? CH : P.a, o = [slab(0, 0, 0, 30, 20, 18, c, { r: 8 }), box(-5, 20, 0, 4, 0.6, 12, DK, { r: 1 }), box(5, 20, 0, 4, 0.6, 12, DK, { r: 1 }), box(15.4, 6, 0, 2, 8, 3, DK, { r: 1 }), ball(-14, 2, 9, 1.6, DK, { k: 3, n: 6 }), ball(14, 2, 9, 1.6, DK, { k: 3, n: 6 })];
    o.push(box(-5, 14, 0, 3, 10, 11, '#e0a65a', { r: 2 }), box(5, 16, 0, 3, 10, 11, '#d0904a', { r: 2 })); if (k === 'junk') o.push(D_(-6, 10, 2.4, 19, '#8a8f94')); return o; }, { round: 0 });
  const tbMixer = S => T(38, 26, P => { const c = S.k === 'mod' ? '#6a707c' : P.a; return [box(0, 0, 0, 34, 4, 22, c, { r: 5 }), box(-12, 4, 0, 10, 26, 14, c, { r: 4 }), ball(-2, 26, 0, 9, c, { sx: 2.1, sy: 0.7, sz: 0.9 }), cyl(8, 4, 0, 9, 14, CH, { n: 14, rg: [[0, 0, 0.6], [14, 0, 1]] }), cyl(8, 18, 0, 0.8, 8, CH, { n: 4 }), ball(-14, 30, 7, 1.6, CR, { k: 3, n: 6 })]; }, { round: 0 });
  const tbJar = S => T(28, 28, P => { const k = S.k, cand = k === 'candy', o = [cyl(0, 0, 0, 11, 22, k === 'junk' ? TIN : '#e6f6ff', { n: 16, zb: -500, emit: k === 'junk' ? 0 : 1, rg: [[0, 0, 0.9], [3, 0, 1], [20, 0, 1], [22, 0, 0.8]] })];
    if (k !== 'junk') for (let i = 0; i < 6; i++) o.push(cand ? ball(-5 + (i % 3) * 5, 3 + Math.floor(i / 3) * 7, 6, 3.4, NE[i], { k: 3, n: 8 }) : disc(-5 + (i % 3) * 5, 5 + Math.floor(i / 3) * 7, 9, 3.6, 1.4, '#d9a066'));
    o.push(cyl(0, 22, 0, 9, 4, k === 'junk' ? '#c9a85a' : P.b, { n: 14 }), ball(0, 26, 0, 3, k === 'junk' ? '#c9a85a' : P.b, { k: 3, n: 8 })); if (k === 'junk') o.push(box(0, 8, 11, 12, 8, 0.6, '#e2554a', { r: 1 })); return o; });
  const tbClock = S => T(28, 18, P => [ball(0, 6, 0, 10, P.a, { sz: 0.6 }), D_(0, 16, 7.4, 13, CR), D_(0, 16, 1.2, 15, INK), bar(0, 16, 0, 21, 1.2, 15, INK), bar(0, 16, 4, 16, 1, 15, INK), ball(-7, 23, 0, 4, P.b, { sy: 0.7 }), ball(7, 23, 0, 4, P.b, { sy: 0.7 }), box(-6, 0, 0, 2, 6, 2, DK, { yaw: 0.3 }), box(6, 0, 0, 2, 6, 2, DK)]);
  const tbRadio = S => T(36, 18, P => [slab(0, 0, 0, 34, 22, 14, P.a, { r: 9 }), D_(-7, 11, 6, 15, shade(P.a, 0.7)), D_(-7, 11, 4, 16, '#c9b48e'), P_(9, 13, 10, 5, 15, '#fff1a8', { emit: 1 }), D_(6, 6, 1.8, 16, CH), D_(12, 6, 1.8, 16, CH), cyl(12, 22, 0, 0.6, 14, CH, { n: 4 })], { round: 0 });
  const tbGlobe = S => T(28, 28, P => [cyl(0, 0, 0, 8, 3, S.k === 'royal' ? GOLD : '#c98d52', { n: 12 }), cyl(0, 3, 0, 1.4, 6, '#c98d52', { n: 6 }), ball(0, 8, 0, 11, '#5cc8f0'), ball(-4, 18, 7, 4, '#7fc66a', { sy: 0.5, k: 3, n: 8 }), ball(5, 12, 8, 3.4, '#7fc66a', { sy: 0.5, k: 3, n: 8 }), solid({ ax: 'z', sh: 'arc', c: [0, 19], a: 13, b: 13, th: 1.6, a0: PI * 0.6, a1: PI * 1.6, n: 12, rings: [[-0.8, 0], [0.8, 0]], col: S.k === 'royal' ? GOLD : CH })]);
  const tbSnow = S => T(26, 26, P => [cyl(0, 0, 0, 10, 7, P.b, { n: 14, rg: [[0, 0, 1], [7, 0, 0.8]] }), cyl(0, 7, 0, 7, 2, WH, { n: 12 }), cyl(0, 8, 0, 2, 3, '#8a5a34', { n: 6 }), cyl(0, 10, 0, 5, 10, LEAF, { n: 10, rg: [[0, 0, 1], [10, 0, 0], [10, 0, 0]] }), ball(0, 6, 0, 11, '#e8f6ff', { emit: 1, zb: -500 }), ...[[-4, 14], [3, 18], [5, 10], [-2, 22]].map(([x, y]) => D_(x, y, 1, 22, WH))]);
  const tbTrophy = S => T(26, 22, P => [box(0, 0, 0, 18, 6, 14, '#5a4030', { r: 2 }), cyl(0, 6, 0, 2, 8, GOLD, { n: 8 }), cyl(0, 14, 0, 10, 14, GOLD, { n: 14, rg: [[0, 0, 0.3], [6, 0, 0.8], [14, 0, 1]] }), solid({ ax: 'z', sh: 'arc', c: [-10, 22], a: 5, b: 5, th: 1.8, a0: PI * 0.5, a1: PI * 1.5, n: 8, rings: [[-1, 0], [1, 0]], col: GOLD }), solid({ ax: 'z', sh: 'arc', c: [10, 22], a: 5, b: 5, th: 1.8, a0: -PI * 0.5, a1: PI * 0.5, n: 8, rings: [[-1, 0], [1, 0]], col: GOLD }), star(0, 4, 3, 16, '#ffd23f')]);
  const tbCandles = S => T(32, 22, P => { const o = [box(0, 0, 0, 30, 3, 18, S.k === 'royal' ? GOLD : P.b, { r: 6 })]; [[-9, 16], [0, 24], [9, 12]].forEach(([x, h]) => o.push(cyl(x, 3, 0, 3.4, h, CR, { n: 10 }), ball(x, 3 + h + 1, 0, 2.4, '#ffb340', { sy: 1.7, emit: 1, k: 3, n: 8 }))); return o; }, { glow: () => ({ y: 30, r: 34 }), round: 0 });
  const tbBox = S => T(30, 22, P => [box(0, 0, 0, 28, 12, 18, S.k === 'royal' ? '#7a1e2c' : P.a, { r: 2 }), box(0, 12, 0, 29, 2, 19, GOLD, { r: 2 }), box(0, 4, 9.2, 4, 4, 0.6, GOLD, { r: 1 }), cyl(0, 14, 0, 0.8, 6, GOLD, { n: 4, part: 1 }), ball(0, 20, 0, 2.6, '#f4f1ea', { k: 3, n: 8, part: 1 }), cyl(0, 22, 0, 4, 3, '#cdb8f5', { n: 10, rg: [[0, 0, 1], [3, 0, 0.3]], part: 1 })], { round: 0 });
  const tbCup = S => T(22, 22, P => [cyl(0, 0, 0, 6, 12, P.a, { n: 12, rg: [[0, 0, 0.85], [12, 0, 1]] }), box(-2, 10, 0, 1.6, 14, 1.6, '#4fe0d0', { yaw: 0.2 }), box(-2.6, 24, 0, 2.6, 4, 2.4, WH, { r: 1 }), box(2, 10, 0, 1.6, 12, 1.6, '#ffa940', { yaw: -0.2 }), box(2.4, 22, 0, 2.6, 4, 2.4, WH, { r: 1 }), S.k === 'junk' ? D_(3, 5, 1.6, 13, shade(P.a, 0.8)) : null].filter(Boolean));
  const duck = (x, z, s, col) => [ball(x, 0, z, 6 * s, col, { sx: 1.25 }), ball(x + 3 * s, 8 * s, z, 4 * s, col), box(x + 7.4 * s, 9 * s, z, 3.6 * s, 1.6 * s, 2.6 * s, '#ff9d4a', { r: 0.8 }), D_(x + 4 * s, 11 * s, 0.8, Math.round(2 * (z + 4 * s) + 1.5), INK)];
  const tbDuck = S => T(40, 22, P => S.k === 'candy' ? [...duck(-12, -2, 1.1, NE[1]), ...duck(2, 2, 0.9, NE[4]), ...duck(14, -1, 0.75, NE[3])] : [...duck(-12, -2, 1.1, '#ffd23f'), ...duck(2, 2, 0.9, '#ffd23f'), ...duck(13, -1, 0.7, '#ffe680')], { round: 0 });
  const tbPerfume = S => T(34, 20, P => { const g = S.k === 'royal' ? '#f6e2e6' : '#e8f6ff'; return [cyl(-10, 0, 0, 5, 12, g, { n: 10, emit: 1 }), cyl(-10, 12, 0, 2, 3, GOLD, { n: 6 }), ball(-10, 15, 0, 2.4, S.k === 'royal' ? '#7a1e2c' : P.a, { k: 3, n: 8 }), box(2, 0, 0, 9, 16, 6, g, { r: 2, emit: 1 }), cyl(2, 16, 0, 1.6, 3, GOLD, { n: 6 }), ball(2, 19, 0, 3, GOLD, { k: 3, n: 8 }), ball(13, 0, 0, 5, P.b, { sy: 1.1, emit: 1 }), cyl(13, 10, 0, 1.4, 4, GOLD, { n: 6 })]; }, { round: 0 });
  const tbSoap = S => T(22, 22, P => [cyl(0, 0, 0, 6, 16, P.a, { n: 12, rg: [[0, 0, 0.9], [14, 0, 1], [16, 0, 0.7]] }), cyl(0, 16, 0, 1.6, 4, DK, { n: 6 }), box(3, 20, 0, 7, 2, 2, DK, { r: 1 }), box(0, 5, 6, 7, 5, 0.6, WH, { r: 1 })]);
  const A3 = { poster, gallery, wallClock, wallShelf, mirror, bookcase, lowShelf, tbVase, tbBooks, tbFruit, tbCake, tbTeapot, tbToaster, tbMixer, tbJar, tbClock, tbRadio, tbGlobe, tbSnow, tbTrophy, tbCandles, tbBox, tbCup, tbDuck, tbPerfume, tbSoap };

  // ---------- register: [level, id, name, room, archetype, extra] ----------
  const L = 'living', Kt = 'kitchen', B = 'bathroom', R = 'bedroom', Dn = 'dance', Y = 'backyard';
  const NEW = [
    [1, 'x_pPal', 'Taped Comic Poster', L, 'poster', { v: 'pal' }], [1, 'x_rRunner', 'Rag Runner', L, 'rug2', { v: 'runner' }], [1, 'x_jarLamp', 'Jar Table Lamp', L, 'tableLamp'],
    [2, 'x_tinClock', 'Tin Wall Clock', L, 'wallClock'], [2, 'x_toastJ', 'Dented Toaster', Kt, 'tbToaster'], [2, 'x_sackPile', 'Sack Bean Pile', L, 'beanpile'], [2, 'x_telly', 'Tiny Telly', L, 'miniTV'], [2, 'x_canCactus', 'Tin Can Cactus', L, 'cactus'],
    [3, 'x_plank', 'Plank Shelf', L, 'wallShelf'], [3, 'x_teaJ', 'Chipped Teapot', Kt, 'tbTeapot'], [3, 'x_kRag', 'Kitchen Rag Mat', Kt, 'rug2', { v: 'stripe' }], [3, 'x_crateBooks', 'Crate Bookcase', L, 'bookcase'], [3, 'x_tinSconce', 'Tin Sconce', L, 'sconce'],
    [4, 'x_crackMir', 'Cracked Mirror', B, 'mirror'], [4, 'x_mug', 'Toothbrush Mug', B, 'tbCup'], [4, 'x_bRag', 'Bath Rag Rug', B, 'rug2', { v: 'oval' }], [4, 'x_jamBowl', 'Jam Jar Fishbowl', L, 'tankSmall'], [4, 'x_tinJar', 'Cookie Tin', Kt, 'tbJar'],
    [5, 'x_oldBox', 'Old Party Box', L, 'partyBox'], [5, 'x_crateTV', 'TV Crate Stand', L, 'tvstand'], [5, 'x_lumpBed', 'Lumpy Daybed', R, 'chaise'], [5, 'x_pMap', 'Old Map Poster', L, 'poster', { v: 'map' }], [5, 'x_bookJ', 'Book Stack', L, 'tbBooks'], [5, 'x_snaps', 'Snapshot Wall', L, 'gallery'],
    [6, 'x_cotL', 'Cottage Corner Sofa', L, 'lsofa'], [6, 'x_pFruit', 'Fruit Print', Kt, 'poster', { v: 'fruit' }], [6, 'x_braidR', 'Braided Round Rug', R, 'rug2', { v: 'round' }], [6, 'x_pleatLamp', 'Pleated Lamp', R, 'tableLamp'], [6, 'x_alarm', 'Twin-Bell Alarm', R, 'tbClock'],
    [7, 'x_cotEnd', 'Cottage Sofa End', L, 'modEnd'], [7, 'x_cotMid', 'Cottage Sofa Middle', L, 'modMid'], [7, 'x_cotCorner', 'Cottage Sofa Corner', L, 'modCorner'], [7, 'x_cuckoo', 'Cuckoo Clock', L, 'wallClock'], [7, 'x_cakeC', 'Cake Stand', Kt, 'tbCake'], [7, 'x_fruitC', 'Fruit Bowl', Kt, 'tbFruit'],
    [8, 'x_cotDay', 'Cottage Daybed', R, 'chaise'], [8, 'x_ovalMir', 'Oval Wood Mirror', R, 'mirror'], [8, 'x_monst', 'Monstera', L, 'monstera'], [8, 'x_sunfl', 'Sunflower Pot', Y, 'sunflower'], [8, 'x_gLantern', 'Garden Lantern', Y, 'lantern'], [8, 'x_picnicRad', 'Picnic Radio', Y, 'partyBox'],
    [9, 'x_cotTV', 'Cottage TV Cabinet', L, 'tvstand'], [9, 'x_spiceSh', 'Spice Shelf', Kt, 'wallShelf'], [9, 'x_mixerC', 'Stand Mixer', Kt, 'tbMixer'], [9, 'x_toyCub', 'Toy Cubby', R, 'lowShelf'], [9, 'x_ducks', 'Rubber Duck Trio', B, 'tbDuck'], [9, 'x_daisyR', 'Daisy Bath Rug', B, 'rug2', { v: 'flower' }],
    [10, 'x_cotLib', 'Cottage Library', L, 'bookcase'], [10, 'x_famPics', 'Family Photos', L, 'gallery'], [10, 'x_goldfish', 'Goldfish Bowl', L, 'tankSmall'], [10, 'x_bedTV', 'Bedside TV', R, 'miniTV'], [10, 'x_candSc', 'Candle Sconce', L, 'sconce'], [10, 'x_succC', 'Succulent', R, 'succulent'],
    [11, 'x_horse', 'Diner Horseshoe Sofa', L, 'usofa'], [11, 'x_pRock', 'Rock Concert Poster', L, 'poster', { v: 'music' }], [11, 'x_recRug', 'Record Rug', Dn, 'rug2', { v: 'record' }], [11, 'x_spkWall', 'Speaker Wall', Dn, 'spkWall'], [11, 'x_burstClk', 'Starburst Clock', L, 'wallClock'],
    [12, 'x_chkRun', 'Checker Runner', Kt, 'rug2', { v: 'check' }], [12, 'x_chromeToast', 'Chrome Toaster', Kt, 'tbToaster'], [12, 'x_chromeSh', 'Chrome Shelf', Kt, 'wallShelf'], [12, 'x_cookieJar', 'Cookie Jar', Kt, 'tbJar'], [12, 'x_retroCon', 'Retro TV Console', L, 'tvstand'], [12, 'x_atomCact', 'Atomic Cactus', L, 'cactus'],
    [13, 'x_pinball', 'Pinball Machine', Dn, 'pinball'], [13, 'x_neonStar', 'Neon Star Sign', Dn, 'neonSign'], [13, 'x_boothRow', 'Diner Booth Row', L, 'longSofa', { n: 4 }], [13, 'x_lobbyPalm', 'Lobby Palm', L, 'pottedPalm'], [13, 'x_atomLamp', 'Atomic Lamp', L, 'tableLamp'],
    [14, 'x_hollyMir', 'Hollywood Mirror', B, 'mirror'], [14, 'x_perfR', 'Perfume Bottles', B, 'tbPerfume'], [14, 'x_pMovie', 'Movie Poster', R, 'poster', { v: 'movie' }], [14, 'x_radioR', 'Tabletop Radio', R, 'tbRadio'], [14, 'x_starRug', 'Star Rug', R, 'rug2', { v: 'star' }], [14, 'x_jetDay', 'Jet-Age Daybed', R, 'chaise'],
    [15, 'x_driveIn', 'Drive-In Screen', Y, 'projector'], [15, 'x_rWallTV', 'Rounded Wall TV', L, 'wallTV'], [15, 'x_bubPost', 'Bubble Lamp Post', Dn, 'lantern'], [15, 'x_recCovers', 'Record Covers', L, 'gallery'], [15, 'x_chromeSc', 'Chrome Sconce', L, 'sconce'], [15, 'x_cakeDome', 'Diner Cake Dome', Kt, 'tbCake'],
    [16, 'x_modBench', 'Modern Bench Sofa', L, 'longSofa', { n: 3 }], [16, 'x_bigWallTV', 'Big Wall TV', L, 'wallTV'], [16, 'x_hexRug', 'Hex Rug', L, 'rug2', { v: 'hex' }], [16, 'x_tallMonst', 'Tall Monstera', L, 'monstera'], [16, 'x_budVase', 'Bud Vase', L, 'tbVase'],
    [17, 'x_modEnd', 'Modular Sofa End', L, 'modEnd'], [17, 'x_modMid', 'Modular Sofa Middle', L, 'modMid'], [17, 'x_modCorner', 'Modular Sofa Corner', L, 'modCorner'], [17, 'x_modL', 'L-Shape Sofa', L, 'lsofa'], [17, 'x_floatSh', 'Floating Shelf', L, 'wallShelf'], [17, 'x_bonsai', 'Bonsai', L, 'bonsai'],
    [18, 'x_screen', 'Movie Screen', L, 'projector'], [18, 'x_aqua', 'Big Aquarium', L, 'aquaBig'], [18, 'x_console', 'Game Console', L, 'consoleSet'], [18, 'x_racer', 'Racing Sim', Dn, 'racer'], [18, 'x_sub', 'Subwoofer', Dn, 'sub'], [18, 'x_cubeLib', 'Cube Library', L, 'bookcase'],
    [19, 'x_pitM', 'Round Pit Sofa', L, 'pit'], [19, 'x_pSunset', 'Gallery Print', R, 'poster', { v: 'sunset' }], [19, 'x_archMir', 'Arch Mirror', R, 'mirror'], [19, 'x_zigRug', 'Zigzag Rug', R, 'rug2', { v: 'zig' }], [19, 'x_orbLamp', 'Orb Lamp', R, 'tableLamp'], [19, 'x_globe', 'Desk Globe', R, 'tbGlobe'],
    [20, 'x_fogSpk', 'Fog Speaker', Dn, 'smokeSpk'], [20, 'x_lightBar', 'Light Bar', L, 'sconce'], [20, 'x_galM', 'Gallery Frames', L, 'gallery'], [20, 'x_glassFruit', 'Glass Fruit Bowl', Kt, 'tbFruit'], [20, 'x_soap', 'Soap Pump', B, 'tbSoap'], [20, 'x_lowSh', 'Low Shelf', R, 'lowShelf'], [20, 'x_minClk', 'Minimal Clock', L, 'wallClock'],
    [21, 'x_candyU', 'Candy U-Sofa', L, 'usofa'], [21, 'x_rainRug', 'Rainbow Rug', L, 'rug2', { v: 'rainbow' }], [21, 'x_gumTV', 'Gumdrop Wall TV', L, 'wallTV'], [21, 'x_pSweet', 'Sweet Pal Poster', L, 'poster', { v: 'pal' }], [21, 'x_mushLamp', 'Mushroom Lamp', R, 'mushLamp'],
    [22, 'x_marshPit', 'Marshmallow Pit', L, 'pit'], [22, 'x_gumPile', 'Gumdrop Bean Pile', L, 'beanpile'], [22, 'x_taffyDay', 'Taffy Daybed', R, 'chaise'], [22, 'x_shag', 'Shaggy Rug', R, 'rug2', { v: 'shag' }], [22, 'x_tubeTank', 'Bubble Tube Tank', L, 'aquaCol'], [22, 'x_cupTower', 'Cupcake Tower', Kt, 'tbCake'],
    [23, 'x_claw', 'Claw Machine', Dn, 'claw'], [23, 'x_neonLolly', 'Neon Lollipop', Dn, 'neonSign'], [23, 'x_jellyBox', 'Jelly Party Box', Dn, 'partyBox'], [23, 'x_handheld', 'Handheld Game', L, 'handheld'], [23, 'x_snowG', 'Snow Globe', R, 'tbSnow'], [23, 'x_cookieClk', 'Cookie Clock', R, 'wallClock'],
    [24, 'x_faceRug', 'Pal Face Rug', R, 'rug2', { v: 'face' }], [24, 'x_cloudMir', 'Cloud Mirror', R, 'mirror'], [24, 'x_cloudSh', 'Cloud Shelf', R, 'wallShelf'], [24, 'x_candyCub', 'Candy Cubby', R, 'lowShelf'], [24, 'x_duckPar', 'Duck Parade', B, 'tbDuck'], [24, 'x_candyJar', 'Candy Jar', Kt, 'tbJar'], [24, 'x_lollyFl', 'Lolly Flowers', L, 'flowerPot'],
    [25, 'x_candyLib', 'Candy Bookcase', L, 'bookcase'], [25, 'x_candyTV', 'Candy TV Stand', L, 'tvstand'], [25, 'x_doodles', 'Doodle Frames', L, 'gallery'], [25, 'x_spiral', 'Spiral Rug', Dn, 'rug2', { v: 'spiral' }], [25, 'x_gumSc', 'Gumdrop Sconce', L, 'sconce'], [25, 'x_sugSucc', 'Sugar Succulent', L, 'succulent'], [25, 'x_gumLamp', 'Gumdrop Lamp', L, 'tableLamp'],
    [26, 'x_grand', 'Royal Settee', L, 'longSofa', { n: 3 }], [26, 'x_royOval', 'Royal Oval Rug', L, 'rug2', { v: 'oval' }], [26, 'x_sunClk', 'Sunburst Clock', L, 'wallClock'], [26, 'x_porcVase', 'Porcelain Vase', L, 'tbVase'], [26, 'x_pStars', 'Starry Sky Painting', L, 'poster', { v: 'stars' }],
    [27, 'x_palU', 'Palace U-Sofa', L, 'usofa'], [27, 'x_gildTV', 'Gilded Wall TV', L, 'wallTV'], [27, 'x_palAqua', 'Palace Aquarium', L, 'aquaBig'], [27, 'x_palPalm', 'Palace Palm', L, 'pottedPalm'], [27, 'x_crysLamp', 'Crystal Lamp', L, 'tableLamp'], [27, 'x_trophy', 'Golden Trophy', R, 'tbTrophy'],
    [28, 'x_royDay', 'Royal Daybed', R, 'chaise'], [28, 'x_gildMir', 'Gilded Mirror', R, 'mirror'], [28, 'x_royStar', 'Royal Star Rug', R, 'rug2', { v: 'star' }], [28, 'x_candles', 'Candle Trio', R, 'tbCandles'], [28, 'x_musicBox', 'Music Box', R, 'tbBox'], [28, 'x_crysPerf', 'Crystal Perfumes', B, 'tbPerfume'],
    [29, 'x_cinema', 'Royal Cinema', Dn, 'projector'], [29, 'x_royTower', 'Royal Speaker Tower', Dn, 'spkTower'], [29, 'x_royPit', 'Royal Pit Sofa', L, 'pit'], [29, 'x_palLib', 'Palace Library', L, 'bookcase'], [29, 'x_royGal', 'Royal Gallery', L, 'gallery'], [29, 'x_goldTea', 'Gold Tea Set', Kt, 'tbTeapot'],
    [30, 'x_goldSh', 'Gold Shelf', L, 'wallShelf'], [30, 'x_gildSc', 'Gilded Sconce', L, 'sconce'], [30, 'x_royBouq', 'Royal Bouquet', L, 'flowerPot'], [30, 'x_mapRug', 'Treasure Map Rug', R, 'rug2', { v: 'map' }], [30, 'x_royCake', 'Royal Cake Dome', Kt, 'tbCake'], [30, 'x_leather', 'Leather Books', L, 'tbBooks'],
  ];
  const WT = { lsofa: 2.6, usofa: 3.2, longSofa: 3, modEnd: 1, modMid: 0.8, modCorner: 0.9, pit: 3, beanpile: 1.6, chaise: 1.6, tvstand: 1.6, miniTV: 0.7, wallTV: 1.8, projector: 2.4, spkWall: 2, sub: 1.2, smokeSpk: 1.4, partyBox: 0.9, spkTower: 1.2, tableLamp: 0.5, sconce: 0.5, lantern: 0.8, neonSign: 1, mushLamp: 0.8, cactus: 0.5, monstera: 0.8, sunflower: 0.5, bonsai: 0.6, flowerPot: 0.5, pottedPalm: 0.9, succulent: 0.3, tankSmall: 0.6, aquaBig: 2.2, aquaCol: 1.8, pinball: 2, claw: 2.2, racer: 2.4, consoleSet: 0.9, handheld: 0.6, rug2: 0.7, poster: 0.4, wallClock: 0.5, wallShelf: 0.5, mirror: 0.6, gallery: 0.6, bookcase: 1.3, lowShelf: 1 };
  const AA = Object.assign({}, X.A2, A3), BK = {}; X.BANDS.forEach(b => BK[b.k] = b);
  NEW.forEach(([lv, id, n, room, arch, ex]) => { const band = X.bandOf(lv).k, S = Object.assign({ k: band }, ex || {}), D = AA[arch](S), price = Math.round((50 + lv * 28) * (WT[arch] || 0.3) / 10) * 10;
    Object.assign(D, { n, cat: room, price, cols: BK[band].cols, lv, band, arch, room, start: false, id }); if (D.mount || D.small) D.noBlock = 1; X.CAT[id] = D;
    X.ITEMS.push({ id, n, room, lv, band, arch, price, start: false, hidden: false, surf: false }); });
  X.ITEMS.sort((a, b) => a.lv - b.lv);
  Object.assign(X.ARCH, AA);
  // host tops: small pieces can sit on these (model units, before FS)
  const HOSTA = ['coffee', 'table', 'counter', 'nightstand', 'dresser', 'desk', 'chest', 'shelf', 'bar', 'bookcase', 'lowShelf', 'wallShelf'], TOPS = {};
  X.topOf = t => { if (t in TOPS) return TOPS[t]; const D = X.CAT[t]; let v = 0; if (D && HOSTA.includes(D.arch)) { if (D.top) v = D.top; else { try { D.build(X.pal(D, 0), '').forEach(S => { let a = 1e9, b = -1e9, c = 1e9, d = -1e9, y = -1e9; S.pts.forEach(p => { a = Math.min(a, p[0]); b = Math.max(b, p[0]); c = Math.min(c, p[2]); d = Math.max(d, p[2]); y = Math.max(y, p[1]); }); if (b - a >= D.w * 0.45 && d - c >= D.d * 0.3 && y < 200) v = Math.max(v, y); }); } catch (e) {} } }
    return (TOPS[t] = v * ((D && D.zs) || 1)); };
  // bigger TVs: zs scales the model in render(); footprint/use are scaled here to match
  const TVZ = { tv: 1.35, tvstand: 1.35, miniTV: 1.6, wallTV: 1.4, projector: 1.2 };
  // pricier (higher level) TVs grow a lot more: x1 up to lv 6, ramping to x1.9 at lv 30 (tabletop minis stay small)
  const TVLV = D => D.small ? 1 : 1 + Math.max(0, Math.min(1, ((D.lv || 1) - 6) / 24)) * 0.9;
  Object.values(X.CAT).forEach(D => { if (!TVZ[D.arch] || D.zs || (D.arch === 'tv' && D.id === 'radio')) return; const f = TVZ[D.arch] * TVLV(D); D.zs = f; if (D.mount && D.elev) D.elev = Math.round(D.elev / Math.sqrt(TVLV(D))); D.w *= f; D.d *= f; if (D.use) D.use = Object.assign({}, D.use, { x: D.use.x * f, z: D.use.z * f }); });
  // wall decor + tabletop pieces scaled up to match the bigger TVs (furniture and creatures keep their size)
  const DECZ = { poster: 1.5, gallery: 1.5, wallClock: 1.5, mirror: 1.45, wallShelf: 1.35, sconce: 1.4, neonSign: 1.4,
    tableLamp: 1.3, bonsai: 1.4, succulent: 1.6, tankSmall: 1.35, consoleSet: 1.5, handheld: 1.6 };
  Object.values(X.CAT).forEach(D => { if (D.zs || !(D.mount || D.small)) return; const f = DECZ[D.arch] || (/^tb/.test(D.arch || '') ? 1.55 : 0); if (!f) return; D.zs = f; D.w *= f; D.d *= f; if (D.use) D.use = Object.assign({}, D.use, { x: D.use.x * f, z: D.use.z * f }); });
  // strict room types: food only in the kitchen
  const ROOMFIX = { bowl: 'kitchen', bar: 'kitchen' };
  Object.values(X.CAT).forEach(D => { const r = ROOMFIX[D.arch]; if (r && D.room !== r) { D.room = r; if (D.cat && D.cat !== 'style') D.cat = r; } });
  X.ITEMS.forEach(m => { const r = !m.surf && ROOMFIX[m.arch]; if (r) m.room = r; });
  // no doors: drop door surfaces from the shop
  for (let i = X.ITEMS.length - 1; i >= 0; i--) { const m = X.ITEMS[i], S = X.SURF[m.id]; if (S && S.arch === 'door') X.ITEMS.splice(i, 1); }
  Object.values(X.SURF).forEach(S => { if (S.arch === 'door') S.hidden = 1; });
  X.EXT = 1;
})();
