// Pet Shop personalities (Nov 9, user: 'each character needs to be unique ... give each one unique animations, they need to look natural').
// Every Pet Shop creature gets, on top of Mittens' shared library:
//   1. a personality card that flavours the shared moves (idle, pokes, hop, spin, crying, sleep ...): its own tempo, and how bouncy / swaying /
//      waggy / floppy it is - so the same poke plays quick and twitchy on Nibbles, slow and dignified on Duchess, heavy and jiggly on Truffle;
//   2. its own hand-made moves: signature dance (dance@key), happy, surprised, squish, a little habit (idle_quirk, also a house fidget), and its
//      own squeeze-and-let-go reaction (PRESS / REL in the rig).
// All moves follow the recipe approved on Mittens' look: the eyes lead, the head travels in an arc, every big move has anticipation, a small
// overshoot and a settle, the body follows a beat later, the weight shifts, feet stay planted unless they step, ears / tail / soft body trail
// (the rig adds that follow-through by itself). Loops end exactly on their first pose.
(function boot() {
  const R = window.RiveRig; if (!R || !R.REST || !R.GROUPS || !R.STATES.dance || !R.STATES.poke_head) { setTimeout(boot, 25); return; } if (R.petV) return; R.petV = 1;
  const REST = R.REST, ST = {}, DESC = R.DESC = R.DESC || {};
  // pitch: NEGATIVE = head down (nods / droops), POSITIVE = head up (the rig's convention, same as sleep / cry / yawn). Nov 9: every pitch here was
  // written the other way round at first and flipped (the look() turn copied from the approved nat() was already right).

  // ---------- timeline DSL (same as mittens-moves, plus a base pose: loops start and end on it) ----------
  function TL(base, T) { // T = tempo (time scale) for a creature's own pace
    base = base || {}; T = T || 1; const B0 = p => p in base ? base[p] : REST[p];
    const k = {}, ev = [], em = []; let t = 0;
    const o = {
      get t() { return t; }, b: B0,
      to(dt, v, ez) { dt *= T; for (const p in v) { const L = k[p] || (k[p] = [[0, B0(p)]]); if (L[L.length - 1][0] < t) L.push([t, L[L.length - 1][1], 'l']); } t += dt; for (const p in v) k[p].push([t, v[p], ez || 'io']); return o; },
      wait(dt) { t += dt * T; return o; },
      at(x) { t = x; return o; },
      e(...a) { ev.push([t, ...a]); return o; },
      em(dur, every, preset, where, n) { em.push([t, t + dur, every, preset, where, n]); return o; },
      osc(dt, n, A, B, ez) { const h = dt / n / 2; for (let i = 0; i < n; i++) o.to(h, A, ez || 'io').to(h, B, ez || 'io'); return o; },
      rest(dt, ez) { const b = {}; for (const p in k) b[p] = B0(p); return o.to(dt || 450, b, ez); },
      out(x, loop) { for (const p in base) if (!k[p]) k[p] = [[0, base[p]]];
        for (const p in k) { const L = k[p].sort((a, b) => a[0] - b[0]); if (L.length > 1 && L[L.length - 1][0] < t) L.push([t, L[L.length - 1][1], 'l']);
          if (loop && L.length > 1) { const a = L[0][1], b = L[L.length - 1][1]; if (p === 'spin' ? Math.abs(((b - a) % 360 + 540) % 360 - 180) > 0.5 : Math.abs(b - a) > 1e-6) (R.LOOPWARN = R.LOOPWARN || []).push(p + ' ' + a + '->' + b); } }
        ev.sort((a, b) => a[0] - b[0]); return Object.assign(loop ? { loop: t } : { dur: t }, { k, ev, emit: em }, x || {}); },
      done(x) { return o.out(x); }, loop(x) { return o.out(x, true); },
    };
    return o;
  }
  const S = s => s < 0 ? { arm: 'armL', hx: 'hLx', hy: 'hLy', ear: 'earL', wink: 'winkL', foot: 'footL', paw: 'pawL' } : { arm: 'armR', hx: 'hRx', hy: 'hRy', ear: 'earR', wink: 'winkR', foot: 'footR', paw: 'pawR' };
  const hand = (s, inX, y) => { const k = S(s); return { [k.hx]: s < 0 ? inX : -inX, [k.hy]: y }; };
  const both = (inX, y) => Object.assign(hand(-1, inX, y), hand(1, inX, y));
  const o = (...a) => Object.assign({}, ...a);
  const NOHANDS = both(0, 0);

  // ---------- natural motion helpers ----------
  // a hop: anticipation crouch (head dips), stretch the moment the feet leave the ground, round at the top, stretched again as it falls, squash on
  // landing, a small overshoot, settle. The lift track and the squash / arm tracks run side by side (different channels).
  // J: h height, ant crouch ms, up / dn air ms, c crouch depth, arm arms at the top, st stretch scale, pre / air / fall / land extra channels
  // (air / fall must not use sq, pitch or arms), x travel (on the lift track), spin (adds a turn in the air, resets to 0 after)
  const jump = (t, J) => { J = J || {}; const h = J.h || 12, up = J.up || 260, dn = J.dn || Math.round(up * 0.92), c = J.c == null ? 0.18 : J.c, ant = J.ant || 170, arm = J.arm == null ? 40 : J.arm, st = J.st || 1;
    t.to(ant, o({ sq: c, pitch: -0.1, armL: -8, armR: -8 }, J.pre), 'io');
    const a = t.t; t.to(up, o({ lift: h }, J.air), 'o').to(dn, o({ lift: 0 }, J.fall), 'i'); const b = t.t;              // the arc: decelerates up, accelerates down
    if (J.x != null) t.at(a - 30).to(up + dn + 30, { x: J.x }, 'io');                                                      // travel rides alongside on its own channel
    if (J.spin) t.at(a).to(up + dn, { spin: J.spin }, 'io');
    t.at(a).to(80, { sq: -0.16 * st }, 'o').to(up - 80, { sq: -0.03 }, 'io').to(dn * 0.6, { sq: -0.02 }, 'io').to(dn * 0.4, { sq: -0.09 * st }, 'i');
    t.at(a + 40).to(up - 40, { armL: arm, armR: arm, pitch: 0.12 }, 'o').to(dn, { armL: arm * 0.6, armR: arm * 0.6, pitch: -0.04 }, 'io');
    t.at(b); if (J.spin) t.to(1, { spin: 0 }, 'l'); (J.ev || []).forEach(e => t.e(...e));
    if (J.chain) return t.to(80, o({ sq: c * 1.1, pitch: -0.08, armL: -6, armR: -6 }, J.land), 'o');                       // chained hops: the landing squash IS the next crouch
    return t.to(80, o({ sq: c * 1.2, pitch: -0.12, armL: -6, armR: -6 }, J.land), 'o').to(150, { sq: -0.05, pitch: 0.03, armL: 4, armR: 4 }, 'io').to(140, { sq: 0, pitch: 0, armL: 0, armR: 0 }, 'io'); };
  // footsteps in place: one foot lifts and goes down, then the other (always ends with both feet down)
  const steps = (t, dur, n, h) => { const q = dur / n / 2; for (let i = 0; i < n; i++) { const f = i % 2 ? 'footR' : 'footL'; t.to(q, { [f]: h }, 'o').to(q, { [f]: 0 }, 'i'); } return t; };
  // a wiggle / sway: n half-swings alternating +A / -A around the base pose, then back to the base - all inside dur
  const swing = (t, dur, n, A, ez) => { const h = dur / (n + 1); for (let i = 0; i < n; i++) { const v = {}; for (const p in A) v[p] = t.b(p) + A[p] * (i % 2 ? -1 : 1); t.to(h, v, ez || 'io'); }
    const z = {}; for (const p in A) z[p] = t.b(p); return t.to(h, z, ez || 'io'); };
  // the approved natural head turn (Mittens' look): eyes first, the head turns along a dipping arc with a blink, overshoots a touch and settles; the
  // chest follows a beat later (twist), the weight shifts (bend, head counter-tilted), the ears trail. Leaves the time at the end of the chest settle.
  const look = (t, from, to, J) => { J = J || {}; const s = Math.sign(to - from) || 1, dir = Math.sign(to), k = J.k == null ? 1 : J.k, d1 = J.d1 || 170, d2 = J.d2 || 210, T = t.t, bendTo = dir * 4 * k, twTo = to * 0.36 * k;
    t.to(110, { lx: dir * 0.9 }, 'o').e('blink').to(d1, { hyaw: (from + to) / 2, pitch: -0.2, earL: s * 7, earR: -s * 7 }, 'i')
      .to(d2, { hyaw: to + s * 0.08, pitch: 0.05, earL: -s * 3, earR: s * 3, htilt: dir * 3 - bendTo }, 'o').to(320, { hyaw: to, pitch: 0, earL: 0, earR: 0 }, 'io');
    const e1 = t.t; t.at(T + 200).to(d1 + d2, { twist: twTo + s * 0.06 * k, bend: bendTo + s * 1.2 * k }, 'io').to(360, { twist: twTo, bend: bendTo }, 'io');
    return t.at(Math.max(e1, t.t)); };
  // a natural shake (Nov 9, user: the shaking looked weird - it rolled the head flat side to side, too fast, all at once): a wet-dog shake / a cat's
  // head shake after washing. The head TWISTS left-right (yaw, a small roll on top), the chest follows a fraction of a swing later, the body slide
  // later still, the tail last - a wave running down the body; it builds up, peaks and dies away (env); the ears flap against the swing.
  // J: P ms per half-swing, env amplitude per half-swing, head yaw, roll, ear, chest twist, body slide, tail wag
  const shake = (t, J) => { const env = J.env || [0.45, 0.85, 1, 1, 0.85, 0.6, 0.35, 0.15], P = J.P || 110, a = t.t, lag = J.lag || P * 0.4;
    const tr = (off, f) => { t.at(a + off); env.forEach((m, i) => { t.to(P, f((i % 2 ? -1 : 1) * m), 'io'); }); t.to(P, f(0), 'io'); return t.t; };
    let e = tr(0, s => ({ hyaw: s * (J.head || 0.38), htilt: s * (J.roll || 4), earL: -s * (J.ear || 12), earR: s * (J.ear || 12) }));
    if (J.chest) e = Math.max(e, tr(lag, s => ({ twist: s * J.chest })));
    if (J.body) e = Math.max(e, tr(lag * 1.6, s => ({ x: s * J.body, tilt: s * J.body * 2.4 })));
    if (J.tail) e = Math.max(e, tr(lag * 2.2, s => ({ wag: s * J.tail })));
    return t.at(e); };
  // a decaying jelly wobble on sq (big soft bodies after a squash / landing)
  const jelly = (t, a, n, per, ch) => { ch = ch || 'sq'; for (let i = 0; i < n; i++) t.to(per / 2, { [ch]: (i % 2 ? 1 : -1) * a * Math.pow(0.55, i) }, 'io'); return t.to(per / 2, { [ch]: 0 }, 'io'); };

  // a chained landing (jump with chain: true) settling through a jelly wobble, arms and head easing back at the same time
  const land = (t, a, n, per) => { const q = t.t; jelly(t, a, n, per); const e = t.t; return t.at(q).to(Math.min(320, e - q), { armL: 0, armR: 0, pitch: 0 }, 'io').at(e); };

  // ---------- 1. personality cards: flavour the shared moves ----------
  // T tempo (time scale), b bounce (squash + lift), s sway (lean, tilt, slide, bend), w tail wag, e ears, c tail curl
  const CARD = {
    biscuit: { T: 0.86, b: 1.2, s: 1.1, w: 1.6, e: 1.3 },   // eager puppy: quick, bouncy, tail never stops, floppy ears swing big
    truffle: { T: 1.06, b: 1.3, s: 1.15, w: 1, e: 1, c: 1.3 }, // round heavy piglet: a touch slower, jiggly squash, wide sway
    nibbles: { T: 0.78, b: 0.9, s: 0.85, e: 1.2 },              // hamster: fast, twitchy, small moves
    quill: { T: 1.18, b: 0.75, s: 0.8, e: 0.8 },                // shy hedgehog: slow, small, careful
    waffles: { T: 0.94, b: 1.25, s: 1.1, w: 1.8, e: 1.1 },     // goofy corgi: bouncy, wiggly stub tail
    poppy: { T: 0.86, b: 1.15, s: 0.9, e: 1.4 },                // guinea pig: quick little hops, ears flick
    duchess: { T: 1.25, b: 0.7, s: 0.9, w: 0.7, c: 1.3 },      // Persian: slow, graceful, never bouncy
    mamapaws: { T: 1.2, b: 0.85, s: 0.9, w: 1.3 },              // big gentle mum: slow, soft, steady (she carries a pup)
    ribbit: { T: 0.9, b: 1.3, s: 1, e: 1 },                     // frog: springy
  };
  const GRP = { sq: 'b', lift: 'b', lean: 's', tilt: 's', x: 's', bend: 's', wag: 'w', earL: 'e', earR: 'e', curl: 'c' };
  const flavor = (st, c) => { if (!st || st.seq || st.fx || st.prop || !st.k) return null; const T = c.T || 1, out = Object.assign({}, st, { k: {} });
    for (const p in st.k) { const a = GRP[p] ? (c[GRP[p]] || 1) : 1, r = REST[p] || 0; out.k[p] = st.k[p].map(q => { let v = r + (q[1] - r) * a; if (p === 'sq') v = Math.max(-0.26, Math.min(0.36, v)); const n = [q[0] * T, v]; if (q[2]) n.push(q[2]); return n; }); } // a heavy squash stays a squash, never a pancake
    if (st.dur) out.dur = st.dur * T; if (st.loop) out.loop = st.loop * T;
    if (st.ev) out.ev = st.ev.map(e => [e[0] * T].concat(e.slice(1)));
    if (st.emit) out.emit = st.emit.map(m => [m[0] * T, m[1] * T, m[2] * T].concat(m.slice(3)));
    return out; };
  const SHARED = ['idle', 'look', 'squish', 'spin', 'hop', 'idle_yawn', 'idle_waveL', 'idle_waveR', 'cry', 'sob', 'sleep',
    'poke_head', 'poke_earL', 'poke_earR', 'poke_nose', 'poke_cheekL', 'poke_cheekR', 'poke_eyeL', 'poke_eyeR', 'poke_belly', 'poke_sideL', 'poke_sideR', 'poke_footL', 'poke_footR', 'poke_tail'];

  // ---------- 2. hand-made moves ----------
  const MOVES = {};

  // ===== Mittens (ginger kitten) - keeps the original dance / happy / surprised; his habit: a cat face-wash =====
  MOVES.mittens = { quirk: [(() => { const t = TL(); const R1 = hand(1, 13, -15), R2 = hand(1, 7, -27), R3 = hand(1, -1, -33);
      t.to(320, o(R1, { armR: 20, pitch: -0.12, htilt: 4, ly: 0.4 }), 'io').e('blink');                                   // paw up to the mouth
      t.osc(900, 3, { tongue: 0.9, open: 0.15, pitch: -0.16, sq: 0.015 }, { tongue: 0.1, open: 0, pitch: -0.1, sq: 0 }, 'io'); // three licks
      t.to(160, { tongue: 0, close: 0.9 }, 'io');
      for (let i = 0; i < 2; i++) t.to(260, o(R2, { htilt: 9, pitch: -0.18, earR: 10 }), 'io').to(260, o(R3, { htilt: 12, earR: 18, sq: 0.02 }), 'o').to(240, o(R1, { htilt: 5, earR: 2, sq: 0 }), 'io'); // wipes over the ear
      t.to(240, o(NOHANDS, { armR: 0, pitch: -0.05, earR: 0, close: 0.9 }), 'io');                                        // paw down, eyes still shut ...
      shake(t, { P: 85, env: [0.6, 1, 0.85, 0.55, 0.25], head: 0.36, roll: 4, ear: 13, chest: 0.08 });                    // ... a quick cat head shake
      t.to(160, { close: 0, pitch: 0 }, 'io').to(200, { hap: 1, smile: 0.8 }, 'io').wait(450).rest(420);
      return t.done(); })(), 'Face wash', 'Licks a paw three times and wipes it over his ear (head leaning into it), then a quick cat head shake that dies away.'] };

  // ===== Biscuit (floppy-eared puppy): 'Biscuit Bot' robot dance, eager + wiggly =====
  MOVES.biscuit = {
    dance: [(() => { const t = TL({ smile: 0.5 }), B = 500;
      // robot: snaps into each pose (fast ease-out + a tiny overshoot, then dead still) while his floppy ears and tail keep swinging
      const snap = (v, over, len) => { t.to(90, over, 'o').to(80, v, 'io'); return t.wait((len || B) - 170); };
      t.e('emit', 'note', 'head').to(60, { lx: 0.7 }, 'o');
      snap({ armR: 88, hyaw: 0.32, sq: 0, wag: 14, htilt: -2 }, { armR: 97, hyaw: 0.38, sq: 0.05, wag: 18, htilt: -3 }, B - 60);
      t.to(60, { lx: -0.7 }, 'o'); snap({ armL: 88, hyaw: -0.32, sq: 0, wag: -14, htilt: 2 }, { armL: 97, hyaw: -0.38, sq: 0.05, wag: -18, htilt: 3 }, B - 60);
      t.to(60, { lx: 0 }, 'o'); snap({ hyaw: 0, htilt: 9, wag: 14, sq: 0 }, { hyaw: 0.05, htilt: 11, wag: 18, sq: 0.04 }, B - 60);   // robot head tilts
      snap({ htilt: -9, wag: -14, sq: 0 }, { htilt: -11, wag: -18, sq: 0.04 });
      snap({ armR: 150, armL: 0, x: 2, htilt: 0, wag: 14, sq: 0 }, { armR: 158, armL: -6, x: 2.6, htilt: 1, wag: 18, sq: 0.05 });     // pop-lock arms
      snap({ armR: 0, armL: 150, x: -2, wag: -14, sq: 0 }, { armR: -6, armL: 158, x: -2.6, wag: -18, sq: 0.05 });
      snap({ armR: 62, armL: 62, x: 0, wag: 0, sq: 0 }, { armR: 68, armL: 68, x: 0.4, wag: 4, sq: 0.06 });
      snap({ armR: 122, armL: 28, sq: 0 }, { armR: 128, armL: 22, sq: 0.05 });
      t.e('emit', 'note', 'head');
      for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1, k = S(d), j = S(-d);                                                     // robot march
        t.to(90, { [k.foot]: 4.5, [j.foot]: 0, [k.arm]: -14, [j.arm]: 46, turn: d * 0.12, sq: -0.03, lift: 1, x: d * 0.8, wag: d * 12 }, 'o').to(80, { [k.foot]: 3.6, sq: -0.01 }, 'io').wait(80)
          .to(90, { [k.foot]: 0, sq: 0.07, lift: 0 }, 'i').to(80, { sq: 0.02 }, 'io').wait(80); }
      t.to(120, { turn: 0, x: 0, sq: 0, armL: 30, armR: 30, wag: 0 }, 'io')                                                          // power down (droops, speeding up like a falling weight)
        .to(700, { sq: 0.17, pitch: -0.38, armL: -8, armR: -8, earL: 4, earR: 4, close: 0.8, smile: 0, ly: 0.6, htilt: 6 }, 'i').to(90, { sq: 0.21 }, 'o').to(90, { sq: 0.19 }, 'io');
      t.e('emit', 'spark', 'head', 4).to(70, { close: 0, wide: 1, ly: -0.2 }, 'o')                                                     // reboot!
        .to(160, { sq: -0.09, lift: 5, pitch: 0.12, armL: 40, armR: 40, earL: -8, earR: -8, htilt: 0 }, 'o').to(170, { sq: 0.1, lift: 0, pitch: -0.02 }, 'i').to(100, { sq: 0 }, 'io');
      t.to(200, { wide: 0, ly: 0, hap: 1, smile: 1, tongue: 0.9, open: 0.35, armL: 10, armR: 10, earL: 0, earR: 0, pitch: 0 }, 'o').e('emit', 'heart', 'head', 2).wait(300); // ... puppy mode
      const a = t.t; t.osc(1500, 3, { tilt: 6, x: 1.6, bend: 3, htilt: -3 }, { tilt: -6, x: -1.6, bend: -3, htilt: 3 }, 'io'); const b = t.t; // whole-body puppy wiggle
      t.at(a - 300).osc(1800, 6, { wag: 32 }, { wag: -32 }, 'io').at(b);
      t.to(350, { tilt: 0, x: 0, bend: 0, htilt: 0, hap: 0, smile: 0.5, tongue: 0, open: 0, wag: 0, armL: 0, armR: 0, sq: 0.04 }, 'io').to(150, { sq: 0 }, 'io'); // and back into the robot
      return t.loop({ stretch: 0.6 }); })(), 'Biscuit Bot', 'Robot head ticks, pop-lock arms and a stiff march while his floppy ears and tail keep swinging; powers down, reboots, and breaks into a happy puppy wiggle.'],
    happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.4, tongue: 0.75 });
      jump(t, { h: 9, ant: 150, up: 220, c: 0.16, arm: 30 });
      const a = t.t; t.osc(900, 2, { tilt: 7, x: 2, bend: 3, htilt: -3 }, { tilt: -7, x: -2, bend: -3, htilt: 3 }, 'io').to(250, { tilt: 0, x: 0, bend: 0, htilt: 0 }, 'io'); const b = t.t;
      t.at(0); swing(t, b, 15, { wag: 34 }); t.at(b).e('emit', 'heart', 'head', 1);
      return Object.assign(t.loop(), { dur: b * 3 }); })(), 'Happy', 'Tongue out, a bouncy hop, then a whole-body wiggle with his tail going non-stop.'],
    surprised: [(() => { const t = TL();
      t.wait(150).to(80, { sq: 0.1, wide: 1, earL: -14, earR: -14, open: 0.5, mw: 0.7 }, 'o');                                     // startle: ears jump up
      jump(t, { h: 7, ant: 60, up: 200, c: 0.08, arm: 34, x: -6, air: { lean: -3 }, fall: { lean: -1 } });
      t.wait(250).e('blink').to(500, { lx: 0.3, earL: -6, earR: -6, open: 0.15, mw: 0.85 }, 'io');
      t.to(420, { htilt: 15, pitch: 0.05, earL: 3, earR: -5, ly: -0.1 }, 'io').wait(500);                                         // the puppy head tilt ...
      t.to(480, { htilt: -14, earL: -5, earR: 3, lx: -0.3 }, 'io').wait(420);                                                      // ... and the other way
      t.e('blink').to(380, { htilt: 0, earL: 0, earR: 0, lx: 0, wide: 0, open: 0.35, mw: 1, hap: 1, smile: 1, tongue: 0.7 }, 'io');
      const a = t.t; t.osc(1200, 4, { wag: 26 }, { wag: -26 }, 'io'); t.at(a).to(1200, { x: 0, lean: 0 }, 'io');                // it's fine: tail starts going, trots back
      return t.rest(450).done({ stretch: 0.5 }); })(), 'Surprised', 'Ears jump up and he hops back, then does the puppy head tilt one way and the other, decides it is fine and wags.'],
    quirk: [(() => { const t = TL();
      look(t, 0, 0.8, { k: 1.2 }); t.wait(150);                                                                                     // spots his tail ...
      t.to(140, { sq: 0.1, wide: 0.6 }, 'io').e('emit', 'dust', 'footL', 2);
      t.to(900, { spin: 360, lean: 3, tilt: 6, hyaw: 0.4, twist: 0.2, bend: 2, x: 1.5, tongue: 0.8, open: 0.35, sq: -0.02 }, 'io').to(1, { spin: 0 }, 'l'); // ... and chases it round
      t.to(220, { hyaw: 0, twist: 0, bend: 0, lean: 0, tilt: 0, x: 0, sq: 0.06, cross: 0.8, wide: 0 }, 'io');                     // dizzy
      t.osc(900, 2, { htilt: 8, lean: 1.2 }, { htilt: -8, lean: -1.2 }, 'io').to(260, { htilt: 0, lean: 0, cross: 0, sq: 0, hap: 1, smile: 1 }, 'io').e('blink2');
      return t.wait(300).rest(420).done(); })(), 'Chases his tail', 'Spots his tail, spins round after it, gets dizzy (crossed eyes, wobbly head) and pants happily.'],
    squish: [(() => { const t = TL();
      t.to(150, { sq: -0.05 }, 'o').to(330, { sq: 0.38, hap: 0.9, tongue: 0.8, open: 0.3, armL: 18, armR: 18, earL: 5, earR: 5 }, 'io');
      const a = t.t; t.wait(420); t.at(a - 200).osc(640, 4, { wag: 30 }, { wag: -30 }, 'io').at(a + 420);
      t.to(130, { sq: -0.18, earL: -6, earR: -6, armL: -4, armR: -4, hap: 0, smile: 1, open: 0.45 }, 'o').to(150, { sq: 0.08 }, 'io').to(160, { sq: -0.03, tongue: 0.3 }, 'io')
        .to(180, { sq: 0, earL: 0, earR: 0, armL: 0, armR: 0, tongue: 0, open: 0, smile: 0, wag: 0 }, 'io');
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Squish', 'Squashed flat with his tongue out and tail wagging, springs back with a big ear flop.'],
    press: { tongue: 0.75, open: 0.25 },
    rel: { dur: 1100, k: { sq: [[0, 0], [110, -0.2, 'o'], [250, 0.1, 'io'], [390, -0.04, 'io'], [540, 0, 'io']], lift: [[0, 0], [120, 3.5, 'o'], [280, 0, 'i']],
      earL: [[0, 0], [120, -14, 'o'], [320, 10, 'io'], [520, -4, 'io'], [720, 0, 'io']], earR: [[0, 0], [120, -14, 'o'], [320, 10, 'io'], [520, -4, 'io'], [720, 0, 'io']],
      wag: [[0, 0], [130, 30], [260, -30], [390, 30], [520, -30], [650, 20], [800, 0]], tongue: [[0, 0], [120, 0.8, 'o'], [700, 0.6], [1000, 0, 'io']], smile: [[0, 0], [150, 1, 'o'], [800, 1], [1100, 0, 'io']] }, em: [['heart', 'head', 1]] },
  };

  // ===== Truffle (pink piglet): 'Piggy Wiggle' - round, heavy, jiggly, nose-first =====
  MOVES.truffle = {
    dance: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 500;
      t.e('emit', 'note', 'head');
      let a = t.t; swing(t, 4 * B, 7, { tilt: 5, x: 1.4, bend: 2.5, wag: 18, htilt: -2.5 });                                            // butt wiggle ...
      t.at(a).osc(4 * B, 4, { pitch: -0.14, sq: 0.06 }, { pitch: 0.05, sq: -0.02 }, 'io');                           // ... with snout bops on the beat
      t.to(200, o(both(9, 1), { pitch: 0, hap: 0, sq: 0 }), 'io');                                                                      // paws on his belly
      for (let i = 0; i < 3; i++) { const d = i % 2 ? 1 : -1;                                                                              // belly bounces + pats
        t.to(140, o(hand(d, 9, -1), hand(-d, 9, 2), { sq: 0.15, lift: 0 }), 'i').to(170, { sq: -0.06, lift: 2.5 }, 'o').to(190, { sq: 0.02, lift: 0 }, 'i'); }
      t.e('emit', 'note', 'head').to(140, o(NOHANDS, { open: 0.6, mw: 0.8, pitch: 0.2, sq: -0.04 }), 'o').to(200, { open: 0, mw: 1, pitch: 0, sq: 0 }, 'io'); // oink!
      a = t.t; t.to(500, { spin: 180, hap: 1 }, 'io').wait(1000).to(500, { spin: 360, hap: 0 }, 'io').to(1, { spin: 0 }, 'l');                            // turns round, wiggles his curly tail at you, turns back
      t.at(a); steps(t, 500, 2, 2.5); swing(t, 1000, 4, { tilt: 6, x: 1.6, wag: 26, curl: 0.4 }); steps(t, 500, 2, 2.5); t.at(a + 2001);
      t.e('emit', 'note', 'head');
      for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1, k = S(d);                                                                   // mud stomps: weight onto one leg, lift the other, stomp
        t.to(200, { bend: -d * 3.5, x: -d * 1.2, htilt: d * 2, [k.foot]: 4, sq: -0.02 }, 'o').to(120, { [k.foot]: 0, sq: 0.1, bend: -d * 1.5 }, 'i').e('emit', 'dust', k.foot, 3).to(180, { sq: 0 }, 'io'); }
      t.to(200, { bend: 0, x: 0, htilt: 0 }, 'io');
      jump(t, { h: 9, ant: 220, up: 280, c: 0.22, arm: 45, chain: true, air: { open: 0.55, mw: 0.8, hap: 1 }, fall: { open: 0.2 }, ev: [['emit', 'dust', 'body', 4], ['emit', 'heart', 'head', 2]] }); // big happy oink hop
      land(t, 0.1, 3, 260).to(160, { open: 0, mw: 1 }, 'io');
      return t.loop({ stretch: 0.7 }); })(), 'Piggy Wiggle', 'Butt wiggle with snout bops, belly bounces with belly pats, an oink, turns round to wiggle his curly tail at you, mud stomps, and a big happy oink hop.'],
    happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
      jump(t, { h: 7, ant: 200, up: 240, c: 0.2, arm: 36, chain: true }); land(t, 0.08, 2, 240);
      jump(t, { h: 8, ant: 180, up: 250, c: 0.22, arm: 44, chain: true, air: { curl: 0.6 }, fall: { curl: 0 }, ev: [['emit', 'heart', 'head', 2]] }); land(t, 0.09, 3, 240);
      const L = t.t; t.at(0); swing(t, L, 11, { wag: 20 }); t.at(L);
      return Object.assign(t.loop(), { dur: L * 3 }); })(), 'Happy', 'Two heavy happy hops, his round body jiggling after each landing, curly tail spinning, hearts.'],
    surprised: [(() => { const t = TL();
      t.wait(150).to(80, { sq: 0.12, wide: 1, earL: -12, earR: -12, open: 0.4 }, 'o');
      jump(t, { h: 6, ant: 60, up: 210, c: 0.1, arm: 30, x: -5, chain: true, air: { lean: -2.5 }, fall: { lean: -1 } }); land(t, 0.08, 2, 220);
      t.osc(360, 2, { sq: 0.05, pitch: 0.1, mw: 0.8 }, { sq: 0, pitch: 0, mw: 1 }, 'o');                                    // snort snort
      t.to(420, { earL: 0, earR: 0, open: 0, wide: 0.4, pitch: -0.18, ly: 0.4 }, 'io');
      const a = t.t; t.osc(1200, 5, { sq: 0.02, pitch: -0.22 }, { sq: 0, pitch: -0.16 }, 'io'); t.at(a).to(1200, { x: 0, lean: 0 }, 'io'); // sniffs his way back
      t.to(300, { pitch: 0, ly: 0, wide: 0, hap: 1, smile: 1 }, 'io').wait(300);
      return t.rest(450).done(); })(), 'Surprised', 'Ears up, a heavy little hop back that wobbles his belly, two snorts, then sniffs his way back nose-first.'],
    quirk: [(() => { const t = TL();
      t.to(380, { pitch: -0.34, ly: 0.8, sq: 0.04 }, 'io');                                                                             // nose to the ground
      const a = t.t; t.to(700, { hyaw: -0.48, x: -2.2, bend: -2.5, twist: -0.12 }, 'io').to(900, { hyaw: 0.45, x: 2.2, bend: 2.5, twist: 0.12 }, 'io').to(500, { hyaw: 0.05, x: 0.4, bend: 0, twist: 0 }, 'io'); const b = t.t; // follows a scent
      t.at(a).osc(b - a, 10, { sq: 0.055, pitch: -0.4, mw: 0.85 }, { sq: 0.015, pitch: -0.3, mw: 1 }, 'o').at(b);
      t.to(200, { pitch: 0.1, ly: 0, sq: -0.04, hap: 1, smile: 1, open: 0.35, hyaw: 0, x: 0 }, 'o').e('emit', 'heart', 'head', 1).osc(500, 2, { wag: 22, curl: 0.4 }, { wag: -22, curl: 0 }, 'io');
      return t.wait(250).rest(450).done(); })(), 'Sniff sniff', 'Puts his snout to the ground and follows a scent left and right, then a happy snort.'],
    squish: [(() => { const t = TL();
      t.to(150, { sq: -0.05 }, 'o').to(340, { sq: 0.42, hap: 0.9, puff: 0.4, armL: 20, armR: 20, earL: 10, earR: 10 }, 'io').wait(400);
      t.to(120, { sq: -0.2, puff: 0, armL: -4, armR: -4, earL: -6, earR: -6, hap: 0, smile: 1, open: 0.5, mw: 0.8 }, 'o'); jelly(t, 0.14, 4, 230);
      t.to(160, { earL: 0, earR: 0, armL: 0, armR: 0, smile: 0, open: 0, mw: 1 }, 'io');
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Squish', 'Squashed into a round piggy pancake, then his whole body jiggles like jelly with an oink.'],
    press: { puff: 0.35 },
    rel: { dur: 1300, k: { sq: [[0, 0], [110, -0.2, 'o'], [230, 0.13, 'io'], [350, -0.08, 'io'], [470, 0.05, 'io'], [590, -0.025, 'io'], [720, 0, 'io']],
      open: [[0, 0], [120, 0.5, 'o'], [450, 0.1, 'io'], [700, 0, 'io']], smile: [[0, 0], [150, 1, 'o'], [900, 1], [1300, 0, 'io']], wag: [[0, 0], [150, 20], [300, -20], [450, 16], [600, -10], [750, 0]] }, em: [['note', 'head', 1]] },
  };

  // ===== Nibbles (hamster): 'Cheek Wiggle' - quick, twitchy, stuffs his cheeks =====
  MOVES.nibbles = {
    dance: [(() => { const P = both(6, -8), t = TL(o(P, { smile: 0.7 })), B = 500;                                                        // paws held together at his chest (hamster pose)
      t.e('emit', 'note', 'head');
      for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1;                                                                           // cheek pulses on the beat
        t.to(110, { puff: 1, sq: 0.05, htilt: d * 5, [S(d).foot]: 2 }, 'o').to(140, { sq: 0, [S(d).foot]: 0 }, 'io').to(250, { puff: 0.15, htilt: d * 2 }, 'io'); }
      t.to(150, { htilt: 0, puff: 0, pitch: -0.2, lean: 0.8, wide: 0.3 }, 'io');                                                        // hamster-wheel run
      let a = t.t; steps(t, 4 * B - 150, 14, 5.5); t.at(a).osc(4 * B - 150, 7, { armL: 48, armR: -10, x: 0.7, tilt: 2 }, { armL: -10, armR: 48, x: -0.7, tilt: -2 }, 'io'); t.at(a).osc(4 * B - 150, 14, { lift: 1.6, sq: -0.03 }, { lift: 0, sq: 0.04 }, 'io');
      t.at(a).em(4 * B - 300, 220, 'dust', 'footL', 1).at(a + 4 * B - 150);
      t.e('emit', 'note', 'head').to(150, { footL: 0, footR: 0, armL: 0, armR: 0, sq: 0, lift: 0, x: 0, tilt: 0, pitch: 0, lean: 0, wide: 0 }, 'io');
      for (let i = 0; i < 3; i++) t.to(150, o(both(11, -14), { pitch: -0.06, sq: 0.03 }), 'io').e('emit', 'crumb', 'mouth', 1)             // stuffs his cheeks: three seeds ...
        .to(110, o(P, { puff: 0.35 + i * 0.32, sq: 0 }), 'o').osc(240, 2, { open: 0.12 }, { open: 0 }, 'io');
      t.to(110, { sq: 0.08, wide: 0.8, puff: 1.2 }, 'io').to(70, { puff: 0, sq: -0.1, open: 0.5, lift: 3 }, 'o').e('emit', 'seed', 'mouth', 3) // ... and POP
        .to(180, { lift: 0, sq: 0.05, open: 0 }, 'i').to(160, { sq: 0, wide: 0 }, 'io');
      a = t.t; t.to(560, { spin: 360 }, 'io').to(1, { spin: 0 }, 'l').at(a).to(260, { lift: 4, sq: -0.06 }, 'o').to(300, { lift: 0, sq: 0.08 }, 'i').to(150, { sq: 0 }, 'io'); // quick spin
      t.at(a + 710);
      jump(t, { h: 6, ant: 110, up: 160, c: 0.12, arm: 20, chain: true }); jump(t, { h: 6, ant: 100, up: 160, c: 0.12, arm: 20 });              // two tiny hops
      t.e('emit', 'note', 'head').to(200, o(NOHANDS, { armL: 140, armR: 140, hap: 1, smile: 1 }), 'o');                                  // paws up, cheek wiggle, nose twitch
      a = t.t; t.osc(1200, 4, { armL: 120, armR: 155, turn: 0.15, htilt: 3 }, { armL: 155, armR: 120, turn: -0.15, htilt: -3 }, 'io'); const b = t.t;
      t.at(a).osc(1200, 8, { sq: 0.02, pitch: 0.04 }, { sq: 0, pitch: 0 }, 'o').at(b);
      t.to(Math.max(150, 20 * B - b), o(P, { armL: 0, armR: 0, turn: 0, htilt: 0, hap: 0, smile: 0.7 }), 'io');
      return t.loop({ stretch: 0.5 }); })(), 'Cheek Wiggle', 'Cheek puffs on the beat, a hamster-wheel run, stuffs three seeds into his cheeks and pops them out, a quick spin, two tiny hops, paws-up wiggle.'],
    happy: [(() => { const t = TL(o(both(6, -8), { hap: 1, smile: 1 }));
      jump(t, { h: 6, ant: 110, up: 160, c: 0.12, arm: 18, chain: true, air: { puff: 0.8 }, fall: { puff: 0.2 } });
      jump(t, { h: 7, ant: 100, up: 170, c: 0.12, arm: 18, air: { puff: 0.9 }, fall: { puff: 0 }, ev: [['emit', 'heart', 'head', 1]] });
      t.osc(500, 4, { pitch: 0.05, sq: 0.02 }, { pitch: 0, sq: 0 }, 'o');
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Happy', 'Two quick tiny hops with his cheeks puffing, paws clasped, a nose twitch.'],
    surprised: [(() => { const t = TL();
      t.wait(120).to(70, { sq: 0.1, wide: 1, earL: -10, earR: -10, open: 0.3 }, 'o').to(160, { lift: 4, sq: -0.08 }, 'o').to(170, { lift: 0, sq: 0.06 }, 'i');
      t.to(90, { sq: 0, open: 0 }, 'o').wait(900);                                                                                      // the hamster freeze: totally still ...
      t.to(90, { lx: -0.8 }, 'o').wait(320).to(90, { lx: 0.8 }, 'o').wait(320).to(90, { lx: 0 }, 'o').wait(150);                        // ... only the eyes dart
      t.e('blink').to(150, o(both(11, -14), { earL: 0, earR: 0 }), 'io');
      t.osc(600, 4, { puff: 0.7, sq: 0.02 }, { puff: 0.5, sq: 0 }, 'o').to(220, o(both(6, -8), { wide: 0.2 }), 'io');                    // nervous cheek stuffing
      return t.wait(300).rest(500).done({ noBlink: true }); })(), 'Surprised', 'A tiny jump, then the hamster freeze - completely still, only his eyes dart left and right - and some nervous cheek stuffing.'],
    quirk: [(() => { const t = TL();
      t.to(360, o(both(9, 6), { pitch: -0.24, ly: 0.6, sq: 0.04, lean: 0.5 }), 'io').e('emit', 'crumb', 'pawL', 1);                      // picks a seed off the floor
      t.to(320, o(both(11, -14), { pitch: -0.04, ly: 0, sq: 0, lean: 0 }), 'io').osc(420, 3, { open: 0.14 }, { open: 0 }, 'io').to(160, { puff: 0.75 }, 'o');
      t.to(260, o(both(2, -19), { htilt: 3 }), 'io').osc(500, 2, { hLy: -21, hRy: -17, puff: 0.85 }, { hLy: -17, hRy: -21, puff: 0.7 }, 'io'); // pats his full cheeks
      t.to(220, o(NOHANDS, { htilt: 0, hap: 1, smile: 1 }), 'io').osc(400, 4, { pitch: 0.05, sq: 0.015 }, { pitch: 0, sq: 0 }, 'o');
      return t.wait(250).rest(500).done(); })(), 'Cheek stash', 'Picks a seed off the floor, stuffs it in his cheek, pats his full cheeks, nose twitch.'],
    squish: [(() => { const t = TL();
      t.to(130, { sq: -0.05 }, 'o').to(300, { sq: 0.36, puff: 1.1, sqz: 0.8, armL: 16, armR: 16 }, 'io').wait(420);
      t.to(80, { sq: -0.2, puff: 0, sqz: 0, open: 0.45, armL: -4, armR: -4 }, 'o').e('emit', 'seed', 'mouth', 3).to(150, { sq: 0.07, open: 0.1 }, 'io').to(150, { sq: -0.02 }, 'io')
        .to(170, { sq: 0, open: 0, armL: 0, armR: 0 }, 'io');
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Squish', 'Squeezed, his cheeks balloon out - let go and the seeds pop out.'],
    press: { puff: 1, sqz: 0.6 },
    rel: { dur: 900, k: { sq: [[0, 0], [90, -0.2, 'o'], [220, 0.08, 'io'], [340, -0.03, 'io'], [460, 0, 'io']], lift: [[0, 0], [100, 3, 'o'], [240, 0, 'i']],
      open: [[0, 0], [80, 0.45, 'o'], [400, 0, 'io']], puff: [[0, 0], [90, -0.3, 'o'], [300, 0, 'io']] }, em: [['seed', 'mouth', 3]] },
  };

  // ===== Quill (shy hedgehog): 'Spike Shuffle' - slow, small, careful; curls into a ball =====
  MOVES.quill = {
    dance: [(() => { const P = both(6, -8), t = TL(o(P, { pitch: -0.08, blush: 0.45, smile: 0.5, ly: 0.3 })), B = 600;               // shy: paws clasped, eyes down
      t.e('emit', 'note', 'head');
      for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1, k = S(d);                                                               // shy side shuffle
        t.to(B * 0.55, { x: d * 3.2, bend: d * 3, htilt: -d * 2, [k.foot]: 2, ly: i === 2 ? 0 : 0.3 }, 'io').to(B * 0.45, { [k.foot]: 0, bend: d * 1.2 }, 'io'); }
      t.to(400, o(both(6, -27), { x: 0, bend: 0, htilt: 0, ly: 0, pitch: -0.1 }), 'io').wait(300);                                       // peek-a-boo: hides his eyes ...
      t.to(260, o(hand(1, -1, -19), { lx: 0.4, htilt: 4 }), 'io').osc(500, 2, { sq: 0.025, htilt: 6 }, { sq: 0, htilt: 3 }, 'io')            // ... peeks out ...
        .to(240, o(hand(1, 6, -27), { lx: 0, htilt: 0, hap: 0 }), 'io').wait(160);
      t.to(140, o(both(-2, -18), { armL: 40, armR: 40, smile: 1, open: 0.45, blush: 0.9, pitch: 0.05, sq: -0.06, lift: 2 }), 'o')       // ... boo!
        .to(200, { sq: 0.04, lift: 0 }, 'i').to(300, o(P, { armL: 0, armR: 0, open: 0, sq: 0, pitch: -0.08, blush: 0.6, ly: 0.3 }), 'io');
      t.e('emit', 'note', 'head');
      for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1, k = S(d);                                                               // braver now: bigger shuffle, arms swing, head bobs
        t.to(B * 0.5, o(NOHANDS, { x: d * 3.4, bend: d * 3.5, htilt: -d * 2, [k.foot]: 2.2, armL: d < 0 ? 34 : 6, armR: d > 0 ? 34 : 6, ly: 0, pitch: -0.14, sq: 0.03, smile: 0.9 }), 'io')
          .to(B * 0.5, { [k.foot]: 0, pitch: -0.02, sq: 0 }, 'io'); }
      t.to(380, { x: 0, bend: 0, htilt: 0, armL: -10, armR: -10, sq: 0.16, pitch: -0.6, close: 1, smile: 0, ly: 0 }, 'io');               // curls into a spiky ball ...
      let a = t.t; t.to(1150, { spin: 360 }, 'io').to(1, { spin: 0 }, 'l'); t.at(a).osc(1150, 2, { lift: 1.5 }, { lift: 0 }, 'io').at(a + 1151);
      t.to(160, { sq: -0.12, pitch: 0.08, close: 0, armL: 60, armR: 60, lift: 5, wide: 0.4, smile: 1, open: 0.4 }, 'o').e('emit', 'spark', 'head', 3) // ... and pops open
        .to(220, { lift: 0, sq: 0.08, pitch: 0 }, 'i').to(190, { sq: 0, armL: 10, armR: 10, wide: 0 }, 'io');
      a = t.t; t.to(300, { armR: 112, hRy: -3, htilt: 4, blush: 1, open: 0 }, 'io').osc(1000, 3, { armR: 100 }, { armR: 124 }, 'io');     // tiny shy wave
      t.to(Math.max(200, 20 * B - t.t), o(P, { armR: 0, armL: 0, htilt: 0, blush: 0.45, smile: 0.5, ly: 0.3, pitch: -0.08 }), 'io');
      return t.loop({ stretch: 0.4, soft: 0.8 }); })(), 'Spike Shuffle', 'A shy side shuffle with paws clasped, peek-a-boo behind his paws, a braver shuffle, curls into a spiky ball and rolls round, pops open, tiny shy wave.'],
    happy: [(() => { const t = TL(o(both(6, -8), { hap: 1, smile: 0.9, blush: 0.8 }));
      swing(t, 1600, 3, { x: 1.8, bend: 2.5, tilt: 2, htilt: -2 });
      jump(t, { h: 5, ant: 200, up: 220, c: 0.12, arm: 14 }); t.e('emit', 'heart', 'head', 1).wait(200);
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Happy', 'Rocks shyly from side to side with happy closed eyes and pink cheeks, a small hop, a heart.'],
    surprised: [(() => { const t = TL();
      t.wait(150).to(70, { wide: 1, sq: 0.06 }, 'o').to(240, o(both(4, 2), { sq: 0.17, pitch: -0.6, close: 1, armL: -10, armR: -10 }), 'o'); // instantly curls into a ball
      t.osc(900, 9, { x: 0.45 }, { x: -0.45 }, 'l').to(60, { x: 0 });                                                                  // trembling
      t.wait(250).to(420, { close: 0.55, sq: 0.14, pitch: -0.46, lx: 0.5, ly: -0.2, wide: 0.4 }, 'io').wait(300)                          // peeks out ...
        .to(260, { lx: -0.5 }, 'io').wait(250).to(200, { lx: 0 }, 'io');
      t.to(700, o(both(6, -8), { sq: 0, pitch: -0.08, close: 0, armL: 0, armR: 0, wide: 0, ly: 0.3, blush: 0.9, smile: 0.6 }), 'io').wait(500); // ... slowly uncurls, blushing
      return t.rest(600).done(); })(), 'Surprised', 'Curls into a ball at once and trembles, peeks out, then slowly uncurls, blushing.'],
    quirk: [(() => { const t = TL();
      t.to(380, o(both(6, -27), { pitch: -0.12, blush: 0.6 }), 'io').wait(350);                                                           // hides his face
      t.to(300, o(hand(-1, -1, -19), { hyaw: -0.25, lx: -0.6, htilt: -3 }), 'io').wait(450).to(260, o(hand(-1, 6, -27), { hyaw: 0, lx: 0, htilt: 0 }), 'io'); // peeks left
      t.to(300, o(hand(1, -1, -19), { hyaw: 0.25, lx: 0.6, htilt: 3 }), 'io').wait(450).to(260, o(hand(1, 6, -27), { hyaw: 0, lx: 0, htilt: 0 }), 'io');      // peeks right
      t.to(320, o(both(6, -8), { blush: 1, smile: 0.7, pitch: -0.06 }), 'io').wait(500);
      return t.rest(600).done(); })(), 'Peek', 'Hides his face behind his paws and peeks out one side, then the other, blushing.'],
    squish: [(() => { const t = TL();
      t.to(150, { sq: -0.04 }, 'o').to(380, o(both(4, 2), { sq: 0.4, pitch: -0.5, close: 1, armL: -10, armR: -10 }), 'io').wait(420);
      t.to(160, o(NOHANDS, { sq: -0.12, pitch: 0.05, close: 0, armL: 40, armR: 40, smile: 0.8, blush: 0.9 }), 'o').to(200, { sq: 0.05, pitch: 0 }, 'io').to(200, { sq: 0, armL: 0, armR: 0 }, 'io')
        .to(220, { smile: 0, blush: 0 }, 'io');
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Squish', 'Curls into a tight ball when squeezed, unrolls with a stretch and a shy smile.'],
    press: { pitch: -0.45, sqz: 0.4, bristle: 1 }, // squeezed: his spines stand up
    rel: { dur: 1200, k: { sq: [[0, 0], [160, -0.12, 'o'], [360, 0.05, 'io'], [560, 0, 'io']], lift: [[0, 0], [160, 2.5, 'o'], [360, 0, 'i']],
      blush: [[0, 0], [200, 0.9, 'io'], [900, 0.9], [1200, 0, 'io']], smile: [[0, 0], [200, 0.7, 'io'], [900, 0.7], [1200, 0, 'io']] } },
  };

  // ===== Waffles (corgi loaf): 'Loaf Hop' - goofy, bouncy, stub tail never stops =====
  MOVES.waffles = {
    dance: [(() => { const t = TL({ smile: 0.8, hap: 1, open: 0.3, tongue: 0.6 }), B = 500;
      t.e('emit', 'note', 'head');
      swing(t, 4 * B, 11, { tilt: 6, x: 1, bend: 2, htilt: -3, wag: 36 });                                                                 // corgi butt wiggle
      for (let i = 0; i < 4; i++) jump(t, { h: 8, ant: 110, up: 150, dn: 130, c: 0.15, arm: 34, chain: i < 3, air: { wag: i % 2 ? 30 : -30 }, fall: { wag: 0 } });     // four loaf hops
      t.e('emit', 'note', 'head').to(260, { sq: 0.36, armL: 34, armR: 34, pitch: -0.1, open: 0.35 }, 'i').to(90, { sq: 0.32 }, 'io');         // the sploot: flops flat ...
      a = t.t; swing(t, 700, 5, { wag: 32 }); t.at(a).to(350, { htilt: 5 }, 'io').to(350, { htilt: 0 }, 'io').at(a + 700);
      t.to(150, { sq: 0.4 }, 'io'); jump(t, { h: 7, ant: 120, up: 180, c: 0.42, arm: 50 });                                                // ... and springs back up
      t.e('emit', 'note', 'head').to(160, { lean: -2, tilt: -4, sq: 0.06, earL: 10, earR: 10, tongue: 1, open: 0.45 }, 'io');             // zoomies: two spins, leaning in
      a = t.t; t.to(1500, { spin: 720 }, 'io').to(1, { spin: 0 }, 'l'); t.at(a).to(500, { x: -6, tilt: -7, lean: -3 }, 'io').to(500, { x: 6, tilt: 7, lean: 3 }, 'io').to(500, { x: 0, tilt: 0, lean: 0 }, 'io');
      t.at(a).em(1400, 200, 'dust', 'footL', 1); t.at(a); steps(t, 1500, 12, 3); t.at(a + 1501).to(300, { sq: 0, earL: 0, earR: 0, tongue: 0.6, open: 0.3 }, 'io');
      t.to(300, { pitch: -0.32, sq: 0.1, armL: -12, armR: -12, ly: 0.2 }, 'io'); swing(t, 800, 5, { tilt: 4, wag: 36 });                    // play bow + butt wiggle ...
      t.to(110, { pitch: -0.1, open: 0.85, mw: 0.85, sq: -0.06, earL: -6, earR: -6 }, 'o').e('emit', 'note', 'head').to(160, { open: 0.3, mw: 1, sq: 0.03, earL: 0, earR: 0 }, 'io'); // ... BOOF!
      t.to(300, { pitch: 0, sq: 0, armL: 0, armR: 0, ly: 0, open: 0.3, tongue: 0.6 }, 'io');
      return t.loop({ stretch: 0.7 }); })(), 'Loaf Hop', 'Corgi butt wiggle, four loaf hops, a sploot (flops flat) and springs back up, zoomies (two spins), play bow and a happy boof.'],
    happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.35, tongue: 0.7 });
      t.to(120, { sq: 0.1, lean: -2 }, 'io'); const a = t.t; t.to(700, { spin: 360 }, 'io').to(1, { spin: 0 }, 'l'); t.at(a).to(350, { sq: -0.04, lean: -3, tilt: -5, x: -2 }, 'io').to(350, { sq: 0, lean: 0, tilt: 0, x: 0 }, 'io');
      t.at(a + 701); jump(t, { h: 8, ant: 130, up: 170, c: 0.15, arm: 36, ev: [['emit', 'heart', 'head', 1]] });
      const L = t.t; t.at(0); swing(t, L, 23, { wag: 36 }); t.at(L);
      return Object.assign(t.loop(), { dur: L * 3 }); })(), 'Happy', 'A happy zoomie spin and a hop, stub tail going frantic, tongue out.'],
    surprised: [(() => { const t = TL();
      t.wait(150).to(80, { sq: 0.08, wide: 1, earL: -10, earR: -10 }, 'o');
      t.to(260, { x: -6, lean: -4, tilt: -3, sq: 0.06 }, 'o').e('emit', 'dust', 'footR', 3).to(220, { lean: -1, tilt: 0, sq: 0 }, 'io');   // skids backwards, feet planted
      t.to(110, { open: 0.85, mw: 0.85, sq: -0.08, pitch: 0.1 }, 'o').e('emit', 'note', 'head').to(200, { open: 0.15, mw: 1, sq: 0.03, pitch: 0 }, 'io'); // BOOF
      t.wait(200).to(420, { htilt: 13, earL: 4, earR: -6, open: 0, lx: 0.3 }, 'io').wait(600);                                          // head tilt
      t.e('blink').to(400, { htilt: 0, earL: 0, earR: 0, lx: 0, wide: 0, hap: 1, smile: 1, open: 0.3 }, 'io');
      const a = t.t; t.osc(1000, 6, { wag: 34 }, { wag: -34 }, 'io'); t.at(a).to(1000, { x: 0, lean: 0 }, 'io');
      return t.rest(450).done(); })(), 'Surprised', 'Ears shoot up, skids backwards, one big boof, a head tilt - then his stub tail starts going.'],
    quirk: [(() => { const t = TL();
      t.to(300, { pitch: -0.3, sq: 0.1, armL: -12, armR: -12, close: 0.6 }, 'io').to(400, { pitch: -0.36, sq: 0.13, lean: 0.8, open: 0.5, mw: 0.9 }, 'io'); // stretch (play-bow stretch, little yawn)
      t.to(300, { pitch: 0, sq: 0, armL: 0, armR: 0, lean: 0, open: 0, mw: 1, close: 0.85 }, 'io');
      t.to(220, { sq: 0.06, pitch: -0.1, close: 1 }, 'io');                                                                // braces for it: a little squat, head down, eyes shut
      t.em(900, 130, 'dust', 'body', 1); shake(t, { P: 110, head: 0.4, roll: 5, ear: 14, chest: 0.3, body: 1.2, tail: 36 }); // the wet-dog shake
      t.to(220, { sq: 0, pitch: 0, close: 0 }, 'io').e('blink').to(150, { earL: -7 }, 'o').to(200, { earL: 0, hap: 1, smile: 1, open: 0.3, tongue: 0.6 }, 'io').wait(500); // fluffed up and happy
      return t.rest(450).done({ stretch: 0, soft: 0.6 }); })(), 'Stretch and shake', 'A play-bow stretch with a little yawn, then a wet-dog shake: he braces, his head twists left and right with his body following a moment later, it builds up and dies away with his ears flapping, then a happy blink.'],
    squish: [(() => { const t = TL();
      t.to(150, { sq: -0.05 }, 'o').to(340, { sq: 0.42, hap: 0.9, armL: 24, armR: 24, earL: 12, earR: 12 }, 'io').wait(400);
      t.to(120, { sq: -0.22, armL: -4, armR: -4, earL: -8, earR: -8, hap: 0, smile: 1, open: 0.4, tongue: 0.6 }, 'o'); jelly(t, 0.12, 3, 220);
      t.to(160, { earL: 0, earR: 0, armL: 0, armR: 0, smile: 0, open: 0, tongue: 0 }, 'io');
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Squish', 'Squashed flat like bread dough, then springs back with a doughy wobble.'],
    press: { tongue: 0.5, open: 0.2 },
    rel: { dur: 1100, k: { sq: [[0, 0], [110, -0.22, 'o'], [230, 0.12, 'io'], [350, -0.06, 'io'], [470, 0.03, 'io'], [600, 0, 'io']], lift: [[0, 0], [120, 3, 'o'], [270, 0, 'i']],
      wag: [[0, 0], [100, 34], [200, -34], [300, 34], [400, -34], [500, 30], [600, -20], [750, 0]], smile: [[0, 0], [150, 1, 'o'], [800, 1], [1100, 0, 'io']] } },
  };

  // ===== Poppy (guinea pig): 'Popcorn Bounce' - sudden popcorn jumps, wheeks =====
  const popcorn = (t, h, d, len) => { const a = t.t; len = len || 520;                                                                     // a guinea-pig popcorn: NO wind-up, straight up with a mid-air twist
    t.to(len * 0.4, { lift: h, tilt: d * 14, turn: d * 0.35 }, 'o').to(len * 0.4, { lift: 0, tilt: 0, turn: 0 }, 'i'); const b = t.t;
    t.at(a).to(60, { sq: -0.14 }, 'o').to(len * 0.8 - 60, { sq: -0.05 }, 'io').to(90, { sq: 0.14 }, 'o').to(len * 0.2 - 90 + 60, { sq: -0.03 }, 'io').to(140, { sq: 0 }, 'io');
    return t.at(b).wait(len * 0.2 + 200); };
  MOVES.poppy = {
    dance: [(() => { const t = TL({ smile: 0.7 }), B = 500;
      t.e('emit', 'note', 'head');
      let a = t.t; steps(t, 3 * B, 12, 1.8); t.at(a); swing(t, 3 * B, 5, { x: 1.5, pitch: -0.05 }); t.at(a).osc(3 * B, 12, { sq: 0.02 }, { sq: 0 }, 'o').at(a + 3 * B); // pitter-patter, nose twitching
      t.to(140, { pitch: 0.22, open: 0.65, mw: 0.75, sq: -0.04 }, 'o').e('emit', 'note', 'head').to(200, { pitch: 0.18, open: 0.5 }, 'io').to(160, { pitch: 0, open: 0, mw: 1, sq: 0 }, 'io'); // wheek!
      t.to(80, { wide: 0.6 }, 'o'); popcorn(t, 11, 1); t.wait(80); popcorn(t, 9, -1, 480); t.wait(260); popcorn(t, 12, 1, 540);             // popcorning (irregular, like the real thing)
      t.to(100, { wide: 0, hap: 1 }, 'io');
      for (let i = 0; i < 4; i++) t.to(140, { pitch: 0.18, open: 0.6, mw: 0.75, sq: -0.04, lift: 1 }, 'o').e('emit', 'note', 'head').to(360, { pitch: -0.04 * (i < 3), open: 0, mw: 1, sq: 0.03 * (i < 3), lift: 0 }, 'io'); // wheek song
      a = t.t; t.to(1500, { spin: 360 }, 'io').to(1, { spin: 0 }, 'l'); t.at(a).to(300, { lean: 2.5, tilt: 4, pitch: -0.12 }, 'io').wait(900).to(300, { lean: 0, tilt: 0, pitch: 0 }, 'io'); // runs a little circle
      t.at(a); steps(t, 1500, 10, 2.4); t.at(a + 1501);
      popcorn(t, 14, -1, 600);                                                                                                               // a big popcorn
      a = t.t; swing(t, 1400, 3, { tilt: 5, x: 1.5, bend: 2.5, htilt: -2 }); t.at(a + 600).to(120, { winkR: 1 }, 'o').to(260, { winkR: 0 }, 'io').at(a + 1400);
      t.to(150, { hap: 0, smile: 0.7 }, 'io');
      return t.loop({ stretch: 0.8 }); })(), 'Popcorn Bounce', 'Pitter-patter feet, a wheek, three sudden popcorn jumps with a twist in the air, a wheek song, runs a little circle, a big popcorn and a cheeky wink.'],
    happy: [(() => { const t = TL({ hap: 1, smile: 1 });
      popcorn(t, 10, 1); t.wait(100); popcorn(t, 12, -1, 560);
      t.to(140, { pitch: 0.18, open: 0.6, mw: 0.75 }, 'o').e('emit', 'note', 'head').to(260, { pitch: 0, open: 0, mw: 1 }, 'io').wait(200);
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Happy', 'Two popcorn jumps with a twist in the air and a happy wheek.'],
    surprised: [(() => { const t = TL();
      t.wait(150).to(70, { wide: 1, sq: 0.06, earL: -10, earR: -10 }, 'o').wait(500);                                                    // freezes ...
      let a = t.t; t.to(320, { x: -7, lean: -2.5 }, 'o'); t.at(a); steps(t, 320, 4, 2.2); // ... zips backwards
      t.at(a + 320).to(130, { lean: 0, pitch: 0.22, open: 0.8, mw: 0.7 }, 'o').e('emit', 'note', 'head').to(300, { pitch: 0, open: 0.1, mw: 1 }, 'io'); // alarm wheek
      t.wait(300).to(300, { lx: 0.7, ly: 0.1 }, 'o').wait(300).to(300, { lx: 0, earL: 0, earR: 0, wide: 0.3, open: 0 }, 'io');
      a = t.t; t.to(800, { x: 0 }, 'io'); t.at(a); steps(t, 800, 6, 1.6);
      return t.at(a + 801).rest(450).done(); })(), 'Surprised', 'Freezes, zips backwards on pattering feet, an alarm wheek, then creeps back.'],
    quirk: [(() => { const t = TL();
      t.to(300, { pitch: -0.2, ly: 0.5, sq: 0.03 }, 'io').e('emit', 'crumb', 'mouth', 2);                                                 // munching hay
      const a = t.t; t.osc(1600, 8, { open: 0.3, mw: 0.75, sq: 0.05, pitch: -0.26, htilt: 3 }, { open: 0.03, mw: 1, sq: 0.02, pitch: -0.16, htilt: -3 }, 'io');
      t.at(a + 400).e('emit', 'crumb', 'mouth', 1).at(a + 1000).e('emit', 'crumb', 'mouth', 1).at(a + 1600);
      t.to(200, { pitch: 0, ly: 0, sq: 0, htilt: 0, open: 0, mw: 1 }, 'io').to(140, { earR: -18 }, 'o').to(240, { earR: 0 }, 'io');     // ear flick
      t.osc(420, 4, { pitch: 0.05, sq: 0.015 }, { pitch: 0, sq: 0 }, 'o').to(160, { sq: 0.05, pitch: -0.15 }, 'io').to(200, { sq: 0, pitch: 0, hap: 1, smile: 1 }, 'io'); // nose twitch, gulp
      return t.wait(300).rest(450).done(); })(), 'Hay munch', 'Munches some hay, an ear flick, a nose twitch and a gulp.'],
    squish: [(() => { const t = TL();
      t.to(130, { sq: -0.05 }, 'o').to(320, { sq: 0.38, open: 0.55, mw: 0.75, wide: 0.6 }, 'io').e('emit', 'note', 'head').wait(400);
      t.to(10, { open: 0, mw: 1, wide: 0 }); popcorn(t, 9, 1, 480); t.to(100, {});
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Squish', 'Squeaks when squeezed, then pops straight up in a popcorn jump.'],
    press: { open: 0.4, mw: 0.8 },
    rel: { dur: 900, k: { lift: [[0, 0], [200, 9, 'o'], [400, 0, 'i']], tilt: [[0, 0], [200, 12, 'o'], [400, 0, 'i']], turn: [[0, 0], [200, 0.3, 'o'], [400, 0, 'i']],
      sq: [[0, 0], [60, -0.14, 'o'], [380, -0.04, 'io'], [460, 0.12, 'o'], [600, -0.03, 'io'], [740, 0, 'io']] }, em: [['note', 'head', 1]] },
  };

  // ===== Duchess (Persian with a crown): 'Royal Sway' - slow, graceful waltz, chin up =====
  MOVES.duchess = {
    dance: [(() => { const t = TL({ pitch: 0.1, close: 0.3, smile: 0.6 }), BAR = 2000, b3 = BAR / 3;                                  // 3/4 time, a bar = 2 s
      t.e('emit', 'spark', 'head', 2);
      for (let j = 0; j < 2; j++) { const d = j ? 1 : -1;                                                                              // waltz sway: down on one, rise on two-three
        t.to(b3, { sq: 0.06, x: d * 2.4, bend: d * 3, tilt: d * 2, htilt: -d * 1.5, lift: 0, wag: d * 14, armR: 40 + j * 6, hRy: -2 }, 'io').to(b3 * 2, { sq: -0.03, lift: 1.6, bend: d * 1.4, tilt: d * 0.6 }, 'io'); }
      t.to(600, { x: 0, bend: 0, tilt: 0, htilt: 0, sq: 0, lift: 0, wag: 0, armL: 72, armR: 72, hRy: 0, close: 0.15 }, 'io');           // the twirl
      let a = t.t; t.to(2400, { spin: 360 }, 'io').to(1, { spin: 0 }, 'l'); t.at(a).to(1200, { lift: 3, sq: -0.04, curl: 0.5 }, 'io').to(1200, { lift: 0, sq: 0, curl: 0 }, 'io');
      t.at(a + 600).e('emit', 'spark', 'body', 3).at(a + 2401).to(1000, { armL: 0, armR: 0, close: 0.3 }, 'io');
      t.to(500, { armR: 100, hRx: -4, hRy: -3 }, 'io').to(500, { armR: 126, hRx: 3, hRy: -6 }, 'io').to(400, { armR: 92, hRx: 0, hRy: -2 }, 'io'); // paw flourish ...
      a = t.t; look(t, 0, 0.5, { k: 0.7, d1: 240, d2: 280 }); t.at(a + 1130).to(600, { close: 1 }, 'io').to(600, { close: 0.3 }, 'io');      // ... looks at you over it: a slow cat blink
      t.at(a + 1130 + 1200).to(500, { hyaw: 0, twist: 0, bend: 0, htilt: 0, lx: 0, armR: 0, hRx: 0, hRy: 0 }, 'io');
      t.to(700, { footL: 2.2, sq: 0.14, pitch: -0.16, armL: -14, armR: -14, x: 0.8, close: 0.6 }, 'io').wait(400)                          // a curtsy
        .to(Math.max(300, 12000 - t.t), { footL: 0, sq: 0, pitch: 0.1, armL: 0, armR: 0, x: 0, close: 0.3 }, 'io');
      return t.loop({ stretch: 0.3, soft: 0.8 }); })(), 'Royal Sway', 'A slow waltz sway with one paw raised daintily, an elegant twirl with sparkles, a paw flourish, a slow cat blink at you over her shoulder, and a curtsy.'],
    happy: [(() => { const t = TL({ pitch: 0.12, smile: 0.9, close: 0.35 });
      t.to(500, { x: 1.6, bend: 2, tilt: 1.5, wag: 14, curl: 0.4 }, 'io').to(500, { x: -1.6, bend: -2, tilt: -1.5, wag: -14, curl: 0.1 }, 'io');
      t.to(500, { close: 1, x: 0, bend: 0, tilt: 0, wag: 0, curl: 0 }, 'io').e('emit', 'heart', 'head', 1).to(600, { close: 0.35 }, 'io').wait(300);
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Happy', 'Pleased: chin up, a gentle sway with her tail curling, a slow cat blink and a heart.'],
    surprised: [(() => { const t = TL();
      t.wait(150).to(120, { wide: 1, sq: 0.05 }, 'o').to(380, o(hand(1, 6, -8), { lean: -4, x: -3, pitch: 0.24, open: 0.35, mw: 0.6, armR: 10, sq: 0 }), 'o') // draws back, paw to chest
        .wait(700).e('blink').to(500, { wide: 0, open: 0, mw: 1 }, 'io');
      t.to(400, o(hand(1, 4, -2)), 'io').to(400, o(hand(1, 6, -8)), 'io').to(300, o(hand(1, 4, -2)), 'io');                              // composes herself: smooths her fur
      t.to(500, o(hand(1, 0, 0), { armR: 0, close: 0.6, pitch: 0.3, hyaw: 0.4, lx: 0.5, htilt: -3 }), 'io').wait(700);                   // ... hmph
      t.to(600, { close: 0, pitch: 0, hyaw: 0, lx: 0, htilt: 0, lean: 0, x: 0 }, 'io');
      return t.rest(500).done(); })(), 'Surprised', 'Draws back with a paw to her chest, then composes herself, smooths her fur and turns away with a dignified hmph.'],
    quirk: [(() => { const t = TL();
      t.to(450, o(hand(1, 8, -6), { armR: 18, pitch: -0.14, ly: 0.7, htilt: 3 }), 'io');                                                 // looks down at her bow, paw on it ...
      t.to(220, { hRx: -10, hRy: -5 }, 'io').to(220, { hRx: -6, hRy: -6 }, 'io').to(200, { hRx: -9, hRy: -6 }, 'io').wait(200);       // ... and sets it straight
      t.to(450, o(hand(1, 13, -15), { armR: 20, ly: 0.3, pitch: -0.08 }), 'io').osc(700, 2, { tongue: 0.8, open: 0.12 }, { tongue: 0.1, open: 0 }, 'io'); // licks her paw
      t.to(400, o(hand(1, 0, 0), { armR: 0, tongue: 0, pitch: 0.18, close: 0.5, smile: 0.8, ly: 0 }), 'io').wait(600);                  // chin up, proud
      return t.rest(600).done(); })(), 'Fixes her bow', 'Looks down and sets her bow straight with a paw, licks the paw, lifts her chin.'],
    squish: [(() => { const t = TL();
      t.to(150, { sq: -0.04 }, 'o').to(380, { sq: 0.34, sqz: 0.8, frown: 0.4, armL: 14, armR: 14 }, 'io').to(300, { sqz: 0, close: 0.8, frown: 0, smile: 0.6 }, 'io');
      t.to(140, { sq: -0.12, close: 0, armL: 0, armR: 0 }, 'o').to(180, { sq: 0.04 }, 'io');
      shake(t, { P: 95, env: [0.5, 1, 0.7, 0.35], head: 0.12, roll: 2, ear: 6, body: 0.45 }); t.to(200, { sq: 0, smile: 0 }, 'io'); // a dainty little fluff-shake
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Squish', 'Not amused at first, then eyes close and she quite likes it; fluffs herself back up.'],
    press: { close: 0.5, pitch: 0.15 },
    rel: { dur: 1100, k: { sq: [[0, 0], [140, -0.12, 'o'], [320, 0.04, 'io'], [480, 0, 'io']], x: [[0, 0], [480, 0], [580, 0.45, 'io'], [680, -0.4, 'io'], [780, 0.25, 'io'], [880, -0.1, 'io'], [980, 0, 'io']],
      pitch: [[0, 0], [200, 0.18, 'io'], [800, 0.18], [1100, 0, 'io']], close: [[0, 0], [200, 0.5, 'io'], [800, 0.5], [1100, 0, 'io']] }, em: [['spark', 'head', 2]] },
  };

  // ===== Mama Paws (big dog carrying her pup): 'Puppy Pile Jelly' - gentle, soft, protective (the pup joins in during any dance) =====
  MOVES.mamapaws = {
    dance: [(() => { const P = both(6, -6), t = TL(o(P, { smile: 0.85 })), B = 600;
      t.e('emit', 'heart', 'head', 1);
      let a = t.t; swing(t, 4 * B, 3, { x: 2, tilt: 3, bend: 2.5, htilt: -2, sq: 0.03 }); t.at(a).to(400, { hap: 0.9 }, 'io').at(a + 4 * B); // jelly sway, rocking the pup
      a = t.t; for (let i = 0; i < 4; i++) t.to(160, { sq: 0.13 }, 'io').to(200, { sq: -0.06 }, 'o').to(140, { sq: 0.035 }, 'io').to(100, { sq: 0 }, 'io'); // soft jelly bounces
      let e = t.t; t.at(a); swing(t, 8 * B, 23, { wag: 24 }); t.at(e);                                                                    // double wag
      t.e('emit', 'note', 'head').to(500, { twist: -0.35, turn: -0.06, pitch: -0.22, htilt: -6, ly: 0.7, lx: -0.3, hap: 0 }, 'io')        // shows the pup off: nuzzles it ...
        .osc(500, 1, { htilt: -9 }, { htilt: -5 }, 'io').e('emit', 'heart', 'head', 1).to(600, { twist: 0.35, turn: 0.06, htilt: 6, lx: 0.3 }, 'io')
        .osc(500, 1, { htilt: 9 }, { htilt: 5 }, 'io').to(300, { twist: 0, turn: 0, pitch: 0, htilt: 0, ly: 0, lx: 0, hap: 0.9 }, 'io');
      jump(t, { h: 5, ant: 260, up: 260, c: 0.12, arm: 0, chain: true }); land(t, 0.1, 4, 280);                                         // a careful little hop, jelly landing
      a = t.t; t.to(400, o(hand(1, 0, 0), { armR: 118, hRy: -3 }), 'io').osc(1200, 3, { armR: 104 }, { armR: 130 }, 'io'); e = t.t;      // waves (one paw keeps the pup safe)
      t.at(a); swing(t, 1600, 1, { x: 2.5, tilt: 3, bend: 3 }); t.at(e);
      t.to(500, o(P, { armR: 0, hap: 0 }), 'io');
      return t.loop({ stretch: 0.4 }); })(), 'Puppy Pile Jelly', 'A soft jelly sway rocking her pup, wobbly jelly bounces, shows the pup off with nuzzles and hearts, a careful little hop and a wave - the pup dances along.'],
    happy: [(() => { const P = both(6, -6), t = TL(o(P, { hap: 1, smile: 1 }));
      for (let i = 0; i < 2; i++) t.to(200, { sq: 0.12 }, 'io').to(240, { sq: -0.06, lift: 2 }, 'o').to(200, { sq: 0.04, lift: 0 }, 'i').to(200, { sq: 0 }, 'io');
      t.to(400, { pitch: -0.2, htilt: -5, ly: 0.6 }, 'io').e('emit', 'heart', 'head', 2).to(400, { pitch: 0, htilt: 0, ly: 0 }, 'io');
      const L = t.t; t.at(0); swing(t, L, 11, { wag: 26 }); t.at(L);
      return Object.assign(t.loop(), { dur: L * 3 }); })(), 'Happy', 'Soft happy bounces, hugs her pup close, hearts, tail wagging.'],
    surprised: [(() => { const t = TL();
      t.wait(150).to(100, { wide: 1, earL: -10, earR: -10, sq: 0.05 }, 'o');
      t.to(380, o(both(8, -6), { twist: -0.45, turn: -0.08, sq: 0.08, lean: -1.5, x: -1.5 }), 'io');                                      // turns to shield her pup
      look(t, 0, -0.5, { k: 0.4 }); t.wait(200);
      const a = t.t; t.to(500, { hyaw: 0.45, lx: 0.9 }, 'io').wait(400).to(400, { hyaw: 0, lx: 0 }, 'io'); t.at(a + 1300);              // checks around
      t.to(700, o(both(6, -6), { twist: 0, turn: 0, bend: 0, htilt: 0, sq: -0.06, lean: 0, x: 0, close: 0.7, earL: 0, earR: 0, wide: 0 }), 'io') // relieved sigh
        .to(500, { sq: 0.03, close: 0, smile: 0.8 }, 'io').to(300, { sq: 0 }, 'io');
      return t.rest(500).done(); })(), 'Surprised', 'Turns to shield her pup, ears up, checks around, then a big relieved sigh.'],
    quirk: [(() => { const t = TL();
      t.to(600, { pitch: -0.28, ly: 0.8, htilt: -4, smile: 0.7 }, 'io');                                                                 // looks down at her pup
      t.osc(1600, 2, { htilt: -9, x: 0.8, tilt: 1.5, close: 0.6 }, { htilt: -3, x: -0.8, tilt: -1.5, close: 0.2 }, 'io').e('emit', 'heart', 'head', 1); // nuzzles and rocks
      t.to(500, { pitch: 0, ly: 0, htilt: 0, x: 0, tilt: 0, close: 0, hap: 1 }, 'io').wait(400);
      return t.rest(500).done(); })(), 'Nuzzle the pup', 'Looks down at her pup, nuzzles it and rocks it gently, a heart.'],
    squish: [(() => { const t = TL();
      t.to(160, { sq: -0.04 }, 'o').to(400, { sq: 0.36, hap: 0.9, earL: 5, earR: 5 }, 'io').wait(400);
      t.to(150, { sq: -0.14, hap: 0, smile: 1, earL: -6, earR: -6 }, 'o'); jelly(t, 0.12, 4, 300); t.to(200, { smile: 0, earL: 0, earR: 0 }, 'io');
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Squish', 'Squashed into a soft cuddle, then a slow jelly wobble.'],
    press: { hap: 0.4 },
    rel: { dur: 1600, k: { sq: [[0, 0], [150, -0.14, 'o'], [300, 0.1, 'io'], [450, -0.06, 'io'], [600, 0.035, 'io'], [750, -0.015, 'io'], [900, 0, 'io']],
      smile: [[0, 0], [200, 1, 'io'], [1200, 1], [1600, 0, 'io']] }, em: [['heart', 'head', 2]] },
  };

  // ===== Ribbit (frog): 'Lily Pad Hop' - springy squats, big leaps, croaks =====
  const croak = (t, n, per) => { for (let i = 0; i < n; i++) t.to(per * 0.35, { puff: 1.1, pitch: 0.06 }, 'o').to(per * 0.65, { puff: 0, pitch: 0 }, 'io'); return t; };
  MOVES.ribbit = {
    dance: [(() => { const t = TL({ smile: 0.85 }), B = 500;
      t.e('emit', 'note', 'head');
      for (let i = 0; i < 3; i++) t.to(200, { sq: 0.26, armL: 30, armR: 30, pitch: -0.08 }, 'io').to(150, { sq: -0.13, lift: 2.5, armL: 8, armR: 8, pitch: 0.06 }, 'o').to(150, { sq: 0, lift: 0, pitch: 0 }, 'i'); // squat-spring
      t.to(120, { armL: 0, armR: 0 }, 'io').e('emit', 'note', 'head'); croak(t, 1, 450);
      jump(t, { h: 15, ant: 160, up: 260, dn: 240, c: 0.26, arm: 60, x: -6, st: 1.1, air: { tilt: -3 }, fall: { tilt: 0 } });                // leaps to the left ...
      jump(t, { h: 17, ant: 150, up: 280, dn: 260, c: 0.26, arm: 60, x: 6, st: 1.1, air: { tilt: 3 }, fall: { tilt: 0 } });                 // ... right across ...
      jump(t, { h: 13, ant: 150, up: 240, dn: 220, c: 0.24, arm: 50, x: 0, st: 1.1 });                                                     // ... and home
      t.e('emit', 'note', 'head').to(200, { close: 0.85, hap: 1 }, 'io'); let a = t.t;                                                     // croak song
      croak(t, 4, 400); t.at(a); swing(t, 1600, 3, { tilt: 3, bend: 2, x: 1 }); t.at(a + 1600);
      t.to(100, { close: 0, hap: 0 }, 'io');
      t.to(250, { lx: -0.8, ly: -0.9, pitch: 0.15 }, 'o').wait(250).to(500, { lx: 0.8, hyaw: 0.2 }, 'io').wait(150);                     // a fly! eyes track it ...
      t.to(90, { tongue: 1, open: 0.5, pitch: 0.2, sq: -0.05 }, 'o').to(130, { tongue: 0, open: 0, sq: 0.08, pitch: -0.06 }, 'io')        // ... zap
        .to(160, { lx: 0, ly: 0, hyaw: 0, pitch: 0, sq: 0, hap: 1 }, 'io').wait(120);
      jump(t, { h: 20, ant: 220, up: 330, dn: 300, c: 0.3, arm: 80, spin: 360, st: 1.15, land: { sq: 0.38, armL: 40, armR: 40 }, ev: [['emit', 'splash', 'body', 1], ['emit', 'heart', 'head', 1]] }); // belly flop with a spin
      t.to(150, { hap: 0 }, 'io');
      return t.loop({ stretch: 0.7 }); })(), 'Lily Pad Hop', 'Squat-spring bounces, a croak, big leaps left and right, a croak song with his throat puffing, catches a fly with his tongue, and a spinning belly flop splash.'],
    happy: [(() => { const t = TL({ hap: 1, smile: 1 });
      jump(t, { h: 12, ant: 150, up: 220, c: 0.24, arm: 50, st: 1.2 }); croak(t, 1, 340);
      jump(t, { h: 14, ant: 140, up: 240, c: 0.26, arm: 56, st: 1.2, ev: [['emit', 'splash', 'body', 1]] }); croak(t, 1, 340);
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Happy', 'Springy happy hops, a croak with his throat puffing after each.'],
    surprised: [(() => { const t = TL();
      t.wait(120).to(70, { wide: 1, sq: 0.12 }, 'o');
      jump(t, { h: 14, ant: 50, up: 240, c: 0.12, arm: 70, st: 1.3, land: { sq: 0.3 } }); t.to(200, { sq: 0.14 }, 'io');                  // springs straight up, lands in a squat
      croak(t, 1, 400); look(t, 0, -0.55, { k: 0.6 }); t.wait(150);
      const a = t.t; look(t, -0.55, 0.55, { k: 0.6 }); t.wait(150); look(t, 0.55, 0, { k: 0.6 });
      t.to(400, { sq: 0, wide: 0, smile: 0.8 }, 'io');
      return t.rest(500).done(); })(), 'Surprised', 'Eyes bulge, springs straight up and lands in a squat, a croak, then looks around.'],
    quirk: [(() => { const t = TL();
      t.to(220, { lx: -0.8, ly: -0.6 }, 'o').wait(200).to(600, { lx: 0.8, ly: -0.8, hyaw: 0.15 }, 'io').to(500, { lx: -0.2, ly: -0.5, hyaw: 0 }, 'io').wait(120); // watches a fly
      t.to(120, { sq: 0.1, pitch: -0.06 }, 'io').to(80, { tongue: 1, open: 0.5, sq: -0.06, pitch: 0.16 }, 'o').to(140, { tongue: 0, open: 0, sq: 0.06, pitch: -0.06 }, 'io'); // zap
      t.to(200, { sq: 0, pitch: 0, lx: 0, ly: 0 }, 'io').to(160, { sq: 0.06, puff: 0.5 }, 'o').to(200, { sq: 0, puff: 0, hap: 1, smile: 1 }, 'io'); // gulp
      t.to(260, o(both(8, 2)), 'io').osc(500, 2, { hLy: 4, hRy: 0 }, { hLy: 0, hRy: 4 }, 'io').to(240, o(NOHANDS), 'io');                 // pats his belly
      return t.wait(200).rest(450).done(); })(), 'Fly snack', 'Watches a fly buzz past, zaps it with his tongue, gulps and pats his belly.'],
    squish: [(() => { const t = TL();
      t.to(130, { sq: -0.05 }, 'o').to(320, { sq: 0.36, puff: 1.2, armL: 30, armR: 30, wide: 0.5 }, 'io').wait(380);
      t.to(10, { puff: 0 }); jump(t, { h: 12, ant: 40, up: 220, c: 0.36, arm: 60, st: 1.3 }); t.to(100, { wide: 0 }, 'io');
      return Object.assign(t.loop(), { dur: t.t * 3 }); })(), 'Squish', 'Squeezed, his throat puffs right out - let go and he springs up high.'],
    press: { puff: 1.1, wide: 0.4 },
    rel: { dur: 1000, k: { lift: [[0, 0], [260, 13, 'o'], [500, 0, 'i']], sq: [[0, 0], [60, -0.18, 'o'], [260, -0.04, 'io'], [420, -0.08, 'i'], [520, 0.22, 'o'], [660, -0.04, 'io'], [800, 0, 'io']],
      armL: [[0, 0], [260, 60, 'o'], [500, 20, 'io'], [800, 0, 'io']], armR: [[0, 0], [260, 60, 'o'], [500, 20, 'io'], [800, 0, 'io']] } },
  };

  // ---------- install (also used by snack-anims.js for the Snack Shack) ----------
  const PRESS = R.PRESS = R.PRESS || {}, REL = R.REL = R.REL || {};
  const install = (MOVES, CARDS) => { const ST = {}, QUIRK = [];
    Object.keys(MOVES).forEach(key => { const M = MOVES[key], D = DESC[key] = DESC[key] || {};
      ['dance', 'happy', 'surprised', 'squish'].forEach(n => { if (M[n]) { ST[n + '@' + key] = M[n][0]; D[n] = [M[n][1], M[n][2]]; } });
      if (M.quirk) { ST['idle_quirk@' + key] = Object.assign(M.quirk[0], { next: 'idle' }); D.idle_quirk = [M.quirk[1], M.quirk[2]]; QUIRK.push(key); }
      if (M.look) ST['idle_look@' + key] = M.look;
      if (M.press) PRESS[key] = M.press; if (M.rel) REL[key] = M.rel; });
    // flavoured copies of the shared moves (only where the creature has no hand-made version)
    for (const key in CARDS) { CARD[key] = CARDS[key]; SHARED.forEach(n => { const nm = n + '@' + key; if (ST[nm] || R.STATES[nm] || !R.STATES[n]) return; const f = flavor(R.STATES[n], CARDS[key]); if (f) ST[nm] = f; }); }
    R.add(ST);
    // the house fidget list: add each creature's habit (FIDK is filled by house-idle when the house rigs are built - wait for it)
    // the house can build its fidget lists more than once (house-idle-c.js runs twice on Squad House v6, Nov 9: the 2nd build dropped the snacks'
    // habit), so every (re)build of a registered creature appends the habit again (HouseIdle.build is wrapped once)
    const QK = R.QUIRKK = R.QUIRKK || new Set(); QUIRK.forEach(k => QK.add(k));
    const hook = () => { const W = window.HouseIdle; if (!W || W.__q) return; W.__q = 1; const b = W.build;
      W.build = function (key) { const r = b.apply(this, arguments); const L = R.FIDK[key]; if (QK.has(key) && L && !L.includes('idle_quirk')) L.push('idle_quirk'); return r; }; };
    let tries = 0; (function addFid() { hook(); let left = 0; QUIRK.forEach(key => { const L = R.FIDK[key]; if (!L) { left++; return; } if (!L.includes('idle_quirk')) L.push('idle_quirk'); });
      if (left && ++tries < 120) setTimeout(addFid, 100); else if (left && R.idleV) QUIRK.forEach(key => { if (!R.FIDK[key]) R.FIDK[key] = R.FIDGETS.filter(n => n !== 'idle_waveL').concat('idle_quirk'); }); })(); };
  R.add({ idle_quirk: Object.assign({}, R.STATES.idle_yawn, { next: 'idle' }) }); // the plain state setState needs (creatures without a habit yawn)
  R.PETLIB = { TL, S, hand, both, o, NOHANDS, jump, look, shake, swing, steps, jelly, land, popcorn, croak, CARD, DESC, install, flavor }; // shared with pet-pokes / pet-eats / snack-*.js
  install(MOVES, Object.assign({}, CARD)); R.HS = R.HS || {};
  // the page's move list: the habit sits in the Idle group (shown only for creatures that have one)
  const G = R.GROUPS.find(g => g.name === 'Idle'); if (G && !G.items.some(i => i[0] === 'idle_quirk')) G.items.splice(2, 0, ['idle_quirk', 'Little habit', 'A habit of its own.']);
})();
