// Renovation Catalog round 2: catalog edits (delete / rename / merge with a colour picker / new rows) + rebuilt pieces with live SMIL animation.
// Loaded after reno-draw.js; the page calls RenoDraw.edit(rows) after parsing the CSV.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.H && X && X.ARCH && X.ARCH.sign && X.SIGNST)) { setTimeout(boot, 30); return; } if (RD.PLUS) return;
  const K = X.K, { solid, box, cush, cyl, ball, slab, slabX, arcW, disc, pillowY, pillowZ, shade, f1 } = K;
  const N = RD.N, M = RD.MAP, em = RD.H.em, NE = K.NEON, GOLD = '#e2b14a', CH = '#d5dde2', WH = '#ffffff', GL = '#cfe8f2', PI = Math.PI, IRON = '#3b3c40';
  const metal = k => k === 'royal' ? GOLD : k === 'candy' ? '#e9ecef' : k === 'junk' ? '#7d7f84' : k === 'mod' ? '#2c2d31' : k === 'retro' ? CH : IRON;
  const mt = o => Object.assign({ mat: 'metal' }, o || {});
  const rep = (n, f) => Array.from({ length: n }, (_, i) => f(i));
  // ---------- SMIL + projection helpers ----------
  const an = (a, v, d, b, kt) => '<animate attributeName="' + a + '" values="' + v + '" dur="' + d + 's"' + (kt ? ' keyTimes="' + kt + '"' : '') + (b ? ' begin="' + b + 's"' : '') + ' repeatCount="indefinite"/>';
  const at = (t, v, d, b, kt) => '<animateTransform attributeName="transform" type="' + t + '" values="' + v + '" dur="' + d + 's"' + (kt ? ' keyTimes="' + kt + '"' : '') + (b ? ' begin="' + b + 's"' : '') + ' repeatCount="indefinite"/>';
  const P2 = q => f1(q[0]) + ' ' + f1(q[1]);
  const about = (q, anim, s) => '<g transform="translate(' + P2(q) + ')"><g>' + anim + '<g transform="translate(' + f1(-q[0]) + ' ' + f1(-q[1]) + ')">' + s + '</g></g></g>';
  const fixed = (q, tf, s) => '<g transform="translate(' + P2(q) + ') ' + tf + ' translate(' + f1(-q[0]) + ' ' + f1(-q[1]) + ')">' + s + '</g>';
  const n4 = v => Math.round(v * 1e4) / 1e4;
  const mtx = (o, a, b) => 'matrix(' + [a[0] - o[0], a[1] - o[1], b[0] - o[0], b[1] - o[1], o[0], o[1]].map(n4).join(' ') + ')';
  const plane = (p, z, y) => mtx(p(0, y, z), p(1, y, z), p(0, y - 1, z));   // wall-facing plane: u = +x, w = down
  const planeH = (p, y) => mtx(p(0, y, 0), p(1, y, 0), p(0, y, 1));          // floor-parallel plane: u = +x, w = +z
  const xe = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const bob = (a, d) => at('translate', '0 0;0 ' + (-a) + ';0 0', d);
  const GLOW = '<filter id="gw" x="-40%" y="-80%" width="180%" height="260%"><feGaussianBlur stdDeviation="1.6" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>';
  const steam = (c, x, y, z, s, n) => { const q = c.p(x, y, z); let o = '<g transform="translate(' + P2(q) + ') scale(' + f1(c.k * (s || 1)) + ')">'; for (let i = 0; i < (n || 3); i++) { const dx = (i - ((n || 3) - 1) / 2) * 4; o += '<path d="M' + dx + ' 0q-3 -5 0 -10t0 -10" fill="none" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round" opacity="0">' + an('opacity', '0;0.8;0', 2.4, -i * 0.8) + at('translate', '0 0;0 -9', 2.4, -i * 0.8) + '</path>'; } return o + '</g>'; };
  const drip = (c, x, y0, y1, z, col, d, b) => { const a = c.p(x, y0, z), e = c.p(x, y1, z); return '<circle cx="' + f1(a[0]) + '" cy="' + f1(a[1]) + '" r="' + f1(0.9 * c.k) + '" fill="' + col + '">' + an('cy', f1(a[1]) + ';' + f1(e[1]), d || 0.9, b) + an('opacity', '1;1;0', d || 0.9, b) + '</circle>'; };
  const spark = (c, x, y, z, s, b, col) => '<g transform="translate(' + P2(c.p(x, y, z)) + ') scale(' + f1(c.k * (s || 1)) + ')"><path d="M0 -4L1 -1L4 0L1 1L0 4L-1 1L-4 0L-1 -1Z" fill="' + (col || '#ffffff') + '" opacity="0">' + an('opacity', '0;1;0;0', 1.8, b) + '</path></g>';
  const bubbles = (c, x, y, z, w, n, col) => rep(n, i => { const q = c.p(x + (i * 37 % 100 / 100 - 0.5) * w, y, z), r = f1((1 + (i % 3) * 0.6) * c.k), d = (1.6 + (i % 4) * 0.3).toFixed(1), b = (-i * 0.37).toFixed(2); return '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + r + '" fill="none" stroke="' + (col || '#ffffff') + '" stroke-width="0.7">' + an('cy', f1(q[1]) + ';' + f1(q[1] - 22 * c.k), d, b) + an('opacity', '0;1;0', d, b) + '</circle>'; }).join('');
  const plate = (x, y, z, r, col, o) => solid(Object.assign({ ax: 'x', sh: 'el', c: [z, y], a: r, b: r, n: 16, rings: [[x - 0.7, 0], [x + 0.7, 0]], col, mat: 'cer' }, o || {}));
  const hash = s => { let h = 7; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) | 0; return Math.abs(h); };
  const rng = s => { let h = hash(s) || 1; return () => { h = (h * 1103515245 + 12345) | 0; return ((h >>> 8) & 0xffff) / 65536; }; };

  // ---------- seating: sofas / armchairs with iron frames, separate seat cushions, real capacity ----------
  N.rsofa = S => { const nm = S.nm, k = S.k, v = S.v;
    let shp = S.shape || (v === 'L' || /l-shaped|sectional|banquette/.test(nm) ? 'L' : v === 'U' || /horseshoe|u-shaped|booth/.test(nm) ? 'U' : v === 'pit' || /pit sofa|curved|conversation/.test(nm) ? 'pit' : '');
    let n = S.n || (v === '1' ? 1 : /two-seater|loveseat|2-seat|pair|bench/.test(nm) ? 2 : shp === 'L' ? 4 : shp ? 5 : 3); if (n === 1) shp = '';
    if (shp === 'L' && n < 3) n = 3; if (shp === 'U' && n < 4) n = 4;
    const fl = S.float || /levitat|floating|anti-grav|zero-g|hover/.test(nm), met = metal(k), SW = 58, AW = n === 1 ? 18 : 20, Dp = 88, ext = 62, by = 9 + (fl ? 14 : 0), wing = /wingback|throne/.test(nm);
    const anim = fl ? bob(5, 3.2) : '', pad = fl ? [0, 8, 0, 0] : null;
    if (shp === 'pit') { const R0 = 30 + n * 16, Rz = R0 * 0.75, a0 = PI * 1.02, a1 = PI * 1.98, zc = R0 * 0.35, sp = rep(n, i => { const a = a0 + (a1 - a0) * (i + 0.5) / n; return { x: Math.cos(a) * (R0 - 30), z: zc + Math.sin(a) * (Rz - 30), a }; });
      return { w: R0 * 2 + 10, d: Rz * 2, act: 'sit', seats: sp.map(s => ({ x: s.x, z: s.z, h: by + 30 })), anim, pad, build: P => { const o = [];
        if (fl) o.push(cyl(0, by - 7, zc - Rz * 0.4, R0 * 0.7, 2, '#8fe8ff', em({ rz: Rz * 0.4, op: 0.5, n: 20 })));
        else rep(n + 1, i => { const a = a0 + (a1 - a0) * i / n; o.push(cyl(Math.cos(a) * (R0 - 20), 0, zc + Math.sin(a) * (Rz - 20), 2.6, by, met, mt({ n: 8 }))); });
        o.push(arcW(0, by - 3, zc, R0 - 2, Rz - 2, 54, 3, a0, a1, met, mt({ n: 18 })), arcW(0, by, zc, R0, Rz, 58, 15, a0, a1, P.aD, { n: 18, soft: 1, mat: 'fab' }), arcW(0, by + 12, zc, R0 + 2, Rz + 2, 14, 46, a0, a1, P.a, { n: 18, soft: 1, mat: 'fab' }));
        sp.forEach(s => o.push(pillowY(s.x, by + 14, s.z, 50, 16, 44, P.aL, { yaw: s.a + PI / 2 })));
        [a0, a1].forEach(a => o.push(ball(Math.cos(a) * (R0 - 26), by + 4, zc + Math.sin(a) * (Rz - 26), 15, P.a, { k: 6, n: 14, soft: 1, shine: 0 })));
        return o; } }; }
    const cols = shp === 'L' ? n - 1 : shp === 'U' ? n - 2 : n, Wd = cols * SW + AW * 2, xs = rep(cols, i => -Wd / 2 + AW + SW * (i + 0.5)), eL = shp === 'L' || shp === 'U', eR = shp === 'U';
    const seats = xs.map(x => ({ x, z: 6, h: by + 30 })); if (eL) seats.push({ x: xs[0], z: Dp / 2 + ext / 2 - 2, h: by + 30 }); if (eR) seats.push({ x: xs[cols - 1], z: Dp / 2 + ext / 2 - 2, h: by + 30 });
    return { w: Wd, d: Dp + (eL ? ext : 0), act: 'sit', seats, anim, pad, build: P => { const o = [], fab = P.a, fL = P.aL, fD = P.aD, tuft = k === 'royal' || k === 'cot' || /tufted|chesterfield|wingback/.test(nm);
      if (!fl) { const lx = Wd / 2 - 7, lz = Dp / 2 - 9, L = [[-lx, -lz], [lx, -lz], [-lx, lz], [lx, lz]]; if (eL) L.push([-lx, lz + ext]); if (eR) L.push([lx, lz + ext]); if (Wd > 200) L.push([0, -lz], [0, lz]);
        L.forEach(([x, z]) => o.push(k === 'royal' ? ball(x, 0, z, 4.4, GOLD, mt({ k: 4, n: 10 })) : cyl(x, 0, z, 2.6, by - 1, met, mt({ n: 8, rg: [[0, 0, 0.65], [by - 1, 0, 1.1]] })))); }
      else o.push(cyl(0, by - 7, 0, Wd / 2 - 16, 2, '#8fe8ff', em({ rz: Dp / 2 - 14, op: 0.55, n: 20 })));
      o.push(box(0, by - 3, 0, Wd - 4, 3, Dp - 4, met, mt({ r: 5 })), box(0, by, 0, Wd - 6, 15, Dp - 6, fD, { r: 12, bev: 4, mat: 'fab' }));
      [eL && -1, eR && 1].filter(Boolean).forEach(sg => { const xc = sg * (Wd / 2 - (AW + SW) / 2), zc = Dp / 2 + ext / 2 - 6;
        o.push(box(xc, by - 3, zc, AW + SW - 4, 3, ext + 6, met, mt({ r: 4 })), box(xc, by, zc, AW + SW - 6, 15, ext + 6, fD, { r: 10, bev: 4, mat: 'fab' }), pillowY(sg * (Wd / 2 - AW - SW / 2), by + 14, Dp / 2 + ext / 2 - 3, SW - 3, 16, ext - 4, fL)); });
      xs.forEach(x => o.push(pillowY(x, by + 14, 6, SW - 3, 16, Dp - 32, fL)));
      const bh = wing ? 62 : k === 'mod' ? 40 : 48, bz = -Dp / 2 + 8;
      o.push(slab(0, by + 12, bz, Wd - AW * 2 + 8, bh, 14, fab, { r: k === 'mod' ? 8 : 16, soft: 1, mat: 'fab' }));
      xs.forEach(x => { o.push(pillowZ(x, by + 26, bz + 12, SW - 4, bh - 12, 12, fL)); if (tuft) [-14, 0, 14].forEach(t => o.push(ball(x + t, by + 26 + (bh - 12) * 0.55, bz + 18.2, 1.7, k === 'royal' ? GOLD : shade(fab, 0.7), mt({ k: 3, n: 8 })))); });
      [-1, 1].forEach(sg => { const e = sg < 0 ? eL : eR, z0 = -Dp / 2 + 3, z1 = Dp / 2 - 3 + (e ? ext : 0), x = sg * (Wd / 2 - AW / 2), ah = wing ? 40 : 32;
        o.push(box(x, by, (z0 + z1) / 2, AW, ah, z1 - z0, fab, { r: 7, soft: 1, mat: 'fab' }), solid({ ax: 'z', sh: 'el', c: [x, by + ah], a: AW / 2 + 2.5, b: 7, n: 14, rings: [[z0, 2.5, 0.85], [z0 + 2.5, 0], [z1 - 2.5, 0], [z1, 2.5, 0.85]], col: fab, soft: 1 }), disc(x, by + ah * 0.5, z1 + 0.2, AW / 2 - 2.5, 1.4, met, mt()));
        if (wing) o.push(slab(x, by + ah + 4, bz + 10, AW + 2, 26, 16, fab, { r: 12, soft: 1 })); });
      o.push(slabX(0, by + 1, Dp / 2 - 2.2, Wd - 10, 2, 1.6, met, mt({ r: 1 })));
      return o; } }; };
  // luxury sofas: carved feet, apron, deep button tufting or channel back, rolled arms, nailheads, bolsters
  N.luxSofa = S => { const n = S.n || 3, st = S.st || 'chester', gold = !!S.gold, legc = gold ? GOLD : S.wood || '#4a2c1a', SW = 56, AW = 24, Dp = 88, Wd = n * SW + AW * 2, by = 16, xs = rep(n, i => -Wd / 2 + AW + SW * (i + 0.5));
    const ah = st === 'chester' ? 40 : 30, bh = st === 'chester' ? 40 : 54, bz = -Dp / 2 + 9, brass = gold || S.brass, cz = 8, cd = Dp - 34, cf = cz + cd / 2;
    return { w: Wd + 8, d: Dp, act: 'sit', seats: xs.map(x => ({ x, z: 8, h: by + 30 })), build: P => { const o = [], fab = P.a, fL = shade(fab, 1.07), fD = shade(fab, 0.82), pip = brass ? GOLD : shade(fab, 0.68), plc = S.plinth, lm = gold ? mt({ k: 3, n: 8 }) : { k: 3, n: 8, mat: 'wood' };
      const pil = S.pil || (/^#(e|f|d)/i.test(fab) ? '#8a6a48' : '#e9d9b0'), thr = /^#(e|f)/i.test(fab) ? '#6b4426' : '#efe4cc';
      // base: marble plinth or carved apron on turned feet with bead moulding
      if (plc) { o.push(box(0, 0, 0, Wd - 8, by - 2, Dp - 10, plc, { r: 3, mat: 'cer' }), box(0, by - 2.4, 0, Wd - 7, 1.2, Dp - 9, GOLD, mt({ r: 3 })));
        const R = rng(S.nm); rep(6, () => o.push(box((R() - 0.5) * (Wd - 30), by - 6 - R() * 6, Dp / 2 - 4.9, 18 + R() * 20, 0.6, 0.2, '#c9b98a', { r: 0, noOut: 1 }))); }
      else { const lx = Wd / 2 - 9, lz = Dp / 2 - 11, L = [[-lx, -lz], [lx, -lz], [-lx, lz], [lx, lz]]; if (n >= 4) L.push([0, lz], [0, -lz]);
        L.forEach(([x, z]) => o.push(ball(x, 2.4, z, 3.6, legc, gold ? mt({ k: 4, n: 10 }) : { k: 4, n: 10, mat: 'wood' }), cyl(x, 4, z, 3, by - 8, legc, Object.assign({ n: 10, rg: [[0, 0, 0.7], [(by - 8) * 0.5, 0, 1.15], [by - 8, 0, 0.8]] }, gold ? { mat: 'metal' } : { mat: 'wood' })), cyl(x, 0, z, 2.6, 1.4, brass ? GOLD : '#2a1a10', mt({ n: 8 }))));
        o.push(box(0, by - 6, 0, Wd - 6, 5, Dp - 8, legc, gold ? mt({ r: 3 }) : { r: 3, mat: 'wood' }));
        const nb = Math.floor((Wd - 16) / 7); rep(nb, i => o.push(ball(-Wd / 2 + 8 + (i + 0.5) * (Wd - 16) / nb, by - 4.8, Dp / 2 - 3.6, 1.3, gold ? GOLD : shade(legc, 1.25), Object.assign({ sz: 0.6, noOut: 1 }, lm))));
        o.push(ball(0, by - 5, Dp / 2 - 3.2, 4.2, gold ? GOLD : shade(legc, 1.2), Object.assign({ sy: 0.7, sz: 0.5 }, lm)));
        if (gold) [-1, 1].forEach(sg => o.push(ball(sg * 14, by - 5, Dp / 2 - 3.4, 2.4, GOLD, mt({ sy: 0.6, sz: 0.5, k: 3, n: 8 })))); }
      // seat deck + skirt piping + nailhead band
      o.push(box(0, by, 0, Wd - 6, 16, Dp - 6, fD, { r: 10, bev: 4, mat: 'fab' }), slabX(0, by + 0.6, Dp / 2 - 3.2, Wd - 10, 1.6, 1.6, pip, brass ? mt({ r: 0.8 }) : { r: 0.8, mat: 'fab' }), slabX(0, by + 14, Dp / 2 - 3.6, Wd - AW * 2, 1.2, 1.2, shade(fab, 0.7), { r: 0.6, mat: 'fab', noOut: 1 }));
      if (brass) { const nn = Math.floor((Wd - 20) / 5); rep(nn, i => o.push(ball(-Wd / 2 + 10 + (i + 0.5) * (Wd - 20) / nn, by + 4, Dp / 2 - 2.6, 0.95, GOLD, mt({ k: 3, n: 6, noOut: 1 })))); }
      // seat cushions: boxed front border with welt piping top + bottom, button
      xs.forEach(x => { o.push(pillowY(x, by + 15, cz, SW - 3, 15, cd, fL), box(x, by + 16, cf - 1.4, SW - 7, 10, 2.4, shade(fab, 0.97), { r: 2, soft: 1, mat: 'fab' }));
        [by + 16.2, by + 26.4].forEach(y => o.push(slabX(x, y, cf - 0.1, SW - 7, 1.1, 1.1, pip, brass ? mt({ r: 0.5, noOut: 1 }) : { r: 0.5, mat: 'fab', noOut: 1 })));
        if (st === 'chester') o.push(ball(x, by + 30.6, cz + 4, 1.6, brass ? GOLD : shade(fab, 0.6), mt({ sy: 0.5, k: 3, n: 8, noOut: 1 }))); });
      // back
      o.push(slab(0, by + 12, bz, Wd - AW * 2 + 8, bh, 16, fab, { r: st === 'chester' ? 6 : 14, soft: 1, mat: 'fab' }));
      if (st === 'chester') { const rows = 3, cols = n * 3 + 1; rep(rows, j => rep(cols - (j % 2), i => { const x = -Wd / 2 + AW + (Wd - AW * 2) * (i + (j % 2 ? 1 : 0.5)) / cols, y = by + 20 + j * 10;
          o.push(ball(x, y, bz + 8.1, 3.6, shade(fab, 0.8), { sz: 0.22, k: 3, n: 10, noOut: 1, shine: 0 }), ball(x, y, bz + 8.7, 1.8, brass ? GOLD : shade(fab, 0.58), mt({ k: 3, n: 8, noOut: 1 }))); }));
        o.push(solid({ ax: 'x', sh: 'el', c: [bz + 2, by + 12 + bh], a: 9, b: 6, n: 14, rings: [[-Wd / 2 + AW - 2, 2.5, 0.85], [-Wd / 2 + AW + 1, 0], [Wd / 2 - AW - 1, 0], [Wd / 2 - AW + 2, 2.5, 0.85]], col: fab, soft: 1 }),
          slabX(0, by + 12 + bh - 5.4, bz + 9.4, Wd - AW * 2 - 2, 1.4, 1.2, pip, brass ? mt({ r: 0.6 }) : { r: 0.6, mat: 'fab' }));
        if (gold) o.push(ball(0, by + 12 + bh + 6, bz + 2, 4, GOLD, mt({ sy: 0.8, sz: 0.5, k: 4, n: 10 }))); }
      else { xs.forEach(x => [-1, 0, 1].forEach(t => o.push(pillowZ(x + t * 17, by + 26, bz + 9, 16, bh - 14, 8, t ? fab : fL)))); }
      // rolled arms: front panel, welt, rosette, nailhead column
      [-1, 1].forEach(sg => { const x = sg * (Wd / 2 - AW / 2), z0 = -Dp / 2 + 3, z1 = Dp / 2 - 3, xr = x + sg * 2;
        o.push(box(x, by, (z0 + z1) / 2, AW - 2, ah, z1 - z0, fab, { r: 6, soft: 1, mat: 'fab' }), solid({ ax: 'z', sh: 'el', c: [xr, by + ah], a: AW / 2 + 4, b: 8, n: 16, rings: [[z0, 2.5, 0.85], [z0 + 2.5, 0], [z1 - 2.5, 0], [z1, 2.5, 0.85]], col: fab, soft: 1 }));
        o.push(box(x, by + 2, z1 + 0.1, AW - 7, ah - 8, 1, shade(fab, 0.92), { r: 3, soft: 1, mat: 'fab' }), disc(xr, by + ah, z1 + 0.3, AW / 2 + 1, 1.2, shade(fab, 0.9), { mat: 'fab' }));
        o.push(solid(Object.assign({ ax: 'z', sh: 'arc', c: [xr, by + ah], a: AW / 2 + 1.6, b: 8.6, th: 1, a0: 0, a1: 2 * PI, n: 18, rings: [[z1 + 0.9, 0], [z1 + 1.7, 0]], col: pip, noOut: 1 }, brass ? { mat: 'metal' } : { mat: 'fab' })));
        o.push(ball(xr, by + ah, z1 + 1.6, 2.8, gold ? GOLD : shade(fab, 0.75), Object.assign({ sz: 0.5 }, gold ? mt({ k: 4, n: 10 }) : { k: 4, n: 10, mat: 'fab' })));
        if (brass) rep(6, i => o.push(ball(x, by + 4 + i * (ah - 12) / 5, z1 + 0.8, 1.1, GOLD, mt({ k: 3, n: 6, noOut: 1 }))));
        o.push(solid({ ax: 'x', sh: 'el', c: [-4, by + 26], a: 9, b: 9, n: 14, rings: [[sg * (Wd / 2 - AW - 1), 0, 0.7], [sg * (Wd / 2 - AW - 24), 0, 0.7]].sort((a, b) => a[0] - b[0]), col: shade(fab, 1.14), soft: 1, mat: 'fab' }));
        [sg * (Wd / 2 - AW - 1.5), sg * (Wd / 2 - AW - 23.5)].forEach(px => o.push(solid(Object.assign({ ax: 'x', sh: 'el', c: [-4, by + 26], a: 6, b: 6, n: 14, rings: [[px - 0.5, 0], [px + 0.5, 0]], col: pip, noOut: 1 }, brass ? { mat: 'metal' } : { mat: 'fab' })))); });
      // throw pillows with piping + corner tassels, lumbar in the middle
      [-1, 1].forEach(sg => { const px = sg * (Wd / 2 - AW - 22), pz = bz + 19, pc = sg < 0 ? pil : shade(pil, 0.88);
        o.push(pillowZ(px, by + 27, pz, 30, 28, 10, pc), slabX(px, by + 27 + 27, pz + 2, 28, 1, 1, shade(pc, 0.7), { r: 0.5, noOut: 1, mat: 'fab' }));
        [-14, 14].forEach(t => o.push(ball(px + t, by + 27 + 28, pz + 3, 1.6, brass ? GOLD : shade(pc, 0.7), { sy: 1.6, k: 3, n: 8 }))); });
      if (n >= 3) o.push(pillowZ(0, by + 28, bz + 20, 36, 16, 9, S.pil ? shade(S.pil, 1.1) : shade(fab, 1.18)), slabX(0, by + 36, bz + 25, 30, 4, 0.6, pip, brass ? mt({ r: 0.4, noOut: 1 }) : { r: 0.4, mat: 'fab', noOut: 1 }));
      // knit throw draped over the left arm, fringe on the end
      { const x = -(Wd / 2 - AW / 2) - 2, tz = 2; o.push(box(x, by + ah + 5.6, tz, AW + 6, 3.2, 30, thr, { r: 1.6, bev: 1.4, soft: 1, mat: 'fab' }), box(-Wd / 2 - 2.6, by + ah - 16, tz, 2.6, 24, 30, thr, { r: 1.2, soft: 1, mat: 'fab' }));
        [-9, 9].forEach(dz => o.push(box(x, by + ah + 8.9, tz + dz, AW + 6.4, 0.3, 3, pil, { r: 0, noOut: 1 }), box(-Wd / 2 - 4, by + ah - 16, tz + dz, 0.3, 24.4, 3, pil, { r: 0, noOut: 1 })));
        rep(8, i => o.push(box(-Wd / 2 - 2.6, by + ah - 20, tz - 13 + i * 3.7, 1, 4, 1, shade(thr, 0.9), { r: 0, noOut: 1 }))); }
      return o; } }; };
  N.luxDChair = S => { const gold = !!S.gold, legc = gold ? GOLD : S.wood || '#4a2c1a', st = S.st || 'tuft';
    return { w: 52, d: 54, act: 'sit', seats: [{ x: 0, z: 4, h: 46 }], build: P => { const o = [], fab = P.a, lm = gold ? mt({ n: 8 }) : { n: 8, mat: 'wood' };
      [[-17, -17], [17, -17], [-17, 17], [17, 17]].forEach(([x, z]) => o.push(cyl(x, 0, z, 2.4, 34, legc, Object.assign({}, lm, { rg: [[0, 0, 0.6], [26, 0, 1], [34, 0, 1.1]] }))));
      if (gold) [-17, 17].forEach(x => o.push(ball(x, 0.6, 17, 2.6, GOLD, mt({ k: 3, n: 8 }))));
      o.push(box(0, 31, 1, 42, 4, 42, legc, gold ? mt({ r: 3 }) : { r: 3, mat: 'wood' }), cush(0, 35, 2, 40, 9, 40, fab, { r: 12 }));
      const bh = 52; o.push(box(0, 38, -19, 40, bh, 7, legc, gold ? mt({ r: 12 }) : { r: 12, mat: 'wood' }), slab(0, 41, -15.4, 34, bh - 6, 4, fab, { r: 10, soft: 1, mat: 'fab' }));
      if (st === 'tuft') rep(3, j => rep(3 - (j % 2), i => o.push(ball(-11 + i * 11 + (j % 2) * 5.5, 52 + j * 11, -13, 1.5, gold ? GOLD : shade(fab, 0.6), mt({ k: 3, n: 8, noOut: 1 })))));
      else [-10, 0, 10].forEach(x => o.push(pillowZ(x, 44, -13.2, 9.4, bh - 12, 3, shade(fab, 1.06))));
      if (gold) o.push(ball(0, 38 + bh + 1, -19, 3.2, GOLD, mt({ k: 4, n: 10 })));
      return o; } }; };
  // low pine slat futon: thick tufted mattress folded into a couch, sagging in the middle
  N.futon = S => { const W = 150, Dp = 72, by = 13, pine = '#c9a26b', pD = shade(pine, 0.8);
    return { w: W + 12, d: Dp + 6, act: 'sit', seats: [{ x: -32, z: 8, h: by + 22 }, { x: 32, z: 8, h: by + 22 }], build: P => { const o = [], fab = '#5d6b8a', fL = shade(fab, 1.08), fD = shade(fab, 0.78), tie = shade(fab, 0.62);
      [-1, 1].forEach(sg => { const x = sg * (W / 2 + 2);
        [-Dp / 2 + 4, Dp / 2 - 4].forEach(z => o.push(box(x, 0, z, 6, 40, 6, pD, { r: 1.5, mat: 'wood' })));
        o.push(box(x, 26, 0, 7, 5, Dp, pine, { r: 1.5, mat: 'wood' }), box(x, 8, 0, 5, 4, Dp - 8, pD, { r: 1, mat: 'wood' }));
        rep(3, i => o.push(box(x, 12, -Dp / 2 + 18 + i * 18, 4, 14, 3, pine, { r: 1, mat: 'wood' }))); });
      o.push(box(0, by - 4, 0, W, 4, Dp - 6, pD, { r: 1, mat: 'wood' }));
      rep(7, i => o.push(box(-W / 2 + 10 + i * (W - 20) / 6, by + 8, -Dp / 2 + 1, 4, 44, 3, pine, { r: 1, mat: 'wood' })));
      o.push(slabX(0, by + 50, -Dp / 2 + 1, W + 4, 5, 4, pine, { r: 1.5, mat: 'wood' }));
      o.push(box(0, by, 3, W - 2, 10, Dp - 16, fD, { r: 6, soft: 1, mat: 'fab' }));
      [-1, 1].forEach(sg => o.push(pillowY(sg * 38, by + 9, 5, 64, 8, Dp - 20, fL, { mat: 'fab' })));
      o.push(solid({ ax: 'x', sh: 'el', c: [-Dp / 2 + 12, by + 13], a: 9, b: 8, n: 14, rings: [[-W / 2 + 1, 2, 0.85], [-W / 2 + 3, 0], [W / 2 - 3, 0], [W / 2 - 1, 2, 0.85]], col: fab, soft: 1, mat: 'fab' }));
      o.push(slab(0, by + 14, -Dp / 2 + 10, W - 2, 34, 12, fab, { r: 9, soft: 1, mat: 'fab' }));
      [-48, -16, 16, 48].forEach(x => { o.push(ball(x, by + 16.6, 4, 1.6, tie, { k: 3, n: 8, noOut: 1 }), ball(x, by + 34, -Dp / 2 + 16.4, 1.6, tie, { k: 3, n: 8, noOut: 1 })); });
      return o; } }; };
  N.rchair = S => { const k = S.k, nm = S.nm, met = metal(k), st = S.st2 || (/folding/.test(nm) ? 'fold' : /windsor|spindle/.test(nm) ? 'windsor' : /thonet|bentwood|cane/.test(nm) ? 'thonet' : /papasan/.test(nm) ? 'papasan' : /bouclé|boucle|upholstered|dining armchair/.test(nm) ? 'tub' : 'mod');
    const LG = [[-17, -17], [17, -17], [-17, 17], [17, 17]];
    if (st === 'fold') return { w: 48, d: 48, act: 'sit', seats: [{ x: 0, z: 4, h: 46 }], build: P => { const o = [], ir = k === 'junk' ? '#6b6e73' : IRON, wd = '#c49a62';
      LG.forEach(([x, z]) => o.push(cyl(x, 0, z, 1.7, 38, ir, mt({ n: 6 }))));
      o.push(slabX(0, 12, 17, 36, 1.6, 1.6, ir, mt({ r: 0.8 })), slabX(0, 12, -17, 36, 1.6, 1.6, ir, mt({ r: 0.8 })), box(0, 36, 2, 42, 3.4, 40, wd, { r: 2, mat: 'wood' }), cyl(-17, 38, -18, 1.7, 40, ir, mt({ n: 6 })), cyl(17, 38, -18, 1.7, 40, ir, mt({ n: 6 })), box(0, 60, -18.5, 40, 14, 3, wd, { r: 2, mat: 'wood' }), pillowY(0, 39.4, 4, 34, 7, 30, P.a));
      return o; } };
    if (st === 'windsor') return { w: 50, d: 50, act: 'sit', seats: [{ x: 0, z: 3, h: 44 }], build: P => { const o = [], pc = P.a, sh = 38;
      LG.forEach(([x, z]) => o.push(cyl(x * 0.95, 0, z * 0.95, 2.2, sh, pc, { n: 8, rg: [[0, 0, 0.7], [sh * 0.5, 0, 1.15], [sh, 0, 0.9]], mat: 'paint' })));
      o.push(slabX(0, 12, 0, 34, 2, 2, pc, { r: 1 }), cyl(0, sh, 2, 23, 5, pc, { rz: 21, rg: [[0, 0, 0.96], [3, 0, 1.02], [5, 0, 0.97]], mat: 'paint' }), cyl(-19, sh + 4, -17, 1.6, 12, pc, { n: 6 }), cyl(19, sh + 4, -17, 1.6, 12, pc, { n: 6 }));
      o.push(solid({ ax: 'z', sh: 'arc', c: [0, sh + 15], a: 20, b: 30, th: 3.2, a0: 0, a1: PI, n: 12, rings: [[-18.5, 0], [-15.5, 0]], col: pc, mat: 'paint' }));
      [-13, -6.5, 0, 6.5, 13].forEach(x => { const top = sh + 15 + 30 * Math.sqrt(Math.max(0, 1 - (x / 18.4) ** 2)) - 2; o.push(cyl(x, sh + 4, -17, 1.1, top - sh - 4, shade(pc, 0.92), { n: 6, mat: 'paint' })); });
      return o; } };
    if (st === 'thonet') return { w: 50, d: 50, act: 'sit', seats: [{ x: 0, z: 2, h: 44 }], build: P => { const o = [], wd = '#5e3a22', sh = 38;
      LG.forEach(([x, z]) => o.push(cyl(x * 0.9, 0, z * 0.9, 1.9, sh, wd, { n: 8, rg: [[0, 0, 0.75], [sh, 0, 1.05]], mat: 'wood' })));
      o.push(arcW(0, 13, 0, 17, 17, 1.8, 1.8, 0, 2 * PI, wd, { n: 18, mat: 'wood' }), cyl(0, sh, 1, 21, 4, wd, { n: 18, mat: 'wood' }), cyl(0, sh + 4, 1, 17.5, 0.8, '#d8b278', { n: 18, mat: 'fab' }));
      o.push(cyl(-15, sh + 2, -15, 1.8, 26, wd, { n: 6, mat: 'wood' }), cyl(15, sh + 2, -15, 1.8, 26, wd, { n: 6, mat: 'wood' }), solid({ ax: 'z', sh: 'arc', c: [0, sh + 28], a: 15, b: 16, th: 2.6, a0: 0, a1: PI, n: 12, rings: [[-16.3, 0], [-13.7, 0]], col: wd, mat: 'wood' }), solid({ ax: 'z', sh: 'arc', c: [0, sh + 20], a: 9, b: 12, th: 2, a0: 0, a1: PI, n: 10, rings: [[-16, 0], [-14, 0]], col: wd, mat: 'wood' }), slab(0, sh + 6, -15, 30, 10, 2, '#d8b278', { r: 4, mat: 'fab' }));
      return o; } };
    if (st === 'tub') return { w: 56, d: 54, act: 'sit', seats: [{ x: 0, z: 4, h: 44 }], build: P => { const o = [], c = P.a, br = k === 'royal' || /brass|gold/.test(nm) ? GOLD : met, sh = 30;
      LG.forEach(([x, z]) => o.push(cyl(x * 1.05, 0, z * 1.05, 1.9, sh, br, mt({ n: 8, rg: [[0, 0, 0.6], [sh, 0, 1.1]] }))));
      o.push(cush(0, sh, 2, 50, 12, 48, c, { r: 18 }), arcW(0, sh + 2, 2, 26, 25, 8, 30, PI * 0.92, PI * 2.08, c, { n: 14, soft: 1, mat: 'fab' }), arcW(0, sh + 31.4, 2, 26, 25, 8, 1.4, PI * 0.92, PI * 2.08, br, mt({ n: 14 })), pillowY(0, sh + 9, 6, 38, 6, 30, shade(c, 1.05)));
      return o; } };
    if (st === 'papasan') return { w: 84, d: 80, round: 1, act: 'sit', seats: [{ x: 0, z: 6, h: 40 }], build: P => { const rt = '#c99a5a';
      return [cyl(0, 0, 0, 22, 4, met, mt({ n: 18 })), cyl(0, 4, 0, 4, 12, met, mt({ n: 10 })), cyl(0, 16, 2, 38, 22, rt, { n: 24, rz: 34, rg: [[0, 0, 0.32], [8, 0, 0.72], [16, 0, 0.94], [22, 0, 1]], mat: 'wood' }), arcW(0, 36, 2, 39, 35, 2.4, 2.4, 0, 2 * PI, shade(rt, 0.8), { n: 24, mat: 'wood' }), ball(0, 32, 4, 33, P.a, { sy: 0.32, sz: 0.85, k: 6, n: 22, soft: 1, shine: 0 }), pillowZ(0, 40, -18, 46, 22, 12, shade(P.a, 1.08))]; } };
    return { w: 52, d: 52, act: 'sit', seats: [{ x: 0, z: 3, h: 46 }], build: P => { const o = [], sh = 36;
      LG.forEach(([x, z]) => o.push(cyl(x, 0, z, 2, sh, met, mt({ n: 8 }))));
      o.push(slabX(0, 10, 17, 34, 1.6, 1.6, met, mt()), slabX(0, 10, -17, 34, 1.6, 1.6, met, mt()), box(0, sh, 2, 46, 4, 44, met, mt({ r: 6 })), cush(0, sh + 3, 3, 44, 7, 42, P.a, { r: 12 }), cyl(-18, sh + 3, -19, 1.8, 34, met, mt({ n: 6 })), cyl(18, sh + 3, -19, 1.8, 34, met, mt({ n: 6 })), slab(0, sh + 12, -19.5, 44, 26, 4, P.a, { r: 10, soft: 1 }));
      return o; } };
  };
  // counter stools: 4 legs set so every leg shows in the 3/4 view (fixes the missing right leg), footrest ring
  N.barstool = S => { const k = S.k, h = 62, fl = /levitat|hydraulic/.test(S.nm), met = k === 'junk' ? '#7d7f84' : k === 'cot' ? '#a86b36' : k === 'mod' ? IRON : k === 'royal' ? GOLD : '#e9ecef';
    const LP = rep(4, i => { const t = (-7.5 + 90 * i) * PI / 180; return [13 * Math.cos(t), 13 * Math.sin(t)]; });
    return { w: 44, d: 44, round: 1, act: 'sit', seats: [{ x: 0, z: 0, h: h + (fl ? 16 : 9) }], anim: fl ? bob(4, 2.6) : '', pad: fl ? [0, 6, 0, 0] : null, build: P => { const o = [];
      if (fl) { o.push(cyl(0, 0, 0, 17, 4, '#3a3c48', mt({ n: 18 })), cyl(0, 4, 0, 12, 1.2, '#8fe8ff', em({ n: 16 })), cyl(0, 5, 0, 3.4, 36, '#c9d0d6', mt({ n: 10 })), cyl(0, 24, 0, 6, 1.2, '#8fe8ff', em({ n: 12, op: 0.7 })), cyl(0, h + 4, 0, 14, 2, '#8fe8ff', em({ n: 16, op: 0.6 })), cyl(0, h + 7, 0, 19, 9, '#f1eee8', { n: 18, rg: [[0, 0, 0.9], [5, 0, 1], [9, 0, 0.92]], soft: 1 })); return o; }
      LP.forEach(([x, z]) => o.push(cyl(x, 0, z, k === 'royal' ? 1.9 : 2.2, h, met, mt({ n: 8, rg: [[0, 0, 0.8], [h, 0, 1.05]] }))));
      o.push(arcW(0, h * 0.32, 0, 15, 15, 2, 2, 0, 2 * PI, k === 'royal' ? GOLD : met, mt({ n: 18 })), cyl(0, h - 3, 0, 14, 3, met, mt({ n: 16 })));
      if (k === 'junk') o.push(cyl(0, h, 0, 16, 4, '#8a8f94', mt({ n: 16 })), ball(-6, h + 3.4, 4, 2.4, '#a0603a', { sy: 0.3, k: 3, n: 8 }), ball(7, h + 3.4, -3, 1.8, '#a0603a', { sy: 0.3, k: 3, n: 8 }));
      else if (k === 'cot') o.push(cyl(0, h, 0, 18, 6, '#b98a58', { rz: 16, rg: [[0, 0, 0.9], [4, 0, 1], [6, 0, 0.96]], mat: 'wood' }));
      else if (k === 'royal') o.push(cyl(0, h - 1, 0, 18, 2, GOLD, mt({ n: 16 })), cush(0, h, 0, 34, 10, 34, /emerald/.test(S.nm) ? '#1f6a4c' : '#7f2030', { r: 15 }), ...[[-7, -7], [7, -7], [-7, 7], [7, 7], [0, 0]].map(([x, z]) => ball(x, h + 9.4, z, 1.4, GOLD, mt({ k: 3, n: 8 }))));
      else o.push(cyl(0, h, 1, 18, 5, /leather|tractor/.test(S.nm) ? '#a8592b' : P.a, { rz: 15, rg: [[0, 0, 0.85], [3, 0, 1], [5, 0, 0.92]], shine: 1 }), ...[[-6, 0], [0, -4], [6, 0], [0, 5]].map(([x, z]) => cyl(x, h + 5, z + 1, 1.4, 0.4, '#3a2a20', { n: 8, noOut: 1 })));
      return o; } }; };
  // one pouf, any colour; idle puff breathing + squish when sat on / poked
  N.puffPouf = S => ({ w: 72, d: 72, round: 1, act: 'sit', squish: 1, seats: [{ x: 0, z: 0, h: 34 }],
    wrap: (p, s) => about(p(0, 0, 0), at('scale', '1 1;1.035 0.95;0.985 1.03;1 1', 2.6), s),
    build: P => { const c = P.a, o = [ball(0, 0, 0, 33, c, { sy: 0.64, k: 8, n: 22, soft: 1, shine: 0, mat: 'fab' })];
      o.push(arcW(0, 20, 0, 33.4, 33.4, 1, 1.6, 0, 2 * PI, shade(c, 0.82), { n: 22, noOut: 1 }), ball(0, 40.6, 0, 3.4, shade(c, 0.72), { sy: 0.5, k: 3, n: 10 }));
      rep(6, i => { const a = i / 6 * 2 * PI + 0.3; o.push(ball(Math.cos(a) * 15, 37.6, Math.sin(a) * 15, 2, shade(c, 0.8), { sy: 0.4, k: 3, n: 8, noOut: 1 })); });
      return o; } });
  // ---------- living room wall pieces ----------
  N.calendar = S => ({ w: 76, d: 6, mount: 'wall', build: P => [slab(0, 0, -1.6, 72, 98, 1.6, '#c49a62', { r: 1, mat: 'wood' }), slab(0, 2, 0.1, 66, 90, 0.9, '#fffdf6', { r: 1, mat: 'paint' }), slab(0, 82, 1.1, 66, 10, 0.5, '#d9483b', { r: 1, noOut: 1 }), ball(0, 93, 1.6, 2.6, '#3f7fc8', { k: 3, n: 8 })],
    fx: c => { const d = new Date(), Y = d.getFullYear(), Mo = d.getMonth(), td = d.getDate(), f0 = new Date(Y, Mo, 1).getDay(), nd = new Date(Y, Mo + 1, 0).getDate(), mk = new Set(String(S.ex || '').split(',').filter(Boolean).map(Number));
      const MN = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'][Mo], WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getDay()];
      let g = '<text x="0" y="7.4" text-anchor="middle" font-family="Georgia, serif" font-weight="700" font-size="5.6" fill="#ffffff">' + MN + ' ' + Y + '</text>';
      'SMTWTFS'.split('').forEach((w, i) => g += '<text x="' + f1(-28.3 + i * 9.43) + '" y="15.6" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="3.6" fill="' + (i ? '#6b4426' : '#d9483b') + '">' + w + '</text>');
      for (let i = 0; i < nd; i++) { const cell = f0 + i, cx = f1(-28.3 + (cell % 7) * 9.43), cy = 23 + Math.floor(cell / 7) * 9.6, day = i + 1;
        if (day === td) g += '<circle cx="' + cx + '" cy="' + f1(cy - 1.3) + '" r="4.2" fill="#d9483b">' + an('r', '4.2;4.8;4.2', 1.6) + '</circle>';
        g += '<text x="' + cx + '" y="' + f1(cy) + '" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="3.8" fill="' + (day === td ? '#ffffff' : '#3b2614') + '">' + day + '</text>';
        if (day < td) g += '<path d="M' + f1(+cx - 3) + ' ' + f1(cy - 4.4) + 'L' + f1(+cx + 3) + ' ' + f1(cy + 1.4) + 'M' + f1(+cx + 3) + ' ' + f1(cy - 4.4) + 'L' + f1(+cx - 3) + ' ' + f1(cy + 1.4) + '" stroke="#d9483b" stroke-width="0.7" opacity="0.55"/>';
        if (mk.has(day)) g += '<circle cx="' + f1(+cx + 3.3) + '" cy="' + f1(cy - 4.2) + '" r="1.7" fill="#3f9a5a" stroke="#ffffff" stroke-width="0.4"/>'; }
      g += '<text x="0" y="86" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="3.8" fill="#8a5a34">Today · ' + WD + ' ' + td + '</text>';
      return { front: '<g transform="' + plane(c.p, 1.1, 92) + '">' + g + '</g>' }; } });
  const PAINT = ['Sunset Sea', 'Starry Swirl', 'Flower Garden', 'Squish Portrait', 'Abstract Flow'];
  N.masterpiece = S => ({ w: 130, d: 12, mount: 'wall', build: P => { const o = [slab(0, 0, -2.4, 126, 100, 5, GOLD, mt({ r: 3 })), slab(0, 7, 1.2, 112, 86, 1.4, shade(GOLD, 0.82), mt({ r: 2 })), slab(0, 11, 2.2, 104, 78, 0.6, '#2a2440', { r: 1, noOut: 1 })];
      [[-60, 2], [60, 2], [-60, 96], [60, 96]].forEach(([x, y]) => o.push(ball(x, y - 3, 2.4, 4.4, GOLD, mt({ k: 4, n: 10 }))));
      o.push(ball(0, 95, 2.6, 5, GOLD, mt({ sx: 2.4, sy: 0.7, k: 4 })), box(0, 100, 2, 3, 7, 6, GOLD, mt({ r: 1 })), slabX(0, 106, 7, 56, 4.4, 5, GOLD, mt({ r: 2 })), slabX(0, 105.4, 9.6, 50, 1, 1, '#fff1b0', em({ r: 0.5 })));
      return o; },
    fx: c => { const sty = Math.max(0, PAINT.indexOf(S.st)) | 0, id = 'mp' + sty, R = rng(S.row.id + sty);
      let g = '<clipPath id="' + id + '"><rect x="-52" y="0" width="104" height="78"/></clipPath><g clip-path="url(#' + id + ')">';
      if (sty === 0) { g += '<defs><linearGradient id="' + id + 's" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd27a"/><stop offset="0.6" stop-color="#ff8a5a"/><stop offset="1" stop-color="#8a5ab0"/></linearGradient></defs><rect x="-52" y="0" width="104" height="50" fill="url(#' + id + 's)"/>'
          + '<circle cx="14" cy="38" r="11" fill="#fff1b0">' + an('r', '11;12.6;11', 4) + '</circle>' + rep(3, i => '<ellipse cx="' + (-30 + i * 30) + '" cy="' + (10 + i * 5) + '" rx="13" ry="3.6" fill="#ffe6c4" opacity="0.8">' + at('translate', '0 0;' + (8 + i * 3) + ' 0;0 0', 9 + i * 2) + '</ellipse>').join('')
          + '<rect x="-52" y="46" width="104" height="32" fill="#2f5f9a"/><path d="M8 47h12l-2 4h-8Z" fill="#ffd27a" opacity="0.8">' + an('opacity', '0.5;0.95;0.5', 2) + '</path>'
          + rep(4, i => '<path d="' + rep(10, j => (j ? '' : 'M-76 ' + (52 + i * 7)) + 'q6 -' + (2 + i % 2) + ' 12 0t12 0').join('') + '" fill="none" stroke="' + ['#9fd2f2', '#cfe8f2', '#6ac8ff', '#ffffff'][i] + '" stroke-width="1.5" opacity="0.85">' + at('translate', '0 0;' + (i % 2 ? 24 : -24) + ' 0', 2.6 + i * 0.6) + '</path>').join(''); }
      else if (sty === 1) { g += '<rect x="-52" y="0" width="104" height="78" fill="#1d2f6a"/>' + rep(3, i => { const x = [-24, 10, 34][i], y = [22, 16, 34][i], r = [14, 10, 8][i]; return '<g transform="translate(' + x + ' ' + y + ')"><g>' + at('rotate', (i % 2 ? '360' : '0') + ';' + (i % 2 ? '0' : '360'), 12 + i * 4) + '<path d="M-' + r + ' 0a' + r + ' ' + r + ' 0 1 1 ' + 2 * r + ' 0a' + (r * 0.7) + ' ' + (r * 0.7) + ' 0 1 1 -' + (r * 1.4) + ' 0" fill="none" stroke="' + ['#9fd2f2', '#ffd66b', '#cfe8f2'][i] + '" stroke-width="2.4" stroke-dasharray="5 3" opacity="0.9"/></g></g>'; }).join('')
          + rep(12, i => '<circle cx="' + f1(-48 + R() * 96) + '" cy="' + f1(4 + R() * 40) + '" r="1.4" fill="#fff4b0">' + an('r', '0.8;2;0.8', 1.4 + (i % 4) * 0.4, -i * 0.3) + '</circle>').join('')
          + '<circle cx="38" cy="10" r="7" fill="#ffe680"/><circle cx="41" cy="8" r="6" fill="#1d2f6a"/><path d="M-52 78V58Q-30 48 -8 58T40 54T52 60V78Z" fill="#16233f"/>'
          + '<g transform="translate(-34 78)"><g>' + at('rotate', '-4;4;-4', 5) + '<path d="M-5 0Q-8 -30 0 -54Q8 -30 5 0Z" fill="#14301e"/></g></g>'; }
      else if (sty === 2) { g += '<rect x="-52" y="0" width="104" height="44" fill="#bfe4f2"/><rect x="-52" y="40" width="104" height="38" fill="#6aa65a"/><ellipse cx="-20" cy="40" rx="44" ry="8" fill="#7fbf64"/>'
          + rep(9, i => { const x = -46 + i * 11.5, y = 58 + (i % 3) * 6, h = 14 + (i % 3) * 5, col = ['#f2c94c', '#ef8f7f', '#b9a6e0', '#ffffff', '#e88a3a'][i % 5]; return '<g transform="translate(' + x + ' ' + y + ')"><g>' + at('rotate', '-7;7;-7', 2.6 + (i % 3) * 0.5, -i * 0.4) + '<path d="M0 0V-' + h + '" stroke="#3f7a3a" stroke-width="1.2"/>' + rep(5, j => '<circle cx="' + f1(Math.cos(j * 1.256) * 3) + '" cy="' + f1(-h + Math.sin(j * 1.256) * 3) + '" r="2.4" fill="' + col + '"/>').join('') + '<circle cx="0" cy="-' + h + '" r="1.6" fill="#8a5a34"/></g></g>'; }).join('')
          + '<g><animateMotion dur="7s" repeatCount="indefinite" path="M-40 30Q-10 6 14 26T44 18Q20 40 -40 30Z"/><path d="M0 0l-4 -3v6Z M0 0l4 -3v6Z" fill="#ffd66b"><animateTransform attributeName="transform" type="scale" values="1 1;0.3 1;1 1" dur="0.3s" repeatCount="indefinite"/></path></g><circle cx="38" cy="10" r="6" fill="#fff1b0"/>'; }
      else if (sty === 3) { g += '<rect x="-52" y="0" width="104" height="78" fill="#e9c98a"/><ellipse cx="0" cy="40" rx="50" ry="40" fill="#f6dfaa" opacity="0.6"/>'
          + '<g><animateTransform attributeName="transform" type="translate" values="0 0;0 -1.4;0 0" dur="2.4s" repeatCount="indefinite"/><path d="M-30 80Q-34 30 0 24Q34 30 30 80Z" fill="#9fdcc4"/><ellipse cx="0" cy="38" rx="26" ry="22" fill="#a9e4cc"/><path d="M-20 22l-6 -12l12 6Z M20 22l6 -12l-12 6Z" fill="#a9e4cc"/>'
          + ['-9', '9'].map(x => '<ellipse cx="' + x + '" cy="36" rx="3.4" ry="4.2" fill="#2a1a10">' + an('ry', '4.2;4.2;0.4;4.2', 4, 0, '0;0.9;0.95;1') + '</ellipse><circle cx="' + (+x + 1.2) + '" cy="34.4" r="1.2" fill="#ffffff"/>').join('')
          + '<ellipse cx="-15" cy="44" rx="4" ry="2.4" fill="#ef8f7f" opacity="0.7"/><ellipse cx="15" cy="44" rx="4" ry="2.4" fill="#ef8f7f" opacity="0.7"/><path d="M-4 45Q0 49 4 45" fill="none" stroke="#2a1a10" stroke-width="1.2" stroke-linecap="round"/></g>'
          + rep(5, i => '<path d="M' + (-46 + i * 22) + ' ' + (6 + (i % 2) * 8) + 'l1.4 3l3 1.4l-3 1.4l-1.4 3l-1.4 -3l-3 -1.4l3 -1.4Z" fill="#fffaf1">' + an('opacity', '0;1;0', 2, -i * 0.4) + '</path>').join(''); }
      else { g += '<rect x="-52" y="0" width="104" height="78" fill="#2a2440"/>' + rep(6, i => { const x = -40 + R() * 80, y = 10 + R() * 58, r = 14 + R() * 14, cs = NE.slice(i % 6).concat(NE.slice(0, i % 6)).slice(0, 4).concat(NE[i % 6]).join(';'); return '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(r) + '" opacity="0.72" fill="' + NE[i % 6] + '">' + an('fill', cs, 8 + i) + at('translate', '0 0;' + f1((R() - 0.5) * 30) + ' ' + f1((R() - 0.5) * 20) + ';0 0', 6 + i * 1.3) + '</circle>'; }).join('')
          + '<path d="M-52 60Q-20 20 10 50T52 30" fill="none" stroke="#fffaf1" stroke-width="2" opacity="0.6" stroke-dasharray="120" stroke-dashoffset="120">' + an('stroke-dashoffset', '120;0;-120', 6) + '</path>'; }
      g += rep(14, i => '<path d="M' + f1(-52 + i * 8) + ' 0l-6 78" stroke="#ffffff" stroke-width="0.6" opacity="0.05"/>').join('') + '<defs><linearGradient id="' + id + 'h" x1="0" y1="0" x2="1" y2="0" gradientTransform="translate(-1 0)"><stop offset="0.4" stop-color="#fff" stop-opacity="0"/><stop offset="0.5" stop-color="#fff" stop-opacity="0.22"/><stop offset="0.6" stop-color="#fff" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-1 0;1 0;1 0" keyTimes="0;0.4;1" dur="7s" repeatCount="indefinite"/></linearGradient></defs><rect x="-52" y="0" width="104" height="78" fill="url(#' + id + 'h)"/></g>';
      return { front: '<g transform="' + plane(c.p, 2.9, 89) + '">' + g + '<path d="M-26 -14H26L44 24H-44Z" fill="#fff6c8" opacity="0.14"/></g>' }; } });
  N.quote = S => { const k = S.k, t = (S.txt || S.row.txt0 || 'Home Sweet Home').slice(0, 26), W = Math.min(236, 40 + t.length * 8.6), Hh = 44, wood = k === 'cot' || k === 'retro';
    return { w: W + 10, d: 6, mount: 'wall', build: P => { const o = [];
        if (k === 'junk') o.push(slab(0, 4, 0, W, Hh - 6, 0.8, '#f4efe2', { r: 1, mat: 'paint' }), ...[-1, 1].map(s => slab(s * (W / 2 - 6), Hh - 8, 0.9, 16, 7, 0.4, '#f6efc8', { r: 0, op: 0.85, noOut: 1 })), slab(W / 2 - 10, 2, 0.9, 14, 6, 0.4, '#f6efc8', { r: 0, op: 0.85, noOut: 1 }));
        else if (wood) o.push(slab(0, 0, -1, W, Hh, 4, '#a8794a', { r: 5, mat: 'wood' }), ball(-W / 2 + 8, Hh - 7, 3.2, 1.8, '#6b6f74', mt({ k: 3, n: 8 })), ball(W / 2 - 8, Hh - 7, 3.2, 1.8, '#6b6f74', mt({ k: 3, n: 8 })));
        else if (k === 'candy') o.push(slab(0, -2, -1, W + 10, Hh + 4, 1.6, '#cfe8f2', { r: 8, op: 0.3, mat: 'cer' }), ...[[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([a, b]) => disc(a * (W / 2), Hh / 2 + b * (Hh / 2 - 4), 0.6, 2.2, 2, CH, mt())));
        else if (k === 'royal') o.push(...[-W / 3, 0, W / 3].map(x => ball(x, Hh / 2 + 3, -0.6, 1.4, GOLD, mt({ k: 3, n: 8 }))));
        else o.push(slab(0, 0, -1.4, W, Hh, 0.4, '#ffffff', { r: 2, op: 0.04, noOut: 1 }));
        return o; },
      fx: c => { const z = wood ? 3.2 : k === 'candy' ? 1 : 0.5, fam = k === 'junk' ? "'Comic Sans MS', 'Marker Felt', cursive" : wood ? "Georgia, 'Times New Roman', serif" : "'Brush Script MT', 'Segoe Script', 'Lucida Handwriting', cursive", fs = wood || k === 'junk' ? 17 : 24;
        const attr = ' x="0" y="' + f1(fs * 0.34) + '" text-anchor="middle" font-family="' + fam + '" font-size="' + fs + '" textLength="' + f1(W - 22) + '" lengthAdjust="spacingAndGlyphs"' + (wood ? ' font-style="italic" font-weight="700"' : '');
        let g;
        if (k === 'candy') g = '<g filter="url(#gw)"><text' + attr + ' fill="none" stroke="#ffd66b" stroke-width="2.6">' + xe(t) + an('opacity', '1;1;0.55;1;1;0.7;1', 5) + '</text><text' + attr + ' fill="none" stroke="#fffaf1" stroke-width="0.8">' + xe(t) + '</text></g>';
        else if (k === 'royal') g = '<text' + attr + ' fill="none" stroke="#8a6420" stroke-width="2.8">' + xe(t) + '</text><text' + attr + ' fill="none" stroke="' + GOLD + '" stroke-width="1.6">' + xe(t) + '</text>';
        else g = '<text' + attr + ' fill="' + (wood ? '#fffaf1' : k === 'junk' ? '#2a1a10' : '#2c2d31') + '"' + (k === 'junk' ? ' transform="rotate(-2)"' : '') + '>' + xe(t) + '</text>';
        return { defs: GLOW, front: '<g transform="' + plane(c.p, z, Hh / 2) + '">' + g + '</g>' }; } }; };
  N.rsign = S => { const D = X.ARCH.sign(S), F = D.face, T = X.SIGNST[S.st] || X.SIGNST.card, t = (S.txt || S.row.txt0 || 'DANCE!').slice(0, 22);
    D.fx = c => { const fs = Math.min(F.h * 0.66, F.w * 1.7 / Math.max(4, t.length)), fam = T.ff.replace(/"/g, "'"), fit = t.length * fs * T.cw > F.w * 0.92, glow = S.st === 'neon' || S.st === 'led' || S.st === 'marq';
      const attr = ' x="0" y="' + f1(fs * 0.34) + '" text-anchor="middle" font-family="' + fam + '" font-size="' + f1(fs) + '"' + (fit ? ' textLength="' + f1(F.w * 0.92) + '" lengthAdjust="spacingAndGlyphs"' : '') + (T.rot ? ' transform="rotate(' + T.rot + ')"' : '');
      let g = '<text' + attr + ' fill="' + T.col + '">' + xe(t) + '</text>';
      if (S.st === 'neon') g = '<g filter="url(#gw)"><text' + attr + ' fill="none" stroke="#ff4fd8" stroke-width="2.2">' + xe(t) + an('opacity', '1;1;0.5;1;1;1;0.75;1', 4.6) + '</text><text' + attr + ' fill="#ffffff">' + xe(t) + '</text></g>';
      if (S.st === 'led') g = '<clipPath id="lc"><rect x="' + f1(-F.w / 2) + '" y="' + f1(-F.h / 2) + '" width="' + f1(F.w) + '" height="' + f1(F.h) + '"/></clipPath><g clip-path="url(#lc)" filter="url(#gw)"><g>' + at('translate', '0 0;' + f1(-F.w) + ' 0;' + f1(F.w) + ' 0;0 0', 7, 0, '0;0.45;0.4501;1') + '<text x="0" y="' + f1(fs * 0.34) + '" text-anchor="middle" font-family="' + fam + '" font-size="' + f1(fs) + '" fill="' + T.col + '" letter-spacing="2">' + xe(t) + '</text></g></g>';
      if (S.st === 'marq') g = '<g>' + an('opacity', '1;0.86;1', 1.2) + g + '</g>';
      return { defs: glow ? GLOW : '', front: '<g transform="' + plane(c.p, F.z + 0.6, F.y) + '">' + g + '</g>' }; };
    return D; };

  // ---------- kitchen appliances ----------
  N.dripCoffee = S => ({ w: 48, d: 42, build: P => { const k = S.k, b = k === 'junk' ? '#2f3034' : k === 'cot' ? '#f1eee8' : P.a, o = [];
      o.push(box(0, 0, 2, 44, 7, 38, b, { r: 4, mat: 'paint' }), cyl(0, 7, 8, 12.5, 1.4, '#1d1d20', mt({ n: 18 })), box(0, 0, -13, 44, 66, 14, b, { r: 4, mat: 'paint' }), box(0, 52, 0, 44, 14, 40, b, { r: 5, bev: 2, mat: 'paint' }), slab(-15, 18, -5.6, 7, 30, 0.6, '#9fd2f2', { r: 2, op: 0.85, noOut: 1 }), disc(15, 4, 21.2, 2.2, 0.8, '#ff4a3a', em()));
      o.push(cyl(0, 44, 8, 11, 8, '#3a3a3e', { n: 16, rg: [[0, 0, 0.55], [8, 0, 1]] }), cyl(0, 8.6, 8, 11.2, 13, '#4a2a14', { n: 16, rg: [[0, 0, 0.92], [10, 0, 1.04], [13, 0, 1]] }), cyl(0, 8.4, 8, 12, 27, GL, { n: 16, rg: [[0, 0, 0.92], [10, 0, 1.06], [20, 0, 0.82], [27, 0, 0.86]], op: 0.5, mat: 'cer' }), cyl(0, 33, 8, 10.6, 3, '#1d1d20', { n: 14 }), box(14.5, 14, 8, 3, 16, 4, '#1d1d20', { r: 1.4 }), slabX(12, 28, 8, 6, 2.4, 3, '#1d1d20', { r: 1 }), slabX(12, 13, 8, 6, 2.4, 3, '#1d1d20', { r: 1 }));
      if (k === 'junk') o.push(slab(4, 13, 20.2, 0.7, 13, 0.3, WH, { r: 0, noOut: 1 }), slab(6, 20, 19.8, 0.6, 6, 0.3, WH, { r: 0, noOut: 1, op: 0.8 }));
      return o; },
    fx: c => ({ front: drip(c, 0, 43, 22, 8, '#5a3a20', 0.8) + drip(c, 0, 43, 22, 8, '#5a3a20', 0.8, -0.4) + steam(c, 0, 37, 8, 0.8, 3) + '<circle cx="' + f1(c.p(15, 4, 21.4)[0]) + '" cy="' + f1(c.p(15, 4, 21.4)[1]) + '" r="' + f1(2.6 * c.k) + '" fill="#ff4a3a" opacity="0.3">' + an('opacity', '0.1;0.5;0.1', 1.6) + '</circle>' }) });
  N.podBrewer = S => ({ w: 42, d: 50, build: P => { const b = P.a;
      return [box(0, 0, 0, 36, 6, 44, '#2c2d31', { r: 4 }), box(0, 6, -10, 36, 50, 24, b, { r: 6, bev: 2, mat: 'paint' }), box(0, 56, -4, 36, 10, 36, b, { r: 8, bev: 3, mat: 'paint' }), box(0, 66, -4, 30, 2, 28, shade(b, 1.15), { r: 6 }), box(0, 6, -26, 30, 46, 8, GL, { r: 4, op: 0.5, mat: 'cer' }), box(0, 7, -26, 27, 32, 6, '#7ac8f0', { r: 3, op: 0.7, noOut: 1 }),
        box(0, 6, 12, 30, 3, 18, '#3a3a3e', mt({ r: 3 })), cyl(0, 52, 9, 3, 4, '#2c2d31', mt({ n: 8 })), cyl(-1, 9, 12, 7.5, 13, WH, { n: 14, mat: 'cer' }), cyl(-1, 21.4, 12, 6.6, 0.6, '#5a3a20', { n: 14, noOut: 1 }), box(8.5, 13, 12, 3, 8, 2.4, WH, { r: 1.4 }), slab(0, 42, 2.4, 22, 8, 0.6, '#1d2030', { r: 3 }), disc(-6, 46, 3.2, 1.6, 0.4, '#6ac8ff', em()), disc(0, 46, 3.2, 1.6, 0.4, '#a6f06a', em()), disc(6, 46, 3.2, 1.6, 0.4, '#ffd66b', em())]; },
    fx: c => ({ front: drip(c, 0, 51, 22, 9, '#5a3a20', 0.7) + drip(c, 0, 51, 22, 9, '#5a3a20', 0.7, -0.35) + steam(c, -1, 23, 12, 0.7, 2) }) });
  // toaster: bread sticks out of the slots; loop = press down, toast, pop. st: '' fresh | 'in' toasting | 'pop' popped toast
  N.toaster = S => { const st = S.st, k = S.k, toast = st === 'pop', L = 'translate', KT = '0;0.1;0.16;0.68;0.73;0.8;1';
    const slice = z => () => [slab(0, 30.4, z, 28, 16, 3.6, toast ? '#8a4a1e' : '#c88a46', { r: 6, rb: 0, mat: 'paint' }), slab(0, 30.4, z + 0.3, 24.6, 14, 3.8, toast ? '#c47a3a' : '#f6e2b6', { r: 5, rb: 0, noOut: 1 })];
    const sw = z => (p, s) => { const q = p(0, 30.4, z); return st === 'in' ? fixed(q, 'scale(1 0.12)', s) : st === 'pop' ? about(q, at(L, '0 0;0 -6;0 0;0 0', 1.6, 0, '0;0.15;0.3;1'), fixed(q, 'scale(1 1.25)', s)) : st ? s : about(q, at('scale', '1 1;1 1;1 0.12;1 0.12;1 1.3;1 1;1 1', 8, 0, KT), s); };
    const lever = (p, s) => { const dy = f1(p(25, 8, 0)[1] - p(25, 20, 0)[1]); return st === 'in' ? '<g transform="translate(0 ' + dy + ')">' + s + '</g>' : st ? s : '<g>' + at(L, '0 0;0 0;0 ' + dy + ';0 ' + dy + ';0 0;0 0;0 0', 8, 0, KT) + s + '</g>'; };
    return { w: 54, d: 36, layers: [{ build: slice(-5.5), wrap: sw(-5.5) }, { build: slice(5.5), wrap: sw(5.5) }, { build: () => [box(25, 20, 0, 3, 3.4, 9, '#2c2d31', { r: 1 })], wrap: lever }],
      build: P => { const body = k === 'junk' || k === 'mod' ? CH : P.a;
        return [box(0, 0, 0, 48, 4, 30, '#2c2d31', { r: 10 }), box(0, 4, 0, 50, 26, 32, body, mt({ r: 12, bev: 5 })), box(0, 30, -5.5, 30, 0.5, 4.6, '#1d1d20', { r: 1.5 }), box(0, 30, 5.5, 30, 0.5, 4.6, '#1d1d20', { r: 1.5 }), slabX(25.4, 8, 0, 0.6, 18, 3, '#1d1d20', { r: 1, noOut: 1 }), disc(-12, 16, 16.2, 3.4, 1.6, '#2c2d31'), disc(12, 16, 16.2, 2, 1, '#ff6a2a', em()), slab(0, 4.5, 16.2, 30, 3, 0.6, shade(body, 0.8), { r: 1 })]; },
      fx: c => { const gl = [-5.5, 5.5].map(z => { const a = c.p(-15, 30.6, z - 2), b = c.p(15, 30.6, z - 2), e = c.p(15, 30.6, z + 2), d = c.p(-15, 30.6, z + 2); return '<path d="M' + P2(a) + 'L' + P2(b) + 'L' + P2(e) + 'L' + P2(d) + 'Z" fill="#ff7a2a"' + (st === 'in' ? ' opacity="0.85">' + an('opacity', '0.6;0.95;0.6', 0.8) : st ? ' opacity="0">' : ' opacity="0">' + an('opacity', '0;0;0.85;0.85;0;0;0', 8, 0, KT)) + '</path>'; }).join('');
        return { front: gl + (st === 'pop' ? steam(c, 0, 50, 0, 0.6, 3) + rep(3, i => spark(c, -10 + i * 10, 52 + (i % 2) * 4, 6, 0.7, -i * 0.5, '#fff1b0')).join('') : '') }; } }; };
  // dishwashers: st '' idle (dirty stack) | 'load' dirty plates on the pulled-out rack | 'wash' door shut, sudsing | 'clean' rack out, sparkling plates
  N.dish2 = S => { const k = S.k, st = S.st || '', open = st === 'load' || st === 'clean', clean = st === 'clean', wash = st === 'wash', nm = S.nm;
    const dirty = (x, y, z, r) => [plate(x, y, z, r, '#f4f2ee'), ball(x + 0.9, y - 2, z + 2, 2, '#a0703a', { sx: 0.25, k: 3, n: 8 }), ball(x + 0.9, y + 3, z - 2.4, 1.4, '#7a8a3a', { sx: 0.25, k: 3, n: 8 })];
    if (k === 'junk') return { w: 92, d: 40, build: P => { const o = [box(-22, 0, 0, 40, 14, 34, '#7fb8d8', { r: 6, mat: 'paint' }), box(-22, 11, 0, 35, 1, 29, wash ? '#e8f4fa' : '#bfe4f2', { r: 5, op: 0.85, noOut: 1 }), box(22, 0, 0, 40, 3, 32, '#f1eee8', { r: 3, mat: 'paint' })];
        rep(6, i => o.push(cyl(22 - 16 + i * 6.4, 3, -12, 0.8, 16, '#d8d2c6', { n: 6 }), cyl(22 - 16 + i * 6.4, 3, 12, 0.8, 9, '#d8d2c6', { n: 6 })));
        if (clean) rep(4, i => o.push(plate(10 + i * 7.6, 12, 0, 9, '#ffffff')));
        else rep(3, i => o.push(...dirty(-32 + i * 9, 13, 0, 9)));
        return o; }, fx: c => ({ front: (wash ? bubbles(c, -22, 12, 4, 30, 9) : '') + (clean ? rep(4, i => spark(c, 10 + i * 7.6, 18 + (i % 2) * 5, 6, 0.8, -i * 0.45)).join('') : '') }) };
    const mini = /countertop|portable|mini/.test(nm), wood = /wood-panel|integrated/.test(nm), plasma = /plasma|robotic/.test(nm), Hh = mini ? 46 : 80, Wd = mini ? 48 : 60, Dd = mini ? 42 : 56, zf = Dd / 2;
    const body = plasma ? '#2a2630' : wood ? '#a86b36' : '#c9d3d8', front = plasma ? '#3a3448' : wood ? '#b8794a' : '#d5dde2', hd = plasma ? '#8fe8ff' : wood ? GOLD : CH, fm = wood ? 'wood' : plasma ? 'paint' : 'metal';
    return { w: Wd + 4, d: Dd + (open ? 50 : 0), anim: wash ? at('translate', '0 0;0.7 0;-0.7 0;0 0', 0.22) : '',
      build: P => { const o = [box(0, 0, 0, Wd, Hh, Dd, body, { r: 3, bev: 2, mat: fm }), slab(0, Hh - 9, zf + 0.3, Wd - 4, 7, 0.8, plasma ? '#16131c' : '#3e4046', { r: 2 })];
        if (!open) { o.push(slab(0, 3, zf + 0.4, Wd - 3, Hh - 14, 1.6, front, { r: 2, mat: fm }), slabX(0, Hh - 19, zf + 3, Wd * 0.7, 2.6, 2.6, hd, plasma ? em({ r: 1.3 }) : mt({ r: 1.3 })));
          if (wood) o.push(slabX(0, Hh * 0.45, zf + 2.2, Wd - 4, 0.8, 0.6, shade(front, 0.7), { noOut: 1 }), slabX(0, Hh * 0.3, zf + 3, Wd * 0.6, 2.4, 2.4, GOLD, mt({ r: 1.2 })));
          if (plasma && wash) o.push(slab(0, 10, zf + 2.1, Wd - 16, Hh - 30, 0.4, '#b48cff', em({ r: 6, op: 0.7 })));
          if (!st) rep(4, i => o.push(cyl(-6, Hh + i * 2, -4, 10, 1.6, '#f4f2ee', { n: 16, mat: 'cer' }))), o.push(ball(-9, Hh + 8, -2, 2.6, '#a0703a', { sy: 0.4, k: 3, n: 8 }), ball(-2, Hh + 8, -7, 2, '#7a8a3a', { sy: 0.4, k: 3, n: 8 }), cyl(12, Hh, 4, 4, 8, '#cfe8f2', { n: 10, op: 0.8 })); }
        else { o.push(slab(0, 5, zf + 0.2, Wd - 6, Hh - 16, 0.6, '#2c3238', { r: 1, noOut: 1 }), box(0, 2, zf + 25, Wd - 3, 2.4, 48, front, { r: 2, mat: fm }), box(0, 4.4, zf + 22, Wd - 10, 8, 38, '#9aa3a8', mt({ r: 2, op: 0.55 })));
          rep(mini ? 3 : 5, i => { const x = -((mini ? 3 : 5) - 1) * 4.5 + i * 9; if (clean) o.push(plate(x, 13, zf + 22, 8, '#ffffff')); else o.push(...dirty(x, 13, zf + 22, 8)); }); }
        if (plasma) o.push(cyl(Wd / 2 - 10, Hh, -Dd / 2 + 10, 5, 4, '#3a3448', mt({ n: 12 })), box(Wd / 2 - 10, Hh + 4, -Dd / 2 + 10, 3, 18, 3, '#c9d0d6', mt()), box(Wd / 2 - 18, Hh + 20, -Dd / 2 + 10, 18, 3, 3, '#c9d0d6', mt()), ball(Wd / 2 - 27, Hh + 18, -Dd / 2 + 10, 3, '#8fe8ff', em()));
        return o; },
      fx: c => { const q = c.p(Wd / 2 - 8, Hh - 5.5, zf + 1.4), col = wash ? '#6ac8ff' : clean ? '#a6f06a' : open ? '#ffd66b' : '#a6f06a';
        let f = '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(1.6 * c.k) + '" fill="' + col + '">' + (wash || !st ? an('opacity', '1;0.2;1', wash ? 0.6 : 2.4) : '') + '</circle>';
        if (wash) f += bubbles(c, 0, Hh - 14, zf + 2, Wd - 10, 10) + steam(c, 0, Hh, 0, 0.8, 3);
        if (clean) f += rep(5, i => spark(c, -18 + i * 9, 20 + (i % 2) * 4, zf + 24, 0.9, -i * 0.35)).join('') + steam(c, 0, 22, zf + 22, 0.7, 3);
        return { front: f }; } }; };
  const PASTEL = [{ n: 'Mint', c: '#9fdcc4' }, { n: 'Butter', c: '#f2dc8a' }, { n: 'Sky', c: '#9fc8ec' }, { n: 'Lavender', c: '#c3b2e8' }, { n: 'Cream', c: '#f1e8d6' }];
  N.standMixer = S => ({ w: 100, d: 52, build: P => { const a = P.a, o = [];
      o.push(box(-22, 0, 2, 30, 7, 42, a, { r: 10, bev: 3, mat: 'paint' }), box(-22, 7, -14, 15, 38, 12, a, { r: 7, mat: 'paint' }), solid({ ax: 'z', sh: 'el', c: [-22, 50], a: 11, b: 10, n: 16, rings: [[-20, 3, 0.75], [-17, 0, 0.95], [6, 0, 1], [11, 2, 0.85], [14, 5, 0.55]], col: a, shine: 1 }), solid({ ax: 'z', sh: 'el', c: [-22, 50], a: 11.5, b: 10.5, n: 16, rings: [[-4, 0], [-1.6, 0]], col: CH, mat: 'metal' }),
        cyl(-22, 7, 8, 12, 17, CH, mt({ n: 16, rg: [[0, 0, 0.55], [3, 0, 0.85], [17, 0, 1.08]] })), cyl(-22, 23.4, 8, 12.4, 0.8, '#f4e2b8', { n: 16, noOut: 1 }), cyl(-22, 24, 8, 1.4, 16, CH, mt({ n: 6 })), box(-13, 40, -14, 4, 3, 8, CH, mt({ r: 1 })));
      o.push(box(24, 0, 0, 24, 15, 24, '#f1eee8', { r: 5, bev: 2, mat: 'paint' }), disc(19, 7, 12.2, 1.8, 0.8, '#3a3a3e'), disc(24, 7, 12.2, 1.8, 0.8, '#3a3a3e'), disc(29, 7, 12.2, 1.8, 0.8, '#ff6a4a', em()), cyl(24, 15, 0, 9, 4, a, { n: 14 }), cyl(24, 19.6, 0, 9, 19, '#f2b04a', { n: 14, rg: [[0, 0, 0.8], [19, 0, 1.02]] }), cyl(24, 19, 0, 9.5, 32, GL, { n: 14, rg: [[0, 0, 0.8], [32, 0, 1.12]], op: 0.45, mat: 'cer' }), cyl(24, 51, 0, 10.8, 4, '#2c2d31', { n: 14 }), cyl(24, 55, 0, 3, 3, '#3a3a3e', { n: 8 }), box(34.5, 28, 0, 3, 16, 4, GL, { r: 1.4, op: 0.6 }));
      return o; },
    fx: c => { const w = c.p(-22, 30, 8), u = c.k, v = c.p(24, 33, 0);
      const whisk = rep(3, i => '<ellipse cx="' + f1(w[0]) + '" cy="' + f1(w[1]) + '" rx="' + f1(5 * u) + '" ry="' + f1(7 * u) + '" fill="none" stroke="#c9d3d8" stroke-width="0.9">' + an('rx', f1(5 * u) + ';' + f1(0.4 * u) + ';' + f1(5 * u), 0.3, -i * 0.1) + '</ellipse>').join('');
      const vort = rep(3, i => '<ellipse cx="' + f1(v[0]) + '" cy="' + f1(v[1] + i * 4 * u) + '" rx="' + f1((6 - i * 1.5) * u) + '" ry="' + f1(1.6 * u) + '" fill="none" stroke="#fff1c4" stroke-width="0.9" opacity="0.8">' + an('rx', f1((6 - i * 1.5) * u) + ';' + f1(1 * u) + ';' + f1((6 - i * 1.5) * u), 0.4, -i * 0.13) + '</ellipse>').join('');
      return { front: whisk + vort + bubbles(c, 24, 22, 2, 12, 5, '#fff1c4') }; } });
  N.espresso = S => ({ w: 112, d: 54, build: P => { const o = [], ch = CH, wd = '#6b4226', X0 = -14;
      o.push(box(X0, 0, 0, 66, 4, 46, '#2c2d31', { r: 3 }), box(X0, 4, -2, 64, 50, 42, ch, mt({ r: 4, bev: 2 })), box(X0, 54, -2, 66, 3, 44, '#9aa3a8', mt({ r: 3 })), slabX(X0, 60, 17, 62, 1.6, 1.6, ch, mt()), slabX(X0 + 32.4, 10, -2, 1.2, 38, 36, wd, { r: 4, mat: 'wood' }));
      [-31, 31].forEach(dx => o.push(cyl(X0 + dx, 57, 17, 1, 4, ch, mt({ n: 6 }))));
      [-16, 0, 16].forEach(dx => o.push(cyl(X0 + dx, 57, -6, 4.5, 6, WH, { n: 12, mat: 'cer' })));
      [-14, 14].forEach(dx => { const x = X0 + dx; o.push(cyl(x, 30, 22, 7, 7, ch, mt({ n: 14 })), cyl(x, 26, 22, 6, 4, '#3a3a3e', mt({ n: 12 })), box(x, 26, 33, 3.4, 3.4, 18, wd, { r: 1.6, mat: 'wood' }), cyl(x, 21, 23, 1, 5, ch, mt({ n: 6 })), cyl(x, 8.4, 24, 4.6, 6.4, WH, { n: 14, mat: 'cer' }), cyl(x, 14.6, 24, 4, 0.4, '#a8693a', { n: 12, noOut: 1 }), box(x + 5, 10, 24, 2, 3.4, 1.4, WH, { r: 0.8 })); });
      o.push(box(X0, 4, 24, 60, 4, 12, '#3a3a3e', mt({ r: 2 })), disc(X0, 44, 19.4, 6.4, 1.2, ch, mt()), disc(X0, 44, 20.6, 5.2, 0.4, '#fffaf1'), cyl(X0 + 31, 18, 18, 1.2, 26, ch, mt({ n: 6 })), ball(X0 + 31, 44, 18, 2.6, '#2c2d31', { k: 3, n: 8 }), disc(X0 - 24, 44, 19.4, 2.6, 1.4, '#d9483b'));
      const G = 40; o.push(box(G, 0, 0, 22, 30, 26, '#2c2d31', mt({ r: 4 })), cyl(G, 30, 0, 9, 4, '#3a3a3e', { n: 14 }), cyl(G, 35, 0, 9, 15, '#5a3a20', { n: 14, rg: [[0, 0, 0.55], [15, 0, 0.95]] }), cyl(G, 34, 0, 10, 24, GL, { n: 14, rg: [[0, 0, 0.55], [24, 0, 1.12]], op: 0.45, mat: 'cer' }), cyl(G, 58, 0, 11.4, 2.4, '#2c2d31', { n: 14 }), cyl(G, 6, 14, 4, 6, ch, mt({ n: 10 })), disc(G, 20, 13.2, 3.4, 1.4, ch, mt()), ...[[-3, 2], [2, -2], [4, 3]].map(([x, z]) => ball(G + x, 49.4, z, 1.6, '#6b4226', { sy: 0.7, k: 3, n: 8 })));
      return o; },
    fx: c => { const X0 = -14, g = c.p(X0, 44, 21.2);
      return { front: '<g transform="' + plane(c.p, 21.2, 44) + '"><g>' + at('rotate', '-50;30;10;40;-50', 5) + '<path d="M0 0L0 -4" stroke="#d9483b" stroke-width="0.8" stroke-linecap="round"/></g><circle r="0.8" fill="#2c2d31"/></g>'
        + [-14, 14].map((dx, i) => drip(c, X0 + dx, 21, 15, 23, '#6b3a1a', 0.5, -i * 0.25) + drip(c, X0 + dx, 21, 15, 23, '#6b3a1a', 0.5, -i * 0.25 - 0.25) + steam(c, X0 + dx, 15, 24, 0.5, 2)).join('') + steam(c, X0 + 31, 18, 18, 0.6, 2) }; } });
  N.sommelier = S => ({ w: 64, d: 48, glow: () => ({ y: 112, r: 46, c: 'url(#gNeon)' }), pad: [0, 20, 0, 0], build: P => [box(0, 0, 0, 52, 4, 44, '#2a2c34', mt({ r: 10 })), box(0, 4, 0, 50, 94, 40, '#f1eee8', { r: 16, bev: 3, mat: 'cer' }), slab(0, 40, 20.4, 40, 50, 1, '#121420', { r: 10 }), box(0, 8, 14, 38, 26, 14, '#23252e', { r: 8 }), cyl(0, 33, 14, 14, 1, '#8fe8ff', em({ n: 16, op: 0.8 })), cyl(0, 10, 15, 6.4, 11, WH, { n: 14, mat: 'cer' }), ball(0, 19.6, 15, 6.2, '#f4e6d0', { sy: 0.4, k: 4, n: 14 }), cyl(0, 98, 0, 20, 4, '#2a2c34', mt({ n: 18 })), cyl(0, 102, 0, 14, 1.6, '#8fe8ff', em({ n: 18 }))],
    fx: c => { let ui = '<rect x="-17" y="2" width="34" height="0.8" fill="#8fe8ff" opacity="0.6">' + an('y', '2;46;2', 3) + '</rect><text x="0" y="8" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="3.4" fill="#8fe8ff">AI SOMMELIER</text>'
        + rep(9, i => '<rect x="' + (-15 + i * 3.4) + '" y="16" width="2.2" height="12" fill="' + NE[i % 6] + '">' + an('height', (4 + i % 4 * 2) + ';' + (12 - i % 3 * 2) + ';' + (4 + i % 4 * 2), 0.8 + (i % 3) * 0.2, -i * 0.1) + '</rect>').join('')
        + '<circle cx="0" cy="38" r="6" fill="none" stroke="#3a3c48" stroke-width="1.6"/><circle cx="0" cy="38" r="6" fill="none" stroke="#a6f06a" stroke-width="1.6" stroke-dasharray="38" stroke-dashoffset="38">' + an('stroke-dashoffset', '38;0;38', 4) + '</circle><text x="0" y="39.4" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="3" fill="#fffaf1">98%</text>';
      const ring = (y, rx, col, d) => '<g transform="' + planeH(c.p, y) + '"><ellipse rx="' + rx + '" ry="' + rx + '" fill="none" stroke="' + col + '" stroke-width="1.4" stroke-dasharray="6 4" filter="url(#gw)">' + an('stroke-dashoffset', '0;40', d) + '</ellipse></g>';
      const orbit = rep(3, i => { const pts = rep(25, j => { const a = j / 24 * 2 * PI; return P2(c.p(Math.cos(a) * 17, 112, Math.sin(a) * 17)); }); return '<circle r="' + f1(2.2 * c.k) + '" fill="' + ['#6b4226', '#7f2030', '#f2c94c'][i] + '"><animateMotion dur="5s" begin="' + (-i * 1.66) + 's" repeatCount="indefinite" path="M' + pts.join('L') + 'Z"/></circle>'; }).join('');
      const cup = c.p(0, 118, 0), u = c.k;
      return { defs: GLOW, front: '<g transform="' + plane(c.p, 21.2, 90) + '">' + ui + '</g>' + ring(106, 19, '#8fe8ff', 3) + ring(126, 13, '#b48cff', 2.2) + orbit
        + '<g>' + bob(3, 2.4) + '<path d="M' + f1(cup[0] - 7 * u) + ' ' + f1(cup[1] - 6 * u) + 'h' + f1(14 * u) + 'l-2 ' + f1(12 * u) + 'h' + f1(-10 * u) + 'Z" fill="#8fe8ff" fill-opacity="0.18" stroke="#8fe8ff" stroke-width="0.9" filter="url(#gw)"/><path d="M' + f1(cup[0] - 3 * u) + ' ' + f1(cup[1] - 9 * u) + 'q2 -3 0 -6t0 -6" fill="none" stroke="#c9f4ff" stroke-width="0.8">' + an('opacity', '0.2;1;0.2', 1.8) + '</path></g>'
        + '<g transform="' + planeH(c.p, 22.2) + ' translate(0 15)"><path d="M0 2.4C-3 0 -3 -2.4 -1.4 -2.6C-0.6 -2.7 0 -2 0 -1.4C0 -2 0.6 -2.7 1.4 -2.6C3 -2.4 3 0 0 2.4Z" fill="#a8693a"/></g>' }; } });
  N.synth = S => ({ w: 92, d: 62, glow: () => ({ y: 60, r: 60, c: 'url(#gNeon)' }), build: P => [box(0, 0, 0, 84, 28, 58, '#23252e', mt({ r: 8, bev: 2 })), slabX(0, 22, 29.4, 76, 2.4, 0.8, '#8fe8ff', em({ r: 1 })), slab(-24, 7, 29.6, 26, 11, 0.6, '#121420', { r: 2 }), box(0, 28, 0, 76, 3, 52, '#3a3c48', mt({ r: 4 })), cyl(0, 31, 0, 22, 1.6, '#8fe8ff', em({ n: 20, op: 0.7 })), ...[[-36, -24], [36, -24], [-36, 24], [36, 24]].map(([x, z]) => box(x, 31, z, 4, 54, 4, '#c9d0d6', mt({ r: 1 }))), box(0, 85, 0, 80, 5, 56, '#23252e', mt({ r: 4 })), slabX(0, 79, 0, 72, 2, 2, '#8a8f98', mt()), box(0, 31, 0, 72, 54, 50, GL, { r: 2, op: 0.14, mat: 'cer', noOut: 1 })],
    layers: [{ build: () => [cyl(0, 32.6, 0, 15, 8, '#e8b878', { n: 18 }), cyl(0, 40.6, 0, 15.4, 3, '#fff6e8', { n: 18 }), cyl(0, 43.6, 0, 11, 6, '#c9874a', { n: 16 }), cyl(0, 49.6, 0, 11.4, 2.4, '#fff6e8', { n: 16 }), ball(0, 52, 0, 3.4, '#d9483b', { k: 4 })], wrap: (p, s) => about(p(0, 32.6, 0), at('scale', '1 0.05;1 1;1 1;1 0.05', 7, 0, '0;0.55;0.92;1'), s) },
      { build: () => [box(0, 74, 0, 12, 9, 12, '#c9d0d6', mt({ r: 2 })), cyl(0, 68, 0, 2, 6, '#3a3c48', mt({ n: 8 })), ball(0, 66, 0, 1.6, '#8fe8ff', em())], wrap: (p, s) => { const v = p(26, 0, 0), o = p(0, 0, 0), dx = f1(v[0] - o[0]), dy = f1(v[1] - o[1]); return '<g>' + at('translate', '-' + dx + ' -' + dy + ';' + dx + ' ' + dy + ';-' + dx + ' -' + dy, 1.75) + s + '</g>'; } }],
    fx: c => { const a = c.p(-36, 31, 26), b = c.p(36, 31, 26), u = c.k, h = 54 * u * X.CA;
      return { defs: GLOW, front: '<rect x="' + f1(a[0]) + '" y="' + f1(a[1]) + '" width="' + f1(b[0] - a[0]) + '" height="' + f1(1.2 * u) + '" fill="#8fe8ff" opacity="0.8" filter="url(#gw)">' + an('y', f1(a[1]) + ';' + f1(a[1] - h) + ';' + f1(a[1]), 3.5) + '</rect>' + rep(6, i => spark(c, -26 + i * 10, 40 + (i % 3) * 10, 10, 0.6, -i * 0.3, '#c9f4ff')).join('')
        + '<g transform="' + plane(c.p, 29.8, 18) + '"><text x="-24" y="0" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="3.4" fill="#8fe8ff">PRINTING' + '</text><rect x="-34" y="2.4" width="20" height="1.2" fill="#3a3c48"/><rect x="-34" y="2.4" width="20" height="1.2" fill="#a6f06a">' + an('width', '0;20;20;0', 7, 0, '0;0.55;0.92;1') + '</rect></g>' }; } });
  N.fruitJar = S => ({ w: 96, d: 46, build: P => { const o = [], wire = '#3a3a3e', bx = -20;
      o.push(cyl(bx, 0, 0, 12, 2, wire, mt({ n: 16 })), arcW(bx, 2, 0, 20, 18, 1.2, 1.2, 0, 2 * PI, wire, mt({ n: 18 })), arcW(bx, 13, 0, 24, 21, 1.4, 1.4, 0, 2 * PI, wire, mt({ n: 18 })));
      rep(8, i => { const a = i / 8 * 2 * PI; o.push(cyl(bx + Math.cos(a) * 21, 2, Math.sin(a) * 19, 0.8, 11, wire, mt({ n: 4 }))); });
      const apple = (x, y, z, col) => [ball(x, y, z, 6.4, col, { sy: 0.92, k: 6, n: 14 }), cyl(x, y + 11.4, z, 0.6, 3, '#5a3a20', { n: 4 }), ball(x + 2, y + 12.6, z, 2.2, '#5fa84a', { sx: 1.4, sy: 0.4, k: 3, n: 8 })];
      const orange = (x, y, z) => [ball(x, y, z, 6.6, '#f2932c', { k: 6, n: 14 }), ball(x, y + 12.6, z + 1, 1, '#6a8a3a', { k: 3, n: 6 })];
      o.push(...orange(bx - 6, 4, -6), ...apple(bx + 2, 4, -8, '#9fcf4a'), ...apple(bx - 9, 4, 4, '#d9363b'), ...orange(bx + 7, 4, 6), ...apple(bx + 1, 13, 0, '#c42a30'));
      o.push(arcW(bx + 3, 17, 4, 12, 12, 3.4, 3.8, PI * 1.12, PI * 1.88, '#f6d24a', { n: 8 }), arcW(bx + 3, 20, 2, 12, 12, 3.4, 3.8, PI * 1.12, PI * 1.88, '#f2c94c', { n: 8 }), cyl(bx + 3 + Math.cos(PI * 1.12) * 10, 18, 4 + Math.sin(PI * 1.12) * 10, 1.2, 5, '#6b4a20', { n: 6 }));
      rep(10, i => o.push(ball(bx + 14 + (i % 3) * 3 - 3, 12 + Math.floor(i / 3) * 3.2 - (i > 8 ? 1 : 0), -2 + (i % 2) * 2.6, 2.3, i % 2 ? '#6b3a8a' : '#7d4a9a', { k: 3, n: 8 })));
      o.push(ball(bx - 15, 10, 4, 5, '#c9d84a', { k: 5, n: 12 }), ball(bx - 15, 18, 4, 3.4, '#c9d84a', { k: 4, n: 10 }), cyl(bx - 15, 24.4, 4, 0.5, 3, '#5a3a20', { n: 4 }));
      const jx = 28; o.push(cyl(jx, 0, 0, 13, 2, '#e9e3d6', { n: 18, mat: 'cer' }));
      rep(6, i => { const y = 2 + i * 4.2, x = jx + (i % 2 ? 1.5 : -1.5); o.push(cyl(x, y, (i % 3) - 1, 9.6, 3.4, i % 3 === 2 ? '#7a4a28' : '#d8a060', { n: 16, mat: 'paint', rg: [[0, 0, 0.94], [1.7, 0, 1], [3.4, 0, 0.94]] }), ...[0, 1, 2].map(j => ball(x + Math.cos(i * 2 + j * 2.1) * 5, y + 2.9, (i % 3) - 1 + Math.sin(i * 2 + j * 2.1) * 5, 1.1, i % 3 === 2 ? '#f4e2b8' : '#3a2010', { sy: 0.6, k: 3, n: 6 }))); });
      o.push(cyl(jx, 2, 0, 12.6, 30, GL, { n: 18, op: 0.16, mat: 'cer', rg: [[0, 0, 0.96], [26, 0, 1], [30, 0, 0.8]] }), cyl(jx, 32, 0, 10.6, 4, '#efe7d8', { n: 18, mat: 'cer' }), ball(jx, 36, 0, 3.4, '#efe7d8', { k: 4 }), cyl(jx + 6, 0, 16, 8, 3, '#d8a060', { n: 16 }), ...[[3, 14], [8, 18], [9, 13]].map(([x, z]) => ball(jx + x, 2.6, z, 1.1, '#3a2010', { sy: 0.6, k: 3, n: 6 })));
      return o; } });
  N.cookieJar = S => ({ w: 74, d: 52, build: P => { const o = [box(0, 0, 0, 68, 1.2, 48, GOLD, mt({ r: 6 })), box(0, 1.2, 0, 66, 3.2, 46, '#efebe5', { r: 6, mat: 'cer' })];
      rep(8, i => { const y = 4.4 + i * 3.8, x = (i % 2 ? 1.6 : -1.6), ck = i % 4 === 3 ? '#7a4a28' : '#d8a060'; o.push(cyl(x, y, (i % 3) - 1, 12, 3.2, ck, { n: 18, mat: 'paint', rg: [[0, 0, 0.94], [1.6, 0, 1], [3.2, 0, 0.94]] }), ...[0, 1, 2, 3].map(j => ball(x + Math.cos(i * 1.7 + j * 1.6) * 6.4, y + 2.7, (i % 3) - 1 + Math.sin(i * 1.7 + j * 1.6) * 6.4, 1.3, ck === '#7a4a28' ? '#f4e2b8' : '#3a2010', { sy: 0.6, k: 3, n: 6 }))); });
      o.push(cyl(0, 4.4, 0, 22, 40, GL, { n: 22, op: 0.16, mat: 'cer', rg: [[0, 0, 1], [18, 0, 1], [30, 0, 0.82], [36, 0, 0.5], [40, 0, 0.12]] }), ball(0, 43, 0, 3.6, GOLD, mt({ k: 4 })), cyl(22, 4.4, 16, 8.6, 3, '#d8a060', { n: 16 }), ...[[19, 14], [24, 19], [25, 13]].map(([x, z]) => ball(x, 7, z, 1.2, '#3a2010', { sy: 0.6, k: 3, n: 6 })), cyl(-22, 4.4, 16, 8.6, 3, '#7a4a28', { n: 16 }), ...[[-24, 14], [-19, 18]].map(([x, z]) => ball(x, 7, z, 1.2, '#f4e2b8', { sy: 0.6, k: 3, n: 6 })));
      return o; } });
  // luxury counters: marble / obsidian tops, gold edge, fluted fronts, waterfall ends; L (left leg), U, I (island)
  N.luxCounter = S => { const nm = S.nm, obs = /obsidian/.test(nm), shp = S.shape || 'L', top = obs ? '#25222a' : '#f4f1ec', vein = obs ? GOLD : '#c9c1b5', cab = obs ? '#2e3138' : /navy/.test(nm) ? '#22324a' : '#1f4f3e', hw = GOLD, TH = 59.2;
    const SEG = shp === 'U' ? [[-112, 112, -68, -16], [-164, -112, -68, 78], [112, 164, -68, 78]] : shp === 'L' ? [[-70, 120, -68, -16], [-122, -70, -68, 86]] : [[-92, 92, -38, 38]];
    const xs = SEG.flatMap(s => [s[0], s[1]]), zs = SEG.flatMap(s => [s[2], s[3]]), W = Math.max(...xs) - Math.min(...xs), D = Math.max(...zs) - Math.min(...zs), R = rng(nm);
    const lift = S.lift ? [{ build: () => { const o = [box(-10, TH, -60, 120, 46, 14, cab, { r: 2, mat: obs ? 'paint' : 'wood' }), box(-10, TH + 46, -60, 124, 3, 16, hw, mt({ r: 1 }))]; [-50, -10, 30].forEach(x => o.push(slab(x, TH + 4, -52.6, 36, 38, 0.8, '#cfe8f2', { r: 2, op: 0.6 }), box(x + 15, TH + 14, -51.6, 1.6, 12, 1.6, hw, mt({ r: 0.8 })))); return o; }, wrap: (p, s) => about(p(-10, TH, -60), at('scale', '1 0.04;1 1;1 1;1 0.04', 8, 0, '0;0.25;0.75;1'), s), back: 1 }] : null;
    return { w: W, d: D, topH: TH, topZ: shp === 'I' ? 0 : -42, topW: shp === 'I' ? 120 : 110, layers: lift, build: P => { const o = [];
      SEG.forEach(([x0, x1, z0, z1], si) => { const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, w = x1 - x0, d = z1 - z0, leg = d > 80;
        o.push(box(cx, 0, cz, w - 6, 6, d - 6, '#1d1d20', { r: 1 }), box(cx, 6, cz, w, 47.4, d, cab, { r: 2, mat: obs ? 'paint' : 'wood' }), box(cx, 53.4, cz, w + 5, 1.4, d + 5, hw, mt({ r: 2 })), box(cx, 54.8, cz, w + 4, 4.4, d + 4, top, { r: 2, mat: 'cer' }));
        rep(5, () => o.push(box(cx + (R() - 0.5) * w * 0.8, TH + 0.05, cz + (R() - 0.5) * d * 0.7, 26 + R() * 30, 0.15, 0.9, vein, { yaw: (R() - 0.5) * 1.6, r: 0, noOut: 1 })));
        const door = (x, z, ax) => { if (ax === 'z') { o.push(slab(x, 10, z + 0.3, 34, 40, 1, shade(cab, 1.12), { r: 2, mat: obs ? 'paint' : 'wood' })); [-8, 0, 8].forEach(t => o.push(slab(x + t, 13, z + 1.4, 1.2, 34, 0.6, shade(cab, 0.82), { r: 0, noOut: 1 }))); o.push(box(x + 13, 26, z + 2.2, 2, 14, 2, hw, mt({ r: 1 }))); }
          else { o.push(slabX(x + 0.3, 10, z, 1, 40, 34, shade(cab, 1.12), { r: 2 })); [-8, 0, 8].forEach(t => o.push(slabX(x + 1.4, 13, z + t, 0.6, 34, 1.2, shade(cab, 0.82), { noOut: 1 }))); o.push(box(x + 2.2, 26, z - 13, 2, 14, 2, hw, mt({ r: 1 }))); } };
        if (!leg) { const n = Math.round(w / 38), pw = w / n; rep(n, i => { const x = x0 + pw * (i + 0.5); if (SEG.some((s, j) => j !== si && x > s[0] - 4 && x < s[1] + 4)) return; door(x, z1, 'z'); }); }
        else { if (x0 < 0) { const n = Math.round((z1 + 16) / 38), pz = (z1 + 16) / n; rep(n, i => door(x1, -16 + pz * (i + 0.5), 'x')); } o.push(box(cx, 0, z1 + 2.4, w + 4, TH, 4.8, top, { r: 1, mat: 'cer' })); }
        if (shp === 'I') [-1, 1].forEach(sg => o.push(box(sg * (w / 2 + 2.4), 0, cz, 4.8, TH, d + 4, top, { r: 1, mat: 'cer' }))); });
      if (S.sink) { const sx = 30; o.push(box(sx, TH - 0.6, -44, 46, 0.8, 28, '#16181c', { r: 5 }), box(sx, TH - 0.2, -44, 40, 0.5, 22, '#7ad8ff', em({ r: 4, op: 0.75 })), cyl(sx, TH, -61, 2.2, 26, hw, mt({ n: 8 })), solid({ ax: 'x', sh: 'arc', c: [-52, TH + 24], a: 9, b: 9, th: 2.2, a0: 0, a1: PI, n: 10, rings: [[sx - 1.1, 0], [sx + 1.1, 0]], col: hw, mat: 'metal' }), cyl(sx, TH + 19, -43, 1.6, 5, hw, mt({ n: 6 })), cyl(sx + 14, TH, -60, 1.8, 14, hw, mt({ n: 6 })), ball(sx + 14, TH + 14, -60, 2.4, hw, mt({ k: 3 }))); }
      if (S.prep) o.push(box(46, TH - 0.4, 0, 26, 0.8, 22, '#16181c', { r: 4 }), cyl(46, TH, -16, 1.8, 20, hw, mt({ n: 8 })), solid({ ax: 'x', sh: 'arc', c: [-9, TH + 18], a: 7, b: 7, th: 1.8, a0: 0, a1: PI, n: 10, rings: [[45, 0], [47, 0]], col: hw, mat: 'metal' }), cyl(-30, TH, 4, 14, 8, '#f4f1ec', { n: 16, mat: 'cer' }), ball(-34, TH + 6, 2, 4, '#d9363b'), ball(-26, TH + 6, 6, 4, '#f2932c'));
      if (S.tep) o.push(box(-30, TH + 0.4, 0, 76, 1.8, 50, '#a8b0b6', mt({ r: 2 })), ...[[-44, -8], [-36, 8], [-22, -4], [-16, 10]].map(([x, z], i) => arcW(x, TH + 2.2, z, 4, 4, 1.8, 2.2, 0, PI * 1.5, '#f2935a', { n: 6 })), ball(-28, TH + 1.8, -12, 3, '#6aa65a', { sy: 0.6 }), box(50, TH, 8, 28, 1.6, 24, '#16181c', mt({ r: 3 })), box(50, TH + 1.6, 8, 20, 0.4, 16, '#8fe8ff', em({ r: 2, op: 0.5 })));
      return o; },
      fx: c => { let f = '';
        if (S.sink) f += '<g transform="' + planeH(c.p, TH + 0.4) + ' translate(30 -44)">' + rep(3, i => '<ellipse rx="2" ry="2" fill="none" stroke="#ffffff" stroke-width="0.6">' + an('rx', '2;16', 1.8, -i * 0.6) + an('ry', '2;9', 1.8, -i * 0.6) + an('opacity', '1;0', 1.8, -i * 0.6) + '</ellipse>').join('') + '</g>' + steam(c, 44, TH + 16, -60, 0.6, 2);
        if (S.tep) f += steam(c, -36, TH + 4, 0, 0.9, 4) + '<g transform="' + plane(c.p, 20.4, TH + 1.4) + ' translate(50 0)"><text x="0" y="0" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="3" fill="#8fe8ff">' + '0.42 kg' + an('opacity', '1;0.4;1', 1.2) + '</text></g>';
        if (S.lift) f += rep(3, i => spark(c, -40 + i * 30, TH + 50, -52, 0.7, -i * 0.6, '#ffe9a0')).join('');
        return { front: f }; } }; };
  N.robotCart = S => ({ w: 56, d: 42, roam: 1, pad: [44, 6, 44, 0],
    wrap: (p, s) => { const v = p(36, 0, 0), o = p(0, 0, 0), dx = f1(v[0] - o[0]), dy = f1(v[1] - o[1]); return '<g>' + at('translate', '-' + dx + ' -' + dy + ';' + dx + ' ' + dy + ';' + dx + ' ' + dy + ';-' + dx + ' -' + dy + ';-' + dx + ' -' + dy, 8, 0, '0;0.42;0.5;0.92;1') + s + '</g>'; },
    layers: [{ build: () => [ball(0, 58, -6, 13, '#f1eee8', { sy: 0.8, k: 6, n: 16, mat: 'cer' }), slab(0, 62, 4.4, 18, 9, 1, '#1d2030', { r: 4 }), cyl(0, 78, -6, 0.6, 7, '#9aa3a8', { n: 4 }), ball(0, 84, -6, 1.8, '#8fe8ff', em())], wrap: (p, s) => about(p(0, 58, -6), at('rotate', '-6;6;-6', 3), s) }],
    build: P => [box(0, 6, 0, 46, 10, 34, '#3a3c48', mt({ r: 8 })), ...[[-18, -13], [18, -13], [-18, 13], [18, 13]].map(([x, z]) => ball(x, 0, z, 5, '#1d1d20', { k: 4, n: 12 })), cyl(0, 16, -6, 9, 42, '#f1eee8', { n: 14, mat: 'cer' }), box(0, 30, 6, 44, 2.4, 30, CH, mt({ r: 3 })), box(0, 46, 6, 40, 2.4, 28, CH, mt({ r: 3 })), cyl(-10, 32.4, 8, 7, 1.2, WH, { n: 14, mat: 'cer' }), ball(-10, 33.4, 8, 3.6, '#e88a3a', { sy: 0.6 }), cyl(10, 32.4, 6, 6, 1.2, WH, { n: 14 }), ball(10, 33.4, 6, 3, '#6aa65a', { sy: 0.6 }), cyl(-8, 48.4, 6, 3.2, 7, '#cfe8f2', { n: 10, op: 0.8 }), cyl(8, 48.4, 8, 3.2, 7, '#cfe8f2', { n: 10, op: 0.8 }), box(-22, 36, 6, 3, 14, 3, '#9aa3a8', mt()), box(22, 36, 6, 3, 14, 3, '#9aa3a8', mt()), slabX(0, 11, 17.4, 30, 2, 0.6, '#8fe8ff', em({ r: 1 }))],
    fx: c => { const e = c.p(0, 66.5, 5.4), u = c.k; return { front: '<g>' + at('translate', '0 0;0 0', 1) + ['-4.4', '4.4'].map(x => '<ellipse cx="' + f1(e[0] + +x * u * 0.866) + '" cy="' + f1(e[1] + +x * u * 0.5 * X.SA) + '" rx="' + f1(1.6 * u) + '" ry="' + f1(1.8 * u) + '" fill="#8fe8ff">' + an('ry', f1(1.8 * u) + ';' + f1(1.8 * u) + ';' + f1(0.2 * u) + ';' + f1(1.8 * u), 3.6, 0, '0;0.9;0.95;1') + '</ellipse>').join('') + '</g>' }; } });
  N.podSeat = S => ({ w: 62, d: 62, round: 1, act: 'sit', seats: [{ x: 0, z: 10, h: 36 }], wrap: (p, s) => '<g>' + bob(5, 3) + s + '</g>', pad: [0, 8, 0, 0],
    fx: c => { const q = c.p(0, 0, 0), u = c.k; return { under: '<ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + f1(24 * u) + '" ry="' + f1(24 * u * X.SA) + '" fill="#8fe8ff" opacity="0.35">' + an('opacity', '0.2;0.5;0.2', 3) + an('rx', f1(22 * u) + ';' + f1(26 * u) + ';' + f1(22 * u), 3) + '</ellipse>' }; },
    build: P => [ball(0, 12, 0, 26, '#f1eee8', { sy: 1.15, k: 8, n: 20, mat: 'cer' }), disc(0, 42, 17.5, 21, 8.6, shade('#f1eee8', 0.86)), disc(0, 42, 19, 18.6, 8.4, '#d9773f', { soft: 1 }), disc(0, 42, 18.8, 19.6, 0.8, '#ff9d4a', em({ op: 0.6 })), pillowY(0, 28, 16, 30, 8, 20, '#e8955a'), cyl(0, 6, 0, 10, 6, '#3a3c48', mt({ n: 14 })), cyl(0, 5, 0, 12, 1, '#8fe8ff', em({ n: 16 }))] });
  N.diningTable = S => { const n = S.n || 6, round = !!S.round, marble = S.top || '#f2efea', vein = S.vein || '#c9c1b5', wood = S.wood || '#6b4226', TH = 60, W = round ? 120 : n >= 8 ? 236 : 184, Dd = round ? 120 : 96, gold = S.gold;
    return { w: W + 16, d: Dd + 16, topH: TH + 5, topW: W * 0.7, build: P => { const o = [];
      if (round) o.push(cyl(0, 0, 0, 30, 5, wood, { n: 20, mat: 'wood' }), cyl(0, 5, 0, 10, TH - 10, wood, { n: 14, rg: [[0, 0, 1.4], [TH * 0.3, 0, 0.8], [TH - 10, 0, 1.3]], mat: 'wood' }), cyl(0, TH - 5, 0, 52, 5, wood, { n: 26, mat: 'wood' }), cyl(0, TH - 0.6, 0, 60.8, 1.2, GOLD, mt({ n: 28 })), cyl(0, TH, 0, 60, 5, marble, { n: 28, mat: 'cer' }));
      else { [-1, 1].forEach(sg => o.push(box(sg * (W / 2 - 26), 0, 0, 14, 5, Dd - 20, wood, { r: 2, mat: 'wood' }), box(sg * (W / 2 - 26), 5, 0, 10, TH - 11, 16, wood, { r: 2, mat: 'wood' }), box(sg * (W / 2 - 26), TH - 9, 0, 14, 4, Dd - 24, wood, { r: 2, mat: 'wood' })));
        o.push(slabX(0, 18, 0, W - 60, 5, 5, wood, { r: 2, mat: 'wood' }), box(0, TH - 6, 0, W - 16, 6, Dd - 16, wood, { r: 2, mat: 'wood' }), box(0, TH - 0.6, 0, W + 1.4, 1.2, Dd + 1.4, GOLD, mt({ r: 3 })), box(0, TH, 0, W, 5, Dd, marble, { r: 3, mat: 'cer' })); }
      const R = rng(S.nm); rep(round ? 5 : 8, () => o.push(box((R() - 0.5) * W * (round ? 0.6 : 0.8), TH + 5.05, (R() - 0.5) * Dd * 0.6, 24 + R() * 30, 0.15, 0.9, vein, { yaw: (R() - 0.5) * 1.6, r: 0, noOut: 1 })));
      if (!round) o.push(box(0, TH + 5.2, 0, W * 0.62, 0.6, 26, gold ? '#7f2030' : '#9fb58c', { r: 2, mat: 'fab' }));
      o.push(cyl(-16, TH + 5, 0, 2.4, 16, '#fff6e2', { n: 10 }), cyl(16, TH + 5, 0, 2.4, 13, '#fff6e2', { n: 10 }), ball(-16, TH + 21, 0, 1.6, '#ffd66b', em({ sy: 1.5 })), ball(16, TH + 18, 0, 1.6, '#ffd66b', em({ sy: 1.5 })));
      return o; } }; };
  // ---------- dance room LED designs: colour palette + pattern are picked at runtime ----------
  const PALS = [{ n: 'Party', c: NE }, { n: 'Ocean', c: ['#4fe0d0', '#6ac8ff', '#3f7fc8', '#8f7bff'] }, { n: 'Sunset', c: ['#ffd66b', '#ff9d4a', '#ff6a4a', '#ffb36a'] }, { n: 'Aurora', c: ['#a6f06a', '#4fe0d0', '#8f7bff', '#6ac8ff'] }, { n: 'Ice', c: ['#ffffff', '#bfe4ff', '#6ac8ff', '#d8f0ff'] }];
  const MODES = ['Wave', 'Pulse', 'Rainbow', 'Chase'];
  N.ledRig = S => { const pal = S.pal || NE, mode = MODES.includes(S.st) ? S.st : 'Wave', lv = S.lv || 3, vals = pal.concat(pal[0]).join(';');
    const ca = (i, j, n) => { const b = mode === 'Wave' ? -i * 0.18 : mode === 'Rainbow' ? -(i + j) * 0.16 : mode === 'Chase' ? -((i + j * 7) % n) * 0.09 : 0; return an('fill', vals, 3, b) + (mode === 'Pulse' ? an('opacity', '1;0.2;1', 1.1, -j * 0.12) : mode === 'Chase' ? an('opacity', '1;0.35;1', 0.9, b) : ''); };
    const sa = (i) => an('stroke', vals, 3, mode === 'Pulse' ? 0 : -i * 0.5) + (mode === 'Pulse' ? an('opacity', '1;0.3;1', 1.1) : '');
    const grid = (c, z, y, cw, chh, nx, ny) => { let g = ''; for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) g += '<rect x="' + f1(-nx * cw / 2 + i * cw + 0.6) + '" y="' + f1(j * chh + 0.6) + '" width="' + f1(cw - 1.2) + '" height="' + f1(chh - 1.2) + '" rx="1" fill="' + pal[(i + j) % pal.length] + '">' + ca(i, j, nx * ny) + '</rect>'; return '<g transform="' + plane(c.p, z, y) + '" filter="url(#gw)">' + g + '</g>'; };
    if (lv <= 2) return { w: 162, d: 10, mount: 'wall', build: P => [slabX(0, 62, 0, 154, 4, 6, '#2c2d31', mt()), slabX(0, 61, 3.4, 152, 2.2, 1.2, '#f4f8fb', { noOut: 1 }), slab(0, 0, -1.4, 160, 0.6, 0.4, '#000000', { op: 0.01, noOut: 1 })],
      fx: c => { let g = ''; rep(16, i => { const a = c.p(-76 + i * 9.5, 62.6, 4.2), b = c.p(-76 + (i + 1) * 9.5, 62.6, 4.2); g += '<path d="M' + P2(a) + 'L' + P2(b) + '" stroke-width="' + f1(2.4 * c.k) + '" stroke-linecap="round" stroke="' + pal[i % pal.length] + '">' + sa(i) + '</path>'; }); const w = c.p(0, 82, 0); return { defs: GLOW, front: '<ellipse cx="' + f1(w[0]) + '" cy="' + f1(w[1]) + '" rx="' + f1(84 * c.k) + '" ry="' + f1(20 * c.k) + '" fill="' + pal[0] + '" opacity="0.28">' + an('fill', vals, 3) + '</ellipse><g filter="url(#gw)">' + g + '</g>' }; } };
    if (lv === 3) return { w: 154, d: 10, mount: 'wall', build: P => [slab(0, 0, -2, 150, 100, 4, '#14151c', mt({ r: 4 })), slab(0, 6, 0.2, 138, 88, 0.6, '#0a0b10', { r: 2, noOut: 1 })], fx: c => ({ defs: GLOW, front: grid(c, 0.9, 93, 9.8, 10.8, 14, 8) }) };
    const rig = P => { const o = []; [-1, 1].forEach(s => { o.push(box(s * 80, 0, 0, 16, 6, 30, '#2c2d31', mt({ r: 2 }))); [-4, 4].forEach(dx => [-4, 4].forEach(dz => o.push(cyl(s * 80 + dx, 6, dz, 1, 150, CH, mt({ n: 6 }))))); rep(6, i => o.push(box(s * 80, 18 + i * 24, 0, 10, 1.4, 10, CH, mt({ r: 0 })))); });
      o.push(slabX(0, 154, 0, 172, 7, 8, '#3a3c48', mt({ r: 1 })), ...[-40, 0, 40].map(x => cyl(x, 132, 0, 0.5, 22, '#9aa3a8', { n: 4 })), arcW(0, 128, 0, 62, 50, 3, 3, 0, 2 * PI, '#23252e', mt({ n: 28 })), arcW(0, 110, 0, 46, 37, 3, 3, 0, 2 * PI, '#23252e', mt({ n: 24 })), arcW(0, 94, 0, 30, 24, 3, 3, 0, 2 * PI, '#23252e', mt({ n: 20 })), cyl(0, 146, 0, 6, 8, '#2c2d31', mt({ n: 10 })));
      if (lv >= 5) o.push(slab(0, 14, -52, 150, 96, 4, '#14151c', mt({ r: 4 })));
      return o; };
    return { w: 176, d: lv >= 5 ? 120 : 60, build: rig, fx: c => { let f = '';
      if (lv >= 5) f += grid(c, -49.6, 106, 9.8, 10.8, 14, 8);
      const rings = [[131, 62, 50], [113, 46, 37], [97, 30, 24]];
      rings.forEach(([y, a, b], i) => { [0, 1, 2].forEach(k2 => { const a0 = c.p(-a * 0.5 + k2 * a * 0.5, y, 0), e = c.p((-a * 0.5 + k2 * a * 0.5) * 2.4, 0, 30); f += '<path d="M' + P2(a0) + 'L' + f1(e[0] - 14 * c.k) + ' ' + f1(e[1]) + 'L' + f1(e[0] + 14 * c.k) + ' ' + f1(e[1]) + 'Z" fill="' + pal[(i + k2) % pal.length] + '" opacity="0.12">' + an('fill', vals, 3, -(i + k2) * 0.4) + an('opacity', mode === 'Pulse' ? '0.25;0.02;0.25' : '0.05;0.22;0.05', mode === 'Pulse' ? 1.1 : 2.4, -(i * 3 + k2) * 0.3) + '</path>'; }); });
      rings.forEach(([y, a, b], i) => { f += '<g transform="' + planeH(c.p, y + 3) + '"><ellipse rx="' + a + '" ry="' + b + '" fill="none" stroke-width="2.2" stroke="' + pal[i % pal.length] + '"' + (mode === 'Chase' ? ' stroke-dasharray="10 6"' : '') + ' filter="url(#gw)">' + sa(i) + (mode === 'Chase' ? an('stroke-dashoffset', '0;' + (i % 2 ? '-' : '') + '64', 2) : '') + '</ellipse></g>'; });
      if (lv >= 5) { const h = c.p(0, 146, 0); f += rep(5, i => '<g transform="translate(' + P2(h) + ')"><g>' + at('rotate', (-30 + i * 6) + ';' + (30 - i * 6) + ';' + (-30 + i * 6), 3 + i * 0.4) + '<path d="M0 0L' + f1((i - 2) * 20 * c.k) + ' ' + f1(150 * c.k) + '" stroke="' + pal[i % pal.length] + '" stroke-width="0.9" opacity="0.85" filter="url(#gw)">' + sa(i) + '</path></g></g>').join(''); }
      const fl = c.p(0, 0, 30); f += '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(70 * c.k) + '" ry="' + f1(70 * c.k * X.SA * 0.6) + '" fill="' + pal[0] + '" opacity="0.18">' + an('fill', vals, 3) + '</ellipse>';
      return { defs: GLOW, front: f }; } }; };

  // ---------- catalog edits ----------
  const LUXC = [{ n: 'Emerald Velvet', c: '#1f6a4c' }, { n: 'Sapphire Velvet', c: '#2b3f7a' }, { n: 'Burgundy Velvet', c: '#7f2030' }, { n: 'Plum Velvet', c: '#5a2a5e' }, { n: 'Mustard Velvet', c: '#c99a2e' }, { n: 'Ivory Bouclé', c: '#ece5d6' }, { n: 'Charcoal Linen', c: '#4a4a4f' }];
  const LROT = i => LUXC.slice(i).concat(LUXC.slice(0, i));
  const POUF = [{ n: 'Macramé Cream', c: '#efe6d4' }, { n: 'Emerald Velvet', c: '#1f6a4c' }, { n: 'Cognac Leather', c: '#a8592b' }, { n: 'Cloud Lavender', c: '#b9a6e0' }, { n: 'Mustard Knit', c: '#d8a531' }, { n: 'Navy Velvet', c: '#2f4870' }];
  const QUOTES = ['Home Sweet Home', 'Living Room', 'Kitchen', 'Bedroom', 'Bath Time', 'Welcome Home', 'Squish Squad', 'Family', 'Good Vibes'];
  const SIGNTX = ['DANCE!', 'Party Time', 'Good Vibes', 'Squish Squad', 'VIP', 'Disco Night', 'Turn It Up'];
  const DEL = new Set(['LIV-014', 'LIV-017', 'LIV-053', 'LIV-073', 'LIV-093', 'KIT-020', 'KIT-040', 'KIT-060', 'KIT-080', 'KIT-100', 'KIT-088',
    'MOV-012', 'MOV-032', 'MOV-052', 'MOV-072', 'MOV-092', 'CLB-012', 'CLB-032', 'CLB-052', 'CLB-072', 'CLB-092', 'BTH-012', 'BTH-032', 'BTH-052', 'BTH-072', 'BTH-092']);
  const SET = {
    'LIV-004': { name: 'Tacked-Up Wall Calendar (Live Date Tracker)', spec: 'calendar', kind: 'cal', note: 'Always shows today. Tap days to mark them; past days get crossed off.' },
    'LIV-084': { spec: 'masterpiece', kind: 'paint', modes: PAINT, note: 'A living painting: it moves on its own. Tap it to repaint.' },
    'LIV-033': { name: 'Cloud Puff Pouf', spec: 'puffPouf', kind: 'squish', colors: POUF, note: 'One pouf in any colour (replaces the Macramé Pouf, Velvet Ottoman, Moroccan Footstool and Levitating Foot Cloud). Squishes when a creature sits or when poked.' },
    'MOV-013': { spec: 'futon' },
    'LIV-055': { spec: 'hearth@cot' }, 'LIV-075': { spec: 'hearth@mod' },
    'LIV-006': { spec: 'rsofa', sx: { n: 2 } }, 'LIV-026': { spec: 'rsofa', sx: { n: 3 } }, 'LIV-046': { spec: 'rsofa', sx: { n: 4, shape: 'L' } }, 'LIV-066': { spec: 'rsofa', sx: { n: 5, shape: 'pit' } }, 'LIV-086': { spec: 'rsofa', sx: { n: 3, float: 1 } },
    'LIV-010': { spec: 'rchair' }, 'LIV-030': { spec: 'rsofa', sx: { n: 1 } }, 'LIV-050': { spec: 'rchair', sx: { st2: 'papasan' } }, 'LIV-070': { spec: 'rsofa', sx: { n: 1 } }, 'LIV-090': { spec: 'rsofa', sx: { n: 1, float: 1 } },
    'KIT-007': { spec: 'dripCoffee' }, 'KIT-027': { spec: 'podBrewer' }, 'KIT-011': { spec: 'toaster', kind: 'toast', note: 'Tap to pop bread in; it pops up toasted after 5 seconds.' },
    'KIT-006': { spec: 'dish2', kind: 'dish' }, 'KIT-026': { spec: 'dish2', kind: 'dish' }, 'KIT-046': { spec: 'dish2', kind: 'dish' }, 'KIT-066': { spec: 'dish2', kind: 'dish' }, 'KIT-086': { spec: 'dish2', kind: 'dish' },
    'KIT-031': { spec: 'standMixer', colors: PASTEL }, 'KIT-047': { spec: 'espresso' }, 'KIT-087': { spec: 'sommelier' }, 'KIT-091': { spec: 'synth' },
    'KIT-015': { food: 1 }, 'KIT-035': { food: 2 }, 'KIT-055': { food: 3 }, 'KIT-075': { food: 4 }, 'KIT-095': { food: 5 },
    'KIT-028': { name: 'Wire Fruit Basket & Glass Cookie Jar', spec: 'fruitJar' }, 'KIT-068': { name: 'Glass Cloche Cookie Jar with Choc-Chip Cookies', spec: 'cookieJar' },
    'KIT-019': { spec: 'barstool' }, 'KIT-039': { spec: 'barstool' }, 'KIT-059': { spec: 'barstool' }, 'KIT-079': { spec: 'barstool' }, 'KIT-099': { spec: 'barstool' },
    'KIT-036': { spec: 'rchair' }, 'KIT-056': { spec: 'rchair' }, 'KIT-076': { spec: 'rchair' }, 'KIT-096': { spec: 'podSeat' },
    'KIT-082': { name: 'Ultrasonic Wave-Clean Basin in a Royal Calacatta L-Kitchen', spec: 'luxCounter', sx: { shape: 'L', sink: 1 } }, 'KIT-090': { name: 'Self-Healing Obsidian U-Kitchen with Motorized Lift Cabinets', spec: 'luxCounter', sx: { shape: 'U', lift: 1 } },
    'KIT-093': { name: 'Gilded Teppanyaki & Smart-Scale Chef\'s Island', spec: 'luxCounter', sx: { shape: 'I', tep: 1 } }, 'KIT-073': { spec: 'luxCounter', sx: { shape: 'I', prep: 1 } },
    'KIT-083': { spec: 'robotCart', note: 'Rolls back and forth delivering plates.' },
    'YRD-004': { name: 'Junkyard Charm: Flamingo & Garden Gnome' }, 'YRD-024': { name: 'Cottage Garden: Copper Wind Chime & Birdhouse' }, 'YRD-044': { name: 'Tuscan Terrace: Stone Sundial & Tiered Birdbath' }, 'YRD-064': { name: 'Zen Temple Garden: Limestone Buddha & Pagoda Lanterns' }, 'YRD-084': { name: 'Sky Garden: Levitating Mirror-Chrome Wind Sculpture' },
    'YRD-008': { name: 'Junkyard Charm: Rusty Watering Can & Tin Candle' }, 'YRD-028': { name: 'Cottage Garden: Galvanized Drinks Tub & Gingham Napkins' }, 'YRD-048': { name: 'Tuscan Terrace: Terracotta Torch & Hurricane Lantern' }, 'YRD-068': { name: 'Zen Temple Garden: Brass Ice Bucket & Bonsai Shears' }, 'YRD-088': { name: 'Sky Garden: Holo Star-Map Globe & Floating Carafe' },
    'YRD-061': { name: 'Ivy-Covered Limestone Garden Wall with Wrought-Iron Railing' }, 'YRD-003': { name: 'Single Bug-Zapper Bulb on a Post' }, 'YRD-020': { name: 'Muddy Coir Bristle Patio Mat' },
    'BED-072': { name: 'Floor-to-Ceiling French Windows with Juliet Balcony' }, 'BED-011': { name: 'Narrow Plastic-Frame Wall Mirror' }, 'BTH-003': { name: 'Loose Metal Wall Hook' },
  };
  const Q = { texts: QUOTES, kind: 'text' }, SG = st => ({ sx: { st }, texts: SIGNTX, kind: 'text' }), LED = lv => ({ sx: { lv }, colors: PALS, modes: MODES });
  // ABC block set (Stack blocks move): 3 big stacked blocks + a small one on the floor, colours per band
  N.abcBlocks = S => { const k = S.k, cs = k === 'candy' ? [NE[0], NE[2], NE[4], NE[1]] : k === 'royal' ? ['#f4f1ea', GOLD, '#7a1e2c', '#f4f1ea'] : k === 'junk' ? ['#c9a36a', '#9fb7a0', '#d6b65a', '#b88a5a'] : ['#7cc4e8', '#8fd3a8', '#f6d466', '#f29a8a'], o = { r: 4, bev: 2, mat: 'paint' };
    return { w: 80, d: 54, act: 'play', use: { x: 56, z: 14 }, build: () => [box(-18, 0, 0, 30, 30, 30, cs[0], o), box(16, 0, 6, 30, 30, 30, cs[1], Object.assign({ yaw: 0.3 }, o)), box(-2, 30, 2, 30, 30, 30, cs[2], Object.assign({ yaw: -0.25 }, o)), box(30, 0, -16, 16, 16, 16, cs[3], { r: 3, bev: 1.5, yaw: 0.6, mat: 'paint' })] }; };
  const ADD = [
    ['LIV', 101, 1, 19, 21, 'Wall Quote', 'Hand-Lettered Paper Banner Quote', 'quote', Q], ['LIV', 102, 2, 19, 21, 'Wall Quote', 'Painted Driftwood Plank Quote Sign', 'quote', Q], ['LIV', 103, 3, 19, 21, 'Wall Quote', 'Script Vinyl Wall Quote Decal', 'quote', Q],
    ['LIV', 104, 4, 19, 21, 'Wall Quote', 'Brass Wire Script Wall Quote', 'quote', Q], ['LIV', 105, 5, 19, 21, 'Wall Quote', 'Glowing Neon Script Wall Quote', 'quote', Q],
    ['LIV', 106, 5, 2, 2, 'Floor Surface', 'Mirror-Polished Calacatta Gold Marble Floor', 's:floor', { note: 'Pristine showroom marble with gold inlay and a moving shine.' }],
    ['KIT', 101, 2, 19, 21, 'Wall Quote', "Painted Wooden 'Kitchen' Sign", 'quote', Object.assign({ txt0: 'Kitchen' }, Q)],
    ['KIT', 102, 3, 10, 22, 'Dining Table', 'Solid Oak & Carrara Marble 4-Seat Round Dining Table', 'diningTable', { note: 'Table only - fits 4 dining chairs (sold separately).', sx: { n: 4, round: 1, wood: '#c8925a', top: '#f4f1ec', vein: '#c9c1b5' } }],
    ['KIT', 103, 4, 10, 22, 'Dining Table', 'Walnut Trestle & Calacatta Marble 6-Seat Dining Table', 'diningTable', { note: 'Table only - fits 6 dining chairs (sold separately).', sx: { n: 6, wood: '#6b4226', top: '#f2efea', vein: '#c9b98a' } }],
    ['KIT', 104, 5, 10, 22, 'Dining Table', 'Royal Ebony & Gold-Veined Nero Marble 8-Seat Banquet Table', 'diningTable', { note: 'Table only - fits 8 dining chairs (sold separately).', sx: { n: 8, wood: '#2c2420', top: '#26232b', vein: GOLD, gold: 1 } }],
    ['KIT', 105, 3, 11, 11, 'Dining Chair', 'Walnut & Linen Button-Tufted Dining Chair', 'luxDChair', { colors: LUXC, sx: { wood: '#6b4226' } }],
    ['KIT', 106, 4, 11, 11, 'Dining Chair', 'Brushed Brass & Velvet Channel-Back Dining Chair', 'luxDChair', { colors: LUXC, sx: { gold: 1, st: 'chan' } }],
    ['KIT', 107, 5, 11, 11, 'Dining Chair', 'Royal Ebony & Gold-Leaf Tufted Velvet Dining Chair', 'luxDChair', { colors: LROT(2), sx: { gold: 1, wood: '#2c2420' } }],
    ['LIV', 107, 3, 8, 8, 'Primary Couch', 'Tufted Velvet Chesterfield Sofa on Walnut Feet', 'luxSofa', { colors: LUXC, sx: { n: 3, wood: '#4a2c1a' } }],
    ['LIV', 108, 4, 8, 8, 'Primary Couch', 'Cognac Leather Chesterfield with Brass Nailheads', 'luxSofa', { colors: [{ n: 'Cognac', c: '#a8592b' }, { n: 'Oxblood', c: '#6e2a24' }, { n: 'Espresso', c: '#4a3226' }, { n: 'Forest', c: '#2f4a36' }], sx: { n: 3, brass: 1, wood: '#3a2416' } }],
    ['LIV', 109, 4, 8, 8, 'Primary Couch', 'Ivory Bouclé Channel-Tufted Sofa on a Calacatta Marble Plinth', 'luxSofa', { colors: LROT(5), sx: { n: 3, st: 'chan', plinth: '#f2efea', pil: '#c9a35a' } }],
    ['LIV', 110, 5, 8, 8, 'Primary Couch', 'Royal Velvet & Gold-Leaf Grand Chesterfield', 'luxSofa', { colors: LROT(2), sx: { n: 4, gold: 1 } }],
    ['YRD', 101, 1, 17, 21, 'Backyard Games', 'Chalk Hopscotch Court', 'hopscotch', {}], ['YRD', 102, 2, 17, 21, 'Backyard Games', 'Driveway Basketball Hoop', 'hoop', {}], ['YRD', 103, 3, 17, 21, 'Backyard Games', 'Tetherball Pole', 'tether', {}],
    ['YRD', 104, 4, 17, 21, 'Backyard Games', 'Backyard Soccer Goal', 'goal', {}], ['YRD', 105, 5, 17, 21, 'Backyard Games', 'Climbing Dome Jungle Gym', 'dome', {}],
    // play pieces for the [B] list moves (trampoline -> bounce, slide -> slide, block sets -> stack blocks): archetypes from house4-cat (tramp, slide) + house3d (blocks)
    ['YRD', 120, 1, 17, 21, 'Backyard Games', 'Patched Hand-Me-Down Trampoline', 'tramp', {}], ['YRD', 121, 3, 17, 21, 'Backyard Games', 'Round Sport Trampoline with Safety Pad', 'tramp', {}],
    ['YRD', 122, 5, 17, 21, 'Backyard Games', 'Jelly Bounce Trampoline', 'tramp', {}], ['YRD', 123, 2, 17, 21, 'Backyard Games', 'Wooden Playground Slide', 'slide', {}],
    ['YRD', 124, 4, 17, 21, 'Backyard Games', 'Gilded Garden Slide', 'slide', {}], ['YRD', 125, 5, 17, 21, 'Backyard Games', 'Rainbow Wave Slide', 'slide', {}],
    ['BED', 120, 1, 16, 22, 'Toys & Play', 'Wooden ABC Block Set', 'abcBlocks', {}], ['LIV', 120, 2, 16, 22, 'Toys & Play', 'Chunky ABC Building Blocks', 'abcBlocks', {}],
    ['CLB', 101, 2, 8, 21, 'LED Light Design', 'Colour-Picker LED Strip Cove Kit', 'ledRig', LED(2)], ['CLB', 102, 3, 8, 21, 'LED Light Design', 'Layered LED Pixel Wall with Custom Patterns', 'ledRig', LED(3)],
    ['CLB', 103, 4, 8, 21, 'LED Light Design', 'Tri-Layer Halo Ring & Beam Light Rig', 'ledRig', LED(4)], ['CLB', 104, 5, 8, 21, 'LED Light Design', 'Multi-Layer Laser, Halo & Pixel Light Show', 'ledRig', LED(5)],
    ['CLB', 105, 1, 19, 22, 'Wall Sign', 'Handwritten Cardboard Sign Taped to the Wall', 'rsign', SG('card')], ['CLB', 106, 2, 19, 22, 'Wall Sign', 'Chalkboard Party Sign', 'rsign', SG('chalk')],
    ['CLB', 107, 3, 19, 22, 'Wall Sign', 'Marquee Bulb Letter Sign', 'rsign', SG('marq')], ['CLB', 108, 4, 19, 22, 'Wall Sign', 'Custom Neon Script Sign', 'rsign', SG('neon')],
    ['CLB', 109, 4, 19, 22, 'Wall Sign', 'Scrolling LED Ticker Sign', 'rsign', SG('led')], ['CLB', 110, 5, 19, 22, 'Wall Sign', 'Royal Gold Marquee Crest Sign', 'rsign', SG('royal')],
  ];
  // every remaining seat archetype in the sheet uses the rebuilt seating
  Object.values(M).forEach(arr => arr.forEach((e, i) => { const fix = s => s.replace(/^(sofa|longSofa)(?=$|[.@*+])/, 'rsofa').replace(/^armchair(?=$|[.@*+])/, 'rsofa.1').replace(/^lsofa(?=$|[.@*+])/, 'rsofa.L').replace(/^usofa(?=$|[.@*+])/, 'rsofa.U').replace(/^pit(?=$|[.@*+])/, 'rsofa.pit').replace(/^chair(?=$|[.@*+])/, 'rchair');
    if (Array.isArray(e)) arr[i] = e.map(fix); else arr[i] = fix(e); }));
  const COLW = /\b(burgundy|crimson|red|cherry|mustard|yellow|orange|lavender|purple|plum|navy|blue|teal|mint|sage|green|emerald|olive|charcoal|black|white|cream|ivory|gray|grey|silver|gold|golden|pastel|cobalt|beige)\b/gi;
  function consolidate(R) { const G = new Map(); R.forEach(r => { const k = r.room + '|' + r.slot + '|' + r.name.toLowerCase().replace(COLW, '').replace(/[^a-z]+/g, ' ').trim(); if (!G.has(k)) G.set(k, []); G.get(k).push(r); });
    const drop = new Set(); G.forEach(g => { if (g.length < 2 || g.some(r => r.colors)) return; const keep = g[0]; keep.colors = g.map(r => { const w = (r.name.match(COLW) || ['Colour'])[0]; return { n: w[0].toUpperCase() + w.slice(1).toLowerCase(), c: RD.colorsOf(r.name, 'cot').a }; }); keep.name = keep.name.replace(COLW, '').replace(/\s+/g, ' ').trim(); g.slice(1).forEach(r => drop.add(r)); });
    return R.filter(r => !drop.has(r)); }
  function edit(rows) { let R = rows.filter(r => !DEL.has(r.id)).map(r => SET[r.id] ? Object.assign({}, r, SET[r.id]) : r);
    ADD.forEach(([room, num, tier, bs, slot, slotName, name, spec, ex]) => { const same = rows.filter(r => r.room === room), b = same.find(r => r.tier === tier && r.slot === bs) || same.find(r => r.tier === tier); if (b) R.push(Object.assign({}, b, { id: room + '-' + num, slot, slotName, name, spec, add: 1 }, ex)); });
    R = consolidate(R);
    R.forEach(r => { if (r.room === 'YRD' && (r.slot === 16 || r.slot === 17 || r.slot === 21)) r.catO = 'Games'; if (/Hearth Feature|Outdoor Hearth/.test(r.slotName)) r.live = 'Live fire'; });
    return R; }
  const FOOD = ['tbFruit', 'tbCake', 'tbTeapot', 'tbJar', 'tbCup'];
  RD.food = i => RD.draw({ id: 'FOOD-' + i, name: 'snack', tier: 2, room: 'KIT', slot: 0, spec: FOOD[i % FOOD.length] });
  Object.assign(RD, { edit, PLUS: 1, PALS, MODES, PAINT, QUOTES, SIGNTX });
})();
