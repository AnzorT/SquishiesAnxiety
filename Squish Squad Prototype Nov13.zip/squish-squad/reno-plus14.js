// Renovation Catalog round 14 — Movie Room: CEILINGS + OVERHEAD LIGHTS, game style, creature scale, colours tied to the matching walls.
// Ceilings = r.c14: drawn twice from one recipe — the catalog card (80 x 56 vignette with the tier's wall below) and D.ceilRoom, the room strip
// in real room pixels (1086 x 50, the band the house lays over the top of the walls), so nothing gets stretched. Each ceiling has its own trim
// along the wall line. Overhead lights = ceiling-mounted pieces (mount 'ceil'), animated. Sets RenoDraw.PLUS14; catalog edits RD.SET14.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS13 && RD.H12 && RD.H11 && RD.H10 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS14) return;
  const K = X.K, shade = K.shade, N = RD.N, PI = Math.PI, H = RD.H10;
  const { cam, rng, an, at, SPL, f1, n4, rep, pth, P2 } = H;
  const { DEF11, zsort } = RD.H11;
  const box3 = (C, o) => H.box3(C, Object.assign({}, o, { mat: null, tpat: null, gl: o.gl ? Math.min(o.gl, 0.2) : 0, olw: 1, olo: 0.95, olc: shade(o.col, 0.32), edge: 0.5 }));
  const cyl3 = (C, a, b, r, col, o) => H.cyl3(C, a, b, r, col, Object.assign({}, o || {}, { mat: o && o.mat === 'gloss' ? 'gloss' : 'plastic', pat: null, olw: 0.8, olo: 0.95 }));
  const sph = (C, q, r, col, o) => { const c = C.P(q); return H.sph(C, q, r, col, o) + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * C.k)}" fill="none" stroke="${shade(col, 0.35)}" stroke-width="0.5"/>`; };

  // ======================= CEILINGS =======================
  // frame G: W x H trapezoid (front edge y 0 full width, back edge y H inset ins each side); t = depth 0 front .. 1 back wall; z(y) = size scale
  const FRM = { room: { W: 1259.6, H: 70, ins: 303.8, s: 1 }, card: { W: 80, H: 26, ins: 16, s: 0.16 } };
  const mk = F => { const G = Object.assign({}, F), wk = y => 1 - 2 * G.ins * y / (G.H * G.W);
    G.x = (u, y) => G.ins * y / G.H + u * G.W * wk(y); G.y = t => G.H * (1 - 1 / (1 + 2 * t / 3)) / 0.4; G.z = y => G.s * wk(y) / 0.6;
    G.P = (u, t) => { const y = G.y(t); return f1(G.x(u, y)) + ' ' + f1(y); };
    G.quad = (u0, t0, u1, t1) => 'M' + G.P(u0, t0) + 'L' + G.P(u1, t0) + 'L' + G.P(u1, t1) + 'L' + G.P(u0, t1) + 'Z';
    G.tr = 'M0 0H' + G.W + 'L' + f1(G.W - G.ins) + ' ' + G.H + 'H' + f1(G.ins) + 'Z';
    G.hl = (y, o) => 'M' + f1(G.x(-0.02, y)) + ' ' + f1(y) + 'H' + f1(G.x(1.02, y)); // straight line across at screen y
    G.b = sd => '<filter id="cb' + sd + '" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="' + n4(sd * (G.s < 1 ? 0.35 : 1)) + '"/></filter>';
    return G; };
  // trim along the three wall lines (back edge + both slanted side edges): band bw px wide at the back, lip = lighter inner edge
  const trim = (G, bw, col, ex) => { const n = 12, w = y => bw * G.z(y), L = [], R = [];
    for (let i = 0; i <= n; i++) { const y = G.H * i / n; L.push([G.x(0, y), y]); R.push([G.x(1, y), y]); }
    const sideIn = (P, sg) => P.map(([x, y]) => [x + sg * w(y) * 1.6, y]);
    const back = 'M' + f1(G.ins) + ' ' + f1(G.H - w(G.H)) + 'H' + f1(G.W - G.ins) + 'V' + G.H + 'H' + f1(G.ins) + 'Z';
    const sl = 'M' + L.map(P2).join('L') + 'L' + sideIn(L, 1).reverse().map(P2).join('L') + 'Z', sr = 'M' + R.map(P2).join('L') + 'L' + sideIn(R, -1).reverse().map(P2).join('L') + 'Z';
    const lipB = 'M' + f1(G.ins + w(G.H) * 1.6) + ' ' + f1(G.H - w(G.H)) + 'H' + f1(G.W - G.ins - w(G.H) * 1.6), lipL = 'M' + sideIn(L, 1).map(P2).join('L'), lipR = 'M' + sideIn(R, -1).map(P2).join('L');
    return '<path d="' + back + '" fill="' + col + '"/><path d="' + sl + '" fill="' + shade(col, 0.88) + '"/><path d="' + sr + '" fill="' + shade(col, 0.8) + '"/>'
      + '<path d="' + lipB + lipL + lipR + '" stroke="' + shade(col, 1.4) + '" stroke-width="' + f1(0.8 * G.s) + '" fill="none"/>' + (ex || ''); };
  const light = (G, a, b) => '<defs><linearGradient id="csh" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000000" stop-opacity="' + a + '"/><stop offset="0.7" stop-color="#000000" stop-opacity="0"/><stop offset="0.92" stop-color="#ffffff" stop-opacity="' + (b || 0.05) + '"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs><path d="' + G.tr + '" fill="url(#csh)"/>';
  const doc = (G, body) => '<defs><clipPath id="ctc"><path d="' + G.tr + '"/></clipPath>' + G.b(1) + G.b(3) + G.b(6) + '</defs><g clip-path="url(#ctc)">' + body + '</g>';

  // MOV-009 exposed basement joists, copper + PVC pipes, a stapled wire, cobwebs with a little spider (tier 1: drywall + concrete)
  function cPipes(G) { const R = rng('pipe14'), NJ = 17, hw = 0.0062, y0 = G.y(0);
    let s = '<path d="' + G.tr + '" fill="#7c6852"/>';
    for (let i = 0; i < 22; i++) { const t0 = i / 22, t1 = (i + 1) / 22; s += '<path d="' + G.quad(-0.05, t0, 1.05, t1) + '" fill="' + shade('#7c6852', 0.9 + R() * 0.2) + '"/><path d="' + G.hl(G.y(t1)) + '" stroke="#5c4a37" stroke-width="' + f1(0.5 * G.z(G.y(t1))) + '"/>'; }
    for (let i = 0; i < NJ; i++) { const u = (i + 0.5) / NJ, sd = u < 0.5 ? 1 : -1, dp = 0.011 * (Math.abs(u - 0.5) * 2);
      s += '<path d="' + G.quad(u + sd * hw, 0, u + sd * (hw + dp), 1) + '" fill="#8a6a44"/><path d="' + G.quad(u - hw, 0, u + hw, 1) + '" fill="#b28a5a"/><path d="M' + G.P(u - hw * 0.4, 0) + 'L' + G.P(u - hw * 0.4, 1) + '" stroke="#d2a874" stroke-width="' + f1(0.5 * G.s) + '"/>'; }
    const pipe = (t, th, c0, c1, c2) => { const y = G.y(t), z = G.z(y), h = th * z, id = 'pp' + c0.slice(1);
      return '<defs><linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + c2 + '"/><stop offset="0.35" stop-color="' + c0 + '"/><stop offset="1" stop-color="' + c1 + '"/></linearGradient></defs><rect x="' + f1(G.x(-0.05, y)) + '" y="' + f1(y + 1.6 * z) + '" width="' + f1(G.W * 1.1) + '" height="' + f1(h) + '" fill="#000000" opacity="0.25" filter="url(#cb1)"/><rect x="' + f1(G.x(-0.05, y)) + '" y="' + f1(y) + '" width="' + f1(G.W * 1.1) + '" height="' + f1(h) + '" fill="url(#' + id + ')"/>'
        + rep(6, k => { const u = (k * 3 + 1.5) / NJ; return '<rect x="' + f1(G.x(u, y) - 0.8 * z) + '" y="' + f1(y - 1.2 * z) + '" width="' + f1(1.6 * z) + '" height="' + f1(h + 1.6 * z) + '" rx="' + f1(0.4 * z) + '" fill="#8e9398"/>'; }).join(''); };
    s += pipe(0.5, 6.4, '#d9dde0', '#8f969c', '#f6f8f9') + pipe(0.74, 3.2, '#d98a4e', '#8a4a24', '#f2c08c');
    { const y = G.y(0.5), z = G.z(y), x = G.x(0.71, y); s += '<rect x="' + f1(x - 3.2 * z) + '" y="' + f1(y - 6 * z) + '" width="' + f1(6.4 * z) + '" height="' + f1(6.4 * z) + '" fill="#c3c8cc"/><rect x="' + f1(x - 3.8 * z) + '" y="' + f1(y - 1.4 * z) + '" width="' + f1(7.6 * z) + '" height="' + f1(2 * z) + '" rx="' + f1(0.6 * z) + '" fill="#e6e9eb" stroke="#8f969c" stroke-width="' + f1(0.3 * G.s) + '"/>'; }
    { const ty = G.y(0.8), z = G.z(ty); let d = ''; for (let i = 3; i < 9; i++) { const xa = G.x((i + 0.5) / NJ, ty), xb = G.x((i + 1.5) / NJ, ty); d += (i === 3 ? 'M' : 'L') + f1(xa) + ' ' + f1(ty) + 'Q' + f1((xa + xb) / 2) + ' ' + f1(ty + 3.2 * z) + ' ' + f1(xb) + ' ' + f1(ty); }
      s += '<path d="' + d + '" stroke="#1d1a18" stroke-width="' + f1(0.9 * z) + '" fill="none"/>'; }
    const web = (u, t, r, fl) => { const y = G.y(t), x = G.x(u, y), z = G.z(y) * r, A = rep(6, k => (k / 5) * PI / 2), sx = fl ? -1 : 1;
      let d = A.map(a => 'M' + f1(x) + ' ' + f1(y) + 'l' + f1(sx * Math.cos(a) * 9 * z) + ' ' + f1(-Math.sin(a) * 5 * z)).join('');
      [0.35, 0.65, 0.95].forEach(k => { d += 'M' + A.map(a => f1(x + sx * Math.cos(a) * 9 * z * k) + ' ' + f1(y - Math.sin(a) * 5 * z * k)).join('L'); });
      return '<path d="' + d + '" stroke="#f4f1ea" stroke-opacity="0.55" stroke-width="' + f1(0.35 * G.s) + '" fill="none"/>'; };
    s += web(4 / NJ + hw, 1, 1) + web(13 / NJ - hw, 1, 0.8, 1) + web(0.004, 0.94, 1.1);
    { const y = G.y(1), z = G.z(y), x = G.x(4.6 / NJ, y);
      s += '<g><path d="M' + f1(x) + ' ' + f1(y - 4 * z) + 'v' + f1(3 * z) + '" stroke="#f4f1ea" stroke-opacity="0.6" stroke-width="' + f1(0.25 * G.s) + '"/><g>' + at('translate', '0 0;0 ' + f1(-2.2 * z) + ';0 0', 7, 0, SPL(2)) + '<circle cx="' + f1(x) + '" cy="' + f1(y - 0.6 * z) + '" r="' + f1(0.8 * z) + '" fill="#2a221c"/><path d="M' + f1(x - 1.6 * z) + ' ' + f1(y - 1.2 * z) + 'L' + f1(x + 1.6 * z) + ' ' + f1(y) + 'M' + f1(x + 1.6 * z) + ' ' + f1(y - 1.2 * z) + 'L' + f1(x - 1.6 * z) + ' ' + f1(y) + '" stroke="#2a221c" stroke-width="' + f1(0.3 * z) + '"/></g></g>'; }
    return s + light(G, 0.32, 0.06) + trim(G, 4.2, '#a07c52'); }

  // MOV-029 drop-tile acoustic foam ceiling: charcoal foam tiles in a light grey T-bar grid, one tile knocked askew, a return-air grille (tier 2: charcoal + carpet tiles)
  function cTile(G) { const R = rng('tile14'), NU = 18, NV = 6; let s = '<path d="' + G.tr + '" fill="#26282d"/>', grid = '';
    for (let v = 0; v < NV; v++) for (let u = 0; u < NU; u++) { const t0 = v / NV, t1 = (v + 1) / NV, u0 = u / NU, u1 = (u + 1) / NU, y1 = G.y(t1), z = G.z(y1), odd = u === 11 && v === 4, gr = u === 5 && v === 5;
      if (odd) { s += '<path d="' + G.quad(u0 + 0.004, t0 + 0.05, u1 - 0.01, t1 - 0.02) + '" fill="#45484f" transform="translate(' + f1(1.4 * z) + ' ' + f1(1.2 * z) + ')"/>'; continue; }
      s += '<path d="' + G.quad(u0, t0, u1, t1) + '" fill="' + (gr ? '#5d6168' : shade('#3c3f46', 0.94 + R() * 0.12)) + '"/>';
      if (gr) rep(4, k => s += '<path d="M' + G.P(u0 + 0.004, t0 + (k + 1) * (t1 - t0) / 5) + 'L' + G.P(u1 - 0.004, t0 + (k + 1) * (t1 - t0) / 5) + '" stroke="#2e3035" stroke-width="' + f1(0.7 * z) + '"/>');
      else s += '<path d="M' + G.P(u0 + 0.006, t0 + 0.02) + 'L' + G.P(u1 - 0.006, t0 + 0.02) + '" stroke="#555962" stroke-width="' + f1(0.5 * z) + '"/>' + rep(3, k => '<circle cx="' + f1(G.x(u0 + (k + 0.6) * (u1 - u0) / 3.2, (G.y(t0) + y1) / 2)) + '" cy="' + f1((G.y(t0) + y1) / 2) + '" r="' + f1(0.5 * z) + '" fill="#2a2c31" opacity="0.6"/>').join(''); }
    for (let u = 0; u <= NU; u++) grid += 'M' + G.P(u / NU, 0) + 'L' + G.P(u / NU, 1);
    for (let v = 1; v <= NV; v++) grid += G.hl(G.y(v / NV));
    s += '<path d="' + grid + '" stroke="#55595f" stroke-width="' + f1(1.5 * G.s) + '" fill="none"/><path d="' + grid + '" stroke="#9aa0a6" stroke-width="' + f1(0.7 * G.s) + '" fill="none"/>';
    return s + light(G, 0.3, 0.05) + trim(G, 2.6, '#9aa0a6'); }

  // MOV-049 coffered dark wood ceiling: walnut beams, burgundy recessed coffers (like the velvet walls), gold rosettes, a warm pin light in every coffer
  function cCoffer(G) { const NU = 12, NV = 5, bw = 0.012; let s = '<path d="' + G.tr + '" fill="#3e2416"/>', ros = '';
    for (let v = 0; v < NV; v++) for (let u = 0; u < NU; u++) { const t0 = v / NV + 0.03, t1 = (v + 1) / NV - 0.03, u0 = u / NU + bw, u1 = (u + 1) / NU - bw, ym = G.y((t0 + t1) / 2), z = G.z(ym), xm = G.x((u0 + u1) / 2, ym);
      s += '<path d="' + G.quad(u0, t0, u1, t1) + '" fill="#6e4329"/><path d="' + G.quad(u0 + 0.006, t0 + 0.04, u1 - 0.006, t1 - 0.012) + '" fill="#5a1a26"/><path d="' + G.quad(u0 + 0.006, t0 + 0.04, u1 - 0.006, t0 + 0.07) + '" fill="#000000" opacity="0.3"/>'
        + '<ellipse cx="' + f1(xm) + '" cy="' + f1(ym) + '" rx="' + f1(6 * z) + '" ry="' + f1(2.4 * z) + '" fill="#ffc27a" opacity="0.35" filter="url(#cb3)"/><ellipse cx="' + f1(xm) + '" cy="' + f1(ym) + '" rx="' + f1(1.6 * z) + '" ry="' + f1(0.7 * z) + '" fill="#fff0c8"/>'; }
    for (let v = 0; v <= NV; v++) for (let u = 0; u <= NU; u++) { const y = G.y(v / NV), z = G.z(y); ros += '<circle cx="' + f1(G.x(u / NU, y)) + '" cy="' + f1(y) + '" r="' + f1(0.95 * z) + '" fill="#d9ac4a"/>'; }
    let bl = ''; for (let u = 0; u <= NU; u++) bl += 'M' + G.P(u / NU - bw * 0.6, 0) + 'L' + G.P(u / NU - bw * 0.6, 1); for (let v = 1; v <= NV; v++) bl += G.hl(G.y(v / NV) - 0.6 * G.z(G.y(v / NV)));
    s += '<path d="' + bl + '" stroke="#8a5a36" stroke-width="' + f1(0.6 * G.s) + '" fill="none" opacity="0.8"/>' + ros;
    return s + light(G, 0.3, 0.06) + trim(G, 4.6, '#4a2b1a', '<path d="' + G.hl(G.H - 4.6 * G.z(G.H) + 0.9 * G.s) + '" stroke="#d9ac4a" stroke-width="' + f1(0.7 * G.s) + '"/>'); }

  // MOV-069 fibre-optic night sky: navy dome, twinkling fibre stars, faint Milky Way, a shooting star, walnut crown with the amber LED cove of the slat walls
  function cSky(G) { const R = rng('sky14'); let s = '<defs><linearGradient id="skg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0b0e26"/><stop offset="1" stop-color="#1c2252"/></linearGradient></defs><path d="' + G.tr + '" fill="url(#skg)"/>';
    s += '<g filter="url(#cb6)" opacity="0.5"><ellipse cx="' + f1(G.W * 0.42) + '" cy="' + f1(G.H * 0.62) + '" rx="' + f1(G.W * 0.38) + '" ry="' + f1(G.H * 0.14) + '" fill="#7a76c8" transform="rotate(-2 ' + f1(G.W * 0.42) + ' ' + f1(G.H * 0.62) + ')"/><ellipse cx="' + f1(G.W * 0.6) + '" cy="' + f1(G.H * 0.7) + '" rx="' + f1(G.W * 0.16) + '" ry="' + f1(G.H * 0.08) + '" fill="#b49ad8"/></g>';
    const COL = ['#ffffff', '#fff2cc', '#cfe4ff', '#ffffff', '#ffd6ef', '#bff6ee'];
    rep(170, i => { const u = R(), t = 0.25 + R() * 0.75, y = G.y(t), z = G.z(y), x = G.x(u, y), r = (0.45 + R() * 0.7) * z;
      s += '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(r) + '" fill="' + COL[i % 6] + '">' + an('opacity', '0.25;1;0.25', n4(1.6 + R() * 3.2), n4(-R() * 4)) + '</circle>'; });
    { const y = G.y(0.8), z = G.z(y), x = G.x(0.3, y); s += '<g opacity="0"><path d="M0 0L' + f1(-26 * z) + ' ' + f1(-1 * z) + 'L' + f1(-26 * z) + ' ' + f1(0.6 * z) + 'Z" fill="#ffffff" transform="translate(' + f1(x) + ' ' + f1(y) + ')"/>' + an('opacity', '0;0;1;0;0', 11, -3, ' keyTimes="0;0.86;0.89;0.94;1"') + at('translate', '0 0;0 0;' + f1(60 * z) + ' ' + f1(3 * z) + ';' + f1(110 * z) + ' ' + f1(6 * z) + ';' + f1(110 * z) + ' ' + f1(6 * z), 11, -3, ' keyTimes="0;0.86;0.89;0.94;1"') + '</g>'; }
    const yb = G.H - 4.4 * G.z(G.H);
    return s + light(G, 0.25, 0.04) + trim(G, 4.4, '#5e3722', '<path d="' + G.hl(yb - 0.6 * G.s) + '" stroke="#ffcf7a" stroke-width="' + f1(4 * G.s) + '" opacity="0.4" filter="url(#cb3)">' + an('opacity', '0.3;0.55;0.3', 4, 0, SPL(2)) + '</path><path d="' + G.hl(yb - 0.3 * G.s) + '" stroke="#ffe7b8" stroke-width="' + f1(0.7 * G.s) + '"/>'); }

  // MOV-089 360 Atmos nebula projection vault: drifting violet / cyan / pink nebula clouds, stars, a projector sweep, obsidian trim with the walls' violet line
  function cNeb(G) { const R = rng('neb14'); let s = '<path d="' + G.tr + '" fill="#0a0818"/>';
    const CL = [['#7a3cff', 0.2, 0.55, 0.22], ['#3fd0ff', 0.55, 0.7, 0.18], ['#ff5fb4', 0.82, 0.5, 0.16], ['#a66bff', 0.4, 0.9, 0.2], ['#3fd0ff', 0.05, 0.85, 0.14], ['#ff5fb4', 0.65, 0.95, 0.12], ['#7a3cff', 0.95, 0.8, 0.18]];
    s += '<g filter="url(#cb6)">' + CL.map(([c, u, t, w], i) => { const y = G.y(t), x = G.x(u, y), dx = f1((i % 2 ? -1 : 1) * G.W * 0.05);
      return '<ellipse cx="' + f1(x) + '" cy="' + f1(y) + '" rx="' + f1(G.W * w) + '" ry="' + f1(G.H * 0.16) + '" fill="' + c + '" opacity="0.55">' + at('translate', '0 0;' + dx + ' 0;0 0', 14 + i * 3, -i * 2, SPL(2)) + an('opacity', '0.4;0.7;0.4', 6 + i, -i, SPL(2)) + '</ellipse>'; }).join('') + '</g>';
    rep(120, i => { const t = 0.2 + R() * 0.8, y = G.y(t), z = G.z(y); s += '<circle cx="' + f1(G.x(R(), y)) + '" cy="' + f1(y) + '" r="' + f1((0.4 + R() * 0.6) * z) + '" fill="' + (i % 4 ? '#ffffff' : '#cfe6ff') + '">' + an('opacity', '0.2;1;0.2', n4(1.6 + R() * 3), n4(-R() * 4)) + '</circle>'; });
    s += '<defs><linearGradient id="nsw" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#e6dcff" stop-opacity="0.14"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs><rect x="' + f1(-G.W * 0.3) + '" width="' + f1(G.W * 0.2) + '" height="' + G.H + '" fill="url(#nsw)">' + at('translate', '0 0;0 0;' + f1(G.W * 1.5) + ' 0', 9, 0, ' keyTimes="0;0.5;1"') + '</rect>';
    const yb = G.H - 3.6 * G.z(G.H);
    return s + light(G, 0.2, 0.03) + trim(G, 3.6, '#0e0b1e', '<path d="' + G.hl(yb - 0.8 * G.s) + '" stroke="#7a6cff" stroke-width="' + f1(4 * G.s) + '" opacity="0.4" filter="url(#cb3)">' + an('opacity', '0.2;0.5;0.2', 4, 0, SPL(2)) + '</path><path d="' + G.hl(yb + 0.6 * G.s) + '" stroke="#a49bff" stroke-width="' + f1(0.6 * G.s) + '"/>'); }

  // card: the tier's wall below the ceiling (same colours as the MOV wall of that tier)
  const WALLC = { pipes: '#c5c3bc', tile: '#4a4e57', coffer: '#951e33', sky: '#704329', neb: '#27223a' };
  const CBASE = { pipes: ['#7c6852', '#a07c52'], tile: ['#26282d', '#9aa0a6'], coffer: ['#3e2416', '#4a2b1a'], sky: ['#0b0e26', '#5e3722'], neb: ['#0a0818', '#0e0b1e'] };
  const CEIL14 = { pipes: cPipes, tile: cTile, coffer: cCoffer, sky: cSky, neb: cNeb };
  const cardOf = k => { const G = mk(FRM.card), w = WALLC[k];
    return '<path d="M16 26H64V56H16Z" fill="' + w + '"/><path d="M0 0L16 26V56H0Z" fill="' + shade(w, 0.88) + '"/><path d="M80 0L64 26V56H80Z" fill="' + shade(w, 0.8) + '"/><path d="M16 26V56M64 26V56" stroke="#000000" stroke-opacity="0.2" stroke-width="0.6"/>'
      + doc(G, CEIL14[k](G)) + '<path d="' + G.tr + '" fill="none" stroke="#000000" stroke-opacity="0.25" stroke-width="0.5"/>'; };

  // ======================= OVERHEAD LIGHTS (ceiling pieces) =======================
  const DEF14 = DEF11 + '<filter id="l14b1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.8"/></filter><filter id="l14b3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>'
    + '<radialGradient id="l14w" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff0c0" stop-opacity="0.85"/><stop offset="0.35" stop-color="#ffd27a" stop-opacity="0.35"/><stop offset="1" stop-color="#ffc060" stop-opacity="0"/></radialGradient>';
  const glow = (C, q, r, op, A) => { const c = C.P(q); return `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * C.k)}" fill="url(#l14w)" opacity="${op}">${A || ''}</circle>`; };
  const ring = (C, y, r, a0, a1, n) => rep(n + 1, i => { const a = a0 + (a1 - a0) * i / n; return C.p(r * Math.sin(a), y, r * Math.cos(a)); });
  const swing = (C, q, deg, T, b) => { const c = C.P(q); return `<animateTransform attributeName="transform" type="rotate" values="${-deg} ${P2(c)};${deg} ${P2(c)};${-deg} ${P2(c)}" dur="${n4(T)}s" begin="${n4(b || 0)}s" repeatCount="indefinite"${SPL(2)}/>`; };
  const FLK = (T, b) => an('opacity', '1;0.9;1;0.72;1;1', T, b, ' keyTimes="0;0.3;0.45;0.5;0.56;1"');

  // MOV-015 bare pull-chain utility bulb: porcelain ceiling socket, cloth cord, clear bulb with a glowing filament; sways, chain swings, flickers
  N.bulb14 = S => { const T = 46, D = { w: 16, d: 16, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx), b = C.P([0, 9.5, 0]), k = C.k;
      const chain = rep(9, i => { const q = C.p(1.3 + i * 0.05, 16 - i * 1.15, 0.6); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.36 * k)}" fill="#b9b2a2" stroke="#6e685c" stroke-width="0.2"/>`; }).join('') + (q => `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.8 * k)}" fill="#d8cfbc" stroke="#6e685c" stroke-width="0.25"/>`)(C.p(1.75, 5.2, 0.6));
      const fil = `<path d="M${f1(b[0] - 1.2 * k)} ${f1(b[1] + 1.8 * k)}L${f1(b[0] - 0.8 * k)} ${f1(b[1] - 0.6 * k)}Q${f1(b[0])} ${f1(b[1] - 1.6 * k)} ${f1(b[0] + 0.8 * k)} ${f1(b[1] - 0.6 * k)}L${f1(b[0] + 1.2 * k)} ${f1(b[1] + 1.8 * k)}" stroke="#ff9a2a" stroke-width="${f1(0.35 * k)}" fill="none"/><path d="M${f1(b[0] - 0.8 * k)} ${f1(b[1] - 0.6 * k)}Q${f1(b[0])} ${f1(b[1] - 1.6 * k)} ${f1(b[0] + 0.8 * k)} ${f1(b[1] - 0.6 * k)}" stroke="#fff6d0" stroke-width="${f1(0.18 * k)}" fill="none"/>`;
      let s = cyl3(C, [0, T - 2, 0], [0, T, 0], 3.2, '#efe8d8');
      s += `<g>${swing(C, [0, T - 2, 0], 2.6, 4.6)}${glow(C, [0, 9.5, 0], 17, 0.9, FLK(5.2))}` + cyl3(C, [0, T - 2, 0], [0, 20, 0], 0.4, '#2c2622') + cyl3(C, [0, 20, 0], [0, 15, 0], 1.8, '#ddd5c4')
        + cyl3(C, [0, 15, 0], [0, 12.6, 0], 1.15, '#c9a85a') + `<g>${swing(C, [1.3, 16, 0.6], 6, 2.3, -0.6)}${chain}</g>` + sph(C, [0, 9.5, 0], 3.6, '#fff1b8', { op: 0.92 }) + `<g>${FLK(5.2)}${fil}</g>` + `<ellipse cx="${f1(b[0] - 1.3 * k)}" cy="${f1(b[1] - 1.4 * k)}" rx="${f1(0.9 * k)}" ry="${f1(0.6 * k)}" fill="#ffffff" opacity="0.8"/></g>`;
      return { defs: DEF14, front: s, bb: C.bb(4) }; };
    return D; };

  // MOV-035 dimmer-switch track spotlight bar: black track on two rods, four spot cans that pan slowly, warm beams that dim up and down
  N.track14 = S => { const T = 34, HX = [-27, -9, 9, 27], D = { w: 84, d: 14, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx), k = C.k; let s = '', beams = '';
      [-30, 30].forEach(x => s += cyl3(C, [x, T - 0.6, 0], [x, T, 0], 2.2, '#2a2b30') + cyl3(C, [x, T - 5, 0], [x, T - 0.6, 0], 0.55, '#3a3c42'));
      s += box3(C, { c: [0, T - 7.6, 0], w: 82, h: 2.6, d: 3.2, r: 0.6, col: '#1d1e22' }) + `<path d="M${P2(C.p(-40, T - 6.2, 1.62))}L${P2(C.p(40, T - 6.2, 1.62))}" stroke="#ffffff" stroke-opacity="0.22" stroke-width="${f1(0.4 * k)}"/>`;
      HX.forEach((x, i) => { const dx = x * 0.12, L = C.P([x + dx, T - 14.4, 4.2]), id = C.u('tb'), F = [C.p(x + dx * 4 - 12, -30, 34), C.p(x + dx * 4 + 12, -30, 34)], dim = an('opacity', '0.55;1;0.55', 6, -i * 1.5, SPL(2));
        beams += `<defs><linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${f1(L[0])}" y1="${f1(L[1])}" x2="${f1((F[0][0] + F[1][0]) / 2)}" y2="${f1(F[0][1])}"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.5"/><stop offset="1" stop-color="#ffd690" stop-opacity="0"/></linearGradient></defs><g>${swing(C, [x, T - 9, 0], 5, 9 + i, -i * 2)}<g>${dim}<path d="M${f1(L[0] - 1.6 * k)} ${f1(L[1])}L${P2(F[0])}L${P2(F[1])}L${f1(L[0] + 1.6 * k)} ${f1(L[1])}Z" fill="url(#${id})"/></g></g>`;
        s += `<g>${swing(C, [x, T - 9, 0], 5, 9 + i, -i * 2)}` + cyl3(C, [x, T - 7.6, 0], [x, T - 10, 0], 0.6, '#2a2b30') + cyl3(C, [x - dx * 0.2, T - 10.4, -2.2], [x + dx, T - 14.4, 4.2], 2.3, '#1b1c20', { mat: 'gloss', cap: cr => `<circle r="${f1(cr * 0.8)}" fill="#fff2cc"/><circle r="${f1(cr * 0.45)}" fill="#ffffff"/>` })
          + `<g>${dim}${glow(C, [x + dx, T - 14.6, 4.6], 5, 0.8)}</g></g>`; });
      return { defs: DEF14, front: beams + s, bb: C.bb(4) }; };
    return D; };

  // MOV-055 Art Deco frosted glass flush-mount: brass canopy, three stepped frosted tiers with fluted lines and brass bands, soft breathing glow on the ceiling
  N.flush14 = S => { const T = 14, GD = '#c9a04a', D = { w: 34, d: 34, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx); let s = '';
      const TI = [[T - 1.2, T - 4.4, 13.6, 12.4], [T - 5.2, T - 8, 11, 8.6], [T - 8.8, T - 10.8, 7.4, 4.2]];
      s += glow(C, [0, T, 0], 34, 0.6, an('opacity', '0.45;0.75;0.45', 5, 0, SPL(2))) + cyl3(C, [0, T - 1.2, 0], [0, T, 0], 15, GD, { mat: 'gloss' });
      TI.forEach(([y0, y1, r0, r1], i) => { s += cyl3(C, [0, y0, 0], [0, y1, 0], r0, '#f6f0e2', { r2: r1, op: 0.96 });
        s += rep(9, j => { const a = C.thV + (j - 4) * 0.3, p = C.p(r0 * Math.sin(a), y0, r0 * Math.cos(a)), q = C.p(r1 * Math.sin(a), y1, r1 * Math.cos(a)); return `<path d="M${P2(p)}L${P2(q)}" stroke="#d6c7a6" stroke-width="${f1(0.22 * C.k)}"/>`; }).join('');
        if (i < 2) s += cyl3(C, [0, y1, 0], [0, y1 - 0.8, 0], r1, GD, { mat: 'gloss' }); });
      const m = C.P([0, T - 6, 0]); s += `<ellipse cx="${f1(m[0])}" cy="${f1(m[1])}" rx="${f1(9 * C.k)}" ry="${f1(3.4 * C.k)}" fill="#fff6d8" opacity="0.5" filter="url(#l14b1)">${an('opacity', '0.35;0.6;0.35', 5, 0, SPL(2))}</ellipse>` + sph(C, [0, T - 12, 0], 1.4, GD);
      return { defs: DEF14, front: s, bb: C.bb(4) }; };
    return D; };

  // MOV-075 motorized brass & crystal chandelier: canopy + motor box (blinking LED), chain, brass column, two rings of candle bulbs,
  // crystal drops that sparkle; the motor slowly lowers and raises it and it sways a little
  N.chand14 = S => { const T = 60, GD = '#c9a04a', D = { w: 50, d: 50, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx), k = C.k, v = C.v; let top = '', L = [];
      top += cyl3(C, [0, T - 1.6, 0], [0, T, 0], 4.4, GD, { mat: 'gloss' }) + box3(C, { c: [0, T - 6, 0], w: 5, h: 4.4, d: 5, r: 0.8, col: '#7a5a24' });
      { const q = C.p(0, T - 4, 2.55); top += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.45 * k)}" fill="#6fe39a">${an('opacity', '1;0.2;1', 1.6)}</circle>`; }
      const ch = rep(10, i => { const q = C.p(0, T - 6.6 - i * 1.9, 0); return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((i % 2 ? 0.35 : 0.7) * k)}" ry="${f1(1.05 * k)}" fill="none" stroke="${GD}" stroke-width="${f1(0.35 * k)}"/>`; }).join('');
      const R1 = 20, Y1 = 22, R2 = 11, Y2 = 30, fr = a => Math.sin(a) * v[0] + Math.cos(a) * v[2] > 0;
      const rp = (P, w) => `<path d="M${P.map(P2).join('L')}" stroke="${GD}" stroke-width="${f1(w * k)}" fill="none" stroke-linecap="round"/><path d="M${P.map(P2).join('L')}" stroke="#fff0b8" stroke-opacity="0.5" stroke-width="${f1(w * 0.3 * k)}" fill="none" transform="translate(0 ${f1(-w * 0.25 * k)})"/>`;
      const back = C.thV + PI, ringB = (r, y, w) => rp(ring(C, y, r, back - PI / 2, back + PI / 2, 24), w), ringF = (r, y, w) => rp(ring(C, y, r, C.thV - PI / 2, C.thV + PI / 2, 24), w);
      const cand = (r, y, a, i) => { const x = r * Math.sin(a), z = r * Math.cos(a), f = C.P([x, y + 5.4, z]);
        return cyl3(C, [x, y, z], [x, y + 0.6, z], 1.5, GD, { mat: 'gloss' }) + cyl3(C, [x, y + 0.6, z], [x, y + 4.4, z], 0.85, '#f6efe0') + glow(C, [x, y + 5.4, z], 5, 0.8, FLK(3 + (i % 3) * 0.7, -i * 0.4)) + `<ellipse cx="${f1(f[0])}" cy="${f1(f[1])}" rx="${f1(0.75 * k)}" ry="${f1(1.25 * k)}" fill="#fff0c0"/>`; };
      const drop = (r, y, a, i) => { const x = r * Math.sin(a), z = r * Math.cos(a), q = C.P([x, y - 3.4, z]), h = C.P([x, y, z]), w = 1 * k, hh = 1.8 * k;
        return `<path d="M${P2(h)}L${f1(q[0])} ${f1(q[1] - hh)}" stroke="#d9e8ee" stroke-width="${f1(0.15 * k)}"/><path d="M${f1(q[0])} ${f1(q[1] - hh)}L${f1(q[0] + w)} ${f1(q[1])}L${f1(q[0])} ${f1(q[1] + hh * 1.4)}L${f1(q[0] - w)} ${f1(q[1])}Z" fill="#dff3ff" stroke="#9cc6d8" stroke-width="${f1(0.15 * k)}" opacity="0.9"/>`
          + `<circle cx="${f1(q[0] - w * 0.3)}" cy="${f1(q[1] - hh * 0.3)}" r="${f1(0.55 * k)}" fill="#ffffff" opacity="0">${an('opacity', '0;0;1;0;0', 2.6 + (i % 5) * 0.5, -i * 0.37, ' keyTimes="0;0.6;0.7;0.8;1"')}</circle>`; };
      rep(8, i => { const a = i * PI / 4 + PI / 8; L.push({ q: [R1 * Math.sin(a), Y1, R1 * Math.cos(a)], s: cand(R1, Y1, a, i) }); });
      rep(5, i => { const a = i * 2 * PI / 5; L.push({ q: [R2 * Math.sin(a), Y2, R2 * Math.cos(a)], s: cand(R2, Y2, a, i + 8) }); });
      rep(16, i => { const a = i * PI / 8; L.push({ q: [R1 * Math.sin(a), Y1 - 2, R1 * Math.cos(a)], s: drop(R1, Y1, a, i) }); });
      rep(10, i => { const a = i * PI / 5 + 0.3; L.push({ q: [R2 * 0.9 * Math.sin(a), Y2 - 2, R2 * 0.9 * Math.cos(a)], s: drop(R2 * 0.9, Y2 - 0.4, a, i + 16) }); });
      const isF = o => o.q[0] * v[0] + o.q[2] * v[2] > 0, Lb = L.filter(o => !isF(o)), Lf = L.filter(isF);
      const arms = rep(8, i => { const a = i * PI / 4 + PI / 8; return `<path d="M${P2(C.p(0, 28, 0))}Q${P2(C.p(R1 * 0.5 * Math.sin(a), 18, R1 * 0.5 * Math.cos(a)))} ${P2(C.p(R1 * Math.sin(a), Y1, R1 * Math.cos(a)))}" stroke="${GD}" stroke-width="${f1(0.7 * k)}" fill="none"/>`; }).join('');
      let body = glow(C, [0, 26, 0], 38, 0.55, an('opacity', '0.45;0.65;0.45', 4, 0, SPL(2))) + ch + ringB(R1, Y1, 1.3) + ringB(R2, Y2, 1) + zsort(C, Lb) + arms + cyl3(C, [0, T - 25, 0], [0, 13, 0], 1.2, GD, { mat: 'gloss' }) + sph(C, [0, 26, 0], 2.6, GD) + sph(C, [0, 12, 0], 1.7, GD)
        + ringF(R1, Y1, 1.3) + ringF(R2, Y2, 1) + zsort(C, Lf);
      body = `<g>${swing(C, [0, T - 6, 0], 1.4, 7)}<g>${at('translate', `0 0;0 ${f1(2.4 * k)};0 0`, 12, 0, SPL(2))}${body}</g></g>`;
      return { defs: DEF14, front: body + top, bb: C.bb(4) }; };
    return D; };

  // MOV-095 voice-synced ambient aurora ceiling halo: two floating rings on fine wires, aurora colours flowing round them, soft aurora curtains
  // rising to the ceiling and a "voice" pulse ring every few seconds
  N.halo14 = S => { const T = 40, R1 = 42, Y1 = 18, R2 = 29, Y2 = 22, D = { w: 96, d: 96, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx), k = C.k, A = C.P([-R1, Y1, 0]), B = C.P([R1, Y1, 0]), g = C.u('ag');
      const STO = '<stop offset="0" stop-color="#4fe0b0"/><stop offset="0.25" stop-color="#3fb8ff"/><stop offset="0.5" stop-color="#a66bff"/><stop offset="0.75" stop-color="#ff6ad5"/><stop offset="1" stop-color="#4fe0b0"/>', Lg = B[0] - A[0];
      let s = `<defs><linearGradient id="${g}" gradientUnits="userSpaceOnUse" x1="${f1(A[0])}" y1="0" x2="${f1(B[0])}" y2="0" spreadMethod="repeat">${STO}<animateTransform attributeName="gradientTransform" type="translate" values="0 0;${f1(Lg)} 0" dur="7s" repeatCount="indefinite"/></linearGradient></defs>`;
      const path = (r, y, a0, a1) => 'M' + ring(C, y, r, a0, a1, 40).map(P2).join('L'), bk = C.thV + PI;
      rep(3, i => { const a = i * 2 * PI / 3 + 0.4, top = C.p(R1 * 0.6 * Math.sin(a), T, R1 * 0.6 * Math.cos(a)), bot = C.p(R1 * Math.sin(a), Y1, R1 * Math.cos(a)); s += `<path d="M${P2(top)}L${P2(bot)}" stroke="#c9cfd8" stroke-opacity="0.7" stroke-width="${f1(0.18 * k)}"/>` + `<circle cx="${f1(top[0])}" cy="${f1(top[1])}" r="${f1(0.9 * k)}" fill="#c9cfd8"/>`; });
      s += `<g filter="url(#l14b3)" opacity="0.5">${rep(5, i => { const a = bk - PI / 2 + i * PI / 4, p = C.p(R1 * Math.sin(a), Y1, R1 * Math.cos(a)), q = C.p(R1 * 0.8 * Math.sin(a), T - 4, R1 * 0.8 * Math.cos(a));
        return `<path d="M${f1(p[0] - 4 * k)} ${f1(p[1])}L${f1(q[0] - 3 * k)} ${f1(q[1])}L${f1(q[0] + 3 * k)} ${f1(q[1])}L${f1(p[0] + 4 * k)} ${f1(p[1])}Z" fill="url(#${g})">${an('opacity', '0.2;0.7;0.2', 4 + i * 0.9, -i)}</path>`; }).join('')}</g>`;
      const rings = (a0, a1, op) => [[R1, Y1, 2.4], [R2, Y2, 1.5]].map(([r, y, w]) => `<path d="${path(r, y, a0, a1)}" stroke="url(#${g})" stroke-width="${f1(w * 2.6 * k)}" fill="none" opacity="${op * 0.45}" filter="url(#l14b1)"/><path d="${path(r, y, a0, a1)}" stroke="#e8ecf2" stroke-width="${f1(w * k)}" fill="none" stroke-linecap="round" opacity="${op}"/><path d="${path(r, y, a0, a1)}" stroke="url(#${g})" stroke-width="${f1(w * 0.62 * k)}" fill="none" stroke-linecap="round" opacity="${op}"/>`).join('');
      s += rings(bk - PI / 2, bk + PI / 2, 0.75);
      const c = C.P([0, Y1, 0]), rx = Math.abs(B[0] - A[0]) / 2, ry = Math.abs(C.P([0, Y1, R1])[1] - c[1]);
      s += `<ellipse cx="${f1(c[0])}" cy="${f1(c[1])}" rx="${f1(rx)}" ry="${f1(ry)}" fill="none" stroke="#bff6ee" stroke-width="${f1(0.6 * k)}" opacity="0"><animate attributeName="rx" values="${f1(rx)};${f1(rx * 1.3)}" dur="3.2s" repeatCount="indefinite"/><animate attributeName="ry" values="${f1(ry)};${f1(ry * 1.3)}" dur="3.2s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.8;0" dur="3.2s" repeatCount="indefinite"/></ellipse>`;
      s += rings(C.thV - PI / 2, C.thV + PI / 2, 1);
      return { defs: DEF14, front: s, bb: C.bb(4) }; };
    return D; };

  const draw13 = RD.draw;
  RD.draw = (r, o) => { const res = draw13(r, o); if (!res || res._p14) return res;
    try { const k = r.c14 && CEIL14[r.c14]; if (k && res.surf) { res._p14 = 1; res.vb = '0 0 80 56'; res.svg = RD.svgDoc('0 0 80 56', [], cardOf(r.c14)); res.src = 'data:image/svg+xml,' + encodeURIComponent(res.svg);
        const G = mk(FRM.room); res.ceilRoom = RD.svgDoc('0 0 ' + G.W + ' ' + G.H, [], doc(G, k(G))); res.ceilBase = CBASE[r.c14][0]; res.ceilTrim = CBASE[r.c14][1]; } } catch (e) { console.warn('reno plus14', r.id, e); }
    return res; };

  RD.SET14 = {
    'MOV-009': { c14: 'pipes', live: 'Spider on a thread', note: 'Bare wooden joists under rough subfloor boards, a grey drain pipe and a copper water line on metal straps, a stapled wire sagging between the joists, and dusty cobwebs in the corners. A tiny spider bobs on its thread.' },
    'MOV-029': { c14: 'tile', note: 'A light grey T-bar grid holding charcoal acoustic foam tiles that soak up sound. One tile has been knocked a little askew and there is a return-air grille in the back row.' },
    'MOV-049': { c14: 'coffer', note: 'Deep coffers framed by dark walnut beams, each lined in burgundy to match the velvet walls, with a gold rosette at every crossing and a warm pin light glowing in each coffer.' },
    'MOV-069': { c14: 'sky', live: 'Twinkling stars', note: 'A navy night-sky dome full of fibre-optic stars in warm and cool white that twinkle at their own pace, a faint Milky Way, now and then a shooting star, and a walnut crown with an amber LED cove.' },
    'MOV-089': { c14: 'neb', live: 'Drifting nebula', note: 'A 360-degree projection vault: violet, cyan and pink nebula clouds drift slowly over a field of twinkling stars while a soft projector sweep passes over, edged in obsidian with a violet light line.' },
    'MOV-015': { spec: 'bulb14', s3: null, live: 'Swaying bulb', note: 'A clear utility bulb in a porcelain socket on a short cloth cord, with a glowing filament and a little pull chain. It sways gently, the chain swings and the light flickers now and then.' },
    'MOV-035': { spec: 'track14', s3: null, live: 'Dimming spots', note: 'A black ceiling track on two rods with four spot cans. The cans pan slowly and their warm beams dim up and down like someone is playing with the dimmer.' },
    'MOV-055': { spec: 'flush14', s3: null, live: 'Soft glow', note: 'An Art Deco flush-mount: a brass canopy with three stepped frosted-glass tiers, fluted lines and brass bands, glowing softly and lighting the ceiling around it.' },
    'MOV-075': { spec: 'chand14', s3: null, live: 'Sparkling crystals', note: 'A brass chandelier on a motorized winch: a chain, two rings of candle bulbs and rows of crystal drops that sparkle. The motor slowly lowers and raises it and it sways a little.' },
    'MOV-095': { spec: 'halo14', s3: null, live: 'Aurora colours', note: 'Two floating rings on fine wires with aurora colours flowing round them, soft aurora curtains rising to the ceiling and a pulse ring that ripples out when it hears voices.' },
  };
  const edit13 = RD.edit;
  RD.edit = rows => edit13(rows).map(r => RD.SET14[r.id] ? Object.assign({}, r, RD.SET14[r.id]) : r);
  RD.H14 = { mk, FRM, CEIL14 };
  RD.PLUS14 = 1;
})();
