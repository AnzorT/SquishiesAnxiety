// Yard Mini Games: SLIDE & SPLASH (the backyard's Slides: Wooden / Gold / Rainbow). Side view.
// 1) Tap to push off: the power bar swings, stronger push = farther. 2) Tap again as you reach the end of the slide to jump (Perfect at the lip).
// Land in the pool's floating rings: near 10, middle 30, far 50 (the glowing ring scores double); past the pool = too far. 5 slides.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add) return setTimeout(go, 30); const { S, cl, lerp, r2, SFX } = YG;
  const ICON = '<svg viewBox="0 0 120 84" aria-hidden="true"><rect width="120" height="84" fill="#cfeaff"/><rect y="66" width="120" height="18" fill="#9fdc6e"/>' +
    '<path d="M16 72V22M30 72V22M16 32H30M16 44H30M16 56H30" stroke="#f4f6fb" stroke-width="2.6" stroke-linecap="round"/><path d="M12 20H36V25H12Z" fill="#c9b8f2"/>' +
    '<path d="M34 22L46 34L58 46L70 58L80 64" stroke="url(#ygRb)" stroke-width="9" stroke-linecap="round" fill="none"/>' +
    '<defs><linearGradient id="ygRb" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7ee0d6"/><stop offset="0.3" stop-color="#ffe36e"/><stop offset="0.55" stop-color="#ffab5c"/><stop offset="0.8" stop-color="#9be27a"/><stop offset="1" stop-color="#8fb4ff"/></linearGradient></defs>' +
    '<rect x="84" y="62" width="32" height="12" rx="6" fill="#5cc2ff"/><path d="M86 64Q93 61 100 64T114 64" stroke="#fff" stroke-width="1.6" fill="none"/><ellipse cx="100" cy="63" rx="7" ry="2.4" fill="none" stroke="#ff7fbf" stroke-width="2.4"/></svg>';
  const LOOK = { rainbow: { chute: ['#8fb4ff', '#9be27a', '#ffab5c', '#ffe36e', '#7ee0d6', '#c9b8f2'], edge: '#ffffff', rail: '#eef1f8', railD: '#b9c0d0', plat: '#c9b8f2', post: '#e8ebf3', sp: 1.0 },
    gold: { chute: ['#f6cf5c'], edge: '#d79a22', rail: '#f4f6fb', railD: '#b9c0d0', plat: '#e7b544', post: '#e8ebf3', sp: 1.06, ball: 1 },
    wood: { chute: ['#c98d54'], edge: '#8e5a2e', rail: '#b47740', railD: '#7f4f28', plat: '#f3ede3', post: '#a46c3a', sp: 0.94 } };
  YG.add({ id: 'slide', name: 'Slide & Splash', item: 'Slides', color: '#3fd0c0', icon: ICON, stars: [100, 170, 240], coinK: 0.15,
    hint: 'Tap to push off · tap again at the end of the slide to jump',
    how: ['Tap to push off; the swinging bar sets how hard.', 'Tap again as you reach the end of the slide to jump; Perfect right at the lip.', 'Land in a ring: near 10, middle 30, far 50. The glowing ring scores double!'],
    options: [{ id: 'rainbow', label: 'Rainbow' }, { id: 'gold', label: 'Gold' }, { id: 'wood', label: 'Wooden' }],
    make(ctx) {
      const { bg, fg, W, H } = ctx, KX = 74, KY = 118, K = 96, OX = 14, GY = 578, X0 = 0.52, X1 = 1.95, TOP = 2.2, DROP = 1.75, UP = 0.12, WL = 0.24, G = 9.8, MU = 0.6, CD = 0.2;
      const PX = (x, y) => [OX + x * KX, GY - y * KY], yC = x => { const t = cl((x - X0) / (X1 - X0), 0, 1); return TOP - DROP * (3 * t * t - 2 * t * t * t) + UP * Math.pow(Math.max(0, (t - 0.82) / 0.18), 2); }, dyC = x => (yC(x + 0.001) - yC(x - 0.001)) / 0.002;
      const POOL = [2.95, 4.52], RINGS = [{ x: 3.3, r: 0.2, p: 10, c: '#ffe36e' }, { x: 3.76, r: 0.17, p: 30, c: '#ff8fc8' }, { x: 4.2, r: 0.15, p: 50, c: '#7ee0d6' }];
      YG.yard(bg, { hz: GY - 90 });
      // sun
      { const s = S('g', { transform: 'translate(300 110)' }, bg); S('circle', { r: 40, fill: '#fff6c2', opacity: 0.6 }, s); S('circle', { r: 26, fill: '#ffe36e' }, s); }
      const slideG = S('g', {}, bg), poolB = S('g', {}, bg), shG = S('g', {}, bg), poolF = S('g', {}, fg), uiG = S('g', {}, fg);
      let look = 'rainbow';
      function drawSlide() { slideG.innerHTML = ''; const L = LOOK[look], ln = (a, b, w, c) => S('path', { d: 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'L' + r2(b[0]) + ' ' + r2(b[1]), stroke: c, 'stroke-width': w, 'stroke-linecap': 'round' }, slideG);
        YG.shadow(slideG, PX(1.0, 0)[0], GY + 2, 1.1 * KX, 0.16);
        // ladder + platform + guard rails
        [0.1, 0.38].forEach(x => ln(PX(x, 0), PX(x, TOP + 0.34), 5, L.rail)); for (let y = 0.24; y < TOP; y += 0.26) ln(PX(0.1, y), PX(0.38, y), 3.4, L.railD);
        const pa = PX(0.04, TOP + 0.02), pb = PX(X0 + 0.04, TOP - 0.05); S('rect', { x: r2(pa[0]), y: r2(pa[1]), width: r2(pb[0] - pa[0]), height: 9, rx: 3, fill: L.plat, stroke: L.railD, 'stroke-width': 1 }, slideG);
        ln(PX(0.1, TOP + 0.34), PX(X0 - 0.02, TOP + 0.28), 4, L.rail); ln(PX(X0 - 0.02, TOP + 0.28), PX(X0 - 0.02, TOP), 4, L.rail);
        if (L.ball) S('circle', { cx: r2(PX(0.1, TOP + 0.38)[0]), cy: r2(PX(0.1, TOP + 0.38)[1]), r: 6, fill: '#f6cf5c', stroke: '#d79a22', 'stroke-width': 1.2 }, slideG);
        // posts under the chute
        [[X0 + 0.5, 0.06], [X1 - 0.07, 0.04]].forEach(([x]) => ln(PX(x, 0), PX(x, yC(x) - 0.06), 5, L.post));
        // the chute: a side wall band along the curve, coloured in segments
        const N = 36, top = [], bot = []; for (let i = 0; i <= N; i++) { const x = X0 + (X1 - X0) * i / N, y = yC(x); top.push(PX(x, y + 0.1)); bot.push(PX(x, y - 0.05)); }
        const segs = L.chute.length; for (let s = 0; s < segs; s++) { const a = Math.round(N * s / segs), b = Math.round(N * (s + 1) / segs), pts = top.slice(a, b + 1).concat(bot.slice(a, b + 1).reverse());
          S('path', { d: 'M' + pts.map(q => r2(q[0]) + ' ' + r2(q[1])).join('L') + 'Z', fill: L.chute[s], stroke: L.chute[s], 'stroke-width': 0.6 }, slideG); }
        S('path', { d: 'M' + top.map(q => r2(q[0]) + ' ' + r2(q[1])).join('L'), fill: 'none', stroke: L.edge, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, slideG);
        S('path', { d: 'M' + bot.map(q => r2(q[0]) + ' ' + r2(q[1])).join('L'), fill: 'none', stroke: '#000', 'stroke-opacity': 0.18, 'stroke-width': 2 }, slideG);
        S('path', { d: 'M' + top.map((q, i) => r2(q[0]) + ' ' + r2(q[1] + 3)).join('L'), fill: 'none', stroke: '#ffffff', 'stroke-width': 1.4, opacity: 0.55 }, slideG); }
      // the kiddie pool: back wall + water behind the creature, front wall + ring fronts in front of it
      const [pl, pr] = POOL, PH = 0.3; let waveT = 0;
      function drawPool(t) { poolB.innerHTML = ''; poolF.innerHTML = ''; const a = PX(pl, 0), b = PX(pr, PH); YG.shadow(poolB, (a[0] + b[0]) / 2, GY + 2, (b[0] - a[0]) * 0.55, 0.16);
        S('rect', { x: r2(a[0]), y: r2(b[1] - 6), width: r2(b[0] - a[0]), height: 12, rx: 6, fill: '#3e9fe0' }, poolB);
        let d = 'M' + r2(a[0] + 4) + ' ' + r2(PX(0, WL)[1]); for (let x = a[0] + 4; x <= b[0] - 4; x += 6) d += 'L' + r2(x) + ' ' + r2(PX(0, WL)[1] + Math.sin(x / 14 + t / 300) * 1.6 + splashWave(x, t));
        d += 'L' + r2(b[0] - 4) + ' ' + r2(a[1]) + 'L' + r2(a[0] + 4) + ' ' + r2(a[1]) + 'Z'; S('path', { d, fill: '#7fd0ff' }, poolB);
        RINGS.forEach((R, i) => { const c = PX(R.x, WL), rx = R.r * KX, ry = 4.5, bob = Math.sin(t / 420 + i) * 1.2, glow = i === bonus; if (glow) S('ellipse', { cx: r2(c[0]), cy: r2(c[1] + bob), rx: r2(rx + 8), ry: 9, fill: '#fff6a8', opacity: 0.5 + 0.3 * Math.sin(t / 150) }, poolB);
          S('path', { d: 'M' + r2(c[0] - rx) + ' ' + r2(c[1] + bob) + 'A' + r2(rx) + ' ' + ry + ' 0 0 1 ' + r2(c[0] + rx) + ' ' + r2(c[1] + bob), fill: 'none', stroke: R.c, 'stroke-width': 6 }, poolB);
          S('path', { d: 'M' + r2(c[0] - rx) + ' ' + r2(c[1] + bob) + 'A' + r2(rx) + ' ' + ry + ' 0 0 0 ' + r2(c[0] + rx) + ' ' + r2(c[1] + bob), fill: 'none', stroke: R.c, 'stroke-width': 7 }, poolF);
          S('path', { d: 'M' + r2(c[0] - rx * 0.5) + ' ' + r2(c[1] + bob + 3.5) + 'A' + r2(rx * 0.5) + ' 2 0 0 0 ' + r2(c[0] + rx * 0.5) + ' ' + r2(c[1] + bob + 3.5), fill: 'none', stroke: '#ffffff', 'stroke-width': 2, opacity: 0.7 }, poolF);
          const tg = S('g', { transform: 'translate(' + r2(c[0]) + ' ' + r2(c[1] - 26 + bob) + ')' }, poolF); S('rect', { x: -15, y: -10, width: 30, height: 18, rx: 9, fill: glow ? '#ffcf3a' : '#ffffff', stroke: R.c, 'stroke-width': 2 }, tg);
          S('text', { y: 4, 'text-anchor': 'middle', 'font-family': 'Fredoka, sans-serif', 'font-weight': 700, 'font-size': 12, fill: '#4a1a73' }, tg).textContent = glow ? R.p * 2 : R.p; });
        // front wall (inflatable rings, stripes)
        const fw = PX(pl, 0), fh = PX(pr, 0.17); S('rect', { x: r2(fw[0]), y: r2(fh[1]), width: r2(fh[0] - fw[0]), height: r2(fw[1] - fh[1]), rx: 10, fill: '#5cb8f0' }, poolF);
        S('rect', { x: r2(fw[0]), y: r2(fh[1] - 2), width: r2(fh[0] - fw[0]), height: 9, rx: 4.5, fill: '#8fd6ff' }, poolF);
        for (let x = fw[0] + 12; x < fh[0] - 6; x += 22) S('rect', { x: r2(x), y: r2(fh[1] + 9), width: 8, height: r2(fw[1] - fh[1] - 13), rx: 4, fill: '#ffffff', opacity: 0.5 }, poolF); }
      let splashes = []; const splashWave = (x, t) => { let s = 0; for (const q of splashes) { const age = (t - q.t) / 1000; if (age > 2) continue; const d = Math.abs(x - q.x); s += Math.sin(d / 9 - age * 12) * 5 * Math.exp(-age * 2.2) * Math.exp(-d / 70); } return s; };
      // power bar (next to the platform)
      const pwr = S('g', { opacity: 0 }, uiG), pw0 = PX(0.86, TOP + 1.05); S('rect', { x: r2(pw0[0] - 9), y: r2(pw0[1]), width: 18, height: 90, rx: 9, fill: '#ffffff', stroke: '#4a1a73', 'stroke-width': 2 }, pwr);
      const pwF = S('rect', { x: r2(pw0[0] - 6), width: 12, rx: 6, fill: '#ff5cae' }, pwr); S('text', { x: r2(pw0[0]), y: r2(pw0[1] - 6), 'text-anchor': 'middle', 'font-family': 'Fredoka, sans-serif', 'font-weight': 700, 'font-size': 12, fill: '#4a1a73' }, pwr).textContent = 'PUSH';
      const lipMk = S('g', { opacity: 0 }, uiG), lp = PX(X1, yC(X1)); S('circle', { cx: r2(lp[0]), cy: r2(lp[1] - 22), r: 16, fill: 'none', stroke: '#ffe36e', 'stroke-width': 3.5 }, lipMk); S('text', { x: r2(lp[0]), y: r2(lp[1] - 18), 'text-anchor': 'middle', 'font-family': 'Fredoka, sans-serif', 'font-weight': 700, 'font-size': 11, fill: '#ffffff', stroke: '#4a1a73', 'stroke-width': 3, 'paint-order': 'stroke' }, lipMk).textContent = 'JUMP';
      const me = ctx.creature(ctx.playerKey, { yaw: 90 }), meSh = YG.shadow(shG, 0, 0, 20, 0.18); me.depth(2);
      let phase = 'push', ph0 = 0, tNow = 0, slide = 0, power = 0, x = 0, y = 0, v = 0, vx = 0, vy = 0, jumped = '', bonus = 1, rot = 0, results = [], firstSpin = 0;
      function reset() { phase = 'push'; ph0 = tNow; x = 0.24; y = TOP; jumped = ''; rot = 0; bonus = Math.floor(Math.random() * 3); me.yaw(90).rot(0).hide(false); me.play('idle'); ctx.timer('Slide ' + (slide + 1) + '/5'); }
      function tap() { if (!ctx.playing) return;
        if (phase === 'push') { power = pwVal(); phase = 'walk'; ph0 = tNow; SFX.tap(); }
        else if (phase === 'slide' && !jumped) { const d = X1 - x; if (d < 0.08) jump('Perfect!', 1.0); else if (d < 0.24) jump('Good', 0.6); else { jumped = 'early'; ctx.toast('Too early', W / 2, 260, '#ffffff'); } }
        else if (phase === 'air' && !jumped && tNow - ph0 < 120) { vy += 0.35; jumped = 'Late'; ctx.toast('Late jump', W / 2, 260, '#ffffff'); } }
      function jump(txt, j) { jumped = txt; api._j = j; ctx.toast(txt, PX(X1, 0)[0] + 20, PX(0, yC(X1) + 0.9)[1], txt === 'Perfect!' ? '#ffe36e' : '#8fe0ff'); SFX.boing(); }
      const pwVal = () => { const u = ((tNow - ph0) / 900) % 2; return u < 1 ? u : 2 - u; };
      function land() { phase = 'splash'; ph0 = tNow; const inPool = x > POOL[0] + 0.05 && x < POOL[1] - 0.05; let pts = 0, txt = '';
        if (inPool) { let best = null; RINGS.forEach((R, i) => { const d = Math.abs(x - R.x); if (d < R.r + 0.04 && (!best || d < best.d)) best = { R, i, d }; });
          if (best) { pts = best.R.p * (best.i === bonus ? 2 : 1); txt = (best.i === bonus ? 'Bonus ring! +' : 'Ring! +') + pts; } else { pts = 5; txt = 'Splash! +5'; }
          if (jumped === 'Perfect!') pts += 10; const s = PX(x, WL); splashes.push({ x: s[0], t: tNow }); ctx.burst(s[0], s[1], 'drop', 26, { v: 190, spread: 1.6, life: 0.9 }); SFX.splash(); if (pts >= 30) setTimeout(SFX.score, 200); }
        else { txt = x <= POOL[0] + 0.05 ? 'Too short!' : 'Too far!'; SFX.thud(); }
        ctx.add(pts, PX(x, 0)[0], PX(0, 1.2)[1], txt, pts >= 30 ? '#ffe36e' : '#ffffff'); results.push(pts); if (!inPool) { phase = 'bonk'; me.play('surprised'); } else if (pts >= 30) me.play('happy'); }
      const api = {
        option(id) { look = id; drawSlide(); },
        start() { slide = 0; results = []; look = ctx.G._opt || 'rainbow'; drawSlide(); reset(); },
        down() { tap(); }, key(k, dn) { if (dn && (k === ' ' || k === 'Enter' || k === 'ArrowUp')) { tap(); return true; } },
        _tap: tap, _state: () => ({ phase, x: +x.toFixed(2), y: +y.toFixed(2), slide, pw: +pwVal().toFixed(2), d: +(X1 - x).toFixed(2) }), _setPow: p => { power = p; phase = 'walk'; ph0 = tNow; },
        celebrate(st) { me.hide(false).rot(0).yaw(0); const s = PX(1.3, 0); me.set(s[0], s[1], K); me.play(st >= 2 ? 'happy' : 'idle'); },
        update(dt, t) { tNow = t; const L = LOOK[look]; let E = {};
          if (phase === 'push') { const p = pwVal(); pwF.setAttribute('y', r2(pw0[1] + 90 - 3 - p * 84)); pwF.setAttribute('height', r2(p * 84)); pwF.setAttribute('fill', p > 0.8 ? '#ff5c5c' : p > 0.45 ? '#ffb020' : '#5cc87a'); pwr.setAttribute('opacity', 1);
            x = 0.24; y = TOP; E = { armL: 40 + 30 * Math.sin(t / 200), armR: 40 + 30 * Math.sin(t / 200 + 1), sq: 0.04 * Math.sin(t / 150) }; }
          else pwr.setAttribute('opacity', 0);
          if (phase === 'walk') { const u = cl((t - ph0) / 350, 0, 1); x = lerp(0.24, X0, u); y = TOP + Math.sin(u * Math.PI) * 0.06; me.walk(dt, 1, 90); if (u >= 1) { phase = 'slide'; v = (0.6 + power * 3.6) * L.sp; ph0 = t; SFX.whoosh(); } }
          if (phase === 'slide') { const n = 4; for (let i = 0; i < n; i++) { const h = dt / n, th = Math.atan(dyC(x)), acc = -G * Math.sin(th) - MU * G * Math.cos(th) - CD * v * v; v = Math.max(0.2, v + acc * h); x += v * Math.cos(th) * h; }
            y = yC(x); rot = Math.atan(dyC(x) * KY / KX) * -180 / Math.PI; E = { armL: 150, armR: 150, open: 0.5, smile: 1, hap: 0.6, sq: -0.04 };
            lipMk.setAttribute('opacity', cl((x - (X1 - 0.5)) / 0.25, 0, 1) * (jumped ? 0.3 : 1));
            if (x >= X1) { const th = Math.atan(dyC(X1 - 0.001)); vx = v * Math.cos(th); vy = v * Math.sin(th) + (api._j && jumped !== 'early' ? api._j : 0); x = X1; phase = 'air'; ph0 = t; api._j = 0; } }
          else lipMk.setAttribute('opacity', 0);
          if (phase === 'air') { vy -= G * dt; x += vx * dt; y += vy * dt; rot = lerp(rot, cl(-Math.atan2(vy * KY, vx * KX) * 180 / Math.PI * 0.6, -45, 45), 1 - Math.exp(-dt * 8)); E = { armL: 160, armR: 160, open: 0.6, smile: 1, hap: 0.4, footL: 2, footR: 2 };
            if (y <= WL && vy < 0 && x > POOL[0] - 0.1) { y = WL; land(); } else if (y <= 0) { y = 0; land(); } }
          if (phase === 'splash') { const u = (t - ph0) / 1000; rot = lerp(rot, 0, 1 - Math.exp(-dt * 6)); y = WL - 0.3 + Math.sin(u * 5) * 0.03 * Math.exp(-u); E = { armL: 120 + 30 * Math.sin(u * 8), armR: 120 - 30 * Math.sin(u * 8), smile: 1, hap: 1, close: 0.6 };
            if (u > 1.6) { slide++; if (slide >= 5) { phase = 'done'; const tot = results.reduce((a, b) => a + b, 0); ctx.finish({ sub: results.filter(p => p >= 10).length + '/5 rings' }); } else reset(); } }
          if (phase === 'bonk') { const u = (t - ph0) / 1000; rot = lerp(rot, 0, 1 - Math.exp(-dt * 6)); E = { tilt: Math.sin(u * 14) * 6 * Math.exp(-u * 2), sq: 0.08 }; if (u > 1.6) { slide++; if (slide >= 5) { phase = 'done'; ctx.finish({ sub: results.filter(p => p >= 10).length + '/5 rings' }); } else reset(); } }
          me.pose(E); me.rot(rot, 50, 90); const s = PX(x, y); me.set(s[0], s[1] + 3, K);
          const gy = phase === 'slide' || phase === 'walk' || phase === 'push' ? Math.max(0, y) : x > POOL[0] && x < POOL[1] ? WL : 0, gs = PX(x, gy); meSh.setAttribute('cx', r2(gs[0])); meSh.setAttribute('cy', r2(gs[1] + 2)); meSh.setAttribute('rx', r2(0.28 * K * cl(1 - (y - gy) / 2, 0.3, 1))); meSh.setAttribute('ry', r2(0.06 * K)); meSh.setAttribute('opacity', phase === 'splash' ? 0 : 0.18);
          drawPool(t); splashes = splashes.filter(q => t - q.t < 2000);
        } };
      drawSlide(); drawPool(0); reset(); { const s = PX(0.24, TOP); me.set(s[0], s[1] + 3, K); } return api;
    } });
  }; go();
})();
