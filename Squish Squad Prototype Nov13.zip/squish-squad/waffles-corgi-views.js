// Waffles the corgi: round, fluffy, shaded views (front, side, back) on a 100x100 grid.
// Palette: orange #e8953e (shade #b86424 / #d9822f), cream #fff8ee, ink #2a1a30, blush #ff8fa3.
// blob(): ellipse with a scalloped fur edge (n bumps, a = bump depth).
function blob(cx, cy, rx, ry, n, a) {
  let d = '';
  for (let i = 0; i <= 72; i++) {
    const t = i / 72 * Math.PI * 2;
    const k = 1 + (a || 0.06) * Math.pow(Math.abs(Math.sin((n || 10) * t / 2)), 0.5);
    d += (i ? 'L' : 'M') + (cx + Math.cos(t) * rx * k).toFixed(2) + ' ' + (cy + Math.sin(t) * ry * k).toFixed(2);
  }
  return d + 'Z';
}
// Shading: top-left lit radial gradients per colour, thin darker rim on every shape.
const SHADE = {
  '#e8953e': 'url(#wO)', '#d9822f': 'url(#wD)', '#b86424': 'url(#wS)', '#fff8ee': 'url(#wC)'
};
const P = (d, fill, extra) => `<path d="${d}" fill="${SHADE[fill] || fill}" stroke="#7a3e12" stroke-opacity=".4" stroke-width=".6"${extra || ''}/>`;
const HL = (cx, cy, rx, ry) => `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="#fff" opacity=".28"/>`;
const SH = `<ellipse cx="50" cy="95" rx="26" ry="3" fill="#2a1a30" opacity=".14"/>`;
const DEFS = `<defs>
<radialGradient id="wO" cx="35%" cy="28%" r="78%"><stop offset="0" stop-color="#fbc283"/><stop offset=".5" stop-color="#e8953e"/><stop offset="1" stop-color="#a85a1c"/></radialGradient>
<radialGradient id="wD" cx="35%" cy="28%" r="78%"><stop offset="0" stop-color="#e8953e"/><stop offset=".6" stop-color="#c2701f"/><stop offset="1" stop-color="#7a3e12"/></radialGradient>
<radialGradient id="wS" cx="35%" cy="28%" r="78%"><stop offset="0" stop-color="#d07a32"/><stop offset=".6" stop-color="#9a5020"/><stop offset="1" stop-color="#5e2e0c"/></radialGradient>
<radialGradient id="wC" cx="35%" cy="28%" r="78%"><stop offset="0" stop-color="#ffffff"/><stop offset=".6" stop-color="#fff3df"/><stop offset="1" stop-color="#dcc7a4"/></radialGradient>
</defs>`;

window.CORGI = {
front: `<g>${DEFS}
${SH}
${P(blob(40, 88, 6, 6, 6, .1), '#d9822f')}${P(blob(60, 88, 6, 6, 6, .1), '#d9822f')}
${P(blob(40, 93, 6, 3.2, 6, .1), '#fff8ee')}${P(blob(60, 93, 6, 3.2, 6, .1), '#fff8ee')}
${P(blob(50, 70, 23, 18, 4, .01), '#e8953e')}${HL(43, 62, 9, 5)}
${P(blob(50, 75, 11, 10, 4, .01), '#fff8ee')}
${P('M30 34 Q22 16 26 2 Q38 12 42 24Z', '#e8953e')}
${P('M70 34 Q78 16 74 2 Q62 12 58 24Z', '#e8953e')}
${P('M32 30 Q27 17 28 9 Q36 16 39 25Z', '#b86424')}
${P('M68 30 Q73 17 72 9 Q64 16 61 25Z', '#b86424')}
${P(blob(50, 42, 22, 20, 4, .01), '#e8953e')}${HL(40, 30, 9, 6)}
${P('M50 36 C60 36 64 46 62 54 C60 62 55 64 50 64 C45 64 40 62 38 54 C36 46 40 36 50 36Z', '#fff8ee')}
${P('M50 22 Q53.5 28 52 38 Q50 42 48 38 Q46.5 28 50 22Z', '#fff8ee')}
<g class="eo">
<ellipse cx="40" cy="41" rx="3.4" ry="3.8" fill="#2a1a30"/><circle cx="39" cy="39.6" r="1.1" fill="#fff"/>
<ellipse cx="60" cy="41" rx="3.4" ry="3.8" fill="#2a1a30"/><circle cx="59" cy="39.6" r="1.1" fill="#fff"/>
</g>
<g class="ec" fill="none" stroke="#2a1a30" stroke-width="1.6" stroke-linecap="round">
<path d="M36 41 Q40 37 44 41"/><path d="M56 41 Q60 37 64 41"/>
</g>
<ellipse cx="33" cy="51" rx="3.6" ry="2.4" fill="#ff8fa3" opacity=".5"/>
<ellipse cx="67" cy="51" rx="3.6" ry="2.4" fill="#ff8fa3" opacity=".5"/>
<ellipse cx="50" cy="49" rx="3.4" ry="2.5" fill="#2a1a30"/><ellipse cx="49" cy="48" rx="1" ry=".7" fill="#fff" opacity=".7"/>
<path d="M50 51.5 V55 M46 57 Q50 60 50 55 Q50 60 54 57" stroke="#2a1a30" stroke-width="1.1" fill="none" stroke-linecap="round"/>
</g>`,

side: `<g>${DEFS}
${SH}
${P(blob(66, 82, 4.5, 11, 6, .1), '#b86424')}${P(blob(34, 82, 4.5, 11, 6, .1), '#b86424')}
${P(blob(66, 94, 5, 3, 6, .1), '#fff8ee')}${P(blob(34, 94, 5, 3, 6, .1), '#fff8ee')}
${P('M34 52 C22 52 10 48 7 38 C5 31 10 27 13 32 C15 40 24 46 36 60Z', '#e8953e')}
${P(blob(9, 33, 3.6, 3.6, 4, .01), '#fff8ee')}
${P(blob(48, 62, 31, 14, 4, .01), '#e8953e')}${HL(42, 52, 16, 4)}
${P(blob(52, 69, 20, 4, 4, .01), '#fff8ee')}
${P(blob(68, 82, 5.5, 11, 6, .1), '#e8953e')}${P(blob(30, 82, 5.5, 11, 6, .1), '#e8953e')}
${P(blob(68, 94, 6, 3.2, 6, .1), '#fff8ee')}${P(blob(30, 94, 6, 3.2, 6, .1), '#fff8ee')}
${P(blob(74, 60, 5, 8, 4, .01), '#fff8ee')}
${P(blob(78, 20, 8, 11, 6, .04), '#e8953e', ' transform="rotate(15 78 16)"')}
${P(blob(78, 22, 4, 7, 6, .05), '#b86424', ' transform="rotate(15 78 18)"')}
${P(blob(70, 50, 11, 12, 6, .02), '#e8953e')}
${P(blob(82, 42, 15, 13, 4, .01), '#e8953e')}${HL(77, 34, 6, 4)}
${P('M80 42 C86 40 96 40 98 40 C98 46 92 50 84 49 C80 48 79 45 80 42Z', '#fff8ee')}
<ellipse cx="88" cy="41" rx="3" ry="2" fill="#ff8fa3" opacity=".5"/>
<ellipse cx="84" cy="34" rx="2.4" ry="2.8" fill="#2a1a30"/><circle cx="83.3" cy="33" r=".8" fill="#fff"/>
<ellipse cx="96" cy="38" rx="2.2" ry="1.7" fill="#2a1a30"/>
<path d="M95 44 Q90 46 86 44" stroke="#2a1a30" stroke-width="1.1" fill="none" stroke-linecap="round"/>
</g>`,

back: `<g>${DEFS}
${SH}
${P(blob(36, 88, 6, 6, 6, .1), '#d9822f')}${P(blob(64, 88, 6, 6, 6, .1), '#d9822f')}
${P(blob(36, 93, 6, 3.2, 6, .1), '#fff8ee')}${P(blob(64, 93, 6, 3.2, 6, .1), '#fff8ee')}
${P(blob(50, 64, 26, 22, 4, .01), '#e8953e')}${HL(40, 50, 10, 5)}
${P(blob(34, 72, 8, 8, 8, .1), '#d9822f')}
${P(blob(66, 72, 8, 8, 8, .1), '#d9822f')}
${P('M40 80 C38 92 50 98 64 94 C56 90 54 84 58 78Z', '#d9822f')}${HL(46, 85, 4, 2)}
${P(blob(63, 93, 4, 3, 4, .01), '#fff8ee')}
${P('M34 26 Q32 12 37 2 Q45 10 45 24Z', '#e8953e')}
${P('M66 26 Q68 12 63 2 Q55 10 55 24Z', '#e8953e')}
${P(blob(50, 42, 13, 6, 8, .08), '#d9822f')}
${P(blob(50, 30, 16, 15, 4, .01), '#e8953e')}${HL(44, 22, 6, 3)}
${P(blob(50, 42, 8, 4, 8, .1), '#fff8ee')}
</g>`
};
