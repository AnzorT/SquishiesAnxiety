// Renovation Catalog round 25 — luxury living-room texture pass (user list, 3 per batch). Batch 1: LIV-086 cashmere smart-gel levitating sofa,
// LIV-110 royal velvet & gold-leaf grand chesterfield, LIV-090 kinetic zero-G carbon-fibre throne.
// Same verified geometry (rsofa / chester); every new detail is a dec() decal solid glued (par) to the part it lies on, so the depth sort is unchanged (nf stays 0).
// Surface kit: fr2(face) = 2D frame on any planar face, hatch() = clipped line families (knit ribs, twill, quilting, leaf seams), outline() = cap edge loops,
// ringL() = a loop along one ring of a solid (welts / piping), dots() = spot grid inside a face.
// Sets RenoDraw.PLUS25; catalog edits RD.SET25; toolkit RD.H25.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS24 && RD.H24 && RD.H22 && RD.H16 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS25) return;
  const K = X.K, { solid, ball, box, cyl, cush, arcW, pillowZ, shade, mix, f1 } = K, N = RD.N, PI = Math.PI, GOLD = '#e2b14a';
  const { dec, spot, at } = RD.H24, { glue, R0 } = RD.H22, { rep } = RD.H16;
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], mul = (a, k) => [a[0] * k, a[1] * k, a[2] * k], dt = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cr = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], nz = a => { const L = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / L, a[1] / L, a[2] / L]; };
  const X3 = [1, 0, 0], Y3 = [0, 1, 0];
  const bbS = S => { const L = [1e9, -1e9, 1e9, -1e9, 1e9, -1e9]; S.pts.forEach(p => { for (let k = 0; k < 3; k++) { if (p[k] < L[2 * k]) L[2 * k] = p[k]; if (p[k] > L[2 * k + 1]) L[2 * k + 1] = p[k]; } }); return L; };
  // ---------- face frames + clipping ----------
  const fr2 = F => { const n = F.n, u = Math.abs(n[1]) > 0.9 ? X3 : nz(cr(Y3, n)), v = nz(cr(n, u)), o = F.q.reduce((a, p) => add(a, mul(p, 1 / F.q.length)), [0, 0, 0]);
    return { n, u, v, o, P: F.q.map(p => { const d = sub(p, o); return [dt(d, u), dt(d, v)]; }), at: (a, b) => add(o, add(mul(u, a), mul(v, b))) }; };
  const area = P => { let s = 0; for (let i = 0; i < P.length; i++) { const a = P[i], b = P[(i + 1) % P.length]; s += a[0] * b[1] - b[0] * a[1]; } return s / 2; };
  const shrinkP = (P, k) => P.map(p => [p[0] * k, p[1] * k]);
  const clip = (P, A, B) => { let t0 = 0, t1 = 1; const d = [B[0] - A[0], B[1] - A[1]], sg = area(P) > 0 ? 1 : -1;
    for (let i = 0; i < P.length; i++) { const p = P[i], q = P[(i + 1) % P.length], e = [q[0] - p[0], q[1] - p[1]], nn = sg > 0 ? [-e[1], e[0]] : [e[1], -e[0]], num = nn[0] * (A[0] - p[0]) + nn[1] * (A[1] - p[1]), den = nn[0] * d[0] + nn[1] * d[1];
      if (Math.abs(den) < 1e-9) { if (num < 0) return null; continue; } const t = -num / den; if (den > 0) t0 = Math.max(t0, t); else t1 = Math.min(t1, t); if (t0 >= t1) return null; }
    return [[A[0] + d[0] * t0, A[1] + d[1] * t0], [A[0] + d[0] * t1, A[1] + d[1] * t1]]; };
  const inP = (P, x) => { const sg = area(P) > 0 ? 1 : -1; for (let i = 0; i < P.length; i++) { const p = P[i], q = P[(i + 1) % P.length]; if (sg * ((q[0] - p[0]) * (x[1] - p[1]) - (q[1] - p[1]) * (x[0] - p[0])) < 0) return false; } return true; };
  const ext2 = P => P.reduce((m, p) => Math.max(m, Math.hypot(p[0], p[1])), 0);
  // hatch: parallel lines at angle ang (radians from the face's u axis), spacing sp, anchored to world space so neighbouring faces line up; Ds = one decal or [a, b] alternating
  const hatch = (Ds, F, ang, sp, w, o) => { o = o || {}; const G = fr2(F), P = shrinkP(G.P, o.sh || 0.96), R = ext2(P) + sp, dir = [Math.cos(ang), Math.sin(ang)], m = [-dir[1], dir[0]], m3 = add(mul(G.u, m[0]), mul(G.v, m[1]));
    const off = ((dt(G.o, m3) + (o.ph || 0)) % sp + sp) % sp, L = Array.isArray(Ds) ? Ds : [Ds]; let k = Math.floor((dt(G.o, m3) + (o.ph || 0)) / sp), c = 0;
    for (let s = -R - off; s <= R; s += sp, k++) { const A = [m[0] * s - dir[0] * R, m[1] * s - dir[1] * R], B = [m[0] * s + dir[0] * R, m[1] * s + dir[1] * R], C = clip(P, A, B); if (!C) continue;
      if (Math.hypot(C[1][0] - C[0][0], C[1][1] - C[0][1]) < (o.min || 0.6)) continue; L[((k % L.length) + L.length) % L.length].line([G.at(...C[0]), G.at(...C[1])], G.n, w); c++; } return c; };
  // wavy: polyline f(t) in face 2D (t 0..1), kept only where inside the face
  const wavy = (D, F, f, m, w, taper) => { const G = fr2(F), P = shrinkP(G.P, 0.94); let run = [];
    const flush = () => { if (run.length > 1) D.line(run, G.n, w, taper); run = []; };
    for (let i = 0; i <= m; i++) { const q = f(i / m, G); if (q && inP(P, q)) run.push(G.at(q[0], q[1])); else flush(); } flush(); };
  const outline = (D, F, k, w) => { const G = fr2(F), P = shrinkP(G.P, k); D.line(P.concat([P[0]]).map(p => G.at(p[0], p[1])), G.n, w); };
  const dots = (D, F, sp, r, o) => { o = o || {}; const G = fr2(F), P = shrinkP(G.P, o.sh || 0.9), R = ext2(P); let c = 0;
    for (let a = -R; a <= R; a += sp) for (let b = -R; b <= R; b += sp * (o.ry || 1)) { const q = [a + ((Math.round((b + R) / (sp * (o.ry || 1))) % 2) && o.stag ? sp / 2 : 0) + (o.off ? o.off[0] : 0), b + (o.off ? o.off[1] : 0)]; if (!inP(P, q)) continue; spot(D, G.at(q[0], q[1]), G.n, r, r, 0, o.m || 6); c++; } return c; };
  // ring loop k of a solid with nr rings (welt / piping), normals pushed out from the ring centre (+ up)
  const ringL = (D, S, k, nr, w, up) => { const n = S.pts.length / nr, R = S.pts.slice(k * n, (k + 1) * n); if (R.length < 3) return; const c = R.reduce((a, p) => add(a, mul(p, 1 / R.length)), [0, 0, 0]);
    const Nn = R.map(p => nz(add(sub(p, c), mul(Y3, up == null ? 0.4 : up)))), P = R.map((p, i) => add(p, mul(Nn[i], 0.12))); D.line(P.concat([P[0]]), Nn.concat([Nn[0]]), w); };
  const caps = (S, c) => S.faces.filter(F => F.cap === c);
  const sides = (S, minV) => S.faces.filter(F => !F.cap && F.q.length === 4 && Math.hypot(...sub(F.q[3], F.q[0])) >= (minV || 0));
  const isFab = (S, P) => S.col === P.a || S.col === P.aL || S.col === P.aD;

  // ---------- floor pad + magnetic lift fx (drawn in 'under', so the pad stays on the floor while the piece bobs) ----------
  const padFx = (c, a, b, lift, id, col) => { const p = c.p, m = 40, E = (s, y) => rep(m, i => { const t = i / m * 2 * PI; return p(Math.cos(t) * a * s, y, Math.sin(t) * b * s); }), path = Q => 'M' + Q.map(q => f1(q[0]) + ' ' + f1(q[1])).join('L') + 'Z';
    const O = E(1.18, 0), PD = E(1, 0), IN = E(0.8, 0.4), q0 = p(0, 0, 0), q1 = p(0, lift, 0), dy = f1(q1[1] - q0[1]);
    let s = '<path d="' + path(O) + '" fill="url(#' + id + 'gl)" opacity="0.6"><animate attributeName="opacity" values="0.35;0.75;0.35" dur="3.2s" repeatCount="indefinite"/></path>'
      + '<path d="' + path(PD) + '" fill="url(#' + id + 'pd)" stroke="#0d0f14" stroke-width="0.8"/><path d="' + path(IN) + '" fill="none" stroke="' + col + '" stroke-width="' + f1(c.k * 0.9) + '" opacity="0.9"/>'
      + '<path d="' + path(E(0.62, 0.4)) + '" fill="none" stroke="' + col + '" stroke-width="' + f1(c.k * 0.35) + '" stroke-dasharray="' + f1(c.k * 2) + ' ' + f1(c.k * 3) + '" opacity="0.7"><animate attributeName="stroke-dashoffset" values="0;' + f1(-c.k * 25) + '" dur="2.4s" repeatCount="indefinite"/></path>';
    [0, 1].forEach(i => { s += '<path d="' + path(E(0.7 - i * 0.12, 0.6)) + '" fill="none" stroke="' + col + '" stroke-width="' + f1(c.k * 0.5) + '" opacity="0"><animate attributeName="opacity" values="0;0.7;0" dur="2.6s" begin="' + (-i * 1.3) + 's" repeatCount="indefinite"/><animateTransform attributeName="transform" type="translate" values="0 0;0 ' + dy + '" dur="2.6s" begin="' + (-i * 1.3) + 's" repeatCount="indefinite"/></path>'; });
    const xs = O.map(q => q[0]), ys = O.map(q => q[1]);
    return { svg: s, bb: [Math.min(...xs) - 2, Math.min(...ys) - 2, Math.max(...xs) + 2, Math.max(...ys) + 2],
      defs: '<radialGradient id="' + id + 'gl"><stop offset="0.55" stop-color="' + col + '" stop-opacity="0.55"/><stop offset="1" stop-color="' + col + '" stop-opacity="0"/></radialGradient>'
        + '<radialGradient id="' + id + 'pd" cx="42%" cy="38%" r="70%"><stop offset="0" stop-color="#3a3f4a"/><stop offset="0.6" stop-color="#1b1e25"/><stop offset="1" stop-color="#0b0c10"/></radialGradient>' }; };
  const splitL = B => { const L0 = B.layers && B.layers.length === 1 ? B.layers[0] : null; return L0 ? [0, 1].map(k => Object.assign({}, L0, { build: P => { const all = L0.build(P), isS = Q => Q.col === P.a && bbS(Q)[1] - bbS(Q)[0] > 34, inS = Q => isS(Q) || (Q.par && isS(Q.par)); return all.filter(Q => k ? !inS(Q) : inS(Q)); } })) : (B.layers || []); };
  const mergeBB = (A, B) => !A ? B : [Math.min(A[0], B[0]), Math.min(A[1], B[1]), Math.max(A[2], B[2]), Math.max(A[3], B[3])];

  // ======================= LIV-086 SELF-WARMING CASHMERE & SMART-GEL LEVITATING SOFA =======================
  // cashmere rib-knit on every upholstered side, cable-knit braids down each back cushion, smart-gel lattice + warm heat nodes on the seats, knit welts,
  // a caramel cashmere throw draped over the left arm with fringe, touch dial on the right arm, camel + ivory pillows, black-glass magnetic floor pad + rising rings, heat shimmer
  const knit = (o, P, on, S, R) => { const lt = dec(shade(S.col, 1.1), { op: 0.42 }), dk = dec(shade(S.col, 0.84), { op: 0.42 }); sides(S, 2.5).forEach(F => { if (Math.abs(F.n[1]) < 0.6) hatch([lt, dk], F, PI / 2, 1.5, 0.42, { sh: 0.98 }); }); on(S, [lt, dk]); };
  const levTex = (o, P, sofa) => { const on = glue(o), R = R0('lev25'), B = o.map(S => ({ S, L: bbS(S) })), fab = B.filter(b => isFab(b.S, P) && !b.S.par);
    fab.forEach(b => knit(o, P, on, b.S, R));
    fab.forEach(({ S, L }) => { const h = L[3] - L[2], d = L[5] - L[4], w = L[1] - L[0];
      if (S.col === P.aL && L[5] > 15 && h < 22 && w > 40) { // seat cushion: gel lattice + heat nodes + welt
        const G1 = dec('#a9d8ec', { op: 0.75 }), G2 = dec('#ffffff', { op: 0.55 }), HT = dec('#ffb784', { emit: 1, op: 0.7 }), WL = dec(shade(S.col, 0.8), { op: 0.7 });
        caps(S, 2).forEach(F => { hatch(G1, F, 0.9, 4.6, 0.45); hatch(G1, F, PI - 0.9, 4.6, 0.45); hatch(G2, F, 0.9, 4.6, 0.2, { ph: 0.4 }); hatch(G2, F, PI - 0.9, 4.6, 0.2, { ph: 0.4 }); dots(HT, F, 6.2, 0.55, { stag: 1, sh: 0.86 }); });
        if (S.pts.length % 6 === 0) ringL(WL, S, 4, 6, 0.55, 0.6); on(S, [G1, G2, HT, WL]); }
      else if (S.col === P.aL && L[5] < 0 && h > 30) { // back cushion: two cable braids + centre rib
        const CB = dec(shade(S.col, 0.74), { op: 0.75 }), CL = dec(shade(S.col, 1.16), { op: 0.6 });
        caps(S, 2).forEach(F => { [-0.25, 0.25].forEach(cx => { const fx = (ph, D) => wavy(D, F, (t, G) => { const Pw = G.P, xs = Pw.map(q => q[0]), ys = Pw.map(q => q[1]), W = Math.max(...xs) - Math.min(...xs), H = Math.max(...ys) - Math.min(...ys); return [cx * W + Math.sin(t * PI * 7 + ph) * W * 0.06, -H / 2 + H * t]; }, 42, 1.2);
          fx(0, CB); fx(PI, CB); fx(0.35, CL); }); hatch(CL, F, PI / 2, 2.2, 0.3); }); on(S, [CB, CL]); } });
    // pillows: camel cashmere + ivory, knit ribs
    B.filter(b => !b.S.par && !isFab(b.S, P) && Math.abs(b.L[3] - b.L[2] - 24) < 3 && b.L[5] - b.L[4] < 11).forEach((b, i) => { b.S.col = i % 2 ? '#d9c3a0' : '#c79a6b'; b.S.mat = 'fab'; knit(o, P, on, b.S, R);
      const CB = dec(shade(b.S.col, 0.8), { op: 0.5 }); caps(b.S, 2).forEach(F => outline(CB, F, 0.86, 0.5)); on(b.S, [CB]); });
    if (!sofa) return;
    // draped throw over the left arm roll + arm side, fringe at the hem; touch dial on the right roll
    const rolls = B.filter(b => b.S.col === P.a && !b.S.par && b.L[1] - b.L[0] < 34 && b.L[5] - b.L[4] > 60 && b.L[2] > 30);
    rolls.forEach(({ S, L }) => { const left = (L[0] + L[1]) / 2 < 0, zc = (L[4] + L[5]) / 2;
      if (left) { const TC = '#b98d5e', TH = dec(TC), TL = dec(shade(TC, 1.12), { op: 0.5 }), TD = dec(shade(TC, 0.8), { op: 0.5 }), FR = dec(shade(TC, 0.9)); const z0 = zc - 2, z1 = zc + 20;
        S.faces.forEach(F => { if (F.cap) return; const zs = F.q.map(q => q[2]); if (Math.max(...zs) < z0 || Math.min(...zs) > z1) return; if (F.n[0] > 0.3) return;
          const q = F.q.map(p => [p[0], p[1], Math.max(z0, Math.min(z1, p[2]))]); if (Math.abs(q[0][2] - q[3][2]) + Math.abs(q[1][2] - q[2][2]) < 0.5) return; TH.poly(q, F.n); });
        on(S, [TH]);
        // hanging part on the outer side of the arm box below the roll
        const AB = B.find(b => b.S.col === P.a && !b.S.par && b !== rolls[0] && b.L[1] - b.L[0] < 34 && b.L[5] - b.L[4] > 60 && b.L[2] < 30 && (b.L[0] + b.L[1]) / 2 < 0);
        if (AB) { const x = AB.L[0], y1 = AB.L[3], y0 = y1 - 17, wv = z => y0 + Math.sin(z * 0.7) * 1.2, Q = [[x, y1, z0], [x, y1, z1], [x, wv(z1), z1 - 1.5], [x, wv(z0), z0 + 1.5]], TH2 = dec(TC);
          TH2.poly(Q, [-1, 0, 0]); on(AB.S, [TH2]); rep(9, i => { const z = z0 + 2 + i * (z1 - z0 - 4) / 8; (i % 2 ? TL : TD).line([[x, y1 - 1, z], [x, wv(z) + 1, z]], [-1, 0, 0], 0.5); });
          rep(14, i => { const z = z0 + 2 + i * (z1 - z0 - 4) / 13; FR.line([[x, wv(z) + 0.5, z], [x, wv(z) - 2.6, z + 0.2]], [-1, 0, 0], 0.32); }); on(AB.S, [TL, TD, FR]); } }
      else { const DL = dec('#1f2227'), DR = dec('#ffcf9a', { emit: 1 }), DW = dec('#ffffff', { emit: 1, op: 0.8 }), top = L[3], x = (L[0] + L[1]) / 2, z = zc + 14, Nn = Y3;
        DL.poly(rep(18, i => { const a = i / 18 * 2 * PI; return [x + Math.cos(a) * 4.2, top + 0.1, z + Math.sin(a) * 4.2]; }), Nn);
        DR.line(rep(15, i => { const a = PI * 0.75 + i / 14 * PI * 1.1; return [x + Math.cos(a) * 3.4, top + 0.15, z + Math.sin(a) * 3.4]; }), Nn, 0.55);
        spot(DW, [x, top + 0.2, z], Nn, 0.9, 0.9, 0, 8); rep(3, i => spot(DR, [x - 2 + i * 2, top + 0.15, z + 6.2], Nn, 0.35, 0.35, 0, 6)); on(S, [DL, DR, DW]); } });
  };
  N.lev25 = S => { const B = N.rsofa(Object.assign({}, S, { float: 1 })), D = Object.assign({}, B), by = 23;
    D.build = P => { const o = B.build(P); levTex(o, P, 1); return o; };
    D.layers = splitL(B).map(L => Object.assign({}, L, { build: P => { const o = L.build(P); levTex(o, P, 1); return o; } }));
    D.fx = c => { const A = padFx(c, D.w * 0.36, D.d * 0.3, by - 8, 'lv25', '#9fe6ff'), p = c.p; let fr = '';
      (D.seats || []).forEach((s, i) => rep(2, j => { const q = p(s.x - 8 + j * 16, s.h + 3, s.z - 6); fr += '<g transform="translate(' + f1(q[0]) + ' ' + f1(q[1]) + ') scale(' + f1(c.k * 0.9) + ')"><path d="M0 0q-2 -4 0 -8t0 -8" fill="none" stroke="#ffd2a6" stroke-width="0.8" stroke-linecap="round" opacity="0"><animate attributeName="opacity" values="0;0.55;0" dur="3s" begin="' + f1(-(i * 0.9 + j * 1.5)) + 's" repeatCount="indefinite"/><animateTransform attributeName="transform" type="translate" values="0 0;0 -7" dur="3s" begin="' + f1(-(i * 0.9 + j * 1.5)) + 's" repeatCount="indefinite"/></path></g>'; }));
      return { defs: A.defs, under: A.svg, front: fr, bb: A.bb }; };
    return D; };

  // ======================= LIV-110 ROYAL VELVET & GOLD-LEAF GRAND CHESTERFIELD =======================
  // crushed-velvet sheen + crush streaks on seats/arms/back, gold piping (seat welts, scroll fronts), gold nailheads round the arm fronts, gold-leaf squares + red bole wear on the apron,
  // bullion fringe under the apron, carved gilt shell crest + finial on the back roll, gold damask on the pillows, embroidered crown + cord welt + tassels on the emerald bolster
  const velvet = (D1, D2, F, R, n) => rep(n, i => { const ph = R() * 6, yy = R() * 0.8 - 0.4, amp = 0.05 + R() * 0.08; wavy(i % 2 ? D2 : D1, F, (t, G) => { const xs = G.P.map(q => q[0]), ys = G.P.map(q => q[1]), W = Math.max(...xs) - Math.min(...xs), H = Math.max(...ys) - Math.min(...ys);
    return [-W / 2 + W * t, yy * H + Math.sin(t * 5 + ph) * H * amp]; }, 24, 1.8 + R() * 2.2, 1); });
  const chesTex = (o, P, li) => { const on = glue(o), R = R0('ch25' + li), F0 = (P.c && P.c.a) || P.a, B = o.map(S => ({ S, L: bbS(S) })).filter(b => !b.S.par);
    const sheen = S => { const D1 = dec(mix(S.col, '#ffffff', 0.2), { op: 0.26 }), D2 = dec(shade(S.col, 0.9), { op: 0.22 }); return [D1, D2]; };
    B.forEach(({ S, L }) => { const w = L[1] - L[0], h = L[3] - L[2], d = L[5] - L[4];
      if (S.col === GOLD || S.emit) return;
      // seat cushions (6 rings): sheen on the top, gold welt
      if (li === 2 && S.pts.length % 6 === 0 && w > 50 && w < 60 && d > 60) { const [D1, D2] = sheen(S), WG = dec('#f0c24a', { op: 0.95 }), WD = dec('#9a6a14', { op: 0.6 });
        caps(S, 2).forEach(F => velvet(D1, D2, F, R, 5)); sides(S, 3).forEach(F => { if (Math.abs(F.n[2]) > 0.7 && F.n[2] > 0) velvet(D1, D2, F, R, 2); });
        ringL(WG, S, 4, 6, 0.75, 0.6); ringL(WD, S, 3, 6, 0.35, 0); on(S, [D1, D2, WD, WG]); return; }
      // throw pillows: gold damask
      if (li === 2 && Math.abs(w - 24) < 3 && Math.abs(h - 24) < 3) { const DM = dec(shade(S.col, 0.72), { op: 0.6 }), DL = dec(mix(S.col, '#ffffff', 0.4), { op: 0.5 }), TS = dec('#9a6a14', { op: 0.7 });
        caps(S, 2).forEach(F => { hatch(DM, F, PI / 4, 5.2, 0.3, { sh: 0.86 }); hatch(DM, F, -PI / 4, 5.2, 0.3, { sh: 0.86 }); dots(DL, F, 3.7, 0.6, { sh: 0.8, stag: 1 }); outline(TS, F, 0.95, 0.5); }); on(S, [DM, DL, TS]); return; }
      // bolster: crown + cord welt + tassels
      if (li === 2 && w > 30 && w < 40 && h < 18) { const CG = dec('#f0c24a', { op: 0.95 }), CD = dec('#0f2c22', { op: 0.5 });
        caps(S, 2).forEach(F => { const G = fr2(F), Q = (a, b) => G.at(a, b); CG.line([Q(-5, -2), Q(-5, 2.6), Q(-2.5, 0.6), Q(0, 3.6), Q(2.5, 0.6), Q(5, 2.6), Q(5, -2), Q(-5, -2)], G.n, 0.6); CG.line([Q(-5.4, -3.2), Q(5.4, -3.2)], G.n, 0.7);
          [-5, 0, 5].forEach(a => spot(CG, Q(a, a ? 3.3 : 4.4), G.n, 0.55, 0.55, 0, 6)); hatch(CD, F, PI / 2, 1.8, 0.25, { sh: 0.9 }); });
        if (S.pts.length % 5 === 0) ringL(CG, S, 3, 5, 0.5, 0); on(S, [CD, CG]);
        const zf = L[5]; [-1, 1].forEach(sg => { const x = sg * (w / 2 - 1.5), y = L[2] + 1.5, T = [ball(x, y - 1.4, zf - 1.2, 1.2, '#f0c24a', { k: 3, n: 8, shine: 1, noOut: 1 }), solid({ ax: 'y', sh: 'el', c: [x, zf - 1.2], a: 0.4, b: 1.5, n: 8, rings: [[y - 7, 0, 1.6], [y - 3.2, 0, 1], [y - 2.4, 0, 0.5]], col: '#d9a83a', mat: 'metal', noOut: 1 })]; on(S, T, [0, 0, 1]); }); return; }
      // velvet sheen on the big upholstered faces (back, arms, rolls)
      if (S.col === F0 || S.col === shade(F0, 0.86)) { const [D1, D2] = sheen(S); sides(S, 6).forEach(F => { if (F.n[1] > -0.3 && Math.hypot(...sub(F.q[1], F.q[0])) > 6) velvet(D1, D2, F, R, 2); }); caps(S, 2).forEach(F => velvet(D1, D2, F, R, 2)); on(S, [D1, D2]); } });
    // arms: gold piping round the scroll front, nailheads down the arm front
    if (li === 1 || li === 3) { const rl = B.find(b => b.S.col === F0 && b.S.pts.length && caps(b.S, 2).length && b.L[2] > 50), ab = B.find(b => b.S.col === F0 && b.L[2] < 30);
      if (rl) { const PG = dec('#f0c24a'); caps(rl.S, 2).forEach(F => outline(PG, F, 0.93, 0.75)); on(rl.S, [PG]); }
      if (ab) { const NL = dec('#f3cf62', { shine: 1 }), z = ab.L[5] + 0.06, x0 = ab.L[0] + 2, x1 = ab.L[1] - 2, y0 = ab.L[2] + 2, y1 = ab.L[3] - 2;
        for (let y = y0; y <= y1; y += 2.7) [x0, x1].forEach(x => spot(NL, [x, y, z], [0, 0, 1], 0.62, 0.62, 0, 6)); on(ab.S, [NL]); } }
    // back roll: carved gilt shell crest + finial
    if (li === 0) { const rl = B.find(b => b.S.col === F0 && b.L[1] - b.L[0] > 200 && b.L[3] - b.L[2] < 14); if (rl) { const L = rl.L, zc = (L[4] + L[5]) / 2, y0 = L[3] + 0.3, a = 14, bb = 10;
      const CR = solid({ ax: 'z', sh: 'el', c: [0, y0 + bb], a, b: bb, n: 22, rings: [[zc - 1.1, 0.7, 0.9], [zc - 0.5, 0], [zc + 0.5, 0], [zc + 1.1, 0.7, 0.9]], col: GOLD, mat: 'metal', shine: 1 });
      const FN = ball(0, y0 + bb * 2 - 0.6, zc, 1.7, '#f0c24a', { k: 4, n: 10, shine: 1, mat: 'metal' }), FL = dec('#9a6a14', { op: 0.75 }), HL = dec('#fff1b0', { op: 0.6 });
      [1, 2].forEach(c0 => caps(CR, c0).forEach(F => { const G = fr2(F); rep(9, i => { const t = PI * (0.1 + 0.8 * i / 8), r0 = 2.2, r1 = 9.4; (i % 2 ? HL : FL).line([G.at(Math.cos(t) * r0 * (c0 === 1 ? -1 : 1), -bb + 1.4 + Math.sin(t) * r0), G.at(Math.cos(t) * r1 * (c0 === 1 ? -1 : 1), -bb + 1.4 + Math.sin(t) * r1)], G.n, 0.42, 1); });
        FL.line(rep(13, i => { const t = PI * i / 12; return G.at(Math.cos(t) * 11, -bb + 1.2 + Math.sin(t) * 8.8); }), G.n, 0.5); spot(FL, G.at(0, -bb + 2), G.n, 1.5, 1.1, 0, 8); }));
      // acanthus scrolls either side of the crest along the roll top
      const SC = dec('#f0c24a', { op: 0.95 }); [-1, 1].forEach(sg => { SC.line(rep(16, i => { const t = i / 15, x = sg * (15 + t * 30); return [x, L[3] + 0.08, zc + Math.sin(t * PI * 2.2) * 2.4]; }), Y3, 0.65, 1); rep(4, j => spot(SC, [sg * (19 + j * 7.5), L[3] + 0.1, zc + (j % 2 ? 2.6 : -2.6)], Y3, 0.9, 0.5, 0.5 * sg, 6)); });
      on(rl.S, [CR, FN, SC, FL, HL]); } }
  };
  const apronTex = (o, P) => { const on = glue(o), AP = at(o, [0, 15, 0], GOLD); if (!AP) return; const L = bbS(AP), R = R0('ap25');
    const LS = dec('#b8862a', { op: 0.32 }), BO = dec('#8a2f22', { op: 0.55 }), SH = dec('#fff1b0', { op: 0.35 }), FA = dec('#e9b94a'), FB = dec('#b8862a');
    sides(AP, 3).forEach(F => { const fl = Math.hypot(...sub(F.q[1], F.q[0])); if (fl < 4) return; hatch(LS, F, 0, 3.6, 0.18, { sh: 0.99 }); hatch(LS, F, PI / 2, 4.2, 0.18, { sh: 0.99, ph: 1.3 });
      const G = fr2(F), P2 = G.P, xs = P2.map(q => q[0]), ys = P2.map(q => q[1]), W = Math.max(...xs) - Math.min(...xs), H = Math.max(...ys) - Math.min(...ys);
      rep(Math.round(W / 14), () => { const a = -W / 2 + R() * W, b = (R() < 0.5 ? -1 : 1) * (H / 2 - 0.7); spot(BO, G.at(a, b), G.n, 0.6 + R() * 1.4, 0.35 + R() * 0.3, 0, 6); });
      SH.line([G.at(-W / 2 + 1, H / 2 - 0.6), G.at(W / 2 - 1, H / 2 - 0.6)], G.n, 0.3); });
    // bullion fringe hanging under the apron (front, back, sides): twisted cords, alternating shades
    const y = L[2], fr = (P0, P1, n) => { const cnt = Math.round(Math.hypot(...sub(P1, P0)) / 1.15); rep(cnt, i => { const p = add(P0, mul(sub(P1, P0), (i + 0.5) / cnt)), lift = add(p, mul(n, 0.25)); (i % 2 ? FB : FA).line([[lift[0], y + 0.2, lift[2]], [lift[0], y - 3.4, lift[2]]], n, 0.62); }); };
    fr([L[0] + 2, 0, L[5]], [L[1] - 2, 0, L[5]], [0, 0, 1]); fr([L[1] - 2, 0, L[4]], [L[0] + 2, 0, L[4]], [0, 0, -1]); fr([L[1], 0, L[5] - 2], [L[1], 0, L[4] + 2], [1, 0, 0]); fr([L[0], 0, L[4] + 2], [L[0], 0, L[5] - 2], [-1, 0, 0]);
    on(AP, [LS, BO, SH, FA, FB]); };
  N.chester25 = S => { const B = N.chester(S), D = Object.assign({}, B);
    D.layers = B.layers.map((L, i) => Object.assign({}, L, { build: P => { const o = L.build(P); chesTex(o, P, i); return o; } }));
    D.build = P => { const o = B.build(P); if (S.gold) apronTex(o, P); return o; };
    return D; };

  // ======================= LIV-090 KINETIC ZERO-G CARBON-FIBRE LOUNGE THRONE =======================
  // carbon-fibre twill shell (gloss black, crosshatched weave + clear-coat streaks), quilted perforated leather seat + back with stitched welts, cyan LED loops round the scroll + wing fronts,
  // speaker grilles in the wings, glowing crest on the back, black-glass magnetic floor pad, two kinetic gyro rings orbiting the throne (back half behind, front half in front)
  const CF = '#26282e';
  const thrTex = (o, P) => { const on = glue(o), R = R0('th25'), B = o.map(S => ({ S, L: bbS(S) })).filter(b => !b.S.par && !b.S.emit);
    B.forEach(({ S, L }) => { const w = L[1] - L[0], h = L[3] - L[2], d = L[5] - L[4];
      if (S.col === P.a) { S.col = CF; S.mat = 'pl'; S.shine = 1; S.soft = 0;
        const T1 = dec('#4a4e57', { op: 0.55 }), T2 = dec('#0d0e11', { op: 0.6 }), CC = dec('#ffffff', { op: 0.22 });
        S.faces.forEach(F => { const G = fr2(F); if (Math.abs(area(G.P)) < 4) return; hatch(T1, F, PI / 4, 1.7, 0.4, { sh: 0.98 }); hatch(T2, F, -PI / 4, 1.7, 0.4, { sh: 0.98, ph: 0.85 }); });
        sides(S, 4).forEach(F => { if (F.n[1] > 0.25 || (Math.abs(F.n[2]) > 0.8 && R() < 0.5)) wavy(CC, F, (t, G) => { const xs = G.P.map(q => q[0]), ys = G.P.map(q => q[1]), W = Math.max(...xs) - Math.min(...xs), H = Math.max(...ys) - Math.min(...ys); return [-W / 2 + W * t, H * 0.25]; }, 6, 0.9, 1); });
        on(S, [T1, T2, CC]);
        // LED loop on the front cap of scroll rolls + wings; speaker grille on wing fronts
        const fc = caps(S, 2).filter(F => F.n[2] > 0.9);
        if (fc.length && L[2] > 40) { const LD = dec('#5fe6ff', { emit: 1 }); fc.forEach(F => outline(LD, F, 0.9, 0.55));
          if (h > 20) { const GR = dec('#0a0b0d'), GD = dec('#6d7380', { op: 0.8 }); fc.forEach(F => { const G = fr2(F); GR.poly(rep(16, i => { const a = i / 16 * 2 * PI; return G.at(Math.cos(a) * 5.2, 2 + Math.sin(a) * 5.2); }), G.n); rep(5, i => rep(5, j => { const a = -4 + i * 2, b = -2 + j * 2; if (a * a + b * b < 19) spot(GD, G.at(a, 2 + b), G.n, 0.38, 0.38, 0, 5); })); }); on(S, [GR, GD]); }
          on(S, [LD]); }
        // glowing crest on the back of the backrest
        if (w > 50 && h > 40) { const EM = dec('#5fe6ff', { emit: 1 }); caps(S, 1).forEach(F => { if (F.n[2] > -0.9) return; const G = fr2(F), Q = (a, b) => G.at(a, b), yy = 6;
          EM.line([Q(-9, yy - 4), Q(0, yy + 4), Q(9, yy - 4)], G.n, 0.9); EM.line([Q(-6, yy - 8), Q(0, yy - 2.5), Q(6, yy - 8)], G.n, 0.7); spot(EM, Q(0, yy + 7), G.n, 1, 1, 0, 8); }); on(S, [EM]); }
        return; }
      if (S.col === P.aL) { S.mat = 'lea'; const QD = dec(shade(S.col, 0.7), { op: 0.6 }), QL = dec(mix(S.col, '#ffffff', 0.3), { op: 0.4 }), PF = dec(shade(S.col, 0.55), { op: 0.7 }), WL = dec('#d5dde2', { op: 0.8 });
        caps(S, 2).forEach(F => { hatch(QD, F, PI / 4, 5.5, 0.5, { sh: 0.9 }); hatch(QD, F, -PI / 4, 5.5, 0.5, { sh: 0.9 }); hatch(QL, F, PI / 4, 5.5, 0.18, { sh: 0.9, ph: 0.5 }); hatch(QL, F, -PI / 4, 5.5, 0.18, { sh: 0.9, ph: 0.5 }); dots(PF, F, 1.9, 0.24, { sh: 0.82, stag: 1, m: 5 }); });
        const nr = h < 22 ? 6 : 5; if (S.pts.length % nr === 0) ringL(WL, S, nr - 2, nr, 0.35, nr === 6 ? 0.6 : 0); on(S, [QD, QL, PF, WL]); return; }
      if (S.col === P.aD) { S.col = '#1b1d22'; S.mat = 'pl'; } });
  };
  const gyro = (c, R, y, zc, col, dur, rev, tilt) => { const p = c.p, m = 56, Q = rep(m + 1, i => { const t = i / m * 2 * PI; return p(Math.cos(t) * R, y + Math.sin(t * 2) * 0 + Math.sin(t) * (tilt || 0), zc + Math.sin(t) * R); }), cy = p(0, y, zc)[1];
    const runs = { b: [], f: [] }; let cur = null, kind = null; Q.forEach(q => { const k = q[1] < cy ? 'b' : 'f'; if (k !== kind) { if (cur && cur.length > 1) runs[kind].push(cur); cur = cur ? [cur[cur.length - 1]] : []; kind = k; } cur.push(q); }); if (cur && cur.length > 1) runs[kind].push(cur);
    const mk = (L, op) => L.map(P => { const d = 'M' + P.map(q => f1(q[0]) + ' ' + f1(q[1])).join('L'); return '<path d="' + d + '" fill="none" stroke="#0d0f14" stroke-width="' + f1(c.k * 1.5) + '" stroke-linecap="round" opacity="' + op * 0.55 + '"/><path d="' + d + '" fill="none" stroke="' + col + '" stroke-width="' + f1(c.k * 0.6) + '" stroke-linecap="round" opacity="' + op * 0.6 + '"/><path d="' + d + '" fill="none" stroke="#ffffff" stroke-width="' + f1(c.k * 0.75) + '" stroke-linecap="round" stroke-dasharray="' + f1(c.k * 1.6) + ' ' + f1(c.k * 10.4) + '" opacity="' + op + '"><animate attributeName="stroke-dashoffset" values="0;' + f1((rev ? 1 : -1) * c.k * 36) + '" dur="' + dur + 's" repeatCount="indefinite"/></path>'; }).join('');
    const xs = Q.map(q => q[0]), ys = Q.map(q => q[1]);
    return { back: mk(runs.b, 0.55), front: mk(runs.f, 0.95), bb: [Math.min(...xs) - 3, Math.min(...ys) - 3, Math.max(...xs) + 3, Math.max(...ys) + 3] }; };
  // sort fixes (single-seat wing chair): back cushion pulled clear of the seat (z) and of the scroll rolls (x); wings glued onto the roll they stand on (near-front views had md cycles)
  const mvPts = (S, f) => { const seen = new Set(); S.pts.forEach(p => { if (seen.has(p)) return; seen.add(p); const q = f(p); p[0] = q[0]; p[1] = q[1]; p[2] = q[2]; }); };
  const thrFix = (o, P) => { const B = o.map(S => ({ S, L: bbS(S) })), bc = B.find(b => b.S.col === P.aL && b.L[5] < 0 && b.L[3] - b.L[2] > 30), st = B.find(b => b.S.col === P.aL && b.L[5] > 15);
    if (bc) { const L = bc.L, z0 = L[4], zt = Math.min(L[5], (st ? st.L[4] : L[5]) - 0.3), kz = (zt - z0) / (L[5] - L[4]), kx = 26.6 / Math.max(26.6, (L[1] - L[0]) / 2), cx = (L[0] + L[1]) / 2; mvPts(bc.S, p => [cx + (p[0] - cx) * kx, p[1], z0 + (p[2] - z0) * kz]); }
    if (st) { const L = st.L, cx = (L[0] + L[1]) / 2, kx = 26.4 / Math.max(26.4, (L[1] - L[0]) / 2); mvPts(st.S, p => [cx + (p[0] - cx) * kx, p[1], p[2]]); } };
  const thrGlue = (o, P) => { const B = o.map(S => ({ S, L: bbS(S) })).filter(b => !b.S.par);
    B.filter(b => b.S.col === CF && b.L[2] > 65 && b.L[1] - b.L[0] < 26).forEach(w => { const r = B.find(b => b !== w && b.S.col === CF && Math.abs(b.L[3] - w.L[2]) < 1.5 && Math.sign(b.L[0] + b.L[1]) === Math.sign(w.L[0] + w.L[1])); if (r) w.S.par = r.S; }); };
  N.throne25 = S => { const B = N.rsofa(Object.assign({}, S, { n: 1, float: 1 })), D = Object.assign({}, B), by = 23;
    D.build = P => { const o = B.build(P); thrFix(o, P); thrTex(o, P); thrGlue(o, P); return o; };
    D.layers = splitL(B).map(L => Object.assign({}, L, { build: P => { const o = L.build(P); thrFix(o, P); thrTex(o, P); thrGlue(o, P); return o; } }));
    D.fx = c => { const A = padFx(c, D.w * 0.55, D.d * 0.42, by - 8, 'th25', '#5fe6ff'), G1 = gyro(c, D.w * 0.62, by + 22, 0, '#5fe6ff', 2.2, 0, 4), G2 = gyro(c, D.w * 0.54, by + 46, -6, '#d5dde2', 3.1, 1, -5);
      return { defs: A.defs, under: A.svg, back: G1.back + G2.back, front: G1.front + G2.front, bb: mergeBB(mergeBB(A.bb, G1.bb), G2.bb) }; };
    return D; };

  // ======================= BATCH 2: LIV-108 cognac leather chesterfield, LIV-109 ivory boucle channel sofa on marble, LIV-070 walnut & shearling lounge chair =======================
  // wood grain: wobbly lines along the longest edge of the face + an odd knot
  const grain = (D1, D2, F, R, sp, KN) => { const G = fr2(F); let best = 0, th = 0; G.P.forEach((p, i) => { const q = G.P[(i + 1) % G.P.length], L = Math.hypot(q[0] - p[0], q[1] - p[1]); if (L > best) { best = L; th = Math.atan2(q[1] - p[1], q[0] - p[0]); } });
    const dir = [Math.cos(th), Math.sin(th)], m = [-dir[1], dir[0]], E = ext2(G.P), n = Math.max(1, Math.floor(2 * E / sp));
    rep(n, k => { const s = -E + (k + 0.5) * sp + (R() - 0.5) * sp * 0.5, ph = R() * 6, amp = 0.2 + R() * 0.5; wavy(k % 2 ? D2 : D1, F, t => { const u = -E + 2 * E * t, off = s + amp * Math.sin(u * 0.12 + ph) + 0.25 * Math.sin(u * 0.41 + ph * 2); return [dir[0] * u + m[0] * off, dir[1] * u + m[1] * off]; }, 30, 0.28 * (0.7 + R() * 0.6), 1); });
    if (KN && best > 20 && R() < 0.6) { const u = (R() - 0.5) * best * 0.6, v = (R() - 0.5) * 2, c = G.at(dir[0] * u + m[0] * v, dir[1] * u + m[1] * v); spot(KN, c, G.n, 1.3, 0.7, th, 8); } };
  const chesWrap = (S, lf, bf) => { const B = N.chester(S), D = Object.assign({}, B);
    D.layers = B.layers.map((L, i) => Object.assign({}, L, { build: P => { const o = L.build(P); lf(o, P, i); return o; } }));
    D.build = P => { const o = B.build(P); bf(o, P); return o; }; return D; };
  const F0of = P => (P.c && P.c.a) || P.a;
  // LIV-108: pebbled cognac leather (grain flecks), rubbed patina on seat fronts + roll tops, creases where you sit, dark welts with cream saddle stitching, tartan wool pillows, turned walnut bun feet with rings
  const leaTex = (o, P, li) => { const on = glue(o), R = R0('le25' + li), F0 = F0of(P), B = o.map(S => ({ S, L: bbS(S) })).filter(b => !b.S.par && !b.S.emit);
    B.forEach(({ S, L }) => { const w = L[1] - L[0], h = L[3] - L[2], d = L[5] - L[4];
      if (li === 2 && S.pts.length % 6 === 0 && w > 50 && w < 60 && d > 60) { const PA = dec(mix(S.col, '#ffe2b8', 0.3), { op: 0.28 }), CRD = dec(shade(S.col, 0.84), { op: 0.3 }), FL = dec(shade(S.col, 0.75), { op: 0.35 }), WL = dec(shade(S.col, 0.55), { op: 0.85 }), ST = dec('#f2e2c0', { op: 0.75 });
        caps(S, 2).forEach(F => { const G = fr2(F); spot(PA, G.at(0, -2), G.n, 11, 13, 0.2, 14); spot(PA, G.at(0, -2), G.n, 6, 8, 0.2, 10);
          rep(7, () => { const a = (R() - 0.5) * 30, b = (R() - 0.5) * 36, th = R() * PI, l = 3 + R() * 5; wavy(CRD, F, t => [a + Math.cos(th) * l * (t - 0.5) + Math.sin(t * PI) * 1.2, b + Math.sin(th) * l * (t - 0.5)], 10, 0.7, 1); });
          dots(FL, F, 2.6, 0.22, { sh: 0.85, stag: 1, m: 5 }); });
        sides(S, 3).forEach(F => { if (F.n[2] > 0.7) { wavy(PA, F, (t, G) => { const xs = G.P.map(q => q[0]), ys = G.P.map(q => q[1]), W = Math.max(...xs) - Math.min(...xs), H = Math.max(...ys) - Math.min(...ys); return [-W / 2 + W * t, H * 0.3]; }, 16, 2.4, 1); } });
        ringL(WL, S, 4, 6, 0.7, 0.6); { const n = S.pts.length / 6, RG = S.pts.slice(3 * n, 4 * n), c = RG.reduce((a, p) => add(a, mul(p, 1 / RG.length)), [0, 0, 0]); for (let i = 0; i < n; i += 2) { const p = RG[i], q = RG[(i + 1) % n], nn = nz(sub(p, c)); ST.line([add(p, mul(nn, 0.15)), add(q, mul(nn, 0.15))], nn, 0.22); } }
        on(S, [PA, FL, CRD, WL, ST]); return; }
      if (li === 2 && Math.abs(w - 24) < 3 && Math.abs(h - 24) < 3) { S.col = '#8e2f2a'; S.mat = 'fab'; const T1 = dec('#2f4a36', { op: 0.7 }), T2 = dec('#1d2a22', { op: 0.6 }), T3 = dec('#f2c94a', { op: 0.7 }), ED = dec('#5a1c18', { op: 0.6 });
        S.faces.filter(F => Math.abs(F.n[2]) > 0.35).forEach(F => { hatch(T1, F, 0, 4.2, 1.1, { sh: 0.86 }); hatch(T1, F, PI / 2, 4.2, 1.1, { sh: 0.86 }); hatch(T2, F, 0, 4.2, 0.45, { sh: 0.86, ph: 2.1 }); hatch(T2, F, PI / 2, 4.2, 0.45, { sh: 0.86, ph: 2.1 }); hatch(T3, F, 0, 8.4, 0.18, { sh: 0.86, ph: 1 }); hatch(T3, F, PI / 2, 8.4, 0.18, { sh: 0.86, ph: 1 }); if (F.cap) outline(ED, F, 0.92, 0.4); });
        on(S, [T1, T2, T3, ED]); return; }
      if (S.col === F0) { const PA = dec(mix(S.col, '#ffe2b8', 0.32), { op: 0.3 }), FL = dec(shade(S.col, 0.72), { op: 0.3 }); let any = 0;
        sides(S, 5).forEach(F => { if (F.n[1] > 0.55 && Math.hypot(...sub(F.q[3], F.q[0])) > 30) { wavy(PA, F, (t, G) => { const ys = G.P.map(q => q[1]), xs = G.P.map(q => q[0]), H = Math.max(...ys) - Math.min(...ys), W = Math.max(...xs) - Math.min(...xs); return W > H ? [-W / 2 + W * t, Math.sin(t * 9) * H * 0.12] : [Math.sin(t * 9) * W * 0.12, -H / 2 + H * t]; }, 20, 2.6, 1); any = 1; } });
        sides(S, 8).forEach(F => { if (Math.abs(F.n[1]) < 0.5 && Math.hypot(...sub(F.q[1], F.q[0])) > 10) { dots(FL, F, 3.4, 0.24, { sh: 0.9, stag: 1, m: 5 }); any = 1; } });
        if (any) on(S, [PA, FL]); } });
  };
  const leaBase = (o, P) => { const on = glue(o), R = R0('lb25'), B = o.map(S => ({ S, L: bbS(S) })).filter(b => !b.S.par);
    B.forEach(({ S, L }) => { if (L[3] < 9 && L[1] - L[0] < 10 && S.pts.length > 20) { const cx = (L[0] + L[1]) / 2, cz = (L[4] + L[5]) / 2, RN = dec('#1f140b', { op: 0.6 }), HL = dec('#c48a5a', { op: 0.5 }), yc = (L[2] + L[3]) / 2, r = (L[1] - L[0]) / 2;
      if (r > 3) { [[yc, r + 0.04, RN, 0.45], [yc + r * 0.5, r * 0.88, HL, 0.3]].forEach(([y, rr, Dd, w]) => Dd.line(rep(29, i => { const a = i / 28 * 2 * PI; return [cx + Math.cos(a) * rr, y, cz + Math.sin(a) * rr]; }), rep(29, i => { const a = i / 28 * 2 * PI; return [Math.cos(a), 0, Math.sin(a)]; }), w)); on(S, [RN, HL]); } } }); };
  N.chester25L = S => chesWrap(S, leaTex, leaBase);
  // LIV-109: nubby boucle loops on seats, scroll tops and arms, channel shadows, mustard velvet pillows with piping, Calacatta veins (grey + gold) round the plinth, brushed brass band
  const bouTex = (o, P, li) => { const on = glue(o), R = R0('bo25' + li), F0 = F0of(P), B = o.map(S => ({ S, L: bbS(S) })).filter(b => !b.S.par && !b.S.emit);
    const loops = (S, F, sp) => { const D1 = dec(mix(S.col, '#ffffff', 0.55), { op: 0.55 }), D2 = dec(shade(S.col, 0.86), { op: 0.45 }); dots(D1, F, sp, 0.55, { sh: 0.92, stag: 1, m: 5 }); const G = fr2(F); rep(Math.round(Math.abs(area(G.P)) / (sp * sp * 2.2)), () => { const P2 = shrinkP(G.P, 0.9), E = ext2(P2), q = [(R() - 0.5) * 2 * E, (R() - 0.5) * 2 * E]; if (inP(P2, q)) spot(D2, G.at(q[0], q[1]), G.n, 0.45, 0.45, 0, 5); }); return [D1, D2]; };
    B.forEach(({ S, L }) => { const w = L[1] - L[0], h = L[3] - L[2], d = L[5] - L[4];
      if (li === 2 && S.pts.length % 6 === 0 && w > 50 && w < 60 && d > 60) { const Ls = []; caps(S, 2).forEach(F => Ls.push(...loops(S, F, 2.6))); sides(S, 3).forEach(F => { if (F.n[2] > 0.7 && Math.hypot(...sub(F.q[1], F.q[0])) > 10) Ls.push(...loops(S, F, 2.6)); });
        const WL = dec(shade(S.col, 0.8), { op: 0.6 }); ringL(WL, S, 4, 6, 0.6, 0.6); on(S, Ls.concat([WL])); return; }
      if (li === 2 && Math.abs(w - 24) < 3 && Math.abs(h - 24) < 3) { const [D1, D2] = [dec(mix(S.col, '#ffffff', 0.25), { op: 0.3 }), dec(shade(S.col, 0.82), { op: 0.25 })], PG = dec(shade(S.col, 0.7), { op: 0.8 });
        caps(S, 2).forEach(F => { velvet(D1, D2, F, R, 3); outline(PG, F, 0.94, 0.55); }); on(S, [D1, D2, PG]); return; }
      if (S.col === F0) { const Ls = []; S.faces.forEach(F => { const G = fr2(F); if (Math.abs(area(G.P)) < 60) return; if (F.n[1] > 0.4 || (Math.abs(F.n[1]) < 0.5 && (li === 1 || li === 3))) Ls.push(...loops(S, F, 3)); }); if (Ls.length) on(S, Ls); } });
  };
  const bouBase = (o, P) => { const on = glue(o), R = R0('bb25'), B = o.map(S => ({ S, L: bbS(S) })).filter(b => !b.S.par);
    const pl = B.find(b => b.L[2] < 0.5 && b.L[1] - b.L[0] > 150 && b.L[3] < 12), br = B.find(b => b.S.col === GOLD && b.L[1] - b.L[0] > 150);
    if (pl) { const VG = dec('#9a958e', { op: 0.42 }), VL = dec('#b8b2aa', { op: 0.3 }), VY = dec('#c9a35a', { op: 0.55 });
      pl.S.faces.forEach(F => { if (F.n[1] < -0.5) return; const G = fr2(F); if (Math.abs(area(G.P)) < 20) return; const E = ext2(G.P), up = F.n[1] > 0.5;
        rep(up ? 3 : Math.max(2, Math.round(E / 22)), k => { const ph = R() * 6, s = (R() - 0.5) * (up ? 1.6 * E : 6), th = (R() - 0.5) * 0.9, Dd = k % 3 === 2 ? VY : k % 2 ? VL : VG;
          wavy(Dd, F, t => { const u = -E + 2 * E * t; return [u * Math.cos(th) - (s + Math.sin(u * 0.15 + ph) * 1.6) * Math.sin(th), u * Math.sin(th) + (s + Math.sin(u * 0.15 + ph) * 1.6) * Math.cos(th)]; }, 36, Dd === VY ? 0.45 : 0.35 + R() * 0.3, 1); }); });
      on(pl.S, [VL, VG, VY]); }
    if (br) { const BL = dec('#fff1c0', { op: 0.3 }), BD = dec('#9a7424', { op: 0.25 }); sides(br.S, 1).forEach(F => { if (Math.abs(F.n[1]) < 0.5) { hatch([BL, BD], F, 0, 0.7, 0.16, { sh: 0.98 }); } }); on(br.S, [BL, BD]); } };
  N.chester25B = S => chesWrap(S, bouTex, bouBase);
  // LIV-070: walnut grain + knots + end-grain rings on every frame piece, fluffy shearling tufts, two cognac leather straps over the back with brass buckles
  const shearTex = (o, P, li) => { const on = glue(o), R = R0('sh25' + li), WAL = '#5b3820', SHE = '#efe6d6', B = o.map(S => ({ S, L: bbS(S) })).filter(b => !b.S.par);
    B.forEach(({ S, L }) => { const wood = S.col === WAL || S.col === shade(WAL, 1.08);
      if (wood) { const G1 = dec('#3a2312', { op: 0.5 }), G2 = dec('#8a5a36', { op: 0.4 }), KN = dec('#2a180c', { op: 0.7 }), ER = dec('#3a2312', { op: 0.45 });
        S.faces.forEach(F => { const G = fr2(F), A = Math.abs(area(G.P)); if (A < 6) return;
          if (F.cap) { if (Math.abs(F.n[0]) > 0.9) grain(G1, G2, F, R, 1.4, KN); }
          else { const E = Math.hypot(...sub(F.q[1], F.q[0])), V = Math.hypot(...sub(F.q[3], F.q[0])), m = Math.max(1, Math.round(V / 1.3)); if (E > 6) rep(m, k => { const f = (k + 0.5) / m + (R() - 0.5) * 0.15; ER.line([add(F.q[0], mul(sub(F.q[3], F.q[0]), f)), add(F.q[1], mul(sub(F.q[2], F.q[1]), f))], F.n, 0.18); }); } });
        on(S, [G1, G2, KN, ER]); return; }
      if (S.col === SHE || S.col === mix(SHE, '#ffffff', 0.15) || S.col === mix(SHE, '#ffffff', 0.12)) { const T1 = dec('#ffffff', { op: 0.55 }), T2 = dec('#cbbfa8', { op: 0.4 }), Ls = [T1, T2];
        S.faces.forEach(F => { if (F.cap) return; const G = fr2(F), A = Math.abs(area(G.P)); if (A < 40) return; dots(T1, F, 3, 0.8, { sh: 0.94, stag: 1, m: 6 }); dots(T2, F, 3, 0.45, { sh: 0.94, stag: 1, m: 5, off: [1.5, 1.2] });
          wavy(T2, F, (t, G2) => { const E = ext2(G2.P); return [-E + 2 * E * t, Math.sin(t * 40) * 0.7 + (R() - 0.5) * 4]; }, 40, 0.3); });
        // leather straps over the back cushion + top roll (the faces spanning x are trimmed to the strap width), brass buckle on the front of each strap
        if (L[3] > 40 && L[1] - L[0] > 55) { const LS = dec('#8a4a22'), LH = dec('#c27a45', { op: 0.6 }), BK = dec('#e2b14a', { shine: 1 });
          [-17, 17].forEach(xc => { const x0 = xc - 2.6, x1 = xc + 2.6; S.faces.forEach(F => { if (F.cap) return; const xs = F.q.map(q => q[0]); if (Math.max(...xs) < x1 || Math.min(...xs) > x0) return; const q = F.q.map(p => [Math.max(x0, Math.min(x1, p[0])), p[1], p[2]]);
            LS.poly(q, F.n); LH.line([q[0], q[1]].map(p => [x0 + 0.6, p[1], p[2]]), F.n, 0.25); });
            const fc = S.faces.filter(F => !F.cap && Math.abs(F.n[0]) < 0.01 && F.n[2] > 0.5).sort((a, b) => Math.hypot(...sub(b.q[1], b.q[0])) - Math.hypot(...sub(a.q[1], a.q[0])))[0];
            if (fc) { const m0 = add(fc.q[0], mul(sub(fc.q[1], fc.q[0]), 0.62)), v = nz(sub(fc.q[1], fc.q[0])), c = [xc, m0[1], m0[2]], u = [1, 0, 0];
              BK.line([add(c, add(mul(u, -3.2), mul(v, -2))), add(c, add(mul(u, 3.2), mul(v, -2))), add(c, add(mul(u, 3.2), mul(v, 2))), add(c, add(mul(u, -3.2), mul(v, 2))), add(c, add(mul(u, -3.2), mul(v, -2)))], fc.n, 0.6); BK.line([add(c, mul(v, -2)), add(c, mul(v, 2))], fc.n, 0.4); } });
          Ls.push(LS, LH, BK); }
        on(S, Ls); } });
  };
  N.shear25 = S => { const B = N.shearChair(S), D = Object.assign({}, B); D.layers = B.layers.map((L, i) => Object.assign({}, L, { build: P => { const o = L.build(P); shearTex(o, P, i); return o; } })); return D; };

  // ======================= BATCH 3-5: generic material pass (decor + pit sofa) =======================
  // mtex: every real (unglued, opaque, not glowing) solid gets texture by material: metal = brushing + catch-light on top edges, wood = grain + knots,
  // stone/ceramic = speckle + faint veins + catch-light, fabric = fine weave (or boucle loops), plastic = soft sheen streak. All decals glued -> sort unchanged.
  const isDec = S => S.cv === 0 && S.noOut && !S.mat;
  const lumOf = c => { const m = /^#([0-9a-f]{6})$/i.exec(c || ''); if (!m) return 0.5; const n = parseInt(m[1], 16); return (((n >> 16) & 255) * 0.3 + ((n >> 8) & 255) * 0.59 + (n & 255) * 0.11) / 255; };
  const mtex = (o, tag, opt) => { opt = opt || {}; const on = glue(o), R = R0('mt25' + tag), list = o.slice();
    list.forEach(S => { if (S && S.faces && !S.par && !S.emit && S.op != null && S.op < 0.95 && !isDec(S) && S.cv !== 0) { const L = bbS(S), h = L[3] - L[2], w = Math.max(L[1] - L[0], L[5] - L[4]); if (h > 6 && w > 3) { const GL = dec('#ffffff', { op: 0.6 }), GD = dec('#ffffff', { op: 0.35 });
        sides(S, 2).forEach(F => { const G = fr2(F), xs = G.P.map(q => q[0]), ys = G.P.map(q => q[1]), W = Math.max(...xs) - Math.min(...xs), H = Math.max(...ys) - Math.min(...ys); if (H < 5 || W < 0.8) return;
          const fz = F.n[2] - F.n[0] * 0.6; if (fz > 0.75) GL.line([G.at(0, -H * 0.42), G.at(0, H * 0.42)], G.n, Math.min(W * 0.5, 0.9)); else if (fz > 0.2 && fz < 0.45) GD.line([G.at(0, -H * 0.3), G.at(0, H * 0.38)], G.n, Math.min(W * 0.4, 0.45)); });
        on(S, [GL, GD]); } } });
    list.forEach(S => { if (!S || !S.faces || S.par || S.emit || S.noTex || (S.op != null && S.op < 0.95) || isDec(S) || S.cv === 0) return; const L = bbS(S), sz = Math.max(L[1] - L[0], L[3] - L[2], L[5] - L[4]); if (sz < (opt.min || 3.5)) return;
      const mat = S.mat || (S.shine ? 'metal' : ''), lu = lumOf(S.col), big = F => Math.abs(area(fr2(F).P)) > (opt.amin || 14), Ls = [];
      const hiC = mix(S.col, '#ffffff', 0.55), loC = shade(S.col, lu > 0.6 ? 0.78 : 0.6);
      if (mat === 'metal') { const BR1 = dec(hiC, { op: 0.32 }), BR2 = dec(loC, { op: 0.28 }), CL = dec('#ffffff', { op: 0.55 });
        S.faces.forEach(F => { if (!big(F)) return; grain(BR1, BR2, F, R, Math.max(0.8, sz / 26)); });
        caps(S, 2).forEach(F => { if (F.n[1] > 0.6 && big(F)) outline(CL, F, 0.94, 0.3); }); Ls.push(BR1, BR2, CL); }
      else if (mat === 'wood') { const G1 = dec(shade(S.col, 0.7), { op: 0.45 }), G2 = dec(mix(S.col, '#ffffff', 0.25), { op: 0.35 }), KN = dec(shade(S.col, 0.5), { op: 0.65 });
        S.faces.forEach(F => { if (big(F)) grain(G1, G2, F, R, 1.5, KN); }); Ls.push(G1, G2, KN); }
      else if (mat === 'cer' || mat === 'stone') { const SP1 = dec(shade(S.col, 0.7), { op: 0.5 }), SP2 = dec(mix(S.col, '#ffffff', 0.5), { op: 0.5 }), VN = dec(lu > 0.55 ? shade(S.col, 0.72) : mix(S.col, '#ffffff', 0.35), { op: 0.4 }), CL = dec('#ffffff', { op: 0.4 });
        S.faces.forEach(F => { const G = fr2(F), A = Math.abs(area(G.P)); if (A < (opt.amin || 14)) return; const P2 = shrinkP(G.P, 0.9), E = ext2(P2), n = Math.min(26, Math.round(A / 9));
          rep(n, k => { const q = [(R() - 0.5) * 2 * E, (R() - 0.5) * 2 * E]; if (inP(P2, q)) spot(k % 3 ? SP1 : SP2, G.at(q[0], q[1]), G.n, 0.18 + R() * 0.32, 0.15 + R() * 0.2, R() * 3, 5); });
          if (A > 60 && R() < 0.7) { const ph = R() * 6, s = (R() - 0.5) * E, th = R() * PI; wavy(VN, F, t => { const u = -E + 2 * E * t, w = s + Math.sin(u * 0.2 + ph) * E * 0.12; return [u * Math.cos(th) - w * Math.sin(th), u * Math.sin(th) + w * Math.cos(th)]; }, 24, 0.3, 1); } });
        caps(S, 2).forEach(F => { if (F.n[1] > 0.6 && big(F)) outline(CL, F, 0.95, 0.25); }); Ls.push(SP1, SP2, VN, CL); }
      else if (mat === 'fab' || mat === 'lea') { if (opt.boucle && mat === 'fab') { const D1 = dec(mix(S.col, '#ffffff', 0.6), { op: 0.6 }), D2 = dec(shade(S.col, 0.84), { op: 0.5 });
          S.faces.forEach(F => { if (!big(F) || F.n[1] < -0.3) return; dots(D1, F, 2.8, 0.6, { sh: 0.92, stag: 1, m: 5 }); dots(D2, F, 2.8, 0.42, { sh: 0.92, stag: 1, m: 5, off: [1.4, 1.1] }); }); Ls.push(D1, D2); }
        else { const W1 = dec(mix(S.col, '#ffffff', 0.3), { op: 0.28 }), W2 = dec(shade(S.col, 0.8), { op: 0.28 }); S.faces.forEach(F => { if (!big(F)) return; hatch(W1, F, 0, 1.4, 0.22, { sh: 0.97 }); hatch(W2, F, PI / 2, 1.4, 0.22, { sh: 0.97 }); }); Ls.push(W1, W2); } }
      else if (sz > 6) { const SH = dec('#ffffff', { op: lu > 0.6 ? 0.45 : 0.25 }), SD = dec(shade(S.col, 0.8), { op: 0.25 });
        caps(S, 2).forEach(F => { if (F.n[1] > 0.6 && big(F)) { outline(SH, F, 0.93, 0.3); wavy(SH, F, (t, G) => { const E = ext2(G.P); return [-E * 0.6 + E * 0.9 * t, -E * 0.25 + E * 0.5 * t]; }, 8, 0.7, 1); } });
        sides(S, 2).forEach(F => { if (Math.abs(F.n[1]) < 0.3 && big(F) && F.n[2] > 0.3) wavy(SD, F, (t, G) => { const xs = G.P.map(q => q[0]), ys = G.P.map(q => q[1]); return [Math.min(...xs) * 0.9 + (Math.max(...xs) - Math.min(...xs)) * 0.9 * t, Math.min(...ys) * 0.7]; }, 4, 0.5, 1); }); Ls.push(SH, SD); }
      if (Ls.length) on(S, Ls); }); };
  const texWrap = (src, tag, opt, more) => S => { const B = N[src](S), D = Object.assign({}, B);
    if (B.build) D.build = (...a) => { const o = B.build(...a); mtex(o, tag, opt); if (more) more(o, a[0]); return o; };
    if (B.layers) D.layers = B.layers.map((L, i) => Object.assign({}, L, { build: (...a) => { const o = L.build(...a); mtex(o, tag + i, opt); if (more) more(o, a[0], i); return o; } }));
    return D; };
  N.bio25 = texWrap('bio24', 'bio');
  N.terra25x = texWrap('terra25', 'ter', { min: 3 });
  N.chrono25x = texWrap('chrono25', 'chr', { min: 3 });
  N.lev25x = texWrap('lev24', 'lev');
  N.ikebana25x = texWrap('ikebana25', 'ike', { min: 2.5, amin: 8 });
  N.alab25 = texWrap('alab24', 'ala');
  // LIV-066 cloud pit: boucle loops on every puff, piped welt round each seat top, oak grain on the plinths, a chunky-knit throw folded over the middle back puff
  N.cloudPitP = S => { const B = N.cloudPit(S), D = Object.assign({}, B), pk = o => { o.filter(S2 => S2 && S2.pts && S2.mat === 'fab').map(S2 => ({ S: S2, L: bbS(S2) })).filter(b => b.S.par && Math.abs(b.L[3] - b.L[2] - 18.4) < 2).sort((a, b) => a.L[0] - b.L[0]).forEach((b, i) => { b.S.noTex = 1; b.S.col = i ? '#f3ede2' : '#b5562f'; b.S.pk = i ? 'fur' : 'cable'; }); return o; }; if (B.build) D.build = P => pk(B.build(P)); if (B.layers) D.layers = B.layers.map(L => Object.assign({}, L, { build: P => pk(L.build(P)) })); return D; };
  const pitPil = o => { const on = glue(o), R = R0('pk25'); o.filter(S => S && S.pk).forEach(S => { const L = bbS(S);
    if (S.pk === 'cable') { const CB = dec(shade(S.col, 0.72), { op: 0.75 }), CL = dec(mix(S.col, '#ffffff', 0.25), { op: 0.6 }), RB = dec(shade(S.col, 0.85), { op: 0.5 });
      S.faces.forEach(F => { if (!bigF(F, 2)) return; hatch(RB, F, PI / 2, 1.2, 0.3, { sh: 0.95 }); hatch(CB, F, PI / 2 - 0.7, 2.4, 0.5, { sh: 0.95 }); hatch(CL, F, PI / 2 + 0.7, 2.4, 0.4, { sh: 0.95, ph: 1.2 }); }); on(S, [RB, CB, CL]); }
    else { const F1 = dec('#ffffff', { op: 0.7 }), F2 = dec('#d9cfbe', { op: 0.6 }); S.faces.forEach(F => { if (!bigF(F, 3)) return; dots(F1, F, 1.1, 0.5, { sh: 0.96, stag: 1, m: 5 }); dots(F2, F, 1.1, 0.35, { sh: 0.96, stag: 1, m: 5, off: [0.55, 0.45] }); }); on(S, [F1, F2]); } }); };
  N.cloudPit25 = texWrap('cloudPitP', 'pit', { boucle: 1, amin: 30 }, (o, P, li) => { pitPil(o); if (li != null) return; const on = glue(o);
    o.filter(S => !S.par && S.mat === 'fab' && S.pts && S.pts.length % 5 === 0).forEach(S => { const L = bbS(S); if (L[3] - L[2] > 25) return; const WL = dec(shade(S.col, 0.8), { op: 0.6 }); ringL(WL, S, 3, 5, 0.6, 0.6); on(S, [WL]); });
    { const bp = o.filter(S => !S.par && S.mat === 'fab').map(S => ({ S, L: bbS(S) })).filter(b => b.L[3] - b.L[2] > 25).sort((a, b) => Math.abs((a.L[0] + a.L[1]) / 2) - Math.abs((b.L[0] + b.L[1]) / 2))[0];
      if (bp) { const TC = '#c9a35a', TH = dec(TC), K1 = dec(shade(TC, 0.78), { op: 0.7 }), K2 = dec(mix(TC, '#ffffff', 0.3), { op: 0.55 }), cx = (bp.L[0] + bp.L[1]) / 2, x0 = cx - 11, x1 = cx + 11;
        bp.S.faces.forEach(F => { if (F.n[1] < -0.2) return; const xs = F.q.map(q => q[0]); if (Math.max(...xs) < x0 || Math.min(...xs) > x1) return; if (F.n[1] < 0.5 && F.n[2] < 0.2) return; const q = F.q.map(p => [Math.max(x0, Math.min(x1, p[0])), p[1], p[2]]); TH.poly(q, F.n); hatch([K1, K2], { q, n: F.n }, PI / 2, 1.8, 0.7, { sh: 0.95 }); });
        on(bp.S, [TH, K1, K2]); } } });

  // ======================= BATCH 6: LIV-006 lumpy plaid thrift two-seater, LIV-026 Scandi grey 3-seat, LIV-046 cognac leather L-sectional =======================
  // rsofa parts by role: seat / back (cushions, P.aL), roll / arm / slab (frame fabric P.a), pil (throw pillows), leg, rail. Glued parts are skipped.
  const roles = (o, P) => o.filter(S => S && S.pts && S.pts.length && !S.par && !S.emit).map(S => { const L = bbS(S), w = L[1] - L[0], h = L[3] - L[2], d = L[5] - L[4];
    const r = S.col === P.aL && L[5] > 15 && h < 22 ? 'seat' : S.col === P.aL && L[5] < 0 && h > 30 ? 'back' : S.col === P.a ? (h < 16 && d > 50 && w < 34 ? 'roll' : w < 34 && d > 50 ? 'arm' : 'slab')
      : !isFab(S, P) && S.mat === 'fab' && w > 17 && w < 28 && d < 11 ? 'pil' : S.mat === 'metal' && L[2] < 0.5 && w < 8 ? 'leg' : S.mat === 'metal' && w > 40 && h < 4 ? 'rail' : '';
    return { S, L, r }; });
  const UPH = { seat: 1, back: 1, roll: 1, arm: 1, slab: 1 };
  const bigF = (F, a) => Math.abs(area(fr2(F).P)) > a;
  const fleck = (D1, D2, F, R, dens, r) => { const G = fr2(F), P2 = shrinkP(G.P, 0.92), E = ext2(P2), n = Math.min(40, Math.round(Math.abs(area(G.P)) * dens));
    rep(n, k => { const q = [(R() - 0.5) * 2 * E, (R() - 0.5) * 2 * E]; if (inP(P2, q)) { const rr = r * (0.7 + R() * 0.6); spot(k % 2 ? D2 : D1, G.at(q[0], q[1]), G.n, rr, rr * 0.85, 0, 6); } }); };
  const WH2 = (G) => { const xs = G.P.map(q => q[0]), ys = G.P.map(q => q[1]); return [Math.max(...xs) - Math.min(...xs), Math.max(...ys) - Math.min(...ys)]; };
  const crease = (D, F, R, n, sx, sy, l) => rep(n, () => { const a = (R() - 0.5) * sx, b = (R() - 0.5) * sy, th = R() * PI, ll = l * (0.6 + R() * 0.8); wavy(D, F, t => [a + Math.cos(th) * ll * (t - 0.5) + Math.sin(t * PI) * 1.1, b + Math.sin(th) * ll * (t - 0.5)], 10, 0.55, 1); });
  const frontF = S => sides(S, 3).filter(F => F.n[2] > 0.7).sort((a, b) => Math.abs(area(fr2(b).P)) - Math.abs(area(fr2(a).P)))[0];
  const stitchRing = (D, S, k, nr, w) => { const n = S.pts.length / nr, RG = S.pts.slice(k * n, (k + 1) * n), c = RG.reduce((a, p) => add(a, mul(p, 1 / RG.length)), [0, 0, 0]);
    for (let i = 0; i < n; i += 2) { const p = RG[i], q = RG[(i + 1) % n], nn = nz(sub(p, c)); D.line([add(p, mul(nn, 0.15)), add(q, mul(nn, 0.15))], nn, w || 0.22); } };
  const sideOf = b => Math.sign(b.L[0] + b.L[1]);
  // throw folded over one arm roll (sg -1 left = back layer, +1 right) and hanging down the arm's outer side; wk = waffle / knit grid
  const armThrow = (o, B, sg, TC, wk) => { const on = glue(o), roll = B.find(b => b.r === 'roll' && sideOf(b) === sg); if (!roll) return;
    const { S, L } = roll, zc = (L[4] + L[5]) / 2, z0 = zc - 2, z1 = zc + 20, TH = dec(TC), K1 = dec(shade(TC, 0.8), { op: 0.5 });
    S.faces.forEach(F => { if (F.cap) return; const zs = F.q.map(q => q[2]); if (Math.max(...zs) < z0 || Math.min(...zs) > z1 || F.n[0] * sg < -0.3) return;
      const q = F.q.map(p => [p[0], p[1], Math.max(z0, Math.min(z1, p[2]))]); if (Math.abs(q[0][2] - q[3][2]) + Math.abs(q[1][2] - q[2][2]) < 0.5) return; TH.poly(q, F.n);
      if (wk === 'fur') { dots(K1, { q, n: F.n }, 1.3, 0.55, { sh: 0.97, stag: 1, m: 5 }); } else if (wk) { hatch(K1, { q, n: F.n }, 0, 1.7, 0.35, { sh: 0.97 }); hatch(K1, { q, n: F.n }, PI / 2, 1.7, 0.35, { sh: 0.97 }); } });
    on(S, [TH, K1]);
    const ab = B.find(b => b.r === 'arm' && sideOf(b) === sg); if (!ab) return;
    const x = sg < 0 ? ab.L[0] : ab.L[1], y1 = ab.L[3], y0 = y1 - 18, wv = z => y0 + Math.sin(z * 0.7) * 1.2, nn = [sg, 0, 0], Q = [[x, y1, z0], [x, y1, z1], [x, wv(z1), z1 - 1.5], [x, wv(z0), z0 + 1.5]];
    const T2 = dec(TC), K2 = dec(shade(TC, 0.8), { op: 0.5 }), FD = dec(shade(TC, 0.72), { op: 0.45 }), FR = dec(shade(TC, 0.86));
    T2.poly(Q, nn); if (wk === 'fur') dots(K2, { q: Q, n: nn }, 1.3, 0.55, { sh: 0.96, stag: 1, m: 5 }); else if (wk) { hatch(K2, { q: Q, n: nn }, 0, 1.7, 0.35, { sh: 0.96 }); hatch(K2, { q: Q, n: nn }, PI / 2, 1.7, 0.35, { sh: 0.96 }); }
    rep(5, i => { const z = z0 + 3 + i * (z1 - z0 - 6) / 4; FD.line([[x, y1 - 1, z], [x, wv(z) + 1.5, z]], nn, 0.5); });
    rep(13, i => { const z = z0 + 2 + i * (z1 - z0 - 4) / 12; FR.line([[x, wv(z) + 0.4, z], [x, wv(z) - 2.4, z + 0.2]], nn, 0.4); });
    on(ab.S, [T2, K2, FD, FR]); };
  // rsofa keeps the back slab and the left arm in one back layer; at 35-70 deg the layer vote keeps that layer behind the base, so the left arm vanished.
  // split it: back slab (+ its glued parts) in its own back layer, left arm (box, roll, disc, wing) in a second back layer, like the chesterfield's arms.
  const rsWrap = (S, f) => { const B = N.rsofa(S), D = Object.assign({}, B);
    D.build = P => { const o = B.build(P); f(o, P); return o; };
    D.layers = splitL(B).map((L, i) => Object.assign({}, L, { build: P => { const o = L.build(P); f(o, P, i); return o; } })); return D; };

  // LIV-006: thrift-store tartan (dark green bands, cream + mustard lines) on every upholstered face, pilling, lumpy seats with dents and creases,
  // a spring poking out of the left seat, duct-tape X on the right seat, coffee ring, corduroy patch on a back cushion, threadbare arm top, granny-square pillow, odd wooden leg
  const plaidTex = (o, P, li) => { const on = glue(o), R = R0('pl25' + (li == null ? 'm' : li)), B = roles(o, P);
    B.forEach(({ S, r }) => { if (!UPH[r]) return;
      const DK = dec(mix(shade(S.col, 0.55), '#2f4a36', 0.5), { op: 0.42 }), LT = dec(mix(S.col, '#fff3d6', 0.6), { op: 0.5 }), AC = dec('#e7b648', { op: 0.55 }), PF = dec(mix(S.col, '#ffffff', 0.45), { op: 0.32 });
      S.faces.forEach(F => { if (!bigF(F, 5)) return; [0, PI / 2].forEach(a => { hatch(DK, F, a, 9, 2.8, { sh: 0.99 }); hatch(LT, F, a, 9, 0.35, { sh: 0.99, ph: 4.5 }); hatch(AC, F, a, 18, 0.3, { sh: 0.99, ph: 1.2 }); });
        if (bigF(F, 40) && F.n[1] > -0.2) fleck(PF, PF, F, R, 0.05, 0.35); });
      const Ls = [DK, LT, AC, PF];
      if (r === 'seat') { const HL = dec(mix(S.col, '#ffffff', 0.35), { op: 0.16 }), DN = dec(shade(S.col, 0.6), { op: 0.22 }), CR = dec(shade(S.col, 0.5), { op: 0.45 });
        caps(S, 2).forEach(F => { const G = fr2(F); spot(HL, G.at(-9, 6), G.n, 11, 9, 0.3, 14); spot(HL, G.at(10, -8), G.n, 9, 8, -0.4, 14); spot(DN, G.at(2, -1), G.n, 8, 6, 0.2, 12); spot(DN, G.at(2, -1), G.n, 4, 3, 0.2, 10); crease(CR, F, R, 5, 34, 36, 7); });
        const fc = frontF(S); if (fc) wavy(CR, fc, (t, G) => { const [W, H] = WH2(G); return [-W / 2 + W * t, H * 0.32 - Math.sin(t * PI) * H * 0.18]; }, 16, 0.5, 1);
        Ls.push(HL, DN, CR); }
      on(S, Ls); });
    const seats = B.filter(b => b.r === 'seat').sort((a, b) => a.L[0] - b.L[0]), backs = B.filter(b => b.r === 'back').sort((a, b) => a.L[0] - b.L[0]);
    if (seats.length) { const sl = seats[0], fc = frontF(sl.S);
      if (fc) { const G = fr2(fc), [W] = WH2(G), x0 = W / 2 - 8, HO = dec('#3a2a20', { op: 0.85 }), SP = dec('#c3c8cc', { shine: 1 }), FY = dec(mix(sl.S.col, '#fff3d6', 0.5), { op: 0.8 });
        spot(HO, G.at(x0, 0.5), G.n, 2.2, 1.3, 0, 10); SP.line(rep(25, i => { const t = i / 24; return G.at(x0 + Math.sin(t * PI * 6) * 1.3 + (t - 0.5) * 1.2, 0.5 + t * 1.4 + Math.cos(t * PI * 6) * 0.55); }), G.n, 0.32);
        rep(6, i => { const a = i / 6 * 2 * PI; FY.line([G.at(x0 + Math.cos(a) * 2, 0.5 + Math.sin(a) * 1.2), G.at(x0 + Math.cos(a) * 3, 0.5 + Math.sin(a) * 1.8)], G.n, 0.22); }); on(sl.S, [HO, SP, FY]); }
      const sr = seats[seats.length - 1], fr = frontF(sr.S);
      if (fr && sr !== sl) { const G = fr2(fr), TP = dec('#b9bec4'), TL = dec('#e8ecef', { op: 0.6 }), TE = dec('#80868c', { op: 0.6 });
        [0.55, -0.55].forEach(a => { const c = Math.cos(a), s = Math.sin(a), Q = [[-5.5, -1.3], [5.5, -1.3], [5.8, 1.3], [-5.2, 1.3]].map(([x, y]) => G.at(-6 + x * c - y * s, 0.3 + x * s + y * c)); TP.poly(Q, G.n); TL.line([Q[3], Q[2]], G.n, 0.25); TE.line([Q[1], Q[2]], G.n, 0.2); }); on(sr.S, [TP, TL, TE]); }
      if (sr !== sl) { const CF = dec('#6b3f22', { op: 0.45 }), CS = dec('#7a4a2a', { op: 0.14 }); caps(sr.S, 2).forEach(F => { const G = fr2(F); CF.line(rep(23, i => { const a = i / 22 * 2 * PI * 0.9; return G.at(9 + Math.cos(a) * 3.2, 10 + Math.sin(a) * 2.8); }), G.n, 0.45); spot(CS, G.at(9.5, 9.6), G.n, 3, 2.6, 0, 10); }); on(sr.S, [CF, CS]); } }
    if (backs.length) { const bl = backs[0], CD = dec('#c98f3a'), CW = dec('#9a6a26', { op: 0.55 }), SN = dec('#f4ead2', { op: 0.9 });
      caps(bl.S, 2).forEach(F => { const G = fr2(F), Q = [[-13, 1], [-4, 1.6], [-4.4, 10], [-13.4, 9.4]].map(([a, b]) => G.at(a, b)); CD.poly(Q, G.n); hatch(CW, { q: Q, n: G.n }, PI / 2, 1, 0.3, { sh: 0.92 });
        rep(4, e => { const A = Q[e], Bq = Q[(e + 1) % 4]; rep(5, k => { const t0 = (k + 0.2) / 5, t1 = (k + 0.6) / 5; SN.line([add(A, mul(sub(Bq, A), t0)), add(A, mul(sub(Bq, A), t1))], G.n, 0.28); }); }); });
      on(bl.S, [CD, CW, SN]); }
    B.filter(b => b.r === 'roll' && sideOf(b) > 0).forEach(({ S }) => { const TB = dec('#efe2c4', { op: 0.42 }), TF = dec('#8a6a48', { op: 0.6 }); S.faces.forEach(F => { if (F.cap || F.n[1] < 0.8) return; const zs = F.q.map(q => q[2]); if (Math.max(...zs) < 10 || Math.min(...zs) > 34) return; const G = fr2(F); spot(TB, G.at(0, 0), G.n, 3.5, 5.5, 0.1, 12); rep(5, i => TF.line([G.at(-2 + i, -3), G.at(-2.2 + i, 3)], G.n, 0.16)); }); on(S, [TB, TF]); });
    B.filter(b => b.r === 'pil').forEach(({ S }) => { S.col = '#3b3340'; const GC = ['#e2554a', '#f2c94c', '#5b8fd0', '#7ab86a', '#e3946a', '#c77dd4'], DS = GC.map(c => dec(c)), IN = dec('#f4ead2');
      [1, 2].forEach(c0 => caps(S, c0).forEach(F => { const G = fr2(F); rep(9, k => { const i = k % 3, j = Math.floor(k / 3), cx = -5.6 + i * 5.6, cy = -5.6 + j * 5.6, sq = (s) => [[-s, -s], [s, -s], [s, s], [-s, s]].map(([a, b]) => G.at(cx + a, cy + b));
        DS[(k + c0) % 6].poly(sq(2.45), G.n); IN.poly(sq(1.1), G.n); DS[(k + c0 + 3) % 6].poly(sq(0.5), G.n); }); }));
      on(S, DS.concat([IN])); });
    if (li == null) { const lg = B.filter(b => b.r === 'leg').sort((a, b) => b.L[4] - a.L[4] || b.L[0] - a.L[0])[0]; if (lg) { lg.S.col = '#8a5a34'; lg.S.mat = 'wood'; } } };
  N.plaid25 = S => rsWrap(S, plaidTex);

  // LIV-026: heathered grey woven fabric (fine weave + dark/light flecks), piped welts, oak tapered legs + oak rail, mustard rib-knit pillow,
  // white pillow with a black zigzag print, oatmeal waffle-knit throw over the left arm
  const scanTex = (o, P, li) => { const on = glue(o), R = R0('sc25' + (li == null ? 'm' : li)), B = roles(o, P);
    B.forEach(({ S, r }) => {
      if (r === 'leg' || r === 'rail') { S.col = '#c99a62'; S.mat = 'wood'; S.shine = 0; const G1 = dec('#9a6c3e', { op: 0.5 }), G2 = dec('#e0bb88', { op: 0.4 }); S.faces.forEach(F => { if (bigF(F, r === 'rail' ? 10 : 2) && Math.abs(F.n[1]) < 0.5) grain(G1, G2, F, R, r === 'rail' ? 0.9 : 0.7); }); on(S, [G1, G2]); return; }
      if (r === 'pil') return;
      if (!UPH[r]) return;
      const W1 = dec(mix(S.col, '#ffffff', 0.3), { op: 0.3 }), W2 = dec(shade(S.col, 0.8), { op: 0.3 }), H1 = dec(shade(S.col, 0.8), { op: 0.22 }), H2 = dec(mix(S.col, '#ffffff', 0.55), { op: 0.3 }), WL = dec(shade(S.col, 0.74), { op: 0.7 }), Ls = [W1, W2, H1, H2, WL];
      S.faces.forEach(F => { if (!bigF(F, 6)) return; hatch(W1, F, 0, 1.3, 0.22, { sh: 0.98 }); hatch(W2, F, PI / 2, 1.3, 0.22, { sh: 0.98 }); fleck(H1, H2, F, R, 0.07, 0.22); });
      if (r === 'seat') { ringL(WL, S, 4, 6, 0.5, 0.6); const CR = dec(shade(S.col, 0.84), { op: 0.22 }); caps(S, 2).forEach(F => crease(CR, F, R, 2, 26, 26, 6)); Ls.push(CR); }
      if (r === 'back' && S.pts.length % 5 === 0) ringL(WL, S, 3, 5, 0.5, 0);
      if (r === 'roll' && S.pts.length % 4 === 0) { ringL(WL, S, 0, 4, 0.45, 0); ringL(WL, S, 3, 4, 0.45, 0); }
      on(S, Ls); });
    B.filter(b => b.r === 'pil').forEach(({ S }, i) => {
      if (i === 0) { S.col = '#d9a441'; const RB = dec(shade(S.col, 0.8), { op: 0.5 }), RL = dec(mix(S.col, '#ffffff', 0.3), { op: 0.4 }), ED = dec(shade(S.col, 0.7), { op: 0.6 }); S.faces.forEach(F => { if (bigF(F, 4)) hatch([RB, RL], F, PI / 2, 1.2, 0.4, { sh: 0.96 }); if (F.cap) outline(ED, F, 0.93, 0.4); }); on(S, [RB, RL, ED]); }
      else { S.col = '#f1eee6'; const BK = dec('#2b2b2e', { op: 0.85 }), ED = dec('#c9c4b8', { op: 0.6 });
        [1, 2].forEach(c0 => caps(S, c0).forEach(F => { rep(4, j => wavy(BK, F, t => { const s = (t * 7) % 1, z = s < 0.5 ? s * 2 : (1 - s) * 2; return [-8 + 16 * t, -6.3 + j * 4.2 + z * 1.7]; }, 42, 0.42)); outline(ED, F, 0.93, 0.4); }));
        on(S, [BK, ED]); } });
    o.forEach(S => { if (S && S.mat === 'metal' && !S.emit && S.par && S.col !== '#c99a62') { S.col = '#b88a55'; S.mat = 'wood'; S.shine = 0; } });
    if (li === 1) armThrow(o, B, -1, '#e3d8c4', 1); };
  N.scandi25 = S => rsWrap(S, scanTex);

  // LIV-046: full-grain cognac leather: pores + flecks, rubbed patina on seat tops/fronts and roll tops, soft creases, dark welts with cream saddle stitching,
  // cream boucle + charcoal herringbone wool pillows, a striped grey wool blanket folded across the chaise end with fringe
  const cogTex = (o, P, li) => { const on = glue(o), R = R0('cg25' + (li == null ? 'm' : li)), B = roles(o, P);
    B.forEach(({ S, r }) => { if (!UPH[r]) return; S.mat = 'lea';
      const PA = dec(mix(S.col, '#ffe2b8', 0.3), { op: 0.26 }), FL = dec(shade(S.col, 0.85), { op: 0.22 }), FL2 = dec(mix(S.col, '#ffffff', 0.3), { op: 0.18 }), WL = dec(shade(S.col, 0.5), { op: 0.85 }), ST = dec('#f2e2c0', { op: 0.75 }), CR = dec(shade(S.col, 0.86), { op: 0.2 }), Ls = [PA, FL, FL2, CR];
      S.faces.forEach(F => { if (bigF(F, 30)) fleck(FL, FL2, F, R, 0.06, 0.25); });
      if (r === 'seat') { caps(S, 2).forEach(F => { const G = fr2(F); spot(PA, G.at(0, 2), G.n, 12, 12, 0.2, 14); spot(PA, G.at(0, 2), G.n, 6, 7, 0.2, 10); crease(CR, F, R, 3, 26, 30, 7); });
        const fc = frontF(S); if (fc) wavy(PA, fc, (t, G) => { const [W, H] = WH2(G); return [-W / 2 + W * t, H * 0.3]; }, 16, 2.2, 1);
        ringL(WL, S, 4, 6, 0.65, 0.6); stitchRing(ST, S, 3, 6); Ls.push(WL, ST); }
      if (r === 'back') { caps(S, 2).forEach(F => { const G = fr2(F); spot(PA, G.at(0, 6), G.n, 14, 10, 0, 14); crease(CR, F, R, 2, 32, 16, 9); }); if (S.pts.length % 5 === 0) { ringL(WL, S, 3, 5, 0.6, 0); stitchRing(ST, S, 2, 5); } Ls.push(WL, ST); }
      if (r === 'roll') { S.faces.forEach(F => { if (!F.cap && F.n[1] > 0.55 && Math.hypot(...sub(F.q[3], F.q[0])) > 30) wavy(PA, F, (t, G) => { const [W, H] = WH2(G); return W > H ? [-W / 2 + W * t, Math.sin(t * 9) * H * 0.12] : [Math.sin(t * 9) * W * 0.12, -H / 2 + H * t]; }, 20, 2.4, 1); });
        if (S.pts.length % 4 === 0) { ringL(WL, S, 0, 4, 0.5, 0); ringL(WL, S, 3, 4, 0.5, 0); } Ls.push(WL); }
      on(S, Ls); });
    B.filter(b => b.r === 'pil').forEach(({ S }, i) => {
      if (i === 0) { S.col = '#ebe3d4'; const D1 = dec('#ffffff', { op: 0.6 }), D2 = dec('#c9bfae', { op: 0.5 }); S.faces.forEach(F => { if (!bigF(F, 6)) return; dots(D1, F, 1.9, 0.5, { sh: 0.92, stag: 1, m: 5 }); dots(D2, F, 1.9, 0.36, { sh: 0.92, stag: 1, m: 5, off: [0.95, 0.8] }); }); on(S, [D1, D2]); }
      else { S.col = '#4a4a50'; const H1 = dec('#6a6a72', { op: 0.6 }), H2 = dec('#34343a', { op: 0.6 }), ED = dec('#2a2a2e', { op: 0.6 });
        S.faces.forEach(F => { if (!bigF(F, 6)) return; const G = fr2(F), E = ext2(G.P); for (let c = -E; c < E; c += 3) [PI / 4, -PI / 4].forEach((a, j) => { const x0 = c + j * 1.5; wavy(j ? H2 : H1, F, t => [x0 + (j ? -1 : 1) * 0.5, -E + 2 * E * t], 6, 0.5); });
          hatch(H1, F, PI / 4, 3, 0.35, { sh: 0.92 }); hatch(H2, F, -PI / 4, 3, 0.35, { sh: 0.92, ph: 1.5 }); if (F.cap) outline(ED, F, 0.93, 0.4); }); on(S, [H1, H2, ED]); } });
    if (li == null) { const ch = B.filter(b => b.r === 'seat').sort((a, b) => (b.L[5] - b.L[4]) - (a.L[5] - a.L[4]))[0];
      if (ch && ch.L[5] - ch.L[4] > 75) { const BC = '#7b8088', BL = dec(BC), BK = dec(shade(BC, 0.82), { op: 0.5 }), BS = dec('#efe6d6', { op: 0.9 }), BF = dec(mix(BC, '#ffffff', 0.3), { op: 0.7 }), FR = dec(shade(BC, 0.9));
        caps(ch.S, 2).forEach(F => { const G = fr2(F), [W, H] = WH2(G), a0 = -W / 2 + 2.5, a1 = W / 2 - 2.5, b0 = -H / 2 + 3, b1 = b0 + 22, Q = [G.at(a0, b0), G.at(a1, b0), G.at(a1 - 0.6, b1), G.at(a0 + 0.6, b1)];
          BL.poly(Q, G.n); hatch(BK, { q: Q, n: G.n }, PI / 4, 1.4, 0.3, { sh: 0.95 }); [3, 4.6].forEach(y => BS.line([G.at(a0 + 0.3, b0 + y), G.at(a1 - 0.3, b0 + y)], G.n, 0.7)); BF.line([G.at(a0 + 0.5, b0 + 11), G.at(a1 - 0.5, b0 + 11.4)], G.n, 0.45);
          rep(Math.round((a1 - a0) / 1.3), i => { const a = a0 + 0.6 + i * 1.3; FR.line([G.at(a, b0 + 0.2), G.at(a + 0.2, b0 - 2)], G.n, 0.35); }); });
        on(ch.S, [BL, BK, BS, BF, FR]); } } };
  N.cognac25 = S => rsWrap(S, cogTex);

  // ======================= BATCH 7: LIV-107 velvet chesterfield, LIV-010 mismatched folding chair, LIV-030 mid-century mustard wingback =======================
  // LIV-107: crushed-velvet nap on every upholstered face, self piping on seat welts + scroll fronts, mustard velvet pillows with piping and corner tassels,
  // ringed walnut bun feet, a paperback lying open on the right arm
  const velTex = (o, P, li) => { const on = glue(o), R = R0('vl25' + li), F0 = F0of(P), B = o.map(S => ({ S, L: bbS(S) })).filter(b => b.S.pts && b.S.pts.length && !b.S.par && !b.S.emit);
    const nap = S => [dec(mix(S.col, '#ffffff', 0.22), { op: 0.18 }), dec(shade(S.col, 0.88), { op: 0.13 })];
    B.forEach(({ S, L }) => { const w = L[1] - L[0], h = L[3] - L[2], d = L[5] - L[4];
      if (li === 2 && S.pts.length % 6 === 0 && w > 50 && w < 60 && d > 60) { const [D1, D2] = nap(S), WL = dec(shade(S.col, 0.7), { op: 0.8 }), WS = dec(shade(S.col, 0.55), { op: 0.4 });
        caps(S, 2).forEach(F => velvet(D1, D2, F, R, 4)); sides(S, 3).forEach(F => { if (F.n[2] > 0.7) velvet(D1, D2, F, R, 2); }); ringL(WL, S, 4, 6, 0.7, 0.6); ringL(WS, S, 3, 6, 0.4, 0); on(S, [D1, D2, WS, WL]); return; }
      if (li === 2 && Math.abs(w - 24) < 3 && Math.abs(h - 24) < 3) { const [D1, D2] = nap(S), PG = dec(shade(S.col, 0.68), { op: 0.85 }), TC = shade(S.col, 0.82);
        caps(S, 2).forEach(F => { velvet(D1, D2, F, R, 3); outline(PG, F, 0.95, 0.55); }); caps(S, 1).forEach(F => outline(PG, F, 0.95, 0.55));
        const zf = L[5] - 3; [[L[0] + 2, L[2] + 2, 1], [L[1] - 2, L[2] + 2, 1], [L[0] + 2.4, L[3] - 2.4, 0], [L[1] - 2.4, L[3] - 2.4, 0]].forEach(([x, y, tl]) => { const T = [ball(x, y, zf, 1.1, TC, { k: 3, n: 8, noOut: 1 })];
          if (tl) T.push(solid({ ax: 'y', sh: 'el', c: [x, zf], a: 0.5, b: 0.5, n: 6, rings: [[y - 4.2, 0, 1.4], [y - 1.4, 0, 0.8], [y - 0.8, 0, 0.5]], col: TC, mat: 'fab', noOut: 1 })); on(S, T, [0, 0, 1]); }); on(S, [D1, D2, PG]); return; }
      if (S.col === F0 || S.col === shade(F0, 0.86) || S.col === mix(F0, '#ffffff', 0.09)) { const [D1, D2] = nap(S); sides(S, 6).forEach(F => { if (F.n[1] > -0.3 && Math.hypot(...sub(F.q[1], F.q[0])) > 6) velvet(D1, D2, F, R, 2); }); if (L[2] < 40) caps(S, 2).forEach(F => velvet(D1, D2, F, R, 2)); on(S, [D1, D2]); } });
    if (li === 1 || li === 3) { const rl = B.find(b => b.S.col === F0 && caps(b.S, 2).length && b.L[2] > 40); if (rl) {
      { const PD = dec(shade(F0, 0.62), { op: 0.7 }), PL = dec(mix(F0, '#ffffff', 0.25), { op: 0.4 }), BT = dec(shade(F0, 0.55)); caps(rl.S, 2).forEach(F => { const G = fr2(F), [W, H] = WH2(G);
        rep(14, i => { const a = i / 14 * 2 * PI, cx = Math.cos(a), cy = Math.sin(a); PD.line([G.at(cx * 1.4, cy * 1.4), G.at(cx * W * 0.44, cy * H * 0.44)], G.n, 0.35, 1); PL.line([G.at(Math.cos(a + 0.12) * 1.6, Math.sin(a + 0.12) * 1.6), G.at(Math.cos(a + 0.12) * W * 0.42, Math.sin(a + 0.12) * H * 0.42)], G.n, 0.3, 1); });
        spot(BT, G.at(0, 0), G.n, 1.5, 1.5, 0, 10); }); on(rl.S, [PD, PL, BT]); }
      if (li === 3) { const L = rl.L, x = (L[0] + L[1]) / 2, y = L[3] - 0.15, z = 6, yw = 0.35, c = Math.cos(yw), s = Math.sin(yw), Pt = (a, b, yy) => [x + a * c + b * s, yy, z - a * s + b * c];
        const CV = box(x, y, z, 13, 0.9, 17, '#7a2a2a', { r: 0.4, yaw: yw, mat: 'fab' }), PG1 = box(x, y + 0.9, z, 12, 0.8, 16, '#f4ecd8', { r: 0.3, yaw: yw, mat: 'fab' }), TX = dec('#8a8072', { op: 0.6 }), SP = dec('#c9bfa8', { op: 0.9 });
        SP.line([Pt(0, -8, y + 1.75), Pt(0, 8, y + 1.75)], Y3, 0.35); [-1, 1].forEach(sg => rep(7, i => { const b = -6 + i * 1.9; TX.line([Pt(sg * 1.2, b, y + 1.75), Pt(sg * (i === 6 ? 3.5 : 5.2), b, y + 1.75)], Y3, 0.28); }));
        on(rl.S, [CV, PG1, TX, SP]); } } } };
  N.chester25V = S => chesWrap(S, velTex, leaBase);

  // LIV-010: grey metal folding chair with a scratched pine seat (grain, knots, carved heart, water ring), back slat painted teal and chipped down to the wood
  // with a star sticker, rust spots + scuffs on the legs, black rubber feet (one missing), red gingham pillow tied to the back posts with bows
  const foldTex = (o, P) => { const on = glue(o), R = R0('fd25'), B = o.filter(S => S && S.pts && S.pts.length && !S.par).map(S => ({ S, L: bbS(S) }));
    let feet = 0; B.forEach(({ S, L }) => { const w = L[1] - L[0], h = L[3] - L[2], d = L[5] - L[4];
      if (S.mat === 'wood' && h < 5) { const G1 = dec('#8e6a3e', { op: 0.5 }), G2 = dec('#e2c08e', { op: 0.4 }), KN = dec('#6b4a26', { op: 0.7 }), SC = dec('#f2deb8', { op: 0.6 }), CV = dec('#5a3a1c', { op: 0.75 }), WR = dec('#7a5a34', { op: 0.35 });
        S.faces.forEach(F => { if (bigF(F, 6)) grain(G1, G2, F, R, 1.1, KN); });
        S.faces.filter(F => F.n[1] > 0.9 && bigF(F, 200)).forEach(F => { const G = fr2(F); rep(7, () => { const a = (R() - 0.5) * 30, b = (R() - 0.5) * 28, th = R() * PI, l = 2 + R() * 5; SC.line([G.at(a, b), G.at(a + Math.cos(th) * l, b + Math.sin(th) * l)], G.n, 0.22); });
          CV.line(rep(17, i => { const t = i / 16 * 2 * PI; return G.at(10 + 1.8 * 16 * Math.pow(Math.sin(t), 3) / 16 * 1.6, -10 + (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) / 16 * 2.6); }), G.n, 0.3);
          CV.line([G.at(7.4, -7.6), G.at(8.4, -7.6), G.at(7.9, -7.6), G.at(7.9, -6.2)], G.n, 0.25); CV.line([G.at(11.6, -6.2), G.at(11.6, -7.6), G.at(12.6, -7.6)], G.n, 0.25);
          WR.line(rep(21, i => { const t = i / 20 * 2 * PI * 0.92; return G.at(-11 + Math.cos(t) * 3, -10 + Math.sin(t) * 3); }), G.n, 0.45); });
        on(S, [G1, G2, KN, SC, CV, WR]); return; }
      if (S.mat === 'wood') { S.col = '#4f8f8a'; S.mat = 'paint'; const CH = dec('#c49a62'), CG = dec('#8e6a3e', { op: 0.5 }), PE = dec('#3b6f6b', { op: 0.6 }), ST = dec('#f2c94c'), SL = dec('#fff3b0', { op: 0.8 });
        S.faces.forEach(F => { if (!bigF(F, 40)) return; const G = fr2(F), P2 = shrinkP(G.P, 0.86), E = ext2(P2); rep(6, () => { const q = [(R() - 0.5) * 2 * E, (R() - 0.5) * 2 * E]; if (!inP(P2, q)) return; const rx = 0.8 + R() * 2.2, ry = 0.5 + R() * 1.1, th = R() * PI;
            spot(PE, G.at(q[0], q[1]), G.n, rx + 0.35, ry + 0.35, th, 9); spot(CH, G.at(q[0], q[1]), G.n, rx, ry, th, 9); CG.line([G.at(q[0] - rx * 0.7, q[1]), G.at(q[0] + rx * 0.7, q[1])], G.n, 0.15); }); });
        const bf = S.faces.filter(F => F.n[2] > 0.9 && bigF(F, 100))[0]; if (bf) { const G = fr2(bf), c = [11, 2]; ST.poly(rep(10, i => { const a = -PI / 2 + i / 10 * 2 * PI, r = i % 2 ? 1.1 : 2.6; return G.at(c[0] + Math.cos(a) * r, c[1] - Math.sin(a) * r); }), G.n); spot(SL, G.at(c[0] - 0.5, c[1] + 0.6), G.n, 0.6, 0.4, 0, 6); }
        on(S, [PE, CH, CG, ST, SL]); return; }
      if (S.mat === 'metal') { const RU = dec('#9a5a2e', { op: 0.55 }), RL = dec('#c9874a', { op: 0.45 }), SF = dec('#b9bec4', { op: 0.5 });
        sides(S, 2).forEach(F => { if (!bigF(F, 3) || R() < 0.55) return; const G = fr2(F), [W, H] = WH2(G); rep(2, k => { const b = (R() - 0.5) * H * 0.8; spot(k ? RL : RU, G.at(0, b), G.n, Math.min(W * 0.4, 0.5), 0.6 + R() * 1.2, 0, 6); }); if (R() < 0.4) SF.line([G.at(0, -H * 0.3), G.at(0, -H * 0.3 + 2.4)], G.n, Math.min(W * 0.3, 0.35)); });
        on(S, [RU, RL, SF]);
        if (L[2] < 0.5 && w < 5 && h > 30) { feet++; if (feet !== 3) { const cx = (L[0] + L[1]) / 2, cz = (L[4] + L[5]) / 2; on(S, [cyl(cx, 0, cz, w / 2 + 0.45, 1.8, '#242428', { n: 8, mat: 'pl' })]); } }
        if (L[2] > 30 && w < 5 && h > 30) { const cx = (L[0] + L[1]) / 2, cz = (L[4] + L[5]) / 2, pc = P.a, sg = Math.sign(cx); on(S, [ball(cx, 43, cz + 0.4, 1.5, pc, { k: 3, n: 8, mat: 'fab' }), ball(cx - sg * 0.4, 43.6, cz + 1.6, 1.1, pc, { sx: 1.5, sy: 0.6, k: 3, n: 8, mat: 'fab' }),
          solid({ ax: 'y', sh: 'el', c: [cx + sg * 0.6, cz + 1.4], a: 0.45, b: 0.45, n: 6, rings: [[37.5, 0, 1], [42.4, 0, 1]], col: shade(pc, 0.9), mat: 'fab', noOut: 1 })]); } return; }
      if (S.col === P.a) { S.col = '#c8393b'; const GW = dec(mix(S.col, '#ffffff', 0.85), { op: 0.5 }), GD = dec(shade(S.col, 0.7), { op: 0.35 }), ED = dec(shade(S.col, 0.6), { op: 0.6 });
        S.faces.forEach(F => { if (!bigF(F, 3)) return; hatch(GW, F, 0, 3.4, 1.5, { sh: 0.97 }); hatch(GW, F, PI / 2, 3.4, 1.5, { sh: 0.97 }); hatch(GD, F, 0, 3.4, 0.25, { sh: 0.97, ph: 1.7 }); });
        caps(S, 2).forEach(F => outline(ED, F, 0.95, 0.4)); on(S, [GW, GD, ED]); } }); };
  N.fold25 = S => { const B = N.rchair(S), D = Object.assign({}, B); D.build = P => { const o = B.build(P); foldTex(o, P); return o; }; return D; };

  // LIV-030: mustard wool tweed (fine weave + rust/cream/olive flecks), self piping on seat, back cushion, rolls and wing edges, walnut tapered legs with brass ferrules,
  // walnut rail + arm discs, rust knit throw over the right arm
  const wingGlue = (o, col) => { const B = o.filter(S => S && S.pts && S.pts.length).map(S => ({ S, L: bbS(S) })).filter(b => !b.S.par);
    B.filter(b => b.S.col === col && b.L[2] > 50 && b.L[1] - b.L[0] < 26).forEach(w => { const r = B.find(b => b !== w && b.S.col === col && Math.abs(b.L[3] - w.L[2]) < 1.5 && Math.sign(b.L[0] + b.L[1]) === Math.sign(w.L[0] + w.L[1])); if (r) w.S.par = r.S; }); };
  const wingTex = (o, P, li) => { thrFix(o, P); const on = glue(o), R = R0('wg25' + (li == null ? 'm' : li)), B = roles(o, P), legC = (B.find(b => b.r === 'leg') || {}).S;
    const mc = legC ? legC.col : null, WAL = '#6b4426';
    B.forEach(({ S, L, r }) => {
      if (r === 'leg' || r === 'rail') { S.col = WAL; S.mat = 'wood'; S.shine = 0; const G1 = dec('#3e2614', { op: 0.5 }), G2 = dec('#9a6a42', { op: 0.4 }); S.faces.forEach(F => { if (bigF(F, r === 'rail' ? 10 : 2) && Math.abs(F.n[1]) < 0.5) grain(G1, G2, F, R, r === 'rail' ? 0.9 : 0.7); }); on(S, [G1, G2]);
        if (r === 'leg') { const cx = (L[0] + L[1]) / 2, cz = (L[4] + L[5]) / 2; on(S, [cyl(cx, -0.3, cz, (L[1] - L[0]) * 0.36, 2.2, '#d9a84a', { n: 8, shine: 1, mat: 'metal' })]); } return; }
      if (!UPH[r]) return;
      const W1 = dec(mix(S.col, '#ffffff', 0.3), { op: 0.28 }), W2 = dec(shade(S.col, 0.78), { op: 0.3 }), F1 = dec('#a04a2a', { op: 0.32 }), F2 = dec('#fff3d6', { op: 0.35 }), F3 = dec('#6a6a2a', { op: 0.28 }), WL = dec(shade(S.col, 0.7), { op: 0.75 }), Ls = [W1, W2, F1, F2, F3, WL];
      S.faces.forEach(F => { if (!bigF(F, 6)) return; hatch(W1, F, PI / 4, 1.2, 0.22, { sh: 0.98 }); hatch(W2, F, -PI / 4, 1.2, 0.22, { sh: 0.98 }); fleck(F1, F2, F, R, 0.05, 0.22); fleck(F3, F2, F, R, 0.03, 0.2); });
      if (r === 'seat') { ringL(WL, S, 4, 6, 0.55, 0.6); const CR = dec(shade(S.col, 0.82), { op: 0.22 }); caps(S, 2).forEach(F => crease(CR, F, R, 2, 26, 26, 6)); Ls.push(CR); }
      if (r === 'back' && S.pts.length % 5 === 0) ringL(WL, S, 3, 5, 0.55, 0);
      if (r === 'roll' && S.pts.length % 4 === 0) { ringL(WL, S, 0, 4, 0.45, 0); ringL(WL, S, 3, 4, 0.45, 0); }
      if (r === 'slab' && L[1] - L[0] < 30) S.faces.forEach(F => { if (F.cap && Math.abs(F.n[2]) > 0.8) outline(WL, F, 0.94, 0.5); });
      on(S, Ls); });
    o.forEach(S => { if (S && S.par && !S.emit && S.mat === 'metal' && S.col === mc) { S.col = shade(WAL, 1.1); S.mat = 'wood'; S.shine = 0; } });
    if (li == null) armThrow(o, B, 1, '#a24a2c', 1);
    wingGlue(o, P.a); };
  N.wing25 = S => rsWrap(S, wingTex);

  // rsofa: split the single back layer (back slab + left arm) for every rsofa row (YRD-046, CLB-016/036/056/076/096 ...); wrappers above see 2 layers and keep them
  { const rs0 = N.rsofa; N.rsofa = S => { const D = rs0(S); if (D.layers && D.layers.length === 1) D.layers = splitL(D); return D; }; }

  // ======================= BATCH 8: LIV-013 cardboard footrest, LIV-050 velvet swivel papasan, LIV-054 felt & birch pet tree (rebuilt) =======================
  const cylPt = (cx, cz, r, a, y, k) => [[cx + Math.cos(a) * (r + (k || 0.06)), y, cz + Math.sin(a) * (r + (k || 0.06))], [Math.cos(a), 0, Math.sin(a)]];
  const ringD = (D, cx, cz, r, y, w, m, a0, a1) => { m = m || 28; const A = a0 == null ? 0 : a0, B2 = a1 == null ? 2 * PI : a1, pts = [], nn = []; rep(m + 1, i => { const [p, n] = cylPt(cx, cz, r, A + (B2 - A) * i / m, y); pts.push(p); nn.push(n); }); D.line(pts, nn, w); };
  // LIV-013: corrugated flutes, flap seams, silver duct tape (crinkles, torn ends), THIS SIDE UP arrows, red FRAGILE stamp, shipping label + barcode,
  // hand holes, crushed corner patched with tape, coffee ring, water-stained bottom, marker 'LIVING RM', folded fleece blanket + TV remote on top
  N.box25 = S => ({ w: 60, d: 46, build: P => { const CB = '#c49a62', o = [], on = glue(o), R = R0('bx25'), W = 28, H = 28, Dz = 21, E = 0.07;
    const BX = box(0, 0, 0, 56, H, 42, CB, { r: 1 }); o.push(BX);
    const BF = { f: (u, v) => [u, v, Dz + E], b: (u, v) => [-u, v, -Dz - E], r: (u, v) => [W + E, v, -u], l: (u, v) => [-W - E, v, u], t: (u, w) => [u, H + E, w] }, BN = { f: [0, 0, 1], b: [0, 0, -1], r: [1, 0, 0], l: [-1, 0, 0], t: [0, 1, 0] };
    const fp = (D, s, Q) => D.poly(Q.map(q => BF[s](q[0], q[1])), BN[s]), fl = (D, s, Q, w, tp) => D.line(Q.map(q => BF[s](q[0], q[1])), BN[s], w, tp);
    const FLU = dec(shade(CB, 0.86), { op: 0.35 }), FLL = dec(mix(CB, '#ffffff', 0.25), { op: 0.25 }); BX.faces.forEach(F => { if (F.cap || Math.abs(F.n[1]) > 0.5 || !bigF(F, 60)) return; hatch([FLU, FLL], F, PI / 2, 1.1, 0.18, { sh: 0.99 }); });
    const SEAM = dec('#6b4a26', { op: 0.75 }), FOLD = dec(shade(CB, 0.8), { op: 0.6 }); fl(SEAM, 't', [[-27, 0], [27, 0]], 0.5); [['f', 20], ['b', 20], ['r', 15], ['l', 15]].forEach(([s, a]) => fl(FOLD, s, [[-a - 6, 26.6], [a + 6, 26.6]], 0.3));
    const TP = dec('#aeb4ba'), TL = dec('#e6ebee', { op: 0.6 }), TD = dec('#6f767c', { op: 0.55 });
    const tape = (s, Q, cr) => { fp(TP, s, Q); const [a, b, c, d] = Q; rep(cr, i => { const t = (i + 0.5) / cr, p0 = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t], p1 = [d[0] + (c[0] - d[0]) * t, d[1] + (c[1] - d[1]) * t]; fl(i % 2 ? TL : TD, s, [p0, [(p0[0] + p1[0]) / 2 + (R() - 0.5) * 0.8, (p0[1] + p1[1]) / 2], p1], 0.14); }); fl(TL, s, [d, c], 0.22); };
    tape('t', [[-28, -2.7], [28, -2.7], [28, 2.7], [-28, 2.7]], 46);
    tape('r', [[-2.7, 28], [2.7, 28], [2.7, 19.5], [1.3, 20.6], [0, 19], [-1.4, 20.4], [-2.7, 19.2]].slice(0, 4).concat([]), 6); fp(TP, 'r', [[2.7, 19.5], [1.3, 20.6], [0, 19], [-1.4, 20.4], [-2.7, 19.2], [-2.7, 21], [2.7, 21]]);
    tape('l', [[-2.7, 28], [2.7, 28], [2.7, 20], [-2.7, 20]], 6); fp(TP, 'l', [[2.7, 20], [1.6, 18.8], [0.2, 20.2], [-1.2, 18.7], [-2.7, 19.6], [-2.7, 21], [2.7, 21]]);
    // crushed corner (front right top) + tape X over it
    const DN = dec(shade(CB, 0.72), { op: 0.45 }), DC = dec('#6b4a26', { op: 0.5 }); fp(DN, 'f', [[20, 28], [28, 28], [28, 19], [24, 22.5]]); fl(DC, 'f', [[20.5, 27.6], [24.2, 22.8], [27.6, 19.6]], 0.3); fl(DC, 'f', [[23, 27.6], [25.2, 24.6], [27.6, 23.6]], 0.22); fp(DN, 't', [[20, 21], [28, 21], [28, 15], [23.5, 18]]); fl(DC, 't', [[21, 20.6], [27.6, 15.6]], 0.25);
    tape('f', [[15.5, 25.6], [17.4, 27.8], [27.8, 18.4], [25.9, 16.2]], 14); tape('f', [[17, 17.4], [27.6, 26.8], [26.2, 28], [15.6, 18.8]], 14);
    // THIS SIDE UP arrows + text, shipping label + barcode, hand holes, FRAGILE stamp, marker
    const INK = dec('#3a2a1c', { op: 0.85 }); [-17, -9].forEach(x => { fl(INK, 'f', [[x, 14], [x, 21.5]], 0.75); fp(INK, 'f', [[x - 2, 21], [x + 2, 21], [x, 24]]); }); rep(8, i => fl(INK, 'f', [[-20 + i * 1.6, 11.6], [-19.1 + i * 1.6, 11.6]], 0.55));
    const LB = dec('#f6f2e6'), BC = dec('#1f1f22'), LT = dec('#8a8a8e', { op: 0.8 }), LR = dec('#d9483b'); fp(LB, 'f', [[-6, 4], [10, 4], [10, 15], [-6, 15]]); fp(LR, 'f', [[-6, 13.6], [10, 13.6], [10, 15], [-6, 15]]);
    let bx = -5; while (bx < 3) { const w = 0.15 + R() * 0.45; fp(BC, 'f', [[bx, 5], [bx + w, 5], [bx + w, 9], [bx, 9]]); bx += w + 0.2 + R() * 0.35; } rep(3, i => fl(LT, 'f', [[-5, 11.8 - i * 1.1], [8.5 - i * 1.6, 11.8 - i * 1.1]], 0.4)); fp(BC, 'f', [[4.4, 5], [9, 5], [9, 9.6], [4.4, 9.6]]); fp(LB, 'f', [[5.4, 6], [8, 6], [8, 8.6], [5.4, 8.6]]);
    const HO = dec('#2a1a0e'), HR = dec(mix(CB, '#ffffff', 0.3), { op: 0.7 }); ['r', 'l'].forEach(s => { const Q = rep(14, i => { const a = i / 14 * 2 * PI, c = Math.cos(a), sn = Math.sin(a); return [c * 4.6 + Math.sign(c) * 1.4, 20.5 + sn * 1.6]; }); fp(HO, s, Q); fl(HR, s, Q.slice(7).concat([Q[0]]), 0.3); });
    const FR = dec('#c8393b', { op: 0.85 }); fl(FR, 'r', [[-11, 6], [9, 6], [9, 14], [-11, 14], [-11, 6]], 0.55); rep(7, i => { const x = -9.4 + i * 2.6; fl(FR, 'r', [[x, 8.2], [x, 11.8]], 0.7); fl(FR, 'r', [[x, 11.8], [x + 1.3, 11.8]], 0.6); if (i % 2) fl(FR, 'r', [[x, 10], [x + 1, 10]], 0.5); });
    fl(FR, 'r', [[11.5, 14], [14.5, 14], [13.6, 10.5], [12.4, 10.5], [11.5, 14]], 0.4); fl(FR, 'r', [[13, 10.5], [13, 7.4]], 0.4); fl(FR, 'r', [[11.8, 7.2], [14.2, 7.2]], 0.4);
    const MK = dec('#1a1a1e', { op: 0.85 }); rep(9, i => { const x = -14 + i * 3.1; fl(MK, 'b', [[x, 15 + (i % 2) * 0.6], [x + 1.2, 18.5 + (i % 3) * 0.3], [x + 2.2, 15.4]], 0.55, 1); }); fl(MK, 'b', [[-15, 13.2], [14, 13.6]], 0.4, 1);
    const WS = dec(shade(CB, 0.7), { op: 0.4 }); ['f', 'r', 'b'].forEach(s => { const a = s === 'f' || s === 'b' ? 28 : 21; fp(WS, s, [[-a, 0.2]].concat(rep(13, i => [-a + i * 2 * a / 12, 2.4 + Math.sin(i * 1.7) * 0.9]), [[a, 0.2]])); });
    const CF = dec('#6b3f22', { op: 0.5 }); fl(CF, 't', rep(23, i => { const a = i / 22 * 2 * PI * 0.9; return [15 + Math.cos(a) * 3.3, -12 + Math.sin(a) * 3.3]; }), 0.5);
    on(BX, [FLU, FLL, WS, FOLD, SEAM, DN, DC, TP, TD, TL, INK, LB, LR, BC, LT, HO, HR, FR, MK, CF]);
    // fleece blanket folded on the lid + remote on it
    const FC = '#7fa8cf', BL = box(-8, H, 5, 30, 3.2, 24, FC, { r: 1.4, bev: 1.2, soft: 1, mat: 'fab' }), FW = dec('#ffffff', { op: 0.75 }), FD = dec(shade(FC, 0.78), { op: 0.6 });
    on(BX, [BL]); caps(BL, 2).forEach(F => { dots(FW, F, 4.2, 0.55, { sh: 0.86, stag: 1, m: 5 }); const G = fr2(F); FD.line([G.at(-14, 2), G.at(14, 2.5)], G.n, 0.35); }); sides(BL, 1).forEach(F => { if (F.n[2] > 0.7) wavy(FD, F, (t, G) => { const [Wd] = WH2(G); return [-Wd / 2 + Wd * t, Math.sin(t * 20) * 0.4]; }, 24, 0.3); });
    const RM = box(-4, H + 3.2, 0, 4.4, 1.5, 12, '#2a2b30', { r: 1, yaw: 0.45, mat: 'pl' }), RB = dec('#d9483b'), RG = dec('#9aa1a6'); on(BL, [FW, FD, RM]);
    { const c = Math.cos(0.45), s = Math.sin(0.45), Pt = (a, b) => [-4 + a * c + b * s, H + 4.78, -a * s + b * c]; spot(RB, Pt(0, -4), Y3, 0.7, 0.7, 0, 8); rep(6, i => spot(RG, Pt(i % 2 ? 0.9 : -0.9, -1 + Math.floor(i / 2) * 1.6), Y3, 0.45, 0.4, 0, 6)); on(RM, [RB, RG]); }
    return o; } });

  // LIV-050: black + brass swivel base, rattan bowl (diagonal weave, horizontal binding bands, wrapped rim), deep velvet cushion with radial pleats, centre + ring buttons and a welt,
  // piped velvet back pillow with channels, a gold tassel hanging off the rim
  N.papasan25 = S => ({ w: 84, d: 80, round: 1, act: 'sit', seats: [{ x: 0, z: 6, h: 40 }], build: P => { const V = P.a, RT = '#c99a5a', BK = '#2c2d31', BR = '#d9a84a', o = [], on = glue(o), R = R0('pp25');
    o.push(cyl(0, 0, 0, 22, 3, BK, { n: 22, mat: 'metal', rg: [[0, 0, 1], [2, 0, 1], [3, 0, 0.88]] }), cyl(0, 3, 0, 8, 2.4, BR, { n: 16, mat: 'metal', shine: 1 }), cyl(0, 5.4, 0, 3.4, 8, BK, { n: 10, mat: 'metal' }), cyl(0, 13.4, 2, 12, 2.6, BR, { n: 16, mat: 'metal', shine: 1 }));
    const BW = cyl(0, 16, 2, 38, 22, RT, { n: 28, rz: 34, rg: [[0, 0, 0.32], [8, 0, 0.72], [16, 0, 0.94], [22, 0, 1]], mat: 'wood' }), RIM = arcW(0, 36, 2, 39, 35, 2.4, 2.4, 0, 2 * PI, shade(RT, 0.8), { n: 28, mat: 'wood' });
    const CU = ball(0, 32, 4, 33, V, { sy: 0.32, sz: 0.85, k: 6, n: 24, soft: 1, shine: 0, mat: 'fab' }), PL = pillowZ(0, 40, -18, 46, 22, 12, shade(V, 1.08), { mat: 'fab', soft: 1 });
    o.push(BW); on(BW, [RIM, CU]); on(CU, [PL]);
    const W1 = dec(shade(RT, 0.72), { op: 0.55 }), W2 = dec(mix(RT, '#fff1d0', 0.35), { op: 0.5 }), BD = dec(shade(RT, 0.62), { op: 0.7 });
    BW.faces.forEach(F => { if (F.cap || !bigF(F, 6)) return; hatch(W1, F, PI / 4, 1.8, 0.5, { sh: 0.98 }); hatch(W2, F, -PI / 4, 1.8, 0.5, { sh: 0.98, ph: 0.9 }); });
    [21, 25.5, 30].forEach(y => { const t = (y - 16) / 22, k = t < 0.36 ? 0.32 + (0.72 - 0.32) * t / 0.36 : t < 0.73 ? 0.72 + 0.22 * (t - 0.36) / 0.37 : 0.94 + 0.06 * (t - 0.73) / 0.27; const pts = [], nn = []; rep(49, i => { const a = i / 48 * 2 * PI; pts.push([Math.cos(a) * 38 * k * 1.012, y, 2 + Math.sin(a) * 34 * k * 1.012]); nn.push([Math.cos(a), -0.3, Math.sin(a)]); }); BD.line(pts, nn, 0.8); });
    const RB1 = dec(shade(RT, 0.6), { op: 0.7 }); RIM.faces.forEach(F => { if (bigF(F, 1)) hatch(RB1, F, PI / 2.6, 0.9, 0.22, { sh: 0.99 }); });
    on(BW, [W1, W2, BD]); on(RIM, [RB1]);
    // cushion: surface point on the ellipsoid top
    const ca = 33, cb = 28.05, cc = 10.56, cy0 = 32 + cc, sp = (x, z, k) => { const e = 1 - (x / ca) ** 2 - ((z - 4) / cb) ** 2, y = cy0 + cc * Math.sqrt(Math.max(0, e)); const n = nz([x / ca / ca, (y - cy0) / cc / cc, (z - 4) / cb / cb]); return [add([x, y, z], mul(n, k || 0.1)), n]; };
    const [D1, D2] = [dec(mix(V, '#ffffff', 0.22), { op: 0.2 }), dec(shade(V, 0.86), { op: 0.18 })], PLT = dec(shade(V, 0.68), { op: 0.55 }), PLL = dec(mix(V, '#ffffff', 0.25), { op: 0.35 }), BTN = dec(shade(V, 0.5)), BTH = dec(mix(V, '#ffffff', 0.4), { op: 0.7 }), WL = dec(shade(V, 0.7), { op: 0.8 });
    CU.faces.forEach(F => { if (F.n[1] > 0.5 && bigF(F, 20)) velvet(D1, D2, F, R, 1); });
    rep(8, i => { const a = i / 8 * 2 * PI + 0.2, bx = Math.cos(a) * 15, bz = 6 + Math.sin(a) * 12; const L = rep(9, j => sp(bx * j / 8, 6 + (bz - 6) * j / 8)); PLT.line(L.map(q => q[0]), L.map(q => q[1]), 0.5, 1); const L2 = rep(9, j => sp(bx * j / 8 + 0.8, 6 + (bz - 6) * j / 8 + 0.6)); PLL.line(L2.map(q => q[0]), L2.map(q => q[1]), 0.3, 1);
      const q = sp(bx, bz, 0.15); spot(BTN, q[0], q[1], 1.2, 1.2, 0, 8); spot(BTH, add(q[0], [-0.3, 0.05, -0.3]), q[1], 0.45, 0.4, 0, 6);
      const L3 = rep(7, j => { const t = a + PI / 8 + (j - 3) * 0.07, r = 1 + j * 0; return sp(Math.cos(t) * 22, 6 + Math.sin(t) * 17.6); }); PLT.line(L3.map(q2 => q2[0]), L3.map(q2 => q2[1]), 0.3, 1); });
    { const q = sp(0, 6, 0.15); spot(BTN, q[0], q[1], 1.8, 1.8, 0, 10); spot(BTH, add(q[0], [-0.4, 0.05, -0.4]), q[1], 0.6, 0.5, 0, 6); }
    if (CU.pts.length % 7 === 0) ringL(WL, CU, 3, 7, 0.75, 0.2); on(CU, [D1, D2, PLT, PLL, BTN, BTH, WL]);
    const PG = dec(shade(V, 0.62), { op: 0.85 }), CH = dec(shade(V, 0.8), { op: 0.45 }), [E1, E2] = [dec(mix(V, '#ffffff', 0.22), { op: 0.2 }), dec(shade(V, 0.86), { op: 0.16 })];
    PL.faces.forEach(F => { if (!bigF(F, 20)) return; if (F.cap) { velvet(E1, E2, F, R, 2); outline(PG, F, 0.93, 0.6); const G = fr2(F); [-11, 0, 11].forEach(a => CH.line([G.at(a, -8), G.at(a, 8)], G.n, 0.45, 1)); } }); on(PL, [E1, E2, PG, CH]);
    // gold tassel on the rim (front left)
    { const a = PI * 0.72, x = Math.cos(a) * 39.6, z = 2 + Math.sin(a) * 35.6, TS = '#e0b34a'; on(RIM, [ball(x, 35.4, z, 1.3, TS, { k: 3, n: 8, mat: 'fab' }), solid({ ax: 'y', sh: 'el', c: [x, z], a: 0.6, b: 0.6, n: 6, rings: [[29.2, 0, 1.8], [33.4, 0, 0.9], [35.6, 0, 0.5]], col: shade(TS, 0.9), mat: 'fab', noOut: 1 })]); }
    return o; } });

  // LIV-054: grey felt base + platforms with stitched edges, real birch logs (white bark, black lenticels, knot eyes, peeling curls), sisal-wrapped scratching section,
  // felt cave pod with a round entrance, felt beds on the platforms (paw-print), a step platform on a birch stump, felt leaves on the logs, a red felt ball on a cord
  N.cattree25 = S => ({ w: 70, d: 60, build: P => { const FE = P.a, BI = '#ece6da', o = [], on = glue(o), R = R0('ct25');
    const felt = (S0, d0) => { const F1 = dec(shade(S0.col, 0.86), { op: 0.35 }), F2 = dec(mix(S0.col, '#ffffff', 0.3), { op: 0.3 }); S0.faces.forEach(F => { if (bigF(F, 8)) fleck(F1, F2, F, R, d0 || 0.12, 0.25); }); return [F1, F2]; };
    const BASE = box(0, 0, 0, 66, 6, 56, FE, { r: 6, soft: 1, mat: 'fab' }); o.push(BASE);
    { const ST = dec(mix(FE, '#ffffff', 0.55), { op: 0.85 }); caps(BASE, 2).forEach(F => { const G = fr2(F), P2 = shrinkP(G.P, 0.9); P2.forEach((p, i) => { const q = P2[(i + 1) % P2.length], L = Math.hypot(q[0] - p[0], q[1] - p[1]), n = Math.max(1, Math.floor(L / 1.6)); rep(n, k => { const t0 = k / n, t1 = t0 + 0.55 / n; ST.line([G.at(p[0] + (q[0] - p[0]) * t0, p[1] + (q[1] - p[1]) * t0), G.at(p[0] + (q[0] - p[0]) * t1, p[1] + (q[1] - p[1]) * t1)], G.n, 0.3); }); }); }); on(BASE, felt(BASE).concat([ST])); }
    const logs = [[-20, 6, 5.5, 6, 34], [18, -8, 6, 6, 94], [22, 16, 4, 6, 50]], LG = logs.map(([x, z, r, y, h]) => cyl(x, y, z, r, h, BI, { n: 16, mat: 'wood' })); o.push(...LG);
    LG.forEach((S0, i) => { const [x, z, r, y, h] = logs[i], LN = dec('#2e2a26', { op: 0.85 }), LS = dec('#8a8278', { op: 0.5 }), PE = dec('#fffaf0', { op: 0.9 }), KN = dec('#3a332c');
      rep(Math.round(h * 0.9), () => { const a = R() * 2 * PI, yy = y + 1 + R() * (h - 2), [p, n] = cylPt(x, z, r, a, yy); spot(R() < 0.7 ? LN : LS, p, n, 0.6 + R() * 1.6, 0.16 + R() * 0.16, 0, 6); });
      rep(Math.max(1, Math.round(h / 30)), () => { const a = R() * 2 * PI, yy = y + 6 + R() * (h - 12), [p, n] = cylPt(x, z, r, a, yy); spot(KN, p, n, 1.8, 0.9, 0, 10); const [p2] = cylPt(x, z, r, a - 0.25, yy + 1.4), [p3] = cylPt(x, z, r, a + 0.25, yy + 1.4); KN.line([p2, add(p, [0, 0.4, 0]), p3], n, 0.35); });
      rep(Math.round(h / 16), () => { const a = R() * 2 * PI, yy = y + 4 + R() * (h - 8); ringD(PE, x, z, r + 0.05, yy, 0.45, 6, a, a + 0.7); });
      on(S0, [LS, LN, KN, PE]); });
    // sisal on the tall log
    const SI = cyl(18, 10, -8, 6.9, 44, '#cdb58a', { n: 18, mat: 'fab' }), SD = dec('#9a8456', { op: 0.7 }), SL = dec('#efe0bc', { op: 0.5 }); on(LG[1], [SI]); for (let y = 10.6; y < 54; y += 0.9) { const pts = [], nn = []; rep(25, i => { const a = i / 24 * 2 * PI, [p, n] = cylPt(18, -8, 6.9, a, y + i / 24 * 0.9); pts.push(p); nn.push(n); }); ((Math.round(y / 0.9)) % 2 ? SD : SL).line(pts, nn, 0.3); } on(SI, [SD, SL]);
    // cave pod on the short log, step platform on the stump, top platform on the tall log
    const POD = box(-20, 40, 5, 30, 24, 28, FE, { r: 10, soft: 1, mat: 'fab' }), PC = box(22, 56, 16, 24, 3, 24, shade(FE, 1.05), { r: 11, mat: 'fab' }), PT = cyl(18, 100, -8, 17, 4, shade(FE, 1.05), { n: 22, mat: 'fab' }); o.push(POD, PC, PT);
    { const HO = dec('#2a2420'), HR = dec(mix(FE, '#ffffff', 0.35)), STc = dec(mix(FE, '#ffffff', 0.6), { op: 0.85 }), zf = 5 + 14 + 0.08, Q = rep(20, i => { const a = i / 20 * 2 * PI; return [-20 + Math.cos(a) * 7.5, 51 + Math.sin(a) * 7.8, zf]; });
      HO.poly(Q, [0, 0, 1]); HR.line(Q.concat([Q[0]]), [0, 0, 1], 1.2); rep(20, i => { const a = (i + 0.3) / 20 * 2 * PI, b = (i + 0.7) / 20 * 2 * PI; STc.line([[-20 + Math.cos(a) * 9.4, 51 + Math.sin(a) * 9.7, zf], [-20 + Math.cos(b) * 9.4, 51 + Math.sin(b) * 9.7, zf]], [0, 0, 1], 0.3); }); on(POD, felt(POD).concat([HO, HR, STc])); }
    on(PC, felt(PC)); on(PT, felt(PT)); { const ST = dec(mix(FE, '#ffffff', 0.55), { op: 0.85 }); rep(36, i => { if (i % 2) return; ringD(ST, 18, -8, 17, 101.8, 0.3, 2, i / 36 * 2 * PI, (i + 0.8) / 36 * 2 * PI); }); on(PT, [ST]); }
    const BED = (x, y, z, w, d, c) => { const C = cush(x, y, z, w, 5, d, c, { mat: 'fab', soft: 1 }), PW = dec(shade(c, 0.78), { op: 0.7 }); caps(C, 2).forEach(F => { const G = fr2(F); spot(PW, G.at(0, -1), G.n, 2.4, 2, 0, 10); [[-2.6, 2], [-0.9, 3.3], [0.9, 3.3], [2.6, 2]].forEach(([a, b]) => spot(PW, G.at(a, b), G.n, 0.85, 0.95, 0, 8)); }); return [C, PW, ...felt(C, 0.1)]; };
    { const [C1, ...d1] = BED(18, 104, -8, 26, 24, shade(FE, 1.16)), [C2, ...d2] = BED(-20, 64, 5, 24, 22, shade(FE, 1.16)); on(PT, [C1]); on(C1, d1); on(POD, [C2]); on(C2, d2); }
    // felt leaves on the tall log
    [[0.3, 64, '#7aa35a'], [1.2, 74, '#d9a441'], [2.4, 60, '#c0603a'], [3.6, 82, '#7aa35a'], [4.9, 70, '#d9a441']].forEach(([a, y, c]) => { const L = dec(c), M = dec(shade(c, 0.7), { op: 0.8 }), [p0, n] = cylPt(18, -8, 6, a, y, 0.12), t = nz(cr(n, Y3)), up = [0, 1, 0];
      const Q = rep(12, i => { const s = i / 11 * 2 * PI, k = Math.sin(s / 2) ** 1.2; return add(p0, add(mul(up, -Math.cos(s / 2) * 3.4 + 3.4), mul(t, Math.sin(s) * 1.6 * (0.5 + 0.5 * k)))); }); L.poly(Q, n); M.line([p0, add(p0, mul(up, 6.4))], n, 0.25); on(LG[1], [L, M]); });
    // felt ball on a cord under the top platform
    { const CO = cyl(30, 82.4, 4, 0.35, 17.6, '#6b4a2a', { n: 5 }), BA = ball(30, 76, 4, 3.4, '#d9483b', { k: 4, n: 10, mat: 'fab', shine: 0 }), BS = dec('#f6e7c8', { op: 0.8 }); o.push(CO); on(CO, [BA]); spot(BS, [30, 81, 7.3], nz([0, 0.4, 1]), 0.9, 0.9, 0, 6); BS.line([[27.5, 78, 6.3], [32.5, 79.5, 6.3]], [0, 0, 1], 0.3); on(BA, [BS]); }
    return o; } });

  // ======================= BATCH 9-10: richer passes on 002 torch, 016 spool, 062 alabaster, chesterfields 107/108/109 =======================
  // chesterfield arm roles for armThrow (rolls live in arm layers 1 = left, 3 = right)
  const chesRA = (o, P) => { const F0 = F0of(P), B = o.filter(S => S && S.pts && S.pts.length && !S.par).map(S => ({ S, L: bbS(S) })), out = [];
    const rl = B.find(b => b.S.col === F0 && b.L[2] > 40 && b.L[1] - b.L[0] < 40), ab = B.find(b => b.S.col === F0 && b.L[2] < 30 && b.L[1] - b.L[0] < 30); if (rl) out.push(Object.assign({ r: 'roll' }, rl)); if (ab) out.push(Object.assign({ r: 'arm' }, ab)); return out; };
  const rollTop = (rl, z, yw) => { const L = rl.L, x = (L[0] + L[1]) / 2, y = L[3] - 0.15, c = Math.cos(yw || 0), s = Math.sin(yw || 0); return { x, y, Pt: (a, b, yy) => [x + a * c + b * s, yy == null ? y : yy, z - a * s + b * c] }; };
  // 107 + chunky oatmeal knit throw over the left arm
  const velX = (o, P, li) => { if (li === 1) armThrow(o, chesRA(o, P), -1, '#e2d3b8', 1); };
  // 108 + red tartan wool throw over the left arm, leather-bound book with gold bands + reading glasses on the right roll
  const leaX = (o, P, li) => { if (li === 1) { armThrow(o, chesRA(o, P), -1, '#8e2f2a', 1); const ab = chesRA(o, P).find(b => b.r === 'arm'); }
    if (li === 3) { const rl = chesRA(o, P).find(b => b.r === 'roll'); if (!rl) return; const on = glue(o), T = rollTop(rl, 8, -0.3), BK = box(T.x, T.y, 8, 11, 3.2, 15, '#3a2418', { r: 0.6, yaw: -0.3, mat: 'lea' }), PG = dec('#f1e6cc'), GD = dec('#e2b14a', { shine: 1 }), GL = dec('#2a2a2e'), LN = dec('#cfe8f2', { op: 0.5 });
      const yt = T.y + 3.25; [-1, 1].forEach(sg => rep(2, k => GD.line([T.Pt(-5.4, sg * (5 - k * 1.2), yt), T.Pt(5.4, sg * (5 - k * 1.2), yt)], Y3, 0.3))); spot(GD, T.Pt(0, 0, yt), Y3, 2, 2.4, 0, 10); [[0, 0, 1], [0, 0, -1], [1, 0, 0]].forEach(() => {});
      sides(BK, 1).forEach(F => { if (Math.abs(F.n[1]) < 0.3 && Math.hypot(...sub(F.q[1], F.q[0])) > 3) hatch(PG, F, 0, 0.5, 0.18, { sh: 0.8 }); });
      [-2.2, 2.2].forEach(a => { const c0 = T.Pt(a + 0.5, -2, yt + 0.1); spot(LN, c0, Y3, 1.6, 1.3, 0, 12); GL.line(rep(13, i => { const t = i / 12 * 2 * PI; return add(c0, [Math.cos(t) * 1.7, 0, Math.sin(t) * 1.4]); }), Y3, 0.3); }); GL.line([T.Pt(-0.6, -2, yt + 0.1), T.Pt(0.6, -2, yt + 0.1)], Y3, 0.25); GL.line([T.Pt(-3.8, -2, yt + 0.1), T.Pt(-4.6, 4, yt + 0.1)], Y3, 0.22); GL.line([T.Pt(4.4, -2, yt + 0.1), T.Pt(5.2, 4, yt + 0.1)], Y3, 0.22);
      on(rl.S, [BK]); on(BK, [PG, GD, LN, GL]); } };
  // 109 + sheepskin throw over the left arm, travertine tray with a lit candle + matches on the right roll
  const bouX = (o, P, li) => { if (li === 1) armThrow(o, chesRA(o, P), -1, '#f4efe4', 'fur');
    if (li === 3) { const rl = chesRA(o, P).find(b => b.r === 'roll'); if (!rl) return; const on = glue(o), T = rollTop(rl, 10, 0.2), TR = box(T.x, T.y, 10, 12, 1.4, 16, '#e3d6bf', { r: 1.5, yaw: 0.2, mat: 'stone' }), CA = cyl(T.x - 1.5, T.y + 1.4, 7, 2.6, 4.6, '#f7f2e8', { n: 12, mat: 'cer' }), MB = box(T.x + 2.2, T.y + 1.4, 13, 3.4, 1.2, 5, '#2a2a2e', { r: 0.4, yaw: 0.5 });
      const PO = dec('#b8a888', { op: 0.6 }), FL = dec('#ffcf7a', { emit: 1 }), FC = dec('#fff4d0', { emit: 1 }), WK = dec('#3a2a1c'), MS = dec('#c9a35a'); caps(TR, 2).forEach(F => fleck(PO, PO, F, R0('tr25'), 0.25, 0.3));
      const top = T.y + 6.05; spot(WK, [T.x - 1.5, top, 7], Y3, 0.25, 0.25, 0, 5); FL.poly(rep(10, i => { const a = i / 10 * 2 * PI; return [T.x - 1.5 + Math.sin(a) * 0.8, top + 1.6 - Math.cos(a) * 1.6 + (Math.cos(a) < 0 ? -Math.cos(a) * 1.2 : 0), 7.3]; }), [0, 0, 1]); spot(FC, [T.x - 1.5, top + 0.9, 7.35], [0, 0, 1], 0.4, 0.7, 0, 8);
      MS.line([[T.x + 1.2, T.y + 2.65, 12], [T.x + 3.4, T.y + 2.65, 14]], Y3, 0.6); on(rl.S, [TR]); on(TR, [PO, CA, MB]); on(CA, [WK, FL, FC]); on(MB, [MS]); } };
  const chesX = (lf, xf) => (o, P, li) => { lf(o, P, li); xf(o, P, li); };
  N.chester25V2 = S => chesWrap(S, chesX(velTex, velX), leaBase);
  N.chester25L2 = S => chesWrap(S, chesX(leaTex, leaX), leaBase);
  N.chester25B2 = S => chesWrap(S, chesX(bouTex, bouX), bouBase);

  // 062: amber + white veins wrapping round every stone (world-anchored so they run on across faces), cloudy inclusions, fine hairline cracks, warm inner-glow cores,
  // bronze patina + chisel marks on the base, felt pad + cord with an inline dimmer
  const AL62 = ['#fbe8c8', '#f7dcb6', '#fdeed6'];
  N.alab25b = texWrap('alab24', 'ala', {}, (o, P) => { const on = glue(o), R = R0('al25b');
    o.filter(S => S && S.pts && !S.par && AL62.includes(S.col)).forEach((S, i) => { const VA = dec('#d9a066', { op: 0.55 }), VW = dec('#ffffff', { op: 0.6 }), CK = dec('#c4a47c', { op: 0.45 }), CL = dec('#ffffff', { op: 0.45 }), GC = dec('#ffd9a0', { emit: 1, op: 0.35 });
      S.faces.forEach(F => { if (!bigF(F, 4)) return; hatch(VA, F, 0.35 + i * 0.4, 6.5, 0.32, { sh: 0.97, ph: i * 1.7 }); hatch(VW, F, -0.5 + i * 0.3, 9, 0.42, { sh: 0.97, ph: i * 2.3 }); fleck(CL, CL, F, R, 0.03, 0.9); if (R() < 0.12) wavy(CK, F, (t, G) => { const [W, H] = WH2(G); return [-W * 0.4 + W * 0.8 * t, (R() - 0.5) * 0.4 + Math.sin(t * 9) * 0.5]; }, 10, 0.18); });
      sides(S, 2).forEach(F => { if (F.n[2] > 0.6 && bigF(F, 20)) { const G = fr2(F); spot(GC, G.at(0, 0), G.n, 2.2, 3, 0, 10); } }); on(S, [GC, VA, VW, CL, CK]); });
    const base = o.filter(S => S && S.pts && !S.par && S.mat === 'metal').map(S => ({ S, L: bbS(S) })).sort((a, b) => (b.L[1] - b.L[0]) - (a.L[1] - a.L[0]))[0];
    if (base) { const PT = dec('#5f8a72', { op: 0.35 }), CH = dec('#4a321e', { op: 0.5 }), L = base.L, r = (L[1] - L[0]) / 2, cx = (L[0] + L[1]) / 2, cz = (L[4] + L[5]) / 2;
      base.S.faces.forEach(F => { if (bigF(F, 3)) fleck(PT, PT, F, R, 0.12, 0.45); }); rep(28, i => { const a = i / 28 * 2 * PI, [p, n] = cylPt(cx, cz, r - 0.2, a, (L[2] + L[3]) / 2); CH.line([add(p, [0, -0.8, 0]), add(p, [0, 0.8, 0])], n, 0.2); });
      const CD = dec('#2a2a2e'), DM = dec('#f4f2ee'), DK = dec('#9aa1a6'); const a0 = PI * 0.25, [p0] = cylPt(cx, cz, r, a0, L[2] + 0.6); CD.line([p0, add(p0, [3, -0.55, 3]), add(p0, [9, -0.55, 6]), add(p0, [14, -0.55, 12])], Y3, 0.6);
      const dm = add(p0, [9, -0.5, 6]); DM.poly([add(dm, [-1.6, 0, -1]), add(dm, [1.6, 0, -1]), add(dm, [1.6, 0, 1.4]), add(dm, [-1.6, 0, 1.4])], Y3); spot(DK, add(dm, [0, 0.05, 0.2]), Y3, 0.7, 0.7, 0, 8); on(base.S, [PT, CH, CD, DM, DK]); } });

  // 016: plywood ply lines + rust halos round the bolts, splinters, a tin-can succulent and a folded newspaper on the top, coasters stack
  N.spool25 = texWrap('spool22', 'spl', {}, (o, P) => { const on = glue(o), R = R0('sp25b');
    { const mg = o.filter(S => S && S.pts && !S.par && S.col === '#3f7fc8').map(S => ({ S, L: bbS(S) })).sort((a, b) => (b.L[1] - b.L[0]) * (b.L[3] - b.L[2]) - (a.L[1] - a.L[0]) * (a.L[3] - a.L[2])); mg.slice(1).forEach(b => { b.S.par = mg[0].S; }); }
    const B = o.filter(S => S && S.pts && !S.par).map(S => ({ S, L: bbS(S) }));
    const discs = B.filter(b => b.L[1] - b.L[0] > 80).sort((a, b) => b.L[3] - a.L[3]), top = discs[0]; if (!top) return;
    discs.forEach(({ S }) => { const PL = dec('#8a6438', { op: 0.45 }), PH = dec('#f0d29e', { op: 0.35 }); sides(S, 1).forEach(F => { if (Math.abs(F.n[1]) < 0.4) { hatch([PL, PH], F, 0, 0.9, 0.16, { sh: 0.99 }); } }); on(S, [PL, PH]); });
    const TY = top.L[3], RS = dec('#8a4a22', { op: 0.35 }), SPL = dec('#f4dcae', { op: 0.75 }); o.filter(S => S && S.mat === 'metal' && S.pts).forEach(S => { const L = bbS(S); if (Math.abs(L[3] - TY) < 2.5 && L[1] - L[0] < 5) spot(RS, [(L[0] + L[1]) / 2 + 0.6, TY + 0.06, (L[4] + L[5]) / 2 + 0.5], Y3, 2.1, 1.6, 0.4, 10); });
    rep(5, () => { const a = R() * 2 * PI, r = 44.6, [p, n] = cylPt(0, 0, r, a, TY - 1.5); SPL.line([p, add(p, [-Math.sin(a) * 2.2, 0.3, Math.cos(a) * 2.2])], n, 0.3); });
    const CN = cyl(-20, TY, -14, 4.2, 8, '#b9bec4', { n: 14, mat: 'metal' }), SO = dec('#4a3426'), LB = dec('#d9483b'), LW = dec('#f4ead2'), RB = dec('#8a8f94', { op: 0.6 }); spot(SO, [-20, TY + 8.06, -14], Y3, 3.8, 3.8, 0, 12);
    rep(14, i => { const a = i / 14 * 2 * PI; LB.line([[-20 + Math.cos(a) * 4.26, TY + 2.4, -14 + Math.sin(a) * 4.26], [-20 + Math.cos(a + 2 * PI / 14) * 4.26, TY + 2.4, -14 + Math.sin(a + 2 * PI / 14) * 4.26]], [Math.cos(a), 0, Math.sin(a)], 3.2); }); ringD(LW, -20, -14, 4.24, TY + 2.6, 0.6, 16, PI * 0.25, PI * 0.75); [1, 7.4].forEach(y => ringD(RB, -20, -14, 4.24, TY + y, 0.3, 20));
    const SU = [[0, 0, 2.6, '#6f9a6a'], [-1.8, 1.2, 1.8, '#86b07a'], [1.9, -1, 1.7, '#5f8a5a'], [0.6, 2, 1.4, '#9ac08a']].map(([dx, dz, r, c]) => ball(-20 + dx, TY + 7.8, -14 + dz, r, c, { sy: 0.75, k: 4, n: 10, mat: 'pl' }));
    const NP = box(14, TY, 18, 16, 0.9, 11, '#ece7dc', { r: 0.3, yaw: -0.35 }), NT = dec('#4a4a50', { op: 0.6 }), NH = dec('#1f1f22', { op: 0.85 }); { const c = Math.cos(-0.35), s2 = Math.sin(-0.35), Pt = (a, b) => [14 + a * c + b * s2, TY + 0.96, 18 - a * s2 + b * c]; NH.line([Pt(-6.5, -3.8), Pt(6.5, -3.8)], Y3, 1.1); rep(6, i => [-1, 1].forEach(sg => NT.line([Pt(sg > 0 ? 0.6 : -6.6, -1.6 + i * 0.95), Pt(sg > 0 ? 6.6 : -0.6, -1.6 + i * 0.95)], Y3, 0.3))); NT.line([Pt(0, -3), Pt(0, 4.8)], Y3, 0.2); }
    const CS = [0, 1, 2].map(i => cyl(24, TY + i * 0.9, -12 + i * 0.3, 3.6, 0.9, i % 2 ? '#b98a58' : '#c9a46a', { n: 14, mat: 'wood' }));
    on(top.S, [CN, NP, CS[0]]); on(CN, [SO, LB, LW, RB, ...SU]); on(NP, [NT, NH]); on(CS[0], [CS[1]]); on(CS[1], [CS[2]]); });

  // 002: dusty shade top, dead moth silhouette, fingerprint smudges, a live moth circling the light (fx)
  N.torch25 = S => { const B = N.torch24(S), D = Object.assign({}, B);
    D.fx = c => { const b = B.fx ? (B.fx(c) || {}) : {}, q = c.p(8, 136, 12), k = c.k;
      const m = '<g transform="translate(' + f1(q[0]) + ' ' + f1(q[1]) + ')"><g><animateMotion dur="5.2s" repeatCount="indefinite" path="M0 0C' + f1(16 * k) + ' ' + f1(-8 * k) + ' ' + f1(14 * k) + ' ' + f1(10 * k) + ' 0 ' + f1(6 * k) + 'S' + f1(-18 * k) + ' ' + f1(-10 * k) + ' 0 0"/><g transform="scale(' + f1(k * 0.7) + ')"><ellipse rx="0.8" ry="2" fill="#5a4a3a"/>'
        + ['-1', '1'].map(sg => '<path d="M0 -0.6C' + sg * 4 + ' -4 ' + sg * 5 + ' 0 ' + sg * 0.6 + ' 1Z" fill="#b8a88e" stroke="#6b5a46" stroke-width="0.3"><animateTransform attributeName="transform" type="scale" values="1 1;0.25 1;1 1" dur="0.14s" repeatCount="indefinite"/></path>').join('') + '</g></g></g>';
      return Object.assign({}, b, { front: (b.front || '') + m, bb: mergeBB(b.bb, [q[0] - 24 * k, q[1] - 16 * k, q[0] + 24 * k, q[1] + 16 * k]) }); };
    return D; };

  // ======================= BATCH 11: LIV-033 pouf (texture per colour), LIV-111 gilded rococo marble coffee table =======================
  // pouf ball: ball(0,0,0,33,{sy:.64}) -> ellipsoid centre y 21.12, rx = rz 33, ry 21.12; sp(th, ph) = surface point + normal
  const PF = { rx: 33, ry: 21.12, cy: 21.12 }, pfP = (th, ph, k) => { const c = Math.cos(ph), p = [PF.rx * c * Math.cos(th), PF.cy + PF.ry * Math.sin(ph), PF.rx * c * Math.sin(th)], n = nz([c * Math.cos(th) / PF.rx, Math.sin(ph) / PF.ry, c * Math.sin(th) / PF.rx]); return [add(p, mul(n, k == null ? 0.12 : k)), n]; };
  const pfL = (D, f, m, w, tp) => { const L = rep(m + 1, i => f(i / m)); D.line(L.map(q => q[0]), L.map(q => q[1]), w, tp); };
  const POUFK = { '#efe6d4': 'mac', '#1f6a4c': 'vel', '#2f4870': 'vel', '#a8592b': 'lea', '#b9a6e0': 'bou', '#d8a531': 'knit' };
  const hexRGB = h => { const n = parseInt(String(h).slice(1, 7), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const pfKind = c => { const q = hexRGB(c); let best = 'knit', bd = 1e9; Object.keys(POUFK).forEach(k => { const p = hexRGB(mix(k, '#ffffff', 0.1)), d = (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2; if (d < bd) { bd = d; best = POUFK[k]; } }); return best; };
  N.pouf25 = S => { const B = N.puffPouf(S), D = Object.assign({}, B);
    D.build = P => { const o = B.build(P), on = glue(o), R = R0('pf25'), c = P.a, kd = pfKind(c), BL = o[0], top = Math.PI / 2;
      for (let i = o.length - 1; i > 0; i--) { const L = bbS(o[i]); if (L[1] - L[0] < 4.5 && L[2] > 36 && L[2] < 39) o.splice(i, 1); }
      o.slice(1).forEach(S2 => { S2.par = BL; });
      const lo = -0.25, hi = 1.32, Ls = [];
      if (kd === 'knit' || kd === 'mac') { // chunky knit: vertical columns of V stitches (two zigzag strands per column) + purl ridge at the equator; macrame: diagonal cord lattice + knots
        const D1 = dec(shade(c, 0.72), { op: 0.7 }), D2 = dec(mix(c, '#ffffff', 0.35), { op: 0.6 }), D3 = dec(shade(c, 0.86), { op: 0.5 }); Ls.push(D1, D2, D3);
        if (kd === 'knit') { const cols = 30, rows = 11; rep(cols, i => { const t0 = i / cols * 2 * PI; [-1, 1].forEach(sg => pfL(sg < 0 ? D1 : D2, u => { const ph = lo + (hi - lo) * u, wob = ((u * rows) % 1 < 0.5 ? (u * rows) % 1 : 1 - (u * rows) % 1) * 2; return pfP(t0 + sg * (0.035 + wob * 0.05) * Math.cos(ph) ** -0.2, ph); }, rows * 4, 0.95)); });
          rep(3, j => pfL(D3, u => pfP(u * 2 * PI, -0.05 - j * 0.08), 96, 0.7)); }
        else { const n = 18; rep(n, i => [1, -1].forEach(sg => pfL(D2, u => { const ph = -0.3 + 1.5 * u; return pfP(i / n * 2 * PI + sg * u * 1.4, ph); }, 40, 0.8)));
          rep(n, i => rep(3, j => { const ph = -0.3 + 1.5 * (j + 0.5) / 3.1, th = i / n * 2 * PI + (j % 2 ? PI / n : 0) + 0.7 * (j + 0.5) / 3.1 * 0; const [p, nn] = pfP(th + 0.7 * ((j + 0.5) / 3.1) * 0, ph, 0.2); spot(D1, p, nn, 1.3, 1.1, 0, 8); spot(D2, add(p, mul(nn, 0.05)), nn, 0.6, 0.5, 0, 6); }));
          rep(n * 2, i => { const [p, nn] = pfP(i / (n * 2) * 2 * PI, -0.42, 0.1); D3.line([p, add(p, [0, -2.6, 0])], nn, 0.5); }); } }
      else if (kd === 'vel') { const D1 = dec(mix(c, '#ffffff', 0.25), { op: 0.22 }), D2 = dec(shade(c, 0.82), { op: 0.2 }), PL = dec(shade(c, 0.68), { op: 0.6 }); Ls.push(D1, D2, PL);
        rep(7, i => { const ph = R() * 0.9 - 0.1, ph2 = R() * 6; pfL(i % 2 ? D2 : D1, u => pfP(u * 2 * PI * 0.45 + ph2, ph + Math.sin(u * 7 + ph2) * 0.08), 30, 2 + R() * 2, 1); });
        rep(12, i => pfL(PL, u => pfP(i / 12 * 2 * PI + Math.sin(u * 3) * 0.05, top - 0.08 - u * 0.62), 12, 0.6, 1)); }
      else if (kd === 'lea') { const PA = dec(mix(c, '#ffe2b8', 0.3), { op: 0.25 }), FL = dec(shade(c, 0.75), { op: 0.28 }), SM = dec(shade(c, 0.55), { op: 0.8 }), ST = dec('#f2e2c0', { op: 0.85 }); Ls.push(PA, FL, SM, ST);
        rep(6, i => { const t0 = i / 6 * 2 * PI; pfL(SM, u => pfP(t0, -0.35 + (top - 0.06 + 0.35) * u), 24, 0.6); rep(18, k => { const ph = -0.3 + (top - 0.15 + 0.3) * k / 18; [-1, 1].forEach(sg => { const [a] = pfP(t0 + sg * 0.035 / Math.max(0.2, Math.cos(ph)), ph, 0.16), [b, nn] = pfP(t0 + sg * 0.035 / Math.max(0.2, Math.cos(ph)), ph + 0.045, 0.16); ST.line([a, b], nn, 0.3); }); }); });
        rep(4, () => { const th = R() * 2 * PI; pfL(PA, u => pfP(th + u * 0.8, 0.5 + Math.sin(u * 4) * 0.1), 12, 3, 1); }); rep(90, () => { const [p, nn] = pfP(R() * 2 * PI, -0.2 + R() * 1.4, 0.1); spot(FL, p, nn, 0.3, 0.25, 0, 5); }); }
      else { const D1 = dec(mix(c, '#ffffff', 0.55), { op: 0.65 }), D2 = dec(shade(c, 0.82), { op: 0.5 }); Ls.push(D1, D2);
        for (let ph = -0.3; ph < top - 0.1; ph += 0.085) { const n = Math.max(6, Math.round(Math.cos(ph) * 74)); rep(n, i => { const th = (i + (Math.round(ph / 0.085) % 2) * 0.5) / n * 2 * PI, [p, nn] = pfP(th, ph, 0.16); spot(i % 3 ? D1 : D2, p, nn, 0.7, 0.6, 0, 6); }); } }
      // welt round the equator, gathered centre button, little pull loop
      const WL = dec(shade(c, 0.66), { op: 0.85 }), WH = dec(mix(c, '#ffffff', 0.3), { op: 0.5 }), GA = dec(shade(c, 0.7), { op: 0.55 });
      pfL(WL, u => pfP(u * 2 * PI, 0, 0.3), 96, 1.1); pfL(WH, u => pfP(u * 2 * PI, 0.035, 0.32), 96, 0.35);
      rep(16, i => pfL(GA, u => pfP(i / 16 * 2 * PI, top - 0.02 - u * 0.28, 0.14), 6, 0.45, 1)); on(BL, Ls.concat([WL, WH, GA]));
      const LP = solid({ ax: 'x', sh: 'arc', c: [0, PF.cy - 0.6], a: 2.2, b: 2.8, th: 0.7, a0: PI, a1: PI * 2, n: 10, rings: [[PF.rx - 0.2, 0], [PF.rx + 0.8, 0]], col: shade(c, 0.7), mat: 'fab', noOut: 1 }); on(BL, [LP]);
      return o; };
    return D; };

  // LIV-111: marble polish glints, gold-leaf apron with carved C-scrolls + bead rows, fluted cabriole legs with acanthus knees, cut-crystal decanter + tumblers (facets, rim glints,
  // whisky surface), gilt title on the book, crystal bowl of sugared almonds
  const luxFix = o => { const B = o.filter(S => S && S.pts && S.pts.length && !S.par).map(S => ({ S, L: bbS(S) })), top = B.find(b => b.S.mat === 'cer' && Math.abs(b.L[3] - 40.8) < 0.8 && b.L[1] - b.L[0] > 100), ap = B.find(b => b.S.col === GOLD && Math.abs(b.L[2] - 28) < 0.6 && b.L[1] - b.L[0] > 100), rim = B.find(b => b.S.col === GOLD && Math.abs(b.L[2] - 35) < 0.5 && b.L[1] - b.L[0] > 110);
    if (top) { B.forEach(b => { if (b !== top && b.L[2] > 40.3) b.S.par = top.S; }); }
    if (ap) B.forEach(b => { if (b.S.col === GOLD && b !== ap && b !== rim && b.L[2] > 20 && b.L[3] < 36 && b.L[1] - b.L[0] < 14 && Math.max(Math.abs(b.L[0] + b.L[1]), Math.abs(b.L[4] + b.L[5])) > 40) b.S.par = ap.S; });
    B.forEach(b => { if (b.S.col === GOLD && b.L[2] > 2 && b.L[2] < 4 && b.L[3] > 29) { const y0 = b.L[2], k = (27.6 - y0) / (b.L[3] - y0); mvPts(b.S, p => [p[0], y0 + (p[1] - y0) * k, p[2]]); } }); };
  N.luxCoffeeF = S => { const B = N.luxCoffee(S), D = Object.assign({}, B); D.build = P => { const o = B.build(P); luxFix(o); return o; }; return D; };
  N.lux25 = texWrap('luxCoffeeF', 'lx', {}, (o, P) => { const on = glue(o), R = R0('lx25'), B = o.filter(S => S && S.pts && S.pts.length && !S.par).map(S => ({ S, L: bbS(S) }));
    const ap = B.find(b => b.S.col === GOLD && Math.abs(b.L[2] - 28) < 0.6 && b.L[1] - b.L[0] > 100);
    if (ap) { const SC = dec('#9a6a14', { op: 0.75 }), HL = dec('#fff1b0', { op: 0.6 }), BD = dec('#fff1b0', { op: 0.85 }), a = 54, b = 30, y0 = 28, y1 = 35, Pp = (t, y, k) => [[Math.cos(t) * (a + (k || 0.12)), y, Math.sin(t) * (b + (k || 0.12))], [Math.cos(t) * b, 0, Math.sin(t) * a].map((v, i, A) => v / Math.hypot(...A))];
      const ln = (D, f, m, w) => { const L = rep(m + 1, i => f(i / m)); D.line(L.map(q => q[0]), L.map(q => q[1]), w); };
      rep(14, i => { const t0 = i / 14 * 2 * PI, dt2 = 2 * PI / 14; ln(SC, u => Pp(t0 + dt2 * 0.1 + u * dt2 * 0.8, y0 + 3.5 + Math.sin(u * PI * 2) * 1.6), 14, 0.45); ln(HL, u => Pp(t0 + dt2 * 0.12 + u * dt2 * 0.76, y0 + 3.9 + Math.sin(u * PI * 2) * 1.6), 14, 0.25);
        [0.25, 0.75].forEach(f => { const [p, n] = Pp(t0 + dt2 * f, y0 + 3.5 + (f < 0.5 ? 1.6 : -1.6), 0.15); spot(SC, p, n, 1, 0.8, 0, 8); spot(HL, add(p, [0, 0.2, 0]), n, 0.4, 0.3, 0, 6); }); });
      [y0 + 0.8, y1 - 0.8].forEach(y => rep(90, i => { const [p, n] = Pp(i / 90 * 2 * PI, y, 0.14); spot(BD, p, n, 0.42, 0.42, 0, 6); })); on(ap.S, [SC, HL, BD]); }
    B.filter(b => b.S.col === GOLD && b.L[3] - b.L[2] > 20 && b.L[1] - b.L[0] < 8).forEach(({ S, L }) => { const FD = dec('#9a6a14', { op: 0.6 }), FH = dec('#fff1b0', { op: 0.5 }), cx = (L[0] + L[1]) / 2, cz = (L[4] + L[5]) / 2;
      rep(8, i => { const a = i / 8 * 2 * PI, k = (y) => { const t = (y - 3) / 28; return 2.8 * (t < 0.25 ? 0.9 - 0.28 * t / 0.25 : t < 0.64 ? 0.62 + 0.28 * (t - 0.25) / 0.39 : 0.9 + 0.7 * (t - 0.64) / 0.25); }; FD.line([5, 9, 13, 17, 20].map(y => [cx + Math.cos(a) * (k(y) + 0.06), y, cz + Math.sin(a) * (k(y) + 0.06)]), [Math.cos(a), 0, Math.sin(a)], 0.35); FH.line([5, 9, 13, 17, 20].map(y => [cx + Math.cos(a + 0.2) * (k(y) + 0.06), y, cz + Math.sin(a + 0.2) * (k(y) + 0.06)]), [Math.cos(a + 0.2), 0, Math.sin(a + 0.2)], 0.2); });
      rep(5, i => { const a = -PI / 2 + (i - 2) * 0.35 + (cz > 0 ? PI : 0) * 0, aa = Math.atan2(cz, cx) + (i - 2) * 0.45; FD.line([[cx + Math.cos(aa) * 4.2, 26.5, cz + Math.sin(aa) * 4.2], [cx + Math.cos(aa) * 3.4, 23, cz + Math.sin(aa) * 3.4]], [Math.cos(aa), 0, Math.sin(aa)], 0.5, 1); }); on(S, [FD, FH]); });
    const top = B.find(b => b.S.mat === 'cer' && Math.abs(b.L[3] - 40.8) < 0.8 && b.L[1] - b.L[0] > 100);
    if (top) { const GW = dec('#ffffff', { op: 0.55 }), GR = dec('#d9a84a', { op: 0.45 }); caps(top.S, 2).forEach(F => { const G = fr2(F); GW.line([G.at(-40, -14), G.at(-22, -20)], G.n, 1.2, 1); GW.line([G.at(26, 16), G.at(40, 10)], G.n, 0.8, 1); }); sides(top.S, 1).forEach(F => { if (Math.abs(F.n[1]) < 0.3) GR.line([F.q[0], F.q[1]].map(p => add(p, [0, 0.4, 0])), F.n, 0.25); }); on(top.S, [GW, GR]); }
    o.filter(S => S && S.pts && S.op != null && S.op < 0.6 && S.mat === 'cer').forEach(S => { const L = bbS(S), cx = (L[0] + L[1]) / 2, cz = (L[4] + L[5]) / 2, r = (L[1] - L[0]) / 2; if (r > 7 || L[3] - L[2] < 3) return; const FC = dec('#ffffff', { op: 0.6 }), FD = dec('#9ab8c8', { op: 0.45 });
      rep(10, i => { const a = i / 10 * 2 * PI; (i % 2 ? FD : FC).line([[cx + Math.cos(a) * (r * 0.92 + 0.05), L[2] + 0.6, cz + Math.sin(a) * (r * 0.92 + 0.05)], [cx + Math.cos(a) * (r * 0.98 + 0.05), L[2] + (L[3] - L[2]) * 0.55, cz + Math.sin(a) * (r * 0.98 + 0.05)]], [Math.cos(a), 0, Math.sin(a)], 0.28); });
      ringD(FC, cx, cz, r * 0.96, L[3] - 0.2, 0.3, 20); on(S, [FD, FC]); });
    o.filter(S => S && S.pts && S.col === '#b8692a').forEach(S => { const L = bbS(S), WS = dec('#e8a660', { op: 0.8 }); spot(WS, [(L[0] + L[1]) / 2 - 0.5, L[3] + 0.05, (L[4] + L[5]) / 2 - 0.4], Y3, (L[1] - L[0]) * 0.3, (L[5] - L[4]) * 0.22, 0, 10); on(S, [WS]); });
    const bk = o.filter(S => S && S.pts && S.pts.length && S.cv !== 0).map(S => ({ S, L: bbS(S) })).find(b => /^#[6-8]/.test(b.S.col) && b.L[3] - b.L[2] < 5 && b.L[1] - b.L[0] > 14 && b.L[2] > 40); if (bk) { const GT = dec('#f0c24a', { shine: 1 }); caps(bk.S, 2).forEach(F => { const G = fr2(F); GT.line([G.at(-5, 3), G.at(5, 3)], G.n, 0.6); GT.line([G.at(-4, 1.6), G.at(4, 1.6)], G.n, 0.3); spot(GT, G.at(0, -1.2), G.n, 1.6, 1.6, 0, 10); GT.line(rep(9, i => G.at(-6.5 + i * 0, 0)).slice(0, 0).concat([G.at(-6.6, -5), G.at(6.6, -5), G.at(6.6, 5.4), G.at(-6.6, 5.4), G.at(-6.6, -5)]), G.n, 0.25); }); on(bk.S, [GT]); } });

  // ---------- catalog edits ----------
  RD.SET25 = {
    'LIV-033': { spec: 'pouf25', note: 'A round floor pouf that squishes when you sit on it, with a piped welt round the middle, a gathered button on top and a little pull loop. Each colour has its own fabric: chunky cable knit, macram\u00e9 cord with knots and fringe, soft velvet, stitched leather panels or nubby boucl\u00e9.' },
    'LIV-111': { spec: 'lux25', note: 'A gilded rococo coffee table: an oval white marble top with polished glints over a gold-leaf apron carved with C-scrolls and bead rows, on fluted cabriole legs. A cut-crystal whisky decanter and tumblers on a gold tray, roses, and a leather book with a gilt title.' },
    'LIV-107': { spec: 'chester25V2', note: 'A deep-buttoned chesterfield in emerald crushed velvet with a soft nap, self piping on the seats and scroll fronts, on ringed walnut bun feet. Two mustard velvet pillows with piping and corner tassels, a chunky oatmeal knit throw over one arm and a paperback left open on the other.' },
    'LIV-108': { spec: 'chester25L2', note: 'A deep-buttoned chesterfield in pebbled cognac leather, rubbed to a warm patina on the seat fronts and scroll tops, with soft creases where you sit. Dark welts with cream saddle stitching, brass nailheads, turned walnut bun feet, tartan pillows, a red tartan wool throw over one arm and a gilt-banded leather book with reading glasses on the other.' },
    'LIV-109': { spec: 'chester25B2', note: 'An ivory channel-tufted sofa in nubby boucl\u00e9 on a Calacatta marble plinth with grey and gold veins and a brushed brass band. Mustard velvet pillows, a fluffy sheepskin over one arm and a travertine tray with a lit candle and matches on the other.' },
    'LIV-062': { spec: 'alab25b', note: 'A totem of six alabaster stones with amber and white veins running round them, cloudy inclusions, hairline cracks and a warm glow from inside, on grooved bronze spacers over a patinated, hand-chiselled bronze base, with a cord and inline dimmer.' },
    'LIV-016': { spec: 'spool25', note: 'An old cable spool coffee table: layered plywood with rust round the bolts, splinters and stencilled letters, black cable still wound round the drum. A succulent in a tomato tin, a folded newspaper, a stack of wooden coasters and a mug on top.' },
    'LIV-002': { spec: 'torch25' },
    'LIV-066': { spec: 'cloudPit25', note: 'A curved pit sofa of five puffy boucl\u00e9 modules on oak plinths, each seat with a piped welt, nubby loops all over, a chunky-knit mustard throw over the middle back cushion, a rust cable-knit pillow with pompoms and a fluffy faux-fur pillow.' },
    'LIV-013': { spec: 'box25', note: 'An old moving box turned footrest: corrugated cardboard held shut with silver duct tape, THIS SIDE UP arrows, a red FRAGILE stamp, a shipping label with a barcode, a crushed corner taped back up, a coffee ring and a water-stained bottom. A folded fleece blanket and the TV remote sit on top.' },
    'LIV-050': { spec: 'papasan25', note: 'A papasan on a black and brass swivel base: a woven rattan bowl with wrapped rim, a deep velvet cushion with pleats running into buttons, a welt round the edge and a piped velvet back pillow. A gold tassel hangs off the rim.' },
    'LIV-054': { spec: 'cattree25', note: 'A pet climbing tree of real birch logs with white bark and black marks on a felt base: a sisal-wrapped scratching post, a felt cave with a round door, felt beds with paw prints on the platforms, felt leaves on the logs and a red felt ball on a cord.' },
    'LIV-010': { spec: 'fold25', note: 'A grey metal folding chair that doesn\u2019t match anything: a scratched pine seat with a carved heart and a water ring, a back slat painted teal and chipped down to the wood with a star sticker, rusty spots on the legs, rubber feet (one is missing) and a red gingham pillow tied on with bows.' },
    'LIV-030': { spec: 'wing25', note: 'A mid-century wingback in mustard wool tweed flecked with rust, cream and olive, with button-tufted back, self piping on every edge and tapered walnut legs with brass tips. A rust knit throw hangs over one arm.' },
    'LIV-006': { spec: 'plaid25', note: 'A lumpy thrift-store two-seater in faded brown tartan with green bands and mustard lines, pilled all over. Saggy seats with dents and creases, a spring poking out of one cushion, a duct-tape X, a coffee ring, a corduroy patch sewn on the back, a threadbare arm, one odd wooden leg and a granny-square pillow.' },
    'LIV-026': { spec: 'scandi25', note: 'A clean Scandinavian three-seater in heathered grey woven fabric with piped welts, button-tufted back cushions and tapered oak legs on an oak rail. A mustard rib-knit pillow, a white pillow with a black zigzag print and an oatmeal waffle-knit throw over one arm.' },
    'LIV-046': { spec: 'cognac25', note: 'An L-shaped sectional in full-grain cognac leather with a chaise, rubbed to a warm patina on the seats and arms, soft creases, dark welts with cream saddle stitching. A cream bouclé pillow, a charcoal herringbone wool pillow and a striped grey wool blanket folded across the chaise.' },
    'LIV-082': { spec: 'bio25' }, 'LIV-100': { spec: 'terra25x' }, 'LIV-088': { spec: 'chrono25x' }, 'LIV-099': { spec: 'lev25x' }, 'LIV-068': { spec: 'ikebana25x' }, 
    'LIV-070': { spec: 'shear25', note: 'A low lounge chair in sculpted walnut with flowing grain, little knots and fine edge grain on every piece, holding fluffy cream shearling cushions. Two cognac leather straps run over the back with brass buckles.' },
    'LIV-086': { spec: 'lev25', live: 'Levitating', note: 'A cloud-soft cashmere sofa in fine rib-knit with cable-knit back cushions, floating above a black-glass magnetic pad. The smart-gel seats glow with warm heat nodes and a touch dial sets the warmth; a caramel cashmere throw with fringe drapes over one arm. Magnetic rings rise under it and warm air shimmers over the seats.' },
    'LIV-110': { spec: 'chester25', note: 'A grand four-seat chesterfield in crushed royal velvet with deep tufting, gold piping and gold nailheads, on a gold-leaf apron with bullion fringe and gilded bun feet. A carved gilt shell crest with acanthus scrolls crowns the back; gold damask pillows and an emerald bolster embroidered with a crown and gold tassels.' },
    'LIV-090': { spec: 'throne25', live: 'Floating', note: 'A floating lounge throne with a gloss carbon-fibre twill shell, quilted perforated leather seat and back with stitched welts, cyan LED loops on the scrolls and wings, speakers in the wings and a glowing crest on the back. Two gyro rings orbit it over a black-glass magnetic pad.' },
  };
  const edit24 = RD.edit;
  RD.edit = rows => edit24(rows).map(r => RD.SET25[r.id] ? Object.assign({}, r, RD.SET25[r.id]) : r);
  RD.H25 = { fr2, clip, hatch, wavy, outline, dots, ringL, caps, sides, padFx, gyro, bbS };
  RD.PLUS25 = 1;
})();
