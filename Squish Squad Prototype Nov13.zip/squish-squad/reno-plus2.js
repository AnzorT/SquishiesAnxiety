// Renovation Catalog round 3: realistic sofa cushions/pillows, realistic food, animated holograms, live LED club floors + walls,
// rugs flagged flat (always under furniture), and a Royal Collection (the most expensive pieces) in every room.
// Loaded after reno-plus.js; sets RenoDraw.PLUS2 when ready.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS2) return;
  const K = X.K, { solid, box, cush, cyl, ball, slab, slabX, arcW, disc, pillowZ, shade, mix, f1 } = K;
  const N = RD.N, em = RD.H.em, NE = K.NEON, GOLD = '#e2b14a', CH = '#d5dde2', WH = '#ffffff', GL = '#cfe8f2', PI = Math.PI, IRON = '#3b3c40';
  const metal = k => k === 'royal' ? GOLD : k === 'candy' ? '#e9ecef' : k === 'junk' ? '#7d7f84' : k === 'mod' ? '#2c2d31' : k === 'retro' ? CH : IRON;
  const mt = o => Object.assign({ mat: 'metal' }, o || {}), wd = o => Object.assign({ mat: 'wood' }, o || {}), cer = o => Object.assign({ mat: 'cer' }, o || {}), fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {}), pt = o => Object.assign({ mat: 'paint' }, o || {});
  const rep = (n, f) => Array.from({ length: n }, (_, i) => f(i));
  const an = (a, v, d, b, kt) => '<animate attributeName="' + a + '" values="' + v + '" dur="' + d + 's"' + (kt ? ' keyTimes="' + kt + '"' : '') + (b ? ' begin="' + b + 's"' : '') + ' repeatCount="indefinite"/>';
  const at = (t, v, d, b, kt) => '<animateTransform attributeName="transform" type="' + t + '" values="' + v + '" dur="' + d + 's"' + (kt ? ' keyTimes="' + kt + '"' : '') + (b ? ' begin="' + b + 's"' : '') + ' repeatCount="indefinite"/>';
  const P2 = q => f1(q[0]) + ' ' + f1(q[1]);
  const n4 = v => Math.round(v * 1e4) / 1e4;
  const mtx = (o, a, b) => 'matrix(' + [a[0] - o[0], a[1] - o[1], b[0] - o[0], b[1] - o[1], o[0], o[1]].map(n4).join(' ') + ')';
  const plane = (p, z, y) => mtx(p(0, y, z), p(1, y, z), p(0, y - 1, z));
  const planeH = (p, y) => mtx(p(0, y, 0), p(1, y, 0), p(0, y, 1));
  const bob = (a, d) => at('translate', '0 0;0 ' + (-a) + ';0 0', d);
  const GLOW = '<filter id="gw2" x="-40%" y="-80%" width="180%" height="260%"><feGaussianBlur stdDeviation="1.6" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>';
  const hash = s => { let h = 7; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) | 0; return Math.abs(h); };
  const rng = s => { let h = hash(s) || 1; return () => { h = (h * 1103515245 + 12345) | 0; return ((h >>> 8) & 0xffff) / 65536; }; };
  const steam = (c, x, y, z, s, n, col) => { const q = c.p(x, y, z); let o = '<g transform="translate(' + P2(q) + ') scale(' + f1(c.k * (s || 1)) + ')">'; for (let i = 0; i < (n || 3); i++) { const dx = (i - ((n || 3) - 1) / 2) * 4; o += '<path d="M' + dx + ' 0q-3 -5 0 -10t0 -10" fill="none" stroke="' + (col || '#ffffff') + '" stroke-width="1.5" stroke-linecap="round" opacity="0">' + an('opacity', '0;0.8;0', 2.4, -i * 0.8) + at('translate', '0 0;0 -9', 2.4, -i * 0.8) + '</path>'; } return o + '</g>'; };
  const spark = (c, x, y, z, s, b, col, d) => '<g transform="translate(' + P2(c.p(x, y, z)) + ') scale(' + f1(c.k * (s || 1)) + ')"><path d="M0 -4L1 -1L4 0L1 1L0 4L-1 1L-4 0L-1 -1Z" fill="' + (col || '#ffffff') + '" opacity="0">' + an('opacity', '0;1;0;0', d || 1.8, b) + '</path></g>';
  const NEV = NE.concat(NE[0]).join(';');

  // ---------- upholstery parts ----------
  // boxed seat cushion: crisp welted edge with a soft crown (not a balloon)
  const seatC = (x, y, z, w, h, d, col, o) => solid(Object.assign({ ax: 'y', sh: 'rr', c: [x, z], a: w / 2, b: d / 2, r: Math.min(w, d) * 0.16, rings: [[y, 1.6, 0.97], [y + 1.6, 0, 1], [y + h - 3.2, 0, 1], [y + h - 1, 1.6, 0.99], [y + h, 4.5, 0.96], [y + h + 1.4, 11, 0.88]], col, soft: 1, mat: 'fab' }, o || {}));
  // upright back cushion resting on the deck against the back frame, crowned front face
  const backC = (x, y0, y1, z0, z1, w, col, o) => { const h = y1 - y0; return solid(Object.assign({ ax: 'z', sh: 'rr', c: [x, y0 + h / 2], a: w / 2, b: h / 2, r: Math.min(w, h) * 0.2, rings: [[z0, 0, 0.98], [z1 - 3.5, 0, 1], [z1 - 1.2, 1.6, 0.99], [z1, 4.5, 0.95], [z1 + 1.6, 10, 0.86]], col, soft: 1, mat: 'fab' }, o || {})); };
  // square throw pillow standing on the seat, leaning on the back cushions
  const throwP = (x, y, z, s, col, o) => solid(Object.assign({ ax: 'z', sh: 'rr', c: [x, y + s / 2], a: s / 2, b: s / 2, r: s * 0.3, rings: [[z - 4.5, 4, 0.82], [z - 2.6, 1, 0.97], [z, 0, 1], [z + 2.6, 1, 0.97], [z + 4.5, 4, 0.82]], col, soft: 1, mat: 'fab' }, o || {}));

  // ---------- seating ----------
  function pitSofa(S, n, fl, met, by, anim, pad) { const DK = 12, R0 = 34 + n * 16, Rz = R0 * 0.75, a0 = PI * 1.02, a1 = PI * 1.98, zc = R0 * 0.35, aw = 0.07, b0 = a0 + aw, b1 = a1 - aw;
    const segs = rep(n, i => [b0 + (b1 - b0) * i / n, b0 + (b1 - b0) * (i + 1) / n]), mid = s => (s[0] + s[1]) / 2, rs = R0 - 13 - 11 - 18;
    const nn = a => Math.max(3, Math.round(a / 0.1));
    const L1 = P => { const o = []; if (!fl) rep(n + 1, i => { const a = a0 + (a1 - a0) * i / n; o.push(cyl(Math.cos(a) * (R0 - 22), 0, zc + Math.sin(a) * (Rz - 22), 2.6, by - 3, met, mt({ n: 8 }))); }); o.push(arcW(0, by - 3, zc, R0 - 2, Rz - 2, 56, 3, a0, a1, met, mt({ n: 18 })), arcW(0, by, zc, R0, Rz, 13, DK + 48, b0, b1, P.a, fb({ n: 18 }))); return o; };
    const L2 = P => segs.map(([s0, s1]) => arcW(0, by + DK, zc, R0 - 13, Rz - 13, 11, 42, s0 + 0.012, s1 - 0.012, P.aL, fb({ n: nn(s1 - s0) })));
    return { w: R0 * 2 + 10, d: Rz * 2, act: 'sit', seats: segs.map(s => ({ x: Math.cos(mid(s)) * rs, z: zc + Math.sin(mid(s)) * rs * 0.75, h: by + DK + 17 })), anim, pad, layers: [{ back: 1, build: L1 }, { back: 1, build: L2 }], build: P => { const o = [], fab = P.a, fL = P.aL, fD = P.aD;
      if (fl) o.push(cyl(0, by - 7, zc - Rz * 0.4, R0 * 0.7, 2, '#8fe8ff', em({ rz: Rz * 0.4, op: 0.5, n: 20 })));
      o.push(arcW(0, by, zc, R0 - 13, Rz - 13, 46, DK, b0, b1, fD, fb({ n: 18 })));
      [[a0, b0], [b1, a1]].forEach(([s0, s1]) => o.push(arcW(0, by - 3, zc, R0, Rz, 59, DK + 34, s0, s1, fab, fb({ n: 2 }))));
      segs.forEach(([s0, s1], i) => { const g = 0.012; o.push(arcW(0, by + DK, zc, R0 - 24, Rz - 24, 34, 15, s0 + g, s1 - g, fL, fb({ n: nn(s1 - s0) }))); });
      [segs[0], segs[n - 1]].forEach((s, i) => { const a = i ? s[1] - 0.18 : s[0] + 0.18, r = R0 - 30; o.push(throwP(Math.cos(a) * r, by + DK + 13, zc + Math.sin(a) * r * 0.75 + 4, 22, i ? shade(P.bL || '#e9d9b0', 0.92) : (P.bL || '#e9d9b0'))); });
      return o; } }; }

  N.rsofa = S => { const nm = S.nm, k = S.k, v = S.v;
    let shp = S.shape || (v === 'L' || /l-shaped|sectional|banquette/.test(nm) ? 'L' : v === 'U' || /horseshoe|u-shaped|booth/.test(nm) ? 'U' : v === 'pit' || /pit sofa|curved|conversation/.test(nm) ? 'pit' : '');
    let n = S.n || (v === '1' ? 1 : /two-seater|loveseat|2-seat|pair|bench/.test(nm) ? 2 : shp === 'L' ? 4 : shp ? 5 : 3); if (n === 1) shp = '';
    if (shp === 'L' && n < 3) n = 3; if (shp === 'U' && n < 4) n = 4;
    const fl = S.float || /levitat|floating|anti-grav|zero-g|hover/.test(nm), met = metal(k), SW = 58, AW = n === 1 ? 18 : 20, Dp = 88, ext = 62, by = 9 + (fl ? 14 : 0), wing = /wingback|throne/.test(nm), tuft = k === 'royal' || k === 'cot' || /tufted|chesterfield|wingback/.test(nm);
    const anim = fl ? bob(5, 3.2) : '', pad = fl ? [0, 8, 0, 0] : null;
    if (shp === 'pit') return pitSofa(S, n, fl, met, by, anim, pad);
    const DK = 12, SH = 15, top = by + DK + SH, bz0 = -Dp / 2 + 2, bz1 = bz0 + 13, cz1 = bz1 + 12, fr = Dp / 2 - 3, frC = Dp / 2 + ext - 3, bh = wing ? 60 : k === 'mod' ? 40 : 48;
    const cols = shp === 'L' ? n - 1 : shp === 'U' ? n - 2 : n, Wd = cols * SW + AW * 2, xs = rep(cols, i => -Wd / 2 + AW + SW * (i + 0.5)), eL = shp === 'L' || shp === 'U', eR = shp === 'U', chaise = i => (eL && i === 0) || (eR && i === cols - 1);
    const seats = []; xs.forEach((x, i) => { seats.push({ x, z: (cz1 + fr) / 2, h: top + 2 }); if (chaise(i)) seats.push({ x, z: Dp / 2 + ext / 2, h: top + 2 }); });
    const parts = P => { const o = [], bk = [], fab = P.a, fL = P.aL, fD = P.aD, xl = -Wd / 2 + AW, xr = Wd / 2 - AW, ze = Dp / 2 + ext - 2;
      const acc = k === 'royal' ? '#e9c66a' : k === 'junk' ? '#c9b48a' : k === 'mod' ? '#d9c7a4' : mix(P.b || '#e9d9b0', '#ffffff', 0.35);
      if (!fl) { const lx = Wd / 2 - 7, lz = Dp / 2 - 9, L = [[-lx, -lz], [lx, -lz], [-lx, lz], [lx, lz]]; if (eL) L.push([-lx, lz + ext]); if (eR) L.push([lx, lz + ext]); if (Wd > 200) L.push([0, -lz], [0, lz]);
        L.forEach(([x, z]) => o.push(k === 'royal' ? ball(x, 0, z, 4.4, GOLD, mt({ k: 4, n: 10 })) : cyl(x, 0, z, 2.6, by - 3, met, mt({ n: 8, rg: [[0, 0, 0.65], [by - 3, 0, 1.1]] })))); }
      else o.push(cyl(0, by - 7, 0, Wd / 2 - 16, 2, '#8fe8ff', em({ rz: Dp / 2 - 14, op: 0.55, n: 20 })));
      // frame: metal rail + upholstered deck per span (main seats / chaise ends) so nothing interpenetrates
      const spans = []; let ma = xl, mb = xr; if (eL) { spans.push([xl, xs[0] + SW / 2, ze]); ma = xs[0] + SW / 2; } if (eR) { spans.push([xs[cols - 1] - SW / 2, xr, ze]); mb = xs[cols - 1] - SW / 2; } if (mb - ma > 1) spans.push([ma, mb, Dp / 2 - 2]);
      // glued details (par = the part they lie on, fn = its face normal) skip the depth sort, so thin strips / tufts / badges never make sort cycles
      const on = (p, S, fn) => { S.par = p; if (fn) S.fn = fn; return S; }; let mdk = null;
      spans.forEach(([a, b, zf]) => { const dk = box((a + b) / 2, by, (bz1 + zf) / 2, b - a, DK, zf - bz1, fD, { r: 3, bev: 2, mat: 'fab', soft: 1 }); const rl = box((a + b) / 2, by - 3, (bz0 + zf) / 2, b - a, 3, zf - bz0, met, mt({ r: 2 })); o.push(rl, on(rl, dk)); if (zf === Dp / 2 - 2) mdk = dk; }); // deck lies on its rail (glued: a wide deck beside the arms made md cycles in near-front views)
      bk.push(slab(0, by, (bz0 + bz1) / 2, xr - xl, DK + bh, bz1 - bz0, fab, { r: k === 'mod' ? 6 : 10, rb: 0, soft: 1, mat: 'fab' }));
      xs.forEach((x, i) => { const bc = backC(x, by + DK, by + DK + bh - 3, bz1, cz1, SW - 3, fL); o.push(bc);
        if (tuft) [-14, 0, 14].forEach(t => o.push(on(bc, ball(x + t, by + DK + (bh - 3) * 0.62, cz1 + 0.8, 1.5, k === 'royal' ? GOLD : shade(fab, 0.68), mt({ k: 3, n: 8, noOut: 1 })), [0, 0, 1])));
        const zf = chaise(i) ? frC : fr; o.push(seatC(x, by + DK, (cz1 + zf) / 2, SW - 3, SH, zf - cz1, fL)); });
      [-1, 1].forEach(sg => { const e = sg < 0 ? eL : eR, z0 = bz0, z1 = e ? ze : Dp / 2 - 2, x = sg * (Wd / 2 - AW / 2), ah = wing ? 40 : 32, t = sg < 0 ? bk : o;
        // arm box stops where the rolled top begins (the roll sits on it, not in it)
        const ab = box(x, by - 3, (z0 + z1) / 2, AW, ah - 4, z1 - z0, fab, { r: 6, soft: 1, mat: 'fab' });
        t.push(ab, solid({ ax: 'z', sh: 'el', c: [x, by + ah], a: AW / 2 + 2, b: 7, n: 14, rings: [[z0, 2.5, 0.85], [z0 + 2.5, 0], [z1 - 2.5, 0], [z1, 2.5, 0.85]], col: fab, soft: 1, mat: 'fab' }), on(ab, disc(x, by + ah * 0.45, z1 + 0.2, AW / 2 - 3, 1.4, met, mt()), [0, 0, 1]));
        if (wing) t.push(slab(x, by + ah + 7, bz0 + 9, AW, 26, 14, fab, { r: 12, soft: 1, mat: 'fab' })); });
      if (n >= 2) { o.push(throwP(xs[0] - SW / 2 + 15, top - 2, cz1 + 5, k === 'junk' ? 21 : 24, acc)); if (k !== 'junk') o.push(throwP(xs[cols - 1] + SW / 2 - 15, top - 2, cz1 + 5, 24, shade(acc, 0.9))); }
      if (mb - ma > 1) { const sx = slabX((ma + mb) / 2, by + 1, Dp / 2 - 1.6, mb - ma, 2, 1.4, met, mt({ r: 1 })); o.push(mdk ? on(mdk, sx, [0, 0, 1]) : sx); }
      return { o, bk }; };
    return { w: Wd, d: Dp + (eL ? ext : 0), act: 'sit', seats, anim, pad, layers: [{ back: 1, build: P => parts(P).bk }], build: P => parts(P).o }; };

  // luxury sofas: cushions meet the back, bolsters lie along the arms, pillows rest on the seat against the back
  N.luxSofa = S => { const n = S.n || 3, st = S.st || 'chester', gold = !!S.gold, legc = gold ? GOLD : S.wood || '#4a2c1a', SW = 56, AW = 24, Dp = 88, Wd = n * SW + AW * 2, by = 16, xs = rep(n, i => -Wd / 2 + AW + SW * (i + 0.5));
    const ah = st === 'chester' ? 40 : 30, bh = st === 'chester' ? 40 : 54, bz = -Dp / 2 + 9, brass = gold || S.brass, bf = st === 'chester' ? bz + 8 : bz + 13, cz = (bf + Dp / 2 - 4) / 2, cd = Dp / 2 - 4 - bf, cf = cz + cd / 2, st0 = by + 30;
    return { w: Wd + 8, d: Dp, act: 'sit', seats: xs.map(x => ({ x, z: cz, h: st0 + 1 })), build: P => { const o = [], fab = P.a, fL = shade(fab, 1.07), fD = shade(fab, 0.82), pip = brass ? GOLD : shade(fab, 0.68), plc = S.plinth, lm = gold ? mt({ k: 3, n: 8 }) : { k: 3, n: 8, mat: 'wood' };
      const pil = S.pil || (/^#(e|f|d)/i.test(fab) ? '#8a6a48' : '#e9d9b0'), thr = /^#(e|f)/i.test(fab) ? '#6b4426' : '#efe4cc';
      if (plc) { o.push(box(0, 0, 0, Wd - 8, by - 2, Dp - 10, plc, { r: 3, mat: 'cer' }), box(0, by - 2.4, 0, Wd - 7, 1.2, Dp - 9, GOLD, mt({ r: 3 })));
        const R = rng(S.nm); rep(6, () => o.push(box((R() - 0.5) * (Wd - 30), by - 6 - R() * 6, Dp / 2 - 4.9, 18 + R() * 20, 0.6, 0.2, '#c9b98a', { r: 0, noOut: 1 }))); }
      else { const lx = Wd / 2 - 9, lz = Dp / 2 - 11, L = [[-lx, -lz], [lx, -lz], [-lx, lz], [lx, lz]]; if (n >= 4) L.push([0, lz], [0, -lz]);
        L.forEach(([x, z]) => o.push(ball(x, 2.4, z, 3.6, legc, gold ? mt({ k: 4, n: 10 }) : { k: 4, n: 10, mat: 'wood' }), cyl(x, 4, z, 3, by - 8, legc, Object.assign({ n: 10, rg: [[0, 0, 0.7], [(by - 8) * 0.5, 0, 1.15], [by - 8, 0, 0.8]] }, gold ? { mat: 'metal' } : { mat: 'wood' })), cyl(x, 0, z, 2.6, 1.4, brass ? GOLD : '#2a1a10', mt({ n: 8 }))));
        o.push(box(0, by - 6, 0, Wd - 6, 5, Dp - 8, legc, gold ? mt({ r: 3 }) : { r: 3, mat: 'wood' }));
        const nb = Math.floor((Wd - 16) / 7); rep(nb, i => o.push(ball(-Wd / 2 + 8 + (i + 0.5) * (Wd - 16) / nb, by - 4.8, Dp / 2 - 3.6, 1.3, gold ? GOLD : shade(legc, 1.25), Object.assign({ sz: 0.6, noOut: 1 }, lm))));
        o.push(ball(0, by - 5, Dp / 2 - 3.2, 4.2, gold ? GOLD : shade(legc, 1.2), Object.assign({ sy: 0.7, sz: 0.5 }, lm)));
        if (gold) [-1, 1].forEach(sg => o.push(ball(sg * 14, by - 5, Dp / 2 - 3.4, 2.4, GOLD, mt({ sy: 0.6, sz: 0.5, k: 3, n: 8 })))); }
      // deck between the arms, in front of the back
      o.push(box(0, by, (bf + Dp / 2 - 3) / 2, Wd - AW * 2, 16, Dp / 2 - 3 - bf, fD, { r: 4, bev: 3, mat: 'fab' }), slabX(0, by + 0.6, Dp / 2 - 2.6, Wd - 10, 1.6, 1.6, pip, brass ? mt({ r: 0.8 }) : { r: 0.8, mat: 'fab' }));
      if (brass) { const nn = Math.floor((Wd - 20) / 5); rep(nn, i => o.push(ball(-Wd / 2 + 10 + (i + 0.5) * (Wd - 20) / nn, by + 4, Dp / 2 - 2, 0.95, GOLD, mt({ k: 3, n: 6, noOut: 1 })))); }
      xs.forEach(x => { o.push(seatC(x, by + 16, cz, SW - 3, 14, cd, fL));
        [by + 17, by + 28.2].forEach(y => o.push(slabX(x, y, cf + 0.2, SW - 9, 1.1, 1.1, pip, brass ? mt({ r: 0.5, noOut: 1 }) : { r: 0.5, mat: 'fab', noOut: 1 })));
        if (st === 'chester') o.push(ball(x, st0 + 0.6, cz + 2, 1.6, brass ? GOLD : shade(fab, 0.6), mt({ sy: 0.5, k: 3, n: 8, noOut: 1 }))); });
      // back
      o.push(slab(0, by, bz, Wd - AW * 2, 12 + bh, 16, fab, { r: st === 'chester' ? 6 : 14, rb: 0, soft: 1, mat: 'fab' }));
      if (st === 'chester') { const rows = 3, cols = n * 3 + 1; rep(rows, j => rep(cols - (j % 2), i => { const x = -Wd / 2 + AW + (Wd - AW * 2) * (i + (j % 2 ? 1 : 0.5)) / cols, y = by + 34 + j * 9;
          o.push(ball(x, y, bz + 8.1, 3.6, shade(fab, 0.8), { sz: 0.22, k: 3, n: 10, noOut: 1, shine: 0 }), ball(x, y, bz + 8.7, 1.8, brass ? GOLD : shade(fab, 0.58), mt({ k: 3, n: 8, noOut: 1 }))); }));
        o.push(solid({ ax: 'x', sh: 'el', c: [bz + 2, by + 12 + bh], a: 9, b: 6, n: 14, rings: [[-Wd / 2 + AW - 2, 2.5, 0.85], [-Wd / 2 + AW + 1, 0], [Wd / 2 - AW - 1, 0], [Wd / 2 - AW + 2, 2.5, 0.85]], col: fab, soft: 1 }),
          slabX(0, by + 12 + bh - 5.4, bz + 9.4, Wd - AW * 2 - 2, 1.4, 1.2, pip, brass ? mt({ r: 0.6 }) : { r: 0.6, mat: 'fab' }));
        if (gold) o.push(ball(0, by + 12 + bh + 6, bz + 2, 4, GOLD, mt({ sy: 0.8, sz: 0.5, k: 4, n: 10 }))); }
      else { xs.forEach(x => [-1, 0, 1].forEach(t => o.push(pillowZ(x + t * 17, by + 16, bz + 9, 16, bh - 6, 8, t ? fab : fL)))); }
      // rolled arms
      [-1, 1].forEach(sg => { const x = sg * (Wd / 2 - AW / 2), z0 = -Dp / 2 + 3, z1 = Dp / 2 - 3, xr = x + sg * 2;
        o.push(box(x, by, (z0 + z1) / 2, AW, ah, z1 - z0, fab, { r: 6, soft: 1, mat: 'fab' }), solid({ ax: 'z', sh: 'el', c: [xr, by + ah], a: AW / 2 + 4, b: 8, n: 16, rings: [[z0, 2.5, 0.85], [z0 + 2.5, 0], [z1 - 2.5, 0], [z1, 2.5, 0.85]], col: fab, soft: 1 }));
        o.push(box(x, by + 2, z1 + 0.1, AW - 7, ah - 8, 1, shade(fab, 0.92), { r: 3, soft: 1, mat: 'fab' }), disc(xr, by + ah, z1 + 0.3, AW / 2 + 1, 1.2, shade(fab, 0.9), { mat: 'fab' }));
        o.push(solid(Object.assign({ ax: 'z', sh: 'arc', c: [xr, by + ah], a: AW / 2 + 1.6, b: 8.6, th: 1, a0: 0, a1: 2 * PI, n: 18, rings: [[z1 + 0.9, 0], [z1 + 1.7, 0]], col: pip, noOut: 1 }, brass ? { mat: 'metal' } : { mat: 'fab' })));
        o.push(ball(xr, by + ah, z1 + 1.6, 2.8, gold ? GOLD : shade(fab, 0.75), Object.assign({ sz: 0.5 }, gold ? mt({ k: 4, n: 10 }) : { k: 4, n: 10, mat: 'fab' })));
        if (brass) rep(6, i => o.push(ball(x, by + 4 + i * (ah - 12) / 5, z1 + 0.8, 1.1, GOLD, mt({ k: 3, n: 6, noOut: 1 }))));
        // bolster lying along the arm on the seat, piped ends
        const bx = sg * (Wd / 2 - AW - 7.5), bc = st0 + 6.6, zA = bf + 4, zB = Dp / 2 - 10;
        o.push(solid({ ax: 'z', sh: 'el', c: [bx, bc], a: 7, b: 7, n: 14, rings: [[zA, 0, 0.72], [zA + 1.6, 0, 1], [zB - 1.6, 0, 1], [zB, 0, 0.72]], col: shade(fab, 1.14), soft: 1, mat: 'fab' }), disc(bx, bc, zB, 4.8, 0.5, pip, brass ? mt() : { mat: 'fab' }), ball(bx, bc - 1.6, zB + 0.4, 1.6, brass ? GOLD : pip, mt({ sz: 0.6, k: 3, n: 8 }))); });
      // throw pillows + lumbar resting on the seat cushions against the back
      [-1, 1].forEach(sg => { const px = sg * (Wd / 2 - AW - 31), pc = sg < 0 ? pil : shade(pil, 0.88);
        o.push(throwP(px, st0 - 1.6, bf + 5.6, 26, pc), slabX(px, st0 + 23.4, bf + 7.2, 22, 1, 1, shade(pc, 0.7), { r: 0.5, noOut: 1, mat: 'fab' }));
        [-12, 12].forEach(t => o.push(ball(px + t, st0 + 22, bf + 6, 1.6, brass ? GOLD : shade(pc, 0.7), { sy: 1.6, k: 3, n: 8 }))); });
      if (n >= 3) { const lc = S.pil ? shade(S.pil, 1.1) : shade(fab, 1.18); o.push(solid({ ax: 'z', sh: 'rr', c: [0, st0 + 6.6], a: 18, b: 8, r: 7, rings: [[bf + 1, 3, 0.82], [bf + 3, 0.6, 0.97], [bf + 5, 0, 1], [bf + 7, 0.6, 0.97], [bf + 9, 3, 0.82]], col: lc, soft: 1, mat: 'fab' }), slabX(0, st0 + 6, bf + 9.2, 30, 1.2, 0.5, pip, brass ? mt({ r: 0.4, noOut: 1 }) : { r: 0.4, mat: 'fab', noOut: 1 })); }
      { const x = -(Wd / 2 - AW / 2) - 2, tz = 2; o.push(box(x, by + ah + 5.6, tz, AW + 6, 3.2, 30, thr, { r: 1.6, bev: 1.4, soft: 1, mat: 'fab' }), box(-Wd / 2 - 2.6, by + ah - 16, tz, 2.6, 24, 30, thr, { r: 1.2, soft: 1, mat: 'fab' }));
        [-9, 9].forEach(dz => o.push(box(x, by + ah + 8.9, tz + dz, AW + 6.4, 0.3, 3, pil, { r: 0, noOut: 1 }), box(-Wd / 2 - 4, by + ah - 16, tz + dz, 0.3, 24.4, 3, pil, { r: 0, noOut: 1 })));
        rep(8, i => o.push(box(-Wd / 2 - 2.6, by + ah - 20, tz - 13 + i * 3.7, 1, 4, 1, shade(thr, 0.9), { r: 0, noOut: 1 }))); }
      return o; } }; };

  // ---------- food ----------
  const POP = ['#fff6dc', '#fbeab8', '#fffaf0', '#f6dc94'];
  const kern = (x, y, z, s, i) => [ball(x, y, z, 1.8 * s, POP[i % 4], { k: 3, n: 7, shine: 0 }), ball(x + 1.15 * s * Math.cos(i), y + 0.9 * s, z + 1.15 * s * Math.sin(i), 1.35 * s, POP[(i + 1) % 4], { k: 3, n: 6, shine: 0 })];
  const heap = (o, x, y, z, rx, rz, h, n, seed, s) => { const R = rng(seed); o.push(ball(x, y - h, z, rx, '#f8e8b8', { sz: rz / rx, sy: h / rx, k: 4, n: 14, shine: 0 }));
    rep(n, i => { const a = R() * 2 * PI, t = Math.sqrt(R()) * 0.9; o.push(...kern(x + rx * t * Math.cos(a), y + h * Math.sqrt(1 - t * t) - 1.6 * (s || 1), z + rz * t * Math.sin(a), s || 1, i)); }); };
  const plateF = (x, y, z, r, col, o) => cyl(x, y, z, r, 2.2, col || '#fbf8f2', Object.assign({ n: 22, mat: 'cer', rg: [[0, 0, 0.6], [0.9, 0, 0.64], [1.6, 0, 1], [2.2, 0, 1]] }, o || {}));
  const SPR = ['#ff6ad5', '#ffd66b', '#6ac8ff', '#a6f06a', '#ffffff', '#ff9d4a'];
  const sprinkles = (o, x, y, z, r, n, seed) => { const R = rng(seed); rep(n, i => { const a = R() * 2 * PI, t = 0.35 + R() * 0.6; o.push(box(x + Math.cos(a) * r * t, y, z + Math.sin(a) * r * t, 2, 0.5, 0.7, SPR[i % 6], { yaw: R() * PI, r: 0.3, noOut: 1 })); }); };
  const apple = (x, y, z, col, s) => { s = s || 1; return [ball(x, y, z, 6.4 * s, col, { sy: 0.9, k: 6, n: 14 }), ball(x, y + 10.6 * s, z, 2.2 * s, shade(col, 0.82), { sy: 0.35, k: 3, n: 8, shine: 0 }), cyl(x, y + 10.8 * s, z, 0.6, 3 * s, '#5a3a20', { n: 4 }), ball(x + 2.2 * s, y + 12.6 * s, z, 2.2 * s, '#5fa84a', { sx: 1.5, sy: 0.35, k: 3, n: 8 })]; };
  const orange = (x, y, z, s) => { s = s || 1; return [ball(x, y, z, 6.6 * s, '#f2932c', { k: 6, n: 14 }), ball(x, y + 12.8 * s, z + 0.6, 1.1 * s, '#6a8a3a', { k: 3, n: 6 }), ball(x + 1.4, y + 12.4 * s, z, 1.8 * s, '#5fa84a', { sx: 1.4, sy: 0.35, k: 3, n: 6 })]; };
  const straw = (x, y, z, s) => { s = s || 1; return [ball(x, y, z, 2.6 * s, '#d9283b', { sy: 1.25, k: 4, n: 10 }), ball(x, y + 5.6 * s, z, 2 * s, '#4f9a3a', { sy: 0.35, k: 2, n: 8, shine: 0 })]; };
  N.fFruitBowl = S => ({ w: 56, d: 52, build: P => { const o = [cyl(0, 0, 0, 9, 3, '#f4f1ea', cer({ n: 16 })), cyl(0, 3, 0, 24, 11, '#f4f1ea', cer({ n: 24, rg: [[0, 0, 0.42], [4, 0, 0.78], [9, 0, 0.98], [11, 0, 1]] })), arcW(0, 14, 0, 24.4, 24.4, 1.4, 1, 0, 2 * PI, '#6b8fb8', cer({ n: 24 }))];
      o.push(...apple(-9, 10, -6, '#d9363b'), ...orange(8, 10, -7), ...apple(1, 10, 8, '#9fcf4a'), ...orange(-11, 9, 7, 0.9), ...apple(2, 19, -2, '#c42a30', 0.95));
      [[-2, 22, 10], [4, 21, 11], [10, 19, 10]].forEach(([a, y, r]) => o.push(arcW(12, y, 4, r, r, 3.2, 3.6, PI * (1.05 + a * 0.01), PI * 1.85, '#f6d24a', { n: 8 })));
      o.push(cyl(12 + Math.cos(PI * 1.05) * 9, 20, 4 + Math.sin(PI * 1.05) * 9, 1.1, 4, '#6b4a20', { n: 6 }));
      rep(12, i => o.push(ball(19 + (i % 3) * 2.8 - (i > 8 ? -1 : 0), 6 + Math.floor(i / 3) * 3, 8 + (i % 2) * 2.4, 2.1, i % 2 ? '#6b3a8a' : '#7d4a9a', { k: 3, n: 8 })));
      o.push(cyl(20, 18, 9, 0.6, 3, '#6b4a20', { n: 4 }));
      return o; } });
  N.fCake = S => ({ w: 58, d: 50, build: P => { const o = [], fr = '#fdf3f0', pk = '#f6c6d2';
      o.push(cyl(0, 0, 0, 9, 1.6, '#f4f1ea', cer({ n: 16 })), cyl(0, 1.6, 0, 2.4, 7, '#f4f1ea', cer({ n: 10, rg: [[0, 0, 1], [3.5, 0, 0.65], [7, 0, 1.3]] })), cyl(0, 8.6, 0, 21, 1.6, '#f4f1ea', cer({ n: 24 })), arcW(0, 10.2, 0, 21, 21, 1, 0.8, 0, 2 * PI, GOLD, mt({ n: 24 })));
      o.push(cyl(0, 10.2, 0, 17, 12, fr, pt({ n: 24 })), cyl(0, 22.2, 0, 11, 10, pk, pt({ n: 20 })));
      rep(16, i => { const a = i / 16 * 2 * PI; o.push(ball(Math.cos(a) * 17, 10.2, Math.sin(a) * 17, 1.4, '#ffffff', { k: 3, n: 6 })); });
      rep(11, i => { const a = i / 11 * 2 * PI; o.push(ball(Math.cos(a) * 11, 22.2, Math.sin(a) * 11, 1.2, '#fff6ea', { k: 3, n: 6 }), ball(Math.cos(a + 0.3) * 11.2, 28.6 - (i % 3), Math.sin(a + 0.3) * 11.2, 1, '#e98aa4', { sy: 2.2, k: 3, n: 6, noOut: 1 })); });
      rep(8, i => { const a = i / 8 * 2 * PI + 0.2; o.push(ball(Math.cos(a) * 14, 22.2, Math.sin(a) * 14, 2.2, '#ffffff', { sy: 0.7, k: 3, n: 8 }), ...straw(Math.cos(a) * 14, 24.6, Math.sin(a) * 14, 0.7)); });
      o.push(ball(0, 32.2, 0, 3.6, '#ffffff', { sy: 0.8, k: 4, n: 10 }), ...straw(0, 37.4, 0, 1.05), ball(-4, 32.4, 3, 1.8, '#2c1a10', { sy: 1.6, k: 3, n: 6 }));
      // a slice on its own plate: layered sponge, jam, cream, frosting cap
      const sx = 26, sz = 14, a0 = PI * 0.62, a1 = PI * 0.62 + 0.75; o.push(plateF(sx - 2, 0, sz - 3, 10, '#fbf8f2'));
      [[2.2, 4.6, '#efc88a'], [6.8, 1.2, '#c8303a'], [8, 1.4, '#fff6ea'], [9.4, 4.6, '#efc88a'], [14, 1.6, pk]].forEach(([y, h, col]) => o.push(arcW(sx + 7, y, sz - 8, 13, 13, 13, h, a0, a1, col, pt({ n: 4 }))));
      o.push(cyl(sx + 6, 2.2, sz + 5, 0.7, 0.6, CH, mt({ n: 4 })), box(sx + 6, 2.2, sz + 1, 1.4, 0.5, 9, CH, mt({ r: 0.4 })));
      return o; } });
  const donut = (o, x, y, z, ic, seed) => { o.push(arcW(x, y, z, 7.4, 7.4, 4, 1.2, 0, 2 * PI, '#c98a46', pt({ n: 18 })), arcW(x, y + 1.2, z, 8.2, 8.2, 5.6, 2.6, 0, 2 * PI, '#d9a35a', pt({ n: 18 })), arcW(x, y + 3.8, z, 8, 8, 5.4, 1.4, 0, 2 * PI, ic, pt({ n: 18 })));
    rep(4, i => { const a = i / 4 * 2 * PI + seed; o.push(ball(x + Math.cos(a) * 8, y + 3.4, z + Math.sin(a) * 8, 1.2, ic, { sy: 1.4, k: 3, n: 6, noOut: 1 })); }); sprinkles(o, x, y + 5.3, z, 7, 9, 'd' + seed + x); };
  N.fDonuts = S => ({ w: 56, d: 50, build: P => { const o = [plateF(0, 0, 0, 24)]; donut(o, -9, 2.2, -4, '#f6a8c4', 1); donut(o, 9, 2.2, -5, '#6b3a22', 2); donut(o, 0, 2.2, 9, '#fff6ea', 3); donut(o, 1, 7.6, -1, '#f6a8c4', 4); return o; } });
  const cupcake = (o, x, z, liner, frost, seed) => { o.push(cyl(x, 2.2, z, 5.4, 7, liner, pt({ n: 16, rg: [[0, 0, 0.78], [7, 0, 1]] })));
    rep(8, i => { const a = i / 8 * 2 * PI; o.push(box(x + Math.cos(a) * 4.9, 2.4, z + Math.sin(a) * 4.9, 0.6, 6.6, 0.6, shade(liner, 0.8), { r: 0, noOut: 1 })); });
    o.push(ball(x, 7.4, z, 6.2, '#e0a85a', { sy: 0.45, k: 3, n: 14 }), ball(x, 9, z, 6, frost, { sy: 0.5, k: 4, n: 14 }), ball(x, 12.6, z, 4.6, frost, { sy: 0.55, k: 4, n: 12 }), ball(x, 15.6, z, 3, frost, { sy: 0.6, k: 3, n: 10 }), ball(x, 18.2, z, 1.4, frost, { k: 3, n: 8 }));
    o.push(ball(x + 0.8, 19.2, z, 2, '#c8243a', { k: 4, n: 10 }), cyl(x + 1.2, 23, z, 0.4, 3, '#5a3a20', { n: 4 })); sprinkles(o, x, 13.6, z, 5, 6, 'c' + seed); };
  N.fCupcakes = S => ({ w: 56, d: 50, build: P => { const o = [plateF(0, 0, 0, 24)]; cupcake(o, -10, -4, '#6ac8ff', '#fff2f6', 1); cupcake(o, 10, -5, '#ffd66b', '#f6a8c4', 2); cupcake(o, 0, 9, '#a6f06a', '#c9a6f0', 3); return o; } });
  const cookie = (o, x, y, z, dark) => { const c0 = dark ? '#6b3a22' : '#c98a46', ch = dark ? '#f4e2b8' : '#3a2010'; o.push(cyl(x, y, z, 6.4, 1.8, c0, pt({ n: 16, rg: [[0, 0, 0.94], [0.9, 0, 1], [1.8, 0, 0.9]] })));
    rep(4, i => { const a = i * 1.7 + x; o.push(ball(x + Math.cos(a) * 3.4, y + 1.5, z + Math.sin(a) * 3.4, 1.1, ch, { sy: 0.6, k: 3, n: 6, noOut: 1 })); }); };
  N.fCookies = S => ({ w: 56, d: 48, build: P => { const o = [plateF(-4, 0, 2, 20)]; rep(4, i => cookie(o, -10 + (i % 2) * 0.8, 2.2 + i * 1.9, -2, i === 2)); rep(2, i => cookie(o, 4, 2.2 + i * 1.9, -5, i === 1)); cookie(o, 0, 2.2, 10, false);
      o.push(cyl(18, 0, -2, 5, 18, GL, cer({ n: 16, op: 0.32 })), cyl(18, 0.4, -2, 4.5, 13, '#fffdf6', { n: 16 }), cyl(18, 13.4, -2, 4.3, 0.4, '#ffffff', { n: 14 }));
      return o; } });
  N.fPizza = S => ({ w: 70, d: 54, build: P => { const o = [cyl(0, 0, 0, 25, 2.4, '#c8925a', wd({ n: 26 })), box(30, 0, 0, 14, 2.4, 8, '#c8925a', wd({ r: 3 })), cyl(0, 2.4, 0, 21, 1.4, '#e8c07a', { n: 26 }), arcW(0, 2.4, 0, 21.6, 21.6, 3.6, 3.4, 0, 2 * PI, '#d6974a', pt({ n: 26 }))];
      o.push(cyl(0, 3.8, 0, 18.2, 0.5, '#d9483b', { n: 24 }), cyl(0, 4.3, 0, 17.6, 0.6, '#f8d872', pt({ n: 24 })));
      [[-8, -6], [6, -9], [10, 3], [-2, 8], [-11, 5], [2, -1], [12, -4], [-5, -12]].forEach(([x, z]) => o.push(cyl(x, 4.9, z, 2.8, 0.6, '#b8382e', pt({ n: 12 }))));
      [[-4, -3], [8, 7], [-12, -2], [4, 12]].forEach(([x, z], i) => o.push(ball(x, 5, z, 1.8, '#3f8a3a', { sx: 1.5, sy: 0.25, k: 2, n: 8, yaw: i })));
      [[0, -14], [-14, 9]].forEach(([x, z]) => o.push(ball(x, 4.8, z, 1.6, '#3a3a3a', { sy: 0.4, k: 2, n: 8 })));
      return o; },
    fx: c => { let f = '<g transform="' + planeH(c.p, 4.95) + '">'; [0, 1, 2, 3].forEach(i => { const a = i * PI / 4; f += '<path d="M' + f1(Math.cos(a) * 18) + ' ' + f1(Math.sin(a) * 18) + 'L' + f1(-Math.cos(a) * 18) + ' ' + f1(-Math.sin(a) * 18) + '" stroke="#c98a3a" stroke-width="0.6" opacity="0.7"/>'; }); f += '</g>';
      return { front: f + steam(c, -3, 6, 0, 0.7, 3) }; } });
  // popcorn bucket, candy box, cereal
  const arcPoly = (x, y, z, R, th, a0, a1, h, sc0, col, o) => { const pts = []; rep(5, i => { const t = a0 + (a1 - a0) * i / 4; pts.push([R * Math.cos(t), R * Math.sin(t)]); }); rep(5, i => { const t = a1 - (a1 - a0) * i / 4; pts.push([(R - th) * Math.cos(t), (R - th) * Math.sin(t)]); });
    return solid(Object.assign({ ax: 'y', sh: 'poly', c: [x, z], pts, rings: [[y, 0, sc0], [y + h, 0, 1]], col, mat: 'paint' }, o || {})); };
  const bucket = (o, x, y, z, R, h, seed) => { rep(14, i => o.push(arcPoly(x, y, z, R, 1.2, i / 14 * 2 * PI, (i + 1) / 14 * 2 * PI, h, 0.74, i % 2 ? '#ffffff' : '#d9363b')));
    o.push(cyl(x, y + 0.2, z, R - 1.1, h - 0.6, '#f8e8b8', { n: 20, rg: [[0, 0, 0.74], [h - 0.6, 0, 1]] }), arcW(x, y + h - 2.4, z, R + 0.5, R + 0.5, 1.6, 2.4, 0, 2 * PI, '#d9363b', pt({ n: 22 })));
    heap(o, x, y + h, z, R * 0.92, R * 0.92, R * 0.42, 22, seed, 0.9); };
  N.popBucket = S => ({ w: 56, d: 46, build: P => { const o = []; bucket(o, -6, 0, 0, 13, 24, 'pb' + S.nm);
      [[14, 10, 0.4], [20, 2, -0.3]].forEach(([x, z, yw]) => o.push(box(x, 0, z, 16, 0.6, 7, '#f2932c', { yaw: yw, r: 0.6 }), box(x - 4, 0.6, z, 0.6, 0.2, 6.6, '#ffffff', { yaw: yw, r: 0, noOut: 1 })));
      rep(5, i => o.push(...kern(8 + i * 3.2, 1.2, 14 - i * 1.6, 0.9, i)));
      return o; } });
  N.candyBox = S => ({ w: 66, d: 44, build: P => { const o = [box(-10, 0, 0, 30, 9, 20, '#d9363b', pt({ r: 1 })), slab(-10, 9, -9.6, 30, 11, 0.8, '#f2c94c', pt({ r: 0.6 })), slab(-10, 2, 10.2, 26, 4.4, 0.4, '#f2c94c', { r: 1, noOut: 1 })];
      const CC = ['#d9363b', '#f2c94c', '#3f7fc8', '#4f9a4a', '#ff9d4a', '#8a4f2c']; rep(14, i => o.push(ball(-21 + (i % 7) * 3.6, 9, -6 + Math.floor(i / 7) * 5 + (i % 2), 1.9, CC[i % 6], { sy: 0.5, k: 3, n: 10 })));
      [[8, 12], [11, 8], [4, 16]].forEach(([x, z], i) => o.push(ball(x, 0, z, 1.9, CC[(i + 2) % 6], { sy: 0.5, k: 3, n: 10 })));
      o.push(box(22, 0, 0, 24, 0.8, 9, '#f4f1ea', { r: 1 }), box(16.5, 0.8, 0.4, 8, 0.3, 5, '#e2554a', { r: 1, op: 0.85 }), box(27.5, 0.8, 0.4, 8, 0.3, 5, '#4fc8e0', { r: 1, op: 0.85 }), box(22, 0.8, -6, 24, 0.6, 2, '#f4f1ea', { r: 0.4 }));
      return o; } });
  N.cereal = S => ({ w: 66, d: 50, build: P => { const o = [box(-16, 0, -4, 24, 36, 10, '#f2c14a', pt({ r: 1 })), slab(-16, 25, 1.2, 22, 7, 0.4, '#d9483b', { r: 1, noOut: 1 }), disc(-16, 13, 1.2, 7, 0.4, '#ffffff', { noOut: 1 })];
      ['#ff6ad5', '#6ac8ff', '#a6f06a', '#ff9d4a'].forEach((cc, i) => o.push(disc(-19 + (i % 2) * 6, 11 + Math.floor(i / 2) * 4, 1.7, 1.6, 0.3, cc, { noOut: 1 })));
      o.push(cyl(-4, 0, 16, 10, 6, '#6ac8ff', cer({ n: 20, rg: [[0, 0, 0.62], [6, 0, 1]] })), cyl(-4, 5.4, 16, 9.2, 0.6, '#fffdf6', { n: 20 }));
      rep(11, i => { const a = i * 2.3, r = 2 + (i % 4) * 1.6; o.push(arcW(-4 + Math.cos(a) * r, 6, 16 + Math.sin(a) * r, 1.7, 1.7, 0.9, 0.9, 0, 2 * PI, ['#ff6ad5', '#ffd66b', '#a6f06a', '#ff9d4a'][i % 4], pt({ n: 8 }))); });
      o.push(box(5, 6.4, 18, 12, 0.6, 1.4, CH, mt({ yaw: -0.5, r: 0.5 })), ball(-1, 6, 19, 2, CH, mt({ sy: 0.35, k: 2, n: 8 })));
      o.push(cyl(16, 0, -2, 5.4, 18, '#7ad08a', { n: 16, op: 0.85, rg: [[0, 0, 1], [14, 0, 1], [18, 0, 0.5]] }), cyl(16, 18, -2, 2, 3, '#ffffff', { n: 10 }), box(18, 20, -2, 5, 1.4, 1.6, '#ffffff', { r: 0.6 }), slab(16, 5, 3.4, 6, 7, 0.3, '#ffffff', { r: 1, noOut: 1 }));
      return o; } });
  N.microPop = S => ({ w: 60, d: 54, build: P => { const o = [], wdc = '#b98a58';
      rep(3, i => { const a = i / 3 * 2 * PI + 0.5; o.push(cyl(Math.cos(a) * 13, 0, Math.sin(a) * 13, 1.8, 38, wdc, wd({ n: 8 }))); });
      o.push(cyl(0, 38, 0, 19, 4, wdc, wd({ n: 20 })), box(0, 42, 0, 44, 26, 30, '#ece8e0', pt({ r: 3 })), slab(-6, 46, 15.2, 28, 18, 0.6, '#2c2d31', { r: 2, op: 0.9 }), slab(-6, 47, 15.6, 24, 15, 0.2, '#ffd66b', { r: 2, op: 0.18, noOut: 1 }), slab(14, 46, 15.2, 9, 18, 0.6, '#d5dde2', { r: 1 }));
      rep(4, i => o.push(ball(14, 58 - i * 3.4, 15.8, 0.9, i ? '#9aa1a6' : '#d9483b', { k: 2, n: 6 })));
      o.push(box(4, 68, -2, 22, 7, 14, '#f4f1ea', { r: 4, soft: 1 }), box(4, 68, 5.2, 22, 6.6, 0.3, '#d9483b', { r: 2, noOut: 1 }), ball(-2, 74.6, -1, 3, '#7a4a28', { sy: 0.3, k: 2, n: 8, noOut: 1 }), ball(9, 74.6, -4, 2.2, '#5a3a20', { sy: 0.3, k: 2, n: 8, noOut: 1 }));
      return o; }, fx: c => ({ front: steam(c, 4, 76, -2, 0.8, 3, '#9aa1a6') }) });
  // popcorn machines
  N.popper = S => ({ w: 52, d: 64, build: P => { const o = [cyl(0, 0, -6, 13, 16, '#d9363b', pt({ n: 20, rg: [[0, 0, 1], [16, 0, 0.88]] })), box(0, 6, 6.6, 6, 3, 2, '#ffffff', { r: 1 })];
      o.push(box(0, 14, 7, 10, 4, 12, '#d9363b', pt({ r: 2 })), cyl(0, 16, -6, 11, 20, GL, cer({ n: 20, op: 0.22, rg: [[0, 0, 1], [14, 0, 1], [20, 0, 0.55]] })), cyl(0, 36, -6, 6, 4, '#f2c94c', pt({ n: 14 })), ball(0, 40, -6, 2, '#ffffff', { k: 3 }));
      heap(o, 0, 18, -6, 9, 9, 3, 10, 'ppd', 0.8);
      o.push(cyl(0, 0, 20, 15, 9, '#ffffff', cer({ n: 22, rg: [[0, 0, 0.62], [9, 0, 1]] })), arcW(0, 6, 20, 15.2, 15.2, 0.8, 1.6, 0, 2 * PI, '#d9363b', pt({ n: 22 })));
      heap(o, 0, 9, 20, 13.6, 13.6, 6, 22, 'ppb', 0.9);
      return o; },
    fx: c => { let f = ''; rep(6, i => { const a = c.p(0, 16, 13), b = c.p((i - 2.5) * 3, 10, 20 + (i % 3) * 2), d = (1.4 + (i % 3) * 0.2).toFixed(1), bg = -(i * 0.37).toFixed(2), mx = f1((a[0] + b[0]) / 2), my = f1(Math.min(a[1], b[1]) - 10 * c.k);
        f += '<circle r="' + f1(1.6 * c.k) + '" fill="#fff6dc" stroke="#e8c870" stroke-width="0.3"><animateMotion dur="' + d + 's" begin="' + bg + 's" repeatCount="indefinite" path="M' + P2(a) + 'Q' + mx + ' ' + my + ' ' + P2(b) + '"/>' + an('opacity', '1;1;0', d, bg) + '</circle>'; });
      return { front: f }; } });
  // classic kettle cart; conc = marble concession counter with nacho warmer; royal = gilded carriage
  N.popCart = S => { const royal = !!S.royal, conc = !!S.conc, fr = royal ? GOLD : conc ? GOLD : '#d5dde2', body = royal ? '#7f2030' : conc ? '#f2efea' : '#d9363b', CX = conc ? -24 : 0, BH = conc ? 46 : 40, BY = conc ? 0 : royal ? 10 : 7, Y0 = BY + BH, W = 46, D = 34, H = 42;
    return { w: conc ? 116 : royal ? 84 : 64, d: conc ? 50 : 46, glow: () => ({ y: Y0 + 26, r: 44, c: 'url(#gWarm)' }), build: P => { const o = [];
      if (conc) { o.push(box(0, 0, 0, 112, 4, 46, '#1d1d20', { r: 1 }), box(0, 4, 0, 110, BH - 6, 44, body, cer({ r: 2 })), box(0, BH - 2, 0, 114, 2, 48, GOLD, mt({ r: 2 })));
        [-36, 0, 36].forEach(x => o.push(slab(x, 9, 22.4, 30, BH - 18, 0.8, shade(body, 0.95), cer({ r: 2 })), box(x, 10, 23, 30, 0.6, 0.6, GOLD, mt({ r: 0, noOut: 1 }))));
        const R = rng('conc'); rep(5, () => o.push(box((R() - 0.5) * 90, 6 + R() * 30, 22.2, 20 + R() * 20, 0.5, 0.2, '#c9b98a', { r: 0, noOut: 1 }))); }
      else { if (royal) [-1, 1].forEach(sg => { const x = sg * 30; o.push(solid({ ax: 'x', sh: 'el', c: [0, 13], a: 13, b: 13, n: 18, rings: [[x - 1.6, 0], [x + 1.6, 0]], col: '#2c2420', mat: 'wood' }), solid({ ax: 'x', sh: 'el', c: [0, 13], a: 11.4, b: 11.4, n: 18, rings: [[x + sg * 1.7 - 0.1, 0], [x + sg * 1.7 + 0.1, 0]], col: GOLD, mat: 'metal' }), solid({ ax: 'x', sh: 'el', c: [0, 13], a: 2.4, b: 2.4, n: 10, rings: [[x - 3, 0], [x + 3, 0]], col: GOLD, mat: 'metal' }));
            rep(6, i => { const a = i / 6 * 2 * PI; [4.4, 7.4, 10.2].forEach(rr => o.push(ball(x + sg * 1.9, 13 + Math.sin(a) * rr - 0.9, Math.cos(a) * rr, 0.9, GOLD, mt({ k: 2, n: 6, noOut: 1 })))); }); });
        else [[-22, -14], [22, -14], [-22, 14], [22, 14]].forEach(([x, z]) => o.push(solid({ ax: 'x', sh: 'el', c: [z, 4], a: 4, b: 4, n: 12, rings: [[x - 1.5, 0], [x + 1.5, 0]], col: '#1d1d20' }), solid({ ax: 'x', sh: 'el', c: [z, 4], a: 1.6, b: 1.6, n: 8, rings: [[x - 1.7, 0], [x + 1.7, 0]], col: CH, mat: 'metal' })));
        o.push(box(CX, BY, 0, 52, BH, 38, body, pt({ r: 3 })), box(CX, Y0 - 3, 0, 54, 3, 40, fr, mt({ r: 2 })), slab(CX, BY + 5, 19.4, 40, BH - 13, 0.8, shade(body, 1.08), pt({ r: 2 })), box(CX, BY + 2, 19.6, 52, 1.4, 0.6, fr, mt({ r: 0, noOut: 1 })));
        if (royal) { o.push(slab(CX, BY + 9, 20.2, 30, BH - 21, 0.4, GOLD, mt({ r: 6, noOut: 1 })), slab(CX, BY + 11, 20.5, 26, BH - 25, 0.4, body, { r: 5, noOut: 1 })); [[-26, -19], [26, -19], [-26, 19], [26, 19]].forEach(([x, z]) => o.push(ball(x, Y0 - 2, z, 2.4, GOLD, mt({ k: 3, n: 8 })))); } }
      // glass case
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => o.push(cyl(CX + a * W / 2, Y0, b * D / 2, 1.4, H, fr, mt({ n: 8 }))));
      o.push(box(CX, Y0, 0, W + 4, 1.6, D + 4, fr, mt({ r: 1 })));
      heap(o, CX + 1, Y0 + 7, 2, 18, 12, 7, 26, 'pc' + S.nm, 1);
      o.push(cyl(CX - 4, Y0 + 34, -4, 0.8, 8, CH, mt({ n: 4 })), cyl(CX - 4, Y0 + 23, -4, 8.6, 9, royal ? GOLD : '#c9d3d8', mt({ n: 16, rg: [[0, 0, 0.82], [4, 0, 1], [9, 0, 1]] })), cyl(CX - 4, Y0 + 32, -4, 9, 1.2, '#9aa3a8', mt({ n: 16 })));
      rep(5, i => o.push(...kern(CX - 4 + (i - 2) * 2.6, Y0 + 32.4, -4 + (i % 2) * 2, 0.85, i)));
      o.push(ball(CX + 12, Y0 + 36, 6, 2.6, '#ffe9a0', em({ k: 3 })));
      o.push(box(CX, Y0 + 1.6, 0, W, H - 1.6, D, GL, cer({ r: 1, op: 0.16 })));
      o.push(box(CX, Y0 + H, 0, W + 6, 3, D + 6, fr, mt({ r: 1 })), box(CX, Y0 + H + 3, 0, W + 2, 4, D + 2, body, pt({ r: 2 })), slab(CX, Y0 + H + 7, 0, W - 4, 13, 3, royal ? '#7f2030' : '#d9363b', pt({ r: 3 })), slab(CX, Y0 + H + 8.2, 1.6, W - 7, 10.6, 0.4, royal ? GOLD : '#ffffff', { r: 2, noOut: 1 }));
      if (royal) { o.push(ball(CX, Y0 + H + 22, 0, 3.6, GOLD, mt({ k: 4 })), ...[-1, 1].map(s => ball(CX + s * 20, Y0 + H + 20, 0, 2.4, GOLD, mt({ k: 3 })))); rep(5, i => o.push(cyl(CX - 8 + i * 4, Y0 + H + 19.6, 0, 1, 4 + (i % 2) * 2, GOLD, mt({ n: 6, top: 0.9 })))); }
      if (conc) { const nx = 28; o.push(box(nx, BH, 0, 34, 3, 26, '#2c2d31', mt({ r: 2 })), box(nx, BH + 3, 0, 32, 1, 24, '#3a3c48', mt({ r: 1 })));
        const R = rng('nacho'); rep(16, i => o.push(solid({ ax: 'y', sh: 'poly', c: [nx - 12 + (i % 6) * 4.8, -8 + Math.floor(i / 6) * 7 + R() * 2], pts: [[0, 3.4], [3, -2], [-3, -2]], yaw: R() * PI * 2, rings: [[BH + 4 + (i % 3) * 0.7, 0], [BH + 4.6 + (i % 3) * 0.7, 0]], col: i % 4 ? '#f2c14a' : '#e8a83a', mat: 'paint' })));
        o.push(cyl(nx + 8, BH + 4, 4, 4.4, 2.6, '#ffffff', cer({ n: 14 })), cyl(nx + 8, BH + 6.2, 4, 3.8, 0.6, '#f6b62c', { n: 12 }));
        o.push(cyl(nx + 12, BH + 4, -8, 6, 16, '#f2d64a', pt({ n: 14 })), cyl(nx + 12, BH + 20, -8, 4, 3, CH, mt({ n: 12 })), cyl(nx + 12, BH + 23, -8, 1, 6, CH, mt({ n: 6 })), box(nx + 12, BH + 28, -4, 3, 2.4, 9, '#2c2d31', mt({ r: 1 })), box(nx + 12, BH + 25, 1, 1.6, 4, 1.6, CH, mt({ r: 0.6 }))); }
      return o; },
      fx: c => { const top = c.p(CX - 4, Y0 + 33.4, -4); let f = '';
        f += '<g transform="' + plane(c.p, 1.9, Y0 + H + 18.8) + ' translate(' + CX + ' 0)"><text x="0" y="8.2" text-anchor="middle" font-family="Georgia, \'Times New Roman\', serif" font-weight="700" font-size="7.4" textLength="' + (W - 12) + '" lengthAdjust="spacingAndGlyphs" fill="' + (royal ? '#7f2030' : '#d9363b') + '">POPCORN</text></g>';
        rep(7, i => { const end = c.p(CX + (i - 3) * 4.4, Y0 + 12, (i % 3) * 3 - 1), d = (1.5 + (i % 3) * 0.25).toFixed(2), bg = -(i * 0.31).toFixed(2), mid = [f1((top[0] + end[0]) / 2), f1(top[1] - (10 + (i % 2) * 6) * c.k)];
          f += '<circle r="' + f1(1.5 * c.k) + '" fill="#fff6dc" stroke="#e8c870" stroke-width="0.3"><animateMotion dur="' + d + 's" begin="' + bg + 's" repeatCount="indefinite" keyPoints="0;1" keyTimes="0;1" path="M' + P2(top) + 'Q' + mid[0] + ' ' + mid[1] + ' ' + P2(end) + '"/>' + an('opacity', '0;1;1;0', d, bg, '0;0.1;0.85;1') + '</circle>'; });
        const g = c.p(CX, Y0 + 24, 0); f += '<ellipse cx="' + P2(g).split(' ')[0] + '" cy="' + P2(g).split(' ')[1] + '" rx="' + f1(22 * c.k) + '" ry="' + f1(18 * c.k) + '" fill="#ffd66b" opacity="0.1">' + an('opacity', '0.05;0.18;0.05', 1.6) + '</ellipse>';
        if (royal) rep(3, i => f += spark(c, CX - 18 + i * 18, Y0 + H + 18, 2, 0.7, -i * 0.6, '#fff1c4'));
        if (conc) f += steam(c, 28, BH + 6, 0, 0.7, 3);
        return { front: f }; } }; };
  N.candyBar = S => ({ w: 120, d: 48, glow: () => ({ y: 70, r: 60, c: 'url(#gNeon)' }), build: P => { const o = [box(0, 0, 0, 116, 6, 42, '#2c2d31', mt({ r: 2 })), box(0, 6, -4, 112, 44, 34, '#f1eee8', cer({ r: 4 })), box(0, 50, -2, 116, 3, 40, CH, mt({ r: 2 }))];
      const CC = [['#ff6ad5', '#ffd66b'], ['#6ac8ff', '#ffffff'], ['#a6f06a', '#ff9d4a'], ['#d9363b', '#7a4a28']];
      CC.forEach(([a, b], i) => { const x = -42 + i * 18; o.push(cyl(x, 53, -8, 7, 4, '#3a3c48', mt({ n: 14 })), cyl(x, 57, -8, 6.6, 38, GL, cer({ n: 16, op: 0.25 })), cyl(x, 95, -8, 7.2, 3, '#3a3c48', mt({ n: 14 })));
        rep(13, j => o.push(ball(x + ((j % 3) - 1) * 3.4, 57.4 + Math.floor(j / 3) * 5.2 + (j % 2), -8 + ((j * 7) % 3 - 1) * 2.6, 2.2, j % 2 ? a : b, { k: 3, n: 8 })));
        o.push(box(x, 40, 13.6, 7, 6, 3, CH, mt({ r: 1 }))); });
      bucket(o, 36, 53, -6, 10, 18, 'cbb'); bucket(o, 18, 53, 8, 7, 13, 'cbs');
      o.push(slab(40, 18, 13.2, 30, 20, 0.6, '#1d2030', { r: 2 }), slab(40, 19.5, 13.6, 26, 17, 0.2, '#6ac8ff', em({ r: 1.5, op: 0.6 })));
      return o; },
    fx: c => { let f = ''; [0, 1, 2, 3].forEach(i => { const x = -42 + i * 18, a = c.p(x, 44, 14), b = c.p(x, 38, 16); f += '<circle r="' + f1(2 * c.k) + '" fill="' + ['#ff6ad5', '#6ac8ff', '#a6f06a', '#d9363b'][i] + '"><animateMotion dur="2.4s" begin="' + (-i * 0.6) + 's" repeatCount="indefinite" path="M' + P2(a) + 'L' + P2(b) + '"/>' + an('opacity', '1;1;0', 2.4, -i * 0.6) + '</circle>'; });
      f += '<g transform="' + plane(c.p, 14, 35) + ' translate(40 0)"><text x="0" y="0" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="4" fill="#ffffff">PICK A TREAT' + an('opacity', '1;0.4;1', 1.6) + '</text></g>';
      return { front: f }; } });

  // ---------- holograms ----------
  const holoFig = (c, x, y, z, s, dur) => { const q = c.p(x, y, z), u = c.k * s;
    const body = '<ellipse cx="0" cy="0" rx="' + f1(15 * u) + '" ry="' + f1(13 * u) + '" fill="url(#hgB)" stroke="#d8fbff" stroke-width="' + f1(0.7 * u) + '"/>' + [-1, 1].map(sg => '<ellipse cx="' + f1(sg * 9 * u) + '" cy="' + f1(-13 * u) + '" rx="' + f1(4 * u) + '" ry="' + f1(6.5 * u) + '" fill="url(#hgB)" stroke="#d8fbff" stroke-width="' + f1(0.6 * u) + '"/>').join('')
      + '<ellipse cx="0" cy="' + f1(4 * u) + '" rx="' + f1(8 * u) + '" ry="' + f1(6 * u) + '" fill="#e8fdff" opacity="0.35"/>' + [-1, 1].map(sg => '<ellipse cx="' + f1(sg * 5 * u) + '" cy="' + f1(-3 * u) + '" rx="' + f1(1.6 * u) + '" ry="' + f1(2.2 * u) + '" fill="#0a3a52"/>').join('')
      + '<path d="M' + f1(-3 * u) + ' ' + f1(2 * u) + 'Q0 ' + f1(5 * u) + ' ' + f1(3 * u) + ' ' + f1(2 * u) + '" fill="none" stroke="#0a3a52" stroke-width="' + f1(0.8 * u) + '" stroke-linecap="round"/>'
      + [-1, 1].map(sg => '<g transform="translate(' + f1(sg * 14 * u) + ' ' + f1(2 * u) + ')"><g>' + at('rotate', (sg * 10) + ';' + (sg * -40) + ';' + (sg * 10), 0.8, sg > 0 ? -0.4 : 0) + '<ellipse cx="' + f1(sg * 3 * u) + '" cy="0" rx="' + f1(4 * u) + '" ry="' + f1(2.4 * u) + '" fill="url(#hgB)" stroke="#d8fbff" stroke-width="' + f1(0.5 * u) + '"/></g></g>').join('');
    const scan = '<g clip-path="url(#hgC)" opacity="0.5"><g>' + at('translate', '0 ' + f1(-14 * u) + ';0 ' + f1(14 * u), 1.6) + rep(8, i => '<rect x="' + f1(-20 * u) + '" y="' + f1((-28 + i * 7) * u) + '" width="' + f1(40 * u) + '" height="' + f1(0.9 * u) + '" fill="#ffffff"/>').join('') + '</g></g>';
    return { defs: '<radialGradient id="hgB" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#e8fdff" stop-opacity="0.8"/><stop offset="1" stop-color="#4fc8f0" stop-opacity="0.35"/></radialGradient><clipPath id="hgC"><ellipse cx="0" cy="0" rx="' + f1(15 * u) + '" ry="' + f1(13 * u) + '"/><ellipse cx="' + f1(-9 * u) + '" cy="' + f1(-13 * u) + '" rx="' + f1(4 * u) + '" ry="' + f1(6.5 * u) + '"/><ellipse cx="' + f1(9 * u) + '" cy="' + f1(-13 * u) + '" rx="' + f1(4 * u) + '" ry="' + f1(6.5 * u) + '"/></clipPath>',
      svg: '<g transform="translate(' + P2(q) + ')"><g>' + at('translate', '0 0;0 ' + f1(-5 * u) + ';0 0', 1.6) + '<g>' + at('scale', '1 1;0.12 1;-1 1;0.12 1;1 1', dur || 6) + '<g>' + an('opacity', '0.9;0.9;0.4;0.9;0.9;0.6;0.9', 3.2, 0, '0;0.42;0.45;0.48;0.8;0.82;1') + body + scan + '</g></g></g></g>' }; };
  const ringH = (c, y, cz, r, col, w, dash, d, rev) => '<g transform="' + planeH(c.p, y) + ' translate(0 ' + cz + ')"><ellipse rx="' + r + '" ry="' + r + '" fill="none" stroke="' + col + '" stroke-width="' + w + '" stroke-dasharray="' + dash + '" filter="url(#gw2)">' + an('stroke-dashoffset', '0;' + (rev ? '' : '-') + f1(2 * PI * r), d) + '</ellipse></g>';
  const holo0 = N.holo; N.holo = S => { const D = holo0(S), f0 = D.fx; D.fx = c => { const F = f0 ? f0(c) || {} : {}; let f = '';
      f += ringH(c, 30, 0, 26, '#c9f4ff', 0.9, '6 4', 4) + ringH(c, 60, 0, 30, '#8fe8ff', 0.9, '3 5', 3, 1) + ringH(c, 84, 0, 31, '#e8fdff', 0.6, '10 8', 5);
      const a = c.p(0, 8, 0), b = c.p(0, 86, 0); f += '<g transform="translate(' + P2(a) + ')"><ellipse cx="0" cy="0" rx="' + f1(24 * c.k) + '" ry="' + f1(24 * c.k * X.SA) + '" fill="#c9f4ff" opacity="0.5">' + at('translate', '0 0;0 ' + f1(b[1] - a[1]), 2.4) + an('opacity', '0.6;0.6;0', 2.4) + an('rx', f1(24 * c.k) + ';' + f1(32 * c.k), 2.4) + '</ellipse></g>';
      rep(6, i => f += spark(c, (i % 3 - 1) * 18, 20 + i * 11, (i % 2 ? 1 : -1) * 8, 0.6, -i * 0.5, '#e8fdff', 2.4));
      let defs = (F.defs || '') + GLOW; if (/mascot|dancer|idol|stage/.test(S.nm)) { const H = holoFig(c, 0, 48, 0, 1.15, 5); defs += H.defs; f += H.svg; }
      return Object.assign({}, F, { defs, front: (F.front || '') + f }); }; return D; };
  // 3D Volumetric Hologram Stage & Acoustic Sculpture: plinth emitter, parametric walnut acoustic fins, dancing hologram, sound ripples
  N.holoStage = S => ({ w: 160, d: 120, glow: () => ({ y: 60, r: 92, c: 'url(#gNeon)' }), build: P => { const o = [];
      o.push(arcW(0, 0, 4, 76, 58, 10, 4, PI * 1.02, PI * 1.98, '#23252e', mt({ n: 20 })));
      rep(11, i => { const t = PI * (1.06 + 0.88 * i / 10), x = Math.cos(t) * 70, z = 4 + Math.sin(t) * 53, h = 52 + 62 * Math.pow(Math.sin(PI * (i + 0.5) / 11), 1.4) + (i % 2) * 8;
        o.push(box(x, 4, z, 16, h, 3.2, i % 2 ? '#6b4226' : '#7d5232', wd({ yaw: t, r: 1.4 })), box(x, 4 + h, z, 16.4, 1.4, 3.6, '#8fe8ff', em({ yaw: t, r: 0.6 }))); });
      o.push(cyl(0, 0, 14, 48, 6, '#1d1f28', mt({ n: 30 })), cyl(0, 6, 14, 47, 1.2, CH, mt({ n: 30 })), cyl(0, 7.2, 14, 44, 4, '#2a2d3a', mt({ n: 30 })), cyl(0, 11.2, 14, 36, 0.8, '#8fe8ff', em({ n: 30, op: 0.9 })), cyl(0, 11.2, 14, 22, 1.4, '#c9f4ff', em({ n: 24 })));
      rep(12, i => { const a = i / 12 * 2 * PI; o.push(ball(Math.cos(a) * 41, 11.2, 14 + Math.sin(a) * 41, 1.3, '#8fe8ff', em({ k: 2, n: 6 }))); });
      return o; },
    fx: c => { const e = c.p(0, 12, 14), tp = c.p(0, 104, 14), u = c.k; let f = '', under = '';
      f += '<path d="M' + f1(e[0] - 30 * u) + ' ' + f1(e[1]) + 'L' + f1(tp[0] - 40 * u) + ' ' + f1(tp[1]) + 'L' + f1(tp[0] + 40 * u) + ' ' + f1(tp[1]) + 'L' + f1(e[0] + 30 * u) + ' ' + f1(e[1]) + 'Z" fill="url(#hgCone)" opacity="0.7">' + an('opacity', '0.55;0.85;0.6;0.8;0.55', 2.2) + '</path>';
      f += ringH(c, 22, 14, 30, '#c9f4ff', 1, '8 5', 4) + ringH(c, 58, 14, 34, '#8fe8ff', 1, '4 6', 3, 1) + ringH(c, 94, 14, 38, '#e8fdff', 0.7, '14 9', 6);
      const H = holoFig(c, 0, 60, 14, 2.1, 6); f += H.svg;
      rep(10, i => { const x = (i % 5 - 2) * 12, z = 14 + (i % 2 ? 10 : -10), a = c.p(x, 14, z), b = c.p(x, 96, z), d = (2.6 + (i % 3) * 0.5).toFixed(1); f += '<circle cx="' + f1(a[0]) + '" cy="' + f1(a[1]) + '" r="' + f1(0.9 * u) + '" fill="#e8fdff">' + an('cy', f1(a[1]) + ';' + f1(b[1]), d, -i * 0.41) + an('opacity', '0;1;0', d, -i * 0.41) + '</circle>'; });
      rep(11, i => { const t = PI * (1.06 + 0.88 * i / 10), h = 52 + 62 * Math.pow(Math.sin(PI * (i + 0.5) / 11), 1.4) + (i % 2) * 8, x = Math.cos(t) * 70, z = 4 + Math.sin(t) * 53, a = c.p(x - Math.cos(t) * 8, 4 + h + 1.4, z - Math.sin(t) * 8), b = c.p(x + Math.cos(t) * 8, 4 + h + 1.4, z + Math.sin(t) * 8);
        f += '<path d="M' + P2(a) + 'L' + P2(b) + '" stroke="#e8fdff" stroke-width="' + f1(1.6 * u) + '" stroke-linecap="round" filter="url(#gw2)" opacity="0.2">' + an('opacity', '0.15;1;0.15', 1.2, -Math.abs(i - 5) * 0.12) + an('stroke', '#e8fdff;#8fe8ff;#b48cff;#e8fdff', 4.8) + '</path>'; });
      rep(3, i => under += '<g transform="' + planeH(c.p, 0.4) + ' translate(0 14)"><ellipse rx="50" ry="50" fill="none" stroke="#8fe8ff" stroke-width="1.4">' + an('rx', '48;92', 3, -i) + an('ry', '48;92', 3, -i) + an('opacity', '0.7;0', 3, -i) + '</ellipse></g>');
      return { defs: GLOW + H.defs + '<linearGradient id="hgCone" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#8fe8ff" stop-opacity="0.45"/><stop offset="1" stop-color="#8fe8ff" stop-opacity="0"/></linearGradient>', under, front: f }; } });

  // ---------- Royal Collection (most expensive piece per room) ----------
  const VEL = '#7f2030', VELD = '#5e1622', IVORY = '#f6efe0', MARB = '#f2efea';
  const veins = (o, R, x, y, z, w, d, n, col) => rep(n, () => o.push(box(x + (R() - 0.5) * w * 0.8, y, z + (R() - 0.5) * d * 0.7, 18 + R() * 26, 0.15, 0.8, col || '#c9b98a', { yaw: (R() - 0.5) * 1.6, r: 0, noOut: 1 })));
  const goldPost = (o, x, z, y, h, r) => o.push(cyl(x, y, z, r, h, GOLD, mt({ n: 10, rg: [[0, 0, 1.5], [h * 0.06, 0, 1.1], [h * 0.12, 0, 1.5], [h * 0.16, 0, 0.9], [h * 0.84, 0, 0.9], [h * 0.9, 0, 1.4], [h, 0, 1]] })), ball(x, y + h, z, r * 1.5, GOLD, mt({ k: 4, n: 10 })));
  const tuftGrid = (o, x0, x1, y0, y1, z, cols, rows, col, btn) => rep(rows, j => rep(cols - (j % 2), i => { const x = x0 + (x1 - x0) * (i + (j % 2 ? 1 : 0.5)) / cols, y = y0 + (y1 - y0) * (j + 0.5) / rows; o.push(ball(x, y, z, 3, shade(col, 0.78), { sz: 0.22, k: 3, n: 8, noOut: 1, shine: 0 }), ball(x, y, z + 0.6, 1.4, btn, mt({ k: 3, n: 6, noOut: 1 }))); }));
  N.luxCoffee = S => ({ w: 132, d: 80, topH: 41.2, topW: 96, build: P => { const o = [], R = rng('rococo');
      [[-46, -22], [46, -22], [-46, 22], [46, 22]].forEach(([x, z]) => o.push(ball(x * 1.06, 0, z * 1.1, 3.6, GOLD, mt({ k: 4, n: 10 })), cyl(x, 3, z, 2.8, 28, GOLD, mt({ n: 10, rg: [[0, 0, 0.9], [7, 0, 0.62], [18, 0, 0.9], [25, 0, 1.6], [28, 0, 1.3]] }))));
      o.push(cyl(0, 28, 0, 54, 7, GOLD, mt({ rz: 30, n: 30 })), cyl(0, 22, 0, 10, 6, GOLD, mt({ n: 14, rg: [[0, 0, 0.4], [6, 0, 1]] })));
      [[0, 30.6], [0, -30.6]].forEach(([x, z]) => o.push(ball(x, 27, z, 6, GOLD, mt({ sy: 0.7, sz: 0.35, k: 4, n: 12 }))));
      [[-54, 0], [54, 0]].forEach(([x, z]) => o.push(ball(x, 28, z, 4.4, GOLD, mt({ sx: 0.35, sy: 0.8, k: 4, n: 10 }))));
      o.push(cyl(0, 35, 0, 62, 1.4, GOLD, mt({ rz: 36, n: 32 })), cyl(0, 36.4, 0, 61, 4.4, MARB, cer({ rz: 35, n: 32 }))); veins(o, R, 0, 40.85, 0, 100, 56, 7);
      o.push(cyl(-20, 40.8, -2, 18, 1.2, GOLD, mt({ rz: 11, n: 20 })), arcW(-20, 42, -2, 18, 11, 1, 1.4, 0, 2 * PI, GOLD, mt({ n: 20 })));
      o.push(cyl(-24, 42, -4, 5.4, 9, GL, cer({ n: 16, op: 0.38, rg: [[0, 0, 0.9], [5, 0, 1], [9, 0, 0.42]] })), cyl(-24, 42.3, -4, 4.8, 5.2, '#b8692a', { n: 14, op: 0.85 }), cyl(-24, 51, -4, 1.7, 5, GL, cer({ n: 10, op: 0.45 })), ball(-24, 55.6, -4, 2.4, '#e8f6ff', cer({ k: 4, op: 0.7 })));
      [[-12, 2], [-16, 5]].forEach(([x, z]) => o.push(cyl(x, 42, z, 2.8, 5.6, GL, cer({ n: 12, op: 0.35, rg: [[0, 0, 0.9], [5.6, 0, 1]] })), cyl(x, 42.3, z, 2.4, 2.2, '#b8692a', { n: 12, op: 0.85 })));
      o.push(cyl(22, 40.8, -4, 6, 12, IVORY, cer({ n: 16, rg: [[0, 0, 0.7], [6, 0, 1], [12, 0, 0.6]] })), cyl(22, 52.8, -4, 4.4, 1.2, GOLD, mt({ n: 14 })));
      [[0, 0, '#c8243a'], [-4, 3, '#f6a8c4'], [4, 2, '#fff2f6'], [-2, -4, '#e94a6a'], [3, -3, '#f6a8c4'], [0, 1, '#c8243a']].forEach(([dx, dz, cc], i) => o.push(ball(22 + dx, 54 + (i === 5 ? 5 : 0) + (i % 2) * 2, -4 + dz, 3, cc, { k: 4, n: 10 })));
      rep(5, i => { const a = i / 5 * 2 * PI; o.push(ball(22 + Math.cos(a) * 7, 54, -4 + Math.sin(a) * 6, 2.4, '#4f8a3a', { sx: 1.6, sy: 0.3, k: 2, n: 8, yaw: a })); });
      o.push(box(30, 40.8, 14, 22, 2.6, 15, '#1f4f3e', { r: 1, mat: 'paint', yaw: 0.25 }), box(30, 43.4, 14, 20, 2.2, 14, VEL, { r: 1, mat: 'paint', yaw: 0.1 }));
      return o; }, fx: c => ({ front: [spark(c, -24, 50, -4, 0.6, 0, '#ffffff'), spark(c, 0, 38, 36, 0.7, -0.9, '#fff1c4'), spark(c, -46, 32, 24, 0.6, -1.4, '#fff1c4')].join('') }) });
  N.luxPatis = S => ({ w: 128, d: 60, glow: () => ({ y: 74, r: 64, c: 'url(#gWarm)' }), build: P => { const o = [], R = rng('patis'), Y = 42, W = 112, D = 44;
      o.push(box(0, 0, 0, 120, 4, 54, GOLD, mt({ r: 2 })), box(0, 4, 0, 116, Y - 6, 52, MARB, cer({ r: 2 })), box(0, Y - 2, 0, 120, 2, 56, GOLD, mt({ r: 2 }))); veins(o, R, 0, 20, 26.2, 100, 0.1, 0);
      [-38, 0, 38].forEach(x => o.push(slab(x, 9, 26.4, 32, Y - 18, 0.8, '#f8f5ef', cer({ r: 2 })), box(x, 9, 26.9, 32, 0.6, 0.6, GOLD, mt({ r: 0, noOut: 1 })), box(x, Y - 9, 26.9, 32, 0.6, 0.6, GOLD, mt({ r: 0, noOut: 1 })), ball(x, Y - 16, 27.2, 2.2, GOLD, mt({ sz: 0.5, k: 3 }))));
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => o.push(cyl(a * W / 2, Y, b * D / 2, 1.6, 54, GOLD, mt({ n: 8 }))));
      // shelf 1: cakes + strawberry tart
      const cake = (x, z, c1, c2) => { o.push(cyl(x, Y, z, 10, 1, '#f4f1ea', cer({ n: 16 })), cyl(x, Y + 1, z, 8.4, 8, c1, pt({ n: 18 })), cyl(x, Y + 9, z, 8.4, 1.2, c2, pt({ n: 18 }))); rep(6, i => { const a = i / 6 * 2 * PI; o.push(ball(x + Math.cos(a) * 6, Y + 10.2, z + Math.sin(a) * 6, 1.6, '#ffffff', { sy: 0.8, k: 3, n: 6 })); }); o.push(...straw(x, Y + 10.6, z, 0.75)); };
      cake(-34, -4, '#6b3a22', '#3a2010'); cake(32, -4, '#fdf3f0', '#f6c6d2');
      o.push(cyl(0, Y, 0, 12, 3, '#e0a85a', pt({ n: 20 })), cyl(0, Y + 3, 0, 10.4, 0.6, '#fff2c8', { n: 18 })); rep(9, i => { const a = i / 9 * 2 * PI; o.push(...straw(Math.cos(a) * 6.6, Y + 3.4, Math.sin(a) * 6.6, 0.7)); }); o.push(...straw(0, Y + 3.4, 0, 0.8));
      o.push(box(0, Y + 18, 0, W - 2, 0.8, D - 2, GL, cer({ r: 1, op: 0.35 })), box(0, Y + 36, 0, W - 2, 0.8, D - 2, GL, cer({ r: 1, op: 0.35 })));
      // shelf 2: macaron rows
      const MAC = ['#f6a8c4', '#a6e0c8', '#c9a6f0', '#ffd66b', '#f6c69a', '#bfe4ff'];
      rep(3, j => rep(6, i => { const x = -36 + i * 14.4, z = -10 + j * 10, cc = MAC[(i + j * 2) % 6]; o.push(cyl(x, Y + 18.8, z, 3.4, 1.6, cc, pt({ n: 14, rg: [[0, 0, 0.9], [1.6, 0, 1]] })), cyl(x, Y + 20.4, z, 3, 1, '#fff6ea', { n: 12 }), cyl(x, Y + 21.4, z, 3.4, 1.8, cc, pt({ n: 14, rg: [[0, 0, 1], [1.8, 0, 0.82]] }))); }));
      // shelf 3: croissants + pain au chocolat
      const croissant = (x, z, yw) => rep(5, i => { const t = (i - 2) * 0.5, r = 6; o.push(ball(x + Math.sin(t + yw) * r, Y + 36.8, z + (Math.cos(t) * r - r) * 0.8 + Math.cos(yw) * 0, 3.6 - Math.abs(i - 2) * 0.9, i % 2 ? '#d99a4a' : '#c8803a', { sy: 0.75, k: 3, n: 10 })); });
      rep(4, i => croissant(-36 + i * 22, -4, 0)); rep(3, i => o.push(box(-26 + i * 22, Y + 36.8, 10, 12, 4, 7, '#d9a35a', pt({ r: 2 })), box(-26 + i * 22, Y + 40.8, 10, 2, 0.5, 6, '#3a2010', { r: 0.3, noOut: 1 })));
      o.push(box(0, Y + 1, 0, W, 53, D, GL, cer({ r: 1, op: 0.13 })));
      o.push(box(0, Y + 54, 0, W + 8, 3, D + 8, GOLD, mt({ r: 1 })), box(0, Y + 57, 0, W + 4, 5, D + 4, MARB, cer({ r: 2 })), slab(0, Y + 62, 0, 44, 10, 3, GOLD, mt({ r: 5 })), ball(0, Y + 72, 0, 4, GOLD, mt({ k: 4 })));
      [-1, 1].forEach(s => o.push(ball(s * 28, Y + 62, 0, 2.6, GOLD, mt({ k: 3 }))));
      o.push(box(0, Y + 52.4, 0, W - 6, 1, 4, '#fff2b0', em({ r: 0.5 })));
      return o; },
    fx: c => ({ front: '<g transform="' + plane(c.p, 1.6, 113) + '"><text x="0" y="0" text-anchor="middle" font-family="Georgia, serif" font-style="italic" font-weight="700" font-size="5.4" fill="#7f2030">Pâtisserie</text></g>' + rep(4, i => spark(c, -40 + i * 26, 60 + (i % 2) * 18, 22, 0.6, -i * 0.5, '#ffffff')).join('') }) });
  N.luxRecliner = S => { const n = 3, SW = 60, AW = 16, Wd = n * SW + (n + 1) * AW, xs = rep(n, i => -Wd / 2 + AW + SW / 2 + i * (SW + AW));
    return { w: Wd + 6, d: 104, act: 'sit', seats: xs.map(x => ({ x, z: 6, h: 44 })), build: P => { const o = [], v = VEL, vL = shade(VEL, 1.12), vD = VELD;
      o.push(box(0, 0, 0, Wd + 6, 6, 98, '#1d1d20', { r: 2 }), box(0, 1.4, 48.6, Wd, 1.4, 1, '#ffd66b', em({ r: 0.4 })));
      xs.forEach(x => { o.push(box(x, 6, 4, SW, 26, 86, vD, fb({ r: 6 })), seatC(x, 32, 8, SW - 4, 10, 62, vL), box(x, 8, 47.4, SW - 6, 22, 3, vD, fb({ r: 6 })));
        o.push(slab(x, 6, -38, SW, 82, 16, v, fb({ r: 14, rb: 0 })), backC(x, 32, 84, -30, -18, SW - 8, vL));
        [0.3, 0.55].forEach(t => o.push(slabX(x, 32 + 52 * t, -17.6, SW - 14, 0.8, 0.8, GOLD, mt({ r: 0.3, noOut: 1 }))));
        o.push(pillowZ(x, 76, -14, SW - 22, 14, 8, shade(VEL, 1.25)), slabX(x, 86.4, -36, SW - 10, 1.4, 6, GOLD, mt({ r: 0.6 })), box(x - 6, 26, 48, 12, 2.6, 1, GOLD, mt({ r: 0.6, noOut: 1 }))); });
      rep(n + 1, i => { const x = -Wd / 2 + AW / 2 + i * (SW + AW); o.push(box(x, 6, 2, AW, 40, 92, v, fb({ r: 6 })), box(x, 46, 2, AW + 2, 3, 94, GOLD, mt({ r: 2 })), arcW(x, 49, 30, 5, 5, 1, 1.6, 0, 2 * PI, GOLD, mt({ n: 14 })), cyl(x, 49, 30, 4, 0.4, '#1d1d20', { n: 12 }));
        if (i === 1 || i === 2) { bucket(o, x, 49.4, 30, 4.4, 9, 'rc' + i); } else o.push(cyl(x, 49.4, 30, 3.4, 10, '#d9363b', pt({ n: 12 })), cyl(x, 59.4, 30, 3.6, 1.2, '#ffffff', { n: 12 }), cyl(x + 1, 60.6, 30, 0.5, 6, '#ffffff', { n: 4 })); });
      return o; }, fx: c => ({ front: rep(3, i => spark(c, -60 + i * 60, 48, 46, 0.6, -i * 0.7, '#fff1c4')).join('') }) }; };
  N.luxTub = S => ({ w: 120, d: 64, act: 'sit', seats: [{ x: 4, z: 0, h: 30 }], build: P => { const o = [];
      [[-34, -14], [34, -14], [-34, 14], [34, 14]].forEach(([x, z]) => { o.push(cyl(x, 3, z, 3, 9, GOLD, mt({ n: 10, rg: [[0, 0, 1.2], [4, 0, 0.7], [9, 0, 1.2]] }))); rep(3, i => o.push(ball(x + (i - 1) * 2.6, 0, z + Math.sign(z) * 2.4, 1.8, GOLD, mt({ sy: 0.8, k: 3, n: 8 })))); });
      o.push(solid({ ax: 'y', sh: 'el', c: [0, 0], a: 47, b: 25, n: 32, rings: [[10, 0, 0.82], [14, 0, 0.9], [26, 0, 0.98], [33, 0, 1]], col: VEL, mat: 'paint' }), arcW(0, 33, 0, 48.4, 26.4, 4.4, 2, 0, 2 * PI, GOLD, mt({ n: 32 })), cyl(0, 33.4, 0, 43, 1.2, '#a9dcef', { rz: 21.6, n: 30, op: 0.92 }));
      rep(4, i => { const a = PI * (0.1 + i * 0.27); o.push(ball(Math.cos(a) * 46, 22, Math.sin(a) * 25, 2.2, GOLD, mt({ sz: 0.5, sx: 0.5, k: 3, n: 8 }))); });
      const R = rng('foam'); rep(18, i => { const a = R() * 2 * PI, t = 0.3 + R() * 0.6; o.push(ball(10 + Math.cos(a) * 30 * t, 33.6, Math.sin(a) * 15 * t, 2.4 + R() * 2.4, '#ffffff', { sy: 0.65, k: 3, n: 10 })); });
      o.push(cyl(-50, 0, 0, 2.2, 46, GOLD, mt({ n: 10 })), box(-45, 44, 0, 10, 2.4, 2.4, GOLD, mt({ r: 1 })), cyl(-40, 40, 0, 1.6, 4, GOLD, mt({ n: 8 })), ...[-1, 1].map(s => ball(-50, 40, s * 4, 2, '#fffaf1', cer({ k: 3 }))), cyl(-50, 46, 0, 3, 1.4, GOLD, mt({ n: 10 })));
      o.push(box(16, 35.2, 0, 10, 1.4, 54, '#6b4226', wd({ r: 1 })), cyl(16, 36.6, -12, 2.4, 5, IVORY, { n: 10 }), ball(16, 41.6, -12, 1, '#ffd66b', em({ sy: 1.6 })), box(16, 36.6, 8, 7, 1.6, 9, '#2f4870', { r: 0.6, mat: 'paint' }));
      rep(5, i => o.push(ball(-10 + i * 8, 34.6, (i % 2 ? 1 : -1) * 6, 1.4, '#c8243a', { sy: 0.3, k: 2, n: 6, noOut: 1 })));
      return o; },
    fx: c => { let f = steam(c, -6, 36, 0, 0.9, 4); rep(8, i => { const a = c.p(-12 + i * 6, 36, (i % 3 - 1) * 6), d = (2 + (i % 3) * 0.4).toFixed(1); f += '<circle cx="' + f1(a[0]) + '" cy="' + f1(a[1]) + '" r="' + f1((1 + (i % 3) * 0.5) * c.k) + '" fill="#ffffff" fill-opacity="0.25" stroke="#ffffff" stroke-width="0.4">' + an('cy', f1(a[1]) + ';' + f1(a[1] - 26 * c.k), d, -i * 0.43) + an('opacity', '0;1;0', d, -i * 0.43) + '</circle>'; });
      f += '<g transform="' + planeH(c.p, 34.7) + '">' + rep(2, i => '<ellipse cx="-30" cy="0" rx="3" ry="2" fill="none" stroke="#ffffff" stroke-width="0.5">' + an('rx', '2;12', 2, -i) + an('ry', '1.4;8', 2, -i) + an('opacity', '0.8;0', 2, -i) + '</ellipse>').join('') + '</g>';
      return { front: f }; } });
  N.luxVanity = S => ({ w: 146, d: 54, build: P => { const o = [], ON = '#26232b', R = rng('vanity');
      [[-64, -18], [64, -18], [-64, 18], [64, 18]].forEach(([x, z]) => o.push(cyl(x, 0, z, 2.2, 30, GOLD, mt({ n: 10, rg: [[0, 0, 1.4], [3, 0, 0.8], [30, 0, 1]] }))));
      o.push(box(0, 8, 0, 128, 2, 40, GOLD, mt({ r: 1 })), slab(0, 36, -21.6, 140, 64, 3, ON, { r: 2, mat: 'cer' }), box(0, 30, 0, 140, 6, 46, ON, cer({ r: 2 })), box(0, 29.4, 0, 141.4, 1.2, 47.4, GOLD, mt({ r: 2 })), slabX(0, 99.4, -22.6, 142, 2, 4, GOLD, mt({ r: 1 }))); veins(o, R, 0, 36.05, 0, 130, 40, 8, GOLD);
      [-34, 34].forEach(x => { o.push(cyl(x, 36, 4, 13, 9, '#fbf8f2', cer({ n: 22, rg: [[0, 0, 0.55], [4, 0, 0.9], [9, 0, 1]] })), arcW(x, 44.4, 4, 13, 13, 1.4, 0.6, 0, 2 * PI, GOLD, mt({ n: 22 })), cyl(x, 43.6, 4, 11, 0.6, '#bfe4f2', { n: 20, op: 0.9 }));
        o.push(cyl(x, 36, -16, 1.8, 24, GOLD, mt({ n: 8 })), box(x, 58, -11, 2.4, 2.4, 11, GOLD, mt({ r: 1 })), cyl(x, 54, -6, 1.2, 4, GOLD, mt({ n: 6 })), ...[-1, 1].map(s => ball(x + s * 4, 36, -16, 1.8, GOLD, mt({ k: 3 }))));
        o.push(disc(x, 74, -21, 19, 1.4, GOLD, mt({ n: 26 })), disc(x, 74, -19.6, 17, 0.6, '#d8eef5', cer({ n: 24 })), ...rep(8, i => { const a = i / 8 * 2 * PI; return ball(x + Math.cos(a) * 19, 74 + Math.sin(a) * 19, -19.6, 1.6, GOLD, mt({ k: 3, n: 8 })); })); });
      [-66, 0, 66].forEach(x => o.push(cyl(x, 72, -20, 1.4, 6, GOLD, mt({ n: 6 })), cyl(x, 78, -16, 3.6, 7, '#fff6e2', { n: 12, rg: [[0, 0, 0.7], [7, 0, 1]] }), ball(x, 79, -16, 1.6, '#ffe9a0', em({ k: 3 }))));
      o.push(cush(0, 10, 0, 30, 6, 22, '#fffaf1'), cush(0, 16, 0, 28, 5, 20, '#f6efe0'), box(0, 36, 12, 10, 1.6, 7, GOLD, mt({ r: 2 })), ball(0, 37.6, 12, 3, '#f6a8c4', { sy: 0.5, k: 3 }));
      [[-8, 0, '#f6a8c4'], [8, -4, '#d8a03a']].forEach(([x, z, cc]) => o.push(cyl(x, 36, z - 10, 3, 8, cc, cer({ n: 12, op: 0.7 })), cyl(x, 44, z - 10, 1.4, 3, GOLD, mt({ n: 8 }))));
      return o; }, glow: () => ({ y: 80, r: 72, c: 'url(#gWarm)' }), fx: c => ({ front: [-34, 34].map((x, i) => spark(c, x - 6, 82, -19, 0.8, -i * 0.9, '#ffffff')).join('') }) });
  N.luxBed = S => ({ w: 140, d: 156, act: 'sit', seats: [{ x: -26, z: -10, h: 44 }, { x: 26, z: -10, h: 44 }], build: P => { const o = [], EB = '#2c2420', IV = '#fffaf1', HB = 76, PH = 150;
      [[-62, -72], [62, -72], [-62, 74], [62, 74]].forEach(([x, z]) => goldPost(o, x, z, 0, PH, 3));
      o.push(box(0, 6, 1, 120, 16, 142, EB, wd({ r: 3 })), box(0, 6, 72.4, 120, 1.2, 1, GOLD, mt({ r: 0, noOut: 1 })), box(0, 20.6, 72.4, 120, 1.2, 1, GOLD, mt({ r: 0, noOut: 1 })), box(0, 22, 2, 116, 14, 138, IV, fb({ r: 6 })));
      o.push(slab(0, 22, -71, 118, HB, 6, VEL, fb({ r: 16, rb: 0 }))); tuftGrid(o, -52, 52, 40, 92, -67.6, 7, 4, VEL, GOLD);
      o.push(solid({ ax: 'z', sh: 'arc', c: [0, 22 + HB - 30], a: 60, b: 34, th: 3, a0: 0.12, a1: PI - 0.12, n: 16, rings: [[-74.6, 0], [-67.4, 0]], col: GOLD, mat: 'metal' }), ball(0, 22 + HB + 3, -71, 5, GOLD, mt({ sz: 0.5, k: 4 })));
      o.push(box(0, 36, 18, 122, 6, 106, IVORY, fb({ r: 8, bev: 3 })), box(0, 42, -30, 122, 2.6, 12, VEL, fb({ r: 3 })), box(0, 42, 52, 124, 2.4, 26, VEL, fb({ r: 3 })), box(0, 43.6, 39.6, 124, 0.8, 1.2, GOLD, mt({ r: 0, noOut: 1 })));
      [-1, 1].forEach(sg => { o.push(box(sg * 62.6, 24, 52, 1.6, 20, 26, VEL, fb({ r: 1 })), box(sg * 62.8, 22.6, 52, 1.8, 1.6, 26.4, GOLD, mt({ r: 0, noOut: 1 }))); rep(7, i => o.push(box(sg * 62.8, 19.6, 41 + i * 3.6, 0.8, 3, 0.8, GOLD, mt({ r: 0, noOut: 1 })))); });
      [-1, 1].forEach(sg => o.push(pillowZ(sg * 28, 36, -60, 50, 30, 12, IV), throwP(sg * 18, 36, -48.4, 22, sg < 0 ? VEL : '#1f4f3e')));
      o.push(solid({ ax: 'z', sh: 'rr', c: [0, 44], a: 16, b: 8, r: 7, rings: [[-48.4, 3, 0.82], [-46.4, 0.6, 0.97], [-44, 0, 1], [-41.6, 0.6, 0.97], [-39.6, 3, 0.82]], col: GOLD, soft: 1, mat: 'fab' }));
      [-1, 1].forEach(sg => { o.push(slabX(0, PH - 2, sg * 73, 128, 4, 4, GOLD, mt({ r: 1 })), box(sg * 62, PH - 2, 1, 4, 4, 146, GOLD, mt({ r: 1 }))); });
      o.push(slab(0, PH - 14, 76, 122, 12, 1.4, VEL, fb({ r: 2 })), box(0, PH - 15, 76.8, 122, 1.4, 1, GOLD, mt({ r: 0, noOut: 1 })), slab(0, PH - 14, -76, 122, 12, 1.4, VEL, fb({ r: 2 })));
      [-1, 1].forEach(sg => o.push(slabX(sg * 64, PH - 14, 0, 1.4, 12, 146, VEL, fb({ r: 2 })), box(sg * 64.8, PH - 15, 0, 1, 1.4, 146, GOLD, mt({ r: 0, noOut: 1 }))));
      [[-56, 74], [56, 74], [-56, -70], [56, -70]].forEach(([x, z], i) => { o.push(cyl(x, 16, z, 6, PH - 30, VEL, fb({ rz: 3.4, n: 12, rg: [[0, 0, 1.7], [40, 0, 0.75], [52, 0, 0.5], [62, 0, 0.8], [PH - 30, 0, 1.2]] })), ball(x, 66, z + (z > 0 ? 3 : 0), 2.4, GOLD, mt({ sy: 1.6, k: 3 }))); });
      return o; }, fx: c => ({ front: rep(3, i => spark(c, -40 + i * 40, 148, 76, 0.7, -i * 0.6, '#fff1c4')).join('') }) });
  N.luxDresser = S => ({ w: 116, d: 52, topH: 66, topW: 80, build: P => { const o = [], MIR = '#d4e2e8', R = rng('dresser');
      [[-50, -18], [50, -18], [-50, 18], [50, 18]].forEach(([x, z]) => o.push(cyl(x, 0, z, 2.6, 10, GOLD, mt({ n: 10, rg: [[0, 0, 0.6], [4, 0, 1.2], [10, 0, 1]] }))));
      o.push(box(0, 10, 0, 108, 52, 44, MIR, cer({ r: 2 })), box(0, 62, 0, 112, 4, 48, MARB, cer({ r: 2 })), box(0, 61.4, 0, 112.8, 1, 48.8, GOLD, mt({ r: 2 }))); veins(o, R, 0, 66.05, 0, 100, 40, 5);
      rep(3, j => rep(2, i => { const x = (i ? 1 : -1) * 26, y = 14 + j * 16; o.push(slab(x, y, 22.4, 50, 14, 0.8, shade(MIR, 1.04), cer({ r: 1 })), box(x, y + 13.6, 22.9, 50, 0.6, 0.6, GOLD, mt({ r: 0, noOut: 1 })), ball(x, y + 6.4, 23.6, 2, '#f4fbff', cer({ k: 4, n: 10, op: 0.92 })), ball(x, y + 6.4, 23.2, 2.6, GOLD, mt({ sz: 0.3, k: 3, n: 10 }))); }));
      o.push(slab(0, 12, 22.6, 1, 48, 0.6, GOLD, mt({ r: 0, noOut: 1 })));
      o.push(solid({ ax: 'z', sh: 'el', c: [0, 102], a: 26, b: 34, n: 26, rings: [[-20, 0], [-17.6, 0]], col: GOLD, mat: 'metal' }), solid({ ax: 'z', sh: 'el', c: [0, 102], a: 22.6, b: 30.6, n: 24, rings: [[-17.6, 0], [-17, 0]], col: '#dbeef5', mat: 'cer' }), ball(0, 135, -19, 4.4, GOLD, mt({ sz: 0.5, k: 4 })), box(0, 66, -18.6, 14, 4, 4, GOLD, mt({ r: 1 })));
      o.push(box(-34, 66, 2, 20, 9, 14, VEL, pt({ r: 1.4 })), box(-34, 75, 2, 21, 1.6, 15, GOLD, mt({ r: 1 })), ball(-34, 76.6, 2, 1.6, '#f4fbff', cer({ k: 3 })));
      [[26, 4, '#f6a8c4'], [36, -4, '#d8a03a'], [34, 10, '#bfe4ff']].forEach(([x, z, cc], i) => o.push(cyl(x, 66, z, 3.4, 7 + i * 2, cc, cer({ n: 12, op: 0.72, rg: [[0, 0, 1], [5, 0, 1], [7 + i * 2, 0, 0.6]] })), ball(x, 73 + i * 2, z, 2, GOLD, mt({ k: 3 }))));
      rep(14, i => { const a = PI * (0.15 + i * 0.05); o.push(ball(-12 + Math.cos(a) * 10, 66, 10 + Math.sin(a) * 6, 1.1, '#fffaf1', cer({ k: 3, n: 6 }))); });
      return o; }, fx: c => ({ front: [spark(c, -8, 112, -17, 0.9, 0, '#ffffff'), spark(c, 10, 92, -17, 0.6, -0.8, '#ffffff'), spark(c, 26, 30, 23, 0.6, -1.3, '#ffffff')].join('') }) });
  N.luxFountain = S => ({ w: 124, d: 100, build: P => { const o = [], WT = '#7ec8e3';
      o.push(cyl(0, 0, 0, 51, 13, WT, { rz: 39, n: 32, op: 0.95 }), arcW(0, 0, 0, 56, 44, 6, 16, 0, 2 * PI, MARB, cer({ n: 32 })), arcW(0, 16, 0, 57, 45, 8, 1.8, 0, 2 * PI, GOLD, mt({ n: 32 })));
      o.push(cyl(0, 13, 0, 9, 24, MARB, cer({ n: 16, rg: [[0, 0, 1.3], [6, 0, 0.8], [18, 0, 0.7], [24, 0, 1]] })), cyl(0, 37, 0, 27, 7, MARB, cer({ n: 24, rg: [[0, 0, 0.35], [4, 0, 0.85], [7, 0, 1]] })), arcW(0, 44, 0, 27.6, 27.6, 2.4, 1.2, 0, 2 * PI, GOLD, mt({ n: 24 })), cyl(0, 43.2, 0, 25, 0.8, WT, { n: 22, op: 0.95 }));
      o.push(cyl(0, 44, 0, 4.6, 18, MARB, cer({ n: 12, rg: [[0, 0, 1.2], [9, 0, 0.75], [18, 0, 1]] })), cyl(0, 62, 0, 14, 5, MARB, cer({ n: 18, rg: [[0, 0, 0.35], [5, 0, 1]] })), arcW(0, 67, 0, 14.6, 14.6, 1.8, 1, 0, 2 * PI, GOLD, mt({ n: 18 })), cyl(0, 66.4, 0, 12.6, 0.6, WT, { n: 16, op: 0.95 }), ball(0, 67, 0, 4.2, GOLD, mt({ sy: 1.4, k: 5 })), ball(0, 78.4, 0, 1.6, GOLD, mt({ k: 3 })));
      const swan = (x, z, d) => { o.push(ball(x, 11.4, z, 7.4, GOLD, mt({ sx: 1.35, sy: 0.62, k: 5, n: 14 })), ball(x - d * 7, 15.4, z, 3.4, GOLD, mt({ sx: 1.2, sy: 1.2, k: 3, n: 10 })));
        [[3, 17], [4.6, 21], [4.4, 25], [3.2, 28.6]].forEach(([dx, y], i) => o.push(ball(x + d * dx, y, z, 1.9 - i * 0.12, GOLD, mt({ k: 3, n: 8 }))));
        o.push(ball(x + d * 1.6, 30.6, z, 2.2, GOLD, mt({ k: 3, n: 8 })), cyl(x - d * 0.4, 30.6, z, 0.7, 1.8, '#2c2420', { n: 4 })); };
      swan(-30, 16, 1); swan(30, -14, -1); swan(26, 18, -1); swan(-26, -16, 1);
      return o; },
    fx: c => { const u = c.k; let f = '';
      rep(10, i => { const a = PI * (0.1 + i * 0.09), s = c.p(Math.cos(a) * 27.6, 44, Math.sin(a) * 27.6), e = c.p(Math.cos(a) * 32, 13.4, Math.sin(a) * 32);
        f += '<path d="M' + P2(s) + 'Q' + f1(s[0] + (e[0] - s[0]) * 0.9) + ' ' + f1(s[1] + 2 * u) + ' ' + P2(e) + '" fill="none" stroke="#e6f6ff" stroke-width="' + f1(1.2 * u) + '" stroke-dasharray="' + f1(3 * u) + ' ' + f1(2 * u) + '" opacity="0.85">' + an('stroke-dashoffset', '0;-' + f1(10 * u), 0.5) + '</path>'; });
      rep(6, i => { const a = PI * (0.15 + i * 0.13), s = c.p(Math.cos(a) * 14.6, 67, Math.sin(a) * 14.6), e = c.p(Math.cos(a) * 24, 44, Math.sin(a) * 24);
        f += '<path d="M' + P2(s) + 'Q' + f1(s[0] + (e[0] - s[0]) * 0.9) + ' ' + f1(s[1]) + ' ' + P2(e) + '" fill="none" stroke="#e6f6ff" stroke-width="' + f1(1 * u) + '" stroke-dasharray="' + f1(2.4 * u) + ' ' + f1(1.6 * u) + '" opacity="0.85">' + an('stroke-dashoffset', '0;-' + f1(8 * u), 0.45) + '</path>'; });
      const t0 = c.p(0, 80, 0); rep(5, i => { const e = c.p(Math.cos(i * 1.26) * 10, 67, Math.sin(i * 1.26) * 10); f += '<path d="M' + P2(t0) + 'Q' + f1((t0[0] + e[0]) / 2) + ' ' + f1(t0[1] - 10 * u) + ' ' + P2(e) + '" fill="none" stroke="#e6f6ff" stroke-width="' + f1(0.9 * u) + '" stroke-dasharray="' + f1(2 * u) + ' ' + f1(1.6 * u) + '">' + an('stroke-dashoffset', '0;-' + f1(7 * u), 0.5) + '</path>'; });
      [[-30, 16, 1], [30, -14, -1], [26, 18, -1], [-26, -16, 1]].forEach(([x, z, d], i) => { const s = c.p(x + d * 3, 30.6, z), e = c.p(x + d * 16, 13.4, z); f += '<path d="M' + P2(s) + 'Q' + f1(s[0] + (e[0] - s[0]) * 0.5) + ' ' + f1(s[1] - 6 * u) + ' ' + P2(e) + '" fill="none" stroke="#e6f6ff" stroke-width="' + f1(0.8 * u) + '" stroke-dasharray="' + f1(2 * u) + ' ' + f1(1.4 * u) + '">' + an('stroke-dashoffset', '0;-' + f1(6.8 * u), 0.5, -i * 0.1) + '</path>'; });
      f += '<g transform="' + planeH(c.p, 13.2) + '">' + rep(4, i => '<ellipse cx="' + [-34, 34, 0, 10][i] + '" cy="' + [10, -6, 30, -30][i] + '" rx="2" ry="2" fill="none" stroke="#ffffff" stroke-width="0.7">' + an('rx', '2;12', 2.2, -i * 0.55) + an('ry', '2;12', 2.2, -i * 0.55) + an('opacity', '0.9;0', 2.2, -i * 0.55) + '</ellipse>').join('') + '</g>';
      f += rep(3, i => spark(c, [-30, 30, 0][i], [28, 28, 76][i], [16, -14, 0][i], 0.6, -i * 0.6, '#fff1c4')).join('');
      return { front: f }; } });
  // posts stand clear of the mattress and stop under the top rails (no finials in the canopy); curtains hang in front of / behind the posts; tie bands glued to the curtains
  N.luxDaybed = S => ({ w: 132, d: 112, act: 'sit', seats: [{ x: -24, z: 8, h: 26 }, { x: 24, z: 8, h: 26 }], build: P => { const o = [], PH = 124, SILK = '#f8f3ea', hp = PH - 11.2;
      o.push(box(0, 0, 0, 126, 10, 106, MARB, cer({ r: 2 })), box(0, 10, 0, 127, 1.2, 107, GOLD, mt({ r: 2 })), box(0, 11.2, 0, 106, 12, 84, SILK, fb({ r: 8 })));
      [[-58, -45], [58, -45], [-58, 45], [58, 45]].forEach(([x, z]) => o.push(cyl(x, 11.2, z, 2.4, hp, GOLD, mt({ n: 10, rg: [[0, 0, 1.5], [hp * 0.06, 0, 1.1], [hp * 0.12, 0, 1.5], [hp * 0.16, 0, 0.9], [hp * 0.84, 0, 0.9], [hp * 0.9, 0, 1.4], [hp, 0, 1]] }))));
      o.push(solid({ ax: 'x', sh: 'el', c: [-34, 31.2], a: 8, b: 8, n: 14, rings: [[-52, 0, 0.75], [-50, 0, 1], [50, 0, 1], [52, 0, 0.75]], col: '#1f4f3e', soft: 1, mat: 'fab' }));
      [[-34, '#e9c66a'], [-12, IVORY], [12, '#1f4f3e'], [34, '#e9c66a']].forEach(([x, cc]) => o.push(throwP(x, 23.2, -21.5, 22, cc)));
      [-1, 1].forEach(sg => { o.push(slabX(0, PH, sg * 48, 120, 3, 3, GOLD, mt({ r: 1 })), box(sg * 58, PH, 0, 3, 3, 98, GOLD, mt({ r: 1 }))); });
      o.push(solid({ ax: 'y', sh: 'rr', c: [0, 0], a: 64, b: 54, r: 10, rings: [[PH + 3, 0, 1], [PH + 7, 0, 0.92], [PH + 20, 0, 0.42], [PH + 25, 0, 0.12]], col: SILK, soft: 1, mat: 'fab' }), ball(0, PH + 24, 0, 4, GOLD, mt({ k: 4 })), cyl(0, PH + 31, 0, 0.8, 6, GOLD, mt({ n: 4 })));
      rep(5, i => { const x = -48 + i * 24; o.push(slab(x, PH - 8, 54.6, 22, 10.8, 1, SILK, fb({ r: 6 }))); }); [-1, 1].forEach(sg => rep(4, i => o.push(slabX(sg * 64.6, PH - 8, -36 + i * 24, 1, 10.8, 22, SILK, fb({ r: 6 }))))); // valances stop a hair under the canopy
      [[-59.5, 51.7], [59.5, 51.7], [-59.5, -51.7], [59.5, -51.7]].forEach(([x, z]) => { const C = cyl(x, 11.2, z, 5, PH - 19.2, SILK, fb({ rz: 2.2, n: 12, op: 0.82, rg: [[0, 0, 1.3], [37, 0, 0.6], [47, 0, 0.45], [57, 0, 0.8], [PH - 19.2, 0, 1.4]] })), T = ball(x, 54.6, z, 2.4, GOLD, mt({ sy: 1.5, sz: 0.6, k: 3 })); T.par = C; o.push(C, T); });
      return o; }, fx: c => ({ front: rep(3, i => spark(c, -40 + i * 40, 128, 50, 0.6, -i * 0.7, '#fff1c4')).join('') }) });
  N.luxBooth = S => { const R0 = 84, Rz = 62, a0 = PI * 1.04, a1 = PI * 1.96, zc = 20, n = 4, segs = rep(n, i => [a0 + (a1 - a0) * i / n, a0 + (a1 - a0) * (i + 1) / n]), PL = '#5a2a5e';
    const LB1 = P => [arcW(0, 0, zc, R0, Rz, 46, 3, a0, a1, GOLD, mt({ n: 20 })), arcW(0, 3, zc, R0, Rz, 12, 62, a0, a1, PL, fb({ n: 20 })), arcW(0, 65, zc, R0 + 0.6, Rz + 0.6, 13.2, 2, a0, a1, GOLD, mt({ n: 20 }))];
    const LB2 = P => rep(12, i => { const s0 = a0 + (a1 - a0) * i / 12 + 0.008, s1 = a0 + (a1 - a0) * (i + 1) / 12 - 0.008; return arcW(0, 19, zc, R0 - 12, Rz - 12, 6, 42, s0, s1, shade(PL, 1.16), fb({ n: 2 })); });
    return { w: R0 * 2 + 8, d: Rz * 2 + 10, act: 'sit', layers: [{ back: 1, build: LB1 }, { back: 1, build: LB2 }], seats: segs.map(s => { const m = (s[0] + s[1]) / 2; return { x: Math.cos(m) * 50, z: zc + Math.sin(m) * 37, h: 28 }; }), build: P => { const o = [];
      o.push(arcW(0, 3, zc, R0 - 12, Rz - 12, 34, 16, a0, a1, shade(PL, 0.85), fb({ n: 20 })));
      segs.forEach(([s0, s1]) => o.push(arcW(0, 19, zc, R0 - 18, Rz - 18, 28, 8, s0 + 0.01, s1 - 0.01, shade(PL, 1.1), fb({ n: 4 }))));
      const TT = cyl(0, 28, zc + 8, 24, 3, '#1a181e', cer({ n: 26 })), RIM = arcW(0, 28, zc + 8, 24.6, 24.6, 1.2, 3, 0, 2 * PI, GOLD, mt({ n: 26 })); RIM.par = TT;
      o.push(cyl(0, 0, zc + 8, 12, 2, GOLD, mt({ n: 18 })), cyl(0, 2, zc + 8, 3, 26, GOLD, mt({ n: 10 })), TT, RIM);
      // champagne tower: glasses spaced so no two bowls share a footprint box; ice bucket clear of the tower, bottle stands in its mouth, ice glued in
      const coupe = (x, y, z) => { o.push(cyl(x, y, z, 1.6, 0.6, GL, cer({ n: 8, op: 0.6 })), cyl(x, y + 0.6, z, 0.4, 3, GL, cer({ n: 4, op: 0.6 })), cyl(x, y + 3.6, z, 3.4, 2.2, '#f2d27a', { n: 12, op: 0.7, rg: [[0, 0, 0.3], [2.2, 0, 1]] })); };
      rep(6, i => { const a = i / 6 * 2 * PI; coupe(Math.cos(a) * 9, 31, zc + 8 + Math.sin(a) * 9); }); rep(3, i => { const a = i / 3 * 2 * PI + 0.5; coupe(Math.cos(a) * 5.2, 36.8, zc + 8 + Math.sin(a) * 5.2); }); coupe(0, 42.6, zc + 8);
      const BK = cyl(16, 31, zc - 2, 5, 9, GOLD, mt({ n: 14, rg: [[0, 0, 0.8], [9, 0, 1]] })); o.push(BK, cyl(16, 40, zc - 2, 2.4, 7.4, '#1f3a2a', { n: 10 }), cyl(16, 47.4, zc - 2, 1, 5, GOLD, mt({ n: 6 })));
      rep(5, i => { const c = ball(13.4 + (i % 3) * 2.6, 39.4, zc - 4 + (i % 2) * 4, 1.4, '#e8f6ff', cer({ k: 2, n: 6, op: 0.8 })); c.par = BK; c.fn = [0, 1, 0]; o.push(c); });
      return o; },
      fx: c => { let f = '', under = ''; rep(9, i => { const a = c.p((i % 3 - 1) * 4, 34 + Math.floor(i / 3) * 5, zc + 8 + (i % 2 ? 2 : -2)), d = (1.4 + (i % 3) * 0.3).toFixed(1); f += '<circle cx="' + f1(a[0]) + '" cy="' + f1(a[1]) + '" r="' + f1(0.5 * c.k) + '" fill="#fffbe0">' + an('cy', f1(a[1]) + ';' + f1(a[1] - 8 * c.k), d, -i * 0.21) + an('opacity', '0;1;0', d, -i * 0.21) + '</circle>'; });
        f += rep(3, i => spark(c, (i - 1) * 6, 46, zc + 8, 0.7, -i * 0.5, '#fff1c4')).join('');
        under = '<g transform="' + planeH(c.p, 0.3) + ' translate(0 ' + zc + ')"><ellipse rx="' + (R0 + 8) + '" ry="' + (Rz + 8) + '" fill="#b48cff" opacity="0.25">' + an('fill', '#b48cff;#ff6ad5;#6ac8ff;#b48cff', 4) + an('opacity', '0.15;0.35;0.15', 1.4) + '</ellipse></g>';
        return { under, front: f }; } }; };
  N.luxDJ = S => ({ w: 160, d: 96, pad: [0, 10, 0, 0], build: P => { const o = [], BK = '#16161b';
      o.push(box(0, 0, 0, 156, 10, 90, BK, mt({ r: 2 })), box(0, 9.4, 0, 157, 1.2, 91, GOLD, mt({ r: 2 })));
      o.push(box(0, 10.6, 14, 132, 46, 30, '#1d1d22', mt({ r: 2 })));
      rep(5, j => rep(14, i => o.push(slab(-61 + i * 9.4, 13 + j * 8.6, 29.4, 8.6, 7.8, 0.6, (i + j) % 3 ? '#cfd6e0' : '#e8eef4', mt({ r: 0.4 })))));
      o.push(box(0, 56.6, 14, 138, 3, 34, GOLD, mt({ r: 1 })));
      [-40, 40].forEach(x => { o.push(box(x, 59.6, 14, 34, 4, 28, '#2c2d31', mt({ r: 2 })), cyl(x - 2, 63.6, 15, 11, 1.2, '#111114', { n: 22 }), cyl(x - 2, 64.8, 15, 3, 0.4, GOLD, mt({ n: 12 })), box(x + 12, 63.6, 6, 1.4, 1.4, 14, CH, mt({ r: 0.6, yaw: 0.4 }))); });
      o.push(box(0, 59.6, 14, 26, 5, 24, '#2c2d31', mt({ r: 2 }))); rep(12, i => o.push(ball(-8 + (i % 4) * 5.4, 64.6, 5 + Math.floor(i / 4) * 5, 1.1, i % 4 === 3 ? '#ff6ad5' : CH, mt({ sy: 0.6, k: 2, n: 6 }))));
      rep(3, i => o.push(box(-6 + i * 6, 64.6, 20, 1.6, 1, 6, '#9aa3a8', mt({ r: 0.3 }))));
      o.push(box(0, 10.6, -24, 36, 22, 30, VEL, fb({ r: 6 })), slab(0, 32.6, -36, 38, 64, 8, VEL, fb({ r: 16, rb: 0 }))); tuftGrid(o, -14, 14, 40, 90, -31.6, 4, 4, VEL, GOLD);
      o.push(solid({ ax: 'z', sh: 'arc', c: [0, 80], a: 21, b: 18, th: 2.4, a0: 0.15, a1: PI - 0.15, n: 12, rings: [[-40.4, 0], [-31.6, 0]], col: GOLD, mat: 'metal' }), ball(0, 99, -36, 3.6, GOLD, mt({ k: 4 })));
      [-1, 1].forEach(s => o.push(box(s * 20, 10.6, -24, 4, 30, 30, GOLD, mt({ r: 2 }))));
      [-72, 72].forEach(x => o.push(cyl(x, 10.6, -36, 2.4, 128, GOLD, mt({ n: 10 })), ball(x, 138, -36, 3.4, GOLD, mt({ k: 4 }))));
      o.push(slabX(0, 136, -36, 148, 3, 3, GOLD, mt({ r: 1 })), cyl(0, 118, -36, 0.5, 18, '#9aa3a8', { n: 4 }), ball(0, 94, -36, 12, '#cfd6e0', mt({ k: 8, n: 18 })));
      o.push(ball(0, 36, 30.6, 6, GOLD, mt({ sz: 0.3, k: 4 }))); rep(3, i => o.push(cyl(-6 + i * 6, 40, 30.6, 1.4, 7 + (i % 2) * 3, GOLD, mt({ n: 6, top: 0.9 }))));
      return o; },
    fx: c => { const u = c.k; let f = '', under = '';
      [-42, 38].forEach((x, i) => { f += '<g transform="' + planeH(c.p, 65) + ' translate(' + x + ' 15)"><g>' + at('rotate', '0;360', 1.8) + '<path d="M0 -10A10 10 0 0 1 10 0" fill="none" stroke="#9aa3a8" stroke-width="0.8"/><path d="M0 7A7 7 0 0 1 -7 0" fill="none" stroke="#6b6f7a" stroke-width="0.6"/><rect x="-0.6" y="-10" width="1.2" height="3" fill="' + GOLD + '"/></g></g>'; });
      const bc = c.p(0, 106, -36); rep(6, i => { f += '<g transform="translate(' + P2(bc) + ')"><g>' + at('rotate', (-40 + i * 16) + ';' + (40 - i * 16) + ';' + (-40 + i * 16), 3 + i * 0.35) + '<path d="M0 0L' + f1(-6 * u) + ' ' + f1(130 * u) + 'L' + f1(6 * u) + ' ' + f1(130 * u) + 'Z" fill="' + NE[i % 6] + '" opacity="0.16">' + an('fill', NEV, 4, -i * 0.6) + '</path></g></g>'; });
      rep(8, i => { const a = i / 8 * 2 * PI, q = c.p(Math.cos(a) * 9, 106 + Math.sin(a) * 9, -36 + 10); f += '<rect x="' + f1(q[0] - 1.2 * u) + '" y="' + f1(q[1] - 1.2 * u) + '" width="' + f1(2.4 * u) + '" height="' + f1(2.4 * u) + '" fill="#ffffff" opacity="0">' + an('opacity', '0;1;0;0', 1.6, -i * 0.2) + '</rect>'; });
      rep(10, i => f += spark(c, -60 + (i % 5) * 30, 18 + Math.floor(i / 5) * 22, 30.2, 0.55, -i * 0.29, '#ffffff', 1.4));
      const e0 = c.p(-78, 10.4, 45.6), e1 = c.p(78, 10.4, 45.6); f += '<path d="M' + P2(e0) + 'L' + P2(e1) + '" stroke="#ff6ad5" stroke-width="' + f1(1.6 * u) + '" stroke-dasharray="' + f1(4 * u) + ' ' + f1(3 * u) + '" filter="url(#gw2)">' + an('stroke', NEV, 3) + an('stroke-dashoffset', '0;-' + f1(14 * u), 0.8) + '</path>';
      under = '<g transform="' + planeH(c.p, 0.3) + '"><ellipse rx="96" ry="66" fill="#8f7bff" opacity="0.25">' + an('fill', NEV, 4) + an('opacity', '0.12;0.32;0.12', 0.9) + '</ellipse></g>';
      return { defs: GLOW, under, front: f }; } });

  // ---------- live LED dance-club walls + floors ----------
  const LED_DEFS = '<filter id="lgb" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="1.4"/></filter><filter id="lgp" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5"/></filter>';
  function ledFloor(t) { const FLT = !!RD._FLAT, px = (u, v) => FLT ? [80 * u, 56 * v] : [14 - 14 * v + (52 + 28 * v) * u, v * 56], P = (u, v) => f1(px(u, v)[0]) + ' ' + f1(px(u, v)[1]), T = FLT ? 'M0 0H80V56H0Z' : 'M14 0H66L80 56H0Z';
    const quad = (u0, v0, u1, v1) => 'M' + P(u0, v0) + 'L' + P(u1, v0) + 'L' + P(u1, v1) + 'L' + P(u0, v1) + 'Z';
    let s = '<defs>' + LED_DEFS + '<clipPath id="lfc"><path d="' + T + '"/></clipPath></defs><g clip-path="url(#lfc)">';
    const rope = (w, op) => '<path d="M15 1H65L78.6 55.2H1.4Z" fill="none" stroke="' + NE[0] + '" stroke-width="' + w + '" stroke-dasharray="2 2.6" stroke-linejoin="round" opacity="' + op + '">' + an('stroke', NEV, 3) + an('stroke-dashoffset', '0;-18.4', 1.1) + '</path>';
    if (t <= 2) { if (t === 2) for (let v = 0; v < 5; v++) for (let u = 0; u < 6; u++) if ((u + v) % 2 === 0) s += '<path d="' + quad(u / 6 + 0.012, v / 5 + 0.02, (u + 1) / 6 - 0.012, (v + 1) / 5 - 0.02) + '" fill="' + NE[(u + v) % 6] + '" opacity="0">' + an('opacity', '0;0.55;0', 2.4, -((u + v) * 0.3).toFixed(2)) + an('fill', NEV, 4.2, -(u * 0.5).toFixed(2)) + '</path>';
      else [[0.3, 0.45, 10], [0.7, 0.62, 12], [0.5, 0.86, 14]].forEach(([u, v, r], i) => { const q = px(u, v); s += '<ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + r + '" ry="' + f1(r * 0.42) + '" fill="' + NE[i * 2] + '" opacity="0.2" filter="url(#lgp)">' + an('fill', NEV, 3, -i) + an('opacity', '0.1;0.32;0.1', 1.4, -i * 0.45) + '</ellipse>'; });
      s += '<g filter="url(#lgb)">' + rope(3, 0.7) + '</g>' + rope(1.2, 1); }
    else { // tiers 3-5 (Acrylic Disco Squares, RGB Matrix, Kinetic Levitation) run the exact Black LED floor loop (CLB-114): same neon set, 5.6 s colour wave,
      // 1.4 s glow pulse, blur-1.2 glow at 50 %; no sensor ripples, sweeps or reactive flashes - one continuous loop. Each keeps its own tile build.
      const NEO = ['#ff3fb4', '#a64dff', '#3f8cff', '#2fe0ff', '#3fff9a', '#ffe23f', '#ff8a2f'], nx = t === 3 ? 5 : t === 4 ? 8 : 10, ny = t === 3 ? 4 : t === 4 ? 6 : 7, gu = (t === 3 ? 0.16 : 0.09) / nx, gv = (t === 3 ? 0.18 : 0.1) / ny;
      s += '<defs><filter id="lfn" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="1.2"/></filter><linearGradient id="lf0" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0d0d10"/><stop offset="1" stop-color="#050506"/></linearGradient>'
        + '<linearGradient id="lfs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="0.55" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs><path d="' + T + '" fill="url(#lf0)"/>';
      const lift = t === 5 ? 1.1 : 0, tile = (i, j, dy) => { const a = i / nx + gu, b = j / ny + gv, c = (i + 1) / nx - gu, d = (j + 1) / ny - gv; return dy ? quad(a, b, c, d).replace(/(-?[\d.]+) (-?[\d.]+)/g, (m, x, y) => x + ' ' + f1(+y - dy)) : quad(a, b, c, d); };
      let tl = '', sh = '', ov = '';
      for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) { const k = (i + j * 2) % NEO.length, seq = rep(NEO.length, m => NEO[(k + m) % NEO.length]).concat(NEO[k]).join(';'), b = -((i + j) * 0.18).toFixed(2);
        tl += '<path d="' + tile(i, j, lift) + '" fill="' + NEO[k] + '">' + an('fill', seq, 5.6, b) + an('opacity', '1;0.3;1', 1.4, (b * 0.5).toFixed(2)) + '</path>';
        if (t === 3) { const a = i / nx + gu, bb = j / ny + gv, c = (i + 1) / nx - gu, d = (j + 1) / ny - gv, ia = a + 0.18 / nx, ib = bb + 0.18 / ny, ic = c - 0.18 / nx, id = d - 0.18 / ny; // thick acrylic block: bevel rim, inner glow, gloss corner
          ov += '<path d="' + quad(a, bb, c, d) + '" fill="none" stroke="#ffffff" stroke-width="0.45" opacity="0.45"/><path d="' + quad(ia, ib, ic, id) + '" fill="none" stroke="#ffffff" stroke-width="0.3" opacity="0.25"/>'
            + '<path d="M' + P(a, bb) + 'L' + P(a + (c - a) * 0.55, bb) + 'L' + P(a, bb + (d - bb) * 0.6) + 'Z" fill="#ffffff" opacity="0.16"/>'; }
        if (t === 5) sh += '<path d="' + tile(i, j, 0) + '" fill="#000000" opacity="0.85"/>'; }
      if (t === 3) { for (let i = 0; i <= nx; i++) s += '<path d="M' + P(i / nx, 0) + 'L' + P(i / nx, 1) + '" stroke="#b8bcc4" stroke-width="0.9"/>'; for (let j = 0; j <= ny; j++) s += '<path d="M' + P(0, j / ny) + 'L' + P(1, j / ny) + '" stroke="#b8bcc4" stroke-width="0.9"/>'; }
      if (t === 4) { const N = 3; for (let i = 1; i < nx * N; i++) if (i % N) ov += '<path d="M' + P(i / (nx * N), 0) + 'L' + P(i / (nx * N), 1) + '" stroke="#000000" stroke-width="0.28" opacity="0.6"/>'; for (let j = 1; j < ny * N; j++) if (j % N) ov += '<path d="M' + P(0, j / (ny * N)) + 'L' + P(1, j / (ny * N)) + '" stroke="#000000" stroke-width="0.28" opacity="0.6"/>'; }
      if (t === 5) { for (let i = 0; i <= nx; i++) s += '<path d="M' + P(i / nx, 0) + 'L' + P(i / nx, 1) + '" stroke="#3a3d48" stroke-width="0.35"/>'; for (let j = 0; j <= ny; j++) s += '<path d="M' + P(0, j / ny) + 'L' + P(1, j / ny) + '" stroke="#3a3d48" stroke-width="0.35"/>';
        ov += '<g opacity="0.5">' + tl.replace(/fill="#/g, 'stroke-width="0.3" stroke="#ffffff" fill-opacity="0" data-f="#') + '</g>'; } // levitating plates: black shadow gap under each, chrome edge highlight on top
      s += sh + '<g filter="url(#lfn)" opacity="0.5">' + tl + '</g>' + tl + ov + (FLT ? '' : '<path d="' + T + '" fill="url(#lfs)"/><path d="' + T + '" fill="none" stroke="#000000" stroke-width="0.35"/>'); }
    return s + '</g>'; }
  RD.H2LED = ledFloor;
  function ledWall(t) { let s = '<defs>' + LED_DEFS + '<clipPath id="lwc"><rect x="0" y="0" width="80" height="56" rx="4"/></clipPath></defs><g clip-path="url(#lwc)">';
    if (t === 1) { [[4, 4], [16, 3.4]].forEach(([y0, sag], k) => { let d = 'M0 ' + y0; for (let x = 0; x <= 80; x += 2) d += 'L' + x + ' ' + f1(y0 + sag * Math.abs(Math.sin(PI * x / 40))); s += '<path d="' + d + '" fill="none" stroke="#2c2d31" stroke-width="0.5"/>';
        rep(14, i => { const x = 2.8 + i * 5.6, y = y0 + sag * Math.abs(Math.sin(PI * x / 40)) + 1.4, c = NE[(i + k * 3) % 6], b = -((i * 7 + k * 3) % 10) * 0.18; s += '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="3.2" fill="' + c + '" filter="url(#lgb)" opacity="0.6">' + an('opacity', '0.15;0.8;0.15', 1.8, b.toFixed(2)) + '</circle><circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="1.2" fill="' + c + '">' + an('opacity', '0.4;1;0.4', 1.8, b.toFixed(2)) + '</circle>'; }); }); }
    else if (t === 2) { s += '<rect x="0" y="0" width="80" height="56" fill="' + NE[0] + '" opacity="0.12">' + an('fill', NEV, 5) + an('opacity', '0.06;0.18;0.06', 1.6) + '</rect>';
      [2, 54].forEach((y, i) => s += '<path d="M0 ' + y + 'H80" stroke="' + NE[i] + '" stroke-width="5" filter="url(#lgb)" opacity="0.7">' + an('stroke', NEV, 3, -i * 1.5) + '</path><path d="M0 ' + y + 'H80" stroke="#ffffff" stroke-width="1.2" stroke-dasharray="1.6 1.4">' + an('stroke-dashoffset', '0;-6', 0.6) + '</path>');
      rep(10, i => s += '<circle cx="' + (6 + i * 7.6) + '" cy="' + (i % 2 ? 22 : 38) + '" r="0.9" fill="' + NE[i % 6] + '">' + an('opacity', '0;1;0', 1.2, (-i * 0.23).toFixed(2)) + '</circle>'); }
    else if (t === 3) { [[14, '#ff6ad5'], [44, '#4fe0d0']].forEach(([y, c], i) => s += '<path d="M0 ' + y + 'H80" stroke="' + c + '" stroke-width="5" filter="url(#lgb)">' + an('opacity', '0.5;1;0.5;1;0.2;1', 2.6, -i * 0.7, '0;0.3;0.5;0.8;0.84;1') + an('stroke', i ? '#4fe0d0;#6ac8ff;#a6f06a;#4fe0d0' : '#ff6ad5;#b48cff;#ff9d4a;#ff6ad5', 5) + '</path>');
      s += '<path d="M2 29Q12 21 22 29T42 29T62 29T82 29" fill="none" stroke="#ffd66b" stroke-width="4" filter="url(#lgb)" opacity="0.8">' + an('stroke', NEV, 4) + '</path><path d="M2 29Q12 21 22 29T42 29T62 29T82 29" fill="none" stroke="#ffffff" stroke-width="1.1" stroke-dasharray="6 4">' + an('stroke-dashoffset', '0;-20', 1) + '</path>'; }
    else { const R = rng('eq' + t), base = t === 5 ? 54 : 52, hi = t === 5 ? 24 : 40, nc = 16;
      if (t === 5) { s += '<rect x="0" y="0" width="80" height="56" fill="#120e24"/><g filter="url(#lgp)" opacity="0.8">'; rep(5, i => { const cx = [16, 40, 64, 28, 54][i], cy = [18, 30, 16, 40, 42][i], r = [16, 18, 14, 13, 15][i]; s += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="' + NE[i] + '">' + an('fill', NEV, 5, -i) + an('cx', cx + ';' + (cx + (i % 2 ? 10 : -10)) + ';' + cx, 4 + i * 0.6) + an('cy', cy + ';' + (cy + (i % 2 ? -6 : 6)) + ';' + cy, 3.4 + i * 0.5) + '</circle>'; }); s += '</g>';
        s += '<rect x="0" y="0" width="80" height="3" fill="#ffffff" opacity="0.35">' + an('y', '-3;56', 2.6) + '</rect>'; }
      else s += '<rect x="2" y="6" width="76" height="48" rx="2" fill="#0a0b10" opacity="0.72"/>';
      rep(nc, i => { const x = 3 + i * 4.6, hs = rep(6, () => f1(4 + R() * hi)); hs.push(hs[0]); s += '<rect x="' + f1(x) + '" width="3.6" fill="' + NE[i % 6] + '" y="' + f1(base - +hs[0]) + '" height="' + hs[0] + '">' + an('height', hs.join(';'), 1.8 + (i % 3) * 0.2) + an('y', hs.map(h => f1(base - +h)).join(';'), 1.8 + (i % 3) * 0.2) + an('fill', NEV, 6, -i * 0.3) + '</rect>'; });
      s += '<g opacity="0.6">' + rep(Math.ceil(hi / 3) + 2, j => '<rect x="0" y="' + f1(base - 3 * j - 0.7) + '" width="80" height="0.7" fill="#0a0b10"/>').join('') + rep(nc, i => '<rect x="' + f1(3 + i * 4.6 + 3.6) + '" y="0" width="1" height="56" fill="#0a0b10"/>').join('') + '</g>';
      if (t === 4) s += '<rect x="0" y="0" width="80" height="56" fill="url(#lws)"/><defs><linearGradient id="lws" x1="0" y1="0" x2="1" y2="1"><stop offset="0.3" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.35"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-1 -1;1 1" dur="3s" repeatCount="indefinite"/></linearGradient></defs>'; }
    return s + '</g>'; }
  const draw0 = RD.draw;
  RD.draw = (r, o) => { const res = draw0(r, o); if (!res || res._p2) return res; res._p2 = 1;
    try { if (r.room === 'CLB' && res.surf && res.svg && (res.kind === 'floor' || res.kind === 'wall')) { const add = res.kind === 'floor' ? ledFloor(r.tier) : ledWall(r.tier); res.svg = res.svg.replace(/<\/svg>\s*$/, add + '</svg>'); res.src = 'data:image/svg+xml,' + encodeURIComponent(res.svg); res.led = 1; }
      else if (!res.surf) { const D = X.CAT['rv_' + r.id + '_' + r.tier + '_' + ((o && o.ci) | 0) + '_' + ((o && o.st) || '')]; if ((D && D.flat) || /^(rug2|rug|mat)$/.test((res.arch || '').split('.')[0])) res.flat = true; } } catch (e) { console.warn('reno plus2', r.id, e); }
    return res; };

  // ---------- catalog edits ----------
  const SET2 = { 'MOV-011': { spec: 'microPop' }, 'MOV-031': { spec: 'popper', live: 'Pops live' }, 'MOV-051': { spec: 'popCart', live: 'Pops live' }, 'MOV-071': { spec: 'popCart', sx: { conc: 1 }, live: 'Pops live' }, 'MOV-091': { spec: 'candyBar', live: 'Live dispenser' },
    'MOV-028': { spec: 'popBucket' }, 'MOV-008': { spec: 'candyBox' }, 'KIT-008': { spec: 'cereal' },
    'LIV-091': { spec: 'holoStage', live: 'Live hologram', note: 'A dancing hologram on a glowing emitter, inside a ring of walnut acoustic fins that pulse with the music. Loops forever.' } };
  const ROYAL = { cost: 0, lv: 30, rarity: 'Legendary', live: 'Royal Collection', note: 'Royal Collection: the most expensive piece in this room.' };
  const ADD2 = [
    ['LIV', 111, 11, 11, 'Center Table', 'Gilded Rococo Marble Coffee Table with Crystal Decanters', 'luxCoffee', 62000],
    ['KIT', 108, 13, 23, 'Patisserie Display', 'Royal Patisserie Display Case with Cakes, Macarons & Croissants', 'luxPatis', 70000],
    ['MOV', 101, 10, 10, 'Primary Sofa / Row', 'Royal Velvet Cinema Recliner Row with Gold Cup Holders', 'luxRecliner', 72000],
    ['MOV', 102, 15, 15, 'Snack Station', 'Gilded Grand Cinema Popcorn Carriage', 'popCart', 64000, { sx: { royal: 1 } }],
    ['BTH', 101, 5, 5, 'Primary Tub', 'Royal Burgundy & 24K Gold Clawfoot Soaking Tub', 'luxTub', 74000],
    ['BTH', 102, 8, 8, 'Washbasin', 'Black Onyx & Gold Double Vanity with Round Mirrors', 'luxVanity', 62000],
    ['BED', 101, 5, 5, 'Primary Bed', 'Royal Gold Four-Poster Canopy Bed with Velvet Drapes', 'luxBed', 75000],
    ['BED', 102, 11, 11, 'Drawer Chest', 'Mirrored Gold Vanity Dresser with Crystal Knobs', 'luxDresser', 62000],
    ['YRD', 106, 5, 5, 'Aquatic Centerpiece', 'Carrara Marble Tiered Fountain with Gold Swans', 'luxFountain', 70000],
    ['YRD', 107, 8, 8, 'Primary Outdoor Seating', 'Gilded Garden Gazebo Daybed with Silk Drapes', 'luxDaybed', 64000],
    ['CLB', 111, 11, 11, 'VIP Lounge Sofa', 'Royal VIP Velvet Booth with Gold Champagne Tower', 'luxBooth', 75000],
    ['CLB', 112, 5, 5, 'DJ Console', 'Gold Mirror-Ball DJ Throne Booth', 'luxDJ', 68000],
  ];
  const BUMP = { 'LIV-110': 68000, 'KIT-104': 66000 };
  const edit1 = RD.edit;
  RD.edit = rows => { let R = edit1(rows).map(r => SET2[r.id] ? Object.assign({}, r, SET2[r.id]) : r);
    const bon = r => '+45 ' + r.stat;
    R = R.map(r => BUMP[r.id] ? Object.assign({}, r, ROYAL, { cost: BUMP[r.id], bonus: bon(r) }) : r);
    ADD2.forEach(([room, num, bs, slot, slotName, name, spec, cost, ex]) => { const same = rows.filter(r => r.room === room), b = same.find(r => r.tier === 5 && r.slot === bs) || same.find(r => r.tier === 5); if (b) R.push(Object.assign({}, b, ROYAL, { id: room + '-' + num, slot, slotName, name, spec, cost, bonus: bon(b), add: 1 }, ex || {})); });
    return R; };
  const FOOD2 = ['fFruitBowl', 'fCake', 'fDonuts', 'fCupcakes', 'fCookies', 'fPizza'];
  RD.food = i => RD.draw({ id: 'FOOD2-' + i, name: 'snack', tier: 2, room: 'KIT', slot: 0, spec: FOOD2[i % FOOD2.length] });
  Object.assign(RD, { PLUS2: 1, ledFloor, ledWall });
})();
