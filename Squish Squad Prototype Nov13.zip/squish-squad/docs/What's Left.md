# What's left

Updated October 20, 2026. This is the only to-do list for the project.

## Done in this pass (latest)
- **Wisecrack:** rebuilt in 3D + own dance "Wisecrack Wiggle". Arms go up on yawn/wave.
- **Aero-Swift:** 3D wings (edge-on side-on, flutter), helmet blades + crest turn with her, arms visible from the back, loop-the-loop stays in frame.
- **All Elemental heroes:** arms go up on yawn/wave and stay visible from the back.

---

## A. Work still to build

### Creatures
1. **Spooky Squish (7 creatures, never reviewed):** Gourdy, Batty, Kernel, Hexie, Mumbles, Hocus, Count Squishula. They have no 3D rebuild and none of their own dances yet (Pumpkin Roll, Bat Flap, Candy Shuffle, Broom Sway, Mummy Robot, Spell Twist, Cape Slide). This is the last category.
2. **Waffles:** full rebuild as a corgi, then all his furniture animations, walk and idle fidgets (skipped in every batch).
   - Now: he reads as Biscuit recoloured (round bun body, flat ears). His head, ears, paws and tail drift apart when he turns, the tail floats off his back, his cheek fluff covers his face, and the white forehead blaze doesn't show.
   - Plan: build him as one grouped corgi, not on the shared rig (patching the shared rig numbers didn't hold). Long low body, big upright pointed ears, fox-shaped head with a white muzzle + blaze, fluffy white-tipped tail low on the back, short legs with white paws. Colours: orange #e8953e, cream #fff8ee, ink #2a1a30, blush #ff8fa3. Reference photos are in uploads/ (pasted-1792297839836-0, -858208-0, -870429-0, -897974-0).
   - Check front / side / back and spin 0/45/90/135 + squish + happy on waffles-rig-check.html before wiring him into the game.
3. **Heroes (7):** use Mittens' moves for everything except their dances.
4. **Giga-Growth / Crystalline:** chest gems + vines (Giga) and the face (Crystalline) show through from the back.
5. **Card pictures still flat (old art)** for about 50 rebuilt creatures: Pet Shop, Sky & Stars, Snack Shack, Pip/Jelli/Finn/Sealy/Octo, Teddy/Panko/Hoot/Leo/Acorn/Fawn/Sprout, all Sweet Bakery, all heroes. 23 have 3D cards so far.

### Squad House v6
6. **Tap a creature → floating room icons** above its head to send it to a room (feature 4 of the v6 request). Not built.
7. **8-way rotation for catalog (reno) pieces:** they're flat art and only mirror. They need 3D versions, and you haven't said which pieces matter yet.
8. **Catalog badges** ("Plug in" / "Sit & nap") are only on the grid layout; the other catalog layouts may be dead code (to confirm).
9. **Renovation catalog leftovers:** creatures in the back-row seats of dining tables draw over the tabletop; only the 4 luxury sofas have the extra detail.
10. **Beach:** catalog pictures for all 100 pieces need a visual pass, tier by tier.

### Chests
11. **Swap the new chests in** to Chest Smash, Chest Damage, Group Chests and Shop v3 (they still use the old `Group Chest Art`; Shop v4 already has them).
12. **Speed fixes 3 + 4:** cache the idle main chest as an image; pre-draw particle glows. Smashing still doesn't reach a full 120+ fps.

### Other
13. **Squad House v6 console error:** an image fails to load on start (`[object SVGAnimatedString]`); the beach one was fixed, check whether any are left.

## B. Needs you to watch it live
- **Squad House v6** (nothing tried in a live room yet): all furniture animations (batches 1–7), 8-way furniture rotation, tapping arcade + DJ pieces, trampoline / slide / blocks, creature walks + idle fidgets in the room, the Beach motion (walking into the sea, surfing, fishing, floats).
- **Chests:** the new chest smash at normal speed, the last 7 groups smashed in real time, and a test on a real phone.

## C. Waiting on your review (built, not signed off)
- Wisecrack, Aero-Swift, hero arms (this pass).
- Kiko: rebuild + "Kiko Leap".
- Every furniture animation (sit, lounge, TV, snuggle, bedtime, water, swing, rocking horse, cook, fridge, the [B] list, batch 7).
- Own walks and stand-idle fidgets for every creature (fidgets only spot-checked on 8). Known: Prickle's ear scratch swings his arm out wide.
- Dances checked frame by frame only: 7 Fruit Patch dances, all of Dreamland, all 9 Sweet Bakery.

## D. Ideas for later (not requested yet)
- The unpicked [ ] furniture animations (about 30 more per creature).
- Holiday map versions; a bigger Squish Town map.

## Suggested order
1. Spooky Squish, 3 per batch (rebuild + own dance).
2. Giga-Growth + Crystalline back-view fixes.
3. Tap-a-creature room icons in Squad House v6.
4. 3D card pictures for the rest of the roster.
5. Waffles rebuild (own session).
6. Swap new chests into the remaining screens + chest speed fixes 3/4.
