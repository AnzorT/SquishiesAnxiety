// Renovation Catalog round 21 — Living Room CEILINGS + OVERHEAD LIGHTS (same game style as the Movie Room ceilings in plus14).
// Ceilings = r.c21, one recipe drawn twice via the plus14 frame (RD.H14.mk): the 80 x 56 catalog card (tier's LIV wall colour below) and
// D.ceilRoom, the 1259.6 x 70 room strip the house lays over the ceiling. G.VY = vanishing line: a point dropped below the ceiling by a fraction
// dd of the ceiling height moves to y + (VY - y) * dd, a point raised above it to VY - (VY - y) * m, so beams, coves and the atrium shaft
// have real depth. Overhead lights (LIV-018/038/058/078/098) = ceiling pieces (mount 'ceil'), animated. Sets RenoDraw.PLUS21; edits RD.SET21.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS20 && RD.H14 && RD.H11 && RD.H10 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS21) return;
  const K = X.K, shade = K.shade, N = RD.N, PI = Math.PI, H = RD.H10;
  const { cam, rng, an, at, SPL, f1, n4, rep, P2 } = H;
  const { DEF11, zsort } = RD.H11;
  const box3 = (C, o) => H.box3(C, Object.assign({}, o, { mat: null, tpat: null, gl: o.gl ? Math.min(o.gl, 0.2) : 0, olw: 1, olo: 0.95, olc: shade(o.col, 0.32), edge: 0.5 }));
  const cyl3 = (C, a, b, r, col, o) => H.cyl3(C, a, b, r, col, Object.assign({}, o || {}, { mat: o && o.mat === 'gloss' ? 'gloss' : 'plastic', pat: null, olw: o && o.olw != null ? o.olw : 0.8, olo: 0.95 }));
  const sph = (C, q, r, col, o) => { const c = C.P(q); return H.sph(C, q, r, col, o) + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * C.k)}" fill="none" stroke="${shade(col, 0.35)}" stroke-width="0.5"/>`; };

  // ======================= CEILINGS =======================
  const mkV = F => { const G = RD.H14.mk(F); G.VY = G.H * G.W / (2 * G.ins); return G; };
  const FRM = RD.H14.FRM;
  const E = (G, u, t) => { const y = G.y(t); return { x: G.x(u, y), y, z: G.z(y), q: 0.28 + 0.22 * (1 - y / G.H) }; }; // q = circle squash at that depth
  const lo = (G, y, dd) => y + (G.VY - y) * dd;
  const dot = (x, y, rx, ry) => `M${n4(x - rx)} ${n4(y)}a${n4(rx)} ${n4(ry)} 0 1 0 ${n4(2 * rx)} 0a${n4(rx)} ${n4(ry)} 0 1 0 ${n4(-2 * rx)} 0`;
  // wall-line band between offsets a..b (0 = on the wall line, 1 = full width bw) along the back edge + both slanted side edges
  const band = (G, bw, a, b) => { const n = 12, w = y => bw * G.z(y), L = [], R = []; for (let i = 0; i <= n; i++) { const y = G.H * i / n; L.push([G.x(0, y), y]); R.push([G.x(1, y), y]); }
    const sh = (P, sg, f) => P.map(([x, y]) => [x + sg * w(y) * 1.6 * f, y]), wb = w(G.H);
    return { back: `M${f1(G.ins + wb * 1.6 * a)} ${f1(G.H - wb * b)}H${f1(G.W - G.ins - wb * 1.6 * a)}V${f1(G.H - wb * a)}H${f1(G.ins + wb * 1.6 * a)}Z`,
      l: 'M' + sh(L, 1, a).map(P2).join('L') + 'L' + sh(L, 1, b).reverse().map(P2).join('L') + 'Z', r: 'M' + sh(R, -1, a).map(P2).join('L') + 'L' + sh(R, -1, b).reverse().map(P2).join('L') + 'Z',
      lip: `M${f1(G.ins + wb * 1.6 * b)} ${f1(G.H - wb * b)}H${f1(G.W - G.ins - wb * 1.6 * b)}M` + sh(L, 1, b).map(P2).join('L') + 'M' + sh(R, -1, b).map(P2).join('L'), wb }; };
  // stepped moulding: cols from the wall out to the ceiling, lighter lip line on the ceiling edge
  const mould = (G, bw, cols, lip, ex) => { let s = ''; cols.forEach((c, i) => { const B = band(G, bw, i / cols.length, (i + 1) / cols.length); s += `<path d="${B.back}" fill="${c}"/><path d="${B.l}" fill="${shade(c, 0.94)}"/><path d="${B.r}" fill="${shade(c, 0.87)}"/>`; });
    const B = band(G, bw, 0, 1); return `<path d="${B.lip}" stroke="#000000" stroke-opacity="0.12" stroke-width="${f1(1.6 * G.s)}" fill="none" transform="translate(0 ${f1(0.8 * G.s)})"/>` + s + `<path d="${B.lip}" stroke="${lip}" stroke-width="${f1(0.8 * G.s)}" fill="none"/>` + (ex || ''); };
  const trim = (G, bw, col, ex) => mould(G, bw, [col], shade(col, 1.4), ex);
  const light = (G, a, b) => '<defs><linearGradient id="csh" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000000" stop-opacity="' + a + '"/><stop offset="0.7" stop-color="#000000" stop-opacity="0"/><stop offset="0.92" stop-color="#ffffff" stop-opacity="' + (b || 0.05) + '"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs><path d="' + G.tr + '" fill="url(#csh)"/>';
  const doc = (G, body) => '<defs><clipPath id="ctc"><path d="' + G.tr + '"/></clipPath>' + G.b(1) + G.b(3) + G.b(6) + '</defs><g clip-path="url(#ctc)">' + body + '</g>';
  const blots = (G, sd, n, cols, op, w) => { const R = rng(sd); return `<g filter="url(#cb6)" opacity="${op}">` + rep(n, i => { const t = 0.05 + R() * 0.92, y = G.y(t), z = G.z(y); return `<ellipse cx="${f1(G.x(R() * 1.1 - 0.05, y))}" cy="${f1(y)}" rx="${f1((w + R() * w) * z)}" ry="${f1((4 + R() * 5) * z)}" fill="${cols[i % cols.length]}"/>`; }).join('') + '</g>'; };
  const web = (G, u, t, r, fl) => { const y = G.y(t), x = G.x(u, y), z = G.z(y) * r, A = rep(6, k => (k / 5) * PI / 2), sx = fl ? -1 : 1;
    let d = A.map(a => 'M' + f1(x) + ' ' + f1(y) + 'l' + f1(sx * Math.cos(a) * 9 * z) + ' ' + f1(-Math.sin(a) * 5 * z)).join('');
    [0.35, 0.65, 0.95].forEach(k => { d += 'M' + A.map(a => f1(x + sx * Math.cos(a) * 9 * z * k) + ' ' + f1(y - Math.sin(a) * 5 * z * k)).join('L'); });
    return '<path d="' + d + '" stroke="#fbf8f0" stroke-opacity="0.7" stroke-width="' + f1(0.35 * G.s) + '" fill="none"/>'; };

  // LIV-009 popcorn stucco: yellowed bumpy texture (one bump tile repeated in depth bands scaled per distance), brown leak rings,
  // a peeled patch with a curled paint flake that flutters, a hairline crack and a cobweb in the corner (tier 1: water-stained wallpaper)
  function cPop(G) { const R = rng('pop21');
    let s = `<path d="${G.tr}" fill="#e6dbbd"/>` + blots(G, 'pop21b', 10, ['#d6c493', '#f3ebd5', '#dccb9f'], 0.55, 40);
    const T0 = rng('popT'); let a = '', b = '';
    for (let i = 0; i < 46; i++) { const x = T0() * 20, y = T0() * 20, r = 0.7 + T0() * 0.8;
      [[0, 0], [20, 0], [-20, 0], [0, 20], [0, -20]].forEach(([dx, dy]) => { const X2 = x + dx, Y2 = y + dy; if (X2 < -2 * r || X2 > 20 + 2 * r || Y2 < -2 * r || Y2 > 20 + 2 * r) return;
        a += dot(X2 + 0.32 * r, Y2 + 0.28 * r, r, r); b += dot(X2 - 0.2 * r, Y2 - 0.2 * r, r * 0.66, r * 0.66); }); }
    const tile = `<path d="${a}" fill="#c2af82" opacity="0.62"/><path d="${b}" fill="#faf5e6" opacity="0.92"/>`, NB = 9; let pd = '';
    for (let j = 0; j < NB; j++) { const t0 = j / NB, t1 = (j + 1) / NB, z = G.z(G.y((t0 + t1) / 2)) * 0.55;
      pd += `<pattern id="pp${j}" patternUnits="userSpaceOnUse" width="20" height="20" patternTransform="translate(${j * 7} 0) scale(${n4(z)} ${n4(z * 0.6)})">${tile}</pattern>`;
      s += `<path d="${G.quad(-0.05, t0, 1.05, t1)}" fill="url(#pp${j})"/>`; }
    s = `<defs>${pd}</defs>` + s;
    const stain = (u, t, rw, sd) => { const P = E(G, u, t), Rr = rng(sd), n = 22, pts = rep(n, i => { const an_ = i / n * 2 * PI, k = rw * P.z * (0.78 + Rr() * 0.4); return [P.x + Math.cos(an_) * k, P.y + Math.sin(an_) * k * P.q]; });
      const d = 'M' + pts.map(P2).join('L') + 'Z', d2 = 'M' + pts.map(([x, y]) => [P.x + (x - P.x) * 0.6, P.y + (y - P.y) * 0.6]).map(P2).join('L') + 'Z';
      return `<path d="${d}" fill="#d0b479" opacity="0.4"/><path d="${d}" fill="none" stroke="#a37e48" stroke-width="${f1(1.1 * P.z)}" opacity="0.55"/><path d="${d2}" fill="#c9a96a" opacity="0.18"/><path d="${d2}" fill="none" stroke="#b18c55" stroke-width="${f1(0.7 * P.z)}" opacity="0.42"/>`; };
    s += stain(0.27, 0.55, 26, 'st1') + stain(0.72, 0.32, 17, 'st2') + stain(0.6, 0.84, 11, 'st3');
    // peeled patch: bare grey plaster, torn paint edge, one curled flake hanging off it that flutters in the draft
    { const P = E(G, 0.33, 0.62), z = P.z, Rr = rng('peel'), pts = rep(14, i => { const a2 = i / 14 * 2 * PI, k = (7 + Rr() * 5) * z; return [P.x + Math.cos(a2) * k * 1.4, P.y + Math.sin(a2) * k * P.q * 1.3]; }), d = 'M' + pts.map(P2).join('L') + 'Z';
      s += `<path d="${d}" fill="#cbc4b2"/><path d="${d}" fill="none" stroke="#a89f88" stroke-width="${f1(0.5 * z)}"/><path d="${d}" fill="none" stroke="#fbf6e6" stroke-width="${f1(0.5 * z)}" transform="translate(${f1(-0.6 * z)} ${f1(-0.5 * z)})"/>`;
      const ax = pts[3][0], ay = pts[3][1], fl = `M${f1(ax)} ${f1(ay)}q${f1(4 * z)} ${f1(-1 * z)} ${f1(7 * z)} ${f1(1.2 * z)}q${f1(-0.6 * z)} ${f1(3.6 * z)} ${f1(-4.2 * z)} ${f1(5.4 * z)}q${f1(-2.8 * z)} ${f1(-1.6 * z)} ${f1(-2.8 * z)} ${f1(-6.6 * z)}Z`;
      s += `<g>${at('rotate', `-9 ${f1(ax)} ${f1(ay)};7 ${f1(ax)} ${f1(ay)};-4 ${f1(ax)} ${f1(ay)};-9 ${f1(ax)} ${f1(ay)}`, 3.8, 0, SPL(3))}<path d="${fl}" fill="#000000" opacity="0.18" transform="translate(${f1(0.8 * z)} ${f1(1 * z)})"/><path d="${fl}" fill="#efe5c8" stroke="#b6a67c" stroke-width="${f1(0.35 * z)}"/><path d="M${f1(ax + 1 * z)} ${f1(ay + 0.6 * z)}q${f1(2.4 * z)} ${f1(0.2 * z)} ${f1(4.6 * z)} ${f1(1.4 * z)}" stroke="#ffffff" stroke-width="${f1(0.4 * z)}" fill="none" opacity="0.8"/></g>`; }
    { const pts = [[0.04, 0.97], [0.07, 0.9], [0.065, 0.84], [0.1, 0.78], [0.12, 0.7], [0.16, 0.66]].map(([u, t]) => { const y = G.y(t); return [G.x(u, y), y]; });
      const br = [[0.1, 0.78], [0.135, 0.8], [0.15, 0.86]].map(([u, t]) => { const y = G.y(t); return [G.x(u, y), y]; });
      s += `<path d="M${pts.map(P2).join('L')}M${br.map(P2).join('L')}" stroke="#9a8a68" stroke-width="${f1(0.5 * G.s)}" fill="none" stroke-linejoin="round"/>`; }
    s += web(G, 0.995, 1, 1.1, 1) + web(G, 0.006, 0.99, 0.8);
    return s + light(G, 0.3, 0.05) + trim(G, 2.6, '#e2d5b2'); }

  // LIV-029 smooth skimmed plaster: warm white, faint roller sheen, sage bounce light near the walls, a deep cove moulding all round,
  // a smoke alarm whose red light blinks and a white air vent (tier 2: sage walls)
  function cCove(G) { let s = `<path d="${G.tr}" fill="#f2eee5"/>` + blots(G, 'cov21', 8, ['#ffffff', '#e6dfcf'], 0.5, 90);
    s += `<defs><linearGradient id="sgb" x1="0" y1="0" x2="0" y2="1"><stop offset="0.5" stop-color="#9caf8b" stop-opacity="0"/><stop offset="1" stop-color="#9caf8b" stop-opacity="0.24"/></linearGradient></defs><path d="${G.tr}" fill="url(#sgb)"/>`;
    { const P = E(G, 0.31, 0.5), z = P.z, x = P.x, y = P.y, yb = lo(G, y, 0.025), r = 6 * z, ry = r * P.q;
      s += `<ellipse cx="${f1(x + 1 * z)}" cy="${f1(yb + 1.2 * z)}" rx="${f1(r * 1.05)}" ry="${f1(ry * 1.05)}" fill="#000000" opacity="0.16" filter="url(#cb1)"/>`
        + `<path d="M${f1(x - r)} ${f1(y)}V${f1(yb)}H${f1(x + r)}V${f1(y)}Z" fill="#dcd8cf"/><ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(r)}" ry="${f1(ry)}" fill="#dcd8cf"/>`
        + `<ellipse cx="${f1(x)}" cy="${f1(yb)}" rx="${f1(r)}" ry="${f1(ry)}" fill="#fbfaf6" stroke="#c9c3b6" stroke-width="${f1(0.4 * G.s)}"/><ellipse cx="${f1(x)}" cy="${f1(yb)}" rx="${f1(r * 0.62)}" ry="${f1(ry * 0.62)}" fill="#f1eee6" stroke="#d6d0c3" stroke-width="${f1(0.35 * G.s)}"/>`
        + rep(4, i => `<path d="M${f1(x - r * 0.42)} ${f1(yb + (i - 1.5) * ry * 0.22)}H${f1(x + r * 0.42)}" stroke="#c4bdae" stroke-width="${f1(0.35 * z)}"/>`).join('')
        + `<ellipse cx="${f1(x + r * 0.78)}" cy="${f1(yb)}" rx="${f1(0.6 * z)}" ry="${f1(0.42 * z)}" fill="#7a1a14"/><ellipse cx="${f1(x + r * 0.78)}" cy="${f1(yb)}" rx="${f1(0.6 * z)}" ry="${f1(0.42 * z)}" fill="#ff3b30" opacity="0.15">${an('opacity', '0.15;0.15;1;0.15', 4, 0, ' keyTimes="0;0.86;0.9;1"')}</ellipse>`
        + `<ellipse cx="${f1(x + r * 0.78)}" cy="${f1(yb)}" rx="${f1(2.4 * z)}" ry="${f1(1.4 * z)}" fill="#ff5a4a" opacity="0" filter="url(#cb1)">${an('opacity', '0;0;0.6;0', 4, 0, ' keyTimes="0;0.86;0.9;1"')}</ellipse>`; }
    { const u0 = 0.75, u1 = 0.81, t0 = 0.27, t1 = 0.34; let l = '';
      for (let i = 1; i < 6; i++) { const t = t0 + (t1 - t0) * i / 6; l += 'M' + G.P(u0 + 0.004, t) + 'L' + G.P(u1 - 0.004, t); }
      s += `<path d="${G.quad(u0, t0, u1, t1)}" fill="#000000" opacity="0.12" filter="url(#cb1)" transform="translate(${f1(0.8 * G.s)} ${f1(1 * G.s)})"/><path d="${G.quad(u0, t0, u1, t1)}" fill="#f8f6f0" stroke="#cbc4b5" stroke-width="${f1(0.5 * G.s)}"/><path d="${G.quad(u0 + 0.004, t0 + 0.012, u1 - 0.004, t1 - 0.012)}" fill="#8c877c"/><path d="${l}" stroke="#f3f0e8" stroke-width="${f1(1.3 * G.s)}"/>`; }
    return s + light(G, 0.24, 0.05) + mould(G, 7, ['#dbd3c2', '#b9ae97', '#cfc6b3', '#e9e3d6', '#fbf9f3'], '#ffffff'); }

  // LIV-049 exposed rustic cedar beams: whitewashed pine boards running toward the back, four heavy cedar beams across the room
  // (front face + lit underside with grain, knots and checks, black iron straps) and a cedar wall plate (tier 3: cream wainscoting)
  function cBeam(G) { const R = rng('bm21'), NU = 40, BC = ['#efe6d5', '#e6dcca', '#f3ecde', '#e0d5c0'];
    let s = `<path d="${G.tr}" fill="#e9e0cf"/>`, gr = '';
    for (let i = 0; i < NU; i++) { const u0 = i / NU * 1.1 - 0.05, u1 = (i + 1) / NU * 1.1 - 0.05; s += `<path d="${G.quad(u0, 0, u1, 1)}" fill="${BC[(i * 5 + ((R() * 2) | 0)) % 4]}"/>`; gr += 'M' + G.P(u0, 0) + 'L' + G.P(u0, 1); }
    s += `<path d="${gr}" stroke="#c4b596" stroke-width="${f1(0.7 * G.s)}" fill="none"/>` + rep(30, () => { const P = E(G, R(), R()); return `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(1.1 * P.z)}" ry="${f1(0.5 * P.z)}" fill="#c9b691" opacity="0.6"/>`; }).join('');
    const beam = t => { const bt = 0.052, dd = 0.068, y0 = G.y(t), y1 = G.y(t + bt), ya = lo(G, y0, dd), yb = lo(G, y1, dd), z0 = G.z(y0), z1 = G.z(y1), XL = -12, XW = G.W + 24, Rb = rng('bm' + t);
      let b = `<rect x="${XL}" y="${f1(y1)}" width="${XW}" height="${f1(yb - y1 + 4 * z1)}" fill="#000000" opacity="0.2" filter="url(#cb1)"/>`
        + `<rect x="${XL}" y="${f1(y0)}" width="${XW}" height="${f1(ya - y0)}" fill="#95522e"/><rect x="${XL}" y="${f1(ya)}" width="${XW}" height="${f1(yb - ya)}" fill="#bb6d40"/>`;
      const wav = (yy, amp, ph) => 'M' + rep(26, i => f1(XL + XW * i / 25) + ' ' + f1(yy + Math.sin(i * 1.3 + ph) * amp + Math.sin(i * 0.37 + ph * 2) * amp * 0.6)).join('L');
      b += `<path d="${[0.25, 0.5, 0.75].map((k, i) => wav(ya + (yb - ya) * k, 0.25 * z1, t * 9 + i)).join('')}" stroke="#97502b" stroke-width="${f1(0.4 * z1)}" fill="none" opacity="0.55"/>`
        + `<path d="${[0.35, 0.7].map((k, i) => wav(y0 + (ya - y0) * k, 0.3 * z0, t * 5 + i * 2)).join('')}" stroke="#74391b" stroke-width="${f1(0.45 * z0)}" fill="none" opacity="0.5"/>`;
      rep(5, () => { const x = G.W * (0.05 + Rb() * 0.9), yk = ya + (yb - ya) * (0.3 + Rb() * 0.4); b += `<ellipse cx="${f1(x)}" cy="${f1(yk)}" rx="${f1(2.2 * z1)}" ry="${f1((yb - ya) * 0.2)}" fill="#7a3d1e" opacity="0.65"/><ellipse cx="${f1(x)}" cy="${f1(yk)}" rx="${f1(3.4 * z1)}" ry="${f1((yb - ya) * 0.3)}" fill="none" stroke="#8a4524" stroke-width="${f1(0.3 * z1)}" opacity="0.5"/>`; });
      rep(4, () => { const x = G.W * (0.05 + Rb() * 0.9), yk = y0 + (ya - y0) * (0.35 + Rb() * 0.3); b += `<path d="M${f1(x)} ${f1(yk)}l${f1((10 + Rb() * 14) * z0)} ${f1(0.4 * z0)}" stroke="#4e2410" stroke-width="${f1(0.45 * z0)}" opacity="0.7"/>`; });
      b += `<path d="M${XL} ${f1(ya)}H${XL + XW}" stroke="#da8f5e" stroke-width="${f1(0.6 * z0)}"/>`;
      [0.2, 0.8].forEach(u => { const x = G.x(u, y0); b += `<rect x="${f1(x - 2.4 * z0)}" y="${f1(y0)}" width="${f1(4.8 * z0)}" height="${f1(yb - y0)}" fill="#2c2724"/><rect x="${f1(x - 2.4 * z0)}" y="${f1(ya - 0.3 * z0)}" width="${f1(4.8 * z0)}" height="${f1(0.6 * z0)}" fill="#5a524b"/>`
        + [[y0 + (ya - y0) * 0.5], [ya + (yb - ya) * 0.5]].map(([yy]) => `<circle cx="${f1(x)}" cy="${f1(yy)}" r="${f1(0.75 * z0)}" fill="#6f665d" stroke="#191614" stroke-width="${f1(0.2 * z0)}"/>`).join(''); });
      return b; };
    [0.86, 0.6, 0.35, 0.1].forEach(t => s += beam(t));
    return s + light(G, 0.26, 0.05) + mould(G, 5.4, ['#7f4524', '#9c5a33', '#b0683c'], '#d18a5a'); }

  // LIV-069 Parisian plaster: cream ceiling with two panel mouldings (gilded fillet on the inner one) + corner rosettes, a carved
  // acanthus ceiling medallion right above the light, and a deep crown moulding with a dentil row (tier 4: herringbone oak)
  function cMed(G) { let s = `<path d="${G.tr}" fill="#f4eee1"/>` + blots(G, 'md21', 8, ['#fffcf4', '#e9e0cc'], 0.45, 80);
    const frame = (u0, t0, u1, t1, w, gold) => { const d = G.quad(u0, t0, u1, t1); return `<path d="${d}" fill="none" stroke="#d2c6ab" stroke-width="${f1(w * 1.7 * G.s)}" transform="translate(${f1(0.4 * G.s)} ${f1(0.8 * G.s)})"/><path d="${d}" fill="none" stroke="#fffdf8" stroke-width="${f1(w * G.s)}"/>` + (gold ? `<path d="${d}" fill="none" stroke="#c9a35a" stroke-width="${f1(0.4 * G.s)}"/>` : ''); };
    s += frame(0.045, 0.06, 0.955, 0.965, 1.8) + frame(0.085, 0.14, 0.915, 0.925, 1.2, 1);
    [[0.085, 0.14], [0.915, 0.14], [0.085, 0.925], [0.915, 0.925]].forEach(([u, t]) => { const P = E(G, u, t); s += `<ellipse cx="${f1(P.x + 0.5 * P.z)}" cy="${f1(P.y + 0.6 * P.z)}" rx="${f1(3.4 * P.z)}" ry="${f1(3.4 * P.z * P.q)}" fill="#cfc2a6"/><ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(3.4 * P.z)}" ry="${f1(3.4 * P.z * P.q)}" fill="#fffaf0" stroke="#d8cdb4" stroke-width="${f1(0.35 * G.s)}"/><ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(1.3 * P.z)}" ry="${f1(1.3 * P.z * P.q)}" fill="#c9a35a"/>`; });
    { const P = E(G, 0.5, 0.74), z = P.z, sq = P.q, R0 = 46, pt = (r, a) => [P.x + Math.cos(a) * r * R0 * z, P.y + Math.sin(a) * r * R0 * z * sq], PP = (r, a) => P2(pt(r, a));
      let m = `<defs><radialGradient id="mdg" cx="0.38" cy="0.3" r="0.75"><stop offset="0" stop-color="#ffffff"/><stop offset="0.55" stop-color="#f1e9d8"/><stop offset="1" stop-color="#d2c5a8"/></radialGradient></defs>`;
      m += `<ellipse cx="${f1(P.x + 1.2 * z)}" cy="${f1(P.y + 1.6 * z)}" rx="${f1(R0 * 1.04 * z)}" ry="${f1(R0 * 1.04 * z * sq)}" fill="#000000" opacity="0.16" filter="url(#cb3)"/>`;
      const NL = 26, hw = PI / NL * 0.92; let lv = '', ls = '', vn = '';
      for (let i = 0; i < NL; i++) { const a = i / NL * 2 * PI, d = `M${PP(0.56, a - hw)}Q${PP(0.86, a - hw * 1.15)} ${PP(1, a)}Q${PP(0.86, a + hw * 1.15)} ${PP(0.56, a + hw)}Z`, br = 1 - 0.07 * (Math.cos(a) * 0.5 + Math.sin(a) * 0.85);
        ls += d; lv += `<path d="${d}" fill="${shade('#fbf6ea', br)}"/>`; vn += `M${PP(0.6, a)}L${PP(0.93, a)}`; }
      m += `<path d="${ls}" fill="#cbbd9f" transform="translate(${f1(0.7 * z)} ${f1(0.7 * z)})"/>` + lv + `<path d="${vn}" stroke="#d5c8ac" stroke-width="${f1(0.35 * z)}" fill="none"/>`;
      let bd = '', bs = ''; for (let i = 0; i < 34; i++) { const q = pt(0.53, i / 34 * 2 * PI); bs += dot(q[0] + 0.3 * z, q[1] + 0.3 * z, 0.9 * z, 0.9 * z * 0.75); bd += dot(q[0], q[1], 0.9 * z, 0.9 * z * 0.75); }
      m += `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(R0 * 0.5 * z)}" ry="${f1(R0 * 0.5 * z * sq)}" fill="#e4d9c2"/><path d="${bs}" fill="#c7b999"/><path d="${bd}" fill="#fffaf0"/>`
        + `<ellipse cx="${f1(P.x)}" cy="${f1(P.y - 0.5 * z)}" rx="${f1(R0 * 0.42 * z)}" ry="${f1(R0 * 0.42 * z * sq)}" fill="url(#mdg)" stroke="#d6cab0" stroke-width="${f1(0.4 * G.s)}"/>`;
      let pe = ''; for (let i = 0; i < 8; i++) { const a = i / 8 * 2 * PI + 0.2, h2 = PI / 8 * 0.8; pe += `M${PP(0.08, a)}Q${PP(0.24, a - h2)} ${PP(0.31, a)}Q${PP(0.24, a + h2)} ${PP(0.08, a)}Z`; }
      m += `<g transform="translate(0 ${f1(-0.5 * z)})"><path d="${pe}" fill="#efe6d3" stroke="#d0c3a6" stroke-width="${f1(0.3 * z)}"/><ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(R0 * 0.075 * z)}" ry="${f1(R0 * 0.075 * z * sq)}" fill="#fffdf8" stroke="#c9a35a" stroke-width="${f1(0.4 * z)}"/></g>`;
      s += m; }
    const crown = mould(G, 7.5, ['#e6ddca', '#fbf8f1', '#d4c9b1', '#f6f0e4', '#e1d6bf', '#fffdf8'], '#ffffff');
    const B = band(G, 7.5, 0.33, 0.5), y0 = G.H - B.wb * 0.5, y1 = G.H - B.wb * 0.33, st = 4.4 * G.z(G.H); let dn = '';
    for (let x = G.ins + B.wb * 0.8; x < G.W - G.ins - B.wb * 0.8 - st * 0.6; x += st) dn += `M${f1(x)} ${f1(y0)}h${f1(st * 0.62)}V${f1(y1)}h${f1(-st * 0.62)}Z`;
    return s + light(G, 0.24, 0.05) + crown + `<path d="${B.back}" fill="#bfb194"/><path d="${dn}" fill="#fffaf0"/><path d="M${f1(G.ins + B.wb)} ${f1(y1 + 0.3 * G.s)}H${f1(G.W - G.ins - B.wb)}" stroke="#c9a35a" stroke-width="${f1(0.4 * G.s)}"/>`; }

  // LIV-089 double-height glass atrium: polished white ceiling with a brass-rimmed opening; inside it the white shaft walls rise to a
  // glazed barrel vault (steel ribs + purlins, a glass gable at the far end) with blue sky, drifting clouds, sun glints, a bird now and then
  function cVault(G) { const VY = G.VY, u0 = 0.16, u1 = 0.84, t0 = 0.1, t1 = 0.8, m0 = 1.2, bmp = 0.28;
    const hi = (u, t, m) => { const y = G.y(t); return [G.x(u, y), VY - (VY - y) * m]; };
    const mu = u => m0 + bmp * Math.sin(PI * Math.min(1, Math.max(0, (u - u0) / (u1 - u0))));
    const O = G.quad(u0, t0, u1, t1), TS = rep(13, i => t0 + (t1 - t0) * i / 12), US = rep(25, i => u0 + (u1 - u0) * i / 24);
    let s = `<path d="${G.tr}" fill="#f3f0ea"/>` + blots(G, 'vt21', 6, ['#ffffff', '#e6e1d8'], 0.45, 80) + `<path d="${O}" fill="none" stroke="#ffffff" stroke-width="${f1(30 * G.s)}" opacity="0.6" filter="url(#cb6)"/>`;
    let v = `<defs><linearGradient id="vsk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a8fd9"/><stop offset="0.65" stop-color="#93c3ee"/><stop offset="1" stop-color="#d9edfb"/></linearGradient><clipPath id="vop"><path d="${O}"/></clipPath>`
      + `<linearGradient id="vfw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f7f4ee"/><stop offset="1" stop-color="#d9d3c8"/></linearGradient></defs><rect x="0" y="0" width="${G.W}" height="${G.H}" fill="url(#vsk)"/>`;
    v += `<ellipse cx="${f1(G.W * 0.66)}" cy="${f1(G.H * 0.22)}" rx="${f1(G.W * 0.08)}" ry="${f1(G.H * 0.2)}" fill="#fffbe6" opacity="0.75" filter="url(#cb6)"/>`;
    v += '<g filter="url(#cb3)">' + [[0.3, 0.35, 1], [0.55, 0.5, 0.8], [0.75, 0.3, 0.9], [0.42, 0.62, 0.6], [0.2, 0.55, 0.7], [0.66, 0.66, 0.55]].map(([u, h, sz], i) => { const x = G.W * u, y = G.H * h, w = G.W * 0.05 * sz, dx = f1(G.W * 0.05 * (i % 2 ? -1 : 1));
      return `<g opacity="0.92">${at('translate', `0 0;${dx} 0;0 0`, 40 + i * 7, -i * 6, SPL(2))}<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(w)}" ry="${f1(w * 0.28)}" fill="#ffffff"/><ellipse cx="${f1(x - w * 0.5)}" cy="${f1(y + w * 0.05)}" rx="${f1(w * 0.6)}" ry="${f1(w * 0.2)}" fill="#ffffff"/><ellipse cx="${f1(x + w * 0.4)}" cy="${f1(y - w * 0.08)}" rx="${f1(w * 0.55)}" ry="${f1(w * 0.24)}" fill="#f4f8fc"/></g>`; }).join('') + '</g>';
    { const z = G.z(G.y(0.5)), y = G.H * 0.42, x0 = G.W * 0.12, x1 = G.W * 0.9, KT = ' keyTimes="0;0.5;0.55;0.84;0.88;1"';
      v += `<g opacity="0">${an('opacity', '0;0;1;1;0;0', 19, -3, KT)}${at('translate', `${f1(x0)} ${f1(y)};${f1(x0)} ${f1(y)};${f1(x0 + (x1 - x0) * 0.1)} ${f1(y - 2 * z)};${f1(x1)} ${f1(y - 9 * z)};${f1(x1)} ${f1(y - 9 * z)};${f1(x1)} ${f1(y - 9 * z)}`, 19, -3, KT)}<g transform="scale(${n4(z)})"><path d="M-3 0Q-1.5 -1.8 0 0Q1.5 -1.8 3 0" stroke="#2c3a4a" stroke-width="0.6" fill="none">${an('d', 'M-3 0Q-1.5 -1.8 0 0Q1.5 -1.8 3 0;M-3 -1.2Q-1.5 0.6 0 0Q1.5 0.6 3 -1.2;M-3 0Q-1.5 -1.8 0 0Q1.5 -1.8 3 0', 0.5)}</path></g></g>`; }
    const side = (u, col) => `<path d="M${TS.map(t => P2(hi(u, t, 1))).join('L')}L${TS.slice().reverse().map(t => P2(hi(u, t, m0))).join('L')}Z" fill="${col}"/>`;
    v += side(u0, '#ece8e0') + side(u1, '#d6d0c4') + `<path d="M${US.map(u => P2(hi(u, t1, 1))).join('L')}L${US.slice().reverse().map(u => P2(hi(u, t1, m0))).join('L')}Z" fill="url(#vfw)"/>`;
    v += `<path d="M${US.map(u => P2(hi(u, t1, m0))).join('L')}" stroke="#c9a04a" stroke-width="${f1(1 * G.z(G.H) )}" fill="none"/>`;
    v += `<path d="M${G.P(u0, t0)}L${G.P(u0, t1)}L${G.P(u1, t1)}L${G.P(u1, t0)}" fill="none" stroke="#000000" stroke-opacity="0.12" stroke-width="${f1(2 * G.s)}"/>`;
    v += `<rect x="${f1(-G.W * 0.4)}" y="0" width="${f1(G.W * 0.12)}" height="${G.H}" fill="#ffffff" opacity="0.16" transform="skewX(-25)">${at('translate', `0 0;0 0;${f1(G.W * 1.7)} 0`, 12, 0, ' keyTimes="0;0.55;1"')}</rect>`;
    let rib = '', ribH = ''; TS.filter((_, i) => i % 2 === 0).forEach(t => { const d = 'M' + US.map(u => P2(hi(u, t, mu(u)))).join('L'); rib += d; });
    rep(5, j => { const u = u0 + (u1 - u0) * (j + 1) / 6, d = 'M' + TS.map(t => P2(hi(u, t, mu(u)))).join('L'), g = `M${P2(hi(u, t1, m0))}L${P2(hi(u, t1, mu(u)))}`; rib += d + g; ribH += d; });
    const base = `M${TS.map(t => P2(hi(u0, t, m0))).join('L')}L${US.map(u => P2(hi(u, t1, m0))).join('L')}L${TS.slice().reverse().map(t => P2(hi(u1, t, m0))).join('L')}`;
    const sw = G.z(G.y(0.6));
    v += `<path d="${rib}" stroke="#7d8996" stroke-width="${f1(1.7 * sw)}" fill="none" stroke-linejoin="round"/><path d="${rib}" stroke="#f4f6f8" stroke-width="${f1(0.9 * sw)}" fill="none" stroke-linejoin="round"/><path d="${ribH}" stroke="#ffffff" stroke-width="${f1(0.3 * sw)}" fill="none" transform="translate(${f1(-0.3 * sw)} 0)"/>`
      + `<path d="${base}" stroke="#8c96a0" stroke-width="${f1(2.6 * sw)}" fill="none"/><path d="${base}" stroke="#fbfbfa" stroke-width="${f1(1.6 * sw)}" fill="none"/>`;
    s += `<g clip-path="url(#vop)">${v}</g>`;
    s += `<path d="${O}" fill="none" stroke="#9e7424" stroke-width="${f1(3.4 * G.s)}"/><path d="${O}" fill="none" stroke="#e2b552" stroke-width="${f1(2 * G.s)}"/><path d="${O}" fill="none" stroke="#fff0b8" stroke-width="${f1(0.5 * G.s)}" transform="translate(0 ${f1(-0.5 * G.s)})"/>`;
    return s + light(G, 0.16, 0.04) + mould(G, 4.4, ['#ddd8cf', '#f6f3ee', '#ebe7e0'], '#ffffff', `<path d="${band(G, 4.4, 0, 1).lip}" stroke="#d4a548" stroke-width="${f1(0.5 * G.s)}" fill="none" transform="translate(0 ${f1(0.6 * G.s)})"/>`); }

  // card: the tier's Living Room wall below the ceiling
  const WALLC = { pop: '#ebe2ca', cove: '#9caf8b', beam: '#eee2c6', med: '#b98a58', vault: '#f2efea' };
  const CBASE = { pop: ['#e6dbbd', '#e2d5b2'], cove: ['#f2eee5', '#efeae0'], beam: ['#e9e0cf', '#9c5a33'], med: ['#f4eee1', '#f6f0e4'], vault: ['#f3f0ea', '#ebe7e0'] };
  const CEIL21 = { pop: cPop, cove: cCove, beam: cBeam, med: cMed, vault: cVault };
  const cardOf = k => { const G = mkV(FRM.card), w = WALLC[k];
    return '<path d="M16 26H64V56H16Z" fill="' + w + '"/><path d="M0 0L16 26V56H0Z" fill="' + shade(w, 0.88) + '"/><path d="M80 0L64 26V56H80Z" fill="' + shade(w, 0.8) + '"/><path d="M16 26V56M64 26V56" stroke="#000000" stroke-opacity="0.2" stroke-width="0.6"/>'
      + doc(G, CEIL21[k](G)) + '<path d="' + G.tr + '" fill="none" stroke="#000000" stroke-opacity="0.25" stroke-width="0.5"/>'; };

  // ======================= OVERHEAD LIGHTS (ceiling pieces) =======================
  const DEF21 = DEF11 + '<filter id="l21b1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.8"/></filter><filter id="l21b3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>'
    + '<radialGradient id="l21w" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff0c0" stop-opacity="0.85"/><stop offset="0.35" stop-color="#ffd27a" stop-opacity="0.35"/><stop offset="1" stop-color="#ffc060" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="l21c" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#eef8ff" stop-opacity="0.85"/><stop offset="0.35" stop-color="#9fd6ff" stop-opacity="0.3"/><stop offset="1" stop-color="#7ab8ff" stop-opacity="0"/></radialGradient>'
    + '<linearGradient id="l21m" x1="0" y1="0" x2="1" y2="0.3"><stop offset="0" stop-color="#f3dcb8" stop-opacity="0.85"/><stop offset="0.45" stop-color="#c49a6e" stop-opacity="0.62"/><stop offset="1" stop-color="#6a4c36" stop-opacity="0.8"/></linearGradient>';
  const glow = (C, q, r, op, A, g) => { const c = C.P(q); return `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * C.k)}" fill="url(#${g || 'l21w'})" opacity="${op}">${A || ''}</circle>`; };
  const ring = (C, y, r, a0, a1, n) => rep(n + 1, i => { const a = a0 + (a1 - a0) * i / n; return C.p(r * Math.sin(a), y, r * Math.cos(a)); });
  const swing = (C, q, deg, T, b) => { const c = C.P(q); return `<animateTransform attributeName="transform" type="rotate" values="${-deg} ${P2(c)};${deg} ${P2(c)};${-deg} ${P2(c)}" dur="${n4(T)}s" begin="${n4(b || 0)}s" repeatCount="indefinite"${SPL(2)}/>`; };
  const FLK = (T, b) => an('opacity', '1;0.88;1;0.66;1;1', T, b, ' keyTimes="0;0.3;0.45;0.5;0.56;1"');
  const ellOf = (C, y, r) => { const c = C.P([0, y, 0]), f = C.P([r * Math.sin(C.thV), y, r * Math.cos(C.thV)]); C.P([r, y, 0]); C.P([-r, y, 0]); C.P([0, y, r]); C.P([0, y, -r]); return { x: c[0], y: c[1], rx: r * C.k, ry: Math.max(0.3, Math.abs(f[1] - c[1])) }; };

  // LIV-018 yellowed plastic dome "boob light": metal ring, frosted dome gone yellow, a few dead bugs inside, chrome finial nut; flickers
  N.dome21 = S => { const T = 12, D = { w: 30, d: 30, zs: 1.6, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx), k = C.k, R0 = 12.5, yR = T - 2.2, e = ellOf(C, yR, R0), bot = C.P([0, yR - 7.5, 0]), rd = Math.max(e.ry + 1, bot[1] - e.y), g = C.u('dg');
      const d = `M${f1(e.x - e.rx)} ${f1(e.y)}A${f1(e.rx)} ${f1(rd)} 0 0 0 ${f1(e.x + e.rx)} ${f1(e.y)}A${f1(e.rx)} ${f1(e.ry)} 0 0 0 ${f1(e.x - e.rx)} ${f1(e.y)}Z`;
      let s = `<defs><radialGradient id="${g}" gradientUnits="userSpaceOnUse" cx="${f1(e.x - e.rx * 0.3)}" cy="${f1(e.y + rd * 0.2)}" r="${f1(e.rx * 1.3)}"><stop offset="0" stop-color="#fff7d2"/><stop offset="0.45" stop-color="#f1d98e"/><stop offset="0.85" stop-color="#d6ad56"/><stop offset="1" stop-color="#b08436"/></radialGradient></defs>`;
      s += glow(C, [0, T, 0], 30, 0.6, FLK(6.1)) + cyl3(C, [0, yR, 0], [0, T, 0], R0 + 0.7, '#dcd6c8');
      s += `<path d="${d}" fill="url(#${g})" stroke="#a37a34" stroke-width="${f1(0.3 * k)}"/>`;
      s += `<g opacity="0.55">${[[-3.2, 0.62, 0.3], [1.8, 0.7, -0.5], [4.6, 0.5, 1]].map(([dx, f, r]) => { const x = e.x + dx * k, y = e.y + rd * f; return `<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(0.7 * k)}" ry="${f1(0.38 * k)}" fill="#4e3a1a" transform="rotate(${f1(r * 40)} ${f1(x)} ${f1(y)})"/><path d="M${f1(x - 0.9 * k)} ${f1(y - 0.4 * k)}l${f1(0.5 * k)} ${f1(0.3 * k)}M${f1(x + 0.9 * k)} ${f1(y - 0.3 * k)}l${f1(-0.5 * k)} ${f1(0.3 * k)}M${f1(x - 0.8 * k)} ${f1(y + 0.5 * k)}l${f1(0.4 * k)} ${f1(-0.3 * k)}" stroke="#4e3a1a" stroke-width="${f1(0.15 * k)}"/>`; }).join('')}</g>`;
      s += `<g>${FLK(6.1)}<ellipse cx="${f1(e.x)}" cy="${f1(e.y + rd * 0.42)}" rx="${f1(e.rx * 0.5)}" ry="${f1(rd * 0.32)}" fill="#fffbe6" opacity="0.75" filter="url(#l21b1)"/></g>`;
      s += `<path d="M${f1(e.x - e.rx * 0.7)} ${f1(e.y + rd * 0.25)}Q${f1(e.x - e.rx * 0.55)} ${f1(e.y + rd * 0.7)} ${f1(e.x - e.rx * 0.15)} ${f1(e.y + rd * 0.86)}" stroke="#ffffff" stroke-width="${f1(0.7 * k)}" fill="none" opacity="0.6" stroke-linecap="round"/>`;
      s += cyl3(C, [0, yR - 7.1, 0], [0, yR - 7.9, 0], 1.6, '#c9ced2', { mat: 'gloss', olw: 0.4 }) + sph(C, [0, yR - 8.4, 0], 0.9, '#dfe3e6');
      return { defs: DEF21, front: s, bb: C.bb(4) }; };
    return D; };

  // LIV-038 woven rattan boho pendant: rattan canopy, black cord, bell shade of criss-cross rattan strands glowing warm through the gaps,
  // dappled light spots on the ceiling; sways gently
  N.rattan21 = S => { const T = 48, D = { w: 40, d: 40, zs: 1.6, mount: 'ceil', build: () => [] };
    const prof = [[T - 15, 4], [T - 18, 9.5], [T - 22, 13.5], [T - 30, 16.6], [T - 38, 17.8], [6, 18.2]];
    const rr = y => { for (let i = 1; i < prof.length; i++) { const [ya, ra] = prof[i - 1], [yb, rb] = prof[i]; if (y >= yb) return ra + (rb - ra) * (ya - y) / (ya - yb); } return 18.2; };
    D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('rat21'); let sp = '', sh = '';
      rep(16, i => { const a = i / 16 * 2 * PI + R() * 0.3, r = 12 + R() * 18, q = C.p(r * Math.sin(a), T, r * Math.cos(a)); sp += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((1.2 + R()) * k)}" ry="${f1(0.55 * k)}" fill="#ffe2a6">${an('opacity', '0.2;0.75;0.2', n4(2.6 + R() * 2.4), n4(-R() * 3), SPL(2))}</ellipse>`; });
      sh += glow(C, [0, 2, 0], 24, 0.55) + cyl3(C, [0, T - 1.6, 0], [0, T - 15, 0], 0.35, '#2a2420', { olw: 0.3 });
      for (let i = 1; i < prof.length; i++) sh += cyl3(C, [0, prof[i - 1][0], 0], [0, prof[i][0], 0], prof[i - 1][1], '#f7cf84', { r2: prof[i][1], olw: 0 });
      const NS = 22, NY = 16, ys = rep(NY, i => T - 15 + (6 - (T - 15)) * i / (NY - 1)); let st = '';
      [1, -1].forEach(sg => rep(NS, j => { let d = '', on = false; ys.forEach((y, i) => { const f = i / (NY - 1), a = 2 * PI * j / NS + sg * 1.25 * f, vis = Math.cos(a - C.thV) > 0.02, q = C.p(rr(y) * Math.sin(a), y, rr(y) * Math.cos(a));
        if (vis) { d += (on ? 'L' : 'M') + P2(q); on = true; } else on = false; }); st += d; }));
      sh += `<path d="${st}" stroke="#7e4f22" stroke-width="${f1(1.25 * k)}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${st}" stroke="#c48a4c" stroke-width="${f1(0.8 * k)}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${st}" stroke="#ebc08a" stroke-width="${f1(0.25 * k)}" fill="none" transform="translate(${f1(-0.2 * k)} ${f1(-0.2 * k)})"/>`;
      const arc = (y, w) => { const P = ring(C, y, rr(y) + 0.15, C.thV - PI / 2, C.thV + PI / 2, 22); return `<path d="M${P.map(P2).join('L')}" stroke="#6e431c" stroke-width="${f1(w * k)}" fill="none" stroke-linecap="round"/><path d="M${P.map(P2).join('L')}" stroke="#d29a5a" stroke-width="${f1(w * 0.45 * k)}" fill="none" transform="translate(0 ${f1(-w * 0.2 * k)})" stroke-linecap="round"/>`; };
      sh += arc(T - 15.4, 1.4) + arc(T - 22, 0.9) + arc(T - 38, 0.9) + arc(6.4, 1.9);
      const top = cyl3(C, [0, T - 1.6, 0], [0, T, 0], 3.4, '#c99a5a', { olw: 0.5 });
      return { defs: DEF21, front: sp + top + `<g>${swing(C, [0, T - 1.6, 0], 2.2, 5.6)}${sh}</g>`, bb: C.bb(5) }; };
    return D; };

  // LIV-058 Sputnik chandelier: brushed-brass hub ball on a rod, 12 arms in every direction (icosahedron), each with a socket and a
  // round bulb; bulbs twinkle softly and it sways a little
  N.sput21 = S => { const T = 40, HY = 19, L = 17, GD = '#c9a04a', D = { w: 66, d: 66, zs: 1.5, mount: 'ceil', build: () => [] };
    const ph = (1 + Math.sqrt(5)) / 2, V = [[0, 1, ph], [0, 1, -ph], [0, -1, ph], [0, -1, -ph], [1, ph, 0], [1, -ph, 0], [-1, ph, 0], [-1, -ph, 0], [ph, 0, 1], [ph, 0, -1], [-ph, 0, 1], [-ph, 0, -1]]
      .map(v => { const n = Math.hypot(...v), c = Math.cos(0.35), s2 = Math.sin(0.35), x = v[0] / n, y = v[1] / n, z = v[2] / n, x2 = x * c - y * s2, y2 = x * s2 + y * c; return [x2, y2, z]; });
    D.fx = ctx => { const C = cam(ctx), v = C.v, A = [];
      V.forEach((d, i) => { const p = (r, o) => [d[0] * r, HY + d[1] * r + (o || 0), d[2] * r], e = p(L), b = p(L + 3.4);
        A.push({ q: e, s: cyl3(C, p(3), e, 0.42, GD, { mat: 'gloss', olw: 0.35 }) + cyl3(C, e, p(L + 1.5), 0.95, '#a7802f', { mat: 'gloss', olw: 0.35 }) + glow(C, b, 7, 0.75, an('opacity', '0.5;0.95;0.5', 2.2 + (i % 4) * 0.55, -i * 0.37, SPL(2))) + sph(C, b, 1.9, '#fff5d8', { op: 0.96 }) }); });
      const isF = o => o.q[0] * v[0] + o.q[2] * v[2] > 0, Ab = A.filter(o => !isF(o)), Af = A.filter(isF);
      let s = glow(C, [0, HY, 0], 46, 0.5, an('opacity', '0.4;0.6;0.4', 5, 0, SPL(2))) + zsort(C, Ab) + cyl3(C, [0, HY + 3, 0], [0, T, 0], 0.6, GD, { mat: 'gloss', olw: 0.35 }) + sph(C, [0, HY, 0], 3.8, GD) + zsort(C, Af);
      return { defs: DEF21, front: cyl3(C, [0, T - 1.2, 0], [0, T, 0], 4.4, GD, { mat: 'gloss' }) + `<g>${swing(C, [0, T, 0], 1.2, 7)}${s}</g>`, bb: C.bb(5) }; };
    return D; };

  // LIV-078 tiered Murano chandelier: brass canopy + column, three brass rings hung with hand-blown smoked-amber glass drops (each
  // swings on its hook and catches a glint), warm light glowing inside each tier
  N.mura21 = S => { const T = 60, GD = '#c9a04a', TI = [{ y: 45, r: 8, n: 8, h: 8 }, { y: 33, r: 13, n: 11, h: 10 }, { y: 20, r: 18.5, n: 14, h: 12 }], D = { w: 46, d: 46, zs: 1.6, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx), k = C.k, v = C.v, L = []; let gl = '';
      const rp = (P, w) => `<path d="M${P.map(P2).join('L')}" stroke="${GD}" stroke-width="${f1(w * k)}" fill="none" stroke-linecap="round"/><path d="M${P.map(P2).join('L')}" stroke="#fff0b8" stroke-opacity="0.5" stroke-width="${f1(w * 0.3 * k)}" fill="none" transform="translate(0 ${f1(-w * 0.25 * k)})"/>`;
      let n = 0;
      TI.forEach((t, ti) => { gl += glow(C, [0, t.y - t.h * 0.4, 0], t.r * 1.5, 0.6, an('opacity', '0.45;0.7;0.45', 4 + ti, -ti, SPL(2)));
        rep(t.n, i => { const a = i / t.n * 2 * PI + ti * 0.4, x = t.r * Math.sin(a), z = t.r * Math.cos(a), p = C.P([x, t.y, z]), w = t.h * 0.44 * k, h = t.h * k, id = n++;
          const d = `M${f1(p[0])} ${f1(p[1])}C${f1(p[0] + w)} ${f1(p[1] + h * 0.22)} ${f1(p[0] + w * 0.75)} ${f1(p[1] + h * 0.86)} ${f1(p[0])} ${f1(p[1] + h)}C${f1(p[0] - w * 0.75)} ${f1(p[1] + h * 0.86)} ${f1(p[0] - w)} ${f1(p[1] + h * 0.22)} ${f1(p[0])} ${f1(p[1])}Z`;
          const sw = `${f1(p[0])} ${f1(p[1])}`, s = `<g>${at('rotate', `-4 ${sw};4 ${sw};-4 ${sw}`, 2.8 + (id % 5) * 0.45, -id * 0.31, SPL(2))}<path d="${d}" fill="url(#l21m)" stroke="#2e2119" stroke-width="${f1(0.22 * k)}"/>`
            + `<path d="M${f1(p[0] - w * 0.45)} ${f1(p[1] + h * 0.25)}Q${f1(p[0] - w * 0.55)} ${f1(p[1] + h * 0.6)} ${f1(p[0] - w * 0.15)} ${f1(p[1] + h * 0.85)}" stroke="#fff4dc" stroke-width="${f1(0.35 * k)}" fill="none" opacity="0.55" stroke-linecap="round"/>`
            + `<circle cx="${f1(p[0] - w * 0.3)}" cy="${f1(p[1] + h * 0.35)}" r="${f1(0.6 * k)}" fill="#ffffff" opacity="0">${an('opacity', '0;0;1;0;0', 3 + (id % 6) * 0.5, -id * 0.41, ' keyTimes="0;0.6;0.68;0.78;1"')}</circle>`
            + `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.45 * k)}" fill="${GD}"/></g>`;
          L.push({ q: [x, t.y - t.h * 0.5, z], s }); }); });
      const isF = o => o.q[0] * v[0] + o.q[2] * v[2] > 0, Lb = L.filter(o => !isF(o)), Lf = L.filter(isF), bk = C.thV + PI;
      const rings = (a0, a1) => TI.map(t => rp(ring(C, t.y, t.r, a0, a1, 24), 0.9)).join('');
      const arms = TI.map(t => rep(4, i => { const a = i * PI / 2 + 0.4; return `<path d="M${P2(C.p(0, t.y + 3, 0))}L${P2(C.p(t.r * Math.sin(a), t.y, t.r * Math.cos(a)))}" stroke="${GD}" stroke-width="${f1(0.5 * k)}"/>`; }).join('')).join('');
      let body = gl + zsort(C, Lb) + rings(bk - PI / 2, bk + PI / 2) + arms + cyl3(C, [0, 9, 0], [0, T - 1.4, 0], 0.8, GD, { mat: 'gloss', olw: 0.35 }) + sph(C, [0, 8.6, 0], 1.6, GD) + TI.map(t => sph(C, [0, t.y + 2.6, 0], 1.3, GD)).join('') + rings(C.thV - PI / 2, C.thV + PI / 2) + zsort(C, Lf);
      return { defs: DEF21, front: cyl3(C, [0, T - 1.4, 0], [0, T, 0], 5, GD, { mat: 'gloss' }) + `<g>${swing(C, [0, T, 0], 1, 8)}${body}</g>`, bb: C.bb(5) }; };
    return D; };

  // LIV-098 kinetic floating crystal constellation: a slim glowing disc on the ceiling, 26 cut crystals floating below it with no wires,
  // each bobbing on its own, joined by fine light lines (pulses run along some), crystals shift colour and sparkle
  N.const21 = S => { const T = 52, D = { w: 90, d: 90, zs: 1.4, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('cst21'), P = [];
      rep(26, i => { const f = i / 25, a = f * 4.4 * PI + R() * 0.3, rd = 4 + 32 * (1 - f) + R() * 3, y = T - 9 - f * 34 + R() * 2; P.push({ q: [rd * Math.sin(a), Math.max(6, y), rd * Math.cos(a)], s: (1.4 + R() * 1.7), A: (0.9 + R() * 1.3) * k, T: 3 + R() * 3.4, b: -R() * 4 }); });
      P.forEach(o => { o.p = C.P(o.q); });
      const bob = (o, at2, v0) => `<animate attributeName="${at2}" values="${f1(v0)};${f1(v0 - o.A)};${f1(v0)}" dur="${n4(o.T)}s" begin="${n4(o.b)}s" repeatCount="indefinite"${SPL(2)}/>`;
      const seen = {}; let ln = '';
      P.forEach((o, i) => { P.map((q, j) => [j, Math.hypot(q.q[0] - o.q[0], q.q[1] - o.q[1], q.q[2] - o.q[2])]).filter(([j]) => j !== i).sort((a, b) => a[1] - b[1]).slice(0, 2).forEach(([j]) => {
        const key = Math.min(i, j) + '_' + Math.max(i, j); if (seen[key]) return; seen[key] = 1; const q = P[j], len = Math.hypot(q.p[0] - o.p[0], q.p[1] - o.p[1]) + 1, A1 = bob(o, 'y1', o.p[1]) + bob(q, 'y2', q.p[1]);
        ln += `<line x1="${f1(o.p[0])}" y1="${f1(o.p[1])}" x2="${f1(q.p[0])}" y2="${f1(q.p[1])}" stroke="#bfe8ff" stroke-opacity="0.8" stroke-width="${f1(0.3 * k)}">${A1}</line>`;
        if ((i + j) % 3 === 0) ln += `<line x1="${f1(o.p[0])}" y1="${f1(o.p[1])}" x2="${f1(q.p[0])}" y2="${f1(q.p[1])}" stroke="#ffffff" stroke-width="${f1(0.5 * k)}" stroke-linecap="round" stroke-dasharray="${f1(2 * k)} ${f1(len * 2)}">${A1}<animate attributeName="stroke-dashoffset" values="${f1(len)};${f1(-len)}" dur="${n4(1.8 + (i % 4) * 0.4)}s" begin="${n4(-i * 0.3)}s" repeatCount="indefinite"/></line>`; }); });
      const CR = ['#e8f6ff', '#f1e6ff', '#e4fff4', '#fff4e0'];
      const L = P.map((o, i) => { const s = o.s * k, c = [-0.2 * s, -0.25 * s], tp = [0, -1.7 * s], rt = [s, 0], bt = [0, 1.7 * s], lf = [-s, 0], tri = (a, b, f) => `<path d="M${P2(a)}L${P2(b)}L${P2(c)}Z" fill="${f}"/>`;
        const g = tri(lf, tp, '#ffffff') + tri(tp, rt, '#cfe6ff') + tri(rt, bt, '#86aad0') + tri(bt, lf, '#b4d0ee')
          + `<path d="M${P2(tp)}L${P2(rt)}L${P2(bt)}L${P2(lf)}Z" fill="${CR[i % 4]}" opacity="0.35">${an('fill', (m => m.concat(m[0]))(CR.slice(i % 4).concat(CR.slice(0, i % 4))).join(';'), 9 + (i % 3) * 2, -i * 0.7)}</path><path d="M${P2(tp)}L${P2(rt)}L${P2(bt)}L${P2(lf)}Z" fill="none" stroke="#6f93b8" stroke-width="${f1(0.18 * k)}"/>`
          + `<path d="M0 ${f1(-2.4 * s)}V${f1(2.4 * s)}M${f1(-2.4 * s)} 0H${f1(2.4 * s)}" stroke="#ffffff" stroke-width="${f1(0.25 * k)}" opacity="0" stroke-linecap="round">${an('opacity', '0;0;1;0;0', 3.4 + (i % 5) * 0.7, -i * 0.53, ' keyTimes="0;0.7;0.76;0.84;1"')}</path>`;
        return { q: o.q, s: `<g transform="translate(${f1(o.p[0])} ${f1(o.p[1])})"><g>${at('translate', `0 0;0 ${f1(-o.A)};0 0`, o.T, o.b, SPL(2))}${g}</g></g>` }; });
      let s = glow(C, [0, T - 2, 0], 40, 0.5, '', 'l21c') + glow(C, [0, 30, 0], 52, 0.45, an('opacity', '0.3;0.55;0.3', 6, 0, SPL(2)), 'l21c') + cyl3(C, [0, T - 1.4, 0], [0, T, 0], 10, '#eef2f6', { mat: 'gloss' });
      { const e = ellOf(C, T - 1.5, 9.2); s += `<ellipse cx="${f1(e.x)}" cy="${f1(e.y)}" rx="${f1(e.rx)}" ry="${f1(e.ry)}" fill="none" stroke="#9fe2ff" stroke-width="${f1(0.6 * k)}">${an('stroke-opacity', '0.4;1;0.4', 3, 0, SPL(2))}</ellipse>`; }
      s += ln + zsort(C, L);
      return { defs: DEF21, front: s, bb: C.bb(8) }; };
    return D; };

  const draw20 = RD.draw, MEMO = {};
  RD.draw = (r, o) => { const res = draw20(r, o); if (!res || res._p21) return res;
    try { const k = r.c21 && CEIL21[r.c21]; if (k && res.surf) { res._p21 = 1; res.vb = '0 0 80 56';
      const M = MEMO[r.c21] || (MEMO[r.c21] = (() => { const G = mkV(FRM.room); return { svg: RD.svgDoc('0 0 80 56', [], cardOf(r.c21)), room: RD.svgDoc('0 0 ' + G.W + ' ' + G.H, [], doc(G, k(G))) }; })());
      res.svg = M.svg; res.src = 'data:image/svg+xml,' + encodeURIComponent(M.svg); res.ceilRoom = M.room; res.ceilBase = CBASE[r.c21][0]; res.ceilTrim = CBASE[r.c21][1]; } } catch (e) { console.warn('reno plus21', r.id, e); }
    return res; };

  RD.SET21 = {
    'LIV-009': { c21: 'pop', live: 'Fluttering paint flake', note: 'An old popcorn stucco ceiling gone yellow, with brown rings where the roof once leaked, a hairline crack, a cobweb in the corner and a peeled patch where a curl of paint hangs and flutters in the draft.' },
    'LIV-029': { c21: 'cove', live: 'Blinking smoke alarm', note: 'A smooth, freshly skimmed warm-white ceiling with a deep curved cove moulding all round, a soft sage glow from the walls, a white air vent and a smoke alarm whose little red light blinks.' },
    'LIV-049': { c21: 'beam', note: 'Four heavy cedar beams across the room with real grain, knots and checks, held by black iron straps, over whitewashed pine boards and a cedar wall plate.' },
    'LIV-069': { c21: 'med', note: 'A cream plaster ceiling with two panel mouldings (the inner one with a thin gilded line), corner rosettes, a carved acanthus medallion right above the light and a deep crown moulding with a dentil row.' },
    'LIV-089': { c21: 'vault', live: 'Drifting clouds', note: 'A brass-rimmed opening in the polished white ceiling rises to a glass barrel vault: steel ribs, blue sky, slow drifting clouds, a sun glint gliding over the glass and now and then a bird flying over.' },
    'LIV-018': { spec: 'dome21', s3: null, live: 'Flickering', note: 'A cheap frosted plastic dome light that has gone yellow, on a metal ring with a chrome nut at the bottom. A few dead bugs sit inside and it flickers now and then.' },
    'LIV-038': { spec: 'rattan21', s3: null, live: 'Swaying shade', note: 'A bell-shaped pendant of criss-cross woven rattan on a black cord. Warm light glows through the gaps and throws dappled spots on the ceiling while it sways gently.' },
    'LIV-058': { spec: 'sput21', s3: null, live: 'Twinkling bulbs', note: 'A brushed-brass Sputnik chandelier: a brass ball on a rod with 12 arms reaching out in every direction, each ending in a round glowing bulb that twinkles softly.' },
    'LIV-078': { spec: 'mura21', s3: null, live: 'Swinging glass', note: 'Three brass rings in tiers hung with hand-blown smoked-amber Murano glass drops. Warm light glows inside, each drop swings on its hook and catches a glint.' },
    'LIV-098': { spec: 'const21', s3: null, live: 'Floating crystals', note: 'A slim glowing disc on the ceiling with 26 cut crystals floating below it on no wires, each bobbing on its own, joined by fine light lines with pulses running along them while the crystals shift colour and sparkle.' },
  };
  const edit20 = RD.edit;
  RD.edit = rows => edit20(rows).map(r => RD.SET21[r.id] ? Object.assign({}, r, RD.SET21[r.id]) : r);
  RD.H21 = { CEIL21, band, mould, mkV };
  RD.PLUS21 = 1;
})();
