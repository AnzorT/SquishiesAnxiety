/* Squish Squad shared motion rig — extracted from Care Motion System.dc.html */
(function(){
const TAU = Math.PI * 2;
const CREATURES = [
  { name: 'Glorp', src: 'export/creatures/01-glorp.png', ink: '#3d1656', mouthInk: '#2a0f2e', cheek: null, sclera: true, iris: '#5a1f80', irisK: 0.43,
    patch: { cx: 49.4, cy: 51.9, rx: 14.8, ry: 19.5, top: '#37d2bd', bot: '#16af9f' },
    eyes: [{ x: 49.4, y: 48, r: 11.2 }], mouth: { x: 50, y: 63, w: 13 }, cheeks: [], head: 17 },
  { name: 'Puffle', src: 'export/creatures/02-puffle.png', ink: '#4a1a6b', mouthInk: '#3a1040', cheek: '#ff86c8', sclera: true, iris: '#4a1a6b', irisK: 0.5,
    patch: { cx: 50, cy: 51.9, rx: 18.5, ry: 14, top: '#ecbdff', bot: '#d296ff' },
    eyes: [{ x: 40, y: 46.2, r: 5 }, { x: 60, y: 46.2, r: 5 }], mouth: { x: 50, y: 59, w: 13 },
    cheeks: [{ x: 31, y: 54 }, { x: 69, y: 54 }], head: 19 },
  { name: 'Nubbin', src: 'export/creatures/03-nubbin.png', ink: '#141a33', mouthInk: '#141a33', cheek: '#ff6f96',
    patch: { cx: 50, cy: 54.3, rx: 18, ry: 14, top: '#ff9442', bot: '#fb701d' },
    eyes: [{ x: 41, y: 45, r: 4.6 }, { x: 58.6, y: 45, r: 4.6 }], mouth: { x: 50, y: 61, w: 13 },
    cheeks: [{ x: 31, y: 57.6 }, { x: 69, y: 57.6 }], head: 19 },
  { name: 'Dotty', src: 'export/creatures/04-dotty.png', ink: '#3d1656', mouthInk: '#91295c', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.42,
    patch: { cx: 50, cy: 55.5, rx: 17.1, ry: 14.2, top: '#fad746', bot: '#f5c51c' },
    eyes: [{ x: 41.7, y: 49.7, r: 4.8 }, { x: 58.2, y: 49.7, r: 4.8 }], mouth: { x: 50, y: 60.3, w: 14.0 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 17.5 },
  { name: 'Spike', src: 'export/creatures/05-spike.png', ink: '#3d1656', mouthInk: '#8f2b5d', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.45,
    patch: { cx: 50, cy: 53.5, rx: 17.7, ry: 14.4, top: '#51d682', bot: '#2cbe62' },
    eyes: [{ x: 40.6, y: 46.8, r: 4.2 }, { x: 59.3, y: 46.8, r: 4.2 }], mouth: { x: 50, y: 60.5, w: 12.4 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 19 },
  { name: 'Stellie', src: 'export/creatures/06-stellie.png', ink: '#3d1656', mouthInk: '#92295f', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.4,
    patch: { cx: 50, cy: 57.8, rx: 16.4, ry: 14.4, top: '#fe91c9', bot: '#ff6fb5' },
    eyes: [{ x: 42.5, y: 51.9, r: 5 }, { x: 57.4, y: 51.9, r: 5 }], mouth: { x: 50, y: 64.4, w: 12.4 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 30 },
  { name: 'Puffington', src: 'export/creatures/07-puffington.png', ink: '#141a33', mouthInk: '#8e275d', cheek: null,
    patch: { cx: 50, cy: 46.8, rx: 14.4, ry: 7.8, top: '#9ae0ff', bot: '#6cd3ff' },
    eyes: [{ x: 42.5, y: 42.4, r: 4.4 }, { x: 57.4, y: 42.4, r: 4.4 }], mouth: { x: 50, y: 50, w: 10.0 },
    cheeks: [], head: 22 },
  { name: 'Noodle', src: 'export/creatures/08-noodle.png', ink: '#3d1656', mouthInk: '#8f275d', cheek: null, sclera: true, iris: '#4a1a6b', irisK: 0.42,
    patch: { cx: 50, cy: 46.4, rx: 11.7, ry: 15.2, top: '#ae8aff', bot: '#9459ff' },
    eyes: [{ x: 50, y: 42.3, r: 8.7 }], mouth: { x: 50, y: 55.1, w: 10.1 },
    cheeks: [], head: 19 },
  { name: 'Glimmer', src: 'export/creatures/09-glimmer.png', ink: '#3d1656', mouthInk: '#8f275d', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.4,
    patch: { cx: 50, cy: 56.4, rx: 16.4, ry: 14.7, top: '#92e8f5', bot: '#71ddee' },
    eyes: [{ x: 42.5, y: 50.3, r: 5 }, { x: 57.5, y: 50.3, r: 5 }], mouth: { x: 50, y: 63.2, w: 12.4 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 22 },
  { name: 'Ember', src: 'export/creatures/10-ember.png', ink: '#3d1656', mouthInk: '#8f275d', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.45,
    patch: { cx: 50, cy: 53.5, rx: 17.7, ry: 14.5, top: '#fc7272', bot: '#f34747' },
    eyes: [{ x: 40.6, y: 46.8, r: 4.2 }, { x: 59.3, y: 46.8, r: 4.2 }], mouth: { x: 50, y: 60.5, w: 12.5 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 19 },
  { name: 'Mochi', src: 'export/creatures/11-mochi.png', ink: '#2b2b42', mouthInk: '#932a5f', cheek: '#ff86c0',
    patch: { cx: 50, cy: 53.3, rx: 19.6, ry: 8.5, top: '#ffc7e6', bot: '#ffbce1' },
    eyes: [{ x: 39.7, y: 47.5, r: 4.4 }, { x: 60.2, y: 47.5, r: 4.4 }], mouth: { x: 50, y: 55.6, w: 10.4 },
    cheeks: [{ x: 31, y: 53 }, { x: 69, y: 53 }], head: 20.5 },
  { name: 'Zappy', src: 'export/creatures/12-zappy.png', ink: '#3d1656', mouthInk: '#141a33', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.43,
    patch: { cx: 50, cy: 53, rx: 19.6, ry: 15.5, top: '#ffef90', bot: '#ffd72b' },
    eyes: [{ x: 39.9, y: 46.1, r: 4.9 }, { x: 60.1, y: 46.1, r: 4.9 }], mouth: { x: 50, y: 59.5, w: 14.0 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 19 },
  { name: 'Bubbles', src: 'export/creatures/13-bubbles.png', ink: '#3d1656', mouthInk: '#141a33', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.41,
    patch: { cx: 50, cy: 57.2, rx: 17.5, ry: 14.7, top: '#b5f5fe', bot: '#51e2f6' },
    eyes: [{ x: 41, y: 50.5, r: 4.4 }, { x: 58.9, y: 50.5, r: 4.4 }], mouth: { x: 50, y: 62.7, w: 10.0 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 18 },
  { name: 'Grumps', src: 'export/creatures/14-grumps.png', ink: '#3d1656', mouthInk: '#0f182d', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.4,
    patch: { cx: 49.9, cy: 50.8, rx: 22.7, ry: 19.2, top: '#6a6fea', bot: '#4a48c6' },
    eyes: [{ x: 40.6, y: 49.3, r: 4.2 }, { x: 59.3, y: 49.3, r: 4.2 }], mouth: { x: 50, y: 62.6, w: 14.0 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 19 },
  { name: 'Sprout', src: 'export/creatures/15-sprout.png', ink: '#3d1656', mouthInk: '#912c5d', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.39,
    patch: { cx: 50, cy: 54.8, rx: 17.7, ry: 13.3, top: '#a8d958', bot: '#84bf2b' },
    eyes: [{ x: 41, y: 49.3, r: 4.6 }, { x: 58.9, y: 49.3, r: 4.6 }], mouth: { x: 50, y: 61, w: 11.2 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 21 },
  { name: 'Cinder', src: 'export/creatures/16-cinder.png', ink: '#3d1656', mouthInk: '#8e275c', cheek: null, sclera: true, iris: '#4a1a6b', irisK: 0.42, scleraColor: '#ffad55',
    patch: { cx: 49.9, cy: 52.8, rx: 18, ry: 14.2, top: '#394454', bot: '#2b3646' },
    eyes: [{ x: 40.5, y: 46.5, r: 4.4 }, { x: 59.3, y: 46.5, r: 4.4 }], mouth: { x: 50, y: 60.2, w: 12.4 },
    cheeks: [], head: 19 },
  { name: 'Pearla', src: 'export/creatures/17-pearla.png', ink: '#3d1656', mouthInk: '#372fb0', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.42,
    patch: { cx: 50, cy: 54.7, rx: 17, ry: 13, top: '#f6edff', bot: '#e1d0ff' },
    eyes: [{ x: 41.6, y: 49.4, r: 4.5 }, { x: 58.5, y: 49.4, r: 4.5 }], mouth: { x: 50, y: 60.8, w: 10.0 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 17.5 },
  { name: 'Tako', src: 'export/creatures/18-tako.png', ink: '#3d1656', mouthInk: '#12182d', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.38,
    patch: { cx: 49.9, cy: 46.2, rx: 18.5, ry: 13.3, top: '#fd879e', bot: '#f8486d' },
    eyes: [{ x: 40.8, y: 40.4, r: 5 }, { x: 59.1, y: 40.4, r: 5 }], mouth: { x: 50, y: 52, w: 10.0 },
    cheeks: [{ x: 32.5, y: 57.5 }, { x: 68.8, y: 57.5 }], head: 17.5 },
  { name: 'Fuzzball', src: 'export/creatures/19-fuzzball.png', ink: '#3d1656', mouthInk: '#8f275d', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.4,
    patch: { cx: 50, cy: 53.6, rx: 18.2, ry: 15.1, top: '#eea7fb', bot: '#d643e9' },
    eyes: [{ x: 40.7, y: 46.9, r: 4.7 }, { x: 59.2, y: 46.9, r: 4.7 }], mouth: { x: 50, y: 60.7, w: 11.0 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 22 },
  { name: 'Cosmo', src: 'export/creatures/20-cosmo.png', ink: '#3d1656', mouthInk: '#91295f', cheek: '#ff86c0', sclera: true, iris: '#4a1a6b', irisK: 0.36,
    patch: { cx: 50, cy: 63.4, rx: 15.5, ry: 12.1, top: '#5e1ec6', bot: '#42158f' },
    eyes: [{ x: 42.4, y: 58.6, r: 4.2 }, { x: 57.5, y: 58.6, r: 4.2 }], mouth: { x: 50, y: 69.3, w: 10.0 },
    cheeks: [{ x: 30.5, y: 57.5 }, { x: 69.3, y: 57.5 }], head: 30 },
];
const FACES = {
  happy: { e: 'happy', m: 'smile', label: 'Happy', desc: '∩ ∩ eyes, open smile' },
  sad: { e: 'sad', m: 'wobble', label: 'Sad', desc: 'glossy eyes, soft brows, tear glint' },
  angry: { e: 'angry', m: 'pout', label: 'Grumpy', desc: 'inward brows, pout' },
  hungry: { e: 'look', m: 'o', label: 'Hungry', desc: 'puppy eyes, little “o”' },
  smelly: { e: 'meh', m: 'wavy', label: 'Smelly', desc: 'half lids, wavy mouth' },
  eating: { e: 'happy', m: 'chomp', label: 'Eating', desc: '∩ ∩ eyes, chomp mouth' },
  content: { e: 'closed', m: 'small', label: 'Content', desc: '‿ ‿ eyes, small smile' },
  sleep: { e: 'closed', m: 'tinyo', label: 'Sleep', desc: '‿ ‿ eyes, tiny breath' },
  squish: { e: 'squish', m: 'wavy', label: 'Squish', desc: '> < eyes, wavy' },
  star: { e: 'star', m: 'grin', label: 'Star', desc: 'star eyes, big grin' },
  party: { e: 'happy', m: 'grin', label: 'Party', desc: '∩ ∩ eyes, big grin' },
};
const FACE_KEYS = Object.keys(FACES);

const EASE = { bouncy: [0.34, 1.56, 0.64, 1], soft: [0.45, 0, 0.55, 1], snappy: [0.2, 0, 0, 1] };
function bez(x1, y1, x2, y2) {
  return t => {
    if (t <= 0) return 0; if (t >= 1) return 1;
    let u = t;
    for (let i = 0; i < 8; i++) {
      const x = 3 * (1 - u) * (1 - u) * u * x1 + 3 * (1 - u) * u * u * x2 + u * u * u - t;
      const dx = 3 * (1 - u) * (1 - u) * x1 + 6 * (1 - u) * u * (x2 - x1) + 3 * u * u * (1 - x2);
      if (Math.abs(dx) < 1e-6) break;
      u = Math.min(1, Math.max(0, u - x / dx));
    }
    return 3 * (1 - u) * (1 - u) * u * y1 + 3 * (1 - u) * u * u * y2 + u * u * u;
  };
}
const EF = { bouncy: bez(...EASE.bouncy), soft: bez(...EASE.soft), snappy: bez(...EASE.snappy) };
const sm = x => x * x * (3 - 2 * x);

// channel: [base, amp, periodMs, phase, shape, extra]
const STATES = [
  { key: 'idle', label: 'Idle', short: 'Calm breathing. The default rest pose.', intent: 'Slow breath with a tiny float and sway. Uses the original artwork untouched, so every creature reads exactly as drawn.', loop: 3000,
    ch: { sy: [1, 0.025, 3000, 0, 'sin'], sx: [1, -0.015, 3000, 0, 'sin'], ty: [-3, -3, 3000, 0, 'sin'], rot: [0, 1, 3000, 0.25, 'sin'] },
    face: 'orig', tint: '#ffffff', ta: 0, br: 1, sat: 1, inMs: 600, inEase: 'soft', outMs: 300, kick: 0, particles: [], fx: 'None', needs: [70, 75, 70, 70] },
  { key: 'happy', label: 'Happy', short: 'Little hops and floating hearts.', intent: 'Two hops per loop with squash on landing and stretch at the apex. Hearts drift up from the head.', loop: 2000,
    ch: { ty: [0, -16, 1000, 0, 'hop'], sy: [1, -0.06, 1000, 0, 'cos'], sx: [1, 0.04, 1000, 0, 'cos'], rot: [0, 3, 2000, 0, 'sin'] },
    face: 'happy', tint: '#ffb3c7', ta: 0.1, br: 1.05, sat: 1.05, inMs: 300, inEase: 'bouncy', outMs: 300, kick: -5, particles: [{ type: 'heart', rate: 1.6 }], fx: 'Hearts 1.6/s from head line', needs: [80, 85, 95, 80] },
  { key: 'sad', label: 'Sad', short: '“I missed you.” Looking up, hoping you stay.', intent: 'Soft droop and slow lean, eyes big and glossy and pointed up at the player. No falling tears, no dark colors. A single tap resolves it into Happy.', loop: 4000,
    ch: { sy: [0.95, 0.012, 4000, 0, 'sin'], sx: [1.035, -0.008, 4000, 0, 'sin'], rot: [-5, 1.5, 4000, 0.25, 'sin'], ty: [6, -2, 4000, 0, 'sin'] },
    face: 'sad', tint: '#8fa8ff', ta: 0.16, br: 0.96, sat: 0.82, inMs: 600, inEase: 'soft', outMs: 300, kick: 0, particles: [], fx: 'None. Tear glint sits in the eye and never falls.', needs: [55, 60, 18, 50], tapTo: 'happy' },
  { key: 'angry', label: 'Grumpy', short: 'Puffed-up pout with little steam puffs.', intent: 'Angry reads as a pout, not a threat: body puffs wider, short shake bursts, then rests. Steam puffs are white and round.', loop: 2000,
    ch: { sx: [1.05, 0.015, 2000, 0, 'sin'], sy: [0.95, -0.015, 2000, 0, 'sin'], tx: [0, 2.5, 2000, 0, 'shake', { sub: 110, win: 0.3 }], rot: [0, 1.5, 2000, 0, 'shake', { sub: 160, win: 0.3 }], ty: [2, 0, 2000, 0, 'sin'] },
    face: 'angry', tint: '#ff7a8a', ta: 0.14, br: 1, sat: 1.08, inMs: 150, inEase: 'snappy', outMs: 300, kick: 4, particles: [{ type: 'steam', rate: 1.6 }], fx: 'Steam puffs 1.6/s, alternating sides', needs: [60, 65, 28, 60] },
  { key: 'hungry', label: 'Hungry', short: 'Tummy rumbles and a cookie daydream.', intent: 'Leans forward with puppy eyes. Every 2s a quick skew wobble reads as a tummy rumble. A thought bubble shows what it wants.', loop: 2000,
    ch: { rot: [3, 1, 2000, 0, 'sin'], skx: [0, 2.5, 2000, 0, 'shake', { sub: 90, win: 0.25 }], sy: [1, 0.02, 2000, 0.25, 'sin'], sx: [1, -0.012, 2000, 0.25, 'sin'], ty: [0, -2, 2000, 0.25, 'sin'] },
    face: 'hungry', tint: '#ffc56b', ta: 0.06, br: 1, sat: 0.96, inMs: 300, inEase: 'soft', outMs: 300, kick: 0, particles: [], fx: 'Thought bubble (cookie), bob ±3dp / 2000ms', needs: [12, 70, 50, 60] },
  { key: 'smelly', label: 'Smelly', short: 'Needs a bath. Cute buzzing friends.', intent: 'Slightly deflated, mild lime tint. Three smiling flies orbit in a figure-eight and soft mint haze rises. Nothing brown, no stink lines.', loop: 3000,
    ch: { sy: [0.97, 0.01, 3000, 0, 'sin'], sx: [1.02, -0.008, 3000, 0, 'sin'], rot: [0, 2, 3000, 0.25, 'sin'], ty: [3, 0, 3000, 0, 'sin'] },
    face: 'smelly', tint: '#a8d672', ta: 0.16, br: 0.98, sat: 0.9, inMs: 600, inEase: 'soft', outMs: 300, kick: 0, particles: [{ type: 'haze', rate: 1.2 }], flies: true, fx: '3 flies (persistent) + mint haze 1.2/s', needs: [70, 14, 45, 60] },
  { key: 'eating', label: 'Eating', short: 'Chomp, chomp. Crumbs on every bite.', intent: 'Chomp beat 500ms: body stretches as the mouth opens and squashes as it closes. The cookie shrinks one step per bite and a new one pops in every 4 bites.', loop: 2000,
    ch: { sy: [1, 0.045, 500, 0, 'cos'], sx: [1, -0.03, 500, 0, 'cos'], rot: [0, 2, 1000, 0, 'sin'] },
    face: 'eating', tint: '#ffd48a', ta: 0.06, br: 1.03, sat: 1.02, inMs: 300, inEase: 'bouncy', outMs: 300, kick: -3, particles: [{ type: 'crumb', burst: 3, every: 500, offset: 250 }], cookie: true, fx: 'Crumbs ×3 on each bite (t = 250 + 500n); cookie overlay', needs: [95, 70, 75, 70], needDur: [2000, 600, 600, 600] },
  { key: 'bathing', label: 'Bathing', short: 'Scrub-a-dub wiggle in a foam hat.', intent: 'Side-to-side scrub wiggle at 1000ms with a fast 500ms squeeze. Brighter and cooler. Foam cap rides on the head and squashes with the body.', loop: 2000,
    ch: { rot: [0, 5, 1000, 0, 'sin'], sx: [1, 0.025, 500, 0, 'sin'], sy: [1, -0.02, 500, 0, 'sin'], ty: [0, -2, 1000, 0.25, 'sin'] },
    face: 'content', tint: '#bff3ff', ta: 0.14, br: 1.08, sat: 1, inMs: 300, inEase: 'soft', outMs: 300, kick: -3, particles: [{ type: 'bubble', rate: 3 }], foam: true, fx: 'Soap bubbles 3/s + foam cap', needs: [70, 98, 80, 70], needDur: [600, 2000, 600, 600] },
  { key: 'sleeping', label: 'Sleeping', short: 'Slow deep breaths. Zzz.', intent: 'Settles lower and leans, breathing on a 4s loop. Scene dims to night. Energy refills over 4s.', loop: 4000,
    ch: { sy: [0.97, 0.025, 4000, 0, 'sin'], sx: [1.02, -0.015, 4000, 0, 'sin'], rot: [-4, 0, 4000, 0, 'sin'], ty: [5, -1.5, 4000, 0, 'sin'] },
    face: 'sleep', tint: '#5b4bb8', ta: 0.16, br: 0.86, sat: 0.9, inMs: 600, inEase: 'soft', outMs: 600, kick: 0, particles: [{ type: 'zzz', rate: 0.6 }], night: true, fx: 'Zzz 0.6/s; scene night overlay α 0→1', needs: [65, 70, 70, 100], needDur: [600, 600, 600, 4000] },
  { key: 'squished', label: 'Squished', short: 'Press and hold. Jelly rebound.', intent: 'Driven by touch, not by a loop. A spring value q follows the finger: 1 while pressed, 0 on release. The underdamped spring overshoots, so release gives a stretch and two or three jiggles. In the preview it auto-presses on a 1400ms cycle.', loop: 1400,
    ch: {}, chText: ['scaleY = base · (1 − 0.28·q)', 'scaleX = base · (1 + 0.22·q)', 'q → spring(dampingRatio 0.32, stiffness 500)', 'target 1 on press, 0 on release', 'demo cycle: press 450ms, release 950ms'],
    face: 'squish', tint: '#ffffff', ta: 0, br: 1.04, sat: 1, inMs: 150, inEase: 'snappy', outMs: 300, kick: 0, particles: [], fx: 'On release: 6 sparkles + 1 heart burst', needs: [70, 75, 90, 70], squish: true },
  { key: 'levelup', label: 'Max Care!', short: 'Level 10 unlocked. Big hops, confetti.', intent: 'Celebration: higher, faster hops with star eyes. Confetti bursts on entry then rains gently. Golden rays turn behind the creature, the care bar fills to 10 and the MAX badge pops.', loop: 3200,
    ch: { ty: [0, -26, 800, 0, 'hop'], sy: [1, -0.08, 800, 0, 'cos'], sx: [1, 0.05, 800, 0, 'cos'], rot: [0, 6, 1600, 0, 'sin'] },
    face: 'star', tint: '#ffe45c', ta: 0.14, br: 1.1, sat: 1.1, inMs: 300, inEase: 'bouncy', outMs: 600, kick: -7, particles: [{ type: 'confetti', rate: 6, mode: 'rain' }, { type: 'sparkle', rate: 5 }], burst: [{ type: 'confetti', n: 50, mode: 'burst' }], rays: true, fx: 'Confetti burst ×50 on entry, rain 6/s, sparkles 5/s, rays 360°/12s, MAX badge', needs: [100, 100, 100, 100], care: 10 },
];
STATES.push(
  { key: 'dance1', label: 'Groove', short: 'Dance 1 · side-step groove on the beat.', intent: 'Steps side to side on a 1000ms bar with a little bob on every beat (500ms). Leans into each step. Music notes pop out on the off-beats.', loop: 2000,
    ch: { tx: [0, 12, 1000, 0, 'sin'], rot: [0, 9, 1000, 0, 'sin'], ty: [0, -6, 500, 0, 'hop'], sy: [1, -0.05, 500, 0, 'cos'], sx: [1, 0.035, 500, 0, 'cos'] },
    face: 'happy', tint: '#ffb3e6', ta: 0.08, br: 1.05, sat: 1.06, inMs: 300, inEase: 'bouncy', outMs: 300, kick: -4, particles: [{ type: 'note', burst: 1, every: 500, offset: 250 }], fx: 'Music note on every off-beat (t = 250 + 500n)', needs: [72, 78, 92, 70] },
  { key: 'dance2', label: 'Pop Hop', short: 'Dance 2 · big bouncy jumps with a twist.', intent: 'High hops on a 750ms beat with strong squash on landing and stretch in the air. The body twists left and right (skew) across every two hops. Sparkles and notes burst at each landing.', loop: 1500,
    ch: { ty: [0, -22, 750, 0, 'hop'], sy: [1, -0.09, 750, 0, 'cos'], sx: [1, 0.06, 750, 0, 'cos'], skx: [0, 6, 1500, 0, 'sin'], rot: [0, 4, 1500, 0.25, 'sin'] },
    face: 'party', tint: '#ffe45c', ta: 0.08, br: 1.06, sat: 1.08, inMs: 300, inEase: 'bouncy', outMs: 300, kick: -6, particles: [{ type: 'sparkle', burst: 3, every: 750, offset: 0 }, { type: 'note', burst: 1, every: 750, offset: 0 }], fx: 'Landing burst: 3 sparkles + 1 note every 750ms', needs: [70, 76, 96, 66] },
  { key: 'dance3', label: 'Spin', short: 'Dance 3 · hop and twirl a full 360° like a ballerina.', intent: 'A 1600ms move: crouch (0–20%), hop and twirl a full turn around the vertical axis (20–70%), like a figure on a music box, land with a squish (70–90%), settle. Halfway through the turn the creature shows its mirrored side; with flat art that reads as its back. Note on takeoff, sparkles on landing.', loop: 1600,
    ch: { spin: [0, 360, 1600, 0, 'spin', { start: 0.2, end: 0.7 }], ty: [0, -26, 1600, 0, 'pulse', { start: 0.2, end: 0.7 }], sy: [1, 0.1, 1600, 0, 'spinsq'], sx: [1, -0.07, 1600, 0, 'spinsq'] },
    face: 'party', tint: '#c9b8ff', ta: 0.08, br: 1.05, sat: 1.05, inMs: 300, inEase: 'bouncy', outMs: 300, kick: 0, particles: [{ type: 'note', burst: 1, every: 1600, offset: 320 }, { type: 'sparkle', burst: 5, every: 1600, offset: 1120 }], fx: 'Note on takeoff (t = 320 + 1600n), 5 sparkles on landing (t = 1120 + 1600n)', needs: [70, 80, 94, 68] },
);
const SM = {}; STATES.forEach(s => SM[s.key] = s);
const NEEDS = [
  { key: 'hunger', label: 'Hunger', color: '#ffad4d' }, { key: 'clean', label: 'Clean', color: '#52d3ff' },
  { key: 'happy', label: 'Happy', color: '#ff6fae' }, { key: 'energy', label: 'Energy', color: '#ffc83d' },
];

function wave(c, t) {
  const [b, a, P, ph = 0, sh = 'sin', ex] = c; const u = t / P + ph;
  if (sh === 'sin') return b + a * Math.sin(TAU * u);
  if (sh === 'cos') return b + a * Math.cos(TAU * u);
  if (sh === 'hop') return b + a * Math.abs(Math.sin(Math.PI * u));
  if (sh === 'spin' || sh === 'pulse') { const x = (t % P) / P; if (x < ex.start || x > ex.end) return b; const v = (x - ex.start) / (ex.end - ex.start); return sh === 'spin' ? b + a * EF.soft(v) : b + a * Math.sin(Math.PI * v); }
  if (sh === 'spinsq') { const x = (t % P) / P; let f = 0; if (x < 0.2) f = -Math.sin(Math.PI * x / 0.2); else if (x < 0.7) f = 0.7 * Math.sin(Math.PI * (x - 0.2) / 0.5); else if (x < 0.9) f = -1.2 * Math.sin(Math.PI * (x - 0.7) / 0.2); return b + a * f; }
  if (sh === 'shake') { const x = (t % P) / P; return x >= ex.win ? b : b + a * Math.sin(TAU * t / ex.sub) * Math.sin(Math.PI * x / ex.win); }
  return b;
}
const hex = h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
function evalS(S, t) {
  const v = { sx: 1, sy: 1, rot: 0, skx: 0, tx: 0, ty: 0, spin: 0 };
  for (const k in S.ch) v[k] = wave(S.ch[k], t);
  const c = hex(S.tint); v.tr = c[0]; v.tg = c[1]; v.tb = c[2]; v.ta = S.ta; v.br = S.br; v.sat = S.sat;
  return v;
}
function lerpV(a, b, w) { const o = {}; for (const k in b) o[k] = a[k] + (b[k] - a[k]) * w; return o; }

const CHN = { spin: 'rotationY (turntable spin)', sx: 'scaleX', sy: 'scaleY', rot: 'rotationZ', skx: 'skewX', tx: 'translationX', ty: 'translationY' };
function fmtCh(k, c) {
  const [b, a, P, ph = 0, sh, ex] = c; const u = (k === 'rot' || k === 'skx' || k === 'spin') ? '°' : (k === 'tx' || k === 'ty') ? 'dp' : '';
  const f = v => u ? (+v.toFixed(1)) + u : v.toFixed(3); const s = a < 0 ? '−' : '+'; const A = f(Math.abs(a)); const N = CHN[k];
  if (a === 0) return `${N} = ${f(b)} (hold)`;
  const arg = `${P}${ph ? ` + ${ph}` : ''}`;
  if (sh === 'hop') return `${N} = ${f(b)} ${s} ${A}·|sin(π·t/${P})|`;
  if (sh === 'spin') return `${N} = ${A}·easeSoft(u), u = 0→1 over ${ex.start * 100}–${ex.end * 100}% of every ${P}ms, else 0`;
  if (sh === 'pulse') return `${N} = ${f(b)} ${s} ${A}·sin(π·u), u over ${ex.start * 100}–${ex.end * 100}% of ${P}ms`;
  if (sh === 'spinsq') return `${N} = ${f(b)} ${s} ${A}·f(t): crouch −1 (0–20%), air +0.7 (20–70%), land −1.2 (70–90%), sine-shaped`;
  if (sh === 'shake') return `${N} = ${f(b)} ± ${A}·sin(2π·t/${ex.sub}), first ${ex.win * 100}% of every ${P}ms, sine envelope`;
  return `${N} = ${f(b)} ${s} ${A}·${sh}(2π·(t/${P}${ph ? ` + ${ph}` : ''}))`;
}
function specRow(S) {
  const F = FACES[S.face];
  return {
    key: S.key, label: S.label, short: S.short, intent: S.intent,
    channels: S.chText || Object.keys(S.ch).map(k => fmtCh(k, S.ch[k])),
    kickText: S.kick ? `Entry pop: spring q velocity ${S.kick > 0 ? '+' : ''}${S.kick}/s (${S.kick < 0 ? 'stretch' : 'squash'} first)` : (S.tapTo ? 'Tap → Happy (reunion hop)' : ''),
    face: S.face === 'orig' ? 'Original art (no patch)' : `${F.label}: ${F.desc}`,
    tint: S.ta ? `${S.tint} @ ${S.ta.toFixed(2)} · brightness ${S.br} · saturation ${S.sat}` : `none · brightness ${S.br} · saturation ${S.sat}`,
    tintColor: S.ta ? S.tint : '#ffffff', particles: S.fx,
    loop: `Loop ${S.loop}ms`, inOut: `In ${S.inMs}ms ${S.inEase} · Out ${S.outMs}ms`,
  };
}

// ---------- face glyphs (viewBox 0 0 100 100) ----------
const n = v => +v.toFixed(2);
let CLIPN = 0;
function mixHex(a, b, t) { const A = hex(a), B = hex(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join(''); }
function eyeSvg(type, e, c, side) {
  const ink = c.ink, sc = !!c.sclera, { x, y } = e, R0 = e.r;
  const r = sc ? R0 * 0.72 : R0; const sw = n(Math.max(1.3, r * 0.3));
  const st = `fill="none" stroke="${ink}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round"`;
  const P = c.patch; const lid = mixHex(P.top, P.bot, Math.min(1, Math.max(0, (y - (P.cy - P.ry)) / (2 * P.ry))));
  const dark = (cy, rr) => `<circle cx="${n(x)}" cy="${n(cy)}" r="${n(rr)}" fill="${ink}"/><circle cx="${n(x - rr * 0.3)}" cy="${n(cy - rr * 0.38)}" r="${n(rr * 0.36)}" fill="#fff"/><circle cx="${n(x + rr * 0.36)}" cy="${n(cy + rr * 0.28)}" r="${n(rr * 0.16)}" fill="#fff"/>`;
  const white = (look) => { const ir = R0 * c.irisK, iy = y + look * R0 * 0.22;
    return `<circle cx="${n(x)}" cy="${n(y)}" r="${n(R0)}" fill="${c.scleraColor || '#fff'}"/><circle cx="${n(x)}" cy="${n(iy)}" r="${n(ir)}" fill="${c.iris}"/><circle cx="${n(x - ir * 0.32)}" cy="${n(iy - ir * 0.36)}" r="${n(ir * 0.36)}" fill="#fff"/><circle cx="${n(x + ir * 0.38)}" cy="${n(iy + ir * 0.34)}" r="${n(ir * 0.17)}" fill="#fff"/>`; };
  const ball = (cy, rr, look = 0) => sc ? white(look) : dark(cy, rr);
  const rb = sc ? R0 * 0.78 : r;
  const lidded = (pathD, edgeD) => { const id = 'eclip' + (CLIPN++); return `<clipPath id="${id}"><circle cx="${n(x)}" cy="${n(y)}" r="${n(R0 + 0.2)}"/></clipPath><g clip-path="url(#${id})"><path d="${pathD}" fill="${lid}"/></g><path d="${edgeD}" ${st}/>`; };
  switch (type) {
    case 'happy': return `<path d="M${n(x - r)} ${n(y + r * 0.35)} Q${n(x)} ${n(y - r * 1.15)} ${n(x + r)} ${n(y + r * 0.35)}" ${st}/>`;
    case 'closed': return `<path d="M${n(x - r)} ${n(y - r * 0.1)} Q${n(x)} ${n(y + r * 0.95)} ${n(x + r)} ${n(y - r * 0.1)}" ${st}/>`;
    case 'look': return ball(y - r * 0.05, r, -1);
    case 'sad': {
      const brow = side === 0
        ? `M${n(x - rb)} ${n(y - rb * 1.3)} Q${n(x)} ${n(y - rb * 1.85)} ${n(x + rb)} ${n(y - rb * 1.3)}`
        : side < 0 ? `M${n(x - rb * 0.9)} ${n(y - rb * 1.35)} Q${n(x)} ${n(y - rb * 1.55)} ${n(x + rb * 0.8)} ${n(y - rb * 1.95)}`
          : `M${n(x + rb * 0.9)} ${n(y - rb * 1.35)} Q${n(x)} ${n(y - rb * 1.55)} ${n(x - rb * 0.8)} ${n(y - rb * 1.95)}`;
      const gr = sc ? R0 : r; const gx = x + gr * 0.55 * (side === 0 ? 1 : -side);
      return ball(y, r * 1.02, -1) + `<path d="${brow}" fill="none" stroke="${ink}" stroke-width="${n(sw * 0.75)}" stroke-linecap="round"/><ellipse cx="${n(gx)}" cy="${n(y + gr * 0.92)}" rx="${n(gr * 0.2)}" ry="${n(gr * 0.26)}" fill="#cfeeff"/>`;
    }
    case 'angry': {
      if (sc) {
        const Q = R0 * 1.2;
        const lidD = side === 0 ? `M${n(x - Q)} ${n(y - Q)} L${n(x + Q)} ${n(y - Q)} L${n(x + Q)} ${n(y - R0 * 0.75)} L${n(x)} ${n(y - R0 * 0.1)} L${n(x - Q)} ${n(y - R0 * 0.75)}Z`
          : side < 0 ? `M${n(x - Q)} ${n(y - Q)} L${n(x + Q)} ${n(y - Q)} L${n(x + Q)} ${n(y - R0 * 0.1)} L${n(x - Q)} ${n(y - R0 * 0.8)}Z`
            : `M${n(x - Q)} ${n(y - Q)} L${n(x + Q)} ${n(y - Q)} L${n(x + Q)} ${n(y - R0 * 0.8)} L${n(x - Q)} ${n(y - R0 * 0.1)}Z`;
        const edge = side === 0 ? `M${n(x - R0 * 0.95)} ${n(y - R0 * 0.7)} L${n(x)} ${n(y - R0 * 0.1)} L${n(x + R0 * 0.95)} ${n(y - R0 * 0.7)}`
          : side < 0 ? `M${n(x - R0 * 0.95)} ${n(y - R0 * 0.78)} L${n(x + R0 * 0.95)} ${n(y - R0 * 0.12)}`
            : `M${n(x + R0 * 0.95)} ${n(y - R0 * 0.78)} L${n(x - R0 * 0.95)} ${n(y - R0 * 0.12)}`;
        return white(0.3) + lidded(lidD, edge);
      }
      const brow = side === 0
        ? `M${n(x - r)} ${n(y - r * 1.5)} L${n(x)} ${n(y - r * 1.0)} L${n(x + r)} ${n(y - r * 1.5)}`
        : side < 0 ? `M${n(x - r * 0.9)} ${n(y - r * 1.55)} L${n(x + r * 0.8)} ${n(y - r * 1.0)}`
          : `M${n(x + r * 0.9)} ${n(y - r * 1.55)} L${n(x - r * 0.8)} ${n(y - r * 1.0)}`;
      return dark(y + r * 0.1, r * 0.82) + `<path d="${brow}" ${st}/>`;
    }
    case 'meh':
      if (sc) { const Q = R0 * 1.2; return white(0.45) + lidded(`M${n(x - Q)} ${n(y - Q)} L${n(x + Q)} ${n(y - Q)} L${n(x + Q)} ${n(y - R0 * 0.05)} L${n(x - Q)} ${n(y - R0 * 0.05)}Z`, `M${n(x - R0 * 1.02)} ${n(y - R0 * 0.05)} L${n(x + R0 * 1.02)} ${n(y - R0 * 0.05)}`); }
      return `<path d="M${n(x - r * 0.9)} ${n(y)} A${n(r * 0.9)} ${n(r * 0.9)} 0 0 0 ${n(x + r * 0.9)} ${n(y)} Z" fill="${ink}"/><path d="M${n(x - r * 1.05)} ${n(y)} L${n(x + r * 1.05)} ${n(y)}" ${st}/><circle cx="${n(x - r * 0.3)}" cy="${n(y + r * 0.35)}" r="${n(r * 0.17)}" fill="#fff"/>`;
    case 'squish': {
      const chev = (cx, dir, rr) => `<path d="M${n(cx - dir * rr * 0.7)} ${n(y - rr * 0.75)} L${n(cx + dir * rr * 0.6)} ${n(y)} L${n(cx - dir * rr * 0.7)} ${n(y + rr * 0.75)}" ${st}/>`;
      if (side === 0) return chev(x - r * 0.55, 1, r * 0.6) + chev(x + r * 0.55, -1, r * 0.6);
      return chev(x, side < 0 ? 1 : -1, r);
    }
    case 'star': {
      const R = r * 1.25, ri = R * 0.42; let d = '';
      for (let i = 0; i < 8; i++) { const a = -Math.PI / 2 + i * Math.PI / 4; const rr = i % 2 ? ri : R; d += (i ? 'L' : 'M') + n(x + Math.cos(a) * rr) + ' ' + n(y + Math.sin(a) * rr); }
      return `<path d="${d}Z" fill="#ffd84a" stroke="${ink}" stroke-width="${n(sw * 0.45)}" stroke-linejoin="round"/><circle cx="${n(x - R * 0.18)}" cy="${n(y - R * 0.2)}" r="${n(R * 0.14)}" fill="#fff"/>`;
    }
  }
  return '';
}
function mouthSvg(type, m, ink, mi) {
  const { x, y, w } = m; const hw = w / 2; const sw = n(Math.max(1.3, w * 0.12));
  const st = `fill="none" stroke="${ink}" stroke-width="${sw}" stroke-linecap="round"`;
  switch (type) {
    case 'smile': return `<path d="M${n(x - hw)} ${n(y)} Q${n(x)} ${n(y + w * 0.85)} ${n(x + hw)} ${n(y)} Z" fill="${mi}"/><ellipse cx="${n(x)}" cy="${n(y + w * 0.29)}" rx="${n(w * 0.19)}" ry="${n(w * 0.1)}" fill="#ff8fb8"/>`;
    case 'grin': return `<path d="M${n(x - hw * 1.2)} ${n(y - w * 0.05)} Q${n(x)} ${n(y + w * 1.15)} ${n(x + hw * 1.2)} ${n(y - w * 0.05)} Z" fill="${mi}"/><ellipse cx="${n(x)}" cy="${n(y + w * 0.38)}" rx="${n(w * 0.24)}" ry="${n(w * 0.13)}" fill="#ff8fb8"/>`;
    case 'small': return `<path d="M${n(x - hw * 0.55)} ${n(y)} Q${n(x)} ${n(y + w * 0.38)} ${n(x + hw * 0.55)} ${n(y)}" ${st}/>`;
    case 'wobble': return `<path d="M${n(x - hw * 0.55)} ${n(y + w * 0.16)} C${n(x - hw * 0.25)} ${n(y - w * 0.1)} ${n(x + hw * 0.25)} ${n(y - w * 0.1)} ${n(x + hw * 0.55)} ${n(y + w * 0.16)}" ${st}/>`;
    case 'pout': return `<path d="M${n(x - hw * 0.35)} ${n(y + w * 0.1)} Q${n(x)} ${n(y - w * 0.16)} ${n(x + hw * 0.35)} ${n(y + w * 0.1)}" ${st}/>`;
    case 'o': return `<ellipse cx="${n(x)}" cy="${n(y + w * 0.1)}" rx="${n(w * 0.2)}" ry="${n(w * 0.25)}" fill="${mi}"/><ellipse cx="${n(x)}" cy="${n(y + w * 0.24)}" rx="${n(w * 0.12)}" ry="${n(w * 0.07)}" fill="#ff8fb8"/>`;
    case 'chomp': return `<g data-chomp="1" data-mx="${n(x)}" data-my="${n(y)}"><ellipse cx="${n(x)}" cy="${n(y)}" rx="${n(w * 0.3)}" ry="${n(w * 0.24)}" fill="${mi}"/><ellipse cx="${n(x)}" cy="${n(y + w * 0.12)}" rx="${n(w * 0.16)}" ry="${n(w * 0.08)}" fill="#ff8fb8"/></g>`;
    case 'wavy': return `<path d="M${n(x - hw * 0.6)} ${n(y)} Q${n(x - hw * 0.3)} ${n(y - w * 0.13)} ${n(x)} ${n(y)} Q${n(x + hw * 0.3)} ${n(y + w * 0.13)} ${n(x + hw * 0.6)} ${n(y)}" ${st}/>`;
    case 'tinyo': return `<ellipse data-breath="1" cx="${n(x)}" cy="${n(y)}" rx="${n(w * 0.1)}" ry="${n(w * 0.12)}" fill="${mi}"/>`;
  }
  return '';
}
function faceInner(c, key, ci) {
  const F = FACES[key]; const single = c.eyes.length === 1;
  let s = '';
  c.cheeks.forEach(k => { s += `<ellipse cx="${k.x}" cy="${k.y}" rx="6" ry="4" fill="url(#ck${ci})"/>`; });
  c.eyes.forEach(e => { s += eyeSvg(F.e, e, c, single ? 0 : (e.x < 50 ? -1 : 1)); });
  s += mouthSvg(F.m, c.mouth, c.ink, c.mouthInk);
  return s;
}
const defs = (c, ci) => c.cheek ? `<defs><radialGradient id="ck${ci}"><stop offset="0" stop-color="${c.cheek}" stop-opacity="0.8"/><stop offset="1" stop-color="${c.cheek}" stop-opacity="0"/></radialGradient></defs>` : '';
function patchHtml(c) {
  const p = c.patch; const mask = 'radial-gradient(closest-side, #000 80%, transparent 100%)';
  return `<div style="position:absolute;left:${p.cx - p.rx}%;top:${p.cy - p.ry}%;width:${p.rx * 2}%;height:${p.ry * 2}%;border-radius:50%;background:linear-gradient(180deg,${p.top},${p.bot});-webkit-mask-image:${mask};mask-image:${mask};"></div>`;
}
function rigSvg(c) {
  const p = c.patch; let s = `<ellipse cx="${p.cx}" cy="${p.cy}" rx="${p.rx}" ry="${p.ry}" fill="none" stroke="#fff" stroke-width="0.5" stroke-dasharray="1.5 1"/><line x1="0" y1="${c.head}" x2="100" y2="${c.head}" stroke="#ffe45c" stroke-width="0.4" stroke-dasharray="2 1"/><text x="2" y="${c.head - 1}" font-size="3" fill="#ffe45c" font-family="monospace">head</text><circle cx="50" cy="92" r="1.2" fill="#ff5cc6"/><text x="52" y="93" font-size="3" fill="#ff5cc6" font-family="monospace">pivot</text>`;
  c.eyes.forEach(e => { s += `<circle cx="${e.x}" cy="${e.y}" r="${e.r}" fill="none" stroke="#3fd7f6" stroke-width="0.5"/><circle cx="${e.x}" cy="${e.y}" r="0.7" fill="#3fd7f6"/>`; });
  const m = c.mouth; s += `<line x1="${m.x - m.w / 2}" y1="${m.y}" x2="${m.x + m.w / 2}" y2="${m.y}" stroke="#7be495" stroke-width="0.6"/>`;
  return s;
}

// ---------- particles ----------
const R = (a, b) => a + Math.random() * (b - a);
const CONF = ['#ff5cc6', '#ffcd3c', '#3fd7f6', '#7be495', '#b38cff', '#ffffff'];
const PT = {
  heart: { life: () => 1600, html: p => `<svg width="${p.s}" height="${p.s}" viewBox="0 0 24 24"><path d="M12 21s-8-5-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 6-8 11-8 11z" fill="#ff6fae" stroke="#fff" stroke-width="1.8"/><ellipse cx="8.5" cy="9" rx="1.8" ry="2.4" fill="#fff" opacity=".7"/></svg>`,
    init(p, F) { p.x = F.cx + R(-0.7, 0.7) * F.rx; p.y = F.head + 10 * F.k; p.vx = R(-10, 10) * F.k; p.vy = -55 * F.k; p.s = Math.round(R(18, 26) * F.k); },
    upd(p, a, dt) { p.x += p.vx * dt; p.y += p.vy * dt; p.ox = Math.sin(p.age * 0.005 + p.seed) * 6 * p.k; p.sc = a < 0.2 ? EF.bouncy(a / 0.2) : 1; p.op = a < 0.1 ? a / 0.1 : a > 0.65 ? (1 - a) / 0.35 : 1; p.r = Math.sin(p.age * 0.004 + p.seed) * 12; } },
  sparkle: { life: () => 800, html: p => `<svg width="${p.s}" height="${p.s}" viewBox="0 0 24 24" style="filter:drop-shadow(0 0 3px rgba(255,240,170,.9))"><path d="M12 1c1 6 5 10 11 11-6 1-10 5-11 11-1-6-5-10-11-11 6-1 10-5 11-11z" fill="#fff6b8"/><circle cx="12" cy="12" r="2.6" fill="#fff"/></svg>`,
    init(p, F, o) { const a = Math.random() * TAU; const d = R(0.65, 1.1); p.x = F.cx + Math.cos(a) * F.rx * d; p.y = F.cy + Math.sin(a) * F.ry * d; p.s = Math.round(R(12, 22) * F.k); },
    upd(p, a) { p.sc = Math.sin(Math.PI * a); p.r = a * 90; p.op = 1; } },
  zzz: { life: () => 2600, html: p => `<div style="font:700 ${p.s}px/1 Fredoka,sans-serif;color:#ece6ff;-webkit-text-stroke:1.5px #6b5bd6;width:${p.s}px;text-align:center">Z</div>`,
    init(p, F) { p.x = F.cx + F.rx * 0.35; p.y = F.head + F.ry * 0.25; p.vx = 16 * F.k; p.vy = -24 * F.k; p.s = Math.round(24 * F.k); },
    upd(p, a, dt) { p.x += p.vx * dt; p.y += p.vy * dt; p.ox = Math.sin(p.age * 0.003) * 6 * p.k; p.sc = 0.6 + 0.7 * a; p.op = a < 0.15 ? a / 0.15 : a > 0.6 ? (1 - a) / 0.4 : 1; p.r = -10 + 20 * a; } },
  steam: { life: () => 900, html: p => `<svg width="${p.s}" height="${p.s}" viewBox="0 0 30 26"><circle cx="9" cy="15" r="7" fill="#fff"/><circle cx="17" cy="10" r="8" fill="#fff"/><circle cx="23" cy="17" r="6" fill="#fff"/></svg>`,
    init(p, F) { p.side = Math.random() < 0.5 ? -1 : 1; p.x = F.cx + p.side * F.rx * 0.55; p.y = F.head + F.ry * 0.3; p.vx = p.side * 28 * F.k; p.vy = -38 * F.k; p.s = Math.round(26 * F.k); },
    upd(p, a, dt) { p.x += p.vx * dt; p.y += p.vy * dt; p.sc = 0.5 + 0.8 * EF.snappy(a); p.op = 0.95 * (1 - a); } },
  haze: { life: () => 2800, html: p => `<div style="width:${p.s}px;height:${p.s}px;border-radius:50%;background:radial-gradient(circle, rgba(184,236,128,.8), rgba(184,236,128,0) 70%)"></div>`,
    init(p, F) { p.x = F.cx + R(-0.7, 0.7) * F.rx; p.y = F.cy + R(0.1, 0.5) * F.ry; p.vy = -14 * F.k; p.s = Math.round(70 * F.k); },
    upd(p, a, dt) { p.y += p.vy * dt; p.ox = Math.sin(p.age * 0.002 + p.seed) * 8 * p.k; p.sc = 0.6 + 0.9 * a; p.op = 0.5 * Math.sin(Math.PI * a); } },
  crumb: { life: () => 900, html: p => `<div style="width:${p.s}px;height:${Math.round(p.s * 0.8)}px;border-radius:40% 55% 45% 50%;background:${p.col}"></div>`,
    init(p, F) { p.col = Math.random() < 0.5 ? '#e0a25a' : '#f4c98a'; p.x = F.mouth.x + R(-4, 4) * F.k + (F.ty || 0) * 0; p.y = F.mouth.y + (F.tyNow || 0); p.vx = R(-70, 70) * F.k; p.vy = R(-90, -30) * F.k; p.g = 420 * F.k; p.vr = R(-400, 400); p.s = Math.round(R(5, 9) * F.k + 1); },
    upd(p, a, dt) { p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.r += p.vr * dt; p.sc = 1; p.op = a > 0.7 ? (1 - a) / 0.3 : 1; } },
  bubble: { life: () => R(2000, 2600), html: p => `<svg width="${p.s}" height="${p.s}" viewBox="0 0 20 20"><circle cx="10" cy="10" r="9" fill="rgba(210,244,255,0.28)" stroke="#fff" stroke-width="1.2"/><path d="M5 8.5a5 5 0 0 1 4-4" stroke="#fff" stroke-width="1.6" fill="none" stroke-linecap="round"/><circle cx="14" cy="13.5" r="1.3" fill="#ffd1f0"/></svg>`,
    init(p, F) { p.x = F.cx + R(-0.9, 0.9) * F.rx; p.y = F.cy + R(-0.2, 0.6) * F.ry; p.vy = R(-45, -28) * F.k; p.s = Math.round(R(12, 28) * F.k); },
    upd(p, a, dt) { p.y += p.vy * dt; p.ox = Math.sin(p.age * 0.004 + p.seed) * 8 * p.k; if (a > 0.92) { const q = (a - 0.92) / 0.08; p.sc = 1 + q * 0.4; p.op = 1 - q; } else { p.sc = Math.min(1, EF.bouncy(Math.min(1, a / 0.08))); p.op = 1; } } },
  confetti: { life: () => R(1800, 2400), html: p => `<div style="width:${p.s}px;height:${Math.round(p.s * 1.6)}px;border-radius:2px;background:${p.col}"></div>`,
    init(p, F, o) {
      p.col = CONF[Math.floor(Math.random() * CONF.length)]; p.s = Math.round(R(5, 8) * F.k + 1); p.vr = R(-300, 300); p.r = R(0, 360);
      if (o.mode === 'burst') { const a = -Math.PI / 2 + R(-1.1, 1.1); const v = R(220, 380) * F.k; p.x = F.cx; p.y = F.cy - F.ry * 0.3; p.vx = Math.cos(a) * v; p.vy = Math.sin(a) * v; p.g = 380 * F.k; p.drag = 0.985; }
      else { p.x = R(-0.3, 1.3) * F.w; p.y = -F.rainTop; p.vx = R(-20, 20) * F.k; p.vy = R(40, 90) * F.k; p.g = 30 * F.k; p.drag = 1; }
    },
    upd(p, a, dt) { p.vy += p.g * dt; p.vx *= p.drag; p.x += p.vx * dt; p.y += p.vy * dt; p.r += p.vr * dt; p.sc = 1; p.sx = Math.cos(p.age * 0.012 + p.seed); p.op = a > 0.75 ? (1 - a) / 0.25 : 1; } },
  note: { life: () => 1800, html: p => `<svg width="${p.s}" height="${p.s}" viewBox="0 0 24 24" style="filter:drop-shadow(0 2px 0 rgba(60,10,100,.35))"><path d="M9 4.5 L19 2.5 V15.5" stroke="#fff" stroke-width="5" fill="none" stroke-linejoin="round"/><path d="M9 4.5 L19 2.5 V15.5 M9 4.5 V18" stroke="${p.col}" stroke-width="2.6" fill="none" stroke-linejoin="round" stroke-linecap="round"/><ellipse cx="6.5" cy="18.5" rx="3.6" ry="2.9" fill="${p.col}" stroke="#fff" stroke-width="1.4"/><ellipse cx="16.5" cy="16" rx="3.6" ry="2.9" fill="${p.col}" stroke="#fff" stroke-width="1.4"/></svg>`,
    init(p, F) { p.col = ['#ff5cc6', '#b38cff', '#3fd7f6', '#ffcd3c'][Math.floor(Math.random() * 4)]; const side = Math.random() < 0.5 ? -1 : 1; p.x = F.cx + side * F.rx * R(0.45, 0.85); p.y = F.head + F.ry * R(0.1, 0.5); p.vx = side * R(8, 22) * F.k; p.vy = R(-50, -35) * F.k; p.s = Math.round(R(18, 26) * F.k); },
    upd(p, a, dt) { p.x += p.vx * dt; p.y += p.vy * dt; p.ox = Math.sin(p.age * 0.006 + p.seed) * 6 * p.k; p.r = Math.sin(p.age * 0.008 + p.seed) * 15; p.sc = a < 0.15 ? EF.bouncy(a / 0.15) : 1; p.op = a > 0.6 ? (1 - a) / 0.4 : 1; } },
  fly: { life: () => Infinity, html: p => `<svg width="${p.s}" height="${p.s}" viewBox="0 0 18 16" style="overflow:visible"><g class="w" style="transform-origin:9px 7px"><ellipse cx="5.2" cy="4.5" rx="4" ry="3" fill="#fff" stroke="#c9d3ff" stroke-width=".8"/><ellipse cx="12.8" cy="4.5" rx="4" ry="3" fill="#fff" stroke="#c9d3ff" stroke-width=".8"/></g><circle cx="9" cy="10" r="5" fill="#6a5585"/><circle cx="7.2" cy="9.4" r="1.4" fill="#fff"/><circle cx="10.8" cy="9.4" r="1.4" fill="#fff"/><circle cx="7.4" cy="9.7" r=".65" fill="#2a1b3d"/><circle cx="11" cy="9.7" r=".65" fill="#2a1b3d"/><path d="M7.6 12.2q1.4 1 2.8 0" stroke="#fff" stroke-width=".7" fill="none" stroke-linecap="round"/></svg>`,
    init(p, F, o) { p.i = o.i || 0; p.s = Math.round(18 * F.k); },
    after(p) { p.wing = p.el.querySelector('.w'); },
    upd(p) { const F = p.F; const th = p.age * 0.0021 + p.i * 2.1; p.x = F.cx + F.rx * 0.95 * Math.sin(th); p.y = F.head + F.ry * 0.3 + F.ry * 0.35 * Math.sin(2 * th) + Math.sin(p.age * 0.05) * 1.5; const d = Math.cos(th); p.sc = 0.9 + 0.15 * d; p.op = 0.78 + 0.22 * d; p.r = Math.sin(p.age * 0.03) * 10; if (p.wing) p.wing.style.transform = `scaleY(${(0.45 + 0.55 * Math.abs(Math.sin(p.age * 0.06))).toFixed(2)})`; } },
};

window.SquishRig = { CREATURES, FACES, FACE_KEYS, EASE, EF, sm, STATES, SM, wave, evalS, lerpV, faceInner, defs, patchHtml, PT, R };
})();
