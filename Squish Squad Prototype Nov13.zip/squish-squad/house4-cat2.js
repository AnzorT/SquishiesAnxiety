// Squad House v4 extra catalog, part 1: helpers + rugs, sofas, TVs, speakers, lamps, plants, aquariums, arcade.
(function boot() {
  const X = window.House3D; if (!(X && X.ITEMS && X.ARCH)) { setTimeout(boot, 20); return; } if (X.A2) return;
  const K = X.K, { solid, box, cyl, ball, slab, slabX, arcW, disc, pillowY, pillowZ, mix, shade, prism, prismZ } = K;
  const NE = K.NEON, GOLD = '#e2b14a', CH = '#d5dde2', CR = '#fffaf1', WH = '#ffffff', DK = '#36373c', TIN = '#a9b0b4', OLD = '#9b7f62', OLD2 = '#a88660', INK = '#2b2f3a', LEAF = '#5fa556', LEAF2 = '#7cbd62';
  const RB6 = ['#e2554a', '#ffa940', '#ffd23f', '#7fc66a', '#5cc8f0', '#8f7bff'];
  const MT = { junk: TIN, cot: '#c9b48e', retro: CH, mod: DK, candy: '#fff1a0', royal: GOLD };
  const FR = (k, P) => k === 'junk' ? OLD : k === 'royal' ? '#f4f1ea' : k === 'candy' ? P.b : k === 'retro' ? CR : P.w;
  const polyY = (pts, y, h, col, o = {}) => solid(Object.assign({ ax: 'y', sh: 'poly', c: [0, 0], pts, rings: [[y, 0], [y + h, 0]], col, cv: 0 }, o));
  const starP = (n, R, r, rz = 1, a0 = -Math.PI / 2) => Array.from({ length: n * 2 }, (_, i) => { const a = a0 + i * Math.PI / n, q = i % 2 ? r : R; return [q * Math.cos(a), q * Math.sin(a) * rz]; });
  const rotS = (list, deg, dx = 0, dz = 0) => { const t = deg * Math.PI / 180, c = Math.cos(t), s = Math.sin(t), P = p => [p[0] * c + p[2] * s + dx, p[1], -p[0] * s + p[2] * c + dz], N = n => [n[0] * c + n[2] * s, n[1], -n[0] * s + n[2] * c];
    list.forEach(S => { S.pts = S.pts.map(P); S.faces.forEach(F => { F.q = F.q.map(P); F.n = N(F.n); }); }); return list; };
  const lg = (k, P, x, z, h, r = 3.5) => [[-x, -z], [x, -z], [-x, z], [x, z]].map(([a, b], i) => k === 'junk' ? box(a, 0, b, r * 2.2, h, r * 2.2, OLD, { r: 1 }) : k === 'retro' ? cyl(a, 0, b, r * 0.7, h, CH, { n: 8, rg: [[0, 0, 0.5], [h, 0, 1]] }) : k === 'mod' ? cyl(a, 0, b, r * 0.5, h, DK, { n: 6 })
    : k === 'candy' ? ball(a, 0, b, Math.max(4, r * 1.2), NE[(i + 1) % 6], { sy: Math.max(0.6, h / (2 * Math.max(4, r * 1.2))), k: 4, n: 10 }) : k === 'royal' ? cyl(a, 0, b, r * 0.8, h, GOLD, { n: 10, rg: [[0, 0, 0.7], [h, 0, 1.15]] }) : cyl(a, 0, b, r, h, P.wD, { n: 10 }));
  const jewel = (x, y, z, r = 4) => ball(x, y, z, r, GOLD);
  const spr = (x, y, z, w, d, n = 8) => Array.from({ length: n }, (_, i) => ball(x + (((i * 37) % 100) / 100 - 0.5) * w, y, z + (((i * 61) % 100) / 100 - 0.5) * d, 2, NE[i % 6], { k: 3, n: 8, sy: 0.6 }));
  const drips = (x, y, z, w, col, n = 5) => Array.from({ length: n }, (_, i) => ball(x - w / 2 + w * (i + 0.5) / n, y - 7 - (i % 2) * 4, z, 4, col, { sy: 1.5, k: 4, n: 10 }));
  // TV picture: off = dark glass, on = little cartoon (sun + hill + bouncing creature, the creature is a moving part)
  const scr = (x, y, z, w, h, on, c1) => {
    if (!on) return [box(x, y, z, w, h, 0.8, '#2b3140', { r: 3 }), box(x - w * 0.22, y + h * 0.64, z + 0.5, w * 0.3, h * 0.1, 0.3, '#46516a', { r: 2 })];
    const r = Math.min(w, h);
    return [box(x, y, z, w, h, 0.8, '#a8e2ff', { r: 3, emit: 1, scr: 1 }), box(x, y, z + 0.5, w, h * 0.34, 0.4, '#8fd17a', { r: 2, emit: 1 }), disc(x + w * 0.3, y + h * 0.72, z + 0.9, r * 0.13, 0.3, '#ffe066', { emit: 1 }),
      disc(x - w * 0.1, y + h * 0.3, z + 1.2, r * 0.2, 0.5, c1 || '#ffa940', { emit: 1, part: 1 }), disc(x - w * 0.1 - r * 0.07, y + h * 0.34, z + 1.9, r * 0.035, 0.3, INK, { part: 1 }), disc(x - w * 0.1 + r * 0.07, y + h * 0.34, z + 1.9, r * 0.035, 0.3, INK, { part: 1 })];
  };
  const pot = (k, P, r, h, y = 0) => { const o = [];
    if (k === 'junk') o.push(cyl(0, y, 0, r, h, TIN, { n: 12 }), cyl(0, y + h * 0.3, 0, r + 0.4, h * 0.35, '#c9a85a', { n: 12 }));
    else if (k === 'cot') o.push(cyl(0, y, 0, r * 0.8, h, '#c97a4a', { n: 12, rg: [[0, 0, 0.8], [h, 0, 1]] }), cyl(0, y + h - 4, 0, r + 1.5, 5, '#d68a58', { n: 12 }));
    else if (k === 'retro') o.push(cyl(0, y, 0, r, h, CR, { n: 12, rg: [[0, 0, 0.75], [h, 0, 1]] }), cyl(0, y + h * 0.55, 0, r * 0.95, 4, '#e2554a', { n: 12 }));
    else if (k === 'mod') o.push(cyl(0, y, 0, r, h, '#d8d4cc', { n: 14 }));
    else if (k === 'candy') { o.push(cyl(0, y, 0, r * 0.82, h, P.a, { n: 14, rg: [[0, 0, 0.82], [h, 0, 1]] })); for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; o.push(box(r * 0.95 * Math.cos(a), y + 2, r * 0.95 * Math.sin(a), 2, h - 4, 2, WH, { r: 1 })); } }
    else o.push(cyl(0, y, 0, r * 0.7, h * 0.3, '#f4f1ea', { n: 12 }), cyl(0, y + h * 0.3, 0, r, h * 0.7, '#f4f1ea', { n: 14, rg: [[0, 0, 0.7], [h * 0.7, 0, 1]] }), cyl(0, y + h - 3, 0, r + 1, 3, GOLD, { n: 14 }));
    return o; };
  const cone = (x, y, z, r, cc, ring, on) => [disc(x, y, z, r, 2, cc, { top: 3, part: 1 }), disc(x, y, z + 2.2, r * 0.36, 1.2, ring, { part: 1, emit: on ? 1 : 0 })];
  const fish = (x, y, z, s, col) => [ball(x, y, z, 5 * s, col, { sx: 1.6, sy: 0.9, sz: 0.7, k: 4, n: 10, part: 1 }), disc(x - 8 * s, y + 4.5 * s, z, 3.6 * s, 1, col, { part: 1 }), disc(x + 3.5 * s, y + 5.5 * s, z + 3.2 * s, 1.1 * s, 0.4, INK, { part: 1 })];

  // ---------- rugs ----------
  const RUGD = { runner: [250, 70], round: [180, 180], face: [170, 150], record: [170, 170], hex: [180, 160], star: [180, 170], flower: [180, 170], shag: [180, 130], oval: [200, 130], rainbow: [200, 120], spiral: [176, 176] };
  const rugB = (v, k, P, W, D) => { const a = P.a, b = P.b, c3 = k === 'royal' ? GOLD : k === 'candy' ? NE[2] : P.w, R = W / 2, Rz = D / 2, o = [];
    if (v === 'oval' || v === 'round') { o.push(cyl(0, 0, 0, R, 2, a, { rz: Rz, n: 24 })); [0.84, 0.66, 0.48, 0.28].forEach((f, i) => o.push(cyl(0, 2 + i * 0.6, 0, R * f, 0.6, [b, CR, c3, a][i], { rz: Rz * f, n: 22 })));
      if (v === 'round') for (let i = 0; i < 14; i++) { const t = i / 14 * Math.PI * 2; o.push(cyl(R * 0.92 * Math.cos(t), 2, Rz * 0.92 * Math.sin(t), 4, 0.6, c3, { n: 8 })); }
      if (k === 'royal') o.push(...[0, 1, 2, 3].map(i => jewel(R * 0.66 * Math.cos(i * 1.571 + 0.785), 2, Rz * 0.66 * Math.sin(i * 1.571 + 0.785), 3.5))); return o; }
    if (v === 'runner') { o.push(box(0, 0, 0, W, 2, D, a, { r: 4 }), box(0, 2, -D * 0.36, W - 12, 0.6, 6, b, { r: 1 }), box(0, 2, D * 0.36, W - 12, 0.6, 6, b, { r: 1 }));
      for (let i = -2; i <= 2; i++) o.push(polyY([[-16, 0], [0, -16], [16, 0], [0, 16]].map(([x, z]) => [x + i * 46, z]), 2, 0.6, i % 2 ? c3 : CR));
      for (let i = 0; i < 9; i++) [-1, 1].forEach(s => o.push(box(s * (W / 2 + 3), 0, -D / 2 + 5 + i * (D - 10) / 8, 6, 1.2, 2.4, CR, { r: 0.5 }))); return o; }
    if (v === 'check') { o.push(box(0, 0, 0, W, 2, D, a, { r: 4 })); for (let i = 0; i < 6; i++) for (let j = 0; j < 4; j++) if ((i + j) % 2) o.push(box(-W / 2 + W / 12 + i * W / 6, 2, -D / 2 + D / 8 + j * D / 4, W / 6 - 2, 0.6, D / 4 - 2, k === 'retro' ? INK : b, { r: 1 })); return o; }
    if (v === 'stripe') { o.push(box(0, 0, 0, W, 2, D, CR, { r: 4 })); for (let i = 0; i < 7; i++) o.push(box(-W / 2 + W / 14 + i * W / 7, 2, 0, W / 7 - 4, 0.6, D - 8, [a, b, c3][i % 3], { r: 1 })); return o; }
    if (v === 'shag') { o.push(cyl(0, 0, 0, R, 2, a, { rz: Rz, n: 22 })); for (let i = 0; i < 44; i++) { const t = i * 2.4, rr = Math.sqrt((i + 0.5) / 44) * 0.9; o.push(ball(rr * R * Math.cos(t), 1, rr * Rz * Math.sin(t), 6.5, k === 'candy' ? NE[i % 6] : i % 3 ? a : P.aL, { sy: 0.45, k: 3, n: 8 })); } return o; }
    if (v === 'rainbow') { o.push(box(0, 0, 0, W, 2, D, CR, { r: 12 })); for (let i = 0; i < 6; i++) { const rO = R - 10 - i * 12; o.push(arcW(0, 2, Rz - 10, rO, (D - 22) * rO / (R - 10), 11, 0.6, Math.PI, Math.PI * 2, RB6[i], { n: 16 })); }
      [-1, 1].forEach(s => o.push(ball(s * (R - 26), 2, Rz - 18, 12, WH, { sy: 0.3, k: 3 }), ball(s * (R - 40), 2, Rz - 12, 10, WH, { sy: 0.3, k: 3 }))); return o; }
    if (v === 'star') { o.push(cyl(0, 0, 0, R, 2, a, { rz: Rz, n: 24 }), polyY(starP(5, R * 0.8, R * 0.34, Rz / R), 2, 0.6, b), polyY(starP(5, R * 0.3, R * 0.13, Rz / R), 2.6, 0.6, c3)); for (let i = 0; i < 10; i++) { const t = i / 10 * Math.PI * 2 + 0.3; o.push(cyl(R * 0.9 * Math.cos(t), 2, Rz * 0.9 * Math.sin(t), 3, 0.6, CR, { n: 8 })); } return o; }
    if (v === 'face') { o.push(cyl(-R * 0.6, 0, -Rz * 0.72, R * 0.3, 2, a, { rz: Rz * 0.28, n: 14 }), cyl(R * 0.6, 0, -Rz * 0.72, R * 0.3, 2, a, { rz: Rz * 0.28, n: 14 }), cyl(-R * 0.6, 2, -Rz * 0.72, R * 0.16, 0.6, P.b, { rz: Rz * 0.15, n: 12 }), cyl(R * 0.6, 2, -Rz * 0.72, R * 0.16, 0.6, P.b, { rz: Rz * 0.15, n: 12 }), cyl(0, 0, 0, R, 2, a, { rz: Rz, n: 26 }));
      [-1, 1].forEach(s => o.push(cyl(s * R * 0.34, 2, -Rz * 0.08, R * 0.14, 0.6, INK, { rz: Rz * 0.18, n: 14 }), cyl(s * R * 0.34 - 3, 2.6, -Rz * 0.16, R * 0.05, 0.6, WH, { n: 8 }), cyl(s * R * 0.58, 2, Rz * 0.26, R * 0.12, 0.6, '#ffa36a', { rz: Rz * 0.08, n: 12 })));
      o.push(arcW(0, 2, Rz * 0.12, R * 0.2, Rz * 0.17, 4, 0.6, Math.PI * 0.12, Math.PI * 0.88, INK, { n: 10 })); return o; }
    if (v === 'map') { o.push(box(0, 0, 0, W, 2, D, '#f1e3c0', { r: 6 }), box(0, 2, -D / 2 + 4, W - 8, 0.6, 3, '#c9a86a'), box(0, 2, D / 2 - 4, W - 8, 0.6, 3, '#c9a86a'));
      [[-46, -12, 40, 28], [48, 20, 34, 24]].forEach(([x, z, r, rz]) => o.push(cyl(x, 2, z, r, 0.6, '#e8cf8a', { rz, n: 16 }), cyl(x, 2.6, z, r * 0.78, 0.6, '#9fc684', { rz: rz * 0.75, n: 16 }), ball(x - 6, 3.2, z - 4, 7, '#6f9e50', { sy: 0.6, k: 3 })));
      for (let i = 0; i < 6; i++) { const u = i / 5, x = -26 + u * 60, z = -2 + Math.sin(u * 3.1) * 14 + u * 12; o.push(box(x, 2, z, 7, 0.6, 2.6, '#b8714a', { r: 1, yaw: 0.5 })); }
      o.push(box(52, 3.2, 16, 18, 0.6, 3.4, '#e2554a', { r: 1, yaw: 0.785 }), box(52, 3.2, 16, 18, 0.6, 3.4, '#e2554a', { r: 1, yaw: -0.785 }), polyY(starP(4, 14, 4).map(([x, z]) => [x - 76, z + 34]), 2, 0.6, '#4a6fd6')); return o; }
    if (v === 'flower') { o.push(cyl(0, 0, 0, R, 2, CR, { rz: Rz, n: 24 })); for (let i = 0; i < 6; i++) { const t = i / 6 * Math.PI * 2; o.push(cyl(R * 0.5 * Math.cos(t), 2, Rz * 0.5 * Math.sin(t), R * 0.3, 0.6, i % 2 ? a : b, { rz: R * 0.17, n: 14, yaw: t })); } o.push(cyl(0, 2.6, 0, R * 0.22, 0.6, c3, { rz: Rz * 0.22, n: 16 })); return o; }
    if (v === 'record' || v === 'spiral') { const rec = v === 'record'; o.push(cyl(0, 0, 0, R, 2, rec ? INK : a, { rz: Rz, n: 26 }));
      for (let i = 0; i < 5; i++) { const f = 0.9 - i * 0.12; o.push(arcW(0, 2, 0, R * f, Rz * f, rec ? 1.4 : 9, 0.6, i * 0.8, i * 0.8 + (rec ? Math.PI * 2 : Math.PI * 1.5), rec ? '#4a4f58' : [b, c3, CR][i % 3], { n: 18 })); }
      o.push(cyl(0, 2.6, 0, R * 0.26, 0.6, rec ? '#e2554a' : b, { rz: Rz * 0.26, n: 16 }), cyl(0, 3.2, 0, 3, 0.4, CR, { n: 8 })); return o; }
    if (v === 'hex') { const hx = f => Array.from({ length: 6 }, (_, i) => [R * f * Math.cos(i * Math.PI / 3), Rz * f * Math.sin(i * Math.PI / 3)]); o.push(polyY(hx(1), 0, 2, a, { cv: 1 }), polyY(hx(0.72), 2, 0.6, b), polyY(hx(0.36), 2.6, 0.6, c3));
      for (let i = 0; i < 6; i++) { const t = i * Math.PI / 3 + Math.PI / 6; o.push(cyl(R * 0.62 * Math.cos(t), 2.6, Rz * 0.62 * Math.sin(t), 6, 0.6, CR, { n: 6 })); } return o; }
    if (v === 'zig') { o.push(box(0, 0, 0, W, 2, D, CR, { r: 4 })); for (let r = 0; r < 4; r++) { const z0 = -D / 2 + 16 + r * (D - 24) / 4, top = [], bot = []; for (let i = 0; i <= 8; i++) { const x = -W / 2 + 8 + i * (W - 16) / 8, zz = z0 + (i % 2 ? -7 : 7); top.push([x, zz]); bot.push([x, zz + 9]); } o.push(polyY(top.concat(bot.reverse()), 2, 0.6, [a, b, c3, a][r])); } return o; }
    return [box(0, 0, 0, W, 2, D, a, { r: 6 })];
  };

  // ---------- sofas ----------
  const SD = 86, sH = k => k === 'junk' ? 34 : 40, seatXs = (len, n, aL, aR) => { const x0 = -len / 2 + (aL ? 24 : 0), sw = len - (aL ? 24 : 0) - (aR ? 24 : 0); return Array.from({ length: n }, (_, i) => x0 + sw / n * (i + 0.5)); };
  const sty = k => ({ by: k === 'junk' ? 0 : 7, bh: k === 'mod' ? 44 : k === 'royal' ? 66 : 56, br: k === 'mod' ? 8 : k === 'candy' ? 26 : k === 'retro' ? 12 : 20 });
  const glue = o => (p, L, fn) => L.map(q => { q.par = p; if (fn) q.fn = fn; o.push(q); return q; });
  // straight sofa run: base + back between the arms, back behind the base, back cushions on the base in front of it, seat cushions in front of those; details glued
  const seg = (S, P, len, n, aL, aR) => { const k = S.k, { by, bh, br } = sty(k), o = [], on = glue(o), F = [0, 0, 1], bH = k === 'junk' ? 14 : 18, AI = k === 'candy' ? 26 : 24;
    if (k !== 'junk') o.push(...lg(k, P, len / 2 - 12, 32, 7));
    const xa = -len / 2 + (aL ? AI : 2), xb = len / 2 - (aR ? AI : 2), xm = (xa + xb) / 2, cw = (xb - xa) / n;
    const BS = box(xm, by, 7, xb - xa, bH, 70, P.aD, { r: k === 'mod' ? 5 : 10, bev: 4 }), BK = slab(xm, by, -35, xb - xa, bh + 7, 14, P.a, { r: br, soft: 1 }); o.push(BS, BK);
    if (k === 'royal') o.push(slab(0, by + 5, -43, len, bh + 6, 2, GOLD, { r: br + 3 }));
    if (k === 'retro') on(BK, [box(xm, by + 7 + bh, -35, xb - xa - 20, 1.4, 12, CH, { r: 1 })]);
    for (let i = 0; i < n; i++) { const x = xa + cw * (i + 0.5);
      o.push(pillowY(x, by + bH, 16, cw - 2, k === 'mod' ? 13 : 16, 52, k === 'junk' && i % 2 ? P.b : P.aL));
      const BC = k === 'mod' ? box(x, by + bH, -21, cw - 4, 38, 14, P.aL, { r: 6, bev: 3 }) : pillowZ(x, by + bH, -19, cw - 2, 44, 18, P.aL); o.push(BC);
      if (k === 'royal') on(BC, [-0.25, 0.25].map(f => ball(x + cw * f, by + 40, -9.6, 2.2, GOLD, { k: 3, n: 8, sz: 0.5 })), F); }
    [[aL, -1], [aR, 1]].forEach(([a, s]) => { if (!a) return; const x = s * (len / 2 - 12);
      o.push(k === 'candy' ? ball(x, by - 2, 2, 20, P.b, { sx: 0.7, sy: 1.05, sz: 2.1, k: 6, n: 16 }) : slab(x, by, 2, 24, k === 'mod' ? 32 : 42, 86, P.a, { r: k === 'mod' ? 4 : 12, soft: 1 })); });
    if (k === 'candy') on(BK, spr(xm, by + 5 + bh, -35, xb - xa - 30, 6, Math.max(4, Math.round(len / 34))));
    if (k === 'junk') on(BS, [box(-len * 0.2, by + 4, 42.6, 16, 8, 1, '#c9a85a', { r: 1 }), box(len * 0.26, by + 5, 42.6, 12, 7, 1, '#8fa8a0', { r: 1 })], F);
    return o; };
  const corner = (S, P) => { const k = S.k, { by, bh, br } = sty(k), o = [];
    if (k !== 'junk') o.push(...lg(k, P, 30, 30, 7));
    o.push(box(0, by, 0, SD, k === 'junk' ? 14 : 18, SD, P.aD, { r: 10, bev: 4 }), slab(-3, by + 7, -35, SD - 6, bh, 14, P.a, { r: br, soft: 1 }), slabX(35, by + 7, 4, 14, bh, SD - 8, P.a, { r: Math.min(br, 10) }),
      pillowY(-4, by + 16, 4, 62, k === 'mod' ? 13 : 16, 62, P.aL), pillowZ(-6, by + 26, -22, 56, 36, 16, P.aL), box(22, by + 26, 4, 14, 32, 54, P.aL, { r: 6, bev: 3 }));
    if (k === 'royal') o.push(jewel(36, by + bh + 6, -36, 5)); if (k === 'candy') o.push(...spr(0, by + bh + 4, -35, 60, 6, 4));
    return o; };
  const sit = (x, z, f, k) => ({ x, z, h: sH(k), f });
  // one-piece sectional (L / U): back strip along the back, side backs along the open sides, bases in front of them, back cushions on the bases, seat cushions in front, arms at the open ends.
  // No part is sunk into another (each touches its neighbours at most), so the depth sort has one answer at every angle; caps / studs / sprinkles / patches are glued (par) to their part.
  const sect = (S, W, D, nM, sides) => { const k = S.k, { by, bh } = sty(k), bH = k === 'junk' ? 14 : 18, aH = k === 'mod' ? 32 : 42, hasL = sides.includes(-1), wl = D - SD - 24, wz = -D / 2 + SD + wl / 2, T = 14, BCd = 18, AW = 24;
    const x0 = hasL ? -W / 2 + SD : -W / 2 + AW, x1 = W / 2 - SD, cw = (x1 - x0) / nM, mx = Array.from({ length: nM }, (_, i) => x0 + cw * (i + 0.5));
    const seats = mx.map(x => sit(x, -D / 2 + 53, 0, k)); sides.forEach(s => seats.push(sit(s * (W / 2 - 50), -D / 2 + 50, -45 * s, k), sit(s * (W / 2 - 53), wz, -90 * s, k)));
    const z0 = -D / 2, zB = z0 + T, zC = zB + BCd, z1 = z0 + SD, zA = D / 2 - AW;
    return { w: W, d: D, act: 'sit', seats, build: P => { const o = [], on = glue(o), F = [0, 0, 1], sm = k === 'mod' ? 13 : 16, yb = by + bH, BH = bh + 7;
      const span = (a, b) => [Math.min(a, b), Math.max(a, b)];
      const back = (xa, xb, za, zb) => { const B = box((xa + xb) / 2, by, (za + zb) / 2, xb - xa, BH, zb - za, P.a, { r: 2, soft: 1 }); o.push(B);
        if (k === 'royal') on(B, [box((xa + xb) / 2, by + BH, (za + zb) / 2, xb - xa, 3, zb - za, GOLD, { r: 1 })]);
        if (k === 'retro') on(B, [box((xa + xb) / 2, by + BH, (za + zb) / 2, Math.max(2, xb - xa - 6), 1.4, Math.max(2, zb - za - 6), CH, { r: 1 })]);
        if (k === 'candy') on(B, spr((xa + xb) / 2, by + BH - 2, (za + zb) / 2, Math.max(4, xb - xa - 8), Math.max(2, zb - za - 6), Math.max(2, Math.round(Math.max(xb - xa, zb - za) / 34))));
        return B; };
      const base = (xa, xb, za, zb) => { const B = box((xa + xb) / 2, by, (za + zb) / 2, xb - xa, bH, zb - za, P.aD, { r: 1 }); o.push(B); return B; };
      const seat = (xa, xb, za, zb, col) => o.push(pillowY((xa + xb) / 2, yb, (za + zb) / 2, xb - xa - 1, sm, zb - za - 1, col || P.aL));
      const bcush = (xa, xb) => { const x = (xa + xb) / 2, w = xb - xa, C = k === 'mod' ? box(x, yb, (zB + zC) / 2 - 2, w - 4, 38, BCd - 4, P.aL, { r: 6, bev: 3 }) : pillowZ(x, yb, (zB + zC) / 2, w - 1, 44, BCd, P.aL); o.push(C); return C; };
      const scush = (xc, za, zb) => o.push(k === 'mod' ? box(xc, yb, (za + zb) / 2, BCd - 4, 38, zb - za - 4, P.aL, { r: 6, bev: 3 }) : rotS([pillowZ(0, yb, 0, zb - za - 1, 44, BCd, P.aL)], -90, xc, (za + zb) / 2)[0]);
      const arm = (xa, xb, za, zb) => { const x = (xa + xb) / 2, z = (za + zb) / 2, w = xb - xa, d = zb - za, A = k === 'candy' ? ball(x, by - 2, z, 20, P.b, { sx: w / 40, sy: 1.05, sz: d / 40, k: 6, n: 16 }) : slab(x, by, z, w, aH, d, P.a, { r: k === 'mod' ? 4 : 12, soft: 1 }); o.push(A); return A; };
      // legs stand under one part each (never under the seam between two)
      if (k !== 'junk') { o.push(...rotS(lg(k, P, W / 2 - 20, SD / 2 - 10, 7), 0, 0, -D / 2 + SD / 2)); sides.forEach(s => o.push(...rotS(lg(k, P, (SD - T) / 2 - 8, wl / 2 + 2, 7), 0, s * (W / 2 - (SD + T) / 2), wz + 12))); }
      if (!hasL) arm(-W / 2, -W / 2 + AW, z0, z1);
      const MB = mx.map((x, i) => { const xa = x - cw / 2, xb = x + cw / 2; back(xa, xb, z0, zB); const B = base(xa, xb, zB, z1), C = bcush(xa, xb); seat(xa, xb, zC, z1, k === 'junk' && i % 2 ? P.b : P.aL);
        if (k === 'royal') on(C, [-0.25, 0.25].map(f => ball(x + cw * f, by + 40, zC + 0.4, 2.2, GOLD, { k: 3, n: 8, sz: 0.5 })), F); return B; });
      sides.forEach(s => { const [ca, cb] = span(s * (W / 2 - SD), s * (W / 2)), [ba, bb] = span(s * (W / 2 - SD), s * (W / 2 - T)), [ka, kb] = span(s * (W / 2 - SD), s * (W / 2 - T - BCd)), xs = s * (W / 2 - T - BCd / 2);
        back(ca, cb, z0, zB); back(...span(s * (W / 2 - T), s * (W / 2)), zB, zA);
        base(ba, bb, zB, z1); base(ba, bb, z1, zA); bcush(ka, kb); // corner + wing bases split at the back row's front edge, so they separate in z from the middle bases and cushions scush(xs, zB, zA); seat(ka, kb, zC, z1); seat(ka, kb, z1, zA);
        const A = arm(ca, cb, zA, D / 2); if (k === 'royal') on(A, [ball(s * (W / 2 - SD / 2), by + aH - 2, D / 2 - 12, 4, GOLD)]); });
      if (k === 'junk') [[-W * 0.18, 16, 8, '#c9a85a'], [W * 0.1, 12, 7, '#8fa8a0']].forEach(([x, w, h, col]) => { let j = 0, bd = 1e9; mx.forEach((m, i) => { if (Math.abs(m - x) < bd) { bd = Math.abs(m - x); j = i; } });
        on(MB[j], [box(Math.max(mx[j] - cw / 2 + w / 2 + 1, Math.min(mx[j] + cw / 2 - w / 2 - 1, x)), by + 4, z1 + 0.6, w, h, 1, col, { r: 1 })], F); });
      return o; } }; };
  const lsofa = S => sect(S, 270, 182, 2, [1]);
  const usofa = S => sect(S, 330, 182, 2, [-1, 1]);
  const longSofa = S => { const n = Math.min(4, S.n || 4), len = n * 50 + 48; return { w: len, d: 90, act: 'sit', seats: seatXs(len, n, 1, 1).map(x => sit(x, 12, 0, S.k)), build: P => seg(S, P, len, n, 1, 1) }; };
  const modEnd = S => ({ w: 98, d: 90, act: 'sit', seats: [sit(12, 12, 0, S.k)], build: P => seg(S, P, 98, 1, 1, 0) });
  const modMid = S => ({ w: 74, d: 90, act: 'sit', seats: [sit(0, 12, 0, S.k)], build: P => seg(S, P, 74, 1, 0, 0) });
  const modCorner = S => ({ w: SD, d: SD, act: 'sit', seats: [sit(-6, 8, -45, S.k)], build: P => corner(S, P) });
  const pit = S => { const k = S.k, R = 124, Rz = 100, a0 = Math.PI * 0.82, a1 = Math.PI * 2.18, N = 7, { by } = sty(k), ph = [0.92, 1.18, 1.5, 1.82, 2.08].map(f => f * Math.PI);
    return { w: R * 2, d: Rz * 2, round: 1, act: 'sit', seats: ph.map(t => ({ x: (R - 30) * Math.cos(t), z: (Rz - 28) * Math.sin(t), h: sH(k) - 4, f: Math.atan2(-Math.cos(t), -Math.sin(t)) * 180 / Math.PI })),
      // stacked in y per segment (curved parts never separate by their boxes, so only height can order them): base, a seat cushion over the whole base, the back sitting on its outer rim
      build: P => { const o = [], on = glue(o); for (let i = 0; i < N; i++) { const t0 = a0 + (a1 - a0) * i / N, t1 = a0 + (a1 - a0) * (i + 1) / N;
          o.push(arcW(0, 0, 0, R, Rz, 42, by + 14, t0, t1, P.aD, { n: 3 }), arcW(0, by + 14, 0, R, Rz, 42, 10, t0 + 0.01, t1 - 0.01, P.aL, { n: 3, soft: 1 }), arcW(0, by + 24, 0, R, Rz, 13, 28, t0, t1, P.a, { n: 3 })); }
        const TB = cyl(0, 0, 4, 34, 26, P.b, { rz: 26, n: 18, rg: [[0, 0, 0.9], [22, 0, 1], [26, 0, 0.85]] }); o.push(TB);
        if (k === 'royal') { o.push(arcW(0, by + 52, 0, R + 1, Rz + 1, 4, 3, a0, a1, GOLD, { n: 14 })); on(TB, [jewel(0, 26, 4, 6)]); } if (k === 'candy') on(TB, spr(0, 26, 4, 40, 30, 6));
        return o; } }; };
  const beanpile = S => { const k = S.k, B = [[-52, -18, 32], [44, -24, 30], [-6, 20, 28], [62, 30, 24]];
    return { w: 200, d: 130, act: 'sit', seats: B.map(([x, z, r]) => ({ x, z: z + 4, h: r * 0.95 })), build: P => B.map(([x, z, r], i) => ball(x, 0, z, r, k === 'candy' ? NE[[0, 2, 4, 1][i]] : [P.a, P.b, P.aL, P.w][i], { sy: 0.62, k: 7, n: 18, shine: 1 })).concat(k === 'junk' ? [box(-40, 24, 10, 14, 8, 1, '#c9a85a', { r: 1 })] : []) }; };
  const chaise = S => { const k = S.k, { by } = sty(k);
    return { w: 176, d: 74, act: 'nap', seats: [{ x: 14, z: 2, h: 32, k: 'nap' }], build: P => { const o = [];
      if (k !== 'junk') o.push(...lg(k, P, 76, 28, 8)); o.push(box(0, by, 0, 172, 14, 70, P.aD, { r: 10, bev: 3 }), pillowY(6, by + 12, 0, 156, 14, 64, P.aL), slab(-76, by + 4, 0, 24, 56, 72, P.a, { r: 14, soft: 1 }), pillowZ(-56, by + 22, 0, 26, 26, 60, P.b));
      if (k === 'royal') o.push(box(0, by - 1, 0, 176, 3, 74, GOLD, { r: 10 }), ...[-40, 0, 40].map(x => ball(x, by + 26, 32, 2.4, GOLD, { k: 3, n: 8 })));
      if (k === 'junk') o.push(...[-60, 0, 60].map(x => box(x, 0, 0, 6, by + 6, 70, OLD, { r: 1 })));
      return o; } }; };

  // ---------- TVs ----------
  const tvGlow = v => v === 'on' ? { y: 76, r: 70, c: 'url(#gNeon)' } : null;
  const tvstand = S => ({ w: 150, d: 56, act: 'watch', anim: 'tv', use: { x: 0, z: 118 }, glow: tvGlow, build: (P, v) => { const k = S.k, on = v === 'on', o = [];
    if (k === 'junk') { o.push(box(0, 0, 0, 110, 34, 46, OLD, { r: 2 }), box(0, 8, 23.4, 104, 4, 1, shade(OLD, 0.8)), box(0, 20, 23.4, 104, 4, 1, shade(OLD, 0.8)), box(0, 34, -2, 76, 58, 44, '#7a7066', { r: 8, bev: 2 }), ...scr(-6, 42, 20.6, 52, 40, on, P.b), box(26, 46, 20.8, 8, 30, 1, '#5a5048', { r: 2 }), ball(26, 74, 21, 2.6, '#c9a85a', { k: 3, n: 8 }), box(-8, 92, -2, 2, 24, 2, DK, { yaw: 0.4 }), box(8, 92, -2, 2, 22, 2, DK), ball(-10, 114, -2, 2.4, '#e2554a', { k: 3, n: 8 })); return o; }
    if (k === 'cot') { o.push(...lg(k, P, 62, 20, 8), box(0, 8, 0, 140, 38, 50, P.w, { r: 4, bev: 2 }), box(-34, 12, 25.4, 62, 30, 1, shade(P.w, 0.9), { r: 3 }), box(34, 12, 25.4, 62, 30, 1, shade(P.w, 0.9), { r: 3 }), ball(-6, 26, 26, 2, GOLD), ball(6, 26, 26, 2, GOLD), box(0, 46, 0, 20, 6, 14, shade(P.w, 0.7)), box(0, 52, 0, 104, 66, 8, shade(P.w, 0.78), { r: 4 }), ...scr(0, 57, 4.4, 92, 56, on, P.b), ball(-40, 46, 14, 8, LEAF, { sy: 0.8 })); return o; }
    if (k === 'retro') { o.push(...lg(k, P, 60, 18, 16), box(0, 16, 0, 140, 36, 48, P.a, { r: 10, bev: 2 }), box(42, 20, 24.4, 44, 28, 0.8, '#c9b48e', { r: 4 }), ...[0, 1, 2, 3].map(i => box(42, 23 + i * 6, 25, 40, 1.4, 0.4, '#a88660')), slab(-14, 52, 0, 92, 66, 40, CR, { r: 18 }), ...scr(-14, 59, 20.4, 74, 50, on, P.b), ...[-34, -22].map(x => box(x, 118, 0, 2, 20, 2, CH, { yaw: x < -30 ? 0.5 : -0.5 }))); return o; }
    if (k === 'mod') { o.push(...lg(k, P, 66, 18, 10), box(0, 10, 0, 150, 26, 46, P.a, { r: 3 }), box(0, 14, 23.4, 140, 18, 0.6, shade(P.a, 0.9), { r: 2 }), box(0, 36, -6, 30, 4, 18, DK, { r: 2 }), box(0, 40, -6, 6, 10, 4, DK), slab(0, 46, -6, 136, 80, 4, '#24262c', { r: 3 }), ...scr(0, 50, -3.6, 128, 72, on, P.b)); return o; }
    if (k === 'candy') { o.push(cyl(0, 0, 0, 66, 22, P.a, { rz: 26, n: 20 }), ...drips(0, 22, 26, 110, CR, 7), cyl(0, 22, 0, 56, 16, P.b, { rz: 22, n: 20 }), ...spr(0, 38, 0, 90, 20, 8), slab(0, 40, 0, 100, 70, 22, P.b, { r: 26 }), ...scr(0, 48, 11.4, 80, 52, on, P.a), ball(-40, 104, 0, 9, P.a), ball(40, 104, 0, 9, P.a)); return o; }
    o.push(...lg(k, P, 62, 20, 10), box(0, 10, 0, 144, 40, 50, '#f4f1ea', { r: 6, bev: 2 }), box(0, 10, 0, 148, 3, 54, GOLD, { r: 6 }), box(0, 48, 0, 148, 3, 54, GOLD, { r: 6 }), jewel(0, 30, 26, 4), slab(0, 54, -2, 116, 76, 8, GOLD, { r: 6 }), ...scr(0, 60, 2.4, 100, 62, on, '#8f7bff'), jewel(0, 134, -2, 6)); return o; } });
  const miniTV = S => ({ w: 48, d: 36, small: 1, act: 'watch', anim: 'tv', use: { x: 0, z: 70 }, glow: tvGlow, build: (P, v) => { const k = S.k, on = v === 'on', c = k === 'junk' ? '#7a7066' : k === 'royal' ? GOLD : P.a;
    return [box(0, 0, 0, 44, 36, 32, c, { r: 6, bev: 2 }), ...scr(-4, 6, 16.2, 28, 24, on, P.b), ball(14, 20, 16.4, 2.2, CR, { k: 3, n: 8 }), ball(14, 12, 16.4, 2.2, CR, { k: 3, n: 8 }), box(-6, 36, 0, 1.6, 16, 1.6, DK, { yaw: 0.5 }), box(6, 36, 0, 1.6, 14, 1.6, DK)]; } });
  const wallTV = S => ({ w: 150, d: 10, mount: 'wall', elev: 40, act: 'watch', anim: 'tv', use: { x: 0, z: 150 }, glow: tvGlow, build: (P, v) => { const k = S.k, on = v === 'on', fc = k === 'royal' ? GOLD : k === 'candy' ? P.b : k === 'cot' ? shade(P.w, 0.8) : k === 'retro' ? CR : '#24262c';
    const o = [box(0, 20, -4, 34, 34, 3, DK, { r: 2 }), slab(0, 0, 1, 140, 80, 5, fc, { r: k === 'candy' ? 18 : k === 'retro' ? 12 : 4 }), ...scr(0, 5, 3.8, 128, 70, on, P.a)];
    if (k === 'royal') o.push(jewel(0, 82, 1, 5)); if (k === 'candy') o.push(...[-50, -20, 20, 50].map((x, i) => ball(x, 74, 3, 4, NE[i])));
    return o; } });
  const projector = S => ({ w: 236, d: 10, mount: 'wall', elev: 24, act: 'watch', anim: 'tv', use: { x: 0, z: 170 }, glow: v => v === 'on' ? { y: 60, r: 110, c: 'url(#gNeon)' } : null, build: (P, v) => { const k = S.k, on = v === 'on', mt = MT[k];
    const o = [box(0, 110, 2, 232, 9, 9, k === 'mod' ? DK : mt, { r: 4 }), box(0, 6, 1, 214, 104, 1, '#f4f4f0', { r: 2 }), box(0, 0, 2, 218, 5, 4, mt, { r: 2 }), cyl(0, -10, 3, 3, 10, mt, { n: 6 })];
    if (on) o.push(...scr(0, 10, 2.2, 204, 96, true, P.b)); else o.push(box(0, 12, 1.8, 200, 92, 0.4, '#e8e8e2', { r: 2 }));
    if (k === 'retro') o.push(...[-90, -60, -30, 0, 30, 60, 90].map((x, i) => ball(x, 118, 6, 3.5, NE[i % 6], { emit: 1, k: 3, n: 8 }))); if (k === 'royal') o.push(slab(-112, 0, 4, 12, 118, 4, '#7a2a3a', { r: 4 }), slab(112, 0, 4, 12, 118, 4, '#7a2a3a', { r: 4 }), jewel(0, 120, 6, 5));
    return o; } });

  // ---------- speakers (pulse to the music, start Party) ----------
  const SPB = (k, P) => k === 'junk' ? '#5a5f6a' : k === 'cot' ? P.w : k === 'retro' ? CR : k === 'mod' ? '#2f2f3a' : k === 'candy' ? P.a : '#f4f1ea';
  const RING = k => k === 'royal' ? GOLD : k === 'candy' ? '#fff1a0' : k === 'retro' ? '#e2554a' : '#4fe0d0';
  const spk = o => Object.assign({ act: 'party', anim: 'pulse', party: 1, bass: 1, glow: v => v === 'on' ? { y: 70, r: 90, c: 'url(#gNeon)' } : null }, o);
  const spkTower = S => spk({ w: 70, d: 50, pivot: [0, 75, 24], build: (P, v) => { const k = S.k, on = v === 'on', b = SPB(k, P), rg = RING(k), o = [];
    o.push(k === 'candy' ? slab(0, 0, 0, 64, 150, 46, b, { r: 30 }) : box(0, 0, 0, 64, 150, 46, b, { r: k === 'retro' ? 14 : 6, bev: 2 }));
    o.push(...cone(0, 124, 23.2, 11, '#3b3e46', rg, on), ...cone(0, 86, 23.2, 19, '#3b3e46', rg, on), ...cone(0, 38, 23.2, 24, '#3b3e46', rg, on));
    [-29, 29].forEach(x => o.push(box(x, 6, 23.6, 2.6, 138, 0.6, on ? NE[x > 0 ? 4 : 0] : shade(b, 0.8), { emit: on ? 1 : 0 })));
    if (k === 'royal') o.push(box(0, 0, 0, 68, 4, 50, GOLD, { r: 6 }), box(0, 146, 0, 68, 4, 50, GOLD, { r: 6 }), jewel(0, 150, 0, 7)); if (k === 'candy') o.push(ball(0, 140, 0, 16, '#e2554a'), ...spr(0, 150, 0, 30, 20, 5));
    if (k === 'retro') o.push(box(0, 146, 0, 66, 4, 48, CH, { r: 8 })); if (k === 'junk') o.push(box(-18, 102, 23.6, 12, 8, 0.6, '#c9a85a', { r: 1 }));
    return o; } });
  const spkWall = S => spk({ w: 214, d: 52, pivot: [0, 70, 26], build: (P, v) => { const k = S.k, on = v === 'on', b = SPB(k, P), rg = RING(k), o = [];
    [-1, 0, 1].forEach(i => [0, 1].forEach(j => { const x = i * 70, y = j * 72, big = j === 0; o.push(box(x, y, 0, 68, 70, 48, k === 'junk' ? (i + j) % 2 ? '#b89a74' : '#a88660' : b, { r: 5, bev: 2 }), ...cone(x, y + 35, 24.2, big ? 26 : 18, '#3b3e46', rg, on)); if (!big) o.push(...cone(x + 22, y + 58, 24.2, 6, '#3b3e46', rg, on)); }));
    o.push(box(0, 144, 0, 206, 5, 48, k === 'royal' ? GOLD : shade(b, 0.8), { r: 3 })); for (let i = 0; i < 9; i++) o.push(ball(-96 + i * 24, 149, 18, 3.4, on ? NE[i % 6] : '#6a6f78', { emit: on ? 1 : 0, k: 3, n: 8 }));
    if (k === 'royal') o.push(jewel(0, 150, 0, 8)); if (k === 'junk') o.push(box(70, 138, 0, 60, 6, 44, '#c9b48e', { r: 1 })); return o; } });
  const sub = S => spk({ w: 104, d: 92, pivot: [0, 48, 46], pk: 2.2, build: (P, v) => { const k = S.k, on = v === 'on', b = SPB(k, P), o = [box(0, 0, 0, 98, 96, 88, b, { r: 9, bev: 3 }), disc(0, 48, 44, 42, 1.4, shade(b, 0.7)), disc(0, 48, 45.2, 38, 3, '#30333a', { top: 6, part: 1 }), disc(0, 48, 48.6, 15, 3, RING(k), { part: 1, emit: on ? 1 : 0, top: 2 })];
    [-36, 36].forEach(x => o.push(disc(x, 12, 44.2, 5, 1, '#1e2026'))); if (k === 'royal') o.push(prismZ(-6, 6, [[-22, 96], [-14, 118], [-6, 104], [0, 122], [6, 104], [14, 118], [22, 96]], GOLD), jewel(0, 120, 0, 4)); if (k === 'candy') o.push(...drips(0, 96, 44, 80, P.b, 6));
    return o; } });
  const smokeSpk = S => spk({ w: 82, d: 58, pivot: [0, 60, 26], smoke: 1, build: (P, v) => { const k = S.k, on = v === 'on', b = SPB(k, P), rg = RING(k), o = [box(0, 0, 0, 76, 120, 52, b, { r: 6, bev: 2 }), ...cone(0, 84, 26.2, 18, '#3b3e46', rg, on), ...cone(0, 38, 26.2, 26, '#3b3e46', rg, on), box(0, 120, 0, 66, 10, 40, DK, { r: 3 })];
    for (let i = 0; i < 4; i++) o.push(ball(-24 + i * 16, 130, 6, 5.5, on ? NE[(i * 2) % 6] : '#7a7f88', { emit: on ? 1 : 0, k: 4, n: 10, part: 1 }));
    o.push(cyl(-30, 120, -12, 5, 18, '#8a8f94', { n: 8 }), ball(-30, 138, -12, 5, CR, { sy: 0.8 })); if (k === 'royal') o.push(box(0, 0, 0, 80, 4, 56, GOLD, { r: 6 }), jewel(0, 118, 26, 4)); return o; } });
  const partyBox = S => spk({ w: 96, d: 62, pivot: [0, 50, 30], build: (P, v) => { const k = S.k, on = v === 'on', b = SPB(k, P), o = [ball(-34, 0, 0, 9, DK, { sy: 0.9 }), ball(34, 0, 0, 9, DK, { sy: 0.9 }), slab(0, 8, 0, 92, 86, 56, b, { r: 22 }), disc(0, 50, 28, 32, 1, on ? NE[5] : shade(b, 0.8), { emit: on ? 1 : 0, part: 1 }), ...cone(0, 50, 29.2, 26, '#30333a', RING(k), on), box(0, 94, 0, 54, 6, 10, DK, { r: 3 }), box(-26, 86, 0, 4, 12, 6, DK), box(26, 86, 0, 4, 12, 6, DK)];
    if (k === 'candy') o.push(...spr(0, 94, 0, 70, 30, 6)); return o; } });

  // ---------- lamps ----------
  const tableLamp = S => ({ w: 34, d: 34, small: 1, round: 1, glow: () => ({ y: 52, r: 54 }), build: P => { const k = S.k;
    if (k === 'junk') return [cyl(0, 0, 0, 9, 22, '#bfe0e4', { n: 12, rg: [[0, 0, 0.9], [18, 0, 1], [22, 0, 0.6]] }), cyl(0, 22, 0, 1.4, 18, '#8a8f94', { n: 6 }), cyl(0, 36, 0, 15, 18, '#e8dcc0', { n: 12, rg: [[0, 0, 1], [18, 0, 0.6]], emit: 1 })];
    if (k === 'cot') return [ball(0, 0, 0, 11, P.a, { sy: 1.1 }), cyl(0, 22, 0, 1.6, 12, P.wD, { n: 6 }), cyl(0, 30, 0, 17, 20, '#fff6dc', { n: 14, rg: [[0, 0, 1], [20, 0, 0.62]], emit: 1 }), cyl(0, 30, 0, 17.4, 2.4, P.b, { n: 14 })];
    if (k === 'retro') return [cyl(0, 0, 0, 10, 3, CH, { n: 12 }), cyl(0, 3, 0, 2, 26, CH, { n: 6 }), cyl(0, 22, 0, 16, 18, '#ffd23f', { n: 14, rg: [[0, 0, 0.5], [18, 0, 1]], emit: 1 }), ball(0, 40, 0, 3, '#e2554a', { k: 3, n: 8 })];
    if (k === 'mod') return [cyl(0, 0, 0, 9, 14, DK, { n: 12, rg: [[0, 0, 1], [14, 0, 0.5]] }), ball(0, 13, 0, 13, '#fff6dc', { emit: 1 })];
    if (k === 'candy') return [cyl(0, 0, 0, 10, 14, P.a, { n: 12, rg: [[0, 0, 0.8], [14, 0, 1]] }), ball(0, 12, 0, 13, '#fff6dc', { sy: 0.8, emit: 1 }), ball(0, 30, 0, 4, '#e2554a', { k: 3, n: 8 }), ...spr(0, 26, 0, 14, 14, 4)];
    return [cyl(0, 0, 0, 10, 4, GOLD, { n: 12 }), ...[8, 14, 20].map(y => ball(0, y, 0, 5, '#dff2fb', { emit: 1, k: 4, n: 10 })), cyl(0, 28, 0, 1.6, 8, GOLD, { n: 6 }), cyl(0, 34, 0, 16, 18, '#7a1e2c', { n: 14, rg: [[0, 0, 1], [18, 0, 0.6]] }), cyl(0, 34, 0, 16.4, 2, GOLD, { n: 14 })]; } });
  const sconce = S => ({ w: 40, d: 12, mount: 'wall', elev: 62, glow: () => ({ y: 22, r: 50 }), build: P => { const k = S.k, mt = MT[k];
    if (k === 'mod') return [box(0, 0, 0, 90, 8, 6, DK, { r: 3 }), box(0, 0, 3.4, 86, 4, 1, '#fff6dc', { r: 2, emit: 1 })];
    return [slab(0, 0, -1, 14, 26, 3, mt, { r: 6 }), box(0, 10, 4, 3, 3, 12, mt), cyl(0, 14, 10, 9, 14, k === 'candy' ? P.a : k === 'cot' ? '#fff6dc' : '#fff1c8', { n: 12, rg: [[0, 0, 0.6], [14, 0, 1]], emit: 1 }), ...(k === 'royal' ? [jewel(0, 30, 10, 3)] : [])]; } });
  const lantern = S => ({ w: 44, d: 44, round: 1, glow: () => ({ y: 120, r: 80 }), build: P => { const k = S.k, mt = MT[k];
    if (k === 'retro') return [cyl(0, 0, 0, 16, 4, CH, { n: 12 }), cyl(0, 4, 0, 1.8, 112, CH, { n: 6 }), ...[[-14, 108], [12, 124], [0, 140]].map(([x, y], i) => ball(x, y, 0, 8, ['#ffd23f', '#5cc8f0', '#e2554a'][i], { emit: 1 })), cyl(-6, 104, 0, 1, 10, CH, { n: 4 }), cyl(6, 118, 0, 1, 10, CH, { n: 4 })];
    return [cyl(0, 0, 0, 14, 4, mt, { n: 12 }), cyl(0, 4, 0, 2, 104, k === 'cot' ? P.wD : mt, { n: 6 }), box(0, 108, 0, 22, 26, 22, '#fff2b8', { r: 3, emit: 1 }), box(0, 106, 0, 26, 3, 26, mt, { r: 2 }), box(0, 134, 0, 26, 3, 26, mt, { r: 2 }), cyl(0, 137, 0, 8, 6, mt, { n: 8, rg: [[0, 0, 1], [6, 0, 0.3]] })]; } });
  const neonSign = S => ({ w: 110, d: 10, mount: 'wall', elev: 50, glow: () => ({ y: 30, r: 70, c: 'url(#gNeon)' }), build: P => { const k = S.k, o = [slab(0, 0, -1, 104, 62, 3, k === 'candy' ? '#3b2e5a' : INK, { r: 8 })], c = k === 'candy' ? '#ffd23f' : '#4fe0d0';
    if (k === 'candy') { for (let i = 0; i < 16; i++) { const t = i / 16 * Math.PI * 2; o.push(ball(-14 + 16 * Math.cos(t), 34 + 16 * Math.sin(t) - 3, 2, 2.6, NE[i % 6], { emit: 1, k: 3, n: 8 })); } for (let i = 0; i < 5; i++) o.push(ball(-14, 6 + i * 3, 2, 2, WH, { emit: 1, k: 3, n: 6 })); o.push(...[0, 1, 2].map(i => ball(18 + i * 10, 30, 2, 3, '#4fe0d0', { emit: 1, k: 3, n: 8 }))); return o; }
    const st = starP(5, 22, 9); for (let i = 0; i < 10; i++) { const a = st[i], b = st[(i + 1) % 10]; for (let j = 0; j < 3; j++) { const u = j / 3; o.push(ball(-24 + a[0] + (b[0] - a[0]) * u, 31 - (a[1] + (b[1] - a[1]) * u) - 2.5, 2, 2.2, c, { emit: 1, k: 3, n: 6 })); } }
    for (let i = 0; i < 6; i++) o.push(ball(14 + i * 6, 26 + Math.sin(i * 1.4) * 8, 2, 2.2, '#ffa940', { emit: 1, k: 3, n: 6 })); return o; } });
  const mushLamp = S => ({ w: 56, d: 56, round: 1, glow: () => ({ y: 40, r: 70 }), build: P => [cyl(0, 0, 0, 10, 40, CR, { n: 12, rg: [[0, 0, 1.3], [20, 0, 0.9], [40, 0, 1]] }), ball(0, 32, 0, 30, '#fff6dc', { sy: 0.18, emit: 1 }), ball(0, 34, 0, 30, P.a, { sy: 0.62 }), ...[[-14, 44, 18], [12, 50, 16], [0, 56, 4], [22, 40, 10]].map(([x, y, z]) => ball(x, y, z, 4, WH, { k: 3, n: 8 }))] });

  // ---------- plants ----------
  const leafB = (x, y, z, s, yaw, col) => ball(x, y, z, 12 * s, col, { sx: 1.8, sy: 0.18, sz: 0.9, yaw, k: 3, n: 12 });
  const cactus = S => ({ w: 40, d: 40, round: 1, build: P => [...pot(S.k, P, 14, 18), cyl(0, 16, 0, 9, 50, '#5fa556', { n: 10, rg: [[0, 0, 1], [44, 0, 1], [50, 0, 0.5]] }), cyl(-12, 34, 0, 4, 14, '#5fa556', { n: 8, rg: [[0, 0, 1], [12, 0, 1], [14, 0, 0.4]] }), box(-8, 34, 0, 8, 6, 6, '#5fa556', { r: 3 }), cyl(11, 42, 0, 4, 12, '#5fa556', { n: 8, rg: [[0, 0, 1], [10, 0, 1], [12, 0, 0.4]] }), box(8, 40, 0, 7, 5, 6, '#5fa556', { r: 3 }), ball(0, 64, 0, 4.5, S.k === 'retro' ? '#ffd23f' : '#ffa940', { k: 3, n: 8 })] });
  const monstera = S => ({ w: 70, d: 70, round: 1, build: P => { const o = [...pot(S.k, P, 22, 30)]; [[0, 60, 0, 1.3, 0], [-24, 52, 8, 1.1, 0.6], [24, 54, 6, 1.1, -0.6], [-14, 76, -8, 1, 1.2], [16, 80, -6, 1.05, -1.1], [0, 92, 4, 0.9, 0.2], [-30, 70, -4, 0.85, 2]].forEach(([x, y, z, s, a], i) => o.push(cyl(x * 0.4, 28, z * 0.4, 1.4, y - 28, '#4a8a46', { n: 5 }), leafB(x, y, z, s, a, i % 2 ? LEAF : LEAF2))); return o; } });
  const sunflower = S => ({ w: 40, d: 40, round: 1, build: P => [...pot(S.k, P, 13, 18), cyl(0, 18, 0, 1.8, 76, '#4a8a46', { n: 6 }), leafB(-10, 46, 4, 0.7, 0.4, LEAF), leafB(10, 62, 2, 0.7, -0.4, LEAF2), disc(0, 100, 4, 18, 2, '#ffd23f', { top: 1 }), disc(0, 100, 6, 9, 2, '#8a5a34', { top: 1 }), ...[0, 1, 2].map(i => disc(-3 + i * 3, 102 - (i % 2) * 3, 8.2, 1, 0.4, '#5b3b22'))] });
  const bonsai = S => ({ w: 46, d: 30, small: 1, build: P => [box(0, 0, 0, 44, 8, 28, S.k === 'royal' ? '#f4f1ea' : '#6a8ab0', { r: 4 }), cyl(0, 8, 0, 3, 20, '#8a5a34', { n: 8, rg: [[0, 0, 1.4], [20, 0, 0.8]] }), ball(-10, 24, 0, 10, LEAF, { sy: 0.6 }), ball(10, 30, 2, 9, LEAF2, { sy: 0.6 }), ball(0, 34, -2, 8, LEAF, { sy: 0.6 })] });
  const flowerPot = S => ({ w: 46, d: 46, round: 1, build: P => { const k = S.k, o = [...pot(k, P, 16, 22)];
    [[-8, 50, 2], [8, 54, -2], [0, 62, 4], [-14, 42, -4], [14, 44, 4]].forEach(([x, y, z], i) => { o.push(cyl(x * 0.5, 20, z * 0.5, 1.2, y - 20, '#4a8a46', { n: 5 }));
      if (k === 'candy') o.push(disc(x, y, z, 8, 2.4, NE[i], { top: 1 }), disc(x, y, z + 2.6, 4, 0.6, WH)); else o.push(...[0, 1, 2, 3, 4].map(j => ball(x + 4.5 * Math.cos(j * 1.26), y - 3, z + 4.5 * Math.sin(j * 1.26), 3.6, k === 'royal' ? ['#f4f1ea', '#7a1e2c'][i % 2] : RB6[(i + 1) % 6], { k: 3, n: 8 })), ball(x, y - 2, z, 2.6, '#ffd23f', { k: 3, n: 8 })); });
    o.push(leafB(-10, 26, 6, 0.6, 0.6, LEAF), leafB(10, 26, -4, 0.6, -0.6, LEAF2)); return o; } });
  const pottedPalm = S => ({ w: 70, d: 70, round: 1, build: P => { const o = [...pot(S.k, P, 22, 28)]; for (let i = 0; i < 5; i++) o.push(cyl(0, 28 + i * 16, 0, 6 - i * 0.4, 16, i % 2 ? '#a8804a' : '#b8925a', { n: 10, rg: [[0, 0, 1.15], [16, 0, 0.9]] }));
    for (let i = 0; i < 7; i++) { const a = i / 7 * Math.PI * 2; o.push(ball(30 * Math.cos(a), 98 - (i % 2) * 8, 20 * Math.sin(a), 16, i % 2 ? LEAF : LEAF2, { sx: 2, sy: 0.16, sz: 0.6, yaw: -a, k: 3, n: 12 })); }
    o.push(ball(0, 104, 0, 7, LEAF2)); return o; } });
  const succulent = S => ({ w: 30, d: 30, small: 1, round: 1, build: P => [...pot(S.k, P, 10, 12), ...[0, 1, 2, 3, 4, 5, 6].map(i => ball(6 * Math.cos(i * 0.9), 12 + (i % 2) * 2, 6 * Math.sin(i * 0.9), 4.5, i % 2 ? '#8fc9a0' : '#a8d8b0', { sy: 0.9, k: 4, n: 10 })), ball(0, 15, 0, 4, '#c8e8c0', { k: 4, n: 10 })] });

  // ---------- aquariums (fish swim) ----------
  const tankSmall = S => ({ w: 46, d: 40, small: 1, round: 1, anim: 'fish', build: P => [cyl(0, 0, 0, 12, 4, S.k === 'royal' ? GOLD : '#d8d4cc', { n: 12 }), ball(0, 3, 0, 20, '#bfe8f6', { sy: 0.92, emit: 1 }), cyl(0, 5, 0, 13, 4, '#e8cf8a', { n: 12 }), ball(-8, 8, 4, 4, LEAF, { sy: 2.2, k: 4, n: 8 }), ...fish(2, 18, 10, 1, S.k === 'candy' ? NE[1] : '#ffa940')] });
  const aquaBig = S => ({ w: 150, d: 56, anim: 'fish', build: P => { const k = S.k, c = FR(k, P), o = [];
    o.push(box(0, 0, 0, 146, 44, 52, c, { r: 4, bev: 2 }), box(-36, 6, 26.4, 64, 32, 1, shade(c, 0.9), { r: 3 }), box(36, 6, 26.4, 64, 32, 1, shade(c, 0.9), { r: 3 }), box(0, 44, 0, 140, 66, 46, '#8fd8f2', { r: 2, emit: 1 }), box(0, 44, 0, 140, 8, 46, '#e8cf8a', { r: 2 }), box(0, 110, 0, 146, 6, 52, k === 'royal' ? GOLD : shade(c, 0.85), { r: 3 }));
    [[-52, 4], [-38, -6], [44, 2], [56, -8]].forEach(([x, z], i) => o.push(ball(x, 52, z, 6, i % 2 ? LEAF : LEAF2, { sy: 3.2, k: 4, n: 8 }))); o.push(ball(10, 52, -8, 8, '#c9a86a', { sy: 0.7 }), box(18, 52, -10, 14, 12, 8, '#b8925a', { r: 2 }));
    o.push(...fish(-24, 78, 24, 1.2, '#ffa940'), ...fish(20, 66, 24, 1, '#5cc8f0'), ...fish(-4, 92, 24, 0.9, '#ffd23f'), ...fish(34, 86, 24, 0.8, k === 'royal' ? GOLD : '#8f7bff'));
    if (k === 'royal') o.push(jewel(0, 116, 0, 6)); return o; } });
  const aquaCol = S => ({ w: 60, d: 60, round: 1, anim: 'fish', build: P => [cyl(0, 0, 0, 26, 14, P.b, { n: 16 }), cyl(0, 14, 0, 22, 104, '#9fdcf4', { n: 18, emit: 1 }), cyl(0, 14, 0, 22, 8, '#fff1a0', { n: 18 }), cyl(0, 118, 0, 26, 10, P.b, { n: 16 }), ...spr(0, 128, 0, 30, 30, 6), ...fish(-4, 50, 20, 1, NE[0]), ...fish(4, 80, 20, 0.9, NE[3]), ...fish(-2, 100, 20, 0.8, NE[4])] });

  // ---------- arcade + games ----------
  const pinball = S => ({ w: 76, d: 128, act: 'play', use: { x: 0, z: 80 }, build: P => { const k = S.k, b = FR(k, P), o = [...lg(k, P, 30, 52, 38, 3)];
    o.push(prism(-34, 34, [[-60, 38], [60, 50], [60, 58], [-60, 46]], b), prism(-30, 30, [[-56, 46.4], [56, 58.4], [56, 59.4], [-56, 47.4]], k === 'candy' ? P.a : '#2b4a8a', { emit: 1 }));
    [[-12, -30], [12, -24], [0, -6]].forEach(([x, z], i) => o.push(cyl(x, 52 + (z + 60) * 0.1 - 5, z, 6, 6, NE[i * 2], { n: 10, emit: 1 }))); o.push(ball(6, 56, 24, 3, CH, { k: 3, n: 8 }));
    o.push(box(0, 50, -62, 68, 60, 12, b, { r: 4 }), box(0, 58, -55.6, 58, 44, 0.8, k === 'royal' ? '#8f7bff' : '#ffa940', { r: 3, emit: 1 }), box(0, 70, -55, 40, 10, 0.6, '#fff1a8', { r: 2, emit: 1 }));
    if (k === 'royal') o.push(jewel(0, 112, -62, 5)); return o; } });
  const claw = S => ({ w: 84, d: 84, act: 'play', use: { x: 0, z: 64 }, build: P => { const k = S.k, b = k === 'candy' ? P.a : k === 'royal' ? '#f4f1ea' : P.a, o = [box(0, 0, 0, 80, 44, 80, b, { r: 6, bev: 2 }), box(0, 44, 0, 74, 74, 74, '#d8f3ff', { r: 2, emit: 1 })];
    for (let i = 0; i < 9; i++) o.push(ball(-24 + (i % 3) * 22, 44 + ((i * 7) % 3) * 4, -18 + Math.floor(i / 3) * 18, 9, NE[i % 6], { k: 5, n: 12 }));
    o.push(cyl(8, 82, 4, 0.8, 32, CH, { n: 4 }), ball(8, 78, 4, 4, CH, { k: 3, n: 8 }), box(0, 118, 0, 84, 18, 84, b, { r: 6 }), box(0, 122, 42.4, 60, 10, 0.8, '#fff1a8', { r: 3, emit: 1 }), box(-20, 30, 40.4, 20, 8, 3, DK, { r: 2 }), ball(-20, 38, 40, 3, '#e2554a', { k: 3, n: 8 }), box(22, 22, 40.4, 14, 14, 1, '#3b3b3b', { r: 2 }));
    if (k === 'candy') o.push(...drips(0, 136, 42, 70, P.b, 6)); return o; } });
  const racer = S => ({ w: 120, d: 120, act: 'ride', seats: [{ x: 0, z: 26, h: 30, k: 'ride', f: 180 }], build: P => { const k = S.k, b = k === 'royal' ? '#f4f1ea' : P.a;
    return [box(0, 0, 10, 116, 10, 100, DK, { r: 8 }), box(0, 10, 30, 50, 18, 44, b, { r: 8, bev: 2 }), slab(0, 18, 54, 50, 50, 12, b, { r: 14, soft: 1 }), box(0, 10, -30, 100, 88, 40, b, { r: 6, bev: 2 }), box(0, 44, -9.6, 84, 48, 1, '#5ad0ff', { r: 3, emit: 1 }), box(0, 58, -9, 40, 6, 0.6, '#ffd23f', { r: 2, emit: 1 }), disc(0, 40, 0, 12, 3, '#30333a', { top: 1 }), box(0, 98, -30, 104, 12, 44, k === 'royal' ? GOLD : '#e2554a', { r: 4 })]; } });
  const consoleSet = S => ({ w: 46, d: 34, small: 1, build: P => [box(-6, 0, -4, 30, 10, 22, S.k === 'mod' ? '#e9e5dc' : '#5a5f6a', { r: 3 }), box(-6, 10, -4, 26, 1, 18, '#4fe0d0', { r: 2, emit: 1 }), ball(14, 0, 10, 7, DK, { sx: 1.4, sy: 0.5, k: 3, n: 10 }), ball(10, 3.4, 13, 1.6, '#e2554a', { k: 3, n: 6 }), ball(18, 3.4, 13, 1.6, '#5cc8f0', { k: 3, n: 6 })] });
  const handheld = S => ({ w: 26, d: 16, small: 1, build: P => [slab(0, 0, 0, 22, 36, 6, P.a, { r: 6 }), box(0, 16, 3.2, 16, 14, 0.6, '#9fe0a0', { r: 2, emit: 1 }), ball(-5, 6, 3, 2.4, DK, { k: 3, n: 8 }), ball(5, 8, 3, 2, '#e2554a', { k: 3, n: 6 }), ball(8, 4, 3, 2, '#ffd23f', { k: 3, n: 6 })] });

  X.A2 = { rug2: S => { const v = S.v, dm = RUGD[v] || [200, 130]; return { w: dm[0], d: dm[1], round: ['round', 'face', 'record', 'spiral', 'flower', 'shag', 'oval', 'star', 'hex'].includes(v) ? 1 : 0, flat: 1, noBlock: 1, build: P => rugB(v, S.k, P, dm[0], dm[1]) }; },
    lsofa, usofa, longSofa, modEnd, modMid, modCorner, pit, beanpile, chaise, tvstand, miniTV, wallTV, projector, spkTower, spkWall, sub, smokeSpk, partyBox,
    tableLamp, sconce, lantern, neonSign, mushLamp, cactus, monstera, sunflower, bonsai, flowerPot, pottedPalm, succulent, tankSmall, aquaBig, aquaCol, pinball, claw, racer, consoleSet, handheld };
  X.H2 = { NE, GOLD, CH, CR, WH, DK, TIN, OLD, OLD2, INK, LEAF, LEAF2, RB6, MT, FR, polyY, starP, rotS, lg, jewel, spr, drips, pot, leafB, fish, cone, scr };
})();
