// Generator for the 49 new Squish Squad plush fronts (ids 30-78). Same conventions as the original 30:
// 100x100 viewBox, body in <g filter="url(#ft)">, eyes = circle url(#ey) + 2 white highlights, mouth stroke #6a3a3a,
// cheeks #ff8fa3 ellipses, arms = rotated ellipses, feet = un-rotated ellipses at cy 84-93.
(function () {
const f = n => +(+n).toFixed(2);
const FT = '<filter id="ft" x="-15%" y="-15%" width="130%" height="130%"><feTurbulence type="fractalNoise" baseFrequency="1.5" numOctaves="2" seed="7"/><feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.22 0"/><feComposite in2="SourceGraphic" operator="in"/><feBlend in="SourceGraphic" mode="multiply"/></filter>';
const EY = '<radialGradient id="ey" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="#6b5470"/><stop offset="1" stop-color="#2a1a30"/></radialGradient>';
const rg = (id, a, b, c) => `<radialGradient id="${id}" cx="38%" cy="30%" r="75%"><stop offset="0" stop-color="${a}"/><stop offset="0.6" stop-color="${b}"/><stop offset="1" stop-color="${c}"/></radialGradient>`;
const lg = (id, a, b, c, h) => `<linearGradient id="${id}" x1="0" y1="0" x2="${h ? 1 : 0}" y2="${h ? 0 : 1}"><stop offset="0" stop-color="${a}"/>${c ? `<stop offset="0.5" stop-color="${b}"/><stop offset="1" stop-color="${c}"/>` : `<stop offset="1" stop-color="${b}"/>`}</linearGradient>`;
const at = o => o ? Object.entries(o).map(([k, v]) => ` ${k}="${v}"`).join('') : '';
const E = (cx, cy, rx, ry, fl, o) => `<ellipse cx="${f(cx)}" cy="${f(cy)}" rx="${f(rx)}" ry="${f(ry)}" fill="${fl}"${at(o)}/>`;
const C = (cx, cy, r, fl, o) => `<circle cx="${f(cx)}" cy="${f(cy)}" r="${f(r)}" fill="${fl}"${at(o)}/>`;
const P = (d, fl, o) => `<path d="${d}" fill="${fl}"${at(o)}/>`;
const S = (d, s, w, o) => `<path d="${d}" stroke="${s}" stroke-width="${w}" fill="none" stroke-linecap="round" stroke-linejoin="round"${at(o)}/>`;
const R = (x, y, w, h, rx, fl, o) => `<rect x="${f(x)}" y="${f(y)}" width="${f(w)}" height="${f(h)}" rx="${f(rx)}" fill="${fl}"${at(o)}/>`;
function mx(d) {
  const tk = d.match(/[a-zA-Z]|-?\d*\.?\d+/g); const out = []; let cmd = '', idx = 0;
  for (let i = 0; i < tk.length; i++) {
    const t = tk[i]; if (/[a-zA-Z]/.test(t)) { cmd = t; idx = 0; out.push(t); continue; }
    const v = +t, C2 = cmd.toUpperCase(), rel = cmd !== C2; let w = v;
    if (C2 === 'H') w = rel ? -v : 100 - v;
    else if (C2 === 'V') w = v;
    else if (C2 === 'A') { const k = idx % 7; if (k === 2) w = -v; else if (k === 4) w = 1 - v; else if (k === 5) w = rel ? -v : 100 - v; }
    else if (idx % 2 === 0) w = rel ? -v : 100 - v;
    idx++; out.push(f(w));
  }
  return out.join(' ');
}
const PM = (d, fl, o) => P(d, fl, o) + P(mx(d), fl, o);           // two elements (animate per side)
const PMc = (d, fl, o) => P(d + ' ' + mx(d), fl, o);              // one element (static decoration)
const SM = (d, s, w, o) => S(d, s, w, o) + S(mx(d), s, w, o);
const SMc = (d, s, w, o) => S(d + ' ' + mx(d), s, w, o);
const arm = (cx, cy, rot, fl, rx = 5, ry = 8) => E(cx, cy, rx, ry, fl, { transform: `rotate(${rot} ${f(cx)} ${f(cy)})` });
const arms = (dx, cy, rot, fl, rx, ry) => arm(50 - dx, cy, rot, fl, rx, ry) + arm(50 + dx, cy, -rot, fl, rx, ry);
const feet = (dx, cy, fl, rx = 8, ry = 4.5) => E(50 - dx, cy, rx, ry, fl) + E(50 + dx, cy, rx, ry, fl);
const dot = (x, y, r) => `M${f(x - r)} ${f(y)} a${f(r)} ${f(r)} 0 1 0 ${f(2 * r)} 0 a${f(r)} ${f(r)} 0 1 0 ${f(-2 * r)} 0`;
const dots = (list, r) => list.map(p => dot(p[0], p[1], p[2] || r)).join(' ');
const lens = (x, y, ang, len, w) => { const a = ang * Math.PI / 180, dx = Math.cos(a) * len / 2, dy = Math.sin(a) * len / 2, px = -Math.sin(a) * w, py = Math.cos(a) * w;
  return `M${f(x - dx)} ${f(y - dy)} Q${f(x + px)} ${f(y + py)} ${f(x + dx)} ${f(y + dy)} Q${f(x - px)} ${f(y - py)} ${f(x - dx)} ${f(y - dy)}Z`; };
const star4 = (x, y, r) => `M${f(x)} ${f(y - r)} Q${f(x)} ${f(y)} ${f(x + r)} ${f(y)} Q${f(x)} ${f(y)} ${f(x)} ${f(y + r)} Q${f(x)} ${f(y)} ${f(x - r)} ${f(y)} Q${f(x)} ${f(y)} ${f(x)} ${f(y - r)}Z`;
const star5 = (x, y, R0, r0) => { let d = ''; for (let i = 0; i < 10; i++) { const a = (-90 + i * 36) * Math.PI / 180, rr = i % 2 ? r0 : R0; d += (i ? ' L' : 'M') + f(x + Math.cos(a) * rr) + ' ' + f(y + Math.sin(a) * rr); } return d + 'Z'; };
const roundStar = (x, y, Rt, r0) => { const Rc = 2 * Rt - r0 * Math.cos(Math.PI / 5); let d = ''; for (let k = 0; k < 5; k++) { const ai = (-90 - 36 + k * 72) * Math.PI / 180, ao = (-90 + k * 72) * Math.PI / 180, an = (-90 + 36 + k * 72) * Math.PI / 180;
  if (!k) d += `M${f(x + Math.cos(ai) * r0)} ${f(y + Math.sin(ai) * r0)}`; d += ` Q${f(x + Math.cos(ao) * Rc)} ${f(y + Math.sin(ao) * Rc)} ${f(x + Math.cos(an) * r0)} ${f(y + Math.sin(an) * r0)}`; } return d + 'Z'; };
const fluffy = (cx, cy, rx, ry, n, amp) => { let d = ''; const k = 1 + amp * 2 + (1 / Math.cos(Math.PI / n) - 1);
  for (let i = 0; i <= n; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / n; const x = cx + rx * Math.cos(a), y = cy + ry * Math.sin(a);
    if (!i) { d += `M${f(x)} ${f(y)}`; continue; } const am = a - Math.PI / n; d += ` Q${f(cx + rx * k * Math.cos(am))} ${f(cy + ry * k * Math.sin(am))} ${f(x)} ${f(y)}`; } return d + 'Z'; };
const ruffle = (x0, x1, y, h, n, amp) => { let d = `M${f(x0)} ${f(y)} L${f(x1)} ${f(y)} L${f(x1)} ${f(y + h)}`; const st = (x1 - x0) / n;
  for (let i = 0; i < n; i++) { const x = x1 - st * (i + 1); d += ` Q${f(x + st / 2)} ${f(y + h + amp)} ${f(x)} ${f(y + h)}`; } return d + 'Z'; };
const hex = (x, y, r) => { let d = ''; for (let i = 0; i < 6; i++) { const a = (30 + i * 60) * Math.PI / 180; d += (i ? ' L' : 'M') + f(x + Math.cos(a) * r) + ' ' + f(y + Math.sin(a) * r); } return d + 'Z'; };
const leafG = rg('l', '#c8f59a', '#7ccd5a', '#3f9a3a');
const cherryG = rg('ch', '#ffb0b6', '#ff3a4e', '#c0102a');
const smile = (cx, my, w = 6) => S(`M${f(cx - w / 2)} ${f(my)} q${f(w / 2)} ${f(w / 2)} ${f(w)} 0`, '#6a3a3a', 1.3);
const wMouth = (cx, my) => S(`M${f(cx - 3)} ${f(my)} q1.5 1.8 3 0 q1.5 1.8 3 0`, '#6a3a3a', 1.2);
const oMouth = (cx, my) => S(`M${f(cx - 2)} ${f(my)} a2 2 0 1 0 4 0 a2 2 0 1 0 -4 0`, '#6a3a3a', 1.3);
const wavy = (cx, my) => S(`M${f(cx - 4)} ${f(my)} q1 -1.3 2 0 q1 1.3 2 0 q1 -1.3 2 0 q1 1.3 2 0`, '#6a3a3a', 1.2);
function face(o) {
  const { y, dx = 10, r = 4.6, cdx = 21, crx = 4.6, cry = 2.8, sh = [28, 42], mouth, mw = 6, cx = 50 } = o;
  const my = o.my ?? y + 7, cy = o.cy ?? y + 6; const ex = [cx - dx, cx + dx]; let s = '';
  if (sh) s += E(sh[0], sh[1], 6, 3, '#fff', { opacity: 0.9, transform: `rotate(-35 ${sh[0]} ${sh[1]})` });
  ex.forEach(x => { s += C(x, y, r, 'url(#ey)') + C(x - r * 0.33, y - r * 0.37, r * 0.35, '#fff') + C(x + r * 0.35, y + r * 0.3, r * 0.13, '#fff', { opacity: 0.9 }); });
  [cx - cdx, cx + cdx].forEach(x => { s += E(x, cy, crx, cry, '#ff8fa3', { opacity: 0.5 }); });
  s += mouth ? mouth(cx, my) : smile(cx, my, mw);
  return { svg: s, data: { eyes: ex.map(x => ({ x: f(x), y: f(y), r: f(r) })), mouth: { x: cx, y: f(my), w: 9.6 }, cheeks: [{ x: f(cx - cdx), y: f(cy) }, { x: f(cx + cdx), y: f(cy) }] } };
}
const D = {};
// ---------- Fruit Patch ----------
D.berri = () => { const fc = face({ y: 57, my: 64, cy: 63, cdx: 20, sh: [29, 45] });
  const seeds = [[40, 48, -20], [60, 48, 20], [32, 57, -30], [68, 57, 30], [35, 73, -20], [65, 73, 20], [43, 81, -10], [57, 81, 10], [50, 86, 0], [50, 49, 0]].map(([x, y, a]) => lens(x, y, a + 90, 3, 1.1)).join(' ');
  return { skin: '#ff6a80', head: 30, defs: rg('g', '#ffa4b2', '#ff4d6a', '#d42a4a') + leafG, fc,
    body: feet(10, 89, 'url(#g)', 7, 4.5) + arms(36, 63, 30, 'url(#g)') + P('M50 32 Q76 26 84 46 Q88 64 70 82 Q58 92 50 92 Q42 92 30 82 Q12 64 16 46 Q24 26 50 32Z', 'url(#g)') + P(seeds, '#ffe58a')
      + PM('M50 34 Q40 34 30 30 Q40 25 50 34Z', 'url(#l)') + PM('M50 34 Q43 27 37 21 Q47 22 50 34Z', 'url(#l)') + P('M50 34 Q45 26 50 18 Q55 26 50 34Z', 'url(#l)') + S('M50 22 Q50 15 55 11', '#4a8a34', 2.2) }; };
D.lemmy = () => { const fc = face({ y: 57, my: 65, cy: 63, cdx: 21, mouth: wavy, sh: [30, 44] });
  return { skin: '#ffe24a', head: 30, defs: rg('g', '#fffbc4', '#ffe34a', '#efb400') + leafG, fc, extra: SM('M35 49 Q39 48 44 50.5', '#c08a00', 1.5),
    body: feet(10, 89, 'url(#g)', 7.5, 4.5) + arms(34, 72, 30, 'url(#g)') + P('M50 30 Q74 30 82 50 Q90 52 89 58 Q88 64 82 64 Q76 88 50 88 Q24 88 18 64 Q12 64 11 58 Q10 52 18 50 Q26 30 50 30Z', 'url(#g)')
      + P(dots([[36, 40, 0.8], [62, 38, 0.8], [70, 48, 0.8], [30, 72, 0.8], [66, 76, 0.8], [46, 82, 0.8], [56, 36, 0.7]]), '#fff6b0', { opacity: 0.9 })
      + P('M48 32 Q47 25 50 24 Q53 25 52 32Z', '#7a9a3a') + P('M52 30 Q58 19 71 19 Q65 30 52 30Z', 'url(#l)') + S('M53 29.5 Q60 23 68 20.5', '#3f8a2a', 0.8) }; };
D.kiwi = () => { const fc = face({ y: 50, my: 57, cy: 56, cdx: 20, sh: [28, 38] });
  const sd = Array.from({ length: 10 }, (_, i) => { const a = i * 36; const rad = a * Math.PI / 180; return lens(50 + Math.cos(rad) * 6.6, 75 + Math.sin(rad) * 6.6, a, 2.4, 0.8); }).join(' ');
  const specks = dots([[30, 36], [40, 30], [62, 30], [72, 40], [26, 52], [76, 56], [24, 68], [78, 70], [34, 86], [66, 86], [50, 28]], 0.45);
  return { skin: '#a87c52', head: 24, defs: rg('g', '#dcb88e', '#a87c52', '#7a5432') + rg('s', '#f2ffc8', '#9ad84a', '#5ea82a'), fc,
    body: feet(11, 89, '#7a5432', 7.5, 4.5) + arms(36, 62, 30, 'url(#g)') + P('M50 24 Q84 24 86 58 Q86 90 50 90 Q14 90 14 58 Q16 24 50 24Z', 'url(#g)') + P(specks, '#d8b48a')
      + C(50, 75, 13.5, '#f6ffe4') + C(50, 75, 12, 'url(#s)') + E(50, 75, 3.6, 2.6, '#fffbe2') + P(sd, '#2a1a30') + P('M48 25 Q48 19 50 18 Q52 19 52 25Z', '#6a4a2a') }; };
D.melo = () => { const fc = face({ y: 52, my: 59, cy: 58, cdx: 21, sh: [28, 44] });
  const sd = [[34, 48, 70], [66, 48, 110], [40, 74, 80], [60, 74, 100], [50, 79, 90], [31, 63, 60], [69, 63, 120], [50, 44, 90]].map(([x, y, a]) => lens(x, y, a, 3.4, 1.1)).join(' ');
  return { skin: '#ff7088', head: 32, defs: rg('g', '#ffc4cc', '#ff6a82', '#e83c5c') + lg('r', '#8ee07a', '#3f9a3a'), fc,
    body: feet(12, 89, '#4fa646', 7.5, 4.5) + arms(37, 58, 25, '#5ab84e', 4.5, 7.5) + P('M10 36 Q50 30 90 36 Q92 84 50 92 Q8 84 10 36Z', 'url(#r)')
      + S('M18 70 Q22 80 28 84 M82 70 Q78 80 72 84 M40 89 L42 91 M60 89 L58 91', '#2f7a2a', 1.4, { opacity: 0.55 })
      + P('M12.5 37 Q50 31 87.5 37 Q89 81 50 88.5 Q11 81 12.5 37Z', '#f6ffe8') + P('M15 38 Q50 32 85 38 Q85 78 50 85 Q15 78 15 38Z', 'url(#g)') + P(sd, '#3a2340') }; };
D.peachy = () => { const fc = face({ y: 57, my: 64, cy: 63, cdx: 21, crx: 5.8, cry: 3.4, sh: [29, 42] });
  return { skin: '#ffaa88', head: 26, defs: rg('g', '#ffe4cc', '#ffaa88', '#ef7468') + leafG, fc,
    body: feet(10, 89, 'url(#g)', 7.5, 4.5) + arms(36, 66, 30, 'url(#g)') + P('M50 28 Q60 22 72 26 Q86 34 86 58 Q86 90 50 90 Q14 90 14 58 Q14 34 28 26 Q40 22 50 28Z', 'url(#g)')
      + S('M50 29 Q46 37 48 45', '#e2735e', 1.4, { opacity: 0.55 }) + P('M49 29 Q48 22 51 20 Q53 22 52 29Z', '#8a5a3a') + P('M52 24 Q60 13 73 15 Q67 26 52 24Z', 'url(#l)') + S('M53 23.5 Q61 17 70 16', '#3f8a2a', 0.8) }; };
D.pitaya = () => { const fc = face({ y: 57, my: 64, cy: 63, cdx: 20, sh: [30, 42] });
  const flap = (x, y, s) => `M${x} ${y} Q${x + s * 5} ${y - 1} ${x + s * 8} ${y - 8} Q${x + s * 2} ${y - 6} ${x} ${y}Z`;
  const flaps = [[24, 48, -1], [20, 65, -1], [26, 81, -1], [36, 37, -1], [37, 82, -1]].map(([x, y, s]) => flap(x, y, s) + ' ' + flap(100 - x, y, -s)).join(' ');
  return { skin: '#ff5ab8', head: 24, defs: rg('g', '#ffc6ec', '#ff4fb4', '#c81e86') + leafG + lg('fl', '#a8ec6a', '#ff6ac0'), fc,
    extra: P(star4(16, 24, 3.4) + ' ' + star4(86, 30, 2.6) + ' ' + star4(82, 84, 2.2), '#fff6b0'),
    body: PM('M26 52 Q4 46 2 24 Q18 26 30 44Z', 'url(#l)') + SM('M26 50 Q12 42 6 28', '#3f8a2a', 0.9) + feet(10, 89, 'url(#g)', 7.5, 4.5) + arms(35, 64, 28, 'url(#g)')
      + P('M50 24 Q78 26 82 56 Q84 90 50 90 Q16 90 18 56 Q22 26 50 24Z', 'url(#g)') + P(flaps, 'url(#fl)') + P('M50 26 Q46 18 50 11 Q54 18 50 26Z M44 27 Q38 20 38 14 Q45 18 47 26Z M56 27 Q62 20 62 14 Q55 18 53 26Z', 'url(#fl)') }; };
D.tutti = () => { const fc = face({ y: 46, dx: 9, r: 4.4, my: 53, cy: 52, cdx: 16, crx: 4, sh: [36, 34] });
  return { skin: '#ffd2bc', head: 24, defs: rg('g', '#fff2e6', '#ffd2bc', '#f0a88e') + rg('b', '#ffe2ac', '#e0a058', '#a86a2a') + lg('w', '#ffffff', '#cdeaff') + leafG + cherryG + rg('pr', '#e8ffb0', '#a8d84a', '#6aa82a'), fc,
    body: PM('M34 42 Q12 18 6 34 Q4 50 31 52Z', 'url(#w)', { opacity: 0.85, stroke: '#b8dcf8', 'stroke-width': 0.8 }) + C(50, 46, 22, 'url(#g)')
      + PM('M50 26 Q41 21 33 27 Q41 31 50 26Z', 'url(#l)') + S('M41 21 Q44 13 50 11 M47 22 Q48 15 50 11', '#5a8a34', 1.1) + C(40, 22, 4, 'url(#ch)') + C(47, 23, 4, 'url(#ch)')
      + C(60, 22, 6, '#ffad3a') + C(60, 22, 4.8, '#ffd67a') + S('M60 17.6 V26.4 M55.6 22 H64.4 M56.9 18.9 L63.1 25.1 M63.1 18.9 L56.9 25.1', '#ffad3a', 0.6)
      + C(25, 56, 6.5, 'url(#ch)') + S('M25 50 q1 -3 3 -4', '#6a4a2a', 1) + C(75, 57, 6, 'url(#pr)') + S('M75 51 q-1 -3 -3 -4', '#6a4a2a', 1)
      + P('M18 64 Q50 58 82 64 L76 88 Q50 94 24 88Z', 'url(#b)') + S('M21 72 Q50 66 79 72 M23 80 Q50 74 77 80 M33 66 L33 90 M44 64 L44 92 M56 64 L56 92 M67 66 L67 90', '#a86a2a', 0.9, { opacity: 0.6 })
      + P('M15 59 Q50 52 85 59 Q87 64 83 66 Q50 60 17 66 Q13 64 15 59Z', '#efb470') + arms(19, 61, 62, 'url(#g)', 4.2, 6.8) }; };
// ---------- Ocean Pals ----------
D.puff = () => { const fc = face({ y: 52, dx: 11, r: 5.2, my: 62, cy: 60, cdx: 22, mouth: oMouth, sh: [30, 38] });
  const sp = [-160, -132, -106, -74, -48, -20, 18, 162].map(a => { const r = a * Math.PI / 180, b1 = r - 0.12, b2 = r + 0.12; return `M${f(50 + Math.cos(b1) * 29)} ${f(56 + Math.sin(b1) * 29)} L${f(50 + Math.cos(r) * 38)} ${f(56 + Math.sin(r) * 38)} L${f(50 + Math.cos(b2) * 29)} ${f(56 + Math.sin(b2) * 29)}Z`; }).join(' ');
  return { skin: '#ffd24a', head: 25, defs: rg('g', '#fff6bc', '#ffd24a', '#f0a020'), fc,
    body: P(sp, '#f2b030') + feet(9, 88, '#f5a830', 6, 3.5) + arms(33, 58, 40, '#f5a830', 4.5, 8) + C(50, 56, 31, 'url(#g)') + E(50, 72, 20, 12, '#fff8dc') + P(dots([[36, 34, 2], [50, 30, 1.6], [64, 35, 2.2], [43, 40, 1.3], [58, 41, 1.3]]), '#e89a30') }; };
D.shelly = () => { const fc = face({ y: 58, dx: 8.5, r: 4.4, my: 65, cy: 64, cdx: 15, crx: 4, sh: null });
  const hx = [hex(50, 36, 7), hex(37, 43, 6), hex(63, 43, 6), hex(26, 56, 5), hex(74, 56, 5)].join(' ');
  return { skin: '#a6e07a', head: 24, defs: rg('s', '#dcfff6', '#7ee6d8', '#36b2aa') + rg('g', '#e8ffcc', '#a6e07a', '#62aa48'), fc,
    extra: E(30, 36, 8, 3.5, '#fff', { opacity: 0.75, transform: 'rotate(-32 30 36)' }) + E(44, 49, 3.5, 1.8, '#fff', { opacity: 0.8, transform: 'rotate(-30 44 49)' }),
    body: feet(14, 85, 'url(#g)', 8, 4.5) + P('M12 66 Q10 26 50 24 Q90 26 88 66 Q88 82 50 82 Q12 82 12 66Z', 'url(#s)') + P(hx, 'none', { stroke: '#ffffff', 'stroke-width': 1.3, opacity: 0.55 })
      + P('M12 66 Q50 74 88 66 Q88 72 50 80 Q12 72 12 66Z', '#2fa39c', { opacity: 0.5 }) + arms(35, 70, 50, 'url(#g)', 5, 10) + C(50, 60, 19, 'url(#g)') + P(dots([[44, 46, 1.3], [57, 47, 1.1], [50, 44, 0.9]]), '#86c862') }; };
D.octo = () => { const fc = face({ y: 48, r: 4.8, my: 56, cy: 55, cdx: 20, sh: [28, 32] });
  const t = ['M26 64 Q12 74 16 84 Q20 90 26 86', 'M36 70 Q30 82 33 89 Q36 93 40 89', 'M46 72 Q46 84 44 90 Q43 94 47 93'];
  const cups = dots([[16.5, 80], [21, 87], [32, 84], [36, 90], [45.5, 86], [45, 92]].flatMap(([x, y]) => [[x, y], [100 - x, y]]), 0.85);
  return { skin: '#ff90c0', head: 18, defs: rg('g', '#ffd4e6', '#ff90c0', '#e05a9a') + lg('t', '#ff9ac6', '#e05a9a'), fc,
    body: t.map(d => SM(d, 'url(#t)', 8)).join('') + P(cups, '#ffe0ee') + P('M16 58 Q14 20 50 18 Q86 20 84 58 Q84 74 50 74 Q16 74 16 58Z', 'url(#g)') + P(dots([[34, 30, 2.4], [64, 28, 2], [72, 40, 1.8], [27, 42, 1.6], [50, 24, 1.4]]), '#f27aae') }; };
D.marina = () => { const fc = face({ y: 44, dx: 8.5, r: 4.3, my: 51, cy: 50, cdx: 14, crx: 4, sh: [38, 32] });
  const sc = Array.from({ length: 8 }, (_, i) => `M${f(41 + (i % 4) * 5)} ${f(76 + Math.floor(i / 4) * 5)} q2.5 2.5 5 0`).join(' ');
  return { skin: '#ffd6c0', head: 18, defs: rg('g', '#fff2e6', '#ffd6c0', '#f0ac90') + rg('h', '#c8fff4', '#5ed8d0', '#2a9aa6') + lg('t', '#7ae6e0', '#5a9ae8', '#8a6ae0') + rg('pl', '#ffffff', '#f0e8ff', '#c4b4ee'), fc,
    body: P('M24 46 Q22 18 50 18 Q78 18 76 46 Q78 62 70 72 L30 72 Q22 62 24 46Z', 'url(#h)') + PM('M28 50 Q20 70 30 82 Q36 72 34 58Z', 'url(#h)')
      + P('M37 66 Q34 80 42 86 Q50 90 58 86 Q66 80 63 66Z', 'url(#t)') + P(sc, 'none', { stroke: '#ffffff', 'stroke-width': 0.8, opacity: 0.45 })
      + P('M46 84 Q36 88 28 96 Q42 97 50 90 Q58 97 72 96 Q64 88 54 84Z', 'url(#t)') + E(50, 66, 12, 7.5, 'url(#g)') + C(44.5, 64, 3.4, '#ffb6d0') + C(55.5, 64, 3.4, '#ffb6d0')
      + C(50, 42, 20, 'url(#g)') + P('M30 38 Q31 22 50 22 Q69 22 70 38 Q62 30 56 34 Q52 27 46 33 Q40 28 30 38Z', 'url(#h)') + P(star5(66, 26, 5, 2.3), '#ffd24a')
      + arms(10, 70, -55, 'url(#g)', 3.5, 6.5) + C(50, 72, 5, 'url(#pl)') }; };
D.pearl = () => { const fc = face({ y: 58, my: 65, cy: 64, cdx: 21, sh: [28, 46] });
  return { skin: '#b4d8ff', head: 32, defs: rg('g', '#f2f9ff', '#b4d8ff', '#7aa4e8') + lg('h', '#fffbe8', '#ffe7a0', '#f2be5a'), fc,
    extra: P(star4(62, 10, 2.6) + ' ' + star4(41, 14, 2), '#fff6c8'),
    body: C(53, 12, 8, '#fff6c8', { opacity: 0.55 }) + P('M46 34 L53 4 Q55 4 55 6 L54 34Z', 'url(#h)') + S('M47 28 L54 26 M48.4 22 L54.6 20.5 M49.8 16 L55 15 M51.2 10 L55 9.5', '#e0a040', 0.9)
      + P('M78 62 Q92 52 96 40 Q90 52 98 58 Q88 60 82 70Z', 'url(#g)') + P('M14 64 Q12 32 50 32 Q88 32 86 64 Q86 88 50 88 Q14 88 14 64Z', 'url(#g)')
      + P('M24 76 Q50 66 76 76 Q72 87 50 87 Q28 87 24 76Z', '#f4faff') + P(dots([[38, 40, 1.5], [50, 37, 1.2], [62, 41, 1.6], [70, 48, 1.2], [30, 48, 1.1]]), '#8ab4ee') + arms(36, 72, 50, 'url(#g)', 4.5, 8) }; };
// ---------- Pet Shop ----------
D.waffles = () => { const fc = face({ y: 46, dx: 11, r: 4.4, my: 65, cy: 56, cdx: 20, crx: 4, mouth: wMouth, sh: null });
  return { skin: '#e8953e', head: 26, defs: rg('g', '#f9bd74', '#e0823a', '#b2561e'), fc, extra: E(50, 62, 4, 2.6, '#2a1a30'),
    body: PM('M18 44 Q16 20 22 8 Q27 3 31 9 Q40 22 46 32Z', 'url(#g)') + PM('M26 36 L28 13 L40 30Z', '#ffd6c0')
      + P('M28 56 Q28 46 50 46 Q72 46 72 56 Q74 72 50 76 Q26 72 28 56Z', 'url(#g)') + P('M36 54 Q50 50 64 54 Q66 68 50 72 Q34 68 36 54Z', '#fff8ee')
      + E(36, 80, 6, 6, 'url(#g)') + E(64, 80, 6, 6, 'url(#g)') + E(36, 85, 6.5, 3.5, '#fff8ee') + E(64, 85, 6.5, 3.5, '#fff8ee')
      + P('M22 40 Q22 26 50 24 Q78 26 78 40 Q80 54 62 64 L50 70 L38 64 Q20 54 22 40Z', 'url(#g)')
      + P('M38 56 Q50 50 62 56 Q58 68 50 70 Q42 68 38 56Z', '#fff8ee')
      + P('M46 26 Q50 24 54 26 Q56 40 50 46 Q44 40 46 26Z', '#fff8ee') }; };
D.poppy = () => { const fc = face({ y: 56, dx: 11, my: 64.5, cy: 62, cdx: 22, mouth: wMouth, sh: [30, 44] });
  const B = 'M12 64 Q12 34 50 34 Q88 34 88 64 Q88 88 50 88 Q12 88 12 64Z';
  return { skin: '#f6e8d4', head: 34, defs: rg('g', '#fffbf2', '#f6e8d4', '#dcc6a6') + `<clipPath id="c"><path d="${B}"/></clipPath>`, fc, extra: P('M48.4 61 Q50 60 51.6 61 Q50 63 48.4 61Z', '#ff8fa3'),
    body: feet(13, 89, '#ffb8c0', 6, 3.5) + PM('M30 38 Q22 28 30 25 Q38 27 39 36Z', '#d9925a') + P(B, 'url(#g)')
      + `<g clip-path="url(#c)">${P('M8 30 H46 Q42 46 32 52 Q20 58 8 54Z', '#eba05e')}${P('M60 30 H92 V60 Q78 52 70 44 Q62 38 60 30Z', '#8a5a3a')}${P('M8 76 Q24 72 30 92 H8Z', '#8a5a3a')}${P('M72 92 Q78 76 92 78 V92Z', '#eba05e')}</g>`
      + arms(34, 76, 20, '#f2dcc0', 4, 6) }; };
D.duchess = () => { const fc = face({ y: 50, r: 4.8, my: 59.5, cy: 57, cdx: 19, mouth: wMouth, sh: [30, 36] });
  return { skin: '#f6f0fb', head: 22, defs: rg('g', '#ffffff', '#f6f0fb', '#d8cce8') + lg('gd', '#fff4b0', '#ffd23a', '#e09a10'), fc, extra: P('M48.4 56 L51.6 56 L50 58Z', '#ff8fa3'),
    body: P('M70 82 Q94 80 92 58 Q90 46 82 50 Q86 62 76 70Z', 'url(#g)') + feet(11, 89, 'url(#g)', 7.5, 4.5) + P(fluffy(50, 76, 24, 13, 10, 0.12), 'url(#g)') + arms(32, 74, 18, 'url(#g)', 5, 7.5)
      + PM('M28 32 Q24 16 30 12 Q38 18 42 26Z', 'url(#g)') + PM('M30 28 Q28 18 31 16 Q36 20 38 25Z', '#ffc4d4') + P(fluffy(50, 48, 29, 24, 14, 0.08), 'url(#g)')
      + PMc('M50 66 Q42 60 40 66 Q42 72 50 66Z', '#ff8fc0') + C(50, 66, 2.2, '#ff5c9e')
      + P('M38 22 L36 10 L43 16 L50 6 L57 16 L64 10 L62 22 Q50 25 38 22Z', 'url(#gd)', { stroke: '#ffffff', 'stroke-width': 0.8 }) + C(50, 13, 1.6, '#ff6aa8') + C(43.5, 18, 1.2, '#7cc8ff') + C(56.5, 18, 1.2, '#7cc8ff') }; };
D.mamapaws = () => { const fc = face({ y: 38, dx: 10, r: 4.6, my: 50.5, cy: 45, cdx: 18, crx: 4.2, mouth: wMouth, sh: [32, 26] });
  return { skin: '#cf9862', head: 15, defs: rg('g', '#f4d2aa', '#cf9862', '#a26a3a') + rg('dk', '#b47e4c', '#8a5a36', '#6a4024') + rg('p', '#fff6e6', '#ffe0be', '#e8b888'), fc,
    extra: E(50, 46, 3, 2.2, '#3a2340') + C(50, 71, 11, 'url(#p)') + PM('M41 64 Q35 66 37 75 Q41 73 43 67Z', '#d8a070') + C(46, 71, 1.8, '#3a2a40') + C(54, 71, 1.8, '#3a2a40') + C(45.4, 70.3, 0.6, '#ffffff') + C(53.4, 70.3, 0.6, '#ffffff')
      + E(50, 74, 1.4, 1, '#3a2340') + S('M48.6 75.6 q1.4 1.2 2.8 0', '#7a4a3a', 0.9) + E(43, 74.5, 2, 1.2, '#ff8fa3', { opacity: 0.5 }) + E(57, 74.5, 2, 1.2, '#ff8fa3', { opacity: 0.5 }),
    body: feet(14, 90, 'url(#g)', 9, 5) + E(50, 74, 28, 17, 'url(#g)') + E(50, 79, 18, 10, '#f8e2c4') + arms(16, 76, -38, 'url(#g)', 5.5, 9) + C(50, 40, 25, 'url(#g)')
      + PM('M28 24 Q16 24 13 42 Q12 58 21 60 Q30 56 31 38Z', 'url(#dk)') + E(50, 48, 11, 7, '#f8e2c4') }; };
// ---------- Forest Friends ----------
D.acorn = () => { const fc = face({ y: 50, dx: 9.5, r: 4.6, my: 57.5, cy: 56, cdx: 17, crx: 4.2, sh: [33, 44] });
  return { skin: '#ec9450', head: 16, defs: rg('g', '#ffd8a6', '#ec9450', '#c46a2a') + rg('t', '#ffe4c0', '#f0a462', '#c87a3a') + rg('cap', '#dcae6e', '#a8743a', '#7a4e22'), fc, extra: E(50, 54.5, 1.7, 1.2, '#7a3a2a'),
    body: P('M62 86 Q98 84 94 50 Q92 22 70 20 Q62 22 64 30 Q82 36 80 56 Q76 72 62 86Z', 'url(#t)') + S('M70 26 Q88 32 86 54 Q84 70 70 80', '#fff0dc', 1.6, { opacity: 0.6 })
      + feet(11, 89, 'url(#g)', 7, 4.5) + E(50, 76, 19, 14, 'url(#g)') + E(50, 78, 11, 9, '#fff0dc') + arms(19, 73, 28, 'url(#g)', 4.5, 7.5)
      + PM('M29 36 Q19 26 23 16 Q32 18 37 29Z', 'url(#g)') + PM('M28.5 32 Q22 26 24.5 20 Q30 22 33 28Z', '#ffc0b0') + C(50, 50, 23, 'url(#g)')
      + P('M24 38 Q24 16 50 16 Q76 16 76 38 Q50 32 24 38Z', 'url(#cap)') + S('M30 34 Q38 22 50 18 M40 34 Q50 24 62 19 M52 33 Q62 26 72 26 M28 27 Q40 30 50 33 M36 20 Q50 25 66 33', '#7a4e22', 0.9, { opacity: 0.55 })
      + P('M22 38 Q50 30 78 38 Q79 42 75 43 Q50 36 25 43 Q21 42 22 38Z', '#c8925a') + P('M48 17 Q47 10 51 8 Q53 10 52 17Z', '#6a4220') }; };
D.fawn = () => { const fc = face({ y: 47, dx: 10, r: 4.8, my: 58, cy: 54, cdx: 18, crx: 4.2, sh: [33, 34] });
  return { skin: '#e6aa6e', head: 23, defs: rg('g', '#ffe6c2', '#e6aa6e', '#c07c44'), fc, extra: E(50, 54, 2.4, 1.7, '#5a3a30'),
    body: feet(10, 90, '#8a5a36', 5.5, 3.5) + E(50, 76, 20, 13, 'url(#g)') + P(dots([[38, 72, 1.8], [44, 81, 1.5], [61, 73, 1.8], [56, 82, 1.5], [66, 80, 1.3], [33, 79, 1.3]]), '#fff6e6') + arms(19.5, 73, 24, 'url(#g)', 4, 7)
      + PM('M30 38 Q14 32 8 22 Q22 20 34 32Z', 'url(#g)') + PM('M29 35 Q18 30 13 24 Q23 24 31 31Z', '#ffb8c4') + PM('M41 26 Q38 18 41 15 Q45 17 45 25Z', '#fff0d8')
      + C(50, 46, 23, 'url(#g)') + P(dots([[40, 30, 1.6], [60, 30, 1.6], [50, 27, 1.3], [34, 38, 1.1], [66, 38, 1.1]]), '#fff6e6') + E(50, 56, 10, 7, '#fff2e0') }; };
D.moss = () => { const fc = face({ y: 66, dx: 9, r: 4.4, my: 73, cy: 72, cdx: 16, crx: 4, sh: [24, 27] });
  return { skin: '#f6ead2', head: 10, defs: rg('cap', '#ffb6a6', '#f2584c', '#c42e2a') + rg('g', '#fffcf4', '#f6ead2', '#dcc8a0') + rg('m', '#c6f08a', '#7cc04a', '#4a8a2a'), fc,
    body: feet(11, 89, 'url(#g)', 7, 4.5) + P('M28 46 Q24 88 50 88 Q76 88 72 46Z', 'url(#g)') + arms(24, 70, 28, 'url(#g)', 4.5, 7)
      + P('M16 90 Q18 84 24 86 Q28 82 32 87 Q30 92 22 92Z M84 90 Q82 84 76 86 Q72 82 68 87 Q70 92 78 92Z', 'url(#m)')
      + P('M8 46 Q8 12 50 10 Q92 12 92 46 Q92 54 50 54 Q8 54 8 46Z', 'url(#cap)') + P(dots([[30, 26, 5], [52, 18, 4], [70, 30, 5.5], [43, 39, 3], [81, 43, 3], [19, 42, 3]]), '#fff4e8')
      + P('M14 50 Q50 58 86 50 Q86 54 50 57 Q14 54 14 50Z', '#e8d2b0') + P('M60 14 Q63 8 69 11 Q75 9 78 15 Q72 18 66 16 Q61 18 60 14Z', 'url(#m)') }; };
D.sprout = () => { const fc = face({ y: 58, dx: 9.5, r: 4.6, my: 65, cy: 64, cdx: 16, crx: 4.2, sh: [30, 40] });
  return { skin: '#f6dfbc', head: 25, defs: rg('g', '#f2d8b0', '#cc9e66', '#9a6a3a') + rg('fd', '#fff6e4', '#f6dfbc', '#e8c898') + lg('l', '#b8f08a', '#4fa646'), fc,
    body: feet(11, 90, '#8a5a32', 8, 4.5) + arms(35, 64, 30, '#a87442', 4, 8) + P('M16 62 Q14 28 50 26 Q86 28 84 62 Q84 90 50 90 Q16 90 16 62Z', 'url(#g)')
      + S('M22 56 Q20 66 23 76 M78 56 Q80 66 77 76 M30 81 Q32 86 36 88 M70 81 Q68 86 64 88', '#9a6a3a', 1.2, { opacity: 0.6 }) + E(50, 61, 22, 17, 'url(#fd)')
      + P('M24 40 Q26 26 50 25 Q74 26 76 40 Q70 34 64 38 Q58 32 50 36 Q42 32 36 38 Q30 34 24 40Z', 'url(#l)')
      + S('M50 30 Q48 18 51 8', '#5a8a34', 2) + P('M50 19 Q40 19 36 11 Q46 9 50 19Z', 'url(#l)') + P('M51 13 Q58 6 66 8 Q60 16 51 13Z', 'url(#l)') + C(51, 7, 2.4, '#ffb6d4') + C(51, 7, 1, '#ffe14a') }; };
// ---------- Sky & Stars ----------
D.plip = () => { const fc = face({ y: 64, my: 71, cy: 70, cdx: 19, sh: [36, 44] });
  return { skin: '#8fd6ff', head: 10, defs: rg('g', '#eaf9ff', '#8fd6ff', '#46a6ec'), fc, extra: E(43, 24, 1.8, 4, '#fff', { opacity: 0.8, transform: 'rotate(28 43 24)' }) + S('M28 76 Q32 85 44 87', '#ffffff', 1.6, { opacity: 0.55 }),
    body: feet(9, 90, 'url(#g)', 6.5, 4) + arms(34, 72, 25, 'url(#g)', 4.5, 7) + P('M50 10 Q58 28 74 44 Q88 60 84 76 Q78 92 50 92 Q22 92 16 76 Q12 60 26 44 Q42 28 50 10Z', 'url(#g)') }; };
D.breeze = () => { const fc = face({ y: 56, dx: 9, r: 4.6, my: 63, cy: 62, cdx: 17, crx: 4.2, sh: [34, 40] });
  const bow = (x, y) => `M${x} ${y} L${x - 3.6} ${y - 2.6} L${x - 3.6} ${y + 2.6}Z M${x} ${y} L${x + 3.6} ${y - 2.6} L${x + 3.6} ${y + 2.6}Z`;
  return { skin: '#e8fbf6', head: 26, defs: rg('g', '#ffffff', '#e8fbf6', '#b4e6dc'), fc, extra: S('M84 26 Q91 24 96 28 M86 33 Q90 33 94 35', '#9ad8cc', 1.4),
    body: S('M20 72 Q8 78 12 87 Q16 94 7 98', '#ff9fcb', 1.5) + P(bow(11, 80), '#ffd24a') + P(bow(13, 89), '#7cc8ff') + P(bow(8, 96), '#ff9fcb')
      + arms(37, 62, 30, 'url(#g)', 4.5, 6.5) + P('M22 74 Q10 72 12 60 Q12 48 24 48 Q24 30 42 30 Q50 20 62 28 Q78 26 80 44 Q92 46 90 60 Q90 74 76 74 Q70 84 50 82 Q30 84 22 74Z', 'url(#g)')
      + S('M58 40 Q66 35 70 42 Q72 48 66 49', '#9ad8cc', 1.6) + S('M30 68 Q25 62 31 59', '#9ad8cc', 1.4) }; };
D.dusty = () => { const fc = face({ y: 56, dx: 9, r: 4.6, my: 63, cy: 62, cdx: 17, crx: 4.2, sh: [38, 44] });
  const feather = s => { const x0 = 50 + s * 6, x1 = 50 + s * 16; let d = `M${x0} 36 Q${50 + s * 10} 24 ${x1} 18`; for (let i = 1; i <= 4; i++) { const t = i / 5; const x = x0 + (x1 - x0) * t, y = 36 - 18 * t; d += ` M${f(x)} ${f(y)} l${f(-s * 2.2)} -1.8 M${f(x)} ${f(y)} l${f(s * 2.2)} 0.6`; } return d; };
  return { skin: '#f4e6cc', head: 34, defs: rg('g', '#fffcf2', '#f4e6cc', '#d8c09a') + rg('w', '#f8eeff', '#d2b6f4', '#a07ad8'), fc,
    body: PM('M34 52 Q10 16 4 34 Q0 52 30 62 Q12 66 13 80 Q20 90 37 74Z', 'url(#w)', { stroke: '#fff4ff', 'stroke-width': 1.2 }) + P(dots([[17, 40, 3.4], [83, 40, 3.4], [22, 76, 2.2], [78, 76, 2.2]]), '#fff1d6')
      + S(feather(-1), '#a08060', 1) + S(feather(1), '#a08060', 1) + feet(8, 86, '#d8c09a', 4.5, 3) + arms(32, 66, 30, 'url(#g)', 3.8, 6.5)
      + C(50, 58, 24, 'url(#g)') + P(fluffy(50, 74, 15, 6, 8, 0.2), '#ffffff', { opacity: 0.7 }) + P('M42 36 Q46 30 50 34 Q54 30 58 36 Q50 38 42 36Z', '#ffffff') }; };
D.aurora = () => { const fc = face({ y: 58, my: 65, cy: 64, cdx: 21, sh: [28, 46] });
  const stars = [star4(34, 41, 2.6), star4(62, 38, 2), star4(72, 48, 2.4), star4(28, 52, 1.8), star4(48, 36, 1.5)].join(' ');
  return { skin: '#a8b8ff', head: 32, defs: '<linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#a6f6e8"/><stop offset="0.5" stop-color="#a2acff"/><stop offset="1" stop-color="#ffaee8"/></linearGradient>', fc,
    extra: P(star4(44, 22, 3) + ' ' + star4(57, 16, 2.4) + ' ' + star4(50, 9, 1.8), '#fff6b0') + S('M50 32 Q46 25 42 23 M50 32 Q54 24 58 20', '#d6f4ff', 1.4),
    body: P('M70 42 Q76 22 92 16 Q86 26 90 34 Q80 32 76 46Z', 'url(#g)') + P('M12 62 Q12 32 50 32 Q88 32 88 62 Q88 88 50 88 Q12 88 12 62Z', 'url(#g)')
      + P('M22 72 Q50 62 78 72 Q74 87 50 87 Q26 87 22 72Z', '#f4f0ff') + S('M34 76 Q50 72 66 76 M30 81 Q50 77 70 81', '#d8d0f6', 1.1) + P(stars, '#ffffff') + arms(36, 72, 50, 'url(#g)', 4.5, 8) }; };
// ---------- Dreamland ----------
D.boo = () => { const fc = face({ y: 48, dx: 9, r: 4.4, my: 55, cy: 55, cdx: 17, crx: 5.2, cry: 3.2, mouth: wavy, sh: [30, 32] });
  return { skin: '#f2f0ff', head: 18, defs: rg('g', '#ffffff', '#f2f0ff', '#cfc6ee'), fc, extra: P('M72 30 Q74 35 72 37.5 Q70 35 72 30Z', '#a8dcff'),
    body: arms(35, 58, 40, 'url(#g)', 4.5, 7.5) + P('M18 54 Q18 18 50 18 Q82 18 82 54 V80 Q77 88 71 82 Q64 90 57 83 Q50 91 43 83 Q36 90 29 82 Q23 88 18 80Z', 'url(#g)') }; };
D.pixie = () => { const fc = face({ y: 46, dx: 8.5, r: 4.3, my: 53, cy: 52, cdx: 14, crx: 4, sh: [38, 34] });
  const petals = Array.from({ length: 5 }, (_, i) => { const a = (i * 72 - 90) * Math.PI / 180; return dot(58 + Math.cos(a) * 2.6, 13 + Math.sin(a) * 2.6, 1.8); }).join(' ');
  return { skin: '#ffd8c6', head: 10, defs: rg('g', '#fff4ea', '#ffd8c6', '#f0b096') + rg('h', '#ffe2f6', '#ff92d4', '#d4549e') + lg('w', '#ffffff', '#c8ecff') + rg('d', '#dcffc4', '#8ad86a', '#4fa646'), fc,
    body: PM('M38 60 Q16 32 7 46 Q3 60 34 68Z', 'url(#w)', { opacity: 0.85, stroke: '#b8e0ff', 'stroke-width': 0.8 }) + PM('M38 70 Q20 73 20 84 Q30 87 40 75Z', 'url(#w)', { opacity: 0.85, stroke: '#b8e0ff', 'stroke-width': 0.8 })
      + feet(7, 90, '#4fa646', 5, 3.2) + S('M43.5 82 L43.5 88 M56.5 82 L56.5 88', '#f6c6b0', 3) + P('M34 66 Q30 80 36 86 Q42 82 44 86 Q50 82 56 86 Q58 82 64 86 Q70 80 66 66Z', 'url(#d)')
      + E(50, 66, 11, 7, 'url(#d)') + arms(15, 68, 30, 'url(#g)', 3.5, 6) + P('M28 44 Q26 20 50 20 Q74 20 72 44 Q72 54 66 56 L34 56 Q28 54 28 44Z', 'url(#h)')
      + PM('M32 47 Q22 41 21 36 Q28 38 34 43Z', 'url(#g)') + C(50, 44, 19, 'url(#g)') + C(50, 18, 8, 'url(#h)')
      + P('M31 40 Q32 26 50 25 Q68 26 69 40 Q62 32 55 36 Q50 30 44 35 Q38 32 31 40Z', 'url(#h)') + P(petals, '#fff6a0') + C(58, 13, 1.4, '#ffb03a') }; };
D.floof = () => { const fc = face({ y: 53, dx: 8.5, r: 4.6, my: 61, cy: 60, cdx: 14, crx: 3.8, cry: 2.4, sh: [30, 40] });
  return { skin: '#b0ccf8', head: 28, defs: rg('g', '#ffffff', '#eef3ff', '#c6d2ee') + rg('fc', '#e6f0ff', '#b0ccf8', '#7c9ee0'), fc, extra: P('M46 62.4 l1.1 2.2 l1.1 -2.2Z M51.8 62.4 l1.1 2.2 l1.1 -2.2Z', '#ffffff'),
    body: feet(13, 89, '#9ab4e8', 9, 5) + P(fluffy(50, 60, 33, 30, 16, 0.07), 'url(#g)') + arms(36, 66, 28, 'url(#g)', 6, 9) + P('M43 31 Q45 21 51 25 Q54 16 60 24 Q56 31 43 31Z', 'url(#g)') + E(50, 57, 18, 15, 'url(#fc)') }; };
D.unibun = () => { const fc = face({ y: 50, dx: 10, r: 4.6, my: 57, cy: 56, cdx: 18, crx: 4.2, sh: [33, 40] });
  return { skin: '#f6f0ff', head: 24, defs: rg('g', '#ffffff', '#f6f0ff', '#d6cbee') + lg('hn', '#fff6b0', '#ffb8e0', '#b8a8ff'), fc, extra: P('M49 53.6 L51 53.6 L50 54.9Z', '#ff8fa3'),
    body: PM('M38 30 Q30 10 34 2 Q42 6 44 28Z', 'url(#g)') + PM('M39 26 Q34 12 36 6 Q41 10 42 26Z', '#ffc4dc') + feet(11, 89, 'url(#g)', 7.5, 4.5) + E(39, 90.5, 4.5, 2.4, '#ffc4dc', { opacity: 0.9 }) + E(61, 90.5, 4.5, 2.4, '#ffc4dc', { opacity: 0.9 })
      + E(50, 76, 19, 13, 'url(#g)') + arms(19.5, 73, 26, 'url(#g)', 5, 7.5) + C(50, 50, 24, 'url(#g)')
      + P('M35 31 Q39 22 47 26 Q50 20 56 26 Q62 22 65 31 Q57 33 50 30 Q42 34 35 31Z', '#ffb8e0') + P('M27 42 Q20 46 24 54 Q29 50 31 45Z', '#c8b0ff') + P('M26.5 52 Q22 58 27 62 Q30 58 30 54Z', '#a8e0ff')
      + P('M46.5 28 L50 9 L53.5 28Z', 'url(#hn)') + S('M47.3 24 L52.6 22.6 M48.2 19 L51.8 18 M49 14.4 L51 14', '#ffffff', 0.8, { opacity: 0.85 }) }; };
D.gumdrop = () => { const fc = face({ y: 41, dx: 9, r: 4.2, my: 48, cy: 47, cdx: 15, crx: 3.8, cry: 2.4, sh: [36, 28] });
  return { skin: '#ff5a72', head: 17, defs: rg('g', '#ffc8d0', '#ff5a72', '#d0203e'), fc, extra: E(64, 67, 2.4, 5, '#fff', { opacity: 0.7, transform: 'rotate(22 64 67)' }) + E(37, 64, 1.4, 2.6, '#fff', { opacity: 0.6, transform: 'rotate(-20 37 64)' }),
    body: C(30, 24, 7.5, 'url(#g)') + C(70, 24, 7.5, 'url(#g)') + C(30, 24, 3.5, '#ff8aa0', { opacity: 0.7 }) + C(70, 24, 3.5, '#ff8aa0', { opacity: 0.7 }) + feet(12, 88, 'url(#g)', 8, 5.5)
      + arms(23, 66, 30, 'url(#g)', 5.5, 8.5) + E(50, 72, 22, 17, 'url(#g)') + E(50, 74, 11, 9, '#ffd6dc', { opacity: 0.55 }) + C(50, 40, 22, 'url(#g)') }; };
D.ember = () => { const fc = face({ y: 54, r: 4.8, my: 66.5, mw: 4, cy: 60, cdx: 20, sh: [30, 40] });
  const tip = (x, y, a, l, w) => P(lens(x, y, a, l, w), 'url(#pl)') + C(x, y + 0.4, w * 0.42, '#d8342a');
  return { skin: '#ffa23a', head: 28, defs: rg('g', '#fff0a0', '#ffa23a', '#e8482a') + lg('wg', '#ffd84a', '#ff8a2a', '#e0402a') + rg('pl', '#fff6b0', '#ffc23a', '#ff6a2a') + lg('bk', '#ffd36a', '#f08a1e'), fc,
    extra: P('M46.6 60.2 Q50 58.6 53.4 60.2 Q52 64.2 50 65 Q48 64.2 46.6 60.2Z', 'url(#bk)'),
    body: S('M60 80 Q78 82 84 63', '#f0582a', 2) + S('M60 82 Q84 86 90 72', '#f0582a', 2) + S('M58 78 Q72 74 76 55', '#f0582a', 2)
      + tip(85, 56, -80, 14, 5) + tip(91.5, 66, -72, 13, 4.6) + tip(77, 47.5, -85, 14, 5)
      + feet(9, 89, '#ff9a2a', 6.5, 3.6) + C(50, 58, 29, 'url(#g)') + P(fluffy(50, 77.5, 13.5, 8, 9, 0.07), '#fff0c4', { opacity: 0.9 })
      + arms(29, 65, 38, 'url(#wg)', 6, 10.5)
      + S('M50 30 Q47 22 51 16', '#f0582a', 1.4) + S('M46 31 Q42 25 39 20', '#f0582a', 1.3) + S('M54 31 Q58 25 61 20', '#f0582a', 1.3)
      + P(lens(51.8, 11.5, -80, 11, 4), 'url(#pl)') + P(lens(37.2, 16.5, -125, 9.5, 3.4), 'url(#pl)') + P(lens(62.8, 16.5, -55, 9.5, 3.4), 'url(#pl)') }; };
// Drako v2 (remodel): chubby baby dragon - round bean body, snout muzzle with nostrils, curled cream horns, purple ear fins, purple back spikes,
// real bat wings (finger bones + scalloped edge) peeking out behind, thick tail along the ground curling up into a spade, cream ridged belly
D.drako = () => { const fc = face({ y: 46.5, r: 5.2, my: 61, cy: 55, cdx: 20, sh: [32, 33] });
  return { skin: '#7ee08c', head: 22, defs: rg('g', '#d8ffd2', '#7ee08c', '#3eae5c') + rg('wg', '#efe2ff', '#b090ff', '#7a50d8') + lg('hn', '#fffbe8', '#f6e2a8', '#d8b870') + rg('mz', '#e6ffe0', '#b4f0b0', '#8ad890'), fc,
    extra: E(50, 57.6, 9.6, 5.6, 'url(#mz)') + E(46.6, 56.2, 1.1, 0.8, '#2e8a4a') + E(53.4, 56.2, 1.1, 0.8, '#2e8a4a') + C(72, 40, 2.6, '#eef0f8', { opacity: 0.85 }) + C(76, 35, 2, '#eef0f8', { opacity: 0.75 }) + C(79, 30, 1.4, '#eef0f8', { opacity: 0.6 }),
    body: PM('M29 49 Q20 39 6 31 Q8.5 39 10.5 43 Q7 47 8 52 Q12 51.5 15.5 54.5 Q14 59 16 62.5 Q21 59.5 27 61Z', 'url(#wg)') + SM('M28 50 L10.5 43 M28 52 L15.5 54.5 M28 55 L16 62.5', '#7a50d8', 0.9, { opacity: 0.7 })
      + P('M62 80 Q78 89 87 80 Q91 74 88 66.5 Q85 74 80 76.5 Q72 79 62 76Z', 'url(#g)') + P('M88 68 Q82 64.5 83 59.5 Q86 60 88.5 53.5 Q91.5 60 94 60.5 Q94 65.5 88 68Z', 'url(#wg)')
      + feet(12, 89, 'url(#g)', 8.5, 5) + P('M50 21 Q80 21 80.5 54 Q82 88 50 88 Q18 88 19.5 54 Q20 21 50 21Z', 'url(#g)')
      + P('M37 64 Q50 58.5 63 64 Q65.5 84 50 86.5 Q34.5 84 37 64Z', '#fff4cc') + S('M38.5 69.5 Q50 66.5 61.5 69.5 M37.8 75.5 Q50 72.5 62.2 75.5 M39.6 81.2 Q50 78.4 60.4 81.2', '#e6d29a', 1)
      + PM('M25 34 Q18 29 16.5 20.5 Q22.5 23.5 27 29Z', '#c6adff') + P('M44 23 L47 15 L50 21.5 L53 15 L56 23Z', '#b090ff')
      + PM('M37 25.5 Q33 17 35.5 10.5 Q37.5 15 42.5 22.5Z', 'url(#hn)') + arms(30, 67, 30, 'url(#g)', 5, 8) }; };
// Jinni (replaced Wishling): a tiny genie floating out of a golden lamp - round teal head with pointy ears + gold drop earrings, puffy lilac turban (wrap folds, ruby jewel,
// feather plume), small round chest with a plum vest (gold trim) + gold sash, a smoky wisp tail swirling down into the spout of a golden oil lamp on the ground (no feet)
D.jinni = () => { const fc = face({ y: 38.5, dx: 8.6, r: 4.5, my: 46.5, cy: 44.5, cdx: 15, crx: 3.6, cry: 2.4, sh: [36.5, 31.5] }); fc.svg = fc.svg.replace(/fill="#ff8fa3" opacity="0.5"/g, 'fill="#ff8fa3" opacity="0.85"');
  const bz = (a, b, c, d, s) => [0, 1].map(k => (1 - s) ** 3 * a[k] + 3 * (1 - s) ** 2 * s * b[k] + 3 * (1 - s) * s * s * c[k] + s ** 3 * d[k]);
  const N = 24, Cs = [], L = [], Rr = []; for (let i = 0; i <= N; i++) Cs.push(bz([68.6, 79.2], [73.2, 70.8], [55, 79.5], [50, 66.5], i / N));
  Cs.forEach((p, i) => { const a = Cs[Math.max(0, i - 1)], b = Cs[Math.min(N, i + 1)], dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1, w = 1 + 7.4 * Math.pow(i / N, 1.25); L.push([p[0] - dy / l * w, p[1] + dx / l * w]); Rr.push([p[0] + dy / l * w, p[1] - dx / l * w]); });
  const tail = 'M' + L.map(p => f(p[0]) + ' ' + f(p[1])).join(' L') + ' L' + Rr.reverse().map(p => f(p[0]) + ' ' + f(p[1])).join(' L') + 'Z';
  const rd = (x, y, r) => `M${f(x)} ${f(y - r)} Q${f(x + r)} ${f(y - r)} ${f(x + r)} ${f(y)} Q${f(x + r)} ${f(y + r)} ${f(x)} ${f(y + r)} Q${f(x - r)} ${f(y + r)} ${f(x - r)} ${f(y)} Q${f(x - r)} ${f(y - r)} ${f(x)} ${f(y - r)}Z`;
  return { skin: '#5ed8c4', head: 20, defs: rg('g', '#dcfff6', '#5ed8c4', '#2a9e8c') + rg('tb', '#f6eaff', '#b48af2', '#7446c8') + rg('au', '#fff8cc', '#ffcf4a', '#c08a14') + rg('vs', '#d8a4ff', '#9a52e0', '#62239e') + lg('wp', '#5ed8c4', '#86e6d6', '#d4fbf3') + rg('rb', '#ffb0c0', '#ff3a6a', '#b0103a'), fc,
    extra: P('M30.2 41 Q31.8 43 30.2 45.4 Q28.6 43 30.2 41Z M69.8 41 Q71.4 43 69.8 45.4 Q68.2 43 69.8 41Z', 'url(#au)'),
    body: P('M41 91.6 L51 91.6 L53.2 95 L38.8 95Z', 'url(#au)') + S('M34.6 84.4 Q25 82.6 25.6 87.6 Q26.4 92 34.3 90.6', '#e0a426', 2.1)
      + P('M55 84.4 Q63 85.4 67.4 78.6 Q69.2 78.2 69.4 79.8 Q66 89 56 90.2Z', 'url(#au)') + P('M33 87.6 Q33 82.2 45 82.2 Q54 82.2 58.4 86.4 Q54 92.8 45 92.8 Q33 92.8 33 87.6Z', 'url(#au)')
      + P('M40.4 82.8 Q45 76.6 49.6 82.8Z', 'url(#au)') + P(rd(45, 77.2, 1.4), 'url(#au)') + P(rd(45, 87.4, 1.7), 'url(#rb)')
      + P(tail, 'url(#wp)')
      + E(50, 59.5, 13, 11.5, 'url(#g)') + PM('M38 52 Q40.6 50.8 43.2 53.8 Q45.6 62 45.2 70.6 Q40 70.8 37.8 66 Q36 59 38 52Z', 'url(#vs)') + SM('M43.2 53.8 Q45.6 62 45.2 70.6', '#ffcf4a', 0.9)
      + P('M37.6 65 Q50 69.4 62.4 65 L61.6 68.6 Q50 72.6 38.4 68.6Z', 'url(#au)')
      + PM('M31.2 38.5 Q24 35.5 21.6 29 Q27.6 30.4 32 34Z', 'url(#g)') + C(50, 36, 20, 'url(#g)')
      + P('M31 28 Q29.5 9.5 50 8.5 Q70.5 9.5 69 28 Q50 22.5 31 28Z', 'url(#tb)') + S('M32.4 24.6 Q47 15 66.6 19.4', '#8858d4', 1.3) + S('M33.6 18.6 Q52 21 68.4 25.4', '#8858d4', 1.3)
      + P('M51 21.5 Q57 12 55.4 3.6 Q52.6 9 49.4 20.8Z', '#f4ecff') + P(rd(50, 24.2, 3.1), 'url(#au)') + P(rd(50, 24.2, 1.8), 'url(#rb)')
      + arms(15.6, 58, 32, 'url(#g)', 4.4, 7.4) }; };
// ---------- Sweet Bakery ----------
D.cuppy = () => { const fc = face({ y: 64, dx: 9, r: 4.4, my: 71, cy: 70, cdx: 17, crx: 4, sh: [26, 42] });
  return { skin: '#a8ecd2', head: 14, defs: rg('fr', '#fff2fa', '#ffa8d6', '#e866aa') + rg('wr', '#e2fff4', '#a8ecd2', '#62c4a2') + cherryG, fc,
    body: feet(10, 90, '#62c4a2', 7, 4) + arms(36, 68, 20, 'url(#wr)', 4, 7) + P('M18 54 H82 L76 88 Q50 92 24 88Z', 'url(#wr)') + S('M33 76 L34 89 M42 77 L42.5 90 M58 77 L57.5 90 M67 76 L66 89 M24 60 L27 86 M76 60 L73 86', '#5ab894', 1, { opacity: 0.7 })
      + P('M12 54 Q10 43 22 41 Q30 33 50 35 Q70 33 78 41 Q90 43 88 54 Q86 61 76 58 Q64 62 50 59 Q36 62 24 58 Q14 61 12 54Z', 'url(#fr)')
      + P('M24 40 Q22 30 34 28 Q42 20 54 24 Q68 22 72 32 Q80 36 74 42 Q62 46 50 44 Q36 46 24 40Z', 'url(#fr)') + P('M38 26 Q38 16 48 14 Q52 8 56 14 Q64 16 62 26 Q50 30 38 26Z', 'url(#fr)')
      + S('M34 47 l2.4 -1 M62 40 l2.2 1.2 M45 31 l1.6 -1.8', '#7cc8ff', 1.4) + S('M54 50 l2.2 0.8 M30 38 l1.8 -1.6 M66 50 l2 -1', '#ffe14a', 1.4) + S('M42 52 l-2 -1 M58 30 l2 -0.8 M74 46 l1.6 1.6', '#9be38a', 1.4)
      + C(52, 10, 4, 'url(#ch)') + S('M52 7 Q53 2 57 1', '#5a8a34', 1.1) }; };
D.chip = () => { const fc = face({ y: 56, my: 63, cy: 62, cdx: 20, sh: [28, 40] });
  const chip = (x, y, s) => `M${f(x - s)} ${f(y + s * 0.6)} Q${f(x - s)} ${f(y - s)} ${f(x)} ${f(y - s)} Q${f(x + s)} ${f(y - s)} ${f(x + s)} ${f(y + s * 0.6)} Q${f(x)} ${f(y + s * 1.1)} ${f(x - s)} ${f(y + s * 0.6)}Z`;
  const chips = [[34, 36, 3.2], [55, 31, 2.8], [70, 42, 3.4], [26, 52, 2.6], [75, 66, 3], [30, 74, 3.2], [46, 81, 2.8], [62, 79, 3.2], [44, 41, 2.2], [66, 30, 2]].map(([x, y, s]) => chip(x, y, s)).join(' ');
  return { skin: '#ebb062', head: 26, defs: rg('g', '#ffe8b8', '#ebb062', '#c0803a'), fc,
    body: feet(12, 89, 'url(#g)', 7.5, 4.5) + arms(36, 64, 30, 'url(#g)', 4.8, 7.5) + P(fluffy(50, 58, 34, 32, 14, 0.04), 'url(#g)') + P(chips, '#6a3a22') + P(dots([[40, 30, 0.6], [60, 70, 0.6], [24, 64, 0.5], [70, 54, 0.6]]), '#c8843e') }; };
D.twisty = () => { const fc = face({ y: 74, dx: 9, r: 4.2, my: 81, cy: 80, cdx: 17, crx: 3.6, cry: 2.3, sh: [33, 69] });
  // a real pretzel: one rope - the thick belly arc at the bottom (face on it), both ends rise up the sides, loop over the top, twist round each other in the middle and rest on the belly (scaled x0.86 about 50,84)
  const K = 0.86, sx = x => f(50 + (x - 50) * K), sy = y => f(84 + (y - 84) * K), sc = d => { let i = 0; return d.replace(/-?[\d.]+/g, v => (i++ % 2 ? sy(+v) : sx(+v))); };
  const SA = sc('M61 64 C56 54 46 42 42 32 C38 20 28 14 20 19 C12 24 11 40 14 53.5 Q15.4 58 17 60'), SB = mx(SA);
  const Qp = (t, i) => (1 - t) * (1 - t) * [17, 60][i] + 2 * (1 - t) * t * [50, 100][i] + t * t * [83, 60][i], bo = [], bi = [];
  for (let k = 0; k <= 28; k++) { const t = k / 28, x = Qp(t, 0), y = Qp(t, 1), tx = 2 * ((1 - t) * 33 + t * 33), ty = 2 * ((1 - t) * 40 - t * 40), l = Math.hypot(tx, ty), w = 6.5 + 5.5 * Math.sin(Math.PI * t); bo.push([x + ty / l * w, y - tx / l * w]); bi.push([x - ty / l * w, y + tx / l * w]); }
  const belly = 'M' + bi.concat(bo.slice().reverse()).map(p => sx(p[0]) + ' ' + sy(p[1])).join(' L') + 'Z';
  const rope = d => S(d, '#8e4c1c', 12 * K) + S(d, 'url(#g)', 10.4 * K, { transform: 'translate(-0.4 -0.5)' }) + S(d, '#ffe0b0', 4 * K, { transform: 'translate(-1.6 -1.9)', opacity: 0.3 });
  const salt = [[24, 22], [34, 18], [14, 38], [76, 22], [66, 18], [86, 38], [44, 36], [57, 40], [27, 72], [73, 72], [36, 87], [64, 87], [50, 92]].map(([x, y]) => `M${sx(x)} ${f(sy(y) - 1)} l0.9 1 l-0.9 1 l-0.9 -1Z`).join(' ');
  return { skin: '#c47a38', head: 23, defs: rg('g', '#fbcf92', '#cf8a44', '#93501e'), fc,
    body: feet(10, 91, 'url(#g)', 7, 4) + arms(36, 73, 28, 'url(#g)', 4.2, 6.8) + P(belly, 'url(#g)') + rope(SB) + rope(SA) + P(salt, '#ffffff', { opacity: 0.95 }) }; };
D.crois = () => { const fc = face({ y: 56, dx: 8.5, r: 4.3, my: 63, cy: 62, cdx: 14, crx: 3.8, cry: 2.4, sh: [41, 38] });
  return { skin: '#f2aa52', head: 28, defs: rg('g', '#ffe8ae', '#f2aa52', '#c8782a') + rg('d', '#ffdc96', '#e8983e', '#b8681e'), fc,
    body: feet(10, 88, 'url(#d)', 6, 3.8) + PM('M8 70 Q8 56 20 54 Q26 64 22 76 Q12 78 8 70Z', 'url(#d)') + PM('M18 52 Q26 38 38 42 Q42 60 36 80 Q22 82 18 70 Q14 60 18 52Z', 'url(#g)')
      + SMc('M26 48 Q30 60 28 74', '#c8782a', 0.9, { opacity: 0.5 }) + P('M32 54 Q32 28 50 28 Q68 28 68 54 Q68 86 50 86 Q32 86 32 54Z', 'url(#g)') + S('M38 36 Q50 31 62 36 M36 78 Q50 83 64 78', '#d88a3a', 1, { opacity: 0.6 }) + arms(17, 68, 25, 'url(#g)', 4.2, 6.8) }; };
D.maca = () => { const fc = face({ y: 40, dx: 11, r: 4.8, my: 47, cy: 46, cdx: 22, sh: [26, 30] });
  return { skin: '#9ee8c4', head: 20, defs: rg('g', '#e8fff4', '#9ee8c4', '#56be92') + rg('fi', '#ffffff', '#fff6e6', '#f0e0c4'), fc,
    body: feet(12, 90, 'url(#g)', 7, 4) + P('M14 66 Q14 62 50 62 Q86 62 86 66 Q86 88 50 88 Q14 88 14 66Z', 'url(#g)') + P(ruffle(14, 86, 64, 3, 14, 2.4), '#7cd2ac')
      + arms(37, 64, 60, 'url(#fi)', 4, 6.5) + P('M13 58 Q50 54 87 58 Q89 63 87 66 Q50 70 13 66 Q11 63 13 58Z', 'url(#fi)')
      + P('M12 54 Q12 20 50 20 Q88 20 88 54 Q88 60 50 60 Q12 60 12 54Z', 'url(#g)') + P(ruffle(13, 87, 54, 3, 14, 2.4), '#7cd2ac') }; };
D.puddi = () => { const fc = face({ y: 60, my: 67, cy: 66, cdx: 19, sh: [30, 54] });
  return { skin: '#ffd870', head: 30, defs: rg('g', '#fffad0', '#ffd870', '#eaa830') + lg('cr', '#eca456', '#a85a1a') + cherryG, fc,
    body: P('M8 86 Q8 82 50 82 Q92 82 92 86 Q92 92 50 92 Q8 92 8 86Z', '#eef4ff', { stroke: '#cddcf2', 'stroke-width': 0.8 }) + arms(36, 66, 25, 'url(#g)', 4.5, 7)
      + P('M24 38 Q50 32 76 38 Q80 60 84 78 Q84 86 50 86 Q16 86 16 78 Q20 60 24 38Z', 'url(#g)')
      + P('M24 38 Q50 30 76 38 Q77 44 75 48 Q73 52 71 46 Q66 50 62 46 Q60 56 56 47 Q50 51 45 47 Q42 54 38 46 Q34 50 30 46 Q27 52 25 45 Q23 42 24 38Z', 'url(#cr)')
      + P('M40 34 Q38 26 46 26 Q48 18 54 22 Q62 22 60 30 Q62 36 50 36 Q40 37 40 34Z', '#fffaf2') + C(52, 18, 4, 'url(#ch)') + S('M52 15 Q53 10 57 9', '#5a8a34', 1.1) }; };
D.mochi = () => { const fc = face({ y: 62, my: 69, cy: 68, cdx: 20, sh: [28, 50] });
  return { skin: '#fff4f6', head: 20, defs: rg('g', '#ffffff', '#fff4f6', '#ecd2da') + rg('st', '#ffb4bc', '#ff4a62', '#d01e3c') + leafG, fc,
    body: P('M38 42 Q36 22 50 20 Q64 22 62 42Z', 'url(#st)') + P(dots([[44, 28, 0.6], [56, 28, 0.6], [50, 33, 0.6], [43, 36, 0.6], [57, 36, 0.6]]), '#ffe58a')
      + P('M50 22 Q42 14 36 18 Q44 22 50 22Z M50 22 Q58 14 64 18 Q56 22 50 22Z M50 22 Q48 14 50 10 Q52 14 50 22Z', 'url(#l)')
      + feet(11, 89, 'url(#g)', 7.5, 4.5) + arms(36, 68, 30, 'url(#g)', 4.8, 7.5) + P('M14 66 Q14 36 50 36 Q86 36 86 66 Q86 90 50 90 Q14 90 14 66Z', 'url(#g)')
      + E(50, 41, 14, 4.6, '#ffc6d2', { opacity: 0.55 }) + P(dots([[30, 48], [70, 50], [24, 70], [76, 72], [40, 84], [62, 84], [50, 44]], 0.6), '#f0dde4') }; };
D.cakey = () => { const fc = face({ y: 55, r: 4.6, my: 62, cy: 61, cdx: 18, crx: 4.2, sh: [30, 48] });
  const drips = (x0, x1, y, n) => { let d = `M${x0} ${y} H${x1} V${y + 3}`; const st = (x1 - x0) / n; for (let i = 0; i < n; i++) { const x = x1 - st * i; d += ` Q${f(x - st * 0.25)} ${f(y + (i % 2 ? 6 : 4))} ${f(x - st * 0.5)} ${f(y + 3)} Q${f(x - st * 0.75)} ${f(y + 2)} ${f(x - st)} ${f(y + 3)}`; } return d + 'Z'; };
  const candle = x => R(x - 1.8, 13, 3.6, 14, 1, '#ffd0f0') + S(`M${x - 1.8} 17 l3.6 -2 M${x - 1.8} 21 l3.6 -2 M${x - 1.8} 25 l3.6 -2`, '#ff8fc8', 0.9) + P(`M${x} 6 Q${x + 2.6} 10 ${x} 12.5 Q${x - 2.6} 10 ${x} 6Z`, '#ffd24a') + P(`M${x} 8.6 Q${x + 1.1} 10.4 ${x} 11.6 Q${x - 1.1} 10.4 ${x} 8.6Z`, '#ff8a2a');
  return { skin: '#fff0dc', head: 26, defs: rg('t1', '#ffe6f2', '#ffb0d0', '#e878a8') + rg('t2', '#fffcf4', '#fff0dc', '#e8d0b0') + rg('t3', '#e6fff4', '#a0ecd0', '#5ac8a0'), fc,
    body: arms(31, 58, 25, 'url(#t2)', 4, 6.5) + P('M12 74 Q12 70 16 70 H84 Q88 70 88 74 V86 Q88 90 84 90 H16 Q12 90 12 86Z', 'url(#t1)') + P(drips(12, 88, 70, 10), '#fff6fa')
      + S('M20 82 l2 -1 M34 84 l2 1 M66 84 l-2 1 M80 82 l-2 -1', '#7cc8ff', 1.3) + S('M27 86 l1.6 -1.4 M50 86 l2 0 M73 86 l-1.6 -1.4', '#ffe14a', 1.3)
      + P('M22 46 Q22 42 26 42 H74 Q78 42 78 46 V70 H22Z', 'url(#t2)') + P(drips(22, 78, 42, 8), '#ffb0d0')
      + P('M32 28 Q32 26 34 26 H66 Q68 26 68 28 V42 H32Z', 'url(#t3)') + P(drips(32, 68, 26, 6), '#fff6fa') + candle(40) + candle(50) + candle(60) }; };
D.sugarplum = () => { const fc = face({ y: 46, dx: 8.5, r: 4.3, my: 53, cy: 52, cdx: 14, crx: 4, sh: [38, 34] });
  return { skin: '#ffd6c4', head: 13, defs: rg('g', '#fff2ea', '#ffd6c4', '#f0ae94') + rg('h', '#eed8ff', '#b47ae6', '#7a40b0') + rg('dr', '#ead0ff', '#a060e0', '#6a30b0') + lg('gd', '#fff4b0', '#ffd23a', '#e09a10'), fc,
    body: feet(8, 90, '#6a30b0', 6, 3.6) + P('M34 64 Q28 80 24 88 Q50 94 76 88 Q72 80 66 64Z', 'url(#dr)') + P('M40 68 Q38 80 40 88 Q50 90 60 88 Q62 80 60 68Z', '#fffaf6')
      + P('M50 82 Q44 76 47 73.6 Q50 72.6 50 75.6 Q50 72.6 53 73.6 Q56 76 50 82Z', '#ff8fc0') + E(50, 64, 12, 7, 'url(#dr)') + arms(15, 68, 25, 'url(#g)', 3.8, 6.5)
      + P('M28 46 Q26 20 50 20 Q74 20 72 46 Q72 58 64 60 L36 60 Q28 58 28 46Z', 'url(#h)') + C(30, 26, 7, 'url(#h)') + C(70, 26, 7, 'url(#h)') + C(50, 44, 19, 'url(#g)')
      + P('M31 40 Q32 26 50 25 Q68 26 69 40 Q62 32 55 36 Q50 30 44 35 Q38 32 31 40Z', 'url(#h)')
      + P('M40 24 L42 15 L46 20.5 L50 12 L54 20.5 L58 15 L60 24 Q50 27 40 24Z', 'url(#gd)', { stroke: '#ffffff', 'stroke-width': 0.7 }) + C(50, 17, 1.5, '#ff6aa8') }; };
D.chefbun = () => { const fc = face({ y: 62, my: 69, cy: 68, cdx: 21, sh: [26, 52] });
  return { skin: '#fff4e6', head: 36, defs: rg('g', '#ffffff', '#fff4e6', '#e9d3b6') + rg('hat', '#ffffff', '#f6f6fc', '#d6d6e6'), fc,
    body: feet(13, 89, 'url(#g)', 8, 4.5) + P('M12 70 Q10 40 50 36 Q90 40 88 70 Q88 86 50 86 Q12 86 12 70Z', 'url(#g)') + P('M36 80 Q50 86 64 80 L58 91 L50 85 L42 91Z', '#ff5c6a')
      + arms(37, 70, 30, 'url(#g)', 5, 8) + P('M30 32 Q20 30 22 20 Q24 10 36 12 Q40 2 52 4 Q64 2 66 12 Q78 10 78 20 Q80 30 70 32 Q50 28 30 32Z', 'url(#hat)')
      + P('M30 42 Q50 36 70 42 L70 32 Q50 28 30 32Z', 'url(#hat)', { stroke: '#e0e0ee', 'stroke-width': 0.8 }) + S('M42 18 Q46 26 44 31 M56 18 Q54 26 56 31', '#e0e0ee', 0.9) }; };
// ---------- Spooky Squish ----------
D.gourdy = () => { const fc = face({ y: 58, dx: 9.5, r: 4.6, my: 65, cy: 64, cdx: 17, crx: 4.2, sh: [34, 40] });
  return { skin: '#ff9a3a', head: 26, defs: rg('g', '#ffd494', '#ff9a3a', '#e2680e') + rg('d', '#ffc282', '#f58a2a', '#d05a08') + leafG, fc,
    body: S('M52 16 Q60 9 64 15 Q66 21 60 21 Q56 19 59 16.5', '#5a9a34', 1.4) + P('M44 22 Q34 14 27 20 Q36 27 44 22Z', 'url(#l)') + P('M47 27 Q46 16 52 12 Q55 14 53 27Z', '#6a8a34')
      + feet(12, 89, '#d05a08', 7, 4) + arms(38, 66, 30, 'url(#d)', 4.5, 7) + PMc('M30 34 Q10 36 10 60 Q10 86 34 86 Q24 60 30 34Z', 'url(#d)')
      + P('M50 26 Q76 26 80 56 Q82 88 50 88 Q18 88 20 56 Q24 26 50 26Z', 'url(#g)') + S('M37 30 Q29 58 37 86 M63 30 Q71 58 63 86', '#e07a20', 1.2, { opacity: 0.55 }) }; };
D.batty = () => { const fc = face({ y: 55, r: 4.8, my: 62, cy: 61, cdx: 18, crx: 4.2, sh: [34, 42] });
  return { skin: '#9a74e2', head: 31, defs: rg('g', '#e4d4ff', '#9a74e2', '#6a42b2') + rg('wg', '#ac8cea', '#7a52c8', '#4e2c96'), fc, extra: P('M46.6 63.3 l1.2 2.4 l1.2 -2.4Z M51 63.3 l1.2 2.4 l1.2 -2.4Z', '#ffffff'),
    body: PM('M28 52 Q14 38 4 44 Q8 50 6 56 Q12 56 12 62 Q18 60 20 66 Q26 62 30 64Z', 'url(#wg)') + PM('M32 36 Q26 20 30 12 Q40 20 42 32Z', 'url(#g)') + PM('M33 32 Q29 22 31 17 Q37 22 39 31Z', '#ffb8d8')
      + feet(9, 88, '#4e2c96', 5, 3.2) + C(50, 58, 27, 'url(#g)') + E(50, 69, 15, 11, '#ece0ff') + P('M46 32 Q48 26 50 30 Q52 26 54 32Z', '#9a74e2') }; };
D.kernel = () => { const fc = face({ y: 54, dx: 8.5, r: 4.3, my: 61, cy: 60, cdx: 15, crx: 3.8, cry: 2.4, sh: [42, 28] });
  const B = 'M50 12 Q58 12 66 30 Q80 60 82 76 Q84 90 50 90 Q16 90 18 76 Q20 60 34 30 Q42 12 50 12Z';
  return { skin: '#ff9a3a', head: 12, defs: rg('w', '#ffffff', '#fff8ec', '#e8dcc8') + rg('o', '#ffcc92', '#ff9a3a', '#e2680e') + rg('y', '#fff4a6', '#ffd84a', '#f0b020') + `<clipPath id="c"><path d="${B}"/></clipPath>`, fc,
    body: feet(10, 89, 'url(#y)', 7, 4) + arms(34, 66, 20, 'url(#o)', 4, 6.5) + `<g clip-path="url(#c)">${R(10, 8, 80, 34, 0, 'url(#w)')}${R(10, 40, 80, 30, 0, 'url(#o)')}${R(10, 68, 80, 26, 0, 'url(#y)')}</g>` }; };
D.hexie = () => { const fc = face({ y: 52, r: 4.8, my: 61, cy: 58, cdx: 18, crx: 4.2, mouth: wMouth, sh: [32, 46] });
  return { skin: '#9a84cc', head: 28, defs: rg('g', '#d8c8f2', '#9a84cc', '#68509e') + rg('hat', '#a272e2', '#6a3ab0', '#3e1a78'), fc,
    extra: P('M48.6 57.5 L51.4 57.5 L50 59Z', '#ff8fa3') + S('M38 60 L28 58 M38 62 L28 63.5 M62 60 L72 58 M62 62 L72 63.5', '#4e3a80', 0.8),
    body: P('M68 82 Q90 84 88 64 Q86 54 92 50 Q84 48 82 60 Q82 72 66 76Z', 'url(#g)') + feet(10, 89, 'url(#g)', 7, 4.5) + E(50, 77, 20, 13, 'url(#g)') + arms(20.5, 74, 26, 'url(#g)', 4.5, 7)
      + PM('M24 44 Q14 30 20 24 Q30 30 36 38Z', 'url(#g)') + PM('M24.5 40 Q18 31 21.5 27.5 Q28 32 32 37Z', '#ffb8d4') + C(50, 52, 24, 'url(#g)') + E(50, 60, 10, 6, '#ece4fa')
      + P('M30 32 Q34 14 46 8 Q56 2 66 10 Q72 14 78 12 Q74 20 66 18 Q64 24 70 32 Q50 26 30 32Z', 'url(#hat)') + P('M31 30 Q50 25 69 30 L70 33 Q50 28 30 33Z', '#ffb03a')
      + P('M16 34 Q50 24 84 34 Q84 40 50 34 Q16 40 16 34Z', 'url(#hat)') + P(star5(79, 13, 3.2, 1.4), '#ffe14a') }; };
D.mumbles = () => { const fc = face({ y: 50, r: 4.6, my: 57, cy: 56, cdx: 18, crx: 4.2, sh: [32, 40] });
  return { skin: '#f2ead8', head: 26, defs: rg('g', '#fffcf4', '#f2ead8', '#d4c6a8'), fc,
    body: PM('M40 30 Q32 10 36 4 Q44 8 46 28Z', 'url(#g)') + SMc('M36.5 10 L43 12 M38 18 L44.5 19 M39.5 25 L45.5 25', '#d8cba8', 1.4) + feet(11, 89, 'url(#g)', 7.5, 4.5) + E(50, 76, 19, 13, 'url(#g)')
      + arms(19.5, 73, 26, 'url(#g)', 5, 7.5) + C(50, 50, 24, 'url(#g)') + S('M27 38 Q50 30 73 36 M29 44 L42 40.5 M33 72 Q50 78 67 70 M33 80 Q50 86 67 80 M27 60 Q34 64 40 63', '#ddd0b2', 2.2, { opacity: 0.9 })
      + S('M72 70 Q84 74 86 84', '#e6dac0', 2.6) }; };
D.hocus = () => { const fc = face({ y: 52, r: 5, my: 62.5, mw: 3.4, cy: 59, cdx: 19, crx: 4.2, sh: [27, 46] });
  return { skin: '#f6f0ff', head: 26, defs: rg('g', '#e6dcff', '#a492e0', '#6e5aae') + rg('hat', '#7e6ee2', '#4a36b0', '#281a70') + lg('bk', '#ff8ad0', '#b02a8a'), fc,
    extra: P('M48 57.2 L52 57.2 L50 61Z', '#ffb03a') + P(star4(38, 66, 2) + ' ' + star4(63, 64, 1.6) + ' ' + star4(50, 62.5, 1.2), '#fff6a0'),
    body: feet(9, 90, '#ffa040', 6, 3.6) + P('M50 26 Q80 26 82 56 Q84 90 50 90 Q16 90 18 56 Q20 26 50 26Z', 'url(#g)') + E(40, 52, 11, 10, '#f6f0ff') + E(60, 52, 11, 10, '#f6f0ff')
      + C(50, 72, 13, '#fff6a0', { opacity: 0.5 }) + P('M28 74 L50 76 L72 74 L72 86 L50 88 L28 86Z', 'url(#bk)') + P('M30 72 Q40 68 50 72 Q60 68 70 72 L70 84 Q60 80 50 84 Q40 80 30 84Z', '#fffaf0')
      + S('M50 72 V84 M34 75 Q40 73 46 75 M34 79 Q40 77 46 79 M54 75 Q60 73 66 75', '#e0d0b0', 0.7) + arms(28, 72, 40, 'url(#g)', 5.5, 9)
      + P('M20 32 Q50 24 80 32 Q80 37 50 32 Q20 37 20 32Z', 'url(#hat)') + P('M32 31 Q40 18 52 4 Q56 12 58 18 Q64 26 68 31 Q50 27 32 31Z', 'url(#hat)')
      + P(star5(46, 22, 2.6, 1.1) + ' ' + star5(60, 27, 1.8, 0.8), '#ffe14a') + P('M54 12 a3.2 3.2 0 1 0 3.4 4.4 a2.5 2.5 0 1 1 -3.4 -4.4Z', '#ffe14a') }; };
D.countsquishula = () => { const fc = face({ y: 45, dx: 8.5, r: 4.4, my: 51.5, cy: 50, cdx: 15, crx: 4, sh: [36, 32] });
  return { skin: '#e4dcf8', head: 20, defs: rg('g', '#fbf8ff', '#e4dcf8', '#b8aae0') + rg('hr', '#6e5e8e', '#3a2a5a', '#1e1236') + rg('cp', '#5e4e7e', '#2e2048', '#160c28') + lg('rd', '#ff6a7a', '#b81e3a'), fc,
    extra: P('M46.9 52.4 l1.1 2.6 l1.1 -2.6Z M50.9 52.4 l1.1 2.6 l1.1 -2.6Z', '#ffffff'),
    body: PM('M32 58 Q16 42 13 22 Q26 34 38 42Z', 'url(#rd)', { stroke: '#2e2048', 'stroke-width': 1.4 }) + P('M26 60 Q18 76 14 90 Q50 96 86 90 Q82 76 74 60Z', 'url(#cp)')
      + P('M38 62 Q36 78 34 90 L66 90 Q64 78 62 62Z', 'url(#rd)') + P('M42 62 Q42 80 44 90 L56 90 Q58 80 58 62Z', '#f6f0ff') + C(50, 69, 4, '#ffd23a') + C(50, 69, 2.8, '#ff4a6a')
      + feet(7, 91, '#2e2048', 5, 3) + arms(22, 72, 15, 'url(#cp)', 5, 9) + C(50, 44, 22, 'url(#g)') + PM('M29 46 Q20 40 20 34 Q26 38 31 42Z', 'url(#g)')
      + P('M28 40 Q28 20 50 20 Q72 20 72 40 Q66 30 56 30 L50 38 L44 30 Q34 30 28 40Z', 'url(#hr)') }; };

// ---------- Masked Heroes ----------
D.wisecrack = () => { const fc = face({ y: 44, dx: 10.5, r: 3.6, my: 56.5, cy: 55, cdx: 18, crx: 4, cry: 2.4, sh: [33, 24], mouth: (cx, my) => S(`M${f(cx - 4)} ${f(my)} q3.5 2.8 8 -1.2`, '#6a3a3a', 1.3) });
  return { skin: '#e2263a', head: 14, defs: rg('g', '#ff8a94', '#e2263a', '#9c0f22') + rg('dk', '#6a5a6a', '#2e222f', '#140c16') + rg('gd', '#fff2a8', '#ffc83a', '#d08a10') + lg('sw', '#a8aec2', '#5a6078'), fc,
    extra: E(39.5, 44, 6.6, 5.6, '#ffffff') + E(60.5, 44, 6.6, 5.6, '#ffffff'),
    body: PMc('M28.8 33 L15.1 6.9 Q11.8 5.8 10.9 9.1 L24.6 35.2Z', 'url(#dk)') + SMc('M21.2 18.9 L17.4 20.9 M19.8 16.3 L16 18.3 M18.4 13.6 L14.6 15.6', '#7a7088', 0.9) + PMc('M25.2 19.5 L26.7 22.4 L17 27.5 L15.5 24.6Z', 'url(#sw)')
      + feet(12, 89, 'url(#dk)', 7.5, 4.5) + arms(33, 64, 30, 'url(#dk)', 5, 8)
      + P('M50 14 Q80 14 82 46 Q84 72 74 84 Q64 91 50 91 Q36 91 26 84 Q16 72 18 46 Q20 14 50 14Z', 'url(#g)')
      + PMc('M19.5 58 Q19 74 28 85 Q33 74 30.5 59 Q25 56 19.5 58Z', 'url(#dk)')
      + PMc('M26.5 41 Q29 33.5 40 35.5 Q48.5 38 48 45.5 Q47 52.5 38.5 52 Q28 51 26.5 41Z', 'url(#dk)')
      + S('M50 15.5 Q51.2 25 50 35', '#8a0e1e', 1, { opacity: 0.55 })
      + P('M19.4 67 Q50 73.5 80.6 67 L80.4 74.5 Q50 81 19.6 74.5Z', '#2a1620') + C(50, 74.5, 5.4, 'url(#gd)') + P(star5(50, 74.7, 3, 1.3), '#e2263a') }; };

// ---------- Elemental Heroes (chibi hero build: big round head, V-taper torso, short legs + boots) ----------
D.gigagrowth = () => { const fc = face({ y: 35.5, dx: 7.5, r: 3.4, my: 43, cy: 41.5, cdx: 11, crx: 3, cry: 1.9, sh: [43, 25] });
  return { skin: '#8fa476', head: 18, defs: rg('g', '#cfdcae', '#8fa476', '#55704a') + rg('st', '#b9c69c', '#7a8f66', '#46603e') + rg('ms', '#d2f7a0', '#74c44c', '#3a8a34') + rg('cy', '#e6fffb', '#5ff0d6', '#1fa89a') + leafG, fc,
    body: feet(9, 89, 'url(#st)', 8, 4.8) + arms(28, 67, 16, 'url(#st)', 7, 11)
      + P('M24 60 Q23 50 36 49 L64 49 Q77 50 76 60 Q75 70 65 77 L64 86 Q50 89 36 86 L35 77 Q25 70 24 60Z', 'url(#g)')
      + S('M38 60 Q44 64 50 60 Q56 64 62 60', '#5f7550', 1.3, { opacity: 0.7 }) + S('M50 65 L50 79 M44 70 L56 70 M44.5 76 L55.5 76', '#5f7550', 1, { opacity: 0.45 })
      + S('M28 56 Q36 66 40 79 Q41 84 39 87', '#6e4a2a', 2.2) + S('M72 56 Q64 66 60 79 Q59 84 61 87', '#6e4a2a', 2.2)
      + P(fluffy(32, 51, 9, 4.6, 9, 0.14) + ' ' + fluffy(68, 51, 9, 4.6, 9, 0.14), 'url(#ms)') + C(29, 49, 1.1, '#ff8fd0') + C(71, 50, 1.1, '#7cc8ff')
      + P('M27 48 L30 40 L33 48 L30 50.5Z M67 48 L70 40 L73 48 L70 50.5Z', 'url(#cy)')
      + C(50, 34, 16.5, 'url(#g)') + P(fluffy(50, 20.5, 15, 5.6, 10, 0.12), 'url(#ms)') + C(42, 18, 1.1, '#ff8fd0') + C(57, 17.5, 1, '#fff27a') + C(62, 21, 1, '#7cc8ff')
      + S('M44 15.5 Q42 10.5 39 7.5', '#5f9a4a', 1.5) + P(lens(37.5, 7, -30, 6.5, 2.2), 'url(#l)') + S('M57 15.5 Q59 10.5 62 7.5', '#5f9a4a', 1.5) + P(lens(63.5, 6.5, 25, 6.5, 2.2), 'url(#l)'),
    extra: PM('M38.5 30.2 Q43 27.4 47.6 30.4 L47.1 32 Q43 29.7 39 31.8Z', '#4e6844') }; };
D.crystalline = () => { const fc = face({ y: 36, dx: 7.5, r: 3.5, my: 43.5, cy: 42, cdx: 11, crx: 3, cry: 1.9, sh: [42, 22] });
  return { skin: '#ffdde6', head: 18, defs: rg('g', '#fdf8ff', '#e6d6fb', '#b498e6') + rg('sk', '#fff6f8', '#ffdde6', '#efb0c2') + rg('hr', '#f8f2ff', '#d4c2f6', '#9a80d8') + lg('cr', '#ffffff', '#c8b4ff', '#8fd8ff') + lg('cp', '#ffe6f6', '#ff9ad6', '#c070ff') + rg('gm', '#ffd6f0', '#ff6ac2', '#c02b8a') + rg('cb', '#e8fbff', '#a8d8ff', '#7a8ae0'), fc,
    body: feet(7, 89, 'url(#cb)', 6, 4) + arms(19, 64.5, 22, 'url(#g)', 4.2, 8.5)
      + P('M31 38 Q30 18 50 16 Q70 18 69 38 Q70 50 64 55 L36 55 Q30 50 31 38Z', 'url(#hr)')
      + P('M35 57 Q35 51 42 51 L58 51 Q65 51 65 57 Q65 66 59 73 Q62 80 60 86 L40 86 Q38 80 41 73 Q35 66 35 57Z', 'url(#g)')
      + P('M42 58 L49 64 L45 71Z M58 58 L51 64 L55 71Z M44 79 L50 76 L56 79 L50 84Z', '#ffffff', { opacity: 0.4 })
      + P('M40.6 73 Q50 75 59.4 73 L59.7 75.4 Q50 77.4 40.3 75.4Z', '#c8b4ff')
      + P('M50 56.5 L54 61.5 L50 67 L46 61.5Z', 'url(#gm)') + P('M50 58 L52.2 61.4 L50 62.6Z', '#ffffff', { opacity: 0.7 })
      + PMc('M37 54 L27 45 L31.5 56Z', 'url(#cr)') + PMc('M37.5 57.5 L28 55.5 L34 61.5Z', 'url(#cp)')
      + C(50, 34.5, 15.5, 'url(#sk)') + P('M34.2 32.5 Q36 19 50 19 Q64 19 65.8 32.5 Q60 25 54.5 26 L50 30.5 L45.5 26 Q40 25 34.2 32.5Z', 'url(#hr)')
      + P('M50 3 L54 12 L50 19.5 L46 12Z', 'url(#cr)') + P('M42 8.5 L45 15 L42 20.5 L39 15Z M58 8.5 L61 15 L58 20.5 L55 15Z', 'url(#cp)') + P('M35 14 L37.6 18.5 L35 22.5 L32.6 18.5Z M65 14 L67.4 18.5 L65 22.5 L62.6 18.5Z', 'url(#cr)')
      + P('M50 5 L52.2 11.6 L50 13.6Z', '#ffffff', { opacity: 0.8 }) }; };
D.aeroswift = () => { const fc = face({ y: 33.5, dx: 7.5, r: 3.3, my: 44, cy: 42.5, cdx: 10.5, crx: 2.6, cry: 1.7, sh: [41, 22] });
  return { skin: '#ffe0d2', head: 18, defs: rg('g', '#ffffff', '#d9e0ea', '#98a4b8') + rg('sk', '#fff4ee', '#ffe0d2', '#eab4a0') + rg('nv', '#4a5a86', '#26325a', '#141c38') + lg('bl', '#9ae6ff', '#2fb0ee', '#1a6ac0') + lg('wg', '#f0fdff', '#a8ecff', '#4ac2f0') + lg('vz', '#c8f8ff', '#38d6ff', '#1a9be0'), fc,
    body: PM('M39 58 Q20 47 13 30 Q26 40 41 52Z', 'url(#wg)') + PM('M39 63 Q22 61 14 50 Q27 55 41 58Z', 'url(#wg)')
      + feet(7, 89, 'url(#bl)', 6, 4) + arms(19, 64.5, 24, 'url(#bl)', 4.3, 8.5)
      + P('M34 57 Q34 51 42 51 L58 51 Q66 51 66 57 Q66 67 60 74 Q62 80 60 86 L40 86 Q38 80 40 74 Q34 67 34 57Z', 'url(#g)')
      + PMc('M34.6 60 Q36 68 40 74 L41.4 86 L45.6 86 L44.6 72 Q39.4 66 38.6 56Z', 'url(#nv)')
      + P('M40.5 54.5 L50 68 L59.5 54.5 L55.5 54.5 L50 62 L44.5 54.5Z', 'url(#bl)') + C(50, 71, 1.7, '#5ad8ff')
      + P('M40 74 Q50 76 60 74 L60.2 76.6 Q50 78.6 39.8 76.6Z', 'url(#nv)')
      + C(50, 34, 16.5, 'url(#g)') + P('M36 38 Q37 50 50 51 Q63 50 64 38 Q57 41.5 50 41.5 Q43 41.5 36 38Z', 'url(#sk)')
      + PM('M37 23.5 Q28.5 13.5 30.5 5.5 Q35 15 41 19.5Z', 'url(#wg)') + P('M47.5 17.5 Q50 8 52.5 17.5 L51.5 22 L48.5 22Z', 'url(#bl)'),
    extra: P('M34.6 30.5 Q50 24.8 65.4 30.5 Q66.4 37 59 39.2 Q50 36.2 41 39.2 Q33.6 37 34.6 30.5Z', 'url(#vz)', { opacity: 0.86 }) + P('M37.5 30.4 Q50 26.4 62.5 30.4 Q50 28 37.5 30.4Z', '#ffffff', { opacity: 0.6 }) }; };
D.phantasm = () => { const fc = { svg: '', data: { eyes: [{ x: 44, y: 37.5, r: 3.2 }, { x: 56, y: 37.5, r: 3.2 }], mouth: { x: 50, y: 45, w: 7 }, cheeks: [{ x: 38, y: 44 }, { x: 62, y: 44 }] } };
  const stars = [[38, 62], [62, 66], [40, 80], [60, 82], [35, 74], [65, 76], [47, 84], [56, 72]].map(([x, y], i) => C(x, y, i % 3 ? 0.55 : 0.85, '#ffffff', { opacity: 0.85 })).join('');
  return { skin: '#4a2a9a', head: 18, defs: rg('g', '#9a6ae0', '#4a2a9a', '#22104e') + rg('gx', '#6a34b0', '#1e0c44', '#08031a') + rg('gv', '#c49af6', '#7a4ad0', '#3a1a7a') + rg('bt', '#5a3a8a', '#2a1650', '#140a2a'), fc,
    body: feet(7, 89.5, 'url(#bt)', 6, 3.8) + arms(19, 64.5, 24, 'url(#gv)', 4.4, 8.8)
      + P('M34 57 Q34 51 42 51 L58 51 Q66 51 66 57 Q67 70 70 86 Q50 90 30 86 Q33 70 34 57Z', 'url(#g)') + stars
      + P('M35.4 70 Q50 72.6 64.6 70 L65 73 Q50 75.6 35 73Z', '#2a1450') + C(50, 72, 3.1, '#2a1450') + C(50, 72, 2.2, 'none', { stroke: '#d79cff', 'stroke-width': 0.9 }) + C(50, 72, 1, '#f4d6ff')
      + P('M50 55.5 Q53 59 50 63.5 Q47 59 50 55.5Z', '#c890ff')
      + PMc('M33 55 Q35.5 49.5 43 50 L41.4 56 Q36.4 57.4 33 55Z', '#6a3ab8')
      + P('M50 9 Q58 14 64 21.5 Q69.5 30 68.5 40 Q67.5 51.5 50 53.5 Q32.5 51.5 31.5 40 Q30.5 30 36 21.5 Q42 14 50 9Z', 'url(#g)'),
    extra: P('M38 39 Q38 25.5 50 25.5 Q62 25.5 62 39 Q62 49.5 50 50.5 Q38 49.5 38 39Z', 'url(#gx)') + S('M38 39 Q38 25.5 50 25.5 Q62 25.5 62 39', '#b78cf0', 1.1, { opacity: 0.8 })
      + S('M50 38 Q52.6 36.4 51.8 39.6 Q50 43 46.2 40.6 Q43.2 37.2 47.4 33.8 Q52.4 30.8 56.2 35.6 Q59.2 40.6 54 45.2', '#e9a0ff', 1.2, { opacity: 0.9 }) + C(50, 38, 1.4, '#ffe6ff') + C(42, 32, 0.45, '#ffffff') + C(58, 46, 0.55, '#ffffff') + C(57, 30.5, 0.4, '#ffffff') }; };

D.magmara = () => { const fc = face({ y: 36, dx: 7.5, r: 3.5, my: 43.5, cy: 42, cdx: 11, crx: 3, cry: 1.9, sh: [43.5, 27.4] });
  return { skin: '#9a6448', head: 18, defs: rg('g', '#6e6670', '#3c3640', '#1c181f') + rg('sk', '#c48a66', '#9a6448', '#64382a') + rg('rk', '#8a8088', '#4e464e', '#2a2428') + rg('hr', '#4e3c3a', '#2a1e1e', '#140c0c') + lg('lv', '#fff3a0', '#ffb02a', '#ff5a1a'), fc,
    body: PM('M34.5 30 Q29 44 31 59 Q33.5 61 35.5 58 Q35 45 38.5 32Z', 'url(#hr)') + C(33.2, 59.2, 1.5, 'url(#lv)') + C(66.8, 59.2, 1.5, 'url(#lv)')
      + feet(7, 89, 'url(#rk)', 6, 4) + arms(19, 64.5, 22, 'url(#rk)', 4.6, 8.8)
      + P('M34 57 Q34 51 42 51 L58 51 Q66 51 66 57 Q66 67 60 74 Q62 80 60 86 L40 86 Q38 80 40 74 Q34 67 34 57Z', 'url(#g)')
      + S('M41 54.5 Q46 57 50 61 Q54 57 59 54.5 M50 61 L50 72 M45.5 64.5 Q50 67.5 54.5 64.5 M46.5 69.5 Q50 71.5 53.5 69.5 M43 79 L44 85 M57 79 L56 85', '#ff8a1e', 1.1)
      + P('M40 74 Q50 76 60 74 L60.2 76.6 Q50 78.6 39.8 76.6Z', 'url(#rk)')
      + PMc('M33 55.5 Q32.5 49 39 48.5 L43 50.5 Q42 56.5 36 57.5Z', 'url(#rk)') + PMc('M34.5 50 L36.5 46.5 L38.5 49Z', 'url(#rk)') + SMc('M35 54 L38.5 51.5 L40.5 53', '#ff8a1e', 0.8)
      + C(50, 34.5, 16, 'url(#sk)') + P('M33.8 32 Q34.6 17 50 17 Q65.4 17 66.2 32 Q60.5 24 50 24.5 Q39.5 24 33.8 32Z', 'url(#hr)')
      + S('M43 18 Q40.6 23.4 38.4 28 M50 17.6 L50 24.2 M57 18 Q59.4 23.4 61.6 28', '#6a5250', 0.8)
      + C(50, 14.5, 5, 'url(#hr)') + P('M45.4 16.4 Q50 18.4 54.6 16.4 L54.2 18 Q50 19.8 45.8 18Z', 'url(#lv)'),
    extra: PM('M39.6 30.8 Q43 29 46.6 30.9 L46.3 32.1 Q43 30.6 39.9 32Z', '#3a2020') + S('M60.5 41 L62.2 39.4 L63.4 40.4', '#ff8a1e', 0.6) }; };
D.chronoshade = () => { const fc = { svg: '', data: { eyes: [{ x: 44.5, y: 37, r: 3.1 }, { x: 55.5, y: 37, r: 3.1 }], mouth: { x: 50, y: 45, w: 7 }, cheeks: [{ x: 39, y: 43 }, { x: 61, y: 43 }] } };
  return { skin: '#3a3654', head: 18, defs: rg('g', '#6a6488', '#3a3654', '#1c1a30') + rg('hd', '#5e4e86', '#2e2650', '#16122c') + rg('mk', '#f0ecf6', '#b0aac0', '#6e687c') + lg('bz', '#f6d2aa', '#c48a5e', '#7a4e2e'), fc,
    body: feet(7, 89, 'url(#g)', 6, 4) + arms(19, 64.5, 24, 'url(#g)', 4.3, 8.5)
      + P('M34 57 Q34 51 42 51 L58 51 Q66 51 66 57 Q66 67 60 74 Q62 80 60 86 L40 86 Q38 80 40 74 Q34 67 34 57Z', 'url(#g)')
      + SMc('M41.5 53 Q44.5 61 43.5 73', '#c48a5e', 0.9) + S('M50 52 L50 56', '#9a5aff', 1.3)
      + C(50, 60, 2.8, 'url(#bz)') + C(50, 60, 1.8, '#221c3a') + S('M50 60 L50 58.6 M50 60 L51.1 60.5', '#f6d2aa', 0.45)
      + C(40.5, 53.5, 1.7, 'url(#bz)') + C(59.5, 53.5, 1.7, 'url(#bz)')
      + P('M40 74 Q50 76 60 74 L60.2 76.6 Q50 78.6 39.8 76.6Z', '#221c3a') + P('M47.2 75 L52.8 75 L50 77.8Z', 'url(#bz)')
      + P('M50 13 Q67 13 68 33 Q69 48 62.5 53 Q50 55.5 37.5 53 Q31 48 32 33 Q33 13 50 13Z', 'url(#hd)'),
    extra: P('M37.5 34 Q37.5 21.5 50 21.5 Q62.5 21.5 62.5 34 Q62.5 47.5 50 52 Q37.5 47.5 37.5 34Z', '#140f24') + S('M37.5 34 Q37.5 21.5 50 21.5 Q62.5 21.5 62.5 34', '#9a5aff', 0.8, { opacity: 0.75 })
      + P('M39.5 33 Q39.5 25.5 50 25 Q60.5 25.5 60.5 33 Q61 41 56 45.5 L52.2 50 Q50 51.6 47.8 50 L44 45.5 Q39 41 39.5 33Z', 'url(#mk)')
      + S('M50 26 L50 49', '#7a7490', 0.6, { opacity: 0.55 }) + PM('M40.8 34.2 Q44.5 32 48.4 34.4 L48 35.6 Q44.5 33.6 41.2 35.4Z', '#4a4460') }; };

const TPL = { sway: 'Nimbo', wiggle: 'Mittens', jelly: 'Mallow', bounce: 'Bao', shuffle: 'Frybo', pop: 'Pip', hop: 'Bunbun', twist: 'Jelli', leap: 'Finn', slide: 'Sealy', robot: 'Biscuit' };
function build(key) {
  const d = D[key](); const fc = d.fc;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="1024" height="1024"><defs>${d.defs}${FT}${EY}</defs><g filter="url(#ft)">${d.body}</g>${d.extra || ''}${fc.svg}</svg>`;
  const e = fc.data.eyes, py = f((e[0].y + fc.data.mouth.y) / 2);
  const data = { name: key[0].toUpperCase() + key.slice(1), src: `export/tripo/${key}/${key}-front.svg?v=1`, ink: '#2a1a30', mouthInk: '#6a3a3a', cheek: '#ff8fa3', sclera: false, iris: '#2a1a30', irisK: 0.5,
    patch: { cx: 50, cy: py, rx: f(Math.abs(e[1].x - e[0].x) / 2 + 6), ry: f(Math.max(7, (fc.data.mouth.y - e[0].y) / 2 + 5)), top: d.skin, bot: d.skin }, eyes: e, mouth: fc.data.mouth, cheeks: fc.data.cheeks, head: d.head };
  return { svg, data };
}
window.PlushNew = { build, keys: Object.keys(D), TPL };
})();
