// Builds side + back views from a creature's front SVG (run in a browser context).
(function () {
const NS = 'http://www.w3.org/2000/svg';
const OVR = window.VIEW_OVR || {};
const mul = (m, n) => [m[0]*n[0]+m[2]*n[1], m[1]*n[0]+m[3]*n[1], m[0]*n[2]+m[2]*n[3], m[1]*n[2]+m[3]*n[3], m[0]*n[4]+m[2]*n[5]+m[4], m[1]*n[4]+m[3]*n[5]+m[5]];
const ID = [1,0,0,1,0,0];
function ptf(str) { let m = ID; if (!str) return m; const re = /(matrix|translate|scale|rotate|skewX|skewY)\s*\(([^)]*)\)/g; let r; while ((r = re.exec(str))) { const v = r[2].split(/[\s,]+/).filter(Boolean).map(Number); let t = ID; if (r[1] === 'matrix') t = v; else if (r[1] === 'translate') t = [1,0,0,1,v[0]||0,v[1]||0]; else if (r[1] === 'scale') t = [v[0],0,0,v[1]===undefined?v[0]:v[1],0,0]; else if (r[1] === 'rotate') { const a = v[0]*Math.PI/180, c = Math.cos(a), si = Math.sin(a); t = [c,si,-si,c,0,0]; if (v.length > 2) t = mul(mul([1,0,0,1,v[1],v[2]], t), [1,0,0,1,-v[1],-v[2]]); } m = mul(m, t); } return m; }
const ap = (m, p) => [m[0]*p[0]+m[2]*p[1]+m[4], m[1]*p[0]+m[3]*p[1]+m[5]];
function pathPts(d) { const tk = d.match(/[a-zA-Z]|-?(?:\d*\.\d+|\d+\.?)(?:e-?\d+)?/g) || []; const P = []; let i = 0, cmd = '', x = 0, y = 0, sx = 0, sy = 0; const n = () => +tk[i++];
  while (i < tk.length) { if (/[a-zA-Z]/.test(tk[i])) cmd = tk[i++]; const rel = cmd === cmd.toLowerCase(), C = cmd.toUpperCase(); const ox = rel ? x : 0, oy = rel ? y : 0;
    if (C === 'Z') { x = sx; y = sy; continue; }
    if (C === 'M' || C === 'L' || C === 'T') { x = ox + n(); y = oy + n(); if (C === 'M') { sx = x; sy = y; cmd = rel ? 'l' : 'L'; } }
    else if (C === 'H') x = ox + n(); else if (C === 'V') y = oy + n();
    else if (C === 'Q' || C === 'S') { P.push([ox + n(), oy + n()]); x = ox + n(); y = oy + n(); }
    else if (C === 'C') { P.push([ox + n(), oy + n()]); P.push([ox + n(), oy + n()]); x = ox + n(); y = oy + n(); }
    else if (C === 'A') { const rx = n(), ry = n(); n(); n(); n(); const nx = ox + n(), ny = oy + n(); P.push([(x+nx)/2 - rx, (y+ny)/2 - ry], [(x+nx)/2 + rx, (y+ny)/2 + ry]); x = nx; y = ny; }
    else { i++; continue; }
    P.push([x, y]); }
  return P; }
function localPts(el) { const t = el.tagName.toLowerCase(), g = a => +(el.getAttribute(a) || 0); const sw = (+el.getAttribute('stroke-width') || 0) / 2;
  if (t === 'circle' || t === 'ellipse') { const rx = (t === 'circle' ? g('r') : g('rx')) + sw, ry = (t === 'circle' ? g('r') : g('ry')) + sw; return Array.from({ length: 16 }, (_, k) => [g('cx') + rx * Math.cos(k / 16 * 6.283), g('cy') + ry * Math.sin(k / 16 * 6.283)]); }
  if (t === 'rect') { const x = g('x'), y = g('y'), w = g('width'), h = g('height'); return [[x, y], [x + w, y], [x, y + h], [x + w, y + h]]; }
  if (t === 'path') { const P = pathPts(el.getAttribute('d') || ''); if (!sw) return P; return P.flatMap(p => [[p[0]-sw,p[1]-sw],[p[0]+sw,p[1]+sw]]); }
  if (t === 'polygon' || t === 'polyline') { const v = (el.getAttribute('points') || '').split(/[\s,]+/).filter(Boolean).map(Number); const P = []; for (let k = 0; k < v.length; k += 2) P.push([v[k], v[k + 1]]); return P; }
  if (t === 'line') return [[g('x1'), g('y1')], [g('x2'), g('y2')]];
  if (t === 'g') return [...el.children].flatMap(c => localPts(c).map(p => ap(ptf(c.getAttribute('transform')), p)));
  return []; }
function ctmParent(el) { const ch = []; let p = el.parentNode; while (p && p.tagName && p.tagName.toLowerCase() !== 'svg') { ch.unshift(p); p = p.parentNode; } return ch.reduce((m, q) => mul(m, ptf(q.getAttribute('transform'))), ID); }
function bbox(el) { const m = mul(ctmParent(el), ptf(el.getAttribute('transform'))); const P = localPts(el).map(p => ap(m, p)); if (!P.length) return { x: 0, y: 0, w: 0, h: 0, cx: 0, cy: 0 }; let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9; for (const [x, y] of P) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); } return { x: x0, y: y0, w: x1 - x0, h: y1 - y0, cx: (x0 + x1) / 2, cy: (y0 + y1) / 2 }; }

function build(src, mode, k) {
  const ov = OVR[k] || {};
  const svg = new DOMParser().parseFromString(src, 'image/svg+xml').documentElement;
  const bx = bbox;
  const fg = svg.querySelector('g[filter]');
  const expand = (els, out) => { for (const c of [...els]) { if (/^(defs|metadata|title)$/i.test(c.tagName)) continue; const b = bx(c); if (b.w === 0 && b.h === 0) continue; if (c.tagName.toLowerCase() === 'g' && !c.getAttribute('fill') && !c.getAttribute('stroke') && c.children.length > 1 && b.w > 36) expand(c.children, out); else out.push({ el: c, b }); } return out; };
  const body = expand(fg ? fg.children : [], []);
  const face = []; let after = false; for (const c of [...svg.children]) { if (c === fg) { after = true; continue; } if (after && !/^(defs|metadata)$/i.test(c.tagName)) { if (c.tagName.toLowerCase() === 'g' && !c.getAttribute('fill') && !c.getAttribute('stroke') && c.children.length > 1 && bx(c).w > 36) expand(c.children, face); else { const b = bx(c); if (b.w || b.h) face.push({ el: c, b }); } } }
  const eyes = [...svg.querySelectorAll('[fill^="url(#ey"]')].map(bx).filter(e => e.w > 0);
  const eyeY = eyes.length ? eyes.reduce((a, e) => a + e.cy, 0) / eyes.length : 45;
  const eR = eyes.length ? eyes.reduce((m, e) => e.cx > m.cx ? e : m) : { cx: 62, cy: eyeY };
  let bigs = body.filter(o => o.b.w > (ov.bigW || 36) || o.b.w * o.b.h > 1000);
  const within = (a, o) => a.x >= o.b.x - 1.5 && a.y >= o.b.y - 1.5 && a.x + a.w <= o.b.x + o.b.w + 1.5 && a.y + a.h <= o.b.y + o.b.h + 1.5;
  bigs = bigs.filter(o => { const f = o.el.getAttribute('fill') || ''; if (f.startsWith('url(#g')) return true; return !bigs.some(p => p !== o && p.b.w * p.b.h > o.b.w * o.b.h && within(o.b, p)); });
  const inside = (p, o) => p.cx > o.b.x && p.cx < o.b.x + o.b.w && p.cy > o.b.y && p.cy < o.b.y + o.b.h;
  const hostOf = (b, self) => bigs.filter(o => o !== self && inside(b, o)).sort((a, c) => a.b.w * a.b.h - c.b.w * c.b.h)[0];
  const H = hostOf({ cx: eR.cx, cy: eyeY }) || [...bigs].sort((a, c) => c.b.w * c.b.h - a.b.w * a.b.h)[0] || { b: { cx: 50, w: 56, x: 22 } };
  const hx = H.b.cx, hw = H.b.w / 2;
  const paired = (o, list) => list.some(p => p !== o && Math.abs(p.b.cx - (100 - o.b.cx)) < 6 && Math.abs(p.b.cy - o.b.cy) < 6 && Math.abs(p.b.w - o.b.w) < 5);
  const firstNonDefs = p => { let c = p.firstElementChild; while (c && /^(defs|metadata)$/i.test(c.tagName)) c = c.nextElementSibling; return c; };
  const wrap = (o, x2, sx, opt = {}) => { const el = o.el; const m = mul(ctmParent(el), ID); const a = m[0], e = m[4]; const lcx = (o.b.cx - e) / a, lx2 = (x2 - e) / a; const g = document.createElementNS(NS, 'g'); g.setAttribute('transform', `translate(${lx2.toFixed(2)} ${(opt.dy || 0).toFixed(2)}) scale(${(sx * (opt.flip ? -1 : 1)).toFixed(3)} 1) translate(${(-lcx).toFixed(2)} 0)`); if (opt.dim) g.setAttribute('style', 'filter:brightness(' + opt.dim + ')'); el.parentNode.insertBefore(g, el); g.appendChild(el); if (opt.behind) g.parentNode.insertBefore(g, firstNonDefs(g.parentNode)); if (opt.front) g.parentNode.appendChild(g); return g; };
  const FX = ov.faceX || 0.62, CX = ov.centerX || 0.8, PX = ov.patchX || 0.56;
  for (const o of body) {
    if (bigs.includes(o)) continue;
    const b = o.b, side = Math.abs(b.cx - 50) > 6, s = Math.sign(b.cx - 50);
    const hst = hostOf(b, o);
    if (ov.keep && ov.keep(b)) continue;
    if (side) {
      if (paired(o, body)) {
        const kind = b.cy < eyeY - 8 ? 'ear' : b.cy > 84 ? 'leg' : 'arm';
        if (mode === 'side') {
          if (kind === 'ear') wrap(o, 50 + s * 3 + (hx - 50), 0.62, { behind: s < 0, dim: s < 0 ? 0.88 : 0 });
          else if (kind === 'leg') wrap(o, 50 + s * 8, 1, { dim: s < 0 ? 0.88 : 0 });
          else wrap(o, 50 + s * 4, 0.9, { behind: s < 0, dim: s < 0 ? 0.88 : 0 });
        }
      } else {
        if (mode === 'side') wrap(o, 50 - Math.abs(b.cx - 50) * 0.9, 1, { flip: b.cx > 50, behind: true });
        else wrap(o, 100 - b.cx, 1, { flip: true, front: true });
      }
    } else if (hst && b.cy > hst.b.y + hst.b.h * 0.28 && b.w < hst.b.w * 0.8) {
      if (mode === 'side') wrap(o, hst.b.cx + hst.b.w / 2 * PX, 0.55); else o.el.remove();
    }
  }
  for (const o of face) {
    const b = o.b, s = Math.sign(b.cx - 50), side = Math.abs(b.cx - 50) > 4;
    if (ov.faceKeep && ov.faceKeep(b)) { if (mode === 'side') wrap(o, b.cx, 1); continue; }
    if (b.cy < eyeY - 10) {
      const pr = side && paired(o, face);
      if (mode === 'side') { if (pr) wrap(o, 50 + s * 3 + (hx - 50), 0.62, { dim: s < 0 ? 0.88 : 0 }); }
      else if (pr) o.el.remove();
      continue;
    }
    if (mode === 'back') { o.el.remove(); continue; }
    if (side && s < 0) { o.el.remove(); continue; }
    if (side) wrap(o, hx + hw * FX + (b.cx - eR.cx) * 0.6, 0.6);
    else wrap(o, hx + hw * CX + (b.cx - 50) * 0.5, 0.6);
  }
  return new XMLSerializer().serializeToString(svg);
}
window.buildViews = function (frontSrc, k) {
  const meta = (frontSrc.match(/<metadata>[\s\S]*?<\/metadata>/) || [''])[0];
  const src = frontSrc.replace(meta, '');
  const add = s => s.replace(/(<svg[^>]*>)/, '$1' + meta);
  const side = build(src, 'side', k), back = build(src, 'back', k);
  const left = side.replace(/(<svg[^>]*>)([\s\S]*)<\/svg>\s*$/, (m, a, b) => a + '<g transform="translate(100 0) scale(-1 1)">' + b + '</g></svg>');
  return { right: add(side), left: add(left), back: add(back), plain: { front: src, right: side, left, back } };
};
})();
