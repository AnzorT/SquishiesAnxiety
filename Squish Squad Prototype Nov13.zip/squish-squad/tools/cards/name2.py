# Compose a creature name from the letter sprites of one style (the user's ABC sheet, Nov 12).
# Optical kerning: each letter's thick body (alpha > 0.5, eroded so thin swirls / wings / sparkles do not count) is
# profiled per scanline against the baseline, and the next letter slides left until the bodies sit GAP apart.
# Long names with a space or hyphen go on two lines when that makes the letters bigger in the name box.
import json, os, numpy as np
from PIL import Image
from scipy import ndimage as nd
if not os.path.exists('abc/meta.json') and os.path.exists('abc-atlas.json'):
    # published copy: the 130 letters live in 5 atlases (export/cards4/abc/atlas-<style>.webp + abc-atlas.json); unpack them once
    _A = json.load(open('abc-atlas.json')); os.makedirs('abc', exist_ok=True); json.dump(_A['meta'], open('abc/meta.json', 'w'))
    for _st, _r in _A['rects'].items():
        _im = Image.open('atlas-%s.webp' % _st)
        for _c, (x, y, w, h) in _r.items(): _im.crop((x, y, x + w, y + h)).save('abc/%s-%s.png' % (_st, _c))
M = json.load(open('abc/meta.json'))
GAP = {'common': 0.07, 'rare': 0.07, 'epic': 0.05, 'legendary': 0.05, 'rainbow': 0.05}   # in cap heights, between eroded bodies
_cache = {}

def sprite(st, c):
    k = st + c
    if k not in _cache:
        im = Image.open(next(p for p in ('abc/%s-%s.png' % (st, c), 'abc/%s-%s.webp' % (st, c)) if os.path.exists(p))).convert('RGBA'); m = M[st][c]; cap = M[st]['A']['cap']
        a = np.asarray(im)[..., 3] / 255.0; r = max(2, int(cap * 0.07))
        body = nd.binary_erosion(a > 0.5, iterations=r)
        # profile rows from baseline - cap*0.95 .. baseline (relative to baseline), in sprite px
        n = int(cap * 0.95); left = np.full(n, np.nan); right = np.full(n, np.nan)
        for i in range(n):
            y = m['base'] - n + i
            if 0 <= y < body.shape[0]:
                xs = np.where(body[y])[0]
                if len(xs): left[i], right[i] = xs[0] - r, xs[-1] + 1 + r
        _cache[k] = (im, m, left, right)
    return _cache[k]

def line_img(text, st):
    cap = M[st]['A']['cap']; n = int(cap * 0.95); gap = GAP[st] * cap
    parts = []; prev_r = None; pend = 0.0; x_end = 0.0
    for c in text.upper():
        if c == ' ': pend += cap * 0.30; continue
        if c == '-': pend += cap * 0.16; continue
        if c not in M[st]: continue
        im, m, left, right = sprite(st, c)
        if prev_r is None: x = 0.0
        else:
            # top 30% of the cap (wings, crossbars, ears) may overlap the neighbour a little; the body below keeps the gap
            d = prev_r - left; up = int(n * 0.3); du, dl = d[:up], d[up:]
            du, dl = du[~np.isnan(du)], dl[~np.isnan(dl)]
            cand = ([np.max(dl) + gap] if len(dl) else []) + ([np.max(du) + gap - cap * 0.16] if len(du) else [])
            x = (max(cand) if cand else x_end - np.nanmin(left) + gap) + pend
            x = max(x, x_end - np.nanmin(left) - cap * 0.25 + pend)   # never tuck a letter far under the previous one
        pend = 0.0
        r_abs = x + right
        prev_r = r_abs if prev_r is None else np.where(np.isnan(prev_r), r_abs, np.fmax(prev_r, r_abs))
        x_end = float(np.nanmax(r_abs))
        parts.append((im, int(round(x)), m['base']))
    x0 = min(p[1] for p in parts); x1 = max(p[1] + p[0].width for p in parts)
    up = max(p[2] for p in parts); dn = max(p[0].height - p[2] for p in parts)
    out = Image.new('RGBA', (x1 - x0, up + dn), (0, 0, 0, 0))
    for im, x, b in parts: out.alpha_composite(im, (x - x0, up - b))
    return out, up, cap

def split2(text):
    # best split point (space or after a hyphen) giving the most balanced two lines
    best = None
    for i, c in enumerate(text):
        if c in ' -':
            a, b = (text[:i], text[i + 1:]) if c == ' ' else (text[:i + 1], text[i + 1:])
            sc = abs(len(a) - len(b))
            if best is None or sc < best[0]: best = (sc, a.strip(), b.strip())
    return best and best[1:]

def fit(im, W, H):
    return min(W / im.width, H / im.height)

def name_box(text, st, W=420, H=200, pad=0.04):
    # the name, centred in a W x H transparent box (single line, or two lines if that reads bigger)
    iw, ih = W * (1 - 2 * pad), H * (1 - 2 * pad)
    one, _, cap = line_img(text, st); k1 = fit(one, iw, ih); best = ('1', k1, one)
    s = split2(text)
    if s:
        a, _, _ = line_img(s[0], st); b, _, _ = line_img(s[1], st)
        lh = int(cap * 0.86)   # line pitch: the second line tucks up under the first (decorations overlap a little)
        w2 = max(a.width, b.width); h2 = lh + b.height
        two = Image.new('RGBA', (w2, h2), (0, 0, 0, 0))
        two.alpha_composite(b, ((w2 - b.width) // 2, lh)); two.alpha_composite(a, ((w2 - a.width) // 2, 0))
        # draw order: second line first so the top line's feet sit over the bottom line's halos
        two2 = Image.new('RGBA', (w2, max(h2, a.height)), (0, 0, 0, 0))
        two2.alpha_composite(b, ((w2 - b.width) // 2, lh)); two2.alpha_composite(a, ((w2 - a.width) // 2, 0))
        k2 = fit(two2, iw, ih)
        if k2 > k1 * 1.12: best = ('2', k2, two2)
    _, k, im = best
    k = min(k, 1.0)
    t = im.resize((max(1, int(im.width * k)), max(1, int(im.height * k))), Image.LANCZOS)
    out = Image.new('RGBA', (W, H), (0, 0, 0, 0)); out.alpha_composite(t, ((W - t.width) // 2, (H - t.height) // 2))
    return out

if __name__ == '__main__':
    import sys
    names = [('common', 'Mittens'), ('rare', 'Mama Paws'), ('epic', 'Peachy'), ('legendary', 'Nori'), ('rainbow', 'Corny'),
             ('legendary', 'Count Squishula'), ('epic', 'Crystalline'), ('legendary', 'Giga-Growth'), ('common', 'Sea Turtle'),
             ('rare', 'Bao'), ('epic', 'Chef Bun'), ('rainbow', 'Sugarplum'), ('common', 'Pip'), ('legendary', 'Chrono-Shade'), ('rare', 'Wisecrack')]
    S = Image.new('RGB', (3 * 440, 5 * 215), (90, 60, 130));
    for i, (st, n) in enumerate(names):
        b = name_box(n, st); bg = Image.new('RGBA', b.size, (60, 40, 90, 255)); bg.alpha_composite(b); S.paste(bg.convert('RGB'), (10 + (i % 3) * 440, 8 + (i // 3) * 215))
    S.save('names2.jpg', quality=86)

# outline + soft drop shadow so the name reads on its rarity's panel (pearl-white legendary, pastel rainbow, copper rare)
from PIL import ImageFilter
OUTLINE = {'common': ((58, 30, 8), 0.55, 3), 'rare': ((52, 22, 6), 0.75, 4), 'epic': ((30, 8, 60), 0.6, 3),
           'legendary': ((122, 70, 8), 0.95, 5), 'rainbow': ((104, 52, 170), 0.9, 5)}
def name_card(text, st, W=420, H=198):
    im = name_box(text, st, W, H, pad=0.06); col, k, d = OUTLINE[st]
    a = im.getchannel('A')
    ring = a.filter(ImageFilter.MaxFilter(2 * d + 1)).filter(ImageFilter.GaussianBlur(1.2)).point(lambda v: int(v * k))
    sh = a.filter(ImageFilter.MaxFilter(2 * d + 1)).filter(ImageFilter.GaussianBlur(4)).point(lambda v: int(v * 0.35))
    out = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    s = Image.new('RGBA', (W, H), col + (0,)); s.putalpha(sh); out.alpha_composite(s, (0, 4))
    r = Image.new('RGBA', (W, H), col + (0,)); r.putalpha(ring); out.alpha_composite(r)
    out.alpha_composite(im)
    return out
