# Re-make every creature name image for the v6 card boards: export/cards4/names/<key>.webp + names.js (?v=).
# Each name is drawn in the user's ABC letters for its rarity (name2.py, atlases in export/cards4/abc/) at the shape of that
# rarity's name board (layout6.json NMPX): common 760x196, rare 760x255, epic 760x227 (deep-purple ring), legendary 760x230,
# rainbow 760x234. Run from this folder: python3 names6.py [new ?v= number] [key ...]   (no keys = every name in names.js)
# roster.json = [{key, name, ...}] for the display names; the rarity comes from names.js. Takes ~6 min for all 118.
import json, os, re, shutil, sys
from PIL import Image, ImageFilter
HERE = os.path.dirname(os.path.abspath(__file__)); C4 = os.path.join(HERE, '..', '..', 'export', 'cards4')
work = os.path.join(HERE, 'work'); os.makedirs(work, exist_ok=True)
for f in os.listdir(os.path.join(C4, 'abc')): shutil.copy(os.path.join(C4, 'abc', f), work)
G = json.load(open(os.path.join(HERE, 'layout6.json'))); R = {x['key']: x for x in json.load(open(os.path.join(HERE, 'roster.json')))}
sys.path.insert(0, HERE); os.chdir(work)
from name2 import name_box, name_card
RAR = ['common', 'rare', 'epic', 'legendary', 'rainbow']
def epic_card(text, W, H, col=(46, 12, 92)):
    im = name_box(text, 'epic', W, H, pad=0.06); a = im.getchannel('A')
    ring = a.filter(ImageFilter.MaxFilter(9)).filter(ImageFilter.GaussianBlur(1.3)).point(lambda v: int(v * 0.92))
    sh = a.filter(ImageFilter.MaxFilter(9)).filter(ImageFilter.GaussianBlur(5)).point(lambda v: int(v * 0.4))
    out = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    s = Image.new('RGBA', (W, H), col + (0,)); s.putalpha(sh); out.alpha_composite(s, (0, 5))
    rr = Image.new('RGBA', (W, H), col + (0,)); rr.putalpha(ring); out.alpha_composite(rr); out.alpha_composite(im); return out
ver = sys.argv[1] if len(sys.argv) > 1 else '7'; only = set(sys.argv[2:])
js = open(os.path.join(C4, 'names.js')).read(); n = 0
for k, rar, src in re.findall(r'"([a-z0-9_]+)":\[(\d),"([^"]+)"\]', js):
    if only and k not in only: continue
    st = RAR[int(rar)]; w, h = G['NMPX'][st]; W = 760; H = round(W * h / w)
    im = epic_card(R[k]['name'], W, H) if st == 'epic' else name_card(R[k]['name'], st, W, H)
    im.save(os.path.join(C4, 'names', k + '.webp'), quality=88, method=6)
    js = js.replace('"%s":[%s,"%s"]' % (k, rar, src), '"%s":[%s,"export/cards4/names/%s.webp?v=%s"]' % (k, rar, k, ver)); n += 1
open(os.path.join(C4, 'names.js'), 'w').write(js); print('names', n, '-> bump names.js ?v= in the pages that load it')
