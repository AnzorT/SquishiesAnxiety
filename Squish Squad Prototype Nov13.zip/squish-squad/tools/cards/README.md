# Card tools (cards v6)

The game's cards use `export/cards4/`. Each card has these layers: the group background (`bg-<group>.webp`), then the creature picture, then the rarity frame (`frame-<rarity>.webp`, 600x894, star pips baked in), then the name image (`names/<key>.webp`). `cards4.js` holds the layer boxes per rarity (`L`, % of the card).

- `frames-original/raw-<rarity>.webp`: the user's 5 frames, keyed to transparency (`key.py` did the keying), 1696x2528.
- `frames-reshaped/raw-<rarity>.webp`: the v6 frames, with a shorter name board and a taller picture window on the same canvas. Made by `reshape.py` (generic: wavy seam cuts, stretches, loose sparkles kept round; uses `seam.py`) and `common3.py` (common: mushrooms lifted out and put back). The exact settings for each rarity are in `docs/HISTORY.md` (grep "CARDS v6").
- `layout6.py` → `layout6.json`: the window, board, pips (`BAR`), name box (`NMPX`) and the `L` boxes that go into `export/cards4/cards4.js`.
- `bake6.py`: frames-reshaped + pips → `export/cards4/frame-<rarity>.webp`. Then bump the frame `?v=` in `cards4.js`.
- `names6.py [ver] [keys...]`: re-makes the name images in the user's ABC letters (`name2.py`, letter atlases in `export/cards4/abc/`) at each board's shape, and updates `names.js`. Then bump `names.js?v=` in the pages. When a creature's rarity changes, re-make its name. Until then the card shows plain text.
- `make_cards4.py`, `layout.py`: the v4 pipeline (group backgrounds via `bgs`). Frames and names now come from `bake6.py` / `names6.py`.

Needs Python 3 with Pillow, numpy and scipy.
