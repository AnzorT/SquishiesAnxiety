# per-rarity card layout (fractions of the 1696x2528 frame canvas)
CX = {'common': 0.5085, 'rare': 0.4997, 'epic': 0.5018, 'legendary': 0.5032, 'rainbow': 0.508}
PANEL_CY = {'common': 0.773, 'rare': 0.766, 'epic': 0.763, 'legendary': 0.7695, 'rainbow': 0.783}
NAME_W, NAME_H = 0.57, 0.18
BAR = {'common': 0.6497, 'rare': 0.6253, 'epic': 0.6869, 'legendary': 0.6222, 'rainbow': 0.6411}   # Nov 13 v5 frames: pips at the top of the name panel
BG = {'common': (0.1828, 0.1622, 0.829, 0.5352), 'rare': (0.1958, 0.1519, 0.8042, 0.4964), 'epic': (0.1492, 0.1946, 0.8414, 0.5811), 'legendary': (0.1875, 0.1713, 0.8154, 0.5107), 'rainbow': (0.1657, 0.1634, 0.8349, 0.5269)}
ART = {'common': (0.2483, 0.2019, 0.7635, 0.5143), 'rare': (0.2586, 0.1896, 0.7414, 0.4759), 'epic': (0.2179, 0.2353, 0.7727, 0.5599), 'legendary': (0.2517, 0.2086, 0.7512, 0.4902), 'rainbow': (0.2328, 0.2024, 0.7678, 0.5061)}
def name_rect(r):
    return (CX[r] - NAME_W / 2, PANEL_CY[r] - NAME_H / 2, CX[r] + NAME_W / 2, PANEL_CY[r] + NAME_H / 2)

# Nov 13 v5 frames (the user's new set): name box inside the lower panel
NM = {'common': (0.279, 0.6856, 0.7381, 0.8268), 'rare': (0.2582, 0.6637, 0.7412, 0.8145), 'epic': (0.246, 0.7151, 0.7576, 0.8258), 'legendary': (0.2555, 0.6638, 0.751, 0.8274), 'rainbow': (0.256, 0.6788, 0.7599, 0.827)}
