# Re-proportion a card frame: take D rows out of the name panel and put D rows into the picture window,
# both along the cheapest wavy seam (where the frame looks the same D rows apart), so the card keeps its size.
import numpy as np, sys, json
from PIL import Image
from scipy import ndimage as nd

def cost_map(A, d, y0, y1, k=21):
    # C[y, x] = how different the frame is between row y and row y + d (premultiplied colour + alpha), smoothed
    P = A.astype(np.float32); al = P[..., 3:4] / 255.0; P = np.concatenate([P[..., :3] * al, P[..., 3:4]], -1)
    D = np.abs(P[y0:y1] - P[y0 + d:y1 + d]).sum(-1)
    return nd.uniform_filter(D, (k, 7))

def dp_seam(C, slope=2):
    H, W = C.shape; acc = C[:, 0].copy(); back = np.zeros((H, W), np.int16)
    for x in range(1, W):
        best = np.full(H, np.inf); arg = np.zeros(H, np.int16)
        for s in range(-slope, slope + 1):
            sh = np.full(H, np.inf)
            if s >= 0: sh[s:] = acc[:H - s]
            else: sh[:s] = acc[-s:]
            m = sh < best; best[m] = sh[m]; arg[m] = s
        acc = best + C[:, x]; back[:, x] = arg
    y = int(np.argmin(acc)); seam = np.zeros(W, int); seam[-1] = y
    for x in range(W - 1, 0, -1): y = y - back[y, x]; seam[x - 1] = y
    return seam, float(acc.min()) / W

def remove(A, d, seam, f=6):
    # rows above the seam stay, rows below come from d further down (the band [seam, seam + d) is gone)
    H, W = A.shape[:2]; out = np.zeros((H - d, W, 4), np.float32); Y = np.arange(H - d)[:, None]
    w = np.clip((Y - (seam[None, :] - f)) / (2 * f), 0, 1)[..., None]   # 0 = top part, 1 = shifted part
    top = A[:H - d].astype(np.float32); bot = A[d:].astype(np.float32)
    return top * (1 - w) + bot * w

def insert(A, d, seam, f=6):
    # rows above the seam stay, then the band [seam - d, seam) repeats once
    H, W = A.shape[:2]; Y = np.arange(H + d)[:, None]
    top = np.zeros((H + d, W, 4), np.float32); top[:H] = A
    bot = np.zeros((H + d, W, 4), np.float32); bot[d:] = A
    w = np.clip((Y - (seam[None, :] - f)) / (2 * f), 0, 1)[..., None]
    return top * (1 - w) + bot * w

if __name__ == '__main__':
    src, dst, d, pr, wr = sys.argv[1], sys.argv[2], int(sys.argv[3]), json.loads(sys.argv[4]), json.loads(sys.argv[5])
    A = np.asarray(Image.open(src).convert('RGBA')).astype(np.float32)
    # 1) panel: remove d rows, seam y in pr = [a, b] (rows a..b, band below it must also stay inside the panel)
    C = cost_map(A, d, pr[0], pr[1]); s1, c1 = dp_seam(C); s1 = s1 + pr[0]
    B = remove(A, d, s1)
    # 2) window: insert d rows, seam t in wr = [a, b]; match row t against row t - d
    C2 = cost_map(B, d, wr[0] - d, wr[1] - d); s2, c2 = dp_seam(C2); s2 = s2 + wr[0]
    O = insert(B, d, s2)
    Image.fromarray(np.clip(O, 0, 255).astype(np.uint8)).save(dst)
    json.dump({'panel_seam': [int(s1.min()), int(s1.max())], 'win_seam': [int(s2.min()), int(s2.max())], 'cost': [c1, c2]}, open(dst + '.json', 'w'))
    print('panel seam', s1.min(), s1.max(), 'cost %.1f' % c1, '| window seam', s2.min(), s2.max(), 'cost %.1f' % c2)
