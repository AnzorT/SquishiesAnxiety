import json
from PIL import Image, ImageDraw
W, H = 1696, 2528
WIN = {'common': [350, 450, 1367, 1644], 'rare': [372, 424, 1325, 1516], 'epic': [308, 544, 1387, 1556], 'legendary': [358, 473, 1344, 1632], 'rainbow': [321, 453, 1377, 1593]}
BOX = {'common': [420, 1862, 1305, 2181], 'rare': [382, 1763, 1313, 2156], 'epic': [358, 1782, 1344, 2159], 'legendary': [376, 1825, 1331, 2197], 'rainbow': [376, 1805, 1347, 2186]}
pc = lambda v, t: round(v / t * 100, 2)
L = {}; BAR = {}; NMPX = {}
for r in WIN:
    x0, y0, x1, y1 = WIN[r]; bx0, by0, bx1, by1 = BOX[r]
    bg = [x0 - 40, y0 - 40, x1 + 40, y1 + 40]
    S = min(1.08 * (x1 - x0), (y1 - y0) - 60); cx = (x0 + x1) / 2; ab = y1 - 28
    art = [cx - S / 2, ab - S, cx + S / 2, ab]
    bar = by0 + 52; bw = bx1 - bx0
    nm = [bx0 + 0.06 * bw, by0 + 100, bx1 - 0.06 * bw, by1 - 18]
    L[r] = {'bg': [pc(bg[0], W), pc(bg[1], H), pc(bg[2], W), pc(bg[3], H)], 'art': [pc(art[0], W), pc(art[1], H), pc(art[2], W), pc(art[3], H)],
            'nm': [pc(nm[0], W), pc(nm[1], H), pc(nm[2], W), pc(nm[3], H)]}
    BAR[r] = round(bar / H, 4); NMPX[r] = [round(nm[2] - nm[0]), round(nm[3] - nm[1])]
    im = Image.open('frames-reshaped/raw-%s.webp' % r).convert('RGBA'); c = Image.new('RGBA', im.size, (205, 225, 250, 255)); c.alpha_composite(im); d = ImageDraw.Draw(c)
    d.rectangle(bg, outline=(0, 160, 0, 255), width=6); d.rectangle(art, outline=(255, 0, 0, 255), width=6); d.rectangle(nm, outline=(0, 0, 255, 255), width=6)
    d.ellipse([W * 0.5 - 40, bar - 40, W * 0.5 + 40, bar + 40], outline=(255, 120, 0, 255), width=6)
    c.convert('RGB').resize((424, 632)).save('lay-%s.jpg' % r)
json.dump({'L': L, 'BAR': BAR, 'NMPX': NMPX}, open('layout6.json', 'w'))
print(json.dumps(L)); print(BAR); print(NMPX)
