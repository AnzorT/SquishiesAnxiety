# Cards v4 (Nov 12): the user's own five rarity frames (common vines, rare bronze, epic purple, legendary gold, rainbow
# pastel) + each creature's name in the user's ABC style for its rarity, + a group background in the picture window.
#   frames:  raw-<rarity>.png (soft-keyed from the attachments by key.py) -> cards4/frame-<rarity>.webp (600x894) with
#            1-5 gold star pips baked into the name bar
#   bgs:     cards4/bg-<group>.svg (square, the group header colours + motif + podium) -> rasterised by rast4.js
#   names:   cards4/names/<key>.webp (420x198, centred) + cards4/names.js  (window.SQ_NAMES = {key: [rarity, src]})
import json, math, os, random, sys, numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from layout import CX, BAR
from name2 import name_card
OUT = 'cards4'; os.makedirs(OUT + '/names', exist_ok=True)
RAR = ['common', 'rare', 'epic', 'legendary', 'rainbow']
FW, FH = 600, 894

def star_pts(cx, cy, R, r, rot=-90):
    return [(cx + (R if i % 2 == 0 else r) * math.cos(math.radians(rot + i * 36)), cy + (R if i % 2 == 0 else r) * math.sin(math.radians(rot + i * 36))) for i in range(10)]

def pips(img, n, cx, cy, R=14):
    S = 4; layer = Image.new('RGBA', (FW * S, FH * S), (0, 0, 0, 0)); d = ImageDraw.Draw(layer)
    step = R * 2.25; x0 = cx - step * (n - 1) / 2
    for i in range(n):
        x, y = (x0 + i * step) * S, cy * S; RR = R * S
        d.polygon(star_pts(x + 0.6 * S, y + 1.6 * S, RR * 1.12, RR * 0.56), fill=(70, 30, 0, 150))       # soft drop
        d.polygon(star_pts(x, y, RR * 1.12, RR * 0.56), fill=(110, 56, 4, 255))                            # dark rim
        d.polygon(star_pts(x, y, RR * 0.92, RR * 0.46), fill=(255, 196, 40, 255))                          # gold
        d.polygon(star_pts(x, y - RR * 0.10, RR * 0.66, RR * 0.33), fill=(255, 236, 140, 255))            # light top
        d.ellipse([x - RR * 0.42, y - RR * 0.52, x - RR * 0.12, y - RR * 0.26], fill=(255, 255, 255, 220))  # glint
    layer = layer.resize((FW, FH), Image.LANCZOS); img.alpha_composite(layer)

def frames():
    for i, r in enumerate(RAR):
        f = Image.open('raw-%s.png' % ('rainbow2' if r == 'rainbow' else r)).convert('RGBA').resize((FW, FH), Image.LANCZOS)
        pips(f, i + 1, CX[r] * FW, BAR[r] * FH)
        f.save(OUT + '/frame-%s.webp' % r, quality=90, method=6)

# ---- group backgrounds (square; shown behind the picture window, object-fit: cover) ----
def _mc2():
    # the group colours + motif shapes come from the cards v3 generator (export/cards2/make_cards2.py.txt; films/make_cards2.py in scratch)
    src = open(next(p for p in ('../films/make_cards2.py', '../cards2/make_cards2.py.txt', 'make_cards2.py.txt') if os.path.exists(p))).read()
    NS = {}; exec(src.split('def background')[0].replace("OUT = sys.argv[1] if len(sys.argv) > 1 else 'cards2'", "OUT = '/tmp/_unused_cards2'"), NS)
    return NS['SETS'], NS['MOT'], NS['SETMOT'], NS['mix']

def background(key, S=400):
    SETS, MOT, SETMOT, mix = _mc2()
    ink, tint = SETS[key]
    deep, mid, light, pale = mix(ink, '#1a0828', 0.45), ink, mix(ink, '#ffffff', 0.38), mix(tint, '#ffffff', 0.2)
    rnd = random.Random(sum(map(ord, key)))
    s = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d">' % (S, S), '<defs>',
         '<radialGradient id="g" cx="50%%" cy="55%%" r="70%%"><stop offset="0" stop-color="%s"/><stop offset="0.5" stop-color="%s"/><stop offset="1" stop-color="%s"/></radialGradient>' % (light, mid, deep),
         '<radialGradient id="pod" cx="50%" cy="40%" r="60%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.8"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.28"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>',
         '<radialGradient id="halo" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>',
         '<linearGradient id="gl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>',
         '<radialGradient id="vg" cx="50%" cy="50%" r="72%"><stop offset="0.62" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.34"/></radialGradient>',
         '</defs>', '<rect width="%d" height="%d" fill="url(#g)"/>' % (S, S)]
    cx, cy, n = S / 2, S * 0.56, 24
    for i in range(n):
        a0 = i * 2 * math.pi / n; a1 = a0 + math.pi / n
        s.append('<path d="M%g %g L%g %g L%g %g Z" fill="#ffffff" opacity="0.09"/>' % (cx, cy, cx + 800 * math.cos(a0), cy + 800 * math.sin(a0), cx + 800 * math.cos(a1), cy + 800 * math.sin(a1)))
    mots = SETMOT[key]; k = 0
    for row in range(7):
        for col in range(6):
            x = 30 + col * 72 + (36 if row % 2 else 0) + rnd.uniform(-6, 6); y = 26 + row * 58 + rnd.uniform(-5, 5)
            m = mots[k % len(mots)]; k += 1; sc = rnd.uniform(1.25, 1.65); r = rnd.uniform(-30, 30)
            s.append('<g transform="translate(%.1f %.1f) rotate(%.0f) scale(%.2f)" fill="%s" stroke="%s" opacity="0.22">%s</g>' % (x, y, r, sc, pale, pale, MOT[m]))
    s.append('<ellipse cx="%g" cy="%g" rx="%g" ry="%g" fill="url(#halo)"/>' % (cx, S * 0.52, S * 0.44, S * 0.44))
    s.append('<ellipse cx="%g" cy="%g" rx="%g" ry="%g" fill="%s" opacity="0.5"/>' % (cx, S * 0.905, S * 0.36, S * 0.075, deep))
    s.append('<ellipse cx="%g" cy="%g" rx="%g" ry="%g" fill="url(#pod)"/>' % (cx, S * 0.89, S * 0.34, S * 0.062))
    s.append('<ellipse cx="%g" cy="%g" rx="%g" ry="%g" fill="none" stroke="#ffffff" stroke-opacity="0.55" stroke-width="2.4"/>' % (cx, S * 0.888, S * 0.34, S * 0.062))
    s.append('<rect width="%d" height="%d" fill="url(#vg)"/>' % (S, S))
    s.append('<path d="M0 0 H%g V%g C%g %g %g %g 0 %gZ" fill="url(#gl)"/>' % (S, S * 0.26, S * 0.7, S * 0.2, S * 0.3, S * 0.2, S * 0.26))
    s.append('</svg>')
    return ''.join(s)

def bgs():
    for k in _mc2()[0]: open(OUT + '/bg-%s.svg' % k, 'w').write(background(k))

def names(roster):
    man = {}
    for x in roster:
        st = RAR[min(4, max(0, x['rar']))]
        im = name_card(x['name'], st, 420, 198)
        p = OUT + '/names/%s.webp' % x['key']; im.save(p, quality=86, method=6)
        man[x['key']] = [x['rar'], 'export/cards4/names/%s.webp?v=1' % x['key']]
    open(OUT + '/names.js', 'w').write(
        "// Nov 12 cards v4: each creature's name drawn in the user's ABC letter style for its rarity (common / rare / epic /\n"
        "// legendary / rainbow), pre-rendered (frames/make_cards4.py). [rarity it was drawn for, image]; if a creature's\n"
        "// rarity changes, the pages show plain text until the names are re-made.\n"
        "window.SQ_NAMES = " + json.dumps(man, separators=(',', ':')) + ";\n")

if __name__ == '__main__':
    what = sys.argv[1:] or ['frames', 'bgs', 'names']
    if 'frames' in what: frames()
    if 'bgs' in what: bgs()
    if 'names' in what: names(json.load(open('roster.json')))
    print('ok')
