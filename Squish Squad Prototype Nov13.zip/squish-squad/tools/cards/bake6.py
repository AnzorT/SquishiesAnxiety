# Bake the 5 card frames the game uses: reshaped frame (frames-reshaped/) + the 1-5 gold star pips at BAR from layout6.json
# -> ../../export/cards4/frame-<rarity>.webp (600 x 894). Run from this folder: python3 bake6.py, then bump the frame ?v= in
# export/cards4/cards4.js (cdFrame) so phones re-download them.
import json, math
from PIL import Image, ImageDraw
FW, FH = 600, 894
CX = {'common': 0.5085, 'rare': 0.4997, 'epic': 0.5018, 'legendary': 0.5032, 'rainbow': 0.508}   # pip row centre x (fraction of width)
def star_pts(cx, cy, R, r, rot=-90):
    return [(cx + (R if i % 2 == 0 else r) * math.cos(math.radians(rot + i * 36)), cy + (R if i % 2 == 0 else r) * math.sin(math.radians(rot + i * 36))) for i in range(10)]

def pips(img, n, cx, cy, R=14):
    S = 4; layer = Image.new('RGBA', (FW * S, FH * S), (0, 0, 0, 0)); d = ImageDraw.Draw(layer)
    step = R * 2.25; x0 = cx - step * (n - 1) / 2
    for i in range(n):
        x, y = (x0 + i * step) * S, cy * S; RR = R * S
        d.polygon(star_pts(x + 0.6 * S, y + 1.6 * S, RR * 1.12, RR * 0.56), fill=(70, 30, 0, 150))       # soft drop
        d.polygon(star_pts(x, y, RR * 1.12, RR * 0.56), fill=(110, 56, 4, 255))                            # dark rim
        d.polygon(star_pts(x, y, RR * 0.92, RR * 0.46), fill=(255, 196, 40, 255))                          # gold
        d.polygon(star_pts(x, y - RR * 0.10, RR * 0.66, RR * 0.33), fill=(255, 236, 140, 255))            # light top
        d.ellipse([x - RR * 0.42, y - RR * 0.52, x - RR * 0.12, y - RR * 0.26], fill=(255, 255, 255, 220))  # glint
    layer = layer.resize((FW, FH), Image.LANCZOS); img.alpha_composite(layer)

G = json.load(open('layout6.json'))
for i, r in enumerate(['common', 'rare', 'epic', 'legendary', 'rainbow']):
    f = Image.open('frames-reshaped/raw-%s.webp' % r).convert('RGBA').resize((FW, FH), Image.LANCZOS)
    pips(f, i + 1, CX[r] * FW, G['BAR'][r] * FH)
    f.save('../../export/cards4/frame-%s.webp' % r, quality=90, method=6)
    print('baked', r)
