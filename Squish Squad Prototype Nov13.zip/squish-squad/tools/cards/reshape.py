# Generic frame re-proportioning. cfg: {"src", "dst", "rm": [[d, lo, hi, [[x0, x1, a, b], ...]], ...],
#   "ins": [[d, lo, hi, [[x0, x1, a, b], ...]], ...], "keep": [[x0, y0, x1, y1, "up"|"stay"], ...]}
# rm: take d rows out along the cheapest seam s(x) in lo..hi (band s..s+d); per-column limits [a, b] for s.
# ins: repeat the d-row band ending at the cheapest seam t(x) in lo..hi; per-column limits [a, b] for t.
# keep: lift an opaque decoration out before the removals (its alpha inside the box) and paste it back after them,
#   moved up with the rows below the cut ('up', by the sum of rm d) or left where it was ('stay').
import sys, json, numpy as np
from PIL import Image
from scipy import ndimage as nd
from seam import cost_map, dp_seam, remove, insert
cfg = json.load(open(sys.argv[1])) if sys.argv[1].endswith('.json') else json.loads(sys.argv[1])
A = np.asarray(Image.open(cfg['src']).convert('RGBA')).astype(np.float32); H, W = A.shape[:2]; O = A.copy()
def limit(C, lo, rows, lims):
    ys = np.arange(lo, lo + rows)[:, None]
    for x0, x1, a, b in lims: C[:, x0:x1] += np.where((ys < a) | (ys > b), 1e6, 0)
    return C
sprites = []
floats = []
if cfg.get('floats'):
    # detached bits (bubbles, dots, sparkles) in rows y0..y1: lifted out now, put back after the cut moved by 'shift'
    y0f, y1f, shf = cfg['floats']; lb, nb = nd.label(A[..., 3] > 60); szs = nd.sum(np.ones((H, W)), lb, range(1, nb + 1)); main = 1 + int(np.argmax(szs))
    for i, sl in enumerate(nd.find_objects(lb)):
        if i + 1 == main or sl is None or sl[0].start < y0f or sl[0].stop > y1f: continue
        m = nd.binary_dilation(lb[sl] == i + 1, iterations=3); patch = A[sl].copy(); patch[..., 3] *= m
        floats.append((sl, patch)); A[sl][m] = 0
for x0, y0, x1, y1, how in cfg.get('keep', []):
    sp = np.zeros_like(O); sp[y0:y1, x0:x1] = O[y0:y1, x0:x1]; sprites.append((sp, how))
log = []
tot = 0
for d, lo, hi, lims in cfg.get('rm', []):
    C = limit(cost_map(A, d, lo, hi), lo, hi - lo, lims); s, c = dp_seam(C, cfg.get('slope', 2)); s = s + lo; A = remove(A, d, s); tot += d
    log.append(['rm', d, int(s.min()), int(s.max()), round(c, 1)])
for d, lo, hi, lims, cx0, cx1, b0, b1 in cfg.get('rmh', []):
    # hybrid cut: the side columns lose d rows along the cheapest seam, the board columns cx0..cx1 squeeze rows b0..b1
    # into b1 - b0 - d (a smooth gradient board survives that better than a seam)
    C = limit(cost_map(A, d, lo, hi), lo, hi - lo, lims); C[:, cx0:cx1] = 0; sm, c = dp_seam(C, cfg.get('slope', 2)); sm = sm + lo
    R = remove(A, d, sm)
    al = A[..., 3:4] / 255.0; P = np.concatenate([A[..., :3] * al, A[..., 3:4]], -1)
    band = Image.fromarray(np.clip(P[b0:b1, cx0:cx1], 0, 255).astype(np.uint8), 'RGBA').resize((cx1 - cx0, b1 - b0 - d), Image.BICUBIC)
    band = np.asarray(band).astype(np.float32); ab = band[..., 3:4] / 255.0
    band = np.concatenate([np.where(ab > 0, band[..., :3] / np.maximum(ab, 1e-6), 0), band[..., 3:4]], -1)
    R[:b0, cx0:cx1] = A[:b0, cx0:cx1]; R[b0:b1 - d, cx0:cx1] = band; R[b1 - d:, cx0:cx1] = A[b1:, cx0:cx1]
    A = R; tot += d; log.append(['rmh', d, int(sm.min()), int(sm.max()), round(c, 1)])
for sl, patch in floats:
    ys, xs = sl; y = ys.start + cfg['floats'][2]; dst = A[y:y + patch.shape[0], xs]; a = patch[..., 3:4] / 255.0
    dst[..., :3] = patch[..., :3] * a + dst[..., :3] * (1 - a); dst[..., 3:4] = np.maximum(dst[..., 3:4], patch[..., 3:4])
for sp, how in sprites:
    sh = tot if how == 'up' else 0 if how == 'stay' else -int(how); spr = np.roll(sp, -sh, axis=0)[:A.shape[0]]
    a = spr[..., 3:4] / 255.0; A[..., :3] = spr[..., :3] * a + A[..., :3] * (1 - a); A[..., 3:4] = np.maximum(A[..., 3:4], spr[..., 3:4])
for d, lo, hi, lims in cfg.get('ins', []):
    C = limit(cost_map(A, d, lo - d, hi - d), lo, hi - lo, lims); s, c = dp_seam(C, cfg.get('slope', 2)); s = s + lo; A = insert(A, d, s)
    log.append(['ins', d, int(s.min()), int(s.max()), round(c, 1)])
def stretch(A, d, a, b):
    al = A[..., 3:4] / 255.0; P = np.concatenate([A[..., :3] * al, A[..., 3:4]], -1)
    band = Image.fromarray(np.clip(P[a:b], 0, 255).astype(np.uint8), 'RGBA')   # premultiplied, so edges do not go dark
    band = np.asarray(band.resize((A.shape[1], b - a + d), Image.BICUBIC)).astype(np.float32)
    out = np.concatenate([P[:a], band, P[b:]], 0); al2 = out[..., 3:4] / 255.0
    return np.concatenate([np.where(al2 > 0, out[..., :3] / np.maximum(al2, 1e-6), 0), out[..., 3:4]], -1)
def stretch_clean(A, d, a, b, cols, thr=185, mode='lum'):
    # like stretch, but light specks (sparkles, dots) in the given column ranges are lifted out first and put back
    # unstretched where they land, so they do not turn into streaks
    H, W = A.shape[:2]; lum = A[..., :3] @ np.array([0.3, 0.55, 0.15], np.float32)
    colm = np.zeros(W, bool)
    for x0, x1 in cols: colm[x0:x1] = True
    M = np.zeros((H, W), bool)
    if mode == 'alpha': M[a - 20:b + 20] = (A[a - 20:b + 20, :, 3] > 8) & colm[None, :]   # see-through window: anything there is a floater
    elif mode == 'float':   # every piece not joined to the frame itself (sparkles, dots, stars around it)
        lb, nb = nd.label(A[..., 3] > 8); sz = nd.sum(np.ones((H, W)), lb, range(1, nb + 1)); main = 1 + int(np.argmax(sz))
        F = (lb > 0) & (lb != main); M[a - 60:b + 60] = F[a - 60:b + 60]
    else: M[a - 20:b + 20] = (lum[a - 20:b + 20] > thr) & (A[a - 20:b + 20, :, 3] > 200) & colm[None, :]
    M = nd.binary_dilation(M, iterations=4)
    lab, n = nd.label(M); objs = nd.find_objects(lab)
    keepA = A.copy(); w = (~M).astype(np.float32)[..., None]
    num = nd.gaussian_filter(A * w, (9, 9, 0)); den = nd.gaussian_filter(w, (9, 9, 0))
    C = np.where(M[..., None], num / np.maximum(den, 1e-3), A)
    out = stretch(C, d, a, b); f = (b - a + d) / (b - a)
    for i, sl in enumerate(objs):
        ys, xs = sl; cy = (ys.start + ys.stop) / 2
        h = ys.stop - ys.start
        ny = ys.start if cy < a else ys.start + d if cy > b else int(round(a + (cy - a) * f - h / 2)); m = (lab[sl] == i + 1)
        soft = nd.gaussian_filter(m.astype(np.float32), 1.0)[..., None]; src = keepA[sl]
        dst = out[ny:ny + (ys.stop - ys.start), xs]; out[ny:ny + (ys.stop - ys.start), xs] = src * soft + dst * (1 - soft)
    return out
def warp_stretch(A, d, pts, thr=185):
    # a curved band: at column x, rows a(x)..b(x) are stretched to a(x)..b(x)+d (a, b linear between control points);
    # light specks inside the band are lifted out first and put back unstretched where they land
    H, W = A.shape[:2]; X = np.arange(W)
    px = [p[0] for p in pts]; a = np.interp(X, px, [p[1] for p in pts]); b = np.interp(X, px, [p[2] for p in pts]); L = b - a
    lum = A[..., :3] @ np.array([0.3, 0.55, 0.15], np.float32); Y = np.arange(H)[:, None]
    inb = (Y > a[None, :] + 3) & (Y < b[None, :] - 3)
    M = nd.binary_dilation((lum > thr) & (A[..., 3] > 200) & inb, iterations=4) & ((Y > a[None, :] - 6) & (Y < b[None, :] + 6))
    lab, n = nd.label(M); objs = nd.find_objects(lab)
    w = (~M).astype(np.float32)[..., None]; num = nd.gaussian_filter(A * w, (9, 9, 0)); den = nd.gaussian_filter(w, (9, 9, 0))
    C = np.where(M[..., None], num / np.maximum(den, 1e-3), A)
    al = C[..., 3:4] / 255.0; P = np.concatenate([C[..., :3] * al, C[..., 3:4]], -1)
    Yo = np.arange(H + d)[:, None].astype(np.float32)
    src = np.where(Yo < a[None, :], Yo, np.where(Yo < (b + d)[None, :], a[None, :] + (Yo - a[None, :]) * (L / (L + d))[None, :], Yo - d))
    Xo = np.broadcast_to(X[None, :].astype(np.float32), src.shape)
    out = np.stack([nd.map_coordinates(P[..., c], [src, Xo], order=1, mode='nearest') for c in range(4)], -1)
    al2 = out[..., 3:4] / 255.0; out = np.concatenate([np.where(al2 > 0, out[..., :3] / np.maximum(al2, 1e-6), 0), out[..., 3:4]], -1)
    for i, sl in enumerate(objs):
        ys, xs = sl; cy = (ys.start + ys.stop) / 2; cx = int((xs.start + xs.stop) / 2)
        f = (L[cx] + d) / L[cx]; ny = int(round(a[cx] + (cy - a[cx]) * f - (ys.stop - ys.start) / 2)); m = (lab[sl] == i + 1)
        soft = nd.gaussian_filter(m.astype(np.float32), 1.0)[..., None]
        out[ny:ny + (ys.stop - ys.start), xs] = A[sl] * soft + out[ny:ny + (ys.stop - ys.start), xs] * (1 - soft)
    return out
for d, pts in cfg.get('wst', []):
    A = warp_stretch(A, d, pts); log.append(['wst', d])
for st in cfg.get('stc', []):
    d, a, b, cols = st[:4]; A = stretch_clean(A, d, a, b, cols, mode=st[4] if len(st) > 4 else 'lum'); log.append(['stc', d, a, b])
for d, a, b in cfg.get('st', []):
    A = stretch(A, d, a, b); log.append(['st', d, a, b])
Image.fromarray(np.clip(A, 0, 255).astype(np.uint8)).save(cfg['dst'])
# measure: the picture window = the largest enclosed see-through hole
al = np.asarray(Image.open(cfg['dst']))[..., 3]; tr = al < 128; lab, n = nd.label(tr)
border = set(np.unique(np.r_[lab[0], lab[-1], lab[:, 0], lab[:, -1]])); sz = nd.sum(tr, lab, range(1, n + 1))
i = max((s, k + 1) for k, s in enumerate(sz) if k + 1 not in border)[1]; ys, xs = np.where(lab == i)
print(json.dumps({'steps': log, 'window': [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]}))
