# Cut a dark-background illustration out with a soft alpha (glows stay soft, solid art stays opaque).
import sys, numpy as np
from PIL import Image
from scipy import ndimage as nd
def key(src, out, lo=14, hi=62, sig=45, DIL=7, protect=()):
    im = Image.open(src).convert('RGB'); a = np.asarray(im).astype(np.float32)
    # local background colour: normalized blur of the dark, grey pixels
    mx, mn = a.max(2), a.min(2); dark = (mx < 48) & ((mx - mn) < 16)
    w = nd.gaussian_filter(dark.astype(np.float32), sig) + 1e-6
    bg = np.stack([nd.gaussian_filter(a[..., i] * dark, sig) / w for i in range(3)], -1)
    far = ~nd.binary_dilation(dark, iterations=3)
    # where there is no dark pixel nearby (inside big art) the blur is undefined: fill with the global median dark colour
    g = np.median(a[dark], 0); wt = np.clip(w / 0.05, 0, 1)[..., None]; bg = bg * wt + g * (1 - wt)
    d = np.sqrt(((a - bg) ** 2).sum(2))
    al = np.clip((d - lo) / (hi - lo), 0, 1); al = al * al * (3 - 2 * al)
    lum = a @ np.array([0.3, 0.59, 0.11], np.float32); bl = bg @ np.array([0.3, 0.59, 0.11], np.float32)
    bright = (al > 0.5) & (lum > 80)
    solid = nd.binary_closing(bright, iterations=3); solid = nd.binary_fill_holes(solid) & ~nd.binary_erosion(~solid, iterations=0) if False else nd.binary_closing(bright, iterations=3)
    solid = nd.binary_opening(solid, iterations=1)
    solid = nd.binary_dilation(solid, iterations=DIL) & (al > 0.25) | solid
    al_l = np.clip((lum - bl - 6) / 95, 0, 1)
    al = np.where(solid, 1.0, np.where(lum < 80, np.minimum(al, al_l), al)).astype(np.float32)
    H, W = al.shape
    for (x0, y0, x1, y1) in protect: al[int(y0 * H):int(y1 * H), int(x0 * W):int(x1 * W)] = 1.0
    # un-mix the background from semi-transparent pixels (glows become pure light)
    A = np.clip(al, 1e-3, 1)[..., None]; c = np.clip(bg + (a - bg) / A, 0, 255)
    rgba = np.dstack([c, al[..., None] * 255]).astype(np.uint8)
    Image.fromarray(rgba, 'RGBA').save(out); return rgba
if __name__ == '__main__':
    import json
    o = json.loads(sys.argv[3]) if len(sys.argv) > 3 else {}
    key(sys.argv[1], sys.argv[2], DIL=o.get('dil', 7), protect=o.get('protect', []))
