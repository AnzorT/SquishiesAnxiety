# Common frame, name panel shortened by D: one wavy cut through the panel sides above the bottom moss (the mushrooms
# are lifted out first and put back D higher, so they still grow out of the moss), then the window grows by D in two
# repeats of its plain log band.
import numpy as np, json, colorsys
from PIL import Image
from scipy import ndimage as nd
from seam import cost_map, dp_seam, remove, insert
D = 330
O = np.asarray(Image.open('frames-original/raw-common.webp').convert('RGBA')).astype(np.float32); H, W = O.shape[:2]
# --- mushroom sprites (cap + stem + their own dark outline) ---
rgb = O[..., :3] / 255.0; mx = rgb.max(-1); mn = rgb.min(-1); sat = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1e-6), 0)
core = (O[..., 3] > 200) & (sat < 0.33) & (mx > 0.55)
dark = (O[..., 3] > 60) & (mx < 0.5)
mask = np.zeros((H, W), bool)
for (x0, y0, x1, y1) in [(80, 1845, 280, 2125), (1377, 1810, 1640, 2135)]:
    box = np.zeros((H, W), bool); box[y0:y1, x0:x1] = True
    c = core & box; lab, n = nd.label(c); sz = nd.sum(c, lab, range(1, n + 1))
    keep = np.isin(lab, [i + 1 for i, s in enumerate(sz) if s > 1500])
    keep = nd.binary_fill_holes(nd.binary_closing(keep, iterations=3))
    ring = nd.binary_dilation(keep, iterations=10) & dark & box
    m = nd.binary_fill_holes(keep | ring); mask |= m
soft = nd.gaussian_filter(mask.astype(np.float32), 1.2)
sprite = O.copy(); sprite[..., 3] *= np.clip(soft * 1.15, 0, 1)
# --- panel cut, per-column allowed seam rows ---
lo, hi = 1540, 2181 - D - 15
C = cost_map(O, D, lo, hi)
ys = np.arange(lo, hi)[:, None]
def allow(x0, x1, a, b):
    bad = (ys < a) | (ys > b); C[:, x0:x1] += np.where(bad, 1e6, 0)
allow(0, 400, 1592, 1720)      # left: below the big moss, above the bottom moss
allow(1340, W, 1550, 1740)     # right
s, c = dp_seam(C); s = s + lo; print('panel seam', s.min(), s.max(), 'cost %.1f' % c, 'left', s[200], 'right', s[1500])
B = remove(O, D, s)
# put the mushrooms back, D rows higher (same place against the moss and rocks)
sp = np.zeros_like(B); sp[:H - D - (H - D - (H - D))] = 0
sh = sprite[D:H] if False else None
spr = np.zeros((H - D, W, 4), np.float32); spr[:H - D] = sprite[D:] * 0
spr = np.roll(sprite, -D, axis=0)[:H - D]
a = spr[..., 3:4] / 255.0; B[..., :3] = spr[..., :3] * a + B[..., :3] * (1 - a); B[..., 3:4] = np.maximum(B[..., 3:4], spr[..., 3:4])
# --- window: two repeats of the plain log band ---
for (d, a0, b0) in [(165, 975, 1060), (165, 980, 1150)]:
    C2 = cost_map(B, d, a0 - d, b0 - d); s2, c2 = dp_seam(C2); s2 = s2 + a0; B = insert(B, d, s2); print('window seam', s2.min(), s2.max(), 'cost %.1f' % c2)
Image.fromarray(np.clip(B, 0, 255).astype(np.uint8)).save('frames-reshaped/raw-common.webp', lossless=True)
