// Renovation Catalog round 23 — Living Room furniture remodel, part 2a: bookcases + fireplaces (10 pieces).
// Built like round 22 (RD.H16 + RD.H22 toolkits): real 3D solids, no sunk-in parts, glued details (par / fn), animated fx that hide when their face turns away.
// Sets RenoDraw.PLUS23; catalog edits RD.SET23; toolkit RD.H23 {bk, deco, face, qd, fireIn, slide}.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS22 && RD.H22 && RD.H16 && RD.H && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS23) return;
  const K = X.K, { box, cyl, ball, slab, slabX, arcW, disc, cush, pillowZ, solid, shade, mix, f1 } = K, prismZ = K.prismZ;
  const N = RD.N, PI = Math.PI, GOLD = '#e2b14a', CH = '#d5dde2', BR = '#d4a548';
  const { tilt, tiltAll, rotF, rod, pipe, fxEll, frame, an, FONT, W_, M_, F_, PL, G_, em, rep } = RD.H16;
  const { band, R0, glue, rp, RG, ell, TOP, book, mug, sprig } = RD.H22;
  const gmug = (o, x, y, z, col) => { const i0 = o.length; mug(o, x, y, z, col); const B = o[i0]; for (let i = i0 + 1; i < o.length; i++) o[i].par = B; return B; };
  const P2 = q => f1(q[0]) + ' ' + f1(q[1]), n4 = v => Math.round(v * 1e4) / 1e4;
  // face(c, nx, nz) ~ cos between a vertical face normal and the viewer (> 0 = the face looks at you); fw(p) same for layer wraps
  const face = (c, nx, nz) => (c.p(nx, 0, nz)[1] - c.p(0, 0, 0)[1]) / (c.k * X.SA);
  const fw = (p, nx, nz) => p(nx == null ? 0 : nx, 0, nz == null ? 1 : nz)[1] - p(0, 0, 0)[1];
  const qd = (c, P) => 'M' + P.map(q => P2(c.p(q[0], q[1], q[2]))).join('L') + 'Z';
  const fireIn = (c, id, P, L) => ({ defs: '<clipPath id="' + id + '"><path d="' + qd(c, P) + '"/></clipPath>', g: '<g clip-path="url(#' + id + ')">' + RD.H.fire(c, L).over + '</g>' });
  // slide(p, xs, ys, dur, kt): smooth looping move along the piece's own x (and y) axes, for layer wraps
  const slide = (p, xs, ys, dur, kt) => { const o0 = p(0, 0, 0), ex = p(1, 0, 0), ey = p(0, 1, 0), T = (dx, dy) => f1((ex[0] - o0[0]) * dx + (ey[0] - o0[0]) * dy) + ' ' + f1((ex[1] - o0[1]) * dx + (ey[1] - o0[1]) * dy);
    return '<animateTransform attributeName="transform" type="translate" values="' + xs.map((x, i) => T(x, ys ? ys[i] : 0)).join(';') + '" keyTimes="' + kt + '" dur="' + dur + 's" calcMode="spline" keySplines="' + rep(xs.length - 1, () => '0.45 0 0.55 1').join(';') + '" repeatCount="indefinite"/>'; };
  // back panel of a bookcase: drawn first while its front faces you, last once you see it from behind (z is ignored by the sort at side views, so it can't be sorted)
  const AOD = '<defs><linearGradient id="q23aV" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0.55"/><stop offset="0.28" stop-color="#000" stop-opacity="0.16"/><stop offset="0.8" stop-color="#000" stop-opacity="0.06"/><stop offset="1" stop-color="#000" stop-opacity="0.26"/></linearGradient><linearGradient id="q23aH" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000" stop-opacity="0.34"/><stop offset="0.14" stop-color="#000" stop-opacity="0"/><stop offset="0.86" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.34"/></linearGradient></defs>';
  const aoSvg = (p, A) => { if (!A) return ''; const [z, L] = A; return '<g transform="' + frame(p, [0, 0, z], [1, 0, 0], [0, -1, 0]) + '">' + AOD + L.map(([a, b, c, d]) => '<rect x="' + a + '" y="' + (-d) + '" width="' + (b - a) + '" height="' + (d - c) + '" fill="url(#q23aV)"/><rect x="' + a + '" y="' + (-d) + '" width="' + (b - a) + '" height="' + (d - c) + '" fill="url(#q23aH)"/>').join('') + '</g>'; };
  const backL = (fn, A) => [{ back: 1, build: fn, wrap: (p, s) => fw(p) >= 0 ? s + aoSvg(p, A) : '' }, { build: fn, wrap: (p, s) => fw(p) < 0 ? s : '' }];
  const sway = (q, a, d) => '<animateTransform attributeName="transform" type="rotate" values="' + [0, a, 0, -a * 0.8, 0].map(v => v + ' ' + P2(q)).join(';') + '" dur="' + d + 's" calcMode="spline" keyTimes="0;0.25;0.5;0.75;1" keySplines="0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1" repeatCount="indefinite"/>';

  // ---------- books + shelf decor ----------
  const BC = ['#7f2030', '#1f4f3e', '#2b3f7a', '#c99a2e', '#5a2a5e', '#e9dfcc', '#3a2a22', '#a8592b', '#2c2d31', '#6b8fb8', '#9fb58c', '#d9483b', '#d8b4a0', '#4a6a5a'];
  const deco = (o, on, R, x, y, z, hm) => { const t = Math.floor(R() * 5);
    if (t === 0) { const r = 3.4, h = Math.min(hm * 0.7, 15); o.push(cyl(x + r + 0.5, y, z, r, h, ['#e9e4da', '#3f6a8a', '#c8693f', '#2c2d31', '#9fb58c'][Math.floor(R() * 5)], { n: 14, mat: 'cer', rg: [[0, 0, 0.66], [h * 0.4, 0, 1], [h * 0.82, 0, 0.5], [h, 0, 0.6]] })); return 2 * r + 1; }
    if (t === 1) { o.push(cyl(x + 4.5, y, z, 3.8, 5, '#d86a4a', { n: 14, mat: 'cer', rg: [[0, 0, 0.78], [5, 0, 1]] })); sprig(o, x + 4.5, y + 5, z, R, null, 6); return 9; }
    if (t === 2) { const h = Math.min(hm * 0.55, 12), pv = [x + 5, y, z - 2.4], F = tilt(box(x + 5, y, z - 3, 10, h, 1.2, '#2c2d31', W_({ r: 0.4 })), [1, 0, 0], -0.08, pv); o.push(F);
      on(F, [tilt(box(x + 5, y + 1.4, z - 2.35, 7, h - 2.8, 0.1, ['#9fc4d9', '#e8c9a0', '#b9d6a8'][Math.floor(R() * 3)], { r: 0.2, noOut: 1 }), [1, 0, 0], -0.08, pv)], [0, 0, 1]); return 10; }
    if (t === 3) { const G = ball(x + 4.5, y + 7.4, z, 4.4, '#4f86b8', { k: 6, n: 14, shine: 1 }); o.push(cyl(x + 4.5, y, z, 3, 1.2, BR, M_({ n: 12 })), rod([x + 4.5, y + 1.2, z], [x + 4.5, y + 3, z], 0.5, BR, M_({ n: 6 })), G);
      glue(o)(G, [band(x + 4.5, y + 7, z, 4.45, 0.7, GOLD, M_({ n: 20 }))].concat([[-1.6, 1.4], [1.8, -0.6]].map(([dx, dy]) => ball(x + 4.5 + dx, y + 7.4 + dy, z + 3.6, 1.7, '#7fb25a', { sz: 0.35, k: 3, n: 8, noOut: 1 }))), [0, 0, 1]); return 9; }
    o.push(box(x + 3.5, y, z, 7, 3, 7, '#2c2d31', M_({ r: 0.6 })), ball(x + 3.5, y + 6.4, z, 3.4, BR, M_({ k: 5, n: 12, shine: 1 }))); return 7; };
  // bk: a row of books between x0..x1 on a shelf at y (back at zb, depth up to dm, height up to hm); some lie in stacks, some spots get a decor piece
  const spine = (on, B, R, cx, y, zf, w, h, col) => { const s = Math.floor(R() * 5), L = [box(cx, y + h - 0.55, zf, w - 0.1, 0.55, 0.1, shade(col, 0.68), { r: 0, noOut: 1 }), box(cx, y, zf, w - 0.1, 0.45, 0.1, shade(col, 0.72), { r: 0, noOut: 1 })];
    if (s === 0) L.push(box(cx, y + h * 0.8, zf, w * 0.82, 0.7, 0.1, GOLD, M_({ r: 0, noOut: 1 })), box(cx, y + h * 0.14, zf, w * 0.82, 0.5, 0.1, GOLD, M_({ r: 0, noOut: 1 })), box(cx, y + h * 0.5, zf, w * 0.36, h * 0.16, 0.1, shade(GOLD, 0.9), M_({ r: 0, noOut: 1 })));
    else if (s === 1) { const ly = y + h * 0.52; L.push(box(cx, ly, zf, w * 0.8, h * 0.22, 0.1, '#f2ead8', { r: 0.2, noOut: 1 }), box(cx, ly + h * 0.15, zf, w * 0.5, 0.35, 0.1, '#3a2a22', { r: 0, noOut: 1 }), box(cx, ly + h * 0.07, zf, w * 0.6, 0.35, 0.1, '#3a2a22', { r: 0, noOut: 1 })); }
    else if (s === 2) L.push(box(cx, y + 0.45, zf, w - 0.1, h * 0.3, 0.1, ['#f2ead8', '#2c2d31', '#c99a2e', '#7f2030'][Math.floor(R() * 4)], { r: 0, noOut: 1 }), box(cx, y + h * 0.66, zf, w * 0.7, h * 0.06, 0.1, '#ffffff', { r: 0, noOut: 1, op: 0.7 }));
    else if (s === 3) rep(3, i => L.push(box(cx, y + h * (0.74 + i * 0.05), zf, w * 0.8, 0.25, 0.1, GOLD, M_({ r: 0, noOut: 1 }))));
    else L.push(box(cx, y + h * 0.25, zf, w * 0.8, h * 0.5, 0.1, shade(col, 1.22), { r: 0.3, noOut: 1 }), box(cx, y + h * 0.5, zf, w * 0.5, 0.4, 0.1, shade(col, 0.6), { r: 0, noOut: 1 }));
    on(B, L, [0, 0, 1]); };
  const bk = (o, on, R, x0, x1, y, zb, dm, hm, dc, sh) => { let x = x0 + 0.3; if (sh) on(sh, [box((x0 + x1) / 2, y + 0.03, zb + dm + 0.6, x1 - x0 - 1, 0.05, 2.4, '#000000', { r: 0, noOut: 1, op: 0.16 }), box((x0 + x1) / 2, y + 0.03, zb + 2, x1 - x0 - 1, 0.05, 4, '#000000', { r: 0, noOut: 1, op: 0.22 })], [0, 1, 0]);
    while (x < x1 - 2.4) { const k = R(), room = x1 - x - 0.3;
      if (dc && k < 0.12 && room > 11) { x += dc(o, on, R, x, y, zb + dm / 2, hm) + 0.8; continue; }
      if (k < 0.24 && room > 13) { const w = 10 + R() * 2.6; let yy = y; rep(2 + Math.floor(R() * 3), j => { const t = 1.8 + R() * 1.4, ww = w - j * 0.9, dd = dm - 2 - j * 0.8, cx = x + w / 2 - j * 0.2, B = box(cx, yy, zb + dm / 2, ww, t, dd, BC[Math.floor(R() * BC.length)], { r: 0.4, mat: 'fab' }); o.push(B);
          on(B, [box(cx, yy + 0.3, zb + dm / 2 + dd / 2 + 0.05, ww - 1.2, t - 0.6, 0.1, '#f2ead8', { r: 0, noOut: 1 }), box(cx, yy + t * 0.45, zb + dm / 2 + dd / 2 + 0.07, ww - 1.4, 0.12, 0.05, '#d8ccb2', { r: 0, noOut: 1 })], [0, 0, 1]); yy += t; }); x += w + 0.8; continue; }
      const w = 2.2 + R() * 2.6, h = hm * (0.62 + R() * 0.34), d = dm - R() * 3, B = box(x + w / 2, y, zb + d / 2, w, h, d, BC[Math.floor(R() * BC.length)], { r: 0.4, mat: 'fab' }); o.push(B);
      spine(on, B, R, x + w / 2, y, zb + d + 0.05, w, h, B.col); on(B, [box(x + w / 2, y + h + 0.02, zb + d / 2 - 0.3, w - 0.5, 0.06, d - 1, '#efe4cc', { r: 0, noOut: 1 })], [0, 1, 0]);
      x += w + 0.25; } };

  // ======================= BOOKCASES =======================
  // LIV-007 warped particleboard 3-cube organizer: leans, one foot on a folded-card shim, peeling laminate, chipped edge, swollen feet, canvas bin, books, games
  N.cube23 = S => { const PB = '#ece6d8', CORE = '#b99a6c', HB = '#7a5a3c', W = 40, T = 1.8, C = 36, H = 3 * C + 4 * T, D = 30, piv = [0, 0, 0], RL = v => v;
    return { w: W + 10, d: D + 6, topH: H, topW: 24, build: () => { const o = [], on = glue(o), R = R0('cube');
      const SL = box(-(W / 2 - T / 2), 0, 0.3, T, H, D - 0.6, PB, PL({ r: 0.3 })), SR = box(W / 2 - T / 2, 0, 0.3, T, H, D - 0.6, PB, PL({ r: 0.3 })); o.push(SL, SR);
      [SL, SR].forEach((P, i) => on(P, [box((i ? 1 : -1) * (W / 2 - T / 2), 0, 0.3, T + 0.12, 4.4, D - 0.48, '#d9ccb0', PL({ r: 0.3, noOut: 1 }))]));
      const SH = rep(4, i => box(0, i * (C + T), 0.4, W - 2 * T, T, D - 0.8, PB, PL({ r: 0.2 }))); SH.forEach(s => o.push(s));
      on(SH[1], [box(W / 2 - T - 2.6, C + T, D / 2 + 0.05, 4.4, T, 0.1, CORE, { r: 0, noOut: 1 })], [0, 0, 1]);
      on(SH[1], pipe([[W / 2 - T - 4.8, C + 2 * T, D / 2 - 0.1], [W / 2 - T - 6.4, C + 2 * T + 1.4, D / 2 + 1.4], [W / 2 - T - 7.2, C + 2 * T + 3.2, D / 2 + 1]], 0.28, '#f6f2ea', PL({ n: 4, noOut: 1 })));
      on(SH[3], [box(-W / 2 + 6, H + 0.02, 6, 6, 0.06, 4, CORE, { r: 1, noOut: 1, op: 0.55 })], [0, 1, 0]);
      // bottom cube: grey canvas bin with a sock flopping out
      const BIN = box(0, T, 1.6, C - 2, C - 4, D - 6, '#8d9096', F_({ r: 2 })); o.push(BIN);
      on(BIN, [box(0, T + C - 13, 13.65, 10, 3.6, 0.1, '#3a3c40', { r: 1.6, noOut: 1 }), box(-10, T + 6, 13.65, 7, 4, 0.1, '#f2efe6', { r: 0.4, noOut: 1 })], [0, 0, 1]);
      on(BIN, [box(9, T + C - 4, 7, 4.4, 1.2, 9, '#e86f5a', F_({ r: 0.6 })), box(9, T + C - 12.4, 14.3, 4.4, 9.6, 1.2, '#e86f5a', F_({ r: 0.6 })), box(9, T + C - 9, 14.95, 4.5, 1.2, 0.1, '#f2efe6', { r: 0, noOut: 1 })]);
      // middle cube: books + one leaning against the side
      const y1 = C + 2 * T; bk(o, on, R, -W / 2 + T, 10, y1, -D / 2 + 0.8, 20, 26, null, SH[1]);
      [SL, SR].forEach((P, i) => { const xf = (i ? 1 : -1) * (W / 2 - T); on(P, [1, 2].map(k => solid({ ax: 'x', sh: 'el', c: [10, k * (C + T) + T / 2], a: 1.1, b: 1.1, n: 10, rings: i ? [[xf - 0.12, 0], [xf, 0]] : [[xf, 0], [xf + 0.12, 0]], col: '#c9ced3', mat: 'metal', noOut: 1 })), [i ? -1 : 1, 0, 0]); });
      const LB = box(12.3, y1, -2, 2.6, 24, 18, '#2b3f7a', { r: 0.4, mat: 'fab' }); tilt(LB, [0, 0, 1], -0.18, [13.6, y1, -2]); o.push(LB);
      // top cube: board games + coin jar
      const y2 = 2 * (C + T) + T; [['#d9483b', 24, 4.2], ['#3f7fc8', 22.6, 3.4], ['#f2c14a', 21, 3]].reduce((yy, [col, w, h], i) => { const G = box(-5 + i * 0.6, yy, -1, w, h, 22 - i, col, PL({ r: 0.5 })); o.push(G); on(G, [box(-5 + i * 0.6, yy + h * 0.5, -1 + (22 - i) / 2 + 0.05, w - 3, h * 0.36, 0.1, '#ffffff', { r: 0.2, noOut: 1, op: 0.8 })], [0, 0, 1]); return yy + h; }, y2);
      const JAR = cyl(12, y2, -2, 4, 11, '#dff2f8', { n: 14, op: 0.42, shine: 1, rg: [[0, 0, 0.92], [9, 0, 1], [11, 0, 0.7]] }); o.push(JAR); on(JAR, [cyl(12, y2 + 0.2, -2, 3.6, 4.6, '#d4a548', M_({ n: 14 })), cyl(12, y2 + 11, -2, 3, 1.4, '#6a6e74', M_({ n: 12 }))]);
      // on top: pen mug + rubber duck
      const MG = gmug(o, -9, H, 2, '#4f9a4a'); [['#e86f5a', -1.2, 0.6], ['#2b3f7a', 0.8, -0.8], ['#f2c14a', 0, 1]].forEach(([col, dx, dz]) => glue(o)(MG, [rod([-9 + dx, H + 6.4, 2 + dz], [-9 + dx * 1.6, H + 13, 2 + dz * 1.6], 0.35, col, PL({ n: 5 }))]));
      o.push(ball(8, H + 3.2, 4, 4, '#ffd23a', PL({ sx: 1.25, sy: 0.85, k: 5, n: 12 })), ball(10.4, H + 8, 4.4, 2.6, '#ffd23a', PL({ k: 4, n: 10 })), ball(13, H + 7.6, 4.4, 1.2, '#ff8a2a', PL({ sx: 1.3, sy: 0.5, k: 3, n: 8 })));
      return o; },
      layers: backL(() => [slab(0, 0, -D / 2 + 0.3, W, H, 0.6, HB, W_({ r: 0 }))], [-D / 2 + 0.62, rep(3, i => [-W / 2 + T, W / 2 - T, i * (C + T) + T, (i + 1) * (C + T)])]),
      fx: c => { if (face(c, 1, 0) < 0.12) return {}; const O = rp(RL, piv, [W / 2 + 0.08, 80, 9]), M = frame(c.p, O, RL([0, 0, -1]), RL([0, -1, 0]));
        return { front: '<g transform="' + M + '"><g><animateTransform attributeName="transform" type="rotate" values="0 3.5 0;5 3.5 0;-2 3.5 0;3 3.5 0;0 3.5 0" dur="4.6s" repeatCount="indefinite"/><rect x="0" y="0" width="7" height="7" fill="#ffe66b" stroke="#e0c24a" stroke-width="0.2"/><path d="M1.2 2.4H5.6M1.2 3.8H5M1.2 5.2H4.2" stroke="#7a6a3a" stroke-width="0.35" stroke-linecap="round"/></g></g>' }; } }; };

  // LIV-027 5-tier black-iron pipe + pine plank bookshelf: pipe segments run between the planks (flanges on the boards), Edison bulb, pothos trailing over the front, record crate, blankets
  N.pipe23 = S => { const PN = '#dca96c', IR = '#2b2c30', W = 96, D = 30, TH = 3.2, YS = [7, 42, 77, 112, 147], PX = W / 2 - 6, PZ = D / 2 - 5, H = YS[4] + TH, CN = [[-1, -1], [1, -1], [-1, 1], [1, 1]];
    return { w: W + 6, d: D + 8, topH: H, topW: 60, glow: () => ({ y: 120, r: 60 }), build: () => { const o = [], on = glue(o), R = R0('pipe');
      const PK = YS.map(y => box(0, y, 0, W, TH, D, PN, W_({ r: 0.8 }))); PK.forEach(s => o.push(s));
      PK.forEach((P, i) => { const y = YS[i];
        on(P, rep(3, () => cyl((R() - 0.5) * (W - 20), y + TH + 0.02, (R() - 0.5) * (D - 10), 1.1 + R(), 0.05, '#a06c3a', { n: 10, rz: 0.7, noOut: 1, op: 0.7 })), [0, 1, 0]);
        on(P, [0.9, 2.2].map(t => slabX(0, y + t, D / 2 + 0.05, W - 3, 0.22, 0.1, shade(PN, 0.78), { r: 0, noOut: 1 })), [0, 0, 1]);
        on(P, CN.map(([sx, sz]) => cyl(sx * PX, y + TH, sz * PZ, 2.8, 0.7, IR, M_({ n: 12 }))).concat([].concat(...CN.map(([sx, sz]) => rep(4, q => ball(sx * PX + Math.cos(q * PI / 2 + 0.78) * 2.1, y + TH + 0.8, sz * PZ + Math.sin(q * PI / 2 + 0.78) * 2.1, 0.42, '#5a5c62', M_({ sy: 0.5, k: 2, n: 6, noOut: 1 })))))), [0, 1, 0]);
        on(P, [].concat(rep(2, j => slabX(0, y + TH + 0.02, -D / 2 + 3 + j * (D - 6), W - 2, 0.03, 0.9, shade(PN, 0.85), { r: 0, noOut: 1, op: 0.6 }))), [0, 1, 0]);
        on(P, CN.map(([sx, sz]) => cyl(sx * PX, y - 0.7, sz * PZ, 2.8, 0.7, IR, M_({ n: 12 })))); });
      CN.forEach(([sx, sz]) => { const x = sx * PX, z = sz * PZ; o.push(cyl(x, 0, z, 3.2, 0.8, IR, M_({ n: 12 })), cyl(x, 0.8, z, 1.5, YS[0] - 1.5, IR, M_({ n: 10, shine: 1 })));
        for (let i = 0; i < 4; i++) { const a = YS[i] + TH + 0.7, b = YS[i + 1] - 0.7, Pp = cyl(x, a, z, 1.5, b - a, IR, M_({ n: 10, shine: 1 })); o.push(Pp); on(Pp, [band(x, (a + b) / 2 - 0.8, z, 1.8, 1.6, '#3a3b40', M_({ n: 12 }))]); }
        on(PK[4], [cyl(x, H + 0.7, z, 1.9, 2.4, IR, M_({ n: 10 }))]); });
      // tier 0: blanket rolls + vinyl crate
      const y0 = YS[0] + TH, roll = (cz, cy, col) => { const Rl = solid({ ax: 'x', sh: 'el', c: [cz, cy], a: 5.2, b: 5.2, n: 14, rings: [[-38, 0, 0.9], [-37.2, 0, 1], [-8.8, 0, 1], [-8, 0, 0.9]], col, mat: 'fab', soft: 1 }); o.push(Rl);
        on(Rl, [-30, -16].map(x => solid({ ax: 'x', sh: 'el', c: [cz, cy], a: 5.3, b: 5.3, n: 14, rings: [[x, 0], [x + 1.4, 0]], col: shade(col, 0.72), noOut: 1 }))); };
      roll(-5.4, y0 + 5.2, '#d9a23a'); roll(5.4, y0 + 5.2, '#8fae8a'); roll(0, y0 + 14.25, '#c4643a');
      const CF = box(20, y0, 0, 30, 11, 20, '#c49660', W_({ r: 0.6 })); o.push(CF); on(CF, [box(20, y0 + 6, 10.05, 8, 2.2, 0.1, '#2a1a10', { r: 1, noOut: 1 }), slabX(20, y0 + 3, 10.05, 29, 0.3, 0.1, '#9a7044', { r: 0, noOut: 1 })], [0, 0, 1]);
      on(CF, [box(20, y0 + 11.02, 0, 27.6, 0.05, 17.6, '#3a2616', { r: 0.3, noOut: 1 })], [0, 1, 0]);
      on(CF, rep(10, i => box(8 + i * 2.5, y0 + 11.05, 0, 1.4, i === 6 ? 7.6 : 5.8, 16.6, ['#e8402a', '#2b3f7a', '#f2c14a', '#1d1e21', '#e9dfcc', '#4f9a4a'][i % 6], PL({ r: 0.2 }))));
      // tier 1: books + iron bookend
      const y1 = YS[1] + TH; bk(o, on, R, -40, 27.6, y1, -D / 2 + 1, 22, 28, deco, PK[1]); o.push(box(31, y1, -2, 6, 0.8, 12, IR, M_({ r: 0.2 })), box(28.4, y1 + 0.8, -2, 0.8, 13, 12, IR, M_({ r: 0.2 })));
      // tier 2: concrete pot pothos (vines in the swaying layer), books + red alarm clock
      const y2 = YS[2] + TH, POT = cyl(-28, y2, 0, 6.5, 9, '#a8a59e', { n: 18, mat: 'cer', rg: [[0, 0, 0.84], [9, 0, 1]] }); o.push(POT); on(POT, [cyl(-28, y2 + 9, 0, 5.8, 0.2, '#4a3426', { n: 16, noOut: 1 })]);
      sprig(o, -28, y2 + 9.2, 0, R, null, 10);
      [['#2b3f7a', 22, 2.6], ['#e9dfcc', 20, 2.4], ['#7f2030', 18.6, 2.2]].reduce((yy, [col, w, h]) => { book(22, yy, 0, w, h, 16, col, 0).forEach(s => o.push(s)); return yy + h; }, y2);
      const CK = disc(22, y2 + 12.4, -1, 5, 3.6, '#c8402e', M_({ n: 22 })); o.push(CK); on(CK, [disc(22, y2 + 12.4, 2.6, 4.2, 0.1, '#f6f0e2', { n: 20, noOut: 1 })], [0, 0, 1]);
      o.push(ball(18.6, y2 + 18.2, 0.8, 1.9, BR, M_({ k: 4, n: 10, sy: 0.7 })), ball(25.4, y2 + 18.2, 0.8, 1.9, BR, M_({ k: 4, n: 10, sy: 0.7 })), rod([19, y2 + 7.2, 0.8], [17.6, y2 + 7.2 - 2.4, 0.8], 0.5, '#2a2a2e', M_({ n: 5 })), rod([25, y2 + 7.2, 0.8], [26.4, y2 + 7.2 - 2.4, 0.8], 0.5, '#2a2a2e', M_({ n: 5 })));
      // tier 3: books, Edison bulb on its cord, a photo
      const y3 = YS[3] + TH; bk(o, on, R, -40, 16, y3, -D / 2 + 1, 22, 27, null, PK[3]);
      o.push(rod([26, YS[4] - 0.1, 0], [26, 128.4, 0], 0.25, '#1d1e21', { n: 4 }), cyl(26, 124.6, 0, 1.4, 3.8, BR, M_({ n: 10 })), ball(26, 120.2, 0, 3.6, '#ffe8b0', { op: 0.55, sy: 1.22, k: 6, n: 14, shine: 1 }));
      deco(o, on, () => 0.5, 30.5, y3, 0, 26);
      // top: old camera + cactus
      const y4 = H, CAM = box(-20, y4, 0, 14, 8, 7, '#2c2d31', { r: 1, mat: 'lea' }); o.push(CAM);
      on(CAM, [disc(-20, y4 + 4, 3.5, 3.1, 2.6, '#1a1a1c', M_({ n: 16 })), slabX(-20, y4 + 5.6, 3.55, 13, 2.2, 0.1, '#c9ced3', M_({ r: 0, noOut: 1 }))], [0, 0, 1]); on(CAM, [cyl(-15, y4 + 8, 0, 1.3, 1.2, '#c9ced3', M_({ n: 8 }))]);
      o.push(cyl(18, y4, 0, 4, 5, '#e9e4da', { n: 14, mat: 'cer', rg: [[0, 0, 0.8], [5, 0, 1]] }), ball(18, y4 + 9.2, 0, 3, '#4f8a3e', { sy: 1.6, k: 5, n: 12 }), ball(18, y4 + 14.4, 0, 1.3, '#ff6f9a', { k: 3, n: 8 }));
      return o; },
      layers: [{ build: () => { const o = [], v = (P, sd) => { pipe(P, 0.35, '#3f7a3a', { n: 5 }).forEach(s => o.push(s)); for (let i = 1; i < P.length; i++) { const a = P[i - 1], b = P[i]; [0.35, 0.8].forEach((t, j) => { const q = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t], s2 = (i + j + sd) % 2 ? 1 : -1;
          o.push(ball(q[0] + s2 * 1.6, q[1] - 0.6, q[2] + 0.9, 1.7, (i + j) % 2 ? '#5fae4a' : '#86c46a', { sx: 1.2, sy: 1.25, sz: 0.4, k: 3, n: 8 })); }); } };
          const y2 = YS[2] + TH; v([[-31, y2 + 8.6, 4], [-32, y2 + 5, 11], [-32.6, y2 + 0.8, 15.7], [-33, y2 - 7, 16.3], [-32, y2 - 16, 16.3], [-34, y2 - 25, 16.5]], 0);
          v([[-25, y2 + 8.6, 4], [-24, y2 + 5, 11], [-23.6, y2 + 0.8, 15.7], [-23, y2 - 6, 16.3], [-24.6, y2 - 15, 16.4]], 1); v([[-28, y2 + 8.6, 5], [-28.4, y2 + 4.4, 12], [-28.6, y2 + 0.8, 15.7], [-29.4, y2 - 10, 16.4], [-28, y2 - 22, 16.5], [-29.6, y2 - 31, 16.6]], 0); o.slice(1).forEach(s => s.par = o[0]); return o; },
        wrap: (p, s) => fw(p) > 0 ? '<g>' + sway(p(-29, YS[2] + TH + 0.8, 15.7), 1.6, 7) + s + '</g>' : '' }],
      fx: c => { const q = c.p(26, 120.4, 0), k = c.k; let f = ell(c, q, 9 * k, 10 * k, 'url(#q23eb)', an('opacity', '0.55;0.8;0.6;0.85;0.55', 3.4), 0.7) + '<path d="M' + f1(q[0] - 1.2 * k) + ' ' + f1(q[1] + 1.4 * k) + 'l' + f1(0.6 * k) + ' ' + f1(-2.6 * k) + 'l' + f1(0.6 * k) + ' ' + f1(1.6 * k) + 'l' + f1(0.6 * k) + ' ' + f1(-1.6 * k) + 'l' + f1(0.6 * k) + ' ' + f1(2.6 * k) + '" fill="none" stroke="#ffb53a" stroke-width="' + f1(0.35 * k) + '">' + an('opacity', '0.8;1;0.7;1;0.8', 1.3) + '</path>';
        if (face(c, 0, 1) > 0.1) { const M = frame(c.p, [22, YS[2] + TH + 12.4, 2.75], [1, 0, 0], [0, -1, 0]); f += '<g transform="' + M + '"><path d="M0 0V-2.6M0 0L1.8 0.6" stroke="#2a2a2e" stroke-width="0.45" stroke-linecap="round"/><path d="M0 0V-3.4" stroke="#c8402e" stroke-width="0.2">' + '<animateTransform attributeName="transform" type="rotate" values="0;360" dur="60s" repeatCount="indefinite"/></path><circle r="0.45" fill="#2a2a2e"/></g>'; }
        return { defs: RG('q23eb', '#fff2c4', '#ffc46a', 0.75), front: f }; } }; };

  // LIV-047 built-in archway alcove bookcases: true arches (spandrel strips in the face frame), reading-nook window seat with cushion, pillows, throw, open book, sconce, floating shelf + ivy
  N.arch23 = S => { const PNT = '#eee7d8', BKP = '#ddd3bf', OAK = '#c8925a', W = 176, H = 148, D = 34, ZF = D / 2, FT = 2.4, BAYS = [[-58, 24, 108], [0, 29, 106], [58, 24, 108]];
    return { w: W + 6, d: D + 6, topH: H, topW: 110, glow: () => ({ y: 100, r: 56 }), build: () => { const o = [], on = glue(o), R = R0('arch23'), zb = -D / 2 + 2.2;
      o.push(box(0, 0, 0, W, 8, D, PNT, PL({ r: 0.6 })));
      [-1, 1].forEach(sg => o.push(box(sg * (W / 2 - 3), 8, 0, 6, H - 12, D, PNT, PL({ r: 0.6 })), box(sg * 31.5, 8, 1, 5, H - 12, D - 2, PNT, PL({ r: 0.4 }))));
      o.push(box(0, H - 4, 0.5, W + 4, 4, D + 1, PNT, PL({ r: 0.6 })), box(0, H, 0, W + 8, 2.4, D + 4, mix(PNT, '#ffffff', 0.35), PL({ r: 0.8 })));
      const HD = box(0, 140, ZF - FT / 2, W - 12, 4, FT, PNT, PL({ r: 0.2 })); o.push(HD);
      BAYS.forEach(([cx, hw, spr]) => { const ay = x => spr + Math.sqrt(Math.max(0, hw * hw - (x - cx) * (x - cx))), NS = 10;
        on(HD, rep(NS, s => { const xa = cx - hw + 2 * hw * s / NS, xb = cx - hw + 2 * hw * (s + 1) / NS; return prismZ(ZF - FT, ZF, [[xa, ay(xa)], [xb, ay(xb)], [xb, 140], [xa, 140]], PNT, PL({ noOut: 1 })); }));
        on(HD, pipe(rep(13, i => { const t = PI - i * PI / 12; return [cx + Math.cos(t) * (hw - 0.3), spr + Math.sin(t) * (hw - 0.3), ZF + 0.3]; }), 0.55, mix(PNT, '#ffffff', 0.5), { n: 5, noOut: 1 }));
        on(HD, [box(cx, spr + hw - 1.2, ZF + 0.3, 5, 7, 0.7, mix(PNT, '#ffffff', 0.4), PL({ r: 0.3 }))]); });
      // side bays: oak shelves with LED strips, books, decor
      [BAYS[0], BAYS[2]].forEach(([cx]) => { const SBs = [36, 64, 92].map(y => { const SB = box(cx, y, 0, 48, 2.2, 30, OAK, W_({ r: 0.4 })); o.push(SB); on(SB, [slabX(cx, y - 0.05, 14.6, 44, 0.45, 0.6, '#fff1c8', em({ r: 0 })), slabX(cx, y + 1.1, 15.05, 47, 0.25, 0.1, shade(OAK, 0.78), { r: 0, noOut: 1 })]); return SB; });
        [[8, 26], [38.2, 24], [66.2, 24], [94.2, 22]].forEach(([y, hm], j) => bk(o, on, R, cx - 24, cx + 24, y, zb, 24, hm, j === 3 ? deco : (R() < 0.6 ? deco : null), j ? SBs[j - 1] : null)); });
      // centre: window seat nook
      const BN = box(0, 8, 0, 58, 26, 30, PNT, PL({ r: 0.5 })); o.push(BN);
      const DL = on(BN, [box(-14, 12, 15.35, 26, 18, 0.6, mix(PNT, '#ffffff', 0.25), PL({ r: 0.4 })), box(14, 12, 15.35, 26, 18, 0.6, mix(PNT, '#ffffff', 0.25), PL({ r: 0.4 }))], [0, 0, 1]);
      on(DL[0], [ball(-14, 21, 16.3, 1, BR, M_({ k: 3, n: 8 }))], [0, 0, 1]);
      o.push(cush(0, 34, 0.5, 56, 6, 28, '#6b8fb8', F_({})), pillowZ(-13, 40, -10, 20, 18, 8, '#c99a2e', F_({})), pillowZ(12, 40, -10, 18, 16, 8, '#efe4cc', F_({})));
      o.push(box(16, 40, 4.6, 18, 0.8, 21, '#c96a4a', F_({ r: 0.4 })), box(16, 21.4, 16.3, 18, 19.4, 0.8, '#c96a4a', F_({ r: 0.4 })));
      o.push(box(-4, 40, 6, 17, 0.4, 11.6, '#7f2030', F_({ r: 0.3 })), tilt(box(-8.1, 40.4, 6, 8, 1.2, 11, '#fbf6ea', { r: 0.2, mat: 'fab' }), [0, 0, 1], -0.08, [-4, 40.4, 6]), tilt(box(0.1, 40.4, 6, 8, 1.2, 11, '#fbf6ea', { r: 0.2, mat: 'fab' }), [0, 0, 1], 0.08, [-4, 40.4, 6]));
      o.push(rod([0, 96, -14.4], [0, 98.6, -9], 0.5, BR, M_({ n: 6 })), cyl(0, 98.6, -9, 3.8, 6.4, '#fff2c8', em({ n: 16, noOut: 0, mat: 'cer', rg: [[0, 0, 0.45], [3, 0, 0.85], [6.4, 0, 1]] })));
      const FS = box(0, 112, -9.5, 40, 2, 11, OAK, W_({ r: 0.4 })); o.push(FS);
      o.push(cyl(-13, 114, -9.5, 3.6, 5, '#e9e4da', { n: 14, mat: 'cer', rg: [[0, 0, 0.8], [5, 0, 1]] })); sprig(o, -13, 119, -9.5, R, null, 7);
      on(FS, rep(7, i => ball(-14.5 + (i % 2) * 1.8 - i * 0.3, 111 - i * 2.2, -2.9, 1.5, i % 2 ? '#5fae4a' : '#86c46a', { sx: 1.2, sz: 0.4, k: 3, n: 8 })).concat([rod([-13.6, 112, -3.6], [-16.4, 97.6, -3.2], 0.25, '#3f7a3a', { n: 4 })]));
      bk(o, on, R, -6, 18, 114, -14.8, 9, 14, null);
      return o; },
      layers: backL(() => { const o = [], on = glue(o), BK = slab(0, 8, -D / 2 + 1, W - 12, H - 12, 2, BKP, W_({ r: 0 })); o.push(BK);
        on(BK, rep(13, i => box(-26 + i * 4.33, 40, -14.95, 0.4, 94, 0.1, shade(BKP, 0.86), { r: 0, noOut: 1 })), [0, 0, 1]);
        on(BK, [box(0, 92, -14.7, 4.4, 8, 0.6, BR, M_({ r: 0.4 })), disc(0, 99, -14.98, 13, 0.05, '#fff2c8', em({ n: 20, op: 0.3 }))], [0, 0, 1]); return o; }, [-14.9, [[-82, -34, 8, 36], [-82, -34, 38.2, 64], [-82, -34, 66.2, 92], [-82, -34, 94.2, 132], [34, 82, 8, 36], [34, 82, 38.2, 64], [34, 82, 66.2, 92], [34, 82, 94.2, 132], [-29, 29, 40, 135]]]),
      fx: c => { if (face(c, 0, 1) < 0.05) return {}; const q = c.p(0, 104.4, -9), k = c.k, M = TOP(c, 41.7, -4, 6);
        let f = ell(c, q, 6 * k, 3.4 * k, 'url(#q23sc)', an('opacity', '0.5;0.85;0.6;0.9;0.5', 5), 0.7);
        f += '<g transform="' + M + '"><path d="M0 -5.4H7.6V5.4H0Z" fill="#fffaf0" stroke="#d9cfb8" stroke-width="0.2" opacity="0"><animateTransform attributeName="transform" type="scale" values="1 1;1 1;-1 1;-1 1" keyTimes="0;0.7;0.86;1" dur="9s" repeatCount="indefinite"/>' + '<animate attributeName="opacity" values="0;1;1;0" keyTimes="0;0.68;0.86;1" dur="9s" repeatCount="indefinite"/></path></g>';
        return { defs: RG('q23sc', '#fff6d0', '#ffd88a', 0.9), front: f }; } }; };

  // LIV-067 floor-to-ceiling walnut library: raised-panel cabinets, counter, 3 open bays, brass picture lights, brass rail + rolling ladder that glides along it
  N.lib23 = S => { const WAL = '#5b3820', WD = '#4a2c18', WL = shade(WAL, 1.12), W = 170, H = 150, D = 38, ZF = D / 2, BX = [[-53.75, 50.5], [0, 51], [53.75, 50.5]];
    return { w: W + 6, d: D + 30, topH: 156.4, topW: 110, glow: () => ({ y: 120, r: 80, c: 'url(#gWarm)' }), build: () => { const o = [], on = glue(o), R = R0('lib23');
      o.push(box(0, 0, 0, W, 6, D, WD, W_({ r: 0.6 })));
      [-1, 1].forEach(sg => o.push(box(sg * (W / 2 - 3), 6, 0, 6, H - 6, D, WAL, W_({ r: 0.8 }))));
      const LC = box(0, 6, 0, W - 12, 34, D, WAL, W_({ r: 0.4 })); o.push(LC);
      [-65, -39, -13, 13, 39, 65].forEach((x, i) => { const DR = on(LC, [box(x, 9, ZF + 0.45, 24, 28, 0.8, WAL, W_({ r: 0.5 }))], [0, 0, 1])[0]; on(DR, [box(x, 12, ZF + 1.15, 18, 22, 0.6, WL, W_({ r: 1 })), ball(x + (i % 2 ? -9.6 : 9.6), 24, ZF + 1.5, 1, BR, M_({ k: 3, n: 8 }))], [0, 0, 1]); });
      o.push(box(0, 40, 1, W - 12, 3, D + 2, WL, W_({ r: 0.6 })));
      [-1, 1].forEach(sg => o.push(box(sg * 27, 43, 1, 3, 99, 36, WAL, W_({ r: 0.4 }))));
      BX.forEach(([cx, bw]) => { const SBs = [76, 108].map(y => { const SB = box(cx, y, 0, bw, 2.4, 34, WAL, W_({ r: 0.4 })); o.push(SB); on(SB, [slabX(cx, y + 0.5, 17.05, bw - 1, 1.4, 0.1, WL, { r: 0, noOut: 1 }), slabX(cx, y + 0.35, 17.08, bw - 1, 0.2, 0.05, '#2a170c', { r: 0, noOut: 1 }), slabX(cx, y + 2.05, 17.08, bw - 1, 0.2, 0.05, '#2a170c', { r: 0, noOut: 1 })], [0, 0, 1]); return SB; });
        [[43, 30], [78.4, 27], [110.4, 28]].forEach(([y, hm], j) => bk(o, on, R, cx - bw / 2, cx + bw / 2, y, -16.8, 28, hm, deco, j ? SBs[j - 1] : null)); });
      const HD = box(0, 142, 1, W - 12, 8, 36, WAL, W_({ r: 0.4 })); o.push(HD);
      o.push(box(0, H, 0, W + 4, 3, D + 4, WAL, W_({ r: 0.8 })), box(0, H + 3, -1, W + 10, 3.4, D + 8, WL, W_({ r: 1 })));
      on(HD, [rod([-77, 145, 23], [77, 145, 23], 1.2, BR, M_({ n: 10, shine: 1 }))].concat([-72, -26, 26, 72].map(x => rod([x, 145, 19], [x, 145, 21.8], 0.6, BR, M_({ n: 6 })))));
      BX.forEach(([cx]) => { const L = [rod([cx - 8, 144, 19], [cx - 8, 141.6, 21.6], 0.4, BR, M_({ n: 5 })), rod([cx + 8, 144, 19], [cx + 8, 141.6, 21.6], 0.4, BR, M_({ n: 5 }))], B = slabX(cx, 139.6, 22.6, 24, 2, 3, BR, M_({ r: 0.8, shine: 1 })); on(HD, L.concat([B])); on(B, [slabX(cx, 139.7, 24.15, 22, 0.6, 0.1, '#fff4d0', em({ r: 0 }))], [0, 0, 1]); });
      return o; },
      layers: backL(() => [slab(0, 43, -D / 2 + 1, W - 12, 99, 2, WD, W_({ r: 0 }))], [-16.95, [].concat(...BX.map(([cx, bw]) => [[cx - bw / 2, cx + bw / 2, 43, 76], [cx - bw / 2, cx + bw / 2, 78.4, 108], [cx - bw / 2, cx + bw / 2, 110.4, 142]]))]).concat([{ build: () => { const o = [], lz = y => 34 - y / 145 * 11, WR = '#7a4a2a';
          [-1, 1].forEach(sg => { const x = sg * 9; o.push(rod([x, 2, lz(2)], [x, 143.4, lz(143.4)], 1.1, WR, W_({ n: 8 })), ball(x, 1.8, lz(0), 1.8, '#2c2d31', M_({ k: 3, n: 8 })), box(x, 142.4, 23.2, 2, 3.6, 2.6, BR, M_({ r: 0.6 }))); });
          rep(9, i => { const y = 14 + i * 14.5; o.push(rod([-7.9, y, lz(y)], [7.9, y, lz(y)], 0.9, '#8a5a34', W_({ n: 6 }))); }); return o; },
        wrap: (p, s) => fw(p) > 0 ? '<g>' + slide(p, [0, -48, -48, 46, 46, 0], null, 34, '0;0.16;0.36;0.6;0.82;1') + s + '</g>' : '' }]),
      fx: c => { if (face(c, 0, 1) < 0.2) return {}; let f = ''; BX.forEach(([cx], i) => f += '<path d="' + qd(c, [[cx - 11, 139.4, 21], [cx + 11, 139.4, 21], [cx + 22, 100, 16], [cx - 22, 100, 16]]) + '" fill="url(#q23pl)">' + an('opacity', '0.55;0.85;0.55', 7, n4(-i * 1.6)) + '</path>');
        return { defs: '<linearGradient id="q23pl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff1c4" stop-opacity="0.55"/><stop offset="1" stop-color="#fff1c4" stop-opacity="0"/></linearGradient>', front: f }; } }; };

  // LIV-087 automated robotic archive wall: graphite grid of lit niches (each a soft LED colour), archive boxes, books, jars, sculpture; gantry robot glides on rails and its picker rises/falls carrying a box
  N.arc23 = S => { const FRM = '#2e3036', EDG = '#b9c0c8', W = 172, H = 150, D = 26, COLS = 5, ROWS = 4, x0 = -W / 2 + 4, y0 = 10, cw = (W - 8) / COLS, rh = (H - 16) / ROWS, LED = ['#cfe9ff', '#ffe7c2', '#e2d4ff', '#c9fff0', '#ffd9c9'];
    const GX = x0 + 12;
    return { w: W + 6, d: D + 16, topH: H, topW: 110, build: () => { const o = [], on = glue(o), R = R0('arc23');
      const BS = box(0, 0, 0, W, y0, D, FRM, M_({ r: 0.8 })); o.push(BS);
      const BKS = slab(0, y0, -D / 2 + 1, W - 8, H - 16, 2, '#15171c', M_({ r: 0 })); o.push(BKS);
      [-1, 1].forEach(sg => o.push(box(sg * (W / 2 - 2), y0, 0, 4, H - 16, D, FRM, M_({ r: 0.6 }))));
      const TP = box(0, H - 6, 0, W, 6, D, FRM, M_({ r: 0.8 })); o.push(TP); on(TP, [slabX(0, H - 4, D / 2 + 0.05, W - 2, 1.2, 0.1, EDG, M_({ r: 0, noOut: 1 }))], [0, 0, 1]);
      rep(COLS - 1, i => { const DV = box(x0 + cw * (i + 1), y0, 1, 2, H - 16, D - 2, FRM, M_({ r: 0.3 })); o.push(DV); on(DV, [box(x0 + cw * (i + 1), y0, D / 2 + 0.05, 2, H - 16, 0.1, EDG, M_({ r: 0, noOut: 1 }))], [0, 0, 1]); });
      rep(COLS, i => { const xa = x0 + cw * i + (i ? 1 : 0), xb = x0 + cw * (i + 1) - (i < COLS - 1 ? 1 : 0);
        rep(ROWS - 1, j => { const SB = box((xa + xb) / 2, y0 + rh * (j + 1) - 1, 1, xb - xa, 2, D - 2, FRM, M_({ r: 0.2 })); o.push(SB); on(SB, [slabX((xa + xb) / 2, y0 + rh * (j + 1) - 1, D / 2 + 0.05, xb - xa, 2, 0.1, EDG, M_({ r: 0, noOut: 1 })), box((xa + xb) / 2, y0 + rh * (j + 1) - 0.6, D / 2 + 0.17, 6, 1.2, 0.05, '#f6f6f2', { r: 0.1, noOut: 1 }), box((xa + xb) / 2 - 1, y0 + rh * (j + 1) - 0.2, D / 2 + 0.2, 3, 0.2, 0.03, '#2c2d31', { r: 0, noOut: 1 }), slabX((xa + xb) / 2, y0 + rh * (j + 1) - 1.4, D / 2 - 1.4, xb - xa - 2, 0.4, 0.5, '#ffffff', em({ r: 0 }))]); });
        rep(ROWS, j => { const cx = x0 + cw * (i + 0.5), b = y0 + rh * j + (j ? 1 : 0), t = y0 + rh * (j + 1) - (j < ROWS - 1 ? 1 : 0), hh = t - b, zc = -1, kind = Math.floor(R() * 6);
          on(BKS, [box(cx, b + 1.4, -D / 2 + 2.05, cw - 6, hh - 3.4, 0.1, LED[(i * 2 + j) % 5], em({ r: 1, op: 0.55 }))], [0, 0, 1]);
          if (kind === 0) rep(3, k => { const A = box(cx - 9.4 + k * 9.4, b, zc, 8.4, 10, 15, ['#d8cdb8', '#c9bba0', '#e2d6c0'][k], { r: 0.5, mat: 'fab' }); o.push(A); on(A, [box(cx - 9.4 + k * 9.4, b + 5.4, zc + 7.55, 4.6, 2.4, 0.1, '#ffffff', { r: 0.2, noOut: 1 }), box(cx - 9.4 + k * 9.4, b + 8, zc + 7.55, 3.6, 1, 0.1, '#5a4a3a', { r: 0.4, noOut: 1 })], [0, 0, 1]); });
          else if (kind === 1) bk(o, on, R, cx - cw / 2 + 1.6, cx + cw / 2 - 1.6, b, -D / 2 + 2.4, 15, hh - 5, null);
          else if (kind === 2) o.push(cyl(cx - 5, b, zc, 4.6, 15, ['#2c2d31', '#e9e4da', '#3f6a8a'][Math.floor(R() * 3)], { n: 16, mat: 'cer', rg: [[0, 0, 0.6], [6, 0, 1], [12, 0, 0.6], [15, 0, 0.75]] }), cyl(cx + 6, b, zc + 2, 3.2, 8, '#c8693f', { n: 14, mat: 'cer', rg: [[0, 0, 0.8], [8, 0, 1]] }));
          else if (kind === 3) o.push(box(cx, b, zc, 10, 4, 10, '#1d1e22', M_({ r: 0.6 })), ball(cx, b + 10, zc, 6, ['#d4a548', '#d5dde2', '#e9e4da'][Math.floor(R() * 3)], M_({ k: 7, n: 16, shine: 1 })));
          else if (kind === 4) rep(3, k => { const x = cx - 9 + k * 9, J = cyl(x, b, zc, 3.4, 10 + k * 2, '#dff2f8', { n: 14, op: 0.38, shine: 1 }); o.push(J); on(J, [cyl(x, b + 0.3, zc, 2.9, 5 + k * 2, ['#9fcf6a', '#ffb45a', '#7fb2ff'][k], { n: 12, op: 0.8 }), cyl(x, b + 10 + k * 2, zc, 3, 1.4, '#2c2d31', M_({ n: 12 }))]); });
          else { o.push(box(cx, b, zc, 14, 2, 10, '#1d1e22', M_({ r: 0.5 })), box(cx, b + 2, zc, 8, 8, 8, '#9ff0ff', em({ r: 0.8, op: 0.55, noOut: 0 }))); } }); });
      on(BS, [rod([-80, 7, D / 2 + 1.4], [80, 7, D / 2 + 1.4], 1, CH, M_({ n: 8, shine: 1 })), box(68, 2.4, D / 2 + 0.15, 16, 4.4, 0.2, '#0e1a24', { r: 0.6, noOut: 1 })]);
      on(TP, [rod([-80, H - 3, D / 2 + 1.4], [80, H - 3, D / 2 + 1.4], 1, CH, M_({ n: 8, shine: 1 }))]);
      return o; },
      layers: [{ build: () => [box(GX, y0 - 0.4, D / 2 + 3.6, 3, H - 2 * y0 + 0.8, 2.4, '#c9ced3', M_({ r: 0.6, shine: 1 })), box(GX, 4.6, D / 2 + 3, 8, 5, 3.6, '#2c2d31', M_({ r: 1 })), box(GX, H - 9.6, D / 2 + 3, 8, 5, 3.6, '#2c2d31', M_({ r: 1 })), box(GX, H - 8.6, D / 2 + 4.85, 4, 1, 0.1, '#4fe0ff', em({ r: 0.3 }))],
          wrap: (p, s) => fw(p) > 0 ? '<g>' + slide(p, [0, 0, 66, 66, 132, 132, 0], null, 22, '0;0.1;0.3;0.45;0.65;0.8;1') + s + '</g>' : '' },
        { build: () => { const o = [], A = box(GX, 70, D / 2 + 7.3, 8, 7, 5, '#2c2d31', M_({ r: 1.2 })); o.push(A, box(GX, 62, D / 2 + 7.3, 7, 8, 5, '#d8cdb8', { r: 0.5, mat: 'fab' }));
            glue(o)(A, [box(GX, 73.4, D / 2 + 9.85, 4, 1.2, 0.1, '#4fe0ff', em({ r: 0.4 })), box(GX - 2.6, 71, D / 2 + 9.85, 1, 1, 0.1, '#ff5a5a', em({ r: 0.4 }))], [0, 0, 1]); return o; },
          wrap: (p, s) => fw(p) > 0 ? '<g>' + slide(p, [0, 0, 66, 66, 132, 132, 0], null, 22, '0;0.1;0.3;0.45;0.65;0.8;1') + '<g>' + slide(p, [0, 0, 0, 0, 0, 0, 0], [0, 30, 0, -28, 0, 36, 0], 22, '0;0.2;0.3;0.55;0.65;0.9;1') + s + '</g></g>' : '' }],
      fx: c => { if (face(c, 0, 1) < 0.1) return {}; let f = ''; rep(5, i => { const q = c.p(62 + i * 2.6, 4.6, D / 2 + 0.3); f += '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(0.6 * c.k) + '" fill="' + ['#4fe0ff', '#7fff9a', '#ffd66b', '#4fe0ff', '#ff7a7a'][i] + '">' + an('opacity', '0.2;1;0.2', n4(1.2 + i * 0.37), n4(-i * 0.3)) + '</circle>'; });
        return { front: f }; } }; };

  // ======================= FIREPLACES =======================
  // LIV-015 drafty faux-brick fireplace (printed brick panel, peeling corner) with a little electric space heater glowing in the empty firebox, sock drying in the draft
  N.faux23 = S => { const MO = '#d8cbb6', BRK = ['#b4553c', '#a84a34', '#c0634a'], W = 120, D = 30, OX = 26, OY = 45.4, HY = 4, MY = 74, ZF = D / 2;
    return { w: W + 12, d: D + 16, glow: () => ({ y: 14, r: 60 }), build: () => { const o = [], on = glue(o);
      const HE = box(0, 0, 4, W + 8, HY, D + 8, '#6f6a64', { r: 0.6, mat: 'cer' }); o.push(HE);
      on(HE, [-5, 4, 13].map(z => slabX(0, HY + 0.02, z, W + 6, 0.05, 0.25, '#55504a', { r: 0, noOut: 1 })).concat(rep(7, i => box(-48 + i * 16, HY + 0.02, 4, 0.25, 0.05, D + 6, '#55504a', { r: 0, noOut: 1 }))), [0, 1, 0]);
      const PLf = box(-43, HY, 1, 34, OY - HY, D - 2, MO, W_({ r: 0.4 })), PRt = box(43, HY, 1, 34, OY - HY, D - 2, MO, W_({ r: 0.4 })), LT = box(0, OY, 0, W, MY - OY, D, MO, W_({ r: 0.4 })); o.push(PLf, PRt, LT);
      o.push(box(0, HY, -ZF + 1, W, OY - HY, 2, '#1e1c1b', { r: 0.2 }));
      on(PLf, [box(-OX + 0.3, HY, 1, 0.6, OY - HY, D - 2, '#2a2725', { r: 0, noOut: 1 })], [1, 0, 0]); on(PRt, [box(OX - 0.3, HY, 1, 0.6, OY - HY, D - 2, '#2a2725', { r: 0, noOut: 1 })], [-1, 0, 0]);
      on(LT, [box(54, 66.4, ZF + 0.05, 8.4, 7.4, 0.1, '#c9a676', { r: 0, noOut: 1 })], [0, 0, 1]);
      for (let j = 0; j < 11; j++) { const y = 4.6 + j * 5.9, off = j % 2 ? 6.15 : 0; for (let k = -1; k < 11; k++) { const xa = -60 + off + k * 12.3, xb = xa + 11.4; (y > OY ? [[-60, 60, LT]] : [[-60, -OX, PLf], [OX, 60, PRt]]).forEach(([u, v, P]) => { const a = Math.max(xa, u + 0.3), b = Math.min(xb, v - 0.3); if (b - a < 1.2) return; if (P === LT && b > 49.6 && y + 5 > 66) return;
            const cc = ['#b4553c', '#a84a34', '#c0634a', '#9c4430', '#b85e44', '#aa5238'][((j * 7 + k * 13) % 6 + 6) % 6]; on(P, [box((a + b) / 2, y, ZF + 0.2, b - a, 5, 0.4, cc, { r: 0.5, noOut: 1, mat: 'cer' }), box((a + b) / 2, y + 4.3, ZF + 0.62, b - a - 0.8, 0.4, 0.05, shade(cc, 1.28), { r: 0, noOut: 1 }), box((a + b) / 2, y + 0.25, ZF + 0.62, b - a - 0.8, 0.35, 0.05, shade(cc, 0.72), { r: 0, noOut: 1 })].concat((j + k) % 3 ? [] : [box(a + (b - a) * 0.3, y + 2.2, ZF + 0.63, 0.7, 0.5, 0.05, shade(cc, 0.6), { r: 0.2, noOut: 1 })]), [0, 0, 1]); }); } }
      on(LT, [tilt(box(54.4, 66.4, ZF + 0.45, 9, 7.4, 0.3, BRK[0], { r: 0.3, mat: 'cer' }), [0, 1, 0], -0.5, [49.9, 66.4, ZF + 0.45])]);
      const MT = box(0, MY, 2, W + 10, 4, D + 6, '#a87a4e', W_({ r: 0.6 })); o.push(MT); on(MT, [box(0, MY + 1.2, D / 2 + 5.05, W + 8, 0.5, 0.1, '#c9a06a', { r: 0, noOut: 1 })], [0, 0, 1]);
      on(MT, pipe([[60.4, MY + 1.8, D / 2 + 5.1], [61.6, MY + 0.6, D / 2 + 6.2], [62, MY - 1.2, D / 2 + 5.6]], 0.3, '#c9a06a', { n: 4, noOut: 1 }));
      // space heater + cord
      const HT = box(0, HY, -1, 28, 20, 12, '#ece6da', PL({ r: 2 })); o.push(HT);
      const GR = on(HT, [box(0, HY + 3, 5.15, 22, 13, 0.3, '#2b2b2e', { r: 1, noOut: 1 })], [0, 0, 1])[0];
      on(GR, rep(3, i => box(0, HY + 5 + i * 3.8, 5.45, 19, 1.1, 0.3, '#ff7a2a', em({ r: 0.5 }))), [0, 0, 1]);
      on(HT, [box(-3, HY + 20, -1, 10, 1.4, 2, '#d8d0c2', PL({ r: 0.6 })), cyl(10, HY + 20, 2, 1.6, 1.4, '#3a3a3e', PL({ n: 10 }))]);
      on(HE, pipe([[-14.4, HY + 1.4, -4], [-20, HY + 0.6, 2], [-22, HY + 0.6, 10], [-25, HY + 0.6, 18], [-34, HY + 0.6, 21], [-50, HY + 0.6, 21]], 0.5, '#f2efe8', PL({ n: 5 })).concat([box(-52.4, HY, 21, 3, 1.6, 2.6, '#f2efe8', PL({ r: 0.5 }))]));
      o.push( ball(44, HY + 1.2, 18, 1.8, '#a8a29a', F_({ sy: 0.6, k: 3, n: 8 })));
      // mantel: plastic clock, candle stubs
      o.push(disc(-36, MY + 4 + 6, 6, 6, 1.6, '#f2efe8', PL({ n: 22 })), box(-36, MY + 4, 6.8, 6, 0.8, 2, '#d8d0c2', PL({ r: 0.3 })));
      o.push(cyl(26, MY + 4, 4, 2.2, 5, '#f4e9d0', { n: 12, mat: 'cer' }), rod([26, MY + 9, 4], [26, MY + 10.2, 4], 0.18, '#2a2020', { n: 4 }), cyl(32, MY + 4, 7, 1.8, 3.2, '#e86f8a', { n: 12, mat: 'cer' }));
      return o; },
      layers: [{ build: () => { const o = [], on = glue(o), z = ZF + 1.4, L = box(14, 60, z, 4.4, 8, 1.4, '#e8e2d4', F_({ r: 0.6 })); o.push(L, box(15.6, 56, z, 7.6, 4, 1.4, '#e8e2d4', F_({ r: 1 })), ball(14, 68.6, ZF + 1.2, 0.9, '#e8402a', PL({ k: 3, n: 8 })));
          on(L, [62, 65].map(y => box(14, y, z + 0.75, 4.5, 1, 0.1, '#d9483b', { r: 0, noOut: 1 })), [0, 0, 1]); return o; },
        wrap: (p, s) => fw(p) > 0 ? '<g>' + sway(p(14, 68.6, ZF + 1.2), 5, 3.8) + s + '</g>' : '' }],
      fx: c => { const out = { defs: '', front: '' }; if (face(c, 0, 1) < 0.05) return out; const k = c.k;
        out.front += '<path d="' + qd(c, [[-11, HY + 3, 5.6], [11, HY + 3, 5.6], [11, HY + 16, 5.6], [-11, HY + 16, 5.6]]) + '" fill="#ff8a3a">' + an('opacity', '0.25;0.6;0.4;0.65;0.25', 2.8) + '</path>';
        out.front += fxEll(c, 0, HY + 0.1, 12, 18, 'url(#q23ht)', an('opacity', '0.5;0.9;0.6;0.9;0.5', 2.8));
        const M = frame(c.p, [-36, MY + 10, 7.7], [1, 0, 0], [0, -1, 0]); out.front += '<g transform="' + M + '"><circle r="5" fill="none" stroke="#c9c2b4" stroke-width="0.3"/>' + rep(12, i => { const a = i * PI / 6; return '<circle cx="' + f1(Math.cos(a) * 4.2) + '" cy="' + f1(Math.sin(a) * 4.2) + '" r="0.25" fill="#5a5450"/>'; }).join('') + '<path d="M0 0L-1.6 -1.6M0 0V-3.6" stroke="#2a2a2e" stroke-width="0.45" stroke-linecap="round"/><path d="M0 0.8V-3.8" stroke="#d9483b" stroke-width="0.2"><animateTransform attributeName="transform" type="rotate" values="0;360" dur="60s" repeatCount="indefinite"/></path></g>';
        const q = c.p(26, MY + 12.4, 4); out.front += '<g transform="translate(' + P2(q) + ') scale(' + f1(k) + ')"><ellipse cy="-1.4" rx="3.4" ry="3.8" fill="url(#q23cf)">' + an('opacity', '0.4;0.8;0.5;0.75;0.4', 1.6) + '</ellipse><path d="M0 -3.6Q1.6 -1.2 0.4 0.6Q-1.4 0 0 -3.6Z" fill="#ffcf4a" stroke="#ff8a2a" stroke-width="0.2"><animateTransform attributeName="transform" type="skewX" values="-14;-4;-18;-8;-14" dur="1.7s" repeatCount="indefinite"/></path></g>';
        const W0 = frame(c.p, [-OX, OY, ZF + 0.7], [1, 0, 0], [0, -1, 0]); out.front += '<g transform="' + W0 + '" opacity="0.6"><g><animateTransform attributeName="transform" type="skewX" values="0;3;0;-2;0" dur="5s" repeatCount="indefinite"/><path d="M0 9Q3 6 9 0M0 5Q2.6 3 5 0M0 2Q1 1 2 0M0 9Q4 9 6.4 4.8Q8 3 9 0" fill="none" stroke="#f4f0ea" stroke-width="0.18"/></g></g>';
        out.defs = RG('q23ht', '#ffb05a', '#ff8a3a', 0.5) + RG('q23cf', '#fff3b0', '#ffb347', 0.8); return out; } }; };

  // LIV-035 cast-iron electric stove: slate hearth pad, cabriole legs, cast relief side panels, glass door with LED flames over glowing logs, flue pipe, red kettle steaming on top, birch-log basket
  N.stove23 = S => { const IRN = '#26272b', IRL = shade(IRN, 1.35), PAD = '#3d4046';
    return { w: 84, d: 62, glow: () => ({ y: 26, r: 60 }), build: () => { const o = [], on = glue(o);
      o.push(box(0, 0, 6, 78, 3, 56, PAD, { r: 1, mat: 'cer', bev: 0.8 }));
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => o.push(cyl(sx * 19, 3, sz * 11, 2.6, 9, IRN, M_({ n: 10, rg: [[0, 0, 1.3], [2, 0, 0.8], [6, 0, 0.7], [9, 0, 1]] }))));
      const BD = box(0, 12, 0, 48, 34, 30, IRN, M_({ r: 1.6 })); o.push(BD);
      on(BD, [box(0, 12, 15.8, 48, 3, 1.6, IRN, M_({ r: 0.6 }))]);
      [-1, 1].forEach(sg => { const P = on(BD, [box(sg * 24.05, 16, 0, 0.6, 26, 24, IRL, M_({ r: 0.6 }))], [sg, 0, 0])[0];
        on(P, [box(sg * 24.4, 19, 0, 0.3, 20, 18, IRN, M_({ r: 2, noOut: 1 }))].concat([[-6, 29], [6, 29], [0, 23], [0, 35]].map(([z, y]) => ball(sg * 24.5, y, z, 1.6, IRL, M_({ sx: 0.3, k: 3, n: 10 })))).concat([solid({ ax: 'x', sh: 'el', c: [0, 29], a: 3.4, b: 3.4, n: 14, rings: [[sg * 24.5, 0], [sg * 24.9, 0]], col: IRL, mat: 'metal' })]), [sg, 0, 0]); });
      on(BD, [].concat(...[-22.6, 22.6].map(x => rep(6, i => ball(x, 18 + i * 5, 15.2, 0.55, IRL, M_({ sz: 0.5, k: 3, n: 8, noOut: 1 }))))), [0, 0, 1]);
      on(BD, [box(0, 13.4, 16.65, 10, 1.6, 0.1, GOLD, M_({ r: 0.2, noOut: 1 }))].concat(rep(6, i => box(-20 + i * 2.2, 13.2, 16.65, 1.2, 1.4, 0.05, '#0e0e10', { r: 0.4, noOut: 1 }))).concat(rep(6, i => box(9 + i * 2.2, 13.2, 16.65, 1.2, 1.4, 0.05, '#0e0e10', { r: 0.4, noOut: 1 }))), [0, 0, 1]);
      const DF = on(BD, [box(0, 17, 15.55, 36, 24, 1, '#1d1e21', M_({ r: 0.8 }))], [0, 0, 1])[0];
      on(DF, [box(0, 19.4, 16.1, 29.4, 19.2, 0.1, '#0c0c0d', { r: 0.8, noOut: 1 }), box(0, 20, 16.15, 28, 18, 0.2, '#1a0d08', { r: 0.6, noOut: 1 }), box(0, 38.8, 16.12, 30, 0.5, 0.06, '#5a5c62', { r: 0, noOut: 1 }), cyl(-18.4, 21, 16.4, 1, 3, '#3a3b40', M_({ n: 8 })), cyl(-18.4, 34, 16.4, 1, 3, '#3a3b40', M_({ n: 8 }))], [0, 0, 1]);
      on(DF, pipe([[16, 32, 16.05], [16, 32, 18.6], [16, 25, 18.6], [16, 25, 16.05]], 0.5, '#b9b2a6', M_({ n: 6 })), [0, 0, 1]);
      const TP = box(0, 46, 0, 54, 2.6, 36, IRN, M_({ r: 1.2 })); o.push(TP); on(TP, [box(0, 48.6, 0, 50, 1.2, 32, IRL, M_({ r: 1 }))]);
      o.push(cyl(0, 48.6, -4, 7.4, 4, IRN, M_({ n: 18 })));
      const FL = cyl(0, 52.6, -4, 6, 96, '#2e2f33', M_({ n: 18, shine: 1 })); o.push(FL); on(FL, [80, 112].map(y => band(0, y, -4, 6.05, 1.2, '#3e4046', M_({ n: 18 }))).concat([rod([6, 70, -4], [9, 70, -4], 0.5, '#b9b2a6', M_({ n: 5 }))]));
      // kettle
      const KB = ball(14, 54.9, 6, 6.4, '#c0392b', M_({ sy: 0.8, k: 6, n: 16, shine: 1 })); o.push(KB);
      on(KB, [cyl(14, 59.6, 6, 2.6, 1, '#a8302a', M_({ n: 12 })), ball(14, 61.2, 6, 1, '#1d1e21', M_({ k: 3, n: 8 }))]);
      pipe([[19.6, 54, 6], [22.6, 57.4, 6], [24.2, 59.2, 6]], 0.8, '#c0392b', M_({ n: 6 })).forEach(s => on(KB, [s]));
      on(KB, pipe([[9.4, 59, 6], [11, 64, 6], [17, 64, 6], [18.6, 59, 6]], 0.45, '#1d1e21', M_({ n: 6 })));
      // birch log basket + remote
      const BA = cyl(-32, 3, 22, 6, 8, '#b98a58', F_({ n: 18, soft: 0, rg: [[0, 0, 0.9], [8, 0, 1]] })); o.push(BA); on(BA, [band(-32, 9.6, 22, 6.05, 1.2, '#8a6440'), band(-32, 4.6, 22, 5.5, 0.9, '#8a6440')]);
      [[20, 13.2], [24.2, 13.2], [22.1, 16.9]].forEach(([z, y]) => { const LG = solid({ ax: 'x', sh: 'el', c: [z, y], a: 2.1, b: 2.1, n: 12, rings: [[-38.5, 0], [-25.5, 0]], col: '#ece6da', mat: 'wood' }); o.push(LG);
        on(LG, [solid({ ax: 'x', sh: 'el', c: [z, y], a: 1.8, b: 1.8, n: 10, rings: [[-25.5, 0], [-25.4, 0]], col: '#d9b48a', noOut: 1 }), box(-32, y + 1.6, z, 1.6, 0.5, 1.4, '#3a3230', { r: 0.2, noOut: 1 }), box(-29, y + 1.7, z + 0.6, 1, 0.4, 1.2, '#3a3230', { r: 0.2, noOut: 1 })]); });
      const RM = box(27, 3, 26, 3.4, 1.2, 8, '#1d1e21', PL({ r: 0.6 })); o.push(RM); on(RM, rep(4, i => cyl(27, 4.2, 23.6 + i * 1.6, 0.5, 0.2, i ? '#9aa3a8' : '#d9483b', { n: 6, noOut: 1 })), [0, 1, 0]);
      return o; },
      fx: c => { const k = c.k, out = { defs: RG('q23sg', '#ffb05a', '#ff7a2a', 0.5), front: '' };
        rep(3, i => { const a = c.p(24.6, 60, 6), b = n4(-i * 1.3); out.front += '<ellipse cx="' + f1(a[0]) + '" cy="' + f1(a[1]) + '" rx="' + f1(1.6 * k) + '" ry="' + f1(1.2 * k) + '" fill="#ffffff" opacity="0">' + an('cy', f1(a[1]) + ';' + f1(a[1] - 18 * k), 3.9, b) + an('cx', f1(a[0]) + ';' + f1(a[0] + 4 * k), 3.9, b) + an('rx', f1(1.2 * k) + ';' + f1(4.6 * k), 3.9, b) + an('opacity', '0;0.55;0', 3.9, b) + '</ellipse>'; });
        if (face(c, 0, 1) < 0.05) return out;
        const F = fireIn(c, 'q23sw', [[-14, 20, 16.3], [14, 20, 16.3], [14, 38, 16.3], [-14, 38, 16.3]], [[-6, 22.4, 12, 0.42], [0.5, 22.4, 12.6, 0.5], [6.6, 22.4, 12, 0.42]]);
        const lg = c.p(0, 21.4, 16.3); out.defs += F.defs;
        out.front += '<g clip-path="url(#q23sw)"><ellipse cx="' + f1(lg[0]) + '" cy="' + f1(lg[1]) + '" rx="' + f1(13 * k) + '" ry="' + f1(4.4 * k) + '" fill="url(#q23sg)">' + an('opacity', '0.6;1;0.75;1;0.6', 2.2) + '</ellipse><rect x="' + f1(lg[0] - 10 * k) + '" y="' + f1(lg[1] - 2.2 * k) + '" width="' + f1(20 * k) + '" height="' + f1(2.4 * k) + '" rx="' + f1(1.2 * k) + '" fill="#4a2a18"/>' + F.g + '<path d="' + qd(c, [[-12, 38, 16.3], [-6, 38, 16.3], [-14, 26, 16.3], [-14, 32, 16.3]]) + '" fill="#ffffff" opacity="0.12"/></g>';
        out.front += fxEll(c, 0, 3.1, 26, 14, 'url(#q23sg)', an('opacity', '0.15;0.32;0.2;0.3;0.15', 2.2)); return out; } }; };

  // LIV-055 classic white painted mantel: fluted pilasters, capitals, frieze with plaque + rosettes, dentil crown, slate surround with brass trim, ceramic gas logs on a grate with blue-based flames, brass mesh screen, candlesticks + leaning mirror
  N.mantel23 = S => { const PNT = '#f4f1ea', PL2 = mix(PNT, '#ffffff', 0.4), SL = '#2c2e33', IRN = '#26272b', D = 40, ZF = D / 2;
    return { w: 144, d: 66, glow: () => ({ y: 18, r: 72 }), build: () => { const o = [], on = glue(o);
      o.push(box(0, 0, 6, 140, 3, 52, '#18191c', { r: 0.8, mat: 'cer', shine: 1 }));
      const PI2 = [-1, 1].map(sg => box(sg * 51.5, 3, 0, 27, 58, D, PNT, PL({ r: 0.4 }))), SLT = [-1, 1].map(sg => box(sg * 34, 3, 0, 8, 50, D, SL, { r: 0.2, mat: 'cer' })), ST = box(0, 53, 0, 76, 8, D, SL, { r: 0.2, mat: 'cer' }), FR = box(0, 61, 0, 130, 25, D, PNT, PL({ r: 0.4 }));
      PI2.concat(SLT, [ST, FR]).forEach(s => o.push(s));
      const FB = box(0, 3, -18.5, 60, 50, 3, '#5e3426', { r: 0.2, mat: 'cer' }); o.push(FB);
      on(FB, [].concat(...rep(8, r => rep(7, kk => { const x0 = -30 + (kk - (r % 2) * 0.5) * 10, a = Math.max(-29.8, x0 + 0.3), b = Math.min(29.8, x0 + 9.7); return b - a > 1 ? box((a + b) / 2, 3 + r * 6.25 + 0.3, -16.98, b - a, 5.6, 0.04, ['#6a3a2a', '#5a3022', '#734232', '#4e2a1e'][(r * 3 + kk * 5) % 4], { r: 0, noOut: 1 }) : null; }))).filter(Boolean), [0, 0, 1]);
      on(FB, rep(7, r => slabX(0, 3 + (r + 1) * 6.25, -16.95, 59, 0.5, 0.1, '#2a1610', { r: 0, noOut: 1 })).concat([].concat(...rep(8, r => rep(5, kk => box(-30 + (kk + 1 - (r % 2) * 0.5) * 10, 3 + r * 6.25, -16.95, 0.5, 6.25, 0.1, '#2a1610', { r: 0, noOut: 1 }))))), [0, 0, 1]);
      on(SLT[0], [box(-29.7, 3, -1, 0.6, 50, D - 6, '#3a2620', { r: 0, noOut: 1 })], [1, 0, 0]); on(SLT[1], [box(29.7, 3, -1, 0.6, 50, D - 6, '#3a2620', { r: 0, noOut: 1 })], [-1, 0, 0]);
      on(SLT[0], [box(-30.4, 3, ZF + 0.2, 1.2, 50.6, 0.4, BR, M_({ r: 0 }))], [0, 0, 1]); on(SLT[1], [box(30.4, 3, ZF + 0.2, 1.2, 50.6, 0.4, BR, M_({ r: 0 }))], [0, 0, 1]); on(ST, [box(0, 52.4, ZF + 0.2, 62, 1.2, 0.4, BR, M_({ r: 0 }))], [0, 0, 1]); on(FB, [0, 1, 2].map(i => box(0, 46 - i * 3, -16.9, 56 - i * 10, 7 + i * 3, 0.05, '#0a0605', { r: 3, noOut: 1, op: 0.28 })), [0, 0, 1]);
      [-1, 1].forEach((sg, i) => { const x = sg * 51.5, PIL = on(PI2[i], [box(x, 3, ZF + 0.9, 18, 52, 1.8, PNT, PL({ r: 0.3 }))], [0, 0, 1])[0];
        on(PIL, rep(4, kk => cyl(x + (kk - 1.5) * 3.6, 11, ZF + 1.8, 0.8, 42, shade(PNT, 0.84), { n: 8, noOut: 1 })), [0, 0, 1]);
        on(PI2[i], [box(x, 3, ZF + 1.1, 21, 6, 2.2, PL2, PL({ r: 0.3 })), box(x, 55, ZF + 1.1, 21, 6, 2.2, PL2, PL({ r: 0.3 })), slabX(x, 5.8, ZF + 2.35, 20, 0.3, 0.1, shade(PNT, 0.8), { r: 0, noOut: 1 }), disc(x - 8, 58, ZF + 3.3, 1.6, 0.6, PL2, { n: 12 }), disc(x + 8, 58, ZF + 3.3, 1.6, 0.6, PL2, { n: 12 }), disc(x - 8, 58, ZF + 3.9, 0.7, 0.2, shade(PNT, 0.8), { n: 8, noOut: 1 }), disc(x + 8, 58, ZF + 3.9, 0.7, 0.2, shade(PNT, 0.8), { n: 8, noOut: 1 })]);
        on(FR, [box(x, 61, ZF + 1, 21, 25, 2, PNT, PL({ r: 0.3 })), disc(x, 73.5, ZF + 2, 4.5, 1, PL2, { n: 16 }), disc(x, 73.5, ZF + 3, 1.8, 0.6, shade(PNT, 0.9), { n: 10, noOut: 1 })]); });
      on(FR, [disc(0, 73.5, ZF, 18, 0.9, PL2, { a: 20, b: 7.5, n: 28 }), disc(0, 73.5, ZF + 0.9, 15, 0.3, shade(PNT, 0.93), { a: 15, b: 4.6, n: 24, noOut: 1 })]);
      const CR = box(0, 86, 1, 134, 2, D + 2, PNT, PL({ r: 0.3 })); o.push(CR); on(CR, rep(26, i => box(-62.5 + i * 5, 86.2, 22.3, 2.6, 1.6, 0.6, PL2, { r: 0.2, noOut: 1 })), [0, 0, 1]);
      const SH5 = box(0, 88, 2, 140, 4, D + 6, PL2, PL({ r: 0.8 })); o.push(SH5); on(SH5, [slabX(0, 89.2, 25.05, 139, 0.3, 0.1, shade(PNT, 0.82), { r: 0, noOut: 1 }), slabX(0, 90.8, 25.05, 139, 0.25, 0.1, '#ffffff', { r: 0, noOut: 1 })], [0, 0, 1]);
      // grate, ember bed, ceramic logs
      o.push(box(0, 3, 0, 32, 0.4, 18, '#ff7a2a', em({ op: 0.55, r: 2 })));
      [-18, 18].forEach(x => { o.push(rod([x, 6, -11], [x, 6, 11], 0.8, IRN, M_({ n: 8 }))); [-10, 10].forEach(z => o.push(rod([x, 3, z], [x, 5.2, z], 0.7, IRN, M_({ n: 6 })))); });
      [-8, 8].forEach(z => o.push(rod([-20, 7.6, z], [20, 7.6, z], 0.8, IRN, M_({ n: 8 }))));
      const LA = rod([-20, 11, 6], [20, 11, 6], 2.6, '#6a5442', { n: 12, mat: 'cer' }), LB = rod([-18, 11.2, -6], [19, 11.6, -6], 2.8, '#5e4a3a', { n: 12, mat: 'cer' }), LC = rod([-12, 16.6, -4], [14, 16, 3], 2.2, '#725a46', { n: 12, mat: 'cer' }); o.push(LA, LB, LC);
      on(LA, [solid({ ax: 'x', sh: 'el', c: [6, 11], a: 2.2, b: 2.2, n: 12, rings: [[20, 0], [20.15, 0]], col: '#2a1a12', noOut: 1 }), ball(-6, 13.3, 7.4, 1.8, '#ff8a3a', em({ sy: 0.4, k: 3, n: 8 })), ball(8, 13.2, 7.6, 1.4, '#ff8a3a', em({ sy: 0.4, k: 3, n: 8 }))]);
      // mantel top: leaning mirror, candlesticks, vase, books + carriage clock
      const MP = [0, 92, -16], RT = rotF([1, 0, 0], -0.06), MF = tilt(box(0, 92, -17, 46, 40, 2, '#c9a04a', M_({ r: 0.8 })), [1, 0, 0], -0.06, MP); o.push(MF);
      on(MF, [tilt(box(0, 95, -15.95, 40, 34, 0.1, '#cfe3ea', { r: 0.4, noOut: 1, shine: 1 }), [1, 0, 0], -0.06, MP)], RT([0, 0, 1]));
      [-54, 54].forEach(x => { o.push(cyl(x, 92, 6, 3.4, 1.4, BR, M_({ n: 14 })), cyl(x, 93.4, 6, 1.2, 10, BR, M_({ n: 10, rg: [[0, 0, 1.4], [3, 0, 0.8], [7, 0, 1], [10, 0, 0.8]] })), cyl(x, 103.4, 6, 2.2, 1.6, BR, M_({ n: 12 })), cyl(x, 105, 6, 1.4, 12, '#f8f2e4', { n: 12, mat: 'cer' }), rod([x, 117, 6], [x, 118.2, 6], 0.18, '#2a2020', { n: 4 })); });
      const VS = cyl(-32, 92, 4, 4, 12, '#e9e4da', { n: 16, mat: 'cer', rg: [[0, 0, 0.7], [5, 0, 1], [10, 0, 0.6], [12, 0, 0.7]] }); o.push(VS);
      rep(4, i => { const a = -0.6 + i * 0.4, tp = [-32 + Math.sin(a) * 9, 116 + (i % 2) * 3, 4 + (i % 2 ? 2 : -2)]; on(VS, [rod([-32, 103, 4], tp, 0.3, '#6a7a5a', { n: 4 })]); rep(3, j => { const t = 0.45 + j * 0.25; on(VS, [ball(-32 + (tp[0] + 32) * t + (j % 2 ? 1.4 : -1.4), 103 + (tp[1] - 103) * t, 4 + (tp[2] - 4) * t, 1.3, '#9fb5a0', { sz: 0.35, k: 3, n: 8 })]); }); });
      [['#2b3f7a', 20, 2.8], ['#e9dfcc', 18, 2.4]].reduce((yy, [col, w, h]) => { book(32, yy, 6, w, h, 13, col, 0.05).forEach(s => o.push(s)); return yy + h; }, 92);
      const CL = box(32, 97.2, 6, 6, 7, 4, BR, M_({ r: 0.8, shine: 1 })); o.push(CL); on(CL, [disc(32, 101.2, 8.05, 2.2, 0.1, '#f6f0e2', { n: 14, noOut: 1 })], [0, 0, 1]);
      return o; },
      fx: c => { const out = { defs: '', front: '' }, k = c.k; if (face(c, 0, 1) < 0.05) return out;
        const F = fireIn(c, 'q23mf', [[-30, 3, ZF], [30, 3, ZF], [30, 53, ZF], [-30, 53, ZF]], [[-12, 12.6, 6, 0.7], [0, 13.6, 4, 0.85], [12, 12.6, 6, 0.7], [-5, 18, -3, 0.6], [6, 18, -2, 0.62]]);
        const ib = c.p(0, 18, -4); let g = '<ellipse cx="' + f1(ib[0]) + '" cy="' + f1(ib[1]) + '" rx="' + f1(30 * k) + '" ry="' + f1(22 * k) + '" fill="url(#q23mi)">' + an('opacity', '0.5;0.85;0.6;0.8;0.5', 2.4) + '</ellipse>';
        [[-12, 6], [0, 5], [12, 6]].forEach(([x, z], i) => { const q = c.p(x, 10.6, z + 2.4); g += '<ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + f1(5 * k) + '" ry="' + f1(1.4 * k) + '" fill="#5aa8ff" opacity="0.6">' + an('opacity', '0.35;0.75;0.45;0.7;0.35', n4(1.1 + i * 0.2), n4(-i * 0.3)) + '</ellipse>'; });
        out.defs += F.defs + RG('q23mi', '#ffb05a', '#ff6a2a', 0.45) + RG('q23mc', '#fff3b0', '#ffb347', 0.8) + '<pattern id="q23mm" width="2" height="2" patternUnits="userSpaceOnUse"><path d="M0 0L2 2M2 0L0 2" stroke="#1d1e21" stroke-width="0.25"/></pattern>';
        out.front += '<g clip-path="url(#q23mf)">' + g + F.g + '</g>';
        [-54, 54].forEach((x, i) => { const q = c.p(x, 120.2, 6); out.front += '<g transform="translate(' + P2(q) + ') scale(' + f1(k) + ')"><ellipse cy="-1.2" rx="3.2" ry="3.8" fill="url(#q23mc)">' + an('opacity', '0.4;0.8;0.5;0.75;0.4', 1.5, n4(-i * 0.5)) + '</ellipse><path d="M0 -3.4Q1.5 -1 0.4 0.6Q-1.3 0 0 -3.4Z" fill="#ffcf4a" stroke="#ff8a2a" stroke-width="0.2"><animateTransform attributeName="transform" type="skewX" values="0;7;-5;4;0" dur="1.4s" begin="' + n4(-i * 0.4) + 's" repeatCount="indefinite"/></path></g>'; });
        const RT = rotF([1, 0, 0], -0.06), MO = rp(RT, [0, 92, -16], [-20, 129, -15.85]); out.front += '<g transform="' + frame(c.p, MO, RT([1, 0, 0]), RT([0, -1, 0])) + '"><clipPath id="q23mr"><rect width="40" height="34" rx="0.4"/></clipPath><g clip-path="url(#q23mr)"><rect x="-30" width="14" height="34" fill="#ffffff" opacity="0.35" transform="skewX(-20)">' + an('x', '-30;70;70', 11) + '</rect></g></g>';
        if (face(c, 0, 1) > 0.3) out.front += '<g transform="' + frame(c.p, [-30, 34, 27], [1, 0, 0], [0, -1, 0]) + '"><path d="M0 31V6Q30 -3 60 6V31Z" fill="url(#q23mm)" stroke="#b8862e" stroke-width="1.2"/><path d="M0 31V6Q30 -3 60 6V31Z" fill="#000000" opacity="0.12"/><path d="M-1 31H4M56 31H61" stroke="#b8862e" stroke-width="1.6" stroke-linecap="round"/><circle cx="30" cy="0.6" r="1.4" fill="#d4a548"/></g>';
        return out; } }; };

  // LIV-075 suspended mid-century black steel wood-burning fireplace: egg-shaped bowl hangs on its flue over a round plate, real logs burn in the round opening, sparks rise; steel log holder
  N.susp23 = S => { const BK = '#2a2b2e', OY = 42, OA = 14, OB = 10, OZ = 28.95;
    return { w: 132, d: 84, glow: () => ({ y: 34, r: 74 }), build: () => { const o = [], on = glue(o);
      const PLT = cyl(0, 0, 0, 34, 2.4, '#3a3c40', { n: 32, mat: 'cer', rg: [[0, 0, 0.98], [2.4, 0, 1]] }); o.push(PLT); on(PLT, [cyl(0, 2.4, 0, 30, 0.3, '#55585e', { n: 30, mat: 'cer', noOut: 1 }), band(0, 0.6, 0, 34.05, 1.2, '#8a8f96', M_({ n: 30 }))]);
      const BW = RD.H16.loft([[22, 0, 0, 6, 6], [24, 0, 0, 14, 14], [28, 0, 0, 21, 21], [34, 0, 0, 26, 26], [42, 0, 0, 27, 27], [50, 0, 0, 25, 25], [58, 0, 0, 20, 20], [64, 0, 0, 14, 14], [68, 0, 0, 8, 8]], BK, { n: 32, mat: 'metal', shine: 1 }); o.push(BW);
      on(BW, [band(0, 30.6, 0, 23.9, 0.5, '#3e4046', M_({ n: 30 })), band(0, 53.5, 0, 23.4, 0.5, '#3e4046', M_({ n: 30 }))]);
      on(PLT, rep(16, i => { const a = i / 16 * 2 * PI; return ball(Math.cos(a) * 32.4, 2.45, Math.sin(a) * 32.4, 0.6, '#8a8f96', M_({ sy: 0.4, k: 2, n: 6, noOut: 1 })); }));
      const ST = on(BW, [solid({ ax: 'z', sh: 'el', c: [0, OY], a: 15.5, b: 11.5, n: 28, rings: [[18, 0], [28, 0]], col: BK, mat: 'metal' })], [0, 0, 1])[0];
      on(ST, [solid({ ax: 'z', sh: 'el', c: [0, OY], a: 16.4, b: 12.4, n: 28, rings: [[27.6, 0], [28.8, 0]], col: '#3a3b40', mat: 'metal', shine: 1 }), disc(0, OY, 28.8, OA, 0.15, '#120d0a', { a: OA, b: OB, n: 28, noOut: 1 })], [0, 0, 1]);
      o.push(cyl(0, 68, 0, 5.4, 118, BK, M_({ n: 18, shine: 1 })), cyl(0, 186, 0, 9, 4, '#3a3b40', M_({ n: 18 })));
      on(o[o.length - 2], [band(0, 92, 0, 5.45, 1, '#3a3b40', M_({ n: 16 }))]);
      // log holder
      [-12, 10].forEach(z => o.push(box(50, 0, z, 26.4, 1.2, 1.4, BK, M_({ r: 0.3 }))));
      [37.4, 62.6].forEach(x => [-12, 10].forEach(z => o.push(box(x, 1.2, z, 1.2, 15, 1.4, BK, M_({ r: 0.3 })))));
      [[42.4, 5], [50, 5], [57.6, 5], [46.2, 11.58], [53.8, 11.58], [50, 18.16]].forEach(([x, y], i) => { const LG = solid({ ax: 'z', sh: 'el', c: [x, y], a: 3.8, b: 3.6, n: 12, rings: [[-13, 0], [11, 0]], col: i % 2 ? '#7a5234' : '#8a5a34', mat: 'wood' }); o.push(LG);
        on(LG, [disc(x, y, 11, 3.2, 0.3, '#d9b48a', W_({ n: 12, noOut: 1 })), disc(x, y, 11.3, 1.8, 0.08, '#b88a5a', { n: 10, noOut: 1 }), disc(x, y, 11.38, 0.6, 0.06, '#8a5a34', { n: 8, noOut: 1 })], [0, 0, 1]); });
      return o; },
      fx: c => { const k = c.k, out = { defs: RG('q23sh', '#ffcf6a', '#ff7a22', 0.95) + RG('q23sp', '#ffb05a', '#ff7a2a', 0.45), front: '' };
        out.front += fxEll(c, 0, 2.8, 14, 20, 'url(#q23sp)', an('opacity', '0.4;0.8;0.5;0.75;0.4', 1.8));
        if (face(c, 0, 1) < 0.05) return out;
        const EP = rep(28, i => { const t = i / 28 * 2 * PI; return [Math.cos(t) * OA, OY + Math.sin(t) * OB, OZ]; }), q = c.p(0, OY - 6, 24);
        const F = RD.H.fire(c, [[-3.4, OY - 6.4, 23, 0.5], [3.6, OY - 6, 23.4, 0.44]]);
        out.defs += '<clipPath id="q23so"><path d="' + qd(c, EP) + '"/></clipPath>' + RG('q23ht2', '#c98a4a', '#6a4a8a', 0.4);
        const hc = c.p(0, OY, 29); out.front = '<ellipse cx="' + f1(hc[0]) + '" cy="' + f1(hc[1]) + '" rx="' + f1(24 * k) + '" ry="' + f1(19 * k) + '" fill="url(#q23ht2)" opacity="0.55"/>' + out.front;
        out.front += '<g clip-path="url(#q23so)"><ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + f1(13 * k) + '" ry="' + f1(6 * k) + '" fill="url(#q23sh)">' + an('opacity', '0.6;1;0.75;0.95;0.6', 1.8) + '</ellipse><ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1] + 2.6 * k) + '" rx="' + f1(11 * k) + '" ry="' + f1(2.6 * k) + '" fill="#8a8580"/><ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1] + 2 * k) + '" rx="' + f1(8 * k) + '" ry="' + f1(1.4 * k) + '" fill="#ff7a2a" opacity="0.6">' + an('opacity', '0.3;0.7;0.4', 1.3) + '</ellipse>'
          + '<rect x="' + f1(q[0] - 9 * k) + '" y="' + f1(q[1] - 1.4 * k) + '" width="' + f1(18 * k) + '" height="' + f1(2.6 * k) + '" rx="' + f1(1.3 * k) + '" fill="#5a3418" transform="rotate(-6 ' + P2(q) + ')"/><rect x="' + f1(q[0] - 8 * k) + '" y="' + f1(q[1] + 0.2 * k) + '" width="' + f1(16 * k) + '" height="' + f1(2.4 * k) + '" rx="' + f1(1.2 * k) + '" fill="#6a3e1e" transform="rotate(8 ' + P2(q) + ')"/>' + F.over + '</g>';
        rep(4, i => { const a = c.p(-2 + i * 1.4, OY + 6, OZ + 1), b = n4(-i * 0.9), dx = (i % 2 ? 1 : -1) * 5 * k; out.front += '<circle cx="' + f1(a[0]) + '" cy="' + f1(a[1]) + '" r="' + f1(0.45 * k) + '" fill="#ffd66b" opacity="0">' + an('cy', f1(a[1]) + ';' + f1(a[1] - 26 * k), 2.6, b) + an('cx', f1(a[0]) + ';' + f1(a[0] + dx), 2.6, b) + an('opacity', '0;1;0', 2.6, b) + '</circle>'; });
        return out; } }; };

  // LIV-095 three-sided floating bio-ethanol + water-vapour fireplace: black stone slab hovering on a hidden plinth (warm under-glow), glass on three sides, steel burner trough with flames + glowing mist, river stones
  N.etha23 = S => { const ST = '#1b1d22', GL = '#d6f0fa', W = 112, D = 40;
    return { w: W + 4, d: D + 6, glow: () => ({ y: 8, r: 70 }), build: () => { const o = [], on = glue(o), R = R0('etha');
      o.push(box(0, 0, 0, 60, 6, 16, '#0d0e10', { r: 0.6, mat: 'cer' }));
      const SB = box(0, 6, 0, W, 9, D, ST, { r: 1.4, mat: 'cer', shine: 1 }); o.push(SB);
      on(SB, [slabX(0, 6.1, D / 2 + 0.05, W - 6, 0.6, 0.1, '#ffb45a', em({ r: 0 })), slabX(0, 13.4, D / 2 + 0.05, W - 3, 0.5, 0.1, '#8a8f96', M_({ r: 0, noOut: 1 })), box(44, 9, D / 2 + 0.05, 10, 3, 0.1, '#0e1a24', { r: 0.6, noOut: 1 })].concat(pipe([[-W / 2 + 2, 11.8, D / 2 + 0.05], [-30, 9.6, D / 2 + 0.05], [-12, 10.6, D / 2 + 0.05], [8, 8.4, D / 2 + 0.05]], 0.12, '#4a4d55', { n: 4, noOut: 1 })), [0, 0, 1]);
      on(SB, pipe([[-W / 2 + 3, 15.02, -16], [-36, 15.02, -9], [-30, 15.02, 6], [-44, 15.02, 18]], 0.12, '#3e4148', { n: 4, noOut: 1 }).concat(pipe([[40, 15.02, -18], [34, 15.02, -6], [46, 15.02, 8], [52, 15.02, 17]], 0.1, '#3e4148', { n: 4, noOut: 1 })), [0, 1, 0]);
      const BT = box(0, 15, 0, 80, 2, 10, CH, M_({ r: 0.6, shine: 1 })); o.push(BT); on(BT, [box(0, 17.02, 0, 74, 0.05, 3.4, '#0e0e10', { r: 0.6, noOut: 1 })], [0, 1, 0]);
      rep(26, i => { const side = i % 2 ? 1 : -1, x = -48 + (i * 37 % 96) + R() * 2, z = side * (8.4 + R() * 7.4), r = 1.5 + R() * 1.1; on(SB, [ball(x, 15 + r * 0.55, z, r, ['#f4f1ea', '#dcd8cf', '#b9b4aa', '#e8e4dc'][i % 4], { sy: 0.55, k: 4, n: 10, mat: 'cer' })]); });
      const FP = slab(0, 15, D / 2 - 1.3, W - 4, 36, 0.6, GL, { r: 0.3, op: 0.16, shine: 1 }), BP = slab(0, 15, -D / 2 + 1.3, W - 4, 36, 0.6, '#14161a', { r: 0.3, op: 0.92, shine: 1 }); o.push(FP, BP);
      const SP = [-1, 1].map(sg => box(sg * (W / 2 - 2.3), 15, 0, 0.6, 36, D - 3.2, GL, { r: 0.2, op: 0.16, shine: 1 })); SP.forEach(s => o.push(s));
      on(FP, [slabX(0, 50.6, D / 2 - 1.3, W - 3.4, 0.8, 0.9, CH, M_({ r: 0.2 }))]); SP.forEach((s, i) => on(s, [box((i ? 1 : -1) * (W / 2 - 2.3), 50.6, 0, 0.9, 0.8, D - 3.2, CH, M_({ r: 0.2 }))]));
      return o; },
      fx: c => { const k = c.k, out = { defs: RG('q23eu', '#ffb45a', '#ff8a2a', 0.6) + RG('q23ev', '#ffd9a0', '#ffffff', 0.7), front: '', under: fxEll(c, 0, 0.2, 0, 52, 'url(#q23eu)', an('opacity', '0.55;0.85;0.55', 4)) };
        if (face(c, 0, 1) < -0.25) return out;
        const L = rep(6, i => [-30 + i * 12, 17, 0, 0.5 + (i % 2) * 0.08]); out.front += RD.H.fire(c, L).over;
        rep(7, i => { const a = c.p(-33 + i * 11, 22, 0), b = n4(-i * 0.7), d = n4(3.6 + (i % 3) * 0.5); out.front += '<ellipse cx="' + f1(a[0]) + '" cy="' + f1(a[1]) + '" rx="' + f1(4 * k) + '" ry="' + f1(2.4 * k) + '" fill="url(#q23ev)" opacity="0">' + an('cy', f1(a[1]) + ';' + f1(a[1] - 24 * k), d, b) + an('rx', f1(3 * k) + ';' + f1(8 * k), d, b) + an('opacity', '0;0.55;0', d, b) + '</ellipse>'; });
        if (face(c, 0, 1) > 0.15) out.front += '<g transform="' + frame(c.p, [-W / 2 + 2, 51, D / 2 - 0.9], [1, 0, 0], [0, -1, 0]) + '"><path d="M10 0L2 36M16 0L8 36M70 0L62 36" stroke="#ffffff" stroke-width="0.8" opacity="0.28"/><path d="M13 0L5 36" stroke="#ffffff" stroke-width="2.4" opacity="0.1"/></g>';
        const r = c.p(0, 15.1, 10); out.front += '<ellipse cx="' + f1(r[0]) + '" cy="' + f1(r[1]) + '" rx="' + f1(40 * k) + '" ry="' + f1(4 * k) + '" fill="#ffb45a" opacity="0.18">' + an('opacity', '0.1;0.24;0.14;0.22;0.1', 1.9) + '</ellipse>';
        return out; } }; };

  // ---------- catalog edits ----------
  RD.SET23 = {
    'LIV-007': { spec: 'cube23', note: 'A cheap white particleboard 3-cube tower. The laminate is peeling off one shelf edge and the feet are swollen. A grey canvas bin with a sock flopping out, a row of books with one leaning over, board games, a coin jar, and a pen mug and rubber duck on top.' },
    'LIV-027': { spec: 'pipe23', live: 'Edison bulb', note: 'Five thick pine planks on black iron pipes with flanges at every board. Blanket rolls and a crate of records at the bottom, books with an iron bookend, a pothos whose vines trail and sway over the front, a red alarm clock ticking, a glowing Edison bulb on its cord and an old camera on top.' },
    'LIV-047': { spec: 'arch23', live: 'Reading nook', note: 'Painted built-in bookcases with three true arches. The side bays are full of books on oak shelves with LED strips. The middle is a window seat with a blue cushion, pillows, a throw, an open book whose pages turn, a brass sconce and a little floating shelf with trailing ivy.' },
    'LIV-067': { spec: 'lib23', live: 'Rolling ladder', note: 'A floor-to-ceiling walnut library: raised-panel cupboards below, three bays of books and curios above, brass picture lights washing the shelves, and a rolling ladder that slowly glides along its brass rail.' },
    'LIV-087': { spec: 'arc23', live: 'Robot picker', note: 'A graphite grid of softly lit niches holding archive boxes, books, specimen jars, vases and sculptures. A robot gantry glides along its rails and the picker rises and falls carrying a box, while status lights blink on the base.' },
    'LIV-015': { spec: 'faux23', live: 'Space heater', note: 'A drafty fake fireplace with a printed brick panel peeling at one corner. Inside the empty firebox a little space heater glows orange, its cord trailing across the hearth. A plastic clock ticks on the mantel, a candle stub flickers sideways and a sock dries on a pin, swinging in the draft.' },
    'LIV-035': { spec: 'stove23', live: 'Flames + steam', note: 'A cast-iron electric stove on cabriole legs over a slate hearth pad, with cast relief side panels and a glass door showing flickering flames over glowing logs. A flue pipe rises behind, a red kettle steams on top, and a basket of birch logs and the remote sit on the pad.' },
    'LIV-055': { spec: 'mantel23', live: 'Gas fire', note: 'A classic white mantel with fluted pilasters, a frieze with a plaque and rosettes and a dentil crown over a black slate surround with brass trim. Ceramic gas logs burn on a grate with blue-based flames behind a brass mesh screen; brass candlesticks flicker either side of a leaning mirror.' },
    'LIV-075': { spec: 'susp23', live: 'Wood fire', note: 'A black steel egg that hangs on its flue over a round slate plate. Real logs burn in its round opening, sparks drift up and the plate glows. A steel holder of split logs stands beside it.' },
    'LIV-095': { spec: 'etha23', live: 'Floating flames', note: 'A black stone slab that seems to float on a warm under-glow, with glass on three sides. A long steel burner sends up a row of flames and softly glowing water-vapour mist between white river stones.' },
  };
  const edit22 = RD.edit;
  RD.edit = rows => edit22(rows).map(r => RD.SET23[r.id] ? Object.assign({}, r, RD.SET23[r.id]) : r);
  RD.H23 = { bk, deco, face, fw, qd, fireIn, slide, sway, BC };
  RD.PLUS23 = 1;
})();
