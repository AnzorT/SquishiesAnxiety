// Squad House Beach catalog: 100 pieces (20 slots x 5 tiers, room BCH) drawn with the House 3D engine + RenoDraw toolkits.
// Surfaces (Beach Sand / Pier & Boardwalk / Beach Lights) are thumbnails cut from the live Beach scene (beach.js); the room paints them itself.
// Activities via D.act / seat k: sun, nap, roast, splash, ride, sit, build, surf, treat, dig; Beach Games = r.play 'game' (2 players).
(function boot() {
  const RD = window.RenoDraw, X = window.House3D, BE = window.Beach; if (!(RD && RD.PLUS9 && RD.H3 && RD.H7 && X && X.K && BE)) { setTimeout(boot, 30); return; } if (RD.BEACH) return;
  const K = X.K, { box, cush, cyl, ball, slab, arcW, prismZ, shade, mix, f1 } = K;
  const { rep, rng, n4, P2, planeH, bbOf, mt, wd, cer, pt } = RD.H3;
  const { atV, tube, curve, water, WP, flames, FDEF, glowE, isPlay, ellPts } = RD.H7;
  const N = RD.N, PI = Math.PI, GOLD = '#e2b14a', WH = '#ffffff', em = RD.H.em, fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {});
  const T = S => (S.row && S.row.tier) || 1;
  const SAND = '#e6c68a', SANDD = '#c9a466';
  const PP = (d, f, s, w, ex) => `<path d="${d}" fill="${f || 'none'}"${s ? ` stroke="${s}" stroke-width="${w || 1}" stroke-linejoin="round" stroke-linecap="round"` : ''}${ex || ''}/>`;
  const PQ = (p, pts) => 'M' + pts.map(q => P2(p(...q))).join('L') + 'Z';
  const AT = (type, vals, d, b) => `<animateTransform attributeName="transform" type="${type}" values="${vals}" dur="${n4(d)}s"${b ? ` begin="${n4(b)}s"` : ''} repeatCount="indefinite"/>`;
  const AN = (a, vals, d, b) => `<animate attributeName="${a}" values="${vals}" dur="${n4(d)}s"${b ? ` begin="${n4(b)}s"` : ''} repeatCount="indefinite"/>`;
  const sway = (q, a, d, b) => atV('rotate', [`${-a} ${P2(q)}`, `${a} ${P2(q)}`, `${-a} ${P2(q)}`], d, b);
  const ink = c => shade(c, 0.55);
  // canopy cone (umbrella / roof) drawn as lit wedges, sorted back to front; o: { y rim height, h apex rise, R, n, cols, fringe, scallop, x, z, droop }
  function cone(p, k, o) { const n = o.n || 12, cx = o.x || 0, cz = o.z || 0, A = [cx, o.y + o.h, cz], R = o.R, dr = o.droop == null ? 3 : o.droop; let s = '', fr = '';
    const rim = i => { const t = i / n * 2 * PI + (o.a0 || 0); return [cx + R * Math.cos(t), o.y - dr, cz + R * Math.sin(t)]; };
    const W = rep(n, i => { const a = rim(i), b = rim(i + 1), m = [(a[0] + b[0]) / 2, a[1], (a[2] + b[2]) / 2]; return { i, a, b, m, dz: p(...m)[1] }; }).sort((u, v) => u.dz - v.dz);
    W.forEach(w => { const c = o.cols[w.i % o.cols.length], th = (w.i + 0.5) / n * 2 * PI + (o.a0 || 0), li = 0.5 + 0.5 * Math.cos(th - 2.4), col = mix(shade(c, 0.8 + li * 0.32), '#ffffff', li * 0.12);
      const mid = [(w.a[0] + w.b[0]) / 2 + Math.cos(th) * R * 0.08, w.a[1] - (o.scallop ? 4 : 0), (w.a[2] + w.b[2]) / 2 + Math.sin(th) * R * 0.08];
      s += PP(`M${P2(p(...A))}L${P2(p(...w.a))}${o.scallop ? `Q${P2(p(...mid))} ${P2(p(...w.b))}` : `L${P2(p(...w.b))}`}Z`, col, ink(c), 0.9);
      if (o.fringe && p(...w.m)[1] > p(cx, o.y, cz)[1] - 2) { rep(3, j => { const u = (j + 0.5) / 3, q = [w.a[0] + (w.b[0] - w.a[0]) * u, w.a[1], w.a[2] + (w.b[2] - w.a[2]) * u], q1 = p(...q), q2 = p(q[0], q[1] - (o.fl || 7), q[2]); fr += PP(`M${P2(q1)}L${P2(q2)}`, 'none', o.fringe, 1.6); }); }
      if (o.tassel && p(...w.m)[1] > p(cx, o.y, cz)[1]) { const q = p(...w.a); fr += PP(`M${P2(q)}l0 5`, 'none', o.tassel, 1) + `<circle cx="${f1(q[0])}" cy="${f1(q[1] + 6)}" r="1.6" fill="${o.tassel}"/>`; } });
    return s + fr; }
  // palm tree in fx: base (x, z), height H, lean (model units at top), returns svg + bounds pts
  function palm(p, k, x, z, H, lean, seed, o) { o = o || {}; const R = rng(seed), top = [x + lean, H, z + lean * 0.3], base = [x, 0, z], mid = [x + lean * 0.15, H * 0.55, z];
    const pts = curve(base, mid, top, 8), sp = pts.map(q => p(...q)), tc = o.trunk || '#b07a44'; let s = tube(sp, (o.tw || 4.2), k, tc, mix(tc, '#ffffff', 0.35), ink(tc));
    sp.slice(1, -1).forEach((q, i) => s += PP(`M${f1(q[0] - 4 * k)} ${f1(q[1])}h${f1(8 * k)}`, 'none', ink(tc), 0.8, ' opacity="0.6"'));
    const tq = p(...top); let fr = ''; const nf = o.nf || 8, L0 = o.L || 34;
    rep(nf, i => { const a = i / nf * 2 * PI + R() * 0.3, L = L0 * (0.8 + R() * 0.35), ex = top[0] + Math.cos(a) * L, ez = top[2] + Math.sin(a) * L * 0.7, ey = H - L * 0.42, m1 = [top[0] + Math.cos(a) * L * 0.5, H + 6, top[2] + Math.sin(a) * L * 0.35];
      const e2 = p(ex, ey, ez), m2 = p(...m1), c = o.leaf ? o.leaf[i % o.leaf.length] : (i % 2 ? '#3f9a42' : '#52b04a'), w = 6 * k;
      fr += { z: e2[1], s: PP(`M${P2(tq)}Q${f1(m2[0] - w * Math.sin(a))} ${f1(m2[1] - w)} ${P2(e2)}Q${f1(m2[0] + w * Math.sin(a))} ${f1(m2[1] + w * 0.4)} ${P2(tq)}Z`, c, ink(c), 0.8) + PP(`M${P2(tq)}Q${P2(m2)} ${P2(e2)}`, 'none', mix(c, '#ffffff', 0.3), 0.6, ' opacity="0.7"') }.s; });
    let co = ''; if (o.nuts !== 0) rep(o.nuts || 3, i => { const q = p(top[0] + (i - 1) * 3, H - 4, top[2] + 3); co += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(3.2 * k)}" fill="${o.nutC || '#7a4e24'}" stroke="#3a2410" stroke-width="0.6"/>`; });
    s += `<g>${sway(tq, o.sw || 2.4, 4.6 + R(), -R() * 3)}${fr}${co}</g>`;
    return { s, pts: [p(...base), tq, p(top[0] - L0, H, top[2]), p(top[0] + L0, H, top[2]), p(top[0], H + 10, top[2]), p(top[0], H - L0 * 0.5, top[2] + L0 * 0.7)] }; }
  const crab = (q, k, col, d, b, dx) => `<g transform="translate(${P2(q)}) scale(${n4(k)})"><g>${AT('translate', `0 0;${dx} 0;0 0;${-dx * 0.6} 0;0 0`, d, b)}<path d="M-5 0Q-5 -4 0 -4Q5 -4 5 0Q0 2 -5 0Z" fill="${col}" stroke="${ink(col)}" stroke-width="0.7"/><path d="M-5 -1L-8 -4M5 -1L8 -4M-4 0L-7 2M4 0L7 2" stroke="${ink(col)}" stroke-width="0.8" stroke-linecap="round"/><circle cx="-2" cy="-5" r="1" fill="#2a1a10"/><circle cx="2" cy="-5" r="1" fill="#2a1a10"/></g></g>`;
  const star5 = (q, k, col, rot) => `<path transform="translate(${P2(q)}) scale(${n4(k)}) rotate(${rot || 0})" d="M0-5L1.4-1.6L5-1.6L2.2 0.6L3.2 4.4L0 2.2L-3.2 4.4L-2.2 0.6L-5-1.6L-1.4-1.6Z" fill="${col}" stroke="${ink(col)}" stroke-width="0.6"/>`;
  const ripples = (p, rx, rz, n, d) => `<g transform="${planeH(p, 0.4)}">${rep(n || 2, j => `<ellipse cx="0" cy="0" rx="${rx}" ry="${rz}" fill="none" stroke="#ffffff" stroke-width="1.4"><animate attributeName="rx" values="${rx};${rx * 1.35}" dur="${d || 2.6}s" begin="${-j * (d || 2.6) / 2}s" repeatCount="indefinite"/><animate attributeName="ry" values="${rz};${rz * 1.35}" dur="${d || 2.6}s" begin="${-j * (d || 2.6) / 2}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.8;0" dur="${d || 2.6}s" begin="${-j * (d || 2.6) / 2}s" repeatCount="indefinite"/></ellipse>`).join('')}</g>`;
  const HUE = '<filter id="bhBlue" x="-50%" y="-50%" width="200%" height="200%"><feColorMatrix type="hueRotate" values="190"/></filter>';
  const GLW = '<radialGradient id="bhG" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff2b0" stop-opacity="0.8"/><stop offset="1" stop-color="#fff2b0" stop-opacity="0"/></radialGradient><radialGradient id="bhC" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#bffcff" stop-opacity="0.85"/><stop offset="1" stop-color="#4fe0f0" stop-opacity="0"/></radialGradient>';
  const glowAt = (q, r, id, op) => `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(r)}" ry="${f1(r * 0.8)}" fill="url(#${id || 'bhG'})" opacity="${op || 1}">${AN('opacity', `${op || 1};${n4((op || 1) * 0.6)};${op || 1}`, 2.2)}</ellipse>`;

  // ======================= SUN LOUNGER =======================
  N.bLounger = S => { const t = T(S), H = [13, 18, 20, 22, 18][t - 1];
    const D = { w: t === 4 ? 160 : 150, d: t === 4 ? 104 : 62, act: 'sun', seats: t === 4 ? [{ x: -18, z: 4, h: H + 8, k: 'sun' }, { x: 34, z: 4, h: H + 8, k: 'sun' }] : [{ x: 14, z: 2, h: H + 4, k: 'sun' }] };
    const back = (z0, z1, c, y0, th, o2) => prismZ(z0, z1, [[-40, y0], [-36, y0 + th], [-62, y0 + 40 + th], [-68, y0 + 40]], c, o2 || {});
    D.build = P => { const o = [];
      if (t === 1) { [[-60, -22], [-60, 22], [58, -22], [58, 22]].forEach(([x, z]) => o.push(cyl(x, 0, z, 1.6, H, '#b8bec4', mt({ n: 6 })))); [-23, 23].forEach(z => o.push(box(0, H, z, 128, 2, 2.4, '#c9cdd2', mt({ r: 1 }))));
        rep(8, i => { if (i === 3) return; o.push(box(-38 + i * 14, H - 0.4, 0, 9, 1.4, 44, i % 2 ? '#f1f0e6' : '#7fbf7a', fb({ r: 0.6 }))); }); o.push(back(-22, 22, '#7fbf7a', H, 2, fb()), box(-12, H - 3, 18, 8, 3, 6, '#7fbf7a', fb({ r: 0.6 }))); }
      else if (t === 2) { [[-58, -24], [-58, 24], [56, -24], [56, 24]].forEach(([x, z]) => o.push(box(x, 0, z, 4, H, 4, '#b8804a', wd({ r: 0.8 })))); [-25, 25].forEach(z => o.push(box(0, H - 3, z, 124, 4, 3, '#c48a52', wd({ r: 1 }))));
        [[-24, -8, '#e2554a'], [-8, 8, '#fffaf1'], [8, 24, '#e2554a']].forEach(([a, b, c]) => { o.push(box(10, H - 1, (a + b) / 2, 100, 2.6, b - a, c, fb({ r: 0.6 })), back(a, b, c, H - 1, 2.6, fb())); }); }
      else if (t === 3) { o.push(box(0, 4, 0, 140, H - 6, 56, '#a8683a', wd({ r: 3, bev: 1.4 })), ...[[-64, -24], [-64, 24], [62, -24], [62, 24]].map(([x, z]) => box(x, 0, z, 6, 5, 6, '#7a4a24', wd({ r: 1 }))));
        o.push(cush(14, H - 2, 0, 104, 8, 54, '#2f4f86', fb()), back(-26, 26, '#a8683a', H - 2, 3, wd()), back(-25, 25, '#2f4f86', H + 1, 6, fb()), ball(-44, H + 18, 0, 8, '#fffaf1', fb({ sx: 2.4, sy: 0.8, k: 4 }))); }
      else if (t === 4) { // canopy posts stand just outside the base (not through it) and stop under the canopy; pillows sit on the cushion
        o.push(box(0, 0, 0, 150, 12, 100, '#f4f1ea', pt({ r: 4, bev: 2 })), cush(0, 12, 0, 142, 12, 92, '#ffffff', fb()), ...[[-77.6, -46], [-77.6, 46], [77.6, -46], [77.6, 46]].map(([x, z]) => cyl(x, 0, z, 2.6, 94, '#e2b14a', mt({ n: 8 }))),
        box(0, 94, 0, 160, 5, 104, '#f4f1ea', fb({ r: 3 })), ...[-40, 0, 40].map((x, i) => ball(x, 24, -38, 9, ['#3fb0c8', '#ffd66b', '#3fb0c8'][i], fb({ sx: 1.8, sy: 1.1, sz: 0.7, k: 4 })))); }
      else { o.push(ball(10, H - 4, 0, 52, '#ffe6dc', cer({ sx: 1.4, sy: 0.28, sz: 0.62, k: 4, n: 20, shine: 1 })), prismZ(-26, 26, [[-44, H - 8], [-30, H], [-64, H + 44], [-78, H + 30]], '#ffd6c8', cer({ shine: 1 })), ball(-48, H + 16, 0, 9, '#fffaf6', cer({ sx: 2.2, sy: 0.9, k: 5, shine: 1 })), cyl(10, 0, 0, 10, 3, '#bfeffa', em({ n: 16 }))); }
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', defs = '';
      if (t === 4) { rep(14, i => { const x = -78 + i * 12, q = p(x, 94, 52); f += PP(`M${P2(q)}l0 ${f1(7 * k)}`, 'none', '#3fb0c8', 1.4); }); }
      if (t === 5) { defs = GLW; f = rep(7, i => { const a = -0.7 + i * 0.23, q0 = p(10, H + 9, 0), q1 = p(10 + Math.cos(a) * 66, H + 6, Math.sin(a) * 32); return PP(`M${P2(q0)}L${P2(q1)}`, 'none', '#e8a898', 1, ' opacity="0.7"'); }).join('') + glowAt(p(10, 0, 0), 40 * k, 'bhC', 0.7); }
      if (t === 1) f += PP(PQ(p, [[-8, H + 1.2, -10], [4, H + 1.2, -6], [-2, H + 1.2, 4]]), '#5a4a3a', '', 0, ' opacity="0.5"');
      return { defs, front: f, bb: bbOf([p(-80, 0, -50), p(80, 0, 50), p(-80, 100, 0), p(80, 100, 0), p(-70, H + 50, 0)], 4) }; };
    return D; };

  // ======================= BEACH UMBRELLA =======================
  const UMB = [{ cols: ['#c9b8a0', '#b4c4bc'], R: 52, h: 18, y: 72, pole: '#9aa1a6', towel: ['#b8b0a0'] }, { cols: ['#ff6a5a', '#ffb340', '#ffe066', '#6fd06a', '#4fb0f0', '#a07af0'], R: 58, h: 20, y: 80, pole: '#ffffff', towel: ['#4fb0f0', '#ffffff'] },
    { cols: ['#d8b46a', '#c9a45a'], R: 56, h: 24, y: 78, pole: '#8a5a2c', towel: ['#e3946a', '#fff1d8'], fringe: '#c49a50', n: 16 }, { cols: ['#ffffff', '#2f9fb8'], R: 60, h: 20, y: 82, pole: '#e2b14a', towel: ['#2f9fb8', '#ffffff'], scallop: 1, tassel: '#e2b14a' },
    { cols: ['#ffe6dc', '#ffd0c4'], R: 64, h: 26, y: 86, pole: '#f4e6d8', towel: ['#ffd6c8', '#fffaf6'], scallop: 1, n: 14 }];
  N.bUmbrella = S => { const t = T(S), U = UMB[t - 1];
    const D = { w: 130, d: 110, act: 'nap', seats: [{ x: -4, z: 20, h: 3, k: 'nap' }] };
    D.build = P => { const o = [cyl(0, 0, -16, 2.2, U.y + U.h, U.pole, mt({ n: 8 })), cyl(0, 0, -16, 6, 2, SANDD, pt({ n: 12 }))];
      U.towel.forEach((c, i) => o.push(box(-4, 0, 20 + (i - (U.towel.length - 1) / 2) * 18, 74, 1.4, U.towel.length > 1 ? 18 : 40, c, fb({ r: 1 }))));
      if (t === 5) o.push(ball(0, U.y + U.h + 6, -16, 6, '#fffaf6', cer({ shine: 1, k: 5 }))); return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = cone(p, k, { y: U.y, h: U.h, R: U.R, n: U.n || 12, cols: U.cols, z: -16, fringe: U.fringe, scallop: U.scallop, tassel: U.tassel, fl: 9 }), defs = GLW;
      if (t === 1) { const q = p(18, U.y + 6, 10); f += PP(`M${f1(q[0] - 7 * k)} ${f1(q[1] - 4 * k)}l${f1(12 * k)} ${f1(-2 * k)}l${f1(1 * k)} ${f1(8 * k)}l${f1(-12 * k)} ${f1(2 * k)}Z`, '#9fa88a', '#5e584e', 0.8) + PP(`M${f1(q[0] - 5 * k)} ${f1(q[1] - 2 * k)}l${f1(8 * k)} ${f1(3 * k)}`, 'none', '#5e584e', 0.6, ' stroke-dasharray="1.4 1.4"'); }
      if (t === 2) { const q = p(30, 0.4, 24); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><ellipse cx="0" cy="0" rx="4" ry="2" fill="#ff6a5a" stroke="#8a2a20" stroke-width="0.6"/><ellipse cx="9" cy="1" rx="4" ry="2" fill="#ff6a5a" stroke="#8a2a20" stroke-width="0.6"/></g>`; }
      if (t === 5) f += glowAt(p(0, U.y + U.h + 6, -16), 22 * k, 'bhG', 0.8);
      return { defs, front: f, bb: bbOf([p(-U.R, U.y, -16 - U.R), p(U.R, U.y, -16 + U.R), p(0, U.y + U.h + 12, -16), p(-50, 0, 50), p(46, 0, 50), p(-U.R, U.y - 12, -16), p(U.R, U.y - 12, -16)], 4) }; };
    return D; };

  // ======================= BEACH TOWEL =======================
  N.bTowel = S => { const t = T(S), round = t === 3;
    const D = { w: round ? 96 : 110, d: round ? 96 : 60, flat: 1, act: 'sun', seats: [{ x: round ? 0 : 6, z: 2, h: t === 4 ? 7 : 2, k: 'sun' }] };
    D.build = P => { const o = [];
      if (t === 1) o.push(box(0, 0, 0, 100, 1.2, 54, '#c9c4b6', fb({ r: 2 })));
      else if (t === 2) [['#3fb0c8', -18], ['#ffffff', -6], ['#ffd23f', 6], ['#ffffff', 18]].forEach(([c, z]) => o.push(box(0, 0, z, 104, 1.4, 12.2, c, fb({ r: 1 }))));
      else if (t === 3) o.push(cyl(0, 0, 0, 46, 1.4, '#e3946a', fb({ n: 28 })), cyl(0, 1.4, 0, 34, 0.4, '#ffd66b', fb({ n: 28 })), cyl(0, 1.8, 0, 20, 0.4, '#2f9fb8', fb({ n: 24 })), cyl(0, 2.2, 0, 8, 0.4, '#fff1d8', fb({ n: 16 })));
      else if (t === 4) o.push(cush(0, 0, 0, 108, 6, 58, '#f4efe4', fb()), ball(-42, 9, -6, 8, '#2f9fb8', fb({ sx: 1.2, sy: 0.6, sz: 1.7, k: 4 })), ball(-42, 9, 14, 7, '#ffd66b', fb({ sx: 1.1, sy: 0.6, sz: 1.4, k: 4 })));
      else o.push(box(0, 0, 0, 108, 1.8, 60, '#e8b84a', fb({ r: 2, shine: 1 })), box(0, 1.8, 0, 92, 0.4, 44, '#f6d77a', fb({ r: 2, shine: 1 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      if (t === 1) { [[-20, -8], [24, 12], [8, -14]].forEach(([x, z]) => f += PP(PQ(p, ellPts(x, z, 4, 3, 8).map(q => [q[0], 1.3, q[1]])), SANDD, '#8a7a5c', 0.5)); f += PP(PQ(p, [[50, 1.3, -27], [56, 1.3, -20], [50, 1.3, -14]]), '#a8a294', '', 0); }
      if (t === 2) { const q = p(60, 0.5, 30); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><ellipse cx="0" cy="0" rx="3.4" ry="7" fill="#e2554a" stroke="#7a2a20" stroke-width="0.6" transform="rotate(70)"/><ellipse cx="6" cy="4" rx="3.4" ry="7" fill="#e2554a" stroke="#7a2a20" stroke-width="0.6" transform="rotate(70 6 4)"/></g>`; }
      if (t === 3) rep(12, i => { const a = i / 12 * 2 * PI; f += PP(PQ(p, [[Math.cos(a) * 22, 2.4, Math.sin(a) * 22], [Math.cos(a + 0.18) * 32, 2.4, Math.sin(a + 0.18) * 32], [Math.cos(a - 0.18) * 32, 2.4, Math.sin(a - 0.18) * 32]]), i % 2 ? '#fff1d8' : '#ff9d6a', '', 0, ' opacity="0.9"'); });
      if (t === 5) { [[-54, -30], [54, -30], [-54, 30], [54, 30]].forEach(([x, z]) => { const q = p(x, 1, z); f += PP(`M${P2(q)}l${f1(x > 0 ? 4 : -4)} 4`, 'none', '#c9961f', 2) + `<circle cx="${f1(q[0] + (x > 0 ? 4 : -4))}" cy="${f1(q[1] + 5)}" r="1.8" fill="#e2b14a"/>`; });
        f += `<g transform="${planeH(p, 2.3)}"><rect x="-46" y="-22" width="92" height="44" fill="url(#bhSh)"/></g>`; }
      return { defs: t === 5 ? '<linearGradient id="bhSh" x1="0" y1="0" x2="1" y2="0.2" gradientTransform="translate(-1 0)"><stop offset="0.35" stop-color="#fff" stop-opacity="0"/><stop offset="0.5" stop-color="#fff" stop-opacity="0.7"/><stop offset="0.65" stop-color="#fff" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-1 0;1 0;1 0" dur="4s" repeatCount="indefinite"/></linearGradient>' : '', front: f, bb: bbOf([p(-66, 0, -40), p(66, 0, 40), p(-66, 0, 40), p(66, 0, -40), p(0, 14, 0)], 3) }; };
    return D; };

  // ======================= SANDCASTLE =======================
  N.bCastle = S => { const t = T(S), sc = t === 5 ? '#cfeefa' : SAND;
    const D = { w: [70, 90, 120, 140, 130][t - 1], d: [60, 70, 100, 110, 100][t - 1], act: 'build', use: { x: 0, z: [44, 50, 64, 70, 64][t - 1] } };
    const tower = (o, x, z, r, h, cap) => { o.push(cyl(x, 0, z, r, h, sc, t === 5 ? em({ n: 14, rg: [[0, 0, 1.08], [h, 0, 0.94]] }) : pt({ n: 14, rg: [[0, 0, 1.1], [h * 0.6, 0, 1], [h, 0, 0.96]] })));
      if (cap === 'dome') o.push(ball(x, h, z, r * 0.95, t === 4 ? '#ffb3a0' : '#ffd6f0', cer({ sy: 1.1, k: 4, shine: 1 })));
      else if (cap === 'spire') o.push(cyl(x, h, z, r * 0.9, r * 2.2, '#bfeefa', em({ n: 10, rg: [[0, 0, 1], [r * 2.2, 0, 0.05]] })));
      else rep(6, i => { const a = i / 6 * 2 * PI; o.push(box(x + Math.cos(a) * r * 0.78, h, z + Math.sin(a) * r * 0.78, r * 0.5, 4, r * 0.5, sc, pt({ r: 0.6 }))); }); };
    D.build = P => { const o = [];
      if (t === 1) { o.push(cyl(-6, 0, 0, 20, 16, SAND, pt({ n: 14, rg: [[0, 0, 1.2], [10, 0, 0.92], [16, 0, 0.6]] })), cyl(18, 0, 10, 8, 12, SAND, pt({ n: 12, rg: [[0, 0, 1], [12, 0, 0.8]] })), cyl(-26, 0, 18, 7, 12, '#e2554a', pt({ n: 12, rg: [[0, 0, 0.8], [12, 0, 1]] }))); }
      else if (t === 2) { o.push(box(0, 0, 0, 52, 14, 34, SAND, pt({ r: 2 }))); tower(o, -24, 0, 9, 26); tower(o, 24, 0, 9, 26); tower(o, 0, -6, 11, 34); o.push(cyl(36, 0, 24, 7, 13, '#4fb0f0', pt({ n: 12, rg: [[0, 0, 0.8], [13, 0, 1]] }))); }
      else if (t === 3) { o.push(box(0, 0, -6, 64, 18, 44, SAND, pt({ r: 2 }))); tower(o, -32, -6, 11, 30); tower(o, 32, -6, 11, 30); tower(o, 0, -14, 13, 44); tower(o, 0, 14, 8, 22); }
      else if (t === 4) { o.push(box(0, 0, -6, 86, 20, 54, SAND, pt({ r: 3 })), box(0, 20, -10, 50, 14, 30, SAND, pt({ r: 2 }))); tower(o, -42, -6, 12, 36, 'dome'); tower(o, 42, -6, 12, 36, 'dome'); tower(o, 0, -12, 15, 52, 'dome'); tower(o, -22, 18, 8, 26); tower(o, 22, 18, 8, 26); }
      else { o.push(box(0, 0, -4, 70, 16, 46, '#e8f6fb', em({ r: 3 }))); tower(o, -34, -4, 10, 40, 'spire'); tower(o, 34, -4, 10, 40, 'spire'); tower(o, 0, -10, 13, 58, 'spire'); tower(o, -16, 16, 7, 26, 'spire'); tower(o, 16, 16, 7, 26, 'spire'); }
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', u = '', defs = '';
      if (t >= 3) { const W = water(p, { sh: { rx: t === 3 ? 52 : 66, rz: t === 3 ? 40 : 46 }, y: 0.3, pal: WP.kid, gl: 3, wave: 0.3 }); defs += W.defs; u += W.svg; const W2 = `<g transform="${planeH(p, 0.5)}"><ellipse cx="0" cy="-4" rx="${t === 3 ? 40 : 52}" ry="${t === 3 ? 30 : 36}" fill="${SAND}"/></g>`; u += W2; }
      if (t >= 2 && t <= 4) { const top = t === 2 ? [0, 34 + 4, -6] : t === 3 ? [0, 48, -14] : [0, 64, -12], q0 = p(...top), q1 = p(top[0], top[1] + 16, top[2]); f += PP(`M${P2(q0)}L${P2(q1)}`, 'none', '#8a6a48', 1.2) + `<g>${AT('skewY', '-8;8;-8', 1.6)}<path d="M${P2(q1)}l${f1(11 * k)} ${f1(3 * k)}l${f1(-11 * k)} ${f1(4 * k)}Z" fill="${t === 4 ? '#3f7fc8' : '#e2554a'}" stroke="#5a2a20" stroke-width="0.6"/></g>`; }
      if (t === 4) rep(18, i => { const a = i / 18 * 2 * PI, q = p(Math.cos(a) * 40, 10, -6 + Math.sin(a) * 26); if (Math.sin(a) < -0.2) return; f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.6 * k)}" fill="${['#ffb3a0', '#fff1d8', '#9fe0e0'][i % 3]}" stroke="#a8784a" stroke-width="0.4"/>`; });
      if (t === 5) { defs += GLW; [[-34, 22, 6], [34, 22, 6], [0, 30, -2], [0, 44, 2], [-16, 14, 23], [16, 14, 23]].forEach(([x, y, z], i) => { const q = p(x, y, z); f += `<rect x="${f1(q[0] - 1.6 * k)}" y="${f1(q[1] - 3 * k)}" width="${f1(3.2 * k)}" height="${f1(5 * k)}" rx="${f1(1.4 * k)}" fill="#fff2a0">${AN('opacity', '1;0.5;1', 1.6 + i * 0.3)}</rect>`; }); f += glowAt(p(0, 30, 0), 46 * k, 'bhC', 0.5); }
      if (t === 2) f += PP(`M${P2(p(30, 0.4, 30))}l${f1(9 * k)} ${f1(-4 * k)}`, 'none', '#c4651f', 1.6);
      return { defs, under: u, front: f, bb: bbOf([p(-70, 0, -50), p(70, 0, 50), p(-70, 0, 50), p(70, 0, -50), p(0, t === 5 ? 90 : 76, -12)], 4) }; };
    return D; };

  // ======================= SURF SPOT =======================
  const BOARD = (o, x, z, w, h, c, stripe, yaw) => { o.push(slab(x, 0, z, w, h, 3.6, c, cer({ r: w / 2 - 0.5, shine: 1, yaw: yaw || 0 }))); if (stripe) o.push(slab(x, h * 0.1, z + 1.9, 2.6, h * 0.8, 0.4, stripe, cer({ r: 1, yaw: yaw || 0 }))); };
  N.bSurf = S => { const t = T(S);
    const D = { w: 110, d: 60, act: 'surf', use: { x: 0, z: 46 } };
    D.build = P => { const o = [];
      if (t === 1) { o.push(cyl(-14, 0, -6, 4, 54, '#a8977c', wd({ n: 8, rg: [[0, 0, 1], [54, 0, 0.8]] }))); BOARD(o, 6, -2, 26, 44, '#5ab0e0', '#ffffff', 0.2); }
      else if (t === 2) { [-24, 24].forEach(x => o.push(box(x, 0, -10, 4, 70, 4, '#b8804a', wd({ r: 0.8 })), box(x, 0, 6, 4, 18, 4, '#b8804a', wd({ r: 0.8 })))); o.push(box(0, 66, -10, 58, 4, 5, '#c48a52', wd({ r: 1 }))); BOARD(o, 0, -4, 24, 96, '#ffe066', '#e2554a'); }
      else if (t === 3) { [-46, 46].forEach(x => o.push(box(x, 0, -12, 5, 76, 5, '#3e4046', mt({ r: 1 })))); o.push(box(0, 72, -12, 98, 5, 6, '#3e4046', mt({ r: 1 }))); BOARD(o, -20, -6, 22, 88, '#ffffff', '#2f9fb8'); BOARD(o, 18, -6, 22, 80, '#ff8a5a', '#ffffff'); o.push(slab(40, 34, -8, 14, 34, 3, '#2c2d31', fb({ r: 5 }))); }
      else if (t === 4) { [-50, 50].forEach(x => o.push(cyl(x, 0, -14, 3.4, 86, '#8a5a2c', wd({ n: 8 })))); o.push(box(0, 82, -14, 108, 4, 6, '#8a5a2c', wd({ r: 1 }))); BOARD(o, -28, -8, 20, 84, '#ffd6c8', '#e2554a'); BOARD(o, 0, -8, 22, 92, '#9fe0e0', '#ffffff'); BOARD(o, 28, -8, 20, 80, '#ffe066', '#3fa04a'); }
      else { o.push(cyl(0, 0, 0, 30, 6, '#2a3a5a', mt({ n: 24, shine: 1 })), cyl(0, 6, 0, 26, 1.4, '#7af6ff', em({ n: 24 }))); }
      return o; };
    if (t === 5) D.layers = [{ build: P => [box(0, 24, 0, 96, 4, 26, '#ffffff', cer({ r: 12, shine: 1 })), box(0, 28, 0, 70, 0.6, 3, '#4fe0f0', em({ r: 1 }))], wrap: (p, s) => `<g>${AT('translate', '0 0;0 -4;0 0', 2.4)}${s}</g>` }];
    D.fx = c => { const p = c.p, k = c.k; let f = '', defs = '';
      if (t === 4) { f += cone(p, k, { y: 86, h: 14, R: 64, n: 4, a0: PI / 4, cols: ['#d8b46a', '#c9a45a'], fringe: '#b8924a', z: -14, droop: 0, fl: 8 }); rep(3, i => { const q = p(-28 + i * 28, 50, -5); f += rep(5, j => `<circle cx="${f1(q[0] + Math.cos(j * 1.256) * 3.2 * k)}" cy="${f1(q[1] + Math.sin(j * 1.256) * 3.2 * k)}" r="${f1(2.2 * k)}" fill="#ff6a8a"/>`).join('') + `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.4 * k)}" fill="#ffe066"/>`; }); }
      if (t === 5) { defs = GLW; f += glowAt(p(0, 8, 0), 44 * k, 'bhC', 0.7) + rep(4, i => `<circle r="${f1(1.4 * k)}" fill="#bffcff"><animateMotion dur="${2 + i * 0.4}s" begin="${-i * 0.5}s" repeatCount="indefinite" path="M${P2(p(-30 + i * 20, 8, 0))}L${P2(p(-30 + i * 20, 22, 0))}"/>${AN('opacity', '1;0', 2 + i * 0.4, -i * 0.5)}</circle>`).join(''); }
      if (t === 1) f += PP(`M${P2(p(0, 30, 0))}l${f1(5 * k)} ${f1(6 * k)}l${f1(-2 * k)} ${f1(5 * k)}`, 'none', '#2a5a7a', 0.8);
      return { defs, front: f, bb: bbOf([p(-66, 0, -30), p(66, 0, 30), p(0, 110, -14), p(-60, 90, -14), p(60, 90, -14)], 4) }; };
    return D; };

  // ======================= BEACH GAMES (volleyball, 2 players) =======================
  N.bVolley = S => { const t = T(S), pl = isPlay(S);
    const D = { w: 170, d: 100 };
    D.build = P => { const o = [], pc = ['#a8977c', '#ffffff', '#3f7fc8', '#e2554a', '#2a2a40'][t - 1], H = t === 1 ? 40 : 48;
      [-72, 72].forEach((x, i) => o.push(cyl(x, 0, 0, t === 1 ? 2.4 : 3, H + (t === 1 ? (i ? -4 : 2) : 4), pc, t === 1 ? wd({ n: 8 }) : mt({ n: 10 }))));
      if (t === 4) o.push(box(-90, 0, -30, 6, 50, 6, '#3a3d44', mt({ r: 1 })), slab(-90, 50, -30, 40, 20, 3, '#1c1f3a', mt({ r: 3 })));
      if (!pl) o.push(ball(30, 7, 26, 7, t === 5 ? '#bffcff' : '#ffffff', t === 5 ? em({ k: 5 }) : cer({ k: 5, shine: 1 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k, H = t === 1 ? 40 : 48, top = t === 1 ? 6 : 0; let f = '', u = '', defs = GLW;
      if (t >= 2) u += `<g transform="${planeH(p, 0.4)}"><rect x="-80" y="-44" width="160" height="88" fill="none" stroke="${t === 5 ? '#7af6ff' : '#ffffff'}" stroke-width="2.2" opacity="0.85"/><path d="M0 -44V44" stroke="${t === 5 ? '#7af6ff' : '#ffffff'}" stroke-width="1.6" opacity="0.6"/></g>`;
      const nT = [[-70, H - 2], [-35, H - 2 - top * 0.7], [0, H - 2 - top], [35, H - 2 - top * 0.7], [70, H - 2]], nB = nT.map(([x, y]) => [x, y - 18]);
      const pth = (A, B) => 'M' + A.map(([x, y]) => P2(p(x, y, 0))).join('L') + 'L' + B.slice().reverse().map(([x, y]) => P2(p(x, y, 0))).join('L') + 'Z';
      let mesh = ''; rep(15, i => { const x = -70 + i * 10, yt = H - 2 - top * Math.sin((x + 70) / 140 * PI); mesh += `M${P2(p(x, yt, 0))}L${P2(p(x, yt - 18, 0))}`; }); rep(4, j => { mesh += 'M' + rep(15, i => { const x = -70 + i * 10, yt = H - 2 - top * Math.sin((x + 70) / 140 * PI); return P2(p(x, yt - 4.5 * (j + 0.5), 0)); }).join('L'); });
      f += PP(pth(nT, nB), t === 1 ? '#c9b896' : '#ffffff', '', 0, ' opacity="0.18"') + PP(mesh, 'none', t === 1 ? '#8a7a5c' : t === 5 ? '#7af6ff' : '#2a2a30', 0.6, ' opacity="0.7"') + PP('M' + nT.map(([x, y]) => P2(p(x, y, 0))).join('L'), 'none', t === 5 ? '#bffcff' : '#ffffff', 2.4) + PP('M' + nT.map(([x, y]) => P2(p(x, y, 0))).join('L'), 'none', t === 5 ? '#4fe0f0' : '#2a2a30', 0.8);
      if (t >= 3) [-72, 72].forEach((x, i) => { const q = p(x, H + 4, 0); f += PP(`M${P2(q)}l0 ${f1(-14 * k)}`, 'none', '#2a2a30', 1) + `<g>${AT('skewY', '-10;10;-10', 1.4, -i * 0.4)}<path d="M${f1(q[0])} ${f1(q[1] - 14 * k)}l${f1(12 * k)} ${f1(3 * k)}l${f1(-12 * k)} ${f1(4 * k)}Z" fill="${i ? '#ffd23f' : '#e2554a'}"/></g>`; });
      if (t === 4) { const q = p(-90, 60, -28); f += `<text x="${f1(q[0])}" y="${f1(q[1] + 3)}" text-anchor="middle" font-family="Fredoka, sans-serif" font-weight="700" font-size="${f1(9 * k)}" fill="#ffd23f">${pl ? '3-2' : '0-0'}</text>`; }
      if (t === 5) { f += glowAt(p(0, H, 0), 60 * k, 'bhC', 0.35); }
      if (pl) { const a = p(-50, 20, 10), b = p(0, H + 40, 0), cc = p(50, 20, -8); f += `<g><animateMotion dur="1.8s" repeatCount="indefinite" path="M${P2(a)}Q${P2(b)} ${P2(cc)}Q${P2(b)} ${P2(a)}"/><circle r="${f1(6 * k)}" fill="${t === 5 ? '#bffcff' : '#ffffff'}" stroke="#8a8a90" stroke-width="0.8"/><path d="M${f1(-6 * k)} 0Q0 ${f1(-3 * k)} ${f1(6 * k)} 0" stroke="#3fb0c8" stroke-width="1.2" fill="none"/></g>`; }
      return { defs, under: u, front: f, bb: bbOf([p(-96, 0, -50), p(96, 0, 50), p(-96, 0, 50), p(96, 0, -50), p(0, H + 50, 0), p(-90, 74, -30)], 4) }; };
    return D; };

  // ======================= SNACK SHACK =======================
  N.bShack = S => { const t = T(S);
    const D = { w: 130, d: 80, act: 'treat', use: { x: 0, z: 56 } };
    D.build = P => { const o = [];
      if (t === 1) { o.push(box(-18, 0, 0, 40, 30, 34, '#c49a62', wd({ r: 1 })), box(22, 0, 0, 36, 30, 34, '#b8894e', wd({ r: 1 })), box(0, 30, 0, 82, 3, 38, '#d8b07a', wd({ r: 1 })), cyl(-14, 33, 0, 7, 16, '#fff6a0', cer({ n: 14, shine: 1 })), cyl(-14, 49, 0, 7.4, 2, '#f2c255', pt({ n: 14 })), slab(18, 33, -12, 34, 26, 2, '#fff8ea', pt({ r: 1 }))); }
      else if (t === 2) { o.push(box(0, 12, 0, 92, 40, 46, '#fffaf1', pt({ r: 6, bev: 2 })), box(0, 52, 0, 96, 4, 50, '#7fd0e0', pt({ r: 4 })), ...[[-34, 24], [34, 24], [-34, -24], [34, -24]].map(([x, z]) => cyl(x, 0, z, 6, 12, '#3a3d44', mt({ n: 12 }))), cyl(46, 12, 0, 1.6, 74, '#9aa1a6', mt({ n: 6 })));
        [[-28, '#ffb3c8'], [-14, '#fff1b8'], [0, '#c9f0b0'], [14, '#cfe0ff']].forEach(([x, c]) => o.push(cyl(x, 56, 0, 5.4, 6, c, fb({ n: 12 })))); }
      else if (t === 3) { o.push(box(0, 0, 10, 110, 34, 30, '#c48a52', wd({ r: 2 })), box(0, 34, 12, 116, 4, 36, '#e8c88a', wd({ r: 1 })), ...[[-52, -26], [52, -26], [-52, 24], [52, 24]].map(([x, z]) => cyl(x, 0, z, 3, 74, '#8a5a2c', wd({ n: 8 }))), box(0, 0, -24, 104, 52, 6, '#b8804a', wd({ r: 1 })));
        [[-30, '#ff8ab0'], [-12, '#ffd66b'], [8, '#a6e870']].forEach(([x, c]) => o.push(cyl(x, 38, 14, 5.4, 14, c, cer({ n: 12, shine: 1 })), cyl(x + 2, 52, 14, 0.8, 8, '#ffffff', pt({ n: 6 })))); }
      else if (t === 4) { o.push(box(0, 0, 0, 120, 46, 44, '#f4f1ea', pt({ r: 3, bev: 2 })), box(0, 46, 6, 126, 4, 56, '#3fb0c8', pt({ r: 2 })), box(0, 0, -26, 120, 76, 8, '#3fb0c8', pt({ r: 2 })), ...[-40, -20, 0, 20, 40].map(x => cyl(x, 0, 30, 5, 22, '#e2554a', mt({ n: 12 }))), ...[-40, -20, 0, 20, 40].map(x => cyl(x, 22, 30, 7, 2.4, '#2c2d31', fb({ n: 12 })))); }
      else { o.push(cyl(0, 0, 0, 46, 44, '#fff6e2', cer({ n: 28, shine: 1 })), cyl(0, 44, 0, 50, 4, GOLD, mt({ n: 28, shine: 1 })), ball(0, 48, 0, 44, '#ffd6e8', cer({ sy: 0.62, k: 6, n: 28, shine: 1 })), cyl(0, 74, 0, 8, 24, '#e8b84a', pt({ n: 12, rg: [[0, 0, 0.2], [24, 0, 1]] })), ball(0, 102, 0, 11, '#ff9ac8', fb({ k: 5 })), ball(0, 112, 0, 4, '#e2554a', cer({ k: 4, shine: 1 }))); }
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', defs = GLW;
      const sign = (q, txt, col, bg, sz) => `<g transform="translate(${P2(q)})"><text text-anchor="middle" y="${f1(sz * 0.35)}" font-family="Fredoka, sans-serif" font-weight="700" font-size="${f1(sz)}" fill="${col}" stroke="${bg}" stroke-width="${f1(sz * 0.22)}" paint-order="stroke">${txt}</text></g>`;
      if (t === 1) f += sign(p(18, 48, -10), 'LEMONADE', '#e2554a', '#fff8ea', 4.6 * k);
      if (t === 2) { f += cone(p, k, { y: 84, h: 12, R: 30, n: 10, x: 46, cols: ['#ff6a8a', '#ffffff'] }); f += sign(p(0, 34, 24), 'ICE CREAM', '#2f9fb8', '#fffaf1', 6 * k); }
      if (t === 3) { f += cone(p, k, { y: 74, h: 22, R: 74, n: 4, a0: PI / 4, cols: ['#d8b46a', '#c9a45a'], fringe: '#b8924a', droop: 0, fl: 10 }); f += sign(p(0, 50, -20), 'SMOOTHIES', '#ffffff', '#8a5a2c', 6.4 * k); }
      if (t === 4) { const sc = rep(7, i => ({ i })).map(({ i }) => { const x = -63 + i * 18; return PP(PQ(p, [[x, 50, 34], [x + 18, 50, 34], [x + 18, 42, 40], [x, 42, 40]]), i % 2 ? '#ffffff' : '#e2554a', ink('#e2554a'), 0.6); }).join(''); f += sc;
        const q = p(30, 60, -24); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><path d="M-5 0L0 14L5 0Z" fill="#ffb340" stroke="#ff7a22" stroke-width="1.6"><animate attributeName="stroke-opacity" values="1;0.4;1" dur="1.2s" repeatCount="indefinite"/></path><circle cx="0" cy="-3" r="6" fill="#ff8ac8" stroke="#ff4fd8" stroke-width="1.6"/></g>` + glowAt(q, 18 * k, 'bhG', 0.6) + sign(p(-20, 62, -24), 'SNACKS', '#ffffff', '#2f7a8a', 7 * k); }
      if (t === 5) { f += glowAt(p(0, 60, 0), 60 * k, 'bhG', 0.5) + rep(8, i => { const a = i / 8 * 2 * PI, q = p(Math.cos(a) * 48, 46, Math.sin(a) * 48); return Math.sin(a) > -0.2 ? `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.8 * k)}" fill="#fff6c8">${AN('opacity', '1;0.3;1', 1.2, -i * 0.15)}</circle>` : ''; }).join(''); }
      return { defs, front: f, bb: bbOf([p(-76, 0, -44), p(76, 0, 44), p(-76, 0, 44), p(76, 0, -44), p(0, 120, 0), p(-70, 96, -20), p(70, 96, -20), p(76, 90, 0)], 4) }; };
    return D; };

  // ======================= BONFIRE =======================
  N.bFire = S => { const t = T(S);
    const D = { w: 140, d: 110, act: 'roast', seats: [{ x: -54, z: 8, h: t === 2 || t === 4 ? 12 : 3, k: 'roast', f: 90 }, { x: 54, z: 8, h: t === 2 || t === 4 ? 12 : 3, k: 'roast', f: -90 }, { x: 0, z: -46, h: t === 4 ? 12 : 3, k: 'roast', f: 0 }] };
    D.build = P => { const o = [];
      if (t === 1) { o.push(cyl(0, 0, 0, 22, 2, SANDD, pt({ n: 18, rg: [[0, 0, 1.2], [2, 0, 1]] }))); rep(5, i => { const a = i / 5 * 2 * PI; o.push(box(Math.cos(a) * 6, 2, Math.sin(a) * 6, 18, 2.4, 2.4, '#8a6a48', wd({ r: 1, yaw: a }))); }); }
      else if (t === 2) { rep(12, i => { const a = i / 12 * 2 * PI; o.push(ball(Math.cos(a) * 20, 3, Math.sin(a) * 16, 5, i % 2 ? '#9a948a' : '#b4ada0', pt({ k: 3, n: 8, sy: 0.7 }))); }); o.push(box(-54, 0, 8, 22, 10, 40, '#8a5a2c', wd({ r: 5 })), box(54, 0, 8, 22, 10, 40, '#8a5a2c', wd({ r: 5 }))); rep(4, i => o.push(box(0, 2, 0, 22, 3, 3, '#6a4a2a', wd({ r: 1.2, yaw: i * 0.8 })))); }
      else if (t === 3) { o.push(...[0, 1, 2].map(i => box(Math.cos(i * 2.09) * 14, 0, Math.sin(i * 2.09) * 14, 3, 12, 3, '#2c2d31', mt({ r: 0.6 }))), cyl(0, 10, 0, 24, 10, '#3a3d44', mt({ n: 22, rg: [[0, 0, 0.6], [10, 0, 1]] })), cyl(0, 19.4, 0, 24.6, 1.2, '#55585e', mt({ n: 22 }))); }
      else if (t === 4) { o.push(cyl(0, 0, 0, 24, 6, '#9a948a', pt({ n: 20 })), cyl(0, 6, 0, 18, 1, '#3a2a20', pt({ n: 18 }))); rep(7, i => { const a = PI * 0.15 + i / 7 * 2 * PI; o.push(cush(Math.cos(a) * 52, 0, Math.sin(a) * 40, 22, 12, 22, i % 2 ? '#e3946a' : '#2f9fb8', fb({ yaw: -a }))); }); }
      else { rep(9, i => { const a = i / 9 * 2 * PI; o.push(cyl(Math.cos(a) * 22, 0, Math.sin(a) * 18, 4, 10 + (i % 3) * 5, '#bfeefa', em({ n: 6, rg: [[0, 0, 1], [10 + (i % 3) * 5, 0, 0.1]] }))); }); o.push(cyl(0, 0, 0, 16, 2, '#3a3a5a', pt({ n: 16 }))); }
      return o; };
    D.fx = c => { const p = c.p, k = c.k, fy = t === 3 ? 20 : t === 4 ? 6 : 3; let f = '', defs = FDEF + HUE + GLW;
      const fl = flames(p(0, fy, 0), k * (t === 1 ? 0.75 : 1), { n: t === 1 ? 3 : 5, sp: t === 1 ? 5 : 9, h: t === 1 ? 14 : 20, w: 3.8, seed: 'bf' + t });
      f += t === 5 ? `<g filter="url(#bhBlue)">${fl}</g>` : fl;
      if (t === 3) rep(3, i => { const a = -0.6 + i * 0.6, q0 = p(Math.cos(a) * 46, 18, Math.sin(a) * 30 + 10), q1 = p(Math.cos(a) * 12, 26, Math.sin(a) * 8); f += PP(`M${P2(q0)}L${P2(q1)}`, 'none', '#8a6a48', 1.2) + `<rect x="${f1(q1[0] - 2.4 * k)}" y="${f1(q1[1] - 1.6 * k)}" width="${f1(4.8 * k)}" height="${f1(3.6 * k)}" rx="${f1(1.4 * k)}" fill="#fffaf1" stroke="#d8c8b0" stroke-width="0.5"/>`; });
      f += glowAt(p(0, 2, 0), 44 * k, t === 5 ? 'bhC' : 'bhG', 0.45);
      return { defs, front: f, bb: bbOf([p(-80, 0, -56), p(80, 0, 56), p(-80, 0, 56), p(80, 0, -56), p(0, 50, 0)], 4) }; };
    return D; };

  // ======================= TIDE POOL =======================
  N.bTide = S => { const t = T(S), RX = 40, RZ = 28, rc = t === 3 ? '#7f8f78' : t === 4 ? '#e8907a' : t === 5 ? '#6a6f9a' : '#9a948a';
    const D = { w: 120, d: 90, act: 'splash', seats: [{ x: -14, z: 0, h: 2, k: 'splash' }, { x: 16, z: 4, h: 2, k: 'splash' }] };
    D.build = P => { const o = [], R = rng('tide' + t), n = t === 1 ? 0 : 13;
      if (t === 1) o.push(cyl(0, 0, 0, RX + 6, 1, '#8a7a5c', pt({ n: 20, rz: RZ + 5 })));
      rep(n, i => { const a = i / n * 2 * PI, r = 7 + R() * 6; o.push(ball(Math.cos(a) * (RX + 4), r * 0.4, Math.sin(a) * (RZ + 4), r, i % 3 === 0 ? shade(rc, 1.1) : rc, pt({ k: 3, n: 9, sy: 0.75 }))); });
      if (t === 3) rep(4, i => o.push(ball(-24 + i * 16, 2, (i % 2 ? 1 : -1) * 10, 3.4, ['#ff7aa0', '#ffb3c8', '#ff9a6a', '#ff7aa0'][i], fb({ k: 3, sy: 1.4 }))));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; const pal = t === 1 ? ['#4a3a24', '#6a5a3e', '#a8987a', '#e8dcc0'] : t === 5 ? ['#0a1838', '#183a6a', '#4f7ab8', '#bfe6ff'] : t === 4 ? WP.lagoon : WP.pool;
      const W = water(p, { sh: { rx: RX, rz: RZ }, y: 1.2, pal, gl: t === 1 ? 1 : 5, wave: 0.35, caust: t === 1 ? 0.1 : 0.4 }); let f = '', defs = W.defs + GLW;
      if (t === 2 || t === 3) { f += star5(p(-20, 1.6, 10), k * 1.2, '#ff8a4a', 20) + star5(p(22, 1.6, -8), k, '#ffb340', -10); }
      if (t === 4) { rep(3, i => { const q = p(-26 + i * 24, 1.4, -12 + (i % 2) * 16); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><path d="M0 0V-10M0 -6l-4 -4M0 -4l4 -5M0 -8l3 -3" stroke="${['#ff7a5a', '#ffb3c8', '#ffd66b'][i]}" stroke-width="2" stroke-linecap="round" fill="none"/></g>`; });
        rep(3, i => f += `<g><animateMotion dur="${5 + i}s" begin="${-i * 1.6}s" repeatCount="indefinite" path="M${P2(p(-26, 1.4, -8 + i * 7))}Q${P2(p(0, 1.4, 16 - i * 8))} ${P2(p(26, 1.4, -6 + i * 6))}Q${P2(p(0, 1.4, -18 + i * 6))} ${P2(p(-26, 1.4, -8 + i * 7))}" rotate="auto"/><path d="M-3 0Q0 -2 3 0Q0 2 -3 0ZM-3 0L-5.4 -1.6V1.6Z" fill="${['#ffb340', '#ff7a6a', '#ffe066'][i]}" transform="scale(${n4(k)})"/></g>`); }
      if (t === 5) { f += glowAt(p(0, 1.2, 0), 40 * k, 'bhC', 0.6) + `<g transform="${planeH(p, 1.3)}"><circle cx="6" cy="-4" r="7" fill="#fff8dc" opacity="0.85">${AN('opacity', '0.85;0.5;0.85', 3)}</circle></g>`; }
      const nc = t === 1 ? 1 : t === 2 ? 2 : 3; rep(nc, i => { const a = PI * (0.25 + i * 0.5), q = p(Math.cos(a) * (RX + 2), 7, Math.sin(a) * (RZ + 3)); f += crab(q, k, t === 5 ? '#ff9ac8' : '#e2554a', 3 + i, -i * 1.3, 5 * k); });
      return { defs, under: W.svg, front: f, bb: bbOf([p(-RX - 14, 0, -RZ - 14), p(RX + 14, 0, RZ + 14), p(-RX - 14, 0, RZ + 14), p(RX + 14, 0, -RZ - 14), p(0, 18, 0)], 4) }; };
    return D; };

  // ======================= FLOAT & BOAT (sits in the sea) =======================
  N.bFloat = S => { const t = T(S);
    const D = { w: [70, 80, 130, 120, 150][t - 1], d: [70, 74, 56, 64, 70][t - 1], sea: 1, act: 'ride', seats: [{ x: t >= 3 ? 8 : 0, z: 0, h: [7, 8, 10, 12, 14][t - 1], k: 'ride' }] };
    D.build = P => { const o = [];
      if (t === 1) o.push(arcW(0, 0, 0, 30, 30, 13, 9, 0, 2 * PI, '#3a3d44', fb({ n: 24, shine: 1 })));
      else if (t === 2) o.push(arcW(0, 0, 0, 32, 30, 14, 10, 0, 2 * PI, '#ffd23f', cer({ n: 24, shine: 1 })), ball(-30, 22, 0, 10, '#ffd23f', cer({ k: 5, shine: 1 })), ball(-40, 20, 0, 4, '#ff8a2a', cer({ sx: 1.8, sy: 0.6, k: 3 })));
      else if (t === 3) o.push(cyl(0, -2, 0, 62, 14, '#b8804a', wd({ rz: 24, n: 26, rg: [[0, 0, 0.78], [14, 0, 1]] })), cyl(0, 4, 0, 56, 1, '#8a5a2c', wd({ rz: 19, n: 24 })), box(8, 8, 0, 14, 2.4, 38, '#c48a52', wd({ r: 0.8 })), box(-6, 13, 26, 70, 2, 3, '#d8b07a', wd({ r: 1, yaw: 0.2 })), box(-6, 13, -26, 70, 2, 3, '#d8b07a', wd({ r: 1, yaw: -0.2 })));
      else if (t === 4) o.push(cyl(0, -2, 0, 56, 16, '#fffaf6', cer({ rz: 30, n: 26, shine: 1, rg: [[0, 0, 0.8], [16, 0, 1]] })), cyl(0, 14, 0, 48, 1, '#3fb0c8', fb({ rz: 24, n: 24 })), slab(-14, 12, -24, 40, 18, 4, '#fffaf6', cer({ r: 9, shine: 1 })), slab(-14, 12, 24, 40, 18, 4, '#fffaf6', cer({ r: 9, shine: 1 })));
      else o.push(cyl(0, -2, 0, 72, 18, '#e8b84a', mt({ rz: 32, n: 28, shine: 1, rg: [[0, 0, 0.8], [18, 0, 1]] })), cyl(0, 16, 0, 64, 1.4, '#7a1e2c', fb({ rz: 26, n: 26 })), ...[[-40, -18], [-40, 18], [40, -18], [40, 18]].map(([x, z]) => cyl(x, 16, z, 1.8, 50, GOLD, mt({ n: 8 }))), box(0, 66, 0, 88, 3, 42, '#7a1e2c', fb({ r: 2 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', u = ripples(p, D.w * 0.55, D.d * 0.5, 2, 2.8);
      if (t === 1) f += PP(PQ(p, [[16, 9.2, 18], [26, 9.2, 10], [22, 9.2, 22]]), '#e2554a', '#7a2a20', 0.6);
      if (t === 2) { const q = p(-34, 26, 0); f += `<circle cx="${f1(q[0] - 3 * k)}" cy="${f1(q[1] - 1 * k)}" r="${f1(1.4 * k)}" fill="#2a1a10"/>`; }
      if (t === 4) { const pts = curve([-50, 10, 0], [-66, 40, 0], [-52, 62, 0], 8).map(q => p(...q)); f += tube(pts, 6, k, '#fffaf6', '#ffffff', '#9aa4b0'); const hq = p(-52, 66, 0); f += `<circle cx="${f1(hq[0])}" cy="${f1(hq[1])}" r="${f1(7 * k)}" fill="#fffaf6" stroke="#9aa4b0" stroke-width="0.8"/><path d="M${f1(hq[0] - 6 * k)} ${f1(hq[1])}l${f1(-8 * k)} ${f1(2 * k)}l${f1(8 * k)} ${f1(3 * k)}Z" fill="#ff8a2a" stroke="#c4561c" stroke-width="0.6"/><circle cx="${f1(hq[0] - 2 * k)}" cy="${f1(hq[1] - 2 * k)}" r="${f1(1.2 * k)}" fill="#2a1a10"/>`; }
      if (t === 5) { f += cone(p, k, { y: 69, h: 14, R: 56, n: 4, a0: PI / 4, cols: ['#a8243a', '#7a1e2c'], droop: 0, tassel: GOLD }); const q = p(0, 84, 0); f += PP(`M${P2(q)}l0 ${f1(-14 * k)}`, 'none', GOLD, 1.4) + `<g>${AT('skewY', '-8;8;-8', 1.6)}<path d="M${f1(q[0])} ${f1(q[1] - 14 * k)}l${f1(12 * k)} ${f1(3 * k)}l${f1(-12 * k)} ${f1(4 * k)}Z" fill="#ffd23f"/></g>`; }
      return { under: u, front: f, bb: bbOf([p(-D.w * 0.7, 0, -D.d * 0.7), p(D.w * 0.7, 0, D.d * 0.7), p(-D.w * 0.7, 0, D.d * 0.7), p(D.w * 0.7, 0, -D.d * 0.7), p(0, t === 5 ? 100 : t === 4 ? 76 : 40, 0)], 4) }; };
    return D; };

  // ======================= LIFEGUARD TOWER =======================
  N.bTower = S => { const t = T(S), H = [24, 52, 60, 64, 70][t - 1];
    const D = { w: 100, d: 90, act: 'sit', seats: [{ x: 0, z: t === 1 ? 2 : 10, h: H + 4, k: 'sit' }] };
    D.build = P => { const o = [];
      if (t === 1) o.push(box(0, 0, 0, 38, H, 34, '#c49a62', wd({ r: 1 })), box(0, 6, 17.4, 34, 3, 0.6, '#8a6a42', wd()), box(0, 15, 17.4, 34, 3, 0.6, '#8a6a42', wd()));
      else if (t === 2) { [[-18, -14], [18, -14], [-18, 18], [18, 18]].forEach(([x, z]) => o.push(box(x, 0, z, 4, H, 4, '#f4f1ea', pt({ r: 1 })))); o.push(box(0, H, 2, 44, 4, 40, '#f4f1ea', pt({ r: 1 })), slab(0, H + 4, -16, 44, 26, 3, '#f4f1ea', pt({ r: 2 })), ...[12, 26, 40].map(y => box(0, y, 18, 36, 2, 2, '#e8e2d6', pt({ r: 0.6 })))); }
      else { const hc = t === 3 ? '#e2554a' : t === 4 ? '#f4f1ea' : '#ffffff', st = t === 5 ? '#e2554a' : '#ffffff';
        if (t === 5) o.push(cyl(0, 0, -6, 26, H, '#ffffff', pt({ n: 22, rg: [[0, 0, 1.1], [H, 0, 0.86]] })), ...[0.2, 0.5, 0.8].map(u => cyl(0, H * u, -6, 26 * (1.1 - 0.24 * u) + 0.4, H * 0.14, '#e2554a', pt({ n: 22 }))), cyl(0, H, -6, 30, 4, '#2c2d31', mt({ n: 22 })));
        else { [[-26, -22], [26, -22], [-26, 18], [26, 18]].forEach(([x, z]) => o.push(box(x, 0, z, 5, H, 5, '#f4f1ea', wd({ r: 1 })))); o.push(box(0, H, -2, 64, 4, 52, '#d8b07a', wd({ r: 1 })), box(0, H + 4, -12, 50, 34, 30, hc, pt({ r: 2 })), box(0, H + 38, -12, 58, 4, 38, st, pt({ r: 2 })), prismZ(-10, 10, [[20, 0], [30, 0], [26, 4], [8, H], [2, H]], '#d8b07a', wd())); }
        if (t === 4) o.push(cyl(32, 0, -30, 1.8, H + 70, '#9aa1a6', mt({ n: 6 }))); }
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', defs = GLW;
      if (t === 2) f += cone(p, k, { y: H + 52, h: 10, R: 34, n: 10, z: -10, cols: ['#e2554a', '#ffffff'] }) + PP(`M${P2(p(0, H + 30, -16))}L${P2(p(0, H + 52, -10))}`, 'none', '#9aa1a6', 1.4);
      if (t === 3 || t === 4) { const q = p(0, H + 22, 3.4); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><circle r="7" fill="none" stroke="#ffffff" stroke-width="3.4"/><circle r="7" fill="none" stroke="#e2554a" stroke-width="3.4" stroke-dasharray="5.5 5.5"/></g>`; }
      if (t === 4) { const q = p(32, H + 70, -30); f += `<g>${AT('skewY', '-8;8;-8', 1.5)}<path d="M${P2(q)}l${f1(18 * k)} ${f1(4 * k)}l${f1(-18 * k)} ${f1(6 * k)}Z" fill="#ffd23f" stroke="#8a5d00" stroke-width="0.6"/><path d="M${f1(q[0])} ${f1(q[1] + 3 * k)}l${f1(18 * k)} ${f1(1 * k)}" stroke="#e2554a" stroke-width="${f1(2 * k)}"/></g>`; }
      if (t === 5) { const q = p(0, H + 14, -6); f += `<rect x="${f1(q[0] - 10 * k)}" y="${f1(q[1] - 12 * k)}" width="${f1(20 * k)}" height="${f1(12 * k)}" rx="${f1(2 * k)}" fill="#fff6c8" stroke="#2c2d31" stroke-width="1"/>` + PP(`M${f1(q[0] - 12 * k)} ${f1(q[1] - 12 * k)}L${f1(q[0])} ${f1(q[1] - 22 * k)}L${f1(q[0] + 12 * k)} ${f1(q[1] - 12 * k)}Z`, '#e2554a', '#7a2a20', 1) + glowAt([q[0], q[1] - 6 * k], 26 * k, 'bhG', 0.8); }
      return { defs, front: f, bb: bbOf([p(-56, 0, -46), p(56, 0, 46), p(-56, 0, 46), p(56, 0, -46), p(0, H + (t === 4 ? 80 : 70), -10)], 4) }; };
    return D; };

  // ======================= COOLER & DRINKS =======================
  N.bCooler = S => { const t = T(S);
    const D = { w: 70, d: 50, act: 'treat', use: { x: 0, z: 40 } };
    D.build = P => { const o = [];
      if (t === 1) o.push(box(0, 0, 0, 44, 24, 30, '#f4f1ea', pt({ r: 3 })), box(0, 24, 0, 46, 5, 32, '#e8e4dc', pt({ r: 3 })));
      else if (t === 2) o.push(box(0, 0, 0, 48, 26, 32, '#e2554a', pt({ r: 4, bev: 1.6 })), box(0, 26, 0, 50, 6, 34, '#ffffff', pt({ r: 4 })), box(0, 34, 0, 30, 2, 4, '#9aa1a6', mt({ r: 1 })));
      else if (t === 3) o.push(box(0, 12, 0, 60, 26, 36, '#3fb0c8', pt({ r: 3 })), ...[[-24, 16], [24, 16], [-24, -16], [24, -16]].map(([x, z]) => cyl(x, 0, z, 5, 12, '#3a3d44', mt({ n: 10 }))), ...[-18, 0, 18].map(x => ball(x, 44, 0, 7.4, '#8a5a2c', wd({ k: 5 }))));
      else if (t === 4) o.push(cyl(0, 0, 0, 22, 40, '#a8683a', wd({ n: 20, rg: [[0, 0, 0.9], [20, 0, 1], [40, 0, 0.9]] })), ...[8, 32].map(y => cyl(0, y, 0, 22 * 0.98, 2, '#3a3d44', mt({ n: 20 }))), ...[-12, 12].map(x => cyl(x, 40, 0, 6, 10, '#ffd23f', pt({ n: 12 }))));
      else o.push(cyl(0, 0, 0, 16, 12, GOLD, mt({ n: 18, shine: 1 })), cyl(0, 12, 0, 6, 20, GOLD, mt({ n: 12, shine: 1 })), cyl(0, 32, 0, 22, 8, GOLD, mt({ n: 20, shine: 1, rg: [[0, 0, 0.6], [8, 0, 1]] })), cyl(0, 39, 0, 20, 1, '#9fe8f6', em({ n: 20 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      if (t === 1) f += PP(`M${P2(p(-16, 18, 15.2))}q${f1(4 * k)} ${f1(3 * k)} ${f1(8 * k)} 0`, 'none', '#b8b0a0', 1);
      if (t === 3) [-18, 0, 18].forEach((x, i) => { const q = p(x, 50, 0); f += PP(`M${P2(q)}l${f1((i - 1) * 3 * k)} ${f1(-12 * k)}`, 'none', ['#ff6a8a', '#ffd23f', '#6fd06a'][i], 1.6); });
      if (t === 4) [-12, 12].forEach(x => { const q = p(x, 50, 0); f += PP(`M${f1(q[0] - 4 * k)} ${f1(q[1])}l${f1(2 * k)} ${f1(-7 * k)}l${f1(2 * k)} ${f1(5 * k)}l${f1(2 * k)} ${f1(-6 * k)}l${f1(2 * k)} ${f1(8 * k)}`, '#3f9a42', '#1e5a2a', 0.6); });
      if (t === 5) { const a = p(0, 40, 0), b = p(0, 62, 0); f += rep(4, i => { const e = p(Math.cos(i * 1.57) * 18, 40, Math.sin(i * 1.57) * 18); return `<path d="M${P2(a)}Q${P2(b)} ${P2(e)}" fill="none" stroke="#bfeefa" stroke-width="${f1(2 * k)}" stroke-linecap="round" stroke-dasharray="4 3" opacity="0.9">${AN('stroke-dashoffset', '0;-14', 0.7)}</path>`; }).join(''); }
      return { front: f, bb: bbOf([p(-40, 0, -30), p(40, 0, 30), p(-40, 0, 30), p(40, 0, -30), p(0, t === 5 ? 66 : 60, 0)], 4) }; };
    return D; };

  // ======================= PALM TREE =======================
  N.bPalm = S => { const t = T(S);
    const D = { w: t >= 3 ? 90 : 50, d: 50, round: 1 };
    D.build = P => [cyl(0, 0, 0, t >= 3 ? 34 : 18, 4, SAND, pt({ n: 18, rg: [[0, 0, 1.15], [4, 0, 0.8]] }))].concat(t === 5 ? [cyl(0, 4, 0, 14, 1, '#ffe08a', em({ n: 16 }))] : []);
    D.fx = c => { const p = c.p, k = c.k; let f = '', bb = [p(-40, 0, -30), p(40, 0, 30)], defs = GLW;
      const add = r => { f += r.s; bb = bb.concat(r.pts); };
      if (t === 1) add(palm(p, k, 0, 0, 62, 22, 'p1', { nf: 5, L: 22, nuts: 0, tw: 3.2, leaf: ['#7a9a4a', '#8aa85a'] }));
      else if (t === 2) add(palm(p, k, 0, 0, 120, 16, 'p2'));
      else if (t === 3) { add(palm(p, k, -18, -6, 112, -18, 'p3a')); add(palm(p, k, 18, 6, 128, 18, 'p3b')); }
      else if (t === 4) { add(palm(p, k, -26, -8, 108, -16, 'p4a')); add(palm(p, k, 24, -4, 126, 14, 'p4b')); add(palm(p, k, 0, 14, 92, 6, 'p4c', { nuts: 2 }));
        const a = p(-42, 96, -12), b = p(38, 112, -2), cc = p(6, 86, 16); let lt = PP(`M${P2(a)}Q${P2(p(0, 82, -6))} ${P2(b)}M${P2(a)}Q${P2(p(-18, 76, 4))} ${P2(cc)}`, 'none', '#4a3a30', 0.8); rep(8, i => { const u = (i + 0.5) / 8, q = [a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u + Math.sin(u * PI) * 10 * k]; lt += `<circle cx="${f1(q[0])}" cy="${f1(q[1] + 2)}" r="${f1(2 * k)}" fill="${['#ff9d4a', '#ffd66b', '#6ac8ff', '#a6f06a'][i % 4]}">${AN('opacity', '1;0.4;1', 1.4, -i * 0.2)}</circle>`; }); f += lt; }
      else { add(palm(p, k, 0, 0, 124, 14, 'p5', { trunk: '#e2b14a', leaf: ['#3fae7a', '#e8c84a', '#4fc08a'], nutC: '#fff6c8' })); f += glowAt(p(14, 124, 4), 54 * k, 'bhG', 0.6) + rep(6, i => `<circle r="${f1(1.4 * k)}" fill="#fff6c8"><animateMotion dur="${3 + i * 0.5}s" begin="${-i * 0.6}s" repeatCount="indefinite" path="M${P2(p(-20 + i * 8, 20, 6))}L${P2(p(-24 + i * 9, 120, 6))}"/>${AN('opacity', '0;1;0', 3 + i * 0.5, -i * 0.6)}</circle>`).join(''); }
      return { defs, front: f, bb: bbOf(bb, 6) }; };
    return D; };

  // ======================= HAMMOCK =======================
  N.bHammock = S => { const t = T(S), XP = 62, HP = 58;
    const D = { w: 160, d: 50, act: 'nap', seats: [{ x: 0, z: 0, h: 22, k: 'nap' }] };
    D.build = P => { const o = [];
      if (t === 1) [-XP, XP].forEach((x, i) => o.push(cyl(x, 0, 0, 3.4, HP + (i ? 2 : -2), '#a8977c', wd({ n: 8, rg: [[0, 0, 1], [HP, 0, 0.75]] }))));
      else if (t === 2) { [-XP, XP].forEach(x => o.push(box(x, 0, 0, 4, HP, 4, '#3e4046', mt({ r: 1 })), box(x, 0, 0, 6, 3, 36, '#3e4046', mt({ r: 1 })))); o.push(box(0, 0, 0, 2 * XP + 6, 3, 4, '#3e4046', mt({ r: 1 }))); }
      else if (t === 4) [-XP, XP].forEach(x => o.push(cyl(x, 0, 0, 3, 90, '#c49a62', wd({ n: 8 }))));
      else if (t === 5) [-XP, XP].forEach(x => o.push(cyl(x, 0, 0, 2.4, HP + 8, '#f4f1ea', pt({ n: 8 })), ball(x, HP + 10, 0, 4, '#fff6c8', em({ k: 4 }))));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', bb = [p(-90, 0, -30), p(90, 0, 30), p(0, 70, 0)], defs = GLW;
      if (t === 3) [[-XP, 'h3a', -10], [XP, 'h3b', 12]].forEach(([x, sd, l]) => { const r = palm(p, k, x, 0, 104, l, sd, { nuts: 2 }); f += r.s; bb = bb.concat(r.pts); });
      const W = 16, sag = 24, cols = [['#c9b896', '#a89878'], ['#ffffff', '#3fb0c8'], ['#e8d2a0', '#c9a870'], ['#f6efe0', '#e3946a'], ['#ffffff', '#e6f0ff']][t - 1];
      const edge = z => rep(13, i => { const u = i / 12, x = -XP + 6 + (2 * XP - 12) * u; return [x, HP - 4 - Math.sin(u * PI) * sag, z]; }), A = edge(-W / 2), Bk = edge(W / 2);
      let band = ''; rep(12, i => { const q = [A[i], A[i + 1], Bk[i + 1], Bk[i]]; band += PP(PQ(p, q), cols[i % 2 && t === 2 ? 1 : 0], ink(cols[0]), 0.4); });
      f += PP(`M${P2(p(-XP, HP, 0))}L${P2(p(...A[0]))}M${P2(p(-XP, HP, 0))}L${P2(p(...Bk[0]))}M${P2(p(XP, HP, 0))}L${P2(p(...A[12]))}M${P2(p(XP, HP, 0))}L${P2(p(...Bk[12]))}`, 'none', '#8a6a48', 1) + band;
      if (t === 1) f += PP(rep(12, i => `M${P2(p(...A[i]))}L${P2(p(...Bk[i + 1]))}M${P2(p(...Bk[i]))}L${P2(p(...A[i + 1]))}`).join(''), 'none', '#6a5a44', 0.6);
      if (t === 4) { f += PP(`M${P2(p(-XP, 90, 0))}Q${P2(p(0, 78, -24))} ${P2(p(XP, 90, 0))}L${P2(p(0, 70, 30))}Z`, '#fffaf1', '#c9b896', 1, ' opacity="0.92"'); rep(10, i => { const u = (i + 0.5) / 10, q = p(-XP + 2 * XP * u, HP - 4 - Math.sin(u * PI) * sag, W / 2); f += PP(`M${P2(q)}l0 ${f1(8 * k)}`, 'none', '#e3946a', 1.2); }); }
      if (t === 5) { rep(6, i => { const u = (i + 0.5) / 6, q = p(-XP + 2 * XP * u, HP - 6 - Math.sin(u * PI) * sag, W / 2 + 2); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1] + 3)}" r="${f1(5 * k)}" fill="#ffffff" opacity="0.9"/>`; });
        let fl = ''; rep(12, i => { const u = (i + 0.5) / 12, q = p(-XP + 2 * XP * u, HP + 8 - Math.sin(u * PI) * 8, 0); fl += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.6 * k)}" fill="#fff6c8">${AN('opacity', '1;0.3;1', 1.6, -i * 0.13)}</circle>`; }); f += PP(`M${P2(p(-XP, HP + 8, 0))}Q${P2(p(0, HP, 0))} ${P2(p(XP, HP + 8, 0))}`, 'none', '#6a5a4a', 0.6) + fl; }
      return { defs, front: f, bb: bbOf(bb, 4) }; };
    return D; };

  // ======================= BEACH CABANA =======================
  N.bCabana = S => { const t = T(S), W = 50, DZ = 34, H = [58, 54, 78, 76, 84][t - 1];
    const D = { w: 130, d: 100, act: 'nap', seats: [{ x: -18, z: 4, h: t >= 3 ? 16 : 3, k: 'nap' }, { x: 20, z: 4, h: t >= 3 ? 16 : 3, k: 'sit' }] };
    D.build = P => { const o = [], post = { 1: '#9a8f80', 3: '#ffffff', 4: '#8a5a2c', 5: GOLD }[t];
      if (post) [[-W, -DZ], [W, -DZ], [-W, DZ], [W, DZ]].forEach(([x, z]) => o.push(cyl(x, 0, z, t === 1 ? 1.6 : 2.6, H, post, t === 5 ? mt({ n: 10, shine: 1 }) : wd({ n: 8 }))));
      if (t === 2) o.push(ball(0, 0, 0, 56, '#3fb0c8', fb({ sy: 0.9, sz: 0.7, k: 6, n: 22 })), box(0, 0, 0, 100, 1.4, 70, '#2f8aa8', fb({ r: 3 })));
      if (t >= 3) o.push(cush(0, 0, 4, 2 * W - 8, 14, 2 * DZ - 12, t === 5 ? '#f6e2b6' : '#ffffff', fb()), ...[-24, 0, 24].map((x, i) => ball(x, 18, -18, 7, ['#3fb0c8', '#ffd66b', '#e3946a'][i], fb({ sx: 1.5, sy: 1.1, sz: 0.7, k: 4 }))));
      else if (t === 1) o.push(box(0, 0, 4, 80, 1.2, 56, '#d8d0c0', fb({ r: 2 })));
      if (t === 3) o.push(box(0, H, 0, 2 * W + 8, 4, 2 * DZ + 8, '#ffffff', fb({ r: 2 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', defs = GLW;
      if (t === 1) f += PP(PQ(p, [[-W - 4, H + 2, -DZ - 4], [W + 4, H + 2, -DZ - 4], [W + 6, H - 10, DZ + 8], [-W - 6, H - 14, DZ + 6]]), '#efe8d8', '#b8ae9a', 1, ' opacity="0.95"') + PP(`M${P2(p(-W + 10, H - 6, 0))}l${f1(10 * k)} ${f1(2 * k)}`, 'none', '#d8a0a0', 2);
      if (t === 2) { const q = p(0, 22, 40); f += PP(`M${f1(q[0] - 12 * k)} ${f1(q[1] + 12 * k)}Q${f1(q[0])} ${f1(q[1] - 18 * k)} ${f1(q[0] + 12 * k)} ${f1(q[1] + 12 * k)}Z`, '#1e5a72', '#123a4a', 0.8) + rep(5, i => PP(PQ(p, rep(9, j => { const a = -PI / 2 + (j / 8) * PI, r = 56; return [Math.cos(a) * r * 0.3 * (i - 2), Math.sin(a + PI / 2) * 50, Math.cos(a) * 0]; })), 'none', '#ffffff', 0, '')).join(''); }
      if (t === 3) { [[-W, -DZ], [W, -DZ], [-W, DZ], [W, DZ]].forEach(([x, z], i) => { const a = p(x, H, z), b = p(x + (x < 0 ? 10 : -10), H * 0.45, z); f += `<g>${sway(a, 1.6, 4, -i)}${PP(`M${P2(a)}Q${f1(b[0] - 4 * k)} ${f1((a[1] + b[1]) / 2)} ${P2(b)}Q${f1(b[0] + 2 * k)} ${f1(b[1] + 14 * k)} ${P2(p(x, 0, z))}L${f1(p(x, 0, z)[0] + (x < 0 ? -3 : 3) * k)} ${f1(p(x, 0, z)[1])}Q${P2(p(x, H * 0.6, z))} ${f1(a[0] + (x < 0 ? -2 : 2) * k)} ${f1(a[1])}Z`, '#fffaf6', '#d8d0c4', 0.8, ' opacity="0.95"')}</g>`; }); }
      if (t === 4) f += cone(p, k, { y: H, h: 26, R: 76, n: 4, a0: PI / 4, cols: ['#d8b46a', '#c9a45a'], fringe: '#b8924a', droop: 0, fl: 10 });
      if (t === 5) { f += cone(p, k, { y: H, h: 30, R: 70, n: 8, cols: ['#f6efe0', '#e8d6f0'], scallop: 1, tassel: GOLD }); const q = p(0, H + 30, 0); f += PP(`M${P2(q)}l0 ${f1(-10 * k)}`, 'none', GOLD, 2) + `<circle cx="${f1(q[0])}" cy="${f1(q[1] - 12 * k)}" r="${f1(3 * k)}" fill="${GOLD}" stroke="#8a5d00" stroke-width="0.6"/>` + glowAt(p(0, 20, 0), 50 * k, 'bhG', 0.4); }
      return { defs, front: f, bb: bbOf([p(-W - 16, 0, -DZ - 16), p(W + 16, 0, DZ + 16), p(-W - 16, 0, DZ + 16), p(W + 16, 0, -DZ - 16), p(0, H + 44, 0), p(-W - 16, H, 0), p(W + 16, H, 0)], 4) }; };
    return D; };

  // ======================= SHELL COLLECTION =======================
  N.bShells = S => { const t = T(S);
    const D = { w: 70, d: 50 };
    D.build = P => { const o = [];
      if (t === 1) o.push(cyl(0, 0, 0, 10, 22, '#dff2f6', cer({ n: 14, shine: 1, rg: [[0, 0, 0.94], [18, 0, 1], [22, 0, 0.76]] })), cyl(0, 22, 0, 8, 3, '#c9cdd2', mt({ n: 12 })));
      else if (t === 2) o.push(cyl(0, 0, 0, 2.4, 70, '#a8977c', wd({ n: 8 })), cyl(0, 0, 0, 7, 2, SANDD, pt({ n: 10 })), box(0, 66, 0, 34, 3, 3, '#b8a07a', wd({ r: 1 })));
      else if (t === 3) o.push(box(0, 0, 0, 74, 4, 30, '#a8977c', wd({ r: 2 })), ...[-30, 30].map(x => box(x, 4, 0, 6, 34, 26, '#a8977c', wd({ r: 1 }))), box(0, 22, 0, 66, 3, 26, '#b8a68a', wd({ r: 1 })), box(0, 38, 0, 74, 4, 30, '#a8977c', wd({ r: 2 })));
      else if (t === 4) o.push(box(0, 0, 0, 56, 26, 36, '#8a5a2c', wd({ r: 3, bev: 1.6 })), ...[-20, 20].map(x => box(x, 0, 0, 4, 27, 37, GOLD, mt({ r: 1 }))), prismZ(-18, 18, [[-28, 26], [28, 26], [26, 38], [-26, 38]], '#9a6a38', wd()));
      else o.push(cyl(0, 0, 0, 22, 6, '#f4efe6', cer({ n: 20, shine: 1 })), ball(0, 22, 0, 18, '#ffd6c8', cer({ sx: 1.3, k: 6, shine: 1 })), cyl(10, 30, 0, 9, 22, '#ffe6dc', cer({ n: 14, rg: [[0, 0, 1], [22, 0, 0.1]], shine: 1 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', defs = GLW; const SH = BE.SHELLK, sh = (q, i, s) => { const [a, b] = SH[i % SH.length]; return `<g transform="translate(${P2(q)}) scale(${n4(k * (s || 1))})"><path d="M-4 1.4C-4-3 4-3 4 1.4Q0 3-4 1.4Z" fill="${a}" stroke="${b}" stroke-width="0.6"/><path d="M0 2V-2M-2 2L-1-2M2 2L1-2" stroke="${b}" stroke-width="0.4"/></g>`; };
      if (t === 1) rep(5, i => f += sh(p(-4 + (i % 3) * 4, 4 + i * 3, 9), i, 0.8));
      if (t === 2) rep(5, i => { const x = -15 + i * 7.5, a = p(x, 66, 0), b = p(x, 36 + (i % 2) * 8, 0); f += `<g>${sway(a, 6, 2.2 + i * 0.2, -i * 0.3)}${PP(`M${P2(a)}L${P2(b)}`, 'none', '#e8dcc0', 0.6)}${sh(b, i)}${sh([b[0], b[1] - 9 * k], i + 2, 0.8)}</g>`; });
      if (t === 3) [[22], [41]].forEach(([y]) => rep(5, i => f += sh(p(-24 + i * 12, y + 1, 4), i + y, 1.2)));
      if (t === 4) { rep(7, i => f += sh(p(-18 + i * 6, 34 + (i % 2) * 2, 12), i, 1.1)); rep(4, i => { const q = p(-12 + i * 8, 33, 14); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(2.4 * k)}" fill="#fffaf6" stroke="#d8d0c8" stroke-width="0.5"/>`; }); f += glowAt(p(0, 34, 10), 20 * k, 'bhG', 0.6); }
      if (t === 5) { const q = p(0, 28, 16); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(5 * k)}" fill="#fffaf6" stroke="#e8d8d0" stroke-width="0.6"/>` + glowAt(q, 30 * k, 'bhG', 0.9); }
      return { defs, front: f, bb: bbOf([p(-44, 0, -30), p(44, 0, 30), p(-44, 0, 30), p(44, 0, -30), p(0, t === 2 ? 76 : 60, 0)], 4) }; };
    return D; };

  // ======================= SAND TOYS =======================
  N.bToys = S => { const t = T(S);
    const D = { w: 80, d: 60, act: 'dig', use: { x: 0, z: 40 } };
    D.build = P => { const o = [], bc = ['#d8a090', '#ff6a5a', '#4fb0f0', '#ffd23f', GOLD][t - 1];
      if (t !== 3) o.push(cyl(-14, 0, 0, 10, 16, bc, (t === 5 ? mt : pt)({ n: 14, rg: [[0, 0, 0.82], [16, 0, 1]], shine: t === 5 ? 1 : 0 })), cyl(-14, 15, 0, 9, 0.6, SAND, pt({ n: 14 })));
      if (t === 2) o.push(cyl(16, 0, 10, 7, 5, '#a6e870', pt({ n: 10 })), cyl(24, 0, -6, 6, 6, '#ffb3c8', pt({ n: 5 })));
      if (t === 3) o.push(ball(-10, 12, 4, 12, '#ffffff', cer({ k: 6, shine: 1 })));
      if (t === 4) o.push(box(20, 6, 0, 36, 10, 22, '#e2554a', pt({ r: 2 })), ...[[6, 12], [34, 12], [6, -12], [34, -12]].map(([x, z]) => cyl(x, 0, z, 5, 3, '#2c2d31', mt({ n: 10 }))), arcW(-16, 0, 16, 14, 12, 6, 6, 0, 2 * PI, '#ff8ac0', cer({ n: 18, shine: 1 })));
      if (t === 5) o.push(box(16, 0, 10, 34, 1, 24, '#f2e2b6', fb({ r: 1 })), box(-2, 0, -14, 20, 12, 14, '#8a5a2c', wd({ r: 2 })), box(-2, 12, -14, 21, 3, 15, GOLD, mt({ r: 1 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', defs = GLW; const spade = (base, col) => { const a = p(...base), b = p(base[0] + 4, base[1] + 26, base[2]); return PP(`M${P2(a)}L${P2(b)}`, 'none', '#8a6a48', 1.6) + PP(`M${f1(a[0] - 4 * k)} ${f1(a[1])}l${f1(4 * k)} ${f1(6 * k)}l${f1(4 * k)} ${f1(-6 * k)}l${f1(-1 * k)} ${f1(-5 * k)}h${f1(-6 * k)}Z`, col, ink(col), 0.6); };
      if (t === 1 || t === 2) f += spade([10, 0, 14], t === 1 ? '#9aa1a6' : '#3fb0c8');
      if (t === 3) { const q = p(-10, 12, 4); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><path d="M-12 0A12 12 0 0 1 12 0" fill="none" stroke="#e2554a" stroke-width="5" opacity="0.85" transform="rotate(-20)"/><path d="M-10 -6A12 12 0 0 1 10 -6" fill="none" stroke="#ffd23f" stroke-width="3" opacity="0.85"/></g>`;
        const a = p(20, 2, 10), kt = p(34, 84, -6); f += PP(`M${P2(a)}Q${P2(p(40, 40, 0))} ${P2(kt)}`, 'none', '#ffffff', 0.6) + `<g>${AT('translate', '0 0;3 -4;0 0', 3)}<path d="M${f1(kt[0])} ${f1(kt[1] - 14 * k)}l${f1(9 * k)} ${f1(10 * k)}l${f1(-9 * k)} ${f1(10 * k)}l${f1(-9 * k)} ${f1(-10 * k)}Z" fill="#ff6a8a" stroke="#8a2a40" stroke-width="0.8"/><path d="M${f1(kt[0])} ${f1(kt[1] + 6 * k)}q${f1(-4 * k)} ${f1(6 * k)} 0 ${f1(12 * k)}" fill="none" stroke="#ffd23f" stroke-width="1.4"/></g>`; }
      if (t === 4) { const pts = curve([-28, 6, 16], [-36, 26, 16], [-26, 36, 16], 6).map(q => p(...q)); f += tube(pts, 4, k, '#ff8ac0', '#ffd0e6', '#a8406a'); const h = p(-26, 38, 16); f += `<circle cx="${f1(h[0])}" cy="${f1(h[1])}" r="${f1(4.6 * k)}" fill="#ff8ac0" stroke="#a8406a" stroke-width="0.6"/><path d="M${f1(h[0] + 3 * k)} ${f1(h[1])}l${f1(5 * k)} ${f1(3 * k)}l${f1(-5 * k)} ${f1(1 * k)}Z" fill="#2c2d31"/>`; }
      if (t === 5) { f += `<g transform="${planeH(p, 1.2, 16, 10)}"><path d="M-12 -6L4 2L10 -4" stroke="#c4651f" stroke-width="1.2" fill="none" stroke-dasharray="2 2"/><path d="M8 -6l4 4m0 -4l-4 4" stroke="#e2554a" stroke-width="1.6"/></g>` + spade([30, 0, -8], GOLD) + glowAt(p(-2, 14, -14), 22 * k, 'bhG', 0.7); }
      return { defs, front: f, bb: bbOf([p(-46, 0, -34), p(46, 0, 34), p(-46, 0, 34), p(46, 0, -34), p(0, t === 3 ? 100 : 50, 0), p(40, 90, -6)], 4) }; };
    return D; };

  // ---------- catalog rows (20 slots x 5 tiers) ----------
  const TN = ['Tier 1: Starter / Fixer-Upper', 'Tier 2: Cozy Budget', 'Tier 3: Modern Stylish', 'Tier 4: Designer Luxury', 'Tier 5: Ultimate / Mythic'], RAR = ['Common', 'Uncommon', 'Rare', 'Epic', 'Legendary'], BASE = [320, 1400, 4800, 14000, 42000];
  const TAG = { sun: ['Sunbathe', 'Tap with a friend selected: they lie down and soak up the sun.', 'Restores energy'], nap: ['Nap', 'Tap with a friend selected: they curl up for a nap in the shade.', 'Restores energy'], build: ['Build', 'A friend builds and pats the sandcastle into shape.', 'Restores fun'],
    surf: ['Surf', 'A friend grabs a board and rides the waves out at sea.', 'Restores fun and gets them clean'], treat: ['Treats', 'A friend gets a treat and eats it right there.', 'Restores hunger'], roast: ['Roast', 'Up to 3 friends sit round the fire and roast marshmallows.', 'Restores hunger and fun'],
    splash: ['Splash', '2 friends splash about with the crabs.', 'Restores fun'], ride: ['Ride', 'Floats out at sea. A friend climbs on and bobs on the waves.', 'Restores fun'], sit: ['Sit', 'A friend climbs up and keeps watch over the sea.', 'Restores energy'], dig: ['Dig', 'A friend digs in the sand with it.', 'Restores fun'],
    game: ['Match \u00b7 2 friends', 'Tap to start a beach volleyball match. Needs 2 friends at the Beach.', 'Free friends come and play'], deco: ['Decor', 'Makes the Beach look lovely.'], shells: ['Shells', 'Shows off the shells your squad finds on the sand. Tap it to count them.'] };
  const SLOTS = [
    ['Beach Sand', 'Floor', 's:ground', 1.2, ['Pebbly Grey Sand with Seaweed & a Soda Can', 'Raked Golden Sand', 'Fine White Sand with Shell Flecks', 'Pink Coral Sand with Sea Glass', 'Glittering Starlight Sand'], { surf: 'ground', tag: ['Sand', 'Covers the whole Beach.'] }],
    ['Pier & Boardwalk', 'Walls', 's:fence', 1.3, ['Rickety Driftwood Pier with Missing Boards', 'Sun-Bleached Boardwalk with Rope Railing', 'Painted White Pier with Lamp Posts', 'Teak Yacht Dock with Brass Cleats & Flags', 'Royal Marble Jetty with Golden Lanterns'], { surf: 'fence', tag: ['Pier', 'Rebuilds the pier. Friends fish from its end.'] }],
    ['Beach Lights', 'Ceiling', 's:ylight', 1, ['Flashlight Taped to a Driftwood Post', 'Solar Path Lights Along the Dunes', 'Tiki Torches on the Dune Fence', 'Paper Lantern Strings over the Sand', 'Glowing Bioluminescent Shoreline'], { surf: 'ylight', tag: ['Lights', 'Lights up the Beach. Glows when the Bedroom lights are off.'] }],
    ['Sun Lounger', 'Furniture', 'bLounger', 1, ['Sagging Lawn Lounger with Torn Webbing', 'Striped Canvas Deck Lounger', 'Teak Sun Lounger with Navy Cushion', 'Double Daybed Lounger with Fringed Canopy', 'Floating Pearl-Shell Lounger'], { tag: 'sun' }],
    ['Beach Umbrella', 'Furniture', 'bUmbrella', 0.9, ['Faded Patched Umbrella Stuck in the Sand', 'Rainbow Striped Beach Umbrella', 'Fringed Tiki Straw Parasol', 'Scalloped Cabana Umbrella with Tassels', 'Giant Seashell Parasol with Pearl Lamp'], { tag: 'nap' }],
    ['Beach Towel', 'Floor', 'bTowel', 0.7, ['Threadbare Old Bath Towel', 'Striped Beach Towel & Flip-Flops', 'Round Mandala Beach Blanket', 'Plush Padded Sunbed Mat with Pillows', 'Golden Silk Royal Sun Mat'], { tag: 'sun' }],
    ['Sandcastle', 'Furniture', 'bCastle', 0.9, ['Lumpy Bucket-Mould Sand Pile', 'Classic Sandcastle with Paper Flag', 'Three-Tower Castle with a Moat', 'Grand Sand Palace with Shell Mosaics', 'Crystal Sand Citadel with Glowing Windows'], { tag: 'build' }],
    ['Surf Spot', 'Furniture', 'bSurf', 1.1, ['Cracked Foam Bodyboard on a Post', 'Retro Longboard on a Wooden Rack', 'Twin Surfboard Rack with Wetsuit', 'Thatched Surf Rack with Hibiscus Boards', 'Hover Surfboard Dock with Wave Glow'], { tag: 'surf' }],
    ['Beach Games', 'Furniture', 'bVolley', 1.1, ['Sagging Rope Net Between Two Sticks', 'Volleyball Net with Painted Court Lines', 'Pro Volleyball Court with Flags', 'Volleyball Arena with Scoreboard', 'Starlight Volleyball Court with Glow Ball'], { tag: 'game', game: 1 }],
    ['Snack Shack', 'Furniture', 'bShack', 1.3, ['Crate Lemonade Stand with a Hand-Drawn Sign', 'Ice Cream Cart with Striped Umbrella', 'Thatched Smoothie Hut', 'Surfside Snack Bar with Neon Cone', 'Golden Ice Cream Palace Kiosk'], { tag: 'treat' }],
    ['Bonfire', 'Furniture', 'bFire', 1.2, ['Driftwood Twig Campfire in a Sand Pit', 'Stone Ring Bonfire with Log Seats', 'Iron Fire Bowl with Marshmallow Sticks', 'Sunken Fire Pit Lounge with Cushions', 'Blue Flame Crystal Bonfire'], { tag: 'roast', live: 'Fire crackling' }],
    ['Tide Pool', 'Furniture', 'bTide', 1, ['Muddy Puddle with One Shy Crab', 'Rock Pool with Starfish & Crabs', 'Mossy Tide Pool with Anemones', 'Coral Grotto Pool with Little Fish', 'Glowing Moon Tide Pool'], { tag: 'splash', live: 'Crabs scuttling' }],
    ['Float & Boat', 'Furniture', 'bFloat', 1.2, ['Patched Inner Tube', 'Rubber Duck Pool Float', 'Wooden Rowboat', 'Swan Pedal Boat', 'Golden Royal Barge'], { tag: 'ride', sea: 1 }],
    ['Lifeguard Tower', 'Furniture', 'bTower', 1.1, ['Upturned Crate Lookout', 'Wooden Lifeguard Chair with Umbrella', 'Classic Red Lifeguard Tower', 'Lifeguard Hut with Flag & Life Ring', 'Lighthouse Lookout Tower'], { tag: 'sit' }],
    ['Cooler & Drinks', 'Furniture', 'bCooler', 0.8, ['Dented Foam Cooler', 'Retro Red Picnic Cooler', 'Rolling Drinks Cart with Coconuts', 'Tiki Barrel with Pineapple Cups', 'Golden Fountain Drinks Cooler'], { tag: 'treat' }],
    ['Palm Tree', 'Furniture', 'bPalm', 1, ['Scraggly Leaning Palm Sapling', 'Coconut Palm', 'Twin Palms with Coconuts', 'Palm Trio with String Lights', 'Golden Glow Palm'], { tag: 'deco', live: 'Swaying in the breeze' }],
    ['Hammock', 'Furniture', 'bHammock', 1, ['Fishing Net Hammock on Driftwood Posts', 'Striped Canvas Hammock on a Stand', 'Rope Hammock Between Two Palms', 'Macram\u00e9 Hammock with Shade Sail', 'Cloud Hammock with Fairy Lights'], { tag: 'nap' }],
    ['Beach Cabana', 'Furniture', 'bCabana', 1.2, ['Bedsheet Tent on Broomsticks', 'Striped Pop-Up Beach Tent', 'White Curtain Cabana', 'Thatched Tiki Cabana with Daybed', 'Royal Silk Pavilion with Gold Finial'], { tag: 'nap' }],
    ['Shell Collection', 'Furniture', 'bShells', 0.7, ['Jam Jar of Broken Shells', 'Shell Wind Chime on a Post', 'Driftwood Shelf of Seashells', 'Treasure Chest of Shells & Pearls', 'Giant Conch with Pearl Glow'], { tag: 'shells', kind: 'shells' }],
    ['Sand Toys', 'Furniture', 'bToys', 0.6, ['Cracked Bucket & Bent Spade', 'Bucket, Spade & Moulds Set', 'Beach Ball & Kite Bundle', 'Inflatable Flamingo & Toy Wagon', 'Treasure Map & Golden Spade'], { tag: 'dig' }],
  ];
  const ROWS = [];
  SLOTS.forEach(([slotName, cat, spec, fac, names, ex], si) => names.forEach((name, ti) => { const tier = ti + 1, n = ti * 20 + si + 1, cost = Math.round(BASE[ti] * fac / 5) * 5, tg = Array.isArray(ex.tag) ? ex.tag : TAG[ex.tag];
    const r = { id: 'BCH-' + String(n).padStart(3, '0'), room: 'BCH', roomName: 'Beach', lv: LVOF(tier), tier, tierName: TN[ti], rarity: RAR[ti], slot: si + 1, cat, slotName, name, cost, stat: 'Fun & Sun', bonus: '+' + (tier * 5 + (si % 4)) + ' Fun & Sun', spec, catO: cat, btag: tg, beach: 1 };
    if (ex.surf) r.bsurf = ex.surf; if (ex.sea) r.sea = 1; if (ex.live) r.live = ex.live; if (ex.kind) r.kind = ex.kind;
    if (ex.game) Object.assign(r, { play: 'game', need: 2, loop: 60 });
    r.note = name + '. ' + tg[1] + (tg[2] ? ' ' + tg[2] + '.' : '');
    ROWS.push(r); }));
  function LVOF() { return BE.LV; }
  const edit0 = RD.edit;
  RD.edit = rows => { const out = edit0(rows); return out.some(r => r.room === 'BCH') ? out : out.concat(ROWS.map(r => Object.assign({}, r))); };
  // ---------- draw hook: beach surfaces (scene cut-outs) + volleyball players ----------
  const BPL = { bVolley: () => [{ x: -52, z: 22, v: 'right', a: 'gjump' }, { x: 52, z: -14, v: 'left', a: 'gjump', d: 0.5 }] };
  const SM = new Map(), d0 = RD.draw;
  RD.draw = (r, o) => {
    if (r && r.room === 'BCH' && r.bsurf) { const key = r.id; if (SM.has(key)) return SM.get(key); const svg = BE.thumb(r.bsurf, r.tier), m = svg.match(/viewBox="([^"]+)"/), res = { svg, src: 'data:image/svg+xml,' + encodeURIComponent(svg), w: 0, h: 0, surf: true, vb: m ? m[1] : '0 0 80 56', kind: r.bsurf, arch: 's:' + r.bsurf, band: 'mod', err: '' }; SM.set(key, res); return res; }
    const res = d0(r, o); if (!res || !r || r.room !== 'BCH' || res._bp) return res; res._bp = 1;
    try { const sp0 = r.spec ? r.spec.split(/[.@*+]/)[0] : ''; if (BPL[sp0] && res.bb) { const p = RD.projOf(1); res.players = BPL[sp0]().map(q => { const s = p(q.x, q.y || 0, q.z); return { x: s[0], y: s[1], v: q.v, a: q.a, b: !!q.b, d: q.d || 0 }; }); } } catch (e) { console.warn('beach draw', r.id, e); }
    return res; };
  RD.BEACH = 1; BE.items = 1; BE.ROWS = ROWS;
})();
