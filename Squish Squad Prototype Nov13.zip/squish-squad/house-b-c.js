// Per-creature [B] list moves (sinkwash, brush, dinein / dine / dineout, surf, fishing, sunin / sun / sunout, slide, bouncein / bounce / bounceout, digin / dig / digout, blocksin / blocks / blocksout, water, roastin / roast / roastout).
// fc = what he catches when fishing (ICON key), tk = his own trick at the top of the trampoline star jump (channels), tb = toothbrush colour,
// sig = his play signature from the play table (p), sun sig = his sleepy signature from the bedtime table (s); cheer / cheerFx come from the shared WX table; sn (snack at the table) from the play table.
window.HouseCreatures = window.HouseCreatures || []; window.HouseCreatures.push(function (H) {
  const { bBuild, PROF, o } = H;
  const TBC = ['#5fb8e8', '#7cc35a', '#ff8fa8', '#ffcc3a', '#b98ae8', '#ff8a4a'];
  const C = {
    // ---------- Pet Shop ----------
    mittens: { fc: 'fish', tk: { curl: 0.8, sqz: 0.6 } }, biscuit: { fc: 'boot', tk: { wag: 30, tongue: 0.6, earL: -16, earR: -16 } }, prickle: { fc: 'crab', tk: { curl: 1, close: 1 } }, truffle: { fc: 'boot', tk: { wag: 24, sqz: 0.5 } }, ribbit: { fc: 'crab', tk: { lift: 3, hap: 1 } },
    nibbles: { fc: 'nut', tk: { puff: 1 } }, quill: { fc: 'leaf', tk: { blush: 1, sqz: 0.6 } }, poppy: { fc: 'carrot', tk: { earL: -20, earR: -20 } }, duchess: { fc: 'fish', tk: { htilt: 10, close: 0.6 } }, mamapaws: { fc: 'bone', tk: { wag: 22 } },
    // ---------- Sky & Stars ----------
    nimbo: { fc: 'drop', tk: { puff: 0.7 } }, lumi: { fc: 'star', tk: { glow: 1 } }, bubbly: { fc: 'bubble', tk: { puff: 0.6 } }, twinkle: { fc: 'star', tk: { glow: 1 } }, zappi: { fc: 'bolt', tk: { zap: 1 } }, plip: { fc: 'drop', tk: { sq: -0.16 } },
    breeze: { fc: 'leaf', tk: { puff: 0.7 } }, dusty: { fc: 'flower', tk: { earL: -14, earR: 14 } }, aurora: { fc: 'fish', tk: { spout: 1, glow: 0.8 } },
    // ---------- Snack Shack ----------
    mallow: { fc: 'candy', tk: { sq: -0.2 } }, bao: { fc: 'cup', tk: { sqz: 0.8 } }, dunkie: { fc: 'cup', tk: { turn: 0.4 } }, frybo: { fc: 'ketchup', tk: { fw: 1 } }, bunbun: { fc: 'cheese', tk: { split: 0.8 } }, choco: { fc: 'nut', tk: { sqz: 0.8 } },
    scoop: { fc: 'cherry', tk: { chb: 1 } }, boba: { fc: 'cup', tk: { slurp: 0.8 } }, chefbun: { fc: 'fish', tk: { sqz: 0.7, blush: 0.6 } },
    // ---------- Ocean Pals ----------
    pip: { fc: 'fish', tk: { armL: 100, armR: 100 } }, jelli: { fc: 'bubble', tk: { sq: -0.18 } }, finn: { fc: 'star', tk: { wag: 30 } }, sealy: { fc: 'fish', tk: { open: 0.6 } }, puff: { fc: 'shell', tk: { blo: 1, puff: 1 } }, shelly: { fc: 'leaf', tk: { nk: 1 } },
    octo: { fc: 'crab', tk: { osp: 1, ow: 1 } }, marina: { fc: 'pearl', tk: { tlf: 0.8 } }, pearl: { fc: 'star', tk: { glow: 1, hsw: 0.6 } },
    // ---------- Fruit Patch ----------
    pina: { fc: 'fish', tk: { crw: 1 } }, avo: { fc: 'boot', tk: { pp: 0.6 } }, berri: { fc: 'berry', tk: { stw: 1 } }, lemmy: { fc: 'fish', tk: { sqz: 1, mw: 0.4 } }, kiwi: { fc: 'leaf', tk: { fzz: 1 } }, melo: { fc: 'fish', tk: { sdj: 1 } },
    peachy: { fc: 'flower', tk: { blush: 1, lfl: 0.8 } }, pitaya: { fc: 'fish', tk: { wsp: 1, brf: 1, crw: 1 } }, tutti: { fc: 'cherry', tk: { wfl: 1 } },
    // ---------- Forest Friends ----------
    kiko: { fc: 'nut', tk: { earL: -14, earR: -14 } }, teddy: { fc: 'fish', tk: { earL: -10, earR: -10, blush: 0.6 } }, hoot: { fc: 'leaf', tk: { tfl: 1, wfl: 1 } }, leo: { fc: 'fish', tk: { mfl: 1 } }, panko: { fc: 'bamboo', tk: { sqz: 0.7 } },
    acorn: { fc: 'acorn', tk: { tfl: 1 } }, fawn: { fc: 'apple', tk: { earL: -18, earR: -18 } }, moss: { fc: 'leaf', tk: { cb: 1 } }, sprout: { fc: 'drop', tk: { blm: 1 } },
    // ---------- Dreamland ----------
    hana: { fc: 'carrot', tk: { flL: 1, flR: 1 } }, boo: { fc: 'boot', tk: { gho: 0.4, flr: 1 } }, pixie: { fc: 'flower', tk: { wfl: 1, wsp: 0.6 } }, floof: { fc: 'snow', tk: { fzz: 1 } }, unibun: { fc: 'rainbow', tk: { earL: -14, earR: -14 } },
    gumdrop: { fc: 'candy', tk: { jig: 1 } }, ember: { fc: 'fire', tk: { cfl: 1 } }, drako: { fc: 'fish', tk: { wsp: 1, wfl: 1 } }, jinni: { fc: 'star', tk: { glo: 1, gwh: 1 } },
    // ---------- Sweet Bakery ----------
    cuppy: { fc: 'cherry', tk: { sqz: 0.8 } }, chip: { fc: 'cup', tk: { sqz: 0.7 } }, twisty: { fc: 'cheese', tk: { sqz: 0.6 } }, crois: { fc: 'cup', tk: { sqz: 0.6 } }, maca: { fc: 'berry', tk: { sq: -0.14 } }, puddi: { fc: 'cherry', tk: { sq: -0.16 } },
    mochi: { fc: 'berry', tk: { sq: -0.2 } }, cakey: { fc: 'cake', tk: { puff: 0.6 } }, sugarplum: { fc: 'crown', tk: { blush: 0.8 } },
    // ---------- Spooky Squish ----------
    gourdy: { fc: 'boot', tk: { sqz: 0.7 } }, batty: { fc: 'moon', tk: { armL: 90, armR: 90 } }, kernel: { fc: 'candy', tk: { sq: -0.18 } }, hexie: { fc: 'fish', tk: { curl: 0.7 } }, mumbles: { fc: 'boot', tk: { armL: 100, armR: 100 } },
    hocus: { fc: 'star', tk: { sqz: 0.6 } }, countsquishula: { fc: 'cherry', tk: { armL: 120, hLy: -10 } },
  };
  // Waffles is skipped (rig rebuild pending) and keeps the shared default moves
  Object.keys(PROF).forEach((k, i) => { const X = Object.assign({ tb: TBC[i % TBC.length] }, C[k] || {}); if (X.tk) X.tk = o(X.tk); bBuild(k, X); });
});
