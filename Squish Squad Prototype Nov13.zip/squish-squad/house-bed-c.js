// Per-creature bedtime (bed / lie / beanbag: climb in, sleep hold, wake up, climb out) for all 79 house creatures.
// dr = what he dreams about (bubble icon), s = his own sleepy signature move, wk = extra channels in the wake-up stretch, wfx = fx at the stretch,
// lp / bp = lying / curled pose tweaks, qy = quilt a little lower (+) or higher (-), dn = own way of getting into bed.
window.HouseCreatures = window.HouseCreatures || []; window.HouseCreatures.push(function (H) {
  const { bedBuild, hand, both, o, PROF } = H;
  const sp = (t, v, d, hold) => { const b = {}; Object.keys(v).forEach(k => b[k] = t.B[k] != null ? t.B[k] : 0); t.to((d || 700) * 0.4, v, 'o').wait(hold || 300).to((d || 700) * 0.6, b, 'io'); return t; };
  const bk = (t, d) => t.back(d || 420);
  const ear = (t, s, a) => { const e = s < 0 ? 'earL' : 'earR'; t.to(90, { [e]: -(a || 10) }, 'o').to(180, { [e]: 3 }).to(150, { [e]: 0 }); return t; };
  const B = {
    // ---------- Pet Shop ----------
    mittens: { dr: 'fish', wk: { curl: 0.6, earL: -8, earR: -8 }, s: t => { t.to(400, { curl: 0.8, smile: 0.7 }).osc(2600, 6, { hLy: t.B.hLy + 3, hRy: t.B.hRy, sq: t.B.sq + 0.012 }, { hLy: t.B.hLy, hRy: t.B.hRy + 3, sq: t.B.sq }, 's'); bk(t, 500); } },
    biscuit: { dr: 'bone', wk: { wag: 24, earL: -10, earR: -10 }, s: t => { t.to(200, { open: 0.12 }).osc(2000, 10, { footL: t.B.footL + 2.4, footR: t.B.footR, wag: 16 }, { footL: t.B.footL, footR: t.B.footR + 2.4, wag: -16 }, 'l').osc(800, 3, { open: 0.3 }, { open: 0.05 }, 'o'); bk(t, 500); } },
    prickle: { dr: 'apple', wfx: ['spark', 'head', 2], bp: { curl: 1, sq: 0.3 }, s: t => sp(t, { curl: 1, sq: t.B.sq + 0.12, armL: -10, armR: -10 }, 1400, 2200) },
    truffle: { dr: 'apple', wk: { wag: 18 }, s: t => sp(t, { sq: t.B.sq + 0.12, smile: 0.9, blush: 0.6 }, 1600, 1400) },
    ribbit: { dr: 'leaf', s: t => { for (let i = 0; i < 2; i++) t.to(300, { sq: t.B.sq + 0.06 }, 'i').to(500, { sq: t.B.sq - 0.03, lift: t.B.lift + 0.8 }, 'o').to(400, { sq: t.B.sq, lift: t.B.lift }, 's'); bk(t, 300); } },
    nibbles: { dr: 'nut', wk: { puff: 0.6 }, s: t => { t.to(300, { puff: 0.9 }).osc(1800, 6, { open: 0.15, htilt: t.B.htilt + 2 }, { open: 0, htilt: t.B.htilt - 2 }, 's').fx('crumb', 'head'); bk(t, 500); } },
    quill: { dr: 'flower', wk: { blush: 0.6 }, s: t => sp(t, { blush: 0.9, smile: 0.9, htilt: t.B.htilt + 5 }, 1400, 1600) },
    waffles: { dr: 'cookie', wk: { wag: 18 }, s: t => { t.to(800, { sq: t.B.sq + 0.1, lift: t.B.lift - 1 }, 's').osc(1600, 5, { footL: t.B.footL + 2 }, { footL: t.B.footL }, 'l'); bk(t, 600); } },
    poppy: { dr: 'carrot', wk: { earL: -16, earR: -16 }, s: t => { t.osc(1200, 6, { sqz: 0.4, ly: -0.1 }, { sqz: 0, ly: 0 }, 'l'); ear(t, -1, 10); bk(t, 400); } },
    duchess: { dr: 'fish', lp: { htilt: 9 }, wk: { htilt: 8 }, s: t => { t.to(500, o(hand(1, 9, -13), { armR: 30 })).osc(1600, 4, { tongue: 0.5 }, { tongue: 0.1 }, 's'); bk(t, 500); } },
    mamapaws: { dr: 'heart', lp: o(both(9, 3), { armL: 14, armR: 14 }), bp: o(both(9, 3), { armL: 10, armR: 10, curl: 0.6 }), wk: { wag: 12 }, s: t => { t.to(600, o(both(12, 1), { armL: 18, armR: 18, smile: 0.9 })).fx('heart', 'head').wait(1400); bk(t, 600); } },
    // ---------- Sky & Stars ----------
    nimbo: { dr: 'sun', wfx: ['drop', 'body', 4], s: t => { t.fx('drop', 'body', 3).osc(2400, 2, { sq: t.B.sq + 0.06 }, { sq: t.B.sq }, 's').fx('drop', 'body', 3); bk(t, 400); } },
    lumi: { dr: 'star', wfx: ['spark', 'head', 4], s: t => { t.to(600, o(hand(1, 2, -8), { armR: 40 })).fx('spark', 'head', 2).wait(1600); bk(t, 600); } },
    bubbly: { dr: 'bubble', wfx: ['bubble', 'head'], s: t => { t.osc(2400, 2, { turn: 0.3, x: 0.8 }, { turn: -0.3, x: -0.8 }, 's').fx('bubble', 'head'); bk(t, 500); } },
    twinkle: { dr: 'moon', zc: '#c9962a', wfx: ['spark', 'body', 6], s: t => { t.to(400, { glow: 1 }).fx('spark', 'body', 4).wait(1200).to(600, { glow: 0 }); bk(t, 400); } },
    zappi: { dr: 'bolt', wk: { zap: 1 }, wfx: ['spark', 'body', 6], s: t => { t.to(80, { zap: 0.7, x: 0.5 }, 'o').osc(400, 4, { x: -0.5 }, { x: 0.5 }, 'l').fx('spark', 'body', 3).to(300, { zap: 0, x: 0 }); bk(t, 400); } },
    plip: { dr: 'rainbow', wfx: ['drop', 'head', 3], s: t => { t.fx('drop', 'head', 2).osc(1400, 3, { sq: t.B.sq + 0.06 }, { sq: t.B.sq - 0.02 }, 'o'); bk(t, 400); } },
    breeze: { dr: 'cloud', wfx: ['gust', 'head'], s: t => { t.to(500, { puff: 0.6, open: 0.2 }).fx('gust', 'head').to(700, { puff: 0, open: 0 }, 'io'); bk(t, 400); } },
    dusty: { dr: 'star', wfx: ['dust', 'body', 4], s: t => { t.fx('dust', 'body', 3); ear(t, 1, 10); ear(t, -1, 8); bk(t, 400); } },
    aurora: { dr: 'rainbow', wk: { spout: 1 }, wfx: ['drop', 'head', 4], s: t => { t.to(400, { spout: 1 }, 'o').fx('drop', 'head', 4).wait(800).to(500, { spout: 0, glow: 0.8 }).wait(800); bk(t, 600); } },
    // ---------- Snack Shack ----------
    mallow: { dr: 'cup', s: t => sp(t, { sq: t.B.sq + 0.18, lift: t.B.lift - 1.4, smile: 0.9 }, 2000, 1600) },
    bao: { dr: 'star', wfx: ['steam', 'head'], s: t => { t.fx('steam', 'head').osc(1600, 2, { sq: t.B.sq + 0.05 }, { sq: t.B.sq }, 's').fx('steam', 'head'); bk(t, 400); } },
    dunkie: { dr: 'cup', wfx: ['sprinkle', 'head'], s: t => { t.osc(1600, 3, { tilt: t.B.tilt + 3, x: 0.6 }, { tilt: t.B.tilt - 3, x: -0.6 }, 's').fx('sprinkle', 'head'); bk(t, 500); } },
    frybo: { dr: 'ketchup', wk: { fw: 1 }, s: t => { sp(t, { fw: 0.8, smile: 0.8 }, 1400, 1200); t.fx('salt', 'head'); } },
    bunbun: { dr: 'cheese', wk: { split: 0.4 }, s: t => sp(t, { split: 0.3, shuf: 0.3 }, 1400, 1000) },
    choco: { dr: 'heart', s: t => sp(t, { melt: 0.45, smile: 1 }, 2000, 1800) },
    scoop: { dr: 'cherry', wk: { chb: 1 }, s: t => { t.osc(1600, 3, { chb: 0.8 }, { chb: 0 }, 'o'); bk(t, 400); } },
    boba: { dr: 'pearl', wk: { slurp: 0.6 }, s: t => { t.osc(1800, 3, { slurp: 0.5, sqz: 0.3 }, { slurp: 0, sqz: 0 }, 's'); bk(t, 400); } },
    chefbun: { dr: 'cake', s: t => { t.to(400, o(hand(1, 10, -13), { armR: 34 })).wait(300).to(260, o(hand(1, -4, -14), { armR: 60, smile: 1 }), 'o').fx('heart', 'head').wait(500); bk(t, 600); } },
    // ---------- Ocean Pals ----------
    pip: { dr: 'fish', wk: { armL: 120, armR: 120 }, s: t => { t.osc(1400, 6, { armL: 26, armR: 26 }, { armL: 4, armR: 4 }, 'o'); bk(t, 400); } },
    jelli: { dr: 'bubble', wfx: ['bubble', 'head'], s: t => { for (let i = 0; i < 3; i++) t.to(400, { sq: t.B.sq + 0.08 }, 'i').to(600, { sq: t.B.sq - 0.04, lift: t.B.lift + 0.8 }, 'o').to(500, { sq: t.B.sq, lift: t.B.lift }, 's'); bk(t, 300); } },
    finn: { dr: 'shell', wk: { wag: 24 }, wfx: ['drop', 'body', 4], s: t => { t.osc(2000, 4, { wag: 20 }, { wag: -20 }, 's').fx('drop', 'body', 2); bk(t, 400); } },
    sealy: { dr: 'fish', s: t => { t.osc(900, 3, { open: 0.35 }, { open: 0.05 }, 'o').osc(1000, 4, { hLx: 2, hRx: -2, armL: 22, armR: 22 }, { hLx: 6, hRx: -6, armL: 12, armR: 12 }, 'o'); bk(t, 500); } },
    puff: { dr: 'bubble', wfx: ['bubble', 'head'], s: t => { t.to(1200, { blo: 0.5, puff: 0.5 }, 's').fx('bubble', 'head').wait(800).to(1400, { blo: 0, puff: 0 }, 's'); bk(t, 400); } },
    shelly: { dr: 'leaf', wk: { nk: 1 }, bp: { hid: 0.35 }, s: t => { t.to(700, { hid: 0.6 }, 'io').wait(2000).to(500, { hid: t.B.hid || 0 }, 'io'); bk(t, 400); } },
    octo: { dr: 'shell', wk: { osp: 1 }, s: t => sp(t, { ocl: 0.8, ow: 0.6 }, 1800, 1600) },
    marina: { dr: 'pearl', wk: { tlf: 0.6 }, s: t => { t.to(500, { tlf: 0.6 }, 'o').osc(1200, 3, { tsw: 0.5 }, { tsw: -0.5 }, 's').to(500, { tlf: 0, tsw: 0 }); bk(t, 400); } },
    pearl: { dr: 'star', wk: { glow: 1 }, wfx: ['spark', 'head', 4], s: t => { sp(t, { glow: 1 }, 1800, 1400); t.fx('spark', 'head', 3); } },
    // ---------- Fruit Patch ----------
    pina: { dr: 'sun', wk: { crw: 1 }, s: t => { t.to(300, { crw: 0.7 }, 'o').osc(1200, 3, { crs: 0.3 }, { crs: 0 }, 's').to(400, { crw: 0 }); bk(t, 400); } },
    avo: { dr: 'leaf', wk: { pp: 0.3 }, s: t => { t.to(300, { prw: 0.8 }).wait(1200).to(400, { prw: 0 }); bk(t, 400); } },
    berri: { dr: 'cake', wk: { stw: 1 }, s: t => { t.to(120, { stw: 1 }, 'o').to(1000, { stw: 0 }); bk(t, 400); } },
    lemmy: { dr: 'cup', wk: { sqz: 0.6 }, s: t => sp(t, { sqz: 0.8, mw: 0.5, frown: 0.2 }, 1000, 900) },
    kiwi: { dr: 'flower', wk: { fzz: 1 }, s: t => sp(t, { fzz: 0.6 }, 1400, 1200) },
    melo: { dr: 'sun', wk: { sdj: 1 }, s: t => { t.osc(1400, 3, { sdj: 1 }, { sdj: 0 }, 'o'); bk(t, 400); } },
    peachy: { dr: 'flower', wk: { blush: 0.8 }, s: t => sp(t, { blush: 1, lfl: 0.5, smile: 0.9 }, 1600, 1400) },
    pitaya: { dr: 'moon', wk: { wsp: 1, wfl: 1 }, s: t => sp(t, { wfl: 0.7, wsp: 0.5 }, 1400, 1200) },
    tutti: { dr: 'cherry', wk: { wfl: 1 }, wfx: ['dust', 'body', 3], s: t => { sp(t, { wfl: 0.6 }, 1400, 1000); t.fx('dust', 'body', 3); } },
    // ---------- Forest Friends ----------
    kiko: { dr: 'leaf', wfx: ['spark', 'head', 3], s: t => { t.to(90, { earL: -10, earR: -10 }, 'o').to(200, { earL: 3, earR: 3 }).fx('spark', 'head', 2); bk(t, 400); } },
    teddy: { dr: 'honey', s: t => { t.to(500, o(both(14, -4), { armL: 26, armR: 26, smile: 1, blush: 0.5 })).osc(1600, 3, { tongue: 0.4 }, { tongue: 0 }, 's'); bk(t, 500); } },
    hoot: { dr: 'moon', wk: { tfl: 1, wfl: 1 }, s: t => { t.to(300, { close: 0, winkL: 1, tfl: 0.6, lx: 0.6, zz: 0 }, 'o').wait(1400).to(400, { close: 1, winkL: 0, tfl: 0, lx: 0 }).to(400, { zz: 1 }); bk(t, 400); } },
    leo: { dr: 'crown', wk: { mfl: 1, msh: 1 }, s: t => { t.to(400, { mfl: 0.7, open: 0.35, puff: 0.3 }, 'o').wait(600).to(600, { mfl: 0, open: 0, puff: 0 }); bk(t, 400); } },
    panko: { dr: 'bamboo', s: t => { t.osc(2000, 6, { open: 0.2, puff: 0.5 }, { open: 0, puff: 0.2 }, 's'); bk(t, 400); } },
    acorn: { dr: 'acorn', wk: { tfl: 1 }, s: t => sp(t, { tfl: 1, tsw: 0.5 }, 1400, 1200) },
    fawn: { dr: 'flower', wk: { earL: -14, earR: -14 }, s: t => { ear(t, -1, 12).wait(500); ear(t, 1, 12); bk(t, 400); } },
    moss: { dr: 'drop', wk: { cb: 1 }, s: t => { t.osc(1400, 3, { cb: 0.8 }, { cb: 0 }, 'o').fx('dust', 'head', 3); bk(t, 400); } },
    sprout: { dr: 'sun', wk: { blm: 1 }, s: t => sp(t, { blm: 0.8 }, 1800, 1800) },
    // ---------- Dreamland ----------
    hana: { dr: 'carrot', wk: { tw: 1 }, s: t => { t.to(400, { flL: 0.8 }).osc(1200, 4, { tw: 1 }, { tw: -1 }, 's').to(400, { flL: 0 }); bk(t, 400); } },
    boo: { dr: 'heart', s: t => sp(t, { gho: 0.45 }, 1800, 1400) },
    pixie: { dr: 'star', wk: { wfl: 1, wsp: 0.6 }, wfx: ['dust', 'body', 4], s: t => { sp(t, { wfl: 0.7, wsp: 0.4 }, 1400, 1000); t.fx('dust', 'body', 3); } },
    floof: { dr: 'snow', wk: { fzz: 1 }, s: t => { t.to(200, { fzz: 0.8 }, 'o').osc(700, 6, { x: 0.5 }, { x: -0.5 }, 'l').to(400, { fzz: 0 }); bk(t, 400); } },
    unibun: { dr: 'rainbow', wfx: ['spark', 'head', 5], s: t => { t.fx('spark', 'head', 4); ear(t, -1, 10); bk(t, 400); } },
    gumdrop: { dr: 'candy', wk: { jig: 1 }, s: t => sp(t, { jig: 0.8 }, 1200, 1000) },
    ember: { dr: 'fire', zc: '#e2621e', wk: { cfl: 1 }, s: t => sp(t, { cfl: 0.6 }, 1600, 1400) },
    drako: { dr: 'fire', wk: { wsp: 1, wfl: 1 }, s: t => { t.to(400, { puff: 0.6 }).to(200, { puff: 0 }).fx('steam', 'head').osc(1600, 2, { tsw: 0.6 }, { tsw: -0.6 }, 's'); bk(t, 400); } },
    jinni: { dr: 'star', wk: { glo: 1, gwh: 1 }, s: t => { sp(t, { glo: 0.8, gwh: 0.6 }, 1600, 1400); t.fx('spark', 'body', 3); } },
    // ---------- Sweet Bakery ----------
    cuppy: { dr: 'cherry', wfx: ['sprinkle', 'head'], s: t => { t.fx('sprinkle', 'head').osc(1400, 3, { sq: t.B.sq + 0.04 }, { sq: t.B.sq }, 'o'); bk(t, 400); } },
    chip: { dr: 'cup', wfx: ['crumb', 'body', 4], s: t => { t.osc(800, 4, { x: 0.5 }, { x: -0.5 }, 'l').fx('crumb', 'body', 3); bk(t, 300); } },
    twisty: { dr: 'heart', wfx: ['salt', 'head'], s: t => { t.osc(2000, 2, { tilt: t.B.tilt + 4 }, { tilt: t.B.tilt - 4 }, 's').fx('salt', 'head'); bk(t, 400); } },
    crois: { dr: 'cup', s: t => sp(t, { lean: 1.4, tilt: t.B.tilt + 3, smile: 0.9 }, 1800, 1200) },
    maca: { dr: 'flower', s: t => { t.to(100, { sq: t.B.sq + 0.1 }, 'o').to(200, { sq: t.B.sq }).wait(300).to(100, { sq: t.B.sq + 0.08 }, 'o').to(200, { sq: t.B.sq }); bk(t, 300); } },
    puddi: { dr: 'cherry', s: t => { t.osc(1600, 6, { sq: t.B.sq + 0.05, x: 0.3 }, { sq: t.B.sq - 0.02, x: -0.3 }, 'l'); bk(t, 400); } },
    mochi: { dr: 'berry', s: t => sp(t, { sq: t.B.sq + 0.14, smile: 0.9 }, 1800, 1400) },
    cakey: { dr: 'star', s: t => { t.to(500, { puff: 0.7 }).to(600, { puff: 0, open: 0.2, mw: 0.5 }, 'o').fx('gust', 'head').to(300, { open: 0, mw: t.B.mw }); bk(t, 400); } },
    sugarplum: { dr: 'candy', wfx: ['spark', 'head', 4], s: t => { t.to(400, { armR: 70, hRy: -2, smile: 0.9 }, 'o').osc(1400, 3, { hRx: -3 }, { hRx: 3 }, 's').fx('spark', 'head', 3); bk(t, 500); } },
    // ---------- Spooky Squish ----------
    gourdy: { dr: 'moon', zc: '#e2621e', s: t => { t.osc(2400, 2, { tilt: t.B.tilt + 5, x: 1 }, { tilt: t.B.tilt - 5, x: -1 }, 's'); bk(t, 400); } },
    batty: { dr: 'moon', lp: { armL: 30, armR: 30 }, wk: { armL: 172, armR: 172 }, s: t => sp(t, { armL: 70, armR: 70, hLx: 12, hRx: -12 }, 1400, 1800) },
    kernel: { dr: 'star', s: t => { t.to(120, { lift: t.B.lift + 2.4, sq: t.B.sq - 0.06 }, 'o').to(240, { lift: t.B.lift, sq: t.B.sq + 0.04 }, 'i').fx('spark', 'head', 2); bk(t, 400); } },
    hexie: { dr: 'moon', wfx: ['spark', 'head', 4], s: t => { sp(t, { curl: 0.7 }, 1400, 1200); t.fx('spark', 'head', 3); } },
    mumbles: { dr: 'candy', s: t => { t.to(900, { armL: 88, armR: 88, hLy: -2, hRy: -2, open: 0.2 }, 'io').wait(1200).to(900, { armL: t.B.armL, armR: t.B.armR, hLy: t.B.hLy, hRy: t.B.hRy, open: 0 }, 'io'); bk(t, 300); } },
    hocus: { dr: 'star', wfx: ['spark', 'body', 4], s: t => { t.fx('spark', 'body', 4).wait(800).fx('spark', 'body', 3); bk(t, 300); } },
    countsquishula: { dr: 'moon', lp: o(both(12, -4), { armL: 26, armR: 26, htilt: 0, tilt: 0 }), s: t => { t.to(300, { close: 0, winkL: 1, smile: 0.6, zz: 0 }, 'o').wait(1200).to(400, { close: 1, winkL: 0 }).to(400, { zz: 1 }); bk(t, 400); } },
  };
  Object.keys(PROF).forEach(k => bedBuild(k, B[k] || {}));
});
