// Squish Squad Rive-style rig: bones + mesh warp + 2.5D head sphere + layered state machine with blended transitions.
// RiveRig.mount(host, 'mittens', { onState }) -> { play(name), destroy(), state }
(function () {
  if (window.RiveRig) return;
  // Plush fabric grain. Was a live feTurbulence (CPU noise regenerated every frame = big FPS drop); now a pre-baked seamless noise tile, same look.
  let FAB = null;
  function fabricFx() {
    if (FAB === null) { FAB = '';
      try { const S = 128, cv = document.createElement('canvas'); cv.width = cv.height = S; const x = cv.getContext('2d'), im = x.createImageData(S, S);
        let sd = 7; const rnd = () => (sd = (sd * 16807) % 2147483647) / 2147483647;
        const oct = n => { const g = []; for (let i = 0; i < n * n; i++) g.push(rnd()); const c = S / n, sm = t => t * t * (3 - 2 * t);
          return (px, py) => { const gx = px / c, gy = py / c, x0 = Math.floor(gx), y0 = Math.floor(gy), fx = sm(gx - x0), fy = sm(gy - y0), a = (i, j) => g[((j % n + n) % n) * n + ((i % n + n) % n)];
            const t = a(x0, y0) + (a(x0 + 1, y0) - a(x0, y0)) * fx, b = a(x0, y0 + 1) + (a(x0 + 1, y0 + 1) - a(x0, y0 + 1)) * fx; return t + (b - t) * fy; }; };
        const o1 = oct(32), o2 = oct(64);
        for (let y = 0; y < S; y++) for (let X = 0; X < S; X++) { const v = (o1(X, y) + o2(X, y)) / 2, k = (y * S + X) * 4; im.data[k + 3] = Math.round(0.2 * 255 * v); }
        x.putImageData(im, 0, 0); const B = 1024, cb = document.createElement('canvas'); cb.width = cb.height = B; const xb = cb.getContext('2d'); xb.fillStyle = xb.createPattern(cv, 'repeat'); xb.fillRect(0, 0, B, B); FAB = cb.toDataURL('image/png'); } catch (e) { FAB = ''; } }
    return FAB ? '<feImage href="' + FAB + '" x="-30" y="-30" width="160" height="160" preserveAspectRatio="none"/>' : '<feFlood flood-opacity="0"/>';
  }
  const NS = 'http://www.w3.org/2000/svg', D2R = Math.PI / 180, TAU = Math.PI * 2;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v)), r2 = n => Math.round(n * 100) / 100, lerp = (a, b, t) => a + (b - a) * t;
  const SM = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
  const bez = (x1, y1, x2, y2) => { const cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx, cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by;
    const X = t => ((ax * t + bx) * t + cx) * t, dX = t => (3 * ax * t + 2 * bx) * t + cx, Y = t => ((ay * t + by) * t + cy) * t;
    return x => { if (x <= 0) return 0; if (x >= 1) return 1; let t = x; for (let i = 0; i < 8; i++) { const d = dX(t); if (Math.abs(d) < 1e-5) break; t = clamp(t - (X(t) - x) / d, 0, 1); } return Y(t); }; };
  const EZ = { l: x => x, io: bez(0.45, 0, 0.55, 1), s: bez(0.37, 0, 0.63, 1), o: x => 1 - Math.pow(1 - x, 2.4), i: x => Math.pow(x, 2.2), bk: bez(0.34, 1.45, 0.64, 1) };
  const kv = (K, t) => { if (t <= K[0][0]) return K[0][1]; for (let i = 1; i < K.length; i++) { const b = K[i]; if (t <= b[0]) { const a = K[i - 1]; return a[1] + (b[1] - a[1]) * EZ[b[2] || 'io']((t - a[0]) / Math.max(1, b[0] - a[0])); } } return K[K.length - 1][1]; };
  class Fol { constructor(v, w, z) { this.v = v || 0; this.d = 0; this.w = w; this.z = z == null ? 1 : z; }
    step(t, dt) { const n = Math.max(1, Math.ceil(dt / 0.006)), h = dt / n; for (let i = 0; i < n; i++) { this.d += (this.w * this.w * (t - this.v) - 2 * this.z * this.w * this.d) * h; this.v += this.d * h; } return this.v; } }

  function parsePath(d) {
    const tk = d.match(/[a-zA-Z]|-?\d*\.?\d+(?:e-?\d+)?/g) || []; let i = 0, cmd = '', x = 0, y = 0, sx = 0, sy = 0; const out = []; const n = () => +tk[i++];
    while (i < tk.length) {
      if (/[a-zA-Z]/.test(tk[i])) cmd = tk[i++];
      const C = cmd.toUpperCase(), rel = cmd !== C, ox = rel ? x : 0, oy = rel ? y : 0;
      if (C === 'Z') { out.push({ c: 'Z' }); x = sx; y = sy; continue; }
      if (C === 'M' || C === 'L') { const p = [ox + n(), oy + n()]; out.push({ c: C, p: [p] }); [x, y] = p; if (C === 'M') { sx = x; sy = y; cmd = rel ? 'l' : 'L'; } }
      else if (C === 'Q') { const a = [ox + n(), oy + n()], b = [ox + n(), oy + n()]; out.push({ c: 'Q', p: [a, b] }); [x, y] = b; }
      else if (C === 'C') { const a = [ox + n(), oy + n()], b = [ox + n(), oy + n()], c = [ox + n(), oy + n()]; out.push({ c: 'C', p: [a, b, c] }); [x, y] = c; }
      else i++;
    }
    return out;
  }
  const ellS = (cx, cy, rx, ry, rot, n) => { n = n || 8; const k = 4 / 3 * Math.tan(Math.PI / (2 * n)), c = Math.cos((rot || 0) * D2R), s = Math.sin((rot || 0) * D2R);
    const P = (x, y) => [cx + x * c - y * s, cy + x * s + y * c]; const out = [{ c: 'M', p: [P(rx, 0)] }];
    for (let i = 0; i < n; i++) { const a0 = i / n * TAU, a1 = (i + 1) / n * TAU, c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
      out.push({ c: 'C', p: [P(rx * (c0 - k * s0), ry * (s0 + k * c0)), P(rx * (c1 + k * s1), ry * (s1 - k * c1)), P(rx * c1, ry * s1)] }); }
    out.push({ c: 'Z' }); return out; };
  // Nov 10 (user: 'Waffles - when I spin him the head shape itself does not turn with him, same for Duchess'): their scalloped fur outlines
  // (headD / bodyD of 8+ quadratic scallops) were flat 2D shapes - the same flower outline from every side. Now the fur is puffs on the ball, on 4
  // rings through the top and bottom (meridians 45 deg apart). Each puff is a small ball sized so that, from the front, the front ring traces
  // exactly the drawn scallops (peak = the arc's furthest point, valleys where neighbours meet); the 45 / 135 deg rings sit half a scallop
  // higher. As he turns the rings turn with him: the side scallops fold in and the next ring's (shifted) scallops roll out, the top / bottom ones
  // slide round, side-on the face-to-back ring is the outline, from the back the front ring again. Worked in the ellipse's own unit space
  // (cx, cy, rx, ry); th = angle from the top, clockwise.
  const furRing = (d, E) => { const n = (d.match(/Q/g) || []).length; if (n < 8 || /[CLAHVS]/i.test(d.replace(/[MQZ]/g, ''))) return null;
    const [cx, cy, rx, ry0] = E, ry = ry0 || rx, v = (d.match(/-?\d+\.?\d*/g) || []).map(Number), pol = (x, y) => [Math.atan2((x - cx) / rx, -(y - cy) / ry), Math.hypot((x - cx) / rx, (y - cy) / ry)];
    const V = [], Pk = []; let p0 = [v[0], v[1]];
    for (let k = 2; k + 3 < v.length; k += 4) { const c = [v[k], v[k + 1]], p1 = [v[k + 2], v[k + 3]]; V.push(pol(p0[0], p0[1])); let best = null;
      for (let i = 1; i < 20; i++) { const t = i / 20, u = 1 - t, q = pol(u * u * p0[0] + 2 * u * t * c[0] + t * t * p1[0], u * u * p0[1] + 2 * u * t * c[1] + t * t * p1[1]); if (!best || q[1] > best[1]) best = q; } Pk.push(best); p0 = p1; }
    const wrap = a => Math.atan2(Math.sin(a), Math.cos(a)), Vs = V.slice().sort((a, b) => a[0] - b[0]);
    const vfn = th => { th = wrap(th); for (let i = 0; i < Vs.length; i++) { const a = Vs[i], b = Vs[(i + 1) % Vs.length]; let span = wrap(b[0] - a[0]); if (span <= 0) span += TAU; let o = wrap(th - a[0]); if (o < 0) o += TAU; if (o <= span) return a[1] + (b[1] - a[1]) * o / span; } return Vs[0][1]; };
    const T = Pk.map((q, i) => { const pv = Pk[(i - 1 + n) % n], nx = Pk[(i + 1) % n], dl = (Math.abs(wrap(q[0] - pv[0])) + Math.abs(wrap(nx[0] - q[0]))) / 4, vv = (vfn(q[0] - dl) + vfn(q[0] + dl)) / 2;
      let lo = 0.001, hi = q[1]; for (let it = 0; it < 40; it++) { const r = (lo + hi) / 2, D0 = q[1] - r, f = D0 * Math.cos(dl) + Math.sqrt(Math.max(0, r * r - D0 * D0 * Math.sin(dl) * Math.sin(dl))) - vv; if (f > 0) hi = r; else lo = r; }   // ball radius: neighbours meet at the valley
      const r = (lo + hi) / 2; return { th: q[0], D: q[1] - r, r }; });
    const T2 = T.map((t, i) => { const u = T[(i + 1) % n]; return { th: t.th + wrap(u.th - t.th) / 2, D: (t.D + u.D) / 2, r: (t.r + u.r) / 2 }; });   // half a scallop round
    return { R: [[Math.PI / 2, T], [0, T], [Math.PI / 4, T2], [3 * Math.PI / 4, T2]], cx, cy, rx, ry, vfn, n }; };
  const furPts = (F, yaw) => { const M = 168, out = [], C = [];
    F.R.forEach(([l0, T]) => { const xs = Math.sin(l0 + yaw); T.forEach(t => { const x = Math.sin(t.th) * t.D * xs, y = Math.cos(t.th) * t.D; C.push({ s: Math.hypot(x, y), ph: Math.atan2(x, y), r: t.r }); }); });
    for (let i = 0; i < M; i++) { const th = i / M * TAU; let rho = F.vfn(th) * 0.995;                                                 // the head ball itself (valley size)
      for (const q of C) { const dl = th - q.ph, sn = q.s * Math.sin(dl); if (Math.abs(sn) < q.r && Math.cos(dl) > 0) { const e = q.s * Math.cos(dl) + Math.sqrt(q.r * q.r - sn * sn); if (e > rho) rho = e; } }
      out.push([F.cx + F.rx * rho * Math.sin(th), F.cy - F.ry * rho * Math.cos(th)]); }
    return out; };
  const toD = (segs, F) => { let s = ''; for (const g of segs) { if (g.c === 'Z') { s += 'Z'; continue; } s += g.c; for (const p of g.p) { const q = F(p[0], p[1]); s += r2(q[0]) + ' ' + r2(q[1]) + ' '; } } return s; };
  const smoothD = P => { let s = 'M' + r2(P[0][0]) + ' ' + r2(P[0][1]);
    for (let i = 0; i < P.length - 1; i++) { const p0 = P[i - 1] || P[i], p1 = P[i], p2 = P[i + 1], p3 = P[i + 2] || p2;
      s += ' C' + r2(p1[0] + (p2[0] - p0[0]) / 6) + ' ' + r2(p1[1] + (p2[1] - p0[1]) / 6) + ' ' + r2(p2[0] - (p3[0] - p1[0]) / 6) + ' ' + r2(p2[1] - (p3[1] - p1[1]) / 6) + ' ' + r2(p2[0]) + ' ' + r2(p2[1]); }
    return s; };
  // volume helpers: outline -> polygon, convex hull silhouette, ellipsoid -> projected ellipse
  const flat = (segs, n) => { const out = []; let p = null; for (const g of segs) { if (g.c === 'M' || g.c === 'L') { p = g.p[0]; out.push(p); }
      else if (g.c === 'Q') { const [a, b] = g.p; for (let i = 1; i <= n; i++) { const t = i / n, m = 1 - t; out.push([m * m * p[0] + 2 * m * t * a[0] + t * t * b[0], m * m * p[1] + 2 * m * t * a[1] + t * t * b[1]]); } p = b; }
      else if (g.c === 'C') { const [a, b, c] = g.p; for (let i = 1; i <= n; i++) { const t = i / n, m = 1 - t; out.push([m * m * m * p[0] + 3 * m * m * t * a[0] + 3 * m * t * t * b[0] + t * t * t * c[0], m * m * m * p[1] + 3 * m * m * t * a[1] + 3 * m * t * t * b[1] + t * t * t * c[1]]); } p = c; } } return out; };
  const hull = P => { P = P.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]); const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]), lo = [], up = [];
    for (const p of P) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= 0) lo.pop(); lo.push(p); }
    for (let i = P.length - 1; i >= 0; i--) { const p = P[i]; while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], p) <= 0) up.pop(); up.push(p); }
    up.pop(); lo.pop(); return lo.concat(up); };
  const closedD = P => { const n = P.length; if (n < 3) return ''; let s = 'M' + r2(P[0][0]) + ' ' + r2(P[0][1]);
    for (let i = 0; i < n; i++) { const p0 = P[(i - 1 + n) % n], p1 = P[i], p2 = P[(i + 1) % n], p3 = P[(i + 2) % n];
      s += ' C' + r2(p1[0] + (p2[0] - p0[0]) / 6) + ' ' + r2(p1[1] + (p2[1] - p0[1]) / 6) + ' ' + r2(p2[0] - (p3[0] - p1[0]) / 6) + ' ' + r2(p2[1] - (p3[1] - p1[1]) / 6) + ' ' + r2(p2[0]) + ' ' + r2(p2[1]); } return s + 'Z'; };
  const ellAx = (cx, cy, A) => { let a = 0, b = 0, c = 0; for (const v of A) { a += v[0] * v[0]; b += v[0] * v[1]; c += v[1] * v[1]; } const tr = (a + c) / 2, df = Math.sqrt(Math.max(0, (a - c) * (a - c) / 4 + b * b));
    return ellS(cx, cy, Math.sqrt(tr + df), Math.sqrt(Math.max(0.01, tr - df)), 0.5 * Math.atan2(2 * b, a - c) / D2R, 8); };
  const earSec = (e, poly) => { const [px, py] = e.pivot, ux = e.ux, uy = e.uy, nx = -uy, ny = ux, A = poly.map(([x, y]) => [(x - px) * ux + (y - py) * uy, (x - px) * nx + (y - py) * ny]);
    const amax = Math.max(...A.map(a => a[0])), amin = Math.max(Math.min(...A.map(a => a[0])), -4), secs = [];
    for (let i = 0; i <= 13; i++) { const a = amin + (amax - amin - 0.5) * i / 13; let lo = 1e9, hi = -1e9;
      for (let j = 0; j < A.length; j++) { const p = A[j], q = A[(j + 1) % A.length]; if ((p[0] - a) * (q[0] - a) <= 0 && p[0] !== q[0]) { const t = p[1] + (q[1] - p[1]) * (a - p[0]) / (q[0] - p[0]); lo = Math.min(lo, t); hi = Math.max(hi, t); } }
      if (lo > hi) continue; const hw = Math.max(0.8, (hi - lo) / 2), tc = (hi + lo) / 2, s = clamp(a / amax, 0, 1); secs.push({ s, cx: px + a * ux + tc * nx, cy: py + a * uy + tc * ny, hw, hd: Math.max(0.8, hw * 0.55 * (0.3 + 0.7 * SM((s - 0.1) / 0.4))) }); }
    return { secs, amax, nx, ny }; };
  const mk = (tag, at, par) => { const e = document.createElementNS(NS, tag); for (const k in at) e.setAttribute(k, at[k]); if (par) par.appendChild(e); return e; };
  const star4 = (x, y, r) => 'M' + r2(x) + ' ' + r2(y - r) + ' Q' + r2(x) + ' ' + r2(y) + ' ' + r2(x + r) + ' ' + r2(y) + ' Q' + r2(x) + ' ' + r2(y) + ' ' + r2(x) + ' ' + r2(y + r) + ' Q' + r2(x) + ' ' + r2(y) + ' ' + r2(x - r) + ' ' + r2(y) + ' Q' + r2(x) + ' ' + r2(y) + ' ' + r2(x) + ' ' + r2(y - r) + 'Z';

  // ---------- Mittens: parts, pivots, depth ----------
  const DEFS = { mittens: {
    G: 95.5, top: 17, head: [50, 46, 29], neck: [50, 73],
    c: { tail: '#e59a58', pad: '#ffb8c6', inner: '#ffb3c1', muzzle: '#fff1e2', nose: '#e8798f', cheek: '#ff8fa3', mouth: '#6a3a3a', whisker: '#a86a3a', stripe: '#e08e48', arm: '#f0aa6a', g: ['#ffe4c0', '#f8b77a', '#d98a4a'] },
    body: [50, 78, 22, 13], feet: [[38, 90], [62, 90]],
    ears: [{ side: -1, pivot: [34, 30], tip: [26, 9], d: 'M22 36 Q20 8 30 10 Q38 14 46 24 Z', inner: 'M28 28 Q28 16 32 16 Q36 18 40 24 Z' }, { side: 1, pivot: [66, 30], tip: [74, 9], d: 'M78 36 Q80 8 70 10 Q62 14 54 24 Z', inner: 'M72 28 Q72 16 68 16 Q64 18 60 24 Z' }],
    arms: [{ side: -1, e: [32, 76, 6, 8, 20], pivot: [34.6, 68.6] }, { side: 1, e: [68, 76, 6, 8, -20], pivot: [65.4, 68.6] }],
    tail: [[52, 86], [74, 92], [92, 82], [88, 66]], eyes: [[38, 47], [62, 47]], eyeR: 5.2,
    // Nov 9 (user: the tail must come from the middle of his lower back): a real 3D tail [x, y, z] (z < 0 = behind him). It grows out of the centre of
    // his lower back (on the back surface, a little above the floor), goes backward and down to the floor behind him, sweeps round to his left side
    // and curls up there - so from the front it still peeks out low on the right and curls up, from behind it comes out of the middle of his lower
    // back, and from the side it sticks out behind him. (The old 2D 'tail' points ran sideways along the floor from under his feet.)
    // the base is thicker and melts into his fur (tapered strokes + a soft fur blob over the root); the curled end stays a little behind him so it shows from the side
    tail3: [[50, 81, -18], [51, 90, -35], [80, 94, -36], [90, 71, -26]],
    whiskers: ['M36 55 Q27 52.5 18 52', 'M36 58 Q27 58.5 18 60', 'M64 55 Q73 52.5 82 52', 'M64 58 Q73 58.5 82 60'],
    stripes: 'M44 18 L45 24 M56 18 L55 24', back: 'M43 21 L44 28 M50 19 L50 27 M57 21 L56 28' } };

  DEFS.biscuit = {
    G: 95.5, top: 16, head: [50, 44, 28], neck: [50, 71],
    c: { tail: '#e8a45a', tailB: '#e2a056', pad: '#7a4a2a', inner: '#c98a50', muzzle: '#fff1de', nose: '#2a1a30', cheek: '#ff8fa3', mouth: '#6a3a3a', whisker: 'none', stripe: '#fff1de', arm: '#efae62', g: ['#ffe2b8', '#f2b56c', '#d48a3e'], ge: ['#c98a50', '#a8693a', '#7c4724'], tailHL: '#ffe2b8' },
    body: [50, 77, 21, 14], belly: [50, 80, 12, 9, '#fff3e0'], bellyTurn: true, feet: [[38, 90], [62, 90]], pads: [[-4, 1, 1.6, 1.2], [0, 2, 1.6, 1.2], [4, 1, 1.6, 1.2]],
    ears: [{ side: -1, flop: true, lobe: [19, 42, 10.5, 18, 9, -2, 14], pivot: [27, 30], tip: [15, 58], d: 'M28 26 Q14 22 10 36 Q8 52 18 60 Q24 62 26 54 Q26 40 32 32Z' }, { side: 1, flop: true, lobe: [81, 42, 10.5, 18, 9, -2, -14], pivot: [73, 30], tip: [85, 58], d: 'M72 26 Q86 22 90 36 Q92 52 82 60 Q76 62 74 54 Q74 40 68 32Z' }],
    arms: [{ side: -1, e: [33, 77, 6, 8, 15], pivot: [35.1, 69.3] }, { side: 1, e: [67, 77, 6, 8, -15], pivot: [64.9, 69.3] }],
    tail: [[72, 78], [86, 77], [89, 65], [84, 57]], tailW: 6, tailRoot: [[62, 86], [67, 83]], eyes: [[38, 45], [62, 45]], eyeR: 5.2,
    // Nov 9 (user: a dog's tail should be short, and like Mittens' it must come out of the middle of his lower back): a short perky puppy tail,
    // about half the length of Mittens' - out of the centre of his lower back, straight back, then a happy upward hook that leans a little to his
    // left so it just peeks out beside his hip from the front; a thicker base, and it wags harder than a cat's (tailWag 1.7)
    // Nov 9 (user: remove the white stripe, make it look like a real dog's tail): drawn as one solid tapered shape in his fur colour - thick at the
    // base, narrowing to a rounded tip - with a slightly darker underside instead of the light highlight line
    tail3: [[50, 80, -16], [51, 79, -31], [60, 74, -34], [71, 62, -27]], tailWag: 1.7, tailK: 8, tailTaper: [0.86, 0.36], tailShade: '#c9873f',
    muzzle: [50, 56, 15, 11], nose: [50, 53, 4.4, 3.2], noseHL: [48.6, 52, 1.4, 0.9], mouth: [50, 60, 4.5], cheeks: [[33, 55], [67, 55]],
    faceExtra: [{ d: 'M44 20 Q50 16 56 20 Q54 30 50 34 Q46 30 44 20Z', fill: '#fff1de', op: 0.9 }, { d: 'M50 56 L50 59', stroke: '#6a3a3a', sw: 1.2 }],
    whiskers: [], stripes: '', back: 'M44 22 Q50 18 56 22',
    // Nov 9 (user: improve his collar): ring = a real 3D band round his neck (it was a flat pink strip with square cut ends painted on his front);
    // Nov 9 (user: keep the old shape, it was on his neck, just lift it a little): seen from the front it traces EXACTLY the old curved band (top edge
    // y = ys + af * cos^2 - the old quadratic from x 30 to 70, dipping 4 under the chin), lifted 2 (sides 64-68, centre 68-72, clear of his paws);
    // ab = the smaller dip at the back of the neck, w = band height, rx / rz = neck radius
    collar: { d: 'M30 66 Q50 74 70 66 L70 70 Q50 78 30 70Z', fill: '#ff6f86', ring: { ys: 64, af: 4, ab: 1.5, w: 4, rx: 20, rz: 20, dark: '#c8445d', light: '#ff9cb0' } }, tag: { x: 50, y: 74, r: 3.4, fill: '#ffd84a' } };
  // ---------- Waffles (Nov 9, user: 'lets fix it all'): his own built-in rig, read straight off his drawing (export/tripo/waffles). He used to run
  // on a copy of Biscuit's generic parts list, which pointed at the wrong pieces of his art (forehead fluff + muzzle swung as his arms over his eyes and
  // chest, his nose was hidden, his mouth + tongue were treated as paw pads, his upright ears flopped, his collar was dropped). Same dog frame as
  // Biscuit (body, feet, arms, eyes, nose, muzzle, collar spots are identical in both drawings); his own: the fluffy scalloped head, tall upright
  // corgi ears, the fluffy cream cheek tufts, the forehead tuft + blaze, the happy tongue, cream paw pads, a brown leather collar with a silver tag,
  // a short fluffy corgi stub tail out of the middle of his lower back.
  DEFS.waffles = {
    G: 95.5, top: 15, head: [50, 46, 30, 26.5], neck: [50, 72],
    c: { tail: '#e8953e', tailB: '#e0903c', pad: '#fff1de', inner: '#ffd29a', muzzle: '#fff1de', nose: '#2a1a30', cheek: '#ff8fa3', mouth: '#6a3a3a', whisker: 'none', stripe: '#fff1de', arm: '#eda052', g: ['#ffd29a', '#e8953e', '#b86424'], tailHL: '#ffd29a' },
    grads: { wcr: [['0', '#fffaf2'], ['0.6', '#fff1de'], ['1', '#f0d9b8']] },
    headD: 'M50 20 Q57.38 14.9 61.86 21.98 Q71 19.63 71.92 27.62 Q81.44 28.38 78.64 36.05 Q87.08 39.81 81 46 Q87.08 52.19 78.64 55.95 Q81.44 63.62 71.92 64.38 Q71 72.37 61.86 70.02 Q57.38 77.1 50 72 Q42.62 77.1 38.14 70.02 Q29 72.37 28.08 64.38 Q18.56 63.62 21.36 55.95 Q12.92 52.19 19 46 Q12.92 39.81 21.36 36.05 Q18.56 28.38 28.08 27.62 Q29 19.63 38.14 21.98 Q42.62 14.9 50 20Z',
    body: [50, 77, 21, 14], belly: [50, 80, 12, 9, 'url(#wcr)'], bellyTurn: true, feet: [[38, 90], [62, 90]], pads: [[-4, 1, 1.6, 1.2], [0, 2, 1.6, 1.2], [4, 1, 1.6, 1.2]],
    ears: [{ side: -1, pivot: [33, 34], tip: [28, 7], d: 'M24 40 Q18 14 28 6 Q40 14 42 34Z' }, { side: 1, pivot: [67, 34], tip: [72, 7], d: 'M76 40 Q82 14 72 6 Q60 14 58 34Z' }],
    arms: [{ side: -1, e: [33, 77, 6, 8, 15], pivot: [35.1, 69.3] }, { side: 1, e: [67, 77, 6, 8, -15], pivot: [64.9, 69.3] }],
    tail: [[72, 78], [86, 77], [89, 65], [84, 57]], eyes: [[38, 45], [62, 45]], eyeR: 5.2,
    // corgi stub: a short fluffy nub out of the centre of his lower back, tipped up; blunt and round, wags fast
    tail3: [[50, 80, -16], [50, 79, -22.5], [51, 77, -25.5], [52.5, 74, -26.5]], tailWag: 1.9, tailK: 8.5, tailTaper: [0.92, 0.78], tailShade: '#b86424',
    muzzle: [50, 56, 15, 11], nose: [50, 53, 4.4, 3.2], noseHL: [48.6, 52, 1.4, 0.9], mouth: [50, 60, 4.5], cheeks: [[33, 55], [67, 55]],
    // fluffy cream cheek tufts that stick out past his face (drawn on their own so they are not clipped to the head; see render)
    tufts: [{ c: [26, 58], d: 'M26 49 Q29.06 46.57 30.5 50.21 Q34.37 49.63 33.79 53.5 Q37.43 54.94 35 58 Q37.43 61.06 33.79 62.5 Q34.37 66.37 30.5 65.79 Q29.06 69.43 26 67 Q22.94 69.43 21.5 65.79 Q17.63 66.37 18.21 62.5 Q14.57 61.06 17 58 Q14.57 54.94 18.21 53.5 Q17.63 49.63 21.5 50.21 Q22.94 46.57 26 49Z' }, { c: [74, 58], d: 'M74 49 Q77.06 46.57 78.5 50.21 Q82.37 49.63 81.79 53.5 Q85.43 54.94 83 58 Q85.43 61.06 81.79 62.5 Q82.37 66.37 78.5 65.79 Q77.06 69.43 74 67 Q70.94 69.43 69.5 65.79 Q65.63 66.37 66.21 62.5 Q62.57 61.06 65 58 Q62.57 54.94 66.21 53.5 Q65.63 49.63 69.5 50.21 Q70.94 46.57 74 49Z' }],
    faceExtra: [{ d: 'M50 30 Q54.77 28.38 57 30.8 Q63.02 30.42 62.12 33 Q67.79 33.96 64 36 Q67.79 38.04 62.12 39 Q63.02 41.58 57 41.2 Q54.77 43.62 50 42 Q45.23 43.62 43 41.2 Q36.98 41.58 37.88 39 Q32.21 38.04 36 36 Q32.21 33.96 37.88 33 Q36.98 30.42 43 30.8 Q45.23 28.38 50 30Z', fill: 'url(#wcr)', op: 0.85 }, { d: 'M44 20 Q50 16 56 20 Q54 30 50 34 Q46 30 44 20Z', fill: '#fff1de', op: 0.9 }, { d: 'M50 56 L50 59', stroke: '#6a3a3a', sw: 1.2 }, { d: 'M47.5 61 Q50 67 52.5 61Z', fill: '#ff7f96' }],
    whiskers: [], stripes: '', back: '',
    collar: { d: 'M30 66 Q50 74 70 66 L70 70 Q50 78 30 70Z', fill: '#b86424', ring: { ys: 66, af: 4, ab: 1.5, w: 4, rx: 20, rz: 20, dark: '#7e3f12', light: '#d9894a', stitch: '#f2c48c' } },
    tag: { x: 50, y: 74, r: 3.4, fill: '#fff8ee', metal: ['#ffffff', '#efece6', '#b3ada2', '#8a8478'] } };

  // ---------- Truffle the piglet (Nov 9, user picked the piglet + the frog; Truffle takes Prickle's Pet Shop slot) ----------
  // built from his front art (export/tripo/truffle): round pink head with perky pointed ears, a big snout with two nostrils, little hooves, a cream-pink
  // belly, and a thin curly pig tail that grows out of the middle of his lower back, goes back, then curls round beside his left hip (a 3D spline)
  DEFS.truffle = {
    G: 95.5, top: 21, head: [50, 47, 30, 26], neck: [50, 72],
    c: { tail: '#f095ad', tailB: '#f4a3b8', pad: '#d9718f', inner: '#f59ab2', muzzle: '#ff9fb6', nose: '#b8506e', cheek: '#ff7f9a', mouth: '#6a3a3a', whisker: 'none', stripe: 'none', arm: '#ffb3c6', g: ['#ffe6ec', '#ffb8c8', '#ee8aa6'] },
    grads: { pcr: [['0', '#fff6f8'], ['0.6', '#ffe2ea'], ['1', '#f7c3d1']] },
    body: [50, 77, 23, 15.5], belly: [50, 80, 14, 10, 'url(#pcr)'], bellyTurn: true, feet: [[38, 90], [62, 90]], pads: [[0, 3.2, 5.6, 1.6]],
    ears: [{ side: -1, pivot: [32, 30], tip: [27, 13.5], d: 'M25 33 Q16 16 28 13 Q38 16 39 27 Z', inner: 'M27 28 Q22 18 29 17 Q35 19 35 26 Z' }, { side: 1, pivot: [68, 30], tip: [73, 13.5], d: 'M75 33 Q84 16 72 13 Q62 16 61 27 Z', inner: 'M73 28 Q78 18 71 17 Q65 19 65 26 Z' }],
    arms: [{ side: -1, e: [33, 77, 6, 8, 15], pivot: [35.1, 69.3] }, { side: 1, e: [67, 77, 6, 8, -15], pivot: [64.9, 69.3] }],
    tail: [[72, 78], [86, 77], [89, 65], [84, 57]], eyes: [[37, 43.5], [63, 43.5]], eyeR: 5.2,
    tail3: [[50, 80, -16], [51.5, 79, -24], [58, 77, -28], [66, 76, -27], [73, 75, -24], [78, 72, -21], [79.5, 68.5, -19.5], [77, 66.5, -19.5], [74.5, 68, -20.5], [75.5, 71, -21.5], [78, 71.5, -21]],
    tailWag: 1.3, tailK: 2.1, tailTaper: [1, 0.78], tailShade: '#d9718f',
    muzzle: [50, 56, 10, 7], nose: null, mouth: [50, 64.6, 4.6], cheeks: [[27, 54], [73, 54]],
    faceExtra: [{ d: 'M44.60 56.00 C44.60 54.62 45.36 53.50 46.30 53.50 C47.24 53.50 48.00 54.62 48.00 56.00 C48.00 57.38 47.24 58.50 46.30 58.50 C45.36 58.50 44.60 57.38 44.60 56.00Z', fill: '#b8506e' }, { d: 'M52.00 56.00 C52.00 54.62 52.76 53.50 53.70 53.50 C54.64 53.50 55.40 54.62 55.40 56.00 C55.40 57.38 54.64 58.50 53.70 58.50 C52.76 58.50 52.00 57.38 52.00 56.00Z', fill: '#b8506e' }, { d: 'M44.50 52.60 C44.50 51.99 45.84 51.50 47.50 51.50 C49.16 51.50 50.50 51.99 50.50 52.60 C50.50 53.21 49.16 53.70 47.50 53.70 C45.84 53.70 44.50 53.21 44.50 52.60Z', fill: '#ffffff', op: 0.45 }],
    whiskers: [], stripes: '', back: '' };

  // ---------- Ribbit the frog (Nov 9, new Pet Shop creature) ----------
  // built from his front art (export/tripo/ribbit): a wide green head with two big eye domes on top (part of the head outline, so they turn with it),
  // white eyeballs, a wide grin, spots, a cream-yellow belly, wide feet with toe pads; no ears, no tail
  DEFS.ribbit = {
    G: 95.5, top: 19, head: [50, 46, 34, 27], neck: [50, 70],
    c: { pad: '#b9e88e', inner: '#9fdb66', muzzle: '#fff2b8', nose: '#3f7a26', cheek: '#ff4f86', mouth: '#6a3a3a', whisker: 'none', stripe: 'none', arm: '#9fdb66', g: ['#ecffc6', '#9fdb66', '#5fa63a'] },
    grads: { fcr: [['0', '#fffbe2'], ['0.6', '#fff2b8'], ['1', '#f2dc8c']] },
    body: [50, 78, 23, 15], belly: [50, 81, 15, 10, 'url(#fcr)'], bellyTurn: true, feet: [[34, 90], [66, 90]], footS: [10.5, 5, 8], pads: [[-5, 3.2, 2.3, 2.1], [0, 4, 2.3, 2.1], [5, 3.2, 2.3, 2.1]],
    // the eye domes are 3D bumps on top of his head (drawn like Waffles' cheek tufts: they turn with the head and roll behind it on the far side)
    tufts: [{ c: [33, 31], r: 12, lift: 3, white: [0, 0, 8], d: 'M21.00 31.00 C21.00 24.37 26.37 19.00 33.00 19.00 C39.63 19.00 45.00 24.37 45.00 31.00 C45.00 37.63 39.63 43.00 33.00 43.00 C26.37 43.00 21.00 37.63 21.00 31.00Z', fill: 'url(#g)' }, { c: [67, 31], r: 12, lift: 3, white: [0, 0, 8], d: 'M55.00 31.00 C55.00 24.37 60.37 19.00 67.00 19.00 C73.63 19.00 79.00 24.37 79.00 31.00 C79.00 37.63 73.63 43.00 67.00 43.00 C60.37 43.00 55.00 37.63 55.00 31.00Z', fill: 'url(#g)' }], eyeDome: true,   // Nov 10 (user: 'change the smile of ribbit to the kawaii smile'): the little 'w' instead of the wide grin (mouthOne)
    ears: [], arms: [{ side: -1, e: [32, 77, 5.5, 8, 15], pivot: [34.5, 69.5] }, { side: 1, e: [68, 77, 5.5, 8, -15], pivot: [65.5, 69.5] }],
    eyes: [[33.5, 32], [66.5, 32]], eyeR: 5.6, // drawn on the eye domes (eyeDome)
    muzzle: null, nose: null, mouth: [50, 52.4, 3.8], cheeks: [[26, 56], [74, 56]],
    faceExtra: [{ d: 'M41.80 37.00 C41.80 35.78 42.78 34.80 44.00 34.80 C45.22 34.80 46.20 35.78 46.20 37.00 C46.20 38.22 45.22 39.20 44.00 39.20 C42.78 39.20 41.80 38.22 41.80 37.00Z', fill: '#5f9e38', op: 0.45 }, { d: 'M55.40 38.50 C55.40 37.62 56.12 36.90 57.00 36.90 C57.88 36.90 58.60 37.62 58.60 38.50 C58.60 39.38 57.88 40.10 57.00 40.10 C56.12 40.10 55.40 39.38 55.40 38.50Z', fill: '#5f9e38', op: 0.45 },
      { d: 'M21.20 48.00 C21.20 47.01 22.01 46.20 23.00 46.20 C23.99 46.20 24.80 47.01 24.80 48.00 C24.80 48.99 23.99 49.80 23.00 49.80 C22.01 49.80 21.20 48.99 21.20 48.00Z', fill: '#5f9e38', op: 0.45 }, { d: 'M75.00 47.00 C75.00 45.90 75.90 45.00 77.00 45.00 C78.10 45.00 79.00 45.90 79.00 47.00 C79.00 48.10 78.10 49.00 77.00 49.00 C75.90 49.00 75.00 48.10 75.00 47.00Z', fill: '#5f9e38', op: 0.45 }, { d: 'M45.60 47.00 C45.60 46.50 46.00 46.10 46.50 46.10 C47.00 46.10 47.40 46.50 47.40 47.00 C47.40 47.50 47.00 47.90 46.50 47.90 C46.00 47.90 45.60 47.50 45.60 47.00Z', fill: '#3f7a26' }, { d: 'M52.60 47.00 C52.60 46.50 53.00 46.10 53.50 46.10 C54.00 46.10 54.40 46.50 54.40 47.00 C54.40 47.50 54.00 47.90 53.50 47.90 C53.00 47.90 52.60 47.50 52.60 47.00Z', fill: '#3f7a26' }],
    whiskers: [], stripes: '', back: '' };

  // ---------- state machine: keyframed timelines, blended on every transition ----------
  // hyaw = the HEAD's own turn (same units as turn: 1 = 40 deg) on top of the body's; twist = the UPPER body (paws + head) turning further than the
  // feet / tail (a torso twist, same units); turn / spin turn the whole body. bend = a real soft-body bend in degrees (Nov 8, user: robotic, the body never
  // bends or stretches): the spine curves as an arc from the feet to the neck (the side it bends toward squeezes, the other side stretches; arc length kept)
  // and the head rides rigidly on the end of it. lean stays the old sideways shear.
  const REST = { sblur: 0, x: 0, lift: 0, tilt: 0, sq: 0, lean: 0, bend: 0, spin: 0, turn: 0, hyaw: 0, twist: 0, pitch: 0, htilt: 0, armL: 0, armR: 0, earL: 0, earR: 0, wag: 0, curl: 0, footL: 0, footR: 0, lx: 0, ly: 0, close: 0, sl: 0, winkL: 0, winkR: 0, hap: 0, wide: 0, smile: 0, open: 0, mw: 1, frown: 0, blush: 0, hLx: 0, hLy: 0, hLz: 0, hRx: 0, hRy: 0, hRz: 0, puff: 0, tongue: 0, sqz: 0, cross: 0, teary: 0, red: 0, green: 0, sit: 0, bristle: 0, dbb: 0, dbh: 0, dbs: 0, wsk: 0 }; // dbb (Nov 10) = the dust-bath tub, dbh = its dust cloud, dbs = sunk into its dust (dustBath); wsk = whiskers folded short + fanned
  const AR = K => ({ armL: K, armR: K }), ER = K => ({ earL: K, earR: K });
  const STATES = {
    idle: { loop: 8400, look: true, k: {
      sq: [[0, 0], [2100, -0.025, 's'], [4200, 0.012, 's'], [6300, -0.025, 's'], [8400, 0, 's']],
      lean: [[0, 0], [2100, 0.9, 's'], [4200, 0, 's'], [6300, -0.9, 's'], [8400, 0, 's']],
      htilt: [[0, 0], [2100, 1.4, 's'], [4200, 0, 's'], [6300, -1.4, 's'], [8400, 0, 's']],
      wag: [[0, 0], [2100, 9, 's'], [4200, 0, 's'], [6300, -9, 's'], [8400, 0, 's']],
      earR: [[0, 0], [5200, 0], [5280, -9, 'o'], [5420, 4, 'io'], [5600, 0, 'io']] } },
    look: { dur: 6000, ev: [[1950, 'blink'], [4500, 'blink']], k: {
      lx: [[0, 0], [200, 0], [380, -1, 'o'], [1700, -1], [1880, 1, 'io'], [3200, 1], [3380, 0, 'io']],
      ly: [[0, 0], [3400, 0], [3580, -1, 'o'], [4400, -1], [4580, 0.8, 'io'], [5200, 0.8], [5400, 0, 'io']],
      turn: [[0, 0], [330, 0], [850, -0.97, 'io'], [1050, -0.9, 'io'], [1950, -0.9], [2550, 0.97, 'io'], [2750, 0.9, 'io'], [3300, 0.9], [3750, -0.05, 'io'], [3950, 0, 'io']],
      pitch: [[0, 0], [3450, 0], [3950, 0.7, 'io'], [4450, 0.7], [4950, -0.5, 'io'], [5250, -0.5], [5800, 0, 'io']],
      htilt: [[0, 0], [330, 0], [900, -4, 'io'], [1950, -4], [2600, 4, 'io'], [3300, 4], [3800, 0, 'io']],
      lean: [[0, 0], [350, 0], [950, -1.5, 'io'], [1950, -1.5], [2650, 1.5, 'io'], [3300, 1.5], [3800, 0, 'io']],
      sq: [[0, 0], [3450, 0], [3950, -0.04, 'io'], [4450, -0.04], [4950, 0.03, 'io'], [5250, 0.03], [5800, 0, 'io']],
      armL: [[0, 0], [330, 0], [850, 10, 'io'], [1950, 10], [2550, 0, 'io']], armR: [[0, 0], [1950, 0], [2550, 10, 'io'], [3300, 10], [3750, 0, 'io']],
      footL: [[0, 0], [350, 0], [550, 2.2, 'o'], [750, 0, 'io'], [2000, 0], [2200, 2.2, 'o'], [2400, 0, 'io'], [3350, 0], [3550, 1.6, 'o'], [3750, 0, 'io']],
      footR: [[0, 0], [500, 0], [700, 2.2, 'o'], [900, 0, 'io'], [2150, 0], [2350, 2.2, 'o'], [2550, 0, 'io'], [3500, 0], [3700, 1.6, 'o'], [3900, 0, 'io']] } },
    squish: { dur: 5400, loop: 1800, k: {
      sq: [[0, 0], [150, -0.05, 'o'], [480, 0.38, 'io'], [900, 0.4, 'l'], [1030, -0.18, 'o'], [1180, 0.08, 'io'], [1340, -0.03, 'io'], [1520, 0, 'io']],
      hap: [[0, 0], [330, 0], [450, 0.85, 'o'], [920, 0.85], [1040, 0, 'o']],
      smile: [[0, 0], [1000, 0], [1100, 1, 'o'], [1500, 1], [1800, 0, 'io']],
      open: [[0, 0], [1000, 0], [1080, 0.45, 'o'], [1400, 0, 'io']],
      lift: [[0, 0], [980, 0], [1110, 3.5, 'o'], [1240, 0, 'i']],
      ...AR([[0, 0], [480, 18, 'io'], [900, 20], [1050, -4, 'o'], [1300, 0, 'io']]),
      ...ER([[0, 0], [480, 12, 'io'], [900, 14], [1050, -6, 'o'], [1300, 0, 'io']]),
      blush: [[0, 0], [600, 0.6, 'io'], [1000, 0.6], [1500, 0, 'io']] } },
    spin: { dur: 5400, ev: [[1750, 'blink'], [4450, 'blink']], k: {
      spin: [[0, 0], [200, 0], [500, -25, 'io'], [1450, 375, 'io'], [1700, 360, 'io'], [2900, 360], [3200, 335, 'io'], [4150, 735, 'io'], [4400, 720, 'io']],
      turn: [[0, 0], [200, 0], [500, 0.3, 'io'], [900, -0.5, 'io'], [1450, 0.4, 'io'], [1800, 0, 'io'], [2900, 0], [3200, 0.3, 'io'], [3600, -0.5, 'io'], [4150, 0.4, 'io'], [4500, 0, 'io']],
      sq: [[0, 0], [200, 0], [500, 0.14, 'io'], [700, -0.1, 'o'], [1250, -0.04, 'io'], [1450, 0.14, 'o'], [1600, -0.04, 'io'], [1800, 0, 'io'], [2900, 0], [3200, 0.14, 'io'], [3400, -0.1, 'o'], [3950, -0.04, 'io'], [4150, 0.14, 'o'], [4300, -0.04, 'io'], [4500, 0, 'io']],
      lift: [[0, 0], [550, 0], [850, 4, 'o'], [1200, 4], [1450, 0, 'i'], [3250, 0], [3550, 4, 'o'], [3900, 4], [4150, 0, 'i']],
      ...AR([[0, 0], [500, -8, 'io'], [750, 35, 'o'], [1300, 35], [1500, 0, 'io'], [2900, 0], [3200, -8, 'io'], [3450, 35, 'o'], [4000, 35], [4200, 0, 'io']]),
      hap: [[0, 0], [700, 0.7, 'io'], [1700, 0.7], [2100, 0, 'io'], [2900, 0], [3400, 0.7, 'io'], [4400, 0.7], [4800, 0, 'io']],
      smile: [[0, 0], [700, 1, 'io'], [1700, 1], [2100, 0, 'io'], [2900, 0], [3400, 1, 'io'], [4400, 1], [4800, 0, 'io']] } },
    hop: { dur: 5700, loop: 1900, k: {
      sq: [[0, 0], [120, 0], [330, 0.24, 'io'], [410, -0.2, 'o'], [640, -0.03, 'io'], [780, -0.12, 'i'], [820, 0.3, 'o'], [960, -0.07, 'io'], [1100, 0.035, 'io'], [1260, 0, 'io']],
      lift: [[0, 0], [380, 0], [620, 18, 'o'], [820, 0, 'i']],
      ...AR([[0, 0], [330, -12, 'io'], [460, 38, 'o'], [700, 26, 'io'], [830, -8, 'o'], [1050, 0, 'io']]),
      ...ER([[0, 0], [330, -6, 'io'], [450, 10, 'o'], [650, 2, 'io'], [830, 12, 'o'], [1000, -3, 'io'], [1200, 0, 'io']]),
      ly: [[0, 0], [250, 0.4, 'io'], [450, -0.6, 'o'], [850, 0.2, 'io'], [1200, 0, 'io']],
      pitch: [[0, 0], [330, -0.2, 'io'], [500, 0.3, 'o'], [820, -0.2, 'io'], [1100, 0, 'io']],
      hap: [[0, 0], [300, 0.6, 'io'], [430, 0, 'io'], [800, 0], [840, 0.6, 'o'], [1100, 0, 'io']] } },
    happy: { dur: 7200, loop: 2400, k: {
      sq: [[0, 0], [200, 0.2, 'io'], [270, -0.16, 'o'], [480, -0.02, 'io'], [600, -0.1, 'i'], [640, 0.26, 'o'], [760, -0.04, 'io'], [860, 0.18, 'io'], [930, -0.16, 'o'], [1140, -0.02, 'io'], [1260, -0.1, 'i'], [1300, 0.26, 'o'], [1440, -0.06, 'io'], [1600, 0.03, 'io'], [1800, 0, 'io']],
      lift: [[0, 0], [240, 0], [440, 13, 'o'], [640, 0, 'i'], [900, 0], [1100, 13, 'o'], [1300, 0, 'i']],
      tilt: [[0, 0], [240, 0], [440, -7, 'io'], [700, 0, 'io'], [900, 0], [1100, 7, 'io'], [1360, 0, 'io']],
      htilt: [[0, 0], [440, -3, 'io'], [720, 4, 'io'], [900, 0, 'io'], [1100, 3, 'io'], [1380, -4, 'io'], [1600, 0, 'io']],
      ...AR([[0, 0], [200, -8, 'io'], [330, 48, 'o'], [640, 40], [700, 24, 'io'], [860, -6, 'io'], [990, 48, 'o'], [1300, 40], [1400, 24, 'io'], [1800, 0, 'io']]),
      wag: [[0, 0], [300, 16, 'io'], [600, -16, 'io'], [900, 16, 'io'], [1200, -16, 'io'], [1500, 16, 'io'], [1800, -16, 'io'], [2100, 10, 'io'], [2400, 0, 'io']],
      hap: [[0, 1]], smile: [[0, 1]], open: [[0, 0.5]], ly: [[0, -0.3]] } },
    surprised: { dur: 5200, ev: [[2400, 'blink2']], k: {
      sq: [[0, 0], [200, 0], [280, 0.16, 'o'], [380, -0.2, 'o'], [700, -0.12, 'io'], [900, 0.12, 'o'], [1050, -0.04, 'io'], [1200, 0, 'io'], [3700, 0], [3800, 0.1, 'o'], [3900, -0.15, 'o'], [4200, -0.05, 'io'], [4350, 0.08, 'o'], [4550, 0, 'io']],
      lift: [[0, 0], [300, 0], [560, 9, 'o'], [880, 0, 'i'], [3820, 0], [4020, 6, 'o'], [4300, 0, 'i']],
      x: [[0, 0], [300, 0], [880, -7, 'o'], [2500, -7], [3300, 0, 'io']],
      lean: [[0, 0], [300, 0], [500, -5, 'o'], [880, -2, 'io'], [1100, 1.5, 'io'], [1400, 0, 'io']],
      tilt: [[0, 0], [300, 0], [500, -7, 'o'], [900, -2, 'io'], [1300, 0, 'io']],
      wide: [[0, 0], [280, 0], [340, 1, 'o'], [2300, 1], [2700, 0.3, 'io'], [3700, 0.3], [3800, 1, 'o'], [4500, 1], [4900, 0, 'io']],
      open: [[0, 0], [280, 0], [360, 0.7, 'o'], [1900, 0.65], [2300, 0.15, 'io'], [3700, 0.1], [3800, 0.65, 'o'], [4500, 0.55], [4900, 0, 'io']],
      mw: [[0, 1], [280, 1], [360, 0.6, 'o'], [2300, 0.6], [2700, 1, 'io'], [3700, 1], [3800, 0.6, 'o'], [4500, 0.6], [4900, 1, 'io']],
      ...AR([[0, 0], [280, 0], [380, 34, 'o'], [1900, 30], [2400, 8, 'io'], [3700, 8], [3800, 34, 'o'], [4500, 30], [4900, 0, 'io']]),
      ...ER([[0, 0], [280, 0], [380, -12, 'o'], [1700, -10], [2100, 0, 'io'], [3700, 0], [3800, -10, 'o'], [4500, -8], [4900, 0, 'io']]),
      lx: [[0, 0], [2500, 0], [2650, -0.9, 'o'], [3000, -0.9], [3150, 0.9, 'io'], [3550, 0.9], [3700, 0, 'io']],
      turn: [[0, 0], [2550, 0], [2900, -0.35, 'io'], [3100, -0.35], [3450, 0.35, 'io'], [3600, 0.35], [3800, 0, 'io']],
      pitch: [[0, 0], [300, 0], [450, 0.25, 'o'], [1500, 0.2], [2000, 0, 'io']],
      curl: [[0, 0], [350, 0.8, 'o'], [2000, 0.6], [2600, 0, 'io']] } },
    sleep: { dur: 9000, noBlink: true, ev: [[8550, 'blink2']], k: {
      open: [[0, 0], [300, 0.9, 'io'], [1100, 0.9], [1500, 0, 'io']], mw: [[0, 1], [300, 0.75, 'io'], [1100, 0.75], [1500, 1, 'io']],
      sq: [[0, 0], [300, -0.08, 'io'], [1100, -0.08], [1500, 0.05, 'io'], [2800, 0.05], [4100, 0.09, 's'], [5400, 0.03, 's'], [6700, 0.09, 's'], [8000, 0.05, 's'], [8250, -0.1, 'o'], [8500, 0.04, 'io'], [8800, 0, 'io']],
      ...AR([[0, 0], [300, 36, 'io'], [1100, 36], [1500, 0, 'io']]),
      close: [[0, 0], [300, 0.75, 'io'], [1100, 0.75], [1500, 0.45, 'io'], [2000, 0.7, 'io'], [2300, 0.4, 'io'], [2800, 1, 'io'], [8200, 1], [8450, 0, 'o']],
      pitch: [[0, 0], [300, 0.4, 'io'], [1100, 0.4], [1600, 0, 'io'], [2800, -0.4, 'io'], [8200, -0.4], [8450, 0, 'io']],
      htilt: [[0, 0], [2800, 0], [3300, 7, 'io'], [8200, 7], [8450, 0, 'io']],
      ...ER([[0, 0], [2800, 8, 'io'], [8200, 8], [8300, -6, 'o'], [8600, 0, 'io']]),
      smile: [[0, 0], [2800, 0], [3300, 0.3, 'io'], [8200, 0.3], [8400, 0, 'io']],
      curl: [[0, 0], [2800, 0], [3400, -0.3, 'io'], [8200, -0.3], [8600, 0, 'io']] } },
  };
  const RELEASE = { dur: 1000, k: { sq: [[0, 0], [110, -0.2, 'o'], [250, 0.1, 'io'], [390, -0.04, 'io'], [540, 0, 'io']], lift: [[0, 0], [120, 3, 'o'], [270, 0, 'i']],
    smile: [[0, 0], [150, 0.8, 'o'], [700, 0.8], [1000, 0, 'io']], open: [[0, 0], [120, 0.35, 'o'], [500, 0, 'io']], ...ER([[0, 0], [120, -8, 'o'], [300, 6, 'io'], [500, 0, 'io']]) } };
  const POKE = s => ({ dur: 1100, k: { dent: [[0, 0], [45, 1, 'o'], [200, 0.3, 'io'], [460, 0, 'io']], lean: [[0, 0], [70, 4 * s, 'o'], [300, -1.6 * s, 'io'], [540, 0, 'io']],
    close: [[0, 0], [40, 1, 'o'], [170, 1], [300, 0, 'io']], hap: [[0, 0], [280, 0], [360, 1, 'o'], [850, 1], [1050, 0, 'io']], smile: [[0, 0], [280, 0], [360, 1, 'o'], [850, 1], [1050, 0, 'io']],
    open: [[0, 0], [280, 0], [360, 0.35, 'o'], [850, 0.3], [1050, 0, 'io']], sq: [[0, 0], [60, 0.06, 'o'], [200, -0.03, 'io'], [380, 0.05, 'io'], [480, -0.02, 'io'], [580, 0.04, 'io'], [680, -0.01, 'io'], [800, 0, 'io']] } });

  const HYAW = new Set([]);
  // SOFT rigs get the soft-body layer: a springy 'top of the body' that trails every sideways move (slide, tilt, turn, bend) and every lift, then
  // overshoots and wobbles back - turned into bend + stretch / squash, so the body bends and stretches by itself whenever he moves
  const SOFT = new Set(['mittens', 'biscuit', 'prickle', 'nibbles', 'quill', 'poppy', 'duchess', 'mamapaws', 'waffles', 'truffle', 'ribbit']); // Pet Shop // rigs whose renderer turns the head on its own (hyaw); the rest keep the old whole-body gaze
  function poseAt(name, t, key) {
    const st = (key && STATES[name + '@' + key]) || STATES[name], P = Object.assign({}, REST), id = STATES.idle;
    if (name !== 'idle') { const ti = t % id.loop; for (const k in id.k) P[k] = kv(id.k[k], ti); }
    const tl = st.loop ? t % st.loop : Math.min(t, st.dur || t); for (const k in st.k) P[k] = kv(st.k[k], tl);
    if (st.breathe) { const bk = st.breathe; P.sq += Math.sin(t / 640) * 0.013 * bk; P.lean += Math.sin(t / 1350) * 0.4 * bk; P.htilt += Math.sin(t / 1900 + 1) * 0.8 * bk; } return P;
  }
  const DENT = { dur: 600, k: { dent: [[0, 0], [45, 1, 'o'], [200, 0.3, 'io'], [460, 0, 'io']], sq: [[0, 0], [50, 0.05, 'o'], [200, -0.02, 'io'], [360, 0, 'io']] } };
  function setState(I, name, now, keepQ) {
    if (!STATES[name]) name = 'idle';
    if (!keepQ) I.queue = [];
    if (STATES[name].seq) { I.queue = STATES[name].seq.slice(1); name = STATES[name].seq[0]; if (!STATES[name]) name = 'idle'; }
    I.prev = I.prev ? { frozen: I.lastP } : { name: I.cur.name, t0: I.cur.t0 };
    I.cur = { name, t0: now }; I.bt0 = now; I.bd = STATES[name].blend || 280; I.evC = -1; I.evF = {}; I.ctr = {}; I.ctT = {}; I.emL = {};
    const st = STATES[name]; if (st.tap) { const tp = I.fromM ? I.fromM(st.tap[0], st.tap[1]) : st.tap; I.shots.push({ S: DENT, t0: now, x: tp[0], y: tp[1] }); }
    if (I.onState) I.onState(name);
  }
  function fire(I, e, now) { const n = e[1]; I.ctr[n] = (I.ctr[n] || 0) + 1; I.ctT[n] = now;
    if (n === 'blink' || n === 'blink2') { I.blinkT = now; I.dbl = n === 'blink2'; I.blinkAt = now + 2600; }
    else if (n === 'poke') poke(I, e[2], e[3], now);
    else if (n === 'emit') emit(I, e[2], e[3], e[4]);
    const st = STATES[I.cur.name]; if (st.on && st.on[n]) st.on[n](I, e, now); }
  function poke(I, x, y, now) { I.shots.push({ S: POKE(x < 50 ? 1 : -1), t0: now, x, y }); }
  function region(I, x, y) { const P = I.lastP || REST; x -= P.x; y += P.lift; if (I.toM) [x, y] = I.toM(x, y); const dx = x - 50, dh = Math.hypot(dx, y - 46), L = dx < 0;
    if (x > 74 && y > 56 && y < 92) return 'tail';
    if (y > 87) return L ? 'footL' : 'footR';
    if (y < 30 && Math.abs(dx) > 9) return L ? 'earL' : 'earR';
    if (y >= 70 && Math.abs(dx) < 13) return 'belly';
    if (y >= 64 && Math.abs(dx) >= 13) return L ? 'sideL' : 'sideR';
    if (dh < 31) { if (y < 38) return 'head'; if (Math.abs(dx) < 6 && y >= 50 && y < 62) return 'nose'; if (y >= 40 && y < 52 && Math.abs(Math.abs(dx) - 12) < 6) return L ? 'eyeL' : 'eyeR'; if (y < 50) return 'head'; return L ? 'cheekL' : 'cheekR'; }
    return L ? 'sideL' : 'sideR'; }
  // particles: crumbs, drops, tears, bubbles, sparkles, hearts, stink waves, steam, notes
  const PRE = {
    crumb: { n: 3, sp: 9, vy: -6, g: 90, life: 650, r: [0.5, 0.9], col: ['#d9a35a', '#b77a3a', '#f0c890'], kind: 'dot' },
    drop: { n: 5, sp: 20, vy: -16, g: 80, life: 750, r: [0.7, 1.2], col: ['#8fd3ff', '#bfe8ff'], kind: 'drop' },
    splash: { n: 8, sp: 28, vy: -28, g: 95, life: 820, r: [0.8, 1.4], col: ['#8fd3ff', '#bfe8ff'], kind: 'drop' },
    tear: { n: 1, sp: 0.6, vy: 3, g: 16, life: 1150, r: [1, 1.2], col: ['#8fd3ff'], kind: 'drop' },
    gush: { n: 2, sp: 5, vx: 24, vy: -15, g: 75, life: 760, r: [0.9, 1.4], col: ['#8fd3ff', '#bfe8ff'], kind: 'drop', out: 1 },
    bubble: { n: 2, sp: 7, vy: -9, g: -3, life: 1700, r: [1.2, 2.6], kind: 'bubble' },
    bigbubble: { n: 1, sp: 3, vx: 7, vy: -6, g: -1.5, life: 2600, r: [3.6, 4.6], kind: 'bubble', out: 1 },
    spark: { n: 4, sp: 16, vy: -6, g: 0, life: 700, r: [1.4, 2.4], col: ['#fff3a0', '#ffffff'], kind: 'star' },
    heart: { n: 1, sp: 7, vy: -12, g: -2, life: 1300, r: [0.8, 1.1], kind: 'heart' },
    stink: { n: 1, sp: 7, vy: -7, g: -1, life: 1900, r: [1, 1.3], col: ['#8fae55', '#a3c266'], kind: 'wave' },
    steam: { n: 2, sp: 3, vy: -13, g: -4, life: 900, r: [1.6, 2.6], col: ['#ffffff'], kind: 'puff' },
    foam: { n: 2, sp: 9, vy: -3, g: 0, life: 1300, r: [1.6, 2.8], col: ['#ffffff'], kind: 'puff' },
    seed: { n: 1, sp: 2, vx: 20, vy: -10, g: 70, life: 800, r: [0.7, 0.8], col: ['#2a1a30'], kind: 'seed', out: 1 },
    sneeze: { n: 9, sp: 20, vy: 2, g: 18, life: 620, r: [0.5, 1], col: ['#d6f2fc', '#ffffff'], kind: 'dot' },
    note: { n: 1, sp: 9, vy: -11, g: -2, life: 1400, r: [1, 1], col: ['#8f3cf2', '#ff5cc6', '#2f7fd6'], kind: 'note' },
    sweat: { n: 1, sp: 0, vy: 2, g: 20, life: 900, r: [1.1, 1.1], col: ['#8fd3ff'], kind: 'drop' },
    duck: { n: 1, sp: 0, vx: 2.2, vy: -24, g: 120, life: 3600, r: [1, 1.15], kind: 'duck', out: 1, hop: 1 },
    dust: { n: 3, sp: 8, vy: -2, g: 5, life: 1500, r: [0.35, 0.75], col: ['#fff1d6', '#d2b6f4', '#ffffff'], kind: 'dot' },
    sprinkle: { n: 4, sp: 22, vy: -22, g: 90, life: 950, r: [0.7, 0.9], col: ['#ffd84a', '#7cc8ff', '#9be38a', '#ffffff', '#ff5cc6'], kind: 'seed' },
    salt: { n: 3, sp: 10, vy: 2, g: 70, life: 900, r: [0.45, 0.75], col: ['#ffffff', '#f2f0ff', '#fffbe6'], kind: 'dot' },
    ketchup: { n: 3, sp: 14, vy: -15, g: 90, life: 800, r: [0.9, 1.4], col: ['#e8352a', '#ff5a4a', '#c8241c'], kind: 'drop' },
    coffee: { n: 4, sp: 18, vy: -20, g: 90, life: 800, r: [0.8, 1.3], col: ['#8a5a3a', '#b07a52'], kind: 'drop' },
    gust: { n: 1, sp: 3, vx: 26, vy: -3, g: 0, life: 1000, r: [0.9, 1.4], col: ['#9ad8cc', '#7cc8ff'], kind: 'wisp', out: 1 },
  };
  function where(I, w) { if (Array.isArray(w)) return [w[0], w[1], w[0] < 50 ? -1 : 1]; const p = (I.W && I.W[w]) || [50, 50]; const sd = /L$/.test(w) ? -1 : /R$/.test(w) || w === 'tail' ? 1 : 0; return [p[0], p[1], sd]; }
  function emit(I, name, w, n) { const q = PRE[name]; if (!q) return; const [x, y, sd] = where(I, w); n = n || q.n;
    for (let i = 0; i < n && I.parts.length < 140; i++) { const a = Math.random() * TAU, m = Math.random() * q.sp, side = q.out ? (sd || (Math.random() < 0.5 ? -1 : 1)) : 1;
      I.parts.push({ x: x + Math.cos(a) * 0.6, y: y + Math.sin(a) * 0.6, vx: (q.vx || 0) * side + Math.cos(a) * m, vy: (q.vy || 0) + Math.sin(a) * m * 0.7, g: q.g, life: q.life * (0.8 + Math.random() * 0.4), age: 0,
        r: q.r[0] + Math.random() * (q.r[1] - q.r[0]), col: q.col ? q.col[Math.floor(Math.random() * q.col.length)] : '#fff', kind: q.kind, ph: Math.random() * TAU, gy: q.hop ? y : null }); } }
  function drawParts(I, dt) { let h = '';
    I.parts = I.parts.filter(p => { p.age += dt * 1000; if (p.age > p.life) return false; p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; if (p.gy != null && p.y > p.gy && p.vy > 0) { p.y = p.gy; p.vy = -24 * (0.85 + Math.random() * 0.3); p.land = p.age; } const u = p.age / p.life, op = r2(Math.min(1, u * 8) * (1 - SM((u - 0.7) / 0.3)));
      const tr = 'translate(' + r2(p.x) + ' ' + r2(p.y) + ')';
      if (p.kind === 'dot') h += '<circle cx="' + r2(p.x) + '" cy="' + r2(p.y) + '" r="' + r2(p.r) + '" fill="' + p.col + '" opacity="' + op + '"/>';
      else if (p.kind === 'drop') h += '<path transform="' + tr + ' rotate(' + r2(Math.atan2(-p.vx, p.vy) / D2R) + ') scale(' + r2(p.r) + ')" d="M0 -2 Q1.4 0.4 0 1.3 Q-1.4 0.4 0 -2Z" fill="' + p.col + '" stroke="#ffffff" stroke-width="0.3" opacity="' + op + '"/>';
      else if (p.kind === 'bubble') { const pop = SM((u - 0.88) / 0.12), rr = p.r * (1 + pop * 0.4); h += '<g opacity="' + r2(op * (1 - pop)) + '"><circle cx="' + r2(p.x + Math.sin(p.age / 300 + p.ph) * 1.2) + '" cy="' + r2(p.y) + '" r="' + r2(rr) + '" fill="rgba(215,240,255,0.35)" stroke="#ffffff" stroke-width="0.45"/><circle cx="' + r2(p.x - rr * 0.35) + '" cy="' + r2(p.y - rr * 0.35) + '" r="' + r2(rr * 0.22) + '" fill="#ffffff"/></g>'; }
      else if (p.kind === 'star') h += '<path d="' + star4(p.x, p.y, p.r * (0.6 + 0.6 * Math.sin(Math.PI * u))) + '" fill="' + p.col + '" opacity="' + op + '"/>';
      else if (p.kind === 'heart') h += '<path transform="' + tr + ' scale(' + r2(p.r * (0.8 + u * 0.5)) + ')" d="M0 2.6 C-4.6 -0.6 -3.4 -5.6 0 -3 C3.4 -5.6 4.6 -0.6 0 2.6Z" fill="#ff5c9e" stroke="#ffffff" stroke-width="0.5" opacity="' + op + '"/>';
      else if (p.kind === 'wave') { const w = Math.sin(p.age / 260 + p.ph) * 1.2; h += '<path transform="' + tr + ' scale(' + r2(p.r) + ')" d="M0 0 q' + r2(-1.6 + w) + ' -2 0 -4 q' + r2(1.6 + w) + ' -2 0 -4" stroke="' + p.col + '" stroke-width="1.1" fill="none" stroke-linecap="round" opacity="' + r2(op * 0.9) + '"/>'; }
      else if (p.kind === 'wisp') { const s = p.r * (0.8 + u * 0.6), dr = p.vx < 0 ? -1 : 1; h += '<path transform="' + tr + ' scale(' + r2(dr * s) + ' ' + r2(s) + ')" d="M-5 0 Q-2 -1.6 1 0 T5 -0.6 Q7 -1.6 6 -3 Q4.6 -3.6 4.6 -2.2" stroke="' + p.col + '" stroke-width="' + r2(0.9 / s) + '" fill="none" stroke-linecap="round" opacity="' + r2(op * 0.9) + '"/>'; }
      else if (p.kind === 'leaf') { const sw = Math.sin(p.age / 260 + p.ph); h += '<path transform="translate(' + r2(p.x + sw * 2.2) + ' ' + r2(p.y) + ') rotate(' + r2(p.ph * 57 + sw * 55) + ') scale(' + r2(p.r) + ')" d="M0 -2.6 Q1.8 -0.8 0.3 2.3 L0 2.9 L-0.3 2.3 Q-1.8 -0.8 0 -2.6Z" fill="' + p.col + '" stroke="#ffffff" stroke-width="0.25" opacity="' + op + '"/>'; }
      else if (p.kind === 'duck') { const sq = p.land != null && p.age - p.land < 140 ? 1 - SM((p.age - p.land) / 140) : 0, wd = Math.sin(p.age / 110 + p.ph) * 14, dr = p.vx < 0 ? -1 : 1, s = p.r * 1.5;
        h += '<g transform="' + tr + ' scale(' + r2(dr * s * (1 + sq * 0.18)) + ' ' + r2(s * (1 - sq * 0.22)) + ') rotate(' + r2(wd) + ')" opacity="' + op + '"><ellipse cx="0.2" cy="-2" rx="3.5" ry="2.3" fill="#e9a512"/><ellipse cx="-0.2" cy="-2.4" rx="3.1" ry="1.9" fill="#ffd43b"/><path d="M-3 -2.6 L-4.5 -4.2 L-2.4 -3.5Z" fill="#ffd43b"/><path d="M-1.6 -2.6 Q0 -1.2 1.4 -2.6" stroke="#e9a512" stroke-width="0.5" fill="none" stroke-linecap="round"/><circle cx="1.95" cy="-4.85" r="1.85" fill="#e9a512"/><circle cx="1.8" cy="-5" r="1.75" fill="#ffd43b"/><ellipse cx="3.7" cy="-4.6" rx="1.05" ry="0.5" fill="#ff8a2a"/><circle cx="2.4" cy="-5.4" r="0.36" fill="#2a1a30"/><ellipse cx="1.1" cy="-5.8" rx="0.6" ry="0.35" fill="#fff8d0"/><ellipse cx="-1.2" cy="-3.3" rx="1" ry="0.4" fill="#fff8d0" opacity="0.8"/></g>'; }
      else if (p.kind === 'haze') h += '<circle cx="' + r2(p.x) + '" cy="' + r2(p.y) + '" r="' + r2(p.r * (0.8 + u * 1.1)) + '" fill="url(#phz' + I.u + ')" opacity="' + op + '"/>'; // a soft cloud of dust that spreads as it rises
      else if (p.kind === 'puff') h += '<circle cx="' + r2(p.x) + '" cy="' + r2(p.y) + '" r="' + r2(p.r * (0.7 + u * 0.8)) + '" fill="' + p.col + '" opacity="' + r2(op * 0.85) + '"/>';
      else if (p.kind === 'seed') h += '<ellipse cx="' + r2(p.x) + '" cy="' + r2(p.y) + '" rx="' + r2(p.r * 0.7) + '" ry="' + r2(p.r) + '" fill="' + p.col + '" opacity="' + op + '"/>';
      else if (p.kind === 'note') h += '<g transform="' + tr + ' rotate(' + r2(Math.sin(p.age / 200) * 12) + ')" opacity="' + op + '"><ellipse cx="0" cy="0" rx="1.5" ry="1.1" fill="' + p.col + '" transform="rotate(-20)"/><path d="M1.3 -0.3 L1.3 -5 Q3 -4.2 3.3 -2.6" stroke="' + p.col + '" stroke-width="0.8" fill="none" stroke-linecap="round"/></g>';
      return true; });
    return h; }

  // water layer (house bath / shower / swim; all channels default 0 = off, so nothing changes for other states):
  // wd = water depth (0 dry .. 1 up to his chin, measured from his own mouth height so every creature keeps his face out), sk = sink, dv = dive (water closes over him),
  // fm = bath foam round the waterline, fh = foam hat, dk = rubber duck (dkx slides it), spg = sponge in the right paw, shw = shower spray, stm = steam, wet = drips.
  // Everything below the surface is clipped (shadow too); the back half of the water ring sits behind him, the front lip + ripples in front.
  function wPrep(I) { const fx = I.fxG, par = fx && fx.parentNode; if (!par) return null; const NS = 'http://www.w3.org/2000/svg', mkE = n => document.createElementNS(NS, n);
    const df = mkE('defs'), cp = mkE('clipPath'), rc = mkE('rect'); cp.setAttribute('id', 'wcl' + I.u); cp.setAttribute('clipPathUnits', 'userSpaceOnUse'); rc.setAttribute('x', -300); rc.setAttribute('y', -400); rc.setAttribute('width', 700); rc.setAttribute('height', 500); cp.appendChild(rc); df.appendChild(cp); par.insertBefore(df, par.firstChild);
    const b = mkE('g'), g = mkE('g'); [...par.childNodes].forEach(n => { if (n === fx || n === df || n.nodeName === 'defs') return; g.appendChild(n); }); par.insertBefore(g, fx); par.insertBefore(b, g);
    return { g, b, rc, on: false, m0: null, cx: null, hw: null }; }
  const DUCK = '<ellipse cx="0.2" cy="-2" rx="3.5" ry="2.3" fill="#e9a512"/><ellipse cx="-0.2" cy="-2.4" rx="3.1" ry="1.9" fill="#ffd43b"/><path d="M-3 -2.6 L-4.5 -4.2 L-2.4 -3.5Z" fill="#ffd43b"/><path d="M-1.6 -2.6 Q0 -1.2 1.4 -2.6" stroke="#e9a512" stroke-width="0.5" fill="none" stroke-linecap="round"/><circle cx="1.95" cy="-4.85" r="1.85" fill="#e9a512"/><circle cx="1.8" cy="-5" r="1.75" fill="#ffd43b"/><ellipse cx="3.7" cy="-4.6" rx="1.05" ry="0.5" fill="#ff8a2a"/><circle cx="2.4" cy="-5.4" r="0.36" fill="#2a1a30"/><ellipse cx="1.1" cy="-5.8" rx="0.6" ry="0.35" fill="#fff8d0"/><ellipse cx="-1.2" cy="-3.3" rx="1" ry="0.4" fill="#fff8d0" opacity="0.8"/>';
  const bub = (x, y, r, op) => '<circle cx="' + r2(x) + '" cy="' + r2(y) + '" r="' + r2(r) + '" fill="#ffffff" stroke="#cfe8f4" stroke-width="0.35" opacity="' + r2(op) + '"/><circle cx="' + r2(x - r * 0.35) + '" cy="' + r2(y - r * 0.38) + '" r="' + r2(r * 0.26) + '" fill="#eaf7ff" opacity="' + r2(op) + '"/>';
  // Nov 10 (user: Chilla's dust bath didn't look good - 'add a dust bath to the animation and then the chilla will really do a bath in it'):
  // channel dbb (0..1, a little over 1 for a pop) = a dust-bath tub full of sand at the creature's feet. The inside of the tub + the sand
  // are drawn BEHIND the creature (a group put in just before it) and the front wall IN FRONT of it, so she sits / lies down inside it (her feet
  // and bottom hidden by the wall); it pops in / out with dbb (scale + fade). The flying sand itself is particles ('dustbath', set by the moves).
  // Nov 10 v2 (user: 'the dust bath needs to be bigger' + a photo of a real chinchilla rolling on her back in a big round wooden tub of grey
  // dust): the tub is now nearly the whole stage wide (rx 45 vs 27) and seen a little from above (ry 10) so she can lie down in it full length;
  // honey wood with staves, one hoop and a thick rounded rim; pale grey-beige dust with roll marks. Channel dbh (0..1) = the cloud of dust
  // hanging over the tub while she rolls (soft blobs behind her + a thinner veil in front, drifting).
  function dustBath(I, P, now) { const s = clamp(P.dbb || 0, 0, 1.3), hz = clamp(P.dbh || 0, 0, 1) * clamp(s, 0, 1);
    if (s < 0.02) { if (I.dbG && I.dbOn) { I.dbG.innerHTML = ''; I.dbOn = false; I.root.removeAttribute('clip-path'); } return ''; }
    if (!I.dbG) { I.dbG = document.createElementNS('http://www.w3.org/2000/svg', 'g'); I.root.parentNode.insertBefore(I.dbG, I.root); }
    const u = I.u, cx = 50, rx = 46 * s, ry = 11.5 * s, rim = 79 + 9 * (1 - Math.min(1, s)), wh = 11 * s, brx = rx * 0.94, bry = ry * 0.94, by = rim + wh, al = r2(clamp(s * 3, 0, 1)), T = (now || 0) / 1000,
      arc = (y, a, b, up) => 'M' + r2(cx - a) + ' ' + r2(y) + 'A' + r2(a) + ' ' + r2(b) + ' 0 0 ' + (up ? 1 : 0) + ' ' + r2(cx + a) + ' ' + r2(y),
      lvl = f => [rim + wh * f, rx + (brx - rx) * f, ry + (bry - ry) * f],
      blob = (x, y, r, o) => '<circle cx="' + r2(x) + '" cy="' + r2(y) + '" r="' + r2(r) + '" fill="url(#dbh' + u + ')" opacity="' + r2(o) + '"/>';
    const sy = rim + 3 * s, srx = rx - 2.6 * s, sry = ry - 0.6 * s;
    let sp = ''; for (let i = 0; i < 26; i++) { const a = i * 2.4, rr = (0.15 + (i * 7 % 10) / 11.5) * srx * 0.92; sp += '<circle cx="' + r2(cx + Math.cos(a) * rr) + '" cy="' + r2(sy + Math.sin(a) * rr * sry / srx * 0.85) + '" r="' + r2((0.3 + (i % 3) * 0.12) * s) + '" fill="' + (i % 2 ? '#bdb2a2' : '#fbf8f3') + '" opacity="0.6"/>'; }
    let gr = ''; [[-24, -2.5, 9, 0.9], [-6, 1.2, 12, 1.1], [17, -1.4, 10, 0.8], [29, 2.6, 7, 0.7], [-31, 3.2, 6, 0.6]].forEach(([dx, dy, w, b]) => { const x = cx + dx * s, y = sy + dy * s, ww = w * s; gr += '<path d="M' + r2(x - ww) + ' ' + r2(y) + 'Q' + r2(x) + ' ' + r2(y + b * 1.6 * s) + ' ' + r2(x + ww) + ' ' + r2(y) + '" stroke="#c3b8a8" stroke-width="' + r2(0.7 * s) + '" fill="none" stroke-linecap="round" opacity="0.55"/><path d="M' + r2(x - ww * 0.9) + ' ' + r2(y - 0.6 * s) + 'Q' + r2(x) + ' ' + r2(y + b * 1.6 * s - 0.6 * s) + ' ' + r2(x + ww * 0.9) + ' ' + r2(y - 0.6 * s) + '" stroke="#fdfbf8" stroke-width="' + r2(0.5 * s) + '" fill="none" stroke-linecap="round" opacity="0.7"/>'; });
    let hzB = '', hzF = '';
    if (hz > 0.01) for (let i = 0; i < 6; i++) { const x = cx + (-34 + i * 13.6) * s + Math.sin(T * 0.8 + i * 1.7) * 3.5, y = rim - 7 - (i % 2) * 6 + Math.sin(T * 1.1 + i * 2.3) * 2.2, r = (12 + (i * 5 % 3) * 3.5) * (0.9 + 0.1 * Math.sin(T * 1.6 + i));
      hzB += blob(x, y, r, hz * 0.85); if (i % 2 === 0) hzF += blob(x + 3, y + 6, r * 0.85, hz * 0.18); }
    if (hz > 0.01) for (let i = 0; i < 4; i++) hzF += blob(cx + (-30 + i * 20) * s + Math.sin(T * 1.3 + i * 2.1) * 3, rim + 2 + Math.sin(T * 1.7 + i) * 1.5, 8 + (i % 2) * 3, hz * 0.2); // a veil of dust over her body too (the photo: she's half hidden in it)
    I.dbG.innerHTML = '<defs><linearGradient id="dbw' + u + '" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#a5763e"/><stop offset="0.16" stop-color="#d6a967"/><stop offset="0.4" stop-color="#f0cf98"/><stop offset="0.62" stop-color="#e5bc7e"/><stop offset="0.86" stop-color="#c49352"/><stop offset="1" stop-color="#9a6c37"/></linearGradient>'
      + '<linearGradient id="dbi' + u + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e4bd84"/><stop offset="1" stop-color="#b08048"/></linearGradient>'
      + '<radialGradient id="dbs' + u + '" cx="42%" cy="35%" r="72%"><stop offset="0" stop-color="#f6f3ee"/><stop offset="0.7" stop-color="#e3dbcf"/><stop offset="1" stop-color="#cdc2b2"/></radialGradient>'
      + '<radialGradient id="dbh' + u + '"><stop offset="0" stop-color="#c9c8c6" stop-opacity="0.9"/><stop offset="0.55" stop-color="#d2d1cf" stop-opacity="0.5"/><stop offset="1" stop-color="#d8d7d5" stop-opacity="0"/></radialGradient>'
      + '<clipPath id="dbk' + u + '" clipPathUnits="userSpaceOnUse"><path d="M-200 -300L300 -300L300 300L' + r2(cx + brx) + ' 300L' + r2(cx + brx) + ' ' + r2(by) + 'A' + r2(brx) + ' ' + r2(bry) + ' 0 0 1 ' + r2(cx - brx) + ' ' + r2(by) + 'L' + r2(cx - brx) + ' 300L-200 300Z"/></clipPath>' // nothing of her shows below the tub's bottom (whiskers, an ear tip) - straight down from its bottom only: a foot / ear draped over its side hangs on outside (a clip up the sides cut it off with a hard vertical edge)
      + '<clipPath id="dbc' + u + '"><ellipse cx="' + cx + '" cy="' + r2(rim) + '" rx="' + r2(rx - 0.4) + '" ry="' + r2(ry - 0.3) + '"/></clipPath></defs>'
      + '<g opacity="' + al + '"><ellipse cx="' + cx + '" cy="' + r2(by + 0.8) + '" rx="' + r2(brx * 1.04) + '" ry="' + r2(bry * 0.95) + '" fill="#6d4f9a" opacity="0.17"/>'
      + '<ellipse cx="' + cx + '" cy="' + r2(rim) + '" rx="' + r2(rx) + '" ry="' + r2(ry) + '" fill="url(#dbi' + u + ')"/>'                                      // the inside wall
      + '<g clip-path="url(#dbc' + u + ')"><ellipse cx="' + cx + '" cy="' + r2(sy + 0.5 * s) + '" rx="' + r2(srx + 0.8) + '" ry="' + r2(sry + 0.6) + '" fill="#8d6232" opacity="0.35"/>'   // shade where the dust meets the wall
      + '<ellipse cx="' + cx + '" cy="' + r2(sy) + '" rx="' + r2(srx) + '" ry="' + r2(sry) + '" fill="url(#dbs' + u + ')"/>' + gr + sp + '</g>'                   // the dust, roll marks, grains
      + '<path d="' + arc(rim, rx, ry, 1) + '" fill="none" stroke="#f6dfb4" stroke-width="' + r2(1.9 * s) + '" stroke-linecap="round"/>'                          // the back rim
      + '<path d="' + arc(rim + 0.35 * s, rx - 1.1 * s, ry - 0.7 * s, 1) + '" fill="none" stroke="#a87a42" stroke-width="' + r2(0.45 * s) + '" opacity="0.55"/>' + hzB + '</g>';
    if (!I.dbOn) I.root.setAttribute('clip-path', 'url(#dbk' + u + ')'); I.dbOn = true;
    let st = ''; for (let a = -72; a <= 72; a += 12) { const q = a * D2R, x0 = cx + rx * Math.sin(q), y0 = rim + ry * Math.cos(q), x1 = cx + brx * Math.sin(q), y1 = by + bry * Math.cos(q);
      st += '<path d="M' + r2(x0) + ' ' + r2(y0 + 1) + 'L' + r2(x1) + ' ' + r2(y1) + '" stroke="#9c6d38" stroke-width="' + r2(0.35 * s) + '" opacity="0.38"/>'; }
    const [hy, ha, hb] = lvl(0.66), [hy2, ha2, hb2] = lvl(0.66 + 1.5 / Math.max(1, wh));
    // dbs (Nov 10 v3, she lay ON the flat dust instead of IN it): dust heaped up against her front where she's sunk in - a mound rising a few units
    // above the front rim, highest in the middle, lumps shifting while she rolls (dbh = rolling); its foot is behind the front wall
    let heap = ''; const dk = clamp(P.dbs || 0, 0, 1) * Math.min(1, s);
    if (dk > 0.01) { const N = 22, x0 = cx - 41 * s, x1 = cx + 41 * s, rf = x => rim + ry * Math.sqrt(Math.max(0, 1 - ((x - cx) / rx) * ((x - cx) / rx))), mv = hz;
      let top = ''; const pts = []; for (let i = 0; i <= N; i++) { const q = i / N, x = x0 + (x1 - x0) * q, e = Math.pow(Math.sin(Math.PI * q), 0.55), lump = 1 + 0.22 * Math.sin(q * 19 + 1.3 + T * 5 * mv) + 0.12 * Math.sin(q * 41 + T * 8 * mv);
        pts.push([x, rf(x) - dk * 5.5 * s * e * lump]); }
      pts.forEach((p, i) => { top += (i ? 'L' : 'M') + r2(p[0]) + ' ' + r2(p[1]); });
      let gn = ''; for (let i = 2; i < N - 1; i += 2) { const p = pts[i]; gn += '<circle cx="' + r2(p[0] + Math.sin(i * 3.7) * 1.2) + '" cy="' + r2(p[1] + 1.4 + (i % 3) * 0.7) + '" r="' + r2(0.32 * s) + '" fill="' + (i % 4 ? '#b9b0a3' : '#fbf9f5') + '" opacity="0.7"/>'; }
      heap = '<g opacity="' + r2(al * Math.min(1, dk * 2.5)) + '"><path d="' + top + 'L' + r2(x1) + ' ' + r2(by + 4) + 'L' + r2(x0) + ' ' + r2(by + 4) + 'Z" fill="url(#dbs' + u + ')"/>'
        + '<path d="' + top + '" fill="none" stroke="#a99f91" stroke-width="' + r2(1.2 * s) + '" stroke-linejoin="round" opacity="0.35" transform="translate(0 -0.5)"/>'
        + '<path d="' + top + '" fill="none" stroke="#fcfaf6" stroke-width="' + r2(0.6 * s) + '" stroke-linejoin="round" opacity="0.9" transform="translate(0 0.45)"/>' + gn + '</g>'; }
    return heap + '<g opacity="' + al + '"><path d="' + arc(rim, rx, ry, 0) + 'L' + r2(cx + brx) + ' ' + r2(by) + 'A' + r2(brx) + ' ' + r2(bry) + ' 0 0 1 ' + r2(cx - brx) + ' ' + r2(by) + 'Z" fill="url(#dbw' + u + ')"/>' + st // the front wall + staves
      + '<path d="' + arc(hy, ha, hb, 0) + 'L' + r2(cx + ha2) + ' ' + r2(hy2) + 'A' + r2(ha2) + ' ' + r2(hb2) + ' 0 0 1 ' + r2(cx - ha2) + ' ' + r2(hy2) + 'Z" fill="#9b6c3a" opacity="0.8"/>'      // the hoop
      + '<path d="' + arc(hy, ha, hb, 0) + '" fill="none" stroke="#e8c58e" stroke-width="' + r2(0.4 * s) + '" opacity="0.8"/>'
      + '<path d="' + arc(rim + 0.9 * s, rx - 0.1, ry, 0) + '" fill="none" stroke="#a97b43" stroke-width="' + r2(0.6 * s) + '" opacity="0.6"/>'                   // under the lip
      + '<path d="' + arc(rim, rx, ry, 0) + '" fill="none" stroke="#f8e4bf" stroke-width="' + r2(1.9 * s) + '" stroke-linecap="round"/>'                          // the front rim
      + '<path d="M' + r2(cx - rx * 0.5) + ' ' + r2(rim + ry * 0.86 - 0.25) + 'Q' + r2(cx - rx * 0.2) + ' ' + r2(rim + ry + 0.05) + ' ' + r2(cx + rx * 0.05) + ' ' + r2(rim + ry * 0.99 - 0.25) + '" stroke="#ffffff" stroke-width="' + r2(0.6 * s) + '" stroke-linecap="round" fill="none" opacity="0.65"/>'
      + '<path d="M' + r2(cx - brx * 0.62) + ' ' + r2(by + bry * 0.6) + 'Q' + r2(cx - brx * 0.3) + ' ' + r2(by + bry * 0.86) + ' ' + r2(cx - brx * 0.05) + ' ' + r2(by + bry * 0.86) + '" stroke="#fff3da" stroke-width="' + r2(0.9 * s) + '" stroke-linecap="round" fill="none" opacity="0.35"/>'
      + hzF + '</g>'; }
  function water(I, P, now) {
    const wd = clamp(P.wd || 0, 0, 1.2), on = wd > 0.02, sh = P.shw || 0, stm = P.stm || 0, wet = P.wet || 0, fh = P.fh || 0, spg = P.spg || 0;
    if (!on && sh < 0.02 && stm < 0.02 && wet < 0.02 && fh < 0.02 && spg < 0.02 && !(I.wc && I.wc.on)) return '';
    if (on && !I.wc) I.wc = wPrep(I); const C = I.wc, W = I.W || {}, ok = p => p && isFinite(p[0]) && isFinite(p[1]), T = now / 1000;
    const M = ok(W.mouth) ? W.mouth : ok(W.nose) ? W.nose : null, m0 = (M ? M[1] : 58) + P.lift, sl = W.sideL, sr = W.sideR, hw0 = ok(sl) && ok(sr) ? Math.abs(sr[0] - sl[0]) * 0.56 + 4 : 22, cx0 = ok(W.body) ? W.body[0] : 50 + P.x;
    let back = '', h = '', Y = 0, cx = cx0, hw = clamp(hw0, 14, 38);
    if (C) { C.m0 = C.m0 == null ? m0 : C.m0 + (m0 - C.m0) * 0.05; C.cx = C.cx == null ? cx0 : C.cx + (cx0 - C.cx) * 0.2; C.hw = C.hw == null ? hw : C.hw + (hw - C.hw) * 0.1; cx = C.cx; hw = C.hw; }
    if (C && on !== C.on) { C.on = on; if (on) C.g.setAttribute('clip-path', 'url(#wcl' + I.u + ')'); else { C.g.removeAttribute('clip-path'); C.b.innerHTML = ''; } }
    if (on && C) {
      const G0 = 96, top = C.m0 + (P.sk || 0) + 5; Y = G0 - Math.min(wd, 1) * (G0 - top); C.rc.setAttribute('height', r2(400 + Y + 1.2));
      const rx = hw + 6, ry = Math.max(2.6, rx * 0.19), half = (y, rxx, ryy, up) => 'M' + r2(cx - rxx) + ' ' + r2(y) + 'A' + r2(rxx) + ' ' + r2(ryy) + ' 0 0 ' + (up ? 1 : 0) + ' ' + r2(cx + rxx) + ' ' + r2(y);
      back += '<path d="' + half(Y, rx, ry, 1) + 'Z" fill="#8fd0ee" opacity="0.55"/><path d="' + half(Y, rx, ry, 1) + '" fill="none" stroke="#ffffff" stroke-width="0.6" opacity="0.7"/>';
      h += '<path d="' + half(Y, rx, ry, 0) + 'Z" fill="#7cc6ea" opacity="0.62"/><path d="' + half(Y + 0.2, rx - 0.6, ry * 0.86, 0) + '" fill="none" stroke="#ffffff" stroke-width="0.9" stroke-linecap="round" opacity="0.85"/>';
      h += '<path d="M' + r2(cx - hw + 1.5) + ' ' + r2(Y + 0.3) + 'Q' + r2(cx) + ' ' + r2(Y + 2.2) + ' ' + r2(cx + hw - 1.5) + ' ' + r2(Y + 0.3) + '" fill="none" stroke="#ffffff" stroke-width="1.1" stroke-linecap="round" opacity="0.9"/>';
      for (let i = 0; i < 2; i++) { const u = (T / 1.8 + i / 2) % 1, k = 1 + u * 0.55, op = r2((1 - u) * 0.6); back += '<path d="' + half(Y, rx * k, ry * k, 1) + '" fill="none" stroke="#ffffff" stroke-width="0.55" opacity="' + op + '"/>'; h += '<path d="' + half(Y, rx * k, ry * k, 0) + '" fill="none" stroke="#ffffff" stroke-width="0.55" opacity="' + op + '"/>'; }
      const fm = clamp(P.fm || 0, 0, 1.4); if (fm > 0.02) { const N = 24; for (let i = 0; i < N; i++) { const a = i / N * TAU + Math.sin(T * 0.6 + i) * 0.05, rr = hw + 0.5 + (i * 7 % 5) * 1.1, x = cx + Math.cos(a) * rr, y = Y + Math.sin(a) * ry * 0.95, r = (2.1 + (i * 5 % 4) * 0.6) * fm * (0.9 + 0.1 * Math.sin(T * 2.2 + i * 1.7)), s = bub(x, y - r * 0.4, r, Math.min(1, fm)); if (Math.sin(a) < 0) back += s; else h += s; }
        [[-1.06, 0.4, 3.6], [-0.9, 0.8, 2.6], [1.1, 0.3, 3.2], [0.85, 0.85, 2.8], [-0.45, 1.05, 2.4], [0.2, 1.15, 2.2], [1.28, -0.3, 2.4], [-1.25, -0.25, 2.6]].forEach(([fx, fy, r], i) => { h += bub(cx + fx * rx, Y + fy * ry - 1, r * fm * (0.92 + 0.08 * Math.sin(T * 1.9 + i)), Math.min(1, fm)); }); }
      const dk = clamp(P.dk || 0, 0, 1); if (dk > 0.02) { const dx = cx + rx * (0.62 + (P.dkx || 0)), dy = Y + ry * 0.75 + Math.sin(T * 2.4) * 0.6 + (1 - dk) * 5, s = 1.8 * dk;
        h += '<g transform="translate(' + r2(dx) + ' ' + r2(dy) + ') rotate(' + r2(Math.sin(T * 1.7) * 6) + ') scale(' + r2(-s) + ' ' + r2(s) + ')" opacity="' + r2(dk) + '">' + DUCK + '</g>'; }
      if ((P.dv || 0) > 0.3) for (let i = 0; i < 3; i++) { const u = (T * 1.4 + i / 3) % 1; h += bub(cx + Math.sin(i * 2.1 + T) * 4, Y - 1 - u * 3, 0.9 + u * 0.8, (1 - u) * 0.9); }
    }
    if (C) C.b.innerHTML = back;
    const HD = ok(W.head) ? W.head : ok(I.topW) ? I.topW : [50 + P.x, 20];
    if (fh > 0.02) { const k = Math.min(fh, 1.8); [[0, -2, 4], [-4.2, 0.3, 3], [4, -0.1, 3.2], [-1.9, -5.4, 2.8], [2.2, -5, 2.5], [0.2, -8.4, 2.3 * Math.max(0, k - 0.6)], [-0.6, -11, 1.6 * Math.max(0, k - 1.1)]].forEach(([x, y, r], i) => { if (r > 0.1) h += bub(HD[0] + x * Math.min(1, k), HD[1] + 1.4 + y * k + Math.sin(T * 2 + i) * 0.3, r * Math.min(1, k) * (0.94 + 0.06 * Math.sin(T * 3 + i)), Math.min(1, fh * 1.4)); }); }
    if (spg > 0.02 && ok(W.pawR) && (!on || W.pawR[1] < Y + 1.5)) { const [x, y] = W.pawR, s = Math.min(1, spg);
      h += '<g transform="translate(' + r2(x) + ' ' + r2(y - 1.4) + ') rotate(' + r2(-14 + Math.sin(T * 9) * 6) + ') scale(' + r2(s) + ')"><rect x="-3.6" y="-2.5" width="7.2" height="5" rx="1.6" fill="#ffd04a" stroke="#e0a21e" stroke-width="0.4"/><rect x="-3.6" y="1" width="7.2" height="1.5" rx="0.7" fill="#7cc35a"/><circle cx="-1.6" cy="-0.6" r="0.5" fill="#e0a21e"/><circle cx="1.2" cy="-1.3" r="0.45" fill="#e0a21e"/><circle cx="0.4" cy="0.2" r="0.35" fill="#e0a21e"/>' + bub(2.6, -2.8, 1.2 * s, s) + '</g>'; }
    if (sh > 0.02) { const n = 13, Yb = on ? Y : 95, hr = Math.max(9, hw * 0.62);
      for (let i = 0; i < n; i++) { const x = cx - hw - 4 + (i + 0.5) * (2 * hw + 8) / n + Math.sin(i * 3.1) * 0.8, inside = Math.abs(x - cx) < hr, yb = inside ? HD[1] + 2 + Math.pow((x - cx) / hr, 2) * 8 : Yb, L = 7 + (i % 3) * 2;
        for (let j = 0; j < 3; j++) { const yy = -26 + ((T * 95 + i * 23 + j * 31) % (yb + 26)), y2 = Math.min(yb, yy + L); if (y2 > yy) h += '<path d="M' + r2(x) + ' ' + r2(yy) + 'L' + r2(x - 0.5) + ' ' + r2(y2) + '" stroke="#5fb8ea" stroke-width="1.25" stroke-linecap="round" opacity="' + r2(0.8 * sh) + '"/><path d="M' + r2(x - 0.2) + ' ' + r2(yy) + 'L' + r2(x - 0.6) + ' ' + r2(y2) + '" stroke="#ffffff" stroke-width="0.45" stroke-linecap="round" opacity="' + r2(0.9 * sh) + '"/>'; }
        if (inside && i % 2) { const u = (T * 3 + i * 0.37) % 1; h += '<circle cx="' + r2(x + (x < cx ? -1 : 1) * u * 4) + '" cy="' + r2(yb - Math.sin(u * Math.PI) * 3) + '" r="0.55" fill="#bfe8ff" opacity="' + r2((1 - u) * sh) + '"/>'; } } }
    if (stm > 0.02) for (let i = 0; i < 5; i++) { const u = (T / 3.2 + i / 5) % 1, x = cx + (i - 2) * hw * 0.42 + Math.sin(T + i) * 3, y = (on ? Y : 70) - u * 46; h += '<circle cx="' + r2(x) + '" cy="' + r2(y) + '" r="' + r2(3 + u * 6) + '" fill="#ffffff" opacity="' + r2(Math.sin(Math.PI * u) * 0.32 * Math.min(1, stm)) + '"/>'; }
    if (wet > 0.02) { const src = [W.sideL, W.sideR, M, W.belly, ok(W.earL) ? W.earL : null].filter(ok); src.forEach((p, i) => { const u = (T / 0.95 + i * 0.29) % 1, y = p[1] + 2 + u * 13; if (on && y > Y) return; h += '<path transform="translate(' + r2(p[0] + (i % 2 ? 1 : -1) * 1.2) + ' ' + r2(y) + ') scale(' + r2(0.9 * Math.min(1, wet)) + ')" d="M0 -2 Q1.4 0.4 0 1.3 Q-1.4 0.4 0 -2Z" fill="#8fd3ff" stroke="#ffffff" stroke-width="0.3" opacity="' + r2((1 - u) * Math.min(1, wet)) + '"/>'; }); }
    return h;
  }

  const blinkC = t => t < 0 ? 0 : t < 75 ? EZ.i(t / 75) : t < 105 ? 1 : t < 240 ? 1 - EZ.o((t - 105) / 135) : 0;

  function tick(I, now, dt) {
    const SO = n => (I.key && STATES[n + '@' + I.key]) || STATES[n]; let st = SO(I.cur.name), t = now - I.cur.t0;
    if (st.dur && t >= st.dur) { setState(I, I.queue.length ? I.queue.shift() : (st.next || 'idle'), now, true); st = SO(I.cur.name); t = 0; }
    const FL = (I.hfid && I.key && FIDK[I.key]) || FIDGETS; if (I.cur.name === 'idle' && I.fidgets && !I.press && !I.down && FL.length) { if (!I.fidAt) I.fidAt = now + (I.hfid ? 3200 + Math.random() * 3600 : 4200 + Math.random() * 4200); else if (now > I.fidAt) { I.fidAt = 0; let f; do { f = FL[Math.floor(Math.random() * FL.length)]; } while (FL.length > 1 && f === I.lastFid); I.lastFid = f; setState(I, f, now, true); st = SO(f); t = 0; } } else if (I.cur.name !== 'idle') I.fidAt = 0;
    if (st.emit) { const tl = st.loop ? t % st.loop : t; st.emit.forEach((m, i) => { if (tl >= m[0] && tl <= m[1] && now - (I.emL[i] || 0) >= m[2]) { I.emL[i] = now; emit(I, m[3], m[4], m[5]); } }); }
    if (st.ev) { const c = st.loop ? Math.floor(t / st.loop) : 0, tl = st.loop ? t % st.loop : t; if (c !== I.evC) { I.evC = c; I.evF = {}; } st.ev.forEach((e, i) => { if (tl >= e[0] && !I.evF[i]) { I.evF[i] = 1; fire(I, e, now); } }); }
    const P = poseAt(I.cur.name, t, I.key);
    if (I.prev) { const w = EZ.io(clamp((now - I.bt0) / I.bd, 0, 1)); if (w >= 1) I.prev = null; else { const Q = I.prev.frozen || poseAt(I.prev.name, now - I.prev.t0, I.key);
      for (const k in P) { if (k === 'spin') { let d = P.spin - Q.spin; d = ((d % 360) + 540) % 360 - 180; P.spin = Q.spin + d * w; } else P[k] = lerp(Q[k] == null ? P[k] : Q[k], P[k], w); } } }
    if (I.ext) for (const k in I.ext) P[k] = (P[k] || 0) + I.ext[k];
    I.lastP = Object.assign({}, P);
    // look layer: eyes lead, head follows
    I.flw.step(st.look ? 1 : 0, dt); const lw = clamp(I.flw.v, 0, 1);
    let tx = 0, ty = 0; if (I.ptr) { tx = I.ptr.x; ty = I.ptr.y; } else { if (now > I.glAt) { const g = Math.random() < 0.3 ? [0, 0] : [(Math.random() * 2 - 1) * 0.9, (Math.random() - 0.5) * 0.7]; if (Math.abs(g[0] - I.gl[0]) > 0.9 && now - I.blinkT > 800) { I.blinkT = now + 60; I.dbl = false; } I.gl = g; I.glAt = now + 1400 + Math.random() * 2600; } tx = I.gl[0]; ty = I.gl[1]; }
    I.fex.step(tx, dt); I.fey.step(ty, dt); I.fhx.step(tx, dt); I.fhy.step(ty, dt);
    // HYAW rigs: the gaze turns the head, the body only follows a touch (was the whole body turning up to ~24 deg)
    if (HYAW.has(I.key)) { P.hyaw += I.fhx.v * 0.62 * lw; P.turn += I.fhx.v * 0.06 * lw; } else P.turn += I.fhx.v * 0.6 * lw;
    P.lx += I.fex.v * lw; P.ly += I.fey.v * lw; P.pitch -= I.fhy.v * 0.35 * lw; P.htilt += I.fhx.v * 2.5 * lw;
    // blink layer
    if (now > I.blinkAt) { I.blinkT = now; I.dbl = Math.random() < 0.2; I.blinkAt = now + 2200 + Math.random() * 3200; }
    if (!st.noBlink) { let b = blinkC(now - I.blinkT); if (I.dbl) b = Math.max(b, blinkC(now - I.blinkT - 260)); P.close = Math.max(P.close, b); }
    // touch layer
    I.fp.w = I.press ? 14 : 28; I.fp.step(I.press ? 1 : 0, dt); const pv = clamp(I.fp.v, 0, 1.05), ht = I.press ? now - I.pressT : 0;
    if (pv > 0.001) { P.sq += pv * (0.34 + 0.06 * clamp(ht / 2000, 0, 1)); P.hap = Math.max(P.hap, pv * 0.85); P.armL += pv * 22; P.armR += pv * 22; P.earL += pv * 14; P.earR += pv * 14;
      P.blush = Math.max(P.blush, pv * clamp((ht - 400) / 900, 0, 1)); if (ht > 1300) P.x += Math.sin(now / 24) * 0.22 * pv;
      const PR = I.key && PRESS[I.key]; if (PR) for (const k in PR) P[k] += pv * PR[k]; } // Nov 9: each Pet Shop creature's own squeeze face (pet-anims.js)
    I.dent = null;
    I.shots = I.shots.filter(s => { const u = now - s.t0; if (u > s.S.dur) return false; for (const k in s.S.k) { const v = kv(s.S.k[k], u); if (k === 'dent') I.dent = { x: s.x, y: s.y, a: v }; else P[k] += v; } return true; });
    if (I.spinTw) { const u = clamp((now - I.spinTw.t0) / I.spinTw.d, 0, 1); I.spinOff = lerp(I.spinTw.from, I.spinTw.to, EZ.bk(u)); if (u >= 1) { I.spinOff = I.spinTw.to % 360; I.spinTw = null; } }
    P.spin += I.spinOff;
    // follow-through: head jiggle, ears and tail trail behind
    I.fs.step(P.sq, dt); I.hs = clamp((I.fs.v - P.sq) * 0.55, -0.12, 0.12);
    const hx = P.x + P.lean + P.tilt * 0.9 + P.htilt * 0.4; I.fx.step(hx, dt); const ed = clamp(I.fx.v - hx, -8, 8);
    I.fl.step(P.lift, dt); const ld = clamp(I.fl.v - P.lift, -10, 10); I.ld = ld;
    if (I.lastSpin != null) { const dd = P.spin - I.lastSpin; if (Math.abs(dd) > 180) I.fsp.v += Math.round(dd / 360) * 360; } I.lastSpin = P.spin;
    I.fsp.step(P.spin, dt); const sd = clamp(I.fsp.v - P.spin, -40, 40);
    // Nov 10 (user: 'the spin doesn't look natural - the body doesn't look like it goes into a spin, the body's motion is not there'): spin body mechanics
    // for every rig. The top of the body follows the spin on a soft spring - it lags while the spin speeds up and swings past + wobbles back when it stops
    // (a twist: the generic renderer turns each point by its height, feet 0 -> top 1; the built-in rigs get it as their torso twist) - and from how fast
    // he spins: he rises a little and stretches tall, the arms fling out, and he squashes as he brakes.
    if (st.whip) { const SB = I.spb; if (SB) { SB.f.v = P.spin; SB.f.d = 0; SB.last = P.spin; SB.w.v = 0; SB.w.d = 0; SB.wl.v = 0; SB.wl.d = 0; } I.spTw = 0; I.spF = 0; }   // whip spins (fast cartoon spin) bring their own body motion
    else { const SB = I.spb || (I.spb = { f: new Fol(P.spin, 7.5, 0.42), w: new Fol(0, 10, 0.75), wl: new Fol(0, 6, 0.55), last: P.spin });
      let dd = P.spin - SB.last; if (Math.abs(dd) > 180) { const k = Math.round(dd / 360) * 360; SB.f.v += k; dd -= k; } SB.last = P.spin;
      SB.f.step(P.spin, dt); const tw = clamp(SB.f.v - P.spin, -40, 40), om = dt > 0.002 ? Math.abs(dd) / dt : 0; SB.w.step(clamp(om / 540, 0, 1), dt);
      const f = clamp(SB.w.v, 0, 1); SB.wl.step(f, dt); I.spTw = tw * 0.9 * D2R; I.spF = f; if (!I.generic) P.twist = (P.twist || 0) + tw * 0.9 / 40;   /* built-in rigs: upper body ~0.5x, head ~0.9x the lag */
      P.sq += -0.045 * f + clamp((SB.wl.v - f) * 0.14, -0.03, 0.05); P.lift += 1.5 * f; P.armL += 18 * f; P.armR += 18 * f; }
    I.ed = ed; P.earL += clamp(-ed * 2 - ld * 1.3, -22, 22); P.earR += clamp(ed * 2 - ld * 1.3, -22, 22); P.wag += clamp(sd * 0.5 - ed * 3, -30, 30);
    if (SOFT.has(I.key)) { const J = I.jel || (I.jel = { x: new Fol(0, 7, 0.3), y: new Fol(0, 8, 0.36) }), g = st.soft || 1;
      const tx = P.x + P.tilt * 0.9 + P.turn * 5 + P.bend * 0.3 + P.lean, ty = P.lift; // a head turn alone carries no body mass (it tipped him over) J.x.step(tx, dt); J.y.step(ty, dt);
      P.bend += clamp((J.x.v - tx) * 2.6 * g, -16, 16); P.sq += clamp((J.y.v - ty) * 0.008 * g, -0.06, 0.06);
      // motion stretch (Nov 8, user: when he moves fast the shape must stretch toward the move and come back when he stops): how fast the top of the
      // body travels sideways (sway + bend + the face swinging round with every head / body turn) and up / down, smoothed, becomes a stretch along that
      // direction (volume kept: thinner across it), strongest on the head, nothing at the feet; applied to every point in render (glob)
      const M = I.mot || (I.mot = { lx: null, ly: 0, yw: 0, vx: new Fol(0, 15, 1), vy: new Fol(0, 15, 1) }), lx = P.x + P.tilt * 0.9 + P.lean + P.bend * 0.35, yw = (P.turn + P.hyaw + P.twist) * 40;
      if (M.lx != null && dt > 0.002) { M.vx.step((lx - M.lx) / dt + (yw - M.yw) * D2R / dt * 4, dt); /* turning barely counts: the stretch is for real travel (hops, slides), a turning head stays round */ M.vy.step(-(P.lift - M.ly) / dt * 0.45, dt); } M.lx = lx; M.ly = P.lift; M.yw = yw;
      const spd = Math.hypot(M.vx.v, M.vy.v), sg = st.stretch != null ? st.stretch : 1; I.ms = spd > 2 ? { s: clamp(spd * 0.0034 * sg, 0, 0.26 * Math.max(1, sg * 0.8)), c: M.vx.v / spd, n: M.vy.v / spd } : null; } else I.ms = null;
    if (P.sk || P.dv) P.lift -= (P.sk || 0) + (P.dv || 0) * 30;
    I.propZ = st.propZ; if (I.generic) { if (!I.ready) return; I.render(I, P, now); } else render(I, P, now);
    const tt = now - I.cur.t0, fx = st.fx || FX[I.cur.name], pr = st.prop ? st.prop(I, tt) : '';
    if (pr || I.propOn) { I.pg.prop.innerHTML = pr; I.propOn = !!pr; }
    I.fxG.innerHTML = drawParts(I, dt) + (fx ? fx(I, tt) : '') + water(I, P, now) + dustBath(I, P, now) + whipFx(I, P);
  }
  // Nov 10 whip spin (user: a cartoon spin faces you, whips round in a flash with a blur, lands facing you): sblur (0..1) = a sideways motion blur on
  // the whole creature + curved speed lines round it, only while the whip is on (built-in rigs: I.root gets a wrapper group with the blur filter)
  function whipFx(I, P) { const s = clamp(+P.sblur || 0, 0, 1.5), R = I.root || I.art; if (!R) return '';   // I.art = the generic rigs' creature group (v1110r: the dance whip spins run on them too)
    if (s > 0.02 && !I.mbW) { const svg = R.ownerSVGElement, NS = 'http://www.w3.org/2000/svg', df = svg.querySelector('defs') || svg.insertBefore(document.createElementNS(NS, 'defs'), svg.firstChild), f = document.createElementNS(NS, 'filter'), b = document.createElementNS(NS, 'feGaussianBlur'), W = document.createElementNS(NS, 'g');
      f.setAttribute('id', 'mbl' + I.u); f.setAttribute('x', '-40%'); f.setAttribute('y', '-10%'); f.setAttribute('width', '180%'); f.setAttribute('height', '120%'); b.setAttribute('in', 'SourceGraphic'); b.setAttribute('stdDeviation', '0 0'); f.appendChild(b); df.appendChild(f);
      R.parentNode.insertBefore(W, R); W.appendChild(R); I.mbW = W; I.mbF = b; }
    if (!I.mbW) return '';
    if (s <= 0.02) { if (I.mbOn) { I.mbW.removeAttribute('filter'); I.mbOn = false; } return ''; }
    I.mbF.setAttribute('stdDeviation', r2(s * 3.4) + ' 0'); if (!I.mbOn) { I.mbW.setAttribute('filter', 'url(#mbl' + I.u + ')'); I.mbOn = true; }
    return ''; }   // only the blur now: the purple side lines (user: not needed) and the white dashed swoosh ring round the lower body (user, v1110q: 'there is a
    // dashed stripe on him') were removed

  const FX = {
    sleep(I, t) { if (t < 2900 || t > 8150) return ''; let h = ''; const [x0, y0] = I.topW; for (let i = 0; i < 3; i++) { const u = (((t - 2900) / 2600) + i / 3) % 1; const x = x0 + 16 + u * 14 + Math.sin(u * TAU) * 2, y = y0 + 4 - u * 22;
      h += '<text x="' + r2(x) + '" y="' + r2(y) + '" font-family="Fredoka,sans-serif" font-weight="700" font-size="' + r2(5 + u * 5) + '" fill="#8f3cf2" stroke="#ffffff" stroke-width="0.6" paint-order="stroke" opacity="' + r2(Math.sin(Math.PI * u)) + '">z</text>'; } return h; },
    happy(I, t) { let h = ''; for (let i = 0; i < 8; i++) { const a = i / 8 * TAU + i * 0.7, u = ((t / 900) + i / 8) % 1, r = 36 * (0.55 + 0.45 * u); h += '<path d="' + star4(50 + Math.cos(a) * r, 52 + Math.sin(a) * r * 0.8, 1.2 + 2.2 * Math.sin(Math.PI * u)) + '" fill="' + (i % 2 ? '#fff3a0' : '#ffffff') + '" opacity="' + r2(Math.sin(Math.PI * u)) + '"/>'; } return h; },
    surprised(I, t) { const u = clamp((t - 300) / 700, 0, 1); if (u <= 0 || u >= 1) return ''; const [x0, y0] = I.topW, a = Math.sin(Math.PI * u); let h = '';
      [-34, 0, 34].forEach(d => { const r = d * D2R, s = 6 + u * 4, x1 = x0 + Math.sin(r) * s, y1 = y0 - 3 - Math.cos(r) * s, x2 = x0 + Math.sin(r) * (s + 5), y2 = y0 - 3 - Math.cos(r) * (s + 5); h += '<path d="M' + r2(x1) + ' ' + r2(y1) + ' L' + r2(x2) + ' ' + r2(y2) + '" stroke="#8f3cf2" stroke-width="1.6" stroke-linecap="round" opacity="' + r2(a) + '"/>'; }); return h; },
  };

  function render(I, P, now) {
    const D = I.D, R = I.RG, E = I.E, G = D.G, Hh = G - D.top, [HX, HY, HR] = D.head, SR = HR + 0.5, HRY = D.head[3] || HR, SRY = HRY + 0.5, KY = SRY / SR, [NX, NY] = D.neck;
    const yb = (P.spin + P.turn * 40) * D2R, yh = yb + ((P.hyaw || 0) + (P.twist || 0)) * 40 * D2R, ya = yb + (P.twist || 0) * 24 * D2R, cya = Math.cos(ya), sya = Math.sin(ya), ph = P.pitch * 22 * D2R;
    const cyb = Math.cos(yb), syb = Math.sin(yb), cyh = Math.cos(yh), syh = Math.sin(yh), cp = Math.cos(ph), sp = Math.sin(ph);
    const bnd = clamp(P.bend || 0, -32, 32) * D2R, HN = Math.max(8, G - D.neck[1] + 2); // bend reaches its full angle at the neck
    const MS = I.ms && I.ms.s > 0.004 ? I.ms : null, MAx = 50 + P.x, MAy = G - P.lift - (G - D.head[1]) * (1 - clamp(P.sq, -0.25, 0.45)); // motion stretch about the head centre
    const sq = clamp(P.sq, -0.25, 0.45), sy = 1 - sq, tr = P.tilt * D2R, ct = Math.cos(tr), stt = Math.sin(tr), dn = I.dent && I.dent.a > 0.01 ? I.dent : null;
    const glob = (x, y) => {
      if (dn) { const ddx = x - dn.x, ddy = y - dn.y, g = Math.exp(-(ddx * ddx + ddy * ddy) / 90); if (g > 0.01) { const vx = 50 - dn.x, vy = 60 - dn.y, L = Math.hypot(vx, vy) || 1; x += vx / L * dn.a * 4.5 * g; y += vy / L * dn.a * 4.5 * g; } }
      const u = clamp((G - y) / Hh, 0, 1), kx = 1 + sq * (0.45 + 0.6 * 4 * u * (1 - u)), X0 = (x - 50) * kx + P.lean * Math.pow(u, 1.5), h = (G - y) * sy; let X = X0, Y = -h;
      if (bnd) { const hn = HN * sy, c = bnd / hn; if (h <= hn) { const a = c * h; X = (1 - Math.cos(a)) / c + X0 * Math.cos(a); Y = -(Math.sin(a) / c - X0 * Math.sin(a)); }
        else { const dh = h - hn, cb = Math.cos(bnd), sb = Math.sin(bnd); X = (1 - cb) / c + X0 * cb + dh * sb; Y = -(sb / c - X0 * sb + dh * cb); } }
      let gx = 50 + X * ct - Y * stt + P.x, gy = G + X * stt + Y * ct - P.lift;
      if (MS) { const w = SM(u * 1.5), k = 1 + MS.s * w, dx = gx - MAx, dy = gy - MAy, al = (dx * MS.c + dy * MS.n) * k, pe = (-dx * MS.n + dy * MS.c) / k; gx = MAx + al * MS.c - pe * MS.n; gy = MAy + al * MS.n + pe * MS.c; }
      return [gx, gy]; };
    const hs = I.hs, hr = P.htilt * D2R, chr = Math.cos(hr), shr = Math.sin(hr), hyo = -P.pitch * 1.1;
    const headT = (x, y) => { x = 50 + (x - 50) * (1 + hs * 0.6); y = NY - (NY - y) * (1 - hs) + hyo; const dx = x - NX, dy = y - NY; return glob(NX + dx * chr - dy * shr, NY + dx * shr + dy * chr); };
    const sz = (dx, dy, zm) => { if (typeof zm === 'number') return zm; const q = 1 - (dx / SR) * (dx / SR) - (dy / SRY) * (dy / SRY), z = q > 0 ? SR * Math.sqrt(q) : 0; return zm === 'b' ? -z : z; };
    const sph = (x, y, zm) => { const dx = x - HX, dy = y - HY, z = sz(dx, dy, zm), x1 = dx * cyh + z * syh, z1 = -dx * syh + z * cyh; let X = x1, Y = dy * cp - z1 * sp * KY;
      if (zm === undefined && dy * sp / KY + z1 * cp < 0) { const nr = Math.hypot(X / SR, Y / SRY) || 1; X /= nr; Y /= nr; } return headT(HX + X, HY + Y); };
    const sphZ = (x, y, zm) => { const dx = x - HX, dy = y - HY, z = sz(dx, dy, zm), z1 = -dx * syh + z * cyh; return dy * sp / KY + z1 * cp; };
    const face = (x, y) => sph(x, y), face0 = face, wrapF = (x, y) => { const dx = x - HX, dy = y - HY, q = 1 - (dx / SR) * (dx / SR) - (dy / SRY) * (dy / SRY), w = SM((q - 0.04) / 0.32); if (w >= 1) return sph(x, y); const a = sph(x, y), b = headT(x, y); return [b[0] + (a[0] - b[0]) * w, b[1] + (a[1] - b[1]) * w]; }, vis = z => SM((z - 1.5) / 6), zc = (x, y, zm) => vis(sphZ(x, y, zm));
    const yw = ((yh / D2R) % 360 + 540) % 360 - 180, hY = clamp(yw, -85, 85) * D2R, hw = 1 - SM((Math.abs(yw) - 45) / 40), HP = Math.PI / 2;
    const hugF = (x, y) => { const dx = x - HX, dy = y - HY, z = sz(dx, dy), r = Math.hypot(dx, z), th = Math.atan2(dx, z), t2 = th < 0 ? -HP + (th + HP) * (HP + hY) / HP : hY + th * (HP - hY) / HP, z1 = r * Math.cos(t2), b = headT(HX + r * Math.sin(t2), HY + dy * cp - z1 * sp * KY); if (hw >= 1) return b; const a = wrapF(x, y); return [a[0] + (b[0] - a[0]) * hw, a[1] + (b[1] - a[1]) * hw]; };
    const byw = (x, y, z) => glob(50 + (x - 50) * cyb + z * syb, y), bywZ = (x, z) => -(x - 50) * syb + z * cyb;
    const set = (e, a, v) => e.setAttribute(a, v);

    // Nov 10 (user: the duckling doesn't look like a duck from the front / back / side): D.body3 = a real 3D body - an ellipsoid with its own
    // depth (c [x, y, z], r [width, height, depth], tilt = front end up, deg) that turns with the body, so a long duck body is round from the
    // front and long from the side. Rigs without it keep the old outline (the same from every side).
    if (D.body3) { const B3 = D.body3, [bx, by, bz] = B3.c, [brx, bry, brz] = B3.r, t3 = (B3.tilt || 0) * D2R, c3 = Math.cos(t3), s3 = Math.sin(t3);
      set(E.body, 'd', toD(ellAx(50 + (bx - 50) * cyb + bz * syb, by, [[brx * cyb, 0], [bry * s3 * syb, bry * c3], [brz * c3 * syb, -brz * s3]]), glob)); }
    else if (I.furB) set(E.body, 'd', 'M' + furPts(I.furB, yb).map(p => { const q = glob(p[0], p[1]); return r2(q[0]) + ' ' + r2(q[1]); }).join('L') + 'Z');
    else set(E.body, 'd', toD(R.body, glob));
    // Nov 10 (user, a side-view screenshot of Puddles: the head sat on the body like a snowman ball): D.neck3 = a fluffy neck - another turning
    // ellipsoid (c, r like body3) drawn over the top of the body, under the head, that fills the dip between the back of the head and the back
    // Nov 10 (Clover rebuilt as a classic bunny): D.lumps = extra turning ellipsoids on the body (a rabbit's two round haunches): each is drawn
    // just over the body while its centre is nearer to you than the body's centre, and behind it once it turns away
    if (E.lumps) { const dB = (D.body3 ? D.body3.c[2] : 0) * cyb; D.lumps.forEach((L, i) => { const [lx, ly, lz] = L.c, [lrx, lry, lrz] = L.r, el = E.lumps[i], fr = -(lx - 50) * syb + lz * cyb > dB;
        set(el, 'd', toD(ellAx(50 + (lx - 50) * cyb + lz * syb, ly, [[lrx * cyb, 0], [0, lry], [lrz * syb, 0]]), glob)); if (fr !== el.__fr) { el.__fr = fr; el.parentNode.insertBefore(el, fr ? E.body.nextSibling : E.body); } }); }
    if (E.neck3) { const N3 = D.neck3, [nx, ny, nz] = N3.c, [nrx, nry, nrz] = N3.r; set(E.neck3, 'd', toD(ellAx(50 + (nx - 50) * cyb + nz * syb, ny, [[nrx * cyb, 0], [0, nry], [nrz * syb, 0]]), glob)); }
    const pf = clamp(P.puff, -0.5, 1.2), hF = pf ? (x, y) => { const dy = y - 58, g = Math.exp(-dy * dy / 80); return headT(x + (x < 50 ? -1 : 1) * pf * 3.2 * g * clamp(Math.abs(x - 50) / 20, 0, 1), y); } : headT,
      skD = I.furH ? 'M' + furPts(I.furH, yh).map(p => { const q = hF(p[0], p[1]); return r2(q[0]) + ' ' + r2(q[1]); }).join('L') + 'Z' : toD(R.skull, hF);
    set(E.skull, 'd', skD); set(E.clip, 'd', skD);
    const rd = clamp(P.red, 0, 1), gr = clamp(P.green, 0, 1); set(E.tintR, 'd', skD); set(E.tintR, 'opacity', r2(rd * 0.34)); set(E.tintG, 'd', skD); set(E.tintG, 'opacity', r2(gr * 0.26));
    if (gr > 0.01) set(E.bodyG, 'd', E.body.getAttribute('d')); set(E.bodyG, 'opacity', r2(gr * 0.26));
    const keys = { body: 0, head: 1, collar: 1.5, prop: I.propZ != null ? I.propZ : 5 }; I.W = {};
    // feet: ellipsoids that keep their roundness from every side; pads are painted on the front
    R.feet.forEach((f, i) => { const st = clamp(+P.sit || 0, 0, 1), cy = f.y - (i ? P.footR : P.footL) + st * 4.6, z = (D.footZ != null ? D.footZ : 8) + st * 7, X = 50 + (f.x - 50) * (1 + st * 0.3) * cyb + z * syb, fsd = f.x < 50 ? 1 : -1;
      // Nov 10: D.web = flat webbed feet (a duck's): the top-view outline web.d (u across, v forward, heel at the origin) lies on the ground, toes
      // pointing forward and a little out (web.out deg), turns with the body and is seen from a little above (web.k = how much depth shows as height);
      // web.toes = the toe ridges (clipped to the foot); web.leg = a short leg from the heel up into the body
      if (D.web) { const W = D.web, kk = W.k || 0.32, ao = (W.out || 0) * D2R * (f.x < 50 ? -1 : 1), co = Math.cos(ao), so = Math.sin(ao), bx0 = 50 + (f.x - 50) * (1 + st * 0.3), d0 = -(bx0 - 50) * syb + z * cyb,
          mp = (u, v) => { const wx = bx0 + u * co + v * so, wz = z - u * so + v * co; return glob(50 + (wx - 50) * cyb + wz * syb, cy + kk * ((-(wx - 50) * syb + wz * cyb) - d0)); };
        const fd = toD(R.web, mp); set(E.feet[i].f, 'd', fd); set(E.feet[i].clip, 'd', fd); set(E.feet[i].p, 'd', R.webT ? toD(R.webT, mp) : '');
        if (E.feet[i].leg) { const L = W.leg, h0 = mp(0, 0.6), top = glob(X, Math.min(cy - 1, L.top + (cy - f.y) * 0.4)); set(E.feet[i].leg, 'd', 'M' + r2(h0[0]) + ' ' + r2(h0[1]) + ' L' + r2(top[0]) + ' ' + r2(top[1])); set(E.feet[i].leg, 'stroke-width', r2((L.w || 3) * Math.sqrt(sy))); }
        keys[i ? 'footR' : 'footL'] = d0 + (D.footK != null ? D.footK : -10); I.W[i ? 'footR' : 'footL'] = glob(X, cy); return; }
      const FS0 = D.footS || [9, 5.5, 8], FS = [FS0[0] * (1 + st * 0.06), FS0[1] * (1 + st * 0.75), FS0[2]], fd = toD(ellAx(X, cy, [[FS[0] * cyb, 0], [fsd * st * FS[1] * 0.28 * cyb, FS[1]], [FS[2] * syb, 0]]), glob); set(E.feet[i].f, 'd', fd); set(E.feet[i].clip, 'd', fd);
      const zp = z + 7.5; set(E.feet[i].p, 'd', (D.pads || [[0, 1, 5, 2.8]]).map(([dx, dy, rx, ry]) => toD(ellAx(50 + (f.x * (1 + st * 0.3) - st * 15 + dx - fsd * st * dy * 0.28 - 50) * cyb + zp * syb, cy + dy * (1 + st * 0.75) - st * 0.8, [[rx * cyb, 0], [0, ry * (1 + st * 0.6)]]), glob)).join(' ')); set(E.feet[i].p, 'opacity', r2(0.9 * SM(cyb * 3)));
      keys[i ? 'footR' : 'footL'] = -(f.x - 50) * syb + z * cyb + (D.footK != null ? D.footK : -10); I.W[i ? 'footR' : 'footL'] = glob(X, cy); });
    // ears: rounded cones whose roots sit on the curved head (mid-surface follows the sphere), bent from the root; parts buried in the head are dropped
    // Nov 10 (Tilly rebuilt as a real cockatiel): D.crest = crest feathers standing up from the top of the head in the head's MIDDLE plane (a real
    // crest sweeps up and back: its shape shows from the side, a slim spike from the front). Each feather: d in (u = back from the head's
    // centre plane, v = y), root [u, v], turn = deg it is swung out of the middle plane (two feathers turned + / - make the V seen from the
    // front), k = how much the ear channels raise it (NEGATIVE earL / earR = crest up, positive = laid back flat). Drawn behind the head.
    if (E.crest) D.crest.forEach((C, i) => { const a = ((P.earL || 0) + (P.earR || 0)) / 2 * (C.k != null ? C.k : 1) * D2R, ca = Math.cos(a), sa = Math.sin(a), [u0, v0] = C.root, tu = (C.turn || 0) * D2R, st = Math.sin(tu), ct = Math.cos(tu);
      set(E.crest[i], 'd', toD(R.crest[i], (u, v) => { const du = u - u0, dv = v - v0, U = u0 + du * ca - dv * sa, V = v0 + du * sa + dv * ca; return sph(HX + U * st, V, -U * ct); })); });
    R.ears.forEach((e, i) => { const a = (e.flop ? (e.side < 0 ? P.earL : -P.earR) * 0.9 : (e.side < 0 ? -P.earL : P.earR)) * D2R, [px, py] = e.pivot, S = e.S, pts = [], lim = SR * SR * 0.81;
      // lobe ears: a rounded ellipsoid hanging beside the head; tucked behind the head's rim until its side turns toward the camera
      if (e.lobe) { const [lx, ly, la, lb, lc, lz, lr] = e.lobe, ca = Math.cos(a), sa = Math.sin(a), vx = lx - px, vy = ly - py, cx = px + vx * ca - vy * sa, cy = py + vx * sa + vy * ca, rr = (lr || 0) * D2R + a, cr = Math.cos(rr), sr = Math.sin(rr);
        const pv = (x, y, z) => { const z1 = -x * syh + z * cyh; return [x * cyh + z * syh, y * cp - z1 * sp * KY]; }, C = pv(cx - HX, cy - HY, lz || 0);
        const ld = toD(ellAx(HX + C[0], HY + C[1], [pv(la * cr, la * sr, 0), pv(-lb * sr, lb * cr, 0), pv(0, 0, lc)]), headT); set(E.ears[i].o, 'd', ld); set(E.ears[i].clip, 'd', ld); set(E.ears[i].n, 'opacity', 0);
        const bk = r2(1 - SM((-e.side * syh - 0.2) / 0.35)); (E.ears[i].mk || []).forEach((m, j) => { set(m, 'd', j ? E.body.getAttribute('d') : skD); set(m, 'fill-opacity', bk); });
        keys[i ? 'earR' : 'earL'] = 2.5; I.W[i ? 'earR' : 'earL'] = headT(HX + C[0], HY + C[1] + lb * 0.8); return; }
      const zm = (x, y) => { const dx = x - HX, dy = y - HY, q = 1 - (dx / SR) * (dx / SR) - (dy / SRY) * (dy / SRY); return e.flop ? (q > 0 ? 0.12 * SR * Math.sqrt(q) : 1) : (q > 0 ? -0.35 * SR * Math.sqrt(q) : 0); };
      const bend = (x, y, w) => { const vx = x - px, vy = y - py, c = Math.cos(a * w), s = Math.sin(a * w); return [px + vx * c - vy * s, py + vx * s + vy * c]; };
      for (const q of S.secs) { const w = Math.pow(q.s, 1.3), c = Math.cos(a * w), s = Math.sin(a * w), nx = S.nx * c - S.ny * s, ny = S.nx * s + S.ny * c, [cx, cy] = bend(q.cx, q.cy, w);
        // ear root blend (Nov 8, user: the ear's outer bottom corner stuck out beside the head like it floated in the air): near the root, points that
        // fall outside the head outline are pulled back onto it (fully at the root, fading out by a third of the way up), so the outer edge runs into
        // the head's curve instead of ending in a spike beside it; standing ears only (flop ears hang beside the head on purpose)
        for (let k = 0; k < 14; k++) { const f = k / 14 * TAU, cf = Math.cos(f); let X = cx + nx * q.hw * cf, Y = cy + ny * q.hw * cf;
          if (!e.flop) { const wr = 1 - SM((q.s - 0.08) / 0.3); if (wr > 0) { const dx0 = X - HX, dy0 = Y - HY, rr = Math.hypot(dx0 / SR, dy0 / SRY); if (rr > 0.94) { const r1 = 0.94 + (rr - 0.94) * (1 - wr); X = HX + dx0 * r1 / rr; Y = HY + dy0 * r1 / rr; } } }
          const Z = zm(X, Y) - q.hd * 0.15 + q.hd * Math.sin(f), dx = X - HX, dy = Y - HY;
          if (e.flop || (dx / SR) * (dx / SR) + (dy / SRY) * (dy / SRY) + (Z / SR) * (Z / SR) >= 0.81) pts.push(sph(X, Y, Z)); } }
      const ed = closedD(hull(pts)); set(E.ears[i].o, 'd', ed); set(E.ears[i].clip, 'd', ed);
      const hdAt = s => { const L = S.secs; let j = 0; while (j < L.length - 2 && L[j + 1].s < s) j++; const A = L[j], B = L[j + 1] || A, u = B.s > A.s ? clamp((s - A.s) / (B.s - A.s), 0, 1) : 0; return lerp(A.hd, B.hd, u); };
      if (e.n) set(E.ears[i].n, 'd', toD(e.n, (x, y) => { const s = clamp(((x - px) * e.ux + (y - py) * e.uy) / S.amax, 0, 1), hd = hdAt(s), [bx, by] = bend(x, y, Math.pow(s, 1.3)); return sph(bx, by, zm(bx, by) - hd * 0.15 + hd * 0.85); }));
      set(E.ears[i].n, 'opacity', r2(0.8 * SM(cyh * cp * 3))); keys[i ? 'earR' : 'earL'] = e.behind ? -99 : sphZ(px, py, zm(px, py)) + (e.flop ? 2.5 : 1); /* e.behind (Nov 10, Bean's button ears): always behind the head - only what sticks out past it shows, so side-on the flat ear can't show as a dark spike on the head */ const tq = S.secs[S.secs.length - 1], tb = bend(tq.cx, tq.cy, 1); I.W[i ? 'earR' : 'earL'] = sph(tb[0], tb[1], 0); });
    // paws: ellipsoids that swing around the body and stay round
    // Nov 10 (user: 'his hands should look like the duck hands - he simply has a wing'): D.wing = real bird wings instead of round paws. Each wing
    // is a flat feathered shape (wing.d in its own plane: A = back along the body from the shoulder, B = down) hinged at the shoulder (wing.root
    // [out from the middle, y, z]) on the side of the body, bulging out a little (wing.bulge), folded down along the side at rest (wing.out deg)
    // and swung up / out round the shoulder by armL / armR (+ a raised hand target); wing.f = feather lines. Edge-on from the front (a thin
    // edge at each side), its full shape from the side, spread from the front when flapping. The paw tube is hidden.
    if (D.wing) R.arms.forEach((a, i) => { const WG = D.wing, sd = a.side, Lf = sd < 0, av = clamp((Lf ? P.armL : P.armR) - (Lf ? P.hLy : P.hRy) * 2, -40, 170), o = (WG.out || 0) * D2R, co = Math.cos(o), so = Math.sin(o),
        om = ((WG.rest || 0) + (90 - (WG.rest || 0)) * SM(av / 60)) * D2R, /* wing.rest (Nov 10, user: 'you don't see his wings when looking at the front'): held a little open at rest, out from the body */ lm = (av > 30 ? (av - 30) * 0.9 : av < 0 ? av * 0.4 : 0) * D2R, cw = Math.cos(om), sw = Math.sin(om), cl = Math.cos(lm), sl = Math.sin(lm), [ro, ry0, rz0] = WG.root, xr = 50 + sd * ro + (Lf ? P.hLx : -P.hRx) * 0.3,
        // folded: along the side, pointing back; as the arm channel rises the wing first OPENS (swings out round the shoulder until it points
        // sideways, its face to the front) then LIFTS (rolls up round the front-back axis) - a bird spreading and flapping its wings
        rot = (x0, y0, z0) => { const x1 = x0 * cw - sd * z0 * sw, z1 = sd * x0 * sw + z0 * cw; return [x1 * cl + sd * y0 * sl, -sd * x1 * sl + y0 * cl, z1]; },
        W3 = (A, B, bu) => { const [x, y, z] = rot(sd * (B * so + bu * co), B * co - bu * so, -A); return [xr + x, ry0 + y, rz0 + z]; },
        P3 = (A, B) => { const [x, y, z] = W3(A, B, (WG.bulge || 0) * Math.max(0, 1 - ((A - 10) / 12) ** 2 - ((B - 3) / 7) ** 2)); return glob(50 + (x - 50) * cya + z * sya, y); },
        Nv = rot(sd * co, -so, 0), nd = -Nv[0] * sya + Nv[2] * cya, C = W3(10, 3, 0), dC = -(C[0] - 50) * sya + C[2] * cya, bz0 = D.body3 ? D.body3.c[2] : 0;
      set(E.arms[i], 'd', toD(R.wing, P3)); if (E.wingF) { set(E.wingF[i], 'd', toD(R.wingF, P3)); set(E.wingF[i], 'opacity', r2(0.8 * SM(Math.abs(nd) * 3 - 0.3))); }
      set(E.armT[i], 'opacity', 0); keys[i ? 'armR' : 'armL'] = dC - bz0 * cya; I.W[Lf ? 'pawL' : 'pawR'] = P3(19, 4); });
    else R.arms.forEach((a, i) => { const Lf = a.side < 0, av = Lf ? P.armL : P.armR, base = Lf ? 20 : -20, wr = SM(Math.abs(av) / 45), ang = ((Lf ? P.armL : -P.armR) + (base - a.e[4]) * wr) * D2R, c = Math.cos(ang), s = Math.sin(ang), [px, py] = a.pivot, vx = a.e[0] - px, vy = a.e[1] - py;
      const [mhx, mhy] = I.mapHand ? I.mapHand(Lf ? P.hLx : -P.hRx, Lf ? P.hLy : P.hRy) : [Lf ? P.hLx : -P.hRx, Lf ? P.hLy : P.hRy], hy = mhy, hz = Lf ? P.hLz : P.hRz, cx = px + vx * c - vy * s + (Lf ? mhx : -mhx) + (I.ed || 0) * 0.35 + (I.mapHand ? a.side * 7 * wr : 0), cy = py + vx * s + vy * c + hy, z = (D.armZ != null ? D.armZ : 9) + hz + Math.max(0, -hy) * 0.25;
      const sx = px - a.side * 1.2, sy0 = py + 1.5, ddx = cx - sx, ddy = cy - sy0, len = Math.hypot(ddx, ddy);
      let r0 = a.e[4] * D2R + ang; if (len > 9) { const want = Math.atan2(ddy, ddx) - Math.PI / 2; let df = want - r0; df = ((df % TAU) + TAU * 1.5) % TAU - Math.PI; r0 += df * SM((len - 9) / 8); }
      const c0 = Math.cos(r0), s0 = Math.sin(r0), ax = [[a.e[2] * c0, a.e[2] * s0, 0], [-a.e[3] * s0, a.e[3] * c0, 0], [0, 0, D.armD || 6.5]].map(([x, y, zz]) => [x * cya + zz * sya, y]); // armD (Nov 10): a deeper ellipsoid = a duck's wing folded along its side
      const PX = 50 + (cx - 50) * cya + z * sya; set(E.arms[i], 'd', toD(ellAx(PX, cy, ax), glob)); keys[i ? 'armR' : 'armL'] = -(cx - 50) * sya + z * cya;
      const Sw = glob(50 + (sx - 50) * cya + 4 * sya, sy0), Pw = glob(PX, cy), mx = (Sw[0] + Pw[0]) / 2, my = (Sw[1] + Pw[1]) / 2, tx = Pw[0] - Sw[0], ty = Pw[1] - Sw[1], tl = Math.hypot(tx, ty) || 1; let nx = -ty / tl, ny = tx / tl; if (nx * a.side < 0) { nx = -nx; ny = -ny; }
      const bu = Math.max(0, tl - 10) * 0.18; set(E.armT[i], 'd', 'M' + r2(Sw[0]) + ' ' + r2(Sw[1]) + ' Q' + r2(mx + nx * bu) + ' ' + r2(my + ny * bu) + ' ' + r2(Pw[0]) + ' ' + r2(Pw[1]));
      set(E.armT[i], 'stroke-width', r2(9.5 * Math.sqrt((1 + sq * 0.4) * sy))); set(E.armT[i], 'opacity', r2(SM((len - 7.5) / 5))); I.W[Lf ? 'pawL' : 'pawR'] = Pw; });
    // tail: a tube whose spine curls back in depth, with a soft highlight along the top
    { const b = R.tail[0], wa = P.wag * D2R, cu = P.curl * 40 * D2R, dnk = I.key === 'mittens' || I.key === 'duchess' ? clamp((P.wd || 0) * 1.6, 0, 1) * 1.4 : 0; // Mittens (+ Duchess, Nov 13): in the water the tail lies down under the surface (the tip used to stick up beside the water ring)
      // 3D tails (D.tail3): the wag swishes the tail side to side round the upright axis through its root (plus a little lift), curl + the water bend
      // still bend it in the front plane; 2D tails keep the old front-plane wag
      const T3 = !!D.tail3, sp3 = R.tail.map(([x, y, s, z]) => { const th = (T3 ? wa * 0.3 : wa) * Math.pow(s, 1.2) - cu * Math.pow(s, 1.6) + dnk * Math.pow(s, 1.1), c = Math.cos(th), sn = Math.sin(th), vx = x - b[0], vy = y - b[1];
        let X = b[0] + vx * c - vy * sn, Y = b[1] + vx * sn + vy * c, Z = z; if (T3) { const ty = wa * (D.tailWag || 1.3) * Math.pow(s, 1.1), cw = Math.cos(ty), sw = Math.sin(ty), ux = X - b[0], uz = Z - b[3]; X = b[0] + ux * cw - uz * sw; Z = b[3] + ux * sw + uz * cw; }
        return byw(X, Y, Z); });
      const tw = (D.tailK || 7) * Math.sqrt((1 + sq * 0.5) * sy); set(E.tail, 'd', smoothD(sp3)); set(E.tail, 'stroke-width', r2(tw * (D.tailW || 7) / 7));
      set(E.tailH, 'd', smoothD(sp3.slice(0, -1).map(p => [p[0] - tw * 0.16, p[1] - tw * 0.18]))); set(E.tailH, 'stroke-width', r2(tw * (D.tailW || 7) / 7 * (D.tailHLW || 0.3)));
      if (E.tailF) { // tapered solid tail: offset the spine by a half-width that shrinks from the base to the tip, round the tip, shade the lower side
        // Nov 9 (user: the bottom of the tail where it joins the body needs an adjustment): the root flares a little wider over the first quarter (it grows out
        // of the body instead of starting as a stick) and ends in a rounded base that tucks into the body, so there is no flat cut / pointed corner there
        const [wb, wt] = D.tailTaper, n = sp3.length, hwAt = i => tw * (wb + (wt - wb) * Math.pow(i / (n - 1), 0.85)) * (1 + 0.14 * (1 - SM(i / (n - 1) / 0.3))), NR = sp3.map((p, i) => { const a = sp3[Math.max(0, i - 1)], b = sp3[Math.min(n - 1, i + 1)], dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1; return [-dy / l, dx / l]; });
        const dn = NR.reduce((q, v) => q + v[1], 0) >= 0 ? 1 : -1, L = sp3.map((p, i) => [p[0] - NR[i][0] * hwAt(i) * dn, p[1] - NR[i][1] * hwAt(i) * dn]), Rr = sp3.map((p, i) => [p[0] + NR[i][0] * hwAt(i) * dn, p[1] + NR[i][1] * hwAt(i) * dn]);
        const tp = sp3[n - 1], tq = sp3[n - 2], ux = tp[0] - tq[0], uy = tp[1] - tq[1], ul = Math.hypot(ux, uy) || 1, hT = hwAt(n - 1), cap = [0.25, 0.5, 0.75].map(f => { const t = f * Math.PI, nx = NR[n - 1][0] * dn, ny = NR[n - 1][1] * dn; return [tp[0] + (ux / ul * Math.sin(t) - nx * Math.cos(t)) * hT, tp[1] + (uy / ul * Math.sin(t) - ny * Math.cos(t)) * hT]; }); // round tip, from the left edge over the end to the right edge
        const s0 = sp3[0], s1 = sp3[2], vx0 = s1[0] - s0[0], vy0 = s1[1] - s0[1], vl0 = Math.hypot(vx0, vy0) || 1, h0 = hwAt(0), nx0 = NR[0][0] * dn, ny0 = NR[0][1] * dn,
          base = [0.2, 0.4, 0.6, 0.8].map(f => { const t = f * Math.PI; return [s0[0] + (nx0 * Math.cos(t) - vx0 / vl0 * Math.sin(t) * 0.55) * h0, s0[1] + (ny0 * Math.cos(t) - vy0 / vl0 * Math.sin(t) * 0.55) * h0]; }); // round base, from the right edge round the back to the left edge
        const fd = closedD(L.concat(cap, Rr.slice().reverse(), base)); set(E.tailF, 'd', fd); set(E.tailSC, 'd', fd); const mid = sp3.map((p, i) => [p[0] + NR[i][0] * hwAt(i) * dn * 0.25, p[1] + NR[i][1] * hwAt(i) * dn * 0.25]), Rx = sp3.map((p, i) => [p[0] + NR[i][0] * hwAt(i) * dn * 1.5, p[1] + NR[i][1] * hwAt(i) * dn * 1.5]);
        set(E.tailS, 'd', closedD(mid.slice(1, n - 1).concat(Rx.slice(1, n - 1).reverse()))); [E.tail, E.tailH].concat(E.tailT).forEach(e => e.style.display = 'none'); }
      if (E.tailT) { [[1.55, 6], [1.25, 10]].forEach(([k, n], i) => { set(E.tailT[i], 'd', smoothD(sp3.slice(0, n))); set(E.tailT[i], 'stroke-width', r2(tw * k)); });
        const r0 = sp3[0], r1 = sp3[2], dx = r1[0] - r0[0], dy = r1[1] - r0[1], dl = Math.hypot(dx, dy) || 1; set(E.tailB, 'cx', r2(r0[0] + dx / dl * tw * 0.3)); set(E.tailB, 'cy', r2(r0[1] + dy / dl * tw * 0.3)); set(E.tailB, 'rx', r2(tw * 1.12)); set(E.tailB, 'ry', r2(tw * 0.95)); set(E.tailB, 'opacity', r2(SM((-0.15 - cyb) / 0.5))); } // the fur blob only where his back (the root) faces you, never a smudge beside him
      if (D.tail) keys.tail = T3 ? bywZ(64, -22) : bywZ(66, -12); keys.collar = 1.5; if (D.mane) { keys.mane = -30; keys.maneF = 1.3; if (E.coat) keys.coatB = 0.6; } if (D.pup) keys.pup = 12; I.W.tail = sp3[sp3.length - 1]; }
    // face, painted on the head sphere
    const MZ = D.muzzle || [50, 57, 16, 10]; set(E.muzzle, 'd', toD(R.muzzle, face)); set(E.muzzle, 'opacity', r2(zc(MZ[0], MZ[1])));
    // cheek tufts (Waffles): fluffy cream rosettes that stick out past the sides of his face. Each sits on the head sphere at its spot, turns with the
    // head (narrower as it turns away), and moves behind the head (into the group before the skull) once it is on the far side
    if (E.tufts) D.tufts.forEach((T, i) => { const [cx, cy] = T.c, dx = cx - HX, dy = cy - HY, q = 1 - (dx / SR) * (dx / SR) - (dy / SRY) * (dy / SRY), z0 = SR * Math.sqrt(Math.max(0.02, q)), th0 = Math.atan2(dx, z0), thN = th0 * 0.55, th = th0 + yh,
        fxs = (0.64 + 0.36 * clamp(Math.cos(thN + yh), 0, 1)) / (0.64 + 0.36 * Math.cos(thN)) /* a fluffy ball: it narrows only a little as it turns away */, lf = 1 + (T.lift || 0) / SR, C0 = lf > 1 ? sph(HX + dx * lf, HY + dy * lf, z0 * lf) : sph(cx, cy) /* lift: the dome sits out from the head surface (Ribbit's eyes stick up from every side) */, hr2 = P.htilt * D2R * 0.6, c2 = Math.cos(hr2), s2 = Math.sin(hr2), ct = Math.cos(th), el = E.tufts[i], eb = E.tuftsB[i];
      // Nov 9 (user: a small problem with the white cheeks): it used to jump from in front of the head to behind it in one frame at about a 25 deg
      // turn (the whole puff vanished at once). Now a copy always sits behind the head (it keeps peeking out past the head's fluffy edge) and the copy
      // in front is hidden from the inside out by a soft mask round the head centre whose radius grows as the puff rolls round to the far side
      // (75 -> 105 deg): the side of the puff nearest his face slips behind the curve of his head first, like a real ball rolling round, no fading
      const TM = (x, y) => { const lx = (x - cx) * fxs, ly = y - cy; return [C0[0] + lx * c2 - ly * s2, C0[1] + lx * s2 + ly * c2]; }, td = toD(R.tufts[i], TM); set(el, 'd', td); set(eb, 'd', td); (I.tuftMap || (I.tuftMap = []))[i] = TM;
      if (E.tuftsW && E.tuftsW[i]) { const Wt = T.white; set(E.tuftsW[i], 'd', toD(ellS(cx + Wt[0], cy + Wt[1], Wt[2], Wt[2], 0, 10), TM)); }
      const Hc = headT(HX, HY), dC = Math.hypot(C0[0] - Hc[0], C0[1] - Hc[1]), tr = T.r || 9.5, f = SM((0.26 - ct) / 0.52), rho = (dC - tr) + f * 2 * tr, Rg = 60, ky = SRY / SR;
      set(el._g, 'cx', r2(Hc[0])); set(el._g, 'cy', r2(Hc[1])); set(el._g, 'gradientTransform', 'translate(' + r2(Hc[0]) + ' ' + r2(Hc[1]) + ') scale(1 ' + ky.toFixed(4) + ') translate(' + r2(-Hc[0]) + ' ' + r2(-Hc[1]) + ')');
      const o1 = f > 0.001 ? clamp(rho / Rg, 0, 1) : 0; el._s[0].setAttribute('offset', o1.toFixed(4)); el._s[1].setAttribute('offset', (f > 0.001 ? clamp((rho + 1.8) / Rg, 0, 1) : 0).toFixed(4));
      set(el, 'opacity', 1); set(eb, 'opacity', r2(SM((ct + 0.95) / 0.25))); });
    (E.fx || []).forEach((el, i) => { const fe = D.faceExtra[i], big = R.fxBig && R.fxBig[i]; set(el, 'd', toD(R.fx[i], fe.gloss ? headT : fe.hug ? hugF : big && !fe.sph ? wrapF : face)); set(el, 'opacity', r2((fe.op || 1) * (fe.gloss ? 1 : fe.hug ? zc(HX, R.fxC[i][1]) : big && !fe.sph ? 1 : zc(R.fxC[i][0], R.fxC[i][1])))); });
    set(E.stripes, 'd', toD(R.stripes, face)); set(E.stripes, 'opacity', r2(zc(50, 21)));
    set(E.back, 'd', toD(R.back, (x, y) => sph(x, y, 'b'))); set(E.back, 'opacity', r2(zc(D.backAt ? D.backAt[0] : 50, D.backAt ? D.backAt[1] : 23, 'b'))); // D.backAt (Nov 10, Mango's head sits low): the point whose facing fades the back-of-head marks
    // Nov 9 (user: Quill doesn't look like a hedgehog): D.snout = a real 3D pointed snout - an ellipsoid set into the face at c, pushed out by
    // 'out', its long axis pointing straight ahead; a dark nose ellipsoid sits on its tip. It turns + nods with the head (pv, same as the lobe ears),
    // sticks out past the head outline in profile, and fades away when the face turns from you.
    if (E.snout) { const S0 = D.snout, [la, lb, lc] = S0.r, dx = S0.c[0] - HX, dy = S0.c[1] - HY, q = 1 - (dx / SR) ** 2 - (dy / SRY) ** 2, z0 = (q > 0 ? SR * Math.sqrt(q) : 0) + (S0.out || 0);
      const pv = (x, y, z) => { const z1 = -x * syh + z * cyh; return [x * cyh + z * syh, y * cp - z1 * sp * KY]; }, dep = (x, y, z) => { const z1 = -x * syh + z * cyh; return y * sp / KY + z1 * cp; };
      const C = pv(dx, dy, z0), ux = S0.tilt || 0, A = [pv(la, 0, 0), pv(0, lb, 0), pv(0, lb * ux, lc)], sv = SM((dep(dx, dy, z0) + 5) / 4.5); // full in profile (it sticks out past the head), gone by ~105 deg (no floating nose dot)
      // Nov 10 (user: a small issue when he spins - the duck's bill went see-through and vanished while it still stuck out past his head):
      // snout.occlude = no fading - once the bill's root turns to the far side it is drawn BEHIND the skull at full strength, so the head
      // hides exactly the part it covers and the tip keeps poking out past the outline (a real bill), until the head covers it all
      let svv = sv; if (S0.occlude) { const bk = dep(dx, dy, z0) < 0; svv = 1; if (bk !== I.snBk) { I.snBk = bk; const els = [E.snoutJ, E.snout, E.snoutN, E.snoutH].filter(Boolean);
          const hg = E.skull.parentNode; if (bk && I.snAnchor === undefined) I.snAnchor = els[els.length - 1].nextSibling; els.forEach(el => hg.insertBefore(el, bk ? E.skull : I.snAnchor || null)); } }
      set(E.snout, 'd', toD(ellAx(HX + C[0], HY + C[1], A), headT)); set(E.snout, 'opacity', r2(svv));
      if (E.snoutJ) { const J = S0.jaw, [ja, jb, jc] = J.r, op = clamp(P.open, 0, 1), JC = pv(dx, dy + lb * 0.62 + op * (J.drop || 2.2), z0 - lc * 0.08 - op * 0.6), jt = (J.tilt || 0) + op * (J.tiltOpen || 0.5); // Nov 10: the lower bill (a duck's) - drops + tips down as the mouth opens
        set(E.snoutJ, 'd', toD(ellAx(HX + JC[0], HY + JC[1], [pv(ja, 0, 0), pv(0, jb, 0), pv(0, jc * jt, jc)]), headT)); set(E.snoutJ, 'opacity', r2(svv)); }
      const N0 = S0.nose || { r: [2.5, 2, 1.6] }, nz = z0 + lc * 0.9, ny = dy + lb * ux * 0.9 - lb * 0.12, NC = pv(dx, ny, nz), [na, nb, nc] = N0.r;
      set(E.snoutN, 'd', toD(ellAx(HX + NC[0], HY + NC[1], [pv(na, 0, 0), pv(0, nb, 0), pv(0, 0, nc)]), headT)); set(E.snoutN, 'opacity', r2(svv));
      const HC = pv(dx - na * 0.35, ny - nb * 0.4, nz + nc * 0.6); set(E.snoutH, 'd', toD(ellS(HX + HC[0], HY + HC[1], na * 0.32, nb * 0.26, 0, 6), headT)); set(E.snoutH, 'opacity', r2(S0.occlude ? (I.snBk ? 0 : 0.75 * SM((dep(dx, dy, z0) + 2) / 4)) : sv * 0.75)); I.W.nose = headT(HX + NC[0], HY + NC[1]); }
    const NS0 = D.nose || [50, 54, 2.6, 1.8]; set(E.nose, 'd', toD(R.nose, face)); set(E.nose, 'opacity', r2(zc(NS0[0], NS0[1]))); if (E.noseHL) { set(E.noseHL, 'd', toD(R.noseHL, face)); set(E.noseHL, 'opacity', r2(0.7 * zc(NS0[0], NS0[1]))); }
    const sm = clamp(P.smile, 0, 1);
    // cheek decals: follow the surface but never stretch past their front-view size (they only compress toward the rim)
    const decal = (F, cx, cy) => { const e = 0.5, k = 1 / (2 * e), C = F(cx, cy), a = F(cx + e, cy), b = F(cx - e, cy), c = F(cx, cy + e), d = F(cx, cy - e), h1 = headT(cx + e, cy), h2 = headT(cx - e, cy), h3 = headT(cx, cy + e), h4 = headT(cx, cy - e);
      const mul = (A, B) => [A[0] * B[0] + A[1] * B[2], A[0] * B[1] + A[1] * B[3], A[2] * B[0] + A[3] * B[2], A[2] * B[1] + A[3] * B[3]];
      const J = [(a[0] - b[0]) * k, (c[0] - d[0]) * k, (a[1] - b[1]) * k, (c[1] - d[1]) * k], Hm = [(h1[0] - h2[0]) * k, (h3[0] - h4[0]) * k, (h1[1] - h2[1]) * k, (h3[1] - h4[1]) * k], dt = Hm[0] * Hm[3] - Hm[1] * Hm[2] || 1;
      const m = mul([Hm[3] / dt, -Hm[1] / dt, -Hm[2] / dt, Hm[0] / dt], J), e1 = (m[0] + m[3]) / 2, f1 = (m[0] - m[3]) / 2, g1 = (m[2] + m[1]) / 2, k1 = (m[2] - m[1]) / 2, q1 = Math.hypot(e1, k1), q2 = Math.hypot(f1, g1), a1 = Math.atan2(g1, f1), a2 = Math.atan2(k1, e1), th = (a2 - a1) / 2, ph2 = (a2 + a1) / 2;
      const s1 = Math.min(q1 + q2, 1), s2 = Math.sign(q1 - q2) * Math.min(Math.abs(q1 - q2), 1), cf = Math.cos(ph2), sf = Math.sin(ph2), ct = Math.cos(th), st = Math.sin(th);
      const M = mul(Hm, mul([cf * s1, -sf * s2, sf * s1, cf * s2], [ct, -st, st, ct])); return (x, y) => { const u = x - cx, v = y - cy; return [C[0] + M[0] * u + M[1] * v, C[1] + M[2] * u + M[3] * v]; }; };
    const CK = D.cheekR || [4, 2.6]; (D.cheeks || [[33, 56], [67, 56]]).forEach(([cx, cy0], i) => { const cy = cy0 - sm * 0.6; const pk = 1 + Math.max(0, pf) * 0.35; set(E.cheeks[i], 'd', toD(ellS(cx + (i ? 1 : -1) * Math.max(0, pf) * 1.2, cy, CK[0] * (1 + sm * 0.08) * pk, CK[1] * pk, 0, 8), D.hugCheeks ? decal(hugF, cx, cy) : face)); set(E.cheeks[i], 'opacity', r2(clamp(0.5 + clamp(P.blush, 0, 1) * 0.45 + Math.max(0, pf) * 0.25 + rd * 0.3, 0, 1) * zc(D.hugCheeks ? HX : cx, cy))); });
    const ox = P.lx * 2.6, oy = P.ly * 2.2, ws = 1 + clamp(P.wide, 0, 1) * 0.22, h = clamp(P.hap, 0, 1), qz = clamp(P.sqz, 0, 1), cr = clamp(P.cross, 0, 1) * 1.8, ty = clamp(P.teary, 0, 1); I.eyeW = [];
    D.eyes.forEach(([ex, ey], i) => { const c = clamp(Math.max(P.close, i ? P.winkR : P.winkL), 0, 1) * (1 - SM(h * 1.6)), dir = i ? -1 : 1, cx = ex + ox + dir * cr, cy = ey + oy - h * 0.8, r = D.eyeR * ws, o = E.eyes[i], face = D.eyeDome && I.tuftMap && I.tuftMap[i] ? I.tuftMap[i] : face0;
      const sl = clamp(P.sl, 0, 1) * 0.32, out = i ? 1 : -1;
      const eD = toD(ellS(cx, cy, r, r, 0, 8), (x, y) => { const dy = y - cy, ce = clamp(c + sl * (0.5 + 0.5 * out * (x - cx) / r), 0, 1); let X = x, Y = cy + dy * (dy < 0 ? 1 - 2 * ce : 1 - 2 * h);
        if (qz > 0) { const cu = clamp((x - cx) / r, -1, 1), u = dir > 0 ? (cu + 1) / 2 : (1 - cu) / 2; X = lerp(X, cx + dir * (-0.8 + u * 1.4) * r, qz); Y = lerp(Y, cy + Math.sign(dy) * (1 - u) * 0.6 * r, qz); } return face(X, Y); }); set(o.e, 'd', eD); set(o.clip, 'd', eD);
      set(o.e, 'stroke-width', r2(1.3 * Math.max(SM((c - 0.5) / 0.45), SM((h - 0.5) / 0.45), SM(qz * 1.6))));
      const ha = (1 - SM((c - 0.4) / 0.25)) * (1 - SM((h - 0.12) / 0.3)) * (1 - SM(qz * 2.5)), hk = ws * (1 + ty * 0.4);
      const hd = c * r * 0.7; set(o.h1, 'd', toD(ellS(cx - 1.7 * ws, cy - 1.9 * ws + hd, 1.8 * hk, 1.8 * hk, 0, 6), face)); set(o.h2, 'd', toD(ellS(cx + 1.8 * ws, cy + 1.6 * ws, 0.7 * hk, 0.7 * hk, 0, 6), face));
      set(o.tp, 'd', toD(ellS(cx, cy + r * 0.8, r, r * 0.42, 0, 8), face)); set(o.tp, 'opacity', r2(ty * 0.85 * (1 - qz) * (1 - SM(c * 1.5))));
      set(o.h1, 'opacity', r2(ha)); set(o.h2, 'opacity', r2(ha * 0.9)); set(o.g, 'opacity', r2(zc(cx, cy))); I.eyeW.push(face(cx, cy)); I.W[i ? 'eyeR' : 'eyeL'] = face(cx, cy); });
    { const [MX0, MY0, MH0] = D.mouth || [50, 58, 3.5], mk0 = D.mouthD != null ? D.mouthD : MH0 / 3.5, /* mouthD (Nov 10): how deep the lip curve + open mouth go, apart from its width (a wide shallow grin, a beak line) */ op = clamp(P.open, 0, 1), fr = clamp(P.frown, 0, 1), mw = P.mw * (1 + sm * 0.12), hw = MH0 * mw * (1 + op * 0.3), y0 = MY0 + (-sm * 0.5 + fr * 1.3) * mk0, d = (2.3 * (1 + sm * 0.45) - fr * 4) * (1 - op * 0.55) * mk0, ym = MY0 - fr * 0.2 * mk0;
      const lip = D.mouthOne ? 'M' + r2(MX0 - hw) + ' ' + r2(y0) + ' Q' + r2(MX0) + ' ' + r2(y0 + d * 2.2) + ' ' + r2(MX0 + hw) + ' ' + r2(y0) // one wide grin (Ribbit) instead of the little 'w'
        : 'M' + r2(MX0 - hw) + ' ' + r2(y0) + ' Q' + r2(MX0 - hw / 2) + ' ' + r2(y0 + d) + ' ' + r2(MX0) + ' ' + r2(ym) + ' Q' + r2(MX0 + hw / 2) + ' ' + r2(ym + d) + ' ' + r2(MX0 + hw) + ' ' + r2(y0);
      const mv = zc(MX0, MY0); set(E.mouth, 'd', toD(parsePath(lip), face)); set(E.mouth, 'opacity', r2(mv));
      if (op > 0.03) { set(E.mopen, 'd', toD(parsePath(lip + ' C' + r2(MX0 + hw) + ' ' + r2(y0 + op * 8 * mk0) + ' ' + r2(MX0 - hw) + ' ' + r2(y0 + op * 8 * mk0) + ' ' + r2(MX0 - hw) + ' ' + r2(y0) + 'Z'), face));
        set(E.tongue, 'd', toD(ellS(MX0, y0 + op * 4.2 * mk0, 2.3 * op * mw * mk0, 1.4 * op * mk0, 0, 8), face)); set(E.mopen, 'opacity', r2(mv)); set(E.tongue, 'opacity', r2(mv)); }
      else { set(E.mopen, 'opacity', 0); set(E.tongue, 'opacity', 0); }
      const tg = clamp(P.tongue, 0, 1); set(E.tout, 'opacity', r2(mv * SM(tg * 3))); if (tg > 0.02) set(E.tout, 'd', toD(ellS(MX0, y0 + (1.3 + tg * 1.9) * mk0, 2.2 * (1 + tg * 0.15) * mk0, (1 + tg * 1.7) * mk0, 0, 8), face)); }
    { const M0 = D.mouth || [50, 58], N0 = D.nose || [50, 54]; I.W.mouth = face(M0[0], M0[1]); if (!D.snout) I.W.nose = face(N0[0], N0[1]); } I.W.body = glob(50, 78); I.W.belly = glob(50, 83); I.W.sideL = glob(30, 78); I.W.sideR = glob(70, 78);
    const wk = clamp(P.wsk || 0, 0, 1); // Nov 10: wsk folds the whiskers to ~half length and fans them apart (lying on her side in the dust they stood straight up like two antennae)
    const wFold = (w, sg) => { const r0 = w[0].p[0], a = 0.34 * wk * sg, ca = Math.cos(a), sa = Math.sin(a), k = 1 - 0.5 * wk; return w.map(g => g.c === 'Z' ? g : { c: g.c, p: g.p.map(([x, y]) => { const dx = (x - r0[0]) * k, dy = (y - r0[1]) * k; return [r0[0] + dx * ca - dy * sa, r0[1] + dx * sa + dy * ca]; }) }); };
    R.wh.forEach((w, i) => { const sd = i < 2 ? -1 : 1, far = 1 - SM((syh * sd - 0.06) / 0.22); set(E.wh[i], 'd', toD(wk > 0.01 ? wFold(w, i === 0 || i === 3 ? 1 : -1) : w, face)); set(E.wh[i], 'opacity', r2(0.8 * zc(i < 2 ? 36 : 64, 56) * far)); });
    // bellyTurn: the belly patch is painted on the body's front and turns with it, sliding to the rim and fading as it goes round the back
    // Nov 10 (Mango rebuilt as a real leopard gecko): D.spots3 = {fill, op, pts: [[around deg (0 = front, 90 = toward x+), up deg, r], ...]} -
    // spots painted on the body3 ellipsoid that turn (and tilt) with it; each is drawn only while its bit of the body faces you, squeezed
    // along the turn (a small circle on the surface seen at an angle), so the pattern wraps round the body from every side.
    if (E.spots3 && D.body3) { const [bx, by, bz] = D.body3.c, [brx, bry, brz] = D.body3.r, t3 = (D.body3.tilt || 0) * D2R, c3 = Math.cos(t3), s3 = Math.sin(t3); let dd = '';
      D.spots3.pts.forEach(([a, b, r]) => { const A = a * D2R, B = b * D2R, lx = brx * Math.cos(B) * Math.sin(A), ly = -bry * Math.sin(B), lz = brz * Math.cos(B) * Math.cos(A),
          X = lx, Y = ly * c3 - lz * s3, Z = ly * s3 + lz * c3, nlx = lx / (brx * brx), nly = ly / (bry * bry), nlz = lz / (brz * brz), NX = nlx, NY = nly * c3 - nlz * s3, NZ = nly * s3 + nlz * c3,
          NL = Math.hypot(NX, NY, NZ) || 1, fz = (-NX * syb + NZ * cyb) / NL; if (fz < 0.06) return;
        const sx = 50 + (bx + X - 50) * cyb + (bz + Z) * syb, sy = by + Y, nxs = NX * cyb + NZ * syb, nys = NY, nl = Math.hypot(nxs, nys) || 1, ux = nxs / nl, uy = nys / nl, mn = r * fz, pts = [];
        for (let k = 0; k < 10; k++) { const t = k / 10 * TAU, c = Math.cos(t), s = Math.sin(t); pts.push(glob(sx - uy * r * c + ux * mn * s, sy + ux * r * c + uy * mn * s)); }
        dd += closedD(pts); }); set(E.spots3, 'd', dd || 'M0 0'); }
    if (E.belly && D.body3 && D.belly) { const [bx, by, bz] = D.body3.c, [brx, bry, brz] = D.body3.r, bf = (x, y) => { const dx = x - bx, v = clamp((y - by) / bry, -0.98, 0.98), cw = Math.sqrt(1 - v * v), w = brx * cw, dd = brz * cw,
        q = 1 - (dx / w) * (dx / w), z = bz + dd * Math.sqrt(Math.max(0, q)), rim = Math.hypot(w * cyb, dd * syb), Xc = bz * syb; return glob(50 + clamp(dx * cyb + z * syb, Xc - rim, Xc + rim), y); };
      set(E.belly, 'd', closedD((R.bellyP || (R.bellyP = flat(R.belly, 4).slice(0, -1))).map(p => bf(p[0], p[1])))); set(E.belly, 'opacity', r2(SM((cyb - 0.15) / 0.45))); } // gone before side-on (on a long body the breast patch squeezes into a thin line at the front edge)
    else if (E.belly) { if (D.bellyTurn && D.belly) { const [BX, BY, BW, BH] = D.body, bf = (x, y) => { const dx = x - BX, v = clamp((y - BY) / BH, -1, 1), w = BW * Math.sqrt(1 - v * v), wc = BW * Math.sqrt(1 - v * v * 0.36), q = wc * wc - dx * dx, z = q > 0 ? Math.sqrt(q) : 0; let X = dx * cyb + z * syb; if (-dx * syb + z * cyb < 0) X = (X < 0 ? -1 : 1) * wc; return glob(BX + clamp(X, -w, w), y); };
      set(E.belly, 'd', closedD((R.bellyP || (R.bellyP = flat(R.belly, 4).slice(0, -1))).map(p => bf(p[0], p[1])))); set(E.belly, 'opacity', r2(SM((cyb + 0.3) / 0.4))); } else set(E.belly, 'd', toD(R.belly, glob)); }
    // Nov 9 (v2, user: the spines should be rounded around his body): ONE shell over his head + back (see coatBuild). Each point is projected with
    // the head (sph, rigid with the head like his eyes) and the body (byw), mixed by how much it belongs to the head - so the crown turns + nods with
    // his head, the back stays with his body, the neck twists smoothly between. Spines: lay = [out from the skin, back along it, droop]; they blend
    // to layUp (standing up) with 'br' = bristle: the bristle channel, being startled (wide), curling into a ball (head down + squashed).
    // Layers: facing you + head-owned -> over the head (maneF); facing you + body-owned -> over the body, under the head (coatB); the rest behind.
    if (E.coat) { const K = R.coat, ed = I.ed || 0, ld = I.ld || 0, p2s = q => r2(q[0]) + ' ' + r2(q[1]);
      const br = clamp(Math.max(P.bristle || 0, clamp(P.wide, 0, 1) * 0.85, SM((-P.pitch - 0.3) / 0.25) * SM((sq - 0.08) / 0.06)), 0, 1), LA = K.lay.map((v, j) => v + (K.layUp[j] - v) * br), gl = 1 + br * 0.22;
      const PJ = (p, w) => { const B = byw(p[0], p[1], p[2]), zb = bywZ(p[0], p[2]); if (w <= 0.002) return [B, zb]; const A = sph(p[0], p[1], p[2]), za = sphZ(p[0], p[1], p[2]); if (w >= 0.998) return [A, za];
        return [[B[0] + (A[0] - B[0]) * w, B[1] + (A[1] - B[1]) * w], zb + (za - zb) * w]; };
      const SM2 = K.mesh.map(row => row.map(v => { const [q, z] = PJ(v.p, v.w); return { q, z, w: v.w }; })); let mB = '', mBF = '', mHF = '';
      for (let r = 0; r < SM2.length - 1; r++) for (let i = 0; i < SM2[r].length; i++) { const i2 = (i + 1) % SM2[r].length, c = [SM2[r][i], SM2[r][i2], SM2[r + 1][i2], SM2[r + 1][i]], w = c.map(o => o.q); let ar = 0;
        for (let k = 0; k < 4; k++) { const A = w[k], B = w[(k + 1) % 4]; ar += A[0] * B[1] - B[0] * A[1]; } if (ar < 0) w.reverse(); const d = 'M' + w.map(p2s).join(' L') + 'Z';
        if ((c[0].z + c[1].z + c[2].z + c[3].z) / 4 > 0) { if ((c[0].w + c[1].w + c[2].w + c[3].w) / 4 > 0.5) mHF += d; else mBF += d; } else mB += d; }
      const LS = { back: [], bodyF: [], headF: [] }, cS = PJ([50, 62, 0], 0.5)[0], f = K.tipF;
      K.sp.forEach(s => { const ou = LA[0] + s.rim * (1 - br), dv = [0, 1, 2].map(j => s.n[j] * ou + s.e[j] * LA[1] + (j === 1 ? LA[2] : 0)), dl = Math.hypot(dv[0], dv[1], dv[2]) || 1, ln = s.len * gl / dl, tip = [0, 1, 2].map(j => s.r[j] + dv[j] * ln);
        const [A, zr] = PJ(s.r, s.o), [Tt, zt] = PJ(tip, s.o), k = s.len / 10;
        let vx = Tt[0] - A[0], vy = Tt[1] - A[1], L = Math.hypot(vx, vy); if (L < 1.2) { const ox = A[0] - cS[0], oy = A[1] - cS[1], ol = Math.hypot(ox, oy) || 1; vx = ox / ol * 1.2; vy = oy / ol * 1.2; L = 1.2; }
        const nx = -vy / L, ny = vx / L, w = s.w, wob = Math.sin(now / 520 + s.i * 1.7) * 0.2 * k, T = [A[0] + vx + ed * 0.3 * k + nx * wob, A[1] + vy - ld * 0.25 * k + ny * wob];
        const B1 = [A[0] + nx * w, A[1] + ny * w], B2 = [A[0] - nx * w, A[1] - ny * w], d = 'M' + p2s(B1) + ' L' + p2s(T) + ' L' + p2s(B2);
        // banded quill: the outer part is cream (real hedgehog spines are dark with pale tips - the frosted look)
        const dt = f ? 'M' + p2s([B1[0] + (T[0] - B1[0]) * f, B1[1] + (T[1] - B1[1]) * f]) + ' L' + p2s(T) + ' L' + p2s([B2[0] + (T[0] - B2[0]) * f, B2[1] + (T[1] - B2[1]) * f]) + 'Z' : '';
        LS[zr > -1.5 ? (s.o > 0.5 ? 'headF' : 'bodyF') : 'back'].push([(zr + zt) / 2, d, dt]); });
      const put = (pool, list) => { list.sort((a, b) => a[0] - b[0]); pool.forEach((el, i) => { const v = list[i], d = v ? v[1] : '', dt = v ? v[2] : ''; if (el._d !== d) { el._d = d; set(el.firstChild, 'd', d); } if (el._t !== dt) { el._t = dt; set(el.lastChild, 'd', dt); } }); };
      put(E.coat.back, LS.back); put(E.coat.bodyF, LS.bodyF); put(E.coat.headF, LS.headF);
      set(E.coat.mB, 'd', mB); set(E.coat.mBF, 'd', mBF); set(E.coat.mHF, 'd', mHF); }
    else if (E.hog) { const K = R.hog, ed = I.ed || 0, ld = I.ld || 0, grow = 1 + clamp(P.wide, 0, 1) * 0.2 + Math.max(0, sq) * 0.15, [BX0, BY0, BW0, BH0] = D.body, BZ = BW0 * 0.75;
      // Nov 9 (user: Quill's spikes don't move when he turns his head - only the ones on top of his head should): each quill point turns with a blend of
      // the body's yaw and the head's yaw + nod, by how much it belongs to the head (hw: high on the front of the shell = head, low or deep over the
      // back = body); the shell between them twists smoothly. Weights depend only on the rest pose, so they are worked out once.
      const hw = p => SM((60 - p[1]) / 18) * SM((p[2] + 26) / 14), dyw = yh - yb;
      const rot = (p, w) => { if (!w) return [50 + (p[0] - 50) * cyb + p[2] * syb, p[1], -(p[0] - 50) * syb + p[2] * cyb]; const a = yb + dyw * w, c = Math.cos(a), s = Math.sin(a); let x = 50 + (p[0] - 50) * c + p[2] * s, y = p[1], z = -(p[0] - 50) * s + p[2] * c;
        if (ph) { const pa = ph * w, cc = Math.cos(pa), ss = Math.sin(pa), dy = y - HY; y = HY + dy * cc - z * ss; z = dy * ss + z * cc; } return [x, y, z]; };
      const fac = (n, w) => { if (!w) return -n[0] * syb + n[2] * cyb; const a = yb + dyw * w; return -n[0] * Math.sin(a) + n[2] * Math.cos(a); }, p2s = q => r2(q[0]) + ' ' + r2(q[1]);
      if (!K.GW) { K.GW = K.G.map(row => row.map(hw)); K.sp.forEach(s => { s.hw = hw([(s.b1[0] + s.b2[0]) / 2, (s.b1[1] + s.b2[1]) / 2, (s.b1[2] + s.b2[2]) / 2]); }); }
      const W2 = (X, Y) => { const w = SM((NY - Y) / 12); if (w <= 0) return glob(X, Y); const a = headT(X, Y); if (w >= 1) return a; const b = glob(X, Y); return [b[0] + (a[0] - b[0]) * w, b[1] + (a[1] - b[1]) * w]; };
      const surf = (X, Y) => { const a = 1 - ((X - HX) / SR) ** 2 - ((Y - HY) / SRY) ** 2, b = 1 - ((X - BX0) / BW0) ** 2 - ((Y - BY0) / BH0) ** 2; return Math.max(a > 0 ? SR * Math.sqrt(a) : -1e9, b > 0 ? BZ * Math.sqrt(b) : -1e9); };
      // back shell: every quad goes behind the body; quads facing the camera and in front of head/body are drawn again on top
      const S = K.G.map((row, j) => row.map((p, i) => { const q = rot(p, K.GW[j][i]); return { q, w: W2(q[0], q[1]) }; })), na = K.A.length; let dB = '', dF = '';
      for (let j = 0; j < K.B.length - 1; j++) for (let i = 0; i < na; i++) { const i2 = (i + 1) % na, c = [S[j][i], S[j][i2], S[j + 1][i2], S[j + 1][i]], w = c.map(o => o.w); let ar = 0;
        for (let k = 0; k < 4; k++) { const a = w[k], b = w[(k + 1) % 4]; ar += a[0] * b[1] - b[0] * a[1]; } if (ar < 0) w.reverse(); const d = 'M' + w.map(p2s).join(' L') + 'Z'; dB += d;
        if (fac(K.QN[j][i], (K.GW[j][i] + K.GW[j + 1][(i + 1) % na]) / 2) > 0.02) { const mx = (c[0].q[0] + c[2].q[0]) / 2, my = (c[0].q[1] + c[2].q[1]) / 2, mz = (c[0].q[2] + c[1].q[2] + c[2].q[2] + c[3].q[2]) / 4; if (mz > surf(mx, my) - 1.5) dF += d; } }
      // spikes: away-facing ones sit under the shell, the rim ring on it, camera-facing ones in front of the body
      const LS = [[], [], []];
      K.sp.forEach(s => { const bc = [(s.b1[0] + s.b2[0]) / 2, (s.b1[1] + s.b2[1]) / 2, (s.b1[2] + s.b2[2]) / 2], t3 = [0, 1, 2].map(k => bc[k] + (s.t[k] - bc[k]) * grow);
        const q1 = rot(s.b1, s.hw), q2 = rot(s.b2, s.hw), qt = rot(t3, s.hw), f = fac(s.n, s.hw), k = s.len / 10, wob = Math.sin(now / 520 + s.i * 1.7) * 0.25 * k; let A1 = W2(q1[0], q1[1]), A2 = W2(q2[0], q2[1]); const At = W2(qt[0], qt[1]);
        { // seen edge-on a spike keeps some width (it is a cone, not a flat blade)
          const mx = (A1[0] + A2[0]) / 2, my = (A1[1] + A2[1]) / 2, ax = At[0] - mx, ay = At[1] - my, al = Math.hypot(ax, ay) || 1, px = -ay / al, py = ax / al, hx = (A2[0] - A1[0]) / 2, hy = (A2[1] - A1[1]) / 2, dp = hx * px + hy * py, need = s.w * 0.8 - Math.abs(dp);
          if (need > 0) { const sg = dp < 0 ? -1 : 1, nx = hx + px * need * sg, ny = hy + py * need * sg; A1 = [mx - nx, my - ny]; A2 = [mx + nx, my + ny]; } }
        const tx = A2[0] - A1[0], ty = A2[1] - A1[1], tl = Math.hypot(tx, ty) || 1, Tp = [At[0] + ed * 0.35 * k + tx / tl * wob, At[1] - ld * 0.3 * k + ty / tl * wob];
        const vis = Math.abs((Tp[0] - A1[0]) * ty - (Tp[1] - A1[1]) * tx) / (tl * Math.max(1, s.len * grow)), qc = [(q1[0] + q2[0]) / 2, (q1[1] + q2[1]) / 2, (q1[2] + q2[2]) / 2];
        const front = f > 0.1 && qc[2] > surf(qc[0], qc[1]) - 1.5; LS[front ? 2 : f < -0.01 ? 0 : 1].push([(qc[2] + qt[2]) / 2, 'M' + p2s(A1) + ' L' + p2s(Tp) + ' L' + p2s(A2), r2(SM(vis * 3))]); });
      const put = (pool, list) => { list.sort((a, b) => a[0] - b[0]); pool.forEach((el, i) => { const v = list[i]; const d = v ? v[1] : '', o = v ? v[2] : 1; if (el._d !== d) { el._d = d; set(el, 'd', d); } if (el._o !== o) { el._o = o; set(el, 'stroke-opacity', o); } }); };
      put(E.hog.pre, LS[0]); put(E.hog.post, LS[1]); put(E.hog.fs, LS[2]); set(E.hog.domeB, 'd', dB); set(E.hog.domeF, 'd', dF); }
    else if (E.mane && R.spk) { const K = R.spk, [cx0, cy0] = K.C, grow = 1 + clamp(P.wide, 0, 1) * 0.12, tris = [];
      const cY = Math.cos(yh), sY = Math.sin(yh), rot = v => { const x1 = v[0] * cY + v[2] * sY, z0 = -v[0] * sY + v[2] * cY; return [x1, v[1] * cp - z0 * sp, v[1] * sp + z0 * cp]; };
      for (const q of K.list) { const sT = Math.sin(q.th), ct2 = Math.cos(q.t), st2 = Math.sin(q.t), d = rot([sT * ct2, sT * st2, -Math.cos(q.th)]), tg = rot(q.th ? [-st2, ct2, 0] : [1, 0, 0]);
        const pr = (rr, ww) => headT(cx0 + d[0] * rr + tg[0] * ww, cy0 + d[1] * rr + tg[1] * ww);
        tris.push([d[2], pr(K.rb * 0.9, K.w), pr(K.rt * grow, 0), pr(K.rb * 0.9, -K.w)]); }
      tris.sort((a, b) => a[0] - b[0]); const pth = L => L.map(([z, a, b, c]) => 'M' + r2(a[0]) + ' ' + r2(a[1]) + ' L' + r2(b[0]) + ' ' + r2(b[1]) + ' L' + r2(c[0]) + ' ' + r2(c[1]) + 'Z').join(' ');
      set(E.mane, 'd', pth(tris.filter(t => t[0] < 0.18))); if (E.maneF) set(E.maneF, 'd', pth(tris.filter(t => t[0] >= 0.18))); }
    else if (E.mane) { const k = 1 + clamp(P.wide, 0, 1) * 0.1 + Math.max(0, sq) * 0.05, rp = 0.025 + clamp(P.wide, 0, 1) * 0.05, tt = now / 260, HC = D.mane.c || [HX, HY], T = D.mane.mode === 'body' ? glob : headT;
      set(E.mane, 'd', toD(R.mane, (x, y) => { const dx = x - HC[0], dy = y - HC[1], th = Math.atan2(dy, dx), m = k * (1 + rp * clamp(P.wide, 0, 1) * Math.sin(th * 7)); return T(HC[0] + dx * m, HC[1] + dy * m); })); }
    (E.hx || []).forEach((el, i) => set(el, 'd', toD(R.hx[i], wrapF)));
    if (E.crown.length) { const ang = ((P.earR - P.earL) * 0.25 - (I.ed || 0) * 2.5 + P.htilt * 0.3) * D2R, [bx, by] = D.crownBase, c = Math.cos(ang), sn = Math.sin(ang); E.crown.forEach((el, i) => set(el, 'd', toD(R.crown[i], (x, y) => { const vx = x - bx, vy = y - by; return sph(bx + vx * c - vy * sn, by + vx * sn + vy * c + Math.min(0, sq) * 2 + (D.crownDy || 0), D.crownZ != null ? D.crownZ : -3); }))); }
    if (E.pup.length) { const [pcx, pcy, pr] = D.pupC || [50, 71, 11], [BX, BY, BW, BH] = D.body, t = now / 1000; const pdt = I.pjT ? Math.min(0.05, (now - I.pjT) / 1000) : 0.016; I.pjT = now; I.pj = (I.pj || 0) + ((/dance/.test(I.cur.name) ? 1 : 0) - (I.pj || 0)) * Math.min(1, pdt * 5); const pj = SM(I.pj);
      const fb = pcy + pr - 1, td = Math.sin(t * 1.3) * 6 * (1 - pj) + Math.sin(t * Math.PI * 2) * 9 * pj + clamp(I.ed || 0, -4, 4) * 2, tl = td * D2R, ca = Math.cos(tl), sa = Math.sin(tl), sq = Math.sin(t * 2.6) * 0.03 * (1 - pj) - clamp(P.sq || 0, -0.3, 0.3) * 0.7 * pj + clamp(I.ld || 0, -6, 6) * 0.008, bl = (now % 3400) < 150 ? 0.12 : 1;
      E.pup.forEach((el, i) => { const h = D.pup[i], ea = h.ear ? -h.ear[2] * (5 + Math.sin(t * 2.6 - 0.9) * 5 * (1 - pj) + Math.abs(Math.sin(t * Math.PI * 2 - 0.6)) * 16 * pj + clamp(I.ld || 0, -6, 6) * 1.2) * D2R - td * 0.5 * D2R : 0, ec = Math.cos(ea), es = Math.sin(ea), cs = h.cheek ? 1 + pj * 0.18 : 1;
        if (h.shine || h.mouthLine || h.joy || h.cheek) set(el, 'opacity', r2(h.joy ? pj : h.cheek ? Math.min(1, (h.op || 1) + pj * 0.4) : (h.op || 1) * (1 - pj)));
        set(el, 'd', toD(R.pup[i], (x, y) => { if (h.eye) { const dy = y - h.eye[1]; y = h.eye[1] - pj * 0.5 + dy * (dy > 0 ? bl * (1 - 1.75 * pj) : bl); } if (h.joy) y = h.joy[1] + (y - h.joy[1]) * Math.max(0.05, pj); if (h.cheek) { x = h.cheek[0] + (x - h.cheek[0]) * cs; y = h.cheek[1] + (y - h.cheek[1]) * cs; }
          if (h.ear) { const p = x - h.ear[0], q = y - h.ear[1]; x = h.ear[0] + p * ec - q * es; y = h.ear[1] + p * es + q * ec; }
          const u0 = x - pcx, v0 = y - pcy, zp = Math.sqrt(Math.max(0, 1 - (u0 * u0 + v0 * v0) / (pr * pr))) * pr * 0.5; x = pcx + u0 * (1 - sq * 0.5); y = fb + (y - fb) * (1 + sq);
          const p = x - pcx, q = y - fb; x = pcx + p * ca - q * sa; y = fb + p * sa + q * ca;
          const dx = x - BX, v = clamp((y - BY) / BH, -1, 1), wc = BW * Math.sqrt(1 - v * v * 0.36), zb = Math.sqrt(Math.max(0, wc * wc - dx * dx)); return glob(BX + dx * cyb + (zb + zp) * syb, y); })); });
      set(I.pg.pup, 'opacity', r2(SM((cyb + 0.15) / 0.35))); }
    // 3D ring collar: the band is cut into 48 slices round the neck; only the slices on the near side are drawn (the far side is behind his neck), each
    // shaded by how much it faces the light, so it wraps round him from every side with no cut ends; a light top edge, a darker lower edge, stitching,
    // a soft shadow on his fur, a gold buckle at the back of the neck. The tag hangs from a small ring under the chin on a pendulum: it swings from
    // the collar's own movement (hops, turns, sways) and is drawn on its own, so it stays round when he is squished.
    if (E.cr) { set(E.cr.mk[0], 'd', E.body.getAttribute('d')); set(E.cr.mk[1], 'd', skD); const C = D.collar.ring, Q = E.cr, N = 48, W = C.w, ty = t => { const c = Math.cos(t); return C.ys + (c >= 0 ? C.af : C.ab) * c * c; }, keys2 = keys; keys2.collar = 1.5; // over the bottom of the head, like a collar round the neck (the ring sits outside the head sphere at this height)
      // Nov 9 (user: from the side the collar's end hung in the air): the band hugs the crease where his head meets his body - at every height its
      // radius is the width of his outline there (head sphere or body, whichever is wider) + a hair, so it narrows a little toward the bottom edge like
      // a collar sitting in the neck crease, and from the side it stays on him instead of sticking out over the gap between head and body
      const RB = D.body, rS = y => { const a = (y - HY) / SRY, b = (y - RB[1]) / RB[3]; return Math.max(a * a < 1 ? SR * Math.sqrt(1 - a * a) : 0, b * b < 1 ? RB[2] * Math.sqrt(1 - b * b) : 0) + (C.pad || 0.25); };
      const pt = (t, dy) => { const y = ty(t) + dy, r = rS(y); return byw(50 + r * Math.sin(t), y, r * Math.cos(t)); }, dep = t => -C.rx * Math.sin(t) * syb + C.rz * Math.cos(t) * cyb, P2 = q => r2(q[0]) + ' ' + r2(q[1]);
      const hx = c => [parseInt(c.slice(1, 3), 16), parseInt(c.slice(3, 5), 16), parseInt(c.slice(5, 7), 16)], cD = hx(C.dark), cB = hx(D.collar.fill), cL = hx(C.light), mix = (a, b, f) => a.map((v, i) => Math.round(v + (b[i] - v) * f));
      const vis = []; for (let i = 0; i < N; i++) { const t0 = i / N * TAU, t1 = (i + 1) / N * TAU, tm = (t0 + t1) / 2, seg = Q.segs[i];
        if (dep(tm) <= 0) { seg.setAttribute('d', ''); continue; } vis.push(i);
        const nx = Math.sin(tm) * cyb + Math.cos(tm) * syb, nz = -Math.sin(tm) * syb + Math.cos(tm) * cyb, lam = clamp((-0.42 * nx + 0.9 * nz) / 0.993, 0, 1), col = lam < 0.6 ? mix(cD, cB, lam / 0.6) : mix(cB, cL, (lam - 0.6) / 0.4 * 0.45), cs = 'rgb(' + col.join(',') + ')';
        set(seg, 'd', 'M' + [pt(t0, 0), pt(t1, 0), pt(t1, W), pt(t0, W)].map(P2).join('L') + 'Z'); set(seg, 'fill', cs); set(seg, 'stroke', cs); }
      // the visible run of slices may wrap past 0 (front view): rotate the list so it starts after the gap, then trace the edges along it
      let k0 = 0; for (let j = 0; j < vis.length; j++) if (vis[(j + vis.length - 1) % vis.length] !== (vis[j] + N - 1) % N) { k0 = j; break; } const run = vis.slice(k0).concat(vis.slice(0, k0));
      const line = dy => run.length ? 'M' + run.map(i => P2(pt(i / N * TAU, dy))).concat([P2(pt((run[run.length - 1] + 1) / N * TAU, dy))]).join('L') : '';
      set(Q.sh, 'd', line(W + 0.7)); set(Q.hl, 'd', line(0.45)); set(Q.lo, 'd', line(W - 0.35)); set(Q.st, 'd', line(W * 0.5));
      // buckle at the back of the neck (t = pi): a gold frame with the strap showing through and a prong
      { const db = dep(Math.PI), o = SM((db - 5) / 5), d1 = 2.4 / C.rz, d2 = 1.25 / C.rz, Bq = (a, y0, y1) => 'M' + [pt(Math.PI - a, y0), pt(Math.PI + a, y0), pt(Math.PI + a, y1), pt(Math.PI - a, y1)].map(P2).join('L') + 'Z';
        if (o > 0.01) { set(Q.bk, 'd', Bq(d1, -0.9, W + 0.9)); set(Q.bki, 'd', Bq(d2, 0.25, W - 0.25)); set(Q.bkp, 'd', 'M' + P2(pt(Math.PI - d2, W / 2)) + 'L' + P2(pt(Math.PI + d1 * 0.15, W / 2))); } else ['bk', 'bki', 'bkp'].forEach(k => set(Q[k], 'd', ''));
        ['bk', 'bki', 'bkp'].forEach(k => set(Q[k], 'opacity', r2(o))); }
      // tag: a pendulum hanging from a ring under the chin, driven by how the ring point moves (sideways acceleration swings it, a hop makes it bounce)
      { const T = D.tag, A = pt(0, W + 0.2), df = dep(0), o = SM((cyb + 0.06) / 0.16), G2 = I.tgp || (I.tgp = { a: 0, v: 0, x: A[0], y: A[1], vx: 0, vy: 0, t: now }), dt = clamp((now - G2.t) / 1000, 0.001, 0.05);
        const vx = (A[0] - G2.x) / dt, vy = (A[1] - G2.y) / dt, ax = clamp((vx - G2.vx) / dt, -4000, 4000), ay = clamp((vy - G2.vy) / dt, -4000, 4000), Lh = T.r + 1.7, g = 700;
        G2.v += (-(g - ay) / Lh * Math.sin(G2.a) - ax / Lh * Math.cos(G2.a) - 3.2 * G2.v) * dt; G2.a = clamp(G2.a + G2.v * dt, -0.95, 0.95); G2.x = A[0]; G2.y = A[1]; G2.vx = vx; G2.vy = vy; G2.t = now;
        const a = G2.a + Math.sin(now / 900) * 0.035, rc = [A[0] + Math.sin(a) * 1.1, A[1] + Math.cos(a) * 1.1], tc = [A[0] + Math.sin(a) * Lh, A[1] + Math.cos(a) * Lh], fx = 0.22 + 0.78 * Math.abs(cyb), rot = 'rotate(' + r2(-a / D2R) + ' ' + P2(tc).replace(' ', ' ') + ')';
        set(Q.rg, 'cx', r2(rc[0])); set(Q.rg, 'cy', r2(rc[1])); set(Q.rg, 'rx', r2(1.05 * fx)); set(Q.rg, 'ry', 1.05);
        [[Q.tg, 1], [Q.ti, 0.62]].forEach(([e, k]) => { set(e, 'cx', r2(tc[0])); set(e, 'cy', r2(tc[1])); set(e, 'rx', r2(T.r * k * fx)); set(e, 'ry', r2(T.r * k)); set(e, 'transform', rot); });
        set(Q.gl, 'cx', r2(tc[0] - T.r * 0.38 * fx)); set(Q.gl, 'cy', r2(tc[1] - T.r * 0.42)); set(Q.gl, 'rx', r2(T.r * 0.3 * fx)); set(Q.gl, 'ry', r2(T.r * 0.2)); set(Q.gl, 'transform', rot);
        [Q.rg, Q.tg, Q.ti].forEach(e => set(e, 'opacity', r2(o))); set(Q.gl, 'opacity', r2(o * 0.75)); } }
    if (E.collar) { if (D.collar.head) { const T = D.tag || { x: 50, y: 66 }, fa = (-(I.ed || 0) * 4 + P.lean * 1.5 + P.htilt * 0.4 - (I.ld || 0) * 1.2 + Math.sin(now / 520) * 2) * D2R, ca = Math.cos(fa), sa = Math.sin(fa), fl = 1 + Math.sin(now / 430) * 0.05 + clamp(I.ld || 0, -10, 10) * 0.012;
      set(E.collar, 'd', toD(R.collar, (x, y) => { const u = (x - T.x) * fl, v = y - T.y; return face(T.x + u * ca - v * sa, T.y + u * sa + v * ca); })); set(E.collar, 'opacity', r2(zc(T.x, T.y))); }
      else if (D.collar.body) { const T = D.tag, cz = D.collar.z || 14, fa = (Math.sin(now / 520) * 3 + P.lean * 1.5 - (I.ld || 0) * 1.2) * D2R, ca = Math.cos(fa), sa = Math.sin(fa), fl = 1 + Math.sin(now / 430) * 0.05; set(E.collar, 'd', toD(R.collar, (x, y) => { const u = (x - T.x) * fl, v = y - T.y; return byw(T.x + u * ca - v * sa, T.y + u * sa + v * ca, cz); })); set(E.collar, 'opacity', r2(SM(bywZ(T.x, cz) / 4))); }
      else set(E.collar, 'd', toD(R.collar, glob)); }
    if (E.tag && D.collar.head) { const T = D.tag; set(E.tag, 'd', toD(ellS(T.x, T.y, T.r, T.r, 0, 8), face)); set(E.tag, 'opacity', r2(zc(T.x, T.y))); }
    else if (E.tag && D.collar.body) { const T = D.tag, cz = (D.collar.z || 14) + 0.5; set(E.tag, 'd', toD(ellS(T.x, T.y, T.r, T.r, 0, 8), (x, y) => byw(x, y, cz))); set(E.tag, 'opacity', r2(SM(bywZ(T.x, cz) / 4))); }
    else if (E.tag) { const T = D.tag, sw = (-(I.ed || 0) * 6 + Math.sin(now / 360) * 4 + P.lean * 2 - (I.ld || 0) * 1.5) * D2R, cz = 13, tx = T.x + Math.sin(sw) * T.r * 1.2, ty = T.y + (Math.cos(sw) - 1) * T.r, X = 50 + (tx - 50) * cyb + cz * syb; set(E.tag, 'd', toD(ellS(X, ty, T.r * (0.75 + 0.25 * Math.abs(cyb)), T.r, 0, 8), glob)); set(E.tag, 'opacity', r2(SM((-(tx - 50) * syb + cz * cyb) / 4))); }
    I.topW = headT(50, D.top); I.W.head = I.topW;
    // ground shadow shrinks as she leaves the floor
    const gl = Math.max(0, P.lift); set(I.shadow, 'cx', r2(50 + P.x + P.lean * 0.15)); set(I.shadow, 'cy', r2(G + 0.6)); set(I.shadow, 'rx', r2(25 * (1 + sq * 0.45) * (1 - gl / 70))); set(I.shadow, 'ry', r2(3.6 * (1 - gl / 90))); set(I.shadow, 'opacity', r2(0.2 * (1 - gl / 50) * (1 - clamp(P.dbb || 0, 0, 1)))); // the dust-bath tub has its own shadow
    // depth sort parts as she turns
    const order = Object.keys(keys).sort((a, b) => keys[a] - keys[b]), os = order.join();
    if (os !== I.order) { I.order = os; order.forEach(k => I.root.appendChild(I.pg[k])); }
  }

  // hedgehog spine coat (Nov 9, v2 - user: the spines should be rounded around his body): ONE smooth shell (an ellipsoid hugging his head + back
  // from the crown to the rump, so there is no dip at the neck) carries an undercoat mesh + spines. Each point belongs partly to the head and partly
  // to the body (own: 1 above neckY, 0 below neckY + span, smooth between) - head-owned points turn + nod with the head, body-owned with the body, the
  // neck twists smoothly between. Bare where the head's hairline (headEdge, head coords) / the body's (bodyEdge, body coords) say so: face, throat,
  // belly. Relaxed spines lie flat along the shell pointing away from the face and overlap like roof tiles; they stand up when he is startled.
  function coatBuild(D) {
    const H = D.mane.hog.coat, [HX, HY, HR] = D.head, SR = HR + 0.5, SRY = (D.head[3] || HR) + 0.5, [BX, BY, BW, BH] = D.body, BZ = BW * 0.75;
    const SH = H.shell || { c: [50, 62], r: [27, 29, 26] }, [CX, CY] = SH.c, [RX, RY, RZ] = SH.r;
    const tab = (T, a) => { if (a <= T[0][0]) return T[0][1]; for (let i = 1; i < T.length; i++) if (a <= T[i][0]) return lerp(T[i - 1][1], T[i][1], (a - T[i - 1][0]) / (T[i][0] - T[i - 1][0])); return T[T.length - 1][1]; };
    const hA = H.headEdge || [[0, 27], [14, 34], [40, 52], [90, 84], [130, 104], [180, 98]], bA = H.bodyEdge || [[0, 55], [90, 82], [150, 112], [180, 135]];
    const dir = (pa, ph) => [Math.sin(pa) * Math.sin(ph), -Math.sin(pa) * Math.cos(ph), Math.cos(pa)], nrm = v => { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; };
    const S = (u, k) => [CX + RX * u[0] * k, CY + RY * u[1] * k, RZ * u[2] * k], NY = H.neckY || 66, NS = H.neckSpan || 12, own = p => SM((NY + NS - p[1]) / NS);
    const ang = (x, y, z) => { const l = Math.hypot(x, y, z) || 1; return [Math.acos(clamp(z / l, -1, 1)) / D2R, Math.abs(Math.atan2(x, -y)) / D2R]; };
    const cov = p => { const [hpa, hph] = ang((p[0] - HX) / SR, (p[1] - HY) / SRY, p[2] / SR), [bpa, bph] = ang((p[0] - BX) / BW, (p[1] - BY) / BH, p[2] / BZ), w = own(p);
      return w * (hpa - tab(hA, hph)) + (1 - w) * (bpa - tab(bA, bph)); }; // > 0 = under the spines (degrees past the hairline)
    const NA = H.meshA || 44, NR = H.meshR || 8, PM = Math.PI * 0.985, edge = Array.from({ length: NA }, (_, i) => { const ph = i / NA * TAU; let lo = 0, hi = PM;
      if (cov(S(dir(hi, ph), 1)) <= 0) return hi; if (cov(S(dir(lo, ph), 1)) > 0) return lo; for (let k = 0; k < 24; k++) { const m = (lo + hi) / 2; if (cov(S(dir(m, ph), 1)) > 0) hi = m; else lo = m; } return hi; });
    const zig = (H.zig != null ? H.zig : 7) * D2R, mesh = [];
    for (let r = 0; r <= NR; r++) { const row = []; for (let i = 0; i < NA; i++) { const ph = i / NA * TAU, a0 = edge[i], a = r === 0 ? Math.max(0, a0 - (i % 2 ? 0 : zig)) : a0 + (PM - a0) * r / NR, p = S(dir(a, ph), 0.985); row.push({ p, w: own(p) }); } mesh.push(row); }
    const hs = i => ((Math.sin(i * 12.9898 + 4.1) * 43758.5453) % 1 + 1) % 1, sp = [], n = H.n || 300, L0 = H.len || 9, W0 = H.w || 3.4;
    for (let i = 0; i < n; i++) { const y = 1 - 2 * (i + 0.5) / n, rr = Math.sqrt(1 - y * y), t = i * 2.399963, u = [rr * Math.cos(t), y, rr * Math.sin(t)], root = S(u, 1);
      if (cov(root) < 3) continue; const pa = Math.acos(clamp(u[2], -1, 1)), ph = Math.atan2(u[0], -u[1]);
      const nr = nrm([u[0] / RX, u[1] / RY, u[2] / RZ]), e = nrm([RX * Math.cos(pa) * Math.sin(ph), -RY * Math.cos(pa) * Math.cos(ph), -RZ * Math.sin(pa)]); // outward normal, and the way along the skin away from the face
      // rim: spines on his outline as seen from the front stand out a little more, so he keeps a spiky silhouette from the front
      sp.push({ r: root, n: nr, e, len: L0 * (0.8 + 0.4 * hs(i)), w: W0, o: own(root), rim: (H.rim != null ? H.rim : 0.45) * Math.pow(1 - Math.abs(nr[2]), 2), i: sp.length }); }
    const nH = sp.filter(q => q.o > 0.5).length;
    return { mesh, sp, nH, nB: sp.length - nH, tipF: H.tipF != null ? H.tipF : 0.62, lay: H.lay || [0.28, 1, 0.22], layUp: H.layUp || [1.25, 0.45, 0] }; }

  // hedgehog quills: the front spike ring becomes the rim of a shell over the back; extra rows cover the back and everything turns with the body
  function hogBuild(D) {
    const M = D.mane, H = M.hog, C = M.c, zc = H.z != null ? H.z : -5, RZ = H.rz || 30, P = flat(parsePath(M.d), 1), ring = P.slice(1, P.length - 2), c0 = P[0], c1 = P[P.length - 2];
    const ang = p => Math.atan2(p[0] - C[0], C[1] - p[1]), rad = p => Math.hypot(p[0] - C[0], p[1] - C[1]), V = ring.filter((p, i) => i % 2 === 0), T = ring.filter((p, i) => i % 2 === 1);
    const prof = L => { const A = L.map(p => [ang(p), rad(p)]).sort((a, b) => a[0] - b[0]); return a => { if (a <= A[0][0]) return A[0][1]; for (let i = 1; i < A.length; i++) if (a <= A[i][0]) return lerp(A[i - 1][1], A[i][1], (a - A[i - 1][0]) / (A[i][0] - A[i - 1][0])); return A[A.length - 1][1]; }; };
    const rim = [c0, ...V, c1], rv0 = prof(rim), rt = prof(T), aE = Math.abs(ang(c0)), yc = (c0[1] + c1[1]) / 2;
    const rv = a => Math.abs(a) <= aE ? rv0(a) : (yc - C[1]) / Math.max(0.3, -Math.cos(a));
    // the rim is not flat: it starts forward on the forehead and sweeps back toward the bottom, so the quill line curves in side view
    const zr = a => zc + (H.zt != null ? H.zt : 9) * Math.max(0, Math.cos(a)) - (H.zb != null ? H.zb : 6) * Math.max(0, -Math.cos(a));
    const sh = (a, b, r, rz) => [C[0] + r * Math.cos(b) * Math.sin(a), C[1] - r * Math.cos(b) * Math.cos(a), zc - rz * Math.sin(b) + (zr(a) - zc) * Math.cos(b)], nrm = (a, b) => [Math.cos(b) * Math.sin(a), -Math.cos(b) * Math.cos(a), -Math.sin(b)];
    const A = rim.map(ang).concat([1, 2, 3].map(k => aE + k * (TAU - 2 * aE) / 4)), B = [0, 18, 36, 54, 72, 90].map(d => d * D2R);
    const G = B.map(b => A.map(a => sh(a, b, rv(a), RZ))), QN = B.slice(0, -1).map((b, j) => A.map((a, i) => { let a2 = A[(i + 1) % A.length]; if (a2 < a) a2 += TAU; return nrm((a + a2) / 2, (b + B[j + 1]) / 2); }));
    const sp = [];
    for (let k = 0; k < T.length; k++) { const b1 = V[k], b2 = V[k + 1], t = T[k], len = rad(t) - (rad(b1) + rad(b2)) / 2;
      sp.push({ b1: [b1[0], b1[1], zr(ang(b1))], b2: [b2[0], b2[1], zr(ang(b2))], t: [t[0], t[1], zr(ang(t)) - len * ((H.tilt != null ? H.tilt : 1) + 0.8 * Math.max(0, Math.cos(ang(t))))], n: nrm(ang(t), 0), len, i: sp.length }); }
    (H.rows || []).forEach(([bd, m, am]) => { const b = bd * D2R, full = am >= 180, stp = (full ? 360 : 2 * am) / m * D2R, a0 = full ? -Math.PI : -am * D2R;
      for (let j = 0; j < m; j++) { const a = a0 + (j + 0.5) * stp, da = stp / 2, len = Math.max(2, (rt(a) - rv(a)) * (H.lk || 0.9));
        sp.push({ b1: sh(a - da, b, rv(a - da), RZ), b2: sh(a + da, b, rv(a + da), RZ), t: sh(a, b, rv(a) + len, RZ + len), n: nrm(a, b), len, i: sp.length }); } });
    return { A, B, G, QN, sp: sp.map(s => Object.assign(s, { w: Math.hypot(s.b2[0] - s.b1[0], s.b2[1] - s.b1[1], s.b2[2] - s.b1[2]) / 2 })) };
  }

  const ALL = new Set(); let raf = 0, last = 0, UID = 0;
  function loop(now) { raf = ALL.size ? requestAnimationFrame(loop) : 0; const dt = clamp((now - (last || now - 16)) / 1000, 0.001, 1 / 20); last = now; ALL.forEach(I => { try { tick(I, now, dt); } catch (e) { if (!I.err) { I.err = 1; console.error('RiveRig', e); } } }); }
  const kick = () => { if (!raf) { last = 0; raf = requestAnimationFrame(loop); } };
  setInterval(() => { const n = performance.now(); if (ALL.size && n - last > 80) { const r = raf; raf = 0; if (r) cancelAnimationFrame(r); loop(n); } }, 50);

  function mount(host, key, opts) {
    const ak0 = key; key = (window.SQ_ALIAS && window.SQ_ALIAS[key]) || key; // copies (squad-store SQ_ALIAS, e.g. Sea Turtle -> Shelly) wear the source creature's rig
    opts = opts || {}; const D = DEFS[key] || DEFS.mittens, u = 'rv' + (++UID), now = performance.now();
    const I = { D, onState: opts.onState, cur: { name: 'idle', t0: now }, prev: null, shots: [], press: false, spinOff: 0, ptr: null, gl: [0, 0], glAt: now + 1200, blinkT: -1e9, blinkAt: now + 1500, dbl: false, hs: 0, lastSpin: null, queue: [], ctr: {}, ctT: {}, emL: {}, parts: [], fidgets: opts.fidgets !== false,
      ak: ak0, flw: new Fol(1, 8), fex: new Fol(0, 22), fey: new Fol(0, 22), fhx: new Fol(0, 6.5), fhy: new Fol(0, 6.5), fp: new Fol(0, 14), fs: new Fol(0, 18, 0.55), fx: new Fol(0, 9, 0.6), fl: new Fol(0, 9, 0.6), fsp: new Fol(0, 7, 0.7) };
    const wrap = document.createElement('div'); wrap.style.cssText = 'position:relative;width:100%;height:100%;touch-action:none;cursor:pointer;user-select:none;-webkit-user-select:none;';
    host.innerHTML = ''; host.appendChild(wrap);
    const svg = mk('svg', { viewBox: '0 0 100 100', width: '100%', height: '100%' }); svg.style.cssText = 'position:absolute;inset:0;overflow:visible;pointer-events:none;'; wrap.appendChild(svg);
    if (!DEFS[key] && window.RiveGeneric) { I.generic = true; I.key = key; I.u = u; window.RiveGeneric.build(I, svg, key, { mk, ellS, toD, parsePath, ellAx, smoothD, SM, clamp, lerp, r2, D2R, TAU, Fol, earSec, flat, hull, closedD }); } else {
    I.key = key; const g = D.c.g; mk('defs', {}, svg).innerHTML =
      '<radialGradient id="g' + u + '" cx="38%" cy="30%" r="75%"><stop offset="0" stop-color="' + g[0] + '"/><stop offset="0.6" stop-color="' + g[1] + '"/><stop offset="1" stop-color="' + g[2] + '"/></radialGradient>' + (D.c.ge ? '<radialGradient id="ge' + u + '" cx="38%" cy="30%" r="75%"><stop offset="0" stop-color="' + D.c.ge[0] + '"/><stop offset="0.6" stop-color="' + D.c.ge[1] + '"/><stop offset="1" stop-color="' + D.c.ge[2] + '"/></radialGradient>' : '') +
      '<radialGradient id="ey' + u + '" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="#6b5470"/><stop offset="1" stop-color="#2a1a30"/></radialGradient>' +
      '<filter id="ft' + u + '" x="-15%" y="-15%" width="130%" height="130%">' + fabricFx() + '<feComposite in2="SourceGraphic" operator="in"/><feBlend in="SourceGraphic" mode="multiply"/></filter>' +
      '<clipPath id="fc' + u + '" clipPathUnits="userSpaceOnUse"><path/></clipPath>' + [0, 1].map(i => '<clipPath id="fk' + i + u + '" clipPathUnits="userSpaceOnUse"><path/></clipPath><clipPath id="ek' + i + u + '" clipPathUnits="userSpaceOnUse"><path/></clipPath>').join('') + '<clipPath id="ec0' + u + '" clipPathUnits="userSpaceOnUse"><path/></clipPath><clipPath id="ec1' + u + '" clipPathUnits="userSpaceOnUse"><path/></clipPath>';
    if (key !== 'mittens' && !D.mittensFrame && D.mouth && D.eyes && D.arms) { const pawY = (D.arms[0].e[1] + D.arms[1].e[1]) / 2, pawX = D.arms[0].e[0], MY = [17, 47, 58, 76, 95.5], CY = [D.top, D.eyes[0][1], D.mouth[1], pawY, D.G].map((v, i, a2) => i && v <= a2[i - 1] ? a2[i - 1] + 1 : v);
      const pl = (A, B, v) => { for (let i = 1; i < A.length; i++) if (v <= A[i] || i === A.length - 1) return B[i - 1] + (v - A[i - 1]) * (B[i] - B[i - 1]) / (A[i] - A[i - 1]); }, kx = Math.max(0.5, Math.abs(50 - pawX) / 18), mxk = Math.abs(50 - D.mouth[0]) < 1 ? 1 : 1;
      I.mapHand = (inX, hy) => [inX * kx, pl(MY, CY, 76 + hy) - pawY]; I.foodK = Math.max(0.05, Math.min(1.5, (pawY - D.mouth[1]) / 18)); I.toM = (x, y) => [50 + (x - D.head[0]) / D.head[2] * 29, pl(CY, MY, y)]; I.fromM = (x, y) => [D.head[0] + (x - 50) / 29 * D.head[2], pl(MY, CY, y)]; }
    const FUR = 'url(#g' + u + ')', CF = f => f ? String(f).replace(/url\(#([^)]+)\)/, 'url(#$1' + u + ')') : FUR;
    svg.querySelector('defs').insertAdjacentHTML('beforeend', '<radialGradient id="phz' + u + '"><stop offset="0" stop-color="#cbcac7" stop-opacity="0.85"/><stop offset="0.5" stop-color="#d3d2cf" stop-opacity="0.45"/><stop offset="1" stop-color="#d9d8d5" stop-opacity="0"/></radialGradient>'); // soft dust puff ('haze' particles, Nov 10)
    if (D.grads) svg.querySelector('defs').insertAdjacentHTML('beforeend', Object.keys(D.grads).map(id => '<radialGradient id="' + id + u + '" cx="38%" cy="30%" r="75%">' + D.grads[id].map(([o, c]) => '<stop offset="' + o + '" stop-color="' + c + '"/>').join('') + '</radialGradient>').join(''));
    if (D.mane && D.mane.hog) { const gs = (D.grads && D.grads[(String(D.mane.fill).match(/url\(#([^)]+)\)/) || [])[1]]) || [['0', '#a8794e'], ['1', '#5a3a22']]; svg.querySelector('defs').insertAdjacentHTML('beforeend', '<radialGradient id="hg' + u + '" gradientUnits="userSpaceOnUse" cx="40" cy="38" r="58">' + gs.map(([o, c]) => '<stop offset="' + o + '" stop-color="' + c + '"/>').join('') + '</radialGradient>'); }
    I.shadow = mk('ellipse', { fill: '#6a1b9a', opacity: 0.2 }, svg);
    I.root = mk('g', { filter: 'url(#ft' + u + ')' }, svg); I.pg = {}; I.u = u;
    ['mane', 'tail', 'footL', 'footR', 'body', 'coatB', 'earL', 'earR', 'head', 'maneF', 'collar', 'pup', 'prop', 'armL', 'armR'].forEach(k => I.pg[k] = mk('g', {}, I.root));
    const pg = I.pg, E = I.E = {};
    if (D.collar && D.collar.ring) { const g = pg.collar; svg.querySelector('defs').insertAdjacentHTML('beforeend',
        (M => '<radialGradient id="tg' + u + '" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="' + M[0] + '"/><stop offset="0.45" stop-color="' + M[1] + '"/><stop offset="1" stop-color="' + M[2] + '"/></radialGradient>')((D.tag && D.tag.metal) || ['#fff7c4', '#ffd84a', '#c9921c']) +
        '<linearGradient id="bg' + u + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0a8"/><stop offset="1" stop-color="#c9921c"/></linearGradient>' +
        '<filter id="csb' + u + '" x="-20%" y="-50%" width="140%" height="200%"><feGaussianBlur stdDeviation="0.7"/></filter>');
      E.cr = { sh: mk('path', { fill: 'none', stroke: '#6a3d14', 'stroke-width': 1.7, opacity: 0.22, 'stroke-linecap': 'round', filter: 'url(#csb' + u + ')' }, g), segs: Array.from({ length: 48 }, () => mk('path', { 'stroke-width': 0.3, 'stroke-linejoin': 'round' }, g)),
        hl: mk('path', { fill: 'none', stroke: D.collar.ring.light, 'stroke-width': 0.6, 'stroke-linecap': 'round', opacity: 0.85 }, g), lo: mk('path', { fill: 'none', stroke: D.collar.ring.dark, 'stroke-width': 0.55, 'stroke-linecap': 'round', opacity: 0.7 }, g),
        st: mk('path', { fill: 'none', stroke: D.collar.ring.stitch || '#ffd6df', 'stroke-width': 0.32, 'stroke-dasharray': '0.9 0.75', 'stroke-linecap': 'round', opacity: 0.8 }, g),
        bk: mk('path', { fill: 'url(#bg' + u + ')', stroke: '#a8761a', 'stroke-width': 0.35 }, g), bki: mk('path', { fill: D.collar.ring.dark }, g), bkp: mk('path', { fill: 'none', stroke: '#c9921c', 'stroke-width': 0.6, 'stroke-linecap': 'round' }, g),
        rg: mk('ellipse', { fill: 'none', stroke: (D.tag && D.tag.metal && D.tag.metal[3]) || '#c9921c', 'stroke-width': 0.55 }, g), tg: mk('ellipse', { fill: 'url(#tg' + u + ')', stroke: (D.tag && D.tag.metal && D.tag.metal[3]) || '#b07d14', 'stroke-width': 0.45 }, g),
        ti: mk('ellipse', { fill: 'none', stroke: (D.tag && D.tag.metal && D.tag.metal[2]) || '#e8b52c', 'stroke-width': 0.35 }, g), gl: mk('ellipse', { fill: '#ffffff', opacity: 0.75 }, g) };
      // Nov 9 (user: an issue with the collar when he turns): the band is masked to his outline (head + body, exactly - nothing of it shows over the background), so where it wraps round the
      // side of his neck it disappears flush with the outline instead of ending in a flat cut sticking out into the air
      svg.querySelector('defs').insertAdjacentHTML('beforeend', '<mask id="cm' + u + '" maskUnits="userSpaceOnUse" x="-60" y="-60" width="220" height="220"><path fill="#fff"/><path fill="#fff"/></mask>');
      const Q0 = E.cr, gb = mk('g', { mask: 'url(#cm' + u + ')' }, g); g.insertBefore(gb, g.firstChild); [Q0.sh].concat(Q0.segs, [Q0.hl, Q0.lo, Q0.st, Q0.bk, Q0.bki, Q0.bkp]).forEach(e => gb.appendChild(e)); Q0.mk = [...svg.querySelectorAll('#cm' + u + ' path')]; }
    else if (D.collar) { E.collar = mk('path', { fill: D.collar.fill }, pg.collar); E.tag = mk('path', { fill: D.tag.fill, stroke: '#ffffff', 'stroke-width': 0.8 }, pg.collar); }
    if (D.tail3) { svg.querySelector('defs').insertAdjacentHTML('beforeend', '<radialGradient id="tb' + u + '"><stop offset="0" stop-color="' + (D.c.tailB || '#eba264') + '"/><stop offset="0.55" stop-color="' + (D.c.tailB || '#eba264') + '" stop-opacity="0.85"/><stop offset="1" stop-color="' + (D.c.tailB || '#eba264') + '" stop-opacity="0"/></radialGradient>');
      E.tailT = [1.55, 1.25].map(() => mk('path', { fill: 'none', stroke: D.c.tail, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, pg.tail));
      if (D.tailTaper) { E.tailF = mk('path', { fill: D.c.tail }, pg.tail); svg.querySelector('defs').insertAdjacentHTML('beforeend', '<filter id="tsb' + u + '" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="0.9"/></filter>');
        E.tailS = mk('path', { fill: D.tailShade || '#c9873f', opacity: 0.38, filter: 'url(#tsb' + u + ')', 'clip-path': 'url(#tsc' + u + ')' }, pg.tail);
        svg.querySelector('defs').insertAdjacentHTML('beforeend', '<clipPath id="tsc' + u + '" clipPathUnits="userSpaceOnUse"><path/></clipPath>'); E.tailSC = svg.querySelector('#tsc' + u + ' path'); } }
    E.tail = mk('path', { fill: 'none', stroke: D.c.tail, 'stroke-width': 7, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, pg.tail);
    E.tailH = mk('path', { fill: 'none', stroke: D.c.tailHL || '#ffd2a3', 'stroke-width': 2, 'stroke-linecap': 'round', opacity: 0.55 }, pg.tail);
    if (D.tail3) E.tailB = mk('ellipse', { fill: 'url(#tb' + u + ')' }, pg.tail);
    E.feet = [0, 1].map(i => { const p = pg[i ? 'footR' : 'footL'], lg = D.web && D.web.leg ? mk('path', { fill: 'none', stroke: CF(D.web.leg.fill || D.c.foot), 'stroke-linecap': 'round' }, p) : null; return { leg: lg, f: mk('path', { fill: CF(D.c.foot) }, p), p: mk('path', { fill: D.c.pad, opacity: 0.9, 'clip-path': 'url(#fk' + i + u + ')' }, p), clip: svg.querySelector('#fk' + i + u + ' path') }; });
    if (D.mane) { const ma = { fill: CF(D.mane.fill), stroke: D.mane.stroke ? CF(D.mane.stroke) : 'none', 'stroke-width': D.mane.sw || 0, 'stroke-linejoin': 'round' }; E.mane = mk('path', ma, pg.mane); if (D.mane.spiky) E.maneF = mk('path', ma, pg.maneF); }
    E.body = mk('path', { fill: CF(D.c.body) }, pg.body); if (D.hideBody) E.body.style.display = 'none'; if (D.belly || D.bellyD) E.belly = mk('path', { fill: CF(D.bellyD ? D.bellyD.fill : D.belly[4]) }, pg.body); E.bodyG = mk('path', { fill: '#93b84a', opacity: 0 }, pg.body); if (D.neck3) { E.neck3 = mk('path', { fill: CF(D.neck3.fill || D.c.body) }, pg.body); pg.body.insertBefore(E.neck3, E.body); } if (D.lumps) E.lumps = D.lumps.map(L => mk('path', { fill: CF(L.fill || D.c.body) }, pg.body)); if (D.spots3 && D.body3) E.spots3 = mk('path', { fill: CF(D.spots3.fill || '#5a3a1e'), opacity: D.spots3.op != null ? D.spots3.op : 1 }, pg.body);
    E.ears = D.ears.map((ed, i) => { const p = pg[ed.side > 0 ? 'earR' : 'earL']; return { o: mk('path', { fill: ed.fill ? CF(ed.fill) : D.c.ge ? 'url(#ge' + u + ')' : FUR }, p), n: mk('path', { fill: CF(ed.innerFill || D.c.inner), opacity: ed.innerOp || 0.8, 'clip-path': 'url(#ek' + i + u + ')' }, p), clip: svg.querySelector('#ek' + i + u + ' path') }; });
    D.ears.forEach((ed, i) => { if (!ed.lobe) return; const m = mk('mask', { id: 'em' + i + u, maskUnits: 'userSpaceOnUse', x: -50, y: -50, width: 200, height: 200 }, svg.querySelector('defs')); mk('rect', { x: -50, y: -50, width: 200, height: 200, fill: '#fff' }, m); E.ears[i].mk = [mk('path', { fill: '#000' }, m), mk('path', { fill: '#000' }, m)]; pg[ed.side > 0 ? 'earR' : 'earL'].setAttribute('mask', 'url(#em' + i + u + ')'); });
    if (D.tufts) { E.tuftB = mk('g', {}, pg.head); }
    E.skull = mk('path', { fill: CF(D.c.head) }, pg.head); E.hx = (D.headExtra || []).map(h => mk('path', { fill: CF(h.fill), opacity: h.op || 1 }, pg.head));
    if (D.crest) E.crest = D.crest.map(c => mk('path', { fill: CF(c.fill || D.c.inner) }, pg.earL));   // Nov 10: a bird's crest feathers (D.crest)
    if (D.tufts) { E.tuftF = mk('g', {}, pg.head); E.tuftG = D.tufts.map(() => mk('g', {}, E.tuftF)); E.tufts = D.tufts.map((t, i) => mk('path', { fill: CF(t.fill || 'url(#wcr)') }, E.tuftG[i])); E.tuftsB = D.tufts.map(t => mk('path', { fill: CF(t.fill || 'url(#wcr)') }, E.tuftB));
      E.tuftsW = D.tufts.map((t, i) => t.white ? mk('path', { fill: t.white[3] || '#fffef4' }, E.tuftG[i]) : null); // eye domes (Ribbit): the white eyeball sits on the dome
      // per tuft: a soft radial mask centred on the head - inside radius rho the front copy is hidden (rho grows as the tuft rolls round to the far side)
      svg.querySelector('defs').insertAdjacentHTML('beforeend', D.tufts.map((t, i) => '<radialGradient id="tfg' + i + u + '" gradientUnits="userSpaceOnUse" cx="50" cy="46" r="60"><stop offset="0" stop-color="#000"/><stop offset="0" stop-color="#fff"/></radialGradient>'
        + '<mask id="tfm' + i + u + '" maskUnits="userSpaceOnUse" x="-60" y="-60" width="220" height="220"><rect x="-60" y="-60" width="220" height="220" fill="url(#tfg' + i + u + ')"/></mask>').join(''));
      E.tufts.forEach((el, i) => { E.tuftG[i].setAttribute('mask', 'url(#tfm' + i + u + ')'); const gq = svg.querySelector('#tfg' + i + u); el._g = gq; el._s = gq.querySelectorAll('stop'); }); }
    const face = mk('g', { 'clip-path': 'url(#fc' + u + ')' }, pg.head);
    E.muzzle = mk('path', { fill: D.c.muzzle }, face); (E.hx || []).forEach(el => face.insertBefore(el, E.muzzle)); E.tintR = mk('path', { fill: '#ff4040', opacity: 0 }, face); E.tintG = mk('path', { fill: '#93b84a', opacity: 0 }, face);
    E.stripes = mk('path', { fill: 'none', stroke: D.c.stripe, 'stroke-width': 2, 'stroke-linecap': 'round' }, face);
    E.back = mk('path', { fill: 'none', stroke: D.c.stripe, 'stroke-width': D.backW || 2.2, 'stroke-linecap': 'round' }, face); // D.backW (Nov 10): thinner back-of-head marks (a budgie's barring)
    E.fx = (D.faceExtra || []).map(fe => mk('path', fe.stroke && !fe.fill ? { fill: 'none', stroke: fe.stroke, 'stroke-width': fe.sw || 1, 'stroke-linecap': 'round' } : { fill: CF(fe.fill), stroke: fe.stroke || 'none', 'stroke-width': fe.sw || 0 }, face)); E.nose = mk('path', { fill: D.c.nose }, face); if (D.noseHL) E.noseHL = mk('path', { fill: '#ffffff' }, face);
    E.cheeks = [0, 1].map(() => mk('path', { fill: D.c.cheek }, face));
    E.eyes = [0, 1].map(i => { const gg = mk('g', {}, face), e = mk('path', { fill: 'url(#ey' + u + ')', stroke: '#2a1a30', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, gg), hg = mk('g', { 'clip-path': 'url(#ec' + i + u + ')' }, gg);
      return { g: gg, e, tp: mk('path', { fill: '#a8dcff', opacity: 0 }, hg), h1: mk('path', { fill: '#fff' }, hg), h2: mk('path', { fill: '#fff' }, hg), clip: svg.querySelector('#ec' + i + u + ' path') }; });
    if (D.eyeDome && E.tuftG) E.eyes.forEach((o, i) => { if (E.tuftG[i]) E.tuftG[i].appendChild(o.g); }); // Ribbit: each eye lives on its dome (turns + hides with it, not clipped to the head)
    E.mopen = mk('path', { fill: '#7a2a40' }, face); E.tongue = mk('path', { fill: '#ff8fa3' }, face);
    E.mouth = mk('path', { fill: 'none', stroke: D.c.mouth, 'stroke-width': 1.2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, face);
    E.tout = mk('path', { fill: '#ff7f9a', stroke: '#e0607e', 'stroke-width': 0.3, opacity: 0 }, face);
    const wg = mk('g', { fill: 'none', stroke: D.c.whisker, 'stroke-width': 0.9, 'stroke-linecap': 'round' }, pg.head); E.wh = D.whiskers.map(() => mk('path', {}, wg));
    if (D.snout) { if (D.snout.jaw) E.snoutJ = mk('path', { fill: CF(D.snout.jaw.fill || D.snout.fill || D.c.muzzle), stroke: D.snout.stroke || 'none', 'stroke-width': D.snout.sw || 0 }, pg.head); E.snout = mk('path', { fill: CF(D.snout.fill || D.c.muzzle), stroke: D.snout.stroke || 'none', 'stroke-width': D.snout.sw || 0 }, pg.head); E.snoutN = mk('path', { fill: CF((D.snout.nose && D.snout.nose.fill) || '#3a2340') }, pg.head); E.snoutH = mk('path', { fill: '#ffffff' }, pg.head); }
    E.armT = [0, 1].map(i => mk('path', { fill: 'none', stroke: D.c.arm, 'stroke-linecap': 'round', opacity: 0 }, pg[i ? 'armR' : 'armL']));
    E.arms = [0, 1].map(i => mk('path', { fill: CF(D.c.armFill) }, pg[i ? 'armR' : 'armL']));
    if (D.wing && D.wing.f) E.wingF = [0, 1].map(i => mk('path', { fill: 'none', stroke: D.wing.fc || '#e8b43a', 'stroke-width': D.wing.sw || 0.5, 'stroke-linecap': 'round' }, pg[i ? 'armR' : 'armL']));
    E.crown = (D.crown || []).map(h => mk('path', { fill: CF(h.fill), stroke: h.stroke || 'none', 'stroke-width': h.sw || 0 }, pg.head)); E.pup = (D.pup || []).map(h => mk('path', h.stroke && !h.fill ? { fill: 'none', stroke: h.stroke, 'stroke-width': h.sw || 1, 'stroke-linecap': 'round' } : { fill: CF(h.fill), opacity: h.op || 1 }, pg.pup));
    if (!D.tail) pg.tail.style.display = 'none'; if (D.muzzle === null) E.muzzle.style.display = 'none'; if (D.nose === null) E.nose.style.display = 'none';
    E.clip = svg.querySelector('#fc' + u + ' path');
    I.fxG = mk('g', {}, svg);
    const [t0, t1, t2, t3] = D.tail || [[50, 85], [50, 85], [50, 85], [50, 85]], cub = (a, b, c, d, t) => { const m = 1 - t; return m * m * m * a + 3 * m * m * t * b + 3 * m * t * t * c + t * t * t * d; };
    I.furH = D.headD ? furRing(D.headD, D.head) : null; I.furB = D.bodyD && !D.body3 ? furRing(D.bodyD, D.body) : null;   // fur ruffs that turn with him (see furRing)
    I.RG = { body: D.bodyD ? parsePath(D.bodyD) : ellS(D.body[0], D.body[1], D.body[2], D.body[3], 0, 16), skull: D.headD ? parsePath(D.headD) : ellS(D.head[0], D.head[1], D.head[2], D.head[3] || D.head[2], 0, 16), muzzle: D.muzzle === null ? [] : ellS(...(D.muzzle || [50, 57, 16, 10]).slice(0, 4), 0, 12), mane: D.mane ? parsePath(D.mane.d) : null, spk: D.mane && D.mane.spiky ? (() => { const C = D.mane.c || [D.head[0], D.head[1]], P = flat(parsePath(D.mane.d), 1).map(p => [Math.atan2(p[1] - C[1], p[0] - C[0]), Math.hypot(p[0] - C[0], p[1] - C[1])]); const avg = P.reduce((a, q) => a + q[1], 0) / P.length, tips = P.filter(q => q[1] > avg), vals = P.filter(q => q[1] <= avg);
        const rt = tips.reduce((a, q) => a + q[1], 0) / tips.length, rb = vals.reduce((a, q) => a + q[1], 0) / vals.length, n = tips.length, th = tips.map(q => q[0]), list = [];
        [[90, 1, 0], [58, 0.8, 0.5], [28, 0.45, 0]].forEach(([tq, f, off]) => { const m = Math.max(3, Math.round(n * f)); for (let k = 0; k < m; k++) list.push({ th: tq * D2R, t: (k + off) / m * TAU + (f === 1 ? th[0] : 0) }); }); list.push({ th: 0, t: 0 }); return { C, rt, rb, w: rb * Math.sin(Math.PI / n) * 1.05, list }; })() : null, hx: (D.headExtra || []).map(h => parsePath(h.d)), crown: (D.crown || []).map(h => parsePath(h.d)), pup: (D.pup || []).map(h => parsePath(h.d)), nose: D.nose === null ? [] : ellS(...(D.nose || [50, 54, 2.6, 1.8]), 0, 8), noseHL: D.noseHL ? ellS(...D.noseHL, 0, 6) : null, belly: D.bellyD ? parsePath(D.bellyD.d) : D.belly ? ellS(D.belly[0], D.belly[1], D.belly[2], D.belly[3], 0, 12) : null, collar: D.collar ? parsePath(D.collar.d) : null,
      fx: (D.faceExtra || []).map(fe => parsePath(fe.d)), fxBig: (D.faceExtra || []).map(fe => { const P = parsePath(fe.d).flatMap(g => g.p || []), hx = D.head[0], hy = D.head[1], rx = D.head[2], ry = D.head[3] || D.head[2]; return P.some(p => Math.pow((p[0] - hx) / rx, 2) + Math.pow((p[1] - hy) / ry, 2) > 0.8); }), fxC: (D.faceExtra || []).map(fe => { const P = parsePath(fe.d).flatMap(g => g.p || []); return [P.reduce((a, p) => a + p[0], 0) / P.length, P.reduce((a, p) => a + p[1], 0) / P.length]; }),
      feet: D.feet.map(([x, y]) => ({ x, y })), web: D.web ? parsePath(D.web.d) : null, wing: D.wing ? parsePath(D.wing.d) : null, wingF: D.wing && D.wing.f ? parsePath(D.wing.f) : null, webT: D.web && D.web.toes ? parsePath(D.web.toes) : null,
      ears: D.ears.map(e => { const vx = e.tip[0] - e.pivot[0], vy = e.tip[1] - e.pivot[1], len = Math.hypot(vx, vy), q = Object.assign({}, e, { o: parsePath(e.d), n: e.inner ? parsePath(e.inner) : null, ux: vx / len, uy: vy / len, len }); q.S = earSec(q, flat(q.o, 14)); return q; }),
      arms: D.arms.map(a => Object.assign({}, a, { s: ellS(a.e[0], a.e[1], a.e[2], a.e[3], a.e[4], 8) })),
      tail: D.tail3 && D.tail3.length > 4 ? (() => { const Q = D.tail3, m = Q.length - 1, n = m * 4, cr = (p0, p1, p2, p3, t) => 0.5 * (2 * p1 + (p2 - p0) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t + (3 * p1 - p0 - 3 * p2 + p3) * t * t * t); // Catmull-Rom through every point
          return Array.from({ length: n + 1 }, (_, i) => { const u = Math.min(i / 4, m - 1e-6), j = Math.floor(u), t = u - j, A = Q[Math.max(0, j - 1)], B = Q[j], C = Q[j + 1], E2 = Q[Math.min(m, j + 2)]; return [cr(A[0], B[0], C[0], E2[0], t), cr(A[1], B[1], C[1], E2[1], t), i / n, cr(A[2], B[2], C[2], E2[2], t)]; }); })()
        : D.tail3 ? Array.from({ length: 16 }, (_, i) => { const s = i / 15, [a, b, c, d] = D.tail3; return [cub(a[0], b[0], c[0], d[0], s), cub(a[1], b[1], c[1], d[1], s), s, cub(a[2], b[2], c[2], d[2], s)]; })
        : Array.from({ length: 14 }, (_, i) => { const s = i / 13, ins = (1 - SM(s / 0.18)) * 3.2; return [cub(t0[0], t1[0], t2[0], t3[0], s) - ins, cub(t0[1], t1[1], t2[1], t3[1], s) + ins * 0.25, s, -9 - 9 * Math.pow(s, 0.9)]; }),
      stripes: parsePath(D.stripes), back: parsePath(D.back), wh: D.whiskers.map(parsePath), tufts: (D.tufts || []).map(t => parsePath(t.d)), crest: (D.crest || []).map(c => parsePath(c.d)) };
    if (D.mane && D.mane.hog && D.mane.hog.coat) { const K = I.RG.coat = coatBuild(D), CT = D.mane.hog.coat, HF = 'url(#hg' + u + ')', sa = { fill: HF, stroke: CT.stroke || D.mane.stroke || 'none', 'stroke-width': CT.sw != null ? CT.sw : D.mane.sw || 0, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, pool = (par, n) => Array.from({ length: n }, () => { const g = mk('g', {}, par); mk('path', sa, g); mk('path', { fill: CT.tip || '#f3e2c4', stroke: 'none' }, g); return g; });
      E.mane.style.display = 'none'; const mB = mk('path', { fill: HF }, pg.mane), back = pool(pg.mane, K.sp.length), mBF = mk('path', { fill: HF }, pg.coatB), bodyF = pool(pg.coatB, K.nB), mHF = mk('path', { fill: HF }, pg.maneF), headF = pool(pg.maneF, K.nH);
      E.coat = { mB, back, mBF, bodyF, mHF, headF }; }
    else if (D.mane && D.mane.hog) { I.RG.hog = hogBuild(D); const n = I.RG.hog.sp.length, HF = 'url(#hg' + u + ')', sa = { fill: HF, stroke: D.mane.stroke || 'none', 'stroke-width': D.mane.sw || 0, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, pool = par => Array.from({ length: n }, () => mk('path', sa, par));
      E.mane.style.display = 'none'; E.hog = { pre: pool(pg.mane), domeB: mk('path', { fill: HF }, pg.mane), post: pool(pg.mane), domeF: mk('path', { fill: HF }, pg.maneF), fs: pool(pg.maneF) }; }
    }
    // touch: tap = poke, hold = squeeze, drag sideways = spin, hover = she watches
    const loc = e => { const r = wrap.getBoundingClientRect(); return { r, x: (e.clientX - r.left) / r.width * 100, y: (e.clientY - r.top) / r.height * 100 }; };
    wrap.addEventListener('pointermove', e => { const p = loc(e); I.ptr = { x: clamp((p.x - 50) / 42, -1, 1), y: clamp((p.y - 46) / 42, -1, 1) };
      if (I.down) { const dx = e.clientX - I.down.cx; if (!I.drag && !I.press && Math.abs(dx) > 10) { I.drag = true; clearTimeout(I.ht); I.spinTw = null; I.spin0 = I.spinOff; } if (I.drag) I.spinOff = I.spin0 + dx / p.r.width * 360; } });
    wrap.addEventListener('pointerleave', () => { I.ptr = null; });
    wrap.addEventListener('pointerdown', e => { try { wrap.setPointerCapture(e.pointerId); } catch (x) {} const p = loc(e), n = performance.now(); if (I.cur.name !== 'idle') setState(I, 'idle', n);
      I.down = { cx: e.clientX, x: p.x, y: p.y }; I.drag = false; clearTimeout(I.ht); I.ht = setTimeout(() => { if (I.down && !I.drag) { I.press = true; I.pressT = performance.now(); } }, 170); });
    const up = () => { if (!I.down) return; clearTimeout(I.ht); const n = performance.now();
      if (I.drag) I.spinTw = { from: I.spinOff, to: Math.round(I.spinOff / 360) * 360, t0: n, d: 650 };
      else if (I.press) { I.press = false; const RS = (I.key && REL[I.key]) || RELEASE; I.shots.push({ S: RS, t0: n }); (RS.em || []).forEach(m => emit(I, m[0], m[1], m[2])); } // own let-go reaction (pet-anims.js) else { const nm = 'poke_' + region(I, I.down.x, I.down.y); I.shots.push({ S: DENT, t0: n, x: I.down.x, y: I.down.y }); if (STATES[nm]) { const tp = STATES[nm].tap; STATES[nm].tap = null; setState(I, nm, n); STATES[nm].tap = tp; } else poke(I, I.down.x, I.down.y, n); }
      I.down = null; I.drag = false; };
    wrap.addEventListener('pointerup', up); wrap.addEventListener('pointercancel', up);
    ALL.add(I); kick(); tick(I, now, 0.016);
    return window.RiveRig._last = { play: n => setState(I, n, performance.now()), ext: o => { I.ext = o; }, destroy: () => { ALL.delete(I); clearTimeout(I.ht); host.innerHTML = ''; }, _pose: (name, t) => { const n = performance.now(); I.cur = { name, t0: n - t }; I.prev = null; I.shots = []; I.flw.v = 0; tick(I, n, 0.016); }, get state() { return I.cur.name; }, _I: I };
  }

  const FIDGETS = [], FIDK = {}, PRESS = {}, REL = {};
  window.RiveRig = { v: 2, HYAW, SOFT, DEFS, mount, STATES, REST, FIDGETS, FIDK, PRESS, REL, PRE, EZ, kv, r2, star4, clamp, SM, add: o => Object.assign(STATES, o), emit, tick1: I => { try { tick(I, performance.now(), 0.016); } catch (e) { if (!I.err) { I.err = 1; console.error('RiveRig', e); } } } };
})();
