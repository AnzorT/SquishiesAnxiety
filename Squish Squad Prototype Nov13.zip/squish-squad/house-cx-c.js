// Per-creature batch 7 extras (house-cx.js): ks = how he kicks a ball (foot / head = floaters / tail = sea tails / flip = flipper or arm swat / body = round foods bump it),
// pc = his prop colour (paddle, bean bag), hc = DJ headphone accent, mc = mic colour, fc2 = frisbee colour; RUN = extra channels while he runs / chases (HouseWalk.RUN).
window.HouseCreatures = window.HouseCreatures || []; window.HouseCreatures.push(function (H) {
  if (!H.cBuild) return; const { cBuild, PROF } = H;
  const GRP = { pet: ['#e8483c', '#45189a'], sky: ['#5ab4f0', '#2e86c8'], snack: ['#ffb84a', '#d95a2a'], ocean: ['#2ea3dc', '#1e6aa8'], fruit: ['#7cc35a', '#4f8f3a'], forest: ['#b07a42', '#5a7a2a'], dream: ['#b98ae8', '#7a3df0'], bakery: ['#ff8a4a', '#c96a2a'], spooky: ['#ff8a2a', '#5a2a8a'] };
  const OF = {}; [['pet', 'mittens biscuit prickle nibbles quill poppy duchess mamapaws truffle ribbit shelly'], ['sky', 'nimbo lumi bubbly twinkle zappi plip breeze dusty aurora'], ['snack', 'mallow bao dunkie frybo bunbun choco scoop boba chefbun'],
    ['ocean', 'pip jelli finn sealy puff seaturtle octo marina pearl'], ['fruit', 'pina avo berri lemmy kiwi melo peachy pitaya tutti'], ['forest', 'kiko teddy hoot leo panko acorn fawn moss sprout'],
    ['dream', 'hana boo pixie floof unibun gumdrop ember drako jinni'], ['bakery', 'cuppy chip twisty crois maca puddi mochi cakey sugarplum'], ['spooky', 'gourdy batty kernel hexie mumbles hocus countsquishula']].forEach(([g, s]) => s.split(' ').forEach(k => OF[k] = g));
  const KS = { head: 'nimbo lumi bubbly twinkle plip breeze zappi dusty jelli boo pixie jinni batty hocus', tail: 'finn sealy pearl marina aurora', flip: 'pip octo puff seaturtle', body: 'dunkie chip twisty mochi puddi maca cakey kernel gourdy melo choco' };
  const ks = {}; Object.keys(KS).forEach(s => KS[s].split(' ').forEach(k => ks[k] = s));
  const C = {
    mittens: { fc2: '#ffcc3a' }, biscuit: { fc2: '#e8483c' }, mamapaws: { fc2: '#5ab4f0' }, poppy: { fc2: '#ff8a4a' }, zappi: { fc2: '#ffd24a' }, lumi: { fc2: '#ffd24a' },
    frybo: { pc: '#e8483c' }, scoop: { mc: '#ff8fa8' }, chefbun: { mc: '#ffffff' }, sugarplum: { mc: '#ffd24a' }, jinni: { mc: '#ffd24a', hc: '#ffd24a' }, countsquishula: { mc: '#7a1e2a', hc: '#c0392b' },
  };
  const RUN = {
    biscuit: { wag: 22, tongue: 0.5 }, mamapaws: { wag: 18, tongue: 0.4 }, mittens: { curl: 0.3 }, poppy: { earL: -8, earR: 8 }, leo: { tsw: 0.6, mfl: 0.4 }, acorn: { tfl: 0.5 }, kiko: { tfl: 0.4 },
    drako: { wfl: 0.6, tsw: 0.4 }, pixie: { wfl: 1 }, ember: { cfl: 0.5, wfl: 0.6 }, hoot: { wfl: 0.6, tfl: 0.4 }, pitaya: { wfl: 0.6 }, tutti: { wfl: 0.8 }, unibun: { earL: 6, earR: -6 },
    floof: { fzz: 0.6 }, kiwi: { fzz: 0.6 }, berri: { stw: 0.6 }, frybo: { fw: 0.5 }, jelli: { sq: -0.05 }, pearl: { hsw: 0.5 }, jinni: { gwh: 0.5 }, boo: { flr: 0.6 }, hana: { flL: 0.3, flR: 0.3 },
    nimbo: { puff: 0.3 }, zappi: { zap: 0.6 }, dusty: { wfl: 0.8 }, batty: { armL: 30, armR: 30 }, marina: { tsw: 0.5 }, finn: { wag: 16 }, sealy: { wag: 14 }, aurora: { glow: 0.4 },
  };
  window.HouseWalkRUN = Object.assign(window.HouseWalkRUN || {}, RUN);
  // Waffles joined Nov 9 (his own rig is built now)
  Object.keys(PROF).forEach(k => { const g = GRP[OF[k]] || GRP.pet; cBuild(k, Object.assign({ ks: ks[k] || 'foot', pc: g[0], hc: g[0], mc: '#3b3b4a' }, C[k] || {})); });
});
