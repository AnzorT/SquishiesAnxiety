// Squad House v4: 3D furniture engine (lofted solids, 3/4 camera, CP-style outlines), catalog, room shells + door graph.
(function () {
  const A = 38 * Math.PI / 180, SA = Math.sin(A), CA = Math.cos(A);
  const LN = Math.hypot(0.5, 1, 0.55), LT = [-0.5 / LN, 1 / LN, 0.55 / LN];
  const VW = 852, FY0 = 128, FY1 = 334;
  // RM: per-room geometry set by the house (s = extra item/creature scale for big rooms, e = side-wall edge for round rooms)
  const RM = { s: 1, e: null };
  const SK = 0.7, sAt = y => (0.6 + 0.24 * (y - 128) / 228) * SK * RM.s;
  const edge0 = y => y < 262 ? 100 - (y - 100) * 100 / 162 : 0, edge = y => RM.e ? RM.e(y) : edge0(y);
  const f1 = v => Math.round(v * 10) / 10;
  const hx = h => { h = h.replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); const n = parseInt(h, 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const th = c => '#' + c.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
  const shade = (h, k) => { const c = hx(h); return th(k <= 1 ? c.map(v => v * k) : c.map(v => v + (255 - v) * (k - 1))); };
  const mix = (a, b, t) => { const x = hx(a), y = hx(b); return th(x.map((v, i) => v + (y[i] - v) * t)); };
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const pathOf = P => 'M' + P.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L') + 'Z';
  const circ = (cx, cy, r) => 'M' + f1(cx - r) + ' ' + f1(cy) + 'a' + r + ' ' + r + ' 0 1 0 ' + 2 * r + ' 0a' + r + ' ' + r + ' 0 1 0 ' + -2 * r + ' 0Z';
  const ell = (cx, cy, rx, ry) => 'M' + f1(cx - rx) + ' ' + f1(cy) + 'a' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(2 * rx) + ' 0a' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(-2 * rx) + ' 0Z';
  function hull(pts) {
    const p = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]); if (p.length < 3) return p;
    const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    const lo = [], up = [];
    for (const q of p) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); }
    for (let i = p.length - 1; i >= 0; i--) { const q = p[i]; while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], q) <= 0) up.pop(); up.push(q); }
    up.pop(); lo.pop(); return lo.concat(up);
  }
  function ring(o, ins, sc) {
    if (o.sh === 'poly') { let P = o.pts.map(p => [p[0] * sc, p[1] * sc]); let A = 0; for (let i = 0; i < P.length; i++) { const j = (i + 1) % P.length; A += P[i][0] * P[j][1] - P[j][0] * P[i][1]; } if (A < 0) P = P.reverse(); return P; }
    if (o.sh === 'arc') { const N = o.n || 6, out = [], inn = []; for (let i = 0; i <= N; i++) { const t = o.a0 + (o.a1 - o.a0) * i / N; out.push([o.a * Math.cos(t), o.b * Math.sin(t)]); inn.push([(o.a - o.th) * Math.cos(t), (o.b - o.th) * Math.sin(t)]); } return out.concat(inn.reverse()); }
    const Aa = Math.max(0.05, (o.a - ins) * sc), Bb = Math.max(0.05, (o.b - ins) * sc);
    if (o.sh === 'el') { const N = o.n || 16, r = []; for (let i = 0; i < N; i++) { const t = i / N * 2 * Math.PI; r.push([Aa * Math.cos(t), Bb * Math.sin(t)]); } return r; }
    const rt = Math.max(0, Math.min(((o.r || 0) - ins) * sc, Aa, Bb)), rb = Math.max(0, Math.min(((o.rb ?? o.r ?? 0) - ins) * sc, Aa, Bb)), S = 5, r = [];
    [[Aa, Bb, 0, rt], [-Aa, Bb, 90, rt], [-Aa, -Bb, 180, rb], [Aa, -Bb, 270, rb]].forEach(([cx, cy, a0, R]) => { const ox = cx - Math.sign(cx) * R, oy = cy - Math.sign(cy) * R; for (let i = 0; i <= S; i++) { const t = (a0 + 90 * i / S) * Math.PI / 180; r.push([ox + R * Math.cos(t), oy + R * Math.sin(t)]); } });
    return r;
  }
  function newell(q) { const n = [0, 0, 0]; for (let i = 0; i < q.length; i++) { const a = q[i], b = q[(i + 1) % q.length]; n[0] += (a[1] - b[1]) * (a[2] + b[2]); n[1] += (a[2] - b[2]) * (a[0] + b[0]); n[2] += (a[0] - b[0]) * (a[1] + b[1]); } return n; }
  const area2 = p => { let s = 0; for (let i = 0; i < p.length; i++) { const j = (i + 1) % p.length; s += p[i][0] * p[j][1] - p[j][0] * p[i][1]; } return Math.abs(s); };
  function solid(o) {
    const ax = o.ax || 'y', cu = o.c[0], cv = o.c[1], yw = o.yaw || 0, cy = Math.cos(yw), sy = Math.sin(yw);
    const m3 = (u, v, t) => ax === 'y' ? [cu + u * cy - v * sy, t, cv + u * sy + v * cy] : ax === 'z' ? [cu + u, cv + v, t] : [t, cv + v, cu + u];
    const n3 = (u, v) => ax === 'y' ? [u * cy - v * sy, 0, u * sy + v * cy] : ax === 'z' ? [u, v, 0] : [0, v, u];
    const axis = ax === 'y' ? [0, 1, 0] : ax === 'z' ? [0, 0, 1] : [1, 0, 0];
    const R2 = o.rings.map(r => ring(o, r[1] || 0, r[2] ?? 1)), R3 = o.rings.map((r, k) => R2[k].map(([u, v]) => m3(u, v, r[0]))), faces = [];
    for (let k = 0; k < R3.length - 1; k++) {
      const a = R3[k], b = R3[k + 1], a2 = R2[k], b2 = R2[k + 1], N = a.length;
      for (let i = 0; i < N; i++) {
        const j = (i + 1) % N, q = [a[i], a[j], b[j], b[i]]; let nn = newell(q); const L = Math.hypot(nn[0], nn[1], nn[2]); if (L < 0.02) continue;
        nn = nn.map(v => v / L);
        let du = a2[j][0] - a2[i][0], dv = a2[j][1] - a2[i][1]; if (Math.abs(du) + Math.abs(dv) < 1e-6) { du = b2[j][0] - b2[i][0]; dv = b2[j][1] - b2[i][1]; }
        if (dot(nn, n3(dv, -du)) < 0) nn = nn.map(v => -v);
        faces.push({ q, n: nn });
      }
    }
    if (area2(R2[0]) > 0.5) faces.push({ q: R3[0], n: axis.map(v => -v), cap: 1 });
    const l = R2.length - 1; if (area2(R2[l]) > 0.5) faces.push({ q: R3[l], n: axis, cap: 2 });
    return { faces, pts: [].concat(...R3), col: o.col, soft: o.soft, shine: o.shine, org: o.org, emit: o.emit, cv: (o.sh === 'arc' || o.cv === 0) ? 0 : 1, zb: o.zb || 0, noOut: o.noOut, part: o.part, op: o.op, mat: o.mat, scr: o.scr ? { r: o.r || 0 } : null, tex: o.tex, texTop: o.texTop, texO: o.texO };
  }
  const box = (x, y, z, w, h, d, col, o = {}) => solid(Object.assign({ ax: 'y', sh: 'rr', c: [x, z], a: w / 2, b: d / 2, r: 3, rings: o.bev ? [[y, 0], [y + h - o.bev, 0], [y + h, o.bev]] : [[y, 0], [y + h, 0]], col }, o));
  const cush = (x, y, z, w, h, d, col, o = {}) => { const e = Math.min(6, h * 0.45); return solid(Object.assign({ ax: 'y', sh: 'rr', c: [x, z], a: w / 2, b: d / 2, r: 10, rings: [[y, 2.5], [y + 2.5, 0], [y + h - e, 0], [y + h, e]], col, soft: 1 }, o)); };
  const cyl = (x, y, z, rx, h, col, o = {}) => solid(Object.assign({ ax: 'y', sh: 'el', c: [x, z], a: rx, b: o.rz ?? rx, n: 16, rings: o.rg ? o.rg.map(r => [y + r[0], r[1] || 0, r[2] ?? 1]) : [[y, 0], [y + h, o.top || 0]], col }, o));
  const ball = (x, y, z, r, col, o = {}) => { const sx = o.sx || 1, sy = o.sy || 1, sz = o.sz || 1, K = o.k || 5, rg = []; for (let i = 0; i <= K; i++) { const an = -Math.PI / 2 + Math.PI * i / K; rg.push([y + r * sy * (1 + Math.sin(an)), 0, Math.max(0.04, Math.cos(an))]); } return solid(Object.assign({ ax: 'y', sh: 'el', c: [x, z], a: r * sx, b: r * sz, n: 12, rings: rg, col, shine: 1 }, o)); };
  const slab = (x, y, z, w, h, d, col, o = {}) => solid(Object.assign({ ax: 'z', sh: 'rr', c: [x, y + h / 2], a: w / 2, b: h / 2, r: 8, rb: 0, rings: o.soft ? [[z - d / 2, 2], [z - d / 2 + 2, 0], [z + d / 2 - 2, 0], [z + d / 2, 2]] : [[z - d / 2, 0], [z + d / 2, 0]], col }, o));
  const slabX = (x, y, z, w, h, d, col, o = {}) => solid(Object.assign({ ax: 'x', sh: 'rr', c: [z, y + h / 2], a: d / 2, b: h / 2, r: 3, rings: [[x - w / 2, 0], [x + w / 2, 0]], col }, o));
  const arcW = (x, y, z, a, b, t, h, a0, a1, col, o = {}) => solid(Object.assign({ ax: 'y', sh: 'arc', c: [x, z], a, b, th: t, a0, a1, n: 5, rings: [[y, 0], [y + h, 0]], col }, o));
  const disc = (x, y, z, r, d, col, o = {}) => solid(Object.assign({ ax: 'z', sh: 'el', c: [x, y], a: r, b: r, n: 14, rings: [[z, 0], [z + d, o.top || 0]], col }, o));
  const pillowY = (x, y, z, w, hh, d, col, o = {}) => solid(Object.assign({ ax: 'y', sh: 'rr', c: [x, z], a: w / 2, b: d / 2, r: Math.min(w, d) * 0.3, rings: [[y, 4, 0.9], [y + 3, 0, 0.99], [y + hh - 5, 0, 1], [y + hh - 1.5, 4, 0.95], [y + hh, 9, 0.82]], col, soft: 1 }, o));
  const pillowZ = (x, y, z, w, hh, d, col, o = {}) => solid(Object.assign({ ax: 'z', sh: 'rr', c: [x, y + hh / 2], a: w / 2, b: hh / 2, r: Math.min(w, hh) * 0.4, rings: [[z - d / 2, 5, 0.86], [z - d / 2 + 3, 0, 0.97], [z + d / 2 - 3, 0, 1], [z + d / 2, 5, 0.88]], col, soft: 1 }, o));
  const legs4 = (x, z, h, col, r = 4, y = 0) => [cyl(-x, y, -z, r, h, col, { n: 8 }), cyl(x, y, -z, r, h, col, { n: 8 }), cyl(-x, y, z, r, h, col, { n: 8 }), cyl(x, y, z, r, h, col, { n: 8 })];
  const quarters = (fn) => [0, 1, 2, 3].map(q => fn(q * Math.PI / 2, (q + 1) * Math.PI / 2));

  const CR = '#fffaf1', WH = '#ffffff', MT = '#c9d3d8', GOLD = '#e2b14a', NEON = ['#4fe0d0', '#ffd66b', '#ff9d4a', '#a6f06a', '#6ac8ff', '#8f7bff'];
  const FAB = [{ a: '#84b6c9', b: '#e3946a' }, { a: '#e3946a', b: '#f2c255' }, { a: '#9fc684', b: '#fffaf1' }, { a: '#f2c255', b: '#84b6c9' }, { a: '#8f86c9', b: '#f2c255' }];
  const WOOD = [{ w: '#d49a60', a: '#84b6c9', b: '#e3946a' }, { w: '#a86b36', a: '#f2c255', b: '#9fc684' }, { w: '#f0d2a4', a: '#9fc684', b: '#84b6c9' }, { w: '#e3946a', a: '#fffaf1', b: '#f2c255' }];
  const pal = (D, ci) => { const c = (D.cols && D.cols[ci % D.cols.length]) || {}, a = mix(c.a || '#84b6c9', '#ffffff', 0.1), b = mix(c.b || '#f2c255', '#ffffff', 0.08), w = mix(c.w || '#d49a60', '#ffffff', 0.1); return { a, b, aL: mix(a, '#ffffff', 0.22), aD: shade(a, 0.86), bL: mix(b, '#ffffff', 0.2), bD: shade(b, 0.86), w, wD: shade(w, 0.76), wL: mix(w, '#ffffff', 0.25), m: c.m || '#d5dde2', c }; };


  const FS = 1.16, GR = (window.House3D && window.House3D._GR) || new Map();
  function gref(t, col, set) { const id = 'h' + t + col.replace('#', ''); if (!GR.has(id)) GR.set(id, t === 'S' ? { id, t, c0: shade(col, 1.1), c1: shade(col, 0.7) } : t === 'T' ? { id, t, c0: shade(col, 1.22), c1: shade(col, 1.02) } : { id, t, c0: shade(col, 1.3), c1: shade(col, 0.66) }); set.add(id); return 'url(#' + id + ')'; }
  // materials: every solid gets a texture (wood grain / fabric weave / brushed metal / paint speckle) + a volume pass (top-left light, darker edges)
  const HSL = h => { const [r, g, b] = hx(h).map(v => v / 255), mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn; let hh = 0, s = 0; if (d > 1e-6) { s = d / (1 - Math.abs(2 * l - 1)); hh = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; hh *= 60; if (hh < 0) hh += 360; } return [hh, s, l]; };
  const MATC = new Map();
  const matOf = S => { if (S.mat) return S.mat; if (S.emit) return 'emit'; if (S.shine || S.org) return 'gloss'; if (S.soft) return 'fab'; const c = S.col; if (MATC.has(c)) return MATC.get(c); const [h, s, l] = HSL(c); let m = 'paint';
    if (s < 0.18) m = l > 0.9 ? 'cer' : l > 0.3 ? 'metal' : 'paint';
    else if (h >= 38 && h <= 54 && s > 0.55 && l > 0.45 && l < 0.78) m = 'metal';
    else if (h >= 16 && h <= 42 && s >= 0.2 && s <= 0.62 && l >= 0.22 && l <= 0.72) m = 'wood';
    MATC.set(c, m); return m; };
  const TEX = { wood: 'url(#mtWood) none', fab: 'url(#mtFab) none', metal: 'url(#mtMetal) none', paint: 'url(#mtPaint) none' };
  const MDEFS = '<pattern id="mtWood" width="64" height="14" patternUnits="userSpaceOnUse"><path d="M0 3Q16 1.6 32 3.2T64 3M0 9.5Q20 11 40 9T64 9.8" fill="none" stroke="#3b1d08" stroke-opacity="0.2" stroke-width="0.8"/><path d="M6 6.2q10-1.4 22 0M38 12.2q8 1 18-0.4" fill="none" stroke="#3b1d08" stroke-opacity="0.13" stroke-width="0.6"/><path d="M0 5.6Q24 4.4 64 6" fill="none" stroke="#ffffff" stroke-opacity="0.13" stroke-width="0.7"/><ellipse cx="50" cy="6.4" rx="2.6" ry="1.2" fill="none" stroke="#3b1d08" stroke-opacity="0.2" stroke-width="0.6"/></pattern>'
    + '<pattern id="mtFab" width="5" height="5" patternUnits="userSpaceOnUse"><path d="M0 1.2H5M0 3.7H5" stroke="#000000" stroke-opacity="0.06" stroke-width="1"/><path d="M1.2 0V5M3.7 0V5" stroke="#ffffff" stroke-opacity="0.08" stroke-width="0.9"/></pattern>'
    + '<pattern id="mtMetal" width="46" height="5" patternUnits="userSpaceOnUse"><path d="M0 1H30M8 3.4H46" stroke="#ffffff" stroke-opacity="0.24" stroke-width="0.6"/><path d="M14 2.2H40M0 4.4H12" stroke="#000000" stroke-opacity="0.08" stroke-width="0.5"/></pattern>'
    + '<pattern id="mtPaint" width="14" height="14" patternUnits="userSpaceOnUse"><circle cx="3" cy="4" r="0.7" fill="#000000" fill-opacity="0.08"/><circle cx="10" cy="2" r="0.5" fill="#ffffff" fill-opacity="0.14"/><circle cx="8" cy="10" r="0.8" fill="#000000" fill-opacity="0.06"/><circle cx="12.5" cy="12" r="0.5" fill="#ffffff" fill-opacity="0.12"/><circle cx="1.5" cy="11" r="0.6" fill="#000000" fill-opacity="0.07"/></pattern>'
    + '<radialGradient id="mVol" cx="34%" cy="26%" r="82%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.26"/><stop offset="0.38" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.7" stop-color="#1a0c04" stop-opacity="0"/><stop offset="1" stop-color="#1a0c04" stop-opacity="0.3"/></radialGradient>';
  const grads = ids => { const lin = [], rad = []; ids.forEach(id => { const g = GR.get(id); if (!g) return; (g.t === 'R' ? rad : lin).push(g.t === 'T' ? Object.assign({ x2: '1', y2: '0.7' }, g) : Object.assign({ x2: '0.85', y2: '1' }, g)); }); return { lin, rad }; };
  const CACHE = (window.House3D && window.House3D.CACHE) || new Map();
  function render(t, rot, ci, v) {
    const key = t + '|' + rot + '|' + ci + '|' + (v || ''); const hit = CACHE.get(key); if (hit) return hit;
    const D = CAT[t]; if (!D) return null;
    const sol = D.build(pal(D, ci || 0), v || ''), tr = rot * Math.PI / 180, c = Math.cos(tr), s = Math.sin(tr);
    const Z = D.zs || 1, Rn = p => [p[0] * c + p[2] * s, p[1], -p[0] * s + p[2] * c], Rf = p => [(p[0] * c + p[2] * s) * FS, p[1] * FS, (-p[0] * s + p[2] * c) * FS], R = p => [(p[0] * c + p[2] * s) * FS * Z, p[1] * FS * Z, (-p[0] * s + p[2] * c) * FS * Z], pr = p => [p[0], p[2] * SA - p[1] * CA], gs = new Set();
    const hi = (P, L, o) => { let a = 1e9, b = 1e9, cc = -1e9, d = -1e9; P.forEach(q => { a = Math.min(a, q[0]); cc = Math.max(cc, q[0]); b = Math.min(b, q[1]); d = Math.max(d, q[1]); }); const w = cc - a, hh = d - b; if (w < 8 || area2(P) / 2 < w * hh * 0.5) return; L.push({ d: ell(a + w * 0.36, b + hh * 0.32, w * 0.24, hh * 0.18), f: 'url(#hiW)', s: 'none', w: 0, o }); };
    let sd = null; if (D.inside) { const q = R(D.inside); sd = q[1] * SA + q[2] * CA; }
    // seat items: solids that stand up past the seat on the viewer's side of it (a chair back turned to us, a table in front of a far seat, a headboard) go to the front layer, drawn over the sitter
    const SQ = sd == null && !D.roam && !D.noFront && D.seats && D.seats.length ? D.seats.map(q => ({ x: q.x, z: q.z, h: q.h, m: (q.k || D.act) === 'nap' ? 34 : 8 })) : null, vwx = -s, vwz = c;
    const inFr = B => { if (!SQ || !B) return false; const cx = (B[0] + B[1]) / 2, cz = (B[4] + B[5]) / 2; let q = SQ[0], bd = 1e18; SQ.forEach(p => { const d = (p.x - cx) * (p.x - cx) + (p.z - cz) * (p.z - cz); if (d < bd) { bd = d; q = p; } }); if (B[3] < q.h + 6) return false;
      return (vwz > 0.3 && B[4] > q.z + q.m) || (vwz < -0.3 && B[5] < q.z - q.m) || (vwx > 0.3 && B[0] > q.x + q.m) || (vwx < -0.3 && B[1] < q.x - q.m); }; // edge-on views (|v| <= 0.3) put nothing over the sitter
    // glued details (S.par = the solid they lie on: a patch on a cushion, tape on a post) skip the sort and are drawn right after their parent, in its layer
    const KID = new Map(), roots = []; sol.forEach(S => { if (S.par && sol.includes(S.par)) { if (!KID.has(S.par)) KID.set(S.par, []); KID.get(S.par).push(S); } else roots.push(S); }); let nf = 0;
    const list = roots.map(S => { const pts = S.pts.map(R); let C0 = 0, C1 = 0, C2 = 0; pts.forEach(p => { C0 += p[0]; C1 += p[1]; C2 += p[2]; }); const n = pts.length; return { S, pts, dep: (C1 / n) * SA + (C2 / n) * CA + S.zb }; });
    list.sort((a, b) => a.dep - b.dep);
    // occlusion order: parts are compared in the piece's own (unrotated) frame; the axis that separates two overlapping parts decides which one is in front for this view
    { const n = list.length, EP = 4, wx = -s, wz = c;
      list.forEach(e => { const L = [1e9, -1e9, 1e9, -1e9, 1e9, -1e9]; e.S.pts.forEach(p => { if (p[0] < L[0]) L[0] = p[0]; if (p[0] > L[1]) L[1] = p[0]; if (p[1] < L[2]) L[2] = p[1]; if (p[1] > L[3]) L[3] = p[1]; if (p[2] < L[4]) L[4] = p[2]; if (p[2] > L[5]) L[5] = p[2]; });
        let a = 1e9, b = -1e9, u0 = 1e9, u1 = -1e9, md = -1e9; e.pts.forEach(p => { if (p[0] < a) a = p[0]; if (p[0] > b) b = p[0]; const sy = p[2] * SA - p[1] * CA, dd = p[1] * SA + p[2] * CA; if (sy < u0) u0 = sy; if (sy > u1) u1 = sy; if (dd > md) md = dd; }); e.L = L; e.sb = [a, b, u0, u1]; e.md = md; });
      const after = Array.from({ length: n }, () => []), indeg = new Array(n).fill(0), inS = new Array(n).fill(0);
      for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) { const A = list[i], B = list[j], P = A.sb, Q = B.sb;
        if (P[1] < Q[0] - 2.5 || Q[1] < P[0] - 2.5 || P[3] < Q[2] - 2.5 || Q[3] < P[2] - 2.5) continue;
        const a = A.L, b = B.L, ax = [[Math.max(a[2] - b[3], b[2] - a[3]), 1, a[2] > b[2] ? 1 : -1]];
        if (Math.abs(wx) > 0.15) ax.push([Math.max(a[0] - b[1], b[0] - a[1]), 0, (a[0] > b[0] ? 1 : -1) * Math.sign(wx)]);
        if (Math.abs(wz) > 0.15) ax.push([Math.max(a[4] - b[5], b[4] - a[5]), 0, (a[4] > b[4] ? 1 : -1) * Math.sign(wz)]);
        // two planes that really separate the parts but disagree on which is nearer = their outlines cannot overlap on screen, so no order is needed (a false edge here made cycles that dropped cushions behind the frame)
        if (ax.some(p => p[0] > 0 && p[2] === 1) && ax.some(p => p[0] > 0 && p[2] === -1)) continue;
        ax.sort((p, q) => q[0] - p[0]); let f = ax[0][0] > -EP ? ax[0][2] : 0; const st = f && ax[0][0] > 0 ? 1 : 0;
        if (!f && Math.abs(A.md - B.md) > 1) f = A.md > B.md ? 1 : -1;
        if (f === 1) { after[j].push([i, st]); indeg[i]++; inS[i] += st; } else if (f === -1) { after[i].push([j, st]); indeg[j]++; inS[j] += st; } }
      // cycles (touching / slightly sunk parts) are broken where only weak edges are violated: fewest strict separations still pending, then fewest pending edges, then depth
      const done = new Array(n).fill(false), out2 = [];
      for (let k = 0; k < n; k++) { let pick = -1; for (let i = 0; i < n; i++) if (!done[i] && indeg[i] === 0) { pick = i; break; }
        if (pick < 0) { nf++; let bs = 1e9, bd = 1e9; for (let i = 0; i < n; i++) if (!done[i] && (inS[i] < bs || (inS[i] === bs && indeg[i] < bd))) { bs = inS[i]; bd = indeg[i]; pick = i; } }
        done[pick] = true; out2.push(list[pick]); after[pick].forEach(([q, st]) => { indeg[q]--; inS[q] -= st; }); }
      list.length = 0; out2.forEach(e => list.push(e)); }
    const out = { back: [], part: [], front: [], nf }; let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    const grow = P => P.forEach(p => { if (p[0] < x0) x0 = p[0]; if (p[0] > x1) x1 = p[0]; if (p[1] < y0) y0 = p[1]; if (p[1] > y1) y1 = p[1]; });
    // front closure: a part drawn after a front part that overlaps it on screen and belongs to another seat (a neighbour's cushion / armrest / cup holder) must stay over it, so it joins the front layer too
    const FR = new Set(); if (SQ) { const near = B => { const cx = (B[0] + B[1]) / 2, cz = (B[4] + B[5]) / 2; let k = 0, bd = 1e18; SQ.forEach((p, i) => { const d = (p.x - cx) * (p.x - cx) + (p.z - cz) * (p.z - cz); if (d < bd) { bd = d; k = i; } }); return k; }, ov = (P, Q) => P[0] < Q[1] - 1 && Q[0] < P[1] - 1 && P[2] < Q[3] - 1 && Q[2] < P[3] - 1;
      list.forEach(e => { if (e.S.part) return; if (inFr(e.L)) { e.nk = near(e.L); FR.add(e); return; } if (!FR.size) return; const k = near(e.L); for (const f of FR) if ((f.cl || f.nk !== k) && ov(e.sb, f.sb)) { e.nk = k; e.cl = 1; FR.add(e); return; } }); }
    if (KID.size) { const ex = [], add = e => { ex.push(e); (KID.get(e.S) || []).forEach(S => add({ S, pts: S.pts.map(R), dep: e.dep, pe: e })); }; list.forEach(add); list.length = 0; ex.forEach(e => list.push(e)); }
    list.forEach(E => { const { S, pts, dep } = E;
      E.lay = E.pe ? (E.pe.lay || out.back) : S.part ? out.part : ((sd != null && dep > sd + 4) || FR.has(E) ? out.front : out.back);
      if (E.pe && S.fn) { const n = Rn(S.fn); if (n[1] * SA + n[2] * CA <= 0.05) return; } // glued detail on a face turned away from the viewer
      const vis = [];
      S.faces.forEach(F => { const n = Rn(F.n), dv = n[1] * SA + n[2] * CA; if (dv <= 0.02) return; vis.push({ P2: F.q.map(p => pr(R(p))), n, cap: F.cap, k: S.emit ? 1 : 0.62 + 0.42 * Math.max(0, dot(n, LT)) + 0.05 * dv }); });
      if (!vis.length) return;
      const L = E.lay, oc = S.noOut ? 'none' : shade(S.col, 0.58), ow = S.noOut ? 0 : 1.15, op = S.op ?? 1;
      if (S.cv) {
        const H = hull(pts.map(pr)); grow(H); const HP = pathOf(H), m = matOf(S);
        let bx0 = 1e9, bx1 = -1e9, by0 = 1e9, by1 = -1e9; H.forEach(p => { if (p[0] < bx0) bx0 = p[0]; if (p[0] > bx1) bx1 = p[0]; if (p[1] < by0) by0 = p[1]; if (p[1] > by1) by1 = p[1]; });
        const bw = bx1 - bx0, bh = by1 - by0, big = bw > 5 && bh > 5 && op > 0.5;
        if (S.emit) { L.push({ d: HP, f: shade(S.col, 1.04), s: oc, w: ow, o: op }); if (big && !S.noOut) L.push({ d: HP, f: 'url(#mVol) none', s: 'none', w: 0, o: 0.35 }); }
        else if (S.shine || S.org) { L.push({ d: HP, f: gref('R', S.col, gs), s: oc, w: ow, o: op }); if (big) L.push({ d: HP, f: 'url(#mVol) none', s: 'none', w: 0, o: 0.6 }); if (!S.noOut) hi(H, L, 0.9); }
        else {
          L.push({ d: HP, f: gref('S', S.col, gs), s: oc, w: ow, o: op });
          const tp = []; vis.forEach(F => { if (F.n[1] > 0.42) F.P2.forEach(p => tp.push(p)); });
          let T = null; if (tp.length >= 3) { T = hull(tp); L.push({ d: pathOf(T), f: gref('T', S.col, gs), s: 'none', w: 0, o: op }); }
          if (big) { if (TEX[m] && bw * bh > 120) L.push({ d: HP, f: TEX[m], s: 'none', w: 0, o: 1 }); L.push({ d: HP, f: 'url(#mVol) none', s: 'none', w: 0, o: m === 'cer' ? 0.65 : 1 }); }
          if (S.soft) hi(T || H, L, T ? 0.75 : 0.6); else if (m === 'metal' || m === 'cer') hi(T || H, L, 0.5);
        }
      } else {
        vis.forEach(F => { grow(F.P2); const fc = shade(S.col, F.k); L.push({ d: pathOf(F.P2), f: fc, s: fc, w: 0.8, o: op }); });
      }
      // optional texture overlay (S.tex = 'url(#id) none'; texTop = only over the up-facing faces)
      if (S.tex) { let HH = null; if (S.texTop) { const tq = []; vis.forEach(F => { if (F.n[1] > 0.42) F.P2.forEach(p => tq.push(p)); }); if (tq.length >= 3) HH = hull(tq); } else HH = hull(pts.map(pr)); if (HH) L.push({ d: pathOf(HH), f: S.tex, s: 'none', w: 0, o: S.texO ?? 1 }); }
    });
    const fpR = (k) => ring({ sh: D.round ? 'el' : 'rr', a: D.w / 2 * k, b: D.d / 2 * k, r: Math.min(D.w, D.d) * 0.22, n: 20 }, 0, 1).map(([u, v]) => pr(Rf([u, 0, v])));
    const shP = hull(fpR(1.04)), ftP = hull(fpR(1.14)), ctP = hull(fpR(0.9)); grow(ftP);
    let face = null; if (D.face) { const q = pr(R([0, D.face.y, D.face.z])), k = FS * Z; face = { x: f1(q[0]), y: f1(q[1]), a: c * k, b: -s * SA * k, d: CA * k, w: D.face.w, h: D.face.h }; }
    let glow = null; const G = D.glow && D.glow(v || ''); if (G) { const q = pr(R([0, G.y, 0])); const gr = G.r * Z; glow = { d: circ(q[0], q[1], gr), f: G.c || 'url(#gWarm)' }; grow([[q[0] - gr, q[1] - gr], [q[0] + gr, q[1] + gr]]); }
    const pv = D.pivot ? pr(R(D.pivot)) : [0, 0];
    // TV screen quad (front plane of the solid tagged scr) as an affine matrix: local (0..w, 0..h, top-left origin) -> item svg coords
    let screen = null; { const SC = sol.find(S => S.scr), nf = Rn([0, 0, 1]);
      if (SC && nf[1] * SA + nf[2] * CA > 0.05) { let a = 1e9, b = -1e9, lo = 1e9, hi2 = -1e9, zf = -1e9; SC.pts.forEach(p => { a = Math.min(a, p[0]); b = Math.max(b, p[0]); lo = Math.min(lo, p[1]); hi2 = Math.max(hi2, p[1]); zf = Math.max(zf, p[2]); });
        const TL = pr(R([a, hi2, zf])), TR = pr(R([b, hi2, zf])), BL = pr(R([a, lo, zf])), W = b - a, H = hi2 - lo;
        if (W > 1 && H > 1) screen = { w: f1(W), h: f1(H), r: f1(Math.min(SC.scr.r, W / 2, H / 2)), m: 'matrix(' + [(TR[0] - TL[0]) / W, (TR[1] - TL[1]) / W, (BL[0] - TL[0]) / H, (BL[1] - TL[1]) / H, TL[0], TL[1]].map(q => q.toFixed(4)).join(' ') + ')' }; } }
    x0 -= 6; y0 -= 6; x1 += 6; y1 += 6;
    const res = { nf, gids: [...gs], back: out.back, part: out.part, front: out.front, glow, shadow: pathOf(shP), contact: pathOf(ctP), foot: pathOf(ftP), pv, face, screen, bb: { x: f1(x0), y: f1(y0), w: f1(x1 - x0), h: f1(y1 - y0) }, vb: f1(x0) + ' ' + f1(y0) + ' ' + f1(x1 - x0) + ' ' + f1(y1 - y0) };
    CACHE.set(key, res); return res;
  }
  const seatXY = (D, rot, k) => { const s = D.seats[k], tr = rot * Math.PI / 180, c = Math.cos(tr), sn = Math.sin(tr); return { x: (s.x * c + s.z * sn) * FS, z: (-s.x * sn + s.z * c) * FS, h: s.h * FS, f: s.f || 0, k: s.k || D.act }; };
  const useXY = (D, rot) => { const u = D.use, tr = rot * Math.PI / 180, c = Math.cos(tr), sn = Math.sin(tr); return { x: (u.x * c + u.z * sn) * FS, z: (-u.x * sn + u.z * c) * FS, inside: u.inside }; };
  const half = (D, rot) => { const tr = rot * Math.PI / 180, c = Math.abs(Math.cos(tr)), s = Math.abs(Math.sin(tr)); return { hx: (D.w / 2 * c + D.d / 2 * s) * FS, hz: (D.w / 2 * s + D.d / 2 * c) * FS }; };

  const prism = (x0, x1, pts, col, o = {}) => solid(Object.assign({ ax: 'x', sh: 'poly', c: [0, 0], pts, rings: [[x0, 0], [x1, 0]], col }, o));
  const prismZ = (z0, z1, pts, col, o = {}) => solid(Object.assign({ ax: 'z', sh: 'poly', c: [0, 0], pts, rings: [[z0, 0], [z1, 0]], col }, o));
  const CAT = (window.House3D && window.House3D.CAT) || {};
  window.House3D = Object.assign(window.House3D || {}, { MDEFS, matOf, grads, FS, SA, CA, VW, FY0, FY1, sAt, edge, edge0, RM, CAT, render, seatXY, useXY, half, pal, CACHE, _GR: GR,
    K: { solid, box, cush, cyl, ball, slab, slabX, arcW, disc, pillowY, pillowZ, legs4, quarters, mix, shade, prism, prismZ, hull, pathOf, circ, ell, f1, NEON, CR, WH, MT, GOLD } });
})();
