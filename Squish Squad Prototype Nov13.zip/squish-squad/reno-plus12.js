// Renovation Catalog round 12 — Movie Room realism pass, part 3: WALLS on the RD.H10 / H11 renderer.
// Wall surfaces = seamless 80 x 56 tiles (the room repeats them as a 214 x 150 pattern), drawn as real materials: drywall + egg-crate foam,
// rolled matte paint, velvet drapes, backlit walnut slats, padded starlight panels (r.s12). Wall hangings + wall lights rebuilt as lit 3D pieces
// with wall shadows; some are animated (corner flutter, chasing bulbs, living posters, swaying lanterns, neon flicker, colour waves, spinning reels).
// Sets RenoDraw.PLUS12; catalog edits RD.SET12.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS11 && RD.H11 && RD.H10 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS12) return;
  const K = X.K, shade = K.shade, N = RD.N, PI = Math.PI, H = RD.H10;
  const { cam, FR, vis, lit, add, mul, rng, an, at, SPL, f1, n4, rep, P2, FONT, pth } = H;
  const { DEF11, ext } = RD.H11;
  // game style: flat cel-shaded faces, chunky dark outlines, no photo textures / chrome streaks, soft glass
  const box3 = (C, o) => H.box3(C, Object.assign({}, o, { mat: null, tpat: null, gl: o.gl ? Math.min(o.gl, 0.2) : 0, olw: 1, olo: 0.95, olc: o.olc && o.olc !== '#050506' && o.olc !== '#050608' && o.olc !== '#020203' ? o.olc : shade(o.col, 0.32), edge: 0.5 }));
  const cyl3 = (C, a, b, r, col, o) => H.cyl3(C, a, b, r, col, Object.assign({}, o || {}, { mat: o && o.mat === 'gloss' ? 'gloss' : 'plastic', pat: null, olw: 0.8, olo: 0.95 }));
  const sph = (C, q, r, col, o) => { const c = C.P(q); return H.sph(C, q, r, col, o) + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * C.k)}" fill="none" stroke="${shade(col, 0.35)}" stroke-width="0.5"/>`; };
  const pane = (C, O, U, V, w, h, o) => RD.H11.pane(C, O, U, V, w, h, Object.assign({}, o, { g: 0.3, e: 0.12, t: 0.03 }));
  const DEF12 = DEF11 + '<pattern id="m12ht" width="1.4" height="1.4" patternUnits="userSpaceOnUse"><circle cx="0.7" cy="0.7" r="0.32" fill="#3a2a10" fill-opacity="0.13"/></pattern>'
    + '<pattern id="m12scan" width="2" height="0.9" patternUnits="userSpaceOnUse"><rect width="2" height="0.3" fill="#ffffff" fill-opacity="0.08"/></pattern>'
    + '<linearGradient id="m12sh" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#d8fcff" stop-opacity="0.3"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
    + '<linearGradient id="m12rt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000000" stop-opacity="0.42"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></linearGradient>'
    + '<linearGradient id="m12rl" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000000" stop-opacity="0.32"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></linearGradient>'
    + '<linearGradient id="m12gl" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.14"/></linearGradient>'
    + '<filter id="m12b1" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="0.55"/></filter><filter id="m12b2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.4"/></filter>';

  // ---------- helpers ----------
  // wall-plane decal: local x right, y down from the top-left corner (x, y) at depth z
  const WD = (C, x, y, z, s, w, h) => { if (w) ext(C, [[x, y, z], [x + w, y - h, z]]); return `<g transform="${FR(C, [x, y, z], [1, 0, 0], [0, -1, 0])}">${s}</g>`; };
  const wsh = (C, x, y, w, h, o) => WD(C, x + (o.dx == null ? 1.6 : o.dx), y - (o.dy == null ? 2.4 : o.dy), 0.06, `<rect width="${f1(w)}" height="${f1(h)}" rx="${o.r || 1}" fill="#000000" opacity="${o.op || 0.4}" filter="url(#${o.f || 'm10b3'})"/>`);
  // inside walls of a recess (x0..x1, yb..yt, z0..z1)
  const innerW = (C, x0, x1, yb, yt, z0, z1, col, f) => [[[0, 1, 0], [[x0, yb, z0], [x1, yb, z0], [x1, yb, z1], [x0, yb, z1]]], [[0, -1, 0], [[x0, yt, z0], [x1, yt, z0], [x1, yt, z1], [x0, yt, z1]]],
    [[1, 0, 0], [[x0, yb, z0], [x0, yt, z0], [x0, yt, z1], [x0, yb, z1]]], [[-1, 0, 0], [[x1, yb, z0], [x1, yt, z0], [x1, yt, z1], [x1, yb, z1]]]]
    .filter(([n]) => vis(C, n)).map(([n, Q]) => { const c = shade(col, lit(C, n) * (f || 0.85)); return `<path d="${pth(Q.map(C.P))}" fill="${c}" stroke="${c}" stroke-width="0.2"/>`; }).join('');
  const T = (x, y, sz, col, txt, ex) => `<text x="${f1(x)}" y="${f1(y)}" text-anchor="middle" ${FONT} font-size="${f1(sz)}" fill="${col}"${ex ? ' ' + ex : ''}>${txt}</text>`;
  const paperFx = (p, w, h, ht) => `<defs><radialGradient id="${p}v" cx="50%" cy="46%" r="72%"><stop offset="0.55" stop-color="#7a5a2a" stop-opacity="0"/><stop offset="1" stop-color="#7a5a2a" stop-opacity="0.45"/></radialGradient></defs>`
    + `<rect width="${f1(w)}" height="${f1(h)}" fill="url(#m12gl)" opacity="0.6"/>`;
  const per = (x0, a, ph, b, ph2) => rep(29, j => { const y = j * 2; return [x0 + a * Math.sin(2 * PI * y / 56 + ph) + (b || 0) * Math.sin(4 * PI * y / 56 + (ph2 || 0)), y]; }); // vertical line that tiles every 56
  const ln = P => 'M' + P.map(P2).join('L');

  // ======================= WALL SURFACES (seamless 80 x 56 tiles) =======================
  const NZ = (id, bf, oct, seed, c, ch, a, b) => `<filter id="${id}" filterUnits="userSpaceOnUse" x="0" y="0" width="80" height="56" color-interpolation-filters="sRGB"><feTurbulence type="fractalNoise" baseFrequency="${bf}" numOctaves="${oct}" seed="${seed}" stitchTiles="stitch"/>`
    + `<feColorMatrix values="0 0 0 0 ${c} 0 0 0 0 ${c} 0 0 0 0 ${c} ${ch === 0 ? a : 0} ${ch === 1 ? a : 0} ${ch === 2 ? a : 0} 0 ${b}"/></filter>`;
  const NR = (id, op, clip) => `<rect width="80" height="56" filter="url(#${id})" opacity="${op}"${clip ? ` clip-path="url(#${clip})"` : ''}/>`;
  const BL = (id, s) => `<filter id="${id}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="${s}"/></filter>`;

  // ---- wall surfaces, creature scale: the room maps one 80 x 56 tile to the full wall height (1 unit ~ 2.7 px, a creature ~ 18 units tall),
  // so every detail is small. Colours come from the matching floor (005 / 025 / 065 / 085), low baseboard in the floor's tone, soft corner shading only.
  // tile(S) = back wall tile; tile(S, 1) = 80 x 280 side-wall tile (4 material rows above the bottom tile) (material above, no ceiling shadow) so the side walls keep the baseboard on their floor edge.
  const BLR = '<filter id="wb2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.3"/></filter><filter id="wb1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.45"/></filter>';
  const blot = (seed, n, cols, op, sz) => { const R = rng(seed); let o = '<g filter="url(#wb2)">'; rep(n, i => { const x = R() * 80, y = R() * 56, rx = (sz || 3) * (0.6 + R() * 0.9), ry = rx * (0.5 + R() * 0.3);
    [-80, 0, 80].forEach(dx => [-56, 0, 56].forEach(dy => { const cx = x + dx, cy = y + dy; if (cx + rx < -3 || cx - rx > 83 || cy + ry < -3 || cy - ry > 59) return; o += '<ellipse cx="' + f1(cx) + '" cy="' + f1(cy) + '" rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="' + cols[i % cols.length] + '" opacity="' + op + '"/>'; })); }); return o + '</g>'; };
  const BB = 53.6;
  const room = (board, o) => { o = o || {}; const lip = shade(board, 1.35), dk = shade(board, 0.7);
    return '<defs><linearGradient id="wsh" x1="0" y1="0" x2="0" y2="1">' + (o.side ? '<stop offset="0" stop-color="#ffffff" stop-opacity="0"/>' : '<stop offset="0" stop-color="#000000" stop-opacity="0.2"/><stop offset="0.07" stop-color="#000000" stop-opacity="0"/>')
      + '<stop offset="0.22" stop-color="#ffffff" stop-opacity="' + (o.top || 0.06) + '"/><stop offset="0.55" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.84" stop-color="#000000" stop-opacity="0"/><stop offset="0.957" stop-color="#000000" stop-opacity="' + (o.ao || 0.13) + '"/></linearGradient></defs>'
      + '<rect width="80" height="56" fill="url(#wsh)"/><rect y="' + (BB - 0.8) + '" width="80" height="1" fill="#000000" opacity="0.18" filter="url(#wb1)"/>'
      + '<rect y="' + BB + '" width="80" height="' + f1(56 - BB) + '" fill="' + board + '"/><rect y="' + BB + '" width="80" height="0.45" fill="' + lip + '"/><rect y="55.35" width="80" height="0.65" fill="' + dk + '"/>' + (o.board || ''); };
  const tile = (S, side) => { const m = '<g clip-path="url(#wtc)">' + (side && S.smat || S.mat) + '</g>', mu = side && S.sup ? '<g clip-path="url(#wtc)">' + S.sup + '</g>' : m, d = '<defs>' + BLR + '<clipPath id="wtc"><rect width="80" height="56"/></clipPath>' + (S.defs || '') + '</defs>';
    return d + (side ? rep(4, i => '<g transform="translate(0 ' + (-56 * (i + 1)) + ')">' + mu + '</g>').join('') : '') + m + room(S.board, Object.assign({}, S.ro, side ? { side: 1 } : {})); };
  const outlet = (x, y, pl, sl) => '<rect x="' + x + '" y="' + y + '" width="1.5" height="2.3" rx="0.22" fill="' + pl + '" stroke="' + shade(pl, 0.7) + '" stroke-width="0.12"/>' + [0.55, 1.45].map(dy => '<rect x="' + f1(x + 0.45) + '" y="' + f1(y + dy) + '" width="0.16" height="0.38" fill="' + sl + '"/><rect x="' + f1(x + 0.9) + '" y="' + f1(y + dy) + '" width="0.16" height="0.38" fill="' + sl + '"/>').join('');

  // MOV-001 peeling basement drywall + egg-carton soundproofing (cool grey to sit on the cracked concrete floor)
  function sDry() { const R = rng('dry13');
    let s = '<rect width="80" height="56" fill="#c5c3bc"/>' + blot('dry', 34, ['#d2d0c9', '#b6b4ac', '#bfbdb5'], 0.55, 3);
    [0, 26.67, 53.33, 80].forEach(x => s += '<rect x="' + f1(x - 1.1) + '" width="2.2" height="56" fill="#d5d3cc" opacity="0.8"/><path d="M' + f1(x - 1.1) + ' 0V56M' + f1(x + 1.1) + ' 0V56" stroke="#adaba3" stroke-width="0.12" opacity="0.7"/>');
    [8.9, 17.8, 35.6, 44.4, 62.2, 71.1].forEach(x => { for (let y = 3.2; y < 53; y += 6.4) s += '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="0.26" fill="#a4a29a"/><circle cx="' + f1(x - 0.07) + '" cy="' + f1(y - 0.07) + '" r="0.1" fill="#e4e2dc"/>'; });
    const stain = (x0, w, h) => { let d = 'M' + f1(x0) + ' 56'; rep(7, i => { d += 'L' + f1(x0 + w * i / 6) + ' ' + f1(54 - h * Math.pow(Math.sin(PI * i / 6), 0.6) * (0.8 + 0.2 * R())); }); d += 'L' + f1(x0 + w) + ' 56Z';
      return '<path d="' + d + '" fill="#9d9174" opacity="0.22" filter="url(#wb2)"/><path d="' + d + '" fill="none" stroke="#857553" stroke-width="0.3" opacity="0.32" filter="url(#wb1)"/>'; };
    s += stain(3, 16, 8) + stain(57, 9, 4.5);
    const flake = (x, y, r) => '<path d="M' + f1(x - r) + ' ' + f1(y) + 'Q' + f1(x - r * 0.4) + ' ' + f1(y - r * 0.9) + ' ' + f1(x + r * 0.6) + ' ' + f1(y - r * 0.6) + 'Q' + f1(x + r) + ' ' + f1(y + r * 0.2) + ' ' + f1(x + r * 0.2) + ' ' + f1(y + r * 0.7) + 'Q' + f1(x - r * 0.6) + ' ' + f1(y + r * 0.8) + ' ' + f1(x - r) + ' ' + f1(y) + 'Z" fill="#aa9878"/>'
      + '<path d="M' + f1(x + r * 0.6) + ' ' + f1(y - r * 0.6) + 'Q' + f1(x + r * 1.5) + ' ' + f1(y - r * 1.2) + ' ' + f1(x + r * 1.4) + ' ' + f1(y - r * 0.1) + 'Q' + f1(x + r) + ' ' + f1(y - r * 0.5) + ' ' + f1(x + r * 0.6) + ' ' + f1(y - r * 0.6) + 'Z" fill="#eeece6" stroke="#b1afa7" stroke-width="0.1"/>';
    s += flake(23.5, 11, 1) + flake(50.5, 37, 0.75) + flake(9.5, 29, 0.65) + flake(75, 42, 0.6);
    const crt = (x, y, rot) => { let o = '<g transform="translate(' + x + ' ' + y + ') rotate(' + rot + ' 3 2.1)"><rect x="0.35" y="0.5" width="6" height="4.2" rx="0.4" fill="#000000" opacity="0.24" filter="url(#wb1)"/><rect width="6" height="4.2" rx="0.4" fill="#8c8e8d"/>';
      for (let j = 0; j < 2; j++) for (let i = 0; i < 3; i++) o += '<circle cx="' + (1 + i * 2) + '" cy="' + f1(1.05 + j * 2.1) + '" r="0.82" fill="url(#dpk)"/>'; return o + '<rect width="6" height="0.35" rx="0.2" fill="#ffffff" opacity="0.2"/></g>'; };
    [[0, 0, 0], [1, 0, 1], [2, 0, -1], [0, 1, 1], [1, 1, 0]].forEach(([i, j, r]) => s += crt(30 + i * 6.3, 21 + j * 4.5, r));
    s += crt(44.2, 30.8, 9) + crt(66, 13.6, -3) + crt(72.4, 14.1, 2);
    s += outlet(60.5, 46.2, '#e6e4dd', '#5a5852');
    return { mat: s, defs: '<radialGradient id="dpk" cx="38%" cy="34%" r="70%"><stop offset="0" stop-color="#a9acb0"/><stop offset="1" stop-color="#6a6d72"/></radialGradient>', board: '#a7a59e',
      ro: { top: 0.07, ao: 0.12, board: rep(26, () => '<circle cx="' + f1(R() * 80) + '" cy="' + f1(BB + 0.6 + R() * 1.6) + '" r="' + f1(0.14 + R() * 0.16) + '" fill="' + (R() < 0.5 ? '#8d8b84' : '#c9c7c0') + '"/>').join('') } }; }

  // MOV-021 matte charcoal cinema paint (cool slate like the grey carpet tiles), black rubber cove base, a small amber step light
  function sChar() { const R = rng('char13'); let s = '<rect width="80" height="56" fill="#4a4e57"/>';
    for (let i = 0; i < 16; i++) s += '<rect x="' + i * 5 + '" width="5" height="56" fill="' + (i % 2 ? '#ffffff' : '#000000') + '" opacity="' + f1(0.005 + R() * 0.008) + '"/>';
    s += blot('char', 28, ['#535761', '#40444c'], 0.5, 3) + '<rect width="80" height="56" fill="url(#chs)"/>';
    s += outlet(21, 46.4, '#3c3f46', '#16171a');
    s += '<g filter="url(#wb2)"><ellipse cx="61" cy="52.6" rx="3.4" ry="1.6" fill="#ffc27a" opacity="0.35">' + an('opacity', '0.3;0.42;0.3', 4, 0, SPL(2)) + '</ellipse></g><rect x="60" y="49.6" width="2" height="1.1" rx="0.25" fill="#1c1d21"/><rect x="60.3" y="50.15" width="1.4" height="0.4" rx="0.15" fill="#ffd9a0"/>';
    return { mat: s, defs: '<pattern id="chs" width="1.6" height="1.6" patternUnits="userSpaceOnUse"><circle cx="0.4" cy="0.5" r="0.2" fill="#000000" fill-opacity="0.1"/><circle cx="1.2" cy="1.2" r="0.16" fill="#ffffff" fill-opacity="0.05"/></pattern>', board: '#2a2d32',
      ro: { top: 0.05, ao: 0.1, board: '<rect y="' + (BB + 0.45) + '" width="80" height="0.35" fill="#5a5e66" opacity="0.55"/>' } }; }

  // MOV-061 backlit walnut acoustic slats in the teak floor's colours, thin like real slats, LED cove strip along the floor like the floor's LED guides
  function sSlat() { const PD = 3.2, SW = 2.3, PC = ['#704329', '#7c4a2c', '#663c24', '#82502f', '#6b4027'], R = rng('slat13');
    const defs = '<linearGradient id="sg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffcf7a" stop-opacity="0.75"/><stop offset="0.25" stop-color="#ffab3a" stop-opacity="0.28"/><stop offset="0.65" stop-color="#ff9a2a" stop-opacity="0.22"/><stop offset="0.95" stop-color="#ffcf7a" stop-opacity="0.95"/></linearGradient>'
      + PC.map((c, i) => '<linearGradient id="sw' + i + '" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="' + shade(c, 1.24) + '"/><stop offset="0.35" stop-color="' + c + '"/><stop offset="1" stop-color="' + shade(c, 0.74) + '"/></linearGradient>').join('');
    let s = '<rect width="80" height="56" fill="#1d120b"/><g>' + an('opacity', '0.65;1;0.65', 7, 0, SPL(2)) + '<rect width="80" height="56" fill="url(#sg)"/></g>';
    for (let i = 0; i < 25; i++) { const x0 = i * PD + (PD - SW) / 2, c = i % 5;
      s += '<rect x="' + f1(x0 + SW) + '" width="0.35" height="56" fill="#000000" opacity="0.35"/><rect x="' + f1(x0) + '" width="' + SW + '" height="56" fill="url(#sw' + c + ')"/><path d="' + ln(per(x0 + 0.7 + R() * 0.9, 0.12, R() * 6)) + '" stroke="' + shade(PC[c], 0.68) + '" stroke-opacity="0.5" stroke-width="0.14" fill="none"/>'; }
    return { mat: s, defs, board: '#3b2213', ro: { top: 0.05, ao: 0.08, board: '<rect y="' + (BB - 3) + '" width="80" height="3" fill="#ffcf7a" opacity="0.4" filter="url(#wb2)">' + an('opacity', '0.3;0.55;0.3', 4, 0, SPL(2)) + '</rect><rect y="' + (BB - 0.5) + '" width="80" height="0.5" fill="#ffe7b8"/>' } }; }

  // MOV-081 obsidian starlight panels: small padded squares in the glass floor's violet, fibre stars, violet light line at the floor like the floor seams
  function sStar() { const R = rng('star13');
    let s = '<rect width="80" height="56" fill="#0c0a16"/>';
    for (let j = 0; j < 7; j++) for (let i = 0; i < 10; i++) { const x = i * 8 + 0.3, y = j * 8 + 0.3;
      s += '<rect x="' + f1(x) + '" y="' + f1(y) + '" width="7.4" height="7.4" rx="1.3" fill="url(#spg)"/><rect x="' + f1(x + 0.6) + '" y="' + f1(y + 0.5) + '" width="6.2" height="2.4" rx="1" fill="#ffffff" opacity="0.05"/><circle cx="' + f1(x + 3.7) + '" cy="' + f1(y + 3.7) + '" r="0.22" fill="#0c0a16" opacity="0.55"/>'; }
    s += '<path d="' + rep(10, i => 'M' + i * 8 + ' 0V56').join('') + rep(7, j => 'M0 ' + j * 8 + 'H80').join('') + '" stroke="#7a6cff" stroke-width="0.14" fill="none" opacity="0.3">' + an('opacity', '0.18;0.4;0.18', 4, 0, SPL(2)) + '</path>';
    const COL = ['#fff4dc', '#cfe6ff', '#ffffff', '#ffd6ef'];
    let n = 0; while (n < 90) { const x = 0.6 + R() * 78.8, y = 0.6 + R() * 52, mx = x % 8, my = y % 8; if (mx < 0.9 || mx > 7.1 || my < 0.9 || my > 7.1 || (Math.abs(mx - 3.7) < 0.5 && Math.abs(my - 3.7) < 0.5)) continue; n++;
      const col = COL[n % 4], A = an('opacity', '0.2;1;0.2', n4(1.8 + R() * 3), n4(-R() * 4));
      if (n % 9 === 0) { const r = 0.55; s += '<path d="M' + f1(x) + ' ' + f1(y - r) + 'Q' + f1(x + r * 0.18) + ' ' + f1(y - r * 0.18) + ' ' + f1(x + r) + ' ' + f1(y) + 'Q' + f1(x + r * 0.18) + ' ' + f1(y + r * 0.18) + ' ' + f1(x) + ' ' + f1(y + r) + 'Q' + f1(x - r * 0.18) + ' ' + f1(y + r * 0.18) + ' ' + f1(x - r) + ' ' + f1(y) + 'Q' + f1(x - r * 0.18) + ' ' + f1(y - r * 0.18) + ' ' + f1(x) + ' ' + f1(y - r) + 'Z" fill="' + col + '">' + A + '</path>'; }
      else s += '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(0.12 + R() * 0.18) + '" fill="' + col + '">' + A + '</circle>'; }
    s += '<g opacity="0"><path d="M0 0L-3.6 -0.25L-3.6 0.25Z" fill="#ffffff" transform="translate(18 9) rotate(22)"/><circle cx="18" cy="9" r="0.3" fill="#ffffff"/>' + an('opacity', '0;0;1;0;0', 13, 0, ' keyTimes="0;0.84;0.87;0.92;1"') + at('translate', '0 0;0 0;6 2.5;11 4.5;11 4.5', 13, 0, ' keyTimes="0;0.84;0.87;0.92;1"') + '</g>';
    return { mat: s, defs: '<linearGradient id="spg" x1="0" y1="0" x2="0.3" y2="1"><stop offset="0" stop-color="#2f2852"/><stop offset="1" stop-color="#1a1530"/></linearGradient>', board: '#0e0b1e',
      ro: { top: 0.05, ao: 0.08, board: '<rect y="' + (BB - 2.4) + '" width="80" height="2.6" fill="#7a6cff" opacity="0.35" filter="url(#wb2)">' + an('opacity', '0.2;0.5;0.2', 4, 0, SPL(2)) + '</rect><rect y="' + (BB + 0.5) + '" width="80" height="0.35" fill="#a49bff"/>' } }; }

  const SURF12 = { dry: sDry, char: sChar, slat: sSlat, star: sStar };
  const draw11 = RD.draw;
  RD.draw = (r, o) => { const res = draw11(r, o); if (!res || res._p12) return res;
    try { const f = r.s12 && SURF12[r.s12]; if (f && res.surf) { const S = f(); res._p12 = 1; res.vb = '0 0 80 56'; res.svg = RD.svgDoc('0 0 80 56', [], tile(S)); res.src = 'data:image/svg+xml,' + encodeURIComponent(res.svg);
        res.side = RD.svgDoc('0 -224 80 280', [], tile(S, 1)); res.board = S.board; res.tile = 1; } } catch (e) { console.warn('reno plus12', r.id, e); }
    return res; };

  // ======================= POSTER ART (local w x h, y down) =======================
  const artSpace = (p, w, h) => { const R = rng('sp' + p), px = w * 0.72, py = h * 0.36, pr = w * 0.17;
    const ring = sw => `<path d="M${f1(px - pr * 1.7)} ${f1(py)}A${f1(pr * 1.7)} ${f1(pr * 0.42)} 0 0 ${sw} ${f1(px + pr * 1.7)} ${f1(py)}" fill="none" stroke="#f6d49a" stroke-width="${f1(pr * 0.16)}" opacity="0.85" transform="rotate(-14 ${f1(px)} ${f1(py)})"/>`;
    return `<defs><linearGradient id="${p}k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#151a3e"/><stop offset="0.5" stop-color="#3b2060"/><stop offset="0.8" stop-color="#a5356b"/><stop offset="1" stop-color="#ee8a4a"/></linearGradient><radialGradient id="${p}p" cx="34%" cy="30%" r="72%"><stop offset="0" stop-color="#ffd9a0"/><stop offset="0.5" stop-color="#e8863c"/><stop offset="1" stop-color="#6a2618"/></radialGradient><linearGradient id="${p}f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff6b0"/><stop offset="0.5" stop-color="#ffb02e"/><stop offset="1" stop-color="#ff5a1a" stop-opacity="0"/></linearGradient></defs>`
      + `<rect width="${w}" height="${h}" fill="url(#${p}k)"/>` + rep(36, () => `<circle cx="${f1(R() * w)}" cy="${f1(R() * h * 0.7)}" r="${f1(0.12 + R() * 0.28)}" fill="#fff6e0" opacity="${f1(0.4 + R() * 0.6)}"/>`).join('')
      + ring(1) + `<circle cx="${f1(px)}" cy="${f1(py)}" r="${f1(pr)}" fill="url(#${p}p)"/>` + ring(0)
      + `<path d="M0 ${f1(h * 0.86)}Q${f1(w * 0.2)} ${f1(h * 0.78)} ${f1(w * 0.42)} ${f1(h * 0.84)}T${f1(w)} ${f1(h * 0.8)}V${h}H0Z" fill="#2a1238"/>`
      + `<g transform="translate(${f1(w * 0.34)} ${f1(h * 0.6)}) rotate(-32) scale(${n4(w / 50)})"><path d="M-2.6 9Q0 19 2.6 9Z" fill="url(#${p}f)"/><path d="M0 -12C4 -8 4.2 0 3 9H-3C-4.2 0 -4 -8 0 -12Z" fill="#e8e2d4"/><path d="M0 -12C2 -10 2.6 -7.6 2.8 -6H-2.8C-2.6 -7.6 -2 -10 0 -12Z" fill="#d6363a"/><path d="M-3 3L-6.5 9.5L-3 8.6ZM3 3L6.5 9.5L3 8.6Z" fill="#d6363a"/><circle cy="-2" r="1.6" fill="#7fd6ff" stroke="#5a5f6a" stroke-width="0.6"/><path d="M-1.8 -9.6C-2.9 -6 -3 -1 -2.4 7" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.5" fill="none"/></g>`
      + T(w / 2, h * 0.11, w * 0.11, '#f6e7c8', 'SPACE', `letter-spacing="${f1(w * 0.03)}"`) + T(w / 2, h * 0.235, w * 0.2, '#ffd34a', 'SQUISH', `stroke="#7a1d2a" stroke-width="${f1(w * 0.014)}" paint-order="stroke"`)
      + T(w / 2, h * 0.905, w * 0.042, '#ffe7b8', 'THE BLOB THAT ATE THE MOON!') + rep(3, i => `<rect x="${f1(w * (0.18 + i * 0.02))}" y="${f1(h * (0.925 + i * 0.022))}" width="${f1(w * (0.64 - i * 0.04))}" height="${f1(h * 0.009)}" fill="#e9d6c0" opacity="0.7"/>`).join(''); };
  const artRocket = (p, w, h) => { const k = w / 24;
    return `<rect width="${f1(w)}" height="${f1(h)}" fill="#f1e4c4"/><circle cx="${f1(w / 2)}" cy="${f1(h * 0.48)}" r="${f1(w * 0.4)}" fill="#e8b13c"/>` + rep(8, i => `<path d="M${f1(w / 2)} ${f1(h * 0.48)}L${f1(w / 2 + w * Math.cos(i * PI / 4))} ${f1(h * 0.48 + w * Math.sin(i * PI / 4))}" stroke="#f1e4c4" stroke-width="${f1(k * 0.5)}"/>`).join('')
      + `<path d="M0 ${f1(h * 0.84)}Q${f1(w * 0.5)} ${f1(h * 0.74)} ${f1(w)} ${f1(h * 0.84)}V${f1(h)}H0Z" fill="#2f8f8a"/>`
      + `<g transform="translate(${f1(w / 2)} ${f1(h * 0.46)}) scale(${n4(k)})" stroke="#233047" stroke-width="0.5" stroke-linejoin="round"><path d="M-2.2 11Q0 19 2.2 11Z" fill="#e8b13c"/><path d="M-1.1 11Q0 15.6 1.1 11Z" fill="#fff3c0" stroke="none"/><path d="M0 -13C4.5 -8 4.6 4 3.2 9H-3.2C-4.6 4 -4.5 -8 0 -13Z" fill="#e0533a"/><path d="M-4.3 -1H4.3V1.2H-4.3Z" fill="#f1e4c4" stroke="none"/><circle cy="-5" r="2" fill="#2f8f8a"/><circle cx="-0.6" cy="-5.6" r="0.6" fill="#ffffff" stroke="none"/><path d="M-3.2 4L-7.5 11L-3.2 9ZM3.2 4L7.5 11L3.2 9Z" fill="#2f8f8a"/><path d="M-2 9H2L2.6 11H-2.6Z" fill="#233047"/></g>`
      + rep(5, i => `<circle cx="${f1(w * (0.14 + i * 0.18))}" cy="${f1(h * 0.83 - (i % 2) * k * 1.2)}" r="${f1(k * (2.2 + (i % 2) * 0.6))}" fill="#f8efd8" stroke="#233047" stroke-width="${f1(k * 0.3)}"/>`).join('')
      + T(w / 2, h * 0.13, w * 0.19, '#233047', 'ROCKET') + T(w / 2, h * 0.96, w * 0.15, '#e0533a', 'RANGERS'); };
  const artSaucer = (p, w, h) => { const R = rng('sau' + p), k = w / 28, sx = w / 2, sy = h * 0.42;
    return `<defs><linearGradient id="${p}n" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1c2740"/><stop offset="1" stop-color="#3e5272"/></linearGradient></defs><rect width="${f1(w)}" height="${f1(h)}" fill="url(#${p}n)"/>`
      + rep(22, () => `<circle cx="${f1(R() * w)}" cy="${f1(R() * h * 0.6)}" r="${f1(0.15 + R() * 0.25)}" fill="#f1e4c4"/>`).join('') + `<circle cx="${f1(w * 0.2)}" cy="${f1(h * 0.24)}" r="${f1(3.2 * k)}" fill="#f1e4c4"/><circle cx="${f1(w * 0.2 + k * 1.2)}" cy="${f1(h * 0.24 - k * 0.6)}" r="${f1(2.6 * k)}" fill="#1c2740" opacity="0.25"/>`
      + `<path d="M${f1(sx - 4 * k)} ${f1(sy + k)}L${f1(sx - 10 * k)} ${f1(h * 0.86)}H${f1(sx + 10 * k)}L${f1(sx + 4 * k)} ${f1(sy + k)}Z" fill="#f1e4c4" opacity="0.3"/>`
      + `<path d="M${f1(sx - 4.6 * k)} ${f1(sy)}A${f1(4.6 * k)} ${f1(3.8 * k)} 0 0 1 ${f1(sx + 4.6 * k)} ${f1(sy)}Z" fill="#bfe8e0" stroke="#233047" stroke-width="${f1(k * 0.3)}"/><ellipse cx="${f1(sx)}" cy="${f1(sy)}" rx="${f1(9.5 * k)}" ry="${f1(2.4 * k)}" fill="#2f8f8a" stroke="#141c2b" stroke-width="${f1(k * 0.3)}"/>`
      + rep(5, i => `<circle cx="${f1(sx + (i - 2) * 3.4 * k)}" cy="${f1(sy + k * 0.5)}" r="${f1(k * 0.6)}" fill="#e8b13c"/>`).join('')
      + rep(7, i => { const bw = w / 7, bh = h * (0.12 + ((i * 37) % 5) * 0.035), x = i * bw; return `<rect x="${f1(x)}" y="${f1(h - bh)}" width="${f1(bw + 0.2)}" height="${f1(bh)}" fill="#141c2b"/>` + rep(3, j => `<rect x="${f1(x + bw * 0.25)}" y="${f1(h - bh + 1.2 + j * 2.2)}" width="${f1(bw * 0.18)}" height="0.9" fill="#e8b13c" opacity="${(i + j) % 3 ? 0.9 : 0.25}"/>`).join(''); }).join('')
      + T(w / 2, h * 0.11, w * 0.17, '#f1e4c4', 'SAUCER') + T(w / 2, h * 0.7, w * 0.16, '#e8b13c', 'SUMMER', 'stroke="#1c2740" stroke-width="0.5" paint-order="stroke"'); };
  const artRobot = (p, w, h) => { const k = w / 24, cx = w / 2, cy = h * 0.52;
    return `<rect width="${f1(w)}" height="${f1(h)}" fill="#e8b13c"/>` + rep(12, i => { const a = i * PI / 6, b = a + PI / 12; return `<path d="M${f1(cx)} ${f1(cy)}L${f1(cx + h * Math.cos(a))} ${f1(cy + h * Math.sin(a))}L${f1(cx + h * Math.cos(b))} ${f1(cy + h * Math.sin(b))}Z" fill="#f2c763"/>`; }).join('')
      + `<g transform="translate(${f1(cx)} ${f1(cy)}) scale(${n4(k)})" stroke="#233047" stroke-width="0.5" stroke-linejoin="round"><path d="M0 -12V-14.5" fill="none"/><circle cy="-15" r="1" fill="#e0533a"/><rect x="-5" y="-12" width="10" height="8" rx="1.4" fill="#c9d3d6"/><circle cx="-2.2" cy="-8.4" r="1.5" fill="#2f8f8a"/><circle cx="2.2" cy="-8.4" r="1.5" fill="#2f8f8a"/><path d="M-2.4 -5.6H2.4M-2.4 -5.6V-4.8M-0.8 -5.6V-4.8M0.8 -5.6V-4.8M2.4 -5.6V-4.8" fill="none"/>`
      + `<rect x="-6" y="-3" width="12" height="10" rx="1.2" fill="#e0533a"/><circle cx="-2.4" cy="0.6" r="1.4" fill="#f1e4c4"/><circle cx="2.4" cy="0.6" r="1.4" fill="#2f8f8a"/><rect x="-3" y="3.4" width="6" height="1.6" fill="#f1e4c4"/><path d="M-6 -1L-9.5 4.5M6 -1L9.5 -5" fill="none" stroke-width="1.6"/><path d="M-11 4.6L-9.5 4.5L-9.4 6.2M8.2 -6.2L9.5 -5L11 -5.4" fill="none"/>`
      + `<path d="M-3.5 7V11.5M3.5 7V11.5" fill="none" stroke-width="1.6"/><rect x="-6" y="11.5" width="4.6" height="1.8" rx="0.6" fill="#233047"/><rect x="1.4" y="11.5" width="4.6" height="1.8" rx="0.6" fill="#233047"/></g>`
      + T(w / 2, h * 0.15, w * 0.24, '#233047', 'ROBO') + T(w / 2, h * 0.95, w * 0.22, '#e0533a', 'PAL', 'stroke="#233047" stroke-width="0.4" paint-order="stroke"'); };
  const artMoon = (p, w, h) => { const R = rng('moon' + p), hz = h * 0.62;
    return `<defs><linearGradient id="${p}s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1b1446"/><stop offset="0.55" stop-color="#6a2a7a"/><stop offset="1" stop-color="#ff8a4a"/></linearGradient><linearGradient id="${p}w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a2160"/><stop offset="1" stop-color="#140b2a"/></linearGradient><radialGradient id="${p}m" cx="42%" cy="38%" r="60%"><stop offset="0" stop-color="#fffdf0"/><stop offset="0.8" stop-color="#ffe6b0"/><stop offset="1" stop-color="#f2c27a"/></radialGradient><radialGradient id="${p}g" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff1c4" stop-opacity="0.7"/><stop offset="1" stop-color="#fff1c4" stop-opacity="0"/></radialGradient></defs>`
      + `<rect width="${f1(w)}" height="${f1(hz)}" fill="url(#${p}s)"/>` + rep(26, () => `<circle cx="${f1(R() * w)}" cy="${f1(R() * hz * 0.7)}" r="${f1(0.15 + R() * 0.25)}" fill="#fff6e0" opacity="${f1(0.5 + R() * 0.5)}"/>`).join('')
      + `<circle cx="${f1(w / 2)}" cy="${f1(h * 0.38)}" r="${f1(w * 0.4)}" fill="url(#${p}g)"/><circle cx="${f1(w / 2)}" cy="${f1(h * 0.38)}" r="${f1(w * 0.2)}" fill="url(#${p}m)"/><circle cx="${f1(w * 0.45)}" cy="${f1(h * 0.35)}" r="${f1(w * 0.035)}" fill="#e8c890" opacity="0.6"/><circle cx="${f1(w * 0.56)}" cy="${f1(h * 0.41)}" r="${f1(w * 0.025)}" fill="#e8c890" opacity="0.5"/>`
      + `<rect y="${f1(hz)}" width="${f1(w)}" height="${f1(h - hz)}" fill="url(#${p}w)"/>` + rep(8, i => `<rect x="${f1(w / 2 - w * (0.16 - i * 0.012))}" y="${f1(hz + 1.2 + i * 2.2)}" width="${f1(w * (0.32 - i * 0.024))}" height="0.6" rx="0.3" fill="#fff1c4" opacity="${f1(0.75 - i * 0.07)}"/>`).join('')
      + `<path d="M${f1(w * 0.18)} ${f1(hz - 0.4)}h${f1(w * 0.2)}l-${f1(w * 0.03)} ${f1(w * 0.04)}h-${f1(w * 0.14)}Z M${f1(w * 0.27)} ${f1(hz - 0.4)}V${f1(hz - w * 0.17)}L${f1(w * 0.35)} ${f1(hz - 0.8)}Z" fill="#140b2a"/>`
      + T(w / 2, h * 0.1, w * 0.16, '#fff1c4', 'MOONLIT', `letter-spacing="${f1(w * 0.02)}"`) + T(w / 2, h * 0.19, w * 0.16, '#ffb36a', 'MATINEE', `letter-spacing="${f1(w * 0.02)}"`)
      + T(w / 2, h * 0.9, w * 0.065, '#fff1c4', 'TONIGHT ONLY', `letter-spacing="${f1(w * 0.02)}"`) + rep(2, i => `<rect x="${f1(w * (0.2 + i * 0.04))}" y="${f1(h * (0.93 + i * 0.025))}" width="${f1(w * (0.6 - i * 0.08))}" height="${f1(h * 0.008)}" fill="#e9d6c0" opacity="0.6"/>`).join(''); };

  // ======================= MOV-004 TORN PAPER MOVIE POSTER WITH SCOTCH TAPE (curled corner flutters) =======================
  N.torn12 = S => { const W = 56, Hh = 80, Z = 0.25, X0 = -W / 2, D = { w: 62, d: 4, mount: 'wall', elev: 48, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), R = rng('torn12');
      const jag = (a, b, n, j) => rep(n, i => { const t = (i + 1) / (n + 1), nx = a[1] - b[1], ny = b[0] - a[0], l = Math.hypot(nx, ny) || 1, o = (R() - 0.5) * 2 * j; return [a[0] + (b[0] - a[0]) * t + nx / l * o, a[1] + (b[1] - a[1]) * t + ny / l * o]; });
      const c0 = [0.4, 0.5], c1 = [W - 8, 0.2], c2 = [W - 0.1, 8], c3 = [W - 0.3, Hh - 15], c4 = [W - 16, Hh - 0.3], c5 = [0.5, Hh - 0.4], r0 = [0.3, Hh * 0.64], r1 = [3.4, Hh * 0.615], r2 = [0.2, Hh * 0.59];
      const torn = [c3, ...jag(c3, c4, 9, 0.9), c4], O = [c0, ...jag(c0, c1, 14, 0.22), c1, c2, ...jag(c2, c3, 12, 0.22), ...torn, ...jag(c4, c5, 10, 0.3), c5, ...jag(c5, r0, 4, 0.2), r0, r1, r2, ...jag(r2, c0, 8, 0.22)];
      const od = pth(O), fl = (Tp, q1, q2) => `M${P2(c1)}L${P2(c2)}Q${P2(q1)} ${P2(Tp)}Q${P2(q2)} ${P2(c1)}Z`;
      const d1 = fl([W - 7.6, 7.6], [W - 3, 7], [W - 7, 3.4]), d2 = fl([W - 6.2, 6.2], [W - 2.6, 5.9], [W - 6, 2.9]);
      const tape = (x, y, L, Wd, rot, op) => { const hl = L / 2, hw = Wd / 2, rt = rep(4, i => `L${f1(hl + (i % 2 ? 0 : 0.45))} ${f1(-hw + (i + 1) * Wd / 4)}`).join(''), lf = rep(4, i => `L${f1(-hl - (i % 2 ? 0 : 0.45))} ${f1(hw - (i + 1) * Wd / 4)}`).join('');
        const d = `M${f1(-hl)} ${f1(-hw)}H${f1(hl)}${rt}L${f1(-hl)} ${f1(hw)}${lf}Z`;
        return `<g transform="translate(${f1(x)} ${f1(y)}) rotate(${rot})" opacity="${op || 1}"><path d="${d}" fill="#fff6c8" opacity="0.8" stroke="#c9b67a" stroke-width="0.35" stroke-linejoin="round"/><path d="M${f1(-hl * 0.6)} ${f1(-hw * 0.45)}H${f1(hl * 0.3)}" stroke="#ffffff" stroke-width="0.5" stroke-linecap="round"/></g>`; };
      const crease = `<path d="M${W / 2} 0V${Hh}M0 ${Hh / 2}H${W}" stroke="#000000" stroke-opacity="0.2" stroke-width="0.5"/><path d="M${W / 2 + 0.45} 0V${Hh}M0 ${Hh / 2 + 0.45}H${W}" stroke="#ffffff" stroke-opacity="0.24" stroke-width="0.35"/><rect x="${W / 2}" width="${W / 2}" height="${Hh}" fill="#000000" opacity="0.04"/><rect y="${Hh / 2}" width="${W}" height="${Hh / 2}" fill="#ffffff" opacity="0.03"/>`;
      const wr = '<g filter="url(#m12b2)"><path d="M7 54Q16 47 25 49" stroke="#000000" stroke-opacity="0.16" stroke-width="1.3" fill="none"/><path d="M7.6 55.2Q16.6 48.2 25.6 50.2" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1" fill="none"/><path d="M36 16Q42 24 40 33" stroke="#000000" stroke-opacity="0.12" stroke-width="1.2" fill="none"/><path d="M37.2 16Q43.2 24 41.2 33" stroke="#ffffff" stroke-opacity="0.12" stroke-width="0.9" fill="none"/></g>';
      const defs = '<defs><clipPath id="tpc"><path d="' + od + '"/></clipPath><linearGradient id="tpg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.45" stop-color="#ffffff" stop-opacity="0.55"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.2"/></linearGradient>'
        + `<linearGradient id="tpb" gradientUnits="userSpaceOnUse" x1="${W - 3.5}" y1="3.5" x2="${W - 7.6}" y2="7.6"><stop offset="0" stop-color="#cfc5ab"/><stop offset="1" stop-color="#f4eddc"/></linearGradient></defs>`;
      let s = WD(C, X0, Hh, 0.06, `<path d="${od}" fill="#000000" opacity="0.35" transform="translate(0.5 0.9)" filter="url(#m12b1)"/>`);
      s += WD(C, X0, Hh, Z, defs + `<g clip-path="url(#tpc)">${artSpace('tp', W, Hh)}${paperFx('tp', W, Hh, 1)}<path d="M${W / 2} 0V${Hh}M0 ${Hh / 2}H${W}" stroke="#ffffff" stroke-opacity="0.18" stroke-width="0.5"/></g>`
        + `<path d="${od}" fill="none" stroke="#3a2a2e" stroke-width="0.8" stroke-linejoin="round"/>`
        + `<path d="${d1}" fill="#000000" opacity="0.32" transform="translate(0.8 1)" filter="url(#m12b1)"/><path d="${d1}" fill="url(#tpb)" stroke="#3a2a2e" stroke-width="0.6" stroke-linejoin="round"><animate attributeName="d" values="${d1};${d2};${d1}" dur="3.4s" repeatCount="indefinite"${SPL(2)}/></path>`
        + tape(2.6, 2.8, 12, 4, -42) + tape(3, Hh - 3.2, 11, 4, 38) + tape(W - 1.2, Hh * 0.46, 10, 3.6, 84) + tape(W - 1.6, 1.8, 6, 3, 45, 0.6), W, Hh);
      return { defs: DEF12, front: s, bb: C.bb(3) }; };
    return D; };

  // ======================= MOV-024 FRAMED RETRO SCI-FI POSTER TRIO =======================
  N.trio12 = S => { const FS = [{ x: -44, w: 36, h: 50, y: 5, a: artRocket }, { x: 0, w: 40, h: 58, y: 1, a: artSaucer }, { x: 44, w: 36, h: 50, y: 5, a: artRobot }], FD = 2.6, FB = 2.4, MI = 3.2, FC = '#1c1b1e';
    const D = { w: 136, d: 6, mount: 'wall', elev: 44, build: () => [] };
    D.fx = ctx => { const C = cam(ctx); let s = '';
      FS.forEach((F, i) => { const x0 = F.x - F.w / 2, yt = F.y + F.h, ow = F.w - 2 * FB, oh = F.h - 2 * FB, aw = ow - 2 * MI, ah = oh - 2 * MI, p = 'tr' + i, e = 0.6;
        s += wsh(C, x0, yt, F.w, F.h, { dx: 1.8, dy: 2.8, op: 0.42 });
        const bev = `<path d="M${f1(MI - e)} ${f1(MI - e)}H${f1(MI + aw + e)}L${f1(MI + aw)} ${MI}H${MI}Z" fill="#d6ccb6"/><path d="M${f1(MI - e)} ${f1(MI + ah + e)}H${f1(MI + aw + e)}L${f1(MI + aw)} ${f1(MI + ah)}H${MI}Z" fill="#fffaf0"/><path d="M${f1(MI - e)} ${f1(MI - e)}V${f1(MI + ah + e)}L${MI} ${f1(MI + ah)}V${MI}Z" fill="#e6ddc9"/><path d="M${f1(MI + aw + e)} ${f1(MI - e)}V${f1(MI + ah + e)}L${f1(MI + aw)} ${f1(MI + ah)}V${MI}Z" fill="#f8f1e2"/>`;
        s += WD(C, x0 + FB, yt - FB, 0.5, `<rect width="${f1(ow)}" height="${f1(oh)}" fill="#efe6d2"/>${bev}<g transform="translate(${MI} ${MI})"><clipPath id="${p}c"><rect width="${f1(aw)}" height="${f1(ah)}"/></clipPath><g clip-path="url(#${p}c)">${F.a(p, aw, ah)}${paperFx(p, aw, ah, 1)}</g></g>`
          + `<rect width="${f1(ow)}" height="2.6" fill="url(#m12rt)"/><rect width="2.2" height="${f1(oh)}" fill="url(#m12rl)"/>`, ow, oh);
        s += innerW(C, x0 + FB, x0 + F.w - FB, F.y + FB, yt - FB, 0.5, FD, FC, 0.95);
        s += box3(C, { c: [F.x, F.y, FD / 2], w: F.w, h: F.h, d: FD, r: 0.3, col: FC, mat: 'brush', gl: 0.5, hole: { f: [FB, FB, FB, FB] }, olc: '#050506', olw: 0.35, edge: 0.3 });
        s += pane(C, [x0 + FB, yt - FB, FD - 0.5], [1, 0, 0], [0, -1, 0], ow, oh, { t: 0.04, g: 0.85, e: 0.25 }); });
      return { defs: DEF12, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-044 BACKLIT MARQUEE LIGHTBOX POSTER FRAME (bulbs chase) =======================
  N.lbox12 = S => { const W = 70, Hh = 100, Dp = 6, BW = 9, HW = 60, HH = 13;
    const D = { w: 80, d: 10, mount: 'wall', elev: 30, build: () => [] };
    const BP = [], L0 = -W / 2 + 4.5, L1 = W / 2 - 4.5, B0 = 4.5, B1 = Hh - 4.5;
    for (let i = 0; i < 9; i++) BP.push([L0 + (L1 - L0) * i / 8, B1]);
    for (let i = 1; i < 12; i++) BP.push([L1, B1 - (B1 - B0) * i / 12]);
    for (let i = 8; i >= 0; i--) BP.push([L0 + (L1 - L0) * i / 8, B0]);
    for (let i = 11; i >= 1; i--) BP.push([L0, B1 - (B1 - B0) * i / 12]);
    D.fx = ctx => { const C = cam(ctx), ow = W - 2 * BW, oh = Hh - 2 * BW; let s = '';
      s += WD(C, -W / 2 - 12, Hh + HH + 12, 0.05, `<rect width="${W + 24}" height="${Hh + HH + 24}" rx="14" fill="#ffc870" opacity="0.3" filter="url(#m11b8)">${an('opacity', '0.22;0.34;0.22', 3.2, 0, SPL(2))}</rect>`);
      s += wsh(C, -W / 2, Hh + HH, W, Hh + HH, { dx: 2.2, dy: 3.2, op: 0.5 });
      s += WD(C, -W / 2 + BW, Hh - BW, 1.2, `<defs><radialGradient id="lbh" cx="50%" cy="45%" r="60%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient></defs>${artMoon('lb', ow, oh)}<rect width="${ow}" height="${oh}" fill="url(#lbh)"/>`
        + `<rect x="0.6" y="0.6" width="${ow - 1.2}" height="${oh - 1.2}" fill="none" stroke="#e2e5e8" stroke-width="1.2"/><rect x="1.2" y="1.2" width="${ow - 2.4}" height="${oh - 2.4}" fill="none" stroke="#8a8f95" stroke-width="0.25"/>`, ow, oh);
      s += innerW(C, -W / 2 + BW, W / 2 - BW, BW, Hh - BW, 1.2, Dp, '#d4d8dc', 0.95);
      const sock = BP.map(([x, y]) => `<circle cx="${f1(x + W / 2)}" cy="${f1(Hh - y)}" r="1.9" fill="#232326" stroke="#c9a24a" stroke-width="0.3"/>`).join('');
      s += box3(C, { c: [0, 0, Dp / 2], w: W, h: Hh, d: Dp, r: 0.8, col: '#141416', gl: 0.5, hole: { f: [BW, BW, BW, BW] }, dec: { f: `<rect x="1.2" y="1.2" width="${W - 2.4}" height="${Hh - 2.4}" rx="0.6" fill="none" stroke="#c9a24a" stroke-width="0.45"/><rect x="${BW - 1}" y="${BW - 1}" width="${ow + 2}" height="${oh + 2}" fill="none" stroke="#c9a24a" stroke-width="0.45"/>${sock}` }, olc: '#050506', olw: 0.4, edge: 0.3 });
      const hdr = `<rect x="2.4" y="2.2" width="${HW - 4.8}" height="8.6" rx="0.8" fill="#fff8e6"/><rect x="2.4" y="2.2" width="${HW - 4.8}" height="8.6" rx="0.8" fill="url(#lbh)"/>` + T(HW / 2, 8.6, 5.4, '#c8202a', 'NOW PLAYING', 'letter-spacing="0.5"') + `<rect x="2.4" y="2.2" width="${HW - 4.8}" height="8.6" rx="0.8" fill="none" stroke="#c9a24a" stroke-width="0.4"/>`;
      s += box3(C, { c: [0, Hh, 2.6], w: HW, h: HH, d: 5.2, r: 0.8, col: '#141416', gl: 0.5, dec: { f: hdr }, olc: '#050506', olw: 0.4, edge: 0.3 });
      s += pane(C, [-W / 2 + BW, Hh - BW, Dp - 0.6], [1, 0, 0], [0, -1, 0], ow, oh, { t: 0.03, g: 0.6, e: 0.2 });
      BP.forEach(([x, y], i) => { const q = [x, y, Dp + 1.1], c = C.P(q), ph = i % 4;
        s += sph(C, q, 1.3, '#9c875c') + `<g opacity="1"><animate attributeName="opacity" values="1;1;0.08;0.08" keyTimes="0;0.25;0.5;0.75" calcMode="discrete" dur="1.6s" begin="${n4(-ph * 0.4)}s" repeatCount="indefinite"/><circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(C.k * 3.8)}" fill="url(#m11warm)"/>${sph(C, q, 1.3, '#fff2c4')}</g>`; });
      return { defs: DEF12, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-064 SIGNED GOLDEN AGE PROP REPLICA SHADOWBOX =======================
  N.sbox12 = S => { const W = 64, Hh = 82, Dp = 11, Tk = 5, WO = '#5a3420', BR = '#d4a640';
    const D = { w: 70, d: 18, mount: 'wall', elev: 40, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), iw = W - 2 * Tk, ih = Hh - 2 * Tk, rail = (c, w, h, f) => box3(C, { c, w, h, d: Dp, r: 0.5, col: WO, mat: 'wood', gl: 0.35, dec: f ? { f } : null, olc: '#1e0f06', olw: 0.35, edge: 0.25 }); let s = '';
      s += wsh(C, -W / 2, Hh, W, Hh, { dx: 2.6, dy: 3.6, op: 0.5 });
      const photo = `<defs><linearGradient id="sbp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9c9c9c"/><stop offset="1" stop-color="#3a3a3a"/></linearGradient><radialGradient id="sbf" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#f2f2f2"/><stop offset="1" stop-color="#9a9a9a"/></radialGradient></defs><g transform="rotate(-4 11 14)"><rect x="0.5" y="0.8" width="22" height="28" fill="#000000" opacity="0.4" filter="url(#m12b1)"/><rect width="22" height="28" fill="#f4efe4"/><rect x="1.6" y="1.6" width="18.8" height="20" fill="url(#sbp)"/>`
        + `<path d="M3.6 21.6Q4.6 15.6 11 15.2Q17.4 15.6 18.4 21.6Z" fill="#2a2a2a"/><ellipse cx="11" cy="10" rx="3.6" ry="4.4" fill="url(#sbf)"/><path d="M7.2 9.4Q7 4.6 11.2 4.8Q15.4 5 14.8 9.6Q13.6 6.8 11 7.2Q8.6 7.4 7.2 9.4Z" fill="#1a1a1a"/><path d="M9.4 15.2L11 18L12.6 15.2" fill="#e8e8e8"/><path d="M8.8 8.9Q9.6 8.4 10.3 8.9M11.7 8.9Q12.4 8.4 13.2 8.9" stroke="#3a3a3a" stroke-width="0.3" fill="none"/><ellipse cx="9.6" cy="9.6" rx="0.5" ry="0.32" fill="#3a3a3a"/><ellipse cx="12.4" cy="9.6" rx="0.5" ry="0.32" fill="#3a3a3a"/><path d="M11 10.2L10.7 11.6H11.3" stroke="#8a8a8a" stroke-width="0.2" fill="none"/><path d="M10 12.6Q11 13.3 12 12.6Q11 12.2 10 12.6Z" fill="#5a5a5a"/><path d="M14.2 9.6Q15.6 12 14.6 14.4Q16.4 12 15 8.4Z" fill="#1a1a1a"/>`
        + `<path d="M3 25.4c2 -3 3 1 4.5 -1s2 -2 2.6 0.5c0.6 1.6 2 -2.4 3.4 -0.6s1.6 0.8 3.4 -1.2M4 26.6c4 -0.6 9 -0.8 13 -0.2" stroke="#1d3a9a" stroke-width="0.45" fill="none" stroke-linecap="round"/><rect width="22" height="28" fill="url(#m12gl)"/></g>`;
      s += WD(C, -iw / 2, Hh - Tk, 0.3, `<defs><radialGradient id="sbl" cx="50%" cy="4%" r="95%"><stop offset="0" stop-color="#fff0c8" stop-opacity="0.38"/><stop offset="0.6" stop-color="#fff0c8" stop-opacity="0.05"/><stop offset="1" stop-color="#000000" stop-opacity="0.3"/></radialGradient></defs><rect width="${iw}" height="${ih}" fill="#1f3a2d"/><rect width="${iw}" height="${ih}" fill="url(#sbl)"/>`
        + `<g transform="translate(3 4)">${photo}</g><rect width="${iw}" height="4" fill="url(#m12rt)"/><rect width="3" height="${ih}" fill="url(#m12rl)"/>`, iw, ih);
      const plq = `<rect x="${W / 2 - 13}" y="1" width="26" height="3" rx="0.4" fill="url(#sbb)"/><rect x="${W / 2 - 13}" y="1" width="26" height="3" rx="0.4" fill="none" stroke="#7a5a1c" stroke-width="0.2"/>` + T(W / 2, 3, 1.35, '#4a3410', 'GOLDEN AGE · SIGNED REPLICA · 1939', 'letter-spacing="0.15"');
      s += `<defs><linearGradient id="sbb" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6dc8a"/><stop offset="0.5" stop-color="#c99a3a"/><stop offset="1" stop-color="#8a6420"/></linearGradient></defs>`;
      s += rail([0, 0, Dp / 2], W, Tk, plq) + rail([-W / 2 + Tk / 2, Tk, Dp / 2], Tk, ih) + rail([W / 2 - Tk / 2, Tk, Dp / 2], Tk, ih);
      // cane leaning on the right, top hat on the floor
      s += H.shadow(C, 13, 4, 3, 2, 0.7, Tk + 0.02) + cyl3(C, [15, Tk, 4.2], [6, Hh - Tk - 6, 2.6], 0.85, '#141416', { mat: 'gloss', olw: 0.25 }) + cyl3(C, [15, Tk, 4.2], [14.7, Tk + 2.4, 4.15], 0.95, BR, { mat: 'metal', olw: 0.2 })
        + cyl3(C, [6.6, Hh - Tk - 10.2, 2.7], [6.3, Hh - Tk - 8.2, 2.65], 1, '#d9dce0', { mat: 'chrome', olw: 0.2 }) + sph(C, [6, Hh - Tk - 6, 2.6], 2.1, BR);
      const hx = -10, hz = 5.5;
      s += H.shadow(C, hx + 1, hz + 0.6, 6.2, 4, 0.9, Tk + 0.02) + cyl3(C, [hx, Tk, hz], [hx, Tk + 0.7, hz], 5.4, '#1b1b1e', { mat: 'gloss', olw: 0.3 })
        + cyl3(C, [hx, Tk + 0.7, hz], [hx, Tk + 12, hz], 3.8, '#141417', { r2: 4.1, mat: 'gloss', olw: 0.3 }) + cyl3(C, [hx, Tk + 0.7, hz], [hx, Tk + 3, hz], 3.86, '#6a1a2a', { r2: 3.92, mat: 'gloss', noCap: 1, olw: 0.2 });
      s += rail([0, Hh - Tk, Dp / 2], W, Tk);
      s += pane(C, [-iw / 2, Hh - Tk, Dp - 0.4], [1, 0, 0], [0, -1, 0], iw, ih, { t: 0.05, g: 0.9, e: 0.3 });
      s += WD(C, -iw / 2, Hh - Tk, Dp - 0.3, `<defs><linearGradient id="sbw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe4a8" stop-opacity="0.3"/><stop offset="1" stop-color="#ffe4a8" stop-opacity="0"/></linearGradient></defs><path d="M${iw / 2 - 14} 0H${iw / 2 + 14}L${iw} ${ih * 0.6}H0Z" fill="url(#sbw)"/>`);
      [-10, 10].forEach(x => s += cyl3(C, [x, Hh - 1.6, Dp], [x, Hh + 2.4, Dp + 3.6], 0.5, BR, { mat: 'metal', olw: 0.2 }));
      s += cyl3(C, [-14, Hh + 2.9, Dp + 4.2], [14, Hh + 2.9, Dp + 4.2], 1.8, BR, { mat: 'metal', olw: 0.3 });
      return { defs: DEF12, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-084 ANIMATED LIVING-INK HOLO-POSTER GALLERY =======================
  const aNeb = (p, w, h) => { const R = rng('neb' + p), st = rep(26, () => [R() * w, R() * h, 0.6 + R() * 1.8, R()]);
    const field = dy => st.map(([x, y, l, o]) => `<path d="M${f1(x)} ${f1(y + dy)}v${f1(l)}" stroke="#dff6ff" stroke-opacity="${f1(0.35 + o * 0.6)}" stroke-width="0.35" stroke-linecap="round"/>`).join('');
    return `<defs><radialGradient id="${p}b" cx="50%" cy="45%" r="75%"><stop offset="0" stop-color="#3a1f7a"/><stop offset="0.55" stop-color="#160c3a"/><stop offset="1" stop-color="#05030f"/></radialGradient><radialGradient id="${p}n" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ff5fb4" stop-opacity="0.55"/><stop offset="1" stop-color="#ff5fb4" stop-opacity="0"/></radialGradient></defs><rect width="${f1(w)}" height="${f1(h)}" fill="url(#${p}b)"/>`
      + `<ellipse cx="${f1(w * 0.3)}" cy="${f1(h * 0.66)}" rx="${f1(w * 0.5)}" ry="${f1(h * 0.2)}" fill="url(#${p}n)">${an('opacity', '0.6;1;0.6', 5, 0, SPL(2))}</ellipse>`
      + `<g>${at('translate', `0 0;0 ${f1(h)}`, 2.6)}${field(0)}${field(-h)}</g>`
      + `<g transform="translate(${f1(w / 2)} ${f1(h * 0.56)}) scale(${n4(w / 30)})"><g>${at('translate', '0 -1;0 1;0 -1', 2.2, 0, SPL(2))}<g transform="translate(0 9)"><g>${at('scale', '1 1;1 1.4;1 0.85;1 1', 0.32)}<path d="M-2.4 0Q0 9 2.4 0Z" fill="#ffb02e"/><path d="M-1.2 0Q0 5 1.2 0Z" fill="#fff6c0"/></g></g>`
      + `<path d="M0 -12C4 -8 4.2 0 3 9H-3C-4.2 0 -4 -8 0 -12Z" fill="#e8eef6"/><path d="M0 -12C2 -10 2.6 -7.6 2.8 -6H-2.8C-2.6 -7.6 -2 -10 0 -12Z" fill="#3fd0ff"/><path d="M-3 3L-6.5 9.5L-3 8.6ZM3 3L6.5 9.5L3 8.6Z" fill="#3fd0ff"/><circle cy="-2" r="1.6" fill="#ff5fb4" stroke="#5a5f6a" stroke-width="0.5"/></g></g>`
      + T(w / 2, h * 0.12, w * 0.11, '#7ff0ff', 'NEBULA RUN', 'letter-spacing="0.3"'); };
  const aInk = (p, w, h) => { const P = w / 2;
    const wave = (yb, amp, col, op, dur, rev) => { let d = `M${f1(-w)} ${f1(yb)}Q${f1(-w + P / 4)} ${f1(yb - amp)} ${f1(-w + P / 2)} ${f1(yb)}`; for (let x = -w + P; x <= 2 * w + 0.01; x += P / 2) d += `T${f1(x)} ${f1(yb)}`; d += `V${f1(h + 2)}H${f1(-w)}Z`;
      return `<path d="${d}" fill="${col}" opacity="${op}">${at('translate', rev ? `${f1(P)} 0;0 0` : `0 0;${f1(P)} 0`, dur)}</path>`; };
    return `<defs><linearGradient id="${p}b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0b1430"/><stop offset="1" stop-color="#1b2d5a"/></linearGradient><radialGradient id="${p}g" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff1c8" stop-opacity="0.6"/><stop offset="1" stop-color="#fff1c8" stop-opacity="0"/></radialGradient></defs><rect width="${f1(w)}" height="${f1(h)}" fill="url(#${p}b)"/>`
      + `<circle cx="${f1(w * 0.68)}" cy="${f1(h * 0.3)}" r="${f1(w * 0.3)}" fill="url(#${p}g)">${an('opacity', '0.6;1;0.6', 4, 0, SPL(2))}</circle><circle cx="${f1(w * 0.68)}" cy="${f1(h * 0.3)}" r="${f1(w * 0.12)}" fill="#fff1c8"/>`
      + rep(2, i => `<circle cx="${f1(w * (0.28 + i * 0.12))}" cy="${f1(h * (0.4 + i * 0.06))}" r="1" fill="none" stroke="#8fd4ff" stroke-width="0.4"><animate attributeName="r" values="0.5;${f1(w * 0.3)}" dur="4s" begin="${-i * 2}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.8;0" dur="4s" begin="${-i * 2}s" repeatCount="indefinite"/></circle>`).join('')
      + wave(h * 0.6, 1.6, '#2a5aa8', 0.75, 7) + wave(h * 0.7, 2, '#3f86d8', 0.8, 5, 1) + wave(h * 0.82, 2.4, '#8fd4ff', 0.9, 3.6)
      + T(w / 2, h * 0.12, w * 0.12, '#ffe9a8', 'INK TIDE', 'letter-spacing="0.4"'); };
  const aSq = (p, w, h) => { const k = w / 34, cx = w / 2, by = h * 0.8;
    return `<defs><radialGradient id="${p}b" cx="50%" cy="55%" r="70%"><stop offset="0" stop-color="#ffb3d6"/><stop offset="1" stop-color="#c2408a"/></radialGradient><radialGradient id="${p}c" cx="36%" cy="30%" r="75%"><stop offset="0" stop-color="#c8a8ff"/><stop offset="0.6" stop-color="#8a5cff"/><stop offset="1" stop-color="#5a2fc8"/></radialGradient></defs><rect width="${f1(w)}" height="${f1(h)}" fill="url(#${p}b)"/>`
      + `<g transform="translate(${f1(cx)} ${f1(h * 0.56)})"><g>${at('rotate', '0;360', 24)}${rep(12, i => { const a = i * PI / 6, b = a + PI / 12; return `<path d="M0 0L${f1(h * Math.cos(a))} ${f1(h * Math.sin(a))}L${f1(h * Math.cos(b))} ${f1(h * Math.sin(b))}Z" fill="#ffffff" opacity="0.13"/>`; }).join('')}</g></g>`
      + `<ellipse cx="${f1(cx)}" cy="${f1(by + 0.6)}" rx="${f1(9 * k)}" ry="${f1(1.6 * k)}" fill="#5a1a4a" opacity="0.35"><animate attributeName="rx" values="${f1(9 * k)};${f1(6 * k)};${f1(9 * k)}" dur="1.1s" repeatCount="indefinite"${SPL(2)}/></ellipse>`
      + `<g transform="translate(${f1(cx)} ${f1(by)})"><g>${at('translate', '0 0;0 -6;0 0', 1.1, 0, SPL(2))}<g>${at('scale', '1.12 0.88;0.95 1.06;1.12 0.88', 1.1, 0, SPL(2))}<g transform="scale(${n4(k)})">`
      + `<path d="M-9 0C-9.5 -8 -5.5 -13 0 -13C5.5 -13 9.5 -8 9 0Z" fill="url(#${p}c)"/><ellipse cx="-3.6" cy="-9.6" rx="2.4" ry="1.4" fill="#ffffff" opacity="0.45"/><ellipse cx="-5" cy="-4" rx="1.4" ry="0.8" fill="#ff8ac8" opacity="0.7"/><ellipse cx="5" cy="-4" rx="1.4" ry="0.8" fill="#ff8ac8" opacity="0.7"/>`
      + `<g transform="translate(0 -7)"><g><animateTransform attributeName="transform" type="scale" values="1 1;1 1;1 0.1;1 1" keyTimes="0;0.9;0.95;1" dur="3.2s" repeatCount="indefinite"/><circle cx="-3" r="1.7" fill="#ffffff"/><circle cx="3" r="1.7" fill="#ffffff"/><circle cx="-2.7" cy="0.3" r="0.95" fill="#2a1450"/><circle cx="3.3" cy="0.3" r="0.95" fill="#2a1450"/></g></g>`
      + `<path d="M-2 -3.4Q0 -1.4 2 -3.4" stroke="#2a1450" stroke-width="0.6" fill="none" stroke-linecap="round"/></g></g></g></g>`
      + `<g transform="translate(${f1(w / 2)} ${f1(h * 0.15)})"><g>${at('scale', '1;1.08;1', 1.1, 0, SPL(2))}${T(0, 0, w * 0.17, '#ffffff', 'SQUISH!', `stroke="#6a2fc8" stroke-width="${f1(w * 0.02)}" paint-order="stroke"`)}</g></g>`; };
  N.holo12 = S => { const FS = [{ x: -44, w: 34, h: 48, y: 6, a: aNeb, c: '#3fd0ff' }, { x: 0, w: 38, h: 56, y: 2, a: aInk, c: '#7f8cff' }, { x: 44, w: 34, h: 48, y: 6, a: aSq, c: '#ff5fb4' }], FD = 1.6, FB = 1.4;
    const D = { w: 132, d: 6, mount: 'wall', elev: 44, build: () => [] };
    D.fx = ctx => { const C = cam(ctx); let s = '';
      FS.forEach((F, i) => { const x0 = F.x - F.w / 2, yt = F.y + F.h, ow = F.w - 2 * FB, oh = F.h - 2 * FB, p = 'hg' + i;
        s += WD(C, x0 - 4, yt + 4, 0.05, `<rect width="${F.w + 8}" height="${F.h + 8}" rx="5" fill="${F.c}" opacity="0.5" filter="url(#m11b4)">${an('opacity', '0.35;0.6;0.35', 3 + i * 0.6, 0, SPL(2))}</rect>`);
        s += wsh(C, x0, yt, F.w, F.h, { dx: 1.2, dy: 2, op: 0.4 });
        s += WD(C, x0 + FB, yt - FB, 0.7, `<clipPath id="${p}c"><rect width="${f1(ow)}" height="${f1(oh)}"/></clipPath><g clip-path="url(#${p}c)">${F.a(p, ow, oh)}<rect width="${f1(ow)}" height="${f1(oh)}" fill="url(#m12scan)"/><rect x="${f1(-ow * 0.6)}" width="${f1(ow * 0.45)}" height="${f1(oh)}" fill="url(#m12sh)" transform="skewX(-18)">${at('translate', `0 0;0 0;${f1(ow * 2.4)} 0`, 5.5, -i * 1.7, ' keyTimes="0;0.55;1" additive="sum"')}</rect></g>`
          + `<rect x="0.25" y="0.25" width="${f1(ow - 0.5)}" height="${f1(oh - 0.5)}" fill="none" stroke="${F.c}" stroke-width="0.5" opacity="0.8">${an('opacity', '0.5;0.95;0.5', 2.4 + i * 0.4)}</rect>`, ow, oh);
        s += innerW(C, x0 + FB, x0 + F.w - FB, F.y + FB, yt - FB, 0.7, FD, '#16171c', 0.9);
        s += box3(C, { c: [F.x, F.y, FD / 2], w: F.w, h: F.h, d: FD, r: 0.3, col: '#101116', gl: 0.9, hole: { f: [FB, FB, FB, FB] }, olc: '#020203', olw: 0.3, edge: 0.4 });
        s += pane(C, [x0 + FB, yt - FB, FD - 0.3], [1, 0, 0], [0, -1, 0], ow, oh, { t: 0.02, g: 0.7, e: 0.2 }); });
      return { defs: DEF12, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-018 PAPER LANTERN STRING LIGHTS (lanterns sway, glow flickers) =======================
  N.lant12 = S => { const COL = ['#fff0cc', '#ffb8cb', '#c4f2d8', '#c4e2ff', '#dccbff', '#ffd3aa', '#fff2a6'], HX = 76, HY = 100, SAG = 17, XS = [-57, -38, -19, 0, 19, 38, 57];
    const D = { w: 160, d: 16, mount: 'wall', elev: 24, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), cy = x => HY - SAG * (1 - (x / HX) ** 2), cz = x => 1.4 + 3.4 * (1 - (x / HX) ** 2);
      const defs = COL.map((c, i) => `<radialGradient id="ln${i}" cx="44%" cy="40%" r="62%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.3" stop-color="${shade(c, 1.06)}"/><stop offset="0.8" stop-color="${c}"/><stop offset="1" stop-color="${shade(c, 0.7)}"/></radialGradient><radialGradient id="lw${i}" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="${c}" stop-opacity="0.75"/><stop offset="0.45" stop-color="${c}" stop-opacity="0.22"/><stop offset="1" stop-color="${c}" stop-opacity="0"/></radialGradient>`).join('');
      let s = `<defs>${defs}</defs>`;
      XS.forEach((x, i) => { const r = i % 2 ? 6 : 7, ly = cy(x) - 2.6 - r; s += WD(C, x - 18, ly + 18, 0.05, `<circle cx="18" cy="18" r="18" fill="url(#lw${i})">${an('opacity', '0.8;1;0.85;1;0.8', 3 + i * 0.37)}</circle>`, 36, 36); });
      const cp = rep(41, j => { const x = -HX + j * 2 * HX / 40; return C.p(x, cy(x), cz(x)); }), cd = ln(cp);
      s += `<path d="${cd}" stroke="#000000" stroke-opacity="0.2" stroke-width="${f1(C.k * 0.9)}" fill="none" transform="translate(${f1(C.k * 0.8)} ${f1(C.k * 1.8)})" filter="url(#m12b1)"/><path d="${cd}" stroke="#2c2622" stroke-width="${f1(C.k * 0.55)}" fill="none" stroke-linecap="round"/><path d="${cd}" stroke="#8a7a6a" stroke-opacity="0.5" stroke-width="${f1(C.k * 0.18)}" fill="none" transform="translate(0 ${f1(-C.k * 0.15)})"/>`;
      [-HX, HX].forEach(x => s += cyl3(C, [x, HY, 0], [x, HY, 1.8], 0.55, '#c9ccd0', { mat: 'chrome', olw: 0.2 }) + sph(C, [x, HY, 1.9], 0.8, '#d9dce0'));
      XS.forEach((x, i) => { const r = i % 2 ? 6 : 7, c = COL[i], q0 = C.p(x, cy(x), cz(x)), ctr = C.p(x, cy(x) - 2.6 - r * 0.92, cz(x) + 0.6), R = r * C.k, ry = R * 0.92, wy = ctr[1] - ry, a = 3 + (i % 3);
        let L = `<path d="M${P2(q0)}L${f1(ctr[0])} ${f1(wy)}" stroke="#3a332c" stroke-width="${f1(C.k * 0.22)}"/><ellipse cx="${f1(ctr[0])}" cy="${f1(ctr[1])}" rx="${f1(R)}" ry="${f1(ry)}" fill="url(#ln${i})"/>`
          + `<ellipse cx="${f1(ctr[0] - R * 0.08)}" cy="${f1(ctr[1] - ry * 0.06)}" rx="${f1(R * 0.42)}" ry="${f1(ry * 0.42)}" fill="#ffffff" opacity="0.35">${an('opacity', '0.22;0.45;0.3;0.42;0.22', 2.2 + i * 0.3)}</ellipse>`;
        for (let k = -2; k <= 2; k++) { const yy = ctr[1] + k * ry * 0.34, hw = R * Math.sqrt(Math.max(0, 1 - (k * 0.34) ** 2)); L += `<path d="M${f1(ctr[0] - hw)} ${f1(yy)}Q${f1(ctr[0])} ${f1(yy + R * 0.12)} ${f1(ctr[0] + hw)} ${f1(yy)}" fill="none" stroke="${shade(c, 0.6)}" stroke-opacity="0.42" stroke-width="${f1(C.k * 0.16)}"/>`; }
        L += `<path d="M${f1(ctr[0])} ${f1(wy)}Q${f1(ctr[0] + R * 0.1)} ${f1(ctr[1])} ${f1(ctr[0])} ${f1(ctr[1] + ry)}" fill="none" stroke="${shade(c, 0.6)}" stroke-opacity="0.2" stroke-width="${f1(C.k * 0.14)}"/><ellipse cx="${f1(ctr[0])}" cy="${f1(ctr[1])}" rx="${f1(R)}" ry="${f1(ry)}" fill="none" stroke="${shade(c, 0.4)}" stroke-width="${f1(C.k * 0.45)}"/>`
          + `<ellipse cx="${f1(ctr[0])}" cy="${f1(wy + R * 0.04)}" rx="${f1(R * 0.34)}" ry="${f1(R * 0.12)}" fill="#2a2420"/><ellipse cx="${f1(ctr[0])}" cy="${f1(ctr[1] + ry - R * 0.04)}" rx="${f1(R * 0.3)}" ry="${f1(R * 0.11)}" fill="#2a2420"/><path d="M${f1(ctr[0] - R * 0.25)} ${f1(wy)}H${f1(ctr[0] + R * 0.1)}" stroke="#7a6a5a" stroke-width="${f1(C.k * 0.15)}"/>`;
        s += `<g><animateTransform attributeName="transform" type="rotate" values="${-a} ${P2(q0)};${a} ${P2(q0)};${-a} ${P2(q0)}" dur="${n4(3.2 + i * 0.41)}s" begin="${n4(-i * 0.7)}s" repeatCount="indefinite"${SPL(2)}/>${L}</g>`; });
      ext(C, [[-HX - 2, HY + 3, 0], [HX + 2, cy(0) - 20, 0]]);
      return { defs: DEF12, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-038 RETRO NEON 'NOW SHOWING' WALL SIGN (glass tubes, flicker) =======================
  const GL = { N: [0.62, 'M0 1L0 0L1 1L1 0'], O: [0.7, 'M0.5 0C0.1 0 0 0.3 0 0.5C0 0.7 0.1 1 0.5 1C0.9 1 1 0.7 1 0.5C1 0.3 0.9 0 0.5 0Z'], W: [0.9, 'M0 0L0.25 1L0.5 0.35L0.75 1L1 0'],
    S: [0.55, 'M0.95 0.15C0.8 0 0.2 -0.02 0.08 0.2C-0.02 0.42 0.3 0.48 0.5 0.52C0.75 0.57 1.02 0.62 0.94 0.82C0.85 1.04 0.2 1.02 0.04 0.85'], H: [0.6, 'M0 0L0 1M1 0L1 1M0 0.5L1 0.5'], I: [0, 'M0 0L0 1'], G: [0.68, 'M0.95 0.18C0.85 0.04 0.7 0 0.5 0C0.15 0 0 0.25 0 0.5C0 0.78 0.18 1 0.5 1C0.8 1 1 0.82 1 0.55L0.55 0.55'] };
  const GS = (d, x0, y0, w, h) => d.replace(/(-?\d*\.?\d+) (-?\d*\.?\d+)/g, (m, a, b) => f1(x0 + a * w) + ' ' + f1(y0 + b * h));
  const word = (str, cx, y, hg, gap) => { const ws = str.split('').map(ch => GL[ch][0] * hg), tw = ws.reduce((a, b) => a + b, 0) + gap * (str.length - 1); let x = cx - tw / 2, d = '';
    str.split('').forEach((ch, i) => { d += GS(GL[ch][1], x, y, ws[i], hg); x += ws[i] + gap; }); return d; };
  const tube = (d, col, ex) => `<g fill="none" stroke-linecap="round" stroke-linejoin="round">${ex || ''}<path d="${d}" stroke="${col}" stroke-width="4.6" opacity="0.35" filter="url(#m12b2)"/><path d="${d}" stroke="${col}" stroke-width="2.2"/><path d="${d}" stroke="#ffffff" stroke-width="0.7" opacity="0.8"/></g>`;
  N.neon12 = S => { const W = 118, Hh = 62;
    const D = { w: 124, d: 10, mount: 'wall', elev: 50, build: () => [] };
    D.fx = ctx => { const C = cam(ctx);
      const bd = 'M10 4.5H108Q113.5 4.5 113.5 10V52Q113.5 57.5 108 57.5H10Q4.5 57.5 4.5 52V10Q4.5 4.5 10 4.5Z', nw = word('NOW', 59, 9, 20, 4), sw = word('SHOWING', 59, 36, 12, 3);
      const FLK = an('opacity', '1;1;0.25;1;0.4;1;1', 6, 0, ' keyTimes="0;0.8;0.81;0.83;0.84;0.86;1"');
      const chev = (x, dir, i) => `<g opacity="0.2">${an('opacity', '0.15;1;0.15', 1.2, -((dir > 0 ? i : 2 - i) * 0.4))}${tube(`M${f1(x)} 38.5L${f1(x + 2.6 * dir)} 42L${f1(x)} 45.5`, '#ffb347')}</g>`;
      const tubes = tube(bd, '#ffb347') + tube(nw, '#ff4fa0', FLK) + tube(sw, '#3fe0ff') + rep(3, i => chev(16.5 - i * 3.6, -1, i) + chev(101.5 + i * 3.6, 1, i)).join('');
      let s = WD(C, -W / 2 - 16, Hh + 16, 0.05, `<defs><linearGradient id="ngw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff4fa0"/><stop offset="1" stop-color="#3fe0ff"/></linearGradient></defs><rect width="${W + 32}" height="${Hh + 32}" rx="22" fill="url(#ngw)" opacity="0.4" filter="url(#m11b8)">${an('opacity', '0.32;0.45;0.32', 4)}</rect>`);
      s += wsh(C, -W / 2, Hh, W, Hh, { dx: 1.4, dy: 2.2, op: 0.45 });
      s += box3(C, { c: [0, 0, 1.6], w: W, h: Hh, d: 2.4, r: 2.4, col: '#16151b', mat: 'noise', gl: 0.55, olc: '#050506', olw: 0.35, edge: 0.3 });
      s += WD(C, -W / 2, Hh, 2.85, `<g opacity="0.5" filter="url(#m11b4)" fill="none" stroke-width="3"><path d="${bd}" stroke="#ffb347"/><path d="${nw}" stroke="#ff4fa0">${FLK}</path><path d="${sw}" stroke="#3fe0ff"/></g>`, W, Hh);
      [[-54, 4], [54, 4], [-54, 58], [54, 58]].forEach(([x, y]) => s += cyl3(C, [x, y, 2.8], [x, y, 3.8], 1.4, '#d9dce0', { mat: 'chrome', olw: 0.2 }));
      s += WD(C, -W / 2, Hh, 4.2, tubes, W, Hh);
      return { defs: DEF12, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-058 BRUSHED BRONZE UP-DOWN THEATER SCONCES =======================
  N.bron12 = S => { const BZ = '#8e6334', SX = [-27, 27], Y0 = 44, Y1 = 68, ZC = 8, RR = 5.4;
    const D = { w: 86, d: 16, mount: 'wall', elev: 28, build: () => [] };
    D.fx = ctx => { const C = cam(ctx);
      let s = '<defs><linearGradient id="bmU" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffdca0" stop-opacity="0.95"/><stop offset="0.35" stop-color="#ffc870" stop-opacity="0.45"/><stop offset="1" stop-color="#ffd690" stop-opacity="0"/></linearGradient><linearGradient id="bmD" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffdca0" stop-opacity="0.9"/><stop offset="0.35" stop-color="#ffc870" stop-opacity="0.4"/><stop offset="1" stop-color="#ffd690" stop-opacity="0"/></linearGradient><radialGradient id="bmH" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff6de" stop-opacity="0.95"/><stop offset="1" stop-color="#fff6de" stop-opacity="0"/></radialGradient></defs>';
      SX.forEach(x => { s += WD(C, x - 17, Y1 + 40, 0.05, `<path d="M12.4 40L0 5Q17 -3 34 5L21.6 40Z" fill="url(#bmU)"/><ellipse cx="17" cy="40" rx="8" ry="3.4" fill="url(#bmH)"/>`, 34, 44)
          + WD(C, x - 15, Y0, 0.05, `<path d="M12.6 0L0 32Q15 38 30 32L17.4 0Z" fill="url(#bmD)"/><ellipse cx="15" cy="0" rx="7" ry="3" fill="url(#bmH)"/>`, 30, 36);
        s += box3(C, { c: [x, 49, 0.45], w: 7.6, h: 14, d: 0.9, r: 0.9, col: BZ, mat: 'brush', gl: 0.4, olw: 0.25 }) + cyl3(C, [x, 56, 0.9], [x, 56, ZC - RR + 0.4], 1.5, BZ, { mat: 'metal', olw: 0.25 });
        s += cyl3(C, [x, Y0, ZC], [x, Y1, ZC], RR, BZ, { mat: 'metal', olw: 0.35, capCol: '#fff0cc', cap: cr => `<circle r="${f1(cr * 0.86)}" fill="none" stroke="#5a3c1c" stroke-width="${f1(cr * 0.14)}"/><circle r="${f1(cr * 0.5)}" fill="#ffffff" opacity="0.75"/>` });
        [Y0 + 2.4, Y1 - 3.2].forEach(y => s += cyl3(C, [x, y, ZC], [x, y + 0.8, ZC], RR + 0.25, shade(BZ, 0.72), { mat: 'metal', noCap: 1, olw: 0.2 }));
        const t = C.p(x, Y1, ZC), b = C.p(x, Y0, ZC); s += `<ellipse cx="${f1(t[0])}" cy="${f1(t[1])}" rx="${f1(RR * C.k * 1.6)}" ry="${f1(RR * C.k * 0.7)}" fill="url(#bmH)" opacity="0.55"/><ellipse cx="${f1(b[0])}" cy="${f1(b[1] + C.k * 0.6)}" rx="${f1(RR * C.k * 1.1)}" ry="${f1(RR * C.k * 0.45)}" fill="url(#bmH)" opacity="0.45"/>`; });
      return { defs: DEF12, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-078 SMART RGBW DOLBY-SYNCED LIGHT BARS (colour waves + beat pulse) =======================
  N.rgbw12 = S => { const BX = [-42, 42], Y0 = 6, BH = 88;
    const D = { w: 110, d: 10, mount: 'wall', elev: 26, build: () => [] };
    const STO = '<stop offset="0" stop-color="#ff3b7a"/><stop offset="0.2" stop-color="#ffb13b"/><stop offset="0.38" stop-color="#f4ffef"/><stop offset="0.55" stop-color="#3bffb0"/><stop offset="0.75" stop-color="#3bb4ff"/><stop offset="0.9" stop-color="#a64bff"/><stop offset="1" stop-color="#ff3b7a"/>';
    const G = (id, L, rev, dur) => `<linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="${L}" spreadMethod="repeat">${STO}<animateTransform attributeName="gradientTransform" type="translate" values="${rev ? `0 ${L};0 0` : `0 0;0 ${L}`}" dur="${dur}s" repeatCount="indefinite"/></linearGradient>`;
    D.fx = ctx => { const C = cam(ctx); let s = '', defs = '';
      BX.forEach((x, i) => { defs += G('rg' + i, 44, i, 6) + G('rw' + i, 44, i, 6);
        s += WD(C, x - 16, Y0 + BH + 8, 0.05, `<g opacity="0.55">${an('opacity', '0.38;0.62;0.42;0.7;0.38', 1.7)}<rect width="32" height="${BH + 16}" rx="16" fill="url(#rw${i})" filter="url(#m11b8)"/></g>`, 32, BH + 16);
        s += wsh(C, x - 2.3, Y0 + BH, 4.6, BH, { dx: 0.8, dy: 1.4, op: 0.35, f: 'm12b2' });
        const dec = `<rect x="0.8" y="1.2" width="3" height="${BH - 2.4}" rx="1.3" fill="url(#rg${i})"/><rect x="0.8" y="1.2" width="3" height="${BH - 2.4}" rx="1.3" fill="#ffffff" opacity="0.26"/><rect x="2" y="1.6" width="0.6" height="${BH - 3.2}" rx="0.3" fill="#ffffff" opacity="0.6"/>`;
        s += box3(C, { c: [x, Y0 - 1.2, 1.8], w: 5, h: 1.2, d: 3.6, r: 1, col: '#2a2c30', gl: 0.4, olw: 0.25 });
        s += box3(C, { c: [x, Y0, 1.7], w: 4.6, h: BH, d: 3.4, r: 1, col: '#b9bec4', mat: 'brush', gl: 0.7, dec: { f: dec }, olw: 0.3, edge: 0.4 });
        s += box3(C, { c: [x, Y0 + BH, 1.8], w: 5, h: 1.2, d: 3.6, r: 1, col: '#2a2c30', gl: 0.4, olw: 0.25 }); });
      const hub = rep(5, i => `<circle cx="${f1(3.2 + i * 2.4)}" cy="2.6" r="0.6" fill="${['#ff3b7a', '#ffb13b', '#3bffb0', '#3bb4ff', '#a64bff'][i]}">${an('opacity', '0.25;1;0.25', 0.85, -i * 0.17)}</circle>`).join('') + T(8, 5.6, 1.5, '#7d838b', 'SYNC', 'letter-spacing="0.4"');
      s += box3(C, { c: [0, 42, 0.8], w: 16, h: 7, d: 1.6, r: 1.4, col: '#1d1f24', gl: 0.6, dec: { f: hub }, olw: 0.3 });
      return { defs: DEF12 + defs, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= MOV-098 FLOATING HOLOGRAPHIC FILM-REEL LIGHT SCULPTURES =======================
  N.reel12 = S => { const RL = [{ c: [-30, 62, 13], r: 17, yaw: 0.42, T: 5 }, { c: [31, 72, 10], r: 12.5, yaw: -0.38, T: 3.6 }];
    const D = { w: 124, d: 30, mount: 'wall', elev: 36, build: () => [] };
    const reel = r => `<circle r="${f1(r)}" fill="#5ff0ff" fill-opacity="0.1" stroke="#9ff8ff" stroke-width="${f1(r * 0.05)}"/><circle r="${f1(r * 0.8)}" fill="#0b4a5a" fill-opacity="0.35" stroke="#5ff0ff" stroke-opacity="0.6" stroke-width="${f1(r * 0.02)}"/>`
      + [0.62, 0.7, 0.76].map(k => `<circle r="${f1(r * k)}" fill="none" stroke="#8ff6ff" stroke-opacity="0.2" stroke-width="${f1(r * 0.012)}"/>`).join('')
      + rep(5, i => { const a = i * 72 * PI / 180; return `<circle cx="${f1(r * 0.5 * Math.cos(a))}" cy="${f1(r * 0.5 * Math.sin(a))}" r="${f1(r * 0.18)}" fill="#02141a" fill-opacity="0.55" stroke="#c8fbff" stroke-width="${f1(r * 0.03)}"/>`; }).join('')
      + `<circle r="${f1(r * 0.16)}" fill="#c8fbff" fill-opacity="0.5" stroke="#ffffff" stroke-width="${f1(r * 0.03)}"/><circle r="${f1(r * 0.06)}" fill="#ffffff"/>`;
    D.fx = ctx => { const C = cam(ctx); let s = '';
      s += WD(C, -64, 96, 0.05, `<rect width="128" height="70" rx="30" fill="#3fd0ff" opacity="0.18" filter="url(#m11b8)">${an('opacity', '0.12;0.24;0.15;0.22;0.12', 3.4)}</rect>`);
      s += wsh(C, -56, 35, 112, 5, { dx: 1, dy: 1.6, op: 0.45, f: 'm12b2' });
      const lens = RL.map(R => `<ellipse cx="${f1(R.c[0] + 56)}" cy="2.2" rx="2.4" ry="1.5" fill="#dffcff"/><ellipse cx="${f1(R.c[0] + 56)}" cy="2.2" rx="1.2" ry="0.7" fill="#ffffff"/>`).join('');
      s += box3(C, { c: [0, 30, 2.2], w: 112, h: 5, d: 4.4, r: 1.6, col: '#1e2129', gl: 0.6, dec: { f: `<rect x="5" y="2" width="102" height="1" rx="0.5" fill="#8ff6ff">${an('opacity', '0.6;1;0.6', 2.2)}</rect>`, t: lens }, olc: '#050608', olw: 0.35, edge: 0.3 });
      const U = R => [Math.cos(R.yaw), 0, -Math.sin(R.yaw)];
      RL.forEach(R => { const u = U(R), e0 = C.p(R.c[0] - 2.4, 35, 2.2), e1 = C.p(R.c[0] + 2.4, 35, 2.2), a = C.P(add(R.c, add(mul(u, -R.r * 0.85), [0, -R.r * 0.5, 0]))), b = C.P(add(R.c, add(mul(u, R.r * 0.85), [0, -R.r * 0.5, 0]))), id = C.u('bm');
        s += `<defs><linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="0" y1="${f1(e0[1])}" x2="0" y2="${f1(a[1])}"><stop offset="0" stop-color="#8ff6ff" stop-opacity="0.55"/><stop offset="1" stop-color="#8ff6ff" stop-opacity="0.03"/></linearGradient></defs><path d="M${P2(e0)}L${P2(a)}L${P2(b)}L${P2(e1)}Z" fill="url(#${id})">${an('opacity', '0.7;1;0.6;0.95;0.7', 2.6)}</path>`;
        const m = C.p(R.c[0], 35, 2.2), c = C.P(R.c); s += rep(5, i => `<circle r="${f1(C.k * 0.45)}" fill="#dffcff" opacity="0"><animate attributeName="opacity" values="0;0.9;0" dur="1.8s" begin="${n4(-i * 0.36)}s" repeatCount="indefinite"/><animateMotion dur="1.8s" begin="${n4(-i * 0.36)}s" repeatCount="indefinite" path="M${f1(m[0] + (i - 2) * C.k * 1.4)} ${f1(m[1])}L${f1(c[0] + (i - 2) * C.k * 3)} ${f1(c[1] + R.r * C.k * 0.4)}"/></circle>`).join(''); });
      const [R1, R2] = RL, u1 = U(R1), u2 = U(R2), A = C.P(add(R1.c, add(mul(u1, R1.r * 0.7), [0, -R1.r * 0.7, 0]))), B = C.P(add(R2.c, add(mul(u2, -R2.r * 0.7), [0, -R2.r * 0.7, 0]))), k = C.k;
      const fd = `M${P2(A)}C${f1(A[0] + 12 * k)} ${f1(A[1] + 10 * k)} ${f1(B[0] - 10 * k)} ${f1(B[1] + 12 * k)} ${P2(B)}`;
      s += `<path d="${fd}" fill="none" stroke="#5ff0ff" stroke-opacity="0.24" stroke-width="${f1(3.4 * k)}"/><path d="${fd}" fill="none" stroke="#dffcff" stroke-opacity="0.5" stroke-width="${f1(2.4 * k)}" stroke-dasharray="${f1(0.45 * k)} ${f1(1.2 * k)}">${an('stroke-dashoffset', `0;${f1(-1.65 * k)}`, 0.5)}</path>`;
      RL.forEach(R => { ext(C, [add(R.c, [-R.r, -R.r, 0]), add(R.c, [R.r, R.r, 0])]); const sp = `<g>${at('rotate', '0;360', R.T)}${reel(R.r)}</g>`;
        s += `<g transform="${FR(C, R.c, U(R), [0, -1, 0])}"><g opacity="0.55" filter="url(#m11b4)">${sp}</g><g>${an('opacity', '0.85;1;0.9;1;0.85', 2.3)}${sp}</g></g>`; });
      return { defs: DEF12, front: s, bb: C.bb(4) }; };
    return D; };

  // ---------- catalog edits ----------
  RD.SET12 = {
    'MOV-001': { s12: 'dry', note: 'Old grey drywall with a taped seam, mudded screw heads, a brown water stain and a patch where the paint is peeling off. Two charcoal egg-crate foam panels are glued on as DIY soundproofing (one a little crooked).' },
    'MOV-021': { s12: 'char', note: 'Walls rolled in a deep matte charcoal that swallows stray light. You can see the fine roller stipple and soft lap marks up close.' },
    'MOV-061': { s12: 'slat', live: 'Glowing slats', note: 'Vertical walnut slats with real grain over black acoustic felt. Amber LED strips behind them glow through the gaps and slowly breathe brighter and dimmer.' },
    'MOV-081': { s3: null, s12: 'star', live: 'Twinkling stars', note: 'Padded obsidian fabric panels with hundreds of fibre-optic stars in warm and cool white. They twinkle at their own pace, and now and then a shooting star streaks past.' },
    'MOV-004': { spec: 'torn12', live: 'Corner flutters', note: 'A sun-faded "Space Squish" B-movie poster with fold creases, wrinkles and a torn-off bottom corner, held up with yellowed scotch tape. The top corner has come loose, folded over, and flutters in the draft.' },
    'MOV-024': { spec: 'trio12', note: 'Three retro sci-fi posters (Rocket Rangers, Saucer Summer, Robo Pal) in satin black frames with cream bevel-cut mats and glass that catches the light. They are printed in faded halftone inks.' },
    'MOV-044': { spec: 'lbox12', live: 'Chasing bulbs', note: 'A black marquee lightbox with a NOW PLAYING header and a backlit "Moonlit Matinee" poster behind acrylic. A ring of warm bulbs chases around the frame.' },
    'MOV-064': { spec: 'sbox12', note: 'A deep walnut shadowbox lined with green velvet: a replica silk top hat and gold-topped cane, a signed black-and-white star photo and an engraved brass plaque, under glass and a brass picture light.' },
    'MOV-084': { spec: 'holo12', live: 'Animated posters', note: 'Three slim glowing frames with living posters: a rocket blasting through streaking stars, ink waves rolling under a pulsing moon, and a bouncy Squish blob that blinks. Holo shimmer sweeps across the glass.' },
    'MOV-018': { spec: 'lant12', live: 'Swaying lanterns', note: 'A drooping cord of seven ribbed paper lanterns in soft pastel colours, hung from two wall hooks. Each one glows from inside, flickers a little and sways on its own.' },
    'MOV-038': { spec: 'neon12', live: 'Flickering neon', note: 'Glass neon tubes on a black backer with chrome standoffs: pink NOW over cyan SHOWING inside an amber border, with chasing arrows. The NOW tube flickers now and then, and the whole sign glows on the wall.' },
    'MOV-058': { spec: 'bron12', note: 'A pair of brushed-bronze cylinder sconces on wall plates. Each one throws a warm fan of light up the wall and another one down.' },
    'MOV-078': { spec: 'rgbw12', live: 'Colour waves', note: 'Two aluminium light bars with frosted diffusers. Rainbow colour waves run up and down them and wash the wall, pulsing to the beat, with a small SYNC hub between them.' },
    'MOV-098': { spec: 'reel12', live: 'Spinning reels', note: 'Two see-through holographic film reels float above a wall emitter bar and spin. A strip of film runs between them, light beams rise from the emitter, and the reels flicker like a hologram.' },
  };
  const edit11 = RD.edit;
  RD.edit = rows => edit11(rows).map(r => RD.SET12[r.id] ? Object.assign({}, r, RD.SET12[r.id]) : r);
  RD.H12 = { DEF12, WD, wsh, innerW, paperFx, NZ, NR, BL, tube, word, tile, room, blot, outlet, BB, SURF12 };
  RD.PLUS12 = 1;
})();
