// Tier 5 movie: "Squish Squad: The Musical" (5 min). Needs movies.js + movies-kit.js.
// Each verse star dances a cartoon version of their real signature dance (SIG), the chorus pops one star out of
// the holo-screen ('pop' cue -> movie-night draws them over the room), and the friends in the room guest-star in the finale.
(function () {
  const SM = window.SquadMovies, K = window.MK; if (!SM || !K || !SM.def) return;
  const { D, P, E, kf, win, put, show, actor, pose, go, dance, bub, lines, parts, glow, film, snd, rnd, cl, lerp, stars, el, art, SPIN } = K;
  const B = 0.5, FY = 158, W = 56;
  const CH = '<svg viewBox="0 0 10 10" width="8" height="8"><path d="M5 0 L6 4 L10 5 L6 6 L5 10 L4 6 L0 5 L4 4Z" fill="currentColor"></path></svg>';
  const seg = (u, a, b) => cl((u - a) / (b - a)), arc = (u, a, b, h) => u > a && u < b ? Math.sin(Math.PI * (u - a) / (b - a)) * h : 0;
  const land = (u, a, d = 8) => u >= a ? Math.exp(-(u - a) * d) : 0, wrapR = a => ((a % 360) + 540) % 360 - 180, tw = (u, r) => SPIN[Math.floor(Math.max(0, u) * r) % 4];
  const bp = u => { const bt = u / B, n = Math.floor(bt), f = bt - n; return { bt, n, f, hp: Math.sin(Math.PI * f), sq: Math.exp(-f * 8), s2: n % 2 ? 1 : -1 }; };
  const FLAME = 'width:9px;height:13px;border-radius:50% 50% 50% 50%/60% 60% 40% 40%;background:radial-gradient(circle at 50% 70%,#fff6c8 0 25%,#ffb84a 55%,#ff5a2a);';
  const PUFF = 'width:10px;height:10px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fff 0 40%,#f1e2ec);';
  const SMOKE = 'width:10px;height:10px;border-radius:50%;background:radial-gradient(circle,#d8d0e0 0 40%,rgba(216,208,224,0) 72%);';
  const DROP = c => 'width:4px;height:5px;border-radius:50% 50% 50% 50%/60% 60% 40% 40%;background:' + c + ';';
  const BUB = 'width:7px;height:7px;border-radius:50%;border:1.5px solid rgba(255,255,255,0.85);box-sizing:border-box;background:rgba(200,240,255,0.15);';
  const RING = c => 'width:40px;height:10px;border-radius:50%;border:2px solid ' + c + ';box-sizing:border-box;';
  // particle sets that read the dancer's pose: defs [[n, css, html, f(i, u, s, ch)]] -> (u, s, on, ch)
  function FX(p, defs) { let U = 0, S = null, ON = false, CHo = false; const ps = defs.map(([n, css, html, f]) => parts(p, n, css, html, i => ON ? f(i, U, S, CHo) : null));
    return (u, s, on, ch) => { U = u; S = s; ON = !!(on && s); CHo = !!ch; ps.forEach(q => q(u)); }; }
  // spray of n drops from (x, y) d seconds after it starts
  const spray = (i, n, d, x, y, dur = 0.6, v = 60, wd = 2.4) => { if (d < 0 || d > dur) return null; const a = -Math.PI / 2 + (i / Math.max(1, n - 1) - 0.5) * wd; return { x: x + Math.cos(a) * v * d, y: y + Math.sin(a) * v * 1.1 * d + 150 * d * d, o: 1 - d / dur }; };
  // burger stack cut into bands (Bunbun's layers fly apart)
  function sliced(p, k, w, cuts) { const sd = D(p, 'left:0;top:0;width:' + (w * 0.72) + 'px;height:' + (w * 0.12) + 'px;border-radius:50%;background:rgba(10,8,30,0.3);display:none;');
    const n = D(p, 'left:0;top:0;width:' + w + 'px;height:' + w + 'px;transform-origin:50% 94%;display:none;'); n._k = k; n._w = w; n._v = ''; n._sd = sd;
    n._sl = cuts.slice(1).map((c, j) => { const a = cuts[j], b = D(n, 'left:0;top:' + (a * w).toFixed(2) + 'px;width:' + w + 'px;height:' + ((c - a) * w + 0.6).toFixed(2) + 'px;overflow:hidden;z-index:' + (cuts.length - j) + ';');
      const im = el('img', 'position:absolute;left:0;top:' + (-a * w).toFixed(2) + 'px;width:' + w + 'px;height:' + w + 'px;', b); im.alt = ''; im.draggable = false; return { b, im }; });
    SPIN.forEach(v => { const i = new Image(); i.src = art(k, v); }); return n; }
  function posA(n, s) { if (n._sl && s) { const v = s.v || 'front'; if (n._sv !== v) { n._sv = v; n._sl.forEach(q => { q.im.src = art(n._k, v); }); }
    const o = s.sl || []; n._sl.forEach((q, j) => { const d = o[j] || [0, 0]; q.b.style.transform = 'translate(' + d[0].toFixed(1) + 'px,' + d[1].toFixed(1) + 'px)'; }); } pose(n, s); }

  // ---------- signature dances: m(u, x, y, chorus) for u in [0, 8) -> pose; fx(layer) -> (u, pose, on, chorus) ----------
  const toastOf = u => u < 3 ? u / 3 : u < 4 ? 1 - seg(u, 3.15, 3.5) : u < 7 ? (u - 4) / 3 : 1 - seg(u, 7, 7.35);
  const tf = a => a > 0.01 ? 'sepia(' + (0.6 * a).toFixed(2) + ') saturate(' + (1 + 0.9 * a).toFixed(2) + ') brightness(' + (1 - 0.14 * a).toFixed(2) + ')' : '';
  const PL = 48;
  const SIG = {
    // Mallow, Toasty Twirl: twirls till toasty golden, puffs back to white with a jump
    mallow: { m(u, x, y) { const { bt, hp } = bp(u), f = tf(toastOf(u));
        if (u < 3) return { x: x + Math.sin(u * Math.PI / 1.5) * 6, y: y - hp * 4, v: tw(u, 4), r: Math.sin(bt * Math.PI) * 5, f };
        if (u < 4) { const j = arc(u, 3, 3.9, 30), q = land(u, 3.9) + (u < 3.08 ? seg(u, 3, 3.04) : 0), a = j > 2 ? 1 : 0; return { x, y: y - j, gy: y, v: 'front', sx: 1 + 0.12 * q - 0.05 * a, sy: 1 - 0.14 * q + 0.07 * a, f }; }
        if (u < 7) return { x: x + Math.sin((u - 4) * Math.PI / 1.5) * 10, y: y - Math.abs(Math.sin(bt * Math.PI)) * 5, v: tw(u, 8), f };
        const j = arc(u, 7, 7.5, 18), q = land(u, 7.5); return { x, y: y - j, gy: y, v: 'front', sx: 1 + 0.12 * q, sy: 1 - 0.14 * q, f }; },
      fx: p => FX(p, [[3, FLAME, null, (i, u, s) => { const a = toastOf(u); if (a < 0.05 || (u >= 3.1 && u < 4) || u >= 7) return null; return { x: s.x + (i - 1) * 11, y: s.y - 2 - Math.abs(Math.sin(u * 13 + i)) * 2, k: (0.6 + 0.5 * a) * (0.85 + 0.15 * Math.sin(u * 20 + i * 2)), o: 0.9 * a }; }],
        [8, PUFF, null, (i, u, s) => { const d = u - (u < 5 ? 3.15 : 7.05); if (d < 0 || d > 0.8) return null; const a = i / 8 * Math.PI * 2; return { x: s.x + Math.cos(a) * (10 + d * 40), y: s.y - 28 + Math.sin(a) * (8 + d * 24) - d * 10, k: 0.6 + d * 1.2, o: 1 - d / 0.8 }; }]]) },
    // Frybo, Fry Shuffle: shuffle steps, salt shake, ketchup dip, box-flip
    frybo: { m(u, x, y) { const { hp, sq } = bp(u);
        if (u < 4) { const d = Math.cos(u * Math.PI / 2) >= 0 ? 1 : -1; return { x: x + 16 * Math.sin(u * Math.PI / 2), y: y - hp * 3, v: d > 0 ? 'right' : 'left', r: d * 5 * hp, sx: 1 + 0.05 * sq, sy: 1 - 0.05 * sq }; }
        if (u < 6) return { x, y: y - Math.abs(Math.sin(u * 19)) * 3, v: 'front', r: Math.sin(u * 38) * 6 };
        if (u < 7) { const e = Math.sin(Math.PI * seg(u, 6, 7)); return { x: x - 8 * e, y: y + 2 * e, v: 'front', r: -30 * e }; }
        const j = arc(u, 7, 7.8, 30), q = land(u, 7.8); return { x, y: y - j, gy: y, v: 'front', r: wrapR(360 * E.io(seg(u, 7.02, 7.78))), sx: 1 + 0.12 * q, sy: 1 - 0.14 * q }; },
      fx: p => FX(p, [[1, 'width:10px;height:16px;', '<svg viewBox="0 0 10 16" width="10" height="16"><rect x="1" y="4" width="8" height="11.5" rx="2" fill="#f4f4f8" stroke="#8a94a6" stroke-width="0.8"></rect><rect x="1.5" y="0.8" width="7" height="4" rx="1.5" fill="#b8c0cc"></rect><circle cx="3.6" cy="2.4" r="0.6" fill="#556"></circle><circle cx="6.4" cy="2.4" r="0.6" fill="#556"></circle></svg>',
          (i, u, s) => u < 3.8 || u > 6.1 ? null : { x: s.x + 14, y: s.y - 70 + Math.sin(u * 38) * 3, r: 180 + Math.sin(u * 38) * 25, k: 1.3 * Math.min(1, (u - 3.8) / 0.2, (6.1 - u) / 0.2) }],
        [12, 'width:2px;height:2px;border-radius:1px;background:#fff;', null, (i, u, s) => { if (u < 4 || u > 6) return null; const a = ((u - 4) * 2.2 + i / 12) % 1; return { x: s.x + 13 + Math.sin(i * 2.7) * 7, y: s.y - 60 + a * 28, o: 1 - a * 0.5 }; }],
        [1, 'width:15px;height:10px;border-radius:2px 2px 6px 6px;background:linear-gradient(#e23030 0 40%,#fff 40% 55%,#f4f4f4 55%);box-shadow:0 1px 2px rgba(0,0,0,0.3);', null, (i, u, s) => u < 5.7 || u > 7.2 ? null : { x: s.x - 22, y: s.y - 5, k: Math.min(1, (u - 5.7) / 0.2, (7.2 - u) / 0.2) }]]) },
    // Bunbun, Stack Attack: the layers fly apart on every jump, shuffle like cards, split-stack spin, stack slam
    bunbun: { sl: [0, 0.505, 0.685, 1], m(u, x, y) { const { bt, hp, sq } = bp(u);
        if (u < 2) return { x, y: y - hp * 6, v: 'front', sx: 1 + 0.06 * sq, sy: 1 - 0.07 * sq, sl: [[0, -hp * 2.5], [0, -hp], [0, 0]] };
        if (u < 4) { const k2 = (u - 2) % 1, sp = Math.sin(Math.PI * k2), q = Math.exp(-k2 * 9); return { x, y: y - sp * 24, gy: y, v: 'front', r: (Math.floor(u - 2) % 2 ? 1 : -1) * 8 * sp, sx: 1 + 0.12 * q, sy: 1 - 0.14 * q, sl: [[0, -sp * 13], [0, -sp * 5.5], [0, 0]] }; }
        if (u < 6) { const w = Math.sin(bt * Math.PI); return { x: x + w * 3, y: y - hp * 3, v: 'front', sl: [[w * 9, -1.5 * hp], [-w * 9, 0], [w * 4, 0]] }; }
        if (u < 7.2) { const sp = Math.sin(Math.PI * seg(u, 6, 7.2)); return { x, y: y - sp * 34, gy: y, v: tw(u - 6, 8), sl: [[0, -sp * 16], [0, -sp * 7], [0, 0]] }; }
        const q = land(u, 7.2, 5); return { x, y, v: 'front', sx: 1 + 0.22 * q, sy: 1 - 0.26 * q, sl: [[0, 2 * q], [0, q], [0, 0]] }; },
      fx: p => FX(p, [[1, RING('rgba(255,240,200,0.9)'), null, (i, u, s) => { const d = u - 7.2; return d < 0 || d > 0.6 ? null : { x: s.x, y: s.y, k: 1 + d * 3, o: 1 - d / 0.6 }; }],
        [6, 'width:4px;height:3px;border-radius:50%;background:#fff3c4;', null, (i, u, s) => spray(i, 6, u - 7.2, s.x, s.y - 4, 0.55, 70, 2.8)]]) },
    // Finn, Splash Dance: wave-swim bobs, breach leap with a flip and splashes, tail-walk backwards, bow
    finn: { m(u, x, y) { const { bt } = bp(u);
        if (u < 3) { const ph = u * Math.PI * 2 / 3; return { x: x + Math.sin(ph) * 14, y: y - Math.abs(Math.sin(bt * Math.PI)) * 6, v: Math.cos(ph) >= 0 ? 'right' : 'left', r: Math.sin(bt * Math.PI) * 10 }; }
        if (u < 5) { const j = Math.sin(Math.PI * seg(u, 3, 5)) * 56, q = u < 3.08 ? seg(u, 3, 3.04) : 0; return { x, y: y - j, gy: y, v: 'right', r: wrapR(-360 * E.io(seg(u, 3.15, 4.85))), sx: 1 + 0.12 * q, sy: 1 - 0.14 * q }; }
        if (u < 7) { const e = Math.sin(Math.PI * seg(u, 5, 7)), q = land(u, 5); return { x: x + 18 * e, y: y - 8 * e - Math.abs(Math.sin(u * 16)) * 3 * e, gy: y, v: 'left', r: 6 * Math.sin(u * 16) * e, sx: 1 + 0.12 * q, sy: 1 - 0.14 * q }; }
        const e = Math.sin(Math.PI * seg(u, 7, 7.9)); return { x, y, v: 'front', r: 20 * e, sy: 1 - 0.05 * e }; },
      fx: p => FX(p, [[9, DROP('#bff4ff'), null, (i, u, s) => spray(i, 9, u - (u < 4.5 ? 3 : 5), s.x, (s.gy ?? s.y) - 2, 0.7, 64)],
        [1, RING('rgba(220,250,255,0.9)'), null, (i, u, s) => { const d = u - (u < 4.5 ? 3 : 5); return d < 0 || d > 0.6 ? null : { x: s.x, y: s.gy ?? s.y, k: 1 + d * 2.5, o: 1 - d / 0.6 }; }]]) },
    // Octo, Tentacle Tango: noodle sway, jet squirt with an ink puff, parachute float down, tango leans
    octo: { m(u, x, y) { const { hp } = bp(u);
        if (u < 3) { const w = Math.sin(u * Math.PI), z = Math.sin(u * 2 * Math.PI); return { x: x + w * 8, y: y - hp * 2, v: 'front', r: w * 16, sx: 1 + 0.06 * z, sy: 1 - 0.06 * z }; }
        if (u < 3.5) { const e = seg(u, 3, 3.5); return { x, y, v: 'front', sx: 1 + 0.16 * e, sy: 1 - 0.22 * e }; }
        if (u < 4.2) { const e = E.out(seg(u, 3.5, 4.2)); return { x, y: y - 70 * e, gy: y, v: 'front', sx: 0.9, sy: 1.18 - 0.18 * e }; }
        if (u < 6.2) { const e = E.io(seg(u, 4.2, 6.2)); return { x: x + Math.sin(u * 3) * 6, y: y - 70 * (1 - e), gy: y, v: 'front', r: Math.sin(u * 3) * 8, sx: 1.14 - 0.14 * e, sy: 0.9 + 0.1 * e }; }
        if (u < 7) { const e = seg(u, 6.2, 6.5); return { x: x - 10 * e, y, v: 'left', r: -18 * e }; }
        const e = seg(u, 7, 7.3) * (1 - seg(u, 7.7, 8)); return { x: x - 10 + 20 * seg(u, 7, 7.3) - 10 * seg(u, 7.7, 8), y, v: u < 7.7 ? 'right' : 'front', r: 18 * e }; },
      fx: p => FX(p, [[7, 'width:14px;height:14px;border-radius:50%;background:radial-gradient(circle,#3a2050 0 45%,rgba(58,32,80,0) 70%);', null, (i, u, s) => { const d = u - 3.5; if (d < 0 || d > 1.2) return null; const a = i / 7 * Math.PI * 2; return { x: s.x + Math.cos(a) * (6 + d * 22), y: (s.gy ?? s.y) - 10 + Math.sin(a) * (4 + d * 12) + d * 6, k: 0.8 + d * 1.6, o: (1 - d / 1.2) * 0.85 }; }]]) },
    // Marina, Mermaid Splash: breaststroke sway, whirlpool twirl with a bubble ring, tail-flick splashes, bubble blowing
    marina: { m(u, x, y) { const { bt, f } = bp(u);
        if (u < 3) { const ph = u * Math.PI * 2 / 3; return { x: x + Math.sin(ph) * 12, y: y - Math.abs(Math.sin(bt * Math.PI)) * 5, v: 'front', r: -Math.sin(ph) * 10 }; }
        if (u < 5.5) { const e = Math.sin(Math.PI * seg(u, 3, 5.5)); return { x, y: y - 16 * e, gy: y, v: tw(u - 3, 6) }; }
        if (u < 7) { const s = Math.floor(bt) % 2 ? 1 : -1; return { x, y: y - Math.sin(Math.PI * f) * 8, gy: y, v: 'front', r: s * 14 * Math.sin(Math.PI * f) }; }
        return { x, y: y - Math.abs(Math.sin(u * 4)) * 2, v: 'front', r: 4 * Math.sin(u * 3) }; },
      fx: p => FX(p, [[8, BUB, null, (i, u, s) => { if (u < 3 || u > 5.5) return null; const a = u * 5 + i / 8 * Math.PI * 2, fr = Math.sin(a) > 0; return { x: s.x + Math.cos(a) * 30, y: s.y - 22 + Math.sin(a) * 8 - (u - 3) * 4, k: 0.9, o: (fr ? 0.95 : 0.4) * Math.min(1, (u - 3) / 0.3, (5.5 - u) / 0.3) }; }],
        [6, BUB, null, (i, u, s) => { if (u < 7) return null; const a = ((u - 7) * 1.3 + i / 6) % 1; return { x: s.x + 4 + Math.sin(i * 2 + u * 4) * 4, y: s.y - 34 - a * 50, k: 0.6 + a * 0.8, o: (1 - a) * Math.min(1, (u - 7) / 0.2) }; }],
        [4, DROP('#bff4ff'), null, (i, u, s) => { if (u < 5.5 || u >= 7) return null; const d = (u - 5.5) % B, sd = Math.floor((u - 5.5) / B) % 2 ? 1 : -1; return spray(i, 4, d, s.x + sd * 16, s.y - 6, 0.45, 50, 1.6); }]]) },
    // Pina, Tropical Sway: hula hips, crown shake (leaves fly), bongo bounces, forward flip
    pina: { m(u, x, y) { const { bt, hp, sq } = bp(u);
        if (u < 4) { const w = Math.sin(u * Math.PI), z = Math.sin(u * 2 * Math.PI); return { x: x + w * 9, y: y - Math.abs(Math.sin(bt * Math.PI)) * 2, v: 'front', r: -w * 11, sx: 1 + 0.04 * z, sy: 1 - 0.03 * z }; }
        if (u < 5) return { x, y: y - Math.abs(Math.sin(u * 20)) * 3, v: 'front', r: Math.sin(u * 40) * 7 };
        if (u < 7) return { x, y: y - hp * 6, v: 'front', sx: 1 + 0.1 * sq, sy: 1 - 0.12 * sq };
        const j = arc(u, 7, 7.8, 30), q = land(u, 7.8); return { x, y: y - j, gy: y, v: 'front', r: wrapR(360 * E.io(seg(u, 7.02, 7.78))), sx: 1 + 0.12 * q, sy: 1 - 0.14 * q }; },
      fx: p => FX(p, [[8, 'width:6px;height:10px;border-radius:50% 0;background:#4ab04a;', null, (i, u, s) => { const d = u - 4; if (d < 0 || d > 1.4) return null; const a = -Math.PI / 2 + (i / 7 - 0.5) * 2.6; return { x: s.x + Math.cos(a) * 50 * d, y: s.y - 54 * (s.k || 1) + Math.sin(a) * 55 * d + 70 * d * d, r: d * 400 + i * 40, o: 1 - d / 1.4 }; }]]) },
    // Berri, Berry Bop: juicy bounces, calyx twirl, squish + pop jump, curtsy, heart pose
    berri: { m(u, x, y) { const { hp, sq, s2 } = bp(u);
        if (u < 3) return { x, y: y - hp * 12, gy: y, v: 'front', r: s2 * 4 * hp, sx: 1 + 0.15 * sq, sy: 1 - 0.16 * sq };
        if (u < 5) return { x, y: y - 6 * Math.sin(Math.PI * seg(u, 3, 5)), gy: y, v: tw(u - 3, 8) };
        if (u < 5.6) { const e = E.out(seg(u, 5, 5.6)); return { x, y, v: 'front', sx: 1 + 0.2 * e, sy: 1 - 0.3 * e }; }
        if (u < 6.4) return { x, y: y - arc(u, 5.6, 6.4, 34), gy: y, v: 'front', sx: 0.94, sy: 1.08 };
        if (u < 7.2) { const e = Math.sin(Math.PI * seg(u, 6.4, 7.2)), q = land(u, 6.4); return { x, y, v: 'front', r: -8 * e, sx: 1 + 0.15 * q, sy: 1 - 0.1 * e - 0.15 * q }; }
        return { x, y: y - Math.abs(Math.sin(u * 6)) * 3, v: 'front' }; },
      fx: p => FX(p, [[5, DROP('#ff3a5a'), null, (i, u, s) => { const d = u < 3 ? u % B : u - 6.4; return spray(i, 5, d, s.x, (s.gy ?? s.y) - 3, 0.42, 55); }],
        [1, 'width:12px;height:11px;', '<svg viewBox="0 0 10 9" width="12" height="11"><path d="M5 9 L1 5 A2.4 2.4 0 0 1 5 2 A2.4 2.4 0 0 1 9 5Z" fill="#ff4a7a"></path></svg>', (i, u, s) => { const d = u - 7.2; return d < 0 ? null : { x: s.x, y: s.y - 62 * (s.k || 1) - d * 20, k: 0.6 + d * 0.9, o: Math.min(1, d / 0.15) }; }]]) },
    // Peachy, Orchard Drop: hangs swinging on the branch and ripens, drops - plop - soft bounces, waltz turns, curtsy
    peachy: { nmY: 112, m(u, x, y, ch) { if (ch) u = 3.45 + (u % 4.55);
        if (u < 0.6) { const e = E.out(seg(u, 0, 0.6)); return { x, px: x, y: lerp(y, 28 + PL, e), gy: y, v: 'front', sx: 0.95, sy: 1.06 }; }
        if (u < 3) { const a = Math.sin((u - 0.6) * 3.4) * 16 * Math.min(1, (u - 0.6) / 0.4), ar = a * Math.PI / 180, b = seg(u, 0.6, 3); return { x: x - PL * Math.sin(ar), px: x, y: 28 + PL * Math.cos(ar), gy: y, v: 'front', r: a, f: 'saturate(' + (1 + 0.5 * b).toFixed(2) + ') hue-rotate(' + (-12 * b).toFixed(0) + 'deg)' }; }
        if (u < 3.45) { const e = E.in(seg(u, 3, 3.45)); return { x, px: x, y: lerp(28 + PL, y, e), gy: y, v: 'front', sx: 0.94, sy: 1.08 }; }
        if (u < 5) { let j = 0, q = 0; [[3.45, 3.95, 12], [3.95, 4.35, 6], [4.35, 4.65, 3]].forEach(([a, b, h]) => { j += arc(u, a, b, h); if (u >= a) q = Math.max(q, Math.exp(-(u - a) * 12) * h / 12); }); return { x, px: x, y: y - j, gy: y, v: 'front', sx: 1 + 0.2 * q, sy: 1 - 0.24 * q }; }
        if (u < 7) { const w = u - 5; return { x: x + Math.sin(w * Math.PI) * 14, px: x, y: y - Math.abs(Math.sin(w * 2 * Math.PI)) * 4, v: tw(w, 2), r: Math.sin(w * 2 * Math.PI) * 4 }; }
        const e = Math.sin(Math.PI * seg(u, 7, 7.9)); return { x, px: x, y, v: 'front', r: -6 * e, sy: 1 - 0.1 * e }; },
      fx: p => FX(p, [[1, 'width:80px;height:20px;', '<svg viewBox="0 0 80 20" width="80" height="20"><path d="M0 9 Q40 4 80 10" stroke="#7a4a2a" stroke-width="5" fill="none" stroke-linecap="round"></path><ellipse cx="14" cy="6" rx="7" ry="3.5" fill="#4a9a4a" transform="rotate(-20 14 6)"></ellipse><ellipse cx="64" cy="7" rx="7" ry="3.5" fill="#4a9a4a" transform="rotate(20 64 7)"></ellipse></svg>',
          (i, u, s, ch) => ch || u > 3.6 ? null : { x: s.px ?? s.x, y: 24, r: Math.sin(u * 3.4) * 2, o: Math.min(1, u / 0.3, (3.6 - u) / 0.3) }],
        [1, 'width:7px;height:11px;border-radius:50% 0;background:#4a9a4a;', null, (i, u, s, ch) => { const d = u - 3; return ch || d < 0 || d > 1.6 ? null : { x: (s.px ?? s.x) + 12 + Math.sin(d * 6) * 10, y: 26 + d * 70, r: Math.sin(d * 6) * 50, o: 1 - d / 1.6 }; }],
        [6, DROP('#ffb07a'), null, (i, u, s, ch) => spray(i, 6, (ch ? 3.45 + (u % 4.55) : u) - 3.45, s.x, (s.gy ?? s.y) - 3, 0.45, 50)]]) },
    // Pixie, Pixie Jig: fluttering rise with pixie dust, loop-the-loop, skipping jig, pirouette, curtsy
    pixie: { m(u, x, y) { const { f } = bp(u);
        if (u < 2) return { x, y: y - (10 + 24 * E.io(seg(u, 0, 2))) + Math.sin(u * 6) * 3, gy: y, v: 'front', r: Math.sin(u * 3) * 5 };
        if (u < 4) { const a = 2 * Math.PI * E.io(seg(u, 2, 4)); return { x: x + Math.sin(a) * 24, y: y - 34 - (1 - Math.cos(a)) * 24, gy: y, v: 'front', r: wrapR(a * 180 / Math.PI) }; }
        if (u < 6) { const h = lerp(34, 8, E.io(seg(u, 4, 4.5))), w = u - 4; return { x: x + Math.sin(w * Math.PI) * 14, y: y - h - Math.sin(Math.PI * f) * 10, gy: y, v: u < 4.5 ? 'front' : Math.cos(w * Math.PI) >= 0 ? 'right' : 'left' }; }
        if (u < 7) return { x, y: y - 12 - Math.sin((u - 6) * Math.PI) * 6, gy: y, v: tw(u - 6, 8) };
        const e = Math.sin(Math.PI * seg(u, 7, 7.9)); return { x, y: y - lerp(12, 4, seg(u, 7, 7.3)), gy: y, v: 'front', r: -6 * e, sy: 1 - 0.08 * e }; },
      fx: p => FX(p, [[12, 'width:8px;height:8px;color:#fff6a0;', CH, (i, u, s) => { const a = (u * 1.4 + i / 12) % 1; return { x: s.x + Math.sin(i * 2.1 + u) * 12, y: s.y - 18 + a * 34, r: u * 200, k: 0.6 + (1 - a) * 0.5, o: (1 - a) * 0.95 }; }]]) },
    // Drako, Rawr Rumble: tail-thump groove, flap hops, big RAWR with fire, tail-chase spin, dizzy + smoke puff
    drako: { m(u, x, y) { const { hp, sq, s2 } = bp(u);
        if (u < 2) return { x, y: y - hp * 4, v: 'front', r: s2 * 6 * hp, sx: 1 + 0.1 * sq, sy: 1 - 0.1 * sq };
        if (u < 4) { const k2 = (u - 2) % 1, q = Math.exp(-k2 * 9); return { x, y: y - Math.sin(Math.PI * k2) * 20, gy: y, v: 'front', sx: 1 + 0.14 * q, sy: 1 - 0.16 * q }; }
        if (u < 4.5) { const e = seg(u, 4, 4.5); return { x, y, v: 'front', sx: 1 + 0.08 * e, sy: 1 - 0.14 * e }; }
        if (u < 6) { const e = E.back(seg(u, 4.5, 4.8)); return { x, y, v: 'front', k: 1 + 0.12 * e, sx: 1.03, sy: 1.06, r: Math.sin(u * 40) * 2, shk: 2.2 * (1 - seg(u, 5.5, 6)) }; }
        if (u < 7.2) { const w = (u - 6) / 1.2 * 2 * Math.PI; return { x: x + Math.sin(w) * 10, y: y - Math.abs(Math.sin(w)) * 3, v: tw(u - 6, 10) }; }
        const e = 1 - seg(u, 7.2, 8), z = Math.sin(u * 9); return { x, y, v: 'front', r: z * 10 * e, sx: 1 + 0.03 * z, sy: 1 - 0.03 * z }; },
      fx: p => FX(p, [[16, FLAME, null, (i, u, s) => { if (u < 4.6 || u > 6) return null; const a = ((u - 4.6) * 2.2 + i / 16) % 1, g = -Math.PI / 2 + 0.35, k = s.k || 1; return { x: s.x + 4 + Math.cos(g) * a * 80 + Math.sin(i * 3.1) * a * 10, y: s.y - 24 * k + Math.sin(g) * a * 80, k: 0.6 + a * 1.6, r: 20, o: (1 - a) * Math.min(1, (u - 4.6) / 0.15, (6 - u) / 0.2) }; }],
        [3, 'width:30px;height:30px;border-radius:50%;border:2px solid rgba(255,255,255,0.8);border-left-color:transparent;border-right-color:transparent;border-bottom-color:transparent;box-sizing:border-box;', null, (i, u, s) => { if (u < 4.5 || u > 6) return null; const d = ((u - 4.5) * 2 + i / 3) % 1; return { x: s.x, y: s.y - 30 * (s.k || 1), k: 0.6 + d * 2.4, o: 1 - d }; }],
        [3, SMOKE, null, (i, u, s) => { const d = u - 7.3 - i * 0.12; return d < 0 || d > 0.8 ? null : { x: s.x + (i - 1) * 4, y: s.y - 30 - d * 24, k: 0.6 + d * 1.5, o: 1 - d / 0.8 }; }]]) },
    // Flicker, Phoenix Inferno: fireball juggle, fire tornado spin, flame cocoon, rebirth burst, hot-foot hops
    ember: { m(u, x, y) { const { bt, hp } = bp(u);
        if (u < 3) return { x: x + Math.sin(u * Math.PI * 2 / 3) * 8, y: y - hp * 5, v: 'front', r: Math.sin(bt * Math.PI) * 4 };
        if (u < 5) return { x, y: y - 12 * Math.sin(Math.PI * seg(u, 3, 5)), gy: y, v: tw(u - 3, 10) };
        if (u < 6) { const e = seg(u, 5, 5.4); return { x, y, v: 'front', sx: 1 - 0.06 * e, sy: 1 - 0.1 * e, f: 'brightness(' + (1 + 0.5 * seg(u, 5, 6)).toFixed(2) + ') saturate(1.3)' }; }
        if (u < 7) { const b = 1 - seg(u, 6, 6.7); return { x, y: y - arc(u, 6, 7, 26), gy: y, v: 'front', k: 1 + 0.15 * Math.sin(Math.PI * seg(u, 6, 7)), f: b > 0.01 ? 'brightness(' + (1 + 1.3 * b).toFixed(2) + ')' : '' }; }
        const k2 = ((u - 7) % 0.25) / 0.25; return { x: x + (Math.floor((u - 7) * 4) % 2 ? 3 : -3), y: y - Math.sin(Math.PI * k2) * 6, v: 'front' }; },
      fx: p => FX(p, [[2, 'width:11px;height:11px;border-radius:50%;background:radial-gradient(circle at 40% 40%,#fff6c8 0 25%,#ffb84a 55%,#ff5a2a 80%);box-shadow:0 0 6px 2px rgba(255,140,40,0.7);', null, (i, u, s) => { if (u > 3) return null; const q = (u + i * 0.5) % 1, d = Math.floor(u + i * 0.5) % 2 ? 1 : -1; return { x: s.x + d * (-16 + 32 * q), y: s.y - 44 - Math.sin(Math.PI * q) * 30, o: Math.min(1, u / 0.2, (3 - u) / 0.2) }; }],
        [10, FLAME, null, (i, u, s) => { if (u < 3 || u > 5) return null; const a = u * 9 + i / 10 * Math.PI * 2; return { x: s.x + Math.cos(a) * 26, y: (s.gy ?? s.y) - 6 - i * 4.5 - (u - 3) * 4, k: 0.9, o: (Math.sin(a) > 0 ? 0.95 : 0.4) * Math.min(1, (u - 3) / 0.25, (5 - u) / 0.25) }; }],
        [1, 'width:70px;height:70px;border-radius:50%;background:radial-gradient(circle,rgba(255,200,90,0.9) 0 30%,rgba(255,110,40,0.5) 55%,rgba(255,80,20,0) 72%);', null, (i, u, s) => u < 5 || u > 6.2 ? null : { x: s.x, y: s.y - 26, k: 0.6 + seg(u, 5, 6) * 0.6, o: Math.min(1, (u - 5) / 0.3, (6.2 - u) / 0.2) }],
        [1, 'width:30px;height:30px;border-radius:50%;border:3px solid #ffd66b;box-sizing:border-box;box-shadow:0 0 8px #ff8a2a;', null, (i, u, s) => { const d = u - 6; return d < 0 || d > 0.7 ? null : { x: s.x, y: (s.gy ?? s.y) - 26, k: 1 + d * 6, o: 1 - d / 0.7 }; }],
        [10, 'width:3px;height:3px;border-radius:50%;background:#ffe9a0;box-shadow:0 0 3px #ffb84a;', null, (i, u, s) => spray(i, 10, u - 6, s.x, (s.gy ?? s.y) - 26, 0.7, 90, 5.6)]]) },
  };
  // jump toward the camera, out of the top of the frame (movie-night shows them over the room), then drop back in
  function popPose(p, X) {
    if (p < 0.15) { const e = seg(p, 0, 0.15); return { x: X, y: FY, v: 'front', sx: 1 + 0.12 * e, sy: 1 - 0.16 * e }; }
    if (p < 0.5) { const e = E.in(seg(p, 0.15, 0.5)); return { x: X + (160 - X) * 0.2 * e, y: FY - 150 * e, gy: FY, v: 'front', k: 1 + 1.8 * e, sx: 0.94, sy: 1.08 }; }
    if (p < 2) return null;
    if (p < 2.4) { const e = E.in(seg(p, 2, 2.4)); return { x: X, y: lerp(-20, FY, e), gy: FY, v: 'front', k: 1.6 - 0.6 * e, sx: 0.95, sy: 1.06 }; }
    const q = land(p, 2.4); return { x: X, y: FY, v: 'front', sx: 1 + 0.16 * q, sy: 1 - 0.2 * q }; }
  const popGlint = (g, p, X) => { const o = Math.max(win(p, 0.35, 0.9, 0.15), win(p, 1.85, 2.2, 0.12)); if (o <= 0) { show(g, false); return; } put(g, X, 2, 1 + 0.3 * Math.sin(p * 20), 0, o); };

  // stage: backdrop slot, wooden floor, footlights, sweeping spotlights, curtain halves, karaoke caption
  function stage(L, back) {
    const bd = D(L, 'inset:0;'); if (back) back(bd);
    const fl = D(L, 'left:0;top:136px;width:320px;height:44px;background:repeating-linear-gradient(90deg,#8a5a3a 0 26px,#7a4e32 26px 28px);'); D(fl, 'left:0;top:0;width:320px;height:4px;background:#c8905a;');
    const fo = Array.from({ length: 9 }, (_, i) => D(L, 'left:' + (14 + i * 36) + 'px;top:172px;width:12px;height:6px;border-radius:6px 6px 0 0;background:#ffe9a0;box-shadow:0 0 8px 3px rgba(255,220,140,0.7);'));
    const act = D(L, 'inset:0;'), cones = [0, 1, 2].map(i => D(L, 'left:0;top:-10px;width:90px;height:190px;transform-origin:50% 0;clip-path:polygon(44% 0,56% 0,100% 100%,0 100%);background:linear-gradient(rgba(255,250,220,0.5),rgba(255,250,220,0.08));mix-blend-mode:screen;pointer-events:none;'));
    const dark = D(L, 'inset:0;pointer-events:none;'), cur = [0, 1].map(i => D(L, 'top:0;width:170px;height:180px;' + (i ? 'right:0;' : 'left:0;') + 'background:repeating-linear-gradient(90deg,#a0182a 0 12px,#c8283a 12px 20px,#a0182a 20px 26px);box-shadow:inset ' + (i ? '6px' : '-6px') + ' 0 10px rgba(0,0,0,0.4);z-index:50;'));
    const val = D(L, 'left:-10px;top:0;width:340px;height:18px;background:repeating-radial-gradient(circle at 10px 0,#c8283a 0 9px,#a0182a 9px 10px) 0 0/20px 18px;z-index:51;box-shadow:0 3px 4px rgba(0,0,0,0.4);');
    const cap = D(L, "left:0;bottom:8px;width:320px;text-align:center;font-weight:700;font-size:13px;line-height:1.1;z-index:60;padding:0 10px;box-sizing:border-box;-webkit-text-stroke:3px #2a0f4f;paint-order:stroke fill;color:#fff;", '');
    let ct = '';
    return { act, bd, upd(t, q = {}) { const c = q.cur ?? 1; cur[0].style.transform = 'translateX(' + (-c * 165).toFixed(1) + 'px) scaleX(' + (1 - c * 0.35).toFixed(3) + ')'; cur[1].style.transform = 'translateX(' + (c * 165).toFixed(1) + 'px) scaleX(' + (1 - c * 0.35).toFixed(3) + ')'; cur[0].style.transformOrigin = '0 0'; cur[1].style.transformOrigin = '100% 0';
      fo.forEach((f, i) => { f.style.opacity = (0.6 + 0.4 * Math.abs(Math.sin(t * 2 + i))).toFixed(2); });
      const sp = q.sp || []; cones.forEach((n, i) => { const s = sp[i]; if (!s) { show(n, false); return; } show(n, true); n.style.transform = 'translateX(' + (s[0] - 45).toFixed(1) + 'px) rotate(' + (s[1] || 0).toFixed(1) + 'deg)'; n.style.opacity = (s[2] ?? 1).toFixed(2); });
      const dk = q.dark || 0, ds = q.ds; dark.style.background = ds ? 'radial-gradient(ellipse 60px 80px at ' + ds[0] + 'px ' + ds[1] + 'px, rgba(8,4,20,0) 60%, rgba(8,4,20,' + dk + ') 100%)' : 'rgba(8,4,20,' + dk + ')';
      const tx = q.cap ? q.cap[0] : ''; if (tx !== ct) { ct = tx; cap.textContent = tx; } cap.style.opacity = q.cap ? q.cap[1].toFixed(3) : '0'; if (q.cap) cap.style.color = q.cap[2] || '#fff'; } };
  }
  const lyr = (t, L) => { const q = L.find(l => t >= l[0] && t < l[1]); return q ? [q[2], win(t, q[0], q[1], 0.2), q[3]] : null; };
  const banner = (p, txt, c1, c2) => D(p, "left:0;top:20px;width:320px;text-align:center;font-weight:700;font-size:26px;letter-spacing:1px;z-index:40;-webkit-text-stroke:4px #2a0f4f;paint-order:stroke fill;color:" + c1 + ";text-shadow:0 0 12px " + c2 + ";display:none;", txt);
  const wash = (L, c) => D(L, 'inset:0;pointer-events:none;mix-blend-mode:screen;z-index:45;opacity:0;background:radial-gradient(ellipse 70% 90% at 50% 100%,' + c + ',rgba(0,0,0,0) 72%);');
  const beatW = t => Math.exp(-((t / B) % 1) * 4);
  // one verse: 3 dancers, a banner, signature solos (name + dance) then the group chorus; o.pop = who pops out of the screen at the chorus
  function verse(o) { return { a: o.a, b: o.a + 50, rgb: o.rgb, lit: t => 0.85 + 0.15 * Math.exp(-((t / B) % 1) * 5), mk(L) {
    const S = stage(L, o.back), ns = o.who.map(w => SIG[w[0]].sl ? sliced(S.act, w[0], W, SIG[w[0]].sl) : actor(S.act, w[0], W)), fxs = o.who.map(w => SIG[w[0]].fx ? SIG[w[0]].fx(S.act) : null);
    const bn = banner(L, o.title, o.c1, o.c2), nm = D(L, "left:0;top:22px;width:320px;text-align:center;z-index:40;display:none;font-weight:700;-webkit-text-stroke:3px #2a0f4f;paint-order:stroke fill;color:#fff;", ''), wa = wash(L, o.c2), pg = glow(L, 'rgba(170,245,255,0.95)', 26, 'z-index:46;');
    const fx = o.fx ? o.fx(S.act) : null, X3 = [74, 160, 246];
    return t => { const sol = t >= 4 && t < 28 ? Math.floor((t - 4) / 8) : -1, gr = t >= 28; let shk = 0;
      put(bn, 160, 40, P(t, 0.2, 0.8, E.back) * (1 + 0.04 * Math.sin(t * 6)), 0, t < 4 ? 1 - P(t, 3.4, 4) : 0);
      if (sol >= 0) { const w = o.who[sol], u = t - 4 - sol * 8; nm.innerHTML = '<div style="font-size:20px;">' + w[1] + '</div><div style="font-size:11px;color:' + o.c1 + ';">' + w[2] + '</div>'; put(nm, 160, SIG[w[0]].nmY || 36, 1, 0, win(t, 4 + sol * 8, 12 + sol * 8, 0.3) * (u < 3.4 ? 1 : 1 - P(u, 3.4, 4))); } else show(nm, false);
      ns.forEach((n, i) => { const w = o.who[i], sg = SIG[w[0]], X = X3[i]; let s, u = -1, ch = false;
        if (t < 3) s = go(t, [[0, i === 0 ? -40 : i === 2 ? 360 : 160, i === 1 ? 210 : FY], [1.6 + i * 0.3, X, FY]], { y: FY, f: 'front', ph: i }) || { x: X, y: FY, v: 'front' };
        else if (t < 4) s = dance(t, X, FY, 'bounce', B, i * 0.3);
        else if (sol === i) { u = t - 4 - sol * 8; const m = P(u, 0, 0.8) * (1 - P(u, 7.2, 8)); s = sg.m(u, lerp(X, 160, m), FY, false); s.k = (s.k || 1) * (1 + 0.25 * m); }
        else if (sol >= 0) { const sl = [0, 1, 2].filter(j => j !== sol).indexOf(i), uu = t - 4 - sol * 8, m = P(uu, 0, 0.8) * (1 - P(uu, 7.2, 8)); s = dance(t, lerp(X, sl ? 268 : 52, m), FY, 'sway', B, i); s.k = 0.85; }
        else { const pu = t - 28; if (i === o.pop && pu < 2.8) { s = popPose(pu, X); popGlint(pg, pu, X + (160 - X) * 0.2); } else { u = pu % 8; ch = true; s = sg.m(u, X, FY, true); } }
        posA(n, s); if (fxs[i]) fxs[i](u, s, u >= 0, ch); if (s && s.shk) shk = Math.max(shk, s.shk); });
      if (!(gr && t - 28 < 2.8)) show(pg, false);
      if (fx) fx(t, sol);
      wa.style.opacity = ((gr ? 0.34 : 0.14) * beatW(t)).toFixed(3);
      L.style.transform = shk > 0.05 ? 'translate(' + (Math.sin(t * 90) * shk).toFixed(1) + 'px,' + (Math.cos(t * 77) * shk * 0.6).toFixed(1) + 'px)' : '';
      const sw = Math.sin(t * 1.3) * 18; S.upd(t, { sp: sol >= 0 ? [[160, 0, 1]] : [[74, sw, 0.8], [160, -sw * 0.6, 0.8], [246, -sw, 0.8]], dark: sol >= 0 ? 0.35 : 0.1, ds: sol >= 0 ? [160, 120] : null, cap: lyr(t, o.lyr) }); }; } }; }
  const guests = (skip) => { let C = []; try { C = (window.MovieNight && window.MovieNight.cast && window.MovieNight.cast()) || []; } catch (e) {} const seen = {}; return C.filter(c => c && c.key && !skip.includes(c.key) && !seen[c.key] && (seen[c.key] = 1)).slice(0, 4); };
  const andList = a => a.length < 2 ? a.join('') : a.slice(0, -1).join(', ') + ' & ' + a[a.length - 1];

  function mk() {
    const S = [];
    S.push({ a: 0, b: 30, rgb: '255,220,170', lit: t => 0.5 + 0.4 * P(t, 2, 5), mk(L) { const St = stage(L, bd => D(bd, 'inset:0;background:radial-gradient(ellipse at 50% 30%,#5a2a8a,#1a0a3a 75%);')), mi = actor(St.act, 'mittens', W + 8), sp = bub(L);
      const ti = D(L, "left:0;top:46px;width:320px;text-align:center;font-weight:700;z-index:55;-webkit-text-stroke:4px #2a0f4f;paint-order:stroke fill;color:#ffd66b;", '<div style="font-size:30px;">SQUISH SQUAD</div><div style="font-size:15px;color:#fff;">THE MUSICAL</div>');
      return t => { const c = P(t, 3.6, 6.4, E.io); ti.style.opacity = (P(t, 0.4, 1.2) * (1 - P(t, 3.4, 4))).toFixed(3); ti.style.transform = 'scale(' + (1 + 0.03 * Math.sin(t * 3)).toFixed(3) + ')';
        pose(mi, t < 22 ? { ...dance(t, 160, FY, t < 14 ? 'sway' : 'bounce', B), k: 1.15 } : { ...dance(t, 160, FY, 'jump', B), k: 1.15 });
        St.upd(t, { cur: c, sp: [[160, Math.sin(t) * 4, P(t, 5, 6)]], dark: 0.55 * (1 - P(t, 22, 23)), ds: [160, 120], cap: lyr(t, [[7, 11, 'Every friend has got a groove,'], [11, 15, 'every paw has got a move!'], [15, 19, 'Squish in close and feel the beat,'], [19, 23, 'jump up, friends, get on your feet!'], [23, 30, 'Squish, squish, SQUAD! Everybody move!', '#ffd66b']]) }); sp(null); }; } });
    S.push(verse({ a: 30, rgb: '255,170,190', title: 'SNACK SHACK!', c1: '#ffd66b', c2: '#ff6fa8', pop: 2, who: [['mallow', 'Mallow', 'Toasty Twirl'], ['frybo', 'Frybo', 'Fry Shuffle'], ['bunbun', 'Bunbun', 'Stack Attack']],
      back: bd => { D(bd, 'inset:0;background:linear-gradient(#ff9ab8,#ffd0a0);'); D(bd, 'left:0;top:60px;width:320px;height:80px;background:repeating-linear-gradient(90deg,#fff 0 16px,#ff6f8a 16px 32px);opacity:0.5;'); D(bd, "left:12px;top:26px;width:78px;height:20px;border-radius:6px;background:#2a0f4f;border:2px solid #ffd66b;box-shadow:0 0 10px #ff6fa8;color:#ffd66b;font-weight:700;font-size:10px;text-align:center;line-height:20px;", 'SNACK SHACK'); },
      fx: p => parts(p, 14, 'width:5px;height:2px;border-radius:1px;background:#fff6c8;', null, (i, t) => { const a = (t * 0.35 + i / 14) % 1; return { x: 20 + (i * 47) % 290, y: a * 150, r: t * 200 + i * 40, o: 0.9 }; }),
      lyr: [[4, 12, 'Toast it up and twirl around!'], [12, 20, 'Fry-shuffle sliding on the ground!'], [20, 28, 'Stack it, smack it, burger high!'], [30, 38, 'Squish, squish, SQUAD!', '#ffd66b'], [38, 46, 'Snack Shack in the groove!', '#ffd66b']] }));
    S.push(verse({ a: 80, rgb: '110,200,255', title: 'UNDER THE SEA!', c1: '#8fe8ff', c2: '#3a8ac8', pop: 0, who: [['finn', 'Finn', 'Splash Dance'], ['octo', 'Octo', 'Tentacle Tango'], ['marina', 'Marina', 'Mermaid Splash']],
      back: bd => { D(bd, 'inset:0;background:linear-gradient(#5ac8f0,#1a5aa0);'); D(bd, 'left:0;top:0;width:320px;height:140px;background:repeating-linear-gradient(100deg,rgba(255,255,255,0.08) 0 10px,rgba(255,255,255,0) 10px 40px);'); [30, 70, 250, 290].forEach((x, i) => D(bd, 'left:' + x + 'px;top:' + (70 + i % 2 * 14) + 'px;width:10px;height:70px;border-radius:10px;background:#3ab07a;transform-origin:50% 100%;transform:rotate(' + (i % 2 ? 6 : -6) + 'deg);')); },
      fx: p => parts(p, 16, 'width:7px;height:7px;border-radius:50%;border:1.5px solid rgba(255,255,255,0.8);box-sizing:border-box;', null, (i, t) => { const a = (t * 0.25 + i / 16) % 1; return { x: 14 + (i * 41) % 300 + Math.sin(t * 2 + i) * 4, y: 150 - a * 150, k: 0.6 + (i % 3) * 0.4, o: 0.9 }; }),
      lyr: [[4, 12, 'Splashing waves and dolphin flips,'], [12, 20, 'eight arms tango, swirls and dips,'], [20, 28, 'mermaid tail goes flick-flick-flash!'], [30, 38, 'Squish, squish, SQUAD!', '#8fe8ff'], [38, 46, 'Make a splash!', '#8fe8ff']] }));
    S.push(verse({ a: 130, rgb: '255,220,120', title: 'FRUIT PATCH!', c1: '#a6f06a', c2: '#ffb84a', pop: 1, who: [['pina', 'Pina', 'Tropical Sway'], ['berri', 'Berri', 'Berry Bop'], ['peachy', 'Peachy', 'Orchard Drop']],
      back: bd => { D(bd, 'inset:0;background:linear-gradient(#8fe0ff,#fff2b0);'); D(bd, 'left:250px;top:14px;width:36px;height:36px;border-radius:50%;background:#ffd23a;box-shadow:0 0 20px 8px rgba(255,210,58,0.6);'); D(bd, 'left:-20px;top:96px;width:360px;height:44px;border-radius:50% 50% 0 0;background:#7ac85a;'); [40, 120, 200].forEach(x => D(bd, 'left:' + x + 'px;top:72px;width:46px;height:40px;border-radius:50%;background:radial-gradient(circle at 30% 40%,#ff5a6a 0 4px,transparent 5px),radial-gradient(circle at 70% 60%,#ffb84a 0 4px,transparent 5px),#4a9a4a;')); },
      fx: p => parts(p, 8, 'width:6px;height:9px;border-radius:50% 0;background:#6ac04a;', null, (i, t) => { const a = (t * 0.18 + i / 8) % 1; return { x: (i * 53 + t * 14) % 330 - 5 + Math.sin(t * 2 + i) * 8, y: a * 140, r: Math.sin(t * 2 + i) * 60, o: 0.8 }; }),
      lyr: [[4, 12, 'Tropical sway in the sun,'], [12, 20, 'berry bop, the fun\u2019s begun,'], [20, 28, 'peachy drops right off the tree!'], [30, 38, 'Squish, squish, SQUAD!', '#a6f06a'], [38, 46, 'Fruity and free!', '#a6f06a']] }));
    S.push(verse({ a: 180, rgb: '200,150,255', title: 'DREAMLAND!', c1: '#c9a6ff', c2: '#ff8fd0', pop: 1, who: [['pixie', 'Pixie', 'Pixie Jig'], ['drako', 'Drako', 'Rawr Rumble'], ['ember', 'Flicker', 'Phoenix Inferno']],
      back: bd => { D(bd, 'inset:0;background:linear-gradient(#2a1a6a,#8a5ac8);'); bd.appendChild(stars(bd, 60, 320, 120, 9, '#fff', 1.3)); D(bd, 'left:40px;top:30px;width:240px;height:240px;border-radius:50%;background:radial-gradient(circle,transparent 52%,#ff6f8a 52% 56%,#ffb84a 56% 60%,#ffe66b 60% 64%,#7ae07a 64% 68%,#6ab0ff 68% 72%,#b07aff 72% 76%,transparent 76%);opacity:0.75;'); },
      fx: p => parts(p, 14, 'width:8px;height:8px;color:#fff6a0;', CH, (i, t) => { const a = (t * 0.3 + i / 14) % 1; return { x: 10 + (i * 61) % 300 + Math.sin(t + i) * 6, y: 10 + (i * 37) % 110, r: t * 90 + i * 30, k: 0.5 + 0.5 * Math.sin(Math.PI * a), o: Math.sin(Math.PI * a) }; }),
      lyr: [[4, 12, 'Pixie jig with sparkly dust,'], [12, 20, 'dragon rumble, rawr we must,'], [20, 28, 'phoenix flames light up the night!'], [30, 38, 'Squish, squish, SQUAD!', '#c9a6ff'], [38, 46, 'Shining bright!', '#c9a6ff']] }));
    S.push({ a: 230, b: 240, rgb: '120,120,200', lit: t => 0.1, mk(L) { const St = stage(L, bd => D(bd, 'inset:0;background:#120826;')), bo = actor(St.act, 'boo', W), sp = bub(L);
      return t => { pose(bo, go(t, [[0, 360, 140, { m: 'float' }], [3, 160, 140]], { m: 'float', gy: FY })); St.upd(t, { sp: [[160, 0, 0.7 * P(t, 2.5, 3.5)]], dark: 0.85, ds: [160, 118] }); lines(sp, t, [[4, 9, '...one more time?', 'b']], { b: [160, 84] }); }; } });
    const BK = ['frybo', 'octo', 'pina', 'pixie', 'peachy', 'marina', 'bunbun'], FR = ['mallow', 'finn', 'berri', 'mittens', 'boo', 'drako', 'ember'];
    S.push({ a: 240, b: 285, rgb: '255,200,240', inF: false, lit: t => 1 + 0.25 * Math.exp(-((t / B) % 1) * 5), mk(L) { const St = stage(L, bd => { D(bd, 'inset:0;background:conic-gradient(from 0deg at 50% 100%,#ff6fa8,#ffd66b,#8fe8ff,#a6f06a,#c9a6ff,#ff6fa8);'); });
      const bn = BK.map(k => actor(St.act, k, W - 12)), fn = FR.map(k => actor(St.act, k, W - 4)), STY = ['bounce', 'sway', 'jump', 'twirl', 'shuffle', 'spin', 'wave'], bg = St.bd.firstChild;
      const G = guests(BK.concat(FR)), gx = [138, 182, 94, 226].slice(0, G.length).sort((a, b) => a - b), gn = G.map(c => actor(St.act, c.key, W + 2)), wa = wash(L, '#ffffff'), pg = glow(L, 'rgba(170,245,255,0.95)', 26, 'z-index:46;');
      const gb = D(L, "left:0;top:14px;width:320px;text-align:center;font-weight:700;z-index:40;display:none;-webkit-text-stroke:3px #2a0f4f;paint-order:stroke fill;color:#fff;", '<div style="font-size:22px;color:#ffd66b;text-shadow:0 0 10px #ff6fa8;">GUEST STARS!</div><div style="font-size:12px;"></div>'); gb.lastChild.textContent = andList(G.map(c => c.name || c.key));
      const cf = parts(St.act, 30, 'width:5px;height:3px;border-radius:1px;', null, (i, t) => { const a = (t * 0.3 + i / 30) % 1; return { x: (i * 53 + Math.sin(t + i) * 20) % 320, y: a * 190 - 10, r: t * 300 + i * 30, o: 0.95 }; }); St.act.querySelectorAll('div').forEach((n, i) => { if (n.style.width === '5px' && n.style.height === '3px') n.style.background = ['#ffd66b', '#ff8fb8', '#8fe8ff', '#a6f06a', '#c9a6ff'][i % 5]; });
      return t => { bg.style.filter = 'hue-rotate(' + (t * 40 % 360).toFixed(0) + 'deg) brightness(0.8)'; const all = Math.floor(t / 8) % 2, pu = t - 30;
        bn.forEach((n, i) => pose(n, dance(t, 40 + i * 40, 132, all ? 'jump' : STY[i], B, i * 0.2)));
        fn.forEach((n, i) => { const x = 28 + i * 44, st = all ? STY[(i + 3) % 7] : STY[(i + 2) % 7];
          if (i === 3 && pu >= 0 && pu < 2.8) { posA(n, popPose(pu, x)); popGlint(pg, pu, x); return; }
          pose(n, t < 2.4 ? go(t, [[0, i < 4 ? -40 : 360], [1.5 + Math.abs(3 - i) * 0.2, x]], { y: FY, f: 'front', m: 'run' }) : dance(t, x, FY, st, B, i * 0.3)); });
        if (!(pu >= 0 && pu < 2.8)) show(pg, false);
        gn.forEach((n, j) => { const t0 = 20 + j * 0.18, y0 = FY + 12; if (t < t0) { pose(n, null); return; } const e = seg(t, t0, t0 + 1.1);
          pose(n, e < 1 ? { x: gx[j], y: lerp(232, y0, E.out(e)) - Math.sin(Math.PI * e) * 34, gy: y0, v: 'front', k: 1.06, r: (j % 2 ? 1 : -1) * 10 * Math.sin(Math.PI * e) } : { ...dance(t, gx[j], y0, all ? 'jump' : STY[(j + 4) % 7], B, j * 0.4), k: 1.06 }); });
        if (G.length) put(gb, 160, 34, P(t, 20.4, 21, E.back), 0, win(t, 20.4, 27.5, 0.4)); else show(gb, false);
        cf(t); wa.style.opacity = (0.22 * beatW(t)).toFixed(3); const sw = Math.sin(t * 2) * 26, gs = G.length && t >= 20 && t < 28;
        St.upd(t, { sp: gs ? gx.slice(0, 3).map(x => [x, 0, 1]) : [[70, sw, 0.9], [160, -sw, 0.9], [250, sw, 0.9]], cap: lyr(t, [[4, 12, 'Every friend has got a groove!'], [12, 20, 'Every paw has got a move!'], [22, 30, 'Squish, squish, SQUAD!', '#ffd66b'], [30, 38, 'Everybody MOVE!', '#ff8fb8'], [38, 45, 'Squish, squish, SQUAD!', '#8fe8ff']]) }); }; } });
    S.push({ a: 285, b: 300, rgb: '255,220,180', inF: false, outF: false, mk(L) { const St = stage(L, bd => D(bd, 'inset:0;background:radial-gradient(ellipse at 50% 40%,#6a2a9a,#1a0a3a 75%);')), G = guests(BK.concat(FR)), ks = FR.concat(G.map(c => c.key)), nn = ks.length, gap = Math.min(44, 300 / nn), kk = Math.max(0.72, Math.min(1, gap / 42)), ns = ks.map(k => actor(St.act, k, W - 4)), sp = bub(L);
      const fl = parts(St.act, 12, 'width:9px;height:9px;color:#ff6f8a;', '<svg viewBox="0 0 10 10" width="9" height="9"><circle cx="5" cy="5" r="2" fill="#ffd66b"></circle><circle cx="5" cy="1.8" r="2" fill="currentColor"></circle><circle cx="8.2" cy="5" r="2" fill="currentColor"></circle><circle cx="5" cy="8.2" r="2" fill="currentColor"></circle><circle cx="1.8" cy="5" r="2" fill="currentColor"></circle></svg>', (i, t) => { const d = t - 2 - (i % 6) * 0.4; if (d < 0 || d > 2) return null; return { x: 20 + i * 26, y: 10 + d * 70 + d * d * 20, r: d * 300, o: 1 }; });
      return t => { ns.forEach((n, i) => { const bw = Math.sin(Math.PI * cl((t % 4) / 1.4)) * (t < 10 ? 1 : 0); pose(n, { x: 160 + (i - (nn - 1) / 2) * gap, y: FY, v: 'front', r: 0, k: kk, sy: 1 - 0.14 * bw, sx: 1 + 0.06 * bw }); }); fl(t);
        St.upd(t, { cur: 1 - P(t, 10.5, 14, E.io), sp: [[160, 0, 1 - P(t, 12, 14)]], cap: lyr(t, [[0.5, 4, 'Thank you!'], [4.4, 9.6, 'Goodnight, Squish Squad!', '#ffd66b']]) }); sp(null); }; } });
    return film(S, { rgb: '255,200,240' });
  }

  const POPS = [[58, 'bunbun', 246], [108, 'finn', 74], [158, 'berri', 160], [208, 'drako', 160], [270, 'mittens', 160]];
  function score(Q) { const I = snd(Q), PR = [[48, [60, 64, 67]], [45, [60, 64, 69]], [41, [60, 65, 69]], [43, [59, 62, 67]]];
    const A = [[0, 67, 1], [1, 67, 1], [2, 69, 1], [3, 67, 1], [4, 72, 1.5], [5.5, 71, 0.5], [6, 67, 2]], A2 = [[0, 69, 1], [1, 69, 1], [2, 71, 1], [3, 69, 1], [4, 74, 1.5], [5.5, 72, 0.5], [6, 71, 2]], C = [[0, 72, 1], [1, 72, 1], [2, 72, 2], [4, 74, 1], [5, 76, 1], [6, 74, 1], [7, 72, 1], [8, 79, 2], [10, 77, 1], [11, 76, 1], [12, 72, 4]];
    const sing = (t0, ph, tr = 0, v = 0.07, f = I.voice) => ph.forEach(([o, m, d]) => f(t0 + o * B, m + tr, d * B * 0.95, v));
    const band = (t0, t1, sty, tr = 0) => I.beat(t0, t1, B / 2, (t, i) => { const bar = Math.floor(i / 8) % 4, p = PR[bar], r = p[0] + tr;
      if (i % 4 === 0) I.kick(t, 0.55); if (i % 8 === 4) { I.snare(t, 0.18); if (sty === 'snack') I.clap(t, 0.12); } if (i % 2) I.hat(t, 0.03);
      if (sty === 'snack') { if (i % 2 === 0) I.bass(t, r - 12 + (i % 4 === 2 ? 12 : 0), 0.18, 0.13); if (i % 8 === 2 || i % 8 === 6) I.pad(t, p[1].map(m => m + tr), B * 0.4, 0.03, 'square', 2000); }
      else if (sty === 'sea') { I.pluck(t, p[1][i % 3] + 12 + tr, 0.3, 0.035); if (i % 4 === 0) I.sub(t, r - 12, B * 2, 0.1); if (i % 8 === 0) I.pad(t, p[1].map(m => m + tr), B * 4, 0.015, 'triangle', 1500); }
      else if (sty === 'fruit') { I.pluck(t, p[1][(i * 2) % 3] + 12 + tr, 0.18, 0.05); if (i % 2 === 0) I.bass(t, r - 12, 0.2, 0.1); if (i % 4 === 3) I.tone(t, 900, 0.05, { type: 'triangle', vol: 0.03 }); }
      else if (sty === 'dream') { if (i % 2 === 0) I.bell(t, p[1][(i / 2) % 3] + 24 + tr, 0.6, 0.025); if (i % 2 === 0) I.bass(t, r - 12, 0.25, 0.12); if (i % 8 === 0) I.pad(t, p[1].map(m => m + tr), B * 4, 0.02, 'sawtooth', 1200); }
      else { if (i % 2 === 0) I.bass(t, r - 12 + (i % 4 === 2 ? 12 : 0), 0.2, 0.14); if (i % 8 === 0) I.pad(t, p[1].map(m => m + tr), B * 4, 0.022, 'sawtooth', 1600); I.pluck(t, p[1][i % 3] + 12 + tr, 0.12, 0.025); } });
    I.pad(0, [48, 55, 60, 64], 6, 0.02, 'sawtooth', 700); I.beat(1, 3.6, 0.12, (t, i) => I.noise(t, 0.08, { ft: 'bandpass', f: 300 + i * 30, vol: 0.02 })); I.crash(3.6, 0.08); [60, 64, 67, 72, 76, 79].forEach((m, k) => I.bell(3.8 + k * 0.12, m + 12, 0.8, 0.04));
    I.beat(5, 7, B, (t, i) => I.kick(t, 0.3)); band(7, 30, 'pop'); sing(7, A); sing(11, A2); sing(15, A); sing(19, A2); sing(23, C, 0, 0.08); I.crash(23, 0.1);
    const V = (a, sty, tr) => { I.crash(a, 0.12); I.brass(a, 60 + tr, 1, 0.04); I.brass(a, 64 + tr, 1, 0.04); band(a + 1, a + 50, sty, tr); sing(a + 4, A, tr); sing(a + 8, A2, tr, 0.05, I.lead); sing(a + 12, A, tr); sing(a + 16, A2, tr, 0.05, I.lead); sing(a + 20, A, tr); sing(a + 24, A2, tr, 0.05, I.lead); I.crash(a + 30, 0.1); sing(a + 30, C, tr, 0.08); sing(a + 38, C, tr, 0.08); sing(a + 38, C, tr + 12, 0.03, I.lead); };
    V(30, 'snack', 0); V(80, 'sea', 2); V(130, 'fruit', -3); I.crash(178, 0.2); I.boom(178, 0.25); V(180, 'dream', 3);
    // signature-dance hits (solo n of the verse at a starts at a + 4 + n * 8)
    const so = (a, n, u) => a + 4 + n * 8 + u;
    I.poof(so(30, 0, 3.15), 0.12); I.poof(so(30, 0, 7.05), 0.1); I.beat(so(30, 1, 4), so(30, 1, 6), 0.065, t => I.hat(t, 0.035)); I.whoosh(so(30, 1, 7), 0.6, 0.06); [2, 3, 6].forEach(u => I.boing(so(30, 2, u), 0.05)); I.timp(so(30, 2, 7.2), 0.35);
    I.splash(so(80, 0, 3), 0.12); I.splash(so(80, 0, 5), 0.14); I.whoosh(so(80, 1, 3.5), 0.4, 0.07); I.poof(so(80, 1, 3.55), 0.08); I.beat(so(80, 2, 3), so(80, 2, 5.5), 0.3, t => I.pop(t, 0.04)); I.beat(so(80, 2, 7), so(80, 2, 8), 0.2, t => I.pop(t, 0.05));
    I.beat(so(130, 0, 4), so(130, 0, 5), 0.07, t => I.noise(t, 0.05, { ft: 'bandpass', f: 2600, vol: 0.03 })); I.pop(so(130, 1, 6.4), 0.08); I.boing(so(130, 1, 5.6), 0.06); I.whoosh(so(130, 2, 3), 0.45, 0.05); I.pop(so(130, 2, 3.45), 0.1); I.pop(so(130, 2, 3.95), 0.06);
    I.sparkle(so(180, 0, 0.2), 88, 0.03); I.sparkle(so(180, 0, 2), 91, 0.03); I.whoosh(so(180, 0, 2), 2, 0.04); I.rumble(so(180, 1, 4.5), 1.5, 0.12); I.tone(so(180, 1, 4.5), 220, 1.2, { to: 140, slide: 1.2, type: 'sawtooth', lp: 1200, vol: 0.06, vib: [18, 20] }); I.noise(so(180, 1, 4.6), 1.3, { ft: 'bandpass', f: 900, q: 0.6, vol: 0.06, at: 0.1 }); I.whoosh(so(180, 2, 3), 2, 0.05); I.boom(so(180, 2, 6), 0.22); I.sparkle(so(180, 2, 6.05), 84, 0.035);
    POPS.forEach(([t]) => { I.whoosh(t + 0.15, 0.4, 0.07); I.sparkle(t + 0.45, 88, 0.03); I.whoosh(t + 1.9, 0.4, 0.05); I.pop(t + 2.4, 0.1); });
    I.tone(230, 400, 1.2, { to: 80, slide: 1.1, type: 'sawtooth', lp: 900, vol: 0.06 }); I.pad(231, [48, 51, 55], 8, 0.02, 'triangle', 800); I.voice(234, 72, 0.6, 0.05); I.voice(234.6, 71, 0.6, 0.05); I.voice(235.4, 67, 1.4, 0.05); I.beat(236, 240, 0.25, (t, i) => I.snare(t, 0.04 + i * 0.012));
    I.crash(240, 0.2); I.boom(240, 0.3); band(240, 285, 'pop', 2); sing(244, A, 2); sing(248, A2, 2); sing(252, A, 2, 0.05, I.lead); sing(256, A2, 2, 0.05, I.lead); I.crash(260, 0.1); [62, 66, 69, 74].forEach((m, k) => I.brass(260 + k * 0.12, m, 0.6, 0.035)); sing(262, C, 2, 0.09); sing(262, C, 14, 0.03, I.lead); I.crash(262, 0.14); sing(270, C, 2, 0.09); sing(278, C, 2, 0.09); sing(278, C, 14, 0.04, I.lead); I.crash(278, 0.14);
    I.crash(285, 0.2); [50, 54, 57, 62, 66, 69].forEach(m => I.brass(285, m, 3, 0.03)); I.timp(285, 0.4); I.beat(286, 292, 0.1, (t, i) => I.clap(t + Math.random() * 0.05, 0.03 + 0.02 * Math.sin(i))); [86, 81, 78, 74].forEach((m, k) => I.bell(292 + k * 0.6, m, 1.4, 0.04)); I.pad(294, [50, 57, 62, 66], 6, 0.02, 'triangle', 1200);
  }
  SM.def('musical', { mk, score, beat: t => { const on = (t >= 7 && t < 230) || (t >= 240 && t < 285); if (!on) return null; const x = t / B; return { n: Math.floor(x), ph: x - Math.floor(x), amp: 1 }; },
    cues: [[6, 'cheer'], [36, 'cheer'], [57.2, 'laugh'], [60.5, 'cheer'], [87, 'gasp'], [110.5, 'cheer'], [140, 'doze'], [160.5, 'cheer'], [178, 'wake'], [184, 'gasp'], [196.5, 'gasp'], [206, 'cheer'], [210.5, 'cheer'], [232, 'hide'], [240.3, 'confetti'], [241, 'cheer'], [252, 'cheer'], [260.5, 'cheer'], [262, 'confetti'], [272.5, 'cheer'], [278, 'confetti'], [279, 'cheer'], [285.6, 'dance']].concat(POPS.map(([t, k, x]) => [t, 'pop', k, x])).sort((a, b) => a[0] - b[0]) });
})();
