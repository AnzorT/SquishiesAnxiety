// Renovation Catalog round 32 — Yard realism pass (same rules as the other rooms: ground -> fences -> overhead -> electronics -> furniture, 3 per batch, user reviews each).
// Grounds = r.g32: the 80 x 56 perspective trapezoid build of plus31 (W(u, y) floor space). The yard ground is stretched over the whole backyard, so grass blades,
// pebbles and stones are drawn small (a blade ~ 0.5-1.3 units tall) and in their thousands, grouped into a few paths per colour.
// The YRD add-ons (101..107, 120..125) are left as they are. Sets RenoDraw.PLUS32; catalog edits RD.SET32; helpers RD.H32.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS31 && RD.H31 && RD.H27 && RD.H20 && RD.H13 && RD.H10 && RD.H3 && RD.H7 && RD.H8 && RD.N && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS32) return;
  const shade = X.K.shade, H = RD.H10;
  const { rng, an, at, SPL, f1, rep, n4 } = H; const N = RD.N, PI = Math.PI;
  const { fblot, FL } = RD.H13;
  const { W, polyW, lineW, crvW } = RD.H20;
  const { K } = RD.H31;
  const P = (u, y) => W(u, y);
  // The backyard stretches the ground picture about 2.4x wider than tall (1004 x 294 px from 80 x 56), so the room copy is drawn with every shape squeezed
  // sideways by AX = 0.42 about its own spot (positions stay where they are); the catalog copy uses AX = 1.
  let AX = 1;
  const gv = t => t * (0.7 + 0.3 * t);
  const dot = (u, y, r, ex) => { const p = W(u, y), k = K(y); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(r * k * AX)}" ry="${f1(r * k * (0.55 + 0.2 * gv(y)))}" ${ex}/>`; };
  const dotD = (u, y, r) => { const p = W(u, y), k = K(y), rx = r * k * AX, ry = r * k * (0.55 + 0.2 * gv(y)); return `M${f1(p[0] - rx)} ${f1(p[1])}a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(2 * rx)} 0a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(-2 * rx)} 0Z`; };
  const SX = () => ` scale(${AX} 1)`;

  // ---------- shared ground helpers ----------
  // grass blades: screen-space strokes standing up from (u, y); bucketed into rows so a whole row can sway from its base line (skewX about the base)
  const blades = (R, n, area, cols, hmin, hmax, wid, sway, keep) => { const rows = {}, NR = 7;
    for (let i = 0; i < n; i++) { const q = area(R); if (!q) continue; const [u, y] = q; if (keep && !keep(u, y)) continue; const p = P(u, y), k = K(y), h = (hmin + R() * (hmax - hmin)) * k, l = (R() - 0.5) * h * 0.7 * AX, c = Math.floor(R() * cols.length), ri = Math.min(NR - 1, Math.floor(y * NR));
      const B = rows[ri] || (rows[ri] = { y: 0, n: 0, d: cols.map(() => '') }); B.y += p[1]; B.n++;
      B.d[c] += `M${f1(p[0])} ${f1(p[1])}q${f1(l * 0.2)} ${f1(-h * 0.55)} ${f1(l)} ${f1(-h)}`; }
    let s = ''; Object.keys(rows).forEach(ri => { const B = rows[ri], by = B.y / B.n, w = wid * K(+ri / NR + 0.07) * AX;
      const body = B.d.map((d, c) => d ? `<path d="${d}" stroke="${cols[c]}" stroke-width="${f1(w)}" stroke-linecap="round" fill="none"/>` : '').join('');
      s += sway ? `<g transform="translate(0 ${f1(by)})"><g>${at('skewX', `0;${f1(sway)};0;${f1(-sway * 0.6)};0`, 4.6 + ri * 0.37, -ri * 0.6, SPL(4))}<g transform="translate(0 ${f1(-by)})">${body}</g></g></g>` : body; });
    return s; };
  const inRect = (u0, y0, u1, y1) => R => [u0 + R() * (u1 - u0), y0 + R() * (y1 - y0)];
  const ALL = inRect(-0.04, -0.02, 1.04, 1.04);
  // blob outline in floor space (irregular closed shape around (u, y), radius r in u units)
  const blobPts = (R, u, y, r, n, j) => rep(n, i => { const a = i / n * Math.PI * 2, q = r * (1 - j / 2 + R() * j); return [u + Math.cos(a) * q * AX, y + Math.sin(a) * q * 0.85]; });
  const blobD = pts => crvW(pts.concat([pts[0], pts[1]]));
  const inBlob = (u, y, B) => B.some(([bu, by, br]) => ((u - bu) / (br * AX)) ** 2 + ((y - by) / (br * 0.85)) ** 2 < 1);
  const DEF32 = '<filter id="g32b" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.25"/></filter>'
    + '<linearGradient id="g32sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#cfe2ee"/><stop offset="0.55" stop-color="#8fa9b8"/><stop offset="1" stop-color="#5e7480"/></linearGradient>'
    + '<linearGradient id="g32pud" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#dfe8ec" stop-opacity="0.75"/><stop offset="0.45" stop-color="#9aaab2" stop-opacity="0.35"/><stop offset="1" stop-color="#6a5a44" stop-opacity="0.1"/></linearGradient>'
    + '<radialGradient id="g32sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff6d8" stop-opacity="0.5"/><stop offset="1" stop-color="#fff6d8" stop-opacity="0"/></radialGradient>'
    + '<linearGradient id="t32w" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd694" stop-opacity="0.2"/><stop offset="0.6" stop-color="#ffd694" stop-opacity="0.04"/><stop offset="1" stop-color="#5a3a1a" stop-opacity="0.08"/></linearGradient>'
    + '<filter id="s32g" x="-200%" y="-200%" width="500%" height="500%"><feGaussianBlur stdDeviation="0.35"/></filter><filter id="s32h" x="-300%" y="-300%" width="700%" height="700%"><feMorphology operator="dilate" radius="0.25"/><feGaussianBlur stdDeviation="0.9"/></filter>'
    + '<linearGradient id="s32sky" x1="0" y1="0" x2="0.4" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.38"/><stop offset="0.45" stop-color="#dfeaf2" stop-opacity="0.08"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.18"/></linearGradient>';

  // ======================= GROUNDS =======================
  // YRD-005 PATCHY DIRT YARD WITH CRABGRASS & MUD PUDDLES (T1): a neglected yard of sun-baked brown dirt: dry crack network, pebbles and grit, wheel ruts,
  // thin dead grass, scruffy clumps of crabgrass (half green, half straw-yellow), two brown mud puddles reflecting a grey sky, sneaker and paw prints
  // pressed into the mud round them, a rusty bottle cap and a popsicle stick. Live: drips ring the puddles, the crabgrass stirs in the breeze.
  function gDirt() { const R = rng('dirt32');
    let s = '<rect width="80" height="56" fill="#8a6c4c"/>';
    s += fblot('dirt32a', 34, ['#9b7d58', '#735a3e', '#a68862', '#6a5236', '#8f7452'], 0.42, 8);
    // wheel ruts (two dark compacted bands running front to back, slightly curved)
    [0.36, 0.47].forEach((u, i) => { s += `<path d="${crvW([[u - 0.05, -0.05], [u - 0.02, 0.3], [u + 0.02, 0.62], [u + 0.07, 1.05]])}" stroke="#5e4930" stroke-width="${f1((1.6 + i * 0.3) * AX)}" fill="none" opacity="0.45" filter="url(#fb1)"/>`
      + `<path d="${crvW([[u - 0.048, -0.05], [u - 0.018, 0.3], [u + 0.022, 0.62], [u + 0.072, 1.05]])}" stroke="#b39672" stroke-width="0.25" fill="none" opacity="0.5"/>`; });
    // sun-baked crack network in the open dirt
    const cracks = [[0.72, 0.3], [0.16, 0.7], [0.82, 0.78], [0.58, 0.12]];
    cracks.forEach(([cu, cy], ci) => { const R2 = rng('crk32' + ci); let d = ''; rep(9, () => { let u = cu + (R2() - 0.5) * 0.14 * AX, y = cy + (R2() - 0.5) * 0.16; const pts = [[u, y]]; rep(3, () => { u += (R2() - 0.5) * 0.035 * AX; y += (R2() - 0.5) * 0.04; pts.push([u, y]); }); d += lineW(pts); });
      s += `<path d="${d}" stroke="#5a4630" stroke-width="0.12" fill="none" opacity="0.6" stroke-linejoin="round"/><path d="${d}" stroke="#b89a74" stroke-width="0.12" fill="none" opacity="0.35" transform="translate(0.12 0.14)"/>`; });
    // grit + pebbles (pebbles get a dark contact shadow and a light top)
    s += `<path d="${rep(700, () => dotD(R() * 1.04 - 0.02, R() * 1.04 - 0.02, 0.05 + R() * 0.06)).join('')}" fill="#5a4630" opacity="0.55"/>`;
    s += `<path d="${rep(500, () => dotD(R() * 1.04 - 0.02, R() * 1.04 - 0.02, 0.04 + R() * 0.05)).join('')}" fill="#c4a882" opacity="0.5"/>`;
    s += rep(70, () => { const u = R(), y = R(), r = 0.12 + R() * 0.22, c = ['#8e8a82', '#a49c8e', '#7a746a', '#b8ae9c'][Math.floor(R() * 4)]; return dot(u, y + 0.006, r * 1.1, 'fill="#3e3020" opacity="0.4"') + dot(u, y, r, `fill="${c}"`) + dot(u - 0.002, y - 0.006, r * 0.45, 'fill="#ffffff" opacity="0.35"'); }).join('');
    // two mud puddles: wet dark rim, brown water reflecting a grey sky, prints pressed in round the edge
    const PUD = [[0.24, 0.42, 0.11], [0.68, 0.64, 0.085]], PB = [];
    PUD.forEach(([u, y, r], i) => { const R3 = rng('pud32' + i), sq = p => p.map(([a, b]) => [a, y + (b - y) * 0.72]), rim = sq(blobPts(R3, u, y, r * 1.3, 12, 0.35)), wat = sq(blobPts(R3, u, y, r, 12, 0.3)); PB.push([u, y, r * 1.4]);
      s += `<path d="${blobD(rim)}" fill="#5a4630" opacity="0.8" filter="url(#fb1)"/><path d="${blobD(wat)}" fill="#4a3a28"/>`
        + `<path d="${blobD(wat)}" fill="url(#g32pud)"/>`
        + `<path d="${crvW([[u - r * 0.75 * AX, y - r * 0.45], [u - r * 0.2 * AX, y - r * 0.58], [u + r * 0.5 * AX, y - r * 0.5]])}" stroke="#ffffff" stroke-width="0.2" fill="none" opacity="0.55" stroke-linecap="round"/>`
        + rep(2, j => dot(u + (j - 0.5) * r * 0.6 * AX, y + r * 0.1 * j, r * (14 + j * 8), 'fill="none" stroke="#e8f0f2" stroke-width="0.1" opacity="0.35"')).join('')
        + `<path d="${blobD(wat)}" fill="none" stroke="#2e2216" stroke-width="0.18" opacity="0.5"/>`
        + `<path d="${crvW([[u - r * 0.8, y + r * 0.45], [u, y + r * 0.7], [u + r * 0.8, y + r * 0.46]])}" stroke="#2e2216" stroke-width="0.2" fill="none" opacity="0.3"/>`;
      // drips: rings growing from a few points, out of step
      rep(3, j => { const pu = u + (R3() - 0.5) * r * AX, py = y + (R3() - 0.5) * r * 0.9, T = 2.6 + R3() * 1.8, b = -R3() * T, k = K(py), q = P(pu, py);
        s += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="0.1" ry="0.06" fill="none" stroke="#e8f0f4" stroke-width="0.14">${an('rx', `0.1;${f1(r * 6 * k * AX)};${f1(r * 6 * k * AX)}`, T, b, ' keyTimes="0;0.7;1"')}${an('ry', `0.06;${f1(r * 3.2 * k)};${f1(r * 3.2 * k)}`, T, b, ' keyTimes="0;0.7;1"')}${an('opacity', '0.8;0;0', T, b, ' keyTimes="0;0.7;1"')}</ellipse>`; }); });
    // a leaf floating on the big puddle, drifting
    { const q = P(0.22, 0.4), k = K(0.4); s += `<g transform="translate(${f1(q[0])} ${f1(q[1])})${SX()}"><g>${at('translate', `0 0;${f1(0.8 * k)} ${f1(0.25 * k)};0 0`, 9, 0, SPL(2))}<path d="M${f1(-0.6 * k)} 0q${f1(0.6 * k)} ${f1(-0.45 * k)} ${f1(1.2 * k)} 0q${f1(-0.6 * k)} ${f1(0.45 * k)} ${f1(-1.2 * k)} 0Z" fill="#b8862e"/><path d="M${f1(-0.6 * k)} 0h${f1(1.2 * k)}" stroke="#7a561c" stroke-width="0.08"/></g></g>`; }
    // sneaker prints + paw prints in the mud round the puddles
    const shoe = (u, y, a, l) => { const q = P(u, y), k = K(y); return `<g transform="translate(${f1(q[0])} ${f1(q[1])})${SX()} rotate(${a}) scale(${f1(k)} ${f1(k * 0.6)})"><path d="M-0.35 -0.9q0.4 -0.25 0.7 0q0.12 0.5 -0.05 0.95q0.05 0.3 -0.05 0.75q-0.25 0.2 -0.5 0q-0.12 -0.4 -0.05 -0.75q-0.2 -0.45 -0.05 -0.95Z" fill="#4e3a26" opacity="0.7"/>${rep(5, j => `<path d="M-0.28 ${f1(-0.7 + j * 0.3)}h0.5" stroke="#6e5638" stroke-width="0.07"/>`).join('')}</g>`; };
    s += shoe(0.4, 0.36, 12, 1) + shoe(0.43, 0.48, 6, 0) + shoe(0.45, 0.6, 14, 1) + shoe(0.5, 0.72, 8, 0) + shoe(0.53, 0.84, 12, 1);
    s += rep(6, i => { const u = 0.62 + i * 0.035, y = 0.5 + i * 0.04 + (i % 2) * 0.02; return dot(u, y, 0.16, 'fill="#4e3a26" opacity="0.6"') + rep(4, j => dot(u + (-0.012 + j * 0.008) * AX, y - 0.022 - (j % 3 === 0 ? 0 : 0.006), 0.06, 'fill="#4e3a26" opacity="0.6"')).join(''); }).join('');
    // thin dead grass across the dirt, crabgrass clumps (spreading flat stems + upright blades, green going straw-yellow)
    s += blades(R, 900, ALL, ['#a89260', '#8c7a48', '#b8a470', '#7a6c3e'], 0.35, 0.8, 0.09, 0, (u, y) => !inBlob(u, y, PB));
    const CL = rep(18, () => [0.04 + R() * 0.92, 0.03 + R() * 0.95, 0.035 + R() * 0.05]).filter(c => !inBlob(c[0], c[1], PB));
    CL.forEach(([u, y, r]) => { const R4 = rng('clump' + u); let d = ''; rep(9, () => { const a = R4() * Math.PI * 2, l = r * (0.6 + R4() * 0.6); d += crvW([[u, y], [u + Math.cos(a) * l * 0.5 * AX, y + Math.sin(a) * l * 0.6 + 0.004], [u + Math.cos(a) * l * AX, y + Math.sin(a) * l * 1.2]]); });
      s += dot(u, y + 0.004, r * 40, 'fill="#3e3020" opacity="0.25" filter="url(#fb1)"') + `<path d="${d}" stroke="#7a8a3a" stroke-width="${f1(0.2 * K(y) * AX)}" fill="none" stroke-linecap="round"/>`; });
    s += blades(R, 1500, R => { const c = CL[Math.floor(R() * CL.length)]; if (!c) return null; const a = R() * Math.PI * 2, q = Math.sqrt(R()) * c[2]; return [c[0] + Math.cos(a) * q * AX, c[1] + Math.sin(a) * q * 0.85]; },
      ['#7c9a3a', '#93ae46', '#c2b46a', '#a69a52', '#6a8432'], 0.5, 1.25, 0.13, 3);
    // litter: rusty bottle cap + popsicle stick
    { const q = P(0.86, 0.36), k = K(0.36); s += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.42 * k * AX)}" ry="${f1(0.24 * k)}" fill="#8e3a22"/><ellipse cx="${f1(q[0])}" cy="${f1(q[1] - 0.05)}" rx="${f1(0.3 * k * AX)}" ry="${f1(0.16 * k)}" fill="#b85a36"/><ellipse cx="${f1(q[0] - 0.1 * k * AX)}" cy="${f1(q[1] - 0.08)}" rx="${f1(0.1 * k * AX)}" ry="${f1(0.05 * k)}" fill="#e8c8a0" opacity="0.6"/>`; }
    { const q = P(0.12, 0.86), k = K(0.86); s += `<g transform="translate(${f1(q[0])} ${f1(q[1])})${SX()} rotate(-24)"><rect x="${f1(-1.1 * k)}" y="${f1(-0.13 * k)}" width="${f1(2.2 * k)}" height="${f1(0.26 * k)}" rx="${f1(0.13 * k)}" fill="#d8c290"/><rect x="${f1(-1.1 * k)}" y="${f1(-0.13 * k)}" width="${f1(2.2 * k)}" height="${f1(0.08 * k)}" rx="${f1(0.04 * k)}" fill="#f0e2b8"/></g>`; }
    return FL('<defs>' + DEF32 + '</defs>' + s);
  }

  // YRD-025 SEEDED GREEN CLOVER & RYEGRASS LAWN (T2): a young lawn sown from a seed mix: soft bright ryegrass, patches of three-leaf white clover with little
  // white-pink pom-pom flowers on short stalks, a couple of thin spots where the seed has not filled in yet (bare soil, scattered seed, golden straw mulch),
  // one dandelion and a few daisies. Live: the grass waves in slow rows and the clover flowers nod.
  function gClover() { const R = rng('clov32');
    let s = '<rect width="80" height="56" fill="#5e8a32"/>';
    s += fblot('clov32a', 30, ['#6c9a3a', '#507c2a', '#7aa844', '#4a7026', '#689636'], 0.45, 9);
    // thin spots: soil, seed specks, straw mulch
    const TH = [[0.78, 0.26, 0.07], [0.2, 0.74, 0.06]];
    TH.forEach(([u, y, r], i) => { const R2 = rng('thin' + i); s += `<path d="${blobD(blobPts(R2, u, y, r, 11, 0.45))}" fill="#7a5e3e" opacity="0.9" filter="url(#fb1)"/>`
      + `<path d="${rep(70, () => dotD(u + (R2() - 0.5) * r * 1.6 * AX, y + (R2() - 0.5) * r * 1.9, 0.035)).join('')}" fill="#e6d29a"/>`
      + `<path d="${rep(26, () => { const a = R2() * 3.14, uu = u + (R2() - 0.5) * r * 1.8 * AX, yy = y + (R2() - 0.5) * r * 2; return lineW([[uu, yy], [uu + Math.cos(a) * 0.02 * AX, yy + Math.sin(a) * 0.03]]); }).join('')}" stroke="#d8b860" stroke-width="0.12" stroke-linecap="round"/>`; });
    const keepT = (u, y) => !TH.some(([tu, ty, tr]) => ((u - tu) / (tr * AX)) ** 2 + ((y - ty) / (tr * 0.85)) ** 2 < 0.55);
    // dense ryegrass: under layer (dark, short, no sway) + top layer (bright, swaying rows)
    s += blades(R, 2600, ALL, ['#3e6a22', '#4a7a28', '#365e1e'], 0.4, 0.75, 0.11, 0, keepT);
    // clover patches: trefoil leaves (3 hearts round a point) in blue-green with a pale chevron
    const CP = rep(9, () => [0.06 + R() * 0.88, 0.05 + R() * 0.92, 0.05 + R() * 0.05]);
    const tref = (u, y, sz) => { const q = P(u, y), k = K(y) * sz, a0 = R() * 120; return `<g transform="translate(${f1(q[0])} ${f1(q[1])})${SX()} scale(1 0.62) rotate(${f1(a0)})">` + rep(3, j => `<g transform="rotate(${j * 120})"><path d="M0 0c${f1(-0.5 * k)} ${f1(-0.3 * k)} ${f1(-0.55 * k)} ${f1(-0.8 * k)} ${f1(-0.22 * k)} ${f1(-0.85 * k)}c${f1(0.12 * k)} 0 ${f1(0.2 * k)} ${f1(0.1 * k)} ${f1(0.22 * k)} ${f1(0.18 * k)}c${f1(0.02 * k)} ${f1(-0.08 * k)} ${f1(0.1 * k)} ${f1(-0.18 * k)} ${f1(0.22 * k)} ${f1(-0.18 * k)}c${f1(0.33 * k)} ${f1(0.05 * k)} ${f1(0.28 * k)} ${f1(0.55 * k)} ${f1(-0.22 * k)} ${f1(0.85 * k)}Z" fill="${R() < 0.5 ? '#4e8a3a' : '#5a9842'}"/><path d="M${f1(-0.2 * k)} ${f1(-0.55 * k)}l${f1(0.2 * k)} ${f1(0.12 * k)}l${f1(0.2 * k)} ${f1(-0.12 * k)}" stroke="#b8d8a0" stroke-width="${f1(0.07 * k)}" fill="none" opacity="0.7"/></g>`).join('') + '</g>'; };
    CP.forEach(([u, y, r]) => { s += rep(26, () => { const a = R() * Math.PI * 2, q = Math.sqrt(R()) * r; return tref(u + Math.cos(a) * q * AX, y + Math.sin(a) * q * 0.85, 0.8 + R() * 0.5); }).join(''); });
    s += blades(R, 3600, ALL, ['#6ea83c', '#82bc48', '#5c9632', '#94c652', '#4e8a2c'], 0.7, 1.35, 0.12, 3.2, keepT);
    // white clover flowers (pom-poms) on short stalks, nodding
    CP.forEach(([u, y, r], ci) => rep(4, j => { const a = R() * 6.28, q = Math.sqrt(R()) * r, fu = u + Math.cos(a) * q * AX, fy = y + Math.sin(a) * q * 0.85, p = P(fu, fy), k = K(fy), h = 1.3 * k;
      s += `<g transform="translate(${f1(p[0])} ${f1(p[1])})${SX()}"><g>${at('rotate', '0;7;0;-5;0', 3.2 + R() * 1.6, -R() * 3, SPL(4))}<path d="M0 0q${f1(0.15 * k)} ${f1(-h * 0.5)} 0 ${f1(-h)}" stroke="#5a8a34" stroke-width="${f1(0.1 * k)}" fill="none"/>`
        + `<circle cx="0" cy="${f1(-h)}" r="${f1(0.38 * k)}" fill="#f2ece4"/>` + rep(7, m => `<circle cx="${f1(Math.cos(m) * 0.22 * k)}" cy="${f1(-h + Math.sin(m) * 0.2 * k)}" r="${f1(0.13 * k)}" fill="${m % 3 ? '#ffffff' : '#f2c8d4'}"/>`).join('') + `<circle cx="${f1(-0.1 * k)}" cy="${f1(-h - 0.12 * k)}" r="${f1(0.09 * k)}" fill="#ffffff"/></g></g>`; }));
    // a dandelion + three daisies
    { const p = P(0.56, 0.58), k = K(0.58); s += `<g transform="translate(${f1(p[0])} ${f1(p[1])})${SX()}">${rep(6, j => `<path d="M0 0l${f1(Math.cos(j) * 0.9 * k)} ${f1(Math.sin(j) * 0.35 * k)}" stroke="#4e8a2c" stroke-width="${f1(0.22 * k)}" stroke-linecap="round"/>`).join('')}<g>${at('rotate', '0;5;0;-4;0', 4.4, 0, SPL(4))}<path d="M0 0v${f1(-1.6 * k)}" stroke="#5e9a34" stroke-width="${f1(0.09 * k)}"/><circle cy="${f1(-1.6 * k)}" r="${f1(0.42 * k)}" fill="#f2c21a"/><circle cy="${f1(-1.68 * k)}" r="${f1(0.24 * k)}" fill="#ffd84a"/></g></g>`; }
    [[0.3, 0.3], [0.66, 0.82], [0.9, 0.62]].forEach(([u, y]) => { const p = P(u, y), k = K(y); s += `<g transform="translate(${f1(p[0])} ${f1(p[1] - 0.9 * k)})${SX()}"><g>${at('rotate', '0;6;0;-4;0', 3.8 + u, -u * 3, SPL(4))}${rep(10, j => `<ellipse cx="${f1(Math.cos(j * 0.628) * 0.3 * k)}" cy="${f1(Math.sin(j * 0.628) * 0.18 * k)}" rx="${f1(0.2 * k)}" ry="${f1(0.08 * k)}" transform="rotate(${j * 36} ${f1(Math.cos(j * 0.628) * 0.3 * k)} ${f1(Math.sin(j * 0.628) * 0.18 * k)})" fill="#ffffff"/>`).join('')}<circle r="${f1(0.13 * k)}" fill="#f4c21e"/></g></g>`; });
    return FL('<defs>' + DEF32 + '</defs>' + s);
  }

  // YRD-045 MANICURED ZOYSIA TURF WITH FLAGSTONE STEPPING PATH (T3): a dense, carpet-like zoysia lawn cut short, with crisp mowing stripes, and a curving
  // path of irregular bluestone flagstones set flush in the turf (cleft surface, pale edges, a little moss in the joints, clean grass margins).
  // Live: wind sheen slides across the stripes and soft sun dapples drift over the lawn and stones.
  function gZoysia() { const R = rng('zoy32');
    let s = '<rect width="80" height="56" fill="#4f8a2e"/>';
    s += fblot('zoy32a', 26, ['#58943a', '#46802a', '#5c9a3c', '#4a842e'], 0.35, 10);
    // mowing stripes: alternating light / dark bands running front to back
    s += rep(8, i => `<path d="${polyW([[i / 8, -0.03], [(i + 1) / 8, -0.03], [(i + 1) / 8, 1.04], [i / 8, 1.04]])}" fill="${i % 2 ? '#2e5e1a' : '#a4d468'}" opacity="${i % 2 ? 0.18 : 0.16}"/>`).join('');
    // flagstone path: 7 steppers on a gentle S from the back left to the front right
    const PATH = [[0.2, 0.08], [0.27, 0.22], [0.37, 0.36], [0.49, 0.5], [0.58, 0.64], [0.64, 0.78], [0.7, 0.93]], ST = [];
    PATH.forEach(([u, y], i) => { const R2 = rng('flag' + i), r = 0.055 + R2() * 0.015; ST.push([u, y, r * 1.2]); });
    const keepS = (u, y) => !inBlob(u, y, ST);
    // dense fine turf: short, many, small widths; top layer sways a little
    s += blades(R, 3000, ALL, ['#3c7424', '#467e2a', '#336a1e'], 0.3, 0.55, 0.09, 0, keepS);
    s += blades(R, 4200, ALL, ['#5a9a36', '#69a83e', '#4c8c2e', '#78b448'], 0.4, 0.75, 0.09, 1.6, keepS);
    PATH.forEach(([u, y], i) => { const R2 = rng('flag' + i), r = ST[i][2] / 1.2, pts = blobPts(R2, u, y, r, 7, 0.45).map(([a, b]) => [a + (R2() - 0.5) * 0.01 * AX, b]); const poly = Q => polyW(Q);
      const sh = pts.map(([a, b]) => [a + 0.004 * AX, b + 0.012]), c = ['#76808a', '#867f78', '#6e7a84', '#8a8e8c', '#7a7470'][i % 5];
      s += `<path d="${poly(sh)}" fill="#1e2a14" opacity="0.4" filter="url(#fb1)"/><path d="${poly(pts)}" fill="${c}" stroke="${shade(c, 0.7)}" stroke-width="0.15" stroke-linejoin="round"/>`
        // cleft texture: layered ridges + speckle, pale worn top, darker lower edge
        + `<path d="${rep(5, j => crvW([[u - r * 0.8 * AX, y - r * 0.6 + j * r * 0.32], [u, y - r * 0.5 + j * r * 0.3 + (R2() - 0.5) * 0.01], [u + r * 0.8 * AX, y - r * 0.62 + j * r * 0.33]])).join('')}" stroke="${shade(c, 0.82)}" stroke-width="0.12" fill="none" opacity="0.7"/>`
        + `<path d="${rep(40, () => dotD(u + (R2() - 0.5) * r * 1.4 * AX, y + (R2() - 0.5) * r * 1.6, 0.03)).join('')}" fill="${shade(c, 1.2)}" opacity="0.6"/>`
        + `<path d="${poly(pts.map(([a, b]) => [u + (a - u) * 0.6, y - r * 0.1 + (b - y) * 0.55]))}" fill="#ffffff" opacity="0.07"/>`
        + `<path d="${lineW([pts[0], pts[1], pts[2], pts[3]])}" stroke="${shade(c, 0.55)}" stroke-width="0.28" fill="none" opacity="0.7"/>`
        + `<path d="${lineW([pts[4], pts[5], pts[6]])}" stroke="#dfe2e2" stroke-width="0.14" fill="none" opacity="0.5"/>`
        // moss + grass creeping over the edge
        + `<path d="${rep(10, () => { const a = R2() * Math.PI * 2; return dotD(u + Math.cos(a) * r * 0.95 * AX, y + Math.sin(a) * r * 0.8, 0.06 + R2() * 0.05); }).join('')}" fill="#6a9a3a" opacity="0.8"/>`; });
    s += blades(R, 700, R => { const c = ST[Math.floor(R() * ST.length)], a = R() * Math.PI * 2, q = c[2] * (0.95 + R() * 0.2); return [c[0] + Math.cos(a) * q * AX, c[1] + Math.sin(a) * q * 0.85]; }, ['#5a9a36', '#69a83e'], 0.35, 0.6, 0.08, 1.6);
    // wind sheen sliding across the stripes + drifting sun dapples
    s += `<g style="mix-blend-mode:screen" opacity="0.5"><path d="${polyW([[-0.4, -0.05], [-0.25, -0.05], [-0.1, 1.05], [-0.25, 1.05]])}" fill="#e8f8c8" opacity="0.35" filter="url(#fb3)">${at('translate', '0 0;110 0', 11, 0)}</path></g>`;
    s += `<g filter="url(#fb3)" opacity="0.7">${rep(7, i => { const u = R(), y = R(); return `<g>${at('translate', `0 0;${f1(3 + R() * 3)} ${f1(1 + R() * 2)};0 0`, 10 + i * 1.3, -i * 2, SPL(2))}${dot(u, y, 2.4 + R() * 2, 'fill="#fff4c8" opacity="0.22"')}</g>`; }).join('')}</g>`;
    return FL('<defs>' + DEF32 + '</defs>' + s);
  }

  // YRD-065 TRAVERTINE PAVER COURTYARD WITH MOSS-INLAID CHECKERBOARD (T4): honed, tumbled ivory-to-walnut travertine squares alternating with squares of
  // velvety cushion moss. Each paver has its own tone, soft parallel banding, the open pits travertine is known for, a pale lit back edge and a darker
  // tumbled front edge; the moss squares sit a touch lower, bumpy, with tiny red-brown spore stalks. Late warm sun lies across the courtyard.
  // Live: leaf shadows drift slowly over it and dew twinkles on the moss. Grid counts follow AX so the squares stay square in the room copy too.
  function gTrav() { const R = rng('trav32'), NU = Math.round(8 / AX), NY = 10;
    let s = '<rect width="80" height="56" fill="#2e4a1c"/>';
    const TC = ['#eadcc2', '#e4d3b4', '#efe4cf', '#dcc7a4', '#e8d8bc', '#d6bf98', '#f1e6d2'];
    let pv = '', bD = '', bL = '', pit = '', pitL = '', eL = '', eD = '', sh = '', mo = '', mb = ['', '', ''], mk = ['', '', ''], spS = '', spT = '', dew = [], mc = [];
    for (let j = 0; j < NY; j++) for (let i = 0; i < NU; i++) { const u0 = i / NU, u1 = (i + 1) / NU, y0 = j / NY, y1 = (j + 1) / NY, du = u1 - u0, dy = y1 - y0;
      if ((i + j) % 2 === 0) { const iu = du * 0.045, iy = dy * 0.06, a = [u0 + iu, y0 + iy], b = [u1 - iu, y0 + iy], c = [u1 - iu, y1 - iy], d = [u0 + iu, y1 - iy];
        sh += polyW([[a[0] + du * 0.03, a[1] + dy * 0.1], [b[0] + du * 0.03, b[1] + dy * 0.1], [c[0] + du * 0.03, c[1] + dy * 0.12], [d[0] + du * 0.03, d[1] + dy * 0.12]]);
        const tc = TC[Math.floor(R() * TC.length)], fd = [[d[0], d[1]], [c[0], c[1]], [c[0], c[1] + dy * 0.05], [d[0], d[1] + dy * 0.05]];
        pv += `<path d="${polyW(fd)}" fill="${shade(tc, 0.72)}"/><path d="${polyW([a, b, c, d])}" fill="${tc}"/>`;
        // cloudy tone: soft darker + lighter clouds inside the stone
        rep(2, k => { pv += dot(a[0] + (b[0] - a[0]) * (0.2 + R() * 0.6), a[1] + (d[1] - a[1]) * (0.2 + R() * 0.6), 0.9 + R() * 0.8, `fill="${k ? '#fff8ea' : shade(tc, 0.86)}" opacity="${k ? 0.35 : 0.4}" filter="url(#fb1)"`); });
        // banding: soft wavy lines running across the stone (a little tilt per paver)
        const tl = (R() - 0.5) * dy * 0.4; rep(4, k => { const yy = y0 + iy + (k + 0.6 + R() * 0.5) * (dy - 2 * iy) / 4.6; const L = rep(6, m => [a[0] + (b[0] - a[0]) * m / 5, yy + tl * m / 5 + (R() - 0.5) * dy * 0.1]);
          if (k % 2) bD += crvW(L); else bL += crvW(L.map(([p, q]) => [p, q + dy * 0.03])); });
        // pits: small open holes, darker inside with a pale lower lip
        rep(5 + Math.floor(R() * 7), () => { const pu = a[0] + R() * (b[0] - a[0]), py = a[1] + R() * (d[1] - a[1]), r = 0.04 + R() * (R() < 0.2 ? 0.16 : 0.08); pit += dotD(pu, py, r); pitL += dotD(pu, py + 0.004, r * 0.8); });
        eL += lineW([d, a, b]); eD += lineW([[d[0], d[1] - dy * 0.02], [c[0], c[1] - dy * 0.02], [b[0], b[1] + dy * 0.02]]); }
      else { const ou = du * 0.01, oy = dy * 0.01; mo += polyW([[u0 - ou, y0 - oy], [u1 + ou, y0 - oy], [u1 + ou, y1 + oy], [u0 - ou, y1 + oy]]);
        // cushion bumps: soft highlights + darker hollows; speckle; spore stalks; dew
        rep(5, () => { const mu = u0 + du * (0.15 + R() * 0.7), my = y0 + dy * (0.2 + R() * 0.65); mb[0] += dotD(mu, my + dy * 0.08, 0.5 + R() * 0.3); mb[1] += dotD(mu, my, 0.45 + R() * 0.25); mb[2] += dotD(mu - du * 0.04, my - dy * 0.08, 0.2 + R() * 0.12); });
        rep(14, () => { mk[Math.floor(R() * 3)] += dotD(u0 + R() * du, y0 + R() * dy, 0.05 + R() * 0.05); }); mc.push([u0, y0, u1, y1]);
        rep(4, () => { const su = u0 + du * (0.1 + R() * 0.8), sy = y0 + dy * (0.15 + R() * 0.8), p = P(su, sy), k = K(sy), h = (0.5 + R() * 0.35) * k, l = (R() - 0.5) * 0.3 * k * AX;
          spS += `M${f1(p[0])} ${f1(p[1])}q${f1(l * 0.3)} ${f1(-h * 0.6)} ${f1(l)} ${f1(-h)}`; spT += `M${f1(p[0] + l)} ${f1(p[1] - h)}h0.01`; });
        if (R() < 0.6) dew.push([u0 + du * (0.2 + R() * 0.6), y0 + dy * (0.25 + R() * 0.5)]); } }
    s += `<path d="${mo}" fill="#3c6622"/><path d="${mb[0]}" fill="#24401a" opacity="0.45" filter="url(#fb1)"/><path d="${mb[1]}" fill="#5c8c30" opacity="0.8" filter="url(#fb1)"/><path d="${mb[2]}" fill="#9cc860" opacity="0.4" filter="url(#fb1)"/>`
      + `<path d="${mk[0]}" fill="#2a4a18"/><path d="${mk[1]}" fill="#7aa83e"/><path d="${mk[2]}" fill="#a8cc5a" opacity="0.7"/>`
      + blades(R, Math.round(mc.length * 70), R => { const c = mc[Math.floor(R() * mc.length)]; return [c[0] + R() * (c[2] - c[0]), c[1] + R() * (c[3] - c[1])]; }, ['#4e7e2a', '#68983a', '#82b04a', '#3e6a22'], 0.18, 0.42, 0.11, 0)
      + `<path d="${spS}" stroke="#8a5a2c" stroke-width="${f1(0.07 * AX + 0.02)}" fill="none" opacity="0.8"/><path d="${spT}" stroke="#a03a22" stroke-width="0.22" stroke-linecap="round"/>`;
    s += `<path d="${sh}" fill="#16220c" opacity="0.5" filter="url(#fb1)"/>` + pv
      + `<path d="${bD}" stroke="#a88a62" stroke-width="0.14" fill="none" opacity="0.4"/><path d="${bL}" stroke="#fff6e4" stroke-width="0.2" fill="none" opacity="0.5" filter="url(#g32b)"/>`
      + `<path d="${pitL}" fill="#fff4e0" opacity="0.55"/><path d="${pit}" fill="#9a8058" opacity="0.75"/>`
      + `<path d="${eL}" stroke="#fffaf0" stroke-width="0.26" fill="none" opacity="0.75" stroke-linejoin="round"/><path d="${eD}" stroke="#9c8460" stroke-width="0.34" fill="none" opacity="0.6" stroke-linejoin="round"/>`;
    // dew twinkles on the moss
    s += dew.map(([u, y], i) => { const p = P(u, y), T = 3 + R() * 3; return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.16 * K(y))}" fill="#ffffff" opacity="0">${an('opacity', '0;0;0.95;0', T, -R() * T, ' keyTimes="0;0.6;0.75;1"')}</circle>`; }).join('');
    // late warm sun across the courtyard + drifting leaf shadows
    s += `<path d="${polyW([[-0.05, -0.05], [1.05, -0.05], [1.05, 1.05], [-0.05, 1.05]])}" fill="url(#t32w)"/>`;
    s += `<g filter="url(#fb3)" opacity="0.5">${rep(6, i => { const u = R(), y = R(); return `<g>${at('translate', `0 0;${f1(2 + R() * 3)} ${f1(0.6 + R())};0 0`, 13 + i * 1.7, -i * 2.3, SPL(2))}${dot(u, y, 3 + R() * 2.4, 'fill="#1a2010" opacity="0.32"')}${dot(u + 0.04 * AX, y + 0.03, 1.8 + R(), 'fill="#1a2010" opacity="0.25"')}</g>`; }).join('')}</g>`;
    return FL('<defs>' + DEF32 + '</defs>' + s);
  }

  // YRD-085 BIOLUMINESCENT STAR-MOSS LAWN & HEATED PORCELAIN PATIO DECK (T5): a velvet lawn of deep emerald star moss (thousands of tiny star-shaped
  // rosettes) with a raised patio deck of large book-matched porcelain slabs (warm white, soft grey + gold veins, polished sky reflection), a bronze nosing
  // and a warm champagne light line washing the moss below the step. Live: pale mint specks in the moss glow in slow waves, glowing spores float up,
  // a glint slides over the polished slabs, the heated deck breathes warm and shimmers.
  function gStar() { const R = rng('star32');
    let s = '<rect width="80" height="56" fill="#245a2c"/>';
    s += fblot('star32a', 26, ['#2c6834', '#1d4a24', '#367a3a', '#22562a'], 0.5, 9);
    const D0 = [0.07, 0.07, 0.6, 0.5], inD = (u, y) => u > D0[0] - 0.012 && u < D0[2] + 0.012 && y > D0[1] - 0.015 && y < D0[3] + 0.03;
    // star moss rosettes: tiny asterisks in three greens
    s += `<path d="${rep(Math.round(170 / (0.6 + AX * 0.4)), () => dotD(R() * 1.04 - 0.02, R() * 1.04 - 0.02, 0.9 + R() * 1.1)).join('')}" fill="#2e6a34" opacity="0.55" filter="url(#fb1)"/>`
      + `<path d="${rep(Math.round(170 / (0.6 + AX * 0.4)), () => dotD(R() * 1.04 - 0.02, R() * 1.04 - 0.02, 0.45 + R() * 0.6)).join('')}" fill="#4f9a4a" opacity="0.35" filter="url(#fb1)"/>`;
    const st = ['', '', ''];
    rep(Math.round(2600 / (0.6 + AX * 0.4)), () => { const u = R() * 1.04 - 0.02, y = R() * 1.04 - 0.02; if (inD(u, y)) return; const p = P(u, y), k = K(y), a = (0.12 + R() * 0.1) * k, ax = a * AX, b = a * 0.55;
      st[Math.floor(R() * 3)] += `M${f1(p[0] - ax)} ${f1(p[1])}h${f1(2 * ax)}M${f1(p[0] - ax * 0.55)} ${f1(p[1] - b)}l${f1(ax * 1.1)} ${f1(2 * b)}M${f1(p[0] + ax * 0.55)} ${f1(p[1] - b)}l${f1(-ax * 1.1)} ${f1(2 * b)}`; });
    s += `<path d="${st[0]}" stroke="#2f7034" stroke-width="0.12" fill="none"/><path d="${st[1]}" stroke="#46904a" stroke-width="0.11" fill="none"/><path d="${st[2]}" stroke="#6eb25c" stroke-width="0.09" fill="none" opacity="0.7"/>`;
    // bioluminescent specks: bucketed by a diagonal phase so the glow rolls across the lawn in waves
    const NB = 8, gb = rep(NB, () => '');
    rep(Math.round(200 / (0.5 + AX * 0.5)), () => { const u = R(), y = R(); if (inD(u, y)) return; const ph = ((u * 1.4 + y * 0.8) * NB * 0.999) % NB; gb[Math.floor(ph)] += dotD(u, y, (0.16 + R() * 0.14) / Math.sqrt(AX)); });
    s += gb.map((d, i) => `<g opacity="0.25">${an('opacity', '0.18;1;0.18', 5.2, -i * 5.2 / NB, SPL(2))}<path d="${d}" fill="#5effc4" filter="url(#s32h)" transform="scale(1)"/><path d="${d}" fill="#7dffd4" filter="url(#s32g)"/><path d="${d}" fill="#f0fffa"/></g>`).join('');
    // the warm light line under the deck nosing, washing the moss in front of the step
    const HH = 0.95, WR = (u, y) => { const p = W(u, y); return [p[0], p[1] - HH * K(y)]; }, PR = pts => 'M' + pts.map(q => { const p = WR(q[0], q[1]); return f1(p[0]) + ' ' + f1(p[1]); }).join('L') + 'Z';
    s += `<path d="${polyW([[D0[0] - 0.01, D0[3]], [D0[2] + 0.01, D0[3]], [D0[2] + 0.02, D0[3] + 0.05], [D0[0] - 0.02, D0[3] + 0.05]])}" fill="#ffd890" opacity="0.3" filter="url(#fb1)">${an('opacity', '0.22;0.36;0.22', 6, 0, SPL(2))}</path>`;
    s += `<path d="${polyW([[D0[2], D0[1]], [D0[2] + 0.025, D0[1] + 0.02], [D0[2] + 0.025, D0[3] + 0.03], [D0[2], D0[3]]])}" fill="#081a0c" opacity="0.45" filter="url(#fb1)"/>`;
    // deck: risers (front + right side), then the slab top
    const A = [D0[0], D0[1]], B = [D0[2], D0[1]], C = [D0[2], D0[3]], Dd = [D0[0], D0[3]], pW = q => W(q[0], q[1]), pR = q => WR(q[0], q[1]), PT = (p) => f1(p[0]) + ' ' + f1(p[1]);
    s += `<path d="M${PT(pW(Dd))}L${PT(pW(C))}L${PT(pR(C))}L${PT(pR(Dd))}Z" fill="#c9bfae"/><path d="M${PT(pW(C))}L${PT(pW(B))}L${PT(pR(B))}L${PT(pR(C))}Z" fill="#a89c88"/>`
      + `<path d="M${PT(pW(Dd))}L${PT(pW(C))}" stroke="#ffd690" stroke-width="0.35" opacity="0.9"/>`;
    // slabs
    const SU = Math.max(3, Math.round(3.2 / AX)), SY = 3, SC = ['#f1ebe1', '#eee7dc', '#f3eee6', '#ece4d8'];
    let sl = '', jn = '', vn = '', vg = '';
    for (let j = 0; j < SY; j++) for (let i = 0; i < SU; i++) { const u0 = D0[0] + (D0[2] - D0[0]) * i / SU, u1 = D0[0] + (D0[2] - D0[0]) * (i + 1) / SU, y0 = D0[1] + (D0[3] - D0[1]) * j / SY, y1 = D0[1] + (D0[3] - D0[1]) * (j + 1) / SY;
      sl += `<path d="${PR([[u0, y0], [u1, y0], [u1, y1], [u0, y1]])}" fill="${SC[(i * 3 + j) % 4]}"/>`; }
    for (let i = 1; i < SU; i++) { const u = D0[0] + (D0[2] - D0[0]) * i / SU, p = WR(u, D0[1]), q = WR(u, D0[3]); jn += `M${PT(p)}L${PT(q)}`; }
    for (let j = 1; j < SY; j++) { const y = D0[1] + (D0[3] - D0[1]) * j / SY, p = WR(D0[0], y), q = WR(D0[2], y); jn += `M${PT(p)}L${PT(q)}`; }
    // flowing veins that run across the joints (book-matched look): soft grey + thin gold
    const walk = (u, y, du, n, dy0) => { let dyv = dy0, pts = []; for (let m = 0; m <= n; m++) { pts.push(WR(u, y)); u += du; dyv += (R() - 0.5) * 0.012; dyv *= 0.85; y += dyv + (R() - 0.5) * 0.006; } let d = 'M' + PT(pts[0]); for (let m = 1; m < pts.length - 1; m++) d += 'Q' + PT(pts[m]) + ' ' + f1((pts[m][0] + pts[m + 1][0]) / 2) + ' ' + f1((pts[m][1] + pts[m + 1][1]) / 2); return d + 'L' + PT(pts[pts.length - 1]); };
    const dU = (D0[2] - D0[0]) / 24;
    rep(4, k => { const y0 = D0[1] + (D0[3] - D0[1]) * (0.12 + k * 0.25 + (R() - 0.5) * 0.08), dy0 = (R() - 0.5) * 0.012; vn += walk(D0[0] - 0.02, y0, dU, 26, dy0);
      rep(2, () => { const m = 3 + Math.floor(R() * 18); vn += walk(D0[0] + dU * m, y0 + (R() - 0.5) * 0.03, dU * (0.6 + R() * 0.4), 4 + Math.floor(R() * 5), (R() - 0.5) * 0.02); });
      if (k % 2 === 0) vg += walk(D0[0] - 0.02, y0 + 0.012, dU, 26, dy0 * 0.9); });
    s += `<defs><clipPath id="s32d"><path d="${PR([A, B, C, Dd])}"/></clipPath></defs>`;
    s += sl + `<g clip-path="url(#s32d)"><path d="${vn}" stroke="#bdb2a2" stroke-width="0.55" fill="none" opacity="0.45" filter="url(#g32b)"/><path d="${vn}" stroke="#958a78" stroke-width="0.1" fill="none" opacity="0.55"/><path d="${vg}" stroke="#c9a05a" stroke-width="0.12" fill="none" opacity="0.65"/>`
      + `<path d="${PR([A, B, C, Dd])}" fill="url(#s32sky)"/>`
      // heated: the deck breathes warm
      + `<path d="${PR([A, B, C, Dd])}" fill="#ffc77a" opacity="0.05">${an('opacity', '0.03;0.13;0.03', 7, 0, SPL(2))}</path>`
      // polished glint sliding over the slabs
      + `<path d="${PR([[D0[0] - 0.2, D0[1]], [D0[0] - 0.12, D0[1]], [D0[0] - 0.04, D0[3]], [D0[0] - 0.12, D0[3]]])}" fill="#ffffff" opacity="0.4" filter="url(#fb1)">${at('translate', `0 0;${f1(48)} 0`, 9, 0)}</path></g>`
      + `<path d="${jn}" stroke="#a69a88" stroke-width="0.16" fill="none" opacity="0.8"/>`
      // bronze nosing on the front + side edge, lit along the top
      + `<path d="M${PT(pR(Dd))}L${PT(pR(C))}L${PT(pR(B))}" stroke="#8a6630" stroke-width="0.5" fill="none" stroke-linejoin="round"/><path d="M${PT(pR(Dd))}L${PT(pR(C))}L${PT(pR(B))}" stroke="#e8c27a" stroke-width="0.18" fill="none" stroke-linejoin="round"/>`;
    // heat shimmer: faint wavy wisps rising off the warm slabs
    s += `<g opacity="0.55">${rep(6, i => { const u = D0[0] + (D0[2] - D0[0]) * (0.12 + i * 0.15), y = D0[1] + (D0[3] - D0[1]) * (0.3 + R() * 0.5), p = WR(u, y), k = K(y), T = 4 + R() * 2, b = -R() * T;
      return `<g transform="translate(${f1(p[0])} ${f1(p[1])})"><g>${at('translate', `0 0;0 ${f1(-5 * k)}`, T, b)}<path d="M0 0q${f1(0.5 * k * AX)} ${f1(-0.8 * k)} 0 ${f1(-1.6 * k)}t0 ${f1(-1.6 * k)}" stroke="#fff4dc" stroke-width="${f1(0.3 * k * AX + 0.05)}" fill="none" stroke-linecap="round" opacity="0">${an('opacity', '0;0.55;0', T, b)}</path></g></g>`; }).join('')}</g>`;
    // glowing spores drifting up from the moss
    s += rep(10, i => { const u = R(), y = 0.55 + R() * 0.45; if (inD(u, y)) return ''; const p = P(u, y), k = K(y), T = 6 + R() * 4, b = -R() * T;
      return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.22 * k)}" fill="#c8fff0" filter="url(#s32g)" opacity="0">${at('translate', `0 0;${f1((R() - 0.5) * 2 * k)} ${f1(-7 * k)}`, T, b)}${an('opacity', '0;0.9;0', T, b)}</circle>`; }).join('');
    return FL('<defs>' + DEF32 + '</defs>' + s);
  }

  // ======================= FENCES =======================
  // r.f32: one front-on fence picture. Catalog card = 80 x 56 (hazy sky, a scruffy hedge behind, dirt strip, one bay seen straight on). Room copy = a
  // 160 x 56 tile with a clear background: the backyard maps it onto both side fences (patterns rnFenceL / rnFenceR, 160 units -> 50 px along the side,
  // 2 tiles a side, rt.fW), so posts, wires and the bag are drawn wider there (hx) to survive the ~3.2x sideways squeeze, and the tile repeats
  // seamlessly (posts every 80, mesh pitch divides 160).
  // YRD-001 RUSTED CHAIN-LINK FENCE WITH GAPS (T1): galvanised pipe posts gone dull with rust blooms and streaks, a sagging top rail on wire ties,
  // diamond chain-link with rust patches, a torn hole with cut wire ends and a peeled flap, the bottom of the mesh curled up over a dug hollow,
  // a plastic bag snagged on the wire, weeds and a bindweed vine at the base. Live: the bag flutters, the flap and a loose tie swing, weeds sway.
  function fChain(TW, room) { const R = rng('chain32' + TW), hx = room ? 2.4 : 1, yb = room ? 55.6 : 49.5, yt = 10, ry = yt + 1.6;
    const PO = room ? [12, 92] : [9, 71], m0 = ry + 0.9, m1 = yb - 0.8, wpx = room ? 6.4 : 3, wpy = room ? 3.6 : 3.4, ww = room ? 0.75 : 0.26;
    let d = '<linearGradient id="c32p" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#55574f"/><stop offset="0.3" stop-color="#a7aaa4"/><stop offset="0.5" stop-color="#cfd2cc"/><stop offset="1" stop-color="#62645c"/></linearGradient>'
      + '<linearGradient id="c32r" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d4d6d0"/><stop offset="0.55" stop-color="#979a92"/><stop offset="1" stop-color="#55574f"/></linearGradient>'
      + '<filter id="c32b" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.7"/></filter><filter id="c32b2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.6"/></filter>';
    let s = '';
    const sag = x => { if (room) { const t = (((x - PO[0]) % 80) + 80) % 80 / 80; return ry + 0.9 * Math.sin(t * Math.PI); } return x < PO[0] || x > PO[1] ? ry + 0.15 : ry + 1.2 * Math.sin((x - PO[0]) / (PO[1] - PO[0]) * Math.PI); };
    if (!room) { d += '<linearGradient id="c32s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#aec6d4"/><stop offset="0.7" stop-color="#dfe3d8"/><stop offset="1" stop-color="#e6e2d2"/></linearGradient>';
      s += '<rect width="80" height="56" fill="url(#c32s)"/>';
      // a neighbour's shed roof + a scruffy privet hedge behind the fence
      let hd = 'M-2 46V34'; for (let x = -2; x < 82; x += 4 + R() * 3) hd += `Q${f1(x + 2)} ${f1(27 + R() * 5)} ${f1(x + 4 + R() * 2)} ${f1(31 + R() * 4)}`; hd += 'L82 46Z';
      s += `<path d="${hd}" fill="#7a8a56"/><path d="${hd}" fill="#5e6e40" opacity="0.5" transform="translate(0 4)"/>`
        + `<path d="${rep(60, () => { const x = R() * 80, y = 30 + R() * 14; return `M${f1(x)} ${f1(y)}a0.9 0.6 0 1 0 0.01 0`; }).join('')}" stroke="#9aaa6a" stroke-width="0.5" fill="none" opacity="0.6"/>`;
      // dirt strip with patchy dead grass
      s += `<path d="M0 ${f1(yb - 2)}Q40 ${f1(yb - 3)} 80 ${f1(yb - 1.6)}V56H0Z" fill="#8b7354"/><path d="${rep(160, () => `M${f1(R() * 80)} ${f1(yb - 1 + R() * 7)}h0.3`).join('')}" stroke="#5e4a32" stroke-width="0.35" stroke-linecap="round" opacity="0.7"/>`
        + `<path d="${rep(120, () => `M${f1(R() * 80)} ${f1(yb + R() * 7)}h0.25`).join('')}" stroke="#bfa47e" stroke-width="0.3" stroke-linecap="round" opacity="0.7"/>`;
      // shadow of the fence on the dirt
      s += `<path d="M${PO[0]} ${f1(yb + 0.6)}L${PO[1]} ${f1(yb + 0.6)}L${PO[1] + 6} ${f1(yb + 3.2)}L${PO[0] + 6} ${f1(yb + 3.2)}Z" fill="#3a2c1c" opacity="0.18" filter="url(#c32b)"/>`; }
    else s += `<path d="M0 ${f1(yb - 0.5)}H${TW}V56H0Z" fill="#6e5a40" opacity="0.55"/>`;
    // the damage: a torn hole (mesh cut away) and the bottom curled up over a dug hollow
    const HOL = room ? [50, 28, 6.5] : [44, 27, 6], GAP = room ? [112, 136] : [18, 33], gh = room ? 7 : 6, gc = (GAP[0] + GAP[1]) / 2;
    const holeP = rep(12, i => { const a = i / 12 * Math.PI * 2, q = HOL[2] * (0.75 + R() * 0.45); return [HOL[0] + Math.cos(a) * q * (room ? 1.6 : 1), HOL[1] + Math.sin(a) * q * 1.05]; });
    const X0 = room ? -2 : PO[0], X1 = room ? TW + 2 : PO[1];
    let top = `M${X0} ${f1(sag(X0) + 0.6)}`; for (let x = X0; x <= X1; x += 2) top += `L${f1(x)} ${f1(sag(x) + 0.6)}`;
    const bot = `L${X1} ${f1(m1)}L${GAP[1]} ${f1(m1)}Q${f1(gc + 3)} ${f1(m1 - gh * 1.3)} ${f1(gc)} ${f1(m1 - gh)}Q${f1(gc - 3)} ${f1(m1 - gh * 1.3)} ${GAP[0]} ${f1(m1)}L${X0} ${f1(m1)}Z`;
    const holeD = 'M' + holeP.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L') + 'Z';
    d += `<clipPath id="c32m"><path clip-rule="evenodd" d="${top}${bot}${holeD}"/></clipPath>`;
    if (!room) s += `<ellipse cx="${f1(gc)}" cy="${f1(yb + 0.8)}" rx="6" ry="1.7" fill="#4a3a26"/><ellipse cx="${f1(gc)}" cy="${f1(yb + 0.3)}" rx="4.6" ry="0.9" fill="#2e2216" opacity="0.7"/><path d="M${f1(gc + 5)} ${f1(yb + 1.6)}q2.5 -2.2 5.5 0.4z" fill="#9a8060"/><path d="${rep(14, () => `M${f1(gc + 5 + R() * 6)} ${f1(yb + 0.8 + R() * 1.6)}h0.3`).join('')}" stroke="#6a5438" stroke-width="0.4" stroke-linecap="round"/>`;
    else s += `<ellipse cx="${f1(gc)}" cy="${f1(yb)}" rx="10" ry="1.4" fill="#3a2c1c" opacity="0.8"/>`;
    // mesh lattice
    const lat = (xa, xb, ya, yb2, px, py) => { let o = ''; const H = yb2 - ya, sh = H * px / py; for (let x = xa - sh - px; x < xb + px; x += px) o += `M${f1(x)} ${f1(ya)}l${f1(sh)} ${f1(H)}M${f1(x + sh)} ${f1(ya)}l${f1(-sh)} ${f1(H)}`; return o; };
    const MD = lat(X0 - 1, X1 + 1, m0 - 1, m1 + 1, wpx, wpy);
    d += `<mask id="c32rm"><rect width="${TW}" height="56" fill="#000"/><g filter="url(#c32b2)">${rep(room ? 9 : 6, () => `<ellipse cx="${f1(R() * TW)}" cy="${f1(m0 + R() * (m1 - m0))}" rx="${f1((3 + R() * 5) * (room ? 1.6 : 1))}" ry="${f1(2 + R() * 4)}" fill="#fff"/>`).join('')}<ellipse cx="${f1(HOL[0])}" cy="${f1(HOL[1])}" rx="${f1(HOL[2] * 1.6 * (room ? 1.6 : 1))}" ry="${f1(HOL[2] * 1.5)}" fill="#fff"/></g></mask>`;
    s += `<g clip-path="url(#c32m)">` + (room ? '' : `<path d="${MD}" stroke="#2e2a22" stroke-width="${ww}" fill="none" opacity="0.3" transform="translate(0.25 0.35)"/>`)
      + `<path d="${MD}" stroke="${room ? '#868a84' : '#a2a5a0'}" stroke-width="${ww}" fill="none"/><path d="${MD}" stroke="#8e4a22" stroke-width="${f1(ww * 1.25)}" fill="none" mask="url(#c32rm)" opacity="0.6"/>`
      + `<path d="${lat(X0 - 1, X1 + 1, m0 - 1, m1 + 1, wpx, wpy)}" stroke="#e8ebe6" stroke-width="${f1(ww * 0.35)}" fill="none" opacity="0.35" transform="translate(-0.08 -0.05)"/></g>`;
    // knuckles along the top + a bottom tension wire (broken over the gap)
    s += `<path d="${rep(Math.ceil((X1 - X0) / wpx), i => { const x = X0 + i * wpx + wpx / 2; return `M${f1(x - 0.4)} ${f1(sag(x) + 1.2)}q0.4 -1 0.8 0`; }).join('')}" stroke="#8e908a" stroke-width="${f1(ww * 0.9)}" fill="none"/>`;
    s += `<path d="M${X0} ${f1(m1 + 0.3)}L${GAP[0] - 1} ${f1(m1 + 0.4)}q-0.8 -0.6 -1.2 -1.6M${GAP[1] + 1} ${f1(m1 + 0.4)}q0.6 -1.2 0.4 -2M${GAP[1] + 1} ${f1(m1 + 0.4)}L${X1} ${f1(m1 + 0.3)}" stroke="#7e807a" stroke-width="${f1(ww * 1.2)}" fill="none"/>`;
    // curled bottom edge over the gap (a rolled lip of mesh)
    { let cl = ''; for (let t = 0.05; t < 0.96; t += room ? 0.07 : 0.09) { const x = GAP[0] + (GAP[1] - GAP[0]) * t, y = m1 - gh * Math.sin(t * Math.PI) * 1.02; cl += `M${f1(x - 0.6 * hx * 0.6)} ${f1(y)}a${f1(0.6 * hx * 0.6)} 0.7 0 1 0 ${f1(1.2 * hx * 0.6)} 0`; }
      s += `<path d="${cl}" stroke="#9a9c96" stroke-width="${f1(ww)}" fill="none"/><path d="${cl}" stroke="#8a4a24" stroke-width="${f1(ww)}" fill="none" opacity="0.5" transform="translate(0.2 0.2)"/>`; }
    // cut wire ends poking into the hole
    s += `<path d="${holeP.map(([x, y], i) => { const dx = HOL[0] - x, dy = HOL[1] - y, L = Math.hypot(dx, dy), l = 1 + R() * 1.1; return `M${f1(x)} ${f1(y)}q${f1(dx / L * l * 0.5 + (R() - 0.5) * 0.6)} ${f1(dy / L * l * 0.5 + (R() - 0.5) * 0.6)} ${f1(dx / L * l)} ${f1(dy / L * l)}`; }).join('')}" stroke="#9a9c96" stroke-width="${f1(ww)}" fill="none" stroke-linecap="round"/>`;
    // the peeled flap: a triangle of mesh bent out from the bottom of the hole, swinging a little
    { const fx = HOL[0], fy = HOL[1] + HOL[2] * 0.8, fw = HOL[2] * (room ? 1.4 : 0.9), fh = HOL[2] * 1.1;
      d += `<clipPath id="c32f"><path d="M${f1(fx - fw)} ${f1(fy)}L${f1(fx + fw)} ${f1(fy)}L${f1(fx + fw * 0.2)} ${f1(fy + fh)}Z"/></clipPath>`;
      s += `<g transform="translate(${f1(fx)} ${f1(fy)})"><g>${at('rotate', '0;4;0;-3;0', 5.5, 0, SPL(4))}<g transform="translate(${f1(-fx)} ${f1(-fy)})"><path d="M${f1(fx - fw)} ${f1(fy)}L${f1(fx + fw)} ${f1(fy)}L${f1(fx + fw * 0.2)} ${f1(fy + fh)}Z" fill="#2e2a22" opacity="0.12" transform="translate(0.6 0.8)"/><g clip-path="url(#c32f)"><path d="${lat(fx - fw - 1, fx + fw + 1, fy - 1, fy + fh + 1, wpx * 0.9, wpy * 0.7)}" stroke="#bfc2bc" stroke-width="${ww}" fill="none"/></g><path d="M${f1(fx - fw)} ${f1(fy)}L${f1(fx + fw)} ${f1(fy)}" stroke="#8a8c86" stroke-width="${f1(ww * 1.4)}"/></g></g></g>`; }
    // top rail (sagging) with wire ties, then the posts
    { let rl = `M${room ? -2 : 0} ${f1(sag(room ? -2 : 0))}`; for (let x = room ? -2 : 0; x <= TW + 2; x += 2) rl += `L${f1(x)} ${f1(sag(x))}`;
      s += `<path d="${rl}" stroke="#3a3a34" stroke-width="2" fill="none" opacity="0.25" transform="translate(0 0.9)"/><path d="${rl}" stroke="url(#c32r)" stroke-width="${room ? 2.2 : 1.5}" fill="none"/><path d="${rl}" stroke="#eef0ec" stroke-width="0.3" fill="none" opacity="0.6" transform="translate(0 -0.45)"/>`
        + `<path d="${rl}" stroke="#8e4a22" stroke-width="1.5" fill="none" mask="url(#c32rm)" opacity="0.5"/>`
        + `<path d="${rep(Math.floor(TW / 7), i => { const x = 3 + i * 7; return `M${f1(x)} ${f1(sag(x) - 0.8)}q${f1(0.6 * hx * 0.5)} 0.8 0 1.7`; }).join('')}" stroke="#5a5c56" stroke-width="${f1(0.22 * hx * 0.7 + 0.05)}" fill="none"/>`; }
    // a loose tie wire swinging under the rail
    { const x = room ? 70 : 30; s += `<g transform="translate(${x} ${f1(sag(x) + 0.8)})"><g>${at('rotate', '-12;14;-12', 3.4, 0, SPL(2))}<path d="M0 0q${f1(0.5 * hx * 0.5)} 1.5 -0.2 3" stroke="#6a6c66" stroke-width="${f1(0.22 * hx * 0.7 + 0.05)}" fill="none"/></g></g>`; }
    PO.forEach((x, i) => { const pw = room ? 9 : 2, lean = !room && i === 1 ? 4 : 0, H0 = yt - 1.2, H1 = yb + (room ? 0.4 : 1.6);
      s += `<g transform="rotate(${lean} ${x} ${f1(yb)})"><rect x="${f1(x - pw / 2)}" y="${f1(H0)}" width="${f1(pw)}" height="${f1(H1 - H0)}" fill="url(#c32p)"/>`
        + `<path d="M${f1(x + pw * 0.05)} ${f1(H0 + 1)}c0.2 4 -0.2 8 0.1 ${f1(9 + R() * 4)}" stroke="#8e4a22" stroke-width="${f1(pw * 0.18)}" fill="none" opacity="0.55" filter="url(#c32b)"/>`
        + `<ellipse cx="${f1(x)}" cy="${f1(yb - 2)}" rx="${f1(pw * 0.55)}" ry="2.4" fill="#7a3a1a" opacity="0.6" filter="url(#c32b)"/>`
        + rep(3, k => `<ellipse cx="${f1(x + (R() - 0.5) * pw * 0.6)}" cy="${f1(m0 + 4 + R() * (m1 - m0 - 8))}" rx="${f1(pw * 0.2)}" ry="${f1(0.5 + R() * 0.6)}" fill="#9a4e24" opacity="0.6"/>`).join('')
        + [m0 + 6, m1 - 6].map(y => `<rect x="${f1(x - pw * 0.66)}" y="${f1(y)}" width="${f1(pw * 1.32)}" height="0.8" rx="0.3" fill="#8a8c86"/><rect x="${f1(x - pw * 0.66)}" y="${f1(y)}" width="${f1(pw * 1.32)}" height="0.25" fill="#d8dad4"/>`).join('')
        + `<ellipse cx="${x}" cy="${f1(H0)}" rx="${f1(pw * 0.66)}" ry="1.05" fill="#7a7c76"/><ellipse cx="${x}" cy="${f1(H0 - 0.25)}" rx="${f1(pw * 0.6)}" ry="0.85" fill="#c4c6c0"/><ellipse cx="${f1(x - pw * 0.15)}" cy="${f1(H0 - 0.45)}" rx="${f1(pw * 0.2)}" ry="0.3" fill="#ffffff" opacity="0.55"/></g>`; });
    // bindweed climbing the first post (heart leaves + one white trumpet)
    { const x = PO[0], pw = room ? 9 : 2; let v = `M${f1(x - pw * 0.6)} ${f1(yb)}`; for (let y = yb, k = 0; y > yb - 22; y -= 3, k++) v += `Q${f1(x + (k % 2 ? 1 : -1) * pw * 0.9)} ${f1(y - 1.5)} ${f1(x + (k % 2 ? -1 : 1) * pw * 0.55)} ${f1(y - 3)}`;
      s += `<path d="${v}" stroke="#5a7a2e" stroke-width="0.3" fill="none"/>` + rep(6, k => { const y = yb - 2 - k * 3.4, lx = x + (k % 2 ? 1 : -1) * pw * 0.8; return `<path d="M${f1(lx)} ${f1(y)}c${f1(-0.9 * hx * 0.6)} -0.6 ${f1(-0.7 * hx * 0.6)} -1.8 0 -1.2c${f1(0.7 * hx * 0.6)} -0.6 ${f1(0.9 * hx * 0.6)} 0.6 0 1.2Z" fill="${k % 2 ? '#6a9a38' : '#5a8a30'}"/>`; }).join('')
        + `<g transform="translate(${f1(x + pw * 0.9)} ${f1(yb - 15)})"><path d="M0 0l${f1(1.2 * hx * 0.6)} -0.9l0 1.8Z" fill="#f6f2ea"/><ellipse cx="${f1(1.2 * hx * 0.6)}" cy="0" rx="${f1(0.25 * hx * 0.6)}" ry="0.95" fill="#ffffff"/><ellipse cx="${f1(1.1 * hx * 0.6)}" cy="0" rx="${f1(0.1 * hx * 0.6)}" ry="0.35" fill="#f2d870"/></g>`; }
    // a plastic bag snagged on the wire, fluttering
    { const bx = room ? 128 : 60, by = room ? 22 : 21, sx = room ? 2.6 : 1;
      s += `<g transform="translate(${bx} ${by}) scale(${sx} 1)"><g>${at('skewX', '0;9;-5;6;0', 2.6, 0, SPL(4))}<g>${at('scale', '1 1;0.92 1.06;1.04 0.96;1 1', 1.9, 0, SPL(3))}`
        + `<path d="M-0.8 0q-1.6 -0.4 -1.2 1.4M0.8 0q1.4 -0.6 1.1 1.3" stroke="#e6e2d8" stroke-width="0.45" fill="none"/>`
        + `<path d="M-2.2 1.2q1 -0.8 2.2 -0.2q1.2 -0.6 2.2 0.2q0.9 3 0.2 5.6q-2.4 1.2 -4.8 0q-0.7 -2.8 0.2 -5.6Z" fill="#f4f2ec" opacity="0.88"/>`
        + `<path d="M-1.2 2.4q0.4 2 -0.2 3.6M0.6 2.2q0.6 1.8 0.3 3.8M-2 3.4q2 0.6 4 -0.2" stroke="#c8c4b8" stroke-width="0.18" fill="none" opacity="0.8"/><path d="M-1.6 1.8q0.6 0.6 0.4 2.6" stroke="#ffffff" stroke-width="0.3" fill="none" opacity="0.8"/></g></g></g>`; }
    // weeds along the base (some poking through the mesh), swaying
    { const wb = ['', '', '', '']; rep(room ? 70 : 46, () => { const x = R() * TW, h = 1.5 + R() * (R() < 0.2 ? 6 : 3.5), l = (R() - 0.5) * h * 0.6; wb[Math.floor(R() * 4)] += `M${f1(x)} ${f1(yb + 0.3)}q${f1(l * 0.2)} ${f1(-h * 0.6)} ${f1(l)} ${f1(-h)}`; });
      const wc = ['#6a8a34', '#8aa246', '#b0a060', '#5a7a2a'];
      s += `<g transform="translate(0 ${f1(yb)})"><g>${at('skewX', '0;5;0;-3;0', 4.2, 0, SPL(4))}<g transform="translate(0 ${f1(-yb)})">${wb.map((p, i) => `<path d="${p}" stroke="${wc[i]}" stroke-width="${f1(room ? 0.5 : 0.28)}" fill="none" stroke-linecap="round"/>`).join('')}</g></g></g>`;
      // a dandelion gone to seed
      const dx = room ? 150 : 76; s += `<path d="M${dx} ${f1(yb)}q0.4 -3 0 -5.5" stroke="#6a8a34" stroke-width="0.25" fill="none"/><circle cx="${dx}" cy="${f1(yb - 5.9)}" r="1" fill="#f4f4ee" opacity="0.85"/><circle cx="${dx}" cy="${f1(yb - 5.9)}" r="0.3" fill="#c8b880"/>`; }
    return '<defs>' + d + '</defs>' + s;
  }
  // ---- shared fence helpers ----
  // catalog backdrop: hazy sky, a two-layer hedge behind, a ground strip (lawn or gravel) under the fence line
  const cBack = (R, yb, gnd) => { let d = '<linearGradient id="cbs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a9c8de"/><stop offset="0.7" stop-color="#e2ead8"/><stop offset="1" stop-color="#e8e6d2"/></linearGradient>', s = '<rect width="80" height="56" fill="url(#cbs)"/>';
    let hd = 'M-2 46V30'; for (let x = -2; x < 82; x += 4 + R() * 3) hd += `Q${f1(x + 2)} ${f1(22 + R() * 5)} ${f1(x + 4 + R() * 2)} ${f1(27 + R() * 4)}`; hd += 'L82 46Z';
    s += `<path d="${hd}" fill="#7e9a5c"/><path d="${hd}" fill="#58763e" opacity="0.55" transform="translate(0 4)"/>`;
    if (gnd === 'lawn') s += `<path d="M0 ${f1(yb - 1.5)}H80V56H0Z" fill="#6a9a3e"/>` + `<path d="${rep(220, () => { const x = R() * 80, y = yb - 1 + R() * 7.5, h = 0.8 + R() * 1.2; return `M${f1(x)} ${f1(y)}l${f1((R() - 0.5) * 0.6)} ${f1(-h)}`; }).join('')}" stroke="#4e7e2c" stroke-width="0.25" stroke-linecap="round"/>`
      + `<path d="${rep(160, () => { const x = R() * 80, y = yb + R() * 7, h = 0.6 + R(); return `M${f1(x)} ${f1(y)}l${f1((R() - 0.5) * 0.6)} ${f1(-h)}`; }).join('')}" stroke="#8cbc56" stroke-width="0.22" stroke-linecap="round"/>`;
    else s += `<path d="M0 ${f1(yb - 1.5)}H80V56H0Z" fill="#b8b2a4"/><path d="${rep(260, () => `M${f1(R() * 80)} ${f1(yb - 1 + R() * 7.5)}h0.35`).join('')}" stroke="#8a8478" stroke-width="0.45" stroke-linecap="round"/><path d="${rep(200, () => `M${f1(R() * 80)} ${f1(yb - 1 + R() * 7.5)}h0.3`).join('')}" stroke="#e4e0d6" stroke-width="0.4" stroke-linecap="round"/>`;
    return [d, s]; };
  // one compact path for many leaves: an ivy leaf (3 lobes) or a plain oval leaf, placed at (x, y), size sz, angle a (deg), x-squash sx
  const IVY = [[0, 0], [-1, -0.3, -1.6, -1, -1.2, -1.6], [-0.9, -1.4, -0.6, -1.5, -0.5, -1.9], [-0.3, -2.4, 0, -2.7, 0, -2.7], [0, -2.7, 0.3, -2.4, 0.5, -1.9], [0.6, -1.5, 0.9, -1.4, 1.2, -1.6], [1.6, -1, 1, -0.3, 0, 0]];
  const OVAL = [[0, 0], [-0.9, -0.6, -0.9, -2, 0, -2.8], [0.9, -2, 0.9, -0.6, 0, 0]];
  const leafD = (L, x, y, sz, a, sx) => { const c = Math.cos(a * Math.PI / 180), s = Math.sin(a * Math.PI / 180), T = (p, q) => f1(x + (p * c - q * s) * sz * sx) + ' ' + f1(y + (p * s + q * c) * sz);
    let d = 'M' + T(L[0][0], L[0][1]); for (let i = 1; i < L.length; i++) { const k = L[i]; d += 'C' + T(k[0], k[1]) + ' ' + T(k[2], k[3]) + ' ' + T(k[4], k[5]); } return d + 'Z'; };

  // YRD-021 WHITE PAINTED WOODEN PICKET FENCE (T2): a cosy budget picket fence: white-painted pointed pickets on two rails, square posts with
  // pyramid caps, wood grain showing faintly through the paint, a few chips where bare wood peeks out, dirt splash on the bottoms, one picket a little
  // crooked; a pink climbing rose on a post, tulips and daisies along the base, picket shadows on the lawn. Live: flowers nod, a butterfly flits by.
  function fPicket(TW, room) { const R = rng('pick32' + TW), yb = room ? 55.6 : 49.5, hx = room ? 2.4 : 1, PO = room ? [12, 92] : [7, 73], pt = yb - (room ? 34 : 30);
    let d = '<filter id="pk32b" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.6"/></filter>', s = '';
    if (!room) { const [bd, bs] = cBack(R, yb, 'lawn'); d += bd; s += bs;
      // picket shadows on the lawn (sun from the upper left)
      s += `<path d="${rep(12, i => { const x = 3 + i * 6.2; return `M${f1(x)} ${f1(yb)}l4.2 0l3 4.5l-4.2 0Z`; }).join('')}" fill="#2e4a1a" opacity="0.22" filter="url(#pk32b)"/>`; }
    else s += `<path d="M0 ${f1(yb - 0.6)}H${TW}V56H0Z" fill="#4e7a2e" opacity="0.5"/>`;
    // rails behind the pickets
    const RY = [yb - 8, pt + 8];
    RY.forEach(y => { s += `<rect x="-2" y="${f1(y)}" width="${TW + 4}" height="2.4" fill="#e6e0d2"/><rect x="-2" y="${f1(y + 1.8)}" width="${TW + 4}" height="0.6" fill="#b8b0a0"/>`; });
    // pickets
    const pp = room ? 10 : 6.2, pw = room ? 6.6 : 4.2, x0 = room ? 2 : 1.2; let pk = '', sh = '', hi = '', gr = '', chip = '', nail = '', dirt = '';
    for (let x = x0, i = 0; x < TW - 0.5; x += pp, i++) { if (PO.some(p => Math.abs(x + pw / 2 - p) < pw)) continue; const top = pt + (R() - 0.5) * 0.8, crook = (!room && i === 8) || (room && i === 11) ? 2.2 : 0;
      const P = `M${f1(x)} ${f1(yb + 0.6)}V${f1(top + 2.4)}L${f1(x + pw / 2)} ${f1(top)}L${f1(x + pw)} ${f1(top + 2.4)}V${f1(yb + 0.6)}Z`;
      const g0 = crook ? `<g transform="rotate(${crook} ${f1(x + pw / 2)} ${f1(yb)})">` : '', g1 = crook ? '</g>' : '';
      pk += g0 + `<path d="${P}" fill="${R() < 0.3 ? '#f2eee4' : '#f8f6ef'}"/>` + `<path d="M${f1(x + pw * 0.78)} ${f1(yb + 0.6)}V${f1(top + 2.4 - 0.4)}L${f1(x + pw)} ${f1(top + 2.4)}V${f1(yb + 0.6)}Z" fill="#d6cfbf"/>`
        + `<path d="M${f1(x + 0.3)} ${f1(yb)}V${f1(top + 2.6)}L${f1(x + pw / 2)} ${f1(top + 0.4)}" stroke="#ffffff" stroke-width="${f1(0.35 * (room ? 1.6 : 1))}" fill="none" opacity="0.9"/>` + g1;
      if (!crook) { rep(2, () => { const gx = x + pw * (0.2 + R() * 0.55); gr += `M${f1(gx)} ${f1(yb - 1)}c0.2 -6 -0.2 -12 0.1 ${f1(-(14 + R() * 8))}`; });
        RY.forEach(y => { nail += `M${f1(x + pw * 0.32)} ${f1(y + 1.2)}h0.01M${f1(x + pw * 0.68)} ${f1(y + 1.2)}h0.01`; });
        if (R() < 0.3) { const cy = top + 4 + R() * (yb - top - 10); chip += `M${f1(x + pw * (0.2 + R() * 0.5))} ${f1(cy)}l${f1(0.5 * (room ? 1.6 : 1))} -0.4l${f1(0.3 * (room ? 1.6 : 1))} 0.6l${f1(-0.6 * (room ? 1.6 : 1))} 0.5Z`; }
        dirt += `M${f1(x)} ${f1(yb + 0.6)}V${f1(yb - 2.4 - R())}H${f1(x + pw)}V${f1(yb + 0.6)}Z`; } }
    s += pk + `<path d="${gr}" stroke="#d8d0be" stroke-width="${f1(0.14 * (room ? 1.6 : 1))}" fill="none" opacity="0.8"/><path d="${chip}" fill="#a8885e"/><path d="${dirt}" fill="#8a7050" opacity="0.28" filter="url(#pk32b)"/><path d="${nail}" stroke="#7a7468" stroke-width="${f1(room ? 0.9 : 0.45)}" stroke-linecap="round"/>`;
    // posts with pyramid caps
    PO.forEach(x => { const w = room ? 9 : 3.6, t = pt - 3; s += `<rect x="${f1(x - w / 2)}" y="${f1(t)}" width="${f1(w)}" height="${f1(yb + 1 - t)}" fill="#f6f3ea"/><rect x="${f1(x + w * 0.2)}" y="${f1(t)}" width="${f1(w * 0.3)}" height="${f1(yb + 1 - t)}" fill="#d6cfbf"/>`
      + `<rect x="${f1(x - w * 0.62)}" y="${f1(t - 1)}" width="${f1(w * 1.24)}" height="1.2" fill="#ebe6da"/><path d="M${f1(x - w * 0.55)} ${f1(t - 1)}L${f1(x)} ${f1(t - 3.2)}L${f1(x + w * 0.55)} ${f1(t - 1)}Z" fill="#faf8f2"/><path d="M${f1(x)} ${f1(t - 3.2)}L${f1(x + w * 0.55)} ${f1(t - 1)}H${f1(x)}Z" fill="#d8d1c2"/>`
      + `<path d="M${f1(x - w * 0.3)} ${f1(t + 2)}c0.2 8 -0.2 16 0.1 ${f1(yb - t - 6)}" stroke="#d8d0be" stroke-width="${f1(0.14 * (room ? 1.6 : 1))}" fill="none"/>`; });
    // climbing rose on the first post: cane, leaves, pink blooms + buds
    { const x = PO[0], sx = room ? 1.8 : 1; let lv = ''; const bl = [];
      let cane = `M${f1(x - 1)} ${f1(yb)}`; for (let y = yb, k = 0; y > pt - 2; y -= 4, k++) cane += `Q${f1(x + (k % 2 ? 3 : -3) * sx)} ${f1(y - 2)} ${f1(x + (k % 2 ? -1.5 : 1.5) * sx)} ${f1(y - 4)}`;
      rep(16, k => { const y = yb - 2 - k * (yb - pt) / 17, lx = x + (k % 2 ? 2 : -2) * sx + (R() - 0.5) * 2 * sx; lv += leafD(OVAL, lx, y, 0.5 + R() * 0.25, (k % 2 ? 60 : -60) + (R() - 0.5) * 40, sx * 0.8); if (k % 3 === 1) bl.push([lx + (R() - 0.5) * 1.5 * sx, y - 0.6]); });
      s += `<path d="${cane}" stroke="#5a6a2e" stroke-width="0.35" fill="none"/><path d="${lv}" fill="#4a7a30"/>` + bl.map(([bx, by], i) => `<g transform="translate(${f1(bx)} ${f1(by)}) scale(${f1(sx * 0.9)} 0.9)">${rep(5, j => `<circle cx="${f1(Math.cos(j * 1.26) * 0.55)}" cy="${f1(Math.sin(j * 1.26) * 0.5)}" r="0.6" fill="${i % 2 ? '#f08aa8' : '#e8769a'}"/>`).join('')}<circle r="0.45" fill="#d4567e"/><circle cx="-0.15" cy="-0.15" r="0.22" fill="#ffc0d2"/></g>`).join(''); }
    // tulips + daisies along the base, nodding
    { const fl = []; for (let x = room ? 22 : 12; x < TW - 3; x += (room ? 9 : 5) + R() * 4) fl.push(x);
      s += fl.map((x, i) => { const h = 3 + R() * 2.5, tul = i % 3 !== 2, c = ['#e8473a', '#f4c430', '#f08aa8', '#ffffff'][i % 4], sx = room ? 1.6 : 1;
        return `<g transform="translate(${f1(x)} ${f1(yb + 0.4)})"><g>${at('rotate', '0;5;0;-4;0', 3.6 + R() * 1.4, -R() * 3, SPL(4))}<path d="M0 0q0.3 ${f1(-h * 0.5)} 0 ${f1(-h)}" stroke="#4a8a30" stroke-width="0.3" fill="none"/>${leafD(OVAL, 0.2, -0.4, 0.9, 25, sx * 0.7).replace(/^/, '<path d="') + '" fill="#5a9a38"/>'}`
          + (tul ? `<path d="M${f1(-0.8 * sx)} ${f1(-h)}q0 -1.6 ${f1(0.8 * sx)} -1.8q${f1(0.8 * sx)} 0.2 ${f1(0.8 * sx)} 1.8q${f1(-0.8 * sx)} 0.5 ${f1(-1.6 * sx)} 0Z" fill="${c}"/><path d="M0 ${f1(-h - 1.8)}v1.6" stroke="${shade(c, 0.8)}" stroke-width="0.15"/>`
            : `${rep(8, j => `<ellipse cx="${f1(Math.cos(j * 0.785) * 0.7 * sx)}" cy="${f1(-h + Math.sin(j * 0.785) * 0.45)}" rx="${f1(0.45 * sx)}" ry="0.2" transform="rotate(${j * 45} ${f1(Math.cos(j * 0.785) * 0.7 * sx)} ${f1(-h + Math.sin(j * 0.785) * 0.45)})" fill="#ffffff"/>`).join('')}<circle cy="${f1(-h)}" r="0.35" fill="#f2c21a"/>`) + '</g></g>'; }).join('');
      s += `<path d="${rep(room ? 90 : 60, () => { const x = R() * TW, h = 0.8 + R() * 2; return `M${f1(x)} ${f1(yb + 0.6)}q${f1((R() - 0.5) * 0.8)} ${f1(-h * 0.6)} ${f1((R() - 0.5) * 1.2)} ${f1(-h)}`; }).join('')}" stroke="#5a9a36" stroke-width="${room ? 0.45 : 0.25}" fill="none" stroke-linecap="round"/>`; }
    // a butterfly flitting past (card only)
    if (!room) s += `<g transform="translate(40 18)"><g>${at('translate', '0 0;10 -4;18 2;8 6;0 0', 14, 0, SPL(4))}<g>${at('scale', '1 1;0.2 1;1 1', 0.35, 0)}<path d="M0 0q-1.6 -1.8 -2.2 -0.2q0.4 1.2 2.2 0.2Zm0 0q1.6 -1.8 2.2 -0.2q-0.4 1.2 -2.2 0.2Z" fill="#f2a83a"/><path d="M0 0q-1.2 1.6 -0.4 1.8M0 0q1.2 1.6 0.4 1.8" stroke="#e08a2a" stroke-width="0.5" fill="none"/></g><path d="M0 -0.6v1.4" stroke="#3a2a1a" stroke-width="0.25"/></g></g>`;
    return '<defs>' + d + '</defs>' + s;
  }

  // YRD-041 HORIZONTAL CEDAR PRIVACY SLAT FENCE (T3): a tall modern privacy fence of horizontal western red cedar boards (honey to reddish-brown, long
  // grain, the odd knot) with narrow even gaps, a cedar cap rail on top, black powder-coated steel posts, a small black wall light on a post washing the
  // boards warm, ornamental grass in a gravel strip at the base. Live: leaf shadows drift across the boards, the grass sways, the light breathes.
  function fCedar(TW, room) { const R = rng('ced32' + TW), yb = room ? 55.6 : 49.5, yt = room ? 5 : 6, PO = room ? [12, 92] : [7, 73];
    let d = '<filter id="cd32b" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.6"/></filter><filter id="cd32c" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.2"/></filter>'
      + '<linearGradient id="cd32p" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#1a1a1c"/><stop offset="0.4" stop-color="#3a3a3e"/><stop offset="0.6" stop-color="#2a2a2e"/><stop offset="1" stop-color="#121214"/></linearGradient>'
      + '<radialGradient id="cd32l" cx="50%" cy="0%" r="100%"><stop offset="0" stop-color="#ffd890" stop-opacity="0.7"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient>', s = '';
    if (!room) { const [bd, bs] = cBack(R, yb, 'gravel'); d += bd; s += bs; }
    else s += `<path d="M0 ${f1(yb - 0.6)}H${TW}V56H0Z" fill="#9a948a" opacity="0.6"/>`;
    // boards
    const bh = room ? 3.3 : 3.4, gap = room ? 0.55 : 0.45, CC = ['#b8743e', '#c4844a', '#a8663a', '#cf9058', '#b06e40', '#bf7a46', '#9e5e34']; let bo = '', gn = ['', ''], kn = '', eg = '', bt = '';
    for (let y = yt + 3, j = 0; y < yb - 1; y += bh + gap, j++) { const h = Math.min(bh, yb - 0.4 - y), c = CC[Math.floor(R() * CC.length)];
      bo += `<rect x="-1" y="${f1(y)}" width="${TW + 2}" height="${f1(h)}" fill="${c}"/>`;
      // a butt joint in some rows away from the posts
      if (R() < 0.5) { const jx = PO[0] + 20 + R() * 40; bt += `M${f1(jx)} ${f1(y)}v${f1(h)}`; }
      rep(room ? 7 : 4, () => { let x = -2, yy = y + 0.4 + R() * (h - 0.8), q = `M${f1(x)} ${f1(yy)}`; while (x < TW + 2) { const l = 6 + R() * 10; x += l; yy = Math.max(y + 0.3, Math.min(y + h - 0.3, yy + (R() - 0.5) * 0.5)); q += `Q${f1(x - l / 2)} ${f1(yy + (R() - 0.5) * 0.4)} ${f1(x)} ${f1(yy)}`; } gn[R() < 0.5 ? 0 : 1] += q; });
      if (R() < 0.35) { const kx = R() * TW, ky = y + h / 2; kn += `<ellipse cx="${f1(kx)}" cy="${f1(ky)}" rx="${f1(room ? 1.6 : 0.8)}" ry="${f1(h * 0.28)}" fill="#6a3a1c" opacity="0.7"/><ellipse cx="${f1(kx)}" cy="${f1(ky)}" rx="${f1(room ? 2.6 : 1.3)}" ry="${f1(h * 0.4)}" fill="none" stroke="#7a4424" stroke-width="0.12" opacity="0.6"/>`; }
      eg += `M-1 ${f1(y + 0.15)}H${TW + 1}`; }
    s += bo + `<path d="${gn[0]}" stroke="#7a4220" stroke-width="0.12" fill="none" opacity="0.45"/><path d="${gn[1]}" stroke="#e8b07a" stroke-width="0.1" fill="none" opacity="0.4"/>` + kn
      + `<path d="${eg}" stroke="#f0c08c" stroke-width="0.22" opacity="0.6"/><path d="${bt}" stroke="#5a2e14" stroke-width="${room ? 0.5 : 0.25}" opacity="0.6"/>`;
    // gaps read as dark shadow lines just under each board (catalog) - the room tile leaves them clear so the hedge shows through
    if (!room) { let gd = ''; for (let y = yt + 3 + bh; y < yb - 1; y += bh + gap) gd += `M-1 ${f1(y + gap / 2)}H${TW + 1}`; s += `<path d="${gd}" stroke="#2a1a10" stroke-width="${gap}" opacity="0.75"/>`; }
    // cap rail
    s += `<rect x="-1" y="${f1(yt + 0.6)}" width="${TW + 2}" height="2.2" fill="#a8663a"/><rect x="-1" y="${f1(yt)}" width="${TW + 2}" height="1" fill="#d89a62"/><rect x="-1" y="${f1(yt + 2.8)}" width="${TW + 2}" height="0.7" fill="#3a2010" opacity="0.45" filter="url(#cd32b)"/>`;
    // steel posts
    PO.forEach(x => { const w = room ? 8 : 2.6; s += `<rect x="${f1(x - w / 2)}" y="${f1(yt - 0.6)}" width="${f1(w)}" height="${f1(yb + 1 - yt)}" fill="url(#cd32p)"/><rect x="${f1(x - w * 0.6)}" y="${f1(yt - 1.2)}" width="${f1(w * 1.2)}" height="0.8" fill="#2a2a2e"/><rect x="${f1(x - w * 0.15)}" y="${f1(yt)}" width="${f1(w * 0.12)}" height="${f1(yb - yt)}" fill="#6a6a72" opacity="0.5"/>`; });
    // a small black wall light on the second post, washing the boards with a warm cone
    { const x = PO[1], w = room ? 8 : 2.6, ly = yt + 12; s += `<path d="M${f1(x - w * 3)} ${f1(yb)}L${f1(x - w * 0.5)} ${f1(ly + 1.6)}H${f1(x + w * 0.5)}L${f1(x + w * 3)} ${f1(yb)}Z" fill="url(#cd32l)" style="mix-blend-mode:screen">${an('opacity', '0.75;1;0.75', 5, 0, SPL(2))}</path>`
      + `<rect x="${f1(x - w * 0.55)}" y="${f1(ly - 1.4)}" width="${f1(w * 1.1)}" height="3" rx="0.4" fill="#18181a"/><rect x="${f1(x - w * 0.45)}" y="${f1(ly + 1.4)}" width="${f1(w * 0.9)}" height="0.4" fill="#ffe2a8"/>`; }
    // drifting leaf shadows + warm sun wash
    s += `<rect x="0" y="${yt}" width="${TW}" height="${f1(yb - yt)}" fill="#ffcf8a" opacity="0.08"/><g filter="url(#cd32c)" opacity="0.4">${rep(room ? 8 : 5, i => { const x = R() * TW, y = yt + 6 + R() * (yb - yt - 12); return `<g>${at('translate', `0 0;${f1(3 + R() * 3)} ${f1(1 + R())};0 0`, 11 + i * 1.5, -i * 2, SPL(2))}<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1((4 + R() * 4) * (room ? 2 : 1))}" ry="${f1(2.5 + R() * 2)}" fill="#2a1408" opacity="0.5"/></g>`; }).join('')}</g>`;
    // ornamental grass clumps in the gravel strip, swaying
    { const cl = room ? [34, 62, 120, 148] : [20, 46, 62]; cl.forEach((x, i) => { let g = ''; rep(16, () => { const a = (R() - 0.5) * 1.6, h = 5 + R() * 5; g += `M${f1(x + (R() - 0.5) * 2)} ${f1(yb + 0.5)}q${f1(Math.sin(a) * h * 0.3 * (room ? 1.8 : 1))} ${f1(-h * 0.6)} ${f1(Math.sin(a) * h * 0.8 * (room ? 1.8 : 1))} ${f1(-h)}`; });
      s += `<g transform="translate(${x} ${f1(yb)})"><g>${at('skewX', '0;6;0;-4;0', 4 + i * 0.5, -i, SPL(4))}<g transform="translate(${-x} ${f1(-yb)})"><path d="${g}" stroke="${i % 2 ? '#b8a868' : '#8aa04e'}" stroke-width="${room ? 0.45 : 0.25}" fill="none" stroke-linecap="round"/><path d="${g}" stroke="#e8dca0" stroke-width="0.1" fill="none" opacity="0.5" transform="translate(0.15 0)"/></g></g></g>`; }); }
    return '<defs>' + d + '</defs>' + s;
  }

  // YRD-061 IVY-COVERED LIMESTONE GARDEN WALL WITH WROUGHT-IRON GATES (T4): a dressed limestone wall in warm cream ashlar courses with fine recessed
  // joints and a moulded coping stone, two square pillars with stone caps carrying iron lanterns, an arched black wrought-iron double gate with scroll
  // work and gilded spear finials (card: a garden path glimpsed through it), English ivy cascading over the coping. In the room the wall repeats with a
  // pillar every bay and an arched iron grille window in one bay. Live: lanterns flicker warm on the stone, the ivy tendrils sway.
  function fStone(TW, room) { const R = rng('lim32' + TW), yb = room ? 55.6 : 49.5, yt = room ? 14 : 14, hx = room ? 2.4 : 1;
    const PI2 = room ? [12, 92] : [27, 53], pw = room ? 20 : 6;
    let d = '<filter id="st32b" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.6"/></filter>'
      + '<radialGradient id="st32l" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffd890" stop-opacity="0.8"/><stop offset="0.4" stop-color="#ffc870" stop-opacity="0.25"/><stop offset="1" stop-color="#ffc870" stop-opacity="0"/></radialGradient>'
      + '<linearGradient id="st32c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f6efe0"/><stop offset="0.5" stop-color="#e2d6bc"/><stop offset="1" stop-color="#b8a88a"/></linearGradient>', s = '';
    if (!room) { const [bd, bs] = cBack(R, yb, 'lawn'); d += bd; s += bs; }
    else s += `<path d="M0 ${f1(yb - 0.6)}H${TW}V56H0Z" fill="#4e7a2e" opacity="0.5"/>`;
    // the openings: card = gate between the pillars; room = an arched grille window in the first bay
    const OP = room ? { x0: 41, x1: 63, y0: 22, y1: 46, arch: 5 } : { x0: PI2[0] + pw / 2, x1: PI2[1] - pw / 2, y0: yt + 6, y1: yb, arch: 6 };
    const archY = x => OP.y0 + OP.arch * (1 - Math.sqrt(Math.max(0, 1 - ((x - (OP.x0 + OP.x1) / 2) / ((OP.x1 - OP.x0) / 2)) ** 2)));
    let opD = `M${OP.x0} ${OP.y1}`; for (let i = 0; i <= 16; i++) { const x = OP.x0 + (OP.x1 - OP.x0) * i / 16; opD += `L${f1(x)} ${f1(archY(x))}`; } opD += `L${OP.x1} ${OP.y1}Z`;
    d += `<clipPath id="st32w"><path clip-rule="evenodd" d="M-2 ${f1(yt + 2.5)}H${TW + 2}V${f1(yb + 1)}H-2Z${opD}"/></clipPath>`;
    // vista through the gate (card): a lawn path running back to a lit hedge
    if (!room) s += `<g><path d="${opD}" fill="#cfe0c0"/><path d="M${OP.x0} ${f1(yb - 8)}H${OP.x1}V${OP.y1}H${OP.x0}Z" fill="#7aa848"/><path d="M38 ${f1(yb - 8)}H42L46 ${OP.y1}H34Z" fill="#d8ccb0"/><path d="M${OP.x0} ${f1(yb - 8)}Q40 ${f1(yb - 16)} ${OP.x1} ${f1(yb - 8)}Z" fill="#5a8a3a"/><ellipse cx="40" cy="${f1(yb - 14)}" rx="6" ry="4" fill="#fff4c8" opacity="0.35" filter="url(#st32b)"/></g>`;
    // ashlar courses
    let bk = '', jl = '', jd = '', sp = '', st = '';
    const CS = ['#e6dcc6', '#ded2b8', '#ece4d2', '#d8cbb0', '#e2d7bf'];
    for (let y = yt + 3, j = 0; y < yb; j++) { const ch = Math.min(j % 2 ? 4 : 5.4, yb + 0.6 - y); let x = -((j * 5.3) % 12) - 2;
      while (x < TW + 2) { const bw = (room ? 14 : 9) + R() * (room ? 14 : 8), c = CS[Math.floor(R() * CS.length)];
        bk += `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(bw)}" height="${f1(ch)}" fill="${c}"/>`;
        jd += `M${f1(x)} ${f1(y + ch)}h${f1(bw)}M${f1(x + bw)} ${f1(y)}v${f1(ch)}`; jl += `M${f1(x + 0.2)} ${f1(y + 0.2)}h${f1(bw - 0.4)}`;
        rep(room ? 6 : 4, () => { sp += `M${f1(x + R() * bw)} ${f1(y + R() * ch)}h0.2`; }); x += bw; }
      y += ch; }
    // a few darker weathering streaks below the coping
    rep(room ? 6 : 4, () => { const x = R() * TW; st += `M${f1(x)} ${f1(yt + 3)}c0.3 4 -0.3 8 0 ${f1(6 + R() * 8)}`; });
    s += `<g clip-path="url(#st32w)">${bk}<path d="${sp}" stroke="#a89a80" stroke-width="0.35" stroke-linecap="round" opacity="0.5"/><path d="${jd}" stroke="#a49478" stroke-width="0.3" fill="none"/><path d="${jl}" stroke="#fffaf0" stroke-width="0.2" fill="none" opacity="0.6"/><path d="${st}" stroke="#8a7c62" stroke-width="${f1(1.2 * hx * 0.7)}" fill="none" opacity="0.15" filter="url(#st32b)"/></g>`;
    // dressed stone surround round the opening + its shadow
    s += `<path d="${opD}" fill="none" stroke="#c8b898" stroke-width="1.6"/><path d="${opD}" fill="none" stroke="#f4ecdc" stroke-width="0.4" transform="translate(-0.5 -0.4)"/>`;
    // coping: moulded cap with an overhang + shadow on the wall
    s += `<rect x="-2" y="${f1(yt + 3)}" width="${TW + 4}" height="1.2" fill="#5a4c36" opacity="0.35" filter="url(#st32b)"/><rect x="-2" y="${f1(yt)}" width="${TW + 4}" height="3" fill="url(#st32c)"/><rect x="-2" y="${f1(yt)}" width="${TW + 4}" height="0.5" fill="#fffaf0"/><rect x="-2" y="${f1(yt + 2.3)}" width="${TW + 4}" height="0.7" fill="#a89878"/>`;
    // the iron: gate (card) or grille (room): bars with gilded spear tips, rails, a band of C-scrolls, rosettes
    { const IR = '#1c1c20', GD = '#d4a84a', bp = room ? 3.2 : 2.1; let bars = '', tips = '', sc = '', ro = ''; const r1 = OP.y1 - (room ? 4 : 6), r2 = OP.y0 + OP.arch + (room ? 7 : 9);
      for (let x = OP.x0 + bp / 2; x < OP.x1; x += bp) { const ty = archY(x) + (room ? 0.6 : 1.2); bars += `M${f1(x)} ${OP.y1}V${f1(ty)}`; if (!room) tips += `M${f1(x - 0.45)} ${f1(ty + 0.3)}L${f1(x)} ${f1(ty - 1)}L${f1(x + 0.45)} ${f1(ty + 0.3)}Z`; }
      for (let x = OP.x0 + bp; x < OP.x1 - bp / 2; x += bp) { const yy = (r1 + r2) / 2 + (room ? 4 : 5); sc += `M${f1(x - bp / 2)} ${f1(yy)}c${f1(bp * 0.1)} -1.4 ${f1(bp * 0.5)} -1.6 ${f1(bp * 0.5)} -0.6s${f1(-bp * 0.3)} 0.6 ${f1(-bp * 0.2)} 0.1M${f1(x + bp / 2)} ${f1(yy)}c${f1(-bp * 0.1)} -1.4 ${f1(-bp * 0.5)} -1.6 ${f1(-bp * 0.5)} -0.6s${f1(bp * 0.3)} 0.6 ${f1(bp * 0.2)} 0.1`; ro += `M${f1(x)} ${f1(r1)}h0.01M${f1(x)} ${f1(r2)}h0.01`; }
      const bw = room ? 0.8 : 0.42;
      s += `<path d="${bars}" stroke="${IR}" stroke-width="${bw}"/><path d="${bars}" stroke="#5a5a64" stroke-width="${f1(bw * 0.3)}" transform="translate(-${f1(bw * 0.2)} 0)"/>`
        + `<path d="M${OP.x0} ${f1(r1)}H${OP.x1}M${OP.x0} ${f1(r2)}H${OP.x1}" stroke="${IR}" stroke-width="${room ? 1.1 : 0.7}"/><path d="${sc}" stroke="${IR}" stroke-width="${f1(bw * 0.8)}" fill="none"/>`
        + `<path d="${opD.replace(/L[^L]*Z$/, '')}" stroke="${IR}" stroke-width="${room ? 1.2 : 0.8}" fill="none"/>`
        + `<path d="${ro}" stroke="${GD}" stroke-width="${room ? 1.4 : 0.8}" stroke-linecap="round"/>` + (tips ? `<path d="${tips}" fill="${GD}"/>` : '');
      if (!room) s += `<path d="M40 ${OP.y1}V${f1(archY(40) + 1)}" stroke="${IR}" stroke-width="0.8"/><rect x="38.6" y="${f1(r1 - 4)}" width="2.8" height="2.2" rx="0.4" fill="${IR}"/><circle cx="41" cy="${f1(r1 - 2.9)}" r="0.35" fill="${GD}"/>`; }
    // pillars with stone caps + iron lanterns (warm flicker on the stone)
    PI2.forEach((x, i) => { const t = yt - 3, cw = pw * 1.25;
      s += `<rect x="${f1(x - pw / 2)}" y="${f1(t)}" width="${f1(pw)}" height="${f1(yb + 1 - t)}" fill="#e4d9c2"/><rect x="${f1(x + pw * 0.22)}" y="${f1(t)}" width="${f1(pw * 0.28)}" height="${f1(yb + 1 - t)}" fill="#c8b898"/>`
        + rep(Math.floor((yb - t) / 6), k => `<path d="M${f1(x - pw / 2)} ${f1(t + 3 + k * 6)}H${f1(x + pw / 2)}" stroke="#a49478" stroke-width="0.3"/>`).join('')
        + `<rect x="${f1(x - cw / 2)}" y="${f1(t - 2.2)}" width="${f1(cw)}" height="2.4" fill="url(#st32c)"/><rect x="${f1(x - cw / 2)}" y="${f1(t - 2.2)}" width="${f1(cw)}" height="0.45" fill="#fffaf0"/><path d="M${f1(x - cw * 0.42)} ${f1(t - 2.2)}L${f1(x)} ${f1(t - 3.6)}L${f1(x + cw * 0.42)} ${f1(t - 2.2)}Z" fill="#ece2cc"/>`;
      if (!room || i === 1) { const lw = room ? 5 : 2.4, ly = t - 3.6; s += `<ellipse cx="${x}" cy="${f1(ly - 2.4)}" rx="${f1(lw * 2.6)}" ry="6" fill="url(#st32l)" style="mix-blend-mode:screen">${an('opacity', '0.8;1;0.85;0.95;0.8', 2.8 + i * 0.4, -i, SPL(4))}</ellipse>`
        + `<path d="M${f1(x - lw * 0.4)} ${f1(ly)}h${f1(lw * 0.8)}l${f1(lw * 0.1)} -0.6h${f1(-lw)}Z" fill="#1c1c20"/><rect x="${f1(x - lw / 2)}" y="${f1(ly - 4)}" width="${f1(lw)}" height="3.4" fill="#ffd890"><animate attributeName="fill" values="#ffd890;#ffe8b0;#ffcf7a;#ffd890" dur="2.2s" repeatCount="indefinite"/></rect>`
        + `<path d="M${f1(x - lw / 2)} ${f1(ly - 4)}v3.4M${f1(x + lw / 2)} ${f1(ly - 4)}v3.4M${x} ${f1(ly - 4)}v3.4" stroke="#1c1c20" stroke-width="${f1(room ? 0.6 : 0.3)}"/><path d="M${f1(x - lw * 0.65)} ${f1(ly - 4)}L${x} ${f1(ly - 5.6)}L${f1(x + lw * 0.65)} ${f1(ly - 4)}Z" fill="#1c1c20"/><circle cx="${x}" cy="${f1(ly - 5.9)}" r="0.4" fill="#d4a84a"/>`; } });
    // ivy cascading from the coping: masses of leaves in three greens + a few swaying tendrils
    { const MS = room ? [[2, 28], [100, 36], [140, 26]] : [[2, 18], [62, 16], [12, 8]], LV = ['', '', ''], sx = room ? 1.9 : 1; let tdr = '';
      MS.forEach(([x0, w], m) => { const n = Math.round(w * (room ? 3.2 : 5)); rep(n, () => { const x = x0 + R() * w, depth = (1 - Math.abs((x - x0) / w - 0.5) * 2) * (room ? 20 : 16) * (0.5 + R() * 0.7), y = yt + 1 + R() * depth;
        LV[Math.floor(R() * 3)] += leafD(IVY, x, y + 1.4, 0.55 + R() * 0.3, (R() - 0.5) * 60 + 180 * (R() < 0.15), sx); }); });
      s += `<path d="${LV[0]}" fill="#2e5a26"/><path d="${LV[1]}" fill="#3e7030"/><path d="${LV[2]}" fill="#5a8a3c"/><path d="${LV[2]}" fill="none" stroke="#c8dca0" stroke-width="0.08" opacity="0.6"/>`;
      MS.forEach(([x0, w], m) => rep(3, k => { const x = x0 + w * (0.2 + k * 0.3), L = (room ? 14 : 10) + R() * 8; let lv = ''; rep(5, j => { lv += leafD(IVY, x + (j % 2 ? 0.8 : -0.8) * sx, yt + 6 + j * L / 5, 0.5, j % 2 ? 160 : 200, sx); });
        s += `<g transform="translate(${f1(x)} ${f1(yt + 3)})"><g>${at('rotate', '0;3;0;-2.5;0', 5 + k + m * 0.7, -k * 1.3, SPL(4))}<g transform="translate(${f1(-x)} ${f1(-yt - 3)})"><path d="M${f1(x)} ${f1(yt + 3)}q${f1(1.2 * sx)} ${f1(L / 2)} 0 ${f1(L)}" stroke="#5a5a2e" stroke-width="0.25" fill="none"/><path d="${lv}" fill="#3e7030"/></g></g></g>`; })); }
    return '<defs>' + d + '</defs>' + s;
  }

  // YRD-061 in the ROOM. Nov 7 (1): one tile per side, gate only on the right. Nov 7 (2): drawn inline as vector, 104 tall (patterns were soft).
  // Nov 7 (3) (user: everything sat on one flat line, the pillars must stand out from the wall, the ivy looked like flat 2D): fStoneWall3 builds each side
  // in ROOM coordinates with real depth. The side wall plane is the old fence matrix W(x, y) (x along the wall, 0 = back corner; y down from the top);
  // the direction straight out of the wall into the yard is horizontal on screen (parallel to the back wall's floor line), +x on the left wall and -x
  // on the right (s). Flat stonework (blocks, mortar, pitting, stains, lichen, moss) stays on the plane; everything that stands out is offset along s:
  // pillars stand out 5 (gate piers 7) with a front face (translate(s*d) + matrix), the side face that looks toward the viewer (a screen rect, since
  // its edges are vertical + horizontal), a soft shadow on the wall behind them, cornice caps with a lit top face, pyramid tops / ball finials, base
  // blocks; the coping overhangs 1.6 and shows its whole top face across the wall's 5 thickness (the wall reads solid); the plinth steps out 1.2; the
  // gate shows its stone jamb (the reveal through the wall thickness) and the iron sits half way in. Ivy, roses, tendrils, lanterns and the fountain basin
  // are drawn UNSHEARED in screen space, each leaf at its own depth in front of the wall (back leaves darker, front ones lighter and veined) with a soft
  // shadow on the stone, so the foliage has volume. Live: lanterns flicker, tendrils sway, the fountain trickles.
  function fStoneWall3(side, gate, H) { const Lw = side === 'L', s = Lw ? 1 : -1, ax = Lw ? -0.3125 : 0.3125, ox = Lw ? 100 : 752, oy = 100 - H, bxy = 0.50625;
    const M = `matrix(${ax} ${bxy} 0 1 ${ox} ${oy})`, W = (x, y) => [ox + ax * x, oy + bxy * x + y], P = (x, y, o) => { const q = W(x, y); return f1(q[0] + s * (o || 0)) + ' ' + f1(q[1]); };
    const tr = o => `translate(${f1(s * o)} 0) ${M}`, poly = (pts, fill, ex) => `<path d="M${pts.join('L')}Z" fill="${fill}"${ex || ''}/>`;
    const srect = (x, y0, y1, o0, o1, fill, ex) => { const q = W(x, 0), a = q[0] + s * o0, b = q[0] + s * o1; return `<rect x="${f1(Math.min(a, b))}" y="${f1(q[1] + y0)}" width="${f1(Math.abs(b - a))}" height="${f1(y1 - y0)}" fill="${fill}"${ex || ''}/>`; };
    const R = rng('lim33' + side), TW = 320, sx = 3.2, yb = H - 0.4, yc = 3, yw = 13, ypl = yb - 10, I = n => n + 'w3' + side, T = 5, OC = 1.6, OP = 1.2;
    const CS = ['#e9dfc9', '#e2d6bc', '#ede5d3', '#dacdb1', '#e5dac1', '#d6c8aa', '#e0d3b6'], FR = '#ebe1cb', SD = '#cdbd9b', TP = '#f8f2e5';
    const dot = (x, y, r) => `M${f1(x - r * sx)} ${f1(y)}a${f1(r * sx)} ${f1(r)} 0 1 0 ${f1(2 * r * sx)} 0a${f1(r * sx)} ${f1(r)} 0 1 0 ${f1(-2 * r * sx)} 0`, sdot = (x, y, r) => `M${f1(x - r)} ${f1(y)}a${f1(r)} ${f1(r)} 0 1 0 ${f1(2 * r)} 0a${f1(r)} ${f1(r)} 0 1 0 ${f1(-2 * r)} 0`;
    let d = `<filter id="${I('b')}" x="-30%" y="-50%" width="160%" height="200%"><feGaussianBlur stdDeviation="0.9"/></filter><filter id="${I('b2')}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.6"/></filter>`
      + `<radialGradient id="${I('l')}" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffd890" stop-opacity="0.85"/><stop offset="0.35" stop-color="#ffc870" stop-opacity="0.3"/><stop offset="1" stop-color="#ffc870" stop-opacity="0"/></radialGradient>`
      + `<radialGradient id="${I('ball')}" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="#fffbf2"/><stop offset="0.6" stop-color="#e2d6bc"/><stop offset="1" stop-color="#b5a482"/></radialGradient>`
      + `<linearGradient id="${I('c')}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f4ecd9"/><stop offset="0.5" stop-color="#ddd0b2"/><stop offset="1" stop-color="#bba987"/></linearGradient>`
      + `<linearGradient id="${I('k')}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#5a4a30" stop-opacity="0.12"/></linearGradient>`
      + `<linearGradient id="${I('s')}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2e1c" stop-opacity="0.4"/><stop offset="1" stop-color="#3a2e1c" stop-opacity="0"/></linearGradient>`
      + `<linearGradient id="${I('ps')}" x1="1" y1="0" x2="0" y2="0"><stop offset="0" stop-color="#3a2e1c" stop-opacity="0.32"/><stop offset="1" stop-color="#3a2e1c" stop-opacity="0"/></linearGradient>`
      + `<linearGradient id="${I('r')}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6a5a40" stop-opacity="0.22"/><stop offset="1" stop-color="#6a5a40" stop-opacity="0"/></linearGradient>`
      + `<linearGradient id="${I('v')}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#bcdcf0"/><stop offset="0.42" stop-color="#e6efe2"/><stop offset="0.48" stop-color="#6a9a44"/><stop offset="1" stop-color="#7cae4a"/></linearGradient>`
      + `<linearGradient id="${I('a')}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#bfe6f6"/><stop offset="1" stop-color="#6ab0d8"/></linearGradient>`;
    let out = '';
    const G = gate ? { x0: 134, x1: 186, top: 26, spring: 42 } : null, gc = G ? (G.x0 + G.x1) / 2 : 160;
    const archY = x => G.spring - (G.spring - G.top) * Math.sqrt(Math.max(0, 1 - ((x - gc) / ((G.x1 - G.x0) / 2)) ** 2));
    let opD = ''; if (G) { opD = `M${G.x0} ${yb}`; for (let i = 0; i <= 24; i++) { const x = G.x0 + (G.x1 - G.x0) * i / 24; opD += `L${f1(x)} ${f1(archY(x))}`; } opD += `L${G.x1} ${yb}Z`; d += `<clipPath id="${I('o')}"><path transform="${M}" d="${opD}"/></clipPath>`; }
    d += `<clipPath id="${I('m')}"><path clip-rule="evenodd" d="M-2 ${yw}H${TW + 2}V${yb + 0.5}H-2Z${opD}"/></clipPath>`;
    const PIL = gate ? [[12, 22, 0], [74, 22, 0], [G.x0 - 13, 26, 1], [G.x1 + 13, 26, 1], [248, 22, 0], [308, 22, 0]] : [[12, 22, 0], [88, 22, 0], [232, 22, 0], [308, 22, 0]];
    // ---------- the wall plane (flat stonework, in the side matrix) ----------
    let pl = `<path d="M-2 ${f1(yb - 1)}H${TW + 2}V${H + 1}H-2Z" fill="#4e7a2e" opacity="0.6"/>`;
    if (G) pl += `<path d="${opD}" fill="url(#${I('v')})"/><path d="M${f1(gc + 8)} ${f1(yb - 26)}q${f1(1.4 * sx)} -14 ${f1(2.6 * sx)} 0z" fill="#2e5a2a"/><path d="M${G.x0} ${f1(yb - 20)}Q${gc} ${f1(yb - 27)} ${G.x1} ${f1(yb - 20)}V${yb}H${G.x0}Z" fill="#5a8a36"/><path d="M${f1(gc - 2.5)} ${f1(yb - 21)}H${f1(gc + 2.5)}L${f1(gc + 11)} ${yb}H${f1(gc - 11)}Z" fill="#dccfb2"/>`
      + rep(12, i => { const x = G.x0 + 3 + R() * (G.x1 - G.x0 - 6), y = yb - 22 + R() * 4; return `<path d="${dot(x, y, 0.55)}" fill="${['#f0a0b8', '#ffffff', '#e8c84a', '#c88ae0'][i % 4]}"/>`; }).join('');
    let bk = '', hi = '', lo = '', jd = '', pit = '', pit2 = '', chip = '';
    for (let y = yw, j = 0; y < ypl - 0.5; j++) { const ch = Math.min(j % 2 ? 7.6 : 9.2, ypl - y); let x = -((j * 19) % 34) - 4;
      while (x < TW + 2) { const bw = 30 + R() * 20, c = CS[Math.floor(R() * CS.length)];
        bk += `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(bw)}" height="${f1(ch)}" fill="${c}"/>`; hi += `M${f1(x + 1.2)} ${f1(y + 0.5)}h${f1(bw - 2.4)}M${f1(x + 0.9)} ${f1(y + 0.7)}v${f1(ch - 1.6)}`;
        lo += `M${f1(x + 1.2)} ${f1(y + ch - 0.6)}h${f1(bw - 2.2)}M${f1(x + bw - 1.1)} ${f1(y + 0.8)}v${f1(ch - 1.4)}`; jd += `M${f1(x)} ${f1(y + ch)}h${f1(bw)}M${f1(x + bw)} ${f1(y)}v${f1(ch)}`;
        rep(9, () => { pit += dot(x + 2 + R() * (bw - 4), y + 1 + R() * (ch - 2), 0.18 + R() * 0.16); }); rep(4, () => { pit2 += dot(x + 2 + R() * (bw - 4), y + 1 + R() * (ch - 2), 0.12 + R() * 0.1); });
        if (R() < 0.18) chip += `M${f1(x + bw - 0.4)} ${f1(y + ch - 0.4)}l${f1(-2.6 - R() * 2)} 0l1.6 -1.2Z`; x += bw; }
      y += ch; }
    let ck = ''; rep(7, () => { let x = R() * TW, y = yw + 6 + R() * (ypl - yw - 18); ck += `M${f1(x)} ${f1(y)}`; rep(4, () => { x += (R() - 0.5) * 6; y += 2 + R() * 3; ck += `L${f1(x)} ${f1(y)}`; }); });
    let rs = ''; rep(16, () => { const x = R() * TW, w = 3 + R() * 6, h = 12 + R() * 26; rs += `<rect x="${f1(x)}" y="${yw}" width="${f1(w)}" height="${f1(h)}" fill="url(#${I('r')})"/>`; });
    let li = '', li2 = ''; rep(28, () => { const x = R() * TW, y = R() < 0.6 ? ypl - 2 - R() * 14 : yw + 4 + R() * 20; rep(5, () => { li += dot(x + (R() - 0.5) * 6, y + (R() - 0.5) * 3, 0.5 + R() * 0.7); }); rep(2, () => { li2 += dot(x + (R() - 0.5) * 5, y + (R() - 0.5) * 2.4, 0.4 + R() * 0.4); }); });
    pl += `<g clip-path="url(#${I('m')})">${bk}<rect x="-2" y="${yw}" width="${TW + 4}" height="${f1(ypl - yw)}" fill="url(#${I('k')})"/><path d="${pit}" fill="#a39274" opacity="0.55"/><path d="${pit2}" fill="#fffaf0" opacity="0.6"/><path d="${chip}" fill="#c4b494"/>`
      + `<path d="${jd}" stroke="#8a7a5c" stroke-width="0.9" fill="none"/><path d="${jd}" stroke="#f6efe0" stroke-width="0.35" fill="none" transform="translate(0.3 0.6)" opacity="0.7"/><path d="${hi}" stroke="#fffbf2" stroke-width="0.7" fill="none" opacity="0.85"/><path d="${lo}" stroke="#a59475" stroke-width="0.8" fill="none" opacity="0.7"/>`
      + rs + `<path d="${ck}" stroke="#7a6a4e" stroke-width="0.35" fill="none" opacity="0.7"/><path d="${li}" fill="#a8b46a" opacity="0.45"/><path d="${li2}" fill="#d8d0a0" opacity="0.6"/>`
      + `<rect x="-2" y="${yw}" width="${TW + 4}" height="6" fill="url(#${I('s')})"/></g>`;
    // soft shadows the pillars + ivy throw on the wall (toward the back of the yard, down)
    PIL.forEach(([x, pw, big]) => { pl += `<rect x="${f1(x - pw / 2 - (big ? 14 : 10))}" y="${f1(big ? 2 : yc)}" width="${big ? 14 : 10}" height="${f1(yb - (big ? 2 : yc))}" fill="url(#${I('ps')})"/>`; });
    out += `<g transform="${M}">${pl}</g>`;
    // ---------- gate: stone jamb (the reveal through the wall thickness), voussoirs standing slightly proud, iron set half way into the wall ----------
    if (G) { const IR = '#1a1a1e', IR2 = '#4a4a54', GD = '#d8ac4c', bp = 5.2, r1 = yb - 4, r2 = yb - 14, r3 = G.spring + 6;
      { const q = W(G.x0, 0); let jl = ''; for (let y = G.spring + 4; y < yb; y += 8.4) jl += `M${f1(q[0])} ${f1(q[1] + y)}h${f1(-s * T)}`;
        out += srect(G.x0, G.spring - 2, yb, 0, -T, SD) + srect(G.x0, G.spring - 2, yb, -T * 0.55, -T, '#b9a988') + `<path d="${jl}" stroke="#9a8a6a" stroke-width="0.4"/>`; }
      let bars = '', dog = '', tips = '', sc = '', sc2 = ''; for (let x = G.x0 + bp / 2; x < G.x1; x += bp) { const ty = archY(x) + 1.6; bars += `M${f1(x)} ${yb}V${f1(ty)}`; tips += `M${f1(x - 1.1)} ${f1(ty + 0.8)}L${f1(x)} ${f1(ty - 2)}L${f1(x + 1.1)} ${f1(ty + 0.8)}Z`; dog += `M${f1(x + bp / 2)} ${f1(r1)}V${f1(r2 + 3)}`; }
      for (let x = G.x0 + bp; x < G.x1 - bp / 2; x += bp) { const yy = (r2 + r3) / 2; sc += `M${f1(x - bp / 2)} ${f1(yy)}c${f1(bp * 0.1)} -2.4 ${f1(bp * 0.5)} -2.6 ${f1(bp * 0.5)} -1M${f1(x + bp / 2)} ${f1(yy)}c${f1(-bp * 0.1)} -2.4 ${f1(-bp * 0.5)} -2.6 ${f1(-bp * 0.5)} -1`;
        sc2 += `M${f1(x - bp / 2)} ${f1(yy + 1)}c${f1(bp * 0.1)} 2.4 ${f1(bp * 0.5)} 2.6 ${f1(bp * 0.5)} 1M${f1(x + bp / 2)} ${f1(yy + 1)}c${f1(-bp * 0.1)} 2.4 ${f1(-bp * 0.5)} 2.6 ${f1(-bp * 0.5)} 1`; }
      const arc = opD.replace(/L[^L]*Z$/, '');
      out += `<g clip-path="url(#${I('o')})"><g transform="${tr(-T * 0.5)}"><path d="${bars}" stroke="${IR}" stroke-width="0.95"/><path d="${bars}" stroke="${IR2}" stroke-width="0.35" transform="translate(-0.35 0)"/><path d="${dog}" stroke="${IR}" stroke-width="0.7"/><path d="${tips}" fill="${GD}"/>`
        + `<path d="M${G.x0} ${f1(r1)}H${G.x1}M${G.x0} ${f1(r2)}H${G.x1}M${G.x0} ${f1(r3)}H${G.x1}M${G.x0} ${f1(r3 + 7)}H${G.x1}" stroke="${IR}" stroke-width="1.2"/><path d="${sc}" stroke="${IR}" stroke-width="0.75" fill="none"/><path d="${sc2}" stroke="${IR}" stroke-width="0.75" fill="none"/>`
        + `<path d="${arc}" stroke="${IR}" stroke-width="1.3" fill="none" transform="translate(0 1.6)"/><path d="M${gc} ${yb}V${f1(G.top + 1.6)}" stroke="${IR}" stroke-width="1.6"/><path d="${dot(gc, r3 + 3.5, 1.5)}" fill="none" stroke="${GD}" stroke-width="0.6"/></g></g>`;
      let vs = ''; const VN = 11; rep(VN + 1, i => { const a0 = PI * i / (VN + 1), a1 = PI * (i + 1) / (VN + 1), rx = (G.x1 - G.x0) / 2, ry = G.spring - G.top, o = 5.5;
        const Pt = (a, k) => [gc - Math.cos(a) * (rx + k * sx * 0.9), G.spring - Math.sin(a) * (ry + k)]; const A = Pt(a0, 0), B = Pt(a1, 0), C = Pt(a1, o), D2 = Pt(a0, o);
        vs += `<path d="M${f1(A[0])} ${f1(A[1])}L${f1(B[0])} ${f1(B[1])}L${f1(C[0])} ${f1(C[1])}L${f1(D2[0])} ${f1(D2[1])}Z" fill="${i % 2 ? '#e6dcc4' : '#ede5d2'}" stroke="#a89878" stroke-width="0.4"/>`; });
      out += `<g transform="${tr(0.8)}">${vs}<path d="M${f1(gc - 4.6)} ${f1(G.top - 7.4)}H${f1(gc + 4.6)}L${f1(gc + 3.2)} ${f1(G.top + 1)}H${f1(gc - 3.2)}Z" fill="#f2eadb" stroke="#a89878" stroke-width="0.5"/></g>`; }
    // ---------- plinth steps out: lit top bevel + front ----------
    { let pf = ''; for (let x = -6, k = 0; x < TW + 2; k++) { const bw = 40 + R() * 22; pf += `<rect x="${f1(x + 0.4)}" y="${f1(ypl + 0.4)}" width="${f1(bw - 0.8)}" height="${f1(yb - ypl - 0.8)}" rx="0.6" fill="${k % 2 ? '#cbbd9e' : '#c3b493'}"/><path d="M${f1(x + bw - 0.9)} ${f1(ypl + 1)}v${f1(yb - ypl - 2)}" stroke="#8e7e60" stroke-width="0.7"/>`; x += bw; }
      let ms = ''; rep(110, () => { const x = R() * TW; ms += `M${f1(x)} ${f1(yb - 0.2)}q${f1(1.1 * sx)} ${f1(-1.8 - R() * 2.6)} ${f1(2.2 * sx)} 0`; });
      const segs = G ? [[-2, G.x0], [G.x1, TW + 2]] : [[-2, TW + 2]];
      segs.forEach(([a0, a1]) => { out += poly([P(a0, ypl, 0), P(a1, ypl, 0), P(a1, ypl, OP), P(a0, ypl, OP)], '#efe6d2'); });
      out += `<g transform="${tr(OP)}"><g clip-path="url(#${I('m')})">${pf}<path d="${ms}" fill="#5a7a34" opacity="0.85"/></g></g>`; }
    // ---------- coping: whole top face across the wall thickness + overhang, joints, moulded front, drip shadow ----------
    { out += poly([P(-2, yc, -T), P(TW + 2, yc, -T), P(TW + 2, yc, OC), P(-2, yc, OC)], TP);
      let cj = '', cs = ''; for (let x = 16 + R() * 10; x < TW; x += 44 + R() * 14) { const a = W(x, yc); cj += `M${f1(a[0] - s * T)} ${f1(a[1])}L${f1(a[0] + s * OC)} ${f1(a[1])}`; rep(5, () => { cs += sdot(a[0] + s * (R() * (T + OC) - T), a[1] - 0.1 + R() * 0.2, 0.12); }); }
      out += `<path d="${cj}" stroke="#bfae8c" stroke-width="0.35"/><path d="${cs}" fill="#a39274" opacity="0.5"/>`
        + `<g transform="${tr(OC)}"><rect x="-2" y="${yc}" width="${TW + 4}" height="${yw - yc}" fill="url(#${I('c')})"/><rect x="-2" y="${yc}" width="${TW + 4}" height="1.2" fill="#fffbf2"/><path d="M-2 ${f1(yc + 4)}H${TW + 2}" stroke="#fffaf0" stroke-width="0.6"/><path d="M-2 ${f1(yc + 4.7)}H${TW + 2}" stroke="#bfae8c" stroke-width="0.5"/><path d="M-2 ${f1(yw - 0.3)}H${TW + 2}" stroke="#7e6e52" stroke-width="0.8"/></g>`
        + `<g transform="${M}"><rect x="-2" y="${yw}" width="${TW + 4}" height="2.6" fill="#3a2e1c" opacity="0.3" filter="url(#${I('b')})"/></g>`; }
    // ---------- pillars standing out of the wall, back to front ----------
    PIL.slice().sort((p, q) => p[0] - q[0]).forEach(([x, pw, big]) => { const dp = big ? 7 : 5, t = big ? -4 : yc, x0 = x - pw / 2, x1 = x + pw / 2, xc0 = x0 - 1.8, xc1 = x1 + 1.8, tc = t - 3.8, dc = dp + 1.2;
      // side face toward the viewer (+ courses), then the front face
      { const q = W(x1, 0); let cl = ''; for (let y = t + 6; y < yb - 1; y += 8.4) cl += `M${f1(q[0])} ${f1(q[1] + y)}h${f1(s * dp)}`;
        out += srect(x1, t, yb, 0, dp, SD) + srect(x1, t, yb, dp * 0.7, dp, '#c1b190') + `<path d="${cl}" stroke="#9a8a6a" stroke-width="0.45"/><path d="M${f1(q[0] + s * dp)} ${f1(q[1] + t)}V${f1(q[1] + yb)}" stroke="#fbf6ea" stroke-width="0.5"/>`; }
      out += `<g transform="${tr(dp)}"><rect x="${f1(x0)}" y="${f1(t)}" width="${pw}" height="${f1(yb - t)}" fill="${FR}"/><rect x="${f1(x0)}" y="${f1(t)}" width="${f1(pw * 0.14)}" height="${f1(yb - t)}" fill="#fbf6ea" opacity="0.8"/><rect x="${f1(x1 - pw * 0.12)}" y="${f1(t)}" width="${f1(pw * 0.12)}" height="${f1(yb - t)}" fill="#d9cbab" opacity="0.8"/>`
        + rep(Math.floor((yb - t - 4) / 8.4), k => { const yy = t + 6 + k * 8.4; return `<path d="M${f1(x0)} ${f1(yy)}H${f1(x1)}" stroke="#9a8a6a" stroke-width="0.7"/><path d="M${f1(x0)} ${f1(yy + 0.7)}H${f1(x1)}" stroke="#fffaf0" stroke-width="0.4"/>`; }).join('')
        + rep(8, () => `<path d="${dot(x0 + 1 + R() * (pw - 2), t + 2 + R() * (yb - t - 4), 0.2)}" fill="#a39274" opacity="0.5"/>`).join('') + `</g>`;
      // base block
      out += srect(x1 + 1.4, ypl, yb, 0, dc, '#bfb08e') + `<g transform="${tr(dc)}"><rect x="${f1(x0 - 1.4)}" y="${f1(ypl)}" width="${f1(pw + 2.8)}" height="${f1(yb - ypl)}" fill="#cfc1a2"/><path d="M${f1(x0 - 1.4)} ${f1(ypl + 0.5)}h${f1(pw + 2.8)}" stroke="#f2ead8" stroke-width="0.7"/></g>`
        + poly([P(x0 - 1.4, ypl, dp), P(x1 + 1.4, ypl, dp), P(x1 + 1.4, ypl, dc), P(x0 - 1.4, ypl, dc)], '#e6dcc6');
      // cornice cap: side, front, lit top
      out += srect(xc1, tc, t, 0, dc, '#c9b997') + `<g transform="${tr(dc)}"><rect x="${f1(xc0)}" y="${f1(tc)}" width="${f1(xc1 - xc0)}" height="3.8" fill="url(#${I('c')})"/><rect x="${f1(xc0)}" y="${f1(tc)}" width="${f1(xc1 - xc0)}" height="0.8" fill="#fffbf2"/><rect x="${f1(xc0 + 1)}" y="${f1(t)}" width="${f1(xc1 - xc0 - 2)}" height="1.2" fill="#d8caa8"/></g>`
        + poly([P(xc0, tc, -0.6), P(xc1, tc, -0.6), P(xc1, tc, dc), P(xc0, tc, dc)], TP, ` stroke="#d2c4a4" stroke-width="0.3"`);
      // finial: stone ball on the gate piers, a pyramid on the pilasters (front + viewer-side faces)
      const cq = W(x, tc), cx = cq[0] + s * dc / 2, cy = cq[1];
      if (big) out += `<ellipse cx="${f1(cx)}" cy="${f1(cy - 0.3)}" rx="2.4" ry="0.9" fill="#d8caa8"/><circle cx="${f1(cx)}" cy="${f1(cy - 3)}" r="2.6" fill="url(#${I('ball')})"/>`;
      else { const ap = [cx, cy - 3.6]; out += poly([P(xc0, tc, dc), P(xc1, tc, dc), f1(ap[0]) + ' ' + f1(ap[1])], '#ece2cc', ` stroke="#b8a888" stroke-width="0.3"`) + poly([P(xc1, tc, dc), P(xc1, tc, -0.6), f1(ap[0]) + ' ' + f1(ap[1])], '#cdbd9b'); } });
    // ---------- lanterns on brackets, standing out in front of the pillars (screen space) ----------
    { const LAN = gate ? PIL.filter(q => q[2]) : [PIL[1], PIL[2]];
      LAN.forEach(([x, pw, big], i) => { const dp = big ? 7 : 5, q = W(x, 31), X = q[0] + s * (dp + 3.2), Y = q[1], lw = 3.6, lh = 5.2;
        out += `<g transform="${M}"><ellipse cx="${x}" cy="33" rx="${f1(26)}" ry="20" fill="url(#${I('l')})" style="mix-blend-mode:screen">${an('opacity', '0.72;1;0.8;0.95;0.72', 2.8 + i * 0.4, -i, SPL(4))}</ellipse></g>`
          + `<path d="M${f1(q[0] + s * dp)} ${f1(Y - lh / 2 - 1.6)}h${f1(s * 2.4)}q${f1(s * 0.9)} 0 ${f1(s * 0.9)} 1" stroke="#1c1c20" stroke-width="0.55" fill="none"/>`
          + `<path d="M${f1(X - lw * 0.7)} ${f1(Y - lh / 2)}L${f1(X)} ${f1(Y - lh / 2 - 1.8)}L${f1(X + lw * 0.7)} ${f1(Y - lh / 2)}Z" fill="#1c1c20"/><circle cx="${f1(X)}" cy="${f1(Y - lh / 2 - 2.1)}" r="0.45" fill="#1c1c20"/>`
          + `<rect x="${f1(X - lw / 2)}" y="${f1(Y - lh / 2)}" width="${lw}" height="${lh}" fill="#ffd890"><animate attributeName="fill" values="#ffd890;#ffeab8;#ffcf7a;#ffd890" dur="2.2s" repeatCount="indefinite"/></rect><rect x="${f1(X - 0.35)}" y="${f1(Y - 0.6)}" width="0.7" height="2" rx="0.3" fill="#fff6d8"/>`
          + `<path d="M${f1(X - lw / 2)} ${f1(Y - lh / 2)}v${lh}M${f1(X + lw / 2)} ${f1(Y - lh / 2)}v${lh}M${f1(X)} ${f1(Y - lh / 2)}v${lh}" stroke="#1c1c20" stroke-width="0.4"/><path d="M${f1(X - lw * 0.62)} ${f1(Y + lh / 2)}h${f1(lw * 1.24)}l-0.5 0.9h${f1(-lw * 1.24 + 1)}Z" fill="#1c1c20"/>`; }); }
    // ---------- wall fountain (left side): spout boss on the wall, a shell basin standing out on a corbel, water trickling ----------
    if (!gate) { const fx = 160, sp = W(fx, 36), bq = W(fx, 60), BX = bq[0] + s * 3.6, BY = bq[1];
      out += `<g transform="${M}"><path d="${dot(fx, 36, 2.8)}" fill="#d8caa8" stroke="#a89878" stroke-width="0.5"/><path d="${dot(fx, 36, 1.2)}" fill="#c4b494"/></g>`
        + `<path d="M${f1(sp[0] + s * 0.3)} ${f1(sp[1] + 0.6)}h${f1(s * 1.6)}" stroke="#7a6a50" stroke-width="0.9" stroke-linecap="round"/>`
        + `<path d="M${f1(BX - 1.6)} ${f1(BY + 2.6)}h3.2l-0.6 3.4h-2Z" fill="#cdbf9e"/><path d="M${f1(BX - 5)} ${f1(BY)}A5 3.6 0 0 0 ${f1(BX + 5)} ${f1(BY)}Z" fill="#e2d6bc" stroke="#a89878" stroke-width="0.4"/>`
        + rep(5, k => `<path d="M${f1(BX)} ${f1(BY + 3.4)}L${f1(BX + (k - 2) * 2)} ${f1(BY + 0.2)}" stroke="#bcae8e" stroke-width="0.3"/>`).join('')
        + `<ellipse cx="${f1(BX)}" cy="${f1(BY)}" rx="5" ry="1.3" fill="url(#${I('a')})" stroke="#f6efe0" stroke-width="0.4"/>`
        + rep(3, k => `<path d="M${f1(sp[0] + s * 1.9 + (k - 1) * 0.25)} ${f1(sp[1] + 0.8)}Q${f1(BX)} ${f1(sp[1] + 4)} ${f1(BX + (k - 1) * 0.3)} ${f1(BY - 0.2)}" stroke="#cdeefa" stroke-width="${0.5 - k * 0.1}" fill="none" stroke-dasharray="1.4 1" opacity="0.9">${an('stroke-dashoffset', '0;-4.8', 0.5 + k * 0.12)}</path>`).join(''); }
    // ---------- ivy with volume: each leaf at its own depth out of the wall, unsheared (screen space), shadow on the stone, roses, swaying tendrils ----------
    { const MS = gate ? [[22, 46], [196, 40], [262, 44]] : [[24, 52], [112, 40], [192, 34], [252, 52]], LV = ['', '', '', ''], VN = []; let ro = '', ro2 = '', tdr = '', shd = '';
      MS.forEach(([x0, w]) => { shd += `<ellipse cx="${f1(x0 + w / 2 - 6)}" cy="${f1(yw + 14)}" rx="${f1(w * 0.55)}" ry="16" fill="#1e2a12" opacity="0.22" filter="url(#${I('b2')})"/>`;
        const n = Math.round(w * 5.2), Lf = []; rep(n, () => { const u = R(), x = x0 + u * w, depth = (1 - Math.abs(u - 0.5) * 2) * 34 * (0.35 + R() * 0.8), y = yc - 1 + R() * depth, z = R(); Lf.push([x, y, z]); });
        Lf.sort((a, b) => a[2] - b[2]).forEach(([x, y, z]) => { const q = W(x, y), X = q[0] + s * (OC + 0.4 + z * 4.2), Y = q[1] - z * 0.6, sz = 0.62 + z * 0.3 + R() * 0.18, a = 180 + (R() - 0.5) * 110, k = z < 0.3 ? 0 : z < 0.6 ? 1 : z < 0.85 ? 2 : 3;
          LV[k] += leafD(IVY, X, Y, sz, a, 1); if (k >= 2 && R() < 0.55) VN.push([X, Y, sz, a]); });
        rep(Math.round(w / 8), () => { const x = x0 + 4 + R() * (w - 8), y = yc + 4 + R() * 20, q = W(x, y), X = q[0] + s * (OC + 3.6 + R() * 1.2), Y = q[1]; ro += sdot(X, Y, 0.75); ro2 += sdot(X - 0.15, Y - 0.15, 0.32); }); });
      const vein = VN.map(([x, y, sz, a]) => { const c = Math.cos(a * PI / 180), sn = Math.sin(a * PI / 180); return `M${f1(x)} ${f1(y)}l${f1(sn * 2.2 * sz)} ${f1(-c * 2.2 * sz)}`; }).join('');
      out += `<g transform="${M}">${shd}</g><path d="${LV[0]}" fill="#1f4219"/><path d="${LV[1]}" fill="#2f5e26"/><path d="${LV[2]}" fill="#467a32"/><path d="${LV[3]}" fill="#679a48"/><path d="${vein}" stroke="#b4d88a" stroke-width="0.18" fill="none" opacity="0.85"/>`
        + `<path d="${ro}" fill="#ec8eaa"/><path d="${ro2}" fill="#b84a6a"/>`;
      MS.forEach(([x0, w], m) => rep(3, k => { const x = x0 + w * (0.18 + k * 0.32), q = W(x, yw + 6), X = q[0] + s * (OC + 1.6 + k * 0.8), Y = q[1], L = 12 + R() * 12; let lv = ''; rep(6, j => { lv += leafD(IVY, X + (j % 2 ? 0.9 : -0.9), Y + 1.6 + j * L / 6, 0.6, j % 2 ? 150 : 210, 1); });
        tdr += `<g transform="translate(${f1(X)} ${f1(Y)})"><g>${at('rotate', '0;4;0;-3.5;0', 5 + k + m * 0.7, -k * 1.3, SPL(4))}<g transform="translate(${f1(-X)} ${f1(-Y)})"><path d="M${f1(X)} ${f1(Y)}q1.2 ${f1(L / 2)} 0 ${f1(L)}" stroke="#4a4a26" stroke-width="0.3" fill="none"/><path d="${lv}" fill="#3a6c2e"/></g></g></g>`; }));
      out += tdr; }
    return '<defs>' + d + '</defs>' + out;
  }

  // YRD-081 LIVING VERTICAL RAINFOREST WALL WITH ACOUSTIC FORCE-FIELD PERIMETER (T5): a tall living wall planted like a rainforest: deep moss behind,
  // ferns, split monstera leaves, glossy philodendrons, red + orange bromeliads, white and pink orchids and trailing vines, held in a dark bronze frame
  // over a long honed-stone planter with warm uplights. Above it a faint iridescent hexagon force field shimmers. Live: misting nozzles breathe little
  // clouds, the fronds sway, the force field ripples, the uplights glow warm.
  function fRain(TW, room) { const R = rng('rain32' + TW), yb = room ? 55.6 : 49.5, yt = room ? 12 : 14, sx = room ? 1.9 : 1, PO = room ? [12, 92] : [4, 76], py = yb - 6;
    let d = '<filter id="rf32b" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.8"/></filter><filter id="rf32m" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="1.6"/></filter>'
      + '<linearGradient id="rf32f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9fe8ff" stop-opacity="0"/><stop offset="0.6" stop-color="#b8f0ff" stop-opacity="0.18"/><stop offset="1" stop-color="#d8c8ff" stop-opacity="0.32"/></linearGradient>'
      + '<radialGradient id="rf32u" cx="50%" cy="100%" r="80%"><stop offset="0" stop-color="#ffd890" stop-opacity="0.75"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient>'
      + '<linearGradient id="rf32s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#cfc6b6"/><stop offset="0.2" stop-color="#a89e8c"/><stop offset="1" stop-color="#6e665a"/></linearGradient>', s = '';
    if (!room) { const [bd, bs] = cBack(R, yb, 'lawn'); d += bd; s += bs; }
    else s += `<path d="M0 ${f1(yb - 0.6)}H${TW}V56H0Z" fill="#3e6a2a" opacity="0.5"/>`;
    // force field above the wall: a soft iridescent band of hexagons, rippling
    { let hx = ''; const hs = room ? 3.2 : 2.2, hh = hs * 0.87; for (let y = 1, r = 0; y < yt - 1; y += hh, r++) for (let x = (r % 2) * hs * 0.75 - hs; x < TW + hs; x += hs * 1.5) hx += `M${f1(x - hs / 2)} ${f1(y)}l${f1(hs / 4)} ${f1(-hh / 2)}h${f1(hs / 2)}l${f1(hs / 4)} ${f1(hh / 2)}l${f1(-hs / 4)} ${f1(hh / 2)}h${f1(-hs / 2)}Z`;
      d += `<clipPath id="rf32c"><rect x="-1" y="0" width="${TW + 2}" height="${yt}"/></clipPath><linearGradient id="rf32w" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.9"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>`;
      s += `<g clip-path="url(#rf32c)"><rect x="-1" y="0" width="${TW + 2}" height="${yt}" fill="url(#rf32f)">${an('opacity', '0.7;1;0.7', 5, 0, SPL(2))}</rect><path d="${hx}" fill="none" stroke="#c8f4ff" stroke-width="${room ? 0.22 : 0.14}" opacity="0.35">${an('opacity', '0.18;0.45;0.18', 4, 0, SPL(2))}</path>`
        + `<rect x="${-TW * 0.4}" y="0" width="${f1(TW * 0.4)}" height="${yt}" fill="url(#rf32w)" opacity="0.35">${at('translate', `0 0;${f1(TW * 1.4)} 0`, 7, 0)}</rect><path d="M-1 ${f1(yt - 0.4)}H${TW + 1}" stroke="#d8f6ff" stroke-width="0.4" opacity="0.6"/></g>`; }
    // moss + shade backing
    s += `<rect x="-1" y="${yt}" width="${TW + 2}" height="${f1(py - yt)}" fill="#1e3a1c"/><path d="${rep(room ? 260 : 160, () => dotPx(R() * TW, yt + R() * (py - yt), (0.6 + R() * 1.2) * sx, 0.6 + R())).join('')}" fill="#2e5a28" opacity="0.8"/>`;
    // foliage layers (back to front): oval leaves in many greens, monstera, philodendron hearts, ferns, bromeliads, orchids, trailing vines
    const LV = ['', '', '', '', ''], LC = ['#1f4a22', '#2e6a2c', '#3e7e34', '#58983e', '#7ab24a'];
    rep(room ? 520 : 300, () => { const x = R() * TW, y = yt + 1 + R() * (py - yt - 1), c = Math.min(4, Math.floor(R() * 5 * (0.6 + (y - yt) / (py - yt) * 0.5))); LV[c] += leafD(OVAL, x, y, 0.8 + R() * 0.9, (R() - 0.5) * 140 + 180 * (R() < 0.5), sx); });
    s += LV.map((p, i) => `<path d="${p}" fill="${LC[i]}"/>`).join('');
    const mon = (x, y, sz, a) => { const k = sz; let hl = `<g transform="translate(${f1(x)} ${f1(y)}) rotate(${f1(a)}) scale(${f1(k * sx)} ${f1(k)})"><path d="M0 0C-3 -0.5 -4 -3 -3.4 -5.4C-2.6 -7.6 -0.6 -8 0 -7.2C0.6 -8 2.6 -7.6 3.4 -5.4C4 -3 3 -0.5 0 0Z" fill="#2f7a34"/>`;
      hl += `<path d="M0 -0.5V-7M0 -2.4L-2.6 -3.4M0 -4L-2.8 -5.6M0 -2.4L2.6 -3.4M0 -4L2.8 -5.6" stroke="#1e3a1c" stroke-width="0.32" fill="none"/><path d="M0 -0.5V-7" stroke="#7ab85a" stroke-width="0.14"/><path d="M-1.6 -6.2C-1 -6.8 0 -7 0.6 -6.8" stroke="#ffffff" stroke-width="0.25" fill="none" opacity="0.35"/></g>`; return hl; };
    const swayG = (x, y, inner, i) => `<g transform="translate(${f1(x)} ${f1(y)})"><g>${at('rotate', '0;3;0;-2;0', 4.6 + (i % 5) * 0.6, -i * 0.9, SPL(4))}<g transform="translate(${f1(-x)} ${f1(-y)})">${inner}</g></g></g>`;
    rep(room ? 9 : 6, i => { const x = 4 + R() * (TW - 8), y = yt + 6 + R() * (py - yt - 8); s += swayG(x, y, mon(x, y, 1.1 + R() * 0.5, (R() - 0.5) * 70), i); });
    // ferns: arching fronds with leaflets
    rep(room ? 10 : 6, i => { const x = R() * TW, y = yt + 3 + R() * (py - yt - 4), L = 7 + R() * 5, dir = R() < 0.5 ? -1 : 1; let fr = `M${f1(x)} ${f1(y)}q${f1(dir * L * 0.5 * sx)} ${f1(-L * 0.4)} ${f1(dir * L * sx)} ${f1(L * 0.2)}`, lf = '';
      rep(10, j => { const t = (j + 1) / 11, fx = x + dir * L * sx * t, fy = y - L * 0.4 * 2 * t * (1 - t) + L * 0.2 * t * t, l = (1 - t * 0.7) * 1.4; lf += `M${f1(fx)} ${f1(fy)}l${f1(-0.3 * sx)} ${f1(-l)}M${f1(fx)} ${f1(fy)}l${f1(0.3 * sx)} ${f1(l)}`; });
      s += swayG(x, y, `<path d="${fr}" stroke="#4a8a34" stroke-width="0.25" fill="none"/><path d="${lf}" stroke="#6aa846" stroke-width="${f1(0.5 * (room ? 1.3 : 1))}" stroke-linecap="round"/>`, i + 3); });
    // bromeliads (rosette of strap leaves with a red / orange heart) + orchids (white / pink sprays)
    rep(room ? 7 : 4, i => { const x = R() * TW, y = yt + 8 + R() * (py - yt - 10), c = ['#d8322a', '#f07a1a', '#e8a020', '#c8204a'][i % 4]; let b = '';
      rep(7, j => { const a = -160 + j * 23; b += leafD(OVAL, x, y, 0.9, a + 90, sx * 0.6); }); s += `<path d="${b}" fill="#3e7a34"/>` + rep(4, j => `<path d="${leafD(OVAL, x, y, 0.65, -40 + j * 27, sx * 0.55)}" fill="${c}"/>`).join(''); });
    rep(room ? 8 : 5, i => { const x = R() * TW, y = yt + 4 + R() * (py - yt - 8), c = i % 2 ? '#fbf6fa' : '#f2a6c8'; let o = `<path d="M${f1(x)} ${f1(y)}q${f1(1.2 * sx)} -1.8 ${f1(3 * sx)} -2" stroke="#4a6a2a" stroke-width="0.2" fill="none"/>`;
      rep(4, j => { const fx = x + (0.6 + j * 0.7) * sx, fy = y - 0.6 - j * 0.45; o += rep(5, m => `<ellipse cx="${f1(fx + Math.cos(m * 1.26) * 0.42 * sx)}" cy="${f1(fy + Math.sin(m * 1.26) * 0.38)}" rx="${f1(0.36 * sx)}" ry="0.26" fill="${c}"/>`).join('') + `<circle cx="${f1(fx)}" cy="${f1(fy)}" r="0.2" fill="#e8b020"/>`; }); s += o; });
    // trailing vines spilling over the planter
    rep(room ? 12 : 8, i => { const x = R() * TW, L = 4 + R() * 6; let lv = ''; rep(5, j => { lv += leafD(OVAL, x + (j % 2 ? 0.6 : -0.6) * sx, py + 1 + j * L / 5, 0.55, j % 2 ? 140 : 220, sx); });
      s += swayG(x, py, `<path d="M${f1(x)} ${f1(py)}q${f1(0.8 * sx)} ${f1(L / 2)} 0 ${f1(L)}" stroke="#3e6a2a" stroke-width="0.2" fill="none"/><path d="${lv}" fill="#4e8a36"/>`, i + 7); });
    // dark bronze frame: top channel + posts with misting nozzles
    s += `<rect x="-1" y="${f1(yt - 1.2)}" width="${TW + 2}" height="1.6" fill="#3a2e22"/><rect x="-1" y="${f1(yt - 1.2)}" width="${TW + 2}" height="0.4" fill="#b08a5a"/>`;
    PO.forEach(x => { const w = room ? 6 : 2; s += `<rect x="${f1(x - w / 2)}" y="${f1(yt - 1.2)}" width="${f1(w)}" height="${f1(py - yt + 1.2)}" fill="#3a2e22"/><rect x="${f1(x - w / 2)}" y="${f1(yt - 1.2)}" width="${f1(w * 0.25)}" height="${f1(py - yt + 1.2)}" fill="#8a6a44" opacity="0.6"/>`; });
    // misting: little clouds breathing out of nozzles along the top channel
    s += `<g filter="url(#rf32m)">${rep(room ? 6 : 4, i => { const x = (i + 0.5) * TW / (room ? 6 : 4), T = 6 + R() * 3, b = -R() * T; return `<circle cx="${f1(x)}" cy="${f1(yt + 1)}" r="${f1(1.6 * sx)}" fill="#ffffff" opacity="0">${at('translate', `0 0;${f1((R() - 0.5) * 3)} 5`, T, b)}${an('opacity', '0;0.55;0', T, b)}${an('r', `${f1(1.2 * sx)};${f1(3.6 * sx)}`, T, b)}</circle>`; }).join('')}</g>`;
    // long honed-stone planter with a bronze lip and warm uplights washing the leaves
    s += `<rect x="-1" y="${f1(py)}" width="${TW + 2}" height="${f1(yb + 0.6 - py)}" fill="url(#rf32s)"/><rect x="-1" y="${f1(py)}" width="${TW + 2}" height="0.5" fill="#d8b47a"/><rect x="-1" y="${f1(yb - 0.6)}" width="${TW + 2}" height="0.8" fill="#3a3228" opacity="0.6"/>`
      + rep(room ? 4 : 3, i => { const x = (i + 0.5) * TW / (room ? 4 : 3); return `<ellipse cx="${f1(x)}" cy="${f1(py - 4)}" rx="${f1(5 * sx)}" ry="7" fill="url(#rf32u)" style="mix-blend-mode:screen">${an('opacity', '0.7;0.95;0.7', 5 + i * 0.7, -i, SPL(2))}</ellipse><rect x="${f1(x - 0.8 * sx)}" y="${f1(py - 0.4)}" width="${f1(1.6 * sx)}" height="0.5" fill="#ffe6b0"/>`; }).join('');
    return '<defs>' + d + '</defs>' + s;
  }
  const dotPx = (x, y, rx, ry) => `M${f1(x - rx)} ${f1(y)}a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(2 * rx)} 0a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(-2 * rx)} 0Z`;

  // ======================= OVERHEAD (3D pieces) =======================
  const H3 = RD.H3, H7 = RD.H7, XK = X.K;
  const LT3 = [-0.42, 0.8, 0.43], nrm = (a, b, c) => { const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]]; let n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]; const l = Math.hypot(...n) || 1; n = n.map(q => q / l); if (n[1] < 0) n = n.map(q => -q); return n; };
  const lit = n => 0.5 + 0.5 * (n[0] * LT3[0] + n[1] * LT3[1] + n[2] * LT3[2]);

  // YRD-009 TORN BLUE TARP TIED TO BROOMSTICKS (T1, back to the catalog name; plus8 had made it a clean shade sail): a sun-faded blue poly tarp with
  // grommets, tied with frayed yellow rope and a bungee to four mismatched broomsticks (one still has its broom head, two lean, one sits in a bucket of
  // rocks, one in a cinder block). It sags into a rain puddle, has duct-tape patches, a couple of holes and one corner torn off with a flap hanging.
  // Live: the flap flutters, the tarp breathes, a drip falls from the flap. Seat under it kept (sail8: 1 seat at -6, 0).
  N.tarp32 = S => { const STK = [[-66, -46, 120, 0, '#5a8a4a'], [68, -50, 112, 0, '#b0503a'], [62, 34, 104, -6, '#c8a878'], [-60, 34, 101, 7, '#4a6aa8']];
    const top = i => { const [x, z, h, l] = STK[i]; return [x + Math.sin(l * PI / 180) * h, h, z]; };
    // Nov 7 (user: canopies too small, creatures looked like they sat on top of them): broomsticks ~2x a sitting creature, wider footprint; the seat sits
    // back a little and D.inside splits the piece so the tarp, near sticks, block and flap draw over the sitter (fxF) and the far sticks + bucket behind him
    const D = { w: 160, d: 112, seats: [{ x: 6, z: -6, h: 0 }], inside: [6, 0, -6], fxF: 1 };
    D.build = P => [XK.cyl(68, 0, -50, 6.4, 9, '#e8e4da', H3.pt({ n: 16, rg: [[0, 0, 0.88], [9, 0, 1]] })), XK.cyl(68, 8.4, -50, 5.8, 0.8, '#8a8478', H3.pt({ n: 14 })),
      XK.box(62, 0, 34, 15, 8, 8, '#9a9890', H3.pt({ r: 0.4 })), XK.box(62, 7.9, 34, 4.6, 0.3, 4.6, '#3a3a36', H3.pt({})),
      XK.cyl(-66, 0, -46, 5, 1.6, '#6a5236', H3.pt({ n: 10 })), XK.cyl(-60, 0, 34, 4.6, 1.4, '#6a5236', H3.pt({ n: 10 }))];
    D.fx = c => { const p = c.p, k = c.k, P = q => H3.P2(p(...q)); let f = '', un = '', bk = '';
      const C = [0, 1, 2, 3].map(i => { const t = top(i); return [t[0] * 0.95, t[1] - 3.5, t[2] * 0.93]; }); // corners: 0 back-left, 1 back-right, 2 front-right, 3 front-left
      const F = (u, v) => { const a = C[0].map((q, j) => q + (C[1][j] - q) * u), b = C[3].map((q, j) => q + (C[2][j] - q) * u), o = a.map((q, j) => q + (b[j] - q) * v);
        o[1] -= 17 * Math.sin(PI * u) * Math.sin(PI * v) + 6 * Math.exp(-((u - 0.45) ** 2 + (v - 0.55) ** 2) / 0.03) + 1.1 * Math.sin(u * 19 + v * 5) * Math.sin(v * 14 - u * 3) * Math.sin(PI * u) * Math.sin(PI * v) + 0.9 * Math.sin(u * 7) * (1 - v) * v * 4; return o; };
      const torn = (u, v) => u * 1.0 + (1 - v) * 1.2 < 0.34 + 0.05 * Math.sin(u * 40 + v * 30);
      const NU = 20, NV = 14; let tq = '', clip = ''; const Rr = rng('tarp32');
      for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const u0 = i / NU, u1 = (i + 1) / NU, v0 = j / NV, v1 = (j + 1) / NV; if (torn((u0 + u1) / 2, (v0 + v1) / 2)) continue;
        const a = F(u0, v0), b = F(u1, v0), cc = F(u1, v1), dd = F(u0, v1), L = lit(nrm(a, b, dd)), col = XK.shade('#2a6cc4', 0.42 + 0.95 * L), d = `M${P(a)}L${P(b)}L${P(cc)}L${P(dd)}Z`;
        tq += `<path d="${d}" fill="${col}" stroke="${col}" stroke-width="${f1(0.3 * k)}"/>`; clip += d; }
      // shadow of the tarp on the ground
      const out = []; for (let i = 0; i <= 10; i++) out.push(F(i / 10, 0)); for (let j = 0; j <= 10; j++) out.push(F(1, j / 10)); for (let i = 10; i >= 0; i--) out.push(F(i / 10, 1)); for (let j = 10; j >= 0; j--) out.push(F(0, j / 10));
      un += `<path d="M${out.map(q => P([q[0] + q[1] * 0.16, 0, q[2] - q[1] * 0.14])).join('L')}Z" fill="#1a2a40" opacity="0.26" filter="url(#f7s)"/>`;
      // sticks: behind the tarp (far ones) first, near ones after
      const cen = p(...F(0.5, 0.5)); const stick = i => { const [x, z, h, l, col] = STK[i], b = [x, 0, z], t = top(i); let s = H7.tube([p(...b), p(...t)], 2.1, k, col, '#ffffff', '#2a241c');
          rep(3, m => { const q0 = 0.2 + m * 0.22 + Rr() * 0.05, q1 = q0 + 0.03; s += `<path d="M${P(b.map((v, j) => v + (t[j] - v) * q0))}L${P(b.map((v, j) => v + (t[j] - v) * q1))}" stroke="#c8a878" stroke-width="${f1(2.1 * k)}"/>`; });
          if (i === 1) { const hq = p(t[0], t[1] + 1, t[2]); s += `<g transform="translate(${H3.P2(hq)}) scale(${n4(k)})"><rect x="-7" y="-2.6" width="14" height="3.4" rx="0.8" fill="#d84a3a"/><rect x="-7" y="-2.6" width="14" height="0.9" fill="#f07a62"/>${rep(22, m => `<path d="M${f1(-6.6 + m * 0.62)} -2.4l${f1((m - 11) * 0.06)} -5.4" stroke="${m % 3 ? '#e6c450' : '#c8a438'}" stroke-width="0.5"/>`).join('')}</g>`; }
          else { const hq = p(...t); s += `<ellipse cx="${f1(hq[0])}" cy="${f1(hq[1])}" rx="${f1(1.4 * k)}" ry="${f1(0.8 * k)}" fill="#e8e4da" stroke="#8a8478" stroke-width="${f1(0.2 * k)}"/>`; }
          return s; };
      const order = [0, 1, 2, 3].map(i => [i, p(STK[i][0], 0, STK[i][1])[1]]).sort((a, b) => a[1] - b[1]);
      order.forEach(([i, sy]) => { if (sy < cen[1] + 4 * k) bk += stick(i); });
      // tarp body + faded patches, folds, puddle, duct tape, holes, grommets
      const UV = (u, v) => P(F(u, v)), qd = (u0, v0, u1, v1) => `M${UV(u0, v0)}L${UV(u1, v0)}L${UV(u1, v1)}L${UV(u0, v1)}Z`;
      let tb = `<clipPath id="tp32"><path d="${clip}"/></clipPath>` + tq + `<g clip-path="url(#tp32)">`;
      rep(6, () => { const q = p(...F(0.15 + Rr() * 0.7, 0.1 + Rr() * 0.8)); tb += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((6 + Rr() * 8) * k)}" ry="${f1((3 + Rr() * 4) * k)}" fill="#a8c4e2" opacity="0.28" filter="url(#f7s)"/>`; });
      [[0.33, 0], [0.66, 0]].forEach(([u]) => { let d1 = '', d2 = ''; rep(11, m => { const v = m / 10; d1 += (m ? 'L' : 'M') + UV(u, v); d2 += (m ? 'L' : 'M') + UV(u + 0.012, v); }); tb += `<path d="${d1}" stroke="#18447e" stroke-width="${f1(0.5 * k)}" fill="none" opacity="0.5"/><path d="${d2}" stroke="#8ab4e4" stroke-width="${f1(0.35 * k)}" fill="none" opacity="0.5"/>`; });
      { let d1 = ''; rep(15, m => { d1 += (m ? 'L' : 'M') + UV(m / 14, 0.5); }); tb += `<path d="${d1}" stroke="#18447e" stroke-width="${f1(0.45 * k)}" fill="none" opacity="0.4"/>`; }
      { let pud = ''; rep(16, m => { const a = m / 16 * 2 * PI; pud += (m ? 'L' : 'M') + UV(0.45 + Math.cos(a) * 0.13, 0.55 + Math.sin(a) * 0.15); });
        tb += `<path d="${pud}Z" fill="#163a68" opacity="0.75"/><path d="${pud}Z" fill="url(#tp32w)"/><path d="M${UV(0.36, 0.48)}Q${UV(0.45, 0.43)} ${UV(0.53, 0.47)}" stroke="#ffffff" stroke-width="${f1(0.5 * k)}" fill="none" opacity="0.6"/>`;
        const lq = p(...F(0.5, 0.58)); tb += `<g transform="translate(${H3.P2(lq)}) scale(${n4(k)})"><g>${H7.atV('translate', ['0 0', '1.2 0.4', '0 0'], 8)}<path d="M-1.6 0q1.6 -1.2 3.2 0q-1.6 1.2 -3.2 0Z" fill="#c88a2e"/></g></g>`; }
      [[0.7, 0.2, 0.82, 0.3], [0.2, 0.3, 0.3, 0.38]].forEach(([u0, v0, u1, v1]) => { tb += `<path d="${qd(u0, v0, u1, v1)}" fill="#a8aaa6"/><path d="${qd(u0, v0, u1, v1)}" fill="none" stroke="#7a7c78" stroke-width="${f1(0.25 * k)}"/><path d="M${UV(u0, v0)}L${UV(u1, v1)}M${UV(u1, v0)}L${UV(u0, v1)}" stroke="#c8cac6" stroke-width="${f1(0.6 * k)}" opacity="0.6"/>`; });
      [[0.62, 0.72, 1.6], [0.84, 0.48, 1], [0.3, 0.15, 1.2]].forEach(([u, v, r]) => { const q = p(...F(u, v)); tb += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(r * k)}" ry="${f1(r * 0.6 * k)}" fill="#3a3428"/><ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(r * k)}" ry="${f1(r * 0.6 * k)}" fill="none" stroke="#7aa6d6" stroke-width="${f1(0.3 * k)}" stroke-dasharray="${f1(0.5 * k)} ${f1(0.4 * k)}"/>`; });
      tb += '</g>';
      // ragged torn edge + grommets along the intact edges
      { let te = ''; rep(9, m => { const t = m / 8; let u = 0.34 * t, v = 1 - (0.34 - u) / 1.2; u += (Rr() - 0.5) * 0.02; v += (Rr() - 0.5) * 0.02; te += (m ? 'L' : 'M') + UV(Math.max(0.01, u), Math.min(0.99, v)); }); tb += `<path d="${te}" stroke="#d8e4f0" stroke-width="${f1(0.45 * k)}" fill="none" stroke-linejoin="round"/>`; }
      { let gm = ''; const ring = (u, v) => { if (torn(u, v)) return; const q = p(...F(u, v)); gm += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.8 * k)}" fill="none" stroke="#d8dcdc" stroke-width="${f1(0.4 * k)}"/>`; };
        rep(8, m => { ring(0.04 + m * 0.13, 0.03); ring(0.04 + m * 0.13, 0.97); }); rep(6, m => { ring(0.03, 0.08 + m * 0.16); ring(0.97, 0.08 + m * 0.16); }); tb += gm; }
      // ropes from the corners to the sticks (frayed yellow poly rope; a black bungee on the front right); the torn corner is tied from further in
      const tieP = [F(0.02, 0.03), F(0.98, 0.03), F(0.98, 0.97), F(0.24, 0.86)];
      [0, 1, 2, 3].forEach(i => { const a = p(...tieP[i]), t = top(i), b = p(t[0], t[1] - 1.5, t[2]); const m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2 + 1.2 * k];
        tb += i === 2 ? `<path d="M${H3.P2(a)}Q${H3.P2(m)} ${H3.P2(b)}" stroke="#1e1e22" stroke-width="${f1(0.7 * k)}" fill="none"/><circle cx="${f1(a[0])}" cy="${f1(a[1])}" r="${f1(0.7 * k)}" fill="none" stroke="#c8202a" stroke-width="${f1(0.4 * k)}"/>`
          : `<path d="M${H3.P2(a)}Q${H3.P2(m)} ${H3.P2(b)}" stroke="#d8b030" stroke-width="${f1(0.6 * k)}" fill="none"/><circle cx="${f1(b[0])}" cy="${f1(b[1])}" r="${f1(1 * k)}" fill="#c8a028"/><path d="M${H3.P2(b)}l${f1(0.6 * k)} ${f1(2.4 * k)}M${H3.P2(b)}l${f1(-0.4 * k)} ${f1(2.2 * k)}" stroke="#e8c84a" stroke-width="${f1(0.3 * k)}"/>`; });
      // the torn flap hanging from the tear, fluttering, with a drip
      { const h0 = F(0.12, 0.72), h1 = F(0.27, 0.9), tip = [(h0[0] + h1[0]) / 2 - 3, Math.min(h0[1], h1[1]) - 15, (h0[2] + h1[2]) / 2 + 3], q0 = p(...h0), q1 = p(...h1), qt = p(...tip), hm = [(q0[0] + q1[0]) / 2, (q0[1] + q1[1]) / 2];
        const fl = `M${H3.P2(q0)}Q${f1(qt[0] - 3 * k)} ${f1((q0[1] + qt[1]) / 2)} ${H3.P2(qt)}Q${f1(qt[0] + 2 * k)} ${f1((q1[1] + qt[1]) / 2)} ${H3.P2(q1)}Z`;
        f += `<g transform="translate(${f1(hm[0])} ${f1(hm[1])})"><g>${H7.atV('skewX', ['-6', '8', '-3', '6', '-6'], 2.4)}<g transform="translate(${f1(-hm[0])} ${f1(-hm[1])})"><path d="${fl}" fill="#2a64b4"/><path d="${fl}" fill="#9ac0ea" opacity="0.25"/><path d="M${H3.P2(q0)}Q${f1(qt[0] - 1.5 * k)} ${f1((q0[1] + qt[1]) / 2)} ${H3.P2(qt)}" stroke="#18447e" stroke-width="${f1(0.4 * k)}" fill="none"/></g></g></g>`
          + `<circle cx="${f1(qt[0])}" cy="${f1(qt[1])}" r="${f1(0.5 * k)}" fill="#bfe0ff" opacity="0">${H3.an('cy', `${f1(qt[1])};${f1(qt[1] + 14 * k)}`, 1.8)}${H3.an('opacity', '0.9;0.9;0', 1.8)}</circle>`; }
      f += `<g>${H7.atV('translate', ['0 0', `0 ${f1(-0.6 * k)}`, '0 0'], 3.8)}${tb}</g>`;
      order.forEach(([i, sy]) => { if (sy >= cen[1] + 4 * k) f += stick(i); });
      const bbp = [p(-80, 0, -60), p(92, 0, 44), p(-80, 0, 44), p(92, 0, -60), p(-70, 126, -48), p(72, 118, -52), p(62, 110, 36), p(-54, 106, 36)];
      return { defs: '<linearGradient id="tp32w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e8f2fa" stop-opacity="0.6"/><stop offset="1" stop-color="#e8f2fa" stop-opacity="0"/></linearGradient>' + (H7.FDEF || ''), under: un, back: bk, front: f, bb: H3.bbOf(bbp, 4) }; };
    return D; };

  // YRD-029 CRANK-OPEN STRIPED PATIO UMBRELLA (T2, rebuild of plus8 umbrella8, same size): blue + cream canvas panels that sag softly between the ribs,
  // stitched seams, a cream pinstripe band near the rim, a woven canvas texture and sun-faded panels on the lit side, a raised wind vent with a finial,
  // a scalloped valance, white steel ribs and stretchers, a two-piece pole with a crank box + handle and a tilt button, a moulded resin base, a velcro tie
  // strap hanging from one rib, and a soft shade on the ground. Live: the canopy breathes, the valance flutters, the strap swings.
  N.umb32 = S => { const R = 60, TOP = 114, RIM = 99, RU = RIM - 20, C1 = '#2f86c8', C2 = '#f6efe0', NP = 8; // Nov 7: taller pole + wider canopy so a creature fits under it
    const D = { w: 124, d: 124, round: 1 };
    D.build = P => [XK.cyl(0, 0, 0, 14, 2.2, '#34363b', H3.mt({ n: 26, rg: [[0, 0, 1], [2.2, 0, 0.97]] })), XK.cyl(0, 2.2, 0, 12, 2.6, '#3e4046', H3.mt({ n: 24, rg: [[0, 0, 1], [2.6, 0, 0.72]] })), XK.cyl(0, 4.6, 0, 3.2, 3.4, '#2c2e33', H3.mt({ n: 12 })),
      XK.cyl(0, 8, 0, 2, 54, '#ece8de', H3.mt({ n: 12, shine: 1 })), XK.cyl(0, 60, 0, 2.6, 2.6, '#d4d0c6', H3.mt({ n: 12 })), XK.cyl(0, 62.6, 0, 1.8, TOP - 62.6, '#ece8de', H3.mt({ n: 12, shine: 1 })),
      XK.cyl(0, 40, 0, 3.2, 8, '#d6dade', H3.mt({ n: 12, shine: 1 })), XK.cyl(0, RU - 1, 0, 2.8, 3, '#e4e0d6', H3.mt({ n: 12 }))];
    D.fx = c => { const p = c.p, k = c.k, P = q => H3.P2(p(...q)); let f = '', bk = '', un = '';
      const rib = i => { const a = i / NP * 2 * PI + PI / NP; return [R * Math.cos(a), RIM, R * Math.sin(a)]; }, T0 = [0, TOP, 0];
      const Q = (i, r, t) => { const a = rib(i), b = rib(i + 1), e = a.map((v, j) => v + (b[j] - v) * t), o = T0.map((v, j) => v + (e[j] - v) * r), cv = Math.sin(PI * t);
        o[1] += -1.6 * cv * Math.pow(r, 0.7) + 2.2 * r * (1 - r) * 1.4; if (r > 0.9) o[1] += cv * (r - 0.9) * 18; return o; };
      // ground shade
      un += `<ellipse cx="${f1(p(6, 0, 4)[0])}" cy="${f1(p(6, 0, 4)[1])}" rx="${f1(64 * k)}" ry="${f1(34 * k)}" fill="#14304a" opacity="0.22" filter="url(#f7s)"/>`;
      // under-side: ribs + stretchers to the runner
      rep(NP, i => { const a = rib(i); bk += H7.tube([p(0, TOP - 1, 0), p(a[0] * 0.98, RIM - 0.2, a[2] * 0.98)], 0.6, k, '#f2f0ea', '#ffffff', '#6a6a60') + H7.tube([p(0, RU, 0), p(a[0] * 0.48, RIM - 4.4, a[2] * 0.48)], 0.5, k, '#f2f0ea', '#ffffff', '#6a6a60'); });
      // crank box handle + tilt button
      { const cq = p(3.2, 44, 0); bk += `<path d="M${H3.P2(cq)}l${f1(4 * k)} ${f1(0.8 * k)}l${f1(0.4 * k)} ${f1(3 * k)}" stroke="#c8ccd0" stroke-width="${f1(0.8 * k)}" fill="none" stroke-linecap="round"/><rect x="${f1(cq[0] + 3.4 * k)}" y="${f1(cq[1] + 3.4 * k)}" width="${f1(1.6 * k)}" height="${f1(3 * k)}" rx="${f1(0.6 * k)}" fill="#2c2e33"/>`;
        const tq = p(0, RU + 3, 2.6); bk += `<circle cx="${f1(tq[0])}" cy="${f1(tq[1])}" r="${f1(0.7 * k)}" fill="#c8202a"/>`; }
      // canopy panels (back to front), each a 4 x 4 patch shaded by its own slope
      const order = rep(NP, i => { const m = Q(i, 0.7, 0.5); return [i, p(...m)[1]]; }).sort((a, b) => a[1] - b[1]);
      let cn = ''; order.forEach(([i]) => { const col = i % 2 ? C1 : C2; let pan = '', out = '';
        for (let r = 0; r < 4; r++) for (let t = 0; t < 4; t++) { const a = Q(i, r / 4, t / 4), b = Q(i, r / 4, (t + 1) / 4), cc = Q(i, (r + 1) / 4, (t + 1) / 4), dd = Q(i, (r + 1) / 4, t / 4), L = lit(nrm(a, b, dd));
          const fade = col === C1 ? 0.06 * L : 0, cq = XK.shade(col, 0.6 + 0.7 * L + fade); pan += `<path d="M${P(a)}L${P(b)}L${P(cc)}L${P(dd)}Z" fill="${cq}" stroke="${cq}" stroke-width="${f1(0.25 * k)}"/>`; }
        rep(9, m => { out += (m ? 'L' : 'M') + P(Q(i, 1, m / 8)); }); const full = `M${P(T0)}L${P(Q(i, 1, 0))}${out.replace(/^M/, 'L')}Z`;
        // pinstripe band near the rim
        let band = ''; rep(9, m => { band += (m ? 'L' : 'M') + P(Q(i, 0.84, m / 8)); }); rep(9, m => { band += 'L' + P(Q(i, 0.89, (8 - m) / 8)); });
        cn += pan + `<path d="${full}" fill="url(#q8wv)" opacity="0.14"/><path d="${band}Z" fill="${i % 2 ? C2 : C1}" opacity="0.9"/>`
          + (i === 3 ? `<ellipse cx="${f1(p(...Q(i, 0.55, 0.5))[0])}" cy="${f1(p(...Q(i, 0.55, 0.5))[1])}" rx="${f1(4 * k)}" ry="${f1(2 * k)}" fill="none" stroke="#b8a888" stroke-width="${f1(0.35 * k)}" opacity="0.5"/>` : '')
          + `<path d="M${P(T0)}L${P(Q(i, 1, 0))}" stroke="#ffffff" stroke-width="${f1(0.5 * k)}" opacity="0.5"/><path d="M${P(T0)}L${P(Q(i, 1, 0))}" stroke="#4a4a44" stroke-width="${f1(0.2 * k)}" opacity="0.45" stroke-dasharray="${f1(0.6 * k)} ${f1(0.4 * k)}"/>`; });
      // valance: scallops under the rim on the panels that face the viewer, fluttering
      let vl = ''; rep(NP, i => { const m = Q(i, 1, 0.5), th = Math.atan2(m[0], m[2]); if (H7.facing(th) < -0.15) return; const col = i % 2 ? C1 : C2; let d = 'M' + P(Q(i, 1, 0));
        rep(4, s0 => { const t0 = s0 / 4, t1 = (s0 + 1) / 4, a = Q(i, 1, t1), mm = Q(i, 1, (t0 + t1) / 2); d += `Q${P([mm[0] * 1.01, mm[1] - 9, mm[2] * 1.01])} ${P(a)}`; });
        let top = ''; rep(9, m => { top += 'L' + P(Q(i, 1, (8 - m) / 8)); }); const mq = p(...m);
        vl += `<g transform="translate(${f1(mq[0])} ${f1(mq[1])})"><g>${H7.atV('skewX', ['0', `${(i % 2 ? 4 : -4)}`, '0', `${(i % 2 ? -3 : 3)}`, '0'], 2.6 + i * 0.2)}<g transform="translate(${f1(-mq[0])} ${f1(-mq[1])})"><path d="${d}${top}Z" fill="${XK.shade(col, 0.88)}" stroke="#8a8478" stroke-width="${f1(0.25 * k)}"/><path d="${d}" stroke="${i % 2 ? C2 : C1}" stroke-width="${f1(0.6 * k)}" fill="none" opacity="0.9"/></g></g></g>`; });
      // wind vent cap + finial
      const VT = p(0, TOP + 3, 0), vr = 10; let vc = ''; rep(NP + 1, m => { const a = m / NP * 2 * PI + PI / NP; vc += (m ? 'L' : 'M') + P([vr * Math.cos(a), TOP + 1.2, vr * Math.sin(a)]); });
      const vent = `<path d="${vc}" fill="#1e2a36" opacity="0.35" transform="translate(0 ${f1(1.2 * k)})"/><path d="M${P([-vr, TOP + 1.2, 0])}L${H3.P2(VT)}L${P([vr, TOP + 1.2, 0])}" fill="none"/>`
        + rep(NP, i => { const a = i / NP * 2 * PI + PI / NP, b = (i + 1) / NP * 2 * PI + PI / NP, A = [vr * Math.cos(a), TOP + 1.2, vr * Math.sin(a)], B = [vr * Math.cos(b), TOP + 1.2, vr * Math.sin(b)], L = lit(nrm([0, TOP + 2.6, 0], A, B)); return `<path d="M${H3.P2(VT)}L${P(A)}L${P(B)}Z" fill="${XK.shade(i % 2 ? C1 : C2, 0.7 + 0.5 * L)}" stroke="#8a8478" stroke-width="${f1(0.2 * k)}"/>`; }).join('')
        + `<circle cx="${f1(VT[0])}" cy="${f1(VT[1] - 1.6 * k)}" r="${f1(1.7 * k)}" fill="#ece8de" stroke="#8a8478" stroke-width="${f1(0.25 * k)}"/><circle cx="${f1(VT[0] - 0.5 * k)}" cy="${f1(VT[1] - 2.1 * k)}" r="${f1(0.5 * k)}" fill="#ffffff"/>`;
      // velcro tie strap hanging off rib 5, swinging
      const si = rep(NP, i => [i, p(...Q(i, 1, 0))[1]]).sort((a, b) => b[1] - a[1])[1][0], sq = p(...Q(si, 1, 0)); const strap = `<g transform="translate(${H3.P2(sq)})"><g>${H7.atV('rotate', ['-8', '10', '-8'], 2.8)}<rect x="${f1(-0.9 * k)}" y="0" width="${f1(1.8 * k)}" height="${f1(9 * k)}" rx="${f1(0.4 * k)}" fill="${C1}"/><rect x="${f1(-0.9 * k)}" y="${f1(6.6 * k)}" width="${f1(1.8 * k)}" height="${f1(2.4 * k)}" fill="#e8e4da"/></g></g>`;
      f += `<g>${H7.atV('translate', ['0 0', `0 ${f1(-0.6 * k)}`, '0 0'], 3.4)}${cn}${vl}${vent}${strap}</g>`;
      return { defs: (RD.H8 ? RD.H8.LEAF : '') + (H7.FDEF || ''), under: un, back: '', front: bk + f, bb: H3.bbOf([p(-R - 2, RIM - 9, -R - 2), p(R + 2, RIM - 9, R + 2), p(-R - 2, RIM - 9, R + 2), p(R + 2, RIM - 9, -R - 2), p(0, TOP + 6, 0), p(-14, 0, -14), p(14, 0, 14), p(-64, 0, 38), p(70, 0, 38)], 3) }; };
    return D; };

  // YRD-049 WISTERIA-DRAPED CEDAR PERGOLA (T3): plus8 wisteria8 layout (cedar posts, beams, notched rafters, bench, stone table; own taller frame since Nov 7)
  // with a new canopy: compound wisteria leaves in fresh greens over the rafters, ~40 long racemes graded from pale lilac at the top to deep violet at the
  // tip, vines spiralling up the front posts, dappled shade on the paving; adds lavender + cream bench pillows and a teapot with two cups on the table.
  // Live: racemes sway out of step, petals drift down, the shade dapples shift.
  // Nov 7 (user: canopies too small + creatures looked like they sat on top of them): own frame, not plus8's: cedar posts ~2x a sitting creature,
  // wider + deeper, a real slatted cedar bench (cushion, back pillows) wide enough for two, a stone slab table in front. D.inside splits the piece:
  // the front posts + bases, table, beams, rafters, leaf canopy, racemes and the front-post vines draw over a seated creature (fxF); the bench,
  // back posts and the back-post vine stay behind. Front racemes are short so they end just above a sitting head.
  N.wist32 = S => { const W = 68, DZ = 42, H = 124, CED = '#a8683a', CED2 = '#c08050', { wd, cer, pt } = H3, fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {});
    const D = { w: 160, d: 108, seats: [{ x: -22, z: -6, h: 16 }, { x: 22, z: -6, h: 16 }], inside: [0, 16, 0], fxF: 1 };
    D.build = P => { const o = [XK.box(0, 0, 0, 2 * W + 12, 1.2, 2 * DZ + 12, '#d8ccb0', pt({ r: 1 }))];
      [[-W, -DZ], [W, -DZ], [-W, DZ], [W, DZ]].forEach(([x, z]) => o.push(XK.box(x, 1.2, z, 7, H, 7, CED, wd({ r: 0.8 })), XK.box(x, 1.2, z, 10, 7, 10, CED2, wd({ r: 0.8 }))));
      o.push(XK.box(0, H, -DZ, 2 * W + 22, 8, 4.5, CED2, wd({ r: 0.6 })), XK.box(0, H, DZ, 2 * W + 22, 8, 4.5, CED2, wd({ r: 0.6 })));
      rep(9, i => o.push(XK.box(-W + i * (2 * W / 8), H + 8, 0, 3.4, 6, 2 * DZ + 22, CED, wd({ r: 0.5 }))));
      // slatted cedar bench: legs, seat, backrest, cushion, pillows
      [[-42, -2], [42, -2], [-42, -18], [42, -18]].forEach(([x, z]) => o.push(XK.box(x, 1.2, z, 4, 8.6, 4, CED, wd({ r: 0.4 }))));
      o.push(XK.box(0, 9.8, -10, 92, 2.6, 22, CED2, wd({ r: 0.6 })), XK.box(0, 12.4, -21, 92, 18, 3, CED2, wd({ r: 0.6 })), XK.box(-46, 12.4, -10, 3, 7, 22, CED, wd({ r: 0.5 })), XK.box(46, 12.4, -10, 3, 7, 22, CED, wd({ r: 0.5 })),
        XK.cush(0, 12.4, -9, 86, 3.6, 19, '#e8e2d4', fb()), XK.cush(-28, 16, -17, 14, 11, 4, '#b8a2dc', fb()), XK.cush(28, 16, -17, 14, 11, 4, '#f2ece0', fb()), XK.cush(-12, 16, -18, 12, 9, 3.6, '#d8c8ec', fb()), XK.cush(10, 16, -18, 12, 9, 3.6, '#ece4f4', fb()));
      // stone slab table with a teapot and two cups
      o.push(XK.box(0, 1.2, 26, 24, 8, 9, '#8a8478', pt({ r: 1 })), XK.box(0, 9.2, 26, 38, 2.4, 18, '#a8a296', pt({ r: 0.8 })),
        XK.ball(0, 14.8, 26, 3.4, '#f4f1ea', cer({ k: 5, n: 14 })), XK.ball(0, 18, 26, 1.4, '#e8e2d6', cer({ k: 4, n: 10 })), XK.cyl(-9, 11.6, 24, 1.6, 2.4, '#f4f1ea', cer({ n: 10 })), XK.cyl(9, 11.6, 29, 1.6, 2.4, '#f4f1ea', cer({ n: 10 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k, R = rng('wis32'), P = q => H3.P2(p(...q)), nr = (x, z) => p(x, 0, z)[1] > p(0, 0, 0)[1]; let f = '', ov = '', un = ''; // ov: behind the sitter but over the build
      // dappled shade under the canopy
      un += `<g filter="url(#f7s)">${rep(12, i => { const q = p((R() - 0.5) * 2 * W, 1.3, (R() - 0.5) * 2 * DZ); return `<g>${H7.atV('translate', ['0 0', `${f1(2 * k)} ${f1(1 * k)}`, '0 0'], 9 + i)}<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((9 + R() * 9) * k)}" ry="${f1((4.5 + R() * 3) * k)}" fill="#2a3a1a" opacity="0.18"/></g>`; }).join('')}</g>`;
      // teapot spout + handle
      { const sp = p(3.2, 15, 26), hq = p(-3.4, 15.8, 26), tp = `<path d="M${H3.P2(sp)}l${f1(2.6 * k)} ${f1(-2 * k)}" stroke="#f4f1ea" stroke-width="${f1(1 * k)}" stroke-linecap="round"/><path d="M${H3.P2(hq)}c${f1(-2 * k)} ${f1(-0.4 * k)} ${f1(-2 * k)} ${f1(2.4 * k)} 0 ${f1(2.2 * k)}" stroke="#e8e2d6" stroke-width="${f1(0.7 * k)}" fill="none"/>`; if (nr(0, 26)) f += tp; else ov += tp; }
      // vines spiralling up three posts with leaves (the back one stays behind the sitter)
      [[-W, DZ], [W, DZ], [-W, -DZ]].forEach(([x, z]) => { const pts = rep(26, i => { const t = i / 25, a = t * 13; return p(x + Math.cos(a) * 4.2, 2 + t * (H - 2), z + Math.sin(a) * 4.2); });
        const v = `<path d="M${pts.map(H3.P2).join('L')}" fill="none" stroke="#6a4a2a" stroke-width="${f1(0.9 * k)}"/>` + pts.filter((q, i) => i % 2).map((q, i) => `<path d="${leafD(OVAL, q[0], q[1], 0.95 * k, i % 2 ? 60 : -60, 1)}" fill="${i % 3 ? '#5a9a44' : '#78b452'}"/>`).join('');
        if (nr(x, z)) f += v; else ov += v; });
      // leaf canopy over the rafters: compound leaves (rows of leaflets) in 3 greens
      const LV = ['', '', '']; rep(320, () => { const x = (R() - 0.5) * (2 * W + 18), z = (R() - 0.5) * (2 * DZ + 20), q = p(x, H + 13 + R() * 3, z), a = R() * 360; rep(7, j => { const d = (j - 3) * 2.4 * k, ca = Math.cos(a * PI / 180), sa = Math.sin(a * PI / 180); LV[(j + Math.floor(R() * 3)) % 3] += leafD(OVAL, q[0] + ca * d, q[1] + sa * d * 0.6, 1.5 * k, a + (j % 2 ? 70 : -70), 1); }); });
      f += `<path d="${LV[0]}" fill="#3f7a2e"/><path d="${LV[1]}" fill="#5a9a3e"/><path d="${LV[2]}" fill="#86bc56"/>`;
      // racemes: tapered cones of florets, pale at the top to deep violet at the tip, swaying out of step; short at the front so they clear a sitting head
      const RC = ['#d8cbf0', '#c4b0ea', '#ab90de', '#9474cc', '#7a58b8', '#6a48a8']; let rc = '';
      // depth after the turn (screen units back to piece units), so the short ones are always the ones nearest the viewer
      const o0 = p(0, 0, 0), u1 = (o0[1] - p(0, 1, 0)[1]) / Math.cos(38 * PI / 180), zr = (x, z) => (p(x, 0, z)[1] - o0[1]) / (u1 * Math.sin(38 * PI / 180));
      rep(54, i => { const x = (R() - 0.5) * (2 * W + 6), z = (R() - 0.5) * (2 * DZ + 6), q = p(x, H + 6, z), Z = zr(x, z), fr = Z > 14 ? 0.4 : Z > -10 ? 0.7 : 1, L0 = (14 + R() * 12) * fr; let g = '';
        rep(20, j => { const t = j / 19, w = (1 - t * 0.75) * 2.6; rep(3, m => { g += `<ellipse cx="${f1((R() - 0.5) * 2 * w)}" cy="${f1(t * L0)}" rx="${f1(1.2 - t * 0.5)}" ry="${f1(0.95 - t * 0.35)}" fill="${RC[Math.min(5, Math.floor(t * 6))]}"/>`; }); });
        rc += `<g transform="translate(${H3.P2(q)}) scale(${n4(k)})"><g>${H7.atV('rotate', ['-4', '5', '-4'], 3.2 + R() * 2, -R() * 3)}<path d="M0 -1V2" stroke="#5a8a3a" stroke-width="0.4"/>${g}<ellipse cx="-0.6" cy="${f1(L0 * 0.25)}" rx="0.5" ry="${f1(L0 * 0.25)}" fill="#ffffff" opacity="0.18"/></g></g>`; });
      f += rc;
      // petals drifting down
      f += rep(8, i => { const q = p((R() - 0.5) * 2 * W, H, (R() - 0.5) * 2 * DZ), T = 7 + R() * 4, b = -R() * T; return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.6 * k)}" ry="${f1(0.35 * k)}" fill="#b49ae4" opacity="0">${H3.an('opacity', '0;0.9;0.9;0', T, b)}<animateTransform attributeName="transform" type="translate" values="0 0;${f1(6 * k)} ${f1(50 * k)};${f1(2 * k)} ${f1(100 * k)}" dur="${n4(T)}s" begin="${n4(b)}s" repeatCount="indefinite"/></ellipse>`; }).join('');
      return { defs: H7.FDEF || '', under: un, front: f, over: ov, bb: H3.bbOf([p(-W - 14, 0, -DZ - 14), p(W + 14, 0, DZ + 14), p(-W - 14, H + 20, DZ + 14), p(W + 14, H + 20, -DZ - 14), p(-W - 14, 0, DZ + 14), p(W + 14, 0, -DZ - 14)], 3) }; };
    return D; };

  // YRD-069 MOTORIZED LOUVERED ALUMINIUM BIOCLIMATIC CABANA (T4): plus8 cabana8 layout (charcoal frame, tilting louvers, LED line, deep sofa; own taller frame since Nov 7) and
  // made to feel expensive: an oiled teak deck (plank seams), a cream wool outdoor rug, the coffee table in teak with a brass hurricane lantern (candle
  // flicker), extra throw pillows, a potted olive tree in a stone planter, sheer linen drapes gathered with a tie at the two front posts. Live: louvers
  // tilt (plus8), the drapes sway, the candle flickers, warm light pools on the deck.
  // Nov 7 (user: canopies too small + creatures sat on top of them): own frame, not plus8's: posts ~2x a sitting creature, wider + deeper, a deep sofa
  // wide enough for two. D.inside splits the piece: front posts, roof frame, louvers, LED line, drapes, coffee table + lantern and the olive tree draw
  // over a seated creature (fxF); the sofa, rug and back posts stay behind.
  N.cab32 = S => { const W = 74, DZ = 46, H = 124, AL = '#3a3d42', { mt, wd, cer, pt } = H3, fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {});
    const D = { w: 160, d: 104, seats: [{ x: -25, z: -4, h: 15 }, { x: 25, z: -4, h: 15 }], inside: [0, 15, 0], fxF: 1 };
    D.build = P => { const o = [XK.box(0, 0, 0, 2 * W + 8, 1.4, 2 * DZ + 8, '#9a6a42', wd({ r: 1 }))];
      [[-W, -DZ], [W, -DZ], [-W, DZ], [W, DZ]].forEach(([x, z]) => o.push(XK.box(x, 1.4, z, 6, H, 6, AL, mt({ r: 0.8 }))));
      o.push(XK.box(0, H, DZ, 2 * W + 6, 8, 6, AL, mt({ r: 0.8 })), XK.box(0, H, -DZ, 2 * W + 6, 8, 6, AL, mt({ r: 0.8 })), XK.box(-W, H, 0, 6, 8, 2 * DZ, AL, mt({ r: 0.8 })), XK.box(W, H, 0, 6, 8, 2 * DZ, AL, mt({ r: 0.8 })));
      // cream wool rug, deep sofa (base, arms, back, cushions, throw pillows)
      o.push(XK.box(0, 1.4, 8, 124, 0.3, 66, '#ece4d4', fb({ r: 1 })),
        XK.box(0, 1.4, -16, 104, 7, 30, AL, mt({ r: 1 })), XK.box(-55, 1.4, -16, 7, 18, 30, AL, mt({ r: 1 })), XK.box(55, 1.4, -16, 7, 18, 30, AL, mt({ r: 1 })), XK.box(0, 1.4, -30, 116, 24, 4, AL, mt({ r: 1 })),
        XK.cush(-25.5, 8.4, -14, 50, 6, 26, '#ece6d8', fb()), XK.cush(25.5, 8.4, -14, 50, 6, 26, '#ece6d8', fb()), XK.cush(-25.5, 14.4, -25, 50, 15, 6, '#ece6d8', fb()), XK.cush(25.5, 14.4, -25, 50, 15, 6, '#ece6d8', fb()),
        XK.cush(-40, 14.4, -20, 13, 11, 5, '#3f6a8a', fb()), XK.cush(40, 14.4, -20, 13, 11, 5, '#c8a45a', fb()), XK.cush(-10, 14.4, -21, 12, 9, 4, '#d8c49a', fb()), XK.cush(10, 14.4, -21, 12, 9, 4, '#f4efe4', fb()));
      // teak coffee table + brass hurricane lantern
      o.push(XK.box(0, 1.4, 26, 40, 11, 20, '#8a5a34', wd({ r: 1 })), XK.box(0, 12.4, 26, 3.8, 0.6, 3.8, '#c9a050', mt({ shine: 1 })), XK.cyl(0, 13, 26, 1.7, 6.4, '#f2f6f8', cer({ n: 12, op: 0.35 })), XK.cyl(0, 13, 26, 0.7, 2.4, '#f6f0e0', cer({ n: 8 })), XK.cyl(0, 19.4, 26, 1.9, 0.6, '#c9a050', mt({ n: 12, shine: 1 })));
      // olive tree in a stone planter, front right corner
      o.push(XK.cyl(W - 11, 1.4, DZ - 11, 7, 12, '#d8cfbe', pt({ n: 18, rg: [[0, 0, 0.9], [12, 0, 1]] })), XK.cyl(W - 11, 13.4, DZ - 11, 2.2, 18, '#7a6a52', wd({ n: 8 })),
        XK.ball(W - 11, 36, DZ - 11, 11, '#8a9a6a', pt({ k: 5, n: 14, soft: 1, sy: 0.85 })), XK.ball(W - 17, 32, DZ - 7, 7, '#9aaa76', pt({ k: 5, n: 12, soft: 1 })), XK.ball(W - 5, 32, DZ - 15, 7, '#7c8c5e', pt({ k: 5, n: 12, soft: 1 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k, R = rng('cab32'), P2 = H3.P2, nr = (x, z) => p(x, 0, z)[1] > p(0, 0, 0)[1]; let f = '', un = '', ov = ''; // ov: behind the sitter but over the build
      // louver blades tilt open and closed (motorized), clipped to the roof frame
      f += `<clipPath id="cb32"><path d="${H7.quad(p, [-W + 3, H + 8, -DZ + 3], [W - 3, H + 8, -DZ + 3], [W - 3, H + 8, DZ - 3], [-W + 3, H + 8, DZ - 3])}"/></clipPath><g clip-path="url(#cb32)">`;
      const n = 20; rep(n, i => { const x = -W + 5 + i * (2 * W - 10) / (n - 1); const q = (dx, dy) => P2(p(x + dx, H + 6.4 + dy, -DZ + 2)), r = (dx, dy) => P2(p(x + dx, H + 6.4 + dy, DZ - 2));
        const sh = t => `M${q(-3.4 * t, 1.7 * (1 - t))}L${r(-3.4 * t, 1.7 * (1 - t))}L${r(3.4 * t, -1.7 * (1 - t))}L${q(3.4 * t, -1.7 * (1 - t))}Z`;
        f += `<path d="${sh(1)}" fill="#e2e4e8" stroke="#6a6e76" stroke-width="${f1(0.3 * k)}"><animate attributeName="d" values="${sh(1)};${sh(1)};${sh(0.18)};${sh(0.18)};${sh(1)}" keyTimes="0;0.35;0.5;0.85;1" dur="14s" repeatCount="indefinite"/></path>`; });
      f += '</g>';
      // warm LED line under the front beam
      f += `<path d="M${P2(p(-W + 3, H + 0.4, DZ - 3))}L${P2(p(W - 3, H + 0.4, DZ - 3))}" stroke="#fff2c8" stroke-width="${f1(1 * k)}">${H3.an('opacity', '0.7;1;0.7', 3)}</path>`;
      // teak deck seams + warm pool of light
      let sm = ''; for (let x = -W - 2; x <= W + 2; x += 6) sm += `M${P2(p(x, 1.45, -DZ - 4))}L${P2(p(x, 1.45, DZ + 4))}`; un += `<path d="${sm}" stroke="#5a3a20" stroke-width="${f1(0.35 * k)}" opacity="0.6"/>` + H7.glowE(p, 0, 1.5, 6, 58, 38, '#ffd890', 0.22);
      // candle flame in the lantern
      { const q = p(0, 16.4, 26); (nr(0, 26) ? (t => { f += t; }) : (t => { ov += t; }))(`<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.6 * k)}" ry="${f1(1.2 * k)}" fill="#ffc860">${H3.an('ry', `${f1(1.1 * k)};${f1(1.4 * k)};${f1(1 * k)};${f1(1.3 * k)}`, 0.9)}</ellipse>` + H7.glowE(p, 0, 16, 26, 6, 6, '#ffd890', 0.45, 1)); }
      // olive leaves over the canopy balls
      { const LV = ['', '']; rep(170, () => { const a = R() * 2 * PI, e = R() * 1.4 - 0.3, q = p(W - 11 + Math.cos(a) * 11 * Math.cos(e), 36 + Math.sin(e) * 10, DZ - 11 + Math.sin(a) * 11 * Math.cos(e)); LV[R() < 0.5 ? 0 : 1] += leafD(OVAL, q[0], q[1], 1.5 * k, R() * 360, 0.45); });
        const ol = `<path d="${LV[0]}" fill="#6a7a4e"/><path d="${LV[1]}" fill="#b4bea0"/>`; if (nr(W - 11, DZ - 11)) f += ol; else ov += ol; }
      // sheer linen drapes at the two front posts, gathered with a tie, swaying
      [[-W, DZ, 1], [W, DZ, -1]].forEach(([x, z, s], i) => { const T0 = p(x + s * 2, H - 1, z + 1), T1 = p(x + s * 17, H - 1, z + 1), Ti = p(x + s * 2.6, 52, z + 2), B0 = p(x + s * 1, 1.6, z + 2), B1 = p(x + s * 12, 1.6, z + 3);
        const dr = `M${P2(T0)}L${P2(T1)}Q${f1((T1[0] + Ti[0]) / 2)} ${f1((T1[1] + Ti[1]) / 2 + 4 * k)} ${P2(Ti)}Q${f1((Ti[0] + B1[0]) / 2 + s * 2 * k)} ${f1((Ti[1] + B1[1]) / 2)} ${P2(B1)}L${P2(B0)}Q${f1(Ti[0] - s * 1 * k)} ${f1((Ti[1] + B0[1]) / 2)} ${P2(Ti)}Q${f1(T0[0])} ${f1((T0[1] + Ti[1]) / 2)} ${P2(T0)}Z`;
        let fold = ''; rep(4, m => { const t = (m + 1) / 5, a = [T0[0] + (T1[0] - T0[0]) * t, T0[1] + (T1[1] - T0[1]) * t], b = [B0[0] + (B1[0] - B0[0]) * t, B0[1] + (B1[1] - B0[1]) * t]; fold += `M${f1(a[0])} ${f1(a[1])}Q${P2(Ti)} ${f1(b[0])} ${f1(b[1])}`; });
        const dg = `<g transform="translate(${P2(T0)})"><g>${H7.atV('skewX', ['0', `${s * 2.5}`, '0', `${-s * 1.5}`, '0'], 5 + i * 0.8)}<g transform="translate(${f1(-T0[0])} ${f1(-T0[1])})"><path d="${dr}" fill="#f8f4ec" opacity="0.72"/><path d="${fold}" stroke="#d8d0c0" stroke-width="${f1(0.4 * k)}" fill="none" opacity="0.8"/></g></g></g>`
          + `<ellipse cx="${f1(Ti[0])}" cy="${f1(Ti[1])}" rx="${f1(2.2 * k)}" ry="${f1(0.8 * k)}" fill="#c9a050"/>`; if (nr(x, z)) f += dg; else ov += dg; });
      return { defs: H7.FDEF || '', under: un, front: f, over: ov, bb: H3.bbOf([p(-W - 8, 0, -DZ - 8), p(W + 8, 0, DZ + 8), p(-W - 8, 0, DZ + 8), p(W + 8, 0, -DZ - 8), p(0, H + 12, -DZ), p(0, H + 12, DZ), p(-W - 8, H + 10, DZ), p(W + 8, H + 10, DZ)], 3) }; };
    return D; };

  // YRD-089 RETRACTABLE GEODESIC GLASS CONSERVATORY DOME (T5, new build; was the generic candy glass ball): a frequency-3 geodesic half-sphere of
  // triangular glass panes in a slim bronze frame on a honed marble plinth with a polished brass ring. Inside: a teak daybed with cream cushions,
  // bolsters and terracotta + saffron pillows (2 seats), a potted fan palm and a fern, a brass side table, and a brass chandelier hanging from the apex.
  // Live: one wedge of panes slides up and back (retracting), a sheen glides over the glass, the chandelier glows warm, the palm sways.
  N.dome32 = S => { const RD0 = 86, Y0 = 3, D = { w: 196, d: 176, seats: [{ x: -20, z: 6, h: 17 }, { x: 20, z: 6, h: 17 }], inside: [0, 17, 6], fxF: 1 }, { mt, wd, cer, pt } = H3, fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {});
    D.build = P => [XK.cyl(0, 0, 0, 93, 3, '#e8e2d6', cer({ n: 48, rg: [[0, 0, 1], [3, 0, 0.94]] })), XK.cyl(0, 3, 0, 90, 0.4, '#c9a050', mt({ n: 48, shine: 1 })), XK.cyl(0, 3.4, 0, 89, 0.2, '#efe9de', cer({ n: 48 })),
      XK.box(0, 3.4, 4, 86, 8, 32, '#8a5a34', wd({ r: 1 })), XK.cush(0, 11.4, 4, 80, 6, 28, '#f4efe4', fb()), XK.cush(-39, 17.4, 4, 6, 7, 26, '#d8c8a8', fb()), XK.cush(39, 17.4, 4, 6, 7, 26, '#d8c8a8', fb()),
      XK.cush(-20, 17.4, -7, 13, 10, 4, '#c86a4a', fb()), XK.cush(20, 17.4, -7, 13, 10, 4, '#e8b45a', fb()), XK.cush(0, 17.4, -8, 12, 9, 4, '#f2e8d4', fb()),
      XK.cyl(-46, 3.4, -36, 7.4, 12, '#c87a4a', cer({ n: 18, rg: [[0, 0, 0.82], [12, 0, 1]] })), XK.cyl(56, 3.4, -40, 6, 9, '#e8e2d6', cer({ n: 16, rg: [[0, 0, 0.85], [9, 0, 1]] })),
      XK.cyl(58, 3.4, 30, 1.1, 11, '#c9a050', mt({ n: 8, shine: 1 })), XK.cyl(58, 14.4, 30, 6.6, 0.8, '#c9a050', mt({ n: 18, shine: 1 })), XK.cyl(58, 15.2, 30, 1.3, 3.2, '#f4f1ea', cer({ n: 10 })),
      // brass uplight pucks set into the plinth rim (they also keep a part of the piece in front of the sitter at every turn, so the glass split always happens)
      ...rep(10, i => { const a = i / 10 * 2 * PI + 0.3; return XK.cyl(Math.cos(a) * 86, 3.4, Math.sin(a) * 86, 2.2, 1.4, '#c9a050', mt({ n: 12, shine: 1 })); })];
    // geodesic: icosahedron with a vertex at the top, each face split 3 x 3, the lower half dropped (kept faces: centroid above the plinth)
    const t0 = (1 + Math.sqrt(5)) / 2, phi = Math.atan(-1 / t0), cr = Math.cos(phi), sr = Math.sin(phi);
    const V0 = [[-1, t0, 0], [1, t0, 0], [-1, -t0, 0], [1, -t0, 0], [0, -1, t0], [0, 1, t0], [0, -1, -t0], [0, 1, -t0], [t0, 0, -1], [t0, 0, 1], [-t0, 0, -1], [-t0, 0, 1]].map(([x, y, z]) => [x * cr - y * sr, x * sr + y * cr, z]);
    const FI = [[0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11], [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8], [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9], [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1]];
    const nz = v => { const l = Math.hypot(...v); return v.map(q => q / l); }, TRI = [];
    FI.forEach(([a, b, cc]) => { const A = V0[a], B = V0[b], C = V0[cc], Pp = (i, j) => nz([0, 1, 2].map(m => (i * A[m] + j * B[m] + (3 - i - j) * C[m]) / 3));
      for (let i = 0; i < 3; i++) for (let j = 0; j < 3 - i; j++) { TRI.push([Pp(i + 1, j), Pp(i, j + 1), Pp(i, j)]); if (i + j < 2) TRI.push([Pp(i + 1, j), Pp(i + 1, j + 1), Pp(i, j + 1)]); } });
    const W3 = v => [v[0] * RD0, Y0 + Math.max(0, v[1]) * RD0 * 1.1, v[2] * RD0], DOME = TRI.filter(T => (T[0][1] + T[1][1] + T[2][1]) / 3 > -0.02).map(T => T.map(W3));
    D.fx = c => { const p = c.p, k = c.k, R = rng('dome32'); let bk = '', fr = '', fg = '', un = '', mov = '', ul = '', gc = '', ov = ''; const nr = (x, z) => p(x, 0, z)[1] > p(0, 0, 0)[1];
      const sA = T => { const a = p(...T[0]), b = p(...T[1]), d = p(...T[2]); return (b[0] - a[0]) * (d[1] - a[1]) - (b[1] - a[1]) * (d[0] - a[0]); };
      const out = T => { const cn = [0, 1, 2].map(m => (T[0][m] + T[1][m] + T[2][m]) / 3), u = [0, 1, 2].map(m => T[1][m] - T[0][m]), v = [0, 1, 2].map(m => T[2][m] - T[0][m]), n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]; return (n[0] * cn[0] + n[1] * (cn[1] - Y0) + n[2] * cn[2]) > 0 ? T : [T[0], T[2], T[1]]; };
      const top = DOME.map(out).sort((a, b) => (b[0][1] + b[1][1] + b[2][1]) - (a[0][1] + a[1][1] + a[2][1]))[0], FS = Math.sign(sA(top));
      // shadow + warm glow on the plinth
      un += `<ellipse cx="${f1(p(4, 0, 4)[0])}" cy="${f1(p(4, 0, 4)[1])}" rx="${f1(90 * k)}" ry="${f1(46 * k)}" fill="#203040" opacity="0.16" filter="url(#f7s)"/>`;
      const frm = d => `<path d="${d}" fill="none" stroke="#6a4a24" stroke-width="${f1(0.75 * k)}" stroke-linejoin="round"/><path d="${d}" fill="none" stroke="#e2c48a" stroke-width="${f1(0.3 * k)}" stroke-linejoin="round" opacity="0.8"/>`;
      DOME.map(out).forEach(T => { const d = `M${T.map(q => H3.P2(p(...q))).join('L')}Z`, front = Math.sign(sA(T)) === FS, cn = [0, 1, 2].map(m => (T[0][m] + T[1][m] + T[2][m]) / 3), L = lit(nrm(T[0], T[1], T[2]));
        if (front) gc += d; if (!front) { bk += `<path d="${d}" fill="#cfe6ee" opacity="0.12"/><path d="${d}" fill="none" stroke="#5a4020" stroke-width="${f1(0.7 * k)}" opacity="0.6" stroke-linejoin="round"/>`; return; }
        const g = `<path d="${d}" fill="#e8f6fa" opacity="${n4(0.04 + 0.1 * L)}"/>` + (L > 0.8 && R() < 0.5 ? `<path d="${d}" fill="url(#dm32g)" opacity="0.6"/>` : '') + frm(d);
        const th = Math.atan2(cn[0], cn[2]); if (th > 0.25 && th < 0.95 && cn[1] < 68) mov += g; else fg += g; });
      // the retracting wedge slides up over its neighbours and back
      fg += `<g>${H7.atV('translate', ['0 0', '0 0', `${f1(-2 * k)} ${f1(-12 * k)}`, `${f1(-2 * k)} ${f1(-12 * k)}`, '0 0'], 16)}${mov}</g>`;
      // sheen sweeping across the front panes, clipped to the glass
      { const a = p(-88, 90, 44), b = p(88, 0, 44); fg += `<clipPath id="dm32c"><path d="${gc}"/></clipPath><g clip-path="url(#dm32c)"><rect x="${f1(Math.min(a[0], b[0]) - 60 * k)}" y="${f1(p(0, 96, 0)[1] - 4 * k)}" width="${f1(20 * k)}" height="${f1(104 * k)}" fill="#ffffff" opacity="0.1" transform="skewX(-20)">${H3.an('x', `${f1(Math.min(a[0], b[0]) - 60 * k)};${f1(Math.max(a[0], b[0]) + 90 * k)}`, 9)}</rect></g>`; }
      // warm pools from the rim uplights (near ones in front, far ones behind, by depth after the turn)
      rep(10, i => { const a = i / 10 * 2 * PI + 0.3, X0 = Math.cos(a) * 86, Z0 = Math.sin(a) * 86, g = `<g>${H7.glowE(p, X0, 5, Z0, 4, 4, '#ffd890', 0.55, 1)}</g>`, nz = p(X0, 0, Z0)[1] > p(0, 0, 0)[1]; if (nz) ul += g; else ov += g; });
      // fan palm + fern (inside, behind the daybed: they stay behind a sitter)
      { const base = [-46, 15.4, -36]; let pl = H7.tube([p(...base), p(-45, 44, -35)], 1.9, k, '#7a5a3a', '#a88a64', '#3a2a1a'); const tp = p(-45, 44, -35);
        rep(10, i => { const a = i / 10 * 2 * PI, L = 15 + R() * 5, e = [-45 + Math.cos(a) * L, 41 - (i % 3) * 4, -35 + Math.sin(a) * L * 0.8], m = [-45 + Math.cos(a) * L * 0.5, 50, -35 + Math.sin(a) * L * 0.4], q = p(...e), qm = p(...m);
          let lf = ''; rep(8, j => { const t = (j + 1) / 9, x = tp[0] + (q[0] - tp[0]) * t, y = tp[1] + (qm[1] - tp[1]) * 2 * t * (1 - t) * 0.9 + (q[1] - tp[1]) * t * t; lf += leafD(OVAL, x, y, (1.5 - t * 0.6) * k, Math.atan2(q[1] - tp[1], q[0] - tp[0]) * 180 / PI + 90 + (j % 2 ? 50 : -50), 0.6); });
          pl += `<path d="M${H3.P2(tp)}Q${H3.P2(qm)} ${H3.P2(q)}" stroke="#4a7a2e" stroke-width="${f1(0.5 * k)}" fill="none"/><path d="${lf}" fill="${i % 2 ? '#3e7a34' : '#5a9a3e'}"/>`; });
        let fe = ''; const fq = p(56, 12.4, -40); rep(12, i => { const a = -172 + i * 13.5, L = (9 + R() * 4) * k, ex = fq[0] + Math.cos(a * PI / 180) * L, ey = fq[1] + Math.sin(a * PI / 180) * L * 0.8; fe += `M${f1(fq[0])} ${f1(fq[1])}Q${f1((fq[0] + ex) / 2)} ${f1(Math.min(fq[1], ey) - 3 * k)} ${f1(ex)} ${f1(ey)}`; });
        const pm = `<g>${H7.atV('rotate', ['-1.5 ' + H3.P2(p(...base)), '1.5 ' + H3.P2(p(...base)), '-1.5 ' + H3.P2(p(...base))], 6)}${pl}</g>`, fn = `<path d="${fe}" stroke="#4e8a36" stroke-width="${f1(1.6 * k)}" fill="none" stroke-linecap="round"/><path d="${fe}" stroke="#7ab452" stroke-width="${f1(0.5 * k)}" fill="none" stroke-dasharray="${f1(0.6 * k)} ${f1(0.6 * k)}"/>`;
        if (nr(-46, -36)) fr += pm; else ov += pm; if (nr(56, -40)) fr += fn; else ov += fn; }
      // brass chandelier from the apex (above and behind a sitting head, so it stays in the back layer): chain, ring, candle bulbs, warm glow
      { const ap = p(0, Y0 + RD0 * 1.1, 0), cy = 86, rg = p(0, cy, 0); let ch = `<path d="M${H3.P2(ap)}L${H3.P2(rg)}" stroke="#a8803a" stroke-width="${f1(0.4 * k)}" stroke-dasharray="${f1(0.8 * k)} ${f1(0.4 * k)}"/>`;
        let ring = ''; rep(25, m => { const a = m / 24 * 2 * PI; ring += (m ? 'L' : 'M') + H3.P2(p(Math.cos(a) * 10, cy, Math.sin(a) * 10)); });
        ch += H7.glowE(p, 0, cy, 0, 30, 30, '#ffd890', 0.35, 1) + `<path d="${ring}" fill="none" stroke="#8a6a2a" stroke-width="${f1(1.2 * k)}"/><path d="${ring}" fill="none" stroke="#f0d08a" stroke-width="${f1(0.4 * k)}"/>`
          + rep(8, m => { const a = m / 8 * 2 * PI, q = p(Math.cos(a) * 10, cy + 2.4, Math.sin(a) * 10); return `<rect x="${f1(q[0] - 0.4 * k)}" y="${f1(q[1])}" width="${f1(0.8 * k)}" height="${f1(2.2 * k)}" fill="#f4efe4"/><ellipse cx="${f1(q[0])}" cy="${f1(q[1] - 0.6 * k)}" rx="${f1(0.7 * k)}" ry="${f1(1 * k)}" fill="#ffe2a0">${H3.an('opacity', '0.8;1;0.85', 1.4 + m * 0.2)}</ellipse>`; }).join('');
        ov += ch; }
      return { defs: (H7.FDEF || '') + '<linearGradient id="dm32g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.7"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/></linearGradient>', under: un, back: bk, over: ov, front: fr + fg + ul,
        bb: H3.bbOf([p(-100, 0, -100), p(100, 0, 100), p(-100, 0, 100), p(100, 0, -100), p(0, Y0 + RD0 * 1.12, 0), p(-RD0, 45, 0), p(RD0, 45, 0), p(0, 45, RD0), p(0, 45, -RD0)], 4) }; };
    return D; };

  // ======================= OUTDOOR LIGHTS =======================
  // YRD-003 SINGLE BUG-ZAPPER BULB ON A POST (T1): plus8 zapper8 (UV coil in a cage, moths circling, zap flash + sparks) made cheap and worn: a grey
  // weathered stake pushed into a dirt mound, a rusty hook arm, a cracked cage, an orange extension cord taped down the post with grey duct tape and
  // coiled in the grass, a cobweb between arm and post, dead bugs littering the ground under the bulb.
  N.zap32 = S => { const D = N.zapper8(S), f0 = D.fx, BY = 70, { pt, wd, mt } = H3;
    D.build = P => [XK.cyl(0, 0, 0, 6, 1.6, '#6a5236', pt({ n: 12, rg: [[0, 0, 1], [1.6, 0, 0.6]] })), XK.box(0, 0, 0, 3.4, BY - 6, 3.4, '#8a7c66', wd({ r: 0.4 })), XK.box(4.5, BY - 8, 0, 10, 1.6, 1.6, '#6a4a32', mt({ r: 0.3 })), XK.cyl(10, BY - 10, 0, 2.4, 3.6, '#1e1e22', mt({ n: 12 }))];
    D.fx = c => { const F = f0(c) || {}, p = c.p, k = c.k, R = rng('zap32'); let f = '', un = '';
      // dead bugs under the bulb + a little scorched patch
      { const q = p(10, 0, 0); un += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(9 * k)}" ry="${f1(4 * k)}" fill="#2a2216" opacity="0.18" filter="url(#f7s)"/>` + rep(14, () => { const b = p(10 + (R() - 0.5) * 14, 0.2, (R() - 0.5) * 10); return `<ellipse cx="${f1(b[0])}" cy="${f1(b[1])}" rx="${f1(0.5 * k)}" ry="${f1(0.3 * k)}" fill="#2a2018" transform="rotate(${f1(R() * 180)} ${f1(b[0])} ${f1(b[1])})"/>`; }).join(''); }
      // orange extension cord: from the socket along the arm, down the post (taped), across the grass into a coil
      { const pts = [p(10, BY - 9, 0), p(3, BY - 7.4, 1.8), p(1.8, BY - 12, 1.8), p(1.9, 40, 1.9), p(1.8, 10, 1.9), p(2.4, 1, 3), p(10, 0.4, 12), p(22, 0.4, 10)]; f += `<path d="M${pts.map(H3.P2).join('L')}" fill="none" stroke="#a84a14" stroke-width="${f1(1.3 * k)}" stroke-linejoin="round"/><path d="M${pts.map(H3.P2).join('L')}" fill="none" stroke="#d87424" stroke-width="${f1(0.8 * k)}" stroke-linejoin="round"/><path d="M${pts.map(H3.P2).join('L')}" fill="none" stroke="#5a3a20" stroke-width="${f1(0.8 * k)}" stroke-linejoin="round" stroke-dasharray="${f1(2 * k)} ${f1(5 * k)}" opacity="0.4"/>`;
        [52, 30, 14].forEach(y => { const q = p(1.8, y, 1.9); f += `<rect x="${f1(q[0] - 2 * k)}" y="${f1(q[1] - 0.9 * k)}" width="${f1(3.6 * k)}" height="${f1(1.6 * k)}" fill="#a8aaa6"/><path d="M${f1(q[0] - 2.4 * k)} ${f1(q[1] - 1.2 * k)}l${f1(0.4 * k)} ${f1(2.2 * k)}" stroke="#8a8c88" stroke-width="${f1(0.2 * k)}"/>`; });
        const cq = p(24, 0.4, 10); f += rep(3, i => `<ellipse cx="${f1(cq[0] + i * 0.6 * k)}" cy="${f1(cq[1] - i * 0.4 * k)}" rx="${f1((5 - i) * k)}" ry="${f1((2.4 - i * 0.4) * k)}" fill="none" stroke="#f08a2a" stroke-width="${f1(0.9 * k)}"/>`).join('') + `<rect x="${f1(cq[0] + 4 * k)}" y="${f1(cq[1] - 1 * k)}" width="${f1(2.4 * k)}" height="${f1(1.6 * k)}" fill="#e87a1a"/>`; }
      // cracks in the cage + cobweb between arm and post
      { const q = p(10, BY - 13, 0); f += `<path d="M${f1(q[0] - 3 * k)} ${f1(q[1] + 3 * k)}l${f1(1.4 * k)} ${f1(2 * k)}l${f1(-0.6 * k)} ${f1(1.6 * k)}" stroke="#e8e8f0" stroke-width="${f1(0.25 * k)}" fill="none" opacity="0.8"/>`;
        const a = p(0, BY - 8, 1.8), b = p(7, BY - 7, 1), cc = p(0, BY - 16, 1.8); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}M${H3.P2(a)}L${H3.P2(cc)}M${H3.P2(b)}Q${f1((b[0] + cc[0]) / 2 + 1 * k)} ${f1((b[1] + cc[1]) / 2 + 1 * k)} ${H3.P2(cc)}` + rep(3, i => { const t = 0.3 + i * 0.22; return `M${f1(a[0] + (b[0] - a[0]) * t)} ${f1(a[1] + (b[1] - a[1]) * t)}Q${f1(a[0] + 1 * k)} ${f1(a[1] + 1 * k)} ${f1(a[0] + (cc[0] - a[0]) * t)} ${f1(a[1] + (cc[1] - a[1]) * t)}`; }).join('') + `" stroke="#f4f4f4" stroke-width="${f1(0.15 * k)}" fill="none" opacity="0.7"/>`; }
      return Object.assign({}, F, { under: (F.under || '') + un, front: (F.front || '') + f }); };
    return D; };

  // YRD-023 SOLAR-POWERED PLASTIC PATHWAY STAKE LIGHTS (T2): a row of five cheap black plastic stake lights pushed into the lawn (one leaning, one cap
  // cracked): spike, thin stem, a frosted plastic lantern with moulded facets, a cap with a little blue solar cell grid, a cool-warm LED; soft glow pools
  // on the grass, little dirt mounds where they were pushed in. Live: the glows breathe, the leaning one flickers (low battery).
  N.solar32 = S => { const D = { w: 140, d: 30, glow: () => ({ y: 30, r: 90 }) }, XS = [-56, -28, 0, 28, 56], ZS = [2, -4, 3, -2, 4], LEAN = [0, 0, 9, 0, -3];
    D.build = P => XS.map((x, i) => XK.cyl(x, 0, ZS[i], 3.4, 0.8, '#6a5236', H3.pt({ n: 10, rg: [[0, 0, 1], [0.8, 0, 0.5]] })));
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '', gl = '';
      XS.forEach((x, i) => { const z = ZS[i], l = LEAN[i] * PI / 180, at3 = h => [x + Math.sin(l) * h, h * Math.cos(l), z], b = p(...at3(0)), s1 = p(...at3(14)), h0 = p(...at3(13)), h1 = p(...at3(24)), cp = p(...at3(25.8)), r = 4.4 * k, ry = r * 0.45;
        const dim = i === 2, warm = i % 2 ? '#fff2c8' : '#fffbe8';
        un += `<ellipse cx="${f1(b[0])}" cy="${f1(b[1])}" rx="${f1(14 * k)}" ry="${f1(6 * k)}" fill="#fff4c8" opacity="0.3" filter="url(#f7s)">${H3.an('opacity', dim ? '0.05;0.3;0.1;0.25;0.05' : '0.24;0.36;0.24', dim ? 1.7 : 4 + i * 0.4)}</ellipse>`;
        f += H7.tube([b, s1], 0.9, k, '#2a2b2e', '#5a5c60', '#121214');
        // lantern body: frosted faceted plastic, lit from inside
        f += `<path d="M${f1(h0[0] - r)} ${f1(h0[1])}L${f1(h1[0] - r)} ${f1(h1[1])}A${f1(r)} ${f1(ry)} 0 0 0 ${f1(h1[0] + r)} ${f1(h1[1])}L${f1(h0[0] + r)} ${f1(h0[1])}A${f1(r)} ${f1(ry)} 0 0 1 ${f1(h0[0] - r)} ${f1(h0[1])}Z" fill="${warm}" opacity="0.88">${H3.an('opacity', dim ? '0.35;0.85;0.45;0.8;0.35' : '0.78;0.95;0.78', dim ? 1.7 : 4 + i * 0.4)}</path>`
          + rep(4, m => { const dx = (-0.6 + m * 0.4) * r; return `<path d="M${f1(h0[0] + dx)} ${f1(h0[1] + ry * 0.6)}L${f1(h1[0] + dx)} ${f1(h1[1] + ry * 0.6)}" stroke="#d8d0b8" stroke-width="${f1(0.25 * k)}" opacity="0.7"/>`; }).join('')
          + `<path d="M${f1(h0[0] - r)} ${f1(h0[1])}A${f1(r)} ${f1(ry)} 0 0 0 ${f1(h0[0] + r)} ${f1(h0[1])}" fill="none" stroke="#1e1e22" stroke-width="${f1(0.8 * k)}"/>`
          // cap + solar cell
          + `<path d="M${f1(h1[0] - r * 1.15)} ${f1(h1[1])}L${f1(cp[0] - r * 1.05)} ${f1(cp[1])}A${f1(r * 1.05)} ${f1(ry * 1.05)} 0 0 1 ${f1(cp[0] + r * 1.05)} ${f1(cp[1])}L${f1(h1[0] + r * 1.15)} ${f1(h1[1])}A${f1(r * 1.15)} ${f1(ry * 1.15)} 0 0 1 ${f1(h1[0] - r * 1.15)} ${f1(h1[1])}Z" fill="#26272b"/>`
          + `<ellipse cx="${f1(cp[0])}" cy="${f1(cp[1])}" rx="${f1(r * 1.05)}" ry="${f1(ry * 1.05)}" fill="#1e1e22"/><ellipse cx="${f1(cp[0])}" cy="${f1(cp[1])}" rx="${f1(r * 0.75)}" ry="${f1(ry * 0.75)}" fill="#24406e"/>`
          + `<path d="M${f1(cp[0] - r * 0.75)} ${f1(cp[1])}h${f1(r * 1.5)}M${f1(cp[0] - r * 0.25)} ${f1(cp[1] - ry * 0.7)}v${f1(ry * 1.4)}M${f1(cp[0] + r * 0.25)} ${f1(cp[1] - ry * 0.7)}v${f1(ry * 1.4)}" stroke="#8aa6d8" stroke-width="${f1(0.18 * k)}" opacity="0.7"/><ellipse cx="${f1(cp[0] - r * 0.3)}" cy="${f1(cp[1] - ry * 0.3)}" rx="${f1(r * 0.25)}" ry="${f1(ry * 0.2)}" fill="#ffffff" opacity="0.35"/>`
          + (i === 4 ? `<path d="M${f1(cp[0] - r * 0.2)} ${f1(cp[1] - ry * 0.9)}l${f1(0.6 * k)} ${f1(ry * 0.8)}l${f1(-0.3 * k)} ${f1(ry * 0.6)}" stroke="#c8c8cc" stroke-width="${f1(0.2 * k)}" fill="none"/>` : '');
        gl += `<circle cx="${f1((h0[0] + h1[0]) / 2)}" cy="${f1((h0[1] + h1[1]) / 2)}" r="${f1(7 * k)}" fill="#fff2c0" opacity="0.35" filter="url(#f7s)">${H3.an('opacity', dim ? '0.05;0.35;0.1;0.3;0.05' : '0.28;0.42;0.28', dim ? 1.7 : 4 + i * 0.4)}</circle>`; });
      // a stray weed by the last stake
      { const q = p(60, 0, 8); f += `<path d="M${H3.P2(q)}q${f1(-1 * k)} ${f1(-3 * k)} ${f1(-2.4 * k)} ${f1(-5 * k)}M${H3.P2(q)}q${f1(1 * k)} ${f1(-2.6 * k)} ${f1(2.6 * k)} ${f1(-4 * k)}M${H3.P2(q)}v${f1(-6 * k)}" stroke="#5a8a34" stroke-width="${f1(0.5 * k)}" fill="none"/>`; }
      return { defs: H7.FDEF || '', under: un, front: f + gl, bb: H3.bbOf([p(-70, 0, -14), p(70, 0, 14), p(-60, 30, 0), p(60, 30, 0), p(0, 28, 0)], 6) }; };
    return D; };

  // YRD-043 EDISON BULB BISTRO STRING LIGHTS ACROSS YARD (T3, a yard-lights surface): catalog card = a dusk patio with criss-crossing strands of amber
  // Edison bulbs (black sockets, teardrop glass, glowing filaments, warm halos). Room: res.ylRoom = an overlay picture in room space (-100 -60 1052 420)
  // that the house draws over the shell (rt.ylOn / rt.yl) instead of the plain festoon: strands from the house gutter to the fence tops and one across,
  // bulbs bigger toward the front. Live: bulbs flicker softly out of step, the strands sway a touch.
  const edisonBulb = (x, y, s, R) => { const T = 2.2 + R() * 2.4, b = -R() * T;
    return `<circle cx="${f1(x)}" cy="${f1(y + 5.4 * s)}" r="${f1(9 * s)}" fill="url(#ed32h)" opacity="0.75">${an('opacity', '0.62;0.85;0.7;0.8;0.62', T, b)}</circle>`
      + `<path d="M${f1(x)} ${f1(y)}v${f1(1.2 * s)}" stroke="#2a2622" stroke-width="${f1(0.5 * s)}"/><rect x="${f1(x - 1.1 * s)}" y="${f1(y + 1.2 * s)}" width="${f1(2.2 * s)}" height="${f1(2.2 * s)}" rx="${f1(0.3 * s)}" fill="#1e1c1a"/><rect x="${f1(x - 1.1 * s)}" y="${f1(y + 1.2 * s)}" width="${f1(0.6 * s)}" height="${f1(2.2 * s)}" fill="#4a4642"/>`
      + `<path d="M${f1(x - 1 * s)} ${f1(y + 3.4 * s)}C${f1(x - 3 * s)} ${f1(y + 5 * s)} ${f1(x - 2.6 * s)} ${f1(y + 9 * s)} ${f1(x)} ${f1(y + 9.4 * s)}C${f1(x + 2.6 * s)} ${f1(y + 9 * s)} ${f1(x + 3 * s)} ${f1(y + 5 * s)} ${f1(x + 1 * s)} ${f1(y + 3.4 * s)}Z" fill="#ffcf72" opacity="0.92"/>`
      + `<path d="M${f1(x - 0.6 * s)} ${f1(y + 4 * s)}l${f1(0.3 * s)} ${f1(3 * s)}q${f1(0.3 * s)} ${f1(-1.2 * s)} ${f1(0.6 * s)} 0q${f1(0.3 * s)} ${f1(-1.2 * s)} ${f1(0.6 * s)} 0l${f1(-0.0)} ${f1(-3 * s)}" stroke="#fff6d0" stroke-width="${f1(0.3 * s)}" fill="none"/>`
      + `<path d="M${f1(x - 1.6 * s)} ${f1(y + 5 * s)}q${f1(-0.4 * s)} ${f1(2 * s)} ${f1(0.6 * s)} ${f1(3.4 * s)}" stroke="#ffffff" stroke-width="${f1(0.4 * s)}" fill="none" opacity="0.6"/>`; };
  const strand = (x0, y0, x1, y1, sag, n, s0, s1, R, ph) => { const xm = (x0 + x1) / 2, ym = (y0 + y1) / 2 + sag, q = (t, a, b2, c2) => (1 - t) * (1 - t) * a + 2 * (1 - t) * t * b2 + t * t * c2;
    let s = `<path d="M${f1(x0)} ${f1(y0)}Q${f1(xm)} ${f1(ym + sag)} ${f1(x1)} ${f1(y1)}" stroke="#2a2622" stroke-width="${f1(0.3 + (s0 + s1) * 0.35)}" fill="none"/>`;
    for (let i = 0; i < n; i++) { const t = (i + 0.5) / n, x = q(t, x0, xm, x1), y = q(t, y0, ym + sag, y1); s += edisonBulb(x, y, s0 + (s1 - s0) * t, R); }
    return `<g>${at('translate', `0 0;0 ${f1(0.8 * (s0 + s1))};0 0`, 5 + ph, -ph, SPL(2))}${s}</g>`; };
  const ED_DEF = '<radialGradient id="ed32h" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffd890" stop-opacity="0.9"/><stop offset="0.35" stop-color="#ffc060" stop-opacity="0.35"/><stop offset="1" stop-color="#ffb040" stop-opacity="0"/></radialGradient>';
  function edisonCard() { const R = rng('ed32c');
    let s = '<defs>' + ED_DEF + '<linearGradient id="ed32s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a3a5e"/><stop offset="0.55" stop-color="#7a6a8a"/><stop offset="1" stop-color="#e8a878"/></linearGradient></defs>';
    s += '<rect width="80" height="56" fill="url(#ed32s)"/>' + rep(14, () => `<circle cx="${f1(R() * 80)}" cy="${f1(R() * 18)}" r="0.25" fill="#ffffff" opacity="${f1(0.4 + R() * 0.5)}"/>`).join('');
    s += `<path d="M0 40Q20 34 40 37T80 35V56H0Z" fill="#2e3a2a"/><path d="M0 46H80V56H0Z" fill="#6a5a48"/><path d="${rep(9, i => `M${f1(i * 10 - 2)} 46L${f1(i * 12 - 10)} 56`).join('')}M0 50H80" stroke="#4e4234" stroke-width="0.3"/>`
      + `<rect x="2" y="12" width="1.4" height="36" fill="#3a2e24"/><rect x="76.6" y="10" width="1.4" height="38" fill="#3a2e24"/>`;
    s += strand(3, 14, 77, 12, 6, 9, 0.38, 0.38, R, 0.2) + strand(3, 22, 77, 14, 9, 10, 0.42, 0.36, R, 1.1) + strand(3, 13, 77, 24, 9, 10, 0.36, 0.44, R, 2);
    s += `<ellipse cx="40" cy="50" rx="34" ry="5" fill="#ffc870" opacity="0.18" filter="url(#g32b)"/>`;
    return RD.svgDoc('0 0 80 56', [], s); }
  function edisonRoom() { const R = rng('ed32r');
    let s = '<defs>' + ED_DEF + '</defs>';
    // fixing points: house gutter (y 9) and the side fence tops (x 40 / 812, y 141); a short pole at each fence end
    [[40, 141], [812, 141]].forEach(([x, y]) => { s += `<rect x="${x - 1.6}" y="${y - 50}" width="3.2" height="52" fill="#3a2e24"/><rect x="${x - 1.6}" y="${y - 50}" width="1" height="52" fill="#6a5a48"/><circle cx="${x}" cy="${y - 50}" r="2" fill="#2a2622"/>`; });
    s += strand(110, 12, 742, 12, 18, 13, 1, 1, R, 2.2) + strand(140, 10, 812, 92, 40, 14, 1.05, 1.7, R, 0.3) + strand(712, 10, 40, 92, 40, 14, 1.05, 1.7, R, 1.4) + strand(40, 92, 812, 92, 26, 16, 1.8, 1.8, R, 0.9);
    return RD.svgDoc('-100 -60 1052 420', [], s); }

  // ======================= BBQ STATIONS =======================
  // YRD-002 RUSTY PORTABLE CHARCOAL HIBACHI GRILL (T1): plus7 hibachi kept (cast iron, draft doors, wooden handles, tap to light) + the cheap mess round
  // it: flaky rust blooms on the walls, a slumped torn paper sack of briquettes with a few spilled, rusty tongs dropped in front, grey ash dust underneath.
  N.hib32 = S => { const D = N.hibachi(S), f0 = D.fx, W = 66, DZ = 34;
    D.build = (b0 => P => b0(P).concat([XK.box(40, 0, -16, 9, 7, 6, '#b8946a', H3.pt({ r: 1.4 })), XK.box(40, 7, -16, 8, 2.4, 5, '#a8845a', H3.pt({ r: 1.2 }))]))(D.build);
    D.fx = c => { const F = f0(c) || {}, p = c.p, k = c.k, R = rng('hib32'); let f = '', un = '';
      { const q = p(0, 0, 0); un += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(44 * k)}" ry="${f1(16 * k)}" fill="#8a8680" opacity="0.28" filter="url(#f7s)"/>`; }
      // rust blooms on the near wall + end walls
      rep(9, () => { const q = p((R() - 0.5) * (W - 8), 6 + R() * 10, DZ / 2 + 0.2); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((1 + R() * 2) * k)}" ry="${f1((0.8 + R() * 1.4) * k)}" fill="${R() < 0.5 ? '#8a3a18' : '#b05a26'}" opacity="0.65"/>`; });
      // torn top of the charcoal sack + spilled briquettes
      { const t = p(40, 9.4, -16); f += `<path d="M${f1(t[0] - 4.4 * k)} ${f1(t[1])}l${f1(1.2 * k)} ${f1(-1.6 * k)}l${f1(1 * k)} ${f1(1 * k)}l${f1(1.4 * k)} ${f1(-1.8 * k)}l${f1(1.6 * k)} ${f1(1.4 * k)}l${f1(1.2 * k)} ${f1(-1 * k)}l${f1(0.8 * k)} ${f1(2 * k)}Z" fill="#c8a47a"/><ellipse cx="${f1(t[0])}" cy="${f1(t[1] + 0.4 * k)}" rx="${f1(3 * k)}" ry="${f1(1 * k)}" fill="#1e1c1a"/>`
        + `<path d="M${f1(t[0] - 3 * k)} ${f1(t[1] + 3 * k)}h${f1(5 * k)}M${f1(t[0] - 2 * k)} ${f1(t[1] + 4.4 * k)}h${f1(3 * k)}" stroke="#c83a1a" stroke-width="${f1(0.8 * k)}" opacity="0.7"/>`;
        rep(7, () => { const b = p(33 + R() * 10, 0.6, -6 + R() * 8); f += `<rect x="${f1(b[0] - 1.1 * k)}" y="${f1(b[1] - 0.8 * k)}" width="${f1(2.2 * k)}" height="${f1(1.6 * k)}" rx="${f1(0.6 * k)}" fill="#26241f" transform="rotate(${f1(R() * 60 - 30)} ${f1(b[0])} ${f1(b[1])})"/>`; }); }
      // rusty tongs dropped in front
      { const a = p(-20, 0.5, 22), b = p(4, 0.5, 23.4), b2 = p(4, 0.5, 21); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}M${H3.P2(a)}L${H3.P2(b2)}" stroke="#6a4a32" stroke-width="${f1(0.9 * k)}" stroke-linecap="round"/><path d="M${H3.P2(a)}L${H3.P2(p(-14, 0.5, 22.4))}" stroke="#1e1e22" stroke-width="${f1(1.6 * k)}" stroke-linecap="round"/>`; }
      return Object.assign({}, F, { under: (F.under || '') + un, front: (F.front || '') + f }); };
    return D; };

  // YRD-022 CLASSIC RED KETTLE CHARCOAL BBQ (T2): plus7 kettle kept (enamel bowl + lid, vent, thermometer, legs, wheels, tap to grill) + the cosy
  // backyard kit: a chimney starter on the ground by a leg, a grill brush and a spatula hanging off the handle hooks, a little grease drip on the bowl.
  N.ket32 = S => { const D = N.kettle(S), f0 = D.fx, BY = 40, BR = 27, RY = 58.8;
    D.build = (b0 => P => b0(P).concat([XK.cyl(30, 0, 18, 6, 15, '#9aa1ad', H3.mt({ n: 18, shine: 1, rg: [[0, 0, 1], [15, 0, 1]] })), XK.cyl(30, 15, 18, 6.2, 0.6, '#c9d0d6', H3.mt({ n: 18, shine: 1 }))]))(D.build);
    D.fx = c => { const F = f0(c) || {}, p = c.p, k = c.k; let f = '';
      // chimney-starter holes + handle
      { const q = p(30, 8, 24); f += rep(5, i => `<circle cx="${f1(q[0] - 4 * k + i * 2 * k)}" cy="${f1(q[1] - 2 * k + (i % 2) * 2 * k)}" r="${f1(0.6 * k)}" fill="#3a3c42"/>`).join('') + H7.tube([p(36, 12, 18), p(42, 12, 18), p(42, 6, 18)], 1.2, k, '#1e1e22', '#5a5e66'); }
      // tools hanging from the side handle: brush + spatula, swinging a little
      [[1.25, '#7a5a3a', 'brush'], [1.55, '#7a5a3a', 'spat']].forEach(([th, col, kind], i) => { const h = p((BR + 3) * Math.sin(th), RY - 4, (BR + 3) * Math.cos(th)), e = [h[0] + 0.6 * k, h[1] + 14 * k];
        let t = `<path d="M${f1(h[0])} ${f1(h[1])}L${f1(e[0])} ${f1(e[1] - 4 * k)}" stroke="${col}" stroke-width="${f1(1.2 * k)}" stroke-linecap="round"/><path d="M${f1(e[0])} ${f1(e[1] - 4 * k)}L${f1(e[0])} ${f1(e[1])}" stroke="#9aa1ad" stroke-width="${f1(0.6 * k)}"/>`;
        t += kind === 'brush' ? `<rect x="${f1(e[0] - 1.6 * k)}" y="${f1(e[1])}" width="${f1(3.2 * k)}" height="${f1(5 * k)}" rx="${f1(0.5 * k)}" fill="#3a3a40"/>${rep(5, m => `<path d="M${f1(e[0] - 1.4 * k + m * 0.7 * k)} ${f1(e[1] + 0.4 * k)}v${f1(4.2 * k)}" stroke="#c8b070" stroke-width="${f1(0.3 * k)}"/>`).join('')}` : `<rect x="${f1(e[0] - 2 * k)}" y="${f1(e[1])}" width="${f1(4 * k)}" height="${f1(5 * k)}" rx="${f1(0.6 * k)}" fill="#c9d0d6"/><path d="M${f1(e[0] - 1 * k)} ${f1(e[1] + 1 * k)}v${f1(3 * k)}M${f1(e[0] + 1 * k)} ${f1(e[1] + 1 * k)}v${f1(3 * k)}" stroke="#7a8088" stroke-width="${f1(0.3 * k)}"/>`;
        f += `<g transform="translate(${f1(h[0])} ${f1(h[1])})"><g>${H7.atV('rotate', ['-4', '4', '-4'], 3 + i)}<g transform="translate(${f1(-h[0])} ${f1(-h[1])})">${t}</g></g></g>`; });
      // a grease drip down the bowl
      { const a = p((BR + 0.4) * Math.sin(0.2), 52, (BR + 0.4) * Math.cos(0.2)); f += `<path d="M${H3.P2(a)}q${f1(0.4 * k)} ${f1(2 * k)} 0 ${f1(4 * k)}" stroke="#5a1410" stroke-width="${f1(0.8 * k)}" stroke-linecap="round" opacity="0.6"/>`; }
      return Object.assign({}, F, { front: (F.front || '') + f }); };
    return D; };

  // YRD-042 4-BURNER STAINLESS PROPANE GRILL & SMOKER (T3, new build; was the generic bbq box): a brushed stainless cart grill: two-door cabinet on
  // locking casters, a firebox with a domed hood (thermometer, tube handle), a slanted control panel with four black knobs + an igniter, a side
  // shelf with tools on hooks (spatula, tongs, brush) over a white propane tank, and a black steel offset smoker barrel on the left with a firebox
  // door, a chimney and a damper. Tap to grill: the hood swings open on steaks, corn and peppers on the grates, flames lick, the knobs glow, smoke
  // pours from the hood and the smoker chimney. Idle: a thin curl of smoke from the smoker.
  N.gas32 = S => { const lit = /play/.test(S.st || ''), SS = '#c9cdd2', SD = '#8a9098', BK = '#26272b', W2 = 25, Z2 = 18, YF = 46, { mt, pt, cer } = H3;
    const D = { w: 110, d: 60, glow: lit ? () => ({ y: 56, r: 50 }) : undefined };
    const HOOD = [[-Z2, YF + 10], [-Z2, YF + 15], [-14, YF + 22], [-6, YF + 25], [4, YF + 25], [12, YF + 22], [Z2, YF + 16], [Z2, YF + 10]];
    const openHood = HOOD.map(([z, y]) => { const dz = z + Z2, dy = y - (YF + 10), a = 1.75, c = Math.cos(a), s = Math.sin(a); return [-Z2 + dz * c - dy * s, YF + 10 + dz * s + dy * c]; });
    D.build = P => { const o = [];
      // casters + cabinet + firebox
      [[-W2 + 3, -Z2 + 3], [W2 - 3, -Z2 + 3], [-W2 + 3, Z2 - 3], [W2 - 3, Z2 - 3]].forEach(([x, z]) => o.push(XK.cyl(x, 0, z, 2.2, 3, BK, pt({ n: 10 }))));
      o.push(XK.box(0, 3, 0, 2 * W2, 33, 2 * Z2, SS, mt({ r: 0.8, shine: 1 })), XK.box(0, 36, 0, 2 * W2 + 1, 2, 2 * Z2 + 1, SD, mt({ r: 0.4 })), XK.box(0, 38, 0, 2 * W2, YF + 10 - 38, 2 * Z2, SS, mt({ r: 0.6, shine: 1 })));
      // control panel slant along the front
      o.push(XK.prism(-W2, W2, [[Z2, 38], [Z2 + 5, 40], [Z2 + 5, 46], [Z2, YF + 10]], '#b8bcc2', mt({ shine: 1 })));
      // side shelf (right) on two legs over the propane tank
      o.push(XK.box(W2 + 13, YF + 6, 0, 26, 1.6, 2 * Z2, SS, mt({ r: 0.6, shine: 1 })), XK.box(W2 + 24, 3, -Z2 + 3, 2, YF + 3, 2, SD, mt({})), XK.box(W2 + 24, 3, Z2 - 3, 2, YF + 3, 2, SD, mt({})),
        XK.cyl(W2 + 12, 3, 2, 7, 17, '#f2f2ee', cer({ n: 20, rg: [[0, 0, 0.9], [3, 0, 1], [14, 0, 1], [17, 0, 0.75]], shine: 1 })), XK.cyl(W2 + 12, 20, 2, 3.6, 3.6, '#e8e8e4', cer({ n: 14 })), XK.cyl(W2 + 12, 23.6, 2, 1.4, 1.6, '#c9a050', mt({ n: 10, shine: 1 })));
      // offset smoker: barrel on two legs, chimney
      o.push(XK.solid({ ax: 'x', sh: 'el', c: [0, YF + 4], a: 12, b: 12, n: 26, rings: [[-W2 - 30, 0], [-W2 - 1, 0]], col: BK, mat: 'metal', shine: 1 }),
        XK.box(-W2 - 24, 3, 0, 2, YF - 10, 2, BK, mt({})), XK.box(-W2 - 24, 3, 0, 2, 2, 22, BK, mt({})), XK.cyl(-W2 - 8, YF + 14, -6, 2.4, 22, BK, mt({ n: 12, shine: 1 })), XK.cyl(-W2 - 8, YF + 36, -6, 3.6, 1, BK, mt({ n: 12 })));
      if (!lit) o.push(XK.prism(-W2 - 0.5, W2 + 0.5, HOOD, SS, mt({ shine: 1 })));
      return o; };
    if (lit) D.layers = [{ build: P => [XK.prism(-W2 - 0.5, W2 + 0.5, openHood, SS, mt({ shine: 1 }))] }];
    D.fx = c => { const p = c.p, k = c.k, R = rng('gas32'); let f = '', bk = '', un = '';
      // cabinet doors, handles, vent slots, caster brakes
      { const fz = Z2 + 0.1; f += `<path d="${H7.quad(p, [-W2 + 2, 6, fz], [-0.6, 6, fz], [-0.6, 34, fz], [-W2 + 2, 34, fz])}" fill="none" stroke="${SD}" stroke-width="${f1(0.5 * k)}"/><path d="${H7.quad(p, [0.6, 6, fz], [W2 - 2, 6, fz], [W2 - 2, 34, fz], [0.6, 34, fz])}" fill="none" stroke="${SD}" stroke-width="${f1(0.5 * k)}"/>`
        + H7.tube([p(-4, 14, fz + 1.4), p(-4, 28, fz + 1.4)], 1.1, k, '#e2e6ea', '#ffffff', '#6a7078') + H7.tube([p(4, 14, fz + 1.4), p(4, 28, fz + 1.4)], 1.1, k, '#e2e6ea', '#ffffff', '#6a7078')
        + rep(6, i => `<path d="M${H3.P2(p(-W2 + 6 + i * 3, 8, fz))}L${H3.P2(p(-W2 + 6 + i * 3, 11, fz))}" stroke="#5a6068" stroke-width="${f1(0.6 * k)}"/>`).join(''); }
      // control knobs + igniter on the slanted panel
      rep(4, i => { const q = p(-18 + i * 12, 43, Z2 + 5.4); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(2.6 * k)}" ry="${f1(2.2 * k)}" fill="#c9cdd2"/><ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(2 * k)}" ry="${f1(1.7 * k)}" fill="#1a1a1d"/><path d="M${f1(q[0])} ${f1(q[1] - 1.5 * k)}v${f1(1.2 * k)}" stroke="#e8e8ec" stroke-width="${f1(0.4 * k)}"/>`
        + (lit ? `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(2.8 * k)}" ry="${f1(2.4 * k)}" fill="none" stroke="#ff8a2a" stroke-width="${f1(0.4 * k)}" opacity="0.8">${H3.an('opacity', '0.5;1;0.5', 1.6 + i * 0.2)}</ellipse>` : ''); });
      { const q = p(22, 43, Z2 + 5.4); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.2 * k)}" fill="#c8202a"/>`; }
      // smoker: firebox door, damper wheel, rivets; ash under it
      { const dq = p(-W2 - 30.2, YF + 4, 0); f += `<ellipse cx="${f1(dq[0])}" cy="${f1(dq[1])}" rx="${f1(5 * k)}" ry="${f1(9 * k)}" fill="#1a1a1d" stroke="#4a4c52" stroke-width="${f1(0.4 * k)}"/><circle cx="${f1(dq[0])}" cy="${f1(dq[1])}" r="${f1(2.4 * k)}" fill="none" stroke="#8a8e96" stroke-width="${f1(0.6 * k)}"/>`
        + rep(5, i => { const a = i / 5 * 2 * PI; return `<path d="M${f1(dq[0])} ${f1(dq[1])}l${f1(Math.cos(a) * 2.2 * k * 0.55)} ${f1(Math.sin(a) * 2.2 * k)}" stroke="#8a8e96" stroke-width="${f1(0.3 * k)}"/>`; }).join('')
        + H7.tube([p(-W2 - 18, YF + 14, 12.4), p(-W2 - 12, YF + 14, 12.4)], 1, k, '#9aa1ad', '#ffffff', '#3a3c42')
        + rep(8, i => { const q = p(-W2 - 28 + i * 3.6, YF + 4 - 1, 12.1); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.4 * k)}" fill="#5a5c62"/>`; }).join(''); }
      // hood details when closed: thermometer + handle bar; tools on the shelf hooks
      if (!lit) { const tq = p(0, YF + 22, 12); f += `<ellipse cx="${f1(tq[0])}" cy="${f1(tq[1])}" rx="${f1(3 * k)}" ry="${f1(2.4 * k)}" fill="#e2e6ea" stroke="#6a7078" stroke-width="${f1(0.3 * k)}"/><ellipse cx="${f1(tq[0])}" cy="${f1(tq[1])}" rx="${f1(2.3 * k)}" ry="${f1(1.8 * k)}" fill="#fbfaf4"/><path d="M${H3.P2(tq)}l${f1(1.4 * k)} ${f1(-0.9 * k)}" stroke="#c8202a" stroke-width="${f1(0.4 * k)}"/>`
        + H7.tube([p(-W2 + 4, YF + 18, Z2 + 3.4), p(W2 - 4, YF + 18, Z2 + 3.4)], 1.4, k, '#e2e6ea', '#ffffff', '#5a6068'); }
      [['spat', W2 + 6], ['tong', W2 + 12], ['brush', W2 + 18]].forEach(([kd, x], i) => { const h = p(x, YF + 6, Z2 + 0.4), e = [h[0], h[1] + 12 * k];
        let t = `<path d="M${H3.P2(h)}L${f1(e[0])} ${f1(e[1] - 3 * k)}" stroke="${kd === 'tong' ? '#c9cdd2' : '#1a1a1d'}" stroke-width="${f1(1 * k)}"/>`;
        t += kd === 'spat' ? `<rect x="${f1(e[0] - 2 * k)}" y="${f1(e[1] - 3 * k)}" width="${f1(4 * k)}" height="${f1(4.6 * k)}" rx="${f1(0.5 * k)}" fill="#d8dce0"/>` : kd === 'tong' ? `<path d="M${f1(e[0])} ${f1(e[1] - 3 * k)}l${f1(-1.2 * k)} ${f1(5 * k)}M${f1(e[0])} ${f1(e[1] - 3 * k)}l${f1(1.2 * k)} ${f1(5 * k)}" stroke="#c9cdd2" stroke-width="${f1(0.6 * k)}"/>` : `<rect x="${f1(e[0] - 1.4 * k)}" y="${f1(e[1] - 3 * k)}" width="${f1(2.8 * k)}" height="${f1(4.6 * k)}" fill="#3a3a40"/><path d="M${f1(e[0] - 1.2 * k)} ${f1(e[1] - 2 * k)}h${f1(2.4 * k)}M${f1(e[0] - 1.2 * k)} ${f1(e[1])}h${f1(2.4 * k)}" stroke="#c8b070" stroke-width="${f1(0.5 * k)}"/>`;
        f += `<g transform="translate(${H3.P2(h)})"><g>${H7.atV('rotate', ['-3', '3', '-3'], 3 + i * 0.6)}<g transform="translate(${f1(-h[0])} ${f1(-h[1])})">${t}</g></g></g>`; });
      // grates + food + fire when grilling
      if (lit) { let ins = `<g transform="${H3.planeH(p, YF + 10.2)}"><rect x="${-W2 + 1}" y="${-Z2 + 1}" width="${2 * W2 - 2}" height="${2 * Z2 - 2}" fill="#141416"/>` + rep(16, i => `<path d="M${-W2 + 2} ${f1(-Z2 + 2 + i * 2.1)}H${W2 - 2}" stroke="#4a4c52" stroke-width="1.1"/><path d="M${-W2 + 2} ${f1(-Z2 + 1.6 + i * 2.1)}H${W2 - 2}" stroke="#9aa1ad" stroke-width="0.4"/>`).join('');
        const steak = (x, z, a) => `<g transform="translate(${x} ${z}) rotate(${a})"><path d="M-7 -4Q-2 -7 5 -4Q8 0 5 4Q-2 7 -7 3Q-9 0 -7 -4Z" fill="#5a2414"/><path d="M-6 -3Q-2 -5.6 4 -3Q6.6 0 4 3Q-2 5.4 -6 2.4Q-7.6 0 -6 -3Z" fill="#8a3a22"/>${[-3, 0, 3].map(d => `<path d="M${d - 2} -3.6L${d + 2} 3.6" stroke="#2a0e06" stroke-width="0.9"/>`).join('')}<path d="M-6 -2.6Q-7 0 -5.6 2" stroke="#f2e8d0" stroke-width="0.8" fill="none"/></g>`;
        const corn = (x, z, a) => `<g transform="translate(${x} ${z}) rotate(${a})"><rect x="-7" y="-2.2" width="14" height="4.4" rx="2.2" fill="#f2c14a"/>${rep(12, i => `<circle cx="${-6 + i * 1.1}" cy="${i % 2 ? -1 : 1}" r="0.5" fill="#c88a1a"/>`).join('')}<path d="M-5 -2L-5 2M0 -2.2L0 2.2M4 -2L4 2" stroke="#3a2010" stroke-width="0.7"/></g>`;
        const pep = (x, z, col) => `<g transform="translate(${x} ${z})"><ellipse rx="3.4" ry="3" fill="${col}"/><ellipse cx="-1" cy="-1" rx="1.2" ry="0.8" fill="#ffffff" opacity="0.35"/><path d="M-2.4 -1L2.4 1" stroke="#2a0e06" stroke-width="0.7"/><rect x="-0.4" y="-4" width="0.8" height="1.6" fill="#4a7a2a"/></g>`;
        ins += steak(-12, -6, 10) + steak(6, -8, -14) + corn(-8, 8, 4) + corn(12, 6, -6) + pep(18, -10, '#c8202a') + pep(-20, 6, '#e8b020') + pep(0, 2, '#4a8a2a') + '</g>';
        f += ins + H7.smoke(p(0, YF + 14, 0), k, { seed: 'gs32', n: 7, H: 70, col: '#d4cfc8', op: 0.4, d: 5, r1: 16, drift: 18 }) + H7.flames(p(-10, YF + 10, 14), k * 0.5, { seed: 'gf1', n: 3, sp: 4, h: 8, emb: 2 }) + H7.flames(p(12, YF + 10, 12), k * 0.5, { seed: 'gf2', n: 3, sp: 4, h: 8, emb: 2 });
        un += H7.glowE(p, 0, 0, 0, 40, 30, '#ff8a3a', 0.18, 1); }
      f += H7.smoke(p(-W2 - 8, YF + 37, -6), k, { seed: 'gsm', n: lit ? 6 : 3, H: lit ? 60 : 34, col: '#cfc8c0', op: lit ? 0.4 : 0.22, d: 6, r1: lit ? 12 : 7, drift: 14 });
      return { defs: H7.FDEF || '', back: bk, under: un, front: f, bb: H3.bbOf([p(-58, 0, -24), p(52, 0, 24), p(-58, 0, 24), p(52, 0, -24), p(0, lit ? 140 : 100, 0), p(-W2 - 8, YF + 80, -6), p(0, YF + 40, -Z2 - 20)], 4) }; };
    return D; };

  // YRD-063 ARCHITECTURAL BRASS UPLIGHTS FOR TREES & PATHWAYS (T4, new build; was the generic solar row, same 140 x 30 + glow): a planted strip in
  // grey river-pebble mulch with a steel edge: a slim Japanese maple (red leaves) and two clipped boxwood balls, each lit from below by a polished brass
  // bullet uplight with a glare snoot on a knuckle stake, plus two short brass louvred path bollards throwing pools of light on the pebbles.
  // Live: the warm beams breathe, glints slide on the brass, the maple leaves sway.
  N.uplit32 = S => { const D = { w: 140, d: 30, glow: () => ({ y: 30, r: 90 }) }, { mt, pt, wd } = H3, BR = '#c9a050';
    D.build = P => [XK.box(0, 0, 0, 136, 1.2, 26, '#8a8a84', pt({ r: 0.6 })), XK.box(0, 0, 13.2, 136, 2, 0.6, '#3a3c40', mt({})), XK.box(0, 0, -13.2, 136, 2, 0.6, '#3a3c40', mt({})),
      XK.ball(-40, 9, -2, 9, '#3e6a2e', pt({ k: 6, n: 16, soft: 1, sy: 0.92 })), XK.ball(40, 9, -2, 9, '#3a6430', pt({ k: 6, n: 16, soft: 1, sy: 0.92 })),
      XK.cyl(-62, 1.2, 6, 1.8, 11, BR, mt({ n: 12, shine: 1 })), XK.cyl(-62, 12.2, 6, 2.4, 1.4, BR, mt({ n: 12, shine: 1 })), XK.cyl(62, 1.2, 6, 1.8, 11, BR, mt({ n: 12, shine: 1 })), XK.cyl(62, 12.2, 6, 2.4, 1.4, BR, mt({ n: 12, shine: 1 }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('upl32'); let f = '', un = '', bm = '';
      // pebble mulch
      un += rep(160, () => { const q = p((R() - 0.5) * 132, 1.25, (R() - 0.5) * 24), r = (0.5 + R() * 0.7) * k; return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(r)}" ry="${f1(r * 0.55)}" fill="${['#a8a49a', '#8a8680', '#c4c0b6', '#6e6a64'][Math.floor(R() * 4)]}"/>`; }).join('');
      // maple: thin trunks + layered red leaf clouds
      { let tr = ''; [[-2, 0], [2, 1], [0, -2]].forEach(([dx, dz], i) => { tr += H7.tube([p(dx, 1.2, dz), p(dx * 2, 22, dz), p(dx * 4 + (i - 1) * 4, 38, dz)], 1.1, k, '#5a3a2a', '#8a6a4a', '#2a1a10'); });
        const LV = ['', '', '']; rep(380, () => { const a = R() * 2 * PI, r = Math.sqrt(R()), q = p(Math.cos(a) * r * 20, 30 + R() * 16 - r * 6, Math.sin(a) * r * 10); LV[Math.floor(R() * 3)] += leafD(IVY, q[0], q[1], 1.15 * k, R() * 360, 1); });
        f += `<g>${H7.atV('rotate', ['-1.2 ' + H3.P2(p(0, 1, 0)), '1.2 ' + H3.P2(p(0, 1, 0)), '-1.2 ' + H3.P2(p(0, 1, 0))], 6)}${tr}<path d="${LV[0]}" fill="#8a1e1a"/><path d="${LV[1]}" fill="#b8321e"/><path d="${LV[2]}" fill="#e05a2a"/></g>`; }
      // boxwood: small-leaf texture over the clipped balls, lit warm from below
      [-40, 40].forEach(x => { const LB = ['', '']; const q0 = p(x, 9, -2); rep(170, () => { const a = R() * 2 * PI, r = Math.sqrt(R()) * 8.4 * k, q = [q0[0] + Math.cos(a) * r, q0[1] + Math.sin(a) * r * 0.92]; LB[Math.sin(a) > 0.2 ? 0 : 1] += leafD(OVAL, q[0], q[1], 0.42 * k, R() * 360, 1); }); f += `<path d="${LB[0]}" fill="#4e8a3a"/><path d="${LB[1]}" fill="#9ab85a"/>`; });
      // brass bullet uplights aiming up at each plant, with warm beams
      [[-40, 9], [0, 10], [40, 9]].forEach(([x, zz], i) => { const b = p(x + 4, 1.2, zz), h = p(x + 3, 4.6, zz - 1), tip = p(x + 1.6, 7.4, zz - 2.4);
        bm += `<path d="M${f1(h[0] - 2 * k)} ${f1(h[1])}L${f1(h[0] - 14 * k)} ${f1(h[1] - 52 * k)}L${f1(h[0] + 14 * k)} ${f1(h[1] - 52 * k)}L${f1(h[0] + 2 * k)} ${f1(h[1])}Z" fill="url(#up32b)" style="mix-blend-mode:screen">${an('opacity', '0.75;1;0.75', 5 + i, -i, SPL(2))}</path>`;
        f += H7.tube([b, h], 0.7, k, '#8a6a30', '#f0d08a', '#3a2a10') + H7.tube([h, tip], 2.4, k, BR, '#fff0c0', '#5a4010') + `<ellipse cx="${f1(tip[0])}" cy="${f1(tip[1])}" rx="${f1(1.5 * k)}" ry="${f1(0.9 * k)}" fill="#fff4d0"/><circle cx="${f1(h[0])}" cy="${f1(h[1])}" r="${f1(0.8 * k)}" fill="#7a5a20"/>`
          + `<path d="M${f1(h[0] - 1 * k)} ${f1(h[1] - 0.6 * k)}l${f1(1.2 * k)} ${f1(-2 * k)}" stroke="#ffffff" stroke-width="${f1(0.4 * k)}" opacity="0">${H3.an('opacity', '0;0.9;0', 4, -i * 1.3)}</path>`; });
      // bollard louvres + light pools
      [-62, 62].forEach(x => { const q = p(x, 10, 6), g = p(x, 1.3, 6); f += rep(3, m => `<path d="M${f1(q[0] - 1.8 * k)} ${f1(q[1] - m * 1.1 * k)}h${f1(3.6 * k)}" stroke="#5a4010" stroke-width="${f1(0.4 * k)}"/>`).join('') + `<rect x="${f1(q[0] - 1.6 * k)}" y="${f1(q[1] - 2.8 * k)}" width="${f1(3.2 * k)}" height="${f1(2.4 * k)}" fill="#ffe2a0" opacity="0.9"/>`;
        un += `<ellipse cx="${f1(g[0])}" cy="${f1(g[1])}" rx="${f1(12 * k)}" ry="${f1(5 * k)}" fill="#ffd890" opacity="0.4" filter="url(#f7s)"/>`; });
      return { defs: (H7.FDEF || '') + '<linearGradient id="up32b" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffe0a0" stop-opacity="0.75"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></linearGradient>', under: un, front: f + bm, bb: H3.bbOf([p(-70, 0, -15), p(70, 0, 15), p(-70, 0, 15), p(70, 0, -15), p(0, 60, 0), p(-40, 60, 0), p(40, 60, 0)], 4) }; };
    return D; };

  // YRD-083 FIREFLY-SWARM MICRO-DRONE AMBIENT LIGHT CHOREOGRAPHY (T5, plus9 drones8 rebuilt, same 80 x 80 + glow): a sculptural docking plinth of black
  // marble with a polished brass band and a frosted glass cap ringed by a soft light; 21 tiny glass-orb drones in three layers fly slow figure-eight
  // loops, each a warm firefly glow (gold, pale lime, warm white) that blinks out of step and trails three fading ghosts; warm light pools on the lawn.
  N.fly32 = S => { const D = { w: 80, d: 80, round: 1, glow: () => ({ y: 30, r: 60 }) }, { mt, cer, pt } = H3;
    D.build = P => [XK.cyl(0, 0, 0, 13, 2, '#1e1e22', cer({ n: 28, shine: 1 })), XK.cyl(0, 2, 0, 11, 7, '#26262c', cer({ n: 26, shine: 1, rg: [[0, 0, 1], [7, 0, 0.86]] })), XK.cyl(0, 6, 0, 10.6, 1, '#c9a050', mt({ n: 26, shine: 1 })), XK.cyl(0, 9, 0, 8, 2.4, '#e8eef0', cer({ n: 24, op: 0.75, rg: [[0, 0, 1], [2.4, 0, 0.6]] }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('fly32'); let f = '', un = '';
      un += H7.glowE(p, 0, 0, 0, 40, 40, '#ffd890', 0.16);
      f += `<ellipse cx="${f1(p(0, 11.4, 0)[0])}" cy="${f1(p(0, 11.4, 0)[1])}" rx="${f1(7 * k)}" ry="${f1(3.4 * k)}" fill="none" stroke="#ffe8a8" stroke-width="${f1(0.7 * k)}">${H3.an('opacity', '0.4;1;0.4', 3)}</ellipse>`;
      const COL = ['#ffd860', '#d8ff8a', '#fff4d8'];
      rep(21, i => { const g = i % 3, cy = 32 + g * 11, ph = i / 21 * 2 * PI, rr = 17 + g * 8, d = 11 + g * 3;
        const pts = rep(31, j => { const t = j / 30 * 2 * PI; return p(Math.cos(t + ph) * rr, cy + Math.sin(2 * t + ph) * (6 + g * 2) + Math.sin(t * 3) * 2, Math.sin(t + ph) * rr * 0.9 * (g === 1 ? -1 : 1)); });
        const pth = 'M' + pts.map(H3.P2).join('L') + 'Z', col = COL[g], bt = 1.4 + R() * 2.2, bb = -R() * bt;
        const body = (sc, op) => `<g opacity="${op}"><circle r="${f1(6 * k * sc)}" fill="${col}" opacity="0.4" filter="url(#f7b)"/><circle r="${f1(2 * k * sc)}" fill="${col}"/><circle r="${f1(0.9 * k * sc)}" fill="#ffffff"/></g>`;
        rep(3, m => { f += `<g>${`<animateMotion dur="${d}s" begin="${n4(-i * d / 21 + (m + 1) * 0.18)}s" repeatCount="indefinite" path="${pth}"/>`}${body(0.75 - m * 0.18, n4(0.45 - m * 0.13))}</g>`; });
        f += `<g>${`<animateMotion dur="${d}s" begin="${n4(-i * d / 21)}s" repeatCount="indefinite" path="${pth}"/>`}<g>${an('opacity', '0.35;1;1;0.35', bt, bb, ' keyTimes="0;0.2;0.6;1"')}${body(1, 1)}</g><g transform="scale(${n4(k)})"><circle r="1" fill="#f4f8fa" opacity="0.55"/><ellipse cy="-1.1" rx="2.2" ry="0.35" fill="#c8ccd2" opacity="0.4">${H3.an('rx', '2.2;1.2;2.2', 0.1)}</ellipse></g></g>`; });
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(-42, 0, -42), p(42, 0, 42), p(-42, 72, 0), p(42, 72, 0), p(0, 80, 0)], 4) }; };
    return D; };

  // YRD-062 BUILT-IN STONE OUTDOOR KITCHEN WITH WOOD-FIRED PIZZA OVEN (T4, new build; was a generic island + ball): a stacked fieldstone island with a
  // thick honed quartzite counter, a stainless built-in grill with its hood, two stainless access doors and a herb board (tomatoes, basil, olive oil);
  // on the right a domed terracotta-stucco pizza oven on a stone base with a brick-arched mouth, an iron door leaning by it, a black flue, and a log
  // store under it. Idle: embers glow low in the oven. Tap (play 'grill'): flames roar, a pizza bakes in the mouth, smoke rises from the flue and the grill.
  N.kitch32 = S => { const lit = /play/.test(S.st || ''), D = { w: 110, d: 60, glow: () => ({ y: 30, r: lit ? 60 : 30 }) }, { mt, pt, cer, wd } = H3, X0 = -52, X1 = 18, OX = 36, Z2 = 20, HC = 34;
    D.build = P => [XK.box((X0 + X1) / 2, 0, 0, X1 - X0, HC, 2 * Z2, '#a89c88', pt({ r: 0.6 })), XK.box((X0 + X1) / 2, HC, 0.6, X1 - X0 + 3, 3.4, 2 * Z2 + 3, '#e6dccb', cer({ r: 0.8, shine: 1 })),
      XK.box(-28, HC + 3.4, -1, 28, 1.4, 24, '#9aa1ad', mt({ r: 0.4, shine: 1 })), XK.prism(-42, -14, [[-13, HC + 4.8], [-13, HC + 9], [-8, HC + 13], [2, HC + 13.6], [8, HC + 11], [11, HC + 6.4], [11, HC + 4.8]], '#c9cdd2', mt({ shine: 1 })),
      XK.box(OX, 0, 0, 36, HC + 3.4, 2 * Z2, '#a89c88', pt({ r: 0.6 })), XK.box(OX, HC + 3.4, 0, 37, 1.6, 2 * Z2 + 2, '#e6dccb', cer({ r: 0.6 })),
      XK.cyl(OX, HC + 5, -1, 16, 20, '#c8764a', cer({ n: 32, rg: [[0, 0, 1], [5, 0, 0.97], [10, 0, 0.86], [14, 0, 0.68], [17, 0, 0.44], [20, 0, 0.12]] })),
      XK.cyl(OX + 4, HC + 20, -8, 2.4, 18, '#1e1e22', mt({ n: 12, shine: 1 })), XK.cyl(OX + 4, HC + 38, -8, 3.6, 1.2, '#1e1e22', mt({ n: 12 })),
      XK.box(6, HC + 3.4, 10, 12, 0.8, 8, '#b8865a', wd({ r: 0.4 })), XK.cyl(13, HC + 3.4, -8, 1.6, 7, '#6a7a2a', cer({ n: 12, op: 0.85 })), XK.cyl(13, HC + 10.4, -8, 0.6, 1.6, '#2a2a2e', mt({ n: 8 }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('kit32'); let f = '', un = '';
      // fieldstone veneer on the front + right faces (irregular stones, mortar between)
      const stones = (face) => { let s = ''; for (let y = 0.6; y < (face === 'ov' ? HC + 2.6 : HC - 0.4); y += 4.2) { let x = (face === 'ov' ? OX - 18 : X0) + (R() * 3); const xe = face === 'ov' ? OX + 18 : X1; while (x < xe - 1) { const w = 4 + R() * 6, h = 3 + R() * 1.2, x2 = Math.min(xe - 0.4, x + w), col = ['#b8ac96', '#a69a84', '#c6baa4', '#9a8e7a', '#b0a08a'][Math.floor(R() * 5)];
          s += `<path d="${H7.quad(p, [x + 0.3, y, Z2 + 0.1], [x2 - 0.3, y + (R() - 0.5) * 0.6, Z2 + 0.1], [x2 - 0.3, y + h, Z2 + 0.1], [x + 0.3, y + h + (R() - 0.5) * 0.6, Z2 + 0.1])}" fill="${col}"/>`; x = x2; } } return s; };
      f += `<path d="${H7.quad(p, [X0, 0, Z2 + 0.05], [X1, 0, Z2 + 0.05], [X1, HC, Z2 + 0.05], [X0, HC, Z2 + 0.05])}" fill="#6e665a"/>` + stones('is');
      f += `<path d="${H7.quad(p, [OX - 18, 0, Z2 + 0.05], [OX + 18, 0, Z2 + 0.05], [OX + 18, HC + 3.4, Z2 + 0.05], [OX - 18, HC + 3.4, Z2 + 0.05])}" fill="#6e665a"/>` + stones('ov');
      // stainless access doors + handles on the island
      [[-46, -30], [-26, -10]].forEach(([a, b]) => { f += `<path d="${H7.quad(p, [a, 6, Z2 + 0.3], [b, 6, Z2 + 0.3], [b, 28, Z2 + 0.3], [a, 28, Z2 + 0.3])}" fill="#c9cdd2" stroke="#7a8088" stroke-width="${f1(0.4 * k)}"/>` + H7.tube([p(a + 3, 24, Z2 + 1), p(b - 3, 24, Z2 + 1)], 0.9, k, '#e2e6ea', '#ffffff', '#5a6068'); });
      // log store under the oven: dark niche with stacked log ends
      { f += `<path d="${H7.quad(p, [OX - 12, 3, Z2 + 0.2], [OX + 12, 3, Z2 + 0.2], [OX + 12, 20, Z2 + 0.2], [OX - 12, 20, Z2 + 0.2])}" fill="#2a2018"/>`;
        rep(3, r => rep(5 - (r % 2), m => { const q = p(OX - 9.6 + m * 4.8 + (r % 2) * 2.4, 5.4 + r * 4.4, Z2 + 0.4); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(2.1 * k)}" fill="#8a5a34"/><circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.4 * k)}" fill="#c8a070"/><circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.6 * k)}" fill="none" stroke="#8a6040" stroke-width="${f1(0.2 * k)}"/>`; })); }
      // oven mouth: brick arch, dark interior, fire / embers, pizza when lit
      { const zz = 13.8, ar = t => [OX + Math.cos(t) * 7, HC + 5 + Math.sin(t) * 8, zz]; let arch = `M${H3.P2(p(OX - 7, HC + 5, zz))}`; for (let i = 0; i <= 16; i++) arch += 'L' + H3.P2(p(...ar(PI - i / 16 * PI))); arch += 'Z';
        f += rep(9, i => { const t0 = PI - i / 9 * PI, t1 = PI - (i + 1) / 9 * PI, a = (t, r) => p(OX + Math.cos(t) * r, HC + 5 + Math.sin(t) * (r + 1), zz + 0.3); return `<path d="M${H3.P2(a(t0, 7.2))}L${H3.P2(a(t0, 10))}L${H3.P2(a(t1, 10))}L${H3.P2(a(t1, 7.2))}Z" fill="${i % 2 ? '#a8462a' : '#8a3a22'}" stroke="#d8c8b0" stroke-width="${f1(0.3 * k)}"/>`; }).join('');
        f += `<path d="${arch}" fill="#1a0e08"/><clipPath id="kt32m"><path d="${arch}"/></clipPath><g clip-path="url(#kt32m)">`;
        const fq = p(OX, HC + 5.2, zz - 6); f += `<ellipse cx="${f1(fq[0])}" cy="${f1(fq[1])}" rx="${f1(8 * k)}" ry="${f1(3 * k)}" fill="#ff6a1a" opacity="${lit ? 0.9 : 0.5}">${H3.an('opacity', lit ? '0.7;1;0.8' : '0.35;0.6;0.4', lit ? 0.8 : 2.4)}</ellipse>`;
        if (lit) f += H7.flames(p(OX - 2, HC + 5.4, zz - 7), k * 0.55, { seed: 'kt32f', n: 4, sp: 3, h: 9, emb: 3 }) + `<g transform="${H3.planeH(p, HC + 5.6, OX + 1, zz - 2)}"><circle r="5" fill="#e8c27a"/><circle r="4.2" fill="#d8402a"/>${rep(6, m => `<circle cx="${f1(Math.cos(m) * 2.4)}" cy="${f1(Math.sin(m) * 2.4)}" r="0.8" fill="#f4ecd8"/>`).join('')}${rep(4, m => `<ellipse cx="${f1(Math.cos(m * 1.7 + 0.5) * 1.6)}" cy="${f1(Math.sin(m * 1.7 + 0.5) * 1.6)}" rx="0.9" ry="0.5" fill="#3a7a2a"/>`).join('')}</g>`;
        f += '</g>'; un += H7.glowE(p, OX, 0, Z2, 24, 14, '#ff9a4a', lit ? 0.3 : 0.12, 1); }
      // iron oven door leaning against the base
      { const a = p(OX + 18.6, 0.4, 10), b = p(OX + 18.6, 13, 6); f += `<path d="M${f1(a[0] - 6 * k)} ${f1(a[1])}L${f1(b[0] - 5 * k)} ${f1(b[1])}Q${f1(b[0])} ${f1(b[1] - 4 * k)} ${f1(b[0] + 5 * k)} ${f1(b[1])}L${f1(a[0] + 6 * k)} ${f1(a[1])}Z" fill="#26262a"/>` + H7.tube([p(OX + 18.6, 8, 9), p(OX + 18.6, 8, 5)], 0.7, k, '#c9a050', '#fff0c0', '#5a4010'); }
      // herb board: tomatoes, basil leaves; pizza peel leaning on the oven base
      { const g = (x, z) => p(x, HC + 4.4, z); [[4, 9], [6.4, 11], [8.6, 9.4]].forEach(([x, z]) => { const q = g(x, z); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1] - 1 * k)}" r="${f1(1.3 * k)}" fill="#d8321e"/><circle cx="${f1(q[0] - 0.4 * k)}" cy="${f1(q[1] - 1.4 * k)}" r="${f1(0.4 * k)}" fill="#ffffff" opacity="0.5"/>`; });
        rep(5, m => { const q = g(9 + m * 0.8, 12 - m * 0.6); f += `<path d="${leafD(OVAL, q[0], q[1], 0.7 * k, m * 50, 1)}" fill="#3e8a2e"/>`; });
        const a = p(OX - 20, 0.4, Z2 + 3), b = p(OX - 17, 24, Z2 + 1); f += H7.tube([a, b], 0.9, k, '#b8865a', '#e8c090', '#5a3a1a') + `<ellipse cx="${f1(b[0] + 0.6 * k)}" cy="${f1(b[1] - 6 * k)}" rx="${f1(5 * k)}" ry="${f1(7 * k)}" fill="#c89a6a" stroke="#8a6040" stroke-width="${f1(0.3 * k)}"/>`; }
      // grill hood handle + temperature dial
      f += H7.tube([p(-38, HC + 8, 11.6), p(-18, HC + 8, 11.6)], 1, k, '#e2e6ea', '#ffffff', '#5a6068');
      // smoke: thin from the flue when idle, full when lit; grill sizzle when lit
      f += H7.smoke(p(OX + 4, HC + 40, -8), k, { seed: 'kt32s', n: lit ? 6 : 3, H: lit ? 60 : 30, col: '#d4cfc8', op: lit ? 0.42 : 0.2, d: 6, r1: lit ? 12 : 6, drift: 16 });
      if (lit) f += H7.smoke(p(-28, HC + 14, 0), k, { seed: 'kt32g', n: 4, H: 40, col: '#d4cfc8', op: 0.3, d: 5, r1: 10, drift: 14 });
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(-56, 0, -24), p(56, 0, 24), p(-56, 0, 24), p(56, 0, -24), p(OX + 4, HC + 40 + (lit ? 60 : 30), -8), p(-28, HC + 30, 0)], 4) }; };
    return D; };

  // ======================= GARDEN STRUCTURES (sheds) =======================
  // face helpers: quads on a constant-z (front) or constant-x (side) plane, front roof slope point (x, t: 0 eave .. 1 ridge)
  const QZ = (p, z, x0, x1, y0, y1) => H7.quad(p, [x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z]);
  const QX = (p, x, z0, z1, y0, y1) => H7.quad(p, [x, y0, z0], [x, y0, z1], [x, y1, z1], [x, y1, z0]);
  const gableTop = (z, Dz, H, YR) => H + (YR - H) * (1 - Math.abs(z) / Dz);

  // YRD-012 RUSTED CORRUGATED TIN TOOL SHED (T1, back to the CSV name; plus8 had made it a modern cedar shed): a small galvanised corrugated shed gone
  // dull and rusty, gable tin roof with rust runs and one lifted corner sheet, a dented front panel, a tin door hanging ajar on a dark inside with tool
  // handles, an open padlock dangling from the hasp, a loose lower sheet on the side, a rake leaning, weeds round the base. Live: the loose sheet and
  // the lifted roof corner rattle in the wind, the padlock swings.
  N.tin32 = S => { const W = 32, Dz = 22, H = 46, YR = 58, TIN = '#a4a8a6', RF = '#8c7660', D = { w: 110, d: 80 }, { mt, pt, wd } = H3;
    D.build = P => [XK.box(0, 0, 0, 2 * W, H, 2 * Dz, TIN, mt({ r: 0.2 })), XK.prism(-W, W, [[-Dz, H], [0, YR], [Dz, H]], TIN, mt({})),
      XK.prism(-W - 3, W + 3, [[Dz + 4, H - 1.6], [0, YR + 0.4], [0, YR + 2.2], [Dz + 4, H + 0.2]], RF, mt({})), XK.prism(-W - 3, W + 3, [[-Dz - 4, H - 1.6], [0, YR + 0.4], [0, YR + 2.2], [-Dz - 4, H + 0.2]], RF, mt({}))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('tin32'); let f = '', un = '', fl = '';
      un += `<ellipse cx="${f1(p(4, 0, 6)[0])}" cy="${f1(p(4, 0, 6)[1])}" rx="${f1(50 * k)}" ry="${f1(24 * k)}" fill="#3a2c1c" opacity="0.25" filter="url(#f7s)"/>`;
      // corrugation: front wall, side gable end, front roof slope
      let cz = ''; for (let x = -W; x < W - 0.1; x += 2.4) cz += `<path d="${QZ(p, Dz + 0.05, x, x + 1.1, 0, H)}" fill="#ffffff" opacity="0.18"/><path d="${QZ(p, Dz + 0.05, x + 1.6, x + 2.2, 0, H)}" fill="#3a3c3e" opacity="0.18"/>`;
      for (let z = -Dz; z < Dz - 0.1; z += 2.4) { const t = Math.min(gableTop(z, Dz, H, YR), gableTop(z + 1.1, Dz, H, YR)); cz += `<path d="${QX(p, W + 0.05, z, z + 1.1, 0, t)}" fill="#ffffff" opacity="0.14"/><path d="${QX(p, W + 0.05, z + 1.6, z + 2.2, 0, Math.min(gableTop(z + 1.6, Dz, H, YR), gableTop(z + 2.2, Dz, H, YR)))}" fill="#2a2c2e" opacity="0.2"/>`; }
      const RFP = (x, t) => [x, H - 1.6 + (YR + 0.4 - H + 1.6) * t + 1.8, (Dz + 4) * (1 - t)];
      for (let x = -W - 3; x < W + 3; x += 2.6) cz += `<path d="M${H3.P2(p(...RFP(x, 0)))}L${H3.P2(p(...RFP(x, 1)))}" stroke="#5a4a3a" stroke-width="${f1(0.45 * k)}" opacity="0.6"/><path d="M${H3.P2(p(...RFP(x + 1, 0)))}L${H3.P2(p(...RFP(x + 1, 1)))}" stroke="#c8b8a0" stroke-width="${f1(0.35 * k)}" opacity="0.5"/>`;
      f += cz;
      // rust: blotches on walls + roof, runs from the roof edge
      rep(16, () => { const x = (R() - 0.5) * 2 * W, y = R() < 0.5 ? R() * 10 : H - 2 - R() * 8, q = p(x, y, Dz + 0.1); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((2 + R() * 4) * k)}" ry="${f1((1.4 + R() * 2.4) * k)}" fill="${R() < 0.5 ? '#8a4420' : '#a85a2a'}" opacity="0.55" filter="url(#f7b)"/>`; });
      rep(10, () => { const x = (R() - 0.5) * 2 * W, a = p(x, H - 0.5, Dz + 0.1), b = p(x + (R() - 0.5), H - 8 - R() * 14, Dz + 0.1); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}" stroke="#8a4420" stroke-width="${f1((0.6 + R() * 0.8) * k)}" opacity="0.45" stroke-linecap="round"/>`; });
      rep(8, () => { const z = (R() - 0.5) * 2 * Dz, q = p(W + 0.1, 4 + R() * 30, z); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((1.6 + R() * 3) * k)}" ry="${f1((1.6 + R() * 3) * k)}" fill="#8a4420" opacity="0.5" filter="url(#f7b)"/>`; });
      rep(12, () => { const q = p(...RFP((R() - 0.5) * 2 * W, R())); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((2 + R() * 5) * k)}" ry="${f1((1 + R() * 2) * k)}" fill="#7a3a18" opacity="0.5" filter="url(#f7b)"/>`; });
      // dent in the front panel
      { const q = p(-22, 20, Dz + 0.1); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(4 * k)}" ry="${f1(3 * k)}" fill="#3a3c3e" opacity="0.25" filter="url(#f7b)"/><path d="M${f1(q[0] - 3 * k)} ${f1(q[1] - 2 * k)}q${f1(3 * k)} ${f1(-1.6 * k)} ${f1(6 * k)} ${f1(0.6 * k)}" stroke="#ffffff" stroke-width="${f1(0.6 * k)}" fill="none" opacity="0.5"/>`; }
      // door ajar: dark gap with tool handles, door panel edge, hasp + swinging padlock
      f += `<path d="${QZ(p, Dz + 0.15, 8, 13, 0, 38)}" fill="#141210"/>` + H7.tube([p(10, 2, Dz - 2), p(11.5, 36, Dz - 2)], 0.8, k, '#8a6040', '#c8a070', '#3a2a1a') + H7.tube([p(12, 2, Dz - 3), p(12, 34, Dz - 3)], 0.7, k, '#6a5a40', '#a89070', '#2a2010');
      f += `<path d="${QZ(p, Dz + 0.2, -12, 8, 0, 38)}" fill="none" stroke="#6a6e70" stroke-width="${f1(0.8 * k)}"/><path d="${QZ(p, Dz + 0.25, -12, 8, 37, 38.6)}" fill="#7a7e80"/>`;
      { const hq = p(7, 22, Dz + 0.4); f += `<rect x="${f1(hq[0] - 1 * k)}" y="${f1(hq[1] - 2 * k)}" width="${f1(2 * k)}" height="${f1(4 * k)}" fill="#6a5a4a"/><g transform="translate(${f1(hq[0])} ${f1(hq[1] + 2 * k)})"><g>${H7.atV('rotate', ['-14', '12', '-14'], 2.4)}<path d="M${f1(-1 * k)} 0v${f1(1.4 * k)}a${f1(1 * k)} ${f1(1 * k)} 0 0 0 ${f1(2 * k)} 0" stroke="#9aa0a4" stroke-width="${f1(0.5 * k)}" fill="none"/><rect x="${f1(-1.5 * k)}" y="${f1(1.4 * k)}" width="${f1(3 * k)}" height="${f1(2.6 * k)}" rx="${f1(0.4 * k)}" fill="#a87a3a"/></g></g>`; }
      // loose lower sheet on the side + lifted roof corner, rattling
      { const a = p(W + 0.3, 0, 8), piv = p(W + 0.3, 12, 14); fl += `<g transform="translate(${H3.P2(piv)})"><g>${H7.atV('skewY', ['0', '6', '-2', '4', '0'], 1.8)}<g transform="translate(${f1(-piv[0])} ${f1(-piv[1])})"><path d="${QX(p, W + 1.2, 8, Dz, 0, 12)}" fill="#9aa0a2" stroke="#6a6e70" stroke-width="${f1(0.4 * k)}"/>${rep(5, m => `<path d="M${H3.P2(p(W + 1.2, 0, 9 + m * 2.6))}L${H3.P2(p(W + 1.2, 12, 9 + m * 2.6))}" stroke="#ffffff" stroke-width="${f1(0.5 * k)}" opacity="0.25"/>`).join('')}<ellipse cx="${f1(p(W + 1.2, 4, 16)[0])}" cy="${f1(p(W + 1.2, 4, 16)[1])}" rx="${f1(3 * k)}" ry="${f1(2 * k)}" fill="#8a4420" opacity="0.5"/></g></g></g>`; void a; }
      { const e0 = RFP(W - 6, 0), e1 = RFP(W + 3, 0), r0 = RFP(W - 6, 0.35), r1 = RFP(W + 3, 0.35), piv = p(...r0); fl += `<g transform="translate(${H3.P2(piv)})"><g>${H7.atV('rotate', ['0', '-4', '0', '-2', '0'], 2.2)}<g transform="translate(${f1(-piv[0])} ${f1(-piv[1])})"><path d="M${H3.P2(p(e0[0], e0[1] + 3, e0[2] + 1))}L${H3.P2(p(e1[0], e1[1] + 3, e1[2] + 1))}L${H3.P2(p(...r1))}L${H3.P2(p(...r0))}Z" fill="#9a7e64" stroke="#5a4a3a" stroke-width="${f1(0.4 * k)}"/></g></g></g>`; }
      // rake leaning on the side, weeds along the base
      { const a = p(W + 7, 0, Dz - 2), b = p(W + 2, 40, Dz - 7); f += H7.tube([a, b], 1, k, '#9a7a52', '#c8a878', '#4a3a24'); const h = p(W + 7, 1, Dz - 2); f += `<path d="M${f1(h[0] - 4 * k)} ${f1(h[1])}h${f1(8 * k)}${rep(8, m => `M${f1(h[0] - 4 * k + m * k)} ${f1(h[1])}v${f1(2.4 * k)}`).join('')}" stroke="#5a5c5e" stroke-width="${f1(0.5 * k)}"/>`; }
      { let wd2 = ''; rep(40, () => { const x = (R() - 0.5) * 2 * (W + 4), q = p(x, 0, Dz + 1 + R() * 3), h = (2 + R() * 5) * k; wd2 += `M${H3.P2(q)}q${f1((R() - 0.5) * 2 * k)} ${f1(-h * 0.6)} ${f1((R() - 0.5) * 3 * k)} ${f1(-h)}`; }); rep(20, () => { const z = (R() - 0.5) * 2 * Dz, q = p(W + 1 + R() * 3, 0, z), h = (2 + R() * 4) * k; wd2 += `M${H3.P2(q)}q${f1((R() - 0.5) * 2 * k)} ${f1(-h * 0.6)} ${f1((R() - 0.5) * 3 * k)} ${f1(-h)}`; });
        f += `<path d="${wd2}" stroke="#7a8a3a" stroke-width="${f1(0.5 * k)}" fill="none" stroke-linecap="round"/>`; }
      return { defs: H7.FDEF || '', under: un, front: f + fl, bb: H3.bbOf([p(-W - 6, 0, -Dz - 6), p(W + 10, 0, Dz + 6), p(-W - 6, 0, Dz + 6), p(W + 10, 0, -Dz - 6), p(0, YR + 4, 0), p(-W - 4, H + 2, Dz + 6), p(W + 4, H + 2, -Dz - 6)], 4) }; };
    return D; };

  // YRD-032 PAINTED WOODEN POTTING SHED WITH WINDOW BOX (T2): a cosy sage-green board-and-batten shed with white corner boards and fascia, a cedar
  // shingle gable roof, a cream door with a four-pane window and a brass knob on a stepping stone, a white six-pane window with blue-grey shutters and
  // a window box of red geraniums, white alyssum and trailing ivy, a heart cut-out in the gable, a black lantern by the door, and a potting bench at
  // the side with terracotta pots, seedlings and a watering can. Keeps the play spot at the door. Live: the flowers nod, the ivy sways, the lantern
  // glows, a butterfly visits.
  N.pot32 = S => { const W = 36, Dz = 26, H = 48, YR = 70, SG = '#9ab89a', D = { w: 130, d: 100, act: 'play', use: { x: 0, z: 62 } }, { mt, pt, wd, cer } = H3;
    D.build = P => [XK.box(0, 0, 0, 2 * W, H, 2 * Dz, SG, wd({ r: 0.4 })), XK.prism(-W, W, [[-Dz, H], [0, YR], [Dz, H]], SG, wd({})),
      XK.prism(-W - 4, W + 4, [[Dz + 5, H - 2], [0, YR + 0.5], [0, YR + 3], [Dz + 5, H + 0.6]], '#7a5e46', wd({})), XK.prism(-W - 4, W + 4, [[-Dz - 5, H - 2], [0, YR + 0.5], [0, YR + 3], [-Dz - 5, H + 0.6]], '#7a5e46', wd({})),
      XK.box(-15, 0, Dz + 4, 22, 1.2, 8, '#a8a49a', pt({ r: 1 })),
      XK.box(W + 13, 0, -9, 1.6, 22, 1.6, '#a88a64', wd({})), XK.box(W + 13, 0, 9, 1.6, 22, 1.6, '#a88a64', wd({})), XK.box(W + 3, 0, -9, 1.6, 22, 1.6, '#a88a64', wd({})), XK.box(W + 3, 0, 9, 1.6, 22, 1.6, '#a88a64', wd({})), XK.box(W + 8, 22, 0, 13, 1.4, 22, '#b8946a', wd({ r: 0.3 })),
      XK.cyl(W + 6, 23.4, -6, 2.4, 3.4, '#c8764a', cer({ n: 14, rg: [[0, 0, 0.8], [3.4, 0, 1]] })), XK.cyl(W + 10, 23.4, -1, 2, 3, '#c8764a', cer({ n: 14, rg: [[0, 0, 0.8], [3, 0, 1]] })), XK.cyl(W + 7, 23.4, 6, 2.8, 5, '#6a8aa0', mt({ n: 16, shine: 1 }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('pot32'); let f = '', un = '', fl = '';
      un += `<ellipse cx="${f1(p(4, 0, 6)[0])}" cy="${f1(p(4, 0, 6)[1])}" rx="${f1(56 * k)}" ry="${f1(28 * k)}" fill="#2a3a1c" opacity="0.22" filter="url(#f7s)"/>`;
      // board-and-batten: battens on front + gable end
      for (let x = -W + 5; x < W; x += 6) f += `<path d="${QZ(p, Dz + 0.1, x - 0.6, x + 0.6, 0, H)}" fill="#86a688"/><path d="${QZ(p, Dz + 0.12, x - 0.6, x - 0.2, 0, H)}" fill="#c8dcc4" opacity="0.6"/>`;
      for (let z = -Dz + 5; z < Dz; z += 6) { const t = gableTop(z, Dz, H, YR) - 0.6; f += `<path d="${QX(p, W + 0.1, z - 0.6, z + 0.6, 0, t)}" fill="#7e9e80"/>`; }
      // white corner boards, fascia, gable heart cut-out
      f += `<path d="${QZ(p, Dz + 0.15, W - 2.4, W, 0, H)}" fill="#f4f1ea"/><path d="${QZ(p, Dz + 0.15, -W, -W + 2.4, 0, H)}" fill="#f4f1ea"/><path d="${QX(p, W + 0.15, Dz - 2.4, Dz, 0, H)}" fill="#e6e2da"/>`;
      { const hq = p(W + 0.2, YR - 9, 0); f += `<path d="M${f1(hq[0])} ${f1(hq[1] + 2 * k)}c${f1(-2 * k)} ${f1(-1.4 * k)} ${f1(-2 * k)} ${f1(-3.4 * k)} ${f1(-0.6 * k)} ${f1(-3.4 * k)}c${f1(0.4 * k)} 0 ${f1(0.6 * k)} ${f1(0.4 * k)} ${f1(0.6 * k)} ${f1(0.8 * k)}c0 ${f1(-0.4 * k)} ${f1(0.2 * k)} ${f1(-0.8 * k)} ${f1(0.6 * k)} ${f1(-0.8 * k)}c${f1(1.4 * k)} 0 ${f1(1.4 * k)} ${f1(2 * k)} ${f1(-0.6 * k)} ${f1(3.4 * k)}Z" fill="#2a3a2a"/>`; }
      // shingles on the front roof slope (staggered courses, varied tone)
      { const RP = (x, t) => p(x, H - 2 + (YR + 0.5 - H + 2) * t + 2.4, (Dz + 5) * (1 - t)); for (let r = 0; r < 9; r++) { const t0 = r / 9, t1 = (r + 1) / 9; let x = -W - 4 - (r % 2) * 2.5; while (x < W + 4) { const w = 4 + R() * 2, x1 = Math.min(W + 4, x + w), col = ['#7a5e46', '#8a6a4e', '#6e5440', '#94765a'][Math.floor(R() * 4)];
          f += `<path d="M${H3.P2(RP(x, t0))}L${H3.P2(RP(x1, t0))}L${H3.P2(RP(x1, t1 + 0.02))}L${H3.P2(RP(x, t1 + 0.02))}Z" fill="${col}" stroke="#4a3a2a" stroke-width="${f1(0.25 * k)}"/>`; x = x1; } } }
      // door: cream, four-pane window, brass knob
      f += `<path d="${QZ(p, Dz + 0.2, -24, -6, 0, 40)}" fill="#f2ead8" stroke="#c8bca4" stroke-width="${f1(0.5 * k)}"/><path d="${QZ(p, Dz + 0.25, -22, -8, 24, 37)}" fill="#a8c8dc"/><path d="${QZ(p, Dz + 0.25, -22, -15.5, 30, 37)}" fill="#ffffff" opacity="0.3"/><path d="M${H3.P2(p(-15, 24, Dz + 0.3))}L${H3.P2(p(-15, 37, Dz + 0.3))}M${H3.P2(p(-22, 30.5, Dz + 0.3))}L${H3.P2(p(-8, 30.5, Dz + 0.3))}" stroke="#f2ead8" stroke-width="${f1(0.9 * k)}"/>`
        + `<path d="${QZ(p, Dz + 0.25, -22, -8, 4, 20)}" fill="none" stroke="#d8ccb4" stroke-width="${f1(0.5 * k)}"/><circle cx="${f1(p(-9, 18, Dz + 0.4)[0])}" cy="${f1(p(-9, 18, Dz + 0.4)[1])}" r="${f1(0.9 * k)}" fill="#c9a050"/>`;
      // lantern by the door, warm glow
      { const q = p(-2, 38, Dz + 1.2); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(6 * k)}" fill="#ffd890" opacity="0.35" filter="url(#f7s)">${an('opacity', '0.25;0.45;0.3', 2.6)}</circle><rect x="${f1(q[0] - 1.4 * k)}" y="${f1(q[1] - 2 * k)}" width="${f1(2.8 * k)}" height="${f1(4 * k)}" fill="#ffe2a0" stroke="#1e1e22" stroke-width="${f1(0.5 * k)}"/><path d="M${f1(q[0] - 1.9 * k)} ${f1(q[1] - 2 * k)}L${f1(q[0])} ${f1(q[1] - 3.6 * k)}L${f1(q[0] + 1.9 * k)} ${f1(q[1] - 2 * k)}Z" fill="#1e1e22"/>`; }
      // window with shutters + window box
      f += `<path d="${QZ(p, Dz + 0.2, 6, 26, 18, 38)}" fill="#f4f1ea"/><path d="${QZ(p, Dz + 0.25, 7.4, 24.6, 19.4, 36.6)}" fill="#9ac0d8"/><path d="${QZ(p, Dz + 0.3, 7.4, 15, 28, 36.6)}" fill="#ffffff" opacity="0.3"/>`
        + `<path d="M${H3.P2(p(13.1, 19.4, Dz + 0.3))}L${H3.P2(p(13.1, 36.6, Dz + 0.3))}M${H3.P2(p(18.9, 19.4, Dz + 0.3))}L${H3.P2(p(18.9, 36.6, Dz + 0.3))}M${H3.P2(p(7.4, 28, Dz + 0.3))}L${H3.P2(p(24.6, 28, Dz + 0.3))}" stroke="#f4f1ea" stroke-width="${f1(0.8 * k)}"/>`
        + `<path d="${QZ(p, Dz + 0.3, 1, 5.4, 18, 38)}" fill="#6a7e90"/><path d="${QZ(p, Dz + 0.3, 26.6, 31, 18, 38)}" fill="#6a7e90"/>` + rep(5, m => `<path d="M${H3.P2(p(1.2, 20 + m * 3.6, Dz + 0.35))}L${H3.P2(p(5.2, 20 + m * 3.6, Dz + 0.35))}M${H3.P2(p(26.8, 20 + m * 3.6, Dz + 0.35))}L${H3.P2(p(30.8, 20 + m * 3.6, Dz + 0.35))}" stroke="#4a5a6a" stroke-width="${f1(0.4 * k)}"/>`).join('');
      f += `<path d="${H7.quad(p, [5, 12, Dz + 4], [27, 12, Dz + 4], [27, 17, Dz + 4], [5, 17, Dz + 4])}" fill="#8a6a4a"/><path d="${H7.quad(p, [5, 17, Dz + 4], [27, 17, Dz + 4], [27, 17, Dz], [5, 17, Dz])}" fill="#5a3a24"/>`;
      { let fw = ''; rep(9, m => { const x = 6.5 + m * 2.4, q = p(x, 19 + (m % 2) * 1.4, Dz + 2.2); fw += `<g transform="translate(${H3.P2(q)})"><g>${H7.atV('rotate', ['-5', '5', '-5'], 3 + (m % 3) * 0.6, -m * 0.4)}${rep(5, j => `<circle cx="${f1(Math.cos(j * 1.26) * 0.9 * k)}" cy="${f1(Math.sin(j * 1.26) * 0.8 * k)}" r="${f1(0.75 * k)}" fill="${m % 3 === 2 ? '#ffffff' : j % 2 ? '#e0302a' : '#c8202a'}"/>`).join('')}</g></g>`; });
        let iv = ''; rep(5, m => { const x = 7 + m * 4.4, q = p(x, 12, Dz + 4.2), L = (6 + R() * 6) * k; let lv = ''; rep(4, j => { lv += leafD(IVY, q[0] + (j % 2 ? 0.7 : -0.7) * k, q[1] + j * L / 4 + 1 * k, 0.55 * k, j % 2 ? 160 : 200, 1); });
          iv += `<g transform="translate(${H3.P2(q)})"><g>${H7.atV('rotate', ['-4', '4', '-4'], 4 + m * 0.5)}<g transform="translate(${f1(-q[0])} ${f1(-q[1])})"><path d="M${H3.P2(q)}q${f1(1 * k)} ${f1(L / 2)} 0 ${f1(L)}" stroke="#4a6a2a" stroke-width="${f1(0.25 * k)}" fill="none"/><path d="${lv}" fill="#3e7a30"/></g></g></g>`; });
        let lf = ''; rep(16, m => { const q = p(6 + R() * 20, 17.5 + R() * 2, Dz + 1 + R() * 3); lf += leafD(OVAL, q[0], q[1], 0.6 * k, R() * 360, 1); });
        fl += `<path d="${lf}" fill="#4a8a34"/>` + fw + iv; }
      // seedlings in the pots, watering can spout
      { [[W + 6, -6], [W + 10, -1]].forEach(([x, z]) => { const q = p(x, 26.8, z); fl += `<path d="M${H3.P2(q)}l${f1(-1 * k)} ${f1(-2 * k)}M${H3.P2(q)}l${f1(1 * k)} ${f1(-2.2 * k)}M${H3.P2(q)}v${f1(-2.6 * k)}" stroke="#5a9a3a" stroke-width="${f1(0.5 * k)}"/>`; });
        fl += H7.tube([p(W + 9, 26, 6), p(W + 14, 30, 6)], 0.6, k, '#6a8aa0', '#c8dce8', '#2a3a48') + H7.tube([p(W + 4.4, 28.4, 6), p(W + 5.2, 29.6, 6), p(W + 9.4, 29.6, 6)], 0.5, k, '#6a8aa0', '#c8dce8', '#2a3a48'); }
      // butterfly visiting the window box
      { const q = p(16, 24, Dz + 6); fl += `<g transform="translate(${H3.P2(q)})"><g>${at('translate', `0 0;${f1(8 * k)} ${f1(-5 * k)};${f1(14 * k)} ${f1(2 * k)};${f1(4 * k)} ${f1(4 * k)};0 0`, 12, 0, SPL(4))}<g transform="scale(${n4(k)})"><g>${at('scale', '1 1;0.2 1;1 1', 0.35, 0)}<path d="M0 0q-1.6 -1.8 -2.2 -0.2q0.4 1.2 2.2 0.2Zm0 0q1.6 -1.8 2.2 -0.2q-0.4 1.2 -2.2 0.2Z" fill="#f2c83a"/></g></g></g></g>`; }
      return { defs: H7.FDEF || '', under: un, front: f + fl, bb: H3.bbOf([p(-W - 6, 0, -Dz - 6), p(W + 16, 0, Dz + 8), p(-W - 6, 0, Dz + 8), p(W + 16, 0, -Dz - 6), p(0, YR + 5, 0), p(-W - 5, H + 2, Dz + 6), p(W + 5, H + 2, -Dz - 6)], 4) }; };
    return D; };

  // YRD-052 VICTORIAN CEDAR & GLASS GREENHOUSE (T3): a glass house on a red-brick knee wall: cedar frame, glazing bars and sills, a glass gable roof
  // with white ornamental cresting and turned finials, one roof vent propped open, a glazed cedar door; inside, slatted benches with terracotta pots,
  // tomato vines with red fruit, ferns, a hanging basket and a watering can; condensation beads on a few panes. Keeps the play spot at the door.
  // Live: a sheen glides across the glass, the vent breathes open and shut, the hanging basket sways.
  N.gh32 = S => { const W = 36, Dz = 26, HB = 10, H = 46, YR = 66, CD = '#a8683a', D = { w: 130, d: 100, act: 'play', use: { x: 0, z: 62 } }, { mt, pt, wd, cer } = H3;
    D.build = P => [XK.box(0, 0, 0, 2 * W, HB, 2 * Dz, '#a8523a', pt({ r: 0.4 })), XK.box(0, HB, 0, 2 * W + 1.4, 1.4, 2 * Dz + 1.4, '#b4ab9c', pt({ r: 0.3 })),
      XK.box(-16, HB + 1.4, -16, 34, 14, 12, '#8a6a4a', wd({ r: 0.3 })), XK.box(20, HB + 1.4, -14, 24, 12, 14, '#8a6a4a', wd({ r: 0.3 })),
      ...[[-28, -16], [-20, -14], [-10, -18], [-2, -15], [14, -12], [24, -16]].map(([x, z], i) => XK.cyl(x, HB + (x < 4 ? 15.4 : 13.4), z, 2.6, 3.8, '#c8764a', cer({ n: 14, rg: [[0, 0, 0.78], [3.8, 0, 1]] })))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('gh32'); let bk = '', f = '', gl = '', un = '';
      un += `<ellipse cx="${f1(p(4, 0, 6)[0])}" cy="${f1(p(4, 0, 6)[1])}" rx="${f1(54 * k)}" ry="${f1(26 * k)}" fill="#2a3a1c" opacity="0.2" filter="url(#f7s)"/>`;
      const GF = (d, op) => `<path d="${d}" fill="#dcecf0" opacity="${op}"/>`, FR = (d, w) => `<path d="${d}" fill="none" stroke="${CD}" stroke-width="${f1((w || 0.9) * k)}" stroke-linejoin="round"/>`;
      // back + left glass (seen through the front), back roof slope
      bk += GF(QZ(p, -Dz, -W, W, HB + 1.4, H), 0.18) + GF(QX(p, -W, -Dz, Dz, HB + 1.4, H), 0.14) + GF(H7.quad(p, [-W, H, -Dz], [W, H, -Dz], [W, YR, 0], [-W, YR, 0]), 0.14);
      for (let x = -W; x <= W; x += 9) bk += FR(`M${H3.P2(p(x, HB + 1.4, -Dz))}L${H3.P2(p(x, H, -Dz))}L${H3.P2(p(x, YR, 0))}`, 0.6);
      // gravel floor speckle + the cedar sill round the top of the knee wall
      rep(120, () => { const q = p((R() - 0.5) * 2 * W, HB + 1.45, (R() - 0.5) * 2 * Dz); un += ''; bk += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.35 * k)}" fill="${R() < 0.5 ? '#8a8478' : '#d8d0c0'}"/>`; });
      f += `<path d="M${H3.P2(p(-W - 0.7, HB + 1.4, Dz + 0.7))}L${H3.P2(p(W + 0.7, HB + 1.4, Dz + 0.7))}L${H3.P2(p(W + 0.7, HB + 1.4, -Dz - 0.7))}" stroke="${CD}" stroke-width="${f1(1.6 * k)}" fill="none"/>`;
      // brick courses on the knee wall (front + side)
      for (let y = 2; y < HB; y += 2.2) f += `<path d="M${H3.P2(p(-W, y, Dz + 0.05))}L${H3.P2(p(W, y, Dz + 0.05))}L${H3.P2(p(W + 0.05, y, -Dz))}" stroke="#e8d8c8" stroke-width="${f1(0.25 * k)}" fill="none" opacity="0.7"/>`;
      for (let y = 0, r = 0; y < HB; y += 2.2, r++) for (let x = -W + (r % 2) * 2.4; x < W; x += 4.8) f += `<path d="M${H3.P2(p(x, y, Dz + 0.05))}L${H3.P2(p(x, Math.min(HB, y + 2.2), Dz + 0.05))}" stroke="#e8d8c8" stroke-width="${f1(0.2 * k)}" opacity="0.6"/>`;
      // plants inside: tomato vines with fruit on canes, ferns on the bench, hanging basket from the ridge
      { const LV = ['', '']; let tm = ''; [-24, -12, -2].forEach((x, i) => { const base = [x, HB + 19, -16]; f += H7.tube([p(...base), p(x + 1, H - 4, -16)], 0.4, k, '#c8b078', '#e8d8a8', '#6a5a30'); rep(24, () => { const y = HB + 20 + R() * (H - HB - 26), q = p(x + (R() - 0.5) * 7, y, -16 + (R() - 0.5) * 4); LV[R() < 0.6 ? 0 : 1] += leafD(OVAL, q[0], q[1], 0.9 * k, R() * 360, 1); });
          rep(4, m => { const q = p(x + (R() - 0.5) * 5, HB + 22 + R() * 12, -14); tm += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.3 * k)}" fill="${m % 3 ? '#d8321e' : '#e8a020'}"/><circle cx="${f1(q[0] - 0.4 * k)}" cy="${f1(q[1] - 0.4 * k)}" r="${f1(0.4 * k)}" fill="#ffffff" opacity="0.5"/>`; }); });
        let fe = ''; [[14, -12], [24, -16]].forEach(([x, z]) => { const q = p(x, HB + 17.6, z); rep(9, m => { const a = -165 + m * 18, L = (6 + R() * 3) * k, ex = q[0] + Math.cos(a * PI / 180) * L, ey = q[1] + Math.sin(a * PI / 180) * L * 0.8; fe += `M${H3.P2(q)}Q${f1((q[0] + ex) / 2)} ${f1(Math.min(q[1], ey) - 2 * k)} ${f1(ex)} ${f1(ey)}`; }); });
        f += `<path d="${LV[0]}" fill="#3e7a2e"/><path d="${LV[1]}" fill="#5a9a3e"/>` + tm + `<path d="${fe}" stroke="#4e8a36" stroke-width="${f1(1.2 * k)}" fill="none" stroke-linecap="round"/>`;
        const hk = p(4, YR - 2, 0), bq = p(4, YR - 18, 0); let hb = `<path d="M${H3.P2(hk)}L${f1(bq[0] - 3 * k)} ${f1(bq[1])}M${H3.P2(hk)}L${f1(bq[0] + 3 * k)} ${f1(bq[1])}" stroke="#5a4a3a" stroke-width="${f1(0.25 * k)}"/><ellipse cx="${f1(bq[0])}" cy="${f1(bq[1] + 1.4 * k)}" rx="${f1(3.4 * k)}" ry="${f1(2 * k)}" fill="#6a4a2a"/>`;
        rep(10, m => { hb += `<path d="${leafD(IVY, bq[0] + (R() - 0.5) * 6 * k, bq[1] + 1 * k + R() * 5 * k, 0.6 * k, 160 + R() * 40, 1)}" fill="${m % 2 ? '#4e8a36' : '#6aa846'}"/>`; }); rep(4, m => { hb += `<circle cx="${f1(bq[0] + (R() - 0.5) * 5 * k)}" cy="${f1(bq[1] + R() * 2 * k)}" r="${f1(0.8 * k)}" fill="#e868a8"/>`; });
        f += `<g transform="translate(${H3.P2(hk)})"><g>${H7.atV('rotate', ['-3', '3', '-3'], 4.4)}<g transform="translate(${f1(-hk[0])} ${f1(-hk[1])})">${hb}</g></g></g>`; }
      // front glass: front wall, side gable end, front roof slope; cedar bars; glazed door
      const frontWall = QZ(p, Dz, -W, W, HB + 1.4, H), side = `M${H3.P2(p(W, HB + 1.4, -Dz))}L${H3.P2(p(W, HB + 1.4, Dz))}L${H3.P2(p(W, H, Dz))}L${H3.P2(p(W, YR, 0))}L${H3.P2(p(W, H, -Dz))}Z`, roofF = H7.quad(p, [-W, H, Dz], [W, H, Dz], [W, YR, 0], [-W, YR, 0]);
      gl += GF(frontWall, 0.16) + GF(side, 0.2) + GF(roofF, 0.22);
      let bars = ''; for (let x = -W; x <= W + 0.1; x += 9) bars += `M${H3.P2(p(x, HB + 1.4, Dz))}L${H3.P2(p(x, H, Dz))}L${H3.P2(p(x, YR, 0))}`; for (let z = -Dz; z <= Dz + 0.1; z += 8.67) bars += `M${H3.P2(p(W, HB + 1.4, z))}L${H3.P2(p(W, gableTop(z, Dz, H, YR), z))}`;
      bars += `M${H3.P2(p(-W, H, Dz))}L${H3.P2(p(W, H, Dz))}L${H3.P2(p(W, H, -Dz))}M${H3.P2(p(-W, 28, Dz))}L${H3.P2(p(W, 28, Dz))}L${H3.P2(p(W, 28, -Dz))}M${H3.P2(p(-W, YR, 0))}L${H3.P2(p(W, YR, 0))}`;
      gl += FR(bars, 0.9) + `<path d="${bars}" fill="none" stroke="#e0a870" stroke-width="${f1(0.25 * k)}" opacity="0.6"/>`;
      gl += `<path d="${QZ(p, Dz + 0.2, -6, 6, HB + 1.4, 40)}" fill="#dcecf0" opacity="0.2"/>` + FR(QZ(p, Dz + 0.2, -6, 6, HB + 1.4, 40), 1.3) + FR(`M${H3.P2(p(0, HB + 1.4, Dz + 0.2))}L${H3.P2(p(0, 40, Dz + 0.2))}`, 0.8) + `<circle cx="${f1(p(4.4, 26, Dz + 0.4)[0])}" cy="${f1(p(4.4, 26, Dz + 0.4)[1])}" r="${f1(0.7 * k)}" fill="#c9a050"/>`;
      // condensation beads on a few panes
      rep(40, () => { const q = p(-W + 2 + R() * 30, HB + 3 + R() * 14, Dz + 0.1); gl += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1((0.2 + R() * 0.3) * k)}" fill="#ffffff" opacity="0.6"/>`; });
      // roof vent propped open (breathing)
      { const a = p(-18, YR - 4, 4), b = p(-9, YR - 4, 4), cc = p(-9, H + 6, Dz - 6), d = p(-18, H + 6, Dz - 6), piv = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
        gl += `<g transform="translate(${f1(piv[0])} ${f1(piv[1])})"><g>${H7.atV('skewY', ['0', '-5', '-5', '0'], 9)}<g transform="translate(${f1(-piv[0])} ${f1(-piv[1])})"><path d="M${H3.P2(a)}L${H3.P2(b)}L${f1(cc[0])} ${f1(cc[1] - 5 * k)}L${f1(d[0])} ${f1(d[1] - 5 * k)}Z" fill="#e8f4f8" opacity="0.45" stroke="${CD}" stroke-width="${f1(0.8 * k)}"/></g></g></g>`; }
      // cresting along the ridge + finials at the gable peaks
      { let cr = ''; for (let x = -W + 2; x < W; x += 3) { const q = p(x, YR + 0.6, 0); cr += `<path d="M${H3.P2(q)}c${f1(-0.8 * k)} ${f1(-1.6 * k)} ${f1(0.4 * k)} ${f1(-3 * k)} ${f1(1.2 * k)} ${f1(-1.8 * k)}M${H3.P2(q)}v${f1(-2.6 * k)}" stroke="#f4f1ea" stroke-width="${f1(0.45 * k)}" fill="none"/>`; }
        [-W, W].forEach(x => { const q = p(x, YR + 0.8, 0); cr += `<path d="M${H3.P2(q)}v${f1(-4 * k)}" stroke="#f4f1ea" stroke-width="${f1(0.9 * k)}"/><circle cx="${f1(q[0])}" cy="${f1(q[1] - 4.6 * k)}" r="${f1(1 * k)}" fill="#f4f1ea"/><path d="M${f1(q[0])} ${f1(q[1] - 5.6 * k)}v${f1(-1.6 * k)}" stroke="#f4f1ea" stroke-width="${f1(0.4 * k)}"/>`; });
        gl += cr; }
      // sheen gliding across the glass
      { const top = p(-W, YR, 0)[1], bot = p(W, HB, Dz)[1], x0 = p(-W, H, Dz)[0], x1 = p(W, H, -Dz)[0]; gl += `<clipPath id="gh32c"><path d="${frontWall}${side}${roofF}"/></clipPath><g clip-path="url(#gh32c)"><rect x="${f1(x0 - 20 * k)}" y="${f1(top)}" width="${f1(10 * k)}" height="${f1(bot - top)}" fill="#ffffff" opacity="0.25" transform="skewX(-25)">${H3.an('x', `${f1(x0 - 40 * k)};${f1(x1 + 60 * k)}`, 10)}</rect></g>`; }
      return { defs: H7.FDEF || '', under: un, back: bk, front: f + gl, bb: H3.bbOf([p(-W - 4, 0, -Dz - 4), p(W + 4, 0, Dz + 4), p(-W - 4, 0, Dz + 4), p(W + 4, 0, -Dz - 4), p(0, YR + 8, 0)], 4) }; };
    return D; };

  // YRD-072 ARCHITECTURAL TEAK POOL HOUSE & GUEST STUDIO (T4, new build; was the generic 'house' with turrets; act play + use kept): a low modern
  // pavilion with a thin white cantilevered roof slab over a teak soffit with warm downlights, vertical teak slat cladding on the side, a stacked
  // travertine feature wall, floor-to-ceiling glass sliders in slim black frames (one slid open), a warm interior (linen daybed, pendant, olive tree,
  // sheer curtain), and a teak deck in front with a bench, rolled towels and a potted olive. Live: the sheer curtain sways, the lights breathe, a sheen
  // slides over the glass.
  N.poolh32 = S => { const W = 42, Z0 = -30, Z1 = 18, H = 42, D = { w: 130, d: 100, act: 'play', use: { x: 0, z: 62 } }, { mt, pt, wd, cer } = H3, TK = '#a8703e', fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {});
    D.build = P => [XK.box(0, 0, 6, 2 * W + 16, 1.6, 2 * (Z1 - 6) + 34, '#9a6a42', wd({ r: 0.6 })), XK.box(0, 1.6, (Z0 + Z1) / 2, 2 * W, 0.4, Z1 - Z0, '#e8e2d6', cer({})),
      XK.box(0, 1.6, Z0 + 2, 2 * W, H, 4, '#d8cebc', pt({ r: 0.4 })), XK.box(-W + 2, 1.6, (Z0 + Z1) / 2, 4, H, Z1 - Z0, '#d8cebc', pt({ r: 0.4 })), XK.box(W - 2, 1.6, (Z0 + Z1) / 2, 4, H, Z1 - Z0, TK, wd({ r: 0.3 })),
      XK.box(-14, 1.6, -14, 30, 8, 16, '#8a6a4a', wd({ r: 0.6 })), XK.cush(-14, 9.6, -14, 28, 4, 15, '#f4efe4', fb()), XK.cush(-22, 13.6, -20, 10, 7, 3, '#d8c8a8', fb()), XK.cush(-8, 13.6, -20, 10, 7, 3, '#b8c8c0', fb()),
      XK.cyl(26, 1.6, -18, 4.4, 8, '#e8e2d6', cer({ n: 16 })), XK.ball(26, 20, -18, 7, '#8a9a6a', pt({ k: 5, n: 14, soft: 1 })),
      XK.box(0, H + 1.6, (Z0 + Z1) / 2 + 4, 2 * W + 14, 2.4, Z1 - Z0 + 18, '#f4f1ea', cer({ r: 0.4 })),
      XK.box(-30, 1.6, Z1 + 10, 24, 6, 7, TK, wd({ r: 0.6 })), XK.cyl(-36, 7.6, Z1 + 10, 2, 5, '#f4efe4', fb({ n: 12 })), XK.cyl(-31, 7.6, Z1 + 10, 2, 5, '#c8dce4', fb({ n: 12 })),
      XK.cyl(W + 2, 1.6, Z1 + 12, 5, 9, '#d8cfbe', pt({ n: 16 })), XK.cyl(W + 2, 10.6, Z1 + 12, 1.2, 10, '#7a6a52', wd({ n: 8 })), XK.ball(W + 2, 24, Z1 + 12, 7, '#8a9a6a', pt({ k: 5, n: 14, soft: 1 }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('ph32'); let f = '', un = '', bk = '';
      // travertine stack on the left wall's outer face can't be seen; show it on the back wall inside + teak slats on the right side
      for (let z = Z0 + 1; z < Z1; z += 2.2) f += `<path d="${QX(p, W + 0.1, z, z + 1.2, 1.6, H + 1.6)}" fill="#c08850" opacity="0.6"/><path d="${QX(p, W + 0.1, z + 1.2, z + 2.2, 1.6, H + 1.6)}" fill="#5a3a20" opacity="0.4"/>`;
      for (let y = 2.6, r = 0; y < H; y += 3.2, r++) for (let x = -W + 4 + (r % 2) * 4; x < W - 4; x += 8) bk += `<path d="${QZ(p, Z0 + 4.1, x, x + 7.6, y, y + 2.8)}" fill="${['#e2d8c4', '#d6cab2', '#eae2d0'][(r + Math.floor(x)) % 3]}"/>`;
      // interior warm glow + pendant over the daybed
      { const q = p(-6, 20, -10); bk += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(40 * k)}" ry="${f1(22 * k)}" fill="#ffd890" opacity="0.2" filter="url(#f7s)">${an('opacity', '0.15;0.25;0.15', 6, 0, SPL(2))}</ellipse>`; const pq = p(-14, 30, -14), tq = p(-14, H + 1.6, -14); bk += `<path d="M${H3.P2(tq)}L${H3.P2(pq)}" stroke="#2a2a2e" stroke-width="${f1(0.3 * k)}"/><ellipse cx="${f1(pq[0])}" cy="${f1(pq[1] + 1.6 * k)}" rx="${f1(3.6 * k)}" ry="${f1(2.4 * k)}" fill="#e8c27a"/><circle cx="${f1(pq[0])}" cy="${f1(pq[1] + 3 * k)}" r="${f1(5 * k)}" fill="#ffe2a0" opacity="0.5" filter="url(#f7s)"/>`; }
      // sheer curtain inside the open slider, swaying
      { const a = p(14, H, Z1 - 3), b = p(22, H, Z1 - 3), cq = p(22, 2, Z1 - 3), d = p(14, 2, Z1 - 3); f += `<g transform="translate(${H3.P2(a)})"><g>${H7.atV('skewX', ['0', '3', '0', '-2', '0'], 5.5)}<g transform="translate(${f1(-a[0])} ${f1(-a[1])})"><path d="M${H3.P2(a)}L${H3.P2(b)}L${H3.P2(cq)}L${H3.P2(d)}Z" fill="#f8f4ec" opacity="0.6"/>${rep(3, m => `<path d="M${H3.P2(p(15.6 + m * 2.4, H, Z1 - 3))}L${H3.P2(p(15.6 + m * 2.4, 2, Z1 - 3))}" stroke="#d8d0c0" stroke-width="${f1(0.35 * k)}"/>`).join('')}</g></g></g>`; }
      // glass sliders: four panes, the right one slid behind its neighbour (open gap), slim black frames, sheen
      { const panes = [[-W + 4, -W / 2 + 2], [-W / 2 + 2, 2], [2, W / 2 - 2], [W / 2 - 6, W - 14]]; let g = '';
        panes.forEach(([x0, x1], i) => { const z = Z1 + (i === 3 ? -0.6 : 0); g += `<path d="${QZ(p, z, x0, x1, 1.6, H + 1.6)}" fill="#cfe4ec" opacity="0.2"/><path d="${QZ(p, z, x0, x1, 1.6, H + 1.6)}" fill="none" stroke="#1e1e22" stroke-width="${f1(0.8 * k)}"/>`; });
        g += `<path d="${QZ(p, Z1 + 0.1, -W + 4, W - 4, 1.6, H + 1.6)}" fill="none" stroke="#1e1e22" stroke-width="${f1(1.1 * k)}"/>`;
        const t = p(-W, H, Z1)[1], b = p(W, 1.6, Z1)[1]; g += `<clipPath id="ph32g"><path d="${QZ(p, Z1, -W + 4, W - 4, 1.6, H + 1.6)}"/></clipPath><g clip-path="url(#ph32g)"><rect x="${f1(p(-W, 0, Z1)[0] - 20 * k)}" y="${f1(Math.min(t, b) - 30 * k)}" width="${f1(8 * k)}" height="${f1(Math.abs(b - t) + 60 * k)}" fill="#ffffff" opacity="0.3" transform="skewX(-20)">${H3.an('x', `${f1(p(-W, 0, Z1)[0] - 40 * k)};${f1(p(W, 0, Z1)[0] + 60 * k)}`, 11)}</rect></g>`;
        f += g; }
      // teak soffit under the roof overhang + warm downlights + the LED line along the fascia
      { const zf = Z1 + 13; f += `<path d="${H7.quad(p, [-W - 7, H + 1.5, Z1], [W + 7, H + 1.5, Z1], [W + 7, H + 1.5, zf], [-W - 7, H + 1.5, zf])}" fill="#b07a46"/>`;
        rep(5, m => { const x = -W + 4 + m * (2 * W - 8) / 4, q = p(x, H + 1.4, Z1 + 6), g0 = p(x, 1.7, Z1 + 8); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.9 * k)}" fill="#fff4d0"/>`; un += `<ellipse cx="${f1(g0[0])}" cy="${f1(g0[1])}" rx="${f1(7 * k)}" ry="${f1(3 * k)}" fill="#ffd890" opacity="0.35" filter="url(#f7s)">${an('opacity', '0.28;0.42;0.28', 5 + m * 0.4, -m, SPL(2))}</ellipse>`; });
        f += `<path d="M${H3.P2(p(-W - 7, H + 1.7, zf))}L${H3.P2(p(W + 7, H + 1.7, zf))}" stroke="#ffe2a0" stroke-width="${f1(0.6 * k)}">${an('opacity', '0.7;1;0.7', 4)}</path>`; }
      // deck seams
      { let sm = ''; for (let x = -W - 7; x <= W + 8; x += 5) sm += `M${H3.P2(p(x, 1.65, Z1))}L${H3.P2(p(x, 1.65, Z1 + 16))}`; un += `<path d="${sm}" stroke="#5a3a20" stroke-width="${f1(0.3 * k)}" opacity="0.6"/>`; }
      return { defs: H7.FDEF || '', under: un, back: bk, front: f, bb: H3.bbOf([p(-W - 9, 0, Z0 - 2), p(W + 9, 0, Z1 + 18), p(-W - 9, 0, Z1 + 18), p(W + 9, 0, Z0 - 2), p(0, H + 6, Z0), p(W + 6, 26, Z1 + 12)], 4) }; };
    return D; };

  // YRD-092 FLOATING GLASS ZEN TEA PAVILION OVER WATER (T5, new build; was a generic pergola; 2 seats new): a koi pond with lily pads, stepping
  // stones and a stone lantern; a hinoki-timber pavilion on slim posts standing in the water, frameless glass walls in thin bronze frames, a shoji
  // screen at the back, a deep charcoal-copper hip roof with timber fascia; inside, a low tea table with a tea set and two cushions, a paper floor
  // lantern. A red maple by the water. Live: koi swim, ripples spread, steam curls from the teapot, the lanterns glow.
  N.zen32 = S => { const PX = 0, PZ = -14, W = 30, Dz = 22, DY = 8, H = 46, D = { w: 170, d: 130, seats: [{ x: -10, z: -12, h: DY + 3 }, { x: 10, z: -12, h: DY + 3 }] }, { mt, pt, wd, cer } = H3, HN = '#d8b484', fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {});
    D.build = P => { const o = [];
      [[-W, -Dz], [W, -Dz], [-W, Dz], [W, Dz]].forEach(([x, z]) => o.push(XK.box(PX + x, -2, PZ + z, 3, DY + H + 2, 3, '#6a4a2a', wd({ r: 0.3 }))));
      o.push(XK.box(PX, DY - 1.6, PZ, 2 * W + 4, 1.8, 2 * Dz + 4, HN, wd({ r: 0.4 })), XK.box(PX, DY + 0.2, PZ, 2 * W - 2, 0.3, 2 * Dz - 2, '#c8c08a', fb({})),
        XK.box(PX, DY + 0.5, PZ - 4, 22, 5, 12, '#3a2a1e', wd({ r: 0.8 })), XK.cush(PX - 10, DY + 0.5, PZ - 12, 12, 2.6, 10, '#8a3a2a', fb()), XK.cush(PX + 10, DY + 0.5, PZ - 12, 12, 2.6, 10, '#3a4a5a', fb()),
        XK.cyl(PX - 2, DY + 5.5, PZ - 4, 2.4, 3, '#4a3a30', cer({ n: 14, rg: [[0, 0, 0.8], [1.5, 0, 1], [3, 0, 0.7]], shine: 1 })), XK.cyl(PX + 4, DY + 5.5, PZ - 2, 1.2, 1.6, '#e8e0cc', cer({ n: 10 })), XK.cyl(PX + 6, DY + 5.5, PZ - 6, 1.2, 1.6, '#e8e0cc', cer({ n: 10 })),
        XK.cyl(PX + W - 6, DY + 0.5, PZ - Dz + 6, 3, 12, '#f4ecd8', cer({ n: 14, op: 0.9 })),
        XK.cyl(56, 0, 34, 4, 2, '#8a8478', pt({ n: 8 })), XK.box(56, 2, 34, 3, 8, 3, '#9a948a', pt({ r: 0.4 })), XK.box(56, 10, 34, 7, 5, 7, '#8a8478', pt({ r: 0.6 })), XK.box(56, 15, 34, 9, 1.4, 9, '#9a948a', pt({ r: 0.8 })),
        XK.cyl(-60, 0, 30, 2.4, 26, '#4a2a1a', wd({ n: 8 })));
      [[-4, 34], [-10, 26], [-6, 16]].forEach(([x, z]) => o.push(XK.cyl(x, 0, z, 5, 1.6, '#9a968c', pt({ n: 12 }))));
      return o; };
    D.fx = c => { const p = c.p, k = c.k, R = rng('zen32'); let un = '', bk = '', f = '', rf = '';
      // pond: organic outline on the ground, deep-to-shallow gradient, ripples, lily pads, koi
      const pond = rep(28, i => { const a = i / 28 * 2 * PI, r = 1 + Math.sin(a * 3) * 0.06 + Math.cos(a * 5) * 0.04; return p(Math.cos(a) * 78 * r, 0.3, Math.sin(a) * 56 * r); });
      const pd = 'M' + pond.map(H3.P2).join('L') + 'Z';
      un += `<path d="${pd}" fill="#8a8478" transform="translate(0 ${f1(1.4 * k)})"/><path d="${pd}" fill="url(#zn32w)"/><clipPath id="zn32c"><path d="${pd}"/></clipPath><g clip-path="url(#zn32c)">`;
      un += rep(3, i => { const q = p((R() - 0.5) * 80, 0.3, (R() - 0.5) * 60), T = 4 + R() * 2; return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="1" ry="0.5" fill="none" stroke="#e8f6fa" stroke-width="${f1(0.4 * k)}">${an('rx', `${f1(1)};${f1(14 * k)}`, T, -i * 1.4)}${an('ry', `${f1(0.5)};${f1(6 * k)}`, T, -i * 1.4)}${an('opacity', '0.8;0', T, -i * 1.4)}</ellipse>`; }).join('');
      un += rep(5, i => { const loop = rep(13, j => { const a = j / 12 * 2 * PI + i; return p(Math.cos(a) * (40 + i * 6), 0.4, Math.sin(a) * (26 + i * 4) + (i % 2 ? 6 : -4)); }), pth = 'M' + loop.map(H3.P2).join('L') + 'Z', col = ['#f08a2a', '#ffffff', '#e86a1a', '#f4c070', '#ffffff'][i];
        return `<g><animateMotion dur="${18 + i * 3}s" begin="${-i * 4}s" repeatCount="indefinite" rotate="auto" path="${pth}"/><g transform="scale(${n4(k)})"><ellipse rx="4" ry="1.4" fill="${col}"/><path d="M-4 0l-2.4 -1.6l0.6 1.6l-0.6 1.6Z" fill="${col}"/>${i % 2 ? '<ellipse cx="1" cy="-0.3" rx="1.4" ry="0.6" fill="#e84a1a"/><ellipse cx="-1.6" cy="0.3" rx="1" ry="0.5" fill="#2a2a2a"/>' : '<ellipse cx="0.6" cy="0" rx="1.2" ry="0.7" fill="#ffffff"/>'}</g></g>`; }).join('');
      un += '</g>' + rep(7, i => { const q = p(-50 + i * 14 + (R() - 0.5) * 6, 0.5, 26 + (R() - 0.5) * 14), r = (3 + R() * 2) * k; return `<path d="M${H3.P2(q)}l${f1(r)} ${f1(-r * 0.15)}A${f1(r)} ${f1(r * 0.5)} 0 1 1 ${f1(q[0] + r * 0.9)} ${f1(q[1] + r * 0.2)}Z" fill="${i % 2 ? '#4a8a3a' : '#5a9a44'}"/>${i === 2 ? `<circle cx="${f1(q[0] - r * 0.3)}" cy="${f1(q[1] - r * 0.2)}" r="${f1(1.2 * k)}" fill="#f4b8c8"/>` : ''}`; }).join('');
      // stone lantern light + paper floor lantern inside
      un += H7.glowE(p, 56, 12, 34, 8, 8, '#ffd890', 0.35, 1);
      { const q = p(56, 12.5, 37.6); f += `<rect x="${f1(q[0] - 1.4 * k)}" y="${f1(q[1] - 1.6 * k)}" width="${f1(2.8 * k)}" height="${f1(2.4 * k)}" fill="#ffe2a0"/>`; }
      // shoji screen at the back + back / left glass
      bk += `<path d="${QZ(p, PZ - Dz, PX - W, PX + W, DY, DY + H)}" fill="#f4eedc" opacity="0.92"/>` + rep(9, m => `<path d="M${H3.P2(p(PX - W + m * 7.5, DY, PZ - Dz))}L${H3.P2(p(PX - W + m * 7.5, DY + H, PZ - Dz))}" stroke="#8a6a44" stroke-width="${f1(0.4 * k)}"/>`).join('') + rep(6, m => `<path d="M${H3.P2(p(PX - W, DY + m * 9, PZ - Dz))}L${H3.P2(p(PX + W, DY + m * 9, PZ - Dz))}" stroke="#8a6a44" stroke-width="${f1(0.4 * k)}"/>`).join('');
      bk += `<path d="${QX(p, PX - W, PZ - Dz, PZ + Dz, DY, DY + H)}" fill="#dcecf0" opacity="0.15"/>`;
      // inside: lantern glow + steam from the teapot; tatami edges
      { const lq = p(PX + W - 6, DY + 8, PZ - Dz + 6); f += `<circle cx="${f1(lq[0])}" cy="${f1(lq[1])}" r="${f1(10 * k)}" fill="#ffd890" opacity="0.35" filter="url(#f7s)">${an('opacity', '0.28;0.45;0.3', 3.4)}</circle>`;
        f += H7.smoke(p(PX - 2, DY + 9, PZ - 4), k, { seed: 'zst', n: 4, H: 16, col: '#ffffff', op: 0.45, d: 4, r1: 3, drift: 4 });
        f += rep(4, m => `<path d="M${H3.P2(p(PX - W + 1, DY + 0.55, PZ - Dz + 1 + m * (2 * Dz - 2) / 3))}L${H3.P2(p(PX + W - 1, DY + 0.55, PZ - Dz + 1 + m * (2 * Dz - 2) / 3))}" stroke="#3a3a2a" stroke-width="${f1(0.35 * k)}" opacity="0.6"/>`).join(''); }
      // front + right glass in thin bronze frames
      f += `<path d="${QZ(p, PZ + Dz, PX - W, PX + W, DY, DY + H)}" fill="#dcecf0" opacity="0.14"/><path d="${QX(p, PX + W, PZ - Dz, PZ + Dz, DY, DY + H)}" fill="#dcecf0" opacity="0.18"/>`
        + `<path d="${QZ(p, PZ + Dz, PX - W, PX + W, DY, DY + H)}${QX(p, PX + W, PZ - Dz, PZ + Dz, DY, DY + H)}M${H3.P2(p(PX, DY, PZ + Dz))}L${H3.P2(p(PX, DY + H, PZ + Dz))}" fill="none" stroke="#8a6a3a" stroke-width="${f1(0.5 * k)}"/>`;
      // maple by the water
      { const LV = ['', '', '']; rep(260, () => { const a = R() * 2 * PI, r = Math.sqrt(R()), q = p(-60 + Math.cos(a) * r * 18, 30 + R() * 14 - r * 6, 30 + Math.sin(a) * r * 10); LV[Math.floor(R() * 3)] += leafD(IVY, q[0], q[1], 1.1 * k, R() * 360, 1); });
        f += `<g>${H7.atV('rotate', ['-1 ' + H3.P2(p(-60, 0, 30)), '1 ' + H3.P2(p(-60, 0, 30)), '-1 ' + H3.P2(p(-60, 0, 30))], 7)}<path d="${LV[0]}" fill="#8a1e1a"/><path d="${LV[1]}" fill="#b8321e"/><path d="${LV[2]}" fill="#d84a24"/></g>`; }
      // hip roof: 4 faces back-to-front, charcoal copper with standing seams, timber fascia
      { const ey = DY + H + 1, ry = DY + H + 18, ex = W + 12, ez = Dz + 12, rx = 12, E = [[-ex, ez], [ex, ez], [ex, -ez], [-ex, -ez]].map(([x, z]) => [PX + x, ey, PZ + z]), RL = [PX - rx, ry, PZ], RR = [PX + rx, ry, PZ];
        const faces = [[E[3], E[2], RR, RL], [E[0], E[3], RL], [E[1], E[0], RL, RR], [E[2], E[1], RR]];
        faces.forEach(F => { const L = lit(nrm(F[0], F[1], F[2])); rf += `<path d="M${F.map(q => H3.P2(p(...q))).join('L')}Z" fill="${XK.shade('#3e4a4a', 0.7 + 0.6 * L)}" stroke="#2a3030" stroke-width="${f1(0.3 * k)}"/>`; });
        let sm = ''; for (let t = 0.08; t < 1; t += 0.08) { const a = E[0].map((v, j) => v + (E[1][j] - v) * t), b = RL.map((v, j) => v + (RR[j] - v) * Math.min(1, Math.max(0, (t - 0.25) / 0.5))); sm += `M${H3.P2(p(...a))}L${H3.P2(p(...b))}`; }
        rf += `<path d="${sm}" stroke="#7a8a86" stroke-width="${f1(0.3 * k)}" opacity="0.6"/><path d="M${[E[3], E[0], E[1], E[2]].map(q => H3.P2(p(q[0], q[1] - 1.4, q[2]))).join('L')}" stroke="#5a3a20" stroke-width="${f1(1.6 * k)}" fill="none"/><path d="M${H3.P2(p(...RL))}L${H3.P2(p(...RR))}" stroke="#8a9a96" stroke-width="${f1(0.8 * k)}"/>`; }
      return { defs: (H7.FDEF || '') + '<radialGradient id="zn32w" cx="50%" cy="45%" r="60%"><stop offset="0" stop-color="#1e4a5a"/><stop offset="0.7" stop-color="#3a7a84"/><stop offset="1" stop-color="#7ab0b0"/></radialGradient>', under: un, back: bk, front: f + rf, bb: H3.bbOf([p(-84, 0, -60), p(84, 0, 60), p(-84, 0, 60), p(84, 0, -60), p(0, DY + H + 22, PZ), p(-60, 50, 30)], 4) }; };
    return D; };

  // YRD-082 AUTOMATED TEPPANYAKI & ROTISSERIE CHEF PAVILION WITH OUTDOOR FRIDGE (T5, new build; was a generic island + glass panel): under a slim bronze
  // canopy with a warm light line and two glass pendants, a black marble island with gold veins on walnut slats: a mirror-steel teppanyaki plate where
  // a white robot arm flips shrimp and vegetables, a glass rotisserie cabinet with a chicken turning over a glowing element, and a glass-door outdoor
  // fridge full of bottles. Live: the arm flips, steam and sizzle rise, the chicken turns, the fridge glows, the pendants breathe.
  N.chef32 = S => { const W = 46, Z0 = -16, Z1 = 14, HC = 32, D = { w: 110, d: 60 }, { mt, pt, wd, cer } = H3, BZ = '#8a6a3a';
    D.build = P => [XK.box(0, 0, -1, 2 * W, HC, Z1 - Z0, '#4a3020', wd({ r: 0.6 })), XK.box(0, HC, -1, 2 * W + 3, 2.6, Z1 - Z0 + 3, '#1c1c20', cer({ r: 0.6, shine: 1 })),
      XK.box(2, HC + 2.6, -1, 34, 0.8, 20, '#d8dce0', mt({ r: 0.3, shine: 1 })),
      XK.box(-W + 11, HC + 2.6, -1, 20, 22, 20, '#e8f0f2', cer({ r: 0.5, op: 0.3 })), XK.box(-W + 11, HC + 24.6, -1, 21, 1.2, 21, '#1c1c20', mt({})),
      XK.cyl(10, HC + 2.6, Z0 + 3, 3.2, 3, '#f2f2f0', cer({ n: 16, shine: 1 })),
      ...[[-W - 4, -Z1 - 8], [W + 4, -Z1 - 8], [-W - 4, Z1 + 6], [W + 4, Z1 + 6]].map(([x, z]) => XK.box(x, 0, z, 2, 72, 2, BZ, mt({ shine: 1 }))), XK.box(0, 72, -2, 2 * W + 12, 2, 2 * Z1 + 18, '#2a2620', mt({ r: 0.4 }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('chef32'); let f = '', un = '';
      // gold veins on the marble top + walnut slats on the island front + the fridge
      { let v = ''; rep(4, () => { let x = -W + R() * 10, z = Z0 + R() * (Z1 - Z0), d = 'M' + H3.P2(p(x, HC + 2.65, z)); rep(10, () => { x += 6 + R() * 4; z += (R() - 0.5) * 5; z = Math.max(Z0 - 1, Math.min(Z1 + 1, z)); d += 'L' + H3.P2(p(Math.min(W + 1, x), HC + 2.65, z)); }); v += d; }); f += `<path d="${v}" stroke="#d8b060" stroke-width="${f1(0.3 * k)}" fill="none" opacity="0.8"/>`; }
      for (let x = -W + 1; x < W; x += 3) f += `<path d="${QZ(p, Z1 + 0.6, x, x + 1.8, 0.5, HC - 0.5)}" fill="#6a4a30"/>`;
      { const x0 = W - 26, x1 = W - 4; f += `<path d="${QZ(p, Z1 + 0.7, x0, x1, 3, HC - 4)}" fill="#1a2024"/><path d="${QZ(p, Z1 + 0.75, x0 + 1, x1 - 1, 4, HC - 5)}" fill="#cfe8f0" opacity="0.18">${an('opacity', '0.14;0.24;0.14', 3)}</path>`;
        rep(3, sh => rep(6, m => { const q = p(x0 + 2.4 + m * 3.4, 6 + sh * 8, Z1 + 0.5); f += `<rect x="${f1(q[0] - 0.7 * k)}" y="${f1(q[1] - 5 * k)}" width="${f1(1.4 * k)}" height="${f1(5 * k)}" rx="${f1(0.4 * k)}" fill="${['#2a5a2a', '#8a1a2a', '#e8c86a', '#f4f4f0'][(sh + m) % 4]}"/>`; }));
        rep(3, sh => { f += `<path d="M${H3.P2(p(x0 + 1, 6.2 + sh * 8, Z1 + 0.55))}L${H3.P2(p(x1 - 1, 6.2 + sh * 8, Z1 + 0.55))}" stroke="#9aa1ad" stroke-width="${f1(0.4 * k)}"/>`; });
        f += H7.tube([p(x0 + 2, 8, Z1 + 1.8), p(x0 + 2, 24, Z1 + 1.8)], 0.8, k, '#c9a050', '#fff0c0', '#5a4010') + `<path d="${QZ(p, Z1 + 0.8, x0, x1, 3, HC - 4)}" fill="none" stroke="#c9a050" stroke-width="${f1(0.5 * k)}"/>`; }
      // teppan plate: mirror sheen, food, sizzle + steam
      { const pq = (x, z) => p(x, HC + 3.45, z); f += `<path d="${H7.quad(p, [-15, HC + 3.42, -11], [19, HC + 3.42, -11], [19, HC + 3.42, 9], [-15, HC + 3.42, 9])}" fill="url(#ch32p)"/>`;
        const food = [[-8, -4, '#f08a6a'], [-4, -6, '#f08a6a'], [0, -3, '#f08a6a'], [6, 2, '#5a9a3a'], [10, -2, '#e8c040'], [3, 5, '#c8402a'], [-10, 4, '#8a5a3a'], [-5, 3, '#8a5a3a']];
        food.forEach(([x, z, col], i) => { const q = pq(x, z); f += i < 3 ? `<path d="M${f1(q[0] - 1.6 * k)} ${f1(q[1])}q${f1(1.6 * k)} ${f1(-2 * k)} ${f1(3.2 * k)} 0q${f1(-1.2 * k)} ${f1(-0.6 * k)} ${f1(-1.6 * k)} ${f1(0.6 * k)}" stroke="${col}" stroke-width="${f1(1.1 * k)}" fill="none" stroke-linecap="round"/>` : `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(1.6 * k)}" ry="${f1(1 * k)}" fill="${col}"/>`; });
        f += H7.smoke(p(2, HC + 4, -1), k, { seed: 'chs', n: 5, H: 24, col: '#ffffff', op: 0.35, d: 3.4, r1: 6, drift: 8 });
        rep(6, i => { const q = pq((R() - 0.5) * 28, (R() - 0.5) * 16), d = 0.5 + R() * 0.5; f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.4 * k)}" fill="#fff6c8" opacity="0"><animate attributeName="cy" values="${f1(q[1])};${f1(q[1] - 4 * k)}" dur="${n4(d)}s" begin="${n4(R())}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;0" dur="${n4(d)}s" begin="${n4(R())}s" repeatCount="indefinite"/></circle>`; }); }
      // robot arm: base at the back, shoulder swings, elbow flips a spatula over the plate
      { const b = p(10, HC + 5.6, Z0 + 3), s1 = p(10, HC + 20, Z0 + 3), wr = p(4, HC + 12, -2); const arm = (pts, w) => H7.tube(pts, w, k, '#f2f2f0', '#ffffff', '#8a9098');
        f += `<g transform="translate(${H3.P2(b)})"><g>${H7.atV('rotate', ['-10', '14', '-10'], 3.2)}<g transform="translate(${f1(-b[0])} ${f1(-b[1])})">${arm([b, s1], 2.6)}<circle cx="${f1(s1[0])}" cy="${f1(s1[1])}" r="${f1(1.8 * k)}" fill="#2a2a2e"/>`
          + `<g transform="translate(${H3.P2(s1)})"><g>${H7.atV('rotate', ['20', '-25', '20'], 3.2)}<g transform="translate(${f1(-s1[0])} ${f1(-s1[1])})">${arm([s1, wr], 2)}<circle cx="${f1(wr[0])}" cy="${f1(wr[1])}" r="${f1(1.2 * k)}" fill="#2a2a2e"/><circle cx="${f1(wr[0])}" cy="${f1(wr[1])}" r="${f1(0.5 * k)}" fill="#6af0ff">${an('opacity', '0.5;1;0.5', 1.2)}</circle><path d="M${H3.P2(wr)}l${f1(1 * k)} ${f1(4 * k)}" stroke="#9aa1ad" stroke-width="${f1(0.6 * k)}"/><rect x="${f1(wr[0] - 1.4 * k)}" y="${f1(wr[1] + 4 * k)}" width="${f1(4 * k)}" height="${f1(1 * k)}" fill="#d8dce0"/></g></g></g></g></g></g>`; }
      // rotisserie: element glow, spit, chicken turning
      { const cq = p(-W + 11, HC + 12, -1); f += `<ellipse cx="${f1(cq[0])}" cy="${f1(cq[1] + 6 * k)}" rx="${f1(8 * k)}" ry="${f1(2 * k)}" fill="#ff6a1a" opacity="0.6" filter="url(#f7b)">${an('opacity', '0.45;0.75;0.45', 1.6)}</ellipse>`
          + H7.tube([p(-W + 1.6, HC + 12, -1), p(-W + 20.4, HC + 12, -1)], 0.5, k, '#9aa1ad', '#ffffff', '#3a3c42')
          + `<g transform="translate(${H3.P2(cq)})"><g>${H7.atV('scale', ['1 1', '0.85 1', '1 1'], 2.4)}<ellipse rx="${f1(5.4 * k)}" ry="${f1(4 * k)}" fill="#b8642a"/><ellipse cx="${f1(-1.6 * k)}" cy="${f1(-1.4 * k)}" rx="${f1(2.4 * k)}" ry="${f1(1.4 * k)}" fill="#e8a060" opacity="0.7"/><path d="M${f1(4.6 * k)} ${f1(-1 * k)}l${f1(2.4 * k)} ${f1(-1.4 * k)}M${f1(4.6 * k)} ${f1(1 * k)}l${f1(2.4 * k)} ${f1(1 * k)}" stroke="#8a4a1a" stroke-width="${f1(1 * k)}" stroke-linecap="round"/></g></g>`; }
      // canopy: warm light line + two glass pendants
      f += `<path d="M${H3.P2(p(-W - 4, 71.6, Z1 + 6))}L${H3.P2(p(W + 4, 71.6, Z1 + 6))}" stroke="#ffe2a0" stroke-width="${f1(0.6 * k)}">${an('opacity', '0.7;1;0.7', 4)}</path>`;
      [-18, 18].forEach((x, i) => { const t = p(x, 72, -2), q = p(x, 56, -2); f += `<path d="M${H3.P2(t)}L${H3.P2(q)}" stroke="#1e1e22" stroke-width="${f1(0.3 * k)}"/><circle cx="${f1(q[0])}" cy="${f1(q[1] + 2 * k)}" r="${f1(2.6 * k)}" fill="#f4e8d0" opacity="0.7" stroke="#c9a050" stroke-width="${f1(0.3 * k)}"/><circle cx="${f1(q[0])}" cy="${f1(q[1] + 2 * k)}" r="${f1(7 * k)}" fill="#ffd890" opacity="0.3" filter="url(#f7s)">${an('opacity', '0.22;0.4;0.22', 4 + i, -i)}</circle>`; });
      un += H7.glowE(p, 0, 0, 0, 50, 30, '#ffd890', 0.16);
      return { defs: (H7.FDEF || '') + '<linearGradient id="ch32p" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f6f8"/><stop offset="0.45" stop-color="#9aa1ad"/><stop offset="0.55" stop-color="#e8ecf0"/><stop offset="1" stop-color="#7a8088"/></linearGradient>', under: un, front: f, bb: H3.bbOf([p(-W - 8, 0, -Z1 - 10), p(W + 8, 0, Z1 + 8), p(-W - 8, 0, Z1 + 8), p(W + 8, 0, -Z1 - 10), p(0, 76, -2), p(-W - 8, 74, -Z1 - 10), p(W + 8, 74, Z1 + 8)], 4) }; };
    return D; };

  // ======================= GARDEN ORNAMENTS =======================
  // YRD-004 CHIPPED PLASTIC PINK FLAMINGO & GARDEN GNOME (T1): a sun-faded plastic flamingo on two bent wire legs (chipped white spots, a scuffed beak)
  // and a small resin gnome with a faded red hat, chipped beard and a tiny shovel, standing in a scruffy patch of grass with a dandelion.
  // Live: the flamingo wobbles on its wire legs in the breeze, the dandelion nods.
  N.gnome32 = S => { const D = { w: 34, d: 34, round: 1 }, { pt, cer } = H3;
    D.build = P => [XK.cyl(-6, 0, 4, 6, 0.5, '#7a6a4a', pt({ n: 14 })), XK.cyl(-6, 0.6, 4, 3.4, 2, '#3a2a20', cer({ n: 14 })), XK.cyl(-6, 2.6, 4, 3.6, 7, '#3a5a9a', cer({ n: 16, rg: [[0, 0, 1], [7, 0, 0.8]] })),
      XK.ball(-6, 13.2, 5.4, 2.3, '#f0c8a8', cer({ k: 4, n: 12 })), XK.ball(-6, 10, 6.4, 2.6, '#f2ece2', cer({ k: 4, n: 12, sy: 1.25 })), XK.ball(-6, 12.8, 7.5, 0.85, '#e89a8a', cer({ k: 3, n: 8 })),
      XK.cyl(-6, 14.6, 5, 2.8, 8, '#c86a5a', cer({ n: 14, rg: [[0, 0, 1], [3, 0, 0.75], [6, 0, 0.35], [8, 0, 0.05]] }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('gn32'); let f = '', un = '';
      // scruffy grass + chips on the gnome
      { let g = ''; rep(40, () => { const a = R() * 2 * PI, r = 5 + R() * 11, q = p(Math.cos(a) * r, 0, Math.sin(a) * r), h = (1.5 + R() * 3) * k; g += `M${H3.P2(q)}q${f1((R() - 0.5) * 1.6 * k)} ${f1(-h * 0.6)} ${f1((R() - 0.5) * 2.4 * k)} ${f1(-h)}`; }); un += `<path d="${g}" stroke="#8a9a4a" stroke-width="${f1(0.45 * k)}" fill="none" stroke-linecap="round"/>`; }
      rep(3, () => { const q = p(-6 + (R() - 0.5) * 5, 3 + R() * 6, 7.6); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.45 * k)}" ry="${f1(0.3 * k)}" fill="#e8e0d0" opacity="0.8"/>`; }); { const e = p(-6.9, 13.6, 7.4), e2 = p(-5.1, 13.6, 7.4); f += `<circle cx="${f1(e[0])}" cy="${f1(e[1])}" r="${f1(0.3 * k)}" fill="#1e1e22"/><circle cx="${f1(e2[0])}" cy="${f1(e2[1])}" r="${f1(0.3 * k)}" fill="#1e1e22"/>`; }
      { const a = p(-2.6, 3, 6.4), b = p(-1.6, 12, 6); f += H7.tube([a, b], 0.35, k, '#8a6a3a', '#c8a070', '#4a3a1a') + `<path d="M${f1(a[0] - 0.9 * k)} ${f1(a[1])}l${f1(1.8 * k)} 0l${f1(-0.4 * k)} ${f1(2.2 * k)}l${f1(-1 * k)} 0Z" fill="#9aa0a4"/>`; }
      // flamingo on wire legs, wobbling about its feet
      { const g0 = p(8, 0, -4), body = p(8, 15, -4), r = k; let fl = `<path d="M${f1(g0[0] - 0.8 * r)} ${f1(g0[1])}L${f1(body[0] - 0.6 * r)} ${f1(body[1] + 2 * r)}M${f1(g0[0] + 0.8 * r)} ${f1(g0[1])}L${f1(g0[0] + 1.2 * r)} ${f1(g0[1] - 7 * r)}L${f1(body[0] + 0.4 * r)} ${f1(body[1] + 2.2 * r)}" stroke="#4a4a48" stroke-width="${f1(0.35 * r)}" fill="none"/>`;
        fl += `<ellipse cx="${f1(body[0])}" cy="${f1(body[1])}" rx="${f1(6.4 * r)}" ry="${f1(3.6 * r)}" fill="#ec8aaa" transform="rotate(-12 ${f1(body[0])} ${f1(body[1])})"/><path d="M${f1(body[0] + 5 * r)} ${f1(body[1] - 1 * r)}l${f1(3 * r)} ${f1(-1.6 * r)}l${f1(-1.6 * r)} ${f1(2.6 * r)}Z" fill="#e47a9c"/><path d="M${f1(body[0] - 3 * r)} ${f1(body[1] - 0.6 * r)}q${f1(3 * r)} ${f1(-2.4 * r)} ${f1(6 * r)} ${f1(-0.4 * r)}" stroke="#c8607e" stroke-width="${f1(0.4 * r)}" fill="none"/>`;
        fl += `<path d="M${f1(body[0] - 5 * r)} ${f1(body[1] - 1.4 * r)}C${f1(body[0] - 9 * r)} ${f1(body[1] - 5 * r)} ${f1(body[0] - 4 * r)} ${f1(body[1] - 8 * r)} ${f1(body[0] - 6 * r)} ${f1(body[1] - 12 * r)}" stroke="#ec8aaa" stroke-width="${f1(1.6 * r)}" fill="none" stroke-linecap="round"/><circle cx="${f1(body[0] - 6 * r)}" cy="${f1(body[1] - 12.6 * r)}" r="${f1(1.7 * r)}" fill="#ec8aaa"/><circle cx="${f1(body[0] - 5.5 * r)}" cy="${f1(body[1] - 13 * r)}" r="${f1(0.35 * r)}" fill="#1e1e22"/><path d="M${f1(body[0] - 7.4 * r)} ${f1(body[1] - 12.6 * r)}q${f1(-1.6 * r)} ${f1(0.4 * r)} ${f1(-1.6 * r)} ${f1(2.4 * r)}" stroke="#f4e8e0" stroke-width="${f1(0.9 * r)}" fill="none" stroke-linecap="round"/><path d="M${f1(body[0] - 8.8 * r)} ${f1(body[1] - 11 * r)}l${f1(-0.2 * r)} ${f1(1.2 * r)}" stroke="#1e1e22" stroke-width="${f1(0.9 * r)}" stroke-linecap="round"/>`;
        fl += rep(3, () => `<path d="M${f1(body[0] + (R() - 0.5) * 8 * r)} ${f1(body[1] + (R() - 0.5) * 3 * r)}l${f1(0.6 * r)} ${f1(-0.3 * r)}l${f1(0.3 * r)} ${f1(0.5 * r)}l${f1(-0.7 * r)} ${f1(0.2 * r)}Z" fill="#f4ece4"/>`).join('') + `<ellipse cx="${f1(body[0] + 2 * r)}" cy="${f1(body[1] + 1 * r)}" rx="${f1(3 * r)}" ry="${f1(1.6 * r)}" fill="#f4c8d4" opacity="0.5"/>` + `<ellipse cx="${f1(body[0] - 1 * r)}" cy="${f1(body[1] - 1.8 * r)}" rx="${f1(3 * r)}" ry="${f1(1 * r)}" fill="#ffffff" opacity="0.3"/>`;
        f += `<g transform="translate(${H3.P2(g0)})"><g>${H7.atV('rotate', ['-3', '4', '-2', '3', '-3'], 3.6)}<g transform="translate(${f1(-g0[0])} ${f1(-g0[1])})">${fl}</g></g></g>`; }
      // dandelion
      { const q = p(2, 0, 10); f += `<g transform="translate(${H3.P2(q)})"><g>${H7.atV('rotate', ['-5', '5', '-5'], 3)}<path d="M0 0q${f1(0.4 * k)} ${f1(-3 * k)} 0 ${f1(-6 * k)}" stroke="#5a8a34" stroke-width="${f1(0.3 * k)}" fill="none"/><circle cy="${f1(-6.4 * k)}" r="${f1(1 * k)}" fill="#f2c21a"/></g></g>`; }
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(-18, 0, -18), p(18, 0, 18), p(-18, 0, 18), p(18, 0, -18), p(-6, 24, 4), p(2, 32, -4)], 4) }; };
    return D; };

  // YRD-024 SPINNING COPPER WIND CHIME & BIRDHOUSE (T2): plus9 chime8 kept (post birdhouse with a peeking bird, copper tubes on a shepherd hook, chime
  // rings) + wear and garden life: grain + peeling paint on the birdhouse, moss on the roof edge, verdigris on the copper tubes, birdseed scattered
  // under the house, a clump of pink cosmos at the post foot.
  N.chime32 = S => { const D = N.chime8(S), f0 = D.fx; D.fx = c => { const F = f0(c) || {}, p = c.p, k = c.k, R = rng('ch32'); let f = '', un = '';
      rep(6, m => { f += `<path d="M${H3.P2(p(-27.9, 66 + m * 1.6, 7.1))}L${H3.P2(p(-12.1, 66 + m * 1.6 + (R() - 0.5) * 0.4, 7.1))}" stroke="#c8b898" stroke-width="${f1(0.2 * k)}" opacity="0.7"/>`; });
      rep(5, () => { const q = p(-20 + (R() - 0.5) * 12, 66 + R() * 8, 7.2); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.9 * k)}" ry="${f1(0.5 * k)}" fill="#a88a64" opacity="0.7"/>`; });
      rep(10, () => { const q = p(-20 + (R() - 0.5) * 16, 75.4, 9 + R() * 0.4); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1((0.4 + R() * 0.5) * k)}" fill="${R() < 0.5 ? '#5a7a2a' : '#7a9a3a'}"/>`; });
      rep(14, () => { const q = p(-20 + (R() - 0.5) * 12, 0.2, (R() - 0.5) * 10); un += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.35 * k)}" ry="${f1(0.22 * k)}" fill="${R() < 0.5 ? '#e8d8a0' : '#2a2018'}"/>`; });
      { const LV = ''; let st = '', fl = ''; rep(5, m => { const q = p(-15 + (R() - 0.5) * 6, 0, 4 + (R() - 0.5) * 6), h = (8 + R() * 6) * k, t = [q[0] + (R() - 0.5) * 3 * k, q[1] - h]; st += `M${H3.P2(q)}Q${f1(q[0])} ${f1(q[1] - h * 0.5)} ${f1(t[0])} ${f1(t[1])}`;
          fl += `<g transform="translate(${f1(t[0])} ${f1(t[1])})"><g>${H7.atV('rotate', ['-6', '6', '-6'], 3 + m * 0.4, -m)}${rep(8, j => `<ellipse cx="${f1(Math.cos(j * 0.785) * 1.1 * k)}" cy="${f1(Math.sin(j * 0.785) * 0.8 * k)}" rx="${f1(0.8 * k)}" ry="${f1(0.4 * k)}" transform="rotate(${j * 45} ${f1(Math.cos(j * 0.785) * 1.1 * k)} ${f1(Math.sin(j * 0.785) * 0.8 * k)})" fill="${m % 2 ? '#f2a6c8' : '#e878a8'}"/>`).join('')}<circle r="${f1(0.5 * k)}" fill="#f2c21a"/></g></g>`; }); void LV;
        f += `<path d="${st}" stroke="#5a8a34" stroke-width="${f1(0.35 * k)}" fill="none"/>` + fl; }
      return Object.assign({}, F, { under: (F.under || '') + un, front: (F.front || '') + f }); };
    return D; };

  // YRD-044 STONE SUNDIAL PEDESTAL & TIERED BIRDBATH (T3): a two-tier cast-stone birdbath (fluted pedestal, wide lower basin, small upper bowl that
  // spills over) and a short stone sundial pedestal with a bronze dial plate, engraved hour lines and a gnomon; moss and lichen on the stone, a sparrow
  // bathing in the lower basin. Live: water trickles from the upper bowl, ripples spread, the sparrow dips and flicks water, the gnomon shadow creeps round.
  N.bath32 = S => { const D = { w: 60, d: 60, round: 1 }, { pt, cer, mt } = H3, ST = '#c8c0b0', BX = -6, BZ = -4, SX = 17, SZ = 12;
    D.build = P => [XK.cyl(BX, 0, BZ, 9, 3, ST, pt({ n: 18, rg: [[0, 0, 1], [3, 0, 0.9]] })), XK.cyl(BX, 3, BZ, 4, 22, ST, pt({ n: 16, rg: [[0, 0, 1], [3, 0, 0.8], [19, 0, 0.8], [22, 0, 1.2]] })),
      XK.cyl(BX, 25, BZ, 18, 5, ST, pt({ n: 28, rg: [[0, 0, 0.45], [2, 0, 0.85], [5, 0, 1]] })), XK.cyl(BX, 30, BZ, 2.2, 9, ST, pt({ n: 12 })), XK.cyl(BX, 39, BZ, 8, 3.4, ST, pt({ n: 20, rg: [[0, 0, 0.4], [3.4, 0, 1]] })), XK.ball(BX, 44, BZ, 2, ST, pt({ k: 4, n: 12 })),
      XK.box(SX, 0, SZ, 12, 2.6, 12, ST, pt({ r: 0.6 })), XK.cyl(SX, 2.6, SZ, 3.6, 18, ST, pt({ n: 16, rg: [[0, 0, 1], [2, 0, 0.82], [16, 0, 0.82], [18, 0, 1.1]] })), XK.cyl(SX, 20.6, SZ, 7.4, 1.6, ST, pt({ n: 22 })), XK.cyl(SX, 22.2, SZ, 6.6, 0.5, '#9a7a42', mt({ n: 22, shine: 1 }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('bb32'); let f = '', un = '';
      un += `<ellipse cx="${f1(p(BX + 4, 0, BZ + 4)[0])}" cy="${f1(p(BX + 4, 0, BZ + 4)[1])}" rx="${f1(22 * k)}" ry="${f1(10 * k)}" fill="#2a2a20" opacity="0.2" filter="url(#f7s)"/>`;
      // flutes on the pedestal, moss + lichen
      rep(8, m => { const a = -0.3 + m * 0.24, x = BX + Math.sin(a) * 3.3, z = BZ + Math.cos(a) * 3.3; f += `<path d="M${H3.P2(p(x, 6, z))}L${H3.P2(p(x, 22, z))}" stroke="#a49c8c" stroke-width="${f1(0.4 * k)}"/>`; });
      rep(14, () => { const a = R() * 2.2 - 0.6, q = p(BX + Math.sin(a) * (R() < 0.5 ? 9 : 4.2), R() < 0.5 ? 1 + R() * 2 : 4 + R() * 18, BZ + Math.cos(a) * (R() < 0.5 ? 9 : 4.2)); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((0.6 + R()) * k)}" ry="${f1((0.4 + R() * 0.6) * k)}" fill="${R() < 0.6 ? '#6a8a3a' : '#d8d08a'}" opacity="0.75"/>`; });
      // water in both basins, ripples, trickle
      const W1 = p(BX, 29.6, BZ), W2 = p(BX, 42, BZ);
      f += `<ellipse cx="${f1(W1[0])}" cy="${f1(W1[1])}" rx="${f1(16.4 * k)}" ry="${f1(8 * k)}" fill="#7aa8b8"/><ellipse cx="${f1(W1[0] - 4 * k)}" cy="${f1(W1[1] - 2 * k)}" rx="${f1(8 * k)}" ry="${f1(3 * k)}" fill="#dceef4" opacity="0.5"/>`
        + `<ellipse cx="${f1(W2[0])}" cy="${f1(W2[1])}" rx="${f1(7 * k)}" ry="${f1(3.4 * k)}" fill="#7aa8b8"/>`;
      rep(3, i => { f += `<ellipse cx="${f1(W1[0] + 2 * k)}" cy="${f1(W1[1] + 1 * k)}" rx="1" ry="0.5" fill="none" stroke="#e8f6fa" stroke-width="${f1(0.35 * k)}">${an('rx', `1;${f1(13 * k)}`, 3, -i)}${an('ry', `0.5;${f1(6 * k)}`, 3, -i)}${an('opacity', '0.9;0', 3, -i)}</ellipse>`; });
      [[-6.4, 0], [5, 3]].forEach(([dx, dz], i) => { const a = p(BX + dx, 42.6, BZ + dz), b = p(BX + dx * 1.15, 30, BZ + dz * 1.1); f += `<path d="M${H3.P2(a)}Q${f1(a[0] + (b[0] - a[0]) * 0.2)} ${f1((a[1] + b[1]) / 2)} ${H3.P2(b)}" stroke="#cfe6ee" stroke-width="${f1(0.7 * k)}" fill="none" stroke-dasharray="${f1(1.2 * k)} ${f1(0.8 * k)}" opacity="0.85"><animate attributeName="stroke-dashoffset" values="0;${f1(-4 * k)}" dur="0.5s" repeatCount="indefinite"/></path>`; });
      // sparrow bathing: dips + flicks droplets
      { const q = p(BX + 8, 30, BZ + 4); f += `<g transform="translate(${H3.P2(q)}) scale(${n4(k)})"><g>${H7.atV('rotate', ['0', '0', '24', '0', '0'], 2.6)}<ellipse rx="3" ry="2" fill="#8a6a4a"/><ellipse cx="-0.4" cy="0.6" rx="2.2" ry="1.2" fill="#d8c8a8"/><path d="M-2.6 -0.6l-2.4 -1.2l0.6 1.6Z" fill="#6a4a2a"/><circle cx="2.4" cy="-1.6" r="1.5" fill="#7a5a3a"/><circle cx="2.9" cy="-1.9" r="0.3" fill="#1e1e22"/><path d="M3.8 -1.6l1.1 0.3l-1.1 0.3Z" fill="#3a3028"/><path d="M-1 -1q1.6 -1.6 3 0" stroke="#5a4028" stroke-width="0.5" fill="none"/></g></g>`
        + rep(4, m => `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.4 * k)}" fill="#e8f6fa" opacity="0"><animate attributeName="cx" values="${f1(q[0])};${f1(q[0] + (m - 1.5) * 3 * k)}" dur="2.6s" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(q[1])};${f1(q[1] - 4 * k)};${f1(q[1])}" dur="2.6s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0;0.9;0" keyTimes="0;0.45;0.55;1" dur="2.6s" repeatCount="indefinite"/></circle>`).join(''); }
      // dial plate: hour lines, a ring, gnomon + its shadow creeping round
      { const cq = p(SX, 22.75, SZ); let hl = ''; rep(13, m => { const a = PI + m / 12 * PI; hl += `M${H3.P2(p(SX + Math.cos(a) * 3.4, 22.75, SZ + Math.sin(a) * 3.4))}L${H3.P2(p(SX + Math.cos(a) * 5.8, 22.75, SZ + Math.sin(a) * 5.8))}`; });
        let rg = ''; rep(25, m => { const a = m / 24 * 2 * PI; rg += (m ? 'L' : 'M') + H3.P2(p(SX + Math.cos(a) * 6, 22.75, SZ + Math.sin(a) * 6)); });
        f += `<path d="${hl}" stroke="#5a4020" stroke-width="${f1(0.3 * k)}"/><path d="${rg}" fill="none" stroke="#5a4020" stroke-width="${f1(0.25 * k)}"/>`
          + `<g transform="translate(${H3.P2(cq)})"><g>${H7.atV('rotate', ['-30', '30', '-30'], 40)}<path d="M0 0L${f1(-5 * k)} ${f1(1 * k)}" stroke="#3a2a10" stroke-width="${f1(0.8 * k)}" opacity="0.5" stroke-linecap="round"/></g></g>`
          + `<path d="M${H3.P2(cq)}L${H3.P2(p(SX + 4.4, 22.75, SZ))}L${H3.P2(p(SX, 27, SZ))}Z" fill="#b08a4a" stroke="#6a4a20" stroke-width="${f1(0.2 * k)}"/>`; }
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(-30, 0, -30), p(30, 0, 30), p(-30, 0, 30), p(30, 0, -30), p(BX, 48, BZ), p(BX - 18, 32, BZ), p(BX + 18, 32, BZ)], 4) }; };
    return D; };

  // YRD-064 HAND-CARVED BALINESE LIMESTONE BUDDHA & PAGODA LANTERNS (T4, zen8 rebuilt, same 150 x 100): a raked white-gravel garden with ripple rings
  // round mossy boulders, a seated limestone Buddha in meditation on a lotus plinth (crossed legs, robe folds, hands resting in the lap, a serene face,
  // the topknot), weathered with lichen; two stone pagoda lanterns with warm light in their fire boxes; a stone water basin fed by a bamboo spout;
  // moss cushions and a mondo-grass edge. Live: the lanterns flicker, water drips from the bamboo and rings spread in the basin.
  N.zen32b = S => { const D = { w: 150, d: 100 }, { pt, cer, wd } = H3, LS = '#d8d0bc', BX = -6, BZ = -10;
    const lantern = (x, z) => [XK.cyl(x, 1.2, z, 5, 2.4, '#a8a294', pt({ n: 6 })), XK.cyl(x, 3.6, z, 1.8, 10, '#b0aa9c', pt({ n: 8 })), XK.cyl(x, 13.6, z, 4.4, 1.6, '#a8a294', pt({ n: 6 })),
      XK.box(x, 15.2, z, 5.4, 5, 5.4, '#b0aa9c', pt({ r: 0.3 })), XK.cyl(x, 20.2, z, 6.4, 3, '#9a9488', pt({ n: 6, rg: [[0, 0, 1], [0.8, 0, 0.95], [3, 0, 0.25]] })), XK.ball(x, 24, z, 1.3, '#a8a294', pt({ k: 4, n: 10 }))];
    D.build = P => [
      XK.cyl(BX, 1.2, BZ, 13, 3, '#c8c0aa', pt({ n: 24 })), XK.ball(BX, 6.6, BZ, 10, LS, pt({ k: 5, n: 22, sy: 0.38 })), XK.cyl(BX, 7, BZ - 1, 5.6, 11, LS, pt({ n: 18, rg: [[0, 0, 1.1], [6, 0, 0.92], [11, 0, 1.05]] })),
      XK.ball(BX, 18.6, BZ - 1, 5.8, LS, pt({ k: 4, n: 16, sy: 0.5 })), XK.cyl(BX, 19.6, BZ - 1, 1.6, 2.2, LS, pt({ n: 10 })), XK.ball(BX, 24.6, BZ - 0.6, 3.7, LS, pt({ k: 5, n: 16, sy: 1.08 })), XK.ball(BX, 28.6, BZ - 0.8, 1.6, '#cdc4ae', pt({ k: 4, n: 10 })),
      ...lantern(-52, -26), ...lantern(46, -30),
      XK.ball(-40, 4, 22, 8, '#8a8680', pt({ k: 5, n: 16, sy: 0.75 })), XK.ball(30, 3.4, 26, 6, '#7e7a74', pt({ k: 5, n: 14, sy: 0.75 })), XK.ball(56, 3, 10, 5, '#8a8680', pt({ k: 5, n: 14, sy: 0.7 })),
      XK.cyl(54, 1.2, 34, 7, 6, '#9a968c', pt({ n: 18 })), XK.box(46, 1.2, 30, 2.4, 14, 2.4, '#c8b86a', wd({ r: 0.6 }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('zn64'); let f = '', un = '';
      // raked lines: straight rows, broken into rings round the rocks / plinth
      const holes = [[BX, BZ, 18], [-40, 22, 13], [30, 26, 11], [56, 10, 9], [-52, -26, 9], [46, -30, 9], [54, 34, 11]]; let rk = '';
      for (let z = -46; z <= 46; z += 3) { let seg = [], on = false; for (let x = -72; x <= 72; x += 2) { const inH = holes.some(([hx, hz, r]) => ((x - hx) / r) ** 2 + ((z - hz) / (r * 0.8)) ** 2 < 1); if (!inH) { seg.push(H3.P2(p(x, 1.25, z))); on = true; } else if (on) { if (seg.length > 1) rk += 'M' + seg.join('L'); seg = []; on = false; } } if (seg.length > 1) rk += 'M' + seg.join('L'); }
      holes.forEach(([hx, hz, r]) => { rep(3, m => { const rr = r * (0.75 + m * 0.12); let d = ''; rep(25, j => { const a = j / 24 * 2 * PI; d += (j ? 'L' : 'M') + H3.P2(p(hx + Math.cos(a) * rr, 1.25, hz + Math.sin(a) * rr * 0.8)); }); rk += d; }); });
      un += `<path d="${H7.quad(p, [-73, 0, 48], [73, 0, 48], [73, 1.2, 48], [-73, 1.2, 48])}" fill="#bdb6a6"/><path d="${H7.quad(p, [73, 0, -48], [73, 0, 48], [73, 1.2, 48], [73, 1.2, -48])}" fill="#a8a294"/><path d="${H7.quad(p, [-73, 1.2, -48], [73, 1.2, -48], [73, 1.2, 48], [-73, 1.2, 48])}" fill="#ebe6da"/>`
        + `<path d="${rk}" stroke="#b4ac98" stroke-width="${f1(0.5 * k)}" fill="none"/><path d="${rk}" stroke="#ffffff" stroke-width="${f1(0.35 * k)}" fill="none" transform="translate(0 ${f1(-0.45 * k)})" opacity="0.9"/>`;
      // moss cushions + mondo-grass edge along the front
      rep(9, () => { const q = p(-68 + R() * 136, 1.3, 40 + R() * 6); un += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((4 + R() * 4) * k)}" ry="${f1((2 + R()) * k)}" fill="#4e7a2e"/>`; });
      { let g = ''; rep(90, () => { const q = p(-70 + R() * 140, 1.3, 44 + R() * 3), h = (1.6 + R() * 2) * k; g += `M${H3.P2(q)}q${f1((R() - 0.5) * 2 * k)} ${f1(-h * 0.6)} ${f1((R() - 0.5) * 3 * k)} ${f1(-h)}`; }); f += `<path d="${g}" stroke="#2e4a22" stroke-width="${f1(0.5 * k)}" fill="none" stroke-linecap="round"/>`; }
      // moss tops on the boulders
      [[-40, 22, 8, 9.4], [30, 26, 6, 7.6], [56, 10, 5, 6.2]].forEach(([x, z, r, h]) => { const q = p(x, 1.2 + h, z); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(r * 0.7 * k)}" ry="${f1(r * 0.3 * k)}" fill="#5a8a34" opacity="0.85"/>`; });
      // Buddha details: lotus petals round the plinth, robe folds, hands, serene face, ears, curls, lichen
      rep(12, m => { const a = m / 12 * 2 * PI, q = p(BX + Math.cos(a) * 12.4, 3.4, BZ + Math.sin(a) * 12.4); if (Math.sin(a) < -0.3) return; f += `<path d="M${f1(q[0] - 2 * k)} ${f1(q[1] + 1 * k)}Q${f1(q[0])} ${f1(q[1] - 2.6 * k)} ${f1(q[0] + 2 * k)} ${f1(q[1] + 1 * k)}" fill="#d0c8b2" stroke="#a8a08a" stroke-width="${f1(0.3 * k)}"/>`; });
      { const fq = (x, y, z) => H3.P2(p(BX + x, y, BZ + z)); f += `<path d="M${fq(-5, 16, 4.6)}Q${fq(-2, 11, 5.4)} ${fq(1, 9, 8)}M${fq(4.8, 16, 4.4)}Q${fq(3, 12, 6)} ${fq(5, 9, 8.6)}M${fq(-8, 8.4, 6)}Q${fq(0, 7, 9.6)} ${fq(8, 8.4, 6)}" stroke="#b8ae96" stroke-width="${f1(0.45 * k)}" fill="none"/>`;
        const hq = p(BX, 9.6, BZ + 7.4); f += `<ellipse cx="${f1(hq[0])}" cy="${f1(hq[1])}" rx="${f1(3.4 * k)}" ry="${f1(1.4 * k)}" fill="#d8d0bc" stroke="#b0a68e" stroke-width="${f1(0.3 * k)}"/>`;
        const fc = p(BX, 24.4, BZ + 3); f += `<path d="M${f1(fc[0] - 1.6 * k)} ${f1(fc[1] - 0.6 * k)}q${f1(0.8 * k)} ${f1(0.5 * k)} ${f1(1.2 * k)} 0M${f1(fc[0] + 0.4 * k)} ${f1(fc[1] - 0.6 * k)}q${f1(0.8 * k)} ${f1(0.5 * k)} ${f1(1.2 * k)} 0" stroke="#8a8270" stroke-width="${f1(0.3 * k)}" fill="none"/><path d="M${f1(fc[0] - 0.7 * k)} ${f1(fc[1] + 1.4 * k)}q${f1(0.7 * k)} ${f1(0.4 * k)} ${f1(1.4 * k)} 0" stroke="#8a8270" stroke-width="${f1(0.3 * k)}" fill="none"/>`
          + `<ellipse cx="${f1(fc[0] - 3.7 * k)}" cy="${f1(fc[1] + 0.6 * k)}" rx="${f1(0.7 * k)}" ry="${f1(2 * k)}" fill="#cec6b0"/><ellipse cx="${f1(fc[0] + 3.7 * k)}" cy="${f1(fc[1] + 0.6 * k)}" rx="${f1(0.7 * k)}" ry="${f1(2 * k)}" fill="#cec6b0"/>`;
        rep(14, m => { const a = m / 14 * 2 * PI, q = p(BX + Math.cos(a) * 3.2, 26.6 + Math.sin(m) * 0.6, BZ - 0.6 + Math.sin(a) * 3.2); if (Math.sin(a) < -0.2) return; f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.55 * k)}" fill="#c4bca6"/>`; });
        rep(10, () => { const q = p(BX + (R() - 0.5) * 12, 4 + R() * 20, BZ + 5); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((0.5 + R() * 0.8) * k)}" ry="${f1((0.4 + R() * 0.5) * k)}" fill="${R() < 0.5 ? '#9aa86a' : '#c8c08a'}" opacity="0.7"/>`; }); }
      // lantern fire boxes: windows glowing, flicker
      [[-52, -26], [46, -30]].forEach(([x, z], i) => { const q = p(x, 17.6, z + 2.75); f += `<rect x="${f1(q[0] - 1.4 * k)}" y="${f1(q[1] - 1.6 * k)}" width="${f1(2.8 * k)}" height="${f1(2.8 * k)}" fill="#ffd27a"><animate attributeName="fill" values="#ffd27a;#ffe6a8;#ffc860;#ffd27a" dur="${2 + i * 0.4}s" repeatCount="indefinite"/></rect><circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(9 * k)}" fill="#ffd890" opacity="0.3" filter="url(#f7s)">${an('opacity', '0.22;0.4;0.26', 2.6 + i * 0.5)}</circle>`; });
      // water basin: water, bamboo spout, drip, rings
      { const wq = p(54, 7.25, 34); f += `<ellipse cx="${f1(wq[0])}" cy="${f1(wq[1])}" rx="${f1(5.4 * k)}" ry="${f1(2.6 * k)}" fill="#4a7a84"/>` + rep(2, i => `<ellipse cx="${f1(wq[0])}" cy="${f1(wq[1])}" rx="0.5" ry="0.3" fill="none" stroke="#e8f6fa" stroke-width="${f1(0.3 * k)}">${an('rx', `0.5;${f1(5 * k)}`, 2, -i)}${an('ry', `0.3;${f1(2.4 * k)}`, 2, -i)}${an('opacity', '0.9;0', 2, -i)}</ellipse>`).join('');
        const s0 = p(46, 14.4, 30), s1 = p(52, 12, 33); f += H7.tube([s0, s1], 0.9, k, '#c8b86a', '#f0e4a0', '#6a5a2a') + `<circle cx="${f1(s1[0])}" cy="${f1(s1[1])}" r="${f1(0.45 * k)}" fill="#cfe6ee"><animate attributeName="cy" values="${f1(s1[1])};${f1(wq[1])}" dur="1s" repeatCount="indefinite"/></circle>`; }
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(-74, 0, -50), p(74, 0, 50), p(-74, 0, 50), p(74, 0, -50), p(BX, 32, BZ), p(-52, 28, -26), p(46, 28, -30)], 4) }; };
    return D; };

  // YRD-084 KINETIC LEVITATING MIRROR-CHROME WIND SCULPTURE (T5, new build; was a generic pinwheel): a low plinth of polished black granite with a brass
  // inlay ring, and floating above it a mirror-chrome sphere inside three nested chrome rings that turn on different axes, reflecting sky and garden;
  // a faint cool glow under the float. Live: the sphere bobs, the rings turn at their own speeds, the glow and the shadow breathe with the bob.
  N.kin32 = S => { const D = { w: 40, d: 40, round: 1 }, { cer, mt } = H3;
    D.build = P => [XK.cyl(0, 0, 0, 10, 4, '#1c1c20', cer({ n: 24, shine: 1, rg: [[0, 0, 1], [4, 0, 0.92]] })), XK.cyl(0, 4, 0, 9.4, 0.4, '#c9a050', mt({ n: 24, shine: 1 })), XK.cyl(0, 4.4, 0, 8.6, 0.6, '#26262c', cer({ n: 24, shine: 1 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      const C = p(0, 22, 0), sr = 5 * k;
      un += `<ellipse cx="${f1(p(0, 5, 0)[0])}" cy="${f1(p(0, 5, 0)[1])}" rx="${f1(6 * k)}" ry="${f1(2.6 * k)}" fill="#000" opacity="0.35" filter="url(#f7b)">${an('rx', `${f1(6 * k)};${f1(4.6 * k)};${f1(6 * k)}`, 4, 0, SPL(2))}</ellipse>`;
      f += `<ellipse cx="${f1(p(0, 5.2, 0)[0])}" cy="${f1(p(0, 5.2, 0)[1])}" rx="${f1(7 * k)}" ry="${f1(3 * k)}" fill="#bfe8ff" opacity="0.35" filter="url(#f7b)">${an('opacity', '0.25;0.5;0.25', 4, 0, SPL(2))}</ellipse>`;
      const ring = (rx, ry, rot, dur, w, i) => `<g transform="rotate(${rot})"><g>${H7.atV('scale', ['1 1', '-1 1', '1 1'], dur, -i)}<ellipse rx="${f1(rx)}" ry="${f1(ry)}" fill="none" stroke="url(#kn32c)" stroke-width="${f1(w)}"/><ellipse rx="${f1(rx)}" ry="${f1(ry)}" fill="none" stroke="#ffffff" stroke-width="${f1(w * 0.25)}" opacity="0.6" transform="translate(${f1(-w * 0.2)} ${f1(-w * 0.2)})"/></g></g>`;
      f += `<g transform="translate(${f1(C[0])} ${f1(C[1])})"><g>${at('translate', `0 0;0 ${f1(-2.2 * k)};0 0`, 4, 0, SPL(2))}`
        + ring(12 * k, 12 * k, 0, 9, 1.1 * k, 0) + ring(9.4 * k, 9.4 * k, 60, 6.5, 0.9 * k, 1) + ring(7.4 * k, 7.4 * k, -40, 4.6, 0.8 * k, 2)
        + `<circle r="${f1(sr)}" fill="url(#kn32s)"/><ellipse cx="${f1(-1.6 * k)}" cy="${f1(-1.8 * k)}" rx="${f1(1.6 * k)}" ry="${f1(1 * k)}" fill="#ffffff" opacity="0.9"/><path d="M${f1(-sr)} ${f1(0.6 * k)}Q0 ${f1(1.8 * k)} ${f1(sr)} ${f1(0.6 * k)}" stroke="#3a4a3a" stroke-width="${f1(0.5 * k)}" fill="none" opacity="0.5"/></g></g>`;
      return { defs: (H7.FDEF || '') + '<radialGradient id="kn32s" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.35" stop-color="#cfe2ee"/><stop offset="0.55" stop-color="#6a7a88"/><stop offset="0.7" stop-color="#e8eef2"/><stop offset="1" stop-color="#8a9a7a"/></radialGradient><linearGradient id="kn32c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="0.45" stop-color="#9ab0c0"/><stop offset="0.55" stop-color="#2a3038"/><stop offset="1" stop-color="#d8e0e4"/></linearGradient>', under: un, front: f, bb: H3.bbOf([p(-12, 0, -12), p(12, 0, 12), p(-12, 0, 12), p(12, 0, -12), p(0, 40, 0), p(-14, 22, 0), p(14, 22, 0)], 4) }; };
    return D; };

  // YRD-006 SUN-BLEACHED CRACKED PLASTIC LAWN CHAIRS (T1, plus8 lawnChairs geometry kept, 2 seats): two cheap resin stacking chairs gone yellow-grey in
  // the sun, one tilted, with hairline cracks, dirty water marks on the seats, a split leg patched with silver duct tape, a missing back slat and grass
  // growing up between the legs.
  N.lawn32 = S => { const D = { w: 110, d: 50, seats: [{ x: -24, z: 2, h: 15 }, { x: 24, z: 2, h: 15 }] }, { pt } = H3, CS = ['#e4dccb', '#dcd6c6'];
    const chair = (o, cx, RS) => { [[-9, 8], [9, 8], [-9, -8], [9, -8]].forEach(([x, z]) => o.push(XK.box(cx + x, 0, z, 2.6, 14, 2.6, RS, pt({ r: 1 }))));
      o.push(XK.cush(cx, 13, 0.6, 22, 2.6, 19, RS, pt({ r: 3 })), XK.prism(cx - 10.6, cx + 10.6, [[-9.6, 15], [-7.4, 15], [-10.4, 38], [-12.8, 38]], RS, pt({ r: 3 })), XK.box(cx - 11, 21, 0, 2.2, 1.6, 18, RS, pt({ r: 0.8 })), XK.box(cx + 11, 21, 0, 2.2, 1.6, 18, RS, pt({ r: 0.8 })), XK.box(cx - 11, 14, 8.4, 2, 7, 2, RS, pt({ r: 0.8 })), XK.box(cx + 11, 14, 8.4, 2, 7, 2, RS, pt({ r: 0.8 }))); };
    D.build = P => { const o = []; chair(o, -24, CS[0]); chair(o, 24, CS[1]); return o; };
    D.fx = c => { const p = c.p, k = c.k, R = rng('lw32'); let f = '', un = '';
      [-24, 24].forEach((cx, ci) => { rep(4, i => { if (ci === 1 && i === 2) return; const y = 22 + i * 3.6, z = -9 - (y - 15) * (2.6 / 23) - 0.4, a = p(cx - 7, y, z + 0.1), b = p(cx + 7, y, z + 0.1); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}" stroke="#a8a294" stroke-width="${f1(1.1 * k)}" stroke-linecap="round"/>`; });
        if (ci === 1) { const y = 29.2, z = -9 - (y - 15) * (2.6 / 23) - 0.4; f += `<path d="M${H3.P2(p(cx - 7, y, z))}L${H3.P2(p(cx + 7, y, z))}" stroke="#6a6458" stroke-width="${f1(1.4 * k)}" stroke-linecap="round" opacity="0.6"/>`; }
        // hairline cracks + water marks on the seat
        f += `<g transform="${H3.planeH(p, 15.7, cx, 0.6)}"><path d="M-6 -4L-3 1L-5 5M4 -6l2 3l-1 3" stroke="#a8a294" stroke-width="0.3" fill="none"/><ellipse cx="2" cy="2" rx="4" ry="2.6" fill="none" stroke="#b8ae96" stroke-width="0.6" opacity="0.6"/><ellipse cx="-3" cy="-2" rx="2.4" ry="1.6" fill="#c8bea8" opacity="0.4"/></g>`;
        rep(3, () => { const q = p(cx + (R() - 0.5) * 18, 18 + R() * 16, -10.5); f += `<path d="M${H3.P2(q)}l${f1(0.8 * k)} ${f1(1.6 * k)}l${f1(-0.4 * k)} ${f1(1.4 * k)}" stroke="#9a948a" stroke-width="${f1(0.25 * k)}" fill="none"/>`; }); });
      // duct tape round the split front leg of the right chair
      { const a = p(24 + 9 + 1.4, 5, 8 + 1.4), b = p(24 + 9 + 1.4, 8, 8 + 1.4); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}" stroke="#b8bab6" stroke-width="${f1(3 * k)}"/><path d="M${H3.P2(a)}L${H3.P2(b)}" stroke="#d8dad6" stroke-width="${f1(1 * k)}" transform="translate(${f1(-0.6 * k)} 0)"/>`; }
      // grass between the legs + dirt rings where the feet stood
      { let g = ''; rep(60, () => { const cx = R() < 0.5 ? -24 : 24, q = p(cx + (R() - 0.5) * 24, 0, (R() - 0.5) * 22), h = (2 + R() * 4) * k; g += `M${H3.P2(q)}q${f1((R() - 0.5) * 2 * k)} ${f1(-h * 0.6)} ${f1((R() - 0.5) * 3 * k)} ${f1(-h)}`; }); f += `<path d="${g}" stroke="#7a9a3a" stroke-width="${f1(0.45 * k)}" fill="none" stroke-linecap="round"/>`; }
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(-40, 0, -14), p(40, 0, 14), p(-40, 0, 14), p(40, 0, -14), p(-24, 40, -12), p(24, 40, -12)], 4) }; };
    return D; };

  // ======================= PATIO SEATING =======================
  // YRD-026 FOLDING WOODEN ADIRONDACK CHAIR PAIR (T2, new build; was the generic chair; same 48 x 48 footprint and 1 seat, lowered to the real
  // Adirondack seat): a cedar Adirondack chair with a tall slatted back that fans out and rounds over, wide flat arms, a sloped slatted seat, silvering
  // grain, a plaid blanket folded over one arm and an enamel mug of cocoa on the other. Live: steam curls from the mug, the blanket fringe stirs.
  N.adk32 = S => { const D = { w: 48, d: 48, act: 'sit', seats: [{ x: 0, z: 2, h: 22 }] }, { wd, cer, pt } = H3, CD = '#c89a62';
    D.build = P => { const o = [];
      [[-17, 16], [17, 16]].forEach(([x, z]) => o.push(XK.box(x, 0, z, 3, 30, 3.4, CD, wd({ r: 0.4 }))));
      [-17, 17].forEach(x => o.push(XK.box(x, 0, -12, 3, 18, 3.4, shade(CD, 0.9), wd({ r: 0.4 })), XK.box(x, 15, 1, 2.4, 3, 30, shade(CD, 0.92), wd({ r: 0.3 }))));
      rep(6, i => { const z = 14 - i * 5, y = 21 - i * 0.9; o.push(XK.box(0, y, z, 32, 1.4, 4.2, shade(CD, 1 + (i % 2) * 0.05), wd({ r: 0.3 }))); });
      [-17, 17].forEach(x => o.push(XK.box(x, 30, 3, 8, 1.6, 34, CD, wd({ r: 0.6 }))));
      rep(5, i => { const x = -12 + i * 6; o.push(XK.prism(x - 2.4, x + 2.4, [[-12, 18], [-10, 18], [-19, 60 + (2 - Math.abs(i - 2)) * 3], [-21, 60 + (2 - Math.abs(i - 2)) * 3]], shade(CD, 0.96 + (i % 2) * 0.06), wd({}))); });
      o.push(XK.box(0, 40, -16, 30, 2, 2, shade(CD, 0.85), wd({})), XK.cyl(17, 31.6, 12, 2.2, 4, '#e8e2d6', cer({ n: 12, rg: [[0, 0, 0.9], [4, 0, 1]], shine: 1 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k, R = rng('adk32'); let f = '';
      // rounded slat tops + grain + silvering
      rep(5, i => { const x = -12 + i * 6, y = 60 + (2 - Math.abs(i - 2)) * 3, q = p(x, y + 0.4, -20); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(2.4 * k)}" ry="${f1(1.2 * k)}" fill="${shade(CD, 1.02)}"/>`; rep(3, m => { const a = p(x - 1.6 + m * 1.6, 22, -12.8), b = p(x - 1.6 + m * 1.6, y - 2, -19.8); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}" stroke="#a87a48" stroke-width="${f1(0.2 * k)}" opacity="0.6"/>`; }); });
      rep(8, () => { const q = p((R() - 0.5) * 30, 22, (R() - 0.5) * 26); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((1 + R() * 2) * k)}" ry="${f1(0.5 * k)}" fill="#b8b4a8" opacity="0.35"/>`; });
      // plaid blanket folded over the left arm, fringe stirring
      { const a = p(-21, 31.8, -4), b = p(-13, 31.8, -4), cc = p(-13, 31.8, 10), d = p(-21, 31.8, 10), dn = p(-21.4, 20, 4); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}L${H3.P2(cc)}L${H3.P2(d)}Z" fill="#b8322a"/><path d="M${H3.P2(a)}L${H3.P2(d)}L${f1(dn[0])} ${f1(dn[1] + 4 * k)}L${f1(dn[0])} ${f1(dn[1] - 8 * k)}Z" fill="#9a2a22"/>`
        + rep(4, m => `<path d="M${H3.P2(p(-21, 31.9, -4 + m * 4))}L${H3.P2(p(-13, 31.9, -4 + m * 4))}" stroke="#2a3a5a" stroke-width="${f1(0.5 * k)}"/><path d="M${H3.P2(p(-21 + m * 2.6, 31.9, -4))}L${H3.P2(p(-21 + m * 2.6, 31.9, 10))}" stroke="#e8c84a" stroke-width="${f1(0.25 * k)}"/>`).join('')
        + `<g transform="translate(${f1(dn[0])} ${f1(dn[1] + 4 * k)})"><g>${H7.atV('skewX', ['-6', '6', '-6'], 3.4)}${rep(7, m => `<path d="M${f1(-1 * k + m * 0.4 * k)} ${f1(-m * 1.6 * k)}l0 ${f1(1.6 * k)}" stroke="#9a2a22" stroke-width="${f1(0.3 * k)}"/>`).join('')}</g></g>`; }
      // mug: cocoa + handle + steam
      { const q = p(17, 35.6, 12); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(1.8 * k)}" ry="${f1(0.8 * k)}" fill="#5a3420"/><path d="M${f1(q[0] + 2 * k)} ${f1(q[1] + 1 * k)}c${f1(1.4 * k)} 0 ${f1(1.4 * k)} ${f1(2 * k)} 0 ${f1(2 * k)}" stroke="#e8e2d6" stroke-width="${f1(0.5 * k)}" fill="none"/>` + H7.smoke(q, k, { seed: 'adm', n: 3, H: 12, col: '#ffffff', op: 0.4, d: 3.4, r1: 2.4, drift: 3 }); }
      return { defs: H7.FDEF || '', front: f, bb: H3.bbOf([p(-24, 0, -24), p(24, 0, 24), p(-24, 0, 24), p(24, 0, -24), p(0, 70, -21), p(17, 50, 12)], 4) }; };
    return D; };

  // YRD-046 WOVEN ALL-WEATHER WICKER SECTIONAL SOFA WITH NAVY CUSHIONS (T3, new build; was the generic L sofa; same 214 x 150, 4 seats, sit): a dark
  // espresso resin-wicker L sectional (basket weave on every face, a woven rim), deep navy seat + back cushions with white piping, a chaise end,
  // throw pillows (white + navy stripe, coral, sand), a knitted throw over the chaise and a woven tray with a lantern + glasses on the corner.
  N.wick32 = S => { const D = { w: 214, d: 150, act: 'sit', seats: [{ x: -58, z: 12, h: 38 }, { x: -58, z: 75, h: 38 }, { x: 0, z: 12, h: 38 }, { x: 58, z: 12, h: 38 }] }, { wd, cer, pt } = H3, WK = '#5a4232', NV = '#22385a', fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {});
    const X0 = -90, X1 = 90, ZB = -30, ZF = 40, CX1 = -26, CZ1 = 100, HB = 26;
    D.build = P => [XK.box(0, 0, (ZB + ZF) / 2, X1 - X0, HB, ZF - ZB, WK, wd({ r: 1 })), XK.box((X0 + CX1) / 2, 0, (ZF + CZ1) / 2, CX1 - X0, HB, CZ1 - ZF, WK, wd({ r: 1 })),
      XK.box(0, HB, ZB + 5, X1 - X0, 30, 10, WK, wd({ r: 1.2 })), XK.box(X1 - 5, HB, (ZB + ZF) / 2, 10, 18, ZF - ZB, WK, wd({ r: 1.2 })), XK.box(X0 + 5, HB, (ZB + CZ1) / 2, 10, 18, CZ1 - ZB, WK, wd({ r: 1.2 })),
      ...[-58, 0, 52].map(x => XK.cush(x, HB, 14, x === 52 ? 50 : 56, 12, 50, NV, fb())), XK.cush(-58, HB, 72, 56, 12, 52, NV, fb()),
      ...[-58, 0, 52].map(x => XK.cush(x, HB + 10, ZB + 15, x === 52 ? 48 : 54, 22, 10, NV, fb())),
      XK.cush(-62, HB + 12, 6, 20, 16, 6, '#f2efe8', fb()), XK.cush(-36, HB + 12, 6, 18, 15, 6, '#e8785a', fb()), XK.cush(44, HB + 12, 6, 20, 16, 6, '#f2efe8', fb()), XK.cush(64, HB + 12, 8, 18, 15, 6, '#d8c8a8', fb()),
      XK.box(-58, HB + 12.2, 92, 30, 1.6, 14, '#e6dccb', fb({ r: 1 })), XK.box(-74, HB + 12.2, 92, 14, 1.2, 12, '#8a6a4a', wd({ r: 0.6 })), XK.cyl(-74, HB + 13.4, 92, 2.6, 6, '#f2f6f8', cer({ n: 12, op: 0.4 })), XK.cyl(-78.6, HB + 13.4, 89, 1.1, 3.4, '#e8f0f2', cer({ n: 10, op: 0.6 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      un += H7.glowE(p, 0, 0, 30, 110, 80, '#000000', 0.12);
      // basket weave on the visible faces: front of the main base, front + right of the chaise end, right arm
      const weave = (face, a0, a1, y0, y1, fixed) => { let d = ''; for (let y = y0 + 1.6; y < y1; y += 2.4) { let u = a0 + ((y - y0) / 2.4 % 2 < 1 ? 0 : 1.6); while (u < a1) { const u1 = Math.min(a1, u + 2.4), P = (uu, yy) => face === 'z' ? p(uu, yy, fixed) : p(fixed, yy, uu); d += `M${H3.P2(P(u, y))}L${H3.P2(P(u1, y + 0.6))}`; u += 3.2; } } return d; };
      let wv = weave('z', CX1, X1, 0, HB, ZF + 0.05) + weave('z', X0, CX1, 0, HB, CZ1 + 0.05) + weave('x', ZB, ZF, 0, HB, X1 + 0.05) + weave('x', ZF, CZ1, 0, HB, CX1 + 0.05) + weave('x', ZB, ZF, HB, HB + 18, X1 + 0.05);
      f += `<path d="${wv}" stroke="#8a6a50" stroke-width="${f1(0.55 * k)}" stroke-linecap="round" opacity="0.8"/><path d="${wv}" stroke="#2e2018" stroke-width="${f1(0.3 * k)}" stroke-linecap="round" transform="translate(0 ${f1(0.6 * k)})" opacity="0.6"/>`;
      f += `<path d="M${H3.P2(p(CX1, HB, ZF + 0.1))}L${H3.P2(p(X1, HB, ZF + 0.1))}L${H3.P2(p(X1 + 0.1, HB, ZB))}M${H3.P2(p(X0, HB, CZ1 + 0.1))}L${H3.P2(p(CX1, HB, CZ1 + 0.1))}L${H3.P2(p(CX1 + 0.1, HB, ZF))}" stroke="#3a2a1e" stroke-width="${f1(1.4 * k)}" fill="none"/>`;
      // white piping on the seat cushions' front edges + stripes on two pillows
      [[-86, -30, 39], [-28, 26, 39], [27, 78, 39], [-86, -30, 98]].forEach(([a, b, z]) => { f += `<path d="M${H3.P2(p(a + 1, HB + 11.4, z))}L${H3.P2(p(b - 1, HB + 11.4, z))}" stroke="#f2efe8" stroke-width="${f1(0.6 * k)}" opacity="0.9"/>`; });
      [[-62, 9.1], [44, 9.1]].forEach(([x, z]) => { rep(3, m => { f += `<path d="M${H3.P2(p(x - 9, HB + 15 + m * 4, z))}L${H3.P2(p(x + 9, HB + 15 + m * 4, z))}" stroke="${NV}" stroke-width="${f1(1 * k)}"/>`; }); });
      // knitted throw over the chaise edge + lantern candle
      { const a = p(-86, HB + 12.3, 60), b = p(-60, HB + 12.3, 60), cc = p(-60, HB + 12.3, 84), d = p(-86, HB + 12.3, 84); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}L${H3.P2(cc)}L${H3.P2(d)}Z" fill="#e6dccb" opacity="0.95"/>` + rep(6, m => `<path d="M${H3.P2(p(-86 + m * 4.4, HB + 12.4, 60))}L${H3.P2(p(-86 + m * 4.4, HB + 12.4, 84))}" stroke="#cfc4b0" stroke-width="${f1(0.6 * k)}" stroke-dasharray="${f1(0.8 * k)} ${f1(0.5 * k)}"/>`).join(''); }
      { const q = p(-74, HB + 17, 92); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.5 * k)}" ry="${f1(1 * k)}" fill="#ffc860">${H3.an('ry', `${f1(0.9 * k)};${f1(1.2 * k)};${f1(0.9 * k)}`, 0.9)}</ellipse>` + H7.glowE(p, -74, HB + 17, 92, 5, 5, '#ffd890', 0.4, 1); }
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(X0 - 4, 0, ZB - 4), p(X1 + 4, 0, ZF + 4), p(X0 - 4, 0, CZ1 + 4), p(X1 + 4, 0, ZB - 4), p(0, HB + 32, ZB)], 4) }; };
    return D; };

  // YRD-066 TEAK DAYBED CABANA WITH FLOWING LINEN CURTAINS (T4, new build; was the generic chaise; same 176 x 74, 1 nap seat): an oiled teak daybed
  // platform with a thick white mattress, bolsters and sand / sage pillows under a four-post teak canopy with a taut linen roof; long sheer linen
  // curtains tied back at the rear posts and flowing loose at the front; a rolled towel and a teak tray with a citrus drink on the corner.
  // Live: the front curtains billow, the back ties sway, the drink's ice glints.
  N.cabana32 = S => { const D = { w: 176, d: 74, act: 'nap', seats: [{ x: 14, z: 2, h: 32, k: 'nap' }] }, { wd, cer, pt } = H3, TK = '#9a6438', fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {}), W = 80, Z = 32, HT = 86;
    D.build = P => [XK.box(0, 0, 0, 2 * W, 22, 2 * Z, TK, wd({ r: 1 })), XK.cush(4, 22, 0, 2 * W - 16, 9, 2 * Z - 6, '#f6f3ec', fb()),
      XK.cush(-W + 14, 31, 0, 10, 10, 2 * Z - 12, '#e8e0d0', fb()), XK.cush(-W + 24, 31, -14, 8, 14, 18, '#d8c8a8', fb()), XK.cush(-W + 24, 31, 12, 8, 14, 18, '#a8b89a', fb()),
      ...[[-W, -Z], [W, -Z], [-W, Z], [W, Z]].map(([x, z]) => XK.box(x, 0, z, 4, HT, 4, TK, wd({ r: 0.3 }))), XK.box(0, HT, -Z, 2 * W + 4, 3, 4, TK, wd({ r: 0.3 })), XK.box(0, HT, Z, 2 * W + 4, 3, 4, TK, wd({ r: 0.3 })), XK.box(-W, HT, 0, 4, 3, 2 * Z, TK, wd({ r: 0.3 })), XK.box(W, HT, 0, 4, 3, 2 * Z, TK, wd({ r: 0.3 })),
      XK.box(0, HT + 2.4, 0, 2 * W, 0.6, 2 * Z, '#f4efe4', fb({})),
      XK.box(W - 18, 31, 18, 16, 1.2, 12, TK, wd({ r: 0.4 })), XK.cyl(W - 14, 32.2, 18, 1.8, 6, '#f6e8b0', cer({ n: 12, op: 0.55 })), XK.solid({ ax: 'x', sh: 'el', c: [6, 33], a: 2.6, b: 2.6, n: 14, rings: [[W - 36, 0], [W - 22, 0]], col: '#e8f0f2', mat: 'fab' })];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      // teak grain on the platform front
      rep(5, m => { f += `<path d="M${H3.P2(p(-W, 4 + m * 4, Z + 0.1))}L${H3.P2(p(W, 4 + m * 4.1, Z + 0.1))}" stroke="#7a4a28" stroke-width="${f1(0.3 * k)}" opacity="0.5"/>`; });
      // curtains: back ones tied (gathered at a tie), front ones loose and billowing
      const curtain = (x, z, s, tied, i) => { const T0 = p(x + s * 1, HT, z), T1 = p(x + s * 22, HT, z), B0 = p(x + s * 1, 0.4, z), B1 = p(x + s * (tied ? 10 : 24), 0.4, z), Ti = p(x + s * 2.6, 36, z);
        const d = tied ? `M${H3.P2(T0)}L${H3.P2(T1)}Q${f1((T1[0] + Ti[0]) / 2)} ${f1((T1[1] + Ti[1]) / 2 + 6 * k)} ${H3.P2(Ti)}Q${f1((Ti[0] + B1[0]) / 2 + s * 3 * k)} ${f1((Ti[1] + B1[1]) / 2)} ${H3.P2(B1)}L${H3.P2(B0)}Z`
          : `M${H3.P2(T0)}L${H3.P2(T1)}Q${f1(T1[0] + s * 4 * k)} ${f1((T1[1] + B1[1]) / 2)} ${H3.P2(B1)}L${H3.P2(B0)}Z`;
        let fold = ''; rep(4, m => { const t = (m + 1) / 5; fold += `M${f1(T0[0] + (T1[0] - T0[0]) * t)} ${f1(T0[1] + (T1[1] - T0[1]) * t)}Q${tied ? H3.P2(Ti) : f1(T0[0] + (T1[0] - T0[0]) * t + s * 2 * k) + ' ' + f1((T0[1] + B0[1]) / 2)} ${f1(B0[0] + (B1[0] - B0[0]) * t)} ${f1(B0[1] + (B1[1] - B0[1]) * t)}`; });
        return `<g transform="translate(${H3.P2(T0)})"><g>${H7.atV('skewX', ['0', `${s * (tied ? 1.5 : 5)}`, '0', `${-s * (tied ? 1 : 3)}`, '0'], tied ? 6 : 4.2 + i * 0.6)}<g transform="translate(${f1(-T0[0])} ${f1(-T0[1])})"><path d="${d}" fill="#faf7f0" opacity="0.75"/><path d="${fold}" stroke="#ddd5c6" stroke-width="${f1(0.5 * k)}" fill="none"/></g></g></g>` + (tied ? `<ellipse cx="${f1(Ti[0])}" cy="${f1(Ti[1])}" rx="${f1(2.6 * k)}" ry="${f1(0.9 * k)}" fill="#b8a888"/>` : ''); };
      bk += curtain(-W, -Z, 1, 1, 0) + curtain(W, -Z, -1, 1, 1);
      f += curtain(-W, Z, 1, 0, 2) + curtain(W, Z, -1, 0, 3);
      // ice glint in the drink + towel stripes
      { const q = p(W - 14, 37, 18); f += `<rect x="${f1(q[0] - 0.8 * k)}" y="${f1(q[1] - 0.6 * k)}" width="${f1(1.2 * k)}" height="${f1(1.2 * k)}" fill="#ffffff" opacity="0.7">${an('opacity', '0.3;0.9;0.3', 2.2)}</rect><path d="M${f1(q[0] + 0.6 * k)} ${f1(q[1] - 3 * k)}l${f1(1.4 * k)} ${f1(-4 * k)}" stroke="#e8402a" stroke-width="${f1(0.4 * k)}"/><circle cx="${f1(q[0] - 1.2 * k)}" cy="${f1(q[1] - 3 * k)}" r="${f1(1 * k)}" fill="#f2c21a" stroke="#e8a020" stroke-width="${f1(0.2 * k)}"/>`;
        f += `<path d="M${H3.P2(p(W - 30, 34.6, 8.7))}L${H3.P2(p(W - 30, 34.6, 3.4))}M${H3.P2(p(W - 26, 34.6, 8.7))}L${H3.P2(p(W - 26, 34.6, 3.4))}" stroke="#5a8aa0" stroke-width="${f1(0.7 * k)}"/>`; }
      return { defs: H7.FDEF || '', back: bk, front: f, bb: H3.bbOf([p(-W - 4, 0, -Z - 4), p(W + 4, 0, Z + 4), p(-W - 4, 0, Z + 4), p(W + 4, 0, -Z - 4), p(0, HT + 4, 0), p(-W - 4, HT + 4, -Z), p(W + 4, HT + 4, Z)], 4) }; };
    return D; };

  // ======================= TEXTILES (flat floor pieces; footprints + flat / noBlock kept; patterns drawn in the floor plane with planeH) =======================
  const rugD = (w, d, h, col, extra) => Object.assign({ w, d, flat: 1, noBlock: 1, build: P => [XK.box(0, 0, 0, w - 4, h, d - 4, col, H3.pt({ r: 1 }))] }, extra || {});
  const PH = (p, y, inner) => `<g transform="${H3.planeH(p, y)}">${inner}</g>`;
  // YRD-020 MUDDY COIR BRISTLE DOORMAT (T1): stiff brown coir bristles on a black rubber backing, a worn bald patch, muddy boot + paw prints, frayed
  // fibres along the edge and a dead leaf caught in it (stirring).
  N.coir32 = S => { const D = rugD(120, 72, 2.4, '#9a6a36'); D.fx = c => { const p = c.p, k = c.k, R = rng('coir32'); let s = '';
      s += `<rect x="-58" y="-34" width="116" height="68" rx="3" fill="#1e1c1a"/><rect x="-55" y="-31" width="110" height="62" rx="2" fill="#a8743a"/>`;
      const fb = ['', '', '']; rep(1100, () => { const x = -54 + R() * 108, z = -30 + R() * 60; fb[Math.floor(R() * 3)] += `M${f1(x)} ${f1(z)}l${f1((R() - 0.5) * 1.6)} ${f1((R() - 0.5) * 1.6)}`; });
      s += `<path d="${fb[0]}" stroke="#c8925a" stroke-width="0.5"/><path d="${fb[1]}" stroke="#7a5228" stroke-width="0.5"/><path d="${fb[2]}" stroke="#d8a868" stroke-width="0.4"/>`;
      s += `<ellipse cx="6" cy="2" rx="18" ry="11" fill="#6a4a2a" opacity="0.45"/>`;
      [[-30, 10, 20], [-16, -6, 14], [22, 8, -8]].forEach(([x, z, a]) => { s += `<g transform="translate(${x} ${z}) rotate(${a})"><path d="M-4 -9q4 -2 7 0q1 6 -1 9q1 3 0 7q-3 2 -6 0q-1 -4 0 -7q-2 -4 1 -9Z" fill="#4a3220" opacity="0.7"/>${rep(4, m => `<path d="M-3 ${-6 + m * 3.6}h5" stroke="#3a2416" stroke-width="0.6"/>`).join('')}</g>`; });
      rep(4, i => { const x = 30 + i * 6, z = -14 + i * 7; s += `<circle cx="${x}" cy="${z}" r="2.2" fill="#4a3220" opacity="0.65"/>` + rep(4, m => `<circle cx="${f1(x - 2 + m * 1.3)}" cy="${f1(z - 3 - (m % 3 ? 0.6 : 0))}" r="0.8" fill="#4a3220" opacity="0.65"/>`).join(''); });
      rep(30, () => { const side = R() < 0.5 ? -1 : 1, x = -55 + R() * 110; s += `<path d="M${f1(x)} ${f1(side * 31)}l${f1((R() - 0.5) * 2)} ${f1(side * (1 + R() * 2.4))}" stroke="#b8844a" stroke-width="0.5"/>`; });
      s += `<g transform="translate(-40 -16)"><g>${H7.atV('rotate', ['-6', '8', '-6'], 3.4)}<path d="M-5 0q5 -4 10 0q-5 4 -10 0Z" fill="#a8742a"/><path d="M-5 0h10" stroke="#6a4a1a" stroke-width="0.4"/></g></g>`;
      return { front: PH(p, 2.45, s), bb: H3.bbOf([p(-60, 0, -36), p(60, 0, 36), p(-60, 0, 36), p(60, 0, -36), p(0, 4, 0)], 3) }; };
    return D; };
  // YRD-040 RECYCLED PLASTIC STRIPED CAMPING MAT (T2): a woven polypropylene mat (over-under straps you can see) in teal, sand, white and coral bands,
  // taped edges, brass corner grommets, two fold creases, grass poking up at one edge. Live: one corner lifts in the breeze.
  N.camp32 = S => { const D = rugD(200, 130, 1, '#e8e2d4'); D.fx = c => { const p = c.p, k = c.k, R = rng('camp32'); let s = '', crn = '';
      const BC = ['#2a8a8a', '#e8dcc0', '#f4f1ea', '#e8705a', '#e8dcc0', '#2a8a8a', '#f4f1ea', '#e8705a', '#e8dcc0', '#2a8a8a'];
      BC.forEach((col, i) => { s += `<rect x="${-96 + i * 19.2}" y="-62" width="19.4" height="124" fill="${col}"/>`; });
      let wv = ''; for (let z = -60; z < 60; z += 2.6) for (let x = -96 + ((z + 60) / 2.6 % 2 < 1 ? 0 : 2.6); x < 96; x += 5.2) wv += `M${f1(x)} ${f1(z)}h2.4`; s += `<path d="${wv}" stroke="#000" stroke-width="2.2" opacity="0.07"/><path d="${wv}" stroke="#fff" stroke-width="0.5" opacity="0.25" transform="translate(0 -0.8)"/>`;
      s += `<path d="M-30 -62v124M34 -62v124" stroke="#000" stroke-width="1.2" opacity="0.1"/><path d="M-29 -62v124M35 -62v124" stroke="#fff" stroke-width="0.8" opacity="0.3"/>`;
      s += `<rect x="-97" y="-63" width="194" height="126" rx="1" fill="none" stroke="#1e5a6a" stroke-width="2.4"/>` + [[-93, -59], [93, -59], [-93, 59]].map(([x, z]) => `<circle cx="${x}" cy="${z}" r="2" fill="none" stroke="#c9a050" stroke-width="1.1"/>`).join('');
      rep(18, () => { const x = -96 + R() * 60; s += `<path d="M${f1(x)} 63q${f1((R() - 0.5) * 2)} -3 ${f1((R() - 0.5) * 3)} -6" stroke="#5a8a34" stroke-width="0.7" fill="none"/>`; });
      // lifting corner (front right): a triangle of the mat folding up and back down
      crn = `<g transform="translate(97 63)"><g>${H7.atV('scale', ['1 1', '1 0.6', '1 1'], 4.6)}<path d="M0 0L-26 0L0 -18Z" fill="#2a8a8a"/><path d="M0 0L-26 0L0 -18Z" fill="none" stroke="#1e5a6a" stroke-width="2"/><circle cx="-3" cy="-3" r="2" fill="none" stroke="#c9a050" stroke-width="1.1"/></g></g>`;
      return { front: PH(p, 1.05, s + crn), bb: H3.bbOf([p(-100, 0, -65), p(100, 0, 65), p(-100, 0, 65), p(100, 0, -65), p(90, 8, 60)], 3) }; };
    return D; };
  // YRD-060 INDOOR-OUTDOOR TERRACOTTA GEOMETRIC WOVEN RUG (T3): a flatweave kilim in terracotta, rust, cream, sand and charcoal: stepped diamond
  // medallions in a field of small crosses, a stepped border, a visible weft texture and knotted fringe on both short ends (stirring).
  N.kilim32 = S => { const D = rugD(200, 130, 1, '#c8643a'); D.fx = c => { const p = c.p, k = c.k, R = rng('kil32'); let s = '';
      s += `<rect x="-92" y="-62" width="184" height="124" fill="#c8643a"/><rect x="-84" y="-54" width="168" height="108" fill="#f0e2c8"/><rect x="-78" y="-48" width="156" height="96" fill="#d8784a"/>`;
      const step = (cx, cz, r, col) => { let d = ''; for (let i = 0; i < r; i += 4) d += `M${cx - r + i} ${cz - i}h${2 * (r - i)}v4h${-2 * (r - i)}Z M${cx - r + i} ${cz + i}h${2 * (r - i)}v-4h${-2 * (r - i)}Z`; return `<path d="${d}" fill="${col}"/>`; };
      [-48, 0, 48].forEach((x, i) => { s += step(x, 0, 30, '#f0e2c8') + step(x, 0, 22, '#3a2a24') + step(x, 0, 14, i % 2 ? '#e8a060' : '#a8442a') + step(x, 0, 6, '#f0e2c8'); });
      rep(28, i => { const x = -72 + (i % 7) * 24, z = -40 + Math.floor(i / 7) * 26.6; if (Math.abs(z) < 14) return; s += `<path d="M${x - 2} ${f1(z)}h4M${x} ${f1(z - 2)}v4" stroke="#3a2a24" stroke-width="1.2"/>`; });
      let b = ''; for (let x = -84; x < 84; x += 8) b += `M${x} -54l4 -4l4 4M${x} 54l4 4l4 -4`; s += `<path d="${b}" stroke="#3a2a24" stroke-width="1" fill="none"/>`;
      let wf = ''; for (let z = -61; z < 62; z += 1.4) wf += `M-92 ${f1(z)}h184`; s += `<path d="${wf}" stroke="#000" stroke-width="0.35" opacity="0.08"/>`;
      [-1, 1].forEach(sd => { let fr = ''; for (let z = -60; z <= 60; z += 3) fr += `M${sd * 92} ${z}l${sd * (4 + R() * 2)} ${f1((R() - 0.5) * 1.4)}`; s += `<g transform="translate(${sd * 92} 0)"><g>${H7.atV('skewY', ['0', `${sd * 3}`, '0'], 4 + (sd > 0 ? 0.6 : 0))}<path d="${fr}" stroke="#f0e2c8" stroke-width="0.8" transform="translate(${-sd * 92} 0)"/></g></g>`; });
      return { front: PH(p, 1.05, s), bb: H3.bbOf([p(-100, 0, -65), p(100, 0, 65), p(-100, 0, 65), p(100, 0, -65)], 3) }; };
    return D; };
  // YRD-080 HAND-LOOMED SUNBRELLA CABANA LOUNGE CARPET (T4): a soft looped outdoor carpet in navy, sand and white cabana stripes with a hand-loomed
  // texture, a wide sand cotton binding with tight stitching, tassels at the corners, warm sun dapples drifting over it.
  N.sunb32 = S => { const D = rugD(200, 130, 1.4, '#e8dcc4'); D.fx = c => { const p = c.p, k = c.k, R = rng('sun32'); let s = '';
      const SC = ['#1f3554', '#e8dcc4', '#f6f2ea', '#e8dcc4', '#1f3554', '#c8b48e', '#f6f2ea', '#1f3554', '#e8dcc4', '#f6f2ea', '#1f3554'];
      s += `<rect x="-98" y="-64" width="196" height="128" rx="3" fill="#d8c8a4"/>`; SC.forEach((col, i) => { s += `<rect x="-90" y="${f1(-56 + i * 112 / SC.length)}" width="180" height="${f1(112 / SC.length + 0.3)}" fill="${col}"/>`; });
      let lp = ''; rep(1400, () => { lp += `M${f1(-90 + R() * 180)} ${f1(-56 + R() * 112)}h0.6`; }); s += `<path d="${lp}" stroke="#000" stroke-width="0.9" stroke-linecap="round" opacity="0.09"/>`;
      s += `<rect x="-94" y="-60" width="188" height="120" rx="2" fill="none" stroke="#b8a47e" stroke-width="0.6" stroke-dasharray="2 1.4"/>`;
      [[-98, -64], [98, -64], [-98, 64], [98, 64]].forEach(([x, z], i) => { s += `<g transform="translate(${x} ${z})"><g>${H7.atV('rotate', ['-8', '8', '-8'], 3 + i * 0.4)}${rep(6, m => `<path d="M0 0l${f1(Math.sign(x) * (2 + m * 0.4))} ${f1(Math.sign(z) * (6 - m * 0.3))}" stroke="#c8b48e" stroke-width="0.8"/>`).join('')}</g></g>`; });
      s += `<g opacity="0.5">${rep(5, i => `<g>${at('translate', `0 0;${f1(6 + i * 2)} ${f1(3 + i)};0 0`, 12 + i * 2, -i * 2, SPL(2))}<ellipse cx="${f1(-60 + i * 30)}" cy="${f1(-30 + (i % 3) * 25)}" rx="${f1(14 + R() * 8)}" ry="${f1(8 + R() * 5)}" fill="#fff4d0" opacity="0.35" filter="url(#f7s)"/></g>`).join('')}</g>`;
      return { defs: H7.FDEF || '', front: PH(p, 1.45, s), bb: H3.bbOf([p(-102, 0, -68), p(102, 0, 68), p(-102, 0, 68), p(102, 0, -68)], 3) }; };
    return D; };
  // YRD-100 SELF-CLEANING HYDROPHOBIC CUSHION-WEAVE PATIO TAPESTRY (T5): a plush quilted outdoor tapestry of pearl-white pillow cells with an iridescent
  // sheen and champagne piping; water beads roll off it and glowing seams pulse as it cleans itself. Live: beads roll to the edge, seams pulse in a
  // wave, the sheen slides.
  N.hydro32 = S => { const D = rugD(200, 120, 2.6, '#f4f2ee'); D.fx = c => { const p = c.p, k = c.k, R = rng('hyd32'); let s = '';
      s += `<rect x="-98" y="-58" width="196" height="116" rx="6" fill="#ebe8e2"/>`;
      const NX = 10, NZ = 6, cw = 188 / NX, ch = 108 / NZ;
      for (let j = 0; j < NZ; j++) for (let i = 0; i < NX; i++) { const x = -94 + i * cw, z = -54 + j * ch; s += `<rect x="${f1(x + 0.8)}" y="${f1(z + 0.8)}" width="${f1(cw - 1.6)}" height="${f1(ch - 1.6)}" rx="5" fill="url(#hy32c)"/>`; }
      let sm = ''; for (let i = 1; i < NX; i++) sm += `M${f1(-94 + i * cw)} -54v108`; for (let j = 1; j < NZ; j++) sm += `M-94 ${f1(-54 + j * ch)}h188`;
      s += `<path d="${sm}" stroke="#c9a868" stroke-width="0.7"/><path d="${sm}" stroke="#9af0ff" stroke-width="1.2" opacity="0.2">${an('opacity', '0;0.55;0', 3.6)}</path>`;
      s += `<rect x="-98" y="-58" width="196" height="116" rx="6" fill="url(#hy32i)" opacity="0.5"><animate attributeName="x" values="-140;20;-140" dur="12s" repeatCount="indefinite"/></rect>`;
      rep(9, i => { const x = -80 + R() * 160, z = -40 + R() * 80, T = 4 + R() * 3, b = -R() * T, ez = z > 0 ? 62 : -62; s += `<circle cx="${f1(x)}" cy="${f1(z)}" r="${f1(1.4 + R())}" fill="#e8f8ff" stroke="#b8d8e8" stroke-width="0.3"><animate attributeName="cy" values="${f1(z)};${ez}" dur="${n4(T)}s" begin="${n4(b)}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.9;0.9;0" keyTimes="0;0.85;1" dur="${n4(T)}s" begin="${n4(b)}s" repeatCount="indefinite"/></circle>`; });
      s += `<rect x="-98" y="-58" width="196" height="116" rx="6" fill="none" stroke="#c9a868" stroke-width="1.4"/>`;
      return { defs: '<radialGradient id="hy32c" cx="40%" cy="35%" r="75%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.7" stop-color="#f0eee8"/><stop offset="1" stop-color="#d8d4cc"/></radialGradient><linearGradient id="hy32i" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.4" stop-color="#c8f0ff" stop-opacity="0.6"/><stop offset="0.6" stop-color="#ffd8f4" stop-opacity="0.6"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>', front: PH(p, 2.65, s), bb: H3.bbOf([p(-100, 0, -62), p(100, 0, 62), p(-100, 0, 62), p(100, 0, -62)], 3) }; };
    return D; };

  // ======================= HANGING SEATS (+ the last patio seat) =======================
  // sway helper: wrap svg in a group that rocks about a screen point
  const rock = (q, inner, a, dur, b) => `<g transform="translate(${f1(q[0])} ${f1(q[1])})"><g>${H7.atV('rotate', [`${-a}`, `${a}`, `${-a}`], dur, b || 0)}<g transform="translate(${f1(-q[0])} ${f1(-q[1])})">${inner}</g></g></g>`;
  // sagging hammock bed between two end points, sampled across (t along, u across)
  const hamPts = (x0, x1, yE, sag, hw) => (t, u) => [x0 + (x1 - x0) * t, yE - sag * Math.sin(PI * t) - Math.abs(u) * 1.2 * Math.sin(PI * t), u * hw * (0.55 + 0.45 * Math.sin(PI * t))];
  // YRD-010 TANGLED ROPE NET HAMMOCK BETWEEN POSTS (T1, generic hammock rebuilt, same 200 x 50 + nap seat): two grey weathered 4x4 posts (one leaning,
  // one with a split), a frayed natural-rope diamond net sagging between them, a messy extra rope knotted round one post, a few dead leaves caught in
  // the net. Live: the net sways.
  N.net32 = S => { const D = { w: 200, d: 50, act: 'nap', seats: [{ x: 0, z: 0, h: 44, k: 'nap' }] }, { wd } = H3, GW = '#9a9284';
    D.build = P => [XK.box(-86, 0, 0, 5, 74, 5, GW, wd({ r: 0.4 })), XK.box(86, 0, 0, 5, 70, 5, shade(GW, 0.92), wd({ r: 0.4 })), XK.cyl(-86, 0, 0, 7, 1.4, '#6a5236', H3.pt({ n: 10 })), XK.cyl(86, 0, 0, 7, 1.4, '#6a5236', H3.pt({ n: 10 }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('net32'); let f = '';
      const F = hamPts(-72, 72, 62, 20, 15); let nt = '', NN = 14, NU = 6;
      for (let i = 0; i <= NN; i++) { let d = ''; for (let j = 0; j <= NU; j++) { const t = (i + (j % 2) * 0.5) / NN, u = j / NU * 2 - 1; d += (j ? 'L' : 'M') + H3.P2(p(...F(Math.min(1, t), u))); } nt += d; }
      for (let j = 0; j <= NU; j++) { let d = ''; for (let i = 0; i <= NN; i++) d += (i ? 'L' : 'M') + H3.P2(p(...F(i / NN, j / NU * 2 - 1))); nt += d; }
      let ends = ''; [[-72, -84, 66], [72, 84, 62]].forEach(([xe, xp, yp]) => { rep(7, j => { const u = j / 6 * 2 - 1; ends += `M${H3.P2(p(...F(xe < 0 ? 0 : 1, u)))}L${H3.P2(p(xp, yp, 0))}`; }); });
      let net = `<path d="${ends}" stroke="#c8b088" stroke-width="${f1(0.5 * k)}"/><path d="${nt}" fill="none" stroke="#b89a68" stroke-width="${f1(0.7 * k)}" stroke-linejoin="round"/><path d="${nt}" fill="none" stroke="#e8d4a8" stroke-width="${f1(0.25 * k)}" transform="translate(${f1(-0.3 * k)} ${f1(-0.3 * k)})"/>`;
      rep(10, () => { const q = p(...F(0.15 + R() * 0.7, (R() - 0.5) * 1.6)); net += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.9 * k)}" fill="#a88a58"/>`; });
      rep(3, () => { const q = p(...F(0.3 + R() * 0.4, (R() - 0.5))); net += `<path d="M${f1(q[0] - 2 * k)} ${f1(q[1])}q${f1(2 * k)} ${f1(-1.6 * k)} ${f1(4 * k)} 0q${f1(-2 * k)} ${f1(1.6 * k)} ${f1(-4 * k)} 0Z" fill="#a8742a"/>`; });
      f += rock(p(0, 64, 0), net, 1.4, 4.4);
      // messy extra rope round the left post + the split in the right post
      { const a = p(-86, 60, 2.6); f += `<path d="M${f1(a[0] - 3 * k)} ${f1(a[1])}c${f1(2 * k)} ${f1(-2 * k)} ${f1(5 * k)} ${f1(1 * k)} ${f1(6 * k)} ${f1(2 * k)}c${f1(-2 * k)} ${f1(2 * k)} ${f1(-5 * k)} 0 ${f1(-6 * k)} ${f1(2 * k)}l${f1(1 * k)} ${f1(10 * k)}" stroke="#c8b088" stroke-width="${f1(0.8 * k)}" fill="none"/>`;
        const s0 = p(86, 40, 2.6); f += `<path d="M${H3.P2(s0)}l${f1(0.4 * k)} ${f1(10 * k)}l${f1(-0.6 * k)} ${f1(6 * k)}" stroke="#5a5448" stroke-width="${f1(0.5 * k)}" fill="none"/>`; }
      return { defs: H7.FDEF || '', front: f, bb: H3.bbOf([p(-92, 0, -8), p(92, 0, 8), p(-92, 76, 0), p(92, 76, 0), p(0, 36, 16), p(0, 36, -16)], 4) }; };
    return D; };

  // YRD-030 STRIPED CANVAS QUILTED HAMMOCK ON STEEL STAND (T2, same 200 x 50 + nap seat): a powder-coated charcoal steel arc stand, a quilted canvas bed
  // in cream / sage / terracotta stripes held flat by varnished wooden spreader bars, S-hooks and short chains, a matching pillow. Live: it rocks gently.
  N.can32 = S => { const D = { w: 200, d: 50, act: 'nap', seats: [{ x: 0, z: 0, h: 44, k: 'nap' }] }, { mt } = H3, ST = '#3a3c42';
    D.build = P => [XK.box(0, 0, 0, 170, 3, 4, ST, mt({ r: 0.6 })), XK.box(-84, 0, 0, 12, 2, 30, ST, mt({ r: 0.6 })), XK.box(84, 0, 0, 12, 2, 30, ST, mt({ r: 0.6 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      // arc arms rising to the hook points
      [-1, 1].forEach(sd => { const pts = rep(9, i => { const t = i / 8; return p(sd * (84 - t * 4), 3 + t * 70 - t * t * 4, 0); }); f += H7.tube(pts, 1.8, k, ST, '#7a7e86', '#1a1a1d'); });
      const F = hamPts(-56, 56, 50, 9, 13), SC = ['#f2ece0', '#9ab89a', '#f2ece0', '#d8784a', '#f2ece0', '#9ab89a'];
      let bed = ''; const NN = 12; for (let s0 = 0; s0 < 6; s0++) { const u0 = s0 / 6 * 2 - 1, u1 = (s0 + 1) / 6 * 2 - 1; let d = 'M'; for (let i = 0; i <= NN; i++) d += (i ? 'L' : '') + H3.P2(p(...F(i / NN, u0))); for (let i = NN; i >= 0; i--) d += 'L' + H3.P2(p(...F(i / NN, u1))); bed += `<path d="${d}Z" fill="${SC[s0]}" stroke="${shade(SC[s0], 0.85)}" stroke-width="${f1(0.3 * k)}"/>`; }
      let q = ''; for (let i = 1; i < NN; i += 2) for (let j = -2; j <= 2; j++) { const a = p(...F(i / NN, j / 3)); q += `M${f1(a[0] - 0.4 * k)} ${f1(a[1])}h${f1(0.8 * k)}`; } bed += `<path d="${q}" stroke="#8a7a62" stroke-width="${f1(0.7 * k)}" stroke-linecap="round" opacity="0.6"/>`;
      [[0, -60], [1, 60]].forEach(([t, xb]) => { const a = p(xb, 50, -15), b = p(xb, 50, 15); bed += H7.tube([a, b], 1.2, k, '#b8864e', '#e8c090', '#5a3a1a'); rep(3, m => { const z = -12 + m * 12; bed += `<path d="M${H3.P2(p(xb, 50, z))}L${H3.P2(p(xb + Math.sign(xb) * 18, 70, 0))}" stroke="#8a8e96" stroke-width="${f1(0.4 * k)}"/>`; }); });
      { const a = p(-46, 53, 0); bed += `<ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="${f1(8 * k)}" ry="${f1(4 * k)}" fill="#d8784a" stroke="#b05a34" stroke-width="${f1(0.3 * k)}"/><path d="M${f1(a[0] - 7 * k)} ${f1(a[1])}h${f1(14 * k)}" stroke="#f2ece0" stroke-width="${f1(0.8 * k)}"/>`; }
      f += rock(p(0, 70, 0), bed, 1.6, 4.8);
      return { defs: H7.FDEF || '', front: f, bb: H3.bbOf([p(-92, 0, -16), p(92, 0, 16), p(-92, 76, 0), p(92, 76, 0), p(0, 38, 16), p(0, 38, -16)], 4) }; };
    return D; };

  // YRD-050 WOVEN RATTAN HANGING EGG SWING CHAIR (T3, eggSwing rebuilt, same 80 x 70 + seat): a black steel C-stand on a weighted round base, a chain and
  // spring, an egg of honey rattan in a diagonal weave with a woven rim round the opening, a thick cream seat cushion, a back cushion and a mustard
  // pillow. Live: the egg sways and turns a touch on its chain.
  N.egg32 = S => { const D = { w: 80, d: 70, seats: [{ x: 0, z: 6, h: 32 }] }, { mt } = H3, BK = '#1e1e22';
    D.build = P => [XK.cyl(0, 0, -8, 12, 2, BK, mt({ n: 24, shine: 1, rg: [[0, 0, 1], [2, 0, 0.9]] }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      const pole = rep(12, i => { const t = i / 11; return p(0 + Math.sin(t * PI) * -2, 3 + t * 98, -8 - Math.sin(t * PI * 0.9) * 10 + t * 2); }); f += H7.tube(pole, 1.6, k, BK, '#5a5c62', '#000');
      const top = p(0, 101, -6), hk = p(0, 92, -6), C = p(0, 46, 0), rx = 17 * k, ry = 26 * k;
      let egg = `<path d="M${H3.P2(top)}L${H3.P2(hk)}" stroke="#8a8e96" stroke-width="${f1(0.6 * k)}" stroke-dasharray="${f1(1.2 * k)} ${f1(0.6 * k)}"/><path d="M${H3.P2(hk)}L${f1(C[0])} ${f1(C[1] - ry)}" stroke="#8a8e96" stroke-width="${f1(0.6 * k)}"/>`;
      egg += `<clipPath id="eg32c"><ellipse cx="${f1(C[0])}" cy="${f1(C[1])}" rx="${f1(rx)}" ry="${f1(ry)}"/></clipPath><ellipse cx="${f1(C[0])}" cy="${f1(C[1])}" rx="${f1(rx)}" ry="${f1(ry)}" fill="#b8864e"/><g clip-path="url(#eg32c)">`;
      let wv = ''; for (let d = -60; d < 60; d += 2.6) wv += `M${f1(C[0] + d * k - 40 * k)} ${f1(C[1] - 40 * k)}l${f1(80 * k)} ${f1(80 * k)}M${f1(C[0] + d * k + 40 * k)} ${f1(C[1] - 40 * k)}l${f1(-80 * k)} ${f1(80 * k)}`;
      egg += `<path d="${wv}" stroke="#7a5228" stroke-width="${f1(0.45 * k)}" opacity="0.7"/><path d="${wv}" stroke="#e8c088" stroke-width="${f1(0.2 * k)}" opacity="0.5" transform="translate(${f1(-0.4 * k)} 0)"/><ellipse cx="${f1(C[0] + 6 * k)}" cy="${f1(C[1])}" rx="${f1(rx)}" ry="${f1(ry)}" fill="#3a2414" opacity="0.25"/></g>`;
      const O = [C[0] - 1 * k, C[1] + 2 * k], orx = 12 * k, ory = 17 * k;
      egg += `<ellipse cx="${f1(O[0])}" cy="${f1(O[1])}" rx="${f1(orx)}" ry="${f1(ory)}" fill="#4a2e18"/><ellipse cx="${f1(O[0])}" cy="${f1(O[1])}" rx="${f1(orx)}" ry="${f1(ory)}" fill="none" stroke="#c8965e" stroke-width="${f1(2.2 * k)}"/><ellipse cx="${f1(O[0])}" cy="${f1(O[1])}" rx="${f1(orx)}" ry="${f1(ory)}" fill="none" stroke="#7a5228" stroke-width="${f1(1.6 * k)}" stroke-dasharray="${f1(1 * k)} ${f1(1 * k)}"/>`;
      egg += `<ellipse cx="${f1(O[0])}" cy="${f1(O[1] - 4 * k)}" rx="${f1(9 * k)}" ry="${f1(10 * k)}" fill="#ece4d4"/><ellipse cx="${f1(O[0])}" cy="${f1(O[1] + 9 * k)}" rx="${f1(10.5 * k)}" ry="${f1(5 * k)}" fill="#f4efe4"/><ellipse cx="${f1(O[0] - 1 * k)}" cy="${f1(O[1] + 8 * k)}" rx="${f1(7 * k)}" ry="${f1(2 * k)}" fill="#ffffff" opacity="0.5"/><ellipse cx="${f1(O[0] + 4 * k)}" cy="${f1(O[1] + 2 * k)}" rx="${f1(4 * k)}" ry="${f1(3.4 * k)}" fill="#e8b440"/>`;
      f += rock(hk, egg, 2.4, 5.2);
      return { defs: H7.FDEF || '', front: f, bb: H3.bbOf([p(-20, 0, -26), p(20, 0, 14), p(0, 104, -8), p(-20, 46, 0), p(20, 46, 0)], 5) }; };
    return D; };

  // YRD-070 SUSPENDED CEDAR PORCH DAYBED SWING (T4): plus8 porchSwing kept (cedar A-frame, swinging bed, mattress, pillows, 2 seats) + a hanging
  // brass lantern with a candle at one end of the beam, a trailing fern basket at the other and warm string lights wound along the beam.
  N.porch32 = S => { const D = N.porchSwing(S), f0 = D.fx, BEAM = 92; D.fx = c => { const F = f0(c) || {}, p = c.p, k = c.k; let f = '';
      { const a = p(-46, BEAM, 3.6), b = p(-46, BEAM - 14, 3.6); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}" stroke="#2a2a2e" stroke-width="${f1(0.4 * k)}"/><rect x="${f1(b[0] - 2.4 * k)}" y="${f1(b[1])}" width="${f1(4.8 * k)}" height="${f1(6.4 * k)}" fill="#ffe2a0" opacity="0.85" stroke="#c9a050" stroke-width="${f1(0.6 * k)}"/><path d="M${f1(b[0] - 3 * k)} ${f1(b[1])}L${f1(b[0])} ${f1(b[1] - 2.6 * k)}L${f1(b[0] + 3 * k)} ${f1(b[1])}Z" fill="#c9a050"/><circle cx="${f1(b[0])}" cy="${f1(b[1] + 3.4 * k)}" r="${f1(9 * k)}" fill="#ffd890" opacity="0.3" filter="url(#f7s)">${an('opacity', '0.22;0.4;0.26', 2.4)}</circle>`; }
      { const a = p(46, BEAM, 3.6), b = p(46, BEAM - 12, 3.6); let lv = ''; const R = rng('pch32'); rep(18, m => { lv += leafD(OVAL, b[0] + (R() - 0.5) * 8 * k, b[1] + 2 * k + R() * 10 * k, 0.9 * k, 150 + R() * 60, 1); });
        f += `<path d="M${H3.P2(a)}L${f1(b[0] - 3 * k)} ${f1(b[1])}M${H3.P2(a)}L${f1(b[0] + 3 * k)} ${f1(b[1])}" stroke="#8a6a4a" stroke-width="${f1(0.3 * k)}"/><ellipse cx="${f1(b[0])}" cy="${f1(b[1] + 1.4 * k)}" rx="${f1(4 * k)}" ry="${f1(2.2 * k)}" fill="#8a6a3a"/>` + rock(a, `<path d="${lv}" fill="#4e8a36"/>`, 3, 5); }
      { let sl = ''; rep(13, m => { const x = -54 + m * 9, q = p(x, BEAM + 0.8 + (m % 2) * 1.6, 3.8); sl += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.9 * k)}" fill="#ffe2a0">${an('opacity', '0.6;1;0.6', 2 + (m % 4) * 0.4, -m * 0.3)}</circle>`; }); f += `<path d="M${rep(13, m => H3.P2(p(-54 + m * 9, BEAM + 0.8 + (m % 2) * 1.6, 3.8))).join('L')}" stroke="#2a2a2e" stroke-width="${f1(0.3 * k)}" fill="none"/>` + sl; }
      return Object.assign({}, F, { defs: (F.defs || '') + (H7.FDEF || ''), front: (F.front || '') + f }); };
    return D; };

  // YRD-090 LEVITATING MAGNETIC CLOUD-HAMMOCK UNDER THE STARS (T5, generic hammock rebuilt, same 200 x 50 + nap seat): two slim obsidian pylons with
  // brass caps and blue field rings; between them a soft cloud of a hammock floating with no ropes, glowing gently underneath; above it a small night-sky
  // canopy of twinkling stars. Live: the cloud bobs and breathes, stars twinkle, the field rings pulse.
  N.cloud32 = S => { const D = { w: 200, d: 50, act: 'nap', seats: [{ x: 0, z: 0, h: 44, k: 'nap' }] }, { mt, cer } = H3;
    D.build = P => [-84, 84].flatMap(x => [XK.cyl(x, 0, 0, 7, 2, '#1c1c20', cer({ n: 18, shine: 1 })), XK.cyl(x, 2, 0, 3, 70, '#26262c', cer({ n: 16, shine: 1 })), XK.cyl(x, 72, 0, 3.8, 2, '#c9a050', mt({ n: 16, shine: 1 }))]);
    D.fx = c => { const p = c.p, k = c.k, R = rng('cld32'); let f = '', un = '';
      [-84, 84].forEach((x, i) => { rep(3, m => { const q = p(x, 30 + m * 14, 0); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(6 * k)}" ry="${f1(2.6 * k)}" fill="none" stroke="#8ad8ff" stroke-width="${f1(0.6 * k)}">${an('opacity', '0.3;1;0.3', 2.4, -m * 0.6 - i)}</ellipse>`; }); });
      un += `<ellipse cx="${f1(p(0, 0, 0)[0])}" cy="${f1(p(0, 0, 0)[1])}" rx="${f1(60 * k)}" ry="${f1(14 * k)}" fill="#8ad8ff" opacity="0.2" filter="url(#f7s)"/>`;
      // cloud: overlapping soft puffs along the bed
      let cl = ''; rep(22, i => { const t = i / 21, x = -62 + t * 124, y = 42 - Math.sin(PI * t) * 4 + (R() - 0.5) * 2, z = (R() - 0.5) * 16, q = p(x, y, z), r = (7 + Math.sin(PI * t) * 5 + R() * 3) * k; cl += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(r)}" fill="url(#cl32g)"/>`; });
      const cq = p(0, 38, 0); cl = `<ellipse cx="${f1(cq[0])}" cy="${f1(cq[1] + 6 * k)}" rx="${f1(56 * k)}" ry="${f1(10 * k)}" fill="#bfe8ff" opacity="0.45" filter="url(#f7s)">${an('opacity', '0.3;0.55;0.3', 4)}</ellipse>` + cl;
      f += `<g>${at('translate', `0 0;0 ${f1(-2 * k)};0 0`, 4.4, 0, SPL(2))}${cl}</g>`;
      // star canopy overhead
      { const q = p(0, 92, 0); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(70 * k)}" ry="${f1(16 * k)}" fill="url(#cl32s)"/>` + rep(26, i => { const a = R() * 2 * PI, r = Math.sqrt(R()); return `<circle cx="${f1(q[0] + Math.cos(a) * r * 66 * k)}" cy="${f1(q[1] + Math.sin(a) * r * 14 * k)}" r="${f1((0.3 + R() * 0.5) * k)}" fill="#fff8e0">${an('opacity', '0.2;1;0.2', 1.6 + R() * 2.4, -R() * 3)}</circle>`; }).join(''); }
      return { defs: (H7.FDEF || '') + '<radialGradient id="cl32g" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.7" stop-color="#f0f4fa"/><stop offset="1" stop-color="#c8d8ec"/></radialGradient><radialGradient id="cl32s" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#18224a" stop-opacity="0.85"/><stop offset="0.7" stop-color="#2a3a6a" stop-opacity="0.5"/><stop offset="1" stop-color="#2a3a6a" stop-opacity="0"/></radialGradient>', under: un, front: f, bb: H3.bbOf([p(-92, 0, -10), p(92, 0, 10), p(-92, 96, 0), p(92, 96, 0), p(-72, 96, 16), p(72, 96, -16)], 4) }; };
    return D; };

  // YRD-086 FLOATING POOLSIDE POD LOUNGERS WITH SOLAR COOLING MIST (T5, generic chaise rebuilt, same 176 x 74 + nap seat): a pearl-white sculpted pod
  // lounger with a sand cushion floating on a shallow turquoise pool patch, a solar-glass hood arched over the head end with a fine cooling mist drifting
  // down, a drink in a recessed holder. Live: the pod bobs, ripples run out, mist drifts, the solar cells glint.
  N.pod32 = S => { const D = { w: 176, d: 74, act: 'nap', seats: [{ x: 14, z: 2, h: 32, k: 'nap' }] }, { cer, mt } = H3, fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {});
    D.build = P => [XK.cush(4, 20, 0, 150, 10, 54, '#f4f2ee', cer({ shine: 1 })), XK.cush(10, 28, 0, 128, 4, 44, '#e8dcc4', fb()), XK.cush(-56, 30, 0, 18, 10, 40, '#e8dcc4', fb())];
    D.fx = c => { const p = c.p, k = c.k, R = rng('pod32'); let f = '', un = '';
      const pool = 'M' + rep(24, i => { const a = i / 24 * 2 * PI; return H3.P2(p(Math.cos(a) * 88, 0.3, Math.sin(a) * 36)); }).join('L') + 'Z';
      un += `<path d="${pool}" fill="#e8e2d6" transform="translate(0 ${f1(2 * k)})"/><path d="${pool}" fill="url(#pd32w)"/>` + rep(3, i => `<ellipse cx="${f1(p(0, 0.3, 0)[0])}" cy="${f1(p(0, 0.3, 0)[1])}" rx="${f1(50 * k)}" ry="${f1(16 * k)}" fill="none" stroke="#e8f8ff" stroke-width="${f1(0.5 * k)}">${an('rx', `${f1(50 * k)};${f1(86 * k)}`, 4, -i * 1.3)}${an('ry', `${f1(16 * k)};${f1(34 * k)}`, 4, -i * 1.3)}${an('opacity', '0.8;0', 4, -i * 1.3)}</ellipse>`).join('');
      un += `<ellipse cx="${f1(p(4, 0.4, 0)[0])}" cy="${f1(p(4, 0.4, 0)[1])}" rx="${f1(72 * k)}" ry="${f1(22 * k)}" fill="#0a4a5a" opacity="0.25" filter="url(#f7s)"/>`;
      // solar hood over the head end
      { const pts = rep(11, i => { const a = i / 10 * PI; return [-62 + Math.cos(a) * 0, 30 + Math.sin(a) * 26, Math.cos(a) * 26]; }); let h = ''; for (let i = 0; i < 10; i++) { const a = pts[i], b = pts[i + 1]; h += `<path d="M${H3.P2(p(a[0], a[1], a[2]))}L${H3.P2(p(b[0], b[1], b[2]))}L${H3.P2(p(b[0] + 16, b[1] - 2, b[2]))}L${H3.P2(p(a[0] + 16, a[1] - 2, a[2]))}Z" fill="#1e3a5a" opacity="0.6" stroke="#c9d6e0" stroke-width="${f1(0.4 * k)}"/>`; }
        f += h + `<path d="M${pts.map(q => H3.P2(p(...q))).join('L')}" fill="none" stroke="#e8eef2" stroke-width="${f1(1.4 * k)}"/>` + `<path d="M${H3.P2(p(-62, 56, 0))}L${H3.P2(p(-46, 54, 0))}" stroke="#ffffff" stroke-width="${f1(0.8 * k)}" opacity="0">${an('opacity', '0;0.9;0', 5)}</path>`;
        f += `<g filter="url(#f7b)">${rep(7, i => { const q = p(-56 + R() * 14, 50, (R() - 0.5) * 30), T = 4 + R() * 2, b = -R() * T; return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(2.4 * k)}" fill="#ffffff" opacity="0">${at('translate', `0 0;${f1((R() - 0.5) * 6 * k)} ${f1(16 * k)}`, T, b)}${an('opacity', '0;0.5;0', T, b)}</circle>`; }).join('')}</g>`; }
      // drink in the side holder
      { const q = p(60, 30, 22); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(2.4 * k)}" ry="${f1(1.2 * k)}" fill="#c8c0b0"/><rect x="${f1(q[0] - 1.4 * k)}" y="${f1(q[1] - 6 * k)}" width="${f1(2.8 * k)}" height="${f1(6 * k)}" fill="#f8c860" opacity="0.8"/><circle cx="${f1(q[0] + 1.4 * k)}" cy="${f1(q[1] - 6 * k)}" r="${f1(1 * k)}" fill="#7ab83a"/>`; }
      return { defs: (H7.FDEF || '') + '<radialGradient id="pd32w" cx="50%" cy="45%" r="60%"><stop offset="0" stop-color="#4ac8d8"/><stop offset="1" stop-color="#8ae4ec"/></radialGradient>', under: un, front: `<g>${at('translate', `0 0;0 ${f1(-0.8 * k)};0 0`, 4, 0, SPL(2))}</g>` + f, bb: H3.bbOf([p(-90, 0, -38), p(90, 0, 38), p(-90, 0, 38), p(90, 0, -38), p(-62, 58, 0)], 4) }; };
    return D; };

  // ======================= BENCHES =======================
  // YRD-013 CINDERBLOCK & UNPAINTED 2x4 PLANK BENCH (T1): plus8 blockBench kept + wear: the planks greyed and split with rusty nail heads, chipped block
  // corners, moss in the block holes, a cobweb under the seat and a squashed soda can by a block.
  N.block32 = S => { const D = N.blockBench(S), f0 = D.fx; D.fx = c => { const F = f0(c) || {}, p = c.p, k = c.k, R = rng('blk32'); let f = '';
      rep(10, () => { const q = p(-40 + R() * 80, 17.3, -6 + R() * 12); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((1.6 + R() * 3) * k)}" ry="${f1(0.4 * k)}" fill="#8a8478" opacity="0.4"/>`; });
      rep(3, () => { const x = -36 + R() * 72, a = p(x, 17.3, 5), b = p(x + 6 + R() * 6, 17.3, 5); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}" stroke="#5a5448" stroke-width="${f1(0.4 * k)}"/>`; });
      [-30, -10, 10, 30].forEach(x => { rep(2, m => { const q = p(x, 17.35, -4 + m * 8); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.6 * k)}" fill="#7a4420"/>`; }); });
      rep(8, () => { const q = p((R() < 0.5 ? -36 : 36) + (R() - 0.5) * 10, 3 + R() * 10, 8.2); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1((0.5 + R() * 0.7) * k)}" fill="${R() < 0.5 ? '#5a8a34' : '#9a948a'}"/>`; });
      { const a = p(-26, 4, 2), b = p(-12, 14, 2); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}M${f1(a[0])} ${f1(b[1])}L${f1(b[0])} ${f1(a[1])}M${f1((a[0] + b[0]) / 2)} ${f1(a[1])}V${f1(b[1])}" stroke="#ffffff" stroke-width="${f1(0.2 * k)}" opacity="0.6"/>`; }
      { const q = p(46, 1.6, 12); f += `<path d="M${f1(q[0] - 3 * k)} ${f1(q[1])}l${f1(1 * k)} ${f1(-2 * k)}h${f1(4 * k)}l${f1(1 * k)} ${f1(2 * k)}Z" fill="#c8282a"/><path d="M${f1(q[0] - 2 * k)} ${f1(q[1] - 1 * k)}h${f1(4 * k)}" stroke="#e8e8ec" stroke-width="${f1(0.4 * k)}"/>`; }
      return Object.assign({}, F, { front: (F.front || '') + f }); };
    return D; };
  // YRD-033 CAST-IRON PARK BENCH WITH OAK SLATS (T2): plus8 parkBench kept + age: chipped black paint on the iron showing rust, weathered oak slats with
  // grain, a few fallen leaves on the seat, a small blank brass plaque on the back rail. Live: one leaf skitters.
  N.park32 = S => { const D = N.parkBench(S), f0 = D.fx; D.fx = c => { const F = f0(c) || {}, p = c.p, k = c.k, R = rng('prk32'); let f = '';
      rep(10, () => { const q = p((R() < 0.5 ? -44 : 44) + (R() - 0.5) * 4, 4 + R() * 24, 4); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((0.5 + R() * 0.8) * k)}" ry="${f1((0.4 + R() * 0.5) * k)}" fill="#8a4420" opacity="0.75"/>`; });
      rep(5, i => { const q = p(-30 + R() * 60, 17.6, -4 + R() * 10), col = ['#c8782a', '#a84a1a', '#d8a030'][i % 3]; f += i === 0 ? `<g transform="translate(${H3.P2(q)})"><g>${at('translate', `0 0;${f1(4 * k)} ${f1(-0.6 * k)};0 0`, 5, 0, SPL(2))}<path d="M${f1(-2 * k)} 0q${f1(2 * k)} ${f1(-1.6 * k)} ${f1(4 * k)} 0q${f1(-2 * k)} ${f1(1.6 * k)} ${f1(-4 * k)} 0Z" fill="${col}"/></g></g>` : `<path d="M${f1(q[0] - 2 * k)} ${f1(q[1])}q${f1(2 * k)} ${f1(-1.6 * k)} ${f1(4 * k)} 0q${f1(-2 * k)} ${f1(1.6 * k)} ${f1(-4 * k)} 0Z" fill="${col}"/>`; });
      { const q = p(0, 31, -12.4); f += `<rect x="${f1(q[0] - 4 * k)}" y="${f1(q[1] - 1.2 * k)}" width="${f1(8 * k)}" height="${f1(2.4 * k)}" rx="${f1(0.4 * k)}" fill="#c9a050" stroke="#8a6a2a" stroke-width="${f1(0.3 * k)}"/>`; }
      return Object.assign({}, F, { front: (F.front || '') + f }); };
    return D; };
  // YRD-053 CURVED ENGLISH LIMESTONE GARDEN BENCH (T3): plus8 limeBench kept + age and garden: lichen and moss on the stone, ivy creeping up the legs,
  // a folded linen cushion and an open book on the seat. Live: the ivy stirs, the book's page lifts.
  N.lime32 = S => { const D = N.limeBench(S), f0 = D.fx; if (D.seats && D.seats.length === 3) D.seats = [D.seats[0], D.seats[2]]; D.fx = c => { const F = f0(c) || {}, p = c.p, k = c.k, R = rng('lim32b'); let f = '';
      rep(16, () => { const q = p(-36 + R() * 72, 2 + R() * 16, 6 + R() * 3); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((0.6 + R()) * k)}" ry="${f1((0.4 + R() * 0.6) * k)}" fill="${R() < 0.5 ? '#9aa86a' : '#d8d08a'}" opacity="0.7"/>`; });
      [-28, 28].forEach((x, i) => { let lv = ''; rep(7, m => { const q = p(x + (R() - 0.5) * 6, 1 + m * 2.2, 8); lv += leafD(IVY, q[0], q[1], 0.7 * k, R() * 360, 1); }); f += rock(p(x, 1, 8), `<path d="${lv}" fill="#3e7030"/>`, 2, 4 + i); });
      { const q = p(18, 19.2, 0); f += `<path d="M${f1(q[0] - 6 * k)} ${f1(q[1])}l${f1(6 * k)} ${f1(-2.4 * k)}l${f1(6 * k)} ${f1(2.4 * k)}l${f1(-6 * k)} ${f1(2.4 * k)}Z" fill="#f4efe4" stroke="#c8bca4" stroke-width="${f1(0.3 * k)}"/>`;
        const b = p(-16, 19.4, 2); f += `<path d="M${H3.P2(b)}l${f1(-4 * k)} ${f1(-1.6 * k)}l${f1(-0.4 * k)} ${f1(2 * k)}l${f1(4.4 * k)} ${f1(1.6 * k)}Z" fill="#f8f4ea" stroke="#8a6a4a" stroke-width="${f1(0.25 * k)}"/><path d="M${H3.P2(b)}l${f1(4 * k)} ${f1(-1.6 * k)}l${f1(0.4 * k)} ${f1(2 * k)}l${f1(-4.4 * k)} ${f1(1.6 * k)}Z" fill="#f8f4ea" stroke="#8a6a4a" stroke-width="${f1(0.25 * k)}"/>` + rock(b, `<path d="M${H3.P2(b)}l${f1(3 * k)} ${f1(-2.6 * k)}l${f1(0.6 * k)} ${f1(1.6 * k)}Z" fill="#ffffff" stroke="#c8bca4" stroke-width="${f1(0.2 * k)}"/>`, 10, 3); }
      return Object.assign({}, F, { front: (F.front || '') + f }); };
    return D; };
  // YRD-073 LIVE-EDGE TEAK ROOT SCULPTURAL BENCH (T4, generic bench rebuilt, same 144 x 50 + 2 seats): a thick slab of teak with its natural wavy live
  // edge, oiled to a warm glow with growth rings at the ends, resting on a sculptural base of gnarled, twisting teak roots; a linen pad at one end.
  N.root32 = S => { const D = { w: 144, d: 50, act: 'sit', seats: [{ x: -34, z: 2, h: 30 }, { x: 34, z: 2, h: 30 }] }, { wd } = H3, TK = '#a8683a';
    D.build = P => [XK.box(0, 22, 0, 136, 8, 36, TK, wd({ r: 3, shine: 1 })), XK.cush(40, 30, 2, 40, 2.4, 26, '#e8dcc4', { mat: 'fab', soft: 1 })];
    D.fx = c => { const p = c.p, k = c.k, R = rng('root32'); let f = '', bk = '';
      // roots: a gnarled core + twisting tubes from the slab underside down into the ground (behind the slab)
      [-44, 44].forEach(cx => { bk += H7.tube([p(cx, 22, 0), p(cx + 2, 12, 2), p(cx - 1, 1, 0)], 10, k, '#7a4a28', '#b07a48', '#3a2010'); rep(7, i => { const a = i / 7 * 2 * PI + R(), r0 = 3 + R() * 3, pts = rep(6, j => { const t = j / 5, ang = a + t * 1.6; return p(cx + Math.cos(ang) * (r0 + t * 16), 22 - t * 22, Math.sin(ang) * (r0 + t * 12) * 0.8); }); bk += H7.tube(pts, 3.4 - i * 0.25, k, '#8a5a32', '#c8945a', '#3a2010'); }); });
      // live edge: wavy front lip + growth rings at the end
      let le = ''; for (let x = -68; x <= 68; x += 4) le += (x === -68 ? 'M' : 'L') + H3.P2(p(x, 30 + Math.sin(x * 0.3) * 0.6, 18 + Math.sin(x * 0.17) * 2.6)); f += `<path d="${le}" stroke="#5a3418" stroke-width="${f1(0.9 * k)}" fill="none" stroke-linejoin="round" opacity="0.7"/><path d="${le}" stroke="#e8b47a" stroke-width="${f1(0.4 * k)}" fill="none" transform="translate(0 ${f1(-0.6 * k)})"/>`;
      { const q = p(68.2, 26, 0); f += rep(5, m => `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((1 + m * 1.4) * k * 0.55)}" ry="${f1((1 + m * 1.4) * k * 0.4)}" fill="none" stroke="#7a4a28" stroke-width="${f1(0.3 * k)}"/>`).join(''); }
      rep(6, m => { const z = -14 + m * 5.6; f += `<path d="M${H3.P2(p(-66, 30.05, z))}Q${H3.P2(p(0, 30.05, z + (R() - 0.5) * 6))} ${H3.P2(p(66, 30.05, z + (R() - 0.5) * 3))}" stroke="#7a4626" stroke-width="${f1(0.3 * k)}" fill="none" opacity="0.6"/>`; });
      f += `<path d="M${H3.P2(p(-64, 30.1, -10))}L${H3.P2(p(-10, 30.1, -10))}" stroke="#ffffff" stroke-width="${f1(1.2 * k)}" opacity="0.18"/>`;
      return { defs: H7.FDEF || '', back: bk, front: f, bb: H3.bbOf([p(-72, 0, -22), p(72, 0, 22), p(-72, 32, 22), p(72, 32, -22)], 4) }; };
    return D; };
  // YRD-093 HEATED GLOW-STONE CURVED AMPHITHEATER BENCH (T5, generic bench rebuilt, same 144 x 50 + 2 seats): a sweeping curved bench of warm honed
  // sandstone in two tiers, a warm amber light line under the seat lip, thin oatmeal seat pads, and a faint heat shimmer off the warm stone.
  // Live: the light line breathes, heat wisps rise.
  N.glow32 = S => { const D = { w: 144, d: 50, act: 'sit', seats: [{ x: -34, z: 2, h: 30 }, { x: 34, z: 2, h: 30 }] }, { pt } = H3, SS = '#d8c4a4', CZ = 64, A0 = -0.95, A1 = 0.95;
    const P3 = (a, r, y) => [Math.sin(a) * r, y, CZ - Math.cos(a) * r];
    D.build = P => [XK.box(0, 0, 10, 130, 0.4, 34, '#c8bca4', pt({ r: 0.4 }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('glw32'); let f = '', un = '';
      const band = (ri, ro, y) => { let d = 'M'; rep(25, i => { const a = A0 + (A1 - A0) * i / 24; d += (i ? 'L' : '') + H3.P2(p(...P3(a, ro, y))); }); rep(25, i => { const a = A1 - (A1 - A0) * i / 24; d += 'L' + H3.P2(p(...P3(a, ri, y))); }); return d + 'Z'; };
      const face = (r, y0, y1) => { let d = 'M'; rep(25, i => { const a = A0 + (A1 - A0) * i / 24; d += (i ? 'L' : '') + H3.P2(p(...P3(a, r, y1))); }); rep(25, i => { const a = A1 - (A1 - A0) * i / 24; d += 'L' + H3.P2(p(...P3(a, r, y0))); }); return d + 'Z'; };
      const endF = (a, ri, ro, y) => `M${H3.P2(p(...P3(a, ri, 0)))}L${H3.P2(p(...P3(a, ro, 0)))}L${H3.P2(p(...P3(a, ro, y)))}L${H3.P2(p(...P3(a, ri, y)))}Z`;
      un += `<path d="${band(48, 80, 0.2)}" fill="#3a2a1a" opacity="0.18" filter="url(#f7s)"/>`;
      // back tier (seat) then front step
      f += `<path d="${endF(A1, 62, 78, 28)}" fill="${shade(SS, 0.82)}"/><path d="${face(62, 0, 28)}" fill="${shade(SS, 0.9)}"/><path d="${band(62, 78, 28)}" fill="${SS}"/>`;
      let jn = ''; rep(8, i => { const a = A0 + (A1 - A0) * (i + 1) / 9; jn += `M${H3.P2(p(...P3(a, 62, 0)))}L${H3.P2(p(...P3(a, 62, 28)))}L${H3.P2(p(...P3(a, 78, 28)))}`; }); f += `<path d="${jn}" stroke="#b8a484" stroke-width="${f1(0.4 * k)}" fill="none"/>`;
      let lip = ''; rep(25, i => { const a = A0 + (A1 - A0) * i / 24; lip += (i ? 'L' : 'M') + H3.P2(p(...P3(a, 61.6, 26.4))); }); f += `<path d="${lip}" stroke="#ffc870" stroke-width="${f1(1.2 * k)}" fill="none">${an('opacity', '0.6;1;0.6', 4)}</path>`;
      f += `<path d="${endF(A1, 50, 62, 12)}" fill="${shade(SS, 0.8)}"/><path d="${face(50, 0, 12)}" fill="${shade(SS, 0.88)}"/><path d="${band(50, 62, 12)}" fill="${shade(SS, 1.04)}"/>`;
      rep(40, () => { const q = p(...P3(A0 + R() * (A1 - A0), 50 + R() * 28, R() < 0.5 ? 28.05 : 12.05)); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.3 * k)}" fill="#a89070" opacity="0.6"/>`; });
      un += `<path d="${face(52, 0.2, 0.4)}" stroke="#ffd890" stroke-width="${f1(8 * k)}" fill="none" opacity="0.25" filter="url(#f7s)"/>`;
      // seat pads
      [[-0.85, -0.2], [0.2, 0.85]].forEach(([a0, a1]) => { let d = 'M'; rep(9, i => { d += (i ? 'L' : '') + H3.P2(p(...P3(a0 + (a1 - a0) * i / 8, 77, 28.8))); }); rep(9, i => { d += 'L' + H3.P2(p(...P3(a1 - (a1 - a0) * i / 8, 63, 28.8))); }); f += `<path d="${d}Z" fill="#ece2d0" stroke="#c8b898" stroke-width="${f1(0.4 * k)}"/>`; });
      f += rep(5, i => { const q = p(...P3(-0.8 + i * 0.4, 70, 30)), T = 4 + i * 0.5; return `<path d="M${H3.P2(q)}q${f1(1.2 * k)} ${f1(-3 * k)} 0 ${f1(-6 * k)}t0 ${f1(-6 * k)}" stroke="#fff0d0" stroke-width="${f1(0.6 * k)}" fill="none" opacity="0">${at('translate', `0 0;0 ${f1(-6 * k)}`, T, -i)}${an('opacity', '0;0.45;0', T, -i)}</path>`; }).join('');
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(...P3(A0, 80, 0)), p(...P3(A1, 80, 0)), p(...P3(0, 80, 0)), p(...P3(0, 48, 0)), p(...P3(A0, 80, 40)), p(...P3(A1, 80, 40))], 6) }; };
    return D; };

  // ======================= TABLES + END TABLES =======================
  const addFx = (base, extra) => S => { const D = N[base](S), f0 = D.fx; D.fx = c => { const F = (f0 && f0(c)) || {}, X2 = extra(c, D, S) || {}; return Object.assign({}, F, { defs: (F.defs || '') + (H7.FDEF || '') + (X2.defs || ''), under: (F.under || '') + (X2.under || ''), front: (F.front || '') + (X2.front || '') }); }; return D; };
  // YRD-016 PLASTIC FOLDING PICNIC TABLE (T1, generic table rebuilt, same 120 x 76): a blow-moulded off-white plastic top gone grubby, with a water ring,
  // a scuff and a crack, grey steel folding legs with rusty feet, a crumpled paper plate and a tipped plastic cup. Live: a fly circles.
  N.fold32 = S => { const D = { w: 120, d: 76 }, { pt, mt } = H3;
    D.build = P => [XK.box(0, 27, 0, 108, 3, 62, '#e8e4da', pt({ r: 3 })), XK.box(0, 25.4, 0, 100, 1.6, 56, '#cfcac0', pt({ r: 1 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      [[-40, 1], [40, -1]].forEach(([x]) => { bk += H7.tube([p(x - 8, 0, -24), p(x + 4, 25, 24)], 1.3, k, '#8a9098', '#c8ccd2', '#3a3e44') + H7.tube([p(x - 8, 0, 24), p(x + 4, 25, -24)], 1.3, k, '#8a9098', '#c8ccd2', '#3a3e44'); [[-8, -24], [-8, 24]].forEach(([dx, z]) => { const q = p(x + dx, 0.4, z); bk += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(1.4 * k)}" ry="${f1(0.7 * k)}" fill="#7a4420"/>`; }); });
      f += `<g transform="${H3.planeH(p, 30.05)}"><rect x="-54" y="-31" width="108" height="62" rx="3" fill="none" stroke="#cfcac0" stroke-width="1"/><circle cx="-24" cy="-6" r="6" fill="none" stroke="#b8b0a0" stroke-width="1.1" opacity="0.7"/><path d="M8 -20l14 6" stroke="#a8a090" stroke-width="0.8" opacity="0.6"/><path d="M30 10l6 4l-2 6l5 5" stroke="#8a8478" stroke-width="0.5" fill="none"/>`
        + `<path d="M-6 6q8 -6 16 0q2 8 -6 10q-10 0 -10 -10Z" fill="#f8f6f0" stroke="#c8c0b0" stroke-width="0.4"/><path d="M-2 8q4 -2 8 0" stroke="#e8705a" stroke-width="0.8" fill="none"/><ellipse cx="24" cy="-16" rx="5" ry="2.6" fill="#e83a3a" opacity="0.9"/><ellipse cx="20" cy="-16" rx="1.6" ry="2.4" fill="#c82a2a"/></g>`;
      const fq = p(0, 44, 0); f += `<g transform="translate(${f1(fq[0])} ${f1(fq[1])})"><g>${at('rotate', '0;360', 3, 0)}<g transform="translate(${f1(10 * k)} 0)"><ellipse rx="${f1(0.8 * k)}" ry="${f1(0.5 * k)}" fill="#1e1e22"/><ellipse cx="${f1(-0.4 * k)}" cy="${f1(-0.6 * k)}" rx="${f1(0.7 * k)}" ry="${f1(0.3 * k)}" fill="#cfe6ee" opacity="0.7"/></g></g></g>`;
      return { defs: H7.FDEF || '', front: bk + f, bb: H3.bbOf([p(-58, 0, -34), p(58, 0, 34), p(-58, 0, 34), p(58, 0, -34), p(0, 48, 0)], 4) }; };
    return D; };
  // YRD-036 REDWOOD A-FRAME PICNIC TABLE (T2): plus8 picnic8 kept + redwood grain and knots, a jar of lemonade beaded with condensation and a citronella
  // bucket candle flickering on the table.
  N.pic32 = addFx('picnic8', c => { const p = c.p, k = c.k, R = rng('pic32'); let f = '';
    rep(10, () => { const x = -48 + R() * 96, z = -14 + R() * 28, a = p(x, 29.6, z), b = p(x + 10 + R() * 8, 29.6, z + (R() - 0.5)); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}" stroke="#6a2a18" stroke-width="${f1(0.3 * k)}" opacity="0.5"/>`; });
    { const q = p(30, 29.8, 6); f += `<rect x="${f1(q[0] - 2.4 * k)}" y="${f1(q[1] - 8 * k)}" width="${f1(4.8 * k)}" height="${f1(8 * k)}" rx="${f1(0.8 * k)}" fill="#f8e070" opacity="0.8" stroke="#e8e8e0" stroke-width="${f1(0.4 * k)}"/><rect x="${f1(q[0] - 2.2 * k)}" y="${f1(q[1] - 9.2 * k)}" width="${f1(4.4 * k)}" height="${f1(1.4 * k)}" fill="#c9cdd2"/>` + rep(6, m => `<circle cx="${f1(q[0] - 1.6 * k + (m % 3) * 1.6 * k)}" cy="${f1(q[1] - 6 * k + Math.floor(m / 3) * 3 * k)}" r="${f1(0.3 * k)}" fill="#ffffff" opacity="0.8"/>`).join(''); }
    { const q = p(-30, 29.8, -4); f += `<rect x="${f1(q[0] - 2.6 * k)}" y="${f1(q[1] - 4 * k)}" width="${f1(5.2 * k)}" height="${f1(4 * k)}" fill="#c9cdd2"/><ellipse cx="${f1(q[0])}" cy="${f1(q[1] - 5.2 * k)}" rx="${f1(0.6 * k)}" ry="${f1(1.2 * k)}" fill="#ffc860">${H3.an('ry', `${f1(1 * k)};${f1(1.4 * k)};${f1(1 * k)}`, 0.9)}</ellipse>` + H7.glowE(p, -30, 35, -4, 6, 6, '#ffd890', 0.35, 1); }
    return { front: f }; });
  // YRD-056 MOSAIC TILE & WROUGHT-IRON BISTRO TABLE (T3): plus8 mosaic8 kept + an espresso cup with steam, a little pot of basil and a sugar bowl.
  N.mos32 = addFx('mosaic8', c => { const p = c.p, k = c.k; let f = '';
    { const q = p(6, 31, 4); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(2.4 * k)}" ry="${f1(1.1 * k)}" fill="#f4f1ea"/><path d="M${f1(q[0] - 1.4 * k)} ${f1(q[1])}v${f1(-2.4 * k)}h${f1(2.8 * k)}v${f1(2.4 * k)}Z" fill="#f4f1ea" stroke="#c8c0b0" stroke-width="${f1(0.2 * k)}"/><ellipse cx="${f1(q[0])}" cy="${f1(q[1] - 2.4 * k)}" rx="${f1(1.4 * k)}" ry="${f1(0.5 * k)}" fill="#4a2a18"/>` + H7.smoke(p(6, 33.6, 4), k, { seed: 'mos', n: 3, H: 10, col: '#ffffff', op: 0.4, d: 3, r1: 2, drift: 2 }); }
    { const q = p(-8, 31, -4); let lv = ''; rep(9, m => { lv += leafD(OVAL, q[0] + (m - 4) * 0.8 * k, q[1] - 3 * k - (m % 3) * 1.2 * k, 0.8 * k, (m - 4) * 20, 1); }); f += `<path d="M${f1(q[0] - 2.2 * k)} ${f1(q[1] - 3 * k)}h${f1(4.4 * k)}l${f1(-0.6 * k)} ${f1(3.4 * k)}h${f1(-3.2 * k)}Z" fill="#c8764a"/><path d="${lv}" fill="#4e9a36"/>`; }
    return { front: f }; });
  // YRD-076 10-FOOT RECLAIMED TEAK HARVEST TABLE (T4): plus8 teak8 kept + a linen runner, brass candlesticks with flickering tapers and wine glasses that
  // catch the light.
  N.teak32 = addFx('teak8', c => { const p = c.p, k = c.k; let f = '';
    f += `<path d="${H7.quad(p, [-72, 34.2, -5], [72, 34.2, -5], [72, 34.2, 5], [-72, 34.2, 5])}" fill="#ece4d4" opacity="0.92"/>`;
    [-40, 0, 40].forEach((x, i) => { const b = p(x, 34.2, 0), t = p(x, 44, 0); f += H7.tube([b, t], 1.1, k, '#c9a050', '#fff0c0', '#6a4a10') + `<rect x="${f1(t[0] - 0.6 * k)}" y="${f1(t[1] - 7 * k)}" width="${f1(1.6 * k)}" height="${f1(7 * k)}" fill="#f8f4ea"/><ellipse cx="${f1(t[0])}" cy="${f1(t[1] - 8.2 * k)}" rx="${f1(0.6 * k)}" ry="${f1(1.2 * k)}" fill="#ffc860">${H3.an('ry', `${f1(1 * k)};${f1(1.4 * k)};${f1(1 * k)}`, 0.8 + i * 0.1)}</ellipse>` + H7.glowE(p, x, 50, 0, 8, 8, '#ffd890', 0.3, 1); });
    [[-58, 12], [-20, -12], [20, 12], [58, -12]].forEach(([x, z], i) => { const q = p(x, 34.2, z); f += `<path d="M${f1(q[0])} ${f1(q[1])}v${f1(-3 * k)}M${f1(q[0] - 1.6 * k)} ${f1(q[1])}h${f1(3.2 * k)}" stroke="#e8f0f2" stroke-width="${f1(0.4 * k)}"/><path d="M${f1(q[0] - 1.6 * k)} ${f1(q[1] - 3 * k)}q0 ${f1(-3 * k)} ${f1(1.6 * k)} ${f1(-3.4 * k)}q${f1(1.6 * k)} ${f1(0.4 * k)} ${f1(1.6 * k)} ${f1(3.4 * k)}Z" fill="#8a1a2a" opacity="0.6" stroke="#e8f0f2" stroke-width="${f1(0.3 * k)}"/><circle cx="${f1(q[0] - 0.6 * k)}" cy="${f1(q[1] - 5 * k)}" r="${f1(0.4 * k)}" fill="#ffffff">${H3.an('opacity', '0.2;1;0.2', 3, -i)}</circle>`; });
    return { front: f }; });
  // YRD-096 ILLUMINATED ONYX & WATERFALL-CHANNEL BANQUET TABLE (T5): plus8 onyx8 kept + light pulsing slowly through the honey onyx and a shimmer running
  // down the water channel.
  N.onyx32 = addFx('onyx8', c => { const p = c.p, k = c.k; let f = '';
    f += `<path d="${H7.quad(p, [-80, 31, -26], [80, 31, -26], [80, 31, 26], [-80, 31, 26])}" fill="#ffd890" opacity="0.1">${H3.an('opacity', '0.04;0.18;0.04', 6)}</path>`;
    f += `<path d="M${H3.P2(p(-80, 31.4, 0))}L${H3.P2(p(80, 31.4, 0))}" stroke="#e8fbff" stroke-width="${f1(1.2 * k)}" stroke-dasharray="${f1(4 * k)} ${f1(10 * k)}" opacity="0.7"><animate attributeName="stroke-dashoffset" values="0;${f1(-28 * k)}" dur="1.6s" repeatCount="indefinite"/></path>`;
    return { front: f }; });
  // YRD-019 UPENDED PLASTIC 5-GALLON BUCKET (T1): plus9 bucket8 kept (tap to tip) + scuffs, a hairline crack, a dirt rim where it sat, a cola can on top.
  N.bkt32 = addFx('bucket8', c => { const p = c.p, k = c.k, R = rng('bkt32'); let f = '', un = '';
    un += `<ellipse cx="${f1(p(0, 0, 0)[0])}" cy="${f1(p(0, 0, 0)[1])}" rx="${f1(16 * k)}" ry="${f1(7 * k)}" fill="#6a5236" opacity="0.35" filter="url(#f7b)"/>`;
    rep(6, () => { const a = R() * 1.6 - 0.2, q = p(Math.sin(a) * 12.4, 4 + R() * 18, Math.cos(a) * 12.4); f += `<path d="M${f1(q[0])} ${f1(q[1])}l${f1((R() - 0.5) * 3 * k)} ${f1((R() - 0.5) * 1.6 * k)}" stroke="#a85a20" stroke-width="${f1(0.4 * k)}" opacity="0.7"/>`; });
    { const q = p(4, 6, 12); f += `<path d="M${H3.P2(q)}l${f1(1 * k)} ${f1(-4 * k)}l${f1(-0.6 * k)} ${f1(-3 * k)}" stroke="#8a4a18" stroke-width="${f1(0.3 * k)}" fill="none"/>`; }
    return { under: un, front: f }; });
  // YRD-039 ROUGH-CUT TREE STUMP SIDE TABLE (T2): plus8 stump8 kept + moss on the bark, a cluster of little mushrooms at the foot, crack lines through
  // the rings. Live: an ant trail marches over the top.
  N.stp32 = addFx('stump8', c => { const p = c.p, k = c.k, R = rng('stp32'); let f = '';
    rep(14, () => { const a = R() * 1.8 - 0.4, q = p(Math.sin(a) * 15, 1 + R() * 10, Math.cos(a) * 15); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((0.6 + R()) * k)}" ry="${f1(0.5 * k)}" fill="${R() < 0.6 ? '#5a8a34' : '#7aa046'}"/>`; });
    rep(4, m => { const q = p(10 + m * 2, 0, 12 - m * 1.4), h = (2 + (m % 2) * 1.4) * k; f += `<path d="M${H3.P2(q)}v${f1(-h)}" stroke="#f2ece0" stroke-width="${f1(0.6 * k)}"/><ellipse cx="${f1(q[0])}" cy="${f1(q[1] - h)}" rx="${f1(1.4 * k)}" ry="${f1(0.8 * k)}" fill="#c8864a"/>`; });
    { const pts = rep(9, i => { const a = i / 8 * PI * 1.2; return p(Math.cos(a) * 9, 22.2, Math.sin(a) * 9); }), pth = 'M' + pts.map(H3.P2).join('L'); f += rep(5, i => `<circle r="${f1(0.35 * k)}" fill="#1e1612"><animateMotion dur="6s" begin="${-i * 1.2}s" repeatCount="indefinite" path="${pth}"/></circle>`).join(''); }
    return { front: f }; });
  // YRD-059 GLAZED COBALT CERAMIC BARREL GARDEN STOOL (T3, generic rebuilt, same 40 x 40): a barrel-shaped porcelain garden stool in deep cobalt glaze
  // with two raised nail-head bands, pierced coin openings on the sides, a glossy highlight and a white crackle glaze on the top. Live: the glaze glints.
  N.cob32 = S => { const D = { w: 40, d: 40, round: 1 }, { cer } = H3;
    D.build = P => [XK.cyl(0, 0, 0, 12, 30, '#1e3a8a', cer({ n: 28, shine: 1, rg: [[0, 0, 0.85], [6, 0, 1], [15, 0, 1.08], [24, 0, 1], [30, 0, 0.85]] }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      [4, 26].forEach(y => { rep(14, i => { const a = -0.3 + i * 0.13, r = y === 4 ? 10.6 : 10.6, q = p(Math.sin(a) * r, y, Math.cos(a) * r); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.55 * k)}" fill="#3a5ac0" stroke="#0e1e5a" stroke-width="${f1(0.15 * k)}"/>`; }); });
      rep(7, i => { const a = -0.9 + i * 0.3, q = p(Math.sin(a) * 12.9, 15, Math.cos(a) * 12.9), r = 0.9 * k; f += rep(4, m => `<circle cx="${f1(q[0] + Math.cos(m * PI / 2) * r * 0.9)}" cy="${f1(q[1] + Math.sin(m * PI / 2) * r * 0.9)}" r="${f1(r * 0.7)}" fill="#0e1430"/>`).join(''); });
      { let sc = ''; rep(13, i => { const a = -1 + i * 0.17; sc += (i ? 'L' : 'M') + H3.P2(p(Math.sin(a) * 13.2, 15 + Math.sin(i * 1.4) * 4, Math.cos(a) * 13.2)); }); f += `<path d="${sc}" stroke="#e8ecf4" stroke-width="${f1(0.4 * k)}" fill="none" opacity="0.6"/>`; }
      { const q = p(0, 30.1, 0); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(10 * k)}" ry="${f1(4.6 * k)}" fill="#e8ecf4"/><path d="M${f1(q[0] - 6 * k)} ${f1(q[1] - 1 * k)}l${f1(3 * k)} ${f1(1 * k)}l${f1(2 * k)} ${f1(-1.6 * k)}l${f1(4 * k)} ${f1(1 * k)}M${f1(q[0] - 2 * k)} ${f1(q[1] + 2 * k)}l${f1(2 * k)} ${f1(-1 * k)}l${f1(3 * k)} ${f1(1.4 * k)}" stroke="#a8b4cc" stroke-width="${f1(0.2 * k)}" fill="none"/><path d="M${f1(q[0] - 4 * k)} ${f1(q[1] - 1.6 * k)}q${f1(4 * k)} ${f1(-1 * k)} ${f1(8 * k)} 0" stroke="#3a5ac0" stroke-width="${f1(0.6 * k)}" fill="none"/>`; }
      { const a = p(-6, 24, 9), b = p(-7, 8, 9); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}" stroke="#ffffff" stroke-width="${f1(1.4 * k)}" stroke-linecap="round" opacity="0.5">${H3.an('opacity', '0.3;0.7;0.3', 4)}</path>`; }
      return { defs: H7.FDEF || '', front: f, bb: H3.bbOf([p(-14, 0, -14), p(14, 0, 14), p(0, 32, 0), p(-14, 16, 0), p(14, 16, 0)], 3) }; };
    return D; };
  // YRD-079 CAST-BRONZE LATTICE DRUM SIDE TABLE (T4, generic rebuilt, same 50 x 50): a drum of cast bronze in an open interlocking lattice with a warm
  // patina and polished high points, a smoked-glass top, and a hurricane candle inside the drum glowing through the lattice. Live: the inner candle
  // flickers, light dances through the openings.
  N.drum32 = S => { const D = { w: 50, d: 50, round: 1 }, { mt, cer } = H3, BZ = '#a8803e';
    D.build = P => [XK.cyl(0, 0, 0, 15, 1.6, BZ, mt({ n: 24, shine: 1 })), XK.cyl(0, 22.4, 0, 15, 1.6, BZ, mt({ n: 24, shine: 1 })), XK.cyl(0, 24, 0, 16, 1, '#5a5a5e', cer({ n: 26, op: 0.45, shine: 1 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '';
      const C = p(0, 12, 0); bk += `<circle cx="${f1(C[0])}" cy="${f1(C[1])}" r="${f1(12 * k)}" fill="#ffc870" opacity="0.5" filter="url(#f7s)">${H3.an('opacity', '0.35;0.6;0.4;0.55;0.35', 1.6)}</circle><rect x="${f1(C[0] - 1.6 * k)}" y="${f1(C[1] - 2 * k)}" width="${f1(3.2 * k)}" height="${f1(6 * k)}" fill="#f8f2e4"/><ellipse cx="${f1(C[0])}" cy="${f1(C[1] - 3.4 * k)}" rx="${f1(0.8 * k)}" ry="${f1(1.6 * k)}" fill="#ffd060">${H3.an('ry', `${f1(1.4 * k)};${f1(1.9 * k)};${f1(1.4 * k)}`, 0.8)}</ellipse>`;
      // lattice: interlocking diagonal bars on the near half of the drum
      const cy0 = p(0, 1.6, 0)[1]; let lt = '', lb = ''; for (let a = 0; a < 2 * PI - 0.01; a += PI / 8) { const L = rep(7, j => { const t = j / 6; return p(Math.sin(a + t * PI / 8) * 15, 1.6 + t * 20.8, Math.cos(a + t * PI / 8) * 15); }), L2 = rep(7, j => { const t = j / 6; return p(Math.sin(a + PI / 8 - t * PI / 8) * 15, 1.6 + t * 20.8, Math.cos(a + PI / 8 - t * PI / 8) * 15); }), front = p(Math.sin(a + PI / 16) * 15, 1.6, Math.cos(a + PI / 16) * 15)[1] > cy0, d = 'M' + L.map(H3.P2).join('L') + 'M' + L2.map(H3.P2).join('L'); if (front) lt += d; else lb += d; }
      bk = `<path d="${lb}" stroke="#4a3418" stroke-width="${f1(1.3 * k)}" fill="none" stroke-linecap="round"/>` + bk;
      f += `<path d="${lt}" stroke="#5a4020" stroke-width="${f1(1.9 * k)}" fill="none" stroke-linecap="round"/><path d="${lt}" stroke="#b8904a" stroke-width="${f1(1.3 * k)}" fill="none" stroke-linecap="round"/><path d="${lt}" stroke="#f4dca0" stroke-width="${f1(0.35 * k)}" fill="none" stroke-linecap="round" transform="translate(${f1(-0.3 * k)} ${f1(-0.3 * k)})" opacity="0.8"/>`;
      f += rep(6, i => { const a = -1 + i * 0.4, q = p(Math.sin(a) * 15.4, 6 + (i % 3) * 5, Math.cos(a) * 15.4); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.9 * k)}" fill="#3a5a4a" opacity="0.5"/>`; }).join('');
      f += `<ellipse cx="${f1(p(0, 25, 0)[0] - 4 * k)}" cy="${f1(p(0, 25, 0)[1] - 1 * k)}" rx="${f1(5 * k)}" ry="${f1(1 * k)}" fill="#ffffff" opacity="0.3"/>`;
      return { defs: H7.FDEF || '', back: bk, front: f, bb: H3.bbOf([p(-17, 0, -17), p(17, 0, 17), p(0, 26, 0), p(-17, 12, 0), p(17, 12, 0)], 3) }; };
    return D; };
  // YRD-099 SOLAR-CHARGING LEVITATING DRINK PEDESTAL (T5): plus9 pedestal8 kept + a glint sweeping over the solar cells and condensation beading on the
  // floating glass.
  N.ped32 = addFx('pedestal8', c => { const p = c.p, k = c.k; let f = '';
    { const q = p(0, 3, 0); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(12 * k)}" ry="${f1(5 * k)}" fill="url(#pd32g)" opacity="0.6"/>`; }
    return { front: f, defs: '<linearGradient id="pd32g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.8"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/><animate attributeName="x1" values="-1;1" dur="5s" repeatCount="indefinite"/><animate attributeName="x2" values="0;2" dur="5s" repeatCount="indefinite"/></linearGradient>' }; });

  // ======================= HEARTHS =======================
  // YRD-018 CIRCLE OF SCAVENGED BRICKS & CAMPFIRE TWIGS (T1, generic firepit rebuilt, same 90 x 90): a rough ring of mismatched broken bricks and a
  // couple of stones on scorched dirt, a tepee of twigs and sticks burning low, grey ash, a charred log end, a crumpled newspaper ball and a dented
  // marshmallow stick. Live: small flames flicker, embers float, thin smoke.
  N.camp32b = S => { const D = { w: 90, d: 90, round: 1, glow: () => ({ y: 10, r: 50 }) }, { pt } = H3, R0 = rng('cmp32');
    D.build = P => { const o = [], BC = ['#a8442a', '#b85a3a', '#8a3a24', '#c06a48', '#9a4a30']; rep(13, i => { const a = i / 13 * 2 * PI + (R0() - 0.5) * 0.15, x = Math.cos(a) * 30, z = Math.sin(a) * 30; o.push(i % 6 === 3 ? XK.ball(x, 0, z, 5, '#8a8680', pt({ k: 5, n: 12, sy: 0.7 })) : XK.box(x, 0, z, 9 + R0() * 3, 5 + R0() * 2, 5, BC[i % 5], pt({ r: 0.4 }))); }); return o; };
    D.fx = c => { const p = c.p, k = c.k, R = rng('cmp32f'); let f = '', un = '';
      const c0 = p(0, 0.2, 0); un += `<ellipse cx="${f1(c0[0])}" cy="${f1(c0[1])}" rx="${f1(34 * k)}" ry="${f1(17 * k)}" fill="#2a2018" opacity="0.6"/><ellipse cx="${f1(c0[0])}" cy="${f1(c0[1])}" rx="${f1(22 * k)}" ry="${f1(11 * k)}" fill="#8a8680" opacity="0.7"/>`;
      let tw = ''; rep(9, i => { const a = i / 9 * 2 * PI, b = p(Math.cos(a) * 14, 0.5, Math.sin(a) * 12), t = p(Math.cos(a) * 2, 16, Math.sin(a) * 2); tw += H7.tube([b, t], 0.9, k, i % 2 ? '#5a3a20' : '#2a1e14', '#8a6a4a', '#1a120a'); });
      f += tw + H7.flames(p(0, 2, 0), k * 0.75, { seed: 'cmpf', n: 4, sp: 3, h: 10, emb: 4 }) + H7.smoke(p(0, 16, 0), k, { seed: 'cmps', n: 4, H: 40, col: '#c8c4be', op: 0.3, d: 5, r1: 6, drift: 10 });
      { const q = p(26, 1.2, 14); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(3.4 * k)}" ry="${f1(2.6 * k)}" fill="#e8e4d8" stroke="#a8a49a" stroke-width="${f1(0.3 * k)}"/><path d="M${f1(q[0] - 2 * k)} ${f1(q[1] - 1 * k)}h${f1(3 * k)}M${f1(q[0] - 1.6 * k)} ${f1(q[1] + 0.6 * k)}h${f1(3 * k)}" stroke="#6a6862" stroke-width="${f1(0.3 * k)}"/>`; }
      { const a = p(-36, 0.6, 18), b = p(-14, 6, 6); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}" stroke="#a8946a" stroke-width="${f1(0.5 * k)}"/><ellipse cx="${f1(b[0])}" cy="${f1(b[1])}" rx="${f1(1.6 * k)}" ry="${f1(1.2 * k)}" fill="#f4ecd8"/><ellipse cx="${f1(b[0] + 0.4 * k)}" cy="${f1(b[1] + 0.4 * k)}" rx="${f1(1 * k)}" ry="${f1(0.6 * k)}" fill="#a86a2a"/>`; }
      un += H7.glowE(p, 0, 0, 0, 30, 18, '#ff8a3a', 0.25, 1);
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(-38, 0, -38), p(38, 0, 38), p(-38, 0, 38), p(38, 0, -38), p(0, 60, 0)], 4) }; };
    return D; };
  // YRD-038 PORTABLE STEEL BOWL FIRE PIT (T2): plus7 bowlPit kept (tap to light) + a few seasoned logs stacked beside it, a fire poker leaning on the rim.
  N.bowl32 = addFx('bowlPit', c => { const p = c.p, k = c.k; let f = '';
    rep(4, i => { const z = 40 + (i % 2) * 6, y = 2.6 + Math.floor(i / 2) * 5, a = p(30, y, z - 10 + (i % 2) * 2), b = p(46, y, z - 12 + (i % 2) * 2); f += H7.tube([a, b], 2.6, k, '#7a5232', '#a87a4a', '#3a2414') + `<ellipse cx="${f1(b[0])}" cy="${f1(b[1])}" rx="${f1(2.2 * k)}" ry="${f1(2.4 * k)}" fill="#c8a070" stroke="#7a5232" stroke-width="${f1(0.4 * k)}"/>`; });
    f += H7.tube([p(-40, 0.4, 20), p(-30, 30, 22)], 0.6, k, '#2a2a2e', '#6a6c72', '#000');
    return { front: f }; });
  // YRD-058 TERRACOTTA MEXICAN CHIMINEA (T3): plus7 chiminea kept + a little stack of wood and a terracotta saucer of pine cones beside it.
  N.chim32 = addFx('chiminea', c => { const p = c.p, k = c.k; let f = '';
    rep(3, i => { const a = p(26, 2.4 + i * 4.4, 20 - i), b = p(40, 2.4 + i * 4.4, 14 - i); f += H7.tube([a, b], 2.2, k, '#7a5232', '#a87a4a', '#3a2414') + `<ellipse cx="${f1(b[0])}" cy="${f1(b[1])}" rx="${f1(1.9 * k)}" ry="${f1(2 * k)}" fill="#c8a070" stroke="#7a5232" stroke-width="${f1(0.3 * k)}"/>`; });
    { const q = p(-30, 1, 22); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(6 * k)}" ry="${f1(3 * k)}" fill="#c4683a"/>` + rep(4, m => `<ellipse cx="${f1(q[0] - 3 * k + m * 2 * k)}" cy="${f1(q[1] - 1.6 * k - (m % 2) * 0.8 * k)}" rx="${f1(1.2 * k)}" ry="${f1(1.6 * k)}" fill="#7a4a24" stroke="#5a3418" stroke-width="${f1(0.3 * k)}"/>`).join(''); }
    return { front: f }; });
  // YRD-078 SUNKEN CONCRETE CONVERSATION PIT WITH LINEAR GAS FIRE TABLE (T4, generic firepit rebuilt, same 90 x 90): a square sunken pit edged in
  // board-formed concrete with built-in benches and charcoal cushions, a long low concrete fire table in the middle with a bed of glass beads and a row
  // of dancing flames, and a warm glow on the walls. Live: the flames dance, glass glints, the glow breathes.
  N.pit32 = S => { const D = { w: 90, d: 90, glow: () => ({ y: 10, r: 60 }) }, { pt } = H3, CC = '#a8a49c', fb = o => Object.assign({ mat: 'fab', soft: 1 }, o || {}), E = 42;
    D.build = P => [XK.box(0, 0, -E + 3, 2 * E, 4, 6, CC, pt({ r: 0.4 })), XK.box(-E + 3, 0, 0, 6, 4, 2 * E - 12, CC, pt({ r: 0.4 })), XK.box(E - 3, 0, 0, 6, 4, 2 * E - 12, CC, pt({ r: 0.4 })), XK.box(0, 0, E - 3, 2 * E, 4, 6, CC, pt({ r: 0.4 })),
      XK.cush(0, 4, -E + 10, 2 * E - 16, 3, 8, '#3a3c42', fb()), XK.cush(-E + 10, 4, 0, 8, 3, 2 * E - 28, '#3a3c42', fb()), XK.cush(E - 10, 4, 0, 8, 3, 2 * E - 28, '#3a3c42', fb()),
      XK.box(0, 0, 0, 40, 9, 14, '#b8b4ac', pt({ r: 0.4 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      // sunken floor: darker inset + board-form lines on the inner walls (drawn as the pit's depth)
      un += `<path d="${H7.quad(p, [-E + 6, 0.1, -E + 6], [E - 6, 0.1, -E + 6], [E - 6, 0.1, E - 6], [-E + 6, 0.1, E - 6])}" fill="#6a6660"/><path d="${H7.quad(p, [-E + 6, 0.1, -E + 6], [E - 6, 0.1, -E + 6], [E - 6, -10, -E + 6], [-E + 6, -10, -E + 6])}" fill="#8a8680"/>`;
      rep(4, m => { f += `<path d="M${H3.P2(p(-E, 1 + m, E))}L${H3.P2(p(E, 1 + m, E))}" stroke="#8a8680" stroke-width="${f1(0.3 * k)}" opacity="0.6"/>`; });
      // fire tray: glass beads + flames along it
      f += `<path d="${H7.quad(p, [-17, 9.05, -3], [17, 9.05, -3], [17, 9.05, 3], [-17, 9.05, 3])}" fill="#1e2a3a"/>` + rep(30, i => { const q = p(-16 + (i % 15) * 2.2, 9.1, -2 + Math.floor(i / 15) * 3); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.6 * k)}" fill="${['#8ad8e8', '#4a8ab8', '#e8f6fa'][i % 3]}"/>`; }).join('');
      f += rep(4, i => H7.flames(p(-12 + i * 8, 9.2, 0), k * 0.8, { seed: 'pit' + i, n: 2, sp: 3, h: 10, emb: 2 })).join('');
      un += H7.glowE(p, 0, 0, 0, 40, 24, '#ff9a4a', 0.3, 1);
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(-E, 0, -E), p(E, 0, E), p(-E, 0, E), p(E, 0, -E), p(0, 30, 0), p(0, -10, -E)], 4) }; };
    return D; };
  // YRD-098 FLOATING WATER-AND-FIRE OBSIDIAN OBELISK HEARTH (T5): plus7 obelisk kept + embers rising around the obelisk.
  N.obel32 = addFx('obelisk', c => { const p = c.p, k = c.k, R = rng('obl32'); let f = '';
    f += rep(8, i => { const q = p((R() - 0.5) * 50, 14, (R() - 0.5) * 50), T = 3 + R() * 2, b = -R() * T; return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.6 * k)}" fill="#ffb040" opacity="0">${at('translate', `0 0;${f1((R() - 0.5) * 8 * k)} ${f1(-40 * k)}`, T, b)}${an('opacity', '0;1;0', T, b)}</circle>`; }).join('');
    return { front: f }; });

  // ======================= ACCESSORIES =======================
  // YRD-008 RUSTY WATERING CAN & CITRONELLA TIN CANDLE (T1, generic rebuilt, same 40 x 40, zs 0.6): a dented galvanised watering can gone rusty, with a
  // long spout and rose, beside a citronella candle in a dented tin bucket with a scorched rim. Live: the candle flickers and a thin smoke curls.
  N.can32b = S => { const D = { w: 40, d: 40, round: 1 }, { mt } = H3, GV = '#9aa0a2';
    D.build = P => [XK.cyl(-4, 0, -2, 9, 16, GV, mt({ n: 20, rg: [[0, 0, 1], [16, 0, 0.88]] })), XK.cyl(12, 0, 8, 6, 8, '#b8bcc0', mt({ n: 16 })), XK.cyl(12, 7.4, 8, 5.4, 0.6, '#e8d8a8', mt({ n: 16 }))];
    D.fx = c => { const p = c.p, k = c.k, R = rng('wcan'); let f = '';
      rep(10, () => { const a = R() * 2 - 0.6, q = p(-4 + Math.sin(a) * 9, 2 + R() * 13, -2 + Math.cos(a) * 9); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((0.8 + R() * 1.4) * k)}" ry="${f1((0.6 + R()) * k)}" fill="#8a4a20" opacity="0.65"/>`; });
      { const q = p(-6, 9, 6.8); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(2.4 * k)}" ry="${f1(1.6 * k)}" fill="#5a6062" opacity="0.5"/>`; }
      f += H7.tube([p(4, 4, -2), p(18, 18, -4)], 1, k, GV, '#d8dcde', '#4a5052') + `<ellipse cx="${f1(p(19, 19, -4)[0])}" cy="${f1(p(19, 19, -4)[1])}" rx="${f1(2 * k)}" ry="${f1(1.4 * k)}" fill="#8a9092" stroke="#5a6062" stroke-width="${f1(0.3 * k)}"/>`;
      f += H7.tube([p(-4, 16, -11), p(-4, 22, -2), p(-4, 16, 7)], 0.8, k, GV, '#d8dcde', '#4a5052');
      { const q = p(12, 8, 8); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.6 * k)}" ry="${f1(1.2 * k)}" fill="#ffc860">${H3.an('ry', `${f1(1 * k)};${f1(1.4 * k)};${f1(1 * k)}`, 0.8)}</ellipse>` + H7.glowE(p, 12, 9, 8, 6, 6, '#ffd890', 0.35, 1) + H7.smoke(p(12, 10, 8), k, { seed: 'cit', n: 3, H: 14, col: '#c8c4be', op: 0.3, d: 4, r1: 2, drift: 3 }); }
      return { defs: H7.FDEF || '', front: f, bb: H3.bbOf([p(-16, 0, -14), p(22, 0, 16), p(-4, 24, 0), p(20, 22, -4), p(12, 24, 8)], 4) }; };
    return D; };
  // YRD-028 GALVANIZED BEVERAGE TUB & CHECKERED NAPKIN HOLDER (T2): plus9 tub8 kept + condensation beads on the tub and ice cubes glinting.
  N.tub32 = addFx('tub8', c => { const p = c.p, k = c.k, R = rng('tub32'); let f = '';
    rep(18, () => { const a = R() * 1.8 - 0.5, q = p(Math.sin(a) * 24, 3 + R() * 13, Math.cos(a) * 15); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1((0.3 + R() * 0.3) * k)}" fill="#ffffff" opacity="0.7"/>`; });
    rep(4, i => { const q = p((R() - 0.5) * 30, 18.4, (R() - 0.5) * 16); f += `<rect x="${f1(q[0] - 1 * k)}" y="${f1(q[1] - 1 * k)}" width="${f1(2 * k)}" height="${f1(2 * k)}" fill="#ffffff" opacity="0.6">${H3.an('opacity', '0.3;0.9;0.3', 2 + i * 0.5)}</rect>`; });
    return { front: f }; });
  // YRD-048 TERRACOTTA CITRONELLA TORCH & BOTANICAL HURRICANE LANTERN (T3, generic torch rebuilt, same 30 x 30, zs 0.6): a terracotta torch cup with a
  // flame on a bamboo pole pushed into the ground, and beside it a glass hurricane lantern with a pillar candle ringed by pressed ferns and dried
  // lemon slices. Live: both flames flicker, smoke curls.
  N.torch32 = S => { const D = { w: 30, d: 30, round: 1, glow: () => ({ y: 40, r: 40 }) }, { wd, cer } = H3;
    D.build = P => [XK.cyl(-4, 0, -4, 1.4, 56, '#c8a868', wd({ n: 10 })), XK.cyl(-4, 56, -4, 4.4, 6, '#c4683a', cer({ n: 16, rg: [[0, 0, 0.6], [6, 0, 1]] })),
      XK.cyl(8, 0, 6, 6, 1.2, '#c9a050', H3.mt({ n: 16, shine: 1 })), XK.cyl(8, 1.2, 6, 4.4, 12, '#f2f6f8', cer({ n: 18, op: 0.3, rg: [[0, 0, 0.8], [6, 0, 1.1], [12, 0, 0.7]] })), XK.cyl(8, 1.2, 6, 2.2, 6, '#f8f2e4', cer({ n: 12 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      rep(5, m => { const q = p(-4, 8 + m * 10, -2.6); f += `<path d="M${f1(q[0] - 1.2 * k)} ${f1(q[1])}h${f1(2.4 * k)}" stroke="#8a7040" stroke-width="${f1(0.5 * k)}"/>`; });
      f += H7.flames(p(-4, 62, -4), k * 0.9, { seed: 'trc', n: 3, sp: 2.4, h: 12, emb: 3 }) + H7.smoke(p(-4, 72, -4), k, { seed: 'trs', n: 3, H: 24, col: '#c8c4be', op: 0.3, d: 5, r1: 3, drift: 6 });
      { const q = p(8, 8.2, 6); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.6 * k)}" ry="${f1(1.3 * k)}" fill="#ffc860">${H3.an('ry', `${f1(1.1 * k)};${f1(1.5 * k)};${f1(1.1 * k)}`, 0.9)}</ellipse>` + H7.glowE(p, 8, 8, 6, 8, 8, '#ffd890', 0.4, 1);
        rep(3, m => { const a = -0.6 + m * 0.6, r = p(8 + Math.sin(a) * 4.6, 4 + m * 2, 6 + Math.cos(a) * 4.6); f += `<path d="${leafD(OVAL, r[0], r[1], 0.9 * k, -20 + m * 20, 0.5)}" fill="#6a9a4a" opacity="0.7"/>`; });
        const l = p(8 + 4.6 * Math.sin(1), 3, 6 + 4.6 * Math.cos(1)); f += `<circle cx="${f1(l[0])}" cy="${f1(l[1])}" r="${f1(1.4 * k)}" fill="#f2c83a" opacity="0.8" stroke="#e8a020" stroke-width="${f1(0.3 * k)}"/>`; }
      return { defs: H7.FDEF || '', front: f, bb: H3.bbOf([p(-10, 0, -10), p(14, 0, 12), p(-4, 90, -4), p(14, 14, 6)], 4) }; };
    return D; };
  // YRD-068 BRASS ICE BUCKET, CRYSTAL PITCHER & BONSAI SHEARS SET (T4, generic rebuilt, same 36 x 26 small): a polished brass ice bucket with ring
  // handles full of ice and a bottle, a cut-crystal pitcher of cucumber water, and a pair of black-and-gold bonsai shears on a walnut tray.
  // Live: light glints over the crystal and brass.
  N.ice32 = S => { const D = { w: 36, d: 26, small: 1 }, { mt, cer, wd } = H3;
    D.build = P => [XK.box(0, 0, 0, 34, 1.2, 24, '#5a3a24', wd({ r: 0.6 })), XK.cyl(-8, 1.2, -2, 5.4, 9, '#c9a050', mt({ n: 20, shine: 1, rg: [[0, 0, 0.85], [9, 0, 1]] })), XK.cyl(-9, 8, -3, 1.2, 9, '#2a4a2a', cer({ n: 10, shine: 1 })),
      XK.cyl(8, 1.2, -1, 4, 10, '#e8f4f6', cer({ n: 18, op: 0.4, shine: 1, rg: [[0, 0, 0.9], [6, 0, 1], [10, 0, 0.75]] })), XK.cyl(8, 1.2, -1, 3.6, 7, '#c8e8c8', cer({ n: 16, op: 0.5 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      [-1, 1].forEach(sd => { const q = p(-8 + sd * 5.6, 6, -2); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(1 * k)}" ry="${f1(1.4 * k)}" fill="none" stroke="#a8803a" stroke-width="${f1(0.4 * k)}"/>`; });
      rep(5, m => { const q = p(-8 + (m - 2) * 1.6, 10.3, -2 + (m % 2) * 1.6); f += `<rect x="${f1(q[0] - 0.8 * k)}" y="${f1(q[1] - 0.8 * k)}" width="${f1(1.6 * k)}" height="${f1(1.6 * k)}" fill="#f2f8fa" opacity="0.9"/>`; });
      rep(5, m => { const a = -0.8 + m * 0.4, q0 = p(8 + Math.sin(a) * 4, 2, -1 + Math.cos(a) * 4), q1 = p(8 + Math.sin(a) * 4.2, 10, -1 + Math.cos(a) * 4.2); f += `<path d="M${H3.P2(q0)}L${H3.P2(q1)}" stroke="#ffffff" stroke-width="${f1(0.3 * k)}" opacity="0.6"/>`; });
      rep(3, m => { const q = p(8 + (m - 1) * 1.6, 6 + m, 2.6); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.9 * k)}" fill="#a8d890" stroke="#6aa04a" stroke-width="${f1(0.2 * k)}" opacity="0.8"/>`; });
      { const q = p(10.6, 10, -1); f += `<path d="M${H3.P2(q)}l${f1(2.4 * k)} ${f1(-1 * k)}" stroke="#e8f4f6" stroke-width="${f1(0.6 * k)}"/>`; }
      { const a = p(2, 1.3, 8), b = p(14, 1.3, 9); f += `<path d="M${H3.P2(a)}L${H3.P2(b)}" stroke="#1e1e22" stroke-width="${f1(0.8 * k)}"/><circle cx="${f1(a[0])}" cy="${f1(a[1])}" r="${f1(1.4 * k)}" fill="none" stroke="#1e1e22" stroke-width="${f1(0.6 * k)}"/><circle cx="${f1(a[0] + 2 * k)}" cy="${f1(a[1] + 0.8 * k)}" r="${f1(1.4 * k)}" fill="none" stroke="#1e1e22" stroke-width="${f1(0.6 * k)}"/><circle cx="${f1((a[0] + b[0]) / 2)}" cy="${f1((a[1] + b[1]) / 2)}" r="${f1(0.5 * k)}" fill="#c9a050"/>`; }
      f += `<rect x="${f1(p(-14, 10, 0)[0])}" y="${f1(p(0, 14, 0)[1])}" width="${f1(4 * k)}" height="${f1(12 * k)}" fill="#ffffff" opacity="0" transform="skewX(-20)"><animate attributeName="opacity" values="0;0.5;0" dur="4s" repeatCount="indefinite"/><animate attributeName="x" values="${f1(p(-14, 10, 0)[0])};${f1(p(14, 10, 0)[0])}" dur="4s" repeatCount="indefinite"/></rect>`;
      return { defs: H7.FDEF || '', front: f, bb: H3.bbOf([p(-18, 0, -13), p(18, 0, 13), p(-18, 0, 13), p(18, 0, -13), p(-9, 18, -3), p(8, 14, -1)], 3) }; };
    return D; };
  // YRD-088 HOLOGRAPHIC STAR-MAP GLOBE & SELF-CHILLING LEVITATING CARAFE (T5): plus9 globe8 kept + constellation lines drawn over the globe and frost
  // breathing off the floating carafe.
  N.glb32 = addFx('globe8', c => { const p = c.p, k = c.k, R = rng('glb32'); let f = '';
    const C = p(0, 50, 0); let cl = ''; rep(4, () => { let x = (R() - 0.5) * 18 * k, y = (R() - 0.5) * 18 * k; cl += `M${f1(C[0] + x)} ${f1(C[1] + y)}`; rep(3, () => { x += (R() - 0.5) * 8 * k; y += (R() - 0.5) * 8 * k; cl += `L${f1(C[0] + x)} ${f1(C[1] + y)}`; }); });
    f += `<path d="${cl}" stroke="#c8f4ff" stroke-width="${f1(0.3 * k)}" fill="none" opacity="0.7">${H3.an('opacity', '0.3;0.8;0.3', 3)}</path>`;
    return { front: f }; });

  // ======================= PLANT BEDS + TREES (existing flora / plus8 builds kept, realism added in fx) =======================
  const gWeeds = (p, k, R, n, cx, cz, rx, rz, col) => { let g = ''; rep(n, () => { const a = R() * 2 * PI, r = Math.sqrt(R()), q = p(cx + Math.cos(a) * r * rx, 0, cz + Math.sin(a) * r * rz), h = (2 + R() * 4) * k; g += `M${H3.P2(q)}q${f1((R() - 0.5) * 2 * k)} ${f1(-h * 0.6)} ${f1((R() - 0.5) * 3 * k)} ${f1(-h)}`; }); return `<path d="${g}" stroke="${col || '#6a8a34'}" stroke-width="${f1(0.5 * k)}" fill="none" stroke-linecap="round"/>`; };
  // YRD-007 OLD RUBBER TIRE FILLED WITH POTTING SOIL (T1): tread blocks and sidewall cracks on the tire, potting soil spilled on the ground, weeds round
  // it and one marigold wilting over the rim.
  N.tire32 = addFx('flora', c => { const p = c.p, k = c.k, R = rng('tire32'); let f = '', un = '';
    un += `<ellipse cx="${f1(p(14, 0, 16)[0])}" cy="${f1(p(14, 0, 16)[1])}" rx="${f1(10 * k)}" ry="${f1(4 * k)}" fill="#3a2a1a" opacity="0.6"/>`;
    rep(22, i => { const a = i / 22 * 2 * PI; if (Math.sin(a) < -0.2) return; const q0 = p(Math.cos(a) * 25, 2, Math.sin(a) * 22), q1 = p(Math.cos(a) * 25, 8, Math.sin(a) * 22); f += `<path d="M${H3.P2(q0)}L${H3.P2(q1)}" stroke="#3a3a3e" stroke-width="${f1(0.8 * k)}"/>`; });
    rep(4, () => { const a = R() * 2 - 0.4, q = p(Math.cos(a) * 25, 5, Math.sin(a) * 22); f += `<path d="M${f1(q[0] - 2 * k)} ${f1(q[1])}l${f1(1.4 * k)} ${f1(-0.6 * k)}l${f1(1.4 * k)} ${f1(0.8 * k)}" stroke="#5a5a60" stroke-width="${f1(0.3 * k)}" fill="none"/>`; });
    f += gWeeds(p, k, R, 40, 0, 0, 34, 30, '#7a9a3a');
    return { under: un, front: f }; });
  // YRD-027 CEDAR RAISED VEGETABLE GARDEN BED (T2): rows of vegetables in the soil: butterhead lettuce rosettes, feathery carrot tops, a staked tomato
  // with red and green fruit, little wooden row markers and a trowel. Live: the leaves stir.
  N.veg32 = addFx('cedarBed8', c => { const p = c.p, k = c.k, R = rng('veg32'); let f = '';
    const TY = 16.4;
    rep(5, i => { const q = p(-46 + i * 12, TY, -16); let l = ''; rep(9, m => { l += leafD(OVAL, q[0], q[1], (1.9 + (m % 3) * 0.4) * k, m * 40, 1); }); f += `<path d="${l}" fill="${i % 2 ? '#8acc5a' : '#6ab84a'}" stroke="#4a8a34" stroke-width="${f1(0.15 * k)}"/><circle cx="${f1(q[0])}" cy="${f1(q[1] - 1 * k)}" r="${f1(1.2 * k)}" fill="#c8e88a"/>`; });
    rep(7, i => { const q = p(-48 + i * 9, TY, 0); let fr = ''; rep(5, m => { const a = -2.4 + m * 0.4; fr += `M${H3.P2(q)}q${f1(Math.cos(a) * 2 * k)} ${f1(-3 * k)} ${f1(Math.cos(a) * 4 * k)} ${f1(-6 * k)}`; }); f += rock(q, `<path d="${fr}" stroke="#4e9a36" stroke-width="${f1(0.5 * k)}" fill="none"/><ellipse cx="${f1(q[0])}" cy="${f1(q[1] + 0.4 * k)}" rx="${f1(0.9 * k)}" ry="${f1(0.5 * k)}" fill="#e87a2a"/>`, 4, 3 + i * 0.3); });
    { const b = p(36, TY, 12), t = p(36, TY + 30, 12); f += H7.tube([b, t], 0.6, k, '#b8945a', '#e8c890', '#5a4020'); let lv = ''; rep(16, m => { lv += leafD(OVAL, b[0] + (R() - 0.5) * 10 * k, b[1] - 4 * k - R() * 22 * k, 1.1 * k, R() * 360, 1); }); f += `<path d="${lv}" fill="#3e7a2e"/>` + rep(6, m => `<circle cx="${f1(b[0] + (R() - 0.5) * 7 * k)}" cy="${f1(b[1] - 6 * k - R() * 18 * k)}" r="${f1(1.4 * k)}" fill="${m % 3 ? '#d8321e' : '#7aa83a'}"/>`).join(''); }
    [[-54, -16], [-54, 0]].forEach(([x, z]) => { const q = p(x, TY, z); f += `<rect x="${f1(q[0] - 1.4 * k)}" y="${f1(q[1] - 5 * k)}" width="${f1(2.8 * k)}" height="${f1(2 * k)}" fill="#e8d4a8"/><path d="M${f1(q[0])} ${f1(q[1] - 3 * k)}v${f1(3 * k)}" stroke="#a88a5a" stroke-width="${f1(0.5 * k)}"/>`; });
    return { front: f }; });
  // YRD-047 TIERED TERRACOTTA HERB & STRAWBERRY TOWER (T3): ripe strawberries hanging over the pocket lips, white flowers and a bumblebee visiting.
  N.str32 = addFx('tower8', c => { const p = c.p, k = c.k, R = rng('str32'); let f = '';
    rep(12, i => { const a = R() * 2 - 0.6, y = 4 + (i % 3) * 7, q = p(Math.cos(a) * (24 - y * 0.5), y, Math.sin(a) * (24 - y * 0.5)); f += `<path d="M${f1(q[0])} ${f1(q[1])}q${f1(0.4 * k)} ${f1(2 * k)} 0 ${f1(3 * k)}" stroke="#4a8a2a" stroke-width="${f1(0.3 * k)}" fill="none"/><path d="M${f1(q[0] - 1.2 * k)} ${f1(q[1] + 3 * k)}q${f1(1.2 * k)} ${f1(3 * k)} ${f1(2.4 * k)} 0Z" fill="#d8202a"/>` + rep(3, m => `<circle cx="${f1(q[0] - 0.6 * k + m * 0.6 * k)}" cy="${f1(q[1] + 3.8 * k)}" r="${f1(0.15 * k)}" fill="#f8e070"/>`).join(''); });
    rep(5, () => { const a = R() * 2 - 0.6, q = p(Math.cos(a) * 18, 18, Math.sin(a) * 18); f += rep(5, m => `<circle cx="${f1(q[0] + Math.cos(m * 1.26) * 0.8 * k)}" cy="${f1(q[1] + Math.sin(m * 1.26) * 0.7 * k)}" r="${f1(0.6 * k)}" fill="#ffffff"/>`).join('') + `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.4 * k)}" fill="#f2c21a"/>`; });
    { const q = p(0, 30, 10); f += `<g transform="translate(${H3.P2(q)})"><g>${at('translate', `0 0;${f1(10 * k)} ${f1(-4 * k)};${f1(-6 * k)} ${f1(-8 * k)};0 0`, 6, 0, SPL(3))}<ellipse rx="${f1(1.6 * k)}" ry="${f1(1.1 * k)}" fill="#f2c21a"/><path d="M${f1(-0.6 * k)} ${f1(-1 * k)}v${f1(2 * k)}M${f1(0.5 * k)} ${f1(-1 * k)}v${f1(2 * k)}" stroke="#1e1e22" stroke-width="${f1(0.5 * k)}"/><ellipse cx="0" cy="${f1(-1.4 * k)}" rx="${f1(1.4 * k)}" ry="${f1(0.6 * k)}" fill="#e8f4fa" opacity="0.7">${H3.an('ry', `${f1(0.6 * k)};${f1(0.2 * k)};${f1(0.6 * k)}`, 0.1)}</ellipse></g></g>`; }
    return { front: f }; });
  // YRD-067 MANICURED FRENCH BOXWOOD PARTERRE & ROSE ARCHES (T4): fine leaf texture on the clipped hedges, raked gravel paths, full pink + cream roses
  // climbing the arch and a pair of white butterflies.
  N.par32 = addFx('parterre8', c => { const p = c.p, k = c.k, R = rng('par32'); let f = '', un = '';
    rep(160, () => { const q = p((R() - 0.5) * 150, 0.2, (R() - 0.5) * 100); un += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.35 * k)}" fill="${R() < 0.5 ? '#c8bca4' : '#f4eedc'}"/>`; });
    rep(220, () => { const q = p((R() - 0.5) * 150, 7 + R() * 2, (R() - 0.5) * 100); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.3 * k)}" fill="${R() < 0.5 ? '#7ab452' : '#2e5a22'}" opacity="0.5"/>`; });
    rep(10, i => { const t = i / 9, a = PI * t, q = p(-12 + Math.cos(a) * 14, 4 + Math.sin(a) * 40, -40); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.6 * k)}" fill="${i % 3 ? '#f2a6c0' : '#f8ecd8'}"/><circle cx="${f1(q[0] - 0.4 * k)}" cy="${f1(q[1] - 0.4 * k)}" r="${f1(0.7 * k)}" fill="${i % 3 ? '#e87a9a' : '#ead8b8'}"/>`; });
    rep(2, i => { const q = p(-20 + i * 30, 26, -10); f += `<g transform="translate(${H3.P2(q)})"><g>${at('translate', `0 0;${f1(12 * k)} ${f1(-6 * k)};${f1(4 * k)} ${f1(4 * k)};0 0`, 9 + i * 2, -i * 3, SPL(3))}<g transform="scale(${n4(k)})"><g>${at('scale', '1 1;0.2 1;1 1', 0.35, -i * 0.1)}<path d="M0 0q-1.4 -1.6 -2 -0.2q0.4 1 2 0.2Zm0 0q1.4 -1.6 2 -0.2q-0.4 1 -2 0.2Z" fill="#ffffff"/></g></g></g></g>`; });
    return { under: un, front: f }; });
  // YRD-087 SELF-POLLINATING EXOTIC ORCHID & FLOATING BONSAI SKY-ISLANDS (T5): soft mist trailing from the floating islands, glowing pollen drifting
  // between the orchids, and faint light rings under each island.
  N.orch32 = addFx('flora', c => { const p = c.p, k = c.k, R = rng('orc32'); let f = '';
    [[-28, 0], [28, 0], [0, 0]].forEach(([x, z], i) => { const q = p(x, 2, z); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(9 * k)}" ry="${f1(3.4 * k)}" fill="none" stroke="#c8f4ff" stroke-width="${f1(0.5 * k)}">${H3.an('opacity', '0.2;0.8;0.2', 3 + i * 0.4)}</ellipse>`; });
    f += `<g filter="url(#f7b)">${rep(6, i => { const q = p(-30 + i * 12, 10, 4), T = 5 + R() * 2, b = -R() * T; return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(3 * k)}" fill="#ffffff" opacity="0">${at('translate', `0 0;${f1(3 * k)} ${f1(8 * k)}`, T, b)}${an('opacity', '0;0.4;0', T, b)}</circle>`; }).join('')}</g>`;
    f += rep(12, () => { const q = p((R() - 0.5) * 70, 18 + R() * 20, (R() - 0.5) * 30), T = 4 + R() * 3, b = -R() * T; return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.6 * k)}" fill="#fff4a0" opacity="0">${at('translate', `0 0;${f1((R() - 0.5) * 20 * k)} ${f1(-6 * k)}`, T, b)}${an('opacity', '0;1;0', T, b)}</circle>`; }).join('');
    return { front: f }; });
  // YRD-011 SCRAGGY SAPLING SUPPORTED BY TWINE (T1): a bamboo cane tied with fraying twine, a plastic nursery tag, a ring of dry dead leaves and weeds.
  N.sap32 = addFx('flora', c => { const p = c.p, k = c.k, R = rng('sap32'); let f = '', un = '';
    rep(9, () => { const q = p((R() - 0.5) * 30, 0.3, (R() - 0.5) * 24); un += `<path d="M${f1(q[0] - 1.6 * k)} ${f1(q[1])}q${f1(1.6 * k)} ${f1(-1.2 * k)} ${f1(3.2 * k)} 0q${f1(-1.6 * k)} ${f1(1.2 * k)} ${f1(-3.2 * k)} 0Z" fill="${R() < 0.5 ? '#a8742a' : '#7a5a2a'}"/>`; });
    f += H7.tube([p(5, 0, 3), p(5, 50, 3)], 0.6, k, '#c8b078', '#e8d8a8', '#6a5a30');
    [16, 32].forEach(y => { const q = p(3, y, 3); f += `<path d="M${f1(q[0] - 2 * k)} ${f1(q[1])}h${f1(4 * k)}M${f1(q[0] + 2 * k)} ${f1(q[1])}l${f1(1 * k)} ${f1(2.4 * k)}M${f1(q[0] + 2 * k)} ${f1(q[1])}l${f1(1.6 * k)} ${f1(1.8 * k)}" stroke="#c8a868" stroke-width="${f1(0.4 * k)}"/>`; });
    { const q = p(-6, 0, 8); f += `<path d="M${H3.P2(q)}v${f1(-6 * k)}" stroke="#e8e8e0" stroke-width="${f1(0.6 * k)}"/><rect x="${f1(q[0] - 1.6 * k)}" y="${f1(q[1] - 9 * k)}" width="${f1(3.2 * k)}" height="${f1(3.4 * k)}" fill="#f4f4ee" stroke="#c8c8c0" stroke-width="${f1(0.2 * k)}"/><path d="M${f1(q[0] - 1 * k)} ${f1(q[1] - 7.8 * k)}h${f1(2 * k)}" stroke="#4a8a34" stroke-width="${f1(0.5 * k)}"/>`; }
    f += gWeeds(p, k, R, 24, 0, 0, 22, 18, '#8a9a4a');
    return { under: un, front: f }; });
  // YRD-031 DWARF MEYER LEMON TREE IN HALF-BARREL (T2): a couple of fallen lemons by the barrel, white blossoms and a bee.
  N.lem32 = addFx('lemon8', c => { const p = c.p, k = c.k, R = rng('lem32'); let f = '';
    [[22, 14], [-18, 20]].forEach(([x, z]) => { const q = p(x, 1.4, z); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(2.2 * k)}" ry="${f1(1.6 * k)}" fill="#f2d040"/><ellipse cx="${f1(q[0] - 0.6 * k)}" cy="${f1(q[1] - 0.5 * k)}" rx="${f1(0.7 * k)}" ry="${f1(0.4 * k)}" fill="#ffffff" opacity="0.5"/>`; });
    rep(8, () => { const q = p((R() - 0.5) * 30, 34 + R() * 14, 8 + R() * 4); f += rep(5, m => `<circle cx="${f1(q[0] + Math.cos(m * 1.26) * 0.7 * k)}" cy="${f1(q[1] + Math.sin(m * 1.26) * 0.6 * k)}" r="${f1(0.5 * k)}" fill="#ffffff"/>`).join(''); });
    return { front: f }; });
  // YRD-051 BLOOMING PINK WEEPING CHERRY (T3): a carpet of fallen petals round the trunk and petals drifting down.
  N.chy32 = addFx('flora', c => { const p = c.p, k = c.k, R = rng('chy32'); let f = '', un = '';
    rep(70, () => { const a = R() * 2 * PI, r = 10 + R() * 40, q = p(Math.cos(a) * r, 0.3, Math.sin(a) * r * 0.8); un += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.8 * k)}" ry="${f1(0.45 * k)}" fill="${R() < 0.5 ? '#f8c8d8' : '#f2a6c0'}"/>`; });
    f += rep(8, () => { const q = p((R() - 0.5) * 70, 70, (R() - 0.5) * 40), T = 6 + R() * 4, b = -R() * T; return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.8 * k)}" ry="${f1(0.45 * k)}" fill="#f8c8d8" opacity="0">${H3.an('opacity', '0;1;1;0', T, b)}<animateTransform attributeName="transform" type="translate" values="0 0;${f1(6 * k)} ${f1(34 * k)};${f1(2 * k)} ${f1(68 * k)}" dur="${n4(T)}s" begin="${n4(b)}s" repeatCount="indefinite"/></ellipse>`; }).join('');
    return { under: un, front: f }; });
  // YRD-071 ANCIENT OLIVE & CYPRESS GROVE (T4): fallen black olives on the gravel, a weathered terracotta urn on its side and bees over the lavender.
  N.grv32 = addFx('grove8', c => { const p = c.p, k = c.k, R = rng('grv32'); let f = '';
    rep(14, () => { const q = p(-20 + (R() - 0.5) * 30, 1, (R() - 0.5) * 20); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(0.7 * k)}" ry="${f1(0.5 * k)}" fill="#2a2a1e"/>`; });
    { const a = p(40, 3, 24), b = p(52, 3, 20); f += H7.tube([a, b], 3.2, k, '#c4683a', '#e8a070', '#6a3418') + `<ellipse cx="${f1(b[0])}" cy="${f1(b[1])}" rx="${f1(2.6 * k)}" ry="${f1(3.2 * k)}" fill="#3a2010"/>`; }
    rep(3, i => { const q = p(-40 + i * 14, 14, 26); f += `<g transform="translate(${H3.P2(q)})"><g>${at('translate', `0 0;${f1(8 * k)} ${f1(-3 * k)};${f1(-4 * k)} ${f1(-5 * k)};0 0`, 5 + i, -i, SPL(3))}<ellipse rx="${f1(1.3 * k)}" ry="${f1(0.9 * k)}" fill="#f2c21a"/><path d="M${f1(-0.4 * k)} ${f1(-0.8 * k)}v${f1(1.6 * k)}" stroke="#1e1e22" stroke-width="${f1(0.4 * k)}"/></g></g>`; });
    return { front: f }; });
  // YRD-091 GIANT BIOLUMINESCENT SPIRIT-WILLOW (T5): many more glowing strands curtaining down in slow waves, glowing roots spreading over the ground,
  // spirit motes rising, and a soft light pool under the canopy.
  N.wil32 = addFx('flora', c => { const p = c.p, k = c.k, R = rng('wil32'); let f = '', un = '';
    un += H7.glowE(p, 0, 0, 0, 60, 40, '#7affd8', 0.25, 1);
    rep(8, i => { const a = i / 8 * 2 * PI + R() * 0.3, pts = rep(5, j => { const t = j / 4; return p(Math.cos(a) * (4 + t * 40), 0.3, Math.sin(a) * (4 + t * 32)); }); un += `<path d="M${pts.map(H3.P2).join('L')}" stroke="#4a3a5a" stroke-width="${f1(1.6 * k)}" fill="none" stroke-linecap="round"/><path d="M${pts.map(H3.P2).join('L')}" stroke="#8affe0" stroke-width="${f1(0.5 * k)}" fill="none" stroke-linecap="round">${an('opacity', '0.3;1;0.3', 3 + i * 0.3, -i * 0.4)}</path>`; });
    let st = ''; rep(36, i => { const a = R() * 2 * PI, r = 12 + R() * 34, top = p(Math.cos(a) * r, 74 + R() * 10, Math.sin(a) * r * 0.8), L = (34 + R() * 30) * k; st += `<g transform="translate(${H3.P2(top)})"><g>${H7.atV('skewX', ['-3', '3', '-3'], 4 + (i % 5) * 0.6, -i * 0.3)}<path d="M0 0q${f1((R() - 0.5) * 4 * k)} ${f1(L / 2)} 0 ${f1(L)}" stroke="#b8fff0" stroke-width="${f1(0.5 * k)}" fill="none" opacity="0.75"/>${rep(4, m => `<circle cy="${f1(L * (0.25 + m * 0.22))}" r="${f1(0.7 * k)}" fill="#e8fff8">${an('opacity', '0.3;1;0.3', 2 + m * 0.4, -i * 0.2)}</circle>`).join('')}</g></g>`; });
    f += `<g filter="url(#f7b)" opacity="0.6">${st}</g>` + st;
    f += rep(10, () => { const q = p((R() - 0.5) * 60, 6, (R() - 0.5) * 40), T = 5 + R() * 3, b = -R() * T; return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.9 * k)}" fill="#e8fff8" opacity="0">${at('translate', `0 0;${f1((R() - 0.5) * 8 * k)} ${f1(-40 * k)}`, T, b)}${an('opacity', '0;1;0', T, b)}</circle>`; }).join('');
    return { under: un, front: f }; });

  // ======================= PET ZONE + AQUATIC + ACTIVITY (plus7 / plus9 builds kept with their play acts; wear, life and light added in fx) =======================
  const pawTrail = (p, k, R, x0, z0, x1, z1, n, col) => rep(n, i => { const t = i / (n - 1), x = x0 + (x1 - x0) * t + (i % 2 ? 2 : -2), z = z0 + (z1 - z0) * t, q = p(x, 0.3, z); return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(1.1 * k)}" ry="${f1(0.7 * k)}" fill="${col}" opacity="0.55"/>` + rep(3, m => `<circle cx="${f1(q[0] - 0.9 * k + m * 0.9 * k)}" cy="${f1(q[1] - 1.1 * k)}" r="${f1(0.38 * k)}" fill="${col}" opacity="0.55"/>`).join(''); }).join('');
  const tBall = (q, k) => `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.8 * k)}" fill="#d8e83a"/><path d="M${f1(q[0] - 1.6 * k)} ${f1(q[1] - 0.6 * k)}q${f1(1.6 * k)} ${f1(1.6 * k)} ${f1(3.2 * k)} 0" stroke="#ffffff" stroke-width="${f1(0.3 * k)}" fill="none"/>`;
  // YRD-014 OLD TENNIS BALL & CARDBOARD TUNNEL: the pet tunnel scuffed and dusty, a chewed tennis ball gone grey-green, paw prints in the dirt.
  N.tun32 = addFx('tunnel8', (c, D) => { const p = c.p, k = c.k, R = rng('tun32'); let f = '', un = '';
    un += `<ellipse cx="${f1(p(0, 0, 0)[0])}" cy="${f1(p(0, 0, 0)[1])}" rx="${f1(58 * k)}" ry="${f1(16 * k)}" fill="#8a7050" opacity="0.25" filter="url(#f7b)"/>` + pawTrail(p, k, R, 52, 4, 70, 18, 4, '#6a5038');
    rep(8, () => { const q = p((R() - 0.5) * 80, 4 + R() * 18, 13.4); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((1.6 + R() * 2) * k)}" ry="${f1(0.8 * k)}" fill="#8a7a6a" opacity="0.3"/>`; });
    { const q = p(-58, 1.8, 14); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(1.9 * k)}" fill="#a8b46a"/><path d="M${f1(q[0] - 1.6 * k)} ${f1(q[1] - 0.6 * k)}q${f1(1.6 * k)} ${f1(1.6 * k)} ${f1(3.2 * k)} 0" stroke="#d8d8c8" stroke-width="${f1(0.3 * k)}" fill="none"/><path d="M${f1(q[0] + 0.4 * k)} ${f1(q[1] - 1.4 * k)}l${f1(0.6 * k)} ${f1(0.6 * k)}l${f1(-0.4 * k)} ${f1(0.4 * k)}" stroke="#6a6a4a" stroke-width="${f1(0.3 * k)}" fill="none"/>`; }
    return { under: un, front: f }; });
  // YRD-034 A-FRAME PET HOUSE & FRISBEE TURF: a steel water bowl, a rope chew toy, a chewed frisbee edge and paw prints across the turf.
  N.afr32 = addFx('aframe8', c => { const p = c.p, k = c.k, R = rng('afr32'); let f = '';
    f += pawTrail(p, k, R, -10, 30, 50, -10, 6, '#3a5a2a');
    { const q = p(-50, 0.6, 30); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(5 * k)}" ry="${f1(2.6 * k)}" fill="#c8ccd0"/><ellipse cx="${f1(q[0])}" cy="${f1(q[1] - 0.6 * k)}" rx="${f1(3.8 * k)}" ry="${f1(1.8 * k)}" fill="#8ac8e0"/>`; }
    { const a = p(30, 0.8, 30), b = p(42, 0.8, 26); f += H7.tube([a, b], 1.2, k, '#e8705a', '#f8c0a0', '#8a3a2a') + `<circle cx="${f1(a[0])}" cy="${f1(a[1])}" r="${f1(1.8 * k)}" fill="#3a6aa8"/><circle cx="${f1(b[0])}" cy="${f1(b[1])}" r="${f1(1.8 * k)}" fill="#3a6aa8"/>`; }
    return { front: f }; });
  // YRD-054 PET AGILITY COURSE: paw prints along the course, a treat pouch and a little pennant flag fluttering on the tire jump.
  N.agi32 = addFx('agility8', c => { const p = c.p, k = c.k, R = rng('agi32'); let f = '';
    f += pawTrail(p, k, R, -60, 30, 60, 20, 8, '#2e5a1e');
    { const q = p(-40, 32, 0); f += `<g transform="translate(${H3.P2(q)})"><g>${H7.atV('skewY', ['0', '10', '-4', '0'], 1.6)}<path d="M0 0l${f1(6 * k)} ${f1(1.6 * k)}l${f1(-6 * k)} ${f1(1.6 * k)}Z" fill="#e8402a"/></g></g>`; }
    { const q = p(60, 0.8, 34); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1] - 1.6 * k)}" rx="${f1(2.6 * k)}" ry="${f1(2 * k)}" fill="#3a6aa8"/><circle cx="${f1(q[0] + 3 * k)}" cy="${f1(q[1])}" r="${f1(0.7 * k)}" fill="#a86a3a"/><circle cx="${f1(q[0] + 4.4 * k)}" cy="${f1(q[1] - 0.4 * k)}" r="${f1(0.6 * k)}" fill="#a86a3a"/>`; }
    return { front: f }; });
  // YRD-074 MINI-MANSION PET VILLA: two clipped topiary balls in white planters by the door and a sparkle running over the splash pad.
  N.vil32 = addFx('villa8', c => { const p = c.p, k = c.k; let f = '';
    [[-10, 30], [26, 30]].forEach(([x, z]) => { const q = p(x, 0, z); f += `<path d="M${f1(q[0] - 3 * k)} ${f1(q[1])}h${f1(6 * k)}l${f1(-0.8 * k)} ${f1(-5 * k)}h${f1(-4.4 * k)}Z" fill="#f4f1ea" stroke="#c8c0b0" stroke-width="${f1(0.3 * k)}"/><circle cx="${f1(q[0])}" cy="${f1(q[1] - 9 * k)}" r="${f1(4.4 * k)}" fill="#4e8a36"/><circle cx="${f1(q[0] - 1.4 * k)}" cy="${f1(q[1] - 10.4 * k)}" r="${f1(1.6 * k)}" fill="#7ab452"/>`; });
    f += rep(5, i => { const q = p(30 + (i % 3) * 10, 1, -20 + i * 6); return `<path d="M${f1(q[0])} ${f1(q[1] - 2 * k)}l${f1(0.6 * k)} ${f1(1.4 * k)}l${f1(1.4 * k)} ${f1(0.6 * k)}l${f1(-1.4 * k)} ${f1(0.6 * k)}l${f1(-0.6 * k)} ${f1(1.4 * k)}l${f1(-0.6 * k)} ${f1(-1.4 * k)}l${f1(-1.4 * k)} ${f1(-0.6 * k)}l${f1(1.4 * k)} ${f1(-0.6 * k)}Z" fill="#ffffff" opacity="0">${an('opacity', '0;1;0', 1.8, -i * 0.4)}</path>`; }).join('');
    return { front: f }; });
  // YRD-094 ANTI-GRAVITY PET BOUNCE-DOME: a floating ball bobbing in the dome and a soft glow ring on the floor pulsing with each bounce.
  N.bnc32 = addFx('bounce8', c => { const p = c.p, k = c.k; let f = '';
    { const q = p(0, 1, 0); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(26 * k)}" ry="${f1(10 * k)}" fill="none" stroke="#8ae8ff" stroke-width="${f1(0.8 * k)}">${an('opacity', '0.2;0.8;0.2', 1.4)}</ellipse>`; const b = p(8, 22, 4); f += `<g>${at('translate', `0 0;0 ${f1(-10 * k)};0 0`, 1.4, 0, SPL(2))}${tBall(b, k)}</g>`; }
    return { front: f }; });
  // YRD-015 INFLATABLE PLASTIC KIDDIE POOL (T1): sun-faded patches, grass clippings and a dead leaf floating, a green garden hose snaking over the rim.
  N.kid32 = addFx('kiddie', c => { const p = c.p, k = c.k, R = rng('kid32'); let f = '';
    rep(5, () => { const a = R() * 2 * PI, q = p(Math.cos(a) * 50, 22, Math.sin(a) * 50); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((4 + R() * 4) * k)}" ry="${f1(2 * k)}" fill="#ffffff" opacity="0.3"/>`; });
    rep(18, () => { const a = R() * 2 * PI, r = R() * 34, q = p(Math.cos(a) * r, 21.2, Math.sin(a) * r); f += `<path d="M${f1(q[0])} ${f1(q[1])}l${f1((R() - 0.5) * 3 * k)} ${f1((R() - 0.5) * 1.2 * k)}" stroke="#5a8a34" stroke-width="${f1(0.4 * k)}"/>`; });
    { const q = p(-14, 21.3, -10); f += `<g transform="translate(${H3.P2(q)})"><g>${at('translate', `0 0;${f1(4 * k)} ${f1(1 * k)};0 0`, 8, 0, SPL(2))}<path d="M${f1(-2 * k)} 0q${f1(2 * k)} ${f1(-1.6 * k)} ${f1(4 * k)} 0q${f1(-2 * k)} ${f1(1.6 * k)} ${f1(-4 * k)} 0Z" fill="#a8742a"/></g></g>`; }
    { const a = p(74, 0.6, 26), b = p(62, 0.6, 52), cc = p(48, 0.6, 50), d = p(46, 31, 40), e = p(36, 26, 30), hd = `M${H3.P2(a)}Q${H3.P2(b)} ${H3.P2(cc)}Q${f1(d[0] + 6 * k)} ${f1(d[1] + 10 * k)} ${H3.P2(d)}Q${f1(d[0] - 3 * k)} ${f1(d[1] - 3 * k)} ${H3.P2(e)}`; f += `<path d="${hd}" stroke="#2e7a3a" stroke-width="${f1(1.6 * k)}" fill="none"/><path d="${hd}" stroke="#6ab85a" stroke-width="${f1(0.5 * k)}" fill="none" transform="translate(${f1(-0.3 * k)} ${f1(-0.3 * k)})"/><circle cx="${f1(e[0])}" cy="${f1(e[1])}" r="${f1(1 * k)}" fill="#e8b440"/>`; }
    return { front: f }; });
  // YRD-035 ABOVE-GROUND TIMBER-WALL PLUNGE POOL: a rolled towel and a lantern on the cedar cap, and caustic light shimmering on the water.
  N.plg32 = addFx('plunge', c => { const p = c.p, k = c.k, R = rng('plg32'); let f = '';
    f += rep(8, i => { const a = R() * 2 * PI, r = R() * 40, q = p(Math.cos(a) * r, 35.2, Math.sin(a) * r); return `<path d="M${f1(q[0] - 3 * k)} ${f1(q[1])}q${f1(3 * k)} ${f1(-1.4 * k)} ${f1(6 * k)} 0" stroke="#e8fbff" stroke-width="${f1(0.5 * k)}" fill="none" opacity="0">${an('opacity', '0;0.8;0', 2.4 + (i % 3) * 0.5, -i * 0.4)}</path>`; }).join('');
    { const q = p(-40, 43, 38); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(5 * k)}" ry="${f1(2.2 * k)}" fill="#f4efe4"/><path d="M${f1(q[0] - 5 * k)} ${f1(q[1])}q${f1(5 * k)} ${f1(2 * k)} ${f1(10 * k)} 0" stroke="#5a8aa0" stroke-width="${f1(0.6 * k)}" fill="none"/>`; }
    { const q = p(44, 43, 32); f += `<rect x="${f1(q[0] - 1.8 * k)}" y="${f1(q[1] - 5 * k)}" width="${f1(3.6 * k)}" height="${f1(5 * k)}" fill="#ffe2a0" stroke="#2a2a2e" stroke-width="${f1(0.5 * k)}"/><circle cx="${f1(q[0])}" cy="${f1(q[1] - 2.5 * k)}" r="${f1(7 * k)}" fill="#ffd890" opacity="0.3" filter="url(#f7s)">${an('opacity', '0.2;0.4;0.25', 2.6)}</circle>`; }
    return { front: f }; });
  // YRD-055 NATURAL ROCK WATERFALL KOI POND: a blue dragonfly darting over the lily pads.
  N.koi32 = addFx('koiPond', c => { const p = c.p, k = c.k; let f = '';
    { const q = p(-10, 20, 10); f += `<g transform="translate(${H3.P2(q)})"><g>${at('translate', `0 0;${f1(14 * k)} ${f1(-4 * k)};${f1(14 * k)} ${f1(-4 * k)};${f1(-8 * k)} ${f1(2 * k)};0 0`, 7, 0, SPL(4))}<path d="M${f1(-3 * k)} 0h${f1(6 * k)}" stroke="#2a6ac8" stroke-width="${f1(0.7 * k)}"/><g>${at('scale', '1 1;1 0.3;1 1', 0.12, 0)}<ellipse cx="${f1(-0.4 * k)}" cy="${f1(-1.2 * k)}" rx="${f1(1 * k)}" ry="${f1(2.2 * k)}" fill="#e8f6ff" opacity="0.7"/><ellipse cx="${f1(0.8 * k)}" cy="${f1(-1.2 * k)}" rx="${f1(1 * k)}" ry="${f1(2.2 * k)}" fill="#e8f6ff" opacity="0.7"/></g></g></g>`; }
    return { front: f }; });
  // YRD-075 HEATED SALTWATER LAP POOL: caustic light dancing on the water and a faint warm steam curling off the heated sun shelf.
  N.lap32 = addFx('lapPool', c => { const p = c.p, k = c.k, R = rng('lap32'); let f = '';
    f += rep(12, i => { const q = p(-80 + R() * 160, 15.2, -24 + R() * 48); return `<path d="M${f1(q[0] - 3 * k)} ${f1(q[1])}q${f1(3 * k)} ${f1(-1.2 * k)} ${f1(6 * k)} 0" stroke="#e8fbff" stroke-width="${f1(0.5 * k)}" fill="none" opacity="0">${an('opacity', '0;0.8;0', 2.2 + (i % 3) * 0.5, -i * 0.3)}</path>`; }).join('');
    f += `<g filter="url(#f7b)">${rep(4, i => { const q = p(60 + i * 5, 16, (i % 2) * 8 - 4), T = 5 + i, b = -i; return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(3 * k)}" fill="#ffffff" opacity="0">${at('translate', `0 0;${f1(2 * k)} ${f1(-14 * k)}`, T, b)}${an('opacity', '0;0.35;0', T, b)}</circle>`; }).join('')}</g>`;
    return { front: f }; });
  // YRD-095 GLASS-WALLED INFINITY LAGOON: caustic shimmer across the lagoon and glints sliding along the glass wall.
  N.lag32 = addFx('lagoon', c => { const p = c.p, k = c.k, R = rng('lag32'); let f = '';
    f += rep(14, i => { const q = p(-80 + R() * 160, 29.4, -40 + R() * 80); return `<path d="M${f1(q[0] - 3 * k)} ${f1(q[1])}q${f1(3 * k)} ${f1(-1.2 * k)} ${f1(6 * k)} 0" stroke="#e8fbff" stroke-width="${f1(0.5 * k)}" fill="none" opacity="0">${an('opacity', '0;0.8;0', 2.4 + (i % 3) * 0.5, -i * 0.3)}</path>`; }).join('');
    return { front: f }; });
  // YRD-017 CROOKED HORSESHOE STAKE IN THE DIRT (T1, back to the CSV name; plus9 had 'Horseshoe Pits'): two worn sand pits round the crooked stakes,
  // rusty horseshoes lying in the sand (one ringer on a stake) and a scuffed throwing line.
  N.shoe32 = addFx('shoe8', c => { const p = c.p, k = c.k, R = rng('sh32'); let un = '', f = '';
    [-62, 62].forEach(x => { const q = p(x, 0.2, 0); un += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(18 * k)}" ry="${f1(8 * k)}" fill="#c8a870"/><ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(18 * k)}" ry="${f1(8 * k)}" fill="none" stroke="#8a6a3a" stroke-width="${f1(0.6 * k)}" opacity="0.6"/>`; rep(20, () => { const s = p(x + (R() - 0.5) * 30, 0.3, (R() - 0.5) * 12); un += `<circle cx="${f1(s[0])}" cy="${f1(s[1])}" r="${f1(0.3 * k)}" fill="#8a6a3a"/>`; }); });
    const shoe = (x, z, a) => { const q = p(x, 0.6, z); return `<g transform="translate(${H3.P2(q)}) rotate(${a}) scale(${n4(k)} ${n4(k * 0.55)})"><path d="M-3 3v-3a3 3 0 0 1 6 0v3" stroke="#7a4a24" stroke-width="1.4" fill="none"/></g>`; };
    f += shoe(-54, 4, 20) + shoe(-70, -3, -40) + shoe(56, 5, 160);
    un += `<path d="M${H3.P2(p(-30, 0.3, -10))}L${H3.P2(p(-30, 0.3, 10))}M${H3.P2(p(30, 0.3, -10))}L${H3.P2(p(30, 0.3, 10))}" stroke="#f4f0e4" stroke-width="${f1(0.6 * k)}" stroke-dasharray="${f1(2 * k)} ${f1(1 * k)}" opacity="0.7"/>`;
    return { under: un, front: f }; });
  // YRD-037 PLASTIC CORNHOLE BOARDS & BEANBAGS: beanbags scattered on the grass and one on a board.
  N.corn32 = addFx('cornhole8', c => { const p = c.p, k = c.k; let f = '';
    [[-20, 10, '#c8282a'], [0, -6, '#2a5ac8'], [14, 12, '#c8282a'], [52, 2, '#2a5ac8']].forEach(([x, z, col]) => { const q = p(x, 0.8, z); f += `<path d="M${f1(q[0] - 2.4 * k)} ${f1(q[1])}q0 ${f1(-1.6 * k)} ${f1(2.4 * k)} ${f1(-1.6 * k)}q${f1(2.4 * k)} 0 ${f1(2.4 * k)} ${f1(1.6 * k)}q0 ${f1(1.2 * k)} ${f1(-2.4 * k)} ${f1(1.2 * k)}q${f1(-2.4 * k)} 0 ${f1(-2.4 * k)} ${f1(-1.2 * k)}Z" fill="${col}"/>`; });
    return { front: f }; });
  // YRD-057 OUTDOOR PING-PONG TABLE (Nov 7, user: drop the bocce, keep only the ping-pong): own builder, no bocce court. A weatherproof blue top with
  // white edge + centre lines, a white-banded net on black post clamps, a folding steel undercarriage (legs, crossbars, wheels), a red and a black paddle
  // resting at the ends, a soft shadow on the grass. Live (play): the ball rallies over the net, bouncing once on each half; idle: a ball rests by a paddle.
  N.boc32 = S => { const pl = H7.isPlay(S), TY = 22, TT = 2, HX = 38, HZ = 21, { mt, pt } = H3, ST = '#5a5e68';
    const D = { w: 100, d: 64, noShad: 1 };
    D.build = P => [XK.box(0, TY, 0, 2 * HX, TT, 2 * HZ, '#1f5a8a', pt({ r: 0.6 })),
      ...[[-26, -15], [-26, 15], [26, -15], [26, 15]].map(([x, z]) => XK.box(x, 2.2, z, 2, TY - 2.2, 2, ST, mt({ r: 0.4 }))),
      ...[[-26, -15], [-26, 15], [26, -15], [26, 15]].map(([x, z]) => XK.cyl(x, 0, z, 1.7, 2.2, '#2a2b30', mt({ n: 10 }))),
      XK.box(-26, 7, 0, 1.5, 1.5, 30, ST, mt({ r: 0.3 })), XK.box(26, 7, 0, 1.5, 1.5, 30, ST, mt({ r: 0.3 })), XK.box(0, 9, 0, 52, 1.4, 1.4, ST, mt({ r: 0.3 })),
      XK.box(0, TY + TT, -HZ - 1, 1.6, 6, 1.6, '#1d1e22', mt({ r: 0.3 })), XK.box(0, TY + TT, HZ + 1, 1.6, 6, 1.6, '#1d1e22', mt({ r: 0.3 })),
      XK.box(0, TY + TT, 0, 0.5, 5.6, 2 * HZ + 2, '#f4f4f0', { op: 0.5, mat: 'fab' }), XK.box(0, TY + TT + 5, 0, 0.8, 0.8, 2 * HZ + 2, '#ffffff', { mat: 'fab' })];
    D.fx = c => { const p = c.p, k = c.k, P2 = H3.P2; let f = '', un = '';
      { const q = p(2, 0, 2); [1, 0.86, 0.72, 0.58, 0.44].forEach(m => { un += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(40 * m * k)}" ry="${f1(18 * m * k)}" fill="#16200c" opacity="0.045"/>`; }); }
      f += `<g transform="${H3.planeH(p, TY + TT + 0.05)}"><rect x="${-HX + 0.6}" y="${-HZ + 0.6}" width="${2 * HX - 1.2}" height="${2 * HZ - 1.2}" fill="none" stroke="#ffffff" stroke-width="0.9"/><path d="M${-HX + 0.6} 0H${HX - 0.6}" stroke="#ffffff" stroke-width="0.5"/>`
        + `<g transform="translate(-28 10) rotate(-25)"><rect x="-1" y="2.4" width="2" height="5" rx="0.8" fill="#c8a06a"/><ellipse rx="4" ry="4.4" fill="#c8282e"/><ellipse rx="3.4" ry="3.8" fill="#e23a3a" opacity="0.6"/></g>`
        + `<g transform="translate(27 -11) rotate(160)"><rect x="-1" y="2.4" width="2" height="5" rx="0.8" fill="#c8a06a"/><ellipse rx="4" ry="4.4" fill="#1d1e22"/><ellipse rx="3.4" ry="3.8" fill="#3a3c42" opacity="0.6"/></g></g>`;
      const BALL = '<circle r="1.15" fill="#fbfbf6" stroke="#c9c6bc" stroke-width="0.2"/><circle cx="-0.35" cy="-0.35" r="0.4" fill="#ffffff"/>', BY = TY + TT + 1.15;
      if (pl) f += ballFly32(p, k, [[-34, BY + 7, -3], [-16, BY, 2], [0, BY + 9, 0], [17, BY, -4], [34, BY + 7, 2], [15, BY, 4], [0, BY + 9, 0], [-17, BY, -2], [-34, BY + 7, -3]], 1.8, BALL);
      else { const q = p(-22, BY, 13); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})">${BALL}</g>`; }
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(-HX - 6, 0, -HZ - 6), p(HX + 6, 0, HZ + 6), p(-HX - 6, 0, HZ + 6), p(HX + 6, 0, -HZ - 6), p(-HX, TY + 10, -HZ), p(HX, TY + 10, HZ)], 3) }; };
    return D; };
  // YRD-077 PUTTING GREEN & OUTDOOR CINEMA: a golf ball rolling toward a hole and a soft flicker on the screen.
  N.glf32 = addFx('golf8', c => { const p = c.p, k = c.k; let f = '';
    { const a = p(-30, 1.2, 20), b = p(-10, 1.2, 10); f += `<circle r="${f1(1 * k)}" fill="#ffffff"><animate attributeName="cx" values="${f1(a[0])};${f1(b[0])};${f1(b[0])}" keyTimes="0;0.7;1" dur="4s" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(a[1])};${f1(b[1])};${f1(b[1])}" keyTimes="0;0.7;1" dur="4s" repeatCount="indefinite"/></circle>`; }
    return { front: f }; });
  // YRD-097 HOLOGRAPHIC AR SPORTS ARENA & STARGAZING TELESCOPE (T5, generic rebuilt, same 70 x 70): a round glowing projection pad with a hologram
  // goal and a ball looping through it, and a brass refracting telescope on a tripod angled up at the sky. Live: the hologram flickers and the ball
  // loops, the pad ring pulses, the telescope slowly sweeps.
  N.ar32 = S => { const D = { w: 70, d: 70, round: 1, glow: () => ({ y: 20, r: 50 }) }, { mt, cer } = H3;
    D.build = P => [XK.cyl(-6, 0, -4, 22, 2, '#1e2028', cer({ n: 28, shine: 1 })), XK.cyl(-6, 2, -4, 20, 0.4, '#2a3a4a', cer({ n: 28, shine: 1 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      { const q = p(-6, 2.5, -4); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(19 * k)}" ry="${f1(8 * k)}" fill="none" stroke="#6af0ff" stroke-width="${f1(0.8 * k)}">${an('opacity', '0.3;1;0.3', 2)}</ellipse>`;
        const g0 = p(-14, 2.5, -12), g1 = p(2, 2.5, -12), t0 = p(-14, 16, -12), t1 = p(2, 16, -12); f += `<g opacity="0.75">${an('opacity', '0.6;0.85;0.5;0.8;0.6', 1.4)}<path d="M${H3.P2(g0)}L${H3.P2(t0)}L${H3.P2(t1)}L${H3.P2(g1)}" stroke="#8af4ff" stroke-width="${f1(1.4 * k)}" fill="none"/><path d="M${H3.P2(t0)}L${H3.P2(p(-14, 12, -18))}L${H3.P2(p(2, 12, -18))}L${H3.P2(t1)}" stroke="#8af4ff" stroke-width="${f1(0.4 * k)}" fill="#8af4ff" fill-opacity="0.12"/>`
          + `<circle r="${f1(2.4 * k)}" fill="#e8feff" stroke="#6af0ff" stroke-width="${f1(0.4 * k)}"><animateMotion dur="2.4s" repeatCount="indefinite" path="M${H3.P2(p(-6, 4, 10))}Q${H3.P2(p(-6, 26, 0))} ${H3.P2(p(-6, 8, -14))}Q${H3.P2(p(-6, 20, 0))} ${H3.P2(p(-6, 4, 10))}"/></circle></g>`; }
      // telescope on a tripod
      { const top = p(22, 30, 18); f += [[14, 12], [30, 14], [22, 28]].map(([x, z]) => H7.tube([p(x, 0, z), p(22, 30, 18)], 0.6, k, '#3a2a1a', '#8a6a4a', '#1a1208')).join('');
        f += `<g transform="translate(${H3.P2(top)})"><g>${H7.atV('rotate', ['-8', '6', '-8'], 14)}<g transform="rotate(-35)"><rect x="${f1(-4 * k)}" y="${f1(-1.8 * k)}" width="${f1(22 * k)}" height="${f1(3.6 * k)}" rx="${f1(1 * k)}" fill="#c9a050"/><rect x="${f1(-4 * k)}" y="${f1(-1.8 * k)}" width="${f1(22 * k)}" height="${f1(1 * k)}" fill="#f4dca0"/><rect x="${f1(16 * k)}" y="${f1(-2.4 * k)}" width="${f1(3 * k)}" height="${f1(4.8 * k)}" fill="#8a6a2a"/><rect x="${f1(-7 * k)}" y="${f1(-1 * k)}" width="${f1(3 * k)}" height="${f1(2 * k)}" fill="#2a2a2e"/></g></g></g><circle cx="${f1(top[0])}" cy="${f1(top[1])}" r="${f1(1.2 * k)}" fill="#2a2a2e"/>`; }
      return { defs: H7.FDEF || '', front: f, bb: H3.bbOf([p(-30, 0, -28), p(34, 0, 30), p(-6, 30, -4), p(38, 46, 18)], 4) }; };
    return D; };

  // seats without an act could not be used in the house (act() matches seat.k || D.act): give every seated yard piece its act
  const SEATACT = { tarp32: 'sit', wist32: 'sit', cab32: 'sit', dome32: 'sit', zen32: 'sit', lawn32: 'sit', block32: 'sit', park32: 'sit', lime32: 'sit', pic32: 'sit', egg32: 'sit', porch32: 'sit', kid32: 'splash', plg32: 'splash', lap32: 'splash', lag32: 'splash' };
  Object.keys(SEATACT).forEach(k => { const g = N[k]; if (!g || g._sa) return; N[k] = S => { const D = g(S); if (D.seats && D.seats.length && !D.act) D.act = SEATACT[k]; return D; }; N[k]._sa = 1; });
  // creature-sized seating (Nov 7 creature test: these read tiny next to a sitting creature): scale the whole piece by f (render zs, footprint, seats)
  // Nov 7 (user: games too small for their players): trampolines + slides come from the house ARCH builders; own spec names so only these yard rows change
  N.tramp32 = S => X.ARCH.tramp(S); N.slide32 = S => X.ARCH.slide(S);
  // Nov 7 (user): basketball + soccer are just the item itself with CHALK lines drawn on the grass: no concrete court pad, no turf patch. Chalk = a soft
  // dusty halo, the main white line, and a broken powdery pass on top, plus a few specks. The hoop is also taller (rim 92, was 64) and a bit bigger
  // (backboard 40 x 26, rim r 8, thicker pole + base; BIG 3.3).
  const chalk = (p, d, k) => `<g transform="${H3.planeH(p, 0.3)}" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="${d}" stroke="#ffffff" stroke-width="3" opacity="0.12"/><path d="${d}" stroke="#f4f4ee" stroke-width="1.15" opacity="0.88"/><path d="${d}" stroke="#ffffff" stroke-width="0.55" stroke-dasharray="1.6 0.9 0.5 1.2" opacity="0.75"/></g>`;
  const specks = (p, R, n, x0, x1, z0, z1) => `<g transform="${H3.planeH(p, 0.3)}" fill="#ffffff" opacity="0.5">${rep(n, () => `<circle cx="${f1(x0 + R() * (x1 - x0))}" cy="${f1(z0 + R() * (z1 - z0))}" r="${f1(0.2 + R() * 0.3)}"/>`).join('')}</g>`;
  // D.noShad: the house skips its footprint shadow (a blurred rounded rect the size of the whole piece) - these draw their own small shadows instead
  // Nov 7 (user: the balls a little bigger + more detailed): own ball drawings, r 3.6 (basketball) / 3.4 (soccer), was 2.6. Basketball: radial shading,
  // pebbled leather, the 4 curved black channels, a rim line, a soft shine. Soccer: shaded white panel ball, the black centre pentagon, five partial
  // pentagons round the edge, the stitched seams between the white hexagons, a shine. Both spin in flight; a resting ball sits on a small shadow.
  const BALLDEF = '<radialGradient id="bb32g" cx="36%" cy="30%" r="72%"><stop offset="0" stop-color="#ffb47a"/><stop offset="0.5" stop-color="#ea762c"/><stop offset="1" stop-color="#a5420e"/></radialGradient>'
    + '<radialGradient id="sb32g" cx="36%" cy="30%" r="72%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.55" stop-color="#eeeeea"/><stop offset="1" stop-color="#a9adb2"/></radialGradient><clipPath id="bl32c"><circle r="1"/></clipPath>'
    + '<radialGradient id="sb32r" cx="40%" cy="36%" r="68%"><stop offset="0.55" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#1a1c22" stop-opacity="0.38"/></radialGradient>';
  const BALL32 = (r, kind) => { const R = rng('ball32' + kind), u = n => f1(n * r);
    if (kind === 'bball') { let pb = ''; rep(46, () => { const a = R() * 2 * PI, d = Math.sqrt(R()) * 0.94; pb += `M${u(Math.cos(a) * d - 0.035)} ${u(Math.sin(a) * d)}a${u(0.035)} ${u(0.035)} 0 1 0 ${u(0.07)} 0a${u(0.035)} ${u(0.035)} 0 1 0 ${u(-0.07)} 0`; });
      return `<circle r="${r}" fill="url(#bb32g)"/><g clip-path="url(#bl32c)" transform="scale(${n4(r)})"><path d="${pb}" fill="#a84810" opacity="0.45" transform="scale(${n4(1 / r)})"/>`
        + `<path d="M-1 0Q0 0.2 1 0M0 -1Q0.14 0 0 1M-0.64 -0.8Q-0.2 0 -0.64 0.8M0.64 -0.8Q0.2 0 0.64 0.8" fill="none" stroke="#2a160a" stroke-width="0.075"/><path d="M-1 -0.05Q0 0.15 1 -0.05M-0.06 -1Q0.08 0 -0.06 1" fill="none" stroke="#ffb07a" stroke-width="0.03" opacity="0.6"/></g>`
        + `<circle r="${f1(r * 0.97)}" fill="none" stroke="#6a2a0a" stroke-width="${u(0.05)}"/><ellipse cx="${u(-0.36)}" cy="${u(-0.42)}" rx="${u(0.3)}" ry="${u(0.18)}" fill="#ffffff" opacity="0.4" transform="rotate(-32 ${u(-0.36)} ${u(-0.42)})"/>`; }
    // soccer: a real truncated icosahedron (12 black pentagons + 20 white hexagons), turned so a pentagon faces a little up-left, front faces only,
    // each panel shaded by its normal, every edge a dark stitched seam (user: the first one had no lines)
    return `<g transform="scale(${n4(r)})">${SOC32()}</g><ellipse cx="${u(-0.34)}" cy="${u(-0.4)}" rx="${u(0.28)}" ry="${u(0.17)}" fill="#ffffff" opacity="0.5" transform="rotate(-32 ${u(-0.34)} ${u(-0.4)})"/>`; };
  const SOC32 = (() => { let memo = ''; return () => { if (memo) return memo; const ph = (1 + Math.sqrt(5)) / 2, V = [], nz = v => { const l = Math.hypot(...v); return v.map(x => x / l); }, dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cr = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
    const cyc = v => [v, [v[1], v[2], v[0]], [v[2], v[0], v[1]]], uniq = (L, q) => { if (!L.some(w => Math.hypot(w[0] - q[0], w[1] - q[1], w[2] - q[2]) < 1e-6)) L.push(q); };
    const signs = (a, b, c, out) => [1, -1].forEach(x => [1, -1].forEach(y => [1, -1].forEach(z => cyc([a * x, b * y, c * z]).forEach(q => uniq(out, q)))));
    signs(0, 1, 3 * ph, V); signs(1, 2 + ph, 2 * ph, V); signs(ph, 2, 2 * ph + 1, V); const U = V.map(nz);
    const PD = [], HD = []; signs(0, 1, ph, PD); signs(1, 1, 1, HD); signs(0, ph, 1 / ph, HD);
    const face = (n0, m) => { const n = nz(n0), e1 = nz(cr(n, Math.abs(n[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0])), e2 = cr(n, e1);
      const ids = U.map((v, i) => [dot(v, n), i]).sort((a, b) => b[0] - a[0]).slice(0, m).map(q => q[1]); return { n, pts: ids.map(i => U[i]).sort((a, b) => Math.atan2(dot(a, e2), dot(a, e1)) - Math.atan2(dot(b, e2), dot(b, e1))) }; };
    const F = PD.map(d => Object.assign(face(d, 5), { k: 1 })).concat(HD.map(d => Object.assign(face(d, 6), { k: 0 })));
    // rotation: pentagon (0, 1, phi) to the viewer (+z), then a small turn for a 3/4 look
    const a0 = nz([0, 1, ph]), ax = nz(cr(a0, [0, 0, 1])), an0 = Math.acos(dot(a0, [0, 0, 1]));
    const rod = (v, k, t) => { const c = Math.cos(t), sn = Math.sin(t), kv = cr(k, v), kd = dot(k, v); return [0, 1, 2].map(i => v[i] * c + kv[i] * sn + k[i] * kd * (1 - c)); };
    const rot = v => rod(rod(rod(v, ax, an0), [0, 1, 0], -0.32), [1, 0, 0], 0.26), L = nz([-0.45, 0.55, 0.75]);
    let o = '<circle r="1" fill="#e4e5e2"/>'; const vis = F.map(f => ({ k: f.k, n: rot(f.n), pts: f.pts.map(rot) })).filter(f => f.n[2] > 0.02).sort((a, b) => a.n[2] - b.n[2]);
    vis.forEach(f => { const l = Math.max(0, dot(f.n, L)), c = f.k ? Math.round(22 + 46 * l) : Math.round(186 + 69 * l), col = f.k ? `rgb(${c},${c},${c + 4})` : `rgb(${c},${c},${Math.min(255, c - 2)})`;
      o += `<path d="M${f.pts.map(q => f1(q[0] * 0.995) + ' ' + f1(-q[1] * 0.995)).join('L')}Z" fill="${col}" stroke="#26282d" stroke-width="0.07" stroke-linejoin="round"/>`; });
    // stitching: a fine light line just inside every white panel edge
    vis.filter(f => !f.k && f.n[2] > 0.45).forEach(f => { const c = f.pts.reduce((a, q) => [a[0] + q[0] / 6, a[1] + q[1] / 6], [0, 0]); o += `<path d="M${f.pts.map(q => f1((c[0] + (q[0] - c[0]) * 0.86) * 0.995) + ' ' + f1(-(c[1] + (q[1] - c[1]) * 0.86) * 0.995)).join('L')}Z" fill="none" stroke="#9a9ea4" stroke-width="0.018" stroke-dasharray="0.05 0.04" opacity="0.6"/>`; });
    o += '<circle r="0.985" fill="url(#sb32r)"/><circle r="0.985" fill="none" stroke="#3a3c42" stroke-width="0.05"/>';
    return (memo = o); }; })();
  // a ball flying along a path (spinning) or resting on its little shadow
  const ballFly32 = (p, k, pts, dur, body) => `<g><animateMotion dur="${n4(dur)}s" repeatCount="indefinite" path="M${pts.map(q => H3.P2(p(...q))).join('L')}"/><g transform="scale(${n4(k)})"><g>${H7.atV('rotate', ['0', '360'], 0.9)}${body}</g></g></g>`;
  const ballRest32 = (p, k, x, r, z, body) => { const g = p(x, 0, z), q = p(x, r, z); return `<ellipse cx="${f1(g[0] + 0.6 * k)}" cy="${f1(g[1])}" rx="${f1(r * 0.95 * k)}" ry="${f1(r * 0.35 * k)}" fill="#1e2a12" opacity="0.3"/><g transform="translate(${H3.P2(q)}) scale(${n4(k)})">${body}</g>`; };
  { N.goal8 = S => { const W = 44, H = 32, DP = 22, BR = 3.4, pl = H7.isPlay(S), R0 = rng('goal32'); const D = { w: 140, d: 120, noShad: 1 };
    D.build = P => [XK.box(0, 0, 0, 2, 0.1, 2, '#ffffff', { op: 0 })];
    D.fx = c => { const p = c.p, k = c.k, P2 = H3.P2, tube = H7.tube; let f = '', bk = '';
      const un = chalk(p, `M${-W - 30} 0H${W + 30}M${-W - 12} 0V22H${W + 12}V0M${-W + 8} 0V9H${W - 8}V0M-14 22A14 10 0 0 0 14 22`, k) + `<g transform="${H3.planeH(p, 0.3)}"><circle cx="0" cy="16" r="1" fill="#f4f4ee" opacity="0.9"/></g>` + specks(p, R0, 26, -W - 30, W + 30, -2, 34)
        + `<g filter="url(#f7s)" opacity="0.3">${[[-W, 0], [W, 0]].map(([x, z]) => { const q = p(x + 4, 0, z - 2); return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(4 * k)}" ry="${f1(1.6 * k)}" fill="#1e2a12"/>`; }).join('')}<path d="M${P2(p(-W, 0, -2))}L${P2(p(W, 0, -2))}L${P2(p(W, 0, -22))}L${P2(p(-W, 0, -22))}Z" fill="#1e2a12" opacity="0.35"/></g>`;
      const post = [[-W, 0, 0], [-W, H, 0], [W, H, 0], [W, 0, 0]], bx = [[-W, H - 6, -DP], [W, H - 6, -DP]]; let net = ''; const NET = '#f4f4f0';
      rep(12, i => { const x = -W + i * (2 * W / 11); net += `<path d="M${P2(p(x, H, 0))}L${P2(p(x, H - 6, -DP))}L${P2(p(x, 0, -DP - 4))}" stroke="${NET}" stroke-width="${f1(0.3 * k)}" fill="none" opacity="0.8"/>`; });
      rep(7, i => { const t = i / 6; net += `<path d="M${P2(p(-W, H * (1 - t), -DP * (t < 0.2 ? t * 5 : 1) - 4 * t))}L${P2(p(W, H * (1 - t), -DP * (t < 0.2 ? t * 5 : 1) - 4 * t))}" stroke="${NET}" stroke-width="${f1(0.3 * k)}" opacity="0.8"/>`; });
      [-W, W].forEach(x => { rep(6, i => { const t = i / 5; net += `<path d="M${P2(p(x, H * t, 0))}L${P2(p(x, (H - 6) * t, -DP - 4 * (1 - t)))}" stroke="${NET}" stroke-width="${f1(0.3 * k)}" opacity="0.7"/>`; }); });
      bk += `<g>${pl ? H7.atV('translate', ['0 0', '0 0', `${f1(-1 * k)} ${f1(-2 * k)}`, '0 0', '0 0'], 4) : ''}${net}</g>` + tube(bx.map(q => p(...q)), 0.8, k, '#d8d8d4') + tube([p(-W, 0, -DP - 4), p(-W, H - 6, -DP), p(-W, H, 0)], 0.8, k, '#d8d8d4') + tube([p(W, 0, -DP - 4), p(W, H - 6, -DP), p(W, H, 0)], 0.8, k, '#d8d8d4');
      f += tube(post.map(q => p(...q)), 1.8, k, '#ffffff', '#ffffff', '#6a6a60');
      if (pl) f += ballFly32(p, k, [[-30, BR, 54], [-10, BR, 46], [-10, BR, 46], [18, BR, 40], [18, BR, 40], [8, 13, 18], [6, 19, -4], [4, BR + 1, -16], [0, BR, 54], [-30, BR, 54]], 4, BALL32(BR, 'soccer'));
      else f += ballRest32(p, k, 0, BR, 16, BALL32(BR, 'soccer'));
      return { defs: BALLDEF + (H7.FDEF || ''), under: un, back: bk, front: f, bb: H3.bbOf([p(-W - 30, 0, -26), p(W + 30, 0, 40), p(-66, 0, 70), p(66, 0, -26), p(-W, H + 8, 0), p(W, H + 8, 0)], 3) }; };
    return D; }; }
  { const { box, cyl } = XK, { mt, P2, plane, bbOf } = H3, { atV, ellPts, sp, isPlay } = H7;
    N.hoop8 = S => { const pl = isPlay(S), RY = 92, BZ = -30, RR = 8, BW = 40, BH = 26, BR = 3.6;
      const D = { w: 110, d: 110, noShad: 1 };
      D.build = P => [cyl(0, 0, BZ - 9, 5, 2.4, '#3a3c42', mt({ n: 14 })), cyl(0, 2.4, BZ - 9, 2.3, RY + 16, '#3a3c42', mt({ n: 12, shine: 1 })), box(0, RY - 3, BZ + 0.6, BW, BH, 1.3, '#e8f4f8', { op: 0.55, mat: 'metal', shine: 1, r: 1 }), box(0, RY + 2, BZ - 4.6, 7, 2.4, 9, '#3a3c42', mt({ r: 0.4 })), box(0, RY - 2, BZ + 2.4, 5, 1.2, 3.6, '#3a3c42', mt({ r: 0.3 }))];
      D.fx = c => { const p = c.p, k = c.k, R = rng('hoop32'); let f = '';
        const bq = p(3, 0, BZ - 7), un = chalk(p, 'M-48 -34H48M-15 -34V10H15V-34M-15 10A15 15 0 0 0 15 10M-46 -34V-8A46 46 0 0 0 46 -8V-34', k) + specks(p, R, 30, -48, 48, -34, 40)
          + `<ellipse cx="${f1(bq[0])}" cy="${f1(bq[1])}" rx="${f1(9 * k)}" ry="${f1(3.6 * k)}" fill="#1e2a12" opacity="0.32" filter="url(#f7s)"/>`;
        f += `<g transform="${plane(p, BZ + 1.3, RY + BH - 3, -BW / 2)}"><rect x="0.7" y="0.7" width="${BW - 1.4}" height="${BH - 1.4}" rx="1" fill="none" stroke="#e8343c" stroke-width="1.3"/><rect x="${BW / 2 - 7}" y="${BH - 13}" width="14" height="10" fill="none" stroke="#e8343c" stroke-width="1"/></g>`;
        const rim = ellPts(0, BZ + 10, RR, RR, 28).map(([x, z]) => p(x, RY, z));
        let net = ''; rep(14, i => { const a = i / 14 * 2 * PI, t0 = p(RR * Math.cos(a), RY, BZ + 10 + RR * Math.sin(a)), t1 = p(4.6 * Math.cos(a + 0.4), RY - 12, BZ + 10 + 4.6 * Math.sin(a + 0.4)); net += `<path d="M${P2(t0)}L${P2(t1)}" stroke="#ffffff" stroke-width="${f1(0.3 * k)}" opacity="0.9"/>`; });
        net += [4, 8].map(dy => `<path d="${sp(p, ellPts(0, BZ + 10, RR - dy * 0.3, RR - dy * 0.3, 22), RY - dy)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.3 * k)}" opacity="0.8"/>`).join('');
        f += `<g>${pl ? atV('scale', ['1 1', '1 1', '1 1.08', '1 1', '1 1'], 3.2) : ''}${net}</g><path d="M${rim.map(P2).join('L')}Z" fill="none" stroke="#e8642a" stroke-width="${f1(1.1 * k)}"/>`;
        if (pl) { const sh = [[-24, 34, 30], [-12, RY + 8, 8], [0, RY + 4, BZ + 10], [0, RY - 10, BZ + 10], [0, BR, BZ + 15], [4, 12, BZ + 25], [12, BR, 6], [18, 14, 18], [22, BR, 26], [-10, 22, 30], [-24, 34, 30]];
          f += ballFly32(p, k, sh, 3.2, BALL32(BR, 'bball')); }
        else f += ballRest32(p, k, 10, BR, 6, BALL32(BR, 'bball'));
        return { defs: BALLDEF + (H7.FDEF || ''), under: un, front: f, bb: bbOf([p(-50, 0, -36), p(50, 0, 54), p(-50, 0, 54), p(50, 0, -36), p(0, RY + BH + 2, BZ), p(-BW / 2, RY + BH, BZ), p(BW / 2, RY + BH, BZ)], 3) }; };
      return D; }; }
  // YRD-101 HOPSCOTCH (Nov 8, user: remove the background, leave only the drawn chalk): no concrete pad, no dotted texture, no footprint shadow - the
  // squares 1-10 and the HOME arc are chalk straight on the grass (same chalk as the hoop + goal: dusty halo, line, powdery broken pass, specks), each
  // square a faint dusting of its chalk colour, the numbers in coloured chalk. The chalk sticks + the tossed stone stay (the stone is the game).
  { const g9 = N.hop8; N.hop8 = S => { const D = g9(S), pl = H7.isPlay(S), R0 = rng('hop32'); D.noShad = 1;
    D.build = P => [XK.box(0, 0, 0, 2, 0.1, 2, '#ffffff', { op: 0 })];
    D.fx = c => { const p = c.p, k = c.k, P2 = H3.P2; let f = '';
      const SQ = [[-50, 0, 1], [-34, 0, 2], [-18, -8, 3], [-18, 8, 4], [-2, 0, 5], [14, -8, 6], [14, 8, 7], [30, 0, 8], [46, -8, 9], [46, 8, 10]], CC = ['#ff6a8a', '#ffd23a', '#6ad8ff', '#9af06a', '#c89aff'], W = 15;
      // the words read left-to-right on screen at any turn: numbers flip 180 when the court's x runs leftwards, HOME (across the court) picks +z or -z
      const o0 = p(0, 0, 0), ex = p(1, 0, 0)[0] - o0[0], ez = p(0, 0, 1)[0] - o0[0];
      let d = '', tint = '', num = '';
      SQ.forEach(([x, z, n], i) => { const R = rng('hq' + n), j = () => f1((R() - 0.5) * 0.9);
        d += `M${f1(x - W / 2 + +j())} ${f1(z - W / 2 + +j())}L${f1(x + W / 2 + +j())} ${f1(z - W / 2 + +j())}L${f1(x + W / 2 + +j())} ${f1(z + W / 2 + +j())}L${f1(x - W / 2 + +j())} ${f1(z + W / 2 + +j())}Z`;
        tint += `<rect x="${x - W / 2 + 1}" y="${z - W / 2 + 1}" width="${W - 2}" height="${W - 2}" fill="${CC[i % 5]}" opacity="0.13"/>`
          + rep(5, t => `<path d="M${f1(x - 5 + R() * 2)} ${f1(z - 5 + t * 2.4)}l${f1(8 + R() * 2)} ${f1(-1 + R() * 2)}" stroke="${CC[i % 5]}" stroke-width="0.7" stroke-linecap="round" opacity="0.16"/>`).join('');
        num += `<text${ex < 0 ? ` transform="rotate(180 ${x} ${z})"` : ''} x="${x}" y="${z + 2.4}" text-anchor="middle" font-family="Comic Sans MS, Marker Felt, cursive" font-size="7" font-weight="700" fill="${CC[i % 5]}" opacity="0.9">${n}</text>`; });
      // HOME = a real half circle across the whole end of 9 + 10 (r 15.5 about (53.5, 0)), faintly dusted yellow, the word in its middle (user Nov 8)
      d += 'M53.5 -15.5A15.5 15.5 0 0 1 53.5 15.5';
      tint += `<path d="M53.5 -14.5A14.5 14.5 0 0 1 53.5 14.5Z" fill="#ffd23a" opacity="0.1"/>`;
      num += `<text transform="translate(60 0) rotate(${ez < 0 ? -90 : 90})" x="0" y="2.2" text-anchor="middle" font-family="Comic Sans MS, Marker Felt, cursive" font-size="6.5" font-weight="700" fill="#ffd23a" opacity="0.9">HOME</text>`; // across the court, inside the arc (user Nov 8: it read lengthwise)
      const un = `<g transform="${H3.planeH(p, 0.25)}">${tint}</g>` + chalk(p, d, k) + `<g transform="${H3.planeH(p, 0.35)}">${num}</g>` + specks(p, R0, 40, -62, 70, -18, 18);
      const at = (x, y, z, body) => `<g transform="translate(${P2(p(x, y, z))}) scale(${n4(k)})">${body}</g>`;
      f += at(-66, 0.9, 26, '<rect x="-3" y="-0.8" width="6" height="1.6" rx="0.8" fill="#ff6a8a"/><rect x="1" y="1" width="5" height="1.4" rx="0.7" fill="#6ad8ff"/>');
      const STONE = '<ellipse rx="1.8" ry="1" fill="#6a6a64"/><ellipse cx="-0.4" cy="-0.3" rx="0.7" ry="0.35" fill="#9a9a94"/>';
      if (pl) { const A = [-64, 20], B = [-18, 8], pts = []; for (let i = 0; i <= 10; i++) { const t = i / 10; pts.push([A[0] + (B[0] - A[0]) * t, 1.4 + 14 * Math.sin(PI * t), A[1] + (B[1] - A[1]) * t]); }
        pts.push([-18, 1.4, 8], [-18, 1.4, 8], [-18, 1.4, 8], [-18, 1.4, 8], [-64, 1.4, 20]);
        f += `<g><animateMotion dur="6s" repeatCount="indefinite" path="M${pts.map(q => P2(p(...q))).join('L')}"/><g transform="scale(${n4(k)})">${STONE}</g></g>`; }
      else f += at(-18, 1.4, 8, STONE);
      return { defs: H7.FDEF || '', under: un, front: f, bb: H3.bbOf([p(-76, 0, -35), p(76, 0, 35), p(-76, 0, 35), p(76, 0, -35)], 3) }; };
    return D; }; }
  // YRD-107 GAZEBO DAYBED moved into Canopies (Nov 7): like the other canopies it gets a D.inside split (posts, drapes, valances + roof over a sitter, the
  // daybed behind), so a creature on the far seat of a turned gazebo is no longer drawn behind the whole piece. The posts, drapes and roof are lifted 40
  // (everything above y 40 eases up over 20 units; the daybed is untouched) so the near valance clears a sitting head on the far seat too.
  { const g = N.luxDaybed, LIFT = 40, my = y => y + LIFT * Math.min(1, Math.max(0, (y - 40) / 20)), mv = q => [q[0], my(q[1]), q[2]];
    if (g && !g._lift) { N.luxDaybed = S => { const D = g(S), b0 = D.build, f0 = D.fx;
      D.build = P => b0(P).map(S0 => Object.assign({}, S0, { pts: S0.pts.map(mv), faces: S0.faces.map(F => Object.assign({}, F, { q: F.q.map(mv) })) }, Array.isArray(S0.org) ? { org: mv(S0.org) } : {}));
      if (f0) D.fx = c => f0(Object.assign({}, c, { p: (x, y, z) => c.p(x, my(y), z) }));
      return Object.assign(D, { inside: [0, 26, 0], fxF: 1 }); }; N.luxDaybed._lift = 1; } }
  const BIG32 = { hop8: 3, hoop8: 3.3, goal8: 3, corn32: 3, boc32: 3.2, vil32: 2.6, afr32: 2.6, tramp32: 3, slide32: 2.4, luxDaybed: 3, lawn32: 1.7, adk32: 1.5, block32: 1.6, park32: 1.6, lime32: 1.8, egg32: 2.3, pic32: 1.45, porch32: 1.35, tarp32: 2.6, umb32: 2.7, wist32: 2.6, cab32: 2.6, dome32: 2.6, kid32: 2.3, plg32: 2.2, koi32: 2.2, lap32: 2.3, lag32: 2.2, zen32: 1.35 };
  Object.keys(BIG32).forEach(k => { const g = N[k], f = BIG32[k]; if (!g || g._big) return; N[k] = S => { const D = g(S); D.zs = (D.zs || 1) * f; D.w = Math.round(D.w * f); D.d = Math.round(D.d * f);
      if (D.seats) D.seats = D.seats.map(st => Object.assign({}, st, { x: st.x * f, z: st.z * f, h: st.h * f })); if (D.use) D.use = Object.assign({}, D.use, { x: (D.use.x || 0) * f, z: (D.use.z || 0) * f }, D.use.h != null ? { h: D.use.h * f } : {}); return D; }; N[k]._big = 1; });
  const FENCE32 = { chain: fChain, picket: fPicket, cedar: fCedar, stone: fStone, rain: fRain };

  const GROUND32 = { dirt: gDirt, clover: gClover, zoysia: gZoysia, trav: gTrav, star: gStar }, MEMO = {};
  // game player spots (piece units; projected at the piece's BIG factor + turn so they line up with the picture, see the draw hook). plus9 found players
  // by spec name (PL9[spec]) so the plus32 renames (corn32 / boc32 / vil32 / afr32) had lost theirs; these are spaced for a creature (~33 units across at x3)
  const GAME32 = {
    hop8: [{ x: -6, z: 0, v: 'right', a: 'ghop' }, { x: -86, z: 26, v: 'front', a: 'grest', d: 0.3 }, { x: -60, z: -30, v: 'front', a: 'gjump', d: 0.6 }],
    hoop8: [{ x: -36, z: 34, v: 'back', a: 'gjump' }, { x: 30, z: 28, v: 'back', a: 'grun', d: 0.4 }, { x: 0, z: -4, v: 'front', a: 'gjump', d: 0.6 }],
    goal8: [{ x: 0, z: 6, v: 'front', a: 'gkeep' }, { x: -32, z: 56, v: 'back', a: 'grun' }, { x: 30, z: 48, v: 'back', a: 'gkick', d: 0.3 }],
    corn32: [{ x: -40, z: 22, v: 'right', a: 'gtoss' }, { x: 40, z: -20, v: 'left', a: 'gtoss', d: 0.5 }],
    boc32: [{ x: -52, z: 2, v: 'right', a: 'gswing' }, { x: 52, z: -2, v: 'left', a: 'gswing', d: 0.5 }],
    vil32: [{ x: 22, y: 1, z: 12, v: 'front', a: 'gsplash' }, { x: 60, y: 1, z: 30, v: 'front', a: 'gsplash', d: 0.4 }, { x: -40, y: 0, z: 20, v: 'front', a: 'grest' }],
    afr32: [{ x: 52, z: 8, v: 'left', a: 'gfetch' }, { x: -34, z: 38, v: 'right', a: 'gtoss', d: 0.4 }],
    tramp32: [{ x: -30, y: 30, z: -14, v: 'front', a: 'gbounce' }, { x: 30, y: 30, z: -14, v: 'front', a: 'gbounce', d: 0.35 }, { x: 0, y: 30, z: 26, v: 'front', a: 'gbounce', d: 0.7 }] };
  const drawG = RD.draw;
  RD.draw = (r, o) => { const res = drawG(r, o); if (!res) return res;
    try { const sp0 = r.spec ? r.spec.split(/[.@*+]/)[0] : '', L = GAME32[sp0]; if (L && res.bb) { let ra = o && o.rot != null ? (((+o.rot || 0) % 360) + 360) % 360 : null; if (ra === 330) ra = null; const p = RD.projOf(BIG32[sp0] || 1, ra);
      res.players = L.map(q => { const s = p(q.x, q.y || 0, q.z); return { x: s[0], y: s[1], v: q.v, a: q.a, b: !!q.b, d: q.d || 0 }; }); } } catch (e) { console.warn('plus32 players', e); }
    return res; };
  const draw31 = RD.draw;
  RD.draw = (r, o) => { const res = draw31(r, o); if (!res || res._p32) return res;
    try { const f = r.g32 && GROUND32[r.g32]; if (f && res.surf) { res._p32 = 1; res.vb = '0 0 80 56'; const mk = ax => { AX = ax; try { return RD.svgDoc('0 0 80 56', [], f()); } finally { AX = 1; } };
      const M = MEMO[r.g32] || (MEMO[r.g32] = { cat: mk(1), room: mk(0.42) }); res.svg = M.room; res.src = 'data:image/svg+xml,' + encodeURIComponent(M.cat); }
      const fe = r.f32 && FENCE32[r.f32]; if (fe && res.surf) { res._p32 = 1; res.vb = '0 0 80 56'; res.fW = 160;
        const M = MEMO['f:' + r.f32] || (MEMO['f:' + r.f32] = { cat: RD.svgDoc('0 0 80 56', [], fe(80, false)), room: RD.svgDoc('0 0 160 56', [], fe(160, true) + '<g/>') }); res.svg = M.room; res.src = 'data:image/svg+xml,' + encodeURIComponent(M.cat);
        // the stone wall: one 320 tile per side (no repeats), the gate only on the right side (house: rt.fenceR / rt.fWR)
        // the stone wall: drawn inline by the house as vector in room coordinates (res.wallRoom = both sides with depth, see fStoneWall3; wallL flags it)
        if (r.f32 === 'stone') { const WH = 104, W2 = MEMO['f:stone3'] || (MEMO['f:stone3'] = fStoneWall3('L', false, WH) + fStoneWall3('R', true, WH));
          res.wallRoom = W2; res.wallL = 1; res.fH = WH; } }
      // yard-lights surface with its own room overlay: the native shell string is switched off (k none) and the house draws res.ylRoom instead
      if (r.yl32 === 'edison' && res.surf) { res._p32 = 1; const M = MEMO.yl || (MEMO.yl = { cat: edisonCard(), room: 'data:image/svg+xml,' + encodeURIComponent(edisonRoom()) }); res.svg = M.cat; res.src = 'data:image/svg+xml,' + encodeURIComponent(M.cat); res.ylRoom = M.room; if (X.SPEC) X.SPEC['rv_' + r.id] = { k: 'none' }; } } catch (e) { console.warn('reno plus32', r.id, e); }
    return res; };

  RD.SET32 = {
    'YRD-005': { g32: 'dirt', live: 'Puddles ripple, crabgrass stirs', note: 'A neglected yard of sun-baked brown dirt with dry cracks, pebbles, wheel ruts and thin dead grass. Scruffy clumps of crabgrass, half green and half straw-yellow, sprawl here and there, and two brown mud puddles reflect a grey sky, with sneaker and paw prints pressed into the mud around them. A rusty bottle cap and a popsicle stick lie in the dirt. Drips ring the puddles and the crabgrass stirs in the breeze.' },
    'YRD-025': { g32: 'clover', live: 'Grass waves, clover flowers nod', note: 'A young lawn grown from a ryegrass and white clover seed mix: soft bright grass with patches of three-leaf clover and little white-pink pom-pom flowers. A couple of thin spots have not filled in yet and show soil, seed and golden straw mulch. A dandelion and a few daisies pop up. The grass waves in slow rows and the clover flowers nod.' },
    'YRD-045': { g32: 'zoysia', live: 'Wind sheen and sun dapples drift', note: 'A dense, carpet-like zoysia lawn cut short with crisp mowing stripes, and a curving path of irregular bluestone flagstones set flush in the turf, with pale worn tops, a little moss in the joints and clean grass edges. Wind sheen slides across the stripes and soft sun dapples drift over the lawn and stones.' },
    'YRD-065': { g32: 'trav', live: 'Leaf shadows drift, dew twinkles', note: 'A courtyard checkerboard of honed, tumbled travertine squares in ivory, cream and walnut tones, each with soft banding and the little open pits travertine is known for, alternating with squares of velvety cushion moss with tiny red-brown spore stalks. Warm late sun lies across it. Leaf shadows drift slowly over the stone and dew twinkles on the moss.' },
    'YRD-085': { g32: 'star', live: 'Moss glows in waves, deck shimmers', note: 'A velvet lawn of deep emerald star moss with a raised patio deck of large porcelain slabs in warm white, with soft grey and gold veins running across the joints and a polished sky reflection. A bronze edge and a warm light line wash the moss below the step. Pale mint specks in the moss glow in slow waves and glowing spores float up, while a glint slides over the heated slabs and the warm deck gently shimmers.' },
    'YRD-021': { f32: 'picket', live: 'Flowers nod, a butterfly flits', note: 'A cosy white-painted picket fence: pointed pickets on two rails and square posts with pyramid caps. Wood grain shows faintly through the paint, a few chips show bare wood, the bottoms carry a little dirt splash and one picket leans a touch. A pink climbing rose winds up a post, tulips and daisies line the base and the pickets cast stripes of shadow on the lawn. The flowers nod and a butterfly flits past.' },
    'YRD-041': { f32: 'cedar', live: 'Leaf shadows drift, grass sways', note: 'A tall modern privacy fence of horizontal western red cedar boards in honey to reddish-brown, with long grain, the odd knot and narrow, even gaps. A cedar cap rail runs along the top between black powder-coated steel posts, a small black wall light washes the boards with warm light, and ornamental grass grows in a gravel strip at the base. Leaf shadows drift across the boards, the grass sways and the light glows softly.' },
    'YRD-061': { f32: 'stone', live: 'Lanterns flicker, ivy sways', note: 'A dressed limestone garden wall in warm cream courses with fine recessed joints and a moulded coping stone. Two square pillars with stone caps carry iron lanterns either side of an arched black wrought-iron double gate with scrollwork and gilded spear tips, with a garden path glimpsed through it. English ivy cascades over the coping. The lanterns flicker warm on the stone and the ivy tendrils sway.' },
    'YRD-081': { f32: 'rain', live: 'Mist breathes, force field ripples', note: 'A tall living wall planted like a rainforest: deep moss behind ferns, split monstera leaves, red and orange bromeliads, white and pink orchids and trailing vines, held in a dark bronze frame over a long honed-stone planter with warm uplights. Above it a faint iridescent hexagon force field shimmers. Misting nozzles breathe little clouds, the fronds sway, the force field ripples and the uplights glow warm.' },
    'YRD-009': { spec: 'tarp32', name: 'Torn Blue Tarp Tied to Broomsticks', live: 'Flap flutters, drips fall', note: 'A sun-faded blue tarp with metal grommets, tied with frayed yellow rope and a bungee cord to four mismatched broomsticks. One still has its broom head, two lean, one stands in a bucket of rocks and one in a cinder block. It sags into a rain puddle, has duct-tape patches and a couple of holes, and one corner is torn off with a flap hanging down. The flap flutters, the tarp breathes and water drips from the flap.' },
    'YRD-029': { spec: 'umb32', live: 'Canopy breathes, valance flutters', note: 'A crank-open patio umbrella with blue and cream canvas panels that sag softly between the ribs, stitched seams, a pinstripe band near the rim and a little sun fading. It has a raised wind vent with a finial, a scalloped valance, white steel ribs, a two-piece pole with a crank handle and a tilt button, a moulded base and a tie strap hanging from one rib, and it casts soft shade on the ground. The canopy breathes, the valance flutters and the strap swings.' },
    'YRD-049': { spec: 'wist32', live: 'Wisteria sways, petals drift', note: 'A cedar pergola with notched rafters under a fresh green leaf canopy. About forty long wisteria clusters hang down, pale lilac at the top deepening to violet at the tips, and vines spiral up the posts. Underneath is a cushioned bench with lavender and cream pillows and a stone table set with a teapot and two cups, in dappled shade. The clusters sway, petals drift down and the shade shifts. Seats 2.' },
    'YRD-069': { spec: 'cab32', live: 'Louvers tilt, drapes sway', note: 'A charcoal aluminium bioclimatic cabana whose roof louvers tilt open and shut on their motor, with a warm light line round the frame. It stands on an oiled teak deck with a cream wool rug, a deep cushioned sofa with throw pillows, a teak coffee table with a brass hurricane lantern, a potted olive tree and sheer linen drapes tied back at the front posts. The drapes sway, the candle flickers and warm light pools on the deck. Seats 2.' },
    'YRD-089': { spec: 'dome32', live: 'Panes slide, chandelier glows', note: 'A geodesic dome of triangular glass panes in a slim bronze frame on a honed marble plinth with a polished brass ring. Inside are a teak daybed with cream cushions and terracotta and saffron pillows, a potted fan palm, a fern, a brass side table and a brass chandelier hanging from the top. One wedge of panes slides open and closed, a sheen glides over the glass, the chandelier glows warm and the palm sways. Seats 2.' },
    'YRD-003': { spec: 'zap32', live: 'Zapping, moths circle', note: 'A violet UV bug-zapper bulb in a cracked cage on a rusty hook, on a weathered grey stake pushed into a dirt mound. An orange extension cord is taped down the post with grey duct tape and coiled in the grass, a cobweb stretches between arm and post, and dead bugs litter the ground underneath. Moths circle the light and every few seconds it zaps with a bright flash.' },
    'YRD-023': { spec: 'solar32', live: 'Glows breathe, one flickers', note: 'A row of five cheap black plastic solar stake lights pushed into the lawn, one leaning and one with a cracked cap: thin stems, frosted faceted lanterns and little blue solar cells on top. Each throws a soft glow on the grass. The glows breathe gently and the leaning one flickers on a low battery.' },
    'YRD-043': { yl32: 'edison', live: 'Bulbs flicker softly', note: 'Strands of amber Edison bulbs criss-cross the yard from the house gutter to posts on the fence tops: black sockets, teardrop glass and glowing filaments with warm halos, bigger toward the front. The bulbs flicker softly out of step and the strands sway a touch.' },
    'YRD-002': { spec: 'hib32', note: 'A heavy cast-iron hibachi with casting ribs, flaky rust, sliding draft doors, wooden end handles and twin grates on notched posts. A torn paper sack of briquettes slumps beside it with a few spilled on the ground, rusty tongs lie in front and grey ash dust marks the ground underneath. Tap to light the coals.' },
    'YRD-022': { spec: 'ket32', note: 'The classic red enamel kettle grill: glossy dome lid with a chrome vent and thermometer, black handle, ash catcher, triangle rack and two wheels. A grill brush and a spatula hang from the side handle, a chimney starter waits on the ground and a little grease drip runs down the bowl. Tap to grill.' },
    'YRD-042': { spec: 'gas32', play: 'grill', live: 'Tap to grill', note: 'A brushed stainless cart grill with a two-door cabinet on casters, a domed hood with a thermometer and handle, four black knobs and an igniter, a side shelf with a spatula, tongs and a brush on hooks over a white propane tank, and a black steel offset smoker barrel with a firebox door and chimney. Tap to grill: the hood swings open on steaks, corn and peppers, flames lick the grates, the knobs glow and smoke pours from the hood and the smoker.' },
    'YRD-063': { spec: 'uplit32', live: 'Beams breathe, brass glints', note: 'A planted strip in grey river-pebble mulch with a steel edge: a slim Japanese maple with red leaves and two clipped boxwood balls, each lit from below by a polished brass bullet uplight with a glare snoot on a knuckle stake, plus two short brass louvred path bollards that throw pools of light on the pebbles. The warm beams breathe, glints slide on the brass and the maple leaves sway.' },
    'YRD-083': { spec: 'fly32', live: 'Swarm glides and blinks', note: 'A sculptural docking plinth of black marble with a polished brass band and a frosted glass cap ringed with soft light. Twenty-one tiny glass-orb drones glide in slow figure-eight loops in three layers, glowing gold, pale lime and warm white like fireflies; each blinks out of step and trails fading ghosts of light, and warm light pools on the lawn.' },
    'YRD-062': { spec: 'kitch32', play: 'grill', live: 'Tap to fire it up', note: 'A stacked fieldstone outdoor kitchen with a thick honed quartzite counter, a stainless built-in grill with a hood, two stainless access doors and a board of tomatoes, basil and olive oil. At the end stands a domed terracotta pizza oven with a brick-arched mouth, an iron door leaning against it, a black flue and a log store underneath; embers glow low inside. Tap to fire it up: flames roar, a pizza bakes in the mouth and smoke rises from the flue and the grill.' },
    'YRD-012': { spec: 'tin32', name: 'Rusted Corrugated Tin Tool Shed', live: 'Loose tin rattles', note: 'A small galvanised corrugated tin shed gone dull and rusty, with rust runs down from the gable roof and one roof corner lifting. The front panel is dented and the tin door hangs ajar on a dark inside with tool handles, an open padlock dangling from the hasp. A loose sheet flaps at the side, a rake leans against it and weeds grow round the base. The loose tin rattles in the wind and the padlock swings.' },
    'YRD-032': { spec: 'pot32', live: 'Flowers nod, butterfly visits', note: 'A cosy sage-green board-and-batten potting shed with white corner boards and a cedar shingle roof. It has a cream door with a four-pane window and a brass knob, a white window with blue-grey shutters and a window box of red geraniums, white alyssum and trailing ivy, a heart cut-out in the gable and a black lantern by the door. A potting bench at the side holds terracotta pots, seedlings and a watering can. The flowers nod, the ivy sways, the lantern glows and a butterfly visits.' },
    'YRD-052': { spec: 'gh32', live: 'Sheen glides, vent breathes', note: 'A Victorian glass house on a red-brick knee wall, with a cedar frame and glazing bars, a glass gable roof with white ornamental cresting and turned finials, a propped roof vent and a glazed cedar door. Inside are slatted benches with terracotta pots, tomato vines with red fruit, ferns and a hanging basket, with condensation beading on a few panes. A sheen glides across the glass, the vent breathes open and shut and the hanging basket sways.' },
    'YRD-072': { spec: 'poolh32', live: 'Curtain sways, lights breathe', note: 'A low modern pool house with a thin white cantilevered roof over a teak soffit with warm downlights, teak slat cladding on the side and a stacked travertine wall inside. Floor-to-ceiling glass sliders in slim black frames open onto a warm studio with a linen daybed, a pendant, an olive tree and a sheer curtain. A teak deck in front holds a bench with rolled towels and a potted olive. The curtain sways, the lights breathe and a sheen slides over the glass.' },
    'YRD-092': { spec: 'zen32', live: 'Koi swim, steam curls', note: 'A koi pond with lily pads, stepping stones and a stone lantern, with a hinoki-timber tea pavilion standing in the water on slim posts. It has frameless glass walls in thin bronze frames, a shoji screen at the back and a deep charcoal-copper hip roof. Inside are a low tea table with a tea set, two cushions and a paper floor lantern, and a red maple leans over the water. Koi swim, ripples spread, steam curls from the teapot and the lanterns glow. Seats 2.' },
    'YRD-082': { spec: 'chef32', live: 'Robot arm flips, chicken turns', note: 'Under a slim bronze canopy with a warm light line and two glass pendants stands a black marble island with gold veins on walnut slats. A white robot arm flips shrimp and vegetables on a mirror-steel teppanyaki plate, a chicken turns in a glass rotisserie cabinet over a glowing element, and a glass-door outdoor fridge glows full of bottles. Steam and sizzle rise and the pendants breathe.' },
    'YRD-004': { spec: 'gnome32', live: 'Flamingo wobbles', note: 'A sun-faded plastic pink flamingo on two bent wire legs, with chipped white spots and a scuffed beak, beside a small resin garden gnome with a faded red hat, a chipped beard and a tiny shovel. They stand in a scruffy patch of grass with a dandelion. The flamingo wobbles on its wire legs in the breeze and the dandelion nods.' },
    'YRD-024': { spec: 'chime32', note: 'Copper chime tubes with green verdigris hang from a black shepherd hook beside a weathered cottage birdhouse on a post, with grain showing through peeling paint, moss on the roof edge and a little bird peeking from the hole. Birdseed is scattered underneath and pink cosmos grow at the foot of the post. The chimes sway and ring.' },
    'YRD-044': { spec: 'bath32', live: 'Water trickles, sparrow bathes', note: 'A two-tier cast-stone birdbath on a fluted pedestal, its small upper bowl spilling into a wide lower basin, beside a short stone sundial pedestal with a bronze dial, engraved hour lines and a gnomon. Moss and lichen grow on the stone and a sparrow bathes in the lower basin. Water trickles down, ripples spread, the sparrow dips and flicks water and the gnomon shadow creeps round.' },
    'YRD-064': { spec: 'zen32b', live: 'Lanterns flicker, water drips', note: 'A raked white-gravel garden with ripple rings round mossy boulders and a seated limestone Buddha in meditation on a lotus plinth, with robe folds, hands resting in the lap, a serene face and a topknot, weathered with lichen. Two stone pagoda lanterns glow warm, a stone water basin is fed by a bamboo spout and moss cushions and mondo grass edge the gravel. The lanterns flicker, water drips from the bamboo and rings spread in the basin.' },
    'YRD-084': { spec: 'kin32', live: 'Sphere floats, rings turn', note: 'A low plinth of polished black granite with a brass inlay ring, with a mirror-chrome sphere floating above it inside three nested chrome rings that turn on different axes, reflecting sky and garden. A faint cool glow shines under the float. The sphere bobs, the rings turn at their own speeds and the glow and shadow breathe with the bob.' },
    'YRD-006': { spec: 'lawn32', note: 'Two cheap resin stacking chairs gone yellow-grey in the sun, with hairline cracks, dirty water marks on the seats, a missing back slat and a split leg patched with silver duct tape. Grass grows up between the legs. Seats 2.' },
    'YRD-026': { spec: 'adk32', live: 'Mug steams', note: 'A cedar Adirondack chair with a tall slatted back that rounds over at the top, wide flat arms, a sloped slatted seat and grain silvering in the sun. A red plaid blanket is folded over one arm and an enamel mug of cocoa sits on the other. Steam curls from the mug and the blanket fringe stirs.' },
    'YRD-046': { spec: 'wick32', live: 'Lantern flickers', note: 'A dark espresso resin-wicker L sectional with basket weave on every face and a woven rim, deep navy seat and back cushions with white piping and a chaise end. It has throw pillows in white with a navy stripe, coral and sand, a knitted throw over the chaise and a woven tray with a candle lantern and glasses. The lantern flickers. Seats 4.' },
    'YRD-066': { spec: 'cabana32', live: 'Curtains billow', note: 'An oiled teak daybed platform with a thick white mattress, bolsters and sand and sage pillows under a four-post teak canopy with a taut linen roof. Long sheer linen curtains are tied back at the rear posts and flow loose at the front, and a rolled towel and a teak tray with a citrus drink sit on the corner. The front curtains billow, the back ties sway and the ice in the drink glints. A spot to nap.' },
    'YRD-020': { spec: 'coir32', note: 'A stiff brown coir doormat on a black rubber backing, with a worn bald patch in the middle, muddy boot and paw prints, frayed fibres along the edge and a dead leaf caught in the bristles that stirs in the breeze.' },
    'YRD-040': { spec: 'camp32', live: 'Corner lifts in the breeze', note: 'A woven recycled-plastic camping mat in teal, sand, white and coral bands with visible over-under straps, taped edges, brass corner grommets, two fold creases and grass poking up along one edge. One corner lifts in the breeze.' },
    'YRD-060': { spec: 'kilim32', note: 'A flatweave kilim in terracotta, rust, cream, sand and charcoal, with stepped diamond medallions in a field of small crosses, a stepped border, a visible weft texture and knotted fringe on both short ends that stirs in the breeze.' },
    'YRD-080': { spec: 'sunb32', live: 'Sun dapples drift', note: 'A soft hand-loomed outdoor carpet in navy, sand and white cabana stripes with a looped texture, a wide sand cotton binding with tight stitching and tassels at the corners. Warm sun dapples drift over it.' },
    'YRD-100': { spec: 'hydro32', live: 'Water beads roll off', note: 'A plush quilted outdoor tapestry of pearl-white pillow cells with an iridescent sheen and champagne piping. Water beads roll off to the edges, the seams pulse with light as it cleans itself and a sheen slides across.' },
    'YRD-010': { spec: 'net32', live: 'Net sways', note: 'A frayed natural-rope diamond net sagging between two grey weathered posts, one leaning and one split, with a messy extra rope knotted round a post and a few dead leaves caught in the net. The net sways. A spot to nap.' },
    'YRD-030': { spec: 'can32', live: 'Hammock rocks', note: 'A quilted canvas hammock in cream, sage and terracotta stripes, held flat by varnished wooden spreader bars on S-hooks and chains from a charcoal steel arc stand, with a matching pillow. It rocks gently. A spot to nap.' },
    'YRD-050': { spec: 'egg32', live: 'Egg sways', note: 'An egg of honey rattan in a diagonal weave with a woven rim round the opening, hanging by a chain from a black steel C-stand on a weighted base, with a thick cream seat cushion, a back cushion and a mustard pillow. The egg sways gently on its chain.' },
    'YRD-070': { spec: 'porch32', live: 'Swinging, lantern glows', note: 'A cedar daybed swing with a thick mattress and pillows, hanging on ropes from a cedar A-frame, with a brass candle lantern at one end of the beam, a trailing fern basket at the other and warm string lights wound along it. The bed swings, the lantern glows and the lights twinkle. Seats 2.' },
    'YRD-090': { spec: 'cloud32', live: 'Cloud bobs, stars twinkle', note: 'A soft cloud of a hammock floating with no ropes between two slim obsidian pylons with brass caps and pulsing blue field rings, glowing gently underneath, under a small night-sky canopy of twinkling stars. The cloud bobs and breathes. A spot to nap.' },
    'YRD-086': { spec: 'pod32', live: 'Pod bobs, mist drifts', note: 'A pearl-white sculpted pod lounger with a sand cushion floating on a shallow turquoise pool, a solar-glass hood arched over the head end letting a fine cooling mist drift down, and a drink in a side holder. The pod bobs, ripples spread, mist drifts and the solar cells glint. A spot to nap.' },
    'YRD-013': { spec: 'block32', note: 'Grey weathered, unpainted 2x4 planks laid across stacked cinderblocks, with splits, rusty nail heads, chipped block corners, moss in the block holes, a cobweb under the seat and a squashed soda can by a block. Seats 2.' },
    'YRD-033': { spec: 'park32', live: 'A leaf skitters', note: 'A cast-iron park bench with oak slats: chipped black paint showing rust on the iron, weathered slats with grain, a few fallen leaves on the seat and a small brass plaque on the back rail. One leaf skitters in the breeze. Seats 2.' },
    'YRD-053': { spec: 'lime32', live: 'Ivy stirs, page lifts', note: 'A curved English limestone bench with lichen and moss on the stone, ivy creeping up the legs, a folded linen cushion and an open book on the seat. The ivy stirs and a page lifts in the breeze. Seats 3.' },
    'YRD-073': { spec: 'root32', note: 'A thick slab of teak with its natural wavy live edge, oiled to a warm glow with growth rings at the ends, resting on a sculptural base of gnarled, twisting teak roots, with a linen pad at one end. Seats 2.' },
    'YRD-093': { spec: 'glow32', live: 'Light breathes, heat shimmers', note: 'A sweeping curved bench of warm honed sandstone in two tiers, with a warm amber light line under the seat lip, thin oatmeal seat pads and a faint heat shimmer rising off the warm stone. Seats 2.' },
    'YRD-016': { spec: 'fold32', live: 'A fly circles', note: 'A blow-moulded off-white plastic folding table gone grubby, with a water ring, a scuff and a hairline crack, grey steel folding legs with rusty feet, a crumpled paper plate and a tipped plastic cup. A fly circles overhead.' },
    'YRD-036': { spec: 'pic32', live: 'Candle flickers', note: 'A classic redwood A-frame picnic table with grain and knots, a checkered cloth, a jar of lemonade beaded with condensation and a citronella bucket candle flickering on the table. Seats 4.' },
    'YRD-056': { spec: 'mos32', live: 'Espresso steams', note: 'A round bistro table topped with colourful mosaic tiles on a scrolled wrought-iron base, with an espresso cup steaming beside a little pot of basil.' },
    'YRD-076': { spec: 'teak32', live: 'Candles flicker', note: 'A ten-foot harvest dining table of reclaimed teak with a linen runner, three brass candlesticks with flickering tapers and wine glasses that catch the light.' },
    'YRD-096': { spec: 'onyx32', live: 'Onyx glows, water runs', note: 'A banquet table of backlit honey onyx with a water channel running down its length. Light pulses slowly through the stone and a shimmer runs down the channel.' },
    'YRD-019': { spec: 'bkt32', note: 'An orange plastic 5-gallon bucket turned upside down as a seat-side table, with scuffs, a hairline crack and a ring of dirt where it sat. Tap to tip it over.' },
    'YRD-039': { spec: 'stp32', live: 'Ants march', note: 'A rough-cut tree stump side table with moss on the bark, crack lines through the rings and a cluster of little mushrooms at its foot. A trail of ants marches over the top.' },
    'YRD-059': { spec: 'cob32', live: 'Glaze glints', note: 'A barrel-shaped porcelain garden stool in deep cobalt glaze with two raised nail-head bands, pierced coin openings on the sides and a white crackle-glaze top. The glossy glaze glints.' },
    'YRD-079': { spec: 'drum32', live: 'Candle glows through', note: 'A drum of cast bronze in an open interlocking lattice with a warm patina and polished high points, a smoked-glass top and a hurricane candle inside. The candle flickers and its light dances through the lattice.' },
    'YRD-099': { spec: 'ped32', note: 'A sleek solar pedestal that holds a drink floating in mid-air above its charging cells. A glint sweeps over the cells and the floating glass beads with condensation.' },
    'YRD-018': { spec: 'camp32b', live: 'Small fire flickers', note: 'A rough ring of mismatched broken bricks and a couple of stones on scorched dirt, with a tepee of twigs burning low over grey ash, a crumpled newspaper ball and a marshmallow stick dropped by the ring. Small flames flicker, embers float and thin smoke rises.' },
    'YRD-038': { spec: 'bowl32', note: 'A black steel bowl fire pit on curved legs with a spark screen ring, a few seasoned logs stacked beside it and a fire poker leaning on the rim. Tap to light the fire.' },
    'YRD-058': { spec: 'chim32', note: 'A terracotta Mexican chiminea with a painted band, a smoke stack and a glowing mouth, with a little stack of wood and a saucer of pine cones beside it.' },
    'YRD-078': { spec: 'pit32', live: 'Flames dance', note: 'A square sunken conversation pit edged in board-formed concrete with built-in benches and charcoal cushions, around a long low concrete fire table with a bed of glass beads and a row of dancing flames. Warm light glows on the walls.' },
    'YRD-098': { spec: 'obel32', note: 'A black obsidian obelisk floating over a ring of fire and a water moat, with embers rising around it and a warm glow on the water.' },
    'YRD-008': { spec: 'can32b', live: 'Candle flickers', note: 'A dented galvanised watering can gone rusty, with a long spout and rose, beside a citronella candle in a dented tin bucket with a scorched rim. The candle flickers and a thin smoke curls.' },
    'YRD-028': { spec: 'tub32', note: 'A galvanised beverage tub full of ice and bottles, beaded with condensation, with a red checkered napkin holder beside it. The ice cubes glint.' },
    'YRD-048': { spec: 'torch32', live: 'Flames flicker', note: 'A terracotta citronella torch on a bamboo pole and a glass hurricane lantern with a pillar candle ringed by pressed ferns and a dried lemon slice. Both flames flicker and a thin smoke curls.' },
    'YRD-068': { spec: 'ice32', live: 'Crystal glints', note: 'A polished brass ice bucket with ring handles, full of ice and a bottle, a cut-crystal pitcher of cucumber water and black-and-gold bonsai shears on a walnut tray. Light glints over the crystal and brass.' },
    'YRD-088': { spec: 'glb32', note: 'A holographic star-map globe turning over a dark pedestal, with constellation lines glowing across it, beside a self-chilling carafe floating in mid-air.' },
    'YRD-007': { spec: 'tire32', note: 'An old cracked rubber tire with worn tread, filled with potting soil and a few marigolds, with soil spilled on the ground and weeds growing round it.' },
    'YRD-027': { spec: 'veg32', live: 'Leaves stir', note: 'A cedar raised bed planted in rows: butterhead lettuces, feathery carrot tops, a staked tomato with red and green fruit and little wooden row markers. The leaves stir in the breeze.' },
    'YRD-047': { spec: 'str32', live: 'A bee visits', note: 'A tiered terracotta tower of herbs and strawberries, with ripe berries hanging over the pocket lips and small white flowers. A bumblebee buzzes round it.' },
    'YRD-067': { spec: 'par32', live: 'Butterflies flutter', note: 'A formal French parterre of clipped boxwood in fine leaf texture around raked gravel paths, with pink and cream roses climbing the arch. A pair of white butterflies flutter by.' },
    'YRD-087': { spec: 'orch32', live: 'Islands float, pollen glows', note: 'Exotic orchids and bonsai on little sky-islands floating over glowing rings, with soft mist trailing beneath them and glowing pollen drifting between the blooms.' },
    'YRD-011': { spec: 'sap32', note: 'A scraggy little sapling tied to a bamboo cane with fraying twine, with a plastic nursery tag, a ring of dry dead leaves and weeds round it.' },
    'YRD-031': { spec: 'lem32', note: 'A dwarf Meyer lemon tree in a half-barrel planter, dotted with lemons and white blossoms, with a couple of fallen lemons on the ground.' },
    'YRD-051': { spec: 'chy32', live: 'Petals fall', note: 'A weeping cherry tree in full pink bloom, with a carpet of fallen petals round the trunk and more petals drifting down.' },
    'YRD-071': { spec: 'grv32', live: 'Bees buzz', note: 'An ancient twisted olive and tall cypresses over gravel and lavender, with fallen black olives, a weathered terracotta urn on its side and bees buzzing over the lavender.' },
    'YRD-091': { spec: 'wil32', live: 'Glowing strands sway', note: 'A giant spirit-willow whose curtain of glowing strands sways in slow waves, with glowing roots spreading across the ground, spirit motes rising and a soft light pooled under the canopy.' },
    'YRD-014': { spec: 'tun32', note: 'A scuffed, dusty pop-up pet tunnel with a chewed grey-green tennis ball beside it and paw prints in the dirt. Tap to play.' },
    'YRD-034': { spec: 'afr32', note: 'A wooden A-frame pet house on a patch of turf with a frisbee, a steel water bowl, a rope chew toy and paw prints across the grass. Tap to play.' },
    'YRD-054': { spec: 'agi32', live: 'Pennant flutters', note: 'A pet agility course with a tire jump, weave poles and a seesaw, paw prints along the course, a treat pouch and a little pennant fluttering on the jump. Tap to play.' },
    'YRD-074': { spec: 'vil32', note: 'A white mini-mansion pet villa with a blue roof and a splash pad, two clipped topiaries in white planters by the door and sparkles running over the water jets. Tap to play.' },
    'YRD-094': { spec: 'bnc32', live: 'Ball floats and bounces', note: 'A glowing anti-gravity bounce dome with an automated fetch launcher, a ball bobbing weightlessly inside and a glow ring pulsing on the floor with each bounce. Tap to play.' },
    'YRD-015': { spec: 'kid32', note: 'A blue inflatable kiddie pool, a little sun-faded, with grass clippings and a dead leaf floating in it and a green garden hose snaking over the rim. Seats 2.' },
    'YRD-035': { spec: 'plg32', live: 'Water shimmers', note: 'An above-ground cedar-wall plunge pool with steps, a rolled towel and a lantern on the cap, and light shimmering on the water. Seats 3.' },
    'YRD-055': { spec: 'koi32', live: 'Waterfall flows, dragonfly darts', note: 'A natural stone koi pond with a little waterfall, lily pads and koi, with a blue dragonfly darting over the water.' },
    'YRD-075': { spec: 'lap32', live: 'Light dances on the water', note: 'A long heated saltwater lap pool in travertine with lane ropes and a sunken sun shelf, light dancing on the water and faint steam curling off the warm shelf. Seats 4.' },
    'YRD-095': { spec: 'lag32', live: 'Water shimmers', note: 'A glass-walled infinity lagoon with a rock grotto waterfall and a swim-up bar, with light shimmering across the water. Seats 5.' },
    'YRD-017': { spec: 'shoe32', name: 'Crooked Horseshoe Stake in the Dirt', note: 'Two crooked steel stakes in worn sand pits, with rusty horseshoes lying in the sand and a scuffed throwing line between them. Tap to play.' },
    'YRD-037': { spec: 'corn32', note: 'A pair of plastic cornhole boards with red and blue beanbags scattered on the grass and one on a board. Tap to play.' },
    'YRD-057': { spec: 'boc32', name: 'Outdoor Ping-Pong Table', live: 'Ping-pong ball rallies over the net', note: 'A weatherproof blue ping-pong table on a folding steel frame with two paddles; the ball rallies back and forth over the net. Tap to play (2 players).' },
    'YRD-077': { spec: 'glf32', note: 'A private three-hole putting green with flags beside an outdoor cinema screen, with a golf ball rolling toward a hole. Tap to play.' },
    'YRD-097': { spec: 'ar32', live: 'Hologram flickers, ball loops', note: 'A round glowing projection pad with a hologram goal and a ball looping through it, beside a brass refracting telescope on a wooden tripod angled up at the sky. The hologram flickers, the ring pulses and the telescope slowly sweeps.' },
    'YRD-001': { f32: 'chain', live: 'Bag flutters, loose wires swing', note: 'Dull galvanised pipe posts with rust blooms and streaks, one leaning, hold a sagging top rail and diamond chain-link mesh with rusty patches. There is a torn hole with cut wire ends and a peeled-back flap, and the bottom of the mesh is curled up over a hollow dug underneath. A plastic bag is snagged on the wire, and weeds and a bindweed vine grow along the base. The bag flutters, the flap and a loose tie wire swing, and the weeds sway.' },
  };
  // Nov 7 user removals from the garden (same filter pattern as RD.DEL16 / RD.DEL31). Furniture: bug zapper 003, watering can 008, tin shed 012,
  // folding table 016, torch & lantern 048, rope hammock 010, canvas hammock 030, rose parterre 067, pool pods 086, root bench 073, pool house 072,
  // cloud hammock 090, floating bonsai 087, glow bench 093. Textiles: patio mat 020, camping mat 040, patio rug 060, cabana carpet 080.
  // Games: tetherball 103, pet tunnel 014, horseshoe stake 017, pet agility 054, jungle gym 105, AR arena 097, pet bounce dome 094, putting green 077, jelly trampoline 122.
  // Nov 7: gazebo daybed moves into Canopies (Pergola / Canopy slot: spin 360, resize to 2x, Canopies tab); trampolines + slides use the scaled own specs;
  // trampolines also start a group bounce (up to 3) when tapped; the pet house frisbee takes 2
  Object.assign(RD.SET32, { 'YRD-107': { slotName: 'Pergola / Canopy' }, 'YRD-120': { spec: 'tramp32', play: 'game', need: 1, max: 3, loop: 60 }, 'YRD-121': { spec: 'tramp32', play: 'game', need: 1, max: 3, loop: 60 },
    'YRD-123': { spec: 'slide32' }, 'YRD-124': { spec: 'slide32' }, 'YRD-125': { spec: 'slide32' } });
  RD.SET32['YRD-034'] = Object.assign({}, RD.SET32['YRD-034'], { max: 2 });
  RD.DEL32 = new Set(['YRD-003', 'YRD-008', 'YRD-012', 'YRD-016', 'YRD-048', 'YRD-010', 'YRD-030', 'YRD-067', 'YRD-086', 'YRD-073', 'YRD-072', 'YRD-090', 'YRD-087', 'YRD-093',
    'YRD-020', 'YRD-040', 'YRD-060', 'YRD-080', 'YRD-103', 'YRD-014', 'YRD-017', 'YRD-054', 'YRD-105', 'YRD-097', 'YRD-094', 'YRD-077', 'YRD-122',
    'YRD-034', 'YRD-074']); // Nov 8 (user): Pet House + Pet Villa removed
  const edit31 = RD.edit;
  RD.edit = rows => edit31(rows).filter(r => !RD.DEL32.has(r.id)).map(r => RD.SET32[r.id] ? Object.assign({}, r, RD.SET32[r.id]) : r);
  RD.H32 = { GROUND32, FENCE32, blades, blobPts, blobD, inBlob };
  RD.PLUS32 = 1;
})();
