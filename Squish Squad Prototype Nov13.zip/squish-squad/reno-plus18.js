// Renovation Catalog round 18 — Living Room electronics remodel (game style, plus15 wrappers).
// TVs (role 'tv': tap = channels; no movie night in the Living Room):
//   LIV-011 rabbit18 CRT on a stool, LIV-031 frame18 wall Frame TV (art mode when off), LIV-051 console18 walnut TV console + turntable + tube amp,
//   LIV-071 oled18 pop-up rollable OLED credenza (huge screen rises out of the slot), LIV-091 holo18 floating holo-screen over an emitter + acoustic fins.
// New rows: LIV-131..135 Speakers (slot 21, role spk; they pump along while a TV in the room is on), LIV-136 robot vacuum + dock (r.vac; page drives the
//   robot sprite D.vac with window.VacBot: tap = it rolls out and cleans for 5 min, then drives back into its dock).
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS17 && RD.H15 && RD.H12 && RD.H11 && RD.H10 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS18) return;
  const K = X.K, shade = K.shade, slab = K.slab, N = RD.N, H = RD.H10, PI = Math.PI;
  const { cam, FR, an, at, SPL, f1, n4, rep, P2, FONT, shadow, isPlay, yawA, sph } = H;
  const { ext, zsort } = RD.H11, { WD } = RD.H12, { DEF15, cone, curve, box3, cyl3 } = RD.H15;
  let NZ = '';
  const DEF18_ = () => DEF15
    + '<linearGradient id="q18gl" x1="0" y1="0" x2="0.5" y2="1"><stop offset="0" stop-color="#3a4150"/><stop offset="0.55" stop-color="#14171f"/><stop offset="1" stop-color="#07080c"/></linearGradient>'
    + '<radialGradient id="q18crt" cx="42%" cy="38%" r="75%"><stop offset="0" stop-color="#5d6f68"/><stop offset="0.6" stop-color="#2c3733"/><stop offset="1" stop-color="#121815"/></radialGradient>'
    + '<radialGradient id="q18vg" cx="50%" cy="50%" r="70%"><stop offset="0.55" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.55"/></radialGradient>'
    + '<linearGradient id="q18sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#78cdfc"/><stop offset="1" stop-color="#e6f8ff"/></linearGradient>'
    + '<linearGradient id="q18rf" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.45" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.62" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
    + '<radialGradient id="q18glw" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffb347" stop-opacity="0.95"/><stop offset="0.5" stop-color="#ff7a1a" stop-opacity="0.45"/><stop offset="1" stop-color="#ff7a1a" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="q18cy" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#8ff6ff" stop-opacity="0.9"/><stop offset="0.5" stop-color="#3fd0ff" stop-opacity="0.35"/><stop offset="1" stop-color="#3fd0ff" stop-opacity="0"/></radialGradient>'
    + '<linearGradient id="q18bm" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#8ff6ff" stop-opacity="0.55"/><stop offset="1" stop-color="#8ff6ff" stop-opacity="0.04"/></linearGradient>'
    + '<pattern id="q18cl" width="1.6" height="1.6" patternUnits="userSpaceOnUse"><rect width="1.6" height="1.6" fill="#d9772e"/><path d="M0 0.4H1.6M0 1.2H1.6" stroke="#a9521a" stroke-width="0.35"/><path d="M0.4 0V1.6M1.2 0V1.6" stroke="#f0a050" stroke-width="0.25" stroke-opacity="0.7"/></pattern>'
    + '<pattern id="q18gr" width="1.4" height="1.4" patternUnits="userSpaceOnUse"><rect width="1.4" height="1.4" fill="#6a4a30"/><circle cx="0.7" cy="0.7" r="0.42" fill="#3a2614"/></pattern>'
    + '<pattern id="q18mg" width="1.2" height="1.2" patternUnits="userSpaceOnUse"><rect width="1.2" height="1.2" fill="#1d1f24"/><circle cx="0.6" cy="0.6" r="0.36" fill="#3a3d45"/></pattern>'
    + '<pattern id="q18sl" width="2" height="2" patternUnits="userSpaceOnUse"><path d="M0 0.5H2" stroke="#000000" stroke-opacity="0.28" stroke-width="0.7"/></pattern>'
    + '<pattern id="q18fl" width="3" height="4" patternUnits="userSpaceOnUse"><rect width="3" height="4" fill="#ffffff" fill-opacity="0.06"/><rect x="2.2" width="0.8" height="4" fill="#000000" fill-opacity="0.28"/></pattern>';
  { let h = 9; const rnd = () => { h = (h * 1103515245 + 12345) | 0; return ((h >>> 8) & 0xffff) / 65536; };
    NZ = rep(3, i => '<pattern id="q18n' + i + '" width="12" height="12" patternUnits="userSpaceOnUse">' + rep(46, () => { const g = Math.round(40 + rnd() * 215); return '<rect x="' + f1(rnd() * 12) + '" y="' + f1(rnd() * 12) + '" width="' + f1(0.5 + rnd() * 1.2) + '" height="0.7" fill="rgb(' + g + ',' + g + ',' + g + ')"/>'; }).join('') + '</pattern>').join(''); }
  const DEF18 = DEF18_() + NZ;
  const ONCE = (v, d, b) => `<animateTransform attributeName="transform" type="translate" values="${v}" dur="${n4(d)}s" begin="${n4(b || 0)}s" fill="freeze" calcMode="spline" keyTimes="0;1" keySplines="0.3 0 0.2 1"/>`;
  const note = (C, x, y, z, i, col) => { const q = C.p(x, y, z), k = C.k, d = 2.4 + (i % 3) * 0.4, b = n4(-i * 0.8);
    return `<text x="${f1(q[0])}" y="${f1(q[1])}" font-size="${f1(6 * k)}" ${FONT} fill="${col || '#5a3a8a'}" opacity="0">${i % 2 ? '♫' : '♪'}${an('opacity', '0;1;0', d, b)}${an('y', f1(q[1]) + ';' + f1(q[1] - 16 * k), d, b)}${an('x', f1(q[0]) + ';' + f1(q[0] + (i % 2 ? 5 : -5) * k), d, b)}</text>`; };

  // ---------- TV picture: "Squish Toons" (8 s loop) drawn in a W x H box (top-left origin, y down). look: crt | clean | vint | holo ----------
  const toon = (C, W, Hh, look, R, ch) => { const cid = C.u('tc'), sx = W / 160, sy = Hh / 90, T = 8;
    const hop = `${at('translate', '0 0;0 -15;0 0', 1, 0, ' calcMode="spline" keyTimes="0;0.45;1" keySplines="0.2 0.6 0.4 1;0.6 0 0.8 0.4"')}`;
    const sq = `${at('scale', '1.18 0.82;0.9 1.12;1 1;1.18 0.82', 1, 0, ' keyTimes="0;0.2;0.55;1"')}`;
    const cloud = (y, s, d, b) => `<g>${at('translate', `-50 ${y};190 ${y}`, d, b)}<g transform="scale(${s})"><ellipse cx="0" cy="0" rx="12" ry="5" fill="#ffffff"/><circle cx="-4" cy="-3" r="5" fill="#ffffff"/><circle cx="4" cy="-4" r="6" fill="#ffffff"/></g></g>`;
    const flower = (x, c) => `<g transform="translate(${x} 78)"><path d="M0 0V-6" stroke="#3f9a3a" stroke-width="0.8"/><g transform="translate(0 -7)">${at('rotate', '-8;8;-8', 2.2, -x / 40)}${rep(5, i => `<circle cx="${f1(Math.cos(i * 1.2566) * 1.8)}" cy="${f1(Math.sin(i * 1.2566) * 1.8)}" r="1.3" fill="${c}"/>`).join('')}<circle r="1" fill="#ffd34a"/></g></g>`;
    const eyes = (dx, dy) => `<g>${an('opacity', '1;1;0;1;1', 3.1, 0, ' keyTimes="0;0.9;0.93;0.96;1"')}<ellipse cx="${-dx}" cy="${dy}" rx="1.2" ry="1.9" fill="#2a1a2a"/><ellipse cx="${dx}" cy="${dy}" rx="1.2" ry="1.9" fill="#2a1a2a"/><circle cx="${-dx + 0.4}" cy="${dy - 0.8}" r="0.45" fill="#ffffff"/><circle cx="${dx + 0.4}" cy="${dy - 0.8}" r="0.45" fill="#ffffff"/></g>`;
    const SC1 = () => ''
      + `<rect width="160" height="90" fill="url(#q18sky)"/>`
      + `<g transform="translate(134 20)"><g>${at('rotate', '0;360', 14)}${rep(8, i => `<path d="M-1.8 -11L0 -16.5L1.8 -11Z" fill="#ffc93a" transform="rotate(${i * 45})"/>`).join('')}</g><circle r="8.4" fill="#ffd84a" stroke="#f0a92a" stroke-width="0.8"/><circle cx="-2.8" cy="-1" r="0.95" fill="#5a3a10"/><circle cx="2.8" cy="-1" r="0.95" fill="#5a3a10"/><path d="M-2.8 2.4Q0 4.8 2.8 2.4" stroke="#5a3a10" stroke-width="0.8" fill="none" stroke-linecap="round"/></g>`
      + cloud(16, 1, 16, 0) + cloud(30, 0.7, 22, -11) + cloud(12, 0.55, 19, -6)
      + `<path d="M0 62Q30 46 62 58T124 54T160 56V90H0Z" fill="#9adf7a"/><path d="M0 72Q42 60 84 70T160 68V90H0Z" fill="#63c25a"/><path d="M0 80Q60 74 160 80V90H0Z" fill="#4fae4c"/>`
      + flower(18, '#ff7aa8') + flower(58, '#ffffff') + flower(104, '#b88aff') + flower(146, '#ff9a4a')
      // Bubu (blue) waves at the side
      + `<g transform="translate(118 79)"><ellipse cy="0.6" rx="9" ry="1.6" fill="#000000" opacity="0.15"/><g>${at('translate', '0 0;0 -1.2;0 0', 0.9)}<path d="M-8 0Q-9 -16 0 -16Q9 -16 8 0Z" fill="#7ab8ff" stroke="#3f7fc8" stroke-width="0.8"/><g transform="translate(7 -9)"><g>${at('rotate', '-20;-80;-20', 0.7)}<ellipse cx="0" cy="-4" rx="2" ry="4.4" fill="#7ab8ff" stroke="#3f7fc8" stroke-width="0.7"/></g></g>${eyes(2.8, -9)}<path d="M-2.4 -4.6Q0 -2.4 2.4 -4.6" stroke="#2a1a2a" stroke-width="0.7" fill="none" stroke-linecap="round"/><circle cx="-5" cy="-5.6" r="1.2" fill="#ff8fb4" opacity="0.7"/><circle cx="5" cy="-5.6" r="1.2" fill="#ff8fb4" opacity="0.7"/></g></g>`
      // Pinky hops across
      + `<g transform="translate(0 80)"><g>${at('translate', '-24 0;184 0', T)}<ellipse cy="0.6" rx="8" ry="1.5" fill="#000000" opacity="0.15"/><g>${hop}<g>${sq}<path d="M-10 0Q-11 -18 0 -18Q11 -18 10 0Z" fill="#ff9cc8" stroke="#d25a90" stroke-width="0.8"/><path d="M-6 -16Q-8 -22 -4 -21Q-3 -18 -3 -17Z" fill="#ff9cc8" stroke="#d25a90" stroke-width="0.6"/><path d="M6 -16Q8 -22 4 -21Q3 -18 3 -17Z" fill="#ff9cc8" stroke="#d25a90" stroke-width="0.6"/>${eyes(3.4, -10)}<path d="M-3 -5.6Q0 -2 3 -5.6Z" fill="#7a1f3a"/><circle cx="-6.4" cy="-6.6" r="1.4" fill="#ff5f8f" opacity="0.6"/><circle cx="6.4" cy="-6.6" r="1.4" fill="#ff5f8f" opacity="0.6"/></g></g></g></g>`
      + `<g transform="translate(6 11)"><g>${at('scale', '1;1.06;1', 1.6)}<text x="0" y="0" font-size="7" font-family="'Fredoka','Comic Sans MS',sans-serif" font-weight="700" fill="#ffffff" stroke="#d25a90" stroke-width="1.4" paint-order="stroke">SQUISH TOONS</text></g></g>`;
    // CH 2 · Squish Cup football (8 s): orange striker dribbles in, shoots past the blue keeper, GOAL! pop, crowd jumps, score 0-0 -> 1-0
    const SC2 = () => { const KT = ' keyTimes="0;0.45;0.62;0.7;1"';
      return `<rect width="160" height="90" fill="#6fc0ff"/><rect width="160" height="26" fill="#3a3f6a"/>`
        + rep(22, i => { const c = ['#ff9a4a', '#7ab8ff', '#ffd84a', '#ff7aa8', '#9adf7a'][i % 5], x = 4 + i * 7.2; return `<g>${at('translate', '0 0;0 0;0 -3.5;0 0;0 -3.5;0 0', T, 0, ' keyTimes="0;0.62;0.68;0.74;0.8;1"')}<circle cx="${f1(x)}" cy="${18 + (i % 2) * 3}" r="2.6" fill="${c}"/><circle cx="${f1(x - 0.8)}" cy="${17.6 + (i % 2) * 3}" r="0.4" fill="#2a1a2a"/><circle cx="${f1(x + 0.8)}" cy="${17.6 + (i % 2) * 3}" r="0.4" fill="#2a1a2a"/></g>`; }).join('')
        + `<rect y="26" width="160" height="64" fill="#5cbf4a"/>` + rep(6, i => `<rect x="${i * 28}" y="26" width="14" height="64" fill="#52b040"/>`).join('')
        + `<path d="M0 30H160M80 30V90" stroke="#ffffff" stroke-opacity="0.7" stroke-width="0.8"/><ellipse cx="80" cy="60" rx="16" ry="9" fill="none" stroke="#ffffff" stroke-opacity="0.7" stroke-width="0.8"/>`
        + `<g transform="translate(140 40)"><path d="M0 0H14V38" stroke="#ffffff" stroke-width="1.6" fill="none"/><path d="M0 0V38" stroke="#ffffff" stroke-width="1.6"/><rect x="1" y="1" width="12" height="36" fill="url(#q18sl)" opacity="0.5"/></g>`
        + `<g>${at('translate', '0 0;0 0;0 -9;0 -2;0 0', T, 0, KT)}<g transform="translate(138 74)"><path d="M-7 0Q-8 -14 0 -14Q8 -14 7 0Z" fill="#7ab8ff" stroke="#3f7fc8" stroke-width="0.8"/>${eyes(2.6, -8)}<path d="M-2 -3.6Q0 -4.6 2 -3.6" stroke="#2a1a2a" stroke-width="0.6" fill="none"/><path d="M-9 -9L-7 -7M9 -9L7 -7" stroke="#3f7fc8" stroke-width="1.4" stroke-linecap="round"/></g></g>`
        + `<g>${at('translate', '-20 0;72 0;72 0;72 0;-20 0', T, 0, ' keyTimes="0;0.4;0.7;0.95;1"')}<g transform="translate(20 80)"><ellipse cy="0.6" rx="8" ry="1.5" fill="#000000" opacity="0.15"/><g>${at('translate', '0 0;0 -3;0 0', 0.5)}<path d="M-9 0Q-10 -17 0 -17Q10 -17 9 0Z" fill="#ff9a4a" stroke="#d2692a" stroke-width="0.8"/>${eyes(3.2, -10)}<path d="M-2.6 -5Q0 -2.4 2.6 -5Z" fill="#7a1f3a"/><text x="0" y="-1.6" text-anchor="middle" font-size="4" ${FONT} fill="#ffffff">9</text></g></g></g>`
        + `<g><animateMotion dur="${T}s" repeatCount="indefinite" keyPoints="0;0.42;0.62;0.62;1" keyTimes="0;0.4;0.6;0.95;1" calcMode="linear" path="M8 84L92 84Q118 70 146 62L146 62"/>${at('rotate', '0;360', 0.6)}<circle r="2.6" fill="#ffffff" stroke="#2a2a2a" stroke-width="0.4"/><path d="M0 -1.2L1.1 -0.4L0.7 0.9H-0.7L-1.1 -0.4Z" fill="#2a2a2a"/></g>`
        + `<g opacity="0">${an('opacity', '0;0;1;1;0;0', T, 0, ' keyTimes="0;0.6;0.63;0.88;0.92;1"')}<g transform="translate(80 44)"><g>${at('scale', '0.4;1.15;1', 0.5, 0, ' keyTimes="0;0.6;1"')}<text x="0" y="0" text-anchor="middle" font-size="16" font-family="'Fredoka','Comic Sans MS',sans-serif" font-weight="700" fill="#ffd84a" stroke="#d2692a" stroke-width="2" paint-order="stroke">GOAL!</text></g></g></g>`
        + `<g transform="translate(4 4)"><rect width="38" height="8" rx="2" fill="#1d1f2a" opacity="0.9"/><circle cx="5" cy="4" r="2.2" fill="#ff9a4a"/><circle cx="33" cy="4" r="2.2" fill="#7ab8ff"/><text x="19" y="6.2" text-anchor="middle" font-size="5.4" ${FONT} fill="#ffffff">0 - 0${an('opacity', '1;1;0;0', T, 0, ' keyTimes="0;0.62;0.63;1"')}</text><text x="19" y="6.2" text-anchor="middle" font-size="5.4" ${FONT} fill="#ffd84a" opacity="0">1 - 0${an('opacity', '0;0;1;1', T, 0, ' keyTimes="0;0.62;0.63;1"')}</text></g>`; };
    // CH 3 · Space Trip (8 s): stars twinkle, ringed planet turns, a rocket with Mittens in the window loops across, shooting star
    const SC3 = () => '<rect width="160" height="90" fill="#141a3e"/><rect width="160" height="90" fill="#3a2a7a" opacity="0.45"/>'
      + rep(36, i => { const x = (i * 47) % 160, y = (i * 29 + 7) % 90, r = 0.35 + (i % 3) * 0.25; return `<circle cx="${x}" cy="${y}" r="${f1(r)}" fill="#ffffff">${an('opacity', '0.3;1;0.3', 1.6 + (i % 5) * 0.4, -i * 0.3)}</circle>`; }).join('')
      + `<g transform="translate(118 62)"><circle r="17" fill="#ff9cc8"/><path d="M-17 0A17 17 0 0 0 17 0" fill="#e86fa8" opacity="0.6"/><g>${at('translate', '-6 0;6 0;-6 0', 8)}<ellipse cx="-4" cy="-6" rx="4" ry="2.2" fill="#ffd0e6" opacity="0.7"/><ellipse cx="5" cy="5" rx="3" ry="1.6" fill="#c9508a" opacity="0.6"/></g><ellipse rx="27" ry="6" fill="none" stroke="#ffd84a" stroke-width="2.2" transform="rotate(-14)"/><path d="M-17 -2A17 17 0 0 1 17 -2" fill="#ff9cc8" transform="rotate(-14)"/></g>`
      + `<g transform="translate(24 20)"><circle r="7" fill="#d9dde2"/><circle cx="-2" cy="-1.6" r="1.6" fill="#b9bec6"/><circle cx="2.4" cy="2" r="1.1" fill="#b9bec6"/></g>`
      + `<path d="M0 0L-14 -4" stroke="#ffffff" stroke-width="0.8" stroke-linecap="round" opacity="0">${an('opacity', '0;0;1;0;0', T, 0, ' keyTimes="0;0.3;0.34;0.42;1"')}<animateMotion dur="${T}s" repeatCount="indefinite" path="M150 6L90 26"/></path>`
      + `<g><animateMotion dur="${T}s" repeatCount="indefinite" rotate="auto" path="M-20 60C30 20 70 80 110 40S170 10 190 30"/><g transform="rotate(90)"><path d="M-4 6L-8 12H-2Z M4 6L8 12H2Z" fill="#ff5a5a"/><path d="M0 -12Q6 -6 5 8H-5Q-6 -6 0 -12Z" fill="#f4f6fa" stroke="#9aa0a6" stroke-width="0.6"/><circle cy="-2" r="3" fill="#7ab8ff" stroke="#3f7fc8" stroke-width="0.6"/><circle cy="-2" r="2" fill="#ffb26a"/><path d="M-1.4 -3.6L-1 -2.6M1.4 -3.6L1 -2.6" stroke="#2a1a2a" stroke-width="0.4"/><path d="M-3 8Q0 ${f1(16)} 3 8" fill="#ffd84a">${an('d', 'M-3 8Q0 16 3 8;M-3 8Q0 13 3 8;M-3 8Q0 16 3 8', 0.25)}</path></g></g>`
      + `<g transform="translate(6 11)"><g>${at('scale', '1;1.06;1', 1.6)}<text x="0" y="0" font-size="7" font-family="'Fredoka','Comic Sans MS',sans-serif" font-weight="700" fill="#ffffff" stroke="#6a4ad8" stroke-width="1.4" paint-order="stroke">SPACE TRIP</text></g></g>`;
    const CHN = ['', 'SQUISH TOONS', 'SQUISH CUP', 'SPACE TRIP'], n = ch === 2 || ch === 3 ? ch : 1;
    let s = `<defs><clipPath id="${cid}"><rect width="${f1(W)}" height="${f1(Hh)}" rx="${R || 0}"/></clipPath></defs><g clip-path="url(#${cid})"><g transform="scale(${n4(sx)} ${n4(sy)})">`
      + (n === 2 ? SC2() : n === 3 ? SC3() : SC1())
      + `<g opacity="0">${'<animate attributeName="opacity" values="1;1;0" keyTimes="0;0.8;1" dur="2.6s" fill="freeze"/>'}<rect x="122" y="4" width="34" height="9" rx="1.6" fill="#000000" opacity="0.45"/><text x="139" y="10.6" text-anchor="middle" font-size="5.6" ${FONT} fill="#7dff9e">CH ${n}</text></g>`;
    if (look === 'crt') s += `<rect width="160" height="90" fill="#7dffb0" opacity="0.1"/><rect width="160" height="90" fill="url(#q18sl)"/><rect y="-20" width="160" height="12" fill="#ffffff" opacity="0.1">${an('y', '-20;100', 3.6)}</rect><rect width="160" height="90" fill="#ffffff" opacity="0">${an('opacity', '0;0;0.2;0;0', 5.3, 0, ' keyTimes="0;0.6;0.62;0.65;1"')}</rect>`;
    if (look === 'vint') s += `<rect width="160" height="90" fill="#ffae5a" opacity="0.16"/><rect width="160" height="90" fill="url(#q18sl)" opacity="0.5"/>`;
    if (look === 'holo') s += `<rect width="160" height="90" fill="#3fe6ff" opacity="0.2"/><rect width="160" height="90" fill="url(#q18sl)" opacity="0.6"/><rect y="-10" width="160" height="5" fill="#bffaff" opacity="0.35">${an('y', '-10;95', 2.6)}</rect>`;
    s += `</g>` + (look === 'crt' || look === 'vint' ? `<rect width="${f1(W)}" height="${f1(Hh)}" fill="url(#q18vg)"/>` : '') + `<rect width="${f1(W)}" height="${f1(Hh)}" fill="url(#q18rf)"/></g>`;
    return look === 'holo' ? `<g opacity="0.88">${s}</g>` : s; };
  // no speakers: the TV only shows static snow (3 random-dot tiles flicker) with a NO SOUND hint
  const noise = (C, W, Hh, R, look) => { const cid = C.u('nz');
    return `<defs><clipPath id="${cid}"><rect width="${f1(W)}" height="${f1(Hh)}" rx="${R || 0}"/></clipPath></defs><g clip-path="url(#${cid})"><rect width="${f1(W)}" height="${f1(Hh)}" fill="#8a8f96"/>`
      + rep(3, i => `<rect width="${f1(W)}" height="${f1(Hh)}" fill="url(#q18n${i})" opacity="${i ? 0 : 1}"><animate attributeName="opacity" values="${['1;0;0', '0;1;0', '0;0;1'][i]}" dur="0.18s" calcMode="discrete" repeatCount="indefinite"/></rect>`).join('')
      + `<rect y="-10" width="${f1(W)}" height="${f1(Hh * 0.18)}" fill="#ffffff" opacity="0.18">${an('y', `${f1(-Hh * 0.2)};${f1(Hh)}`, 1.4)}</rect><rect width="${f1(W)}" height="${f1(Hh)}" fill="url(#q18sl)" opacity="0.5"/>`
      + `<g transform="translate(${f1(W / 2)} ${f1(Hh / 2)}) scale(${n4(Math.min(W / 160, Hh / 90))})"><rect x="-38" y="-9" width="76" height="18" rx="3" fill="#000000" opacity="0.55"/><text x="0" y="-1" text-anchor="middle" font-size="7" ${FONT} fill="#ffffff">NO SOUND</text><text x="0" y="6" text-anchor="middle" font-size="4.4" ${FONT} fill="#ffd84a">add speakers to watch</text></g>`
      + (look === 'crt' || look === 'vint' ? `<rect width="${f1(W)}" height="${f1(Hh)}" fill="url(#q18vg)"/>` : '') + '</g>'; };
  // TV state from S.st: '' off, 'play' CH1, 'play|ch2' / 'play|ch3', 'noise' (no speakers in the room)
  const tvState = S => { const st = S.st || ''; if (/noise/.test(st)) return { on: 1, ch: 0, nz: 1 }; if (!isPlay(S)) return { on: 0, ch: 0 }; const m = /ch(\d)/.exec(st); return { on: 1, ch: m ? +m[1] : 1 }; };
  const tvPic = (C, W, Hh, look, R, T, off) => T.nz ? noise(C, W, Hh, R, look) : T.ch ? toon(C, W, Hh, look, R, T.ch) : off;
  const glass = (W, Hh, R, fill) => `<rect width="${f1(W)}" height="${f1(Hh)}" rx="${R || 0}" fill="${fill || 'url(#q18gl)'}"/><path d="M${f1(W * 0.56)} 0H${f1(W * 0.74)}L${f1(W * 0.46)} ${f1(Hh)}H${f1(W * 0.28)}Z" fill="#ffffff" opacity="0.06"/><rect x="0.3" y="0.3" width="${f1(W - 0.6)}" height="${f1(Hh - 0.6)}" rx="${R || 0}" fill="none" stroke="#ffffff" stroke-opacity="0.1" stroke-width="0.5"/>`;
  const scr = (x, y, z, w, h) => slab(x, y, z, w, h, 0.2, '#000000', { scr: 1, r: 0.3, emit: 1, noOut: 1, op: 0 });
  const knob = (x, y, r, on) => `<circle cx="${x}" cy="${y}" r="${f1(r)}" fill="#2a2622"/><circle cx="${x}" cy="${y}" r="${f1(r * 0.78)}" fill="#c9c2b0"/>${rep(8, i => `<path d="M${f1(x + Math.cos(i * 0.785) * r * 0.78)} ${f1(y + Math.sin(i * 0.785) * r * 0.78)}L${f1(x + Math.cos(i * 0.785) * r * 0.55)} ${f1(y + Math.sin(i * 0.785) * r * 0.55)}" stroke="#7a7262" stroke-width="0.3"/>`).join('')}<path d="M${x} ${y}L${f1(x + r * 0.4)} ${f1(y - r * 0.6)}" stroke="#3a342a" stroke-width="${f1(r * 0.2)}" stroke-linecap="round"/><circle cx="${f1(x - r * 0.3)}" cy="${f1(y - r * 0.35)}" r="${f1(r * 0.2)}" fill="#ffffff" opacity="0.5"/>`;
  const led = (x, y, on, c) => `<circle cx="${x}" cy="${y}" r="0.6" fill="${on ? (c || '#5dff7a') : '#ff5a4a'}"/><circle cx="${x}" cy="${y}" r="1.5" fill="${on ? (c || '#5dff7a') : '#ff5a4a'}" opacity="0.25"/>`;

  // ======================= LIV-011 RABBIT-EAR PORTABLE TV ON A STOOL =======================
  N.rabbit18 = S => { const T = tvState(S), on = T.on, mu = T.ch > 0, TB = '#a9d3c2', TW = 44, TH = 32, TD = 30, SY = 34, ST = 3.2;
    const D = { w: 46, d: 40, act: 'watch', use: { x: 0, z: 100 }, build: () => [scr(-5, SY + 5, TD / 2 + 0.3, 30, 22)] };
    const face = `<rect x="1.4" y="1.4" width="${TW - 2.8}" height="${TH - 2.8}" rx="3" fill="${shade(TB, 0.92)}"/>`
      + `<rect x="2.2" y="2.4" width="32" height="24" rx="5" fill="#2a2e2a"/><g transform="translate(3.2 3.4)">${tvPic({ u: s => 'q18' + s + (++UID) }, 30, 22, 'crt', 4, T, glass(30, 22, 4, 'url(#q18crt)'))}</g>`
      + `<rect x="36" y="2.4" width="6.2" height="24" rx="1.2" fill="${shade(TB, 0.8)}"/>` + knob(39.1, 7.2, 2.5) + knob(39.1, 14.2, 2) + rep(5, i => `<rect x="36.9" y="${f1(18.6 + i * 1.5)}" width="4.4" height="0.7" rx="0.35" fill="#3d4a44"/>`).join('')
      + led(39.1, 28.4, on) + `<text x="18.2" y="30" text-anchor="middle" ${FONT} font-size="2.1" letter-spacing="0.6" fill="#4a6a5c">SQUISH·TV</text>`
      + `<g transform="rotate(-38 3 3)"><rect x="-4" y="1.6" width="13" height="3.4" fill="#b9bcc1" opacity="0.92"/><path d="M-4 2.2H9M-4 3.2H9M-4 4.2H9" stroke="#8e9298" stroke-width="0.15"/></g>`;
    const top = `<path d="M3 4H${TW - 3}M3 ${TD - 4}H${TW - 3}" stroke="#000000" stroke-opacity="0.1" stroke-width="0.5"/>` + rep(6, i => `<rect x="${f1(20 + i * 2.6)}" y="${TD - 9}" width="1.2" height="6" rx="0.6" fill="#000000" fill-opacity="0.22"/>`).join('');
    const side = rep(5, i => `<rect x="${f1(6 + i * 3.6)}" y="20" width="1.4" height="8" rx="0.7" fill="#000000" fill-opacity="0.22"/>`).join('');
    D.fx = ctx => { const C = cam(ctx), L = []; let s = shadow(C, 0, 0, 22, 18, 0.8);
      rep(3, i => { const t = PI / 2 + i * 2 * PI / 3 + PI, bx = Math.cos(t) * 17, bz = Math.sin(t) * 17, tx = Math.cos(t) * 11, tz = Math.sin(t) * 11;
        L.push({ q: [bx, 10, bz], s: cyl3(C, [bx, 0, bz], [tx, SY - ST, tz], 1.6, '#b8834d', { r2: 2 }) + cyl3(C, [bx, -0.1, bz], [bx * 1.02, 1.2, bz * 1.02], 1.9, '#3a3d44') }); });
      rep(3, i => { const t0 = PI / 2 + i * 2 * PI / 3 + PI, t1 = t0 + 2 * PI / 3, r = 14.6, y = 13; L.push({ q: [(Math.cos(t0) + Math.cos(t1)) * r / 2, y, (Math.sin(t0) + Math.sin(t1)) * r / 2], s: cyl3(C, [Math.cos(t0) * r, y, Math.sin(t0) * r], [Math.cos(t1) * r, y, Math.sin(t1) * r], 0.9, '#a8743f') }); });
      s += zsort(C, L);
      s += cyl3(C, [0, SY - ST, 0], [0, SY, 0], 17, '#c99257', { r2: 17 }) + `<g transform="${FR(C, [0, SY + 0.03, 0], [1, 0, 0], [0, 0, 1])}"><circle r="15.5" fill="none" stroke="#a8743f" stroke-width="0.4"/><circle r="10" fill="none" stroke="#a8743f" stroke-width="0.3" stroke-opacity="0.6"/><path d="M-12 -3Q-2 -6 12 -2" stroke="#e8b47a" stroke-width="0.4" fill="none"/></g>`;
      // rabbit ears: base dome + 2 telescopic rods (one with a tinfoil ball), they sway a little
      const ab = [5, SY + TH, -3], tip1 = [-14, SY + TH + 34, -9], tip2 = [24, SY + TH + 30, -6];
      const ears = sph(C, ab, 4, '#33363d') + cyl3(C, ab, tip1, 0.5, '#d9dde2') + cyl3(C, [(ab[0] + tip1[0]) * 0.5, (ab[1] + tip1[1]) * 0.5, -6], tip1, 0.35, '#eef0f2') + sph(C, tip1, 1, '#c9ced3')
        + cyl3(C, ab, [16, SY + TH + 18, -4], 0.5, '#d9dde2') + cyl3(C, [16, SY + TH + 18, -4], tip2, 0.4, '#eef0f2') + sph(C, tip2, 2.8, '#dfe3e8', {}) + `<g transform="translate(${P2(C.p(tip2[0], tip2[1], tip2[2]))})"><path d="M${f1(-1.6 * C.k)} ${f1(-0.6 * C.k)}l${f1(1.2 * C.k)} ${f1(0.8 * C.k)} ${f1(1.4 * C.k)} ${f1(-1 * C.k)}" stroke="#9aa0a6" stroke-width="${f1(0.3 * C.k)}" fill="none"/></g>`;
      const ap = C.p(ab[0], ab[1], ab[2]);
      const tv = box3(C, { c: [0, SY, 0], w: TW, h: TH, d: TD, r: 4, col: TB, dec: { f: face, t: top, r: side, l: side } });
      s += tv + `<g>${at('rotate', `-1.6 ${P2(ap)};1.8 ${P2(ap)};-1.6 ${P2(ap)}`, 4.2, 0, SPL(2))}${ears}</g>`;
      s += curve(C, [[16, SY + 6, -TD / 2], [24, SY - 10, -20], [20, 4, -24], [30, 0.3, -18]], '#2a2a2e', 1.2);
      if (mu) s += rep(3, i => note(C, 24 + i * 3, SY + TH + 4, 8, i, '#3a7a5c')).join('');
      ext(C, [[tip1[0] - 4, tip1[1] + 4, tip1[2]], [tip2[0] + 4, tip2[1] + 4, tip2[2]]]);
      return { defs: DEF18, front: s, bb: C.bb(4) }; };
    return D; };
  let UID = 0;

  // ======================= LIV-031 WALL-MOUNTED SMART FRAME ART TV =======================
  const artPic = (W, Hh, id) => `<defs><clipPath id="${id}"><rect width="${f1(W)}" height="${f1(Hh)}"/></clipPath></defs><g clip-path="url(#${id})"><g transform="scale(${n4(W / 160)} ${n4(Hh / 90)})">`
    + `<rect width="160" height="90" fill="#f6ead3"/><circle cx="104" cy="36" r="17" fill="#f08a6a"/><circle cx="104" cy="36" r="24" fill="#f08a6a" opacity="0.18"/>`
    + `<path d="M0 60Q34 38 72 54T160 48V90H0Z" fill="#8fb39a"/><path d="M0 70Q48 54 96 66T160 62V90H0Z" fill="#3f7f78"/><path d="M0 80Q60 70 120 78T160 76V90H0Z" fill="#e3b24f"/>`
    + `<path d="M30 26l3 2 3 -2M44 20l2.4 1.6 2.4 -1.6M52 30l2 1.4 2 -1.4" stroke="#5a4a3a" stroke-width="0.9" fill="none" stroke-linecap="round"/>`
    + rep(16, i => `<path d="M${(i * 37) % 160} ${(i * 23) % 90}l2 1" stroke="#8a7050" stroke-opacity="0.18" stroke-width="0.4"/>`).join('')
    + `</g><rect x="-60" width="34" height="${f1(Hh)}" fill="url(#p15shn)" opacity="0.28" transform="skewX(-16)">${an('x', `-60;${f1(W + 80)}`, 11)}</rect></g>`;
  N.frame18 = S => { const T = tvState(S), on = T.on, SW = 120, SH = 67.5, MT = 3.4, FB = 5.6, FW = SW + 2 * (MT + FB), FH = SH + 2 * (MT + FB), ZF = 3.6, OAK = '#d2a66c';
    const D = { w: FW + 6, d: 8, mount: 'wall', elev: 40, act: 'watch', use: { x: 0, z: 150 }, build: () => [scr(0, FB + MT, ZF + 0.3, SW, SH)] };
    D.fx = ctx => { const C = cam(ctx), sid = C.u('ar'); let s = '';
      s += WD(C, -FW / 2 + 1.6, FH - 3, 0.1, `<rect width="${f1(FW + 4)}" height="${f1(FH + 5)}" rx="2" fill="#000000" opacity="0.1"/><rect x="1.6" y="1.6" width="${f1(FW)}" height="${f1(FH + 1.6)}" rx="1.4" fill="#000000" opacity="0.14"/>`, FW, FH);
      const pic = tvPic({ u: q => sid + q + (++UID) }, SW, SH, 'clean', 0, T, artPic(SW, SH, sid));
      const f = `<rect width="${f1(FW)}" height="${f1(FH)}" fill="${OAK}"/>` + rep(7, i => `<path d="M0 ${f1(1 + i * 0.7)}H${f1(FW)}" stroke="#b5864e" stroke-opacity="0.35" stroke-width="0.25"/>`).join('')
        + `<path d="M0 0H${f1(FW)}V${f1(FH)}H0Z M${FB} ${FB}V${f1(FH - FB)}H${f1(FW - FB)}V${FB}Z" fill="#000000" fill-opacity="0" stroke="#8a5e2e" stroke-opacity="0.5" stroke-width="0.4"/>`
        + `<path d="M${FB} ${FB}L${f1(FB - 1.2)} ${f1(FB - 1.2)}M${f1(FW - FB)} ${FB}L${f1(FW - FB + 1.2)} ${f1(FB - 1.2)}M${FB} ${f1(FH - FB)}L${f1(FB - 1.2)} ${f1(FH - FB + 1.2)}M${f1(FW - FB)} ${f1(FH - FB)}L${f1(FW - FB + 1.2)} ${f1(FH - FB + 1.2)}" stroke="#8a5e2e" stroke-opacity="0.45" stroke-width="0.3"/>`
        + `<rect x="${FB}" y="${FB}" width="${f1(FW - 2 * FB)}" height="${f1(FH - 2 * FB)}" fill="#fbf7ee"/><rect x="${FB}" y="${FB}" width="${f1(FW - 2 * FB)}" height="1.2" fill="#000000" opacity="0.08"/><rect x="${FB}" y="${FB}" width="1" height="${f1(FH - 2 * FB)}" fill="#000000" opacity="0.06"/>`
        + `<g transform="translate(${f1(FB + MT)} ${f1(FB + MT)})">${pic}<rect width="${SW}" height="${f1(SH)}" fill="none" stroke="#000000" stroke-opacity="0.18" stroke-width="0.4"/></g>`
        + `<path d="M${f1(FW - 2)} 1H1V${f1(FH - 2)}" stroke="#ffffff" stroke-opacity="0.35" stroke-width="0.5" fill="none"/>`;
      s += box3(C, { c: [0, 0, ZF / 2], w: FW, h: FH, d: ZF, r: 0.6, col: OAK, dec: { f, t: rep(5, i => `<path d="M0 ${f1(0.5 + i * 0.6)}H${f1(FW)}" stroke="#b5864e" stroke-opacity="0.4" stroke-width="0.2"/>`).join('') } });
      const lp = C.p(0, -1.6, ZF); s += `<circle cx="${f1(lp[0])}" cy="${f1(lp[1])}" r="${f1(0.6 * C.k)}" fill="${on ? '#9dffb8' : '#fff4d6'}">${an('opacity', on ? '1;1' : '0.35;0.9;0.35', 3.2)}</circle>`;
      return { defs: DEF18, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= LIV-051 RETRO WALNUT TV CONSOLE & TURNTABLE (tube amp) =======================
  N.console18 = S => { const T = tvState(S), on = T.ch > 0, nz = !!T.nz, WAL = '#8b5a34', CW = 152, CH = 30, CD = 34, LG = 12, TY = LG + CH, CRM = '#efe3c4', TW = 64, TH = 44, TD = 26, PY = TY + 2.6;
    const D = { w: CW + 4, d: CD + 6, act: 'watch', use: { x: 0, z: 110 }, topH: TY, build: () => [scr(-6, PY + 4.4, TD / 2 + 0.3, 46, 32)] };
    const grill = (x0, w) => `<rect x="${x0}" y="3" width="${w}" height="${CH - 6}" rx="1.6" fill="url(#q18cl)"/><rect x="${x0}" y="3" width="${w}" height="${CH - 6}" rx="1.6" fill="none" stroke="#5a3a1c" stroke-width="0.6"/>` + rep(5, i => `<path d="M${f1(x0 + 2)} ${f1(6 + i * 4.4)}H${f1(x0 + w - 2)}" stroke="#7a3d12" stroke-opacity="0.35" stroke-width="0.5"/>`).join('');
    const front = grill(4, 42) + grill(CW - 46, 42)
      + `<rect x="50" y="3" width="25" height="${CH - 6}" rx="1" fill="${shade(WAL, 1.08)}" stroke="#5a3a1c" stroke-width="0.4"/><rect x="77" y="3" width="25" height="${CH - 6}" rx="1" fill="${shade(WAL, 1.08)}" stroke="#5a3a1c" stroke-width="0.4"/>`
      + rep(9, i => `<path d="M${f1(52 + i * 2.6)} 4.5V${CH - 4.5}M${f1(79 + i * 2.6)} 4.5V${CH - 4.5}" stroke="#5a3a1c" stroke-opacity="0.35" stroke-width="0.4"/>`).join('')
      + `<circle cx="73" cy="15" r="1.5" fill="#d9b25a" stroke="#8a6420" stroke-width="0.4"/><circle cx="79" cy="15" r="1.5" fill="#d9b25a" stroke="#8a6420" stroke-width="0.4"/>`
      + `<path d="M2 ${CH - 1.4}H${CW - 2}" stroke="#d9b25a" stroke-width="0.7"/>`;
    const topD = rep(6, i => `<path d="M2 ${f1(3 + i * 5.4)}Q${CW / 2} ${f1(1 + i * 5.4 + (i % 2) * 2)} ${CW - 2} ${f1(3 + i * 5.4)}" stroke="#5a3a1c" stroke-opacity="0.25" stroke-width="0.35" fill="none"/>`).join('');
    const tvF = `<rect x="2.4" y="2.4" width="${TW - 4.8}" height="${TH - 4.8}" rx="6" fill="${shade(CRM, 0.94)}"/><rect x="3.4" y="3.4" width="48" height="34" rx="7" fill="#3a3226"/>`
      + `<g transform="translate(4.4 4.4)">${tvPic({ u: q => 'cv' + q + (++UID) }, 46, 32, 'vint', 6, T, glass(46, 32, 6, 'url(#q18crt)'))}</g>`
      + `<rect x="53.4" y="3.4" width="8" height="34" rx="2" fill="${WAL}"/>` + knob(57.4, 9, 2.6) + knob(57.4, 17, 2.1) + rep(6, i => `<rect x="54.8" y="${f1(22.4 + i * 1.9)}" width="5.2" height="0.9" rx="0.45" fill="#3a2614"/>`).join('')
      + `<text x="27.4" y="41.2" text-anchor="middle" font-size="2.3" font-family="'Fredoka','Comic Sans MS',sans-serif" font-weight="700" letter-spacing="0.5" fill="#8b5a34">Squish-o-Vision</text>` + led(50.6, 40.4, on, '#ffb347');
    const tvS = `<rect width="${TD}" height="${TH}" fill="${WAL}"/>` + rep(5, i => `<path d="M0 ${f1(4 + i * 8)}Q${TD / 2} ${f1(2 + i * 8)} ${TD} ${f1(5 + i * 8)}" stroke="#5a3a1c" stroke-opacity="0.35" stroke-width="0.35" fill="none"/>`).join('');
    D.fx = ctx => { const C = cam(ctx), L = []; let s = shadow(C, 0, 0, CW / 2 + 4, CD / 2 + 4, 0.75);
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => { const x = sx * (CW / 2 - 8), z = sz * (CD / 2 - 5); L.push({ q: [x, 4, z], s: cyl3(C, [x + sx * 3, 0, z + sz * 2], [x, LG, z], 1.1, WAL, { r2: 2.2 }) + cyl3(C, [x + sx * 3, 0, z + sz * 2], [x + sx * 2.8, 1.8, z + sz * 1.9], 1.25, '#d9b25a', { mat: 'gloss' }) }); });
      s += zsort(C, L);
      s += box3(C, { c: [0, LG, 0], w: CW, h: CH, d: CD, r: 2, col: WAL, dec: { f: front, t: topD } });
      // turntable (left): plinth, silver platter, vinyl spinning when on, tonearm
      const tx = -50, tz = 1, ty = TY + 4;
      s += box3(C, { c: [tx, TY, tz], w: 40, h: 4, d: 30, r: 1.4, col: '#c79a64', dec: { f: `<circle cx="34" cy="2" r="0.8" fill="${on ? '#ff5a4a' : '#5a3a1c'}"/><text x="6" y="2.8" ${FONT} font-size="1.6" fill="#5a3a1c">33 · 45</text>` } });
      s += cyl3(C, [tx - 4, ty, tz], [tx - 4, ty + 1.3, tz], 13, '#c9ced6', { mat: 'gloss' });
      const rec = `<circle r="12" fill="#17161a"/>` + rep(6, i => `<circle r="${f1(5.6 + i * 1.05)}" fill="none" stroke="#2c2b31" stroke-width="0.35"/>`).join('') + `<path d="M-9 -6A11 11 0 0 1 -2 -11" stroke="#ffffff" stroke-opacity="0.22" stroke-width="0.7" fill="none"/>`
        + `<circle r="4.2" fill="#e8504a"/><path d="M-2.6 -0.6H2.6" stroke="#ffffff" stroke-width="0.6"/><circle r="0.6" fill="#d9dde2"/>`;
      s += `<g transform="${FR(C, [tx - 4, ty + 1.35, tz], [1, 0, 0], [0, 0, 1])}"><g>${on ? at('rotate', '0;360', 1.8) : ''}${rec}</g></g>`;
      const pv = [tx + 14, ty + 1.5, tz - 10], hd = on ? [tx - 1, ty + 2.4, tz + 2] : [tx + 15, ty + 2, tz + 8];
      s += cyl3(C, [pv[0], ty, pv[2]], pv, 1.6, '#9aa0a6') + cyl3(C, pv, hd, 0.4, '#e4e7ea') + box3(C, { c: [hd[0], hd[1] - 1, hd[2]], w: 2.2, h: 1.2, d: 3, r: 0.3, col: '#3a3d44' });
      // tube amp (right): VU meters + glowing tubes
      const ax = 52, az = -1;
      const vu = (x, ph) => `<rect x="${x}" y="1.6" width="9" height="5" rx="0.6" fill="#f4e6c0" stroke="#5a4a2a" stroke-width="0.3"/><path d="M${x + 1.2} 5.6A3.6 3.6 0 0 1 ${x + 7.8} 5.6" stroke="#c0392b" stroke-width="0.25" fill="none"/><g transform="translate(${x + 4.5} 6.2)"><path d="M0 0L0 -3.8" stroke="#2a2a2a" stroke-width="0.35">${on ? at('rotate', '-40;30;-10;40;-30;-40', 1.3, ph, '') : '<animateTransform attributeName="transform" type="rotate" values="-42;-42" dur="1s"/>'}</path></g>`;
      s += box3(C, { c: [ax, TY, az], w: 34, h: 9, d: 22, r: 1.2, col: '#2f2a26', dec: { f: vu(3, 0) + vu(13, -0.4) + knob(27.5, 4.5, 2.2) + `<path d="M2 8.2H32" stroke="#d9b25a" stroke-width="0.4"/>` } });
      rep(3, i => { const x = ax - 9 + i * 9, z = az - 4, y0 = TY + 9; const gp = C.p(x, y0 + 4.4, z);
        s += cyl3(C, [x, y0, z], [x, y0 + 1.6, z], 2.4, '#1d1e22') + `<circle cx="${f1(gp[0])}" cy="${f1(gp[1])}" r="${f1(3.4 * C.k)}" fill="url(#q18glw)" opacity="${on ? 0.9 : 0.35}">${on ? an('opacity', '0.7;1;0.8;0.95;0.7', 1.1 + i * 0.2) : ''}</circle>`
          + cyl3(C, [x, y0 + 1.6, z], [x, y0 + 8.4, z], 2, '#fff1d6', { op: 0.55 }) + sph(C, [x, y0 + 8.4, z], 2, '#fff1d6', {}).replace('<circle', '<circle opacity="0.55"'); });
      // the TV on its brass swivel
      s += cyl3(C, [0, TY, -1], [0, PY, -1], 7, '#d9b25a', { mat: 'gloss' });
      s += box3(C, { c: [0, PY, -1], w: TW, h: TH, d: TD, r: 7, col: CRM, dec: { f: tvF, r: tvS, l: tvS, t: `<path d="M8 6H${TW - 8}" stroke="#000000" stroke-opacity="0.08" stroke-width="0.6"/>` } });
      const a0 = [6, PY + TH, -4]; s += sph(C, a0, 2.4, '#d9b25a') + cyl3(C, a0, [-10, PY + TH + 18, -8], 0.4, '#e4e7ea') + cyl3(C, a0, [20, PY + TH + 16, -8], 0.4, '#e4e7ea') + sph(C, [-10, PY + TH + 18, -8], 0.9, '#d9b25a') + sph(C, [20, PY + TH + 16, -8], 0.9, '#d9b25a');
      if (on) s += rep(3, i => note(C, -60 + i * 7, TY + 18, 6, i, '#8b4a1a')).join('');
      return { defs: DEF18, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= LIV-071 CONCEALED POP-UP ROLLABLE OLED CREDENZA (big screen) =======================
  N.oled18 = S => { const T = tvState(S), on = T.on, CW = 216, CH = 30, CD = 38, PH = 4, TY = PH + CH, SW = 200, SH = 112.5, BZ = 1.3, PW = SW + 2 * BZ, PB = TY - 1.2, SZ = -10, WAL = '#3e2b22', GOLD = '#d4af5a';
    const D = { w: CW + 4, d: CD + 6, act: 'watch', use: { x: 0, z: 150 }, build: () => [scr(0, PB + BZ, SZ + 1, SW, SH)] };
    const flutes = (x0, w) => `<rect x="${x0}" y="2" width="${w}" height="${CH - 5}" fill="url(#q18fl)"/><rect x="${x0}" y="2" width="${w}" height="${CH - 5}" fill="none" stroke="#000000" stroke-opacity="0.35" stroke-width="0.4"/>`;
    const pw = (CW - 10) / 4, front = rep(4, i => flutes(2 + i * (pw + 2), pw)).join('') + rep(3, i => `<rect x="${f1(1 + (i + 1) * (pw + 2) - 0.4)}" y="1" width="1.2" height="${CH - 2.6}" fill="${GOLD}"/>`).join('')
      + [1, 2].map(i => `<rect x="${f1(i * (pw + 2) - 1.6)}" y="10" width="0.9" height="8" rx="0.45" fill="${GOLD}"/><rect x="${f1(i * (pw + 2) + 2.5)}" y="10" width="0.9" height="8" rx="0.45" fill="${GOLD}"/>`).join('')
      + `<path d="M0 0.6H${CW}" stroke="${GOLD}" stroke-width="0.8"/>` + `<circle cx="${CW / 2}" cy="${CH - 1.6}" r="0.55" fill="${on ? '#9dffb8' : '#ffffff'}">${on ? '' : an('opacity', '0.25;0.9;0.25', 3.4)}</circle>`;
    const topD = `<rect x="${f1((CW - PW) / 2 - 1.6)}" y="${f1(CD / 2 + SZ - 2.2)}" width="${f1(PW + 3.2)}" height="4.4" rx="1.4" fill="#0d0b0a"/><path d="M${f1((CW - PW) / 2 - 1.6)} ${f1(CD / 2 + SZ + 2.2)}H${f1((CW + PW) / 2 + 1.6)}" stroke="${GOLD}" stroke-width="0.5"/>` + rep(6, i => `<path d="M2 ${f1(4 + i * 5.6)}Q${CW / 2} ${f1(2 + i * 5.6)} ${CW - 2} ${f1(4 + i * 5.6)}" stroke="#000000" stroke-opacity="0.2" stroke-width="0.35" fill="none"/>`).join('');
    D.fx = ctx => { const C = cam(ctx), k = C.k; let s = shadow(C, 0, 0, CW / 2 + 6, CD / 2 + 6, 0.8);
      // back glow on the wall behind when on
      if (on) s += `<g opacity="0.55">${an('opacity', '0.4;0.65;0.4', 4)}${WD(C, -PW / 2 - 24, PB + SH + 30, SZ - 6, `<rect width="${f1(PW + 48)}" height="${f1(SH + 40)}" rx="30" fill="url(#q18cy)"/>`)}</g>`;
      const panel = `<rect width="${f1(PW)}" height="${f1(SH + 2 * BZ)}" rx="0.8" fill="#08080b"/><g transform="translate(${BZ} ${BZ})">${T.on ? tvPic({ u: q => 'ol' + q + (++UID) }, SW, SH, 'clean', 0.4, T, '') : glass(SW, SH, 0.4)}</g>`
        + (on ? '' : `<rect x="-60" y="${BZ}" width="40" height="${f1(SH)}" fill="url(#p15shn)" opacity="0.12" transform="skewX(-14)">${an('x', `-60;${f1(PW + 80)}`, 10)}</rect>`)
        + `<rect x="0.25" y="0.25" width="${f1(PW - 0.5)}" height="${f1(SH + 2 * BZ - 0.5)}" rx="0.8" fill="none" stroke="${GOLD}" stroke-width="0.5" stroke-opacity="0.85"/>`;
      const scrS = box3(C, { c: [0, PB, SZ], w: PW, h: SH + 2 * BZ, d: 1.6, r: 0.3, col: '#141418', dec: { f: panel, t: `<path d="M0 0.5H${f1(PW)}" stroke="${GOLD}" stroke-width="0.6"/>` } });
      // the screen rolls up only when the TV is switched on (CH 1 / static); flipping to CH 2 / 3 keeps it up (no re-rise)
      if (on && (T.ch === 1 || T.nz)) { const a = C.p(-CW / 2 - 4, TY, SZ), b = C.p(CW / 2 + 4, TY, SZ), cid = C.u('rc'), up = 400;
        s += `<defs><clipPath id="${cid}"><path d="M${P2(a)}L${P2(b)}L${f1(b[0])} ${f1(b[1] - up)}L${f1(a[0])} ${f1(a[1] - up)}Z"/></clipPath></defs><g clip-path="url(#${cid})"><g>${ONCE(`0 ${f1((SH + 4) * k)};0 0`, 2.2)}${scrS}</g></g>`; }
      else s += scrS;
      s += box3(C, { c: [0, 0, 0], w: CW - 8, h: PH, d: CD - 6, r: 1, col: GOLD, dec: {} });
      s += box3(C, { c: [0, PH, 0], w: CW, h: CH, d: CD, r: 2, col: WAL, dec: { f: front, t: topD } });
      return { defs: DEF18, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= LIV-091 FLOATING HOLO-SCREEN STAGE & ACOUSTIC SCULPTURE =======================
  const mascot = (W, Hh, id) => { const cx = W / 2, by = Hh * 0.86, sc = Hh / 70;
    return `<defs><clipPath id="${id}"><rect width="${f1(W)}" height="${f1(Hh)}"/></clipPath></defs><g clip-path="url(#${id})"><rect width="${f1(W)}" height="${f1(Hh)}" fill="#0a2a3a" opacity="0.35"/>`
      + rep(9, i => `<path d="M0 ${f1(Hh * (i + 1) / 10)}H${f1(W)}" stroke="#8ff6ff" stroke-opacity="0.12" stroke-width="0.4"/>`).join('')
      + `<g transform="translate(${f1(cx)} ${f1(by)}) scale(${n4(sc)})"><ellipse rx="22" ry="4" fill="none" stroke="#8ff6ff" stroke-width="0.8" opacity="0.7">${an('rx', '18;24;18', 2)}</ellipse>`
      + `<g>${at('translate', '0 0;0 -6;0 0', 1.2, 0, SPL(2))}<g>${at('rotate', '-8;8;-8', 2.4, 0, SPL(2))}<path d="M-16 0Q-18 -34 0 -34Q18 -34 16 0Z" fill="#8ff6ff" fill-opacity="0.45" stroke="#c9fbff" stroke-width="1"/>`
      + `<path d="M-10 -30Q-14 -42 -6 -40Q-5 -34 -5 -32Z M10 -30Q14 -42 6 -40Q5 -34 5 -32Z" fill="#8ff6ff" fill-opacity="0.45" stroke="#c9fbff" stroke-width="0.8"/>`
      + `<g>${an('opacity', '1;1;0;1;1', 3, 0, ' keyTimes="0;0.9;0.93;0.96;1"')}<ellipse cx="-6" cy="-18" rx="2" ry="3" fill="#0a3a4a"/><ellipse cx="6" cy="-18" rx="2" ry="3" fill="#0a3a4a"/></g><path d="M-5 -9Q0 -4 5 -9" stroke="#0a3a4a" stroke-width="1.4" fill="none" stroke-linecap="round"/>`
      + `<g transform="translate(15 -16)"><g>${at('rotate', '10;-60;10', 0.8)}<ellipse cy="-5" rx="3" ry="6" fill="#8ff6ff" fill-opacity="0.45" stroke="#c9fbff" stroke-width="0.8"/></g></g></g></g>`
      + `<text x="0" y="-48" text-anchor="middle" font-size="7" ${FONT} fill="#c9fbff" opacity="0.8">HELLO!${an('opacity', '0;0.9;0.9;0', 3)}</text></g>`
      + `<rect y="-6" width="${f1(W)}" height="4" fill="#bffaff" opacity="0.25">${an('y', `-6;${f1(Hh + 4)}`, 3)}</rect></g>`; };
  N.holo18 = S => { const T = tvState(S), on = T.on, mu = T.ch > 0, PR = 64, PHt = 7, SW = 208, SH = 117, Y0 = 30, FINR = 82;
    const D = { w: Math.max(SW, FINR * 2) + 10, d: PR * 2 + 10, act: 'watch', use: { x: 0, z: 170 }, build: () => [scr(0, Y0, 1, SW, SH)] };
    D.fx = ctx => { const C = cam(ctx), k = C.k, L = []; let s = shadow(C, 0, 0, PR + 12, PR + 8, 0.7);
      // walnut acoustic fins on the back arc, cyan LED tips (pulse to the music when on)
      rep(13, i => { const t = PI * (1.04 + 0.92 * i / 12), x = Math.cos(t) * FINR, z = Math.sin(t) * FINR * 0.62 - 6, h = 70 + 70 * Math.pow(Math.sin(PI * (i + 0.5) / 13), 1.3) + (i % 2) * 8, yaw = -(t + PI / 2);
        const tip = `<rect x="0" y="0" width="4" height="1.6" fill="#8ff6ff">${on ? an('opacity', '0.4;1;0.4', 0.48 * (1 + (i % 3) * 0.5), -i * 0.11) : an('opacity', '0.5;0.9;0.5', 3, -i * 0.2)}</rect>`;
        L.push({ q: [x, h / 2, z], s: box3(C, { c: [x, 0, z], ax: yawA(yaw), w: 5, h, d: 11, r: 0.8, col: i % 2 ? '#8b5a34' : '#a06a3e', dec: { f: tip, l: rep(4, j => `<path d="M${f1(1 + j * 2.6)} 2V${f1(h - 2)}" stroke="#5a3a1c" stroke-opacity="0.3" stroke-width="0.35"/>`).join('') } }) }); });
      s += zsort(C, L);
      // emitter plinth + rings
      s += cyl3(C, [0, 0, 0], [0, PHt, 0], PR, '#1f2129', { mat: 'gloss' });
      s += `<g transform="${FR(C, [0, PHt + 0.04, 0], [1, 0, 0], [0, 0, 1])}"><circle r="${PR - 3}" fill="#15161c"/><circle r="${PR - 6}" fill="none" stroke="#3fd0ff" stroke-width="1.2" stroke-dasharray="3 5">${an('stroke-dashoffset', '0;-32', on ? 1.2 : 4)}</circle>`
        + `<circle r="${PR - 12}" fill="none" stroke="#8ff6ff" stroke-width="0.6" stroke-opacity="0.6"/><circle r="20" fill="url(#q18cy)">${an('r', '18;24;18', on ? 0.96 : 3)}</circle><circle r="9" fill="#0c3a4a" stroke="#8ff6ff" stroke-width="0.8"/><circle r="4" fill="#dffcff"/></g>`;
      // beams from the emitter to the floating screen
      const e0 = C.p(-12, PHt, 0), e1 = C.p(12, PHt, 0), b0 = C.p(-SW / 2, Y0, 0), b1 = C.p(SW / 2, Y0, 0);
      s += `<path d="M${P2(e0)}L${P2(b0)}L${P2(b1)}L${P2(e1)}Z" fill="url(#q18bm)">${an('opacity', '0.6;1;0.7;0.9;0.6', 2.6)}</path>`;
      // floating screen: translucent glass, glowing edge, bobbing
      const sid = C.u('hm'), pic = tvPic({ u: q => 'hs' + q + (++UID) }, SW, SH, 'holo', 1, T, mascot(SW, SH, sid));
      const o0 = C.p(-SW / 2, Y0 + SH, 0);
      const scrG = `<g transform="${FR(C, [-SW / 2, Y0 + SH, 0], [1, 0, 0], [0, -1, 0])}"><rect width="${SW}" height="${SH}" rx="1.4" fill="#06202c" opacity="0.55"/>${pic}`
        + `<rect width="${SW}" height="${SH}" rx="1.4" fill="none" stroke="#8ff6ff" stroke-width="1.2">${an('stroke-opacity', '0.5;1;0.5', 2.2)}</rect><path d="M0 8V0H8M${SW - 8} 0H${SW}V8M0 ${SH - 8}V${SH}H8M${SW - 8} ${SH}H${SW}V${SH - 8}" stroke="#dffcff" stroke-width="1.6" fill="none"/></g>`;
      s += `<g>${at('translate', `0 0;0 ${f1(-2 * k)};0 0`, 3.6, 0, SPL(2))}${scrG}</g>`;
      ext(C, [[-SW / 2, Y0 + SH + 3, 0], [SW / 2, Y0 + SH + 3, 0]]);
      s += rep(10, i => { const x = -SW / 2 + SW * (i + 0.5) / 10, p = C.p(x, Y0 + SH + 1, 0), d = 2.8 + (i * 7) % 5 * 0.5;
        return `<circle r="${f1(0.8 * k)}" fill="#dffcff" opacity="0"><animate attributeName="opacity" values="0;0.95;0" dur="${n4(d)}s" begin="${n4(-i * 0.41)}s" repeatCount="indefinite"/><animateMotion dur="${n4(d)}s" begin="${n4(-i * 0.41)}s" repeatCount="indefinite" path="M${P2(p)}l${f1((i % 3 - 1) * 2 * k)} ${f1(-16 * k)}"/></circle>`; }).join('');
      if (mu) s += rep(4, i => note(C, -SW / 2 + 20 + i * 54, Y0 + SH + 6, 0, i, '#3fd0ff')).join('');
      void o0; return { defs: DEF18, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= SPEAKERS (LIV-131..135, slot 21) =======================
  const notes = (C, on, P, col) => on ? P.map((q, i) => note(C, q[0], q[1], q[2], i, col)).join('') : '';
  // sound coming out of a driver: 3 rings expand from it and fade (screen space round the projected driver centre)
  const waves = (C, on, P, col) => on ? P.map(([x, y, z, r0], j) => { const q = C.p(x, y, z), k = C.k; ext(C, [[x - r0 - 14, y, z], [x + r0 + 14, y, z]]);
    return rep(3, i => { const b = n4(-i * 0.5 - j * 0.17); return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(r0 * k)}" fill="none" stroke="${col}" stroke-width="${f1(1.1 * k)}" opacity="0">${an('r', f1(r0 * k) + ';' + f1((r0 + 13) * k), 1.5, b)}${an('opacity', '0.85;0', 1.5, b)}${an('stroke-width', f1(1.3 * k) + ';' + f1(0.3 * k), 1.5, b)}</circle>`; }).join(''); }).join('') : '';
  N.spkJunk18 = S => { const on = isPlay(S), D = { w: 52, d: 20, zs: 1.3, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), L = [];
      const brick = (x, yaw) => box3(C, { c: [x, 0, 0], ax: yawA(yaw), w: 18, h: 6, d: 10, r: 0.4, col: '#b5523b', dec: { f: `<path d="M0 3H18M9 0V3M4.5 3V6M13.5 3V6" stroke="#7a2e1e" stroke-width="0.4"/>`, t: `<rect x="3" y="3" width="3.4" height="4" rx="0.6" fill="#7a2e1e"/><rect x="7.3" y="3" width="3.4" height="4" rx="0.6" fill="#7a2e1e"/><rect x="11.6" y="3" width="3.4" height="4" rx="0.6" fill="#7a2e1e"/>` } });
      const wood = `<rect x="1.2" y="1.2" width="13.6" height="20.6" rx="1" fill="url(#q18gr)"/>` + cone(8, 7, 3, on, 0.1) + cone(8, 15.4, 4.6, on, 0) + `<circle cx="13" cy="20.4" r="0.5" fill="${on ? '#5dff7a' : '#553311'}"/>`;
      const plas = `<rect x="1" y="1" width="12" height="16" rx="1.4" fill="#26272b"/>` + cone(7, 5.4, 2.6, on, 0.2) + cone(7, 12, 3.6, on, 0.15)
        + `<path d="M12.6 1.4L10 4.4L11.6 5.4L9.4 8" stroke="#e9e9ee" stroke-width="0.35" fill="none"/><g transform="rotate(35 3 14)"><rect x="-1" y="12.8" width="9" height="2.6" fill="#b9bcc1" opacity="0.95"/></g><g transform="rotate(-35 3 14)"><rect x="-1" y="12.8" width="9" height="2.6" fill="#b9bcc1" opacity="0.95"/></g>`;
      L.push({ q: [-15, 6, 0], s: shadow(C, -15, 0, 11, 8, 0.8) + brick(-15, 0.1) + box3(C, { c: [-15, 6, 0], ax: yawA(0.24), w: 16, h: 23, d: 13, r: 1, col: '#b07a45', dec: { f: wood, t: `<path d="M2 6H14" stroke="#7a4e25" stroke-width="0.3"/>` } }) });
      L.push({ q: [15, 6, 1], s: shadow(C, 15, 1, 10, 8, 0.8) + brick(15, -0.12) + `<g>${on ? '' : at('translate', '0 0;0 0;0.3 0;-0.3 0;0 0;0 0', 3.2, 0, ' keyTimes="0;0.6;0.64;0.68;0.72;1"')}${box3(C, { c: [15, 6, 1], ax: yawA(-0.26), w: 14, h: 18, d: 12, r: 1.4, col: '#2f3035', dec: { f: plas } })}</g>` });
      let s = curve(C, [[-9, 12, -6], [-4, 0.3, -12], [6, 0.3, -12], [10, 10, -5]], '#d9c2a0', 0.9) + zsort(C, L) + waves(C, on, [[-15, 13.6, 7, 4.6], [15, 12, 8, 3.6]], '#ffffff') + notes(C, on, [[-15, 34, 4], [14, 30, 4], [0, 36, 6]], '#8a4a1a');
      ext(C, [[0, 44, 0]]); return { defs: DEF18, front: s, bb: C.bb(4) }; };
    return D; };
  N.spkShelf18 = S => { const on = isPlay(S), D = { w: 64, d: 22, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), L = [];
      [-1, 1].forEach(sg => { const x = sg * 22, yaw = -sg * 0.2, SY = 30;
        const f = `<rect x="0.8" y="0.8" width="13.4" height="21.4" rx="1.2" fill="#d6ad78"/>` + rep(4, i => `<path d="M1 ${f1(3 + i * 5)}Q7 ${f1(2 + i * 5)} 14 ${f1(3.4 + i * 5)}" stroke="#b5864e" stroke-opacity="0.45" stroke-width="0.3" fill="none"/>`).join('') + cone(7.5, 5.4, 2.4, on, sg > 0 ? 0.2 : 0) + cone(7.5, 14.4, 5, on, sg > 0 ? 0.1 : 0) + (sg < 0 ? led(12.6, 20.6, true, on ? '#5ab8ff' : '#ffffff') : '');
        L.push({ q: [x, 15, 0], s: shadow(C, x, 0, 9, 8, 0.8) + box3(C, { c: [x, 0, 0], ax: yawA(yaw), w: 14, h: 1.6, d: 14, r: 1, col: '#2a2b30' }) + cyl3(C, [x, 1.6, 0], [x, SY - 1.4, 0], 1.5, '#2a2b30') + box3(C, { c: [x, SY - 1.4, 0], ax: yawA(yaw), w: 12, h: 1.4, d: 12, r: 0.8, col: '#2a2b30' })
          + box3(C, { c: [x, SY, 0], ax: yawA(yaw), w: 15, h: 23, d: 15, r: 1.6, col: '#f4f1ea', dec: { f, t: `<circle cx="7.5" cy="10" r="0.6" fill="#c9c2b0"/>` } }) }); });
      let s = zsort(C, L) + curve(C, [[-20, 2, -6], [-8, 0.3, -10], [8, 0.3, -10], [20, 2, -6]], '#3a3b40', 0.7) + waves(C, on, [[-22, 38.6, 8, 5], [22, 38.6, 8, 5]], '#7ab8ff') + notes(C, on, [[-22, 60, 4], [22, 58, 4], [0, 62, 4]], '#3f7fc8');
      ext(C, [[0, 66, 0]]); return { defs: DEF18, front: s, bb: C.bb(4) }; };
    return D; };
  N.spkTower18 = S => { const on = isPlay(S), WAL = '#8b5a34', D = { w: 68, d: 26, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), L = [];
      [-1, 1].forEach(sg => { const x = sg * 24, yaw = -sg * 0.18, LY = 7, TH = 92, ph = sg > 0 ? 0.12 : 0;
        const f = `<rect x="1.4" y="1.4" width="17.2" height="${TH - 2.8}" rx="1.6" fill="${shade(WAL, 0.82)}"/><rect x="2.6" y="2.6" width="14.8" height="30" rx="1.4" fill="url(#q18cl)"/><rect x="2.6" y="2.6" width="14.8" height="30" rx="1.4" fill="none" stroke="#5a3a1c" stroke-width="0.4"/>`
          + `<circle cx="10" cy="39" r="2.6" fill="none" stroke="#d9b25a" stroke-width="0.6"/>` + cone(10, 39, 2.2, on, ph) + [51, 64, 77].map((y, j) => `<circle cx="10" cy="${y}" r="5.6" fill="none" stroke="#d9b25a" stroke-width="0.7"/>` + cone(10, y, 5, on, ph + 0.05 * (j + 1))).join('')
          + `<text x="10" y="${TH - 2.6}" text-anchor="middle" font-size="1.5" ${FONT} fill="#d9b25a">SQUISH</text>`;
        let g = shadow(C, x, 0, 12, 10, 0.8);
        [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => { g += cyl3(C, [x + a * 7.4, 0, b * 6.4], [x + a * 6, LY, b * 5.4], 0.8, WAL, { r2: 1.4 }); });
        g += box3(C, { c: [x, LY, 0], ax: yawA(yaw), w: 20, h: TH, d: 20, r: 2.2, col: WAL, dec: { f, t: `<path d="M2 4H18M2 16H18" stroke="#5a3a1c" stroke-opacity="0.3" stroke-width="0.3"/>`, r: rep(5, i => `<path d="M0 ${f1(8 + i * 12)}Q10 ${f1(6 + i * 12)} 20 ${f1(9 + i * 12)}" stroke="#5a3a1c" stroke-opacity="0.3" stroke-width="0.35" fill="none"/>`).join('') } });
        L.push({ q: [x, 30, 0], s: g }); });
      let s = zsort(C, L) + waves(C, on, [[-24, 35, 11, 5], [24, 35, 11, 5], [-24, 61, 11, 5], [24, 61, 11, 5]], '#ffd28a') + notes(C, on, [[-24, 108, 4], [24, 106, 4], [0, 110, 4]], '#8b4a1a'); ext(C, [[0, 114, 0]]); return { defs: DEF18, front: s, bb: C.bb(4) }; };
    return D; };
  N.spkPiano18 = S => { const on = isPlay(S), GOLD = '#d4af5a', BK = '#16161a', D = { w: 104, d: 30, build: () => [] };
    const drv = (cx, cy, r, ph) => `<circle cx="${cx}" cy="${cy}" r="${f1(r + 1.1)}" fill="${GOLD}"/><circle cx="${cx}" cy="${cy}" r="${f1(r + 0.4)}" fill="#0a0a0c"/>` + cone(cx, cy, r, on, ph);
    D.fx = ctx => { const C = cam(ctx), L = [];
      [-1, 1].forEach(sg => { const x = sg * 40, yaw = -sg * 0.16, TH = 116, ph = sg > 0 ? 0.1 : 0;
        const f = `<rect x="0.8" y="0.8" width="20.4" height="${TH - 1.6}" rx="1.4" fill="#0f0f12"/>` + drv(11, 10, 2.6, ph) + drv(11, 21, 2.6, ph) + drv(11, 38, 6.4, ph) + drv(11, 57, 6.4, ph + 0.05) + drv(11, 76, 6.4, ph + 0.1) + drv(11, 95, 6.4, ph + 0.15)
          + `<path d="M3 0.8L9 0.8L3 ${TH * 0.5}Z" fill="#ffffff" opacity="0.06"/><rect x="5" y="${TH - 6}" width="12" height="2.6" rx="0.6" fill="${GOLD}"/><text x="11" y="${TH - 4.1}" text-anchor="middle" font-size="1.6" ${FONT} fill="#16161a">SQUISH</text>`;
        let g = shadow(C, x, 0, 14, 12, 0.85) + box3(C, { c: [x, 0, 0], ax: yawA(yaw), w: 24, h: 3, d: 24, r: 1.2, col: GOLD });
        g += box3(C, { c: [x, 3, 0], ax: yawA(yaw), w: 22, h: TH, d: 22, r: 2.6, col: BK, dec: { f, t: `<path d="M1 1H21" stroke="${GOLD}" stroke-width="0.6"/>`, r: `<path d="M3 2L8 2L3 ${TH * 0.6}Z" fill="#ffffff" opacity="0.07"/>`, l: `<path d="M3 2L8 2L3 ${TH * 0.6}Z" fill="#ffffff" opacity="0.07"/>` } });
        L.push({ q: [x, 56, 0], s: g }); });
      const sf = `<rect x="1" y="1" width="28" height="28" rx="2" fill="#0f0f12"/>` + drv(15, 15, 10, 0.2) + `<text x="15" y="28" text-anchor="middle" font-size="1.4" ${FONT} fill="${GOLD}">SUB</text>`;
      L.push({ q: [0, 14, -4], s: shadow(C, 0, -4, 18, 16, 0.85) + `<g>${box3(C, { c: [0, 0, -4], w: 30, h: 30, d: 30, r: 2.4, col: BK, dec: { f: sf, t: `<path d="M2 2H28" stroke="${GOLD}" stroke-width="0.5"/>` } })}</g>` });
      let s = zsort(C, L) + waves(C, on, [[-40, 62, 12, 6.4], [40, 62, 12, 6.4], [-40, 43, 12, 6.4], [40, 43, 12, 6.4], [0, 15, 12, 10]], '#ffe29a') + notes(C, on, [[-40, 130, 4], [40, 128, 4], [0, 44, 12]], '#b8872a'); ext(C, [[0, 134, 0]]); return { defs: DEF18, front: s, bb: C.bb(4) }; };
    return D; };
  N.spkOrb18 = S => { const on = isPlay(S), D = { w: 70, d: 24, zs: 1.6, build: () => [] };
    D.fx = ctx => { const C = cam(ctx), k = C.k, L = [];
      [-1, 1].forEach(sg => { const x = sg * 26, OY = 34, R = 11, ph = sg > 0 ? -1.1 : 0, cp = C.p(x, OY, 0);
        let g = shadow(C, x, 0, 10, 9, 0.7) + cyl3(C, [x, 0, 0], [x, 2, 0], 9, '#c9ced6', { mat: 'gloss' }) + cyl3(C, [x, 2, 0], [x, 5, 0], 6, '#e4e7ec', { mat: 'gloss' })
          + `<g transform="${FR(C, [x, 5.05, 0], [1, 0, 0], [0, 0, 1])}"><circle r="4.4" fill="url(#q18cy)">${an('r', '3.6;5.4;3.6', on ? 0.48 : 2.6, ph)}</circle><circle r="2" fill="#dffcff"/></g>`;
        const lp = C.p(x, 5, 0); g += `<path d="M${f1(lp[0] - 3 * k)} ${f1(lp[1])}L${f1(cp[0] - 8 * k)} ${f1(cp[1] + 6 * k)}L${f1(cp[0] + 8 * k)} ${f1(cp[1] + 6 * k)}L${f1(lp[0] + 3 * k)} ${f1(lp[1])}Z" fill="url(#q18bm)" opacity="0.6"/>`;
        let orb = sph(C, [x, OY, 0], R, '#e9eef8') + `<g transform="translate(${P2(cp)})"><ellipse rx="${f1(R * 0.9 * k)}" ry="${f1(R * 0.9 * k)}" fill="url(#q18mg)" opacity="0.55" transform="scale(0.55 1)"/>` + cone(0, 0, R * 0.4 * k, on, ph) + `</g>`;
        const ring = (r, tilt, d, op) => `<g transform="translate(${P2(cp)}) rotate(${tilt})"><ellipse rx="${f1(r * k)}" ry="${f1(r * 0.3 * k)}" fill="none" stroke="#5ff0ff" stroke-width="${f1(0.8 * k)}" stroke-dasharray="${f1(6 * k)} ${f1(4 * k)}" opacity="${op}">${an('stroke-dashoffset', `0;${f1(-40 * k)}`, d)}${an('stroke', '#5ff0ff;#b98aff;#ff7ac8;#5ff0ff', 6, ph)}</ellipse></g>`;
        orb = ring(R + 4, sg * -12, on ? 0.9 : 3, 0.9) + orb;
        if (on) orb += `<circle cx="${f1(cp[0])}" cy="${f1(cp[1])}" r="${f1(R * k)}" fill="none" stroke="#8ff6ff" stroke-width="${f1(0.6 * k)}" opacity="0">${an('r', `${f1(R * k)};${f1((R + 14) * k)}`, 0.96, ph * 0.3)}${an('opacity', '0.8;0', 0.96, ph * 0.3)}</circle>`;
        g += `<g>${at('translate', `0 0;0 ${f1(-2.4 * k)};0 0`, 3, ph, SPL(2))}${orb}</g>`;
        L.push({ q: [x, 20, 0], s: g }); });
      let s = zsort(C, L) + notes(C, on, [[-26, 56, 4], [26, 54, 4], [0, 60, 4]], '#3fb8e0'); ext(C, [[0, 62, 0], [-44, 34, 0], [44, 34, 0]]); return { defs: DEF18, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= LIV-136 ROBO-VAC + CHARGING DOCK =======================
  // robot built at (x, y, z); mv = driving (brush + lidar spin, blue LED); the page shows it as its own sprite (D.vac) while it cleans
  const robot = (C, x, y, z, mv, dk) => { const k = C.k, R = 15, BL = mv || dk === 2;
    let s = shadow(C, x, z, R + 1.5, R, 0.85, 0.05);
    // two side brushes under the front edge (horizontal, on the floor; drawn first so the body covers their middle)
    [-1, 1].forEach(sg => { s += `<g transform="${FR(C, [x + sg * 9.4, 0.35, z + 9.6], [1, 0, 0], [0, 0, 1])}"><g>${mv ? at('rotate', sg < 0 ? '0;-360' : '0;360', 0.4) : ''}${rep(3, i => { const t = i * 2.094 + sg * 0.4; return `<path d="M0 0L${f1(Math.cos(t) * 8)} ${f1(Math.sin(t) * 8)}" stroke="#3a3f4a" stroke-width="0.7" stroke-linecap="round"/><path d="M${f1(Math.cos(t) * 5)} ${f1(Math.sin(t) * 5)}L${f1(Math.cos(t + 0.18) * 8.2)} ${f1(Math.sin(t + 0.18) * 8.2)}M${f1(Math.cos(t) * 5)} ${f1(Math.sin(t) * 5)}L${f1(Math.cos(t - 0.18) * 8.2)} ${f1(Math.sin(t - 0.18) * 8.2)}" stroke="#5a606c" stroke-width="0.35" stroke-linecap="round"/>`; }).join('')}<circle r="1.4" fill="#3fb8ff"/></g></g>`; });
    s += cyl3(C, [x, y + 0.4, z], [x, y + 1.6, z], R - 1, '#2a2e38');
    s += cyl3(C, [x, y + 1.6, z], [x, y + 3.8, z], R, '#9fb4cc', { noCap: 1 }) + cyl3(C, [x, y + 3.8, z], [x, y + 6.4, z], R, '#ffffff', { capCol: '#fbfcfe' });
    // top: soft rings, face display (front), power button (back), lidar puck with a spinning scan sweep
    s += `<g transform="${FR(C, [x, y + 6.45, z], [1, 0, 0], [0, 0, 1])}"><circle r="${R - 1.6}" fill="none" stroke="#dde2ea" stroke-width="0.5"/><path d="M${-R + 2} 3A${R - 2} ${R - 2} 0 0 0 ${R - 2} 3" stroke="#e6eaf0" stroke-width="0.9" fill="none"/>`
      + `<rect x="-6" y="4.4" width="12" height="5.4" rx="2.7" fill="#161a22"/>${[-2.6, 2.6].map(ex => `<ellipse cx="${ex}" cy="6.6" rx="0.95" ry="1.25" fill="${BL ? '#7ff0ff' : '#7dffb0'}"><animate attributeName="ry" values="1.25;1.25;0.2;1.25;1.25" keyTimes="0;0.9;0.94;0.98;1" dur="3.6s" repeatCount="indefinite"/></ellipse>`).join('')}<path d="M-1.4 8.2Q0 9.2 1.4 8.2" stroke="${BL ? '#7ff0ff' : '#7dffb0'}" stroke-width="0.5" fill="none" stroke-linecap="round"/>`
      + `<circle cx="0" cy="-11" r="1.6" fill="#e6eaf0" stroke="#aab2be" stroke-width="0.35"/><circle cx="0" cy="-11" r="0.9" fill="none" stroke="${dk === 1 ? '#5dff7a' : '#3fb8ff'}" stroke-width="0.45">${an('stroke-opacity', mv ? '1;0.4;1' : '0.3;1;0.3', mv ? 0.8 : 2.2)}</circle></g>`;
    s += cyl3(C, [x, y + 6.4, z - 4.6], [x, y + 9.4, z - 4.6], 4.8, '#2a2e38');
    s += `<g transform="${FR(C, [x, y + 9.45, z - 4.6], [1, 0, 0], [0, 0, 1])}"><circle r="4.2" fill="#1a1d24"/><g>${mv ? at('rotate', '0;360', 1.2) : ''}<path d="M0 0L0 -4.2A4.2 4.2 0 0 1 3 -2.9Z" fill="#3fb8ff" opacity="${mv ? 0.55 : 0.2}"/></g><circle r="1.6" fill="#3a3f4a"/><path d="M-0.9 -0.9A1.3 1.3 0 0 1 0.9 -0.9" stroke="#ffffff" stroke-opacity="0.4" stroke-width="0.35" fill="none"/></g>`;
    void k; return s; };
  N.vac18 = S => { const st = S.st || '', play = isPlay(S), out = /out/.test(st), RZ = 15, RY = 1.2, TW = 38, TH = 46, TD = 16, TZ = -9;
    const D = { w: 44, d: 50, zs: 1.5, noBlock: 1, build: () => [] };
    const LC = out ? '#3fb8ff' : '#5dff7a';
    const dockF = `<rect x="5" y="4" width="${TW - 10}" height="15" rx="4" fill="#1c2230"/><rect x="6.4" y="12" width="${TW - 12.8}" height="5.6" rx="2.4" fill="#5a5f6a" opacity="0.7"/><path d="M8 12.6Q12 10.6 16 12.4T24 12T30 12.6" stroke="#8a8f98" stroke-width="0.4" fill="none"/>`
      + `<path d="M6.4 5.4H${TW - 6.4}" stroke="#ffffff" stroke-opacity="0.25" stroke-width="0.7"/><text x="${TW / 2}" y="9.6" text-anchor="middle" font-size="3" font-family="'Fredoka','Comic Sans MS',sans-serif" font-weight="700" fill="#8fe0ff">SQUISH VAC</text>`
      + `<circle cx="${TW / 2}" cy="25.6" r="3.6" fill="#e6eaf0" stroke="#b9c0cc" stroke-width="0.4"/><circle cx="${TW / 2}" cy="25.6" r="2.4" fill="none" stroke="${LC}" stroke-width="0.8">${an('stroke-opacity', '0.25;1;0.25', out ? 1 : 2.4)}</circle>`
      + `<path d="M${TW / 2 + 0.5} 23.8L${TW / 2 - 1} 26H${TW / 2 + 0.2}L${TW / 2 - 0.5} 27.6L${TW / 2 + 1.1} 25.2H${TW / 2 - 0.1}Z" fill="${LC}"/>`
      + `<path d="M5 ${TH - 3}V${TH - 10}Q5 ${TH - 15} 10 ${TH - 15}H${TW - 10}Q${TW - 5} ${TH - 15} ${TW - 5} ${TH - 10}V${TH - 3}Z" fill="#2a2e38"/><path d="M8 ${TH - 3}V${TH - 9}Q8 ${TH - 12} 11 ${TH - 12}H${TW - 11}Q${TW - 8} ${TH - 12} ${TW - 8} ${TH - 9}V${TH - 3}Z" fill="#14171e"/>`
      + rep(2, i => `<rect x="${f1(TW / 2 - 6 + i * 9)}" y="${TH - 6}" width="3" height="1.6" rx="0.6" fill="#c9ced6"/>`).join('');
    const dockT = `<rect x="9" y="4" width="${TW - 18}" height="5" rx="2.5" fill="#d6dbe3"/><rect x="12" y="5.2" width="${TW - 24}" height="2.6" rx="1.3" fill="#b9c0cc"/>`;
    const side = `<path d="M3 6V${TH - 4}" stroke="#d6dbe3" stroke-width="0.6"/>` + rep(4, i => `<rect x="${f1(5 + i * 2.2)}" y="30" width="1" height="8" rx="0.5" fill="#c3cad5"/>`).join('');
    D.fx = ctx => { const C = cam(ctx); let s = shadow(C, 0, 6, 28, 22, 0.75);
      s += box3(C, { c: [0, 0, 9], w: 44, h: RY, d: 34, r: 5, col: '#d3d9e2', dec: { t: `<rect x="15.4" y="16" width="4" height="7" rx="1.2" fill="#aeb6c2"/><rect x="24.6" y="16" width="4" height="7" rx="1.2" fill="#aeb6c2"/><path d="M6 31H38" stroke="#b9c0cc" stroke-width="0.5"/><path d="M19 27L22 29.4L25 27" stroke="#9aa4b4" stroke-width="0.7" fill="none" stroke-linecap="round"/>` } });
      s += box3(C, { c: [0, 0, TZ], w: TW, h: TH, d: TD, r: 5, col: '#f3f5f8', dec: { f: dockF, t: dockT, r: side, l: side } });
      if (!out) { if (play) { const h = C.p(0, RY, RZ), P = [[-34, 0, 38], [0, 0, 60], [34, 0, 38], [0, 0, RZ]].map(q => { const v = C.p(q[0], q[1], q[2]); return f1(v[0] - h[0]) + ' ' + f1(v[1] - h[1]); });
          s += `<g><animateMotion dur="9s" repeatCount="indefinite" path="M0 0C${P[0]} ${P[1]} ${P[1]}S${P[2]} ${P[3]}"/>${robot(C, 0, RY, RZ, 1, 0)}</g>`; }
        else s += robot(C, 0, RY, RZ, 0, 1); }
      // the sprite the page drives around the room (same projection; origin = the docked spot on the floor)
      const C2 = cam(ctx), body = robot(C2, 0, RY, RZ, 1, 0), hm = C2.p(0, 0, RZ), b = C2.bb(2), vb = [b[0] - hm[0], b[1] - hm[1], b[2] - b[0], b[3] - b[1]];
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${f1(b[0])} ${f1(b[1])} ${f1(vb[2])} ${f1(vb[3])}"><defs>${DEF18}</defs>${body}</svg>`;
      RD._vac = { src: 'data:image/svg+xml,' + encodeURIComponent(svg), bb: vb.map(v => +f1(v)), home: [+f1(hm[0]), +f1(hm[1])] };
      ext(C, [[-38, 0, 62], [38, 0, 62]]);
      return { defs: DEF18, front: s, bb: C.bb(3) }; };
    return D; };
  const draw0 = RD.draw;
  RD.draw = (r, o) => { RD._vac = null; const res = draw0(r, o); if (RD._vac && res && !res.vac) res.vac = RD._vac; RD._vac = null; return res; };

  // ---------- catalog edits ----------
  const TV = { role: 'tv', play: 'show', playL: 'Turn on the TV', stopL: 'Turn off the TV', playS: 'Squish Toons is on · tap to turn it off' };
  RD.SET18 = {
    'LIV-011': Object.assign({ spec: 'rabbit18', note: 'Needs speakers in the room for sound: without them it only shows static. With speakers, tap to flip through 3 channels (Squish Toons, Squish Cup football, Space Trip) and off. A chunky mint CRT with two channel dials sits on a three-legged pine stool. The rabbit-ear antenna sways a little, one ear has a tinfoil ball on the tip, and a strip of duct tape holds a corner together. Tap it: Squish Toons comes on with fuzzy scanlines and a rolling bar.' }, TV),
    'LIV-031': Object.assign({ spec: 'frame18', note: 'A slim TV in a light oak picture frame with a white mat. When it is off it shows a sunrise painting (art mode) with a soft sheen sweeping over it; tap it and the painting turns into Squish Toons.' }, TV),
    'LIV-051': Object.assign({ name: 'Retro Walnut TV Console & Turntable', spec: 'console18', note: 'A mid-century walnut console on brass-capped legs with orange grille-cloth speakers, a cream Squish-o-Vision TV on a brass swivel, a turntable and a little tube amp. Tap it: the TV warms up, the record spins, the tubes glow and the VU needles dance.' }, TV),
    'LIV-071': Object.assign({ spec: 'oled18', note: 'A smoked-walnut credenza with fluted doors and gold trim. Its huge 200-unit OLED screen (the biggest TV in the house) rolls up out of the slot on top when you turn it on, and the wall behind it glows.' }, TV),
    'LIV-091': Object.assign({ name: 'Floating Holo-Screen & Acoustic Sculpture', spec: 'holo18', note: 'A giant see-through holo-screen floats over a glowing emitter, wrapped by a ring of walnut acoustic fins with cyan tips. When it is off a little hologram mascot waves hello; tap it for Squish Toons in holo colour.' }, TV),
  };
  const ADD18 = [
    [131, 1, 'Mismatched Garage-Sale Speakers', 'spkJunk18', 80, 'One wooden speaker and one cracked plastic one held together with duct tape, each propped on a brick. The plastic one buzzes now and then. They give the TV its sound: when a TV in the room is on, sound waves pulse out of them.'],
    [132, 2, 'Bookshelf Speakers on Stands', 'spkShelf18', 360, 'Two white bookshelf speakers with oak fronts on slim black stands, toed in toward the sofa. They give the TV its sound: when a TV in the room is on, sound waves pulse out of them.'],
    [133, 3, 'Walnut Tower Speakers', 'spkTower18', 1400, 'Tall walnut towers on tapered legs with orange grille cloth and brass-ringed drivers. They give the TV its sound: when a TV in the room is on, sound waves pulse out of them.'],
    [134, 4, 'Piano-Black Towers & Subwoofer', 'spkPiano18', 5200, 'Glossy piano-black floor speakers on gold plinths with gold-ringed drivers, plus a subwoofer cube that thumps in the middle. They give the TV its sound: when a TV in the room is on, sound waves pulse out of them.'],
    [135, 5, 'Levitating Orb Speakers', 'spkOrb18', 26000, 'Two pearl orb speakers float over glowing pedestals inside colour-shifting light rings; when music plays, sound rings pulse out of them. They give the TV its sound: when a TV in the room is on, sound waves pulse out of them.'],
  ];
  const edit17 = RD.edit;
  RD.edit = rows => { const R = edit17(rows).map(r => RD.SET18[r.id] ? Object.assign({}, r, RD.SET18[r.id]) : r);
    if (R.some(r => r.id === 'LIV-131')) return R;
    const base = t => R.find(r => r.room === 'LIV' && r.tier === t && r.slot === 15) || R.find(r => r.room === 'LIV' && r.tier === t);
    ADD18.forEach(([n, t, name, spec, cost, note]) => { const b = base(t); if (b) R.push(Object.assign({}, b, { id: 'LIV-' + n, slot: 21, slotName: 'Speakers', name, spec, cost, note, role: 'tvspk', add: 1, play: undefined, playL: undefined, stopL: undefined, playS: undefined, live: undefined })); });
    { const b = base(3); if (b) R.push(Object.assign({}, b, { id: 'LIV-136', slot: 22, slotName: 'Robot Vacuum', catO: 'Electronics', name: 'Robo-Vac & Charging Dock', spec: 'vac18', cost: 1450, vac: 1, role: undefined, play: 'show', playL: 'Start cleaning', stopL: 'Send it home', playS: 'Cleaning… tap to send it home', live: undefined, add: 1,
      note: 'A little white robot vacuum with blinking LED eyes, a spinning lidar puck and a side brush, parked on its charging dock. Tap it: it rolls out and cleans the whole room by itself, then after 5 minutes it drives back into the dock to charge.' })); }
    // tier swaps (user): Frame TV + Bookshelf Speakers -> tier 3, Walnut Console + Walnut Towers -> tier 2 (level, rarity, price and bonus go with the tier)
    const TF = ['tier', 'tierName', 'rarity', 'lv', 'cost', 'bonus', 'statVal'];
    [['LIV-031', 'LIV-051'], ['LIV-132', 'LIV-133']].forEach(([x, y]) => { const i = R.findIndex(r => r.id === x), j = R.findIndex(r => r.id === y); if (i < 0 || j < 0 || R[i].sw18) return;
      const A = R[i], B = R[j], pa = {}, pb = {}; TF.forEach(f => { if (f in B) pa[f] = B[f]; if (f in A) pb[f] = A[f]; }); R[i] = Object.assign({}, A, pa, { sw18: 1 }); R[j] = Object.assign({}, B, pb, { sw18: 1 }); });
    return R; };
  RD.H18 = { DEF18, toon, robot };
  RD.PLUS18 = 1;
})();
