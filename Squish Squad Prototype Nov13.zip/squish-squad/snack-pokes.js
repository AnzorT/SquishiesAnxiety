// Snack Shack pokes (Nov 9, user: 'now, i want us to do what we did with petshop to the snack shack'): every Snack Shack creature reacts to a poke
// on each of the 14 spots in its own way, built with the Pet Shop poke kit (pet-pokes.js: contact -> notice -> reaction -> settle).
// The 'ear' spots are the top corners of each snack (Frybo's fries, Chef Bun's hat, Boba's straw, Dunkie's / Choco's bite mark ...), the 'tail'
// spot is its back / cone / cup / wrapper. Food-y reactions use each snack's own parts (steam, salt, sprinkles, the layers, the melt, the cherry,
// the pearls and straw). Generic snack paws can't reach the head by hand offsets (they stretch into rods), so reaching up is done by swinging the
// arm up (armUp).
(function boot() {
  const R = window.RiveRig; if (!R || !R.POKELIB || !R.SNACKLIB || !R.STATES.poke_head) { setTimeout(boot, 25); return; } if (R.snackPokeV) return; R.snackPokeV = 1;
  const { S, hand, both, o, NOHANDS, jump, shake, swing, jelly } = R.PETLIB;
  const { see, unsee, giggle, sniff, lick, para, leanIn, happy, build } = R.POKELIB;

  // ---------- snack verbs ----------
  // swings that side's arm up beside the head (paw near the poked spot) and rubs it with small strokes
  const armUp = (t, s, n, a, x) => { const k = S(s); a = a || 150; t.to(300, o({ [k.arm]: a }, x || {}), 'io');
    for (let i = 0; i < (n || 2); i++) t.to(170, { [k.arm]: a - 16 }, 'io').to(170, { [k.arm]: a }, 'io'); return t.to(300, { [k.arm]: 0, winkL: 0, winkR: 0 }, 'io'); };
  // the eye is low enough for the paw: hand(s, 12, -20) with the arm at 20 lands it on the eye (calibrated on Mallow / Frybo / Chef Bun)
  const eyeRub = (t, s) => { const k = S(s), h = hand(s, 12, -20); t.e('blink2').to(300, o(h, { [k.arm]: 20, [k.wink]: 1 }), 'io');
    for (let i = 0; i < 2; i++) t.to(170, { [k.hx]: h[k.hx] + (s < 0 ? 3 : -3), [k.hy]: h[k.hy] - 1.5 }, 'io').to(170, { [k.hx]: h[k.hx], [k.hy]: h[k.hy] }, 'io');
    return t.to(300, { [k.hx]: 0, [k.hy]: 0, [k.arm]: 0, [k.wink]: 0 }, 'io').e('blink'); };
  const wobble = (t, a, ch) => jelly(t, a || 0.12, 3, 300, ch);
  const lookBack = (t, hold) => { see(t, 'tail', 1, hold || 350); return unsee(t, 380); };
  const hop = (t, h, ev) => jump(t, { h: h || 6, ant: 140, up: 190, c: 0.14, arm: 40, ev });
  const tickle = (t, extra) => { t.to(220, o(both(8, -4), { hap: 1, smile: 1 }), 'io'); const a = t.t; giggle(t, 3, 0.9); if (extra) para(t, a, extra); return t.to(260, NOHANDS, 'io'); };
  const tasteHeart = t => { lick(t, 2); return t.to(220, { hap: 1, smile: 1 }, 'io').e('emit', 'heart', 'head', 1).wait(320).to(220, { hap: 0, smile: 0 }, 'io'); };

  // ---------- body facts: ear swing, feet, taps, spot names ----------
  const BODY = {
    mallow: { ear: 0.6, lbl: { ear: 'top corner', nose: 'Mouth', tail: 'Back' } },
    bao: { ear: 0.6, lbl: { ear: 'pleats', nose: 'Mouth', tail: 'Back' } },
    dunkie: { ear: 0.6, lbl: { ear: s => s > 0 ? 'Bite mark' : 'Left of his icing', nose: 'Mouth', tail: 'Back' } },
    frybo: { ear: 1, lbl: { ear: 'fries', nose: 'Mouth', tail: 'Box' } },
    bunbun: { ear: 0.6, hopBack: 1, lbl: { ear: 'top bun', nose: 'Mouth', belly: 'Patty', side: 'side', foot: 'bottom bun', tail: 'Back' } },
    choco: { ear: 0.6, lbl: { ear: s => s > 0 ? 'Bite mark' : 'Left top corner', nose: 'Mouth', belly: 'Wrapper', tail: 'Wrapper (back)' } },
    scoop: { ear: 0.6, hopBack: 1, lbl: { head: 'Cherry', ear: 'scoop', nose: 'Mouth', belly: 'Cone', foot: 'cone tip', tail: 'Cone (back)' } },
    boba: { ear: 1, hopBack: 1, lbl: { ear: s => s > 0 ? 'Straw' : 'Left of his lid', head: 'Lid', nose: 'Mouth', belly: 'Pearls', foot: 'cup bottom', tail: 'Cup (back)' } },
    chefbun: { ear: 1, lbl: { head: 'Chef hat', ear: 'side of his hat', nose: 'Mouth', tail: 'Back' } },
  };

  // ---------- each snack's reactions, spot by spot (t is just after the contact; s = side) ----------
  const RE = {
    mallow: { // marshmallow: slow memory-foam rise, the squishiest
      head: (t, s) => { t.to(260, { sq: 0.3, close: 1, hap: 0.6 }, 'io').wait(200).to(1300, { sq: 0, close: 0, hap: 0 }, 'o'); giggle(t, 2, 0.8); },
      ear: (t, s) => { see(t, 'ear', s, 150); t.to(320, { puff: 0.5, wide: 0.4 }, 'io').to(450, { puff: 0, wide: 0 }, 'io'); unsee(t); happy(t, 1); },
      nose: (t, s) => { t.to(150, { cross: 0, ly: 0.3 }, 'io'); tasteHeart(t); t.to(200, { ly: 0 }, 'io'); },
      eye: (t, s) => { eyeRub(t, s); },
      cheek: (t, s) => { leanIn(t, s, { sq: 0.06 }); },
      belly: (t, s) => { tickle(t, u => jelly(u, 0.1, 4, 280)); },
      side: (t, s) => { jelly(t, 4, 3, 340, 'bend'); see(t, 'side', s, 250); unsee(t, 350); },
      foot: (t, s) => { see(t, 'foot', s, 200); t.to(260, { [S(s).foot]: 0 }, 'io'); unsee(t); hop(t, 4); },
      tail: (t, s) => { wobble(t, 0.14); lookBack(t); },
    },
    bao: { // steamed bun: steam puffs from his knot
      head: (t, s) => { t.e('emit', 'steam', 'head', 5).to(200, { puff: 0.35, close: 0.6 }, 'io').to(300, { puff: 0, close: 0 }, 'io'); giggle(t, 2); },
      ear: (t, s) => { see(t, 'ear', s, 100); t.osc(520, 2, { htilt: s * 5 }, { htilt: s * 1 }, 'io').e('emit', 'steam', 'head', 2); unsee(t); },
      nose: (t, s) => { t.to(150, { cross: 0, ly: 0.2 }, 'io'); sniff(t, 3); t.to(240, { hap: 1, smile: 1, ly: 0 }, 'io').e('emit', 'steam', 'head', 2).wait(300).to(200, { hap: 0, smile: 0 }, 'io'); },
      eye: (t, s) => { eyeRub(t, s); },
      cheek: (t, s) => { leanIn(t, s, { puff: 0.2 }); },
      belly: (t, s) => { tickle(t, u => jelly(u, 0.09, 4, 260)); t.e('emit', 'steam', 'head', 2); },
      side: (t, s) => { jelly(t, 3, 3, 320, 'bend'); t.e('emit', 'steam', 'head', 2); see(t, 'side', s, 200); unsee(t, 320); },
      foot: (t, s) => { hop(t, 5, [['emit', 'steam', 'head', 3]]); },
      tail: (t, s) => { t.e('emit', 'steam', 'head', 3); lookBack(t); },
    },
    dunkie: { // donut: rolls like a wheel, sprinkles bounce off
      head: (t, s) => { t.e('emit', 'sprinkle', 'head', 4); see(t, 'head', s, 200); unsee(t, 300); giggle(t, 2); },
      ear: (t, s) => { if (s > 0) { see(t, 'ear', s, 100); t.to(220, { frown: 0.45, puff: 0.3, wide: 0.4 }, 'io'); armUp(t, 1, 2, 132); unsee(t); t.to(250, { frown: 0, puff: 0, wide: 0, hap: 1, smile: 1 }, 'io').wait(250); }
        else { see(t, 'ear', s, 150); unsee(t); giggle(t, 2); } },
      nose: (t, s) => { t.to(150, { cross: 0, ly: 0.2 }, 'io'); sniff(t, 2); tasteHeart(t); },
      eye: (t, s) => { eyeRub(t, s); },
      cheek: (t, s) => { leanIn(t, s); },
      belly: (t, s) => { tickle(t, u => swing(u, 900, 3, { tilt: 8, x: 2 }, 'io')); },
      side: (t, s) => { const d = -s; t.to(420, { x: d * 6, tilt: d * 24, wide: 0.6 }, 'io').to(380, { tilt: d * 18 }, 'io').to(520, { x: 0, tilt: -d * 3, wide: 0 }, 'io').to(260, { tilt: 0 }, 'io'); giggle(t, 2); }, // rolls away like a wheel and rolls back
      foot: (t, s) => { hop(t, 6, [['emit', 'sprinkle', 'head', 4]]); },
      tail: (t, s) => { t.e('emit', 'sprinkle', 'body', 3); lookBack(t); },
    },
    frybo: { // box of fries: the fries flick and rustle, salt flies
      head: (t, s) => { t.to(120, { earL: 12, earR: 12, fw: 0.6 }, 'o').to(160, { earL: -16, earR: -16, sq: -0.1 }, 'o').e('emit', 'salt', 'head', 5).to(240, { earL: 3, earR: 3, sq: 0.03 }, 'io').to(240, { earL: 0, earR: 0, sq: 0, fw: 0 }, 'io'); giggle(t, 2); },
      ear: (t, s) => { const a = t.t; t.to(500, { fw: 1.3 }, 'io').to(500, { fw: 0 }, 'io'); para(t, a, u => { see(u, 'ear', s, 120); unsee(u); }); giggle(t, 2); },
      nose: (t, s) => { t.to(150, { cross: 0, ly: 0.2 }, 'io'); sniff(t, 3); t.to(260, { hap: 1, smile: 1, open: 0.3, ly: 0 }, 'io').wait(300).to(220, { hap: 0, smile: 0, open: 0 }, 'io'); },
      eye: (t, s) => { eyeRub(t, s); },
      cheek: (t, s) => { leanIn(t, s, { earL: -s * 6, earR: -s * 6 }); },
      belly: (t, s) => { tickle(t, u => u.to(500, { fw: 1 }, 'io').to(500, { fw: 0 }, 'io')); },
      side: (t, s) => { const a = t.t; t.to(300, { earL: -s * 14, earR: -s * 14 }, 'io').to(300, { earL: s * 6, earR: s * 6 }, 'io').to(300, { earL: 0, earR: 0 }, 'io'); para(t, a, u => { see(u, 'side', s, 200); unsee(u, 300); }); },
      foot: (t, s) => { hop(t, 7, [['emit', 'salt', 'head', 4]]); },
      tail: (t, s) => { t.osc(420, 3, { earL: 5, earR: -5 }, { earL: -5, earR: 5 }, 'io').to(150, { earL: 0, earR: 0 }, 'io'); lookBack(t); },
    },
    bunbun: { // burger: the layers fan, shuffle and lift apart
      head: (t, s) => { t.to(120, { sq: 0.2, fan: 0.3 }, 'o').e('emit', 'note', 'head', 1).to(160, { sq: -0.08, split: 0.5, fan: 0 }, 'o').to(300, { sq: 0, split: 0 }, 'io'); giggle(t, 2); },
      ear: (t, s) => { see(t, 'ear', s, 100); t.to(240, { fan: s * 0.9 }, 'o').to(260, { fan: -s * 0.3 }, 'io').to(240, { fan: 0 }, 'io'); unsee(t); },
      nose: (t, s) => { t.to(150, { cross: 0, ly: 0.2 }, 'io'); sniff(t, 2); tasteHeart(t); },
      eye: (t, s) => { eyeRub(t, s); },
      cheek: (t, s) => { leanIn(t, s); },
      belly: (t, s) => { tickle(t, u => u.osc(900, 3, { shuf: 0.6 }, { shuf: -0.6 }, 'io').to(150, { shuf: 0 }, 'io')); },
      side: (t, s) => { t.to(200, { shuf: -s * 0.9, wide: 0.5 }, 'o'); see(t, 'side', s, 100); t.to(300, o(both(9, 2), { shuf: -s * 0.4 }), 'io').to(300, o(NOHANDS, { shuf: 0, wide: 0 }), 'io'); unsee(t, 300); }, // the layers slide, he pushes them back in line
      foot: (t, s) => { jump(t, { h: 7, ant: 140, up: 200, c: 0.14, arm: 40, air: { split: 0.5 }, fall: { split: 0 } }); },
      tail: (t, s) => { t.to(160, { split: 0.4 }, 'o').to(260, { split: 0 }, 'io'); lookBack(t); },
    },
    choco: { // chocolate bar: snaps stiff, melts a little at a warm finger
      head: (t, s) => { t.to(80, { tw: 1.2 }, 'o').e('emit', 'spark', 'head', 2).wait(200).to(300, { tw: 0 }, 'io'); giggle(t, 1); },
      ear: (t, s) => { if (s > 0) { see(t, 'ear', s, 100); t.to(220, { frown: 0.4, puff: 0.3 }, 'io'); armUp(t, 1, 2, 132); unsee(t); t.to(250, { frown: 0, puff: 0, hap: 1, smile: 1 }, 'io').wait(200); }
        else { t.to(80, { tw: 1 }, 'o').wait(150).to(300, { tw: 0 }, 'io'); see(t, 'ear', s, 150); unsee(t); } },
      nose: (t, s) => { t.to(150, { cross: 0, ly: 0.2 }, 'io').to(700, { melt: 0.45, blush: 0.8, sq: 0.05, close: 0.4 }, 'io').wait(300).to(140, { melt: 0, sq: -0.05, tw: 1, close: 0 }, 'o').to(300, { sq: 0, tw: 0, blush: 0, ly: 0 }, 'io'); }, // melts at your warm finger, blushes, firms up
      eye: (t, s) => { eyeRub(t, s); },
      cheek: (t, s) => { leanIn(t, s, { melt: 0.3 }); t.to(250, { melt: 0 }, 'io'); },
      belly: (t, s) => { tickle(t, u => u.to(600, { melt: 0.5 }, 'io').to(400, { melt: 0 }, 'io')); },
      side: (t, s) => { jelly(t, 3, 2, 300, 'bend'); t.to(80, { tw: 1 }, 'o').to(300, { tw: 0 }, 'io'); see(t, 'side', s, 200); unsee(t, 300); },
      foot: (t, s) => { hop(t, 5); },
      tail: (t, s) => { t.to(200, { wrap: 0.35 }, 'o').to(260, { wrap: 0.1 }, 'io'); lookBack(t, 250); t.to(260, { wrap: 0 }, 'io'); },
    },
    scoop: { // strawberry ice cream: the cherry bobs and pops, cold shivers
      head: (t, s) => { t.to(150, { chy: 1 }, 'o').to(280, { chy: 0 }, 'i'); see(t, 'head', s, 150); unsee(t); giggle(t, 2); },
      ear: (t, s) => { see(t, 'ear', s, 100); t.osc(600, 3, { chb: 1, htilt: s * 3 }, { chb: 0, htilt: 0 }, 'io'); unsee(t); },
      nose: (t, s) => { t.to(150, { cross: 0, ly: 0.2 }, 'io'); lick(t, 2); t.to(150, { close: 0.4 }, 'io'); shake(t, { P: 70, env: [0.5, 1, 0.7, 0.35], head: 0.1, roll: 2, ear: 0, body: 0.5 }); t.to(260, { close: 0, hap: 1, smile: 1, ly: 0 }, 'io').wait(200); }, // licks: brr, cold!
      eye: (t, s) => { eyeRub(t, s); },
      cheek: (t, s) => { leanIn(t, s, { chb: 0.6 }); t.to(200, { chb: 0 }, 'io'); },
      belly: (t, s) => { tickle(t, u => u.osc(900, 4, { chb: 1 }, { chb: 0 }, 'io')); },
      side: (t, s) => { const d = -s; t.to(260, { tilt: d * 9, chb: 1 }, 'o').to(320, { tilt: -d * 4, chb: 0.3 }, 'io').to(300, { tilt: 0, chb: 0 }, 'io'); see(t, 'side', s, 200); unsee(t, 300); },
      foot: (t, s) => { jump(t, { h: 5, ant: 140, up: 180, c: 0.12, arm: 35, air: { chy: 0.6 }, fall: { chy: 0 } }); },
      tail: (t, s) => { t.osc(360, 2, { chb: 1 }, { chb: 0 }, 'io'); lookBack(t); },
    },
    boba: { // bubble tea: the straw pops up, pearls swirl and jump
      head: (t, s) => { t.to(90, { sup: 1.1, pop: 1.6 }, 'o').wait(200).to(400, { sup: 0, pop: 0 }, 'io'); giggle(t, 2); },
      ear: (t, s) => { see(t, 'ear', s, 100); if (s > 0) t.to(500, { stw: 1.6 }, 'io').to(400, { stw: 0 }, 'io'); else t.to(400, { swirl: -1.5 }, 'io').to(400, { swirl: 0 }, 'io'); unsee(t); if (s > 0) giggle(t, 2); },
      nose: (t, s) => { t.to(150, { cross: 0, ly: 0.2 }, 'io').to(300, { slurp: 1, mw: 0.5 }, 'io').wait(700).to(200, { slurp: 0, mw: 1 }, 'io').e('gulp'); t.to(260, { hap: 1, smile: 1, swirl: 1.2, ly: 0 }, 'io').wait(400).to(300, { hap: 0, smile: 0, swirl: 0 }, 'io'); }, // takes a sip
      eye: (t, s) => { eyeRub(t, s); },
      cheek: (t, s) => { leanIn(t, s, { swirl: s * 1 }); t.to(200, { swirl: 0 }, 'io'); },
      belly: (t, s) => { tickle(t, u => u.to(300, { pop: 1.4, swirl: 1.5 }, 'o').to(700, { pop: 0, swirl: 0 }, 'io')); },
      side: (t, s) => { t.to(300, { swirl: -s * 2.2 }, 'o').to(500, { swirl: s * 0.8 }, 'io').to(400, { swirl: 0 }, 'io'); see(t, 'side', s, 150); unsee(t, 300); }, // the pearls slosh away and back
      foot: (t, s) => { jump(t, { h: 6, ant: 140, up: 190, c: 0.12, arm: 35, air: { pop: 1.5 }, fall: { pop: 0 } }); },
      tail: (t, s) => { t.to(300, { swirl: 1.5 }, 'io').to(300, { swirl: 0 }, 'io'); lookBack(t); },
    },
    chefbun: { // tiny chef: his hat tips, he tastes, dusts off flour
      head: (t, s) => { t.to(300, o(both(-4, -30), { armL: 150, armR: 150, close: 0.6 }), 'io').osc(500, 2, { armL: 140, armR: 140 }, { armL: 154, armR: 154 }, 'io').to(320, o(NOHANDS, { armL: 0, armR: 0, close: 0 }), 'io'); happy(t, 1); }, // straightens his hat
      ear: (t, s) => { const k = S(s); see(t, 'ear', s, 80); t.to(260, { [k.ear]: -18 }, 'o'); armUp(t, s, 1, 145, { [k.ear]: 0 }); unsee(t); }, // the hat tips, he sets it straight
      nose: (t, s) => { t.to(150, { cross: 0, ly: 0.2 }, 'io'); lick(t, 1); t.to(400, { close: 0.85, htilt: 6, pitch: 0.1 }, 'io').wait(300).to(140, { open: 0.3, mw: 0.5 }, 'o').to(260, { armR: 80, open: 0.2, mw: 1, close: 0, htilt: 0, pitch: 0, hap: 1, smile: 1, ly: 0 }, 'o').e('emit', 'spark', 'pawR', 3).wait(250).to(300, { armR: 0, hap: 0, smile: 0, open: 0 }, 'io'); }, // tastes, thinks, chef's kiss
      eye: (t, s) => { eyeRub(t, s); },
      cheek: (t, s) => { leanIn(t, s); },
      belly: (t, s) => { t.e('emit', 'dust', 'body', 2); tickle(t); },
      side: (t, s) => { jelly(t, 3, 2, 300, 'bend'); t.e('emit', 'dust', 'body', 2); const k = S(s); t.to(260, { [k.arm]: 40 }, 'io').osc(500, 2, { [k.arm]: 20 }, { [k.arm]: 40 }, 'io').to(260, { [k.arm]: 0 }, 'io'); }, // dusts the flour off
      foot: (t, s) => { hop(t, 5, [['emit', 'dust', 'footL', 2], ['emit', 'dust', 'footR', 2]]); },
      tail: (t, s) => { t.e('emit', 'dust', 'body', 2); lookBack(t); },
    },
  };

  // ---------- page labels + descriptions ----------
  const TXT = {
    mallow: { head: 'Squashes like a marshmallow, rises back slowly, giggles.', ear: 'Looks up at the dent and puffs back out.', nose: 'Licks your finger: sweet! A heart.', eye: 'Blinks hard and rubs the eye with a paw.',
      cheek: 'Leans into your finger, soft as a pillow.', belly: 'Ticklish: giggles, wobbling all over.', side: 'Wobbles like jelly, looks at the spot, walks back.', foot: 'Looks down at the foot, a tiny bounce.', tail: 'A soft wobble, looks over the shoulder.' },
    bao: { head: 'Steam puffs out of his knot, he giggles.', ear: 'His pleats wiggle, a little steam.', nose: 'Sniffs your finger, a warm steamy smile.', eye: 'Blinks and rubs his eye.',
      cheek: 'Leans in, his doughy cheek squishing.', belly: 'Doughy belly wobbles, he giggles, steam.', side: 'Wobbles like soft dough, a puff of steam.', foot: 'A little hop, steam puffs.', tail: 'Steam puffs, he looks back.' },
    dunkie: { head: 'Sprinkles bounce off his icing, he looks up, giggles.', ear: s => s > 0 ? 'Ouch, his bite mark! Reaches up and rubs it, then smiles.' : 'Looks up at the poke and giggles.', nose: 'Sniffs your finger and gives it a lick.', eye: 'Blinks and rubs his eye.',
      cheek: 'Leans into your finger.', belly: 'Rocks with giggles like a rolling wheel.', side: 'Rolls away like a wheel, rolls back, giggles.', foot: 'Hops, sprinkles fly.', tail: 'Sprinkles drop off, he looks back.' },
    frybo: { head: 'His fries squash down and spring back up, salt flies.', ear: 'The fries flick, all of them wave, he giggles.', nose: 'Sniffs your finger, hoping for ketchup, and grins.', eye: 'Blinks and rubs his eye.',
      cheek: 'Leans in, his fries tipping with him.', belly: 'Giggles, his fries rustling.', side: 'His fries sway over and back, he looks at the spot.', foot: 'Hops, salt sprinkles out.', tail: 'His fries shiver, he looks back.' },
    bunbun: { head: 'Top bun pressed down: a cheesy squeak, his layers pop apart and back.', ear: 'His top bun tips and the layers fan out and settle.', nose: 'Sniffs and licks: a little cheesy! A heart.', eye: 'Blinks and rubs his eye.',
      cheek: 'Leans into your finger.', belly: 'Ticklish: his layers shuffle as he giggles.', side: 'His layers slide sideways, he pushes them back in line.', foot: 'Hops, his layers lifting apart and back.', tail: 'His layers lift a little, he looks back.' },
    choco: { head: 'Snap! His segments flash, he stays firm, a giggle.', ear: s => s > 0 ? 'Ouch, his bite mark! Reaches up and rubs it.' : 'His segments flash, he looks up.', nose: 'Your warm finger makes him melt a little and blush, then he firms up.', eye: 'Blinks and rubs his eye.',
      cheek: 'Leans in and goes a little melty.', belly: 'Giggles and goes gooey.', side: 'Wobbles, then snaps back stiff.', foot: 'A crisp little hop.', tail: 'His wrapper crinkles, he looks back.' },
    scoop: { head: 'His cherry pops up and lands back, he giggles.', ear: 'His cherry bobs side to side.', nose: 'Licks your finger - brr, cold! - a shiver.', eye: 'Blinks and rubs his eye.',
      cheek: 'Leans in, his cherry bobbing.', belly: 'Giggles, cherry bopping.', side: 'Wobbles on his cone, cherry bobbing, looks.', foot: 'A little hop, the cherry lifts.', tail: 'Cherry bobs, he looks back.' },
    boba: { head: 'His straw pops up and the pearls jump, he giggles.', ear: s => s > 0 ? 'His straw wiggles, he giggles.' : 'His pearls swirl round.', nose: 'Takes a sip through his straw, gulp, pearls swirl happily.', eye: 'Blinks and rubs his eye.',
      cheek: 'Leans in, his pearls drifting over.', belly: 'Pearls pop and swirl as he giggles.', side: 'The pearls slosh away and back.', foot: 'A hop, the pearls jump.', tail: 'Pearls swirl, he looks back.' },
    chefbun: { head: 'Holds his chef hat and straightens it.', ear: 'His hat tips, he reaches up and sets it straight.', nose: "Tastes your finger, thinks about it, chef's kiss.", eye: 'Blinks and rubs his eye.',
      cheek: 'Leans into your finger.', belly: 'Giggles in a puff of flour.', side: 'Wobbles and dusts the flour off.', foot: 'A little hop, flour puffs.', tail: 'A puff of flour, he looks back.' },
  };
  build(RE, TXT, BODY);
})();
