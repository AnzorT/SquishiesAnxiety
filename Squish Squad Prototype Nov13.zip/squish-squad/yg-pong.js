// Yard Mini Games: PING-PONG (the backyard's Outdoor Ping-Pong Table). You (from behind) vs a creature across the table. Slide your finger
// left / right to move the paddle; where the ball meets the paddle (and how fast you're moving) angles the return. Rallies speed up.
// First to 7. Score = 10 a point won + 5 x your longest rally + 50 for the win.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add || !YG.cam) return setTimeout(go, 30); const { S, D, cl, lerp, r2, track, SFX } = YG;
  const ICON = '<svg viewBox="0 0 120 84" aria-hidden="true"><rect width="120" height="84" fill="#9fdc6e"/><path d="M22 70L38 22H82L98 70Z" fill="#2f6fc0"/><path d="M22 70H98V75H22Z" fill="#245a9e"/>' +
    '<path d="M60 22V70M24 64L96 64M37 25H83" stroke="#fff" stroke-width="1.6" opacity="0.9"/><path d="M29 47H91" stroke="#e9eef5" stroke-width="5"/><path d="M29 44H91" stroke="#3a3a44" stroke-width="1"/>' +
    '<circle cx="40" cy="62" r="7" fill="#e8483c"/><rect x="38.5" y="67" width="3" height="7" rx="1.5" fill="#8a5a34"/><circle cx="80" cy="28" r="4.6" fill="#3a3a44"/><circle cx="66" cy="38" r="2.4" fill="#fff"/></svg>';
  YG.add({ id: 'pong', name: 'Ping-Pong', item: 'Ping-Pong Table', color: '#2f9e6f', icon: ICON, stars: [100, 160, 220], coinK: 0.25,
    hint: 'Slide left and right to move your paddle · first to 7',
    how: ['Slide your finger left and right to move your paddle.', 'Hit the ball on the paddle\'s edge (or while moving) to angle it.', 'First to 7 wins. Long rallies score extra!'],
    make(ctx) {
      const { bg, fg, W, H } = ctx, P = YG.cam(1.4, 2.6, 60, 348), G = 8.2, TW = 0.6, Z0 = 0.55, Z1 = 2.95, ZN = 1.75, TY = 0.76, NH = 0.13, BR = 0.022, ZP = 0.45, ZO = 3.06;
      YG.yard(bg, { hz: 60, trees: false });
      // extra layers: the opponent stands BEHIND the table, you stand in front of it
      const stage = ctx.crl.parentNode, oppL = D('div', { cls: 'yg-layer yg-crl' }), tbl = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      tbl.setAttribute('viewBox', '0 0 ' + W + ' ' + H); tbl.setAttribute('class', 'yg-layer'); tbl.setAttribute('preserveAspectRatio', 'none'); stage.insertBefore(oppL, ctx.crl); stage.insertBefore(tbl, ctx.crl);
      const quad = (pts, a, p) => S('path', Object.assign({ d: 'M' + pts.map(q => { const s = P(q[0], q[1], q[2]); return r2(s[0]) + ' ' + r2(s[1]); }).join('L') + 'Z' }, a), p);
      // patio under the table
      quad([[-1.6, 0, -0.5], [1.6, 0, -0.5], [1.6, 0, 4.2], [-1.6, 0, 4.2]], { fill: '#d9d4cc' }, bg); for (let z = -0.5; z < 4.2; z += 0.5) quad([[-1.6, 0, z], [1.6, 0, z], [1.6, 0, z + 0.015], [-1.6, 0, z + 0.015]], { fill: '#c7c0b4' }, bg);
      for (let x = -1.6; x <= 1.6; x += 0.5) quad([[x, 0, -0.5], [x + 0.015, 0, -0.5], [x + 0.015, 0, 4.2], [x, 0, 4.2]], { fill: '#c7c0b4' }, bg);
      // the table (in its own layer between the two players)
      { const g0 = P(0, 0, (Z0 + Z1) / 2); YG.shadow(tbl, g0[0], g0[1], 0.9 * g0[2], 0.22);
        [[-TW + 0.08, Z0 + 0.15], [TW - 0.08, Z0 + 0.15], [-TW + 0.08, Z1 - 0.15], [TW - 0.08, Z1 - 0.15]].forEach(([x, z]) => { const a = P(x, 0, z), b = P(x, TY - 0.03, z); S('path', { d: 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'L' + r2(b[0]) + ' ' + r2(b[1]), stroke: '#3a3a44', 'stroke-width': r2(0.04 * a[2]), 'stroke-linecap': 'round' }, tbl); });
        quad([[-TW, TY - 0.04, Z0], [TW, TY - 0.04, Z0], [TW, TY, Z0], [-TW, TY, Z0]], { fill: '#245a9e' }, tbl);
        quad([[-TW, TY, Z0], [TW, TY, Z0], [TW, TY, Z1], [-TW, TY, Z1]], { fill: '#2f6fc0' }, tbl);
        const ln = (a, b, w) => { const p = P(a[0], TY + 0.001, a[1]), q = P(b[0], TY + 0.001, b[1]); S('path', { d: 'M' + r2(p[0]) + ' ' + r2(p[1]) + 'L' + r2(q[0]) + ' ' + r2(q[1]), stroke: '#ffffff', 'stroke-width': w, opacity: 0.92 }, tbl); };
        ln([-TW + 0.015, Z0], [-TW + 0.015, Z1], 2.4); ln([TW - 0.015, Z0], [TW - 0.015, Z1], 2.4); ln([-TW, Z0 + 0.01], [TW, Z0 + 0.01], 2.4); ln([-TW, Z1 - 0.01], [TW, Z1 - 0.01], 1.6); ln([0, Z0], [0, Z1], 1.2);
        // shine
        quad([[-TW + 0.1, TY + 0.001, Z0 + 0.15], [-0.05, TY + 0.001, Z0 + 0.15], [-0.25, TY + 0.001, Z1 - 0.2], [-TW + 0.1, TY + 0.001, Z1 - 0.2]], { fill: '#ffffff', opacity: 0.06 }, tbl); }
      const netBack = S('g', {}, tbl), oppPad = S('g', {}, tbl), netFront = S('g', {}, fg), ballSh = S('ellipse', { fill: '#10203a', opacity: 0.3 }, tbl), ballG = S('g', {}, fg), myPad = S('g', {}, fg);
      { const a = P(-TW - 0.06, TY, ZN), b = P(TW + 0.06, TY, ZN), c = P(TW + 0.06, TY + NH, ZN), d = P(-TW - 0.06, TY + NH, ZN);
        S('path', { d: 'M' + [a, b, c, d].map(s => r2(s[0]) + ' ' + r2(s[1])).join('L') + 'Z', fill: '#eef2f8', opacity: 0.55 }, netFront);
        let m = ''; for (let i = 0; i <= 30; i++) { const x = -TW - 0.06 + (2 * TW + 0.12) * i / 30, p = P(x, TY, ZN), q = P(x, TY + NH, ZN); m += 'M' + r2(p[0]) + ' ' + r2(p[1]) + 'L' + r2(q[0]) + ' ' + r2(q[1]); }
        for (let j = 1; j < 4; j++) { const y = TY + NH * j / 4, p = P(-TW - 0.06, y, ZN), q = P(TW + 0.06, y, ZN); m += 'M' + r2(p[0]) + ' ' + r2(p[1]) + 'L' + r2(q[0]) + ' ' + r2(q[1]); }
        S('path', { d: m, stroke: '#3a3a44', 'stroke-width': 0.6, opacity: 0.6 }, netFront); S('path', { d: 'M' + r2(d[0]) + ' ' + r2(d[1]) + 'L' + r2(c[0]) + ' ' + r2(c[1]), stroke: '#ffffff', 'stroke-width': 3 }, netFront);
        [a, b].forEach((s, i) => { const t = [d, c][i]; S('path', { d: 'M' + r2(s[0]) + ' ' + r2(s[1] + 3) + 'L' + r2(t[0]) + ' ' + r2(t[1]), stroke: '#3a3a44', 'stroke-width': 3 }, netFront); }); }
      const ball = S('circle', { r: 5, fill: '#ffffff', stroke: '#e6dccb', 'stroke-width': 0.8 }, ballG), trail = S('path', { fill: 'none', stroke: '#ffffff', 'stroke-width': 3, 'stroke-linecap': 'round', opacity: 0.35 }, ballG);
      function paddle(g, x, y, z, col, tilt) { g.innerHTML = ''; const s = P(x, y, z), r = 0.085 * s[2]; const gg = S('g', { transform: 'translate(' + r2(s[0]) + ' ' + r2(s[1]) + ') rotate(' + r2(tilt || 0) + ')' }, g);
        S('rect', { x: -r * 0.16, y: r * 0.7, width: r * 0.32, height: r * 1.1, rx: r * 0.12, fill: '#a4703f' }, gg); S('ellipse', { cx: 0, cy: 0, rx: r, ry: r * 1.06, fill: col, stroke: '#3a2a20', 'stroke-width': 1 }, gg); S('ellipse', { cx: -r * 0.3, cy: -r * 0.35, rx: r * 0.35, ry: r * 0.22, fill: '#ffffff', opacity: 0.25 }, gg); }
      // players
      const ok = ctx.opponent(), okName = ctx.nameOf(ok), opp = YG.creature(oppL, ok, { yaw: 0 }), me = ctx.creature(ctx.playerKey, { yaw: 180 });
      const scoreTx = D('div', { cls: 'yg-pill', style: 'position:absolute;left:50%;top:12.5%;transform:translateX(-50%);font-size:14px;padding:6px 12px;white-space:nowrap;' }, stage.querySelector('.yg-hud'));
      let px = 0, pxT = 0, pv = 0, ox = 0, oxT = 0, b = null, pts = [0, 0], rally = 0, best = 0, serve = 0, serveN = 0, phase = 'serve', ph0 = 0, tNow = 0, swingP = -9, swingO = -9, side = 0, lastHit = 0, skill = 0.55, trailPts = [];
      const say = () => { scoreTx.textContent = 'You ' + pts[0] + ' – ' + pts[1] + ' ' + okName; ctx.timer(''); };
      function newBall(who) { b = { x: who ? ox : px + 0.04, y: TY + 0.3, z: who ? ZO - 0.02 : ZP + 0.02, vx: 0, vy: 0, vz: 0, bounces: 0, side: -1 }; phase = 'serve'; ph0 = tNow; serve = who; if (!who) ctx.hint('Tap to serve · slide to move'); }
      // send the ball to land on the other half; T = flight time to that bounce
      function send(from, lx, lz) { const T = Math.max(0.34, 0.6 - rally * 0.012) * (from ? 1.05 : 1); b.vx = (lx - b.x) / T; b.vz = (lz - b.z) / T; b.vy = (TY + BR - b.y + 0.5 * G * T * T) / T;
        // net clearance: if it would clip the net, loft it
        const tn = (ZN - b.z) / b.vz; if (tn > 0 && tn < T) { const yn = b.y + b.vy * tn - 0.5 * G * tn * tn; if (yn < TY + NH + BR + 0.03) b.vy += (TY + NH + BR + 0.05 - yn) / tn; }
        b.bounces = 0; b.side = from; lastHit = from; }
      function hitByMe() { const off = (b.x - px) / 0.11, lx = cl(b.x + off * 0.35 + pv * 0.18 + (Math.random() - 0.5) * 0.06, -TW + 0.06, TW - 0.06), lz = 2.25 + Math.random() * 0.5;
        send(0, lx, lz); rally++; swingP = tNow; SFX.pop(); if (rally > 1 && rally % 5 === 0) ctx.toast('Rally ' + rally + '!', W / 2, 200, '#ffe36e'); }
      function hitByOpp() { const away = Math.abs(px) < 0.25 ? (Math.random() < 0.5 ? -1 : 1) : -Math.sign(px), aim = Math.random() < skill * 0.6 ? away * (0.3 + Math.random() * 0.25) : (Math.random() - 0.5) * 0.7;
        send(1, cl(aim, -TW + 0.08, TW - 0.08), 0.8 + Math.random() * 0.55); rally++; swingO = tNow; SFX.tap(); }
      function point(win, why) { if (phase === 'point') return; phase = 'point'; ph0 = tNow; pts[win ? 0 : 1]++; best = Math.max(best, rally); say();
        if (win) { ctx.add(10, W / 2, 240, why || 'Point!', '#ffe36e'); SFX.score(); me.play('happy'); opp.play('surprised'); } else { ctx.toast(why || 'Point ' + okName, W / 2, 240, '#ffffff'); SFX.miss(); opp.play('happy'); }
        rally = 0; skill = cl(0.5 + (pts[0] - pts[1]) * 0.06 + (pts[0] + pts[1]) * 0.015, 0.4, 0.85); }
      const api = {
        start() { pts = [0, 0]; rally = 0; best = 0; serveN = 0; ctx.setScore(0); say(); newBall(0); me.play('idle'); opp.play('idle'); },
        down(p) { pxT = cl((p.x - W / 2) / (P(0, TY, ZP)[2]), -TW - 0.1, TW + 0.1); if (phase === 'serve' && serve === 0 && tNow - ph0 > 300) { phase = 'play'; ctx.hint(''); b.x = px + 0.04; hitByMe(); } },
        move(p) { pxT = cl((p.x - W / 2) / (P(0, TY, ZP)[2]), -TW - 0.1, TW + 0.1); },
        key(k, dn) { if (!dn) return; if (k === 'ArrowLeft') { pxT = cl(pxT - 0.15, -TW - 0.1, TW + 0.1); return true; } if (k === 'ArrowRight') { pxT = cl(pxT + 0.15, -TW - 0.1, TW + 0.1); return true; } if (k === ' ' || k === 'ArrowUp') { api.down({ x: W / 2 + px * P(0, TY, ZP)[2] }); return true; } },
        _state: () => ({ phase, pts: pts.slice(), rally, best, b: b && [b.x, b.y, b.z].map(v => +v.toFixed(2)), px: +px.toFixed(2) }), _aimAt: () => { if (b && b.vz < 0) { const tz = (ZP - b.z) / b.vz; pxT = cl(b.x + b.vx * tz - 0.04, -TW - 0.1, TW + 0.1); } },
        celebrate(st) { me.yaw(0); me.play(st >= 2 ? 'happy' : 'idle'); },
        update(dt, t) { tNow = t; const px0 = px; px += (pxT - px) * (1 - Math.exp(-dt * 16)); pv = (px - px0) / Math.max(dt, 0.001);
          if (b && phase === 'serve' && serve === 1 && t - ph0 > 900) { phase = 'play'; hitByOpp(); }
          if (b && phase === 'serve' && serve === 0) { b.x = px + 0.04; b.y = TY + 0.3 + Math.abs(Math.sin((t - ph0) / 260)) * 0.15; b.z = ZP + 0.02; }
          if (b && (phase === 'play' || phase === 'point')) { const n = 4; for (let i = 0; i < n; i++) { const h = dt / n, pz = b.z; b.vy -= G * h; b.x += b.vx * h; b.y += b.vy * h; b.z += b.vz * h;
              // table bounce
              if (b.y <= TY + BR && b.vy < 0 && Math.abs(b.x) <= TW && b.z >= Z0 && b.z <= Z1) { b.y = TY + BR; b.vy = -b.vy * 0.82; b.bounces++; SFX.tap(); const hs = b.z < ZN ? 0 : 1;
                if (phase === 'play') { if (hs === lastHit) point(lastHit === 1, lastHit === 1 ? 'Fault!' : 'Fault'); else if (b.bounces >= 2) point(hs === 1, hs === 1 ? 'Point!' : null); } }
              // net
              if (phase === 'play' && (pz - ZN) * (b.z - ZN) <= 0 && b.y < TY + NH + BR && Math.abs(b.x) < TW + 0.06) { b.vz = -b.vz * 0.15; b.vx *= 0.3; SFX.thud(); point(lastHit === 1, lastHit === 1 ? 'Net!' : 'Into the net'); }
              if (b.y < BR) { if (phase === 'play' && b.bounces === 0) point(lastHit === 1, lastHit === 1 ? 'Out!' : 'Out'); b.y = BR; b.vy = -b.vy * 0.5; b.vx *= 0.7; b.vz *= 0.7; }
              if (phase === 'play') {
                // my paddle plane
                if (b.vz < 0 && pz >= ZP && b.z < ZP && b.y < TY + 0.75) { if (Math.abs(b.x - px) < 0.13) { if (b.bounces === 1 || b.side === 1 && b.bounces >= 1) hitByMe(); else if (b.bounces === 0) { hitByMe(); } } }
                if (b.z < ZP - 0.35) point(false, null);
                // opponent paddle plane
                if (b.vz > 0 && pz <= ZO && b.z > ZO && b.y < TY + 0.75) { const pMiss = cl(0.05 + rally * 0.012 - (skill - 0.5) * 0.12, 0.03, 0.32); if (Math.abs(b.x - ox) < 0.13 && Math.random() > pMiss) hitByOpp(); else if (Math.abs(b.x - ox) < 0.2) { swingO = tNow; } }
                if (b.z > ZO + 0.4) point(true, 'Point!'); } } }
          if (phase === 'point' && t - ph0 > 1200) { if (pts[0] >= 7 || pts[1] >= 7) { phase = 'done'; const won = pts[0] > pts[1]; if (won) ctx.add(50 + best * 5, W / 2, 260, 'You win! +' + (50 + best * 5), '#ffe36e'); else ctx.add(best * 5); ctx.finish({ title: won ? 'You win!' : okName + ' wins', sub: 'You ' + pts[0] + ' – ' + pts[1] + ' · best rally ' + best, delay: 900 }); }
            else { serveN++; newBall(Math.floor(serveN / 2) % 2); } }
          // opponent AI: track where the ball will cross its plane (late + a little off when it is far)
          if (b && phase === 'play' && b.vz > 0) { const tz = (ZO - b.z) / b.vz, gx = b.x + b.vx * tz, err = (1 - skill) * 0.16 * Math.sin(t / 300 + rally); oxT = cl(gx + err, -TW, TW); } else if (phase !== 'serve' || serve === 0) oxT = lerp(oxT, 0, 1 - Math.exp(-dt * 2));
          const sp = 0.9 + skill * 1.4; ox += cl(oxT - ox, -sp * dt, sp * dt); if (phase === 'serve' && serve === 1) { ox = lerp(ox, 0, 0.1); b.x = ox; b.y = TY + 0.28 + Math.abs(Math.sin((t - ph0) / 240)) * 0.12; b.z = ZO - 0.02; }
          // creatures + paddles
          const sP = t - swingP, sO = t - swingO;
          const EP = Object.assign({ lean: cl(pv * 3, -5, 5) }, sP < 420 ? track([[0, { armR: 40 }], [90, { armR: 150, lean: 4 }], [420, { armR: 60, lean: 0 }]], sP) : { armR: 60, armL: 20 });
          me.pose(EP); { const kx = P(0, TY, ZP)[2]; me.set(W / 2 + (px - 0.2) * kx, 700, 215); me.yaw(196 + cl(pv * 4, -8, 8)); }
          const EO = Object.assign({ lean: 0 }, sO < 420 ? track([[0, { armR: 40 }], [90, { armR: 150 }], [420, { armR: 60 }]], sO) : { armR: 55, armL: 25 }); opp.pose(EO);
          { const fe = P(ox + 0.1, TY, Z1); opp.set(fe[0], fe[1] + 16, 128); }
          paddle(myPad, px, TY + 0.14 + (sP < 300 ? 0.05 * Math.sin(sP / 300 * Math.PI) : 0), ZP, '#e8483c', cl(-pv * 6, -25, 25) + (sP < 300 ? -30 * Math.sin(sP / 300 * Math.PI) : 0));
          paddle(oppPad, ox, TY + 0.14, ZO, '#3a3a44', sO < 300 ? 30 * Math.sin(sO / 300 * Math.PI) : 0);
          if (b) { const s = P(b.x, b.y, b.z), r = Math.max(2.4, BR * s[2]); ball.setAttribute('cx', r2(s[0])); ball.setAttribute('cy', r2(s[1])); ball.setAttribute('r', r2(r));
            const onT = Math.abs(b.x) <= TW && b.z >= Z0 && b.z <= Z1, gy = onT ? TY : 0, g0 = P(b.x, gy, b.z), hk = cl(1 - (b.y - gy) / 1.0, 0.2, 1); ballSh.setAttribute('cx', r2(g0[0])); ballSh.setAttribute('cy', r2(g0[1])); ballSh.setAttribute('rx', r2(r * 1.2 * hk)); ballSh.setAttribute('ry', r2(r * 0.5 * hk)); ballSh.setAttribute('opacity', r2(0.35 * hk));
            trailPts.push([s[0], s[1]]); if (trailPts.length > 6) trailPts.shift(); trail.setAttribute('d', phase === 'play' ? 'M' + trailPts.map(q => r2(q[0]) + ' ' + r2(q[1])).join('L') : ''); }
        },
        destroy() { opp.destroy(); oppL.remove(); tbl.remove(); } };
      newBall(0); say(); return api;
    } });
  }; go();
})();
