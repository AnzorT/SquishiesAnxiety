// Renovation Catalog round 6: Arcade, Dance & Audio Lounge overhaul.
// Neon pinball (playfield, flippers, bumpers, backglass + live game), dance-rhythm cabinet (screen, marquee, 2 lit pads), glow billiards / air-hockey table
// (2-creature games), oscillating bubble fan, fog machines by tier, obsidian bass reactors + mist matrix, DJ booths with a creature playing, modern microwave.
// Creature players: RD.draw(...).players = [{ x, y (viewBox), v: front|back|left|right, a: act, b: behind item, d: phase }].
// Fog: RD.draw(...).fog = { t: tier, style, tint, pts, dir, fl, cf } -> ClubFog (club-fx.js). Sets RenoDraw.PLUS5; catalog edit layer RD.SET5.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS4 && RD.H3 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS5) return;
  const K = X.K, { solid, box, cyl, ball, slab, slabX, arcW, disc, prism, prismZ, shade, mix, f1 } = K;
  const { rep, rng, n4, P2, mtx, plane, planeH, an, atS, BLUR, bbOf, mt, wd, cer, pt } = RD.H3;
  const N = RD.N, em = RD.H.em, PI = Math.PI, SA = X.SA, CA = X.CA, CH = '#d5dde2', GOLD = '#e2b14a', TI = '#b8bcc4', CG = '#cdb48a', OB = '#141318', OB2 = '#211f28';
  const B = b => b ? ' begin="' + n4(b) + 's"' : '';
  const anK = (a, v, d, kt, b, dis) => '<animate attributeName="' + a + '" values="' + v + '" keyTimes="' + kt + '" dur="' + n4(d) + 's"' + (dis ? ' calcMode="discrete"' : '') + B(b) + ' repeatCount="indefinite"/>';
  const anD = (a, v, d, b) => '<animate attributeName="' + a + '" values="' + v + '" dur="' + n4(d) + 's" calcMode="discrete"' + B(b) + ' repeatCount="indefinite"/>';
  const atK = (t, v, d, kt, b) => '<animateTransform attributeName="transform" type="' + t + '" values="' + v + '" keyTimes="' + kt + '" dur="' + n4(d) + 's"' + B(b) + ' repeatCount="indefinite"/>';
  const atL = (t, v, d, b) => '<animateTransform attributeName="transform" type="' + t + '" values="' + v + '" dur="' + n4(d) + 's"' + B(b) + ' repeatCount="indefinite"/>';
  const surf = (p, O, U, V) => mtx(p(O[0], O[1], O[2]), p(O[0] + U[0], O[1] + U[1], O[2] + U[2]), p(O[0] + V[0], O[1] + V[1], O[2] + V[2]));
  const isPlay = S => /play/.test(S.st || ''), isOn = S => /(^|\|)(on|play)$/.test(S.st || ''), modeOf = S => (S.st || '').split('|')[0];
  const kts = a => a.map(n4).join(';'), pts = a => a.map(q => f1(q[0]) + ' ' + f1(q[1])).join(';');
  const G = (id, stops, o) => '<' + (o && o.r ? 'radialGradient' : 'linearGradient') + ' id="' + id + '"' + (o && o.a ? ' ' + o.a : '') + '>' + stops.map(s => '<stop offset="' + s[0] + '" stop-color="' + s[1] + '"' + (s[2] != null ? ' stop-opacity="' + s[2] + '"' : '') + '/>').join('') + '</' + (o && o.r ? 'radialGradient' : 'linearGradient') + '>';
  const glowL = (d, c, w, f) => '<path d="' + d + '" fill="none" stroke="' + c + '" stroke-width="' + f1(w * 4.2) + '" stroke-linecap="round" stroke-linejoin="round" opacity="0.14"/><path d="' + d + '" fill="none" stroke="' + c + '" stroke-width="' + f1(w * 2.6) + '" stroke-linecap="round" stroke-linejoin="round" opacity="0.26"/><path d="' + d + '" fill="none" stroke="' + c + '" stroke-width="' + f1(w) + '" stroke-linecap="round" stroke-linejoin="round"/><path d="' + d + '" fill="none" stroke="#ffffff" stroke-width="' + f1(w * 0.35) + '" stroke-linecap="round" stroke-linejoin="round" opacity="0.85"/>';
  const polyD = a => 'M' + a.map(P2).join('L');
  // event flashes: values/keyTimes that hold `lo`, jump to `hi` at each fraction and ease back within w
  const flash = (fs, lo, hi, w) => { const q = [[0, lo]]; fs.slice().sort((a, b) => a - b).forEach(f => { const a = Math.max(q[q.length - 1][0] + 0.002, f - 0.003), b = a + 0.003, c = Math.min(0.998, b + w); if (c <= b + 0.001) return; q.push([a, lo], [b, hi], [c, lo]); }); q.push([1, lo]); return { v: q.map(x => x[1]).join(';'), kt: q.map(x => n4(x[0])).join(';') }; };
  const plen = P => { const L = [0]; for (let i = 1; i < P.length; i++) L.push(L[i - 1] + Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1])); return L.map(l => l / L[L.length - 1]); };
  // creature players (model coords); behind = drawn under the item image
  const PL = {
    pinball5: [{ x: 88, z: 2, v: 'left', a: 'pin' }],
    danceCab: [{ x: -42, z: 62, v: 'back', a: 'dance' }, { x: 42, z: 62, v: 'back', a: 'dance', d: 0.5 }],
    glowTable: st => /bill/i.test(st) ? [{ x: -106, z: -2, v: 'right', a: 'watch', b: 1 }, { x: 106, z: 4, v: 'left', a: 'pool' }] : [{ x: -106, z: -2, v: 'right', a: 'hockey', b: 1 }, { x: 106, z: 4, v: 'left', a: 'hockey', d: 0.5 }],
    djBooth: [{ x: 0, z: -44, v: 'front', a: 'dj', b: 1 }],
  };
  const plOf = (k, st) => { const L = PL[k]; return typeof L === 'function' ? L(st || '') : L; };
  const plBB = (p, L) => [].concat(...L.map(o => { const q = p(o.x, 0, o.z); return [[q[0] - 40, q[1] - 74], [q[0] + 40, q[1] + 6]]; }));
  const PAW = '<radialGradient id="pwG" cx="38%" cy="32%" r="70%"><stop offset="0" stop-color="#ffd9a8"/><stop offset="0.55" stop-color="#eba45e"/><stop offset="1" stop-color="#b8692c"/></radialGradient>';
  const pawS = k => '<ellipse cx="0" cy="' + f1(1.4 * k) + '" rx="' + f1(5.8 * k) + '" ry="' + f1(3 * k) + '" fill="#000000" opacity="0.2"/><ellipse rx="' + f1(5.4 * k) + '" ry="' + f1(4.2 * k) + '" fill="url(#pwG)" stroke="#a35a24" stroke-width="' + f1(0.35 * k) + '"/>'
    + [[-3.1, -2.7], [0, -3.5], [3.1, -2.7]].map(([x, y]) => '<circle cx="' + f1(x * k) + '" cy="' + f1(y * k) + '" r="' + f1(1.55 * k) + '" fill="url(#pwG)" stroke="#a35a24" stroke-width="' + f1(0.3 * k) + '"/>').join('') + '<ellipse cx="' + f1(-1.4 * k) + '" cy="' + f1(-1.2 * k) + '" rx="' + f1(1.6 * k) + '" ry="' + f1(1 * k) + '" fill="#ffffff" opacity="0.45"/>';

  // ======================= NEON PINBALL MACHINE =======================
  N.pinball5 = S => { const play = isPlay(S), BODY = '#1d1538', TRIM = '#2e2452', NP = '#ff4fb8', NC = '#3ff0ff', NY = '#ffe14f', TT = 4.2;
    const yT = x => 57 - (x + 59) * 8 / 118, PF = p => surf(p, [-59, 57.3, 0], [1, -8 / 118, 0], [0, 0, 1]);
    const BUMP = [[30, -7, '#ff4f6a'], [30, 8, '#ffd84f'], [44, 0.5, '#3fb8ff']];
    const BALL = [[105, -4.2], [64, -13], [47, -5.8], [37, 0.6], [27, 13.4], [17, 3], [36, 15.6], [79, 17.4], [99.5, 6], [58, 9], [26, -15.4], [14, -5], [33, 1.8], [74, -17], [105, -4.2]], FB = plen(BALL);
    const D = { w: 150, d: 64 };
    D.build = P => { const o = [];
      [[50, 33.4], [-50, 37.4]].forEach(([x, h]) => [-21, 21].forEach(z => o.push(cyl(x, 0, z, 3.6, 1.6, '#26262c', mt({ n: 12 })), cyl(x, 1.6, z, 2, h - 5.2, CH, mt({ n: 10, shine: 1 })), box(x, h - 3.8, z, 6.4, 4, 6.4, CH, mt({ r: 1, shine: 1 })))));
      o.push(prismZ(-25, 25, [[59, 33], [59, 49], [-59, 57], [-59, 37]], BODY, pt()));
      o.push(slabX(59.5, 34.5, 0, 1.2, 11, 24, '#2c2c34', mt({ r: 1 })), slabX(60.2, 41.4, -5, 0.5, 3, 2.2, NY, em({ r: 0.4 })), slabX(60.2, 41.4, 5, 0.5, 3, 2.2, NY, em({ r: 0.4 })), slabX(60.2, 36.4, 0, 0.5, 1.8, 12, '#70758a', mt({ r: 0.4 })));
      o.push(solid({ ax: 'x', sh: 'el', c: [-17, 45.6], a: 0.9, b: 0.9, n: 8, rings: [[59, 0], [64.5, 0]], col: CH, mat: 'metal', shine: 1 }), ball(66, 45.6, -17, 2.1, '#e8343c', { k: 4, n: 10, shine: 1 }));
      o.push(disc(52, 43.2, 25, 1.9, 1.3, NP, em({ n: 12 })));
      o.push(box(-55.6, 55.4, 0, 8, 3.4, 48, CH, mt({ r: 1, shine: 1 })), box(-56, 58.6, 0, 10, 50, 54, BODY, pt({ r: 2 })), box(-56, 108.6, 0, 11.4, 2.6, 55.4, TRIM, mt({ r: 1 })));
      return o; };
    const field = p => { let f = '<g transform="' + PF(p) + '"><g clip-path="url(#pbClip)">';
      f += '<rect x="8" y="-23.4" width="107.5" height="46.8" fill="url(#pbF)"/><circle cx="62" cy="0" r="36" fill="url(#pbGl)"/>';
      f += rep(12, i => { const a = i * PI / 6; return '<path d="M62 0L' + f1(62 + Math.cos(a - 0.09) * 60) + ' ' + f1(Math.sin(a - 0.09) * 60) + 'L' + f1(62 + Math.cos(a + 0.09) * 60) + ' ' + f1(Math.sin(a + 0.09) * 60) + 'Z" fill="#ffffff" opacity="0.06"/>'; }).join('');
      f += rep(26, i => { const R2 = rng('pbs' + i); return '<circle cx="' + f1(10 + R2() * 100) + '" cy="' + f1(-22 + R2() * 44) + '" r="' + f1(0.25 + R2() * 0.4) + '" fill="#ffffff" opacity="0.6"/>'; }).join('') + '</g>';
      f += '<path d="M40 -23 Q11 -23 11 0 Q11 23 40 23" fill="none" stroke="#d5dde2" stroke-width="1.3"/><path d="M24 -18.6H110" stroke="#d5dde2" stroke-width="1"/>';
      [-10, -2, 6, 14].forEach(b => f += '<path d="M15 ' + b + 'H23" stroke="#d5dde2" stroke-width="0.9" stroke-linecap="round"/>');
      [-6, 2, 10].forEach((b, i) => f += '<circle cx="19" cy="' + b + '" r="1.4" fill="' + NY + '">' + anD('opacity', i === 0 ? '1;0.25;0.25' : i === 1 ? '0.25;1;0.25' : '0.25;0.25;1', play ? 0.6 : 1.5) + '</circle>');
      rep(4, i => f += '<path d="M' + (60 + i * 6) + ' 0l4.2 -2.8v5.6Z" fill="' + [NP, NC, NY, '#7dff6a'][i] + '" stroke="#ffffff" stroke-width="0.25">' + anD('opacity', rep(4, j => j === 3 - i ? 1 : 0.22).join(';'), play ? 0.5 : 1.4) + '</path>');
      [[72, 12], [72, -12]].forEach(([a, b], i) => f += '<path d="M' + a + ' ' + (b - 3) + 'l0.9 2.1 2.2 0.2-1.7 1.4 0.6 2.2-2-1.2-2 1.2 0.6-2.2-1.7-1.4 2.2-0.2z" fill="' + (i ? NC : NP) + '">' + an('opacity', '1;0.3;1', 1.1, -i * 0.5) + '</path>');
      BUMP.forEach(([a, b, c], j) => { const hits = BALL.map((q, i) => Math.hypot(q[0] - a, q[1] - b) < 9.5 ? FB[i] : -1).filter(x => x >= 0), F = flash(hits, 0.15, 1, 0.08);
        f += '<circle cx="' + a + '" cy="' + b + '" r="7.4" fill="' + c + '" opacity="0.15">' + (play ? anK('opacity', F.v, TT, F.kt) : an('opacity', '0.1;0.35;0.1', 1.6, -j * 0.5)) + '</circle>'
          + '<circle cx="' + (a + 0.6) + '" cy="' + (b + 0.6) + '" r="5" fill="#000000" opacity="0.35"/><circle cx="' + a + '" cy="' + b + '" r="4.7" fill="#f2f2f6" stroke="#8a8fa0" stroke-width="0.4"/><circle cx="' + a + '" cy="' + b + '" r="3.4" fill="' + c + '" stroke="' + shade(c, 0.6) + '" stroke-width="0.4"/><circle cx="' + (a - 1) + '" cy="' + (b - 1) + '" r="1.1" fill="#ffffff" opacity="0.75"/>'; });
      [1, -1].forEach(sg => { f += '<path d="M80 ' + 19.5 * sg + 'L94 ' + 13 * sg + 'L82 ' + 13.4 * sg + 'Z" fill="' + (sg > 0 ? NP : NC) + '" stroke="#ffffff" stroke-width="1.1" stroke-linejoin="round"/><path d="M84 ' + (sg > 0 ? 22 : -18) + 'L96.6 ' + 16.4 * sg + '" stroke="#d5dde2" stroke-width="1.1" stroke-linecap="round"/>'; });
      f += '<path d="M108 -18.6H115.5V23.4H108Z" fill="#241a48"/><path d="M108 -18.6V-6L103 -2.6M108 23.4V8L103 4.4" fill="none" stroke="#d5dde2" stroke-width="0.8"/>';
      const flip = (px, pz, rest, up, fs) => { const F = flash(fs, rest, up, 0.06);
        return '<g transform="translate(' + px + ' ' + pz + ')"><g transform="rotate(' + rest + ')">' + (play ? '<animateTransform attributeName="transform" type="rotate" values="' + F.v + '" keyTimes="' + F.kt + '" dur="' + TT + 's" repeatCount="indefinite"/>' : '')
          + '<path d="M0.4 -1.9A2.3 2.3 0 0 0 0.4 2.7L12 1.7A1.1 1.1 0 0 0 12 -0.5Z" fill="#000000" opacity="0.3"/><path d="M0 -2.3A2.3 2.3 0 0 0 0 2.3L11.6 1.1A1.1 1.1 0 0 0 11.6 -1.1Z" fill="#f6f6f2" stroke="' + NP + '" stroke-width="0.7"/><circle r="0.9" fill="#c9ccd6"/></g></g>'; };
      f += flip(96, 15, -51, -93, [FB[8]]) + flip(96, -15, 51, 93, [0.001]);
      f += play ? '<circle r="1.9" fill="url(#pbBl)" stroke="#6a6f80" stroke-width="0.2"><animateMotion dur="' + TT + 's" repeatCount="indefinite" path="' + polyD(BALL) + '"/></circle>' : '<circle cx="111.5" cy="-21" r="1.9" fill="url(#pbBl)" stroke="#6a6f80" stroke-width="0.2"/>';
      return f + '</g>'; };
    D.layers = [{ build: P => { const rl = z0 => prismZ(z0, z0 + 2.6, [[59.2, 48.6], [59.2, 51.4], [-51, yT(-51) + 2.6], [-51, yT(-51) - 0.4]], CH, mt({ shine: 1 }));
      return [rl(22.8), rl(-25.4), box(57, 48.4, 0, 4.6, 3.4, 52.4, CH, mt({ r: 1.4, shine: 1 }))]; }, wrap: (p, s) => field(p) + s }];
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      f += '<g transform="' + PF(p) + '"><rect x="8" y="-23" width="107.5" height="46" fill="url(#pbGlass)"/><path d="M14 -21L40 21" stroke="#ffffff" stroke-width="0.5" opacity="0.25"/></g>';
      const FF = (O, U, V) => { const a = p(O[0], O[1], O[2]), b = p(O[0] + U[0], O[1] + U[1], O[2] + U[2]), c2 = p(O[0] + V[0], O[1] + V[1], O[2] + V[2]); return (b[0] - a[0]) * (c2[1] - a[1]) - (b[1] - a[1]) * (c2[0] - a[0]) > 0; };
      const ZS = FF([-59, 0, 25.4], [1, 0, 0], [0, -1, 0]) ? 25.4 : -25.4, BGV = FF([-50.8, 108.2, 25.6], [0, 0, -1], [0, -1, 0]); c.pbZ = ZS; c.pbBG = BGV;
      const SD = surf(p, [-59, 0, ZS], [1, 0, 0], [0, -1, 0]), top = u => -(57 - u * 8 / 118), bot = u => -(37 - u * 4 / 118);
      const band = (a, b) => 'M0 ' + f1(top(0) + a) + 'L118 ' + f1(top(118) + a) + 'L118 ' + f1(top(118) + b) + 'L0 ' + f1(top(0) + b) + 'Z';
      f += '<g transform="' + SD + '"><path d="' + band(2.6, 5.4) + '" fill="' + NP + '">' + (play ? an('opacity', '1;0.55;1', 0.8) : '') + '</path><path d="' + band(6.6, 7.8) + '" fill="' + NC + '">' + (play ? an('opacity', '0.55;1;0.55', 0.8) : '') + '</path>'
        + '<path d="M28 -48l2.4 5.6 6 0.5-4.6 3.9 1.4 5.9-5.2-3.2-5.2 3.2 1.4-5.9-4.6-3.9 6-0.5z" fill="' + NY + '" stroke="#ffffff" stroke-width="0.5"/><path d="M60 -46l-6 7h4l-3 6 8-8h-4l3-5z" fill="' + NC + '"/><circle cx="84" cy="-43" r="1.3" fill="#ffffff" opacity="0.7"/><circle cx="96" cy="-40" r="0.9" fill="#ffffff" opacity="0.6"/>'
        + '<path d="M0 ' + f1(top(0)) + 'L118 ' + f1(top(118)) + 'L118 ' + f1(bot(118)) + 'L0 ' + f1(bot(0)) + 'Z" fill="url(#pbSide)"/></g>';
      const BG = surf(p, [-50.8, 108.2, 25.6], [0, 0, -1], [0, -1, 0]);
      let bg = '<rect x="1.5" y="1.5" width="48.2" height="32" rx="1.5" fill="url(#pbBG)"/>' + rep(18, i => { const R2 = rng('bgs' + i); return '<circle cx="' + f1(3 + R2() * 45) + '" cy="' + f1(3 + R2() * 28) + '" r="' + f1(0.2 + R2() * 0.4) + '" fill="#ffffff">' + an('opacity', '0.3;1;0.3', n4(1 + R2() * 2), -R2() * 2) + '</circle>'; }).join('');
      bg += '<circle cx="39" cy="10" r="5.6" fill="url(#pbPl)"/><ellipse cx="39" cy="10.6" rx="9" ry="2" fill="none" stroke="' + NY + '" stroke-width="0.7" transform="rotate(-14 39 10.6)"/><path d="M9 6l-3 6h3l-2 5 6-7h-3l2-4z" fill="' + NY + '"/>';
      bg += '<text x="25.6" y="25.4" text-anchor="middle" font-family="Arial Black, Arial, sans-serif" font-weight="900" font-style="italic" font-size="8.2" fill="' + NP + '" filter="url(#pbBl2)" opacity="0.9">STAR BALL' + (play ? anD('opacity', '0.9;0.4', 0.5) : '') + '</text><text x="25.6" y="25.4" text-anchor="middle" font-family="Arial Black, Arial, sans-serif" font-weight="900" font-style="italic" font-size="8.2" fill="#ffffff" stroke="' + NP + '" stroke-width="0.45">STAR BALL</text>';
      bg += '<rect x="5" y="36" width="41.4" height="10.6" rx="0.8" fill="#140900" stroke="#3a2a10" stroke-width="0.5"/>';
      const dmd = (t, op) => '<text x="25.7" y="43.6" text-anchor="middle" font-family="Courier New, monospace" font-weight="700" font-size="5.4" fill="#ff9a2e" opacity="' + op + '">' + t;
      if (play) { const SC = ['1,284,500', '1,302,750', '1,327,000', '1,358,250', 'JACKPOT!'], nS = SC.length; SC.forEach((t, i) => bg += dmd(t, i ? 0 : 1) + anD('opacity', rep(nS, j => j === i ? 1 : 0).join(';'), nS * 0.84) + '</text>'); }
      else ['PRESS START', 'HI 9,870,120'].forEach((t, i) => bg += dmd(t, i ? 0 : 1) + anD('opacity', i ? '0;1' : '1;0', 3.2) + '</text>');
      bg += '<rect x="5" y="36" width="41.4" height="10.6" fill="url(#pbDot)"/>';
      if (BGV) f += '<g transform="' + BG + '">' + bg + '<rect x="1.5" y="1.5" width="48.2" height="32" rx="1.5" fill="url(#pbGlass)"/></g>';
      [-27.4, 27.4].forEach((z, i) => { const a = p(-51, 59, z), b = p(-51, 108, z); f += '<g>' + (play ? an('opacity', '1;0.55;1', 0.6, -i * 0.3) : '') + glowL('M' + P2(a) + 'L' + P2(b), i ? NC : NP, 1.1 * k, 'pbBl2') + '</g>'; });
      { const a = p(-51, 110.6, -27.4), b = p(-51, 110.6, 27.4); f += glowL('M' + P2(a) + 'L' + P2(b), NY, 1 * k, 'pbBl2'); }
      const fl = p(0, 0, 0), un = '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(80 * k) + '" ry="' + f1(80 * k * SA * 0.55) + '" fill="' + NP + '" opacity="' + (play ? 0.24 : 0.12) + '" filter="url(#pbBl2)">' + (play ? an('fill', NP + ';' + NC + ';' + NP, 1.6) : '') + '</ellipse>';
      const defs = PAW + BLUR('pbBl2', 1.2) + '<clipPath id="pbClip"><rect x="8" y="-23.4" width="107.5" height="46.8"/></clipPath>'
        + G('pbF', [[0, '#1a0f4a'], [0.55, '#3a1678'], [1, '#121a52']]) + G('pbGl', [[0, '#ff4fb8', 0.45], [1, '#ff4fb8', 0]], { r: 1 }) + G('pbBl', [[0, '#ffffff'], [0.5, '#c9ccd6'], [1, '#5a5f70']], { r: 1, a: 'cx="35%" cy="30%" r="70%"' })
        + G('pbGlass', [[0, '#ffffff', 0], [0.42, '#ffffff', 0], [0.48, '#ffffff', 0.3], [0.56, '#ffffff', 0.05], [0.62, '#ffffff', 0.18], [0.68, '#ffffff', 0]], { a: 'x1="0" y1="0" x2="1" y2="1"' })
        + G('pbBG', [[0, '#2a0a5a'], [0.6, '#8a1a8a'], [1, '#ff6a3c']], { a: 'x1="0" y1="0" x2="0" y2="1"' }) + G('pbPl', [[0, '#9fe8ff'], [1, '#2a5aa8']], { r: 1, a: 'cx="35%" cy="30%" r="75%"' })
        + G('pbSide', [[0, '#ffffff', 0.16], [0.4, '#ffffff', 0], [1, '#000000', 0.25]], { a: 'x1="0" y1="0" x2="0" y2="1"' })
        + '<pattern id="pbDot" width="0.9" height="0.9" patternUnits="userSpaceOnUse"><path d="M0 0H0.9V0.9" fill="none" stroke="#140900" stroke-width="0.28"/></pattern>';
      return { defs, under: un, front: f, bb: bbOf([p(-62, 113, -28), p(-62, 113, 28), p(66, 0, 26), p(66, 0, -26), p(-62, 0, 26)].concat(plBB(p, PL.pinball5)), 3) }; };
    return D; };

  // ======================= 2-PLAYER DANCE-MAT RHYTHM CABINET =======================
  N.danceCab = S => { const play = isPlay(S), BODY = '#20232c', WING = '#c9d0d8', NC = '#3ff0ff', NP = '#ff4fb8', NY = '#ffe14f', BEAT = 0.36, CYC = BEAT * 8;
    const CAB = [[-30, 0], [12, 0], [12, 50], [0, 116], [10, 122], [10, 150], [-30, 150]], WG = [[-32, 0], [16, 0], [16, 52], [4, 116], [14, 121], [14, 152], [-32, 152]];
    const PADX = [-42, 42], PZ = 62, CELL = 22, DIRC = ['#ff5fc8', '#5fb0ff', '#5fffb8', '#ffd85f'], ROT = [-90, 180, 0, 90], STEPS = [[0, 1, 2, 3, 2, 1, 0, 3], [3, 2, 1, 0, 1, 2, 3, 0]];
    const ARW = 'M0 -2.8L2.8 0H1.2V2.8H-1.2V0H-2.8Z', CELLS = [[-1, 0, 0], [0, 1, 1], [0, -1, 2], [1, 0, 3]];
    const D = { w: 176, d: 140 };
    D.build = P => { const o = [box(0, 0, 60, 178, 5, 80, '#2a2c34', mt({ r: 3 })), box(0, 0.6, 100.4, 176, 3, 0.6, NC, em({ r: 0.3 }))];
      PADX.forEach(px => { o.push(box(px, 5, PZ, 72, 1, 72, '#8e96a0', mt({ r: 2 })));
        for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) { const arrow = (i === 0) !== (j === 0); o.push(box(px + i * (CELL + 1), 6, PZ + j * (CELL + 1), CELL, 1.3, CELL, arrow ? '#1a2433' : '#b9c0c8', arrow ? cer({ r: 1.4, op: 0.96 }) : mt({ r: 1.4, shine: 1 }))); } });
      o.push(prism(-40, 40, CAB, BODY, pt()), prism(-46, -40, WG, WING, mt({ shine: 1 })), prism(40, 46, WG, WING, mt({ shine: 1 })));
      [-22, 22].forEach(x => o.push(disc(x, 28, 12, 10, 1, '#121318', mt({ n: 20 })), disc(x, 28, 13, 7.4, 0.8, '#2a2c33', { n: 18 }), disc(x, 28, 13.8, 2.6, 0.8, '#44474f', mt({ n: 12 }))));
      o.push(slab(0, 6, 12.6, 13, 14, 0.8, '#3a3d48', mt({ r: 1 })), slab(0, 15, 13.1, 6, 1.6, 0.4, NY, em({ r: 0.4 })), box(0, 47, 16, 80, 4, 10, '#2c2f3a', mt({ r: 1.5 })), cyl(-30, 51, 16, 2.4, 1.2, NP, em({ n: 12 })), cyl(30, 51, 16, 2.4, 1.2, NC, em({ n: 12 })), cyl(-24, 51, 16, 1.6, 1, '#f4f6f8', { n: 10 }), cyl(24, 51, 16, 1.6, 1, '#f4f6f8', { n: 10 }));
      o.push(slab(0, 123, 10.3, 76, 25, 0.6, '#140a3a', { r: 1 }));
      [-43, 43].forEach(x => o.push(cyl(x, 152, -8, 3.8, 3, '#2a2c34', mt({ n: 12 })), cyl(x, 155, -8, 3, 22, '#f2f8ff', cer({ n: 14, op: 0.5 })), cyl(x, 177, -8, 3.8, 2.4, '#2a2c34', mt({ n: 12 }))));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      const SCR = surf(p, [-32, 112, 1.4], [1, 0, 0], [0, -0.9839, 0.1789]);
      let s = '<rect width="64" height="57" rx="1.5" fill="url(#dcS)"/><g transform="translate(32 30)" opacity="0.22"><g>' + atL('rotate', '0;360', 16) + rep(8, i => '<path d="M0 0L' + f1(Math.cos(i * PI / 4 - 0.12) * 50) + ' ' + f1(Math.sin(i * PI / 4 - 0.12) * 50) + 'L' + f1(Math.cos(i * PI / 4 + 0.12) * 50) + ' ' + f1(Math.sin(i * PI / 4 + 0.12) * 50) + 'Z" fill="#ffffff"/>').join('') + '</g></g>';
      [0, 1].forEach(pl => { const x0 = pl ? 39 : 7; s += '<rect x="' + (x0 - 3.6) + '" y="4" width="24.2" height="52" rx="1" fill="#000000" opacity="0.3"/><rect x="' + (x0 - 3.4) + '" y="1.4" width="24" height="1.8" rx="0.9" fill="#2a2a40"/><rect x="' + (x0 - 3.4) + '" y="1.4" width="17" height="1.8" rx="0.9" fill="url(#dcL)">' + an('width', play ? '15;21;18;23;15' : '12;14;12', play ? 2.4 : 4) + '</rect>';
        rep(4, d => { const lx = x0 + d * 6, hit = STEPS[pl].map(v => v === d ? 1 : 0.18).join(';');
          s += '<g transform="translate(' + lx + ' 7) rotate(' + ROT[d] + ')"><path d="' + ARW + '" fill="none" stroke="#c9d0e8" stroke-width="0.6"/><path d="' + ARW + '" fill="' + DIRC[d] + '" opacity="0.18" transform="scale(1.25)">' + anD('opacity', hit, CYC) + '</path></g>'; });
        STEPS[pl].forEach((d, i) => { const lx = x0 + d * 6, b = i * BEAT - CYC / 2;
          s += '<g transform="translate(' + lx + ' 56)">' + atK('translate', lx + ' 56;' + lx + ' 7;' + lx + ' 7', CYC, '0;0.5;1', b) + anK('opacity', '1;0', CYC, '0;0.5', b, 1) + '<g transform="rotate(' + ROT[d] + ')"><path d="' + ARW + '" fill="' + DIRC[d] + '" stroke="#ffffff" stroke-width="0.4" transform="scale(1.1)"/></g></g>'; }); });
      if (play) s += '<text x="32" y="33" text-anchor="middle" font-family="Arial Black, Arial, sans-serif" font-weight="900" font-style="italic" font-size="6.4" fill="#ffe14f" stroke="#ff4fb8" stroke-width="0.35">PERFECT!!' + anD('opacity', '1;0.35', BEAT) + '</text><text x="32" y="40" text-anchor="middle" font-family="Arial, sans-serif" font-weight="800" font-size="3.6" fill="#ffffff">COMBO 128</text>';
      else s += '<text x="32" y="32" text-anchor="middle" font-family="Arial Black, Arial, sans-serif" font-weight="900" font-style="italic" font-size="7" fill="#ffffff" stroke="#3ff0ff" stroke-width="0.35">BEAT STEP</text><text x="32" y="40" text-anchor="middle" font-family="Arial, sans-serif" font-weight="800" font-size="3.6" fill="#ffe14f">PRESS START' + anD('opacity', '1;0', 1.2) + '</text>';
      s += '<rect width="64" height="57" rx="1.5" fill="url(#dcGl)"/><rect width="64" height="57" rx="1.5" fill="none" stroke="#0b0c10" stroke-width="1.6"/>';
      f += '<g transform="' + SCR + '">' + s + '</g>';
      const MQ = surf(p, [-38, 147.6, 10.95], [1, 0, 0], [0, -1, 0]);
      let m = '<rect width="76" height="23" rx="1.4" fill="url(#dcM)"/><text x="38" y="14.6" text-anchor="middle" font-family="Arial Black, Arial, sans-serif" font-weight="900" font-style="italic" font-size="11" fill="#ffe14f" stroke="#ff4fb8" stroke-width="0.6" letter-spacing="0.4">BEAT STEP</text><text x="38" y="20" text-anchor="middle" font-family="Arial, sans-serif" font-weight="800" font-size="3.4" fill="#ffffff" letter-spacing="1.2">2 PLAYER DANCE</text>';
      const bl = []; rep(13, i => bl.push([3 + i * 5.83, 1.8])); rep(3, i => bl.push([74.2, 6.6 + i * 5])); rep(13, i => bl.push([73 - i * 5.83, 21.2])); rep(3, i => bl.push([1.8, 16.6 - i * 5]));
      bl.forEach(([x, y], i) => m += '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="0.9" fill="#fff6c8">' + anD('opacity', rep(4, j => j === i % 4 ? 1 : 0.25).join(';'), play ? 0.32 : 0.8) + '</circle>');
      f += '<g transform="' + MQ + '">' + m + '<rect width="76" height="23" rx="1.4" fill="url(#dcGl)"/></g>';
      [-43, 43].forEach((x, i) => { const pp = WG.slice(1, 6).map(([z, y]) => p(x, y, z + 0.4)); f += '<g>' + (play ? an('opacity', '1;0.5;1', BEAT * 2, -i * BEAT) : '') + glowL(polyD(pp), i ? NC : NP, 1.1 * k, 'dcB') + '</g>';
        const q = p(x, 166, -8); f += '<ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + f1(4.6 * k) + '" ry="' + f1(13 * k) + '" fill="' + (i ? NC : NP) + '" opacity="0.6" filter="url(#dcB)">' + an('fill', [NP, NY, NC, NP].join(';'), play ? 1.4 : 4, -i * 0.7) + '</ellipse>'; });
      if (play) [-22, 22].forEach((x, i) => { const q = p(x, 28, 14); f += '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(10 * k) + '" fill="none" stroke="' + NC + '" stroke-width="' + f1(0.8 * k) + '">' + an('r', f1(8 * k) + ';' + f1(16 * k), BEAT) + an('opacity', '0.8;0', BEAT) + '</circle>'; });
      PADX.forEach((px, pl) => CELLS.forEach(([i, j, d]) => { const g = planeH(p, 7.4, px + i * (CELL + 1), PZ + j * (CELL + 1)), hit = STEPS[pl].map(v => v === d ? 1 : (play ? 0.16 : 0.3)).join(';'), idle = rep(8, t => (t + d + pl) % 4 === 0 ? 0.85 : 0.25).join(';');
        f += '<g transform="' + g + '"><rect x="-10" y="-10" width="20" height="20" rx="1.6" fill="' + DIRC[d] + '" opacity="0.3" filter="url(#dcB)">' + anD('opacity', play ? hit : idle, CYC) + '</rect><g transform="rotate(' + ROT[d] + ') scale(2.4)"><path d="' + ARW + '" fill="' + DIRC[d] + '" stroke="#ffffff" stroke-width="0.25">' + anD('opacity', play ? hit : idle, CYC) + '</path></g></g>'; }));
      const fl = p(0, 0, 60); un += '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(110 * k) + '" ry="' + f1(110 * k * SA * 0.6) + '" fill="' + NC + '" opacity="' + (play ? 0.22 : 0.1) + '" filter="url(#dcB)">' + (play ? an('fill', NC + ';' + NP + ';' + NC, CYC) : '') + '</ellipse>';
      const defs = BLUR('dcB', 1.4) + G('dcS', [[0, '#14093a'], [0.55, '#3a1670'], [1, '#0b2a5a']], { a: 'x1="0" y1="0" x2="0" y2="1"' }) + G('dcL', [[0, '#3ff0ff'], [1, '#7dff6a']]) + G('dcM', [[0, '#1a0a4a'], [0.5, '#6a1a9a'], [1, '#1a0a4a']])
        + G('dcGl', [[0, '#ffffff', 0.22], [0.35, '#ffffff', 0.02], [0.6, '#ffffff', 0], [1, '#ffffff', 0.06]], { a: 'x1="0" y1="0" x2="1" y2="1"' });
      return { defs, under: un, front: f, bb: bbOf([p(-47, 180, -30), p(47, 180, -30), p(-90, 0, 102), p(90, 0, 102), p(90, 0, 18), p(-90, 0, 18)].concat(plBB(p, PL.danceCab)), 3) }; };
    return D; };

  // ======================= LED GLOW BILLIARDS & AIR HOCKEY TABLE =======================
  N.glowTable = S => { const bill = /bill/i.test(modeOf(S)), play = isPlay(S), BODY = '#4a2c1a', RAIL = '#5c3822', LED = bill ? '#ffb45a' : '#ffd9a0', LED2 = '#f6c070', BRS = '#c8a050', HX = 75, HZ = 42, SY = 38.6;
    const D = { w: 160, d: 92 };
    D.build = P => { const o = [];
      [-46, 46].forEach(x => o.push(box(x, 0, 0, 28, 4, 62, '#2e1c10', wd({ r: 2 })), box(x, 0, 0, 28.4, 0.8, 62.4, BRS, mt({ r: 2, shine: 1 })), box(x, 4, 0, 20, 24, 48, BODY, wd({ r: 3 })), box(x, 4, 0, 21, 1.4, 49, BRS, mt({ r: 0.6, shine: 1 })), box(x, 20, 24.2, 12, 2.6, 0.6, BRS, mt({ r: 0.3, shine: 1 }))));
      o.push(box(0, 12, 0, 74, 8, 14, BODY, wd({ r: 2 })), box(0, 28, 0, 2 * HX, 10, 2 * HZ, BODY, wd({ r: 3 })), box(0, 27.4, 0, 2 * HX + 0.6, 1.2, 2 * HZ + 0.6, BRS, mt({ r: 3, shine: 1 })), box(0, 30.6, HZ + 0.1, 36, 5.6, 0.8, '#0b0c10', mt({ r: 0.8 })));
      return o; };
    const art = p => { let f = '<g transform="' + planeH(p, SY) + '">';
      if (!bill) { f += '<rect x="-69" y="-36" width="138" height="72" rx="3" fill="url(#gtI)"/><rect x="-69" y="-36" width="138" height="72" rx="3" fill="url(#gtH)" opacity="0.6"/>'
          + '<path d="M0 -36V36" stroke="#b8323a" stroke-width="1.4"/><path d="M-24 -36V36M24 -36V36" stroke="#2a4a8a" stroke-width="0.9"/><circle r="10" fill="none" stroke="#2a4a8a" stroke-width="0.9"/><circle r="1.4" fill="#2a4a8a"/>'
          + '<path d="M-69 -12A12 12 0 0 1 -69 12M69 -12A12 12 0 0 0 69 12" fill="none" stroke="#b8323a" stroke-width="0.9"/><rect x="-69.6" y="-9" width="2.6" height="18" fill="#0a0b10"/><rect x="67" y="-9" width="2.6" height="18" fill="#0a0b10"/>';
        f += play ? '<g><animateMotion dur="2.4s" repeatCount="indefinite" path="M-60 0L-22 33L16 -33L58 3L24 33L-14 -33L-60 0"/><ellipse cx="0.5" cy="0.6" rx="3.4" ry="3.4" fill="#000000" opacity="0.25"/><circle r="3.2" fill="#ff3b5c" stroke="#8a1a2a" stroke-width="0.5"/><circle r="1.9" fill="none" stroke="#ffffff" stroke-width="0.35" opacity="0.6"/></g>'
          : '<circle r="3.2" fill="#ff3b5c" stroke="#8a1a2a" stroke-width="0.5"/>'; }
      else { f += '<rect x="-69" y="-36" width="138" height="72" rx="2" fill="url(#gtF)"/><path d="M34 -36V36" stroke="#efe6cc" stroke-width="0.4" stroke-dasharray="2 2" opacity="0.45"/><circle cx="-34" cy="0" r="0.8" fill="#efe6cc"/><circle cx="34" cy="0" r="0.8" fill="#efe6cc"/>';
        [[-69, -36], [0, -37.5], [69, -36], [-69, 36], [0, 37.5], [69, 36]].forEach(([x, z], i) => f += '<circle cx="' + x + '" cy="' + z + '" r="4.6" fill="#120c08"/><circle cx="' + x + '" cy="' + z + '" r="3.4" fill="#2a1a10"/><circle cx="' + x + '" cy="' + z + '" r="4.6" fill="none" stroke="' + BRS + '" stroke-width="1.1">' + an('opacity', '1;0.75;1', 1.6, -i * 0.27) + '</circle>'); }
      f += '<rect x="-69" y="-36" width="138" height="72" rx="3" fill="none" stroke="' + LED + '" stroke-width="1.4" opacity="0.4" filter="url(#gtB)">' + an('opacity', '0.45;0.25;0.45', play ? 1.2 : 3) + '</rect>';
      return f + '</g>'; };
    D.layers = [{ build: P => [box(0, 38, HZ - 3, 2 * HX, 4.6, 6, RAIL, wd({ r: 1.4 })), box(0, 38, -(HZ - 3), 2 * HX, 4.6, 6, RAIL, wd({ r: 1.4 })), box(HX - 3, 38, 0, 6, 4.6, 2 * HZ - 12, RAIL, wd({ r: 1.4 })), box(-(HX - 3), 38, 0, 6, 4.6, 2 * HZ - 12, RAIL, wd({ r: 1.4 }))],
      wrap: (p, s) => { const k = kOf2(p); let e = '';
        [[-HX + 6, HZ - 6, HX - 6, HZ - 6], [-HX + 6, -HZ + 6, HX - 6, -HZ + 6], [HX - 6, -HZ + 6, HX - 6, HZ - 6], [-HX + 6, -HZ + 6, -HX + 6, HZ - 6]].forEach(([a, b, c2, d], i) => e += glowL('M' + P2(p(a, 42.7, b)) + 'L' + P2(p(c2, 42.7, d)), i % 2 ? LED2 : LED, 0.7 * k, 'gtB'));
        if (bill) rep(6, i => { const x = -50 + i * 20, a = p(x, 42.7, HZ - 3), b = p(x, 42.7, -HZ + 3); e += '<circle cx="' + f1(a[0]) + '" cy="' + f1(a[1]) + '" r="' + f1(0.8 * k) + '" fill="#ffffff"/><circle cx="' + f1(b[0]) + '" cy="' + f1(b[1]) + '" r="' + f1(0.8 * k) + '" fill="#ffffff"/>'; });
        return art(p) + s + e; } }];
    const kOf2 = p => (p(0, 0, 0)[1] - p(0, 1, 0)[1]) / CA;
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      if (!bill) { const H = [[-60, 0], [-22, 33], [16, -33], [58, 3], [24, 33], [-14, -33], [-60, 0]], FH = plen(H), f3 = FH[3];
        const mallet = (col, kf) => { const vals = kf.map(([t, x, z]) => p(x, SY, z)); return '<g transform="translate(' + P2(vals[0]) + ')">' + (play ? atK('translate', pts(vals), 2.4, kts(kf.map(q => q[0]))) : '')
          + '<ellipse cx="0" cy="' + f1(0.6 * k) + '" rx="' + f1(5 * k) + '" ry="' + f1(5 * k * SA) + '" fill="#000000" opacity="0.25"/><ellipse rx="' + f1(4.6 * k) + '" ry="' + f1(4.6 * k * SA) + '" fill="' + shade(col, 0.7) + '"/><path d="M' + f1(-4.6 * k) + ' 0V' + f1(-1.6 * k) + 'A' + f1(4.6 * k) + ' ' + f1(4.6 * k * SA) + ' 0 0 1 ' + f1(4.6 * k) + ' ' + f1(-1.6 * k) + 'V0Z" fill="' + col + '"/>'
          + '<ellipse cy="' + f1(-1.6 * k) + '" rx="' + f1(4.6 * k) + '" ry="' + f1(4.6 * k * SA) + '" fill="' + mix(col, '#ffffff', 0.25) + '"/><rect x="' + f1(-1.1 * k) + '" y="' + f1(-6.4 * k) + '" width="' + f1(2.2 * k) + '" height="' + f1(4.8 * k) + '" fill="' + shade(col, 0.85) + '"/><ellipse cy="' + f1(-6.6 * k) + '" rx="' + f1(2.4 * k) + '" ry="' + f1(2 * k) + '" fill="' + col + '"/><ellipse cx="' + f1(-0.7 * k) + '" cy="' + f1(-7 * k) + '" rx="' + f1(0.8 * k) + '" ry="' + f1(0.5 * k) + '" fill="#ffffff" opacity="0.7"/></g>'; };
        f += mallet('#ffd84f', play ? [[0, -64, 0], [0.08, -58, 1], [0.4, -64, 12], [0.75, -63, -10], [0.93, -67, -1], [1, -64, 0]] : [[0, -60, 0]]);
        f += mallet('#3fdc6a', play ? [[0, 64, -8], [f3 - 0.12, 66, 5], [f3, 62, 3], [f3 + 0.08, 57, 2], [0.8, 64, 12], [1, 64, -8]] : [[0, 60, 0]]);
        if (play) [[0.001, -60, 0], [f3, 58, 3]].forEach(([t, x, z]) => { const q = p(x, SY + 2, z), F = flash([t], 0, 1, 0.06); f += '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(5 * k) + '" fill="#ffffff" opacity="0">' + anK('opacity', F.v, 2.4, F.kt) + '</circle>'; }); }
      else { const BC = ['#ffd84f', '#3b7bff', '#ff3b5c', '#b04bff', '#ff9d3c', '#3fdc6a', '#ff4fb8', '#1a1a20', '#7df9ff', '#c8ff4f'], R2 = rng('pool');
        const rack = []; for (let r = 0; r < 4; r++) for (let j = 0; j <= r; j++) rack.push([-30 - r * 4.6, (j - r / 2) * 5.3]);
        const dst = rack.map((q, i) => i === 7 ? [-69, -36] : i === 3 ? [0, 37.5] : [-60 + R2() * 100, -30 + R2() * 60]);
        const KT = '0;0.28;0.5;0.88;0.94;0.97;1', ballS = (col, kf, op) => { const vals = kf.map(([x, z]) => p(x, SY + 2.6, z)), r = 2.6 * k;
          return '<g transform="translate(' + P2(vals[0]) + ')">' + (play ? atK('translate', pts(vals), 5, KT) + anK('opacity', op || '1;1;1;1;0;0;1', 5, KT) : '')
            + '<circle r="' + f1(r * 1.8) + '" fill="' + col + '" opacity="0.35" filter="url(#gtB)"/><circle r="' + f1(r) + '" fill="url(#gtb' + col.slice(1) + ')"/><circle cx="' + f1(-r * 0.35) + '" cy="' + f1(-r * 0.4) + '" r="' + f1(r * 0.3) + '" fill="#ffffff" opacity="0.7"/></g>'; };
        let gd = ''; BC.concat('#f4f6f8').forEach(c2 => gd += G('gtb' + c2.slice(1), [[0, mix(c2, '#ffffff', 0.55)], [0.6, c2], [1, shade(c2, 0.55)]], { r: 1, a: 'cx="35%" cy="30%" r="70%"' }));
        f += '<defs>' + gd + '</defs>';
        const ord = rack.map((q, i) => i).sort((a, b) => (rack[a][1] * 0.866 + rack[a][0] * 0.5) - (rack[b][1] * 0.866 + rack[b][0] * 0.5));
        ord.forEach(i => { const q = rack[i], e = dst[i]; f += ballS(BC[i], play ? [q, q, e, e, e, q, q] : [q], i === 7 || i === 3 ? '1;1;0;0;0;0;1' : null); });
        f += ballS('#f4f6f8', play ? [[34, 0], [-25, 0], [-12, 8], [-12, 8], [-12, 8], [34, 0], [34, 0]] : [[34, 0]]);
        if (play) { const t = p(37.4, SY + 2.6, 0.3), u = p(98, SY + 7, 3.2), dx = (u[0] - t[0]) / Math.hypot(u[0] - t[0], u[1] - t[1]), dy = (u[1] - t[1]) / Math.hypot(u[0] - t[0], u[1] - t[1]), off = d => f1(dx * d * k) + ' ' + f1(dy * d * k);
          f += '<g>' + atK('translate', [6, 13, 0, 1.5, 14, 14, 6].map(off).join(';'), 5, '0;0.11;0.16;0.2;0.4;0.95;1') + '<path d="M' + P2(t) + 'L' + P2(u) + '" stroke="#5a3418" stroke-width="' + f1(2.2 * k) + '" stroke-linecap="round"/><path d="M' + P2(t) + 'L' + P2(u) + '" stroke="url(#gtCue)" stroke-width="' + f1(1.4 * k) + '" stroke-linecap="round"/><circle cx="' + f1(t[0]) + '" cy="' + f1(t[1]) + '" r="' + f1(0.8 * k) + '" fill="#3b7bff"/></g>'; } }
      const SC = surf(p, [-18, 35.9, HZ + 0.6], [1, 0, 0], [0, -1, 0]);
      f += '<g transform="' + SC + '"><rect x="1" y="0.6" width="34" height="4.4" rx="0.6" fill="#050608"/>' + (bill ? '<text x="18" y="4.1" text-anchor="middle" font-family="Courier New, monospace" font-weight="700" font-size="3.6" fill="' + LED + '">8-BALL ' + (play ? 'P1' : '--') + '</text>'
        : '<text x="18" y="4.1" text-anchor="middle" font-family="Courier New, monospace" font-weight="700" font-size="3.6" fill="#ffb45a">' + (play ? '3 : 2' : '0 : 0') + (play ? anD('opacity', '1;0.5', 0.6) : '') + '</text>') + '</g>';
      const fl = p(0, 0, 0), un = '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(96 * k) + '" ry="' + f1(96 * k * SA * 0.62) + '" fill="' + LED + '" opacity="' + (play ? 0.32 : 0.2) + '" filter="url(#gtB)">' + an('opacity', play ? '0.32;0.18;0.32' : '0.2;0.12;0.2', play ? 1.2 : 3) + '</ellipse>';
      const defs = BLUR('gtB', 1.3) + G('gtI', [[0, '#fffdf8'], [0.6, '#f6f0e6'], [1, '#e6dccb']], { r: 1 }) + G('gtF', [[0, '#2f7a5a'], [0.7, '#1f5e44'], [1, '#154430']], { r: 1 }) + G('gtCue', [[0, '#f4e4c0'], [0.7, '#c99a5a'], [1, '#2a1a10']], { a: 'x1="0" y1="0" x2="1" y2="0"' })
        + '<pattern id="gtH" width="3.2" height="3.2" patternUnits="userSpaceOnUse"><circle cx="1.6" cy="1.6" r="0.3" fill="#a8987e"/></pattern>';
      return { defs, under: un, front: f, bb: bbOf([p(-80, 44, -45), p(80, 44, -45), p(80, 0, 46), p(-80, 0, 46)].concat(plBB(p, plOf('glowTable', S.st))), 3) }; };
    return D; };

  // ======================= OSCILLATING FAN WITH SOAP-BUBBLE WAND =======================
  N.bubbleFan = S => { const on = isOn(S), T = 5.6, A0 = 34, HY = 80, R = 19, PLc = '#efeadf', PL2 = '#d8d0bf', NB = on ? 30 : 14;
    const D = { w: 60, d: 50 };
    D.build = P => [cyl(0, 0, 0, 17, 2, PL2, pt({ n: 24 })), cyl(0, 2, 0, 16, 4.4, PLc, pt({ n: 24, rg: [[0, 0, 1], [4.4, 0, 0.72]] })),
      ...rep(3, i => box(-5.2 + i * 5.2, 3.6, 11.6, 4.4, 2.2, 4, i === (on ? 2 : 0) ? '#7fd0ff' : '#f7f4ec', pt({ r: 0.6 }))),
      cyl(0, 6.4, 0, 2.6, 30, CH, mt({ n: 10, shine: 1 })), cyl(0, 36, 0, 3.6, 3, PLc, pt({ n: 12 })), slabX(3.6, 37.5, 0, 2.4, 1.2, 1.2, PL2), cyl(0, 39, 0, 1.9, 27, CH, mt({ n: 10, shine: 1 })), cyl(0, 64, 0, 4.4, 5, PLc, pt({ n: 14 })), cyl(0, 69, 0, 2.4, 5, PL2, pt({ n: 10 }))];
    D.fx = c => { const p = c.p, k = c.k, NS = 16, th = i => A0 * Math.sin(2 * PI * i / NS) * PI / 180;
      const frame = off => { const tr = [], sk = [], sc = []; rep(NS + 1, i => { const t = th(i), ph = t, d = [Math.sin(t + PI / 6), 0, Math.cos(t + PI / 6)], q = p(d[0] * off, HY, d[2] * off), a = Math.cos(ph), cc = -SA * Math.sin(ph);
          tr.push(P2(q)); sk.push(n4(Math.atan2(cc, a) * 180 / PI)); sc.push(n4(k * a) + ' ' + n4(k * CA)); });
        return { o: '<g transform="translate(' + tr[0] + ')">' + atL('translate', tr.join(';'), T) + '<g transform="skewY(' + sk[0] + ')">' + atL('skewY', sk.join(';'), T) + '<g transform="scale(' + sc[0] + ')">' + atL('scale', sc.join(';'), T), c: '</g></g></g>' }; };
      let f = '';
      [-14, -11, -8, -5, -2.5].forEach((off, i) => { const F = frame(off); f += F.o + '<circle r="' + (i === 0 ? 7.5 : 9.4) + '" fill="url(#bfM)" stroke="' + shade(PL2, 0.8) + '" stroke-width="0.4"/>' + (i === 4 ? '<circle r="9.4" fill="none" stroke="#ffffff" stroke-width="0.5" opacity="0.3"/>' : '') + F.c; });
      { const F = frame(-0.5); f += F.o + '<circle r="' + R + '" fill="#dfeaf2" fill-opacity="0.18" stroke="#e7e2d6" stroke-width="1"/>' + F.c; }
      { const F = frame(1.5); f += F.o + '<circle r="17" fill="#bfe2f5" opacity="0.25"/><g>' + atL('rotate', '0;360', on ? 0.32 : 0.5) + rep(3, i => '<path d="M0 0C5 -4.5 15 -6.5 16.4 -0.6C16 4.6 7 5.4 0 0Z" fill="#8fcbef" fill-opacity="0.78" stroke="#5a9cc4" stroke-width="0.35" transform="rotate(' + i * 120 + ')"/>').join('') + '</g><circle r="3.6" fill="' + PLc + '" stroke="' + PL2 + '" stroke-width="0.4"/>' + F.c; }
      { const F = frame(4); let g = '';
        [R, R * 0.74, R * 0.48].forEach((r, i) => g += '<circle r="' + f1(r) + '" fill="none" stroke="#f6f3ec" stroke-width="' + (i ? 0.5 : 1.3) + '"/>');
        rep(18, i => { const a = i * PI / 9; g += '<path d="M' + f1(Math.cos(a) * 4.2) + ' ' + f1(Math.sin(a) * 4.2) + 'L' + f1(Math.cos(a) * R) + ' ' + f1(Math.sin(a) * R) + '" stroke="#f6f3ec" stroke-width="0.45"/>'; });
        g += '<circle r="4.4" fill="' + PLc + '" stroke="' + PL2 + '" stroke-width="0.5"/><circle r="2.6" fill="none" stroke="#7fd0ff" stroke-width="0.6"/><path d="M-12 -14A18 18 0 0 1 8 -16" stroke="#ffffff" stroke-width="0.8" fill="none" opacity="0.7"/>';
        f += F.o + g + F.c; }
      { const F = frame(7.5); let g = '<path d="M-3 19L-4.5 27M3 19L4.5 27" stroke="#2fa8b8" stroke-width="1.1"/><path d="M-14 25H14L12 31Q0 33 -12 31Z" fill="#2fa8b8" stroke="#1d7c8a" stroke-width="0.4"/><path d="M-13 26.4H13" stroke="#bff4ff" stroke-width="1.2" opacity="0.8"/>';
        g += '<g transform="translate(0 15)"><g>' + atL('rotate', '0;360', on ? 3.2 : 5) + rep(6, i => { const a = i * PI / 3, x = Math.cos(a) * 9, y = Math.sin(a) * 9; return '<path d="M0 0L' + f1(x * 0.72) + ' ' + f1(y * 0.72) + '" stroke="#ffc93c" stroke-width="0.9"/><circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="2.6" fill="#dff4ff" fill-opacity="0.35" stroke="#ffc93c" stroke-width="0.8"/>'; }).join('') + '</g><circle r="2" fill="#ff9d3c" stroke="#c86a1a" stroke-width="0.3"/></g>';
        f += F.o + g + F.c; }
      const ends = [];
      rep(NB, i => { const t0 = i * T / NB, t = A0 * Math.sin(2 * PI * t0 / T) * PI / 180 + PI / 6, d = [Math.sin(t), 0, Math.cos(t)], e1 = [Math.cos(t), 0, -Math.sin(t)], R2 = rng('bub' + i), L = 70 + R2() * 60, sw = (R2() - 0.5) * 40, rise = 30 + R2() * 34;
        const at = s2 => [d[0] * (9 + L * s2) + e1[0] * sw * s2, HY + 1 + rise * Math.pow(s2, 1.2), d[2] * (9 + L * s2) + e1[2] * sw * s2], P0 = p(...at(0)), P1 = p(...at(0.45)), P2a = p(...at(1)), r = (2.2 + R2() * 2.6) * k;
        ends.push(P2a); const b = -(T - t0);
        f += '<g transform="translate(' + P2(P0) + ')">' + atK('translate', pts([P0, P1, P2a, P2a]), T, '0;0.35;0.72;1', b) + anK('opacity', '0;1;0.95;0;0', T, '0;0.05;0.66;0.72;1', b)
          + '<g>' + atK('scale', '0.3;1;1.05;1.3;1.3', T, '0;0.12;0.66;0.72;1', b) + '<circle r="' + f1(r) + '" fill="url(#bfB)" stroke="#ffffff" stroke-opacity="0.75" stroke-width="' + f1(0.25 * k) + '"/><circle cx="' + f1(-r * 0.35) + '" cy="' + f1(-r * 0.4) + '" r="' + f1(r * 0.22) + '" fill="#ffffff" opacity="0.9"/></g></g>'; });
      const defs = G('bfM', [[0, '#fbf8f1'], [0.6, PLc], [1, '#b9b09c']], { r: 1, a: 'cx="38%" cy="32%" r="70%"' }) + G('bfB', [[0, '#ffffff', 0.04], [0.7, '#bfefff', 0.12], [0.86, '#ff9ee0', 0.3], [1, '#7fe0ff', 0.5]], { r: 1 });
      return { defs, front: f, bb: bbOf(ends.concat([p(-24, HY + 24, 0), p(24, HY + 24, 0), p(-20, HY - 24, 20), p(20, HY - 24, 20), p(-18, 0, 18), p(18, 0, -18)]), 4) }; };
    return D; };

  // ======================= FOG MACHINES =======================
  const plume = (o, dir, n, L, col, dur, k, spread) => rep(n, i => { const R2 = rng('pl' + i + L), b = -i * dur / n, sp = (R2() - 0.5) * (spread || 0.5), ex = o[0] + (dir[0] + sp * dir[1]) * L, ey = o[1] + (dir[1] - sp * dir[0]) * L - L * 0.15, r0 = 2 * k, r1 = (9 + R2() * 6) * k;
    return '<circle cx="' + f1(o[0]) + '" cy="' + f1(o[1]) + '" r="' + f1(r0) + '" fill="' + col + '" filter="url(#fgB)">' + an('cx', f1(o[0]) + ';' + f1(ex), dur, b) + an('cy', f1(o[1]) + ';' + f1(ey), dur, b) + an('r', f1(r0) + ';' + f1(r1), dur, b) + an('opacity', '0.85;0.5;0', dur, b) + '</circle>'; }).join('');
  const FGD = BLUR('fgB', 2.2) + BLUR('fgb', 0.9);
  // Compact Halloween mini fog machine (tier 2)
  N.fogMini = S => { const on = isOn(S), BK = '#1d1d22', OR = '#ff8a1e';
    const D = { w: 70, d: 48 };
    D.build = P => { const o = [];
      [[-20, -11], [16, -11], [-20, 11], [16, 11]].forEach(([x, z]) => o.push(cyl(x, 0, z, 2, 3, '#111114', { n: 10 })));
      o.push(box(-2, 3, 0, 44, 20, 30, BK, mt({ r: 2.5 })), box(-2, 3.4, 0, 44.6, 3.6, 30.6, OR, pt({ r: 1 })), slabX(20.4, 7, 0, 1, 13, 22, '#2b2b31', mt({ r: 1 })));
      o.push(solid({ ax: 'x', sh: 'el', c: [0, 15], a: 3.4, b: 3.4, n: 12, rings: [[20.6, 0], [25, 0, 0.92]], col: CH, mat: 'metal', shine: 1 }), solid({ ax: 'x', sh: 'el', c: [0, 15], a: 3, b: 3, n: 12, rings: [[25, 0], [26.6, 0, 0.8]], col: '#c9a046', mat: 'metal' }));
      o.push(box(-14, 23, 0, 3, 6, 4, '#2a2a30', mt({ r: 1 })), box(10, 23, 0, 3, 6, 4, '#2a2a30', mt({ r: 1 })), slabX(-2, 28.4, 0, 28, 3.2, 5, '#2a2a30', mt({ r: 1.5 })));
      o.push(box(-14, 23, -8, 12, 13, 11, '#e2d8ff', cer({ op: 0.4, r: 2 })), box(-14, 23.4, -8, 10.6, 8.6, 9.6, '#8f5bd8', cer({ op: 0.82, r: 1.6 })), cyl(-14, 36, -8, 2.6, 2, OR, pt({ n: 12 })));
      o.push(box(28, 0, 24, 10, 3, 6.4, '#26262b', mt({ r: 1.2 })), cyl(26, 3, 24, 1.5, 1, '#e8343c', em({ n: 10 })), cyl(31, 3, 24, 0.7, 0.6, on ? '#ffb43c' : '#4fdc6a', em({ n: 8 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      const SD = plane(p, 15.3, 22, -22); let g = '<rect x="2" y="3.6" width="40" height="12" rx="1" fill="#26262c"/>' + rep(7, i => '<rect x="' + (4 + i * 2.4) + '" y="5.4" width="1.1" height="8.4" rx="0.5" fill="#0c0c0f"/>').join('');
      g += '<circle cx="31.5" cy="9.4" r="5.2" fill="' + OR + '" stroke="#b85a10" stroke-width="0.4"/><path d="M31.5 4.2q1.2-1.4 2.2-0.6" stroke="#3a7a2a" stroke-width="0.8" fill="none"/><path d="M29 8l1.4-1.4 1.4 1.4zM32.4 8l1.4-1.4 1.4 1.4zM28.6 11q2.9 2.4 5.8 0l-1 0.8-0.9-0.6-0.9 0.6-0.9-0.6-0.9 0.6z" fill="#2a1406"/>';
      g += '<path d="M22 6q1.4-1.2 2.6 0q1.2-1.2 2.6 0q-1.3 0.2-2.6 1.4q-1.3-1.2-2.6-1.4z" fill="#0c0c0f"/><path d="M38 14q1-0.9 2 0q1-0.9 2 0q-1 0.2-2 1q-1-0.8-2-1z" fill="#0c0c0f"/>';
      g += '<circle cx="40" cy="6" r="0.9" fill="' + (on ? '#ffb43c' : '#4fdc6a') + '">' + (on ? anD('opacity', '1;0.2', 0.6) : '') + '</circle>';
      f += '<g transform="' + SD + '">' + g + '</g>';
      const rm = p(28, 1.5, 21), bd = p(-6, 3.5, 15.4); f += '<path d="M' + P2(rm) + 'Q' + f1((rm[0] + bd[0]) / 2) + ' ' + f1(Math.max(rm[1], bd[1]) + 10 * k) + ' ' + P2(bd) + '" fill="none" stroke="#111114" stroke-width="' + f1(0.9 * k) + '"/>';
      const nz = p(27, 15, 0); f += '<circle cx="' + f1(nz[0]) + '" cy="' + f1(nz[1]) + '" r="' + f1(1.7 * k) + '" fill="#0c0c0f"/>';
      if (on) { const o0 = p(0, 0, 0), dv = p(1, 0.05, 0.3), L = Math.hypot(dv[0] - o0[0], dv[1] - o0[1]); f += '<circle cx="' + f1(nz[0]) + '" cy="' + f1(nz[1]) + '" r="' + f1(2.6 * k) + '" fill="#ffb43c" opacity="0.5" filter="url(#fgb)"/>' + plume(nz, [(dv[0] - o0[0]) / L, (dv[1] - o0[1]) / L], 7, 34 * k, '#eef1f6', 1.6, k, 0.5); }
      return { defs: FGD, front: f, bb: bbOf([p(-26, 40, -18), p(28, 0, 30), p(-26, 0, 18), p(70, 30, 20)], 3) }; };
    return D; };
  // High-output club hazer on a road case + 2 UV blacklight cannons (tier 3)
  N.hazer = S => { const on = isOn(S), UV = '#9a6bff';
    const D = { w: 130, d: 80 };
    D.build = P => { const o = [box(-14, 0, 0, 64, 18, 40, '#2a2c33', mt({ r: 1.5 })), box(-14, 8.4, 20.2, 64, 1.2, 0.6, '#9aa3a8', mt({ r: 0.3 }))];
      [-44, 16].forEach(x => [-19, 19].forEach(z => o.push(box(x + (x < 0 ? 1.6 : -1.6), 0, z, 3.6, 18, 3.6, '#b9c0c6', mt({ r: 0.8, shine: 1 })))));
      [-30, 2].forEach(x => o.push(slab(x, 10.6, 20.6, 6, 3, 0.8, '#b9c0c6', mt({ r: 0.6, shine: 1 }))));
      o.push(box(-16, 18, 0, 52, 26, 34, '#18191d', mt({ r: 2.5 })), slabX(10.4, 21, 0, 0.8, 20, 26, '#22242a', mt({ r: 1 })), slabX(-16, 44, -12, 30, 3, 4, '#2a2c33', mt({ r: 1.2 })), slabX(-16, 44, 12, 30, 3, 4, '#2a2c33', mt({ r: 1.2 })));
      o.push(box(-46, 18, -8, 10, 18, 10, '#f4f6f8', cer({ r: 3, op: 0.92 })), box(-46, 18.4, -8, 9, 9, 9, '#bfe4ff', cer({ r: 2.6, op: 0.7 })), cyl(-46, 36, -8, 2.4, 2.4, '#3f7fc8', pt({ n: 10 })));
      [-24, 24].forEach(z => { const x = 44; o.push(cyl(x, 0, z, 8, 1.6, '#1d1e22', mt({ n: 18 })), cyl(x, 1.6, z, 1.5, 28, '#3a3c44', mt({ n: 8 })), box(x, 28, z, 18, 3, 3, '#2a2c33', mt({ r: 1 })),
        cyl(x, 30, z, 7.4, 13, '#141418', mt({ n: 20 })), cyl(x, 32, z, 8.2, 1.2, '#2a2c33', mt({ n: 20 })), cyl(x, 37, z, 8.2, 1.2, '#2a2c33', mt({ n: 20 })), cyl(x, 43, z, 6.6, 0.8, on ? '#c9a6ff' : '#3a2a6a', em({ n: 18 }))); });
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      const FR = surf(p, [10.9, 31, 13], [0, 0, -1], [0, -1, 0]); f += '<g transform="' + FR + '"><circle cx="13" cy="0" r="9" fill="#0a0a0d"/><g transform="translate(13 0)"><g>' + (on ? atL('rotate', '0;360', 0.25) : '') + rep(5, i => '<path d="M0 0C3 -3 7.6 -3 8 0C6 1.6 3 1.2 0 0Z" fill="#3a3c44" transform="rotate(' + i * 72 + ')"/>').join('') + '</g>'
        + rep(4, i => '<circle r="' + (2.2 + i * 2.2) + '" fill="none" stroke="#6a6f78" stroke-width="0.45"/>').join('') + '<path d="M-9 0H9M0 -9V9" stroke="#6a6f78" stroke-width="0.45"/></g></g>';
      const LC = plane(p, 17.4, 40, -38); f += '<g transform="' + LC + '"><rect x="2" y="2" width="20" height="8" rx="1" fill="#0a1830"/><text x="12" y="7.6" text-anchor="middle" font-family="Courier New, monospace" font-weight="700" font-size="3.6" fill="#6ac8ff">' + (on ? 'HAZE 80%' : 'READY') + (on ? anD('opacity', '1;0.6', 0.8) : '') + '</text><rect x="26" y="3" width="4" height="2.4" rx="0.6" fill="#3a3c44"/><rect x="31" y="3" width="4" height="2.4" rx="0.6" fill="#3a3c44"/><circle cx="40" cy="5" r="1" fill="' + (on ? '#4fdc6a' : '#ff9d3c') + '"/>'
        + '<text x="2" y="16" font-family="Arial, sans-serif" font-weight="800" font-size="3" fill="#9aa3a8" letter-spacing="0.6">HZ-1500</text></g>';
      [-24, 24].forEach((z, i) => { const o = p(44, 44, z);
        if (on) { const L = 120 * k; f += '<g opacity="0.75">' + an('opacity', '0.75;0.5;0.75', 1.4, -i * 0.7) + '<path d="M' + f1(o[0] - 6 * k) + ' ' + f1(o[1]) + 'L' + f1(o[0] - 38 * k) + ' ' + f1(o[1] - L) + 'L' + f1(o[0] + 38 * k) + ' ' + f1(o[1] - L) + 'L' + f1(o[0] + 6 * k) + ' ' + f1(o[1]) + 'Z" fill="url(#hzU)"/></g>'
          + rep(12, j => { const R2 = rng('uv' + i + j), x = o[0] + (R2() - 0.5) * 56 * k, y = o[1] - (20 + R2() * 90) * k; return '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(0.6 * k) + '" fill="' + ['#d9ff4f', '#ff4fb8', '#3ff0ff'][j % 3] + '">' + an('opacity', '0;1;0', n4(1.2 + R2()), -R2() * 2) + '</circle>'; }).join('');
          const fl = p(44, 0, z); un += '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(40 * k) + '" ry="' + f1(40 * k * SA * 0.6) + '" fill="' + UV + '" opacity="0.3" filter="url(#fgB)"/>'; }
        f += '<ellipse cx="' + f1(o[0]) + '" cy="' + f1(o[1]) + '" rx="' + f1(6.6 * k) + '" ry="' + f1(6.6 * k * SA) + '" fill="' + (on ? '#e2d4ff' : '#4a3a7a') + '" opacity="0.9"/>'; });
      if (on) { const o0 = p(0, 0, 0), dv = p(1, 0.1, 0.35), L = Math.hypot(dv[0] - o0[0], dv[1] - o0[1]); f += plume(p(12, 31, 0), [(dv[0] - o0[0]) / L, (dv[1] - o0[1]) / L], 9, 40 * k, '#efeaff', 2.2, k, 0.9); }
      const defs = FGD + G('hzU', [[0, UV, 0.7], [1, UV, 0]], { a: 'x1="0" y1="1" x2="0" y2="0"' });
      return { defs, under: un, front: f, bb: bbOf([p(-52, 46, -22), p(54, 44, 32), p(-48, 0, 22), p(56, 0, -32), on ? p(44, 160, 0) : p(44, 46, 0)], 4) }; };
    return D; };
  // Cryo CO2 jet blasters + confetti swirl cannon (tier 4)
  N.cryoJets = S => { const on = isOn(S), JX = [-40, 40], JZ = 10;
    const D = { w: 130, d: 76 };
    D.build = P => { const o = [];
      JX.forEach(x => o.push(box(x, 0, JZ, 22, 3, 22, '#1d1e22', mt({ r: 1.5 })), box(x, 3, JZ, 12, 24, 12, '#2a2c33', mt({ r: 2 })), slab(x, 14, JZ + 6.1, 8, 6, 0.4, '#3f7fc8', pt({ r: 0.8 })), cyl(x, 27, JZ, 3, 14, CH, mt({ n: 12, shine: 1 })), cyl(x, 41, JZ, 3.2, 5, CH, mt({ n: 12, shine: 1, rg: [[0, 0, 0.8], [5, 0, 1.3]] })), cyl(x, 46, JZ, 2.2, 0.4, '#0c0c10', { n: 10 })));
      o.push(cyl(-4, 0, -22, 9.4, 76, '#7f8f9c', mt({ n: 22, shine: 1 })), ball(-4, 76, -22, 9.4, '#7f8f9c', mt({ sy: 0.5, k: 5, n: 22, shine: 1 })), cyl(-4, 44, -22, 9.8, 2, '#2a2c33', mt({ n: 22 })), cyl(-4, 80, -22, 2.4, 6, GOLD, mt({ n: 10, shine: 1 })), box(-4, 85, -22, 8, 2, 2, GOLD, mt({ r: 0.6 })), disc(-4, 84, -19.6, 3, 1, '#f4f6f8', { n: 14 }));
      o.push(box(6, 0, 24, 16, 3, 16, '#1d1e22', mt({ r: 1.5 })), cyl(6, 3, 24, 5, 30, '#161618', mt({ n: 18 })), cyl(6, 10, 24, 5.4, 1.6, GOLD, mt({ n: 18, shine: 1 })), cyl(6, 24, 24, 5.4, 1.6, GOLD, mt({ n: 18, shine: 1 })), cyl(6, 33, 24, 5.8, 2, GOLD, mt({ n: 18, shine: 1 })), cyl(6, 34.6, 24, 4, 0.5, '#0c0c10', { n: 14 }));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      const t0 = p(-4, 2, -14); JX.forEach(x => { const j = p(x, 2, JZ - 8); f += '<path d="M' + P2(t0) + 'Q' + f1((t0[0] + j[0]) / 2) + ' ' + f1(Math.max(t0[1], j[1]) + 8 * k) + ' ' + P2(j) + '" fill="none" stroke="#0e0e12" stroke-width="' + f1(1.6 * k) + '"/><path d="M' + P2(t0) + 'Q' + f1((t0[0] + j[0]) / 2) + ' ' + f1(Math.max(t0[1], j[1]) + 8 * k) + ' ' + P2(j) + '" fill="none" stroke="#5a5f6a" stroke-width="' + f1(0.4 * k) + '"/>'; });
      const gg = p(-4, 84, -19); f += '<path d="M' + P2(gg) + 'l' + f1(1.6 * k) + ' ' + f1(-1.2 * k) + '" stroke="#e8343c" stroke-width="' + f1(0.4 * k) + '"/>';
      const cm = p(6, 35, 24); rep(8, i => { const R2 = rng('cf' + i); f += '<rect x="' + f1(cm[0] + (R2() - 0.5) * 6 * k) + '" y="' + f1(cm[1] - R2() * 1.5 * k) + '" width="' + f1(1.2 * k) + '" height="' + f1(0.7 * k) + '" fill="' + ['#ff4f6a', '#ffd84f', '#3ff0ff', '#7dff6a'][i % 4] + '"/>'; });
      if (on) { JX.forEach((x, i) => { const o = p(x, 46, JZ), H = 130 * k;
          f += '<g>' + anK('opacity', '0;1;1;0;0', 2.4, '0;0.04;0.28;0.42;1', -i * 0.08) + '<path d="M' + f1(o[0] - 2 * k) + ' ' + f1(o[1]) + 'L' + f1(o[0] - 16 * k) + ' ' + f1(o[1] - H) + 'Q' + f1(o[0]) + ' ' + f1(o[1] - H - 14 * k) + ' ' + f1(o[0] + 16 * k) + ' ' + f1(o[1] - H) + 'L' + f1(o[0] + 2 * k) + ' ' + f1(o[1]) + 'Z" fill="url(#cjP)" filter="url(#fgb)"/>'
            + rep(7, j => { const y = o[1] - H * (0.2 + j * 0.12), w = (5 + j * 2) * k; return '<ellipse cx="' + f1(o[0] + (j % 2 ? 2 : -2) * k) + '" cy="' + f1(y) + '" rx="' + f1(w) + '" ry="' + f1(w * 0.7) + '" fill="#ffffff" opacity="0.55" filter="url(#fgB)"/>'; }).join('') + '</g>';
          const fl = p(x, 0, JZ); un += '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(34 * k) + '" ry="' + f1(34 * k * SA * 0.6) + '" fill="#bfe8ff" opacity="0.4" filter="url(#fgB)"/>'; });
        rep(26, i => { const R2 = rng('cft' + i), vx = (R2() - 0.5) * 120 * k, H = (90 + R2() * 70) * k, x1 = cm[0] + vx * 0.5, y1 = cm[1] - H, x2 = cm[0] + vx, y2 = cm[1] - H * 0.3 + R2() * 30 * k, b = -1.2 - R2() * 0.1;
          f += '<rect x="0" y="0" width="' + f1(1.6 * k) + '" height="' + f1(0.9 * k) + '" fill="' + ['#ff4f6a', '#ffd84f', '#3ff0ff', '#7dff6a', '#b04bff', '#ffffff'][i % 6] + '">' + atK('translate', pts([cm, cm, [x1, y1], [x2, y2], [x2, y2]]), 2.4, '0;0.5;0.66;0.98;1', b) + anK('opacity', '0;0;1;0.9;0', 2.4, '0;0.5;0.52;0.95;1', b) + '</rect>'; }); }
      const defs = FGD + G('cjP', [[0, '#ffffff', 0.95], [0.7, '#e6f6ff', 0.55], [1, '#e6f6ff', 0]], { a: 'x1="0" y1="1" x2="0" y2="0"' });
      return { defs, under: un, front: f, bb: bbOf([p(-58, 0, 24), p(58, 0, 24), p(-14, 90, -32), p(56, 50, -4), on ? p(0, 190, 0) : p(0, 50, 0), on ? p(-90, 120, 20) : p(0, 0, 0), on ? p(90, 120, 20) : p(0, 0, 0)], 4) }; };
    return D; };

  // ======================= ZERO-G BUBBLE-CLOUD & EUPHORIA MIST MATRIX (obsidian + titanium) =======================
  N.mistMatrix = S => { const on = isOn(S), ICE = '#e6f7ff', RINGS = [[82, 18, 0], [96, 15, 0.9], [108, 11, 1.7]];
    const D = { w: 96, d: 96 };
    D.build = P => [cyl(0, 0, 0, 33, 3.4, '#0c0b10', cer({ n: 30 })), cyl(0, 3.4, 0, 31, 10, OB2, cer({ n: 30, rg: [[0, 0, 1], [10, 0, 0.9]] })), arcW(0, 7.6, 0, 31.4, 31.4, 0.8, 0.9, 0, 2 * PI, CG, em({ n: 30 })),
      cyl(0, 13.4, 0, 28.4, 1.4, TI, mt({ n: 30, shine: 1 })), cyl(0, 14.8, 0, 26.6, 2, OB, cer({ n: 28 })), cyl(0, 16.8, 0, 9.6, 52, OB, cer({ n: 22, rg: [[0, 0, 1.08], [52, 0, 0.88]] })),
      ...[30, 48].map(y => cyl(0, y, 0, 9.9 - (y - 17) * 0.004, 1.4, TI, mt({ n: 22, shine: 1 }))), cyl(0, 68.8, 0, 12.4, 3, TI, mt({ n: 24, shine: 1 })), cyl(0, 71.8, 0, 10.4, 1.4, OB, cer({ n: 22 })), arcW(0, 71.8, 0, 10.6, 10.6, 0.5, 0.6, 0, 2 * PI, ICE, em({ n: 22 }))];
    D.layers = RINGS.map(([y, r, ph]) => ({ anim: '<animateTransform attributeName="transform" type="translate" values="0 0;0 -2.4;0 0" dur="3.4s" begin="' + (-ph) + 's" calcMode="spline" keyTimes="0;0.5;1" keySplines="0.42 0 0.58 1;0.42 0 0.58 1" repeatCount="indefinite"/>',
      build: P => [arcW(0, y, 0, r, r, 2.4, 2.2, 0, 2 * PI, TI, mt({ n: 28, shine: 1 })), arcW(0, y + 2.2, 0, r - 0.4, r - 0.4, 1.2, 0.4, 0, 2 * PI, OB, cer({ n: 28 })), ...rep(6, i => { const a = i * PI / 3 + ph; return cyl(Math.cos(a) * r, y + 2.2, Math.sin(a) * r, 0.9, 1, ICE, em({ n: 8 })); })] }));
    D.layers.push({ anim: '<animateTransform attributeName="transform" type="translate" values="0 0;0 -3.4;0 0" dur="4.2s" calcMode="spline" keyTimes="0;0.5;1" keySplines="0.42 0 0.58 1;0.42 0 0.58 1" repeatCount="indefinite"/>',
      build: P => [ball(0, 116, 0, 9.4, '#eef8ff', cer({ op: 0.4, k: 6, n: 20, shine: 1 })), ball(0, 120.4, 0, 4.4, ICE, em({ k: 4, n: 14 })), arcW(0, 119.6, 0, 9.8, 9.8, 0.6, 0.8, 0, 2 * PI, TI, mt({ n: 24, shine: 1 }))] });
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '', un = '';
      const cg = p(0, 70, 0); bk += '<ellipse cx="' + f1(cg[0]) + '" cy="' + f1(cg[1]) + '" rx="' + f1(30 * k) + '" ry="' + f1(70 * k) + '" fill="url(#mmH)">' + an('opacity', on ? '0.9;1;0.9' : '0.55;0.75;0.55', 4) + '</ellipse>';
      [-1, 1].forEach(s => { const a = p(s * 6.6, 19, 6.6), b = p(s * 6.0, 66, 6.0); f += glowL('M' + P2(a) + 'L' + P2(b), s > 0 ? ICE : CG, 0.45 * k, 'mmB'); });
      const oc = p(0, 120, 0), nb = on ? 22 : 12; rep(nb, i => { const R2 = rng('mb' + i), rx = (16 + R2() * 18) * k, ry = rx * 0.32, cy = oc[1] - (R2() * 26 - 10) * k, d = n4(6 + R2() * 6), r = (1.4 + R2() * 2.4) * k, b = -R2() * d;
        const path = 'M' + f1(oc[0] - rx) + ' ' + f1(cy) + 'A' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(oc[0] + rx) + ' ' + f1(cy) + 'A' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(oc[0] - rx) + ' ' + f1(cy);
        f += '<g><animateMotion dur="' + d + 's" begin="' + n4(b) + 's" repeatCount="indefinite" path="' + path + '"/>' + anK('opacity', '1;1;0.25;0.25;1', d, '0;0.44;0.54;0.94;1', b) + '<circle r="' + f1(r) + '" fill="url(#mmBb)" stroke="#ffffff" stroke-opacity="0.7" stroke-width="' + f1(0.2 * k) + '"/><circle cx="' + f1(-r * 0.35) + '" cy="' + f1(-r * 0.4) + '" r="' + f1(r * 0.24) + '" fill="#ffffff" opacity="0.9"/></g>'; });
      if (on) RINGS.forEach(([y, r, ph], j) => rep(6, i => { const a = i * PI / 3 + ph, q = p(Math.cos(a) * r, y + 2.4, Math.sin(a) * r), ex = q[0] + Math.cos(a - PI / 6) * 22 * k, ey = q[1] - 10 * k + Math.sin(a) * 8 * k, b = -(i * 0.4 + j * 0.2);
        f += '<path d="M' + P2(q) + 'q' + f1(6 * k) + ' ' + f1(-6 * k) + ' ' + f1(ex - q[0]) + ' ' + f1(ey - q[1]) + '" fill="none" stroke="#ffffff" stroke-width="' + f1(2.6 * k) + '" stroke-linecap="round" opacity="0" filter="url(#mmB)">' + an('opacity', '0;0.55;0', 2.4, b) + an('stroke-width', f1(1 * k) + ';' + f1(5 * k), 2.4, b) + '</path>'; }));
      const fl = p(0, 0, 0); un += '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(60 * k) + '" ry="' + f1(60 * k * SA * 0.6) + '" fill="' + CG + '" opacity="' + (on ? 0.3 : 0.16) + '" filter="url(#mmB)"/>';
      const defs = BLUR('mmB', 1.2) + G('mmH', [[0, ICE, 0.45], [0.6, '#bcd8ff', 0.12], [1, '#bcd8ff', 0]], { r: 1 }) + G('mmBb', [[0, '#ffffff', 0.04], [0.7, '#cfeeff', 0.14], [0.86, '#f6c8ff', 0.32], [1, '#9fe6ff', 0.52]], { r: 1 });
      return { defs, under: un, back: bk, front: f, bb: bbOf([p(-36, 160, 0), p(36, 160, 0), p(-36, 0, 36), p(36, 0, -36), p(-36, 0, -36), p(36, 0, 36)], 4) }; };
    return D; };

  // ======================= OMNIDIRECTIONAL SONIC-BEAM & SUB-HARMONIC LEVITATION BASS REACTORS =======================
  N.bassReactor = S => { const play = isPlay(S), ICE = '#e8f4ff', WARM = '#f2d9a6', TX = 44, TZ = -6, GM = '#3a3c44', DRV = [26, 52, 78];
    const D = { w: 150, d: 70 };
    D.build = P => { const o = [];
      [-TX, TX].forEach(x => { o.push(box(x, 0, TZ, 29, 4, 29, '#0c0c10', mt({ r: 3 })), box(x, 4, TZ, 24, 96, 24, OB, cer({ r: 6 })));
        [-1, 1].forEach(s => rep(6, i => o.push(box(x + s * 12.6, 14 + i * 13.6, TZ, 1.8, 8, 19, GM, mt({ r: 0.6, shine: 1 })))));
        o.push(box(x, 100, TZ, 25.6, 3, 25.6, TI, mt({ r: 3, shine: 1 })), box(x, 99.6, TZ, 26, 0.6, 26, CG, em({ r: 3 })), cyl(x, 103, TZ, 7.4, 6, '#0c0c10', cer({ n: 20, rg: [[0, 0, 0.8], [6, 0, 1.1]] })), cyl(x, 108.6, TZ, 8.4, 1.2, TI, mt({ n: 22, shine: 1 })));
        DRV.forEach(y => o.push(disc(x, y, TZ + 12, 8.8, 1, TI, mt({ n: 24, shine: 1 })), disc(x, y, TZ + 13, 7.2, 0.8, '#0a0a0e', cer({ n: 22 })), disc(x, y, TZ + 13.8, 2.6, 1.4, TI, mt({ n: 14, shine: 1 })))); });
      o.push(cyl(0, 0, 4, 21, 3, '#0c0c10', mt({ n: 28 })), cyl(0, 3, 4, 18, 6, OB2, cer({ n: 28, rg: [[0, 0, 1], [6, 0, 0.86]] })), cyl(0, 9, 4, 15.4, 1, TI, mt({ n: 28, shine: 1 })), arcW(0, 10, 4, 12, 12, 0.6, 0.4, 0, 2 * PI, ICE, em({ n: 26 })));
      return o; };
    D.layers = [{ anim: '<animateTransform attributeName="transform" type="translate" values="0 0;0 -3;0 0" dur="' + (play ? 0.9 : 3.6) + 's" calcMode="spline" keyTimes="0;0.5;1" keySplines="0.42 0 0.58 1;0.42 0 0.58 1" repeatCount="indefinite"/>',
      build: P => [ball(0, 21, 4, 15, '#0d0d12', cer({ k: 8, n: 24, shine: 1 })), arcW(0, 35.2, 4, 15.3, 15.3, 0.9, 1.4, 0, 2 * PI, TI, mt({ n: 28, shine: 1 })), arcW(0, 36.6, 4, 15.4, 15.4, 0.4, 0.3, 0, 2 * PI, WARM, em({ n: 28 }))] }];
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      [-TX, TX].forEach((x, i) => { const a = p(x, 8, TZ + 12.3), b = p(x, 96, TZ + 12.3); f += glowL('M' + P2(p(x - 9.6, 9, TZ + 12.3)) + 'L' + P2(p(x - 9.6, 94, TZ + 12.3)), ICE, 0.4 * k, 'brB');
        DRV.forEach((y, j) => { const g = plane(p, TZ + 14.2, y, x); f += '<g transform="' + g + '"><circle r="7.2" fill="url(#brC)"/><circle r="2.2" fill="' + (play ? ICE : '#3a3c44') + '" opacity="' + (play ? 0.9 : 0.6) + '">' + (play ? an('r', '1.8;3;1.8', 0.45, -j * 0.15) : '') + '</circle>'
          + (play ? rep(3, r2 => '<circle r="8" fill="none" stroke="' + (j === 1 ? WARM : ICE) + '" stroke-width="0.6">' + an('r', '8;36', 1.35, -r2 * 0.45 - j * 0.2) + an('opacity', '0.8;0', 1.35, -r2 * 0.45 - j * 0.2) + '</circle>').join('') : '') + '</g>'; });
        const tp = p(x, 109, TZ); if (play) f += '<path d="M' + f1(tp[0] - 4 * k) + ' ' + f1(tp[1]) + 'L' + f1(tp[0] - 16 * k) + ' ' + f1(tp[1] - 90 * k) + 'L' + f1(tp[0] + 16 * k) + ' ' + f1(tp[1] - 90 * k) + 'L' + f1(tp[0] + 4 * k) + ' ' + f1(tp[1]) + 'Z" fill="url(#brBeam)">' + an('opacity', '1;0.4;1', 0.9, -i * 0.45) + '</path>'; });
      const sp = p(0, 21, 4); f += '<circle cx="' + f1(sp[0]) + '" cy="' + f1(sp[1] - 3 * k) + '" r="' + f1(26 * k) + '" fill="none" stroke="' + ICE + '" stroke-width="' + f1(0.35 * k) + '" opacity="0.4" stroke-dasharray="' + f1(2 * k) + ' ' + f1(3 * k) + '">' + atL('rotate', '0 ' + P2(sp) + ';360 ' + P2(sp), play ? 4 : 16) + '</circle>';
      un += '<g transform="' + planeH(p, 0.5, 0, 4) + '">' + rep(play ? 4 : 2, j => '<ellipse rx="20" ry="20" fill="none" stroke="' + (j % 2 ? WARM : ICE) + '" stroke-width="1.1">' + an('rx', '20;' + (play ? 90 : 46), play ? 1.8 : 4, -j * (play ? 0.45 : 2)) + an('ry', '20;' + (play ? 90 : 46), play ? 1.8 : 4, -j * (play ? 0.45 : 2)) + an('opacity', '0.7;0', play ? 1.8 : 4, -j * (play ? 0.45 : 2)) + '</ellipse>').join('') + '</g>';
      const fl = p(0, 0, 0); un += '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(86 * k) + '" ry="' + f1(86 * k * SA * 0.55) + '" fill="' + ICE + '" opacity="' + (play ? 0.24 : 0.12) + '" filter="url(#brB)"/>';
      const defs = BLUR('brB', 1.2) + G('brC', [[0, '#2a2c34'], [0.7, '#0a0a0e'], [1, '#000000']], { r: 1 }) + G('brBeam', [[0, ICE, 0.55], [1, ICE, 0]], { a: 'x1="0" y1="1" x2="0" y2="0"' });
      return { defs, under: un, front: f, bb: bbOf([p(-TX - 16, 112, TZ - 14), p(TX + 16, 112, TZ - 14), p(-TX - 16, 0, TZ + 16), p(TX + 16, 0, TZ + 16), p(0, 0, 40), play ? p(-TX, 200, TZ) : p(0, 0, 0), play ? p(TX, 200, TZ) : p(0, 0, 0)], 4) }; };
    return D; };

  // ======================= DJ BOOTHS (5 booths + 3 deck rigs), creature on the decks =======================
  const DJV = { table: { body: 'table', gear: 'ctrl' }, plywood: { body: 'ply', gear: 'tt' }, truss: { body: 'truss', gear: 'cdj' }, altar: { body: 'altar', gear: 'cdj' }, cyber: { body: 'cyber', gear: 'holo' },
    ctrl: { body: 'desk', gear: 'ctrl' }, vinyl: { body: 'desk', gear: 'tt' }, quad: { body: 'deskW', gear: 'cdj4' } };
  N.djBooth = S => { const V = DJV[S.v] || DJV.plywood, play = isPlay(S), W = V.body === 'deskW' ? 140 : 124, HW = W / 2, DD = 50, TOP = 40, LUX = V.body === 'altar' || V.body === 'cyber' || V.body === 'deskW', CY = LUX ? '#ffcf8a' : '#3ff0ff', MG = LUX ? '#ff9a8a' : '#ff4fb8', BRS = '#c8a050';
    const decks = V.gear === 'cdj4' ? [-58, -30, 30, 58] : V.gear === 'tt' ? [-34, 34] : V.gear === 'ctrl' ? [-22, 22] : [-32, 32], DZ = 2;
    const DR = V.gear === 'tt' ? 12 : V.gear === 'ctrl' ? 9 : 10.5, DY = TOP + (V.gear === 'tt' ? 6.6 : V.gear === 'ctrl' ? 3.4 : V.gear === 'holo' ? 3.6 : 7);
    const D = { w: W + 8, d: DD + 10 };
    D.build = P => { const o = [], b = V.body;
      if (b === 'table') { o.push(box(0, 36.6, 0, W, 3, DD, '#ecebe6', pt({ r: 1.5 })), box(0, 34.6, 0, W - 8, 2, DD - 6, '#8a8f96', mt({ r: 0.4 })));
        [-1, 1].forEach(s => { [-1, 1].forEach(t => o.push(cyl(s * (HW - 8), 0, t * 19, 1.3, 34.6, '#9aa1a8', mt({ n: 8 })))); o.push(box(s * (HW - 8), 8, 0, 1.6, 1.6, 38, '#9aa1a8', mt({ r: 0.6 }))); });
        o.push(slab(0, 6, DD / 2 + 0.6, W - 6, 30, 0.6, '#f1ece0', { r: 1, soft: 1, mat: 'fab' })); }
      else if (b === 'ply') o.push(box(0, 0, 0, W, 38, DD, '#d9b98a', wd({ r: 1 })), box(0, 38, 0, W + 2, 2, DD + 2, '#c49a62', wd({ r: 0.8 })), box(0, 0, 0, W + 1, 3, DD + 1, '#2a2a2e', pt({ r: 0.6 })));
      else if (b === 'truss') { o.push(box(0, 0, -2, W - 8, 36, DD - 8, '#141519', mt({ r: 1 })), box(0, 36, 0, W - 2, 4, DD - 2, '#1b1c21', mt({ r: 1 })));
        [-1, 1].forEach(s => [-1, 1].forEach(t => [0, 1].forEach(e => o.push(cyl(s * (HW - 3 - e * 4), 0, t * (DD / 2 - 3), 1, 36, CH, mt({ n: 8, shine: 1 }))))));
        [0, 34].forEach(y => [-1, 1].forEach(t => o.push(solid({ ax: 'x', sh: 'el', c: [t * (DD / 2 - 3), y + 1], a: 1, b: 1, n: 8, rings: [[-HW + 3, 0], [HW - 3, 0]], col: CH, mat: 'metal', shine: 1 }))));
        o.push(slab(0, 2, DD / 2 + 0.2, W - 4, 32, 1.2, '#cfe8f2', cer({ op: 0.26, r: 1 }))); }
      else if (b === 'altar') o.push(box(0, 0, 0, W, 2.6, DD + 2, '#0a0a0d', cer({ r: 1 })), box(0, 2.6, 0, W, 0.8, DD + 2, BRS, mt({ r: 1, shine: 1 })), box(0, 3.4, 0, W, 0.6, DD + 2, '#0a0a0d', cer({ r: 1 })), prism(-HW, HW, [[-DD / 2, 4], [DD / 2 - 6, 4], [DD / 2 + 1, 16], [DD / 2 - 3, 38], [-DD / 2, 38]], OB, cer()), box(0, 38, 0, W + 1, 0.8, DD + 1, BRS, mt({ r: 0.8, shine: 1 })), box(0, 38.8, 0, W + 1, 1.2, DD + 1, '#2e2418', mt({ r: 0.8, shine: 1 })));
      else if (b === 'cyber') { o.push(box(0, 0, 0, W + 6, 3.4, DD + 8, '#141216', cer({ r: 3 })), box(0, 3.4, 0, W + 6, 0.8, DD + 8, BRS, mt({ r: 3, shine: 1 })), box(0, 4.2, 0, W + 6, 0.8, DD + 8, '#141216', cer({ r: 3 })), box(0, 5, DD / 2 + 3.6, W + 4, 0.8, 0.6, CY, em({ r: 0.3 })));
        [-1, 1].forEach(s => [-1, 1].forEach(t => o.push(cyl(s * (HW - 10), 5, t * 14, 3.2, 6, BRS, mt({ n: 14, shine: 1 })), cyl(s * (HW - 10), 11, t * 14, 1.8, 4, CH, mt({ n: 10, shine: 1 })))));
        o.push(box(0, 15, 0, W, 1.2, DD, BRS, mt({ r: 4, shine: 1 })), box(0, 16.2, 0, W, 21.8, DD, '#1a1418', cer({ r: 4 })), box(0, 15.4, DD / 2 + 0.2, W - 4, 1, 0.6, CY, em({ r: 0.3 })), box(0, 38, 0, W + 1, 0.8, DD + 1, BRS, mt({ r: 1, shine: 1 })), box(0, 38.8, 0, W + 1, 1.2, DD + 1, '#2e2418', mt({ r: 1, shine: 1 }))); }
      else { const gd = b === 'deskW', WN = '#4a2c1a'; o.push(box(0, 36, 0, W, 4, DD - 4, gd ? WN : '#1d1e22', gd ? wd({ r: 1.5 }) : mt({ r: 1.5 })), box(0, 39.6, 0, W + 0.4, 0.6, DD - 3.6, gd ? GOLD : '#2c2e35', mt({ r: 1.5, shine: 1 })));
        [-1, 1].forEach(s => o.push(box(s * (HW - 3), 0, 0, 4, 36, DD - 8, gd ? '#3e2416' : '#26282e', gd ? wd({ r: 1 }) : mt({ r: 1 })), box(s * (HW - 3), 0, 0, 6, 2, DD - 4, gd ? GOLD : '#3a3c44', mt({ r: 0.8 }))));
        o.push(box(0, 8, -12, W - 8, 3, 3, gd ? GOLD : '#26282e', mt({ r: 0.8, shine: gd ? 1 : 0 })), box(0, 33, DD / 2 - 3, W - 6, 1, 0.6, gd ? GOLD : CY, em({ r: 0.3 })));
        if (V.gear === 'tt') o.push(box(-HW + 16, 0, 6, 22, 16, 18, '#3a2a1e', wd({ r: 1 })), ...rep(8, i => slab(-HW + 7.6 + i * 2.4, 2, 6, 0.8, 18, 15, ['#d9363b', '#3f7fc8', '#f2c14a', '#2c2d31', '#4f9a4a', '#e3946a', '#8f7bff', '#f4f1ea'][i], pt({ r: 0.3 })))); }
      // gear
      const g = V.gear;
      if (g === 'ctrl') { o.push(box(0, TOP, DZ, 76, 3.4, 32, '#1a1b20', mt({ r: 2 })), ...decks.map(x => cyl(x, TOP + 3.4, DZ + 2, DR, 0.1, '#2c2e35', mt({ n: 24 }))), box(-HW + 14, TOP, -10, 18, 7, 14, '#9aa3a8', mt({ r: 1 })), slab(-HW + 14, TOP + 7, -16.6, 22, 13, 0.8, '#2a2c33', mt({ r: 1 }))); }
      else if (g === 'tt') { decks.forEach(x => o.push(box(x, TOP, DZ, 36, 5, 32, '#2a2b30', mt({ r: 1.5 })), cyl(x - 2, TOP + 5, DZ + 1, 13, 1.6, '#c9cdd2', mt({ n: 26, shine: 1 })), cyl(x + 13, TOP + 5, DZ - 10, 2, 2, CH, mt({ n: 10 })), box(x + 14, TOP + 5, DZ + 9, 2, 1, 7, '#5a5f6a', mt({ r: 0.4 }))));
        o.push(box(0, TOP, DZ, 24, 6, 30, '#1d1e22', mt({ r: 1.5 }))); }
      else if (g === 'cdj' || g === 'cdj4') { decks.forEach(x => o.push(box(x, TOP, DZ, g === 'cdj4' ? 26 : 30, 6, 36, '#1f2026', mt({ r: 2 })), cyl(x, TOP + 6, DZ + 3, DR, 0.8, '#3a3c44', mt({ n: 26, shine: 1 })), slab(x, TOP + 6, DZ - 13, g === 'cdj4' ? 18 : 22, 6, 1, '#0b0c10', { r: 0.8 })));
        o.push(box(0, TOP, DZ, g === 'cdj4' ? 30 : 24, 7, 36, '#1a1b20', mt({ r: 1.5 })));
        if (g === 'cdj4') rep(4, i => o.push(cyl(-9 + i * 6, TOP + 7, DZ - 4, 2.4, 2.6, GOLD, mt({ n: 14, shine: 1 }))));
        if (V.body === 'truss') o.push(box(-HW + 10, TOP, -14, 14, 6, 12, '#9aa3a8', mt({ r: 1 })), slab(-HW + 10, TOP + 6, -19.6, 18, 11, 0.8, '#2a2c33', mt({ r: 1 }))); }
      else if (g === 'holo') { decks.forEach(x => o.push(box(x, TOP, DZ, 30, 2.4, 30, '#1a1418', cer({ r: 2 })), cyl(x, TOP + 2.4, DZ, 11.4, 0.6, CY, em({ n: 26, op: 0.6 })))); o.push(box(0, TOP, DZ, 22, 3, 30, '#1a1418', cer({ r: 1.5 }))); }
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '', bk = ''; const g = V.gear;
      // deck surfaces (records / jogs / holo rings)
      decks.forEach((x, i) => { const cx = g === 'tt' ? x - 2 : x, cz = DZ + (g === 'tt' ? 1 : g === 'holo' ? 0 : g === 'ctrl' ? 2 : 3), M = planeH(p, DY, cx, cz), spin = play ? atL('rotate', '0;360', g === 'tt' ? 1.8 : 2.4, -i * 0.3) : '';
        let s = '';
        if (g === 'tt') s = '<circle r="' + DR + '" fill="#0d0d10"/>' + rep(5, j => '<circle r="' + f1(DR - 1.6 - j * 1.4) + '" fill="none" stroke="#2c2c32" stroke-width="0.35"/>').join('') + '<g>' + spin + '<circle r="4.2" fill="' + ['#d9363b', '#3f7fc8', '#f2c14a', '#4f9a4a'][i % 4] + '"/><path d="M0 -4.2V-' + DR + '" stroke="#ffffff" stroke-width="0.5" opacity="0.5"/><path d="M-1.6 -2.2h3.2" stroke="#ffffff" stroke-width="0.5"/></g><circle r="0.6" fill="#d5dde2"/><path d="M' + f1(-DR * 0.7) + ' ' + f1(-DR * 0.45) + 'A' + DR + ' ' + DR + ' 0 0 1 ' + f1(DR * 0.2) + ' ' + f1(-DR * 0.95) + '" fill="none" stroke="#ffffff" stroke-width="0.6" opacity="0.25"/>';
        else if (g === 'holo') s = '<g>' + (play ? atL('rotate', '0;360', 1.6, -i * 0.4) : atL('rotate', '0;360', 8)) + '<circle r="' + DR + '" fill="none" stroke="' + CY + '" stroke-width="0.8" stroke-dasharray="3 1.4" opacity="0.9"/><circle r="' + (DR - 3) + '" fill="none" stroke="' + MG + '" stroke-width="0.5" stroke-dasharray="1 1.6"/></g><circle r="3" fill="' + CY + '" opacity="0.5"/>';
        else s = '<circle r="' + DR + '" fill="url(#djJ)"/><circle r="' + f1(DR - 2.2) + '" fill="#202228" stroke="#4a4d58" stroke-width="0.3"/><circle r="' + f1(DR * 0.42) + '" fill="#0b0c10" stroke="' + (play ? CY : '#3a3c44') + '" stroke-width="0.5"/><g>' + spin + '<path d="M0 ' + f1(-DR * 0.42) + 'V' + f1(-DR * 0.2) + '" stroke="' + (play ? CY : '#6a6f78') + '" stroke-width="0.7"/><circle cx="0" cy="' + f1(-DR + 1.1) + '" r="0.5" fill="#9aa3a8"/></g>';
        f += '<g transform="' + M + '">' + s + '</g>';
        if (g === 'tt') { const pv = p(x + 13, TOP + 7, DZ - 10), tip = p(x - 2 + DR * 0.55, DY + 0.6, DZ + 1 + DR * 0.25); f += '<path d="M' + P2(pv) + 'L' + P2(tip) + '" stroke="#d5dde2" stroke-width="' + f1(0.7 * k) + '" stroke-linecap="round"/><rect x="' + f1(tip[0] - 1.2 * k) + '" y="' + f1(tip[1] - 0.8 * k) + '" width="' + f1(2.4 * k) + '" height="' + f1(1.4 * k) + '" fill="#2a2b30"/>'; }
        if (g === 'cdj' || g === 'cdj4') { const sc = surf(p, [x - 9, TOP + 12, DZ - 12.4], [1, 0, 0], [0, -1, 0]); f += '<g transform="' + sc + '"><rect x="0.6" y="0.6" width="16.8" height="4.8" rx="0.5" fill="#0a1830"/><path d="M1.4 3H16.6" stroke="#ff9d3c" stroke-width="0.4"/><path d="' + polyD(rep(16, j => [1.4 + j, 3 + Math.sin(j * 1.7 + i) * 1.4])) + '" fill="none" stroke="#6ac8ff" stroke-width="0.35"/>' + (play ? '<rect x="1.4" y="1" width="0.4" height="4" fill="#ffffff">' + an('x', '1.4;16.4', 2.4, -i * 0.6) + '</rect>' : '') + '</g>'; } });
      // mixer
      { const mw = g === 'cdj4' ? 30 : g === 'tt' ? 24 : g === 'ctrl' ? 24 : 22, my = TOP + (g === 'tt' ? 6 : g === 'ctrl' ? 3.4 : g === 'holo' ? 3 : 7) + 0.1, M = planeH(p, my, 0, DZ); let s = '<rect x="' + f1(-mw / 2 + 1.4) + '" y="-13" width="' + f1(mw - 2.8) + '" height="26" rx="1" fill="' + (g === 'holo' ? '#0a1a24' : '#111216') + '" opacity="0.9"/>';
        const nch = g === 'cdj4' ? 4 : 2; rep(nch, i => { const x = -mw / 2 + 4 + i * (mw - 8) / Math.max(1, nch - 1); s += '<path d="M' + f1(x) + ' -2V7" stroke="#000000" stroke-width="1"/><rect x="' + f1(x - 1.4) + '" y="' + (play ? 0 : 3) + '" width="2.8" height="1.4" rx="0.3" fill="#e8eaee">' + (play ? an('y', '0;4;1;3;0', 1.8, -i * 0.4) : '') + '</rect>'
          + rep(3, j => '<circle cx="' + f1(x) + '" cy="' + (-11 + j * 3) + '" r="1.1" fill="' + (g === 'cdj4' ? GOLD : '#3a3c44') + '" stroke="#9aa3a8" stroke-width="0.2"/>').join('')
          + rep(6, j => '<rect x="' + f1(x + 2.1) + '" y="' + f1(6 - j * 1.3) + '" width="1" height="0.9" fill="' + (j > 4 ? '#ff3b3b' : j > 3 ? '#ffd84f' : '#4fdc6a') + '" opacity="0.25">' + (play ? anD('opacity', rep(5, t => (t * 7 + j * 3 + i * 5) % 6 >= j ? 1 : 0.2).join(';'), 0.5, -i * 0.13) : '') + '</rect>').join(''); });
        s += '<path d="M-6 10.6H6" stroke="#000000" stroke-width="1.2"/><g transform="translate(0 10.6)"><rect x="-1" y="-1.3" width="2" height="2.6" rx="0.3" fill="#e8eaee">' + (play ? an('x', '-1;-6;3;-5;4;-1', 1.2) : '') + '</rect></g>';
        f += '<g transform="' + M + '">' + s + '</g>'; }
      // laptop screen
      if (g === 'ctrl' || (g === 'cdj' && V.body === 'truss')) { const lx = -HW + (g === 'ctrl' ? 14 : 10), ly = TOP + (g === 'ctrl' ? 7 : 6), lz = g === 'ctrl' ? -16.1 : -19.1, sc = surf(p, [lx - 9.5, ly + 11.6, lz], [1, 0, 0], [0, -1, 0]);
        f += '<g transform="' + sc + '"><rect x="0.6" y="0.6" width="17.8" height="10" rx="0.5" fill="#0b1426"/>' + [0, 1].map(j => '<path d="' + polyD(rep(17, t => [1.2 + t, 3.4 + j * 4 + Math.sin(t * 1.3 + j * 2) * 1.2])) + '" fill="none" stroke="' + (j ? MG : CY) + '" stroke-width="0.35"/>').join('') + (play ? '<rect x="9" y="1" width="0.3" height="9.4" fill="#ffffff">' + an('x', '2;16', 2) + '</rect>' : '') + '</g>'; }
      // booth front art
      const FZ = V.body === 'table' ? DD / 2 + 1 : V.body === 'truss' ? DD / 2 + 0.9 : V.body === 'altar' ? DD / 2 + 1.1 : DD / 2 + 0.25, FP = (y, x0) => plane(p, FZ, y, x0);
      if (V.body === 'table') { let s = '<path d="M0 0H' + (W - 6) + 'V30H0Z" fill="url(#djSh)"/>' + rep(6, i => '<path d="M' + (10 + i * 19) + ' 0Q' + (13 + i * 19) + ' 15 ' + (9 + i * 19) + ' 30" stroke="#c9bfa8" stroke-width="0.6" fill="none" opacity="0.6"/>').join('');
          s += '<text x="' + (W / 2 - 3) + '" y="19" text-anchor="middle" font-family="Comic Sans MS, Marker Felt, cursive" font-weight="700" font-size="12" fill="#1d1d22" transform="rotate(-3 ' + (W / 2) + ' 16)">DJ SQUISH</text>' + rep(5, i => '<path d="M' + (34 + i * 13) + ' ' + (20 + (i % 2)) + 'v' + (3 + i % 3) + '" stroke="#1d1d22" stroke-width="0.7" stroke-linecap="round"/>').join('');
          s += '<path d="M92 0L95 6L91 11L96 17L93 24" fill="none" stroke="#8a7f68" stroke-width="0.9"/><path d="M92.5 0L95 6L91 11L96 17L93 24L94.6 23L97.4 16.6L92.6 11L96.6 6L94 0Z" fill="#2a2620" opacity="0.6"/>';
          s += '<rect x="-2" y="-1" width="10" height="4" fill="#b9bdc4" opacity="0.92" transform="rotate(-12 3 1)"/><rect x="' + (W - 14) + '" y="-1" width="10" height="4" fill="#b9bdc4" opacity="0.92" transform="rotate(10 ' + (W - 9) + ' 1)"/><path d="M14 8l1 2 2 0.2-1.6 1.4 0.6 2-2-1-1.8 1 0.4-2-1.4-1.4 2-0.2z" fill="#f2c14a"/>';
          f += '<g transform="' + FP(36, -HW + 3) + '">' + s + '</g>'; }
      else if (V.body === 'ply') { let s = '<rect width="' + W + '" height="38" fill="url(#djPly)"/>' + rep(7, i => '<path d="M0 ' + (4 + i * 5) + 'Q' + (W / 2) + ' ' + (3 + i * 5 + (i % 2 ? 1.5 : -1)) + ' ' + W + ' ' + (5 + i * 5) + '" stroke="#b8925e" stroke-width="0.4" fill="none" opacity="0.6"/>').join('');
          { const BB = [[-16, 0, 7.4], [-6, -3, 8.6], [5, -1, 8], [15, 1, 7], [-10, 6, 6], [9, 6, 6.4], [22, 4, 5]], cx0 = W / 2, cy0 = 19; s += '<g transform="rotate(-4 ' + cx0 + ' ' + cy0 + ')">' + BB.map(([x, y, r]) => '<circle cx="' + (cx0 + x + 1.2) + '" cy="' + (cy0 + y + 1.4) + '" r="' + (r + 1.2) + '" fill="#1d1d22"/>').join('') + BB.map(([x, y, r]) => '<circle cx="' + (cx0 + x) + '" cy="' + (cy0 + y) + '" r="' + (r + 0.9) + '" fill="#ffffff"/>').join('') + BB.map(([x, y, r]) => '<circle cx="' + (cx0 + x) + '" cy="' + (cy0 + y) + '" r="' + r + '" fill="url(#djGr)"/>').join('') + BB.map(([x, y, r]) => '<path d="M' + f1(cx0 + x - r * 0.55) + ' ' + f1(cy0 + y - r * 0.2) + 'q' + f1(r * 0.2) + ' ' + f1(-r * 0.5) + ' ' + f1(r * 0.6) + ' ' + f1(-r * 0.55) + '" stroke="#ffffff" stroke-width="0.9" fill="none" stroke-linecap="round" opacity="0.85"/>').join('') + '<path d="M' + (cx0 - 26) + ' ' + (cy0 - 2) + 'l-5 -3m5 6l-6 1" stroke="#1d1d22" stroke-width="1" stroke-linecap="round"/><path d="M' + (cx0 + 28) + ' ' + (cy0 - 6) + 'l5 -4m-4 8l6 -1" stroke="#1d1d22" stroke-width="1" stroke-linecap="round"/></g>'; } [[3, 3], [W - 3, 3], [3, 35], [W - 3, 35], [W / 2, 3], [W / 2, 35]].forEach(([x, y]) => s += '<circle cx="' + x + '" cy="' + y + '" r="0.8" fill="#8a8f96" stroke="#4a4d52" stroke-width="0.25"/><path d="M' + (x - 0.5) + ' ' + y + 'h1" stroke="#4a4d52" stroke-width="0.25"/>'); s += '<rect x="22" y="4" width="9" height="6" rx="0.6" fill="#f4f1ea" transform="rotate(8 26 7)"/><circle cx="26.4" cy="7" r="1.8" fill="#d9363b" transform="rotate(8 26 7)"/><rect x="' + (W - 44) + '" y="28" width="8" height="8" rx="4" fill="#ffd84f" opacity="0.9"/><path d="M' + (W - 42) + ' 32.6q2 1.6 4 0" stroke="#1d1d22" stroke-width="0.5" fill="none"/>'; rep(14, i => { const R3 = rng('ply' + i); s += '<path d="M' + f1(R3() * W) + ' ' + f1(32 + R3() * 6) + 'l' + f1(2 + R3() * 6) + ' ' + f1((R3() - 0.5) * 1.4) + '" stroke="#3a2a1a" stroke-width="' + f1(0.3 + R3() * 0.5) + '" opacity="0.35"/>'; });
          s += rep(9, i => '<path d="M' + (W / 2 - 22 + i * 5.5) + ' ' + (26 + (i % 3)) + 'v' + (3 + (i * 7) % 5) + '" stroke="' + ['#ff4fb8', '#3ff0ff', '#ffd84f'][i % 3] + '" stroke-width="0.9" stroke-linecap="round"/>').join('');
          s += '<path d="M8 30q6-14 14-6t12-8" fill="none" stroke="#3ff0ff" stroke-width="2.2" stroke-linecap="round"/><path d="M' + (W - 30) + ' 10l4 8 8 1-6 5 2 8-8-4-7 4 2-8-6-5 8-1z" fill="#ffd84f" stroke="#1d1d22" stroke-width="0.6"/><path d="M' + (W - 14) + ' 30c-3-6 3-10 0-16" stroke="#ff4fb8" stroke-width="1.8" fill="none" stroke-linecap="round"/><circle cx="14" cy="10" r="3" fill="#7dff6a" opacity="0.85"/>';
          rep(30, i => { const R2 = rng('spr' + i); s += '<circle cx="' + f1(R2() * W) + '" cy="' + f1(R2() * 36) + '" r="' + f1(0.2 + R2() * 0.4) + '" fill="' + ['#ff4fb8', '#3ff0ff', '#1d1d22'][i % 3] + '" opacity="0.7"/>'; });
          f += '<g transform="' + FP(38, -HW) + '">' + s + '</g>'; }
      else if (V.body === 'truss') { const s = '<rect width="' + (W - 4) + '" height="32" rx="1" fill="url(#djAc)">' + an('opacity', play ? '1;0.6;1' : '0.7;0.85;0.7', play ? 0.9 : 3) + '</rect><text x="' + (W / 2 - 2) + '" y="20" text-anchor="middle" font-family="Arial Black, Arial, sans-serif" font-weight="900" font-size="9" fill="none" stroke="#e8fdff" stroke-width="0.5" opacity="0.8" letter-spacing="2">SQUISH</text><rect width="' + (W - 4) + '" height="32" rx="1" fill="none" stroke="' + CY + '" stroke-width="0.8" opacity="0.9"/>';
          f += '<g transform="' + FP(34, -HW + 2) + '">' + s + '</g>'; }
      else if (V.body === 'altar') { const R2 = rng('alt'), cols = 9, rows = 3, cw = W / cols, rh = 12; let s = '';
          for (let r = 0; r < rows; r++) for (let i = 0; i < cols; i++) { const x = i * cw, y = r * rh + (r === 2 ? 0 : 0), j = (R2() - 0.5) * 3, tri = [[x, y], [x + cw, y + j * 0.5], [x + cw * 0.5 + j, y + rh]], tri2 = [[x + cw, y + j * 0.5], [x + cw * 1.5 + j, y + rh], [x + cw * 0.5 + j, y + rh]], mirror = R2() < 0.3;
            s += '<path d="' + polyD(tri) + 'Z" fill="' + (mirror ? 'url(#djMi)' : mix(OB, '#3a3026', R2() * 0.6)) + '" stroke="#8a6c3a" stroke-width="0.3"/>' + (i < cols - 1 ? '<path d="' + polyD(tri2) + 'Z" fill="' + mix(OB, '#2e261e', R2()) + '" stroke="#8a6c3a" stroke-width="0.3"/>' : '');
            if (mirror) s += '<path d="' + polyD(tri) + 'Z" fill="#ffffff" opacity="0">' + an('opacity', '0;0.6;0', 2.6, -R2() * 2.6) + '</path>'; }
          s += '<path d="M0 6L' + W + ' 30M0 30L' + W + ' 4" stroke="' + (play ? '#ffd28a' : '#b8945a') + '" stroke-width="0.6" stroke-dasharray="6 60" fill="none">' + an('stroke-dashoffset', '0;-132', play ? 1.4 : 4) + '</path>';
          f += '<g transform="' + FP(37, -HW) + '"><g clip-path="url(#djAlt)">' + s + '</g></g>'; }
      else if (V.body === 'cyber') { const hc = p(0, TOP + 1, 0); f += '<g opacity="0.85"><ellipse cx="' + f1(hc[0]) + '" cy="' + f1(hc[1]) + '" rx="' + f1((HW + 14) * k) + '" ry="' + f1((HW + 14) * k * SA * 0.62) + '" fill="none" stroke="' + CY + '" stroke-width="' + f1(0.6 * k) + '" stroke-dasharray="' + f1(5 * k) + ' ' + f1(3 * k) + '">' + an('stroke-dashoffset', '0;' + f1(-32 * k), play ? 0.8 : 3) + '</ellipse><ellipse cx="' + f1(hc[0]) + '" cy="' + f1(hc[1] - 8 * k) + '" rx="' + f1((HW + 8) * k) + '" ry="' + f1((HW + 8) * k * SA * 0.62) + '" fill="none" stroke="' + MG + '" stroke-width="' + f1(0.4 * k) + '" opacity="0.6"/></g>';
        const fl = p(0, 5, 0); un += '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(HW * 1.1 * k) + '" ry="' + f1(HW * 1.1 * k * SA * 0.6) + '" fill="' + CY + '" opacity="0.35" filter="url(#djB)"/>'; }
      // EQ visualizer strip on the front face
      if (play) { const n = 22, ew = W * 0.62, x0 = -ew / 2, bw = ew / n, ey = V.body === 'table' ? 3 : V.body === 'ply' ? 3.2 : V.body === 'altar' ? 3 : 4, eh = V.body === 'truss' ? 12 : 8, yb = TOP - ey - 1 - eh;
        let s = '<rect x="' + f1(x0 - 1.2) + '" y="0" width="' + f1(ew + 2.4) + '" height="' + (eh + 2) + '" rx="1" fill="#08090c" opacity="0.88"/>';
        rep(n, i => { const R2 = rng('eq' + i + S.v), hs = rep(7, () => f1(1 + R2() * (eh - 1))), h0 = play ? hs[0] : '1'; s += '<rect x="' + f1(x0 + i * bw + 0.3) + '" y="' + f1(eh + 1 - h0) + '" width="' + f1(bw - 0.6) + '" height="' + h0 + '" fill="url(#' + (LUX ? 'djEqW' : 'djEq') + ')">' + (play ? an('height', hs.concat(hs[0]).join(';'), n4(0.7 + R2() * 0.5)) + an('y', hs.concat(hs[0]).map(h => f1(eh + 1 - h)).join(';'), n4(0.7 + R2() * 0.5)) : an('opacity', '0.4;0.8;0.4', 2.4, -i * 0.1)) + '</rect>'; });
        f += '<g transform="' + plane(p, FZ + 0.2, yb + eh + 2, 0) + '">' + s + '</g>'; }
      // DJ on the decks: the creature sprite (dj-crew.js) wears shades + headset and does its own arms; the booth only adds notes + sound rings
      if (play) {
        rep(6, i => { const s = i % 2 ? 1 : -1, st = p(s * (HW + 4), TOP + 14, 12), R2 = rng('nt' + i), dx = s * (14 + R2() * 18) * k, dy = -(50 + R2() * 30) * k, b = -i * 0.45;
          f += '<g transform="translate(' + P2(st) + ')">' + atL('translate', P2(st) + ';' + f1(st[0] + dx) + ' ' + f1(st[1] + dy), 2.7, b) + an('opacity', '0;1;1;0', 2.7, b) + '<g transform="scale(' + n4(k * 1.1) + ')"><path d="M0 0V-7L5 -8.6V-1.6" fill="none" stroke="' + [CY, MG, '#ffd84f'][i % 3] + '" stroke-width="1"/><ellipse cx="-1.3" cy="0.2" rx="1.6" ry="1.2" fill="' + [CY, MG, '#ffd84f'][i % 3] + '"/><ellipse cx="3.7" cy="-1.4" rx="1.6" ry="1.2" fill="' + [CY, MG, '#ffd84f'][i % 3] + '"/></g></g>'; });
        un += '<g transform="' + planeH(p, 0.4, 0, 0) + '">' + rep(3, j => '<ellipse rx="' + HW + '" ry="' + (DD * 0.8) + '" fill="none" stroke="' + (j % 2 ? MG : CY) + '" stroke-width="1.4">' + an('rx', HW + ';' + (HW + 70), 2.1, -j * 0.7) + an('ry', DD * 0.8 + ';' + (DD * 0.8 + 70), 2.1, -j * 0.7) + an('opacity', '0.8;0', 2.1, -j * 0.7) + '</ellipse>').join('') + '</g>';
        const fl = p(0, 0, 0); un += '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(HW * 1.4 * k) + '" ry="' + f1(HW * 1.4 * k * SA * 0.6) + '" fill="' + MG + '" opacity="0.2" filter="url(#djB)">' + an('fill', MG + ';' + CY + ';' + MG, 2.4) + '</ellipse>'; }
      const defs = PAW + BLUR('djB', 1.4) + G('djJ', [[0, '#5a5f6a'], [0.5, '#2a2c33'], [1, '#14151a']], { r: 1, a: 'cx="40%" cy="35%" r="70%"' }) + G('djEq', [[0, '#ff4fb8'], [0.5, '#ffd84f'], [1, '#3ff0ff']], { a: 'x1="0" y1="0" x2="0" y2="1"' }) + G('djEqW', [[0, '#fff0c8'], [0.5, '#ffd28a'], [1, '#e8945a']], { a: 'x1="0" y1="0" x2="0" y2="1"' })
        + G('djSh', [[0, '#f6f2e8'], [0.5, '#ece4d2'], [1, '#d9cfb8']], { a: 'x1="0" y1="0" x2="0" y2="1"' }) + G('djPly', [[0, '#e2c496'], [1, '#c9a46e']], { a: 'x1="0" y1="0" x2="1" y2="1"' }) + G('djGr', [[0, '#ff4fb8'], [0.5, '#ffd84f'], [1, '#3ff0ff']])
        + G('djAc', [[0, '#ffffff', 0.55], [0.5, '#f2f0ec', 0.3], [1, '#ffe6c4', 0.5]], { a: 'x1="0" y1="0" x2="1" y2="1"' }) + G('djMi', [[0, '#fff6e6'], [0.45, '#b8a68a'], [0.55, '#f2e6d0'], [1, '#7a6a54']], { a: 'x1="0" y1="0" x2="1" y2="1"' })
        + '<clipPath id="djAlt"><rect width="' + W + '" height="34"/></clipPath>';
      return { defs, under: un, back: bk, front: f, bb: bbOf([p(-HW - 6, TOP + 20, -DD / 2 - 6), p(HW + 6, TOP + 20, -DD / 2 - 6), p(-HW - 6, 0, DD / 2 + 6), p(HW + 6, 0, DD / 2 + 6), p(-HW - 30, TOP + 70, 12), p(HW + 30, TOP + 70, 12)].concat(plBB(p, PL.djBooth)), 3) }; };
    return D; };

  // ======================= MODERN COMPACT MICROWAVE (graphite + black glass) on an oak stool =======================
  N.microLux = S => { const OAK = '#c99a62', GR = '#2b2d31', SS = '#cfd3d8';
    const D = { w: 58, d: 48 };
    D.build = P => { const o = [];
      [[-12, -10], [12, -10], [-12, 10], [12, 10]].forEach(([x, z]) => o.push(cyl(x, 0, z, 1.3, 36, '#1d1d20', mt({ n: 8 }))));
      o.push(arcW(0, 11, 0, 13.4, 11.4, 1.1, 1.1, 0, 2 * PI, '#1d1d20', mt({ n: 24 })), cyl(0, 36, 0, 20, 3.2, OAK, wd({ rz: 16.5, n: 30, rg: [[0, 0, 0.96], [2.2, 0, 1], [3.2, 0, 0.97]] })));
      [[-17, -11], [17, -11], [-17, 11], [17, 11]].forEach(([x, z]) => o.push(cyl(x, 39.2, z, 1.4, 0.8, '#111114', { n: 8 })));
      o.push(box(0, 40, 0, 44, 25, 31, GR, mt({ r: 3.4 })), slab(0, 40.4, 15.6, 43.2, 24.2, 0.6, SS, mt({ r: 3.2, shine: 1 })), slab(-5.2, 41.4, 16.1, 32, 22.2, 0.7, '#0c0d10', cer({ r: 2.2 })), slab(16.2, 41.4, 16.1, 9.2, 22.2, 0.7, '#141518', cer({ r: 1.8 })), box(10.4, 43, 16.6, 0.8, 18, 1.2, SS, mt({ r: 0.4, shine: 1 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '';
      f += '<g transform="' + plane(p, 16.9, 61.4, -19) + '"><rect x="0.6" y="0.6" width="26" height="17" rx="1.6" fill="url(#mlW)">' + an('opacity', '0.8;1;0.8', 2.2) + '</rect><g transform="translate(13.6 13.4)"><ellipse rx="9" ry="1.8" fill="#ffffff" opacity="0.3"/><g>' + atS('scale', '1 1;0.6 1;1 1', 3) + '<path d="M-3.6 0L-3 -6Q0 -7.6 3 -6L3.6 0Z" fill="#f6efdc" stroke="#cbb48a" stroke-width="0.3"/><g>' + atS('scale', '1 1;1.06 1.12;1 1', 1.4) + '<rect x="-2.8" y="-4.6" width="5.6" height="1.6" fill="#d9363b"/></g></g></g>'
        + '<rect x="0.6" y="0.6" width="26" height="17" rx="1.6" fill="url(#mlG)"/><path d="M4 2L10 17" stroke="#ffffff" stroke-width="0.6" opacity="0.18"/></g>';
      f += '<g transform="' + plane(p, 16.9, 62.4, 12.2) + '"><rect x="0.6" y="1" width="7.2" height="3.4" rx="0.6" fill="#05070a"/><text x="4.2" y="3.6" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="2.5" fill="#7fe8ff">1:30' + anD('opacity', '1;0.55', 1) + '</text>'
        + '<circle cx="4.2" cy="9.4" r="2.6" fill="none" stroke="#7fe8ff" stroke-width="0.35" opacity="0.8"/><circle cx="4.2" cy="9.4" r="1.9" fill="#1d1f24" stroke="' + SS + '" stroke-width="0.3"/>' + rep(4, i => '<circle cx="' + (1.8 + i * 1.6) + '" cy="14.6" r="0.5" fill="#9aa3a8"/>').join('') + '<rect x="1.4" y="17" width="5.6" height="2" rx="0.5" fill="none" stroke="#4fdc6a" stroke-width="0.3"/></g>';
      let v = ''; rep(7, i => v += '<path d="M' + (3 + i * 3.4) + ' 4V15" stroke="#1a1b1e" stroke-width="0.7" stroke-linecap="round"/>'); f += '<g transform="' + RD.H3.planeX(p, 22.15, 62, -10) + '">' + v + '</g>';
      const tp = surf(p, [-22, 65.1, -15.5], [1, 0, 0], [0, 0, 1]); f += '<g transform="' + tp + '"><rect x="1" y="1" width="42" height="29" rx="3" fill="url(#mlT)"/></g>';
      const defs = G('mlW', [[0, '#ffe6a8'], [0.6, '#f2b45a'], [1, '#8a4f1e']], { r: 1, a: 'cx="50%" cy="65%" r="75%"' }) + G('mlG', [[0, '#0a0b0e', 0.55], [0.4, '#0a0b0e', 0.2], [0.55, '#ffffff', 0.12], [0.6, '#0a0b0e', 0.25], [1, '#0a0b0e', 0.55]], { a: 'x1="0" y1="0" x2="1" y2="1"' })
        + G('mlT', [[0, '#ffffff', 0.18], [0.5, '#ffffff', 0], [1, '#000000', 0.15]], { a: 'x1="0" y1="0" x2="1" y2="1"' });
      return { defs, front: f }; } ;
    return D; };

  // ---------- draw hook: creature players + fog emitters (projected into viewBox space) ----------
  const draw4 = RD.draw;
  RD.draw = (r, o) => { const res = draw4(r, o); if (!res || res._p5) return res; res._p5 = 1;
    try { const p = RD.projOf(1), sp = r.spec ? r.spec.split(/[.@*+]/)[0] : '';
      if (PL[sp] && res.bb) res.players = plOf(sp, o && o.st).map(q => { const s = p(q.x, 0, q.z); return { x: s[0], y: s[1], v: q.v, a: q.a, b: !!q.b, d: q.d || 0 }; });
      if (r.fog && res.bb) { const F = r.fog, pr = q => p(q[0], q[1], q[2]), o0 = p(0, 0, 0), dv = pr(F.dir || [1, 0, 0]), dl = Math.hypot(dv[0] - o0[0], dv[1] - o0[1]) || 1;
        res.fog = { t: F.t, style: F.style, tint: F.tint, pts: F.at.map(pr), dir: [(dv[0] - o0[0]) / dl, (dv[1] - o0[1]) / dl], fl: pr(F.fl || [F.at[0][0], 0, F.at[0][2]]), cf: F.cf ? pr(F.cf) : null }; }
    } catch (e) { console.warn('reno plus5', r.id, e); }
    return res; };

  // ---------- catalog edits ----------
  const DJN = 'Tap the booth and a creature steps up in boss shades and a studio headset: one paw holding the ear cup, the other pumping the crowd, head bobbing to the beat while the decks spin and the EQ pumps.';
  RD.SET5 = {
    'CLB-031': { spec: 'pinball5', play: 'pin', live: 'Playable', note: 'A classic pinball cabinet: angled playfield under glass, two flippers, three pop bumpers, slingshots, a lit backglass with a score display and neon trim. Tap to play a ball.' },
    'CLB-051': { spec: 'danceCab', play: 'dance', live: '2-player', note: 'An upright rhythm cabinet with a big screen, light-up marquee and two floor pads. Arrows scroll up the screen and the pad panels light on the beat. Tap and two creatures dance.' },
    'CLB-071': { spec: 'glowTable', play: 'table', live: '2-player', modes: ['Air Hockey', 'Billiards'], modeLbl: 'GAME', note: 'A flip-top glow table: an icy air-hockey surface or a UV billiards felt with LED pockets. Tap and two creatures play a live match.' },
    'CLB-010': { spec: 'bubbleFan', live: 'Blows bubbles', fog: { t: 1, style: 'bubble', at: [[0, 82, 10]], dir: [0.5, 0.25, 0.87] }, note: 'A retro floor fan that turns side to side, with a bubble-wand wheel spinning through a soap tray in front of the grille. Tap to switch on more bubbles.' },
    'CLB-030': { spec: 'fogMini', live: 'Fog · light', fog: { t: 2, style: 'jet', at: [[27, 15, 0]], dir: [1, 0.05, 0.3], fl: [40, 0, 10] }, note: 'A small Halloween fog machine with a carry handle, fluid tank and wired remote. Tap for short, light puffs that clear quickly.' },
    'CLB-050': { spec: 'hazer', live: 'Haze · medium', fog: { t: 3, style: 'haze', at: [[12, 31, 0]], dir: [1, 0.1, 0.35], fl: [20, 0, 20], tint: ['#f2efff', '#d6c8ff', '#f6f6fa'] }, note: 'A pro hazer on a road case with two UV blacklight cannons. Tap for a wider haze that settles into a low fog bank under UV light.' },
    'CLB-070': { spec: 'cryoJets', live: 'CO2 · heavy', fog: { t: 4, style: 'up', at: [[-40, 47, 10], [40, 47, 10]], fl: [0, 0, 16], cf: [6, 36, 24], tint: ['#ffffff', '#e6f4ff'] }, note: 'Two cryo CO2 jets on a steel tank shoot freezing white columns, and a confetti cannon fires on the beat. Tap for dense bursts and a thick, lasting floor fog.' },
    'CLB-090': { spec: 'mistMatrix', live: 'Mist · max', fog: { t: 5, style: 'mist', at: [[0, 84, 0], [0, 98, 0], [0, 110, 0]], fl: [0, 0, 0], tint: ['#f6fbff', '#eaf2ff', '#fff4e6'] }, note: 'An obsidian and titanium column with three floating mist rings and a zero-gravity bubble cloud. Tap for the densest, longest-lasting mist in the club.' },
    'CLB-082': { spec: 'bassReactor', live: 'Bass + haze', fog: { t: 5, style: 'ring', at: [[0, 6, 4]], fl: [0, 0, 4], tint: ['#eef6ff', '#f6ead6'] }, note: 'Twin obsidian reactor towers with titanium drivers and a black-glass sub sphere levitating between them. Tap to play: sonic beams pulse and a haze ring rolls out across the floor.' },
    'CLB-015': { spec: 'djBooth', sx: { v: 'table' }, play: 'dj', live: 'DJ set', note: 'A folding table with a cracked bed-sheet banner and a cheap 2-deck controller. ' + DJN },
    'CLB-035': { spec: 'djBooth', sx: { v: 'plywood' }, play: 'dj', live: 'DJ set', note: 'A plywood booth with a graffiti front, two turntables and a club mixer. ' + DJN },
    'CLB-055': { spec: 'djBooth', sx: { v: 'truss' }, play: 'dj', live: 'DJ set', note: 'Brushed aluminium truss with an edge-lit acrylic shield, two CDJs, a mixer and a laptop. ' + DJN },
    'CLB-075': { spec: 'djBooth', sx: { v: 'altar' }, play: 'dj', live: 'DJ set', note: 'A faceted obsidian altar with mirror shards and projection-mapped light lines. ' + DJN },
    'CLB-095': { spec: 'djBooth', sx: { v: 'cyber' }, play: 'dj', live: 'DJ set', note: 'A booth lifted on hydraulic pistons, with holographic jog rings and a 360° hologram halo. ' + DJN },
    'CLB-038': { spec: 'djBooth', sx: { v: 'ctrl' }, play: 'dj', live: 'DJ set', note: 'A 2-channel controller and laptop on a black DJ desk. ' + DJN },
    'CLB-058': { spec: 'djBooth', sx: { v: 'vinyl' }, play: 'dj', live: 'DJ set', note: 'Two direct-drive turntables and a 4-channel mixer, with a crate of records under the desk. ' + DJN },
    'CLB-078': { spec: 'djBooth', sx: { v: 'quad' }, play: 'dj', live: 'DJ set', note: 'Four flagship CDJs around a gold rotary mixer on a wide gold-trimmed desk. ' + DJN },
    'MOV-011': { spec: 'microLux', name: 'Compact Graphite Microwave on an Oak Stool', live: 'Popping', note: 'A modern compact microwave: graphite body, flush black-glass door, touch strip with a glowing timer, on a round oak stool. Popcorn puffs up inside.' },
  };
  const edit4 = RD.edit;
  RD.edit = rows => edit4(rows).map(r => RD.SET5[r.id] ? Object.assign({}, r, RD.SET5[r.id]) : r);
  RD.PLUS5 = 1;
})();
