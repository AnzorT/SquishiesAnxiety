// Squad House batch 7 = the rest of Furniture Animations List.md: kick ball (once), eat from bowl, wash dishes, toaster (wait hold + pop/catch once), grill,
// bouncy pouf (in / hold / out), pool splash (in / hold / out), pick up shell (once), stage perform, DJ booth, pinball, dance cabinet, air hockey, billiards,
// backyard games g_goal g_keep g_hoop g_golf g_dome g_agility g_bocce g_pong g_tether g_villa g_cornhole g_hop g_shoe g_tunnel g_frisbee + g_cheer (spectator).
// cBuild(key, X): X = BB[key] ([B] table: cheer, cheerFx, play sig p, tk trick) + house-cx-c.js extras (ks kick style foot/head/tail/body/flip, mc mic colour, pc prop colour).
// Holds loop until the house sends him elsewhere; props are drawn per frame from st.beats + st.rec moments (same pattern as bBuild).
window.HouseCreatures = window.HouseCreatures || []; window.HouseCreatures.push(function (H) {
  const R = window.RiveRig, REST = R.REST, { TL, BEAT, hand, both, SIDE, SIT0, PROF, BB, ICON, o, sitdown, standup, gnd, rside, G, facing, ss, cl, r2, shade, ci, pa, lerp, okp, BATH0 } = H;
  if (!sitdown || !G) { console.warn('house-cx: house-moves.js too old'); return; }
  const K = Object.keys;
  const ST0 = { sq: 0, lift: 0, pitch: 0, lx: 0, ly: 0, smile: 0.7, hap: 0.3, armL: 20, armR: 20, hLx: 0, hLy: 0, hRx: 0, hRy: 0, footL: 0, footR: 0, lean: 0, tilt: 0, x: 0, open: 0, mw: 1, puff: 0, htilt: 0, close: 0, wide: 0, sqz: 0, turn: 0, spin: 0, tongue: 0, winkL: 0, winkR: 0, frown: 0 };
  const S0 = (x, ...a) => o(ST0, ...a, x || {});
  function hold(B, ord, BK, X, sig, gaps, ex) {
    const t = TL(B), v = {}; K(B).forEach(p => v[p] = B[p]); t.to(10, v); t.B = o(REST, B); const bt = [], rec = {};
    ord.forEach((n, i) => { t.wait(gaps[i % gaps.length]); const a = t.t; if (n === 'sig') { if (!sig) return; sig(t); } else if (BK[n]) BK[n](t, X, rec); else if (BEAT[n]) BEAT[n](t); else return; bt.push([n, a, t.t]); });
    t.wait(800); const st = t.out(o({ breathe: 0.5, look: false, blend: 420 }, ex || {}), true); st.beats = bt; st.rec = rec; return st;
  }
  // last launch <= tl -> [phase fly|away|ret, u, launch time, elapsed]
  const flyF = (L, tl, F) => { let e = null; (L || []).forEach(v => { if (v <= tl) e = v; }); if (e == null) return null; const d = tl - e;
    if (d < F.fly) return ['fly', d / F.fly, e, d]; if (d < F.away) return ['away', 1, e, d]; if (d < F.away + F.ret) return ['ret', (d - F.away) / F.ret, e, d]; return null; };
  const g0 = I => { const [gx, gy] = gnd(I); return [gx - ((I.lastP && I.lastP.x) || 0), gy]; }; // ground point under his rest spot (ignores the x shuffle)
  const mid = W => okp(W.pawL) && okp(W.pawR) ? [(W.pawL[0] + W.pawR[0]) / 2, (W.pawL[1] + W.pawR[1]) / 2] : W.pawR;
  const hx = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)), mixC = (a, b, u) => { const A = hx(a), B = hx(b); return 'rgb(' + A.map((v, i) => Math.round(v + (B[i] - v) * cl(u, 0, 1))).join(',') + ')'; };
  const push = (rec, k, v) => (rec[k] = rec[k] || []).push(v);

  // ---------- shared reactions ----------
  function cheer(t, X, ex) { const B = t.B, L = B.lift || 0, Q = B.sq || 0;
    t.to(260, o({ armL: 150, armR: 150, hLx: 0, hRx: 0, hLy: -4, hRy: -4, hap: 1, smile: 1, open: 0.5, mw: 1, wide: 0.4, sq: Q - 0.04, frown: 0 }, ex || {}, X.cheer), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('spark', 'head', 3);
    t.to(150, { lift: L + 5, sq: Q - 0.08 }, 'o').to(170, { lift: L, sq: Q + 0.06 }, 'i').to(150, { sq: Q }, 'o').osc(800, 3, { armL: 130, armR: 165 }, { armL: 165, armR: 130 }, 'io'); return t.back(420); }
  function frown(t) { const B = t.B, Q = B.sq || 0; t.to(240, { frown: 0.5, wide: 0.6, open: 0.3, mw: 0.5, sq: Q + 0.05, pitch: (B.pitch || 0) - 0.1 }, 'o').wait(600)
    .to(260, { frown: 0, sqz: 0.6, hap: 0.8, smile: 1, wide: 0, open: 0.25, mw: 1 }, 'o').osc(700, 3, { sq: Q + 0.03 }, { sq: Q }, 'o'); return t.back(380); }
  const COM = {
    yay(t, X) { cheer(t, X); return t; }, oops(t) { frown(t); return t; },
    watch(t) { t.to(320, o(hand(1, 6, -15), { armR: 118, lx: 0.9, ly: -0.2, htilt: 6, lean: 0.4 }), 'io').wait(900).to(240, { lx: 0.6, ly: 0.2 }).wait(400); return t.back(380); },
    pant(t) { const Q = t.B.sq || 0; t.to(200, { open: 0.45, mw: 0.7, tongue: 0.4, close: 0.3 }).osc(1200, 8, { sq: Q + 0.03 }, { sq: Q - 0.01 }, 'l').fx('sweat', 'head', 1); return t.back(300); },
    clap(t) { t.to(240, o(both(10, -6), { armL: 40, armR: 40, hap: 1, smile: 1, open: 0.3 }), 'o'); for (let i = 0; i < 5; i++) t.to(110, { hLx: 6, hRx: -6 }, 'l').to(110, { hLx: 11, hRx: -11 }, 'l'); return t.back(340); },
  };
  // the kick itself in his own style; returns the moment the ball is hit
  function kickCore(t, X) { const ks = X.ks || 'foot'; let hit;
    if (ks === 'head') { t.to(300, { pitch: 0.12, lean: -1, sq: 0.08, lift: -0.6 }, 'io').to(140, { pitch: -0.34, lean: 1.6, sq: -0.06, lift: 2.4, close: 1 }, 'o'); hit = t.t; t.fx('spark', 'head', 3).to(260, { pitch: 0, lean: 0.4, lift: 0, sq: 0.04, close: 0 }, 'io'); }
    else if (ks === 'tail') { t.to(320, { spin: -40, sq: 0.06, wag: -20, tsw: -0.6 }, 'io').to(220, { spin: 150, wag: 34, tsw: 1, sq: -0.04 }, 'o'); hit = t.t - 80; t.fx('splash', 'body', 2).to(420, { spin: 0, wag: 0, tsw: 0, sq: 0 }, 'io'); }
    else if (ks === 'body') { t.to(320, { x: -1.6, tilt: -6, sq: 0.1, lean: -0.8 }, 'io').to(150, { x: 2.4, tilt: 8, sq: -0.08, lean: 1.4, lift: 2 }, 'o'); hit = t.t; t.fx('dust', 'belly', 3).to(300, { x: 0, tilt: 0, sq: 0.04, lean: 0, lift: 0 }, 'i'); }
    else if (ks === 'flip') { t.to(320, o(hand(1, -6, -2), { armR: 70, lean: -0.8, tilt: -3 }), 'io').to(150, o(hand(1, 10, 4), { armR: 18, lean: 1.2, tilt: 4, sq: -0.04 }), 'o'); hit = t.t; t.to(300, o(hand(1, 0, 0), { armR: 20, lean: 0, tilt: 0, sq: 0 }), 'io'); }
    else { t.to(300, { lean: -1, footR: 0.4, armL: 50, armR: 4, sq: 0.06, tilt: -2 }, 'io').to(130, { lean: 1.4, footR: 3.6, armL: 10, armR: 64, sq: -0.05, lift: 1.4, tilt: 3 }, 'o'); hit = t.t - 30; t.fx('dust', 'footR', 3).to(280, { footR: 0, lean: 0.3, lift: 0, sq: 0.03, tilt: 0, armL: 20, armR: 20 }, 'io'); }
    return hit; }
  function kickMove(X) { const t = TL(REST); t.B = o(REST);
    t.to(320, { lx: 0.7, ly: 0.6, pitch: -0.1, sqz: 0.3, smile: 0.8, hap: 0.5 }, 'io'); const hit = kickCore(t, X);
    t.to(320, o(hand(1, 6, -15), { armR: 118, lx: 0.9, ly: -0.3, htilt: 6, wide: 0.5, open: 0.3, mw: 0.6, sqz: 0 }), 'io').wait(700);
    t.to(240, o({ armR: 150, armL: 150, hRx: 0, hRy: -4, hLy: -4, hap: 1, smile: 1, sqz: 0.7, open: 0.4, mw: 1, htilt: 0, wide: 0, lx: 0.4 }, X.cheer), 'o').to(140, { lift: 4, sq: -0.06 }, 'o').to(160, { lift: 0, sq: 0.05 }, 'i');
    t.back(420); const st = t.out({ next: 'idle', blend: 180 }); st.hit = hit; return st; }

  // ---------- eat from the bowl (standing, head down in the bowl) ----------
  const BW0 = S0({ pitch: -0.3, ly: 0.9, sq: 0.07, armL: 12, armR: 12, smile: 0.8, hap: 0.4 }, both(4, 4));
  const BWB = {
    munch(t, X, rec) { const B = t.B; t.to(260, { pitch: B.pitch - 0.12, sq: B.sq + 0.03, lift: -0.6, open: 0.4 }, 'io'); push(rec, 'bite', t.t);
      t.osc(1200, 4, { open: 0.42, puff: 0.15 }, { open: 0, puff: 0.5 }, 'l').fx('crumb', 'mouth', 3).osc(600, 2, { open: 0.38 }, { open: 0, puff: 0.4 }, 'l'); return t.back(300); },
    up(t) { t.to(340, { pitch: 0.04, ly: -0.1, lx: 0.5, sq: 0, puff: 0.4 }, 'io').osc(900, 4, { puff: 0.55 }, { puff: 0.2 }, 'l').to(420, { lx: -0.5, htilt: -4 }, 'io').osc(700, 3, { puff: 0.5 }, { puff: 0.15 }, 'l').to(200, { puff: 0 }); return t.back(380); },
    slurp(t) { const B = t.B; t.to(280, { pitch: B.pitch - 0.16, sq: B.sq + 0.04, close: 0.6 }, 'io').osc(1100, 6, { tongue: 0.6, sq: B.sq + 0.05 }, { tongue: 0.1, sq: B.sq + 0.03 }, 'l').fx('drop', 'mouth', 3).to(160, { tongue: 0 }); return t.back(320); },
    lick(t) { t.to(300, { pitch: -0.04, ly: 0, close: 0.5, smile: 1 }, 'io').osc(1000, 4, { tongue: 0.65 }, { tongue: 0.15 }, 's').to(160, { tongue: 0 }); return t.back(360); },
    tummy(t, X) { BEAT.belly(t, -1); t.to(240, o({ smile: 1, hap: 1, sqz: 0.6 }, X.cheer), 'o').fx('heart', 'head', 2).wait(300); return t.back(380); },
    hic(t) { const B = t.B; for (let i = 0; i < 2; i++) t.to(80, { sq: B.sq - 0.07, lift: 1.8, wide: 0.9, open: 0.2 }, 'o').to(160, { sq: B.sq, lift: 0 }, 'i').fx('bubble', 'mouth', 1).wait(420); BEAT.giggle(t, -1); return t; },
  };

  // ---------- wash dishes (plate in the left paw, sponge in the right, clean plates stack up beside him) ----------
  const DS0 = S0({ pitch: -0.16, ly: 0.7, armL: 28, armR: 30, smile: 0.6 }, hand(-1, 8, -1), hand(1, 6, 0));
  const DSB = {
    scrub(t, X, rec) { const B = t.B, a = t.t; t.to(200, { sqz: 0.3, smile: 0.9 }); for (let i = 0; i < 8; i++) { t.to(115, { hRx: B.hRx - 2.4, hRy: B.hRy - 1.6 }, 'l').to(115, { hRx: B.hRx + 1, hRy: B.hRy + 1.4 }, 'l'); if (i % 3 === 0) t.fx('foam', 'pawR', 2); } push(rec, 'sc', [a, t.t]); return t.back(260); },
    rinse(t) { const B = t.B; t.to(300, { hLy: B.hLy + 3, hRy: B.hRy + 3, armL: 22, armR: 24, ly: 0.9 }, 'io').osc(1100, 4, { tilt: 3, hLx: B.hLx + 1.4 }, { tilt: -3, hLx: B.hLx - 1 }, 's').fx('drop', 'pawL', 4).fx('splash', 'pawL', 2); return t.back(320); },
    squeak(t) { const B = t.B; t.to(380, o(hand(-1, 6, -11), { armL: 54, pitch: B.pitch + 0.22, ly: -0.3, lx: -0.5, wide: 0.5 }), 'io').fx('spark', 'pawL', 4).to(200, { winkR: 1, sqz: 0.5, smile: 1, hap: 0.7 }, 'o').wait(500).to(160, { winkR: 0 }); return t.back(400); },
    stack(t, X, rec) { const B = t.B, a = t.t; t.to(420, o(hand(-1, 16, 2), { armL: 34, lean: 0.8, tilt: 3, lx: 0.8, ly: 0.6 }), 'io').to(140, { hLy: 4, sq: B.sq + 0.03 }, 'i'); push(rec, 'st', [a, t.t]); t.wait(200); return t.back(420); },
    bubble(t) { t.to(260, { puff: 0.8, open: 0, lx: 0, ly: -0.4, pitch: 0.12 }).to(500, { puff: 0.2, open: 0.2, mw: 0.4 }, 's').fx('bubble', 'mouth', 2).to(200, { wide: 0.8, open: 0.4, mw: 1, puff: 0 }, 'o').wait(300); BEAT.giggle(t, 1); return t; },
  };
  const PLATE = d => '<ellipse cx="0" cy="0" rx="6" ry="2.4" fill="#ffffff" stroke="#9fb4c9" stroke-width="0.45"/><ellipse cx="0" cy="-0.2" rx="3.8" ry="1.3" fill="none" stroke="#5ab4f0" stroke-width="0.4" opacity="0.8"/>' +
    (d > 0.03 ? '<g opacity="' + r2(d) + '">' + ci(-2, -0.2, 0.9, '#c9a46a') + ci(1.6, 0.4, 0.7, '#b9864a') + ci(0.4, -0.6, 0.5, '#d9b07a') + '</g>' : '');
  const SPONGE = '<rect x="-2.4" y="-1.6" width="4.8" height="3.2" rx="0.7" fill="#ffd24a" stroke="#d9a22a" stroke-width="0.35"/><rect x="-2.4" y="-1.6" width="4.8" height="1.1" rx="0.5" fill="#7cc35a" stroke="#4f8f3a" stroke-width="0.3"/>';
  function dishProp(st) { const R0 = st.rec;
    return (I, tt) => { const W = I.W; if (!W || !okp(W.pawL) || !okp(W.pawR)) return ''; const f0 = facing(I); if (f0 < 0.02) return ''; const tl = tt % st.loop, [gx, gy] = g0(I), sx = rside(I, gx) + 4, sy = gy - 22;
      const Sk = R0.st || [], done = Sk.filter(q => tl >= q[1]).length, cur = Sk.find(q => tl >= q[0] && tl < q[1] + 500); let last = 0; Sk.forEach(q => { if (tl >= q[1]) last = q[1]; });
      let scr = 0; (R0.sc || []).forEach(([a, b]) => { if (b > last && a < tl) scr += cl((Math.min(tl, b) - Math.max(a, last)) / (b - a), 0, 1); }); const dirt = cl(1 - scr * 0.75, 0, 1);
      let h = ''; for (let i = 0; i < done; i++) h += G(sx, sy - i * 1.8, 0, 2.3, PLATE(0));
      if (cur && tl < cur[1]) { const u = ss((tl - cur[0]) / (cur[1] - cur[0])); h += G(lerp(W.pawL[0], sx, u), lerp(W.pawL[1] - 1, sy - done * 1.8, u), 0, 2.3, PLATE(0), f0); }
      else { const fi = cur ? ss((tl - cur[1] - 200) / 300) : 1; if (fi > 0.02) h += G(W.pawL[0], W.pawL[1] - 1, -8, 2.3 * (0.6 + 0.4 * fi), PLATE(dirt), f0 * fi); }
      return h + G(W.pawR[0], W.pawR[1] - 1, 10, 2.1, SPONGE, f0); }; }

  // ---------- grill (tongs in the right paw: poke, flip the patty, smoke in the face, season, sniff, serve it up) ----------
  const GR0 = S0({ pitch: -0.12, ly: 0.6, armR: 40, armL: 18, smile: 0.8, hap: 0.4 }, hand(1, 2, -4), hand(-1, 6, 2));
  const GRB = {
    poke(t) { const B = t.B; t.to(200, { sqz: 0.2 }).osc(1000, 4, { hRy: B.hRy + 2.4, armR: B.armR - 4 }, { hRy: B.hRy, armR: B.armR }, 'io').fx('gust', 'pawR', 1); return t.back(260); },
    flip(t, X, rec) { const B = t.B; t.to(240, { hRy: B.hRy + 3, armR: B.armR - 8, sq: B.sq + 0.04, wide: 0.3 }, 'io'); push(rec, 'fl', t.t); t.to(150, { hRy: B.hRy - 7, armR: B.armR + 30, sq: B.sq - 0.03, ly: -0.6, pitch: B.pitch + 0.2, open: 0.4, mw: 0.6 }, 'o');
      t.to(320, { ly: -0.9, pitch: B.pitch + 0.28, wide: 0.7 }, 'o').to(330, { ly: B.ly, pitch: B.pitch, hRy: B.hRy, armR: B.armR }, 'i').fx('gust', 'pawR', 1).to(220, { sqz: 0.7, hap: 1, smile: 1, open: 0.3, mw: 1, wide: 0 }, 'o').wait(300); return t.back(320); },
    smoke(t) { const B = t.B; t.to(260, { lean: -1, pitch: B.pitch + 0.14, close: 0.8, sqz: 0.9, puff: 0.4 }, 'o').osc(1200, 5, o(hand(-1, 2, -6), { armL: 72 }), o(hand(-1, 2, -4), { armL: 44 }), 'io').fx('sweat', 'head', 1).to(220, { puff: 0, open: 0.3, mw: 0.5 }, 'o').fx('gust', 'mouth', 1); return t.back(400); },
    season(t) { t.to(320, o(hand(-1, 4, -6), { armL: 64, lx: 0.4 }), 'io').osc(900, 5, { hLy: -8, tilt: 1 }, { hLy: -5, tilt: -1 }, 'l').fx('sand', 'pawL', 4); return t.back(320); },
    sniff(t) { t.to(380, { pitch: -0.04, close: 0.7, smile: 1, hap: 0.7, puff: 0.2 }, 's').fx('heart', 'head', 1).wait(600).to(200, { close: 0, wide: 0.4, puff: 0 }, 'o'); return t.back(360); },
    serve(t, X, rec) { const a = t.t; t.to(320, o({ armR: 140, hRy: -10, hRx: 2, ly: -0.6, pitch: 0.12, hap: 1, smile: 1, open: 0.5, wide: 0.4 }, X.cheer), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('spark', 'pawR', 3); t.wait(800); push(rec, 'sv', [a, t.t]); return t.back(420); },
  };
  const TONGS = '<path d="M0-0.6L13-1.6M0 0.6L13 1.6" stroke="#9aa3b2" stroke-width="0.9" stroke-linecap="round"/><path d="M-2.4-0.8H1V0.8H-2.4Z" fill="#3b2a24"/><path d="M12.4-2.4L14.2-1.2M12.4 2.4L14.2 1.2" stroke="#7a8392" stroke-width="0.7" stroke-linecap="round"/>';
  const PATTY = k => '<ellipse cx="0" cy="0" rx="4.4" ry="1.7" fill="' + mixC('#e98a8a', '#7a4428', k) + '" stroke="#5a3018" stroke-width="0.4"/><path d="M-2.6-0.3H2.6M-1.6 0.6H1.8" stroke="#3a1e10" stroke-width="0.45" opacity="' + r2(k * 0.8) + '"/><ellipse cx="-1.4" cy="-0.7" rx="1.4" ry="0.4" fill="#ffffff" opacity="0.25"/>';
  function grillProp(st) { const R0 = st.rec, TL0 = 13 * 1.75, an = -14 * Math.PI / 180;
    return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const f0 = facing(I); if (f0 < 0.02) return ''; const tl = tt % st.loop, p = W.pawR, tip = [p[0] + TL0 * Math.cos(an), p[1] + TL0 * Math.sin(an)], gy = p[1] + 5;
      const ck = cl(tl / (st.loop * 0.8), 0, 1), sv = (R0.sv || []).find(q => tl >= q[0] && tl < q[1] + 300), fl = (R0.fl || []).find(a => tl >= a && tl < a + 800); let h = G(tip[0] + 12, gy, 0, 2, PATTY(ck * 0.8), f0);
      if (sv) h += G(tip[0], tip[1] + 0.6, 0, 2, PATTY(1), f0);
      else if (fl != null) { const u = (tl - fl) / 800; h += G(tip[0] + 1, lerp(tip[1] + 1, gy, u) - Math.sin(Math.PI * u) * 16, 360 * ss(u), 2, PATTY(ck), f0); }
      else h += G(tip[0] + 1, gy, 0, 2, PATTY(ck), f0);
      return G(p[0], p[1], -14, 1.75, TONGS, f0) + h; }; }

  // ---------- toaster: waits (tap foot, peek in, rub paws), then it pops: startle, catch, hot-hot juggle, blow, happy (the house eats it after) ----------
  const TW0 = S0({ lx: 0.7, ly: 0.4, pitch: -0.04 });
  const TWB = {
    tap(t) { t.to(300, o(both(4, 4), { armL: 30, armR: 30, close: 0.3 })).osc(1500, 6, { footR: 1.4 }, { footR: 0 }, 'o'); return t.back(300); },
    peek(t) { t.to(380, { lean: 0.9, pitch: -0.22, lx: 0.9, ly: 0.8, wide: 0.6, sq: 0.04 }, 'io').wait(700).to(200, { wide: 0.2 }); return t.back(380); },
    rub(t) { t.to(300, o(both(9, -5), { armL: 36, armR: 36, sqz: 0.6, smile: 1, hap: 0.6 }), 'io').osc(1100, 6, { hLx: 11, hRx: -7 }, { hLx: 7, hRx: -11 }, 'l'); return t.back(340); },
  };
  const TOAST = '<path d="M-3-3Q-3.6-4.6-2-4.8Q0-5.6 2-4.8Q3.6-4.6 3-3V3.2H-3Z" fill="#d9964a" stroke="#9a5a24" stroke-width="0.45"/><path d="M-2.2-2.8Q-2.4-3.8-1.4-3.9Q0-4.5 1.4-3.9Q2.4-3.8 2.2-2.8V2.4H-2.2Z" fill="#f2d08a"/>';
  function toastMove(X) { const t = TL(TW0); t.B = o(REST, TW0);
    t.to(90, { wide: 1, open: 0.5, mw: 0.5, lift: 4, sq: -0.08, armL: 90, armR: 90, lx: 0.9, ly: -0.6 }, 'o').to(200, { lift: 0, sq: 0.05 }, 'i');
    t.to(260, o(both(9, -11), { armL: 56, armR: 56, ly: -0.4, lx: 0.3 }), 'io'); const c = t.t; t.to(120, { sq: 0.06 }, 'i');
    t.osc(1000, 5, { hLx: 12, hRx: -6, sqz: 0.8, tilt: 2 }, { hLx: 6, hRx: -12, tilt: -2 }, 'l').fx('sweat', 'head', 1);
    t.to(200, { puff: 0.8, open: 0, sqz: 0, ly: 0.3, lx: 0 }).to(160, { puff: 0, open: 0.4, mw: 0.45 }, 'o').fx('gust', 'mouth', 1).to(200, { puff: 0.7, open: 0 }).to(160, { puff: 0, open: 0.4 }, 'o').fx('gust', 'mouth', 1);
    t.to(260, o({ sqz: 0.7, hap: 1, smile: 1, open: 0.3, mw: 1, wide: 0, tilt: 0 }, X.cheer), 'o').fx('heart', 'head', 1).wait(300);
    const st = t.out({ next: 'idle', blend: 160 });
    st.prop = (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const f0 = Math.max(0.35, facing(I)), m = mid(W), [gx] = g0(I), s0 = [rside(I, gx) + 2, W.pawR[1] - 8]; let x = m[0], y = m[1] - 3, r = 0;
      if (tt < c) { const u = cl(tt / c, 0, 1); x = lerp(s0[0], m[0], u); y = lerp(s0[1], m[1] - 3, u) - Math.sin(Math.PI * u) * 24; r = 400 * u; } return G(x, y, r, 2.6, TOAST, f0); };
    return st; }

  // ---------- bouncy pouf (seated bounces) ----------
  const POB = {
    big(t, X) { const B = t.B, L = B.lift || 0, Q = B.sq || 0; t.to(160, { sq: Q + 0.14, lift: L - 1 }, 'i').to(300, o({ sq: Q - 0.1, lift: L + 8, armL: 130, armR: 130, open: 0.5, hap: 1, wide: 0.4 }, X.tk || {}), 'o').to(280, { lift: L, sq: Q + 0.22, armL: B.armL, armR: B.armR }, 'i').to(200, { sq: Q - 0.04 }, 'o').to(160, { sq: Q }, 'io'); return t.back(300); },
    rock(t) { const L = t.B.lift || 0; t.osc(1600, 4, { tilt: 6, lift: L + 1.6, x: 1 }, { tilt: -6, lift: L + 1.6, x: -1 }, 's'); return t.back(300); },
    spinb(t) { const L = t.B.lift || 0, Q = t.B.sq || 0; t.to(140, { sq: Q + 0.12 }, 'i').to(500, { spin: 360, lift: L + 5, sq: Q - 0.06, hap: 1 }, 'io').to(10, { spin: 0 }).to(200, { lift: L, sq: Q + 0.12 }, 'i'); return t.back(260); },
  };

  // ---------- pool splash (sits in the kiddie pool) ----------
  const SP0 = o(BATH0, { wd: 0.48, sk: 5, fm: 0, dk: 0, dkx: 0, armL: 40, armR: 40, smile: 1, hap: 0.6, close: 0 }, both(2, -2));
  const SPB = {
    slap(t) { const Q = t.B.sq || 0; for (let i = 0; i < 3; i++) t.to(200, { armL: 96, armR: 96, hLy: -6, hRy: -6, open: 0.4, hap: 1 }, 'o').to(130, { armL: 26, armR: 26, hLy: 3, hRy: 3, sq: Q + 0.05, sqz: 0.6 }, 'i').fx('splash', 'body', 5); return t.back(320); },
    kick(t) { const B = t.B, Q = B.sq || 0; t.to(200, { lean: -0.6, pitch: (B.pitch || 0) + 0.12 }).osc(1200, 6, { footL: 3, footR: 0, sq: Q + 0.02 }, { footL: 0, footR: 3, sq: Q }, 'l').fx('splash', 'belly', 4).fx('drop', 'belly', 3); return t.back(320); },
    soak(t) { const B = t.B; t.to(400, { pitch: (B.pitch || 0) + 0.25, close: 0.7, wd: (B.wd || 0) + 0.18, lean: -0.6, smile: 1 }, 's').wait(900); return t.back(400, null, 's'); },
    atyou(t) { t.to(300, o(both(10, 2), { armL: 30, armR: 30, sqz: 0.5, hap: 1, smile: 1, lx: 0, ly: 0 }), 'io').to(140, o(both(8, -10), { armL: 80, armR: 80, open: 0.5 }), 'o').fx('splash', 'head', 7).fx('drop', 'head', 4).wait(200); BEAT.giggle(t, 1); return t; },
    duck(t) { t.to(300, { dk: 1, dkx: 0.6, lx: 0.7, ly: 0.6, smile: 1 }, 'o').osc(1600, 2, { dkx: -0.6, lx: -0.7 }, { dkx: 0.6, lx: 0.7 }, 's').to(300, { dk: 0, dkx: 0 }); return t.back(300); },
    wave(t) { BEAT.wave(t, 1); return t; },
  };
  function splashIn(B, P) { const t = TL(REST); t.B = o(REST);
    if (P.dn === 'float') t.to(300, { lift: 6, sq: -0.04 }, 'o').to(500, o(B, { lift: 0 }), 's');
    else t.to(160, { sq: 0.12, armL: -6, armR: -6 }, 'io').to(240, { lift: 8, sq: -0.1, footR: 2.4, armL: 50, armR: 50 }, 'o').to(220, o(B, { lift: 0, sq: (B.sq || 0) + 0.1 }), 'i').fx('splash', 'body', 7);
    const v = {}; K(B).forEach(p => v[p] = B[p]); t.to(220, v, 'io'); return t.out({ next: 'splash', blend: 180 }); }
  function splashOut(B) { const t = TL(B); t.B = o(REST, B); t.to(300, { wd: 0.2, sk: 1, lift: 1, sq: -0.04, armL: 60, armR: 60 }, 'io').to(220, { lift: 8, wd: 0, sk: 0, sit: 0, footL: 2, sq: -0.08 }, 'o').fx('drop', 'body', 5);
    const z = {}; K(B).forEach(p => z[p] = REST[p] || 0); t.to(240, o(z, { lift: 0, sq: 0.08 }), 'i').to(140, { sq: 0 }, 'io').osc(700, 5, { x: 1.2, tilt: 5, sqz: 0.8 }, { x: -1.2, tilt: -5, sqz: 0.8 }, 'l').fx('drop', 'body', 6).to(200, { x: 0, tilt: 0, sqz: 0, smile: 1, hap: 0.8 }, 'o');
    t.back(260); return t.out({ next: 'idle', blend: 160 }); }

  // ---------- pick up a shell (once): bend, pick, inspect, hold it to his ear, hug it, tuck it away, happy hop ----------
  function shellMove(X) { const t = TL(REST); t.B = o(REST);
    t.to(300, { lx: 0.4, ly: 0.9, pitch: -0.16, wide: 0.5 }, 'io').to(380, o(hand(1, -2, 10), { pitch: -0.42, ly: 1, sq: 0.1, lean: 0.5, armR: 12, tilt: 2 }), 'io').wait(160); const g = t.t;
    t.to(160, { sqz: 0.3 }).to(420, o(hand(1, 8, -10), { armR: 48, pitch: 0.08, ly: -0.1, lx: 0.3, sq: 0, lean: 0, tilt: 0, wide: 0.8, open: 0.3, mw: 0.6, htilt: 8, sqz: 0 }), 'io').wait(500).to(300, { htilt: -6, lx: -0.3 }, 'io').wait(300);
    t.to(380, o(hand(1, 3, -16), { armR: 112, htilt: -12, close: 0.7, smile: 1, open: 0, wide: 0, mw: 1 }), 'io').fx('note', 'head', 1).wait(900).fx('bubble', 'head', 1);
    t.to(360, o(both(8, 3), { armL: 18, armR: 18, htilt: 0, close: 0.4, blush: 0.7, hap: 1, smile: 1 }, X.cheer), 'io'); const k = t.t; t.fx('heart', 'head', 2).osc(700, 3, { sq: 0.04, tilt: 2 }, { sq: 0, tilt: -2 }, 's');
    t.to(140, { lift: 4, sq: -0.06 }, 'o').to(160, { lift: 0, sq: 0.05 }, 'i'); t.back(420); const st = t.out({ next: 'idle', blend: 180 });
    st.prop = (I, tt) => { const W = I.W; if (!W || !okp(W.pawR) || tt < g) return ''; const f0 = Math.max(0.3, facing(I)), Bp = okp(W.belly) ? W.belly : [50, 80]; let x = W.pawR[0], y = W.pawR[1] - 2.5, op = f0;
      if (tt > k) { const u = ss((tt - k) / 600); x = lerp(x, Bp[0], u); y = lerp(y, Bp[1], u); op *= 1 - ss((tt - k - 400) / 500); } return op < 0.02 ? '' : G(x, y, -10, 2.4, ICON.shell || ICON.star, op); };
    return st; }

  // ---------- stage perform (hand mic) ----------
  const PF0 = S0({ armR: 40, armL: 22, smile: 0.9, hap: 0.5, open: 0.1 }, hand(1, 8, -12));
  const PFB = {
    sing(t) { t.to(220, { close: 0.4, open: 0.4, mw: 0.7 }).fx('note', 'mouth', 1).osc(2000, 4, { htilt: 6, lean: 0.6, x: 0.6, open: 0.5 }, { htilt: -6, lean: -0.6, x: -0.6, open: 0.15 }, 's').fx('note', 'mouth', 1); return t.back(360); },
    belt(t) { t.to(360, { pitch: 0.24, ly: -0.6, armL: 128, hLy: -2, open: 0.75, mw: 0.6, close: 0.8, sq: -0.05, lean: -0.4 }, 'io').fx('note', 'mouth', 2).osc(1200, 8, { sq: -0.03 }, { sq: -0.06 }, 'l').fx('note', 'mouth', 2).to(240, { open: 0.2 }); return t.back(420); },
    point(t) { t.to(300, { armL: 150, hLx: -5, hLy: -2, lx: -0.7, winkL: 1, smile: 1, hap: 0.8, htilt: -5 }, 'o').wait(600).to(160, { winkL: 0 }); return t.back(360); },
    spin(t) { t.to(160, { sq: 0.06 }).to(560, { spin: 360, armL: 110, sq: -0.04, hap: 1, open: 0.4 }, 'io').to(10, { spin: 0 }).to(160, { sq: 0.05 }, 'o'); return t.back(300); },
    step(t) { const B = t.B; for (let i = 0; i < 4; i++) { const s = i % 2 ? -1 : 1; t.to(260, { x: s * 1.8, footL: s > 0 ? 2 : 0, footR: s > 0 ? 0 : 2, tilt: s * 3, armL: B.armL + 20 }, 'io'); } t.fx('note', 'mouth', 1); return t.back(300); },
    bow(t) { const B = t.B; t.to(380, o(hand(-1, 9, 6), { armL: 14, pitch: -0.42, ly: 0.8, sq: 0.1, close: 0.6, smile: 1 }), 'io').wait(700).to(320, { pitch: B.pitch, ly: 0, sq: 0, close: 0 }, 'io'); BEAT.wave(t, -1); t.fx('heart', 'head', 3); return t; },
  };
  const MIC = c => '<rect x="-1" y="-1.1" width="9" height="2.2" rx="1.1" fill="' + c + '" stroke="' + shade(c, 0.6) + '" stroke-width="0.4"/><circle cx="10" cy="0" r="2.6" fill="#c9cfdb" stroke="#6a7080" stroke-width="0.45"/><path d="M8.6-1.6L11.4 1.6M8.6 1.6L11.4-1.6M10-2.4V2.4" stroke="#8a90a0" stroke-width="0.3"/><path d="M8.8-1.4Q9.6-2.2 10.8-1.8" stroke="#fff" stroke-width="0.5" fill="none" opacity="0.8"/>';
  const micProp = col => (I) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const f0 = facing(I); if (f0 < 0.02) return ''; const p = W.pawR, M = okp(W.mouth) ? W.mouth : [p[0] - 8, p[1] - 3], d = Math.hypot(M[0] - p[0], M[1] - p[1]);
    return G(p[0], p[1], Math.atan2(M[1] - p[1], M[0] - p[0]) * 180 / Math.PI, cl((d - 2) / 12.6, 0.8, 1.25) * 1.3, MIC(col), f0); };

  // ---------- DJ booth (left paw holds the ear cup, right paw on the deck) ----------
  const DJ0 = S0({ armL: 74, armR: 26, smile: 0.9, hap: 0.5, pitch: -0.05, ly: 0.3 }, hand(-1, 3, -15), hand(1, 6, 2));
  const DJB = {
    nod(t) { const B = t.B; t.osc(2000, 8, { pitch: B.pitch - 0.14, sq: B.sq + 0.04, lift: -0.4 }, { pitch: B.pitch + 0.03, sq: B.sq - 0.01, lift: 0 }, 'io').fx('note', 'head', 1); return t.back(240); },
    scratch(t) { const B = t.B; t.to(200, { sqz: 0.5, lean: 0.4, pitch: B.pitch - 0.1, ly: 0.7 }); for (let i = 0; i < 6; i++) t.to(110, { hRx: B.hRx - 3.2 }, 'l').to(110, { hRx: B.hRx + 1.6 }, 'l'); t.fx('note', 'pawR', 1); return t.back(260); },
    pump(t) { const B = t.B; t.to(200, { armR: 150, hRy: -4, open: 0.4, hap: 1 }, 'o'); for (let i = 0; i < 4; i++) t.to(250, { armR: 112, sq: B.sq + 0.05, lift: -0.5 }, 'i').to(250, { armR: 160, sq: B.sq - 0.03, lift: 1 }, 'o'); return t.back(320); },
    point(t, X) { t.to(300, o({ armR: 140, hRx: 5, hRy: -2, lx: 0.6, winkR: 1, smile: 1, open: 0.3 }, X.cheer), 'o').wait(600).to(160, { winkR: 0 }); return t.back(340); },
    drop(t, X) { const B = t.B; t.to(500, { sq: B.sq + 0.1, armR: 10, lift: -1, wide: 0.5 }, 'i').to(200, o({ armR: 165, armL: 165, hLy: -4, hRy: -4, hLx: 0, lift: 7, sq: -0.08, open: 0.7, wide: 0.6, hap: 1 }, X.tk || {}), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('spark', 'body', 5);
      t.to(220, { lift: 0, sq: 0.08 }, 'i').osc(900, 4, { sq: B.sq + 0.05, pitch: B.pitch - 0.12 }, { sq: B.sq, pitch: B.pitch + 0.03 }, 'io'); return t.back(400); },
    spin(t) { t.to(560, { spin: 360, sq: -0.03, hap: 1 }, 'io').to(10, { spin: 0 }); return t.back(240); },
  };
  const phoneProp = col => (I) => { const W = I.W || {}, f0 = facing(I); if (f0 < 0.05) return ''; let a = W.eyeL, b = W.eyeR; if (!okp(a) && !okp(b)) return ''; if (!okp(a)) a = b; if (!okp(b)) b = a;
    const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2, d = Math.max(Math.hypot(b[0] - a[0], b[1] - a[1]), 6), hw = d * 1.15 + 5, top = okp(W.head) ? Math.min(W.head[1] - my + 1, -6) : -d * 1.4 - 5, an = Math.atan2(b[1] - a[1], b[0] - a[0]) * 180 / Math.PI;
    const arc = 'M' + r2(-hw) + ' 0C' + r2(-hw) + ' ' + r2(top * 1.3) + ' ' + r2(hw) + ' ' + r2(top * 1.3) + ' ' + r2(hw) + ' 0';
    const cup = x => '<rect x="' + r2(x - 2.2) + '" y="-2" width="4.4" height="7" rx="2" fill="#2a2440" stroke="#111" stroke-width="0.35"/><rect x="' + r2(x - 1.3) + '" y="-0.8" width="2.6" height="4.6" rx="1.2" fill="' + col + '"/>';
    return G(mx, my + 1, an, 1, '<path d="' + arc + '" fill="none" stroke="#2a2440" stroke-width="2"/><path d="' + arc + '" fill="none" stroke="' + col + '" stroke-width="0.9"/>' + cup(-hw) + cup(hw), Math.min(1, f0 * 1.3)); };

  // ---------- arcade: pinball, dance cabinet, air hockey, billiards ----------
  const PB0 = S0({ pitch: -0.12, ly: 0.6, armL: 44, armR: 44, wide: 0.2 }, both(4, -4));
  const PBB = {
    flip(t) { const B = t.B; for (let i = 0; i < 8; i++) { const s = i % 2 ? 'armL' : 'armR'; t.to(90, { [s]: B[s] + 14, sq: B.sq + 0.015 }, 'o').to(120, { [s]: B[s], sq: B.sq }, 'i'); } return t.back(260); },
    track(t) { t.to(300, { lx: -0.8, turn: -0.12, wide: 0.5 }, 'io').to(300, { lx: 0.8, turn: 0.12 }, 'io').to(260, { lx: -0.4, ly: 0.9 }, 'io').to(300, { lx: 0.6, ly: 0.3 }, 'io'); return t.back(300); },
    nudge(t) { const Q = t.B.sq; t.to(140, { tilt: 7, x: 1.4, sq: Q + 0.05, sqz: 0.6 }, 'o').to(200, { tilt: -3, x: -0.4 }, 'io').to(140, { tilt: 6, x: 1.2 }, 'o').to(240, { tilt: 0, x: 0, sqz: 0 }, 'io'); return t.back(260); },
    multi(t) { const B = t.B; t.to(200, { wide: 1, open: 0.5, mw: 0.6, pitch: B.pitch + 0.06 }, 'o'); for (let i = 0; i < 10; i++) t.to(70, { armL: B.armL + (i % 2 ? 14 : 0), armR: B.armR + (i % 2 ? 0 : 14), lx: i % 2 ? 0.7 : -0.7 }, 'l'); t.fx('spark', 'head', 3).fx('sweat', 'head', 1); return t.back(300); },
  };
  const DC0 = S0({ armL: 36, armR: 36, smile: 1, hap: 0.6 });
  const DCB = {
    steps(t) { for (let i = 0; i < 8; i++) { const s = i % 2 ? -1 : 1; t.to(115, { footL: s > 0 ? 2.6 : 0, footR: s > 0 ? 0 : 2.6, x: s * 1.2, armL: s > 0 ? 60 : 20, armR: s > 0 ? 20 : 60, sq: 0.03, tilt: s * 2 }, 'o').to(115, { footL: 0, footR: 0, sq: 0 }, 'i'); } return t.back(240); },
    arrows(t) { t.to(160, { x: -2.6, footL: 2.4, tilt: -5, armL: 90 }, 'o').to(160, { footL: 0, armL: 36 }, 'i').to(160, { x: 2.6, footR: 2.4, tilt: 5, armR: 90 }, 'o').to(160, { footR: 0, armR: 36 }, 'i')
      .to(160, { x: 0, tilt: 0, lift: 4, sq: -0.06, armL: 120, armR: 120 }, 'o').to(160, { lift: 0, sq: 0.06 }, 'i').to(160, { sq: 0.14, lift: -1, armL: 10, armR: 10 }, 'o').to(160, { sq: 0, lift: 0 }, 'io'); return t.back(240); },
    jump(t) { for (let i = 0; i < 2; i++) t.to(110, { sq: 0.12 }, 'i').to(220, { sq: -0.08, lift: 8, footL: 1.6, footR: 1.6, armL: 130, armR: 130, open: 0.4 }, 'o').to(220, { lift: 0, sq: 0.06, footL: 0, footR: 0, armL: 40, armR: 40 }, 'i'); return t.back(240); },
    combo(t, X) { for (let i = 0; i < 12; i++) { const s = i % 2 ? -1 : 1; t.to(80, { footL: s > 0 ? 2.4 : 0, footR: s > 0 ? 0 : 2.4, x: s * 1.6, armL: s > 0 ? 90 : 30, armR: s > 0 ? 30 : 90, sqz: 0.5 }, 'l'); } t.fx('sweat', 'head', 1); cheer(t, X, { footL: 0, footR: 0, x: 0, sqz: 0 }); return t; },
    spin(t) { t.to(120, { sq: 0.08 }).to(600, { spin: 360, armL: 100, armR: 100, sq: -0.04, lift: 2 }, 'io').to(10, { spin: 0 }).to(160, { lift: 0, sq: 0.04 }, 'i'); return t.back(260); },
    freeze(t, X) { t.to(200, o({ armL: 165, armR: 18, hLy: -4, tilt: 7, x: 1, footR: 2, winkR: 1, smile: 1, open: 0.3, hap: 1 }, X.tk || {}), 'o'); if (X.cheerFx) t.fx(...X.cheerFx); else t.fx('spark', 'body', 3); t.wait(900).to(160, { winkR: 0 }); return t.back(360); },
  };
  const HK0 = S0({ pitch: -0.16, ly: 0.7, armR: 34, armL: 24, wide: 0.2 }, hand(1, 4, -2), hand(-1, 8, 2));
  const HKB = {
    ready(t) { const B = t.B; t.to(260, { sq: B.sq + 0.06, lift: -0.6, sqz: 0.3 }, 'io').osc(1000, 2, { lx: -0.6, x: -0.6 }, { lx: 0.6, x: 0.6 }, 's'); return t.back(260); },
    hit(t, X, rec) { const B = t.B; t.to(200, { armR: B.armR + 16, hRx: B.hRx + 4, lean: -0.5 }, 'io').to(110, { armR: B.armR - 10, hRx: B.hRx - 7, lean: 1, sq: B.sq - 0.03, open: 0.3, mw: 0.6 }, 'o'); push(rec, 'h', t.t); t.to(300, { lean: 0.3, lx: 0.8, ly: 0.4 }, 'io'); return t.back(300); },
    block(t, X, rec) { const B = t.B; t.to(120, { x: -1.6, lean: -1, hRx: B.hRx + 3, wide: 0.9, open: 0.4 }, 'o'); push(rec, 'h', t.t); t.wait(250); return t.back(300); },
  };
  const PADDLE = c => '<ellipse cx="0" cy="1" rx="4.2" ry="2" fill="' + c + '" stroke="' + shade(c, 0.65) + '" stroke-width="0.45"/><ellipse cx="0" cy="-0.4" rx="1.5" ry="1.1" fill="' + shade(c, 1.2) + '" stroke="' + shade(c, 0.65) + '" stroke-width="0.35"/>';
  const PPAD = c => '<path d="M-0.6 0H0.6V4H-0.6Z" fill="#c98a52" stroke="#8a5a2c" stroke-width="0.3"/><circle cx="0" cy="-2.6" r="3.2" fill="' + c + '" stroke="' + shade(c, 0.65) + '" stroke-width="0.45"/>';
  // puck / ping-pong ball shuttles out from his paddle after each hit and comes back for the next one
  function puckProp(st, col, pong) { const R0 = st.rec, PD = pong ? PPAD(col) : PADDLE(col);
    return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const f0 = Math.max(0.4, facing(I)), tl = tt % st.loop, p = W.pawR, HS = (R0.h || []).slice().sort((a, b) => a - b); let h0 = null, h1 = null; HS.forEach(v => { if (v <= tl) h0 = v; else if (h1 == null) h1 = v; });
      const Tm = pong ? 300 : 450, FAR = pong ? 34 : 30, T = h0 != null && h1 != null ? Math.min(Tm, (h1 - h0) / 2) : Tm; let d = 5, op = 1;
      if (h0 != null) d = lerp(5, FAR, ss((tl - h0) / T)); if (h1 != null && tl > h1 - T) d = lerp(FAR, 5, ss((tl - (h1 - T)) / T)); if (h0 != null && h1 == null && tl - h0 > 1200) op = 1 - ss((tl - h0 - 1200) / 300);
      const u = (d - 5) / (FAR - 5); let h = '';
      if (op > 0.02) h += '<g opacity="' + r2(op) + '">' + (pong ? ci(r2(p[0] + d), r2(p[1] - 2 - Math.abs(Math.sin(Math.PI * 2 * u)) * 5), 1.6, '#ffffff', '#c9cfdb') : '<ellipse cx="' + r2(p[0] + d) + '" cy="' + r2(p[1] + 2.5) + '" rx="4.2" ry="1.6" fill="#2a2a36" stroke="#111" stroke-width="0.3"/>') + '</g>';
      return h + G(p[0], p[1], pong ? -20 : 0, 2.4, PD, f0); }; }
  const BL0 = S0({ pitch: -0.2, ly: 0.7, armL: 30, armR: 22, lean: 0.3, tilt: 3 }, hand(-1, 10, -2), hand(1, -2, 2));
  const BLB = {
    chalk(t) { t.to(340, o(hand(-1, 4, -8), { armL: 56, ly: 0.2, lx: 0.4, pitch: -0.04 }), 'io').osc(900, 4, { hLx: 6, tilt: 2 }, { hLx: 3, tilt: 4 }, 's').fx('dust', 'pawL', 2).to(200, { puff: 0.6 }).to(200, { puff: 0, open: 0.3, mw: 0.5 }, 'o').fx('gust', 'mouth', 1); return t.back(360); },
    aim(t) { const B = t.B; t.to(420, { sq: B.sq + 0.1, pitch: B.pitch - 0.12, lift: -1, winkL: 1, lx: 0.6, ly: 0.8, tongue: 0.3 }, 'io').osc(1200, 3, { hRx: B.hRx + 2.4 }, { hRx: B.hRx - 1 }, 'io'); return t; },
    shoot(t, X, rec) { const B = t.B; t.to(300, { hRx: B.hRx + 4.4, armR: B.armR + 6 }, 'io').to(90, { hRx: B.hRx - 6, armR: B.armR - 4, sq: B.sq + 0.1 }, 'o'); push(rec, 'sh', t.t); t.to(400, { winkL: 0, wide: 0.6, lx: 0.9, ly: 0.5, tongue: 0, pitch: B.pitch - 0.04 }, 'io').wait(500); return t.back(420); },
    miss(t) { t.to(260, o(hand(1, 6, -18), { armR: 128, frown: 0.4, htilt: 8, lx: 0.7 }), 'io').osc(900, 4, { hRx: -3 }, { hRx: -7 }, 's').to(240, { frown: 0, sqz: 0.6, hap: 0.7, smile: 1 }, 'o'); return t.back(400); },
    circle(t) { t.to(500, { turn: 0.3, lx: 0.9, ly: 0.6, htilt: 6, tilt: 0 }, 'io').wait(700).to(600, { turn: -0.3, lx: -0.9, htilt: -6 }, 'io').wait(600); return t.back(500); },
  };
  function cueProp(st) { return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR) || !okp(W.pawL)) return ''; const f0 = Math.max(0.35, facing(I)), tl = tt % st.loop, a = W.pawR, b = W.pawL;
      let dx = b[0] - a[0], dy = b[1] - a[1], d = Math.hypot(dx, dy); if (d < 4) { dx = -1; dy = 0.2; d = Math.hypot(dx, dy); } dx /= d; dy /= d;
      const s0 = [a[0] - dx * 16, a[1] - dy * 16], tip = [b[0] + dx * 14, b[1] + dy * 14], L = (p, q, c, w) => '<path d="M' + r2(p[0]) + ' ' + r2(p[1]) + 'L' + r2(q[0]) + ' ' + r2(q[1]) + '" stroke="' + c + '" stroke-width="' + w + '" stroke-linecap="round"/>';
      let h = '<g opacity="' + r2(f0) + '">' + L(s0, tip, '#8a5a2c', 2.6) + L(s0, tip, '#c98a52', 1.7) + L(s0, [s0[0] + dx * 12, s0[1] + dy * 12], '#3b2a24', 2.8) + ci(r2(tip[0]), r2(tip[1]), 1.1, '#5ab4f0') + '</g>';
      const S = (st.rec.sh || []).filter(v => v <= tl).pop(), home = [tip[0] + dx * 3.6, tip[1] + dy * 3.6]; let bp = home, op = 1;
      if (S != null && tl - S < 2200) { const e = tl - S; if (e < 1300) { const u = cl(e / 900, 0, 1), v = 1 - (1 - u) * (1 - u); bp = [home[0] + dx * 40 * v, home[1] + dy * 40 * v]; op = 1 - ss((e - 900) / 400); } else op = ss((e - 1700) / 500); }
      if (op > 0.02) h += '<g opacity="' + r2(op) + '">' + ci(r2(bp[0]), r2(bp[1]), 3, '#ffffff', '#9aa3b2') + ci(r2(bp[0] - 1), r2(bp[1] - 1), 0.8, '#ffffff') + '</g>';
      return h; }; }

  // ---------- backyard games ----------
  const ICX = {
    ball: '<circle cx="0" cy="0" r="3" fill="#ffffff" stroke="#3a3a48" stroke-width="0.45"/><path d="M0-1.2L1.15-0.35L0.7 1H-0.7L-1.15-0.35Z" fill="#2a2a36"/><path d="M0-1.2V-3M1.15-0.35L2.85-0.9M0.7 1L1.7 2.4M-0.7 1L-1.7 2.4M-1.15-0.35L-2.85-0.9" stroke="#3a3a48" stroke-width="0.35"/>',
    bball: ci(0, 0, 3, '#f28a2e', '#b8561a') + pa('M-3 0H3M0-3V3M-2.1-2.1Q0 0-2.1 2.1M2.1-2.1Q0 0 2.1 2.1', null, '#7a3a10', 0.35) + ci(-1.1, -1.2, 0.7, 'rgba(255,255,255,0.45)'),
    bocce: ci(0, 0, 2.4, '#c0392b', '#7a1e14') + pa('M-2.2-0.6Q0 0.6 2.2-0.6', null, '#ffd24a', 0.5) + ci(-0.8, -0.9, 0.6, '#ffffff'),
    bag: c => '<rect x="-2.6" y="-2" width="5.2" height="4" rx="1.2" fill="' + c + '" stroke="' + shade(c, 0.65) + '" stroke-width="0.4"/><path d="M-1.8-1.2H1.8" stroke="#ffffff" stroke-width="0.4" opacity="0.5"/>',
    shoe: pa('M-2.6 2.4V-0.4A2.6 2.6 0 0 1 2.6-0.4V2.4', null, '#6a7080', 1.3) + pa('M-2.6 2.4V-0.4A2.6 2.6 0 0 1 2.6-0.4V2.4', null, '#c9cfdb', 0.45),
    disc: c => '<ellipse cx="0" cy="0" rx="4.4" ry="1.5" fill="' + c + '" stroke="' + shade(c, 0.65) + '" stroke-width="0.4"/><ellipse cx="0" cy="-0.3" rx="2.4" ry="0.7" fill="none" stroke="#ffffff" stroke-width="0.35" opacity="0.6"/>',
    stone: pa('M-1.8 0.6Q-1.6-1.2 0-1.3Q1.8-1.2 1.9 0.4Q1.6 1.3 0 1.3Q-1.6 1.3-1.8 0.6Z', '#a9a39a', '#6a645a'),
  };
  // soccer goal: dribble, kick (his own style), watch, header
  const GOB = {
    dribble(t, X, rec) { const a = t.t; for (let i = 0; i < 6; i++) { const s = i % 2 ? 'footL' : 'footR'; t.to(160, { [s]: 1.8, x: i % 2 ? -0.6 : 0.6, lx: 0.3, ly: 0.8, pitch: -0.12, tilt: i % 2 ? -2 : 2 }, 'o').to(160, { [s]: 0 }, 'i'); } push(rec, 'dr', [a, t.t]); return t.back(240); },
    kick(t, X, rec) { const h = kickCore(t, X); push(rec, 'k', h); return t.back(300); },
    header(t, X, rec) { t.to(400, { ly: -0.9, pitch: 0.25, wide: 0.5, lean: -0.3 }, 'io').to(140, { pitch: -0.14, lift: 3, close: 1, sq: -0.05 }, 'o'); push(rec, 'hd', t.t); t.fx('spark', 'head', 2).to(260, { lift: 0, close: 0, sq: 0.05, pitch: 0 }, 'i'); return t.back(300); },
  };
  function goalProp(st) { const R0 = st.rec, HD = R0.hd || [];
    return (I, tt) => { const W = I.W || {}, tl = tt % st.loop, [gx, gy] = g0(I), F = [gx + 8, gy - 3], Hd = okp(W.head) ? W.head : [50, 20]; let x = F[0], y = F[1], r = 0, s = 2, op = 1;
      const dr = (R0.dr || []).find(q => tl >= q[0] && tl <= q[1]); if (dr) { const ph = (tl - dr[0]) / 320 * Math.PI; x += Math.sin(ph) * 2.4 + ((I.lastP && I.lastP.x) || 0); y -= Math.abs(Math.sin(ph * 2)) * 1.6; r = (tl - dr[0]) * 0.5; }
      const pre = HD.find(v => tl >= v - 500 && tl < v), f = flyF((R0.k || []).concat(HD), tl, { fly: 700, away: 1700, ret: 900 });
      if (pre != null) { const u = ss((tl - pre + 500) / 500); x = lerp(Hd[0] + 6, Hd[0], u); y = lerp(Hd[1] - 46, Hd[1] - 4, u); r = 200 * u; }
      else if (f) { const [ph, u, e] = f, from = HD.includes(e) ? [Hd[0], Hd[1] - 4] : F; if (ph === 'fly') { x = from[0] + 70 * u; y = from[1] - Math.sin(Math.PI * u) * 26 + (F[1] - 14 - from[1]) * u; s = 2 * (1 - 0.45 * u); r = 720 * u; if (u > 0.85) op = 1 - (u - 0.85) / 0.15; } else if (ph === 'away') op = 0; else { x = lerp(F[0] + 60, F[0], ss(u)); r = -600 * (1 - u); op = ss(u / 0.2); } }
      return op < 0.02 ? '' : G(x, y, r, s, ICX.ball, op); }; }
  // goalkeeper
  const KP0 = S0({ sq: 0.1, lift: -1, armL: 70, armR: 70, pitch: -0.04, wide: 0.3, footL: 0.6, footR: 0.6 }, both(-2, -4));
  const dive = (t, s) => { const Kk = SIDE(s); t.to(160, { sq: 0.16, lift: -1.4 }, 'i').to(260, { [Kk.arm]: 165, [Kk.hy]: -6, tilt: s * 34, x: s * 6, lift: 4, sq: -0.06, wide: 1, open: 0.5 }, 'o').to(200, { lift: 0, sq: 0.18, tilt: s * 40 }, 'i').fx('dust', 'body', 4).wait(300).to(400, { tilt: 0, x: 0, sq: 0.1 }, 'io').fx('sweat', 'head', 1); return t.back(300); };
  const KPB = {
    ready(t) { t.osc(1400, 4, { x: -2.2, tilt: -3, footL: 1.4 }, { x: 2.2, tilt: 3, footR: 1.4 }, 's'); return t.back(260); },
    diveL(t) { return dive(t, -1); }, diveR(t) { return dive(t, 1); },
    catch(t, X, rec) { t.to(200, o(both(9, -9), { armL: 56, armR: 56, wide: 0.9, open: 0.4, lift: 2 }), 'o').to(200, o(both(10, 2), { armL: 20, armR: 20, lift: 0, sq: 0.14, sqz: 0.6, hap: 1, smile: 1, wide: 0, open: 0.2 }), 'i'); push(rec, 'c', [t.t - 200, t.t + 900]); t.wait(900); return t.back(320); },
    punch(t, X, rec) { t.to(160, { armR: 165, hRy: -8, lift: 5, sq: -0.06, open: 0.5 }, 'o'); push(rec, 'pu', t.t); t.fx('spark', 'pawR', 3).to(240, { lift: 0, sq: 0.08 }, 'i'); return t.back(300); },
  };
  function keepProp(st) { const R0 = st.rec; return (I, tt) => { const W = I.W; if (!W || !okp(W.pawL) || !okp(W.pawR)) return ''; const tl = tt % st.loop, c = (R0.c || []).find(q => tl >= q[0] - 250 && tl <= q[1]);
      if (c) { const m = mid(W), u = ss((tl - c[0] + 250) / 250); return G(lerp(m[0] + 10, m[0], u), lerp(m[1] - 14, m[1], u), 0, 2.2 * (0.6 + 0.4 * u), ICX.ball); }
      const p = (R0.pu || []).find(v => tl >= v - 250 && tl < v + 600); if (p == null) return '';
      if (tl < p) { const v = ss((tl - p + 250) / 250); return G(W.pawR[0] + 12 * (1 - v), W.pawR[1] - 14 * (1 - v), 0, 2, ICX.ball, v); }
      const u = (tl - p) / 600; return G(W.pawR[0] + 30 * u, W.pawR[1] - 26 * Math.sin(Math.PI * u * 0.8), 500 * u, 2 * (1 - 0.4 * u), ICX.ball, 1 - ss((u - 0.7) / 0.3)); }; }
  // basketball hoop
  const HPB = {
    dribble(t, X, rec) { const a = t.t; t.to(200, o(hand(1, -2, 4), { armR: 30, pitch: -0.08, ly: 0.6, sq: 0.03 }), 'io'); for (let i = 0; i < 5; i++) t.to(150, { hRy: 8, armR: 22, sq: 0.05 }, 'i').to(150, { hRy: 3, armR: 32, sq: 0.02 }, 'o'); push(rec, 'dr', [a, t.t]); return t.back(240); },
    shoot(t, X, rec) { t.to(260, o(both(6, -6), { armL: 60, armR: 60, sq: 0.12, lift: -1, ly: -0.6, pitch: 0.12, sqz: 0.3 }), 'io').to(240, o(both(6, -14), { armL: 160, armR: 160, sq: -0.08, lift: 9, footL: 1.4, footR: 1.4, sqz: 0 }), 'o'); push(rec, 'sh', t.t);
      t.to(160, { armR: 170, hRy: -16 }, 'o').to(260, { lift: 0, sq: 0.08, footL: 0, footR: 0 }, 'i').to(300, { sq: 0, ly: -0.8, pitch: 0.2, wide: 0.6 }, 'io').wait(300); return t.back(300); },
    spinball(t, X, rec) { const a = t.t; t.to(320, o(hand(1, 4, -16), { armR: 150, ly: -0.8, pitch: 0.16, tongue: 0.5, sqz: 0.4 }), 'io').osc(1600, 4, { tilt: 2, x: 0.5 }, { tilt: -2, x: -0.5 }, 's'); push(rec, 'sp', [a, t.t]); t.to(200, { tongue: 0, smile: 1, hap: 0.8 }, 'o'); return t.back(360); },
  };
  function hoopProp(st) { const R0 = st.rec; return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const tl = tt % st.loop, [gx, gy] = g0(I), p = W.pawR, f0 = Math.max(0.4, facing(I)), m = mid(W), mm = [m[0], m[1] - 3];
      const dr = (R0.dr || []).find(q => tl >= q[0] && tl <= q[1]), sp = (R0.sp || []).find(q => tl >= q[0] && tl <= q[1]), f = flyF(R0.sh, tl, { fly: 900, away: 1500, ret: 600 });
      if (f) { const [ph, u] = f; if (ph === 'fly') return G(mm[0] + 30 * u, mm[1] - 50 * u - Math.sin(Math.PI * u) * 16 + 40 * u * u, 600 * u, 2.4 * (1 - 0.4 * u), ICX.bball, 1 - ss((u - 0.8) / 0.2)); if (ph === 'away') return '';
        return G(lerp(gx + 50, mm[0], ss(u)), lerp(gy - 3, mm[1], ss(u)) - Math.sin(Math.PI * u) * 10, -400 * (1 - u), 2.4, ICX.bball, ss(u / 0.25)); }
      if (sp) return G(p[0], p[1] - 7, (tl - sp[0]) * 1.4, 2.4, ICX.bball, f0);
      if (dr) { const ph = Math.abs(Math.sin((tl - dr[0]) / 300 * Math.PI)); return G(p[0] + 1, lerp(p[1] + 3.5, gy - 3, ph), 0, 2.4, ICX.bball, f0); }
      return G(mm[0], mm[1], 0, 2.4, ICX.bball, f0); }; }
  // putting green
  const GF0 = S0({ pitch: -0.2, ly: 0.8, armL: 26, armR: 26, lean: 0.2 }, both(9, 4));
  const GFB = {
    line(t) { t.to(400, { sq: 0.1, lift: -1.2, pitch: -0.3, lx: 0.9, ly: 0.9, winkL: 1 }, 'io').wait(700).to(300, { lx: 0.2 }, 'io').wait(300).to(300, { sq: 0, lift: 0, winkL: 0, pitch: -0.2, lx: 0 }, 'io'); return t.back(200); },
    waggle(t) { const B = t.B; t.osc(1000, 3, { hLx: B.hLx - 1.6, hRx: B.hRx - 1.6, tilt: 1 }, { hLx: B.hLx + 1.2, hRx: B.hRx + 1.2, tilt: -1 }, 'io'); return t.back(200); },
    putt(t, X, rec) { const B = t.B; t.to(500, { hLx: B.hLx + 3, hRx: B.hRx + 3, tilt: -2, sqz: 0.4 }, 'io').to(200, { hLx: B.hLx - 3.4, hRx: B.hRx - 3.4, tilt: 2 }, 'o'); push(rec, 'pt', t.t - 120); t.to(500, { lx: 0.9, ly: 0.8, lean: 0.8, wide: 0.6, sqz: 0, tongue: 0.4 }, 'io').wait(700); return t.back(360); },
  };
  function golfProp(st) { return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR) || !okp(W.pawL)) return ''; const tl = tt % st.loop, [gx, gy] = g0(I), m = mid(W), hd = [m[0] + 3, gy - 1];
      let h = '<path d="M' + r2(m[0]) + ' ' + r2(m[1]) + 'L' + r2(hd[0]) + ' ' + r2(hd[1]) + '" stroke="#6a7080" stroke-width="1.5" stroke-linecap="round"/><rect x="' + r2(hd[0] - 1.6) + '" y="' + r2(hd[1] - 1.4) + '" width="7" height="2.8" rx="0.5" fill="#6a7080" stroke="#3a3a48" stroke-width="0.3"/>' + ci(r2(m[0]), r2(m[1]), 1.6, '#2a2a36');
      const b0 = gx + 9, f = flyF(st.rec.pt, tl, { fly: 1300, away: 2600, ret: 400 }); let bx = b0, op = 1;
      if (f) { const [ph, u, , d] = f; if (ph === 'fly') bx = b0 + 44 * (1 - (1 - u) * (1 - u)); else if (ph === 'away') { bx = b0 + 44; op = 1 - ss((d - 1500) / 500); } else op = ss(u); }
      if (op > 0.02) h += '<g opacity="' + r2(op) + '">' + ci(r2(bx), r2(gy - 1.8), 1.9, '#ffffff', '#9aa3b2') + '</g>'; return h; }; }
  // climbing dome: climbs up, hangs, waves from the top, looks around, climbs down
  const DMU = o(both(-3, -6), { lift: 15, armL: 158, armR: 158, sq: -0.04, footL: 1.4, footR: 1.4, pitch: 0.06, ly: -0.2, tilt: 0 });
  const DMB = {
    climb(t) { for (let i = 0; i < 4; i++) { const s = i % 2 ? -1 : 1; t.to(300, { armL: s > 0 ? 165 : 120, armR: s > 0 ? 120 : 165, footL: s > 0 ? 2.6 : 0.6, footR: s > 0 ? 0.6 : 2.6, lift: 3.75 * (i + 1), tilt: s * 3, pitch: 0.1, ly: -0.4, sqz: 0.3 }, 'io'); } t.to(240, o(DMU, { sqz: 0 }), 'io'); return t; },
    hang(t) { t.osc(2000, 4, { footL: 3, footR: 0.4, tilt: 3 }, { footL: 0.4, footR: 3, tilt: -3 }, 's').to(240, DMU, 'io'); return t; },
    topwave(t, X) { t.to(300, o({ armR: 150, hRy: -2, hap: 1, smile: 1, open: 0.4 }, X.cheer), 'o').osc(1200, 3, { armR: 120 }, { armR: 165 }, 'io').to(300, o(DMU, { hap: 0.3, smile: 0.7, open: 0 }), 'io'); return t; },
    peek(t) { t.to(400, { lx: -0.9, ly: 0.9, pitch: -0.2, htilt: -6 }, 'io').wait(600).to(400, { lx: 0.9, htilt: 6 }, 'io').wait(500).to(300, o(DMU, { lx: 0, htilt: 0 }), 'io'); return t; },
    down(t) { for (let i = 3; i >= 0; i--) { const s = i % 2 ? -1 : 1; t.to(260, { armL: s > 0 ? 160 : 110, armR: s > 0 ? 110 : 160, lift: 3.75 * i, footL: s > 0 ? 2 : 0, footR: s > 0 ? 0 : 2, tilt: s * 3 }, 'io'); } t.to(200, { sq: 0.1 }, 'i'); return t.back(320); },
  };
  // agility course: hurdles, weave poles, tyre jump, A-frame ramp
  const AGB = {
    hurdle(t) { for (let i = 0; i < 3; i++) t.to(120, { sq: 0.12, lift: -0.6, pitch: -0.04 }, 'i').to(240, { sq: -0.08, lift: 9, footL: 3, footR: 3, armL: 120, armR: 60, lean: 1 }, 'o').to(220, { lift: 0, sq: 0.06, footL: 0, footR: 0, armL: 40, armR: 40, lean: 0.4 }, 'i'); t.fx('dust', 'belly', 3); return t.back(260); },
    weave(t) { t.osc(1800, 4, { x: 3, tilt: 7, lean: 1, footL: 1.6 }, { x: -3, tilt: -7, lean: -1, footR: 1.6 }, 's'); return t.back(300); },
    tire(t, X) { t.to(260, { sq: 0.16, lift: -1.4, armL: 10, armR: 10, pitch: -0.1 }, 'io').to(300, o({ sq: -0.12, lift: 13, armL: 160, armR: 160, hLy: -6, hRy: -6, footL: 3, footR: 3, open: 0.5, wide: 0.5, hap: 1 }, X.tk || {}), 'o')
      .to(300, { lift: 0, sq: 0.14, armL: 40, armR: 40, hLy: 0, hRy: 0, footL: 0, footR: 0 }, 'i').fx('dust', 'belly', 4).to(200, { sq: 0 }, 'o'); return t.back(300); },
    ramp(t) { t.to(700, { lift: 10, pitch: 0.1, lean: 1, footL: 1.6, armL: 70, armR: 70 }, 'io').to(200, { pitch: -0.1 }, 'io').to(500, { lift: 0, pitch: -0.2, lean: 0.6, sq: 0.06, open: 0.5, wide: 0.6 }, 'i').to(200, { sq: 0, pitch: 0 }, 'o'); return t.back(300); },
  };
  // toss games: bocce (underhand roll), cornhole (underhand lob), horseshoes (swing + spin)
  const tossB = kind => function (t, X, rec) { const bo = kind === 'bocce'; t.to(300, o(hand(1, -2, 4), { armR: bo ? -8 : 6, lean: -0.5, lx: 0.8, ly: bo ? 0.6 : -0.1, sqz: 0.3, sq: bo ? 0.1 : 0.04 }), 'io')
    .to(kind === 'shoe' ? 200 : 240, o(hand(1, 2, -4), { armR: bo ? 60 : kind === 'shoe' ? 120 : 100, lean: 0.8, footL: 2, sq: -0.03, sqz: 0, open: 0.3 }), 'o'); push(rec, 'ts', t.t);
    t.to(300, { footL: 0, lean: 0.4 }, 'io').to(400, { lx: 0.9, ly: bo ? 0.7 : 0.3, wide: 0.6, open: 0.2 }, 'io').wait(500); return t.back(360); };
  const aimB = t => { const B = t.B; t.to(300, { lx: 0.9, ly: 0.3, htilt: 5, winkL: 0.8, tongue: 0.3 }, 'io').osc(1200, 3, { armR: B.armR + 18 }, { armR: B.armR - 6 }, 'io').to(200, { winkL: 0, tongue: 0 }); return t.back(300); };
  function tossProp(st, kind, col) { const R0 = st.rec, IC = kind === 'bag' ? ICX.bag(col) : kind === 'shoe' ? ICX.shoe : ICX.bocce, Fp = kind === 'bocce' ? { fly: 1500, away: 2600, ret: 400 } : { fly: 800, away: 2400, ret: 400 };
    return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const tl = tt % st.loop, [gx, gy] = g0(I), p = W.pawR, f0 = Math.max(0.4, facing(I)), f = flyF(R0.ts, tl, Fp), s = 2.8, T = [gx + 48, gy - 9];
      if (!f) return G(p[0], p[1] - 1, 0, s, IC, f0); const [ph, u, , d] = f;
      if (ph === 'ret') return G(p[0], p[1] - 1, 0, s, IC, f0 * ss(u));
      if (ph === 'away') return G(T[0], T[1], kind === 'shoe' ? 0 : 10, s * 0.75, IC, 1 - ss((d - Fp.away + 500) / 500));
      if (kind === 'bocce') { const v = 1 - (1 - u) * (1 - u); return G(lerp(p[0], T[0], v), lerp(p[1], T[1], v) - (u < 0.12 ? (1 - u / 0.12) * 4 : 0), 900 * v, s * (1 - 0.25 * v), IC); }
      return G(lerp(p[0], T[0], u), lerp(p[1], T[1], u) - Math.sin(Math.PI * u) * 24, (kind === 'shoe' ? 720 : 300) * u, s * (1 - 0.25 * u), IC); }; }
  // ping-pong
  const PG0 = S0({ armR: 44, pitch: -0.06, ly: 0.3 }, hand(1, 0, -4));
  const PGB = {
    serve(t, X, rec) { t.to(300, o(hand(-1, 6, -12), { armL: 70, ly: -0.6 }), 'io').to(300, { hLy: -18, armL: 110, ly: -0.9 }, 'o').to(200, { armR: 120, hRy: -8 }, 'io').to(110, { armR: 40, hRy: -2, lean: 0.6 }, 'o'); push(rec, 'h', t.t); return t.back(300); },
    rally(t, X, rec) { for (let i = 0; i < 6; i++) { const fh = i % 2 === 0; t.wait(160).to(140, fh ? { armR: 70, hRx: -4, lean: 0.6, x: 0.8 } : { armR: 30, hRx: 6, lean: -0.4, x: -0.8 }, 'o'); push(rec, 'h', t.t); } return t.back(300); },
    smash(t, X, rec) { t.to(220, { armR: 160, hRy: -10, lift: 4, sq: -0.06, open: 0.4, wide: 0.5 }, 'o').to(100, { armR: 30, hRy: 2, lift: 0, sq: 0.06, lean: 1 }, 'i'); push(rec, 'h', t.t); t.fx('spark', 'pawR', 3).wait(300); return t.back(300); },
  };
  // tetherball
  const TTB = {
    punch(t) { t.to(160, o(hand(1, 6, -10), { armR: 90, lean: -0.4, turn: -0.15 }), 'io').to(140, o(hand(1, -6, -14), { armR: 160, lean: 0.8, turn: 0.15, sq: -0.04, open: 0.4 }), 'o').fx('spark', 'pawR', 2).to(300, { turn: 0, lean: 0, lx: 0.9, ly: -0.6 }, 'io'); return t.back(300); },
    duck(t) { t.to(200, { sq: 0.2, lift: -2.4, close: 1, sqz: 0.8, armL: 100, armR: 100, hLy: -4, hRy: -4 }, 'o').wait(400).to(260, { sq: 0, lift: 0, close: 0, sqz: 0, wide: 0.8 }, 'o').fx('gust', 'head', 1); return t.back(300); },
    track(t) { t.osc(2400, 2, { lx: 0.9, turn: 0.2, ly: -0.5 }, { lx: -0.9, turn: -0.2, ly: -0.3 }, 's'); return t.back(300); },
    double(t) { TTB.punch(t); t.to(140, o(hand(-1, -6, -14), { armL: 160, lean: -0.8, sq: -0.04 }), 'o').fx('spark', 'pawL', 2); return t.back(300); },
  };
  // hopscotch: toss the stone, hop the squares (one foot / two feet), twirl, hop back, pick the stone up
  const HSB = {
    toss(t, X, rec) { t.to(300, o(hand(1, -4, 6), { armR: 10, lean: -0.4, lx: 0.8, ly: 0.8 }), 'io').to(200, o(hand(1, 4, -2), { armR: 70, lean: 0.4 }), 'o'); push(rec, 'ts', t.t); t.to(500, { lx: 0.9, ly: 0.9 }, 'io'); return t.back(300); },
    hops(t) { for (let i = 0; i < 6; i++) { const one = i % 3 !== 2, s = i % 2 ? 1 : -1; t.to(110, { sq: 0.1, lift: -0.5 }, 'i').to(200, { sq: -0.06, lift: 6, footL: one ? 3 : 0, footR: 0, armL: 90, armR: 90, x: (i + 1) * 0.8, tilt: one ? s * 2 : 0 }, 'o').to(180, { lift: 0, sq: 0.05 }, 'i'); } t.to(200, { footL: 0, tilt: 0 }); return t; },
    twirl(t) { t.to(160, { sq: 0.1 }, 'i').to(600, { spin: 360, lift: 5, sq: -0.05, hap: 1 }, 'io').to(10, { spin: 0 }).to(200, { lift: 0, sq: 0.05 }, 'i'); return t; },
    hopback(t) { for (let i = 5; i >= 0; i--) t.to(110, { sq: 0.1 }, 'i').to(200, { sq: -0.06, lift: 6, footR: 3, armL: 90, armR: 90, x: i * 0.8 }, 'o').to(180, { lift: 0, sq: 0.05 }, 'i'); return t.back(300); },
    pick(t, X, rec) { t.to(380, o(hand(1, -2, 10), { pitch: -0.4, ly: 1, sq: 0.1, armR: 12 }), 'io'); push(rec, 'pk', t.t); t.wait(200); return t.back(400); },
  };
  function hopProp(st) { const R0 = st.rec; return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const tl = tt % st.loop, [gx, gy] = g0(I), p = W.pawR, T = [gx + 30, gy + 1], ts = (R0.ts || [])[0], pk = (R0.pk || [])[0], f0 = Math.max(0.4, facing(I));
      if (ts == null || tl < ts || (pk != null && tl >= pk)) return G(p[0], p[1], 0, 2.6, ICX.stone, f0); const u = cl((tl - ts) / 600, 0, 1); return G(lerp(p[0], T[0], u), lerp(p[1], T[1], u) - Math.sin(Math.PI * u) * 14, 0, 2.6, ICX.stone); }; }
  // tunnel: crawls on all fours, peeks out, pops out cheering
  const TU0 = S0({ sq: 0.16, lift: -2.4, pitch: -0.22, ly: 0.8, armL: 60, armR: 60 }, both(-4, 6));
  const TUB = {
    crawl(t) { for (let i = 0; i < 6; i++) { const s = i % 2 ? -1 : 1; t.to(220, { armL: s > 0 ? 82 : 46, armR: s > 0 ? 46 : 82, footL: s > 0 ? 0 : 1.6, footR: s > 0 ? 1.6 : 0, tilt: s * 3, x: s * 0.5 }, 'io'); } return t.back(260); },
    peek(t) { t.to(300, { pitch: 0.12, ly: -0.2, sq: 0.06, wide: 0.6, lx: -0.8 }, 'io').wait(400).to(400, { lx: 0.8 }, 'io').wait(300); return t.back(300); },
    pop(t, X) { t.to(200, { sq: 0.2, lift: -3 }, 'i'); cheer(t, X, { pitch: 0.06, ly: 0 }); return t; },
  };
  // frisbee: throws it, it loops out and comes back like a boomerang, jump-catch
  const FRB = {
    throw(t, X, rec) { t.to(320, o(hand(1, 10, 0), { armR: 30, turn: -0.2, lean: -0.4, lx: 0.6 }), 'io').to(160, o(hand(1, -6, -4), { armR: 96, turn: 0.2, lean: 0.8, open: 0.3 }), 'o'); push(rec, 'th', t.t); t.to(400, { turn: 0, lean: 0.2, lx: 0.9, ly: -0.3 }, 'io').to(600, { lx: -0.2, ly: -0.6 }, 'io'); return t; },
    catch(t, X, rec) { t.to(200, { sq: 0.12, lift: -1 }, 'i').to(240, o(both(6, -14), { armL: 160, armR: 160, lift: 10, sq: -0.08, wide: 0.6, open: 0.5 }), 'o'); push(rec, 'ca', t.t); t.to(260, { lift: 0, sq: 0.08 }, 'i').to(200, o({ sq: 0, sqz: 0.6, hap: 1, smile: 1 }, X.cheer), 'o'); return t.back(360); },
  };
  function frisbeeProp(st, col) { const R0 = st.rec, IC = ICX.disc(col); return (I, tt) => { const W = I.W; if (!W || !okp(W.pawR)) return ''; const tl = tt % st.loop, p = W.pawR, f0 = Math.max(0.4, facing(I)), m = mid(W), mm = [m[0], m[1] - 4], th = R0.th || [], ca = R0.ca || [];
      let e = -1; th.forEach((v, i) => { if (tl >= v && ca[i] != null && tl < ca[i]) e = i; });
      if (e >= 0) { const a = th[e], b = ca[e], u = (tl - a) / (b - a); return G(lerp(p[0], mm[0], u) + Math.sin(Math.PI * u) * 56, lerp(p[1], mm[1], u) - Math.sin(Math.PI * u) * 16 - Math.sin(Math.PI * 2 * u) * 6, Math.sin(Math.PI * 2 * u) * 12, 3 * (1 - 0.35 * Math.sin(Math.PI * u)), IC); }
      return ca.some(v => tl >= v && tl < v + 1200) ? G(mm[0], mm[1], 0, 3, IC, f0) : G(p[0], p[1], -10, 3, IC, f0); }; }

  const CX = {};
  function cBuild(key, X) {
    X = o(BB[key] || {}, X || {}); const P = PROF[key] || {}, nm = n => key ? n + '@' + key : n, S = {}, SB = o(SIT0, P.pose || {});
    const sig = X.b || X.p || (P.f || []).find(f => typeof f === 'function'), pc = X.pc || '#e8483c';
    const H1 = (n, B, ord, BK, gaps, e) => (S[nm(n)] = hold(B, ord, o(COM, BK || {}), X, sig, gaps || [500, 700, 600, 800], e || { breathe: 0.4 }));
    S[nm('kick')] = kickMove(X); S[nm('shellpick')] = shellMove(X);
    H1('bowl', o(BW0, X.bwp || {}), ['munch', 'up', 'munch', 'slurp', 'lick', 'sig', 'munch', 'tummy', 'hic'], BWB, [300, 500, 400, 600]);
    H1('dishes', DS0, ['scrub', 'rinse', 'squeak', 'stack', 'scrub', 'hum', 'rinse', 'stack', 'bubble', 'sig', 'scrub', 'squeak', 'stack'], DSB, [300, 500, 400]).prop = null;
    S[nm('dishes')].prop = dishProp(S[nm('dishes')]);
    { const st = H1('grill', GR0, ['poke', 'flip', 'smoke', 'season', 'poke', 'flip', 'sniff', 'sig', 'serve'], GRB, [400, 600, 500]); st.prop = grillProp(st); }
    H1('toastwait', TW0, ['tap', 'peek', 'rub', 'hum', 'look', 'tap'], TWB, [600, 900]); S[nm('toast')] = toastMove(X);
    { const PO = o(SB, { sq: (SB.sq || 0) + 0.04 }); H1('pouf', PO, ['bounce', 'look', 'big', 'wiggle', 'rock', 'bounce', 'sig', 'spinb', 'giggle'], POB, [500, 900, 700]); const a = sitdown(PO, P); a.next = 'pouf'; S[nm('poufin')] = a; S[nm('poufout')] = standup(PO, P); }
    { const SP = o(SP0, P.dn === 'float' ? { sit: 0, sk: 3 } : {}, X.spp || {}); H1('splash', SP, ['slap', 'kick', 'duck', 'atyou', 'soak', 'sig', 'slap', 'wave'], SPB, [500, 800, 600], { breathe: 0.5 }); S[nm('splashin')] = splashIn(SP, P); S[nm('splashout')] = splashOut(SP); }
    H1('perform', PF0, ['sing', 'step', 'sing', 'belt', 'point', 'spin', 'sing', 'sig', 'belt', 'bow'], PFB, [300, 500, 400]).prop = micProp(X.mc || '#3b3b4a');
    H1('dj', DJ0, ['nod', 'scratch', 'nod', 'pump', 'point', 'nod', 'scratch', 'drop', 'sig', 'spin', 'pump'], DJB, [200, 300]).prop = phoneProp(X.hc || '#45189a');
    H1('pinball', PB0, ['flip', 'track', 'flip', 'nudge', 'multi', 'yay', 'flip', 'oops', 'sig'], PBB, [200, 400, 300]);
    H1('dancecab', DC0, ['steps', 'arrows', 'steps', 'jump', 'combo', 'spin', 'steps', 'freeze', 'sig'], DCB, [150, 250]);
    { const st = H1('hockey', HK0, ['ready', 'hit', 'ready', 'block', 'hit', 'yay', 'ready', 'hit', 'oops', 'sig'], HKB, [300, 500, 400]); st.prop = puckProp(st, pc, 0); }
    { const st = H1('billiards', BL0, ['chalk', 'aim', 'shoot', 'yay', 'aim', 'shoot', 'miss', 'circle', 'sig'], BLB, [500, 500, 0]); st.prop = cueProp(st); }
    const GM = (n, B, ord, BK, gaps, prop) => { const st = H1('g_' + n, B, ord, BK, gaps); if (prop) st.prop = prop(st); };
    GM('goal', ST0, ['dribble', 'kick', 'watch', 'yay', 'dribble', 'header', 'dribble', 'kick', 'sig', 'yay'], GOB, [400, 600, 500], goalProp);
    GM('keep', KP0, ['ready', 'diveL', 'ready', 'catch', 'ready', 'diveR', 'punch', 'sig', 'ready', 'catch'], KPB, [300, 500], keepProp);
    GM('hoop', ST0, ['dribble', 'shoot', 'yay', 'dribble', 'spinball', 'dribble', 'shoot', 'oops', 'sig', 'dribble', 'shoot', 'yay'], HPB, [300, 500, 400], hoopProp);
    GM('golf', GF0, ['line', 'waggle', 'putt', 'yay', 'line', 'waggle', 'putt', 'oops', 'sig'], GFB, [400, 300, 300], golfProp);
    GM('dome', ST0, ['climb', 'hang', 'topwave', 'peek', 'hang', 'down', 'yay', 'climb', 'hang', 'down', 'sig'], DMB, [300, 200]);
    GM('agility', ST0, ['hurdle', 'weave', 'pant', 'tire', 'ramp', 'yay', 'sig', 'hurdle', 'pant'], AGB, [300, 500]);
    GM('bocce', ST0, ['aim', 'roll', 'watch', 'yay', 'aim', 'roll', 'watch', 'oops', 'sig'], { aim: aimB, roll: tossB('bocce') }, [500, 300, 200], st => tossProp(st, 'bocce'));
    GM('cornhole', ST0, ['aim', 'toss', 'yay', 'aim', 'toss', 'watch', 'oops', 'sig'], { aim: aimB, toss: tossB('bag') }, [500, 300, 300], st => tossProp(st, 'bag', pc));
    GM('shoe', ST0, ['aim', 'toss', 'yay', 'aim', 'toss', 'oops', 'sig'], { aim: aimB, toss: tossB('shoe') }, [500, 300, 300], st => tossProp(st, 'shoe'));
    GM('pong', PG0, ['serve', 'rally', 'smash', 'yay', 'serve', 'rally', 'oops', 'sig'], PGB, [300, 0, 0, 400], st => puckProp(st, pc, 1));
    GM('tether', ST0, ['punch', 'track', 'duck', 'punch', 'double', 'yay', 'track', 'sig'], TTB, [400, 300]);
    GM('villa', SB, ['look', 'wave', 'wiggle', 'yawn', 'giggle', 'sig', 'doze', 'nod'], {}, [900, 1400, 1100]);
    GM('hop', ST0, ['toss', 'hops', 'twirl', 'hopback', 'pick', 'yay', 'sig'], HSB, [400, 200, 200, 200, 300]);
    GM('tunnel', TU0, ['crawl', 'peek', 'crawl', 'pop', 'crawl', 'giggle', 'sig'], TUB, [300, 500]);
    GM('frisbee', ST0, ['throw', 'catch', 'yay', 'throw', 'catch', 'sig', 'throw', 'catch', 'clap'], FRB, [300, 0, 400], st => frisbeeProp(st, X.fc2 || '#ffcc3a'));
    GM('cheer', ST0, ['clap', 'watch', 'yay', 'look', 'clap', 'sig', 'wave', 'oops', 'clap'], {}, [500, 800, 600]);
    R.add(S); R.HS = Object.assign(R.HS || {}, S); if (key) CX[key] = X;
  }
  cBuild(null, {});
  Object.assign(H, { cBuild, CX, ST0 });
});
