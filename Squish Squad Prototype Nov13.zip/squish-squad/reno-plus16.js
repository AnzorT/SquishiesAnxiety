// Renovation Catalog round 16 — Movie Room furniture remodel, part 1: seating (sofas, chairs, pet bed) + catalog clean-up.
// Deletes MOV-027/039/059/079/099, renames every Movie Room furniture piece to a short simple name.
// Toolkit: xf/tilt (rotate any K solid in place, normals follow), rod() (3D tube between two points), tiltAll, fxEll (floor glow ellipse).
// Sets RenoDraw.PLUS16; catalog edits RD.SET16 (+ RD.DEL16).
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS15 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS16) return;
  const K = X.K, { solid, box, cyl, ball, slab, slabX, arcW, disc, pillowY, pillowZ, shade, mix, f1 } = K;
  const N = RD.N, PI = Math.PI, GOLD = '#e2b14a', CH = '#d5dde2';
  const rep = (n, f) => Array.from({ length: n }, (_, i) => f(i));
  const em = o => Object.assign({ emit: 1, noOut: 1 }, o || {});
  const W_ = o => Object.assign({ mat: 'wood' }, o || {}), M_ = o => Object.assign({ mat: 'metal' }, o || {}), F_ = o => Object.assign({ mat: 'fab', soft: 1 }, o || {});
  const L_ = o => Object.assign({ mat: 'lea' }, o || {}), PL = o => Object.assign({ mat: 'pl' }, o || {}), G_ = o => Object.assign({ shine: 1 }, o || {});
  // ---------- vector + transform helpers ----------
  const cr = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], dt = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const rotF = (ax, an) => { const L = Math.hypot(ax[0], ax[1], ax[2]) || 1, k = ax.map(v => v / L), c = Math.cos(an), s = Math.sin(an); return v => { const kv = cr(k, v), kd = dt(k, v); return [0, 1, 2].map(i => v[i] * c + kv[i] * s + k[i] * kd * (1 - c)); }; };
  const xf = (S, R, piv, off) => { piv = piv || [0, 0, 0]; off = off || [0, 0, 0]; const seen = new Set();
    const mv = p => { if (seen.has(p)) return; seen.add(p); const q = R([p[0] - piv[0], p[1] - piv[1], p[2] - piv[2]]); p[0] = q[0] + piv[0] + off[0]; p[1] = q[1] + piv[1] + off[1]; p[2] = q[2] + piv[2] + off[2]; };
    S.pts.forEach(mv); S.faces.forEach(F => { F.q.forEach(mv); const n = R(F.n); F.n[0] = n[0]; F.n[1] = n[1]; F.n[2] = n[2]; }); return S; };
  const tilt = (S, ax, an, piv) => xf(S, rotF(ax, an), piv);
  const tiltAll = (L, ax, an, piv) => L.map(S => tilt(S, ax, an, piv));
  // loft: rings [y, cx, cz, a, b] (horizontal ellipses whose centre can drift) -> one convex K solid
  const newell = q => { const n = [0, 0, 0]; for (let i = 0; i < q.length; i++) { const a = q[i], b = q[(i + 1) % q.length]; n[0] += (a[1] - b[1]) * (a[2] + b[2]); n[1] += (a[2] - b[2]) * (a[0] + b[0]); n[2] += (a[0] - b[0]) * (a[1] + b[1]); } return n; };
  const loft = (R, col, o) => { o = o || {}; const n = o.n || 24, RR = R.map(([y, cx, cz, a, b]) => rep(n, i => { const t = i / n * 2 * PI; return [cx + a * Math.cos(t), y, cz + b * Math.sin(t)]; })), faces = [];
    for (let k = 0; k < RR.length - 1; k++) for (let i = 0; i < n; i++) { const j = (i + 1) % n, q = [RR[k][i], RR[k][j], RR[k + 1][j], RR[k + 1][i]]; let nn = newell(q); const L = Math.hypot(nn[0], nn[1], nn[2]); if (L < 0.02) continue; nn = nn.map(v => v / L);
      const mx = (q[0][0] + q[1][0] + q[2][0] + q[3][0]) / 4 - (R[k][1] + R[k + 1][1]) / 2, mz = (q[0][2] + q[1][2] + q[2][2] + q[3][2]) / 4 - (R[k][2] + R[k + 1][2]) / 2; if (mx * nn[0] + mz * nn[2] < 0) nn = nn.map(v => -v); faces.push({ q, n: nn }); }
    faces.push({ q: RR[0], n: [0, -1, 0], cap: 1 }); const lr = R[R.length - 1]; if (lr[3] > 0.4) faces.push({ q: RR[RR.length - 1], n: [0, 1, 0], cap: 2 });
    return { faces, pts: [].concat(...RR), col, soft: o.soft, shine: o.shine, emit: o.emit, cv: 1, zb: o.zb || 0, noOut: o.noOut, part: o.part, op: o.op, mat: o.mat }; };
  const rod = (a, b, r, col, o) => { const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], L = Math.hypot(d[0], d[1], d[2]), u = d.map(v => v / L), S = cyl(0, 0, 0, r, L, col, Object.assign({ n: 10 }, o || {}));
    const ax = cr([0, 1, 0], u), sn = Math.hypot(ax[0], ax[1], ax[2]); return xf(S, sn < 1e-6 ? (u[1] > 0 ? (v => v) : rotF([1, 0, 0], PI)) : rotF(ax, Math.atan2(sn, u[1])), [0, 0, 0], a); };
  const pipe = (P, r, col, o) => { const out = []; for (let i = 0; i < P.length - 1; i++) out.push(rod(P[i], P[i + 1], r, col, o)); for (let i = 1; i < P.length - 1; i++) out.push(ball(P[i][0], P[i][1] - r, P[i][2], r, col, Object.assign({ k: 3, n: 8, shine: 0 }, o || {}))); return out; };
  const n4 = v => Math.round(v * 1e4) / 1e4, P2 = q => f1(q[0]) + ' ' + f1(q[1]);
  const an = (a, v, d, b) => '<animate attributeName="' + a + '" values="' + v + '" dur="' + d + 's"' + (b ? ' begin="' + b + 's"' : '') + ' repeatCount="indefinite"/>';
  const bobA = (a, d) => '<animateTransform attributeName="transform" type="translate" values="0 0;0 ' + (-a) + ';0 0" dur="' + d + 's" calcMode="spline" keyTimes="0;0.5;1" keySplines="0.45 0 0.55 1;0.45 0 0.55 1" repeatCount="indefinite"/>';
  // flat horizontal ellipse on the floor (radius R in model units), filled with a gradient id
  const fxEll = (c, x, y, z, R, fill, extra) => { const q = c.p(x, y, z); return '<ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + f1(R * c.k) + '" ry="' + f1(R * c.k * X.SA) + '" fill="' + fill + '">' + (extra || '') + '</ellipse>'; };
  const FONT = `font-family="'Fredoka','Arial Rounded MT Bold',sans-serif" font-weight="700"`;
  const mtx = (o, a, b) => 'matrix(' + [a[0] - o[0], a[1] - o[1], b[0] - o[0], b[1] - o[1], o[0], o[1]].map(n4).join(' ') + ')';
  const frame = (p, O, U, Vd) => mtx(p(...O), p(O[0] + U[0], O[1] + U[1], O[2] + U[2]), p(O[0] + Vd[0], O[1] + Vd[1], O[2] + Vd[2]));
  const kern = (x, y, z, r, i) => { const C = ['#fffaf0', '#fff4d6', '#ffefc0']; return [ball(x, y, z, r * 1.1, C[i % 3], { k: 3, n: 9, sy: 0.85, shine: 0, mat: 'fab' }), ball(x + r * 0.7, y + r * 0.5, z + r * 0.4, r * 0.8, C[(i + 1) % 3], { k: 3, n: 8, shine: 0, mat: 'fab', noOut: 1 }), ball(x - r * 0.5, y + r * 0.6, z - r * 0.3, r * 0.55, '#f6cf5a', { k: 3, n: 8, shine: 0, noOut: 1 })]; };
  const cup = (x, y, z, r, h, col, band) => [cyl(x, y, z, r * 0.84, h, col, PL({ n: 12, rg: [[0, 0, 0.84], [h, 0, 1]] })), cyl(x, y + h * 0.45, z, r * 0.95, h * 0.2, band || '#ffffff', PL({ n: 12, noOut: 1 })), cyl(x, y + h, z, r * 1.04, 1.1, '#ffffff', PL({ n: 12 })), rod([x, y + h, z], [x + r * 0.5, y + h + 7, z - r * 0.3], 0.55, '#f4f4f4', PL({ n: 5 }))];
  const holder = (x, y, z, r, ring) => { const o = [cyl(x, y, z, r, 1, ring || CH, M_({ n: 16 })), cyl(x, y + 0.2, z, r * 0.76, 1, '#141416', { n: 16, noOut: 1 })]; return o; };

  // ======================= MOV-013 OLD FUTON =======================
  N.futon16 = S => { const W = 150, Dp = 74, by = 14, PN = '#dcb37a', PD = '#b98a50', FAB = '#6f84a8', FL = shade(FAB, 1.1), FD = shade(FAB, 0.8), TIE = shade(FAB, 0.55), sag = x => by + 16.6 - 3.4 * (1 - Math.min(1, Math.abs(x) / 74));
    // every part sits clear of its neighbours (no part sunk into another), so the depth sort has one answer at every angle; small details are glued (par) to the part they lie on
    return { w: W + 16, d: Dp + 8, act: 'sit', seats: [{ x: -34, z: 8, h: 36 }, { x: 34, z: 8, h: 36 }], build: () => { const o = [], on = (p, L) => L.map(k => { k.par = p; o.push(k); return k; }), FP = {};
      [-1, 1].forEach(sg => { const x = sg * (W / 2 + 3);
        o.push(box(x, 0, -Dp / 2 + 5, 8, 64, 8, PD, W_({ r: 2.4, bev: 1.6 })), FP[sg] = box(x, 0, Dp / 2 - 5, 8, 36, 8, PD, W_({ r: 2.4, bev: 1.6 })));
        // arm rail + stretcher run between the posts (not through them)
        o.push(box(x, 31, 0, 10, 5, Dp - 18, PN, W_({ r: 2, bev: 1.5 })), box(x, 6, 0, 6, 4, Dp - 18, PD, W_({ r: 1 })));
        rep(3, i => o.push(box(x, 10, -Dp / 2 + 20 + i * 17, 4.6, 21, 3.6, PN, W_({ r: 1.2 })))); });
      o.push(slabX(0, 58, -Dp / 2 + 3, W - 4, 6, 6, PN, W_({ r: 2 })), slabX(0, 5, Dp / 2 - 4, W - 4, 9, 4, PN, W_({ r: 1.5 })), box(0, by - 6, 0, W - 6, 4, Dp - 14, PD, W_({ r: 1 })));
      // tape wrapped round the front-left post
      on(FP[-1], [box(-W / 2 - 3, 18, Dp / 2 - 5, 9.4, 4, 9.4, '#b9bec4', { r: 1.2, mat: 'pl' })]);
      // mattress: base layer, two seat halves sagging into the middle (in front of the back half), leaning back half
      o.push(box(0, by - 2, 0, W - 6, 3, Dp - 14, FD, F_({ r: 6 })));
      const SE = {}; [-1, 1].forEach(sg => o.push(SE[sg] = tilt(pillowY(sg * 36.5, by + 4.6, 7, 72, 12, 44, FL, F_()), [0, 0, 1], sg * 0.046, [sg * 72.5, by + 4.6, 7])));
      const BK = pillowZ(0, by + 12, -21.5, W - 6, 38, 12, FAB, F_()), bt = [];
      [-54, -18, 18, 54].forEach(x => [10, 26].forEach(h => bt.push(ball(x, by + 12 + h, -14.8, 1.7, TIE, { k: 3, n: 8, sz: 0.5, noOut: 1, shine: 0 }))));
      tiltAll([BK].concat(bt), [1, 0, 0], -0.08, [0, by + 12, -21.5]); o.push(BK); on(BK, bt).forEach(k => k.fn = [0, 0.08, 1]);
      [-54, -18, 18, 54].forEach(x => on(SE[Math.sign(x)], [ball(x, sag(x) - 0.6, 10, 1.7, TIE, { k: 3, n: 8, sy: 0.5, noOut: 1, shine: 0 })]));
      // plaid patch on the right seat
      const [pa] = on(SE[1], [box(46, sag(46) - 0.3, 14, 17, 0.9, 13, '#c8584a', F_({ r: 1, yaw: 0.25 }))]);
      on(pa, [box(46, sag(46) + 0.5, 14, 17, 0.2, 2, '#f0d49a', { r: 0, yaw: 0.25, noOut: 1 }), box(46, sag(46) + 0.5, 14, 2, 0.2, 13, '#f0d49a', { r: 0, yaw: 0.25, noOut: 1 })]);
      // crumpled mustard blanket on the left end (lies on the seat), one corner hanging down in front of the mattress + rail
      on(SE[-1], [ball(-54, sag(-54) - 1.5, 8, 14, '#e2b45a', F_({ sy: 0.42, sx: 1.2, k: 4, n: 14, shine: 0 })), ball(-46, sag(-46) + 3, 2, 8, '#ecc472', F_({ sy: 0.55, k: 4, n: 12, shine: 0 })), ball(-60, sag(-60) + 4, -2, 6, '#d9a84c', F_({ sy: 0.6, k: 4, n: 10, shine: 0 }))]);
      const BC = box(-58, by - 3, Dp / 2 + 1.5, 20, 18, 3, '#e2b45a', F_({ r: 3 })); o.push(BC);
      on(BC, rep(5, i => box(-66 + i * 4, by - 6, Dp / 2 + 3.2, 1, 4, 1, '#c99a40', { r: 0, noOut: 1 })));
      // old striped pillow slumped on the right seat against the back half
      const PW = pillowZ(54, by + 19, -10, 28, 26, 9, '#efe4cc', F_()), PS = slabX(54, by + 30, -5.3, 26, 3, 0.6, '#7fa4c8', { r: 0.4, noOut: 1, mat: 'fab' });
      tiltAll([PW, PS], [0, 0, 1], 0.18, [54, by + 19, -10]); o.push(PW); on(PW, [PS])[0].fn = [-0.18, 0, 1];
      return o; } }; };

  // ======================= MOV-033 COMFY COUCH (colour picker) =======================
  const PIL33 = [['#f3d27a', '#f3ead8'], ['#f3ead8', '#7fb2c9'], ['#f3ead8', '#e98f74'], ['#f3ead8', '#9cbf8a'], ['#f3d27a', '#f3ead8']];
  N.couch16 = S => { const n = 3, SW = 54, AW = 22, Wd = n * SW + 2 * AW, Dp = 90, by = 10, xs = rep(n, i => -Wd / 2 + AW + SW * (i + 0.5)), PC = PIL33[(S.ci | 0) % PIL33.length];
    // every part sits clear of its neighbours (arms beside the base/back, cushions on the base, back pillows on the seat cushions); small details are glued (par) to the part they lie on
    return { w: Wd + 14, d: Dp + 6, act: 'sit', seats: xs.map(x => ({ x, z: 8, h: by + 28 })), build: P => { const o = [], A = P.a, AL = P.aL, AD = P.aD, WD = '#b07c48', IW = Wd - 2 * AW, on = (p, L, fn) => L.map(k => { k.par = p; if (fn) k.fn = fn; o.push(k); return k; });
      // tapered wood legs (under the arms) + base between the arms
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => o.push(cyl(sx * (Wd / 2 - 12), 0, sz * (Dp / 2 - 12), 3.4, by, WD, W_({ n: 10, rg: [[0, 0, 0.62], [by, 0, 1.1]] }))));
      o.push(box(0, by, 0, IW, 14, Dp - 4, AD, F_({ r: 10, bev: 4 })));
      // back frame on the base, three seat cushions on the base, three fat back cushions standing on the seat cushions
      o.push(slab(0, by + 14, -Dp / 2 + 9, IW, 42, 16, A, F_({ r: 14 })));
      xs.forEach(x => o.push(pillowY(x, by + 14, 11, SW - 2, 15, Dp - 36, AL, F_())));
      xs.forEach(x => o.push(tilt(pillowZ(x, by + 29, -Dp / 2 + 25.5, SW - 3, 34, 14, AL, F_()), [1, 0, 0], -0.07, [x, by + 29, -Dp / 2 + 25.5])));
      // rolled arms: one round-topped piece each
      const ARM = {}; [-1, 1].forEach(sg => { const x = sg * (Wd / 2 - AW / 2), z1 = Dp / 2 - 3;
        o.push(ARM[sg] = slab(x, by, 0, AW, 40, Dp - 6, A, F_({ r: AW / 2 - 0.5 })));
        const [dc] = on(ARM[sg], [disc(x, by + 29, z1 + 0.6, AW / 2 - 2.5, 0.9, AD, F_({ n: 18 }))], [0, 0, 1]); on(dc, [disc(x, by + 29, z1 + 1.5, 2.2, 0.6, shade(A, 0.7), { n: 10, noOut: 1, mat: 'fab' })], [0, 0, 1]); });
      // two throw pillows leaning in the corners (stripes on the left one, buttons on the right one), sitting on the seat cushions in front of the back cushions
      [-1, 1].forEach(sg => { const px = sg * (Wd / 2 - AW - 20), pz = -Dp / 2 + 40, py = by + 30.6, col = sg < 0 ? PC[0] : PC[1], PW = pillowZ(px, py, pz, 32, 30, 10, col, F_()), L = [];
        if (sg > 0) rep(5, i => L.push(ball(px - 9 + (i % 3) * 9 + (i > 2 ? 4.5 : 0), py + 8 + (i > 2 ? 13 : 0), pz + 5.3, 1.8, shade(col, 0.7), { k: 3, n: 8, sz: 0.4, noOut: 1, shine: 0 })));
        else [0, 1].forEach(j => L.push(slabX(px, py + 9 + j * 10, pz + 5.2, 27, 2.4, 0.6, shade(col, 0.78), { r: 0.4, noOut: 1, mat: 'fab' })));
        tiltAll(tiltAll([PW].concat(L), [0, 0, 1], -sg * 0.08, [px, py, pz]), [1, 0, 0], -0.08, [px, py, pz]); o.push(PW); on(PW, L, [0, 0.08, 1]); });
      // cosy knit throw folded in a soft stack on the right arm, with a stripe and fringe
      { const xa = Wd / 2 - AW / 2, THR = PC[0] === '#f3d27a' ? '#e98f74' : '#f3d27a', ST = shade(THR, 0.78), y0 = by + 39.6;
        const [T1] = on(ARM[1], [pillowY(xa, y0, 6, AW + 2, 5, 36, THR, F_())]), [T2] = on(T1, [pillowY(xa, y0 + 4.4, 5, AW - 2, 5, 33, mix(THR, '#ffffff', 0.12), F_())]);
        on(T2, [slabX(xa, y0 + 6.6, 5 + 16.7, AW - 6, 1.4, 0.5, ST, { r: 0.3, noOut: 1, mat: 'fab' })], [0, 0, 1]);
        on(T1, rep(7, i => box(xa - AW / 2 + i * AW / 6, y0 - 1.6, 6 + 18.4, 1.1, 3, 1.1, ST, { r: 0.4, noOut: 1, mat: 'fab' })), [0, 0, 1]); }
      // TV remote on the left arm
      { const x = -Wd / 2 + AW / 2, [RM] = on(ARM[-1], [box(x, by + 39.6, 14, 6, 2.2, 16, '#3a3b40', PL({ r: 1.6, yaw: 0.2 }))]); on(RM, [['#ff5a4a', 0], ['#4fd06a', 4], ['#4fa8ff', 8]].map(([c, dz]) => ball(x + dz * 0.2, by + 41.8, 9 + dz, 0.9, c, { k: 2, n: 6, sy: 0.5, noOut: 1 })), [0, 1, 0]); }
      return o; } }; };

  // ======================= MOV-053 LEATHER LOVESEAT =======================
  N.loveseat16 = S => { const n = 2, SW = 60, AW = 26, Wd = n * SW + 2 * AW, Dp = 92, by = 21, xs = rep(n, i => -Wd / 2 + AW + SW * (i + 0.5));
    const LEA = '#a65a33', LL = shade(LEA, 1.12), LD = shade(LEA, 0.8), BTN = shade(LEA, 0.5), STI = shade(LEA, 1.4);
    // arms stand beside the base and back frame, cushions sit on the base / in front of the frame; stitching, tufting, cup holders glued (par) to their part
    return { w: Wd + 6, d: Dp + 6, act: 'sit', seats: xs.map(x => ({ x, z: 8, h: 36 })), build: () => { const o = [], IW = Wd - 2 * AW, on = (p, L, fn) => L.map(k => { k.par = p; if (fn) k.fn = fn; o.push(k); return k; });
      const PLN = box(0, 0, 0, Wd - 14, 7, Dp - 16, '#232326', PL({ r: 3 })); o.push(PLN); on(PLN, [slabX(0, 1.6, Dp / 2 - 7.6, Wd - 18, 1.8, 0.6, '#ffc870', em())], [0, 0, 1]);
      o.push(box(0, 7, 0, IW, 14, Dp - 4, LD, L_({ r: 10, bev: 4, soft: 1 })));
      xs.forEach(x => { const SC = pillowY(x, by, 10, SW - 2, 15, Dp - 34, LL, L_({ soft: 1 })); o.push(SC); on(SC, [slabX(x, by + 8, 39.3, SW - 12, 0.7, 0.6, STI, { r: 0.3, noOut: 1, mat: 'lea' })], [0, 0, 1]); });
      // tall rolled back frame + one thick back cushion per seat, each with real diamond tufting (pillowy diamonds, buttons in the dimples)
      const bz = -Dp / 2 + 10, zf = -20, yb = 32, yt = 72, BF = slab(0, by, bz, IW, 59, 16, LEA, L_({ r: 14, soft: 1 }));
      o.push(BF); on(BF, [slabX(0, by + 58.4, bz + 4, IW - 16, 0.7, 0.6, STI, { r: 0.3, noOut: 1, mat: 'lea' })], [0, 1, 0]);
      xs.forEach(x => { const BC = slab(x, yb, zf - 4, SW - 3, yt - yb, 8, LD, L_({ r: 7, soft: 1 })), T = []; o.push(BC);
        const PX = 13, rows = [43, 53.5, 64];
        rows.forEach((y, j) => { const odd = j % 2, nI = odd ? 3 : 4; rep(nI, i => { const px = x + (i - (nI - 1) / 2) * PX;
            T.push(ball(px, y, zf, 6.4, i % 2 === odd % 2 ? LL : shade(LL, 0.96), L_({ sx: 1.18, sy: 1, sz: 0.4, k: 4, n: 14, shine: 0.5, noOut: 1 }))); }); });
        on(BC, T, [0, 0, 1]);
        rep(2, j => { const y = (rows[j] + rows[j + 1]) / 2; rep(3, i => on(BC, [ball(x + (i - 1) * PX, y, zf + 2.3, 1.3, BTN, { sz: 0.6, k: 3, n: 8, noOut: 1, mat: 'lea' })], [0, 0, 1])); });
        [-1, 1].forEach(sg => on(BC, [ball(x + sg * 1.5 * PX, rows[1], zf + 2.3, 1.3, BTN, { sz: 0.6, k: 3, n: 8, noOut: 1, mat: 'lea' })], [0, 0, 1])); });
      // padded shelter arms with cup holders (blue glow ring), a soda in the right one
      [-1, 1].forEach(sg => { const x = sg * (Wd / 2 - AW / 2), z = Dp / 2 - 16, AB = box(x, 7, 0, AW, 35, Dp - 6, LEA, L_({ r: 8, soft: 1 })), CP = box(x, 42, 0, AW, 5, Dp - 4, LL, L_({ r: 6, bev: 2.5, soft: 1 }));
        o.push(AB, CP); on(AB, [slabX(x, 30, Dp / 2 - 2.6, AW - 6, 0.7, 0.6, STI, { r: 0.3, noOut: 1, mat: 'lea' })], [0, 0, 1]);
        on(CP, [cyl(x, 46.6, z, 6, 0.5, '#7fd8ff', em({ n: 16 }))].concat(holder(x, 46.8, z, 5)), [0, 1, 0]);
        if (sg > 0) { const [c0, ...cr] = cup(x, 47, z, 4, 12, '#d9363b'); o.push(c0); on(c0, cr); } });
      return o; } }; };

  // ======================= MOV-073 RECLINER SOFA (middle seat reclined, footrest out) =======================
  N.recliner16 = S => { const n = 3, SW = 56, CW = 18, EW = 20, Wd = n * SW + (n - 1) * CW + 2 * EW, Dp = 96, by = 12, LEA = '#b8703e', LL = shade(LEA, 1.12), LD = shade(LEA, 0.78), STI = shade(LEA, 1.45);
    const xs = rep(n, i => -Wd / 2 + EW + SW / 2 + i * (SW + CW)), cxs = rep(n - 1, i => xs[i] + SW / 2 + CW / 2), rec = [0, 1, 0];
    // seats, consoles and end arms stand side by side with small gaps; each back hinges at its bottom-back edge (upright -0.06, reclined -0.42: its cushions are glued to it)
    return { w: Wd + 6, d: Dp + 30, act: 'sit', seats: xs.map((x, i) => ({ x, z: rec[i] ? 4 : 8, h: by + 28 })), build: () => { const o = [], on = (p, L, fn) => L.map(k => { k.par = p; if (fn) k.fn = fn; o.push(k); return k; });
      o.push(box(0, 0, 0, Wd - 10, by, Dp - 14, '#2b2320', PL({ r: 3 })));
      xs.forEach((x, i) => { const r = rec[i], SB = box(x, by, 4.5, SW - 2, 15, Dp - 15, LD, L_({ r: 8, bev: 3, soft: 1 })), SP = pillowY(x, by + 15, r ? 1.5 : 8, SW - 4, 14, r ? 75 : Dp - 34, LL, L_());
        o.push(SB, SP); on(SP, [slabX(x, by + 22, 37.3, SW - 12, 0.7, 0.6, STI, { r: 0.3, noOut: 1, mat: 'lea' })], [0, 0, 1]);
        const th = r ? -0.42 : -0.06, piv = [x, by, -Dp / 2 + 2], BK = slab(x, by, -Dp / 2 + 7, SW - 2, r ? 66 : 72, 10, LD, L_({ r: 16, rb: 4, soft: 1 }));
        const CU = pillowZ(x, by + 18, -Dp / 2 + 18, SW - 8, 42, 12, LEA, L_()), HD = pillowZ(x, by + 60, -Dp / 2 + 18.5, SW - 12, 12, 11, LL, L_()), ST = slabX(x, by + 38, -Dp / 2 + 24.4, SW - 14, 0.7, 0.6, STI, { r: 0.3, noOut: 1, mat: 'lea' });
        tiltAll([BK, CU, HD, ST], [1, 0, 0], th, piv); o.push(BK); const fn = [0, Math.sin(-th), Math.cos(th)];
        if (r) on(BK, [CU, HD], fn); else o.push(CU, HD); on(CU, [ST], fn);
        if (r) { const FR = tilt(box(x, by + 5, Dp / 2 + 10, SW - 6, 7, 24, LEA, L_({ r: 4, soft: 1 })), [1, 0, 0], 0.1, [x, by + 5, Dp / 2 - 2]);
          on(SB, [-1, 1].map(sg => rod([x + sg * 20, by + 4, Dp / 2 - 4], [x + sg * 20, by + 6, Dp / 2 + 6], 1, '#9aa0a6', M_({ n: 6 }))), [0, 0, 1]); o.push(FR); }
        else on(SB, [slabX(x, by + 4, Dp / 2 - 3.2, SW - 8, 0.8, 0.8, shade(LEA, 0.6), { r: 0.3, noOut: 1 })], [0, 0, 1]); });
      cxs.forEach((x, i) => { const z = Dp / 2 - 18, CB = box(x, by, 0, CW, 24, Dp - 12, LD, L_({ r: 5, soft: 1 })), CP = box(x, by + 24, 0, CW, 5, Dp - 10, LEA, L_({ r: 4, bev: 2, soft: 1 }));
        o.push(CB, CP); on(CP, [slabX(x, by + 29.1, -4, CW - 3, 0.3, 0.6, shade(LEA, 0.55), { r: 0, noOut: 1 }), cyl(x, by + 29.2, z, 6.2, 0.5, '#5fc8ff', em({ n: 16 }))].concat(holder(x, by + 29.4, z, 5.2)), [0, 1, 0]);
        on(CB, [ball(x, by + 18, Dp / 2 - 6.5, 1, '#5fc8ff', em({ k: 2, n: 6 }))], [0, 0, 1]);
        if (i === 0) { const [c0, ...cr] = cup(x, by + 29, z, 4, 12, '#3a8fd8'); o.push(c0); on(c0, cr); }
        else { const BU = cyl(x, by + 29, z, 4.6, 9, '#ffffff', PL({ n: 12, rg: [[0, 0, 0.82], [9, 0, 1]] })); o.push(BU);
          on(BU, [0, 1, 2].map(k => rod([x - 3.4 + k * 3.4, by + 29.2, z + 4], [x - 4 + k * 4, by + 37.8, z + 4.4], 0.9, '#d9363b', PL({ n: 4, noOut: 1 }))));
          rep(6, k => on(BU, kern(x - 3 + (k % 3) * 3, by + 37.8 + (k > 2 ? 1.6 : 0), z - 1.5 + (k > 2 ? 3 : 0), 1.5, k))); } });
      [-1, 1].forEach(sg => { const x = sg * (Wd / 2 - EW / 2), AB = box(x, by, 0, EW, 26, Dp - 8, LEA, L_({ r: 8, soft: 1 }));
        o.push(AB, box(x, by + 26, 0, EW, 5, Dp - 6, LL, L_({ r: 5, bev: 2, soft: 1 })));
        on(AB, [0, 1].map(k => ball(x - sg * 4, by + 20 - k * 5, Dp / 2 - 4.2, 1.3, '#c9ced3', M_({ k: 3, n: 8, sz: 0.5 }))), [0, 0, 1]); });
      return o; } }; };

  // ---------- glossy egg shell with a front opening: the shell is a normal solid; rim, hollow and cushions are 'part' solids so they draw over it ----------
  const egg = (x, y0, z, rx, ry, rz, SH, ID, o) => { o = o || {}; const ox = rx * (o.ow || 0.76), oy = ry * (o.oh || 0.62), oc = y0 + ry * (o.oc || 0.9), fz = z + rz * 0.58;
    return { shell: [ball(x, y0, z, rx, SH, G_({ sy: ry / rx, sz: rz / rx, k: 9, n: 24 }))],
      part: [ball(x, oc - oy, fz, ox, ID, { sy: oy / ox, sz: (rz * 0.4) / ox, k: 7, n: 22, part: 1, mat: 'fab', shine: 0 })], oc, ox, oy, fz: fz + rz * 0.4 }; };
  const partOf = L => L.map(S => { S.part = 1; return S; });

  // ======================= MOV-093 ZERO-G PODS (reclined egg pods float + bob, interior colour picker) =======================
  N.pods16 = S => { const n = 3, R = 30, CW = 18, Wd = n * 2 * R + (n - 1) * CW, by = 14, xs = rep(n, i => -Wd / 2 + R + i * (2 * R + CW)), cxs = rep(n - 1, i => xs[i] + R + CW / 2), SH = '#f2f4f8', TL = -0.32;
    return { w: Wd + 8, d: 2 * R + 14, act: 'sit', seats: xs.map(x => ({ x, z: 12, h: by + 22 })), anim: bobA(4, 3.6), pad: [0, 8, 0, 0],
      build: P => { const o = [], IN = P.a, IL = P.aL, ID = shade(P.aD, 0.8);
        xs.forEach(x => { const E = egg(x, by - 6, 0, R, 38, R, SH, ID, { ow: 0.74, oh: 0.6, oc: 0.92 }), piv = [x, by, 0];
          const cz = E.fz, L = E.shell.concat(E.part, partOf([pillowY(x, by + 6, cz - 2, 38, 11, 20, IL, L_()), pillowZ(x, by + 14, cz - 5, 36, 34, 7, IN, L_()), pillowZ(x, by + 44, cz - 6, 24, 10, 6, IL, L_()), ball(x, by + 53, cz - 9, 2.4, '#7ff0ff', em({ k: 3, n: 8, part: 1 }))]));
          tiltAll(L, [1, 0, 0], TL, piv).forEach(s => o.push(s));
          o.push(cyl(x, by - 9, 0, 10, 1.4, '#8ff6ff', em({ n: 18 }))); });
        cxs.forEach((x, i) => { o.push(cyl(x, by - 4, 6, 7, 30, SH, G_({ n: 16, rg: [[0, 0, 0.6], [4, 0, 1], [30, 0, 1]] })), cyl(x, by + 26, 6, 7.4, 1, '#7ff0ff', em({ n: 16 })), cyl(x, by + 26.6, 6, 5, 0.6, '#1a1d2a', { n: 14 }));
          o.push(cyl(x, by + 27, 6, 3, 9, '#bfefff', { n: 12, op: 0.55, rg: [[0, 0, 0.8], [9, 0, 1]] }), cyl(x, by + 27.4, 6, 2.5, 6, i ? '#ff6fae' : '#7ff0ff', em({ n: 12, op: 0.85 })), rod([x, by + 36, 6], [x + 1.4, by + 42, 5], 0.5, '#ffffff', PL({ n: 4 }))); });
        return o; },
      fx: c => { let u = '<defs><radialGradient id="p16hv" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#8ff6ff" stop-opacity="0.85"/><stop offset="0.55" stop-color="#5fd8ff" stop-opacity="0.35"/><stop offset="1" stop-color="#5fd8ff" stop-opacity="0"/></radialGradient></defs>';
        xs.forEach((x, i) => { u += fxEll(c, x, 0, 0, 30, 'url(#p16hv)', an('opacity', '0.7;1;0.7', 3.6, -i * 0.4)) + fxEll(c, x, 0, 0, 16, 'none" stroke="#8ff6ff" stroke-width="' + f1(0.6 * c.k) + '" stroke-opacity="0.8', an('rx', f1(8 * c.k) + ';' + f1(30 * c.k), 2.4, -i * 0.8) + an('ry', f1(8 * c.k * X.SA) + ';' + f1(30 * c.k * X.SA), 2.4, -i * 0.8) + an('stroke-opacity', '0.9;0', 2.4, -i * 0.8)); });
        return { under: u }; } }; };

  // ======================= MOV-101 ROYAL CINEMA SEATS (tall arched channel backs, padded arms, mahogany riser) =======================
  N.royal16 = S => { const n = 3, SW = 56, AW = 15, Wd = n * SW + (n + 1) * AW, Dp = 100, MAH = '#6a2a1c', MAL = shade(MAH, 1.22), VEL = '#a3202f', VL = shade(VEL, 1.16), VD = shade(VEL, 0.76);
    const xs = rep(n, i => -Wd / 2 + AW + SW / 2 + i * (SW + AW)), axs = rep(n + 1, i => -Wd / 2 + AW / 2 + i * (SW + AW)), AR = 26, archTop = xo => 71 + Math.sqrt(Math.max(0, AR * AR - Math.max(0, Math.abs(xo) - 1) ** 2));
    return { w: Wd + 10, d: Dp + 6, act: 'sit', seats: xs.map(x => ({ x, z: 10, h: 34 })), build: () => { const o = [];
      o.push(box(0, 0, 0, Wd + 8, 8, Dp + 4, MAH, W_({ r: 3, bev: 1.2 })), slabX(0, 6.2, Dp / 2 + 2.1, Wd + 7, 1.6, 1.2, GOLD, M_({ r: 0.5 })));
      rep(9, i => o.push(ball(-Wd / 2 + 10 + i * (Wd - 20) / 8, 2.6, Dp / 2 + 2.4, 1.2, '#ffd98a', em({ k: 2, n: 6 }))));
      xs.forEach(x => { const bz = -Dp / 2 + 14;
        o.push(box(x, 8, 6, SW - 2, 15, Dp - 22, VD, F_({ r: 6 })), pillowY(x, 22, 9, SW - 6, 11, Dp - 36, VL, F_()), slabX(x, 22.6, 9 + (Dp - 36) / 2 - 0.4, SW - 10, 1.2, 1, GOLD, M_({ r: 0.4, noOut: 1 })));
        const B = [slab(x, 20, bz - 1.8, SW + 2, 78, 10, GOLD, M_({ r: AR + 1, rb: 4 })), slab(x, 21, bz, SW - 2, 76, 13, VEL, F_({ r: AR, rb: 4 }))];
        [-19.5, -6.5, 6.5, 19.5].forEach(xo => { const top = archTop(xo) - 5.5; B.push(pillowZ(x + xo, 31, bz + 10, 12.6, top - 31, 5.4, VEL, F_())); });
        B.push(ball(x, 97.6, bz - 1.8, 3, GOLD, M_({ sz: 0.5, k: 4, n: 12 })));
        tiltAll(B, [1, 0, 0], -0.05, [x, 22, bz]).forEach(s => o.push(s)); });
      axs.forEach((x, i) => { const z = Dp / 2 - 16, zf = 2 + (Dp - 14) / 2;
        o.push(box(x, 8, 2, AW, 27, Dp - 14, MAH, W_({ r: 4, bev: 1.4 })), box(x, 35, 2, AW + 2, 5, Dp - 10, VEL, F_({ r: 4, bev: 2.2 })));
        o.push(slab(x, 13, zf + 0.2, AW - 5, 16, 0.6, MAL, W_({ r: 2.4, noOut: 1 })), disc(x, 21, zf + 0.6, 3, 0.8, GOLD, M_({ n: 16 })), ball(x, 20.4, zf + 1.3, 1.2, shade(GOLD, 1.2), M_({ k: 3, n: 8, sz: 0.4, noOut: 1 })));
        holder(x, 40, z, 4.8, GOLD).forEach(s => o.push(s));
        if (i === 1) cup(x, 40.6, z, 3.8, 12, '#ffffff', '#d9363b').forEach(s => o.push(s));
        if (i === 2) { o.push(cyl(x, 40.6, z, 4.4, 9, '#d4a640', M_({ n: 12, rg: [[0, 0, 0.8], [9, 0, 1]] }))); rep(6, k => kern(x - 2.8 + (k % 3) * 2.8, 49.4 + (k > 2 ? 1.6 : 0), z - 1.4 + (k > 2 ? 2.8 : 0), 1.5, k).forEach(s => o.push(s))); } });
      return o; } }; };

  // ======================= MOV-016 CAMP CHAIR =======================
  N.camp16 = S => { const FR = '#2c2e33', CAN = '#3f7a52', CL = shade(CAN, 1.12), CD = shade(CAN, 0.72), hw = 22, hd = 19, ht = 29;
    return { w: 64, d: 52, act: 'sit', seats: [{ x: 0, z: 2, h: 31 }], build: () => { const o = [], T = (a, b) => o.push(rod(a, b, 1.15, FR, M_({ n: 8 })));
      [-1, 1].forEach(sz => { T([-hw, 0, sz * hd], [hw, ht, sz * hd]); T([hw, 0, sz * hd], [-hw, ht, sz * hd]); });
      [-1, 1].forEach(sx => { T([sx * hw, 0, hd], [sx * hw, ht, -hd]); T([sx * hw, 0, -hd], [sx * hw, ht, hd]);
        T([sx * (hw - 1), ht, -hd], [sx * (hw - 2), 64, -26]); T([sx * hw, ht, hd], [sx * (hw + 1), 44, 17]); T([sx * (hw + 1), 44, 17], [sx * (hw - 1.5), 46, -23]);
        [-1, 1].forEach(sz => o.push(ball(sx * hw, -0.6, sz * hd, 2, '#18191c', { k: 3, n: 8, sy: 0.6, shine: 0 })));
        o.push(box(sx * (hw + 0.5), 45.6, -3, 6, 1.6, 36, CAN, F_({ r: 1.4, yaw: 0 }))); });
      o.push(box(0, 26.5, 0, 42, 3, 38, CAN, F_({ r: 2, bev: 1 })), pillowY(0, 25.4, 0, 34, 4, 30, CL, F_()), slabX(0, 27, hd - 0.4, 42, 2.4, 1, CD, F_({ r: 0.6 })));
      tiltAll([slab(0, 33, -hd - 0.6, 39, 29, 2.2, CAN, F_({ r: 2 })), slabX(0, 60, -hd - 0.6, 39, 2.4, 2.6, CD, F_({ r: 0.8 })), slabX(0, 33, -hd - 0.6, 39, 2.4, 2.6, CD, F_({ r: 0.8 }))], [1, 0, 0], -0.197, [0, ht, -hd]).forEach(s => o.push(s));
      // mesh cup holder off the right arm with a soda can
      o.push(rod([hw + 1, 42, 13], [hw + 7, 40, 13], 0.8, FR, M_({ n: 6 })), arcW(hw + 8, 33, 13, 5, 5, 0.7, 7, 0, 2 * PI, CD, F_({ n: 12 })), cyl(hw + 8, 33, 13, 4.6, 0.6, CD, { n: 12 }));
      o.push(cyl(hw + 8, 33.4, 13, 3.6, 11, '#d9363b', M_({ n: 12, rg: [[0, 0, 0.9], [0.8, 0, 1], [10, 0, 1], [11, 0, 0.82]] })), cyl(hw + 8, 38, 13, 3.7, 2, '#ffffff', { n: 12, noOut: 1 }), cyl(hw + 8, 44.4, 13, 3, 0.4, CH, M_({ n: 10 })));
      return o; } }; };

  // ======================= MOV-036 BEANBAG (one slouchy corduroy sack, colour picker) =======================
  // sack = one loft: fat round bottom, flat-ish seat at the front, the sack rises into a lean-back lump behind it
  const BBR = [[0, 0, 4, 36, 33], [3, 0, 4, 42, 38], [9, 0, 4, 45, 41], [15, 0, 3, 45, 40.5], [20, 0, 1, 43, 37], [24, 0, -2, 40, 32], [27, 0, -7, 36.5, 26], [30, 0, -11, 33.5, 21], [35, 0, -14, 30, 17], [40, 0, -15, 26, 14], [44, 0, -15.5, 19.5, 10.5], [46.6, 0, -15.5, 10.5, 6], [47.4, 0, -15.5, 2, 1.4]];
  const bbAt = (k, f) => { const q = BBR[k]; return [q[1] + q[3] * Math.cos(f), q[0], q[2] + q[4] * Math.sin(f)]; };
  N.bean16 = S => ({ w: 92, d: 84, act: 'sit', seats: [{ x: 0, z: 13, h: 27 }], build: P => { const o = [], A = P.a, AD = P.aD;
      o.push(loft(BBR, A, F_({ n: 30 })));
      // little sewn-in tag at the side seam
      { const f = PI * 0.3, q = bbAt(3, f); o.push(box(q[0] + Math.cos(f) * 0.7, 9, q[2] + Math.sin(f) * 0.7, 6, 6.4, 0.9, '#f3ead8', { r: 0.6, yaw: f + PI / 2, noOut: 1, mat: 'fab' }), box(q[0] + Math.cos(f) * 1.2, 12.8, q[2] + Math.sin(f) * 1.2, 6.1, 1.4, 0.4, '#d9363b', { r: 0, yaw: f + PI / 2, noOut: 1 })); }
      return o; },
    fx: c => { const A = c.P.a || '#d99a35', DK = shade(A, 0.5), LT = mix(A, '#ffffff', 0.45), o0 = c.p(0, 0, 0), e1 = c.p(1, 0, 0), cT = (e1[0] - o0[0]) / c.k, sT = -(e1[1] - o0[1]) / (c.k * X.SA), k = c.k;
      const vis = (k2, f) => { const q = BBR[k2]; return -(Math.cos(f) / q[3]) * sT + (Math.sin(f) / q[4]) * cT; };
      let wl = ''; for (let j = 0; j < 34; j++) { const f = j / 34 * 2 * PI, seg = []; let pts = [];
        for (let k2 = 1; k2 < BBR.length - 1; k2++) { if (vis(k2, f) > 0.004) pts.push(P2(c.p(...bbAt(k2, f)))); else { if (pts.length > 1) seg.push(pts); pts = []; } } if (pts.length > 1) seg.push(pts);
        seg.forEach(P => wl += 'M' + P.join('L')); }
      const seam = k2 => { let s = '', pts = []; for (let j = 0; j <= 56; j++) { const f = j / 56 * 2 * PI; if (vis(k2, f) > 0.004) pts.push(P2(c.p(...bbAt(k2, f)))); else { if (pts.length > 1) s += 'M' + pts.join('L'); pts = []; } } if (pts.length > 1) s += 'M' + pts.join('L'); return s; };
      const sm = seam(2), dn = c.p(0, 26.4, 14), dr = 20 * k;
      // the seat dent: soft dark hollow, a lit roll on its back rim, a few slouch creases
      const crease = [[-15, 24, 26, -24, 16, 32], [13, 24.5, 27, 22, 17, 33], [-26, 26.5, 6, -34, 20, 14], [26, 27, 7, 34, 20.5, 15]].map(([x0, y0, z0, x1, y1, z1]) => { const a = c.p(x0, y0, z0), b = c.p(x1, y1, z1), m = c.p((x0 + x1) / 2 + (x0 < 0 ? -2 : 2), (y0 + y1) / 2 + 1.5, (z0 + z1) / 2); return 'M' + P2(a) + 'Q' + P2(m) + ' ' + P2(b); }).join('');
      const rim = (() => { const a = c.p(-22, 29.6, 1), m = c.p(0, 32.6, -6), b = c.p(22, 29.6, 1); return 'M' + P2(a) + 'Q' + P2(m) + ' ' + P2(b); })(), fold = (() => { const a = c.p(-21, 27.6, 3), m = c.p(0, 29.4, -2), b = c.p(21, 27.6, 3); return 'M' + P2(a) + 'Q' + P2(m) + ' ' + P2(b); })(), lip = (() => { const a = c.p(-24, 24.4, 24), m = c.p(0, 25.6, 36), b = c.p(24, 24.4, 24); return 'M' + P2(a) + 'Q' + P2(m) + ' ' + P2(b); })();
      return { front: '<defs><radialGradient id="b16dn" cx="50%" cy="44%" r="50%"><stop offset="0" stop-color="' + DK + '" stop-opacity="0.6"/><stop offset="0.6" stop-color="' + DK + '" stop-opacity="0.22"/><stop offset="1" stop-color="' + DK + '" stop-opacity="0"/></radialGradient></defs>'
        + '<path d="' + wl + '" fill="none" stroke="' + DK + '" stroke-opacity="0.11" stroke-width="' + f1(0.5 * k) + '" stroke-linecap="round" stroke-linejoin="round"/>'
        + '<ellipse cx="' + f1(dn[0]) + '" cy="' + f1(dn[1]) + '" rx="' + f1(dr) + '" ry="' + f1(dr * 0.56) + '" fill="url(#b16dn)"/>'
        + '<path d="' + fold + '" fill="none" stroke="' + DK + '" stroke-opacity="0.45" stroke-width="' + f1(1.3 * k) + '" stroke-linecap="round"/><path d="' + rim + '" fill="none" stroke="' + LT + '" stroke-opacity="0.7" stroke-width="' + f1(2.4 * k) + '" stroke-linecap="round"/><path d="' + lip + '" fill="none" stroke="' + LT + '" stroke-opacity="0.5" stroke-width="' + f1(2 * k) + '" stroke-linecap="round"/>'
        + '<path d="' + crease + '" fill="none" stroke="' + DK + '" stroke-opacity="0.32" stroke-width="' + f1(0.8 * k) + '" stroke-linecap="round"/>'
        + '<path d="' + sm + '" fill="none" stroke="' + DK + '" stroke-opacity="0.45" stroke-width="' + f1(1 * k) + '" stroke-linecap="round"/><path d="' + sm + '" fill="none" stroke="' + LT + '" stroke-opacity="0.6" stroke-width="' + f1(0.35 * k) + '" stroke-dasharray="' + f1(1.1 * k) + ' ' + f1(1.1 * k) + '" transform="translate(0 ' + f1(-0.9 * k) + ')"/>' }; } });

  // ======================= MOV-056 VELVET SWIVEL CHAIR (barrel, colour picker) =======================
  // barrel back = a ring of puffy channel columns (each one convex) that wrap round the seat, tall at the back and sloping down into the arms
  N.barrel16 = S => { const BR = '#d4a548', R = 26, NC = 13, a0 = PI * 0.8, a1 = PI * 2.2, rc = R - 4.8, dA = (a1 - a0) / (NC - 1);
    return { w: 60, d: 60, act: 'sit', seats: [{ x: 0, z: 5, h: 34 }], build: P => { const o = [], V = P.a, VL = P.aL, VD = P.aD;
      o.push(cyl(0, 0, 0, 16, 2.4, BR, M_({ n: 28, rg: [[0, 0, 1], [1.5, 0, 1], [2.4, 0.8, 0.9]] })), cyl(0, 2.4, 0, 4.2, 7.4, BR, M_({ n: 14, rg: [[0, 0, 1.5], [1.6, 0, 1], [7.4, 0, 0.85]] })), cyl(0, 9.6, 0, 19, 1.4, BR, M_({ n: 26 })));
      o.push(cyl(0, 11, 0, R, 15, VD, F_({ n: 30, rg: [[0, 1.6, 0.93], [2, 0, 1], [13, 0, 1], [15, 0.5, 0.99]] })));
      rep(NC, i => { const t = a0 + i * dA, d = Math.abs(t - PI * 1.5) / (PI * 0.7), top = 39 + 16 * (0.5 + 0.5 * Math.cos(PI * Math.min(1, d))), h = top - 24, end = i === 0 || i === NC - 1;
        o.push(cyl(Math.cos(t) * rc, 24, Math.sin(t) * rc, rc * dA * 0.62, h, end ? VL : V, F_({ rz: 5, yaw: t + PI / 2, n: 14, rg: [[0, 0, 1], [h - 3.6, 0, 1], [h - 1.6, 0.6, 0.86], [h - 0.5, 1.2, 0.62], [h, 1.6, 0.34]] }))); });
      o.push(cyl(0, 24.6, 4, 16.6, 9.6, VL, F_({ n: 26, rz: 18.6, rg: [[0, 0, 1], [5.4, 0, 1.02], [8, 2, 0.95], [9.6, 5, 0.8]] })), ball(0, 33.9, 4, 1.4, VD, { k: 3, n: 8, sy: 0.5, noOut: 1, shine: 0 }));
      return o; } }; };

  // ======================= MOV-076 WOOD LOUNGE CHAIR + OTTOMAN =======================
  N.eames16 = S => { const RW = '#5e2f1d', LEA = '#2a2628', LL = '#3a3538', AL = '#c9ced3', BT = '#141214';
    const star = (cx, cz, r, nL, y, ph) => { const out = []; rep(nL, i => { const t = ph + i * 2 * PI / nL, e = [cx + Math.cos(t) * r, y, cz + Math.sin(t) * r]; out.push(rod([cx, y + 3, cz], [e[0], y + 1.2, e[2]], 1.6, LEA, M_({ n: 8 })), ball(e[0], 0, e[2], 2, AL, M_({ k: 3, n: 8, sy: 0.7 }))); }); return out; };
    return { w: 70, d: 104, act: 'sit', seats: [{ x: 0, z: -8, h: 32 }], build: () => { const o = [], cz = -10, oz = 34;
      star(0, cz, 22, 5, 1, PI / 10).forEach(s => o.push(s)); o.push(cyl(0, 4, cz, 3.2, 13, AL, M_({ n: 12 })));
      const seat = [box(0, 17, cz + 2, 42, 4, 40, RW, W_({ r: 10, bev: 1.6 })), pillowY(0, 20.6, cz + 3, 39, 10, 36, LEA, L_())];
      [-9, 9].forEach(x => seat.push(ball(x, 30.2, cz + 2, 1.1, BT, { k: 3, n: 6, sy: 0.4, noOut: 1 })));
      tiltAll(seat, [1, 0, 0], -0.07, [0, 17, cz + 2]).forEach(s => o.push(s));
      const bz = cz - 18, back = [slab(0, 24, bz, 42, 30, 4, RW, W_({ r: 12 })), pillowZ(0, 25, bz + 5, 39, 28, 8, LEA, L_()), slab(0, 56, bz, 38, 17, 4, RW, W_({ r: 8 })), pillowZ(0, 57, bz + 5, 35, 15, 7, LL, L_())];
      [[-9, 37], [9, 37], [0, 65]].forEach(([x, y]) => back.push(ball(x, y, bz + 9.2, 1.1, BT, { k: 3, n: 6, sz: 0.4, noOut: 1 })));
      back.push(rod([0, 52, bz - 2.2], [0, 60, bz - 2.2], 1.6, '#3a3a3e', M_({ n: 6 })));
      tiltAll(back, [1, 0, 0], -0.34, [0, 24, bz]).forEach(s => o.push(s));
      [-1, 1].forEach(sg => { const x = sg * 22.5; o.push(rod([x, 21, cz + 10], [x, 33, cz + 6], 1, AL, M_({ n: 6 })), rod([x, 21, cz - 14], [x, 33, cz - 16], 1, AL, M_({ n: 6 })), box(x, 33, cz - 4, 6, 3.2, 30, LEA, L_({ r: 2.5, soft: 1 }))); });
      star(0, oz, 15, 4, 1, PI / 4).forEach(s => o.push(s)); o.push(cyl(0, 4, oz, 2.8, 8, AL, M_({ n: 12 })));
      tiltAll([box(0, 12, oz, 36, 3.6, 30, RW, W_({ r: 9, bev: 1.4 })), pillowY(0, 15.4, oz, 34, 8, 27, LEA, L_()), ball(0, 23.2, oz, 1.1, BT, { k: 3, n: 6, sy: 0.4, noOut: 1 })], [1, 0, 0], 0.08, [0, 12, oz]).forEach(s => o.push(s));
      return o; } }; };

  // ======================= MOV-096 HOVER EGG CHAIR (floats, massage nodes pulse, interior colour picker) =======================
  N.hover16 = S => { const by = 16, zc = -4, SH = '#f4f6fa', E0 = { ow: 0.78, oh: 0.6, oc: 0.86 };
    return { w: 76, d: 74, act: 'sit', seats: [{ x: 0, z: 8, h: by + 16 }], anim: bobA(4, 3.2), pad: [0, 8, 0, 0],
      build: P => { const o = [], IN = P.a, IL = P.aL, ID = shade(P.aD, 0.8), E = egg(0, by - 8, zc, 33, 44, 31, SH, ID, E0), cz = E.fz;
        E.shell.concat(E.part).forEach(s => o.push(s));
        o.push(cyl(0, by - 9.2, zc, 12, 1.2, '#8ff6ff', em({ n: 18 })), arcW(0, by - 2, zc, 33.4, 31.4, 1, 1.4, 0, 2 * PI, '#7ff0ff', em({ n: 28 })));
        partOf([pillowY(0, by + 2, cz - 3, 42, 12, 22, IL, L_()), pillowZ(0, by + 12, cz - 6, 40, 38, 8, IN, L_()), pillowZ(0, by + 46, cz - 7, 26, 11, 7, IL, L_()), box(25, by + 12, cz - 6, 6, 5, 18, shade(IN, 0.85), L_({ r: 2.4, soft: 1 })), box(25, by + 17, cz - 1, 4.4, 0.6, 6, '#1a1d2a', { r: 1 }), ball(25, by + 17.6, cz - 1, 1, '#7ff0ff', em({ k: 2, n: 6 }))]).forEach(s => o.push(s));
        return o; },
      fx: c => { const cz = zc + 31 * 0.58 + 31 * 0.4, node = (x, y, i) => { const q = c.p(x, y, cz - 1.6), r = 1.5 * c.k;
          return '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(r * 2.4) + '" fill="#7ff0ff" opacity="0">' + an('opacity', '0;0.5;0', 1.6, -i * 0.27) + '</circle><circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(r) + '" fill="#dffcff" stroke="#3fc8d8" stroke-width="' + f1(0.3 * c.k) + '">' + an('opacity', '0.45;1;0.45', 1.6, -i * 0.27) + '</circle>'; };
        let f = ''; [by + 24, by + 34, by + 44].forEach((y, j) => [-8, 8].forEach((x, i) => f += node(x, y, j * 2 + i)));
        const u = '<defs><radialGradient id="p16hc" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#8ff6ff" stop-opacity="0.85"/><stop offset="0.55" stop-color="#5fd8ff" stop-opacity="0.35"/><stop offset="1" stop-color="#5fd8ff" stop-opacity="0"/></radialGradient></defs>'
          + fxEll(c, 0, 0, zc, 32, 'url(#p16hc)', an('opacity', '0.7;1;0.7', 3.2)) + rep(2, i => fxEll(c, 0, 0, zc, 16, 'none" stroke="#8ff6ff" stroke-width="' + f1(0.6 * c.k) + '" stroke-opacity="0.8', an('rx', f1(8 * c.k) + ';' + f1(32 * c.k), 2.4, -i * 1.2) + an('ry', f1(8 * c.k * X.SA) + ';' + f1(32 * c.k * X.SA), 2.4, -i * 1.2) + an('stroke-opacity', '0.9;0', 2.4, -i * 1.2))).join('');
        return { front: f, under: u }; } }; };

  // ======================= MOV-019 POPCORN BOX BED =======================
  N.pnest16 = S => { const WHT = '#fbf6ec', RED = '#d9363b', CB = '#d8b88a', hw = 24, hd = 21;
    const wallZ = (z, h, sg) => { const L = [slab(0, 0, z, 2 * hw, h, 2.4, WHT, { r: 1.2, mat: 'pl' })]; rep(4, i => L.push(slab(-hw + 6 + i * 12, 0.4, z + sg * 1.35, 6, h - 0.8, 0.3, RED, { r: 0.4, mat: 'pl', noOut: 1 }))); return tiltAll(L, [1, 0, 0], sg * 0.12, [0, 0, z]); };
    const wallX = (x, h, sg) => { const L = [box(x, 0, 0, 2.4, h, 2 * hd, WHT, { r: 1.2, mat: 'pl' })]; rep(4, i => L.push(box(x + sg * 1.35, 0.4, -hd + 5 + i * 10.6, 0.3, h - 0.8, 5.2, RED, { r: 0.4, mat: 'pl', noOut: 1 }))); return tiltAll(L, [0, 0, 1], -sg * 0.12, [x, 0, 0]); };
    return { w: 64, d: 58, act: 'sit', seats: [{ x: 0, z: 2, h: 14 }], build: () => { const o = [];
      o.push(box(0, 0, 0, 2 * hw, 2, 2 * hd, CB, { r: 1.5, mat: 'pl' }));
      wallZ(-hd, 36, -1).concat(wallX(-hw, 28, -1), wallX(hw, 28, 1), wallZ(hd, 15, 1)).forEach(s => o.push(s));
      o.push(pillowY(0, 2, 1, 2 * hw - 6, 11, 2 * hd - 6, '#fff3dc', F_()), ball(-8, 12.5, -6, 6, '#ffe9c4', F_({ sy: 0.45, k: 4, n: 12, shine: 0 })));
      [[-16, 25, -16], [-10, 22, -17], [14, 24, -16], [18, 15.5, -10], [-17, 15, -9], [6, 13.6, 10]].forEach(([x, y, z], i) => kern(x, y, z, 2, i).forEach(s => o.push(s)));
      [[30, 0, 18], [34, 0, 10], [-30, 0, 22]].forEach(([x, y, z], i) => kern(x, y, z, 1.8, i + 2).forEach(s => o.push(s)));
      return o; },
      fx: c => { const O = rotF([1, 0, 0], 0.12)([0, 8.4, 1.4]), Vd = rotF([1, 0, 0], 0.12)([0, -1, 0]), M = frame(c.p, [O[0], O[1], O[2] + hd], [1, 0, 0], Vd);
        return { front: '<g transform="' + M + '"><rect x="-16" y="-4.2" width="32" height="8.4" rx="4.2" fill="#ffd23f" stroke="#b8202a" stroke-width="0.7"/><text x="0" y="2.2" text-anchor="middle" ' + FONT + ' font-size="6" fill="#c8202a" letter-spacing="0.4">POPCORN</text></g>' }; } }; };

  // ---------- catalog edits ----------
  const COUCH = [{ n: 'Sage', c: '#9cbf8a' }, { n: 'Coral', c: '#e98f74' }, { n: 'Denim', c: '#6f8fc0' }, { n: 'Mustard', c: '#e0b04c' }, { n: 'Lilac', c: '#b39ad8' }];
  const POD = [{ n: 'Teal', c: '#3fc7c9' }, { n: 'Violet', c: '#8a6ee0' }, { n: 'Hot pink', c: '#ff6fae' }, { n: 'Midnight', c: '#3a4466' }];
  const CORD = [{ n: 'Mustard', c: '#d99a35' }, { n: 'Rust', c: '#c4643a' }, { n: 'Olive', c: '#8a9a4a' }, { n: 'Plum', c: '#8a4f7a' }];
  const VELC = [{ n: 'Emerald', c: '#2f7a5e' }, { n: 'Blush', c: '#d98a8f' }, { n: 'Navy', c: '#34477a' }, { n: 'Mustard', c: '#d0a03c' }];
  const EGG = [{ n: 'Ice', c: '#7fd6e0' }, { n: 'Lavender', c: '#b6a2f0' }, { n: 'Peach', c: '#ffb38a' }, { n: 'Mint', c: '#8ee6b4' }];
  RD.DEL16 = new Set(['MOV-027', 'MOV-039', 'MOV-059', 'MOV-079', 'MOV-099', 'LIV-034', 'LIV-074', 'LIV-094']);
  RD.SET16 = {
    'MOV-013': { name: 'Old Futon', spec: 'futon16', note: 'A saggy blue futon on a pine slat frame: the mattress dips in the middle, a plaid patch covers a hole, a mustard blanket is crumpled on one end and an old striped pillow slumps on the other. Duct tape holds one leg together.' },
    'MOV-033': { name: 'Comfy Couch', spec: 'couch16', colors: COUCH, note: 'A big puffy 3-seat couch on wooden legs: rolled arms, three fat seat cushions and three back cushions, two throw pillows, a striped knit throw folded over one arm and the TV remote on the other. Pick a colour.' },
    'MOV-053': { name: 'Leather Loveseat', spec: 'loveseat16', note: 'A cognac leather 2-seater with a tall rolled back and two thick diamond-tufted back cushions (pillowy diamonds with buttons in the dimples), plump seat cushions and padded arms with glowing cup holders. Sits on a black plinth with a warm light strip underneath.' },
    'MOV-073': { name: 'Recliner Sofa', spec: 'recliner16', note: 'Three caramel leather recliners in a row with consoles between them: cup holders with blue light rings, a cola and a tub of popcorn. The middle seat is reclined with its footrest out.' },
    'MOV-093': { name: 'Zero-G Pods', spec: 'pods16', colors: POD, live: 'Floating', note: 'Three white egg pods floating over glowing hover pads, with cushy seats, a light line inside each shell and glowing drink pillars between them. Pick the cushion colour.' },
    'MOV-101': { name: 'Royal Cinema Seats', spec: 'royal16', note: 'Three crimson velvet cinema seats with tall arched channel-tufted backs framed in gold, padded arms on mahogany with gold medallions, on a mahogany step with little floor lights. Gold cup holders hold a soda and a gold tub of popcorn.' },
    'MOV-016': { name: 'Camp Chair', spec: 'camp16', note: 'A green folding camp chair on a black steel X frame, with canvas arms and a mesh cup holder holding a can of soda.' },
    'MOV-036': { name: 'Beanbag', spec: 'bean16', colors: CORD, note: 'A big slouchy corduroy beanbag with a deep dent to sink into, a soft lump behind to lean on, a stitched seam round the bottom and a little tag. Pick a colour.' },
    'MOV-056': { name: 'Velvet Swivel Chair', spec: 'barrel16', colors: VELC, note: 'A round velvet scallop chair: puffy channel tufts wrap round a deep button cushion, tall at the back and curving down into the arms, on a brass swivel base. Pick a colour.' },
    'MOV-076': { name: 'Wood Lounge Chair', spec: 'eames16', note: 'A classic rosewood lounge chair with black leather cushions and buttons, leaning back on a five-star base, with its matching footstool in front.' },
    'MOV-096': { name: 'Hover Egg Chair', spec: 'hover16', colors: EGG, live: 'Massage lights', note: 'A white egg chair floating over a glowing hover pad. Light lines trace its opening and six massage lights pulse on the back cushion. Pick the cushion colour.' },
    'MOV-019': { name: 'Popcorn Box Bed', spec: 'pnest16', note: 'A giant red-and-white popcorn box turned into a pet bed: the front is cut low to climb in, a fluffy cushion fills the bottom and a few popcorn pieces are scattered around.' },
    // renames for the tables, shelves and props (remodelled in round 17)
    'MOV-003': { name: 'Crate Table' }, 'MOV-023': { name: 'Snack Table' }, 'MOV-043': { name: 'Glass Coffee Table' }, 'MOV-063': { name: 'Fridge Table' }, 'MOV-083': { name: 'Holo Table' },
    'MOV-007': { name: 'TV Tray' }, 'MOV-047': { name: 'Brass Side Table' }, 'MOV-067': { name: 'Marble Side Table' }, 'MOV-087': { name: 'Robot Butler' },
    'MOV-017': { name: 'Brick Shelf' }, 'MOV-037': { name: 'DVD Tower' }, 'MOV-057': { name: 'Wood Media Console' }, 'MOV-077': { name: 'Movie Vault' }, 'MOV-097': { name: 'Holo Movie Library' },
    'MOV-008': { name: 'Candy & 3D Glasses' }, 'MOV-028': { name: 'Popcorn Bucket' }, 'MOV-048': { name: 'Director Kit' }, 'MOV-068': { name: 'Gold Trophy' }, 'MOV-088': { name: 'Holo Mascot' },
  };
  const edit15 = RD.edit;
  RD.edit = rows => edit15(rows).filter(r => !RD.DEL16.has(r.id)).map(r => RD.SET16[r.id] ? Object.assign({}, r, RD.SET16[r.id]) : r);
  RD.H16 = { loft, xf, tilt, tiltAll, rotF, rod, pipe, fxEll, frame, kern, cup, holder, bobA, an, FONT, W_, M_, F_, L_, PL, G_, em, rep };
  RD.PLUS16 = 1;
})();
