// Ocean Pals personalities (Nov 10, user: 'modify the animations of shelly like we did with pet shop, about his dance i want to include him going
// inside his shell and spinning non stop'). Same recipe as pet-anims / snack2-anims: a personality card that flavours the shared moves, her own
// happy / surprised / squish / habit / squeeze + let-go, the natural look, a signature dance, 14 pokes and all 20 foods.
// Shelly is a sea turtle (rive-generic RC.turtle): hid (0..1 pulls her head + legs into the shell, the shell settles down), nk (-0.6..1.6 the neck
// stretches out / tucks), armL / armR = front flippers, footL / footR = back feet, wag = little tail, spin / turn turn the whole shell (the scutes
// slide round). The Sea Turtle (Pet Shop) wears Shelly's rig (squad-store SQ_ALIAS), so he gets all of this too. pitch: NEGATIVE = head down.
(function () {
  const KEYS = ['shelly', 'seaturtle'];   // Nov 12: Shelly lives in the Pet Shop now (her moves come with her); the Sea Turtle (Ocean Pals) is a real sea turtle with flippers
  // =====================================================================================================================================
  // personality, moves, dance
  (function boot() {
    const R = window.RiveRig; if (!R || !R.PETLIB || !R.PETLIB.install || !R.SOFT) { setTimeout(boot, 25); return; } if (R.oceanV) return; R.oceanV = 1;
    ['hid', 'nk', 'swim', 'dz'].forEach(k => { if (R.REST[k] == null) R.REST[k] = 0; });
    const { TL, o, jump, look, shake, swing, jelly, land, install } = R.PETLIB;
    KEYS.forEach(k => R.SOFT.add(k));
    const loopN = (t, n) => Object.assign(t.loop(), { dur: t.t * (n || 3) });
    const spinR = (t, dur, deg, x, ez) => { const a = t.t; t.to(dur, o({ spin: deg }, x || {}), ez || 'io').to(1, { spin: 0 }, 'l'); return a; };
    // ducks into her shell: a quick look of alarm (neck up a touch), then the head + legs snap in, the shell drops with a squash
    const duck = (t, x) => t.to(110, { nk: 0.35, wide: 0.6, sq: -0.04 }, 'o').to(120, o({ hid: 1, sq: 0.14, wide: 0, nk: 0 }, x || {}), 'o').to(160, { sq: 0.06 }, 'io');
    // pops back out: the head shoots out a bit too far (neck overshoot), wobbles and settles
    const popOut = (t, x) => t.to(160, o({ hid: 0, nk: 1.1, sq: -0.06, lift: 1.5 }, x || {}), 'o').to(220, { nk: 0.25, sq: 0.04, lift: 0 }, 'io').to(200, { nk: 0.45, sq: 0 }, 'io').to(220, { nk: 0.3 }, 'io');
    // a front-flipper swim stroke (sea turtle: both flippers sweep down and back together, the shell rises a little on the push)
    const stroke = (t, n, per, lift) => { for (let i = 0; i < n; i++) t.to(per * 0.45, { armL: 115, armR: 115, lift: (lift || 0) + 1.2, pitch: 0.04 }, 'o').to(per * 0.55, { armL: -15, armR: -15, lift: lift || 0, pitch: -0.02 }, 'io'); return t; };

    const CARDS = { shelly: { T: 1.15, b: 0.85, s: 0.95, w: 1 }, seaturtle: { T: 1.1, b: 0.9, s: 1, w: 1 } };   // turtles: unhurried, gentle, not bouncy

    const MOVES = {
      shelly: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 }, 1.1);
          t.to(160, { lx: 0, ly: -0.4 }, 'o').to(320, { nk: 1.3, pitch: 0.14, sq: -0.04 }, 'o');                                                   // stretches her neck up, beaming
          t.to(260, { armL: 70, armR: 0, tilt: -3, wag: 20 }, 'io').to(260, { armL: 0, armR: 70, tilt: 3, wag: -20 }, 'io').to(260, { armL: 70, armR: 0, tilt: -3, wag: 20 }, 'io') // happy flipper flaps
            .to(260, { armL: 0, armR: 0, tilt: 0, wag: 0, nk: 0.6, pitch: 0, ly: 0 }, 'io');
          jump(t, { h: 4, ant: 170, up: 200, c: 0.12, arm: 30, ev: [['emit', 'bubble', 'head', 2]] });                                             // a little heavy shell hop
          return loopN(t.rest(320)); })(), 'Happy', 'Stretches her neck up with a big smile, flaps her flippers left and right, then a little shell hop.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(70, { wide: 1, open: 0.5, mw: 0.7, nk: 0.5 }, 'o'); duck(t); t.e('emit', 'dust', 'body', 2);                                 // eyes pop - she snaps into her shell
          t.osc(600, 4, { tilt: 2.2 }, { tilt: -2.2 }, 'io').to(120, { tilt: 0 }, 'io').wait(250);                                                  // the shell trembles
          t.to(380, { hid: 0.55, wide: 0.3, open: 0 }, 'io').to(200, { lx: -0.9 }, 'o').wait(220).to(260, { lx: 0.9 }, 'io').wait(220).to(160, { lx: 0 }, 'io'); // peeks out, eyes dart
          popOut(t, { hap: 1, smile: 1, wide: 0, mw: 1 }); return t.rest(420).done(); })(), 'Surprised', 'Eyes pop and she snaps into her shell, it trembles, she peeks out with darting eyes, then pops back out relieved.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.04, nk: 0.3 }, 'o').to(320, { sq: 0.3, hid: 0.85, hap: 0.9, close: 0.6 }, 'io').wait(300);                             // squeezed: pulls into her shell
          t.to(140, { hid: 0, nk: 1.5, sq: -0.14, close: 0, smile: 1, open: 0.4, armL: 50, armR: 50 }, 'o').e('emit', 'bubble', 'head', 3)            // let go: boing - her neck springs out
            .to(200, { nk: 0.6, sq: 0.06, armL: 10, armR: 10 }, 'io'); jelly(t, 0.5, 3, 300, 'nk'); t.to(200, { nk: 0, sq: 0, armL: 0, armR: 0, smile: 0, open: 0, hap: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squeezed, she pulls into her shell; let go and her neck boings out and wobbles.'],
        quirk: [(() => { const t = TL();
          t.to(500, { nk: 1.25, pitch: 0.2, close: 1, smile: 1, armL: -18, armR: -18, footL: 1, footR: 1 }, 'io');                                    // basks: neck out to the sun, flippers spread, eyes shut
          t.osc(1600, 2, { sq: -0.03, lift: 0.4 }, { sq: 0.02, lift: 0 }, 'io').e('emit', 'spark', 'head', 1);                                        // two slow sunny breaths
          t.to(420, { pitch: 0.05, nk: 0.4 }, 'io').to(250, { close: 0.4 }, 'io').to(140, { close: 1 }, 'i').to(300, { close: 0, hap: 1 }, 'io')        // a slow turtle blink
            .to(400, { armL: 0, armR: 0, footL: 0, footR: 0, nk: 0, pitch: 0 }, 'io'); return t.wait(300).rest(450).done(); })(), 'Sunbathe', 'Stretches her neck out to the sun with her flippers spread and eyes shut, two slow happy breaths, a slow turtle blink.'],
        press: { hid: 0.55, sq: 0.06 },
        rel: { dur: 1100, k: { hid: [[0, 0.55], [140, 0, 'o']], nk: [[0, 0], [160, 1.3, 'o'], [420, 0.1, 'io'], [650, 0.45, 'io'], [900, 0, 'io']], sq: [[0, 0], [110, -0.12, 'o'], [270, 0.05, 'io'], [430, 0, 'io']],
          armL: [[0, 0], [160, 40, 'o'], [600, 0, 'io']], armR: [[0, 0], [160, 40, 'o'], [600, 0, 'io']] }, em: [['bubble', 'head', 3]] },
        // the natural look, turtle style: the neck comes out a little to look, eyes first, head turns on the neck (dipping arc + blink), the shell follows a beat later
        look: (() => { const t = TL(); t.to(320, { nk: 0.55 }, 'io'); look(t, 0, -0.6, { k: 0.7 }); t.wait(700); look(t, -0.6, 0.6, { k: 0.7, d1: 210, d2: 250 }); t.wait(700); look(t, 0.6, 0, { k: 0.7 });
          return t.to(320, { nk: 0 }, 'io').rest(300).done({ soft: 0.4, stretch: 0 }); })(),
      },
      // the REAL SEA TURTLE (Nov 12): calm, dreamy, at home in the water - it can't pull into its shell, so it talks with its big front flippers
      // (armL / armR raise them), rear flippers (footL / footR), its neck (nk) and little tail (wag)
      seaturtle: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 }, 1.05);
          t.to(160, { ly: -0.4 }, 'o').to(300, { nk: 0.9, pitch: 0.12 }, 'o');                                                                                       // head up, beaming
          for (let i = 0; i < 3; i++) t.to(200, { armL: 75, armR: 75, lift: 1.2, sq: -0.03, wag: 14 }, 'o').to(240, { armL: 5, armR: 5, lift: 0, sq: 0.02, wag: -14 }, 'io'); // three big happy flipper flaps, like a swim stroke
          t.e('emit', 'bubble', 'head', 3); t.to(260, { armL: 0, armR: 0, wag: 0, nk: 0.5, pitch: 0, ly: 0 }, 'io');
          jump(t, { h: 3, ant: 160, up: 200, c: 0.1, arm: 0 });
          return loopN(t.rest(320)); })(), 'Happy', 'Lifts its head with a big smile, flaps both front flippers three times like a swim stroke (bubbles!), then a little hop.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, nk: 0.8, armL: 95, armR: 95, lift: 2.5, sq: -0.08 }, 'o').e('emit', 'bubble', 'head', 2);                 // eyes pop, both flippers fly up
          t.to(180, { lift: 0, sq: 0.08, nk: -0.3, armL: 40, armR: 40 }, 'i').to(200, { sq: 0 }, 'io');                                                              // plops back down, neck tucked
          t.to(260, { lx: -0.9 }, 'io').wait(200).to(300, { lx: 0.9 }, 'io').wait(200).to(220, { lx: 0, wide: 0.3 }, 'io');                                         // looks left, right
          t.to(320, { armL: 0, armR: 0, nk: 0.2, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io'); return t.rest(420).done(); })(), 'Surprised', 'Eyes pop and both flippers fly up, it plops back down with its neck tucked, looks left and right, then relaxes with a smile.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.04, nk: 0.2 }, 'o').to(320, { sq: 0.3, armL: -25, armR: -25, footL: 3, footR: 3, nk: -0.4, hap: 0.9, close: 0.6 }, 'io').wait(300);   // squeezed flat, flippers splayed out
          t.to(140, { sq: -0.14, nk: 1, armL: 70, armR: 70, footL: 0, footR: 0, close: 0, smile: 1, open: 0.4 }, 'o').e('emit', 'bubble', 'head', 3)           // let go: boings up, flippers up
            .to(200, { sq: 0.06, nk: 0.4, armL: 10, armR: 10 }, 'io'); jelly(t, 0.5, 3, 300, 'nk'); t.to(200, { nk: 0, sq: 0, armL: 0, armR: 0, smile: 0, open: 0, hap: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squeezed flat with its flippers splayed out; let go and it boings up with both flippers raised, its neck wobbling.'],
        quirk: [(() => { const t = TL();
          t.to(500, { close: 1, smile: 1, nk: 0.5, pitch: 0.06 }, 'io');                                                                                             // dreams of the sea: eyes shut ...
          for (let i = 0; i < 3; i++) t.to(520, { armL: 60, armR: 60, footL: 2, footR: 2, lift: 0.8, tilt: i % 2 ? 2 : -2 }, 'io').to(620, { armL: -10, armR: -10, footL: 0, footR: 0, lift: 0, tilt: 0 }, 'io').e('emit', 'bubble', 'head', 1); // ... slow swimming strokes, bubbles rise
          t.to(300, { close: 0.4 }, 'io').to(140, { close: 1 }, 'i').to(300, { close: 0, hap: 1 }, 'io').to(400, { armL: 0, armR: 0, nk: 0, pitch: 0 }, 'io'); return t.wait(300).rest(450).done(); })(), 'Sea Dream', 'Closes its eyes and dreams of the sea: three slow swimming strokes with its big flippers, bubbles rising, a slow blink.'],
        press: { sq: 0.1, armL: -12, armR: -12 },
        rel: { dur: 1000, k: { nk: [[0, 0], [160, 1, 'o'], [420, 0.1, 'io'], [700, 0, 'io']], sq: [[0, 0], [110, -0.12, 'o'], [270, 0.05, 'io'], [430, 0, 'io']],
          armL: [[0, 0], [160, 60, 'o'], [600, 0, 'io']], armR: [[0, 0], [160, 60, 'o'], [600, 0, 'io']] }, em: [['bubble', 'head', 3]] },
        look: (() => { const t = TL(); t.to(320, { nk: 0.5 }, 'io'); look(t, 0, -0.6, { k: 0.7 }); t.wait(700); look(t, -0.6, 0.6, { k: 0.7, d1: 210, d2: 250 }); t.wait(700); look(t, 0.6, 0, { k: 0.7 });
          return t.to(320, { nk: 0 }, 'io').rest(300).done({ soft: 0.4, stretch: 0 }); })(),
      },
    };

    // ---------- signature dance: 'Shell Spin' (Nov 10, user: 'he is not spinning fast enough and he needs to spin for at least 10 seconds, after that he
    // comes out and looks dizzy and then goes back again and same thing until we stop'): ONE cycle that loops for as long as she dances -
    // ducks in -> spins 12.4 s (10.65 s of it flat out at 3.5 turns a second) -> pops out dizzy -> shakes it off -> ducks straight back in ...
    // The spin keys join with no speed jump: ease 'i' = x^2.2 ends at 2.2 x its average speed, 'o' = 1-(1-x)^2.4 starts at 2.4 x, so the wind-up covers
    // V * 0.7 / 2.2 and the wind-down V * 1.1 / 2.4; the full-speed part fills the rest of 40 whole turns (she stops facing front).
    const DANCES = {
      shelly: [(() => { const t = TL({ smile: 0.9, hap: 1 }), d = 1;   // spins to the right (d = -1 mirrors it)
        // 1. here we go: neck up, a determined little nod
        t.to(220, { nk: 0.9, sq: -0.04, hap: 0.6 }, 'o').to(160, { nk: 0.6, pitch: -0.08, sq: 0.03 }, 'io');
        // 2. in she goes FIRST (Nov 12, user: 'first enter his shell and only then do the motion that he wants to spin, then the spin')
        duck(t, { hap: 1, pitch: 0 }); t.e('emit', 'dust', 'body', 3); t.wait(140);
        // 3. then, inside the shell, the WHIP SPIN get-ready (Nov 12, user: 'his spinning is not like our new one - same behaviour as the new spin, keep
        //    spinning like today without stopping'): same keys + v1110g timings as whip() in mittens-moves / whip-spin.js, on the shell - it leans to the
        //    spin side ('finds the spot'), plie + coils the other way (spin -32, squash, leans away, tail flicks), holds the coil - then the WHIP (50 ms,
        //    sblur 0.5 = the new spin's sideways motion blur; the shell's white swoosh arcs are off while it's on) straight into ONE non-stop spin
        //    (no landing after a turn) for ~10.7 s, and the whip landing at the end: a touch past front, back, squash
        t.to(75, { tilt: 1.5 * d, lean: 0.4 * d, sq: 0.03 }, 'io');                                                    // finds the spot
        t.to(155, { sq: 0.14, spin: -32 * d, turn: -0.12 * d, tilt: -3 * d, lean: -1 * d, wag: 14 * d }, 'o');          // plie + coil
        t.to(100, { sq: 0.16, spin: -36 * d }, 'io');                                                                  // hold the coil
        // 3. THE SPIN: whip in, 59 turns flat out at 5.5 turns / s (V 1980 deg/s, ~ the whip's own speed), the whip landing; never a pause in between
        const V = 1980, s0 = t.t, END = 59 * 360, RUN = Math.round((END + 18 - 40) / V * 1000), TOT = 50 + RUN + 200;
        t.to(50, { sblur: 0.5, sq: -0.1, turn: 0, tilt: 4 * d, lean: 0.6 * d }, 'l').to(110, { sq: 0.08, tilt: 0, lean: 0, wag: 0 }, 'o').to(160, { sq: 0.04 }, 'io');   // WHIP
        t.at(s0).e('emit', 'dust', 'body', 2);
        // the shell tips round in a circle like a spinning top, two little hops along the way, sparks + dust off the ground the whole time
        t.at(s0 + 250); const nW = Math.floor((TOT - 750) / 400); for (let i = 0; i < nW; i++) { const g = Math.min(1, i / 3) * (i > nW - 4 ? (nW - i) / 4 : 1), w = 2 + 4 * g; t.to(200, { tilt: w, lean: w * 0.5 }, 'io').to(200, { tilt: -w, lean: -w * 0.5 }, 'io'); }
        t.to(300, { tilt: 0, lean: 0 }, 'io');
        [3200, 8200].forEach(h => { t.at(s0 + h); jump(t, { h: 5, ant: 140, up: 220, c: 0.1, arm: 0, ev: [['emit', 'spark', 'body', 3]] }); });
        for (let k = 0; k * 400 < TOT - 300; k++) t.at(s0 + 250 + k * 400).e('emit', k % 2 ? 'spark' : 'dust', 'body', k % 2 ? 2 : 1);
        t.at(s0 + 50 + RUN).to(200, { sblur: 0, sq: 0.12 }, 'o');                                                                                                                   // the whip landing: squash, blur off
        t.at(s0).to(50, { spin: 40 * d }, 'l').to(RUN, { spin: (END + 18) * d }, 'l').to(200, { spin: END * d }, 'o').to(1, { spin: 0 }, 'l');                                         // one non-stop spin, a touch past front and back
        // 4. pops out DIZZY: eyes open + crossed, the head lolls round on her neck, the shell sways, stars - then she shakes it off
        t.at(s0 + TOT + 60); popOut(t, { cross: 1, open: 0.4, hap: 0, smile: 0.4, wide: 0.4 }); t.at(s0 + TOT + 120).to(320, { dz: 1 }, 'o');   // the cartoon dizzy halo: stars circle over her head
        t.osc(1500, 3, { htilt: 10, tilt: 3.5, nk: 0.6, x: 1.2, hyaw: 0.12 }, { htilt: -10, tilt: -3.5, nk: 0.15, x: -1.2, hyaw: -0.12 }, 'io').to(220, { htilt: 0, tilt: 0, x: 0, hyaw: 0, nk: 0.3 }, 'io');
        const sk = t.t; shake(t, { P: 115, env: [0.7, 1, 0.55, 0.2], head: 0.3, roll: 5, ear: 0, chest: 0.05 }); const sk2 = t.t; t.at(sk + 150).to(sk2 - sk, { dz: 0 }, 'io').at(sk2);   // shakes it off - the stars fade away
        t.to(220, { cross: 0, wide: 0, hap: 1, smile: 1, open: 0.45 }, 'io');
        // 5. a big grin - and straight into the next get-ready (the loop starts with the nod)
        t.wait(200);
        return t.rest(260).loop({ stretch: 0.6, whip: 1 }); })(), 'Shell Spin', 'Ducks into her shell, then gets ready like a pirouette (the shell coils the other way and holds), whips round with a blur - and keeps spinning super fast (5.5 turns a second) for over 10 seconds like a spinning top (two hops along the way), lands facing you, pops out dizzy and cross-eyed with cartoon stars circling over her head, shakes it off - and goes again, until you stop her.'],
      // the Sea Turtle's dance 'Ocean Glide' (Nov 12): it swims on the spot - gliding strokes left and right, a slow graceful roll, a flipper wave,
      // a turn to show off its side as it 'swims past', a dreamy full turn on the current, bubbles all along, a wink
      seaturtle: [(() => { const t = TL({ smile: 0.9, hap: 1 });
        const stroke2 = (dur, x, tl) => t.to(dur * 0.45, { armL: 85, armR: 85, footL: 2, footR: 2, lift: 1.4, x, tilt: tl, nk: 0.6 }, 'o').to(dur * 0.55, { armL: -8, armR: -8, footL: 0, footR: 0, lift: 0, nk: 0.3 }, 'io');
        t.to(300, { nk: 0.7, pitch: 0.08 }, 'io').e('emit', 'bubble', 'head', 2);
        stroke2(900, -4, -4); stroke2(900, -7, -5); t.e('emit', 'bubble', 'head', 2); stroke2(900, 4, 4); stroke2(900, 7, 5); t.e('emit', 'bubble', 'head', 2);   // glides left, then right
        t.to(500, { x: 0, tilt: -14, lean: -4, armL: 90, armR: -10 }, 'io').to(700, { tilt: 14, lean: 4, armL: -10, armR: 90 }, 'io').to(500, { tilt: 0, lean: 0, armL: 0, armR: 0 }, 'io');   // a slow graceful roll
        for (let i = 0; i < 2; i++) t.to(220, { armR: 100, hyaw: 0.2 }, 'o').to(220, { armR: 60 }, 'io').to(220, { armR: 100 }, 'io').to(240, { armR: 0, hyaw: 0 }, 'io'); // waves a flipper at you
        t.to(700, { spin: 90, nk: 0.8 }, 'io'); stroke2(800, 0, 0); stroke2(800, 0, 0); t.to(700, { spin: 0, nk: 0.4 }, 'io');                                        // swims past: shows its side, two strokes, back
        t.to(1400, { spin: 360, armL: 50, armR: 50, footL: 3, footR: 3, lift: 2, nk: 0.9 }, 'io').e('emit', 'bubble', 'body', 4).to(1, { spin: 0 }, 'l');             // a dreamy full turn on the current
        t.to(400, { armL: 0, armR: 0, footL: 0, footR: 0, lift: 0, nk: 0.3 }, 'io').to(200, { winkL: 1 }, 'o').wait(250).to(200, { winkL: 0 }, 'io').e('emit', 'heart', 'head', 1);
        return t.rest(400).loop({ stretch: 0.6 }); })(), 'Ocean Glide', 'Swims on the spot: gliding strokes to the left and right with its big flippers, a slow graceful roll, waves a flipper at you, turns to show its side as it swims past, a dreamy full turn on the current, bubbles all along, then a wink.'],
    };
    KEYS.forEach(k => { MOVES[k].dance = DANCES[k]; });
    install(MOVES, CARDS);
  })();

  // =====================================================================================================================================
  // pokes (14 spots)
  (function boot() {
    const R = window.RiveRig; if (!R || !R.POKELIB || !R.oceanV || !R.STATES.poke_head) { setTimeout(boot, 25); return; } if (R.oceanPokeV) return; R.oceanPokeV = 1;
    const { S, o, jump, shake, jelly } = R.PETLIB;
    const { see, unsee, giggle, sniff, lick, leanIn, para, build } = R.POKELIB;
    const duck = (t, a) => t.to(110, { nk: 0.3, wide: 0.6 }, 'o').to(120, { hid: a == null ? 1 : a, sq: 0.12, wide: 0, nk: 0 }, 'o').to(150, { sq: 0.05 }, 'io');
    const popOut = t => t.to(160, { hid: 0, nk: 1, sq: -0.05 }, 'o').to(220, { nk: 0.2, sq: 0.03 }, 'io').to(220, { nk: 0, sq: 0 }, 'io');
    const tasteHeart = t => { lick(t, 2); return t.to(220, { hap: 1, smile: 1 }, 'io').e('emit', 'heart', 'head', 1).wait(320).to(220, { hap: 0, smile: 0 }, 'io'); };
    const BODY = { shelly: { ear: 0, tail: 1, noWalk: 1, earTap: [33, 37], lbl: { ear: 'shell top', head: 'Head', nose: 'Nose', belly: 'Belly shell', side: 'shell', foot: 'flipper', tail: 'Little tail' } },
      seaturtle: { ear: 0, tail: 1, noWalk: 1, earTap: [33, 37], lbl: { ear: 'shell top', head: 'Head', nose: 'Nose', belly: 'Belly shell', side: 'shell', foot: 'flipper', tail: 'Little tail' } } };
    const RE = {
      shelly: {
        head: (t, s) => { duck(t); t.wait(500).to(300, { hid: 0.55, lx: 0, ly: -0.6 }, 'io').wait(300); popOut(t); giggle(t, 2); },                         // boop: into the shell, peeks, pops out giggling
        ear: (t, s) => { const k = S(s); t.to(80, { tilt: s * 4, sq: 0.05 }, 'o').to(260, { tilt: -s * 2, sq: 0 }, 'io').to(200, { tilt: 0 }, 'io');           // knock knock on her shell (it rocks)
          see(t, 'ear', s, 250); t.to(260, { [k.arm]: 70, nk: 0.3 }, 'io').osc(420, 2, { [k.arm]: 85 }, { [k.arm]: 65 }, 'io').to(260, { [k.arm]: 0 }, 'io'); unsee(t); giggle(t, 1); },
        nose: (t, s) => { t.to(250, { nk: 0.7, cross: 0 }, 'io'); sniff(t, 2); tasteHeart(t); t.to(250, { nk: 0 }, 'io'); },                                   // neck reaches out to sniff your finger
        eye: (t, s) => { const k = S(s); t.e('blink2').to(200, { [k.wink]: 1, nk: -0.3 }, 'io').wait(250).to(220, { [k.wink]: 0, nk: 0 }, 'io'); shake(t, { P: 110, env: [0.5, 0.8, 0.4], head: 0.22, roll: 3, ear: 0 }); },
        cheek: (t, s) => { leanIn(t, s); },
        belly: (t, s) => { t.to(220, { hap: 1, smile: 1, open: 0.4 }, 'io'); const a = t.t; giggle(t, 3, 0.9);                                               // ticklish: legs kick, shell rocks
          para(t, a, u => u.osc(1000, 3, { footL: 3, footR: 0, armL: 30, armR: 0, tilt: 4 }, { footL: 0, footR: 3, armL: 0, armR: 30, tilt: -4 }, 'io').to(200, { footL: 0, footR: 0, armL: 0, armR: 0, tilt: 0 }, 'io')); },
        side: (t, s) => { duck(t, 0.75); t.to(420, { spin: -s * 70 }, 'io').wait(150).to(460, { spin: 0 }, 'io'); popOut(t); see(t, 'side', s, 200); unsee(t, 300); },   // tucks in and the shell turns away, then back
        foot: (t, s) => { const k = S(s); t.to(100, { [k.foot]: 0, hid: 0.4 }, 'o').wait(250).to(160, { hid: 0, [k.foot]: 3 }, 'o').to(120, { [k.foot]: 0, sq: 0.06 }, 'i').e('emit', 'dust', 'body', 1).to(150, { sq: 0 }, 'io'); see(t, 'foot', s, 200); unsee(t); },
        tail: (t, s) => { t.osc(600, 3, { wag: 26 }, { wag: -26 }, 'io').to(150, { wag: 0 }, 'io'); see(t, 'tail', 1, 350); unsee(t, 380); giggle(t, 1); },
      },
      // the sea turtle can't hide in its shell: it answers with its flippers, neck and head
      seaturtle: {
        head: (t, s) => { t.to(120, { nk: -0.4, close: 0.7, sq: 0.06 }, 'o').to(260, { nk: 0.5, close: 0, sq: 0 }, 'io'); giggle(t, 2); t.to(260, { armL: 50, armR: 50 }, 'o').to(300, { armL: 0, armR: 0 }, 'io'); },   // boop: head bobs down, giggles, happy flap
        ear: (t, s) => { const k = S(s); t.to(80, { tilt: s * 4, sq: 0.05 }, 'o').to(260, { tilt: -s * 2, sq: 0 }, 'io').to(200, { tilt: 0 }, 'io');           // tap on its shell: it rocks
          see(t, 'ear', s, 250); t.to(260, { [k.arm]: 80, nk: 0.4 }, 'io').osc(420, 2, { [k.arm]: 95 }, { [k.arm]: 70 }, 'io').to(260, { [k.arm]: 0 }, 'io'); unsee(t); giggle(t, 1); },
        nose: (t, s) => { t.to(250, { nk: 0.8 }, 'io'); sniff(t, 2); tasteHeart(t); t.to(250, { nk: 0 }, 'io'); },
        eye: (t, s) => { const k = S(s); t.e('blink2').to(200, { [k.wink]: 1, nk: -0.3 }, 'io').wait(250).to(220, { [k.wink]: 0, nk: 0 }, 'io'); shake(t, { P: 110, env: [0.5, 0.8, 0.4], head: 0.22, roll: 3, ear: 0 }); },
        cheek: (t, s) => { leanIn(t, s); },
        belly: (t, s) => { t.to(220, { hap: 1, smile: 1, open: 0.4 }, 'io'); const a = t.t; giggle(t, 3, 0.9);                                               // ticklish: all four flippers paddle
          para(t, a, u => u.osc(1000, 4, { armL: 70, armR: 10, footL: 3, footR: 0, tilt: 3 }, { armL: 10, armR: 70, footL: 0, footR: 3, tilt: -3 }, 'io').to(200, { armL: 0, armR: 0, footL: 0, footR: 0, tilt: 0 }, 'io')); },
        side: (t, s) => { t.to(380, { spin: -s * 40, [S(-s).arm]: 60, nk: 0.3 }, 'io').wait(200).to(420, { spin: 0, [S(-s).arm]: 0, nk: 0 }, 'io'); see(t, 'side', s, 200); unsee(t, 300); },   // turns a little away, then back
        foot: (t, s) => { const k = S(s); t.to(120, { [k.arm]: 90 }, 'o').osc(500, 2, { [k.arm]: 60 }, { [k.arm]: 95 }, 'io').to(220, { [k.arm]: 0, sq: 0.05 }, 'i').e('emit', 'dust', 'body', 1).to(150, { sq: 0 }, 'io'); see(t, 'foot', s, 200); unsee(t); },
        tail: (t, s) => { t.osc(600, 3, { wag: 26, footL: 2, footR: 2 }, { wag: -26, footL: 0, footR: 0 }, 'io').to(150, { wag: 0 }, 'io'); see(t, 'tail', 1, 350); unsee(t, 380); giggle(t, 1); },
      },
    };
    const TXT = {
      shelly: { head: 'Boop! She ducks into her shell, peeks out and pops back out giggling.', ear: 'Knock knock on her shell - it rocks, she looks up and pats the spot with a flipper.',
        nose: 'Stretches her neck out to sniff your finger and licks it: a heart.', eye: 'Blinks hard, tucks her neck a little, a small head shake.', cheek: 'Leans her head into your finger.',
        belly: 'Ticklish: giggles with her little legs kicking and her shell rocking.', side: 'Tucks in and her shell turns away from the poke, then she turns back and peeks.',
        foot: 'Pulls that flipper into her shell, then stomps it back down.', tail: 'Her little tail wiggles, she looks back and giggles.' },
      seaturtle: { head: 'Boop! Its head bobs down, it giggles and gives a happy flipper flap.', ear: 'Tap on its shell - it rocks, looks up and pats the spot with a big flipper.',
        nose: 'Stretches its neck out to sniff your finger and licks it: a heart.', eye: 'Blinks hard, tucks its neck a little, a small head shake.', cheek: 'Leans its head into your finger.',
        belly: 'Ticklish: giggles while all four flippers paddle.', side: 'Turns a little away from the poke with a flipper flap, then turns back and peeks.',
        foot: 'Waves that big flipper, then pats it down on the ground.', tail: 'Its little tail wiggles with the back flippers, it looks back and giggles.' },
    };
    build(RE, TXT, BODY);
  })();

  // =====================================================================================================================================
  // eating (all 20 foods, her own way)
  (function boot() {
    const R = window.RiveRig; if (!R || !R.EATKIT || !R.oceanV || !R.EATLIB) { setTimeout(boot, 25); return; } if (R.oceanEatV) return; R.oceanEatV = 1;
    const { o, jump } = R.PETLIB;
    const { EAR, sniffF, lipLick, hearts, buildAll } = R.EATKIT;
    Object.assign(EAR, { shelly: 0, seaturtle: 0 });
    const CARDS = {
      shelly: { chewMs: 150, crumbs: 1, open: 0.6, armsUp: 1, txt: 'Stretches her neck out to sniff it, slow careful turtle bites; flaps her flippers and wags her little tail when she likes it.',
        pre: t => { t.to(300, { nk: 0.8 }, 'io'); sniffF(t, 1); t.to(260, { nk: 0.3 }, 'io'); }, post: t => { lipLick(t); t.to(250, { nk: 0 }, 'io'); },
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io').to(220, { nk: 1, armL: 60, armR: 0, wag: 18 }, 'io').to(220, { armL: 0, armR: 60, wag: -18 }, 'io').to(240, { armL: 0, armR: 0, wag: 0, nk: 0.2 }, 'io'); },
        love: t => { hearts(t, 2); t.to(120, { hid: 0.6, blush: 1 }, 'o').wait(200).to(180, { hid: 0, nk: 1 }, 'o').to(240, { nk: 0.2 }, 'io'); CARDS.shelly.yum(t); } },   // shy-happy: ducks in, pops out blushing
      seaturtle: { chewMs: 150, crumbs: 1, open: 0.6, armsUp: 1, txt: 'Stretches its neck out to sniff it, slow careful sea-turtle bites; paddles its big flippers when it likes it.',
        pre: t => { t.to(300, { nk: 0.8 }, 'io'); sniffF(t, 1); t.to(260, { nk: 0.3 }, 'io'); }, post: t => { lipLick(t); t.to(250, { nk: 0 }, 'io'); },
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io').to(220, { nk: 0.9, armL: 70, armR: 10, wag: 14 }, 'io').to(220, { armL: 10, armR: 70, wag: -14 }, 'io').to(240, { armL: 0, armR: 0, wag: 0, nk: 0.2 }, 'io'); },
        love: t => { hearts(t, 2); t.to(160, { blush: 1, armL: 90, armR: 90, lift: 1.5 }, 'o').to(260, { armL: 0, armR: 0, lift: 0 }, 'io'); CARDS.seaturtle.yum(t); } },   // both flippers up for joy
    };
    buildAll(CARDS);
  })();
})();
