// Per-creature play + kitchen moves (swing: swingin / swing / swingout, rocking horse: ridein / ride / rideout, cook: cookin / cook, fridge rummage: fridge) for all house creatures.
// p = his own play signature (swing + horse; falls back to his sit signature), k = cooking signature (falls back to p), sn = favourite snack icon pulled from the fridge (ICON key),
// sp / rp / cp = swing / ride / cook pose tweaks, sy = extra lag channels synced to the swing / horse by the house ({channel: amount}), cheer / cheerFx come from the shared WX table.
window.HouseCreatures = window.HouseCreatures || []; window.HouseCreatures.push(function (H) {
  const { playBuild, hand, both, o, PROF } = H;
  const sp = (t, v, d, hold) => { const b = {}; Object.keys(v).forEach(k => b[k] = t.B[k] != null ? t.B[k] : 0); t.to((d || 700) * 0.4, v, 'o').wait(hold || 300).to((d || 700) * 0.6, b, 'io'); return t; };
  const bk = (t, d) => t.back(d || 420);
  const ears = (t, n) => { for (let i = 0; i < (n || 2); i++) t.to(110, { earL: -14, earR: 14 }, 'o').to(130, { earL: 10, earR: -10 }); return t.to(140, { earL: 0, earR: 0 }); };
  const lick = t => { t.to(380, o(hand(1, 8, -13), { armR: 34, close: 0.6 }), 'io').osc(1300, 5, { tongue: 0.6 }, { tongue: 0.1 }, 's').to(200, { tongue: 0 }); return bk(t); };
  const nib = t => { t.to(320, o(hand(1, 8, -12), { armR: 32 }), 'io').to(260, { puff: 1 }).osc(900, 5, { open: 0.2 }, { open: 0 }, 'l').fx('crumb', 'mouth'); return bk(t); };
  const LAPS = { armL: 64, armR: 64, hLx: 2, hRx: -2, hLy: 0, hRy: 0 }; // fins / wings: no grip on the ropes, held out for balance
  // round foods with side-hinged arms: grip the ropes low beside the body (raised high they stick straight out)
  const RND = Object.fromEntries('lumi plip mallow bao dunkie frybo bunbun choco scoop boba chefbun pina avo berri lemmy kiwi peachy melo pitaya tutti floof ember cuppy chip twisty crois maca puddi mochi cakey'.split(' ').map(k => [k, 1]));
  const C = {
    // ---------- Pet Shop ----------
    mittens: { sn: 'fish', p: t => sp(t, { curl: 0.9, sqz: 0.6, hap: 1, smile: 1 }, 1400, 900), k: lick },
    biscuit: { sn: 'bone', p: t => { t.to(200, { hap: 1, smile: 1, open: 0.5, tongue: 0.5 }).osc(1500, 8, { wag: 28 }, { wag: -28 }, 'o'); bk(t); },
      k: t => { t.to(300, { pitch: t.B.pitch - 0.16, ly: 0.8, wide: 0.6 }).osc(900, 6, { puff: 0.4, htilt: 3 }, { puff: 0, htilt: -3 }, 'l').osc(800, 4, { wag: 26 }, { wag: -26 }, 'o'); bk(t); } },
    prickle: { sn: 'berry', p: t => sp(t, { curl: 1, sq: t.B.sq + 0.12, close: 1 }, 1400, 900),
      k: t => { t.to(300, { wide: 0.8, open: 0.3 }).fx('steam', 'head').to(300, { curl: 0.8, sq: t.B.sq + 0.1, close: 1 }).wait(500).to(200, { curl: 0, wide: 0.5 }, 'o'); bk(t); } },
    truffle: { sn: 'apple', p: t => sp(t, { sqz: 0.6, hap: 1, smile: 1, wag: 20 }, 1300, 900), k: nib },
    ribbit: { sn: 'berry', p: t => { for (let i = 0; i < 2; i++) t.to(120, { lift: (t.B.lift || 0) + 3, sq: (t.B.sq || 0) - 0.06, hap: 1, open: 0.4 }, 'o').to(160, { lift: t.B.lift || 0, sq: (t.B.sq || 0) + 0.04 }, 'i'); bk(t); } },
    nibbles: { sn: 'nut', p: t => sp(t, { puff: 1, hap: 1, smile: 1 }, 1200, 800), k: nib },
    quill: { sn: 'berry', p: t => sp(t, { blush: 1, sqz: 0.6, htilt: 7, smile: 1 }, 1400, 900), k: t => { sp(t, { blush: 1, close: 0.7, smile: 1, htilt: -6 }, 1200, 800); t.fx('heart', 'head'); } },
    poppy: { sn: 'carrot', sy: { ear: 22 }, p: t => { t.osc(1200, 4, { earL: -18, earR: 16 }, { earL: 16, earR: -18 }, 's'); bk(t); },
      k: t => { for (let i = 0; i < 2; i++) t.to(120, { lift: (t.B.lift || 0) + 3, sq: (t.B.sq || 0) - 0.06, hap: 1, open: 0.4 }, 'o').to(160, { lift: t.B.lift || 0, sq: (t.B.sq || 0) + 0.04 }, 'i'); bk(t); } },
    duchess: { sn: 'fish', p: t => sp(t, { htilt: 9, close: 0.6, pitch: t.B.pitch + 0.14, smile: 0.6 }, 1400, 1000),
      k: t => { t.to(400, o(hand(1, 9, -13), { armR: 34, close: 0.7 })).wait(600).to(260, { sqz: 0.5 }).fx('spark', 'head', 2); bk(t); } },
    mamapaws: { sn: 'bone', p: t => { sp(t, o(both(12, 1), { armL: 18, armR: 18, close: 0.6, smile: 1 }), 1400, 1000); t.fx('heart', 'head'); } },
    // ---------- Sky & Stars ----------
    nimbo: { sn: 'candy', p: t => { t.fx('drop', 'body', 4).osc(1400, 3, { sq: t.B.sq + 0.06, puff: 0.4 }, { sq: t.B.sq, puff: 0 }, 's').fx('drop', 'body', 3); bk(t); },
      k: t => { t.fx('drop', 'body', 3).to(300, { wide: 0.7, open: 0.3 }).fx('steam', 'head').wait(400).to(260, { sqz: 0.6, smile: 1 }); bk(t); } },
    lumi: { sn: 'honey', p: t => { t.fx('spark', 'head', 4).to(400, { hap: 1, smile: 1, ly: -0.6 }).wait(600); bk(t); } },
    bubbly: { sn: 'candy', sp: LAPS, p: t => { for (let i = 0; i < 2; i++) t.to(300, { puff: 0.6, sq: t.B.sq + 0.05 }).to(200, { puff: 0, open: 0.4 }, 'o').fx(i ? 'bigbubble' : 'bubble', 'mouth', 2); bk(t); } },
    twinkle: { sn: 'star', sp: LAPS, p: t => { sp(t, { glow: 1, wide: 0.6, hap: 1 }, 1200, 800); t.fx('spark', 'body', 5); } },
    zappi: { sn: 'bolt', p: t => { t.to(80, { zap: 1, wide: 1 }, 'o').osc(420, 4, { x: -0.5 }, { x: 0.5 }, 'l').fx('spark', 'body', 5).to(300, { zap: 0, x: 0 }); bk(t); },
      k: t => { t.to(80, { zap: 1, wide: 1, open: 0.4 }, 'o').fx('spark', 'pawR', 5).osc(420, 4, { x: -0.5 }, { x: 0.5 }, 'l').fx('steam', 'pawR').to(300, { zap: 0, x: 0, sqz: 0.6 }); bk(t); } },
    plip: { sn: 'berry', p: t => { t.osc(1200, 3, { sq: t.B.sq + 0.08 }, { sq: t.B.sq - 0.03 }, 'o').fx('drop', 'head', 3); bk(t); } },
    breeze: { sn: 'apple', p: t => { t.to(400, { puff: 0.8 }).to(300, { puff: 0, open: 0.35 }, 'o').fx('gust', 'head'); bk(t); },
      k: t => { t.to(380, o(hand(1, 8, -12), { armR: 34 }), 'io').to(400, { puff: 0.9 }).to(400, { puff: 0, open: 0.4, mw: 0.5 }, 'o').fx('gust', 'mouth').fx('steam', 'pawR').wait(300).to(200, { sqz: 0.6, smile: 1 }); bk(t); } },
    dusty: { sn: 'flower', p: t => { ears(t, 3).fx('dust', 'body', 4); bk(t); } },
    aurora: { sn: 'fish', sp: LAPS, p: t => { t.to(300, { spout: 1 }, 'o').fx('gush', 'head', 3).wait(500).to(400, { spout: 0, glow: 0.8 }).wait(400); bk(t, 600); } },
    // ---------- Snack Shack ----------
    mallow: { sn: 'candy', p: t => sp(t, { sq: t.B.sq + 0.18, close: 0.8, smile: 1 }, 1400, 1000), k: t => { sp(t, { sq: t.B.sq + 0.14, blush: 1, smile: 1, close: 0.6 }, 1400, 900); t.fx('steam', 'head'); } },
    bao: { sn: 'cup', p: t => { t.fx('steam', 'head').osc(1200, 2, { sq: t.B.sq + 0.06 }, { sq: t.B.sq }, 's').fx('steam', 'head'); bk(t); } },
    dunkie: { sn: 'cup', p: t => { t.osc(1600, 3, { tilt: 5, turn: 0.3 }, { tilt: -5, turn: -0.3 }, 's').fx('sprinkle', 'head'); bk(t); } },
    frybo: { sn: 'ketchup', p: t => { sp(t, { fw: 1, smile: 1, hap: 1 }, 1200, 800); t.fx('salt', 'head'); },
      k: t => { t.to(300, { fw: 0.8, hap: 1 }, 'o').osc(900, 6, { tilt: 3 }, { tilt: -3 }, 'l').fx('salt', 'head', 4).fx('salt', 'pawR', 3).to(300, { fw: 0 }); bk(t); } },
    bunbun: { sn: 'cheese', p: t => sp(t, { split: 0.5, shuf: 0.3, hap: 1 }, 1300, 800) },
    choco: { sn: 'nut', p: t => sp(t, { melt: 0.5, close: 0.8, smile: 1 }, 1500, 1000), k: t => { sp(t, { melt: 0.7, wide: 0.6, open: 0.3 }, 1400, 800); t.fx('steam', 'head').fx('sweat', 'head'); } },
    scoop: { sn: 'cherry', p: t => { t.osc(1300, 3, { chb: 0.9 }, { chb: 0 }, 'o'); bk(t); }, k: t => { t.fx('sweat', 'head').to(300, { wide: 0.7, open: 0.3, frown: 0.3 }).fx('drop', 'head', 2).wait(500).to(300, { chb: 0.9, frown: 0, smile: 1 }).to(300, { chb: 0 }); bk(t); } },
    boba: { sn: 'cup', p: t => { t.osc(1400, 3, { slurp: 0.6, sqz: 0.4 }, { slurp: 0, sqz: 0 }, 's').fx('bubble', 'head', 2); bk(t); } },
    chefbun: { sn: 'cake', cOrd: ['stir', 'season', 'shake', 'flip', 'sig', 'flip', 'taste', 'kiss'],
      p: t => { t.to(400, o(hand(1, 10, -13), { armR: 34 })).wait(300).to(260, o(hand(1, -4, -14), { armR: 60, smile: 1 }), 'o').fx('heart', 'head').wait(400); bk(t, 500); },
      k: t => { t.to(300, o(hand(-1, 8, -16), { armL: 70, close: 0.6, smile: 1 }), 'io').osc(800, 2, { htilt: 6 }, { htilt: -2 }, 's').to(300, o(hand(1, 7, -14), { armR: 38, puff: 0.3 })).to(200, { armR: 120, hRx: 4, hRy: -6, puff: 0, sqz: 0.8, hap: 1 }, 'o').fx('heart', 'head', 2).fx('spark', 'head', 4).wait(500); bk(t, 500); } },
    // ---------- Ocean Pals ----------
    pip: { sn: 'fish', p: t => { t.osc(1200, 6, { armL: 60, armR: 60 }, { armL: 20, armR: 20 }, 'o'); bk(t); } },
    jelli: { sn: 'candy', sp: LAPS, p: t => { for (let i = 0; i < 2; i++) t.to(350, { sq: t.B.sq + 0.1 }, 'i').to(450, { sq: t.B.sq - 0.05, lift: t.B.lift + 1.2 }, 'o').fx('bubble', 'body', 2).to(400, { sq: t.B.sq, lift: t.B.lift }, 's'); bk(t, 300); } },
    finn: { sn: 'fish', sp: LAPS, p: t => { t.osc(1400, 4, { wag: 26 }, { wag: -26 }, 's').fx('drop', 'tail', 3); bk(t); } },
    sealy: { sn: 'fish', sp: LAPS, p: t => { t.osc(800, 3, { open: 0.4 }, { open: 0.05 }, 'o').osc(900, 4, { hLx: 2, hRx: -2, armL: 30, armR: 30 }, { hLx: 7, hRx: -7, armL: 14, armR: 14 }, 'o'); bk(t, 500); } },
    puff: { sn: 'berry', p: t => { t.to(700, { blo: 0.8, puff: 0.8 }, 's').wait(500).to(500, { blo: 0, puff: 0 }).fx('bubble', 'mouth', 3); bk(t); } },
    shelly: { sn: 'leaf', sp: LAPS, p: t => sp(t, { nk: 1, wide: 0.5, hap: 1 }, 1400, 900) },
    octo: { sn: 'fish', p: t => sp(t, { ow: 1, osp: 0.8, hap: 1 }, 1400, 900), k: t => { sp(t, { ow: 1, hap: 1, smile: 1 }, 1600, 1000); t.fx('steam', 'pawR').fx('salt', 'pawL', 3); } },
    marina: { sn: 'shell', sy: { tsw: 0.5 }, p: t => { t.to(400, { tlf: 0.8 }, 'o').osc(900, 2, { tsw: 0.6 }, { tsw: -0.6 }, 's').to(400, { tlf: 0, tsw: 0 }); bk(t); } },
    pearl: { sn: 'fish', p: t => { sp(t, { glow: 1, hsw: 0.6 }, 1400, 900); t.fx('spark', 'head', 3); } },
    // ---------- Fruit Patch ----------
    pina: { sn: 'cake', p: t => { t.to(300, { crw: 0.8 }, 'o').osc(1000, 3, { crs: 0.4 }, { crs: 0 }, 's').to(300, { crw: 0 }); bk(t); } },
    avo: { sn: 'cookie', p: t => { t.to(300, { prw: 0.9 }).wait(900).to(300, { prw: 0 }); bk(t); } },
    berri: { sn: 'cake', p: t => { t.to(120, { stw: 1 }, 'o').to(800, { stw: 0 }); bk(t); } },
    lemmy: { sn: 'candy', p: t => sp(t, { sqz: 0.9, mw: 0.5 }, 900, 700), k: t => { t.to(300, o(hand(1, 8, -13), { armR: 36 }), 'io').to(160, { sqz: 1, mw: 0.4, frown: 0.3, wide: 0 }, 'o').osc(600, 6, { x: 0.5 }, { x: -0.5 }, 'l').to(200, { frown: 0, wide: 0.8, sqz: 0, open: 0.4 }, 'o'); bk(t); } },
    kiwi: { sn: 'berry', p: t => sp(t, { fzz: 0.8, sqz: 0.5 }, 1200, 800) },
    melo: { sn: 'cookie', p: t => { t.osc(1300, 3, { sdj: 1 }, { sdj: 0 }, 'o'); bk(t); } },
    peachy: { sn: 'honey', p: t => sp(t, { blush: 1, lfl: 0.6, smile: 1 }, 1400, 900) },
    pitaya: { sn: 'berry', p: t => sp(t, { wfl: 1, wsp: 0.6, brf: 0.5 }, 1200, 800) },
    tutti: { sn: 'cherry', p: t => { sp(t, { wfl: 0.8 }, 1200, 800); t.fx('dust', 'body', 3); } },
    // ---------- Forest Friends ----------
    kiko: { sn: 'nut', p: t => { ears(t, 2).fx('spark', 'head', 3); bk(t); } },
    teddy: { sn: 'honey', p: t => sp(t, o(both(14, -4), { armL: 26, armR: 26, smile: 1, blush: 0.5 }), 1300, 900), k: lick },
    hoot: { sn: 'nut', sp: LAPS, p: t => { t.to(300, { wfl: 1, armL: 70, armR: 70 }, 'o').osc(800, 6, { armL: 80, armR: 80 }, { armL: 40, armR: 40 }, 'l'); bk(t); } },
    leo: { sn: 'cookie', sy: { tsw: 0.4 }, p: t => { t.to(400, { mfl: 0.8, open: 0.5 }, 'o').wait(500).to(500, { mfl: 0, open: 0 }); bk(t); } },
    panko: { sn: 'bamboo', p: t => { t.osc(1600, 3, { tilt: 5, x: 1 }, { tilt: -5, x: -1 }, 's'); bk(t); }, k: nib },
    acorn: { sn: 'acorn', sy: { tsw: 0.4 }, p: t => sp(t, { tfl: 1, tsw: 0.6 }, 1300, 900), k: nib },
    fawn: { sn: 'apple', sy: { ear: 20 }, p: t => { ears(t, 3); bk(t); } },
    moss: { sn: 'berry', p: t => { t.osc(1300, 3, { cb: 0.9 }, { cb: 0 }, 'o'); bk(t); } },
    sprout: { sn: 'drop', p: t => sp(t, { blm: 1, lfl: 0.6 }, 1600, 1200) },
    // ---------- Dreamland ----------
    hana: { sn: 'carrot', p: t => { t.to(400, { flL: 0.9, flR: 0.9 }).osc(1000, 4, { tw: 1 }, { tw: -1 }, 's').to(400, { flL: 0, flR: 0 }); bk(t); } },
    boo: { sn: 'candy', p: t => sp(t, { gho: 0.5, flr: 0.6 }, 1500, 900) },
    pixie: { sn: 'honey', p: t => { sp(t, { wfl: 1, wsp: 0.5 }, 1200, 800); t.fx('dust', 'body', 4); } },
    floof: { sn: 'berry', p: t => { t.to(200, { fzz: 0.9 }, 'o').osc(700, 6, { x: 0.6 }, { x: -0.6 }, 'l').to(400, { fzz: 0 }); bk(t); } },
    unibun: { sn: 'carrot', p: t => { t.fx('spark', 'head', 5); ears(t, 2); bk(t); } },
    gumdrop: { sn: 'candy', p: t => sp(t, { jig: 1, hap: 1 }, 1200, 900) },
    ember: { sn: 'berry', p: t => { t.to(300, { cfl: 1, open: 0.4, hap: 1 }, 'o').wait(700).to(400, { cfl: 0 }); bk(t); }, k: t => { t.to(300, { cfl: 1, wide: 0.6, open: 0.4 }, 'o').fx('spark', 'pawR', 4).fx('steam', 'pawR').wait(600).to(400, { cfl: 0, sqz: 0.6, smile: 1 }); bk(t); } },
    drako: { sn: 'apple', sy: { tsw: 0.5 }, p: t => { t.osc(1400, 2, { tsw: 0.7 }, { tsw: -0.7 }, 's').to(300, { puff: 0.6 }).to(200, { puff: 0 }).fx('steam', 'head'); bk(t); } },
    jinni: { sn: 'cup', p: t => { sp(t, { glo: 0.8, gwh: 0.6 }, 1400, 900); t.fx('spark', 'body', 3); } },
    // ---------- Sweet Bakery ----------
    cuppy: { sn: 'cherry', p: t => { t.fx('sprinkle', 'head').osc(1300, 3, { sq: t.B.sq + 0.05 }, { sq: t.B.sq }, 'o'); bk(t); } },
    chip: { sn: 'cup', p: t => { t.osc(800, 4, { x: 0.5 }, { x: -0.5 }, 'l').fx('crumb', 'body', 3); bk(t, 300); } },
    twisty: { sn: 'cheese', p: t => { t.osc(1800, 2, { tilt: 5 }, { tilt: -5 }, 's').fx('salt', 'head'); bk(t); } },
    crois: { sn: 'cup', p: t => sp(t, { lean: 1.2, tilt: 3, smile: 1 }, 1400, 900) },
    maca: { sn: 'berry', p: t => { t.to(100, { sq: t.B.sq + 0.1 }, 'o').to(200, { sq: t.B.sq }).wait(250).to(100, { sq: t.B.sq + 0.08 }, 'o').to(200, { sq: t.B.sq }); bk(t, 300); } },
    puddi: { sn: 'cherry', p: t => { t.osc(1400, 6, { sq: t.B.sq + 0.06, x: 0.3 }, { sq: t.B.sq - 0.02, x: -0.3 }, 'l'); bk(t); } },
    mochi: { sn: 'berry', p: t => sp(t, { sq: t.B.sq + 0.16, smile: 1, close: 0.6 }, 1400, 1000) },
    cakey: { sn: 'cup', p: t => { t.to(400, { puff: 0.7 }).to(500, { puff: 0, open: 0.2, mw: 0.5 }, 'o').fx('gust', 'head').to(300, { open: 0, mw: 1 }); bk(t); } },
    sugarplum: { sn: 'cake', p: t => { t.to(400, { armR: 70, hRy: -2, smile: 0.9 }, 'o').osc(1300, 3, { hRx: -3 }, { hRx: 3 }, 's').fx('spark', 'head', 3); bk(t, 500); } },
    // ---------- Spooky Squish ----------
    gourdy: { sn: 'candy', p: t => { t.osc(2000, 2, { tilt: 6, x: 1 }, { tilt: -6, x: -1 }, 's'); bk(t); } },
    batty: { sn: 'berry', sp: LAPS, p: t => sp(t, { armL: 80, armR: 80, hLx: 12, hRx: -12 }, 1000, 900) },
    kernel: { sn: 'candy', p: t => { t.to(120, { lift: t.B.lift + 3, sq: t.B.sq - 0.06 }, 'o').to(240, { lift: t.B.lift, sq: t.B.sq + 0.04 }, 'i').fx('spark', 'head', 2); bk(t); } },
    hexie: { sn: 'fish', p: t => { sp(t, { curl: 0.7 }, 1200, 900); t.fx('spark', 'head', 3); } },
    mumbles: { sn: 'candy', p: t => { t.to(800, { armL: 88, armR: 88, hLy: -2, hRy: -2, open: 0.2 }, 'io').wait(700); bk(t, 700); } },
    hocus: { sn: 'candy', p: t => { t.fx('spark', 'body', 4).wait(700).fx('spark', 'body', 3); bk(t, 300); } },
    countsquishula: { sn: 'cherry', p: t => { t.to(400, o(hand(-1, 10, -14), { armL: 60, close: 0.4, smile: 0.6 })).wait(800).fx('spark', 'head', 2); bk(t, 500); } },
  };
  // Waffles joined Nov 9 (his own rig is built now)
  Object.keys(PROF).forEach(k => { const X = C[k] || {}; if (RND[k] && !X.sp) X.sp = { armL: 42, armR: 42, hLy: -7, hRy: -7, hLx: 1, hRx: -1 }; playBuild(k, X); });
});
