/* Squish Squad plush animation engine: moods, part rigs, faces, props. Used by Creature Plush.dc.html */
(function () {
  const TAU = Math.PI * 2, NS = 'http://www.w3.org/2000/svg';
  const num = (e, a) => parseFloat(e.getAttribute(a) || '0');
  const cap = k => k[0].toUpperCase() + k.slice(1);
  const ease = { back: x => { const c = 1.9; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); }, out: x => 1 - Math.pow(1 - x, 3) };
  const MOODS = ['idle', 'eat', 'dance', 'unlock', 'happy', 'sad', 'clean', 'dirty', 'bath', 'tv', 'sleep'];
  const ALIAS = { ready: 'idle', jump: 'happy', celebrate: 'unlock', wobble: 'dance' };
  const FACE = { idle: null, eat: 'eating', dance: 'happy', unlock: 'star', happy: 'party', sad: 'sad', clean: 'content', dirty: 'smelly', bath: 'content', tv: null, sleep: 'sleep' };
  const MOVEKEY = { idle: 'idle', eat: 'eat', dance: 'dance', unlock: 'happy', happy: 'happy', sleep: 'sleep' };
  const FOODS = { nimbo: 'drop', mittens: 'fish', mallow: 'cocoa', bao: 'dumpling', dunkie: 'sprinkle', frybo: 'ketchup', pip: 'shrimp', bunbun: 'pickle', jelli: 'plankton', pina: 'coconut', finn: 'fish', sealy: 'fish', biscuit: 'bone', hana: 'carrot', choco: 'strawberry', prickle: 'apple', lumi: 'mooncake', kiko: 'honey', bubbly: 'soap', twinkle: 'starcandy', zappi: 'battery' };
  const FOOD = {
    drop: '<path d="M0 -7 Q6 1 0 7 Q-6 1 0 -7Z" fill="#8fd3ff"/><ellipse cx="-1.5" cy="1" rx="1.2" ry="2" fill="#fff" opacity=".8"/>',
    fish: '<path d="M-7 0 Q-2 -5 4 0 Q-2 5 -7 0Z" fill="#ff9a5a"/><path d="M4 0 L8 -4 L8 4Z" fill="#ff9a5a"/><circle cx="-4" cy="-1" r="0.9" fill="#2a1a30"/>',
    cocoa: '<rect x="-5" y="-4" width="9" height="9" rx="2" fill="#f2a6c6"/><path d="M4 -1 q3 0 3 2.5 q0 2.5 -3 2.5" stroke="#f2a6c6" stroke-width="1.6" fill="none"/><ellipse cx="-0.5" cy="-4" rx="4.5" ry="1.4" fill="#7a4a2a"/><circle cx="-2" cy="-5" r="1.2" fill="#fff"/><circle cx="1" cy="-5.4" r="1.1" fill="#fff"/>',
    dumpling: '<path d="M-7 3 Q-6 -6 0 -6 Q6 -6 7 3Z" fill="#fff6e8"/><path d="M-3 -5 Q0 -2 3 -5" stroke="#e2cfb6" stroke-width="0.8" fill="none"/>',
    sprinkle: '<rect x="-5" y="-5" width="10" height="11" rx="3" fill="#fff" stroke="#f0d6e2" stroke-width="0.8"/><rect x="-3" y="-2" width="2.6" height="1" fill="#ff5c8a" transform="rotate(30 -2 -1.5)"/><rect x="0.5" y="0" width="2.6" height="1" fill="#7cc8ff"/><rect x="-2.5" y="2.5" width="2.6" height="1" fill="#ffd84a" transform="rotate(-25 -1 3)"/>',
    ketchup: '<rect x="-3.5" y="-3" width="7" height="10" rx="2" fill="#f2665a"/><rect x="-1.5" y="-7" width="3" height="4" rx="1" fill="#fff"/>',
    shrimp: '<path d="M-5 -3 Q2 -7 6 0 Q4 6 -2 5 Q2 2 0 -1 Q-3 -1 -5 -3Z" fill="#ff9f80"/>',
    pickle: '<ellipse rx="3.6" ry="7" fill="#8bc34a" transform="rotate(25)"/><circle cx="-1" cy="-2" r="0.6" fill="#5f8a2a"/><circle cx="1" cy="2" r="0.6" fill="#5f8a2a"/>',
    plankton: '<circle r="5.5" fill="#bfefff" opacity=".85"/><circle cx="-2" cy="-1" r="1.2" fill="#7fd06f"/><circle cx="2" cy="1.5" r="1" fill="#ffd84a"/>',
    coconut: '<circle r="6" fill="#8a5a3a"/><circle r="4.2" fill="#fff8ee"/><path d="M1 -6 L4 -10" stroke="#ff7fb0" stroke-width="1.2"/>',
    bone: '<rect x="-5" y="-1.6" width="10" height="3.2" rx="1.6" fill="#f3dcb6"/><circle cx="-5.5" cy="-1.8" r="2" fill="#f3dcb6"/><circle cx="-5.5" cy="1.8" r="2" fill="#f3dcb6"/><circle cx="5.5" cy="-1.8" r="2" fill="#f3dcb6"/><circle cx="5.5" cy="1.8" r="2" fill="#f3dcb6"/>',
    carrot: '<path d="M-2.4 -4 L2.4 -4 L0 8Z" fill="#ff9a3c"/><path d="M0 -4 L-3 -9 M0 -4 L0 -10 M0 -4 L3 -9" stroke="#7fd06f" stroke-width="1.4" stroke-linecap="round"/>',
    strawberry: '<path d="M-5 -2 Q0 -5 5 -2 Q4 6 0 8 Q-4 6 -5 -2Z" fill="#ff5c7a"/><path d="M-3 -3 L0 -6 L3 -3Z" fill="#7fd06f"/><circle cx="-1.5" cy="1" r="0.5" fill="#fff3b0"/><circle cx="1.5" cy="3" r="0.5" fill="#fff3b0"/>',
    apple: '<circle r="5.5" fill="#ff6f6f"/><path d="M0 -5 L1 -8" stroke="#7a4a2a" stroke-width="1.2"/><ellipse cx="3" cy="-7" rx="2" ry="1" fill="#7fd06f"/>',
    mooncake: '<circle r="6" fill="#e9a85e"/><circle r="4" fill="none" stroke="#c98a40" stroke-width="0.8"/><path d="M-2 0 H2 M0 -2 V2" stroke="#c98a40" stroke-width="0.8"/>',
    honey: '<rect x="-5" y="-3" width="10" height="9" rx="3" fill="#ffc23a"/><rect x="-5.5" y="-5" width="11" height="3" rx="1.2" fill="#c98a40"/><path d="M-3 -2 q0 3 1 4" stroke="#fff3b0" stroke-width="1" fill="none"/>',
    soap: '<circle r="5.5" fill="rgba(210,244,255,0.5)" stroke="#fff" stroke-width="0.8"/><path d="M-3 -1 a3 3 0 0 1 2 -3" stroke="#fff" stroke-width="1" fill="none"/>',
    starcandy: '<path d="M0 -6 L1.8 -1.8 L6 -1.5 L2.8 1.3 L3.8 5.6 L0 3.3 L-3.8 5.6 L-2.8 1.3 L-6 -1.5 L-1.8 -1.8Z" fill="#ffd84a" stroke="#fff" stroke-width="0.6"/>',
    battery: '<rect x="-4" y="-6" width="8" height="12" rx="2" fill="#7cc8ff"/><rect x="-1.5" y="-7.5" width="3" height="1.6" fill="#555"/><path d="M1 -3 L-1.5 0.5 H1 L-1 4" stroke="#fff" stroke-width="1.2" fill="none"/>',
  };
  const TV = ['#7cc8ff', '#ff9fcb', '#ffe14a', '#9be38a'];

  function scan(k, root) {
    const eyes = [];
    root.querySelectorAll('[fill^="url(#ey"]').forEach(e => { eyes.push(e); let n = e.nextElementSibling; for (let i = 0; i < 2 && n; i++, n = n.nextElementSibling) if ((n.getAttribute('fill') || '') === '#fff') eyes.push(n); });
    eyes.forEach(e => { e.style.transformBox = 'fill-box'; e.style.transformOrigin = 'center'; });
    const mouth = Array.from(root.querySelectorAll('path[stroke="#6a3a3a"]'));
    const used = new Set([...eyes, ...mouth]);
    const arms = [], feet = [], circles = Array.from(root.querySelectorAll('circle'));
    root.querySelectorAll('ellipse').forEach(e => {
      const fill = e.getAttribute('fill') || '', tr = e.getAttribute('transform') || '';
      const cx = num(e, 'cx'), cy = num(e, 'cy'), rx = num(e, 'rx'), ry = num(e, 'ry');
      if (/^#ff8fa3|^#ff9a3c/.test(fill)) { used.add(e); return; }
      if (/rotate/.test(tr) && fill.indexOf('#fff') !== 0 && !e.getAttribute('opacity')) {
        const r0 = parseFloat((tr.match(/rotate\(([-\d.]+)/) || [0, 0])[1]) * Math.PI / 180;
        const sx = cx + Math.sin(r0) * ry, sy = cy - Math.cos(r0) * ry, bx = cx - Math.sin(r0) * ry, by = cy + Math.cos(r0) * ry;
        const hands = circles.filter(c => Math.hypot(num(c, 'cx') - bx, num(c, 'cy') - by) < 7);
        arms.push({ els: [e, ...hands], base: [tr, ...hands.map(h => h.getAttribute('transform') || '')], side: cx < 50 ? -1 : 1, sx, sy }); used.add(e); hands.forEach(h => used.add(h));
      } else if (!tr && cy >= 84 && cy <= 93 && rx >= 4 && fill !== '#3a2340') { feet.push({ el: e, side: cx < 50 ? -1 : 1 }); used.add(e); }
    });
    const c = (window.CREATURES_V2 || []).find(x => x.name.toLowerCase() === k) || null;
    let bb = { x: 14, y: 14, width: 72, height: 78 }; try { const b = root.getBBox(); if (b.width > 10) bb = b; } catch (e) {}
    const eyeY = c ? c.eyes[0].y : 50; const area = bb.width * bb.height;
    const parts = [];
    root.querySelectorAll('path, ellipse, circle, rect, polygon').forEach(e => {
      if (used.has(e) || e.closest('defs,clipPath,mask')) return;
      if ((e.getAttribute('fill') || '').indexOf('#fff') === 0 && e.getAttribute('opacity')) return;
      let b; try { b = e.getBBox(); } catch (x) { return; } if (!b || b.width * b.height < 3) return;
      const ccx = b.x + b.width / 2, ccy = b.y + b.height / 2, a = b.width * b.height;
      if (a > area * 0.22) return;
      if (ccy < eyeY - 12) parts.push({ el: e, kind: 'top', side: ccx < 50 ? -1 : 1, px: ccx, py: b.y + b.height, base: e.getAttribute('transform') || '' });
      else if (ccy > eyeY - 4 && (ccx < bb.x + bb.width * 0.2 || ccx > bb.x + bb.width * 0.8) && a < area * 0.12) { const s = ccx < 50 ? -1 : 1; parts.push({ el: e, kind: 'tail', side: s, px: s < 0 ? b.x + b.width : b.x, py: ccy, base: e.getAttribute('transform') || '' }); }
    });
    return { eyes, mouth, arms, feet, parts, c, bb, hash: k.split('').reduce((a, ch) => a + ch.charCodeAt(0), 0), food: FOOD[FOODS[k]] || FOOD.apple };
  }

  function extras(P, mood) {
    const c = P.c, bb = P.bb; if (!c) return '';
    const head = c.head, m = c.mouth; let h = '';
    if (mood === 'eat') h += '<g data-food>' + P.food + '</g>' + [0, 1, 2].map(i => '<circle data-crumb="' + i + '" r="0.9" fill="#e9b26a"/>').join('');
    if (mood === 'sad') c.eyes.forEach((e, i) => { const s = i ? 1 : -1; h += '<path data-tear d="M' + e.x + ' ' + (e.y + e.r) + ' Q' + (e.x + s * 3) + ' ' + (e.y + e.r + 10) + ' ' + (e.x + s) + ' ' + (e.y + e.r + 22) + '" stroke="#8fd3ff" stroke-width="2.4" stroke-linecap="round" fill="none" opacity="0.85" stroke-dasharray="4 3"/><circle data-drop="' + i + '" r="1.4" fill="#8fd3ff"/>'; });
    if (mood === 'dirty') { [[0.25, 0.72, 5], [0.72, 0.56, 4], [0.6, 0.86, 4.5], [0.34, 0.4, 3.2], [0.8, 0.8, 2.6]].forEach(([fx, fy, r]) => { h += '<ellipse cx="' + (bb.x + bb.width * fx).toFixed(1) + '" cy="' + (bb.y + bb.height * fy).toFixed(1) + '" rx="' + r + '" ry="' + (r * 0.7).toFixed(1) + '" fill="#6e6a75" opacity="0.32"/>'; }); [38, 50, 62].forEach((x, i) => { h += '<path data-stink="' + i + '" d="M0 0 q-3 -3 0 -6 q3 -3 0 -6 q-3 -3 0 -6" transform="translate(' + x + ' ' + head + ')" stroke="#a3b38c" stroke-width="1.6" stroke-linecap="round" fill="none"/>'; }); }
    if (mood === 'bath') { [36, 42, 48, 54, 60, 64, 45, 55].forEach((x, i) => { h += '<circle cx="' + x + '" cy="' + (head - (i > 5 ? 5 : 1) + (i % 2)).toFixed(1) + '" r="' + (i > 5 ? 4.5 : 3.8) + '" fill="#fff" stroke="#d6f2fc" stroke-width="0.6"/>'; }); h += [0, 1, 2, 3, 4].map(i => '<circle data-bub="' + i + '" r="2" fill="rgba(210,244,255,0.35)" stroke="#fff" stroke-width="0.6"/>').join(''); }
    if (mood === 'clean') h += [0, 1, 2, 3].map(i => '<path data-spk="' + i + '" d="M0 -4 Q0.6 -0.6 4 0 Q0.6 0.6 0 4 Q-0.6 0.6 -4 0 Q-0.6 -0.6 0 -4Z" fill="#fff6b8"/>').join('');
    if (mood === 'tv') h += '<ellipse data-glow cx="' + (bb.x + bb.width / 2).toFixed(1) + '" cy="' + (bb.y + bb.height / 2).toFixed(1) + '" rx="' + (bb.width / 2).toFixed(1) + '" ry="' + (bb.height / 2).toFixed(1) + '" fill="#7cc8ff" opacity="0.14" style="mix-blend-mode:screen"/>';
    if (mood === 'sleep') h += [0, 1, 2].map(i => '<text data-z="' + i + '" font-family="Fredoka, sans-serif" font-weight="700" font-size="9" fill="#ece6ff" stroke="#6b5bd6" stroke-width="0.8" paint-order="stroke">z</text>').join('');
    if (mood === 'happy') h += [0, 1].map(i => '<path data-h="' + i + '" d="M0 2.6c-1.6-1.4-4-2.6-4-4.6a2 2 0 0 1 4-0.6a2 2 0 0 1 4 0.6c0 2-2.4 3.2-4 4.6z" fill="#ff6fae" stroke="#fff" stroke-width="0.6"/>').join('');
    if (mood === 'dance') h += [0, 1].map(i => '<text data-note="' + i + '" font-size="9" font-weight="900" fill="' + (i ? '#b38cff' : '#ff5cc6') + '" stroke="#fff" stroke-width="0.8" paint-order="stroke">♪</text>').join('');
    return h;
  }
  function fxHtml(mood) {
    if (mood === 'unlock') return '<g data-box><rect x="28" y="68" width="44" height="26" rx="4" fill="#ff7fd0"/><rect x="47" y="68" width="6" height="26" fill="#ffd84a"/></g><g data-lid><rect x="25" y="60" width="50" height="10" rx="3" fill="#ff5cc6"/><rect x="47" y="60" width="6" height="10" fill="#ffd84a"/><path d="M50 60 q-8 -8 -12 -2 q4 4 12 2 q8 -8 12 -2 q-4 4 -12 2" fill="#ffd84a"/></g>' +
      Array.from({ length: 24 }, (_, i) => '<rect data-cf="' + i + '" width="2.4" height="3.6" rx="0.6" fill="' + ['#ff5cc6', '#ffcd3c', '#3fd7f6', '#7be495', '#b38cff'][i % 5] + '"/>').join('');
    if (mood === 'bath') return '<path d="M12 76 H88 Q86 98 50 98 Q14 98 12 76Z" fill="#9fd8f5"/><rect x="10" y="72" width="80" height="6" rx="3" fill="#e6f7fd"/>' + [18, 28, 40, 60, 72, 82].map((x, i) => '<circle cx="' + x + '" cy="' + (72 + (i % 2)) + '" r="' + (4 + (i % 3)) + '" fill="#fff"/>').join('');
    return '';
  }

  function frame(I, now) {
    const P = I.parts, el = I.bodyRef.current; if (!P || !el) return;
    const G = window.SquishRig, SM = window.SquishMoves; if (!G || !SM) return;
    let mood = I.props.mood || 'idle'; mood = ALIAS[mood] || mood; if (MOODS.indexOf(mood) < 0) mood = 'idle';
    if (I.props.still) { el.style.transform = ''; return; }
    if (mood !== I._mood) { I._mood = mood; I._t0 = now; I._built = null; }
    const t = now + I.seed, T = now - I._t0, k = I.key(), M = SM.MOVES[cap(k)], h = P.hash, sp = 0.8 + (h % 7) * 0.06;
    const v = { sx: 1, sy: 1, rot: 0, skx: 0, tx: 0, ty: 0, spin: 0 };
    const mk = MOVEKEY[mood]; if (M && mk && M[mk]) for (const c in M[mk]) v[c] = SM.w2(M[mk][c], t, G);
    let scale = 1, hidden = false, laugh = false, faceKey = FACE[mood];
    if (mood === 'sad') { const sob = (t % 1400) < 520; v.sy = 0.94 + 0.01 * Math.sin(t / 1500); v.sx = 1.04; v.rot = -4 + 2 * Math.sin(t / 2000); v.ty = 4 - (sob ? 2.4 * Math.abs(Math.sin(t / 70)) : 0); }
    if (mood === 'clean') { v.rot = 5 * Math.sin(t / 450); v.ty = -3 * Math.abs(Math.sin(t / 450)); v.sx = 1 + 0.02 * Math.sin(t / 225); }
    if (mood === 'dirty') { v.sy = 0.96; v.sx = 1.03; v.rot = 3 * Math.sin(t / 1300); v.tx = (t % 2600) < 320 ? 1.6 * Math.sin(t / 25) : 0; }
    if (mood === 'bath') { v.rot = 6 * Math.sin(t / 500); v.sx = 1 + 0.025 * Math.sin(t / 250); v.sy = 1 - 0.02 * Math.sin(t / 250); v.ty = 6; }
    if (mood === 'tv') { laugh = (t % 4200) < 700; v.rot = -6 + Math.sin(t / 1800); v.ty = 2 - (laugh ? 4 * Math.abs(Math.sin(t / 90)) : 0); if (laugh) faceKey = 'happy'; }
    let U = 0;
    if (mood === 'unlock') { U = (T % 3400) / 3400; if (U < 0.22) { hidden = true; scale = 0.001; } else if (U < 0.34) { const e = (U - 0.22) / 0.12; scale = Math.max(0.001, ease.back(e)); v.ty += 18 * (1 - ease.out(e)); } }
    const u = (Number(I.props.size) || 150) / 150;
    el.style.transform = (v.spin ? 'perspective(400px) rotateY(' + v.spin.toFixed(1) + 'deg) ' : '') + 'translate(' + (v.tx * u).toFixed(2) + 'px,' + (v.ty * u).toFixed(2) + 'px) rotate(' + v.rot.toFixed(2) + 'deg) skewX(' + v.skx.toFixed(2) + 'deg) scale(' + (v.sx * scale).toFixed(3) + ',' + (v.sy * scale).toFixed(3) + ')';
    el.style.opacity = hidden ? '0' : '1';
    // face + overlays
    if (faceKey && !G.FACES[faceKey]) faceKey = faceKey === 'smelly' ? 'sad' : 'happy';
    const sig = mood + '|' + faceKey;
    if (sig !== I._built) {
      I._built = sig; const hide = !!faceKey && !!P.c;
      P.eyes.forEach(e => { e.style.display = hide ? 'none' : ''; e.style.transform = ''; }); P.mouth.forEach(e => e.style.display = hide ? 'none' : '');
      const F = I.faceRef.current; if (F) { F.innerHTML = (hide ? G.faceInner({ ...P.c, cheeks: [] }, faceKey, 0) : '') + extras(P, mood); I.q = s => F.querySelectorAll(s); I.chomp = F.querySelector('[data-chomp]'); I.food = F.querySelector('[data-food]'); I.glow = F.querySelector('[data-glow]'); }
      const X = I.fxRef && I.fxRef.current; if (X && X._m !== mood) { X._m = mood; X.innerHTML = fxHtml(mood); I.box = X.querySelector('[data-box]'); I.lid = X.querySelector('[data-lid]'); I.cf = X.querySelectorAll('[data-cf]'); }
    }
    // arms
    P.arms.forEach((a, i) => {
      const s = a.side, ph = s > 0 ? Math.PI : 0; let r = 0;
      switch (mood) {
        case 'idle': r = 6 + 7 * Math.sin(t / (700 / sp) + i * 1.3); break;
        case 'happy': r = 95 + 30 * Math.sin(t / (150 / sp) + ph * (h % 2)); break;
        case 'unlock': r = U < 0.34 ? 150 : 110 + 25 * Math.sin(t / 140 + ph); break;
        case 'dance': r = 55 + 55 * Math.sin(t / (280 / sp) + ph); break;
        case 'eat': r = -40 + 12 * Math.sin(t / 220 + ph); break;
        case 'sad': r = -70 + 8 * Math.sin(t / 160 + ph); break;
        case 'clean': r = 30 + 20 * Math.sin(t / 450 + ph); break;
        case 'dirty': r = s < 0 ? 8 : 80 + 25 * Math.sin(t / 70); break;
        case 'bath': r = 40 + 40 * Math.sin(t / 250 + ph); break;
        case 'tv': r = s < 0 ? -8 : 14 + (laugh ? 30 * Math.abs(Math.sin(t / 90)) : 0); break;
        case 'sleep': r = -6 + 2 * Math.sin(t / 1600); break;
      }
      const R = (-s * r).toFixed(1); a.els.forEach((e, j) => e.setAttribute('transform', 'rotate(' + R + ' ' + a.sx.toFixed(1) + ' ' + a.sy.toFixed(1) + ') ' + a.base[j]));
    });
    P.feet.forEach(f => {
      const ph = f.side > 0 ? Math.PI : 0; let lift = 0;
      if (mood === 'dance') lift = 4 * Math.max(0, Math.sin(t / (280 / sp) + ph));
      else if (mood === 'happy' || (mood === 'unlock' && U > 0.34)) lift = 2.5 * Math.max(0, Math.sin(t / (150 / sp) + ph));
      else if (mood === 'clean') lift = 1.5 * Math.max(0, Math.sin(t / 225 + ph));
      f.el.setAttribute('transform', lift ? 'translate(0 ' + (-lift).toFixed(2) + ')' : '');
    });
    P.parts.forEach((p, i) => {
      let r = 0; const s = p.side;
      if (p.kind === 'top') {
        const amp = { idle: 4, eat: 3, dance: 14, unlock: 12, happy: 10, sad: 0, clean: 7, dirty: 3, bath: 5, tv: 2, sleep: 0 }[mood];
        const droop = mood === 'sleep' ? 16 : mood === 'sad' ? 14 : mood === 'dirty' ? 6 : 0;
        r = s * droop + amp * Math.sin(t / (mood === 'dance' || mood === 'happy' ? 160 : 520) + (s > 0 ? 1.4 : 0) + i * 0.3);
        if (mood === 'idle' && (t % 3600) < 260) r += s * 10 * Math.sin(Math.PI * (t % 3600) / 260);
      } else {
        const amp = { idle: 10, eat: 8, dance: 22, unlock: 20, happy: 24, sad: 3, clean: 14, dirty: 5, bath: 12, tv: 6, sleep: 2 }[mood];
        r = amp * Math.sin(t / (mood === 'happy' || mood === 'dance' ? 140 : 420) + i);
      }
      p.el.setAttribute('transform', 'rotate(' + r.toFixed(1) + ' ' + p.px.toFixed(1) + ' ' + p.py.toFixed(1) + ') ' + p.base);
    });
    if (!faceKey && P.eyes.length) {
      if (!I.blinkAt || now > I.blinkAt) { I.blinkAt = now + 2200 + Math.random() * 3000; I.blinkT = now; }
      const b = I.blinkT ? (now - I.blinkT) / 160 : 1; const sc = b < 1 ? Math.max(0.08, Math.abs(1 - 2 * b)) : 1;
      P.eyes.forEach(e => e.style.transform = sc < 1 ? 'scaleY(' + sc.toFixed(2) + ')' : '');
    }
    const c = P.c; if (!c || !I.q) return; const m = c.mouth;
    if (I.chomp) { const o = 0.35 + 0.65 * Math.abs(Math.sin(t / 220)); I.chomp.setAttribute('transform', 'translate(' + m.x + ' ' + m.y + ') scale(1 ' + o.toFixed(2) + ') translate(' + (-m.x) + ' ' + (-m.y) + ')'); }
    if (I.food) { const bite = [1, 0.8, 0.6, 0.42][Math.floor((t % 2000) / 500)]; I.food.setAttribute('transform', 'translate(' + (m.x + 8) + ' ' + (m.y + 3 + Math.sin(t / 220)) + ') scale(' + (0.9 * bite).toFixed(2) + ')'); I.q('[data-crumb]').forEach((cr, i) => { const p = ((t % 500) / 500); cr.setAttribute('cx', (m.x + 4 + (i - 1) * 3 * p * 2).toFixed(1)); cr.setAttribute('cy', (m.y + 4 + p * p * 14).toFixed(1)); cr.setAttribute('opacity', (1 - p).toFixed(2)); }); }
    I.q('[data-tear]').forEach(e => e.setAttribute('stroke-dashoffset', (-(t / 40) % 7).toFixed(1)));
    I.q('[data-drop]').forEach((d, i) => { const e = c.eyes[i] || c.eyes[0]; const p = ((t / 700) + i * 0.5) % 1; d.setAttribute('cx', (e.x + (i ? 1 : -1) * (1 + p * 2)).toFixed(1)); d.setAttribute('cy', (e.y + e.r + 22 + p * 10).toFixed(1)); d.setAttribute('opacity', (1 - p).toFixed(2)); });
    I.q('[data-stink]').forEach((s, i) => { const p = ((t / 1800) + i / 3) % 1; s.setAttribute('transform', 'translate(' + ([38, 50, 62][i] + Math.sin(p * TAU) * 2).toFixed(1) + ' ' + (c.head - 2 - p * 12).toFixed(1) + ')'); s.setAttribute('opacity', Math.sin(Math.PI * p).toFixed(2)); });
    I.q('[data-bub]').forEach((b, i) => { const p = ((t / 2200) + i / 5) % 1; b.setAttribute('cx', (26 + i * 12 + Math.sin(p * TAU + i) * 3).toFixed(1)); b.setAttribute('cy', (80 - p * 60).toFixed(1)); b.setAttribute('r', (1.5 + p * 2).toFixed(1)); b.setAttribute('opacity', (p > 0.9 ? (1 - p) * 10 : 1).toFixed(2)); });
    I.q('[data-spk]').forEach((s, i) => { const p = ((t / 900) + i / 4) % 1; const a = i * 1.7 + 0.6; s.setAttribute('transform', 'translate(' + (50 + Math.cos(a) * 34).toFixed(1) + ' ' + (52 + Math.sin(a) * 32).toFixed(1) + ') scale(' + Math.sin(Math.PI * p).toFixed(2) + ') rotate(' + (p * 90).toFixed(0) + ')'); });
    if (I.glow) { I.glow.setAttribute('fill', TV[Math.floor(t / 900) % 4]); I.glow.setAttribute('opacity', (0.12 + 0.06 * Math.sin(t / 130)).toFixed(3)); }
    I.q('[data-z]').forEach((z, i) => { const p = ((t / 2400) + i / 3) % 1; z.setAttribute('x', (60 + p * 18 + Math.sin(p * TAU) * 3).toFixed(1)); z.setAttribute('y', (c.head + 4 - p * 22).toFixed(1)); z.setAttribute('font-size', (6 + p * 6).toFixed(1)); z.setAttribute('opacity', (p < 0.15 ? p / 0.15 : 1 - (p - 0.15) / 0.85).toFixed(2)); });
    I.q('[data-h]').forEach((hh, i) => { const p = ((t / 1600) + i / 2) % 1; hh.setAttribute('transform', 'translate(' + (i ? 74 : 26) + ' ' + (c.head + 8 - p * 24).toFixed(1) + ') scale(' + (0.8 + p * 0.5).toFixed(2) + ')'); hh.setAttribute('opacity', (1 - p).toFixed(2)); });
    I.q('[data-note]').forEach((nn, i) => { const p = ((t / 1400) + i / 2) % 1; nn.setAttribute('x', (i ? 76 + p * 8 : 18 - p * 8).toFixed(1)); nn.setAttribute('y', (c.head + 10 - p * 22).toFixed(1)); nn.setAttribute('opacity', Math.sin(Math.PI * p).toFixed(2)); });
    if (mood === 'unlock' && I.box) {
      const pre = U < 0.22, e = Math.max(0, (U - 0.22) / 0.3);
      I.box.setAttribute('transform', pre ? 'rotate(' + (4 * Math.sin(t / 40)).toFixed(1) + ' 50 94)' : ''); I.box.setAttribute('opacity', (U < 0.5 ? 1 : Math.max(0, 1 - (U - 0.5) / 0.15)).toFixed(2));
      I.lid.setAttribute('transform', pre ? 'rotate(' + (4 * Math.sin(t / 40)).toFixed(1) + ' 50 94)' : 'translate(' + (e * 18).toFixed(1) + ' ' + (-e * 50).toFixed(1) + ') rotate(' + (e * 40).toFixed(1) + ' 50 65)'); I.lid.setAttribute('opacity', pre ? '1' : Math.max(0, 1 - e * 1.4).toFixed(2));
      I.cf.forEach((r, i) => { if (pre || U > 0.8) { r.setAttribute('opacity', '0'); return; } const tau = (U - 0.22) * 3.4, a = -Math.PI / 2 + ((i * 37) % 24 - 12) / 12 * 1.2, sp2 = 40 + (i * 13) % 30; r.setAttribute('x', (50 + Math.cos(a) * sp2 * tau).toFixed(1)); r.setAttribute('y', (66 + Math.sin(a) * sp2 * tau + 60 * tau * tau).toFixed(1)); r.setAttribute('opacity', Math.max(0, 1 - (U - 0.22) / 0.58).toFixed(2)); r.setAttribute('transform', 'rotate(' + (i * 40 + tau * 400).toFixed(0) + ' ' + r.getAttribute('x') + ' ' + r.getAttribute('y') + ')'); });
    }
  }
  window.PlushAnim = { scan, frame, MOODS, FOODS };
})();
