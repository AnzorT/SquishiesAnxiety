// Renovation Catalog round 5: dance-club light pieces. Party bulb + foil ball (simple glow), spinning mirror ball + pinspot,
// RGB laser projector + giant mirror sphere, hologram dancer + plasma coils, LED strip cove, multi-layer light show.
// Loaded after reno-plus3.js; sets RenoDraw.PLUS4 when ready. Catalog edit layer RD.SET4.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS3 && RD.H3 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS4) return;
  const K = X.K, { box, cyl, ball, slab, slabX, arcW, disc, mix, f1 } = K;
  const { rep, rng, n4, P2, plane, planeH, an, atS, BLUR, bbOf, mt, cer, pt } = RD.H3;
  const N = RD.N, em = RD.H.em, NE = K.NEON, PI = Math.PI, CH = '#d5dde2', WH = '#ffffff', SA = X.SA, MODES = RD.MODES || ['Wave', 'Pulse', 'Rainbow', 'Chase'];
  const B = b => b ? ' begin="' + n4(b) + 's"' : '';
  const anD = (a, v, d, b) => '<animate attributeName="' + a + '" values="' + v + '" dur="' + d + 's" calcMode="discrete"' + B(b) + ' repeatCount="indefinite"/>';
  const anK = (a, v, d, kts, b) => '<animate attributeName="' + a + '" values="' + v + '" keyTimes="' + kts + '" dur="' + d + 's"' + B(b) + ' repeatCount="indefinite"/>';
  const nrm = (x, y, z) => { const l = Math.hypot(x, y, z) || 1; return [x / l, y / l, z / l]; };
  const cyc = (arr, k) => { k = ((k % arr.length) + arr.length) % arr.length; return arr.slice(k).concat(arr.slice(0, k), [arr[k]]).join(';'); };
  let UID = 0;

  // ---------- faceted mirror ball, really turning: F discrete frames per tile step, glints from a fixed light environment ----------
  function mball(cx, cy, R, o) { o = o || {}; const F = o.F || 6, cols = o.cols || 18, rows = o.rows || 10, dt = o.dt || 0.09, e = o.e == null ? 0.38 : o.e, ce = Math.cos(e), se = Math.sin(e);
    const env = o.env || [{ d: nrm(-0.6, 0.55, 0.6), c: '#ffffff', p: 26, s: 1.3 }], base = o.base || '#2e335c', hi = o.hi || '#eef2ff', id = 'mb' + (++UID);
    const pr = (ph, th) => { const x = Math.cos(ph) * Math.sin(th), y = Math.sin(ph), z = Math.cos(ph) * Math.cos(th); return [x, y * ce - z * se, y * se + z * ce]; };
    const sc = v => f1(cx + R * v[0]) + ' ' + f1(cy - R * v[1]);
    const gp = 0.11, dph = PI / rows, dth = 2 * PI / cols; let fr = '';
    for (let f = 0; f < F; f++) { let g = '';
      for (let i = 0; i < rows; i++) { const p0 = -PI / 2 + i * dph, pa = p0 + dph * gp, pb = p0 + dph * (1 - gp), pc = p0 + dph / 2;
        for (let j = 0; j < cols; j++) { const t0 = j * dth + f * dth / F, ta = t0 + dth * gp, tb = t0 + dth * (1 - gp), n = pr(pc, t0 + dth / 2); if (n[2] < 0.05) continue;
          const r = [2 * n[2] * n[0], 2 * n[2] * n[1], 2 * n[2] * n[2] - 1]; let col = mix(base, hi, Math.max(0, Math.min(1, 0.14 + 0.3 * (n[1] + 1) / 2 + 0.14 * n[2])));
          env.forEach(L => { const v = Math.max(0, r[0] * L.d[0] + r[1] * L.d[1] + r[2] * L.d[2]), s = Math.min(1, Math.pow(v, L.p) * L.s); if (s > 0.02) col = mix(col, L.c, s); });
          g += '<path d="M' + sc(pr(pa, ta)) + 'L' + sc(pr(pa, tb)) + 'L' + sc(pr(pb, tb)) + 'L' + sc(pr(pb, ta)) + 'Z" fill="' + col + '"/>'; } }
      fr += '<g opacity="' + (f ? 0 : 1) + '">' + (F > 1 ? anD('opacity', rep(F, m => m === f ? 1 : 0).join(';'), n4(F * dt)) : '') + g + '</g>'; }
    const C = ' cx="' + f1(cx) + '" cy="' + f1(cy) + '" r="' + f1(R) + '"';
    const s = '<defs><radialGradient id="' + id + 'r" cx="50%" cy="50%" r="50%"><stop offset="0.6" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#0a0c20" stop-opacity="0.6"/></radialGradient>'
      + '<radialGradient id="' + id + 'h" cx="32%" cy="27%" r="42%"><stop offset="0" stop-color="#fff" stop-opacity="0.5"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient><clipPath id="' + id + 'c"><circle' + C + '/></clipPath></defs>'
      + '<circle' + C + ' fill="#181b38"/><g clip-path="url(#' + id + 'c)">' + fr + '</g><circle' + C + ' fill="url(#' + id + 'r)"/><circle' + C + ' fill="url(#' + id + 'h)"/><circle' + C + ' fill="none" stroke="#151830" stroke-width="' + f1(R * 0.035) + '"/>';
    return { s, T: cols * F * dt }; }
  // light specks thrown round the room on an ellipse (front half bright, back half faint), one lap per ball turn
  const specks = (cx, cy, rx, ry, n, T, cols, sz) => { const path = 'M' + f1(cx - rx) + ' ' + f1(cy) + 'A' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(cx + rx) + ' ' + f1(cy) + 'A' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(cx - rx) + ' ' + f1(cy);
    return rep(n, i => { const b = -n4(T * i / n), c = cols[i % cols.length], s = sz * (0.7 + ((i * 37) % 10) / 18), q = s * 0.28;
      return '<g>' + '<circle r="' + f1(s * 1.1) + '" fill="' + c + '" opacity="0.3"/><path d="M0 ' + f1(-s) + 'L' + f1(q) + ' ' + f1(-q) + 'L' + f1(s) + ' 0L' + f1(q) + ' ' + f1(q) + 'L0 ' + f1(s) + 'L' + f1(-q) + ' ' + f1(q) + 'L' + f1(-s) + ' 0L' + f1(-q) + ' ' + f1(-q) + 'Z" fill="' + c + '"/>'
        + '<animateMotion dur="' + n4(T) + 's" begin="' + b + 's" repeatCount="indefinite" path="' + path + '"/>' + anK('opacity', '1;1;0.12;0.12;1', n4(T), '0;0.44;0.54;0.94;1', b) + '</g>'; }).join(''); };
  // crumpled tin-foil ball (static)
  function foilBall(cx, cy, R, seed) { const Rn = rng(seed), n = 15, id = 'fb' + (++UID);
    const pts = rep(n, i => { const a = i / n * 2 * PI, r = R * (0.86 + Rn() * 0.22); return [cx + Math.cos(a) * r, cy + Math.sin(a) * r]; }), outl = 'M' + pts.map(P2).join('L') + 'Z';
    let s = '<defs><radialGradient id="' + id + 'g" cx="34%" cy="30%" r="75%"><stop offset="0" stop-color="#fbfcfe"/><stop offset="0.5" stop-color="#c3c9d2"/><stop offset="1" stop-color="#737a86"/></radialGradient><clipPath id="' + id + 'c"><path d="' + outl + '"/></clipPath></defs>';
    s += '<path d="' + outl + '" fill="url(#' + id + 'g)"/><g clip-path="url(#' + id + 'c)">';
    rep(18, i => { const a = Rn() * 2 * PI, rr = Rn() * R * 0.8, x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr, s2 = R * (0.18 + Rn() * 0.22), b = Rn() * PI, lit = (x - cx) + (y - cy) < 0;
      s += '<path d="M' + [0, 2.1, 4.2].map(k2 => P2([x + Math.cos(b + k2) * s2, y + Math.sin(b + k2) * s2 * 0.8])).join('L') + 'Z" fill="' + (i % 4 === 0 ? '#ffffff' : lit ? '#e8ecf2' : '#858c97') + '" opacity="' + (i % 4 === 0 ? 0.85 : 0.5) + '"/>'; });
    let d = ''; rep(11, () => { let x = cx + (Rn() - 0.5) * R * 1.4, y = cy + (Rn() - 0.5) * R * 1.4; d += 'M' + f1(x) + ' ' + f1(y); rep(3, () => { x += (Rn() - 0.5) * R * 0.55; y += (Rn() - 0.5) * R * 0.55; d += 'L' + f1(x) + ' ' + f1(y); }); });
    s += '<path d="' + d + '" fill="none" stroke="#565c66" stroke-width="0.32" opacity="0.6"/><path d="' + d + '" transform="translate(0.3 0.3)" fill="none" stroke="#ffffff" stroke-width="0.22" opacity="0.5"/></g>';
    return { s: s + '<path d="' + outl + '" fill="none" stroke="#5f6670" stroke-width="0.45"/>', clip: id + 'c' }; }

  // ---------- ceiling swatches ----------
  // small: clip-on coloured party bulb + foil ball, just a steady soft glow
  function foilLight() { const BC = '#5aa0ff', fb = foilBall(9, 29, 7.4, 'foil6');
    let s = '<defs><radialGradient id="pbG" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="' + BC + '" stop-opacity="0.75"/><stop offset="0.35" stop-color="' + BC + '" stop-opacity="0.32"/><stop offset="1" stop-color="' + BC + '" stop-opacity="0"/></radialGradient>'
      + '<linearGradient id="pbC" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + BC + '" stop-opacity="0.35"/><stop offset="1" stop-color="' + BC + '" stop-opacity="0"/></linearGradient>'
      + '<radialGradient id="pbB" cx="45%" cy="40%" r="60%"><stop offset="0" stop-color="#eef6ff"/><stop offset="0.45" stop-color="#9cc8ff"/><stop offset="1" stop-color="' + BC + '"/></radialGradient></defs>';
    s += '<g>' + an('opacity', '0.86;1;0.86', 3.4) + '<path d="M-23.5 17L-36 60H-4L-16.5 17Z" fill="url(#pbC)"/><circle cx="-20" cy="14" r="24" fill="url(#pbG)"/></g>';
    s += '<rect x="-36" y="-3.4" width="34" height="3.4" rx="1.7" fill="#a3a9b1" stroke="#5f646c" stroke-width="0.5"/><path d="M-35 -2.6H-3" stroke="#e4e8ee" stroke-width="0.6" opacity="0.8"/>';
    s += '<path d="M-27 -5L-23.5 -3.6M-27 1.4L-23.5 0.2" stroke="#2a2b30" stroke-width="1.4" stroke-linecap="round"/><rect x="-23.5" y="-4.6" width="7" height="1.8" rx="0.6" fill="#2a2b30"/><rect x="-23.5" y="-0.6" width="7" height="1.8" rx="0.6" fill="#2a2b30"/><circle cx="-24.6" cy="-1.7" r="1.3" fill="none" stroke="#8a8f98" stroke-width="0.6"/>';
    s += '<rect x="-22.4" y="1.2" width="4.8" height="6" rx="1" fill="#2a2b30"/><rect x="-23" y="6.6" width="6" height="1.7" rx="0.5" fill="#b8bcc4"/>';
    s += '<path d="M-22.4 8.3C-25.6 10 -26.2 15.6 -20 19.6C-13.8 15.6 -14.4 10 -17.6 8.3Z" fill="url(#pbB)" stroke="#3f7fd8" stroke-width="0.4"/><ellipse cx="-21.6" cy="12" rx="1" ry="2.2" fill="#ffffff" opacity="0.75"/>';
    s += '<path d="M9 -4V22.4" stroke="#d8d2c4" stroke-width="0.5"/><rect x="5.6" y="-4" width="6.8" height="3" rx="0.4" fill="#efe3b8" opacity="0.92" transform="rotate(-6 9 -2.5)"/>' + fb.s;
    s += '<g clip-path="url(#' + fb.clip + ')"><circle cx="2" cy="27" r="7.2" fill="' + BC + '" opacity="0.4">' + an('opacity', '0.32;0.45;0.32', 3.4) + '</circle><circle cx="4.6" cy="26" r="1.1" fill="#dff0ff"/></g>';
    return { vb: '-46 -4 92 64', body: s }; }
  // big: 12-inch glass mirror ball turning on its motor, strong pinspot, rays + light specks circling round
  function mirrorLight() { const cx = 0, cy = 34, R = 19, ENV = [{ d: nrm(-0.62, 0.5, 0.6), c: '#ffffff', p: 22, s: 1.5 }, { d: nrm(0.75, 0.15, 0.62), c: '#9cc4ff', p: 16, s: 0.8 }, { d: nrm(0.15, -0.65, 0.74), c: '#ffe08a', p: 16, s: 0.6 }];
    const MB = mball(cx, cy, R, { env: ENV, F: 6, cols: 18, rows: 10, dt: 0.09 }), T = MB.T, Lr = 50;
    const sx = -46, sy = 4, a = Math.atan2(cy - sy, cx - sx), ca = Math.cos(a), sa = Math.sin(a), lx = sx + ca * 6.5, ly = sy + sa * 6.5, px = -sa, py = ca;
    let s = '<defs><radialGradient id="mrH" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fffbe8" stop-opacity="0.75"/><stop offset="0.4" stop-color="#fffbe8" stop-opacity="0.28"/><stop offset="1" stop-color="#fffbe8" stop-opacity="0"/></radialGradient>'
      + '<radialGradient id="mrR" gradientUnits="userSpaceOnUse" cx="0" cy="0" r="' + Lr + '"><stop offset="0.25" stop-color="#ffffff" stop-opacity="0.55"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>'
      + '<linearGradient id="mrB" gradientUnits="userSpaceOnUse" x1="' + f1(lx) + '" y1="' + f1(ly) + '" x2="' + f1(cx) + '" y2="' + f1(cy) + '"><stop offset="0" stop-color="#fffbe8" stop-opacity="0.85"/><stop offset="1" stop-color="#fffbe8" stop-opacity="0.3"/></linearGradient>' + BLUR('mrS', 0.8) + '</defs>';
    s += '<circle cx="' + cx + '" cy="' + cy + '" r="46" fill="url(#mrH)">' + an('opacity', '0.8;1;0.8', 1.6) + '</circle>';
    s += '<g transform="translate(' + cx + ' ' + cy + ')"><g>' + '<animateTransform attributeName="transform" type="rotate" values="0;360" dur="' + n4(T * 1.5) + 's" repeatCount="indefinite"/>' + rep(12, i => { const b = i * PI / 6, w = 0.09; return '<path d="M0 0L' + f1(Math.cos(b - w) * Lr) + ' ' + f1(Math.sin(b - w) * Lr) + 'L' + f1(Math.cos(b + w) * Lr) + ' ' + f1(Math.sin(b + w) * Lr) + 'Z" fill="url(#mrR)" opacity="' + (i % 2 ? 0.55 : 0.9) + '">' + an('opacity', (i % 2 ? '0.35;0.7;0.35' : '0.9;0.55;0.9'), 1.3 + (i % 3) * 0.3) + '</path>'; }).join('') + '</g></g>';
    s += '<g filter="url(#mrS)" opacity="0.6">' + specks(cx, cy, 48, 25, 9, T, ['#ffffff', '#cfe0ff'], 2.2) + '</g>' + specks(cx, cy, 48, 25, 16, T, ['#ffffff', '#dbe8ff', '#fff4c8'], 1.9);
    s += '<path d="M' + f1(lx + px * 2.2) + ' ' + f1(ly + py * 2.2) + 'L' + f1(cx + px * R * 0.8) + ' ' + f1(cy + py * R * 0.8) + 'L' + f1(cx - px * R * 0.8) + ' ' + f1(cy - py * R * 0.8) + 'L' + f1(lx - px * 2.2) + ' ' + f1(ly - py * 2.2) + 'Z" fill="url(#mrB)">' + an('opacity', '0.9;1;0.9', 1.6) + '</path>';
    s += '<path d="M0 -4V8" stroke="#9aa0ae" stroke-width="1.6"/><rect x="-5.5" y="6.5" width="11" height="7" rx="2" fill="#2c2e38" stroke="#16171d" stroke-width="0.5"/><rect x="-4" y="8" width="8" height="1.2" rx="0.6" fill="#4a4d5a"/><path d="M0 13.5V15.6" stroke="#c9cde8" stroke-width="1.2"/><circle cx="3" cy="10.8" r="0.8" fill="#6fe39a">' + an('opacity', '1;0.3;1', 1) + '</circle>';
    s += MB.s;
    s += '<path d="M' + sx + ' -4V' + (sy - 3) + '" stroke="#5f646c" stroke-width="1.2"/><path d="M' + (sx - 4) + ' ' + (sy - 3) + 'H' + (sx + 4) + '" stroke="#5f646c" stroke-width="1.2" stroke-linecap="round"/>';
    s += '<g transform="translate(' + sx + ' ' + sy + ') rotate(' + f1(a * 180 / PI) + ')"><rect x="-6" y="-3.6" width="12" height="7.2" rx="1.6" fill="#2a2b30" stroke="#121317" stroke-width="0.5"/><rect x="-4" y="-3.6" width="1" height="7.2" fill="#3e4048"/><rect x="5.4" y="-3" width="1.6" height="6" rx="0.5" fill="#fffbe8"/><circle cx="7" cy="0" r="2.4" fill="#fffbe8" opacity="0.6"/></g>';
    return { vb: '-58 -4 116 84', body: s }; }
  const SURF4 = { foil: foilLight, mirror: mirrorLight };

  // ---------- laser beams (screen space) ----------
  const RGB = ['#ff3b3b', '#3bff6a', '#3b8bff', '#ffe23b', '#3bf0ff', '#b04bff'];
  // fan: n beams from o, centre angle c0 (deg from straight up), half-spread sp, length L, sweeping +-sw
  const fan = (o, k, F) => { const n = F.n, cols = F.cols || RGB, vals = cyc(cols, F.ci || 0), ang = rep(n, i => (F.c0 + (n > 1 ? (i / (n - 1) - 0.5) * 2 * F.sp : 0)) * PI / 180), L = F.L * k;
    const E = ang.map(a => [o[0] + Math.sin(a) * L, o[1] - Math.cos(a) * L]), c0 = cols[(F.ci || 0) % cols.length], ph = F.ph || 0;
    let glow = '', core = '', dots = '';
    E.forEach((e, i) => { const d = 'M' + P2(o) + 'L' + P2(e);
      glow += '<path d="' + d + '"/>'; core += '<path d="' + d + '"/>';
      dots += '<circle cx="' + f1(e[0]) + '" cy="' + f1(e[1]) + '" r="' + f1(1.5 * k) + '" fill="' + c0 + '">' + an('fill', vals, F.cd || 4, -ph) + '</circle>'; });
    const sheet = n > 1 ? '<path d="M' + P2(o) + 'L' + P2(E[0]) + 'L' + P2(E[n - 1]) + 'Z" fill="' + c0 + '" opacity="0.07">' + an('fill', vals, F.cd || 4, -ph) + '</path>' : '';
    const rot = F.sw ? atS('rotate', [-F.sw, F.sw, -F.sw].map(v => v + ' ' + P2(o)).join(';'), F.dur || 3, -ph) : '';
    return '<g>' + (F.blink ? anD('opacity', F.blink, F.bd || 2.4, -ph) : '') + '<g>' + rot + sheet
      + '<g stroke="' + c0 + '" stroke-width="' + f1(2.8 * k) + '" opacity="0.4" filter="url(#lzb)" stroke-linecap="round">' + an('stroke', vals, F.cd || 4, -ph) + glow + '</g>'
      + '<g stroke="' + c0 + '" stroke-width="' + f1(0.75 * k) + '" stroke-linecap="round">' + an('stroke', vals, F.cd || 4, -ph) + core + '</g>'
      + '<g stroke="#ffffff" stroke-width="' + f1(0.22 * k) + '" opacity="0.8">' + core + '</g>' + dots + '</g></g>'; };

  // ---------- Full-colour RGB laser projector & giant mirror sphere ----------
  N.laserSphere = S => { const G = '#23252e', SY = 152, SR = 24;
    const D = { w: 60, d: 60, round: 1 };
    D.build = P => [cyl(0, 0, 0, 20, 4, '#16171c', mt({ n: 20 })), cyl(0, 4, 0, 15, 3, G, mt({ n: 18 })), arcW(0, 7, 0, 15, 15, 0.9, 0.7, 0, 2 * PI, '#6ac8ff', em({ n: 18 })),
      cyl(0, 7, 0, 3.4, 82, CH, mt({ n: 10, shine: 1 })), cyl(0, 46, 0, 4.8, 3, G, mt({ n: 12 })),
      box(0, 89, 0, 32, 15, 22, '#454a58', mt({ r: 3 })), box(0, 103.4, 0, 33, 1.4, 23, CH, mt({ r: 3 })), slabX(0, 92, 11.2, 22, 0.8, 0.4, '#3a3d48', { noOut: 1 }), slabX(0, 100, 11.2, 22, 0.8, 0.4, '#3a3d48', { noOut: 1 }),
      disc(0, 96.5, 11, 5.2, 1.2, '#0b0c10', mt({ n: 16 })), disc(0, 96.5, 12.2, 3.2, 0.5, '#e8fdff', em({ n: 14 })),
      disc(-11, 101, 11, 1.1, 0.5, '#3bff6a', em()), disc(-8, 101, 11, 1.1, 0.5, '#ff3b3b', em()), disc(-5, 101, 11, 1.1, 0.5, '#3b8bff', em()),
      cyl(0, 104, 0, 4.5, 5, G, mt({ n: 12 })), cyl(0, 109, 0, 1.3, 20, CH, mt({ n: 8 })), cyl(0, 126, 0, 3.2, 3, G, mt({ n: 10 }))];
    D.fx = c => { const p = c.p, k = c.k, o = p(0, 96.5, 12.8), sc = p(0, SY, 0), R = SR * k;
      const MB = mball(sc[0], sc[1], R, { F: 6, cols: 20, rows: 11, dt: 0.08, base: '#262a4c', env: [{ d: nrm(-0.6, 0.55, 0.6), c: '#ffffff', p: 24, s: 1.4 }, { d: nrm(0.7, 0.2, 0.68), c: '#ff5a5a', p: 14, s: 0.9 }, { d: nrm(0.05, -0.7, 0.72), c: '#3bff6a', p: 14, s: 0.9 }, { d: nrm(-0.75, -0.25, 0.6), c: '#3b8bff', p: 14, s: 0.9 }] });
      let f = '';
      f += fan(o, k, { n: 7, c0: -40, sp: 26, L: 104, sw: 22, dur: 3.2, ci: 1, ph: 0, blink: '1;1;1;0.15;1;1;0.15;1', bd: 3.2 });
      f += fan(o, k, { n: 7, c0: 40, sp: 26, L: 104, sw: 22, dur: 3.2, ci: 0, ph: 1.6, blink: '1;0.15;1;1;1;0.15;1;1', bd: 3.2 });
      f += fan(o, k, { n: 4, c0: -96, sp: 12, L: 78, sw: 14, dur: 2.2, ci: 4, ph: 0.7, blink: '0;1;1;0;1;1', bd: 2.4 });
      f += fan(o, k, { n: 4, c0: 96, sp: 12, L: 78, sw: 14, dur: 2.2, ci: 3, ph: 1.9, blink: '1;0;1;1;0;1', bd: 2.4 });
      f += fan(o, k, { n: 2, c0: 0, sp: 9, L: (SY - 96.5 - SR * 0.6) * X.CA, ci: 2, ph: 0 });
      f += MB.s + specks(sc[0], sc[1], R * 2.6, R * 1.15, 18, MB.T, RGB, 1.7 * k);
      const fl = p(0, 0, 14); const un = '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(64 * k) + '" ry="' + f1(64 * k * SA * 0.6) + '" fill="' + RGB[1] + '" opacity="0.18">' + an('fill', cyc(RGB, 0), 4) + '</ellipse>';
      const L = 108 * k; return { defs: BLUR('lzb', 1.3), under: un, front: f, bb: bbOf([[o[0] - L, o[1] - L], [o[0] + L, o[1] + 30 * k], [sc[0] - R * 2.7, sc[1] - R * 1.3], [sc[0] + R * 2.7, sc[1] + R * 1.3]], 4) }; };
    return D; };

  // ---------- Volumetric hologram dancer & ion-plasma lightning coils ----------
  const jag = (a, b, bend, R, n, amp) => { const dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy) || 1, nx = -dy / L, ny = dx / L, cx = (a[0] + b[0]) / 2 + nx * bend, cy = (a[1] + b[1]) / 2 + ny * bend; let d = 'M' + P2(a);
    for (let i = 1; i < n; i++) { const t = i / n, x = (1 - t) * (1 - t) * a[0] + 2 * (1 - t) * t * cx + t * t * b[0], y = (1 - t) * (1 - t) * a[1] + 2 * (1 - t) * t * cy + t * t * b[1], j = (R() - 0.5) * 2 * amp; d += 'L' + f1(x + nx * j) + ' ' + f1(y + ny * j); }
    return d + 'L' + P2(b); };
  const bolt = (a, b, bend, seed, k, o) => { const R = rng(seed), V = rep(4, () => jag(a, b, bend * (0.75 + R() * 0.5), R, o.n || 9, (o.amp || 3.5) * k)), vs = V.join(';'), dd = o.dd || 0.28;
    return '<g>' + anD('opacity', o.strike || '1;0;1;1;0;1;0;0', o.sd || 1.3, o.b) + '<path d="' + V[0] + '" fill="none" stroke="#b48cff" stroke-width="' + f1((o.w || 1) * 2.6 * k) + '" opacity="0.6" filter="url(#hdb)">' + anD('d', vs, dd, o.b) + '</path>'
      + '<path d="' + V[0] + '" fill="none" stroke="#f6f0ff" stroke-width="' + f1((o.w || 1) * 0.6 * k) + '" stroke-linejoin="round">' + anD('d', vs, dd, o.b) + '</path></g>'; };
  N.holoDancer = S => { const CY = '#7ff0ff', LT = '#e8fdff', TX = 44, TZ = -4, TY = 57.5;
    const D = { w: 120, d: 50 };
    D.build = P => { const o = [cyl(0, 0, 0, 26, 4, '#1c1d22', mt({ n: 24 })), arcW(0, 4, 0, 26, 26, 1.2, 0.8, 0, 2 * PI, CY, em({ n: 24 })), cyl(0, 4, 0, 18, 4, '#2b2e36', mt({ n: 22 })), cyl(0, 8, 0, 12, 2, '#14151a', mt({ n: 20 })),
        cyl(0, 10, 0, 7, 1.6, '#bfefff', cer({ n: 18, op: 0.7 })), ball(0, 11, 0, 3, CY, em({ k: 4, sy: 0.5 }))];
      [-1, 1].forEach(s => { const x = s * TX; o.push(box(x, 0, TZ, 16, 6, 16, '#2b2e36', mt({ r: 2 })), cyl(x, 6, TZ, 4.2, 38, '#c87a46', mt({ n: 14 })));
        rep(7, i => o.push(cyl(x, 9 + i * 5, TZ, 4.5, 1, '#8a4f2c', mt({ n: 14 }))));
        o.push(cyl(x, 44, TZ, 2, 3.4, CH, mt({ n: 10 })), ball(x, 46.6, TZ, 10, CH, mt({ sy: 0.36, n: 20, shine: 1 })), cyl(x, 53, TZ, 0.7, 3.4, CH, mt({ n: 6 })), ball(x, 56, TZ, 1.5, '#e9dcff', em({ k: 4 }))); });
      return o; };
    D.fx = c => { const p = c.p, k = c.k, ft = p(0, 15, 0), ln = p(0, 12, 0), top = p(0, 84, 0), tL = p(-TX, TY, TZ), tR = p(TX, TY, TZ);
      const limb = (d, pv, vals) => '<g>' + atS('rotate', vals.split(';').map(v => v + ' ' + pv).join(';'), 1.2) + '<path d="' + d + '" fill="none" stroke="' + CY + '" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" opacity="0.75"/><path d="' + d + '" fill="none" stroke="' + LT + '" stroke-width="0.9" stroke-linecap="round" stroke-linejoin="round"/></g>';
      const fig = '<g id="hdF">' + atS('rotate', '-5 0 0;5 0 0;-5 0 0', 2.4) + '<g>' + atS('translate', '0 0;0 -2.6;0 0;0 -2.6;0 0', 1.2)
        + limb('M-2 -26L-5 -13L-6 0', '-2 -26', '0;-14;0;6;0') + limb('M2 -26L5 -13L6 0', '2 -26', '0;-6;0;14;0')
        + limb('M5 -40L10 -32L12 -24', '5 -40', '-20;-70;-25;-135;-20')
        + '<ellipse cx="0" cy="-33" rx="6.4" ry="9" fill="' + CY + '" fill-opacity="0.42" stroke="' + LT + '" stroke-width="0.9"/><ellipse cx="0" cy="-33" rx="6.4" ry="9" fill="url(#hdS)"/>'
        + limb('M-5 -40L-10 -32L-12 -24', '-5 -40', '20;110;160;110;20')
        + '<g>' + atS('rotate', '-9 0 -44;9 0 -44;-9 0 -44', 1.2) + '<circle cx="-5.2" cy="-56" r="2.7" fill="' + CY + '" fill-opacity="0.5" stroke="' + LT + '" stroke-width="0.8"/><circle cx="5.2" cy="-56" r="2.7" fill="' + CY + '" fill-opacity="0.5" stroke="' + LT + '" stroke-width="0.8"/>'
        + '<circle cx="0" cy="-50" r="6.8" fill="' + CY + '" fill-opacity="0.45" stroke="' + LT + '" stroke-width="0.9"/><circle cx="0" cy="-50" r="6.8" fill="url(#hdS)"/><path d="M-3.4 -50.6q1-1.2 2 0M1.4 -50.6q1-1.2 2 0M-1.6 -47.4q1.6 1.4 3.2 0" fill="none" stroke="' + LT + '" stroke-width="0.8" stroke-linecap="round"/></g>'
        + '</g></g>';
      let f = '<path d="M' + f1(ln[0] - 4 * k) + ' ' + f1(ln[1]) + 'L' + f1(top[0] - 26 * k) + ' ' + f1(top[1]) + 'L' + f1(top[0] + 26 * k) + ' ' + f1(top[1]) + 'L' + f1(ln[0] + 4 * k) + ' ' + f1(ln[1]) + 'Z" fill="url(#hdC)">' + an('opacity', '0.7;1;0.75;0.95;0.7', 2.2) + '</path>';
      f += '<g>' + anD('opacity', '0.95;0.95;0.95;0.45;0.95;0.95;0.95;0.95;0.2;0.9', 3.1) + '<g>' + '<animateTransform attributeName="transform" type="translate" values="0 0;0 0;' + f1(1.4 * k) + ' 0;0 0;0 0;' + f1(-1 * k) + ' 0;0 0" dur="2.7s" calcMode="discrete" repeatCount="indefinite"/>'
        + '<g transform="translate(' + P2(ft) + ') scale(' + n4(k) + ')"><use href="#hdF" filter="url(#hdg)" opacity="0.7"/>' + fig + '</g></g></g>';
      rep(8, i => { const x = (i % 4 - 1.5) * 10, e0 = p(x, 14, i % 2 ? 5 : -5), d = (2.2 + (i % 3) * 0.5).toFixed(1); f += '<circle cx="' + f1(e0[0]) + '" cy="' + f1(e0[1]) + '" r="' + f1(0.7 * k) + '" fill="#e8fdff">' + an('cy', f1(e0[1]) + ';' + f1(e0[1] - 66 * k), d, -i * 0.41) + an('opacity', '0;1;0', d, -i * 0.41) + '</circle>'; });
      [tL, tR].forEach((t, i) => { f += '<circle cx="' + f1(t[0]) + '" cy="' + f1(t[1]) + '" r="' + f1(6 * k) + '" fill="#b48cff" opacity="0.45" filter="url(#hdb)">' + an('opacity', '0.25;0.6;0.3;0.55;0.25', 0.9, -i * 0.3) + an('r', f1(5 * k) + ';' + f1(8 * k) + ';' + f1(5 * k), 1.3, -i * 0.4) + '</circle>'; });
      f += bolt(tL, tR, -34 * k, 'hdx', k, { n: 14, amp: 4, strike: '1;0;1;1;0;0;0;1;0;0', sd: 1.6, w: 1.2 });
      const brs = [[-1, -26, -14], [-1, -14, -26], [-1, -30, 4], [1, 26, -14], [1, 14, -26], [1, 30, 4]];
      brs.forEach(([s, dx, dy], i) => { const t = s < 0 ? tL : tR; f += bolt(t, [t[0] + dx * k, t[1] + dy * k], (i % 2 ? 5 : -5) * k, 'hdb' + i, k, { n: 6, amp: 3, strike: ['0;1;0;1;1;0;0', '1;0;0;1;0;1;0', '0;0;1;0;1;1;0'][i % 3], sd: 1 + (i % 3) * 0.25, b: -i * 0.17, w: 0.8 }); });
      const un = '<g transform="' + planeH(p, 4.4) + '">' + rep(3, j => '<ellipse rx="10" ry="10" fill="none" stroke="#7ff0ff" stroke-width="0.9">' + an('rx', '10;34', 2.4, -j * 0.8) + an('ry', '10;34', 2.4, -j * 0.8) + an('opacity', '0.8;0', 2.4, -j * 0.8) + '</ellipse>').join('') + '</g>';
      const defs = BLUR('hdb', 1.3) + BLUR('hdg', 2.2) + '<linearGradient id="hdC" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#8fe8ff" stop-opacity="0.45"/><stop offset="1" stop-color="#8fe8ff" stop-opacity="0.02"/></linearGradient>'
        + '<pattern id="hdS" width="4" height="2.4" patternUnits="userSpaceOnUse"><rect width="4" height="0.7" fill="#ffffff" opacity="0.35"/><animateTransform attributeName="patternTransform" type="translate" values="0 0;0 -2.4" dur="0.6s" repeatCount="indefinite"/></pattern>';
      return { defs, under: un, front: f, bb: bbOf([[tL[0] - 34 * k, tL[1] - 30 * k], [tR[0] + 34 * k, tR[1] - 30 * k], [(tL[0] + tR[0]) / 2, Math.min(tL[1], tR[1]) - 40 * k], [top[0] - 28 * k, top[1]], p(0, 80, 0)], 4) }; };
    return D; };

  // ---------- Colour-picker LED strip cove kit (wall) ----------
  N.ledCove = S => { const pal = S.pal || NE, mode = MODES.includes(S.st) ? S.st : 'Wave', vals = pal.concat(pal[0]).join(';'), W = 150, Y = 58;
    const off = i => mode === 'Wave' ? -i * 0.22 : mode === 'Rainbow' ? -i * 3 / 12 : mode === 'Chase' ? -i * 0.1 : 0;
    const flick = i => mode === 'Pulse' ? an('opacity', '1;0.25;1', 1.6) : mode === 'Chase' ? an('opacity', '1;0.15;1', 1.2, off(i)) : '';
    return { w: 176, d: 14, mount: 'wall', build: P => [slabX(0, Y, 1, W, 12, 2, '#e4ded2', pt({ r: 1 })), slabX(0, Y, 5, W, 2, 8, '#f1ece2', pt({ r: 1 })), slabX(0, Y + 2, 8.6, W, 7, 1.6, '#fbf8f2', pt({ r: 1 })),
        box(-W / 2 - 1, Y, 4.6, 2.4, 9, 8, '#e4ded2', pt({ r: 1 })), box(W / 2 + 1, Y, 4.6, 2.4, 9, 8, '#e4ded2', pt({ r: 1 })),
        box(W / 2 + 11, Y - 2, 4, 13, 14, 7, '#2c2d31', mt({ r: 2 })), slabX(W / 2 + 4, Y + 4, 3, 6, 1, 1, '#2c2d31', { noOut: 1 })],
      fx: c => { const p = c.p, k = c.k, NS = 12, sw = W / NS; let defs = BLUR('lcb', 3) + BLUR('lcg', 0.9), wash = '', fr = '';
        rep(NS, i => { const gid = 'lcw' + i, sc = an('stop-color', vals, 3, off(i));
          defs += '<linearGradient id="' + gid + '" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="' + pal[0] + '" stop-opacity="0.9">' + sc + '</stop><stop offset="0.4" stop-color="' + pal[0] + '" stop-opacity="0.38">' + sc + '</stop><stop offset="1" stop-color="' + pal[0] + '" stop-opacity="0"/></linearGradient>';
          wash += '<rect x="' + f1(-W / 2 + i * sw - 1.5) + '" y="0" width="' + f1(sw + 3) + '" height="52" fill="url(#' + gid + ')">' + flick(i) + '</rect>'; });
        defs += '<linearGradient id="lcd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + pal[0] + '" stop-opacity="0.55">' + an('stop-color', vals, 3) + '</stop><stop offset="1" stop-color="' + pal[0] + '" stop-opacity="0"/></linearGradient>';
        const un = '<g transform="' + plane(p, -0.3, Y + 12 + 52) + '" filter="url(#lcb)">' + wash + '</g><g transform="' + plane(p, -0.3, Y) + '"><rect x="' + f1(-W / 2) + '" y="0" width="' + W + '" height="12" fill="url(#lcd)" opacity="0.6"/></g>';
        const n = 32; let gl = '', dt = '';
        rep(n, i => { const x = -W / 2 + 2.5 + i * (W - 5) / (n - 1), q = p(x, Y + 9.6, 5.4), j = i * NS / n, fa = an('fill', vals, 3, off(j)) + flick(j);
          gl += '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(2.4 * k) + '" fill="' + pal[i % pal.length] + '">' + fa + '</circle>';
          dt += '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(0.95 * k) + '" fill="' + pal[i % pal.length] + '">' + fa + '</circle><circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(0.4 * k) + '" fill="#ffffff" opacity="0.85"/>'; });
        const a = p(-W / 2, Y + 9.1, 9.5), b = p(W / 2, Y + 9.1, 9.5);
        fr += '<path d="M' + P2(a) + 'L' + P2(b) + '" stroke="' + pal[0] + '" stroke-width="' + f1(0.8 * k) + '" opacity="0.75">' + an('stroke', vals, 3) + '</path><g filter="url(#lcg)" opacity="0.7">' + gl + '</g>' + dt;
        let wh = ''; rep(6, i => { const a0 = i / 6 * 2 * PI - PI / 2, a1 = (i + 1) / 6 * 2 * PI - PI / 2, r = 3.6; wh += '<path d="M0 0L' + f1(Math.cos(a0) * r) + ' ' + f1(Math.sin(a0) * r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(Math.cos(a1) * r) + ' ' + f1(Math.sin(a1) * r) + 'Z" fill="' + NE[i] + '"/>'; });
        fr += '<g transform="' + plane(p, 7.6, Y + 10.5, W / 2 + 11) + '"><g transform="translate(0 4.8)">' + wh + '<circle r="1.5" fill="#ffffff"/><circle r="4.4" fill="none" stroke="' + pal[0] + '" stroke-width="0.7">' + an('stroke', vals, 3) + '</circle></g><rect x="-3.6" y="10" width="7.2" height="1.4" rx="0.7" fill="#4a4d5a"/></g>';
        return { defs, under: un, front: fr, bb: bbOf([p(-W / 2 - 4, Y + 66, 0), p(W / 2 + 18, Y + 66, 0), p(-W / 2 - 4, Y - 6, 10), p(W / 2 + 18, Y - 6, 10)], 2) }; } }; };

  // ---------- Multi-layer laser, halo & pixel light show: truss arch + pixel wall + 3 halo rings + 4 laser heads ----------
  N.ledShow = S => { const pal = S.pal || NE, mode = MODES.includes(S.st) ? S.st : 'Wave', vals = pal.concat(pal[0]).join(';'), TX = 84, TH = 160, HX = [-54, -18, 18, 54], RC = 84, RR = [54, 40, 26];
    const D = { w: 190, d: 44 };
    D.build = P => { const o = [];
      [-1, 1].forEach(s => { const x = s * TX; o.push(box(x, 0, 0, 18, 5, 24, '#2c2d31', mt({ r: 2 })));
        [-5, 5].forEach(dx => [-5, 5].forEach(dz => o.push(cyl(x + dx, 5, dz, 1.1, TH - 5, CH, mt({ n: 6 })))));
        rep(8, i => o.push(box(x, 14 + i * 19, 0, 11, 1.2, 11, CH, mt({ r: 0 })))); });
      o.push(slabX(0, TH, 0, 2 * TX + 14, 8, 11, '#3a3c48', mt({ r: 1 })), slab(0, 14, -11, 150, 134, 3, '#0e0f14', mt({ r: 3 })));
      HX.forEach(x => o.push(box(x, TH - 7, 5, 9, 7, 9, '#1e2028', mt({ r: 2 })), disc(x, TH - 3.5, 9.5, 2.1, 0.6, '#e8fdff', em())));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let un = '', f = '';
      const nx = 15, ny = 13, cw = 9.6, chh = 9.8;
      let g = ''; for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) { const dc = Math.hypot(i - (nx - 1) / 2, (j - (ny - 1) / 2) * 1.05), b = mode === 'Wave' ? -dc * 0.3 : mode === 'Rainbow' ? -(i + j) * 0.14 : mode === 'Chase' ? -i * 0.12 : 0;
        g += '<rect x="' + f1(-nx * cw / 2 + i * cw + 0.8) + '" y="' + f1(j * chh + 0.8) + '" width="' + f1(cw - 1.6) + '" height="' + f1(chh - 1.6) + '" rx="1.4" fill="' + pal[(i + j) % pal.length] + '">' + an('fill', vals, 3, b)
          + (mode === 'Pulse' ? an('opacity', '1;0.2;1', 1.2, -((i + j) % 2) * 0.6) : mode === 'Chase' ? an('opacity', '1;0.15;0.15;1', 1.5, b) : an('opacity', '1;0.55;1', 2.2, b)) + '</rect>'; }
      f += '<g transform="' + plane(p, -9.4, 14 + 134 - 4) + '" opacity="0.88"><g filter="url(#lsg)" opacity="0.55">' + g + '</g>' + g + '</g>';
      const z0 = p(0, TH, 6), zr = p(0, RC + RR[0], 6); f += '<path d="M' + P2(z0) + 'L' + P2(zr) + '" stroke="#9aa3a8" stroke-width="' + f1(0.5 * k) + '"/>';
      let rg = '', rgG = ''; RR.forEach((r, i) => { const L = 2 * PI * r, ca = an('stroke', vals, 3, mode === 'Rainbow' ? -i : -i * 0.3), da = mode === 'Chase' ? ' stroke-dasharray="' + f1(L / 12 * 0.62) + ' ' + f1(L / 12 * 0.38) + '"' : '', dan = mode === 'Chase' ? an('stroke-dashoffset', '0;' + (i % 2 ? '' : '-') + f1(L / 6), 1.6) : '';
        const op = mode === 'Pulse' ? an('opacity', '1;0.2;1', 1.2, -i * 0.25) : mode === 'Wave' ? an('opacity', '1;0.45;1', 1.8, -i * 0.4) : '';
        rgG += '<circle r="' + r + '" fill="none" stroke="' + pal[i % pal.length] + '" stroke-width="5"' + da + '>' + ca + dan + op + '</circle>';
        rg += '<circle r="' + r + '" fill="none" stroke="' + pal[i % pal.length] + '" stroke-width="2"' + da + '>' + ca + dan + op + '</circle><circle r="' + r + '" fill="none" stroke="#ffffff" stroke-width="0.6" opacity="0.8"' + da + '>' + dan + op + '</circle>'; });
      const cm = 2 * PI * RR[0]; rg += '<circle r="' + RR[0] + '" fill="none" stroke="#ffffff" stroke-width="2.6" stroke-linecap="round" stroke-dasharray="' + f1(cm * 0.07) + ' ' + f1(cm * 0.93) + '">' + an('stroke-dashoffset', '0;' + f1(-cm), 2.4) + '</circle>';
      rg += '<circle r="' + RR[2] + '" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-dasharray="' + f1(2 * PI * RR[2] * 0.1) + ' ' + f1(2 * PI * RR[2] * 0.9) + '">' + an('stroke-dashoffset', '0;' + f1(2 * PI * RR[2]), 1.8) + '</circle>';
      f += '<g transform="' + plane(p, 6, RC) + '"><g filter="url(#lsg)" opacity="0.6">' + rgG + '</g>' + rg + '</g>';
      const ends = [];
      HX.forEach((x, i) => { const o = p(x, TH - 3.5, 10.2), cols = rep(pal.length, m => pal[(m + i) % pal.length]);
        f += fan(o, k, { n: 4, c0: 180 + (i - 1.5) * 14, sp: 20, L: 116, sw: 18, dur: 2.4 + i * 0.35, ph: i * 0.6, cols, cd: 3, blink: i % 2 ? '1;1;0;1;1;0' : '1;0;1;1;0;1', bd: 2.6 });
        ends.push([o[0] - 66 * k, o[1] + 118 * k], [o[0] + 66 * k, o[1] + 118 * k]); });
      let tz = ''; [-1, 1].forEach(s => { let d = ''; rep(16, i => { const q = p(s * TX + (i % 2 ? 5 : -5), 6 + i * 9.6, 5.3); d += (i ? 'L' : 'M') + P2(q); }); tz += '<path d="' + d + '" fill="none" stroke="' + CH + '" stroke-width="' + f1(0.6 * k) + '"/>'; });
      { let d = ''; rep(36, i => { const q = p(-TX - 6 + i * (2 * TX + 12) / 35, TH + (i % 2 ? 7 : 1), 5.6); d += (i ? 'L' : 'M') + P2(q); }); tz += '<path d="' + d + '" fill="none" stroke="#6a6f80" stroke-width="' + f1(0.5 * k) + '"/>'; }
      f = tz + f;
      const fl = p(0, 0, 22); un += '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(96 * k) + '" ry="' + f1(96 * k * SA * 0.55) + '" fill="' + pal[0] + '" opacity="0.22">' + an('fill', vals, 3) + '</ellipse>';
      return { defs: BLUR('lzb', 1.2) + BLUR('lsg', 2.2), under: un, front: f, bb: bbOf(ends.concat([p(-TX - 10, TH + 10, 0), p(TX + 10, TH + 10, 0)]), 2) }; };
    return D; };

  // ---------- draw hook: swatch art for the two ceiling lights ----------
  const draw3 = RD.draw;
  RD.draw = (r, o) => { const res = draw3(r, o); if (!res || res._p4) return res; res._p4 = 1;
    try { const f = r.s4 && SURF4[r.s4]; if (f && res.surf) { const A = f(); res.vb = A.vb; res.svg = RD.svgDoc(A.vb, [], A.body); res.src = 'data:image/svg+xml,' + encodeURIComponent(res.svg); } } catch (e) { console.warn('reno plus4', r.id, e); }
    return res; };

  // ---------- catalog edits ----------
  RD.SET4 = {
    'CLB-006': { s4: 'foil', live: 'Soft glow', note: 'A small crumpled tin-foil ball on a string, lit by one clip-on blue party bulb. It just glows.' },
    'CLB-026': { s4: 'mirror', live: 'Spinning ball', note: 'A bigger glass mirror ball that turns on its motor under a strong pinspot. Light rays and sparkles circle the room as it spins.' },
    'CLB-066': { spec: 'laserSphere', live: 'Laser show', note: 'An RGB laser projector fires sweeping beam fans in changing colours. The giant mirror sphere above it spins and throws coloured sparkles round the room.' },
    'CLB-086': { spec: 'holoDancer', live: 'Live hologram', note: 'A hologram dancer grooves on the emitter with a glitchy flicker, while two plasma coils throw lightning across the stage.' },
    'CLB-101': { spec: 'ledCove', note: 'An LED strip hidden in a wall cove washes the wall with colour. Pick a colour set and a pattern.' },
    'CLB-104': { spec: 'ledShow', note: 'A truss arch with a pixel wall, three halo rings and four sweeping laser heads, all in one colour set and pattern.' },
  };
  const edit3 = RD.edit;
  RD.edit = rows => edit3(rows).map(r => RD.SET4[r.id] ? Object.assign({}, r, RD.SET4[r.id]) : r);
  RD.PLUS4 = 1;
})();
