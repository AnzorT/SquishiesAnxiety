// Squad Movies: one cartoon per Movie Room screen tier. Everything is a pure function of movie time t
// (320 x 180 stage), so the player can pause, resume and seek. Sound is a time-stamped score that
// movie-night.js schedules. Picture quality comes from the screen (look(tier)), not from the movie.
(function () {
  if (window.SquadMovies) return;
  if (!document.querySelector('link[data-sm-font]')) { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'https://fonts.googleapis.com/css2?family=Limelight&display=swap'; l.setAttribute('data-sm-font', '1'); document.head.appendChild(l); }
  const cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v)), lerp = (a, b, u) => a + (b - a) * u;
  const E = { lin: x => x, in: x => x * x, out: x => 1 - Math.pow(1 - x, 3), io: x => x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2, back: x => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); } };
  const P = (t, a, b, e = E.out) => e(cl((t - a) / (b - a)));
  const kf = (t, K, e = E.lin) => { if (t <= K[0][0]) return K[0][1]; for (let i = 1; i < K.length; i++) if (t <= K[i][0]) { const a = K[i - 1], b = K[i]; return lerp(a[1], b[1], e((t - a[0]) / ((b[0] - a[0]) || 1))); } return K[K.length - 1][1]; };
  const hop = (t, a, d, h) => (t > a && t < a + d ? Math.sin(Math.PI * (t - a) / d) * h : 0);
  function el(tag, css, parent, html) { const n = document.createElement(tag); if (css) n.style.cssText = css; if (html != null) n.innerHTML = html; if (parent) parent.appendChild(n); return n; }
  const art = (k, v) => 'export/tripo/' + k + '/' + k + '-' + v + '.svg';
  function actor(p, k, w) { const n = el('img', 'position:absolute;left:0;top:0;width:' + w + 'px;height:' + w + 'px;transform-origin:50% 94%;display:none;', p); n.alt = ''; n.draggable = false; n._k = k; n._w = w; n._v = '';
    ['front', 'left', 'right'].forEach(v => { const i = new Image(); i.src = art(k, v); }); return n; }
  function pose(n, s) {
    if (!s) { if (n.style.display !== 'none') n.style.display = 'none'; return; }
    if (n._v !== s.v) { n._v = s.v; n.src = art(n._k, s.v); } const w = n._w, ra = Math.min(90, Math.abs(s.r || 0)) * Math.PI / 180, ly = Math.pow(Math.sin(ra), 2) * w * 0.4; n.style.display = 'block';
    n.style.transform = 'translate(' + (s.x - w / 2).toFixed(2) + 'px,' + (s.y - ly - w * 0.94).toFixed(2) + 'px) rotate(' + (s.r || 0).toFixed(2) + 'deg) scale(' + (s.sx || 1).toFixed(3) + ',' + (s.sy || 1).toFixed(3) + ')'; }
  const put = (n, x, y, k = 1, r = 0, o = 1) => { if (o <= 0.001) { n.style.display = 'none'; return; } n.style.display = 'block'; n.style.opacity = o.toFixed(3); n.style.transform = 'translate(' + x.toFixed(2) + 'px,' + y.toFixed(2) + 'px) translate(-50%,-50%) rotate(' + r.toFixed(2) + 'deg) scale(' + k.toFixed(3) + ')'; };
  const show = (n, on) => { const d = on ? 'block' : 'none'; if (n.style.display !== d) n.style.display = d; };
  const rnd = s => () => { s |= 0; s = (s + 0x6D2B79F5) | 0; let x = Math.imul(s ^ (s >>> 15), 1 | s); x = (x + Math.imul(x ^ (x >>> 7), 61 | x)) ^ x; return ((x ^ (x >>> 14)) >>> 0) / 4294967296; };

  // ---------- sound kit (writes into a recorder Q: tone / noise records with movie time) ----------
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
  function kit(Q) { const I = {
    piano: (t, m, d = 0.3, v = 0.1) => { Q.tone(t, mtof(m), d, { type: 'triangle', vol: v, at: 0.003 }); Q.tone(t, mtof(m) * 1.004, d * 0.8, { vol: v * 0.55, at: 0.003 }); Q.tone(t, mtof(m) * 2, d * 0.3, { vol: v * 0.16, at: 0.002 }); },
    chord: (t, ms, d, v, roll = 0) => ms.forEach((m, i) => I.piano(t + i * roll, m, d, v)),
    thud: (t, v = 0.45) => Q.tone(t, 120, 0.2, { to: 48, slide: 0.12, vol: v, at: 0.002 }),
    tok: (t, v = 0.14) => Q.tone(t, 880, 0.05, { to: 600, slide: 0.04, type: 'triangle', vol: v, at: 0.001 }),
    whistle: (t, f0, f1, d, v = 0.08) => Q.tone(t, f0, d, { to: f1, slide: d, vol: v, at: 0.03 }),
    splat: t => { Q.noise(t, 0.35, { ft: 'lowpass', f: 2200, fTo: 180, vol: 0.38, at: 0.002 }); Q.tone(t, 170, 0.22, { to: 55, slide: 0.18, vol: 0.28 }); },
    crash: (t, v = 0.14) => Q.noise(t, 1.2, { f: 4200, vol: v }),
    whoosh: (t, d = 0.4, v = 0.09) => Q.noise(t, d, { ft: 'bandpass', f: 700, fTo: 3200, q: 1.1, vol: v, at: d * 0.4 }),
    chirp: (t, v = 0.05) => Q.tone(t, 2300, 0.09, { to: 3300, slide: 0.07, vol: v, at: 0.004 }),
    slurp: (t, v = 0.1) => Q.tone(t, 420, 0.28, { to: 1500, slide: 0.24, type: 'triangle', vol: v, at: 0.01 }),
  }; return I; }
  // ragtime: stride bass (low note / chord) + syncopated tune over an 8-bar progression
  const RCH = [[36, 43, [52, 55, 60]], [36, 43, [52, 55, 60]], [41, 36, [53, 57, 60]], [41, 36, [53, 57, 60]], [36, 43, [52, 55, 60]], [45, 40, [55, 61, 64]], [38, 45, [54, 57, 60]], [43, 38, [53, 59, 62]]];
  const RMEL = [
    [[0, 76, .5], [.5, 79, .5], [1, 84, .75], [2, 83, .5], [2.5, 84, .5], [3, 79, 1]],
    [[0, 76, .5], [.5, 77, .5], [1, 78, .5], [1.5, 79, 1], [3, 76, .5], [3.5, 72, .5]],
    [[0, 77, .5], [.5, 81, .5], [1, 84, .75], [2, 81, .5], [2.5, 84, .5], [3, 86, 1]],
    [[0, 84, .5], [.5, 81, .5], [1, 77, .5], [1.5, 81, 1], [3, 80, .5], [3.5, 81, .5]],
    [[0, 79, .5], [.5, 76, .5], [1, 72, .5], [1.5, 76, .5], [2, 79, .75], [3, 84, 1]],
    [[0, 85, .5], [.5, 84, .5], [1, 81, .5], [1.5, 79, .5], [2, 76, .5], [2.5, 79, .5], [3, 81, 1]],
    [[0, 78, .5], [.5, 81, .5], [1, 84, .5], [1.5, 81, .5], [2, 78, .5], [2.5, 74, .5], [3, 72, 1]],
    [[0, 71, .5], [.5, 74, .5], [1, 77, .5], [1.5, 79, 1], [2.5, 83, .5], [3, 84, 1]]];
  function rag(I, t0, t1, B, v, bar0 = 0) {
    for (let b = bar0, t = t0; t < t1 - 0.01; b++, t += 4 * B) { const k = b % 8, ch = RCH[k];
      for (let j = 0; j < 4; j++) { const tj = t + j * B; if (tj >= t1) break; if (j % 2 === 0) I.piano(tj, ch[j / 2], B * 0.95, v * 1.15); else I.chord(tj, ch[2], B * 0.5, v * 0.42); }
      RMEL[k].forEach(([o, m, d]) => { const tm = t + o * B; if (tm < t1) I.piano(tm, m, d * B * 1.15, v * 0.85); }); }
  }
  function sneak(I, t0, t1, B, v) { const W = [45, 48, 52, 51, 50, 49, 48, 47]; let i = 0; for (let t = t0; t < t1 - 0.01; t += B, i++) { I.piano(t, W[i % 8], 0.13, v); if (i % 2) I.piano(t + B / 2, W[i % 8] + 12, 0.08, v * 0.4); } }

  // ---------- picture quality by screen tier ----------
  function look(tier, st, film) {
    const L = { upd() {} }, top = el('div', 'position:absolute;inset:0;pointer-events:none;', st);
    if (tier <= 1) { // wrinkled bedsheet + old projector: gate weave, flicker, grain, scratches, vignette, sheet folds
      film.style.filter = 'blur(0.35px)';
      const folds = el('div', 'position:absolute;inset:-20px;background:linear-gradient(103deg,rgba(0,0,0,0) 0 14%,rgba(0,0,0,0.13) 18%,rgba(255,255,255,0.07) 22%,rgba(0,0,0,0) 27% 52%,rgba(0,0,0,0.11) 57%,rgba(255,255,255,0.06) 61%,rgba(0,0,0,0) 66% 80%,rgba(0,0,0,0.09) 86%,rgba(0,0,0,0) 92%),linear-gradient(8deg,rgba(0,0,0,0) 0 60%,rgba(0,0,0,0.08) 70%,rgba(0,0,0,0) 78%);', top);
      const cv = el('canvas', 'position:absolute;inset:0;width:100%;height:100%;opacity:0.3;mix-blend-mode:overlay;', top); cv.width = 96; cv.height = 54; const cx = cv.getContext('2d'), img = cx.createImageData(96, 54);
      const fl = el('div', 'position:absolute;inset:0;background:#000;opacity:0;', top), sc = [0, 1].map(() => el('div', 'position:absolute;top:0;width:1px;height:180px;background:rgba(250,240,220,0.55);display:none;', top));
      const hair = el('div', 'position:absolute;left:250px;top:120px;width:60px;height:60px;display:none;', top, '<svg viewBox="0 0 60 60" width="60" height="60"><path d="M58 58 C40 50 46 30 30 26 S12 18 6 4" stroke="#1a120a" stroke-width="0.8" fill="none" opacity="0.7"></path></svg>');
      el('div', 'position:absolute;inset:0;background:radial-gradient(ellipse at 50% 50%,rgba(0,0,0,0) 52%,rgba(0,0,0,0.5) 100%);', top);
      let last = 0, hairT = 0;
      L.upd = now => { if (now - last < 83) return; last = now; const d = img.data; for (let i = 0; i < d.length; i += 4) { const g = Math.random() * 255; d[i] = d[i + 1] = d[i + 2] = g; d[i + 3] = 255; } cx.putImageData(img, 0, 0);
        fl.style.opacity = (0.03 + Math.random() * 0.1).toFixed(3);
        film.style.transform = 'translate(' + ((Math.random() - 0.5) * 1.4).toFixed(2) + 'px,' + ((Math.random() - 0.5) * 1.8).toFixed(2) + 'px) rotate(' + ((Math.random() - 0.5) * 0.3).toFixed(2) + 'deg)';
        folds.style.transform = 'translate(' + (Math.sin(now / 2300) * 4).toFixed(1) + 'px,' + (Math.sin(now / 3100) * 2).toFixed(1) + 'px)';
        sc.forEach(s => { const on = Math.random() < 0.28; s.style.display = on ? 'block' : 'none'; if (on) s.style.left = (Math.random() * 320).toFixed(0) + 'px'; });
        if (now > hairT) { hairT = now + 3000 + Math.random() * 5000; hair.style.display = Math.random() < 0.35 ? 'block' : 'none'; } };
    } else if (tier === 2) { // old plasma: scanlines, soft colour bleed, tracking roll, dark rounded edge
      film.style.filter = 'saturate(1.25) blur(0.3px)';
      el('div', 'position:absolute;inset:0;background:repeating-linear-gradient(0deg,rgba(0,0,0,0.2) 0 1px,rgba(0,0,0,0) 1px 3px);', top);
      const roll = el('div', 'position:absolute;left:0;width:100%;height:26px;background:linear-gradient(rgba(255,255,255,0),rgba(255,255,255,0.08),rgba(255,255,255,0));', top);
      el('div', 'position:absolute;inset:0;border-radius:10px;box-shadow:inset 0 0 22px 6px rgba(0,0,0,0.6);', top);
      L.upd = now => { roll.style.top = (((now / 6000) % 1) * 230 - 30).toFixed(1) + 'px'; film.style.transform = Math.random() < 0.01 ? 'translateX(' + ((Math.random() - 0.5) * 3).toFixed(1) + 'px)' : ''; };
    } else if (tier === 4) { // cinema: letterbox bars + a little bloom
      film.style.filter = 'contrast(1.06) saturate(1.1)';
      el('div', 'position:absolute;left:0;top:0;width:100%;height:10px;background:#000;', top); el('div', 'position:absolute;left:0;bottom:0;width:100%;height:10px;background:#000;', top);
    } else if (tier >= 5) { // holo: crisp, rainbow shimmer round the edge, sheen sweep
      film.style.filter = 'contrast(1.04) saturate(1.15) brightness(1.03)';
      const edge = el('div', 'position:absolute;inset:0;', top), sheen = el('div', 'position:absolute;top:-20px;width:60px;height:220px;background:linear-gradient(90deg,rgba(255,255,255,0),rgba(255,255,255,0.14),rgba(255,255,255,0));transform:rotate(18deg);', top);
      L.upd = now => { const h = (now / 20) % 360; edge.style.boxShadow = 'inset 0 0 12px 2px hsla(' + h.toFixed(0) + ',90%,70%,0.55),inset 0 0 3px 1px hsla(' + ((h + 120) % 360).toFixed(0) + ',90%,75%,0.6)'; sheen.style.left = (((now / 5000) % 1) * 520 - 100).toFixed(0) + 'px'; };
    }
    return L;
  }

  // ---------- Tier 1: "The Great Cake Caper" (60 s silent film) ----------
  const FY = 164, W = 60;
  const CARDS = [[3, 6.2, '<div style="font-size:10px;letter-spacing:3px;">THE GREAT</div><div style="font-size:32px;line-height:1.05;margin-top:2px;">CAKE CAPER</div><div style="font-size:7.5px;letter-spacing:2px;margin-top:10px;">STARRING CHEF BUN &middot; FRYBO &middot; CAKEY</div>'],
    [6.2, 8.6, 'Chef Bun baked a birthday cake<br>for Cakey...'], [14.2, 16.4, '...but somebody else<br>could smell frosting!'], [30, 31.6, '<div style="font-size:42px;">HEY!!</div>'],
    [48, 50.4, 'Happy Birthday,<br><span style="font-size:28px;">Cakey!</span>'], [56.2, 60, '<div style="font-size:36px;">THE END</div><div style="font-size:7.5px;letter-spacing:2px;margin-top:8px;white-space:nowrap;">A CUTEFUNNYCREATURES PICTURE</div>']];
  const SCN = [[8.6, 14.2], [16.4, 30], [31.6, 48], [50.4, 56.2]];
  function cakeCaper() {
    const root = el('div', "position:absolute;left:0;top:0;width:320px;height:180px;overflow:hidden;background:#0d0a06;font-family:'Limelight',Georgia,serif;");
    const film = el('div', 'position:absolute;inset:0;filter:sepia(0.85) saturate(0.65) contrast(1.22) brightness(0.96);', root);
    // countdown leader
    const ld = el('div', 'position:absolute;inset:0;display:none;background:#d8cbb0;', film);
    const ldW = el('div', 'position:absolute;left:90px;top:20px;width:140px;height:140px;border-radius:50%;', ld);
    el('div', 'position:absolute;left:159px;top:0;width:1.5px;height:180px;background:#3a2f22;', ld); el('div', 'position:absolute;left:0;top:89px;width:320px;height:1.5px;background:#3a2f22;', ld);
    [140, 112].forEach(d => el('div', 'position:absolute;left:' + (160 - d / 2) + 'px;top:' + (90 - d / 2) + 'px;width:' + d + 'px;height:' + d + 'px;border-radius:50%;border:2px solid #f6efe0;box-sizing:border-box;', ld));
    const ldN = el('div', 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:78px;line-height:1;color:#241b12;', ld, '3');
    // intertitle card
    const cd = el('div', 'position:absolute;inset:0;display:none;background:#100c07;', film);
    el('div', 'position:absolute;left:10px;top:10px;right:10px;bottom:10px;border:1.5px solid #e9dfc6;border-radius:3px;', cd); el('div', 'position:absolute;left:15px;top:15px;right:15px;bottom:15px;border:0.75px solid #e9dfc6;', cd);
    [[16, 16], [304, 16], [16, 164], [304, 164]].forEach(([x, y]) => el('div', 'position:absolute;left:' + (x - 4) + 'px;top:' + (y - 4) + 'px;width:8px;height:8px;background:#e9dfc6;transform:rotate(45deg);', cd));
    const cdT = el('div', 'position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:#f3ebd8;font-size:16px;line-height:1.35;padding:0 24px;', cd); let cdI = -1;
    // the kitchen
    const sc = el('div', 'position:absolute;inset:0;display:none;background:#0d0a06;', film), set = el('div', 'position:absolute;inset:0;', sc);
    el('div', 'position:absolute;left:0;top:0;width:320px;height:138px;background:repeating-linear-gradient(90deg,rgba(70,50,25,0.16) 0 6px,rgba(0,0,0,0) 6px 16px),#bfae8c;', set);
    el('div', 'position:absolute;left:0;top:112px;width:320px;height:26px;background:repeating-linear-gradient(90deg,rgba(40,25,10,0.35) 0 1px,rgba(0,0,0,0) 1px 22px),#8f7656;border-top:3px solid #8a7050;box-sizing:border-box;', set);
    el('div', 'position:absolute;left:0;top:138px;width:320px;height:42px;background:repeating-conic-gradient(#3d3024 0% 25%,#d6c9ae 0% 50%) 0 0/26px 14px;', set);
    el('div', 'position:absolute;left:0;top:138px;width:320px;height:10px;background:linear-gradient(rgba(30,20,10,0.35),rgba(30,20,10,0));', set);
    const win = el('div', 'position:absolute;left:186px;top:20px;width:56px;height:54px;background:linear-gradient(#fbf8f0,#eee6d2);border:3px solid #6b5236;box-sizing:border-box;', set);
    el('div', 'position:absolute;left:23.5px;top:0;width:3px;height:100%;background:#6b5236;', win); el('div', 'position:absolute;left:0;top:22.5px;width:100%;height:3px;background:#6b5236;', win);
    [180, 230].forEach(x => el('div', 'position:absolute;left:' + x + 'px;top:16px;width:18px;height:64px;background:repeating-linear-gradient(90deg,#d9c7a6 0 3px,#c8b38e 3px 6px);border-radius:0 0 8px 8px;', set));
    el('div', 'position:absolute;left:176px;top:13px;width:76px;height:5px;background:#6b5236;border-radius:3px;', set);
    const clk = el('div', 'position:absolute;left:104px;top:24px;width:26px;height:26px;border-radius:50%;background:#f6f0e2;border:2.5px solid #5d4630;box-sizing:border-box;', set);
    const hM = el('div', 'position:absolute;left:10.5px;top:2px;width:1.6px;height:9px;background:#2a2018;transform-origin:50% 100%;', clk), hH = el('div', 'position:absolute;left:10.3px;top:5px;width:2px;height:6px;background:#2a2018;transform-origin:50% 100%;', clk);
    el('div', 'position:absolute;left:26px;top:84px;width:68px;height:4px;background:#6b5236;border-radius:2px;', set);
    [32, 84].forEach(x => el('div', 'position:absolute;left:' + x + 'px;top:88px;width:4px;height:8px;background:#6b5236;', set));
    el('div', 'position:absolute;left:30px;top:68px;width:12px;height:16px;border-radius:3px 3px 2px 2px;background:linear-gradient(90deg,#cfd8d8,#eef3f2 40%,#b9c4c4);border:1px solid #7a8282;box-sizing:border-box;', set);
    const pie = el('div', 'position:absolute;left:0;top:0;width:26px;height:11px;', sc, '<svg viewBox="0 0 26 11" width="26" height="11"><path d="M1 5 L25 5 L22 10.5 L4 10.5Z" fill="#8f8a80"></path><ellipse cx="13" cy="5" rx="12.5" ry="4.2" fill="#d9a866"></ellipse><path d="M4 4.5 Q13 0.5 22 4.5" stroke="#f6e2b8" stroke-width="1.6" fill="none"></path><circle cx="9" cy="4" r="0.9" fill="#a8743a"></circle><circle cx="15" cy="3.4" r="0.9" fill="#a8743a"></circle></svg>');
    // floor lamp
    el('div', 'position:absolute;left:259px;top:157px;width:26px;height:7px;border-radius:50%;background:#4a3826;', set); el('div', 'position:absolute;left:270.5px;top:94px;width:3px;height:66px;background:#4a3826;', set);
    const bulb = el('div', 'position:absolute;left:266px;top:86px;width:12px;height:12px;border-radius:50%;background:#fffbe8;', set);
    const shade = el('div', 'position:absolute;left:0;top:0;width:36px;height:24px;', sc, '<svg viewBox="0 0 36 24" width="36" height="24"><path d="M9 1 L27 1 L35 20 L1 20Z" fill="#ead6a6" stroke="#6b5236" stroke-width="1.2"></path><path d="M13 1 L10 20 M18 1 L18 20 M23 1 L26 20" stroke="#c8ae78" stroke-width="1"></path><path d="M1 20 L35 20" stroke="#6b5236" stroke-width="1.6"></path><path d="M3 21 v2.5 M7 21 v2.5 M11 21 v2.5 M15 21 v2.5 M19 21 v2.5 M23 21 v2.5 M27 21 v2.5 M31 21 v2.5" stroke="#8a7050" stroke-width="1.1"></path></svg>');
    // table
    const tsh = el('div', 'position:absolute;left:118px;top:154px;width:84px;height:10px;border-radius:50%;background:rgba(30,20,10,0.3);', sc);
    const tb = el('div', 'position:absolute;left:0;top:0;width:320px;height:180px;', sc);
    [132, 184].forEach(x => el('div', 'position:absolute;left:' + x + 'px;top:126px;width:4px;height:32px;background:#6b5236;', tb));
    el('div', 'position:absolute;left:124px;top:112px;width:72px;height:22px;border-radius:3px 3px 0 0;background:radial-gradient(circle at 4px 22px,rgba(0,0,0,0) 3.5px,#f2ead8 4px) -4px 0/8px 22px repeat-x;', tb);
    el('div', 'position:absolute;left:124px;top:112px;width:72px;height:4px;border-radius:2px;background:#fbf7ee;box-shadow:0 1px 0 rgba(90,70,40,0.35);', tb);
    // the cake (bottom centre = position)
    const ck = el('div', 'position:absolute;left:0;top:0;width:30px;height:30px;transform-origin:50% 100%;', sc);
    el('div', 'position:absolute;left:-2px;bottom:0;width:34px;height:4px;border-radius:50%;background:#fbf7ee;border:1px solid #b9a98a;box-sizing:border-box;', ck);
    el('div', 'position:absolute;left:2px;bottom:3px;width:26px;height:12px;border-radius:3px 3px 2px 2px;background:#f2b6c2;', ck);
    el('div', 'position:absolute;left:2px;bottom:11px;width:26px;height:5px;border-radius:3px;background:radial-gradient(circle at 2.2px 4px,#fffaf2 2.2px,rgba(0,0,0,0) 2.6px) 0 1px/4.33px 5px repeat-x,linear-gradient(#fffaf2 0 2px,rgba(0,0,0,0) 2px);', ck);
    el('div', 'position:absolute;left:7px;bottom:15px;width:16px;height:9px;border-radius:3px 3px 1px 1px;background:#bfe6d2;', ck);
    el('div', 'position:absolute;left:7px;bottom:20px;width:16px;height:4px;border-radius:2px;background:radial-gradient(circle at 2px 3px,#fffaf2 2px,rgba(0,0,0,0) 2.4px) 0 1px/4px 4px repeat-x,linear-gradient(#fffaf2 0 1.6px,rgba(0,0,0,0) 1.6px);', ck);
    el('div', 'position:absolute;left:13.8px;bottom:24px;width:2.6px;height:7px;background:repeating-linear-gradient(160deg,#fffaf2 0 1.5px,#e88aa0 1.5px 3px);', ck);
    const flame = el('div', 'position:absolute;left:12.6px;bottom:30.5px;width:5px;height:7px;border-radius:50% 50% 50% 50%/62% 62% 38% 38%;background:radial-gradient(circle at 50% 70%,#fffbe0 0 30%,#ffc94a 60%,#ff8a2a);transform-origin:50% 100%;display:none;', ck);
    const bite1 = el('div', 'position:absolute;left:23px;bottom:9px;width:9px;height:9px;border-radius:50%;background:#bfae8c;display:none;', ck), bite2 = el('div', 'position:absolute;left:3.5px;bottom:18.5px;width:7px;height:7px;border-radius:50%;background:#bfae8c;display:none;', ck);
    const cksh = el('div', 'position:absolute;left:0;top:0;width:40px;height:8px;border-radius:50%;background:rgba(30,20,10,0.4);display:none;', sc);
    // the cast
    const shd = [0, 1, 2].map(() => el('div', 'position:absolute;left:0;top:0;width:44px;height:7px;border-radius:50%;background:rgba(30,20,10,0.32);display:none;', sc));
    const chef = actor(sc, 'chefbun', W), fry = actor(sc, 'frybo', W), cak = actor(sc, 'cakey', W), sil = actor(sc, 'chefbun', 120);
    sil.style.filter = 'brightness(0) blur(1.5px)'; sil.style.opacity = '0.4';
    [sil, chef, fry, cak].forEach((n, i) => { n.style.zIndex = i ? 5 : 1; }); [ck, shade, pie].forEach(n => { n.style.zIndex = 6; });
    const peel = el('div', 'position:absolute;left:0;top:0;width:18px;height:10px;z-index:6;display:none;', sc, '<svg viewBox="0 0 18 10" width="18" height="10"><path d="M9 7 C6 2 3 2 1 4 C4 4 6 6 8 8Z M9 7 C12 2 15 2 17 4 C14 4 12 6 10 8Z M8 8 C8 4 9 1 10 1 C10 4 10 6 10 8Z" fill="#f2d65a" stroke="#6b5236" stroke-width="0.7"></path><ellipse cx="9" cy="8.4" rx="2.4" ry="1.4" fill="#d9b23a"></ellipse></svg>');
    const splat = el('div', 'position:absolute;left:0;top:0;width:36px;height:29px;z-index:7;display:none;', sc, '<svg viewBox="0 0 30 24" width="36" height="29"><path d="M15 2 C19 1 20 5 23 4 C27 3 29 8 26 10 C30 12 28 17 24 16 C25 21 20 23 17 20 C14 24 9 22 9 18 C4 20 1 15 4 12 C0 9 3 4 7 6 C8 2 12 0 15 2Z" fill="#7a3a2a" stroke="#2a1a10" stroke-width="1"></path><path d="M11 6 C14 4 18 6 20 8 C23 10 22 14 19 15 C16 17 11 16 9 13 C7 10 8 7 11 6Z" fill="#fbf3e0"></path><circle cx="22" cy="6" r="1.4" fill="#d9a866"></circle><circle cx="6" cy="14" r="1.4" fill="#d9a866"></circle><path d="M10 20 q0 3.5 1.5 3.5 q1.5 0 1.5-3.5" fill="#7a3a2a"></path></svg>');
    const mark = el('div', 'position:absolute;left:0;top:0;font-size:20px;line-height:1;color:#241b12;text-shadow:0 0 2px #fff8e8,0 0 2px #fff8e8;z-index:8;display:none;', sc, '!');
    const hearts = Array.from({ length: 6 }, () => el('div', 'position:absolute;left:0;top:0;font-size:11px;line-height:1;color:#e05a7a;z-index:8;display:none;', sc, '\u2665'));
    const stars = Array.from({ length: 3 }, () => el('div', 'position:absolute;left:0;top:0;font-size:9px;line-height:1;color:#f6d36a;text-shadow:0 0 1px #241b12;z-index:8;display:none;', sc, '\u2726'));
    const dust = Array.from({ length: 6 }, () => el('div', 'position:absolute;left:0;top:0;width:9px;height:9px;border-radius:50%;background:#efe6d4;border:1px solid rgba(90,70,40,0.4);box-sizing:border-box;z-index:4;display:none;', sc));
    const lines = Array.from({ length: 6 }, () => el('div', 'position:absolute;left:0;top:0;width:18px;height:1.5px;border-radius:1px;background:#3a2f22;z-index:4;display:none;', sc));
    const slices = [0, 1].map(() => el('div', 'position:absolute;left:0;top:0;width:20px;height:12px;z-index:8;display:none;', sc, '<svg viewBox="0 0 20 12" width="20" height="12"><ellipse cx="10" cy="10" rx="9.5" ry="2" fill="#fbf7ee" stroke="#b9a98a" stroke-width="0.6"></ellipse><path d="M4 9 L16 9 L16 4 L4 6.5Z" fill="#f2b6c2"></path><path d="M4 6.5 L16 4 L16 2.4 L4 5Z" fill="#fffaf2"></path></svg>'));
    // burn-through + flapping film tail
    const burn = el('div', 'position:absolute;inset:0;display:none;z-index:20;', root), flap = el('div', 'position:absolute;inset:0;display:none;background:#fff8e8;z-index:21;', root), bar = el('div', 'position:absolute;top:0;width:16px;height:180px;background:#2a1e12;', flap);

    const walk = (t, t0, t1, x0, x1, v, amp = 2.5) => { const ph = (t - t0) * 10; return { v, x: lerp(x0, x1, cl((t - t0) / (t1 - t0))), y: FY - Math.abs(Math.sin(ph)) * amp, r: Math.sin(ph) * 3 }; };
    const run = (t, t0, t1, x0, x1) => { const d = x1 > x0 ? 1 : -1, ph = (t - t0) * 19; return { v: d > 0 ? 'right' : 'left', x: lerp(x0, x1, cl((t - t0) / (t1 - t0))), y: FY - Math.abs(Math.sin(ph)) * 5, r: d * 9 + Math.sin(ph) * 2, run: d }; };
    const stand = (v, x, o) => Object.assign({ v, x, y: FY, r: 0 }, o);
    function chefAt(t) {
      if (t >= 8.6 && t < 11) return walk(t, 8.6, 11, -40, 122, 'right');
      if (t >= 11 && t < 11.6) return stand('right', 122, { r: -5 * Math.sin(Math.PI * P(t, 11, 11.6, E.lin)) });
      if (t >= 11.6 && t < 12.6) { const h = hop(t, 11.7, 0.38, 8) + hop(t, 12.1, 0.38, 8); return stand('front', 122, { y: FY - h, sy: 1 + h * 0.008, sx: 1 - h * 0.006 }); }
      if (t >= 12.6 && t < 14.2) return walk(t, 12.6, 14.2, 122, 360, 'right');
      if (t >= 23.8 && t < 24.8) return walk(t, 23.8, 24.8, -40, 112, 'right');
      if (t >= 24.8 && t < 25.6) return stand('front', 112, { r: Math.sin((t - 24.8) * 9) * 4 });
      if (t >= 25.6 && t < 26.3) return walk(t, 25.6, 26.3, 112, 210, 'right');
      if (t >= 26.3 && t < 26.8) return stand('right', 210, { r: 10 * Math.sin(Math.PI * P(t, 26.35, 26.7, E.lin)) });
      if (t >= 26.8 && t < 27.5) return walk(t, 26.8, 27.5, 210, 190, 'left', 1.5);
      if (t >= 27.5 && t < 28.1) return stand('right', 190, { y: FY - hop(t, 27.5, 0.22, 5) });
      if (t >= 28.1 && t < 28.7) return walk(t, 28.1, 28.7, 190, 172, 'left', 1.5);
      if (t >= 28.7 && t < 29.4) return stand('right', 172, { y: FY - hop(t, 28.7, 0.22, 5) });
      if (t >= 29.4 && t < 30) return stand('right', 172, { y: FY - hop(t, 29.5, 0.35, 10) });
      if (t >= 31.6 && t < 33.6) return run(t, 31.6, 33.6, 420, -50);
      if (t >= 33.8 && t < 35.4) return run(t, 33.8, 35.4, -50, 370);
      if (t >= 35.9 && t < 36.85) return run(t, 35.9, 36.85, 380, 176);
      if (t >= 36.85 && t < 37) return stand('left', 176, { r: -8 });
      if (t >= 37 && t < 38.3) { const d = t - 37, k = Math.exp(-d * 6); return stand('left', 176 + 6 * P(t, 37, 37.15), { r: 14 * Math.exp(-d * 3) * Math.cos(d * 9), sx: 1 + 0.1 * k, sy: 1 - 0.1 * k }); }
      if (t >= 38.3 && t < 39.4) return run(t, 38.3, 39.4, 182, 128);
      if (t >= 39.4 && t < 41.8) { const r = t < 40.1 ? kf(t, [[39.4, 0], [39.75, 112], [40.1, 92]], E.io) : t > 41.2 && t < 41.6 ? 92 + Math.sin((t - 41.2) * 32) * 7 : 92; return { v: 'left', x: 128, y: FY - hop(t, 39.4, 0.7, 26) + (t >= 40.1 ? 2 : 0), r }; }
      if (t >= 41.8 && t < 42.6) return { v: t < 42.3 ? 'left' : 'front', x: 128, y: FY, r: kf(t, [[41.8, 92], [42.4, 0]], E.io) };
      if (t >= 42.6 && t < 45) { const ph = t * 12; return { v: 'front', x: kf(t, [[42.6, 128], [43.3, 90], [44, 200], [44.6, 104], [45, 104]], E.io), y: FY - Math.abs(Math.sin(ph)) * 3, r: Math.sin(ph) * 5 }; }
      if (t >= 45 && t < 46.8) return { v: 'front', x: kf(t, [[45, 104], [45.45, 122]], E.out), y: FY - hop(t, 45, 0.45, 12), r: kf(t, [[45, 0], [45.45, 84]], E.in) };
      if (t >= 46.8 && t < 48) return { v: 'front', x: kf(t, [[46.8, 122], [47.2, 112]]), y: FY - (t > 47.2 ? Math.abs(Math.sin((t - 47.2) * Math.PI / 0.4)) * 7 : 0), r: kf(t, [[46.8, 84], [47.2, 0]], E.io) };
      if (t >= 50.4 && t < 56.2) { const h = Math.abs(Math.sin((t - 50.4) * Math.PI / 0.4)) * 5 * (t < 55.2 ? 1 : 0), lf = t >= 55.3 ? Math.sin(t * 40) : 0; return { v: 'front', x: 100, y: FY - h, r: lf * 3, sy: 1 + 0.04 * lf }; }
      return null;
    }
    function fryAt(t) {
      if (t >= 16.4 && t < 19) { const s = (t - 16.4) / 0.52, k = Math.min(4, Math.floor(s)), u = Math.min(1, s - k); return { v: 'left', x: 350 - 30.8 * (k + E.io(u)), y: FY - Math.sin(Math.PI * u) * 9, r: 7 - Math.sin(Math.PI * u) * 4, sx: 0.96 }; }
      if (t >= 19 && t < 19.9) return stand(t < 19.35 ? 'left' : t < 19.7 ? 'right' : 'front', 196);
      if (t >= 19.9 && t < 20.6) return stand('left', 196 - 6 * P(t, 19.9, 20.3), { r: -16 * P(t, 19.9, 20.25) * (1 - P(t, 20.45, 20.6)) });
      if (t >= 20.6 && t < 22.4) { const w = t < 21.8 ? 1 : 1 - P(t, 21.8, 22.2); return stand('front', 190, { r: Math.sin(t * 13) * 6 * w, sx: 1 + 0.04 * Math.sin(t * 26) * w, sy: 1 - 0.04 * Math.sin(t * 26) * w }); }
      if (t >= 22.4 && t < 22.9) return stand('front', 190, { y: FY - hop(t, 22.5, 0.32, 12) });
      if (t >= 22.9 && t < 23.5) return run(t, 22.9, 23.5, 190, 252);
      if (t >= 23.5 && t < 29.35) { const x = kf(t, [[23.5, 252], [26.8, 252], [27.5, 240], [28.1, 240], [28.7, 228]]), sl = (t > 26.8 && t < 27.5) || (t > 28.1 && t < 28.7), d = t - 26.5, tap = d > 0 && d < 0.8 ? Math.sin(d * 30) * 4 * Math.exp(-d * 5) : 0; return stand('front', x, { y: FY - (sl ? Math.abs(Math.sin(t * 22)) * 1.5 : 0), r: tap }); }
      if (t >= 29.35 && t < 30) { const d = t - 29.35, w = d < 0.12 ? -d : 0.12 * Math.exp(-(d - 0.12) * 5) * Math.cos((d - 0.12) * 20); return stand('front', 228, { sx: 1 - w * 0.8, sy: 1 + w }); }
      if (t >= 31.6 && t < 33.2) return run(t, 31.6, 33.2, 290, -50);
      if (t >= 34.1 && t < 35.7) return run(t, 34.1, 35.7, -50, 370);
      if (t >= 35.8 && t < 36.4) return run(t, 35.8, 36.4, -40, 78);
      if (t >= 36.4 && t < 37) return stand('right', 78, { r: t < 36.6 ? 0 : kf(t, [[36.6, -10], [36.8, 12], [37, 0]]) });
      if (t >= 37 && t < 38.2) return stand('front', 78, { y: FY - Math.abs(Math.sin(t * 16)) * 3, r: Math.sin(t * 16) * 4 });
      if (t >= 38.2 && t < 39) return run(t, 38.2, 39, 78, -50);
      if (t >= 41.8 && t < 42.6) return run(t, 41.8, 42.6, -40, 84);
      if (t >= 42.6 && t < 45) { const ph = t * 12 + 1; return { v: 'front', x: kf(t, [[42.6, 84], [43.3, 214], [44, 150], [44.6, 232], [45, 232]], E.io), y: FY - Math.abs(Math.sin(ph)) * 3, r: Math.sin(ph) * 5 }; }
      if (t >= 45 && t < 46.8) return { v: 'front', x: kf(t, [[45, 232], [45.45, 214]], E.out), y: FY - hop(t, 45, 0.45, 12), r: kf(t, [[45, 0], [45.45, -84]], E.in) };
      if (t >= 46.8 && t < 48) return { v: 'front', x: kf(t, [[46.8, 214], [47.2, 220]]), y: FY - (t > 47.2 ? Math.abs(Math.sin((t - 47.0) * Math.PI / 0.4)) * 7 : 0), r: kf(t, [[46.8, -84], [47.2, 0]], E.io) };
      if (t >= 50.4 && t < 56.2) { if (t >= 54.8 && t < 55.5) return stand('left', 220 - 8 * P(t, 54.8, 55.1), { r: -18 * P(t, 54.8, 55.1) * (1 - P(t, 55.35, 55.5)) });
        const h = Math.abs(Math.sin((t - 50.2) * Math.PI / 0.4)) * 5 * (t < 54.8 ? 1 : 0); return stand('front', 220, { y: FY - h, r: t >= 55.5 ? Math.sin(t * 40) * 3 : 0 }); }
      return null;
    }
    function cakAt(t) {
      if (t >= 43.6 && t < 45.2) return walk(t, 43.6, 45.2, 380, 168, 'left');
      if (t >= 45.2 && t < 48) { const d = t - 46.2, q = d > 0 ? 0.2 * Math.exp(-d * 5) * Math.cos(d * 18) : 0, h = t > 46.6 ? Math.abs(Math.sin((t - 46.6) * Math.PI / 0.4)) * 6 : 0; return stand('front', 168, { y: FY - h, sx: 1 + q * 0.7, sy: 1 - q }); }
      if (t >= 50.4 && t < 56.2) { const h = Math.abs(Math.sin((t - 50.3) * Math.PI / 0.4)) * 5 * (t < 55.2 ? 1 : 0); return stand(t >= 55.25 && t < 55.9 ? 'right' : 'front', 160, { y: FY - h, r: t > 55.9 ? Math.sin(t * 40) * 2.5 : 0 }); }
      return null;
    }
    function upd(t) {
      const lead = t >= 0 && t < 3, ci = CARDS.findIndex(c => t >= c[0] && t < c[1]), inS = SCN.some(s => t >= s[0] && t < s[1]);
      show(ld, lead); show(cd, ci >= 0); show(sc, inS);
      if (lead) { const n = 3 - Math.floor(t), f = t % 1; ldN.textContent = String(n); ldW.style.background = 'conic-gradient(rgba(40,30,20,0.38) 0deg ' + (f * 360).toFixed(1) + 'deg,rgba(0,0,0,0) ' + (f * 360).toFixed(1) + 'deg)'; ld.style.background = f < 0.06 ? '#f6efe0' : '#d8cbb0'; }
      if (ci >= 0) { const C = CARDS[ci]; if (cdI !== ci) { cdI = ci; cdT.innerHTML = C[2]; }
        const o = P(t, C[0], C[0] + 0.3) * (ci === CARDS.length - 1 ? 1 : 1 - P(t, C[1] - 0.25, C[1])); cdT.style.opacity = o.toFixed(3);
        cdT.style.transform = ci === 3 ? 'translate(' + (Math.sin(t * 61) * 1.6).toFixed(2) + 'px,' + (Math.cos(t * 53) * 1.6).toFixed(2) + 'px) scale(' + (1 + 0.15 * Math.exp(-(t - 30) * 6)).toFixed(3) + ')' : ''; }
      if (inS) {
        let ir = null, ix = 160, iy = 112; if (t < 9.4) ir = 10 + P(t, 8.6, 9.4, E.in) * 230; else if (t >= 16.4 && t < 16.9) ir = 10 + P(t, 16.4, 16.9, E.in) * 230; else if (t >= 55.6) { ir = 230 * (1 - P(t, 55.6, 56.15, E.in)); ix = 160; iy = 118; }
        sc.style.clipPath = ir == null ? 'none' : 'circle(' + ir.toFixed(1) + 'px at ' + ix + 'px ' + iy + 'px)';
        const quake = t >= 40.1 && t < 40.4 ? Math.sin((t - 40.1) * 70) * 2 * (1 - (t - 40.1) / 0.3) : t >= 46.2 && t < 46.5 ? Math.sin((t - 46.2) * 70) * 1.5 * (1 - (t - 46.2) / 0.3) : 0;
        set.style.transform = quake ? 'translateY(' + quake.toFixed(2) + 'px)' : '';
        hM.style.transform = 'rotate(' + (t * 36).toFixed(1) + 'deg)'; hH.style.transform = 'rotate(' + (120 + t * 3).toFixed(1) + 'deg)';
        const C = chefAt(t), F = fryAt(t), K = cakAt(t);
        pose(chef, C); pose(fry, F); pose(cak, K);
        [C, F, K].forEach((s, i) => { if (!s || Math.abs(s.r || 0) > 60) { show(shd[i], false); return; } const k = 1 - cl((FY - s.y) / 40) * 0.5; put(shd[i], s.x, FY + 1, k, 0, 0.9 * k); });
        const sh = t >= 41.6 && t < 42 ? Math.sin((t - 41.6) * 60) * 2.5 * (1 - (t - 41.6) / 0.4) : 0; tb.style.transform = sh ? 'translateX(' + sh.toFixed(2) + 'px)' : '';
        // chef's shadow on the wall as he comes back
        if (t >= 22.4 && t < 23.9) pose(sil, { v: 'right', x: lerp(-30, 40, P(t, 22.4, 23.8, E.lin)), y: 150, sx: lerp(1.3, 0.9, P(t, 22.4, 23.8)), sy: lerp(1.3, 0.9, P(t, 22.4, 23.8)) }); else pose(sil, null);
        // cake
        let S = null;
        if (C && t >= 8.6 && t < 11) S = { x: C.x + 3, yb: C.y - 53, r: C.r };
        else if (t >= 11 && t < 11.6) { const u = P(t, 11, 11.6, E.io); S = { x: lerp(125, 160, u), yb: lerp(FY - 53, 113, u) - Math.sin(Math.PI * u) * 8 }; }
        else if (t >= 11.6 && t < 41.6) S = { x: 160 + sh, yb: 113 };
        else if (t >= 41.6 && t < 42.7) { const u = P(t, 41.6, 42.7, E.lin); S = { x: 160 + u * 12, yb: 113 - E.out(u) * 200, r: u * 420 }; }
        else if (t >= 45.4 && t < 46.2 && K) { const u = P(t, 45.4, 46.2, E.in); S = { x: K.x, yb: lerp(-40, K.y - 47, u), r: (1 - u) * 200 }; }
        else if (K && t >= 46.2) S = { x: K.x, yb: K.y - 47 * (K.sy || 1), r: K.r || 0, sx: K.sx, sy: K.sy };
        if (S) { show(ck, true); ck.style.transform = 'translate(' + (S.x - 15).toFixed(2) + 'px,' + (S.yb - 30).toFixed(2) + 'px) rotate(' + (S.r || 0).toFixed(1) + 'deg) scale(' + (S.sx || 1).toFixed(3) + ',' + (S.sy || 1).toFixed(3) + ')'; } else show(ck, false);
        show(bite1, t >= 20.3); show(bite2, t >= 55.1);
        if (t >= 50.6) { show(flame, true); flame.style.transform = 'scale(' + (0.9 + 0.15 * Math.sin(t * 31)).toFixed(3) + ',' + (0.9 + 0.2 * Math.sin(t * 23 + 1)).toFixed(3) + ') rotate(' + (Math.sin(t * 17) * 8).toFixed(1) + 'deg)'; } else show(flame, false);
        if (t >= 43.4 && t < 46.2) { const k = P(t, 43.4, 46.2, E.in); put(cksh, kf(t, [[43.4, 180], [44.2, 140], [44.8, 176], [45.4, 168]], E.io), FY + 1, 0.3 + 0.8 * k, 0, 0.3 + 0.6 * k); } else show(cksh, false);
        // lampshade + bulb
        let L = { x: 272, y: 87, r: 0 };
        if (F && t >= 23.5 && t < 23.8) { const u = P(t, 23.5, 23.8, E.io); L = { x: lerp(272, F.x, u), y: lerp(87, F.y - 44, u) - Math.sin(Math.PI * u) * 12, r: u * -20 }; }
        else if (F && t >= 23.8 && t < 29.45) L = { x: F.x - Math.sin((F.r || 0) * Math.PI / 180) * 44, y: F.y - 44 * (F.sy || 1), r: F.r || 0 };
        else if (t >= 29.45 && t < 30) { const d = (t - 29.45) / 0.55; L = { x: 228 + d * 50, y: FY - 44 - E.out(d) * 230, r: d * 720 }; }
        put(shade, L.x, L.y, 1, L.r, 1); bulb.style.boxShadow = t >= 23.5 && t < 30 ? '0 0 10px 5px rgba(255,248,215,0.9)' : 'none';
        // pie, splat, banana peel
        if (t < 36.4) put(pie, 60, 79, 1, 0, 1); else if (F && t < 36.6) put(pie, F.x + 10, F.y - 50, 1, -10, 1);
        else if (t < 37) { const u = P(t, 36.6, 37, E.lin); put(pie, lerp(92, 172, u), lerp(112, 138, u) - Math.sin(Math.PI * u) * 26, 1, u * 300, 1); } else show(pie, false);
        if (C && t >= 37 && t < 38.3) put(splat, C.x - 6, C.y - 24, P(t, 37, 37.1, E.back), 0, 1 - P(t, 37.9, 38.3)); else show(splat, false);
        if (t >= 38.4 && t < 38.75) { const u = P(t, 38.4, 38.75, E.lin); put(peel, lerp(64, 128, u), lerp(126, 161, u) - Math.sin(Math.PI * u) * 18, 1, u * 360, 1); }
        else if (t >= 38.75 && t < 39.4) put(peel, 128, 161, 1, 0, 1); else if (t >= 39.4 && t < 40.1) { const u = P(t, 39.4, 40.1, E.lin); put(peel, lerp(128, 60, u), lerp(161, 30, u) + u * u * 60, 1, -u * 700, 1); } else show(peel, false);
        // marks, hearts, dizzy stars
        let M = null; if (F && t >= 22.5 && t < 23) M = ['!', F.x + 16, F.y - 64, t - 22.5]; else if (C && t >= 24.9 && t < 26.1) M = ['?', C.x + 14, C.y - 64, t - 24.9]; else if (C && t >= 29.55 && t < 30) M = ['!', C.x + 14, C.y - 66, t - 29.55];
        if (M) { if (mark.textContent !== M[0]) mark.textContent = M[0]; put(mark, M[1], M[2], P(M[3], 0, 0.15, E.back), 8, 1); } else show(mark, false);
        hearts.forEach((h, k) => { let on = false, x = 0, y = 0, a = 0;
          if (t >= 20.7 && t < 22.4 && k < 3) { a = ((t - 20.7) * 0.8 + k / 3) % 1; x = 188 + (k - 1) * 9 + Math.sin(a * 6 + k) * 4; y = 106 - a * 42; on = true; }
          else if (t >= 52.8 && t < 55.4) { a = ((t - 52.8) * 0.7 + k / 6) % 1; x = [100, 160, 220][k % 3] + (k > 2 ? 8 : -8) + Math.sin(a * 6 + k) * 4; y = 104 - a * 46; on = true; }
          if (on) put(h, x, y, 0.7 + 0.5 * a, Math.sin(a * 8) * 12, Math.sin(Math.PI * a)); else show(h, false); });
        stars.forEach((s, k) => { if (t >= 40.1 && t < 41.8) { const a = t * 7 + k * 2.1; put(s, 182 + Math.cos(a) * 13, 126 + Math.sin(a) * 4, 1, 0, 1); } else show(s, false); });
        // dust puffs + speed lines behind runners
        const R = [C, F, K].filter(s => s && s.run); dust.forEach((d, i) => { const s = R[Math.floor(i / 3)]; if (!s) { show(d, false); return; } const a = ((t * 5) + (i % 3) / 3) % 1; put(d, s.x - s.run * (10 + a * 20), FY - 3 - a * 6, 0.5 + a * 0.9, 0, 0.7 * (1 - a)); });
        lines.forEach((l, i) => { const s = R[Math.floor(i / 3)]; if (!s) { show(l, false); return; } const j = i % 3; put(l, s.x - s.run * (34 + j * 6), s.y - 18 - j * 10, 1, 0, 0.55 * (0.6 + 0.4 * Math.sin(t * 40 + j))); });
        slices.forEach((n, k) => { const a = 52 + k * 0.4; if (t >= a) put(n, k ? 200 : 120, 144, 1.4 * P(t, a, a + 0.3, E.back), 0, 1); else show(n, false); });
      }
      // burn-through, then the film tail flapping on a white sheet
      if (t >= 58.4 && t < 59.2) { const R = P(t, 58.4, 59.2, E.in) * 280; show(burn, true); burn.style.background = 'radial-gradient(circle at 196px 82px,#fffdf6 0,#fffdf6 ' + R.toFixed(1) + 'px,#ffcf6a ' + (R + 2).toFixed(1) + 'px,#6a3008 ' + (R + 5).toFixed(1) + 'px,rgba(40,20,5,0) ' + (R + 12).toFixed(1) + 'px)'; } else show(burn, false);
      if (t >= 59.2) { show(flap, true); flap.style.opacity = (0.92 + 0.08 * Math.abs(Math.sin(t * 47))).toFixed(3); bar.style.left = (((t * 14) % 1) * 340 - 20).toFixed(1) + 'px'; bar.style.opacity = (0.5 + 0.5 * Math.abs(Math.sin(t * 29))).toFixed(2); } else show(flap, false);
      const lit = t < 0 ? 0 : t >= 59.2 ? 1.25 : t >= 58.4 ? 0.4 + P(t, 58.4, 59.2) * 0.8 : lead ? 0.6 : ci >= 0 ? 0.28 : 0.85;
      return { rgb: '240,220,180', lit };
    }
    return { root, upd };
  }
  function cakeScore(Q) { const I = kit(Q), r = rnd(7);
    [0, 1, 2].forEach(s => Q.tone(s + 0.02, 1000, 0.13, { vol: 0.07 }));
    for (let t = 0; t < 59.2; t += 1 / 12) Q.noise(t, 0.012, { f: 2600, vol: 0.01 + 0.005 * (Math.round(t * 12) % 2) });
    for (let i = 0; i < 160; i++) Q.noise(r() * 59, 0.008, { f: 1200, vol: 0.015 + 0.03 * r() });
    rag(I, 3, 16.4, 0.4, 0.085);
    sneak(I, 16.4, 20.3, 0.3, 0.1); for (let k = 0; k < 5; k++) I.piano(16.4 + k * 0.52 + 0.26, 91, 0.1, 0.05);
    I.slurp(20.3); [72, 76, 79, 83, 84, 83, 79, 76, 72, 76, 79, 83].forEach((m, i) => I.piano(20.7 + i * 0.14, m, 0.3, 0.05));
    I.thud(22.4, 0.35); I.thud(22.75, 0.4); for (let k = 0; k < 8; k++) I.chord(22.55 + k * 0.06, [56, 59, 62, 65], 0.1, 0.04);
    for (let k = 0; k < 5; k++) I.piano(22.9 + k * 0.12, 84 + k * 2, 0.08, 0.05);
    sneak(I, 23.9, 29.3, 0.6, 0.07); I.tok(26.5); I.tok(26.62, 0.1); [27.5, 28.7].forEach(t => I.chord(t, [48, 54, 60, 63], 0.4, 0.09));
    Q.tone(29.05, 300, 0.32, { to: 560, slide: 0.3, type: 'sawtooth', lp: 1400, vol: 0.04, at: 0.05 }); Q.noise(29.4, 0.25, { ft: 'bandpass', f: 2200, q: 0.9, vol: 0.28 }); I.whistle(29.45, 600, 1900, 0.5); I.chord(29.55, [55, 61, 64, 70], 0.5, 0.08);
    I.chord(30, [36, 43, 48, 55], 1.2, 0.1); I.crash(30);
    rag(I, 31.6, 39.4, 0.25, 0.08); [31.6, 33.8].forEach(t => I.whistle(t, 900, 1500, 0.25, 0.05));
    I.whoosh(36.6); I.splat(37); I.whistle(38.4, 1200, 1800, 0.3, 0.05);
    I.whistle(39.4, 420, 1700, 0.35, 0.1); I.thud(40.1, 0.55); Q.noise(40.1, 0.3, { ft: 'lowpass', f: 900, vol: 0.2 }); for (let k = 0; k < 5; k++) I.chirp(40.3 + k * 0.24);
    I.tok(41.2, 0.08); I.tok(41.35, 0.08); I.thud(41.6, 0.4); I.tok(41.6, 0.16); I.whistle(41.6, 500, 2100, 0.9, 0.08);
    for (let t = 41.9; t < 46.2; t += 0.045) Q.noise(t, 0.04, { ft: 'bandpass', f: 1600, q: 0.8, vol: 0.025 + 0.07 * (t - 41.9) / 4.3 });
    I.whistle(45.4, 2000, 520, 0.8, 0.08); I.thud(45.45, 0.3); I.thud(45.5, 0.3);
    I.crash(46.2, 0.16); I.chord(46.2, [48, 55, 60, 64, 67, 72], 0.9, 0.08, 0.02); Q.tone(46.2, 200, 0.3, { to: 620, slide: 0.25, vol: 0.12 });
    rag(I, 46.4, 48, 0.4, 0.08);
    [[0, 67, .75], [.75, 67, .25], [1, 69, 1], [2, 67, 1], [3, 72, 1], [4, 71, 2]].forEach(([o, m, d]) => { I.piano(48.3 + o * 0.32, m + 12, d * 0.32 + 0.1, 0.08); I.piano(48.3 + o * 0.32, m, d * 0.32, 0.04); });
    rag(I, 50.4, 55.6, 0.4, 0.085, 4); I.slurp(55.1, 0.08); [84, 81, 79, 76, 72, 76, 79].forEach((m, i) => I.piano(55.4 + i * 0.08, m, 0.1, 0.06));
    I.chord(56.2, [43, 53, 59, 62, 67], 0.7, 0.07, 0.04); I.chord(56.9, [36, 48, 55, 60, 64, 72], 1.6, 0.08, 0.04);
    Q.noise(58.4, 0.8, { ft: 'lowpass', f: 400, fTo: 3000, vol: 0.06, at: 0.5 });
    for (let t = 59.2; t < 60; t += 1 / 14) Q.noise(t, 0.015, { f: 1200, vol: 0.06 });
  }
  const beatsOf = S => t => { for (const [a, b, B] of S) if (t >= a && t < b) { const x = (t - a) / B; return { n: Math.floor(x), ph: x - Math.floor(x), amp: B < 0.3 ? 1 : 0.7 }; } return null; };

  const list = [
    { id: 'cake', tier: 1, title: 'The Great Cake Caper', dur: 60, old: true, mk: cakeCaper, score: cakeScore,
      beat: beatsOf([[3, 16.4, 0.4], [16.4, 20.3, 0.6], [23.9, 29.3, 0.6], [31.6, 39.4, 0.25], [46.4, 48, 0.4], [50.4, 55.6, 0.4]]),
      cues: [[20.6, 'laugh'], [24.3, 'laugh'], [27.7, 'laugh'], [29.6, 'gasp'], [37.1, 'laugh'], [39.7, 'laugh'], [41.8, 'gasp'], [46.4, 'cheer'], [53.5, 'cheer'], [55.4, 'laugh'], [59.3, 'laugh']] },
    { id: 'moonpie', tier: 2, title: 'Who Ate the Moon Pie?', dur: 120 },
    { id: 'lantern', tier: 3, title: 'The Lantern of Lost Woods', dur: 180 },
    { id: 'trek', tier: 4, title: 'Squad Trek: Mission to Planet Sprinkle', dur: 240 },
    { id: 'musical', tier: 5, title: 'Squish Squad: The Musical', dur: 300 }];
  function record(mv) { if (mv._rec) return mv._rec; const R = []; const Q = { tone: (t, f, d, o) => R.push([t, 't', f, d, o || {}]), noise: (t, d, o) => R.push([t, 'n', d, o || {}]) }; if (mv.score) mv.score(Q); R.sort((a, b) => a[0] - b[0]); return (mv._rec = R); }
  const def = (id, o) => { const m = list.find(x => x.id === id); if (m) { Object.assign(m, o); m._rec = null; } };
  window.SquadMovies = { list, look, record, def };
})();
