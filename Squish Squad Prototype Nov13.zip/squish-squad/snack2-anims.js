// Snack Shack, the 11 new creatures (Nov 9, user: 'add 11 more creatures to snack shack ... now lets focus on snack shack'): Frankie (hot dog),
// Corny (popcorn), Peppi (pizza), Nori (rice ball), Sunny (soft-boiled egg that rolls), Toco (taco), Churro, Khinki (khinkali), Maki (sushi), Noodle (ramen cup),
// Flossie (cotton candy). Same recipe as the first nine (snack-anims / snack-pokes / snack-eats): the natural look, personality cards, own happy /
// surprised / squish / habit / squeeze reaction, a signature dance made of what only their body can do, 9 poke spots and all 20 foods, each with
// its own parts (the channels below are drawn by snack-3d.js). pitch: NEGATIVE = head down.
//   slip / hug (Frankie's sausage slides, bun squeezes), pop / cfz (Corny's kernels jump / fizz), pull / flop (Peppi's cheese strings / tip),
//   ume / nwr (Nori's salmon flakes hop - was his plum - / jacket slides), cap / wob / rl (Sunny's shell cap lifts like a hat, her yolk wobbles, she rolls: rl = roll angle in degrees), snap (Toco's shell), cork (Churro's
//   ridges corkscrew), kt / knot (Khinki's pleats twist, his knot flicks), veg (Maki's veggies pop up), slurp / lid (Noodle: noodles slurp up / the chopsticks lift a pinch of noodles (+) or dip (-)), fluff / swirl (Flossie's floss).
(function () {
  const CH = { slip: 0, hug: 0, pop: 0, cfz: 0, pull: 0, flop: 0, ume: 0, nwr: 0, wob: 0, cap: 0, rl: 0, snap: 0, cork: 0, kt: 0, knot: 0, veg: 0, slurp: 0, lid: 0, fluff: 0, swirl: 0 };
  const KEYS = ['frankie', 'corny', 'peppi', 'nori', 'sunny', 'toco', 'churro', 'khinki', 'maki', 'noodle', 'flossie'];
  const preset = R => { const P = R.PRE; if (!P || P.mustard) return; Object.assign(P, {
    mustard: { n: 5, sp: 18, vy: -16, g: 70, life: 900, r: [0.7, 1.2], col: ['#ffd43b', '#ffc21a', '#ffe27a'], kind: 'drop' },
    popk: { n: 4, sp: 26, vy: -30, g: 90, life: 1100, r: [1.5, 2.3], col: ['#fffdf0', '#ffeaa8', '#fff3c4'], kind: 'puff' },
    cheese: { n: 5, sp: 16, vy: -10, g: 80, life: 900, r: [0.8, 1.3], col: ['#ffd45c', '#ffc63a', '#ffe27a'], kind: 'drop' },
    rice: { n: 6, sp: 18, vy: -14, g: 80, life: 900, r: [0.5, 0.9], col: ['#ffffff', '#f6f2e8'], kind: 'dot' },
    floss: { n: 5, sp: 14, vy: -10, g: 10, life: 1500, r: [1.2, 2.2], col: ['#ffc6e2', '#c4e6ff', '#fff0f7'], kind: 'puff' },
    broth: { n: 5, sp: 18, vy: -18, g: 80, life: 800, r: [0.6, 1.1], col: ['#f0b25a', '#ffd79a'], kind: 'drop' },
    pepper: { n: 6, sp: 16, vy: -14, g: 70, life: 900, r: [0.4, 0.7], col: ['#3e3028', '#5a4a3e'], kind: 'dot' },
    lettuce: { n: 4, sp: 16, vy: -12, g: 60, life: 1100, r: [1, 1.6], col: ['#86d24e', '#a8e870'], kind: 'leaf' } }); };

  // =====================================================================================================================================
  // personalities, moves, dances
  (function boot() {
    const R = window.RiveRig; if (!R || !R.PETLIB || !R.PETLIB.install || !R.SOFT || !R.SNACKLIB) { setTimeout(boot, 25); return; } if (R.snack2V) return; R.snack2V = 1;
    Object.keys(CH).forEach(k => { if (R.REST[k] == null) R.REST[k] = 0; }); preset(R);
    const { TL, hand, both, o, NOHANDS, jump, shake, swing, steps, jelly, land, install } = R.PETLIB, natF = R.SNACKLIB.natF;
    KEYS.forEach(k => R.SOFT.add(k)); if (R.SNACKLIB.KEYS) KEYS.forEach(k => { if (!R.SNACKLIB.KEYS.includes(k)) R.SNACKLIB.KEYS.push(k); });
    const loopN = (t, n) => Object.assign(t.loop(), { dur: t.t * (n || 3) });
    const eyes = (t, d) => t.to(110, { lx: d * 0.9 }, 'o').e('blink');
    const hopC = (t, h, x) => jump(t, o({ h: h || 7, ant: 150, up: 210, c: 0.16, arm: 46 }, x || {}));
    const yay = (t, d) => t.to(d || 260, { hap: 1, smile: 1, open: 0.3 }, 'io');
    const calm = t => t.to(300, { hap: 0, smile: 0, open: 0, wide: 0, mw: 1, lx: 0, ly: 0, pitch: 0, hyaw: 0 }, 'io');
    const spinR = (t, dur, deg, x) => { const a = t.t; t.to(dur, o({ spin: deg }, x || {}), 'io').to(1, { spin: 0 }, 'l'); return a; };

    const CARDS = {
      frankie: { T: 0.95, b: 1.1, s: 1.05 },  // hot dog: cheerful, huggy
      corny: { T: 0.9, b: 1.15, s: 1 },       // popcorn: excitable, poppy
      peppi: { T: 1.05, b: 1, s: 1.15 },      // pizza: laid-back, floppy
      nori: { T: 1.05, b: 1.05, s: 0.95 },    // rice ball: neat and polite
      sunny: { T: 1.05, b: 1.3, s: 1.05 },    // fried egg: sunny, wobbly
      toco: { T: 0.9, b: 1.15, s: 1 },        // taco: crunchy, sassy
      churro: { T: 1, b: 0.95, s: 1.1 },      // churro: suave dancer
      khinki: { T: 1, b: 1.15, s: 1 },        // khinkali: juicy, proud of his knot
      maki: { T: 0.95, b: 1, s: 1 },          // sushi: zen, rolls
      noodle: { T: 1, b: 1.05, s: 1.05 },     // ramen: warm, slurpy
      flossie: { T: 1.1, b: 1.25, s: 1.2 },   // cotton candy: dreamy, floaty
    };

    const MOVES = {
      // ===== Frankie (hot dog: the bun hugs, the sausage slides) =====
      frankie: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(260, { hug: -0.7, sq: 0.06, armL: 22, armR: 22 }, 'io').to(220, { hug: 0.4, sq: -0.04 }, 'o').e('emit', 'mustard', 'head', 3).to(200, { hug: 0 }, 'io');    // hugs his sausage ...
          hopC(t, 7, { chain: true, air: { slip: 0.35 }, fall: { slip: 0 } }); land(t, 0.06, 2, 220); hopC(t, 8, { air: { slip: -0.35 }, fall: { slip: 0 } });       // ... and hops (it slides)
          return loopN(t.rest(300)); })(), 'Happy', 'Gives his sausage a big bun hug (a squirt of mustard), then hops so it slides back and forth.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, sq: 0.08 }, 'o').to(220, { slip: 1.1, x: -2, tilt: -4, sq: -0.06, armL: 40, armR: 60 }, 'o')                // the sausage shoots out
            .wait(300).to(300, { lx: 0.9, hyaw: 0.22 }, 'io').wait(250);
          t.to(320, o(hand(1, 6, -6), { armR: 60, slip: 0.25, sq: 0 }), 'io').to(200, { slip: 0, x: 0, tilt: 0 }, 'o').e('emit', 'mustard', 'head', 2)                     // pushes it back in
            .to(320, o(NOHANDS, { lx: 0, hyaw: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1, armL: 0, armR: 0 }), 'io').wait(250);
          return t.rest(400).done(); })(), 'Surprised', 'His sausage shoots out of the bun - he stares at it, pushes it back in with a paw, phew.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.42, hug: -1, hap: 0.9, armL: 22, armR: 22 }, 'io').wait(250);
          t.to(140, { sq: -0.16, hug: 0.6, slip: 0.4, hap: 0, smile: 1, open: 0.3 }, 'o').e('emit', 'mustard', 'head', 3); jelly(t, 0.5, 3, 260, 'slip'); jelly(t, 0.06, 2, 240);
          t.to(260, { hug: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io'); return loopN(t); })(), 'Squish', 'The bun squeezes the sausage, then it springs back and the sausage wobbles.'],
        quirk: [(() => { const t = TL();
          t.to(300, { hug: 1, pitch: -0.12, ly: 0.7 }, 'io').wait(450).e('blink');                                                                                     // opens his bun to check ...
          t.to(260, { hug: -0.7, sq: 0.06, close: 0.7, smile: 1, armL: 30, armR: 30 }, 'io').osc(1200, 3, { x: 0.6, slip: 0.12 }, { x: -0.6, slip: -0.12 }, 's')       // ... then hugs it snug
            .to(400, { hug: 0, sq: 0, close: 0, pitch: 0, ly: 0, x: 0, slip: 0, armL: 0, armR: 0, hap: 1 }, 'io');
          return t.wait(300).rest(450).done(); })(), 'Snug check', 'Opens his bun to check on his sausage, then hugs it snug and rocks it.'],
        press: { hug: -0.6 }, rel: { dur: 1100, k: { sq: [[0, 0], [110, -0.16, 'o'], [250, 0.08, 'io'], [400, -0.03, 'io'], [560, 0, 'io']], slip: [[0, 0], [130, 0.5, 'o'], [420, -0.2, 'io'], [700, 0, 'io']], smile: [[0, 0], [150, 1, 'o'], [800, 1], [1100, 0, 'io']] }, em: [['mustard', 'head', 3]] },
      },
      // ===== Corny (popcorn bucket: kernels pop) =====
      corny: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(200, { cfz: 1 }, 'io').wait(350).to(150, { pop: 1.1, sq: -0.08, cfz: 0.4 }, 'o').e('emit', 'popk', 'head', 3).to(420, { pop: 0, sq: 0, cfz: 0 }, 'i');    // fizz ... pop!
          hopC(t, 7, { chain: true, air: { pop: 0.6 }, fall: { pop: 0 } }); land(t, 0.06, 2, 220); hopC(t, 8, { air: { pop: 0.9 }, fall: { pop: 0 }, ev: [['emit', 'popk', 'head', 2]] });
          return loopN(t.rest(300)); })(), 'Happy', 'Fizzes with excitement, her popcorn pops up, then bouncy hops that toss the kernels.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(70, { wide: 1, open: 0.6, mw: 0.6, pop: 1.5, sq: -0.12, lift: 3, armL: 60, armR: 60 }, 'o').e('emit', 'popk', 'head', 6)                       // everything pops at once
            .to(520, { pop: 0, lift: 0, sq: 0.06 }, 'i').to(200, { sq: 0 }, 'io');
          t.to(300, { pitch: -0.14, ly: 0.8 }, 'io').wait(500).to(300, { pitch: 0, ly: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1, armL: 0, armR: 0 }, 'io').wait(200);      // checks her bucket
          return t.rest(400).done(); })(), 'Surprised', 'Every kernel pops at once - then she peeks into her bucket to check they all came back.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(300, { sq: 0.4, pop: 0.4, hap: 0.9, armL: 22, armR: 22 }, 'io').wait(250);
          t.to(120, { sq: -0.16, pop: 1.2, hap: 0, smile: 1, open: 0.4 }, 'o').e('emit', 'popk', 'head', 3).to(420, { pop: 0 }, 'i'); jelly(t, 0.08, 3, 240);
          t.to(200, { armL: 0, armR: 0, smile: 0, open: 0 }, 'io'); return loopN(t); })(), 'Squish', 'Squashed down, then she springs back and her popcorn pops up and rains back in.'],
        quirk: [(() => { const t = TL();
          t.to(320, { armR: 150, ly: -0.8, pitch: 0.06 }, 'io').wait(200).to(160, { armR: 140, pop: 0.3 }, 'o').to(160, { pop: 0 }, 'i');                               // takes one of her own kernels ...
          t.to(300, o(hand(1, 12, -15), { armR: 22, ly: 0.2, pitch: 0, open: 0.4 }), 'io').to(140, { open: 0 }, 'o').osc(900, 4, { puff: 0.35 }, { puff: 0 }, 'l').e('emit', 'crumb', 'mouth', 2) // ... munch
            .to(300, o(NOHANDS, { armR: 0, ly: 0, hap: 1, smile: 1, cfz: 0.6 }), 'io').wait(300).to(200, { cfz: 0 }, 'io');
          return t.rest(450).done(); })(), 'Snack break', 'Reaches up, takes one of her own kernels and munches it, fizzing with joy.'],
        press: { pop: 0.4, cfz: 0.6 }, rel: { dur: 1000, k: { sq: [[0, 0], [100, -0.16, 'o'], [240, 0.07, 'io'], [390, -0.02, 'io'], [520, 0, 'io']], pop: [[0, 0], [100, 1.1, 'o'], [560, 0, 'i']], cfz: [[0, 0.6], [400, 0, 'io']] }, em: [['popk', 'head', 4]] },
      },
      // ===== Peppi (pizza slice: cheese strings, floppy tip) =====
      peppi: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(420, { pull: 1, lift: 2.5, sq: -0.06, armL: 40, armR: 40 }, 'o').wait(250).to(220, { pull: 0, lift: 0, sq: 0.06, armL: 10, armR: 10 }, 'i').e('emit', 'cheese', 'head', 2).to(200, { sq: 0 }, 'io');
          swing(t, 1300, 3, { tilt: 6, flop: 0.6, x: 1.2 }, 'io'); return loopN(t.rest(300)); })(), 'Happy', 'A big cheesy stretch (the strings pull from his crust), then a lazy sway that flops his tip.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7 }, 'o').to(200, { flop: -1, sq: -0.1, lift: 3, armL: 55, armR: 55 }, 'o').to(300, { flop: 0.8, lift: 0, sq: 0.05 }, 'io')
            .to(260, { flop: -0.3 }, 'io').to(240, { flop: 0, sq: 0 }, 'io');
          t.to(300, { ly: 0.8, pitch: -0.1 }, 'io').wait(300).to(300, { ly: 0, pitch: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1, armL: 0, armR: 0 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Jumps - his tip flaps back and forth like a floppy slice - then checks it.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.4, flop: 0.9, hap: 0.9, armL: 20, armR: 20, pull: 0.5 }, 'io').e('emit', 'cheese', 'body', 3).wait(250);
          t.to(120, { sq: -0.15, flop: -0.5, pull: 0, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.7, 3, 280, 'flop'); t.to(220, { sq: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed, his tip flops and the cheese stretches; it all wobbles back.'],
        quirk: [(() => { const t = TL();
          t.to(900, { flop: 1, sq: 0.03, close: 0.4 }, 'i').wait(300).e('blink').to(200, { wide: 0.6, close: 0 }, 'o');                          // his tip slowly droops ...
          t.to(200, { ly: -0.9, pitch: 0.06 }, 'io').to(360, { armL: 145, armR: 145, flop: 0.2 }, 'io').to(260, { flop: -0.15 }, 'o').to(320, { flop: 0, armL: 0, armR: 0, wide: 0, ly: 0, pitch: 0, sq: 0, hap: 1, smile: 1 }, 'io'); // ... he props it up
          return t.wait(250).rest(450).done(); })(), 'Floppy tip', 'His tip slowly droops over his head - he looks up and props it back up with both paws.'],
        press: { flop: 0.5, pull: 0.3 }, rel: { dur: 1100, k: { sq: [[0, 0], [110, -0.14, 'o'], [260, 0.06, 'io'], [420, 0, 'io']], flop: [[0, 0.5], [160, -0.6, 'o'], [380, 0.35, 'io'], [600, -0.12, 'io'], [800, 0, 'io']], pull: [[0, 0.3], [300, 0, 'io']] } },
      },
      // ===== Nori (rice ball: polite; the salmon flakes on his top hop (Nov 11: was a plum), the seaweed jacket slides) =====
      nori: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1 });
          t.to(320, { pitch: -0.2, sq: 0.04, close: 0.6 }, 'io').wait(200).to(300, { pitch: 0.04, sq: -0.04, close: 0 }, 'o').to(200, { pitch: 0, sq: 0 }, 'io');          // a polite bow ...
          t.to(150, { ume: 1, open: 0.3 }, 'o').e('emit', 'spark', 'head', 2).to(300, { ume: 0 }, 'i'); hopC(t, 6);                                                      // ... his salmon flakes hop, a little hop
          return loopN(t.rest(300)); })(), 'Happy', 'A polite little bow, the salmon flakes on his head hop up, then a neat little hop.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7 }, 'o').to(200, { nwr: 1, sq: -0.08, lift: 2 }, 'o').to(200, { lift: 0, sq: 0 }, 'i');                           // his jacket slips down!
          t.to(250, { ly: 0.9, pitch: -0.12, blush: 0.8 }, 'io').to(320, o(both(4, 4), { armL: 20, armR: 20 }), 'io').to(300, o(both(4, -2), { nwr: 0, armL: 35, armR: 35 }), 'io') // tugs it back up
            .to(300, o(NOHANDS, { armL: 0, armR: 0, ly: 0, pitch: 0, wide: 0, open: 0, mw: 1, blush: 0.3, smile: 1 }), 'io').wait(200);
          return t.rest(400).done(); })(), 'Surprised', 'His seaweed jacket slips down - he blushes and tugs it back up neatly.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.4, hap: 0.9, armL: 20, armR: 20 }, 'io').e('emit', 'rice', 'body', 4).wait(250);
          t.to(120, { sq: -0.15, ume: 0.7, hap: 0, smile: 1, open: 0.3 }, 'o').to(260, { ume: 0 }, 'i'); jelly(t, 0.08, 3, 240); t.to(200, { armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed, a few rice grains fly, he springs back and his salmon flakes bob.'],
        quirk: [(() => { const t = TL();
          t.to(300, o(both(3, 6), { armL: 18, armR: 18, ly: 0.7, pitch: -0.08 }), 'io').osc(800, 2, { nwr: 0.6 }, { nwr: -0.3 }, 'io').to(200, { nwr: 0 }, 'io')           // straightens his jacket
            .to(300, o(NOHANDS, { armL: 0, armR: 0, ly: 0, pitch: 0 }), 'io').to(200, { pitch: -0.1 }, 'io').to(200, { pitch: 0 }, 'io').to(300, { hap: 1, smile: 1 }, 'io');
          return t.wait(300).rest(450).done(); })(), 'Jacket tug', 'Straightens his seaweed jacket with both paws, smooths it and gives a neat nod.'],
        press: { nwr: 0.3 }, rel: { dur: 1100, k: { sq: [[0, 0], [110, -0.15, 'o'], [250, 0.07, 'io'], [400, -0.02, 'io'], [540, 0, 'io']], ume: [[0, 0], [120, 0.8, 'o'], [400, 0, 'i']], nwr: [[0, 0.3], [300, 0, 'io']], smile: [[0, 0], [150, 1, 'o'], [800, 1], [1100, 0, 'io']] }, em: [['rice', 'body', 3]] },
      },
      // ===== Sunny (soft-boiled egg, no cup, no legs: her shell cap lifts like a hat, the runny yolk wobbles, she rocks and rolls on her round bottom) =====
      sunny: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(320, { cap: 0.8, armR: 120 }, 'o').to(200, { wob: 1 }, 'io').wait(250).to(260, { cap: 0, armR: 0 }, 'i').to(200, { wob: 0 }, 'io');                       // tips her cap ...
          t.osc(900, 2, { rl: -14, x: -4 }, { rl: 14, x: 4 }, 'io').to(240, { rl: 0, x: 0 }, 'io');                                                                      // ... rocks on her round bottom ...
          jump(t, { h: 10, ant: 160, up: 250, c: 0.16, arm: 50, air: { rl: 180 }, fall: { rl: 360 }, ev: [['emit', 'spark', 'head', 2]] }); t.to(1, { rl: 0 }, 'l');     // ... and a happy somersault
          land(t, 0.06, 2, 220); return loopN(t.rest(300), 2); })(), 'Happy', 'Tips her shell cap like a hat (her runny yolk wobbles), rocks on her round bottom, then a happy little somersault.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(70, { wide: 1, open: 0.5, mw: 0.7, cap: 1.1, sq: -0.08, lift: 2 }, 'o').to(200, { wob: 1.3, lift: 0, sq: 0.04 }, 'io').wait(350)              // her cap pops off!
            .to(320, { cap: 0, sq: 0 }, 'i').to(160, { sq: 0.05 }, 'o').to(200, { sq: 0, wob: 0 }, 'io');
          t.to(300, { lx: -0.8 }, 'o').wait(250).to(300, { lx: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io'); return t.rest(400).done(); })(), 'Surprised', 'Her shell cap pops right off in surprise, the yolk jiggles, and it drops back on.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.36, hap: 0.9, armL: 20, armR: 20 }, 'io').wait(250);
          t.to(140, { sq: -0.12, cap: 0.7, wob: 1.5, hap: 0, smile: 1, open: 0.3 }, 'o').to(300, { cap: 0 }, 'i'); jelly(t, 0.08, 3, 240); t.to(400, { wob: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squeezed down flat - her cap pops up and the yolk wobbles - then she springs back.'],
        quirk: [(() => { const t = TL();
          t.to(400, { cap: 0.75, armR: 140, htilt: -4, close: 0.4, smile: 1 }, 'io').wait(150).to(250, { wob: 0.8 }, 'io').to(300, { pitch: -0.12 }, 'io').wait(300).to(300, { pitch: 0 }, 'io') // a polite hat tip and a bow
            .to(360, { cap: 0, armR: 0, htilt: 0, close: 0, wob: 0, hap: 1 }, 'io'); return t.wait(300).rest(450).done(); })(), 'Hat tip', 'Lifts her shell cap like a hat and gives a little bow, her runny yolk peeking out.'],
        press: { cap: 0.3 }, rel: { dur: 1100, k: { sq: [[0, 0], [110, -0.14, 'o'], [260, 0.06, 'io'], [420, 0, 'io']], cap: [[0, 0.3], [120, 0.9, 'o'], [600, 0, 'i']], wob: [[0, 0], [150, 1.2, 'o'], [1100, 0, 'io']] } },
      },
      // ===== Toco (taco: the shell snaps) =====
      toco: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          for (let i = 0; i < 2; i++) t.to(120, { snap: -0.7, sq: 0.04 }, 'o').to(200, { snap: 0.6, sq: -0.03 }, 'o').e('emit', 'lettuce', 'head', 1); t.to(200, { snap: 0, sq: 0 }, 'io');
          hopC(t, 7, { air: { snap: 0.5 }, fall: { snap: 0 } }); return loopN(t.rest(300)); })(), 'Happy', 'Snaps his shell open and shut like happy chomps, lettuce flies, then a hop.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(70, { snap: -0.8, wide: 1, open: 0.4, sq: 0.06 }, 'o').wait(300).to(260, { snap: 0.8, sq: -0.05 }, 'o').e('emit', 'lettuce', 'head', 3).to(300, { snap: 0, sq: 0 }, 'io');
          t.to(300, { lx: -0.8 }, 'o').wait(250).to(300, { lx: 0, wide: 0, open: 0, hap: 1, smile: 1 }, 'io'); return t.rest(400).done(); })(), 'Surprised', 'Snaps shut with a crunch, then pops back open and lettuce flies.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.4, snap: 1.2, hap: 0.9, armL: 20, armR: 20 }, 'io').e('emit', 'lettuce', 'head', 3).wait(250);
          t.to(120, { sq: -0.15, snap: -0.5, hap: 0, smile: 1, open: 0.3 }, 'o').to(260, { snap: 0 }, 'io'); jelly(t, 0.08, 3, 240); t.to(200, { armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Pressed down, his shell bursts open (lettuce flies), then snaps back.'],
        quirk: [(() => { const t = TL();
          t.to(260, { snap: 0.8 }, 'o').to(300, { armR: 140, ly: -0.7, pitch: 0.05 }, 'io').osc(500, 2, { armR: 126 }, { armR: 140 }, 'io').to(260, { armR: 0 }, 'io');          // tucks a leaf back in
          t.to(160, { snap: -0.3 }, 'o').to(240, { snap: 0, ly: 0, pitch: 0, hap: 1, smile: 1 }, 'io'); return t.wait(300).rest(450).done(); })(), 'Filling fix', 'Opens up, tucks a stray lettuce leaf back in, snaps shut - perfect.'],
        press: { snap: -0.5 }, rel: { dur: 1000, k: { sq: [[0, 0], [100, -0.15, 'o'], [240, 0.06, 'io'], [400, 0, 'io']], snap: [[0, -0.5], [120, 0.9, 'o'], [360, -0.25, 'io'], [600, 0, 'io']] }, em: [['lettuce', 'head', 2]] },
      },
      // ===== Churro (suave: the ridges corkscrew) =====
      churro: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(400, { cork: 1, lift: 1, sq: -0.06 }, 'io').to(420, { cork: -1 }, 'io').to(300, { cork: 0, lift: 0, sq: 0 }, 'io').e('emit', 'sugar', 'head', 3); hopC(t, 7);
          return loopN(t.rest(300)); })(), 'Happy', 'Twists like a corkscrew one way then the other, sugar sparkles, then a hop.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7 }, 'o').to(200, { sq: -0.16, lift: 3, armL: 30, armR: 30 }, 'o').e('emit', 'sugar', 'body', 5).to(250, { lift: 0, sq: 0.05 }, 'i').to(200, { sq: 0 }, 'io');
          t.to(300, { lx: 0.8 }, 'o').wait(250).to(300, { lx: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1, armL: 0, armR: 0 }, 'io'); return t.rest(400).done(); })(), 'Surprised', 'Stands up straight in surprise and sugar puffs off him.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.36, hap: 0.9, armL: 20, armR: 20 }, 'io').e('emit', 'sugar', 'body', 4).wait(250);
          t.to(120, { sq: -0.14, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.6, 3, 280, 'cork'); t.to(220, { sq: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'A crunchy squash, a puff of sugar, his ridges twist as he springs back.'],
        quirk: [(() => { const t = TL();
          shake(t, { P: 90, env: [0.5, 1, 1, 0.7, 0.35], head: 0.08, roll: 3, ear: 0, body: 0.6 }); t.e('emit', 'sugar', 'body', 5);                                     // shakes off the extra sugar
          t.to(300, { cork: 0.4, close: 0.6, smile: 1 }, 'io').to(300, { cork: 0, close: 0, hap: 1 }, 'io'); return t.wait(300).rest(450).done(); })(), 'Sugar shake', 'Shakes off the extra sugar like a dog after a bath, then a smug little twist.'],
        press: { cork: 0.4 }, rel: { dur: 1000, k: { sq: [[0, 0], [100, -0.14, 'o'], [240, 0.06, 'io'], [400, 0, 'io']], cork: [[0, 0.4], [150, -0.8, 'o'], [400, 0.4, 'io'], [650, 0, 'io']] }, em: [['sugar', 'head', 3]] },
      },
      // ===== Khinki (khinkali: the pleats twist, the knot flicks, juicy inside) =====
      khinki: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(220, { knot: 0.8, kt: 0.4 }, 'o').to(260, { knot: -0.7, kt: -0.3 }, 'io').to(220, { knot: 0, kt: 0 }, 'io');                                               // flicks his knot like a ponytail
          hopC(t, 7, { chain: true, air: { knot: 0.4 }, fall: { knot: 0 } }); land(t, 0.08, 2, 240); hopC(t, 7, { air: { knot: -0.4 }, fall: { knot: 0 } }); return loopN(t.rest(300)); })(), 'Happy', 'Flicks his knot like a ponytail, then juicy little hops that make it bounce.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(70, { wide: 1, open: 0.5, mw: 0.7, sq: -0.12, lift: 3, kt: 0.8 }, 'o').e('emit', 'broth', 'head', 4).to(240, { lift: 0, sq: 0.06, kt: -0.3 }, 'i').to(260, { sq: 0, kt: 0 }, 'io'); // a squirt of broth!
          t.to(300, { lx: 0.8 }, 'o').wait(250).to(300, { lx: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io'); return t.rest(400).done(); })(), 'Surprised', 'Jumps - his pleats twist tight and a squirt of broth shoots out of his knot.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.42, kt: 0.6, hap: 0.9, armL: 22, armR: 22 }, 'io').e('emit', 'broth', 'head', 5).wait(250);                     // so juicy: broth squirts out the top
          t.to(120, { sq: -0.15, kt: -0.3, hap: 0, smile: 1, open: 0.3 }, 'o'); jelly(t, 0.09, 3, 260); t.to(220, { kt: 0, armL: 0, armR: 0, smile: 0, open: 0 }, 'io'); return loopN(t); })(), 'Squish', 'Squeezed, a juicy squirt of broth shoots out of his knot; a doughy wobble back.'],
        quirk: [(() => { const t = TL();
          t.to(320, { armR: 150, ly: -0.8, pitch: 0.06 }, 'io').to(700, { kt: 1, knot: 0.3 }, 'io').to(500, { kt: -0.3, knot: -0.2 }, 'io').to(300, { kt: 0, knot: 0, armR: 0 }, 'io')    // twirls his knot neat
            .e('emit', 'pepper', 'head', 3).to(300, { ly: 0, pitch: 0, hap: 1, smile: 1 }, 'io'); return t.wait(300).rest(450).done(); })(), 'Knot twirl', 'Reaches up and twirls his top knot neat (the pleats twist with it), a sprinkle of pepper falls.'],
        press: { kt: 0.4 }, rel: { dur: 1100, k: { sq: [[0, 0], [110, -0.16, 'o'], [250, 0.08, 'io'], [420, 0, 'io']], knot: [[0, 0], [150, 0.8, 'o'], [400, -0.4, 'io'], [700, 0, 'io']], kt: [[0, 0.4], [400, 0, 'io']] }, em: [['broth', 'head', 3]] },
      },
      // ===== Maki (sushi roll standing up: the salmon and veggies pop up out of the rice, spins like a top) =====
      maki: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(160, { veg: 1, sq: -0.05 }, 'o').e('emit', 'spark', 'head', 2).to(360, { veg: 0, sq: 0 }, 'io'); spinR(t, 900, 360, { armL: 50, armR: 50 }); t.to(200, { armL: 0, armR: 0 }, 'io'); hopC(t, 6);
          return loopN(t.rest(300)); })(), 'Happy', 'His salmon and veggies pop up out of the rice, a quick spin like a top, then a hop.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(70, { wide: 1, open: 0.5, mw: 0.7, veg: 1.3 }, 'o'); hopC(t, 8, { ant: 60 }); t.to(400, { veg: 0 }, 'io');
          t.to(300, { lx: 0.8 }, 'o').wait(250).to(300, { lx: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io'); return t.rest(400).done(); })(), 'Surprised', 'His salmon and veggies shoot up out of the rice and he jumps.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.38, hap: 0.9, armL: 20, armR: 20 }, 'io').e('emit', 'rice', 'head', 4).wait(250);
          t.to(120, { sq: -0.14, veg: 0.9, hap: 0, smile: 1, open: 0.3 }, 'o').to(300, { veg: 0 }, 'io'); jelly(t, 0.08, 3, 240); t.to(200, { armL: 0, armR: 0, smile: 0, open: 0 }, 'io'); return loopN(t); })(), 'Squish', 'Pressed like rolling a mat, rice grains fly, his salmon and veggies pop up.'],
        quirk: [(() => { const t = TL();
          t.to(400, { close: 1, smile: 0.8 }, 'io').wait(200); spinR(t, 2600, 360, { veg: 0.3 }); t.to(300, { veg: 0, close: 0, hap: 1, smile: 1 }, 'io');           // a slow zen turn like a spinning top
          return t.wait(300).rest(450).done(); })(), 'Zen spin', 'Closes his eyes and turns slowly round like a spinning top, perfectly calm.'],
        press: { sq: 0.05, veg: 0.3 }, rel: { dur: 900, k: { sq: [[0, 0], [100, -0.14, 'o'], [240, 0.06, 'io'], [400, 0, 'io']], veg: [[0, 0.3], [120, 1, 'o'], [500, 0, 'io']] }, em: [['rice', 'head', 3]] },
      },
      // ===== Noodle (a bowl of ramen since Nov 10: slurp, the chopsticks (lid channel) lift noodles, steam) =====
      noodle: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(300, { slurp: 1, puff: -0.3, open: 0.2, mw: 0.5 }, 'io').wait(300).to(250, { slurp: 0, puff: 0, open: 0.3, mw: 1 }, 'o').e('emit', 'steam', 'head', 3);   // slurp! yum
          hopC(t, 7, { air: { lid: 0.8 }, fall: { lid: 0 } }); return loopN(t.rest(300)); })(), 'Happy', 'Slurps up his noodles, a happy puff of steam, then a hop that lifts a pinch of noodles with his chopsticks.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(70, { wide: 1, open: 0.5, mw: 0.7, lid: -1, sq: -0.08, lift: 3 }, 'o').e('emit', 'steam', 'head', 5).to(250, { lid: 1, lift: 0, sq: 0.04 }, 'io').to(250, { lid: 0, sq: 0 }, 'io');
          t.to(300, { lx: -0.8 }, 'o').wait(250).to(300, { lx: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io'); return t.rest(400).done(); })(), 'Surprised', 'His chopsticks jump up out of the noodles and a burst of steam puffs out like a whistle.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.38, lid: 0.8, hap: 0.9, armL: 20, armR: 20 }, 'io').e('emit', 'broth', 'head', 4).wait(250);
          t.to(120, { sq: -0.14, lid: -0.4, hap: 0, smile: 1, open: 0.3 }, 'o').to(260, { lid: 0 }, 'io'); jelly(t, 0.08, 3, 240); t.to(200, { armL: 0, armR: 0, smile: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squeezed, a splash of broth and his chopsticks bob, then he springs back.'],
        quirk: [(() => { const t = TL();
          t.to(400, { close: 1, smile: 1, sq: 0.03 }, 'io').e('emit', 'steam', 'head', 3).osc(1600, 4, { lid: 0.7 }, { lid: -0.2 }, 'io').e('emit', 'steam', 'head', 3)        // twirls up noodles with his chopsticks
            .to(300, { lid: 0, close: 0, sq: 0, hap: 1 }, 'io'); return t.wait(300).rest(450).done(); })(), 'Steam sigh', 'Closes his eyes in a cosy cloud of steam while his chopsticks twirl up noodles.'],
        press: { lid: 0.5 }, rel: { dur: 1000, k: { sq: [[0, 0], [100, -0.15, 'o'], [250, 0.06, 'io'], [400, 0, 'io']], lid: [[0, 0.5], [150, -0.6, 'o'], [400, 0.3, 'io'], [650, 0, 'io']] }, em: [['steam', 'head', 4]] },
      },
      // ===== Flossie (cotton candy: the floss poofs and swirls) =====
      flossie: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, open: 0.3 });
          t.to(300, { fluff: 1.2, sq: -0.06, lift: 2 }, 'o').e('emit', 'floss', 'head', 3).to(500, { fluff: 0, sq: 0, lift: 0 }, 'io');
          t.to(1100, { swirl: 1 }, 'io').to(1, { swirl: 0 }, 'l'); hopC(t, 6); return loopN(t.rest(300)); })(), 'Happy', 'Poofs up big and fluffy, her floss swirls round her, then a soft hop.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, open: 0.5, mw: 0.7, fluff: 1.6, sq: -0.1 }, 'o').e('emit', 'floss', 'head', 4).wait(300).to(900, { fluff: 0, sq: 0.03 }, 'io').to(200, { sq: 0 }, 'io');
          t.to(300, { lx: 0.8 }, 'o').wait(250).to(300, { lx: 0, wide: 0, open: 0, mw: 1, hap: 1, smile: 1 }, 'io'); return t.rest(400).done(); })(), 'Surprised', 'Poofs out huge in surprise, then slowly fluffs back down.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.05 }, 'o').to(320, { sq: 0.42, hap: 0.9, armL: 20, armR: 20 }, 'io').wait(250);
          t.to(160, { sq: -0.16, fluff: 1.3, hap: 0, smile: 1, open: 0.3 }, 'o').e('emit', 'floss', 'head', 4).to(500, { fluff: 0 }, 'io'); jelly(t, 0.08, 3, 260);
          t.to(200, { armL: 0, armR: 0, smile: 0, open: 0 }, 'io'); return loopN(t); })(), 'Squish', 'Squished down, then she poofs back out fluffier than before.'],
        quirk: [(() => { const t = TL();
          t.to(700, { lift: 6, close: 1, smile: 1, armL: 40, armR: 40 }, 'io'); const a = t.t; t.osc(1800, 2, { lift: 7.5 }, { lift: 5.5 }, 's'); t.at(a).to(1800, { swirl: 1 }, 'io').to(1, { swirl: 0 }, 'l'); // floats up, drifting
          t.to(800, { lift: 0, close: 0, armL: 0, armR: 0 }, 'io').to(200, { sq: 0.05 }, 'o').to(200, { sq: 0, hap: 1 }, 'io'); return t.wait(300).rest(450).done(); })(), 'Cloud float', 'Closes her eyes and floats up like a little cloud, her floss drifting round, then sinks softly down.'],
        press: { fluff: 0.5 }, rel: { dur: 1200, k: { sq: [[0, 0], [100, -0.15, 'o'], [250, 0.07, 'io'], [420, 0, 'io']], fluff: [[0, 0.5], [160, 1.3, 'o'], [1200, 0, 'io']] }, em: [['floss', 'head', 3]] },
      },
    };

    // ---------- signature dances (each made of what only that body can do) ----------
    const DANCES = {
      // Frankie: the sausage slides side to side in the bun while he sways the other way, bun-hug beats (mustard), hops it rides, a spin it trails, a mustard finale
      frankie: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 500;
        eyes(t, 1); for (let i = 0; i < 2; i++) t.to(B, { slip: 0.9, x: -1.6, tilt: -3, armL: 30, armR: -6 }, 'io').to(B, { slip: -0.9, x: 1.6, tilt: 3, armL: -6, armR: 30 }, 'io');   // sausage slides, he sways against it
        t.to(B * 0.6, { slip: 0, x: 0, tilt: 0, armL: 0, armR: 0, lx: 0 }, 'io');
        for (let i = 0; i < 3; i++) t.to(150, { hug: -0.9, sq: 0.08 }, 'o').e('emit', 'mustard', 'head', 2).to(B - 150, { hug: 0.3, sq: -0.03 }, 'io');                       // bun-hug beats
        t.to(200, { hug: 0, sq: 0 }, 'io');
        for (let i = 0; i < 2; i++) hopC(t, 8, { chain: i < 1, air: { slip: i ? -0.5 : 0.5 }, fall: { slip: 0 } });                                                         // hops - it rides
        let a = spinR(t, 1300, 360, { armL: 70, armR: 70 }); t.at(a).to(500, { slip: -0.7 }, 'o').to(800, { slip: 0 }, 'io'); t.at(a + 1301).to(250, { armL: 0, armR: 0 }, 'io'); // spin - it trails
        t.to(300, { armL: 150, armR: 150, sq: -0.08, lift: 2 }, 'o').e('emit', 'mustard', 'head', 4).to(160, { hug: -0.8, sq: 0.1, lift: 0 }, 'i').e('emit', 'mustard', 'head', 3)
          .to(400, { hug: 0, sq: 0, armL: 0, armR: 0 }, 'io').e('emit', 'heart', 'head', 1).wait(300);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Bun Hug Wiggle', 'His sausage slides side to side in the bun while he sways the other way, bun-hug beats squirt mustard, two hops it rides, a spin it trails behind, and a big mustard finale.'],
      // Corny: kernels pop on every step, a fizzing shimmy, a big jump that pops them all, a spin, a cheer
      corny: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 460;
        for (let i = 0; i < 4; i++) t.to(B / 2, { pop: 0.9, footL: i % 2 ? 0 : 2.4, footR: i % 2 ? 2.4 : 0, x: i % 2 ? 1 : -1, tilt: i % 2 ? 3 : -3 }, 'o').e('emit', 'popk', 'head', 1).to(B / 2, { pop: 0, footL: 0, footR: 0 }, 'i');
        t.to(200, { x: 0, tilt: 0, cfz: 1 }, 'io').osc(1300, 6, { tilt: 4, armL: 40, armR: 10 }, { tilt: -4, armL: 10, armR: 40 }, 'io').to(200, { cfz: 0, tilt: 0, armL: 0, armR: 0 }, 'io'); // fizzing shimmy
        jump(t, { h: 13, ant: 200, up: 280, c: 0.2, arm: 120, air: { pop: 1.5 }, fall: { pop: 0 }, ev: [['emit', 'popk', 'head', 6]] });                                     // the big pop
        let a = spinR(t, 1200, 360, { armL: 60, armR: 60 }); t.at(a); for (let i = 0; i < 3; i++) t.to(200, { pop: 0.7 }, 'o').to(200, { pop: 0 }, 'i'); t.at(a + 1201);
        t.to(300, { armL: 150, armR: 150, cfz: 1 }, 'o').wait(400).to(300, { armL: 0, armR: 0, cfz: 0 }, 'io').wait(200);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Popcorn Pop', 'Her kernels pop on every step, a fizzing shimmy, a big jump that pops them all at once, a spin with popcorn bouncing and a fizzy cheer.'],
      // Peppi: lazy floppy sway, two cheese pulls (crust lifts, strings stretch), a slice spin in the air, a floppy-tip shimmy, a cheesy bow
      peppi: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 520;
        swing(t, 2400, 4, { tilt: 5, x: 1.5, flop: 0.7, armL: 20, armR: -20 }, 'io');                                                                                       // lazy floppy sway
        for (let i = 0; i < 2; i++) t.to(320, { pull: 1, lift: 3, armL: 120, armR: 120 }, 'o').e('emit', 'cheese', 'head', 2).wait(160).to(260, { pull: 0, lift: 0, armL: 20, armR: 20 }, 'i').wait(B - 260);
        t.to(200, { armL: 0, armR: 0 }, 'io'); jump(t, { h: 11, ant: 180, up: 260, c: 0.18, arm: 90, spin: 360, air: { flop: -0.7 }, fall: { flop: 0 } });                // slice spin
        t.osc(1200, 4, { flop: 1, tilt: 3 }, { flop: -0.6, tilt: -3 }, 'io').to(200, { flop: 0, tilt: 0 }, 'io');                                                          // floppy-tip shimmy
        t.to(400, { pitch: -0.18, flop: 0.6, armL: 60, armR: 60, close: 0.6 }, 'io').e('emit', 'cheese', 'head', 2).wait(300).to(400, { pitch: 0, flop: 0, armL: 0, armR: 0, close: 0 }, 'io').wait(200);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Cheese Pull Sway', 'A lazy floppy sway, two big cheese pulls with his crust lifting, a slice spin in the air, a floppy-tip shimmy and a cheesy bow.'],
      // Nori: polite bow, neat side steps (salmon flakes bob), a jacket shimmy, a rolling spin with rice flying, a bow
      nori: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 500;
        t.to(400, { pitch: -0.2, close: 0.6 }, 'io').wait(200).to(300, { pitch: 0, close: 0 }, 'io');
        for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; t.to(B / 2, { x: d * 3, footL: d < 0 ? 2.4 : 0, footR: d > 0 ? 2.4 : 0, ume: 0.6, tilt: d * 2 }, 'o').to(B / 2, { footL: 0, footR: 0, ume: 0 }, 'i'); }
        t.to(300, { x: 0, tilt: 0 }, 'io').to(200, o(both(3, 6), { armL: 18, armR: 18 }), 'io').osc(1200, 4, { nwr: 0.7, sq: 0.03 }, { nwr: -0.3, sq: 0 }, 'io').to(240, o(NOHANDS, { nwr: 0, armL: 0, armR: 0 }), 'io'); // jacket shimmy
        jump(t, { h: 11, ant: 180, up: 260, c: 0.18, arm: 80, spin: 360, air: { ume: 1 }, fall: { ume: 0 }, ev: [['emit', 'rice', 'body', 6]] });
        t.to(300, { armL: 150, armR: 150, hap: 1 }, 'o').e('emit', 'spark', 'head', 3).wait(300).to(300, { armL: 0, armR: 0 }, 'io').to(400, { pitch: -0.2, close: 0.6 }, 'io').wait(300).to(300, { pitch: 0, close: 0 }, 'io');
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Rice Ball Roll', 'A polite bow, neat side steps with his salmon flakes bobbing, a seaweed-jacket shimmy, a spinning hop that scatters rice, a cheer and another bow.'],
      // Sunny: rock 'n' roll on her round bottom tipping her cap on the beat, rolls right over and back, the cap pops off and lands back (yolk wobbling),
      // a somersault, a wobble and a hat-tip bow
      sunny: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 480;
        for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; t.to(B * 0.55, { rl: d * 22, x: d * 6, cap: 0.5, [d < 0 ? 'armL' : 'armR']: 120, [d < 0 ? 'armR' : 'armL']: 20, sq: 0.03 }, 'io').to(B * 0.45, { cap: 0, sq: 0 }, 'i'); } // rocks, cap tips
        t.to(260, { rl: 0, x: 0, armL: 0, armR: 0 }, 'io');
        t.to(1000, { rl: 360, x: 22, armL: 40, armR: 40 }, 'io').to(1, { rl: 0 }, 'l').wait(150).to(1000, { rl: -360, x: 0 }, 'io').to(1, { rl: 0 }, 'l').to(200, { armL: 0, armR: 0 }, 'io'); // rolls over and back
        t.to(200, { sq: 0.14 }, 'io').to(120, { cap: 1.2, sq: -0.1, wob: 1.4, wide: 0.6, open: 0.5 }, 'o').wait(500).to(360, { cap: 0, sq: 0.06 }, 'i').to(200, { sq: 0, wob: 0.6, wide: 0, open: 0 }, 'io');
        jump(t, { h: 12, ant: 180, up: 280, c: 0.18, arm: 80, air: { rl: -180 }, fall: { rl: -360 } }); t.to(1, { rl: 0 }, 'l');                                            // a somersault
        t.osc(1000, 4, { rl: 10, wob: 0.8 }, { rl: -10, wob: 0.3 }, 'io').to(200, { rl: 0, wob: 0 }, 'io');
        t.to(400, { cap: 0.6, pitch: -0.14, close: 0.6, armR: 120 }, 'io').wait(300).to(400, { cap: 0, pitch: 0, close: 0, armR: 0 }, 'io').e('emit', 'heart', 'head', 1).wait(200);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Roly-Poly Rock', 'Rocks side to side on her round bottom tipping her shell cap on every beat, rolls right over and back, the cap pops off and lands back while her yolk wobbles, a somersault, a wobble and a hat-tip bow.'],
      // Toco: castanet snaps on the beat with flamenco arms and stamps, a spin, a lettuce shower, an ole
      toco: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 420;
        for (let i = 0; i < 6; i++) { const d = i % 2 ? 1 : -1; t.to(B * 0.3, { snap: -0.6, [d < 0 ? 'armL' : 'armR']: 150, [d < 0 ? 'armR' : 'armL']: 30, [d < 0 ? 'footL' : 'footR']: 2.2, tilt: d * 3 }, 'o').to(B * 0.7, { snap: 0.5, footL: 0, footR: 0 }, 'io'); } // castanets + flamenco
        t.to(200, { snap: 0, armL: 0, armR: 0, tilt: 0 }, 'io');
        let a = spinR(t, 1200, 360, { armL: 60, armR: 150 }); t.at(a); for (let i = 0; i < 3; i++) t.to(150, { snap: -0.5 }, 'o').to(250, { snap: 0.4 }, 'io'); t.at(a + 1201).to(200, { snap: 0, armL: 0, armR: 0 }, 'io');
        jump(t, { h: 10, ant: 160, up: 240, c: 0.18, arm: 120, air: { snap: 1.2 }, fall: { snap: 0 }, ev: [['emit', 'lettuce', 'head', 5]] });                              // lettuce shower
        t.to(300, { armR: 160, armL: 20, tilt: -4, snap: -0.4 }, 'o').e('emit', 'spark', 'head', 3).wait(500).to(300, { armR: 0, armL: 0, tilt: 0, snap: 0 }, 'io').wait(200);   // ole!
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Taco Snap', 'Snaps his shell like castanets on every beat with flamenco arms and stamps, a spin, a jump that showers lettuce, and an ole.'],
      // Churro: tango steps, a corkscrew spin (the ridges twist round him), a deep tango dip, sugar dust, a pose
      churro: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 520;
        for (let i = 0; i < 4; i++) { const d = i < 2 ? 1 : -1; t.to(B * 0.4, { x: d * (i % 2 ? 4 : 2), [i % 2 ? 'footR' : 'footL']: 2.5, armL: 60, armR: 20, lean: d * 1.2 }, 'o').to(B * 0.6, { footL: 0, footR: 0 }, 'i'); } // tango steps
        t.to(300, { x: 0, lean: 0, armL: 0, armR: 0 }, 'io');
        let a = spinR(t, 1500, 720, { armL: 120, armR: 120, lift: 2 }); t.at(a).to(600, { cork: 1.2 }, 'io').to(900, { cork: -0.4 }, 'io').to(1, { cork: -0.4 }, 'l'); t.at(a + 1501).to(300, { cork: 0, lift: 0, armL: 0, armR: 0 }, 'io').e('emit', 'sugar', 'head', 4);
        t.to(600, { bend: -14, lean: -2, armL: 150, armR: 40, close: 0.5 }, 'io').wait(500).to(500, { bend: 0, lean: 0, armL: 0, armR: 0, close: 0 }, 'io');                // the tango dip
        t.to(300, { armR: 150, htilt: 6 }, 'o').e('emit', 'sugar', 'body', 5).wait(500).to(300, { armR: 0, htilt: 0 }, 'io').wait(200);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Churro Corkscrew', 'Suave tango steps, a double spin that twists his ridges into a corkscrew, a deep tango dip and a sugar-dusted pose.'],
      // Khinki: twists his pleats one way and the other with the knot whipping round, juicy bounces, a twirling spin, a pepper shake, a squirt finale
      khinki: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 500;
        for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; t.to(B, { kt: d * 1, knot: -d * 0.8, tilt: d * 3, armL: d < 0 ? 60 : 10, armR: d > 0 ? 60 : 10 }, 'io'); }                 // pleat twists, knot whips
        t.to(300, { kt: 0, knot: 0, tilt: 0, armL: 0, armR: 0 }, 'io');
        for (let i = 0; i < 3; i++) hopC(t, 7, { chain: i < 2, air: { knot: i % 2 ? 0.6 : -0.6 }, fall: { knot: 0 } });
        let a = spinR(t, 1400, 360, { armL: 70, armR: 70 }); t.at(a).to(700, { kt: 1.1, knot: -0.8 }, 'io').to(700, { kt: 0, knot: 0 }, 'io'); t.at(a + 1401).to(200, { armL: 0, armR: 0 }, 'io');
        shake(t, { P: 90, env: [0.4, 0.9, 1, 0.6, 0.3], head: 0.06, roll: 3, ear: 0, body: 0.5 }); t.e('emit', 'pepper', 'head', 5);                                           // a pepper shake
        t.to(200, { sq: 0.18, kt: 0.5 }, 'io').to(120, { sq: -0.1, lift: 3, armL: 150, armR: 150, kt: -0.3, wide: 0.5, open: 0.5 }, 'o').e('emit', 'broth', 'head', 6).to(300, { sq: 0, lift: 0, armL: 0, armR: 0, kt: 0, wide: 0, open: 0 }, 'io').e('emit', 'heart', 'head', 1).wait(200);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Topknot Twist', 'Twists his pleats one way and the other with his knot whipping round, juicy bounces, a twirling spin, a pepper shake and a big juicy squirt.'],
      // Maki: spins like a top (double turn) with the veggies wiggling, rice-tossing hops, a slow top spin, a bow
      maki: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 500;
        for (let i = 0; i < 4; i++) t.to(B / 2, { veg: 0.9, x: i % 2 ? 1.5 : -1.5, tilt: i % 2 ? 3 : -3, footL: i % 2 ? 0 : 2, footR: i % 2 ? 2 : 0 }, 'o').to(B / 2, { veg: 0.1, footL: 0, footR: 0 }, 'io');
        t.to(200, { x: 0, tilt: 0, veg: 0 }, 'io');
        let a = spinR(t, 1600, 720, { armL: 90, armR: 90, lift: 2 }); t.at(a).osc(1600, 4, { veg: 1 }, { veg: 0.2 }, 'io'); t.at(a + 1601).to(300, { armL: 0, armR: 0, lift: 0, veg: 0 }, 'io');      // spins like a top
        for (let i = 0; i < 3; i++) hopC(t, 6, { chain: i < 2, air: { veg: 0.8 }, fall: { veg: 0 }, ev: [['emit', 'rice', 'head', 2]] });
        t.to(300, { close: 0.7 }, 'io'); a = spinR(t, 2000, 360, {}); t.to(200, { close: 0 }, 'io');
        t.to(400, { pitch: -0.2, close: 0.6, armL: 40, armR: 40 }, 'io').wait(300).to(300, { pitch: 0, close: 0, armL: 0, armR: 0 }, 'io').wait(200);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Sushi Spin', 'Sways with his salmon and veggies wiggling, spins like a top twice, three hops that toss rice, a slow calm turn and a bow.'],
      // Noodle: slurp shimmy, the chopsticks lift noodles on the beat, a steamy spin, a big slurp finish
      noodle: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 480;
        for (let i = 0; i < 4; i++) t.to(B / 2, { slurp: 0.8, x: i % 2 ? 1 : -1, tilt: i % 2 ? 3 : -3, puff: -0.2, mw: 0.6 }, 'o').to(B / 2, { slurp: 0, puff: 0, mw: 1 }, 'io'); // slurp shimmy
        t.to(200, { x: 0, tilt: 0 }, 'io');
        for (let i = 0; i < 3; i++) t.to(150, { lid: -0.8, armR: 120 }, 'o').to(B - 150, { lid: 0.6, armR: 30 }, 'io'); t.to(200, { lid: 0, armR: 0 }, 'io');                // chopsticks lift noodles on the beat
        let a = spinR(t, 1300, 360, { armL: 60, armR: 60 }); t.at(a); [0, 400, 800].forEach(d => t.at(a + d).e('emit', 'steam', 'head', 2)); t.at(a + 1301).to(200, { armL: 0, armR: 0 }, 'io');
        t.to(400, { slurp: 1.2, puff: -0.3, open: 0.2, mw: 0.5, close: 0.6 }, 'io').wait(300).to(300, { slurp: 0, puff: 0, open: 0.3, mw: 1, close: 0 }, 'o').e('emit', 'steam', 'head', 4).wait(300);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Noodle Slurp', 'A slurpy shimmy, lifts noodles with his chopsticks on the beat, a steamy spin and one big slurp.'],
      // Flossie: floats up and down, her floss swirling, poofs on the beat, a twirl, sparkles, a soft landing
      flossie: [(() => { const t = TL({ smile: 0.9, hap: 1 }), B = 560;
        t.to(800, { lift: 6, armL: 50, armR: 50 }, 'io'); let a = t.t; t.osc(2200, 2, { lift: 8 }, { lift: 5 }, 's'); t.at(a).to(2200, { swirl: 1 }, 'io').to(1, { swirl: 0 }, 'l'); // floats, floss swirling
        t.to(600, { lift: 0, armL: 0, armR: 0 }, 'io');
        for (let i = 0; i < 4; i++) t.to(150, { fluff: 1, sq: -0.05 }, 'o').e('emit', 'floss', 'head', 1).to(B - 150, { fluff: 0.1, sq: 0 }, 'io');                          // poofs on the beat
        t.to(200, { fluff: 0 }, 'io'); a = spinR(t, 1500, 360, { armL: 120, armR: 120, lift: 3 }); t.at(a).to(1500, { swirl: 1 }, 'io').to(1, { swirl: 0 }, 'l'); t.at(a + 1501).to(400, { armL: 0, armR: 0, lift: 0 }, 'io');
        t.to(300, { fluff: 1.4, armL: 150, armR: 150 }, 'o').e('emit', 'floss', 'head', 4).e('emit', 'spark', 'head', 3).wait(300).to(700, { fluff: 0, armL: 0, armR: 0 }, 'io').wait(200);
        return t.rest(300).loop({ stretch: 0.6 }); })(), 'Candy Cloud Float', 'Floats up and down with her floss swirling round her, poofs on the beat, a twirling spin and a big sparkly poof.'],
    };
    KEYS.forEach(k => { MOVES[k].dance = DANCES[k]; MOVES[k].look = natF(1); });
    install(MOVES, CARDS);
  })();

  // =====================================================================================================================================
  // pokes (9 spots each, left / right where it matters)
  (function boot() {
    const R = window.RiveRig; if (!R || !R.POKELIB || !R.snack2V || !R.STATES.poke_head) { setTimeout(boot, 25); return; } if (R.snack2PokeV) return; R.snack2PokeV = 1;
    const { S, hand, both, o, NOHANDS, jump, shake, swing, jelly } = R.PETLIB;
    const { see, unsee, giggle, sniff, lick, para, leanIn, happy, build } = R.POKELIB;
    const armUp = (t, s, n, a, x) => { const k = S(s); a = a || 150; t.to(300, o({ [k.arm]: a }, x || {}), 'io'); for (let i = 0; i < (n || 2); i++) t.to(170, { [k.arm]: a - 16 }, 'io').to(170, { [k.arm]: a }, 'io'); return t.to(300, { [k.arm]: 0, winkL: 0, winkR: 0 }, 'io'); };
    const eyeRub = (t, s) => { const k = S(s), h = hand(s, 12, -20); t.e('blink2').to(300, o(h, { [k.arm]: 20, [k.wink]: 1 }), 'io');
      for (let i = 0; i < 2; i++) t.to(170, { [k.hx]: h[k.hx] + (s < 0 ? 3 : -3), [k.hy]: h[k.hy] - 1.5 }, 'io').to(170, { [k.hx]: h[k.hx], [k.hy]: h[k.hy] }, 'io');
      return t.to(300, { [k.hx]: 0, [k.hy]: 0, [k.arm]: 0, [k.wink]: 0 }, 'io').e('blink'); };
    const wobble = (t, a, ch) => jelly(t, a || 0.12, 3, 300, ch);
    const lookBack = (t, hold) => { see(t, 'tail', 1, hold || 350); return unsee(t, 380); };
    const hop = (t, h, ev, x) => jump(t, o({ h: h || 6, ant: 140, up: 190, c: 0.14, arm: 40, ev }, x || {}));
    const tickle = (t, extra) => { t.to(220, o(both(8, -4), { hap: 1, smile: 1 }), 'io'); const a = t.t; giggle(t, 3, 0.9); if (extra) para(t, a, extra); return t.to(260, NOHANDS, 'io'); };
    const tasteHeart = t => { lick(t, 2); return t.to(220, { hap: 1, smile: 1 }, 'io').e('emit', 'heart', 'head', 1).wait(320).to(220, { hap: 0, smile: 0 }, 'io'); };
    const fizz = (t, ch, a, n) => t.osc(n * 160, n, { [ch]: a }, { [ch]: 0 }, 'io');
    const nose = (t, k) => { t.to(150, { cross: 0, ly: 0.2 }, 'io'); if (k) k(t); return t.to(200, { ly: 0 }, 'io'); };

    const BODY = {
      frankie: { ear: 0.6, lbl: { ear: s => s > 0 ? 'Sausage end (right)' : 'Sausage end (left)', head: 'Sausage', nose: 'Mouth', belly: 'Bun', tail: 'Back of the bun' } },
      corny: { ear: 0.6, hopBack: 1, lbl: { ear: 'popcorn', head: 'Popcorn', nose: 'Mouth', belly: 'Stripes', foot: 'bucket bottom', tail: 'Back of the bucket' } },
      peppi: { ear: 0.6, lbl: { ear: 'crust corner', head: 'Crust', nose: 'Mouth', belly: 'Pepperoni', foot: 'tip', tail: 'Underside' } },
      nori: { ear: 0.6, lbl: { ear: 'rice corner', head: 'Salmon', nose: 'Mouth', belly: 'Seaweed jacket', tail: 'Back' } },
      sunny: { ear: 0.6, lbl: { ear: 'shell', head: 'Shell cap', nose: 'Mouth', belly: 'Tummy', foot: 'Round bottom', tail: 'Back' } },
      toco: { ear: 0.6, lbl: { ear: 'lettuce', head: 'Fillings', nose: 'Mouth', belly: 'Shell', tail: 'Back of the shell' } },
      churro: { ear: 0.6, lbl: { ear: 'chocolate', head: 'Chocolate top', nose: 'Mouth', belly: 'Ridges', tail: 'Back' } },
      khinki: { ear: 0.6, lbl: { ear: 'pleats', head: 'Top knot', nose: 'Mouth', belly: 'Dough belly', tail: 'Back' } },
      maki: { ear: 0.6, lbl: { ear: 'rice rim', head: 'Filling', nose: 'Mouth', belly: 'Rice belly', side: 'rice', tail: 'Back' } },
      noodle: { ear: 0.6, hopBack: 1, lbl: { ear: s => s > 0 ? 'Chopsticks' : 'Noodles', head: 'Toppings', nose: 'Mouth', belly: 'Red band', foot: 'bowl bottom', tail: 'Bowl (back)' } },
      flossie: { ear: 0.6, lbl: { ear: 'floss', head: 'Floss top', nose: 'Mouth', belly: 'Floss', foot: 'stick', tail: 'Back' } },
    };
    const RE = {
      frankie: { // hot dog: the sausage slides, the bun hugs
        head: (t, s) => { t.to(140, { hug: -0.6, sq: 0.08 }, 'o').e('emit', 'mustard', 'head', 3).to(260, { hug: 0, sq: 0 }, 'io'); giggle(t, 2); },
        ear: (t, s) => { t.to(220, { slip: -s * 0.8, wide: 0.5 }, 'o'); see(t, 'ear', s, 150); t.to(320, o(hand(s, 6, -6), { [S(s).arm]: 60, slip: 0 }), 'io').to(260, o(NOHANDS, { [S(s).arm]: 0, wide: 0 }), 'io'); unsee(t); },
        nose: (t, s) => nose(t, u => { sniff(u, 2); tasteHeart(u); }),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s, { hug: -0.3 }); t.to(200, { hug: 0 }, 'io'); },
        belly: (t, s) => { tickle(t, u => u.osc(900, 3, { slip: 0.5 }, { slip: -0.5 }, 'io').to(150, { slip: 0 }, 'io')); },
        side: (t, s) => { t.to(200, { slip: -s * 1, tilt: -s * 4 }, 'o').to(400, { slip: -s * 0.3, tilt: 0 }, 'io').to(300, { slip: 0 }, 'io'); see(t, 'side', s, 200); unsee(t, 300); },
        foot: (t, s) => { hop(t, 6, [['emit', 'mustard', 'head', 2]], { air: { slip: 0.4 }, fall: { slip: 0 } }); },
        tail: (t, s) => { t.to(160, { hug: 0.6 }, 'o').to(260, { hug: 0 }, 'io'); lookBack(t); },
      },
      corny: { // popcorn: the kernels pop up
        head: (t, s) => { t.to(100, { pop: 1, sq: 0.06 }, 'o').e('emit', 'popk', 'head', 3).to(380, { pop: 0, sq: 0 }, 'i'); giggle(t, 2); },
        ear: (t, s) => { see(t, 'ear', s, 100); t.to(100, { pop: 0.7 }, 'o').to(300, { pop: 0 }, 'i'); fizz(t, 'cfz', 0.8, 3); unsee(t); },
        nose: (t, s) => nose(t, u => { sniff(u, 3); u.to(200, { hap: 1, smile: 1, cfz: 0.7 }, 'io').wait(400).to(200, { hap: 0, smile: 0, cfz: 0 }, 'io'); }),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s, { cfz: 0.5 }); t.to(200, { cfz: 0 }, 'io'); },
        belly: (t, s) => { tickle(t, u => { for (let i = 0; i < 3; i++) u.to(120, { pop: 0.8 }, 'o').to(200, { pop: 0 }, 'i'); }); },
        side: (t, s) => { const d = -s; t.to(260, { tilt: d * 8, x: d * 2, pop: 0.5 }, 'o').to(320, { tilt: -d * 3, pop: 0 }, 'io').to(260, { tilt: 0, x: 0 }, 'io'); see(t, 'side', s, 200); unsee(t, 300); },
        foot: (t, s) => { hop(t, 7, [['emit', 'popk', 'head', 3]], { air: { pop: 1 }, fall: { pop: 0 } }); },
        tail: (t, s) => { t.to(100, { pop: 0.6 }, 'o').to(300, { pop: 0 }, 'i'); lookBack(t); },
      },
      peppi: { // pizza: the tip flops, the cheese stretches
        head: (t, s) => { t.to(200, { pull: 0.8, lift: 1.5 }, 'o').to(260, { pull: 0, lift: 0 }, 'i').e('emit', 'cheese', 'head', 2); giggle(t, 2); },
        ear: (t, s) => { see(t, 'ear', s, 100); t.osc(520, 2, { htilt: s * 5, tilt: s * 2 }, { htilt: s, tilt: 0 }, 'io'); unsee(t); },
        nose: (t, s) => nose(t, u => { sniff(u, 2); tasteHeart(u); }),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s, { flop: 0.3 }); t.to(200, { flop: 0 }, 'io'); },
        belly: (t, s) => { tickle(t, u => u.osc(900, 3, { flop: 0.8 }, { flop: -0.4 }, 'io').to(150, { flop: 0 }, 'io')); },
        side: (t, s) => { jelly(t, 4, 3, 320, 'bend'); see(t, 'side', s, 200); unsee(t, 300); },
        foot: (t, s) => { t.to(160, { flop: 1 }, 'o'); jelly(t, 0.7, 3, 300, 'flop'); see(t, 'foot', s, 200); unsee(t, 300); },
        tail: (t, s) => { t.to(200, { flop: -0.8 }, 'o').to(300, { flop: 0 }, 'io'); lookBack(t); },
      },
      nori: { // rice ball: the salmon flakes hop, the jacket slips
        head: (t, s) => { t.to(120, { ume: 1, sq: 0.06 }, 'o').e('emit', 'spark', 'head', 2).to(320, { ume: 0, sq: 0 }, 'i'); giggle(t, 2); },
        ear: (t, s) => { see(t, 'ear', s, 150); t.to(200, { blush: 0.6 }, 'io'); unsee(t); t.to(200, { pitch: -0.1 }, 'io').to(200, { pitch: 0, blush: 0 }, 'io'); },
        nose: (t, s) => nose(t, u => { sniff(u, 2); tasteHeart(u); }),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s, { blush: 0.5 }); t.to(200, { blush: 0 }, 'io'); },
        belly: (t, s) => { t.to(200, { nwr: 0.8, wide: 0.6, blush: 0.8 }, 'o').to(320, o(both(4, 4), { armL: 20, armR: 20 }), 'io').to(300, o(NOHANDS, { nwr: 0, armL: 0, armR: 0, wide: 0 }), 'io'); giggle(t, 2); t.to(200, { blush: 0 }, 'io'); },
        side: (t, s) => { jelly(t, 3, 3, 320, 'bend'); t.e('emit', 'rice', 'body', 2); see(t, 'side', s, 200); unsee(t, 300); },
        foot: (t, s) => { hop(t, 5, [['emit', 'rice', 'body', 2]]); },
        tail: (t, s) => { t.e('emit', 'rice', 'body', 2); lookBack(t); },
      },
      sunny: { // boiled egg: the shell cap pops, the yolk wobbles
        head: (t, s) => { t.to(100, { cap: 0.9, sq: 0.06 }, 'o').to(200, { wob: 1 }, 'io').to(320, { cap: 0, sq: 0 }, 'i').to(300, { wob: 0 }, 'io'); giggle(t, 2); },
        ear: (t, s) => { see(t, 'ear', s, 150); t.to(140, { [s < 0 ? 'armL' : 'armR']: 60 }, 'o').to(260, { [s < 0 ? 'armL' : 'armR']: 0 }, 'io'); unsee(t); },
        nose: (t, s) => nose(t, u => { sniff(u, 2); tasteHeart(u); }),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s, { cap: 0.2 }); t.to(200, { cap: 0 }, 'io'); },
        belly: (t, s) => { tickle(t, u => u.osc(900, 3, { rl: 10, x: 2, cap: 0.3 }, { rl: -10, x: -2, cap: 0 }, 'io').to(180, { rl: 0, x: 0 }, 'io')); },
        side: (t, s) => { const d = -s; t.to(240, { rl: d * 28, x: d * 6, cap: 0.4 }, 'o').to(380, { rl: -d * 10, x: -d * 1.5, cap: 0 }, 'io').to(300, { rl: d * 3, x: 0 }, 'io').to(200, { rl: 0 }, 'io'); see(t, 'side', s, 200); unsee(t, 300); },
        foot: (t, s) => { const d = s || 1; t.to(260, { rl: d * 38, x: d * 8, cap: 0.5 }, 'o').to(400, { rl: -d * 14, x: -d * 2, cap: 0 }, 'io').to(320, { rl: d * 5, x: 0 }, 'io').to(240, { rl: 0 }, 'io'); giggle(t, 1); },
        tail: (t, s) => { wobble(t, 0.1); lookBack(t); },
      },
      toco: { // taco: the shell snaps
        head: (t, s) => { t.to(80, { snap: -0.7, sq: 0.06 }, 'o').to(240, { snap: 0.5, sq: 0 }, 'o').e('emit', 'lettuce', 'head', 2).to(200, { snap: 0 }, 'io'); giggle(t, 2); },
        ear: (t, s) => { see(t, 'ear', s, 100); t.to(240, { snap: 0.6 }, 'o'); armUp(t, s, 1, 138); t.to(200, { snap: 0 }, 'io'); unsee(t); },
        nose: (t, s) => nose(t, u => { sniff(u, 2); u.to(100, { snap: -0.5 }, 'o').to(200, { snap: 0 }, 'io'); tasteHeart(u); }),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s, { snap: -0.3 }); t.to(200, { snap: 0 }, 'io'); },
        belly: (t, s) => { tickle(t, u => { for (let i = 0; i < 3; i++) u.to(100, { snap: -0.5 }, 'o').to(200, { snap: 0.4 }, 'io'); u.to(100, { snap: 0 }, 'io'); }); },
        side: (t, s) => { jelly(t, 3, 3, 300, 'bend'); t.e('emit', 'lettuce', 'head', 1); see(t, 'side', s, 200); unsee(t, 300); },
        foot: (t, s) => { hop(t, 6, [['emit', 'lettuce', 'head', 2]], { air: { snap: 0.6 }, fall: { snap: 0 } }); },
        tail: (t, s) => { t.to(100, { snap: -0.6 }, 'o').to(260, { snap: 0 }, 'io'); lookBack(t); },
      },
      churro: { // churro: twists, sugar puffs
        head: (t, s) => { t.e('emit', 'sugar', 'head', 4).to(300, { cork: 0.6 }, 'io').to(300, { cork: 0 }, 'io'); giggle(t, 2); },
        ear: (t, s) => { see(t, 'ear', s, 100); armUp(t, s, 2, 140); t.to(200, { hap: 1, smile: 1 }, 'io').wait(200).to(200, { hap: 0, smile: 0 }, 'io'); unsee(t); },
        nose: (t, s) => nose(t, u => { sniff(u, 2); tasteHeart(u); }),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s, { cork: 0.3 }); t.to(200, { cork: 0 }, 'io'); },
        belly: (t, s) => { tickle(t, u => u.osc(900, 3, { cork: 0.7 }, { cork: -0.7 }, 'io').to(150, { cork: 0 }, 'io')); },
        side: (t, s) => { t.to(400, { cork: -s * 0.9, spin: -s * 18 }, 'io').to(450, { cork: s * 0.2, spin: 0 }, 'io').to(300, { cork: 0 }, 'io'); see(t, 'side', s, 200); unsee(t, 300); }, // twists away from the poke and back (the cork twist turns all of him)
        foot: (t, s) => { hop(t, 6, [['emit', 'sugar', 'body', 3]]); },
        tail: (t, s) => { t.e('emit', 'sugar', 'body', 3); lookBack(t); },
      },
      khinki: { // khinkali: pleats twist, the knot flicks, broth squirts
        head: (t, s) => { t.to(120, { knot: 0.9, sq: 0.06 }, 'o').to(260, { knot: -0.4 }, 'io').to(220, { knot: 0, sq: 0 }, 'io'); giggle(t, 2); },
        ear: (t, s) => { see(t, 'ear', s, 100); t.to(300, { kt: s * 0.7 }, 'io').to(300, { kt: 0 }, 'io'); unsee(t); },
        nose: (t, s) => nose(t, u => { sniff(u, 2); tasteHeart(u); }),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s, { knot: -s * 0.3 }); t.to(200, { knot: 0 }, 'io'); },
        belly: (t, s) => { t.to(200, { sq: 0.12 }, 'o').e('emit', 'broth', 'head', 3).to(300, { sq: 0 }, 'io'); tickle(t, u => u.osc(900, 3, { knot: 0.5 }, { knot: -0.5 }, 'io').to(150, { knot: 0 }, 'io')); },
        side: (t, s) => { jelly(t, 4, 3, 320, 'bend'); t.to(200, { knot: -s * 0.6 }, 'o').to(300, { knot: 0 }, 'io'); see(t, 'side', s, 200); unsee(t, 300); },
        foot: (t, s) => { hop(t, 6, null, { air: { knot: 0.5 }, fall: { knot: 0 } }); },
        tail: (t, s) => { t.e('emit', 'pepper', 'head', 2); lookBack(t); },
      },
      maki: { // sushi: veggies pop, turns like a top
        head: (t, s) => { t.to(120, { veg: 1, sq: 0.06, close: 0.8 }, 'o').to(320, { veg: 0, sq: 0, close: 0 }, 'io'); giggle(t, 2); },
        ear: (t, s) => { see(t, 'ear', s, 150); t.to(120, { veg: 0.5 }, 'o').to(300, { veg: 0 }, 'io'); unsee(t); giggle(t, 1); },
        nose: (t, s) => nose(t, u => { sniff(u, 2); tasteHeart(u); }),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s); },
        belly: (t, s) => { tickle(t, u => u.osc(900, 3, { tilt: 6, veg: 0.5 }, { tilt: -6, veg: 0 }, 'io').to(150, { tilt: 0 }, 'io')); },
        side: (t, s) => { t.to(420, { spin: -s * 50, veg: 0.6 }, 'io').to(420, { spin: 0, veg: 0 }, 'io'); see(t, 'side', s, 200); unsee(t, 300); },                     // turns away from the poke like a top and back
        foot: (t, s) => { hop(t, 6, [['emit', 'rice', 'body', 2]]); },
        tail: (t, s) => { t.e('emit', 'rice', 'body', 2); lookBack(t); },
      },
      noodle: { // ramen bowl: steam, the chopsticks lift noodles (lid), noodles slurp
        head: (t, s) => { t.e('emit', 'steam', 'head', 4).to(150, { slurp: 0.6, sq: 0.05 }, 'o').to(300, { slurp: 0, sq: 0 }, 'io'); giggle(t, 2); },
        ear: (t, s) => { see(t, 'ear', s, 100); if (s > 0) t.osc(600, 3, { lid: -0.7 }, { lid: 0.5 }, 'io').to(150, { lid: 0 }, 'io'); else t.to(300, { slurp: 0.8 }, 'io').to(300, { slurp: 0 }, 'io'); unsee(t); },
        nose: (t, s) => nose(t, u => { sniff(u, 3); u.e('emit', 'steam', 'head', 2); tasteHeart(u); }),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s, { lid: 0.3 }); t.to(200, { lid: 0 }, 'io'); },
        belly: (t, s) => { tickle(t, u => u.osc(900, 3, { lid: 0.6 }, { lid: -0.3 }, 'io').to(150, { lid: 0 }, 'io')); },
        side: (t, s) => { jelly(t, 3, 3, 300, 'bend'); t.e('emit', 'broth', 'head', 2); see(t, 'side', s, 200); unsee(t, 300); },
        foot: (t, s) => { hop(t, 6, [['emit', 'steam', 'head', 2]], { air: { lid: 0.7 }, fall: { lid: 0 } }); },
        tail: (t, s) => { t.e('emit', 'steam', 'head', 2); lookBack(t); },
      },
      flossie: { // cotton candy: poofs, swirls
        head: (t, s) => { t.to(150, { fluff: 1, sq: 0.06 }, 'o').e('emit', 'floss', 'head', 2).to(500, { fluff: 0, sq: 0 }, 'io'); giggle(t, 2); },
        ear: (t, s) => { see(t, 'ear', s, 150); t.to(600, { swirl: s * 0.3 }, 'io').to(500, { swirl: 0 }, 'io'); unsee(t); },
        nose: (t, s) => nose(t, u => { sniff(u, 2); tasteHeart(u); }),
        eye: (t, s) => { eyeRub(t, s); },
        cheek: (t, s) => { leanIn(t, s, { fluff: 0.4 }); t.to(200, { fluff: 0 }, 'io'); },
        belly: (t, s) => { tickle(t, u => u.to(300, { fluff: 1 }, 'io').to(500, { fluff: 0 }, 'io')); },
        side: (t, s) => { t.to(500, { swirl: -s * 0.4, x: -s * 2 }, 'io').to(500, { swirl: 0, x: 0 }, 'io'); see(t, 'side', s, 200); unsee(t, 300); },
        foot: (t, s) => { hop(t, 6, [['emit', 'floss', 'head', 2]], { air: { fluff: 0.8 }, fall: { fluff: 0 } }); },
        tail: (t, s) => { t.to(200, { fluff: 0.6 }, 'io').to(300, { fluff: 0 }, 'io'); lookBack(t); },
      },
    };
    const TXT = {
      frankie: { head: 'His bun hugs the sausage tight, a squirt of mustard, a giggle.', ear: 'The sausage slides out the other end - he pushes it back with a paw.', nose: 'Sniffs your finger and licks it: a heart.', eye: 'Blinks hard and rubs the eye.',
        cheek: 'Leans into your finger, his bun squeezes a little.', belly: 'Ticklish bun: giggles while the sausage slides back and forth.', side: 'The sausage slides away from the poke and back, he looks.', foot: 'A hop - the sausage slides as he lands.', tail: 'The bun opens a little, he looks back.' },
      corny: { head: 'Pop! Kernels jump up and fall back in, she giggles.', ear: 'A few kernels pop and she fizzes.', nose: 'Sniffs your finger, fizzes with happiness.', eye: 'Blinks and rubs her eye.',
        cheek: 'Leans in, fizzing a little.', belly: 'Ticklish stripes: giggles, popcorn popping.', side: 'Rocks away, popcorn bouncing, looks at the spot.', foot: 'Hops - all the popcorn jumps.', tail: 'A few kernels hop, she looks back.' },
      peppi: { head: 'His crust lifts and the cheese stretches, he giggles.', ear: 'Tilts at the poke on his crust corner.', nose: 'Sniffs your finger and licks it: a cheesy heart.', eye: 'Blinks and rubs his eye.',
        cheek: 'Leans in, his tip flopping.', belly: 'Ticklish pepperoni: giggles, tip flapping.', side: 'Wobbles like a soft slice, looks at the spot.', foot: 'His tip flops and wobbles, he looks down.', tail: 'His tip flips back, he looks behind.' },
      nori: { head: 'His salmon flakes hop up with a sparkle, he giggles.', ear: 'Looks up at his rice corner, blushes, a little bow.', nose: 'Sniffs your finger politely, then a lick: a heart.', eye: 'Blinks and rubs his eye.',
        cheek: 'Leans in, blushing.', belly: 'Oh no, his seaweed jacket slips - he blushes and tugs it back.', side: 'Wobbles, a few rice grains fall, he looks.', foot: 'A neat little hop, rice grains fly.', tail: 'A grain of rice drops, he looks back.' },
      sunny: { head: 'Her shell cap pops up and drops back on, the yolk wobbles, she giggles.', ear: 'Looks at the tap on her shell and pats it.', nose: 'Sniffs your finger and licks it: a heart.', eye: 'Blinks and rubs her eye.',
        cheek: 'Leans into your finger, her cap lifting a little.', belly: 'Ticklish tummy: giggles, rocking on her round bottom.', side: 'Rolls a little away from the poke and wobbles back upright.', foot: 'Tap her round bottom: she rocks right over and wobbles back, giggling.', tail: 'A soft wobble, she looks back.' },
      toco: { head: 'His shell snaps shut and pops open, lettuce flies.', ear: 'Opens his shell and pats his lettuce back in.', nose: 'Sniffs, a crunchy little chomp, then licks your finger.', eye: 'Blinks and rubs his eye.',
        cheek: 'Leans in, his shell closing a little.', belly: 'Ticklish shell: giggles, snapping like castanets.', side: 'Wobbles, a lettuce leaf falls, he looks.', foot: 'Hops, his shell opens in the air.', tail: 'Snaps his shell, looks back.' },
      churro: { head: 'Sugar puffs off him and his ridges twist, he giggles.', ear: 'Reaches up and dabs his chocolate top.', nose: 'Sniffs your finger and licks it: a sweet heart.', eye: 'Blinks and rubs his eye.',
        cheek: 'Leans in, a little twist.', belly: 'Ticklish ridges: giggles, twisting like a corkscrew.', side: 'Twists away from the poke and back, looks.', foot: 'A hop, sugar falls.', tail: 'Sugar sprinkles off, he looks back.' },
      khinki: { head: 'His top knot flicks like a ponytail, he giggles.', ear: 'His pleats twist round from the poke.', nose: 'Sniffs your finger and licks it: a heart.', eye: 'Blinks and rubs his eye.',
        cheek: 'Leans into your finger, his knot tipping.', belly: 'So juicy: a squirt of broth, then he giggles, knot wagging.', side: 'A doughy wobble, his knot flicks, he looks.', foot: 'A hop, his knot bounces.', tail: 'A sprinkle of pepper, he looks back.' },
      maki: { head: 'His salmon and veggies pop up out of the rice, he giggles.', ear: 'Looks at his rice rim, the veggies bob.', nose: 'Sniffs your finger and licks it: a heart.', eye: 'Blinks and rubs his eye.',
        cheek: 'Leans into your finger.', belly: 'Ticklish rice: rocks with giggles, veggies wiggling.', side: 'Turns away like a spinning top and back.', foot: 'A hop, rice grains fly.', tail: 'A grain of rice falls, he looks back.' },
      noodle: { head: 'Steam puffs out, his noodles slurp, he giggles.', ear: s => s > 0 ? 'His chopsticks bob up and down with noodles.' : 'His noodles slurp up out of reach.', nose: 'Sniffs your finger, steam, then a lick: a heart.', eye: 'Blinks and rubs his eye.',
        cheek: 'Leans in, his chopsticks lifting a few noodles.', belly: 'Ticklish band: giggles, chopsticks bobbing.', side: 'Wobbles, a splash of broth, he looks.', foot: 'A hop that lifts his chopsticks.', tail: 'A puff of steam, he looks back.' },
      flossie: { head: 'Her floss poofs up big, she giggles.', ear: 'Her floss swirls round from the poke.', nose: 'Sniffs your finger and licks it: a sugary heart.', eye: 'Blinks and rubs her eye.',
        cheek: 'Leans into your finger, fluffing up.', belly: 'Ticklish floss: giggles and poofs.', side: 'Her floss swirls away from the poke and back.', foot: 'A hop, her floss poofs.', tail: 'A soft poof, she looks back.' },
    };
    build(RE, TXT, BODY);
  })();

  // =====================================================================================================================================
  // eating (all 20 foods, each its own way)
  (function boot() {
    const R = window.RiveRig; if (!R || !R.EATKIT || !R.snack2V || !R.EATLIB) { setTimeout(boot, 25); return; } if (R.snack2EatV) return; R.snack2EatV = 1;
    const { hand, both, o, NOHANDS, jump, swing, jelly } = R.PETLIB;
    const { EAR, sniffF, lipLick, hearts, pat, buildAll } = R.EATKIT;
    Object.assign(EAR, { frankie: 0.6, corny: 0.6, peppi: 0.6, nori: 0.6, sunny: 0.6, toco: 0.6, churro: 0.6, khinki: 0.6, maki: 0.6, noodle: 0.6, flossie: 0.6 });
    const hop = (t, h, x) => jump(t, o({ h: h || 6, ant: 140, up: 190, c: 0.14, arm: 40 }, x || {}));
    const CARDS = {
      frankie: { crumbs: 2, open: 0.8, armsUp: 1, txt: 'A squirt of mustard first, big happy bites, then hugs his sausage in his bun when he likes it.',
        pre: t => t.to(200, { hug: -0.5 }, 'o').e('emit', 'mustard', 'head', 2).to(220, { hug: 0 }, 'io'), post: t => lipLick(t),
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io').to(200, { hug: -0.7, sq: 0.05 }, 'o').to(300, { hug: 0, sq: 0 }, 'io'); hop(t, 6, { air: { slip: 0.4 }, fall: { slip: 0 } }); },
        love: t => { hearts(t, 2); CARDS.frankie.yum(t); } },
      corny: { chewMs: 115, chewN: 0.9, crumbs: 2, armsUp: 1, txt: 'Quick crunchy nibbles, fizzing with excitement; her popcorn pops when she likes it.',
        pre: t => { sniffF(t, 1); t.to(150, { cfz: 0.6 }, 'io'); }, post: t => t.to(200, { cfz: 0 }, 'io'),
        yum: t => { t.to(140, { hap: 1, smile: 1 }, 'io').to(100, { pop: 1 }, 'o').e('emit', 'popk', 'head', 3).to(380, { pop: 0 }, 'i'); },
        love: t => { hearts(t, 2); CARDS.corny.yum(t); hop(t, 6, { air: { pop: 0.8 }, fall: { pop: 0 } }); } },
      peppi: { savor: 0.5, chewMs: 140, crumbs: 1, open: 0.7, armsUp: 1, txt: 'Lazy, cheesy bites (a string of cheese stretches), then a floppy happy sway.',
        pre: t => sniffF(t, 1), post: t => t.to(200, { pull: 0.6 }, 'o').to(300, { pull: 0 }, 'i'),
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io'); swing(t, 1100, 3, { tilt: 5, flop: 0.6 }, 'io'); },
        love: t => { hearts(t, 2); t.to(300, { pull: 1, lift: 2 }, 'o').to(260, { pull: 0, lift: 0 }, 'i'); CARDS.peppi.yum(t); } },
      nori: { chewMs: 135, crumbs: 1, open: 0.55, armsUp: 1, txt: 'A polite little bow first, small neat bites, his salmon flakes hop when he likes it.',
        pre: t => t.to(300, { pitch: -0.16, close: 0.5 }, 'io').to(260, { pitch: 0, close: 0 }, 'io'), post: t => lipLick(t),
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io').to(140, { ume: 1 }, 'o').e('emit', 'spark', 'head', 2).to(300, { ume: 0 }, 'i'); },
        love: t => { hearts(t, 2); t.to(250, { blush: 1 }, 'io'); CARDS.nori.yum(t); } },
      sunny: { savor: 0.6, chewMs: 130, crumbs: 1, armsUp: 1, txt: 'Lifts her shell cap first (manners!), soft bites, her yolk wobbles when she likes it.',
        pre: t => t.to(260, { cap: 0.6 }, 'io').wait(150).to(260, { cap: 0 }, 'io'), post: t => lipLick(t),
        yum: t => { t.to(300, { hap: 1, smile: 1, cap: 0.7, wob: 1.2 }, 'io').wait(300).to(400, { cap: 0, wob: 0 }, 'io'); },
        love: t => { hearts(t, 2); hop(t, 6); CARDS.sunny.yum(t); } },
      toco: { chewMs: 110, chewN: 0.9, crumbs: 3, open: 0.9, armsUp: 1, txt: 'Opens his shell wide, big crunchy chomps (bits of lettuce fly), castanet snaps when he likes it.',
        pre: t => t.to(200, { snap: 0.8 }, 'o').wait(150).to(200, { snap: 0 }, 'io'), post: t => pat(t, 1),
        yum: t => { t.to(140, { hap: 1, smile: 1 }, 'io'); for (let i = 0; i < 2; i++) t.to(100, { snap: -0.5 }, 'o').to(180, { snap: 0.5 }, 'io').e('emit', 'lettuce', 'head', 1); t.to(150, { snap: 0 }, 'io'); },
        love: t => { hearts(t, 2); CARDS.toco.yum(t); } },
      churro: { chewMs: 120, crumbs: 2, armsUp: 1, txt: 'Dips it first like a churro in chocolate, crunchy bites, twists happily when he likes it.',
        pre: t => t.to(320, { pitch: -0.2, ly: 0.9, sq: 0.04 }, 'io').to(140, { sq: 0.07 }, 'o').to(300, { pitch: 0, ly: 0.3, sq: 0 }, 'io'), post: t => lipLick(t, true),
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io').to(400, { cork: 0.8 }, 'io').to(400, { cork: 0 }, 'io').e('emit', 'sugar', 'head', 3); },
        love: t => { hearts(t, 2); CARDS.churro.yum(t); } },
      khinki: { chewMs: 130, crumbs: 1, open: 0.75, armsUp: 1, txt: 'A careful first nibble and a slurp of the juice (the khinkali way), then big bites; his knot wags when he likes it.',
        pre: t => { sniffF(t, 1); t.to(200, { open: 0.25, mw: 0.5, puff: -0.3 }, 'io').wait(200).to(200, { open: 0, mw: 1, puff: 0 }, 'io'); }, post: t => lipLick(t),
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io').osc(800, 3, { knot: 0.6 }, { knot: -0.6 }, 'io').to(150, { knot: 0 }, 'io'); },
        love: t => { hearts(t, 2); t.e('emit', 'broth', 'head', 2); CARDS.khinki.yum(t); } },
      maki: { savor: 0.6, chewMs: 140, crumbs: 1, open: 0.55, armsUp: 1, txt: 'Calm, careful bites with his eyes closed; his salmon and veggies pop up when he likes it.',
        pre: t => t.to(260, { close: 0.7 }, 'io').wait(200).to(200, { close: 0 }, 'io'), post: t => lipLick(t),
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io').to(140, { veg: 1 }, 'o').to(300, { veg: 0 }, 'io'); swing(t, 1000, 3, { tilt: 6 }, 'io'); },
        love: t => { hearts(t, 2); CARDS.maki.yum(t); } },
      noodle: { chewMs: 125, crumbs: 1, open: 0.7, armsUp: 1, txt: 'Blows on it (steam), slurps it up, his chopsticks bob happily.',
        pre: t => t.to(250, { puff: 0.6, pitch: -0.08, ly: 0.6 }, 'io').to(160, { puff: -0.3, open: 0.3, mw: 0.5 }, 'o').e('emit', 'steam', 'mouth', 2).to(260, { puff: 0, open: 0, mw: 1, pitch: 0 }, 'io'),
        post: t => t.to(260, { slurp: 1 }, 'io').to(300, { slurp: 0 }, 'io'),
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io').osc(800, 3, { lid: 0.7 }, { lid: -0.2 }, 'io').to(150, { lid: 0 }, 'io').e('emit', 'steam', 'head', 2); },
        love: t => { hearts(t, 2); CARDS.noodle.yum(t); } },
      flossie: { savor: 0.7, chewMs: 150, chewN: 1, crumbs: 1, open: 0.55, armsUp: 1, txt: 'Dainty little bites, savours it dreamily, poofs up fluffy when she likes it.',
        pre: t => sniffF(t, 1), post: t => t.to(300, { close: 0.6, smile: 0.8 }, 'io').wait(250).to(250, { close: 0 }, 'io'),
        yum: t => { t.to(300, { hap: 1, smile: 1, fluff: 1 }, 'o').e('emit', 'floss', 'head', 2).to(600, { fluff: 0 }, 'io'); },
        love: t => { hearts(t, 2); t.to(300, { blush: 1 }, 'io'); CARDS.flossie.yum(t); } },
    };
    buildAll(CARDS);
  })();
})();
