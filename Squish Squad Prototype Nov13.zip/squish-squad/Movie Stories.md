# Movie Room: one movie per screen tier (stories for approval)

Each tier's screen plays its own movie. The stars are cartoon versions of the squad, drawn from their real art. Picture quality goes up with the tier. Creatures in the room react at the marked moments: 😂 laugh · 😮 gasp · 🎉 cheer · 🙈 hide · 💤 one or two doze off (long movies only).

Player: pause/resume, skip, progress bar, resume where you left off, and a picker for any unlocked movie. A better screen still plays the older movies, in its own better picture.

---

## Tier 1 · Bedsheet · 1 min · Comedy
### "The Great Cake Caper"
**Look:** a silent film shown on a wrinkled sheet. Sepia, film grain, flicker, a wobbly frame, a hair in the gate, title cards between scenes, ragtime piano.
**Stars:** Chef Bun, Cakey, Frybo.

| Time | Beat | Room |
|---|---|---|
| 0:00 | Title card "THE GREAT CAKE CAPER", then a countdown leader 3-2-1 | |
| 0:06 | Chef Bun proudly sets Cakey's birthday cake on the counter and leaves | |
| 0:12 | Frybo tiptoes in and sneaks one lick of frosting | 😂 |
| 0:20 | Chef Bun comes back, so Frybo freezes and pretends to be a lamp | 😂 |
| 0:28 | The chase: round the table and back, a pie in the face, a banana-peel slide | 😂 😂 |
| 0:42 | The cake flies up in the air. Everyone dives, and it lands on Cakey's head like a hat | 😮 then 🎉 |
| 0:52 | All three share the cake. Title card "THE END". The film burns through and flaps on the reel | 😂 |

---

## Tier 2 · Plasma TV · 2 min · Spooky-cute mystery
### "Who Ate the Moon Pie?"
**Look:** a fuzzy old TV picture. Scanlines, a little colour bleed, slight tracking roll, moody blues, spooky theremin music.
**Stars:** Boo (detective, with a tiny hat), Hoot (sidekick), Mochi, Puddi, Chip, Jinni (twist).

| Time | Beat | Room |
|---|---|---|
| 0:00 | A stormy night at the bakery. Lightning shows an empty plate: the Moon Pie is gone | 😮 |
| 0:15 | Boo floats in with a magnifying glass, and Hoot carries a lantern | |
| 0:25 | Suspect 1, Mochi: there's powder on his face. It turns out he just sneezed flour | 😂 |
| 0:45 | Suspect 2, Puddi: his caramel is smudged. He was only napping on a tray | 😂 |
| 1:00 | The lights go out. Two glowing eyes appear in the dark | 🙈 |
| 1:10 | The lights come back on. It was Chip's chocolate chips catching the light | 😂 |
| 1:25 | Boo follows crumbs to an old golden lamp. It rattles... | 🙈 |
| 1:40 | Jinni poofs out with crumbs on his chin: "I wished for a snack!" | 😮 then 😂 |
| 1:50 | Jinni wishes up a new giant Moon Pie for everyone. Boo tips his hat. Case closed | 🎉 |

---

## Tier 3 · 85" QLED · 3 min · Adventure / quest
### "The Lantern of Lost Woods"
**Look:** clean, bright, full colour, sharp edges, soft parallax backgrounds, sweeping orchestral music.
**Stars:** Lumi (hero, her lantern goes out), Acorn, Fawn, Teddy, Moss, Leo (guardian).

| Time | Beat | Room |
|---|---|---|
| 0:00 | Night falls on the forest. Lumi's lantern flickers and goes out, and the woods go dark | 😮 |
| 0:20 | An old map leads to the Glow Spring at the top of Mossy Mountain. Acorn and Fawn join her | |
| 0:40 | The river crossing: hopping across stepping stones. Acorn slips, and Fawn catches him | 😮 then 🎉 |
| 1:05 | Teddy is stuck in a honey tree. They pull him free and he joins the team | 😂 |
| 1:30 | The mushroom maze: Moss bounces them up and over the top | 🎉 |
| 1:55 | A thunderstorm on the cliff path, and a giant shadow with a mane blocks the way | 🙈 |
| 2:10 | It's Leo, who only roars because he's afraid of the dark too. Lumi shares a glow-bug | 💤 one friend |
| 2:30 | The Glow Spring. Lumi dips her lantern and it blazes, and the whole forest lights up | 🎉 🎉 |
| 2:50 | Everyone walks home in a line of lanterns. Credits roll over fireflies | |

---

## Tier 4 · 150" Laser Projection · 4 min · Space sci-fi
### "Squad Trek: Mission to Planet Sprinkle"
**Look:** a cinema widescreen frame (letterbox bars), deep blacks, glowing neon, lens flares, starfield parallax, a big synth score.
**Stars:** Zappi (captain), Twinkle (navigator), Nimbo (engineer), Octo (alien), Aurora (space whale), Pip (stowaway).

| Time | Beat | Room |
|---|---|---|
| 0:00 | Countdown on the launch pad. The ship (a polished teapot rocket) blasts off | 🎉 |
| 0:25 | The ship cruises past planets, and Pip pops out of a cargo box, a stowaway | 😂 |
| 0:50 | The mission: Planet Sprinkle's candy core is fading and must be recharged | |
| 1:10 | An asteroid field. Twinkle steers and Zappi's sparks blast rocks into sprinkles | 😮 |
| 1:45 | The engine breaks down. Nimbo drizzles on it to cool it and it hisses back to life | 😂 |
| 2:10 | Zero-g snack time: everyone floats and chases drifting pudding blobs | 😂 💤 one friend |
| 2:40 | A tractor beam pulls them into a giant alien ship. Octo appears, all tentacles | 🙈 |
| 3:00 | Octo is friendly, just lonely. He shows them the shortcut through a nebula | |
| 3:20 | Aurora the space whale carries the ship on her back to Planet Sprinkle | 😮 |
| 3:40 | The candy core recharges and the planet bursts into rainbow sprinkle fireworks | 🎉 🎉 |
| 3:52 | They fly home with Octo waving goodbye. "To be continued...?" | |

---

## Tier 5 · 16K MicroLED Holo-Screen · 5 min · Musical / dance
### "Squish Squad: The Musical"
**Look:** crystal clear, holographic shimmer at the edges, characters pop out past the screen frame on big moments, colour washes in time with the beat, a full song in five verses.
**Stars:** the whole squad. Each verse features one category, and the creatures dance their real signature dances in cartoon form.

| Time | Beat | Room |
|---|---|---|
| 0:00 | Curtain rise. Spotlight on Mittens: "Every friend has a groove..." | 🎉 |
| 0:30 | **Verse 1 · Snack Shack:** Mallow's Toasty Twirl, Frybo's Fry Shuffle, Bunbun's Stack Attack | 🎉 |
| 1:20 | **Verse 2 · Ocean:** Finn's Splash Dance, Octo's Tentacle Tango, Marina's Mermaid Splash, all underwater bubbles | 😮 |
| 2:10 | **Verse 3 · Fruit Patch:** Pina's Tropical Sway, Berri's Berry Bop, Peachy's Orchard Drop | 💤 one friend, woken by a cymbal crash 😂 |
| 3:00 | **Verse 4 · Dreamland:** Pixie's Pixie Jig, Drako's Rawr Rumble, Flicker's Phoenix Inferno, with fire, sparkles and rainbows | 😮 🎉 |
| 3:50 | **Bridge:** the music stops, the lights drop, and Boo whispers "...one more time?" | 🙈 |
| 4:00 | **Finale:** everyone at once in a giant formation. The holo-screen bursts out confetti that floats into the room | 🎉 🎉 🎉 |
| 4:45 | Bows in a line, curtain call, and the room creatures stand and dance along | 🎉 (everyone dances) |

---

### Open choices
- **Casting:** the creatures listed are suggestions, and I can swap in any favourites.
- **Owned friends cameo:** the friend sitting in the room could get a guest moment in each movie. I'd suggest yes for the musical, where your own creatures would join the finale.
- **Speech:** do you want speech bubbles, title cards only, or no words?
