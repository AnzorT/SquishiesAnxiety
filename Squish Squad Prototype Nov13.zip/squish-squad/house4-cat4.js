// Squad House v4 catalog, part 3: yard Games + garden decor, Dance Room LED lighting, customizable wall signs, dance-only ceiling rigs,
// more garden lights, size proportions pass, and shop categories (X.CATS / X.catOf / X.surfOk).
(function boot() {
  const X = window.House3D; if (!(X && X.EXT && X.shell && X.SPEC && X.ITEMS)) { setTimeout(boot, 20); return; } if (X.EXT2) return;
  const K = X.K, { solid, box, cyl, ball, slab, slabX, arcW, disc, prism, prismZ, legs4, shade, mix } = K;
  const NE = K.NEON, PI = Math.PI, GOLD = '#e2b14a', CH = '#d5dde2', CR = '#fffaf1', WH = '#ffffff', DK = '#36373c', INK = '#3a2a20', LEAF = '#5fa84a', BARK = '#8a5a34';
  const em = o => Object.assign({ emit: 1, noOut: 1 }, o || {});
  const neon = { y: 60, r: 90, c: 'url(#gNeon)' };
  const ring = (x, y, z, r, t, h, col, o) => arcW(x, y, z, r, r, t, h, 0, PI * 2, col, Object.assign({ n: 14 }, o || {}));
  const flame = (x, y, z, s) => [ball(x, y, z, 5 * s, '#ff9d2a', em({ sy: 1.7, k: 4, n: 10 })), ball(x, y + 2 * s, z + 1, 2.8 * s, '#ffe9a0', em({ sy: 1.6, k: 3, n: 8 }))];

  // ---------- yard games ----------
  const A4 = {
    hopscotch: S => ({ w: 74, d: 196, flat: 1, noBlock: 1, act: 'play', use: { x: 0, z: 0 }, build: P => { const cs = S.k === 'candy' ? NE : ['#fffaf1', '#ffd66b', '#9fd8ff', '#ffb3a0', '#b8f0a0', '#fffaf1'], o = [];
      [[0], [0], [-1, 1], [0], [-1, 1], [0], [-1, 1]].forEach((r, i) => r.forEach(c => o.push(box(c * 17, 0, 84 - i * 28, 32, 0.8, 26, cs[(i * 2 + c + 7) % 6], { r: 3, mat: 'paint' }))));
      o.push(ball(10, 0.8, 66, 4.5, S.k === 'royal' ? GOLD : '#e2554a', { sy: 0.4, k: 3, n: 8 })); return o; } }),
    hoop: S => ({ w: 72, d: 60, act: 'play', use: { x: 0, z: 92 }, build: P => { const k = S.k, pole = k === 'royal' ? GOLD : k === 'candy' ? WH : k === 'junk' ? '#8a8f94' : DK, bd = k === 'junk' ? '#c9a46a' : k === 'royal' ? '#7a1e2c' : WH, rim = k === 'royal' ? GOLD : '#ff7a2a';
      const o = [box(0, 0, -16, 46, 8, 34, k === 'junk' ? '#6b6f74' : shade(pole, 0.85), { r: 4 }), cyl(0, 8, -16, 3.2, 150, pole, { n: 8 }), box(0, 150, -12, 4, 4, 12, pole), slab(0, 128, -5, 66, 46, 3, bd, { r: 3 }),
        slab(0, 136, -3.2, 28, 22, 0.6, k === 'royal' ? GOLD : '#e2554a', { r: 1 }), slab(0, 138, -2.8, 23, 17, 0.6, bd, { r: 1 }), ring(0, 132, 9, 11, 1.6, 1.8, rim), cyl(0, 116, 9, 9.5, 16, '#f4f1ea', { n: 12, rg: [[0, 0, 0.65], [16, 0, 1]], mat: 'fab' })];
      if (k === 'candy') [30, 60, 90, 120].forEach((y, i) => o.push(cyl(0, 8 + y, -16, 3.5, 7, NE[i], { n: 8 })));
      o.push(ball(30, 0, 36, 10, '#ff8a3a', { k: 5, n: 12 })); return o; } }),
    goal: S => ({ w: 156, d: 62, act: 'play', use: { x: 0, z: 74 }, build: P => { const k = S.k, f = k === 'royal' ? GOLD : WH, net = k === 'candy' ? '#fff0fa' : '#e6ecef';
      return [cyl(-72, 0, 24, 2.8, 70, f, { n: 8 }), cyl(72, 0, 24, 2.8, 70, f, { n: 8 }), slabX(0, 67, 24, 150, 5.4, 5.4, f, { r: 2 }), slab(0, 0, -24, 144, 44, 1.2, net, { r: 2, mat: 'fab' }),
        prism(-73, -71, [[24, 0], [24, 68], [-24, 44], [-24, 0]], net, { mat: 'fab' }), prism(71, 73, [[24, 0], [24, 68], [-24, 44], [-24, 0]], net, { mat: 'fab' }), box(0, 0, -24, 150, 3, 4, f, { r: 1 }),
        ball(38, 0, 48, 9, WH, { k: 5, n: 12 }), ball(36, 12, 54, 2.6, DK, { sy: 0.5, k: 3, n: 6 })]; } }),
    toss: S => ({ w: 74, d: 116, act: 'play', use: { x: 0, z: 84 }, build: P => { const k = S.k, wd = k === 'candy' ? P.a : k === 'royal' ? '#7a1e2c' : P.w, st = k === 'royal' ? GOLD : P.b;
      return [prism(-32, 32, [[52, 0], [52, 5], [-52, 26], [-52, 0]], wd), prism(-7, 7, [[52.4, 5.2], [-52.4, 26.2], [-52.4, 27], [52.4, 6]], st), ball(0, 21.6, -30, 7.5, '#2a1c14', { sy: 0.18, k: 3, n: 12 }),
        box(-14, 0, 66, 13, 4, 13, P.b, { r: 4, soft: 1 }), box(14, 0, 72, 13, 4, 13, '#e2554a', { r: 4, soft: 1 }), box(6, 13, 12, 13, 4, 13, P.b, { r: 4, soft: 1 })]; } }),
    ringToss: S => ({ w: 64, d: 64, round: 1, act: 'play', use: { x: 0, z: 74 }, build: P => [cyl(0, 0, 0, 26, 5, S.k === 'royal' ? GOLD : P.w, { n: 16 }), cyl(0, 5, 0, 3, 46, P.a, { n: 8 }), ball(0, 50, 0, 4.4, P.b),
      ...[0, 1, 2].map(i => ring(0, 5.4 + i * 3, 0, 12 - i * 1.3, 3, 2.6, NE[i * 2])), ring(30, 0, 30, 11, 3, 2.6, NE[3])] }),
    tether: S => ({ w: 90, d: 90, round: 1, act: 'play', use: { x: 46, z: 46 }, build: P => { const k = S.k, pole = k === 'royal' ? GOLD : '#c9d3d8';
      return [cyl(0, 0, 0, 20, 6, k === 'royal' ? '#f4f1ea' : '#8a8f94', { n: 14 }), cyl(0, 6, 0, 2.4, 146, pole, { n: 8 }), ball(0, 150, 0, 3, pole), prismZ(-0.5, 0.5, [[-0.5, 148], [0.5, 148], [27, 100], [25.8, 100]], CR), ball(26, 82, 0, 12, k === 'royal' ? '#7a1e2c' : P.b)]; } }),
    sprinkler: S => ({ w: 64, d: 40, act: 'play', use: { x: 0, z: 54 }, build: P => { const o = [box(0, 0, 0, 30, 5, 18, S.k === 'mod' ? DK : '#5cb85c', { r: 4 }), cyl(0, 5, 0, 2, 8, CH, { n: 6 }), box(0, 13, 0, 46, 3, 4, CH, { r: 1.5 })];
      for (let i = 0; i <= 12; i++) { const a = PI * i / 12; o.push(ball(-48 * Math.cos(a), 14 + 44 * Math.sin(a), 0, 2.3, i % 3 ? '#bfe9ff' : '#ffffff', em({ k: 3, n: 8, op: 0.75 }))); } return o; } }),
    dome: S => ({ w: 144, d: 144, round: 1, act: 'play', use: { x: 0, z: 96 }, build: P => { const k = S.k, cs = k === 'candy' ? NE : k === 'royal' ? [GOLD, '#f4f1ea', GOLD] : [P.a, P.b, '#e2554a'], o = [];
      o.push(solid({ ax: 'z', sh: 'arc', c: [0, 0], a: 66, b: 66, th: 3.2, a0: 0, a1: PI, n: 14, rings: [[-1.6, 0], [1.6, 0]], col: cs[0] }), solid({ ax: 'x', sh: 'arc', c: [0, 0], a: 66, b: 66, th: 3.2, a0: 0, a1: PI, n: 14, rings: [[-1.6, 0], [1.6, 0]], col: cs[1] }));
      [[0, 66], [22, 62], [42, 50], [56, 34]].forEach(([y, r], i) => o.push(ring(0, y, 0, r, 3, 3, cs[(i + 2) % cs.length])));
      o.push(ball(0, 64, 0, 4, cs[0])); return o; } }),
    golf: S => ({ w: 164, d: 94, flat: 1, noBlock: 1, act: 'play', use: { x: 0, z: 0 }, build: P => { const k = S.k, g = k === 'candy' ? '#9fe0c4' : '#5cb85c';
      const o = [cyl(0, 0, 0, 80, 1.6, shade(g, 0.85), { rz: 46, n: 24 }), cyl(0, 1.6, 0, 75, 0.4, g, { rz: 42, n: 22, mat: 'fab' }), ball(42, 1.4, -10, 4.4, '#20160e', { sy: 0.15, k: 3, n: 10 }), cyl(42, 1.6, -10, 0.8, 42, WH, { n: 4 }),
        prismZ(-0.4, 0.4, [[42.8, 44], [60, 37], [42.8, 30]], k === 'royal' ? GOLD : '#e2554a'), ball(-34, 2, 16, 3, WH, { k: 3, n: 8 })];
      if (k === 'candy') [[-6, -16], [16, 18]].forEach(([x, z], i) => o.push(cyl(x, 2, z, 1, 14, WH, { n: 4 }), disc(x, 18, z, 8, 2, NE[i * 2])));
      return o; } }),
    pong: S => ({ w: 152, d: 86, act: 'play', use: { x: 0, z: 74 }, build: P => { const k = S.k, top = k === 'candy' ? P.a : k === 'royal' ? '#2f6a4a' : '#2f6f8a';
      return [...legs4(64, 34, 36, k === 'royal' ? GOLD : DK, 2.6), box(0, 36, 0, 152, 4, 86, top, { r: 2, mat: 'paint' }), box(0, 40, 41.6, 152, 0.4, 1.4, WH), box(0, 40, -41.6, 152, 0.4, 1.4, WH), box(0, 40, 0, 152, 0.4, 1, WH),
        box(0, 40, 0, 2, 10, 90, '#f4f1ea', { mat: 'fab' }), cyl(-52, 40, 20, 8, 1.2, '#e2554a', { n: 12 }), box(-52, 40.4, 30, 3, 1, 9, '#a86b36'), ball(22, 40, -12, 2.6, '#ff9d4a', { k: 3, n: 8 })]; } }),
    // ---------- garden decor + lights ----------
    gnome: S => ({ w: 34, d: 34, round: 1, build: P => { const k = S.k, hat = k === 'royal' ? GOLD : '#e2554a', coat = k === 'candy' ? NE[4] : '#3f7fc4';
      return [cyl(0, 0, 0, 12, 4, '#8a8f94', { n: 12 }), cyl(-5, 4, 2, 4, 6, '#5a3a24', { n: 8 }), cyl(5, 4, 2, 4, 6, '#5a3a24', { n: 8 }), cyl(0, 9, 0, 11, 18, coat, { n: 12, rg: [[0, 0, 1], [18, 0, 0.7]] }), ball(0, 22, 4, 7.5, '#f4f1ea', { sy: 1.3, sz: 0.7 }), ball(0, 28, 1, 6.5, '#f2c7a0'), ball(0, 30, 7, 2.6, '#e88a7a', { k: 3, n: 8 }), cyl(0, 34, 0, 7.4, 20, hat, { n: 12, rg: [[0, 0, 1], [20, 0, 0.05]] })]; } }),
    birdbath: S => ({ w: 60, d: 60, round: 1, build: P => { const st = S.k === 'royal' ? '#f4f1ea' : '#c9c3b8';
      return [cyl(0, 0, 0, 16, 6, st, { n: 14, mat: 'paint' }), cyl(0, 6, 0, 6, 40, st, { n: 12, rg: [[0, 0, 1.3], [20, 0, 0.8], [40, 0, 1.2]], mat: 'paint' }), cyl(0, 46, 0, 26, 8, st, { n: 18, rg: [[0, 0, 0.6], [8, 0, 1]], mat: 'paint' }), cyl(0, 53, 0, 22, 0.6, '#9fd8f2', em({ n: 18, op: 0.85 })),
        ball(12, 54, -6, 5, '#7fa8d8', { sx: 1.3 }), ball(17, 59, -6, 3.4, '#7fa8d8'), box(21, 60, -6, 3, 1.4, 2, '#ff9d4a', { r: 0.5 }), ...(S.k === 'royal' ? [cyl(0, 54, 0, 26.4, 2, GOLD, { n: 18 })] : [])]; } }),
    flowerBed: S => ({ w: 130, d: 44, build: P => { const k = S.k, ed = k === 'royal' ? '#f4f1ea' : k === 'candy' ? P.a : '#a86b36', o = [box(0, 0, 0, 130, 12, 44, ed, { r: 3 }), box(0, 12, 0, 122, 1.6, 36, '#5a3a24', { r: 2, mat: 'paint' })];
      for (let i = 0; i < 14; i++) { const x = -54 + (i % 7) * 18 + (i > 6 ? 9 : 0), z = i > 6 ? 8 : -8, h = 10 + (i * 7) % 9, c = k === 'candy' ? NE[i % 6] : ['#e2554a', '#ffd23f', '#f4f1ea', '#c4a0e0', '#ff9d4a'][i % 5];
        o.push(cyl(x, 13, z, 0.9, h, LEAF, { n: 4 }), ball(x - 3, 13 + h * 0.4, z, 3.4, LEAF, { sy: 0.5, k: 3, n: 6 }), ball(x, 13 + h, z, 4.6, c, { k: 4, n: 10 }), ball(x, 15 + h, z + 3, 1.6, '#ffd23f', { k: 3, n: 6 })); }
      return o; } }),
    stones: S => ({ w: 150, d: 120, flat: 1, noBlock: 1, build: P => [[-56, 40, 15], [-22, 18, 13], [12, -4, 16], [46, -28, 13], [66, -50, 11]].map(([x, z, r], i) => cyl(x, 0, z, r, 2.4, S.k === 'royal' ? (i % 2 ? '#f4f1ea' : '#e6dcc8') : ['#b9b2a6', '#a8a196', '#c4beb2'][i % 3], { rz: r * 0.72, n: 14, mat: 'paint' })) }),
    spinner: S => ({ w: 40, d: 40, round: 1, build: P => { const o = [cyl(0, 0, 0, 2, 90, S.k === 'royal' ? GOLD : CH, { n: 6 })], cs = NE;
      for (let i = 0; i < 6; i++) { const a = i / 6 * PI * 2, b = a + 0.9; o.push(prismZ(5, 6, [[0, 92], [Math.cos(a) * 22, 92 + Math.sin(a) * 22], [Math.cos(b) * 14, 92 + Math.sin(b) * 14]], cs[i])); }
      o.push(disc(0, 92, 6, 3, 2, WH)); return o; } }),
    urn: S => ({ w: 54, d: 54, round: 1, build: P => [cyl(0, 0, 0, 14, 6, GOLD, { n: 14 }), cyl(0, 6, 0, 22, 34, '#f4f1ea', { n: 16, rg: [[0, 0, 0.5], [16, 0, 1], [30, 0, 0.9], [34, 0, 1.1]], mat: 'paint' }), cyl(0, 30, 0, 22.6, 3, GOLD, { n: 16 }), ball(0, 38, 0, 24, '#4f9a44', { mat: 'fab' }), ball(-8, 56, 6, 10, '#6fae50', { mat: 'fab' })] }),
    tiki: S => ({ w: 30, d: 30, round: 1, glow: () => ({ y: 112, r: 70 }), build: P => { const k = S.k, c = k === 'royal' ? GOLD : '#c9a46a';
      return [cyl(0, 0, 0, 8, 4, '#5a4020', { n: 10 }), cyl(0, 4, 0, 2.6, 96, c, { n: 8 }), ...[24, 48, 72].map(y => cyl(0, y, 0, 3, 2, shade(c, 0.7), { n: 8 })), cyl(0, 98, 0, 7, 10, k === 'royal' ? GOLD : '#8a6a3e', { n: 10, rg: [[0, 0, 0.6], [10, 0, 1]] }), ...flame(0, 108, 0, 1.4)]; } }),
    solar: S => ({ w: 140, d: 30, glow: () => ({ y: 30, r: 90 }), build: P => { const o = [], c = S.k === 'royal' ? GOLD : '#3a3d44';
      [-54, -18, 18, 54].forEach(x => o.push(cyl(x, 0, 0, 1.6, 26, c, { n: 6 }), cyl(x, 26, 0, 6, 8, '#fff1b8', em({ n: 10 })), cyl(x, 34, 0, 7.4, 2, c, { n: 10 }), box(x, 36, 0, 10, 1, 10, '#2c3a5a', { r: 1, mat: 'metal' }))); return o; } }),
    // ---------- Dance Room LED lighting ----------
    ledWall: S => ({ w: 132, d: 8, mount: 'wall', elev: 36, act: 'party', party: 1, glow: () => ({ y: 40, r: 100, c: 'url(#gNeon)' }), build: (P, v) => { const on = v === 'on', o = [slab(0, 0, -1, 126, 82, 4, '#1b1d2a', { r: 4, mat: 'metal' })];
      for (let i = 0; i < 10; i++) for (let j = 0; j < 6; j++) { const c = S.k === 'candy' ? NE[(i + j) % 6] : NE[(i * 2 + j * 3) % 6], lit = on || (i * 7 + j * 3) % 4 !== 0; o.push(box(-54 + i * 12, 4 + j * 12.6, 1.4, 9.4, 9.4, 1, lit ? c : shade(c, 0.4), lit ? em({ r: 2 }) : { r: 2, noOut: 1 })); }
      return o; } }),
    laser: S => ({ w: 42, d: 42, round: 1, act: 'party', party: 1, glow: () => ({ y: 150, r: 90, c: 'url(#gNeon)' }), build: (P, v) => { const on = v === 'on', body = S.k === 'royal' ? GOLD : '#23252e', cs = ['#ff3b6b', '#4fe0d0', '#a6f06a', '#8f7bff', '#ffd66b'];
      const o = [cyl(0, 0, 0, 17, 6, body, { n: 14, mat: 'metal' }), cyl(0, 6, 0, 9, 100, body, { n: 12, mat: 'metal' }), ...[26, 50, 74].map((y, i) => cyl(0, y, 0, 9.6, 3, NE[i * 2], em({ n: 12 }))), box(0, 106, 0, 24, 15, 24, body, { r: 5, mat: 'metal' }), ball(0, 109, 12, 4.6, '#ff4fd8', em({ k: 3, n: 8 }))];
      const n = on ? 5 : 3; for (let i = 0; i < n; i++) { const a = -0.85 + i * 1.7 / (n - 1), ex = Math.sin(a) * 120, ey = 114 + Math.cos(a) * 100; o.push(prismZ(12, 13, [[-1, 114], [1, 114], [ex + 2, ey], [ex - 2, ey]], cs[i], em({ op: 0.7 }))); }
      return o; } }),
    infinity: S => ({ w: 92, d: 8, mount: 'wall', elev: 42, act: 'party', party: 1, glow: () => ({ y: 40, r: 80, c: 'url(#gNeon)' }), build: (P, v) => { const sh = v === 'on' ? 1 : 0, o = [slab(0, 0, -1, 86, 82, 4, S.k === 'royal' ? GOLD : '#2a2c38', { r: 12, mat: 'metal' }), slab(0, 4, 1.2, 78, 74, 1, '#0b0d18', { r: 9, noOut: 1 })];
      for (let i = 0; i < 6; i++) { const s = 1 - i * 0.15, zz = 2 + i * 0.7; o.push(slab(0, 41 - 35 * s, zz, 72 * s, 70 * s, 0.3, NE[(i + sh) % 6], em({ r: 9 * s })), slab(0, 41 - 35 * s + 2.6, zz + 0.35, 72 * s - 5.2, 70 * s - 5.2, 0.3, '#0b0d18', { r: 8 * s, noOut: 1 })); }
      return o; } }),
    ledArch: S => ({ w: 156, d: 76, act: 'party', party: 1, glow: () => ({ y: 70, r: 110, c: 'url(#gNeon)' }), build: (P, v) => { const base = S.k === 'royal' ? GOLD : '#2a2c38', cs = S.k === 'candy' ? [NE[0], NE[2], NE[4]] : S.k === 'royal' ? ['#fff1b8', '#cdb8f5', '#bff0ff'] : ['#4fe0d0', '#8f7bff', '#ff4fd8'], o = [];
      [-30, 0, 30].forEach((z, i) => o.push(solid({ ax: 'z', sh: 'arc', c: [0, 0], a: 72, b: 94, th: 7, a0: 0, a1: PI, n: 14, rings: [[z - 2.6, 0], [z + 2.6, 0]], col: base }), solid({ ax: 'z', sh: 'arc', c: [0, 0], a: 68.4, b: 90.4, th: 2.4, a0: 0.05, a1: PI - 0.05, n: 14, rings: [[z + 2.7, 0], [z + 3.3, 0]], col: cs[(i + (v === 'on' ? 1 : 0)) % 3], emit: 1, noOut: 1 }), box(-72, 0, z, 12, 4, 9, base), box(72, 0, z, 12, 4, 9, base)));
      return o; } }),
    spot: S => ({ w: 62, d: 62, round: 1, act: 'party', party: 1, glow: () => ({ y: 96, r: 80, c: 'url(#gNeon)' }), build: (P, v) => { const c = S.k === 'royal' ? GOLD : '#2a2c38', lit = v === 'on' ? WH : '#ffe9a0';
      return [box(0, 0, 0, 4, 4, 54, c, { yaw: 0 }), box(0, 0, 0, 4, 4, 54, c, { yaw: PI / 3 }), box(0, 0, 0, 4, 4, 54, c, { yaw: -PI / 3 }), cyl(0, 0, 0, 2.4, 72, CH, { n: 6 }), box(0, 72, 0, 28, 6, 16, c, { r: 2, mat: 'metal' }), box(-13, 78, 0, 3, 18, 10, c), box(13, 78, 0, 3, 18, 10, c),
        ball(0, 78, 0, 12, '#22242e', { sx: 0.95, mat: 'metal' }), disc(0, 90, 10, 7.4, 1.6, lit, em()), prismZ(12, 13, [[-6, 92], [6, 92], [36, 176], [-14, 176]], '#fff6c8', em({ op: 0.35 }))]; } }),
    crystal: S => ({ w: 62, d: 62, round: 1, act: 'party', party: 1, glow: () => ({ y: 70, r: 90, c: 'url(#gNeon)' }), build: (P, v) => { const cs = ['#dff2fb', '#cdb8f5', '#bff0dc', '#fff1b8', '#ffd6f2'], o = [cyl(0, 0, 0, 25, 10, GOLD, { n: 16 }), cyl(0, 10, 0, 19, 4, '#7a1e2c', { n: 16, soft: 1 })];
      [[-12, 46, -4], [0, 74, 0], [12, 54, 4], [-4, 36, 10], [8, 30, -10]].forEach(([x, h, z], i) => o.push(prismZ(z - 4, z + 4, [[x - 6, 14], [x + 6, 14], [x + 4, 14 + h], [x, 14 + h + 10], [x - 4, 14 + h]], cs[(i + (v === 'on' ? 2 : 0)) % 5], em({ op: 0.88 }))));
      return o; } }),
    gcube: S => ({ w: 46, d: 46, act: 'sit', party: 1, seats: [{ x: 0, z: 0, h: 42 }], glow: () => ({ y: 20, r: 50, c: 'url(#gNeon)' }), build: (P, v) => { const c = S.k === 'candy' ? (v === 'on' ? '#ffd66b' : '#ff9de6') : (v === 'on' ? '#8f7bff' : '#4fe0d0');
      return [box(0, 0, 0, 44, 40, 44, c, { r: 6, emit: 1 }), box(0, 40, 0, 40, 1.5, 40, WH, em({ r: 6, op: 0.55 }))]; } }),
  };

  // ---------- customizable wall signs (text is per placed piece: it.txt) ----------
  const SIGNS = {
    card: { W: 160, H: 94, z: 0.4, elev: 40 }, chalk: { W: 172, H: 106, z: 2.6, elev: 44 }, marq: { W: 196, H: 100, z: 4, elev: 44 },
    neon: { W: 212, H: 92, z: 2.2, elev: 46 }, led: { W: 222, H: 80, z: 2.8, elev: 50 }, royal: { W: 212, H: 112, z: 3, elev: 42 } };
  X.SIGNST = {
    card: { ff: "'Permanent Marker', 'Comic Sans MS', cursive", col: '#2a1a10', sh: '0 0 1px rgba(42,26,16,0.4)', rot: -3, cw: 0.62 },
    chalk: { ff: "'Gochi Hand', 'Comic Sans MS', cursive", col: '#f4f1ea', sh: '0 0 1.5px rgba(255,255,255,0.7)', rot: 0, cw: 0.55 },
    marq: { ff: "'Limelight', Georgia, serif", col: '#c4312f', sh: '0 1px 0 rgba(255,255,255,0.6)', rot: 0, cw: 0.66 },
    neon: { ff: "'Pacifico', 'Brush Script MT', cursive", col: '#ffffff', sh: '0 0 2px #ffffff, 0 0 6px #ff4fd8, 0 0 14px #ff4fd8, 0 0 26px #ff4fd8', rot: -4, cw: 0.6 },
    led: { ff: "'VT323', 'Courier New', monospace", col: '#ffcf6a', sh: '0 0 3px #ff9d4a, 0 0 9px #ff6a00', rot: 0, cw: 0.5, ls: '0.08em' },
    royal: { ff: "'Cinzel Decorative', Georgia, serif", col: '#ffe9a0', sh: '0 1px 0 #4a2c14, 0 0 6px rgba(255,214,107,0.7)', rot: 0, cw: 0.72 } };
  A4.sign = S => { const st = S.st, G = SIGNS[st], W = G.W, H = G.H, lit = st === 'marq' || st === 'neon' || st === 'led';
    return { w: W + 8, d: 8, mount: 'wall', elev: G.elev, sign: st, face: { y: H / 2, z: G.z, w: W - (st === 'card' ? 14 : 22), h: H - (st === 'card' ? 18 : 24) }, txt: 'DANCE!', glow: lit ? () => ({ y: H / 2, r: W * 0.65, c: 'url(#gNeon)' }) : null,
      build: P => { const o = [];
        if (st === 'card') { o.push(slab(0, 0, -1, W, H, 2.4, '#c99a62', { r: 2, mat: 'wood' }), slab(0, H - 6, 0.4, W - 4, 2, 0.4, '#b88850', { r: 0, noOut: 1 }), slab(-W / 2 + 10, H - 10, 0.8, 22, 9, 0.4, '#f6efc8', { r: 0, op: 0.8, noOut: 1 }), slab(W / 2 - 12, -2, 0.8, 22, 9, 0.4, '#f6efc8', { r: 0, op: 0.8, noOut: 1 }), slab(W / 2 - 8, H - 12, 0.6, 10, 10, 0.4, '#a87a44', { r: 0, noOut: 1 })); }
        else if (st === 'chalk') { o.push(slab(0, 0, -1, W, H, 3.6, '#a86b36', { r: 3, mat: 'wood' }), slab(0, 6, 1, W - 12, H - 12, 1, '#2f4a3a', { r: 2, mat: 'paint' }), box(0, -4, 3, W - 20, 3, 6, '#a86b36', { r: 1 }), box(-24, -1, 4, 12, 2.4, 2.4, WH, { r: 1 }), box(-8, -1, 4.6, 9, 2.4, 2.4, '#ffb3c8', { r: 1 })); }
        else if (st === 'marq') { o.push(slab(0, 0, -1, W, H, 6, '#b8282a', { r: 6, mat: 'metal' }), slab(0, 8, 2.2, W - 16, H - 16, 1, '#fff6e2', { r: 4, mat: 'paint' }));
          const n = 9, m = 4; for (let i = 0; i < n; i++) { const x = -W / 2 + 8 + i * (W - 16) / (n - 1); o.push(ball(x, H - 7, 2.4, 2.6, '#fff1a8', em({ k: 3, n: 8 })), ball(x, 1.8, 2.4, 2.6, '#fff1a8', em({ k: 3, n: 8 }))); }
          for (let j = 1; j < m; j++) { const y = 2 + j * (H - 10) / m; o.push(ball(-W / 2 + 4, y, 2.4, 2.6, '#fff1a8', em({ k: 3, n: 8 })), ball(W / 2 - 4, y, 2.4, 2.6, '#fff1a8', em({ k: 3, n: 8 }))); } }
        else if (st === 'neon') { o.push(slab(0, 0, -0.5, W, H, 2, '#cfe6f7', { r: 8, op: 0.55, mat: 'cer' }), slab(0, 3, -1.8, W - 6, H - 6, 0.6, '#1b1030', { r: 7, op: 0.5, noOut: 1 }), ...[[-W / 2 + 8, H - 8], [W / 2 - 8, H - 8], [-W / 2 + 8, 8], [W / 2 - 8, 8]].map(([x, y]) => disc(x, y, 0.5, 2.6, 2.4, CH))); }
        else if (st === 'led') { o.push(slab(0, 0, -1, W, H, 5, '#14151c', { r: 4, mat: 'metal' }), slab(0, 5, 1.6, W - 10, H - 10, 0.6, '#262017', { r: 2, noOut: 1 }), box(-W / 2 + 14, H - 4, 1, 4, 6, 4, '#3a3d44'), box(W / 2 - 14, H - 4, 1, 4, 6, 4, '#3a3d44')); }
        else if (st === 'royal') { o.push(slab(0, 0, -1, W, H, 5, GOLD, { r: 8 }), slab(0, 6, 1.6, W - 12, H - 12, 1, '#7a1e2c', { r: 5, soft: 1 }), prismZ(0, 4, [[-30, H], [-18, H + 14], [-8, H + 6], [0, H + 20], [8, H + 6], [18, H + 14], [30, H]], GOLD), ball(0, H + 20, 2, 4, '#e2554a', { k: 3, n: 8 })); }
        return o; } }; };

  // ---------- register ----------
  const L = 'living', Dn = 'dance', Y = 'backyard';
  const NEW = [
    [8, 'g_chalkHop', 'Chalk Hopscotch', Y, 'hopscotch'], [8, 'g_oldSprk', 'Garden Sprinkler', Y, 'sprinkler'], [9, 'g_drvHoop', 'Driveway Hoop', Y, 'hoop'], [9, 'y_gnome', 'Garden Gnome', Y, 'gnome'], [10, 'g_yGoal', 'Backyard Goal', Y, 'goal'],
    [10, 'y_stones', 'Stepping Stones', Y, 'stones'], [11, 'g_ringT', 'Ring Toss', Y, 'ringToss'], [12, 'g_toss', 'Beanbag Toss', Y, 'toss'], [12, 'y_bath', 'Stone Bird Bath', Y, 'birdbath'], [13, 'y_bed', 'Flower Bed', Y, 'flowerBed'],
    [14, 'g_tether', 'Tetherball', Y, 'tether'], [15, 'g_pong', 'Ping-Pong Table', Y, 'pong'], [15, 'y_tiki', 'Tiki Torch', Y, 'tiki'], [16, 'g_dome', 'Climbing Dome', Y, 'dome'], [17, 'g_proHoop', 'Pro Hoop', Y, 'hoop'],
    [17, 'y_solar', 'Solar Path Lights', Y, 'solar'], [18, 'g_putt', 'Putting Green', Y, 'golf'], [19, 'g_proGoal', 'Pro Soccer Goal', Y, 'goal'], [20, 'y_spin', 'Wind Spinner', Y, 'spinner'], [21, 'g_cPong', 'Candy Ping-Pong', Y, 'pong'],
    [22, 'g_jToss', 'Jellybean Toss', Y, 'toss'], [23, 'g_cHop', 'Rainbow Hopscotch', Y, 'hopscotch'], [24, 'g_cGolf', 'Candy Mini Golf', Y, 'golf'], [25, 'g_gHoop', 'Gumball Hoop', Y, 'hoop'], [26, 'g_sky', 'Sky Climber', Y, 'dome'],
    [27, 'y_urn', 'Royal Garden Urn', Y, 'urn'], [28, 'g_rTether', 'Royal Tetherball', Y, 'tether'], [28, 'y_rTiki', 'Golden Torch', Y, 'tiki'], [29, 'g_gHoop2', 'Golden Hoop', Y, 'hoop'], [29, 'y_rGnome', 'Royal Gnome', Y, 'gnome'],
    [11, 'x_sgCard', 'Cardboard Sign', Dn, 'sign', { st: 'card' }, 20], [13, 'x_sgChalk', 'Chalkboard Sign', Dn, 'sign', { st: 'chalk' }], [16, 'x_sgMarq', 'Marquee Bulb Sign', Dn, 'sign', { st: 'marq' }],
    [20, 'x_sgNeon', 'Neon Script Sign', Dn, 'sign', { st: 'neon' }], [24, 'x_sgLed', 'LED Ticker Sign', Dn, 'sign', { st: 'led' }], [29, 'x_sgRoyal', 'Royal Gold Marquee', Dn, 'sign', { st: 'royal' }],
    [16, 'x_ledWall', 'LED Light Wall', Dn, 'ledWall'], [18, 'x_laser', 'Laser Tower', Dn, 'laser'], [19, 'x_gcube', 'Glow Cube Seat', Dn, 'gcube'], [20, 'x_spot', 'Moving-Head Spotlight', Dn, 'spot'], [21, 'x_infin', 'Infinity Mirror', Dn, 'infinity'],
    [23, 'x_cLed', 'Rainbow LED Wall', Dn, 'ledWall'], [24, 'x_ledArch', 'LED Tunnel Arch', Dn, 'ledArch'], [25, 'x_cCube', 'Candy Glow Cube', Dn, 'gcube'], [27, 'x_auArch', 'Aurora Light Arch', Dn, 'ledArch'], [28, 'x_crysS', 'Crystal Light Sculpture', Dn, 'crystal'],
    [29, 'x_rLaser', 'Royal Laser Tower', Dn, 'laser'], [30, 'x_rInf', 'Royal Infinity Mirror', Dn, 'infinity'],
  ];
  const WT = { hopscotch: 0.6, sprinkler: 0.6, hoop: 1.2, gnome: 0.4, goal: 1.3, stones: 0.5, ringToss: 0.7, toss: 0.9, birdbath: 0.7, flowerBed: 0.8, tether: 1, pong: 1.6, tiki: 0.5, dome: 1.8, solar: 0.6, golf: 1.4, spinner: 0.5, urn: 0.9,
    sign: 0.8, ledWall: 1.8, laser: 1.6, gcube: 0.9, spot: 1.4, infinity: 1.6, ledArch: 2.4, crystal: 2 };
  const BK = {}; X.BANDS.forEach(b => BK[b.k] = b);
  NEW.forEach(([lv, id, n, room, arch, ex, fixed]) => { const band = X.bandOf(lv).k, S = Object.assign({ k: band }, ex || {}), D = A4[arch](S), price = fixed || Math.round((50 + lv * 28) * (WT[arch] || 1) / 10) * 10;
    Object.assign(D, { n, cat: room, price, cols: BK[band].cols, lv, band, arch, room, start: false, id }); if (D.mount || D.small) D.noBlock = 1; X.CAT[id] = D;
    X.ITEMS.push({ id, n, room, lv, band, arch, price, start: false, hidden: false, surf: false }); });
  Object.assign(X.ARCH, A4);

  // dance-only ceiling rigs + more garden lights (surfaces)
  Object.assign(X.SPEC, { l_halo: { k: 'halo' }, l_laser: { k: 'laser' }, l_truss: { k: 'truss' }, l_crys: { k: 'crys' }, yl_fairy: { k: 'fairy' }, yl_festoon: { k: 'festoon' }, yl_lantern: { k: 'lantern' }, yl_torch: { k: 'torch' } });
  [[16, 'l_halo', 'LED Halo Rings', 'style', 'light', 'dance'], [19, 'l_laser', 'Laser Light Rig', 'style', 'light', 'dance'], [23, 'l_truss', 'Spotlight Truss', 'style', 'light', 'dance'], [28, 'l_crys', 'Crystal LED Chandelier', 'style', 'light', 'dance'],
    [10, 'yl_fairy', 'Fairy Lights', Y, 'ylight'], [18, 'yl_festoon', 'Festoon Bulbs', Y, 'ylight'], [22, 'yl_lantern', 'Paper Lanterns', Y, 'ylight'], [27, 'yl_torch', 'Garden Torches', Y, 'ylight']].forEach(([lv, id, n, room, arch, only]) => {
    const price = Math.round((50 + lv * 28) * (arch === 'light' ? 1.1 : 0.9) / 10) * 10, m = { id, n, room, lv, band: X.bandOf(lv).k, arch, price, start: false, hidden: false, surf: true }; if (only) m.only = only; X.SURF[id] = m; X.ITEMS.push(m); });
  X.ITEMS.sort((a, b) => a.lv - b.lv);

  // ---------- proportions: creature ~96 units tall, counters ~80, seats ~40 ----------
  const rescale = (D, f) => { if (!f || Math.abs(f - 1) < 1e-3) return; D.zs = (D.zs || 1) * f; D.w *= f; D.d *= f; if (D.use) D.use = Object.assign({}, D.use, { x: D.use.x * f, z: D.use.z * f });
    if (D.seats) D.seats = D.seats.map(s => Object.assign({}, s, { x: s.x * f, z: s.z * f, h: s.h * f })); };
  const ramp = (D, k) => 1 + Math.max(0, Math.min(1, ((D.lv || 1) - 6) / 24)) * k;
  Object.values(X.CAT).forEach(D => { if (!['tv', 'tvstand', 'wallTV', 'projector'].includes(D.arch) || D.small || D.id === 'radio' || !D.zs) return;
    const f = ramp(D, 0.45) / ramp(D, 0.9); rescale(D, f); if (D.mount && D.elev) D.elev = Math.round(D.elev / Math.sqrt(f));
    const cap = D.arch === 'projector' ? 560 : D.arch === 'wallTV' ? 430 : 0; if (cap && D.w * X.FS > cap) rescale(D, cap / (D.w * X.FS)); });
  const TBF = { tbToaster: 0.66, tbTeapot: 0.7, tbJar: 0.66, tbCake: 0.62, tbFruit: 0.66, tbMixer: 0.64, tbCup: 0.7, tbPerfume: 0.72, tbSoap: 0.72, tbDuck: 0.75, tbBooks: 0.75, tbClock: 0.7, tbRadio: 0.68, tbGlobe: 0.68, tbSnow: 0.72, tbTrophy: 0.72, tbCandles: 0.68, tbBox: 0.72, tbVase: 0.62, miniTV: 0.72, handheld: 0.6 };
  Object.values(X.CAT).forEach(D => { const f = TBF[D.arch]; if (f && D.small) rescale(D, f); });
  X.CACHE.clear();
  // live per-type size tuning (dev sizes panel): D._uk = user scale; topOf follows host zs changes
  X.rescale = rescale;
  const topBase = X.topOf; X.topOf = t => { const D = X.CAT[t]; if (D && D._tz == null) D._tz = D.zs || 1; const v = topBase(t); return D ? v / D._tz * (D.zs || 1) : v; };
  // locked sizes (Living Room pass, tuned against creatures at x1.09)
  X.CRDEF = 1.09;
  X.SZDEF = { bookcase: 2.15, wallTV: 1.45, aquaCol: 0.5, handheld: 1.05, dj: 1.7, projector: 1.25, arcade: 1.05, stage: 2.5, tv: 1.2, pit: 1.35, poster: 1.05 };
  // ratio pass: every other type scaled to a target height in creatures (front-edge height / creature height at x1.09, creature = 1)
  // e.g. fridge 2, wardrobe 2.2, shower 2.2, counter/stove 1, table 0.6, sofa/armchair 0.75, stool 0.5, tabletop pieces 0.15-0.5
  Object.assign(X.SZDEF, { sofa: 1.09, armchair: 1.09, lsofa: 1.15, usofa: 1.15, longSofa: 1.15, modEnd: 1.15, modMid: 1.15, modCorner: 1.15, plant: 1.18, lamp: 1.26, pouf: 0.8, beanpile: 1.22, tvstand: 0.83,
    monstera: 1.24, pottedPalm: 1.45, cactus: 1.18, flowerPot: 0.92, aquaBig: 1.09, mushLamp: 1.21, lowShelf: 1.15,
    fridge: 1.5, hutch: 1.55, table: 0.86, chair: 1.16, stool: 1.22, bowl: 1.25,
    tub: 1.11, bsink: 1.45, basket: 1.19, rack: 1.54, shower: 1.49,
    bed: 1.2, nightstand: 0.91, wardrobe: 1.46, chest: 0.85, dresser: 1.23,
    swing: 1.23, pool: 1.14, slide: 1.32, stand: 1.29, grill: 1.32, tramp: 1.25, house: 1.58, merry: 0.86, tree: 1.81, fountain: 1.27, bush: 1.09, sunflower: 1.27, lantern: 1.1,
    hoop: 1.48, goal: 1.47, ringToss: 1.09, toss: 1.2, birdbath: 1.48, tether: 1.37, pong: 1.28, tiki: 1.3, dome: 1.49, spinner: 1.25, urn: 1.13, sprinkler: 0.86,
    juke: 1.16, pillar: 1.21, claw: 1.21, spkWall: 1.24, spkTower: 1.31, gcube: 1.15, ledArch: 2.05, crystal: 1.43, ledWall: 1.58, infinity: 1.32,
    gallery: 1.35, wallClock: 0.83, sconce: 1.22,
    miniTV: 0.89, tankSmall: 0.8, tbCup: 0.71, tbClock: 0.76, tbCake: 0.91, tbFruit: 0.87, tbDuck: 0.79, tbPerfume: 0.77, tbRadio: 0.86, tbVase: 0.85, bonsai: 0.79, tbSoap: 0.87, tbSnow: 0.86, tbCandles: 0.83, tbBox: 0.85 });
  X.setSize = (arch, k) => { Object.values(X.CAT).forEach(D => { if (D.arch !== arch) return; const f = k / (D._uk || 1); if (Math.abs(f - 1) < 1e-4) return; rescale(D, f); D._uk = k; }); X.CACHE.clear(); };

  // ---------- shop categories ----------
  const ELEC = new Set(['tv', 'tvstand', 'miniTV', 'wallTV', 'projector', 'speaker', 'spkWall', 'sub', 'smokeSpk', 'partyBox', 'spkTower', 'juke', 'dj', 'arcade', 'pinball', 'claw', 'racer', 'consoleSet', 'handheld', 'tbRadio', 'tbToaster', 'tbMixer',
    'lamp', 'tableLamp', 'mushLamp', 'sconce', 'neonSign', 'pillar', 'fridge', 'stove', 'lantern', 'aquaBig', 'aquaCol', 'tankSmall', 'ledWall', 'laser', 'infinity', 'ledArch', 'spot', 'crystal', 'gcube']);
  const FLOORA = new Set(['rug', 'rug2', 'mat']);
  const GAMES = new Set(['swing', 'slide', 'seesaw', 'sandbox', 'pool', 'tramp', 'merry', 'house', 'hopscotch', 'hoop', 'goal', 'toss', 'ringToss', 'tether', 'sprinkler', 'dome', 'golf', 'pong']);
  const GARDEN = new Set(['sunflower', 'tree', 'bush', 'fountain', 'flowerPot', 'plant', 'pottedPalm', 'monstera', 'cactus', 'gnome', 'birdbath', 'flowerBed', 'stones', 'spinner', 'urn']);
  const YGLOW = new Set(['lantern', 'tiki', 'solar']);
  const IN = [{ k: 'furn', n: 'Furniture' }, { k: 'walls', n: 'Walls' }, { k: 'floors', n: 'Floors' }, { k: 'ceil', n: 'Ceiling' }, { k: 'elec', n: 'Electronics' }];
  const OUT = [{ k: 'patio', n: 'Patio' }, { k: 'games', n: 'Games' }, { k: 'garden', n: 'Garden' }, { k: 'glow', n: 'Lights' }, { k: 'lawn', n: 'Lawn & Fence' }];
  X.CATS = rk => (X.ROOMS[rk] && X.ROOMS[rk].out ? OUT : IN);
  X.catOf = id => { const M = X.SURF[id]; if (M) { const a = M.arch; return a === 'floor' ? 'floors' : a === 'light' ? 'ceil' : a === 'fence' || a === 'ground' ? 'lawn' : a === 'ylight' ? 'glow' : 'walls'; }
    const D = X.CAT[id]; if (!D) return 'furn'; const a = D.arch;
    if (D.room === 'backyard') return GAMES.has(a) ? 'games' : GARDEN.has(a) ? 'garden' : YGLOW.has(a) ? 'glow' : 'patio';
    if (ELEC.has(a)) return 'elec'; if (D.flat || FLOORA.has(a)) return 'floors'; if (D.mount) return 'walls'; return 'furn'; };
  X.surfOk = (id, rk) => { const M = X.SURF[id]; return !!M && !M.hidden && X.slotsOf(rk).includes(M.arch) && (!M.only || M.only === rk); };
  X.EXT2 = 1;
})();
