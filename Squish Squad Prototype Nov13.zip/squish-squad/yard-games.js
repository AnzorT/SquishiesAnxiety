// Yard Mini Games (Nov 12, user: 'I want to add the mini games that are in the yard, can you create examples of these games').
// One playable mini game per game in the backyard's Games tab, starring the player's own creature (the real rig, driven through ext):
// Hoop Shot (Basketball Hoop), Penalty Kick (Soccer Goal), Hopscotch, Bounce Up (Trampolines), Slide & Splash (Slides), Cornhole, Ping-Pong.
// window.YardGames.mount(el) builds the hub (creature picker + game cards) in el. Each game lives in its own yg-*.js and registers with YardGames.add({...}).
// Stage = 360 x 640 units (phone portrait), scaled to fit: bg <svg> | creature layer (rig hosts) | fg <svg> | HUD | input.
(function () {
  const NS = 'http://www.w3.org/2000/svg', W = 360, H = 640, TAU = Math.PI * 2;
  const YG = window.YardGames = window.YardGames || { GAMES: [] };
  YG.W = W; YG.H = H; YG.add = g => { const i = YG.GAMES.findIndex(x => x.id === g.id); if (i >= 0) YG.GAMES[i] = g; else YG.GAMES.push(g); if (YG._hub) YG._hub(); };   // the page runtime may run the scripts twice: same id = replace
  // ---------- tiny helpers ----------
  const S = (tag, a, p) => { const e = document.createElementNS(NS, tag); if (a) for (const k in a) if (a[k] != null) e.setAttribute(k, a[k]); if (p) p.appendChild(e); return e; };
  const D = (tag, a, p, txt) => { const e = document.createElement(tag); if (a) for (const k in a) { if (k === 'style') e.style.cssText = a[k]; else if (k === 'cls') e.className = a[k]; else if (k.startsWith('on')) e.addEventListener(k.slice(2), a[k]); else e.setAttribute(k, a[k]); } if (txt != null) e.textContent = txt; if (p) p.appendChild(e); return e; };
  const cl = (v, a, b) => v < a ? a : v > b ? b : v, lerp = (a, b, u) => a + (b - a) * u, SM = u => { u = cl(u, 0, 1); return u * u * (3 - 2 * u); };
  const r2 = v => Math.round(v * 100) / 100, set = (e, k, v) => { if (e._c === undefined) e._c = {}; if (e._c[k] !== v) { e._c[k] = v; e.setAttribute(k, v); } };
  const ease = { o: u => 1 - (1 - u) * (1 - u), i: u => u * u, io: u => u < 0.5 ? 2 * u * u : 1 - 2 * (1 - u) * (1 - u), back: u => { const c = 1.7; return 1 + (c + 1) * Math.pow(u - 1, 3) + c * Math.pow(u - 1, 2); } };
  // a pose track: keys [[t ms, {ch: v}], ...] -> values at t (linear between keys, eased in-out)
  const track = (keys, t) => { const o = {}; const chs = new Set(); keys.forEach(k => Object.keys(k[1]).forEach(c => chs.add(c)));
    chs.forEach(c => { let a = null, b = null; for (const k of keys) { if (k[1][c] == null) continue; if (k[0] <= t) a = k; else { b = k; break; } }
      o[c] = !a ? (b ? b[1][c] : 0) : !b ? a[1][c] : lerp(a[1][c], b[1][c], ease.io((t - a[0]) / Math.max(1, b[0] - a[0]))); }); return o; };
  Object.assign(YG, { S, D, cl, lerp, SM, r2, set, ease, track, TAU });
  // ---------- saved stuff ----------
  const LS = 'yardgames.v1'; let SAVE = { best: {}, player: null, plays: {} };
  try { const s = JSON.parse(localStorage.getItem(LS) || 'null'); if (s && s.best) SAVE = Object.assign(SAVE, s); } catch (e) {}
  const save = () => { try { localStorage.setItem(LS, JSON.stringify(SAVE)); } catch (e) {} };
  // ---------- sound: little synth pops (no files) ----------
  let AC = null, muted = false; try { muted = localStorage.getItem(LS + '.mute') === '1'; } catch (e) {}
  const ac = () => { if (muted) return null; try { if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume(); } catch (e) { AC = null; } return AC; };
  function tone(f0, f1, dur, type, vol, delay) { const a = ac(); if (!a) return; const t = a.currentTime + (delay || 0), o = a.createOscillator(), g = a.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t); if (f1) o.frequency.exponentialRampToValueAtTime(f1, t + dur); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.18, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + dur + 0.02); }
  function noise(dur, vol, lp, delay) { const a = ac(); if (!a) return; const t = a.currentTime + (delay || 0), n = Math.floor(a.sampleRate * dur), b = a.createBuffer(1, n, a.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2); const s = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain(); s.buffer = b; f.type = 'lowpass'; f.frequency.value = lp || 1800; g.gain.value = vol || 0.2;
    s.connect(f); f.connect(g); g.connect(a.destination); s.start(t); }
  const SFX = { pop: () => tone(520, 880, 0.09, 'sine', 0.16), boing: () => tone(180, 520, 0.22, 'triangle', 0.18), thud: () => { tone(140, 60, 0.12, 'sine', 0.22); noise(0.08, 0.12, 600); },
    swish: () => noise(0.22, 0.16, 3200), score: () => { tone(660, 0, 0.1, 'triangle', 0.16); tone(880, 0, 0.12, 'triangle', 0.16, 0.08); tone(1320, 0, 0.16, 'triangle', 0.14, 0.16); },
    miss: () => tone(330, 180, 0.25, 'sine', 0.14), tick: () => tone(1200, 0, 0.04, 'square', 0.05), splash: () => { noise(0.45, 0.22, 1400); tone(300, 120, 0.2, 'sine', 0.1); },
    clang: () => { tone(900, 860, 0.25, 'triangle', 0.1); tone(1340, 1300, 0.2, 'sine', 0.06); }, whoosh: () => noise(0.3, 0.1, 900), tap: () => tone(760, 0, 0.05, 'sine', 0.1),
    win: () => [523, 659, 784, 1046].forEach((f, i) => tone(f, 0, 0.18, 'triangle', 0.14, i * 0.1)) };
  YG.SFX = SFX;
  // ---------- creatures ----------
  // A creature in a game: the real rig in a host div, feet at (x, y) in stage units, box height `size` (the rig's 100 x 100 box; feet sit ~93% down it).
  // c.E = ext channels (added to whatever state plays; c.pose(o) clears them and sets o), c.yaw(deg) facing (0 = you, 180 = away, 90 = right),
  // c.rot(deg, ox, oy) = whole-body roll (flips, slides), c.walk(dt, w, spin) = its own house gait on the spot.
  YG.creature = function (layer, key, o) {
    o = o || {}; const host = D('div', { cls: 'yg-cr', style: 'position:absolute;pointer-events:none;' }, layer); const R = window.RiveRig;
    let ctrl = null; try { ctrl = R.mount(host, key, { fidgets: false }); } catch (e) { console.warn('YardGames rig', key, e); }
    const I = ctrl && ctrl._I, E = {}; if (I) { I.ext = E; I.fidgets = false; I.ptr = { x: 0, y: 0 }; }
    const c = { key, host, ctrl, I, E, x: 0, y: 0, size: 100, r: 0, ox: 50, oy: 93, ws: {}, z: 0,
      set(x, y, size) { if (x != null) this.x = x; if (y != null) this.y = y; if (size != null) this.size = size; const s = this.size;
        host.style.left = r2((this.x - s / 2) / W * 100) + '%'; host.style.top = r2((this.y - s * 0.93) / H * 100) + '%'; host.style.width = r2(s / W * 100) + '%'; host.style.height = r2(s / H * 100) + '%'; return this; },
      rot(deg, ox, oy) { this.r = deg; if (ox != null) { this.ox = ox; this.oy = oy; } host.style.transformOrigin = this.ox + '% ' + this.oy + '%'; host.style.transform = deg ? 'rotate(' + r2(deg) + 'deg)' : ''; return this; },
      yaw(deg) { if (I) I.spinOff = deg; return this; },
      play(n) { if (ctrl) ctrl.play(n); return this; },
      pose(p) { for (const k in E) E[k] = 0; if (p) Object.assign(E, p); return this; },
      walk(dt, w, spin) { if (w > 0.01 && window.HouseWalk) try { window.HouseWalk.step(key, this.ws, E, w, dt, 1, spin || 0); } catch (e) {} return this; },
      depth(z) { this.z = z; host.style.zIndex = Math.round(z); return this; },
      hide(v) { host.style.visibility = v ? 'hidden' : ''; return this; },
      destroy() { try { ctrl && ctrl.destroy(); } catch (e) {} host.remove(); } };
    if (I && I.shadow && !o.shadow) { I.shadow.style.display = 'none'; I.shadow.setAttribute('rx', 0); }   // the games draw their own shadows
    if (o.yaw != null) c.yaw(o.yaw); c.set(o.x || W / 2, o.y || H - 60, o.size || 140); return c;
  };
  // a camera behind the player: world metres (x right, y up, z away) -> [screen x, screen y, px per metre there]
  YG.cam = (Dc, CH, HY, K) => (x, y, z) => { const s = Dc / (Dc + z); return [W / 2 + x * s * K, HY + (CH - y) * s * K, s * K]; };
  // a soft ground shadow ellipse (bg svg)
  YG.shadow = (p, x, y, rx, op) => S('ellipse', { cx: x, cy: y, rx, ry: rx * 0.22, fill: '#3a2a55', opacity: op == null ? 0.18 : op }, p);
  // ---------- shared defs (gradients / filters every game can use by id) ----------
  function defs(svg) { const d = S('defs', {}, svg);
    d.innerHTML = '<radialGradient id="ygBall" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#ffb070"/><stop offset="0.55" stop-color="#f07a2e"/><stop offset="1" stop-color="#b44a14"/></radialGradient>' +
      '<radialGradient id="ygWhite" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.6" stop-color="#eef0f6"/><stop offset="1" stop-color="#b8bccb"/></radialGradient>' +
      '<radialGradient id="ygGlow" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff" stop-opacity="0.95"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>' +
      '<linearGradient id="ygSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7cc6ff"/><stop offset="0.65" stop-color="#bfe6ff"/><stop offset="1" stop-color="#eaf7ff"/></linearGradient>' +
      '<linearGradient id="ygGrass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9fdc6e"/><stop offset="1" stop-color="#5fb04a"/></linearGradient>' +
      '<linearGradient id="ygWood" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#c98d54"/><stop offset="0.5" stop-color="#e2ad74"/><stop offset="1" stop-color="#b47740"/></linearGradient>' +
      '<filter id="ygFuzz" x="-10%" y="-10%" width="120%" height="120%"><feTurbulence type="fractalNoise" baseFrequency="1.6" numOctaves="2" seed="4"/><feColorMatrix values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.16 0"/><feComposite in2="SourceGraphic" operator="in"/><feBlend in="SourceGraphic" mode="screen"/></filter>' +
      '<filter id="ygSoft" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="2.2"/></filter>'; }
  // the shared backyard backdrop: sky, soft clouds, picket fence, grass (games add their own pieces on top)
  YG.yard = function (p, o) { o = o || {}; const hz = o.hz || 250; if (o.sky !== false) S('rect', { x: -20, y: -20, width: W + 40, height: hz + 40, fill: 'url(#ygSky)' }, p);
    if (o.sky !== false) [[60, 70, 1], [250, 46, 0.8], [320, 120, 0.6], [140, 140, 0.55]].forEach(([x, y, k]) => { const g = S('g', { opacity: 0.92, transform: 'translate(' + x + ' ' + (y * hz / 250) + ') scale(' + k + ')' }, p);
      [[-26, 4, 18], [0, -6, 24], [26, 4, 18], [10, 8, 18], [-12, 9, 16]].forEach(([a, b, r]) => S('circle', { cx: a, cy: b, r, fill: '#ffffff' }, g)); });
    if (o.trees !== false) [[18, 0.9], [342, 1.1], [300, 0.7]].forEach(([x, k]) => { const g = S('g', { transform: 'translate(' + x + ' ' + (hz - 6) + ') scale(' + k + ')' }, p);
      S('rect', { x: -4, y: -34, width: 8, height: 36, rx: 3, fill: '#8a5a34' }, g); [[-14, -44, 18], [12, -46, 20], [0, -62, 22], [-4, -40, 16]].forEach(([a, b, r]) => S('circle', { cx: a, cy: b, r, fill: '#57a854' }, g));
      S('circle', { cx: -6, cy: -66, r: 9, fill: '#7cc46a', opacity: 0.8 }, g); });
    if (o.fence !== false) { const fy = hz - 34, g = S('g', {}, p); S('rect', { x: -10, y: fy + 10, width: W + 20, height: 6, fill: '#f3e8da' }, g); S('rect', { x: -10, y: fy + 26, width: W + 20, height: 6, fill: '#f3e8da' }, g);
      for (let x = -6; x < W + 10; x += 18) S('path', { d: 'M' + x + ' ' + (fy + 38) + 'V' + (fy + 6) + 'L' + (x + 6) + ' ' + fy + 'L' + (x + 12) + ' ' + (fy + 6) + 'V' + (fy + 38) + 'Z', fill: '#fff8ee', stroke: '#e2cfb8', 'stroke-width': 1 }, g); }
    S('rect', { x: -20, y: hz, width: W + 40, height: H - hz + 20, fill: 'url(#ygGrass)' }, p);
    // grass tufts + a few flowers, seeded so every game looks the same each time
    let sd = 7; const rnd = () => (sd = (sd * 9301 + 49297) % 233280) / 233280; const tg = S('g', { opacity: 0.55 }, p);
    for (let i = 0; i < 46; i++) { const x = rnd() * W, y = hz + 8 + rnd() * (H - hz - 10), k = 0.6 + (y - hz) / (H - hz) * 0.9; S('path', { d: 'M' + r2(x - 3 * k) + ' ' + r2(y) + 'q' + r2(1 * k) + ' ' + r2(-6 * k) + ' ' + r2(2 * k) + ' ' + r2(-8 * k) + 'q' + r2(0.5 * k) + ' ' + r2(5 * k) + ' ' + r2(1.6 * k) + ' ' + r2(8 * k) + 'q' + r2(1 * k) + ' ' + r2(-5 * k) + ' ' + r2(3 * k) + ' ' + r2(-7 * k) + 'q' + r2(-0.6 * k) + ' ' + r2(5 * k) + ' ' + r2(0.4 * k) + ' ' + r2(7 * k) + 'Z', fill: '#4f9a3e' }, tg); }
    if (o.flowers !== false) for (let i = 0; i < 9; i++) { const x = rnd() * W, y = hz + 14 + rnd() * (H - hz - 30), k = 0.7 + (y - hz) / (H - hz) * 0.8, c = ['#ffd1e8', '#fff3a8', '#ffffff', '#d9c8ff'][i % 4];
      for (let j = 0; j < 5; j++) S('circle', { cx: r2(x + Math.cos(j * 1.2566) * 2.6 * k), cy: r2(y + Math.sin(j * 1.2566) * 2.6 * k), r: r2(1.9 * k), fill: c }, p); S('circle', { cx: r2(x), cy: r2(y), r: r2(1.3 * k), fill: '#ffb84a' }, p); }
  };
  // ---------- a running game ----------
  function run(app, G) {
    const R = window.SquishSquad, pl = playerC(), stageWrap = app.stage, now0 = performance.now();
    stageWrap.innerHTML = ''; app.root.classList.add('yg-playing');
    const bg = S('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'yg-layer', preserveAspectRatio: 'none' }, stageWrap); defs(bg);
    const crL = D('div', { cls: 'yg-layer yg-crl' }, stageWrap);
    const fg = S('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'yg-layer', preserveAspectRatio: 'none' }, stageWrap);
    const hud = D('div', { cls: 'yg-hud' }, stageWrap), inp = D('div', { cls: 'yg-input' }, stageWrap), ov = D('div', { cls: 'yg-ov' }, stageWrap);
    const top = D('div', { cls: 'yg-top' }, hud), back = D('button', { cls: 'yg-back', 'aria-label': 'Back to the yard' }, top, '‹');
    const ttl = D('div', { cls: 'yg-ttl' }, top, G.name), pills = D('div', { cls: 'yg-pills' }, top);
    const scP = D('div', { cls: 'yg-pill yg-score' }, pills, '0'), tmP = D('div', { cls: 'yg-pill yg-time' }, pills, ''), hint = D('div', { cls: 'yg-hint' }, hud, G.hint || '');
    const toastL = D('div', { cls: 'yg-toasts' }, stageWrap);
    let alive = true, playing = false, score = 0, left = G.dur || 0, raf = 0, last = 0, inst = null, parts = [], creatures = [], ended = false;
    const ctx = { W, H, bg, fg, crl: crL, G, S, D, YG, SFX, playerKey: pl.key, playerName: pl.name,
      creature(key, o) { const c = YG.creature(crL, key, o); creatures.push(c); return c; },
      opponent(n) { const pool = ['biscuit', 'pip', 'mallow', 'nimbo', 'ribbit', 'bao', 'mittens', 'sealy', 'frybo', 'poppy'].filter(k => k !== pl.key); const out = []; while (out.length < (n || 1) && pool.length) out.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]); return n ? out : out[0]; },
      nameOf(key) { const c = R && R.ROSTER.find(x => x && x.key === key); return c ? c.name : key; },
      get score() { return score; }, add(n, x, y, txt, col) { score = Math.max(0, score + n); scP.textContent = score; scP.classList.remove('yg-bump'); void scP.offsetWidth; scP.classList.add('yg-bump'); if (txt) ctx.toast(txt, x, y, col); },
      setScore(n) { score = n; scP.textContent = score; }, timer(txt) { tmP.textContent = txt; tmP.style.display = txt ? '' : 'none'; }, hint(t) { hint.textContent = t || ''; },
      get time() { return left; }, get playing() { return playing; },
      toast(txt, x, y, col, big) { const e = D('div', { cls: 'yg-toast' + (big ? ' yg-big' : ''), style: 'left:' + r2((x == null ? W / 2 : x) / W * 100) + '%;top:' + r2((y == null ? H * 0.4 : y) / H * 100) + '%;color:' + (col || '#ffffff') }, toastL, txt); setTimeout(() => e.remove(), big ? 1400 : 1000); },
      // particles: kind 'spark' | 'star' | 'drop' | 'dust' | 'confetti'
      burst(x, y, kind, n, o) { o = o || {}; for (let i = 0; i < (n || 10); i++) { const a = (o.dir != null ? o.dir : -Math.PI / 2) + (Math.random() - 0.5) * (o.spread || TAU), v = (o.v || 120) * (0.5 + Math.random() * 0.7);
          const col = o.col || (kind === 'drop' ? '#8fd3ff' : kind === 'dust' ? '#d8c7a8' : ['#ffd84a', '#ff8fc8', '#8fe0ff', '#b6f07a', '#ffffff'][i % 5]);
          const e = kind === 'star' || kind === 'spark' ? S('path', { d: 'M0-5L1.4-1.4L5 0L1.4 1.4L0 5L-1.4 1.4L-5 0L-1.4-1.4Z', fill: col }, o.layer || fg) : kind === 'confetti' ? S('rect', { x: -2.5, y: -1.5, width: 5, height: 3, fill: col }, o.layer || fg) : S('circle', { r: kind === 'dust' ? 4 : 2.6, fill: col, opacity: 0.9 }, o.layer || fg);
          parts.push({ e, x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: o.g != null ? o.g : (kind === 'dust' ? -20 : 260), life: (o.life || 0.8) * (0.7 + Math.random() * 0.5), t: 0, rot: Math.random() * 360, vr: (Math.random() - 0.5) * 600, k: o.k || (kind === 'dust' ? 1.8 : 1) }); } },
      finish(extra) { if (ended) return; ended = true; playing = false; setTimeout(() => results(extra || {}), extra && extra.delay != null ? extra.delay : 700); },
      on: (ev, fn) => (ctx['_' + ev] = fn) };
    function results(extra) { if (!alive) return; const best = SAVE.best[G.id] || 0, nb = score > best; if (nb) { SAVE.best[G.id] = score; } SAVE.plays[G.id] = (SAVE.plays[G.id] || 0) + 1; save();
      const st = G.stars ? G.stars.filter(v => score >= v).length : 0; if (nb || st >= 2) SFX.win();
      ov.innerHTML = ''; ov.className = 'yg-ov yg-show'; const card = D('div', { cls: 'yg-card yg-res' }, ov);
      D('div', { cls: 'yg-res-t' }, card, extra.title || (st >= 3 ? 'Amazing!' : st === 2 ? 'Great job!' : st === 1 ? 'Nice!' : 'Good try!'));
      const sr = D('div', { cls: 'yg-stars' }, card); for (let i = 0; i < 3; i++) D('span', { cls: 'yg-star' + (i < st ? ' on' : ''), style: 'animation-delay:' + (i * 0.15 + 0.1) + 's' }, sr, '★');
      D('div', { cls: 'yg-res-score' }, card, String(score)); D('div', { cls: 'yg-res-sub' }, card, (extra.sub ? extra.sub + ' · ' : '') + (nb ? 'New best!' : 'Best ' + best));
      D('div', { cls: 'yg-res-coins' }, card, '+' + Math.max(1, Math.round(score * (G.coinK || 1))) + ' coins (preview)');
      const row = D('div', { cls: 'yg-row' }, card); D('button', { cls: 'yg-btn yg-ghost', onclick: () => app.hub() }, row, 'Yard'); D('button', { cls: 'yg-btn', onclick: () => app.play(G) }, row, 'Play again');
      if (inst && inst.celebrate) try { inst.celebrate(st); } catch (e) {} }
    // intro card
    function intro() { ov.innerHTML = ''; ov.className = 'yg-ov yg-show'; const card = D('div', { cls: 'yg-card' }, ov); const ic = D('div', { cls: 'yg-ic' }, card); ic.innerHTML = G.icon || '';
      D('div', { cls: 'yg-card-t' }, card, G.name); D('div', { cls: 'yg-card-s' }, card, 'Yard: ' + G.item); const ul = D('ul', { cls: 'yg-how' }, card); (G.how || []).forEach(t => D('li', {}, ul, t));
      if (G.options) { const op = D('div', { cls: 'yg-opts' }, card); G.options.forEach(o2 => { const b = D('button', { cls: 'yg-opt' + (G._opt === o2.id || (!G._opt && o2 === G.options[0]) ? ' on' : ''), onclick: () => { G._opt = o2.id; [...op.children].forEach(x => x.classList.remove('on')); b.classList.add('on'); if (inst && inst.option) inst.option(o2.id); } }, op, o2.label); }); }
      D('button', { cls: 'yg-btn yg-go', onclick: () => { ac(); ov.className = 'yg-ov'; start(); } }, card, 'Play');
      D('div', { cls: 'yg-best' }, card, SAVE.best[G.id] ? 'Best ' + SAVE.best[G.id] : 'No best yet'); }
    function start() { playing = true; ended = false; score = 0; scP.textContent = '0'; left = G.dur || 0; ctx.toast('Go!', W / 2, H * 0.42, '#ffffff', true); SFX.pop(); if (inst.start) inst.start(); }
    const loop = t => { if (!alive) return; const dt = Math.min(0.05, last ? (t - last) / 1000 : 0.016); last = t;
      if (playing && G.dur) { const pl0 = Math.ceil(left); left = Math.max(0, left - dt); if (Math.ceil(left) !== pl0 && left <= 5 && left > 0) SFX.tick(); ctx.timer(Math.ceil(left) + 's'); tmP.classList.toggle('yg-hurry', left <= 5); if (left <= 0) { if (inst.timeUp) inst.timeUp(); else ctx.finish(); } }
      try { inst.update(dt, t); } catch (e) { if (!loop.err) { loop.err = 1; console.error('YardGames', G.id, e); } }
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t += dt; if (q.t >= q.life) { q.e.remove(); parts.splice(i, 1); continue; } q.vy += q.g * dt; q.x += q.vx * dt; q.y += q.vy * dt; q.rot += q.vr * dt; const u = q.t / q.life;
        q.e.setAttribute('transform', 'translate(' + r2(q.x) + ' ' + r2(q.y) + ') rotate(' + Math.round(q.rot) + ') scale(' + r2((1 - u * 0.5) * q.k) + ')'); q.e.setAttribute('opacity', r2(1 - u * u)); }
      raf = requestAnimationFrame(loop); };
    // input in stage units
    const pt = e => { const r = inp.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width * W, y: (e.clientY - r.top) / r.height * H, t: performance.now(), id: e.pointerId }; };
    inp.addEventListener('pointerdown', e => { if (!playing) return; e.preventDefault(); try { inp.setPointerCapture(e.pointerId); } catch (x) {} ac(); inst.down && inst.down(pt(e)); });
    inp.addEventListener('pointermove', e => { if (!playing) return; inst.move && inst.move(pt(e)); });
    const up = e => { if (!playing) return; inst.up && inst.up(pt(e)); }; inp.addEventListener('pointerup', up); inp.addEventListener('pointercancel', up);
    const key = e => { if (!playing || !inst.key) return; if (inst.key(e.key, e.type === 'keydown')) e.preventDefault(); };
    window.addEventListener('keydown', key); window.addEventListener('keyup', key);
    back.addEventListener('click', () => app.hub());
    ctx.timer(G.dur ? G.dur + 's' : ''); inst = G.make(ctx) || {}; if (!inst.update) inst.update = () => {}; intro(); raf = requestAnimationFrame(loop);
    YG._cur = { G, ctx, inst, get score() { return score; }, start: () => { ov.className = 'yg-ov'; start(); }, step: null };
    return () => { alive = false; cancelAnimationFrame(raf); window.removeEventListener('keydown', key); window.removeEventListener('keyup', key); try { inst.destroy && inst.destroy(); } catch (e) {} creatures.forEach(c => c.destroy()); app.root.classList.remove('yg-playing'); YG._cur = null; };
  }
  // ---------- player pick ----------
  function roster() { const R = window.SquishSquad; if (!R) return []; return R.ROSTER.filter(c => c && R.src(c.id)); }
  function playerC() { const L = roster(); return L.find(c => c.id === SAVE.player) || L.find(c => c.key === 'mittens') || L[0]; }
  const thumb = c => { const R = window.SquishSquad, s = R.src(c.id); return (window.SQ_THUMBS && window.SQ_THUMBS[s]) || s; };
  // ---------- the hub ----------
  YG.mount = function (el) {
    el.innerHTML = ''; const root = D('div', { cls: 'yg-root' }, el), app = { root }; let stop = null, hubC = null;
    const frame = D('div', { cls: 'yg-frame' }, root); app.stage = D('div', { cls: 'yg-stage' }, frame); const hubEl = D('div', { cls: 'yg-hubwrap' }, frame);
    app.hub = () => { if (stop) { stop(); stop = null; } app.stage.innerHTML = ''; app.stage.style.display = 'none'; hubEl.style.display = ''; drawHub(); };
    app.play = G => { if (stop) { stop(); stop = null; } if (hubC) { hubC.destroy(); hubC = null; } hubEl.style.display = 'none'; app.stage.style.display = ''; stop = run(app, G); };
    function drawHub() { if (hubC) { hubC.destroy(); hubC = null; } hubEl.innerHTML = ''; const pc = playerC();
      const head = D('div', { cls: 'yg-hhead' }, hubEl); D('div', { cls: 'yg-htitle' }, head, 'Yard Games'); D('div', { cls: 'yg-hsub' }, head, 'Play with the games in your backyard');
      const mute = D('button', { cls: 'yg-mute', 'aria-label': 'Sound on or off', onclick: () => { muted = !muted; try { localStorage.setItem(LS + '.mute', muted ? '1' : '0'); } catch (e) {} mute.textContent = muted ? '🔇' : '🔊'; } }, head, muted ? '🔇' : '🔊');
      // your player: the live rig on a little stage + a strip of everyone to pick from
      const me = D('div', { cls: 'yg-me' }, hubEl), meSt = D('div', { cls: 'yg-me-st' }, me), meTx = D('div', { cls: 'yg-me-tx' }, me);
      D('div', { cls: 'yg-me-k' }, meTx, 'Your player'); D('div', { cls: 'yg-me-n' }, meTx, pc ? pc.name : '…'); D('div', { cls: 'yg-me-h' }, meTx, 'Pick anyone below');
      if (pc) { hubC = YG.creature(meSt, pc.key, { x: W / 2, y: H * 0.92, size: H * 0.95, shadow: 1 }); hubC.host.style.cssText += ';left:0;top:0;width:100%;height:100%;'; hubC.play('happy'); setTimeout(() => hubC && hubC.play('idle'), 2400); }
      const strip = D('div', { cls: 'yg-strip', role: 'list' }, hubEl);
      roster().forEach(c => { const b = D('button', { cls: 'yg-pick' + (pc && c.id === pc.id ? ' on' : ''), 'aria-label': c.name, title: c.name, role: 'listitem', onclick: () => { SAVE.player = c.id; save(); SFX.pop(); drawHub(); } }, strip);
        D('img', { src: thumb(c), alt: '', loading: 'lazy' }, b); });
      setTimeout(() => { const on = strip.querySelector('.on'); if (on) strip.scrollLeft = on.offsetLeft - strip.clientWidth / 2 + on.offsetWidth / 2; }, 30);
      const grid = D('div', { cls: 'yg-grid' }, hubEl);
      YG.GAMES.forEach(G => { const b = D('button', { cls: 'yg-gcard', style: '--gc:' + (G.color || '#ff8a3d'), onclick: () => { SFX.pop(); app.play(G); } }, grid);
        const ic = D('div', { cls: 'yg-gic' }, b); ic.innerHTML = G.icon || ''; if (ic.firstChild && ic.firstChild.setAttribute) ic.firstChild.setAttribute('preserveAspectRatio', 'xMidYMid slice'); D('div', { cls: 'yg-gname' }, b, G.name); D('div', { cls: 'yg-gitem' }, b, G.item);
        D('div', { cls: 'yg-gbest' }, b, SAVE.best[G.id] ? '★ Best ' + SAVE.best[G.id] : 'New!'); });
      D('div', { cls: 'yg-foot' }, hubEl, 'Examples of the backyard mini games. Coins are shown as a preview and not added to your wallet.'); }
    YG._hub = () => { if (!stop) drawHub(); }; YG._app = app; app.hub(); return app;
  };
})();
