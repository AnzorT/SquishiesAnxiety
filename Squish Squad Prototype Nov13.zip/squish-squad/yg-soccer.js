// Yard Mini Games: PENALTY KICK (the backyard's Soccer Goal). 5 penalties against a goalkeeper creature. Swipe up from the ball:
// the swipe's direction aims left / right, its length sets the height (too long = over the bar). The keeper reads some shots (more each kick);
// corners and top shots are harder to save but easy to put wide. Goal 100, corner +50, top +50.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add || !YG.cam) return setTimeout(go, 30); const { S, cl, lerp, r2, track, SFX } = YG;
  const ICON = '<svg viewBox="0 0 120 84" aria-hidden="true"><rect width="120" height="84" fill="#cfeaff"/><rect y="46" width="120" height="38" fill="#9fdc6e"/>' +
    '<path d="M22 58V22H98V58" fill="none" stroke="#fff" stroke-width="4" stroke-linejoin="round"/><path d="M26 24L34 34V56M94 24L86 34V56M34 34H86" fill="none" stroke="#e8eef5" stroke-width="2"/>' +
    '<path d="M26 26H94M26 32H94M26 38H94M26 44H94M26 50H94M34 24V56M44 24V56M54 24V56M64 24V56M74 24V56M84 24V56" stroke="#ffffff" stroke-width="0.8" opacity="0.6"/>' +
    '<path d="M12 70H108" stroke="#fff" stroke-width="2"/><circle cx="60" cy="68" r="9" fill="#fff" stroke="#3a3a44" stroke-width="1.2"/><path d="M60 63L64 66L62.5 71H57.5L56 66Z" fill="#3a3a44"/></svg>';
  YG.add({ id: 'soccer', name: 'Penalty Kick', item: 'Soccer Goal', color: '#5cc2ff', icon: ICON, stars: [250, 450, 700], coinK: 0.06,
    hint: 'Swipe up from the ball · direction aims · longer swipe = higher',
    how: ['Swipe up from the ball to shoot.', 'The swipe direction aims; a longer swipe sends it higher (too long flies over the bar).', '5 penalties. Corners and top shots score bonus points.'],
    make(ctx) {
      const { bg, fg, W, H } = ctx, P = YG.cam(2.6, 1.5, 230, 247), G = 9.8, GZ = 4.1, GW = 1.3, GH = 1.4, BR = 0.11, B0 = [0, BR, 1.3];
      YG.yard(bg, { hz: 230 });
      const line = (pts, w, p, op) => S('path', { d: 'M' + pts.map(q => { const s = P(q[0], 0, q[1]); return r2(s[0]) + ' ' + r2(s[1]); }).join('L'), fill: 'none', stroke: '#ffffff', 'stroke-width': w || 2.5, opacity: op || 0.9, 'stroke-linejoin': 'round' }, p || bg);
      // mowing stripes + pitch lines
      for (let i = 0; i < 7; i++) { const z0 = -0.6 + i * 1.1, a = P(-4, 0, z0), b = P(4, 0, z0), c = P(4, 0, z0 + 0.55), d = P(-4, 0, z0 + 0.55); S('path', { d: 'M' + [a, b, c, d].map(s => r2(s[0]) + ' ' + r2(s[1])).join('L') + 'Z', fill: '#ffffff', opacity: 0.07 }, bg); }
      line([[-3.2, GZ], [3.2, GZ]]); line([[-2.1, GZ], [-2.1, GZ - 1.3], [2.1, GZ - 1.3], [2.1, GZ]]); line([[-3.4, GZ], [-3.4, -0.6]], 2, bg, 0.5); line([[3.4, GZ], [3.4, -0.6]], 2, bg, 0.5);
      { let d = ''; for (let i = 0; i <= 18; i++) { const a = Math.PI * i / 18, s = P(Math.cos(a) * 0.9, 0, GZ - 2.2 - Math.sin(a) * 0.55); d += (i ? 'L' : 'M') + r2(s[0]) + ' ' + r2(s[1]); } S('path', { d, fill: 'none', stroke: '#ffffff', 'stroke-width': 2.2, opacity: 0.8 }, bg); }
      const spot = P(0, 0, B0[2]); S('ellipse', { cx: spot[0], cy: spot[1], rx: 5, ry: 1.6, fill: '#ffffff', opacity: 0.9 }, bg);
      // the goal: back frame + net behind, then the posts in front of the keeper
      const netG = S('g', {}, bg), shG = S('g', {}, bg), kSlot = null, postG = S('g', {}, fg), ballSlotBack = S('g', {}, bg);
      const NX = 14, NY = 7, ND = 0.9; let bulge = { x: 0, y: 0, a: 0, t: -9 };
      function drawNet(t) { netG.innerHTML = ''; const k = bulge.a * Math.exp(-(t - bulge.t) / 420) * (1 + 0.2 * Math.sin((t - bulge.t) / 60));
        const pt = (x, y) => { const back = ND * (1 - y / GH * 0.55), d = Math.hypot(x - bulge.x, y - bulge.y), push = k * Math.exp(-d * d / 0.18) * 0.5; return P(x, y, GZ + back + push); };
        let d = ''; for (let i = 0; i <= NX; i++) { const x = -GW + 2 * GW * i / NX; for (let j = 0; j <= NY; j++) { const y = GH * j / NY, s = pt(x, y); d += (j ? 'L' : 'M') + r2(s[0]) + ' ' + r2(s[1]); } }
        for (let j = 0; j <= NY; j++) { const y = GH * j / NY; for (let i = 0; i <= NX; i++) { const x = -GW + 2 * GW * i / NX, s = pt(x, y); d += (i ? 'L' : 'M') + r2(s[0]) + ' ' + r2(s[1]); } }
        for (let j = 0; j <= NY; j++) { const y = GH * j / NY, a = P(-GW, y, GZ), b = pt(-GW, y), c = P(GW, y, GZ), e = pt(GW, y); d += 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'L' + r2(b[0]) + ' ' + r2(b[1]) + 'M' + r2(c[0]) + ' ' + r2(c[1]) + 'L' + r2(e[0]) + ' ' + r2(e[1]); }
        S('path', { d, fill: 'none', stroke: '#ffffff', 'stroke-width': 0.9, opacity: 0.75 }, netG);
        const fb = [P(-GW, 0, GZ + ND), P(-GW, GH * 0.95, GZ + ND * 0.48), P(GW, GH * 0.95, GZ + ND * 0.48), P(GW, 0, GZ + ND)]; S('path', { d: 'M' + fb.map(s => r2(s[0]) + ' ' + r2(s[1])).join('L'), fill: 'none', stroke: '#dfe6ee', 'stroke-width': 2.6 }, netG); }
      { const a = P(-GW, 0, GZ), b = P(-GW, GH, GZ), c = P(GW, GH, GZ), d = P(GW, 0, GZ), w = 0.07 * a[2];
        S('path', { d: 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'L' + r2(b[0]) + ' ' + r2(b[1]) + 'L' + r2(c[0]) + ' ' + r2(c[1]) + 'L' + r2(d[0]) + ' ' + r2(d[1]), fill: 'none', stroke: '#c9d2dc', 'stroke-width': r2(w + 1.6), 'stroke-linejoin': 'round' }, postG);
        S('path', { d: 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'L' + r2(b[0]) + ' ' + r2(b[1]) + 'L' + r2(c[0]) + ' ' + r2(c[1]) + 'L' + r2(d[0]) + ' ' + r2(d[1]), fill: 'none', stroke: '#ffffff', 'stroke-width': r2(w), 'stroke-linejoin': 'round' }, postG); }
      // keeper (faces you) + kicker (from behind, to the left of the ball)
      const kp = ctx.opponent(), kpName = ctx.nameOf(kp), KZ = GZ - 0.32, keeper = ctx.creature(kp, { yaw: 0 }), kick = ctx.creature(ctx.playerKey, { yaw: 200 });
      const kShadow = YG.shadow(shG, 0, 0, 20, 0.2), pShadow = YG.shadow(shG, 0, 0, 30, 0.2), bShadow = S('ellipse', { fill: '#3a2a55', opacity: 0.2 }, shG);
      // the ball
      const bG = S('g', {}, fg), bC = S('circle', { fill: 'url(#ygWhite)', stroke: '#3a3a44', 'stroke-width': 1 }, bG), bP = S('path', { fill: '#3a3a44' }, bG);
      const res = []; let shot = 0, phase = 'aim', ph0 = 0, tNow = 0, ball = null, kx = 0, kTarget = 0, kDive = 0, kDiveDir = 0, kReact = 0, kH = 0, drag = null, runFrom = null, skill = 0.35, outcome = null, guide = null;
      const dots = []; const dotsEl = document.createElement('div'); dotsEl.className = 'yg-pill'; dotsEl.style.cssText = 'position:absolute;left:50%;top:12.5%;transform:translateX(-50%);display:flex;gap:6px;padding:6px 10px;font-size:14px;'; ctx.crl.parentNode.querySelector('.yg-hud').appendChild(dotsEl);
      function drawDots() { dotsEl.innerHTML = ''; for (let i = 0; i < 5; i++) { const s = document.createElement('span'); s.textContent = res[i] == null ? '○' : res[i] ? '●' : '✕'; s.style.color = res[i] == null ? '#b9a8d6' : res[i] ? '#2fb24a' : '#e8483c'; dotsEl.appendChild(s); } }
      function place() { // keeper + kicker host positions
        const k = P(kx, 0, KZ); keeper.set(k[0], k[1] - kH * k[2], 1.15 * k[2]); keeper.depth(1); kShadow.setAttribute('cx', r2(k[0])); kShadow.setAttribute('cy', r2(k[1])); kShadow.setAttribute('rx', r2(0.36 * k[2]));
        const kk = P(kick.wx, 0, kick.wz); kick.set(kk[0], kk[1], 0.98 * kk[2]); kick.depth(3); pShadow.setAttribute('cx', r2(kk[0])); pShadow.setAttribute('cy', r2(kk[1])); pShadow.setAttribute('rx', r2(0.36 * kk[2])); }
      function resetShot() { ball = { x: B0[0], y: B0[1], z: B0[2], vx: 0, vy: 0, vz: 0, st: 'rest', spin: 0 }; kick.wx = -0.82; kick.wz = 0.72; kx = 0; kTarget = 0; kDive = 0; kH = 0; keeper.rot(0); keeper.play('idle'); kick.play('idle'); phase = 'aim'; outcome = null;
        skill = 0.3 + shot * 0.12; ctx.timer('Kick ' + (shot + 1) + '/5'); drawDots(); }
      function shoot(fx, fy) { if (phase !== 'aim') return; const len = Math.hypot(fx, fy); if (fy > -25 || len < 40) return;
        const ang = Math.atan2(fx, -fy), X = Math.tan(cl(ang, -1.1, 1.1)) * 3.0 + (Math.random() - 0.5) * 0.12, Y = 0.12 + cl((len - 60) / 250, 0, 1.25) * 1.55 + (Math.random() - 0.5) * 0.08;
        ball.tx = X; ball.ty = Y; phase = 'run'; ph0 = tNow; runFrom = [kick.wx, kick.wz]; SFX.tap(); }
      function launch() { const T = 0.62 - Math.min(0.12, Math.abs(ball.ty) * 0.05), dz = GZ + 0.05 - ball.z; ball.vx = (ball.tx - ball.x) / T; ball.vz = dz / T; ball.vy = (ball.ty - ball.y + 0.5 * G * T * T) / T; ball.st = 'fly'; ball.t = 0; SFX.thud(); SFX.whoosh();
        // the keeper decides: reads the shot with chance `skill`, else guesses; reacts after a beat
        const read = Math.random() < skill; kDiveDir = read ? Math.sign(ball.tx) || (Math.random() < 0.5 ? -1 : 1) : (Math.random() < 0.34 ? 0 : Math.random() < 0.5 ? -1 : 1);
        kTarget = read ? cl(ball.tx, -1.25, 1.25) : kDiveDir * (0.6 + Math.random() * 0.6); kReact = tNow + 140 + Math.random() * 110; phase = 'fly'; }
      function settle(goal, txt, col) { if (outcome) return; outcome = goal ? 'goal' : 'miss'; res[shot] = goal ? 1 : 0; drawDots(); phase = 'after'; ph0 = tNow;
        if (goal) { let pts = 100; const corner = Math.abs(ball.x) > 0.8, top = ball.y > 0.9; if (corner) pts += 50; if (top) pts += 50; const g = P(ball.x, ball.y, GZ);
          ctx.add(pts, W / 2, 200, (corner && top ? 'Top corner! ' : corner ? 'Corner! ' : top ? 'Top shelf! ' : 'Goal! ') + '+' + pts, '#ffe36e'); ctx.burst(g[0], g[1], 'confetti', 22, { v: 170 }); SFX.score(); kick.play('happy'); keeper.play('surprised'); }
        else { ctx.toast(txt, W / 2, 200, col || '#ffffff', true); SFX.miss(); if (txt === 'Saved!') keeper.play('happy'); kick.play('surprised'); } }
      const api = {
        start() { shot = 0; res.length = 0; ctx.setScore(0); resetShot(); },
        down(p) { if (phase === 'aim') drag = { x0: p.x, y0: p.y, x: p.x, y: p.y }; },
        move(p) { if (drag) { drag.x = p.x; drag.y = p.y; } },
        up(p) { if (!drag) return; const fx = p.x - drag.x0, fy = p.y - drag.y0; drag = null; shoot(fx, fy); },
        key(k, dn) { if (!dn) return; if (k === 'ArrowUp' || k === ' ') { shoot(0, -170); return true; } if (k === 'ArrowLeft') { shoot(-90, -170); return true; } if (k === 'ArrowRight') { shoot(90, -170); return true; } },
        _shoot: (fx, fy) => shoot(fx, fy), _state: () => ({ phase, shot, res: res.slice(), ball: ball && [ball.x, ball.y, ball.z].map(v => +v.toFixed(2)) }),
        celebrate(st) { kick.play(st >= 2 ? 'happy' : 'idle'); },
        update(dt, t) { tNow = t; const ts = t - ph0; let KE = { armL: 30, armR: 30, sq: 0.03 }, PE = {};
          if (phase === 'aim') { kx = Math.sin(t / 700) * 0.18; KE = { armL: 40 + 10 * Math.sin(t / 300), armR: 40 + 10 * Math.sin(t / 300 + 1), sq: 0.06 + 0.02 * Math.sin(t / 150), lean: Math.sin(t / 700) * 3 }; kick.pose({}); }
          if (phase === 'run') { const u = cl(ts / 520, 0, 1); kick.wx = lerp(runFrom[0], -0.36, u); kick.wz = lerp(runFrom[1], 1.1, u); kick.pose({}); kick.walk(dt, 1, 160); if (u >= 1) { launch(); ph0 = t; } }
          else if (phase !== 'aim') { const kt = t - (phase === 'fly' ? ph0 : ph0 - 400); PE = track([[0, { lean: 10, sq: -0.06, footR: 0, armL: 60, armR: -10 }], [90, { lean: 6, sq: 0.04, footR: 3, armL: 90, armR: 30 }], [420, { lean: 0, sq: 0, footR: 0, armL: 0, armR: 0 }]], kt); kick.pose(PE); }
          // keeper dive
          if ((phase === 'fly' || phase === 'after') && t > kReact) { kDive = Math.min(1, kDive + dt / 0.32); kx = lerp(kx, kTarget, 1 - Math.pow(0.0005, dt)); }
          const dd = YG.SM(kDive) * kDiveDir; kH = Math.sin(Math.min(1, kDive) * Math.PI) * (kDiveDir ? 0.25 : 0.45);
          if (phase === 'fly' || phase === 'after') KE = { armL: 160 * Math.min(1, kDive * 1.5), armR: 160 * Math.min(1, kDive * 1.5), sq: -0.04, lean: dd * 8 };
          keeper.rot(dd * 62, 50, 55); keeper.pose(KE); place();
          // ball flight
          if (ball.st === 'fly' || ball.st === 'net' || ball.st === 'out') { const n = 3; for (let i = 0; i < n; i++) { const h = dt / n, pz = ball.z; ball.vy -= G * h; ball.x += ball.vx * h; ball.y += ball.vy * h; ball.z += ball.vz * h; ball.spin += h * 14;
              if (ball.y < BR) { ball.y = BR; ball.vy = Math.abs(ball.vy) * 0.45; ball.vx *= 0.8; ball.vz *= 0.8; }
              if (ball.st === 'fly' && pz < KZ && ball.z >= KZ - 0.05) { // keeper body / gloves: a capsule from his feet up, tilted with the dive
                const ang = dd * 62 * Math.PI / 180, rx = ball.x - kx, ry = ball.y - kH, along = rx * Math.sin(ang) + ry * Math.cos(ang), across = rx * Math.cos(ang) - ry * Math.sin(ang);
                if (along > -0.1 && along < 1.15 + (kDive > 0.2 ? 0.25 : 0) && Math.abs(across) < 0.32 + (kDive > 0.2 ? 0.12 : 0)) { ball.vz = -Math.abs(ball.vz) * 0.35; ball.vx = (Math.random() - 0.5) * 3 + Math.sign(rx || 1) * 1.5; ball.vy = 2.5; ball.st = 'out'; settle(false, 'Saved!', '#8fe0ff'); SFX.thud(); } }
              if (ball.st === 'fly' && pz < GZ && ball.z >= GZ) { const ax = Math.abs(ball.x);
                if (Math.abs(ax - GW) < BR + 0.04 && ball.y < GH + 0.05 || Math.abs(ball.y - GH) < BR + 0.04 && ax < GW + 0.05) { ball.vz = -Math.abs(ball.vz) * 0.5; ball.vx += (ax < GW ? -1 : 1) * Math.sign(ball.x) * 1.2; ball.st = 'out'; SFX.clang(); settle(false, Math.abs(ball.y - GH) < 0.2 ? 'Off the bar!' : 'Off the post!'); }
                else if (ax < GW && ball.y < GH) { ball.st = 'net'; bulge = { x: ball.x, y: ball.y, a: 1, t }; SFX.swish(); settle(true); }
                else { ball.st = 'out'; settle(false, ball.y >= GH ? 'Over the bar!' : 'Wide!'); } }
              if (ball.st === 'net') { if (ball.z > GZ + 0.55) { ball.z = GZ + 0.55; ball.vz = -0.3; ball.vx *= 0.3; } if (Math.abs(ball.x) > GW - 0.12) { ball.x = Math.sign(ball.x) * (GW - 0.12); ball.vx *= -0.3; } if (ball.y > GH - 0.12) { ball.y = GH - 0.12; ball.vy = -Math.abs(ball.vy) * 0.3; } } } }
          drawNet(t);
          // ball drawing (behind the posts once it is in the goal)
          const s = P(ball.x, ball.y, ball.z), r = BR * s[2], inG = ball.z > GZ - 0.02; if (inG && bG.parentNode !== ballSlotBack) ballSlotBack.appendChild(bG); else if (!inG && bG.parentNode !== fg) fg.insertBefore(bG, postG.nextSibling);
          bC.setAttribute('cx', r2(s[0])); bC.setAttribute('cy', r2(s[1])); bC.setAttribute('r', r2(r)); const sp = ball.spin; let pd = ''; for (let i = 0; i < 5; i++) { const a = sp + i * 1.2566; pd += (i ? 'L' : 'M') + r2(s[0] + Math.cos(a) * r * 0.42) + ' ' + r2(s[1] + Math.sin(a) * r * 0.42); } bP.setAttribute('d', pd + 'Z');
          const g0 = P(ball.x, 0, ball.z), hk = cl(1 - ball.y / 2.5, 0.3, 1); bShadow.setAttribute('cx', r2(g0[0])); bShadow.setAttribute('cy', r2(g0[1])); bShadow.setAttribute('rx', r2(BR * g0[2] * 1.2 * hk)); bShadow.setAttribute('ry', r2(BR * g0[2] * 0.35 * hk));
          // aim guide while swiping
          if (!guide) guide = S('path', { fill: 'none', stroke: '#ffffff', 'stroke-width': 3, 'stroke-dasharray': '2 7', 'stroke-linecap': 'round', opacity: 0 }, fg);
          if (drag && phase === 'aim') { const fx = drag.x - drag.x0, fy = drag.y - drag.y0, len = Math.hypot(fx, fy); if (fy < -10) { const ang = Math.atan2(fx, -fy), X = Math.tan(cl(ang, -1.1, 1.1)) * 3.0, Y = 0.12 + cl((len - 60) / 250, 0, 1.25) * 1.55, tg = P(X, Y, GZ), b0 = P(ball.x, ball.y, ball.z);
              guide.setAttribute('d', 'M' + r2(b0[0]) + ' ' + r2(b0[1]) + 'Q' + r2((b0[0] + tg[0]) / 2) + ' ' + r2(Math.min(b0[1], tg[1]) - 30) + ' ' + r2(tg[0]) + ' ' + r2(tg[1])); guide.setAttribute('opacity', 0.75); } } else guide.setAttribute('opacity', 0);
          if (phase === 'after' && ts > 1700) { shot++; if (shot >= 5) { phase = 'done'; const g = res.filter(Boolean).length; ctx.finish({ sub: g + '/5 goals vs ' + kpName }); } else resetShot(); }
        } };
      resetShot(); place(); drawNet(0); return api;
    } });
  }; go();
})();
