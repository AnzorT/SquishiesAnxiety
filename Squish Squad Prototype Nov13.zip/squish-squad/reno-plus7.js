// Renovation Catalog round 8 — Yard section 1: pools, ponds, fountains & fire.
// Shared toolkit: water() = live water surface in a horizontal plane (depth tint, two moving caustic nets, wavelets, ripples, glints, waterline),
// clipped to the pool's top opening so walls in front always cover it; fall() = flowing water sheets; flames() = layered living fire tongues
// (path morphing), embers; smoke(). Pieces: kiddie, plunge, koiPond, lapPool, lagoon, marbleFount, obelisk, chiminea, bowlPit, kettle, hibachi.
// Tap-to-ignite pieces use r.play ('fire' | 'grill' | 'coals') -> st 'play'. Sets RenoDraw.PLUS7; catalog edit layer RD.SET7.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS6 && RD.H3 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS7) return;
  const K = X.K, { solid, box, cyl, ball, arcW, prismZ, f1 } = K;
  const { rep, rng, n4, P2, mtx, plane, planeX, planeH, an, BLUR, bbOf, mt, wd, cer, pt } = RD.H3;
  const N = RD.N, PI = Math.PI, GOLD = '#e2b14a', CH = '#d5dde2', MARB = '#f3efe8';
  const isPlay = S => /play/.test(S.st || '');
  const B = b => b ? ' begin="' + n4(b) + 's"' : '';
  const kts = n => rep(n + 1, i => n4(i / n)).join(';');
  const anV = (a, vals, d, b) => `<animate attributeName="${a}" values="${vals.join(';')}" dur="${n4(d)}s" calcMode="spline" keyTimes="${kts(vals.length - 1)}" keySplines="${rep(vals.length - 1, () => '0.45 0 0.55 1').join(';')}"${B(b)} repeatCount="indefinite"/>`;
  const atV = (type, vals, d, b) => `<animateTransform attributeName="transform" type="${type}" values="${vals.join(';')}" dur="${n4(d)}s" calcMode="spline" keyTimes="${kts(vals.length - 1)}" keySplines="${rep(vals.length - 1, () => '0.45 0 0.55 1').join(';')}"${B(b)} repeatCount="indefinite"/>`;
  const once = (a, vals, kt, d, b) => `<animate attributeName="${a}" values="${vals}" keyTimes="${kt}" dur="${d}s"${B(b)} fill="freeze"/>`;
  const onceT = (type, vals, kt, d, b) => `<animateTransform attributeName="transform" type="${type}" values="${vals}" keyTimes="${kt}" dur="${d}s"${B(b)} fill="freeze"/>`;
  const st = s => s.map(q => `<stop offset="${q[0]}" stop-color="${q[1]}"${q[2] != null ? ` stop-opacity="${q[2]}"` : ''}/>`).join('');
  const G = (id, s, a) => `<radialGradient id="${id}" ${a || 'cx="38%" cy="34%" r="70%"'}>${st(s)}</radialGradient>`;
  const L = (id, s, a) => `<linearGradient id="${id}" ${a || 'x1="0" y1="0" x2="0" y2="1"'}>${st(s)}</linearGradient>`;
  const lerp = (a, b, t) => a + (b - a) * t, shade7 = c => K.shade ? K.shade(c, 0.92) : c;
  const lerpA = (arr, t) => { const f = t * (arr.length - 1), i = Math.min(arr.length - 2, Math.max(0, Math.floor(f))), u = f - i; return arr[i].map((v, j) => v + (arr[i + 1][j] - v) * u); };

  // ---------- shapes ----------
  const ellPts = (cx, cz, rx, rz, n, a0, a1) => { const full = a1 == null; a0 = a0 || 0; if (full) a1 = a0 + 2 * PI; return rep(full ? n : n + 1, i => { const t = a0 + (a1 - a0) * i / n; return [cx + rx * Math.cos(t), cz + rz * Math.sin(t)]; }); };
  const rrPts = (cx, cz, hx, hz, r) => { r = Math.min(r, hx, hz); const o = []; [[1, 1, 0], [-1, 1, 0.5], [-1, -1, 1], [1, -1, 1.5]].forEach(([sx, sz, a0]) => { for (let i = 0; i <= 5; i++) { const a = (a0 + i / 10) * PI; o.push([cx + sx * (hx - r) + r * Math.cos(a), cz + sz * (hz - r) + r * Math.sin(a)]); } }); return o; };
  const shPts = s => s.pts || (s.hx ? rrPts(s.cx || 0, s.cz || 0, s.hx, s.hz, s.r == null ? 3 : s.r) : ellPts(s.cx || 0, s.cz || 0, s.rx, s.rz == null ? s.rx : s.rz, 60));
  const lp = pts => 'M' + pts.map(q => f1(q[0]) + ' ' + f1(q[1])).join('L') + 'Z';
  const sp = (p, pts, y) => 'M' + pts.map(q => P2(p(q[0], y, q[1]))).join('L') + 'Z';
  const quad = (p, a, b, c, d) => 'M' + [a, b, c, d].map(q => P2(p(...q))).join('L') + 'Z';
  // tangent plane on a vertical cylinder (th from +z toward +x): local u along the surface (left -> right on screen), v down
  const planeT = (p, cx, cz, R, th, y) => { const s = Math.sin(th), c = Math.cos(th), o = [cx + R * s, y, cz + R * c]; return mtx(p(...o), p(o[0] + c, y, o[2] - s), p(o[0], y - 1, o[2])); };
  const facing = th => Math.cos(th - PI / 6);
  // everything above the front half of a horizontal ring (used to clip flames so they never cover a rim in front of them)
  const aboveFront = (p, r, y, cx, cz) => { const a = ellPts(cx || 0, cz || 0, r, r, 24, -PI / 6, 5 * PI / 6).map(q => p(q[0], y, q[1])); return 'M' + a.map(P2).join('L') + `L${f1(a[a.length - 1][0])} -999L${f1(a[0][0])} -999Z`; };
  const tube = (pts, w, k, c, hl, ol) => { const d = 'M' + pts.map(P2).join('L'); return `<path d="${d}" fill="none" stroke="${ol || '#141418'}" stroke-width="${f1((w + 0.7) * k)}" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" fill="none" stroke="${c}" stroke-width="${f1(w * k)}" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" fill="none" stroke="${hl || '#ffffff'}" stroke-width="${f1(w * 0.3 * k)}" stroke-linecap="round" stroke-linejoin="round" opacity="0.5" transform="translate(${f1(-0.22 * w * k)} ${f1(-0.22 * w * k)})"/>`; };
  const curve = (a, b, c, n) => rep(n + 1, i => { const t = i / n, u = 1 - t; return a.map((v, j) => u * u * v + 2 * u * t * b[j] + t * t * c[j]); });

  // ---------- water ----------
  let UID = 0;
  const WP = { pool: ['#147aa6', '#2ab0d6', '#93e6f6', '#ffffff'], kid: ['#2a9ed8', '#4cc6ee', '#aeeefb', '#ffffff'], cedar: ['#0e5a72', '#1f8ea8', '#80d4e4', '#eafcff'], koi: ['#153b37', '#2a6a5d', '#6aae98', '#e6fff4'],
    marble: ['#2a8fb4', '#57bfdc', '#b8eef8', '#ffffff'], lagoon: ['#0a6886', '#1db2cd', '#8af0f5', '#ffffff'], night: ['#05101a', '#0f2536', '#294b62', '#ffc890'] };
  const C1 = 'M0 5.5C3 3.2 6.5 8.4 11 5.2S18.5 2.8 22 5.5M0 16.5C4 13.6 7.4 19.8 12.2 16.8S19 14.4 22 16.5M5.5 0C3.4 3.6 8.2 6.8 5.4 11.4S3 18.6 5.5 22M16.5 0C14 4.4 19.6 7.2 16.8 12S14.6 19 16.5 22';
  const C2 = 'M0 9C6 5 11 14 17 9S26 6 31 9M0 24C5 20 12 28 18 23S27 21 31 24M9 0C5 6 14 11 9 17S6 26 9 31M24 0C20 5 28 12 23 18S21 27 24 31';
  const ripple = (x, z, R1, d, b, col, w) => rep(2, j => { const bb = b - j * d / 2; return `<circle cx="${f1(x)}" cy="${f1(z)}" r="0.4" fill="none" stroke="${col || '#ffffff'}" stroke-width="${w || 0.7}"><animate attributeName="r" values="0.4;${f1(R1)}" dur="${n4(d)}s"${B(bb)} repeatCount="indefinite"/><animate attributeName="opacity" values="0.85;0" dur="${n4(d)}s"${B(bb)} repeatCount="indefinite"/></circle>`; }).join('');
  const STAR4 = 'M0 -1.7L0.35 -0.35L1.7 0L0.35 0.35L0 1.7L-0.35 0.35L-1.7 0L-0.35 -0.35Z';
  function water(p, o) {
    const id = 'w7' + (++UID), pts = shPts(o.sh), Lp = lp(pts), C = o.pal || WP.pool, R = rng(id + (o.seed || '')), cs = o.cs || 1;
    let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9, cx = 0, cz = 0; pts.forEach(q => { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); z0 = Math.min(z0, q[1]); z1 = Math.max(z1, q[1]); cx += q[0] / pts.length; cz += q[1] / pts.length; });
    const rect = (fill, op) => `<rect x="${f1(x0 - 2)}" y="${f1(z0 - 2)}" width="${f1(x1 - x0 + 4)}" height="${f1(z1 - z0 + 4)}" fill="${fill}" opacity="${op}"/>`;
    const t1 = 22 * cs, t2 = 31 * cs, sp1 = o.slow ? 2 : 1;
    let defs = `<clipPath id="${id}L"><path d="${Lp}"/></clipPath>` + (o.rim ? `<clipPath id="${id}S"><path d="${o.rim.p3 ? 'M' + o.rim.p3.map(q => P2(p(...q))).join('L') + 'Z' : sp(p, shPts(o.rim.sh || o.sh), o.rim.y)}"/></clipPath>` : '')
      + `<linearGradient id="${id}g" gradientUnits="userSpaceOnUse" x1="${f1(cx - (x1 - x0) * 0.12)}" y1="${f1(z0)}" x2="${f1(cx + (x1 - x0) * 0.12)}" y2="${f1(z1)}">${st([[0, C[2], n4(0.92 * (o.tint || 1))], [0.3, C[1], n4(0.55 * (o.tint || 1))], [1, C[0], n4(0.4 * (o.tint || 1))]])}</linearGradient>`
      + `<pattern id="${id}a" width="${f1(t1)}" height="${f1(t1)}" patternUnits="userSpaceOnUse"><path d="${C1}" transform="scale(${cs})" fill="none" stroke="${C[3]}" stroke-width="0.85" stroke-linecap="round"/><animateTransform attributeName="patternTransform" type="translate" values="0 0;${f1(t1)} ${f1(t1)}" dur="${n4(9 * sp1)}s" repeatCount="indefinite"/></pattern>`
      + `<pattern id="${id}b" width="${f1(t2)}" height="${f1(t2)}" patternUnits="userSpaceOnUse"><path d="${C2}" transform="scale(${cs})" fill="none" stroke="${C[3]}" stroke-width="1.1" stroke-linecap="round"/><animateTransform attributeName="patternTransform" type="translate" values="${f1(t2)} 0;0 ${f1(t2)}" dur="${n4(13 * sp1)}s" repeatCount="indefinite"/></pattern>`
      + `<pattern id="${id}w" width="16" height="9" patternUnits="userSpaceOnUse"><path d="M1.5 2.6q2.2-1.5 4.4 0M9.5 7q2.2-1.5 4.4 0" stroke="#ffffff" stroke-width="0.55" stroke-linecap="round" fill="none"/><animateTransform attributeName="patternTransform" type="translate" values="0 0;${o.flow ? '32 0' : '16 9'}" dur="${o.flow ? 3 : 7 * sp1}s" repeatCount="indefinite"/></pattern>`
      + `<pattern id="${id}v" width="23" height="13" patternUnits="userSpaceOnUse"><path d="M2 4q3-2 6 0M13 10q3-2 6 0" stroke="#ffffff" stroke-width="0.45" stroke-linecap="round" fill="none"/><animateTransform attributeName="patternTransform" type="translate" values="0 0;${o.flow ? '46 0' : '-23 13'}" dur="${o.flow ? 4.2 : 10 * sp1}s" repeatCount="indefinite"/></pattern>`
      + BLUR(id + 'f', 1.6);
    let s = `<path d="${Lp}" fill="${C[0]}"/>` + (o.floor || '');
    s += rect(`url(#${id}a)`, o.caust == null ? 0.42 : o.caust) + rect(`url(#${id}b)`, (o.caust == null ? 0.42 : o.caust) * 0.7) + (o.under || '');
    s += `<path d="${Lp}" fill="url(#${id}g)"/><path d="${Lp}" fill="none" stroke="${C[2]}" stroke-width="${o.edge || 5}" opacity="0.5" filter="url(#${id}f)"/>`;
    s += rect(`url(#${id}w)`, o.wave == null ? 0.5 : o.wave) + rect(`url(#${id}v)`, (o.wave == null ? 0.5 : o.wave) * 0.75);
    (o.rip || []).forEach(r => s += ripple(...r));
    rep(o.gl == null ? 6 : o.gl, i => { const q = pts[Math.floor(R() * pts.length)], f = Math.sqrt(R()) * 0.85, d = 2.2 + R() * 1.6; s += `<path d="${STAR4}" fill="#ffffff" opacity="0" transform="translate(${f1(lerp(cx, q[0], f))} ${f1(lerp(cz, q[1], f))}) scale(${n4(0.8 + R() * 0.7)})">${an('opacity', '0;0;1;0', n4(d), n4(-R() * d))}</path>`; });
    s += (o.over || '') + `<path d="${Lp}" fill="none" stroke="${C[3]}" stroke-width="0.7" opacity="0.75"/>`;
    const svg = `<g${o.rim ? ` clip-path="url(#${id}S)"` : ''}><g transform="${planeH(p, o.y)}"><g clip-path="url(#${id}L)">${s}</g>${o.top || ''}</g></g>`;
    return { defs, svg };
  }
  const WDEF = L('w7fall', [[0, '#f2fdff', 0.95], [0.5, '#bdeef8', 0.7], [1, '#8fd8ec', 0.55]]) + BLUR('w7m', 2.4);
  // falling water: top edge A, control C (lip -> outward), bottom Bt — arrays of model points
  function fall(p, k, A, Cc, Bt, o) { o = o || {}; const a = A.map(q => p(...q)), c = Cc.map(q => p(...q)), b = Bt.map(q => p(...q)), n = a.length - 1;
    let s = `<path d="M${a.map(P2).join('L')}Q${P2(c[n])} ${P2(b[n])}L${b.slice().reverse().map(P2).join('L')}Q${P2(c[0])} ${P2(a[0])}Z" fill="url(#w7fall)" opacity="${o.op || 0.8}"/>`;
    const m = o.streaks || Math.max(4, n * 2 + 2);
    rep(m, i => { const t = (i + 0.5) / m, A1 = lerpA(a, t), C2 = lerpA(c, t), B1 = lerpA(b, t), len = Math.hypot(B1[0] - A1[0], B1[1] - A1[1]) + 1;
      s += `<path d="M${P2(A1)}Q${P2(C2)} ${P2(B1)}" fill="none" stroke="#ffffff" stroke-width="${f1((0.45 + (i % 3) * 0.22) * k)}" stroke-linecap="round" stroke-dasharray="${f1(len * 0.22)} ${f1(len * 0.14)}" opacity="${n4(0.45 + (i % 2) * 0.35)}">${an('stroke-dashoffset', '0;-' + f1(len * 0.72), n4(0.55 + (i % 4) * 0.07), n4(-i * 0.13))}</path>`; });
    if (o.foam !== 0) rep(Math.max(3, n + 2), i => { const B1 = lerpA(b, i / Math.max(1, n + 1)), d = 0.8 + (i % 3) * 0.2; s += `<ellipse cx="${f1(B1[0])}" cy="${f1(B1[1])}" rx="${f1(2.6 * k)}" ry="${f1(1.2 * k)}" fill="#ffffff" opacity="0.8">${an('rx', f1(1.6 * k) + ';' + f1(3.2 * k) + ';' + f1(1.6 * k), d, -i * 0.3)}${an('opacity', '0.9;0.5;0.9', d, -i * 0.3)}</ellipse>`; });
    if (o.mist !== 0) { const M = lerpA(b, 0.5); s += `<ellipse cx="${f1(M[0])}" cy="${f1(M[1] - 3 * k)}" rx="${f1((o.mw || 14) * k)}" ry="${f1(5 * k)}" fill="#ffffff" filter="url(#w7m)" opacity="0.5">${an('opacity', '0.35;0.65;0.35', 2.6)}</ellipse>`; }
    return s; }
  // thin arcing stream (fountain jets / spouts)
  const stream = (p, k, a, c, b, w, d, bg) => { const A = p(...a), Cc = p(...c), Bb = p(...b), len = Math.hypot(Bb[0] - A[0], Bb[1] - A[1]) + Math.hypot(Cc[0] - A[0], Cc[1] - A[1]) * 0.3 + 1, dd = `M${P2(A)}Q${P2(Cc)} ${P2(Bb)}`;
    return `<path d="${dd}" fill="none" stroke="#bfeefa" stroke-width="${f1(w * k)}" stroke-linecap="round" opacity="0.6"/><path d="${dd}" fill="none" stroke="#ffffff" stroke-width="${f1(w * 0.55 * k)}" stroke-linecap="round" stroke-dasharray="${f1(len * 0.16)} ${f1(len * 0.1)}">${an('stroke-dashoffset', '0;-' + f1(len * 0.52), n4(d || 0.6), bg || 0)}</path>`; };

  // ---------- fire ----------
  const FDEF = L('f7o', [[0, '#b8241a', 0], [0.2, '#d8361a', 0.9], [0.62, '#ff6a1c'], [1, '#ffa22e']]) + L('f7m', [[0, '#ff7a1c', 0.15], [0.38, '#ffa42a'], [1, '#ffe066']]) + L('f7c', [[0, '#fff3b8', 0.2], [0.5, '#fff8d8'], [1, '#ffffff']])
    + G('f7g', [[0, '#ffb347', 0.75], [0.5, '#ff7a22', 0.24], [1, '#ff5a1a', 0]], 'cx="50%" cy="50%" r="50%"') + BLUR('f7s', 2.4) + BLUR('f7b', 1.2);
  const FLP = (s, h, w) => `M${f1(-w)} 0C${f1(-w * 1.15)} ${f1(-h * 0.32)} ${f1(-w * 0.2 + s * 0.4)} ${f1(-h * 0.58)} ${f1(s)} ${f1(-h)}C${f1(w * 0.3 + s * 0.45)} ${f1(-h * 0.6)} ${f1(w * 1.15)} ${f1(-h * 0.3)} ${f1(w)} 0Q0 ${f1(w * 0.9)} ${f1(-w)} 0Z`;
  function tongue(R, h, w, d, b) { const V = rep(4, () => [(R() - 0.5) * w * 2.4, h * (0.74 + R() * 0.38)]); V.push(V[0]);
    const Ly = (sc, f, dy) => `<path d="${FLP(V[0][0] * sc, V[0][1] * sc, w * sc)}" fill="${f}"${dy ? ` transform="translate(0 ${dy})"` : ''}>${anV('d', V.map(v => FLP(v[0] * sc, v[1] * sc, w * sc)), d, b)}</path>`;
    return Ly(1, 'url(#f7o)') + Ly(0.66, 'url(#f7m)', f1(w * 0.1)) + Ly(0.36, 'url(#f7c)', f1(w * 0.2)); }
  const embers = (R, n, sp, h) => rep(n, () => { const x = (R() - 0.5) * sp * 1.6, d = 1.5 + R() * 1.5, b = -R() * d, dx = (R() - 0.5) * 12; return `<circle r="${f1(0.45 + R() * 0.45)}" fill="#ffd66b"><animate attributeName="cx" values="${f1(x)};${f1(x + dx * 0.5)};${f1(x + dx)}" dur="${n4(d)}s"${B(b)} repeatCount="indefinite"/><animate attributeName="cy" values="${f1(-h * 0.5)};${f1(-h * 2.4)}" dur="${n4(d)}s"${B(b)} repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;0.8;0" dur="${n4(d)}s"${B(b)} repeatCount="indefinite"/></circle>`; }).join('');
  // flame cluster: screen point q, u = screen px per local unit; o: n tongues, sp spread, h height, w width
  function flames(q, u, o) { o = o || {}; const R = rng(o.seed || 'f'), n = o.n || 5, spr = o.sp == null ? 9 : o.sp, h = o.h || 16, w = o.w || 3.6; let s = '';
    if (!o.noGlow) s += `<ellipse cx="0" cy="${f1(-h * 0.35)}" rx="${f1(spr * 1.2 + 9)}" ry="${f1(h * 0.85)}" fill="url(#f7g)">${an('opacity', '0.7;1;0.78;0.95;0.7', 1.3)}</ellipse>`;
    const T = rep(n, i => { const x = n === 1 ? 0 : (i / (n - 1) - 0.5) * spr * 2, c = 1 - Math.abs(x) / (spr * 1.5 + 1e-6); return { x: x + (R() - 0.5) * 2, hh: h * (0.45 + 0.55 * c) * (0.85 + R() * 0.3), ww: w * (0.72 + 0.38 * c) }; }).sort((a, b) => a.hh - b.hh);
    T.forEach(t => s += `<g transform="translate(${f1(t.x)} 0)">${tongue(R, t.hh, t.ww, 0.5 + R() * 0.4, -R())}</g>`);
    if (o.emb !== 0) s += embers(R, o.emb || 4, spr + 4, h);
    return `<g transform="translate(${P2(q)}) scale(${n4(u)})">${s}</g>`; }
  function smoke(q, u, o) { o = o || {}; const R = rng(o.seed || 's'), n = o.n || 5, H = o.H || 50, col = o.col || '#8a8784', op = o.op || 0.35, d = o.d || 4.5;
    return `<g transform="translate(${P2(q)}) scale(${n4(u)})" filter="url(#f7s)">` + rep(n, i => { const b = -i * d / n + (o.b || 0), dx = (R() - 0.3) * (o.drift || 14);
      return `<circle cx="0" cy="0" r="3" fill="${col}" opacity="0"><animate attributeName="cx" values="0;${f1(dx * 0.4)};${f1(dx)}" dur="${d}s"${B(b)} repeatCount="indefinite"/><animate attributeName="cy" values="0;${f1(-H * 0.5)};${f1(-H)}" dur="${d}s"${B(b)} repeatCount="indefinite"/><animate attributeName="r" values="${f1(o.r0 || 2.5)};${f1((o.r1 || 9) * 0.7)};${f1(o.r1 || 9)}" dur="${d}s"${B(b)} repeatCount="indefinite"/><animate attributeName="opacity" values="0;${op};${n4(op * 0.55)};0" dur="${d}s"${B(b)} repeatCount="indefinite"/></circle>`; }).join('') + '</g>'; }
  const glowE = (p, x, y, z, rx, rz, col, op, fl) => { const q = p(x, y, z), q2 = p(x + rx, y, z), q3 = p(x, y, z + rz); return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(Math.hypot(q2[0] - q[0], q2[1] - q[1]) * 1.2)}" ry="${f1(Math.abs(q3[1] - q[1]) * 1.3 + 2)}" fill="${col}" opacity="${op}" filter="url(#f7s)">${fl ? an('opacity', `${op};${n4(op * 0.6)};${op};${n4(op * 0.75)};${op}`, 1.6) : ''}</ellipse>`; };

  // ---------- small props ----------
  const DUCK = '<ellipse cx="0" cy="0.8" rx="7" ry="2.1" fill="#ffffff" opacity="0.35"/><path d="M-5.6 -1.6Q-6.4 -4.6 -3.4 -4.4Q0 -3.6 3.6 -4.2Q6 -4.4 5.6 -1.4Q5 0.8 0 0.9Q-5 0.8 -5.6 -1.6Z" fill="#ffd23a" stroke="#c98a10" stroke-width="0.3"/><path d="M-4 -3.6Q-1 -1.8 3 -3" stroke="#e8a81a" stroke-width="0.5" fill="none"/>'
    + '<path d="M-6 -2.6Q-7.8 -4.2 -7 -5.2Q-5.6 -4.4 -5 -3Z" fill="#ffd23a"/><circle cx="2.6" cy="-6.8" r="3" fill="#ffd23a" stroke="#c98a10" stroke-width="0.3"/><path d="M5.2 -7.3Q7.8 -7 7.5 -6Q6.8 -5.3 5.2 -5.8Z" fill="#ff7a1a"/><circle cx="3.5" cy="-7.6" r="0.55" fill="#1d1e22"/><ellipse cx="1.5" cy="-8.2" rx="1.1" ry="0.7" fill="#ffffff" opacity="0.65"/>';
  const BBALL = r => `<ellipse cx="0" cy="${f1(r * 0.85)}" rx="${f1(r * 1.15)}" ry="${f1(r * 0.3)}" fill="#ffffff" opacity="0.3"/><circle r="${r}" fill="#fbfbf6"/><g clip-path="url(#k7bb)">${[['#e8343c', 0], ['#2a86e6', 60], ['#ffd23a', 120]].map(([c, a]) => `<ellipse rx="${f1(r * 0.36)}" ry="${f1(r * 1.1)}" fill="${c}" transform="rotate(${a})"/>`).join('')}</g><circle r="${f1(r * 0.22)}" fill="#fbfbf6"/><circle r="${r}" fill="url(#k7bs)"/><ellipse cx="${f1(-r * 0.35)}" cy="${f1(-r * 0.4)}" rx="${f1(r * 0.3)}" ry="${f1(r * 0.18)}" fill="#ffffff" opacity="0.8"/>`;
  const BBDEF = r => `<clipPath id="k7bb"><circle r="${r}"/></clipPath>` + G('k7bs', [[0, '#ffffff', 0], [0.6, '#000000', 0], [1, '#000000', 0.3]], 'cx="40%" cy="38%" r="65%"');

  // ======================= INFLATABLE KIDDIE POOL =======================
  N.kiddie = S => { const R0 = 52, RI = 40, TY = 30, WY = 21, BL = '#2a86e6', WT = '#f6f9fc';
    const D = { w: 112, d: 112, round: 1, seats: [{ x: -16, z: 6, h: WY }, { x: 16, z: -6, h: WY }] };
    const prof = top => top ? [[0, 0, 0.955], [2.5, 0, 0.99], [5, 0, 1], [7.4, 0, 0.985], [9, 0, 0.95], [10, 0, 0.9]] : [[0, 0, 0.955], [2.5, 0, 0.99], [5, 0, 1], [7.5, 0, 0.99], [10, 0, 0.955]];
    D.build = P => [0, 1, 2].map(i => cyl(0, i * 10, 0, R0, 10, i === 1 ? WT : BL, { n: 48, rg: prof(i === 2), shine: 1 }));
    D.fx = c => { const p = c.p, k = c.k; let f = '', defs = WDEF + BBDEF(5.2);
      // printed fish / starfish / bubbles round the white tube
      const FISH = '<path d="M-4.2 0Q-1 -3 3 0Q-1 3 -4.2 0Z" fill="#ff8a3a"/><path d="M2.6 0L5.6 -2.2V2.2Z" fill="#ff8a3a"/><circle cx="-2.2" cy="-0.5" r="0.45" fill="#1d2a3a"/><circle cx="-6" cy="-2.4" r="0.8" fill="none" stroke="#5ab4f0" stroke-width="0.35"/><circle cx="-7.4" cy="-4" r="0.5" fill="none" stroke="#5ab4f0" stroke-width="0.3"/>';
      const STAR = '<path d="M0 -3.6L1 -1.2L3.5 -1.1L1.5 0.6L2.2 3.1L0 1.7L-2.2 3.1L-1.5 0.6L-3.5 -1.1L-1 -1.2Z" fill="#ffd23a" stroke="#e8a81a" stroke-width="0.3"/>';
      rep(9, i => { const th = -1.25 + i * 0.42; if (facing(th) < 0.18) return; f += `<g transform="${planeT(p, 0, 0, R0 + 0.15, th, 15)}">${i % 2 ? STAR : FISH}</g>`; });
      // rounded tube crown (top ring reads as a fat inflated torus)
      const cr = `<radialGradient id="k7cr" gradientUnits="userSpaceOnUse" cx="0" cy="0" r="47">${st([[0, '#1a5fb0'], [0.851, '#1a5fb0'], [0.9, '#9ad6ff'], [0.955, '#3f9af0'], [1, BL]])}</radialGradient>`;
      defs += cr + L('k7in', [[0, '#1b5fae'], [1, '#4aa2f2']]);
      f += `<g transform="${planeH(p, TY)}"><path d="${lp(ellPts(0, 0, 46.9, 46.9, 60))}${lp(ellPts(0, 0, RI, RI, 60))}" fill="url(#k7cr)" fill-rule="evenodd"/><ellipse cx="${f1(46 * Math.cos(-0.5))}" cy="${f1(46 * Math.sin(-0.5) + 0)}" rx="1.6" ry="1.6" fill="#f6f9fc" stroke="#9aa1ad" stroke-width="0.3"/></g>`;
      // inner wall + water
      f += `<path d="${sp(p, ellPts(0, 0, RI, RI, 60), TY)}" fill="url(#k7in)"/>`;
      const fl = `<circle r="${RI}" fill="#8fdcf6" opacity="0.55"/>` + [[-14, -10, 1], [12, 12, 0], [-6, 18, 1], [18, -14, 0], [0, 0, 1]].map(([x, z, t], i) => `<g transform="translate(${x} ${z}) rotate(${i * 47}) scale(1.3)" opacity="0.5">${t ? '<path d="M0 -3.6L1 -1.2L3.5 -1.1L1.5 0.6L2.2 3.1L0 1.7L-2.2 3.1L-1.5 0.6L-3.5 -1.1L-1 -1.2Z" fill="#ffd23a"/>' : '<path d="M-4.2 0Q-1 -3 3 0Q-1 3 -4.2 0Z" fill="#ff8a3a"/><path d="M2.6 0L5.6 -2.2V2.2Z" fill="#ff8a3a"/>'}</g>`).join('');
      const W = water(p, { sh: { rx: RI + 0.5 }, y: WY, rim: { y: TY, sh: { rx: RI } }, pal: WP.kid, cs: 0.8, floor: fl, rip: [[-14, 8, 9, 2.6, 0], [10, -10, 8, 3.1, -1.2], [4, 14, 7, 2.2, -0.6]], gl: 7 });
      defs += W.defs; f += W.svg;
      // drifting rubber duck + bobbing beach ball
      { const path = 'M' + ellPts(4, -4, 17, 12, 24).map(q => P2(p(q[0], WY, q[1]))).join('L') + 'Z';
        f += `<g><animateMotion dur="18s" repeatCount="indefinite" path="${path}"/><g transform="scale(${n4(k * 0.95)})"><g>${atV('translate', ['0 0', '0 -0.8', '0 0'], 1.6)}<g>${atV('rotate', ['-5', '5', '-5'], 2.2)}${DUCK}</g></g></g></g>`;
        const bq = p(-20, WY, 12); f += `<g transform="translate(${P2(bq)}) scale(${n4(k)})"><g>${atV('translate', ['0 -5', '0 -5.9', '0 -5'], 1.9, -0.7)}<g>${atV('rotate', ['-14', '14', '-14'], 5)}${BBALL(5.2)}</g></g></g>`; }
      return { defs, front: f, bb: bbOf([p(-R0, 0, -R0), p(R0, 0, R0), p(-R0, 34, R0), p(R0, 34, -R0), p(R0, 0, -R0), p(-R0, 0, R0)], 3) }; };
    return D; };

  // ======================= CEDAR STAVE PLUNGE POOL =======================
  N.plunge = S => { const RO = 58, RI = 51, H = 40, CAP = 43, WY = 35, TH = 72 * PI / 180, sT = Math.sin(TH), cT = Math.cos(TH), CED = '#b9733e', CED2 = '#cf8f55';
    const D = { w: 150, d: 150, round: 1, seats: [{ x: -18, z: 4, h: WY }, { x: 14, z: -10, h: WY }, { x: 2, z: 16, h: WY }] };
    D.build = P => { const o = [arcW(0, 0, 0, RO, RO, RO - RI, H, 4.4, 4.4 + 2 * PI, CED, wd({ n: 56 })), arcW(0, H, 0, RO + 1.6, RO + 1.6, RO - RI + 3.2, 3, 4.4, 4.4 + 2 * PI, CED2, wd({ n: 56 }))];
      [6, 30].forEach(y => o.push(arcW(0, y, 0, RO + 0.9, RO + 0.9, 1.3, 2.6, 4.4, 4.4 + 2 * PI, '#2a2c31', mt({ n: 56, shine: 1 }))));
      return o; };
    // cedar steps (own layer so the stave lines on the tub sit under them)
    const at = (r, t, y) => [sT * r + cT * t, y, cT * r - sT * t];
    D.layers = [{ build: P => [box(sT * 76, 0, cT * 76, 34, 14, 11, CED2, wd({ r: 1.2, yaw: -TH })), box(sT * 66, 0, cT * 66, 34, 28, 10, CED, wd({ r: 1.2, yaw: -TH }))],
      wrap: (p, s) => { let ln = ''; rep(64, i => { const th = i / 64 * 2 * PI; if (facing(th) < 0.04) return; const a = p(RO * Math.sin(th), 0.6, RO * Math.cos(th)), b = p(RO * Math.sin(th), H - 0.4, RO * Math.cos(th));
          ln += `<path d="M${P2(a)}L${P2(b)}" stroke="#6e3f1e" stroke-width="0.55" opacity="${n4(0.35 + 0.4 * facing(th))}"/>`; }); return ln + s; } }];
    D.fx = c => { const p = c.p, k = c.k; let f = '', defs = WDEF;
      // inner staves above the waterline (back half)
      let inn = ''; rep(56, i => { const th = i / 56 * 2 * PI; if (facing(th) > -0.05) return; inn += `<path d="M${P2(p(RI * Math.sin(th), CAP, RI * Math.cos(th)))}L${P2(p(RI * Math.sin(th), WY, RI * Math.cos(th)))}" stroke="#7a4522" stroke-width="0.5" opacity="0.6"/>`; });
      f += `<g clip-path="url(#p7rim)">${inn}</g>`; defs += `<clipPath id="p7rim"><path d="${sp(p, ellPts(0, 0, RI, RI, 60), CAP)}"/></clipPath>`;
      const fl = `<circle r="${RI}" fill="#5a8a7a" opacity="0.35"/>` + rep(9, i => `<path d="M${-RI} ${-RI + 6 + i * 11}H${RI}" stroke="#3b5f55" stroke-width="0.8" opacity="0.35"/>`).join('');
      const leaf = '<path d="M0 0Q2.6 -2.6 6 0Q2.6 2.6 0 0Z" fill="#d9a03a"/><path d="M0 0H6" stroke="#9a6a1e" stroke-width="0.3"/>';
      const W = water(p, { sh: { rx: RI }, y: WY, rim: { y: CAP, sh: { rx: RI } }, pal: WP.cedar, cs: 1.1, floor: fl, rip: [[-10, 6, 10, 3, 0], [16, -8, 9, 3.6, -1.5]], gl: 6,
        over: `<g transform="translate(-22 -18)">${atV('rotate', ['-20', '25', '-20'], 14)}${leaf}</g><g transform="translate(24 10) rotate(140)">${leaf}</g>` });
      defs += W.defs; f += W.svg;
      // floating cedar thermometer
      { const q = p(10, WY, 4); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><g>${atV('translate', ['0 0', '2 -0.6', '0 0'], 4.4)}<ellipse cx="0" cy="0.6" rx="5" ry="1.4" fill="#ffffff" opacity="0.35"/><rect x="-1.4" y="-7.6" width="2.8" height="8" rx="1.4" fill="#c98c56" stroke="#6e3f1e" stroke-width="0.3"/><rect x="-0.4" y="-6.4" width="0.8" height="5" rx="0.4" fill="#ffffff"/><rect x="-0.4" y="-3.8" width="0.8" height="2.4" fill="#e8343c"/><circle cx="0" cy="-8.4" r="1" fill="#6e3f1e"/></g></g>`; }
      // stainless handrails from the top step over the cap into the water
      [-9, 9].forEach(t => { const pts = curve(at(70, t, 28), at(68, t, 62), at(54, t, 50), 10).concat(curve(at(54, t, 50), at(48, t, 44), at(47, t, 26), 6).slice(1)).map(q => p(...q)); f += tube(pts, 1.5, k, '#c9d0d6'); });
      return { defs, front: f, bb: bbOf([p(-RO - 2, 0, -RO - 2), p(RO + 2, 0, RO + 2), p(-RO - 2, CAP, RO + 2), p(RO + 2, CAP, -RO - 2), p(...at(82, 0, 0)), p(...at(70, 0, 62))], 3) }; };
    return D; };

  // ======================= NATURAL ROCK WATERFALL KOI POND =======================
  N.koiPond = S => { const RX = 56, RZ = 42, WY = 5.5, R = rng('koiP'), ST = ['#8f8a7e', '#a39d90', '#7d786d', '#b3ab9c', '#948c7c'], MOSS = '#6f9a4a';
    const D = { w: 140, d: 112 };
    D.build = P => [cyl(0, 0, 0, RX + 5, 4.6, '#4f4436', pt({ rz: RZ + 5, n: 44 }))];
    const rocks = () => { const o = [], RR = rng('koiR');
      rep(26, i => { const t = i / 26 * 2 * PI + 0.08; if (Math.sin(t) < -0.82) return; const r = 6 + RR() * 4, x = (RX + 1.5) * Math.cos(t), z = (RZ + 1.5) * Math.sin(t);
        o.push(ball(x, -0.5, z, r, ST[i % 5], pt({ sx: 1.15 + RR() * 0.3, sy: 0.6 + RR() * 0.25, sz: 0.95, k: 4, n: 10, yaw: RR() * 3 })));
        if (i % 3 === 0) o.push(ball(x - 0.6, r * 0.62, z, r * 0.6, MOSS, pt({ sx: 1.3, sy: 0.28, k: 3, n: 10, soft: 1 }))); });
      // waterfall: two rock pillars, a back boulder and a protruding spill stone
      o.push(ball(-17, -1, -42, 13, ST[2], pt({ sx: 1.1, sy: 1.15, k: 5, n: 12, yaw: 0.6 })), ball(-15, 17, -46, 10, ST[0], pt({ sx: 1.15, sy: 0.9, k: 5, n: 12 })),
        ball(17, -1, -43, 12, ST[4], pt({ sx: 1.1, sy: 1.2, k: 5, n: 12, yaw: 1.4 })), ball(16, 16, -47, 10, ST[1], pt({ sx: 1.2, sy: 0.95, k: 5, n: 12 })),
        ball(0, 6, -54, 15, ST[2], pt({ sx: 1.5, sy: 1.5, k: 5, n: 12 })), box(0, 28, -40, 22, 3, 14, '#7b766a', pt({ r: 2 })), ball(-8, 30, -50, 7, ST[3], pt({ sx: 1.3, sy: 0.7, k: 4, n: 10 })),
        ball(10, 30, -52, 6, ST[0], pt({ sx: 1.2, sy: 0.8, k: 4, n: 10 })), ball(-17, 26, -46, 6, MOSS, pt({ sx: 1.3, sy: 0.3, k: 3, n: 10, soft: 1 })), ball(16, 25, -47, 6, MOSS, pt({ sx: 1.2, sy: 0.3, k: 3, n: 10, soft: 1 })));
      return o; };
    const KOI = [['#f7f2ea', '#e8452c', 1], ['#ff8a2a', '#ffb347', 0], ['#1d1d22', '#e8452c', 2], ['#f2c14a', '#fff1a8', 0], ['#f7f2ea', '#ff7a2a', 1]];
    const fish = (c0, c1, kind) => `<path d="M-6.5 0Q-3.8 -2.3 0 -2.7Q4.6 -2.4 6.6 0Q4.6 2.4 0 2.7Q-3.8 2.3 -6.5 0Z" fill="${c0}"/>`
      + (kind === 1 ? `<path d="M-2 -2.2Q1 -3 3.4 -1.6Q1.8 0.4 -1.6 0.8Z" fill="${c1}"/><path d="M3.6 -1.4Q5.6 -1 5.8 0.4Q4.4 1.4 3 0.6Z" fill="${c1}"/>` : kind === 2 ? `<path d="M-3.4 -1.6Q0 -2.8 3 -1Q1 1.8 -2.4 1.2Z" fill="${c1}"/><path d="M2.4 1Q4.6 1.6 5.4 0.2" stroke="#f7f2ea" stroke-width="1.1" fill="none"/>` : `<path d="M-3 -0.9Q1 -2 4.6 -0.4" stroke="${c1}" stroke-width="0.9" fill="none" opacity="0.8"/>`)
      + `<g>${atV('rotate', ['-22', '22', '-22'], 0.55)}<path d="M-6.2 0Q-8.8 -3.6 -11.2 -3.4Q-9.6 0 -11.2 3.4Q-8.8 3.6 -6.2 0Z" fill="${c0}" opacity="0.88"/></g>`
      + `<path d="M1.2 -2.3Q-0.6 -5.2 -2.6 -4.8Q-1.2 -3 -0.6 -2.4Z" fill="${c0}" opacity="0.8"/><path d="M1.2 2.3Q-0.6 5.2 -2.6 4.8Q-1.2 3 -0.6 2.4Z" fill="${c0}" opacity="0.8"/><circle cx="4.6" cy="-1" r="0.4" fill="#1d1e22"/><circle cx="4.6" cy="1" r="0.4" fill="#1d1e22"/>`;
    const loop = (cx, cz, rx, rz, rev) => `M${f1(cx - rx)} ${cz}A${rx} ${rz} 0 1 ${rev ? 0 : 1} ${f1(cx + rx)} ${cz}A${rx} ${rz} 0 1 ${rev ? 0 : 1} ${f1(cx - rx)} ${cz}Z`;
    const PAD = (r, a) => `<g transform="rotate(${a})"><path d="M0 0L${f1(r * Math.cos(0.22))} ${f1(r * Math.sin(0.22))}A${r} ${r} 0 1 1 ${f1(r * Math.cos(-0.22))} ${f1(r * Math.sin(-0.22))}Z" fill="url(#k7pad)" stroke="#2f6a26" stroke-width="0.35"/>${rep(7, i => { const t = 0.5 + i * 0.8; return `<path d="M0 0L${f1(r * 0.85 * Math.cos(t))} ${f1(r * 0.85 * Math.sin(t))}" stroke="#9ad06a" stroke-width="0.25" opacity="0.7"/>`; }).join('')}</g>`;
    let WAT = null;
    const mkWater = p => { if (WAT) return WAT; const RR = rng('koiW');
      const under = KOI.map((c, i) => { const pth = loop([-14, 10, -6, 16, 4][i], [4, -6, 10, 4, -2][i], [26, 22, 30, 18, 34][i], [16, 14, 18, 12, 20][i], i % 2), d = 16 + i * 4, b = -RR() * d;
          return `<g opacity="0.3" filter="url(#w7m)"><animateMotion dur="${d}s"${B(b)} repeatCount="indefinite" rotate="auto" path="${pth}"/><g transform="translate(2.4 3.4) scale(1.45)"><ellipse rx="7" ry="2.6" fill="#0a1a18"/></g></g><g><animateMotion dur="${d}s"${B(b)} repeatCount="indefinite" rotate="auto" path="${pth}"/><g transform="scale(1.45)">${fish(...c)}</g></g>`; }).join('');
      const floor = rep(30, i => `<ellipse cx="${f1((RR() - 0.5) * RX * 1.7)}" cy="${f1((RR() - 0.5) * RZ * 1.7)}" rx="${f1(1.4 + RR() * 2.2)}" ry="${f1(1 + RR() * 1.6)}" fill="${['#6b6a5a', '#8a8470', '#4f5a48'][i % 3]}" opacity="0.5"/>`).join('') + `<ellipse rx="${RX * 0.6}" ry="${RZ * 0.6}" fill="#0c2622" opacity="0.45" filter="url(#w7m)"/>`;
      const over = [[22, 10, 6.5, 30], [30, -6, 5, 160], [-30, 14, 6, 250], [-24, 24, 4.4, 80], [8, 26, 5.4, 300], [-36, -6, 4.6, 200]].map(([x, z, r, a], i) => `<g transform="translate(${x} ${z})"><g>${atV('rotate', ['-6', '6', '-6'], 9 + i * 1.7, -i)}<ellipse cx="0.8" cy="1" rx="${f1(r)}" ry="${f1(r)}" fill="#0c2622" opacity="0.3"/>${PAD(r, a)}</g></g>`).join('');
      WAT = water(p, { sh: { rx: RX, rz: RZ }, y: WY, pal: WP.koi, cs: 1.25, caust: 0.3, tint: 0.45, floor, under, over, slow: 1, rip: [[0, -26, 12, 1.6, 0], [-4, -24, 9, 1.9, -0.7], [5, -25, 8, 1.4, -0.3], [-20, 6, 7, 3.2, -1], [14, 2, 6, 3.8, -2]], gl: 5 });
      return WAT; };
    D.layers = [{ build: rocks, wrap: (p, s) => mkWater(p).svg + s }];
    D.fx = c => { const p = c.p, k = c.k, W = mkWater(p); let f = '', defs = WDEF + W.defs + L('k7pad', [[0, '#6fb04a'], [1, '#3f7f2c']], 'x1="0" y1="0" x2="1" y2="1"');
      // waterfall off the spill stone + a small side cascade
      const xs = [-8, -4, 0, 4, 8]; f += fall(p, k, xs.map(x => [x, 31, -33]), xs.map(x => [x * 1.05, 26, -29]), xs.map(x => [x * 1.15, WY + 0.4, -26]), { mw: 16 });
      f += fall(p, k, [[-19, 22, -38], [-15, 22, -37]], [[-20, 15, -34], [-15, 15, -33]], [[-21, WY + 0.4, -31], [-15, WY + 0.4, -31]], { streaks: 3, mist: 0, op: 0.7 });
      // lotus flowers on pads
      const lotus = (x, z, s) => { const q = p(x, WY + 0.6, z); let l = ''; [[-50, '#f7b7cf'], [50, '#f7b7cf'], [-28, '#f49ac0'], [28, '#f49ac0'], [-8, '#fcd4e2'], [8, '#fcd4e2'], [0, '#ffe6ee']].forEach(([a, col]) => l += `<path d="M0 0Q-2.4 -3.4 0 -7.6Q2.4 -3.4 0 0Z" fill="${col}" stroke="#d26a94" stroke-width="0.25" transform="rotate(${a})"/>`);
        return `<g transform="translate(${P2(q)}) scale(${n4(k * s)})"><g>${atV('rotate', ['-3', '3', '-3'], 9)}${l}<circle cy="-1.4" r="1.3" fill="#ffd23a"/></g></g>`; };
      f += lotus(22, 10, 1) + lotus(-30, 14, 0.85);
      // cattails + grass tufts between the rocks
      [[-50, -18], [-46, -24], [-53, -12], [44, -26]].forEach(([x, z], i) => { const b0 = p(x, 4, z), h = (30 + i * 4) * k; f += `<g transform="translate(${P2(b0)})"><g>${atV('rotate', ['-3', '4', '-3'], 3.6 + i * 0.4, -i)}<path d="M0 0Q${f1(2 * k)} ${f1(-h * 0.5)} ${f1(1 * k)} ${f1(-h)}" stroke="#5a8a3a" stroke-width="${f1(0.8 * k)}" fill="none"/><rect x="${f1(0.2 * k)}" y="${f1(-h * 0.92)}" width="${f1(1.8 * k)}" height="${f1(7 * k)}" rx="${f1(0.9 * k)}" fill="#7a4a26"/><path d="M0 0Q${f1(-4 * k)} ${f1(-h * 0.4)} ${f1(-6 * k)} ${f1(-h * 0.6)}" stroke="#6fa84a" stroke-width="${f1(0.9 * k)}" fill="none"/></g></g>`; });
      const RR = rng('tuft'); rep(9, i => { const t = i / 9 * 2 * PI + 0.4; if (Math.sin(t) < -0.8) return; const b0 = p((RX + 4) * Math.cos(t), 6, (RZ + 4) * Math.sin(t)); f += `<g transform="translate(${P2(b0)}) scale(${n4(k)})">${rep(5, j => `<path d="M0 0Q${f1((j - 2) * 1.2)} -3 ${f1((j - 2) * 2.2)} ${f1(-5 - RR() * 3)}" stroke="${j % 2 ? '#5f9a3e' : '#7ab854'}" stroke-width="0.7" fill="none"/>`).join('')}</g>`; });
      return { defs, front: f, bb: bbOf([p(-RX - 8, 0, -RZ - 8), p(RX + 8, 0, RZ + 8), p(-RX - 8, 0, RZ + 8), p(RX + 8, 0, -RZ - 8), p(0, 52, -54), p(-52, 42, -18)], 3) }; };
    return D; };

  // ======================= HEATED SALTWATER LAP POOL + SUN SHELF =======================
  N.lapPool = S => { const HX = 90, HZ = 34, IX = 82, IZ = 26, BH = 16, CY = 19, WY = 15, TRV = '#e9dfc9';
    const D = { w: 190, d: 80, seats: [{ x: -52, z: -6, h: WY }, { x: -14, z: 7, h: WY }, { x: 22, z: -6, h: WY }, { x: 66, z: 4, h: 17.5 }] };
    D.build = P => [box(0, 0, 0, 2 * HX, BH, 2 * HZ, '#d4c7ac', cer({ r: 2 })), box(0, BH, (IZ + HZ) / 2, 2 * HX + 1, 3, HZ - IZ + 1, TRV, cer({ r: 1.4 })), box(0, BH, -(IZ + HZ) / 2, 2 * HX + 1, 3, HZ - IZ + 1, TRV, cer({ r: 1.4 })),
      box(-(IX + HX) / 2, BH, 0, HX - IX + 1, 3, 2 * IZ, TRV, cer({ r: 1 })), box((IX + HX) / 2, BH, 0, HX - IX + 1, 3, 2 * IZ, TRV, cer({ r: 1 }))];
    let WAT = null; const mkW = p => { if (WAT) return WAT;
      const lanes = [-13, 13].map(z => `<rect x="${-IX + 8}" y="${z - 1.2}" width="${2 * IX - 48}" height="2.4" fill="#16467e" opacity="0.6"/><rect x="${-IX + 6}" y="${z - 4}" width="1.6" height="8" fill="#16467e" opacity="0.6"/><rect x="${IX - 42}" y="${z - 4}" width="1.6" height="8" fill="#16467e" opacity="0.6"/>`).join('');
      const shelf = `<rect x="46" y="${-IZ}" width="${IX - 46}" height="${2 * IZ}" fill="#c9f2fa" opacity="0.55"/><path d="M46 ${-IZ}V${IZ}" stroke="#ffffff" stroke-width="1.2" opacity="0.7"/>` + [-12, 12].map(x => `<ellipse cx="${x * 4 - 20}" cy="${-IZ + 2}" rx="5" ry="2.2" fill="#fff8d0" opacity="0.7" filter="url(#w7m)"/>`).join('');
      const tiles = `<rect x="${-IX}" y="${-IZ}" width="${2 * IX}" height="${2 * IZ}" fill="url(#k7tile)" opacity="0.35"/>`;
      const rope = rep(34, i => `<circle cx="${f1(-IX + 4 + i * 3.5)}" cy="0" r="1.25" fill="${['#e8343c', '#ffffff', '#1f5fb8'][Math.floor(i / 3) % 3]}" stroke="#0a2a4a" stroke-width="0.2"/>`).join('');
      WAT = water(p, { sh: { hx: IX, hz: IZ, r: 1.5 }, y: WY, rim: { y: CY, sh: { hx: IX, hz: IZ, r: 1.5 } }, pal: WP.pool, cs: 1, floor: tiles + lanes + shelf, over: `<g>${atV('translate', ['0 0', '0 0.6', '0 0'], 3.4)}${rope}</g>`, rip: [[-40, -10, 9, 3.2, 0], [12, 12, 8, 3.6, -1.6], [64, -4, 7, 2.8, -0.8]], gl: 9 });
      return WAT; };
    D.layers = [{ build: P => { const AL = '#f4f4f0', o = []; [[56, -5.6], [56, 5.6], [75, -5.6], [75, 5.6]].forEach(([x, z]) => o.push(box(x, WY - 0.4, z, 1.4, 2.2, 1.4, AL, mt({ r: 0.4 }))));
        o.push(prismZ(-7, 7, [[53, 16.4], [77, 16.4], [77, 17.6], [62, 17.6], [56.6, 25.6], [54.8, 25]], AL, mt({ shine: 1 })), prismZ(-6.3, 6.3, [[61.8, 17.4], [76.4, 17.4], [76.4, 19.8], [62.8, 19.8], [57.8, 26.8], [56.2, 25.8]], '#f0e9da', { mat: 'fab', soft: 1 }), ball(58.8, 26.2, 0, 3.4, '#2f86c8', { mat: 'fab', soft: 1, sx: 0.7, sy: 0.75, sz: 1.7, k: 4, n: 12 }));
        o.push(cyl(79, WY - 0.4, -19, 0.8, 38, AL, mt({ n: 8 })), cyl(79, WY + 34, -19, 17, 5, '#f2ece0', { mat: 'fab', soft: 1, n: 16, rg: [[0, 0, 1], [1.2, 0, 0.96], [5, 0, 0.06]] }), cyl(79, WY + 38.6, -19, 1.2, 1.6, AL, mt({ n: 8 })), cyl(68, WY - 0.4, -14, 3.6, 1.2, '#f2ece0', cer({ n: 14 })), cyl(68, WY + 0.8, -14, 0.6, 5, AL, mt({ n: 6 })), cyl(68, WY + 5.8, -14, 4, 0.8, AL, mt({ n: 14 })));
        return o; },
      wrap: (p, s) => { const W = mkW(p), k = (p(0, 0, 0)[1] - p(0, 1, 0)[1]) / X.CA;
        const back = `<path d="${quad(p, [-IX, CY, -IZ], [IX, CY, -IZ], [IX, WY - 0.5, -IZ], [-IX, WY - 0.5, -IZ])}" fill="#d9eef2"/><g transform="${plane(p, -IZ + 0.05, CY - 0.6, -IX)}"><rect x="0" y="0" width="${2 * IX}" height="2.6" fill="url(#k7mos)"/></g>`
          + `<path d="${quad(p, [-IX, CY, -IZ], [-IX, CY, IZ], [-IX, WY - 0.5, IZ], [-IX, WY - 0.5, -IZ])}" fill="#c3dfe6"/><g transform="${planeX(p, -IX + 0.05, CY - 0.6, -IZ)}"><rect x="0" y="0" width="${2 * IZ}" height="2.6" fill="url(#k7mos)"/></g>`;
        return `<g clip-path="url(#k7rim)">${back}</g>` + W.svg + s + rep(8, i => { if (i % 2) return ''; const a0 = i / 8 * 2 * PI, a1 = a0 + PI / 4, A = p(79 + 16.6 * Math.cos(a0), WY + 34.2, -19 + 16.6 * Math.sin(a0)), Bq = p(79 + 16.6 * Math.cos(a1), WY + 34.2, -19 + 16.6 * Math.sin(a1)), T = p(79, WY + 39, -19); return `<path d="M${P2(T)}L${P2(A)}L${P2(Bq)}Z" fill="#2f86c8" opacity="0.85"/>`; }).join('') + (() => { const q = p(68, WY + 6.6, -14); return `<g transform="translate(${P2(q)}) scale(${n4(k)})"><path d="M-1.6 -5H1.6L1.1 0H-1.1Z" fill="#8fe0f0" opacity="0.8"/><path d="M-1.4 -3.4H1.4L1.1 0H-1.1Z" fill="#ff9a3a"/><circle cx="1.4" cy="-5" r="0.9" fill="#ffd23a"/></g>`; })(); } }];
    D.fx = c => { const p = c.p, k = c.k, W = mkW(p); let f = '';
      const defs = WDEF + FDEF + W.defs + `<clipPath id="k7rim"><path d="${sp(p, rrPts(0, 0, IX, IZ, 1.5), CY)}"/></clipPath>`
        + `<pattern id="k7mos" width="2.6" height="2.6" patternUnits="userSpaceOnUse"><rect width="2.6" height="2.6" fill="#1f6fb0"/><rect x="0.15" y="0.15" width="1.1" height="1.1" fill="#2f8fd0"/><rect x="1.35" y="1.35" width="1.1" height="1.1" fill="#4fb0e8"/><rect x="1.35" y="0.15" width="1.1" height="1.1" fill="#1a5f9a"/></pattern>`
        + `<pattern id="k7tile" width="6" height="6" patternUnits="userSpaceOnUse"><path d="M0 0H6M0 0V6" stroke="#ffffff" stroke-width="0.4"/></pattern>`;
      // steam from the heated water
      [[-60, -8], [-20, 10], [20, -14], [52, 6], [-40, 14]].forEach(([x, z], i) => f += smoke(p(x, WY, z), k, { seed: 'st' + i, n: 3, H: 26, col: '#ffffff', op: 0.32, d: 5 + i * 0.6, r0: 2, r1: 8, drift: 10, b: -i }));
      // stainless ladder
      [-72, -62].forEach(x => f += tube(curve([x, CY + 0.5, IZ + 6], [x, CY + 14, IZ + 6], [x, CY + 10, IZ - 1], 8).concat(curve([x, CY + 10, IZ - 1], [x, CY + 6, IZ - 4], [x, 4, IZ - 4], 5).slice(1)).map(q => p(...q)), 1.5, k, '#cfd6dc'));
      return { defs, front: f, bb: bbOf([p(-HX, 0, -HZ), p(HX, 0, HZ), p(-HX, CY, HZ), p(HX, CY, -HZ), p(-HX, 50, -HZ), p(HX, 46, -HZ), p(-72, CY + 15, IZ + 6)], 3) }; };
    return D; };

  // ======================= GLASS-WALLED INFINITY LAGOON =======================
  N.lagoon = S => { const IX = 90, IZ0 = -52, IZ1 = 55, H = 30, WY = 29.3, ST = '#3d434a', ST2 = '#4a5058', ROCK = ['#5f5a52', '#6e685e', '#585248', '#7a7266'], TEAK = '#8a5a34', LIME = '#e9e1d0';
    const D = { w: 214, d: 124, seats: [{ x: 34, z: -26, h: WY + 1.4 }, { x: 50, z: -26, h: WY + 1.4 }, { x: 66, z: -26, h: WY + 1.4 }, { x: -10, z: 20, h: WY }, { x: 20, z: 30, h: WY }] };
    D.build = P => [box(0, 0, 0, 2 * IX + 12, 2, IZ1 - IZ0 + 6, '#24303a', pt({ r: 1 })), box(0, 0, IZ0 - 3, 2 * IX + 12, H, 6, ST, pt({ r: 1.5 })), box(-IX - 3, 0, 1.5, 6, H, IZ1 - IZ0 + 3, ST, pt({ r: 1.5 })),
      box(IX + 3, 0, 1.5, 6, H - 0.9, IZ1 - IZ0 + 3, '#2c3238', cer({ r: 0.6 })), box(IX + 12, 0, 1.5, 12, 9, IZ1 - IZ0 + 9, ST2, pt({ r: 1.5 })), box(0, 0, IZ1 + 1.5, 2 * IX + 12, 1.8, 3, '#1c2026', mt({ r: 0.6 })),
      box(-IX - 3, H, 1.5, 7, 1.4, IZ1 - IZ0 + 4, '#5a6068', pt({ r: 0.6 })), box(0, H, IZ0 - 3, 2 * IX + 12, 1.4, 7, '#5a6068', pt({ r: 0.6 }))];
    let WAT = null; const SH = { pts: [[-IX, IZ0], [IX + 6, IZ0], [IX + 6, IZ1], [-IX, IZ1]] };
    const mkW = p => { if (WAT) return WAT;
      const floor = `<rect x="${-IX}" y="${IZ0}" width="${2 * IX + 6}" height="${IZ1 - IZ0}" fill="url(#k7lg)" opacity="0.4"/><rect x="18" y="${IZ0}" width="64" height="16" fill="#1a4a5a" opacity="0.5"/>${[34, 50, 66].map(x => `<ellipse cx="${x + 1}" cy="-24" rx="4.6" ry="4.6" fill="#0a3a4a" opacity="0.55"/>`).join('')}` + [-40, 0, 40].map(x => `<ellipse cx="${x}" cy="${IZ0 + 3}" rx="7" ry="2.4" fill="#d8fbff" opacity="0.6" filter="url(#w7m)"/>`).join('');
      WAT = water(p, { sh: SH, y: WY, rim: { p3: [[-IX, H + 1.4, IZ0], [IX + 6, H + 1.4, IZ0], [IX + 6, WY, IZ0], [IX + 6, WY, IZ1], [-IX, WY + 0.5, IZ1], [-IX, H + 1.4, IZ1 - 1]] }, pal: WP.lagoon, cs: 1.2, floor, flow: 1, rip: [[-64, -30, 12, 1.5, 0], [-58, -28, 10, 1.8, -0.6], [-70, -26, 8, 1.3, -0.3], [34, -26, 9, 3, -0.4], [50, -26, 9, 3.2, -1.4], [66, -26, 9, 2.8, -2.2], [42, -22, 6, 3, -1], [-6, 18, 9, 3.4, -2]], gl: 10 });
      return WAT; };
    D.layers = [{ build: P => { const o = [], RR = rng('grot');
        [[-72, 0, -40, 22, 1.3, ROCK[0]], [-52, 6, -46, 17, 1.2, ROCK[1]], [-84, 0, -22, 13, 1.1, ROCK[2]], [-64, 28, -44, 14, 0.95, ROCK[3]], [-80, 22, -34, 10, 1, ROCK[1]], [-44, 22, -48, 9, 1, ROCK[2]], [-60, 44, -46, 9, 0.8, ROCK[0]]].forEach(([x, y, z, r, sy, c2]) => o.push(ball(x, Math.max(y, WY - r * sy * 0.4), z, r, c2, pt({ sx: 1.15, sy, k: 5, n: 12, yaw: RR() * 3 }))));
        [[-66, 50, -46, 9], [-84, 31, -30, 6], [-46, 31, -46, 6]].forEach(([x, y, z, r]) => o.push(ball(x, y, z, r, '#4f8a3a', pt({ sx: 1.3, sy: 0.32, k: 3, n: 10, soft: 1 }))));
        o.push(box(50, WY - 0.5, -42, 64, 11, 12, LIME, cer({ r: 1.5 })), box(50, WY + 10.5, -41, 70, 2.4, 16, TEAK, wd({ r: 1.2 })));
        [34, 50, 66].forEach(x => o.push(cyl(x, WY - 0.6, -26, 4.8, 2.4, '#2fa8b8', cer({ n: 20, rg: [[0, 0, 0.9], [1.6, 0, 1], [2.4, 0, 0.84]], shine: 1 })), cyl(x, WY + 1.7, -26, 3.9, 1, '#f4efe6', { mat: 'fab', soft: 1, n: 18, rg: [[0, 0, 1], [0.6, 0, 1], [1, 0, 0.8]] })));
        return o; },
      wrap: (p, s) => mkW(p).svg + s }];
    D.fx = c => { const p = c.p, k = c.k, W = mkW(p); let f = '', un = '';
      let defs = WDEF + W.defs + L('k7lg', [[0, '#0a4a62'], [1, '#2ad0e8']]) + L('k7gw', [[0, '#5fe0f0', 0.5], [0.25, '#2ab4d0', 0.62], [1, '#06506a', 0.88]]) + L('k7gl', [[0, '#ffffff', 0], [0.48, '#ffffff', 0], [0.5, '#ffffff', 0.5], [0.56, '#ffffff', 0.06], [0.62, '#ffffff', 0.25], [0.66, '#ffffff', 0]], 'x1="0" y1="0" x2="1" y2="0.6"')
        + `<pattern id="k7ray" width="18" height="${f1(WY)}" patternUnits="userSpaceOnUse"><path d="M3 0Q6 ${f1(WY * 0.5)} 2 ${f1(WY)}M11 0Q8 ${f1(WY * 0.4)} 13 ${f1(WY)}" stroke="#d8fbff" stroke-width="1.6" fill="none" opacity="0.45"/><animateTransform attributeName="patternTransform" type="translate" values="0 0;18 0" dur="5s" repeatCount="indefinite"/></pattern>`;
      // glass front: the lagoon in cross-section (light rays, rising bubbles, LED strip), steel cap
      { let g = `<rect x="0" y="0" width="${2 * IX + 6}" height="${f1(WY)}" fill="url(#k7gw)"/><rect x="0" y="0" width="${2 * IX + 6}" height="${f1(WY)}" fill="url(#k7ray)"/>`
          + `<path d="M0 0.4Q20 -0.6 40 0.4T80 0.4T120 0.4T160 0.4T200 0.4" stroke="#ffffff" stroke-width="0.8" fill="none" opacity="0.8">${atV('translate', ['0 0', '-20 0', '0 0'], 4)}</path>`;
        const RR = rng('bub'); rep(14, i => { const x = 8 + RR() * (2 * IX - 10), d = 3 + RR() * 3, b = -RR() * d; g += `<circle cx="${f1(x)}" cy="${f1(WY)}" r="${f1(0.5 + RR() * 0.8)}" fill="none" stroke="#e8fdff" stroke-width="0.3"><animate attributeName="cy" values="${f1(WY - 1)};1" dur="${n4(d)}s"${B(b)} repeatCount="indefinite"/><animate attributeName="cx" values="${f1(x)};${f1(x + 2)};${f1(x - 1)}" dur="${n4(d)}s"${B(b)} repeatCount="indefinite"/></circle>`; });
        g += `<rect x="0" y="${f1(WY - 1.6)}" width="${2 * IX + 6}" height="1.2" fill="#8af6ff" opacity="0.9"/><rect x="0" y="0" width="${2 * IX + 6}" height="${f1(WY)}" fill="url(#k7gl)"/><rect x="0" y="0" width="${2 * IX + 6}" height="${f1(WY)}" fill="none" stroke="#e8fbff" stroke-width="0.5" opacity="0.6"/>`;
        f += `<g transform="${plane(p, IZ1 + 0.2, WY, -IX)}">${g}</g>` + `<path d="${quad(p, [-IX - 6, WY + 0.5, IZ1 + 0.3], [IX + 6, WY + 0.5, IZ1 + 0.3], [IX + 6, WY - 0.6, IZ1 + 0.3], [-IX - 6, WY - 0.6, IZ1 + 0.3])}" fill="#cfd6dc"/>`; }
      // infinity edge: sheet spilling over the knife edge into the catch trough
      { const zs = rep(9, i => IZ0 + 2 + i * (IZ1 - IZ0 - 4) / 8); f += fall(p, k, zs.map(z => [IX + 6, WY, z]), zs.map(z => [IX + 6.6, 20, z]), zs.map(z => [IX + 8, 9, z]), { streaks: 22, mist: 0, op: 0.65 });
        const T = water(p, { sh: { pts: [[IX + 7, IZ0 - 2], [IX + 17, IZ0 - 2], [IX + 17, IZ1 + 4], [IX + 7, IZ1 + 4]] }, y: 8.6, pal: WP.lagoon, flow: 1, gl: 3, wave: 0.7 }); defs += T.defs; f += T.svg; }
      // grotto: dark cave mouth behind a falling curtain
      { const cq = p(-62, 36, -27); f += `<ellipse cx="${f1(cq[0])}" cy="${f1(cq[1])}" rx="${f1(11 * k)}" ry="${f1(8 * k)}" fill="#1a1612" opacity="0.92"/><ellipse cx="${f1(cq[0])}" cy="${f1(cq[1] + 3 * k)}" rx="${f1(8 * k)}" ry="${f1(4 * k)}" fill="#2a8aa0" opacity="0.5"/>`;
        const xs = [-74, -68, -62, -56, -50]; f += fall(p, k, xs.map(x => [x, 50, -32]), xs.map(x => [x, 44, -24]), xs.map(x => [x, WY + 0.4, -20]), { mw: 22, op: 0.7 }); }
      // tropical fronds on the grotto + swim-up bar drinks
      [[-66, 54, -46, 0], [-86, 34, -30, 1], [-46, 34, -48, 2]].forEach(([x, y, z, i]) => { const q = p(x, y, z); f += `<g transform="translate(${P2(q)}) scale(${n4(k)})"><g>${atV('rotate', ['-4', '4', '-4'], 4 + i, -i)}${rep(6, j => `<path d="M0 0Q${f1(Math.cos(-PI * (0.1 + j * 0.16)) * 8)} ${f1(Math.sin(-PI * (0.1 + j * 0.16)) * 10 - 2)} ${f1(Math.cos(-PI * (0.1 + j * 0.16)) * 16)} ${f1(Math.sin(-PI * (0.1 + j * 0.16)) * 12 + 4)}" stroke="${j % 2 ? '#3f8a34' : '#5aaa44'}" stroke-width="2.2" stroke-linecap="round" fill="none"/>`).join('')}</g></g>`; });
      const drink = (x, z, kind) => { const q = p(x, WY + 12.9, z); return `<g transform="translate(${P2(q)}) scale(${n4(k)})">` + (kind ? '<ellipse cx="0" cy="-2.6" rx="2.8" ry="2.8" fill="#7a4a26"/><ellipse cx="-0.8" cy="-3.4" rx="1" ry="0.7" fill="#b07a4a"/><path d="M0.6 -5L2.4 -9" stroke="#ff4fb8" stroke-width="0.4"/>'
          : '<path d="M-2 -7.6H2L1 -2.4H-1Z" fill="#ff9a3a" opacity="0.9"/><path d="M-2 -7.6H2L1 -2.4H-1Z" fill="none" stroke="#ffffff" stroke-width="0.3" opacity="0.8"/><path d="M0 -2.4V0M-1.4 0H1.4" stroke="#ffffff" stroke-width="0.35"/><path d="M0.5 -7.6L2.6 -11" stroke="#7a4a26" stroke-width="0.25"/><path d="M0.4 -11.6Q2.6 -13.2 4.8 -11.6Z" fill="#ffd23a"/><circle cx="-1.2" cy="-7.8" r="0.8" fill="#ff5a3a"/>') + '</g>'; };
      f += drink(36, -42, 0) + drink(48, -40, 1) + drink(60, -42, 0) + drink(70, -40, 1);
      return { defs, front: f, bb: bbOf([p(-IX - 7, 0, IZ0 - 6), p(IX + 18, 0, IZ1 + 6), p(-IX - 7, 0, IZ1 + 6), p(IX + 18, 0, IZ0 - 6), p(-62, 70, -46), p(-90, 50, -30), p(IX + 18, H, IZ0 - 6)], 3) }; };
    return D; };

  // ======================= CARRARA MARBLE TIERED FOUNTAIN WITH GOLD SWANS =======================
  N.marbleFount = S => { const BR = 58, BI = 50, BY = 2.5, BH = 16, BW = 15.5, MY = 47.4, MR = 26, TY = 70, TR = 13.6;
    const D = { w: 128, d: 128, round: 1 };
    const balu = (y, r, h) => cyl(0, y, 0, r, h, MARB, cer({ n: 20, rg: [[0, 0, 1.25], [h * 0.12, 0, 0.9], [h * 0.45, 0, 0.72], [h * 0.75, 0, 0.82], [h * 0.9, 0, 1.05], [h, 0, 1.2]] }));
    D.build = P => [cyl(0, 0, 0, BR + 5, BY, '#e2ddd3', cer({ n: 48 })), arcW(0, BY, 0, BR, BR, BR - BI, BH, 4.4, 4.4 + 2 * PI, MARB, cer({ n: 52 })), arcW(0, BY + BH, 0, BR + 1, BR + 1, BR - BI + 1.6, 1.6, 4.4, 4.4 + 2 * PI, GOLD, mt({ n: 52, shine: 1 }))];
    const swan = (o, x, z, d) => { const by = BW - 0.6; o.push(ball(x, by, z, 7, GOLD, mt({ sx: 1.45, sy: 0.55, k: 5, n: 14, shine: 1 })), ball(x + d * 1.5, by + 2.6, z - 2.6, 4.4, GOLD, mt({ sx: 1.5, sy: 0.5, k: 4, n: 12 })), ball(x + d * 1.5, by + 2.6, z + 2.6, 4.4, GOLD, mt({ sx: 1.5, sy: 0.5, k: 4, n: 12 })), ball(x + d * 8.6, by + 4.6, z, 2.2, GOLD, mt({ sx: 1.2, sy: 1.3, k: 3, n: 8 })));
      [[-5.6, 4.4, 2.3], [-7, 8, 2], [-6.4, 11.6, 1.8], [-4.8, 14.6, 1.7]].forEach(([dx, dy, r]) => o.push(ball(x + d * dx, by + dy, z, r, GOLD, mt({ k: 3, n: 8 }))));
      o.push(ball(x - d * 3.6, by + 16.6, z, 2.3, GOLD, mt({ sx: 1.25, k: 3, n: 8, shine: 1 })), ball(x - d * 5.8, by + 16.2, z, 1, '#b9862a', mt({ sx: 1.6, k: 3, n: 6 }))); };
    const SW = [[-38, 14, -1], [38, -12, 1], [30, 26, 1], [-30, -24, -1]];
    let WB = null, WM = null, WT = null;
    const mk = p => { if (WB) return; WB = water(p, { sh: { rx: BI + 0.5 }, y: BW, rim: { y: BY + BH + 1.6, sh: { rx: BI } }, pal: WP.marble, cs: 1, rip: rep(9, i => { const t = -0.4 + i * 0.24; return [32 * Math.cos(t + 0.5), 32 * Math.sin(t + 0.5), 7, 1.6 + (i % 3) * 0.3, -i * 0.3]; }).concat(SW.map(([x, z, d], i) => [x - d * 17, z, 5, 1.4, -i * 0.4])), gl: 8 });
      WM = water(p, { sh: { rx: MR }, y: MY - 1.6, rim: { y: MY, sh: { rx: MR } }, pal: WP.marble, cs: 0.7, rip: rep(5, i => [16 * Math.cos(i * 1.25), 16 * Math.sin(i * 1.25), 5, 1.4, -i * 0.3]), gl: 4 });
      WT = water(p, { sh: { rx: TR }, y: TY - 1.2, rim: { y: TY, sh: { rx: TR } }, pal: WP.marble, cs: 0.5, rip: [[0, 0, 7, 1.2, 0], [4, 3, 4, 1, -0.5]], gl: 2, edge: 3 }); };
    D.layers = [
      { build: P => { const o = [balu(BW, 9, MY - 8 - BW), cyl(0, MY - 8, 0, MR + 1.6, 8, MARB, cer({ n: 28, rg: [[0, 0, 0.3], [3, 0, 0.66], [6, 0, 0.94], [8, 0, 1]] })), arcW(0, MY - 1, 0, MR + 2.2, MR + 2.2, 2.6, 1.6, 4.4, 4.4 + 2 * PI, GOLD, mt({ n: 30, shine: 1 }))]; SW.forEach(s => swan(o, ...s)); return o; }, wrap: (p, s) => { mk(p); return WB.svg + s; } },
      { build: P => [balu(MY - 1.6, 4.8, TY - 5 - MY + 1.6), cyl(0, TY - 5, 0, TR + 1.6, 5, MARB, cer({ n: 20, rg: [[0, 0, 0.36], [3, 0, 0.84], [5, 0, 1]] })), arcW(0, TY - 0.6, 0, TR + 2, TR + 2, 2, 1, 4.4, 4.4 + 2 * PI, GOLD, mt({ n: 20, shine: 1 }))], wrap: (p, s) => { mk(p); return WM.svg + s; } },
      { build: P => [cyl(0, TY - 1.2, 0, 2.6, 4, GOLD, mt({ n: 12 })), ball(0, TY + 4.4, 0, 3.6, GOLD, mt({ sy: 1.5, k: 5, shine: 1 })), ball(0, TY + 14, 0, 1.4, GOLD, mt({ k: 3 }))], wrap: (p, s) => { mk(p); return WT.svg + s; } }];
    D.fx = c => { const p = c.p, k = c.k; mk(p); let f = '';
      const defs = WDEF + WB.defs + WM.defs + WT.defs;
      // crown jet from the finial falling back into the top bowl
      rep(8, i => { const t = i / 8 * 2 * PI; f += stream(p, k, [0, TY + 15, 0], [Math.cos(t) * 6, TY + 30, Math.sin(t) * 6], [Math.cos(t) * 10, TY - 1, Math.sin(t) * 10], 0.9, 0.7, -i * 0.09); });
      f += stream(p, k, [0, TY + 15, 0], [0, TY + 28, 0], [0, TY + 21, 0], 1.6, 0.5);
      // curtains spilling from both bowl rims (front half)
      const curt = (r0, y0, r1, y1, n, w) => { let s = ''; rep(n, i => { const t = -PI / 6 + (i + 0.5) / n * PI + (PI / 3) * 0; const cs = Math.cos(t + PI / 3 - PI / 2 + PI / 6), sn = Math.sin(t + PI / 3 - PI / 2 + PI / 6); s += stream(p, k, [cs * r0, y0, sn * r0], [cs * (r0 + 4), y0 - (y0 - y1) * 0.25, sn * (r0 + 4)], [cs * r1, y1, sn * r1], w, 0.55 + (i % 3) * 0.06, -i * 0.11); }); return s; };
      f += curt(TR + 2, TY - 0.2, TR + 6, MY - 1.4, 10, 1) + curt(MR + 2.2, MY + 0.4, 33, BW + 0.2, 16, 1.1);
      // swans spout from their beaks into the basin
      SW.forEach(([x, z, d], i) => { f += stream(p, k, [x - d * 6.4, BW + 15.8, z], [x - d * 12, BW + 19, z], [x - d * 17, BW, z], 0.7, 0.6, -i * 0.2); });
      f += `<ellipse cx="${f1(p(0, BW, 0)[0])}" cy="${f1(p(0, BW + 2, 0)[1])}" rx="${f1(38 * k)}" ry="${f1(10 * k)}" fill="#ffffff" filter="url(#w7m)" opacity="0.18">${an('opacity', '0.12;0.26;0.12', 3)}</ellipse>`;
      return { defs, front: f, bb: bbOf([p(-BR - 5, 0, -BR - 5), p(BR + 5, 0, BR + 5), p(-BR - 5, 0, BR + 5), p(BR + 5, 0, -BR - 5), p(0, TY + 34, 0)], 3) }; };
    return D; };

  // ======================= FLOATING WATER-AND-FIRE OBSIDIAN OBELISK =======================
  N.obelisk = S => { const RB = 47, RI = 43, WY = 10, TOP = 11, OB = '#0f0c16', YW = 0.32, A0 = 8.4, Y0 = 36, Y1 = 45, Y2 = 116, Y3 = 130;
    const D = { w: 104, d: 104, round: 1, glow: () => ({ y: 20, r: 70 }) };
    D.build = P => [cyl(0, 0, 0, RB + 4, 3, '#1b1a20', mt({ n: 44, shine: 1 })), arcW(0, 3, 0, RB, RB, RB - RI, 8, 4.4, 4.4 + 2 * PI, '#121016', { mat: 'gloss', n: 48, shine: 1 })];
    const FL = rep(8, i => { const t = i / 8 * 2 * PI + 0.2, r = i % 2 ? 24 : 18; return [r * Math.cos(t), r * Math.sin(t), i]; }).concat([[0, 0, 8], [6, -4, 9], [-5, 5, 10]]);
    let WAT = null; const mkW = p => WAT || (WAT = water(p, { sh: { rx: RI }, y: WY, rim: { y: TOP, sh: { rx: RI - 0.5 } }, pal: WP.night, cs: 0.9, caust: 0.28,
      floor: `<circle r="${RI}" fill="url(#o7led)" opacity="0.6"/>`, under: FL.map(([x, z]) => `<ellipse cx="${f1(x)}" cy="${f1(z)}" rx="7" ry="7" fill="#ff7a22" opacity="0.4" filter="url(#w7m)">${an('opacity', '0.25;0.5;0.3;0.45;0.25', 1.2)}</ellipse>`).join(''),
      rip: FL.slice(0, 8).map(([x, z, i]) => [x, z, 8, 1.4 + (i % 3) * 0.25, -i * 0.21, '#ffb070', 0.6]).concat([[0, 0, 14, 2.4, 0, '#ffd0a0', 0.5]]), gl: 6 }));
    const corner = (j, y, sc) => { const u = (j === 0 || j === 3 ? A0 : -A0) * sc, v = (j < 2 ? A0 : -A0) * sc, cy = Math.cos(YW), sy = Math.sin(YW); return [u * cy - v * sy, y, u * sy + v * cy]; };
    D.layers = [{ build: P => [solid({ ax: 'y', sh: 'rr', c: [0, 0], a: A0, b: A0, r: 0.3, yaw: YW, rings: [[Y0, 0, 0.05], [Y1, 0, 1], [Y2, 0, 0.6], [Y3, 0, 0.04]], col: OB, mat: 'gloss', shine: 1 })],
      wrap: (p, s) => { const W = mkW(p), k = (p(0, 0, 0)[1] - p(0, 1, 0)[1]) / X.CA; let back = '', front = '', ed = '';
        FL.forEach(([x, z, i]) => { const fl = flames(p(x, WY, z), k * (i >= 8 ? 0.9 : 0.8), { seed: 'ob' + i, n: 3, sp: 4, h: i >= 8 ? 24 : 19, w: 3.2, emb: 2, noGlow: i % 2 }); if (0.5 * x + 0.866 * z < 2) back += fl; else front += fl; });
        // razor edges + firelight on the lower faces
        rep(4, j => { const nx = corner(j, 0, 1), dot = (0.5 * nx[0] + 0.866 * nx[2]) / A0 / 1.414; if (dot < -0.35) return; const pts = [corner(j, Y0, 0.05), corner(j, Y1, 1), corner(j, Y2, 0.6), corner(j, Y3, 0.04)].map(q => p(...q));
          ed += `<path d="M${pts.map(P2).join('L')}" fill="none" stroke="${dot > 0.6 ? '#f2e8ff' : '#9a88c8'}" stroke-width="${f1((dot > 0.6 ? 0.5 : 0.35) * k)}" opacity="${n4(0.45 + dot * 0.5)}"/>`; });
        rep(4, j => { const a = corner(j, 0, 1), b = corner((j + 1) % 4, 0, 1), nx = (a[0] + b[0]) / 2, nz = (a[2] + b[2]) / 2; if (0.5 * nx + 0.866 * nz < 0) return;
          ed += `<path d="${quad(p, corner(j, Y1, 1), corner((j + 1) % 4, Y1, 1), corner((j + 1) % 4, Y1 + 34, 0.86), corner(j, Y1 + 34, 0.86))}" fill="url(#o7fl)" opacity="0.75">${an('opacity', '0.55;0.85;0.6;0.8;0.55', 1.4)}</path><path d="${quad(p, corner(j, Y0, 0.05), corner((j + 1) % 4, Y0, 0.05), corner((j + 1) % 4, Y1, 1), corner(j, Y1, 1))}" fill="#ff8a3a" opacity="0.45"/>`; });
        const q0 = p(0, Y3, 0); ed += `<circle cx="${f1(q0[0])}" cy="${f1(q0[1])}" r="${f1(1.6 * k)}" fill="#ffe0c0" filter="url(#f7b)">${an('opacity', '0.4;1;0.4', 2.4)}</circle>`;
        return W.svg + back + `<g>${atV('translate', ['0 0', `0 ${f1(-4 * k)}`, '0 0'], 4.4)}${s}${ed}</g>` + front; } }];
    D.fx = c => { const p = c.p, k = c.k, W = mkW(p); let f = '', un = '';
      const defs = WDEF + FDEF + W.defs + G('o7led', [[0, '#ff7a22', 0], [0.82, '#ff7a22', 0], [0.95, '#ff9a4a', 0.7], [1, '#ff7a22', 0]], 'cx="50%" cy="50%" r="50%"') + L('o7fl', [[0, '#ff9a4a', 0], [1, '#ff7a22', 0.7]]);
      f += `<path d="M${ellPts(0, 0, RB - 0.6, RB - 0.6, 20, -PI / 6, 5 * PI / 6).map(q => P2(p(q[0], TOP, q[1]))).join('L')}" fill="none" stroke="#c8b8ff" stroke-width="${f1(0.45 * k)}" opacity="0.55"/>`;
      f += smoke(p(0, WY + 30, 0), k, { seed: 'obs', n: 4, H: 60, col: '#ffffff', op: 0.12, d: 6, r1: 14 });
      un += glowE(p, 0, 0, 0, 60, 60, '#ff8a3a', 0.35, 1);
      return { defs, under: un, front: f, bb: bbOf([p(-RB - 6, 0, -RB - 6), p(RB + 6, 0, RB + 6), p(-RB - 6, 0, RB + 6), p(RB + 6, 0, -RB - 6), p(0, Y3 + 12, 0)], 3) }; };
    return D; };

  // ======================= TERRACOTTA MEXICAN CHIMINEA =======================
  N.chiminea = S => { const BY = 12, R0 = 30, TC = '#c4683a', TM = PI / 6;
    const RG = [[0, 0.5], [3, 0.74], [9, 0.93], [17, 1], [26, 0.95], [33, 0.78], [38, 0.56], [42, 0.4], [46, 0.3], [86, 0.27], [89, 0.31], [92, 0.3]];
    const Rb = y => { for (let i = 0; i < RG.length - 1; i++) if (y <= RG[i + 1][0]) return R0 * lerp(RG[i][1], RG[i + 1][1], (y - RG[i][0]) / (RG[i + 1][0] - RG[i][0])); return R0 * RG[RG.length - 1][1]; };
    const D = { w: 70, d: 70, round: 1, glow: () => ({ y: 30, r: 60 }) };
    D.build = P => [arcW(0, BY - 2, 0, 21, 21, 2.2, 2, 4.4, 4.4 + 2 * PI, '#1c1c1f', mt({ n: 30 })), cyl(0, BY, 0, R0, 46, TC, pt({ n: 40, rg: RG.slice(0, 9).map(r => [r[0], 0, r[1]]) })),
      cyl(0, BY + 45, 0, R0 * 0.3, 41, TC, pt({ n: 28, rg: [[0, 0, 1], [41, 0, 0.9]] })), cyl(0, BY + 86, 0, R0 * 0.31, 6, shade7(TC), pt({ n: 28, rg: [[0, 0, 0.9], [3, 0, 1.03], [6, 0, 1]] }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '', un = '';
      const defs = FDEF + G('c7in', [[0, '#8a3414'], [0.55, '#3a160c'], [1, '#120806']], 'cx="50%" cy="80%" r="75%"') + L('c7lip', [[0, '#7a3a20'], [1, '#e0864a']]);
      // stand legs with scroll feet
      [TM + 0.2, TM + 2.3, TM + 4.4].forEach(t => { const a = p(20 * Math.sin(t), BY - 1, 20 * Math.cos(t)), m = p(23 * Math.sin(t), 5, 23 * Math.cos(t)), b = p(26 * Math.sin(t), 0.8, 26 * Math.cos(t));
        const s = tube([a, m, b], 1.6, k, '#26262a', '#7a7a80') + `<path d="M${P2(b)}c${f1(2 * k)} ${f1(0.4 * k)} ${f1(3 * k)} ${f1(-2 * k)} ${f1(1.2 * k)} ${f1(-2.6 * k)}" fill="none" stroke="#26262a" stroke-width="${f1(1.4 * k)}" stroke-linecap="round"/>`; if (facing(t) > -0.1) f += s; else bk += s; });
      // surface mapping on the body: arc length u, height above the stand yr, depth inset d
      const S3 = (u, yr, d) => { const R = Rb(yr) - (d || 0), th = TM + u / Math.max(4, Rb(yr)); return p(R * Math.sin(th), BY + yr, R * Math.cos(th)); };
      const outer = (() => { const o = []; rep(9, i => o.push([-14, 5 + 12 * i / 8])); rep(17, i => { const a = PI + i / 16 * PI; o.push([14 * Math.cos(a), 17 - 9 * Math.sin(a)]); }); rep(9, i => o.push([14, 17 - 12 * i / 8])); return o; })();
      const pth = (pts, d) => 'M' + pts.map(([u, y]) => P2(S3(u, y, d))).join('L') + 'Z';
      const OUT = pth(outer, -0.2), INN = pth(outer.map(([u, y]) => [u * 0.84, 6 + (y - 5) * 0.86]), 3.4);
      // painted Talavera band on the shoulder
      { let bnd = ''; const vis = yr => rep(37, i => (-1.5 + i / 12) * Rb(yr)); const line = (yr, col, w) => `<path d="M${vis(yr).map(u => P2(S3(u, yr, -0.1))).join('L')}" fill="none" stroke="${col}" stroke-width="${f1(w * k)}" stroke-linecap="round"/>`;
        bnd += line(29.6, '#2a5aa8', 0.9) + line(36, '#2a5aa8', 0.9) + `<path d="M${vis(32.8).map((u, i) => P2(S3(u, i % 2 ? 31.2 : 34.4, -0.1))).join('L')}" fill="none" stroke="#f6efe0" stroke-width="${f1(0.7 * k)}" stroke-linejoin="round"/>`;
        vis(32.8).forEach((u, i) => { if (i % 2) return; const q = S3(u, 32.8, -0.1); bnd += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.55 * k)}" fill="${i % 4 ? '#f2c14a' : '#2fa89a'}"/>`; });
        f += bnd; }
      const visClip = '';
      // mouth: lip (wall thickness), recessed chamber, logs + fire kept inside
      f += `<path d="${OUT}" fill="url(#c7lip)"/><path d="${INN}" fill="url(#c7in)"/>`;
      let ins = ''; const L0 = S3(-8, 7.4, 9), L1 = S3(8, 8.2, 8), L2 = S3(-7, 8.4, 6), L3 = S3(7, 7.2, 11);
      ins += `<ellipse cx="${f1((L0[0] + L1[0]) / 2)}" cy="${f1((L0[1] + L1[1]) / 2 + 1.4 * k)}" rx="${f1(11 * k)}" ry="${f1(2.6 * k)}" fill="#ff6a1a">${an('opacity', '0.6;1;0.7;0.9;0.6', 1.1)}</ellipse>`;
      [[L0, L1], [L2, L3]].forEach(([a, b]) => ins += `<path d="M${P2(a)}L${P2(b)}" stroke="#2a1608" stroke-width="${f1(3.6 * k)}" stroke-linecap="round"/><path d="M${P2(a)}L${P2(b)}" stroke="#5a3418" stroke-width="${f1(2.6 * k)}" stroke-linecap="round"/><path d="M${P2(a)}L${P2(b)}" stroke="#ff7a2a" stroke-width="${f1(0.5 * k)}" stroke-dasharray="${f1(1.4 * k)} ${f1(2 * k)}">${an('opacity', '0.4;1;0.5', 0.9)}</path><circle cx="${f1(b[0])}" cy="${f1(b[1])}" r="${f1(1.3 * k)}" fill="#ff9a3a"/>`);
      ins += flames(S3(0, 8.6, 7), k * 0.95, { seed: 'chim', n: 6, sp: 8, h: 20, w: 3.6, emb: 3 });
      f += `<g clip-path="url(#c7m)">${ins}</g>` + `<path d="${INN}" fill="none" stroke="#2a120a" stroke-width="${f1(0.6 * k)}" opacity="0.7"/>`;
      // chimney: glowing throat, smoke + sparks
      const ct = p(0, BY + 92, 0), cr = Rb(92) - 2; f += `<ellipse cx="${f1(ct[0])}" cy="${f1(ct[1])}" rx="${f1(cr * k * 1.02)}" ry="${f1(cr * k * X.SA * 1.02)}" fill="#2a120a"/><ellipse cx="${f1(ct[0])}" cy="${f1(ct[1])}" rx="${f1(cr * k * 0.6)}" ry="${f1(cr * k * X.SA * 0.6)}" fill="#ff7a2a" opacity="0.7">${an('opacity', '0.4;0.85;0.5', 1.4)}</ellipse>`;
      f += smoke(ct, k, { seed: 'chs', n: 5, H: 50, col: '#9a948e', op: 0.38, d: 4.6, r1: 11, drift: 18 }) + `<g transform="translate(${P2(ct)}) scale(${n4(k)})">${embers(rng('che'), 4, 6, 8)}</g>`;
      un += glowE(p, 34 * Math.sin(TM), 0, 34 * Math.cos(TM), 26, 18, '#ff8a3a', 0.45, 1);
      return { defs: defs + `<clipPath id="c7m"><path d="${INN}"/></clipPath>` + visClip, back: bk, under: un, front: f, bb: bbOf([p(-34, 0, -34), p(34, 0, 34), p(-34, 0, 34), p(34, 0, -34), p(0, BY + 92 + 50, 0), p(18, BY + 92 + 50, 0)], 3) }; };
    return D; };

  // ======================= PORTABLE STEEL BOWL FIRE PIT (tap to light) =======================
  N.bowlPit = S => { const lit = isPlay(S), BY = 13, RT = 33, LY = 31.2, LR = 37.5, LI = 32, AY = 21, STL = '#34363b';
    const D = { w: 84, d: 84, round: 1, glow: lit ? () => ({ y: 30, r: 70 }) : undefined };
    D.build = P => [cyl(0, 10.5, 0, 9, 2.6, '#222428', mt({ n: 16 })), cyl(0, BY, 0, RT, 17, STL, mt({ n: 44, rg: [[0, 0, 0.42], [4, 0, 0.7], [10, 0, 0.9], [17, 0, 1]], shine: 1 })), arcW(0, LY - 1.6, 0, LR, LR, LR - LI, 1.6, 4.4, 4.4 + 2 * PI, '#2a2c30', mt({ n: 52, shine: 1 }))];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '', un = '';
      let defs = FDEF + G('b7in', [[0, '#151517'], [0.6, '#1e1f22'], [0.85, '#3a3c41'], [1, '#55585e']], 'cx="50%" cy="58%" r="55%"') + G('b7ash', [[0, lit ? '#ff7a2a' : '#45413d'], [0.5, lit ? '#a8422a' : '#5e5953'], [1, lit ? '#b8b2aa' : '#857f77']], 'cx="50%" cy="50%" r="50%"')
        + `<clipPath id="b7rim"><path d="${sp(p, ellPts(0, 0, LI, LI, 60), LY)}"/></clipPath><clipPath id="b7up"><path d="${aboveFront(p, LR, LY)}"/></clipPath>`;
      [PI / 12, PI / 12 + PI / 2, PI / 12 + PI, PI / 12 + 1.5 * PI].forEach(t => { const pts = [p(10 * Math.sin(t), 11, 10 * Math.cos(t)), p(24 * Math.sin(t), 9.5, 24 * Math.cos(t)), p(33 * Math.sin(t), 0.8, 33 * Math.cos(t))];
        const s = tube(pts, 1.9, k, '#2c2e33', '#8a8f98') + `<ellipse cx="${f1(pts[2][0])}" cy="${f1(pts[2][1] + 0.4 * k)}" rx="${f1(2.6 * k)}" ry="${f1(1.1 * k)}" fill="#141416"/>`; if (facing(t) > 0) f += s; else bk += s; });
      // soot bloom on the outer bowl just under the lip
      rep(7, i => { const th = -0.9 + i * 0.4; if (facing(th) < 0.1) return; const q = p((RT - 0.5) * Math.sin(th), LY - 4.5, (RT - 0.5) * Math.cos(th)); f += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(5 * k)}" ry="${f1(2.2 * k)}" fill="#0c0c0e" opacity="0.4" filter="url(#f7b)"/>`; });
      // inside the bowl: soot wall, ash bed, coals, logs
      let ins = `<path d="${sp(p, ellPts(0, 0, LI, LI, 60), LY)}" fill="url(#b7in)"/><g transform="${planeH(p, AY)}"><ellipse rx="24" ry="24" fill="url(#b7ash)"/>`;
      const RR = rng('pitc'); rep(26, i => { const a = RR() * 2 * PI, r = Math.sqrt(RR()) * 20, x = r * Math.cos(a), z = r * Math.sin(a); ins += `<ellipse cx="${f1(x)}" cy="${f1(z)}" rx="${f1(1.4 + RR())}" ry="${f1(1.1 + RR() * 0.8)}" fill="${lit ? (i % 3 ? '#ff5a1a' : '#ffb347') : (i % 3 ? '#1d1c1b' : '#3a3836')}">${lit ? an('opacity', '0.55;1;0.6', n4(0.8 + RR()), n4(-RR())) : ''}</ellipse>`; });
      ins += '</g>';
      const log = (a, b) => { const A = p(...a), Bq = p(...b); return `<path d="M${P2(A)}L${P2(Bq)}" stroke="#1a120c" stroke-width="${f1(4.8 * k)}" stroke-linecap="round"/><path d="M${P2(A)}L${P2(Bq)}" stroke="${lit ? '#3a2416' : '#6e4a2c'}" stroke-width="${f1(3.8 * k)}" stroke-linecap="round"/><path d="M${P2(A)}L${P2(Bq)}" stroke="${lit ? '#ff6a1a' : '#9a7048'}" stroke-width="${f1(0.6 * k)}" stroke-dasharray="${f1(2 * k)} ${f1(1.6 * k)}" transform="translate(0 ${f1(-0.9 * k)})">${lit ? an('opacity', '0.4;1;0.5', 1) : ''}</path><circle cx="${f1(Bq[0])}" cy="${f1(Bq[1])}" r="${f1(1.9 * k)}" fill="${lit ? '#ff8a3a' : '#d1aa78'}" stroke="#5a3a20" stroke-width="${f1(0.3 * k)}"/><circle cx="${f1(Bq[0])}" cy="${f1(Bq[1])}" r="${f1(0.9 * k)}" fill="none" stroke="#8a5a34" stroke-width="${f1(0.2 * k)}"/>`; };
      ins += log([-15, 22.5, -4], [14, 25.5, 5]) + log([-9, 23.5, 12], [12, 26, -9]) + log([2, 22.5, -15], [-1, 27.5, 12]);
      f += `<g clip-path="url(#b7rim)">${ins}</g>`;
      if (lit) { f += `<g clip-path="url(#b7up)">${flames(p(0, 25, 0), k, { seed: 'pit', n: 7, sp: 11, h: 28, w: 3.8, emb: 6 }) + flames(p(-10, 23, 6), k * 0.7, { seed: 'pit2', n: 3, sp: 4, h: 16, noGlow: 1, emb: 0 }) + flames(p(10, 23, -4), k * 0.7, { seed: 'pit3', n: 3, sp: 4, h: 15, noGlow: 1, emb: 0 })}</g>`;
        f += `<path d="M${ellPts(0, 0, LI + 0.5, LI + 0.5, 20, 5 * PI / 6, 11 * PI / 6).map(q => P2(p(q[0], LY, q[1]))).join('L')}" fill="none" stroke="#ff9a4a" stroke-width="${f1(1.4 * k)}" opacity="0.55" filter="url(#f7b)"/>`;
        f += smoke(p(0, 52, 0), k, { seed: 'pits', n: 6, H: 60, op: 0.3, d: 5, r1: 14, drift: 16 });
        un += glowE(p, 0, 0, 0, 52, 52, '#ff8a3a', 0.5, 1); }
      // poker leaning on the rim
      f += tube([p(-30, 0.6, 28), p(-27, 31.4, 17)], 0.8, k, '#3a3c42', '#a0a6b0') + tube([p(-27, 31.4, 17), p(-26.2, 34, 15.4)], 1.3, k, '#6e4a2c', '#c09060') + tube([p(-30, 0.6, 28), p(-32.4, 2.6, 29.4)], 0.8, k, '#3a3c42', '#a0a6b0');
      return { defs, back: bk, under: un, front: f, bb: bbOf([p(-40, 0, -40), p(40, 0, 40), p(-40, 0, 40), p(40, 0, -40), p(0, lit ? 112 : 34, 0)], 3) }; };
    return D; };

  // ======================= CLASSIC RED KETTLE CHARCOAL BBQ (tap to grill) =======================
  N.kettle = S => { const TM0 = PI / 6, lit = isPlay(S), RED = '#c41e26', BY = 40, BR = 27, RY = 58.8, LID = [[0, 0, 1], [5, 0, 0.96], [10, 0, 0.84], [15, 0, 0.6], [18, 0, 0.3], [19, 0, 0.1]];
    const D = { w: 80, d: 80, round: 1 };
    const LEG = [PI / 6, PI / 6 + 2.1, PI / 6 + 4.2];
    D.build = P => [cyl(0, BY, 0, BR, 18, RED, cer({ n: 44, rg: [[0, 0, 0.32], [4, 0, 0.66], [10, 0, 0.9], [18, 0, 1]], shine: 1 })), arcW(0, RY - 1.4, 0, BR + 0.6, BR + 0.6, 1.4, 1.4, 4.4, 4.4 + 2 * PI, CH, mt({ n: 44, shine: 1 })),
      cyl(0, 31, 0, 10, 4, CH, mt({ n: 24, rg: [[0, 0, 0.72], [4, 0, 1]], shine: 1 }))];
    const closedLid = P => [cyl(0, RY, 0, BR + 0.6, 19, RED, cer({ n: 44, rg: LID, shine: 1 })), cyl(0, RY + 17.6, 0, 6, 1.4, CH, mt({ n: 18, shine: 1 })), box(0, RY + 20.6, 9, 18, 2.6, 3.2, '#1a1a1d', pt({ r: 1.3 })), box(-7, RY + 16.6, 9, 1.4, 4.2, 1.4, CH, mt({ r: 0.4 })), box(7, RY + 16.6, 9, 1.4, 4.2, 1.4, CH, mt({ r: 0.4 }))];
    const hungLid = P => [solid({ ax: 'x', sh: 'el', c: [0, 48], a: BR + 0.6, b: BR + 0.6, n: 44, rings: LID.map(r => [BR + 2 + r[0], 0, r[2]]), col: RED, mat: 'cer', shine: 1 }), solid({ ax: 'x', sh: 'el', c: [0, 48], a: 6, b: 6, n: 18, rings: [[BR + 19.6, 0], [BR + 21, 0]], col: CH, mat: 'metal', shine: 1 })];
    D.layers = lit && window.R7END ? [{ build: hungLid }] : lit ? [{ build: closedLid, wrap: (p, s) => `<g>${once('opacity', '1;1;0', '0;0.4;1', 0.7)}<g>${onceT('translate', '0 0;0 -14;12 -20', '0;0.6;1', 0.7)}${s}</g></g>` }, { build: hungLid, wrap: (p, s) => `<g opacity="0">${once('opacity', '0;0;1', '0;0.5;1', 0.9)}${s}</g>` }] : [{ build: closedLid }];
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '', un = '';
      let defs = FDEF + G('k7bowl', [[0, '#0e0e10'], [0.7, '#1c1c1f'], [1, '#3a3a40']], 'cx="50%" cy="60%" r="55%"') + `<clipPath id="k7rimK"><path d="${sp(p, ellPts(0, 0, BR - 0.4, BR - 0.4, 60), RY)}"/></clipPath>`;
      LEG.forEach((t, i) => { const a = p(21 * Math.sin(t), BY + 4, 21 * Math.cos(t)), b = p(30 * Math.sin(t), 2.4, 30 * Math.cos(t)); let s = tube([a, b], 2.4, k, '#1d1e22', '#6a6e78');
        if (i) s += `<g transform="${planeT(p, 0, 0, 31.5, t, 2.6)}"><circle r="4.4" fill="#141416"/><circle r="2.4" fill="#5a5e66"/><circle r="0.9" fill="${CH}"/></g>`; else s += `<ellipse cx="${f1(b[0])}" cy="${f1(b[1] + 1.4 * k)}" rx="${f1(2 * k)}" ry="${f1(1 * k)}" fill="#141416"/>`;
        if (facing(t) > -0.2) f += s; else bk += s; });
      { const tri = LEG.map(t => p(26.4 * Math.sin(t), 16, 26.4 * Math.cos(t))); bk += tube([tri[1], tri[2]], 1, k, '#3a3b40', '#8a8f98'); f += tube([tri[2], tri[0], tri[1]], 1, k, '#3a3b40', '#8a8f98'); }
      { const th = TH => p((BR + 1) * Math.sin(TH), RY - 4, (BR + 1) * Math.cos(TH)); f += tube([th(1.2), p((BR + 5) * Math.sin(1.35), RY - 3.4, (BR + 5) * Math.cos(1.35)), p((BR + 5) * Math.sin(1.75), RY - 3.4, (BR + 5) * Math.cos(1.75)), th(1.9)], 1.4, k, '#1a1a1d', '#5a5e66'); }
      if (!lit) { f += `<g transform="${planeT(p, 0, 0, BR * 0.97, TM0, RY + 6)}"><circle r="3.4" fill="${CH}" stroke="#7a8088" stroke-width="0.4"/><circle r="2.7" fill="#fbfaf4"/>${rep(9, i => `<path d="M0 -2.4V-1.9" stroke="#3a3a40" stroke-width="0.25" transform="rotate(${-120 + i * 30})"/>`).join('')}<path d="M0 0L1.6 -1.2" stroke="#e8343c" stroke-width="0.4" stroke-linecap="round"/><circle r="0.4" fill="#3a3a40"/></g>`;
        const vq = p(0, RY + 19, 0); f += `<g transform="${planeH(p, RY + 19.05)}">${rep(3, i => `<path d="M0 0L${f1(4 * Math.cos(i * 2.1))} ${f1(4 * Math.sin(i * 2.1))}" stroke="#7a8088" stroke-width="1.1" stroke-linecap="round"/>`).join('')}<circle r="1.1" fill="#9aa1ad"/></g>`; void vq; }
      if (lit) { let ins = `<path d="${sp(p, ellPts(0, 0, BR, BR, 60), RY)}" fill="url(#k7bowl)"/><g transform="${planeH(p, 49)}">`;
        const RR = rng('kco'); rep(34, i => { const a = RR() * 2 * PI, r = Math.sqrt(RR()) * 17, x = r * Math.cos(a), z = r * Math.sin(a); ins += `<rect x="${f1(x - 1.8)}" y="${f1(z - 1.6)}" width="3.6" height="3.2" rx="1.3" fill="#d8d2c8" transform="rotate(${f1(RR() * 90)} ${f1(x)} ${f1(z)})"/><rect x="${f1(x - 1.2)}" y="${f1(z - 1)}" width="2.4" height="2" rx="0.9" fill="#ff5a1a">${an('opacity', '0.5;1;0.6', n4(0.8 + RR()), n4(-RR()))}</rect>`; });
        ins += '</g>';
        ins += `<g transform="${planeH(p, 55)}">` + rep(15, i => `<path d="M${-26} ${f1(-24 + i * 3.4)}H26" stroke="#2a2b30" stroke-width="0.9"/><path d="M${-26} ${f1(-24.4 + i * 3.4)}H26" stroke="#c9d0d6" stroke-width="0.45"/>`).join('') + `<circle r="25.6" fill="none" stroke="#c9d0d6" stroke-width="0.9"/>`;
        const patty = (x, z) => `<g transform="translate(${x} ${z})"><ellipse rx="6.2" ry="6.2" fill="#4a2a18"/><ellipse rx="5.6" ry="5.6" fill="#7a4a2a"/>${[-2.6, 0, 2.6].map(d => `<path d="M-4.6 ${d - 1.4}L4.6 ${d + 1.4}" stroke="#2a1608" stroke-width="0.9" stroke-linecap="round"/>`).join('')}<path d="M-4.4 -4.4H4.4V3.6L2 6L1 3.6L-1 5.4L-4.4 3.2Z" fill="#ffc02e" opacity="0.92"/></g>`;
        const saus = (x, z, a) => `<g transform="translate(${x} ${z}) rotate(${a})"><rect x="-8" y="-2" width="16" height="4" rx="2" fill="#7a2a1a"/><rect x="-7.6" y="-1.6" width="15.2" height="1.6" rx="0.8" fill="#b4542e"/>${[-4, 0, 4].map(d => `<path d="M${d - 1} -1.8L${d + 1} 1.8" stroke="#2a1008" stroke-width="0.7"/>`).join('')}</g>`;
        ins += patty(-9, -6) + patty(9, 4) + saus(-6, 12, 10) + saus(10, -12, -14) + `<g transform="translate(-14 8) rotate(-60)"><rect x="-6" y="-2.2" width="12" height="4.4" rx="2.2" fill="#f2c14a"/>${rep(10, i => `<circle cx="${-5 + i * 1.1}" cy="${i % 2 ? -1 : 1}" r="0.5" fill="#d89a1a"/>`).join('')}<path d="M6 0L9 -2.4L8.4 1.6Z" fill="#8aa84a"/></g></g>`;
        f += window.R7END ? `<g clip-path="url(#k7rimK)">${ins}</g>` : `<g clip-path="url(#k7rimK)" opacity="0">${once('opacity', '0;0;1', '0;0.45;1', 0.8)}${ins}</g>`;
        const RS = rng('siz'); rep(8, i => { const q = p((RS() - 0.5) * 30, 56, (RS() - 0.5) * 30), d = 0.6 + RS() * 0.5; f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.5 * k)}" fill="#fff6c8" opacity="0"><animate attributeName="cy" values="${f1(q[1])};${f1(q[1] - 6 * k)}" dur="${n4(d)}s" begin="${n4(0.8 + RS())}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;0" dur="${n4(d)}s" begin="${n4(0.8 + RS())}s" repeatCount="indefinite"/></circle>`; });
        f += smoke(p(0, 60, 0), k, { seed: 'kts', n: 7, H: 72, col: '#d4cfc8', op: 0.42, d: 5, r1: 16, drift: 20 }) + `<g clip-path="url(#k7up)">${flames(p(-12, 52, 4), k * 0.5, { seed: 'kf1', n: 3, sp: 3, h: 9, emb: 2 })}${flames(p(12, 52, -6), k * 0.5, { seed: 'kf2', n: 3, sp: 3, h: 9, emb: 2 })}</g>`;
        defs += `<clipPath id="k7up"><path d="${aboveFront(p, BR, RY)}"/></clipPath>`;
        un += glowE(p, 0, 0, 0, 36, 36, '#ff8a3a', 0.2, 1); }
      return { defs, back: bk, under: un, front: f, bb: bbOf([p(-34, 0, -34), p(34, 0, 34), p(-34, 0, 34), p(34, 0, -34), p(0, lit ? 136 : 82, 0), p(BR + 24, 76, 0)], 3) }; };
    return D; };

  // ======================= CAST-IRON CHARCOAL HIBACHI (tap to light) =======================
  N.hibachi = S => { const lit = isPlay(S), CI = '#34302c', CI2 = '#2a2724', W = 66, DZ = 34, Y0 = 4, H = 13, TOP = Y0 + H, GY = 21;
    const D = { w: 96, d: 50, glow: lit ? () => ({ y: 20, r: 50 }) : undefined };
    D.build = P => { const o = [];
      [[-27, -12], [27, -12], [-27, 12], [27, 12]].forEach(([x, z]) => o.push(box(x, 0, z, 6, Y0 + 0.2, 6, CI2, pt({ r: 1 }))));
      o.push(box(0, Y0, 0, W - 6, 2, DZ - 6, CI, pt({ r: 0.6 })), box(0, Y0, DZ / 2 - 1.5, W, H, 3, CI, pt({ r: 0.8 })), box(0, Y0, -DZ / 2 + 1.5, W, H, 3, CI, pt({ r: 0.8 })), box(-W / 2 + 1.5, Y0, 0, 3, H, DZ - 6, CI, pt({ r: 0.8 })), box(W / 2 - 1.5, Y0, 0, 3, H, DZ - 6, CI, pt({ r: 0.8 })));
      [-1, 1].forEach(s => { o.push(box(s * (W / 2 + 2.6), 10.6, -6, 5.4, 1.8, 1.6, CI2, pt({ r: 0.4 })), box(s * (W / 2 + 2.6), 10.6, 6, 5.4, 1.8, 1.6, CI2, pt({ r: 0.4 })), solid({ ax: 'z', sh: 'el', c: [s * (W / 2 + 5.4), 11.5], a: 2.2, b: 2.2, n: 14, rings: [[-8.5, 0], [8.5, 0]], col: '#8a5a34', mat: 'wood' }));
        [-11, 11].forEach(z => o.push(box(s * (W / 2 - 1.6), TOP, z, 2.6, 5.4, 2.6, CI2, pt({ r: 0.5 })))); });
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      let defs = FDEF + `<clipPath id="h7rim"><path d="${sp(p, rrPts(0, 0, W / 2 - 3, DZ / 2 - 3, 0.6), TOP)}"/></clipPath>` + G('h7rust', [[0, '#a8562a', 0.55], [1, '#a8562a', 0]], 'cx="50%" cy="50%" r="50%"');
      // cast-iron detail: casting ribs, sliding draft doors, rust patina
      let fr = `<rect x="0" y="0" width="${W}" height="${H}" fill="none"/>` + [3.2, 9.8].map(y => `<rect x="1" y="${y}" width="${W - 2}" height="0.8" fill="#4a4540"/><rect x="1" y="${y + 0.8}" width="${W - 2}" height="0.4" fill="#1a1816"/>`).join('');
      [14, 40].forEach(x => { fr += `<rect x="${x}" y="4.4" width="12" height="5" rx="0.6" fill="#1a1816"/>${rep(4, i => `<rect x="${x + 1.2 + i * 2.7}" y="5.2" width="1.6" height="3.4" rx="0.3" fill="${lit ? '#ff6a1a' : '#0a0908'}">${lit ? an('opacity', '0.5;1;0.6', 1.2, -i * 0.2) : ''}</rect>`).join('')}<rect x="${x - 0.6 + (lit ? 5 : 0)}" y="3.8" width="7.4" height="6.2" rx="0.6" fill="#3a3632" stroke="#55504a" stroke-width="0.3">${lit ? `<animate attributeName="x" values="${x - 0.6};${x + 4.4}" dur="0.5s" fill="freeze"/>` : ''}</rect><circle cx="${x + 3.1 + (lit ? 5 : 0)}" cy="7" r="0.7" fill="#6a645c"/>`; });
      fr += [[8, 6, 7], [32, 9, 5], [55, 4, 6]].map(([x, y, r]) => `<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r * 0.6}" fill="url(#h7rust)"/>`).join('') + `<text x="${W / 2}" y="11.6" text-anchor="middle" font-family="Georgia, serif" font-weight="700" font-size="1.7" fill="#5a544c" letter-spacing="0.4">SQUISH IRONWORKS</text>`;
      f += `<g transform="${plane(p, DZ / 2 + 0.05, TOP, -W / 2)}">${fr}</g><g transform="${planeX(p, W / 2 + 0.05, TOP, DZ / 2)}"><g transform="scale(-1 1)">${[3.2, 9.8].map(y => `<rect x="1" y="${y}" width="${DZ - 2}" height="0.8" fill="#4a4540"/>`).join('')}<ellipse cx="12" cy="7" rx="6" ry="3.4" fill="url(#h7rust)"/></g></g>`;
      // charcoal bed: black briquettes that catch one by one, grey ash coat + pulsing cores
      let cb = `<rect x="${-W / 2 + 3}" y="${-DZ / 2 + 3}" width="${W - 6}" height="${DZ - 6}" fill="#151312"/>`; const RR = rng('hib');
      rep(5, j => rep(11, i => { const x = -27 + i * 5.4 + (j % 2) * 2.4 + (RR() - 0.5), z = -11 + j * 5.4 + (RR() - 0.5), a = f1(RR() * 40 - 20), tI = 0.3 + Math.hypot(x + 28, z - 12) / 64 * 3.2;
        cb += `<g transform="translate(${f1(x)} ${f1(z)}) rotate(${a})"><rect x="-2.4" y="-2.2" width="4.8" height="4.4" rx="1.8" fill="#262422"/><rect x="-1.8" y="-1.9" width="2.6" height="1.4" rx="0.7" fill="#4a4744"/>`
          + (lit ? `<rect x="-2.4" y="-2.2" width="4.8" height="4.4" rx="1.8" fill="#d6d0c6" opacity="0">${once('opacity', '0;0.85', '0;1', 1.6, tI + 0.6)}</rect><rect x="-1.6" y="-1.4" width="3.2" height="2.8" rx="1.2" fill="#ff5a1a" opacity="0">${once('opacity', '0;1', '0;1', 0.6, tI)}<animate attributeName="opacity" values="1;0.55;1" dur="${n4(0.9 + RR() * 0.8)}s" begin="${n4(tI + 0.6)}s" repeatCount="indefinite"/></rect>` : '') + '</g>'; }));
      f += `<g clip-path="url(#h7rim)"><g transform="${planeH(p, Y0 + 3.4)}">${cb}</g></g>`;
      if (lit) { f += `<g clip-path="url(#h7up)">` + [[-20, -4, 0.4], [-6, 6, 1.4], [10, -6, 2.4], [22, 4, 3]].map(([x, z, b], i) => `<g opacity="0">${once('opacity', '0;1', '0;1', 0.5, b)}${flames(p(x, Y0 + 4, z), k * 0.45, { seed: 'hf' + i, n: 3, sp: 4, h: 10, w: 3, emb: 2 })}</g>`).join('') + '</g>';
        defs += `<clipPath id="h7up"><path d="M${P2(p(-W / 2, TOP, DZ / 2))}L${P2(p(W / 2, TOP, DZ / 2))}L${P2(p(W / 2, TOP, -DZ / 2))}L${f1(p(W / 2, TOP, -DZ / 2)[0])} -999L${f1(p(-W / 2, TOP, DZ / 2)[0])} -999Z"/></clipPath>`; }
      // twin cast-iron grates
      [-1, 1].forEach(s => { let g = `<rect x="-14.5" y="-12.5" width="29" height="25" rx="1" fill="none" stroke="#1a1816" stroke-width="2"/><rect x="-14.5" y="-12.5" width="29" height="25" rx="1" fill="none" stroke="#4a4540" stroke-width="0.8"/>`;
        rep(7, i => g += `<path d="M${-11 + i * 3.7} -12V12" stroke="#1a1816" stroke-width="1.5"/><path d="M${-11.3 + i * 3.7} -12V12" stroke="#55504a" stroke-width="0.5"/>`);
        f += `<g transform="${planeH(p, GY, s * 15, 0)}">${g}</g>`; });
      if (lit) { const sk = (x, z) => `<g transform="${planeH(p, GY + 1.2, x, z)}"><path d="M-17 0H17" stroke="#d8c08a" stroke-width="0.9" stroke-linecap="round"/>${[-10, -4, 2, 8].map((d, i) => `<rect x="${d - 2.2}" y="-2.4" width="4.4" height="4.8" rx="1.6" fill="${i % 2 ? '#c9d88a' : '#b7743a'}"/>` + (i % 2 ? '' : `<path d="M${d - 1.6} -1.2H${d + 1.6}M${d - 1.6} 1H${d + 1.6}" stroke="#4a2410" stroke-width="0.6"/>`)).join('')}</g>`;
        f += `<g opacity="0">${once('opacity', '0;1', '0;1', 0.5, 1.6)}${sk(-14, -2) + sk(14, 4)}</g>` + smoke(p(0, GY + 2, 0), k, { seed: 'hbs', n: 5, H: 50, col: '#c8c2ba', op: 0.32, d: 4.4, r1: 10, drift: 14, b: 0 });
        const RS = rng('hsp'); rep(6, i => { const q = p((RS() - 0.5) * 50, GY, (RS() - 0.5) * 20), d = 0.7 + RS() * 0.6, b = n4(1 + RS() * 3); f += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.4 * k)}" fill="#ffd66b" opacity="0"><animate attributeName="cy" values="${f1(q[1])};${f1(q[1] - 10 * k)}" dur="${n4(d)}s" begin="${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;0" dur="${n4(d)}s" begin="${b}s" repeatCount="indefinite"/></circle>`; });
        un += glowE(p, 0, 0, 0, 44, 26, '#ff8a3a', 0.35, 1); }
      return { defs, under: un, front: f, bb: bbOf([p(-W / 2 - 9, 0, -DZ / 2), p(W / 2 + 9, 0, DZ / 2), p(-W / 2 - 9, 0, DZ / 2), p(W / 2 + 9, 0, -DZ / 2), p(0, lit ? 76 : GY + 4, 0)], 3) }; };
    return D; };

  // ---------- catalog edits ----------
  RD.SET7 = {
    'YRD-015': { spec: 'kiddie', live: 'Rippling water', note: 'A clean three-ring inflatable kiddie pool: fat glossy blue and white tubes printed with little fish and starfish. The water is alive with moving sunlight caustics, ripples and sparkles, a rubber duck drifts round and a beach ball bobs. Seats 2 splashing creatures.' },
    'YRD-035': { spec: 'plunge', live: 'Rippling water', note: 'A round above-ground plunge pool built from vertical cedar staves held by two steel hoops, with a wide cedar cap, cedar steps and stainless handrails. Deep teal water with drifting caustics, ripples, a floating thermometer and a couple of leaves. Seats 3.' },
    'YRD-055': { spec: 'koiPond', live: 'Koi swimming', note: 'A natural pond ringed with mossy boulders. Water spills off a stone ledge in a flowing waterfall with foam and mist, five koi (kohaku, showa, ogon, yamabuki) swim lazy loops under the surface, lily pads sway, two pink lotus flowers bloom and cattails nod.' },
    'YRD-075': { spec: 'lapPool', live: 'Heated · steaming', note: 'A long travertine-edged lap pool with a blue mosaic waterline, lane stripes on the floor and a red-white-blue lane rope that bobs on the surface. The sunken sun shelf at the end holds an in-water chaise. Warm water steams gently. Seats 4.' },
    'YRD-095': { spec: 'lagoon', live: 'Waterfalls + infinity edge', note: 'A dark-stone lagoon with a glass front wall, so you see the water in cross-section with light rays and rising bubbles. A grotto waterfall pours over a hidden cave, the right side spills over an infinity edge into a catch trough, and the swim-up bar has stools in the water and tropical drinks. Seats 5.' },
    'YRD-106': { spec: 'marbleFount', live: 'Flowing fountain', note: 'Three Carrara marble tiers with gold rims. A crown jet sprays from the gold finial, water spills over every bowl rim in shining curtains, four gold swans spout into the basin, and each pool ripples with sunlight caustics.' },
    'YRD-098': { spec: 'obelisk', live: 'Fire on water', note: 'A razor-sharp obsidian obelisk that hovers above a black reflecting basin. Living fire tongues rise straight out of the rippling water around its base, the polished faces glow with firelight and the water mirrors the flames.' },
    'YRD-058': { spec: 'chiminea', live: 'Live fire', note: 'A pot-bellied terracotta chiminea with a hand-painted Talavera band on a wrought-iron stand. The logs and flames burn inside the clay chamber behind the arched mouth (you can see the wall thickness at the lip), smoke and sparks rise from the chimney and the mouth throws a warm glow on the ground.' },
    'YRD-038': { spec: 'bowlPit', play: 'fire', live: 'Tap to light', note: 'A deep steel bowl fire pit with a wide lip, four bent tube legs and a poker. The bowl is soot-darkened inside with a bed of ash and three split logs. Tap to light it: flames roar up out of the logs, coals and log cracks glow, embers drift up and smoke rises.' },
    'YRD-022': { spec: 'kettle', play: 'grill', live: 'Tap to grill', note: 'The classic red enamel kettle grill: glossy dome lid with a chrome vent and thermometer, black handle, ash catcher, triangle rack and two wheels. Tap to grill: the lid comes off and hangs on the side, the charcoal glows, burgers with melting cheese, sausages and corn sizzle and smoke billows up.' },
    'YRD-002': { spec: 'hibachi', play: 'coals', live: 'Tap to light', note: 'A heavy cast-iron hibachi with casting ribs, rust patina, sliding draft doors, wooden end handles and twin grates on notched posts. Tap to light: the draft doors slide open, the briquettes catch one by one (orange cores, grey ash coat), small flames lick up and two yakitori skewers start to sizzle.' },
  };
  const edit6 = RD.edit;
  RD.edit = rows => edit6(rows).map(r => RD.SET7[r.id] ? Object.assign({}, r, RD.SET7[r.id]) : r);
  RD.H7 = { isPlay, B, anV, atV, once, onceT, st, G, L, lerp, lerpA, ellPts, rrPts, shPts, lp, sp, quad, planeT, facing, aboveFront, tube, curve, water, WP, WDEF, fall, stream, FDEF, flames, tongue, embers, smoke, glowE, DUCK, BBALL, BBDEF, ripple };
  RD.PLUS7 = 1;
})();
