// Snack Shack eating (Nov 9, user: 'now, i want us to do what we did with petshop to the snack shack'): every Snack Shack creature eats all 20
// foods its own way, built with the Pet Shop eating kit (pet-eats.js: receive -> own ritual -> the food's beat -> eating style made of its own
// bite / chew / swallow -> own after-habit -> the food's reaction in its own way). Snack parts join in: Bao's steam, Frybo's fries and salt,
// Bunbun's layers, Choco's melt, Scoop's cherry, Boba's pearls and straw, Chef Bun's chef's kiss. Brain freeze swings the arms up (armsUp:
// generic snack paws can't reach the head by hand offsets).
(function boot() {
  const R = window.RiveRig; if (!R || !R.EATKIT || !R.SNACKLIB || !R.EATLIB) { setTimeout(boot, 25); return; } if (R.snackEatV) return; R.snackEatV = 1;
  const { hand, both, o, NOHANDS, jump, swing, jelly } = R.PETLIB;
  const { EAR, sniffF, lipLick, hearts, para, pat, buildAll } = R.EATKIT;
  const { REACT } = R.EATLIB;
  Object.assign(EAR, { mallow: 0.6, bao: 0.6, dunkie: 0.6, frybo: 1, bunbun: 0.6, choco: 0.6, scoop: 0.6, boba: 1, chefbun: 1 });
  const hop = (t, h, ev) => jump(t, { h: h || 6, ant: 140, up: 190, c: 0.14, arm: 40, ev });
  const kiss = t => t.to(260, o(hand(1, 13, -15), { armR: 20, close: 0.9 }), 'io').to(130, { open: 0.3, mw: 0.5, puff: -0.2 }, 'o')                     // fingers to his lips ...
    .to(220, o(hand(1, -4, -10), { armR: 80, open: 0.25, mw: 1, puff: 0 }), 'o').e('emit', 'spark', 'pawR', 3).wait(250).to(300, o(hand(1, 0, 0), { armR: 0, close: 0, open: 0 }), 'io'); // ... flung open

  const CARDS = {
    mallow: { // marshmallow: slow soft bites, savours with her eyes shut, sinks into a happy wobble
      savor: 0.7, chewMs: 145, chewN: 1, crumbs: 1, open: 0.6, armsUp: 1, txt: 'Slow soft bites, savours it with eyes shut, then sinks into a happy wobble.',
      pre: t => sniffF(t, 1),
      post: t => t.to(300, { close: 0.6, smile: 0.8 }, 'io').wait(250).to(250, { close: 0 }, 'io'),
      yum: t => { t.to(500, { sq: 0.16, hap: 1, smile: 1 }, 'io').to(900, { sq: -0.03 }, 'o'); jelly(t, 0.06, 2, 300); },
      love: t => { hearts(t, 2); t.to(300, { blush: 1 }, 'io'); CARDS.mallow.yum(t); } },
    bao: { // steamed bun: blows on it to cool it, neat bites, steam puffs when he's happy
      chewMs: 135, crumbs: 1, armsUp: 1, txt: 'Blows on it to cool it first (a puff of steam), neat bites, steam puffs out of his knot when he is happy.',
      pre: t => { t.to(250, { puff: 0.6, pitch: -0.08, ly: 0.6 }, 'io').to(160, { puff: -0.3, open: 0.3, mw: 0.5 }, 'o').e('emit', 'steam', 'mouth', 2).to(260, { puff: 0, open: 0, mw: 1, pitch: 0 }, 'io'); },
      post: t => lipLick(t),
      yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io'); hop(t, 6, [['emit', 'steam', 'head', 4]]); },
      love: t => { hearts(t, 2); t.e('emit', 'steam', 'head', 3); CARDS.bao.yum(t); } },
    dunkie: { // donut: dunks it first (like a donut in coffee), happy chomps, rocks like a wheel
      crumbs: 2, open: 0.8, armsUp: 1, txt: 'Dunks it first, like a donut in coffee, then happy chomps; rocks like a rolling wheel when he likes it.',
      pre: (t, H) => { const L = o(H.chest); for (const q in L) if (/y$/.test(q)) L[q] += 7;
        t.to(320, o(L, { pitch: -0.22, ly: 0.9, sq: 0.04 }), 'io').to(120, { sq: 0.08 }, 'o').e('emit', 'drop', [50, 82], 2).to(160, { sq: 0.03 }, 'io').to(320, o(H.chest, { pitch: -0.05, ly: 0.4, sq: 0 }), 'io'); },
      post: t => lipLick(t, true),
      yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io').e('emit', 'sprinkle', 'head', 4); swing(t, 1100, 3, { tilt: 10, x: 2.5 }); },
      love: t => { hearts(t, 2); CARDS.dunkie.yum(t); } },
    frybo: { // fries: a sprinkle of salt on top first, quick crunchy bites, the fries wave when he's happy
      chewMs: 110, chewN: 0.9, crumbs: 2, armsUp: 1, txt: 'Salts it first, quick crunchy bites, his fries wave when he is happy.',
      pre: t => { t.to(200, { pitch: -0.1, ly: 0.7 }, 'io').to(120, { earL: -8, earR: -8 }, 'o').e('emit', 'salt', 'head', 4).to(220, { earL: 0, earR: 0 }, 'io'); sniffF(t, 1); },
      post: t => lipLick(t),
      yum: t => { t.to(160, { hap: 1, smile: 1, earL: -10, earR: -10 }, 'io').to(700, { fw: 1.3 }, 'io').to(400, { fw: 0, earL: 0, earR: 0 }, 'io'); },
      love: t => { hearts(t, 2); CARDS.frybo.yum(t); } },
    bunbun: { // burger: opens wide - his layers lift apart - big chomps, squeaky cheese when he's happy
      open: 0.95, crumbs: 3, puff: 1.15, armsUp: 1, txt: 'Opens wide (his layers lift apart), big chomps, crumbs everywhere, a cheesy squeak when he likes it.',
      pre: t => t.to(220, { split: 0.45, open: 0.5, wide: 0.3 }, 'o').wait(160).to(220, { split: 0, open: 0, wide: 0 }, 'io'),
      post: t => pat(t, 2),
      yum: t => { t.to(140, { hap: 1, smile: 1 }, 'io').e('emit', 'note', 'head', 1).to(160, { split: 0.5 }, 'o').to(260, { split: 0 }, 'io'); swing(t, 900, 3, { fan: 0.5, tilt: 3 }); },
      love: t => { hearts(t, 2); CARDS.bunbun.yum(t); } },
    choco: { // chocolate bar: neat little snaps, savours, melts a little with happiness
      open: 0.5, savor: 0.6, chewMs: 140, crumbs: 1, armsUp: 1, txt: 'Neat little snapping bites, savours it, melts a little with happiness, then firms up.',
      post: t => t.to(80, { tw: 1 }, 'o').to(300, { tw: 0 }, 'io'),
      yum: t => { t.to(700, { melt: 0.5, sq: 0.06, hap: 1, smile: 1, close: 0.5 }, 'io').wait(300).to(140, { melt: 0, sq: -0.04, tw: 1, close: 0 }, 'o').to(300, { sq: 0, tw: 0 }, 'io'); },
      love: t => { hearts(t, 2); t.to(250, { blush: 1 }, 'io'); CARDS.choco.yum(t); } },
    scoop: { // ice cream: a little lick first, small bites, his cherry bobs when he's happy
      open: 0.55, chewMs: 130, armsUp: 1, txt: 'A little lick first, small bites, his cherry bobs and pops when he likes it.',
      pre: t => t.to(200, { pitch: -0.08, ly: 0.7 }, 'io').to(150, { tongue: 0.9, open: 0.2 }, 'o').to(200, { tongue: 0, open: 0, pitch: 0 }, 'io'),
      post: t => lipLick(t),
      yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io').osc(900, 3, { chb: 1, htilt: 3 }, { chb: 0, htilt: -3 }, 'io').to(150, { chy: 0.8, htilt: 0 }, 'o').to(280, { chy: 0 }, 'i'); },
      love: t => { hearts(t, 2); CARDS.scoop.yum(t); } },
    boba: { // bubble tea: gulps it down, his pearls swirl as he chews, a happy bubble
      chewMs: 125, crumbs: 1, armsUp: 1, txt: 'Gulps it down with his pearls swirling as he chews, then happy bubbles.',
      pre: t => t.to(250, { pitch: -0.08, ly: 0.7, swirl: 1 }, 'io').to(250, { swirl: 0, pitch: 0 }, 'io'),
      post: t => t.to(300, { swirl: 1.5, pop: 0.8 }, 'io').e('emit', 'bubble', 'mouth', 2).to(400, { swirl: 0, pop: 0 }, 'io'),
      yum: t => { t.to(150, { hap: 1, smile: 1 }, 'io'); hop(t, 6); t.to(160, { stw: 1.5, pop: 1.5 }, 'o').to(500, { stw: 0, pop: 0 }, 'io'); },
      love: t => { hearts(t, 2); CARDS.boba.yum(t); } },
    chefbun: { // tiny chef: sniffs it like a critic, a careful taste, considers, then eats - chef's kiss
      open: 0.6, chewMs: 145, savor: 0.5, armsUp: 1, txt: "Sniffs it like a food critic, a careful taste, thinks about it, then eats; a chef's kiss after.",
      pre: t => { sniffF(t, 2); t.to(350, { close: 0.85, htilt: 6, pitch: 0.08 }, 'io').wait(350).to(250, { close: 0, htilt: 0, pitch: 0 }, 'io'); },
      post: t => kiss(t),
      yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io'); hop(t, 5); },
      love: t => { hearts(t, 2); kiss(t); hop(t, 5); } },
  };
  buildAll(CARDS);
})();
