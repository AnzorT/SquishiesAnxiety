// Yard Mini Games: HOOP SHOT (the backyard's Basketball Hoop). Flick up from your creature to shoot; the flick's direction aims and its length is the power.
// Real ball physics in metres: rim (a ring the ball can rattle on), backboard bank shots, net, bounces on the driveway. Swish +3, rim-in / bank +2,
// 3 in a row = On fire (double points). From 20 points the hoop starts sliding side to side. 45 s.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add || !YG.cam) return setTimeout(go, 30); const { S, cl, lerp, r2, track, SFX } = YG;
  const ICON = '<svg viewBox="0 0 120 84" aria-hidden="true"><rect width="120" height="84" fill="#cfeaff"/><rect y="58" width="120" height="26" fill="#9fdc6e"/><path d="M14 84L36 58H84L106 84Z" fill="#d9d4cc"/>' +
    '<rect x="57" y="22" width="5" height="40" rx="2" fill="#3a3a44"/><rect x="38" y="8" width="44" height="28" rx="3" fill="#fff" stroke="#e8483c" stroke-width="2.5"/><rect x="51" y="18" width="18" height="12" fill="none" stroke="#e8483c" stroke-width="2"/>' +
    '<ellipse cx="60" cy="34" rx="10" ry="3" fill="none" stroke="#f07a2e" stroke-width="2.4"/><path d="M51 35L54 46H66L69 35M55 35L57 46M65 35L63 46M60 35V46" stroke="#fff" stroke-width="1.2" fill="none"/>' +
    '<circle cx="34" cy="40" r="9" fill="#f07a2e"/><path d="M25 40H43M34 31V49M27.5 33.5Q34 40 27.5 46.5M40.5 33.5Q34 40 40.5 46.5" stroke="#7a3410" stroke-width="1.2" fill="none"/></svg>';
  YG.add({ id: 'hoop', name: 'Hoop Shot', item: 'Basketball Hoop', color: '#ff9a4a', icon: ICON, dur: 45, stars: [16, 32, 50], coinK: 0.5,
    hint: 'Flick up to shoot · longer flick = harder throw',
    how: ['Flick up from your creature to shoot the ball.', 'Aim with the direction, power with the length.', 'Swish = 3, rim or bank = 2. Three in a row sets you on fire!'],
    make(ctx) {
      const { bg, fg, W, H } = ctx, P = YG.cam(2.4, 1.9, 210, 189), G = 9.8, BR = 0.12, RR = 0.23, RT = 0.018, RY = 3.05, RZ = 3.8, BZ = 4.18, PZ = 4.5;
      YG.yard(bg, { hz: 210 });
      // driveway slab + painted key
      const quad = (pts, a, p) => S('path', Object.assign({ d: 'M' + pts.map(q => { const s = P(q[0], 0, q[1]); return r2(s[0]) + ' ' + r2(s[1]); }).join('L') + 'Z' }, a), p || bg);
      quad([[-2.6, -0.6], [2.6, -0.6], [2.6, 6.5], [-2.6, 6.5]], { fill: '#d9d4cc' }); quad([[-2.6, -0.6], [2.6, -0.6], [2.6, -0.45], [-2.6, -0.45]], { fill: '#c5beb3' });
      for (let z = 0.6; z < 6.4; z += 1.2) quad([[-2.6, z], [2.6, z], [2.6, z + 0.02], [-2.6, z + 0.02]], { fill: '#c9c2b7' });
      quad([[-0.9, 1.6], [0.9, 1.6], [0.9, 4.4], [-0.9, 4.4]], { fill: 'none', stroke: '#ffffff', 'stroke-width': 2.2, opacity: 0.9 });
      { let d = ''; for (let i = 0; i <= 20; i++) { const a = Math.PI * i / 20, s = P(Math.cos(a) * 0.9, 0, 1.6 - Math.sin(a) * 0.9); d += (i ? 'L' : 'M') + r2(s[0]) + ' ' + r2(s[1]); } S('path', { d, fill: 'none', stroke: '#ffffff', 'stroke-width': 2.2, opacity: 0.9 }, bg); }
      // the hoop (moves as a group in x once it starts sliding)
      const hoopG = S('g', {}, bg), backG = S('g', {}, hoopG), slotB = S('g', {}, hoopG), frontG = S('g', {}, hoopG), slotF = S('g', {}, fg), shG = S('g', {}, bg);
      bg.insertBefore(shG, hoopG);
      let hx = 0, netSw = 0, netAt = -9;
      function drawHoop(t) { backG.innerHTML = ''; frontG.innerHTML = '';
        const pb = P(hx, 0, PZ), pt2 = P(hx, 3.55, PZ); YG.shadow(backG, pb[0], pb[1], 16, 0.22);
        S('rect', { x: r2(pb[0] - 4), y: r2(pt2[1]), width: 8, height: r2(pb[1] - pt2[1]), rx: 3, fill: '#3a3a44' }, backG); S('rect', { x: r2(pb[0] - 1.5), y: r2(pt2[1]), width: 2, height: r2(pb[1] - pt2[1]), fill: '#5a5a66' }, backG);
        const a1 = P(hx, 3.5, PZ), a2 = P(hx, 3.4, BZ + 0.02); S('path', { d: 'M' + r2(a1[0]) + ' ' + r2(a1[1]) + 'L' + r2(a2[0]) + ' ' + r2(a2[1]), stroke: '#3a3a44', 'stroke-width': 5, 'stroke-linecap': 'round' }, backG);
        const b1 = P(hx - 0.9, 3.85, BZ), b2 = P(hx + 0.9, 2.78, BZ); S('rect', { x: r2(b1[0]), y: r2(b1[1]), width: r2(b2[0] - b1[0]), height: r2(b2[1] - b1[1]), rx: 3, fill: '#ffffff', stroke: '#e8483c', 'stroke-width': 3.4 }, backG);
        S('rect', { x: r2(b1[0] + 3), y: r2(b1[1] + 3), width: r2(b2[0] - b1[0] - 6), height: 5, rx: 2, fill: '#eef6ff' }, backG);
        const s1 = P(hx - 0.3, 3.5, BZ), s2 = P(hx + 0.3, 3.08, BZ); S('rect', { x: r2(s1[0]), y: r2(s1[1]), width: r2(s2[0] - s1[0]), height: r2(s2[1] - s1[1]), fill: 'none', stroke: '#e8483c', 'stroke-width': 2.6 }, backG);
        const br = P(hx, RY - 0.02, BZ - 0.01), c = P(hx, RY, RZ); S('rect', { x: r2(br[0] - 4), y: r2(br[1] - 2), width: 8, height: 5, rx: 1.5, fill: '#c8501e' }, backG);
        // rim = ellipse; back half behind the ball slot, front half + net in front
        const rx = RR * c[2], ry = RR * c[2] * 0.3, arc = (a0, a1, w, col, g) => { let d = ''; for (let i = 0; i <= 16; i++) { const a = a0 + (a1 - a0) * i / 16, s = P(hx + Math.cos(a) * RR, RY, RZ + Math.sin(a) * RR); d += (i ? 'L' : 'M') + r2(s[0]) + ' ' + r2(s[1]); } S('path', { d, fill: 'none', stroke: col, 'stroke-width': w, 'stroke-linecap': 'round' }, g); };
        arc(0, Math.PI, 3.2, '#c8501e', backG);
        // net: 12 cords from the rim down to a smaller ring, swaying after a basket
        const sw = netSw * Math.sin((t - netAt) / 70) * Math.exp(-(t - netAt) / 500); let nd = '';
        const ring = (yy, rr, k) => [...Array(12)].map((_, i) => { const a = i / 12 * Math.PI * 2, s = P(hx + Math.cos(a) * rr + sw * 0.05 * k, yy, RZ + Math.sin(a) * rr); return s; });
        const r0 = ring(RY, RR, 0), r1 = ring(RY - 0.22, RR * 0.82, 1), r2b = ring(RY - 0.42, RR * 0.6, 2);
        for (let i = 0; i < 12; i++) { const j = (i + 1) % 12; nd += 'M' + r2(r0[i][0]) + ' ' + r2(r0[i][1]) + 'L' + r2(r1[j][0]) + ' ' + r2(r1[j][1]) + 'L' + r2(r2b[i][0]) + ' ' + r2(r2b[i][1]); nd += 'M' + r2(r0[j][0]) + ' ' + r2(r0[j][1]) + 'L' + r2(r1[i][0]) + ' ' + r2(r1[i][1]) + 'L' + r2(r2b[j][0]) + ' ' + r2(r2b[j][1]); }
        S('path', { d: nd, fill: 'none', stroke: '#ffffff', 'stroke-width': 1.1, opacity: 0.95 }, frontG); arc(Math.PI, Math.PI * 2, 3.6, '#f07a2e', frontG);
        S('ellipse', { cx: r2(c[0]), cy: r2(c[1]), rx: r2(rx), ry: r2(ry), fill: 'none', stroke: '#ffb070', 'stroke-width': 1, opacity: 0.6 }, frontG); }
      // the player: your creature from behind, the ball over its head
      const me = ctx.creature(ctx.playerKey, { yaw: 180 }); const f0 = P(0, 0, 0.25); me.set(f0[0], f0[1], 1.12 * f0[2]); YG.shadow(shG, f0[0], f0[1] - 2, 42, 0.2);
      const HOLD = [0, 1.0, 0.36]; let balls = [], held = null, nextAt = 0, streak = 0, fire = 0, shotT = -9, cheerT = -9, made = 0, clangAt = 0, drag = null, tNow = 0, moving = false;
      function mkBall() { const g = S('g', {}, slotF), sh = S('ellipse', { fill: '#3a2a55', opacity: 0.18 }, shG), b = S('circle', { r: 10, fill: 'url(#ygBall)' }, g),
          sm = S('path', { fill: 'none', stroke: '#7a3410', 'stroke-width': 1.4, 'stroke-linecap': 'round', opacity: 0.85 }, g), hl = S('ellipse', { fill: '#ffffff', opacity: 0.35 }, g), fl = S('circle', { fill: 'none', stroke: '#ffd84a', 'stroke-width': 2, opacity: 0 }, g);
        return { g, sh, b, sm, hl, fl, x: HOLD[0], y: HOLD[1], z: HOLD[2], vx: 0, vy: 0, vz: 0, spin: 0, st: 'hold', t: 0, rim: 0, board: 0, scored: 0, bounces: 0, fire: 0 }; }
      function shoot(fx, fy) { if (!held) return; const len = Math.hypot(fx, fy); if (fy > -18 || len < 30) return;
        const p = cl(len / 230, 0.15, 1.25), sb = P(held.x, held.y, held.z), sr = P(hx, RY, RZ), aT = Math.atan2(sr[0] - sb[0], sb[1] - sr[1]), a = Math.atan2(fx, -fy);
        const dx = hx - held.x, dz = RZ + 0.03 - held.z, L = Math.hypot(dx, dz), dy = RY - held.y, th = 65 * Math.PI / 180, ct = Math.cos(th), v0 = Math.sqrt(G * L * L / (2 * ct * ct * (L * Math.tan(th) - dy)));
        const v = v0 * (1 + (p - 0.55) * 0.15), ph = Math.atan2(dx, dz) + (a - aT) * 0.24, vh = v * ct;
        Object.assign(held, { st: 'fly', vx: Math.sin(ph) * vh, vz: Math.cos(ph) * vh, vy: v * Math.sin(th), t: 0, spin: 0, fire: fire > 0 ? 1 : 0 }); balls.push(held); held = null; nextAt = tNow + 520; shotT = tNow; SFX.whoosh(); }
      function step(b, dt) { const py = b.y, ins0 = Math.hypot(b.x - hx, b.z - RZ);
        b.vy -= G * dt; b.x += b.vx * dt; b.y += b.vy * dt; b.z += b.vz * dt; b.spin += dt * 9;
        // rim: nearest point on the ring
        const rx = b.x - hx, rz = b.z - RZ, d = Math.hypot(rx, rz) || 1e-6, qx = hx + RR * rx / d, qz = RZ + RR * rz / d, ex = b.x - qx, ey = b.y - RY, ez = b.z - qz, dist = Math.hypot(ex, ey, ez);
        if (dist < BR + RT) { const nx = ex / dist, ny = ey / dist, nz = ez / dist, vn = b.vx * nx + b.vy * ny + b.vz * nz;
          if (vn < 0) { b.vx -= 1.55 * vn * nx; b.vy -= 1.55 * vn * ny; b.vz -= 1.55 * vn * nz; b.vx *= 0.92; b.vz *= 0.92; b.rim++; if (tNow - clangAt > 120) { SFX.clang(); clangAt = tNow; } }
          b.x = qx + nx * (BR + RT); b.y = RY + ny * (BR + RT); b.z = qz + nz * (BR + RT); }
        // backboard (front face) + its edges
        if (b.vz > 0 && b.z + BR > BZ && b.z < BZ + 0.08 && Math.abs(b.x - hx) < 0.9 + BR * 0.5 && b.y > 2.78 - BR * 0.5 && b.y < 3.85 + BR * 0.5) { b.vz = -b.vz * 0.6; b.vx *= 0.9; b.z = BZ - BR; b.board++; SFX.thud(); }
        // the net: inside the ring and just under it the cords catch the ball and slow it down
        const din = Math.hypot(b.x - hx, b.z - RZ); if (b.y < RY && b.y > RY - 0.45 && ins0 < RR && py >= RY - 0.45) { if (din > RR * 0.78 - BR * 0.4) { const k = (RR * 0.78 - BR * 0.4) / din; b.x = hx + (b.x - hx) * k; b.z = RZ + (b.z - RZ) * k; } b.vx *= 0.9; b.vz *= 0.9; b.vy *= 0.97; }
        // scored? the centre drops through the ring plane inside it
        if (!b.scored && py >= RY && b.y < RY && b.vy < 0 && Math.hypot(b.x - hx, b.z - RZ) < RR - 0.02) basket(b);
        if (b.y < BR) { b.y = BR; if (Math.abs(b.vy) > 1.2) { SFX.thud(); b.bounces++; } b.vy = -b.vy * 0.55; b.vx *= 0.8; b.vz *= 0.8; if (Math.abs(b.vy) < 0.6) b.vy = 0; } }
      function basket(b) { b.scored = 1; made++; const sw = !b.rim && !b.board; streak++; if (streak >= 3 && !fire) { fire = 1; ctx.toast('On fire!', W / 2, 150, '#ffb03a', true); SFX.win(); }
        const pts = (sw ? 3 : 2) * (fire ? 2 : 1), c = P(hx, RY, RZ); ctx.add(pts, c[0], c[1] - 34, (sw ? 'Swish! +' : '+') + pts, sw ? '#8fe0ff' : '#ffffff');
        ctx.burst(c[0], c[1] + 10, 'confetti', 14, { v: 140, life: 0.9 }); netSw = 1; netAt = tNow; cheerT = tNow; SFX.swish(); setTimeout(SFX.score, 80);
        if (streak % 5 === 0) me.play('happy'); }
      // input: press, drag, release = flick
      const api = {
        start() { if (!held) held = mkBall(); balls.forEach(b => { b.g.remove(); b.sh.remove(); }); balls = []; streak = 0; fire = 0; made = 0; moving = false; hx = 0; },
        down(p) { drag = { x: p.x, y: p.y, t: p.t, x0: p.x, y0: p.y }; },
        move(p) { if (!drag) return; drag.x = p.x; drag.y = p.y; },
        up(p) { if (!drag) return; const fx = p.x - drag.x0, fy = p.y - drag.y0; drag = null; shoot(fx, fy); },
        key(k, dn) { if (dn && (k === ' ' || k === 'ArrowUp')) { shoot(0, -127); return true; } },
        // for automated tests: shoot with a given flick
        _shoot: (fx, fy) => shoot(fx, fy), _balls: () => balls.map(b => [+b.x.toFixed(2), +b.y.toFixed(2), +b.z.toFixed(2), b.rim, b.board, b.scored]),
        timeUp() { ctx.finish({ sub: made + ' basket' + (made === 1 ? '' : 's') }); },
        celebrate(st) { if (st >= 2) me.play('happy'); },
        update(dt, t) { tNow = t; if (ctx.score >= 20 && !moving && !api._still) { moving = true; ctx.toast('The hoop moves!', W / 2, 160, '#ffe36e'); } if (moving) hx = Math.sin((t / 1000) * 0.9) * 0.75;
          if (!held && t > nextAt && ctx.playing) held = mkBall();
          for (const b of balls) { const n = 4; for (let i = 0; i < n; i++) step(b, dt / n); b.t += dt; if (b.st === 'fly' && !b.scored && (b.bounces >= 1 || b.t > 2.2) && !b.missed) { b.missed = 1; if (streak) { streak = 0; if (fire) { fire = 0; ctx.toast('Fire out', W / 2, 160, '#ffffff'); } } } }
          balls = balls.filter(b => { if (b.t > 3.2) { b.g.remove(); b.sh.remove(); return false; } return true; });
          // the creature: arms up holding the ball; a quick push on the shot, a hop on a basket
          const ts = t - shotT, tc = t - cheerT, hasB = !!held, E = track([[0, { armL: 128, armR: 128, lift: 0, sq: 0 }], [90, { armL: 168, armR: 168, lift: 4, sq: -0.06 }], [260, { armL: 150, armR: 150, lift: 0, sq: 0.04 }], [460, { armL: hasB ? 128 : 40, armR: hasB ? 128 : 40, lift: 0, sq: 0 }]], ts);
          if (tc < 700) { const u = tc / 700; E.lift += Math.sin(u * Math.PI) * 9; E.armL = lerp(E.armL, 150 + 20 * Math.sin(tc / 60), Math.sin(u * Math.PI)); E.armR = lerp(E.armR, 150 - 20 * Math.sin(tc / 60), Math.sin(u * Math.PI)); E.smile = Math.sin(u * Math.PI); }
          me.pose(E); me.yaw(180 + Math.sin(t / 900) * 6);
          drawHoop(t);
          // balls: pick their layer (in front of everything until they're up at the hoop, then between the rim halves)
          for (const b of [held, ...balls]) { if (!b) continue; if (b === held) { const k = cl(ts / 450, 0, 1); b.x = HOLD[0]; b.y = HOLD[1] + (1 - SM(k)) * -0.3 + Math.sin(t / 400) * 0.015; b.z = HOLD[2]; }
            const s = P(b.x, b.y, b.z), r = BR * s[2], behind = b.z > RZ - 0.35 && b.y < RY + 0.9 && b.st === 'fly'; if (behind && b.g.parentNode !== slotB) slotB.appendChild(b.g); else if (!behind && b.g.parentNode !== slotF) slotF.appendChild(b.g);
            b.b.setAttribute('cx', r2(s[0])); b.b.setAttribute('cy', r2(s[1])); b.b.setAttribute('r', r2(r));
            const sp = b.spin, c = Math.cos(sp), sn = Math.sin(sp); b.sm.setAttribute('d', 'M' + r2(s[0] - r * c) + ' ' + r2(s[1] - r * sn) + 'L' + r2(s[0] + r * c) + ' ' + r2(s[1] + r * sn) + 'M' + r2(s[0] + r * sn) + ' ' + r2(s[1] - r * c) + 'Q' + r2(s[0] - r * 0.25 * c) + ' ' + r2(s[1] - r * 0.25 * sn) + ' ' + r2(s[0] - r * sn) + ' ' + r2(s[1] + r * c));
            b.hl.setAttribute('cx', r2(s[0] - r * 0.35)); b.hl.setAttribute('cy', r2(s[1] - r * 0.4)); b.hl.setAttribute('rx', r2(r * 0.4)); b.hl.setAttribute('ry', r2(r * 0.25));
            b.fl.setAttribute('cx', r2(s[0])); b.fl.setAttribute('cy', r2(s[1])); b.fl.setAttribute('r', r2(r + 2)); b.fl.setAttribute('opacity', b.fire ? 0.5 + 0.4 * Math.sin(t / 60) : 0);
            const g0 = P(b.x, 0, b.z), hgt = cl(1 - b.y / 4, 0.25, 1); b.sh.setAttribute('cx', r2(g0[0])); b.sh.setAttribute('cy', r2(g0[1])); b.sh.setAttribute('rx', r2(BR * g0[2] * 1.1 * hgt)); b.sh.setAttribute('ry', r2(BR * g0[2] * 0.3 * hgt)); b.sh.setAttribute('opacity', r2(0.22 * hgt));
            if (b.fire && Math.random() < 0.5 && b.st === 'fly') ctx.burst(s[0], s[1], 'spark', 1, { v: 30, life: 0.4, g: -40, col: '#ffb03a' }); }
          // aim guide while dragging: a dotted arc of where the flick points
          if (drag && held && !api._g) api._g = S('path', { fill: 'none', stroke: '#ffffff', 'stroke-width': 3, 'stroke-dasharray': '2 7', 'stroke-linecap': 'round', opacity: 0.8 }, fg);
          if (api._g) { if (drag && held) { const fx = drag.x - drag.x0, fy = drag.y - drag.y0, s0 = P(held.x, held.y, held.z); api._g.setAttribute('d', 'M' + r2(s0[0]) + ' ' + r2(s0[1]) + 'l' + r2(-fx * 0.0) + ' 0l' + r2(fx * 0.6) + ' ' + r2(fy * 0.6)); api._g.setAttribute('opacity', cl(-fy / 60, 0, 0.8)); } else api._g.setAttribute('opacity', 0); }
        } };
      const SM = YG.SM; drawHoop(0); held = mkBall(); return api;
    } });
  }; go();
})();
