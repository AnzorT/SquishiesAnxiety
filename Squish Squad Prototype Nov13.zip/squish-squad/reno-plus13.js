// Renovation Catalog round 13 — Movie Room: FLOORS + RUGS on the RD.H10 / H11 / H12 toolkit, game style.
// Floors = r.f13: 80 x 56 perspective trapezoid (the room stretches it over the floor) painted in the floor style: soft blurred blotches,
// light from the back wall, details mapped through px(u, v). Rugs = flat 3D floor pieces (flat + noBlock): slab sides + a top-plane decal.
// Sets RenoDraw.PLUS13; catalog edits RD.SET13.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS12 && RD.H12 && RD.H11 && RD.H10 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS13) return;
  const K = X.K, shade = K.shade, N = RD.N, PI = Math.PI, H = RD.H10;
  const { cam, FR, vis, lit, rng, an, at, SPL, f1, n4, rep, pth, FONT } = H;

  // ======================= FLOORS =======================
  const TR = 'M14 0H66L80 56H0Z';
  // RD._FLAT: draw floors as a flat overhead 80 x 56 tile (undo the row spacing gv) so the house can lay them as a repeating perspective surface
  const ginv = v => (-0.7 + Math.sqrt(0.49 + 1.2 * Math.max(0, v))) / 0.6;
  const px = (u, v) => RD._FLAT ? [80 * u, 56 * ginv(v)] : [14 - 14 * v + (52 + 28 * v) * u, 56 * v], PP = (u, v) => { const p = px(u, v); return f1(p[0]) + ' ' + f1(p[1]); };
  const wk = v => (52 + 28 * v) / 80;
  const gv = t => t * (0.7 + 0.3 * t); // row spacing: rows get shorter toward the back wall
  const quad = (u0, v0, u1, v1) => 'M' + PP(u0, v0) + 'L' + PP(u1, v0) + 'L' + PP(u1, v1) + 'L' + PP(u0, v1) + 'Z';
  const lineUV = pts => 'M' + pts.map(([u, v]) => PP(u, v)).join('L');
  const crv = pts => { const P = pts.map(([u, v]) => px(u, v)); let d = 'M' + f1(P[0][0]) + ' ' + f1(P[0][1]);
    for (let i = 1; i < P.length - 1; i++) d += 'Q' + f1(P[i][0]) + ' ' + f1(P[i][1]) + ' ' + f1((P[i][0] + P[i + 1][0]) / 2) + ' ' + f1((P[i][1] + P[i + 1][1]) / 2);
    const l = P[P.length - 1]; return d + 'L' + f1(l[0]) + ' ' + f1(l[1]); };
  const FDEF = '<filter id="fb3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.4"/></filter><filter id="fb2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.2"/></filter><filter id="fb1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.6"/></filter>'
    + '<clipPath id="ftc"><path d="' + TR + '"/></clipPath>'
    + '<linearGradient id="fsh" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000000" stop-opacity="0.32"/><stop offset="0.12" stop-color="#000000" stop-opacity="0.06"/><stop offset="0.55" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="1" stop-color="#000000" stop-opacity="0.14"/></linearGradient>'
    + '<radialGradient id="fpl" cx="50%" cy="60%" r="55%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>'
    + '<linearGradient id="fsd" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000000" stop-opacity="0.2"/><stop offset="0.16" stop-color="#000000" stop-opacity="0"/><stop offset="0.84" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.2"/></linearGradient>';
  const FL = (body, dk) => RD._FLAT ? '<defs>' + FDEF + '</defs>' + body : '<defs>' + FDEF + '</defs><g clip-path="url(#ftc)">' + body + `<path d="${TR}" fill="url(#fsh)"/><path d="${TR}" fill="url(#fpl)" opacity="${dk ? 0.4 : 1}"/><path d="${TR}" fill="url(#fsd)"/></g>`;
  const fblot = (seed, n, cols, op, sz) => { const R = rng(seed); let o = '<g filter="url(#fb3)">';
    rep(n, i => { const u = R() * 1.1 - 0.05, v = R(), p = px(u, v), rx = (sz || 7) * (0.6 + R() * 0.8) * wk(v); o += `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(rx)}" ry="${f1(rx * (0.45 + 0.2 * v))}" fill="${cols[i % cols.length]}" opacity="${op}"/>`; }); return o + '</g>'; };

  // MOV-005 cracked concrete + cables held down with duct tape
  function fConc() { const R = rng('conc13');
    let s = '<rect width="80" height="56" fill="#b3b1aa"/>' + fblot('conc', 26, ['#c6c4bd', '#9c9a93', '#aba9a1'], 0.55, 8);
    s += rep(70, () => { const p = px(R(), R()); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.22 + R() * 0.3)}" fill="${R() < 0.55 ? '#8d8b84' : '#d4d2cb'}" opacity="0.75"/>`; }).join('');
    { const p = px(0.72, 0.3); s += `<g filter="url(#fb1)"><ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(7.5 * wk(0.3))}" ry="2.8" fill="#5c5950" opacity="0.32"/><ellipse cx="${f1(p[0] + 2)}" cy="${f1(p[1] + 0.6)}" rx="${f1(3.6 * wk(0.3))}" ry="1.4" fill="#4a473f" opacity="0.3"/></g>`; }
    const J = pts => `<path d="${lineUV(pts)}" stroke="#d6d4cd" stroke-width="0.3" fill="none" transform="translate(0.25 0.3)"/><path d="${lineUV(pts)}" stroke="#7a7871" stroke-width="0.4" fill="none"/>`;
    rep(4, k => s += J([[(k + 1) / 5, 0], [(k + 1) / 5, 1]])); [1, 2, 3].forEach(k => s += J([[0, gv(k / 4)], [1, gv(k / 4)]]));
    const ck = [[0.1, 0.58], [0.16, 0.63], [0.21, 0.61], [0.26, 0.7], [0.31, 0.72], [0.33, 0.82], [0.4, 0.87], [0.45, 1.02]], br = [[0.26, 0.7], [0.21, 0.79], [0.23, 0.87]], br2 = [[0.16, 0.63], [0.14, 0.7]];
    s += `<g fill="none" stroke-linejoin="round" stroke-linecap="round"><path d="${lineUV(ck)}" stroke="#e2e0d9" stroke-width="1" transform="translate(0.35 0.4)" opacity="0.8"/><path d="${lineUV(ck)}" stroke="#54524c" stroke-width="0.75"/><path d="${lineUV(br)}" stroke="#54524c" stroke-width="0.45"/><path d="${lineUV(br2)}" stroke="#54524c" stroke-width="0.35"/></g>`;
    s += `<path d="${lineUV([[0.3, 0.73], [0.36, 0.71], [0.375, 0.77], [0.33, 0.795]])}Z" fill="#9a978e" stroke="#6e6b64" stroke-width="0.35" stroke-linejoin="round"/><path d="${lineUV([[0.31, 0.735], [0.355, 0.72]])}" stroke="#c9c7c0" stroke-width="0.35"/>`;
    const cab = (pts, col, w) => { const d = crv(pts); return `<path d="${d}" stroke="#000000" stroke-opacity="0.28" stroke-width="${w + 0.8}" fill="none" stroke-linecap="round" transform="translate(0.5 1)" filter="url(#fb1)"/><path d="${d}" stroke="${shade(col, 0.6)}" stroke-width="${w + 0.4}" fill="none" stroke-linecap="round"/><path d="${d}" stroke="${col}" stroke-width="${w}" fill="none" stroke-linecap="round"/><path d="${d}" stroke="#ffffff" stroke-opacity="0.35" stroke-width="${f1(w * 0.28)}" fill="none" transform="translate(-0.15 -0.35)"/>`; };
    const A = [[-0.05, 0.52], [0.15, 0.48], [0.35, 0.56], [0.55, 0.5], [0.75, 0.6], [1.05, 0.55]], B = [[-0.05, 0.7], [0.2, 0.77], [0.45, 0.7], [0.62, 0.81], [0.85, 0.74], [1.05, 0.83]];
    s += cab(A, '#2b2c31', 0.8) + cab(B, '#e2783a', 0.95);
    const tape = (u, v, sk) => { const Q = [[u - 0.018, v - 0.042], [u + 0.017 + sk, v - 0.04], [u + 0.02 + sk, v + 0.042], [u - 0.016, v + 0.045]], d = 'M' + Q.map(([a, b]) => PP(a, b)).join('L') + 'Z';
      return `<path d="${d}" fill="#000000" opacity="0.25" transform="translate(0.4 0.8)" filter="url(#fb1)"/><path d="${d}" fill="#c2c6cb" stroke="#868b92" stroke-width="0.3" stroke-linejoin="round"/><path d="${lineUV([[u - 0.012, v - 0.034], [u + 0.012 + sk, v - 0.032]])}" stroke="#f1f3f5" stroke-width="0.3"/><path d="${lineUV([[u - 0.006, v - 0.018], [u + 0.006, v + 0.02]])}" stroke="#9a9fa6" stroke-width="0.2"/>`; };
    const mid = (P, i) => [(P[i][0] + P[i + 1][0]) / 2, (P[i][1] + P[i + 1][1]) / 2];
    [[A, 1, 0.006], [A, 3, -0.004], [B, 1, 0.004], [B, 3, -0.006], [B, 4, 0.005]].forEach(([P, i, sk]) => { const m = mid(P, i); s += tape(m[0], m[1], sk); });
    return FL(s); }

  // MOV-025 low-pile grey commercial carpet tiles (quarter-turned pile)
  function fTile() { const NU = 14, NV = 8, V = rep(NV + 1, k => gv(k / NV)); let s = '<rect width="80" height="56" fill="#8a8f96"/>', pile = '', seam = '';
    for (let v = 0; v < NV; v++) for (let u = 0; u < NU; u++) { const odd = (u + v) % 2, col = (u === 9 && v === 2) || (u === 3 && v === 6) ? '#7d8997' : odd ? '#83888f' : '#8f949b', v0 = V[v], v1 = V[v + 1];
      s += `<path d="${quad(u / NU, v0, (u + 1) / NU, v1)}" fill="${col}"/>`;
      rep(3, k => { pile += odd ? lineUV([[u / NU, v0 + (v1 - v0) * (k + 0.5) / 3], [(u + 1) / NU, v0 + (v1 - v0) * (k + 0.5) / 3]]) : lineUV([[(u + (k + 0.5) / 3) / NU, v0], [(u + (k + 0.5) / 3) / NU, v1]]); }); }
    s += `<path d="${pile}" stroke="#000000" stroke-opacity="0.07" stroke-width="0.3" fill="none"/>` + fblot('ct', 18, ['#9ca1a8', '#777c83'], 0.4, 9);
    s += `<path d="${quad(0.38, 0, 0.62, 1)}" fill="#a5aab0" opacity="0.35" filter="url(#fb3)"/>`;
    { const p = px(0.78, 0.66); s += `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(3 * wk(0.66))}" ry="1.6" fill="#6a6258" opacity="0.28" filter="url(#fb1)"/>`; }
    for (let u = 1; u < NU; u++) seam += lineUV([[u / NU, 0], [u / NU, 1]]); for (let v = 1; v < NV; v++) seam += lineUV([[0, V[v]], [1, V[v]]]);
    s += `<path d="${seam}" stroke="#a9aeb4" stroke-width="0.25" fill="none" transform="translate(0.2 0.25)"/><path d="${seam}" stroke="#5c6168" stroke-width="0.32" fill="none"/>`;
    const cu = 5 / 14, cv = V[6], a = px(cu, cv - 0.04), b = px(cu - 0.024, cv), c = px(cu, cv), tp = [(a[0] + b[0]) / 2 - 0.6, (a[1] + b[1]) / 2 - 0.9], P = q => f1(q[0]) + ' ' + f1(q[1]);
    s += `<path d="M${P(a)}L${P(c)}L${P(b)}Z" fill="#3e4146"/><path d="M${P(a)}L${P(tp)}L${P(b)}Z" fill="#000000" opacity="0.3" transform="translate(0.5 1)" filter="url(#fb1)"/><path d="M${P(a)}Q${f1(tp[0] + 1.4)} ${f1(tp[1] + 0.4)} ${P(tp)}Q${f1(tp[0] + 0.4)} ${f1(tp[1] + 1.6)} ${P(b)}Z" fill="#a4a9af" stroke="#5c6168" stroke-width="0.3" stroke-linejoin="round"/>`;
    return FL(s); }

  // MOV-045 plush crimson cinema carpet with chasing aisle lights
  function fCrim() { let s = '<rect width="80" height="56" fill="#9a1d2c"/>' + fblot('crim', 24, ['#b02a3c', '#7e1626'], 0.5, 8), lat = '', dots = '';
    const a = 0.5, CS = []; for (let c = -0.56; c <= 1.06; c += 1 / 16) CS.push(c);
    CS.forEach(c => { lat += lineUV([[c, 0], [c + a, 1]]) + lineUV([[c + a, 0], [c, 1]]); });
    CS.forEach(c1 => CS.forEach(c2 => { const v = (c2 + a - c1) / (2 * a), u = c1 + a * v; if (v < 0 || v > 1 || u < -0.03 || u > 1.03) return; const p = px(u, v), z = 0.55 * wk(v);
      dots += `<path d="M${f1(p[0])} ${f1(p[1] - z * 0.62)}L${f1(p[0] + z)} ${f1(p[1])}L${f1(p[0])} ${f1(p[1] + z * 0.62)}L${f1(p[0] - z)} ${f1(p[1])}Z"/>`; }));
    s += `<path d="${lat}" stroke="#e8b850" stroke-opacity="0.2" stroke-width="0.25" fill="none"/><g fill="#efc25a" opacity="0.6">${dots}</g>`;
    [0.2, 0.8].forEach(u => { const ln = lineUV([[u, 1], [u, 0]]);
      s += `<path d="${ln}" stroke="#ffb347" stroke-width="3" opacity="0.3" filter="url(#fb2)"/><path d="${quad(u - 0.011, 0, u + 0.011, 1)}" fill="#241a1e" stroke="#c9a24a" stroke-width="0.25"/>`;
      s += rep(26, i => { const v = gv((i + 0.5) / 26), p = px(u, v), r = 0.3 * wk(v) + 0.1, b = n4(-(i / 26) * 1.8);
        return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(r * 3.2)}" fill="#ffb347" opacity="0.05" filter="url(#fb1)">${an('opacity', '0.05;0.45;0.05', 1.8, b)}</circle><circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(r)}" fill="#ffe0a0" opacity="0.35">${an('opacity', '0.35;1;0.35', 1.8, b)}</circle>`; }).join(''); });
    return FL(s); }

  // MOV-065 heated dark teak hardwood with recessed LED guides
  function fTeak() { const NP = 26, R = rng('teak13'), PC = ['#5e3722', '#683d24', '#52311e', '#6f4227', '#5a3421'];
    let s = '<defs><radialGradient id="tkh" cx="50%" cy="72%" r="60%"><stop offset="0" stop-color="#ff9a3a" stop-opacity="0.24"/><stop offset="1" stop-color="#ff9a3a" stop-opacity="0"/></radialGradient></defs><rect width="80" height="56" fill="#4e2e1b"/>', lines = '';
    for (let i = 0; i < NP; i++) { const u0 = i / NP, u1 = (i + 1) / NP, cuts = [0]; let cv = R() * 0.25; while (cv < 0.94) { cuts.push(gv(cv)); cv += 0.2 + R() * 0.16; } cuts.push(1);
      for (let j = 0; j < cuts.length - 1; j++) { s += `<path d="${quad(u0, cuts[j], u1, cuts[j + 1])}" fill="${shade(PC[(i * 2 + j) % 5], 0.92 + R() * 0.16)}"/>`; if (j) lines += `<path d="${lineUV([[u0, cuts[j]], [u1, cuts[j]]])}" stroke="#2a160b" stroke-width="0.3"/>`; }
      { const ub = u0 + (0.5 + (R() - 0.5) * 0.3) / NP, ph = R() * 6, pts = rep(9, j => [ub + 0.003 * Math.sin(j * 1.3 + ph), j / 8]);
        s += `<path d="${crv(pts)}" stroke="#2c170b" stroke-opacity="0.24" stroke-width="0.22" fill="none"/><path d="${crv(pts.map(([x, y]) => [x + 0.004, y]))}" stroke="#c88a58" stroke-opacity="0.16" stroke-width="0.25" fill="none"/>`; }
      lines += `<path d="${lineUV([[u0, 0], [u0, 1]])}" stroke="#231208" stroke-width="0.32"/>`; }
    s += fblot('teak', 16, ['#80502f', '#3a2112'], 0.3, 8) + lines;
    s += `<g filter="url(#fb3)"><ellipse cx="40" cy="9" rx="17" ry="3.2" fill="#ffe9c8" opacity="0.22"/><path d="${quad(0.42, 0.05, 0.58, 0.55)}" fill="#ffe6c0" opacity="0.08"/></g>`;
    s += `<path d="${TR}" fill="url(#tkh)">${an('opacity', '0.55;1;0.55', 6, 0, SPL(2))}</path>`;
    [0.07, 0.93].forEach((u, i) => { const ln = lineUV([[u, 1], [u, 0]]);
      s += `<path d="${quad(u - 0.008, 0, u + 0.008, 1)}" fill="#160b05"/><path d="${ln}" stroke="#ffcf7a" stroke-width="3" opacity="0.45" filter="url(#fb2)">${an('opacity', '0.35;0.65;0.35', 4, -i * 2, SPL(2))}</path><path d="${ln}" stroke="#ffe7b8" stroke-width="0.55"/>`
        + `<path d="${ln}" stroke="#ffffff" stroke-width="1.1" stroke-linecap="round" stroke-dasharray="5 66" opacity="0.9"><animate attributeName="stroke-dashoffset" values="0;-71" dur="3s" begin="${-i * 1.5}s" repeatCount="indefinite"/></path>`; });
    return FL(s, 1); }

  // MOV-085 interactive haptic bass-resonant glass flooring
  function fGlass() { const NU = 12, NV = 7, V = rep(NV + 1, k => gv(k / NV)), R = rng('hg13'), CL = ['#00d8ff', '#8a2cff', '#ff1f9a'], m = 0.005;
    let s = '<defs><linearGradient id="hgt" x1="0" y1="0" x2="0.4" y2="1"><stop offset="0" stop-color="#2a1470"/><stop offset="1" stop-color="#120838"/></linearGradient><linearGradient id="hgs" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs><rect width="80" height="56" fill="#0e0b1e"/>', seam = '';
    s += rep(46, i => { const p = px(R(), R()); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.18 + R() * 0.22)}" fill="${i % 3 ? '#fff4dc' : '#cfe6ff'}" opacity="0.4">${an('opacity', '0.15;0.95;0.15', n4(1.8 + R() * 2.6), n4(-R() * 3))}</circle>`; }).join('');
    for (let v = 0; v < NV; v++) for (let u = 0; u < NU; u++) { const u0 = u / NU + m, u1 = (u + 1) / NU - m, v0 = V[v] + m * 1.4, v1 = V[v + 1] - m * 1.4, q = quad(u0, v0, u1, v1), d = Math.hypot(u - 5.5, (v - 3) * 1.6) * 0.45;
      s += `<path d="${q}" fill="url(#hgt)"/><path d="${q}" fill="${CL[(u + v) % 3]}" opacity="0.55"><animate attributeName="opacity" values="0.55;1;0.75;0.55" keyTimes="0;0.1;0.4;1" dur="2.4s" begin="${n4(d * 0.22 - 2.4)}s" repeatCount="indefinite"/></path>`
        + `<path d="${lineUV([[u0, v1], [u0, v0], [u1, v0]])}" stroke="#b49cff" stroke-opacity="0.75" stroke-width="0.22" fill="none"/>`; }
    for (let u = 1; u < NU; u++) seam += lineUV([[u / NU, 0], [u / NU, 1]]); for (let v = 1; v < NV; v++) seam += lineUV([[0, V[v]], [1, V[v]]]);
    s += `<path d="${seam}" stroke="#6a3cff" stroke-width="0.9" fill="none" opacity="0.5" filter="url(#fb1)">${an('opacity', '0.3;0.8;0.3', 1.2)}</path><path d="${seam}" stroke="#8f6bff" stroke-opacity="0.9" stroke-width="0.24" fill="none"/>`;
    // touch-ripple rings removed (user)
    [].forEach(([u, v, b]) => { const p = px(u, v), RR = 24 * wk(v);
      s += `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(4 * wk(v))}" ry="${f1(2.2 * wk(v))}" fill="#8ff6ff" opacity="0" filter="url(#fb2)"><animate attributeName="opacity" values="0.7;0;0" keyTimes="0;0.3;1" dur="2.4s" begin="${n4(-b)}s" repeatCount="indefinite"/></ellipse>`;
      s += rep(3, k => { const bg = n4(-b - k * 0.8); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="0.5" ry="0.3" fill="none" stroke="#8ff6ff" stroke-width="0.7" opacity="0"><animate attributeName="rx" values="0.5;${f1(RR)}" dur="2.4s" begin="${bg}s" repeatCount="indefinite"/><animate attributeName="ry" values="0.3;${f1(RR * 0.55)}" dur="2.4s" begin="${bg}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.9;0" dur="2.4s" begin="${bg}s" repeatCount="indefinite"/></ellipse>`; }).join(''); });
    s += `<path d="M-30 0H-12L-22 56H-40Z" fill="url(#hgs)">${at('translate', '0 0;0 0;130 0', 6, 0, ' keyTimes="0;0.4;1"')}</path>`;
    return FL(s, 1); }

  const FLOOR13 = { conc: fConc, tile: fTile, crim: fCrim, teak: fTeak, glass: fGlass };
  const draw12 = RD.draw;
  RD.draw = (r, o) => { const res = draw12(r, o); if (!res || res._p13) return res;
    try { const f = r.f13 && FLOOR13[r.f13]; if (f && res.surf) { res._p13 = 1; res.vb = '0 0 80 56'; res.svg = RD.svgDoc('0 0 80 56', [], f()); res.src = 'data:image/svg+xml,' + encodeURIComponent(res.svg); } } catch (e) { console.warn('reno plus13', r.id, e); }
    return res; };

  // ======================= RUGS (flat floor pieces) =======================
  const DEF13 = '<filter id="r13b" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="1.6"/></filter><filter id="r13s" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="0.5"/></filter>';
  const ellP = (a, b, n) => rep(n, i => { const t = i / n * 2 * PI; return [a * Math.cos(t), b * Math.sin(t)]; });
  const rrP = (w, d, r) => { const o = []; [[w / 2 - r, d / 2 - r, 0], [-w / 2 + r, d / 2 - r, PI / 2], [-w / 2 + r, -d / 2 + r, PI], [w / 2 - r, -d / 2 + r, 1.5 * PI]].forEach(([cx, cz, a0]) => { for (let k = 0; k <= 6; k++) { const a = a0 + k / 6 * PI / 2; o.push([cx + r * Math.cos(a), cz + r * Math.sin(a)]); } }); return o; };
  const dP = P => 'M' + P.map(q => f1(q[0]) + ' ' + f1(q[1])).join('L') + 'Z';
  // slab: contact shadow + lit visible side faces of the outline extruded to thickness t
  const slab = (C, P, t, side) => { let cx = 0, cz = 0; P.forEach(q => { cx += q[0]; cz += q[1]; }); cx /= P.length; cz /= P.length;
    let s = `<g transform="${FR(C, [0, 0.03, 0], [1, 0, 0], [0, 0, 1])}"><path d="${dP(P.map(q => [q[0] * 1.02 + 2, q[1] * 1.02 + 3]))}" fill="#000000" opacity="0.3" filter="url(#r13b)"/></g>`;
    P.forEach((a, i) => { const b = P[(i + 1) % P.length], dx = b[0] - a[0], dz = b[1] - a[1], L = Math.hypot(dx, dz) || 1; let n = [dz / L, 0, -dx / L]; if (n[0] * ((a[0] + b[0]) / 2 - cx) + n[2] * ((a[1] + b[1]) / 2 - cz) < 0) n = [-n[0], 0, -n[2]];
      const Q = [[a[0], 0, a[1]], [b[0], 0, b[1]], [b[0], t, b[1]], [a[0], t, a[1]]].map(C.P); if (!vis(C, n)) return; const c = shade(side, lit(C, n)); s += `<path d="${pth(Q)}" fill="${c}" stroke="${c}" stroke-width="0.3"/>`; });
    return s; };
  const top = (C, t, svg) => `<g transform="${FR(C, [0, t, 0], [1, 0, 0], [0, 0, 1])}">${svg}</g>`;
  // clipped top art + light from the back-left + plush darker rim
  const face = (id, P, art, rim) => `<defs><clipPath id="${id}c"><path d="${dP(P)}"/></clipPath><linearGradient id="${id}l" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.16"/></linearGradient></defs>`
    + `<g clip-path="url(#${id}c)">${art}<path d="${dP(P)}" fill="url(#${id}l)"/><path d="${dP(P)}" fill="none" stroke="#000000" stroke-opacity="${rim == null ? 0.28 : rim}" stroke-width="5" filter="url(#r13b)"/></g>`;
  const RUG = (w, d, o) => Object.assign({ w, d, flat: 1, noBlock: 1, build: () => [] }, o || {});

  // MOV-020 frayed braided rag rug (loose strand sways)
  N.rag13 = S => { const A = 84, B = 56, T = 2.2, P = ellP(A, B, 60), COLS = ['#c8553d', '#e8b04a', '#4f7cac', '#7fa65a', '#e9dcc4', '#9a5a8a', '#d97a4a'];
    const D = RUG(180, 124, { round: 1 });
    D.fx = ctx => { const C = cam(ctx), R = rng('rag13'); let art = `<ellipse rx="${A}" ry="${B}" fill="#6a4a3a"/>`, k = 0;
      for (; ; k++) { const rx = A - 2.6 - 5 * k, ry = B - 2.6 - 5 * k; if (ry < 3) break; const c = COLS[k % 7];
        art += `<ellipse rx="${f1(rx)}" ry="${f1(ry)}" fill="none" stroke="${c}" stroke-width="4.9"/><ellipse rx="${f1(rx)}" ry="${f1(ry)}" fill="none" stroke="${shade(c, 0.66)}" stroke-width="4.9" stroke-dasharray="1.1 2.3" opacity="0.6"/>`
          + `<ellipse rx="${f1(rx - 1)}" ry="${f1(ry - 1)}" fill="none" stroke="${shade(c, 1.25)}" stroke-width="0.6" stroke-dasharray="1.6 1.8" opacity="0.7"/><ellipse rx="${f1(rx + 2.45)}" ry="${f1(ry + 2.45)}" fill="none" stroke="#3a2418" stroke-width="0.4" opacity="0.45"/>`; }
      { const rx = A - 2.6 - 5 * k + 2.4, ry = B - 2.6 - 5 * k + 2.4; if (ry > 0.5) art += `<ellipse rx="${f1(rx)}" ry="${f1(ry)}" fill="${COLS[k % 7]}"/><path d="M${f1(-rx * 0.8)} 0H${f1(rx * 0.8)}" stroke="${shade(COLS[k % 7], 0.66)}" stroke-width="${f1(ry * 1.2)}" stroke-dasharray="1.1 2.3" opacity="0.5"/>`; }
      let fr = '';
      rep(54, () => { const t = R() * 2 * PI, x = A * Math.cos(t), z = B * Math.sin(t), nx = Math.cos(t) / A, nz = Math.sin(t) / B, nl = Math.hypot(nx, nz), a = Math.atan2(nz / nl, nx / nl) + (R() - 0.5) * 0.9, L = 1.4 + R() * 2;
        fr += `<path d="M${f1(x)} ${f1(z)}l${f1(L * Math.cos(a))} ${f1(L * Math.sin(a))}" stroke="${R() < 0.75 ? COLS[0] : '#e9dcc4'}" stroke-width="0.5" stroke-linecap="round"/>`; });
      const t0 = 0.55, rx0 = A * Math.cos(t0), rz0 = B * Math.sin(t0), ang = Math.atan2(Math.sin(t0) / B, Math.cos(t0) / A) * 180 / PI;
      const strand = `<g><animateTransform attributeName="transform" type="rotate" values="-12 ${f1(rx0)} ${f1(rz0)};14 ${f1(rx0)} ${f1(rz0)};-12 ${f1(rx0)} ${f1(rz0)}" dur="3.6s" repeatCount="indefinite"${SPL(2)}/><g transform="translate(${f1(rx0)} ${f1(rz0)}) rotate(${f1(ang)})"><path d="M-1 0q4 2.6 7.5 0.6q3.4 -2 6.5 1.2q1.6 1.6 3 1" stroke="${shade(COLS[0], 0.7)}" stroke-width="1.5" fill="none" stroke-linecap="round"/><path d="M-1 0q4 2.6 7.5 0.6q3.4 -2 6.5 1.2q1.6 1.6 3 1" stroke="${COLS[0]}" stroke-width="1" fill="none" stroke-linecap="round"/><path d="M15.8 2.6l1.6 0.2M15.6 2.9l1.2 1" stroke="${COLS[0]}" stroke-width="0.4" stroke-linecap="round"/></g></g>`;
      const s = slab(C, P, T, '#8a3a2a') + top(C, T, face('rg', P, art) + fr + strand);
      return { defs: DEF13, front: s, bb: C.bb(5) }; };
    return D; };

  // MOV-040 film-strip printed nylon runner
  N.film13 = S => { const W = 240, Dd = 64, T = 1.4, P = rrP(W, Dd, 3);
    const D = RUG(250, 70);
    const ico = (i, cx) => { const B = (y, sq) => `<g transform="translate(${cx} ${y}) scale(${sq ? '1.2 0.8' : '1 1'})"><path d="M-7 4C-7.4 -3 -4 -7 0 -7C4 -7 7.4 -3 7 4Z" fill="#a46bff"/><ellipse cx="-2.6" cy="-4.4" rx="1.8" ry="1" fill="#ffffff" opacity="0.45"/><circle cx="-2.4" cy="-1" r="1.3" fill="#ffffff"/><circle cx="2.4" cy="-1" r="1.3" fill="#ffffff"/><circle cx="-2.2" cy="-0.8" r="0.7" fill="#2a1450"/><circle cx="2.6" cy="-0.8" r="0.7" fill="#2a1450"/><path d="M-1.4 1.6Q0 2.8 1.4 1.6" stroke="#2a1450" stroke-width="0.5" fill="none"/></g>`;
      const star = (r, y) => { let d = ''; for (let k = 0; k < 10; k++) { const a = -PI / 2 + k * PI / 5, rr = k % 2 ? r * 0.45 : r; d += (k ? 'L' : 'M') + f1(cx + rr * Math.cos(a)) + ' ' + f1(y + rr * Math.sin(a)); } return `<path d="${d}Z" fill="#ffd34a" stroke="#c98a1a" stroke-width="0.4"/>`; };
      if (i === 0) return B(4) + `<ellipse cx="${cx}" cy="9.5" rx="7" ry="1.2" fill="#000000" opacity="0.3"/>`;
      if (i === 1) return B(5, 1) + `<ellipse cx="${cx}" cy="9.5" rx="8" ry="1.2" fill="#000000" opacity="0.35"/>`;
      if (i === 2) return B(-5) + `<ellipse cx="${cx}" cy="9.5" rx="4" ry="0.8" fill="#000000" opacity="0.2"/><path d="M${cx - 8} 6l2 1M${cx + 8} 6l-2 1" stroke="#ffffff" stroke-width="0.6"/>`;
      if (i === 3) return star(9, 0) + star(2.6, -10) + star(2, 9);
      if (i === 4) return `<path d="M${cx - 6} -4L${cx - 4} 10H${cx + 4}L${cx + 6} -4Z" fill="#f4efe6"/><path d="M${cx - 4.5} -4L${cx - 3} 10M${cx} -4V10M${cx + 4.5} -4L${cx + 3} 10" stroke="#e0383e" stroke-width="1.4"/>` + rep(7, k => `<circle cx="${cx - 5 + k * 1.7}" cy="${-5 - (k % 2) * 1.6}" r="2" fill="#fff6d8" stroke="#e8c27a" stroke-width="0.3"/>`).join('');
      if (i === 5) return `<circle cx="${cx + 2}" cy="-2" r="7" fill="#fff1c8"/><circle cx="${cx + 5}" cy="-4" r="6" fill="#33467a"/>` + star(1.6, 8).replace(/#ffd34a/, '#fff1c8');
      if (i === 6) return B(4) + `<path d="M${cx + 6} -8c-1.6 -2.4 -4.6 -0.6 -2.8 1.4l2.8 2.8l2.8 -2.8c1.8 -2 -1.2 -3.8 -2.8 -1.4Z" fill="#ff5f8a"/>`;
      return `<text x="${cx}" y="1.8" text-anchor="middle" ${FONT} font-size="5" fill="#f1e4c4" letter-spacing="0.4">THE</text><text x="${cx}" y="8" text-anchor="middle" ${FONT} font-size="5" fill="#f1e4c4" letter-spacing="0.4">END</text>`; };
    D.fx = ctx => { const C = cam(ctx), BG = ['#3b5a8a', '#5a3b7a', '#2f6f6a', '#7a4a3a', '#3b5a8a', '#25305a', '#5a3b7a', '#2a2a30'];
      let art = `<defs><linearGradient id="fms" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.14"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs><rect x="${-W / 2}" y="${-Dd / 2}" width="${W}" height="${Dd}" fill="#1c1b21"/>`;
      for (let x = -W / 2 + 4; x <= W / 2 - 4; x += 7.25) [-Dd / 2 + 4.6, Dd / 2 - 7.4].forEach(z => art += `<rect x="${f1(x - 1.8)}" y="${f1(z)}" width="3.6" height="2.8" rx="0.7" fill="#e8e2d4"/>`);
      rep(8, i => { const x0 = -114.5 + i * 29, cx = x0 + 13; art += `<rect x="${f1(x0)}" y="-20" width="26" height="40" rx="1.2" fill="${BG[i]}"/><clipPath id="fmc${i}"><rect x="${f1(x0)}" y="-20" width="26" height="40" rx="1.2"/></clipPath><g clip-path="url(#fmc${i})"><rect x="${f1(x0)}" y="10" width="26" height="10" fill="#000000" opacity="0.18"/>${ico(i, cx)}</g><rect x="${f1(x0)}" y="-20" width="26" height="40" rx="1.2" fill="none" stroke="#0e0d12" stroke-width="0.6"/><rect x="${f1(x0 + 0.6)}" y="-19.4" width="24.8" height="38.8" rx="0.8" fill="none" stroke="#ffffff" stroke-opacity="0.15" stroke-width="0.4"/>`; });
      art += `<rect x="${f1(-W / 2 + 0.7)}" y="${f1(-Dd / 2 + 0.7)}" width="${W - 1.4}" height="${Dd - 1.4}" rx="2.4" fill="none" stroke="#4a4a52" stroke-width="1.2"/>`;
      art += `<rect x="-150" y="-40" width="44" height="80" fill="url(#fms)" transform="skewX(-25)">${at('translate', '0 0;0 0;330 0', 8, 0, ' keyTimes="0;0.45;1" additive="sum"')}</rect>`;
      const s = slab(C, P, T, '#2a2a30') + top(C, T, face('fm', P, art, 0.22));
      return { defs: DEF13, front: s, bb: C.bb(4) }; };
    return D; };

  // MOV-060 thick shag blackout acoustic rug
  N.shag13 = S => { const W = 172, Dd = 124, RC = 20, T = 4, P = rrP(W, Dd, RC), PAL = ['#3a3a42', '#232328', '#45454e', '#1c1c20', '#2e2e35'];
    const D = RUG(180, 130);
    const inside = (x, z) => { const ax = Math.abs(x) - (W / 2 - RC), az = Math.abs(z) - (Dd / 2 - RC); return Math.abs(x) <= W / 2 && Math.abs(z) <= Dd / 2 && (ax <= 0 || az <= 0 || ax * ax + az * az <= RC * RC); };
    D.fx = ctx => { const C = cam(ctx), R = rng('shag13'), tf = [];
      for (let i = 0; i < 640; i++) { const x = (R() - 0.5) * W, z = (R() - 0.5) * Dd; if (!inside(x, z)) continue; tf.push([x, z, 2.6 + R() * 2, PI / 2 + (R() - 0.5) * 1.8, PAL[(R() * 5) | 0], R()]); }
      tf.sort((a, b) => a[1] - b[1]);
      const tuft = ([x, z, L, a, c, h], w) => { const ex = x + L * Math.cos(a), ez = z + L * Math.sin(a), mx = x + L * 0.5 * Math.cos(a - 0.5), mz = z + L * 0.5 * Math.sin(a - 0.5);
        return `<path d="M${f1(x)} ${f1(z)}Q${f1(mx)} ${f1(mz)} ${f1(ex)} ${f1(ez)}" stroke="${c}" stroke-width="${w || 1.6}" fill="none" stroke-linecap="round"/>` + (h > 0.7 ? `<path d="M${f1(x - 0.3)} ${f1(z - 0.3)}Q${f1(mx - 0.3)} ${f1(mz - 0.3)} ${f1(ex - 0.2)} ${f1(ez - 0.2)}" stroke="#5c5c66" stroke-width="0.45" fill="none" stroke-linecap="round" opacity="0.8"/>` : ''); };
      const art = `<path d="${dP(P)}" fill="#26262c"/>` + tf.map(q => tuft(q)).join('');
      let fr = ''; const per = []; P.forEach((a, i) => { const b = P[(i + 1) % P.length], L = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.max(1, Math.round(L / 2.4)); for (let k = 0; k < n; k++) per.push([a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n]); });
      per.forEach(([x, z]) => { const a = Math.atan2(z / Dd, x / W) + (R() - 0.5) * 0.9; fr += tuft([x - Math.cos(a) * 1.2, z - Math.sin(a) * 1.2, 2.4 + R() * 2.2, a, PAL[(R() * 5) | 0], R()], 1.5); });
      const s = slab(C, P, T, '#1f1f24') + top(C, T * 0.45, fr) + top(C, T, face('sh', P, art, 0.4) + fr);
      return { defs: DEF13, front: s, bb: C.bb(6) }; };
    return D; };

  // MOV-080 hand-tufted Art Deco gold-and-crimson carpet (gold shimmer)
  N.deco13 = S => { const W = 196, Dd = 126, T = 1.8, P = rrP(W, Dd, 2);
    const D = RUG(200, 130);
    const G = (st, fl, k) => { const w = x => f1(x * (k || 1)); let g = `<g fill="none" stroke="${st}" stroke-linejoin="miter">`;
      g += `<rect x="${-W / 2 + 4.5}" y="${-Dd / 2 + 4.5}" width="${W - 9}" height="${Dd - 9}" stroke-width="${w(3.2)}"/><rect x="${-W / 2 + 10}" y="${-Dd / 2 + 10}" width="${W - 20}" height="${Dd - 20}" stroke-width="${w(0.9)}"/><rect x="${-W / 2 + 13}" y="${-Dd / 2 + 13}" width="${W - 26}" height="${Dd - 26}" stroke-width="${w(0.5)}"/>`;
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => g += `<g transform="translate(${sx * (W / 2 - 13)} ${sz * (Dd / 2 - 13)}) scale(${-sx} ${-sz})"><path d="M0 18V0H18M4 13V8H8V4H13" stroke-width="${w(1.2)}"/><path d="M4 4h3v3h-3z" fill="${fl}" stroke="none"/></g>`);
      g += `<circle r="27" stroke-width="${w(1.6)}"/><circle r="23" stroke-width="${w(0.6)}"/>` + rep(24, i => { const a = i * PI / 12, r1 = i % 2 ? 18 : 22.4; return `<path d="M${f1(9 * Math.cos(a))} ${f1(9 * Math.sin(a))}L${f1(r1 * Math.cos(a))} ${f1(r1 * Math.sin(a))}" stroke-width="${w(i % 2 ? 0.6 : 1)}"/>`; }).join('') + `<circle r="7.2" fill="${fl}" stroke="none"/>`;
      [-1, 1].forEach(sx => rep(3, k => g += `<path d="M${sx * (52 + k * 7)} -20L${sx * (64 + k * 7)} 0L${sx * (52 + k * 7)} 20" stroke-width="${w(1.4)}"/>`));
      [-1, 1].forEach(sz => g += `<g transform="translate(0 ${sz * (Dd / 2 - 13)}) scale(1 ${sz})"><path d="M-13 0A13 13 0 0 1 13 0M-8.5 0A8.5 8.5 0 0 1 8.5 0" stroke-width="${w(1)}"/>${rep(7, i => { const a = PI + (i + 0.5) * PI / 7; return `<path d="M${f1(3.4 * Math.cos(a))} ${f1(3.4 * Math.sin(a))}L${f1(8 * Math.cos(a))} ${f1(8 * Math.sin(a))}" stroke-width="${w(0.7)}"/>`; }).join('')}</g>`);
      return g + '</g>'; };
    D.fx = ctx => { const C = cam(ctx), R = rng('deco13');
      let art = `<defs><linearGradient id="dgl" gradientUnits="userSpaceOnUse" x1="-60" y1="-40" x2="-20" y2="40"><stop offset="0" stop-color="#fff6c8" stop-opacity="0"/><stop offset="0.5" stop-color="#fff6c8" stop-opacity="0.95"/><stop offset="1" stop-color="#fff6c8" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-120 0;-120 0;240 0" keyTimes="0;0.35;1" dur="5s" repeatCount="indefinite"/></linearGradient></defs>`
        + `<rect x="${-W / 2}" y="${-Dd / 2}" width="${W}" height="${Dd}" fill="#8c1a2b"/><rect x="${-W / 2 + 13}" y="${-Dd / 2 + 13}" width="${W - 26}" height="${Dd - 26}" fill="#7a1525"/>`;
      art += '<g filter="url(#r13b)">' + rep(12, i => `<ellipse cx="${f1((R() - 0.5) * W)}" cy="${f1((R() - 0.5) * Dd)}" rx="${f1(10 + R() * 14)}" ry="${f1(7 + R() * 9)}" fill="${i % 2 ? '#a02436' : '#5e0f1b'}" opacity="0.35"/>`).join('') + '</g>';
      art += `<circle r="7.2" fill="#d9a441"/><circle r="3.6" fill="#8c1a2b"/>`;
      art += `<g transform="translate(0.5 0.7)" opacity="0.7" filter="url(#r13s)">${G('#3e0912', '#3e0912')}</g>` + G('#d9a441', '#d9a441') + `<g transform="translate(-0.25 -0.3)" opacity="0.45">${G('#ffe7a0', 'none', 0.4)}</g>` + G('url(#dgl)', 'url(#dgl)') + `<circle r="3.6" fill="#8c1a2b"/>`;
      const s = slab(C, P, T, '#6e1220') + top(C, T, face('dc', P, art, 0.24));
      return { defs: DEF13, front: s, bb: C.bb(4) }; };
    return D; };

  // MOV-100 self-cleaning silk acoustic cloud rug (pearly shimmer + sparkle sweep)
  N.cloud13 = S => { const A = 92, B = 64, T = 3.2, cl = k => rep(120, i => { const t = i / 120 * 2 * PI, r = (0.88 + 0.12 * Math.abs(Math.sin(4 * t))) * k; return [A * r * Math.cos(t), B * r * Math.sin(t)]; }), P = cl(1);
    const D = RUG(200, 140, { round: 1 });
    const spk = (x, z, r, b) => `<path d="M${f1(x)} ${f1(z - r)}Q${f1(x + r * 0.18)} ${f1(z - r * 0.18)} ${f1(x + r)} ${f1(z)}Q${f1(x + r * 0.18)} ${f1(z + r * 0.18)} ${f1(x)} ${f1(z + r)}Q${f1(x - r * 0.18)} ${f1(z + r * 0.18)} ${f1(x - r)} ${f1(z)}Q${f1(x - r * 0.18)} ${f1(z - r * 0.18)} ${f1(x)} ${f1(z - r)}Z" fill="#ffffff">${an('opacity', '0.2;1;0.2', 0.9, b)}</path>`;
    D.fx = ctx => { const C = cam(ctx);
      let art = `<defs><linearGradient id="csg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6efff"/><stop offset="0.5" stop-color="#e4eaff"/><stop offset="1" stop-color="#fbe4f1"/></linearGradient>`
        + `<linearGradient id="csh" gradientUnits="userSpaceOnUse" x1="-60" y1="0" x2="60" y2="0"><stop offset="0" stop-color="#ffd6f0" stop-opacity="0"/><stop offset="0.35" stop-color="#ffc8ea" stop-opacity="0.55"/><stop offset="0.65" stop-color="#bfe8ff" stop-opacity="0.55"/><stop offset="1" stop-color="#bfe8ff" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-150 0;150 0" dur="7s" repeatCount="indefinite"/></linearGradient>`
        + `<linearGradient id="csw" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.5"/></linearGradient></defs>`
        + `<path d="${dP(P)}" fill="url(#csg)"/><rect x="-100" y="-70" width="200" height="140" fill="url(#csh)"/>`;
      [0.76, 0.52, 0.28].forEach(k => { const d = dP(cl(k)); art += `<path d="${d}" fill="none" stroke="#ffffff" stroke-width="0.7" transform="translate(-0.5 -0.6)"/><path d="${d}" fill="none" stroke="#bfb0e2" stroke-width="0.8"/>`; });
      art += `<g>${at('translate', '-120 0;120 0', 4.5)}<rect x="-16" y="-70" width="16" height="140" fill="url(#csw)" transform="skewX(-12)"/>` + [[-56, 2.4], [-38, 1.6], [-20, 2.8], [-2, 1.8], [16, 2.6], [34, 1.5], [52, 2.2]].map(([z, r], i) => spk(z * 0.21 - 2, z, r, n4(-i * 0.13))).join('') + '</g>';
      const s = slab(C, P, T, '#d6cdea') + top(C, T, face('cl', P, art, 0.16));
      return { defs: DEF13, front: s, bb: C.bb(4) }; };
    return D; };

  // ---------- catalog edits ----------
  RD.SET13 = {
    'MOV-005': { s3: null, f13: 'conc', note: 'Bare grey concrete with saw-cut joints, a long crack with a chipped edge, an old oil stain and paint specks. A black cable and an orange extension cord snake across it, held down with strips of silver duct tape.' },
    'MOV-025': { f13: 'tile', note: 'Low-pile grey carpet squares laid with the pile turned every other way, a worn path down the middle, one bluer replacement tile and a corner that has started to curl up.' },
    'MOV-045': { f13: 'crim', live: 'Chasing aisle lights', note: 'Plush crimson cinema carpet with a gold diamond pattern. Two aisle strips run toward the screen, with little amber lights that chase forward like in a real theatre.' },
    'MOV-065': { f13: 'teak', live: 'Glowing guides', note: 'Long dark teak planks with soft grain and staggered joints, polished so the screen glow shows in them. Warm LED guide strips are set into both sides with a pulse of light running toward the screen, and the heated floor glows softly.' },
    'MOV-085': { f13: 'glass', live: 'Bass glow', note: 'Dark obsidian glass tiles with tiny stars underneath. Panels light up in waves of cyan, violet and pink with every bass hit.' },
    'MOV-020': { spec: 'rag13', live: 'Loose thread sways', note: 'An oval rag rug braided from strips of old fabric in red, mustard, denim, green, cream and plum. The edge is frayed, and one loose strand sticks out and sways.' },
    'MOV-040': { spec: 'film13', note: 'A long black nylon runner printed like a film strip: sprocket holes along both edges and eight frames telling a tiny story about a bouncing Squish, ending with THE END. A soft sheen slides across the nylon.' },
    'MOV-060': { spec: 'shag13', note: 'A thick charcoal shag rug with deep, floppy tufts that spill over the edges. It soaks up sound and light so the room stays dark and quiet.' },
    'MOV-080': { spec: 'deco13', live: 'Gold shimmer', note: 'A hand-tufted crimson rug with a carved gold Art Deco design: a sunburst medallion, stepped corners, fan motifs and chevrons. A soft shimmer runs across the gold.' },
    'MOV-100': { spec: 'cloud13', live: 'Self-cleaning sparkle', note: 'A cloud-shaped silk rug with quilted sound-soaking channels. Its pearly sheen shifts between pink and blue, and a sweep of sparkles keeps gliding across it to clean it.' },
  };
  const edit12 = RD.edit;
  RD.edit = rows => edit12(rows).map(r => RD.SET13[r.id] ? Object.assign({}, r, RD.SET13[r.id]) : r);
  RD.H13 = { px, quad, lineUV, crv, fblot, FL, slab, top, face, ellP, rrP, dP };
  RD.PLUS13 = 1;
})();
