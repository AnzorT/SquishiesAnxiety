// Renovation Catalog round 22 — Living Room furniture remodel, part 1: floor lamps, console tables, coffee tables, side tables (20 pieces).
// Built like the Movie Room furniture (plus16/17 toolkit RD.H16): real 3D solids with materials, glued details (par / fn), animated fx.
// Sets RenoDraw.PLUS22; catalog edits RD.SET22; toolkit RD.H22 {prism, R0, glue}.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS21 && RD.H16 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS22) return;
  const K = X.K, { box, cyl, ball, slab, slabX, arcW, disc, shade, mix, f1 } = K;
  const N = RD.N, PI = Math.PI, GOLD = '#e2b14a', CH = '#d5dde2', BR = '#d4a548';
  const { loft, tilt, tiltAll, rotF, rod, pipe, fxEll, frame, bobA, an, FONT, W_, M_, F_, PL, G_, em, rep } = RD.H16;
  const P2 = q => f1(q[0]) + ' ' + f1(q[1]), n4 = v => Math.round(v * 1e4) / 1e4;
  const R0 = s => { let h = 7; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) | 0; h = Math.abs(h) || 1; return () => { h = (h * 1103515245 + 12345) | 0; return ((h >>> 8) & 0xffff) / 65536; }; };
  const rp = (R, p, v) => { const q = R([v[0] - p[0], v[1] - p[1], v[2] - p[2]]); return [q[0] + p[0], q[1] + p[1], q[2] + p[2]]; };
  // glue helper: details lying on a part draw right after it (no sort), fn = local face normal (hides when that face turns away)
  const glue = o => (p, L, fn) => L.map(k => { k.par = p; if (fn) k.fn = fn; o.push(k); return k; });
  // prism: any (near-convex) floor outline [[x,z],...] extruded from y to y+h
  const prism = (poly, y, h, col, o) => { const n = poly.length, B = poly.map(([x, z]) => [x, y, z]), T = poly.map(([x, z]) => [x, y + h, z]), faces = []; let cx = 0, cz = 0; poly.forEach(p => { cx += p[0] / n; cz += p[1] / n; });
    for (let i = 0; i < n; i++) { const j = (i + 1) % n, dx = poly[j][0] - poly[i][0], dz = poly[j][1] - poly[i][1], L = Math.hypot(dx, dz) || 1; let nn = [dz / L, 0, -dx / L]; if (nn[0] * ((poly[i][0] + poly[j][0]) / 2 - cx) + nn[2] * ((poly[i][1] + poly[j][1]) / 2 - cz) < 0) nn = nn.map(v => -v); faces.push({ q: [B[i], B[j], T[j], T[i]], n: nn }); }
    faces.push({ q: B, n: [0, -1, 0], cap: 1 }, { q: T, n: [0, 1, 0], cap: 2 }); return Object.assign({ faces, pts: B.concat(T), col, cv: 1, zb: 0 }, o || {}); };
  const band = (x, y, z, r, h, col, o) => { const S = arcW(x, y, z, r, r, 0.2, h, 0, 2 * PI, col, Object.assign({ n: 30 }, o || {})); S.faces = S.faces.filter(F => { if (Math.abs(F.n[1]) > 0.5) return false; const m = F.q.reduce((a, q) => [a[0] + q[0] / F.q.length, a[1] + q[2] / F.q.length], [0, 0]); return F.n[0] * (m[0] - x) + F.n[2] * (m[1] - z) > 0; }); return S; };
  const RG = (id, c0, c1, o0) => '<radialGradient id="' + id + '"><stop offset="0" stop-color="' + c0 + '" stop-opacity="' + (o0 == null ? 0.9 : o0) + '"/><stop offset="1" stop-color="' + (c1 || c0) + '" stop-opacity="0"/></radialGradient>';
  const ell = (c, q, rx, ry, fill, extra, op) => '<ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="' + fill + '"' + (op != null ? ' opacity="' + op + '"' : '') + '>' + (extra || '') + '</ellipse>';
  const TOP = (c, y, x, z) => frame(c.p, [x || 0, y, z || 0], [1, 0, 0], [0, 0, 1]);
  const book = (x, y, z, w, h, d, col, yaw) => { yaw = yaw || 0; const s = Math.sin(yaw), c = Math.cos(yaw), B = box(x, y, z, w, h, d, col, PL({ r: 0.4, yaw })), P = box(x - s * (d / 2 + 0.03), y + 0.35, z + c * (d / 2 + 0.03), w - 1.2, h - 0.7, 0.06, '#f6f0e2', { r: 0, yaw, noOut: 1 }); P.par = B; P.fn = [-s, 0, c]; return [B, P]; };
  const mug = (o, x, y, z, col) => { o.push(cyl(x, y, z, 3.4, 7, col, { n: 14, mat: 'cer', rg: [[0, 0, 0.92], [7, 0, 1]] }), cyl(x, y + 6.7, z, 2.9, 0.3, '#5a3418', { n: 12, noOut: 1 })); pipe([[x + 3.1, y + 5.6, z], [x + 5.4, y + 5.2, z], [x + 5.4, y + 2.4, z], [x + 3.1, y + 2, z]], 0.55, col, { mat: 'cer', n: 5 }).forEach(s => o.push(s)); };
  const sprig = (o, x, y, z, R, col, n) => rep(n || 7, i => { const a = i * 2.4, r = 1.4 + R() * 2.2; o.push(ball(x + Math.cos(a) * r, y + R() * 3, z + Math.sin(a) * r, 1.8 + R(), col || (i % 2 ? '#6fae5a' : '#86c46a'), { sy: 1.4, k: 3, n: 8 })); });

  // ======================= LAMPS =======================
  // LIV-002 wobbly gooseneck torchiere, cracked shade (flickers)
  N.torch22 = S => { const ST = '#8a8f94', SD = shade(ST, 0.72), SH = '#eadcbe', piv = [7, 121, 7], TA = -0.22, RT = rotF([1, 0, 0], TA);
    return { w: 48, d: 44, glow: () => ({ y: 120, r: 72 }), anim: p => { const q = P2(p(0, 0, 0)), v = a => a + ' ' + q; return '<animateTransform attributeName="transform" type="rotate" values="' + [0, 1.2, 0, -0.9, 0.4, 0].map(v).join(';') + '" dur="5.5s" calcMode="spline" keyTimes="0;0.2;0.45;0.65;0.85;1" keySplines="0.4 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1" repeatCount="indefinite"/>'; }, build: () => { const o = [], on = glue(o);
      o.push(cyl(0, 0, 0, 13, 3, ST, M_({ n: 22, rg: [[0, 0, 1], [3, 0, 0.82]] })), cyl(0, 3, 0, 3.4, 2.4, SD, M_({ n: 10 })));
      const PO = pipe([[0, 5.4, 0], [0.8, 48, 0.4], [-1.3, 92, 0.6], [-0.6, 104, 1]], 1, ST, M_({ n: 8 })); PO.forEach(s => o.push(s));
      on(PO[1], [cyl(0.3, 60, 0.5, 1.6, 4.6, '#b9bec4', PL({ n: 8 }))]);
      const GN = pipe([[-0.6, 104, 1], [-0.2, 111, 2.4], [2.4, 117, 4.6], [5.6, 120.4, 6.4]], 1.35, '#6f7479', M_({ n: 8 })); on(PO[2], GN);
      on(GN[0], rep(3, i => cyl(-0.6 + i * 0.15, 105 + i * 2.2, 1 + i * 0.45, 1.75, 0.8, '#5c6166', M_({ n: 8, noOut: 1 })))); on(GN[1], [cyl(0.6, 113, 3.2, 1.75, 0.8, '#5c6166', M_({ n: 8, noOut: 1 })), cyl(1.6, 115.4, 4, 1.75, 0.8, '#5c6166', M_({ n: 8, noOut: 1 }))]);
      const SHD = on(GN[2], [tilt(cyl(7, 118, 7, 6, 13, SH, { n: 22, mat: 'pl', rg: [[0, 0, 0.45], [4, 0, 0.95], [13, 0, 2.25]] }), [1, 0, 0], TA, piv)])[0];
      const fnT = RT([0, 1, 0]), fnF = RT([0, 0, 1]);
      on(SHD, [tilt(band(7, 129.6, 7, 13.45, 1.4, '#d9b46a', { n: 24 }), [1, 0, 0], TA, piv), tilt(cyl(7, 131, 7, 12.2, 0.3, '#fff2c2', em({ n: 22 })), [1, 0, 0], TA, piv)], fnT);
      on(SHD, tiltAll(pipe([[8, 121.6, 12.9], [6, 124.4, 15.4], [8.4, 126.6, 17.6], [7.2, 129.4, 20]], 0.28, '#6a5a40', { n: 4, noOut: 1 }), [1, 0, 0], TA, piv), fnF);
      pipe([[0, 1, -12], [-6, 0.6, -18], [-14, 0.6, -20]], 0.7, '#3a3b40', PL({ n: 5 })).forEach(s => o.push(s)); o.push(box(-8, 0, -18.6, 3, 1.8, 5, '#f2efe6', PL({ r: 0.8, yaw: 0.5 })));
      return o; },
      fx: c => { const tc = c.p(...rp(rotF([1, 0, 0], -0.22), piv, [7, 131.4, 7])), k = c.k;
        return { defs: RG('q22tg', '#fff6cc', '#ffd27a', 0.95), front: ell(c, tc, 13 * k, 6 * k, 'url(#q22tg)', an('opacity', '0.75;0.95;0.35;0.9;0.6;0.95;0.2;0.85;0.75', 2.6), 0.8) }; } }; };

  // LIV-022 tripod wooden lamp with a linen drum
  N.tripod22 = S => { const WD = '#c08a52', LIN = '#f6ecd4';
    return { w: 60, d: 56, round: 1, glow: () => ({ y: 104, r: 80 }), build: () => { const o = [], on = glue(o);
      rep(3, i => { const t = PI / 2 + i * 2 * PI / 3, fx = Math.cos(t) * 24, fz = Math.sin(t) * 24, L = rod([fx, 0, fz], [Math.cos(t) * 4.5, 77.4, Math.sin(t) * 4.5], 1.5, WD, W_({ n: 8 })); o.push(L); on(L, [ball(fx, -0.6, fz, 1.9, shade(WD, 0.7), { k: 3, n: 8, sy: 0.6, shine: 0 })]); });
      o.push(cyl(0, 78, 0, 5.6, 7, BR, M_({ n: 14, rg: [[0, 0, 1], [7, 0, 0.6]] })), rod([0, 85, 0], [0, 93, 0], 0.8, BR, M_({ n: 6 })));
      const SH = cyl(0, 93, 0, 19, 22, LIN, em({ n: 30, noOut: 0, mat: 'fab' })); o.push(SH);
      on(SH, [cyl(0, 115, 0, 18.2, 0.25, '#f8d98a', em({ n: 26 }))], [0, 1, 0]);
      on(SH, [rod([0, 93.6, 19.1], [0, 114.4, 19.1], 0.25, '#ddcca8', { n: 4, noOut: 1 })], [0, 0, 1]);
      on(SH, [band(0, 93, 0, 19.15, 1.4, '#cbb690'), band(0, 113.6, 0, 19.15, 1.4, '#cbb690')]);
      on(SH, [rod([9, 92.6, 6], [9, 85, 6], 0.25, BR, M_({ n: 4, noOut: 1 })), ball(9, 83.6, 6, 1, BR, M_({ k: 3, n: 8 }))]);
      pipe([[-24, 0.6, -16], [-28, 0.6, -21], [-34, 0.6, -24]], 0.6, '#3a3b40', PL({ n: 5 })).forEach(s => o.push(s));
      return o; },
      fx: c => ({ defs: RG('q22wg', '#fff3cf', '#ffcf7a', 0.5), under: fxEll(c, 0, 0.2, 0, 34, 'url(#q22wg)') }) }; };

  // LIV-042 mid-century chrome arc lamp on a marble block
  N.arc22 = S => { const MB = '#f4f1ec', BX = -40, BZ = -8, DX = 30, DZ = 8, DY = 92;
    const bez = t => { const P = [[BX, 12, BZ], [BX, 156, BZ], [DX, 158, DZ], [DX, DY + 14, DZ]], u = 1 - t; return [0, 1, 2].map(k => u * u * u * P[0][k] + 3 * u * u * t * P[1][k] + 3 * u * t * t * P[2][k] + t * t * t * P[3][k]); };
    return { w: 100, d: 48, glow: () => ({ y: 96, r: 86 }), build: () => { const o = [], on = glue(o);
      const BS = box(BX, 0, BZ, 26, 11, 26, MB, { r: 2.6, mat: 'cer', bev: 1.2 }); o.push(BS);
      on(BS, [rod([BX - 9, 11.05, BZ - 6], [BX + 2, 11.05, BZ + 4], 0.22, '#b9b2a6', { n: 4, noOut: 1 }), rod([BX + 2, 11.05, BZ + 4], [BX + 10, 11.05, BZ + 1], 0.18, '#c4beb2', { n: 4, noOut: 1 })], [0, 1, 0]);
      o.push(cyl(BX, 11, BZ, 2.8, 3.4, CH, M_({ n: 12 })));
      pipe(rep(13, i => bez(i / 12)), 1.3, CH, M_({ n: 8 })).forEach(s => o.push(s));
      const DM = cyl(DX, DY, DZ, 14, 14, CH, M_({ n: 26, shine: 1, rg: [[0, 0, 1], [4, 0, 0.96], [8, 0, 0.8], [11, 0, 0.55], [13, 0, 0.25], [14, 0, 0.08]] })); o.push(DM);
      on(DM, [cyl(DX, DY - 0.5, DZ, 13.4, 0.5, '#fff1c0', em({ n: 26 }))]);
      o.push(ball(BX + 1.3, 40, BZ, 2, '#2a2b30', { k: 3, n: 8 }));
      pipe([[BX, 1, BZ - 13], [BX - 6, 0.6, BZ - 18], [BX - 8, 0.6, BZ - 24]], 0.6, '#3a3b40', PL({ n: 5 })).forEach(s => o.push(s));
      return o; },
      fx: c => { const a = c.p(DX - 13, DY - 0.5, DZ), b = c.p(DX + 13, DY - 0.5, DZ), fl = c.p(DX, 0, DZ), k = c.k;
        return { defs: '<linearGradient id="q22ac" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff4cc" stop-opacity="0.5"/><stop offset="1" stop-color="#fff4cc" stop-opacity="0"/></linearGradient>' + RG('q22ap', '#fff1c4', '#ffd27a', 0.55),
          under: fxEll(c, DX, 0.2, DZ, 30, 'url(#q22ap)'), front: '<path d="M' + P2(a) + 'L' + f1(fl[0] - 30 * k) + ' ' + f1(fl[1] - 6 * k) + 'H' + f1(fl[0] + 30 * k) + 'L' + P2(b) + 'Z" fill="url(#q22ac)" opacity="0.7"/>' }; } }; };

  // LIV-062 sculptural alabaster totem (stones glow and breathe)
  const ST62 = [[11, 15, 0.6], [13.5, 19, -1], [9, 13, 1.2], [12, 21, 0], [8, 12, -0.6], [10.5, 17, 0.5]];
  N.alab22 = S => { const BRZ = '#7a5534', AL = ['#fbe8c8', '#f7dcb6', '#fdeed6'];
    const lay = () => { let y = 4.6; return ST62.map(([r, h, dx], i) => { const s = { r, h, dx, y }; y += h + 2.4; return s; }); };
    return { w: 40, d: 40, round: 1, glow: () => ({ y: 70, r: 78 }), build: () => { const o = [];
      o.push(cyl(0, 0, 0, 14, 4.6, BRZ, M_({ n: 24, rg: [[0, 0, 1], [4.6, 0, 0.9]] })));
      lay().forEach((s, i) => { o.push(cyl(s.dx, s.y, 0, s.r, s.h, AL[i % 3], em({ n: 24, noOut: 0, mat: 'cer', rz: s.r * 0.86, rg: [[0, 0, 0.5], [s.h * 0.18, 0, 0.9], [s.h * 0.5, 0, 1], [s.h * 0.82, 0, 0.9], [s.h, 0, 0.5]] })));
        o.push(cyl(s.dx * 0.5, s.y + s.h, 0, 3.4, 2.4, BRZ, M_({ n: 12 }))); });
      return o; },
      fx: c => { const k = c.k; let f = ''; lay().forEach((s, i) => { const q = c.p(s.dx, s.y + s.h / 2, 0); f += ell(c, q, s.r * 0.8 * k, s.h * 0.42 * k, 'url(#q22al)', an('opacity', '0.25;0.85;0.25', 4.2, n4(-i * 0.7)), 0.5); });
        return { defs: RG('q22al', '#ffffff', '#ffe2b0', 0.9), front: f }; } }; };

  // LIV-082 bioluminescent living-plant tower (vine glows, spores rise, light pulse climbs the vine)
  N.bio22 = S => { const POT = '#2b3436', hel = t => { const a = t * 4.2 * PI; return [Math.cos(a) * 6, 19 + t * 90, Math.sin(a) * 6]; };
    return { w: 40, d: 40, round: 1, glow: () => ({ y: 64, r: 80, c: 'url(#gNeon)' }), build: () => { const o = [], on = glue(o), R = R0('bio');
      const PT = cyl(0, 0, 0, 15, 16, POT, { n: 26, mat: 'cer', rg: [[0, 0, 0.8], [16, 0, 1]] }); o.push(PT);
      on(PT, [cyl(0, 16, 0, 14.3, 1.2, '#38c98a', em({ n: 24 }))], [0, 1, 0]);
      const V = rep(25, i => hel(i / 24)), back = [], front = [];
      for (let i = 0; i < 24; i++) (V[i][2] + V[i + 1][2] < 0 ? back : front).push(rod(V[i], V[i + 1], 0.75, '#1f6b4a', { n: 5 }));
      const LV = rep(16, i => { const t = (i + 0.5) / 16, p = hel(t), a = t * 4.2 * PI; return ball(p[0] + Math.cos(a) * 2.2, p[1], p[2] + Math.sin(a) * 2.2, 2.2, i % 2 ? '#62f2c4' : '#9affdc', em({ sx: 1.5, sy: 0.55, k: 3, n: 8, yaw: -a })); });
      const MU = [[0.22, '#7fd8ff'], [0.55, '#b48cff'], [0.82, '#7fd8ff']].map(([t, col]) => { const p = hel(t); return cyl(p[0] * 1.3, p[1], p[2] * 1.3, 2.6, 2.2, col, em({ n: 12, rg: [[0, 0, 1], [1.4, 0, 0.8], [2.2, 0, 0.2]] })); });
      on(PT, back.concat(LV.filter((s, i) => Math.sin((i + 0.5) / 16 * 4.2 * PI) < 0), front, LV.filter((s, i) => Math.sin((i + 0.5) / 16 * 4.2 * PI) >= 0), MU));
      on(PT, [cyl(0, 17.2, 0, 10.6, 96, '#d8fbff', { n: 24, op: 0.2, shine: 1 })]);
      on(PT, [cyl(0, 113.2, 0, 11.6, 3, BR, M_({ n: 24 })), cyl(0, 116.2, 0, 7, 0.6, '#9affe8', em({ n: 18 }))]);
      return o; },
      fx: c => { const R = R0('spore'), k = c.k; let f = '';
        rep(9, i => { const x = (R() - 0.5) * 12, z = (R() - 0.5) * 10, a = c.p(x, 22, z), b = c.p(x, 108, z), d = n4(5 + R() * 3), bg = n4(-R() * 6); f += '<circle cx="' + f1(a[0]) + '" cy="' + f1(a[1]) + '" r="' + f1(0.9 * k) + '" fill="#c8fff2" opacity="0">' + an('cy', f1(a[1]) + ';' + f1(b[1]), d, bg) + an('opacity', '0;0.9;0.9;0', d, bg) + '</circle>'; });
        const path = 'M' + rep(25, i => P2(c.p(...hel(i / 24)))).join('L');
        f += '<circle r="' + f1(2.4 * k) + '" fill="#e8fff8" opacity="0.9"><animateMotion path="' + path + '" dur="3.6s" repeatCount="indefinite"/>' + an('opacity', '0;1;1;0', 3.6) + '</circle>';
        return { front: f }; } }; };

  // ======================= CONSOLE TABLES =======================
  // LIV-003 rough plywood top on two sawhorse trestles
  N.trestle22 = S => { const PLY = '#dcbd8c', PD = shade(PLY, 0.74), PN = '#c9a06a', W = 124, Dp = 34, TY = 48;
    return { w: W + 4, d: Dp + 6, topH: TY + 2.2, topW: 70, build: () => { const o = [], on = glue(o), R = R0('ply');
      [-44, 44].forEach(x => { o.push(box(x, TY - 4, 0, 6, 4, Dp - 6, PN, W_({ r: 0.6 })));
        [-1, 1].forEach(sx => [-1, 1].forEach(sz => o.push(rod([x + sx * 2.2, TY - 4.5, sz * 11], [x + sx * 7.5, 0, sz * 14], 1.4, shade(PN, 0.92), W_({ n: 6 })))));
        [-1, 1].forEach(sx => o.push(rod([x + sx * 5.2, 14, -13], [x + sx * 5.2, 14, 13], 0.9, shade(PN, 0.84), W_({ n: 5 })))); });
      const TP = box(0, TY, 0, W, 2.2, Dp, PLY, W_({ r: 0.5, yaw: 0.02 })); o.push(TP);
      on(TP, [0.7, 1.45].map(y => slabX(0, TY + y, Dp / 2 + 0.9, W - 4, 0.3, 0.3, PD, { r: 0, noOut: 1, yaw: 0.02 })), [0, 0, 1]);
      on(TP, [cyl(20, TY + 2.22, 6, 4, 0.05, '#8a5a30', { n: 16, noOut: 1, op: 0.3 }), cyl(26, TY + 2.22, -3, 3.6, 0.05, '#8a5a30', { n: 16, noOut: 1, op: 0.25 }), box(-30, TY + 2.22, -6, 9, 0.05, 6, '#f2e27a', { r: 0.2, noOut: 1, yaw: 0.3 })], [0, 1, 0]);
      mug(o, 40, TY + 2.2, 4, '#e86f5a');
      [['#f4efe4', 0.1], ['#bcd4f0', -0.12], ['#f4c9c9', 0.22]].forEach(([col, y], i) => o.push(box(-40 + i * 0.8, TY + 2.2 + i * 0.6, 4, 16, 0.6, 10, col, PL({ r: 0.2, yaw: y }))));
      o.push(arcW(-22, TY + 2.2, 8, 2, 2, 0.5, 0.5, 0, 2 * PI, CH, M_({ n: 10 })), box(-18.6, TY + 2.2, 9.4, 4.6, 0.5, 1.6, '#c9a14a', M_({ r: 0.3, yaw: 0.4 })));
      return o; } }; };

  // LIV-023 slim black iron + glass entry console
  N.iron22 = S => { const IR = '#25262a', GL = '#cfe6ee', W = 118, Dp = 28, H = 56;
    return { w: W + 4, d: Dp + 4, topH: H + 1.2, topW: 66, build: () => { const o = [];
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => o.push(box(sx * (W / 2 - 1), 0, sz * (Dp / 2 - 1), 1.8, H, 1.8, IR, M_({ r: 0.3 }))));
      [H - 2, 11].forEach(y => { [-1, 1].forEach(sz => o.push(slabX(0, y, sz * (Dp / 2 - 1), W - 3.6, 1.8, 1.4, IR, M_({ r: 0.3 })))); [-1, 1].forEach(sx => o.push(box(sx * (W / 2 - 1), y, 0, 1.4, 1.8, Dp - 3.6, IR, M_({ r: 0.3 })))); });
      o.push(box(0, 12.8, 0, W - 4, 0.9, Dp - 4, GL, { r: 0.8, op: 0.42, shine: 1 }), box(0, H, 0, W + 2, 1.2, Dp + 2, GL, { r: 1, op: 0.45, shine: 1 }));
      const BK = cyl(-30, 13.7, 0, 9, 9, '#c9a06a', F_({ n: 20, soft: 0, rg: [[0, 0, 0.9], [9, 0, 1]] })); o.push(BK);
      glue(o)(BK, [band(-30, 18, 0, 9.05, 1.4, '#8a6440'), band(-30, 21.6, 0, 9.05, 1, '#8a6440')]);
      [['#2f5a8a', 0], ['#e0b04c', 0.1], ['#c4643a', -0.08]].forEach(([col, y], i) => book(26, 13.7 + i * 2.6, 0, 22, 2.6, 15, col, y).forEach(s => o.push(s)));
      o.push(box(28, H + 1.2, 0, 20, 0.9, 11, BR, M_({ r: 1.2 })), arcW(25, H + 2.1, 0, 1.8, 1.8, 0.45, 0.45, 0, 2 * PI, CH, M_({ n: 10 })), box(28.6, H + 2.1, 1.4, 4.4, 0.5, 1.4, '#c9a14a', M_({ r: 0.3, yaw: 0.6 })));
      o.push(cyl(-34, H + 1.2, -2, 4.2, 6, '#f2efe8', { n: 16, mat: 'cer', rg: [[0, 0, 0.8], [6, 0, 1]] })); sprig(o, -34, H + 7, -2, R0('suc'), null, 6);
      return o; } }; };

  // LIV-043 cane-front rattan + teak credenza
  N.rattan22 = S => { const TK = '#a8683a', TL = shade(TK, 1.14), TD = shade(TK, 0.74), CANE = '#dcb47a', W = 132, Dp = 36, BY = 14, BH = 40;
    return { w: W + 6, d: Dp + 6, topH: BY + BH + 2.4, topW: 76, build: () => { const o = [], on = glue(o);
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => o.push(cyl(sx * (W / 2 - 6), 0, sz * (Dp / 2 - 5), 2.6, BY, TD, W_({ n: 10, rg: [[0, 0, 0.6], [BY, 0, 1]] }))));
      const BD = box(0, BY, 0, W, BH, Dp, TK, W_({ r: 1.4 })); o.push(BD);
      o.push(box(0, BY + BH, 0, W + 2, 2.4, Dp + 2, TL, W_({ r: 1.2 })));
      [-43, 43].forEach(x => { const FR = on(BD, [box(x, BY + 3, Dp / 2 + 0.05, 42, BH - 6, 0.8, TD, W_({ r: 0.5 }))], [0, 0, 1])[0];
        const CN = on(FR, [box(x, BY + 5.4, Dp / 2 + 0.85, 36.4, BH - 10.8, 0.3, CANE, { r: 0.3, mat: 'fab' })], [0, 0, 1])[0];
        const hw = 18.2, hh = (BH - 10.8) / 2, cy = BY + 5.4 + hh, zf = Dp / 2 + 1.25, L = [];
        for (let k = -hw - hh; k <= hw + hh; k += 3.4) [1, -1].forEach(sg => { // diagonal cane strands v = sg (u - k), clipped to the panel
          const u0 = Math.max(-hw, k - hh), u1 = Math.min(hw, k + hh); if (u1 - u0 < 1) return;
          L.push(rod([x + u0, cy + sg * (u0 - k), zf], [x + u1, cy + sg * (u1 - k), zf], 0.24, shade(CANE, 0.72), { n: 4, noOut: 1 })); });
        on(CN, L, [0, 0, 1]); on(FR, [box(x + (x < 0 ? 18 : -18), BY + 18, Dp / 2 + 0.85, 1.2, 6, 0.8, BR, M_({ r: 0.4 }))], [0, 0, 1]); });
      rep(3, i => { const DR = on(BD, [box(0, BY + 3 + i * 11.4, Dp / 2 + 0.05, 40, 10.4, 0.8, TL, W_({ r: 0.4 }))], [0, 0, 1])[0]; on(DR, [slabX(0, BY + 7.6 + i * 11.4, Dp / 2 + 1.25, 10, 1.2, 0.8, BR, M_({ r: 0.4 }))], [0, 0, 1]); });
      const TY = BY + BH + 2.4, VS = cyl(-44, TY, -4, 5.6, 16, '#efe7da', { n: 18, mat: 'cer', rg: [[0, 0, 0.8], [8, 0, 1], [14, 0, 0.5], [16, 0, 0.6]] }); o.push(VS);
      rep(5, i => { const a = -0.5 + i * 0.25, tp = [-44 + Math.sin(a) * 18, TY + 38 + Math.cos(i) * 3, -4 + (i % 2 ? 3 : -3)]; on(VS, [rod([-44, TY + 14, -4], tp, 0.35, '#c9b48a', { n: 4 }), ball(tp[0], tp[1] - 2, tp[2], 3.6, '#efe2c4', F_({ sy: 2, sx: 0.8, k: 4, n: 10, shine: 0 }))]); });
      [['#2f4f5a', 0.05], ['#e8dcc4', -0.06], ['#b44a3a', 0.12]].forEach(([col, y], i) => book(40, TY + i * 3, 2, 24, 3, 17, col, y).forEach(s => o.push(s)));
      return o; } }; };

  // LIV-063 burl wood + lacquered brass gallery console
  N.burl22 = S => { const BU = '#a2653a', W = 124, Dp = 34, TY = 52;
    return { w: W + 4, d: Dp + 4, topH: TY + 4, topW: 70, build: () => { const o = [], on = glue(o), R = R0('burl');
      [-52, 52].forEach(x => { [-1, 1].forEach(sz => o.push(box(x, 2.4, sz * 13, 2.6, TY - 2.4, 2.6, BR, M_({ r: 0.6, shine: 1 })))); o.push(box(x, 0, 0, 3, 2.4, 30, BR, M_({ r: 0.6, shine: 1 })), box(x, TY - 3, 0, 2.6, 2.4, 24, BR, M_({ r: 0.5 }))); });
      o.push(slabX(0, 9, -13, 101, 2, 2, BR, M_({ r: 0.5, shine: 1 })));
      const TP = box(0, TY, 0, W, 4, Dp, BU, W_({ r: 2, bev: 1.2 })); o.push(TP);
      on(TP, rep(22, i => { const x = (R() - 0.5) * (W - 14), z = (R() - 0.5) * (Dp - 8), s = 1.4 + R() * 2.6; return cyl(x, TY + 4.02, z, s * 1.4, 0.08, ['#6e3a1c', '#c98c56', '#7f4724', '#b57540'][i % 4], { n: 10, rz: s, noOut: 1, op: 0.7 }); }), [0, 1, 0]);
      on(TP, [slabX(0, TY + 1, Dp / 2 + 0.05, W - 4, 1.4, 0.3, BR, M_({ r: 0, noOut: 1 }))], [0, 0, 1]);
      o.push(rod([-56, TY + 9.6, -15], [56, TY + 9.6, -15], 0.6, BR, M_({ n: 6 }))); rep(5, i => o.push(rod([-56 + i * 28, TY + 4, -15], [-56 + i * 28, TY + 9.6, -15], 0.45, BR, M_({ n: 5 }))));
      o.push(cyl(-34, TY + 4, 2, 9, 4.6, BR, M_({ n: 20, shine: 1, rg: [[0, 0, 0.5], [2.4, 0, 0.9], [4.6, 0, 1]] })));
      rep(4, i => o.push(ball(-34 + (i % 2 ? 3 : -3), TY + 7, 2 + (i > 1 ? 2.6 : -2.6), 2.6, ['#e0b04c', '#d9663a', '#e86fa8', '#4f9a4a'][i], { k: 4, n: 10 })));
      o.push(cyl(36, TY + 4, -2, 3, 3, '#2a2b30', { n: 12 }), ball(36, TY + 7, -2, 7, '#e9e3d8', { k: 5, n: 16, mat: 'cer' }));
      [['#1f3a4a', 0], ['#e0d4b8', 0.08]].forEach(([col, y], i) => book(10, TY + 4 + i * 3.2, 4, 26, 3.2, 18, col, y).forEach(s => o.push(s)));
      return o; } }; };

  // LIV-083 sculpted liquid-metal parametric console (mirror chrome, drips, ripples)
  N.liquid22 = S => { const W = 120, Dp = 32, TY = 46;
    const leg = sx => [loft([[0, sx * 36, 0, 15, 10], [2.4, sx * 36, 0, 14, 9.4], [5, sx * 35, 0, 9, 6.4]], CH, { n: 22, shine: 1, mat: 'metal' }),
      loft([[5, sx * 35, 0, 8.4, 6], [16, sx * 31.6, 1, 4.4, 3.6], [28, sx * 30.6, 0, 3.8, 3.2]], CH, { n: 18, shine: 1, mat: 'metal' }),
      loft([[28, sx * 30.6, 0, 3.8, 3.2], [37, sx * 33, -1, 7, 5], [43, sx * 36, 0, 13, 8.6], [46, sx * 37, 0, 16, 10.4]], CH, { n: 22, shine: 1, mat: 'metal' })];
    return { w: W + 4, d: Dp + 6, topH: TY + 4.6, topW: 66, build: () => { const o = [];
      leg(-1).concat(leg(1)).forEach(s => o.push(s));
      o.push(box(0, TY, 0, W, 4.6, Dp, CH, { r: 14, shine: 1, mat: 'metal', bev: 2 }));
      o.push(cyl(14, 0, 18, 5.4, 0.4, CH, { n: 16, rz: 3, shine: 1, mat: 'metal' }), cyl(-48, 0, 12, 3, 0.3, CH, { n: 12, rz: 1.8, shine: 1, mat: 'metal' }));
      o.push(ball(-20, TY + 4.6, -4, 6, '#2a2b30', { k: 5, n: 16, sy: 1.1 }), ball(24, TY + 4.6, -6, 3.6, CH, { k: 4, n: 12, sy: 1.6, mat: 'metal' }));
      return o; },
      fx: c => { const k = c.k, a = c.p(14, TY + 0.4, 17.4), b = c.p(14, 0.6, 18), M = TOP(c, TY + 4.62);
        let f = '<g transform="' + M + '"><g clip-path="url(#q22lc)"><rect x="-80" y="-18" width="22" height="36" fill="url(#q22ls)" transform="skewX(-25)">' + an('x', '-80;80', 4.2) + '</rect>'
          + rep(2, i => '<ellipse cx="6" cy="2" rx="1" ry="1" fill="none" stroke="#ffffff" stroke-width="0.4" opacity="0">' + an('rx', '1;14', 3, -i * 1.5) + an('ry', '1;9', 3, -i * 1.5) + an('opacity', '0.8;0', 3, -i * 1.5) + '</ellipse>').join('') + '</g></g>';
        f += '<ellipse cx="' + f1(a[0]) + '" cy="' + f1(a[1]) + '" rx="' + f1(1 * k) + '" ry="' + f1(1.4 * k) + '" fill="' + CH + '" stroke="#8a949c" stroke-width="0.3" opacity="0">' + an('cy', f1(a[1]) + ';' + f1(a[1]) + ';' + f1(b[1]), 3.2) + an('opacity', '0;1;1;0', 3.2) + '</ellipse>';
        f += ell(c, b, 1, 1, 'none', an('rx', f1(1 * k) + ';' + f1(1 * k) + ';' + f1(7 * k), 3.2) + an('ry', f1(0.5 * k) + ';' + f1(0.5 * k) + ';' + f1(3 * k), 3.2) + an('opacity', '0;0;0.8;0', 3.2)).replace('fill="none"', 'fill="none" stroke="#ffffff" stroke-width="0.5"');
        return { defs: '<clipPath id="q22lc"><rect x="-60" y="-16" width="120" height="32" rx="14"/></clipPath><linearGradient id="q22ls" x1="0" x2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.6"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>', front: f }; } }; };

  // ======================= COFFEE TABLES =======================
  // LIV-016 cable-spool coffee table
  N.spool22 = S => { const PLY = '#d6ae78', DR = '#b98a58', R = 46, TY = 28;
    return { w: 2 * R + 4, d: 2 * R + 4, round: 1, topH: TY + 5, topW: 50, build: () => { const o = [], on = glue(o);
      o.push(cyl(0, 0, 0, R - 2, 5, PLY, W_({ n: 30 })));
      const DM = cyl(0, 5, 0, 17, TY - 5, DR, W_({ n: 22 })); o.push(DM);
      on(DM, [9, 13.4, 17.8].map(y => band(0, y, 0, 17.5, 4, '#2a2a2e', PL({ n: 24 }))));
      const TP = cyl(0, TY, 0, R, 5, PLY, W_({ n: 34 })); o.push(TP);
      on(TP, [cyl(0, TY + 5.02, 0, 6, 0.1, '#5a3a1a', { n: 16, noOut: 1 })].concat(rep(8, i => { const a = i * PI / 4 + 0.2; return cyl(Math.cos(a) * 30, TY + 5.02, Math.sin(a) * 30, 1.6, 0.6, '#8a8f94', M_({ n: 8 })); })), [0, 1, 0]);
      on(TP, rep(3, i => band(0, TY + 1.2 + i * 1.3, 0, R + 0.05, 0.25, shade(PLY, 0.74), { n: 34, noOut: 1 })));
      o.push(cyl(26, TY + 5, -18, 5, 0.6, '#c9a87a', { n: 14 })); mug(o, 26, TY + 5.6, -18, '#3f7fc8');
      return o; },
      fx: c => ({ front: '<g transform="' + TOP(c, TY + 5.04) + '" opacity="0.5"><text x="0" y="33" text-anchor="middle" ' + FONT + ' font-size="5.4" fill="#5a3a1a" letter-spacing="1.2">SQUISH CABLE CO.</text><text x="-24" y="-24" text-anchor="middle" ' + FONT + ' font-size="4" fill="#5a3a1a" transform="rotate(-30 -24 -24)">REEL 07</text></g>' }) }; };

  // LIV-036 two-tier pine + hairpin-leg coffee table
  N.hairpin22 = S => { const PN = '#e2b57e', BK = '#232428', W = 104, Dp = 52, TY = 32;
    return { w: W + 4, d: Dp + 4, topH: TY + 3, topW: 60, build: () => { const o = [], R = R0('hp');
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => { const x = sx * (W / 2 - 8), z = sz * (Dp / 2 - 7); o.push(rod([x - 2.4, TY, z], [x, 0.6, z], 0.55, BK, M_({ n: 6 })), rod([x + 2.4, TY, z], [x, 0.6, z], 0.55, BK, M_({ n: 6 })), ball(x, 0, z, 0.9, BK, M_({ k: 2, n: 6 }))); });
      o.push(box(0, 10, 0, W - 24, 2.4, Dp - 17, shade(PN, 0.95), W_({ r: 1.2 })), box(0, TY, 0, W, 3, Dp, PN, W_({ r: 2, bev: 0.8 })));
      [['#e86f5a', 0.1], ['#3f7fc8', -0.15], ['#f2e27a', 0.3]].forEach(([col, y], i) => o.push(box(-26 + i, 12.4 + i * 0.8, 2, 22, 0.8, 16, col, PL({ r: 0.2, yaw: y }))));
      o.push(cyl(24, 12.4, 0, 10, 8, '#c9a06a', F_({ n: 20, soft: 0, rg: [[0, 0, 0.88], [8, 0, 1]] })));
      rep(3, i => o.push(ball(21 + i * 3, 19.4, -1 + (i % 2) * 2, 3.4, ['#f2ead8', '#9cbf8a', '#e0b04c'][i], F_({ k: 4, n: 10, shine: 0, sy: 0.8 }))));
      o.push(cyl(34, TY + 3, -12, 5, 7, '#d86a4a', { n: 16, mat: 'cer', rg: [[0, 0, 0.8], [7, 0, 1]] })); sprig(o, 34, TY + 10, -12, R, null, 8);
      [[-30, 10], [-20, 14]].forEach(([x, z]) => o.push(cyl(x, TY + 3, z, 4, 0.6, '#3a3b40', { n: 14 })));
      return o; } }; };

  // LIV-056 live-edge walnut slab on black steel frames
  N.live22 = S => { const WAL = '#6e4226', SAP = '#d9b07c', ST = '#232428', TY = 26.4;
    const outl = (a, b, g) => rep(32, i => { const t = i / 32 * 2 * PI, c = Math.cos(t), s = Math.sin(t), ex = 0.32, w = 1 + g * (0.05 * Math.sin(5 * t + 1) + 0.03 * Math.sin(9 * t + 2)) * Math.abs(s);
      return [a * Math.sign(c) * Math.pow(Math.abs(c), ex), b * w * Math.sign(s) * Math.pow(Math.abs(s), 0.8)]; });
    return { w: 118, d: 62, topH: TY + 4, topW: 60, build: () => { const o = [], on = glue(o);
      [-40, 40].forEach(x => { [-1, 1].forEach(sz => o.push(box(x, 2.4, sz * 20, 3, TY - 4.8, 3, ST, M_({ r: 0.5 })))); o.push(box(x, 0, 0, 3, 2.4, 44, ST, M_({ r: 0.5 })), box(x, TY - 2.4, 0, 3, 2.4, 44, ST, M_({ r: 0.5 }))); });
      const SW = prism(outl(57, 28, 1), TY, 3, SAP, W_({})); o.push(SW);
      const HW = on(SW, [prism(outl(55, 24.5, 1.4), TY + 3, 1, WAL, W_({}))], [0, 1, 0])[0];
      on(HW, [-1, 1].map(s => box(-12 + s * 1.5, TY + 4.02, 6, 3.2, 0.1, 2.4, '#2e1a0c', { r: 0.2, yaw: s * 0.5, noOut: 1 })), [0, 1, 0]);
      o.push(cyl(26, TY + 4, -4, 9, 4.4, '#8a5a34', W_({ n: 20, rg: [[0, 0, 0.55], [2, 0, 0.88], [4.4, 0, 1]] })));
      rep(3, i => o.push(ball(23 + i * 3, TY + 7.4, -5 + (i % 2) * 2.6, 3, ['#5f9a4a', '#7fb25a', '#4f8a3e'][i], F_({ k: 4, n: 10, shine: 0 }))));
      o.push(cyl(-30, TY + 4, -6, 3, 6, '#f2efe8', { n: 14, mat: 'cer', rg: [[0, 0, 0.8], [6, 0, 1]] }), cyl(-30, TY + 9.7, -6, 2.5, 0.3, '#5a3418', { n: 12, noOut: 1 }));
      return o; },
      fx: c => ({ front: '<g transform="' + TOP(c, TY + 4.03) + '" opacity="0.55"><path d="M-12 26Q-13 18 -11.5 10T-12 7.4M-12 4.6Q-11 0 -14 -6" stroke="#22120a" stroke-width="0.5" fill="none" stroke-linecap="round"/></g>' }) }; };

  // LIV-076 nesting travertine + smoked bronze drums
  N.drum22 = S => { const TV = '#eadcc2', TVD = '#d4c09c', BZ = '#4e3e32';
    return { w: 98, d: 76, topH: 30, topZ: -4, topW: 40, build: () => { const o = [], on = glue(o), R = R0('trav');
      const T = cyl(-12, 0, -6, 30, 30, TV, { n: 34, mat: 'cer' }); o.push(T);
      on(T, [9.5, 21].map(y => band(-12, y, -6, 30.05, 0.6, mix(TV, TVD, 0.55), { n: 34, noOut: 1 })));
      on(T, rep(18, () => { const a = R() * 2 * PI, r = Math.sqrt(R()) * 26; return cyl(-12 + Math.cos(a) * r, 30.02, -6 + Math.sin(a) * r, 0.5 + R() * 0.9, 0.05, '#c7b28c', { n: 8, rz: 0.4 + R() * 0.5, noOut: 1 }); }), [0, 1, 0]);
      const B = cyl(32, 0, 16, 17, 21, BZ, M_({ n: 28, shine: 1 })); o.push(B);
      on(B, [band(32, 20.2, 16, 17.05, 0.8, BR, M_({ n: 28 }))]);
      o.push(cyl(32, 21, 16, 7, 4, '#f2efe8', { n: 18, mat: 'cer', rg: [[0, 0, 0.5], [2, 0, 0.9], [4, 0, 1]] }));
      book(-28, 30, 4, 22, 2.6, 16, '#2f4f5a', 0.2).forEach(s => o.push(s)); o.push(ball(-28, 32.6, 4, 2.6, BR, M_({ k: 3, n: 10, sy: 0.6 })));
      return o; } }; };

  // LIV-096 interactive koi-pond holographic glass coffee table (koi swim, ripples, lily pads)
  N.koi22 = S => { const W = 110, Dp = 60, TY = 26;
    return { w: W + 4, d: Dp + 4, topH: TY + 2, topW: 60, build: () => { const o = [], on = glue(o), R = R0('koi');
      const PL0 = box(0, 0, 0, W - 8, 4, Dp - 8, '#2e3338', { r: 2, mat: 'cer' }); o.push(PL0);
      on(PL0, rep(26, i => ball((R() - 0.5) * (W - 20), 4, (R() - 0.5) * (Dp - 18), 1.6 + R() * 1.6, ['#8a8478', '#b8ae9a', '#5e5a54'][i % 3], { k: 3, n: 8, sy: 0.6, shine: 0 })));
      on(PL0, [box(0, 4, 0, W - 4, TY - 4, Dp - 4, '#1f7088', { r: 3, op: 0.55 })]);
      on(PL0, [box(0, TY, 0, W, 2, Dp, '#d6f4fa', { r: 3, op: 0.3, shine: 1 })]);
      on(PL0, [slabX(0, TY - 0.4, Dp / 2 + 0.1, W - 2, 2.4, 0.6, '#2a2d34', M_({ r: 0.4 })), box(W / 2 + 0.1, TY - 0.4, 0, 0.6, 2.4, Dp - 2, '#2a2d34', M_({ r: 0.4 }))]);
      return o; },
      fx: c => { const M = TOP(c, TY - 1);
        const fish = (col, spot, s) => '<g transform="scale(' + s + ')"><path d="M7 0C5 -3 -2 -3.2 -5 -1L-10 -3.4L-8.6 0L-10 3.4L-5 1C-2 3.2 5 3 7 0Z" fill="' + col + '" stroke="#ffffff" stroke-opacity="0.5" stroke-width="0.4"><animateTransform attributeName="transform" type="skewY" values="-6;6;-6" dur="0.9s" repeatCount="indefinite"/></path><ellipse cx="1" cy="-0.6" rx="2.6" ry="1.4" fill="' + spot + '"/><path d="M1 -2.6L-1 -5L-2 -2.2Z" fill="' + col + '" opacity="0.8"/></g>';
        const swim = (path, d, b, body) => '<g opacity="0.92">' + body + '<animateMotion path="' + path + '" dur="' + d + 's" begin="' + b + 's" rotate="auto" repeatCount="indefinite"/></g>';
        let f = '<g transform="' + M + '"><g clip-path="url(#q22kc)"><rect x="-52" y="-28" width="104" height="56" fill="url(#q22kw)" opacity="0.5"><animate attributeName="opacity" values="0.3;0.6;0.3" dur="3s" repeatCount="indefinite"/></rect>';
        f += swim('M-36 0a36 16 0 1 0 72 0a36 16 0 1 0 -72 0', 14, 0, fish('#ff7a2a', '#ffffff', 1));
        f += swim('M30 4a28 12 0 1 1 -56 0a28 12 0 1 1 56 0', 11, -3, fish('#fff6ea', '#e8402a', 0.85));
        f += swim('M-20 -6a22 14 0 1 0 44 0a22 14 0 1 0 -44 0', 9, -5, fish('#ffc63a', '#ff7a2a', 0.7));
        [[-34, -14, 7], [30, 14, 6], [38, -12, 4.6]].forEach(([x, y, r]) => { f += '<path d="M' + x + ' ' + y + 'm0 0l' + r + ' -1.6a' + r + ' ' + r + ' 0 1 1 -1.4 -3.2Z" fill="#4f9a4a" stroke="#2f6a2e" stroke-width="0.4"/>'; });
        f += '<g transform="translate(-30 -16)"><circle r="2.6" fill="#ffb0cc"/><circle r="1.2" fill="#ffe27a"/></g>';
        rep(3, i => { f += '<ellipse cx="' + [10, -16, 24][i] + '" cy="' + [-8, 10, 6][i] + '" rx="1" ry="1" fill="none" stroke="#e8fbff" stroke-width="0.5" opacity="0">' + an('rx', '1;12', 3.4, -i * 1.1) + an('ry', '1;6', 3.4, -i * 1.1) + an('opacity', '0.9;0', 3.4, -i * 1.1) + '</ellipse>'; });
        f += '</g></g>';
        return { defs: '<clipPath id="q22kc"><rect x="-52" y="-28" width="104" height="56" rx="3"/></clipPath><pattern id="q22kw" width="16" height="8" patternUnits="userSpaceOnUse"><path d="M0 4Q4 1 8 4T16 4" stroke="#bff6ff" stroke-width="0.5" fill="none"/></pattern>', front: f }; } }; };

  // ======================= SIDE TABLES =======================
  // LIV-019 plastic milk crate end table
  N.crate22 = S => { const RED = '#d9363b', RD2 = shade(RED, 0.62), W = 34, H = 30, Dp = 30;
    return { w: W + 4, d: Dp + 4, topH: H, topW: 22, build: () => { const o = [], on = glue(o);
      const C = box(0, 0, 0, W, H, Dp, RED, PL({ r: 2.4, bev: 1 })); o.push(C);
      on(C, rep(3, i => rep(2, j => box(-10 + i * 10, 6 + j * 10, Dp / 2 + 0.05, 7, 7, 0.4, RD2, { r: 1.6, noOut: 1 }))).flat().concat([box(0, H - 6, Dp / 2 + 0.05, 12, 2.6, 0.4, RD2, { r: 1.2, noOut: 1 })]), [0, 0, 1]);
      on(C, rep(3, i => rep(2, j => box(W / 2 + 0.05, 6 + j * 10, -9 + i * 9, 0.4, 7, 6.4, RD2, { r: 1.6, noOut: 1 }))).flat(), [1, 0, 0]);
      on(C, rep(4, i => rep(4, j => box(-11.4 + i * 7.6, H + 0.02, -10 + j * 6.8, 5, 0.06, 4.6, RD2, { r: 0.8, noOut: 1 }))).flat(), [0, 1, 0]);
      o.push(cyl(5, H, 4, 4.6, 8.4, '#fbf6ec', PL({ n: 16, rg: [[0, 0, 0.78], [8.4, 0, 1]] })), cyl(5, H + 3, 4, 4.4, 2.6, '#e8402a', PL({ n: 16, noOut: 1 })), tilt(box(5, H + 8.4, 4, 9, 0.3, 9, '#e8e2d4', { r: 3.6 }), [1, 0, 0], -0.5, [5, H + 8.4, -0.6]));
      o.push(rod([6, H + 6, 4], [9, H + 15, 1], 0.3, '#f2f2f2', PL({ n: 4 })));
      pipe([[-8, H + 0.4, -4], [-14, H + 0.4, 4], [-W / 2 - 0.8, H - 2, 6], [-W / 2 - 0.8, 4, 8]], 0.4, '#f4f4f4', PL({ n: 4 })).forEach(s => o.push(s));
      o.push(box(-6, H, -6, 4.6, 0.7, 9, '#2a2d34', PL({ r: 1, yaw: 0.4 })));
      return o; } }; };

  // LIV-039 round white pedestal bistro side table
  N.bistro22 = S => { const WH = '#f7f5f0';
    return { w: 42, d: 42, round: 1, topH: 38.4, topW: 24, build: () => { const o = [];
      o.push(cyl(0, 0, 0, 13, 2.4, WH, G_({ n: 26, rg: [[0, 0, 1], [2.4, 0, 0.9]] })), cyl(0, 2.4, 0, 10, 4, WH, G_({ n: 20, rg: [[0, 0, 1], [2, 0, 0.55], [4, 0, 0.3]] })), cyl(0, 6.4, 0, 3, 22, WH, G_({ n: 14, rg: [[0, 0, 1], [22, 0, 0.85]] })), cyl(0, 28.4, 0, 3, 7.6, WH, G_({ n: 20, rg: [[0, 0, 0.85], [4, 0, 1.6], [7.6, 0, 3.6]] })));
      o.push(cyl(0, 36, 0, 19, 2.4, WH, G_({ n: 32 })));
      o.push(cyl(-5, 38.4, -2, 2.4, 8, '#bfe2ee', { n: 14, op: 0.6, shine: 1, rg: [[0, 0, 1], [5, 0, 1], [8, 0, 0.6]] }), rod([-5, 44, -2], [-4.2, 54, -2.4], 0.3, '#5f9a4a', { n: 4 }), ball(-4.2, 53.4, -2.4, 2, '#ff6f8a', { k: 4, n: 10, sy: 1.3 }), ball(-6, 49, -1.6, 1.4, '#6fae5a', { sx: 0.6, sy: 1.8, k: 3, n: 8 }));
      book(5, 38.4, 3, 12, 2, 9, '#7fb2c9', 0.3).forEach(s => o.push(s));
      return o; } }; };

  // LIV-059 fluted oak tambour side table (door slid half open)
  N.tambour22 = S => { const OK = '#cd9a60', OL = shade(OK, 1.12), OD = shade(OK, 0.7), W = 40, Dp = 36, BY = 6, BH = 36;
    return { w: W + 6, d: Dp + 6, topH: BY + BH + 2.4, topW: 24, build: () => { const o = [], on = glue(o);
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => o.push(cyl(sx * (W / 2 - 4), 0, sz * (Dp / 2 - 4), 2, BY, OD, W_({ n: 8, rg: [[0, 0, 0.7], [BY, 0, 1]] }))));
      const BD = box(0, BY, 0, W, BH, Dp, OK, W_({ r: 2 })); o.push(BD);
      o.push(box(0, BY + BH, 0, W + 2, 2.4, Dp + 2, OL, W_({ r: 1.6 })));
      const IN = on(BD, [box(-10, BY + 3, Dp / 2 + 0.05, 16, BH - 6, 0.3, '#2a1a10', { r: 0.4, noOut: 1 })], [0, 0, 1])[0];
      on(IN, [['#3f7fc8', 2.2], ['#e0b04c', 2.6], ['#c4643a', 2], ['#4f9a4a', 2.4]].map(([col, w], i) => box(-15.5 + i * 3, BY + 4, Dp / 2 + 0.5, w, 12 - (i % 2) * 1.6, 0.6, col, { r: 0.3 })), [0, 0, 1]);
      on(BD, rep(10, i => cyl(-0.6 + i * 2.3, BY + 3, Dp / 2 + 0.05, 1.15, BH - 6, i % 2 ? OL : OK, W_({ n: 8 }))), [0, 0, 1]);
      on(BD, [ball(0.6, BY + BH / 2, Dp / 2 + 1.4, 1.1, BR, M_({ k: 3, n: 8 }))], [0, 0, 1]);
      const TY = BY + BH + 2.4; o.push(cyl(5, TY, -3, 3, 8, '#e8f6ff', { n: 14, op: 0.5, shine: 1, rg: [[0, 0, 0.86], [8, 0, 1]] }), cyl(5, TY + 0.4, -3, 2.6, 5.6, '#bfe6ff', { n: 14, op: 0.5 }));
      [-1, 1].forEach(s => o.push(arcW(-5 + s * 2.6, TY + 0.6, 4, 2.2, 1.4, 0.5, 0.6, 0, 2 * PI, '#2a2b30', { n: 12 }))); o.push(rod([-5, TY + 0.9, 4], [-4.6, TY + 0.9, 4], 0.3, '#2a2b30', { n: 4 }));
      return o; } }; };

  // LIV-079 Nero Marquina black marble plinth (white veins) + candle
  N.marq22 = S => { const NM = '#1e1e22', VN = '#f2efe8', W = 34, H = 40;
    return { w: W + 4, d: W + 4, topH: H, topW: 20, build: () => { const o = [], on = glue(o);
      const P = box(0, 0, 0, W, H, W, NM, { r: 1.2, shine: 1 }); o.push(P); const h = W / 2 + 0.05;
      const vein = (L, fn, r) => on(P, pipe(L, r || 0.3, VN, { n: 4, noOut: 1, op: 0.85 }), fn);
      vein([[-h, 34, h], [-6, 26, h], [2, 27.4, h], [h, 12, h]], [0, 0, 1]); vein([[-8, 26.4, h], [-10, 14, h], [-4, 4, h]], [0, 0, 1], 0.16);
      vein([[h, 12, h], [h, 20, 4], [h, 26, -6], [h, 40, -h]], [1, 0, 0]); vein([[h, 22, 0], [h, 8, -8]], [1, 0, 0], 0.16);
      vein([[-h, H + 0.05, -4], [-6, H + 0.05, 2], [4, H + 0.05, 0], [h, H + 0.05, h]], [0, 1, 0]);
      o.push(cyl(3, H, 2, 6, 1, BR, M_({ n: 18 })), cyl(3, H + 1, 2, 3.2, 12, '#fbf6ea', { n: 14, mat: 'cer' }), rod([3, H + 13, 2], [3, H + 14.2, 2], 0.2, '#2a2020', { n: 4 }));
      return o; },
      fx: c => { const q = c.p(3, H + 16.6, 2), k = c.k;
        return { defs: RG('q22cf', '#fff3b0', '#ffb347', 0.8), front: ell(c, q, 9 * k, 9 * k, 'url(#q22cf)', an('opacity', '0.4;0.75;0.5;0.8;0.4', 1.6), 0.6)
          + '<path d="M' + f1(q[0]) + ' ' + f1(q[1] - 2.6 * k) + 'q' + f1(1.6 * k) + ' ' + f1(2.2 * k) + ' 0 ' + f1(3.6 * k) + 'q' + f1(-1.6 * k) + ' ' + f1(-1.4 * k) + ' 0 ' + f1(-3.6 * k) + 'Z" fill="#ffcf4a" stroke="#ff8a2a" stroke-width="' + f1(0.25 * k) + '">'
          + '<animateTransform attributeName="transform" type="skewX" values="0;6;-4;3;0" dur="1.4s" repeatCount="indefinite" additive="sum"/></path>' }; } }; };

  // LIV-099 floating levitation side pedestal with wireless power (top floats and bobs, energy rings rise)
  N.lev22 = S => { const WH = '#f2f4f8', CY = '#7fe8ff', TY = 26;
    return { w: 40, d: 40, round: 1, topH: TY + 3, topW: 22, glow: () => ({ y: 14, r: 46, c: 'url(#gNeon)' }), pad: [0, 4, 0, 0],
      layers: [{ anim: bobA(2.4, 3.2), build: () => { const o = [], on = glue(o);
        const T = cyl(0, TY, 0, 17, 3, WH, G_({ n: 30, rg: [[0, 0, 0.9], [1, 0, 1], [3, 0, 1]] })); o.push(T);
        on(T, [band(0, TY + 0.4, 0, 15.4, 0.7, CY, em({ n: 28 }))]);
        on(T, [cyl(4, TY + 3, 2, 6.4, 0.5, '#1c1f26', { n: 18 }), arcW(4, TY + 3.5, 2, 5.6, 5.6, 0.5, 0.2, 0, 2 * PI, CY, em({ n: 18 }))], [0, 1, 0]);
        const PH = box(4, TY + 3.7, 2, 5.4, 0.8, 10.4, '#2a2d34', { r: 1.4, yaw: 0.3, shine: 1 }); o.push(PH);
        on(PH, [box(4, TY + 4.52, 2, 4.6, 0.05, 9.4, '#3a6aa8', em({ r: 1.1, yaw: 0.3, op: 0.9 }))], [0, 1, 0]);
        return o; } }],
      build: () => { const o = [], on = glue(o);
        const B = cyl(0, 0, 0, 13, 3.4, '#23262d', G_({ n: 26, rg: [[0, 0, 1], [3.4, 0, 0.88]] })); o.push(B);
        on(B, [arcW(0, 3.4, 0, 9, 9, 1.2, 0.3, 0, 2 * PI, CY, em({ n: 24 })), cyl(0, 3.42, 0, 3, 0.2, CY, em({ n: 12 }))], [0, 1, 0]);
        return o; },
      fx: c => { const a = c.p(0, 4, 0), b = c.p(0, TY - 0.4, 0), k = c.k; let f = '<path d="M' + f1(a[0] - 4 * k) + ' ' + f1(a[1]) + 'L' + f1(b[0] - 12 * k) + ' ' + f1(b[1]) + 'H' + f1(b[0] + 12 * k) + 'L' + f1(a[0] + 4 * k) + ' ' + f1(a[1]) + 'Z" fill="url(#q22lb)">' + an('opacity', '0.5;0.9;0.5', 2.4) + '</path>';
        rep(3, i => { const bg = n4(-i * 0.8); f += ell(c, a, 4 * k, 4 * k * X.SA, 'none', an('cy', f1(a[1]) + ';' + f1(b[1]), 2.4, bg) + an('rx', f1(4 * k) + ';' + f1(13 * k), 2.4, bg) + an('ry', f1(4 * k * X.SA) + ';' + f1(13 * k * X.SA), 2.4, bg) + an('opacity', '0;0.8;0', 2.4, bg)).replace('fill="none"', 'fill="none" stroke="' + CY + '" stroke-width="' + f1(0.5 * k) + '"'); });
        return { defs: '<linearGradient id="q22lb" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="' + CY + '" stop-opacity="0.45"/><stop offset="1" stop-color="' + CY + '" stop-opacity="0.05"/></linearGradient>', back: f }; } }; };

  // ---------- catalog edits ----------
  RD.SET22 = {
    'LIV-002': { spec: 'torch22', live: 'Flickers', note: 'A cheap grey torchiere with a slightly bent pole (held together with tape), a bendy gooseneck and an upturned plastic bowl shade with a crack. The bulb flickers now and then.' },
    'LIV-022': { spec: 'tripod22', note: 'Three oak legs meet at a brass hub under a glowing linen drum shade, with a little pull chain and the cord trailing off one leg.' },
    'LIV-042': { spec: 'arc22', note: 'A chrome arc that rises from a heavy white marble block and curves over the sofa, ending in a shiny dome shade that throws a pool of warm light below.' },
    'LIV-062': { spec: 'alab22', live: 'Glowing stones', note: 'A totem of six smooth alabaster stones stacked on bronze spacers. Light glows through the stones and slowly breathes from one to the next.' },
    'LIV-082': { spec: 'bio22', live: 'Living light', note: 'A glass column on a stone pot with a glowing vine spiralling up inside, little glowing mushrooms and moss. Spores drift up and a pulse of light climbs the vine.' },
    'LIV-003': { spec: 'trestle22', note: 'A rough plywood board on two wooden sawhorses, with layered ply edges, mug rings, a sticky note, a pile of mail, keys and a coffee mug.' },
    'LIV-023': { spec: 'iron22', note: 'A slim black iron frame with a glass top and a glass shelf: a brass key tray and a little succulent on top, a woven basket and books below.' },
    'LIV-043': { spec: 'rattan22', note: 'A teak credenza on tapered legs with two woven cane doors, three drawers with brass pulls, a vase of pampas and a stack of books on top.' },
    'LIV-063': { spec: 'burl22', note: 'A swirly burl-wood top with a brass edge on shiny brass legs and a little brass gallery rail at the back. A brass bowl of fruit, a stone orb sculpture and art books on top.' },
    'LIV-083': { spec: 'liquid22', live: 'Dripping', note: 'A mirror-chrome console that looks poured: its legs flow up like liquid metal into the top. A shine sweeps across it, ripples spread on the top and a drop drips down into a little puddle.' },
    'LIV-016': { spec: 'spool22', note: 'An old cable spool turned into a coffee table: a thick round plywood top with bolts and stencilled letters, black cable still wound round the drum, and a mug on a coaster.' },
    'LIV-036': { spec: 'hairpin22', note: 'A pine coffee table with a lower shelf on black hairpin legs. Magazines and a basket of yarn below, a terracotta plant and coasters on top.' },
    'LIV-056': { spec: 'live22', note: 'A thick walnut slab with its natural wavy edge and pale sapwood rim, a small crack held by two wooden bowties, on black steel frames. A wooden bowl of moss balls and a cup of coffee.' },
    'LIV-076': { spec: 'drum22', note: 'A big cream travertine drum with soft bands and little pores, nested with a smaller smoked-bronze drum with a brass rim. A book, a brass orb and a white bowl.' },
    'LIV-096': { spec: 'koi22', live: 'Koi swim', note: 'A low glass table that is a little pond: three koi swim round under the glass between lily pads and a lotus, the water shimmers and ripples spread across it.' },
    'LIV-019': { spec: 'crate22', note: 'A red plastic milk crate turned upside down, with a cup of instant noodles and a fork on top, a phone and its charger cable hanging over the side.' },
    'LIV-039': { spec: 'bistro22', note: 'A glossy white tulip table on one slim pedestal, with a bud vase holding a pink tulip and a little book.' },
    'LIV-059': { spec: 'tambour22', note: 'A small oak cabinet with a fluted tambour door slid half open to show books inside. A glass of water and reading glasses on top.' },
    'LIV-079': { spec: 'marq22', live: 'Candle', note: 'A solid block of glossy black Nero Marquina marble with white veins running over its faces, with a brass candle holder and a flickering candle.' },
    'LIV-099': { spec: 'lev22', live: 'Floating', note: 'A white round top floats over a glowing base and gently bobs. Rings of light rise between them and the phone on the top charges wirelessly.' },
  };
  const edit21 = RD.edit;
  RD.edit = rows => edit21(rows).map(r => RD.SET22[r.id] ? Object.assign({}, r, RD.SET22[r.id]) : r);
  RD.H22 = { band, prism, R0, glue, rp, RG, ell, TOP, book, mug, sprig };
  RD.PLUS22 = 1;
})();
