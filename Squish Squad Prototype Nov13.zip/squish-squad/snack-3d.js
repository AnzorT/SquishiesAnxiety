// Snack Shack 3D kit (Nov 9, user: add 11 more creatures to the Snack Shack). Real 3D bodies for the new snacks, built from their own front art and drawn
// by rive-generic through two hooks: SN3D.setup (after the head anchor is found; the flat art that is rebuilt here is hidden) and SN3D.draw (every frame,
// before the parts are drawn). The kit sets I.bk = B (kind = key, sn = 1) so the generic code treats them like the Sweet Bakery pastries: the head path
// is B.d (the 3D silhouette), paws hinge at the body and ride on its front (B.rT / B.zAt), I.zE puts the face on the 3D surface, B.slab hides the face
// as a whole when the back turns round. Shapes: pillow slab (outline + thickness + rounded edge), body of revolution, tubes / capsules, sprites.
(function () {
  if (window.SN3D) return;
  const NS = 'http://www.w3.org/2000/svg', TAU = Math.PI * 2, D2R = Math.PI / 180;
  const r2 = v => Math.round(v * 100) / 100, clamp = (v, a, b) => v < a ? a : v > b ? b : v, SM = t => { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };
  const el = (tag, a, par, before) => { const e = document.createElementNS(NS, tag); for (const k in a) e.setAttribute(k, a[k]); if (par) { if (before) par.insertBefore(e, before); else par.appendChild(e); } return e; };
  const pt = p => r2(p[0]) + ' ' + r2(p[1]);
  const polyD = Q => Q.length > 2 ? 'M' + Q.map(pt).join('L') + 'Z' : '';
  const area = Q => { let a = 0; for (let i = 0; i < Q.length; i++) { const p = Q[i], q = Q[(i + 1) % Q.length]; a += p[0] * q[1] - q[0] * p[1]; } return a / 2; };
  const polyW = Q => { if (Q.length < 3) return ''; const a = area(Q); if (Math.abs(a) < 0.02) return ''; return polyD(a > 0 ? Q.slice().reverse() : Q); }; // same winding: one path = union
  const circD = (c, r) => 'M' + r2(c[0] - r) + ' ' + r2(c[1]) + 'a' + r2(r) + ' ' + r2(r) + ' 0 1 0 ' + r2(2 * r) + ' 0a' + r2(r) + ' ' + r2(r) + ' 0 1 0 ' + r2(-2 * r) + ' 0Z';
  const ellD = (c, rx, ry, a) => { const o = []; const ca = Math.cos(a || 0), sa = Math.sin(a || 0); for (let k = 0; k < 16; k++) { const f = k / 16 * TAU, x = rx * Math.cos(f), y = ry * Math.sin(f); o.push([c[0] + x * ca - y * sa, c[1] + x * sa + y * ca]); } return polyW(o); };
  const runs = (pts, ok) => { let d = '', pen = false; for (let i = 0; i < pts.length; i++) { if (ok[i]) { d += (pen ? 'L' : 'M') + pt(pts[i]); pen = true; } else pen = false; } return d; }; // polyline split where hidden
  const rnd = s => { const v = Math.sin(s * 127.1 + 311.7) * 43758.5453; return v - Math.floor(v); };

  // ---- round 2 helpers: art decals (any shapes in a data-k group, re-projected onto the 3D surface every frame) + lit pleat facets ----
  const subs = (segs, n) => { const out = []; let cur = null, p = [0, 0]; for (const g of segs) { const c = g.c;
      if (c === 'M') { cur = [g.p[0]]; out.push(cur); p = g.p[0]; } else if (c === 'Z') { if (cur) cur.closed = 1; } else if (!cur) continue;
      else if (c === 'L' || c === 'T') { cur.push(g.p[0]); p = g.p[0]; }
      else if (c === 'Q' || c === 'S') { const a = g.p[0], b = g.p[1]; for (let k = 1; k <= n; k++) { const t = k / n, u = 1 - t; cur.push([u * u * p[0] + 2 * u * t * a[0] + t * t * b[0], u * u * p[1] + 2 * u * t * a[1] + t * t * b[1]]); } p = b; }
      else if (c === 'C') { const a = g.p[0], b = g.p[1], e = g.p[2]; for (let k = 1; k <= n; k++) { const t = k / n, u = 1 - t; cur.push([u * u * u * p[0] + 3 * u * u * t * a[0] + 3 * u * t * t * b[0] + t * t * t * e[0], u * u * u * p[1] + 3 * u * u * t * a[1] + 3 * u * t * t * b[1] + t * t * t * e[1]]); } p = e; } }
    return out; };
  const DA = ['fill', 'stroke', 'stroke-width', 'opacity', 'stroke-linecap', 'stroke-linejoin', 'fill-opacity', 'stroke-opacity'];
  const inh = (e, k) => { for (let n = e; n && n.getAttribute; n = n.parentNode) { if (n.tagName === 'g' && n.hasAttribute('filter')) break; const v = n.getAttribute(k); if (v != null && !(k === 'opacity' && n !== e && n.hasAttribute('data-k'))) return v; } return null; };
  const decD = (o, f) => o.L.map(L => L.length > 1 ? 'M' + L.map(p => pt(f(p[0], p[1]))).join('L') + (L.closed ? 'Z' : '') : '').join('') || 'M0 0';
  const LV = (v => { const L = Math.hypot(v[0], v[1], v[2]); return v.map(c => c / L); })([-0.5, -0.55, 0.67]);
  const pal = (dark, mid, light, n) => { const hx = c => [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16)), A = hx(dark), M = hx(mid), L = hx(light);
    return Array.from({ length: n + 1 }, (_, i) => { const t = i / n, a = t < 0.5 ? A : M, b = t < 0.5 ? M : L, u = t < 0.5 ? t / 0.5 : (t - 0.5) / 0.5; return '#' + a.map((v, k) => Math.round(v + (b[k] - v) * u).toString(16).padStart(2, '0')).join(''); }); };
  // pleated body of revolution (same maths as the art): N pleats, each a ridge between two grooves, from y0 down to scalloped ends; each half-pleat is a
  // flat facet lit by its own normal (light from the upper left front), so the folds read as pinched dough from every side
  const pleatSet = (sp, par, linePar) => { const F = [], H = TAU / (2 * sp.N); for (let k = 0; k < sp.N; k++) { const fg = (sp.ph || 0) + k * TAU / sp.N, j = (rnd(k * 1.7) - 0.5) * (sp.jit || 0);
      for (let side = 0; side < 2; side++) F.push({ side, fa: side ? fg + H : fg, fb: side ? fg + 2 * H : fg + H, yge: sp.yG + j * 0.5, yre: sp.yR + j, id: 'p' + k + '_' + side, e: el('path', {}, par) }); }
    return { sp, F, H, par, ln: el('path', { fill: 'none', stroke: sp.lc, 'stroke-width': sp.lw, 'stroke-linecap': 'round', opacity: 0.75 }, linePar || par.parentNode), PAL: pal(sp.cols[0], sp.cols[1], sp.cols[2], 24) }; };
  const pleatDraw = (D, PS, proj, Z, xt) => { const { sp, F, H } = PS, { rT, y0, yR, tw, dep } = sp, U = y => clamp((y - y0) / (yR - y0), 0, 1), TW = u => tw(u) + xt * (1 - u);
    const P3d = (f, y, ridge) => { const u = U(y), ff = f + TW(u), r = rT(y) + (ridge ? dep(u) : -0.25); return proj(50 + r * Math.sin(ff), y, r * Math.cos(ff)); };
    let gl = '', lob = ''; const L = [];
    F.forEach(o => { const um = 0.45, ym = y0 + (yR - y0) * um, fm = (o.fa + o.fb) / 2 + TW(um), rm = rT(ym), be = Math.atan2(dep(um) + 0.25, rm * H) * (o.side ? 1 : -1), az = fm + be, g = Math.atan((rT(ym + 1) - rT(ym - 1)) / 2);
      const n = [Math.sin(az) * Math.cos(g), -Math.sin(g), Math.cos(az) * Math.cos(g)], m = [50 + rm * Math.sin(fm), ym, rm * Math.cos(fm)], fz = D.facing(m[0], m[1], m[2], n[0], n[1], n[2]);
      if (fz <= 0.02) { if (o.on !== 0) { o.on = 0; o.e.setAttribute('d', 'M0 0'); } return; } o.on = 1;
      const p0 = proj(m[0], m[1], m[2]), p1 = proj(m[0] + n[0], m[1] + n[1], m[2] + n[2]), sx = (p1[0] - p0[0]) / D.kS, sy = (p1[1] - p0[1]) / D.kS, ln = Math.hypot(sx, sy, fz) || 1, b = (sx * LV[0] + sy * LV[1] + fz * LV[2]) / ln;
      const ra = o.side === 1, rb = o.side === 0, ea = ra ? o.yre : o.yge, eb = rb ? o.yre : o.yge, A = [], B = [], lo = [];
      for (let i = 0; i <= 10; i++) { A.push(P3d(o.fa, y0 + (ea - y0) * i / 10, ra)); B.push(P3d(o.fb, y0 + (eb - y0) * i / 10, rb)); }
      for (let i = 1; i <= 5; i++) { const t = i / 6, f = o.fa + (o.fb - o.fa) * t, s = Math.sin((o.side ? 1 - t : t) * Math.PI / 2), y = o.yge + (o.yre - o.yge) * s, u = U(y), r = rT(y) - 0.25 + (dep(u) + 0.25) * s, ff = f + TW(u); lo.push(proj(50 + r * Math.sin(ff), y, r * Math.cos(ff))); }
      o.e.setAttribute('d', polyD(A.concat(lo, B.slice().reverse()))); const c = PS.PAL[Math.round(clamp(0.3 + 0.95 * b, 0, 1) * 24)]; if (o.c !== c) { o.c = c; o.e.setAttribute('fill', c); }
      if (!o.side) gl += 'M' + A.map(pt).join('L'); if (sp.lobe) lob += 'M' + lo.map(p => pt([p[0], p[1] + 0.7 * D.kS])).join('L'); L.push({ id: o.id, e: o.e, z: Z(m[0], m[1], m[2]) }); });
    L.sort((a, b) => a.z - b.z); SN.order(PS.par, L); PS.ln.setAttribute('d', gl || 'M0 0'); return lob; };
  // long pleats (Khinki v3): pleats that run the WHOLE body, knob to base. Each half-pleat is one strip shaded top to bottom by its own gradient (the colour at
  // the SY heights comes from the strip's normal there, lit like the facets above), so there is no edge between head and belly. Groove lines are clipped to
  // where the groove faces us and fade down the body (stroke gradient). TW(y) is the twist (pleat angle offset) at height y.
  const SA = (e, k, v) => { if (e['_' + k] !== v) { e['_' + k] = v; e.setAttribute(k, v); } };
  const longSet = (S, sp, par, linePar) => { const F = [], H = TAU / (2 * sp.N), u = S.u, LG = (id, a) => el('linearGradient', Object.assign({ id: id + u, gradientUnits: 'userSpaceOnUse', x1: 50, y1: sp.y0, x2: 50, y2: sp.y1 }, a || {}), S.df);
    for (let k = 0; k < sp.N; k++) { const fg = (sp.ph || 0) + k * TAU / sp.N; for (let side = 0; side < 2; side++) { const g = LG('lp' + k + '_' + side);
      F.push({ side, fa: side ? fg + H : fg, fb: side ? fg + 2 * H : fg + H, id: 'p' + k + '_' + side, g, st: sp.SY.map(() => el('stop', { offset: 0, 'stop-color': sp.cols[1] }, g)), e: el('path', { fill: 'url(#lp' + k + '_' + side + u + ')' }, par) }); } }
    const lg = LG('lpl'); sp.LS.forEach(([o, op]) => el('stop', { offset: o, 'stop-color': sp.lc, 'stop-opacity': op }, lg));
    return { sp, F, H, par, lg, YS: Array.from({ length: sp.NY + 1 }, (_, i) => sp.y0 + (sp.y1 - sp.y0) * i / sp.NY),
      ln: el('path', { fill: 'none', stroke: 'url(#lpl' + u + ')', 'stroke-width': sp.lw, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, linePar || par.parentNode), PAL: pal(sp.cols[0], sp.cols[1], sp.cols[2], 24) }; };
  const longDraw = (D, PS, proj, Z, TW) => { const { sp, F, H, YS } = PS, { rT, dep, SY } = sp, r3 = v => Math.round(v * 1000) / 1000, gT = y => Math.atan((rT(y + 1) - rT(y - 1)) / 2);
    const X3 = (f, y, ridge) => { const ff = f + TW(y), r = rT(y) + (ridge ? dep(y) : -0.25); return [50 + r * Math.sin(ff), y, r * Math.cos(ff)]; };
    let gl = ''; const L = [];
    F.forEach(o => { let vis = false, zs = 0;
      const C = SY.map(y => { const fm = (o.fa + o.fb) / 2 + TW(y), rm = rT(y), be = Math.atan2(dep(y) + 0.25, rm * H) * (o.side ? 1 : -1), az = fm + be, g = gT(y);
        const n = [Math.sin(az) * Math.cos(g), -Math.sin(g), Math.cos(az) * Math.cos(g)], m = [50 + rm * Math.sin(fm), y, rm * Math.cos(fm)], fz = D.facing(m[0], m[1], m[2], n[0], n[1], n[2]);
        if (fz > 0.02) vis = true; zs += Z(m[0], m[1], m[2]);
        const p0 = proj(m[0], m[1], m[2]), p1 = proj(m[0] + n[0], m[1] + n[1], m[2] + n[2]), sx = (p1[0] - p0[0]) / D.kS, sy = (p1[1] - p0[1]) / D.kS, ln = Math.hypot(sx, sy, fz) || 1, b = (sx * LV[0] + sy * LV[1] + fz * LV[2]) / ln;
        return { p: p0, c: PS.PAL[Math.round(clamp(0.3 + 0.95 * b, 0, 1) * 24)] }; });
      if (!vis) { if (o.on !== 0) { o.on = 0; o.e.setAttribute('d', 'M0 0'); } return; } o.on = 1;
      const ra = o.side === 1, A3 = YS.map(y => X3(o.fa, y, ra)), A = A3.map(p => proj(p[0], p[1], p[2])), B = YS.map(y => { const p = X3(o.fb, y, !ra); return proj(p[0], p[1], p[2]); });
      o.e.setAttribute('d', polyD(A.concat(B.reverse())));
      const a = C[0].p, bq = C[C.length - 1].p, vx = bq[0] - a[0], vy = bq[1] - a[1], vv = vx * vx + vy * vy || 1;
      SA(o.g, 'x1', r3(a[0])); SA(o.g, 'y1', r3(a[1])); SA(o.g, 'x2', r3(bq[0])); SA(o.g, 'y2', r3(bq[1]));
      let of = 0; C.forEach((s, i) => { of = Math.max(of, clamp(((s.p[0] - a[0]) * vx + (s.p[1] - a[1]) * vy) / vv, 0, 1)); SA(o.st[i], 'offset', r3(of)); SA(o.st[i], 'stop-color', s.c); });
      if (!o.side) gl += runs(A, A3.map((p, i) => { const ff = o.fa + TW(YS[i]), g = gT(YS[i]); return D.facing(p[0], p[1], p[2], Math.sin(ff) * Math.cos(g), -Math.sin(g), Math.cos(ff) * Math.cos(g)) > 0.05; }));
      L.push({ id: o.id, e: o.e, z: zs / SY.length }); });
    L.sort((a, b) => a.z - b.z); SN.order(PS.par, L); PS.ln.setAttribute('d', gl || 'M0 0');
    const t0 = proj(50, sp.y0, 0), t1 = proj(50, sp.y1, 0); SA(PS.lg, 'x1', r3(t0[0])); SA(PS.lg, 'y1', r3(t0[1])); SA(PS.lg, 'x2', r3(t1[0])); SA(PS.lg, 'y2', r3(t1[1])); };
  // ---- 2D outline helpers (art space) ----
  const resample = (Q, n) => { const L = [0]; for (let i = 1; i <= Q.length; i++) { const a = Q[i - 1], b = Q[i % Q.length]; L.push(L[i - 1] + Math.hypot(b[0] - a[0], b[1] - a[1])); }
    const tot = L[L.length - 1], out = []; let j = 0; for (let k = 0; k < n; k++) { const s = tot * k / n; while (L[j + 1] < s) j++; const a = Q[j], b = Q[(j + 1) % Q.length], u = (s - L[j]) / ((L[j + 1] - L[j]) || 1); out.push([a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u]); } return out; };
  const inside = (O, x, y) => { let c = false; for (let i = 0, j = O.length - 1; i < O.length; j = i++) { const a = O[i], b = O[j]; if ((a[1] > y) !== (b[1] > y) && x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]) c = !c; } return c; };
  const segDist = (O, x, y) => { let m = 1e9; for (let i = 0; i < O.length; i++) { const a = O[i], b = O[(i + 1) % O.length], vx = b[0] - a[0], vy = b[1] - a[1], L = vx * vx + vy * vy || 1, t = clamp(((x - a[0]) * vx + (y - a[1]) * vy) / L, 0, 1), dx = a[0] + vx * t - x, dy = a[1] + vy * t - y, d = dx * dx + dy * dy; if (d < m) m = d; } return Math.sqrt(m); };
  const sdist = (O, x, y) => (inside(O, x, y) ? 1 : -1) * segDist(O, x, y);
  const halfW = (O, y) => { let lo = 1e9, hi = -1e9; for (let i = 0; i < O.length; i++) { const a = O[i], b = O[(i + 1) % O.length]; if ((a[1] - y) * (b[1] - y) <= 0 && a[1] !== b[1]) { const x = a[0] + (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]); if (x < lo) lo = x; if (x > hi) hi = x; } } return hi < lo ? 0 : (hi - lo) / 2; };
  const offset = (O, b) => { if (!b) return O; const n = O.length; return O.map((p, i) => { const a = O[(i - 1 + n) % n], c = O[(i + 1) % n], tx = c[0] - a[0], ty = c[1] - a[1], L = Math.hypot(tx, ty) || 1; let nx = -ty / L, ny = tx / L;
      if (!inside(O, p[0] + nx * 0.4, p[1] + ny * 0.4)) { nx = -nx; ny = -ny; } return [p[0] + nx * b, p[1] + ny * b]; }); };
  // pillow slab: rings from the outline (z = 0) to the inset face (z = T), quarter-round edge of radius b
  const pillowRings = (O, T, b, K) => { const R = []; for (let k = 0; k <= K; k++) { const th = k / K * Math.PI / 2; R.push({ z: T * Math.sin(th), Q: offset(O, b * (1 - Math.cos(th))) }); } return R; };
  const pillowZ = (O, T, b) => (x, y) => { const d = sdist(O, x, y); if (d <= 0) return 0; const u = Math.min(1, d / b); return T * Math.sqrt(1 - (1 - u) * (1 - u)); };

  const MODELS = {};
  const SN = window.SN3D = { MODELS, h: { el, pt, polyD, polyW, circD, ellD, runs, resample, inside, sdist, halfW, offset, pillowRings, pillowZ, clamp, SM, r2, rnd, subs, decD, pal, pleatSet, pleatDraw, longSet, longDraw } };

  SN.setup = c => { try { SN.setup0(c); } catch (e) { (window.__SNERR = window.__SNERR || []).push('setup ' + c.key + ' ' + (e && e.message)); console.error('SN3D setup', c.key, e && e.stack); } };
  SN.setup0 = c => {
    const { I, key, art, items, headA, H } = c, M = MODELS[key]; if (!M || !headA) return;
    const sk = headA.q, par = sk.e.parentNode, df = art.querySelector('defs') || art.insertBefore(el('defs', {}), art.firstChild);
    const dOf = q => q.e.getAttribute('d') || '', fOf = q => q.e.getAttribute('fill') || (q.e.parentNode && q.e.parentNode.getAttribute && q.e.parentNode.getAttribute('fill')) || '',
      sOf = q => q.e.getAttribute('stroke') || (q.e.parentNode && q.e.parentNode.getAttribute && q.e.parentNode.getAttribute('stroke')) || '';
    const S = { I, key, art, items, headA, H, sk, par, df, u: I.u, HX: headA.cx, HY: headA.cy, d: dOf, f: fOf, s: sOf, el,
      hide: pred => items.filter(q => { if (q === sk || q.role === 'xHide' || !pred(q)) return false; q.role = 'xHide'; q.e.style.display = 'none'; return true; }),
      path: (a, p, before) => el('path', a, p || S.LG, before), g: (p, before) => el('g', {}, p || S.LG, before),
      outline: (q, n) => resample(H.flat(q.segs, 8).filter((p, i, A) => !i || Math.hypot(p[0] - A[i - 1][0], p[1] - A[i - 1][1]) > 0.01), n || 64),
      rgrad: (id, st, o) => { const g = el('radialGradient', Object.assign({ id: id + I.u, cx: '38%', cy: '30%', r: '75%' }, o || {}), df); st.forEach(([of, cl, op]) => el('stop', op != null ? { offset: of, 'stop-color': cl, 'stop-opacity': op } : { offset: of, 'stop-color': cl }, g)); return 'url(#' + id + I.u + ')'; },
      lgrad: (id, st, o) => { const g = el('linearGradient', Object.assign({ id: id + I.u, x1: 0, y1: 0, x2: 1, y2: 0 }, o || {}), df); st.forEach(([of, cl, op]) => el('stop', op != null ? { offset: of, 'stop-color': cl, 'stop-opacity': op } : { offset: of, 'stop-color': cl }, g)); return 'url(#' + id + I.u + ')'; },
      clip: id => { const cp = el('clipPath', { id: id + I.u }, df); return { p: el('path', { d: 'M0 0' }, cp), url: 'url(#' + id + I.u + ')' }; },
      dk: (q, k) => !!(q.e.closest && q.e.closest(k ? '[data-k="' + k + '"]' : '[data-k]')),                                       // the art marks its decal groups with data-k
      decals: (pred, par) => S.hide(pred).map(q => { const a = {}; DA.forEach(k => { const v = inh(q.e, k); if (v != null) a[k] = v; }); if (a.fill == null) a.fill = '#000'; return { e: el('path', a, par || S.LG), L: subs(q.segs, 6), q }; }) };
    S.gB = el('g', {}, par, sk.e); S.LG = el('g', {}, par, sk.e.nextSibling);
    const B = I.bk = Object.assign({ kind: key, sn: 1, bodyG: c.bodyG, d: '', ya: 30, yb: 90, rx: 30, rT: () => 20, S, M }, M.setup(S) || {});
    if (B.zE) I.zE = B.zE;
  };

  SN.draw = c => { try { SN.draw0(c); } catch (e) { if (!SN.err) { SN.err = 1; (window.__SNERR = window.__SNERR || []).push('draw ' + (c.I.bk && c.I.bk.kind) + ' ' + (e && e.message)); console.error('SN3D draw', c.I.bk && c.I.bk.kind, e && e.stack); } } };
  SN.draw0 = c => {
    const { I, P, now, sph, sphZ, glob, H, HY } = c, B = I.bk, M = B && B.M; if (!M) return;
    const dt = c.dtS || 0.016, ts = now / 1000, tg = P.x * 1.4 + P.tilt * 0.5 + P.lean * 1.5 + P.turn * 12, ly = P.lift - c.sq * 8;
    const Q = B.__q || (B.__q = { p: tg, v: 0, l: ly, lv: 0 });                                                          // soft lag spring (toppings trail the body)
    Q.v += ((tg - Q.p) * 120 - Q.v * 7) * dt; Q.p += Q.v * dt; Q.lv += ((ly - Q.l) * 140 - Q.lv * 7.5) * dt; Q.l += Q.lv * dt;
    const g0 = glob(40, HY), g1 = glob(60, HY), D = Object.assign({}, c, { B, ts, P3: sph, Z3: sphZ, kS: Math.hypot(g1[0] - g0[0], g1[1] - g0[1]) / 20,
      ox: clamp(Q.p - tg, -12, 12), oy: clamp(Q.l - ly, -6, 6), front: c.cyh * c.cp, bv: k => { const v = +P[k]; return v === v ? v : 0; },
      hull: pts => polyD(H.hull(pts)), /* straight hull: a spline overshoots at the rim corners (little horns) */ set: (e, a, v) => e.setAttribute(a, v),
      facing: (x, y, z, nx, ny, nz) => sphZ(x + nx, y + ny, z + nz) - sphZ(x, y, z) });
    M.draw(B, D);
  };
  // reorder children of a group back to front (only touches the DOM when the order changes)
  SN.order = (g, list, key) => { const k = list.map(o => o.id).join(','); if (g.__ok === k) return; g.__ok = k; list.forEach(o => g.appendChild(o.e)); };
  const sphereHull = (D, c, r, n) => { const o = []; n = n || 8; for (let i = 0; i <= n; i++) { const th = -Math.PI / 2 + Math.PI * i / n, cr = Math.cos(th), y = c[1] + r * Math.sin(th); if (cr < 0.01) { o.push(D.P3(c[0], y, c[2])); continue; } for (let k = 0; k < 2 * n; k++) { const f = k / (2 * n) * TAU; o.push(D.P3(c[0] + r * cr * Math.sin(f), y, c[2] + r * cr * Math.cos(f))); } } return o; };
  SN.h.sphereHull = sphereHull;
  // tube along 3D centre points (radius per point): union of the hulls of neighbouring spheres
  const tubeD = (D, C, R) => { let d = ''; const SP = C.map((c, i) => sphereHull(D, c, R[i], 5)); for (let i = 0; i < C.length - 1; i++) d += polyW(D.H.hull(SP[i].concat(SP[i + 1]))); return d; };
  SN.h.tubeD = tubeD;
  const pillowHull = (D, rings, z0, sg, extra) => { const o = extra ? extra.slice() : []; rings.forEach(R => R.Q.forEach(p => o.push(D.P3(p[0], p[1], z0 + sg * R.z)))); return o; };
  SN.h.pillowHull = pillowHull;
  SN.h.frontArc = (D, r, y, n) => { const v = []; for (let k = 0; k < n; k++) { const f = k / n * TAU; v.push(D.facing(50 + r * Math.sin(f), y, r * Math.cos(f), Math.sin(f), 0, Math.cos(f)) > -0.002); }
    let i0 = v.findIndex((o, k) => o && !v[(k - 1 + n) % n]); if (i0 < 0) i0 = 0; const o = []; for (let j = 0; j <= n; j++) { const k = (i0 + j) % n; if (!v[k]) break; o.push((i0 + j) / n * TAU); } return o; };

  // ================= Corny: popcorn bucket. A round tapered tub (body of revolution) with red stripes wrapping all the way round, a rolled rim and a
  // mound of 3D popcorn (each kernel a bumpy puff) sitting in the opening, seen a touch from above; the kernels sink inside the front rim and trail
  // the moves. Channels: pop (0..1.5: kernels jump up out of the tub and fall back), cfz (popcorn fizz - a fast little jitter).
  MODELS.corny = {
    setup(S) { const { sk } = S, O = S.outline(sk, 64), rT = y => halfW(O, clamp(y, 41.2, 86.8)), EL = 0.11;
      const red = (S.items.find(q => q.inBody && /^M15\.00 41/.test(S.d(q))) || {}).e; const RF = red ? red.getAttribute('fill') : '#f0464e';
      const pk = S.hide(q => q.inBody && q.e.parentNode && q.e.parentNode.getAttribute && /translate/.test(q.e.parentNode.getAttribute('transform') || '')), PF = (pk.find(q => /^url/.test(S.f(q))) || {}).e;
      const popF = PF ? PF.getAttribute('fill') : '#fff2c8'; S.hide(q => q.inBody && (/^(M15\.00 41|M33\.90 41|M57\.00 41|M75\.90 41|M13\.5 39\.5|M15 40\.6)/.test(S.d(q))));
      const sh = S.path({ fill: S.lgrad('cnsh', [[0, '#7a2a22', 0.34], [0.14, '#7a2a22', 0.08], [0.3, '#ffffff', 0.32], [0.46, '#ffffff', 0], [0.76, '#5a1a14', 0.05], [1, '#5a1a14', 0.4]]) });
      const st = S.path({ fill: RF }), bed = S.path({ fill: S.rgrad('cnbd', [[0, '#fff3c4'], [0.7, '#f4d27a'], [1, '#d9a848']], { cx: '50%', cy: '40%', r: '60%' }) }), cl = S.clip('cnc'), KG = S.g(); KG.setAttribute('clip-path', cl.url);
      const rim = S.path({ fill: RF }), rimL = S.path({ fill: 'none', stroke: '#ffd0d0', 'stroke-width': 0.9, opacity: 0.8, 'stroke-linecap': 'round' });
      // kernels on a mound over the opening: rings of puffs, each a cluster of 5 bumps + a butter-brown hull fleck
      const K = []; const add = (rho, n, y, s, ph) => { for (let i = 0; i < n; i++) { const a = ph + i / n * TAU, id = K.length; K.push({ id, x: 50 + rho * Math.sin(a), z: rho * Math.cos(a), y: y + (rnd(id * 2.3 + 1) - 0.5) * 2.8, s: s * (0.9 + rnd(id) * 0.25), hk: 6 + rnd(id + 9) * 10, B: [0, 1, 2, 3, 4].map(j => { const aa = j * 1.257 + rnd(id * 7 + j) * 0.6, dd = 1.7 + rnd(id * 5 + j) * 0.9; return [Math.cos(aa) * dd, Math.sin(aa) * dd, 2.5 + rnd(id * 3 + j) * 1.0]; }) }); } };
      [[0, 1, 12.5, 1.8, 0], [6.5, 5, 16.5, 1.75, 0.4], [13, 9, 21, 1.75, 0.1], [19.5, 12, 25.5, 1.7, 0.35], [25.5, 15, 30, 1.7, 0.05], [30.5, 18, 34.2, 1.65, 0.25], [34.5, 21, 38, 1.6, 0.15], [36.8, 12, 38.8, 1.5, 0.3]].forEach(a => add(...a));   // Nov 10 (user: 'please add more popcorn'): a heaped dome of 93 kernels spilling onto the rim (was 29)
      K.forEach(k => { k.g = el('g', {}, KG); k.e = el('path', { fill: popF }, k.g); k.dot = el('path', { fill: '#d89a3a', opacity: 0.8 }, k.g); k.id = 'k' + k.id; });
      return { O, rT, EL, K, KG, cl, sh, st, bed, rim, rimL, rx: 35, ya: 44, yb: 86, zE: (dx, dy) => { const r = rT(S.HY + dy); return Math.sqrt(Math.max(0, r * r - dx * dx)) + 0.3; } }; },
    draw(B, D) { const { P3, Z3, set } = D, EL = B.EL, rT = B.rT, pop = clamp(D.bv('pop'), 0, 1.6), fz = clamp(D.bv('cfz'), 0, 1);
      const PE = (x, y, z) => { const p = P3(x, y, z); return [p[0], p[1] + EL * Z3(x, y, z)]; };        // a touch from above: nearer points sit lower
      const hp = []; for (let i = 0; i <= 14; i++) { const y = 41.5 + 45.5 * i / 14, r = rT(y); for (let k = 0; k < 24; k++) { const f = k / 24 * TAU; hp.push(PE(50 + r * Math.sin(f), y, r * Math.cos(f))); } }
      for (let k = 0; k < 32; k++) { const f = k / 32 * TAU; hp.push(PE(50 + 35.6 * Math.sin(f), 39.8, 35.6 * Math.cos(f))); }
      B.d = D.hull(hp); set(B.sh, 'd', B.d);
      // stripes: 8 red bands wrapping all the way round, clipped to the visible half
      const vis = (f, y) => { const r = rT(y); return D.facing(50 + r * Math.sin(f), y, r * Math.cos(f), Math.sin(f), 0, Math.cos(f)) > 0.004; };
      let sd = ''; for (let s = 0; s < 8; s++) { const fc = (s + 0.5) * TAU / 8, fa = fc - TAU / 32, fb = fc + TAU / 32, F = []; for (let j = 0; j <= 12; j++) { const f = fa + (fb - fa) * j / 12; if (vis(f, 62)) F.push(f); } if (F.length < 2) continue;
        const Q = [], ys = [44.5, 52, 60, 68, 76, 82, 85, 86.8]; F.forEach(f => Q.push(PE(50 + rT(44.5) * Math.sin(f), 44.5, rT(44.5) * Math.cos(f)))); ys.forEach(y => { const f = F[F.length - 1], r = rT(y); Q.push(PE(50 + r * Math.sin(f), y, r * Math.cos(f))); });
        F.slice().reverse().forEach(f => { const r = rT(86.8); Q.push(PE(50 + r * Math.sin(f), 86.8, r * Math.cos(f))); }); ys.slice().reverse().forEach(y => { const f = F[0], r = rT(y); Q.push(PE(50 + r * Math.sin(f), y, r * Math.cos(f))); }); sd += polyW(Q); }
      set(B.st, 'd', sd || 'M0 0');
      // opening (popcorn bed) + rolled rim, front half of the rim drawn over the kernels
      const ring = (r, y) => { const o = []; for (let k = 0; k < 40; k++) { const f = k / 40 * TAU; o.push(PE(50 + r * Math.sin(f), y, r * Math.cos(f))); } return o; }; set(B.bed, 'd', polyW(ring(34.2, 40.6)));
      const FR = [], FRb = [], FRl = []; SN.h.frontArc(D, 36, 41, 60).forEach(f => { FR.push(PE(50 + 36.8 * Math.sin(f), 39.2, 36.8 * Math.cos(f))); FRb.push(PE(50 + 36.1 * Math.sin(f), 44.2, 36.1 * Math.cos(f))); FRl.push(PE(50 + 36.3 * Math.sin(f), 40.5, 36.3 * Math.cos(f))); });
      set(B.rim, 'd', polyW(FR.concat(FRb.slice().reverse())) || 'M0 0'); set(B.rimL, 'd', runs(FRl, FRl.map(() => true)) || 'M0 0');
      // clip: everything above the top edge of the front rim (kernels inside the tub hide behind its front wall)
      if (FR.length > 2) { const a = FR[0], z = FR[FR.length - 1], L = a[0] < z[0] ? FR : FR.slice().reverse(); set(B.cl.p, 'd', 'M' + r2(L[0][0] - 40) + ' ' + r2(L[0][1] + 0.6) + 'L' + r2(L[0][0] - 40) + ' -200L' + r2(L[L.length - 1][0] + 40) + ' -200L' + r2(L[L.length - 1][0] + 40) + ' ' + r2(L[L.length - 1][1] + 0.6) + L.slice().reverse().map(p => 'L' + r2(p[0]) + ' ' + r2(p[1] + 0.6)).join('') + 'Z'); }
      // kernels: trail the body a little (higher = more), jump on pop, depth-sorted
      const L = B.K.map(k => { const hgt = clamp((41 - k.y) / 28, 0, 1), jp = pop * k.hk * (0.6 + 0.4 * Math.sin(D.ts * 9 + k.hk)) + fz * Math.sin(D.ts * 37 + k.hk * 3) * 0.6, x = k.x + D.ox * 0.25 * hgt + fz * Math.sin(D.ts * 41 + k.hk) * 0.5, y = k.y - D.oy * 0.3 * hgt - Math.max(0, jp), C = PE(x, y, k.z), s = k.s * D.kS;
        let d = ''; k.B.forEach(b => { d += circD([C[0] + b[0] * s * 0.55, C[1] + b[1] * s * 0.55], b[2] * s * 0.55); }); set(k.e, 'd', d); set(k.dot, 'd', circD([C[0] + k.B[1][0] * s * 0.3, C[1] + 0.7 * s], 0.85 * s * 0.55)); return { id: k.id, e: k.g, z: Z3(x, y, k.z) }; }).sort((a, b) => a.z - b.z);
      SN.order(B.KG, L); }
  };

  // ================= Nori: rice ball. A thick pillow (soft rounded edges) cut from the rice outline. Round 2 (user: 'needs more details'): real rice
  // grains + sesame (the art's data-k="dc" decals) ride the pillow on whichever side faces you (the back gets extra grains where the front has the face),
  // the textured nori jacket (data-k="sw": sheet, fibres, sheen, edge) wraps the bottom edge, the pickled plum sits on a shiso leaf on the top edge.
  // Channels: ume (0..1: the plum pops up), nwr (-1..1: the seaweed jacket slides down / up a little).
  // Nov 11 (user: 'the seaweed doesn't cover him from the sides - you just see 2 diagonal stripes and dashed lines', then 'he needs to be like in the
  // image in terms of the seaweed that covers his bottom'): the strip of the art (data-k="sw": the trapezoid 31.5-68.5 at the top, 29.5-70.5 at the
  // bottom, its wavy top edge, 7 fibres, a sheen, a dark top edge) is now a real 3D strip WRAPPED round the pillow: down the front face, round the
  // rounded bottom edge, underneath and up the back. It is a grid of columns across its width x rows along the wrap; each column shows only the part
  // whose surface faces you (convex body: facing = visible), the turn-away boundary is interpolated so it slides smoothly. So from the front it is the
  // picture's strip, from 3/4 a foreshortened sheet with the bottom fold, from behind the back half of the wrap - never edge-on lines or dashes.
  MODELS.nori = {
    setup(S) { const { sk } = S, O = S.outline(sk, 64), T = 10.5, b = 8, rings = pillowRings(O, T, b, 4), zF = pillowZ(O, T, b);
      S.hide(q => q.inBody && (S.dk(q, 'sal') || (q.tag === 'circle' && /^url/.test(S.f(q))) || S.f(q) === '#5aa04a' || S.s(q) === '#ffd0da'));   // the art's salmon heap (or an old plum + leaf) is redrawn in 3D below
      const GG = S.g(), DC = S.decals(q => q.inBody && S.dk(q, 'dc'), GG), BG = S.g(), SG = S.g(), swq = S.hide(q => q.inBody && S.dk(q, 'sw')), sh = swq.find(q => /^url/.test(S.f(q)));
      const SW = { st: S.path({ fill: sh ? S.f(sh) : '#2b4232' }, SG), rim: S.path({ fill: '#0f1c13', opacity: 0.45 }, SG), fib: S.path({ fill: 'none', stroke: '#46644e', 'stroke-width': 0.45, 'stroke-linecap': 'round', opacity: 0.7 }, SG),
        shn: S.path({ fill: 'none', stroke: '#86a88c', 'stroke-width': 1.3, 'stroke-linecap': 'round', opacity: 0.45 }, SG), edge: S.path({ fill: 'none', stroke: '#122017', 'stroke-width': 0.7, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', opacity: 0.7 }, SG) };
      // the strip's wavy top edge (the art's two curves: 31.5,65.5 Q41,64 50,64.6 Q59,64 68.5,65.5) as samples
      const TOP = []; [[[31.5, 65.5], [41, 64], [50, 64.6]], [[50, 64.6], [59, 64], [68.5, 65.5]]].forEach(([p0, c, p1], h) => { for (let k = h ? 1 : 0; k <= 12; k++) { const t = k / 12, u = 1 - t; TOP.push([u * u * p0[0] + 2 * u * t * c[0] + t * t * p1[0], u * u * p0[1] + 2 * u * t * c[1] + t * t * p1[1]]); } });
      SW.yt = x => { if (x <= TOP[0][0]) return TOP[0][1]; for (let k = 1; k < TOP.length; k++) if (x <= TOP[k][0]) { const a = TOP[k - 1], c = TOP[k], t = (x - a[0]) / ((c[0] - a[0]) || 1); return a[1] + (c[1] - a[1]) * t; } return TOP[TOP.length - 1][1]; };
      // grains for the back (where the front has the face)
      const BK = []; let n = 0; while (BK.length < 12 && n < 400) { n++; const x = 31 + rnd(n * 3.3) * 38, y = 46 + rnd(n * 7.1) * 18; if (BK.some(p => Math.hypot(p[0] - x, p[1] - y) < 4.6)) continue; BK.push([x, y, rnd(n * 1.9) * Math.PI]); }
      const bkg = el('path', { fill: '#ffffff', stroke: '#ddd5c3', 'stroke-width': 0.35 }, BG);
      // Nov 11 (user on the pickled plum: 'what is this olive on top?' / 'it doesn't look so good' -> chose salmon flakes): a little heap of cooked
      // salmon flakes on his top (the same 13 flakes as the art's data-k="sal" group: x, y, size, colour, fat lines, depth), each a flaky blob with
      // pale fat lines, spread through his thickness so the heap turns with him; ume (the old plum channel) makes them hop up, a little apart
      const FL = [[43.92, 18.79, 2.48, "#f8b897", 1, 2.64], [46.89, 18.71, 2.48, "#e97c55", 1, 2.64], [50.17, 18.41, 2.37, "#e97c55", 1, 1.22], [53.59, 18.65, 2.2, "#ee8a62", 1, 2.49], [57.12, 18.06, 2.28, "#f39a72", 1, 1.32], [45.78, 15.18, 2.06, "#f39a72", 1, -1.95], [48.98, 15.41, 1.85, "#f8b897", 0, -0.96], [52.94, 15.17, 2.03, "#f6ad8a", 1, -1.24], [56.3, 15.08, 2.16, "#e97c55", 1, -0.89], [47.11, 12.8, 1.62, "#e97c55", 0, 1.24], [51.35, 12.56, 1.67, "#f8b897", 0, 0.66], [54.4, 12.22, 1.92, "#f39a72", 1, 1.1], [50.85, 10.35, 1.53, "#f8b897", 0, 0.0]];
      const SAL = S.g(), shd = S.path({ fill: '#cfc6b2', opacity: 0.4 }, SAL), FK = FL.map(([x, y, r, c, ft, z], k) => { const g = el('g', {}, SAL); return { k, x, y, r, z, rot: (rnd(k * 3.1) - 0.5) * 1.3, g,
        b: el('path', { fill: c, stroke: '#cf6a44', 'stroke-width': 0.3, 'stroke-opacity': 0.5 }, g), f: ft ? el('path', { fill: 'none', stroke: '#ffe6d8', 'stroke-width': 0.42, 'stroke-linecap': 'round', opacity: 0.8 }, g) : null }; });
      // slab: 1 (Nov 11, user: 'his eyes disappear as well'): his face sits on the FLAT front of the pillow, so it shows whole while the front looks at
      // you and goes as a whole when the back turns round (without it each eye faded by its depth as if on a ball - the far eye was gone at 40 deg)
      return { O, T, b, rings, zF, DC, SW, BG, bkg, BK, SAL, shd, FK, slab: 1, rx: 38, ya: 20, yb: 86, rT: y => halfW(O, y), zAt: (x, y) => zF(x, y), zE: (dx, dy) => zF(S.HX + dx, S.HY + dy) + 0.3 }; },
    draw(B, D) { const { P3, set } = D, zF = B.zF, umeV = clamp(D.bv('ume'), 0, 1.2), nw = clamp(D.bv('nwr'), -1, 1) * 3;
      B.d = D.hull(pillowHull(D, B.rings, 0, 1, pillowHull(D, B.rings, 0, -1)));
      // grains + sesame ride the pillow on the side facing you (front or back; the back gets extra grains where the face is); the nori jacket too,
      // wrapping over the rounded bottom edge
      const fr = D.front >= 0, s = fr ? 1 : -1, S2 = (x, y, dz) => P3(x, y, s * (zF(x, y) + dz));
      B.DC.forEach(o => set(o.e, 'd', decD(o, (x, y) => S2(x, y, 0.2))));
      B.BG.setAttribute('opacity', fr ? 0 : 1); if (!fr) set(B.bkg, 'd', B.BK.map(([x, y, a]) => polyW(Array.from({ length: 10 }, (_, k) => { const f = k / 10 * TAU; return S2(x + 1.65 * Math.cos(f) * Math.cos(a) - 0.8 * Math.sin(f) * Math.sin(a), y + 1.65 * Math.cos(f) * Math.sin(a) + 0.8 * Math.sin(f) * Math.cos(a), 0.2); }))).join(''));
      // the nori strip, wrapped: columns across its width (u 0..1, its sides lean out a little toward the bottom), rows along the wrap
      // (front face from the wavy top down, round the bottom edge, up the back face); a row point is drawn where its surface faces you
      const W = B.SW, YB = 87.5, xl = y => 31.5 - 2 * (y - 65.5) / 22, xr = y => 68.5 + 2 * (y - 65.5) / 22, NU = 16, e = 0.25;
      const nrm = (x, y, z) => { if (Math.abs(z) < 0.05) return [0, 1, 0]; const gx = (zF(x + e, y) - zF(x - e, y)) / (2 * e), gy = (zF(x, y + e) - zF(x, y - e)) / (2 * e), sg = z > 0 ? 1 : -1; const L_ = Math.hypot(gx, gy, 1); return [-gx * sg / L_, -gy * sg / L_, sg / L_]; };   // unit normal
      const line = u => { const x0 = xl(65) + u * (xr(65) - xl(65)), y0 = W.yt(x0) + nw, P = [], Y = [];
        for (let j = 0; j <= 6; j++) Y.push([y0 + (YB - B.b - y0) * j / 6, 1]);                                                   // front face
        for (let j = 1; j <= 6; j++) Y.push([YB - B.b * (1 - Math.cos((1 - j / 6) * Math.PI / 2)), 1]);                          // round the bottom edge
        for (let j = 1; j <= 6; j++) Y.push([YB - B.b * (1 - Math.cos(j / 6 * Math.PI / 2)), -1]);                              // underneath, to the back
        for (let j = 1; j <= 6; j++) Y.push([YB - B.b + (y0 - (YB - B.b)) * j / 6, -1]);                                       // up the back face
        Y.forEach(([y, sg], j) => { const yy = Math.min(y, YB - 0.02), x = xl(yy) + u * (xr(yy) - xl(yy)), z = sg * zF(x, yy), n = nrm(x, yy, z);
          P.push({ p: P3(x, yy, z), f: D.facing(x, yy, z, n[0], n[1], n[2]), rim: j > 6 && j < 19 }); }); return P; };
      const L = []; for (let i = 0; i <= NU; i++) L.push(line(i / NU));
      const lerp = (a, c, t) => [a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t];
      let dS = '', dR = '';
      for (let i = 0; i < NU; i++) { const A = L[i], C = L[i + 1], G = A.map((q, j) => (q.f + C[j].f) / 2), n = G.length;
        const G0 = 0.05; let j0 = G.findIndex(g => g > G0); if (j0 < 0) continue; let j1 = j0; while (j1 + 1 < n && G[j1 + 1] > G0) j1++;   // nearly edge-on = hidden (no hairlines side-on)
        const side = (pick, rimOnly) => { const o = []; let a0 = j0, a1 = j1; if (rimOnly) { while (a0 <= a1 && !A[a0].rim) a0++; while (a1 >= a0 && !A[a1].rim) a1--; if (a0 > a1) return null; }
          const cut = (j, k) => { const t = (G[j] - G0) / ((G[j] - G[k]) || 1); return lerp(pick[j].p, pick[k].p, clamp(t, 0, 1)); };
          if (!rimOnly && j0 > 0) o.push(cut(j0, j0 - 1)); for (let j = a0; j <= a1; j++) o.push(pick[j].p); if (!rimOnly && j1 < n - 1) o.push(cut(j1, j1 + 1)); return o; };
        const sa = side(A), sc = side(C); dS += polyW(sa.concat(sc.slice().reverse()));
        const ra = side(A, 1), rc = side(C, 1); if (ra && rc && ra.length > 1) dR += polyW(ra.concat(rc.slice().reverse())); }
      set(W.st, 'd', dS || 'M0 0'); set(W.rim, 'd', dR || 'M0 0');
      // the dark top edge on whichever face looks at you; fibres + sheen along the wrap where they face you
      const fr2 = L[NU >> 1][0].f >= L[NU >> 1][24].f, ti = fr2 ? 0 : 24;
      set(W.edge, 'd', runs(L.map(P => P[ti].p), L.map(P => P[ti].f > 0.05)) || 'M0 0');
      let fd = ''; [0.084, 0.216, 0.354, 0.495, 0.641, 0.781, 0.916].forEach(u => { const P = line(u); fd += runs(P.map(q => q.p), P.map((q, j) => q.f > 0.08 && j > 0 && j < 24)); });
      set(W.fib, 'd', fd || 'M0 0');
      const PS = line(fr2 ? 0.06 : 0.94), sj = fr2 ? [1, 5] : [19, 23];                                                  // sheen on the lit (screen-left) side of the face you see
      set(W.shn, 'd', runs(PS.map(q => q.p), PS.map((q, j) => q.f > 0.05 && j >= sj[0] && j <= sj[1])) || 'M0 0');
      // the salmon heap on his top: each flake drawn round its own 3D point (depth sorted), the same flaky shape as in the art; ume pops them up
      const kS = D.kS, M2 = (a, c) => [(a[0] + c[0]) / 2, (a[1] + c[1]) / 2];
      const flk = (o, C, r) => { const P = []; for (let i = 0; i < 7; i++) { const a = i * TAU / 7, rr = r * (0.72 + 0.5 * rnd(o.k * 7 + i)), x = rr * Math.cos(a) * 1.32, y = rr * Math.sin(a) * 0.74; P.push([C[0] + x * Math.cos(o.rot) - y * Math.sin(o.rot), C[1] + x * Math.sin(o.rot) + y * Math.cos(o.rot)]); }
        let d = 'M' + pt(M2(P[6], P[0])); for (let i = 0; i < 7; i++) d += 'Q' + pt(P[i]) + ' ' + pt(M2(P[i], P[(i + 1) % 7])); return d + 'Z'; };
      const fatL = (o, C, r) => { const q = (x, y) => [C[0] + x * Math.cos(o.rot) - y * Math.sin(o.rot), C[1] + x * Math.sin(o.rot) + y * Math.cos(o.rot)]; return 'M' + pt(q(-0.75 * r, -0.2 * r)) + 'Q' + pt(q(0, 0.12 * r)) + ' ' + pt(q(0.72 * r, -0.14 * r)) + 'M' + pt(q(-0.55 * r, 0.22 * r)) + 'Q' + pt(q(0, 0.5 * r)) + ' ' + pt(q(0.5 * r, 0.26 * r)); };
      set(B.shd, 'd', ellD(P3(50, 20, 0), 8.6 * kS * Math.max(0.35, Math.abs(D.front)) + 2.2 * kS, 1.7 * kS, 0));
      SN.order(B.SAL, B.FK.map(o => { const up = umeV * (5 + 3 * rnd(o.k * 5.3)), x = o.x + (o.x - 50) * 0.18 * umeV, y = o.y - up, C = P3(x, y, o.z), r = o.r * kS;
        set(o.b, 'd', flk(o, C, r)); if (o.f) set(o.f, 'd', fatL(o, C, r)); return { id: 'f' + o.k, e: o.g, z: D.Z3(x, y, o.z) }; }).sort((a, b) => a.z - b.z)); }
  };
  // exact silhouette of a thin slab (keeps a wobbly outline's dips that a hull would fill): front + back polygons + the side quads, one union path
  const slabD = (D, Q, zf, zb, W) => { W = W || D.P3; const F = Q.map(p => W(p[0], p[1], zf)), K = Q.map(p => W(p[0], p[1], zb)); let d = polyW(F) + polyW(K);
    for (let i = 0; i < Q.length; i++) { const j = (i + 1) % Q.length; d += polyW([F[i], F[j], K[j], K[i]]); } return d; };
  SN.h.slabD = slabD;
  const PEf = (D, EL, rT) => (x, y, z) => { const p = D.P3(x, y, z); return [p[0], p[1] + EL * (D.Z3(x, y, z) - rT(y))]; };      // seen a touch from above, front edge stays put

  // ================= Toco: taco. A folded tortilla: two thin curved shells that meet at the fold (bottom) and open toward the top, with the
  // fillings (ruffled lettuce, meat, tomato, cheese) packed between them along the top arc - from the side you see the V. Channel: snap
  // (-0.8..1.5: the shell opens wide / snaps shut, fillings bounce), the fillings trail the moves.
  MODELS.toco = {
    setup(S) { const { sk } = S, O = S.outline(sk, 64), th = 1.5, W0 = 9.5, Wy = y => W0 * Math.pow(clamp((87.5 - y) / 45.5, 0, 1), 0.85);
      const lt = S.hide(q => q.inBody && /^url/.test(S.f(q)) && q.tag === 'path' && /^M12\.00 88/.test(S.d(q)))[0], mt = S.hide(q => q.inBody && /^M11\.50 88/.test(S.d(q)))[0];
      S.hide(q => q.inBody && (q.tag === 'rect' || S.s(q) === '#ffb02e' || S.f(q) === '#d9952a' || S.s(q) === '#fff6cf'));
      const LF = lt ? S.f(lt) : '#86d24e', MF = mt ? S.f(mt) : '#8a4526', SG = S.g(S.par, sk.e); SG.appendChild(sk.e);
      const back = el('path', { fill: S.f(sk) }, SG, sk.e), FG = el('g', {}, SG, sk.e), F = [];
      const add = (a, kind, dz, r, id) => F.push({ a, kind, dz, r, id: kind + F.length, e: el('path', kind === 'l' ? { fill: LF, stroke: '#4d9a2a', 'stroke-width': 0.45, 'stroke-opacity': 0.55 } : kind === 'm' ? { fill: MF } : kind === 't' ? { fill: '#ff5a4a' } : { fill: 'none', stroke: '#ffb02e', 'stroke-width': 1.5, 'stroke-linecap': 'round' }, FG) });
      for (let i = 0; i < 13; i++) add(0.08 + i * 0.07, 'm', (i % 2 ? 1 : -1) * 0.3, 3.6);
      for (let i = 0; i < 30; i++) add(0.025 + i * 0.0328, 'l', [-0.45, 0.1, 0.5, -0.1, 0.35, -0.35][i % 6], 3.3 + (i % 3) * 0.45);
      [[0.16, 0.2], [0.36, -0.3], [0.62, 0.3], [0.84, -0.2]].forEach(([a, dz]) => add(a, 't', dz, 2.7)); [[0.24, 0.1], [0.5, -0.2], [0.7, 0.25], [0.92, 0]].forEach(([a, dz]) => add(a, 'c', dz, 2.4));
      const sp = S.path({ fill: '#d9952a', opacity: 0.5 }), hl = S.path({ fill: 'none', stroke: '#fff6cf', 'stroke-width': 1.2, opacity: 0.7, 'stroke-linecap': 'round' });
      return { O, th, Wy, SG, back, FG, F, sp, hl, slab: 1, rx: 38, ya: 44, yb: 86, rT: y => halfW(O, y), zAt: (x, y) => Wy(y) + th, zE: (dx, dy) => Wy(S.HY + dy) + th + 0.3 }; },
    draw(B, D) { const { P3, Z3, set } = D, snap = clamp(D.bv('snap'), -0.8, 1.6), k = 1 + snap * 0.6, W = y => B.Wy(y) * k, th = B.th, fr = D.front >= 0;
      const sh = sg => { const o = []; B.O.forEach(p => { const z = W(p[1]); o.push(P3(p[0], p[1], sg * z)); o.push(P3(p[0], p[1], sg * (z + th))); }); return D.hull(o); };
      B.d = sh(1); set(B.back, 'd', sh(-1));
      // fillings along the top arc (lettuce outermost, meat inside, tomato + cheese bits), packed in the gap between the shells
      const L = B.F.map((o, i) => { const a = Math.PI * (1 - o.a), out = o.kind === 'l' ? 1.8 + (o.r - 3.3) * 1.4 : o.kind === 'm' ? 1.2 : o.kind === 't' ? 3.4 : 4.2, wob = Math.sin(D.ts * 3 + i * 1.7) * 0.4 + snap * Math.sin(D.ts * 18 + i) * 0.8,
          x = 50 + (38 + out) * Math.cos(a) + D.ox * 0.15, y = 86 - (44 + out + wob) * Math.sin(a) - D.oy * 0.25, z = o.dz * W(y) * 1.6, C = P3(x, y, z), r = o.r * D.kS * (o.kind === 'l' ? 1 + clamp(W(y) / 14, 0, 0.4) : 1);
        if (o.kind === 'c') { const t = [Math.cos(a + 1.2), -Math.sin(a + 1.2)]; set(o.e, 'd', 'M' + pt([C[0] - t[0] * r, C[1] - t[1] * r]) + 'L' + pt([C[0] + t[0] * r, C[1] + t[1] * r])); }
        else if (o.kind === 't') set(o.e, 'd', ellD(C, r, r * 0.9, -a)); else set(o.e, 'd', circD(C, r)); return { id: o.id, e: o.e, z: Z3(x, y, z) }; }).sort((a, b) => a.z - b.z);
      SN.order(B.FG, L);
      const s = fr ? 1 : -1, SP = [[24, 78], [76, 79], [31, 84], [69, 84], [22, 64], [78, 63], [36, 49], [64, 48], [45, 70], [57, 77]];
      set(B.sp, 'd', SP.map(([x, y]) => circD(P3(x, y, s * (W(y) + th + 0.1)), 0.8 * D.kS)).join(''));
      const hp = []; for (let i = 0; i <= 24; i++) { const a = Math.PI * i / 24, x = 50 + 33.5 * Math.cos(a), y = 86 - 39.5 * Math.sin(a); hp.push(P3(x, y, s * (W(y) + th + 0.15))); } set(B.hl, 'd', runs(hp, hp.map(() => true)));
      SN.order(B.SG, fr ? [{ id: 'b', e: B.back }, { id: 'f', e: B.FG }, { id: 's', e: B.S.sk.e }] : [{ id: 's', e: B.S.sk.e }, { id: 'f', e: B.FG }, { id: 'b', e: B.back }]); }
  };

  // ================= Churro: a round star-ridged stick (8 ridges run its length and turn with it). Round 2 (user: 'add to him more chocolate'): dunked
  // deep in chocolate with long drips all the way round (the ones near his eyes stay short) and three chocolate drizzle strands wrapping his lower half;
  // sugar sparkles. Channel: cork (-1..1: the ridges and drizzle corkscrew round him), the chocolate gloss follows the light.
  MODELS.churro = {
    setup(S) { const { sk } = S, O = S.outline(sk, 64), rT = y => halfW(O, clamp(y, 12.2, 86.8));
      const ch = S.hide(q => q.inBody && /^M29 \d+ L29 22/.test(S.d(q)))[0], CF = ch ? S.f(ch) : '#5e3620';
      S.hide(q => q.inBody && (S.dk(q, 'dz') || S.s(q) === '#9a5420' || S.s(q) === '#ffe8c0' || S.s(q) === '#b8865e' || S.s(q) === '#a87652' || (q.tag === 'circle' && S.f(q) === '#ffffff')));
      const sh = S.path({ fill: S.lgrad('crsh', [[0, '#6a3410', 0.38], [0.16, '#6a3410', 0.08], [0.32, '#fff2d0', 0.34], [0.48, '#fff2d0', 0], [0.78, '#4a2008', 0.06], [1, '#4a2008', 0.42]]) });
      const gv = S.path({ fill: 'none', stroke: '#9a5420', 'stroke-width': 1.1, opacity: 0.55, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }), cr = S.path({ fill: 'none', stroke: '#ffe8c0', 'stroke-width': 0.85, opacity: 0.6, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }),
        sug = S.path({ fill: '#ffffff', opacity: 0.9 }), dz = S.path({ fill: 'none', stroke: '#4e2c18', 'stroke-width': 2.1, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }), dzh = S.path({ fill: 'none', stroke: '#9a6a48', 'stroke-width': 0.6, opacity: 0.8, 'stroke-linecap': 'round' }),
        cap = S.path({ fill: CF }), cg = S.path({ fill: 'none', stroke: '#b8865e', 'stroke-width': 1.1, opacity: 0.7, 'stroke-linecap': 'round' }), cg2 = S.path({ fill: 'none', stroke: '#a87652', 'stroke-width': 1.2, opacity: 0.55, 'stroke-linecap': 'round' });
      const SU = Array.from({ length: 30 }, (_, i) => [rnd(i * 3.1) * TAU, 46 + rnd(i * 7.7) * 38]).filter(([f, y]) => !(Math.abs(Math.atan2(Math.sin(f), Math.cos(f))) < 0.62 && y > 41 && y < 64));
      // the chocolate dip: deep, with long drips running down round him (the ones near his eyes stay short)
      const DR = [[0, 6.5, 0.17], [0.5, 2.2, 0.13], [-0.5, 2.4, 0.13], [0.98, 9.5, 0.15], [-0.98, 10.5, 0.15], [1.75, 7, 0.16], [-1.8, 8.5, 0.14], [2.5, 10, 0.15], [-2.55, 6.5, 0.16], [3.14, 9, 0.17]];
      const yd = f => { let y = 37 + 1.2 * Math.sin(5 * f + 0.7); DR.forEach(([c, L, w]) => { const d = Math.atan2(Math.sin(f - c), Math.cos(f - c)) / w; if (Math.abs(d) < 1) y = Math.max(y, 37 + L * Math.sqrt(1 - d * d)); }); return y; };
      const DZ = [[67, 0.4, 1.1], [75.2, 2.3, 4.0], [83, 4.3, 2.6]];                                                                          // drizzle strands: centre y + phases
      // cork turns his WHOLE body from the feet up (user: parts didn't move in the pokes - only the ridges twisted): pre() turns his middle with spin
      // (paws follow) + a little hyaw for the face height (the rig turns the face + the 3D body with it), draw() twists the rest relative to that - the top further, the bottom back to the feet
      const pre = P => { const c = clamp(+P.cork || 0, -1.2, 1.2); return c ? Object.assign({}, P, { spin: (+P.spin || 0) + c * 17, hyaw: (+P.hyaw || 0) + c * 0.2 }) : P; };   // arm height turns 17 deg (spin: paws follow), the face 25
      return { O, rT, sh, gv, cr, sug, dz, dzh, cap, cg, cg2, SU, yd, DZ, pre, rx: 21, ya: 22, yb: 82, zE: (dx, dy) => { const r = rT(S.HY + dy); return Math.sqrt(Math.max(0, r * r - dx * dx)) + 0.3; } }; },
    draw(B, D) { const { P3, set } = D, rT = B.rT, cork = clamp(D.bv('cork'), -1.2, 1.2), P = (f, y, k) => { const r = rT(y) * (k || 1); return P3(50 + r * Math.sin(f), y, r * Math.cos(f)); },
        vis = (f, y) => { const r = rT(y); return D.facing(50 + r * Math.sin(f), y, r * Math.cos(f), Math.sin(f), 0, Math.cos(f)) > 0.01; };
      const hp = []; for (let i = 0; i <= 18; i++) { const y = 12.2 + 74.6 * i / 18; for (let k = 0; k < 24; k++) hp.push(P(k / 24 * TAU, y, 1.02)); } B.d = D.hull(hp); set(B.sh, 'd', B.d);
      // ridges: grooves between 8 crests; they skip the smooth patch round his face (it turns with him) and twist into a corkscrew with cork
      const fz = (f, y) => Math.abs(Math.atan2(Math.sin(f), Math.cos(f))) < 0.6 && y > 40 && y < 66, tw = y => cork * 0.9 * (51 - y) / 75;
      let gd = '', cd = ''; for (let k = 0; k < 8; k++) { const G = [], Go = [], C = [], Co = []; for (let y = 39; y <= 85; y += 2) { const fg = (k + 0.5) * TAU / 8 + tw(y), fc = k * TAU / 8 + tw(y); G.push(P(fg, y, 0.985)); Go.push(vis(fg, y) && !fz(fg, y)); C.push(P(fc, y, 1.01)); Co.push(vis(fc, y) && !fz(fc, y)); }
        gd += runs(G, Go); cd += runs(C, Co); } set(B.gv, 'd', gd || 'M0 0'); set(B.cr, 'd', cd || 'M0 0');
      set(B.sug, 'd', B.SU.filter(([f, y]) => vis(f + tw(y), y)).map(([f, y]) => circD(P(f + tw(y), y, 1.02), 0.5 * D.kS)).join('') || 'M0 0');
      // chocolate drizzle: three wavy strands wrapping all the way round his lower half (they turn and corkscrew with him)
      let zd = '', zh = ''; B.DZ.forEach(([yc, p1, p2]) => { const Q = [], ok = [], Qh = [], okh = []; for (let k = 0; k <= 96; k++) { const f = k / 96 * TAU, y = yc + 2.3 * Math.sin(3 * f + p1) + 0.5 * Math.sin(7 * f + p2), ff = f + tw(y), v = vis(ff, y);
          Q.push(P(ff, y, 1.03)); ok.push(v); Qh.push(P(ff, y - 0.55, 1.04)); okh.push(v && Math.cos(f * 3 + p1 + 0.6) > 0.1); } zd += runs(Q, ok); zh += runs(Qh, okh); }); set(B.dz, 'd', zd || 'M0 0'); set(B.dzh, 'd', zh || 'M0 0');
      // chocolate dip: front-facing part of the cap, top round to the drippy lower edge that wraps round him
      const A = SN.h.frontArc(D, 21, 40, 160); if (A.length > 1) { const t2 = tw(42), yd = f => B.yd(f - t2), Q = [];                       // the drips turn with the twist
        A.forEach(f => Q.push(P(f, yd(f), 1.035))); const fb = A[A.length - 1], fa = A[0]; for (let y = yd(fb); y >= 13; y -= 2.5) Q.push(P(fb, y, 1.035)); for (let i = A.length - 1; i >= 0; i -= 4) Q.push(P(A[i], 12.4, 1.035)); Q.push(P(A[0], 12.4, 1.035)); for (let y = 13; y <= yd(fa); y += 2.5) Q.push(P(fa, y, 1.035));
        set(B.cap, 'd', polyW(Q)); set(B.cg, 'd', runs(A.map(f => P(f, 17, 1.04)), A.map(f => Math.cos(f + D.yh) > 0.35))); set(B.cg2, 'd', runs(A.map(f => P(f, 22 + (f + D.yh + 0.9) * 8, 1.045)), A.map(f => Math.abs(f + D.yh + 0.85) < 0.16))); } }
  };

  // seen a touch from above (a world-space tilt after the turn, about the face's centre so the face stays put): P3W / Z3W
  const tiltW = (D, al, yc, zc) => { const ca = Math.cos(al), sa = Math.sin(al), HX = D.HX, cyh = D.cyh, syh = D.syh;
    const R = (x, y, z) => { const cs = D.yawH ? D.yawH(y) : [cyh, syh], dx = x - HX, x1 = dx * cs[0] + z * cs[1], z1 = -dx * cs[1] + z * cs[0], u = y - yc, w = z1 - zc; return [HX + x1, yc + u * ca + w * sa, zc - u * sa + w * ca]; };
    return { P: (x, y, z) => { const r = R(x, y, z); return D.headT(r[0], r[1]); }, Z: (x, y, z) => R(x, y, z)[2], F: (x, y, z, nx, ny, nz) => R(x + nx, y + ny, z + nz)[2] - R(x, y, z)[2] }; };
  SN.h.tiltW = tiltW;

  // ================= Frankie: hot dog, seen a touch from above. Two soft bun halves (rounded outer crust, soft bread on the inside faces) with the
  // sausage lying IN the split between them; ketchup + mustard run along the TOP of the sausage. Channels: slip (-1..1: the sausage slides out to one
  // side), hug (-1..1.5: the halves squeeze it / open out).
  // v2 (Nov 10, user: 'Frankie has some issues - look at hot dogs online'): a real hot dog bun is ONE roll split along the top (side-split rolls stay
  // hinged at the bottom), plump and rounded with rounded ends, golden-brown toasted on top, paler lower down and soft cream inside; the sausage sits
  // in the split with its rounded ends poking out past the bun. Was: two thin flat boards (box outline n 5, edge 7.5 on 12) standing apart all the way
  // down (a gap under the sausage from the side), one flat colour. Now: rounder outline (n 2.8), plump crust (edge 9.5 on 11), the halves close in to
  // meet at the bottom (zz(y): z0 -> 0 below the sausage, so from the end he is a U with the sausage in the notch), the near half a touch lower (top
  // 53, more sausage shows), toasted crust gradients + a crust sheen, cream crumb lip, a reddish-brown glossy sausage.
  MODELS.frankie = {
    setup(S) { const { sk } = S, T = 11, b = 9.5;
      const rr = (y0, n) => { const Q = []; for (let k = 0; k < 72; k++) { const f = k / 72 * TAU, c = Math.cos(f), s = Math.sin(f), ax = 42, ay = (88 - y0) / 2; Q.push([50 + ax * Math.sign(c) * Math.pow(Math.abs(c), 2 / n), (88 + y0) / 2 + ay * Math.sign(s) * Math.pow(Math.abs(s), 2 / n)]); } return Q; };
      // the half nearer you sits a little lower than the far one (top 53 vs 43), so the sausage reads as lying IN the bun from any side
      const O = rr(53, 2.8), OF = rr(43, 2.8), rings = pillowRings(O, T, b, 5), ringsF = pillowRings(OF, T, b, 5), zF = pillowZ(O, T, b), sau = S.hide(q => q.inBody && /^M14 41/.test(S.d(q)))[0], bi = S.hide(q => q.inBody && /^M13 43/.test(S.d(q)))[0];
      S.hide(q => q.inBody && (/^M9 50 Q9 31|^M14 43\.6|^M16 46 L20|^M16 56/.test(S.d(q)) || S.s(q) === '#e8402e'));
      sk.e.setAttribute('fill', S.lgrad('fkb', [[0, '#c9782f'], [0.16, '#d98f42'], [0.42, '#eeb265'], [0.78, '#f6cf92'], [1, '#eebd7c']], { x2: 0, y2: 1 }));   // toasted on top -> pale lower down
      const zz = y => SM((88 - y) / 26), SG = S.g(S.par, sk.e); SG.appendChild(sk.e);
      const topY = x => { let m = 1e9; for (let i = 0; i < O.length; i++) { const a = O[i], c = O[(i + 1) % O.length]; if ((a[0] - x) * (c[0] - x) <= 0 && a[0] !== c[0]) { const y = a[1] + (c[1] - a[1]) * (x - a[0]) / (c[0] - a[0]); if (y < m) m = y; } } return m; };   // the near half's top edge (the split)
      const OFi = offset(OF, 1.5).map(p => [p[0], Math.min(p[1], 62)]);                                                                         // its inside face shows only above the hinge                                                               // 1 at the split, 0 at the hinge underneath
      const back = el('path', { fill: S.lgrad('fkf', [[0, '#bf6c28'], [0.3, '#d48a3e'], [1, '#e9ae63']], { x2: 0, y2: 1 }) }, SG, sk.e),
        inB = el('path', { fill: S.rgrad('fki', [[0, '#fff8ea'], [0.6, '#ffeccb'], [1, '#f2d29c']], { cy: '70%' }) }, SG, sk.e), sg = el('g', {}, SG, sk.e),
        sp = el('path', { fill: S.lgrad('fks', [[0, '#f08660'], [0.38, '#d85434'], [0.78, '#b23d26'], [1, '#8c2c1c']], { x2: 0, y2: 1 }) }, sg),
        sh = el('path', { fill: 'none', stroke: '#ffd8c6', 'stroke-width': 1.3, 'stroke-linecap': 'round', opacity: 0.75 }, sg),
        kc = el('path', { fill: 'none', stroke: '#e8402e', 'stroke-width': 2.1, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, sg), ms = el('path', { fill: 'none', stroke: '#ffd43b', 'stroke-width': 1.8, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, sg),
        lip = el('path', { fill: 'none', stroke: '#fff3dc', 'stroke-width': 1.7, opacity: 0.85, 'stroke-linecap': 'round' }, SG),
        shn = el('path', { fill: 'none', stroke: '#fff4dc', 'stroke-width': 4, opacity: 0.2, 'stroke-linecap': 'round' }, SG);
      return { O, OF, OFi, topY, T, b, rings, ringsF, zF, zz, SG, back, inB, sg, sp, sh, kc, ms, lip, shn, z0: 4, AL: 0.45, YC: 70, slab: 1, rx: 41, ya: 50, yb: 87, rT: y => halfW(O, y), zAt: (x, y) => 4 * zz(y) + zF(x, y),
        zE: (dx, dy) => 4 * zz(S.HY + dy) + zF(S.HX + dx, S.HY + dy) + 0.3 }; },
    draw(B, D) { const { set } = D, slip = clamp(D.bv('slip'), -1.3, 1.3) * 15, hug = clamp(D.bv('hug'), -1, 1.5), z0 = B.z0 + hug * 3, zc = z0 + B.T, W = tiltW(D, B.AL, B.YC, zc), P = W.P, zz = y => z0 * B.zz(y);
      const fr = D.front >= 0, s = fr ? 1 : -1, half = (sg, RG) => { const o = []; RG.forEach(R => R.Q.forEach(p => o.push(P(p[0], p[1], sg * (zz(p[1]) + R.z))))); return D.hull(o); };
      B.d = half(1, fr ? B.rings : B.ringsF); set(B.back, 'd', half(-1, fr ? B.ringsF : B.rings));                                              // near half lower, far half taller
      set(B.inB, 'd', polyW(B.OFi.map(p => P(p[0], p[1], -s * (zz(p[1]) - 0.2)))));                                     // the soft inside face of the far half
      const r = 8.4 - Math.max(0, -hug) * 0.8, yS = 52.5 - Math.max(0, -hug) * 1.5, sph = c => { const o = []; for (let i = 0; i <= 6; i++) { const th = -Math.PI / 2 + Math.PI * i / 6, cr = Math.cos(th); for (let k = 0; k < 12; k++) { const f = k / 12 * TAU; o.push(P(c[0] + r * cr * Math.sin(f), c[1] + r * Math.sin(th), c[2] + r * cr * Math.cos(f))); } } return o; };
      set(B.sp, 'd', D.hull(sph([12 + slip, yS, 0]).concat(sph([88 + slip, yS, 0]))));
      // ketchup (wavy) + mustard (zig-zag) along the top of the sausage
      const line = (fn, x0, x1, st) => { const Q = [], ok = []; for (let x = x0; x <= x1; x += st) { const ph = fn(x), ny = -Math.cos(ph), nz = Math.sin(ph); Q.push(P(x + slip, yS + r * ny * 1.03, r * nz * 1.03)); ok.push(W.F(x + slip, yS + r * ny, r * nz, ny * 0 + 0, ny, nz) > 0.02); } return runs(Q, ok); };
      set(B.kc, 'd', line(x => 0.32 + 0.24 * Math.sin((x - 15) * 0.9), 15, 85, 0.9) || 'M0 0');
      set(B.ms, 'd', line(x => { const u = (x - 16) / 4, tri = Math.abs(((u % 2) + 2) % 2 - 1) * 2 - 1; return -0.2 + 0.3 * tri; }, 16, 84, 1) || 'M0 0');
      set(B.sh, 'd', line(() => 0.95, 18, 82, 4) || 'M0 0');
      const lp = [], sn = []; for (let x = 12; x <= 88; x += 2) { const ty = B.topY(x); if (ty > 72) continue; lp.push(P(x, ty + 0.5, s * (zz(ty + 0.5) + 0.7))); if (x >= 24 && x <= 76) sn.push(P(x, ty + 5.2, s * (zz(ty + 5.2) + B.T * 0.9))); } set(B.lip, 'd', runs(lp, lp.map(() => true))); set(B.shn, 'd', runs(sn, sn.map(() => true)));   // the cream crumb at the split + a sheen on the crust
      const L = [{ id: 'b', e: B.back, z: W.Z(50, 68, -z0 - 6) }, { id: 'i', e: B.inB, z: W.Z(50, 68, -s * z0) + s * 0.01 }, { id: 's', e: B.sg, z: W.Z(50 + slip, yS, 0) }, { id: 'f', e: B.S.sk.e, z: W.Z(50, 68, z0 + 6) }, { id: 'l', e: B.lip, z: W.Z(50, 68, s * (z0 + 6)) + 0.01 }, { id: 'h', e: B.shn, z: W.Z(50, 68, s * (z0 + 6)) + 0.02 }].sort((a, b) => a.z - b.z);   // crumb lip + sheen ride on the near half
      SN.order(B.SG, L); }
  };

  // ================= Peppi: pizza slice standing on his crust, the tip pointing up. A thin slab cut from the art outline, baked dough underneath, the crust
  // a real round tube along the bottom arc with toasty char bubbles. Round 2 (user: toppings too identical / only pepperoni): every topping in the art's
  // data-k="tp" group (sauce, cheese drips, browned spots, 2 pepperoni of different sizes, olives, green pepper, mushroom, basil) is re-projected onto
  // the cheese face in its own colours. Channels: pull (0..1: the crust pulls down, cheese strings stretch), flop (-1..1: the tip droops forward / back).
  MODELS.peppi = {
    setup(S) { const { sk } = S, O = S.outline(sk, 56), T = 2.3, b = 1.4, rings = pillowRings(O, T, b, 2);
      const cheese = S.f(sk), cr = S.hide(q => q.inBody && /^M6\.5 75\.5/.test(S.d(q)))[0], CR = cr ? S.f(cr) : '#eaa95c'; S.hide(q => q.inBody && /^M18 80\.5/.test(S.d(q)));
      sk.e.setAttribute('fill', S.rgrad('pzd', [[0, '#ffe9bf'], [0.6, '#f0c886'], [1, '#c99450']]));
      const face = S.path({ fill: cheese }), dec = S.g(), DC = S.decals(q => q.inBody && S.dk(q, 'tp'), dec);                       // every topping in the art, in its own colours and order
      const spots = S.path({ fill: '#c98a44', opacity: 0.4 }), strings = S.path({ fill: 'none', stroke: '#ffd45c', 'stroke-width': 1.6, 'stroke-linecap': 'round', opacity: 0.95 }), crust = S.path({ fill: CR }),
        char = S.path({ fill: '#a8642a', opacity: 0.4 }), cl = S.path({ fill: 'none', stroke: '#ffeccc', 'stroke-width': 1.3, 'stroke-linecap': 'round', opacity: 0.8 });
      return { O, T, b, rings, face, dec, DC, spots, strings, crust, char, cl, slab: 1, rx: 41, ya: 20, yb: 78,
        rT: y => halfW(O, y), zAt: (x, y) => inside(O, x, y) ? T : 0, zE: () => T + 0.25, cheese, back: S.rgrad('pzb', [[0, '#fff2d2'], [0.6, '#f2d39a'], [1, '#d6a660']]) }; },
    draw(B, D) { const { P3, set } = D, T = B.T, pull = clamp(D.bv('pull'), 0, 1.2), flop = clamp(D.bv('flop'), -1, 1) * 10;
      const W = (x, y, z) => { const u = clamp((46 - y) / 36, 0, 1); return P3(x, y + Math.abs(flop) * u * u * 0.35, z + flop * u * u); };          // the tip droops (z) without leaving the slab
      const all = []; B.rings.forEach(R => R.Q.forEach(p => { all.push(W(p[0], p[1], R.z)); all.push(W(p[0], p[1], -R.z)); })); B.d = D.hull(all);
      const fr = D.front >= 0, s = fr ? 1 : -1; set(B.face, 'd', polyW(B.rings[B.rings.length - 1].Q.map(p => W(p[0], p[1], s * T)))); set(B.face, 'fill', fr ? B.cheese : B.back);
      B.dec.setAttribute('opacity', fr ? 1 : 0); set(B.spots, 'opacity', fr ? 0 : 0.4); const cir = (x, y, r, z, n) => polyW(Array.from({ length: n || 14 }, (_, k) => W(x + r * Math.cos(k / (n || 14) * TAU), y + r * Math.sin(k / (n || 14) * TAU), z)));
      if (fr) B.DC.forEach((o, i) => set(o.e, 'd', decD(o, (x, y) => W(x, y, T + 0.15 + i * 0.004))));
      else set(B.spots, 'd', [[44, 40, 1.4], [58, 46, 1.3], [50, 58, 1.5], [40, 62, 1.1], [62, 64, 1.2], [30, 66, 1], [70, 60, 1.3]].map(([x, y, r]) => cir(x, y, r, -T - 0.15, 8)).join(''));
      const C = [], R = []; for (let i = 0; i <= 10; i++) { const t = i / 10, u = 1 - t, x = u * u * 7.5 + 2 * u * t * 50 + t * t * 92.5, y = u * u * 80 + 2 * u * t * 91.5 + t * t * 80 + pull * 6; C.push([x, y, 0]); R.push(4.6 - 0.9 * Math.pow(Math.abs(t - 0.5) * 2, 3)); }
      set(B.crust, 'd', tubeD(D, C, R)); const lp = C.slice(1, -1).map((c, i) => P3(c[0], c[1] - R[i + 1] * 0.72, s * R[i + 1] * 0.55)); set(B.cl, 'd', runs(lp, lp.map(() => true)));
      // toasty char bubbles on the crust (the side facing you)
      set(B.char, 'd', [[1.6, -0.1, 1.1], [3.2, 0.25, 0.8], [4.6, -0.2, 1.2], [6.3, 0.15, 0.9], [7.7, -0.15, 1], [8.9, 0.3, 0.7]].map(([i, dy, r]) => { const a = Math.floor(i), f = i - a, c = [C[a][0] + (C[a + 1][0] - C[a][0]) * f, C[a][1] + (C[a + 1][1] - C[a][1]) * f], rr = R[a]; return ellD(P3(c[0], c[1] + dy * rr, s * rr * 0.82), r * D.kS, r * 0.65 * D.kS, 0); }).join(''));
      let sd = ''; if (pull > 0.02) [20, 33, 47, 61, 75].forEach((x, i) => { const yb = 74 + (1 - Math.pow((x - 50) / 42, 2)) * 5, a = W(x, yb - 1, s * (T + 0.3)), b = P3(x + Math.sin(i * 2.1) * 1.2, yb + 2 + pull * 6, s * 1), m = P3(x + Math.sin(D.ts * 6 + i) * 0.8 * pull, yb + 1 + pull * 3, s * (T + 0.5)); sd += 'M' + pt(a) + 'Q' + pt(m) + ' ' + pt(b); });
      set(B.strings, 'd', sd || 'M0 0'); set(B.strings, 'stroke-width', r2(0.6 + pull * 1.2)); }
  };

  // ================= Sunny: a soft-boiled egg on her own (round 2, user: no egg cup, no legs, she rolls from place to place). A body of revolution
  // from the art outline (the face on it), a hairline crack round the top, speckles. B.roll: rive-generic turns the whole drawing by the rl channel
  // (degrees) about her middle and keeps the lowest point of the turned egg on the ground; snack2-house drives rl from the distance she walks.
  // Channels: cap (0..1: the top of the shell lifts off and tips like a hat, showing the runny yolk), wob (yolk wobble), rl (roll).
  MODELS.sunny = {
    setup(S) { const { sk } = S, O = S.outline(sk, 72), rT = y => halfW(O, clamp(y, 12.2, 91.8)), YK = 31.8;
      S.hide(q => q.inBody && (S.s(q) === '#c9a87c' || S.f(q) === '#d8c09c'));
      const crack = S.path({ fill: 'none', stroke: '#c9a87c', 'stroke-width': 0.9, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }), spk = S.path({ fill: '#d8c09c', opacity: 0.55 }),
        open = S.path({ fill: '#fffdf6' }), yolk = S.path({ fill: S.rgrad('sny', [[0, '#fff3a8'], [0.6, '#ffc42c'], [1, '#ef9410']], { cx: '42%', cy: '35%', r: '70%' }) }), capE = el('path', { fill: S.f(sk) }, S.gB), capL = el('path', { fill: 'none', stroke: '#c9a87c', 'stroke-width': 0.8 }, S.gB);
      const SP = Array.from({ length: 18 }, (_, i) => [rnd(i * 3.7) * TAU, 16 + rnd(i * 5.9) * 72]).filter(([f, y]) => !(Math.abs(Math.atan2(Math.sin(f), Math.cos(f))) < 0.55 && y > 50 && y < 72));
      // rolling (rl channel, degrees): rive-generic turns the whole drawing about her middle, then lifts / drops it so the lowest point of the turned egg
      // sits on the ground (an egg on its side lies lower than one standing up)
      const OS = O.filter((p, i) => i % 2 === 0), roll = (a, P, G, sy) => { const c = Math.cos(a), s = Math.sin(a), lf = +P.lift || 0, px = +P.x || 0, cx = 50 + px, cy = G - lf - (G - 56) * sy; let my = -1e9;
        OS.forEach(p => { const gx = p[0] + px, gy = G - lf - (G - p[1]) * sy, y = cy + (gx - cx) * s + (gy - cy) * c; if (y > my) my = y; }); return { c, s, cx, cy, up: my - (G - lf) }; };
      return { O, rT, YK, crack, spk, open, yolk, capE, capL, SP, roll, rx: 30, ya: 30, yb: 88, zE: (dx, dy) => { const r = rT(S.HY + dy); return Math.sqrt(Math.max(0, r * r - dx * dx)) + 0.3; } }; },
    draw(B, D) { const { P3, set } = D, rT = B.rT, YK = B.YK, cap = clamp(D.bv('cap'), 0, 1.2), wob = clamp(D.bv('wob'), 0, 1.6), ring = (r, y, n) => Array.from({ length: n }, (_, k) => { const f = k / n * TAU; return P3(50 + r * Math.sin(f), y, r * Math.cos(f)); });
      const y0 = cap > 0.02 ? YK : 12.2, hp = []; for (let i = 0; i <= 18; i++) { const y = y0 + (91.8 - y0) * i / 18; hp.push(...ring(rT(y), y, 24)); } B.d = D.hull(hp);
      set(B.spk, 'd', B.SP.filter(([f, y]) => y > y0 + 1 && D.facing(50 + rT(y) * Math.sin(f), y, rT(y) * Math.cos(f), Math.sin(f), 0, Math.cos(f)) > 0.05).map(([f, y]) => circD(P3(50 + (rT(y) + 0.1) * Math.sin(f), y, (rT(y) + 0.1) * Math.cos(f)), 0.75 * D.kS)).join('') || 'M0 0');
      // the crack (zig-zag round the top) / the opened top with the runny yolk + the shell cap tipped like a hat
      const rk = rT(YK), CA = SN.h.frontArc(D, rk, YK, 72), cq = CA.map((f, i) => P3(50 + (rk + 0.1) * Math.sin(f), YK + (i % 2 ? -1.6 : 1.4), (rk + 0.1) * Math.cos(f)));
      if (cap <= 0.02) { set(B.crack, 'd', runs(cq, cq.map(() => true)) || 'M0 0'); ['open', 'yolk', 'capE', 'capL'].forEach(k => set(B[k], 'd', 'M0 0')); return; }
      set(B.crack, 'd', 'M0 0'); const EL = 0.22, PE = (x, y, z) => { const p = P3(x, y, z); return [p[0], p[1] + EL * (D.Z3(x, y, z) - rk)]; };
      set(B.open, 'd', polyW(Array.from({ length: 36 }, (_, k) => { const f = k / 36 * TAU; return PE(50 + rk * Math.sin(f), YK, rk * Math.cos(f)); })));
      const yr = rk * 0.62 * (1 + wob * 0.06 * Math.sin(D.ts * 15)), yk = YK - 1.2 - wob * 0.6 * Math.sin(D.ts * 17); set(B.yolk, 'd', polyW(Array.from({ length: 30 }, (_, k) => { const f = k / 30 * TAU; return PE(50 + yr * Math.sin(f), yk, yr * Math.cos(f)); })));
      const lift = cap * 11, tip = cap * 58 * Math.PI / 180, ct = Math.cos(tip), st = Math.sin(tip), pv = [50, YK, -rk], cp = []; for (let i = 0; i <= 8; i++) { const y = 12.2 + (YK - 12.2) * i / 8, r = rT(y); for (let k = 0; k < 20; k++) { const f = k / 20 * TAU, x = 50 + r * Math.sin(f), z = r * Math.cos(f), vy = y - pv[1], vz = z - pv[2];
          cp.push(P3(x, pv[1] + vy * ct - vz * st - lift, pv[2] + vy * st + vz * ct)); } }
      set(B.capE, 'd', D.hull(cp)); const cl = []; for (let k = 0; k <= 24; k++) { const f = -Math.PI / 2 + Math.PI * k / 24, x = 50 + rk * Math.sin(f), z = rk * Math.cos(f), vz = z - pv[2]; cl.push(P3(x, pv[1] - vz * st - lift, pv[2] + vz * ct)); } set(B.capL, 'd', runs(cl, cl.map(() => true))); }
  };

  // ================= Khinki: a Georgian khinkali (round 2, user: 'looks like Bao with hair'). A plump smooth belly (body of revolution, the face on it),
  // the top gathered into 18 deep dough pleats: every half-pleat is a flat facet lit by its own normal (light from the upper left front), with groove
  // lines and scalloped ends, twisting up into a short thick knob (kudi, 7 twisted lit facets) - same maths as the art (an/newsnack/round2.py).
  // Black pepper on the pleats. Channels: kt (-1..1: the pleats twist round), knot (-1..1: the knob flicks to a side), the knob trails his moves.
  // v3 (Nov 10, user: 'his head looks really good, but you can see the difference between his lower body and head - continue the design and the colour'):
  // the 18 pleats now run knob to base as long strips (longSet / longDraw), soft wide folds over the belly, a ridge down the middle of his face, the whole
  // body (and arms / feet, from the art) in the head's dough palette, pepper on the belly too (not on his face). The twist fades smoothly down to y 72.
  MODELS.khinki = {
    setup(S) { const { sk } = S, O = S.outline(sk, 80), rT = y => halfW(O, clamp(y, 27.6, 90.2)), KN = y => y >= 20.5 ? 6.9 - (28.5 - y) * 0.16 : 5.62 * Math.sqrt(Math.max(0, 1 - Math.pow((20.5 - y) / 3.6, 2)));
      const kn = S.hide(q => q.inBody && /^url\(#k/.test(S.f(q)))[0], KF = kn ? S.f(kn) : '#e3c895'; S.hide(q => q.inBody && S.dk(q));
      const Y0 = 28.2, Y1 = 90, tw = y => 0.55 * Math.pow(1 - clamp((y - Y0) / 30.8, 0, 1), 2), xw = y => Math.pow(1 - clamp((y - Y0) / 44, 0, 1), 2),
        dep = y => y <= 59 ? 0.8 + 3 * Math.pow(1 - clamp((y - Y0) / 30.8, 0, 1), 0.8) : y <= 81 ? 0.8 + 0.55 * Math.sin((y - 59) / 22 * Math.PI / 2) : 0.4 + 0.95 * Math.cos(clamp((y - 81) / 9, 0, 1) * Math.PI / 2);
      const PG = S.g(), LN = S.g(), knob = S.path({ fill: KF }), KG = S.g(), KL = S.g(), pep = S.path({ fill: '#3e3028' });
      const cone = longSet(S, { N: 18, ph: -TAU / 36, rT, y0: Y0, y1: Y1, NY: 24, SY: [28.2, 36, 45, 56, 68, 79, 89.6], tw, dep, cols: ['#b08c56', '#ead6ac', '#fdf3dc'], lc: '#a68552', lw: 0.6, LS: [[0, 0.8], [0.45, 0.55], [0.8, 0.34], [1, 0.2]] }, PG, LN);
      const kp = pleatSet({ N: 7, rT: KN, y0: 18.2, yG: 28.8, yR: 28.8, ph: 0.3, tw: u => 1.25 * (1 - u), dep: () => 1, cols: ['#a8844e', '#e2c896', '#fff6e2'], lc: '#9c7a48', lw: 0.55 }, KG, KL);
      const PE = Array.from({ length: 26 }, (_, i) => [rnd(i * 4.1) * TAU, 31 + rnd(i * 2.3) * 22]).concat(Array.from({ length: 30 }, (_, i) => [rnd(i * 3.7 + 9) * TAU, 58 + rnd(i * 1.9 + 4) * 29]).filter(([f, y]) => !(y < 84 && Math.abs(Math.atan2(Math.sin(f), Math.cos(f))) < 0.75)).slice(0, 14));
      // hands and feet: little pleated dumplings too (Nov 10, user: 'please also do it on his legs and hands'). rive-generic hands over each limb every frame as an
      // ellipsoid (centre c, projected axes ax, unit view axes E, radii R): N pleats run from its root (shoulder / under his body) round to its tip, groove lines where
      // they face us, and each half-pleat gets a light or dark overlay from its own normal (same light as the body) over the limb's own dough gradient.
      // paws: the pleats are gathered at the shoulder and melt away into the round paw (gradients from root to tip); feet: pleated little buns (even all over)
      let LC = 0; const limb = (q, kind, c, ax, E, R, glob) => { const ar = kind === 'arm';
        if (!q.dec) { const u = 'kl' + (LC++) + S.u, gr = (n, col, st) => { const g = el('linearGradient', { id: n + u, gradientUnits: 'userSpaceOnUse', x1: 0, y1: 0, x2: 0, y2: 1 }, S.df); st.forEach(([o, op]) => el('stop', { offset: o, 'stop-color': col, 'stop-opacity': op }, g)); return g; };
          const fd = ar ? [[0, 1], [0.45, 0.85], [0.92, 0]] : [[0, 1], [1, 1]]; q.dGr = [gr('d', '#8a6436', fd), gr('l', '#fffaf0', fd), gr('g', '#a68552', fd)];
          q.dec = el('g', {}, q.e.parentNode, q.e.nextSibling); q.dD = el('path', { fill: 'url(#d' + u + ')', opacity: 0.2 }, q.dec); q.dL = el('path', { fill: 'url(#l' + u + ')', opacity: 0.45 }, q.dec);
          q.dG = el('path', { fill: 'none', stroke: 'url(#g' + u + ')', 'stroke-width': 0.42, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', opacity: 0.7 }, q.dec); }
        const N = ar ? 8 : 10, H = Math.PI / N, ph = ar ? 0 : H, th0 = ar ? 0.04 : 0.14, th1 = ar ? 0.84 : 0.9, NS = 8, BE = 0.38;
        { const r0 = glob(c[0] - ax[1][0], c[1] - ax[1][1]), t0 = glob(c[0] + ax[1][0], c[1] + ax[1][1]); q.dGr.forEach(g => { SA(g, 'x1', r2(r0[0])); SA(g, 'y1', r2(r0[1])); SA(g, 'x2', r2(t0[0])); SA(g, 'y2', r2(t0[1])); }); }
        const S3 = (th, f) => [Math.sin(th) * Math.sin(f), -Math.cos(th), Math.sin(th) * Math.cos(f)];
        const P2 = s => glob(c[0] + s[0] * ax[0][0] + s[1] * ax[1][0] + s[2] * ax[2][0], c[1] + s[0] * ax[0][1] + s[1] * ax[1][1] + s[2] * ax[2][1]);
        const NV = s => { const n = [0, 0, 0]; for (let i = 0; i < 3; i++) { const k = s[i] / R[i]; for (let j = 0; j < 3; j++) n[j] += k * E[i][j]; } const l = Math.hypot(n[0], n[1], n[2]) || 1; return [n[0] / l, n[1] / l, n[2] / l]; };
        const BR = n => n[0] * LV[0] + n[1] * LV[1] + n[2] * LV[2], TH = Array.from({ length: NS + 1 }, (_, i) => Math.PI * (th0 + (th1 - th0) * i / NS));
        let dL = '', dD = '', dG = '';
        for (let k = 0; k < N; k++) { const fg = ph + k * 2 * H, G3 = TH.map(th => S3(th, fg)); dG += runs(G3.map(P2), G3.map(s => NV(s)[2] > 0.03));
          for (let side = 0; side < 2; side++) { const fa = fg + side * H, fb = fa + H, fm = fa + H / 2, nm = NV(S3(Math.PI / 2, fm)); if (nm[2] < 0.05) continue;
            const d = BR(NV(S3(Math.PI / 2, fm + (side ? BE : -BE)))) - BR(nm); if (Math.abs(d) < 0.03) continue;
            const pd = 'M' + TH.map(th => P2(S3(th, fa))).concat(TH.slice().reverse().map(th => P2(S3(th, fb)))).map(pt).join('L') + 'Z'; if (d > 0) dL += pd; else dD += pd; } }
        SA(q.dL, 'd', dL || 'M0 0'); SA(q.dD, 'd', dD || 'M0 0'); SA(q.dG, 'd', dG || 'M0 0'); };
      return { O, rT, KN, tw, xw, dep, knob, cone, kp, pep, PE, limb, rx: 37, ya: 44, yb: 88, zE: (dx, dy) => { const r = rT(S.HY + dy); return Math.sqrt(Math.max(0, r * r - dx * dx)) + 0.3; } }; },
    draw(B, D) { const { P3, Z3, set } = D, rT = B.rT, kt = clamp(D.bv('kt'), -1.2, 1.2), kq = clamp(D.bv('knot'), -1.2, 1.2);
      const hp = []; for (let i = 0; i <= 20; i++) { const y = 27.6 + 62.6 * i / 20, r = rT(y); for (let k = 0; k < 24; k++) { const f = k / 24 * TAU; hp.push(P3(50 + r * Math.sin(f), y, r * Math.cos(f))); } } B.d = D.hull(hp);
      // the pleats, knob to base: twist round with kt (most at the top, fading out down the belly)
      const TW = y => B.tw(y) + kt * 0.6 * B.xw(y); longDraw(D, B.cone, P3, Z3, TW);
      set(B.pep, 'd', B.PE.filter(([f, y]) => { const ff = f + TW(y); return D.facing(50 + rT(y) * Math.sin(ff), y, rT(y) * Math.cos(ff), Math.sin(ff), 0, Math.cos(ff)) > 0.08; }).map(([f, y]) => { const ff = f + TW(y), r = rT(y) + B.dep(y) * 0.55; return circD(P3(50 + r * Math.sin(ff), y, r * Math.cos(ff)), 0.5 * D.kS); }).join('') || 'M0 0');
      // the knob (kudi): short and thick, sways a little, trails his moves and flicks with knot
      const sw = Math.sin(D.ts * 1.6) * 0.5 + D.ox * 0.25 + kq * 3.5, KP = (x, y, z) => { const u = clamp((28.8 - y) / 12, 0, 1); return P3(x + sw * u * u, y - D.oy * 0.25 * u, z); }, KZ = (x, y, z) => Z3(x, y, z);
      const kh = []; for (let i = 0; i <= 12; i++) { const y = 28.8 - (28.8 - 16.95) * i / 12, r = B.KN(y); for (let k = 0; k < 16; k++) { const f = k / 16 * TAU; kh.push(KP(50 + r * Math.sin(f), y, r * Math.cos(f))); } } set(B.knob, 'd', D.hull(kh));
      pleatDraw(D, B.kp, KP, KZ, kt * 0.4 + kq * 0.5); }
  };

  // ================= Maki v4 (Nov 10, user photo: an inside-out roll): a sushi roll standing up, seen a touch from above. White sticky rice is OUTSIDE - his round side
  // (his face sits on it, dark eyes read on white): plump grains raised a little off the surface (they make his outline lumpy) shaded by their facing, golden sesame.
  // The cut end faces up: a rice ring (grains + sesame), a thin nori ring, and the filling just proud of it - a big salmon piece at the back (two broad pale fat bands),
  // pale avocado and green cucumber in front (side walls darker, lit tops). Same seeded layout as the art (an/newsnack/round2.py Maki v4). Paws / feet: rice with grains
  // (I.bk.limb). Channel: veg (0..1.3: the filling pops up and wiggles), spins like a top in his dance.
  MODELS.maki = {
    setup(S) { const R0 = 29, YT = 38.6, AL = Math.asin(0.44), KF = 21.5 / 17.8,   // Nov 10: 5% shorter (top lowered 34 -> 38.6) + a bigger filling circle (x KF)
      rT = y => y > 82 ? Math.sqrt(Math.max(0, 36 - (y - 82) * (y - 82))) + R0 - 6 : R0;
      S.hide(q => q.inBody && S.dk(q));
      const ang = f => Math.atan2(Math.sin(f), Math.cos(f)), face = (f, y) => Math.abs(ang(f)) < 0.6 && y > 52 && y < 75;
      const SG = Array.from({ length: 300 }, (_, i) => [rnd(i * 2.31 + 1) * TAU, YT + 2 + rnd(i * 1.73 + 2) * (84 - YT), rnd(i * 3.1 + 5) * Math.PI]).filter(g => !face(g[0], g[1]));
      const TG = Array.from({ length: 52 }, (_, i) => [24.3 + rnd(i * 1.37 + 7) * 4.2, rnd(i * 2.9 + 3) * TAU, rnd(i * 4.3 + 1) * Math.PI]);
      const SS = Array.from({ length: 34 }, (_, i) => [rnd(i * 5.1 + 11) * TAU, YT + 4 + rnd(i * 2.2 + 9) * (80 - YT), rnd(i * 1.9 + 4) * Math.PI]).filter(g => !face(g[0], g[1]));
      const TS = Array.from({ length: 10 }, (_, i) => [24.5 + rnd(i * 3.3 + 2) * 3.8, rnd(i * 1.1 + 8) * TAU, rnd(i * 2.7 + 6) * Math.PI]);
      // the filling: the nori ring (wobbly circle round 50.5 / -1.2), cut into salmon (back, most of it) / avocado (front left) / cucumber (front right)
      const NR = f => KF * (17.8 + 0.8 * Math.sin(3 * f + 1.1) + 0.45 * Math.sin(5 * f + 0.3)), C = [50.5, -1.2], SCc = (a, b, c) => KF * (c - a * C[0] - b * C[1]) + a * C[0] + b * C[1], SM = (x, z) => [C[0] + (x - C[0]) * KF, C[1] + (z - C[1]) * KF], ringXZ = (rf, n) => Array.from({ length: n }, (_, k) => { const f = k / n * TAU; return [C[0] + rf(f) * Math.sin(f), C[1] + rf(f) * Math.cos(f)]; });
      const clip = (Q, a, b, c) => { const o = []; for (let i = 0; i < Q.length; i++) { const p = Q[i], q = Q[(i + 1) % Q.length], s1 = a * p[0] + b * p[1] - c, s2 = a * q[0] + b * q[1] - c; if (s1 <= 0) o.push(p); if (s1 * s2 < 0) { const t = s1 / (s1 - s2); o.push([p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t]); } } return o; };
      const bed = ringXZ(f => NR(f) - 0.7, 64), fr = clip(bed, -0.08, -1, SCc(-0.08, -1, -(3.8 + 4))), shr = (Q, k) => { const cx = Q.reduce((s, p) => s + p[0], 0) / Q.length, cz = Q.reduce((s, p) => s + p[1], 0) / Q.length; return Q.map(p => [cx + (p[0] - cx) * k, cz + (p[1] - cz) * k]); };
      const PC = [{ n: 's', Q: clip(bed, 0.08, 1, SCc(0.08, 1, 2.6 + 4)), h: 2.2, sd: '#d9542a', top: S.rgrad('mks', [[0, '#ffb894'], [0.6, '#ff7c4a'], [1, '#e65a2c']]) },
        { n: 'a', Q: clip(fr, 1, -0.3, SCc(1, -0.3, 54.8 - 2.7)), h: 1.7, sd: '#5e8e30', top: S.rgrad('mka', [[0, '#f8f4ba'], [0.6, '#e6e690'], [1, '#b4c862']]), in: '#eef0b0', ik: 0.55, io: 0.8 },
        { n: 'k', Q: clip(fr, -1, 0.3, SCc(-1, 0.3, -(56.2 - 2.7))), h: 1.4, sd: '#2e6a22', top: S.rgrad('mkk', [[0, '#b6ea80'], [0.6, '#86cc52'], [1, '#4f9a2e']]), in: '#e2f6c0', ik: 0.5, io: 0.85 }];
      const GSH = S.path({ fill: '#d6ccb7', opacity: 0.75 }), GT = [S.path({ fill: '#ffffff', stroke: '#cfc5b0', 'stroke-width': 0.26 }), S.path({ fill: '#fbf9f4', stroke: '#cfc5b0', 'stroke-width': 0.26 }), S.path({ fill: '#efeae0', stroke: '#c4b9a2', 'stroke-width': 0.26 })], ses = S.path({ fill: '#e6c682', stroke: '#b48a42', 'stroke-width': 0.24 });
      const top = S.path({ fill: S.rgrad('mkt', [[0, '#fdfbf7'], [0.6, '#f3efe6'], [1, '#ddd5c4']], { cx: '45%', cy: '40%', r: '65%' }) }), tgr = S.path({ fill: '#ffffff', stroke: '#cfc5b0', 'stroke-width': 0.26 }), tse = S.path({ fill: '#e6c682', stroke: '#b48a42', 'stroke-width': 0.22 });
      const nori = S.path({ fill: '#1f3326' }), bedE = S.path({ fill: '#f1ece0' }), VG = S.g(), scl = S.clip('mksc');
      PC.forEach((p, i) => { p.id = 'v' + i; p.sdE = el('path', { fill: p.sd }, VG); p.e = el('path', { fill: p.top }, VG);
        p.ex = p.n === 's' ? (() => { const g = el('g', { 'clip-path': scl.url }, VG); el('path', { fill: 'none', stroke: '#ffe6d6', 'stroke-width': 2.1, 'stroke-linecap': 'round', opacity: 0.6 }, g); return g; })() : el('path', { fill: p.in, opacity: p.io }, VG); p.QI = p.ik ? shr(p.Q, p.ik) : null; });
      // paws / feet: rice too - a few plump grains + a sesame seed on each (same ellipsoid hook as Khinki's pleats)
      const LGR = Array.from({ length: 9 }, (_, i) => [0.22 + rnd(i * 2.7 + 1) * 0.62, rnd(i * 1.9 + 3) * TAU, rnd(i * 3.3 + 2) * Math.PI]);
      const limb = (q, kind, c, ax, E, R, glob) => {
        if (!q.dec) { q.dec = el('g', {}, q.e.parentNode, q.e.nextSibling); q.dG = el('path', { fill: '#ffffff', stroke: '#cfc5b0', 'stroke-width': 0.24 }, q.dec); q.dS = el('path', { fill: '#e6c682', stroke: '#b48a42', 'stroke-width': 0.22 }, q.dec); }
        const S3 = (th, f) => [Math.sin(th) * Math.sin(f), -Math.cos(th), Math.sin(th) * Math.cos(f)], P2 = s => glob(c[0] + s[0] * ax[0][0] + s[1] * ax[1][0] + s[2] * ax[2][0], c[1] + s[0] * ax[0][1] + s[1] * ax[1][1] + s[2] * ax[2][1]);
        const NZ = s => { let n0 = 0, n1 = 0, n2 = 0; for (let i = 0; i < 3; i++) { const k = s[i] / R[i]; n0 += k * E[i][0]; n1 += k * E[i][1]; n2 += k * E[i][2]; } return n2 / (Math.hypot(n0, n1, n2) || 1); };
        const RA = (R[0] + R[1] + R[2]) / 3; let dg = '', ds = '';
        LGR.forEach(([th, f, o], i) => { const T = th * Math.PI, s = S3(T, f); if (NZ(s) < 0.15) return; const e1 = [Math.cos(f), 0, -Math.sin(f)], e2 = [Math.cos(T) * Math.sin(f), Math.sin(T), Math.cos(T) * Math.cos(f)], sz = i === 4 ? [1.1, 0.55] : [1.5, 0.72];
          const Q = []; for (let k = 0; k < 8; k++) { const t = k / 8 * TAU, a = sz[0] / RA * Math.cos(t), b = sz[1] / RA * Math.sin(t), ca = Math.cos(o), sa = Math.sin(o); Q.push(P2([0, 1, 2].map(j => s[j] * 1.04 + (e1[j] * ca + e2[j] * sa) * a + (-e1[j] * sa + e2[j] * ca) * b))); }
          if (i === 4) ds += polyW(Q); else dg += polyW(Q); });
        SA(q.dG, 'd', dg || 'M0 0'); SA(q.dS, 'd', ds || 'M0 0'); };
      return { R0, YT, AL, rT, SM, SG, TG, SS, TS, GT, GSH, ses, top, tgr, tse, nori, bedE, VG, PC, scl, NO: ringXZ(f => NR(f) + 0.85, 64), BD: ringXZ(NR, 64), limb, rx: 29, ya: 36, yb: 86,
        zE: (dx, dy) => { const r = rT(S.HY + dy); return Math.sqrt(Math.max(0, r * r - dx * dx)) + 0.3; } }; },
    draw(B, D) { const { set } = D, W = tiltW(D, B.AL, 60, B.R0), P = W.P, rT = B.rT, veg = clamp(D.bv('veg'), 0, 1.3), YT = B.YT;
      const hp = []; for (let i = 0; i <= 14; i++) { const y = YT + (88 - YT) * i / 14, r = rT(y); for (let k = 0; k < 24; k++) { const f = k / 24 * TAU; hp.push(P(50 + r * Math.sin(f), y, r * Math.cos(f))); } } B.d = D.hull(hp);
      // an oval lying on a surface: centre c, unit tangents u / v (3D), half sizes a / b, orientation o
      const ovalQ = (c, u, v, a, b, o) => { const ca = Math.cos(o), sa = Math.sin(o), Q = []; for (let k = 0; k < 8; k++) { const t = k / 8 * TAU, A = a * Math.cos(t), Bb = b * Math.sin(t); Q.push(P(c[0] + (u[0] * ca + v[0] * sa) * A + (-u[0] * sa + v[0] * ca) * Bb, c[1] + (u[1] * ca + v[1] * sa) * A + (-u[1] * sa + v[1] * ca) * Bb, c[2] + (u[2] * ca + v[2] * sa) * A + (-u[2] * sa + v[2] * ca) * Bb)); } return Q; }, oval = (c, u, v, a, b, o) => polyW(ovalQ(c, u, v, a, b, o));
      // side grains (raised 0.45 off the rice, so the outline goes lumpy), three tones by how they face the light; sesame
      const g3 = ['', '', '']; let gs = ''; const dx = 0.32 * D.kS, dy = 0.42 * D.kS; B.SG.forEach(([f, y, o]) => { const sf = Math.sin(f), cf = Math.cos(f), r = rT(y) + 0.55, c = [50 + r * sf, y, r * cf], fz = W.F(c[0], c[1], c[2], sf, 0, cf); if (fz < 0.02) return;
        const p0 = P(c[0], c[1], c[2]), p1 = P(c[0] + sf, c[1], c[2] + cf), b = ((p1[0] - p0[0]) / D.kS * LV[0] + (p1[1] - p0[1]) / D.kS * LV[1] + fz * LV[2]); const Q = ovalQ(c, [cf, 0, -sf], [0, 1, 0], 1.85, 0.88, o); g3[b > 0.45 ? 0 : b > 0.12 ? 1 : 2] += polyW(Q); gs += polyW(Q.map(q => [q[0] + dx, q[1] + dy])); });
      B.GT.forEach((e, i) => set(e, 'd', g3[i] || 'M0 0')); set(B.GSH, 'd', gs || 'M0 0');
      let sd = ''; B.SS.forEach(([f, y, o]) => { const sf = Math.sin(f), cf = Math.cos(f), r = rT(y) + 0.5, c = [50 + r * sf, y, r * cf]; if (W.F(c[0], c[1], c[2], sf, 0, cf) < 0.06) return; sd += oval(c, [cf, 0, -sf], [0, 1, 0], 1.15, 0.55, o); }); set(B.ses, 'd', sd || 'M0 0');
      // the cut end: rice ring with grains + sesame, the nori ring, the bed
      const ring = (r, y, n) => Array.from({ length: n }, (_, k) => { const f = k / n * TAU; return P(50 + r * Math.sin(f), y, r * Math.cos(f)); }); set(B.top, 'd', polyW(ring(B.R0, YT, 48)));
      const TP = (x, z, h) => P(x, YT - (h || 0), z); let tg = '', ts = ''; B.TG.forEach(([r, f, o]) => { tg += oval([50 + r * Math.sin(f), YT - 0.12, r * Math.cos(f)], [1, 0, 0], [0, 0, 1], 1.65, 0.8, o); }); B.TS.forEach(([r, f, o]) => { ts += oval([50 + r * Math.sin(f), YT - 0.14, r * Math.cos(f)], [1, 0, 0], [0, 0, 1], 1.15, 0.55, o); });
      set(B.tgr, 'd', tg); set(B.tse, 'd', ts); set(B.nori, 'd', polyW(B.NO.map(([x, z]) => TP(x, z, 0.05)))); set(B.bedE, 'd', polyW(B.BD.map(([x, z]) => TP(x, z, 0.08))));
      // the filling pieces, back to front: side wall (darker) + lit top (+ salmon fat bands / avocado + cucumber pale middles); veg pops them up and wiggles them
      const L = B.PC.map((p, i) => { const h = p.h * (1 + veg * 0.6) + veg * 1.2 * Math.max(0, Math.sin(D.ts * 9 + i * 1.7)), sw = D.ox * 0.06 + veg * Math.sin(D.ts * 11 + i) * 0.5, bot = p.Q.map(([x, z]) => TP(x, z, 0.1)), tp = p.Q.map(([x, z]) => TP(x + sw, z, h));
        set(p.sdE, 'd', D.hull(bot.concat(tp))); const td = polyW(tp); set(p.e, 'd', td);
        if (p.n === 's') { set(B.scl.p, 'd', td); set(p.ex.firstChild, 'd', [37.5, 46.5].map(x0 => 'M' + Array.from({ length: 12 }, (_, k) => { const q = B.SM(x0 + k * 1.05, -14.5 + k * 1.45); return pt(TP(q[0] + sw, q[1], h + 0.02)); }).join('L')).join('')); }
        else set(p.ex, 'd', polyW(p.QI.map(([x, z]) => TP(x + sw, z, h + 0.02))));
        const cx = p.Q.reduce((s, q) => s + q[0], 0) / p.Q.length, cz = p.Q.reduce((s, q) => s + q[1], 0) / p.Q.length; return { id: p.id, e: p.sdE, ex: [p.e, p.ex], z: W.Z(cx, YT - h / 2, cz) }; }).sort((a, b) => a.z - b.z);
      const ord = []; L.forEach(l => { ord.push(l); l.ex.forEach((e, j) => ord.push({ id: l.id + 'x' + j, e })); }); SN.order(B.VG, ord); }
  };

  // ================= Noodle v2 (Nov 10, user: 'ramen ... he does not look like ramen, needs to look really like him' + 'the food on top doesn't look realistic
  // enough' - v1 was a white cup with a big foil lid): a bowl of ramen. The bowl is a body of revolution seen a touch from above (EL .178) whose profile is
  // the art's side outline lifted by EL * r, so the rim circle (r 37 at y 52.6) lands exactly on the art's rim ellipse; the red rim stripe and the square-
  // spiral band run all the way round. In the opening, everything is the art's own drawing (data-k="top", one data-s group per piece): the broth; the things
  // lying on it (oil drops, sesame, onion rings) laid flat on the broth plane; the two nori sheets as flat standing sheets that turn with him (edge-on from
  // the side); the noodle heap, egg, two naruto and the chashu as art sprites standing on the broth at their own 3D spots (they go round with the bowl,
  // depth-sorted, always showing their drawn side). The chopsticks are 3D. Channels: lid (-1..1.2: the chopsticks lift a pinch of noodles up (+) / dip
  // (-)), slurp (0..1.2: noodles slurp up out of the heap), steam via emit.
  MODELS.noodle = {
    setup(S) { const EL = 0.178, O = S.outline(S.sk, 96), sid = q => { const g = q.e.closest && q.e.closest('[data-s]'); return g ? g.getAttribute('data-s') : ''; };
      const PR = []; for (let ys = 46; ys <= 86.6; ys += 0.4) { const r = halfW(O, ys); if (r > 0.5) PR.push([ys + EL * r, r]); } PR.sort((p, q) => p[0] - q[0]);
      const Y0 = PR[0][0], Y1 = PR[PR.length - 1][0], rT = y => { y = clamp(y, Y0, Y1); let i = 1; while (i < PR.length - 1 && PR[i][0] < y) i++; const p = PR[i - 1], q = PR[i], t = q[0] > p[0] ? (y - p[0]) / (q[0] - p[0]) : 0; return p[1] + (q[1] - p[1]) * t; };
      const hid = S.hide(q => q.inBody && S.dk(q, 'top') && ['rim', 'broth', 'lip', 'sticks'].includes(sid(q))), bro = hid.find(q => sid(q) === 'broth'), BF = bro ? S.f(bro) : '#efb35c', sk0 = hid.find(q => sid(q) === 'sticks'), CK = sk0 ? S.f(sk0) : '#d9a868';
      S.hide(q => q.inBody && !S.dk(q) && (S.f(q) === '#e2402e' || S.s(q) === '#e2402e'));
      const sh = S.path({ fill: S.lgrad('ndsh', [[0, '#8a7a66', 0.3], [0.15, '#8a7a66', 0.06], [0.3, '#ffffff', 0.4], [0.46, '#ffffff', 0], [0.76, '#6a5a46', 0.05], [1, '#6a5a46', 0.34]]) });
      const bd = S.path({ fill: '#e2402e' }), rm = S.path({ fill: 'none', stroke: '#e2402e', 'stroke-width': 1.0, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' });
      const rimB = S.path({ fill: '#fbf3e6' }), rimI = S.path({ fill: '#efe4d2' }), broth = S.path({ fill: BF }), FG = S.g(), TG = S.g(), rimF = S.path({ fill: '#fbf3e6' }), rimL = S.path({ fill: 'none', stroke: '#ffffff', 'stroke-width': 0.8, opacity: 0.8 });
      const FL = S.decals(q => q.inBody && sid(q) === 'flat', FG);
      const box = D_ => { let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9; D_.forEach(o => o.L.forEach(L => L.forEach(p => { if (p[0] < x0) x0 = p[0]; if (p[0] > x1) x1 = p[0]; if (p[1] < y0) y0 = p[1]; if (p[1] > y1) y1 = p[1]; }))); return { x0, x1, y0, y1 }; };
      const SP = ['chashu', 'heap', 'egg', 'nar1', 'nar2'].map(n => { const g = el('g', {}, TG), D_ = S.decals(q => q.inBody && sid(q) === n, g), b = box(D_), h = b.y1 - b.y0; return { n, g, D: D_, ax: (b.x0 + b.x1) / 2, ay: b.y1 - Math.min(2.2, h * 0.3), lag: n === 'heap' ? 1 : 0.5 }; });
      const hp = SP.find(o => o.n === 'heap'); hp.sl = [0, 1, 2].map(() => el('path', { fill: 'none', stroke: '#b07c22', 'stroke-width': 2.2, 'stroke-linecap': 'round' }, hp.g)); hp.sl2 = [0, 1, 2].map(() => el('path', { fill: 'none', stroke: '#ffd65e', 'stroke-width': 1.5, 'stroke-linecap': 'round' }, hp.g));
      const NS = ['nori1', 'nori2'].map(n => { const g = el('g', {}, TG), D_ = S.decals(q => q.inBody && sid(q) === n, g), b = box(D_); return { n, g, D: D_, yb: b.y1 - 0.6, cx: (b.x0 + b.x1) / 2 }; });
      const SG = el('g', {}, TG), hang = el('path', { fill: 'none', stroke: '#b07c22', 'stroke-width': 2.2, 'stroke-linecap': 'round' }, SG), hang2 = el('path', { fill: 'none', stroke: '#ffd65e', 'stroke-width': 1.5, 'stroke-linecap': 'round' }, SG);
      const ck = S.lgrad('ndck', [[0, '#f4d6a4'], [0.5, '#d9a868'], [1, '#a87a44']], { x1: 0, y1: 0, x2: 0, y2: 1 }), sticks = [0, 1].map(() => el('path', { fill: CK.startsWith('url') ? ck : CK }, SG));
      return { EL, O, rT, Y0, Y1, YR: Y0, YB: Y0 + 0.3, R0: rT(Y0), sh, bd, rm, rimB, rimI, broth, FG, TG, rimF, rimL, FL, SP, NS, SG, hang, hang2, sticks, rx: 34, ya: 55, yb: 86,
        zE: (dx, dy) => { const r = rT(S.HY + dy); return Math.sqrt(Math.max(0, r * r - dx * dx)) + 0.3; } }; },
    draw(B, D) { const { Z3, set } = D, { EL, rT, YR, YB, R0 } = B, PE = PEf(D, EL, rT), slurp = clamp(D.bv('slurp'), 0, 1.2), lid = clamp(D.bv('lid'), -1, 1.2), ts = D.ts;
      const RP = (r, y, f) => PE(50 + r * Math.sin(f), y, r * Math.cos(f)), ring = (r, y, n) => Array.from({ length: n }, (_, i) => RP(r, y, i / n * TAU));
      const hp = []; for (let i = 0; i <= 16; i++) { const y = B.Y0 + (B.Y1 - B.Y0) * i / 16; ring(rT(y), y, 28).forEach(p => hp.push(p)); } B.d = D.hull(hp); set(B.sh, 'd', B.d);
      // red rim stripe + the square spirals, all the way round (only what faces you)
      const A = SN.h.frontArc(D, 34, 58, 72); if (A.length > 1) set(B.bd, 'd', polyW(A.map(f => RP(rT(55.4) + 0.05, 55.4, f)).concat(A.slice().reverse().map(f => RP(rT(57.1) + 0.05, 57.1, f))))); else set(B.bd, 'd', 'M0 0');
      const yS = 58.8, hS = 4.0, rS = rT(yS + hS / 2) + 0.08, nS = Math.round(TAU * rS / 7.4), wS = TAU / nS, q = 0.82, SPI = [[0, 1], [0, 0], [q, 0], [q, 0.8], [q * 0.25, 0.8], [q * 0.25, 0.3], [q * 0.62, 0.3], [q * 0.62, 0.55]];
      let rd = ''; for (let i = 0; i < nS; i++) { const f0 = (i - 0.41) * wS, fm = f0 + 0.41 * wS; if (D.facing(50 + rS * Math.sin(fm), yS, rS * Math.cos(fm), Math.sin(fm), 0, Math.cos(fm)) < 0.08) continue;
        rd += 'M' + SPI.map(([u, v]) => { const f = f0 + u * wS, y = yS + v * hS, r = rT(y) + 0.08; return pt(RP(r, y, f)); }).join('L'); } set(B.rm, 'd', rd || 'M0 0');
      // rim, inner wall at the back, broth
      set(B.rimB, 'd', polyW(ring(37, YR, 56))); set(B.rimI, 'd', polyW(ring(35.2, YR + 0.1, 56))); set(B.broth, 'd', polyW(ring(33.6, YB, 56)));
      const zOf = y => (y - YB) / EL + R0;
      B.FL.forEach(o => set(o.e, 'd', decD(o, (x, y) => PE(x, YB, zOf(y)))));
      const L = [];
      // sprites: the art piece stands on the broth at its spot; its size follows the bowl's local stretch there
      B.SP.forEach(sp => { const A3 = [sp.ax + D.ox * 0.05 * sp.lag, YB, zOf(sp.ay)], C = PE(A3[0], A3[1], A3[2]), cy = PE(A3[0], A3[1] + 1, A3[2]), kx = D.kS, ky = Math.hypot(cy[0] - C[0], cy[1] - C[1]);   // facing you: width = the body's scale, not the turn
        const sy = sp.n === 'heap' ? 1 - 0.1 * slurp : 1, oy = -D.oy * 0.08 * sp.lag;
        sp.D.forEach(o => set(o.e, 'd', decD(o, (x, y) => [C[0] + (x - sp.ax) * kx, C[1] + (y - sp.ay) * ky * sy + oy])));
        if (sp.sl) { const top = [C[0], C[1] - 9 * ky * sy]; sp.sl.forEach((e, j) => { let d = ''; if (slurp > 0.03) { const h = 13 * slurp, x0 = top[0] + (j - 1) * 3.2 * kx; for (let i = 0; i <= 14; i++) { const u = i / 14; d += (i ? 'L' : 'M') + r2(x0 + 1.1 * kx * Math.sin(u * 9 + j * 2.1 + ts * 9)) + ' ' + r2(top[1] - h * u * ky); } } set(e, 'd', d || 'M0 0'); set(sp.sl2[j], 'd', d || 'M0 0'); }); }
        L.push({ id: sp.n, e: sp.g, z: Z3(A3[0], A3[1], A3[2]) }); });
      // nori: flat sheets standing at their own depth, swaying a beat behind the moves
      B.NS.forEach(sh => { const z = zOf(sh.yb), sw = clamp(-D.ox * 0.05, -0.6, 0.6); sh.D.forEach(o => set(o.e, 'd', decD(o, (x, y) => { const up = Math.max(0, sh.yb - y) / 20; return PE(x + sw * up * 5, y - EL * (z - R0) + up * up * 0.3, z - up * 1.5); })));
        L.push({ id: sh.n, e: sh.g, z: Z3(sh.cx, YB - 8, z) - 4 }); });
      // chopsticks: tips in the noodles, ends up over the right rim; lid lifts them with a pinch of noodles hanging from the tips (or dips them)
      const zt = zOf(46.4), ze = zt - 9, lf = Math.max(0, lid), dp = Math.min(0, lid), T = [[53.8, 39.6], [56.8, 41.2]], E = [[88.6, 13.4], [92.4, 17.4]];
      const tips = []; B.sticks.forEach((e, i) => { const t3 = [T[i][0] - 2 * lf, T[i][1] - EL * (zt - R0) - 11 * lf - 2.5 * dp, zt], e3 = [E[i][0] - 5 * lf + 2 * dp, E[i][1] - EL * (ze - R0) - 8 * lf - 3 * dp, ze], a = PE(t3[0], t3[1], t3[2]), b = PE(e3[0], e3[1], e3[2]);
        const dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1, nx = -dy / l, ny = dx / l, w0 = 0.72 * D.kS, w1 = 1.15 * D.kS; tips.push(t3);
        set(e, 'd', polyD([[a[0] + nx * w0, a[1] + ny * w0], [b[0] + nx * w1, b[1] + ny * w1], [b[0] - nx * w1, b[1] - ny * w1], [a[0] - nx * w0, a[1] - ny * w0]])); });
      let hd = ''; if (lf > 0.04) { const m3 = [(tips[0][0] + tips[1][0]) / 2, (tips[0][1] + tips[1][1]) / 2 + 0.6, zt], b3 = [48, YB - 8, zt + 3];
        for (let j = 0; j < 4; j++) { const Q = []; for (let i = 0; i <= 16; i++) { const u = i / 16, x = m3[0] + (b3[0] - m3[0]) * u + (j - 1.5) * 1.1 * u + 1.2 * Math.sin(u * 10 + j * 1.9 + ts * 4) * Math.sin(u * Math.PI), y = m3[1] + (b3[1] - m3[1]) * u, z = m3[2] + (b3[2] - m3[2]) * u; Q.push(PE(x, y, z)); } hd += runs(Q, Q.map(() => true)); } }
      set(B.hang, 'd', hd || 'M0 0'); set(B.hang2, 'd', hd || 'M0 0');
      L.push({ id: 'st', e: B.SG, z: Z3(70, YB - 12, zt) + 1 });
      L.sort((a, b) => a.z - b.z); SN.order(B.TG, L);
      // the front lip of the rim covers the near edge of the broth
      const FA = SN.h.frontArc(D, 37, YR, 72); set(B.rimF, 'd', FA.length > 1 ? polyW(FA.map(f => RP(37.2, YR, f)).concat(FA.slice().reverse().map(f => RP(33.4, YB, f)))) : 'M0 0'); set(B.rimL, 'd', FA.length > 1 ? runs(FA.map(f => RP(36.3, YR - 0.05, f)), FA.map(() => true)) : 'M0 0'); }
  };

  // ================= Flossie: cotton candy. A soft round sugar cloud (the face sits on it) wrapped in 3D puffs of pink and blue floss that keep
  // their places round her as she turns (the ones round the back go behind), on a striped paper stick. Channels: fluff (0..1.5: the floss poofs up),
  // swirl (turns: the puffs swirl round her), she sparkles now and then.
  MODELS.flossie = {
    setup(S) { const { sk } = S, C = [50, 51], R = 28, pf = S.hide(q => q.inBody && q.tag === 'circle' && q !== S.sk && /^url/.test(S.f(q)));
      const PF = (pf.find(q => /#p_/.test(S.f(q)) || /url\(#p/.test(S.f(q))) || {}), BF = (pf.find(q => /url\(#b/.test(S.f(q))) || {}); const fP = PF.e ? S.f(PF) : '#ffbede', fB = BF.e ? S.f(BF) : '#b8e0ff';
      const st = S.hide(q => q.inBody && /^M46 74/.test(S.d(q)))[0]; S.hide(q => q.inBody && (S.s(q) === '#ff8ac4' || S.s(q) === '#ffffff' || S.s(q) === '#b8e0ff')); S.hide(q => !q.inBody && q.tag === 'path' && q.role === 'face' && q.cy < 40);
      const stick = el('path', { fill: st ? S.f(st) : '#ffffff' }, S.gB), sts = el('path', { fill: 'none', stroke: '#ff8ac4', 'stroke-width': 1.3, 'stroke-linecap': 'round' }, S.gB), BG = el('g', {}, S.gB), FG = S.g();
      const sP = S.rgrad('flp', [[0, '#fff3f9'], [0.55, '#ffcbe5'], [1, '#f7afd3']], { cx: '42%', cy: '36%', r: '68%' }), sB = S.rgrad('flb', [[0, '#f4fbff'], [0.55, '#cbe8ff'], [1, '#a6d2f6']], { cx: '42%', cy: '36%', r: '68%' });
      const PU = []; const n = 34; for (let i = 0; i < n; i++) { const yy = 1 - 2 * (i + 0.5) / n, rr = Math.sqrt(1 - yy * yy), a = i * 2.39996, dx = rr * Math.cos(a), dz = rr * Math.sin(a), dy = -yy;
        if (dz > 0.3 && dy > -0.55) continue; if (dy > 0.8) continue; PU.push({ d: [dx, dy, dz], rho: R - 3 + rnd(i) * 3, r: 10 + rnd(i * 3) * 4, c: i % 3 === 1 ? sB : sP, id: 'u' + i }); }
      PU.forEach(o => { o.e = el('path', { fill: o.c }, BG); });
      const wisp = S.path({ fill: 'none', stroke: '#ffffff', 'stroke-width': 1.4, opacity: 0.55, 'stroke-linecap': 'round' }), wisp2 = S.path({ fill: 'none', stroke: '#b8e0ff', 'stroke-width': 1.8, opacity: 0.85, 'stroke-linecap': 'round' }), spk = S.path({ fill: '#ffffff', opacity: 0.95 });
      return { C, R, PU, BG, FG, stick, sts, wisp, wisp2, spk, rx: 28, ya: 30, yb: 76, rT: y => Math.sqrt(Math.max(0, R * R - (y - C[1]) * (y - C[1]))),
        zE: (dx, dy) => Math.sqrt(Math.max(0, R * R - dx * dx - dy * dy)) + 0.3 }; },
    draw(B, D) { const { P3, Z3, set } = D, { C, R } = B, fl = clamp(D.bv('fluff'), 0, 1.6), sw = D.bv('swirl') * TAU, ts = D.ts;
      const sp = []; for (let i = 0; i <= 8; i++) { const th = -Math.PI / 2 + Math.PI * i / 8, cr = Math.cos(th); for (let k = 0; k < 20; k++) { const f = k / 20 * TAU; sp.push(P3(C[0] + R * cr * Math.sin(f), C[1] + R * Math.sin(th), R * cr * Math.cos(f))); } } B.d = D.hull(sp);
      set(B.stick, 'd', SN.h.tubeD(D, [[50, 76, 0], [50, 97.4, 0]], [3.7, 3.3]));
      let sd = ''; [80, 85.5, 91, 96].forEach(y0 => { const Q = [], ok = []; for (let j = 0; j <= 8; j++) { const a = -1.4 + j / 8 * 2.8, y = y0 + j * 0.42, r = 3.75; Q.push(P3(50 + r * Math.sin(a), y, r * Math.cos(a))); ok.push(D.facing(50 + r * Math.sin(a), y, r * Math.cos(a), Math.sin(a), 0, Math.cos(a)) > 0); } sd += runs(Q, ok); }); set(B.sts, 'd', sd || 'M0 0');
      const L = B.PU.map((o, i) => { const ca = Math.cos(sw), sa = Math.sin(sw), dx = o.d[0] * ca + o.d[2] * sa, dz = -o.d[0] * sa + o.d[2] * ca, rho = o.rho * (1 + fl * 0.1) + Math.sin(ts * 1.3 + i) * 0.4, up = clamp(-o.d[1], 0, 1),
          x = C[0] + rho * dx + D.ox * 0.2 * up, y = C[1] + rho * o.d[1] - D.oy * 0.25 * up, z = rho * dz, c = P3(x, y, z), zz = Z3(x, y, z); set(o.e, 'd', circD(c, o.r * (1 + fl * 0.22) * D.kS)); return { id: o.id, e: o.e, z: zz }; }).sort((a, b) => a.z - b.z);
      L.forEach(l => { const tg = l.z > 6 ? B.FG : B.BG; if (l.e.parentNode !== tg) tg.appendChild(l.e); }); SN.order(B.BG, L.filter(l => l.z <= 6)); SN.order(B.FG, L.filter(l => l.z > 6));
      const S3 = (x, y) => { const dz = Math.sqrt(Math.max(0, R * R - (x - C[0]) * (x - C[0]) - (y - C[1]) * (y - C[1]))); return [P3(x, y, dz + 0.2), D.facing(x, y, dz, x - C[0], y - C[1], dz) > 0.5]; };
      const wl = (pts) => { const Q = pts.map(p => S3(p[0], p[1])); return runs(Q.map(q => q[0]), Q.map(q => q[1])); };
      set(B.wisp, 'd', wl([[33, 40], [38, 36], [44, 34.5], [50, 35.5], [56, 37.5], [61, 37], [66, 34]]) || 'M0 0'); set(B.wisp2, 'd', wl([[28, 70], [33, 73], [38, 74.5], [43, 73], [47, 71]]) || 'M0 0');
      let kd = ''; [[24, 20, 0], [78, 16, 1.7], [88, 36, 3.1]].forEach(([x, y, ph]) => { const a = Math.max(0, Math.sin(ts * 2.1 + ph)), s = (1.2 + 1.4 * a) * D.kS, p = P3(x, y, 0); if (a > 0.05) kd += 'M' + r2(p[0]) + ' ' + r2(p[1] - s) + 'L' + r2(p[0] + s * 0.3) + ' ' + r2(p[1] - s * 0.3) + 'L' + r2(p[0] + s) + ' ' + r2(p[1]) + 'L' + r2(p[0] + s * 0.3) + ' ' + r2(p[1] + s * 0.3) + 'L' + r2(p[0]) + ' ' + r2(p[1] + s) + 'L' + r2(p[0] - s * 0.3) + ' ' + r2(p[1] + s * 0.3) + 'L' + r2(p[0] - s) + ' ' + r2(p[1]) + 'L' + r2(p[0] - s * 0.3) + ' ' + r2(p[1] - s * 0.3) + 'Z'; }); set(B.spk, 'd', kd || 'M0 0'); }
  };
})();
