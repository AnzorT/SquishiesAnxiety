// Renovation Catalog round 7: Dance Room portable audio remodel.
// CLB-018 retro chrome boombox (dual cones, working cassette door, neatly coiled aux cable), CLB-002 pro active PA cabinet on a metal tripod
// (tactile knobs, glowing power LED, click-to-play sound check). Both play through the speaker jam (role spk, st 'play'). Sets RenoDraw.PLUS6; edits RD.SET6.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS5 && RD.H3 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS6) return;
  const K = X.K, { solid, box, cyl, slab, slabX, disc, f1 } = K;
  const { rep, rng, n4, P2, plane, planeX, planeH, an, BLUR, bbOf, mt, cer, pt } = RD.H3;
  const N = RD.N, CH = '#d5dde2';
  const isPlay = S => /play/.test(S.st || '');
  const G = (id, stops, a) => '<radialGradient id="' + id + '" ' + (a || 'cx="36%" cy="32%" r="72%"') + '>' + stops.map(s => '<stop offset="' + s[0] + '" stop-color="' + s[1] + '"/>').join('') + '</radialGradient>';
  const L = (id, stops, a) => '<linearGradient id="' + id + '" ' + (a || 'x1="0" y1="0" x2="0" y2="1"') + '>' + stops.map(s => '<stop offset="' + s[0] + '" stop-color="' + s[1] + '"' + (s[2] != null ? ' stop-opacity="' + s[2] + '"' : '') + '/>').join('') + '</linearGradient>';
  const once = (type, vals, kt, d, b) => '<animateTransform attributeName="transform" type="' + type + '" values="' + vals + '" keyTimes="' + kt + '" dur="' + d + 's"' + (b ? ' begin="' + b + 's"' : '') + ' fill="freeze"/>';
  const loopT = (type, vals, d, b) => '<animateTransform attributeName="transform" type="' + type + '" values="' + vals + '" dur="' + n4(d) + 's"' + (b ? ' begin="' + n4(b) + 's"' : '') + ' repeatCount="indefinite"/>';
  const pulse = (d, b) => '<animateTransform attributeName="transform" type="scale" values="1;1.07;1" keyTimes="0;0.3;1" calcMode="spline" keySplines="0.2 0 0.4 1;0.45 0 0.55 1" dur="' + d + 's"' + (b ? ' begin="' + b + 's"' : '') + ' repeatCount="indefinite"/>';
  const NOTE = c => '<path d="M0 0V-7L5 -8.6V-1.6" fill="none" stroke="' + c + '" stroke-width="1"/><ellipse cx="-1.3" cy="0.2" rx="1.6" ry="1.2" fill="' + c + '"/><ellipse cx="3.7" cy="-1.4" rx="1.6" ry="1.2" fill="' + c + '"/>';
  const notes = (o, n, k, seed, b0) => rep(n, i => { const R2 = rng(seed + i), s = i % 2 ? 1 : -1, dx = s * (8 + R2() * 16) * k, dy = -(34 + R2() * 22) * k, b = n4((b0 || 0) - i * 0.5), c = ['#3ff0ff', '#ff4fb8', '#ffe14f'][i % 3];
    return '<g transform="translate(' + P2(o) + ')"><animateTransform attributeName="transform" type="translate" values="' + P2(o) + ';' + f1(o[0] + dx) + ' ' + f1(o[1] + dy) + '" dur="2.4s" begin="' + b + 's" repeatCount="indefinite"/>' + an('opacity', '0;1;1;0', 2.4, b) + '<g transform="scale(' + n4(k * 0.95) + ')">' + NOTE(c) + '</g></g>'; }).join('');
  const tube = (a, b, w, k, c) => { const d = 'M' + P2(a) + 'L' + P2(b); return '<path d="' + d + '" stroke="#0a0a0d" stroke-width="' + f1((w + 0.6) * k) + '" stroke-linecap="round"/><path d="' + d + '" stroke="' + (c || '#2c2e35') + '" stroke-width="' + f1(w * k) + '" stroke-linecap="round"/><path d="' + d + '" stroke="#9aa1ad" stroke-width="' + f1(w * 0.28 * k) + '" stroke-linecap="round" opacity="0.6" transform="translate(' + f1(-0.22 * w * k) + ' ' + f1(-0.22 * w * k) + ')"/>'; };

  // ======================= RETRO 80s CHROME BOOMBOX =======================
  N.boom80 = S => { const play = isPlay(S), BODY = '#c9cfd6', FAS = '#1f2127', IN = 1.4;
    const D = { w: 112, d: 34 };
    D.build = P => { const o = [];
      [[-34, -6], [34, -6], [-34, 6], [34, 6]].forEach(([x, z]) => o.push(box(x, 0, z, 6, 2, 4, '#141418', pt({ r: 0.8 }))));
      o.push(box(0, 2, 0, 84, 46, 20, BODY, mt({ r: 4, shine: 1 })), slab(0, 4, 10.05, 80, 42, 0.6, FAS, mt({ r: 2.5 })));
      [-25, 25].forEach(x => o.push(disc(x, 21, 10.7, 13.4, 1, CH, mt({ n: 28, shine: 1 })), disc(x, 21, 11.7, 12, 0.4, '#101115', { n: 28 }), disc(x, 40.5, 10.7, 4.2, 0.8, CH, mt({ n: 16, shine: 1 }))));
      o.push(slab(0, 8, 10.7, 22, 22, 0.5, '#2a2c33', mt({ r: 1 })), slab(0, 32.6, 10.7, 22, 9.4, 0.5, '#0b0d12', cer({ r: 1 })));
      rep(6, i => { const x = -13.75 + i * 5.5, dn = play && i === 1; o.push(box(x, 48, 4.5, 5, dn ? 1 : 2.4, 7, i === 1 ? '#3a8f5a' : i === 0 ? '#c93a3a' : '#2a2c33', pt({ r: 0.6 }))); });
      [-24, 24].forEach(x => o.push(cyl(x, 48, -4.5, 3, 2.4, '#2a2c33', mt({ n: 16 })), cyl(x, 50.4, -4.5, 2.2, 0.8, CH, mt({ n: 14, shine: 1 }))));
      [-34, 34].forEach(x => o.push(cyl(x, 48, 0, 1.9, 8, CH, mt({ n: 10, shine: 1 }))));
      o.push(solid({ ax: 'x', sh: 'el', c: [0, 56.4], a: 1.8, b: 1.8, n: 10, rings: [[-35.5, 0], [35.5, 0]], col: CH, mat: 'metal', shine: 1 }), solid({ ax: 'x', sh: 'el', c: [0, 56.4], a: 2.7, b: 2.7, n: 12, rings: [[-16, 0], [16, 0]], col: '#1d1e22', mat: 'metal' }));
      o.push(cyl(38, 48, -6, 1.7, 2.2, CH, mt({ n: 10, shine: 1 })), slabX(42.1, 8, 5, 0.5, 8, 9, '#2a2c33', mt({ r: 1 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', un = '';
      // front fascia (local u = x + 40, v = 46 - y)
      let s = '';
      [15, 65].forEach((cx, i) => { s += '<g transform="translate(' + cx + ' 25)"><g>' + (play ? pulse(0.5, IN) : '') + '<circle r="12" fill="#17181d"/><circle r="11.3" fill="none" stroke="#ffffff" stroke-width="0.5" stroke-dasharray="9 62" stroke-dashoffset="-46" opacity="0.28"/>'
          + '<circle r="10.4" fill="url(#bxCone)"/>' + [8.6, 6.8].map(r => '<circle r="' + r + '" fill="none" stroke="#2c2e36" stroke-width="0.4"/>').join('') + '<path d="M-7 -5.6A9 9 0 0 1 2 -8.8" fill="none" stroke="#ffffff" stroke-width="0.7" opacity="0.18"/>'
          + '<circle r="3.6" fill="url(#bxCap)" stroke="#2a2c33" stroke-width="0.3"/><ellipse cx="-1.1" cy="-1.3" rx="1.3" ry="0.8" fill="#ffffff" opacity="0.75"/></g></g>';
        s += '<g transform="translate(' + cx + ' 5.5)"><circle r="3.4" fill="#141518"/><circle r="2.6" fill="url(#bxCap)"/><ellipse cx="-0.8" cy="-0.9" rx="0.9" ry="0.55" fill="#ffffff" opacity="0.7"/></g>'; });
      // tuner window + VU meter
      s += '<rect x="29.6" y="4.4" width="20.8" height="8.2" rx="0.8" fill="#0b0f1a"/><text x="40" y="7.4" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="1.7" fill="#ffcf7a" letter-spacing="0.25">88  92  96  100  104  108</text>'
        + rep(21, i => '<path d="M' + f1(31 + i * 0.9) + ' 8.1V' + (i % 5 ? 8.6 : 9) + '" stroke="#ffcf7a" stroke-width="0.18"/>').join('') + '<path d="M41.2 5V9.6" stroke="#ff3b3b" stroke-width="0.4"/>'
        + '<text x="31" y="11.8" font-family="Arial, sans-serif" font-weight="800" font-size="1.3" fill="' + (play ? '#ff5a4a' : '#5a3a3a') + '">FM STEREO</text>';
      rep(8, i => { const col = i > 6 ? '#ff3b3b' : i > 4 ? '#ffd84f' : '#4dff7a'; s += '<rect x="' + f1(38.6 + i * 1.4) + '" y="10.6" width="1" height="1.2" rx="0.2" fill="' + col + '" opacity="' + (play ? 1 : 0.18) + '">' + (play ? '<animate attributeName="opacity" values="' + rep(6, t => (t * 5 + i * 3) % 8 >= i ? 1 : 0.15).join(';') + '" dur="0.5s" calcMode="discrete" repeatCount="indefinite"/>' : '') + '</rect>'; });
      s += '<text x="40" y="15.2" text-anchor="middle" font-family="Arial Black, Arial, sans-serif" font-weight="900" font-style="italic" font-size="2.3" fill="url(#bxChr)" letter-spacing="0.3">SQUISH-BOX 2000</text>';
      // cassette deck: well, tape (reels roll once the door shuts), smoked flip-down door
      s += '<rect x="29.4" y="16.4" width="21.2" height="21.2" rx="0.8" fill="#0d0e12"/><g clip-path="url(#bxWell)"><g>' + (play ? once('translate', '0 -18;0 -18;0 0;0 0', '0;0.3;0.62;1', 1.4) : '') + '<rect x="30.6" y="19" width="18.8" height="13.2" rx="0.9" fill="#26272e" stroke="#0a0a0d" stroke-width="0.3"/>'
        + '<rect x="31.6" y="19.8" width="16.8" height="3.8" rx="0.4" fill="#f2ead6"/><path d="M31.6 22.2H48.4" stroke="#e8343c" stroke-width="0.6"/><text x="32.4" y="21.6" font-family="Comic Sans MS, Marker Felt, cursive" font-weight="700" font-size="1.5" fill="#2a2a30">PARTY MIX</text>'
        + '<rect x="34" y="24.6" width="12" height="5" rx="2.4" fill="#100f14"/>';
      [[36.6, 3], [43.4, 2.2]].forEach(([x, r], i) => { s += '<circle cx="' + x + '" cy="27.1" r="' + r + '" fill="#4a3424"/><g transform="translate(' + x + ' 27.1)"><g>' + (play ? loopT('rotate', '0;360', i ? 1.4 : 1.9, IN) : '') + '<circle r="1.25" fill="#f4f6f8"/>' + rep(6, j => '<rect x="-0.18" y="-1.25" width="0.36" height="0.5" fill="#26272e" transform="rotate(' + j * 60 + ')"/>').join('') + '<circle r="0.4" fill="#26272e"/></g></g>'; });
      s += '<path d="M33 32.2L34 30.6H46L47 32.2Z" fill="#1d1e24"/></g></g>';
      const door = '<rect x="29.8" y="16.8" width="20.4" height="20.6" rx="0.8" fill="#9fb4c8" fill-opacity="0.16" stroke="url(#bxChr)" stroke-width="0.6"/><path d="M31 18.2L37 18.2L31 26Z" fill="#ffffff" opacity="0.12"/><rect x="33.4" y="24" width="13.2" height="6.2" rx="0.6" fill="none" stroke="#d5dde2" stroke-width="0.25" opacity="0.6"/>'
        + '<text x="40" y="36.4" text-anchor="middle" font-family="Arial, sans-serif" font-weight="800" font-size="1.25" fill="#c9cdd2" letter-spacing="0.4">AUTO REVERSE</text><rect x="37.6" y="16.8" width="4.8" height="0.9" rx="0.3" fill="url(#bxChr)"/>';
      s += '<g transform="translate(0 37.4)"><g>' + (play ? once('scale', '1 1;1 0.16;1 0.16;1 1', '0;0.26;0.66;1', 1.4) : '') + '<g transform="translate(0 -37.4)">' + door + '</g></g></g>';
      [[2.2, 2.2], [77.8, 2.2], [2.2, 39.8], [77.8, 39.8]].forEach(([x, y]) => s += '<circle cx="' + x + '" cy="' + y + '" r="0.55" fill="url(#bxCap)"/>');
      f += '<g transform="' + plane(p, 10.95, 46, -40) + '">' + s + '</g>';
      // top keys labels
      { let t = ''; ['●', '▶', '◀◀', '▶▶', '■', '⏏'].forEach((g2, i) => t += '<text x="' + f1(26.25 + i * 5.5) + '" y="0.9" text-anchor="middle" font-family="Arial, sans-serif" font-weight="800" font-size="1.7" fill="#f4f6f8">' + g2 + '</text>'); f += '<g transform="' + planeH(p, play ? 49.1 : 50.5, -40, 4.5) + '">' + t + '</g>'; }
      // telescopic antenna
      { const a = p(38, 50.2, -6), b = p(45, 68, -9), cc = p(51, 84, -11.5), d = p(56, 98, -13.5);
        f += '<path d="M' + P2(a) + 'L' + P2(b) + '" stroke="#6a6f7a" stroke-width="' + f1(1.5 * k) + '" stroke-linecap="round"/><path d="M' + P2(a) + 'L' + P2(b) + '" stroke="' + CH + '" stroke-width="' + f1(1.1 * k) + '" stroke-linecap="round"/>'
          + '<path d="M' + P2(b) + 'L' + P2(cc) + '" stroke="' + CH + '" stroke-width="' + f1(0.8 * k) + '" stroke-linecap="round"/><path d="M' + P2(cc) + 'L' + P2(d) + '" stroke="' + CH + '" stroke-width="' + f1(0.55 * k) + '" stroke-linecap="round"/><circle cx="' + f1(d[0]) + '" cy="' + f1(d[1]) + '" r="' + f1(1 * k) + '" fill="url(#bxCap)"/>'; }
      // neatly coiled aux cable: 3.5 mm plug in the side jack, one smooth drop to the floor, three even loops held by a red strap
      { const j0 = p(42.4, 12, 7), j1 = p(45.2, 12, 7), j2 = p(49.4, 12, 7), fl = p(55.6, 0.6, 9), mid = p(53, 6, 8);
        f += '<path d="M' + P2(j2) + 'Q' + P2(mid) + ' ' + P2(fl) + '" fill="none" stroke="#141418" stroke-width="' + f1(1.3 * k) + '" stroke-linecap="round"/><path d="M' + P2(j2) + 'Q' + P2(mid) + ' ' + P2(fl) + '" fill="none" stroke="#5a5f6a" stroke-width="' + f1(0.35 * k) + '" stroke-linecap="round" transform="translate(' + f1(-0.3 * k) + ' ' + f1(-0.3 * k) + ')"/>'
          + '<path d="M' + P2(j0) + 'L' + P2(j1) + '" stroke="url(#bxCapL)" stroke-width="' + f1(1.3 * k) + '" stroke-linecap="butt"/><path d="M' + P2(j1) + 'L' + P2(j2) + '" stroke="#1d1e22" stroke-width="' + f1(2.3 * k) + '" stroke-linecap="round"/><path d="M' + P2(j1) + 'L' + P2(j2) + '" stroke="#4a4d58" stroke-width="' + f1(0.5 * k) + '" stroke-linecap="round" transform="translate(0 ' + f1(-0.6 * k) + ')"/>';
        let cl = ''; [7.6, 5.9, 4.2].forEach(r => cl += '<circle r="' + r + '" fill="none" stroke="#141418" stroke-width="1.1"/><circle r="' + r + '" fill="none" stroke="#6a6f7c" stroke-width="0.32" stroke-dasharray="' + f1(r * 1.6) + ' ' + f1(r * 4.7) + '" stroke-dashoffset="' + f1(r * 3.2) + '"/>');
        cl += '<rect x="-1.4" y="3.4" width="2.8" height="5" rx="0.5" fill="#e8343c" stroke="#8a1a24" stroke-width="0.3"/><path d="M-1.4 5.9H1.4" stroke="#ffffff" stroke-width="0.3" opacity="0.5"/><path d="M-2.6 -2.2L-0.8 -0.6" stroke="url(#bxCapL)" stroke-width="1.1"/><path d="M-4 -3.4L-2.6 -2.2" stroke="#1d1e22" stroke-width="1.9"/>';
        f += '<g transform="' + planeH(p, 0.6, 62.6, 9) + '">' + cl + '</g>'; }
      if (play) { [-25, 25].forEach((x, i) => { f += '<g transform="' + plane(p, 11.4, 21, x) + '">' + rep(2, j => '<circle r="13" fill="none" stroke="' + (i ? '#ff4fb8' : '#3ff0ff') + '" stroke-width="0.8" opacity="0">' + '<animate attributeName="r" values="13;26" dur="1s" begin="' + n4(IN + j * 0.5) + 's" repeatCount="indefinite"/><animate attributeName="opacity" values="0.75;0" dur="1s" begin="' + n4(IN + j * 0.5) + 's" repeatCount="indefinite"/></circle>').join('') + '</g>'; });
        f += notes(p(0, 60, 6), 5, k, 'bx', IN); }
      const defs = G('bxCone', [[0, '#4a4d58'], [0.55, '#1f2027'], [1, '#0a0a0d']], 'cx="38%" cy="34%" r="70%"') + G('bxCap', [[0, '#ffffff'], [0.45, '#c9cfd6'], [1, '#4a4f58']]) + L('bxCapL', [[0, '#ffffff'], [0.5, '#c9cfd6'], [1, '#6a6f7a']])
        + L('bxChr', [[0, '#ffffff'], [0.45, '#c9cfd6'], [0.55, '#8a919c'], [1, '#e8edf2']]) + '<clipPath id="bxWell"><rect x="29.4" y="16.4" width="21.2" height="21.2"/></clipPath>';
      return { defs, under: un, front: f, bb: bbOf([p(-44, 0, 12), p(44, 0, 12), p(-44, 60, -11), p(44, 60, -11), p(58, 100, -14), p(72, 0, 18), p(72, 0, 0), p(56, 0, -2)].concat(play ? [p(-30, 112, 6), p(30, 112, 6), p(-52, 21, 12), p(52, 21, 12)] : []), 3) }; };
    return D; };

  // ======================= PRO ACTIVE PA SPEAKER ON A TRIPOD =======================
  N.paPro = S => { const play = isPlay(S), HUB = 33, FEET = [90, 210, 330].map(a => [24 * Math.cos(a * Math.PI / 180), 0, 24 * Math.sin(a * Math.PI / 180)]);
    const KN = [[-8, 136, 2.3, 'VOL', play ? 70 : -60], [-1.5, 136, 2.3, 'GAIN', 20], [5, 136, 2.3, 'MIC', -30], [-8, 126.6, 1.6, 'HI', 0], [-3.2, 126.6, 1.6, 'MID', 10], [1.6, 126.6, 1.6, 'LO', 35]];
    const D = { w: 56, d: 54 };
    D.build = P => { const o = [cyl(0, 10, 0, 1.9, 60, '#23252b', mt({ n: 12 })), cyl(0, 30, 0, 3.4, 6, '#1a1b20', mt({ n: 14 })), cyl(0, 15, 0, 2.6, 2.4, '#1a1b20', mt({ n: 12 })), cyl(0, 68, 0, 2.8, 4, '#1a1b20', mt({ n: 14 })), box(4.2, 69, 0, 3.4, 1.8, 1.8, '#2a2c33', mt({ r: 0.6 })),
        cyl(0, 72, 0, 1.4, 22, CH, mt({ n: 10, shine: 1 })), cyl(0, 94, 0, 3.2, 3, '#1a1b20', mt({ n: 14 }))];
      o.push(box(0, 97, 0, 36, 56, 30, '#1b1c21', pt({ r: 4 })), slab(0, 99.5, 15.15, 33, 51, 0.7, '#2c2e35', mt({ r: 3 })), box(0, 153, -3, 18, 2.6, 7, '#26272d', pt({ r: 1.2 })), slabX(18.2, 106, -1, 0.6, 38, 24, '#2a2c33', mt({ r: 1.6 })));
      KN.forEach(([z, y, r]) => o.push(solid({ ax: 'x', sh: 'el', c: [z, y], a: r, b: r, n: 14, rings: [[18.5, 0], [18.5 + r, 0, 0.9]], col: '#16171c', mat: 'metal', shine: 1 })));
      o.push(slabX(18.6, 108.4, 6.4, 0.8, 3.4, 2.2, '#16171c', mt({ r: 0.4 })));
      return o; };
    D.fx = c => { const p = c.p, k = c.k; let f = '', bk = '', un = '';
      const hub = p(0, HUB, 0), legs = FEET.map(q => { const ft = p(...q), br = p(q[0] * 0.55, 14.9, q[2] * 0.55); return { front: q[2] > 0, s: tube(hub, ft, 1.7, k) + tube(p(0, 16, 0), br, 1, k) + '<ellipse cx="' + f1(ft[0]) + '" cy="' + f1(ft[1] + 0.4 * k) + '" rx="' + f1(2.6 * k) + '" ry="' + f1(1.2 * k) + '" fill="#0c0c0f"/>' }; });
      legs.forEach(l => { if (l.front) f += l.s; else bk += l.s; });
      // front grille: woofer + horn waveguide show through the perforated steel
      let g = '<rect x="0.4" y="0.4" width="32.2" height="50.2" rx="2.4" fill="#26282e"/><path d="M6 4.6H27L21.4 15.4H11.6Z" fill="#121317" stroke="#34363e" stroke-width="0.4"/><ellipse cx="16.5" cy="7.6" rx="2.4" ry="1.4" fill="#0a0a0d"/>'
        + '<g transform="translate(16.5 34)"><g>' + (play ? pulse(0.5) : '') + '<circle r="13" fill="#141519"/><circle r="12.2" fill="none" stroke="#3a3c44" stroke-width="0.6"/><circle r="9.6" fill="url(#paCone)"/><circle r="3.4" fill="#2a2c33"/></g></g>'
        + '<rect x="0.4" y="0.4" width="32.2" height="50.2" rx="2.4" fill="url(#paHole)"/><rect x="0.4" y="0.4" width="32.2" height="50.2" rx="2.4" fill="url(#paGl)"/><rect x="0.4" y="0.4" width="32.2" height="50.2" rx="2.4" fill="none" stroke="#4a4d58" stroke-width="0.5"/>'
        + '<rect x="21.4" y="45.6" width="9.6" height="3.2" rx="0.6" fill="url(#paChr)"/><text x="26.2" y="47.9" text-anchor="middle" font-family="Arial Black, Arial, sans-serif" font-weight="900" font-size="1.7" fill="#1d1e22" letter-spacing="0.2">SQUISH</text>'
        + '<circle cx="4.2" cy="47.3" r="2.2" fill="#4dff7a" opacity="0.55" filter="url(#paB)"/><circle cx="4.2" cy="47.3" r="0.85" fill="#c8ffd6" stroke="#2a9a4a" stroke-width="0.25"/>';
      f += '<g transform="' + plane(p, 15.95, 150.5, -16.5) + '">' + g + '</g>';
      // amp panel (right side): knob scales + pointer caps, combo jacks, power rocker, power / signal / limit LEDs
      f += '<g transform="' + planeX(p, 18.55, 142.4, -12) + '"><text x="0" y="0" font-family="Arial, sans-serif" font-weight="800" font-size="1.4" fill="#c9cdd2" letter-spacing="0.3">ACTIVE 2-WAY · 400W</text></g>';
      [[-7, 117], [0.5, 117]].forEach(([z, y]) => f += '<g transform="' + planeX(p, 18.55, y, z) + '"><circle r="2.7" fill="#0c0c10" stroke="#9aa1ad" stroke-width="0.35"/><circle r="1.6" fill="#1d1e24"/>' + rep(3, i => '<circle cx="' + f1(Math.cos(i * 2.1 - 1.6) * 0.95) + '" cy="' + f1(Math.sin(i * 2.1 - 1.6) * 0.95) + '" r="0.3" fill="#9aa1ad"/>').join('') + '</g>');
      f += '<g transform="' + planeX(p, 19.45, 111.8, 6.4) + '"><text x="0" y="2.8" text-anchor="middle" font-family="Arial, sans-serif" font-weight="800" font-size="1" fill="#c9cdd2">I</text><rect x="-1" y="0.2" width="2" height="1.4" fill="#e8343c" opacity="0.85"/></g>';
      KN.forEach(([z, y, r, lab, ang], i) => { let t = rep(7, j => { const q = (-135 + j * 45) * Math.PI / 180, s0 = Math.sin(q), c0 = -Math.cos(q); return '<path d="M' + f1(s0 * (r + 0.6)) + ' ' + f1(c0 * (r + 0.6)) + 'L' + f1(s0 * (r + 1.2)) + ' ' + f1(c0 * (r + 1.2)) + '" stroke="#c9cdd2" stroke-width="0.25"/>'; }).join('');
        t += '<text x="0" y="' + f1(r + 2.6) + '" text-anchor="middle" font-family="Arial, sans-serif" font-weight="800" font-size="1.15" fill="#c9cdd2">' + lab + '</text>';
        f += '<g transform="' + planeX(p, 18.55, y, z) + '">' + t + '</g>';
        const cap = '<circle r="' + f1(r * 0.86) + '" fill="url(#paKnob)"/><g transform="rotate(' + (i === 0 && play ? -60 : ang) + ')">' + (i === 0 && play ? once('rotate', '-60;-60;70', '0;0.35;1', 0.9) : '') + '<path d="M0 ' + f1(-r * 0.25) + 'V' + f1(-r * 0.82) + '" stroke="#f4f6f8" stroke-width="0.45" stroke-linecap="round"/></g>';
        f += '<g transform="' + planeX(p, 18.5 + r + 0.05, y, z) + '">' + cap + '</g>'; });
      [[137, '#4dff7a', 'PWR', 1], [132.4, '#3ff0ff', 'SIG', 0], [127.8, '#ff3b3b', 'LIM', 0]].forEach(([y, col, lab, on], i) => {
        const lit = on ? '' : play ? '<animate attributeName="opacity" values="' + (i === 1 ? '1;0.25;1;0.6;1;0.2' : '0.12;0.12;0.12;1;0.12;0.12;0.12;0.12') + '" dur="' + (i === 1 ? 0.5 : 2) + 's" calcMode="discrete" repeatCount="indefinite"/>' : '';
        f += '<g transform="' + planeX(p, 18.6, y, 9) + '"><circle r="1.9" fill="' + col + '" filter="url(#paB)" opacity="' + (on || play ? 0.6 : 0) + '">' + lit + '</circle><circle r="0.75" fill="' + col + '" opacity="' + (on || play ? 1 : 0.22) + '" stroke="#000000" stroke-width="0.2">' + lit + '</circle><text x="-2.2" y="0.45" text-anchor="end" font-family="Arial, sans-serif" font-weight="800" font-size="1.05" fill="#c9cdd2">' + lab + '</text></g>'; });
      if (play) { f += '<g transform="' + plane(p, 16.4, 116.5, 0) + '">' + rep(3, j => '<ellipse rx="15" ry="15" fill="none" stroke="' + ['#3ff0ff', '#ff4fb8', '#ffe14f'][j] + '" stroke-width="0.9" opacity="0"><animate attributeName="rx" values="15;34" dur="1.5s" begin="' + n4(-j * 0.5) + 's" repeatCount="indefinite"/><animate attributeName="ry" values="15;34" dur="1.5s" begin="' + n4(-j * 0.5) + 's" repeatCount="indefinite"/><animate attributeName="opacity" values="0.8;0" dur="1.5s" begin="' + n4(-j * 0.5) + 's" repeatCount="indefinite"/></ellipse>').join('') + '</g>';
        f += notes(p(0, 156, 8), 4, k, 'pa', 0);
        const fl = p(0, 0, 0); un += '<ellipse cx="' + f1(fl[0]) + '" cy="' + f1(fl[1]) + '" rx="' + f1(40 * k) + '" ry="' + f1(40 * k * X.SA * 0.6) + '" fill="#3ff0ff" opacity="0.18" filter="url(#paB)"/>'; }
      const defs = BLUR('paB', 1.1) + G('paCone', [[0, '#3a3c46'], [0.6, '#16171c'], [1, '#0a0a0d']]) + G('paKnob', [[0, '#6a6e7a'], [0.5, '#26272e'], [1, '#0c0c10']])
        + L('paChr', [[0, '#ffffff'], [0.45, '#c9cfd6'], [0.55, '#8a919c'], [1, '#e8edf2']]) + L('paGl', [[0, '#ffffff', 0.12], [0.35, '#ffffff', 0], [1, '#000000', 0.2]])
        + '<pattern id="paHole" width="1.5" height="1.3" patternUnits="userSpaceOnUse"><circle cx="0.4" cy="0.35" r="0.42" fill="#0b0c10" opacity="0.85"/><circle cx="1.15" cy="1" r="0.42" fill="#0b0c10" opacity="0.85"/><circle cx="0.25" cy="0.2" r="0.16" fill="#ffffff" opacity="0.08"/></pattern>';
      return { defs, under: un, back: bk, front: f, bb: bbOf(FEET.map(q => p(q[0] * 1.12, 0, q[2] * 1.12)).concat([p(-19, 156, -16), p(19, 156, -16), p(-19, 97, 16), p(23, 140, 14)], play ? [p(-34, 200, 8), p(34, 200, 8), p(-36, 116, 16), p(36, 116, 16)] : []), 3) }; };
    return D; };

  // ---------- catalog edits ----------
  RD.SET6 = {
    'CLB-018': { spec: 'boom80', role: 'spk', live: 'Tap to play', note: 'A clean 80s chrome boombox: two big speaker cones with chrome rings, tweeters, a tuner window and a smoked cassette door. Tap to play: the door flips down, the tape drops in, the reels roll and the cones pump. The aux cable is neatly coiled with a red strap.' },
    'CLB-002': { spec: 'paPro', live: 'Sound check', note: 'A modern active PA cabinet on a sturdy steel tripod: perforated steel grille over the woofer and horn, an amp panel with volume, gain, mic and EQ knobs, combo jacks and a glowing green power LED. Tap for a clean sound check: the volume knob turns up, the signal light dances and the woofer pumps.' },
    'CLB-045': { live: 'Live LED', note: 'Big 70s acrylic light-up squares in a chrome grid. They run the same neon colour wave as the Black LED floor, all the time.' },
    'CLB-065': { live: 'Live LED', note: 'A fine RGB pixel-matrix floor. It runs the same neon colour wave as the Black LED floor in one steady loop, with no step flashes.' },
    'CLB-085': { live: 'Live LED', note: 'Floating light plates over a black base. They run the same neon colour wave as the Black LED floor in one steady loop, with no step flashes.' },
  };
  const edit5 = RD.edit;
  RD.edit = rows => edit5(rows).map(r => RD.SET6[r.id] ? Object.assign({}, r, RD.SET6[r.id]) : r);
  RD.PLUS6 = 1;
})();
