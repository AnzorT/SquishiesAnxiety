// Renovation Catalog drawings: every row of the renovation CSV drawn with the Squad House v4 3D engine (house4*.js).
// tier -> style band, name keywords -> colours/materials, slot -> archetype (existing X.ARCH or new ones below), surfaces -> swatch vignettes.
(function boot() {
  const X = window.House3D; if (!(X && X.EXT2 && X.swatch && X.ARCH && X.SPEC)) { setTimeout(boot, 30); return; } if (window.RenoDraw) return;
  const K = X.K, { solid, box, cush, cyl, ball, slab, slabX, arcW, disc, pillowY, pillowZ, prism, prismZ, shade, mix, f1 } = K;
  const NE = K.NEON, GOLD = '#e2b14a', CH = '#d5dde2', CR = '#fffaf1', WH = '#ffffff', DK = '#36373c', GL = '#cfe8f2', PI = Math.PI;
  const em = o => Object.assign({ emit: 1, noOut: 1 }, o || {});
  const TB = ['junk', 'cot', 'mod', 'royal', 'candy'];

  // ---------- keyword colours ----------
  const CA = { burgundy: '#7f2030', crimson: '#a8243a', red: '#d9483b', cherry: '#c23a3a', cognac: '#a8592b', leather: '#8a4f2c', mustard: '#d8a531', yellow: '#f2c94c', yellowed: '#e8d79a', orange: '#e88a3a', terracotta: '#c8693f', coral: '#ef8f7f', pink: '#f0948e',
    lavender: '#b9a6e0', purple: '#7a4fb0', plum: '#5b2a63', navy: '#2f4870', blue: '#5b8fd0', cobalt: '#2f5fb0', teal: '#3aa6a0', mint: '#9fdcc4', sage: '#9fb58c', green: '#6aa65a', emerald: '#1f6a4c', olive: '#8a8f4a', moss: '#6f8f4a', eucalyptus: '#8fb39a', jade: '#5fae8a',
    charcoal: '#3e4046', black: '#2c2d31', obsidian: '#2a2630', onyx: '#3a3438', basalt: '#3c3c40', slate: '#5c6670', gray: '#9a9ea3', grey: '#9a9ea3', silver: '#c9d0d6', platinum: '#e5e7ea', white: '#f4f1ea', cream: '#f3ead6', ivory: '#f3ead6', beige: '#d9c7a6', eggshell: '#efe7d6', 'off-white': '#ece4d2',
    'bouclé': '#efe8dc', boucle: '#efe8dc', linen: '#e9dfcc', flax: '#e3d6bc', cashmere: '#e8dcc8', shearling: '#efe6d6', sheepskin: '#f1ead8', cotton: '#f4efe6', silk: '#f2e6e0', 'faux-fur': '#efe6da', berber: '#efe6d4',
    marble: '#efebe5', calacatta: '#f2efea', alabaster: '#f2ece2', travertine: '#e1cfae', limestone: '#e3d8c0', terrazzo: '#e6ded2', quartz: '#ece8e2', quartzite: '#e8e2d8', soapstone: '#7d8584', stone: '#b9b4aa', concrete: '#a9a8a2', cinderblock: '#a7a6a0', brick: '#b8664a', pebble: '#b8b2a6', tadelakt: '#e8d2b4', plaster: '#ece2d0', terra: '#c8693f',
    jute: '#c9a873', seagrass: '#b8a46a', rattan: '#c99a5a', wicker: '#c99a5a', cane: '#d8b278', coir: '#a9804c', cardboard: '#c49a62', rust: '#a0603a', rusty: '#a0603a', rusted: '#a0603a', corrugated: '#a9b0b4', tin: '#a9b0b4', galvanized: '#b5bcc0', foil: '#d5dde2',
    plaid: '#b8714a', gingham: '#e3946a', leopard: '#c99a4a', neon: '#4fe0d0', rgb: '#6ac8ff', led: '#6ac8ff', uv: '#8f7bff', holographic: '#8fe8ff', hologram: '#8fe8ff', holo: '#8fe8ff', bioluminescent: '#7af0d0', aurora: '#7ae8c8', nebula: '#8f7bff', plasma: '#b48cff', crystal: '#d8f0ff', glass: '#cfe8f2', acrylic: '#d8eef5', mirror: '#cfe8f2', 'mirror-chrome': '#d5dde2', 'liquid-metal': '#c9d0d6', 'carbon-fiber': '#3a3c42', foam: '#3a3a40', lucite: '#d8eef5', lacquered: '#2c2d31', shagreen: '#9fbfb0', murano: '#6b6f7a', capiz: '#f4eee2', porcelain: '#f4f2ee', ceramic: '#efe8dc', enamel: '#f1ece2', fireclay: '#f4f1ea', vinyl: '#d9483b', felt: '#b9a088', denim: '#4a6890' };
  const CW = { walnut: '#6b4226', teak: '#a86b36', oak: '#d4a56a', pine: '#e6c48e', cedar: '#b8693f', hinoki: '#e8cf9c', cypress: '#d9b98a', mahogany: '#6a2a1c', rosewood: '#6e2d24', redwood: '#9a4a2e', birch: '#ead9b8', bamboo: '#d8c27a', burl: '#9a5a32', plywood: '#d2b07a', particleboard: '#c9ab7a', ash: '#d8c4a2', wooden: '#b98a58', wood: '#b98a58', butcher: '#d0a066', timber: '#a87a48', driftwood: '#b9ab96', '2x4': '#d8b886' };
  const CM = { brass: '#d4a548', gold: '#e2b14a', golden: '#e2b14a', '24k': '#e2b14a', gilded: '#e2b14a', bronze: '#a8743a', copper: '#c87a46', chrome: '#d5dde2', stainless: '#c9d3d8', steel: '#9aa3a8', iron: '#4a4a4e', 'cast-iron': '#3e3e42', 'wrought-iron': '#3a3a3e', aluminum: '#c9cfd3', aluminium: '#c9cfd3', metal: '#a9b0b4' };
  const words = n => n.toLowerCase().replace(/[^a-z0-9\-é ]+/g, ' ').split(/\s+/).filter(Boolean);
  function colorsOf(name, band) {
    const B = (X.BANDS.find(b => b.k === band) || X.BANDS[0]).cols[0], W = words(name), cs = [], ms = [], ws = [];
    W.forEach(w => { const s = w.replace(/s$/, ''); if (CA[w] || CA[s]) cs.push(CA[w] || CA[s]); else if (CM[w] || CM[s]) ms.push(CM[w] || CM[s]); else if (CW[w] || CW[s]) ws.push(CW[w] || CW[s]); });
    const a = cs[0] || ms[0] || ws[0] || B.a, b = (cs[0] || ws[0] ? ms[0] : ms[1]) || cs[1] || B.b, w = ws[0] || B.w;
    return { a, b, w, m: ms[0] || '#d5dde2', anyA: !!(cs[0] || ms[0] || ws[0]) };
  }

  // ---------- new archetypes ----------
  const legs4 = (x, z, h, col, r = 3) => [[-x, -z], [x, -z], [-x, z], [x, z]].map(([a, b]) => cyl(a, 0, b, r, h, col, { n: 8 }));
  const metalOf = k => k === 'royal' ? GOLD : k === 'candy' ? '#fff1a0' : k === 'junk' ? '#9aa1a6' : k === 'mod' ? DK : CH;
  const holoBase = (o, y, r) => { o.push(cyl(0, y, 0, r, 4, '#3a3c48', { n: 18 }), cyl(0, y + 4, 0, r * 0.75, 2, '#8fe8ff', em({ n: 18 }))); };
  const N = {
    sheet: S => ({ w: 150, d: 8, mount: 'wall', build: P => [slab(0, 46, -2, 150, 96, 2, '#f4efe4', { r: 2, soft: 1, mat: 'fab', scr: { r: 2 } }), slab(-30, 60, -0.6, 2, 70, 0.6, '#d8cfbe', { r: 1, noOut: 1 }), slab(34, 52, -0.6, 2, 80, 0.6, '#d8cfbe', { r: 1, noOut: 1 }), ball(-73, 139, 0, 2.6, '#d9483b', { k: 3, n: 8 }), ball(73, 139, 0, 2.6, '#5b8fd0', { k: 3, n: 8 }), ball(-73, 46, 0, 2.6, '#f2c94c', { k: 3, n: 8 }), ball(73, 46, 0, 2.6, '#6aa65a', { k: 3, n: 8 })] }),
    projDev: S => ({ w: 60, d: 50, glow: () => S.k === 'candy' ? { y: 60, r: 60, c: 'url(#gNeon)' } : null, build: P => { const k = S.k, o = [];
      if (k === 'junk') { o.push(...legs4(16, 14, 34, '#9a7550', 2.6), box(0, 34, 0, 44, 4, 38, '#b08a5e', { r: 2 }), box(0, 38, 2, 40, 10, 30, '#3a3a3e', { r: 2 }), box(0, 40, 17.4, 22, 3, 1, '#1d1d20', { r: 0.5 }), box(0, 48, 0, 30, 18, 26, '#d6d0c4', { r: 4 }), disc(-4, 57, 13, 7, 4, '#2c2d31'), disc(-4, 57, 17, 4.6, 0.8, '#8fd0ff', em())); return o; }
      if (k === 'candy') { holoBase(o, 0, 24); o.push(cyl(0, 6, 0, 10, 70, '#8fe8ff', em({ rg: [[0, 0, 0.4], [70, 0, 2.2]], op: 0.28 })), ball(0, 50, 0, 10, '#c9f4ff', em({ op: 0.7 })), ball(-14, 66, 6, 4, '#ffd66b', em()), ball(14, 60, -4, 3, '#a6f06a', em())); return o; }
      const c = k === 'royal' ? '#2c2d31' : k === 'mod' ? '#f1eee8' : P.a;
      if (k !== 'cot') o.push(cyl(0, 52, -4, 2.4, 40, metalOf(k), { n: 8 }), box(0, 90, -4, 24, 4, 14, metalOf(k), { r: 2 }));
      o.push(box(0, k === 'cot' ? 0 : 28, 0, 50, 22, 42, c, { r: 8, bev: 3 }), disc(-10, (k === 'cot' ? 0 : 28) + 11, 21, 8, 4, '#2c2d31'), disc(-10, (k === 'cot' ? 0 : 28) + 11, 25, 5, 0.8, '#8fd0ff', em()), box(14, (k === 'cot' ? 0 : 28) + 22, 4, 12, 1.2, 10, shade(c, 0.85), { r: 2 }));
      if (k === 'royal') o.push(disc(14, 39, 21, 7, 4, '#2c2d31'), disc(14, 39, 25, 4.6, 0.8, '#8fd0ff', em()), box(0, 28, 0, 52, 2, 44, GOLD, { r: 8 }));
      return o; } }),
    popcorn: S => ({ w: 70, d: 54, glow: () => S.k === 'junk' ? null : { y: 80, r: 50 }, build: P => { const k = S.k, o = [];
      if (k === 'junk') { o.push(...legs4(13, 13, 38, '#8a8f94', 2.4), cyl(0, 38, 0, 20, 3, '#9aa1a6', { n: 14 }), box(0, 41, 0, 48, 26, 34, '#efe9dc', { r: 4 }), slab(-4, 45, 17.4, 30, 18, 1, '#3a3a3e', { r: 2 }), box(16, 48, 17.6, 6, 14, 1, '#c9c2b2', { r: 1 }), ball(-4, 46, 18.4, 5, '#f4e2b8', { sy: 0.7, k: 3, n: 8 })); return o; }
      const r = k === 'royal' ? '#7f2030' : k === 'candy' ? '#bfe4ff' : k === 'mod' ? '#d9483b' : P.a, trim = k === 'royal' ? GOLD : k === 'candy' ? '#fff1a0' : '#f2c94c';
      o.push(box(0, k === 'cot' ? 0 : 10, 0, 56, 36, 40, r, { r: 4, bev: 2 }), box(0, (k === 'cot' ? 0 : 10) + 36, 0, 58, 3, 42, trim, { r: 3 }));
      if (k !== 'cot') o.push(...[[-22, 16], [22, 16], [-22, -16], [22, -16]].map(([x, z]) => cyl(x, 0, z, 5, 10, '#2c2d31', { n: 10 })));
      const y0 = (k === 'cot' ? 0 : 10) + 39; o.push(box(0, y0, 0, 50, 40, 34, GL, { r: 2, op: 0.45, mat: 'cer' }));
      for (let i = 0; i < 16; i++) o.push(ball(-18 + (i % 6) * 7, y0 + Math.floor(i / 6) * 5, -10 + (i * 7 % 20), 3.4, i % 3 ? '#fff4d0' : '#f2d27a', { k: 3, n: 8 }));
      o.push(box(0, y0 + 40, 0, 56, 6, 40, r, { r: 5 }), cyl(0, y0 + 46, 0, 12, 6, trim, { n: 12, top: 6 }), slab(0, (k === 'cot' ? 0 : 10) + 12, 20.4, 40, 12, 0.8, WH, { r: 2 }), slab(0, (k === 'cot' ? 0 : 10) + 15, 21, 30, 6, 0.6, r, { r: 1 }));
      return o; } }),
    icechest: S => ({ w: 70, d: 44, build: P => { const k = S.k, c = k === 'junk' ? '#f2efe6' : P.a, l = k === 'junk' ? '#ebe6da' : shade(P.a, 1.15);
      const o = [box(0, 0, 0, 66, 34, 40, c, { r: 5, mat: k === 'junk' ? 'cer' : undefined }), box(0, 34, 0, 68, 7, 42, l, { r: 6 })];
      if (k === 'junk') o.push(box(18, 41, 0, 20, 2, 16, '#9fd2f2', { r: 3 }), patch(-16, 14, 20.6, 16, 8, '#c9c2b2'));
      else o.push(slabX(0, 42, 0, 40, 4, 4, '#3a3a3e', { r: 2 }), cyl(-26, 41, 0, 2, 4, '#3a3a3e', { n: 6 }), cyl(26, 41, 0, 2, 4, '#3a3a3e', { n: 6 }));
      return o; } }),
    minifridge: S => ({ w: 56, d: 50, glow: () => S.glass ? { y: 30, r: 40, c: 'url(#gNeon)' } : null, build: P => { const k = S.k, c = k === 'junk' ? '#d8d2c6' : k === 'royal' ? '#2c2d31' : P.a, o = [box(0, 0, 0, 54, 70, 46, c, { r: 6, bev: 2 })];
      if (S.glass || k === 'royal' || k === 'candy') { o.push(slab(0, 6, 23.4, 44, 56, 1, '#c9eef8', { r: 3, op: 0.75 })); [16, 32, 48].forEach((y, i) => [-14, -4, 6, 16].forEach((x, j) => o.push(cyl(x, y - 4, 18, 3.2, 9, NE[(i + j) % 6], { n: 8 })))); o.push(slab(0, 64, 23.8, 44, 4, 0.8, k === 'royal' ? GOLD : '#d9483b', { r: 1 })); }
      else { o.push(slab(0, 4, 23.6, 50, 62, 1.2, shade(c, 1.06), { r: 4 }), box(20, 26, 25, 3, 18, 3, CH, { r: 1.5 })); if (k === 'junk') o.push(box(-8, 40, 24.4, 12, 10, 1, '#a0603a', { r: 4, op: 0.5 }), ball(-16, 54, 24.6, 4, '#e2554a', { sz: 0.3, k: 3 })); }
      return o; } }),
    tray: S => ({ w: 52, d: 40, build: P => { const k = S.k, o = [];
      if (k === 'junk') { [-1, 1].forEach(s => { o.push(prism(s * 18 - 1, s * 18 + 1, [[-14, 0], [-12, 0], [12, 40], [14, 40]], '#9aa1a6'), prism(s * 18 - 1, s * 18 + 1, [[12, 0], [14, 0], [-12, 40], [-14, 40]], '#9aa1a6')); }); o.push(box(0, 40, 0, 50, 3, 36, '#d9483b', { r: 3 }), box(0, 43, 0, 36, 1, 24, '#e8d79a', { r: 2 }), ball(8, 43, 2, 5, '#c49a62', { sy: 0.5, k: 3, n: 8 })); return o; }
      if (k === 'cot') { o.push(box(0, 0, 0, 52, 3, 30, P.w, { r: 3 }), box(-24, 3, 0, 3, 6, 30, P.wD), box(24, 3, 0, 3, 6, 30, P.wD), cyl(-8, 3, 0, 5, 8, CR, { n: 10 }), box(12, 3, 2, 14, 2, 12, '#e3946a', { r: 1 })); return o; }
      o.push(box(0, 0, 0, 50, 3, 34, k === 'candy' ? '#bfe4ff' : P.w, { r: 6 }), box(0, 3, 0, 50, 4, 34, k === 'royal' ? GOLD : shade(P.w, 0.85), { r: 6, rings: [[3, 0], [7, 0]] }), cyl(-10, 3, 0, 5, 10, k === 'candy' ? '#ffd66b' : CR, { n: 10 }), cyl(10, 3, 4, 4, 12, '#a6d8ff', { n: 10, op: 0.8 }));
      if (k === 'candy') o.push(ball(0, -14, 0, 8, '#8fe8ff', em({ sy: 0.4, op: 0.5 })));
      return o; } }),
    bistro: S => ({ w: 50, d: 50, round: 1, glow: () => S.k === 'candy' ? { y: 40, r: 40, c: 'url(#gNeon)' } : null, build: P => { const k = S.k, top = k === 'candy' ? '#bfe4ff' : k === 'royal' ? P.a : k === 'mod' ? P.a : P.w, m = metalOf(k), h = S.tall ? 78 : 48;
      const o = [cyl(0, 0, 0, 18, 3, m, { n: 16 }), cyl(0, 3, 0, 3, h - 6, m, { n: 8 }), cyl(0, h - 3, 0, 24, 4, top, { n: 18, mat: /marble|stone/.test(S.nm) ? 'cer' : undefined })];
      if (k === 'royal') o.push(cyl(0, h - 4, 0, 25, 1.4, GOLD, { n: 18 }), cyl(0, h * 0.45, 0, 5, 10, GOLD, { n: 10, rg: [[0, 0, 0.6], [5, 0, 1.2], [10, 0, 0.6]] }));
      if (k === 'candy') o.push(cyl(0, 6, 0, 10, h - 12, '#8fe8ff', em({ op: 0.35 })));
      o.push(cyl(-6, h + 1, 3, 3.4, 9, k === 'royal' ? GOLD : '#a6d8ff', { n: 10, op: 0.85 }));
      return o; } }),
    petbed: S => ({ w: 70, d: 60, round: 1, build: P => { const k = S.k, a = P.a, o = [];
      if (k === 'junk') { if (/box/.test(S.nm)) return N.cardbox(S).build(P).concat([cush(0, 14, 0, 40, 6, 28, '#e8dcc0')]); o.push(cush(0, 0, 0, 60, 7, 46, a), cush(-6, 7, -2, 46, 6, 30, shade(a, 1.1)), cush(4, 13, -4, 30, 5, 20, shade(a, 0.95))); return o; }
      if (k === 'cot') o.push(cyl(0, 0, 0, 34, 18, P.w, { rz: 28, n: 20, rg: [[0, 0, 0.9], [18, 0, 1]], mat: 'wood' }));
      o.push(arcW(0, k === 'cot' ? 8 : 0, 0, 32, 26, 12, 14, 0, PI * 2, k === 'cot' ? '#f4efe6' : a, { n: 16, soft: 1 }), cush(0, k === 'cot' ? 8 : 0, 0, 44, 10, 34, shade(a, 1.12)));
      if (k === 'cot') for (let i = 0; i < 5; i++) o.push(ball(-12 + i * 6, 18, -4 + (i % 2) * 8, 1.8, '#d9483b', { k: 3, n: 6, sy: 0.4 }));
      if (k === 'royal') { [[-30, -24], [30, -24], [-30, 24], [30, 24]].forEach(([x, z]) => o.push(cyl(x, 0, z, 2, 64, GOLD, { n: 8 }))); o.push(box(0, 64, 0, 66, 3, 54, GOLD, { r: 3 }), slab(0, 40, -24, 60, 24, 1, P.a, { r: 2, soft: 1 })); }
      if (k === 'candy') o.push(ball(0, -16, 0, 14, '#8fe8ff', em({ sx: 2, sy: 0.3, op: 0.35 })));
      if (k === 'mod') o.push(ball(10, 10, -6, 6, P.b, { k: 4 }));
      return o; } }),
    cardbox: S => ({ w: 60, d: 46, build: P => [box(0, 0, 0, 56, 30, 42, '#c49a62', { r: 1 }), box(0, 29.5, 0, 50, 0.6, 36, '#8a6a42', { r: 1 }), prism(-28, -27, [[-21, 30], [21, 30], [21, 40], [-21, 34]], '#d2aa70'), slab(0, 30, 21, 56, 6, 1, '#d2aa70', { r: 0, yaw: 0 }), slab(0, 10, 21.4, 56, 5, 0.6, '#d8c8a0', { r: 0 }), box(28, 30, 0, 1, 12, 40, '#d2aa70', { r: 0 })] }),
    crate: S => ({ w: 46, d: 46, build: P => { const c = S.k === 'junk' ? (/red/.test(S.nm) ? '#d9483b' : '#3f7fbf') : P.a, o = [];
      [-1, 1].forEach(s => { o.push(box(s * 20, 0, 0, 4, 40, 42, c, { r: 1 }), box(0, 0, s * 20, 42, 40, 4, c, { r: 1 })); });
      o.push(box(0, 36, 0, 44, 4, 44, shade(c, 1.08), { r: 2 }), slab(0, 12, 22.4, 26, 6, 0.6, shade(c, 0.6), { r: 3 }), slab(0, 26, 22.4, 26, 6, 0.6, shade(c, 0.6), { r: 3 }));
      if (/neon|sticker/.test(S.nm)) o.push(disc(-8, 18, 22.6, 4, 0.5, NE[0], em()), disc(8, 28, 22.6, 3, 0.5, NE[2], em()));
      return o; } }),
    console: S => ({ w: 150, d: 40, build: P => { const k = S.k, top = k === 'mod' ? GL : k === 'royal' ? P.w : k === 'candy' ? P.a : P.w, m = metalOf(k), o = [];
      if (k === 'junk') { [-1, 1].forEach(s => o.push(prism(s * 60 - 2, s * 60 + 2, [[-16, 0], [-12, 0], [0, 56], [12, 0], [16, 0], [2, 62], [-2, 62]], '#c9a46a'))); o.push(box(0, 60, 0, 150, 4, 36, '#d2b07a', { r: 1 }), slabX(0, 22, 0, 120, 4, 4, '#b89058')); return o; }
      if (k === 'mod') { o.push(...legs4(68, 14, 62, m, 1.6), slabX(0, 10, -14, 136, 2, 2, m), slabX(0, 10, 14, 136, 2, 2, m), box(0, 62, 0, 150, 2.4, 38, top, { r: 2, op: 0.7 })); return o; }
      if (k === 'candy') { o.push(prismZ(-16, 16, [[-70, 0], [-40, 0], [0, 44], [40, 0], [70, 0], [74, 62], [-74, 62]], '#c9d0d6', { mat: 'metal' }), box(0, 62, 0, 152, 4, 38, '#d5dde2', { r: 18 })); return o; }
      o.push(box(0, 0, 0, 146, 58, 36, k === 'royal' ? P.w : P.w, { r: 3, bev: 2 }));
      [-48, 0, 48].forEach((x, i) => o.push(slab(x, 6, 18.4, 44, 46, 1, k === 'cot' ? '#e6d2a8' : shade(P.w, 1.08), { r: 2, mat: k === 'cot' ? 'fab' : undefined }), ball(x + (i === 1 ? 0 : 0), 30, 19.5, 2.2, k === 'royal' ? GOLD : '#3a3a3e', { k: 3, n: 8 })));
      if (k === 'royal') o.push(box(0, 58, 0, 150, 3, 38, GOLD, { r: 3 }), ...[-66, 66].map(x => cyl(x, -6, 14, 3, 6, GOLD, { n: 8 })));
      o.push(box(0, 58, 0, 148, 3, 37, shade(P.w, 0.9), { r: 3 }));
      return o; } }),
    cattree: S => ({ w: 70, d: 60, build: P => { const c = P.a, w = '#e6d4b0', o = [box(0, 0, 0, 66, 6, 56, c, { r: 6, soft: 1 })];
      [[-18, 0, 70], [16, -8, 110]].forEach(([x, z, h]) => o.push(cyl(x, 6, z, 6, h, w, { n: 12, mat: 'wood' })));
      o.push(cush(-18, 76, 0, 40, 6, 36, c), cush(16, 116, -8, 36, 6, 32, shade(c, 1.1)), box(-18, 40, 14, 30, 22, 24, shade(c, 0.9), { r: 8, soft: 1 }), disc(-18, 50, 26.2, 7, 0.6, '#3a2a20'), ball(28, 80, 6, 4, '#f2c94c', { k: 3 }), cyl(28, 84, 6, 0.6, 30, '#8a6a48', { n: 4 }));
      return o; } }),
    hearth: S => ({ w: 130, d: 46, glow: () => ({ y: 30, r: 70 }), fx: c => H.fire(c, S._fl, S.k === 'junk'), build: P => { const k = S.k, o = [], FL = S._fl = [], fl = (x, y, z, s) => FL.push([x, y, z, s]);
      if (k === 'mod') { o.push(box(0, 0, 0, 80, 6, 50, '#3e4046', { r: 4 }), cyl(0, 6, 0, 30, 46, '#2c2d31', { n: 18, rg: [[0, 0, 0.9], [30, 0, 1.05], [46, 0, 0.3]] }), cyl(0, 52, 0, 7, 90, '#2c2d31', { n: 10 }), box(0, 12, 16, 34, 20, 14, '#1d1d20', { r: 10 })); fl(-4, 13, 22, 0.9); fl(7, 13, 21, 0.7); return o; }
      if (k === 'candy') { o.push(box(0, 0, 0, 60, 8, 44, '#2a2630', { r: 4 }), cyl(0, 8, 0, 20, 100, '#cfe8f2', { n: 16, op: 0.35, mat: 'cer' }), cyl(0, 8, 0, 6, 70, '#8fe8ff', em({ op: 0.4, rg: [[0, 0, 1], [70, 0, 2]] }))); fl(0, 10, 0, 1.3); fl(-6, 22, 4, 0.9); fl(6, 30, -2, 0.8); return o; }
      const br = k === 'junk' ? '#b8664a' : k === 'royal' ? '#f3ead6' : '#f4f1ea', mt = k === 'royal' ? '#efebe5' : k === 'cot' ? '#3e3e42' : '#a87a58';
      o.push(box(0, 0, 0, 126, 96, 40, br, { r: 2, mat: k === 'junk' ? 'paint' : 'cer' }), box(0, 0, 20.5, 70, 56, 1, '#2c1c14', { r: 6 }), box(0, 96, 2, 134, 6, 46, mt, { r: 2 }), box(0, 0, 10, 140, 6, 62, shade(br, 0.85), { r: 2 }));
      if (k === 'junk') { for (let r = 0; r < 6; r++) o.push(slab(0, 8 + r * 15, 20.2, 126, 1, 0.4, '#e6d0b8', { r: 0, noOut: 1 })); o.push(box(0, 6, 24, 30, 24, 10, '#d5dde2', { r: 3 }), slab(0, 10, 29.2, 22, 16, 0.6, '#ff8a3a', em()), ball(30, 102, 4, 6, '#a9b0b4', { k: 3 })); }
      else { if (k === 'cot') o.push(box(0, 4, 22, 64, 44, 2, '#2c2c30', { r: 8 })); o.push(cyl(-14, 4, 28, 4, 30, '#8a5a34', { n: 8, yaw: 0 }), box(0, 4, 30, 44, 7, 10, '#8a5a34', { r: 3 })); fl(-8, 10, 30, 1); fl(8, 10, 29, 0.8); if (k === 'royal') o.push(...[-50, 50].map(x => cyl(x, 0, 21, 5, 96, GOLD, { n: 10 })), ball(0, 102, 10, 7, GOLD)); }
      return o; } }),
    divider: S => ({ w: 110, d: 20, build: P => { const k = S.k, o = [], m = metalOf(k);
      if (k === 'junk') { o.push(slabX(0, 150, 0, 112, 2.4, 2.4, '#9aa1a6', { r: 1 })); for (let i = 0; i < 6; i++) o.push(slab(-46 + i * 18, 4, (i % 2) * 3 - 1.5, 20, 144, 1.2, '#cfe8f2', { r: 2, op: 0.8, rb: 0 })); o.push(slab(30, 30, 3, 20, 40, 1.4, '#b9ab92', { r: 6, op: 0.5 })); return o; }
      const fr = k === 'royal' ? '#b8693f' : k === 'mod' ? '#c9d3d8' : k === 'candy' ? '#8fe8ff' : '#e6e6e2';
      o.push(box(0, 0, 0, 110, 4, 18, fr, { r: 2 }), box(-54, 0, 0, 4, 154, 6, fr, { r: 1 }), box(54, 0, 0, 4, 154, 6, fr, { r: 1 }), box(0, 150, 0, 112, 4, 6, fr, { r: 1 }), slab(0, 4, 0, 104, 146, 1.4, k === 'royal' ? '#f6efe0' : k === 'cot' ? '#e8eef0' : '#d8f0f8', { r: 1, op: k === 'royal' ? 0.95 : 0.55, rb: 1 }));
      if (k === 'royal') { [-26, 0, 26].forEach(x => o.push(box(x, 4, 1.4, 2, 146, 1.2, '#b8693f', { r: 0 }))); [40, 80, 120].forEach(y => o.push(slabX(0, y, 1.4, 104, 2, 1.2, '#b8693f', { r: 0 }))); }
      if (k === 'mod' || k === 'candy') o.push(slab(-30, 60, 1.2, 4, 70, 0.4, WH, { r: 1, op: 0.6, noOut: 1 }));
      if (k === 'candy') o.push(slab(0, 4, 0.8, 104, 146, 0.5, '#8fe8ff', em({ r: 1, op: 0.25, rb: 1 })));
      if (k === 'cot') o.push(box(40, 60, 4, 3, 20, 3, m, { r: 1.5 }));
      return o; } }),
    onsen: S => ({ w: 150, d: 110, build: P => { const k = S.k, wd = k === 'candy' ? '#ece8e2' : P.w, o = [];
      [-1, 1].forEach(s => { o.push(box(s * 71, 0, 0, 8, 54, 110, wd, { r: 1 }), box(0, 0, s * 51, 150, 54, 8, wd, { r: 1 })); });
      o.push(box(0, 0, 0, 136, 42, 96, wd, { r: 1 }), box(0, 42, 0, 136, 6, 96, k === 'candy' ? '#7ad8ff' : '#9fd8ee', k === 'candy' ? em({ r: 1, op: 0.9 }) : { r: 1, op: 0.85, mat: 'gloss' }), box(0, 54, 0, 154, 3, 114, shade(wd, 1.12), { r: 2, rings: [[54, 0], [57, 0]] }));
      if (k === 'candy') { o.push(slab(0, 0, 55.4, 150, 54, 1, '#8fe8ff', em({ op: 0.35, r: 0 })), ball(-40, 46, -20, 8, WH, { sy: 0.5, op: 0.8, k: 3 }), ball(30, 46, 10, 10, WH, { sy: 0.4, op: 0.7, k: 3 })); }
      else o.push(...[[-40, -20], [30, 14]].map(([x, z]) => ball(x, 48, z, 9, WH, em({ sy: 1.6, op: 0.35, k: 4 }))), slabX(0, 10, 55.2, 150, 3, 1, shade(wd, 0.7)), slabX(0, 40, 55.2, 150, 3, 1, shade(wd, 0.7)));
      return o; } }),
    toilet: S => ({ w: 56, d: 70, build: P => { const k = S.k, c = k === 'royal' ? '#f4f2ee' : k === 'candy' ? '#f4f2ee' : '#f4f2ee', o = [];
      const base = k === 'mod' || k === 'candy' ? 14 : 0;
      if (!base) o.push(cyl(0, 0, 8, 12, 24, c, { rz: 14, n: 14, rg: [[0, 0, 1.1], [24, 0, 0.8]], mat: 'cer' }));
      o.push(cyl(0, 24, 10, 22, 14, c, { rz: 26, n: 18, rg: [[0, 0, 0.75], [14, 0, 1]], mat: 'cer' }), cyl(0, 38, 10, 22, 3, k === 'junk' ? '#c9a46a' : k === 'royal' ? '#f6efe0' : WH, { rz: 26, n: 18 }), cyl(0, 38.4, 10, 15, 0.8, '#9fd2f2', { rz: 18, n: 16, noOut: 1 }));
      if (k === 'junk') { o.push(cyl(0, 24, -22, 6, 100, '#9aa1a6', { n: 8 }), box(0, 120, -24, 46, 24, 18, c, { r: 3, mat: 'cer' }), cyl(18, 80, -14, 0.6, 40, '#8a8f94', { n: 4 }), ball(18, 76, -14, 2.4, '#3a3a3e', { k: 3 }), box(0, 24, -22, 36, 4, 6, '#a0603a', { r: 1, op: 0.6 })); return o; }
      if (k === 'mod') { o.push(slab(0, 0, -30, 54, 110, 6, '#3e4046', { r: 3, rb: 3 }), slab(0, 76, -26.6, 20, 12, 1, '#d5dde2', { r: 3 })); return o; }
      o.push(box(0, 26, -22, 46, k === 'candy' ? 40 : 46, 18, c, { r: 6, bev: 2, mat: 'cer' }), box(0, (k === 'candy' ? 66 : 72), -22, 48, 4, 20, k === 'royal' ? GOLD : c, { r: 6 }));
      if (k === 'royal') o.push(box(22, 44, -2, 5, 6, 16, '#3e4046', { r: 2 }), disc(22, 47, 6, 1.4, 0.6, '#6ac8ff', em()), box(0, 38, 10, 44, 1, 44, GOLD, { r: 18, rings: [[38, 0], [39.2, 0]] }));
      if (k === 'cot') o.push(ball(20, 64, -12, 2.6, CH, { k: 3 }));
      if (k === 'candy') o.push(ball(0, -8, 0, 20, '#8fe8ff', em({ sx: 1.4, sy: 0.25, op: 0.4 })), slab(0, 50, -12.6, 30, 6, 0.6, '#8f7bff', em({ r: 3 })));
      return o; } }),
    sauna: S => ({ w: 130, d: 110, glow: () => S.k === 'candy' ? { y: 50, r: 80, c: 'url(#gNeon)' } : null, build: P => { const k = S.k, o = [], st = (x, y, z, s) => o.push(ball(x, y, z, 10 * s, WH, em({ sy: 1.3, op: 0.35, k: 4 })));
      if (k === 'junk') { o.push(cyl(0, 0, 0, 20, 30, '#9aa1a6', { n: 14, rg: [[0, 0, 0.85], [30, 0, 1]], mat: 'metal' }), cyl(0, 30, 0, 20, 2, '#b5bcc0', { n: 14 }), cyl(0, 26, 0, 17, 1, '#9fd2f2', { n: 14, noOut: 1 }), arcW(0, 30, 0, 20, 20, 1.2, 1.2, PI, PI * 2, '#6b6f74', { n: 8 })); st(-4, 34, 0, 0.8); st(6, 50, -4, 0.9); return o; }
      if (k === 'cot') { o.push(box(0, 0, 0, 74, 104, 74, '#9fb58c', { r: 16, soft: 1, mat: 'fab' }), slab(0, 70, 37.6, 30, 30, 1, '#2c2d31', { r: 14 }), ball(0, 76, 36, 12, '#f2d0b0', { sz: 0.6, k: 4 }), slab(0, 4, 37.4, 1.4, 64, 0.6, '#d5dde2', { r: 0 })); st(-16, 110, 0, 0.8); return o; }
      if (k === 'mod') { const sl = []; for (let i = 0; i < 10; i++) { const a = PI * i / 9; sl.push(solid({ ax: 'x', sh: 'el', c: [0, 60], a: 56, b: 56, n: 20, rings: [[-60, 0], [60, 0]], col: P.w })); break; } o.push(...sl, ...[-60, 60].map(x => slabX(x, 2, 0, 6, 116, 116, shade(P.w, 0.8), { r: 56 })), box(0, 0, 0, 100, 8, 60, shade(P.w, 0.7), { r: 2 })); [-30, 0, 30].forEach(x => o.push(slabX(x, 2, 0, 2.4, 118, 118, shade(P.w, 0.62), { r: 58 }))); return o; }
      if (k === 'royal') { o.push(box(0, 0, 0, 126, 150, 100, P.w, { r: 3 }), box(0, 150, 0, 132, 6, 106, shade(P.w, 0.8), { r: 3 }), slab(-14, 10, 50.4, 70, 130, 1.2, '#f2b866', { r: 2, op: 0.6 }), slab(-14, 30, 49, 64, 18, 12, shade(P.w, 0.85), { r: 2 }), box(40, 70, 51, 4, 26, 3, GOLD, { r: 2 }), slab(-14, 110, 50.8, 50, 18, 0.6, '#e8a080', em({ r: 4, op: 0.45 }))); st(-30, 60, 40, 0.9); return o; }
      o.push(ball(0, 0, 0, 44, '#f1eee8', { sx: 0.8, sz: 1.3, sy: 1.1, k: 7, n: 18, mat: 'cer' }), ball(0, 26, 22, 32, '#8fe8ff', em({ sx: 0.6, sy: 0.7, sz: 0.4, op: 0.55 })), ball(-10, 40, 34, 6, '#c9f4ff', em()), cyl(0, -6, 0, 30, 6, '#3a3c48', { rz: 50, n: 18 }));
      return o; } }),
    greenwall: S => ({ w: 120, d: 14, build: P => { const k = S.k, o = [slab(0, 0, -4, 120, 120, 6, '#8a5a34', { r: 3, rb: 3 })];
      for (let i = 0; i < 26; i++) o.push(ball(-50 + (i * 23 % 100), 8 + (i * 37 % 104), 0, 7 + (i % 3) * 2, ['#5fa84a', '#6fbf54', '#4f9a3e', '#7ac860'][i % 4], { sz: 0.5, k: 3, n: 10 }));
      if (k !== 'junk') o.push(cyl(40, 90, 6, 2, 30, '#d8c27a', { n: 6 }), cyl(40, 88, 9, 1.4, 1, '#9fd2f2', { n: 6 }), box(30, 0, 8, 40, 14, 20, '#b9b4aa', { r: 4 }), box(30, 14, 8, 36, 1, 16, '#9fd8ee', { r: 3 }));
      return o; } }),
    washer: S => ({ w: 66, d: 60, build: P => { const k = S.k, c = k === 'royal' ? P.w : '#f1eee8';
      return [box(0, 0, 0, 62, 84, 56, c, { r: 4, bev: 2 }), box(0, 70, 28.4, 58, 12, 1, k === 'royal' ? shade(c, 0.85) : '#d5dde2', { r: 2 }), disc(16, 76, 28.8, 3, 1, '#3e4046'), disc(0, 36, 28, 22, 2, k === 'royal' ? GOLD : '#c9d3d8'), disc(0, 36, 30, 16, 1, '#7aa6c2', { op: 0.85 }), ball(-6, 34, 30, 7, WH, { sz: 0.3, k: 3, op: 0.6 })]; } }),
    hotplate: S => ({ w: 44, d: 40, build: P => [box(0, 0, 0, 40, 9, 36, '#d8d2c6', { r: 3 }), cyl(0, 9, -2, 13, 1.6, '#3a3a3e', { n: 16 }), arcW(0, 10.6, -2, 10, 10, 1.4, 0.8, 0, PI * 2, '#e2554a', { n: 14 }), arcW(0, 10.6, -2, 5.5, 5.5, 1.4, 0.8, 0, PI * 2, '#e2554a', { n: 12 }), disc(12, 4, 18, 2.4, 1.4, '#2c2d31'), cyl(-14, 0, -16, 0.8, 1, '#3a3a3e', { n: 4 })] }),
    dishwasher: S => ({ w: 64, d: 56, build: P => { const k = S.k, o = [];
      if (k === 'junk') { o.push(cyl(0, 0, 0, 30, 14, '#7fb8d8', { rz: 20, n: 18, mat: 'paint' }), box(0, 14, -6, 60, 2, 30, '#d8d2c6', { r: 2 })); [-20, -10, 0, 10, 20].forEach((x, i) => o.push(disc(x, 34, -6 + (i % 2) * 2, 13, 1.6, i % 2 ? WH : '#f2d27a'))); for (let i = 0; i < 6; i++) o.push(slabX(0, 16 + i * 1, -20 + i * 6, 58, 1, 1, '#d8d2c6', { r: 0 })); return o; }
      if (k === 'cot') { o.push(box(0, 0, 0, 50, 40, 44, '#f1eee8', { r: 6, bev: 2 }), slab(0, 4, 22.4, 42, 26, 1, '#bfe4ff', { r: 4, op: 0.7 }), slab(0, 32, 22.6, 42, 5, 0.6, '#3e4046', { r: 2 })); return o; }
      const c = k === 'royal' ? P.w : k === 'candy' ? '#2a2630' : '#c9d3d8';
      o.push(box(0, 0, 0, 62, 78, 54, c, { r: 3, bev: 2 }), slab(0, 70, 27.4, 60, 6, 0.8, k === 'candy' ? '#8fe8ff' : '#3e4046', { r: 1, emit: k === 'candy' ? 1 : 0 }), slabX(0, 62, 30, 44, 3, 3, k === 'royal' ? GOLD : CH, { r: 1.5 }));
      if (k === 'royal') o.push(slabX(0, 34, 27.6, 58, 1.4, 0.8, shade(c, 0.7)), slabX(0, 28, 30, 30, 3, 3, GOLD, { r: 1.5 }));
      if (k === 'candy') { o.push(ball(0, 80, 0, 8, '#8fe8ff', em({ sy: 0.5 }))); for (let i = 0; i < 4; i++) o.push(disc(-18 + i * 12, 84, -14, 8, 1.4, '#f4f2ee')); }
      return o; } }),
    cart: S => ({ w: 60, d: 42, build: P => { const k = S.k, m = k === 'junk' ? '#d8d2c6' : k === 'cot' ? P.w : k === 'mod' ? GOLD : k === 'royal' ? '#c87a46' : '#d5dde2', top = k === 'royal' ? '#efebe5' : k === 'mod' ? GL : m, o = [];
      if (k === 'candy') { o.push(box(0, 10, 0, 50, 44, 36, '#f1eee8', { r: 12, mat: 'cer' }), slab(0, 34, 18.6, 30, 12, 1, '#2a2630', { r: 5 }), disc(-6, 40, 19.8, 2.2, 0.6, '#8fe8ff', em()), disc(6, 40, 19.8, 2.2, 0.6, '#8fe8ff', em()), slabX(0, 48, 0, 70, 4, 4, '#c9d0d6', { r: 2 }), box(0, 54, 0, 46, 3, 32, '#d5dde2', { r: 4 }), cyl(-8, 57, 0, 5, 12, '#f2c94c', { n: 10 }), ...[[-18, 12], [18, 12], [-18, -12], [18, -12]].map(([x, z]) => ball(x, 0, z, 5, '#3a3c48', { k: 3 }))); return o; }
      [[-26, -18], [26, -18], [-26, 18], [26, 18]].forEach(([x, z]) => o.push(cyl(x, 6, z, 1.8, 74, m, { n: 8 }), ball(x, 0, z, 3.4, '#3a3a3e', { k: 3, n: 8 })));
      [10, 40, 76].forEach((y, i) => o.push(box(0, y, 0, 56, 3, 40, i === 2 ? top : m, { r: 2, op: k === 'mod' && i === 2 ? 0.7 : 1 })));
      if (k === 'royal') { [[-10, 0], [10, 0]].forEach(([x]) => o.push(cyl(x, 92, -14, 9, 5, '#c87a46', { n: 12 }), cyl(x, 116, -14, 0.8, 1, '#c87a46'))); o.push(slabX(0, 110, -18, 60, 2, 2, '#c87a46')); }
      o.push(cyl(-12, 79, 0, 4, 10, k === 'mod' ? '#d9483b' : '#a6d8ff', { n: 10, op: 0.9 }), box(10, 43, 0, 22, 10, 18, k === 'cot' ? '#f1eee8' : '#e3946a', { r: 2 }), ball(14, 79, 4, 5, '#f2c94c', { k: 3 }));
      return o; } }),
    coffeeMk: S => ({ w: 40, d: 34, build: P => { const k = S.k, c = k === 'junk' ? '#3a3a3e' : k === 'royal' ? '#2c2d31' : k === 'candy' ? '#f1eee8' : P.a, o = [];
      if (k === 'mod' || k === 'royal') { o.push(box(0, 0, 0, 44, 38, 30, k === 'mod' ? CH : c, { r: 3 }), box(0, 38, 0, 44, 4, 30, k === 'royal' ? GOLD : '#9aa3a8', { r: 3 }), box(0, 22, 12, 30, 8, 10, '#9aa3a8', { r: 2 }), cyl(-6, 4, 12, 3, 8, CR, { n: 8 }), cyl(6, 4, 12, 3, 8, CR, { n: 8 }), disc(-10, 32, 15.2, 3, 1, '#3e4046'), disc(10, 32, 15.2, 3, 1, '#3e4046'), cyl(26, 0, 0, 7, 30, '#3e4046', { n: 10, rg: [[0, 0, 1], [20, 0, 1], [30, 0, 1.3]] }), cyl(26, 30, 0, 7, 12, '#c49a62', { n: 10, op: 0.8 })); return o; }
      o.push(box(0, 0, -4, 30, 44, 22, c, { r: 4 }), box(0, 44, 2, 30, 6, 30, c, { r: 4 }), cyl(0, 2, 8, 9, 18, '#cfe8f2', { n: 12, op: 0.6, mat: 'cer' }), cyl(0, 2, 8, 8.6, 9, '#5a3a20', { n: 12 }), slabX(0, 22, 8, 22, 2, 18, c, { r: 1 }));
      if (k === 'junk') o.push(slab(4, 8, 17.2, 1, 12, 0.4, WH, { r: 0, noOut: 1 }));
      if (k === 'candy') o.push(ball(0, 52, 2, 8, '#8fe8ff', em({ op: 0.6 })), disc(0, 30, 7.4, 3, 0.6, '#8f7bff', em()));
      return o; } }),
    pergola: S => ({ w: 170, d: 130, build: P => { const k = S.k, o = [];
      if (k === 'junk') { [[-70, -50], [70, -50], [-60, 50], [64, 50]].forEach(([x, z], i) => o.push(cyl(x, 0, z, 2, 90 + (i % 2) * 8, '#c9a46a', { n: 6 }))); o.push(solid({ ax: 'y', sh: 'rr', c: [0, 0], a: 78, b: 58, r: 4, rings: [[92, 0], [96, -6]], col: '#3f7fbf', mat: 'fab', soft: 1 }), slab(-50, 70, 58, 30, 26, 1, '#3f7fbf', { r: 4, soft: 1 })); return o; }
      if (k === 'cot') { o.push(cyl(0, 0, 0, 14, 6, '#3e3e42', { n: 12 }), cyl(0, 6, 0, 2.4, 120, '#f4efe6', { n: 8 })); const C = ['#5b8fd0', WH]; for (let i = 0; i < 8; i++) { const a0 = i / 8 * PI * 2, a1 = (i + 1) / 8 * PI * 2; o.push(solid({ ax: 'y', sh: 'arc', c: [0, 0], a: 82, b: 82, th: 80, a0, a1, n: 3, rings: [[100, 0, 1], [128, 0, 0.04]], col: C[i % 2], cv: 0, mat: 'fab' })); } return o; }
      if (k === 'candy') { o.push(ball(0, 0, 0, 80, '#cfe8f2', { sy: 1, k: 7, n: 20, op: 0.32, mat: 'cer' }), arcW(0, 0, 0, 80, 80, 3, 4, 0, PI * 2, '#d5dde2', { n: 20 })); for (let i = 0; i < 4; i++) o.push(solid({ ax: 'y', sh: 'arc', c: [0, 0], a: 80, b: 80, th: 2, a0: i * PI / 2, a1: i * PI / 2 + 0.06, n: 1, rings: [[0, 0, 1], [80, 0, 0.6], [140, 0, 0.05]], col: '#d5dde2', cv: 0 })); return o; }
      const c = k === 'royal' ? '#c9cfd3' : P.w; [[-74, -54], [74, -54], [-74, 54], [74, 54]].forEach(([x, z]) => o.push(box(x, 0, z, 9, 134, 9, c, { r: 1 })));
      [-60, 60].forEach(z => o.push(slabX(0, 128, z, 166, 8, 6, c, { r: 1 })));
      for (let i = 0; i < 8; i++) o.push(box(-70 + i * 20, 136, 0, k === 'royal' ? 14 : 5, 4, 132, shade(c, 1.06), { r: 1 }));
      if (k === 'mod') for (let i = 0; i < 14; i++) o.push(ball(-70 + (i * 37 % 140), 108 + (i % 3) * 8, -54 + (i * 53 % 108), 6, i % 2 ? '#b9a6e0' : '#9a86d0', { sy: 1.6, k: 3, n: 8 }));
      if (k === 'royal') o.push(slab(-74, 20, 56, 14, 108, 2, '#f4efe6', { r: 3, soft: 1 }), slab(74, 20, 56, 14, 108, 2, '#f4efe6', { r: 3, soft: 1 }));
      return o; } }),
    firepit: S => ({ w: 90, d: 90, round: 1, glow: () => ({ y: 26, r: 60 }), fx: c => H.fire(c, S._fl), build: P => { const k = S.k, o = [], FL = S._fl = [], fl = (x, y, z, s) => FL.push([x, y, z, s]);
      if (k === 'junk') { for (let i = 0; i < 10; i++) { const a = i / 10 * PI * 2; o.push(box(Math.cos(a) * 32, 0, Math.sin(a) * 26, 18, 9, 10, i % 3 ? '#b8664a' : '#a85a40', { r: 1, yaw: -a })); } [0, 1, 2].forEach(i => o.push(cyl(-8 + i * 8, 0, 0, 2, 22, '#8a5a34', { n: 6 }))); fl(0, 2, 0, 1); return o; }
      if (k === 'cot') { o.push(...legs4(26, 26, 14, '#3e3e42', 2), cyl(0, 14, 0, 40, 16, '#3e3e42', { n: 20, rg: [[0, 0, 0.5], [16, 0, 1]], mat: 'metal' })); fl(-6, 24, 0, 1.1); fl(8, 24, 4, 0.8); return o; }
      if (k === 'mod') { o.push(cyl(0, 0, 0, 28, 30, '#c8693f', { n: 16, rg: [[0, 0, 0.8], [18, 0, 1], [30, 0, 0.55]] }), cyl(0, 30, 0, 11, 60, '#c8693f', { n: 12, rg: [[0, 0, 1], [60, 0, 0.7]] }), box(0, 10, 22, 26, 18, 8, '#2c1c14', { r: 9 }), cyl(0, -2, 0, 30, 4, '#3e3e42', { n: 16 })); fl(0, 12, 24, 0.7); return o; }
      if (k === 'royal') { o.push(box(0, 0, 0, 110, 36, 60, '#a9a8a2', { r: 3, mat: 'cer' }), box(0, 36, 0, 116, 4, 66, '#3e4046', { r: 3 }), box(0, 40, 0, 80, 3, 14, '#2c2d31', { r: 2 })); [-30, -10, 10, 30].forEach((x, i) => fl(x, 42, 0, 0.8 + (i % 2) * 0.2)); return o; }
      o.push(prismZ(-10, 10, [[-12, 0], [12, 0], [6, 120], [-6, 120]], '#2a2630', { mat: 'gloss' }), cyl(0, 0, 0, 40, 4, '#7ad8ff', { n: 18, op: 0.6 })); fl(0, 120, 0, 1.2); fl(0, 128, 0, 0.8); return o; } }),
    bbq: S => ({ w: 110, d: 60, fx: c => H.fire(c, S._fl), build: P => { const k = S.k, o = [], FL = S._fl = [], fl = (x, y, z, s) => FL.push([x, y, z, s * 0.85]);
      if (k === 'junk') { o.push(...legs4(16, 10, 8, '#6b6f74', 2), box(0, 8, 0, 50, 18, 30, '#7a6a5a', { r: 2, mat: 'metal' }), box(0, 26, 0, 52, 1.4, 32, '#3a3a3e', { r: 1 }), ball(-10, 26, 0, 5, '#a0603a', { sy: 0.5 }), ball(8, 26, 4, 5, '#c08050', { sy: 0.5 }), box(0, 12, 15.4, 30, 6, 1, '#ff8a3a', em({ r: 2, op: 0.6 }))); return o; }
      if (k === 'mod') { o.push(box(0, 0, 0, 104, 56, 54, '#c9d3d8', { r: 3 }), ...[-34, 0, 34].map(x => slab(x, 6, 27.4, 30, 40, 1, '#d5dde2', { r: 2 })), box(0, 56, 0, 70, 4, 54, '#9aa3a8', { r: 2 }), solid({ ax: 'x', sh: 'rr', c: [-4, 70], a: 26, b: 14, r: 12, rb: 0, rings: [[-34, 0], [34, 0]], col: '#c9d3d8' }), slabX(0, 72, 26, 50, 3, 3, '#3e4046', { r: 1.5 }), box(-46, 56, 0, 22, 2, 50, '#9aa3a8', { r: 2 }), box(46, 56, 0, 22, 2, 50, '#9aa3a8', { r: 2 }), cyl(-50, 60, 34, 4, 3, '#3e4046', { n: 8 })); return o; }
      if (k === 'royal') { o.push(box(0, 0, 0, 120, 60, 60, '#b9b4aa', { r: 3, mat: 'cer' }), box(0, 60, 0, 124, 5, 64, '#3c3c40', { r: 3 }), ball(30, 65, -6, 26, '#b8664a', { sy: 1, sz: 0.9, k: 6, n: 16 }), box(30, 66, 18, 20, 14, 6, '#2c1c14', { r: 7 }), box(-30, 65, 0, 44, 2, 40, '#3a3a3e', { r: 2 }), ...[-48, -30, -12].map(x => slab(x, 10, 30.4, 14, 40, 1, P.w, { r: 2 }))); fl(30, 66, 22, 0.7); return o; }
      o.push(box(0, 0, 0, 120, 60, 60, '#f1eee8', { r: 8, mat: 'cer' }), box(0, 60, 0, 124, 4, 64, '#2a2630', { r: 8 }), box(0, 64, -20, 100, 60, 4, '#cfe8f2', { r: 4, op: 0.4 }), cyl(-30, 64, 0, 14, 2, '#3a3c48', { n: 16 }), cyl(20, 64, 0, 3, 40, '#c9d0d6', { n: 8 }), slabX(20, 100, 0, 44, 3, 3, '#c9d0d6'), ball(20, 92, 0, 8, '#c08050', { sx: 1.6 }), slab(-30, 20, 30.4, 40, 30, 1, '#8fe8ff', em({ r: 4, op: 0.5 })));
      return o; } }),
    bucket: S => ({ w: 40, d: 40, round: 1, build: P => { const k = S.k, c = /cobalt|ceramic|barrel/.test(S.nm) ? '#2f5fb0' : /galvanized|watering|rusty/.test(S.nm) ? '#a9b0b4' : k === 'junk' ? '#f1eee8' : P.a, o = [cyl(0, 0, 0, 16, 34, c, { n: 16, rg: [[0, 0, 0.85], [34, 0, 1]] }), arcW(0, 34, 0, 17, 17, 2, 2, 0, PI * 2, shade(c, 1.1), { n: 16 })];
      if (/ceramic|barrel|cobalt/.test(S.nm)) o.push(arcW(0, 10, 0, 16, 16, 1, 3, 0, PI * 2, WH, { n: 16 }), arcW(0, 24, 0, 17, 17, 1, 3, 0, PI * 2, WH, { n: 16 }), cyl(0, 34, 0, 16, 2, c, { n: 16 }));
      else o.push(arcW(0, 30, 0, 18, 18, 0.8, 0.8, PI, PI * 2, '#6b6f74', { n: 8 }));
      if (/watering/.test(S.nm)) o.push(cyl(20, 6, 0, 2.4, 30, c, { n: 6, yaw: 0 }), box(26, 30, 0, 8, 4, 8, c, { r: 2 }));
      return o; } }),
    stump: S => ({ w: 46, d: 46, round: 1, build: P => [cyl(0, 0, 0, 20, 36, '#8a5a34', { n: 14, rg: [[0, 0, 1.25], [6, 0, 1], [36, 0, 1]] }), cyl(0, 36, 0, 20, 1, '#e6c48e', { n: 14 }), arcW(0, 36.6, 0, 12, 12, 1, 0.6, 0, PI * 2, '#b8864e', { n: 12, noOut: 1 }), arcW(0, 36.6, 0, 6, 6, 1, 0.6, 0, PI * 2, '#b8864e', { n: 10, noOut: 1 }), ball(10, 34, 14, 4, '#6fbf54', { sy: 0.5, k: 3 })] }),
    tirebed: S => ({ w: 60, d: 60, round: 1, build: P => [arcW(0, 0, 0, 28, 28, 12, 14, 0, PI * 2, '#2c2d31', { n: 18 }), cyl(0, 0, 0, 17, 12, '#5a3a20', { n: 14 }), ...[[-6, 0], [6, 4], [0, -6]].map(([x, z], i) => ball(x, 12, z, 6, ['#5fa84a', '#6fbf54', '#4f9a3e'][i], { sy: 1.4, k: 3, n: 8 })), ball(8, 18, -2, 3, '#f2c94c', { k: 3 })] }),
    linens: S => ({ w: 90, d: 60, build: P => { const k = S.k, a = P.a, b = P.b, o = [cush(0, 0, 0, 90, 10, 56, a), cush(0, 10, 0, 86, 10, 52, shade(a, 1.08)), cush(0, 20, 2, 80, 8, 46, b)];
      o.push(pillowZ(-18, 28, -6, 40, 26, 14, k === 'junk' ? '#e8e2d4' : WH), pillowZ(20, 28, -4, 40, 26, 14, k === 'junk' ? '#d8d2c4' : shade(b, 1.15)));
      if (k === 'mod' || /knit/.test(S.nm)) for (let i = 0; i < 4; i++) o.push(cyl(-30 + i * 20, 20, 24, 4, 2, shade(b, 0.9), { n: 8, rz: 3 }));
      if (k === 'royal') o.push(box(0, 26, 24, 82, 1.4, 2, GOLD, { r: 0.6 }));
      if (k === 'candy') o.push(ball(0, -12, 0, 18, '#8fe8ff', em({ sx: 2, sy: 0.3, op: 0.35 })));
      return o; } }),
    garmrack: S => ({ w: 110, d: 46, build: P => { const o = [box(0, 0, 0, 100, 3, 40, '#6b6f74', { r: 2 }), cyl(-48, 3, 0, 1.8, 130, '#9aa1a6', { n: 6 }), cyl(48, 3, 0, 1.8, 130, '#9aa1a6', { n: 6 }), slabX(0, 132, 0, 100, 2.4, 2.4, '#9aa1a6', { r: 1 })];
      ['#5b8fd0', '#e3946a', '#9fb58c', '#f2c94c'].forEach((c, i) => o.push(slab(-30 + i * 20, 70, (i % 2) * 2, 18, 56, 4, c, { r: 4, soft: 1, mat: 'fab' }), cyl(-30 + i * 20, 126, 0, 0.6, 6, '#6b6f74', { n: 4 })));
      return o; } }),
    cheval: S => ({ w: 70, d: 40, build: P => { const k = S.k, fr = k === 'royal' || /gild|brass|gold/.test(S.nm) ? GOLD : k === 'candy' ? '#d5dde2' : P.w, o = [];
      if (k !== 'candy') o.push(prism(-28, -24, [[-16, 0], [-12, 0], [0, 130], [-4, 130]], fr), prism(24, 28, [[-16, 0], [-12, 0], [0, 130], [-4, 130]], fr));
      o.push(slab(0, 14, 2, 50, 140, 5, fr, { r: k === 'mod' || k === 'royal' ? 25 : 6, rb: 6 }), slab(0, 18, 4.8, 42, 132, 0.8, '#cfe8f2', { r: k === 'mod' || k === 'royal' ? 21 : 4, rb: 4, mat: 'gloss' }), slab(-10, 60, 5.4, 8, 60, 0.4, WH, { r: 3, op: 0.6, noOut: 1 }));
      if (k === 'royal') o.push(ball(0, 152, 2, 7, GOLD), slab(0, 18, 5.2, 42, 132, 0.4, '#ffe9a0', em({ r: 21, rb: 4, op: 0.15 })));
      if (k === 'candy') o.push(slab(0, 18, 5.6, 42, 132, 0.4, '#8fe8ff', em({ r: 4, rb: 4, op: 0.3 })), cyl(0, 0, 2, 22, 4, '#3a3c48', { n: 16 }));
      return o; } }),
    decks: S => ({ w: 110, d: 56, glow: () => S.k === 'candy' ? { y: 60, r: 70, c: 'url(#gNeon)' } : null, build: P => { const k = S.k, c = k === 'royal' ? '#2c2d31' : k === 'cot' ? '#3e4046' : '#2c2d31', o = [];
      if (k === 'cot') { o.push(box(0, 0, 0, 70, 5, 40, c, { r: 4 }), ...[-22, 22].map(x => cyl(x, 5, -2, 11, 1.6, '#555860', { n: 16 })), ...[-12, -4, 4, 12].map(x => slab(x, 5, 10, 4, 6, 4, NE[(x + 12) / 8 % 6], { r: 1, emit: 1 })), box(0, 5, -16, 50, 1, 8, '#6b6f74', { r: 1 })); return o; }
      o.push(box(0, 0, 0, 110, 40, 54, k === 'royal' ? '#3e4046' : '#555860', { r: 3 }), box(0, 40, 0, 112, 6, 56, c, { r: 4 }));
      const n = k === 'royal' ? 4 : 2, xs = n === 4 ? [-42, -18, 18, 42] : [-30, 30]; xs.forEach(x => o.push(cyl(x, 46, 0, n === 4 ? 10 : 15, 2, '#1d1d20', { n: 16 }), cyl(x, 48, 0, 3, 0.6, k === 'royal' ? GOLD : '#d9483b', { n: 8 })));
      o.push(box(0, 46, 0, n === 4 ? 14 : 22, 3, 40, k === 'royal' ? GOLD : '#3e4046', { r: 2 }), ...[-6, 0, 6].map(x => slab(x, 46, 14, 2, 6, 2, '#d5dde2', { r: 1 })));
      if (k === 'candy') o.push(...[-30, 0, 30].map((x, i) => slab(x, 56, -10, 26, 30, 0.6, NE[i * 2], em({ r: 3, op: 0.6 }))));
      if (k === 'mod') o.push(slab(0, 4, 27.4, 100, 30, 1, '#8f7bff', em({ r: 3, op: 0.5 })));
      return o; } }),
    fan: S => ({ w: 50, d: 40, build: P => { const o = [cyl(0, 0, 0, 16, 4, '#d8d2c6', { n: 14 }), cyl(0, 4, 0, 2.4, 70, '#d8d2c6', { n: 8 }), disc(0, 86, -4, 18, 8, '#d8d2c6', { op: 0.5 }), disc(0, 86, 4, 5, 3, '#9aa1a6')];
      for (let i = 0; i < 4; i++) o.push(slab(Math.cos(i * PI / 2 + 0.4) * 9, 86 + Math.sin(i * PI / 2 + 0.4) * 9 - 3, 2, 10, 6, 0.6, '#9fd2f2', { r: 3 }));
      if (/bubble/.test(S.nm)) [[-24, 100, 10, 7], [-36, 116, 4, 5], [-20, 124, 0, 4]].forEach(([x, y, z, r]) => o.push(ball(x, y, z, r, '#cfe8f2', { op: 0.55, k: 4 })));
      return o; } }),
    dart: S => ({ w: 60, d: 8, build: P => [disc(0, 70, -4, 30, 4, '#2c2d31'), disc(0, 70, 0, 24, 0.6, '#f2e6c8'), ...[0, 1, 2, 3, 4, 5].map(i => disc(0, 70, 0.6 + i * 0.2, 24 - i * 4, 0.2, i % 2 ? '#d9483b' : '#2f6a4c', { noOut: 1 })), disc(0, 70, 1.8, 2, 0.4, '#d9483b'), cyl(8, 74, 4, 0.8, 1, '#f2c94c'), slab(8, 72, 3, 1, 10, 6, '#f2c94c', { r: 0 }), slab(20, 60, -3.6, 16, 10, 0.4, '#a0603a', { r: 2, op: 0.4 })] }),
    holo: S => ({ w: 70, d: 70, round: 1, glow: () => ({ y: 50, r: 70, c: 'url(#gNeon)' }), build: P => { const o = []; holoBase(o, 0, 28);
      o.push(cyl(0, 6, 0, 22, 80, '#8fe8ff', em({ rg: [[0, 0, 1], [80, 0, 1.4]], op: 0.2 })), arcW(0, 30, 0, 26, 26, 1, 1.4, 0, PI * 2, '#8fe8ff', em({ n: 18 })), arcW(0, 60, 0, 30, 30, 1, 1.4, 0, PI * 2, '#b48cff', em({ n: 18 })));
      if (/mascot|dancer|idol/.test(S.nm)) o.push(ball(0, 28, 0, 16, '#b48cff', em({ op: 0.6 })), ball(0, 56, 0, 11, '#c9f4ff', em({ op: 0.7 })));
      else if (/arena|sport/.test(S.nm)) o.push(ball(0, 34, 0, 10, '#ffd66b', em({ op: 0.8 })), cyl(30, 0, -20, 3, 70, '#c9d0d6', { n: 8 }), cyl(30, 70, -20, 6, 20, '#3e4046', { n: 10, yaw: 0 }));
      else o.push(ball(-8, 30, 0, 9, '#c9f4ff', em({ op: 0.7 })), box(8, 26, 4, 14, 22, 14, '#8f7bff', em({ op: 0.5, r: 2 })), ball(4, 62, -4, 6, '#ffd66b', em()));
      return o; } }),
    cups: S => ({ w: 50, d: 40, build: P => [cyl(-10, 0, 0, 6, 16, '#d9483b', { n: 12, rg: [[0, 0, 0.75], [16, 0, 1]] }), cyl(-10, 16, 0, 6, 1.4, WH, { n: 12 }), cyl(6, 0, 6, 6, 16, '#d9483b', { n: 12, rg: [[0, 0, 0.75], [16, 0, 1]] }), cyl(6, 16, 6, 6, 1.4, WH, { n: 12 }), cyl(8, 0, -10, 6, 16, '#d9483b', { n: 12, rg: [[0, 0, 0.75], [16, 0, 1]], yaw: 0 }), ...[[18, 4, '#a6f06a'], [22, 2, '#4fe0d0'], [-22, 6, '#ffd66b']].map(([x, z, c]) => box(x, 0, z, 3, 2, 22, c, em({ r: 1.5 })))] }),
    popbucket: S => ({ w: 36, d: 36, round: 1, build: P => { const o = [cyl(0, 0, 0, 12, 26, WH, { n: 16, rg: [[0, 0, 0.75], [26, 0, 1]] })]; for (let i = 0; i < 4; i++) o.push(slab(Math.cos(i * 0.5 - 0.8) * 10.5, 1, Math.sin(i * 0.5 - 0.8) * 10.5 + 0, 3.6, 24, 0.4, '#d9483b', { r: 0, yaw: 0 })); for (let i = 0; i < 9; i++) o.push(ball(-8 + (i % 4) * 5, 25 + Math.floor(i / 4) * 3, -4 + (i * 3 % 9), 3, i % 3 ? '#fff4d0' : '#f2d27a', { k: 3, n: 8 })); o.push(box(18, 0, 6, 14, 1, 8, '#f2c94c', { r: 1 }), box(20, 1, 10, 14, 1, 8, '#e88a3a', { r: 1 })); return o; } }),
  };
  const patch = (x, y, z, w, h, col) => box(x, y, z, w, h, 1.2, col, { r: 2 });
  // live fire: SVG flames at the build's flame points, flickering with SMIL (works inside <img> data URIs)
  const H = { em, patch, legs4, metalOf, holoBase,
    fire(c, L, heater) { let f = ''; const OUT = 'M-7 0C-9 -6 -6 -11 -3 -15C-3 -10 -1 -9 0 -13C1 -18 0 -21 -1 -25C4 -21 7 -15 5 -10C7 -11 8 -13 8 -15C10 -9 9 -3 7 0Z', MID = 'M-5 0C-6 -5 -4 -8 -2 -11C-1 -8 0 -8 1 -11C4 -8 5 -4 4 0Z', INN = 'M-3 0C-3.5 -3 -2 -5 -0.5 -7C0.5 -5 2 -4 2.4 0Z';
      (L || []).forEach(([x, y, z, s], i) => { const q = c.p(x, y, z), u = c.k * s * 0.95, d = (0.5 + (i % 3) * 0.14).toFixed(2), b = (-i * 0.23).toFixed(2);
        f += '<g transform="translate(' + f1(q[0]) + ' ' + f1(q[1]) + ') scale(' + f1(u) + ')"><ellipse cx="0" cy="-9" rx="15" ry="13" fill="#ffb347" opacity="0.25"><animate attributeName="opacity" values="0.16;0.34;0.2;0.3;0.16" dur="1.4s" begin="' + b + 's" repeatCount="indefinite"/></ellipse>'
          + '<g><animateTransform attributeName="transform" type="scale" values="1 1;0.9 1.16;1.07 0.9;0.96 1.1;1 1" dur="' + d + 's" begin="' + b + 's" repeatCount="indefinite"/><path d="' + OUT + '" fill="#ff7a22"/><path d="' + MID + '" fill="#ffb53a"/><path d="' + INN + '" fill="#fff1b0"/></g>'
          + [0, 1, 2].map(j => '<circle cx="' + (j * 3 - 3) + '" cy="-14" r="0.9" fill="#ffd66b"><animate attributeName="cy" values="-12;-40" dur="' + (1.4 + j * 0.3) + 's" begin="' + (-j * 0.5 + +b) + 's" repeatCount="indefinite"/><animate attributeName="opacity" values="1;0" dur="' + (1.4 + j * 0.3) + 's" begin="' + (-j * 0.5 + +b) + 's" repeatCount="indefinite"/></circle>').join('') + '</g>'; });
      if (heater) { const q = c.p(0, 18, 29.4), u = c.k; f += '<rect x="' + f1(q[0] - 10 * u) + '" y="' + f1(q[1] - 7 * u) + '" width="' + f1(20 * u) + '" height="' + f1(13 * u) + '" rx="' + f1(2 * u) + '" fill="#ff6a2a"><animate attributeName="opacity" values="0.35;0.85;0.5;0.8;0.35" dur="2.2s" repeatCount="indefinite"/></rect>'; }
      return { over: f }; } };

  // ---------- slot -> archetype per room (5 tiers each when an array) ----------
  const M = {
    MOV: ['s:wall', 's:floor', 's:ceil', 's:door', 's:light', ['s:ylight', 'neonSign@retro', 'sconce', 'sconce', 'crystal'], ['sheet', 'wallTV', 'wallTV', 'projector', 'projector'], 'projDev', ['speaker*0.7', 'sub', 'speaker', 'spkTower', 'speaker'],
      ['chaise', 'sofa', 'sofa', 'longSofa', 'pit'], ['chair', 'pouf', 'armchair', 'armchair', 'armchair'], 'petbed', 'coffee', ['tray', 'tray', 'bistro', 'bistro', 'cart'], 'popcorn', ['icechest', 'minifridge', 'minifridge+glass@retro', 'minifridge+glass', 'minifridge+glass'], ['shelf', 'bookcase', 'tvstand', 'bookcase', 'holo'], ['rug2.oval', 'rug2.runner', 'rug2.shag', 'rug2', 'rug2.spiral'], ['poster.movie', 'gallery', 'poster.movie', 'gallery', 'gallery'], ['tbBox', 'popbucket', 'tbBooks', 'tbTrophy', 'holo*0.45']],
    LIV: ['s:wall', 's:floor', 's:ceil', 's:win', 'hearth', 's:light', 'lamp', ['sofa', 'sofa', 'lsofa', 'pit', 'sofa'], ['chair', 'armchair', 'armchair', 'armchair', 'armchair'], ['cardbox*0.7', 'pouf', 'pouf', 'pouf', 'pouf'], ['#spoolTable', 'coffee', 'coffee', 'coffee', 'coffee'], ['crate', 'bistro', 'nightstand', 'bistro', 'bistro'], 'console',
      ['shelf', 'bookcase', 'bookcase', 'bookcase', 'bookcase'], ['miniTV', 'wallTV', '#radio', 'tvstand', 'holo'], ['petbed', 'petbed', 'cattree', 'petbed', 'petbed'], ['mat', 'rug2.hex', 'rug2', 'rug2.zig', 'rug2.spiral'], ['plant', 'plant', 'monstera', 'bonsai', 'bonsai'], ['poster', 'mirror', 'gallery', 'mirror', 'poster.sunset'], ['tbBooks', 'tbCandles', 'tbBooks', 'tbVase', 'tbGlobe']],
    BTH: ['s:wall', 's:floor', 's:ceil', 'divider', ['tub', 'tub', 'tub', 'onsen', 'onsen'], 'shower', 'toilet', 'bsink', 'mirror', ['sconce', 'sconce', 'lantern*0.7', 'sconce', 'sconce'], ['stool', 'stool', 'stool', 'bench', 'chaise'], ['tbSoap', 'tray', 'bistro', 'cart', 'tray'], ['rack', 'rack', 'rack', 'washer', 'wardrobe*0.8'], 'sauna',
      ['tub*0.5', 'tub*0.5', 'onsen*0.45', 'sauna*0.55', 'onsen*0.5'], ['mat', 'rug2.oval', 'mat', 'rug2.runner', 'rug2.shag'], ['plant*0.7', 'plant', 'plant', 'greenwall', 'bonsai'], ['basket', 'basket', 'dresser*0.7', 'washer', 'wardrobe'], ['poster', 'gallery', 'poster', 'poster', 'poster.sunset'], ['tbSoap', 'tbCup', 'tbCandles', 'tbPerfume', 'tbPerfume']],
    KIT: ['s:wall', 's:floor', 's:ceil', 's:win', ['minifridge', 'fridge', 'fridge', 'fridge', 'fridge'], ['hotplate', 'stove', 'stove', 'stove', 'stove'], 'counter+sink', 'dishwasher', 'counter', ['table', 'cart', 'table', 'counter', 'counter'], ['stool', 'chair', 'chair', 'chair', 'chair'], 'stool', 'cart', 'coffeeMk',
      ['tbToaster', 'tbMixer', 'tbToaster', 'tbMixer', 'holo*0.45'], ['wallShelf', 'wallShelf', 'hutch', 'hutch', 'hutch'], 's:light', 'bowl', ['poster', 'poster.fruit', 'wallShelf', 'gallery', 'poster.stars'], ['tbJar', 'tbFruit', 'tbTeapot', 'tbJar', 'tbGlobe']],
    YRD: ['s:fence', 's:ground', 'pergola', ['house', 'house', 'house', 'house', 'pergola@royal'], ['pool', 'pool', 'fountain', 'pool', 'pool'], 'firepit', ['bbq', '#kettleGrill', 'bbq', 'bbq', 'bbq'], ['chair', 'chair', 'lsofa', 'chaise', 'chaise'], ['hammock', 'hammock', 'swing', 'swing', 'hammock'], 'bench', ['table', 'table', 'bistro', 'table', 'table'], ['bucket', 'stump', 'bucket', 'bistro', 'bistro'],
      ['lantern', 'solar', 's:ylight', 'solar', 'lantern'], ['tirebed', 'flowerBed', 'flowerPot', 'flowerBed', 'bonsai'], 'tree', ['cardbox*0.7', 'house*0.5', 'seesaw*0.6', 'house*0.6', 'dome*0.6'], ['ringToss', 'toss', 'pong', 'golf', 'holo'], ['mat', 'rug2.stripe', 'rug2.zig', 'rug2', 'rug2.rainbow'], ['gnome', 'spinner', 'birdbath', 'urn', 'spinner'], ['bucket*0.6', 'bucket*0.6', 'tiki*0.6', 'tbTeapot', 'tbGlobe']],
    BED: ['s:wall', 's:floor', 's:ceil', 's:win', 'bed', 'linens', ['cardbox*0.7', 'nightstand', 'nightstand', 'nightstand', 'nightstand'], ['tableLamp', 'tableLamp', 'sconce', 'tableLamp', 'tableLamp'], 's:light', ['garmrack', 'wardrobe', 'wardrobe', 'wardrobe', 'wardrobe'], ['dresser*0.8', 'dresser', 'dresser', 'dresser', 'dresser'], ['tray', 'desk', 'desk', 'desk', 'desk'],
      ['stool', 'pouf', 'armchair', 'armchair', 'armchair'], ['chest', 'bench', 'bench', 'bench', 'bench'], ['mirror', 'cheval', 'cheval', 'cheval', 'cheval'], 'petbed', ['mat', 'rug2.shag', 'rug2.runner', 'rug2', 'rug2.oval'], ['tbClock', 'tbRadio', 'tbClock', 'projDev', 'holo*0.45'], ['poster.stars', 'gallery', 'gallery', 'poster', 'poster.sunset'], ['tbCup', 'tbPerfume', 'tbBooks', 'tbCandles', 'tbSnow']],
    CLB: ['s:wall', 's:floor', 's:ceil', 's:door', 'dj', ['speaker@junk', 'decks', 'decks', 'decks', 'holo'], ['speaker', 'speaker', 'spkWall', 'spkTower', 'sub'], ['s:light', 's:light', 'spot', 'laser', 'crystal'], ['fan', 'smokeSpk', 'smokeSpk', 'smokeSpk', 'smokeSpk'], ['icechest', 'bar', 'bar', 'bar', 'bar'], ['sofa@retro', 'lsofa', 'usofa', 'usofa', 'pit'], ['crate', 'stool@retro', 'gcube', 'stool', 'gcube'],
      ['#spoolTable', 'bistro+tall', 'coffee', 'coffee', 'coffee'], ['stool', 'bistro', 'bistro+tall', 'bistro', 'bistro'], ['dart', 'pinball', 'arcade', 'pong', 'holo'], ['cardbox*0.6', 'stage*0.45', 'decks*0.5', 'pouf', 'stage*0.45'], ['mat', 'rug2.runner', 'rug2', 'rug2.runner', 'rug2.rainbow'], ['beanpile', 'lamp@retro', 'gcube', 'chaise', 'chaise'], ['poster.stars', 'neonSign', 'gallery', 'ledWall', 'infinity'], ['cups', 'tbJar', 'tbCandles', 'tbTrophy', 'tbGlobe']],
  };
  const RETRO = /\bretro\b|diner|70s|jukebox|vintage red|cola|neon pinball|'now showing'/i;
  const FLOAT = /levitat|floating|hover|zero-g|anti-grav|suspended magnetic|magnetic cloud/i;
  const HOLO = /holo|hologra|bioluminescent|plasma|quantum|aurora|nebula/i;
  function parseSpec(s) { const m = s.match(/^([^.@*+]+)(.*)$/), o = { base: m[1], v: '', band: '', zs: 1, flags: [] }; for (const t of m[2].matchAll(/([.@*+])(\w+(?:\.\d+)?)/g)) { if (t[1] === '.') o.v = t[2]; else if (t[1] === '@') o.band = t[2]; else if (t[1] === '*') o.zs = +t[2]; else o.flags.push(t[2]); } return o; }
  const specFor = r => { const e = M[r.room] && M[r.room][r.slot - 1]; if (!e) return parseSpec('box'); return parseSpec(Array.isArray(e) ? e[r.tier - 1] : e); };

  // ---------- surface vignettes (flat SVG polys like X.swatch) ----------
  const pd = (d, f, s, w, o) => ({ d, f, s: s || 'none', w: w || 0, o: o == null ? 1 : o });
  const rr = (x, y, w, h, r) => { r = Math.min(r, w / 2, h / 2); return 'M' + f1(x + r) + ' ' + f1(y) + 'H' + f1(x + w - r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x + w) + ' ' + f1(y + r) + 'V' + f1(y + h - r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x + w - r) + ' ' + f1(y + h) + 'H' + f1(x + r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x) + ' ' + f1(y + h - r) + 'V' + f1(y + r) + 'A' + r + ' ' + r + ' 0 0 1 ' + f1(x + r) + ' ' + f1(y) + 'Z'; };
  const circ = K.circ, ell = K.ell;
  const has = (n, re) => re.test(n);
  const rnd = s => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) | 0; return () => { h = (h * 1103515245 + 12345) | 0; return ((h >>> 8) & 0xffff) / 65536; }; };
  function wallPolys(n, C, tier) {
    const o = [], L = n.toLowerCase(), R = rnd(n); let b0 = C.anyA ? C.a : ['#d9c9ae', '#e8dcc8', '#ece6da', '#e2d0b0', '#3a3448'][tier - 1];
    if (has(L, /foam|egg-carton/)) b0 = /black/.test(L) ? '#34343a' : '#8a8f94';
    o.push(pd(rr(0, 0, 80, 56, 4), b0));
    const dk = shade(b0, 0.82), lt = mix(b0, '#ffffff', 0.3);
    if (has(L, /wainscot/)) { o.push(pd(rr(0, 30, 80, 26, 0), tier >= 3 ? '#2f4870' : '#f4f1ea'), pd(rr(0, 28, 80, 3, 0), '#fffaf1')); [6, 26, 46, 66].forEach(x => o.push(pd(rr(x, 34, 12, 18, 1), 'none', shade(tier >= 3 ? '#2f4870' : '#f4f1ea', 0.85), 1))); }
    if (has(L, /egg-carton|pyramid|foam/)) for (let y = 0; y < 5; y++) for (let x = 0; x < 7; x++) { const cx = 6 + x * 11.5, cy = 6 + y * 11; o.push(pd('M' + (cx - 5) + ' ' + (cy + 5) + 'L' + cx + ' ' + (cy - 5) + 'L' + (cx + 5) + ' ' + (cy + 5) + 'Z', lt, 0, 0, 0.5), pd('M' + cx + ' ' + (cy - 5) + 'L' + (cx + 5) + ' ' + (cy + 5) + 'L' + cx + ' ' + (cy + 2) + 'Z', dk, 0, 0, 0.7)); }
    else if (has(L, /drape|velvet|silk-woven|curtain/)) for (let i = 0; i < 8; i++) o.push(pd('M' + (i * 10 + 2) + ' 0Q' + (i * 10 + 6) + ' 28 ' + (i * 10 + 2) + ' 56H' + (i * 10 + 6) + 'Q' + (i * 10 + 9) + ' 28 ' + (i * 10 + 6) + ' 0Z', dk, 0, 0, 0.6));
    else if (has(L, /slat|panel+ing|paneling|shiplap|hinoki|cedar accent/)) for (let i = 0; i < 11; i++) o.push(pd(rr(i * 7.4 + 1, 0, 5, 56, 1), i % 2 ? lt : dk, 0, 0, 0.5));
    else if (has(L, /brick|cinderblock/)) { for (let y = 0; y < 8; y++) for (let x = 0; x < 5; x++) o.push(pd(rr(x * 17 - (y % 2) * 8, y * 7, 16, 6, 1), y % 3 ? b0 : dk, shade(b0, 0.7), 0.6)); }
    else if (has(L, /subway|tile|backsplash|zellige/)) { const hex = /hex/.test(L); for (let y = 0; y < 9; y++) for (let x = 0; x < 6; x++) o.push(pd(rr(x * 14 - (y % 2) * 7, y * 6.4, 13, 5.6, hex ? 2.5 : 1), y * 7 + x * 3 & 1 ? b0 : lt, has(L, /mildew|cracked/) ? '#8a8a70' : '#ffffff', 0.7)); if (has(L, /cracked/)) o.push(pd('M30 4L36 18L32 26L40 40', 'none', '#6a6a5a', 1)); }
    else if (has(L, /herringbone/)) for (let y = 0; y < 6; y++) o.push(pd('M0 ' + (y * 10 + 5) + 'l10 -8l10 8l10 -8l10 8l10 -8l10 8l10 -8l10 8', 'none', dk, 1.6, 0.7));
    else if (has(L, /marble|onyx|quartzite|calacatta|stone|slate|basalt|tadelakt|limewash|plaster|venetian|travertine/)) { o.push(pd('M0 18Q20 10 34 22T80 14', 'none', dk, 1, 0.7), pd('M8 56Q22 36 46 40T80 30', 'none', dk, 0.8, 0.6), pd('M40 0Q48 14 62 18', 'none', lt, 1.2, 0.7)); if (has(L, /brass|gold/)) o.push(pd('M0 28H80', 'none', GOLD, 1.6)); if (has(L, /slab|slate/)) o.push(pd('M0 28H80M40 0V28M20 28V56M60 28V56', 'none', dk, 1)); if (has(L, /backlit|translucent/)) o.push(pd(rr(0, 0, 80, 56, 4), '#ffe9a0', 0, 0, 0.25)); }
    else if (has(L, /wallpaper/) && !has(L, /chinoiserie|botanical/)) for (let i = 0; i < 5; i++) o.push(pd(rr(4 + i * 16, 0, 7, 56, 0), lt, 0, 0, 0.45));
    else if (has(L, /chinoiserie|botanical/)) [[14, 12], [48, 8], [30, 30], [64, 32], [10, 46], [50, 50]].forEach(([x, y], i) => { o.push(pd('M' + x + ' ' + y + 'q6 -8 12 -2q-6 8 -12 2Z', i % 2 ? '#6aa65a' : '#9fb58c', 0, 0, 0.8), pd(circ(x + 3, y + 4, 2), '#e3946a', 0, 0, 0.8)); });
    else if (has(L, /graffiti/)) { o.push(pd('M8 30q8 -16 16 0t16 0', 'none', '#e2554a', 3), pd('M44 18q6 10 14 -2t12 6', 'none', '#4fe0d0', 3), pd('M14 46l10 -6l8 8l12 -10', 'none', '#ffd66b', 2.4)); for (let i = 0; i < 8; i++) o.push(pd(rr(R() * 70, R() * 50, 8, 6, 0), '#d5dde2', 0, 0, 0.5)); for (let y = 0; y < 8; y++) o.push(pd('M0 ' + y * 7 + 'H80', 'none', dk, 0.5, 0.4)); }
    else if (has(L, /mirror-tile|geometric mirror|led matrix|visualizer|plasma|starlight|holographic|liquid-light/)) { o[0] = pd(rr(0, 0, 80, 56, 4), has(L, /mirror/) ? '#5a6a7a' : '#1e1a30'); for (let i = 0; i < 26; i++) o.push(pd(circ(R() * 80, R() * 56, 0.8 + R() * 1.4), NE[i % 6], 0, 0, 0.9)); if (has(L, /plasma|liquid|visualizer/)) o.push(pd('M0 40Q20 10 40 30T80 20', 'none', '#8f7bff', 4, 0.6), pd('M0 20Q24 44 50 24T80 40', 'none', '#4fe0d0', 3, 0.6)); if (has(L, /mirror/)) for (let x = 0; x < 6; x++) o.push(pd('M' + (x * 14) + ' 0L' + (x * 14 + 7) + ' 28L' + (x * 14) + ' 56', 'none', '#c9d8e4', 0.8, 0.8)); }
    else if (has(L, /copper/)) for (let i = 0; i < 30; i++) o.push(pd(circ(R() * 80, R() * 56, 2.6), '#c87a46', '#a8643a', 0.5, 0.6));
    else if (has(L, /neon/)) {}
    if (has(L, /neon tube|neon accent/)) o.push(pd('M0 14H80', 'none', '#ff6ad5', 2.4), pd('M0 14H80', 'none', '#ffffff', 0.8), pd('M0 44H80', 'none', '#4fe0d0', 2.4));
    if (has(L, /peeling|stain|water-|scuffed|grease|tack|mildew/)) { o.push(pd(ell(22, 18, 11, 7), '#8a6a48', 0, 0, 0.18), pd(ell(56, 34, 8, 12), '#8a6a48', 0, 0, 0.12)); if (/peel/.test(L)) o.push(pd('M62 4Q70 8 66 20L74 22L72 2Z', '#f1e8d6', dk, 1)); if (/tack/.test(L)) [[16, 10], [38, 12], [60, 8], [24, 30]].forEach(([x, y]) => o.push(pd(circ(x, y, 1.6), '#6b5a40', 0, 0, 0.5))); if (/grease/.test(L)) [[30, 40], [36, 44], [44, 38]].forEach(([x, y]) => o.push(pd(circ(x, y, 3), '#a08040', 0, 0, 0.25))); }
    if (has(L, /foil/)) o.push(pd(rr(46, 6, 26, 20, 1), '#d5dde2', '#9aa1a6', 0.6));
    if (has(L, /hinoki|cedar accent|walnut paneling/)) o.push(pd(rr(52, 0, 28, 56, 0), C.w, 0, 0, 0.9), ...[56, 62, 68, 74].map(x => pd('M' + x + ' 0V56', 'none', shade(C.w, 0.8), 0.8)));
    o.push(pd(rr(0, 0, 80, 56, 4), 'none', shade(b0, 0.6), 1.2));
    return { vb: '0 0 80 56', polys: o };
  }
  function floorPolys(n, C, tier, ground) {
    const o = [], L = n.toLowerCase(), R = rnd(n), T = 'M14 0H66L80 56H0Z', px = (u, v) => [14 - 14 * v + (52 + 28 * v) * u, v * 56], P = (u, v) => f1(px(u, v)[0]) + ' ' + f1(px(u, v)[1]);
    if (has(L, /mirror-polished|pristine/)) { // shiny showroom marble: gold inlay grid, reflections, static reflections (sheen/twinkle flash removed at user request)
      const q = [pd(T, '#f7f4ef')], ln = (u0, v0, u1, v1, c, w, op) => q.push(pd('M' + P(u0, v0) + 'L' + P(u1, v1), 'none', c, w, op));
      for (let u = 1; u < 4; u++) ln(u / 4, 0, u / 4, 1, '#e6dfd2', 0.8, 1); for (let v = 1; v < 3; v++) ln(0, v / 3, 1, v / 3, '#e6dfd2', 0.8, 1);
      ln(0.5, 0, 0.5, 1, GOLD, 1.4, 1); ln(0, 0.5, 1, 0.5, GOLD, 1.4, 1);
      q.push(pd('M' + P(0.42, 0.42) + 'L' + P(0.58, 0.42) + 'L' + P(0.58, 0.58) + 'L' + P(0.42, 0.58) + 'Z', 'none', GOLD, 1.2));
      [[0.18, 0.2], [0.7, 0.3], [0.32, 0.75], [0.82, 0.8]].forEach(([u, v]) => { const a = px(u, v); q.push(pd('M' + f1(a[0] - 3) + ' ' + f1(a[1] + 6) + 'l6 -12l2 0l-6 12Z', '#ffffff', 0, 0, 0.7)); });
      q.push(pd(T, 'none', '#c9bfae', 1.2)); return { vb: '0 0 80 56', polys: q }; }
    let f = C.anyA ? C.a : ground ? '#93cf70' : ['#a9a8a2', '#d4a56a', '#e0c49a', '#d8cbb4', '#2a2630'][tier - 1];
    if (has(L, /concrete/)) f = '#a9a8a2'; if (has(L, /dirt|mud/)) f = '#a88a5c'; if (has(L, /lawn|turf|grass|clover|moss lawn|star-moss/)) f = has(L, /star|bioluminescent/) ? '#2a3a40' : '#8fcf6a'; if (has(L, /carpet|pile|cushion/) && !C.anyA) f = '#b9ab9a';
    o.push(pd(T, f));
    const dk = shade(f, 0.8), lt = mix(f, '#ffffff', 0.3), line = (u0, v0, u1, v1, c, w, op) => o.push(pd('M' + P(u0, v0) + 'L' + P(u1, v1), 'none', c, w, op));
    if (has(L, /checker|checkerboard|vinyl tile|moss-inlaid/)) { for (let v = 0; v < 5; v++) for (let u = 0; u < 6; u++) if ((u + v) % 2) o.push(pd('M' + P(u / 6, v / 5) + 'L' + P((u + 1) / 6, v / 5) + 'L' + P((u + 1) / 6, (v + 1) / 5) + 'L' + P(u / 6, (v + 1) / 5) + 'Z', has(L, /moss/) ? '#6f8f4a' : has(L, /black/) ? '#2c2d31' : dk, 0, 0, 0.9)); if (has(L, /peeling/)) o.push(pd(ell(54, 40, 7, 3), '#c9c2b2', 0, 0, 0.9)); }
    else if (has(L, /light-up|disco squares|rgb matrix|interactive|haptic|levitation|glass flooring|led guides|footstep glow/)) { for (let v = 0; v < 4; v++) for (let u = 0; u < 5; u++) o.push(pd('M' + P(u / 5 + 0.01, v / 4 + 0.02) + 'L' + P((u + 1) / 5 - 0.01, v / 4 + 0.02) + 'L' + P((u + 1) / 5 - 0.01, (v + 1) / 4 - 0.02) + 'L' + P(u / 5 + 0.01, (v + 1) / 4 - 0.02) + 'Z', NE[(u * 3 + v * 2) % 6], 0, 0, has(L, /guides|footstep/) ? 0.12 : 0.75)); if (has(L, /guides/)) [0.2, 0.8].forEach(u => line(u, 0, u, 1, '#ffe9a0', 1.6, 0.9)); }
    else if (has(L, /herringbone|chevron|parquet/)) for (let v = 0; v < 6; v++) { let d = ''; for (let u = 0; u <= 8; u++) d += (u ? 'L' : 'M') + P(u / 8, (v + (u % 2) * 0.7) / 6); o.push(pd(d, 'none', dk, 1.4, 0.8)); }
    else if (has(L, /plank|oak|teak|hardwood|subfloor|laminate|ash|wood|duckboard/)) { for (let u = 1; u < 7; u++) line(u / 7, 0, u / 7, 1, dk, 1.1, 0.8); for (let i = 0; i < 6; i++) { const u = (i + 0.5) / 7, v = R(); line(u - 0.07, v, u + 0.07, v, dk, 0.8, 0.6); } if (has(L, /splintery|cold/)) o.push(pd(ell(50, 30, 6, 2), '#8a6a48', 0, 0, 0.3)); if (has(L, /plush perimeter/)) o.push(pd('M' + P(0, 0.75) + 'L' + P(1, 0.75) + 'L' + P(1, 1) + 'L' + P(0, 1) + 'Z', '#e8dcc8', 0, 0, 0.9)); if (has(L, /pebble/)) {} }
    else if (has(L, /hex|porcelain|terrazzo|quarry|tile|linoleum|vinyl/)) { for (let u = 1; u < 6; u++) line(u / 6, 0, u / 6, 1, dk, 0.9, 0.7); for (let v = 1; v < 5; v++) line(0, v / 5, 1, v / 5, dk, 0.9, 0.7); if (has(L, /terrazzo/)) for (let i = 0; i < 24; i++) { const q = px(R(), R()); o.push(pd(circ(q[0], q[1], 1.2), NE[i % 6], 0, 0, 0.5)); } if (has(L, /cracked|curled|scuffed/)) o.push(pd('M20 20L30 30L26 40', 'none', '#6a6a5a', 1), pd('M66 4L72 10L64 12Z', '#c9c2b2')); }
    else if (has(L, /pebble/)) for (let i = 0; i < 30; i++) { const q = px(R(), R()); o.push(pd(ell(q[0], q[1], 3, 1.8), i % 2 ? '#c9c2b6' : '#9a948a', 0, 0, 0.9)); }
    else if (has(L, /marble|stone|basalt|onyx|quartz|slab|travertine|paver|flagstone/)) { line(0.5, 0, 0.5, 1, dk, 1.2, 0.7); line(0, 0.45, 1, 0.45, dk, 1.2, 0.7); o.push(pd('M10 40Q24 32 38 42', 'none', has(L, /gold/) ? GOLD : lt, 1.4, 0.8)); if (has(L, /gold vein|illumination/)) o.push(pd('M44 10Q56 20 70 16', 'none', GOLD, 1.4)); if (has(L, /drain/)) line(0.1, 0.8, 0.9, 0.8, GOLD, 2, 1); }
    else if (has(L, /carpet|pile|loop/)) { for (let i = 0; i < 70; i++) { const q = px(R(), R()); o.push(pd(circ(q[0], q[1], 0.8), i % 2 ? dk : lt, 0, 0, 0.6)); } if (has(L, /aisle/)) [0.25, 0.75].forEach(u => line(u, 0, u, 1, '#e2b14a', 1.6, 0.9)); if (has(L, /tiles/)) { line(0.5, 0, 0.5, 1, dk, 0.8, 0.6); line(0, 0.5, 1, 0.5, dk, 0.8, 0.6); } }
    else if (has(L, /cardboard/)) o.push(pd('M' + P(0.2, 0.2) + 'L' + P(0.8, 0.2) + 'L' + P(0.8, 0.85) + 'L' + P(0.2, 0.85) + 'Z', '#c49a62', '#8a6a42', 0.8), pd('M' + P(0.2, 0.5) + 'L' + P(0.8, 0.5), 'none', '#d8c8a0', 3));
    if (has(L, /concrete/)) { for (let i = 0; i < 20; i++) { const q = px(R(), R()); o.push(pd(circ(q[0], q[1], 0.7), dk, 0, 0, 0.6)); } o.push(pd('M30 10L36 24L32 34L40 50', 'none', shade(f, 0.6), 1)); }
    if (has(L, /duct-tape|cables/)) o.push(pd('M4 40Q30 30 50 44T80 36', 'none', '#2c2d31', 1.6), pd(rr(30, 32, 10, 4, 1), '#b9bcbf'));
    if (has(L, /lawn|turf|grass|clover|ryegrass/)) for (let i = 0; i < 22; i++) { const q = px(R(), R()); o.push(pd('M' + f1(q[0]) + ' ' + f1(q[1]) + 'l-1.4 -4M' + f1(q[0] + 2) + ' ' + f1(q[1]) + 'l1 -4.4', 'none', dk, 1, 0.8)); }
    if (has(L, /clover/)) [[30, 30], [52, 44], [20, 46]].forEach(([x, y]) => o.push(pd(circ(x, y, 2), '#fffaf1'), pd(circ(x + 3, y, 2), '#fffaf1')));
    if (has(L, /stepping|flagstone/)) [[0.4, 0.15], [0.55, 0.45], [0.4, 0.8]].forEach(([u, v]) => { const q = px(u, v); o.push(pd(ell(q[0], q[1], 8 + v * 4, 3 + v * 2), '#c9c2b6', '#9a948a', 0.8)); });
    if (has(L, /puddle|patchy|crabgrass/)) o.push(pd(ell(48, 38, 12, 4), '#8fb8c8', 0, 0, 0.8), pd(ell(24, 20, 9, 4), '#93b86a', 0, 0, 0.9));
    if (has(L, /star-moss|bioluminescent/)) for (let i = 0; i < 26; i++) { const q = px(R(), R()); o.push(pd(circ(q[0], q[1], 1 + R()), i % 2 ? '#7af0d0' : '#ffe9a0', 0, 0, 0.9)); }
    if (has(L, /porcelain patio|heated porcelain/)) o.push(pd('M' + P(0.55, 0) + 'L' + P(1, 0) + 'L' + P(1, 1) + 'L' + P(0.6, 1) + 'Z', '#e6e1d6', 0, 0, 0.95));
    o.push(pd(T, 'none', shade(f, 0.6), 1.2));
    return { vb: '0 0 80 56', polys: o };
  }
  function ceilPolys(n, C, tier) {
    const o = [], L = n.toLowerCase(), R = rnd(n); let c = C.anyA ? C.a : ['#d8d0c0', '#f4f1ea', '#c99a6a', '#f4efe2', '#1e1a30'][tier - 1];
    if (has(L, /pipes|rafters|basement/)) c = '#8a7a66'; if (has(L, /black painted|night sky|space|dome|vault|immersion|aurora/) && !/glass atrium|steam-dome/.test(L)) c = '#1e1a30';
    const top = 'M0 0H80L64 26H16Z', wl = mix(c, '#e8e0d0', 0.6);
    o.push(pd('M16 26H64V56H16Z', wl), pd('M0 0L16 26V56H0Z', shade(wl, 0.9)), pd('M80 0L64 26V56H80Z', shade(wl, 0.85)), pd(top, c));
    const dk = shade(c, 0.75), lt = mix(c, '#ffffff', 0.35), L0 = (d, col, w, op) => o.push(pd(d, 'none', col, w, op));
    if (has(L, /beam|rafter|coffer|shiplap/)) { [0.2, 0.4, 0.6, 0.8].forEach(t => o.push(pd('M' + f1(t * 80) + ' 0L' + f1(16 + t * 48) + ' 26', 'none', has(L, /dark wood|cedar|beam/) ? '#7a4a28' : dk, has(L, /coffer|beam/) ? 3.6 : 1.4))); if (has(L, /coffer|mirror/)) [8, 17].forEach(y => L0('M' + f1(16 * y / 26) + ' ' + y + 'H' + f1(80 - 16 * y / 26), dk, 3)); }
    if (has(L, /pipes/)) { L0('M0 6H80', '#9aa1a6', 3.4); L0('M0 14H80', '#b07a50', 2.6); L0('M40 6V22', '#9aa1a6', 2); }
    if (has(L, /cobweb/)) o.push(pd('M0 0L12 0Q8 6 0 10Z', 'none', '#fffaf1', 0.6), pd('M2 0L6 8M0 4L10 3', 'none', '#fffaf1', 0.5));
    if (has(L, /popcorn|stucco|water-spotted|stained|peeling/)) { for (let i = 0; i < 40; i++) { const x = 6 + R() * 68, y = R() * 24; if (x > 16 * y / 26 + 2 && x < 80 - 16 * y / 26 - 2) o.push(pd(circ(x, y, 0.7), dk, 0, 0, 0.6)); } o.push(pd(ell(54, 10, 8, 3), '#a08a60', 0, 0, 0.3)); }
    if (has(L, /acoustic|drop-tile|pvc|foam/)) { [0.25, 0.5, 0.75].forEach(t => L0('M' + f1(t * 80) + ' 0L' + f1(16 + t * 48) + ' 26', dk, 0.8)); [9, 18].forEach(y => L0('M' + f1(16 * y / 26) + ' ' + y + 'H' + f1(80 - 16 * y / 26), dk, 0.8)); }
    if (has(L, /star|night sky|fiber-optic|space|nebula|aurora|immersion|halo rig|laser/)) { for (let i = 0; i < 26; i++) { const y = R() * 24, x = 16 * y / 26 + R() * (80 - 32 * y / 26); o.push(pd(circ(x, y, 0.6 + R() * 0.9), i % 5 ? '#fffbe0' : NE[i % 6], 0, 0, 0.95)); } if (has(L, /aurora|nebula/)) { L0('M6 6Q30 20 50 8T76 10', '#7ae8c8', 4, 0.55); L0('M10 14Q34 4 60 16', '#b48cff', 3, 0.5); } if (has(L, /laser|halo/)) o.push(pd(ell(40, 13, 16, 4), 'none', '#ff6ad5', 1.4), pd(ell(40, 13, 10, 2.4), 'none', '#4fe0d0', 1.2)); }
    if (has(L, /fan/)) { o.push(pd(circ(40, 14, 2.4), '#9aa1a6')); [[-16, -2], [12, -4], [4, 6]].forEach(([dx, dy]) => o.push(pd('M40 14L' + (40 + dx) + ' ' + (14 + dy) + 'l3 3Z', '#d4a56a', '#a87a48', 0.6))); }
    if (has(L, /exhaust|vent|hood|fan/) && !/paddle/.test(L)) o.push(pd(rr(32, 6, 16, 10, 1), '#c9d3d8', '#8a949a', 0.8), pd('M34 9H46M34 12H46', 'none', '#8a949a', 0.8));
    if (has(L, /range hood|chimney|canopy range|hood/)) o.push(pd('M30 26L34 34H46L50 26Z', has(L, /brass/) ? '#d4a548' : has(L, /plaster/) ? '#ece2d0' : '#c9d3d8', '#8a949a', 0.8), pd(rr(37, 18, 6, 9, 0), has(L, /brass/) ? '#d4a548' : '#c9d3d8'));
    if (has(L, /pot lights|recessed|cove|tray|led vent|chromotherapy/)) { [[26, 8], [40, 8], [54, 8], [32, 18], [48, 18]].forEach(([x, y]) => o.push(pd(ell(x, y, 2.6, 1.2), '#fff2b0'))); if (has(L, /cove|tray/)) o.push(pd('M10 4H70L58 22H22Z', 'none', '#ffd88a', 1.6, 0.8)); if (has(L, /chromo/)) o.push(pd(ell(40, 13, 14, 4), 'none', '#8f7bff', 2)); }
    if (has(L, /skylight|atrium|glass|sky-vault/)) o.push(pd('M24 4H56L50 18H30Z', 'url(#hsSky)', '#c9d3d8', 1), pd('M40 4V18M27 11H53', 'none', '#c9d3d8', 1));
    if (has(L, /medallion|crown|molding|cove molding/)) { o.push(pd('M0 0H80L77 4H3Z', '#fffaf1', '#d8cbb4', 0.6), pd(circ(40, 13, 6), '#fffaf1', '#d8cbb4', 0.8), pd(circ(40, 13, 3), 'none', '#d8cbb4', 0.8)); }
    if (has(L, /steam-dome|rain-cloud|mist/)) o.push(pd(ell(30, 12, 12, 5), '#ffffff', 0, 0, 0.9), pd(ell(50, 10, 14, 6), '#f4f8fb', 0, 0, 0.9), pd('M30 18v6M40 20v6M50 18v6', 'none', '#9fd2f2', 1, 0.8));
    if (has(L, /truss/)) { L0('M8 8H72', '#9aa1a6', 2); L0('M10 12H70', '#9aa1a6', 2); for (let x = 10; x < 70; x += 6) L0('M' + x + ' 8L' + (x + 3) + ' 12', '#9aa1a6', 1); }
    if (has(L, /christmas|kinetic triangle|led ceiling/)) for (let i = 0; i < 10; i++) o.push(pd(circ(10 + i * 6.6, 6 + Math.sin(i) * 2, 1.6), NE[i % 6]));
    if (has(L, /disco/)) [[30, 14], [52, 12]].forEach(([x, y]) => o.push(pd('M' + x + ' 0V' + (y - 4), 'none', '#9aa1a6', 0.6), pd(circ(x, y, 4.4), 'url(#dBall)', '#6c72a8', 0.6)));
    if (has(L, /triangle/)) for (let i = 0; i < 6; i++) o.push(pd('M' + (12 + i * 10) + ' 4l5 8h-10Z', NE[i % 6], 0, 0, 0.7));
    o.push(pd(top, 'none', shade(c, 0.6), 1), pd('M16 26H64V56H16Z', 'none', shade(wl, 0.7), 0.8));
    return { vb: '0 0 80 56', polys: o };
  }
  function fencePolys(n, C, tier) {
    const o = [], L = n.toLowerCase();
    if (has(L, /chain-link/)) { [4, 40, 76].forEach(x => o.push(pd(rr(x - 1.6, 4, 3.2, 52, 1), '#8a8f94'))); o.push(pd('M4 8H76', 'none', '#8a8f94', 1.6)); let d = ''; for (let x = -40; x < 80; x += 6) d += 'M' + x + ' 56L' + (x + 48) + ' 8M' + (x + 48) + ' 56L' + x + ' 8'; o.push(pd(d, 'none', '#a0603a', 0.6, 0.8), pd(rr(50, 20, 14, 18, 0), '#93cf70', 0, 0, 0.5)); return { vb: '0 0 80 56', polys: o }; }
    if (has(L, /limestone|stone/)) { o.push(pd(rr(0, 14, 80, 42, 1), '#e3d8c0', '#b9ab92', 1)); for (let y = 0; y < 5; y++) for (let x = 0; x < 5; x++) o.push(pd(rr(x * 17 - (y % 2) * 8, 14 + y * 8.4, 16, 7.6, 1), '#e3d8c0', '#b9ab92', 0.6)); o.push(pd('M0 16H80', 'none', '#3a3a3e', 1.4)); for (let x = 4; x < 80; x += 8) o.push(pd('M' + x + ' 16V9', 'none', '#3a3a3e', 1)); for (let i = 0; i < 9; i++) o.push(pd(ell(6 + i * 9, 14 + (i % 3) * 3, 5, 3), i % 2 ? '#5fa84a' : '#4f9a3e')); return { vb: '0 0 80 56', polys: o }; }
    if (has(L, /living|rainforest|force-field/)) { o.push(pd(rr(0, 0, 80, 56, 3), '#2f6a3c')); for (let i = 0; i < 40; i++) o.push(pd(ell((i * 23) % 80, (i * 37) % 56, 6, 4), ['#5fa84a', '#6fbf54', '#4f9a3e', '#7ac860'][i % 4])); o.push(pd(rr(0, 0, 80, 56, 3), '#8fe8ff', 0, 0, 0.18), pd('M0 6H80', 'none', '#8fe8ff', 1.6, 0.8)); return { vb: '0 0 80 56', polys: o }; }
    if (has(L, /horizontal|slat/)) { [4, 76].forEach(x => o.push(pd(rr(x - 2, 4, 4, 52, 1), shade(C.w, 0.8)))); for (let i = 0; i < 8; i++) o.push(pd(rr(0, 6 + i * 6.2, 80, 5, 1), i % 2 ? C.w : shade(C.w, 1.1), shade(C.w, 0.7), 0.6)); return { vb: '0 0 80 56', polys: o }; }
    for (let i = 0; i < 6; i++) { const x = 2 + i * 13.4; o.push(pd('M' + x + ' 56V18L' + (x + 5) + ' 11L' + (x + 10) + ' 18V56Z', '#fffaf1', '#d8cbb4', 1.2)); } o.push(pd(rr(0, 26, 80, 4, 1), '#f4efe6', '#d8cbb4', 0.8), pd(rr(0, 44, 80, 4, 1), '#f4efe6', '#d8cbb4', 0.8));
    return { vb: '0 0 80 56', polys: o };
  }
  function doorCurtain(n, C) {
    const o = [], L = n.toLowerCase(); o.push(pd(rr(-34, 16, 68, 86, 3), '#d8cbb4'), pd(rr(-26, 22, 52, 80, 2), '#2c2830'));
    if (has(L, /beaded|plastic curtain/)) for (let i = 0; i < 10; i++) for (let j = 0; j < 12; j++) o.push(pd(circ(-23 + i * 5.2, 26 + j * 6.4, 1.6), NE[(i + j) % 6]));
    else if (has(L, /shower curtain/)) { o.push(pd('M-30 22H30', 'none', '#9aa1a6', 2)); for (let i = 0; i < 6; i++) o.push(pd('M' + (-26 + i * 9) + ' 22Q' + (-22 + i * 9) + ' 60 ' + (-26 + i * 9 + (i === 4 ? 6 : 0)) + ' 100H' + (-17 + i * 9) + 'Q' + (-20 + i * 9) + ' 60 ' + (-17 + i * 9) + ' 22Z', i % 2 ? '#cfe8f2' : '#bfe0ee', 0, 0, 0.9)); o.push(pd('M8 40L14 52L10 60', 'none', '#2c2830', 1)); }
    else { for (let i = 0; i < 6; i++) o.push(pd('M' + (-26 + i * 9) + ' 22Q' + (-22 + i * 9) + ' 60 ' + (-26 + i * 9) + ' 102H' + (-17 + i * 9) + 'Q' + (-20 + i * 9) + ' 60 ' + (-17 + i * 9) + ' 22Z', i % 2 ? '#2c2d31' : '#3a3a40')); o.push(pd('M-30 22H30', 'none', '#9aa1a6', 2.4)); if (has(L, /stanchion|rope/)) o.push(pd(rr(-40, 80, 3, 22, 1), GOLD), pd(rr(37, 80, 3, 22, 1), GOLD), pd('M-38 82Q0 96 38 82', 'none', '#a8243a', 2.4)); }
    return { vb: '-40 16 80 86', polys: o };
  }
  const swPolys = (id, spec, arch) => { X.SURF[id] = { arch }; X.SPEC[id] = spec; return X.swatch(id); };
  function surface(r, kind, C) {
    const n = r.name, L = n.toLowerCase(), t = r.tier, id = 'rv_' + r.id;
    if (kind === 'wall') return wallPolys(n, C, t);
    if (kind === 'floor') return floorPolys(n, C, t, false);
    if (kind === 'ground') return floorPolys(n, C, t, true);
    if (kind === 'ceil') return ceilPolys(n, C, t);
    if (kind === 'fence') return fencePolys(n, C, t);
    if (kind === 'door') { if (has(L, /curtain|beaded/)) return doorCurtain(n, C); const k = has(L, /double|mahogany|palace|brass vip/) ? 'palace' : has(L, /padded|studio|speakeasy|steel/) ? 'flush' : has(L, /airlock|portal|biometric|hologram|neon tunnel/) ? 'jet' : has(L, /squeaky|hollow|basement/) ? 'scuff' : 'plank';
      const c = k === 'palace' ? (/mahogany/.test(L) ? '#6a2a1c' : '#f3ead6') : k === 'flush' ? (/leather|padded/.test(L) ? '#3e3438' : '#7a8086') : k === 'jet' ? (/neon/.test(L) ? '#8f7bff' : '#2a2630') : k === 'scuff' ? '#a89478' : C.w;
      return swPolys(id, { k, c, cl: k === 'palace' ? GOLD : k === 'jet' ? '#8fe8ff' : shade(c, 1.2) }, 'door'); }
    if (kind === 'win') { const k = has(L, /crack|hopper|rust screen|drafty/) ? 'crack' : has(L, /lace|sheer/) ? 'lace' : has(L, /herb|greenhouse|box window|hydroponic|window seat/) ? 'flower' : has(L, /french|balcony|arch/) ? 'arch' : has(L, /panoram|floor-to-ceiling|bay|wall|pass-through|skyline|glass wall/) ? 'big' : 'curt';
      const fr = k === 'big' ? (/holo|skyline/.test(L) ? '#8f7bff' : /steel|smart/.test(L) ? '#3e4046' : '#f4f1ea') : k === 'arch' ? GOLD : k === 'crack' ? '#cbbfa6' : '#fffaf1', cu = /gingham|cafe/.test(L) ? '#e3946a' : /linen|roman|cotton/.test(L) ? '#e9dfcc' : /blackout/.test(L) ? '#2f4870' : /blinds|plastic/.test(L) ? '#e8e2d4' : /accordion|paper/.test(L) ? '#efe6d4' : /shutter/.test(L) ? '#9fb58c' : '#c9a85a';
      return swPolys(id, { k, fr, cu: k === 'arch' ? (/silk|drape/.test(L) ? '#7f2030' : '#f3ead6') : cu }, 'win'); }
    if (kind === 'light') { const k = has(L, /disco|mirror sphere|mirror ball|tin-foil ball/) ? 'disco' : has(L, /laser|beam spot|moving-head|strobe/) ? 'laser' : has(L, /neon/) ? 'neon' : has(L, /constellation|kinetic|floating|halo|aurora|herb-halo|feather|bioluminescent|hologram|plasma/) ? (has(L, /halo|herb/) ? 'halo' : 'crys') : has(L, /chandelier|murano|capiz|tiered/) ? 'chand' : has(L, /rattan|wicker|woven|bamboo|barn|enamel|paper|origami|drum/) ? 'wicker' : has(L, /sputnik|globe|pendant|flush-mount|deco/) ? 'globe' : has(L, /track|spotlight|truss/) ? 'truss' : has(L, /bulb|fluorescent|strip|dome|pull-chain|party bulb/) ? 'bulb' : 'globe';
      return swPolys(id, { k }, 'light'); }
    if (kind === 'ylight') return swPolys(id, { k: has(L, /paper lantern/) ? 'lantern' : has(L, /edison|bistro|festoon/) ? 'festoon' : 'string' }, 'ylight');
    return { vb: '0 0 80 56', polys: [] };
  }

  // ---------- build + render ----------
  const SD = '<radialGradient id="hiW" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff" stop-opacity="0.85"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient><radialGradient id="gWarm" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff2b0" stop-opacity="0.6"/><stop offset="1" stop-color="#fff2b0" stop-opacity="0"/></radialGradient><radialGradient id="gNeon" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffe9a0" stop-opacity="0.75"/><stop offset="1" stop-color="#ffe9a0" stop-opacity="0"/></radialGradient><linearGradient id="hsSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9fd2f2"/><stop offset="1" stop-color="#e6f4fb"/></linearGradient><linearGradient id="hsWood" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e2ad74"/><stop offset="1" stop-color="#b97a42"/></linearGradient><radialGradient id="bMirror" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#f4fbfd"/><stop offset="1" stop-color="#a9d3e3"/></radialGradient><radialGradient id="dBall" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#fff"/><stop offset="0.5" stop-color="#c9cde8"/><stop offset="1" stop-color="#6c72a8"/></radialGradient><radialGradient id="hsGold" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="#fff6c8"/><stop offset="0.5" stop-color="#ffd66b"/><stop offset="1" stop-color="#d99a20"/></radialGradient><radialGradient id="hsClock" cx="38%" cy="32%" r="70%"><stop offset="0" stop-color="#fffdf7"/><stop offset="1" stop-color="#efe2cc"/></radialGradient>';
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;');
  const svgOf = (vb, polys, gids) => { const G = X.grads(gids || []); let d = SD + (X.MDEFS || '');
    G.lin.forEach(g => d += '<linearGradient id="' + g.id + '" x1="0" y1="0" x2="' + g.x2 + '" y2="' + g.y2 + '"><stop offset="0" stop-color="' + g.c0 + '"/><stop offset="1" stop-color="' + g.c1 + '"/></linearGradient>');
    G.rad.forEach(g => d += '<radialGradient id="' + g.id + '" cx="36%" cy="30%" r="78%"><stop offset="0" stop-color="' + g.c0 + '"/><stop offset="1" stop-color="' + g.c1 + '"/></radialGradient>');
    return 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + vb + '"><defs>' + d + '</defs>' + pstr(polys) + '</svg>'); };
  const pstr = polys => { let b = ''; polys.forEach(p => b += p.raw != null ? p.raw : '<path d="' + p.d + '" fill="' + esc(p.f) + '" stroke="' + esc(p.s) + '" stroke-width="' + p.w + '" opacity="' + p.o + '" stroke-linejoin="round" stroke-linecap="round"/>'); return b; };
  const svgDoc = (vb, gids, body) => { const G = X.grads(gids || []); let d = SD + (X.MDEFS || '');
    G.lin.forEach(g => d += '<linearGradient id="' + g.id + '" x1="0" y1="0" x2="' + g.x2 + '" y2="' + g.y2 + '"><stop offset="0" stop-color="' + g.c0 + '"/><stop offset="1" stop-color="' + g.c1 + '"/></linearGradient>');
    G.rad.forEach(g => d += '<radialGradient id="' + g.id + '" cx="36%" cy="30%" r="78%"><stop offset="0" stop-color="' + g.c0 + '"/><stop offset="1" stop-color="' + g.c1 + '"/></radialGradient>');
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + vb + '"><defs>' + d + '</defs>' + body + '</svg>'; };
  // same camera as X.render(id, -30): model point -> viewBox point
  const projOf = (Z, ra) => { const t = (ra == null ? -30 : ra) * PI / 180, c = Math.cos(t), s = Math.sin(t), k = X.FS * Z; return (x, y, z) => [(x * c + z * s) * k, (-x * s + z * c) * k * X.SA - y * k * X.CA]; };
  const HOSTB = /^(table|coffee|bistro|counter|diningTable|luxCounter|nightstand|#spoolTable|cart|bar|desk|dresser)$/;
  const MEMO = new Map();
  // o: { ci: colour index into r.colors, st: state / mode, txt: custom text, ex: extra (calendar marks...) }
  function draw(r, o) {
    const X = window.House3D; o = o || {}; const ci = o.ci | 0, st = o.st || '', txt = o.txt || '', ex = o.ex || '';
    let ra = o.rot == null ? -30 : (((+o.rot || 0) % 360) + 360) % 360; if (ra === 330) ra = -30; const RA = '|' + ra + '|';
    const key = r.id + '|' + r.name + '|' + r.tier + '|' + ci + '|' + st + '|' + txt + '|' + ex + '|' + (r.spec || '') + (ra === -30 ? '' : RA); if (MEMO.has(key)) return MEMO.get(key);
    const sp = r.spec ? parseSpec(r.spec) : specFor(r), nm = r.name.toLowerCase();
    let band = sp.band || TB[r.tier - 1]; if (!sp.band && r.tier <= 3 && RETRO.test(r.name)) band = 'retro';
    const cv = r.colors && r.colors[ci], C = colorsOf(r.name, band); if (cv) { C.a = Array.isArray(cv.c) ? cv.c[0] : cv.c; C.anyA = true; }
    const res = { float: r.tier >= 4 && FLOAT.test(r.name), holo: HOLO.test(r.name), surf: false, err: '' };
    try {
      if (sp.base.startsWith('s:')) { const s = surface(r, sp.base.slice(2), C); const svg = svgDoc(s.vb, [], pstr(s.polys)); Object.assign(res, { svg, src: 'data:image/svg+xml,' + encodeURIComponent(svg), w: 0, h: 0, surf: true, vb: s.vb, kind: sp.base.slice(2) }); }
      else {
        const id = 'rv_' + r.id + '_' + r.tier + '_' + ci + '_' + st; let D;
        const S = Object.assign({ k: band, v: sp.v, nm, st, txt, ex, ci, pal: cv && Array.isArray(cv.c) ? cv.c : null, row: r }, r.sx || {}); sp.flags.forEach(f => S[f] = 1);
        if (sp.base.startsWith('#')) { const D0 = X.CAT[sp.base.slice(1)]; D = Object.assign({}, D0); }
        else { const fn = N[sp.base] || X.ARCH[sp.base] || X.ARCH.coffee; D = fn(S); }
        const base = (X.BANDS.find(b => b.k === band) || X.BANDS[0]).cols;
        D.cols = C.anyA ? [{ a: C.a, b: C.b, w: C.w, m: C.m }] : [Object.assign({}, base[0], { w: C.w !== base[0].w ? C.w : base[0].w })];
        D.zs = (D.zs || 1) * sp.zs; window.House3D.CAT[id] = D; X.CACHE.delete(id + RA + 0 + '|' + (D.v0 || ''));
        const R = X.render(id, ra, 0, D.v0 || ''), polys = R.back.concat(R.part, R.front), gids = R.gids.slice(); if (R.glow) polys.unshift({ d: R.glow.d, f: R.glow.f, s: 'none', w: 0, o: 1 });
        let x0 = +R.bb.x, y0 = +R.bb.y, x1 = x0 + +R.bb.w, y1 = y0 + +R.bb.h; const grow = b => { if (!b) return; x0 = Math.min(x0, b[0]); y0 = Math.min(y0, b[1]); x1 = Math.max(x1, b[2]); y1 = Math.max(y1, b[3]); };
        const p = projOf(D.zs || 1, ra), ctx = { p, S, P: X.pal(D, 0), band, k: X.FS * (D.zs || 1) };
        let back = '', front = '', frontS = '';
        // multi-part seats (sofas / booths / benches built from layers): when turned away from the default view, layers are re-ordered by depth (far ones before the base,
        // near ones after it) and a layer that rises past a seat on the viewer's side (a backrest / arm / pillow facing you) goes over the sitter (srcF)
        const LY = D.layers || [], dsort = LY.length > 0 && !!(D.seats && D.seats.length) && LY.some(L => L.back), tr0 = ra * PI / 180, c0 = Math.cos(tr0), s0 = Math.sin(tr0);
        const LR = LY.map((L, i) => { const lid = id + '_L' + i; window.House3D.CAT[lid] = Object.assign({ w: D.w, d: D.d, zs: D.zs, cols: D.cols, build: L.build }, dsort ? { seats: D.seats, act: D.act } : {}); X.CACHE.delete(lid + RA + '0|'); const R2 = X.render(lid, ra, 0, ''); R2.gids.forEach(g => gids.push(g)); grow([+R2.bb.x, +R2.bb.y, +R2.bb.x + +R2.bb.w, +R2.bb.y + +R2.bb.h]);
          return { L, R2 }; });
        // depth order of the groups (base + each layer), same rule as house4 render: the axis that separates two overlapping groups in the piece's own frame decides, else the nearest point
        let before = null; if (dsort) { const SA = X.SA, CA = X.CA, wx = -s0, wz = c0, bnd1 = S0 => { const L0 = [1e9, -1e9, 1e9, -1e9, 1e9, -1e9], sb = [1e9, -1e9, 1e9, -1e9]; let md = -1e9;
            S0.pts.forEach(q => { for (let k = 0; k < 3; k++) { if (q[k] < L0[k * 2]) L0[k * 2] = q[k]; if (q[k] > L0[k * 2 + 1]) L0[k * 2 + 1] = q[k]; } const x1 = q[0] * c0 + q[2] * s0, z1 = -q[0] * s0 + q[2] * c0, sy = z1 * SA - q[1] * CA, dd = q[1] * SA + z1 * CA;
              if (x1 < sb[0]) sb[0] = x1; if (x1 > sb[1]) sb[1] = x1; if (sy < sb[2]) sb[2] = sy; if (sy > sb[3]) sb[3] = sy; if (dd > md) md = dd; }); return { L: L0, sb, md }; };
          const sols = f => { try { return (f() || []).filter(S0 => S0 && S0.pts && S0.pts.length).map(bnd1); } catch (e) { return []; } };
          const G = [sols(() => D.build(X.pal(D, 0), D.v0 || ''))].concat(LR.map(o => sols(() => o.L.build(X.pal(D, 0), ''))));
          // groups are ordered by a vote over their solids: each pair of solids that overlaps on screen is ordered like house4 render (separating axis in the piece's own frame, else nearest point), weighted by the overlap area
          const pr = (A0, B0) => { const P = A0.sb, Q = B0.sb, ox = Math.min(P[1], Q[1]) - Math.max(P[0], Q[0]), oy = Math.min(P[3], Q[3]) - Math.max(P[2], Q[2]); if (ox <= 0.5 || oy <= 0.5) return 0;
            const a = A0.L, b = B0.L, ax = [[Math.max(a[2] - b[3], b[2] - a[3]), a[2] > b[2] ? 1 : -1]];
            if (Math.abs(wx) > 0.15) ax.push([Math.max(a[0] - b[1], b[0] - a[1]), (a[0] > b[0] ? 1 : -1) * Math.sign(wx)]); if (Math.abs(wz) > 0.15) ax.push([Math.max(a[4] - b[5], b[4] - a[5]), (a[4] > b[4] ? 1 : -1) * Math.sign(wz)]);
            if (ax.some(u => u[0] > 0 && u[1] === 1) && ax.some(u => u[0] > 0 && u[1] === -1)) return 0;
            ax.sort((u, v) => v[0] - u[0]); let f = ax[0][0] > -4 ? ax[0][1] : 0; if (!f && Math.abs(A0.md - B0.md) > 1) f = A0.md > B0.md ? 1 : -1; return f * ox * oy; };
          const n = G.length, aft = Array.from({ length: n }, () => []), ind = new Array(n).fill(0);
          // a full-width back layer (backrest, curved booth shell) stays behind the base and keeps its authored order while the seat's front faces the viewer
          const WB = G.map((g, i) => { if (!i || !LR[i - 1].L.back || c0 <= 0.2) return false; let a = 1e9, b = -1e9; g.forEach(o => { a = Math.min(a, o.L[0]); b = Math.max(b, o.L[1]); }); return b - a > (D.w || 0) * 0.6; });
          for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) { let v = 0, f = 0; if (WB[j] && (i === 0 || WB[i])) f = i === 0 ? 1 : -1; else { G[i].forEach(A0 => G[j].forEach(B0 => { v += pr(A0, B0); })); f = v > 0 ? 1 : v < 0 ? -1 : 0; }
            if (f === 1) { aft[j].push(i); ind[i]++; } else if (f === -1) { aft[i].push(j); ind[j]++; } }
          const dn = new Array(n).fill(false), ord = []; for (let k = 0; k < n; k++) { let pk = -1; for (let i = 0; i < n; i++) if (!dn[i] && ind[i] === 0) { pk = i; break; } if (pk < 0) for (let i = 0; i < n; i++) if (!dn[i]) { pk = i; break; } dn[pk] = true; ord.push(pk); aft[pk].forEach(q => ind[q]--); }
          const bi = ord.indexOf(0); before = new Set(ord.slice(0, bi).map(i => i - 1)); const rk = new Map(ord.map((g, i) => [g - 1, i])); LR.forEach((o, i) => o.i = i); LR.sort((u, v) => rk.get(u.i) - rk.get(v.i)); }
        LR.forEach(o => { const { L, R2 } = o, all2 = R2.back.concat(R2.part, R2.front), m = L.wrap ? L.wrap(p, pstr(all2)) : '<g>' + (L.anim || '') + pstr(all2) + '</g>';
          if (!dsort) { if (L.back) back += m; else front += m; return; }
          const nB = R2.back.length + R2.part.length; if (R2.front.length && R2.front.length >= nB) frontS += m; else if (before.has(o.i)) back += m; else front += m; });
        const F = D.fx ? (D.fx(ctx) || {}) : {}; if (F.bb) grow(F.bb);
        const mk = (PL, bare, noS) => { let a = bare ? pstr(PL) + frontS : (F.back || '') + back + pstr(PL) + front + (noS ? '' : frontS) + (F.front || '');
          if (D.wrap) a = D.wrap(p, a); else if (D.anim) a = '<g>' + (typeof D.anim === 'function' ? D.anim(p) : D.anim) + a + '</g>'; return bare ? a : (F.under || '') + a + (F.over || ''); };
        const all = mk(polys), spl = (R.front.length > 0 || !!frontS) && !D.roam;
        const pd2 = D.pad || [0, 0, 0, 0]; x0 -= pd2[0]; y0 -= pd2[1]; x1 += pd2[2]; y1 += pd2[3];
        const vb = f1(x0) + ' ' + f1(y0) + ' ' + f1(x1 - x0) + ' ' + f1(y1 - y0), svg = svgDoc(vb, gids, (F.defs ? '<defs>' + F.defs + '</defs>' : '') + all);
        // in-room split: srcB = everything behind the sitter / bather, srcF = the parts in front of him (src stays whole for thumbnails)
        if (spl) { const DF = F.defs ? '<defs>' + F.defs + '</defs>' : '', FF = D.fxF ? (F.front || '') : ''; if (D.fxF) F.front = ''; let FB = '', FS = mk(R.front, 1) + FF; if (D.cutF) { const q = p(D.cutF[0], D.cutF[1], D.cutF[2]), cy = f1(q[1]), W2 = f1(x0 - 50), WW = f1(x1 - x0 + 100); FB = '<clipPath id="cfB"><rect x="' + W2 + '" y="' + f1(y0 - 200) + '" width="' + WW + '" height="' + f1(q[1] - y0 + 200) + '"/></clipPath><clipPath id="cfF"><rect x="' + W2 + '" y="' + cy + '" width="' + WW + '" height="' + f1(y1 - q[1] + 200) + '"/></clipPath>'; const CD = '<defs>' + FB + '</defs>'; FB = CD + '<g clip-path="url(#cfB)">' + FS + '</g>'; FS = CD + '<g clip-path="url(#cfF)">' + FS + '</g>'; }
          res.srcB = 'data:image/svg+xml,' + encodeURIComponent(svgDoc(vb, gids, DF + mk(polys.filter(q => !R.front.includes(q)), false, true) + FB)); res.srcF = 'data:image/svg+xml,' + encodeURIComponent(svgDoc(vb, gids, DF + FS)); if (D.fxF) F.front = FF; }
        Object.assign(res, { svg, src: 'data:image/svg+xml,' + encodeURIComponent(svg), w: x1 - x0, h: y1 - y0, vb, bb: [x0, y0, x1 - x0, y1 - y0], squish: !!D.squish, roam: !!D.roam, mount: D.mount || '', foot: p(0, 0, 0) });
        { let SC = R.screen; if (!SC && (D.anim === 'tv' || D.act === 'watch')) { try { X.CACHE.delete(id + RA + '0|on'); SC = X.render(id, ra, 0, 'on').screen; } catch (e) {} }
          if (SC) res.screen = { w: +SC.w, h: +SC.h, m: String(SC.m).replace(/matrix\(|\)/g, '').trim().split(/[\s,]+/).map(Number) }; }
        if (D.seats && D.seats.length) res.seats = D.seats.map(s => { const q = p(s.x, s.h, s.z); return { x: q[0], y: q[1] }; });
        if (D.topH || HOSTB.test(sp.base)) { let th = D.topH; if (!th) { th = 0; D.build(X.pal(D, 0), '').forEach(s0 => s0.pts.forEach(q => { if (q[1] > th && Math.abs(q[0]) < D.w * 0.45) th = q[1]; })); } const q = p(0, th, D.topZ || 0); res.top = { x: q[0], y: q[1], w: D.topW || D.w * 0.6 }; }
      }
    } catch (e) { res.err = String(e && e.message || e); res.src = ''; console.warn('reno draw', r.id, e); }
    res.arch = sp.base + (sp.v ? '.' + sp.v : ''); res.band = band; MEMO.set(key, res); return res;
  }
  function parseCSV(t) { const rows = []; let row = [], cur = '', q = false; for (let i = 0; i < t.length; i++) { const ch = t[i]; if (q) { if (ch === '"') { if (t[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; } else if (ch === '"') q = true; else if (ch === ',') { row.push(cur); cur = ''; } else if (ch === '\n' || ch === '\r') { if (ch === '\r' && t[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.length > 1) rows.push(row); row = []; } else cur += ch; } if (cur || row.length) { row.push(cur); if (row.length > 1) rows.push(row); }
    const H = rows.shift().map(h => h.trim()); return rows.map(r => { const o = {}; H.forEach((h, i) => o[h] = (r[i] || '').trim()); return { id: o.item_id, room: o.room_code, roomName: o.room_name, lv: +o.unlock_level, tier: +o.tier, tierName: o.tier_name, rarity: o.rarity, slot: +o.slot_index, cat: o.category, slotName: o.slot_name, name: o.item_name, cost: +o.cost_coins, stat: o.stat_type, bonus: o.stat_bonus_display }; }).filter(r => r.id); }
  window.RenoDraw = { draw, parseCSV, MAP: M, N, H, projOf, svgDoc, pstr, colorsOf, MEMO, rr };
})();
