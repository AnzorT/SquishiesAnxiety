// Whip spin in the dances (Nov 10, user: 'awesome - now only the characters that have a spin in their dance should have this; not all of them
// must spin both ways - make it random: some spin right, some left, some both' + 'only on Snack Shack, Pet Shop and the fruit characters').
// Every dance of those sets that had a real spin (a full turn or more) gets Mittens' approved whip spin spliced in where the old spin was:
// get-ready (eyes find the spot, plie + coil the other way, head tilted to the spin side, hold), WHIP the turn on one leg (the other foot
// stays down) with the arms on a tilted line + motion blur, land facing you with a ta-da, then blend back into the dance. 'both' = right
// then left back to back, the second get-ready 0.2 s after the first turn ends. Must stay in step with whip() in mittens-moves.js.
// How: the dance state ('dance@key', or Mittens' shared 'dance') is rebuilt - the spin window [t0, t1] is found from the spin keys, the
// body channels are re-keyed (dance pose at t0 -> whip keys -> blend into the dance pose at t1), other channels / events / emitters are
// stretched across the window, everything later is shifted (the shift is rounded to 250 ms so the beat carries on). States are wrapped in
// accessors on STATES, so dances that are added later (the generic rigs build theirs when first shown) are converted too.
(function boot() {
  const R = window.RiveRig; if (!R || !R.STATES || !R.STATES.dance || !R.REST || !R.kv) { setTimeout(boot, 25); return; } if (R.whipV) return; R.whipV = 1;
  const STATES = R.STATES, REST = R.REST, kv = R.kv;
  // 1 = spins right, -1 = left, 2 = both (right then left). Picked at random once (seeded) and kept, so each character always does its own.
  // Left out on purpose: truffle (turns round to wiggle his tail), melo (fan flip to show his rind), peachy (waltz turn), shelly / Sea Turtle
  // (the non-stop shell spin), chilla (spin wiggles, never a full turn); dances with no spin: biscuit, mamapaws, bao, frybo, sunny, pina, kiwi, blueby, coco.
  const PLAN = {
    // Pet Shop
    bean: 1, clover: -1, duchess: 2, mimi: 2, mittens: 1, nibbles: 1, pico: 2, poppy: 2, puddles: 1, quill: -1, ribbit: 2, tilly: -1, waffles: -1, zippy: 2,
    // Snack Shack
    boba: 1, bunbun: 2, chefbun: 2, choco: 1, churro: 2, corny: 1, dunkie: 1, flossie: -1, frankie: 2, khinki: -1, maki: 2, mallow: -1, noodle: 1, nori: -1, peppi: 2, scoop: 2, toco: -1,
    // Fruit Patch
    appy: 2, avo: 2, berri: 2, bing: 2, clemmy: 1, grana: 2, lemmy: 1, mangie: -1, nana: -1, perry: 1, pitaya: 1, plummy: 2, razzy: -1, tutti: -1 };
  R.WHIP_PLAN = PLAN;
  const rv = c => (REST[c] != null ? REST[c] : 0);
  const S = s => s < 0 ? { arm: 'armL', hx: 'hLx', hy: 'hLy', hz: 'hLz', foot: 'footL' } : { arm: 'armR', hx: 'hRx', hy: 'hRy', hz: 'hRz', foot: 'footR' };
  const hand = (s, inX, y, z) => { const k = S(s); return { [k.hx]: s < 0 ? inX : -inX, [k.hy]: y, [k.hz]: z }; };
  const o = (...a) => Object.assign({}, ...a);
  // a tiny keyframe builder (same as mittens-moves' TL): every channel starts at REST at 0 and holds until its next key
  function TL() { const k = {}; let t = 0; const q = { get t() { return t; }, k,
    to(dt, v, ez) { for (const p in v) { const L = k[p] || (k[p] = [[0, rv(p)]]); if (L[L.length - 1][0] < t) L.push([t, L[L.length - 1][1], 'l']); } t += dt; for (const p in v) k[p].push([t, v[p], ez || 'io']); return q; } }; return q; }
  // the whip (v1110g timings, chained: ends at the landing, no settle - the dance or the next whip carries on from the ta-da)
  function whip(t, d) { const ld = d > 0 ? 1 : -1, A = S(ld).arm, B = S(-ld).arm, FT = S(ld).foot;
    t.to(75, { lx: 0.9 * d, htilt: 3 * d, sq: -0.03, [A]: 6, [B]: 6, earL: -3, earR: -3, hap: 0.2, open: 0 }, 'io')                                                       // 1 eyes find the spot
      .to(155, o({ sq: 0.14, spin: -32 * d, turn: -0.12 * d, hyaw: 0.55 * d, tilt: -3 * d, lean: -1 * d, htilt: 7 * d, lx: d, [B]: 70, [A]: -6, close: 0.2, earL: 10, earR: 10, wag: 14 * d, hap: 0.35 }, hand(ld, 7, -2, 5)), 'o') // 2 plie + coil
      .to(100, { sq: 0.16, spin: -36 * d, htilt: 8 * d, [B]: 76 }, 'io')                                                                                                   // 3 hold the coil
      .to(50, o({ spin: 40 * d, sblur: 0.5, sq: -0.1, turn: 0, hyaw: 0.35 * d, tilt: 4 * d, lean: 0.6 * d, htilt: 10 * d, lx: 0.6 * d, [B]: 125, [A]: 30, close: 0, earL: -8, earR: -8, [FT]: 8 }, hand(ld, 0, 2, 3), hand(-ld, 0, -4, 3)), 'l') // 4 WHIP on one leg
      .to(180, { spin: 378 * d, sq: -0.12, [B]: 128, [A]: 32, earL: -12, earR: -12, [FT]: 9 }, 'l')
      .to(200, o({ spin: 360 * d, sblur: 0, sq: 0.12, [FT]: 0, hyaw: -0.12 * d, tilt: -2 * d, lean: 0, htilt: -3 * d, lx: 0, [A]: 115, [B]: 40, earL: 12, earR: 12, wag: -18 * d, hap: 1, smile: 1, open: 0.3 }, hand(ld, 0, 0, 0), hand(-ld, 0, 0, 0)), 'o') // 5 land, ta-da
      .to(1, { spin: 0 }, 'l'); return t; }
  // body channels the whip owns while it runs (besides the ones it keys): no hop, no bend / pitch / twist, eyes / mouth neutral; x holds
  // + the 'in the air' channels of the old jump-spins (split = Bunbun's layers apart, ume = Nori's plum popping up, flop = a flop in the air) - no jump now
  const NEUTRAL = { lift: 0, pitch: 0, bend: 0, twist: 0, ly: 0, winkL: 0, winkR: 0, wide: 0, frown: 0, tongue: 0, puff: 0, sit: 0, split: 0, ume: 0, flop: 0 }, HOLD = { x: 1 };
  // spin windows from the spin keys: runs of moving keys (instant snaps back by a whole turn are resets, not moves); next-door runs merge
  // (two spins back to back = one window); a window must turn at least 300 deg and last at most 3 s
  function windows(K) { if (!K || K.length < 2) return []; const W = []; let cur = null;
    for (let i = 1; i < K.length; i++) { const a = K[i - 1], b = K[i], dv = b[1] - a[1], dt = b[0] - a[0];
      if (dt <= 2 && Math.abs(dv) >= 90) continue;                          // a reset snap
      if (Math.abs(dv) < 0.01) { if (cur && a[0] - cur.t1 > 0) { W.push(cur); cur = null; } continue; }
      if (cur && a[0] - cur.t1 <= 60) { cur.t1 = b[0]; cur.net += dv; } else { if (cur) W.push(cur); cur = { t0: a[0], t1: b[0], net: dv }; } }
    if (cur) W.push(cur); return W.filter(w => Math.abs(w.net) >= 300 && w.t1 - w.t0 <= 3000); }
  function dirsFor(mode, i) { if (mode === 2) return i === 0 ? [1, -1] : [i % 2 ? -1 : 1]; return [mode < 0 ? -1 : 1]; }
  function splice(st, w, dirs) {
    const { t0, t1 } = w, L = st.loop || st.dur, sv = (c, t) => st.k[c] ? kv(st.k[c], t) : rv(c);
    const tl = TL(); dirs.forEach(d => whip(tl, d)); const Wc = tl.t, Wk = tl.k;
    let Wt = Wc + 300; { const dl = Wt - (t1 - t0); Wt += (Math.ceil(dl / 250) * 250 - dl); }   // whip + a 300 ms blend back into the dance, padded so the shift is a multiple of 250 ms
    const dl = Wt - (t1 - t0), M = t => t < t0 ? t : t <= t1 ? t0 + (t - t0) * Wt / Math.max(1, t1 - t0) : t + dl;
    const k = {}, chans = new Set([...Object.keys(st.k), ...Object.keys(Wk), ...Object.keys(NEUTRAL).filter(c => st.k[c])]);
    chans.forEach(c => { const K = st.k[c];
      if (Wk[c] || NEUTRAL[c] != null || HOLD[c]) { const v0 = sv(c, t0), v1 = sv(c, t1), N = [];
        if (K) K.forEach(q => { if (q[0] < t0) N.push(q.slice()); }); else N.push([0, rv(c)]);
        N.push([t0, v0, 'l']);
        if (Wk[c]) { const off = c === 'spin' ? v0 : 0; Wk[c].forEach(q => { if (q[0] > 0) N.push([t0 + q[0], q[1] + off, q[2]]); });
          if (c === 'spin') N.push([t0 + Wc + 1, v0 + 360 * Math.round((v1 - v0) / 360), 'l']); }   // snap to the same facing as the dance's (360 = 0)
        else if (NEUTRAL[c] != null) N.push([t0 + 230, NEUTRAL[c], 'io'], [t0 + Wc, NEUTRAL[c], 'l']);
        else N.push([t0 + Wc, v0, 'l']);
        N.push([t0 + Wt, v1, 'io']);
        if (K) K.forEach(q => { if (q[0] > t1) N.push([q[0] + dl, q[1], q[2]]); }); else N.push([L + dl, rv(c), 'l']);
        k[c] = N; }
      else k[c] = K.map(q => [M(q[0]), q[1], q[2]]); });
    const out = Object.assign({}, st, { k });
    if (st.loop) out.loop = st.loop + dl; else out.dur = st.dur + dl;
    if (st.ev) out.ev = st.ev.map(e => [M(e[0]), ...e.slice(1)]);
    if (st.emit) out.emit = st.emit.map(e => [M(e[0]), e[1] >= 1e8 ? e[1] : M(e[1]), ...e.slice(2)]);
    if (st.fx) { const f = st.fx, Mi = t => t < t0 ? t : t <= t0 + Wt ? t0 + (t - t0) * (t1 - t0) / Wt : t - dl; out.fx = (I, tt) => f(I, Mi(tt)); }
    return out; }
  function convert(st, key) { if (!st || st.__whip || !st.k || !(st.loop || st.dur)) return st; const mode = PLAN[key]; if (!mode) return st;
    const W = windows(st.k.spin); if (!W.length) return st; let out = st;
    for (let i = W.length - 1; i >= 0; i--) out = splice(out, W[i], dirsFor(mode, i));   // last window first, so the earlier ones keep their times
    out.__whip = W.length; out.whip = 1; out.whipDirs = W.map((_, i) => dirsFor(mode, i)); return out; }
  R.whipConvert = convert;
  // accessors: whatever sets 'dance@key' (now or later, R.add or a plain assignment) gets the converted dance; Mittens has no dance of his
  // own - his 'dance@mittens' is made from the shared dance the first time it's asked for
  // (not enumerable until it holds a dance, so nothing that lists STATES ever meets an empty one)
  Object.keys(PLAN).forEach(key => { const nm = 'dance@' + key; let val = convert(STATES[nm] || (key === 'mittens' ? STATES.dance : null), key) || undefined;
    const D = { configurable: true, get() { return val; }, set(v) { val = convert(v, key); if (!D.enumerable && val) { D.enumerable = true; Object.defineProperty(STATES, nm, D); } } };
    D.enumerable = !!val; Object.defineProperty(STATES, nm, D); });
})();
