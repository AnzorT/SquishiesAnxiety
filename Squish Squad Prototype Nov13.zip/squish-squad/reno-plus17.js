// Renovation Catalog round 17 — Movie Room furniture remodel, part 2: centre tables, side tables, media shelves, tabletop props.
// Uses the plus16 toolkit (RD.H16). Sets RenoDraw.PLUS17; catalog edits RD.SET17.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS16 && RD.H16 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS17) return;
  const K = X.K, { solid, box, cyl, ball, slab, slabX, arcW, disc, pillowY, pillowZ, shade, mix, f1 } = K;
  const N = RD.N, PI = Math.PI, GOLD = '#e2b14a', CH = '#d5dde2';
  const { xf, tilt, tiltAll, rotF, rod, pipe, fxEll, frame, kern, cup, holder, an, FONT, W_, M_, F_, L_, PL, G_, em, rep } = RD.H16;
  const P2 = q => f1(q[0]) + ' ' + f1(q[1]), n4 = v => Math.round(v * 1e4) / 1e4;
  const R0 = s => { let h = 7; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) | 0; h = Math.abs(h) || 1; return () => { h = (h * 1103515245 + 12345) | 0; return ((h >>> 8) & 0xffff) / 65536; }; };
  const CASE = ['#d9363b', '#3f7fc8', '#f2c94c', '#4f9a4a', '#8a55c8', '#ff9d4a', '#2a2d34', '#e86fa8', '#3fc0c8'];
  const spark = (c, x, y, z, s, b, col) => '<g transform="translate(' + P2(c.p(x, y, z)) + ') scale(' + f1(c.k * (s || 1)) + ')"><path d="M0 -4L1 -1L4 0L1 1L0 4L-1 1L-4 0L-1 -1Z" fill="' + (col || '#ffffff') + '" opacity="0">' + an('opacity', '0;1;0;0', 1.8, b) + '</path></g>';
  const puffs = (c, x, y, z, n, col, d) => rep(n, i => { const q = c.p(x + (i % 3 - 1) * 2.4, y, z), b = n4(-i * (d || 2.4) / n); return '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(1.6 * c.k) + '" fill="' + (col || '#ffffff') + '" opacity="0">' + an('cy', f1(q[1]) + ';' + f1(q[1] - 14 * c.k), d || 2.4, b) + an('r', f1(1.2 * c.k) + ';' + f1(3.4 * c.k), d || 2.4, b) + an('opacity', '0;0.55;0', d || 2.4, b) + '</circle>'; }).join('');
  const can = (x, y, z, col, h) => [cyl(x, y, z, 3.2, h || 10, col, M_({ n: 12, rg: [[0, 0, 0.86], [0.8, 0, 1], [(h || 10) - 0.8, 0, 1], [h || 10, 0, 0.8]] })), cyl(x, y + (h || 10) * 0.42, z, 3.25, 2, '#ffffff', { n: 12, noOut: 1 }), cyl(x, y + (h || 10), z, 2.6, 0.3, CH, M_({ n: 10, noOut: 1 }))];

  // ======================= MOV-003 CRATE TABLE =======================
  N.crate17 = S => ({ w: 98, d: 50, topH: 31, topW: 60, build: () => { const o = [], BL = '#3f7fc8', BD = shade(BL, 0.68), PLY = '#d9b98a';
      [-21, 21].forEach(x => { const w = 40, h = 28, d = 38;
        o.push(box(x, 0, 0, w, h, d, BL, PL({ r: 3, bev: 1.2 })), box(x, 0, 0, w + 1.4, 3.4, d + 1.4, shade(BL, 0.88), PL({ r: 3.4 })), box(x, h - 3.4, 0, w + 1.4, 3.4, d + 1.4, shade(BL, 0.88), PL({ r: 3.4 })));
        rep(3, i => rep(2, j => o.push(box(x - 12 + i * 12, 6 + j * 9.6, d / 2 + 0.05, 8.4, 6.6, 0.4, BD, { r: 1.6, noOut: 1, mat: 'pl' }))));
        rep(3, i => rep(2, j => o.push(box(x + w / 2 + 0.05, 6 + j * 9.6, -12 + i * 12, 0.4, 6.6, 8.4, BD, { r: 1.6, noOut: 1, mat: 'pl' })))); });
      o.push(box(0, 28, 1, 94, 2.4, 46, PLY, W_({ r: 1, yaw: 0.035 })), cyl(26, 30.45, -10, 5, 0.1, '#8a6a40', { n: 16, noOut: 1, op: 0.35 }));
      o.push(box(-16, 30.4, 3, 32, 3.8, 30, '#ead6ae', PL({ r: 1, yaw: -0.14 })), cyl(-16, 34.2, 3, 6.4, 0.25, '#d9363b', { n: 16, noOut: 1 }), cyl(-16, 34.5, 3, 4, 0.2, '#ffffff', { n: 12, noOut: 1 }), cyl(-24, 34.25, 10, 3, 0.1, '#c9a060', { n: 10, noOut: 1, op: 0.5 }));
      can(20, 30.4, 8, '#4f9a4a').forEach(s => o.push(s)); o.push(ball(33, 30.4, 12, 3.2, '#ffffff', { sy: 0.8, k: 4, n: 10, shine: 0, mat: 'fab' }), ball(31, 30.4, 15, 2.4, '#f3f3f3', { k: 3, n: 8, shine: 0, mat: 'fab' }));
      return o; } });

  // ======================= MOV-023 SNACK TABLE (lift-top open, storage inside) =======================
  N.lift17 = S => { const W = 96, D2 = 50, OAK = '#d9a066', WH = '#f4efe6', LG = '#b98048';
    // top lifts up and back toward the sofa on chrome scissor arms; the open storage well in front shows the movie stash
    const FL = 13, TY = 40, TZ = -14, TD = 30;
    return { w: W + 6, d: D2 + 14, topH: TY + 3, topZ: TZ, topW: 50, build: () => { const o = [];
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => o.push(cyl(sx * (W / 2 - 7), 0, sz * (D2 / 2 - 7), 2.6, 6, LG, W_({ n: 10, rg: [[0, 0, 0.7], [6, 0, 1]] }))));
      o.push(box(0, 6, 0, W, FL - 6, D2, WH, PL({ r: 2, bev: 1.2 })), box(0, FL, 0, W - 6, 0.4, D2 - 6, '#4a3a40', { r: 0.6, noOut: 1, mat: 'fab' }));
      [-1, 1].forEach(sz => o.push(box(0, FL, sz * (D2 / 2 - 1.5), W, 26 - FL, 3, WH, PL({ r: 1.2 })))); [-1, 1].forEach(sx => o.push(box(sx * (W / 2 - 1.5), FL, 0, 3, 26 - FL, D2 - 6, WH, PL({ r: 0.8 }))));
      o.push(slabX(0, 9, D2 / 2 + 0.05, W - 12, 0.6, 0.4, shade(WH, 0.85), { r: 0, noOut: 1 }));
      [-1, 1].forEach(sz => o.push(box(0, 26, sz * (D2 / 2 - 1.6), W + 1, 2.2, 3.4, OAK, W_({ r: 1 })))); [-1, 1].forEach(sx => o.push(box(sx * (W / 2 - 1.6), 26, 0, 3.4, 2.2, D2 - 5, OAK, W_({ r: 0.8 }))));
      rep(9, i => o.push(box(-38 + i * 3.1, FL + 0.4, 6, 2.4, 12.6, 11, CASE[i % 9], PL({ r: 0.4, yaw: (i % 3 - 1) * 0.05 }))));
      rep(7, i => o.push(box(8 + i * 3.1, FL + 0.4, 6, 2.4, 12.6, 11, CASE[(i + 4) % 9], PL({ r: 0.4, yaw: (i % 2) * 0.06 }))));
      o.push(box(-2, FL + 0.4, 9, 10, 1.6, 13, '#2a2d34', PL({ r: 0.4, yaw: 0.2 })), box(-1.5, FL + 2, 9, 9.4, 1.4, 12.4, '#e86fa8', PL({ r: 0.4, yaw: 0.32 })));
      [-1, 1].forEach(sg => { const x = sg * 41.5; o.push(rod([x, FL + 1.8, -4], [x, TY - 1.8, TZ - 10], 0.8, CH, M_({ n: 6 })), rod([x, FL + 1.8, -18], [x, TY - 1.8, TZ + 8], 0.8, CH, M_({ n: 6 })), ball(x, (FL + TY) / 2 - 0.9, -11, 1.3, CH, M_({ k: 2, n: 8 })), box(x, FL, -11, 3, 1, 16, CH, M_({ r: 0.4 })), box(x, TY - 1, TZ, 3, 1, 24, CH, M_({ r: 0.4 }))); });
      o.push(box(0, TY, TZ - 2, W - 2, 3, TD, OAK, W_({ r: 2 })));
      const BX = -12, BZ = TZ + 4; o.push(cyl(BX, TY + 3, BZ, 8.4, 4.6, '#e86f5a', PL({ n: 18, rg: [[0, 0, 0.62], [4.6, 0, 1]] })), cyl(BX, TY + 7.2, BZ, 7.6, 0.4, '#a8402c', { n: 16, noOut: 1 }));
      const R = R0('chips'); rep(9, i => o.push(ball(BX + (R() - 0.5) * 10, TY + 7.2 + R() * 2, BZ + (R() - 0.5) * 8, 2.4, i % 2 ? '#f2c94c' : '#e8b23a', { sy: 0.32, k: 3, n: 8, shine: 0 })));
      can(14, TY + 3, TZ + 2, '#d9363b').forEach(s => o.push(s)); o.push(box(30, TY + 3, TZ - 2, 5, 1.8, 14, '#3a3b40', PL({ r: 1.4, yaw: 0.3 })));
      return o; } }; };

  // ======================= MOV-043 GLASS COFFEE TABLE =======================
  N.glass17 = S => { const W = 100, D2 = 52, H = 28, ST = '#26272b', GL = '#5a6470';
    return { w: W + 6, d: D2 + 6, topH: H + 1.6, topW: 60, build: () => { const o = [];
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => o.push(box(sx * (W / 2 - 2), 0, sz * (D2 / 2 - 2), 3, H, 3, ST, M_({ r: 0.6 }))));
      [H - 2.4, 5].forEach(y => { [-1, 1].forEach(sz => o.push(slabX(0, y, sz * (D2 / 2 - 2), W - 4, 2.4, 2.4, ST, M_({ r: 0.4 })))); [-1, 1].forEach(sx => o.push(box(sx * (W / 2 - 2), y, 0, 2.4, 2.4, D2 - 4, ST, M_({ r: 0.4 })))); });
      o.push(box(0, 7.4, 0, W - 6, 1.2, D2 - 6, GL, { r: 1, op: 0.5, shine: 1 }));
      [0, 1, 2].forEach(i => o.push(box(-24 + i * 2, 8.6 + i * 1.6, 2, 18, 1.6, 13, ['#3f7fc8', '#2a2d34', '#d9363b'][i], PL({ r: 0.5, yaw: i * 0.12 - 0.1 }))));
      o.push(box(22, 8.6, 4, 16, 3, 9, '#2a2c33', PL({ r: 3, yaw: -0.3 })), ball(18, 11.4, 2, 1, '#4fd06a', { k: 2, n: 6, noOut: 1 }), ball(26, 11.4, 6, 1, '#ff5a4a', { k: 2, n: 6, noOut: 1 }));
      o.push(box(0, H, 0, W, 1.6, D2, GL, { r: 2, op: 0.55, shine: 1 }));
      o.push(cyl(-20, H + 1.6, -6, 9, 5, '#cfe8f2', { n: 18, op: 0.55, shine: 1, rg: [[0, 0, 0.6], [5, 0, 1]] }));
      const R = R0('candy'); rep(10, i => o.push(ball(-20 + (R() - 0.5) * 11, H + 3 + R() * 2, -6 + (R() - 0.5) * 9, 1.6, CASE[i % 6], { k: 3, n: 8 })));
      o.push(cyl(24, H + 1.6, -8, 4.6, 6, '#e9e2d4', { n: 14, mat: 'cer', rg: [[0, 0, 0.8], [6, 0, 1]] })); rep(5, i => o.push(ball(24 + Math.cos(i * 1.26) * 2.4, H + 7 + (i % 2) * 2, -8 + Math.sin(i * 1.26) * 2.4, 2.4, i % 2 ? '#6fae5a' : '#86c46a', { sy: 1.3, k: 3, n: 8 })));
      [[8, 12], [-6, 14]].forEach(([x, z]) => o.push(cyl(x, H + 1.6, z, 4, 0.5, '#c9a87a', { n: 14 })));
      return o; } }; };

  // ======================= MOV-063 FRIDGE TABLE (lit fridge drawers, charging pad) =======================
  N.fridgeT17 = S => { const W = 120, D2 = 56, BODY = '#2b2d33', TOPC = '#14161c', CANS = ['#d9363b', '#3f7fc8', '#f2c94c', '#4f9a4a', '#ff9d4a', '#e86fa8'];
    return { w: W + 6, d: D2 + 14, topH: 36.4, topW: 70, glow: () => ({ y: 18, r: 70, c: 'url(#gNeon)' }), build: () => { const o = [];
      o.push(box(0, 0, 0, W - 10, 4, D2 - 10, '#141519', PL({ r: 1 })), slabX(0, 1.4, D2 / 2 - 4.6, W - 14, 1.2, 0.5, '#5fc8ff', em()));
      o.push(box(0, 4, 0, W, 30, D2, BODY, PL({ r: 3 })), box(0, 34, 0, W + 2, 2.4, D2 + 2, TOPC, G_({ r: 3 })));
      [-1, 1].forEach(sg => { const x = sg * 29, zf = D2 / 2;
        o.push(box(x, 6.4, zf + 2.4, 52, 24, 5, '#3a3d44', PL({ r: 2 })), box(x, 8.4, zf + 4.95, 47, 20, 0.4, '#cfeeff', em({ op: 0.95 })));
        [[10.4, 0], [19.6, 1]].forEach(([y, j]) => rep(6, i => o.push(cyl(x - 18.5 + i * 7.4, y, zf + 7.6, 2.8, 8, CANS[(i + j * 2 + (sg > 0 ? 3 : 0)) % 6], M_({ n: 10, rg: [[0, 0, 0.85], [0.7, 0, 1], [8, 0, 0.85]] })))));
        o.push(box(x, 6.4, zf + 10.6, 52, 24, 0.8, '#d8f0ff', { r: 1.6, op: 0.28, shine: 1 }), slabX(x, 27.2, zf + 11.8, 34, 1.6, 1.6, CH, M_({ r: 0.8 })));
        [6.4, 29.4].forEach(y => o.push(slabX(x, y, zf + 10.8, 52, 1, 1.2, '#4a4d55', PL({ r: 0.4 })))); });
      o.push(cyl(32, 36.4, -8, 9, 0.6, '#1d1f26', { n: 20 }), arcW(32, 36.6, -8, 8.4, 8.4, 0.8, 0.4, 0, 2 * PI, '#5fc8ff', em({ n: 20 })), box(32, 37.2, -8, 7.4, 0.9, 13.6, '#23252c', PL({ r: 1.6, yaw: 0.25 })), box(32, 38.1, -8, 6, 0.2, 11.6, '#3fa8ff', em({ r: 1, yaw: 0.25, op: 0.75 })));
      o.push(cyl(-30, 36.4, -6, 10, 4, '#f4efe6', { n: 18, mat: 'cer', rg: [[0, 0, 0.65], [4, 0, 1]] })); rep(8, i => kern(-30 + Math.cos(i * 0.8) * 5, 39.4 + (i % 3) * 0.8, -6 + Math.sin(i * 0.8) * 4, 1.7, i).forEach(s => o.push(s)));
      return o; },
      fx: c => { const q = c.p(32, 36.8, -8); return { front: '<ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + f1(11 * c.k) + '" ry="' + f1(11 * c.k * X.SA) + '" fill="none" stroke="#7fd8ff" stroke-width="' + f1(0.8 * c.k) + '">' + an('opacity', '0;0.9;0', 2) + an('rx', f1(8 * c.k) + ';' + f1(13 * c.k), 2) + an('ry', f1(8 * c.k * X.SA) + ';' + f1(13 * c.k * X.SA), 2) + '</ellipse>' + puffs(c, -29, 30, D2 / 2 + 12, 4, '#e8f8ff', 3) + puffs(c, 29, 30, D2 / 2 + 12, 4, '#e8f8ff', 3) }; } }; };

  // ======================= MOV-083 HOLO TABLE (round, touch lights, spinning hologram) =======================
  N.holoT17 = S => { const WH = '#f2f4f8', R = 32;
    return { w: 2 * R + 8, d: 2 * R + 8, topH: 30, topW: 44, build: () => { const o = [];
      o.push(cyl(0, 0, 0, 18, 3, WH, G_({ n: 24, rg: [[0, 0, 1], [3, 0, 0.86]] })), arcW(0, 2.6, 0, 18.4, 18.4, 0.9, 0.8, 0, 2 * PI, '#7ff0ff', em({ n: 24 })));
      o.push(cyl(0, 3, 0, 6, 23, WH, G_({ n: 16, rg: [[0, 0, 1], [10, 0, 0.75], [23, 0, 1.4]] })), cyl(0, 24, 0, 12, 1, '#7ff0ff', em({ n: 20 })));
      o.push(cyl(0, 25, 0, R, 3.4, WH, G_({ n: 30, rg: [[0, 0, 0.94], [1.2, 0, 1], [3.4, 0, 1]] })), cyl(0, 28.4, 0, R - 1.6, 1.2, '#bfefff', { n: 30, op: 0.5, shine: 1 }), arcW(0, 28.6, 0, R - 0.4, R - 0.4, 0.8, 0.6, 0, 2 * PI, '#7ff0ff', em({ n: 30 })));
      rep(8, i => { const t = i * PI / 4 + PI / 8, col = ['#7ff0ff', '#ff6fae', '#ffd66b', '#8fff9e'][i % 4]; o.push(box(Math.cos(t) * (R - 7), 29.7, Math.sin(t) * (R - 7), 5, 0.3, 3, col, em({ r: 0.8, yaw: t + PI / 2 }))); });
      o.push(cyl(0, 29.6, 0, 5, 0.6, '#1a1d2a', { n: 16 }), cyl(0, 30.2, 0, 3.6, 0.3, '#7ff0ff', em({ n: 14 })));
      return o; },
      fx: c => { const b = c.p(0, 30.4, 0), t = c.p(0, 62, 0), k = c.k, cx = f1(t[0]), cy = f1(t[1] + 6 * k);
        let f = '<defs><linearGradient id="p17hb" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#8ff6ff" stop-opacity="0.55"/><stop offset="1" stop-color="#8ff6ff" stop-opacity="0"/></linearGradient><pattern id="p17sc" width="4" height="1.6" patternUnits="userSpaceOnUse"><rect width="4" height="0.7" fill="#ffffff" opacity="0.35"/></pattern></defs>';
        f += '<path d="M' + f1(b[0] - 3.6 * k) + ' ' + f1(b[1]) + 'L' + f1(t[0] - 16 * k) + ' ' + f1(t[1]) + 'H' + f1(t[0] + 16 * k) + 'L' + f1(b[0] + 3.6 * k) + ' ' + f1(b[1]) + 'Z" fill="url(#p17hb)">' + an('opacity', '0.6;1;0.7;0.95;0.6', 2.2) + '</path>';
        const rr = 12 * k, hole = i => { const a = i * 2 * PI / 5; return '<circle cx="' + f1(Math.cos(a) * rr * 0.55) + '" cy="' + f1(Math.sin(a) * rr * 0.55) + '" r="' + f1(rr * 0.2) + '" fill="#0d3a4a" fill-opacity="0.55"/>'; };
        f += '<g transform="translate(' + cx + ' ' + cy + ')" opacity="0.9">' + an('opacity', '0.85;0.95;0.6;0.95;0.85', 1.7) + '<g>' + '<animateTransform attributeName="transform" type="rotate" values="0;360" dur="6s" repeatCount="indefinite"/>'
          + '<circle r="' + f1(rr) + '" fill="#8ff6ff" fill-opacity="0.45" stroke="#dffcff" stroke-width="' + f1(0.6 * k) + '"/>' + rep(5, hole).join('') + '<circle r="' + f1(rr * 0.16) + '" fill="#dffcff"/></g>'
          + '<circle r="' + f1(rr) + '" fill="url(#p17sc)"/>' + '<path d="M' + f1(rr * 0.9) + ' ' + f1(rr * 0.7) + 'q' + f1(rr * 0.6) + ' ' + f1(rr * 0.3) + ' ' + f1(rr * 1.1) + ' ' + f1(-rr * 0.1) + '" stroke="#8ff6ff" stroke-width="' + f1(1.2 * k) + '" fill="none" stroke-linecap="round" opacity="0.7"/></g>';
        rep(3, i => { const a = c.p(-20 + i * 20, 44 + (i % 2) * 6, 6); f += '<rect x="' + f1(a[0] - 4 * k) + '" y="' + f1(a[1] - 2.4 * k) + '" width="' + f1(8 * k) + '" height="' + f1(4.8 * k) + '" rx="' + f1(1 * k) + '" fill="#8ff6ff" fill-opacity="0.18" stroke="#8ff6ff" stroke-width="' + f1(0.4 * k) + '">' + an('opacity', '0.3;1;0.3', 2 + i * 0.4, -i * 0.5) + '</rect>'; });
        return { front: f, bb: [t[0] - 26 * k, t[1] - 10 * k, t[0] + 26 * k, t[1] + 30 * k] }; } }; };

  // ======================= MOV-007 TV TRAY (TV dinner on it) =======================
  N.tray17 = S => { const MU = '#e8a23a', GT = '#d8b04a';
    return { w: 50, d: 40, topH: 33.6, topW: 26, build: () => { const o = [];
      [-1, 1].forEach(sx => { const x = sx * 17; o.push(rod([x, 0, -13], [x, 29.4, 11], 0.9, GT, M_({ n: 6 })), rod([x, 0, 13], [x, 29.4, -11], 0.9, GT, M_({ n: 6 }))); [-13, 13].forEach(z => o.push(ball(x, -0.4, z, 1.4, '#3a3530', { k: 3, n: 6, sy: 0.6, shine: 0 }))); });
      o.push(rod([-17, 3.4, -12], [17, 3.4, -12], 0.8, GT, M_({ n: 6 })));
      o.push(box(0, 30, 0, 44, 1.6, 32, MU, PL({ r: 2 })));
      [-1, 1].forEach(s => { o.push(slabX(0, 31.6, s * 15.4, 44, 1.6, 1.2, shade(MU, 0.82), PL({ r: 0.5 }))); o.push(box(s * 21.4, 31.6, 0, 1.2, 1.6, 30, shade(MU, 0.82), PL({ r: 0.5 }))); });
      [[-14, -9], [14, 8], [-15, 9], [15, -9]].forEach(([x, z]) => { o.push(cyl(x, 31.62, z, 3.4, 0.1, '#fff3dc', { n: 12, noOut: 1 }), cyl(x, 31.7, z, 1.3, 0.1, '#e86f2a', { n: 10, noOut: 1 })); });
      o.push(box(1, 31.6, 0, 26, 2.2, 19, '#c9ced3', M_({ r: 1.6 })), slabX(1, 31.9, -1, 24, 1.8, 0.5, '#aeb4ba', M_({ r: 0, noOut: 1 })), box(-4, 31.9, 4.6, 0.5, 1.8, 8, '#aeb4ba', M_({ r: 0, noOut: 1 })));
      o.push(ball(5, 33.2, -5, 4.4, '#fffaf0', { sy: 0.5, k: 4, n: 12, shine: 0, mat: 'fab' }), ball(4, 35, -5.6, 1, '#ffd34a', { k: 2, n: 6, sy: 0.5 }));
      rep(7, i => o.push(ball(-9 + (i % 4) * 2.2, 33.4 + (i > 3 ? 0.4 : 0), 3 + Math.floor(i / 4) * 2.6, 1.05, '#6fbf4a', { k: 3, n: 6 })));
      [[7, 4], [10.4, 5], [8.5, 7.4]].forEach(([x, z]) => o.push(ball(x, 33.4, z, 2, '#c8823a', { sy: 0.6, k: 3, n: 8, shine: 0 })));
      o.push(rod([-11, 32.6, -4], [-11, 32.6, 9], 0.45, '#e9ecef', M_({ n: 5 })), box(-11, 32.4, -6, 2.2, 0.4, 3.4, '#e9ecef', M_({ r: 0.4 })));
      return o; } }; };

  // ======================= MOV-047 BRASS SIDE TABLE (C shape, slides under the sofa) =======================
  N.ctable17 = S => { const BR = '#d4a548', WAL = '#7a4a2a';
    return { w: 40, d: 40, topH: 38.6, topW: 22, build: () => { const o = [];
      o.push(box(-2, 0, 0, 28, 2, 26, BR, M_({ r: 8 })), box(-15, 2, 0, 3, 34, 16, BR, M_({ r: 1.2 })), box(-9, 34, 0, 13, 2, 16, BR, M_({ r: 1.2 })));
      o.push(cyl(1, 36, 0, 17, 2.6, WAL, W_({ n: 26 })), arcW(1, 36, 0, 17.4, 17.4, 0.7, 2.6, 0, 2 * PI, BR, M_({ n: 26 })));
      o.push(cyl(6, 38.6, 4, 5.2, 0.7, '#b98a58', { n: 16, mat: 'fab' }), cyl(6, 39.3, 4, 3.6, 12, '#e8f6ff', { n: 14, op: 0.5, shine: 1, rg: [[0, 0, 0.86], [12, 0, 1]] }), cyl(6, 39.7, 4, 3.1, 9, '#6a2a12', { n: 14, op: 0.85 }));
      o.push(box(5, 46.6, 3, 2.2, 2.2, 2.2, '#ffffff', { r: 0.4, op: 0.8, yaw: 0.4 }), box(7, 47.4, 5, 2, 2, 2, '#ffffff', { r: 0.4, op: 0.8, yaw: 1 }), rod([6.6, 49, 4], [8.4, 56, 2.6], 0.5, '#ff5a7a', PL({ n: 4 })));
      o.push(cyl(-6, 38.6, -5, 6, 4, '#ffffff', { n: 16, mat: 'cer', rg: [[0, 0, 0.7], [4, 0, 1]] })); rep(6, i => kern(-6 + Math.cos(i) * 3, 41.6 + (i % 2), -5 + Math.sin(i) * 2.6, 1.5, i).forEach(s => o.push(s)));
      return o; } }; };

  // ======================= MOV-067 MARBLE SIDE TABLE (glowing chilled coaster) =======================
  N.marbleT17 = S => { const MB = '#f3efe8';
    return { w: 44, d: 44, topH: 34, topW: 26, build: () => { const o = [];
      o.push(cyl(0, 0, 0, 14, 2.6, GOLD, M_({ n: 22, rg: [[0, 0, 1], [2.6, 0, 0.82]] })), cyl(0, 2.6, 0, 5, 26, GOLD, M_({ n: 16, rg: [[0, 0, 1.3], [4, 0, 0.9], [22, 0, 0.9], [26, 0, 1.5]] })));
      rep(8, i => { const t = i * PI / 4; o.push(rod([Math.cos(t) * 4.7, 6.6, Math.sin(t) * 4.7], [Math.cos(t) * 4.7, 24.6, Math.sin(t) * 4.7], 0.45, shade(GOLD, 0.78), M_({ n: 4, noOut: 1 }))); });
      o.push(cyl(0, 28.6, 0, 10, 2.4, GOLD, M_({ n: 18 })), cyl(0, 31, 0, 19, 3, MB, { n: 28, mat: 'cer' }), arcW(0, 31, 0, 19.4, 19.4, 0.8, 3, 0, 2 * PI, GOLD, M_({ n: 28 })));
      o.push(cyl(4, 34, 2, 6, 0.8, '#7fd8ff', em({ n: 18 })), cyl(4, 34.8, 2, 3.8, 12, '#e8f6ff', { n: 14, op: 0.55, shine: 1, rg: [[0, 0, 0.82], [12, 0, 1]] }), cyl(4, 35.2, 2, 3.2, 8.6, '#7a3216', { n: 14, op: 0.85 }));
      o.push(box(3, 42.4, 1.4, 2.4, 2.4, 2.4, '#f4fbff', { r: 0.5, op: 0.85, yaw: 0.5 }), box(5.4, 43, 3, 2, 2, 2, '#f4fbff', { r: 0.5, op: 0.85, yaw: 1.1 }), disc(4.6, 46.4, 5.6, 2.6, 0.6, '#f2d23a', { n: 12 }));
      return o; },
      fx: c => { const q = c.p(4, 34.6, 2), V = '<path d="M-3 0Q0 -1 3 0" stroke="#b8b2a8" stroke-width="0.5" fill="none" stroke-linecap="round"/>';
        const veins = [[-10, -6, 0.3], [-4, 8, -0.4], [9, -9, 0.8]].map(([x, z, a]) => { const o = c.p(x, 34.05, z); return '<g transform="' + frame(c.p, [x, 34.05, z], [Math.cos(a) * 2, 0, Math.sin(a) * 2], [0, 0, 1]) + '" opacity="0.6">' + V + '</g>'; }).join('');
        return { front: veins + '<ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + f1(8 * c.k) + '" ry="' + f1(8 * c.k * X.SA) + '" fill="#7fd8ff" opacity="0.3">' + an('opacity', '0.15;0.45;0.15', 2.4) + '</ellipse>' + puffs(c, 4, 36, 6.4, 5, '#ffffff', 3) + spark(c, 1, 44, 6, 0.4, -0.3) + spark(c, 8, 40, 6, 0.35, -1.1) }; } }; };

  // ======================= MOV-087 ROBOT BUTLER (rolls around, blinks) =======================
  N.bot17 = S => { const WH = '#f2f4f8', CY = '#5fe0ff';
    return { w: 44, d: 48, roam: 1, build: () => { const o = [];
      o.push(cyl(0, 1.6, 0, 15, 5, '#3a3d44', PL({ n: 22, rg: [[0, 0, 0.9], [1.4, 0, 1], [5, 0, 0.92]] })), arcW(0, 3, 0, 15.4, 15.4, 0.9, 1, 0, 2 * PI, CY, em({ n: 24 })));
      rep(3, i => { const t = i * 2 * PI / 3 + PI / 2; o.push(ball(Math.cos(t) * 10, 0, Math.sin(t) * 10, 2.2, '#1d1e22', { k: 3, n: 8, shine: 0 })); });
      o.push(ball(0, 6, 0, 15, WH, G_({ sy: 1.22, k: 8, n: 20 })), box(0, 18, 14, 10, 8, 1.4, '#1a1d2a', { r: 2.4 }), box(-2.4, 22, 14.8, 1.8, 1.8, 0.4, '#ff6fae', em({ r: 0.9 })), box(1.2, 22, 14.8, 1.8, 1.8, 0.4, CY, em({ r: 0.9 })), box(0, 19, 14.8, 7, 1.2, 0.4, '#8fff9e', em({ r: 0.5 })));
      o.push(cyl(0, 41, 0, 7, 3, '#c9ced3', M_({ n: 16 })), ball(0, 43, 0, 13, WH, G_({ sy: 0.86, k: 7, n: 20 })), box(0, 47, 9.6, 17, 10, 2, '#1a1d2a', { r: 4.6 }));
      [-1, 1].forEach(sg => o.push(ball(sg * 12.6, 52, 0, 2.6, '#c9ced3', M_({ k: 3, n: 10, sx: 0.6 }))));
      o.push(rod([0, 64.6, 0], [0, 71, -1], 0.6, '#9aa0a6', M_({ n: 6 })), ball(0, 70, -1, 1.8, '#ff5a7a', em({ k: 3, n: 8 })));
      [-1, 1].forEach(sg => pipe([[sg * 13.6, 30, 3], [sg * 17, 26, 10], [sg * 11, 32, 18]], 1.4, '#c9ced3', M_({ n: 8 })).forEach(s => o.push(s)));
      o.push(cyl(0, 33.4, 18, 13, 1.4, CH, M_({ n: 24 })), arcW(0, 34.8, 18, 13, 13, 0.8, 1, 0, 2 * PI, CH, M_({ n: 24 })));
      cup(-5, 34.8, 18, 3.4, 10, '#d9363b').forEach(s => o.push(s));
      o.push(cyl(5, 34.8, 19, 4, 7, '#ffffff', PL({ n: 12, rg: [[0, 0, 0.8], [7, 0, 1]] }))); rep(6, i => kern(5 + (i % 3 - 1) * 2.4, 41.6 + (i > 2 ? 1.4 : 0), 19 + (i > 2 ? 1.6 : -1), 1.4, i).forEach(s => o.push(s)));
      return o; },
      fx: c => { const M = frame(c.p, [0, 52, 10.7], [1, 0, 0], [0, -1, 0]), eye = x => '<rect x="' + (x - 1.8) + '" y="-2.4" width="3.6" height="4.4" rx="1.8" fill="#7ff0ff"><animate attributeName="height" values="4.4;4.4;0.6;4.4;4.4" keyTimes="0;0.9;0.94;0.98;1" dur="3.4s" repeatCount="indefinite"/><animate attributeName="y" values="-2.4;-2.4;-0.3;-2.4;-2.4" keyTimes="0;0.9;0.94;0.98;1" dur="3.4s" repeatCount="indefinite"/></rect>';
        const a = c.p(0, 72.6, -1);
        return { front: '<g transform="' + M + '">' + eye(-4) + eye(4) + '<path d="M-2.4 3Q0 4.8 2.4 3" stroke="#7ff0ff" stroke-width="0.8" fill="none" stroke-linecap="round"/><circle cx="-6.6" cy="2.6" r="1.1" fill="#ff8fb4" opacity="0.6"/><circle cx="6.6" cy="2.6" r="1.1" fill="#ff8fb4" opacity="0.6"/></g>'
          + '<circle cx="' + f1(a[0]) + '" cy="' + f1(a[1] + 1.6 * c.k) + '" r="' + f1(3.6 * c.k) + '" fill="#ff5a7a" opacity="0">' + an('opacity', '0;0.6;0', 1.4) + '</circle>' }; } }; };

  // ======================= MOV-017 BRICK SHELF (cinder blocks + pine boards, VHS tapes) =======================
  N.brick17 = S => { const CB = '#a9a7a1', PN = '#dcb37a', W = 104, Dd = 24, BH = 11, TH = 2.4;
    return { w: W + 6, d: Dd + 6, topH: 3 * (BH + TH), topW: 50, build: () => { const o = [], R = R0('vhs');
      rep(3, l => { const y = l * (BH + TH);
        [-40, 40].forEach(x => { o.push(box(x, y, 0, 18, BH, Dd - 2, shade(CB, 1 - l * 0.03), { r: 0.8, mat: 'paint' })); [-4.2, 4.2].forEach(dx => o.push(box(x + dx, y + 2.2, (Dd - 2) / 2 + 0.05, 6, BH - 4.4, 0.3, '#5a5853', { r: 0.8, noOut: 1 }))); });
        o.push(box(0, y + BH, 0, W, TH, Dd, PN, W_({ r: 0.8 }))); });
      const tape = (x, y, z, yaw, col) => [box(x, y, z, 3.4, 11.4, 17, '#1d1d21', PL({ r: 0.4, yaw })), box(x, y + 1.2, z + 8.55, 3, 9, 0.2, col, { r: 0.2, yaw, noOut: 1 })];
      rep(7, i => tape(-30 + i * 4.2, BH + TH, 0, 0, CASE[i]).forEach(s => o.push(s)));
      tiltAll(tape(1.6, BH + TH, 0, 0, '#ffffff'), [0, 0, 1], -0.4, [3.4, BH + TH, 0]).forEach(s => o.push(s));
      rep(4, i => o.push(box(-18 + (i % 2) * 1.4, 2 * (BH + TH) + i * 3.4, 0, 19, 3.4, 11, i % 2 ? '#26262a' : '#1d1d21', PL({ r: 0.4, yaw: (R() - 0.5) * 0.3 })), box(-18 + (i % 2) * 1.4, 2 * (BH + TH) + i * 3.4 + 0.6, 5.55, 15, 2.2, 0.2, CASE[i + 3], { r: 0.2, noOut: 1 })));
      o.push(cyl(16, 2 * (BH + TH), 2, 4.4, 8, '#c9ced3', M_({ n: 14 })), cyl(16, 2 * (BH + TH) + 3, 2, 4.5, 2.6, '#d9363b', { n: 14, noOut: 1 }));
      rep(5, i => { const t = i * 1.25; o.push(ball(16 + Math.cos(t) * 2.2, 2 * (BH + TH) + 8 + (i % 2) * 3, 2 + Math.sin(t) * 2.2, 2.6, i % 2 ? '#5fa84a' : '#79c25a', { sy: 1.4, k: 3, n: 8 })); });
      { const y = 3 * (BH + TH); o.push(box(-10, y, 0, 5, 14, 19, '#f7f3ea', PL({ r: 0.6 })), box(-10, y + 2, 9.55, 4.6, 10, 0.2, '#ff9d4a', { r: 0.2, noOut: 1 }), box(-4, y, 0, 5, 14, 19, '#26262a', PL({ r: 0.6, yaw: 0.06 }))); }
      o.push(box(24, 3 * (BH + TH), 0, 22, 9, 10, '#4a4c52', PL({ r: 1.4 })), cyl(18, 3 * (BH + TH) + 4.5, 5.1, 3.2, 0.4, '#2a2a2e', { n: 14 }));
      o.push(disc(18, 3 * (BH + TH) + 4.5, 5.1, 3.2, 0.5, '#2a2a2e', { n: 14 }), disc(30, 3 * (BH + TH) + 4.5, 5.1, 3.2, 0.5, '#2a2a2e', { n: 14 }), box(24, 3 * (BH + TH) + 7, 5.2, 5, 1.4, 0.3, '#7dff9e', em({ r: 0.4 })), rod([16, 3 * (BH + TH) + 9, 0], [32, 3 * (BH + TH) + 9, 0], 0.6, '#9aa0a6', M_({ n: 5 })));
      return o; } }; };

  // ======================= MOV-037 DVD TOWER (spinning wire rack) =======================
  N.dvd17 = S => { const ST = '#2c2e33', TY = [6, 28, 50, 72], RR = 13;
    return { w: 40, d: 40, build: () => { const o = [];
      o.push(cyl(0, 0, 0, 16, 2.4, ST, M_({ n: 22, rg: [[0, 0, 1], [2.4, 0, 0.9]] })), cyl(0, 2.4, 0, 1.4, 92, CH, M_({ n: 8 })), ball(0, 93, 0, 3, '#d9363b', G_({ k: 4, n: 10 })));
      TY.forEach((y, l) => { o.push(cyl(0, y, 0, RR + 1, 1, ST, M_({ n: 22 })), arcW(0, y + 13, 0, RR + 1, RR + 1, 0.8, 0.8, 0, 2 * PI, ST, M_({ n: 22 })));
        rep(10, i => { const t = i * 2 * PI / 10 + l * 0.3, col = CASE[(i + l * 3) % CASE.length]; o.push(box(Math.cos(t) * (RR - 2), y + 1, Math.sin(t) * (RR - 2), 7.4, 11, 1.4, col, PL({ r: 0.4, yaw: t + PI / 2 })), box(Math.cos(t) * (RR - 1.25), y + 7, Math.sin(t) * (RR - 1.25), 5, 3, 0.1, '#ffffff', { r: 0.3, yaw: t + PI / 2, noOut: 1, op: 0.75 })); });
        rep(4, i => { const t = i * PI / 2 + PI / 4; o.push(rod([Math.cos(t) * (RR + 0.6), y + 1, Math.sin(t) * (RR + 0.6)], [Math.cos(t) * (RR + 0.6), y + 13.4, Math.sin(t) * (RR + 0.6)], 0.4, ST, M_({ n: 4 }))); }); });
      return o; } }; };

  // ======================= MOV-057 WOOD MEDIA CONSOLE (walnut, slatted doors, drawers) =======================
  N.console17 = S => { const W = 140, Dd = 40, WAL = '#7a4a2a', WL = shade(WAL, 1.18), WD = shade(WAL, 0.72), BR = '#d4a548';
    return { w: W + 8, d: Dd + 8, topH: 42.4, topW: 80, build: () => { const o = [];
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => o.push(rod([sx * (W / 2 - 9), 12, sz * (Dd / 2 - 7)], [sx * (W / 2 - 4), 0, sz * (Dd / 2 - 3)], 1.8, WD, W_({ n: 8 }))));
      o.push(box(0, 12, 0, W, 28, Dd, WAL, W_({ r: 2 })), box(0, 40, 0, W + 2, 2.4, Dd + 2, WL, W_({ r: 1.6 })));
      [-1, 1].forEach(sg => { const x = sg * 46; o.push(box(x, 14, Dd / 2 + 0.4, 44, 24, 1, WL, W_({ r: 1 }))); rep(10, i => o.push(box(x - 19.8 + i * 4.4, 15, Dd / 2 + 1.1, 2.4, 22, 0.8, i % 2 ? WAL : shade(WAL, 0.88), W_({ r: 0.5 })))); o.push(ball(x - sg * 18, 25.4, Dd / 2 + 2.2, 1.2, BR, M_({ k: 3, n: 8, sz: 0.6 }))); });
      [14, 26].forEach(y => { o.push(box(0, y, Dd / 2 + 0.4, 44, 11, 1.2, WL, W_({ r: 1 })), slabX(0, y + 7.4, Dd / 2 + 1.4, 12, 1.4, 1, BR, M_({ r: 0.6 }))); });
      o.push(cyl(-50, 42.4, -4, 5, 9, '#e9e2d4', { n: 14, mat: 'cer', rg: [[0, 0, 0.75], [9, 0, 1]] }));
      rep(7, i => { const t = i * 0.9; o.push(tilt(box(-50 + Math.cos(t) * 2.4, 50, -4 + Math.sin(t) * 2.4, 2.4, 14, 1, i % 2 ? '#5fa84a' : '#79c25a', { r: 1 }), [Math.sin(t), 0, -Math.cos(t)], 0.45, [-50, 50, -4])); });
      [0, 1, 2].forEach(i => o.push(box(40 + i * 0.8, 42.4 + i * 1.8, -2, 16, 1.8, 12, ['#3f7fc8', '#d9363b', '#2a2d34'][i], PL({ r: 0.5, yaw: i * 0.15 - 0.1 }))));
      o.push(cyl(14, 42.4, -8, 9, 1.4, '#1a1a1d', { n: 20 }), cyl(14, 43.8, -8, 2, 0.6, '#e86f5a', { n: 10 }), box(-6, 42.4, -6, 16, 3, 12, '#26272b', PL({ r: 1.4 })), ball(-2, 45.4, -1, 0.8, '#5fe0ff', em({ k: 2, n: 6 })));
      return o; } }; };

  // ======================= MOV-077 MOVIE VAULT (tall glass cabinet of steelbooks) =======================
  N.vault17 = S => { const W = 92, Dd = 34, H = 150, FR = '#1e1d22', STL = ['#aab3bb', '#7d858e', '#d4a548', '#9a3a3a', '#3f6aa8', '#c9ced3', '#5a5e66', '#b07a3a'];
    return { w: W + 6, d: Dd + 8, build: () => { const o = [];
      o.push(box(0, 0, 0, W, 8, Dd, FR, PL({ r: 1.5 })), box(0, H - 6, 0, W + 2, 6, Dd + 2, FR, PL({ r: 1.5 })), slab(0, 8, -Dd / 2 + 1.5, W - 4, H - 14, 2, '#2c2a36', { r: 1, mat: 'pl' }));
      [-1, 1].forEach(sg => o.push(box(sg * (W / 2 - 2), 8, 0, 4, H - 14, Dd, FR, PL({ r: 1 }))));
      const sh = [8, 35, 62, 89, 116];
      sh.forEach((y, l) => { if (l) o.push(box(0, y, 0, W - 8, 1.2, Dd - 4, '#cfe8f2', { r: 0.5, op: 0.45, shine: 1 })); o.push(slabX(0, y + 26, Dd / 2 - 4, W - 10, 0.8, 0.8, '#fff2c8', em()));
        rep(6, i => { const x = -W / 2 + 13 + i * 13.2, col = STL[(i + l * 3) % STL.length], yaw = (i === 2 || i === 5) ? 0.35 : 0, front = yaw === 0;
          o.push(box(x, y + 1.2, front ? -4 : -2, 10, 16 - (i % 2) * 1.6, 1.6, col, M_({ r: 0.8, yaw })), box(x, y + 4 + (i % 2), (front ? -4 : -2) + 0.85, 7, 6, 0.2, shade(col, 1.35), { r: 0.6, yaw, noOut: 1 }));
          if (!front) o.push(box(x, y + 1.2, 0.6, 7, 2, 4, '#2c2e33', PL({ r: 0.4, yaw }))); }); });
      [-1, 1].forEach(sg => { const x = sg * (W / 4 - 0.6);
        o.push(box(x, 9, Dd / 2 + 0.8, W / 2 - 3.6, H - 16, 0.8, '#d6eef8', { r: 1, op: 0.2, shine: 1, noOut: 1 }));
        [9, H - 9].forEach(y => o.push(slabX(x, y - 0.8, Dd / 2 + 1, W / 2 - 3.6, 1.6, 1.4, FR, PL({ r: 0.4 }))));
        [x - sg * (W / 4 - 2.4), x + sg * (W / 4 - 2.4)].forEach(xx => o.push(box(xx, 9, Dd / 2 + 1, 1.6, H - 18, 1.4, FR, PL({ r: 0.4 }))));
        o.push(rod([sg * 3.4, 60, Dd / 2 + 3], [sg * 3.4, 92, Dd / 2 + 3], 0.8, GOLD, M_({ n: 6 })), rod([sg * 3.4, 60, Dd / 2 + 1.6], [sg * 3.4, 60, Dd / 2 + 3], 0.6, GOLD, M_({ n: 4 })), rod([sg * 3.4, 92, Dd / 2 + 1.6], [sg * 3.4, 92, Dd / 2 + 3], 0.6, GOLD, M_({ n: 4 }))); });
      o.push(box(W / 2 + 0.4, 70, Dd / 2 - 6, 1.2, 9, 6, '#26272b', PL({ r: 0.8 })), box(W / 2 + 1.1, 76, Dd / 2 - 6, 0.3, 1.6, 4, '#7dff9e', em({ r: 0.3 })));
      return o; },
      fx: c => { const A = c.p(-W / 2 + 4, H - 10, Dd / 2 + 1.4), B = c.p(W / 2 - 4, 10, Dd / 2 + 1.4), k = c.k;
        return { front: '<defs><clipPath id="p17vc"><path d="M' + P2(c.p(-W / 2 + 3, H - 9, Dd / 2 + 1.4)) + 'L' + P2(c.p(W / 2 - 3, H - 9, Dd / 2 + 1.4)) + 'L' + P2(c.p(W / 2 - 3, 9, Dd / 2 + 1.4)) + 'L' + P2(c.p(-W / 2 + 3, 9, Dd / 2 + 1.4)) + 'Z"/></clipPath></defs><g clip-path="url(#p17vc)"><rect x="' + f1(A[0] - 30 * k) + '" y="' + f1(Math.min(A[1], B[1]) - 20 * k) + '" width="' + f1(16 * k) + '" height="' + f1(Math.abs(B[1] - A[1]) + 60 * k) + '" fill="#ffffff" opacity="0.22" transform="skewX(-20)">' + an('x', f1(A[0] - 60 * k) + ';' + f1(B[0] + 60 * k), 6) + '</rect></g>' }; } }; };

  // ======================= MOV-097 HOLO MOVIE LIBRARY (pedestal + orbiting movie covers) =======================
  N.holoLib17 = S => { const WH = '#eef1f6';
    return { w: 56, d: 56, glow: () => ({ y: 40, r: 60, c: 'url(#gNeon)' }), build: () => { const o = [];
      o.push(cyl(0, 0, 0, 22, 4, WH, G_({ n: 26, rg: [[0, 0, 1], [4, 0, 0.9]] })), cyl(0, 4, 0, 15, 7, WH, G_({ n: 22, rg: [[0, 0, 1], [7, 0, 0.82]] })), arcW(0, 3.6, 0, 22.4, 22.4, 1, 0.8, 0, 2 * PI, '#7ff0ff', em({ n: 26 })));
      o.push(cyl(0, 11, 0, 11, 1, '#1a1d2a', { n: 20 }), cyl(0, 12, 0, 8, 0.6, '#7ff0ff', em({ n: 18 })));
      rep(3, i => o.push(box(-6 + i * 6, 6, 13.6, 3.4, 1.4, 0.6, ['#7ff0ff', '#ff6fae', '#ffd66b'][i], em({ r: 0.6 }))));
      return o; },
      fx: c => { const k = c.k, b = c.p(0, 12.6, 0), t = c.p(0, 86, 0), ring = (y, r, n, d, rev, w, h, sh) => { const q = c.p(0, y, 0), rx = r * k, ry = r * k * X.SA, path = 'M' + f1(q[0] + (rev ? -rx : rx)) + ' ' + f1(q[1]) + 'A' + f1(rx) + ' ' + f1(ry) + ' 0 1 ' + (rev ? 0 : 1) + ' ' + f1(q[0] + (rev ? rx : -rx)) + ' ' + f1(q[1]) + 'A' + f1(rx) + ' ' + f1(ry) + ' 0 1 ' + (rev ? 0 : 1) + ' ' + f1(q[0] + (rev ? -rx : rx)) + ' ' + f1(q[1]);
          return '<path d="M' + f1(q[0] - rx) + ' ' + f1(q[1]) + 'a' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(2 * rx) + ' 0a' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(-2 * rx) + ' 0" fill="none" stroke="#8ff6ff" stroke-opacity="0.35" stroke-width="' + f1(0.5 * k) + '"/>'
            + rep(n, i => { const bg = n4(-i * d / n), col = CASE[(i + sh) % CASE.length];
              return '<g opacity="1"><animateMotion dur="' + d + 's" begin="' + bg + 's" repeatCount="indefinite" path="' + path + '"/><animate attributeName="opacity" values="1;1;0.35;0.35;1" keyTimes="0;0.42;0.55;0.92;1" dur="' + d + 's" begin="' + bg + 's" repeatCount="indefinite"/>'
                + '<rect x="' + f1(-w / 2 * k) + '" y="' + f1(-h / 2 * k) + '" width="' + f1(w * k) + '" height="' + f1(h * k) + '" rx="' + f1(0.8 * k) + '" fill="' + col + '" fill-opacity="0.75" stroke="#dffcff" stroke-width="' + f1(0.4 * k) + '"/><rect x="' + f1(-w / 2 * k + 1.2 * k) + '" y="' + f1(h / 2 * k - 3.6 * k) + '" width="' + f1((w - 2.4) * k) + '" height="' + f1(2 * k) + '" fill="#ffffff" fill-opacity="0.7"/><circle cx="0" cy="' + f1(-h * 0.12 * k) + '" r="' + f1(w * 0.22 * k) + '" fill="#ffffff" fill-opacity="0.45"/></g>'; }).join(''); };
        let f = '<defs><linearGradient id="p17lb" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#8ff6ff" stop-opacity="0.5"/><stop offset="1" stop-color="#8ff6ff" stop-opacity="0"/></linearGradient></defs>';
        f += '<path d="M' + f1(b[0] - 8 * k) + ' ' + f1(b[1]) + 'L' + f1(t[0] - 14 * k) + ' ' + f1(t[1]) + 'H' + f1(t[0] + 14 * k) + 'L' + f1(b[0] + 8 * k) + ' ' + f1(b[1]) + 'Z" fill="url(#p17lb)">' + an('opacity', '0.6;1;0.75;0.95;0.6', 2.6) + '</path>';
        f += ring(34, 24, 8, 12, 0, 8, 11, 0) + ring(60, 18, 6, 9, 1, 7, 9.6, 3);
        const s = c.p(0, 80, 0); f += '<g transform="translate(' + P2(s) + ')"><g>' + '<animateTransform attributeName="transform" type="scale" values="1 1;0.15 1;1 1" dur="3s" repeatCount="indefinite"/><circle r="' + f1(5 * k) + '" fill="#8ff6ff" fill-opacity="0.3" stroke="#dffcff" stroke-width="' + f1(0.5 * k) + '"/><path d="M' + f1(-1.6 * k) + ' ' + f1(-2.6 * k) + 'L' + f1(2.8 * k) + ' 0L' + f1(-1.6 * k) + ' ' + f1(2.6 * k) + 'Z" fill="#ffffff"/></g></g>';
        return { front: f }; } }; };

  // ======================= MOV-008 CANDY & 3D GLASSES =======================
  N.candy17 = S => ({ w: 62, d: 40, small: 1, build: () => { const o = [], CC = ['#d9363b', '#f2c94c', '#3f7fc8', '#4f9a4a', '#ff9d4a', '#8a55c8', '#ff7fb0'];
      o.push(box(-10, 0, 0, 28, 8, 18, '#d9363b', PL({ r: 1.2 })), box(-10, 7.6, 0, 26, 0.6, 16, '#7a1a1e', { r: 0.8, noOut: 1 }), slabX(-10, 3, 9.05, 24, 2, 0.2, '#f2c94c', { r: 0, noOut: 1 }));
      tiltAll([slab(-10, 8, -9, 28, 13, 0.8, '#f2c94c', PL({ r: 1 })), slab(-10, 10, -8.55, 22, 9, 0.2, '#d9363b', { r: 2, noOut: 1 })], [1, 0, 0], -0.4, [-10, 8, -9]).forEach(s => o.push(s));
      rep(16, i => o.push(ball(-20 + (i % 6) * 4 + (Math.floor(i / 6) % 2) * 2, 7.2, -5 + Math.floor(i / 6) * 4.6, 1.9, CC[i % CC.length], { sy: 0.6, k: 3, n: 8 })));
      [[8, 12], [11, 7], [4, 16], [-24, 13]].forEach(([x, z], i) => o.push(ball(x, 0, z, 1.9, CC[(i + 2) % CC.length], { sy: 0.6, k: 3, n: 8 })));
      const gx = 20, gz = 8; o.push(slab(gx, 2.2, gz, 20, 7, 0.8, '#f5f2ea', PL({ r: 1.6 })), slab(gx - 5, 3.4, gz + 0.5, 7, 4.6, 0.3, '#ff4a5a', { r: 1.4, op: 0.85, noOut: 1, shine: 1 }), slab(gx + 5, 3.4, gz + 0.5, 7, 4.6, 0.3, '#3fd0ff', { r: 1.4, op: 0.85, noOut: 1, shine: 1 }));
      [-1, 1].forEach(sg => o.push(tilt(box(gx + sg * 9.6, 0, gz - 8, 0.8, 3.4, 16, '#f5f2ea', PL({ r: 0.4 })), [1, 0, 0], 0.05, [gx, 0, gz])));
      return o; },
    fx: c => ({ front: '<g transform="' + frame(c.p, rotF([1, 0, 0], -0.4)([0, 6.2, 0.9]).map((v, i) => v + [-10, 8, -9][i]), [1, 0, 0], rotF([1, 0, 0], -0.4)([0, -1, 0])) + '"><text x="0" y="1.4" text-anchor="middle" ' + FONT + ' font-size="4" fill="#ffffff" stroke="#7a1a1e" stroke-width="0.3" paint-order="stroke">CANDY</text></g>' }) });

  // ======================= MOV-028 POPCORN BUCKET (overflowing, ticket stubs) =======================
  N.pop17 = S => ({ w: 56, d: 46, small: 1, build: () => { const o = [], RED = '#d9363b', R = R0('pop');
      o.push(cyl(0, 0, 0, 12, 24, '#fbf6ec', PL({ n: 22, rg: [[0, 0, 0.8], [24, 0, 1]], r: 15 })));
      o.push(arcW(0, 23, 0, 12.6, 12.6, 1.6, 1.8, 0, 2 * PI, '#ffffff', PL({ n: 22 })));
      rep(30, i => { const a = R() * 2 * PI, rr = Math.sqrt(R()) * 11, h = 24 + (1 - (rr / 11) * (rr / 11)) * 9 + R() * 2; kern(Math.cos(a) * rr, h - 2, Math.sin(a) * rr, 2.3, i).forEach(s => o.push(s)); });
      rep(4, i => o.push(ball((R() - 0.5) * 10, 30 + R() * 4, (R() - 0.2) * 8, 1.2, '#ffd34a', { k: 3, n: 8 })));
      [[16, 0, 12], [-15, 0, 14], [19, 0, -2]].forEach(([x, y, z], i) => kern(x, y, z, 2, i).forEach(s => o.push(s)));
      [[18, 12, 0.4, '#f2932c'], [24, 4, -0.3, '#ffd66b']].forEach(([x, z, yw, col]) => o.push(box(x, 0, z, 15, 0.6, 7, col, PL({ yaw: yw, r: 0.6 })), box(x - 4.4 * Math.cos(yw), 0.6, z - 4.4 * Math.sin(yw), 0.4, 0.15, 6.4, '#ffffff', { yaw: yw, r: 0, noOut: 1 })));
      return o; },
    // printed red stripes + curved POP label wrapped on the round bucket (front-facing part only, shaded across the curve)
    fx: c => { const k = c.k, rA = y => 12 * (0.8 + 0.2 * y / 24) + 0.15, P = (t, y, dr) => { const r = rA(y) + (dr || 0); return c.p(Math.cos(t) * r, y, Math.sin(t) * r); };
      const fac = t => P(t, 12, 2)[1] - P(t, 12)[1] > 0.02 * k, Y0 = 0.7, Y1 = 22.9, st = PI / 96, vis = [];
      for (let t = 0; t < 2 * PI; t += st) if (fac(t)) vis.push(t); if (!vis.length) return {};
      const xs = vis.map(t => P(t, 12)[0]), x0 = Math.min(...xs), x1 = Math.max(...xs), U = t => (P(t, 12)[0] - x0) / Math.max(1e-3, x1 - x0);
      const band = ts => ts.length < 2 ? '' : 'M' + ts.map(t => P2(P(t, Y0))).join('L') + 'L' + ts.slice().reverse().map(t => P2(P(t, Y1))).join('L') + 'Z';
      const inV = (a, b) => { const r = []; for (let t = a; t <= b + 1e-6; t += st / 2) { const tt = ((t % (2 * PI)) + 2 * PI) % (2 * PI); if (fac(tt)) r.push(t); } return r; };
      let red = ''; rep(8, s => { const a = PI / 16 + s * PI / 4; red += band(inV(a, a + PI / 8)); });
      const hl = band(vis.filter(t => { const u = U(t); return u > 0.2 && u < 0.3; }).sort((a, b) => a - b));
      let f = '<defs><linearGradient id="p17pk" gradientUnits="userSpaceOnUse" x1="' + f1(x0) + '" y1="0" x2="' + f1(x1) + '" y2="0"><stop offset="0" stop-color="#f0574c"/><stop offset="0.3" stop-color="#e2403b"/><stop offset="0.75" stop-color="#c62a2d"/><stop offset="1" stop-color="#9c1d24"/></linearGradient></defs>';
      f += '<path d="' + red + '" fill="url(#p17pk)"/>' + (hl ? '<path d="' + hl + '" fill="#ffffff" opacity="0.22"/>' : '');
      if (fac(PI / 2)) { const ts = []; for (let t = PI / 2 - 0.44; t <= PI / 2 + 0.44; t += 0.04) ts.push(t);
        f += '<path d="M' + ts.map(t => P2(P(t, 9.4, 0.1))).join('L') + 'L' + ts.slice().reverse().map(t => P2(P(t, 17.4, 0.1))).join('L') + 'Z" fill="#ffd23f" stroke="#c8202a" stroke-width="' + f1(0.5 * k) + '" stroke-linejoin="round"/>'
          + '<g transform="' + frame(c.p, [0, 13.4, rA(13.4) + 0.3], [1, 0, 0], [0, -1, 0]) + '"><text x="0" y="1.3" text-anchor="middle" ' + FONT + ' font-size="3.6" fill="#c8202a">POP</text></g>'; }
      return { front: f }; } });

  // ======================= MOV-048 DIRECTOR KIT (clapperboard claps, megaphone) =======================
  const slTilt = rotF([1, 0, 0], -0.22), SLP = [-6, 0, 0], slAt = v => slTilt(v).map((a, i) => a + SLP[i]);
  N.director17 = S => ({ w: 70, d: 40, small: 1, build: () => { const o = [], RED = '#d9363b';
      o.push(box(-6, 0, 4, 22, 2, 12, '#4a3a2a', W_({ r: 1 })));
      tiltAll([slab(-6, 0, 0, 30, 21, 2, '#1d1d21', PL({ r: 1.2 })), slab(-6, 19.2, 0, 30, 2.6, 2.2, '#f4f4f4', PL({ r: 0.6 }))], [1, 0, 0], -0.22, SLP).forEach(s => o.push(s));
      const mg = [solid(PL({ ax: 'x', sh: 'el', c: [0, 7], a: 2.6, b: 2.6, n: 16, rings: [[12, 0, 1], [16, 0, 1.3], [30, 0, 2.5], [31, 0, 2.7]], col: RED })), solid(PL({ ax: 'x', sh: 'el', c: [0, 7], a: 7.4, b: 7.4, n: 18, rings: [[30.4, 0, 1], [32.2, 0, 1]], col: '#ffffff' })), solid(PL({ ax: 'x', sh: 'el', c: [0, 7], a: 2.2, b: 2.2, n: 12, rings: [[8, 0, 1], [12, 0, 1]], col: '#26272b' })), box(19, 0.8, 0, 3, 4.4, 2.4, '#26272b', PL({ r: 0.8 })), solid(PL({ ax: 'x', sh: 'el', c: [0, 7], a: 6.2, b: 6.2, n: 18, rings: [[32.3, 0, 1], [32.5, 0, 1]], col: '#3a3b40', noOut: 1 }))];
      tiltAll(mg, [0, 1, 0], -0.5, [20, 0, 0]).forEach(s => o.push(xf(s, v => v, null, [-2, 0, 12])));
      return o; },
    layers: [{ build: () => { const L = [box(-6, 21.8, 0, 30, 3.4, 2.2, '#1d1d21', PL({ r: 0.6 }))]; rep(5, i => L.push(tilt(box(-17 + i * 5.6, 22, 1.15, 2.6, 3, 0.2, '#f4f4f4', { r: 0, noOut: 1 }), [0, 0, 1], 0.6, [-17 + i * 5.6, 23.5, 1.15]))); return tiltAll(L, [1, 0, 0], -0.22, SLP); },
      wrap: (p, s) => { const h = slAt([-20.6, 21.8, 0]), q = p(h[0], h[1], h[2]); return '<g transform="translate(' + P2(q) + ')"><g><animateTransform attributeName="transform" type="rotate" values="0;-24;-24;0;0" keyTimes="0;0.18;0.62;0.68;1" dur="2.8s" calcMode="spline" keySplines="0.3 0 0.4 1;0 0 1 1;0.7 0 1 1;0 0 1 1" repeatCount="indefinite"/><g transform="translate(' + f1(-q[0]) + ' ' + f1(-q[1]) + ')">' + s + '</g></g></g>'; } }],
    fx: c => { const O = slAt([-6, 14, 1.15]), M = frame(c.p, O, slTilt([1, 0, 0]), slTilt([0, -1, 0])), h = slAt([-6, 24, 1.4]), q = c.p(h[0], h[1], h[2]), k = c.k;
      const pop = rep(5, i => { const a = -PI * (0.15 + i * 0.17); return '<path d="M' + f1(q[0] + Math.cos(a) * 18 * k) + ' ' + f1(q[1] + Math.sin(a) * 9 * k) + 'l' + f1(Math.cos(a) * 4 * k) + ' ' + f1(Math.sin(a) * 4 * k) + '" stroke="#ffd23f" stroke-width="' + f1(0.9 * k) + '" stroke-linecap="round" opacity="0"><animate attributeName="opacity" values="0;0;1;0;0" keyTimes="0;0.67;0.7;0.82;1" dur="2.8s" repeatCount="indefinite"/></path>'; }).join('');
      return { front: '<g transform="' + M + '" fill="none" stroke="#f4f4f4" stroke-width="0.35" stroke-linecap="round"><path d="M-13 -5H13M-13 1H13M0 -5V7"/><text x="-12" y="-1.4" ' + FONT + ' font-size="2.6" fill="#f4f4f4" stroke="none">SCENE 1</text><text x="1.4" y="-1.4" ' + FONT + ' font-size="2.6" fill="#f4f4f4" stroke="none">TAKE 3</text><text x="-12" y="5" ' + FONT + ' font-size="2.4" fill="#f4f4f4" stroke="none">SQUISH</text><text x="1.4" y="5" ' + FONT + ' font-size="2.4" fill="#f4f4f4" stroke="none">MOVIE</text></g>' + pop }; } });

  // ======================= MOV-068 GOLD TROPHY (star on a film reel + crystal decanter) =======================
  // gold loving cup with handles, a film-strip band and a lidded top crowned by a bevelled star; crystal decanter + glass beside it
  const TX = -8, STY = 46;
  N.trophy17 = S => ({ w: 58, d: 40, small: 1, build: () => { const o = [], BLK = '#24202a', GD = shade(GOLD, 0.8), GL = shade(GOLD, 1.16), GLS = '#e6f4fb', AMB = '#c26a1e';
      o.push(box(TX, 0, 0, 20, 5, 18, BLK, { r: 1.6, bev: 1, mat: 'cer' }), box(TX, 5, 0, 15, 4, 13, BLK, { r: 1.4, bev: 0.8, mat: 'cer' }), box(TX, 1.2, 9.05, 12, 2.6, 0.4, GOLD, M_({ r: 0.5, noOut: 1 })));
      o.push(cyl(TX, 9, 0, 5.4, 2, GOLD, M_({ n: 18, rg: [[0, 0, 1], [0.9, 0, 1], [2, 0, 0.62]] })), cyl(TX, 10.8, 0, 1.7, 5, GD, M_({ n: 12 })), ball(TX, 12.2, 0, 2.6, GOLD, M_({ k: 4, n: 12, sy: 0.8 })));
      o.push(cyl(TX, 16, 0, 9, 15, GOLD, G_({ mat: 'metal', n: 24, rg: [[0, 0, 0.2], [2, 0, 0.52], [5, 0, 0.78], [9, 0, 0.94], [13, 0, 1], [15, 0, 1.04]] })));
      o.push(cyl(TX, 30.6, 0, 9.8, 1.4, GL, M_({ n: 24 })), ball(TX, 31.8, 0, 8.6, GOLD, M_({ sy: 0.42, k: 5, n: 22 })), cyl(TX, 35.2, 0, 1.4, 3.6, GD, M_({ n: 10 })), ball(TX, 37.8, 0, 2, GL, M_({ k: 4, n: 10 })));
      const DX = 15, DZ = -7;
      o.push(box(DX, 0, DZ, 11, 9.6, 11, AMB, { r: 1.8, bev: 1, op: 0.9, mat: 'pl' }), box(DX, 0, DZ, 12, 15, 12, GLS, G_({ r: 2.4, bev: 3.4, op: 0.48 })));
      o.push(cyl(DX, 15, DZ, 2.2, 4.4, GLS, G_({ n: 12, op: 0.6 })), cyl(DX, 19, DZ, 3, 1, GLS, G_({ n: 12, op: 0.7 })), ball(DX, 19.8, DZ, 3.4, GLS, G_({ k: 2, n: 8, sy: 1.15, op: 0.8 })));
      o.push(cyl(DX + 4, 0, 10, 3.2, 3.4, AMB, { n: 14, op: 0.9, mat: 'pl' }), box(DX + 4, 2.4, 10, 2.4, 2.4, 2.4, '#f4fbff', { r: 0.5, op: 0.9, yaw: 0.4 }), cyl(DX + 4, 0, 10, 3.7, 6.4, GLS, G_({ n: 16, op: 0.45 })));
      return o; },
    fx: c => { const q = c.p(TX, STY, 0), k = c.k, R1 = 7.6 * k, R2 = 3.1 * k, T = rep(5, i => { const a = -PI / 2 + i * 2 * PI / 5; return [q[0] + Math.cos(a) * R1, q[1] + Math.sin(a) * R1]; }), V = rep(5, i => { const a = -PI / 2 + PI / 5 + i * 2 * PI / 5; return [q[0] + Math.cos(a) * R2, q[1] + Math.sin(a) * R2]; });
      const pt = p => f1(p[0]) + ' ' + f1(p[1]), outl = rep(5, i => pt(T[i]) + 'L' + pt(V[i])).join('L'), back = rep(5, i => pt([T[i][0] + 0.9 * k, T[i][1] + 1.1 * k]) + 'L' + pt([V[i][0] + 0.9 * k, V[i][1] + 1.1 * k])).join('L');
      let fac = ''; rep(5, i => { const a = -PI / 2 + i * 2 * PI / 5; [[V[(i + 4) % 5], a - 0.32], [V[i], a + 0.32]].forEach(([v, m]) => { const l = 0.5 - 0.5 * (Math.cos(m) * 0.6 + Math.sin(m) * 0.8), col = mix('#b8801a', '#fff3b0', l); fac += '<path d="M' + pt(q) + 'L' + pt(T[i]) + 'L' + pt(v) + 'Z" fill="' + col + '"/>'; }); });
      const stem = c.p(TX, 39.6, 0), o0 = c.p(0, 0, 0), e1 = c.p(1, 0, 0), sT = -(e1[1] - o0[1]) / (k * X.SA);
      // smooth gold handles (stroked tubes: dark rim, gold body, light glint); the far one goes behind the cup
      const hd = sg => { const P = [[8.2, 28.4], [12.6, 29.6], [15, 26.2], [13.4, 21.2], [7.4, 18.6]].map(([x, y]) => c.p(TX + sg * x, y, 0)); P.forEach(p => hb.push(p)); let d = 'M' + pt(P[0]);
        for (let i = 0; i < P.length - 1; i++) { const a = P[Math.max(0, i - 1)], b = P[i], e = P[i + 1], f = P[Math.min(P.length - 1, i + 2)]; d += 'C' + pt([b[0] + (e[0] - a[0]) / 6, b[1] + (e[1] - a[1]) / 6]) + ' ' + pt([e[0] - (f[0] - b[0]) / 6, e[1] - (f[1] - b[1]) / 6]) + ' ' + pt(e); }
        return '<g fill="none" stroke-linecap="round"><path d="' + d + '" stroke="#7a5410" stroke-width="' + f1(3.6 * k) + '"/><path d="' + d + '" stroke="' + GOLD + '" stroke-width="' + f1(2.3 * k) + '"/><path d="' + d + '" stroke="#fff3b0" stroke-opacity="0.8" stroke-width="' + f1(0.7 * k) + '" transform="translate(' + f1(-0.4 * k) + ' ' + f1(-0.5 * k) + ')"/></g>'; };
      const nearR = -sT > 0, hb = [[q[0] - R1 - 2 * k, q[1] - R1 - 3 * k], [q[0] + R1 + 4 * k, q[1]]], hB = hd(nearR ? -1 : 1), hF = hd(nearR ? 1 : -1), bb = [Math.min(...hb.map(p => p[0])) - 3 * k, Math.min(...hb.map(p => p[1])) - 3 * k, Math.max(...hb.map(p => p[0])) + 3 * k, Math.max(...hb.map(p => p[1])) + 3 * k];
      // film-strip band wrapped round the front of the cup, with sprocket holes
      const cT = (e1[0] - o0[0]) / k, ac = Math.atan2(cT, -sT), N2 = 24, ON = (a, y, r) => c.p(TX + Math.cos(a) * r, y, Math.sin(a) * r);
      const top = rep(N2 + 1, i => ON(ac - PI / 2 + i * PI / N2, 27, 8.9)), bot = rep(N2 + 1, i => ON(ac + PI / 2 - i * PI / N2, 23.6, 8.1));
      let holes = ''; rep(13, i => { const a = ac - PI / 2 + (i + 0.5) * PI / 13, w = Math.cos(a - ac); if (w < 0.25) return; [[24.4, 8.3], [26.2, 8.75]].forEach(([y, r]) => { const p = ON(a, y, r); holes += '<rect x="' + f1(p[0] - 0.45 * k * w) + '" y="' + f1(p[1] - 0.35 * k) + '" width="' + f1(0.9 * k * w) + '" height="' + f1(0.7 * k) + '" rx="' + f1(0.15 * k) + '" fill="#f4efe2"/>'; }); });
      const band = '<path d="M' + top.concat(bot).map(pt).join('L') + 'Z" fill="#2b2a30" stroke="#121116" stroke-width="' + f1(0.6 * k) + '" stroke-linejoin="round"/><path d="M' + top.map(pt).join('L') + '" fill="none" stroke="#ffffff" stroke-opacity="0.25" stroke-width="' + f1(0.4 * k) + '" transform="translate(0 ' + f1(0.5 * k) + ')"/>' + holes;
      return { bb, back: hB, front: band + hF + '<path d="M' + pt(stem) + 'L' + pt([q[0], q[1] + R2 * 0.6]) + '" stroke="#b8801a" stroke-width="' + f1(1.4 * k) + '"/><path d="M' + back + 'Z" fill="#7a5410" stroke="#5e400a" stroke-width="' + f1(0.6 * k) + '" stroke-linejoin="round"/>' + fac
        + '<path d="M' + outl + 'Z" fill="none" stroke="#7a5410" stroke-width="' + f1(0.7 * k) + '" stroke-linejoin="round"/><circle cx="' + f1(q[0] - 1.4 * k) + '" cy="' + f1(q[1] - 1.6 * k) + '" r="' + f1(0.9 * k) + '" fill="#ffffff" opacity="0.85"/>'
        + rep(5, i => spark(c, TX + [-11, 10, -13, 13, 2][i], [50, 44, 27, 20, 56][i], 0, 0.6, -i * 0.38, '#fff6c8')).join('') }; } });

  // ======================= MOV-088 HOLO MASCOT (projector puck + waving hologram buddy) =======================
  N.mascot17 = S => ({ w: 36, d: 36, small: 1, build: () => { const o = [];
      o.push(cyl(0, 0, 0, 10, 4, '#2c2e36', M_({ n: 20, rg: [[0, 0, 1], [3, 0, 1], [4, 0, 0.86]] })), cyl(0, 4, 0, 5, 0.5, '#7ff0ff', em({ n: 16 })), arcW(0, 4, 0, 8.4, 8.4, 0.6, 0.3, 0, 2 * PI, '#7ff0ff', em({ n: 20 })));
      rep(3, i => o.push(box(-3 + i * 3, 1.6, 9.7, 1.6, 0.9, 0.3, ['#7dff9e', '#7ff0ff', '#ff6fae'][i], em({ r: 0.4 }))));
      return o; },
    fx: c => { const k = c.k, b = c.p(0, 4.6, 0), q = c.p(0, 22, 0), u = k;
      const body = '<ellipse cx="0" cy="2" rx="' + f1(7 * u) + '" ry="' + f1(6.4 * u) + '"/><circle cx="' + f1(-4.6 * u) + '" cy="' + f1(-4 * u) + '" r="' + f1(2.4 * u) + '"/><circle cx="' + f1(4.6 * u) + '" cy="' + f1(-4 * u) + '" r="' + f1(2.4 * u) + '"/>';
      const arm = '<g><animateTransform attributeName="transform" type="rotate" values="0 ' + f1(6 * u) + ' ' + f1(2 * u) + ';-40 ' + f1(6 * u) + ' ' + f1(2 * u) + ';0 ' + f1(6 * u) + ' ' + f1(2 * u) + '" dur="1.2s" repeatCount="indefinite"/><ellipse cx="' + f1(8.6 * u) + '" cy="' + f1(0.6 * u) + '" rx="' + f1(2.6 * u) + '" ry="' + f1(1.6 * u) + '"/></g>';
      return { front: '<defs><linearGradient id="p17mb" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#8ff6ff" stop-opacity="0.55"/><stop offset="1" stop-color="#8ff6ff" stop-opacity="0"/></linearGradient><pattern id="p17ms" width="4" height="1.4" patternUnits="userSpaceOnUse"><rect width="4" height="0.6" fill="#ffffff" opacity="0.4"/></pattern></defs>'
        + '<path d="M' + f1(b[0] - 4 * k) + ' ' + f1(b[1]) + 'L' + f1(q[0] - 11 * k) + ' ' + f1(q[1] - 10 * k) + 'H' + f1(q[0] + 11 * k) + 'L' + f1(b[0] + 4 * k) + ' ' + f1(b[1]) + 'Z" fill="url(#p17mb)">' + an('opacity', '0.6;1;0.7;0.95;0.6', 2.2) + '</path>'
        + '<g transform="translate(' + P2(q) + ')"><g>' + '<animateTransform attributeName="transform" type="translate" values="0 0;0 ' + f1(-1.6 * k) + ';0 0" dur="2s" repeatCount="indefinite"/>' + an('opacity', '0.9;0.95;0.55;0.95;0.9', 1.9)
        + '<g fill="#8ff6ff" fill-opacity="0.55" stroke="#dffcff" stroke-width="' + f1(0.45 * u) + '">' + body + arm + '</g><g fill="url(#p17ms)">' + body + '</g>'
        + '<g fill="#0d3a4a"><ellipse cx="' + f1(-2.4 * u) + '" cy="' + f1(1 * u) + '" rx="' + f1(1 * u) + '" ry="' + f1(1.3 * u) + '"/><ellipse cx="' + f1(2.4 * u) + '" cy="' + f1(1 * u) + '" rx="' + f1(1 * u) + '" ry="' + f1(1.3 * u) + '"/></g><path d="M' + f1(-1.4 * u) + ' ' + f1(3.6 * u) + 'Q0 ' + f1(5 * u) + ' ' + f1(1.4 * u) + ' ' + f1(3.6 * u) + '" stroke="#0d3a4a" stroke-width="' + f1(0.5 * u) + '" fill="none" stroke-linecap="round"/></g></g>' }; } });

  // ---------- catalog edits ----------
  RD.SET17 = {
    'MOV-003': { spec: 'crate17', note: 'Two blue milk crates turned upside down with a crooked plywood board on top. A pizza box, a can of soda and a crumpled napkin sit on it.' },
    'MOV-023': { spec: 'lift17', note: 'A white coffee table whose oak top lifts up and back toward the sofa on chrome scissor arms, opening a storage well packed with movies. A bowl of chips, a soda and the remote wait on the raised top.' },
    'MOV-043': { spec: 'glass17', note: 'A black steel table with a smoked glass top and a glass shelf underneath holding movie cases and a game controller. A candy bowl, a little plant and two coasters on top.' },
    'MOV-063': { spec: 'fridgeT17', live: 'Chilled', note: 'A charcoal coffee table with two lit glass fridge drawers full of cold cans (a little cold mist drifts out), a wireless charging pad with a phone that pulses, and a bowl of popcorn.' },
    'MOV-083': { spec: 'holoT17', live: 'Hologram', note: 'A round white table on a glowing pedestal, with touch lights round the glass top and a spinning film-reel hologram beaming up from the middle.' },
    'MOV-007': { spec: 'tray17', note: 'A mustard folding TV tray with flower prints on gold legs, holding a TV dinner: mashed potato, peas, nuggets and a fork.' },
    'MOV-047': { spec: 'ctable17', note: 'A brass C-shaped side table that slides under the sofa, with a round walnut top, a cola on ice and a bowl of popcorn.' },
    'MOV-067': { spec: 'marbleT17', live: 'Chilled coaster', note: 'A white marble table on a fluted gold pedestal. Its blue glowing coaster keeps a frosty soda with ice and lemon ice-cold, with little puffs of cold rising.' },
    'MOV-087': { spec: 'bot17', live: 'Rolls around', note: 'A round little robot butler on glowing wheels. It blinks, flashes its antenna and carries a tray with a soda and popcorn.' },
    'MOV-017': { spec: 'brick17', note: 'Grey cinder blocks and pine boards stacked into a shelf, full of VHS tapes (one has tipped over), a plant in a tin can, a SQUISH tape box and an old tape player.' },
    'MOV-037': { spec: 'dvd17', note: 'A tall wire tower with four round racks of colourful DVDs all the way round, topped with a red knob.' },
    'MOV-057': { spec: 'console17', note: 'A low walnut media console on splayed legs, with slatted doors, two drawers with brass pulls, and a plant, a record and a stack of movies on top.' },
    'MOV-077': { spec: 'vault17', live: 'Glass glare', note: 'A tall black cabinet with glass doors and lit glass shelves full of shiny metal movie cases, gold handles and a glowing keypad lock.' },
    'MOV-097': { spec: 'holoLib17', live: 'Orbiting covers', note: 'A white pedestal that beams up a hologram library: two rings of glowing movie covers orbit round it and a play button spins on top.' },
    'MOV-008': { spec: 'candy17', note: 'An open box of colourful candy with its lid flipped up (a few pieces spilled) and a pair of red-and-blue 3D glasses.' },
    'MOV-028': { spec: 'pop17', note: 'A red-and-white striped bucket overflowing with buttery popcorn, with a few pieces dropped and two ticket stubs.' },
    'MOV-048': { spec: 'director17', live: 'Clapping', note: 'A movie clapperboard (SCENE 1, TAKE 3) that keeps snapping shut with a clap, next to a red director megaphone.' },
    'MOV-068': { spec: 'trophy17', live: 'Sparkles', note: 'A shiny gold award cup with curly handles, a film-strip band and a bevelled gold star on its lid, on a black base with a gold plate, next to a crystal decanter and a glass.' },
    'MOV-088': { spec: 'mascot17', live: 'Hologram', note: 'A little projector puck that beams up a waving hologram buddy.' },
  };
  const edit16 = RD.edit;
  RD.edit = rows => edit16(rows).map(r => RD.SET17[r.id] ? Object.assign({}, r, RD.SET17[r.id]) : r);
  RD.PLUS17 = 1;
})();
