/* Plush skin: restyles flat outlined crib art to match the creatures' look
   (radial shading lit from top-left, darker edges, soft same-hue outlines, gloss, fine grain).
   PlushSkin.svgStr(w,h,inner) skins an SVG string; any element with [data-plush-skin] is skinned live in the DOM. */
(function () {
  const NS = 'http://www.w3.org/2000/svg';
  const OUT_HEX = new Set(['#8e1580', '#2a1430', '#140818']);
  const OUT_RGB = ['rgb(142, 21, 128)', 'rgb(42, 20, 48)', 'rgb(20, 8, 24)'];
  const SOFT = 'rgba(120, 40, 125, 0.45)';
  const W = [255, 255, 255], P = [70, 14, 90];
  const hx = c => { c = (c || '').trim().toLowerCase(); if (c[0] !== '#') return null; if (c.length === 4) c = '#' + c[1] + c[1] + c[2] + c[2] + c[3] + c[3]; if (c.length !== 7) return null; return [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16)); };
  const rgba = s => { const m = /rgba?\(([^)]+)\)/.exec(s || ''); if (!m) return null; const p = m[1].split(',').map(parseFloat); return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1]; };
  const toHex = a => '#' + a.slice(0, 3).map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
  const mix = (a, b, t) => a.slice(0, 3).map((v, i) => v + (b[i] - v) * t);
  const lum = c => (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]) / 255;
  const light = c => toHex(mix(c, W, lum(c) < 0.3 ? 0.22 : 0.5));
  const dark = c => toHex(mix(c, P, 0.2));
  const edge = c => toHex(mix(c, P, 0.4));
  const hasOut = s => OUT_RGB.some(c => s.indexOf(c) >= 0);
  const repOut = (s, r) => OUT_RGB.reduce((a, c) => a.split(c).join(r), s);
  let uid = 0;
  const GLOSSED = new WeakSet();

  function grainFilter(doc, id) {
    const f = doc.createElementNS(NS, 'filter');
    f.setAttribute('id', id); f.setAttribute('x', '-5%'); f.setAttribute('y', '-5%'); f.setAttribute('width', '110%'); f.setAttribute('height', '110%');
    f.innerHTML = '<feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="7"/><feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.2 0"/><feComposite in2="SourceGraphic" operator="in"/><feBlend in="SourceGraphic" mode="multiply"/>';
    return f;
  }

  function skinSvg(svg, doc, wrap) {
    if (!svg.__pk) {
      svg.__pk = { pre: 'pk' + (++uid) + '_', g: {}, n: 0, defs: null };
      const d = doc.createElementNS(NS, 'defs'); svg.appendChild(d); svg.__pk.defs = d;
    }
    const K = svg.__pk;
    const grad = (rgb) => {
      const key = toHex(rgb); if (K.g[key]) return K.g[key];
      const id = K.pre + (K.n++), g = doc.createElementNS(NS, 'radialGradient');
      g.setAttribute('id', id); g.setAttribute('cx', '38%'); g.setAttribute('cy', '30%'); g.setAttribute('r', '75%');
      [[0, light(rgb)], [0.6, key], [1, dark(rgb)]].forEach(([o, c]) => { const s = doc.createElementNS(NS, 'stop'); s.setAttribute('offset', o); s.setAttribute('stop-color', c); g.appendChild(s); });
      K.defs.appendChild(g); return (K.g[key] = id);
    };
    let shaded = 0;
    svg.querySelectorAll('rect,circle,ellipse,path,polygon,polyline,line').forEach(el => {
      if (el.closest('defs,clipPath,mask,pattern,filter') || el.hasAttribute('data-pk-gloss')) return;
      const fr = hx(el.getAttribute('fill'));
      const st = (el.getAttribute('stroke') || '').trim().toLowerCase();
      const sw = parseFloat(el.getAttribute('stroke-width') || '1');
      const op = parseFloat(el.getAttribute('opacity') || '1');
      const tag = el.tagName.toLowerCase();
      if (fr && op > 0.5 && tag !== 'line' && tag !== 'polyline') { el.setAttribute('fill', 'url(#' + grad(fr) + ')'); shaded++; }
      if (OUT_HEX.has(st)) {
        if (fr) { el.setAttribute('stroke', edge(fr)); el.setAttribute('stroke-width', String(Math.max(1, +(sw * 0.55).toFixed(2)))); }
        else { el.setAttribute('stroke', sw >= 4 ? '#b268ac' : SOFT); el.setAttribute('stroke-width', String(+(sw * (sw >= 4 ? 1 : 0.75)).toFixed(2))); }
      }
      if (fr && op > 0.5 && !GLOSSED.has(el)) {
        GLOSSED.add(el);
        const n = a => parseFloat(el.getAttribute(a) || '0');
        let gx, gy, rx, ry;
        if (tag === 'rect') { const w = n('width'), h = n('height'); if (w >= 22 && h >= 14) { gx = n('x') + w * 0.26; gy = n('y') + h * 0.28; rx = Math.min(w * 0.14, 22); ry = Math.min(h * 0.16, 11); } }
        else if (tag === 'circle') { const r = n('r'); if (r >= 9) { gx = n('cx') - r * 0.36; gy = n('cy') - r * 0.4; rx = r * 0.3; ry = r * 0.2; } }
        else if (tag === 'ellipse') { const a = n('rx'), b = n('ry'); if (a >= 9 && b >= 6) { gx = n('cx') - a * 0.36; gy = n('cy') - b * 0.42; rx = a * 0.3; ry = b * 0.22; } }
        if (gx != null) {
          const g = doc.createElementNS(NS, 'ellipse');
          g.setAttribute('data-pk-gloss', '1');
          g.setAttribute('cx', gx.toFixed(1)); g.setAttribute('cy', gy.toFixed(1)); g.setAttribute('rx', rx.toFixed(1)); g.setAttribute('ry', ry.toFixed(1));
          g.setAttribute('fill', '#ffffff'); g.setAttribute('opacity', lum(fr) < 0.2 ? '0.14' : '0.32');
          g.setAttribute('pointer-events', 'none');
          const tf = el.getAttribute('transform'); if (tf) g.setAttribute('transform', tf);
          if (el.nextSibling) el.parentNode.insertBefore(g, el.nextSibling); else el.parentNode.appendChild(g);
        }
      }
    });
    if (wrap && shaded) {
      const fid = K.pre + 'gr'; K.defs.appendChild(grainFilter(doc, fid));
      const g = doc.createElementNS(NS, 'g'); g.setAttribute('filter', 'url(#' + fid + ')');
      Array.from(svg.childNodes).forEach(c => { if (c !== K.defs) g.appendChild(c); });
      svg.appendChild(g);
    }
  }

  function svgStr(w, h, inner) {
    try {
      const doc = new DOMParser().parseFromString('<svg xmlns="' + NS + '" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ' + w + ' ' + h + '">' + inner + '</svg>', 'image/svg+xml');
      const svg = doc.documentElement; if (!svg || svg.querySelector('parsererror')) return null;
      skinSvg(svg, doc, true);
      return new XMLSerializer().serializeToString(svg);
    } catch (e) { return null; }
  }

  /* ---------- live DOM ---------- */
  const SIDES = ['Top', 'Right', 'Bottom', 'Left'];
  const SHADED = new WeakSet();
  function skinEl(el) {
    if (!el || el.nodeType !== 1 || !el.isConnected) return;
    if (el instanceof SVGElement) { const svg = el.tagName.toLowerCase() === 'svg' ? el : el.ownerSVGElement; if (svg) skinSvg(svg, document, false); return; }
    if (el.tagName === 'IMG' || el.hasAttribute('data-plush-overlay') || el.closest('[data-plush-skip]')) return;
    const cs = getComputedStyle(el);
    const bgA = rgba(cs.backgroundColor), bg = bgA && bgA[3] > 0.5 ? bgA : null;
    const ed = bg ? edge(bg) : SOFT;
    let had = false;
    SIDES.forEach(sd => { if (parseFloat(cs['border' + sd + 'Width']) > 0 && OUT_RGB.indexOf(cs['border' + sd + 'Color']) >= 0) { el.style['border' + sd + 'Color'] = ed; had = true; } });
    let bs = cs.boxShadow && cs.boxShadow !== 'none' ? cs.boxShadow : '';
    if (bs && hasOut(bs)) { bs = repOut(bs, ed); had = true; el.style.boxShadow = bs; }
    const bi = cs.backgroundImage;
    if (bi && bi !== 'none' && hasOut(bi)) el.style.backgroundImage = repOut(bi, 'rgb(200, 128, 190)');
    const ts = cs.textShadow; if (ts && ts !== 'none' && hasOut(ts)) el.style.textShadow = repOut(ts, 'rgba(150, 50, 140, 0.8)');
    if (!SHADED.has(el)) {
      SHADED.add(el);
      const w = el.offsetWidth, h = el.offsetHeight;
      if (w >= 10 && h >= 6 && w <= 340 && h <= 300 && cs.mixBlendMode === 'normal' && (bg || (bi !== 'none' && (had || parseFloat(cs.borderTopWidth) > 0)))) {
        const s = Math.max(2, Math.min(w, h) * 0.2), f = v => v.toFixed(1) + 'px';
        const sh = 'inset ' + f(s * 0.45) + ' ' + f(s * 0.55) + ' ' + f(s * 0.9) + ' rgba(255,255,255,0.5), inset ' + f(-s * 0.5) + ' ' + f(-s * 0.7) + ' ' + f(s * 1.2) + ' rgba(70,14,90,0.24)';
        el.style.boxShadow = sh + (bs ? ', ' + bs : '');
      }
    }
  }
  function skinTree(root) {
    if (root.nodeType !== 1) return;
    skinEl(root);
    root.querySelectorAll('*').forEach(el => { if (el instanceof SVGElement && el.tagName.toLowerCase() !== 'svg') return; skinEl(el); });
  }

  const ROOTS = new WeakSet();
  let pend = new Set(), raf = 0;
  const flush = () => { raf = 0; const p = pend; pend = new Set(); p.forEach(n => { try { skinTree(n); } catch (e) { console.warn('plush-skin', e && e.message); } }); };
  const queue = n => { pend.add(n); if (!raf) raf = setTimeout(flush, 30); };
  function attach(root) {
    if (ROOTS.has(root)) return; ROOTS.add(root);
    queue(root);
    new MutationObserver(ms => ms.forEach(m => {
      if (m.type === 'childList') m.addedNodes.forEach(n => { if (n.nodeType === 1) queue(n); });
      else if (m.target.nodeType === 1) queue(m.target);
    })).observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'fill'] });
  }
  function scan(n) { if (n.nodeType !== 1) return; if (n.hasAttribute('data-plush-skin')) attach(n); n.querySelectorAll('[data-plush-skin]').forEach(attach); }
  function boot() {
    scan(document.body);
    new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(scan))).observe(document.body, { childList: true, subtree: true });
  }
  if (document.body) boot(); else document.addEventListener('DOMContentLoaded', boot);

  const NOISE = 'url("data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220"><filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" stitchTiles="stitch"/><feColorMatrix values="0 0 0 0 0.28  0 0 0 0 0.08  0 0 0 0 0.34  0 0 0 0.42 0"/></filter><rect width="100%" height="100%" filter="url(#n)"/></svg>') + '")';
  window.PlushSkin = { svgStr, skinTree, NOISE };
})();
