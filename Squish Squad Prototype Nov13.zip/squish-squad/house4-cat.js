// Squad House v4 catalog: 6 theme bands x 5 levels x 8 items = 240 pieces (furniture + room surfaces).
(function boot() {
  const X = window.House3D; if (!(X && X.K)) { setTimeout(boot, 20); return; } if (X.ITEMS) return;
  const K = X.K;
  const { solid, box, cush, cyl, ball, slab, slabX, arcW, disc, pillowY, pillowZ, quarters, mix, shade, prism, prismZ } = K;
  const NE = K.NEON, GOLD = '#e2b14a', CH = '#d5dde2', CR = '#fffaf1', WH = '#ffffff', DK = '#36373c', TIN = '#a9b0b4', OLD = '#9b7f62', OLD2 = '#a88660', SCR = '#6cc6ee';
  const BANDS = [
    { k: 'junk', n: 'Junk & Thrift', lv: [1, 5], ui: '#a88a6a', cols: [{ a: '#a99a84', b: '#c9a85a', w: '#9a7550' }, { a: '#8fa8a0', b: '#b8714a', w: '#8a6a48' }, { a: '#c4a27a', b: '#8fa8a0', w: '#a88660' }] },
    { k: 'cot', n: 'Cozy Cottage', lv: [6, 10], ui: '#7fb565', cols: [{ a: '#9fc684', b: '#fffaf1', w: '#d49a60' }, { a: '#e3946a', b: '#f2c255', w: '#c98d58' }, { a: '#84b6c9', b: '#fffaf1', w: '#e0b07a' }] },
    { k: 'retro', n: 'Retro Diner', lv: [11, 15], ui: '#e2554a', cols: [{ a: '#e2554a', b: '#fffaf1', w: '#d5dde2' }, { a: '#5cc8c0', b: '#ffd23f', w: '#d5dde2' }, { a: '#ffd23f', b: '#e2554a', w: '#d5dde2' }] },
    { k: 'mod', n: 'Modern', lv: [16, 20], ui: '#3a3c42', cols: [{ a: '#d9d5cd', b: '#2c2d31', w: '#c9a37a' }, { a: '#3e4046', b: '#c8c2b6', w: '#d8bb92' }, { a: '#8e9a84', b: '#f1eee8', w: '#2c2d31' }] },
    { k: 'candy', n: 'Dreamy Candy', lv: [21, 25], ui: '#a98be8', cols: [{ a: '#bff0dc', b: '#cdb8f5', w: '#fff1a0' }, { a: '#cdb8f5', b: '#fff1a0', w: '#bfe4ff' }, { a: '#bfe4ff', b: '#ffcfa8', w: '#bff0dc' }] },
    { k: 'royal', n: 'Royal Palace', lv: [26, 30], ui: '#7a1e2c', cols: [{ a: '#7f2030', b: '#e2b14a', w: '#f3ead6' }, { a: '#1f5a44', b: '#e2b14a', w: '#5e321f' }, { a: '#4b2763', b: '#e2b14a', w: '#f3ead6' }] },
  ];
  const BK = {}; BANDS.forEach(b => BK[b.k] = b);

  const legs = (S, P, x, z, h, r = 4) => { const o = []; [[-x, -z], [x, -z], [-x, z], [x, z]].forEach(([a, b], i) => {
    if (S.k === 'junk') o.push(i === 3 ? cyl(a, 0, b, r * 1.3, h, TIN, { n: 10 }) : box(a, 0, b, r * 2.4, h, r * 2.4, OLD, { r: 1 }));
    else if (S.k === 'cot') o.push(cyl(a, 0, b, r, h, P.wD, { n: 10, rg: [[0, 0, 0.6], [h * 0.3, 0, 1.15], [h * 0.55, 0, 0.75], [h, 0, 1]] }));
    else if (S.k === 'retro') o.push(cyl(a, 0, b, r * 0.75, h, CH, { n: 8, rg: [[0, 0, 0.5], [h, 0, 1]] }));
    else if (S.k === 'mod') o.push(cyl(a, 0, b, r * 0.55, h, DK, { n: 6 }));
    else if (S.k === 'candy') { const R = Math.max(r * 1.3, 4); o.push(ball(a, 0, b, R, NE[i + 1], { sy: Math.max(0.6, h / (2 * R)), k: 4, n: 10 })); }
    else { const hh = Math.max(1, h - r * 1.2); o.push(cyl(a, r * 1.2, b, r * 0.8, hh, GOLD, { n: 10, rg: [[0, 0, 0.8], [hh, 0, 1.15]] }), ball(a, 0, b, r * 1.1, GOLD, { k: 4, n: 10 })); }
  }); return o; };
  const spr = (x, y, z, w, d, n = 10) => { const o = []; for (let i = 0; i < n; i++) { const u = ((i * 37) % 100) / 100 - 0.5, v = ((i * 61) % 100) / 100 - 0.5; o.push(ball(x + u * w, y, z + v * d, 2, NE[i % 6], { k: 3, n: 8, sy: 0.6 })); } return o; };
  const drips = (x, y, z, w, col, n = 5) => { const o = []; for (let i = 0; i < n; i++) o.push(ball(x - w / 2 + w * (i + 0.5) / n, y - 7 - (i % 2) * 4, z, 4, col, { sy: 1.5, k: 4, n: 10 })); return o; };
  const patch = (x, y, z, w, h, col) => box(x, y, z, w, h, 1.2, col, { r: 2 });
  const jewel = (x, y, z, r = 5) => ball(x, y, z, r, GOLD);
  const knob = (S, x, y, z, r = 2.4) => ball(x, y, z, r, S.k === 'candy' ? NE[(x > 0) + 3] : S.k === 'retro' || S.k === 'mod' ? (S.k === 'mod' ? DK : CH) : S.k === 'junk' ? '#8a8f94' : GOLD, { k: 3, n: 8 });
  const book = (x, y, z, C) => [box(x, y, z, 26, 4, 18, C[0], { r: 1 }), box(x + 1, y + 4, z, 22, 4, 16, C[1], { r: 1 })];
  const flame = (x, y, z, s = 1) => [ball(x, y, z, 4 * s, '#ffb347', { sy: 1.6, emit: 1, k: 4, n: 10 }), ball(x, y + 2 * s, z + 1, 2.2 * s, '#fff1a8', { sy: 1.5, emit: 1, k: 3, n: 8 })];
  const sideL = (x, y, h, d, col) => [box(x, y, 0, 4, h, d, col, { r: 1 })];

  // sofa / armchair: every part sits clear of its neighbours (base + back between the arms, back behind the base, back cushions on the base in front of the back, seat cushions in front of them); details glued (par) to the part they lie on
  const couch = (S, n) => { const W = n === 2 ? 196 : 122, ax = W / 2 - 14, cx = n === 2 ? [-36, 36] : [0], k = S.k, fix = S.fix;
    return { w: W, d: 90, act: 'sit', seats: cx.map(x => ({ x, z: 12, h: k === 'junk' ? 34 : 40 })), build: P => {
      const o = [], by = k === 'junk' ? 0 : 7, bH = k === 'junk' ? 14 : 18, IH = ax - (k === 'candy' ? 14 : 12), on = (p, L, fn) => L.map(q => { q.par = p; if (fn) q.fn = fn; o.push(q); return q; }), F = [0, 0, 1];
      if (k !== 'junk') o.push(...legs(S, P, W / 2 - 12, 34, 7));
      const bh = k === 'mod' ? 44 : k === 'royal' ? 72 : 58, br = k === 'mod' ? 8 : k === 'retro' ? 12 : k === 'candy' ? 30 : 24, st = by + bH + 16;
      o.push(box(0, by, 7, 2 * IH, bH, 70, P.aD, { r: k === 'mod' ? 6 : 12, bev: 4 }));
      const BK = slab(0, by, -35, 2 * IH, bh + 7, 14, P.a, { r: br, soft: 1 }); o.push(BK);
      if (k === 'royal') { const G = slab(0, by + 5, -43, W - 4, bh + 8, 2, GOLD, { r: br + 4 }); o.push(G); on(G, [jewel(0, by + bh + 10, -40, 6)]); }
      if (k === 'retro') on(BK, [box(0, by + 7 + bh, -35, 2 * IH - 24, 1.4, 12, CH, { r: 1 })]);
      const SC = [], BC = [];
      cx.forEach((x, i) => { const sag = k === 'junk' && !fix && i === cx.length - 1 ? -5 : 0, w = (n === 2 ? 2 * Math.min(IH - Math.abs(x), Math.abs(x)) : 2 * IH) - 2;
        o.push(SC[i] = pillowY(x, by + bH, 16, w, (k === 'mod' ? 13 : 16) + sag, 52, k === 'junk' && i && !fix ? P.b : P.aL));
        o.push(BC[i] = k === 'mod' ? box(x, by + bH, -21, w - 4, 38, 14, P.aL, { r: 6, bev: 3 }) : pillowZ(x, by + bH, -19, w, 40 + sag, 18, P.aL)); });
      const AR = {}; if (k === 'candy') [-1, 1].forEach(s => o.push(AR[s] = ball(s * (ax + 2), by - 2, 2, 22, P.b, { sx: 0.72, sy: 1.1, sz: 2, k: 6, n: 16 })));
      else [-1, 1].forEach(s => o.push(AR[s] = slab(s * ax, by, 2, 24, k === 'mod' ? 32 : 44, 86, P.a, { r: k === 'mod' ? 4 : 12, soft: 1 })));
      if (k === 'junk' && !fix) { on(AR[-1], [patch(-ax + 3, by + 18, 45.6, 12, 12, P.b)], F); on(SC[0], [patch(cx[0] - 12, by + 19, 42.6, 18, 8, '#c9a85a')], F); on(AR[1], [patch(ax - 4, by + 28, 45.6, 10, 8, '#8fa8a0')], F); }
      if (fix) { const j = n === 2 ? 1 : 0, x = cx[j]; on(SC[j], [pillowY(x, st - 1, 4, 56, 8, 30, P.b)]); on(SC[j], [box(x, by + bH + 2, 42.6, 56, 14, 1.2, P.b, { r: 3 })], F); }
      if (k === 'cot') { const px = cx[0] - (n === 2 ? 12 : 0), [TP] = on(SC[0], [pillowZ(px, st, -5, 30, 28, 10, P.b)]); on(TP, [ball(px, st + 11, -0.2, 3, P.a, { k: 3, n: 8, sz: 0.5 })], F); }
      if (k === 'candy') on(BK, spr(0, by + 5 + bh, -35, 2 * IH - 30, 8, 9));
      if (k === 'royal') cx.forEach((x, i) => on(BC[i], [-22, 0, 22].map(t => ball(x + t, by + 40, -9.6, 2.4, GOLD, { k: 3, n: 8, sz: 0.5 })), F));
      if (k === 'mod') on(SC[cx.length - 1], [pillowZ(cx[cx.length - 1] + 14, st - 3, -5, 28, 26, 9, P.b)]);
      return o; } }; };

  const A = {
    sofa: S => couch(S, 2), armchair: S => couch(S, 1),
    coffee: S => ({ w: 122, d: 66, round: S.k === 'candy' || S.spool ? 1 : 0, build: P => { const k = S.k, o = [];
      if (S.spool) return [cyl(0, 0, 0, 44, 6, OLD2, { rz: 30, n: 20 }), cyl(0, 6, 0, 18, 22, OLD, { n: 14 }), cyl(0, 28, 0, 48, 7, OLD2, { rz: 33, n: 20 }), cyl(0, 35, 0, 40, 0.6, '#c4a882', { rz: 27, n: 18 }), cyl(-14, 35.6, 4, 7, 10, CR, { n: 10 }), ...book(16, 35.6, -4, ['#8fa8a0', '#c9a85a'])];
      if (k === 'junk') { [-30, 30].forEach((x, i) => { const c = i ? OLD2 : OLD; o.push(box(x, 0, -23, 56, 30, 4, shade(c, 0.85)), box(x - 26, 0, 0, 4, 30, 50, c), box(x + 26, 0, 0, 4, 30, 50, c), box(x, 6, 23, 56, 7, 4, c), box(x, 18, 23, 56, 7, 4, c), box(x, 0, 0, 52, 3, 46, shade(c, 0.7))); }); o.push(box(0, 30, 0, 126, 4, 56, '#b89a74', { r: 2 }), cyl(26, 34, 4, 5, 9, TIN, { n: 10 }), box(-24, 34, -2, 26, 2, 18, '#e8dcc0', { r: 1 })); return o; }
      if (k === 'retro') return [...legs(S, P, 40, 16, 24, 4), cyl(-24, 24, 0, 40, 7, P.a, { rz: 28, n: 18 }), cyl(26, 24, 3, 34, 7, P.a, { rz: 24, n: 18 }), cyl(-24, 31, 0, 37, 0.6, P.aL, { rz: 25, n: 18 }), ball(28, 31, 2, 6, P.b), cyl(-30, 31, 4, 6, 8, CH, { n: 10 })];
      if (k === 'candy') return [cyl(0, 0, 0, 52, 12, P.a, { rz: 32, n: 20, rg: [[0, 4], [5, 0], [12, 4]] }), cyl(0, 12, 0, 47, 8, CR, { rz: 28, n: 20 }), cyl(0, 20, 0, 52, 12, P.a, { rz: 32, n: 20, rg: [[0, 4], [7, 0], [12, 6]] }), ...spr(0, 31, 0, 64, 32, 11)];
      const h = k === 'mod' ? 24 : 28; o.push(...legs(S, P, 50, 22, h, 3.5));
      o.push(box(0, h, 0, 122, k === 'mod' ? 6 : 8, 66, k === 'royal' ? '#f4f1ea' : P.w, { r: k === 'mod' ? 4 : 12, bev: 2 }));
      if (k === 'royal') o.push(box(0, h - 3, 0, 125, 3, 69, GOLD, { r: 12 }), cyl(0, h + 8, 0, 16, 7, GOLD, { rg: [[0, 8], [7, 0]] }), ball(-5, h + 13, 0, 6, '#e85a3a'), ball(6, h + 13, 3, 6, '#9fc684'), ball(0, h + 16, -4, 5, '#8f7bff'));
      else if (k === 'cot') o.push(cyl(-24, h + 8, -2, 18, 0.6, CR, { n: 16 }), cyl(-24, h + 8.6, -2, 9, 10, P.b, { rg: [[0, 3], [5, 0], [10, 2]] }), cyl(-14, h + 13, -2, 2, 2, P.b, { n: 6 }), box(26, h + 8, 4, 28, 4, 20, P.a, { r: 2 }));
      else o.push(...book(-26, h + 6, -4, [P.b, CR]), cyl(28, h + 6, 6, 5, 12, '#c9c9c4', { n: 10 }), ball(28, h + 18, 6, 6, '#8fc176'));
      return o; } }),
    tv: S => ({ w: 110, d: 44, ...(S.radio ? {} : { act: 'watch', anim: 'tv', use: { x: 0, z: 112 } }), build: P => { const k = S.k, o = [];
      if (S.radio) return [box(0, 0, 0, 74, 92, 36, OLD2, { r: 4, bev: 2 }), slab(0, 70, 0, 74, 34, 36, OLD2, { r: 30 }), box(0, 50, 18.4, 56, 34, 1, '#c9b48e', { r: 6 }), disc(-14, 32, 18, 7, 1.4, '#5a4a40'), disc(14, 32, 18, 7, 1.4, '#5a4a40'), box(0, 8, 18.4, 56, 16, 1, OLD, { r: 3 }), box(0, 70, 18.4, 40, 6, 1, '#e8dcc0', { r: 2, emit: 1 })];
      if (k === 'junk') return [box(0, 0, 0, 70, 30, 40, OLD, { r: 2 }), box(0, 12, 20.3, 64, 1.6, 0.8, '#7d6248'), box(0, 30, 0, 62, 48, 40, '#8a7d6c', { r: 10, bev: 3 }), box(-7, 36, 20.2, 42, 34, 1, '#9fc6c0', { r: 9, emit: 1, scr: 1 }), ball(22, 58, 20, 3, '#5a4a40', { k: 3, n: 8 }), ball(22, 46, 20, 3, '#5a4a40', { k: 3, n: 8 }), cyl(-10, 78, -4, 1.2, 24, CH, { n: 6 }), cyl(12, 78, -4, 1.2, 20, CH, { n: 6 }), ball(-10, 101, -4, 2, CH, { k: 3, n: 8 }), patch(-28, 36, 20.6, 8, 14, '#c9a85a')];
      const lg = k === 'retro' || k === 'mod', cy = lg ? 10 : 0, ch = k === 'mod' ? 16 : 30;
      if (lg) o.push(...legs(S, P, 46, 14, 10, 3));
      o.push(box(0, cy, 0, 110, ch, 40, k === 'royal' ? '#f4f1ea' : k === 'candy' ? P.b : P.w, { r: k === 'candy' ? 14 : 5, bev: 2 }));
      if (k !== 'mod') o.push(box(-27, cy + 4, 20.4, 50, ch - 8, 1, k === 'royal' ? GOLD : P.wL, { r: 3 }), box(27, cy + 4, 20.4, 50, ch - 8, 1, k === 'royal' ? GOLD : P.wL, { r: 3 }));
      else o.push(box(0, cy + 4, 20.4, 100, 3, 0.6, P.b, { r: 1 }));
      const sy = cy + ch;
      if (k === 'retro') o.push(...legs(S, P, 18, 4, 6, 2).map(s => s), box(0, sy + 6, -4, 80, 56, 24, P.a, { r: 20, bev: 5 }), box(-8, sy + 14, 8.4, 52, 40, 1, SCR, { r: 12, emit: 1, scr: 1 }), ball(30, sy + 42, 8, 3.5, CH, { k: 3, n: 8 }), ball(30, sy + 28, 8, 3.5, CH, { k: 3, n: 8 }), cyl(-14, sy + 62, -4, 1, 18, CH, { n: 6 }), cyl(14, sy + 62, -4, 1, 18, CH, { n: 6 }));
      else if (k === 'mod') o.push(box(0, sy, -6, 104, 58, 5, '#2f2f3a', { r: 3 }), box(0, sy + 3, -3.4, 98, 52, 0.6, SCR, { r: 2, emit: 1, scr: 1 }), box(18, sy + 8, -3, 44, 12, 0.4, '#9fc684', { r: 6, emit: 1 }));
      else if (k === 'candy') o.push(box(0, sy, -4, 92, 60, 18, P.a, { r: 26, bev: 5 }), box(0, sy + 9, 5.4, 70, 42, 0.8, SCR, { r: 16, emit: 1, scr: 1 }), ball(-36, sy + 56, -4, 8, NE[1]), ball(36, sy + 56, -4, 8, NE[4]), ...drips(0, sy + 60, 5, 70, P.aL, 5));
      else if (k === 'royal') o.push(box(0, sy, -6, 102, 64, 6, GOLD, { r: 6 }), box(0, sy + 5, -2.8, 92, 54, 0.6, SCR, { r: 4, emit: 1, scr: 1 }), jewel(0, sy + 64, -6, 6), ball(-50, sy + 60, -6, 4, GOLD), ball(50, sy + 60, -6, 4, GOLD));
      else o.push(box(0, sy, -4, 86, 58, 16, P.wD, { r: 8, bev: 3 }), box(0, sy + 7, 4.2, 70, 44, 0.8, SCR, { r: 6, emit: 1, scr: 1 }), box(16, sy + 12, 4.8, 30, 10, 0.4, '#e9f7fd', { r: 5, emit: 1 }));
      return o; } }),
    shelf: S => ({ w: 102, d: 36, build: P => { const k = S.k, o = [], C = ['#e3946a', '#84b6c9', '#f2c255', '#9fc684', '#8f86c9', '#fffaf1'];
      if (k === 'junk') { [[-24, 0, OLD], [24, 0, OLD2], [-12, 36, '#b89a74']].forEach(([x, y, c], i) => { o.push(box(x, y, -15, 46, 36, 4, shade(c, 0.8)), box(x - 21, y, 0, 4, 36, 34, c), box(x + 21, y, 0, 4, 36, 34, c), box(x, y, 0, 46, 4, 34, c), box(x, y + 32, 0, 46, 4, 34, c), box(x - 8, y + 4, -2, 8, 24 - i * 3, 22, C[i], { r: 1 }), box(x + 2, y + 4, -2, 7, 27, 22, C[i + 2], { r: 1 })); }); o.push(cyl(24, 36, 0, 7, 11, TIN, { n: 10 }), ball(24, 45, 0, 9, '#8fc176')); return o; }
      const fc = k === 'royal' ? '#f4f1ea' : k === 'mod' ? DK : k === 'retro' ? P.a : k === 'candy' ? P.a : P.w, H = k === 'mod' ? 120 : 130, th = k === 'mod' ? 3 : 8;
      o.push(box(0, 0, -14, 86, H, 6, k === 'mod' ? '#e9e5dc' : shade(fc, 0.8), { r: 1 }), box(-46, 0, 0, th, H, 34, fc, { r: 2 }), box(46, 0, 0, th, H, 34, fc, { r: 2 }));
      if (k === 'candy') o.push(slab(0, H - 8, 0, 102, 26, 36, P.a, { r: 18 }), ...drips(0, H - 6, 18, 90, P.aL, 6), ...spr(0, H + 18, 0, 60, 14, 6));
      else o.push(box(0, H - 4, 0, 102, 6, 36, fc, { r: 3, bev: 1.5 }));
      if (k === 'royal') o.push(box(0, H + 2, 0, 102, 3, 36, GOLD, { r: 3 }), jewel(0, H + 5, 0, 7), jewel(-46, H + 5, 0, 4), jewel(46, H + 5, 0, 4));
      if (k === 'retro') o.push(box(0, H - 10, 17.6, 96, 3, 1, CH));
      [0, 42, 84].forEach((y, s) => { o.push(box(0, y, 1, 86, k === 'mod' ? 3 : 4, 30, k === 'mod' ? DK : fc, { r: 1 })); let x = -38, i = 0; while (true) { const w = 7 + ((i * 5 + s * 3) % 4), h = 24 + ((i * 7 + s) % 4) * 3; if (x + w > (s === 1 ? 14 : 38)) break; o.push(box(x + w / 2, y + 4, -1, w, h, 22, C[(i + s * 2) % 6], { r: 1 })); x += w + 1; i++; } if (s === 1) o.push(k === 'royal' ? jewel(28, y + 4, 0, 8) : ball(28, y + 4, 0, 8, k === 'candy' ? NE[1] : '#9fc684')); });
      if (k === 'mod') o.push(box(0, 0, 1, 86, 3, 30, DK));
      return o; } }),
    lamp: S => ({ w: 44, d: 44, round: 1, glow: () => ({ y: S.k === 'royal' ? 92 : 108, r: 80 }), build: P => { const k = S.k;
      if (k === 'junk') return [box(0, 0, 0, 24, 4, 24, '#8a8f94', { r: 2 }), cyl(0, 4, 0, 1.6, 92, '#8a8f94', { n: 6 }), ball(0, 84, 3, 5, '#fff1a8', { emit: 1 }), cyl(2, 90, 2, 18, 20, '#c9b48e', { rg: [[0, 0], [20, 7]] }), patch(-8, 96, 14, 6, 8, '#a99a84')];
      if (k === 'retro') return [cyl(0, 0, 0, 14, 28, CH, { rg: [[0, 0], [28, 8]] }), cyl(0, 28, 0, 11, 54, '#ffb347', { rg: [[0, 0, 0.6], [26, 0, 1], [54, 0, 0.55]], emit: 1 }), ball(-3, 38, 0, 4.5, P.a, { emit: 1 }), ball(3, 54, 1, 3.5, P.a, { emit: 1 }), ball(-1, 66, 0, 3, P.a, { emit: 1 }), cyl(0, 82, 0, 6, 10, CH, { top: 3 })];
      if (k === 'mod') { const o = [box(26, 0, 0, 22, 6, 22, DK, { r: 3 })]; for (let i = 0; i <= 16; i++) { const t = i / 16 * Math.PI * 0.62; o.push(ball(26 - 44 * (1 - Math.cos(t)), 6 + 120 * Math.sin(t) - 3.4, 0, 3.6, DK, { k: 3, n: 10 })); } o.push(cyl(-16, 100, 0, 17, 14, P.a, { rg: [[0, 0, 1], [14, 10]] }), ball(-16, 96, 0, 5, '#fff1a8', { emit: 1 })); return o; }
      if (k === 'candy') return [cyl(0, 0, 0, 14, 5, P.b), cyl(0, 5, 0, 2.4, 82, WH, { n: 8 }), ball(-14, 84, 0, 14, '#fffdf5', { emit: 1 }), ball(10, 82, 2, 16, '#fffdf5', { emit: 1 }), ball(0, 96, -2, 16, '#fffdf5', { emit: 1 }), ball(-4, 86, 12, 3, NE[1], { emit: 1 }), ball(8, 92, 12, 3, NE[4], { emit: 1 })];
      if (k === 'royal') return [cyl(0, 0, 0, 16, 6, GOLD, { rg: [[0, 0], [6, 6]] }), cyl(0, 6, 0, 3, 70, GOLD, { n: 8, rg: [[0, 0, 1.4], [30, 0, 0.8], [70, 0, 1]] }), box(0, 72, 0, 56, 4, 5, GOLD, { r: 2 }), ...[-26, 0, 26].flatMap(x => [cyl(x, 76, 0, 3.5, 3, GOLD, { n: 8 }), cyl(x, 79, 0, 2.4, 14, CR, { n: 8 }), ...flame(x, 93, 0, 0.9)])];
      return [cyl(0, 0, 0, 16, 4, P.wD), cyl(0, 4, 0, 2.5, 100, P.wD, { n: 8, rg: [[0, 0, 1.4], [30, 0, 0.8], [100, 0, 1]] }), cyl(0, 98, 0, 24, 30, P.a, { rg: [[0, 0], [30, 8]] }), ...[0, 1, 2, 3, 4, 5, 6, 7].map(i => ball(24 * Math.cos(i * 0.785), 94, 24 * Math.sin(i * 0.785), 2.4, P.b, { k: 3, n: 8 }))];
    } }),
    plant: S => ({ w: S.k === 'cot' ? 70 : 50, d: S.k === 'cot' ? 34 : 50, round: S.k === 'cot' ? 0 : 1, build: P => { const k = S.k;
      if (k === 'junk') return [cyl(0, 0, 0, 12, 20, TIN, { n: 12 }), cyl(0, 20, 0, 12.5, 2, '#c9cfd2', { n: 12 }), ball(-6, 20, 0, 7, '#9fc684', { sy: 1.5 }), ball(6, 22, 2, 6, '#8fc176', { sy: 1.4 }), ball(0, 28, -3, 5, '#a8d48a', { sy: 1.4 })];
      if (k === 'cot') return [box(0, 0, 0, 66, 22, 30, P.w, { r: 3, bev: 2 }), box(0, 22, 0, 60, 0.6, 24, '#6a4020'), ...[-22, 0, 22].flatMap((x, i) => [ball(x, 20, 0, 10, ['#7ab45c', '#8fc176', '#a8d48a'][i], { sy: 1.3 }), ball(x - 4, 36, 4, 3, i === 1 ? CR : '#c4a0e0', { k: 3, n: 8 })])];
      if (k === 'retro') return [...legs(S, P, 9, 9, 14, 2.5), cyl(0, 14, 0, 16, 18, P.a, { rg: [[0, 0, 0.7], [18, 0, 1]] }), cyl(0, 32, 0, 8, 34, '#6fae50', { n: 10, top: 6 }), ball(-14, 44, 0, 5, '#6fae50', { sy: 2 }), ball(12, 50, 0, 5, '#6fae50', { sy: 1.8 }), ball(0, 66, 0, 3, '#e2554a', { k: 3, n: 8 })];
      if (k === 'mod') { const o = [cyl(0, 0, 0, 17, 30, '#c9c9c4', { n: 16 })]; [[-8, 70, 0.2], [0, 84, -0.3], [8, 66, 0.6], [-2, 58, 1.2], [6, 76, 2.2]].forEach(([x, h, y], i) => o.push(box(x, 28, (i % 2) * 4 - 2, 7, h - 20, 3, i % 2 ? '#5a9a54' : '#6fae50', { r: 3, yaw: y }))); return o; }
      if (k === 'candy') return [cyl(0, 0, 0, 16, 22, P.b, { rg: [[0, 0, 0.8], [22, 0, 1]] }), cyl(0, 22, 0, 2.4, 40, WH, { n: 8 }), disc(0, 70, -3, 20, 6, P.a, { top: 2 }), disc(0, 70, 3, 13, 0.6, P.w), disc(0, 70, 3.6, 6, 0.6, CR), ...spr(0, 22, 0, 18, 18, 5)];
      return [cyl(0, 0, 0, 12, 8, '#f4f1ea'), cyl(0, 8, 0, 18, 30, '#f4f1ea', { rg: [[0, 0, 0.6], [16, 0, 1.1], [30, 0, 0.9]] }), cyl(0, 22, 0, 19.5, 3, GOLD), ball(-15, 34, 6, 14, '#5a9a54', { sy: 0.8 }), ball(15, 36, 4, 14, '#5a9a54', { sy: 0.8 }), ball(0, 38, 0, 18, '#6fae50'), ball(-4, 60, -4, 11, '#8fc176'), ball(8, 56, 8, 10, '#8fc176')];
    } }),
    rug: S => ({ w: S.k === 'cot' || S.k === 'candy' ? 180 : 200, d: S.k === 'cot' || S.k === 'candy' ? 124 : 130, round: S.k === 'cot' || S.k === 'candy' ? 1 : 0, flat: 1, noBlock: 1, build: P => { const k = S.k;
      if (k === 'junk') return [box(0, 0, 0, 190, 2, 120, P.a, { r: 6 }), ...[-44, -22, 0, 22, 44].map((z, i) => box(0, 2, z, 180, 0.6, 12, [P.b, '#8fa8a0', CR, '#b8714a', P.b][i], { r: 2 })), patch(-60, 2.6, 0, 1, 1, P.a)];
      if (k === 'cot') return [cyl(0, 0, 0, 90, 2, P.a, { rz: 62, n: 24 }), cyl(0, 2, 0, 76, 0.6, CR, { rz: 52, n: 24 }), cyl(0, 2.6, 0, 62, 0.6, P.b, { rz: 42, n: 22 }), cyl(0, 3.2, 0, 46, 0.6, P.a, { rz: 31, n: 20 }), cyl(0, 3.8, 0, 28, 0.6, CR, { rz: 19, n: 16 })];
      if (k === 'retro') { const o = [box(0, 0, 0, 200, 2, 130, '#3d4048', { r: 6 })]; for (let i = 0; i < 6; i++) for (let j = 0; j < 4; j++) if ((i + j) % 2 === 0) o.push(box(-80 + 32 * i, 2, -45 + 30 * j, 31, 0.6, 29, CR, { r: 1 })); return o; }
      if (k === 'mod') return [box(0, 0, 0, 200, 2, 130, P.a, { r: 4 }), box(0, 2, 0, 176, 0.6, 106, shade(P.a, 0.9), { r: 3 }), box(0, 2.6, 30, 176, 0.6, 8, P.b, { r: 1 })];
      if (k === 'candy') return [cyl(0, 0, 0, 90, 3, P.a, { rz: 62, n: 24, rg: [[0, 3], [3, 0]] }), cyl(0, 3, 0, 70, 0.6, P.b, { rz: 48, n: 22 }), cyl(0, 3.6, 0, 40, 0.6, P.w, { rz: 27, n: 18 }), ...spr(0, 3, 0, 130, 70, 12)];
      return [box(0, 0, 0, 200, 2, 130, P.a, { r: 6 }), box(0, 2, 0, 186, 0.6, 116, GOLD, { r: 4 }), box(0, 2.6, 0, 176, 0.6, 106, P.a, { r: 3 }), cyl(0, 3.2, 0, 34, 0.6, GOLD, { rz: 24, n: 16 }), cyl(0, 3.8, 0, 24, 0.6, P.b === GOLD ? CR : P.b, { rz: 16, n: 14 })];
    } }),
    mat: S => ({ w: 120, d: 72, flat: 1, noBlock: 1, build: P => [box(0, 0, 0, 120, 3, 72, P.a, { r: 14 }), ...[-36, -12, 12, 36].flatMap(x => [-16, 0, 16].map(z => cyl(x, 3, z, 4, 0.6, shade(P.a, 0.86), { n: 8 })))] }),
    pouf: S => ({ w: S.k === 'junk' ? 96 : 70, d: S.k === 'junk' ? 86 : 70, round: 1, act: S.k === 'junk' ? 'nap' : 'sit', seats: [{ x: 0, z: S.k === 'junk' ? 10 : 0, h: S.k === 'junk' ? 34 : 36, k: S.k === 'junk' ? 'nap' : 'sit' }], build: P => S.k === 'junk'
      ? [ball(0, 0, -14, 32, '#c4a882', { sx: 1.3, sy: 1.15, sz: 0.95, k: 8, n: 20 }), ball(0, 0, 10, 36, '#c4a882', { sx: 1.28, sy: 0.55, sz: 0.92, k: 8, n: 20 }), patch(-18, 22, 42, 16, 12, P.b), ball(26, 64, -18, 6, '#b39a6c', { sy: 1.4 }), box(0, 24, 43, 30, 6, 1, '#a88a66', { r: 2 })]
      : [ball(0, 0, 0, 32, P.a, { sy: 0.62, k: 7, n: 20, shine: 1 }), ...[0, 1, 2, 3, 4, 5, 6, 7].map(i => ball(22 * Math.cos(i * 0.8), 30 + (i % 2) * 3, 22 * Math.sin(i * 0.8), 2.4, WH, { k: 3, n: 8 }))] }),
    bowl: S => ({ w: 40, d: 40, round: 1, noBlock: 1, act: 'feed', use: { x: 42, z: 6 }, build: P => [cyl(0, 0, 0, 18, 12, S.k === 'junk' ? TIN : P.a, { rg: [[0, 6], [10, 0], [12, 0]] }), cyl(0, 12, 0, 15, 0.8, '#c98a52'), ball(-5, 12, -2, 2.8, '#a86b36', { k: 3, n: 8 }), ball(4, 12, 3, 2.8, '#e2ad74', { k: 3, n: 8 }), ball(1, 12, -5, 2.6, '#c98a52', { k: 3, n: 8 }), S.k === 'junk' ? patch(-10, 3, 17, 6, 5, '#8a8f94') : cyl(0, 0, 0, 1, 0.2, P.a)] }),

    fridge: S => { const k = S.k, H = k === 'junk' ? 110 : k === 'mod' ? 146 : 136, Wd = k === 'mod' ? 84 : 70;
      return { w: Wd, d: 60, act: 'snack', use: { x: 0, z: 62 }, build: (P, v) => { const op = v === 'open', t = 100 * Math.PI / 180, o = [], body = k === 'junk' ? OLD2 : k === 'royal' ? '#f4f1ea' : P.a;
        if (k === 'mod' || k === 'junk') o.push(box(0, 0, 0, Wd, 4, 56, DK, { r: 3 })); else o.push(...legs(S, P, 26, 22, 4, 3));
        o.push(k === 'retro' || k === 'candy' ? slab(0, 4, 0, Wd, H, 60, body, { r: 28, rb: 6 }) : box(0, 4, 0, Wd, H, 60, body, { r: k === 'mod' ? 4 : 12, bev: 4 }));
        if (k === 'junk') o.push(box(0, 62, 30.4, 64, 2, 0.8, '#7d6248'), box(22, 74, 31, 8, 10, 3, GOLD, { r: 2 }), box(22, 36, 31, 8, 10, 3, GOLD, { r: 2 }), box(-31, 90, 31, 4, 8, 3, '#8a8f94'), box(-31, 20, 31, 4, 8, 3, '#8a8f94'), patch(-14, 80, 30.6, 14, 10, '#c9a85a'));
        else if (k === 'mod') o.push(box(0, 8, 30.4, 1.4, H - 8, 0.8, shade(body, 0.8)), box(-5, 70, 31, 3, 40, 3, CH, { r: 1.5 }), box(5, 70, 31, 3, 40, 3, CH, { r: 1.5 }), box(-22, 92, 30.6, 18, 26, 0.8, '#5a6270', { r: 3 }));
        else { o.push(box(0, 93, 30.2, Wd - 4, 2, 0.8, shade(body, 0.85), { r: 1 }), box(24, 102, 31, 5, 24, 3, k === 'royal' ? GOLD : k === 'retro' ? CH : '#fbf7ee', { r: 2 })); if (!op) o.push(box(24, 44, 31, 5, 40, 3, k === 'royal' ? GOLD : k === 'retro' ? CH : '#fbf7ee', { r: 2 })); }
        if (k === 'retro') o.push(box(0, 130, 30.6, 40, 5, 0.8, CH, { r: 2 }));
        if (k === 'candy') o.push(...drips(0, H + 4, 26, 66, P.b, 6), ball(0, H + 2, 0, 9, '#e2554a'), ...spr(0, H, 0, 40, 30, 6));
        if (k === 'royal') o.push(box(0, 4, 0, Wd + 2, 6, 62, GOLD, { r: 12 }), jewel(0, H + 4, 0, 7), disc(-14, 112, 30, 7, 1, GOLD));
        if (k === 'cot') o.push(box(-14, 50, 30.4, 14, 10, 1, CR, { r: 2 }), ball(-18, 70, 30, 4, '#e3946a', { sz: 0.4 }));
        if (op) o.push(box(0, 10, 30.6, Wd - 12, 78, 1, '#fff8e2', { r: 4, emit: 1 }), box(0, 36, 31.4, Wd - 14, 2, 1, '#e6d6b4'), box(0, 60, 31.4, Wd - 14, 2, 1, '#e6d6b4'), ball(-14, 12, 32, 6, '#e85a3a'), ball(10, 12, 32, 7, '#ffb347'), box(14, 38, 32, 14, 14, 2, CR, { r: 2 }), cyl(-14, 38, 32, 5, 14, '#84b6c9', { n: 8 }), box(-Wd / 2 + 33 * Math.cos(t), 8, 30 + 33 * Math.sin(t), Wd - 4, 84, 6, body, { r: 10, yaw: t }));
        return o; } }; },
    stove: S => ({ w: 82, d: 62, act: 'cook', use: { x: 0, z: 60 }, build: (P, v) => { const k = S.k, on = v === 'on', o = [];
      const body = k === 'junk' ? '#5a5450' : k === 'royal' ? '#f4f1ea' : k === 'mod' ? '#e9e5dc' : k === 'cot' ? '#f4ead8' : P.a, top = k === 'mod' ? '#2b2b33' : '#4a3a30';
      o.push(box(0, 0, 0, 80, 64, 60, body, { r: k === 'mod' ? 3 : 8, bev: 2 }), box(0, 64, 0, 82, 4, 62, top, { r: 4 }));
      if (k === 'junk') o.push(cyl(-26, 68, -22, 6, 70, '#6a625c', { n: 10 }), patch(24, 40, 30.4, 12, 9, '#b8714a'), patch(-20, 14, 30.4, 10, 8, '#b8714a'));
      else if (k === 'candy') o.push(slab(0, 68, -27, 82, 30, 8, P.b, { r: 14, soft: 1 }), ...drips(0, 98, -23, 70, P.bL, 5), ball(0, 96, -27, 7, '#e2554a'));
      else o.push(slab(0, 68, -27, 80, k === 'mod' ? 8 : 22, 6, k === 'royal' ? GOLD : body, { r: 6 }));
      [-20, 20].forEach(x => o.push(cyl(x, 68, 6, 11, 1, k === 'mod' ? '#3d3d48' : '#2b211b')));
      if (on) [-20, 20].forEach(x => o.push(cyl(x, 69, 6, 9.5, 0.5, '#ff8a3a', { emit: 1 })));
      o.push(cyl(-20, 69.5, 6, 13, 18, k === 'junk' ? TIN : P.b === CR || P.b === '#fffaf1' ? P.a : P.b), cyl(-20, 87.5, 6, 13, 3, shade(k === 'junk' ? TIN : P.b, 0.86), { top: 5 }), cyl(20, 69.5, 6, 12, 4, '#3b3b3b'), box(37, 70, 6, 16, 3, 4, '#3b3b3b', { r: 1.5 }));
      o.push(box(0, 10, 30.5, 64, 40, 1.2, k === 'mod' ? '#2b2b33' : '#3b2e28', { r: 5 }), box(0, 16, 31.4, 48, 26, 0.8, on ? '#ffb347' : '#5a4a40', { r: 4, emit: on ? 1 : 0 }), box(0, 54, 30.5, 58, 3, 1.2, k === 'royal' ? GOLD : k === 'retro' ? CH : '#cbbca2', { r: 1.5 }));
      [-24, -8, 8, 24].forEach(x => o.push(knob(S, x, 58, 30.6, 2.6)));
      if (k === 'retro') o.push(box(0, 4, 30.6, 76, 3, 0.8, CH, { r: 1 }));
      if (k === 'royal') o.push(box(0, 0, 0, 82, 5, 62, GOLD, { r: 8 }), jewel(0, 90, -27, 6));
      return o; } }),
    counter: S => ({ w: 124, d: 54, act: S.sink ? 'wash' : undefined, use: S.sink ? { x: 0, z: 54 } : undefined, build: P => { const k = S.k, o = [];
      const body = k === 'junk' ? P.a : k === 'royal' ? '#f4f1ea' : P.a, top = k === 'junk' ? '#b89a74' : k === 'royal' ? '#f4f1ea' : k === 'mod' ? '#3d4048' : k === 'retro' ? P.b : k === 'candy' ? P.b : '#f4ead8';
      if (k === 'mod') o.push(box(0, 0, 0, 116, 6, 46, DK, { r: 2 }));
      o.push(box(0, k === 'mod' ? 6 : 0, 0, 120, k === 'mod' ? 42 : 48, 50, body, { r: k === 'mod' ? 3 : k === 'candy' ? 12 : 4 }), box(0, 48, 0, 124, 6, 54, top, { r: 4, bev: 1.5 }));
      if (k === 'junk') o.push(box(-30, 6, 25, 52, 36, 1.2, P.aL, { r: 4 }), box(32, 6, 34, 50, 36, 2, P.aL, { r: 4, yaw: -0.5 }), patch(-36, 30, 25.8, 12, 8, P.b), cyl(-34, 0, 34, 8, 12, TIN, { n: 10 }));
      else if (k === 'mod') o.push(box(0, 26, 25.2, 1, 20, 0.8, shade(body, 0.8)), box(-30, 44, 25.6, 30, 2, 1.4, CH), box(30, 44, 25.6, 30, 2, 1.4, CH));
      else { o.push(box(-30, 6, 25, 52, 36, 1.2, P.aL, { r: 4 }), box(30, 6, 25, 52, 36, 1.2, P.aL, { r: 4 })); o.push(knob(S, -6, 28, 26), knob(S, 6, 28, 26)); }
      if (k === 'retro') o.push(box(0, 46, 27.2, 124, 2.4, 0.8, CH));
      if (k === 'candy') o.push(...drips(0, 54, 27, 110, P.bL, 7));
      if (k === 'royal') o.push(box(0, 47, 0, 125, 2, 55, GOLD, { r: 4 }));
      if (S.sink) o.push(cyl(-14, 54, 0, 22, 0.8, '#9aa8ae', { rz: 16, n: 14 }), cyl(-14, 54, -20, 3, 14, k === 'royal' ? GOLD : CH, { n: 8 }), box(-14, 66, -14, 4, 3, 12, k === 'royal' ? GOLD : CH, { r: 1.5 }), k === 'junk' ? cyl(30, 54, 0, 12, 14, TIN, { rg: [[0, 0, 0.85], [14, 0, 1]] }) : cyl(32, 54, 2, 7, 10, CR, { n: 10 }));
      else o.push(cyl(-28, 54, 0, 14, 7, CR, { rg: [[0, 6], [7, 0]] }), ball(-32, 59, 0, 5, '#ffb347'), ball(-24, 59, 3, 5, '#e85a3a'), cyl(30, 54, -8, 6, 14, CR, { n: 10 }), cyl(30, 68, -8, 6, 3, k === 'junk' ? TIN : P.b === CR ? P.a : P.b, { n: 10 }));
      return o; } }),
    hutch: S => ({ w: 104, d: 46, build: P => { const k = S.k, c = k === 'junk' ? '#8fa8a0' : P.w, o = [box(0, 0, 0, 104, 54, 46, c, { r: 4, bev: 2 }), box(0, 54, 0, 108, 4, 48, shade(c, 0.9), { r: 3 }), box(0, 58, -16, 96, 74, 6, shade(c, 0.85)), box(-46, 58, -8, 6, 74, 22, c), box(46, 58, -8, 6, 74, 22, c), box(0, 130, -8, 104, 8, 26, c, { r: 3 }), box(0, 92, -6, 92, 3, 18, c)];
      o.push(box(-25, 6, 23.2, 46, 42, 1.2, mix(c, '#ffffff', 0.25), { r: 4 }), box(25, 6, 23.2, 46, 42, 1.2, mix(c, '#ffffff', 0.25), { r: 4 }), knob(S, -5, 28, 24), knob(S, 5, 28, 24));
      [-30, -10, 10, 30].forEach((x, i) => o.push(disc(x, 74, -12, 8, 1.2, i % 2 ? P.b : CR, { top: 1 }), disc(x, 108, -12, 7, 1.2, i % 2 ? CR : P.b, { top: 1 })));
      if (k === 'junk') o.push(patch(30, 30, 24, 10, 8, '#c9a85a'), box(-25, 6, 24.4, 2, 42, 0.6, '#7d6248'));
      return o; } }),
    table: S => { const k = S.k, round = k === 'retro' || k === 'candy', W = k === 'royal' ? 160 : 120, D = round ? 100 : 76;
      return { w: W, d: D, round: round ? 1 : 0, build: P => { const o = [], h = 48;
        if (round) { o.push(cyl(0, 0, 0, 26, 4, k === 'retro' ? CH : P.b), cyl(0, 4, 0, 6, h - 4, k === 'retro' ? CH : P.b, { n: 10 })); o.push(cyl(0, h, 0, 52, 7, k === 'candy' ? '#d49a60' : P.a, { rz: 46, n: 20, rg: [[0, 2], [4, 0], [7, 2]] })); if (k === 'retro') o.push(cyl(0, h + 6.5, 0, 51, 0.6, P.b, { rz: 45, n: 20 }), cyl(0, h - 0.5, 0, 53, 2.4, CH, { rz: 47, n: 20 }), cyl(-14, h + 7, 0, 5, 12, CR, { n: 10 }), cyl(-14, h + 19, 0, 1.4, 8, '#e2554a', { n: 6 }), cyl(14, h + 7, 6, 10, 2, CR, { n: 12 }), ball(14, h + 9, 6, 6, '#ffb347', { sy: 0.5 })); else o.push(...[[-24, -10], [18, 14], [6, -24], [-10, 22], [30, -6]].map(([x, z]) => ball(x, h + 6, z, 4, '#6a4020', { sy: 0.5 })), cyl(0, h + 7, 0, 22, 2, P.a, { n: 14 }), ...spr(0, h + 9, 0, 30, 20, 6)); return o; }
        if (k === 'junk') { [[-50, -30], [50, -30], [-50, 30], [50, 30]].forEach(([x, z]) => o.push(cyl(x, 0, z, 1.8, h, '#8a8f94', { n: 6 }))); o.push(box(0, h, 0, 120, 4, 76, '#c9c1b0', { r: 2 }), box(-20, h + 4, 0, 40, 1, 30, '#e8e4dc', { r: 1, yaw: 0.2 }), cyl(26, h + 4, 8, 6, 10, TIN, { n: 10 })); return o; }
        o.push(...legs(S, P, W / 2 - 10, 28, h, 4), box(0, h, 0, W, 6, 76, k === 'royal' ? '#f4f1ea' : k === 'mod' ? '#cfe8f0' : P.w, { r: k === 'mod' ? 4 : 8, bev: 2 }));
        if (k === 'cot') o.push(box(0, h + 6, 0, 88, 0.8, 80, P.b, { r: 2 }), ...[-33, -11, 11, 33].map((x, i) => box(x, h + 6.8, 0, 11, 0.4, 80, P.a, { r: 1 })), cyl(0, h + 7, 0, 7, 14, CR, { rg: [[0, 0, 0.8], [8, 0, 1.1], [14, 0, 0.6]] }), ball(-3, h + 21, 0, 4, '#e3946a'), ball(4, h + 22, 2, 4, '#f2c255'));
        else if (k === 'mod') o.push(cyl(20, h + 6, 0, 10, 2, '#e9e5dc', { n: 12 }), ball(20, h + 8, 0, 5, '#9fc684'), cyl(-22, h + 6, -6, 4, 10, '#c9c9c4', { n: 8 }));
        else { o.push(box(0, h + 6, 0, 150, 1, 60, CR, { r: 2 }), box(0, h - 2, 0, 162, 3, 78, GOLD, { r: 8 })); [-40, 0, 40].forEach((x, i) => { if (i === 1) o.push(cyl(x, h + 7, 0, 5, 20, GOLD, { n: 8, rg: [[0, 0, 1.6], [6, 0, 0.6], [20, 0, 1]] }), ...flame(x, h + 27, 0, 0.8)); else o.push(cyl(x, h + 7, 0, 12, 2, WH, { n: 12 }), ball(x, h + 9, 0, 6, x < 0 ? '#e85a3a' : '#9fc684')); }); }
        return o; } }; },
    chair: S => ({ w: 48, d: 48, act: 'sit', seats: [{ x: 0, z: 3, h: S.k === 'candy' ? 38 : 40 }], build: P => { const k = S.k, o = [];
      if (k === 'candy') return [ball(0, 0, 2, 22, P.a, { sy: 0.8, k: 6, n: 16 }), ball(0, 22, -18, 18, P.b, { sy: 1.1, sz: 0.5, k: 6, n: 16 }), ...spr(0, 34, 6, 22, 16, 5)];
      if (k === 'mod') return [...legs(S, P, 17, 17, 26, 3), box(0, 26, 2, 46, 8, 44, P.a, { r: 14, bev: 4 }), slab(0, 30, -20, 46, 34, 6, P.a, { r: 18, soft: 1 })];
      const lc = k === 'retro' ? CH : k === 'royal' ? GOLD : P.wD, sc = k === 'junk' ? '#b89a74' : k === 'royal' ? '#f4f1ea' : P.w;
      o.push(...legs(S, P, 18, 18, 26, 3), box(0, 26, 0, 48, 6, 48, k === 'retro' ? CH : sc, { r: 8, bev: 2 }), pillowY(0, 32, 2, 40, 8, 38, k === 'junk' ? '#8fa8a0' : P.a));
      if (k === 'retro') o.push(cyl(-19, 32, -21, 2.4, 30, CH, { n: 8 }), cyl(19, 32, -21, 2.4, 30, CH, { n: 8 }), slab(0, 50, -21, 46, 24, 8, P.a, { r: 12, soft: 1 }));
      else if (k === 'royal') o.push(slab(0, 30, -22, 48, 66, 6, P.a, { r: 24, soft: 1 }), slab(0, 28, -25.5, 52, 72, 2, GOLD, { r: 26 }), jewel(0, 100, -23, 5));
      else { o.push(cyl(-19, 32, -21, 3, 40, lc, { n: 10 }), cyl(19, 32, -21, 3, 40, lc, { n: 10 })); if (k === 'junk') o.push(slab(0, 46, -21, 38, 6, 4, OLD2, { r: 3 }), slab(0, 62, -21, 48, 12, 6, OLD, { r: 4 })); else o.push(slab(0, 46, -21, 38, 5, 4, sc, { r: 3 }), slab(0, 56, -21, 38, 5, 4, sc, { r: 3 }), slab(0, 66, -21, 48, 12, 6, sc, { r: 6 })); }
      return o; } }),
    stool: S => { const k = S.k, h = k === 'junk' ? 30 : k === 'mod' ? 52 : k === 'royal' ? 34 : 33;
      return { w: 40, d: 40, round: k !== 'junk' ? 1 : 0, act: 'sit', seats: [{ x: 0, z: 0, h: h + 8 }], build: P => {
        if (k === 'junk') return [box(0, 0, 0, 38, h, 38, P.b, { r: 3 }), box(0, 4, 19.3, 34, 3, 0.8, shade(P.b, 0.7)), box(0, 12, 19.3, 34, 3, 0.8, shade(P.b, 0.7)), box(0, 20, 19.3, 34, 3, 0.8, shade(P.b, 0.7)), pillowY(0, h, 0, 34, 6, 34, P.a)];
        if (k === 'retro' || k === 'mod') return [cyl(0, 0, 0, 16, 3, k === 'mod' ? DK : CH), cyl(0, 3, 0, 2.6, h - 3, k === 'mod' ? DK : CH, { n: 8 }), k === 'mod' ? cyl(0, h * 0.45, 0, 12, 1.6, DK, { n: 12 }) : cyl(0, h - 4, 0, 18, 3, CH), cyl(0, h, 0, 19, 9, P.a, { rg: [[0, 0], [5, 0], [9, 4]], soft: 1 })];
        if (k === 'candy') return [cyl(0, 0, 0, 14, 3, P.b), cyl(0, 3, 0, 2.6, h - 3, WH, { n: 8 }), cyl(0, h, 0, 20, 8, P.a, { rg: [[0, 0], [5, 0], [8, 5]], soft: 1 }), cyl(0, h + 8, 0, 12, 0.6, P.w, { n: 12 }), cyl(0, h + 8.6, 0, 5, 0.6, CR, { n: 10 })];
        return [...[0, 1, 2].map(i => cyl(12 * Math.cos(i * 2.094 + 0.5), 0, 12 * Math.sin(i * 2.094 + 0.5), 2.6, h, k === 'royal' ? GOLD : '#a86b36', { n: 8 })), cyl(0, h, 0, 19, 9, P.a, { rg: [[0, 0], [5, 0], [9, 4]], soft: 1 }), ...(k === 'royal' ? [cyl(0, h - 1, 0, 20, 2, GOLD), ball(0, h + 8, 0, 2.6, GOLD, { k: 3, n: 8 })] : [])];
      } }; },

    tub: S => { const k = S.k, box_ = k === 'retro' || k === 'mod';
      return { w: 172, d: 90, act: 'bath', inside: [0, 14, 0], seats: [{ x: -36, z: 0, h: 14, k: 'bath' }, { x: 36, z: 0, h: 14, k: 'bath' }], build: P => { const o = [], sh = k === 'junk' ? TIN : k === 'royal' ? GOLD : k === 'cot' ? '#ffffff' : P.a;
        if (k === 'junk') { o.push(cyl(0, 0, 0, 74, 4, shade(TIN, 0.9), { rz: 36, n: 20 }), cyl(0, 4, 0, 70, 18, '#b9dbe4', { rz: 32, n: 20, emit: 1 })); o.push(...quarters((a0, a1) => arcW(0, 0, 0, 78, 40, 6, 30, a0, a1, TIN))); o.push(box(-82, 18, 0, 6, 8, 16, '#8a8f94', { r: 2 }), box(82, 18, 0, 6, 8, 16, '#8a8f94', { r: 2 }), patch(-20, 10, 40.6, 12, 8, '#b8714a'), ...[[-30, 6, 6], [20, -10, 5], [40, 8, 5]].map(([x, z, r]) => ball(x, 20, z, r, WH))); return o; }
        if (box_) { const y0 = k === 'retro' ? 8 : 0; if (k === 'retro') o.push(...legs(S, P, 66, 28, 8, 4)); o.push(box(0, y0, 0, 166, 6, 84, sh, { r: 18 }), cyl(0, y0 + 6, 0, 74, 22, '#a9def0', { rz: 32, n: 20, emit: 1 }), box(0, y0, -38, 166, 36, 8, sh, { r: 4 }), box(0, y0, 38, 166, 36, 8, sh, { r: 4 }), box(-79, y0, 0, 8, 36, 68, sh, { r: 4 }), box(79, y0, 0, 8, 36, 68, sh, { r: 4 })); if (k === 'retro') o.push(box(0, y0 + 30, 42.4, 160, 3, 0.8, CH)); else o.push(box(-60, y0 + 36, -36, 30, 4, 12, '#e9e5dc', { r: 2 }), cyl(-72, y0 + 36, -38, 2.4, 18, CH, { n: 8 }), box(-66, y0 + 52, -38, 12, 3, 4, CH, { r: 1.5 })); }
        else {
          const ft = k === 'royal' ? GOLD : k === 'candy' ? P.b : P.b === CR || P.b === '#fffaf1' ? '#c9d3d8' : P.b;
          o.push(ball(-64, 0, -26, 5, ft), ball(64, 0, -26, 5, ft), ball(-64, 0, 26, 5, ft), ball(64, 0, 26, 5, ft), cyl(0, 6, 0, 82, 6, sh, { rz: 40, n: 20 }), cyl(0, 6, 0, 77, 26, '#a9def0', { rz: 35, n: 20, emit: 1 }), ...quarters((a0, a1) => arcW(0, 6, 0, 85, 44, 8, 38, a0, a1, sh)), cyl(-72, 44, 0, 3, 14, k === 'royal' ? GOLD : '#c9d3d8', { n: 8 }), box(-66, 55, 0, 12, 3, 4, k === 'royal' ? GOLD : '#c9d3d8', { r: 1.5 }));
          if (k === 'royal') o.push(jewel(-72, 58, 0, 4), cyl(0, 43.5, 0, 86, 1.5, '#fff1a8', { rz: 45, n: 20 }));
        }
        const bub = k === 'candy' ? [[-40, 10, 9], [-26, -14, 8], [30, 12, 10], [46, -8, 8], [0, 18, 8], [-10, -20, 7], [58, 12, 7], [-56, -4, 7], [14, -4, 9], [-14, 6, 7]] : [[-40, 10, 7], [-28, -14, 6], [30, 12, 8], [46, -8, 6], [0, 18, 6], [58, 12, 5]];
        bub.forEach(([x, z, r], i) => o.push(ball(x, 29, z, r, k === 'candy' ? [WH, '#e6ddff', '#d8f3ff'][i % 3] : WH)));
        return o; } }; },
    bsink: S => ({ w: 60, d: 50, round: 1, act: 'wash', use: { x: 0, z: 44 }, build: P => { const k = S.k, fc = k === 'royal' ? GOLD : CH;
      if (k === 'junk') return [cyl(0, 0, 0, 14, 40, TIN, { rg: [[0, 0, 0.8], [40, 0, 1]], n: 12 }), cyl(0, 40, 0, 26, 12, CR, { rz: 20, rg: [[0, 0, 0.6], [12, 0, 1]] }), cyl(0, 52, 0, 20, 0.6, '#cfe6ee', { rz: 14 }), patch(10, 44, 19.6, 6, 6, '#a99a84'), cyl(16, 52, -10, 5, 9, '#c9a85a', { n: 8 })];
      if (k === 'cot') return [...legs(S, P, 22, 16, 40, 3), box(0, 40, 0, 58, 5, 44, P.w, { r: 6, bev: 1.5 }), cyl(0, 45, 0, 20, 9, WH, { rg: [[0, 0, 0.7], [9, 0, 1]] }), cyl(18, 45, -10, 6, 16, P.a, { rg: [[0, 0, 1], [10, 0, 0.7], [16, 0, 0.9]] }), box(0, 10, 0, 50, 3, 38, P.w, { r: 2 })];
      if (k === 'mod') return [box(0, 0, 0, 66, 8, 44, DK, { r: 2 }), box(0, 8, 0, 66, 34, 44, P.w, { r: 3 }), box(0, 24, 22.2, 60, 1, 0.8, shade(P.w, 0.8)), box(0, 42, 0, 68, 4, 46, '#e9e5dc', { r: 2 }), cyl(0, 46, 2, 16, 10, WH, { rg: [[0, 0, 0.8], [10, 0, 1]] }), cyl(0, 46, -16, 2, 20, DK, { n: 8 }), box(0, 64, -10, 3, 2, 12, DK, { r: 1 })];
      if (k === 'candy') return [ball(0, 0, 0, 18, P.b, { sy: 1.2, k: 6, n: 14 }), cyl(0, 40, 0, 30, 14, P.a, { rz: 24, rg: [[0, 0, 0.55], [10, 0, 1], [14, 0, 1]] }), cyl(0, 54, 0, 24, 0.6, '#cfe6ee', { rz: 18 }), ...drips(0, 54, 22, 40, P.aL, 4), cyl(0, 54, -17, 3, 12, P.w, { n: 8 }), ...spr(0, 4, 0, 18, 14, 4)];
      const pc = k === 'royal' ? '#f4f1ea' : P.a;
      return [cyl(0, 0, 0, 10, 46, pc, { rg: [[0, 0, 1.3], [46, 0, 1]], n: 12 }), cyl(0, 44, 0, 30, 14, pc, { rz: 24, rg: [[0, 0, 0.55], [10, 0, 1], [14, 0, 1]] }), cyl(0, 58, 0, 24, 0.6, '#cfe6ee', { rz: 18 }), cyl(0, 58, -17, 3, 12, fc, { n: 8 }), box(0, 68, -12, 4, 3, 10, fc, { r: 1.5 }), cyl(18, 58, -14, 4, 8, k === 'royal' ? '#8f7bff' : '#f2c255', { n: 8 }), ...(k === 'royal' ? [cyl(0, 0, 0, 14, 4, GOLD), cyl(0, 56, 0, 31, 2, GOLD, { rz: 25 })] : k === 'retro' ? [cyl(0, 54, 0, 31, 2, CH, { rz: 25 })] : [])];
    } }),
    basket: S => ({ w: 50, d: 50, round: 1, build: P => [cyl(0, 0, 0, 20, 36, S.k === 'junk' ? '#c4a882' : P.w, { rg: [[0, 0, 0.82], [36, 0, 1]], n: 14 }), ...[8, 18, 28].map(y => cyl(0, y, 0, 20 * (0.82 + 0.18 * y / 36) + 0.4, 1.4, shade(S.k === 'junk' ? '#c4a882' : P.w, 0.8), { n: 14 })), ball(-6, 32, 2, 9, P.a, { sy: 0.7 }), ball(6, 33, -2, 8, P.b === CR ? '#84b6c9' : P.b, { sy: 0.7 }), ball(2, 38, 4, 6, CR, { sy: 0.6 })] }),
    rack: S => ({ w: 74, d: 30, build: P => { const k = S.k, pc = k === 'junk' ? '#8a8f94' : k === 'royal' ? GOLD : k === 'mod' ? DK : k === 'candy' ? WH : k === 'retro' ? CH : P.wD;
      const o = [box(-32, 0, 0, 12, 4, 24, pc, { r: 3 }), box(32, 0, 0, 12, 4, 24, pc, { r: 3 }), cyl(-32, 4, 0, 2.4, 80, pc, { n: 8 }), cyl(32, 4, 0, 2.4, 80, pc, { n: 8 })];
      if (k === 'mod') [30, 46, 62].forEach(y => o.push(slabX(0, y, 0, 66, 3, 3, pc, { r: 1.5 }))); else o.push(slabX(0, 80, 0, 70, 4, 4, pc, { r: 2 }), slabX(0, 50, 0, 66, 3, 3, pc, { r: 1.5 }));
      o.push(slab(-12, 30, 2, 30, 52, 4, k === 'candy' ? P.a : P.a, { r: 6, soft: 1 }), slab(14, 40, 3, 26, 42, 4, k === 'junk' ? '#c9a85a' : P.b === CR ? '#84b6c9' : P.b, { r: 6, soft: 1 }), box(-12, 34, 4.2, 26, 3, 0.6, shade(P.a, 0.85)));
      if (k === 'candy') o.push(ball(-32, 84, 0, 5, NE[1]), ball(32, 84, 0, 5, NE[4])); if (k === 'royal') o.push(jewel(-32, 84, 0, 4), jewel(32, 84, 0, 4));
      return o; } }),
    shower: S => ({ w: 90, d: 86, act: 'wash', use: { x: 0, z: 6, inside: 1 }, inside: [0, 6, 0], build: P => { const k = S.k, pc = k === 'royal' ? GOLD : k === 'junk' ? '#8a8f94' : k === 'mod' ? DK : CH, wall = k === 'junk' ? '#e8e1ca' : k === 'royal' ? '#f4f1ea' : WH;
      const o = [box(0, 0, 0, 90, 6, 86, k === 'candy' ? P.b : wall, { r: 6 }), cyl(0, 6, 0, 30, 0.6, '#b9dbe4', { rz: 28 }), box(0, 6, -40, 88, 150, 6, wall, { r: 2 })];
      for (let y = 20; y < 150; y += 18) o.push(box(0, y, -36.8, 86, 1, 0.6, k === 'candy' ? NE[(y / 18 | 0) % 6] : shade(wall, 0.9)));
      o.push(cyl(-28, 6, -36, 2, 128, pc, { n: 8 }), box(-14, 132, -34, 30, 3, 3, pc, { r: 1.5 }), cyl(0, 124, -30, k === 'mod' ? 14 : 8, 6, pc, { rg: [[0, 0, 0.5], [6, 0, 1]] }), box(-28, 64, -34, 8, 6, 4, pc, { r: 2 }));
      if (k === 'mod') o.push(box(28, 6, 0, 2, 150, 80, '#cfe8f0', { r: 1 }), box(0, 6, 41, 56, 150, 2, '#cfe8f0', { r: 1 }));
      else { o.push(cyl(-44, 6, 40, 1.6, 152, pc, { n: 6 }), cyl(44, 6, 40, 1.6, 152, pc, { n: 6 }), slabX(0, 156, 40, 92, 3, 3, pc, { r: 1.5 }), slab(-24, 30, 40, 40, 124, 4, k === 'junk' ? '#c9a85a' : P.a, { r: 6, soft: 1 })); if (k === 'candy') o.push(...[0, 1, 2, 3, 4].map(i => box(-24, 50 + i * 20, 42.2, 40, 8, 0.6, NE[i], { r: 2 }))); if (k === 'junk') o.push(patch(-30, 80, 42.2, 12, 10, '#8fa8a0')); }
      if (k === 'royal') o.push(jewel(0, 158, -40, 6), box(0, 0, 0, 92, 3, 88, GOLD, { r: 6 }));
      return o; } }),

    bed: S => { const k = S.k; return { w: 140, d: 186, act: 'nap', seats: [{ x: -30, z: -30, h: k === 'junk' ? 26 : k === 'mod' ? 36 : 46, k: 'nap' }, { x: 30, z: -30, h: k === 'junk' ? 26 : k === 'mod' ? 36 : 46, k: 'nap' }], build: P => { const o = [];
      if (k === 'junk') return [pillowY(0, 0, 4, 134, 20, 176, '#e8e1ca'), patch(-40, 6, 92.2, 18, 8, '#c4a882'), cush(0, 16, 36, 130, 10, 104, P.a, { r: 14 }), pillowY(-26, 20, -62, 54, 10, 30, '#f1ead6'), pillowY(28, 18, -58, 44, 8, 26, P.b), box(-50, 26, 40, 22, 1, 20, P.b, { r: 3 }), box(30, 26, 60, 18, 1, 16, '#8fa8a0', { r: 3 })];
      const fr = k === 'royal' ? '#f4f1ea' : k === 'retro' ? P.b : k === 'candy' ? P.b : P.w, lo = k === 'mod';
      if (lo) o.push(box(0, 0, 4, 156, 14, 196, P.w, { r: 6, bev: 2 }), box(0, 0, 4, 136, 4, 176, DK, { r: 4 }));
      else o.push(...legs(S, P, 62, 84, 6, 4), box(0, 6, 4, 136, 18, 172, fr, { r: 10, bev: 3 }));
      const y0 = lo ? 0 : 0; o.push(pillowY(0, 20 + y0 - (lo ? 6 : 0), 6, 128, 14, 164, WH), box(0, 18 - (lo ? 6 : 0), 30, 134, 26, 114, P.a, { r: 14, bev: 7, soft: 1 }), pillowY(0, 41 - (lo ? 6 : 0), -25, 134, 6, 16, mix(P.a, '#ffffff', 0.55)), pillowY(-30, 33 - (lo ? 6 : 0), -60, 50, 12, 28, WH), pillowY(30, 33 - (lo ? 6 : 0), -60, 50, 12, 28, WH));
      if (k === 'cot') [[-44, 10], [0, 40], [44, 10], [-22, 70], [22, 70], [-44, 60], [44, 50]].forEach(([x, z], i) => o.push(box(x, 44.2, z, 26, 0.6, 22, [P.b, '#f2c255', '#84b6c9', '#e3946a'][i % 4], { r: 2 })));
      if (k === 'candy') { [-50, -25, 0, 25, 50].forEach((x, i) => o.push(ball(x, 20, -92, 20 - Math.abs(i - 2) * 2, '#fffdf5', { sz: 0.6 }))); o.push(...spr(0, 44, 30, 110, 90, 12)); }
      else if (k === 'royal') { o.push(slab(0, 6, -91, 140, 76, 10, P.a, { r: 40, soft: 1 }), slab(0, 4, -96.5, 146, 82, 2, GOLD, { r: 42 }), jewel(0, 86, -93, 7)); [[-68, -88], [68, -88], [-68, 88], [68, 88]].forEach(([x, z]) => o.push(cyl(x, 0, z, 4, 168, GOLD, { n: 10 }), jewel(x, 196, z, 4))); o.push(slabX(0, 166, -88, 140, 5, 5, GOLD, { r: 2 }), slabX(0, 166, 88, 140, 5, 5, GOLD, { r: 2 }), box(-68, 166, 0, 5, 5, 176, GOLD, { r: 2 }), box(68, 166, 0, 5, 5, 176, GOLD, { r: 2 }), slab(0, 140, -88, 136, 28, 4, P.a, { r: 10, soft: 1 }), slab(-64, 40, -84, 18, 126, 4, P.a, { r: 8, soft: 1 }), slab(64, 40, -84, 18, 126, 4, P.a, { r: 8, soft: 1 }), ...[-48, -16, 16, 48].map(x => ball(x, 140, -85, 3, GOLD, { k: 3, n: 8 }))); }
      else if (k === 'retro') o.push(slab(0, 6, -91, 140, 70, 12, P.a, { r: 46, soft: 1 }), slab(0, 50, -84.6, 110, 4, 1, CH, { r: 2 }));
      else if (lo) o.push(slab(0, 0, -96, 156, 48, 8, P.w, { r: 4 }), box(-84, 0, -60, 30, 30, 40, P.w, { r: 3 }));
      else o.push(slab(0, 6, -91, 136, 60, 10, P.w, { r: 30, soft: 1 }), slab(0, 26, -85.6, 106, 32, 1.4, P.wL, { r: 16 }), cyl(-70, 0, -90, 6, 72, P.wD, { n: 12 }), cyl(70, 0, -90, 6, 72, P.wD, { n: 12 }), ball(-70, 72, -90, 7, P.wD), ball(70, 72, -90, 7, P.wD));
      if (!lo && k !== 'royal') o.push(slab(0, 6, 90, 140, 30, 8, fr, { r: 10, soft: 1 }));
      return o; } }; },
    nightstand: S => ({ w: 48, d: 42, act: 'lights', glow: v => v === 'on' ? { y: 72, r: 70 } : null, build: (P, v) => { const k = S.k, on = v === 'on', o = [];
      if (k === 'junk') { o.push(box(0, 0, -19, 46, 46, 4, shade(OLD, 0.85)), box(-21, 0, 0, 4, 46, 40, OLD), box(21, 0, 0, 4, 46, 40, OLD), box(0, 0, 0, 46, 4, 40, OLD), box(0, 42, 0, 46, 4, 40, OLD), ...book(-2, 4, -2, ['#8fa8a0', '#c9a85a']), cyl(-6, 46, 0, 9, 2, TIN, { n: 10 }), cyl(-6, 48, 0, 4, 12, CR, { n: 10 })); if (on) o.push(...flame(-6, 60, 0)); return o; }
      const c = k === 'royal' ? '#f4f1ea' : k === 'candy' ? P.a : P.w, lg = k !== 'cot' && k !== 'royal' && k !== 'mod' ? 0 : 8, y0 = k === 'mod' ? 14 : lg;
      if (k === 'mod') o.push(cyl(0, 0, 0, 2, 14, DK, { n: 6 }), cyl(0, 0, 0, 14, 2, DK)); else if (lg) o.push(...legs(S, P, 18, 14, lg, 3));
      o.push(box(0, y0, 0, 48, k === 'mod' ? 32 : 40, 42, c, { r: k === 'candy' ? 12 : 5, bev: 2 }), box(0, y0 + 20, 21, 40, k === 'mod' ? 8 : 14, 1.2, mix(c, '#ffffff', 0.3), { r: 3 }), knob(S, 0, y0 + 25, 21.8));
      if (k !== 'mod') o.push(box(0, y0 + 4, 21, 40, 14, 1.2, mix(c, '#ffffff', 0.3), { r: 3 }), knob(S, 0, y0 + 9, 21.8));
      const ty = y0 + (k === 'mod' ? 32 : 40);
      if (k === 'candy') o.push(...drips(0, ty, 21, 40, P.b, 4), ball(-6, ty, -4, 10, P.b, { sy: 0.6 }), ball(-6, ty + 10, -4, 4, '#e2554a'));
      if (k === 'royal') o.push(box(0, ty - 2, 0, 50, 3, 44, GOLD, { r: 5 }), cyl(-6, ty, -4, 7, 3, GOLD), cyl(-6, ty + 3, -4, 2, 10, GOLD, { n: 8 }), cyl(-6, ty + 13, -4, 3, 10, CR, { n: 8 }), ...(on ? flame(-6, ty + 23, -4) : []));
      else if (k !== 'candy') o.push(cyl(-6, ty, -4, 8, 3, k === 'retro' ? CH : P.b), cyl(-6, ty + 3, -4, 2, 14, k === 'retro' ? CH : P.wD, { n: 8 }), cyl(-6, ty + 14, -4, k === 'retro' ? 10 : 14, 16, on ? '#fff1a8' : k === 'retro' ? P.a : '#fff4cc', k === 'retro' ? { rg: [[0, 0, 0.7], [8, 0, 1], [16, 0, 0.7]], emit: on } : { rg: [[0, 0], [16, 5]], emit: on }));
      else if (on) o.push(ball(-6, ty + 6, -4, 6, '#fff1a8', { emit: 1 }));
      return o; } }),
    wardrobe: S => ({ w: 106, d: 54, build: P => { const k = S.k, o = [], c = k === 'junk' ? OLD2 : k === 'royal' ? '#f4f1ea' : k === 'candy' || k === 'retro' ? P.a : P.w, dL = mix(c, '#ffffff', 0.25);
      if (k === 'mod') { o.push(box(0, 0, 0, 104, 156, 52, c, { r: 3 }), box(-24, 6, 26.6, 52, 146, 1.2, dL, { r: 2 }), box(24, 6, 27.8, 52, 146, 1.2, mix(c, '#ffffff', 0.1), { r: 2 }), box(-4, 60, 27.6, 2, 40, 1.4, DK), box(4, 60, 28.8, 2, 40, 1.4, DK)); return o; }
      if (k !== 'junk') o.push(...legs(S, P, 42, 18, 6, 3));
      const y0 = k === 'junk' ? 0 : 6;
      o.push(k === 'candy' || k === 'retro' ? slab(0, y0, 0, 100, 152, 50, c, { r: 40, rb: 6 }) : box(0, y0, 0, 100, 152, 50, c, { r: 6, bev: 3 }));
      if (k === 'junk') o.push(box(-25, 8, 25.3, 46, 136, 1.2, dL, { r: 4 }), box(30, 8, 34, 44, 136, 2, dL, { r: 4, yaw: -0.45 }), patch(-30, 100, 26.2, 14, 12, '#8fa8a0'), patch(-20, 30, 26.2, 10, 10, '#c9a85a'), ball(-5, 76, 26, 2.6, '#8a8f94', { k: 3, n: 8 }), box(0, 152, 0, 104, 6, 54, shade(c, 0.85), { r: 3 }));
      else { o.push(box(-25, y0 + 8, 25.3, 46, k === 'candy' || k === 'retro' ? 116 : 136, 1.2, dL, { r: k === 'candy' ? 16 : 4 }), box(25, y0 + 8, 25.3, 46, k === 'candy' || k === 'retro' ? 116 : 136, 1.2, dL, { r: k === 'candy' ? 16 : 4 }), knob(S, -5, y0 + 74, 26, 2.8), knob(S, 5, y0 + 74, 26, 2.8)); if (k !== 'candy' && k !== 'retro') o.push(box(0, y0 + 152, 0, 106, 8, 54, k === 'royal' ? GOLD : shade(c, 0.85), { r: 4 })); }
      if (k === 'candy') o.push(...drips(0, y0 + 150, 22, 80, P.b, 6), ...spr(0, y0 + 154, 0, 50, 30, 6));
      if (k === 'royal') o.push(jewel(0, y0 + 160, 0, 8), jewel(-48, y0 + 160, 0, 4), jewel(48, y0 + 160, 0, 4), box(-25, y0 + 70, 26, 30, 30, 0.6, GOLD, { r: 12 }), box(25, y0 + 70, 26, 30, 30, 0.6, GOLD, { r: 12 }));
      if (k === 'retro') o.push(box(0, y0 + 20, 25.4, 96, 3, 0.8, CH));
      return o; } }),
    dresser: S => ({ w: 104, d: 46, build: P => { const k = S.k, c = k === 'royal' ? '#f4f1ea' : k === 'candy' ? P.a : P.w, low = k === 'mod', H = low ? 40 : 60, o = [];
      if (!low) o.push(...legs(S, P, 44, 16, 6, 3)); else o.push(...legs(S, P, 44, 16, 14, 3));
      const y0 = low ? 14 : 6; o.push(box(0, y0, 0, 104, H, 46, c, { r: k === 'candy' ? 12 : 5, bev: 2 }));
      const n = low ? 2 : 3; for (let i = 0; i < n; i++) { const hh = (H - 8) / n; o.push(box(0, y0 + 4 + i * hh, 23.2, 94, hh - 4, 1.2, mix(c, '#ffffff', 0.3), { r: 3 }), knob(S, -24, y0 + 4 + i * hh + hh / 2 - 2, 24), knob(S, 24, y0 + 4 + i * hh + hh / 2 - 2, 24)); }
      const ty = y0 + H; o.push(box(0, ty - 2, 0, 106, 4, 48, k === 'royal' ? GOLD : shade(c, 0.9), { r: 4 }));
      if (!low) o.push(disc(0, ty + 26, -18, 22, 3, k === 'royal' ? GOLD : k === 'candy' ? P.b : P.wD), disc(0, ty + 26, -15, 18, 0.6, '#cfe6ee'), cyl(0, ty, -18, 6, 6, k === 'royal' ? GOLD : P.wD));
      o.push(cyl(32, ty + 2, 4, 6, 12, k === 'candy' ? P.b : CR, { n: 10 }), ball(-30, ty + 2, 6, 5, k === 'candy' ? NE[3] : P.b));
      if (k === 'candy') o.push(...drips(0, ty, 23, 90, P.b, 6)); if (k === 'royal') o.push(jewel(0, ty + 50, -18, 5));
      return o; } }),
    desk: S => ({ w: 116, d: 58, act: 'play', use: { x: 0, z: 50 }, build: P => { const k = S.k, c = k === 'royal' ? '#f4f1ea' : k === 'candy' ? P.a : P.w, o = [];
      if (k === 'retro') o.push(cyl(-34, 0, 0, 22, 4, CH, { rz: 16 }), cyl(-34, 4, 0, 4, 44, CH, { n: 8 }), cyl(34, 0, 0, 22, 4, CH, { rz: 16 }), cyl(34, 4, 0, 4, 44, CH, { n: 8 }), cyl(0, 48, 0, 58, 6, P.a, { rz: 29, n: 22 }));
      else { o.push(...legs(S, P, 50, 22, 48, 3.5), box(0, 48, 0, 116, 6, 58, c, { r: k === 'candy' ? 14 : 4, bev: 2 })); if (k !== 'mod') o.push(box(-34, 30, 2, 44, 18, 52, c, { r: 4 }), box(-34, 33, 28.2, 38, 12, 1, mix(c, '#ffffff', 0.3), { r: 3 }), knob(S, -34, 38, 29)); }
      o.push(...book(28, 54, 6, [P.b === CR ? '#84b6c9' : P.b, CR]), cyl(-36, 54, -14, 7, 3, k === 'mod' ? DK : P.b), cyl(-36, 57, -14, 1.6, 22, k === 'mod' ? DK : CH, { n: 6 }), cyl(-30, 76, -14, 9, 8, k === 'mod' ? DK : P.b, { rg: [[0, 0, 1], [8, 0, 0.5]] }), box(0, 54, -10, 30, 2, 22, CR, { r: 1 }), cyl(10, 54, -16, 3, 10, '#e3946a', { n: 6 }));
      if (k === 'candy') o.push(...drips(0, 54, 29, 100, P.b, 7)); if (k === 'royal') o.push(box(0, 47, 0, 118, 2, 60, GOLD, { r: 4 }), jewel(-36, 84, -14, 3));
      return o; } }),
    chest: S => ({ w: 94, d: 58, act: 'play', use: { x: 0, z: 54 }, build: P => [box(0, 0, 0, 90, 44, 54, P.w, { r: 6, bev: 2 }), box(0, 44, 0, 94, 10, 58, P.a, { r: 8, bev: 3 }), ...[[-30, 10], [0, 40], [30, 20]].map(([x, z], i) => box(x, 54, z - 28, 22, 0.6, 18, [P.b, '#f2c255', '#84b6c9'][i], { r: 2 })), ball(-18, 50, -8, 11, '#c98d58'), ball(-26, 68, -8, 4, '#c98d58'), ball(-10, 68, -8, 4, '#c98d58'), ball(22, 54, 0, 8, '#e3946a'), box(0, 18, 27.2, 26, 10, 1, P.b, { r: 3 })] }),

    swing: S => { const k = S.k; return { w: 184, d: 56, act: 'swing', anim: 'swing', pivot: [0, 146, 0], seats: [{ x: 0, z: 0, h: k === 'junk' ? 36 : 42, k: 'swing' }], build: P => { const fc = k === 'junk' ? OLD : k === 'royal' ? GOLD : k === 'candy' ? WH : k === 'retro' ? CH : '#a86b36', o = [];
      [-80, 80].forEach(x => [-20, 20].forEach(z => o.push(cyl(x, 0, z, 4, 148, fc, { n: 8 }))));
      if (k === 'candy') [-80, 80].forEach(x => [-20, 20].forEach(z => [20, 50, 80, 110, 140].forEach(y => o.push(cyl(x, y, z, 4.4, 7, '#e2554a', { n: 8 })))));
      o.push(slabX(0, 146, -20, 172, 6, 6, fc, { r: 2 }), slabX(0, 146, 20, 172, 6, 6, fc, { r: 2 }), slabX(0, 148, 0, 184, 9, 46, k === 'junk' ? OLD2 : k === 'royal' ? P.a : k === 'candy' ? P.a : '#c98d58', { r: 4 }));
      if (k === 'royal') o.push(jewel(-80, 157, 0, 6), jewel(80, 157, 0, 6));
      if (k === 'junk') o.push(cyl(0, 40, 0, 1.6, 106, '#8a6a3e', { n: 6, part: 1 }), ...quarters((a0, a1) => arcW(0, 26, 0, 24, 24, 9, 12, a0, a1, '#3b3b3b', { part: 1 })));
      else o.push(cyl(-18, 40, 0, 1.4, 106, k === 'royal' ? GOLD : '#8a6a3e', { n: 6, part: 1 }), cyl(18, 40, 0, 1.4, 106, k === 'royal' ? GOLD : '#8a6a3e', { n: 6, part: 1 }), box(0, 36, 0, 50, 6, 24, P.a, { r: 4, part: 1 }));
      return o; } }; },
    sandbox: S => ({ w: 132, d: 100, act: 'dig', inside: [0, 10, 0], use: { x: 0, z: 0, inside: 1 }, build: P => { const k = S.k, fc = k === 'junk' ? OLD : k === 'candy' ? P.a : P.w, sand = k === 'candy' ? '#fff1c8' : '#f3dca0';
      const o = [box(0, 0, 0, 116, 12, 84, sand, { r: 4 }), ball(-24, 12, -12, 18, shade(sand, 0.94), { sy: 0.35 }), box(0, 0, -46, 132, 16, 8, fc, { r: 2 }), box(-62, 0, 0, 8, 16, 84, fc, { r: 2 }), box(62, 0, 0, 8, 16, 84, fc, { r: 2 })];
      if (k === 'junk') o.push(box(-34, 0, 46, 64, 16, 8, fc, { r: 2 }), box(40, 0, 50, 40, 12, 8, OLD2, { r: 2, yaw: 0.2 }), ball(56, 12, -40, 7, '#8fc176', { sy: 1.4 }), ball(-60, 14, 38, 6, '#8fc176', { sy: 1.4 }));
      else o.push(box(0, 0, 46, 132, 16, 8, fc, { r: 2 }), cyl(34, 12, 10, 8, 12, '#7cc4e8', { rg: [[0, 0, 0.75], [12, 0, 1]], n: 10 }), box(16, 12, 22, 4, 2, 20, '#e3946a', { yaw: 0.6 }));
      if (k === 'candy') o.push(...spr(0, 12, 0, 90, 60, 10));
      return o; } }),
    pool: S => { const k = S.k, rect = k === 'mod'; return { w: 150, d: 110, round: rect ? 0 : 1, act: 'splash', inside: [0, 4, 0], seats: [{ x: -26, z: 0, h: 4, k: 'splash' }, { x: 26, z: 0, h: 4, k: 'splash' }], build: P => { const o = [];
      if (rect) return [box(0, 0, 0, 132, 12, 92, '#8fdcf5', { r: 6, emit: 1 }), box(0, 0, -50, 150, 18, 10, P.a, { r: 3 }), box(0, 0, 50, 150, 18, 10, P.a, { r: 3 }), box(-70, 0, 0, 10, 18, 90, P.a, { r: 3 }), box(70, 0, 0, 10, 18, 90, P.a, { r: 3 }), cyl(-50, 18, -50, 2, 26, CH, { n: 6 }), box(-50, 40, -46, 4, 3, 10, CH)];
      const wl = k === 'junk' ? 9 : 13, rc = k === 'junk' ? '#8fa8a0' : k === 'royal' ? '#f4f1ea' : P.a;
      o.push(cyl(0, 0, 0, 62, wl, '#8fdcf5', { rz: 42, n: 20, emit: 1 }), ...quarters((a0, a1) => arcW(0, 0, 0, 75, 55, 16, 20, a0, a1, rc, { n: 6 })), ...quarters((a0, a1) => arcW(0, 20, 0, 73, 53, 12, 4, a0, a1, k === 'royal' ? GOLD : CR, { n: 6 })));
      if (k === 'junk') o.push(patch(-30, 6, 55.4, 14, 10, '#c9a85a'), patch(36, 8, 52, 12, 8, '#b8714a'), box(60, 0, 30, 20, 2, 16, '#8fdcf5', { r: 6, emit: 1 }));
      if (k === 'candy') o.push(...quarters((a0, a1) => arcW(-30, wl, -8, 18, 14, 9, 6, a0, a1, P.b, { n: 5 })));
      if (k === 'royal') o.push(jewel(0, 24, -55, 5));
      return o; } }; },
    bench: S => { const k = S.k; return k === 'mod' ? { w: 80, d: 170, act: 'nap', seats: [{ x: 0, z: 24, h: 30, k: 'nap' }], build: P => [...legs(S, P, 32, 72, 16, 3), box(0, 16, 0, 78, 8, 166, P.w, { r: 4 }), pillowY(0, 24, 24, 72, 8, 110, P.a), prism(-36, 36, [[-82, 24], [-34, 24], [-70, 70], [-84, 66]], P.a, { soft: 1 }), pillowZ(0, 52, -64, 50, 18, 8, P.b)] }
      : { w: 144, d: 50, act: 'sit', seats: [{ x: -34, z: 2, h: 30 }, { x: 34, z: 2, h: 30 }], build: P => [...legs(S, P, 60, 16, 22, 3.5), box(0, 22, 0, 144, 8, 46, P.w, { r: 6, bev: 2 }), cyl(-62, 30, -21, 3, 34, P.wD, { n: 10 }), cyl(62, 30, -21, 3, 34, P.wD, { n: 10 }), slab(0, 40, -21, 118, 10, 5, P.w, { r: 5 }), slab(0, 54, -21, 118, 10, 5, P.w, { r: 5 }), slab(-70, 30, 0, 6, 14, 40, P.wD, { r: 6 }), slab(70, 30, 0, 6, 14, 40, P.wD, { r: 6 }), pillowY(-34, 30, 2, 44, 6, 36, P.a)] }; },
    hammock: S => ({ w: 200, d: 50, act: 'nap', anim: 'swing', pivot: [0, 110, 0], seats: [{ x: 0, z: 0, h: 44, k: 'nap' }], build: P => [box(-92, 0, 0, 14, 4, 30, P.wD, { r: 3 }), box(92, 0, 0, 14, 4, 30, P.wD, { r: 3 }), cyl(-92, 4, 0, 4, 110, P.w, { n: 8 }), cyl(92, 4, 0, 4, 110, P.w, { n: 8 }), ball(-92, 112, 0, 5, P.wD), ball(92, 112, 0, 5, P.wD), prismZ(-1, 1, [[-90, 108], [-86, 110], [-50, 52], [-56, 50]], '#c4a882', { part: 1 }), prismZ(-1, 1, [[90, 108], [86, 110], [50, 52], [56, 50]], '#c4a882', { part: 1 }), cush(0, 34, 0, 112, 14, 38, P.a, { r: 14, part: 1 }), ...[-40, -20, 0, 20, 40].map(x => box(x, 47.5, 0, 8, 0.6, 36, P.b, { r: 1, part: 1 })), pillowY(-40, 46, 0, 26, 8, 24, CR, { part: 1 })] }),
    slide: S => ({ w: 180, d: 50, act: 'slide', use: { x: 102, z: 8 }, build: P => { const k = S.k, fc = k === 'royal' ? '#f4f1ea' : k === 'candy' ? WH : k === 'retro' ? CH : P.w, rc = k === 'candy' ? P.a : P.a, o = [];
      [-14, 14].forEach(z => o.push(cyl(-76, 0, z, 2.6, 92, fc, { n: 8 }), cyl(-46, 0, z, 3.5, 92, fc, { n: 8 })));
      for (let y = 14; y < 90; y += 15) o.push(slabX(-76, y, 0, 3, 3, 30, fc, { r: 1 }));
      o.push(box(-60, 86, 0, 36, 6, 34, k === 'royal' ? GOLD : P.b === CR ? P.aD : P.b, { r: 3 }));
      if (k === 'candy') o.push(...[0, 1, 2, 3, 4, 5].map(i => prismZ(-13, 13, [[-42 + i * 22, 92 - i * 15.5], [-20 + i * 22, 92 - (i + 1) * 15.5], [-20 + i * 22, 98 - (i + 1) * 15.5], [-42 + i * 22, 98 - i * 15.5]], NE[i])));
      else o.push(prismZ(-13, 13, [[-42, 92], [90, 0], [90, 6], [-42, 98]], rc), prismZ(-15, -11, [[-42, 98], [90, 6], [90, 14], [-42, 106]], shade(rc, 0.9)), prismZ(11, 15, [[-42, 98], [90, 6], [90, 14], [-42, 106]], shade(rc, 0.9)));
      if (k === 'royal') o.push(prismX(-78, -42, [[-18, 92], [18, 92], [0, 126]], P.a), jewel(-60, 126, 0, 6), prismZ(-13, 13, [[90, 0], [100, 0], [100, 6], [90, 6]], GOLD));
      if (k === 'retro') o.push(cyl(-60, 92, 0, 3, 34, CH, { n: 6 }), disc(-60, 120, 0, 10, 1.4, '#ffd23f'));
      return o; } }),
    seesaw: S => ({ w: 180, d: 40, act: 'ride', anim: 'rock', pivot: [0, 28, 0], seats: [{ x: -66, z: 0, h: 34, k: 'ride' }, { x: 66, z: 0, h: 34, k: 'ride' }], build: P => { const k = S.k; return [prismZ(-12, 12, [[-20, 0], [20, 0], [0, 28]], k === 'retro' ? CH : P.w), box(0, 26, 0, 180, 6, 20, P.a, { r: 4, part: 1 }), pillowY(-66, 32, 0, 30, 5, 20, P.b, { part: 1 }), pillowY(66, 32, 0, 30, 5, 20, P.b, { part: 1 }), cyl(-50, 32, 0, 2, 18, k === 'retro' ? CH : P.wD, { n: 6, part: 1 }), cyl(50, 32, 0, 2, 18, k === 'retro' ? CH : P.wD, { n: 6, part: 1 }), slabX(-50, 48, 0, 4, 3, 22, k === 'retro' ? CH : P.wD, { r: 1.5, part: 1 }), slabX(50, 48, 0, 4, 3, 22, k === 'retro' ? CH : P.wD, { r: 1.5, part: 1 }), ball(0, 22, 0, 5, '#ffd23f', { part: 1 })]; } }),
    stand: S => ({ w: 120, d: 60, act: 'snack', use: { x: 0, z: 56 }, build: P => { const o = [box(0, 0, 0, 116, 50, 52, P.w === '#d5dde2' ? CR : P.w, { r: 3, bev: 2 }), box(0, 50, 0, 120, 5, 56, P.b === CR ? '#ffd23f' : P.b, { r: 3 }), box(0, 18, 26.4, 90, 22, 1, '#ffd23f', { r: 6 }), cyl(-56, 55, -24, 2.6, 66, CH, { n: 6 }), cyl(56, 55, -24, 2.6, 66, CH, { n: 6 })];
      for (let i = 0; i < 6; i++) o.push(box(-50 + i * 20, 120, -12, 20, 4, 36, i % 2 ? CR : P.a, { r: 1 }));
      o.push(cyl(-26, 55, 4, 9, 22, '#fff4b8', { rg: [[0, 0, 0.9], [22, 0, 1]], n: 12 }), cyl(-26, 77, 4, 9, 2, '#fff1a0', { n: 12 }), ...[0, 16, 32].map(x => cyl(x, 55, 10, 4.5, 11, '#ffe680', { n: 8 })), ball(38, 55, -6, 7, '#ffd23f'), ball(28, 55, -12, 6, '#ffd23f'));
      return o; } }),
    grill: S => ({ w: 90, d: 70, round: S.k === 'mod' || S.k === 'retro' ? 1 : 0, act: 'cook', use: { x: 0, z: 54 }, glow: v => S.k === 'mod' || v === 'on' ? { y: 30, r: 60 } : null, build: (P, v) => { const k = S.k, on = v === 'on', o = [];
      if (k === 'mod') { for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2; o.push(ball(34 * Math.cos(a), 0, 26 * Math.sin(a), 9, i % 2 ? '#b8b2a6' : '#a59f94', { sy: 0.8, k: 4, n: 10 })); } o.push(cyl(0, 0, 0, 26, 4, '#5a4a40', { rz: 18 }), box(-8, 4, 0, 30, 5, 6, '#8a5a34', { r: 2, yaw: 0.6 }), box(8, 4, 2, 30, 5, 6, '#8a5a34', { r: 2, yaw: -0.6 }), ...flame(0, 8, 0, on ? 2.2 : 1.6), ...flame(-8, 8, 4, on ? 1.4 : 1), ...flame(8, 8, -3, on ? 1.4 : 1)); return o; }
      if (k === 'retro') { [0, 1, 2].forEach(i => o.push(cyl(22 * Math.cos(i * 2.094 + 0.5), 0, 18 * Math.sin(i * 2.094 + 0.5), 2, 40, CH, { n: 6 }))); o.push(ball(0, 26, 0, 30, P.a, { sy: 0.5, k: 6, n: 18 }), cyl(0, 40, 0, 31, 2, CH)); if (on) o.push(cyl(0, 42, 0, 26, 1, '#ff8a3a', { emit: 1 })); else o.push(ball(0, 42, 0, 30, P.a, { sy: 0.45, k: 6, n: 18 }), cyl(0, 68, 0, 3, 5, CH, { n: 6 })); return o; }
      o.push(...[[-36, -20], [36, -20], [-36, 20], [36, 20]].map(([x, z]) => cyl(x, 0, z, 2, 32, '#5a5450', { n: 6 })), solid({ ax: 'x', sh: 'el', c: [0, 50], a: 28, b: 22, n: 16, rings: [[-42, 0], [42, 0]], col: k === 'junk' ? '#6a625c' : P.a }), box(0, 50, 0, 84, 2, 54, '#3b3b3b', { r: 2 }));
      if (k === 'junk') o.push(patch(-20, 40, 27, 12, 10, '#b8714a'), patch(16, 56, 27, 10, 8, '#b8714a'));
      if (on) o.push(...flame(-16, 50, 0, 1.2), ...flame(14, 50, 4, 1.2)); o.push(box(-12, 52, -2, 18, 4, 8, '#a86b36', { r: 3 }), box(12, 52, 6, 18, 4, 8, '#a86b36', { r: 3 }));
      return o; } }),
    tramp: S => ({ w: 150, d: 120, round: 1, act: 'bounce', inside: [0, 30, 0], use: { x: 0, z: 0, inside: 1, h: 30 }, build: P => { const k = S.k, o = [];
      for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; o.push(cyl(64 * Math.cos(a), 0, 50 * Math.sin(a), 2.6, 28, k === 'candy' ? NE[i] : DK, { n: 6 })); }
      o.push(cyl(0, 26, 0, 72, 6, k === 'candy' ? P.b : P.a, { rz: 56, n: 24 }), cyl(0, 31.5, 0, 60, 0.6, k === 'candy' ? P.a : '#3d4048', { rz: 46, n: 22 }));
      if (k === 'candy') o.push(...spr(0, 32, 0, 80, 60, 8)); else o.push(cyl(0, 32, 0, 30, 0.4, shade('#3d4048', 1.3), { rz: 23, n: 18 }));
      return o; } }),
    house: S => ({ w: 130, d: 100, act: 'play', use: { x: 0, z: 62 }, build: P => { const k = S.k, wall = k === 'candy' ? '#c98d52' : k === 'royal' ? '#f4f1ea' : P.a, roof = k === 'candy' ? CR : k === 'royal' ? P.b === GOLD ? '#4a6fd6' : P.a : P.b === '#f5f3ef' ? DK : P.b, o = [];
      o.push(box(0, 0, 0, 110, 78, 80, wall, { r: 4 }));
      if (k === 'mod') o.push(prism(-60, 60, [[-48, 76], [48, 76], [48, 96], [-48, 80]], roof));
      else o.push(prism(-62, 62, [[-50, 76], [50, 76], [0, 122]], roof));
      if (k === 'royal') o.push(cyl(-58, 0, 42, 12, 130, wall, { n: 12 }), cyl(-58, 130, 42, 14, 26, P.a, { rg: [[0, 0], [26, 13]] }), jewel(-58, 156, 42, 4), cyl(58, 0, 42, 12, 130, wall, { n: 12 }), cyl(58, 130, 42, 14, 26, P.a, { rg: [[0, 0], [26, 13]] }), jewel(58, 156, 42, 4));
      o.push(box(-18, 0, 40.4, 28, 48, 1, k === 'candy' ? P.a : shade(wall, 0.7), { r: 12 }), ball(-10, 22, 41, 2.4, GOLD, { k: 3, n: 8 }), box(24, 34, 40.4, 30, 26, 1, '#cfe8f4', { r: k === 'royal' ? 13 : 3 }), box(24, 34, 41.2, 2, 26, 0.6, CR), box(24, 46, 41.2, 30, 2, 0.6, CR));
      if (k === 'candy') o.push(...[-36, 0, 36].map((x, i) => ball(x, 70, 40, 5, NE[i * 2])), ...drips(0, 78, 41, 100, CR, 7), ...spr(0, 112, 0, 40, 40, 6));
      if (k === 'mod') o.push(box(24, 34, 40.4, 44, 34, 1, '#cfe8f4', { r: 2 }));
      return o; } }),
    merry: S => ({ w: 140, d: 120, round: 1, act: 'ride', anim: 'rock', pivot: [0, 0, 0], seats: [{ x: -36, z: 10, h: 14, k: 'ride' }, { x: 36, z: 10, h: 14, k: 'ride' }], build: P => { const k = S.k, o = [cyl(0, 0, 0, 20, 6, DK, { rz: 16 })];
      o.push(cyl(0, 6, 0, 66, 8, k === 'royal' ? '#f4f1ea' : P.a, { rz: 52, n: 24, part: 1 }));
      for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2 + 0.3; o.push(box(40 * Math.cos(a), 14, 32 * Math.sin(a), 20, 0.6, 14, k === 'royal' ? GOLD : NE[i], { r: 4, part: 1, yaw: -a })); }
      o.push(cyl(0, 14, 0, 4, k === 'royal' ? 110 : 40, k === 'royal' ? GOLD : CH, { n: 8, part: 1 }));
      if (k === 'royal') { o.push(cyl(0, 110, 0, 70, 6, P.a, { rz: 54, n: 24, part: 1 }), cyl(0, 116, 0, 70, 22, P.a, { rz: 54, n: 24, rg: [[0, 0], [22, 60]], part: 1 }), jewel(0, 136, 0, 7)); [0, 1, 2, 3].forEach(i => { const a = i / 4 * Math.PI * 2 + 0.78; o.push(cyl(56 * Math.cos(a), 14, 44 * Math.sin(a), 2, 96, GOLD, { n: 6, part: 1 })); }); }
      else { [0, 1, 2, 3].forEach(i => { const a = i / 4 * Math.PI * 2 + 0.78; o.push(cyl(46 * Math.cos(a), 14, 36 * Math.sin(a), 1.8, 30, k === 'candy' ? WH : CH, { n: 6, part: 1 })); }); if (k === 'candy') o.push(ball(0, 44, 0, 50, P.b, { sy: 0.32, sz: 0.8, part: 1 }), ...[0, 1, 2, 3, 4, 5].map(i => ball(30 * Math.cos(i * 1.05), 58, 22 * Math.sin(i * 1.05), 6, NE[i], { part: 1 })), ball(0, 64, 0, 8, '#e2554a', { part: 1 })); else o.push(cyl(0, 54, 0, 48, 3, CH, { rz: 38, n: 20, part: 1 }), ball(0, 50, 0, 10, P.b, { part: 1 })); }
      return o; } }),
    fountain: S => ({ w: 150, d: 120, round: 1, act: 'wash', use: { x: 0, z: 70 }, build: P => [cyl(0, 0, 0, 72, 22, '#f4f1ea', { rz: 56, n: 24, rg: [[0, 0], [18, 0], [22, 3]] }), cyl(0, 22, 0, 66, 0.6, '#8fdcf5', { rz: 50, n: 22, emit: 1 }), cyl(0, 0, 0, 74, 4, GOLD, { rz: 58, n: 24 }), cyl(0, 22, 0, 9, 46, '#f4f1ea', { n: 12, rg: [[0, 0, 1.4], [20, 0, 0.8], [46, 0, 1]] }), cyl(0, 68, 0, 34, 10, '#f4f1ea', { rz: 28, rg: [[0, 0, 0.6], [10, 0, 1]] }), cyl(0, 78, 0, 30, 0.6, '#8fdcf5', { rz: 24, emit: 1 }), cyl(0, 78, 0, 6, 26, GOLD, { n: 10, rg: [[0, 0, 1], [26, 0, 0.6]] }), jewel(0, 104, 0, 7), ...[0, 1, 2, 3, 4, 5].map(i => { const a = i / 6 * Math.PI * 2; return ball(28 * Math.cos(a), 30, 22 * Math.sin(a), 4, '#bfe8f6', { sy: 2.2, emit: 1 }); }), ...[[-40, 10], [40, -6], [10, 34]].map(([x, z]) => ball(x, 22, z, 5, WH, { sy: 0.5 }))] }),
    tree: S => ({ w: 40, d: 40, round: 1, build: P => S.k === 'candy' ? [cyl(0, 0, 0, 6, 100, WH, { n: 10 }), ...[20, 50, 80].map(y => cyl(0, y, 0, 6.4, 8, '#e2554a', { n: 10 })), ball(0, 96, 0, 40, P.a), ball(-30, 88, 14, 22, P.b), ball(30, 92, 10, 24, P.w), ball(0, 134, -2, 22, P.b), ...spr(0, 120, 20, 50, 20, 8), ...[[-20, 120, 36], [24, 112, 34], [4, 146, 18]].map(([x, y, z], i) => ball(x, y, z, 5, NE[i * 2]))] : [cyl(0, 0, 0, 12, 112, '#a86b36', { rg: [[0, 4], [10, 0], [112, 3]], n: 10 }), ball(0, 104, 0, 46, P.a), ball(-40, 96, 10, 32, P.a), ball(40, 100, 6, 34, P.a), ball(-14, 150, -6, 30, P.aL), ball(18, 146, 10, 28, P.aL), ball(-22, 128, 40, 5, '#ffb347'), ball(26, 118, 38, 5, '#ffb347')] }),
    bush: S => ({ w: 60, d: 60, round: 1, build: P => S.k === 'royal' ? [cyl(0, 0, 0, 22, 26, '#f4f1ea', { rg: [[0, 0, 0.8], [26, 0, 1]] }), cyl(0, 24, 0, 23, 3, GOLD), ball(0, 26, 0, 24, '#6fae50'), ball(0, 70, 0, 18, '#7ab45c'), ball(0, 104, 0, 12, '#8fc176'), cyl(0, 30, 0, 2, 80, '#a86b36', { n: 6 }), jewel(0, 128, 0, 5)] : [ball(-22, 0, 8, 18, P.aD), ball(22, 0, 6, 18, P.aD), ball(0, 0, 0, 26, P.a, { sy: 0.9 }), ball(-8, 40, 18, 3.5, CR, { k: 3, n: 8 }), ball(10, 36, 19, 3.5, '#f2c255', { k: 3, n: 8 })] }),

    stage: S => ({ w: 220, d: 90, act: 'perform', seats: [{ x: -50, z: 0, h: 24, k: 'perform' }, { x: 50, z: 0, h: 24, k: 'perform' }], build: P => { const k = S.k, o = [];
      if (k === 'junk') { [-82, -27, 28, 83].forEach((x, i) => o.push(box(x, 0, 0, 54, 18, 88, i % 2 ? OLD : OLD2, { r: 1 }), box(x, 6, 44.4, 50, 3, 0.8, '#7d6248'))); o.push(box(0, 18, 0, 222, 4, 90, '#b89a74', { r: 2 }), cyl(-90, 22, -36, 1.4, 50, '#8a8f94', { n: 6 }), ball(-90, 70, -36, 5, '#fff1a8', { emit: 1 })); return o; }
      o.push(box(0, 0, 0, 220, 24, 90, k === 'royal' ? '#f4f1ea' : P.a, { r: 12, bev: 3 }), box(0, 0, 52, 70, 10, 16, k === 'royal' ? GOLD : P.aD, { r: 4 }));
      if (k === 'royal') o.push(box(0, 23, 0, 214, 2, 84, P.a, { r: 10 }), slab(-96, 24, -40, 30, 120, 8, P.a, { r: 10, soft: 1 }), slab(96, 24, -40, 30, 120, 8, P.a, { r: 10, soft: 1 }), slab(0, 136, -40, 222, 18, 10, P.a, { r: 6, soft: 1 }), ...[-60, -20, 20, 60].map(x => jewel(x, 150, -38, 4)), box(0, 0, 0, 224, 4, 94, GOLD, { r: 12 }));
      else o.push(...[0, 1, 2, 3, 4, 5, 6, 7, 8].map(i => ball(-96 + 24 * i, 8, 45.4, 3.5, k === 'candy' ? NE[(i + 2) % 6] : NE[i % 6], { emit: 1, k: 3, n: 8 })));
      if (k === 'mod') o.push(box(0, 24, 44, 216, 2, 2, '#4fe0d0', { emit: 1 }), box(0, 24, -44, 216, 2, 2, '#8f7bff', { emit: 1 }));
      if (k === 'candy') o.push(...spr(0, 24, 0, 180, 60, 14), ...drips(0, 24, 46, 200, P.aL, 10));
      return o; } }),
    speaker: S => ({ w: S.k === 'junk' ? 70 : 54, d: 40, build: P => { const k = S.k;
      if (k === 'junk') return [box(0, 0, 0, 70, 36, 30, '#5a5f6a', { r: 6, bev: 2 }), disc(-18, 16, 15, 11, 2, '#3b3e46', { top: 2 }), disc(18, 16, 15, 11, 2, '#3b3e46', { top: 2 }), box(0, 26, 15.2, 16, 6, 1, '#9fc6c0', { r: 2, emit: 1 }), slabX(0, 40, 0, 50, 4, 4, DK, { r: 2 }), cyl(-24, 36, 0, 2, 6, DK, { n: 6 }), cyl(24, 36, 0, 2, 6, DK, { n: 6 }), patch(-28, 28, 15.6, 8, 6, '#c9a85a')];
      const body = k === 'royal' ? GOLD : k === 'candy' ? P.a : k === 'mod' ? '#2f2f3a' : P.a, cone = k === 'royal' ? '#f4f1ea' : k === 'candy' ? P.b : '#5a5f96';
      const o = [k === 'candy' ? slab(0, 0, 0, 54, 100, 40, body, { r: 26 }) : box(0, 0, 0, 54, k === 'mod' ? 120 : 96, 40, body, { r: 6, bev: 2 })];
      const ys = k === 'mod' ? [96, 64, 30] : [66, 28];
      ys.forEach((y, i) => o.push(disc(0, y, 20, i === ys.length - 1 ? 19 : 14, 2, cone, { top: 3 }), disc(0, y, 22, 6, 1, k === 'royal' ? '#8f7bff' : '#4fe0d0', { emit: 1 })));
      if (k === 'royal') o.push(jewel(0, 96, 0, 7)); if (k === 'candy') o.push(...[[-14, 100], [12, 102], [0, 108]].map(([x, y]) => ball(x, y - 10, 0, 12, '#fffdf5')));
      if (k === 'retro') o.push(box(0, 92, 20.4, 50, 3, 0.8, CH), box(0, 4, 20.4, 50, 3, 0.8, CH));
      return o; } }),
    juke: S => ({ w: 64, d: 44, act: 'party', glow: v => v === 'on' ? { y: 70, r: 95, c: 'url(#gNeon)' } : null, build: (P, v) => { const k = S.k, on = v === 'on';
      if (k === 'junk') return [box(0, 0, -19, 62, 46, 4, shade(OLD, 0.85)), box(-29, 0, 0, 4, 46, 40, OLD), box(29, 0, 0, 4, 46, 40, OLD), box(0, 0, 0, 62, 4, 40, OLD), box(0, 42, 0, 62, 4, 40, OLD), box(0, 46, 0, 56, 12, 38, '#8a5a34', { r: 3 }), cyl(-6, 58, 2, 15, 1.4, '#2b2b2b'), cyl(-6, 59.4, 2, 5, 0.6, '#e3946a'), cyl(20, 58, 12, 2, 10, CH, { n: 6 }), cyl(14, 58, -12, 3, 26, GOLD, { n: 8 }), cyl(14, 84, -12, 16, 14, GOLD, { rg: [[0, 0, 0.2], [14, 0, 1]] }), ...book(0, 4, -2, ['#8fa8a0', '#c9a85a'])];
      const body = k === 'royal' ? '#f4f1ea' : k === 'candy' ? P.b : '#a86b36', glow = k === 'candy' ? P.a : k === 'royal' ? '#8f7bff' : '#ffa940';
      const o = [box(0, 0, 0, 64, 70, 44, body, { r: 8, bev: 2 }), box(0, 6, 22, 52, 58, 1.5, glow, { r: 6 }), slab(0, 70, 0, 64, 36, 44, glow, { r: 32, soft: 1 }), slab(0, 74, 22.6, 46, 26, 1.5, on ? '#fff1a8' : '#ffe2a6', { r: 23, emit: 1 }), box(0, 10, 23.4, 40, 18, 0.8, shade(body, 0.6), { r: 3 }), disc(0, 46, 22.8, 8, 1.2, '#3b2e28'), disc(0, 46, 24, 2.5, 0.8, GOLD)];
      if (k === 'royal') o.push(prismZ(-4, 4, [[0, 122], [5, 110], [16, 108], [7, 100], [10, 88], [0, 95], [-10, 88], [-7, 100], [-16, 108], [-5, 110]].filter((p, i) => i % 2 === 0), GOLD), jewel(0, 106, 0, 4), box(0, 0, 0, 66, 4, 46, GOLD, { r: 8 }));
      if (k === 'candy') o.push(...spr(0, 104, 0, 40, 30, 7), ball(0, 104, 0, 8, '#e2554a'));
      if (k === 'retro') o.push(box(-26, 6, 23, 3, 58, 1, CH), box(26, 6, 23, 3, 58, 1, CH));
      return o; } }),
    arcade: S => ({ w: 70, d: 60, act: 'play', use: { x: 0, z: 54 }, build: P => { const k = S.k, body = k === 'candy' ? P.a : k === 'royal' ? '#f4f1ea' : P.a, o = [];
      o.push(prism(-30, 30, [[-24, 0], [24, 0], [24, 62], [14, 112], [-24, 120]], body), box(-31, 0, 0, 2, 118, 48, k === 'royal' ? GOLD : shade(body, 0.8)), box(31, 0, 0, 2, 118, 48, k === 'royal' ? GOLD : shade(body, 0.8)));
      o.push(box(0, 74, 14, 46, 32, 2, '#2b2b33', { r: 4 }), box(0, 77, 15.2, 40, 26, 0.6, k === 'candy' ? '#bfe4ff' : '#5ad0ff', { r: 3, emit: 1 }), box(-6, 86, 15.8, 14, 6, 0.4, '#ffd23f', { r: 2, emit: 1 }), box(0, 60, 22, 56, 5, 18, DK, { r: 3 }), ball(-14, 65, 24, 3, '#e2554a', { k: 3, n: 8 }), cyl(-14, 65, 24, 1, 6, DK, { n: 6 }), ball(6, 65, 24, 3, NE[0], { k: 3, n: 8 }), ball(16, 65, 22, 3, NE[1], { k: 3, n: 8 }), box(0, 110, 4, 50, 12, 2, '#fff1a8', { r: 3, emit: 1 }), box(0, 20, 24.2, 20, 14, 0.8, '#3b3b3b', { r: 2 }));
      if (k === 'candy') o.push(...drips(0, 120, -6, 46, P.b, 5), ball(0, 118, -6, 8, '#e2554a'));
      if (k === 'royal') o.push(jewel(0, 122, -14, 6));
      return o; } }),
    dj: S => ({ w: 130, d: 56, act: 'party', glow: v => v === 'on' ? { y: 60, r: 100, c: 'url(#gNeon)' } : null, build: (P, v) => { const k = S.k, on = v === 'on', body = k === 'royal' ? '#f4f1ea' : k === 'mod' ? '#2f2f3a' : P.a, o = [];
      o.push(box(0, 0, 0, 130, 50, 52, body, { r: 6, bev: 2 }), box(0, 50, 0, 134, 6, 56, k === 'royal' ? GOLD : '#3d4048', { r: 4 }));
      for (let i = 0; i < 6; i++) o.push(box(-50 + i * 20, 10, 26.4, 16, 30, 1, k === 'royal' ? ['#cfe6f7', '#ffffff'][i % 2] : NE[i], { r: 3, emit: on ? 1 : 0 }));
      [-34, 34].forEach(x => o.push(cyl(x, 56, 4, 18, 2, '#2b2b2b'), cyl(x, 58, 4, 6, 0.6, k === 'royal' ? GOLD : '#4fe0d0', { emit: 1 }), cyl(x + 14, 58, -8, 1.4, 6, CH, { n: 6 })));
      o.push(box(0, 56, 4, 24, 3, 20, '#5a5f6a', { r: 2 }), slab(0, 56, -18, 34, 22, 2, '#3d4048', { r: 3 }), box(0, 59, -16.6, 30, 18, 0.4, '#6cc6ee', { r: 2, emit: 1 }));
      if (k === 'royal') o.push(jewel(-60, 56, 22, 4), jewel(60, 56, 22, 4)); if (k === 'mod') o.push(box(0, 0, 26.6, 126, 3, 0.6, '#4fe0d0', { emit: 1 }));
      return o; } }),
    pillar: S => ({ w: 44, d: 44, round: 1, glow: () => ({ y: 70, r: 70, c: 'url(#gNeon)' }), build: P => { const k = S.k, c = k === 'royal' ? '#cfe6f7' : k === 'mod' ? '#4fe0d0' : P.a, o = [cyl(0, 0, 0, 20, 8, k === 'royal' ? GOLD : DK), cyl(0, 8, 0, 15, 110, c, { n: 16, emit: 1 }), cyl(0, 118, 0, 20, 8, k === 'royal' ? GOLD : DK)];
      for (let y = 22; y < 118; y += 18) o.push(cyl(0, y, 0, 15.6, 2, k === 'candy' ? NE[(y / 18 | 0) % 6] : mix(c, '#ffffff', 0.5), { n: 16, emit: 1 }));
      if (k === 'royal') o.push(jewel(0, 126, 0, 8)); if (k === 'candy') o.push(ball(0, 126, 0, 14, P.b));
      return o; } }),
    bar: S => ({ w: 140, d: 56, act: 'snack', use: { x: 0, z: 54 }, build: P => { const o = [box(0, 0, 0, 136, 50, 48, P.a, { r: 8, bev: 2 }), box(0, 50, 0, 140, 6, 54, P.b === '#fffaf1' ? CR : P.b, { r: 6 }), box(0, 4, 24.4, 130, 3, 0.8, CH), box(0, 40, 24.4, 130, 3, 0.8, CH)];
      [-46, -24].forEach((x, i) => o.push(cyl(x, 56, 6, 6, 18, '#e2554a', { rg: [[0, 0, 0.7], [18, 0, 1]], n: 10 }), cyl(x, 74, 6, 6.5, 3, CR, { n: 10 }), cyl(x + 3, 74, 6, 0.8, 12, '#e2554a', { n: 4 }), ball(x, 77, 6, 2.4, '#e2554a', { k: 3, n: 8 })));
      o.push(cyl(20, 56, 0, 13, 16, '#e2554a', { rg: [[0, 0, 0.75], [16, 0, 1]] }), ...[[16, 0], [24, 3], [20, -4], [14, 4], [26, -2]].map(([x, z]) => ball(x, 70, z, 4, '#fff6d6', { k: 3, n: 8 })), box(48, 56, 0, 30, 3, 20, CR, { r: 2 }), ball(42, 59, 0, 5, '#c98d52', { sy: 0.6 }), ball(54, 59, 2, 5, '#c98d52', { sy: 0.6 }));
      return o; } }),
  };
  const prismX = prism;

  // [id, name, room, arch, band, extra]  - 8 per level, levels 1..30
  const S_ = 'style', Y_ = 'backyard';
  const LV = [
    [['saggySofa', 'Saggy Sofa', 'living', 'sofa', 'junk', { start: 1 }], ['crateTable', 'Crate Table', 'living', 'coffee', 'junk', { start: 1 }], ['boxTV', 'Box TV', 'living', 'tv', 'junk', { start: 1 }], ['dentedBowl', 'Dented Bowl', 'living', 'bowl', 'junk', { start: 1 }], ['w_peel', 'Peeling Wallpaper', S_, 's:wall', 'junk', { start: 1 }], ['f_boards', 'Creaky Boards', S_, 's:floor', 'junk', { start: 1 }], ['win_crack', 'Cracked Window', S_, 's:win', 'junk', { start: 1 }], ['l_bulb', 'Bare Bulb', S_, 's:light', 'junk', { start: 1 }]],
    [['icebox', 'Old Icebox', 'kitchen', 'fridge', 'junk', { start: 1 }], ['rustyStove', 'Rusty Stove', 'kitchen', 'stove', 'junk', { start: 1 }], ['wobblyCounter', 'Wobbly Counter', 'kitchen', 'counter', 'junk', { start: 1 }], ['crateStool', 'Milk Crate Stool', 'kitchen', 'stool', 'junk', { start: 1 }], ['patchedChair', 'Patched Armchair', 'living', 'armchair', 'junk'], ['ragRug', 'Rag Rug', 'living', 'rug', 'junk'], ['d_plank', 'Plank Door', S_, 's:door', 'junk'], ['tinPlant', 'Tin Can Sprout', 'living', 'plant', 'junk']],
    [['palletShelf', 'Crate Shelf', 'living', 'shelf', 'junk'], ['thriftLamp', 'Thrift Lamp', 'living', 'lamp', 'junk'], ['foldTable', 'Folding Table', 'kitchen', 'table', 'junk'], ['oddChair', 'Odd Chair', 'kitchen', 'chair', 'junk'], ['bucketSink', 'Bucket Sink', 'kitchen', 'counter', 'junk', { sink: 1 }], ['w_plaster', 'Patched Plaster', S_, 's:wall', 'junk'], ['f_lino', 'Old Linoleum', S_, 's:floor', 'junk'], ['a_cards', 'Postcard Wall', S_, 's:art', 'junk']],
    [['washtub', 'Tin Washtub', 'bathroom', 'tub', 'junk', { start: 1 }], ['chipBasin', 'Chipped Basin', 'bathroom', 'bsink', 'junk', { start: 1 }], ['oldBasket', 'Laundry Basket', 'bathroom', 'basket', 'junk', { start: 1 }], ['sackBag', 'Potato Sack Beanbag', 'living', 'pouf', 'junk'], ['towelHook', 'Towel Hooks', 'bathroom', 'rack', 'junk'], ['l_jar', 'Jar Lantern', S_, 's:light', 'junk'], ['win_oil', 'Oilcloth Curtains', S_, 's:win', 'junk'], ['bathMat', 'Rubber Bath Mat', 'bathroom', 'mat', 'junk']],
    [['thriftSofa', 'Thrift Store Sofa', 'living', 'sofa', 'junk', { fix: 1 }], ['spoolTable', 'Cable Spool Table', 'living', 'coffee', 'junk', { spool: 1 }], ['radio', 'Radio Cabinet', 'living', 'tv', 'junk', { radio: 1 }], ['paintHutch', 'Painted Hutch', 'kitchen', 'hutch', 'junk'], ['bathStool', 'Bath Stool', 'bathroom', 'stool', 'junk'], ['oldShower', 'Pipe Shower', 'bathroom', 'shower', 'junk'], ['t_ging', 'Gingham Trim', S_, 's:trim', 'junk'], ['a_map', 'Old Map Poster', S_, 's:art', 'junk']],
    [['oldMattress', 'Old Mattress', 'bedroom', 'bed', 'junk', { start: 1 }], ['crateStand', 'Crate Nightstand', 'bedroom', 'nightstand', 'junk', { start: 1 }], ['rickWard', 'Rickety Wardrobe', 'bedroom', 'wardrobe', 'junk', { start: 1 }], ['floralSofa', 'Floral Loveseat', 'living', 'sofa', 'cot'], ['ginghamChair', 'Gingham Armchair', 'living', 'armchair', 'cot'], ['w_daisy', 'Daisy Wallpaper', S_, 's:wall', 'cot'], ['f_oak', 'Honey Oak Floor', S_, 's:floor', 'cot'], ['win_lace', 'Lace Curtains', S_, 's:win', 'cot']],
    [['cotFridge', 'Butter Fridge', 'kitchen', 'fridge', 'cot'], ['enamelStove', 'Enamel Stove', 'kitchen', 'stove', 'cot'], ['farmCounter', 'Farmhouse Counter', 'kitchen', 'counter', 'cot'], ['cotBed', 'Patchwork Bed', 'bedroom', 'bed', 'cot'], ['quiltChest', 'Quilt Chest', 'bedroom', 'chest', 'cot'], ['braidRug', 'Braided Rug', 'living', 'rug', 'cot'], ['a_flowers', 'Pressed Flowers', S_, 's:art', 'cot'], ['l_wicker', 'Wicker Pendant', S_, 's:light', 'cot']],
    [['tireSwing', 'Tire Swing', Y_, 'swing', 'junk', { start: 1 }], ['oldSandbox', 'Old Sandbox', Y_, 'sandbox', 'junk', { start: 1 }], ['leakyPool', 'Leaky Paddling Pool', Y_, 'pool', 'junk', { start: 1 }], ['y_picket', 'Picket Fence', Y_, 's:fence', 'cot'], ['g_clover', 'Clover Lawn', Y_, 's:ground', 'cot'], ['cotStand', 'Cottage Nightstand', 'bedroom', 'nightstand', 'cot'], ['cotWard', 'Cottage Wardrobe', 'bedroom', 'wardrobe', 'cot'], ['wickerChair', 'Reading Armchair', 'bedroom', 'armchair', 'cot']],
    [['clawTub', 'Clawfoot Tub', 'bathroom', 'tub', 'cot'], ['washstand', 'Washstand', 'bathroom', 'bsink', 'cot'], ['towelLadder', 'Towel Stand', 'bathroom', 'rack', 'cot'], ['swingSet', 'Wooden Swing Set', Y_, 'swing', 'cot'], ['gardenBench', 'Garden Bench', Y_, 'bench', 'cot'], ['herbBox', 'Herb Planter', 'kitchen', 'plant', 'cot'], ['w_tile', 'Cottage Tiles', S_, 's:wall', 'cot'], ['t_pastel', 'Pastel Trim', S_, 's:trim', 'cot']],
    [['cotTable', 'Farm Table', 'kitchen', 'table', 'cot'], ['ladderChair', 'Ladder-back Chair', 'kitchen', 'chair', 'cot'], ['cotShelf', 'Cottage Bookcase', 'living', 'shelf', 'cot'], ['fringeLamp', 'Fringe Lamp', 'living', 'lamp', 'cot'], ['cotDresser', 'Chest of Drawers', 'bedroom', 'dresser', 'cot'], ['win_flower', 'Flower Box Window', S_, 's:win', 'cot'], ['hammock', 'Rope Hammock', Y_, 'hammock', 'cot'], ['d_arch', 'Arched Door', S_, 's:door', 'cot']],
    [['crateStage', 'Pallet Stage', 'dance', 'stage', 'junk', { start: 1 }], ['boombox', 'Boombox', 'dance', 'speaker', 'junk', { start: 1 }], ['recPlayer', 'Record Player', 'dance', 'juke', 'junk', { start: 1 }], ['boothSofa', 'Diner Booth Sofa', 'living', 'sofa', 'retro'], ['vinylChair', 'Vinyl Armchair', 'living', 'armchair', 'retro'], ['f_check', 'Checker Floor', S_, 's:floor', 'retro'], ['w_burst', 'Starburst Wallpaper', S_, 's:wall', 'retro'], ['l_neon', 'Neon Ring Light', S_, 's:light', 'retro']],
    [['dinerFridge', 'Diner Fridge', 'kitchen', 'fridge', 'retro'], ['chromeStove', 'Chrome Range', 'kitchen', 'stove', 'retro'], ['sodaCounter', 'Soda Counter', 'kitchen', 'counter', 'retro'], ['spinStool', 'Spin Stool', 'kitchen', 'stool', 'retro'], ['formicaTable', 'Formica Table', 'kitchen', 'table', 'retro'], ['dinerChair', 'Diner Chair', 'kitchen', 'chair', 'retro'], ['a_clock', 'Atomic Clock', S_, 's:art', 'retro'], ['win_port', 'Porthole Window', S_, 's:win', 'retro']],
    [['jukebox', 'Jukebox', 'dance', 'juke', 'retro'], ['arcade', 'Arcade Cabinet', 'dance', 'arcade', 'retro'], ['l_disco', 'Disco Ball', S_, 's:light', 'retro'], ['f_lightup', 'Light-Up Tiles', S_, 's:floor', 'retro'], ['retroTV', 'Rounded TV', 'living', 'tv', 'retro'], ['lavaLamp', 'Lava Lamp', 'living', 'lamp', 'retro'], ['kidneyTable', 'Boomerang Table', 'living', 'coffee', 'retro'], ['a_records', 'Record Wall', S_, 's:art', 'retro']],
    [['pastelTub', 'Pastel Tub', 'bathroom', 'tub', 'retro'], ['mintSink', 'Diner Sink', 'bathroom', 'bsink', 'retro'], ['retroBed', 'Jet-Age Bed', 'bedroom', 'bed', 'retro'], ['retroStand', 'Jet-Age Nightstand', 'bedroom', 'nightstand', 'retro'], ['tulipDesk', 'Tulip Desk', 'bedroom', 'desk', 'retro'], ['retroWard', 'Jet-Age Wardrobe', 'bedroom', 'wardrobe', 'retro'], ['t_stripe', 'Racing Stripe Trim', S_, 's:trim', 'retro'], ['d_jet', 'Jet-Age Door', S_, 's:door', 'retro']],
    [['rocketSlide', 'Rocket Slide', Y_, 'slide', 'retro'], ['seesaw', 'Seesaw', Y_, 'seesaw', 'retro'], ['kiddiePool', 'Kiddie Pool', Y_, 'pool', 'retro'], ['lemonStand', 'Lemonade Stand', Y_, 'stand', 'retro'], ['kettleGrill', 'Kettle Grill', Y_, 'grill', 'retro'], ['speakerTower', 'Speaker Tower', 'dance', 'speaker', 'retro'], ['snackBar', 'Snack Bar', 'dance', 'bar', 'retro'], ['yl_tiki', 'Party String Lights', Y_, 's:ylight', 'retro']],
    [['sectional', 'Low Sectional', 'living', 'sofa', 'mod'], ['loungeChair', 'Lounge Chair', 'living', 'armchair', 'mod'], ['slabTable', 'Slab Coffee Table', 'living', 'coffee', 'mod'], ['flatTV', 'Flat TV', 'living', 'tv', 'mod'], ['cubeShelf', 'Cube Shelf', 'living', 'shelf', 'mod'], ['arcLamp', 'Arc Lamp', 'living', 'lamp', 'mod'], ['snakePlant', 'Snake Plant', 'living', 'plant', 'mod'], ['f_herring', 'Herringbone Floor', S_, 's:floor', 'mod']],
    [['smartFridge', 'Double Fridge', 'kitchen', 'fridge', 'mod'], ['induction', 'Induction Range', 'kitchen', 'stove', 'mod'], ['island', 'Kitchen Island', 'kitchen', 'counter', 'mod'], ['barStool', 'Bar Stool', 'kitchen', 'stool', 'mod'], ['glassTable', 'Glass Table', 'kitchen', 'table', 'mod'], ['shellChair', 'Moulded Chair', 'kitchen', 'chair', 'mod'], ['w_linen', 'Linen Wall', S_, 's:wall', 'mod'], ['l_globe', 'Globe Pendant', S_, 's:light', 'mod']],
    [['soakTub', 'Soaking Tub', 'bathroom', 'tub', 'mod'], ['vanity', 'Vessel Vanity', 'bathroom', 'bsink', 'mod'], ['rainShower', 'Rain Shower', 'bathroom', 'shower', 'mod'], ['towelRail', 'Towel Rail', 'bathroom', 'rack', 'mod'], ['platBed', 'Platform Bed', 'bedroom', 'bed', 'mod'], ['floatStand', 'Pedestal Nightstand', 'bedroom', 'nightstand', 'mod'], ['slideWard', 'Sliding Wardrobe', 'bedroom', 'wardrobe', 'mod'], ['win_big', 'Picture Window', S_, 's:win', 'mod']],
    [['trampoline', 'Trampoline', Y_, 'tramp', 'mod'], ['modHouse', 'Modern Playhouse', Y_, 'house', 'mod'], ['lounger', 'Sun Lounger', Y_, 'bench', 'mod'], ['firePit', 'Fire Pit', Y_, 'grill', 'mod'], ['splashPool', 'Splash Pool', Y_, 'pool', 'mod'], ['y_slat', 'Slat Fence', Y_, 's:fence', 'mod'], ['g_patio', 'Stone Patio', Y_, 's:ground', 'mod'], ['modDesk', 'Writing Desk', 'bedroom', 'desk', 'mod']],
    [['djBooth', 'DJ Booth', 'dance', 'dj', 'mod'], ['ledPillar', 'LED Pillar', 'dance', 'pillar', 'mod'], ['glowStage', 'Glow Stage', 'dance', 'stage', 'mod'], ['soundTower', 'Sound Tower', 'dance', 'speaker', 'mod'], ['a_canvas', 'Gallery Canvas', S_, 's:art', 'mod'], ['t_min', 'Minimal Trim', S_, 's:trim', 'mod'], ['d_flush', 'Flush Door', S_, 's:door', 'mod'], ['lowDresser', 'Low Dresser', 'bedroom', 'dresser', 'mod']],
    [['marshSofa', 'Marshmallow Sofa', 'living', 'sofa', 'candy'], ['gumPouf', 'Gumdrop Pouf', 'living', 'pouf', 'candy'], ['macaronTable', 'Macaron Table', 'living', 'coffee', 'candy'], ['cloudLamp', 'Cloud Lamp', 'living', 'lamp', 'candy'], ['lollyPlant', 'Lollipop Plant', 'living', 'plant', 'candy'], ['w_candy', 'Candy Stripe Wall', S_, 's:wall', 'candy'], ['f_wafer', 'Wafer Floor', S_, 's:floor', 'candy'], ['gummyRug', 'Gummy Rug', 'living', 'rug', 'candy']],
    [['iceFridge', 'Ice-Cream Fridge', 'kitchen', 'fridge', 'candy'], ['cupOven', 'Cupcake Oven', 'kitchen', 'stove', 'candy'], ['candyCounter', 'Candy Counter', 'kitchen', 'counter', 'candy'], ['cookieTable', 'Cookie Table', 'kitchen', 'table', 'candy'], ['lollyStool', 'Lollipop Stool', 'kitchen', 'stool', 'candy'], ['gumChair', 'Gumdrop Chair', 'kitchen', 'chair', 'candy'], ['l_sprinkle', 'Sprinkle Lights', S_, 's:light', 'candy'], ['win_bonbon', 'Bonbon Window', S_, 's:win', 'candy']],
    [['bubbleTub', 'Bubble Tub', 'bathroom', 'tub', 'candy'], ['gumSink', 'Gumball Sink', 'bathroom', 'bsink', 'candy'], ['rainbowShower', 'Rainbow Shower', 'bathroom', 'shower', 'candy'], ['taffyRack', 'Taffy Towel Rack', 'bathroom', 'rack', 'candy'], ['cloudBed', 'Cloud Bed', 'bedroom', 'bed', 'candy'], ['cupStand', 'Cupcake Nightstand', 'bedroom', 'nightstand', 'candy'], ['candyWard', 'Candy Wardrobe', 'bedroom', 'wardrobe', 'candy'], ['a_rainbow', 'Rainbow Art', S_, 's:art', 'candy']],
    [['rainbowSlide', 'Rainbow Slide', Y_, 'slide', 'candy'], ['candySwing', 'Candy Cane Swing', Y_, 'swing', 'candy'], ['gumballGo', 'Gumball Spinner', Y_, 'merry', 'candy'], ['jellyTramp', 'Jelly Trampoline', Y_, 'tramp', 'candy'], ['gingerHouse', 'Gingerbread House', Y_, 'house', 'candy'], ['lollyTree', 'Lollipop Tree', Y_, 'tree', 'candy'], ['y_cane', 'Candy Cane Fence', Y_, 's:fence', 'candy'], ['g_mint', 'Mint Meadow', Y_, 's:ground', 'candy']],
    [['jellyStage', 'Jellybean Stage', 'dance', 'stage', 'candy'], ['candyJuke', 'Candy Jukebox', 'dance', 'juke', 'candy'], ['cloudSpeaker', 'Cloud Speaker', 'dance', 'speaker', 'candy'], ['sweetArcade', 'Sweet Arcade', 'dance', 'arcade', 'candy'], ['gummyPillar', 'Gummy Light Pillar', 'dance', 'pillar', 'candy'], ['t_frost', 'Frosted Trim', S_, 's:trim', 'candy'], ['d_ginger', 'Gingerbread Door', S_, 's:door', 'candy'], ['candyDresser', 'Candy Dresser', 'bedroom', 'dresser', 'candy']],
    [['throneSofa', 'Velvet Throne Sofa', 'living', 'sofa', 'royal'], ['royalChair', 'Royal Armchair', 'living', 'armchair', 'royal'], ['marbleTable', 'Marble Table', 'living', 'coffee', 'royal'], ['royalTV', 'Gilded Screen', 'living', 'tv', 'royal'], ['goldShelf', 'Golden Bookcase', 'living', 'shelf', 'royal'], ['candelabra', 'Candelabra', 'living', 'lamp', 'royal'], ['palmUrn', 'Palace Fern', 'living', 'plant', 'royal'], ['w_damask', 'Damask Wallpaper', S_, 's:wall', 'royal']],
    [['royalFridge', 'Royal Fridge', 'kitchen', 'fridge', 'royal'], ['palaceRange', 'Palace Range', 'kitchen', 'stove', 'royal'], ['marbleCounter', 'Marble Counter', 'kitchen', 'counter', 'royal'], ['banquet', 'Banquet Table', 'kitchen', 'table', 'royal'], ['throneChair', 'Throne Chair', 'kitchen', 'chair', 'royal'], ['velvetStool', 'Velvet Stool', 'kitchen', 'stool', 'royal'], ['l_chand', 'Crystal Chandelier', S_, 's:light', 'royal'], ['f_marble', 'Marble Floor', S_, 's:floor', 'royal']],
    [['goldTub', 'Golden Tub', 'bathroom', 'tub', 'royal'], ['marbleBasin', 'Marble Basin', 'bathroom', 'bsink', 'royal'], ['crystalShower', 'Crystal Shower', 'bathroom', 'shower', 'royal'], ['canopyBed', 'Canopy Bed', 'bedroom', 'bed', 'royal'], ['royalStand', 'Royal Nightstand', 'bedroom', 'nightstand', 'royal'], ['armoire', 'Grand Armoire', 'bedroom', 'wardrobe', 'royal'], ['win_arch', 'Palace Window', S_, 's:win', 'royal'], ['a_portrait', 'Royal Portrait', S_, 's:art', 'royal']],
    [['castleSlide', 'Castle Slide', Y_, 'slide', 'royal'], ['royalSwing', 'Royal Swing', Y_, 'swing', 'royal'], ['skyFountain', 'Sky Fountain', Y_, 'fountain', 'royal'], ['carousel', 'Carousel', Y_, 'merry', 'royal'], ['castleHouse', 'Castle Playhouse', Y_, 'house', 'royal'], ['topiary', 'Topiary', Y_, 'bush', 'royal'], ['y_gold', 'Golden Gate Fence', Y_, 's:fence', 'royal'], ['g_cloud', 'Cloud Lawn', Y_, 's:ground', 'royal']],
    [['royalStage', 'Royal Stage', 'dance', 'stage', 'royal'], ['starJuke', 'Star Jukebox', 'dance', 'juke', 'royal'], ['goldSpeaker', 'Golden Speaker', 'dance', 'speaker', 'royal'], ['crystalDJ', 'Crystal DJ Booth', 'dance', 'dj', 'royal'], ['skyPillar', 'Sky Pillar', 'dance', 'pillar', 'royal'], ['t_gold', 'Gold Leaf Trim', S_, 's:trim', 'royal'], ['d_palace', 'Palace Door', S_, 's:door', 'royal'], ['f_ballroom', 'Starry Ballroom', S_, 's:floor', 'royal']],
  ];
  const HIDDEN = [['t_scuff', 'Scuffed Trim', S_, 's:trim', 'junk'], ['d_scuff', 'Scuffed Door', S_, 's:door', 'junk'], ['a_none', 'Bare Wall', S_, 's:art', 'junk'], ['y_broken', 'Broken Fence', Y_, 's:fence', 'junk'], ['g_patchy', 'Patchy Lawn', Y_, 's:ground', 'junk'], ['yl_none', 'No Lights', Y_, 's:ylight', 'junk']];
  const WT = { sofa: 1.8, armchair: 1.3, coffee: 1, tv: 1.6, shelf: 1.3, lamp: 0.8, plant: 0.5, rug: 0.7, mat: 0.5, pouf: 0.8, bowl: 0.3, fridge: 1.8, stove: 1.6, counter: 1.2, hutch: 1.3, table: 1.2, chair: 0.7, stool: 0.5, tub: 2, bsink: 1.1, basket: 0.4, rack: 0.5, shower: 1.6, bed: 2, nightstand: 0.7, wardrobe: 1.5, dresser: 1.2, desk: 1.1, chest: 0.9, swing: 1.8, sandbox: 1.2, pool: 1.6, bench: 1, hammock: 1.2, slide: 1.8, seesaw: 1.3, stand: 1.2, grill: 1.1, tramp: 1.8, house: 2.2, merry: 2, fountain: 2, tree: 1.2, bush: 0.6, stage: 2.2, speaker: 0.9, juke: 1.8, arcade: 1.8, dj: 2.2, pillar: 1, bar: 1.3, wall: 1.2, floor: 1.3, trim: 0.6, win: 0.9, light: 0.7, art: 0.6, door: 0.8, fence: 1.2, ground: 1.3, ylight: 0.8 };
  const SURF = {}, ITEMS = [];
  const add = (row, lv, hidden) => { const [id, n, room, arch, band, ex] = row, e = ex || {}, isS = arch.startsWith('s:'), kind = isS ? arch.slice(2) : arch;
    const price = e.start || hidden ? 0 : Math.round((50 + lv * 28) * (WT[kind] || 1) / 10) * 10;
    const meta = { id, n, room, lv, band, arch: kind, price, start: !!e.start, hidden: !!hidden, surf: isS };
    if (isS) SURF[id] = meta;
    else { const S = Object.assign({ k: band }, e), D = A[kind](S); Object.assign(D, { n, cat: room, price, cols: BK[band].cols, lv, band, arch: kind, room, start: !!e.start, id }); X.CAT[id] = D; }
    if (!hidden) ITEMS.push(meta); };
  LV.forEach((rows, i) => rows.forEach(r => add(r, i + 1)));
  HIDDEN.forEach(r => add(r, 0, 1));
  X.BANDS = BANDS; X.SURF = SURF; X.ITEMS = ITEMS; X.ARCH = A;
  X.bandOf = lv => BANDS.find(b => lv >= b.lv[0] && lv <= b.lv[1]) || BANDS[0];
})();
