// Yard Mini Games: BOUNCE UP (the backyard's Trampolines). Side view, the camera rides up with your creature.
// Tap as it lands on the mat (deepest sag = Perfect) to bounce higher; no tap and the bounces die down. Tap in the air to twirl (+points),
// but finish the twirl before you land or you wobble. Stars hang in the sky the higher you go. 40 s.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add) return setTimeout(go, 30); const { S, cl, lerp, r2, SFX } = YG;
  const ICON = '<svg viewBox="0 0 120 84" aria-hidden="true"><rect width="120" height="84" fill="#cfeaff"/><rect y="66" width="120" height="18" fill="#9fdc6e"/>' +
    '<path d="M30 58L36 74M60 60V76M90 58L84 74" stroke="#2c2f38" stroke-width="3" stroke-linecap="round"/><ellipse cx="60" cy="56" rx="38" ry="8" fill="#9aa3b2"/><ellipse cx="60" cy="55" rx="31" ry="5.5" fill="#2f3340"/><path d="M29 55Q60 64 91 55" fill="none" stroke="#454a59" stroke-width="2"/>' +
    '<path d="M55 12L57.4 18.6L64 21L57.4 23.4L55 30L52.6 23.4L46 21L52.6 18.6Z" fill="#ffd84a"/><path d="M76 26L77.4 29.6L81 31L77.4 32.4L76 36L74.6 32.4L71 31L74.6 29.6Z" fill="#ff8fc8"/><path d="M40 34Q60 26 60 44" stroke="#fff" stroke-width="2" stroke-dasharray="2 4" fill="none"/></svg>';
  YG.add({ id: 'tramp', name: 'Bounce Up', item: 'Trampolines', color: '#7d8cff', icon: ICON, dur: 40, stars: [200, 450, 800], coinK: 0.08,
    hint: 'Tap as you land = higher · tap in the air = twirl',
    how: ['Tap just as your creature lands on the mat to bounce higher.', 'No tap and the bounces get smaller.', 'Tap in the air to twirl for points; finish it before you land!'],
    options: [{ id: 'sport', label: 'Sport Trampoline' }, { id: 'old', label: 'Old Trampoline' }],
    make(ctx) {
      const { bg, fg, W, H } = ctx, K = 108, BASE = 588, MY = 0.78, G = 9.8 * 0.72, PX = (x, y, cam) => [W / 2 + x * K, BASE - (y - cam) * K];
      const sky = S('rect', { x: -20, y: -20, width: W + 40, height: H + 40, fill: '#9fd6ff' }, bg), skyG = S('rect', { x: -20, y: -20, width: W + 40, height: H + 40, fill: 'url(#ygSky)', opacity: 1 }, bg);
      const space = S('g', { opacity: 0 }, bg); for (let i = 0; i < 40; i++) S('circle', { cx: r2(Math.random() * W), cy: r2(Math.random() * H), r: r2(0.6 + Math.random() * 1.3), fill: '#ffffff', opacity: r2(0.4 + Math.random() * 0.6) }, space);
      const world = S('g', {}, bg), ground = S('g', {}, world), deco = S('g', {}, world), ruler = S('g', {}, world), starsG = S('g', {}, world), tramp = S('g', {}, world);
      // ground: the backyard (fence, trees, grass) at the bottom of the world column
      { const g = S('g', { transform: 'translate(0 ' + (BASE - 250) + ')' }, ground); YG.yard(g, { hz: 196, flowers: false, sky: false }); }
      // clouds + birds + a balloon higher up (world metres)
      const clouds = []; for (let i = 0; i < 22; i++) { const y = 4 + i * 2.2 + Math.random() * 1.2, x = (Math.random() - 0.5) * 3.6, k = 0.5 + Math.random() * 0.7, g = S('g', { opacity: 0.85 }, deco); [[-22, 4, 15], [0, -5, 20], [22, 4, 15], [8, 7, 14]].forEach(([a, b, r]) => S('circle', { cx: a, cy: b, r, fill: '#ffffff' }, g)); clouds.push({ g, x, y, k, v: (Math.random() - 0.5) * 0.25 }); }
      const birds = [7, 12, 18].map((y, i) => { const g = S('path', { d: 'M-7 0Q-3.5 -5 0 0Q3.5 -5 7 0', fill: 'none', stroke: '#3a2a55', 'stroke-width': 2, 'stroke-linecap': 'round' }, deco); return { g, y, x: -2 + i, v: 0.6 + i * 0.2 }; });
      const bal = S('g', {}, deco); S('path', { d: 'M0 14Q3 26 -2 40', stroke: '#ffffff', 'stroke-width': 1.2, fill: 'none' }, bal); S('ellipse', { cx: 0, cy: 0, rx: 11, ry: 14, fill: '#ff7fbf' }, bal); S('ellipse', { cx: -4, cy: -5, rx: 3, ry: 4.5, fill: '#ffffff', opacity: 0.5 }, bal);
      // trampoline (two looks)
      let look = 'sport'; const matF = S('path', {}, tramp), matB = S('path', {}, tramp), pad = S('g', {}, tramp), legs = S('g', {}, tramp);
      function drawTramp(sag, cam) { const L = look === 'sport' ? { pad: '#c9ced6', padD: '#9aa3b2', mat: '#2f3340', leg: '#2c2f38' } : { pad: '#a7c79a', padD: '#7c9a70', mat: '#3a3a3a', leg: '#7a6a58' };
        const R = 1.45, y0 = PX(0, MY, cam)[1], x0 = W / 2, rx = R * K, ry = 0.17 * K; legs.innerHTML = ''; pad.innerHTML = '';
        [-1.25, 0, 1.25].forEach(x => { const a = PX(x * 0.95, MY - 0.02, cam), b = PX(x * 1.05 + (x ? Math.sign(x) * 0.12 : 0), 0, cam); S('path', { d: 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'L' + r2(b[0]) + ' ' + r2(b[1]), stroke: L.leg, 'stroke-width': 5, 'stroke-linecap': 'round' }, legs); });
        { const a = PX(-1.4, 0.02, cam), b = PX(1.4, 0.02, cam); S('path', { d: 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'Q' + r2(x0) + ' ' + r2(a[1] - 6) + ' ' + r2(b[0]) + ' ' + r2(b[1]), stroke: L.leg, 'stroke-width': 4, fill: 'none', opacity: 0.8 }, legs); YG.shadow(legs, x0, a[1] + 2, rx * 0.95, 0.18); }
        const sg = sag * K; matB.setAttribute('d', 'M' + r2(x0 - rx * 0.86) + ' ' + r2(y0) + 'Q' + r2(x0) + ' ' + r2(y0 - ry * 1.5 + sg * 0.6) + ' ' + r2(x0 + rx * 0.86) + ' ' + r2(y0)); matB.setAttribute('fill', L.mat); matB.setAttribute('stroke', 'none');
        matF.setAttribute('d', 'M' + r2(x0 - rx * 0.86) + ' ' + r2(y0) + 'Q' + r2(x0) + ' ' + r2(y0 + ry * 1.4 + sg * 2) + ' ' + r2(x0 + rx * 0.86) + ' ' + r2(y0) + 'Z'); matF.setAttribute('fill', L.mat);
        // springs + padded ring (front half drawn later over the creature's feet in fg)
        for (let i = 0; i <= 14; i++) { const u = i / 14, x = x0 - rx * 0.92 + u * rx * 1.84, y = y0 + Math.sin(u * Math.PI) * ry * 0.85; S('path', { d: 'M' + r2(x) + ' ' + r2(y - 3) + 'l2 1.5l-4 1.5l4 1.5l-2 1.5', stroke: '#b8bcc6', 'stroke-width': 1, fill: 'none' }, pad); }
        S('path', { d: 'M' + r2(x0 - rx) + ' ' + r2(y0) + 'A' + r2(rx) + ' ' + r2(ry) + ' 0 0 1 ' + r2(x0 + rx) + ' ' + r2(y0), stroke: L.padD, 'stroke-width': 9, fill: 'none' }, pad);
        padF.setAttribute('d', 'M' + r2(x0 - rx) + ' ' + r2(y0) + 'A' + r2(rx) + ' ' + r2(ry) + ' 0 0 0 ' + r2(x0 + rx) + ' ' + r2(y0)); padF.setAttribute('stroke', L.pad); padF2.setAttribute('d', padF.getAttribute('d')); padF2.setAttribute('stroke', L.padD); }
      const padF2 = S('path', { fill: 'none', 'stroke-width': 13, 'stroke-linecap': 'round' }, fg), padF = S('path', { fill: 'none', 'stroke-width': 9, 'stroke-linecap': 'round' }, fg);
      // collectible stars
      let stars = []; function seedStars() { starsG.innerHTML = ''; stars = []; for (let y = 3.2; y < 60; y += 1.6 + Math.random() * 1.4) { const gold = Math.random() < 0.18, g = S('g', {}, starsG);
          S('circle', { r: 14, fill: 'url(#ygGlow)', opacity: 0.8 }, g); S('path', { d: 'M0-11L3.2-3.4L11-2.4L5 3L6.8 11L0 6.8L-6.8 11L-5 3L-11-2.4L-3.2-3.4Z', fill: gold ? '#ffcf3a' : '#ffffff', stroke: gold ? '#e09a14' : '#ffd84a', 'stroke-width': 1.5, 'stroke-linejoin': 'round' }, g);
          stars.push({ g, x: (Math.random() - 0.5) * 0.5, y, gold, taken: 0 }); } }
      // ruler on the right: a tick every metre, label every 5; your best height as a gold line
      const best0 = (YG._trampBest || 0); let recLine = S('g', {}, world);
      const me = ctx.creature(ctx.playerKey, { yaw: 0 }); me.depth(2);
      let cy = MY, vy = 0, cam = 0, contact = -1, vin = 0, sag = 0, tapAt = -9, tw = null, twirls = 0, combo = 0, maxH = 0, lastMeter = 0, tNow = 0, perfect = 0, wob = 0, started = false, gotStars = 0, lastJ = '';
      const tToMat = () => { const a = -G / 2, b = vy, c = cy - MY, disc = b * b - 4 * a * c; if (disc < 0) return 9; const t1 = (-b - Math.sqrt(disc)) / (2 * a); return t1 > 0 ? t1 : 9; };
      function tap() { if (!ctx.playing) return; const ttm = contact < 0 ? tToMat() : 0;
        if (contact >= 0 || ttm < 0.22) { tapAt = tNow; return; }   // a landing tap, judged at take-off
        if (!tw) { tw = { t0: tNow, d: 520 }; SFX.whoosh(); } else if (!tw.q) tw.q = 1; }
      const api = {
        option(id) { look = id; drawTramp(0, cam); },
        start() { cy = 2.0; vy = 0; cam = 0; contact = -1; twirls = 0; combo = 0; maxH = 0; lastMeter = 0; perfect = 0; tw = null; gotStars = 0; seedStars(); started = true; look = ctx.G._opt || 'sport'; me.play('idle'); },
        down(p) { tap(); }, key(k, dn) { if (dn && (k === ' ' || k === 'ArrowUp' || k === 'Enter')) { tap(); return true; } },
        _tap: tap, _state: () => ({ cy: +cy.toFixed(2), vy: +vy.toFixed(2), contact, ttm: +tToMat().toFixed(2), maxH: +maxH.toFixed(1), twirls, lastJ }),
        timeUp() { ctx.finish({ sub: 'Highest ' + maxH.toFixed(1) + ' m · ' + gotStars + ' stars · ' + twirls + ' twirls' }); },
        celebrate(st) { me.play(st >= 2 ? 'happy' : 'idle'); },
        update(dt, t) { tNow = t; let E = {};
          if (started) {
            if (contact < 0) { vy -= G * dt; cy += vy * dt; if (cy <= MY && vy < 0) { contact = 0; vin = -vy; cy = MY; SFX.boing();
                if (tw) { tw = null; wob = 1; combo = 0; ctx.toast('Wobble!', W / 2, 300, '#ff7a8a'); E.spin = 0; } } }
            if (contact >= 0) { contact += dt; const CT = 0.22, u = contact / CT; sag = Math.sin(Math.min(1, u) * Math.PI) * Math.min(0.42, 0.08 + vin * 0.035); cy = MY - sag;
              if (u >= 1) { // take off: judge the tap against the deepest moment (contact middle)
                const mid = t - CT * 500, d = Math.abs(tapAt - mid); let e = 0.84, boost = 0, j = '';
                if (wob) { e = 0.62; wob = 0; j = 'wobble'; } else if (d < 110) { e = 1.0; boost = 1.55; j = 'Perfect!'; perfect++; combo++; } else if (d < 210) { e = 1.0; boost = 0.6; j = 'Good'; combo++; } else combo = 0;
                if (j && j !== 'wobble') { const p = PX(0, MY, cam); ctx.toast(j + (combo >= 3 ? ' x' + combo : ''), p[0] + 70, p[1] - 30, j === 'Perfect!' ? '#ffe36e' : '#8fe0ff'); SFX.pop(); }
                lastJ = j || 'none'; vy = Math.min(24, Math.max(4.3, vin * e + boost)); contact = -1; sag = 0; tapAt = -9; } }
            // height score: +5 for every new metre of height reached this round
            const hgt = cy - MY; if (hgt > maxH) { maxH = hgt; const m = Math.floor(maxH); if (m > lastMeter) { ctx.add(5 * (m - lastMeter)); lastMeter = m; if (m % 5 === 0) { ctx.toast(m + ' m!', W / 2 + 90, 200, '#ffffff'); SFX.score(); } } }
            // stars
            for (const s of stars) if (!s.taken && Math.abs(s.y - (cy + 0.45)) < 0.45) { s.taken = 1; gotStars++; const p = PX(s.x, s.y, cam); ctx.add(s.gold ? 30 : 10, p[0] + 40, p[1], s.gold ? '+30' : '+10', s.gold ? '#ffcf3a' : '#ffffff'); ctx.burst(p[0], p[1], 'star', 8, { v: 110, life: 0.6, g: 0 }); SFX.pop(); s.g.setAttribute('opacity', 0); }
            // twirl
            if (tw) { const u = (t - tw.t0) / tw.d; E.spin = 360 * YG.SM(Math.min(1, u)); if (u >= 1) { twirls++; const pts = 15 + Math.min(30, combo * 3); const p = PX(0, cy + 0.6, cam); ctx.add(pts, p[0] - 80, p[1], 'Twirl! +' + pts, '#ff8fc8'); if (tw.q) tw = { t0: t, d: 520 }; else tw = null; } }
          }
          // the creature: squash on the mat, arms up flying up, tuck at the top
          const up = cl(vy / 10, -1, 1); if (contact >= 0) Object.assign(E, { sq: sag * 0.9, armL: 10, armR: 10, close: 0.3 }); else Object.assign(E, { armL: lerp(50, 150, cl(up, 0, 1)) + (up < 0 ? 40 * -up : 0), armR: lerp(50, 150, cl(up, 0, 1)) + (up < 0 ? 40 * -up : 0), sq: -0.05 * Math.abs(up), smile: 0.6, hap: Math.abs(up) < 0.3 ? 0.8 : 0.3, open: cl(up, 0, 1) * 0.4, footL: 2 * cl(-up, 0, 1), footR: 2 * cl(-up, 0, 1) });
          me.pose(E);
          // camera: keep the creature in the upper part of the screen as it climbs
          const tc = Math.max(0, cy - 2.6); cam += (tc - cam) * (1 - Math.exp(-dt * 7)); world.setAttribute('transform', 'translate(0 ' + r2(cam * K) + ')');
          const p = PX(0, cy, cam); me.set(p[0], p[1] + K * 0.02, 1.02 * K);
          drawTramp(sag, 0); // trampoline is drawn in world coords (cam 0) inside the world group; the fg ring follows the camera
          padF.setAttribute('transform', 'translate(0 ' + r2(cam * K) + ')'); padF2.setAttribute('transform', 'translate(0 ' + r2(cam * K) + ')');
          // sky: day blue -> evening violet -> starry
          const hk = cl(cam / 35, 0, 1); skyG.setAttribute('opacity', r2(1 - hk)); sky.setAttribute('fill', hk < 0.5 ? '#8fb4ff' : '#4a3a9a'); space.setAttribute('opacity', r2(cl((cam - 18) / 15, 0, 1)));
          clouds.forEach(c => { c.x += c.v * dt; if (c.x > 2.4) c.x = -2.4; if (c.x < -2.4) c.x = 2.4; const q = PX(c.x, c.y, 0); c.g.setAttribute('transform', 'translate(' + r2(q[0]) + ' ' + r2(q[1]) + ') scale(' + c.k + ')'); });
          birds.forEach(b => { b.x += b.v * dt; if (b.x > 2.2) b.x = -2.2; const q = PX(b.x, b.y, 0); b.g.setAttribute('transform', 'translate(' + r2(q[0]) + ' ' + r2(q[1] + Math.sin(t / 200 + b.y) * 3) + ') scale(1 ' + r2(0.6 + 0.4 * Math.abs(Math.sin(t / 120 + b.y))) + ')'); });
          { const q = PX(-1.2 + Math.sin(t / 3000) * 0.3, 24 + Math.sin(t / 1700) * 0.4, 0); bal.setAttribute('transform', 'translate(' + r2(q[0]) + ' ' + r2(q[1]) + ')'); }
          stars.forEach(s => { if (!s.taken) { const q = PX(s.x, s.y, 0); s.g.setAttribute('transform', 'translate(' + r2(q[0]) + ' ' + r2(q[1]) + ') rotate(' + r2(Math.sin(t / 400 + s.y) * 12) + ') scale(' + r2(1 + 0.08 * Math.sin(t / 250 + s.y)) + ')'); } });
          if (!api._ru) { api._ru = 1; for (let m = 1; m <= 60; m++) { const q = PX(1.5, MY + m, 0); S('path', { d: 'M' + r2(W - (m % 5 ? 10 : 18)) + ' ' + r2(q[1]) + 'H' + W, stroke: '#ffffff', 'stroke-width': m % 5 ? 1.5 : 2.5, opacity: 0.8 }, ruler); if (m % 5 === 0) S('text', { x: W - 22, y: r2(q[1] + 4), 'text-anchor': 'end', 'font-family': 'Fredoka, sans-serif', 'font-weight': 700, 'font-size': 12, fill: '#ffffff' }, ruler).textContent = m + ' m'; } }
          recLine.innerHTML = ''; if (maxH > 1) { const q = PX(0, MY + maxH, 0); S('path', { d: 'M0 ' + r2(q[1]) + 'H' + W, stroke: '#ffcf3a', 'stroke-width': 2, 'stroke-dasharray': '6 6', opacity: 0.8 }, recLine); S('text', { x: 8, y: r2(q[1] - 5), 'font-family': 'Fredoka, sans-serif', 'font-weight': 700, 'font-size': 12, fill: '#ffcf3a' }, recLine).textContent = maxH.toFixed(1) + ' m'; }
        } };
      drawTramp(0, 0); me.set(W / 2, PX(0, MY, 0)[1], 1.02 * K); seedStars(); return api;
    } });
  }; go();
})();
