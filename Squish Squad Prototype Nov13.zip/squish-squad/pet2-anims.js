// Pet Shop round 2 personalities (Nov 10, user: 'add 9 more characters to pet shop' -> 'new characters' -> 'replace lolo with a bird ... add them
// and do what we did to the pet shop animations'). Same recipe as pet-anims / ocean-anims: a personality card that flavours the shared moves, each
// one's own happy / surprised / squish / habit / squeeze + let-go, the natural look, a signature dance, 14 pokes and all 20 foods.
// Rigs: pet2-defs.js (built-in rigs on Mittens' skeleton). Channel notes: Tilly's crest is her two 'ears' (NEGATIVE ear = crest up, positive = flat);
// Clover's tall bunny ears stand up (Nov 10 rebuild; positive = spread out / back, negative = pricked in); Puddles' head fluff is two tiny ears; the birds' wings are the arms.
// pitch: NEGATIVE = head down.
(function () {
  const KEYS = ['tilly', 'pico', 'clover', 'chilla', 'mimi', 'puddles', 'bean', 'zippy', 'mango'];
  // =====================================================================================================================================
  // personality, moves, dance
  (function boot() {
    const R = window.RiveRig; if (!R || !R.PETLIB || !R.PETLIB.install || !R.SOFT || !R.DEFS || !R.DEFS.mango) { setTimeout(boot, 25); return; } if (R.pet2V) return; R.pet2V = 1;
    const { TL, S, hand, both, o, NOHANDS, jump, look, shake, swing, steps, jelly, popcorn, install } = R.PETLIB;
    KEYS.forEach(k => R.SOFT.add(k));
    if (R.PRE) Object.assign(R.PRE, {
      featherY: { n: 2, sp: 10, vy: -9, g: 9, life: 1800, r: [0.8, 1.1], col: ['#ffef9a', '#e6e7ee', '#cfd0d8'], kind: 'leaf' },   // Tilly's down
      featherG: { n: 2, sp: 10, vy: -9, g: 9, life: 1800, r: [0.8, 1.1], col: ['#a9e25c', '#fff07a', '#86c84a'], kind: 'leaf' },   // Pico's
      fluffY: { n: 2, sp: 9, vy: -8, g: 8, life: 1700, r: [0.7, 1], col: ['#fff6c2', '#ffe46a', '#ffffff'], kind: 'leaf' },        // Puddles' fluff
      poof: { n: 3, sp: 14, vy: -6, g: 3, life: 1300, r: [1.8, 3.4], col: ['#f2f1f7', '#e2e1ea', '#ffffff'], kind: 'puff' },       // Chilla's dusty fur
      dustbath: { n: 3, sp: 16, vy: -13, g: 4, life: 1500, r: [2.8, 4.8], kind: 'haze' },   // dust flying up out of her dust bath (Nov 10 v2: soft grey clouds like the photo, were cream blobs; v3 bigger + darker)
      dustplume: { n: 1, sp: 5, vy: -21, g: -2, life: 1900, r: [4, 6.2], kind: 'haze' },   // a big soft puff that billows up above her (Nov 10 v3)
      dustspray: { n: 4, sp: 24, vy: -22, g: 55, life: 900, r: [0.3, 0.65], col: ['#b5ada1', '#d8d1c6', '#f3f0ea'], kind: 'dot' },   // grains of dust kicked out over the rim (Nov 10 v3)
    });
    const loopN = (t, n) => Object.assign(t.loop(), { dur: t.t * (n || 3) });
    const para = (t, from, fn) => { const e = t.t; t.at(from); fn(t); return t.at(Math.max(e, t.t)); };
    // ---------- shared little verbs ----------
    const bob = (t, n, per, a) => { a = a || 0.14; for (let i = 0; i < n; i++) t.to(per * 0.4, { pitch: -a, sq: 0.025 }, 'o').to(per * 0.6, { pitch: a * 0.25, sq: 0 }, 'io'); return t.to(120, { pitch: 0 }, 'io'); };   // bird head bob
    const crest = (t, v, d, ez) => t.to(d || 140, { earL: v, earR: v }, ez || 'o');
    const flap = (t, n, per, A) => { for (let i = 0; i < n; i++) t.to(per * 0.45, { armL: A, armR: A }, 'o').to(per * 0.55, { armL: A * 0.25, armR: A * 0.25 }, 'io'); return t; };
    const chirp = (t, a) => t.to(90, { open: 0.5 * (a || 1), mw: 0.6, pitch: 0.08 }, 'o').e('emit', 'note', 'head').to(140, { open: 0, mw: 1, pitch: 0 }, 'io');
    const quack = t => t.to(90, { open: 0.65, mw: 1.1, pitch: 0.12, sq: -0.03 }, 'o').e('emit', 'note', 'head').to(170, { open: 0, mw: 1, pitch: 0, sq: 0 }, 'io');
    const squeak = t => t.to(70, { open: 0.4, mw: 0.55, pitch: 0.1, wide: 0.3 }, 'o').e('emit', 'note', 'head').to(140, { open: 0, mw: 1, pitch: 0, wide: 0 }, 'io');
    const snort = (t, n) => { for (let i = 0; i < (n || 2); i++) t.to(80, { sq: 0.05, pitch: 0.1, mw: 0.75, close: 0.5 }, 'o').to(170, { sq: 0, pitch: 0, mw: 1, close: 0 }, 'io'); return t; };
    const dook = (t, n) => { t.to(120, { open: 0.35, hap: 1, smile: 1 }, 'o'); for (let i = 0; i < (n || 3); i++) t.to(80, { lift: 1.6, sq: -0.05 }, 'o').to(90, { lift: 0, sq: 0.04 }, 'i'); t.e('emit', 'note', 'head'); return t.to(140, { sq: 0, open: 0.1 }, 'io'); };
    const twitch = (t, n) => t.osc((n || 3) * 150, n || 3, { mw: 0.7, pitch: 0.04 }, { mw: 1, pitch: 0 }, 'o');   // bunny / mouse nose twitch
    // a bird's flutter: crouch, wings beat while it rises and floats down, lands with a squash
    const flutter = (t, h, dur, n, x) => { t.to(120, { sq: 0.12, pitch: -0.08, armL: -6, armR: -6 }, 'io'); const b = t.t;
      t.to(dur * 0.45, o({ lift: h, sq: -0.08, pitch: 0.06 }, x || {}), 'o').to(dur * 0.55, { lift: 0, sq: -0.02, pitch: 0 }, 'io'); const e = t.t;
      t.at(b); flap(t, n, dur / n, 115); t.at(e); return t.to(90, { sq: 0.1, armL: 10, armR: 10 }, 'o').to(170, { sq: 0, armL: 0, armR: 0 }, 'io'); };
    // stepping along: each step lifts one foot while the body moves to the next x
    const stepTo = (t, xs, per, h, x) => { xs.forEach((X, i) => { const f = i % 2 ? 'footL' : 'footR'; t.to(per * 0.5, o({ [f]: h || 3, x: X, tilt: i % 2 ? -2 : 2 }, x || {}), 'o').to(per * 0.5, { [f]: 0, tilt: 0 }, 'i'); }); return t; };
    const waddle = (t, xs, per) => { xs.forEach((X, i) => { const f = i % 2 ? 'footL' : 'footR', d = i % 2 ? -1 : 1; t.to(per * 0.5, { [f]: 2.6, x: X, tilt: d * 7, lean: d * 1.5, wag: d * 20 }, 'o').to(per * 0.5, { [f]: 0, tilt: d * 2, lean: 0 }, 'i'); }); return t.to(160, { tilt: 0, wag: 0 }, 'io'); };
    const binky = (t, s, h) => jump(t, { h: h || 12, ant: 150, up: 240, c: 0.18, arm: 20, air: { tilt: s * 10, turn: s * 0.35, earL: 28, earR: 28, footL: s < 0 ? 3.5 : 0, footR: s > 0 ? 3.5 : 0 }, fall: { tilt: 0, turn: 0, earL: 0, earR: 0, footL: 0, footR: 0 } });
    const thump = (t, s) => { const k = S(s || 1); return t.to(200, { [k.foot]: 3.5, sq: -0.03, earL: 18, earR: 18, wide: 0.6 }, 'io').to(70, { [k.foot]: 0, sq: 0.12 }, 'i').e('emit', 'dust', 'body', 3).to(160, { sq: 0, earL: 0, earR: 0 }, 'io'); };
    const slowBlink = t => t.to(380, { close: 1 }, 'io').wait(250).to(420, { close: 0 }, 'io');
    // Chilla's dust bath (Nov 10, user: 'the dust bath doesn't look so good - add a dust bath and the chilla will really do a bath in it'): the rig's
    // bowl of sand (channel dbb) pops in under her, she hops in and sinks into the sand; rolls = she flops down and rolls from side to side on her
    // back, turning round in it, sand flying; she hops out as the bowl pops away
    const bathIn = t => { const a = t.t; t.to(240, { dbb: 1.12 }, 'o').to(170, { dbb: 1 }, 'io'); t.at(a + 90); jump(t, { h: 8, ant: 120, up: 190, c: 0.12, arm: 30 });
      return t.to(220, { lift: -2.5, sq: 0.1 }, 'io').e('emit', 'dustbath', [36, 84], 2).e('emit', 'dustbath', [64, 84], 2); };
    // Nov 10 v2 (user: 'the dust bath needs to be bigger' + a photo of a real chinchilla rolling in a big wooden tub of dust): the tub is big now
    // (rig dustBath v2) and she rolls in it like the photo - flops right over onto her side (belly toward us, head resting sideways in the dust,
    // eyes shut), then rolls over onto her back (belly up, feet in the air) and back over onto her other side, fast; the habit and the dance share it.
    // (tilt turns her about her feet, so x / lift carry her back into the middle of the tub; sq stays small so her head doesn't go egg-shaped)
    // Nov 10 v3 (user: 'look at the animation, is it missing something?' - it was: the dust hardly showed, she lay ON the flat dust instead of IN it,
    // the roll was a metronome, her whiskers stood up like antennae, nothing came off her when she shook): dbs 1 = she's sunk into the dust (rig heaps
    // dust up against her front), wsk 1 = whiskers folded short + fanned; every half-roll her feet kick out in the middle and her head rubs into the
    // dust (htilt / hyaw / bend), the size of the roll varies (a couple of bigger rolls every 8), each roll throws a puff + grains out at the end she
    // rolls toward; dustOff = a cloud of dust shaken out of her fur.
    // Nov 10 v4 (user: 'the body isn't doing anything, it's not moving, no body motion'): spinning her round ellipsoid body about its long axis
    // barely changes its outline, so the roll read as a still blob with a turning face. Now the BODY works: the roll is much bigger (spin -82 right
    // over on her back <-> +38 over onto her other side = her back shows), the spine arches (bend -14, head thrown back) on her back and curls
    // (bend +18, cheek scrubbed into the dust) on her side, she squashes into the dust as she lands (sq 0.14) and stretches long rolling over the
    // middle (sq -0.08) with a bump up over her spine (lift +2.2), her shoulders + head roll first and her hips follow (twist leads the roll), a
    // wriggle (lean) and the soft body is on (soft 0.45 / stretch 0.3) so she jiggles with it.
    const BLIE = { tilt: 99, x: -43.5, lift: 26.5, spin: -16, sq: 0.1, sit: 1, close: 1, hap: 1, smile: 1, earL: 18, earR: 50, footL: 1.5, footR: 1.5, armL: -8, armR: -8, htilt: 0, hyaw: 0, bend: 0, twist: 0, lean: 0, wag: 0, dbs: 1, wsk: 1 },   // (earR = the lower ear lying down - turned down into the dust so it doesn't hang out over the tub's side)
      BA = { tilt: 105, x: -42, lift: 28.5, spin: -82, sq: 0.18, footL: 3.4, footR: 1.2, armL: -28, armR: 6, earL: 27, earR: 50, htilt: -11, hyaw: -0.14, bend: -14, twist: -0.12, wag: -32 },   // right over on her back: belly up, back arched, feet in the air
      BB = { tilt: 95, x: -46, lift: 25.5, spin: 38, sq: 0.18, footL: 0.6, footR: 3.4, armL: 6, armR: -28, earL: 26, earR: 55, htilt: 11, hyaw: 0.14, bend: 18, twist: 0.12, wag: 32 },          // over onto her other side, curled, cheek scrubbed into the dust
      bmix = (o, g) => { const r = {}; for (const k in o) r[k] = BLIE[k] + (o[k] - BLIE[k]) * g; return r; };
    const flopIn = t => t.to(220, { sq: 0.22, lift: -4, close: 0.7, hap: 1, smile: 1, earL: 10, earR: 10 }, 'io')                                     // a little crouch, eyes closing in bliss
      .to(200, { tilt: 44, x: -17, lift: 9, spin: -6, sq: 0.06, sit: 0.6, earL: 18, earR: 18, close: 1, wsk: 0.5 }, 'i')                               // flops right over onto her side ...
      .to(190, Object.assign({}, BLIE, { tilt: 105, lift: 25, x: -42.5 }), 'o').e('emit', 'dustbath', [26, 83], 3).e('emit', 'dustbath', [52, 84], 3).e('emit', 'dustbath', [74, 83], 2).e('emit', 'dustspray', [20, 82], 3).e('emit', 'dustspray', [80, 82], 3)
      .to(170, { tilt: 99, lift: 26.5, x: -43.5 }, 'io');                                                                                               // ... sinks into the dust in a puff, a small bounce
    // n half-rolls of P ms (the roll builds up over the first 3 and dies down over the last 3), dust thrown up all along her + the cloud (dbh) over the tub
    const rolls = (t, n, P, hz) => { const s0 = t.t; let last = BLIE;
      for (let i = 0; i < n; i++) { const g = Math.min(1, (i + 1) / 3, (n - i) / 3), big = i % 8 === 5 || i % 8 === 6 ? 1.22 : 1, amp = g * big * (0.88 + 0.12 * Math.sin(i * 1.7)), A = i % 2 === 0, q = bmix(A ? BA : BB, amp), mid = {};
        for (const k in q) mid[k] = (last[k] + q[k]) / 2;                                                                                             // half way over (eased in, then out = one smooth roll) ...
        Object.assign(mid, { sq: 0.1 - 0.09 * g, lift: mid.lift + 2.2 * g, twist: (A ? -0.38 : 0.38) * g, lean: (A ? -3 : 3) * g, bend: mid.bend * 0.4 },   // ... stretched long over her spine, shoulders leading, a wriggle
          A ? { footL: 1.5 + 3 * g, footR: 0 } : { footL: 0, footR: 1.5 + 3 * g });                                                                // ... and a kick of the back feet
        t.to(P / 2, mid, 'i').to(P / 2, q, 'o');
        if (A) t.e('emit', 'dustbath', [17 + (i * 7) % 9, 82], 1).e('emit', 'dustspray', [82, 81], 2).e('emit', 'dustplume', i % 4 ? [86, 74] : [14, 74], 1); else t.e('emit', 'dustbath', [i % 4 === 1 ? 30 : 70, 87], 1).e('emit', 'dustspray', [24, 82], 2);
        last = q; }
      t.to(200, bmix(BA, 0), 'io'); const s1 = t.t;
      t.at(s0).to(Math.min(700, (s1 - s0) * 0.4), { dbh: hz }, 'io').at(s0).em(s1 - s0, 100, 'dustbath', [24, 83], 1).em(s1 - s0, 160, 'dustbath', [50, 88], 1).em(s1 - s0, 110, 'dustbath', [74, 83], 1);
      t.at(s1).to(1100, { dbh: 0 }, 'io'); return t.at(s1); };
    const rollUp = t => t.to(230, { tilt: 46, x: -16, lift: 10, spin: -6, sit: 0.4, sq: 0.06, close: 0.4, footL: 0, footR: 0, armL: 0, armR: 0, htilt: 0, hyaw: 0, bend: 0, twist: 0, lean: 0, wag: 0, dbs: 0, wsk: 0.4 }, 'i')   // rolls back up onto her feet, out of the dust
      .e('emit', 'dustbath', [30, 83], 2).e('emit', 'dustbath', [66, 83], 2)
      .to(230, { tilt: -6, x: 0, lift: -1, spin: 0, sit: 0, sq: 0.04, close: 0, hap: 0, earL: 0, earR: 0, wsk: 0 }, 'o').to(170, { tilt: 0, lift: -2.5, sq: 0.1 }, 'io');
    const rollBath = (t, n) => { flopIn(t); rolls(t, n, 170, 0.8); return rollUp(t.wait(200)); };                                                   // the habit: a short roll
    const dustOff = (t, d) => { const a = t.t; t.e('emit', 'dustbath', 'head', 2).e('emit', 'dustbath', 'sideL', 2).e('emit', 'dustbath', 'sideR', 2).em(d || 500, 90, 'dustbath', 'body', 1); return t.at(a); };   // a cloud of dust shaken out of her fur
    const bathOut = t => { const b = t.t; jump(t, { h: 10, ant: 130, up: 210, c: 0.14, arm: 40, ev: [['emit', 'dustbath', [34, 84], 2], ['emit', 'dustbath', [66, 84], 2]] }); const e = t.t; t.at(b + 230).to(260, { dbb: 0 }, 'i'); return t.at(Math.max(e, t.t)); };
    const eyeLick = (t, s) => { const k = S(s); return t.to(120, { tongue: 1, open: 0.3, pitch: 0.18, htilt: s * 8, hyaw: s * 0.12, [k.wink]: 0.8 }, 'o').to(160, { tongue: 0.7, [k.wink]: 1 }, 'io').to(150, { tongue: 0, open: 0, pitch: 0, htilt: 0, hyaw: 0, [k.wink]: 0 }, 'io'); };

    const headShake = (t, a) => shake(t, { P: 95, env: [0.6, 1, 0.8, 0.5, 0.25], head: 0.32 * (a || 1), roll: 4, ear: 14, chest: 0.08 });
    const CARDS = {
      tilly: { T: 0.95, b: 1.05, s: 1.1, e: 1.4 },            // cockatiel: chatty, her crest says everything
      pico: { T: 0.8, b: 1.15, s: 1, e: 1 },                   // budgie: quick, busy, bouncy
      clover: { T: 1, b: 1.2, s: 1, e: 1.4 },                  // bunny: soft, springy, the tall ears swing big
      chilla: { T: 0.85, b: 1.3, s: 1.1, e: 1.1, w: 1.2 },     // chinchilla: springy, fluffy
      mimi: { T: 0.75, b: 0.95, s: 0.85, e: 1.2, w: 1.3 },     // mouse: tiny quick twitchy moves
      puddles: { T: 0.95, b: 1.1, s: 1.3, w: 1.6 },            // duckling: waddly, the little tail waggles
      bean: { T: 1.05, b: 1.2, s: 1.15, w: 1.8, e: 0.7 },      // pug: wiggly, snorty, a bit heavy
      zippy: { T: 0.8, b: 1.3, s: 1.4, w: 1.4, e: 0.8 },       // ferret: bouncy, wiggly, never still
      mango: { T: 1.2, b: 0.8, s: 1.1, w: 1.6, e: 0 },         // gecko: slow and chill, the tail does the talking
    };

    const MOVES = {
      // ===== Tilly (cockatiel) =====
      tilly: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1 });
          t.to(110, { ly: -0.4 }, 'o'); crest(t, -24, 170);                                                                     // crest shoots up
          t.to(150, { armL: 70, armR: 70, lift: 1, sq: -0.04 }, 'o').to(240, { armL: 96, armR: 96, lift: 0, sq: 0.02 }, 'io');   // heart wings: both wings open wide ...
          bob(t, 4, 260, 0.16); chirp(t); chirp(t, 0.7);                                                                       // ... and she bobs her head and whistles
          t.to(240, { armL: 0, armR: 0, sq: 0, ly: 0 }, 'io'); crest(t, 0, 280, 'io');
          return loopN(t.rest(300)); })(), 'Happy', 'Her crest shoots up, she opens her wings in a heart shape, bobs her head and whistles.'],
        surprised: [(() => { const t = TL();
          t.wait(120).to(60, { wide: 1, earL: -32, earR: -32, sq: -0.07, lift: 1.5, armL: 45, armR: 45 }, 'o')                 // crest straight up, eyes pop, wings flick out
            .to(170, { lift: 0, sq: 0.08, armL: 10, armR: 10 }, 'i').to(150, { sq: 0, armL: 0, armR: 0 }, 'io').e('emit', 'featherY', 'body', 2);
          t.wait(280); look(t, 0, -0.55, { k: 0.7, d1: 140, d2: 170 }); t.wait(120); look(t, -0.55, 0.55, { k: 0.7, d1: 140, d2: 170 }); t.wait(120); look(t, 0.55, 0, { k: 0.7 });
          t.to(500, { earL: 0, earR: 0, wide: 0 }, 'io'); chirp(t, 0.6);                                                       // the crest lowers slowly as she calms down
          return t.rest(400).done(); })(), 'Surprised', 'Her crest flies straight up, eyes pop and her wings flick out, a few feathers drift down, she looks around, and the crest slowly lowers.'],
        squish: [(() => { const t = TL();
          t.to(130, { sq: -0.04, earL: -10, earR: -10 }, 'o').to(320, { sq: 0.3, earL: 26, earR: 26, close: 0.8, hap: 0.6, armL: 22, armR: 22 }, 'io').wait(320);   // a fluffy ball, crest flat
          t.to(110, { sq: -0.16, earL: -32, earR: -32, close: 0, hap: 0, wide: 0.6, lift: 3, armL: 90, armR: 90 }, 'o').e('emit', 'featherY', 'body', 3)     // let go: pops up, crest springs up
            .to(200, { sq: 0.06, lift: 0, earL: 8, earR: 8, armL: 20, armR: 20 }, 'i'); jelly(t, 0.06, 2, 260);
          t.to(260, { earL: 0, earR: 0, wide: 0, armL: 0, armR: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squeezed, she puffs into a fluffy ball with her crest flat; let go and she pops up with her crest springing tall.'],
        quirk: [(() => { const t = TL();
          t.to(180, { lx: -0.8, ly: 0.5 }, 'o').to(380, { hyaw: -0.55, pitch: -0.25, htilt: -10, armL: 32, twist: -0.12 }, 'io');   // looks down at her wing and lifts it
          for (let i = 0; i < 3; i++) t.to(120, { pitch: -0.32, open: 0.25, mw: 0.6 }, 'o').to(170, { pitch: -0.22, open: 0, mw: 1, hyaw: -0.55 + (i % 2 ? 0.05 : -0.05) }, 'io');   // nibbles along the feathers
          t.to(360, { hyaw: 0, pitch: 0, htilt: 0, armL: 0, twist: 0, lx: 0, ly: 0 }, 'io');
          t.to(220, { sq: 0.12, earL: 18, earR: 18, close: 0.6 }, 'io');                                                         // fluffs up ...
          shake(t, { P: 80, env: [0.6, 1, 0.8, 0.5, 0.25], head: 0.3, roll: 4, ear: -14, chest: 0.1, body: 0.6 }); t.e('emit', 'featherY', 'body', 2);   // ... a whole-body feather shake
          t.to(260, { sq: 0, earL: 0, earR: 0, close: 0 }, 'io'); chirp(t, 0.6);
          return t.wait(200).rest(400).done(); })(), 'Preening', 'Lifts a wing and nibbles along her feathers, then fluffs right up and shakes every feather back into place, a little whistle.'],
        press: { sq: 0.12, earL: 24, earR: 24, close: 0.6 },
        rel: { dur: 1000, k: { earL: [[0, 24], [120, -32, 'o'], [420, 6, 'io'], [700, 0, 'io']], earR: [[0, 24], [120, -32, 'o'], [420, 6, 'io'], [700, 0, 'io']], sq: [[0, 0.12], [100, -0.14, 'o'], [260, 0.06, 'io'], [420, 0, 'io']],
          close: [[0, 0.6], [100, 0, 'o']], armL: [[0, 0], [140, 70, 'o'], [520, 0, 'io']], armR: [[0, 0], [140, 70, 'o'], [520, 0, 'io']] }, em: [['featherY', 'body', 2]] },
        look: (() => { const t = TL(); look(t, 0, -0.6, { k: 0.8 }); t.wait(600); look(t, -0.6, 0.6, { k: 0.8 }); crest(t, -12, 160); t.wait(500); crest(t, 0, 300, 'io'); look(t, 0.6, 0, { k: 0.8 });
          return t.rest(300).done({ soft: 0.4, stretch: 0 }); })(),
      },
      // ===== Pico (budgie) =====
      pico: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1 });
          t.e('emit', 'note', 'head').osc(900, 6, { open: 0.45, mw: 0.6, pitch: 0.06 }, { open: 0, mw: 1, pitch: 0 }, 'o');                 // chatty chirps
          jump(t, { h: 6, ant: 110, up: 160, c: 0.12, arm: 70, x: 2.5, air: { tilt: 4 }, fall: { tilt: 0 } });                            // hop right ...
          jump(t, { h: 6, ant: 110, up: 160, c: 0.12, arm: 70, x: -2.5, air: { tilt: -4 }, fall: { tilt: 0 } });                          // ... hop left ...
          jump(t, { h: 4, ant: 100, up: 140, c: 0.1, arm: 50, x: 0 }); bob(t, 3, 200, 0.18);                                              // ... home, bob bob bob
          return loopN(t.rest(250)); })(), 'Happy', 'Chatters away, hops right, left and home again, then bobs his head.'],
        surprised: [(() => { const t = TL();
          t.wait(100).to(60, { wide: 1, sq: 0.1, lift: 1 }, 'o').to(120, { lift: 0, sq: 0.08 }, 'i').e('emit', 'featherG', 'body', 1);     // feathers puff, eyes pop
          t.wait(350).to(70, { hyaw: -0.42, lx: -0.9 }, 'o').wait(180).to(70, { hyaw: 0.42, lx: 0.9 }, 'o').wait(180).to(70, { hyaw: -0.2, lx: -0.4 }, 'o').wait(140).to(90, { hyaw: 0, lx: 0 }, 'o');   // quick birdy head snaps
          t.to(240, { sq: 0, wide: 0.2 }, 'io'); chirp(t, 0.8); chirp(t, 0.6);
          return t.rest(400).done(); })(), 'Surprised', 'Puffs up with his eyes popping, freezes, snaps his head left, right, left the way birds do, then two little chirps.'],
        squish: [(() => { const t = TL();
          t.to(120, { sq: -0.04 }, 'o').to(300, { sq: 0.32, close: 0.7, hap: 0.5, armL: 20, armR: 20 }, 'io').wait(300).to(80, { close: 0, hap: 0, wide: 0.5, armL: 0, armR: 0 }, 'o');
          flutter(t, 9, 520, 4); t.e('emit', 'featherG', 'body', 2).to(160, { wide: 0 }, 'io'); chirp(t);
          return loopN(t); })(), 'Squish', 'Squeezed, he puffs into a round ball; let go and he flutters up and chirps.'],
        quirk: [(() => { const t = TL();
          look(t, 0, 0.55, { k: 0.8, d1: 140, d2: 170 });                                                                                  // spots the bird in the mirror
          t.e('emit', 'note', 'head').osc(1100, 8, { open: 0.4, mw: 0.6, pitch: 0.05 }, { open: 0, mw: 1, pitch: 0 }, 'o');                // chatters at it
          bob(t, 3, 220, 0.18);
          t.to(160, { pitch: -0.12, hyaw: 0.66, mw: 0.5, open: 0.15 }, 'o').e('emit', 'heart', 'head', 1).to(220, { pitch: 0, hyaw: 0.55, mw: 1, open: 0 }, 'io');   // a kiss for the mirror bird
          look(t, 0.55, 0, { k: 0.8 });
          return t.rest(400).done(); })(), 'Mirror chat', 'Turns to the bird in his mirror, chatters at it, bobs his head and gives it a little kiss.'],
        press: { sq: 0.14, close: 0.6 },
        rel: { dur: 900, k: { lift: [[0, 0], [240, 8, 'o'], [520, 0, 'io']], sq: [[0, 0.14], [80, -0.12, 'o'], [500, -0.02, 'io'], [600, 0.08, 'o'], [760, 0, 'io']], close: [[0, 0.6], [80, 0, 'o']],
          armL: [[0, 0], [80, 110, 'o'], [180, 40, 'io'], [280, 110, 'o'], [380, 40, 'io'], [480, 100, 'o'], [700, 0, 'io']], armR: [[0, 0], [80, 110, 'o'], [180, 40, 'io'], [280, 110, 'o'], [380, 40, 'io'], [480, 100, 'o'], [700, 0, 'io']] }, em: [['featherG', 'body', 2]] },
        look: (() => { const t = TL(); look(t, 0, -0.6, { k: 0.8, d1: 130, d2: 160 }); t.wait(450); look(t, -0.6, 0.6, { k: 0.8, d1: 130, d2: 160 }); t.wait(450); look(t, 0.6, 0, { k: 0.8, d1: 130, d2: 160 });
          return t.rest(300).done({ soft: 0.4, stretch: 0 }); })(),
      },
      // ===== Clover (bunny) =====
      clover: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1 });
          twitch(t, 3); binky(t, 1, 12); binky(t, -1, 13);                                                                              // two binkies: twist + kick in the air
          t.wait(120); twitch(t, 2);
          return loopN(t.rest(300)); })(), 'Happy', 'Nose twitching, she does two binkies - leaping up with a twist and a kick, her long ears flying out.'],
        surprised: [(() => { const t = TL();
          t.wait(120).to(70, { wide: 1, sq: 0.05 }, 'o'); thump(t, 1); t.wait(200);                                                     // eyes pop - THUMP with a back foot
          t.to(200, { earL: -7, earR: -7 }, 'o').wait(300).to(90, { lx: -0.8 }, 'o').wait(280).to(90, { lx: 0.8 }, 'o').wait(280);         // frozen, ears out, eyes dart
          twitch(t, 4); t.to(300, { lx: 0, wide: 0, earL: 0, earR: 0 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Eyes pop and she thumps a back foot, freezes with her ears pricked straight up while her eyes dart around, then her nose starts twitching again.'],
        squish: [(() => { const t = TL();
          t.to(120, { sq: -0.04 }, 'o').to(320, { sq: 0.3, earL: -10, earR: -10, close: 0.8, hap: 0.6, pitch: -0.08 }, 'io').wait(320);   // a squished bunny loaf
          t.to(60, { close: 0, hap: 0 }, 'o'); binky(t, 1, 14); t.to(200, { pitch: 0, earL: 0, earR: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squeezed into a bunny loaf; let go and she binkies straight up.'],
        quirk: [(() => { const t = TL();
          t.to(300, o(both(4, -16), { armL: 30, armR: 30, pitch: -0.08, close: 0.8 }), 'io');                                             // both paws up to her face
          for (let i = 0; i < 3; i++) t.to(220, o(both(5, -22), { pitch: -0.12 }), 'io').to(200, o(both(4, -13), { pitch: -0.06 }), 'io');  // wipes her face downwards
          t.to(320, o(hand(-1, -4, -24), { armL: 40, armR: 0, hRx: 0, hRy: 0, htilt: -12, earL: -16, close: 0.5 }), 'io');                 // tips her head and pulls her left ear down ...
          t.osc(900, 3, { tongue: 0.8, open: 0.2, hLy: -20 }, { tongue: 0.1, open: 0, hLy: -24 }, 'io');                                 // ... and licks it clean
          t.to(300, o(NOHANDS, { armL: 0, htilt: 0, earL: 0, tongue: 0, open: 0, close: 0, pitch: 0 }), 'io'); headShake(t, 0.7); twitch(t, 3);
          return t.wait(200).rest(400).done(); })(), 'Face wash', 'Washes her face with both paws, tips her head and pulls a long ear down to lick it clean, a quick head shake, nose twitch.'],
        press: { sq: 0.14, earL: -8, earR: -8, close: 0.6 },
        rel: { dur: 1100, k: { lift: [[0, 0], [260, 12, 'o'], [520, 0, 'i']], sq: [[0, 0.14], [60, -0.16, 'o'], [260, -0.04, 'io'], [460, -0.08, 'i'], [540, 0.16, 'o'], [700, -0.03, 'io'], [840, 0, 'io']],
          earL: [[0, -8], [200, 28, 'o'], [520, -6, 'io'], [800, 0, 'io']], earR: [[0, -8], [200, 28, 'o'], [520, -6, 'io'], [800, 0, 'io']], tilt: [[0, 0], [200, 8, 'o'], [500, 0, 'io']], close: [[0, 0.6], [60, 0, 'o']] } },
        look: (() => { const t = TL(); look(t, 0, -0.6, { k: 0.8 }); twitch(t, 2); t.wait(500); look(t, -0.6, 0.6, { k: 0.8 }); twitch(t, 2); t.wait(500); look(t, 0.6, 0, { k: 0.8 });
          return t.rest(300).done({ soft: 0.4, stretch: 0 }); })(),
      },
      // ===== Chilla (chinchilla) =====
      chilla: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1 });
          popcorn(t, 13, 1, 520); t.wait(150); popcorn(t, 15, -1, 540); t.e('emit', 'poof', 'body', 2);                                 // chinchilla popcorn - straight up, a twist in the air
          t.osc(800, 4, { wag: 24 }, { wag: -24 }, 'io').to(150, { wag: 0 }, 'io');
          return loopN(t.rest(300)); })(), 'Happy', 'Popcorns twice - springing straight up with a twist in the air - and swishes her bushy tail.'],
        surprised: [(() => { const t = TL();
          t.wait(120).to(60, { wide: 1, earL: -12, earR: -12, sq: 0.06 }, 'o').wait(450);                                              // freezes, ears forward
          jump(t, { h: 7, ant: 60, up: 180, c: 0.1, arm: 30, x: -3 }); t.e('emit', 'poof', 'body', 2);                                 // a quick hop back
          t.to(90, { lx: -0.8 }, 'o').wait(250).to(90, { lx: 0.8 }, 'o').wait(250); stepTo(t, [-1.5, 0], 220, 2); t.to(300, { lx: 0, wide: 0, earL: 0, earR: 0, sq: 0 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Freezes with her big ears forward, hops back, eyes darting, then steps back to her spot.'],
        squish: [(() => { const t = TL();
          t.to(120, { sq: -0.04 }, 'o').to(320, { sq: 0.34, close: 0.9, hap: 0.8, earL: 10, earR: 10 }, 'io').wait(320).to(60, { close: 0, hap: 0 }, 'o');   // a squashed fluffball
          popcorn(t, 16, 1, 560); t.e('emit', 'poof', 'body', 3).to(260, { earL: 0, earR: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squashed into a soft fluffball; let go and she popcorns up in a puff of dust.'],
        quirk: [(() => { const t = TL();
          t.to(160, { ly: 0.8, pitch: -0.15 }, 'o').wait(150).to(200, { ly: 0, pitch: 0, hap: 1, smile: 1 }, 'io');                        // looks down: bath time!
          bathIn(t); t.osc(600, 3, { mw: 0.7, pitch: -0.12 }, { mw: 1, pitch: -0.05 }, 'o').to(150, { pitch: 0 }, 'io');                   // hops into her dust bath, sniffs the sand
          rollBath(t, 12); t.wait(120);                                                                                                      // flops over onto her side and rolls onto her back + over, ~2 s (Nov 10 v2)
          bathOut(t); t.to(160, { hap: 0, smile: 0.6 }, 'io');                                                                               // hops out - the bath pops away
          dustOff(t, 520); shake(t, { P: 85, env: [0.6, 1, 0.85, 0.5, 0.25], head: 0.3, roll: 5, ear: 12, chest: 0.1, body: 0.8, tail: 30 }); t.e('emit', 'poof', 'head', 2).e('emit', 'poof', 'sideL', 1).e('emit', 'poof', 'sideR', 1);   // shakes the sand out of her fur
          return t.wait(200).rest(400).done({ stretch: 0.3, soft: 0.45 }); })(), 'Dust bath', 'Her big dust-bath tub pops in under her: she hops in, sniffs the dust, flops right over onto her side and rolls onto her back and over, feet in the air, dust flying; then she rolls back up, hops out - the tub pops away - and shakes the dust off.'],
        press: { sq: 0.16, close: 0.7, hap: 0.6 },
        rel: { dur: 1000, k: { lift: [[0, 0], [260, 15, 'o'], [520, 0, 'i']], spin: [[0, 0], [520, 180, 'io'], [521, -180, 'l'], [900, 0, 'io']], sq: [[0, 0.16], [60, -0.18, 'o'], [260, -0.04, 'io'], [460, -0.08, 'i'], [540, 0.18, 'o'], [700, -0.03, 'io'], [840, 0, 'io']],
          close: [[0, 0.7], [60, 0, 'o']], hap: [[0, 0.6], [60, 1, 'o'], [900, 0, 'io']] }, em: [['poof', 'body', 3]] },
        look: (() => { const t = TL(); look(t, 0, -0.6, { k: 0.8 }); t.wait(500); look(t, -0.6, 0.6, { k: 0.8 }); t.wait(500); look(t, 0.6, 0, { k: 0.8 });
          return t.rest(300).done({ soft: 0.4, stretch: 0 }); })(),
      },
      // ===== Mimi (mouse) =====
      mimi: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1 });
          t.to(220, { sq: -0.08, lift: 1.5, pitch: 0.06 }, 'o');                                                                        // up on her tiptoes
          t.to(160, both(6, -4), 'io'); for (let i = 0; i < 4; i++) t.to(90, both(2, -5), 'o').to(110, both(6, -4), 'io');             // claps her tiny paws
          squeak(t); t.osc(700, 4, { wag: 28 }, { wag: -28 }, 'io');
          t.to(240, o(NOHANDS, { sq: 0, lift: 0, pitch: 0, wag: 0 }), 'io');
          return loopN(t.rest(250)); })(), 'Happy', 'Stands up on her tiptoes, claps her tiny paws, squeaks and wiggles her tail.'],
        surprised: [(() => { const t = TL();
          t.wait(100).to(60, { wide: 1 }, 'o'); squeak(t); jump(t, { h: 9, ant: 50, up: 180, c: 0.1, arm: 60, st: 1.2 });               // squeak! a jump straight up
          t.to(100, { sq: 0.06, earL: -10, earR: -10 }, 'o').wait(450);                                                                 // frozen
          t.to(90, { lx: -0.8 }, 'o').wait(200).to(90, { lx: 0.8 }, 'o').wait(200).to(90, { lx: 0 }, 'o');
          t.osc(700, 5, { mw: 0.7, pitch: 0.06, earL: -4, earR: -4 }, { mw: 1, pitch: 0, earL: -10, earR: -10 }, 'o');                 // sniffs, whiskers twitching
          t.to(300, { wide: 0, sq: 0, earL: 0, earR: 0 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Squeaks and jumps straight up, freezes with her ears forward, eyes darting, then sniffs the air with her whiskers twitching.'],
        squish: [(() => { const t = TL();
          t.to(120, { sq: -0.04 }, 'o').to(300, { sq: 0.3, close: 1, hap: 0.6, earL: 12, earR: 12 }, 'io'); squeak(t); t.wait(200).to(60, { close: 0, hap: 0 }, 'o');
          jump(t, { h: 10, ant: 40, up: 200, c: 0.3, arm: 50, st: 1.2 }); t.to(220, { earL: 0, earR: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squeezed, she squeaks; let go and she springs up.'],
        quirk: [(() => { const t = TL();
          t.to(240, o(both(5, -15), { armL: 34, armR: 34, sq: -0.04, pitch: -0.06 }), 'io');                                              // sits up, paws to her nose
          for (let i = 0; i < 4; i++) t.to(110, o(both(9, -13), { htilt: i % 2 ? 4 : -4 }), 'io').to(110, both(4, -15), 'io');            // quick whisker wash
          t.to(240, o(both(2, -13), { pitch: -0.12, ly: 0.5 }), 'io');                                                                  // finds a crumb ...
          t.osc(900, 6, { open: 0.25, mw: 0.6, puff: 0.3 }, { open: 0, mw: 1, puff: 0 }, 'o').e('emit', 'crumb', 'head', 2);              // ... nibble nibble nibble
          t.to(260, o(NOHANDS, { armL: 0, armR: 0, sq: 0, pitch: 0, ly: 0, htilt: 0, hap: 1, smile: 1 }), 'io'); squeak(t);
          return t.wait(200).rest(400).done(); })(), 'Whisker wash', 'Sits up and gives her whiskers a quick wash with both paws, finds a crumb and nibbles it super fast, then a happy squeak.'],
        press: { sq: 0.14, close: 1, earL: 10, earR: 10 },
        rel: { dur: 900, k: { lift: [[0, 0], [220, 10, 'o'], [440, 0, 'i']], sq: [[0, 0.14], [60, -0.14, 'o'], [220, -0.03, 'io'], [400, -0.06, 'i'], [460, 0.12, 'o'], [620, 0, 'io']],
          close: [[0, 1], [60, 0, 'o']], earL: [[0, 10], [220, -12, 'o'], [600, 0, 'io']], earR: [[0, 10], [220, -12, 'o'], [600, 0, 'io']], open: [[0, 0], [80, 0.4, 'o'], [260, 0, 'io']] } },
        look: (() => { const t = TL(); look(t, 0, -0.6, { k: 0.8, d1: 140, d2: 170 }); t.osc(480, 3, { mw: 0.75 }, { mw: 1 }, 'o'); t.wait(300); look(t, -0.6, 0.6, { k: 0.8, d1: 140, d2: 170 }); t.wait(450); look(t, 0.6, 0, { k: 0.8 });
          return t.rest(300).done({ soft: 0.4, stretch: 0 }); })(),
      },
      // ===== Puddles (duckling) =====
      puddles: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1 });
          t.osc(700, 5, { wag: 30 }, { wag: -30 }, 'io').to(100, { wag: 0 }, 'io');                                                    // tail waggle
          flap(t, 3, 260, 100); t.to(160, { armL: 0, armR: 0 }, 'io'); quack(t);                                                       // flaps her little wings, quack
          jump(t, { h: 6, ant: 130, up: 180, c: 0.14, arm: 70 }); quack(t);
          return loopN(t.rest(250)); })(), 'Happy', 'Waggles her little tail, flaps her wings, quacks, a happy hop and another quack.'],
        surprised: [(() => { const t = TL();
          t.wait(100).to(60, { wide: 1, earL: -20, earR: -20 }, 'o'); quack(t);                                                          // QUACK - her head fluff stands up
          jump(t, { h: 9, ant: 50, up: 190, c: 0.1, arm: 110, st: 1.2, ev: [['emit', 'fluffY', 'body', 2]] });
          t.wait(250); waddle(t, [-1.5, -3, -1.5, 0], 260);                                                                            // waddles a step back, and back again
          t.to(90, { lx: -0.8 }, 'o').wait(220).to(90, { lx: 0.8 }, 'o').wait(220).to(300, { lx: 0, wide: 0, earL: 0, earR: 0 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Quacks with her head fluff standing up, jumps with her wings out, waddles back a step, eyes darting.'],
        squish: [(() => { const t = TL();
          t.to(120, { sq: -0.04 }, 'o').to(260, { sq: 0.36, close: 1, hap: 0.5, mw: 0.6, open: 0.3 }, 'io').e('emit', 'note', 'head').wait(280);   // a squeaky-toy squeeze
          t.to(60, { close: 0, hap: 0, mw: 1, open: 0 }, 'o'); jump(t, { h: 10, ant: 40, up: 210, c: 0.34, arm: 90, st: 1.25 }); quack(t);
          return loopN(t); })(), 'Squish', 'Squeezed like a squeaky bath toy - squeak! - let go and she bounces up with a quack.'],
        quirk: [(() => { const t = TL();
          t.to(110, { ly: 0.9 }, 'o').to(260, { pitch: -0.22 }, 'io');                                                                 // spots a puddle at her feet
          for (let i = 0; i < 4; i++) { const f = i % 2 ? 'footL' : 'footR'; t.to(140, { [f]: 3.5, tilt: i % 2 ? -4 : 4, sq: -0.03 }, 'o').to(90, { [f]: 0, sq: 0.08 }, 'i').e('emit', 'splash', 'body', 2).to(120, { sq: 0 }, 'io'); }   // stomp stomp splash
          t.to(260, { pitch: 0, ly: 0, tilt: 0, hap: 1, smile: 1, open: 0.3 }, 'io').osc(700, 5, { wag: 30, sq: 0.03 }, { wag: -30, sq: 0 }, 'io').to(150, { wag: 0, open: 0 }, 'io');   // giggles, tail waggle
          return t.wait(200).rest(400).done(); })(), 'Puddle stomp', 'Spots a puddle and stomps in it - splash, splash, splash, splash - then giggles with her tail waggling.'],
        press: { sq: 0.18, close: 1, mw: 0.6, open: 0.25 },
        rel: { dur: 1000, k: { lift: [[0, 0], [240, 11, 'o'], [480, 0, 'i']], sq: [[0, 0.18], [60, -0.16, 'o'], [240, -0.04, 'io'], [420, -0.08, 'i'], [500, 0.16, 'o'], [660, 0, 'io']],
          close: [[0, 1], [60, 0, 'o']], mw: [[0, 0.6], [80, 1, 'o']], open: [[0, 0.25], [520, 0.6, 'o'], [700, 0, 'io']], wag: [[0, 0], [520, 30, 'io'], [640, -30, 'io'], [760, 20, 'io'], [880, 0, 'io']],
          armL: [[0, 0], [200, 100, 'o'], [500, 0, 'io']], armR: [[0, 0], [200, 100, 'o'], [500, 0, 'io']] } },
        look: (() => { const t = TL(); look(t, 0, -0.6, { k: 0.8 }); t.wait(500); look(t, -0.6, 0.6, { k: 0.8 }); t.osc(500, 3, { wag: 20 }, { wag: -20 }, 'io').to(100, { wag: 0 }); t.wait(300); look(t, 0.6, 0, { k: 0.8 });
          return t.rest(300).done({ soft: 0.4, stretch: 0 }); })(),
      },
      // ===== Bean (pug) =====
      bean: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1, tongue: 0.5, open: 0.25 });
          snort(t, 2); swing(t, 1400, 7, { x: 1.4, tilt: 4, wag: 40, bend: 2 });                                                       // snorts, then the butt wiggle
          jump(t, { h: 5, ant: 140, up: 170, c: 0.14, arm: 30 }); snort(t, 1);
          return loopN(t.rest(250)); })(), 'Happy', 'Tongue out, two happy snorts, a big butt wiggle with his curly tail going, a little hop.'],
        surprised: [(() => { const t = TL();
          t.wait(120).to(70, { wide: 1, earL: -12, earR: -12, sq: 0.04 }, 'o').wait(250);                                                // eyes bulge, ears perk
          t.to(320, { htilt: 16, hyaw: 0.1, lx: 0.3 }, 'io').wait(400).to(380, { htilt: -16, hyaw: -0.1, lx: -0.3 }, 'io').wait(400);   // the pug head tilt - one way, the other
          t.to(260, { htilt: 0, hyaw: 0, lx: 0 }, 'io'); snort(t, 2); t.to(300, { wide: 0, earL: 0, earR: 0, sq: 0 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Eyes bulge and his ears perk up, a big puzzled pug head tilt one way, then the other, then two snorts.'],
        squish: [(() => { const t = TL();
          t.to(120, { sq: -0.04 }, 'o').to(320, { sq: 0.3, close: 0.8, puff: 0.6, mw: 0.7 }, 'io'); snort(t, 1); t.wait(200);
          t.to(60, { close: 0, puff: 0, mw: 1, hap: 1, tongue: 0.6, open: 0.3 }, 'o'); jump(t, { h: 8, ant: 40, up: 200, c: 0.3, arm: 40 });
          swing(t, 700, 3, { wag: 36, x: 1 }); t.to(200, { hap: 0, tongue: 0, open: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squished, all his wrinkles bunch up and he snorts; let go and he bounces with his tongue out, tail wiggling.'],
        quirk: [(() => { const t = TL();
          t.to(120, { lx: 0.8, ly: -0.3 }, 'o').to(300, { earL: -12, earR: -12, hyaw: 0.2 }, 'io').wait(300);                              // hears something ...
          t.to(320, { htilt: 18 }, 'io').wait(500).to(360, { htilt: -12, hyaw: 0.25 }, 'io').wait(400);                                // ... head tilt, tilt
          t.to(200, { htilt: 0, hyaw: 0, lx: 0, ly: 0, earL: 0, earR: 0 }, 'io');
          t.to(120, { pitch: 0.12, close: 0.6, mw: 0.7, sq: -0.03 }, 'o').to(160, { pitch: 0, close: 0, mw: 1, sq: 0.03 }, 'io').to(120, { sq: 0 }); snort(t, 2);   // a big pug sneeze-snort
          t.to(160, { tongue: 0.7, open: 0.2, hap: 1 }, 'o').wait(600).to(200, { tongue: 0, open: 0, hap: 0 }, 'io');                  // forgets his tongue out
          return t.wait(200).rest(400).done(); })(), 'Head tilt', 'Hears something - a puzzled head tilt, then the other way - a big pug snort, and he forgets his tongue sticking out.'],
        press: { sq: 0.14, puff: 0.5, close: 0.7, mw: 0.7 },
        rel: { dur: 1000, k: { lift: [[0, 0], [240, 9, 'o'], [480, 0, 'i']], sq: [[0, 0.14], [60, -0.14, 'o'], [240, -0.03, 'io'], [420, -0.06, 'i'], [500, 0.14, 'o'], [660, 0, 'io']],
          puff: [[0, 0.5], [60, 0, 'o']], close: [[0, 0.7], [60, 0, 'o']], mw: [[0, 0.7], [80, 1, 'o']], tongue: [[0, 0], [200, 0.7, 'o'], [800, 0, 'io']], open: [[0, 0], [200, 0.3, 'o'], [800, 0, 'io']],
          wag: [[0, 0], [500, 36, 'io'], [620, -36, 'io'], [740, 30, 'io'], [860, 0, 'io']] } },
        look: (() => { const t = TL(); look(t, 0, -0.55, { k: 0.8 }); t.to(260, { htilt: 8 }, 'io').wait(400).to(260, { htilt: 0 }, 'io'); look(t, -0.55, 0.55, { k: 0.8 }); t.wait(500); look(t, 0.55, 0, { k: 0.8 });
          return t.rest(300).done({ soft: 0.4, stretch: 0 }); })(),
      },
      // ===== Zippy (ferret) =====
      zippy: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1 });
          dook(t, 3); t.wait(100); dook(t, 4);                                                                                          // dook dook dook
          t.osc(800, 4, { wag: 32, x: 0.8 }, { wag: -32, x: -0.8 }, 'io').to(150, { wag: 0, x: 0, open: 0 }, 'io');
          return loopN(t.rest(250)); })(), 'Happy', 'Happy ferret chuckles - dook dook dook - bouncing on the spot, his long tail swishing.'],
        surprised: [(() => { const t = TL();
          t.wait(100).to(70, { wide: 1, sq: -0.12, lift: 2, bend: -3, wag: 20 }, 'o').to(200, { lift: 0, sq: -0.06 }, 'i');               // arches up tall, tail puffs
          jump(t, { h: 6, ant: 60, up: 150, c: 0.08, arm: 40, x: -3, air: { tilt: -8 }, fall: { tilt: 0 } });                             // a sideways startled hop ...
          jump(t, { h: 6, ant: 60, up: 150, c: 0.08, arm: 40, x: 0, air: { tilt: 8 }, fall: { tilt: 0 } });                               // ... and back
          t.to(260, { bend: 0, wag: 0, wide: 0, sq: 0 }, 'io'); dook(t, 2); t.to(200, { open: 0, hap: 0, smile: 0 }, 'io');
          return t.rest(400).done(); })(), 'Surprised', 'Arches up tall with his tail puffed, a startled sideways hop and back, then a little dook.'],
        squish: [(() => { const t = TL();
          t.to(120, { sq: -0.04 }, 'o').to(320, { sq: 0.32, close: 0.9, hap: 0.7, wag: 18 }, 'io').wait(300).to(60, { close: 0, hap: 1, smile: 1 }, 'o');
          jump(t, { h: 12, ant: 40, up: 230, c: 0.32, arm: 60, st: 1.3, spin: 360 }); dook(t, 2); t.to(200, { hap: 0, smile: 0, open: 0, wag: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squished; let go and he boings up with a spin and a dook.'],
        quirk: [(() => { const t = TL();
          t.to(120, { lx: -0.8 }, 'o').to(260, { hyaw: -0.3 }, 'io').wait(200).to(120, { lx: 0.8 }, 'o').to(300, { hyaw: 0.3 }, 'io').wait(200);   // shifty eyes: anyone looking?
          t.to(200, { hyaw: 0, lx: 0, pitch: -0.1 }, 'io').to(140, o(both(12, -2), { armL: 50, armR: 50, x: 1.5, sq: -0.04 }), 'o')         // grabs something ...
            .to(240, o(both(-2, 6), { armL: -20, armR: -20, x: 0, sq: 0, pitch: 0 }), 'io');                                            // ... and hides it behind his back
          t.to(220, { close: 0.6, smile: 1, hap: 0.5, ly: -0.5, pitch: 0.1 }, 'io').osc(900, 3, { htilt: 5 }, { htilt: -5 }, 'io');     // all innocent
          t.to(300, o(NOHANDS, { armL: 0, armR: 0, close: 0, smile: 0, hap: 0, ly: 0, pitch: 0, htilt: 0 }), 'io');
          return t.wait(200).rest(400).done(); })(), 'Sneaky stash', 'Shifty eyes - anyone looking? - grabs something, hides it behind his back and looks all innocent.'],
        press: { sq: 0.14, close: 0.8, hap: 0.5 },
        rel: { dur: 1000, k: { lift: [[0, 0], [250, 13, 'o'], [500, 0, 'i']], spin: [[0, 0], [500, 360, 'io'], [501, 0, 'l']], sq: [[0, 0.14], [60, -0.18, 'o'], [250, -0.04, 'io'], [430, -0.08, 'i'], [510, 0.16, 'o'], [680, 0, 'io']],
          close: [[0, 0.8], [60, 0, 'o']], hap: [[0, 0.5], [60, 1, 'o'], [900, 0, 'io']], open: [[0, 0], [520, 0.4, 'o'], [800, 0, 'io']] } },
        look: (() => { const t = TL(); look(t, 0, -0.6, { k: 0.85, d1: 140, d2: 170 }); t.wait(400); look(t, -0.6, 0.6, { k: 0.85, d1: 140, d2: 170 }); t.wait(400); look(t, 0.6, 0, { k: 0.85 });
          return t.rest(300).done({ soft: 0.4, stretch: 0 }); })(),
      },
      // ===== Mango (leopard gecko) =====
      mango: {
        happy: [(() => { const t = TL({ hap: 1, smile: 1 });
          t.to(500, { pitch: 0.1, sq: -0.03 }, 'io'); slowBlink(t);                                                                     // chin up, a slow happy blink
          swing(t, 1800, 3, { wag: 34, tilt: 2, x: 0.6 }); bob(t, 2, 500, 0.1);                                                         // a slow tail wave, two slow nods
          return loopN(t.rest(400)); })(), 'Happy', 'Lifts his chin with a big grin, a slow happy blink, waves his tail slowly and gives two chill nods.'],
        surprised: [(() => { const t = TL();
          t.wait(150).to(80, { wide: 1, sq: 0.05 }, 'o').wait(300);                                                                     // freezes
          t.osc(700, 7, { wag: 10 }, { wag: -6 }, 'l').to(100, { wag: 0 }, 'io');                                                        // the tail tip twitches (gecko on alert)
          t.to(110, { lx: -0.8 }, 'o').wait(350).to(110, { lx: 0.8 }, 'o').wait(350).to(200, { lx: 0, wide: 0, sq: 0 }, 'io'); slowBlink(t);
          return t.rest(400).done(); })(), 'Surprised', 'Freezes, the tip of his tail twitches, his eyes slide left and right, then a slow relaxed blink.'],
        squish: [(() => { const t = TL();
          t.to(150, { sq: -0.03 }, 'o').to(360, { sq: 0.3, close: 1, hap: 0.7 }, 'io').wait(380);
          t.to(220, { sq: -0.08, lift: 2, close: 0, hap: 1, smile: 1 }, 'o').to(260, { sq: 0.05, lift: 0 }, 'i'); jelly(t, 0.05, 2, 360); slowBlink(t); t.to(260, { hap: 0, smile: 0 }, 'io');
          return loopN(t); })(), 'Squish', 'Squishes flat; let go and he puffs back up with a big grin and a slow blink.'],
        quirk: [(() => { const t = TL();
          eyeLick(t, 1); t.wait(200); eyeLick(t, -1);                                                                                   // leopard geckos lick their own eyes
          t.to(240, { hap: 1, smile: 1 }, 'io').osc(1200, 3, { wag: 26 }, { wag: -26 }, 'io').to(200, { wag: 0, hap: 0, smile: 0 }, 'io');
          return t.wait(200).rest(400).done(); })(), 'Eye lick', 'Licks his own eyeball - one, then the other (leopard geckos really do that) - then a grin and a lazy tail wave.'],
        press: { sq: 0.12, close: 1, hap: 0.6 },
        rel: { dur: 1100, k: { sq: [[0, 0.12], [200, -0.08, 'o'], [450, 0.05, 'io'], [700, 0, 'io']], lift: [[0, 0], [200, 2, 'o'], [450, 0, 'i']], close: [[0, 1], [300, 0, 'io']],
          hap: [[0, 0.6], [300, 1, 'io'], [1000, 0, 'io']], wag: [[0, 0], [400, 30, 'io'], [700, -30, 'io'], [1000, 0, 'io']] } },
        look: (() => { const t = TL(); look(t, 0, -0.55, { k: 0.75, d1: 220, d2: 260 }); t.wait(800); look(t, -0.55, 0.55, { k: 0.75, d1: 220, d2: 260 }); slowBlink(t); t.wait(300); look(t, 0.55, 0, { k: 0.75, d1: 220, d2: 260 });
          return t.rest(400).done({ soft: 0.4, stretch: 0 }); })(),
      },
    };

    // ---------- signature dances (each loops until stopped and ends exactly on its first pose) ----------
    const DANCES = {
      tilly: [(() => { const t = TL({ smile: 0.8 }), B = 460;
        t.e('emit', 'note', 'head');
        for (let i = 0; i < 8; i++) { t.to(B * 0.35, { pitch: -0.16, sq: 0.03, earL: -20, earR: -20, x: (i % 2 ? 1 : -1) * 0.8 }, 'o').to(B * 0.65, { pitch: 0.04, sq: 0, earL: -4, earR: -4 }, 'io'); if (i === 3) t.e('emit', 'note', 'head'); }   // bobs to the beat, crest flicking
        t.to(200, { x: 0, pitch: 0 }, 'io');
        t.to(240, { armL: 100, armR: 100, sq: -0.04, lift: 1, earL: -24, earR: -24 }, 'o').to(160, { armL: 92, armR: 92, sq: 0, lift: 0 }, 'io');   // heart wings ...
        swing(t, 1600, 3, { tilt: 5, x: 1.5, htilt: -4 }); chirp(t); chirp(t, 0.7);                                                    // ... swaying with them, whistling
        t.to(220, { armL: 30, armR: 30, earL: -6, earR: -6 }, 'io');
        stepTo(t, [2, 4, 2, 0, -2, -4, -2, 0], 300, 2.5);                                                                              // side steps right ... and left
        t.to(150, { armL: 0, armR: 0 }, 'io');
        jump(t, { h: 11, ant: 160, up: 290, c: 0.18, arm: 120, spin: 360, ev: [['emit', 'featherY', 'body', 3]] });                   // a flutter hop with a spin
        t.osc(1000, 6, { earL: -26, earR: 6 }, { earL: 6, earR: -26 }, 'io').to(160, { earL: 0, earR: 0 }, 'io');                       // crest shake!
        chirp(t); return t.rest(300).loop({ stretch: 0.7 }); })(), 'Crest Shake Boogie', 'Bobs her head to the beat with her crest flicking up, opens her wings in a heart and sways, side-steps right and left, a flutter hop with a spin, and shakes her crest from side to side.'],
      pico: [(() => { const t = TL({ smile: 0.8, hap: 0.4 }), B = 360;
        t.e('emit', 'note', 'head');
        for (let i = 0; i < 8; i++) t.to(B * 0.35, { pitch: -0.18, sq: 0.04, tilt: i % 2 ? 3 : -3 }, 'o').to(B * 0.65, { pitch: 0.05, sq: 0 }, 'io');        // fast bopping
        t.to(150, { tilt: 0, pitch: 0 }, 'io');
        for (let i = 0; i < 4; i++) { const k = i % 2 ? 'armL' : 'armR', j = i % 2 ? 'armR' : 'armL'; t.to(140, { [k]: 110, [j]: 10, htilt: i % 2 ? -6 : 6 }, 'o').to(180, { [k]: 30 }, 'io'); if (i % 2) t.e('emit', 'note', 'head'); }   // one wing, the other
        t.to(150, { armL: 0, armR: 0, htilt: 0 }, 'io');
        jump(t, { h: 6, ant: 110, up: 160, c: 0.12, arm: 80, x: 3, air: { tilt: 5 }, fall: { tilt: 0 } }); jump(t, { h: 6, ant: 110, up: 160, c: 0.12, arm: 80, x: -3, air: { tilt: -5 }, fall: { tilt: 0 } });
        jump(t, { h: 5, ant: 110, up: 150, c: 0.1, arm: 60, x: 0 });
        flutter(t, 12, 900, 6, { spin: 360 }); t.to(1, { spin: 0 }, 'l').e('emit', 'featherG', 'body', 3);                            // flutters up with a spin
        t.e('emit', 'note', 'head').osc(900, 6, { open: 0.45, mw: 0.6, pitch: 0.06 }, { open: 0, mw: 1, pitch: 0 }, 'o'); bob(t, 3, 220, 0.18);   // chatter + bob finale
        return t.rest(250).loop({ stretch: 0.7 }); })(), 'Birdie Bop', 'Bops his head super fast to the beat, flaps one wing then the other, hops right, left and home, flutters up with a spin, then chatters and bobs.'],
      clover: [(() => { const t = TL({ smile: 0.8 });
        t.e('emit', 'note', 'head');
        for (let i = 0; i < 4; i++) jump(t, { h: 5, ant: 110, up: 150, c: 0.12, arm: 15, x: [2, 0, -2, 0][i], air: { earL: 20, earR: 20 }, fall: { earL: 0, earR: 0 } });   // bunny hops forward and back
        binky(t, 1, 13); binky(t, -1, 14); t.e('emit', 'note', 'head');                                                               // binky binky
        twitch(t, 3);
        t.to(320, { tilt: 26, sq: 0.22, lift: -1, close: 1, hap: 1, smile: 1, earL: -10, earR: 26 }, 'io').e('emit', 'heart', 'head', 1).wait(900);   // the happy bunny 'flop' onto her side
        t.to(200, { tilt: 8, sq: 0.06, lift: 0, close: 0 }, 'o').to(200, { tilt: 0, sq: 0, earL: 0, earR: 0, hap: 0 }, 'io'); headShake(t, 0.8);   // up again, ear shake
        jump(t, { h: 15, ant: 170, up: 270, c: 0.2, arm: 30, spin: 360, air: { earL: 30, earR: 30 }, fall: { earL: 0, earR: 0 } });    // a big spinning binky to finish
        return t.rest(300).loop({ stretch: 0.7 }); })(), 'Bunny Hop', 'Little bunny hops forward and back, two twisting binkies, a nose twitch, the happy bunny flop onto her side, back up with an ear shake, and a big spinning binky.'],
      // Nov 10 (user: 'the dust bath stays and he lies with his belly on it and rotates to the left and to the right really fast and non stop for
      // 10 seconds, then he finishes, and until we decide he keeps repeating the process'): ONE cycle that loops for as long as she dances - the tub
      // (dbb 1) is there the whole time (it fades in / out with the switch to / from the dance); she sits in it at the start of every cycle.
      // Nov 10 v2 (user: 'the dust bath needs to be bigger' + a photo of a real chinchilla rolling in a big wooden tub of dust - on her side / back,
      // belly up and toward us, head resting sideways in the dust, eyes shut, back feet in the air, a cloud of dust round her): the tub is now big
      // (rig dustBath v2) and she no longer lies on her belly - she flops right over onto her side in it and ROLLS: over onto her back (belly up,
      // feet in the air) and back over onto her other side, left - right - left really fast, non stop for 10 s, a cloud of dust (dbh) building up
      // over the tub; then she rolls back up, shakes the dust off, a happy hop in the tub, and flops straight back down to go again.
      chilla: [(() => { const t = TL({ dbb: 1, lift: -2.5, sq: 0.1, smile: 0.8 });
        // 1. a little crouch, then she flops right over onto her side in the dust (flopIn)
        flopIn(t);
        // 2. rolls over onto her back and over onto her other side, left - right - left really fast, non stop for 10 s (59 half-rolls of 170 ms);
        //    feet kicking in the air, ears + tail flung about, dust thrown up all along her and a cloud of dust building up over the tub
        rolls(t, Math.round(10000 / 170), 170, 1);
        // 3. a blissful moment lying still, then she rolls back up onto her feet (eyes open), shakes the dust off, a happy hop in the tub, a big grin
        rollUp(t.wait(260));
        dustOff(t, 520); shake(t, { P: 85, env: [0.6, 1, 0.85, 0.5, 0.25], head: 0.3, roll: 5, ear: 12, chest: 0.1, body: 0.6, tail: 30 }); t.e('emit', 'poof', 'head', 2).e('emit', 'poof', 'sideL', 1).e('emit', 'poof', 'sideR', 1);
        jump(t, { h: 7, ant: 130, up: 200, c: 0.12, arm: 45, ev: [['emit', 'dustbath', [36, 83], 2], ['emit', 'dustbath', [64, 83], 2], ['emit', 'note', 'head', 1]] }); t.to(220, { lift: -2.5, sq: 0.1 }, 'io');
        t.to(200, { hap: 1, smile: 1, open: 0.3 }, 'io').wait(350).to(200, { hap: 0, open: 0, smile: 0.8 }, 'io');
        return t.rest(200).loop({ stretch: 0.3, soft: 0.45 }); })(), 'Dust Bath Roll', 'A big wooden tub of dust stays out the whole dance: she flops right over onto her side in it and rolls - over onto her back with her feet in the air and back over onto her other side, left and right really fast, non stop for 10 seconds, a cloud of dust rising over the tub; then she rolls back up, shakes the dust off, does a happy hop and flops straight back down to go again - over and over until you stop her.'],
      mimi: [(() => { const t = TL({ smile: 0.8 }), H = both(4, -10);
        t.e('emit', 'note', 'head').to(220, o(H, { armL: 20, armR: 20 }), 'io');                                                       // paws together
        stepTo(t, [1.5, 3, 1.5, 0, -1.5, -3, -1.5, 0], 240, 2, { wag: 0 });                                                           // shuffle right ... and left
        t.osc(700, 4, { wag: 30, x: 0.6 }, { wag: -30, x: -0.6 }, 'io').to(120, { wag: 0, x: 0 }, 'io'); squeak(t);                    // tail swish, squeak
        t.e('emit', 'note', 'head');
        t.to(900, { spin: 360 }, 'io').to(1, { spin: 0 }, 'l'); para(t, t.t - 900, u => steps(u, 900, 4, 2));                          // a twirl on the spot
        t.to(220, o(NOHANDS, { armL: 0, armR: 0, sq: -0.06, lift: 1.2 }), 'o'); for (let i = 0; i < 3; i++) t.to(90, both(2, -6), 'o').to(110, both(6, -4), 'io');   // up on tiptoes, claps
        t.to(220, o(H, { sq: 0, lift: 0 }), 'io'); squeak(t);
        return t.rest(250).loop({ stretch: 0.7 }); })(), 'Cheese Shuffle', 'Paws together, a tiny shuffle to the right and to the left, a tail swish and a squeak, a twirl on the spot, then up on her tiptoes clapping.'],
      puddles: [(() => { const t = TL({ smile: 0.8 });
        t.e('emit', 'note', 'head'); waddle(t, [1.5, 3, 4.5, 3, 1.5, 0, -1.5, -3, -4.5, -3, -1.5, 0], 280);                             // waddle waddle
        flap(t, 3, 260, 105); t.to(150, { armL: 0, armR: 0 }, 'io'); quack(t);
        jump(t, { h: 11, ant: 170, up: 250, c: 0.2, arm: 110, land: { sq: 0.3 }, ev: [['emit', 'splash', 'body', 2], ['emit', 'splash', 'body', 2]] });   // jumps into a puddle - SPLASH
        t.to(200, { hap: 1, smile: 1 }, 'io').osc(900, 7, { wag: 34, x: 0.8, tilt: 3 }, { wag: -34, x: -0.8, tilt: -3 }, 'io').to(150, { wag: 0, x: 0, tilt: 0 }, 'io');   // tail-feather wiggle
        t.to(900, { spin: 360 }, 'io').to(1, { spin: 0 }, 'l'); para(t, t.t - 900, u => steps(u, 900, 4, 2)); quack(t); quack(t);
        t.to(150, { hap: 0 }, 'io');
        return t.rest(250).loop({ stretch: 0.7 }); })(), 'Puddle Splash', 'Waddles right and left, flaps her wings and quacks, jumps into a puddle with a big splash, wiggles her tail feathers, a spin and two quacks.'],
      bean: [(() => { const t = TL({ smile: 0.8, tongue: 0.5, open: 0.2 });
        t.e('emit', 'note', 'head'); swing(t, 1600, 7, { x: 1.6, tilt: 5, wag: 42, bend: 2 }); snort(t, 2);                             // butt wiggle
        t.to(260, { pitch: -0.25, sq: 0.12, lift: -0.6, armL: -20, armR: -20, wag: 30 }, 'io').osc(700, 4, { wag: -40 }, { wag: 40 }, 'io').to(240, { pitch: 0, sq: 0, lift: 0, armL: 0, armR: 0, wag: 0 }, 'io');   // play bow
        for (let i = 0; i < 2; i++) { t.e('emit', 'dust', 'body', 2); t.to(700, { spin: 360, tilt: 6 }, 'io').to(1, { spin: 0 }, 'l'); para(t, t.t - 700, u => steps(u, 700, 4, 2.5)); }   // zoomies on the spot
        t.to(150, { tilt: 0 }, 'io'); snort(t, 2);
        jump(t, { h: 7, ant: 150, up: 190, c: 0.16, arm: 40 }); t.e('emit', 'heart', 'head', 1);
        return t.rest(300).loop({ stretch: 0.7 }); })(), 'Pug Wiggle', 'A big butt wiggle with his curly tail going, two snorts, a play bow, two rounds of zoomies spinning on the spot, more snorts and a happy hop - tongue out the whole time.'],
      zippy: [(() => { const t = TL({ smile: 0.9, hap: 0.6, open: 0.25 });
        t.e('emit', 'note', 'head');
        for (let i = 0; i < 6; i++) { const d = i % 2 ? -1 : 1; jump(t, { h: 7, ant: 70, up: 150, c: 0.1, arm: 50, x: [4, -4, 5, -5, 2, 0][i], air: { tilt: d * 12, bend: -3, wag: d * 30 }, fall: { tilt: 0, bend: 0, wag: 0 } }); }   // frantic sideways war-dance hops
        dook(t, 3);
        t.to(200, { sq: -0.12, lift: 1, bend: -4 }, 'o').to(260, { sq: 0.08, lift: 0, bend: 0 }, 'i');                                 // arches his back ...
        jump(t, { h: 9, ant: 70, up: 170, c: 0.12, arm: 50, x: 6, air: { tilt: 18 }, fall: { tilt: 26 }, land: { sq: 0.2 } });         // ... bonks into the 'wall' ...
        t.to(120, { x: 6, tilt: 30, close: 1, cross: 0 }, 'o').wait(500).to(260, { tilt: 0, close: 0 }, 'io'); headShake(t, 0.8);      // ... flops over, gets up, shakes it off
        t.to(500, { x: 0 }, 'io'); para(t, t.t - 500, u => steps(u, 500, 2, 2.5));
        jump(t, { h: 12, ant: 120, up: 230, c: 0.18, arm: 60, spin: 360 }); dook(t, 3); t.to(150, { open: 0.25 }, 'io');
        return t.rest(250).loop({ stretch: 0.7 }); })(), 'Weasel War Dance', 'Frantic sideways war-dance hops with his back arched and mouth open, dook dook dook, bonks into an invisible wall and flops over, gets up, shakes it off, then a spinning hop and more dooks.'],
      mango: [(() => { const t = TL({ smile: 0.9, hap: 0.4 }), B = 600;
        t.e('emit', 'note', 'head');
        for (let i = 0; i < 4; i++) { const f = i % 2 ? 'footL' : 'footR'; t.to(B * 0.35, { [f]: 2.6, tilt: i % 2 ? -3 : 3, wag: i % 2 ? -24 : 24 }, 'o').to(B * 0.65, { [f]: 0, tilt: 0 }, 'i'); }   // sticky toe taps
        swing(t, 2000, 3, { x: 1.5, tilt: 4, wag: 34, htilt: -3 }); bob(t, 2, 500, 0.1);                                               // slow sway, tail swish, chill nods
        t.e('emit', 'note', 'head').osc(800, 10, { wag: 12 }, { wag: -12 }, 'l').to(150, { wag: 0 }, 'io');                            // tail rattle!
        eyeLick(t, 1); t.to(220, { sq: -0.06, lift: 1.5, pitch: 0.12 }, 'o').wait(300).to(260, { sq: 0, lift: 0, pitch: 0 }, 'io');    // licks his eye, stands up proud
        t.to(1400, { spin: 360 }, 'io').to(1, { spin: 0 }, 'l'); para(t, t.t - 1400, u => steps(u, 1400, 4, 2));                        // a slow turn on the spot
        slowBlink(t);
        return t.rest(300).loop({ stretch: 0.7 }); })(), 'Sticky Toe Tap', 'Taps his sticky toes left and right, sways slowly with his tail swishing, two chill nods, rattles his tail, licks his eye, stands up proud and does a slow turn on the spot.'],
    };
    KEYS.forEach(k => { MOVES[k].dance = DANCES[k]; });
    install(MOVES, CARDS);
  })();

  // =====================================================================================================================================
  // pokes (14 spots)
  (function boot() {
    const R = window.RiveRig; if (!R || !R.POKELIB || !R.pet2V || !R.STATES.poke_head) { setTimeout(boot, 25); return; } if (R.pet2PokeV) return; R.pet2PokeV = 1;
    const { S, o, jump, shake, jelly, popcorn, both, hand, NOHANDS } = R.PETLIB;
    const { see, unsee, giggle, hmph, sneeze, sniff, lick, para, leanIn, swat, pawShake, headShake, snort, freeze, curl, blushy, happy, pat, smooth, rub, build } = R.POKELIB;
    const chirp = (t, a) => t.to(90, { open: 0.5 * (a || 1), mw: 0.6, pitch: 0.08 }, 'o').e('emit', 'note', 'head').to(140, { open: 0, mw: 1, pitch: 0 }, 'io');
    const quack = t => t.to(90, { open: 0.65, mw: 1.1, pitch: 0.12 }, 'o').e('emit', 'note', 'head').to(170, { open: 0, mw: 1, pitch: 0 }, 'io');
    const squeak = t => t.to(70, { open: 0.4, mw: 0.55, pitch: 0.1 }, 'o').e('emit', 'note', 'head').to(140, { open: 0, mw: 1, pitch: 0 }, 'io');
    const dook = (t, n) => { t.to(120, { open: 0.35, hap: 1, smile: 1 }, 'o'); for (let i = 0; i < (n || 3); i++) t.to(80, { lift: 1.6, sq: -0.05 }, 'o').to(90, { lift: 0, sq: 0.04 }, 'i'); t.e('emit', 'note', 'head'); return t.to(160, { sq: 0, open: 0, hap: 0, smile: 0 }, 'io'); };
    const twitch = (t, n) => t.osc((n || 3) * 150, n || 3, { mw: 0.7, pitch: 0.04 }, { mw: 1, pitch: 0 }, 'o');
    const peck = (t, n) => { for (let i = 0; i < (n || 2); i++) t.to(90, { pitch: -0.2, sq: 0.04, open: 0.2 }, 'o').to(150, { pitch: 0, sq: 0, open: 0 }, 'io'); return t; };   // a gentle nibble at your finger
    const crest = (t, v, d) => t.to(d || 140, { earL: v, earR: v }, 'o');
    const flap = (t, n, A) => { for (let i = 0; i < n; i++) t.to(110, { armL: A, armR: A }, 'o').to(140, { armL: A * 0.25, armR: A * 0.25 }, 'io'); return t.to(150, { armL: 0, armR: 0 }, 'io'); };
    const wagT = (t, n, a, per) => t.osc((per || 160) * n, n, { wag: a || 30 }, { wag: -(a || 30) }, 'io').to(120, { wag: 0 }, 'io');
    const eyeLick = (t, s) => { const k = S(s); return t.to(120, { tongue: 1, open: 0.3, pitch: 0.18, htilt: s * 8, [k.wink]: 0.8 }, 'o').to(160, { tongue: 0.7, [k.wink]: 1 }, 'io').to(150, { tongue: 0, open: 0, pitch: 0, htilt: 0, [k.wink]: 0 }, 'io'); };
    const BODY = {
      tilly: { ear: 1.3, tail: 1, earTap: [44, 12], lbl: { ear: s => s < 0 ? 'Crest (left)' : 'Crest (right)', side: 'wing', tail: 'Tail feathers', nose: 'Beak' } },
      pico: { ear: 0, tail: 1, earTap: [30, 30], lbl: { ear: 'head stripes', side: 'wing', tail: 'Tail feathers', nose: 'Beak' } },
      clover: { ear: 1.3, tail: 1, earTap: [39, 13], lbl: { ear: 'long ear', tail: 'Cotton tail' } },
      chilla: { ear: 1, tail: 1, lbl: { tail: 'Bushy tail' } },
      mimi: { ear: 1.1, tail: 1 },
      puddles: { ear: 0.5, tail: 1, earTap: [49, 15], lbl: { ear: s => s < 0 ? 'Head fluff (left)' : 'Head fluff (right)', side: 'wing', foot: 'webbed foot', nose: 'Bill', tail: 'Tail' } },
      bean: { ear: 0.5, tail: 1, lbl: { tail: 'Curly tail', nose: 'Squishy nose' } },
      zippy: { ear: 0.6, tail: 1, lbl: { tail: 'Fluffy tail' } },
      mango: { ear: 0, tail: 1, noWalk: 1, earTap: [24, 40], lbl: { ear: 'head side', foot: 'sticky toes', tail: 'Chunky tail' } },
    };
    const RE = {
      tilly: {
        head: (t, s) => { crest(t, -28, 120); t.wait(250); see(t, 'head', 0, 200); unsee(t); t.to(260, { earL: 0, earR: 0, close: 0.6, hap: 1 }, 'io').osc(700, 2, { pitch: -0.12 }, { pitch: 0 }, 'io').to(200, { close: 0, hap: 0 }, 'io'); },   // crest pops up, then she bows for more head scratches
        ear: (t, s) => { const k = S(s); t.to(90, { [k.ear]: -34 }, 'o').to(200, { [k.ear]: 10 }, 'io').to(200, { [k.ear]: 0 }, 'io'); see(t, 'ear', s, 200); unsee(t); chirp(t, 0.7); },
        nose: (t, s) => { t.to(200, { cross: 1 }, 'io'); peck(t, 2); t.to(150, { cross: 0, hap: 1 }, 'io'); chirp(t); t.to(200, { hap: 0 }, 'io'); },       // nibbles your finger gently
        eye: (t, s) => { const k = S(s); t.to(200, { [k.wink]: 1, earL: 16, earR: 16 }, 'io').wait(250).to(200, { [k.wink]: 0, earL: 0, earR: 0 }, 'io'); headShake(t, 0.7); },
        cheek: (t, s) => { leanIn(t, s, { earL: 14, earR: 14 }); t.to(200, { earL: 0, earR: 0 }, 'io'); },                                          // loves cheek scratches: crest goes flat with bliss
        belly: (t, s) => { t.to(150, { sq: 0.14, earL: 18, earR: 18 }, 'o'); giggle(t, 3); t.to(200, { sq: 0, earL: 0, earR: 0 }, 'io'); },
        side: (t, s) => { const k = S(s); t.to(100, { [k.arm]: 80 }, 'o').to(260, { [k.arm]: 20 }, 'io').e('emit', 'featherY', 'body', 1); see(t, 'side', s, 200); unsee(t); t.to(150, { [k.arm]: 0 }, 'io'); },   // wing flicks out
        foot: (t, s) => { const k = S(s); t.to(120, { [k.foot]: 3, lift: 1 }, 'o').to(200, { [k.foot]: 0, lift: 0 }, 'i'); see(t, 'foot', s, 200); unsee(t); chirp(t, 0.5); },
        tail: (t, s) => { wagT(t, 3, 24); see(t, 'tail', 1, 300); unsee(t); crest(t, -18, 140); t.to(250, { earL: 0, earR: 0 }, 'io'); },
      },
      pico: {
        head: (t, s) => { t.to(80, { sq: 0.1 }, 'o').to(150, { sq: 0 }, 'io'); see(t, 'head', 0, 150); unsee(t); chirp(t); chirp(t, 0.6); },
        ear: (t, s) => { see(t, 'ear', s, 100); t.osc(600, 4, { htilt: s * 10 }, { htilt: s * 4 }, 'io'); unsee(t); chirp(t, 0.7); },
        nose: (t, s) => { t.to(150, { cross: 1 }, 'io'); peck(t, 3); t.to(150, { cross: 0 }, 'io'); t.e('emit', 'heart', 'head', 1); chirp(t); },
        eye: (t, s) => { const k = S(s); t.to(180, { [k.wink]: 1 }, 'io').wait(200).to(160, { [k.wink]: 0 }, 'io'); t.to(70, { hyaw: -s * 0.4 }, 'o').wait(150).to(90, { hyaw: 0 }, 'o'); chirp(t, 0.6); },
        cheek: (t, s) => { leanIn(t, s); },
        belly: (t, s) => { t.to(150, { sq: 0.12 }, 'o'); giggle(t, 3); flap(t, 2, 80); },
        side: (t, s) => { const k = S(s); t.to(100, { [k.arm]: 90 }, 'o').to(220, { [k.arm]: 15 }, 'io').e('emit', 'featherG', 'body', 1); see(t, 'side', s, 150); unsee(t); t.to(120, { [k.arm]: 0 }, 'io'); },
        foot: (t, s) => { const k = S(s); t.to(100, { [k.foot]: 3, lift: 1 }, 'o').to(150, { [k.foot]: 0, lift: 0 }, 'i'); see(t, 'foot', s, 150); unsee(t); chirp(t, 0.5); },
        tail: (t, s) => { wagT(t, 4, 24, 120); see(t, 'tail', 1, 200); unsee(t); chirp(t); },
      },
      clover: {
        head: (t, s) => { t.to(260, { close: 0.9, hap: 1, smile: 1, earL: 16, earR: 16, pitch: -0.12, sq: 0.06 }, 'io').wait(500).to(260, { close: 0, earL: 0, earR: 0, pitch: 0, sq: 0, hap: 0, smile: 0 }, 'io'); twitch(t, 3); },   // melts flat for head pats
        ear: (t, s) => { const k = S(s); t.to(260, { [k.ear]: 24 }, 'io').wait(150).to(300, { [k.ear]: 0 }, 'io'); see(t, 'ear', s, 150); unsee(t); headShake(t, 0.7); },   // the long ear flicks back and springs up, then an ear shake
        nose: (t, s) => { t.to(150, { cross: 1 }, 'io'); twitch(t, 6); t.to(150, { cross: 0 }, 'io'); lick(t, 1); t.e('emit', 'heart', 'head', 1); },
        eye: (t, s) => { const k = S(s); t.to(200, { [k.wink]: 1 }, 'io').wait(250).to(200, { [k.wink]: 0 }, 'io'); rub(t, s, 'eye', 2); },
        cheek: (t, s) => { leanIn(t, s, { earL: 10, earR: 10 }); t.to(200, { earL: 0, earR: 0 }, 'io'); },
        belly: (t, s) => { t.to(150, { sq: 0.1 }, 'o'); giggle(t, 3); },
        side: (t, s) => { see(t, 'side', s, 150); unsee(t); twitch(t, 2); },
        foot: (t, s) => { const k = S(s); t.to(200, { [k.foot]: 3.5, earL: 14, earR: 14 }, 'io').to(70, { [k.foot]: 0, sq: 0.1 }, 'i').e('emit', 'dust', 'body', 2).to(160, { sq: 0, earL: 0, earR: 0 }, 'io'); see(t, 'foot', s, 150); unsee(t); },   // THUMP
        tail: (t, s) => { t.osc(500, 4, { wag: 20 }, { wag: -20 }, 'io').to(100, { wag: 0 }); see(t, 'tail', 1, 300); unsee(t); giggle(t, 1); },
      },
      chilla: {
        head: (t, s) => { t.to(250, { close: 0.9, hap: 1, pitch: -0.1, earL: 10, earR: 10 }, 'io').wait(500).to(250, { close: 0, hap: 0, pitch: 0, earL: 0, earR: 0 }, 'io'); },
        ear: (t, s) => { const k = S(s); t.osc(500, 3, { [k.ear]: -14 }, { [k.ear]: 8 }, 'io').to(120, { [k.ear]: 0 }); see(t, 'ear', s, 150); unsee(t); },
        nose: (t, s) => { t.to(150, { cross: 1 }, 'io'); sniff(t, 4); t.to(150, { cross: 0 }, 'io'); lick(t, 1); },
        eye: (t, s) => { const k = S(s); t.to(200, { [k.wink]: 1 }, 'io').wait(250).to(200, { [k.wink]: 0 }, 'io'); rub(t, s, 'eye', 2); },
        cheek: (t, s) => { leanIn(t, s); },
        belly: (t, s) => { t.to(150, { sq: 0.14 }, 'o'); giggle(t, 3); t.e('emit', 'poof', 'body', 2); },                                                 // so fluffy a little dust puffs out
        side: (t, s) => { popcorn(t, 9, -s, 460); t.e('emit', 'poof', 'body', 2); see(t, 'side', s, 150); unsee(t); },                                    // pops straight up
        foot: (t, s) => { pawShake(t, s, 0.8); see(t, 'foot', s, 150); unsee(t); },
        tail: (t, s) => { t.osc(700, 4, { wag: 30, curl: 0.4 }, { wag: -30, curl: 0 }, 'io').to(120, { wag: 0, curl: 0 }); see(t, 'tail', 1, 300); unsee(t); giggle(t, 1); },
      },
      mimi: {
        head: (t, s) => { t.to(120, { sq: 0.12, earL: 14, earR: 14 }, 'o'); squeak(t); t.to(200, { sq: 0, earL: 0, earR: 0 }, 'io'); see(t, 'head', 0, 150); unsee(t); },
        ear: (t, s) => { const k = S(s); t.osc(400, 3, { [k.ear]: -16 }, { [k.ear]: 8 }, 'io').to(100, { [k.ear]: 0 }); see(t, 'ear', s, 150); rub(t, s, 'ear', 2); unsee(t); },
        nose: (t, s) => { t.to(150, { cross: 1 }, 'io'); t.osc(900, 6, { mw: 0.7, pitch: 0.05 }, { mw: 1, pitch: 0 }, 'o'); t.to(150, { cross: 0 }, 'io'); squeak(t); },   // sniff-sniff-sniff, whiskers going
        eye: (t, s) => { const k = S(s); t.to(160, { [k.wink]: 1 }, 'io').wait(200).to(160, { [k.wink]: 0 }, 'io'); rub(t, s, 'eye', 3); },
        cheek: (t, s) => { leanIn(t, s); },
        belly: (t, s) => { t.to(150, { sq: 0.12 }, 'o'); giggle(t, 4); squeak(t); },
        side: (t, s) => { t.to(70, { wide: 1 }, 'o'); squeak(t); see(t, 'side', s, 150); unsee(t); t.to(150, { wide: 0 }, 'io'); },
        foot: (t, s) => { pawShake(t, s, 0.7); see(t, 'foot', s, 150); unsee(t); squeak(t); },
        tail: (t, s) => { t.osc(500, 5, { wag: 34 }, { wag: -34 }, 'io').to(100, { wag: 0 }); t.to(70, { wide: 1 }, 'o'); squeak(t); see(t, 'tail', 1, 250); unsee(t); t.to(150, { wide: 0 }, 'io'); },
      },
      puddles: {
        head: (t, s) => { t.to(80, { sq: 0.14, earL: -16, earR: -16 }, 'o').to(200, { sq: 0, earL: 0, earR: 0 }, 'io'); quack(t); see(t, 'head', 0, 150); unsee(t); },
        ear: (t, s) => { const k = S(s); t.osc(500, 3, { [k.ear]: -20 }, { [k.ear]: 10 }, 'io').to(100, { [k.ear]: 0 }); see(t, 'ear', s, 150); unsee(t); giggle(t, 1); },
        nose: (t, s) => { t.to(150, { cross: 1 }, 'io'); peck(t, 2); t.to(150, { cross: 0 }, 'io'); quack(t); },                                       // nibbles your finger with her bill
        eye: (t, s) => { const k = S(s); t.to(200, { [k.wink]: 1 }, 'io').wait(250).to(200, { [k.wink]: 0 }, 'io'); headShake(t, 0.7); },
        cheek: (t, s) => { leanIn(t, s); },
        belly: (t, s) => { t.to(150, { sq: 0.12 }, 'o'); giggle(t, 3); flap(t, 2, 90); },
        side: (t, s) => { const k = S(s); t.to(100, { [k.arm]: 90 }, 'o').to(220, { [k.arm]: 15 }, 'io').e('emit', 'fluffY', 'body', 1); see(t, 'side', s, 150); unsee(t); t.to(120, { [k.arm]: 0 }, 'io'); },
        foot: (t, s) => { const k = S(s); t.to(150, { [k.foot]: 3 }, 'o').to(80, { [k.foot]: 0, sq: 0.08 }, 'i').e('emit', 'splash', 'body', 2).to(150, { sq: 0 }, 'io'); see(t, 'foot', s, 150); unsee(t); giggle(t, 1); },   // splashy stomp
        tail: (t, s) => { wagT(t, 5, 34, 120); see(t, 'tail', 1, 250); unsee(t); quack(t); },
      },
      bean: {
        head: (t, s) => { t.to(260, { close: 0.9, hap: 1, tongue: 0.6, open: 0.25, pitch: -0.08 }, 'io'); wagT(t, 4, 38); t.to(250, { close: 0, hap: 0, tongue: 0, open: 0, pitch: 0 }, 'io'); },   // head pat: eyes shut, tongue out, tail going
        ear: (t, s) => { const k = S(s); t.to(120, { [k.ear]: -14 }, 'o').to(200, { [k.ear]: 0 }, 'io'); t.to(300, { htilt: s * 14 }, 'io').wait(300).to(250, { htilt: 0 }, 'io'); },   // a puzzled head tilt
        nose: (t, s) => { t.to(150, { cross: 1 }, 'io'); snort(t, 2); t.to(150, { cross: 0 }, 'io'); lick(t, 2); t.e('emit', 'heart', 'head', 1); },
        eye: (t, s) => { const k = S(s); t.to(200, { [k.wink]: 1 }, 'io').wait(250).to(200, { [k.wink]: 0 }, 'io'); snort(t, 1); },
        cheek: (t, s) => { leanIn(t, s, { tongue: 0.5, open: 0.2 }); t.to(200, { tongue: 0, open: 0 }, 'io'); },
        belly: (t, s) => { t.to(200, { sq: 0.12, hap: 1, tongue: 0.6, open: 0.3 }, 'o'); const a = t.t; giggle(t, 3); para(t, a, u => u.osc(800, 4, { footL: 2.5, footR: 0 }, { footL: 0, footR: 2.5 }, 'io').to(150, { footL: 0, footR: 0 })); t.to(200, { tongue: 0, open: 0, hap: 0 }, 'io'); },   // belly rub leg-kicks
        side: (t, s) => { see(t, 'side', s, 150); unsee(t); snort(t, 1); },
        foot: (t, s) => { pawShake(t, s, 0.8); see(t, 'foot', s, 150); unsee(t); },
        tail: (t, s) => { t.to(300, { hap: 1, smile: 1 }, 'io'); wagT(t, 6, 44, 120); see(t, 'tail', 1, 200); unsee(t); t.to(200, { hap: 0, smile: 0 }, 'io'); },
      },
      zippy: {
        head: (t, s) => { dook(t, 3); see(t, 'head', 0, 120); unsee(t); },
        ear: (t, s) => { const k = S(s); t.to(80, { [k.ear]: -14 }, 'o').to(150, { [k.ear]: 0 }, 'io'); see(t, 'ear', s, 100); unsee(t); dook(t, 2); },
        nose: (t, s) => { t.to(150, { cross: 1 }, 'io'); sniff(t, 3); t.to(150, { cross: 0 }, 'io'); lick(t, 1); },
        eye: (t, s) => { const k = S(s); t.to(160, { [k.wink]: 1 }, 'io').wait(200).to(160, { [k.wink]: 0 }, 'io'); headShake(t, 0.8); },
        cheek: (t, s) => { leanIn(t, s); },
        belly: (t, s) => { t.to(150, { sq: 0.12 }, 'o'); giggle(t, 4, 1.2); dook(t, 2); },
        side: (t, s) => { jump(t, { h: 6, ant: 50, up: 140, c: 0.08, arm: 40, x: -s * 3, air: { tilt: -s * 10 }, fall: { tilt: 0 } }); see(t, 'side', s, 150); unsee(t); },   // a sideways war-dance hop away
        foot: (t, s) => { pawShake(t, s, 0.8); see(t, 'foot', s, 120); unsee(t); dook(t, 2); },
        tail: (t, s) => { t.to(70, { wide: 1, sq: -0.08 }, 'o').osc(500, 4, { wag: 36 }, { wag: -36 }, 'io').to(100, { wag: 0, sq: 0 }); see(t, 'tail', 1, 200); unsee(t); t.to(150, { wide: 0 }, 'io'); dook(t, 2); },
      },
      mango: {
        head: (t, s) => { t.to(300, { close: 1, hap: 1, smile: 1, pitch: -0.06 }, 'io').wait(700).to(400, { close: 0, pitch: 0 }, 'io').to(200, { hap: 0, smile: 0 }, 'io'); },   // a long happy eyes-shut moment
        ear: (t, s) => { t.to(300, { htilt: s * 10 }, 'io'); see(t, 'ear', s, 250); unsee(t, 400); t.to(250, { htilt: 0 }, 'io'); },
        nose: (t, s) => { t.to(200, { cross: 1 }, 'io').to(120, { tongue: 0.9, open: 0.3 }, 'o').to(160, { tongue: 0, open: 0 }, 'io').to(200, { cross: 0 }, 'io'); t.e('emit', 'heart', 'head', 1); },   // tastes your finger with his tongue
        eye: (t, s) => { const k = S(s); t.to(220, { [k.wink]: 1 }, 'io').wait(200).to(200, { [k.wink]: 0 }, 'io'); eyeLick(t, s); },                       // licks that eye clean
        cheek: (t, s) => { leanIn(t, s); },
        belly: (t, s) => { t.to(200, { sq: 0.1 }, 'o'); giggle(t, 2, 0.8); t.osc(600, 4, { wag: 20 }, { wag: -20 }, 'io').to(100, { wag: 0 }); },
        side: (t, s) => { t.to(300, { bend: s * 4, wag: -s * 20 }, 'io'); see(t, 'side', s, 300); unsee(t, 400); t.to(300, { bend: 0, wag: 0 }, 'io'); },
        foot: (t, s) => { const k = S(s); t.to(260, { [k.foot]: 3 }, 'io').osc(500, 3, { [k.foot]: 3.5 }, { [k.foot]: 2.5 }, 'io').to(260, { [k.foot]: 0 }, 'io'); see(t, 'foot', s, 200); unsee(t); },   // peels his sticky toes off, one by one
        tail: (t, s) => { t.osc(800, 10, { wag: 12 }, { wag: -12 }, 'l').to(100, { wag: 0 }); see(t, 'tail', 1, 300); unsee(t, 400); },                     // tail rattle
      },
    };
    const TXT = {
      tilly: { head: 'Her crest pops up, then she bows her head for more scratches.', ear: 'That crest feather flicks up and back, she looks up and whistles.', nose: 'Gently nibbles your finger with her beak, then a happy whistle.',
        eye: 'Blinks hard with her crest going flat, a little head shake.', cheek: 'Leans her cheek into your finger, crest flat with bliss.', belly: 'Fluffs up and giggles, crest flat.',
        side: 'Her wing flicks out and a feather drifts down; she looks at the spot.', foot: 'Lifts that foot, looks down and gives a small whistle.', tail: 'Her tail feathers wag, she looks back and her crest pops up.' },
      pico: { head: 'Bobs down under your finger, looks up, two chirps.', ear: 'Tilts his head to show off his stripes, then chirps.', nose: 'Pecks your finger playfully - peck peck peck - a heart and a chirp.',
        eye: 'Blinks, a quick bird head-snap away and back, a chirp.', cheek: 'Leans into your finger.', belly: 'Puffs up giggling and flaps his wings.',
        side: 'His wing flicks out and a feather drifts down.', foot: 'Lifts that foot and looks at it, chirp.', tail: 'Tail flicks fast, he looks back and chirps.' },
      clover: { head: 'Melts flat with her eyes shut and her ears spread - a happy bunny - then her nose twitches.', ear: 'That long ear flicks back and springs up, then an ear shake.',
        nose: 'Her nose twitches like crazy at your finger, then a little lick and a heart.', eye: 'Blinks and rubs her eye with a paw.', cheek: 'Leans into your finger.', belly: 'Giggles.',
        side: 'Looks at the spot, nose twitching.', foot: 'THUMP - stamps that foot and looks down at it.', tail: 'Her cotton tail wiggles, she looks back and giggles.' },
      chilla: { head: 'Shuts her eyes and leans into the pat.', ear: 'That big round ear flicks back and forth.', nose: 'Sniffs your finger and licks it.', eye: 'Blinks and rubs her eye.',
        cheek: 'Leans into your finger.', belly: 'So fluffy that a little dust puffs out when she giggles.', side: 'Pops straight up like popcorn.', foot: 'Shakes that foot.', tail: 'Her bushy tail swishes, she looks back and giggles.' },
      mimi: { head: 'Squeaks and ducks with her ears out.', ear: 'That big pink ear flutters, she rubs it.', nose: 'Sniff-sniff-sniff with her whiskers going, then a squeak.', eye: 'Blinks and rubs her eye with a tiny paw.',
        cheek: 'Leans into your finger.', belly: 'Giggles and squeaks.', side: 'Jumps with a squeak, eyes wide.', foot: 'Shakes that foot and squeaks.', tail: 'Her tail flicks fast, squeak! - she looks back.' },
      puddles: { head: 'Ducks with her head fluff standing up, then a quack.', ear: 'Her head fluff wiggles, she giggles.', nose: 'Nibbles your finger with her bill, quack.', eye: 'Blinks, a little head shake.',
        cheek: 'Leans into your finger.', belly: 'Giggles and flaps her wings.', side: 'Her wing flicks out and some fluff floats off.', foot: 'Stomps that webbed foot - splash - and giggles.', tail: 'Waggles her tail, looks back, quack.' },
      bean: { head: 'Eyes shut, tongue out, his curly tail going.', ear: 'His ear perks and he tilts his head, puzzled.', nose: 'Snorts at your finger, then licks it: a heart.', eye: 'Blinks hard and snorts.',
        cheek: 'Leans into your finger with his tongue out.', belly: 'Belly rub! Giggles with his back legs kicking.', side: 'Looks at the spot and snorts.', foot: 'Shakes that paw.', tail: 'His curly tail wags like mad.' },
      zippy: { head: 'Happy dooks, bouncing.', ear: 'His ear flicks, he looks up - dook dook.', nose: 'Sniffs your finger and licks it.', eye: 'Blinks and shakes his head.', cheek: 'Leans into your finger.',
        belly: 'Super ticklish: giggles and dooks.', side: 'A sideways war-dance hop away from the poke.', foot: 'Shakes that paw, then dooks.', tail: 'His tail puffs and swishes, he looks back - dook.' },
      mango: { head: 'Shuts his eyes with a big grin for a long happy moment.', ear: 'Tilts his head slowly toward the poke and looks.', nose: 'Tastes your finger with his tongue: a heart.',
        eye: 'Blinks, then licks that eyeball clean.', cheek: 'Leans into your finger.', belly: 'Giggles, tail swishing.', side: 'Curves away and looks at the spot, slowly.', foot: 'Peels his sticky toes up and pats them back down.', tail: 'Rattles the tip of his tail.' },
    };
    build(RE, TXT, BODY);
  })();

  // =====================================================================================================================================
  // eating (all 20 foods, each their own way)
  (function boot() {
    const R = window.RiveRig; if (!R || !R.EATKIT || !R.pet2V || !R.EATLIB) { setTimeout(boot, 25); return; } if (R.pet2EatV) return; R.pet2EatV = 1;
    const { o, jump, swing, popcorn } = R.PETLIB;
    const { EAR, sniffF, lipLick, hearts, buildAll } = R.EATKIT;
    Object.assign(EAR, { tilly: 1, pico: 0, clover: 1.2, chilla: 0.9, mimi: 1, puddles: 0.4, bean: 0.5, zippy: 0.6, mango: 0 });
    const chirp = (t, a) => t.to(90, { open: 0.5 * (a || 1), mw: 0.6, pitch: 0.08 }, 'o').e('emit', 'note', 'head').to(140, { open: 0, mw: 1, pitch: 0 }, 'io');
    const quack = t => t.to(90, { open: 0.65, mw: 1.1, pitch: 0.12 }, 'o').e('emit', 'note', 'head').to(170, { open: 0, mw: 1, pitch: 0 }, 'io');
    const bob = (t, n) => { for (let i = 0; i < n; i++) t.to(100, { pitch: -0.14, sq: 0.02 }, 'o').to(150, { pitch: 0.03, sq: 0 }, 'io'); return t.to(100, { pitch: 0 }, 'io'); };
    const CARDS = {
      tilly: { chewMs: 110, chewN: 1.2, open: 0.5, crumbs: 1, txt: 'Crest up with interest, quick little beak nibbles; bobs her head and whistles when she likes it.',
        pre: t => { t.to(160, { earL: -20, earR: -20 }, 'o'); sniffF(t, 1); }, post: t => t.to(250, { earL: 0, earR: 0 }, 'io'),
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io'); bob(t, 3); chirp(t); },
        love: t => { hearts(t, 2); t.to(200, { armL: 96, armR: 96, earL: -26, earR: -26 }, 'o'); bob(t, 3); t.to(240, { armL: 0, armR: 0, earL: 0, earR: 0 }, 'io'); chirp(t); } },
      pico: { chewMs: 90, chewN: 1.4, open: 0.5, crumbs: 2, txt: 'Pecks at it super fast; chatters and bobs when he likes it.',
        yum: t => { t.to(140, { hap: 1, smile: 1 }, 'io').osc(700, 5, { open: 0.4, mw: 0.6 }, { open: 0, mw: 1 }, 'o'); bob(t, 3); },
        love: t => { hearts(t, 2); jump(t, { h: 6, ant: 100, up: 160, c: 0.12, arm: 90 }); bob(t, 3); chirp(t); } },
      clover: { chewMs: 95, chewN: 1.5, open: 0.4, txt: 'Sniffs it with her nose twitching, tiny quick bunny nibbles; binkies when she loves it.',
        pre: t => { t.osc(450, 3, { mw: 0.7, pitch: 0.04 }, { mw: 1, pitch: 0 }, 'o'); },
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io').osc(450, 3, { mw: 0.7 }, { mw: 1 }, 'o'); },
        love: t => { hearts(t, 2); jump(t, { h: 12, ant: 150, up: 240, c: 0.18, arm: 20, air: { tilt: 10, turn: 0.35, earL: 28, earR: 28, footR: 3.5 }, fall: { tilt: 0, turn: 0, earL: 0, earR: 0, footR: 0 } }); } },
      chilla: { chewMs: 85, chewN: 1.5, open: 0.45, crumbs: 1, headY: -14, txt: 'Holds it up in both paws and nibbles it fast; popcorns when she loves it.',
        yum: t => { t.to(160, { hap: 1, smile: 1 }, 'io'); swing(t, 700, 3, { wag: 26 }); },
        love: t => { hearts(t, 2); popcorn(t, 13, 1, 520); } },
      mimi: { chewMs: 70, chewN: 1.8, open: 0.4, crumbs: 2, headY: -14, txt: 'Holds it in her tiny paws and nibbles it super fast, whiskers going; squeaks when she likes it.',
        pre: t => { t.osc(500, 4, { mw: 0.7, pitch: 0.05 }, { mw: 1, pitch: 0 }, 'o'); },
        yum: t => { t.to(70, { open: 0.4, mw: 0.55, hap: 1, smile: 1 }, 'o').e('emit', 'note', 'head').to(140, { open: 0, mw: 1 }, 'io'); swing(t, 600, 3, { wag: 30 }); },
        love: t => { hearts(t, 2); jump(t, { h: 8, ant: 60, up: 180, c: 0.12, arm: 50 }); CARDS.mimi.yum(t); } },
      puddles: { chewMs: 100, chewN: 1.1, open: 0.6, crumbs: 2, txt: 'Dabbles at it with her bill, gulps it down; quacks and waggles her tail when she likes it.',
        post: t => t.to(120, { pitch: 0.2, sq: -0.04 }, 'o').to(200, { pitch: 0, sq: 0 }, 'io'),
        yum: t => { t.to(140, { hap: 1, smile: 1 }, 'io'); quack(t); swing(t, 700, 5, { wag: 32 }); },
        love: t => { hearts(t, 2); t.to(100, { armL: 100, armR: 100 }, 'o').to(140, { armL: 25, armR: 25 }, 'io').to(100, { armL: 100, armR: 100 }, 'o').to(160, { armL: 0, armR: 0 }, 'io'); CARDS.puddles.yum(t); } },
      bean: { chewMs: 130, chewN: 0.7, open: 0.85, crumbs: 3, txt: 'Snorts at it excitedly and gobbles it in big messy bites; licks his nose and wiggles his butt when he likes it.',
        pre: t => { for (let i = 0; i < 2; i++) t.to(80, { sq: 0.05, pitch: 0.1, mw: 0.75 }, 'o').to(150, { sq: 0, pitch: 0, mw: 1 }, 'io'); },
        post: t => t.to(150, { tongue: 1, open: 0.35, pitch: 0.12 }, 'o').to(200, { tongue: 0.4 }, 'io').to(150, { tongue: 0, open: 0, pitch: 0 }, 'io'),
        yum: t => { t.to(150, { hap: 1, smile: 1 }, 'io'); swing(t, 1000, 7, { x: 1.4, tilt: 4, wag: 40 }); },
        love: t => { hearts(t, 2); CARDS.bean.yum(t); } },
      zippy: { chewMs: 90, chewN: 1.2, open: 0.6, crumbs: 2, txt: 'Grabs it quick, looks around in case anyone wants it, nibbles fast; dooks and bounces when he likes it.',
        pre: t => { t.to(90, { lx: -0.8 }, 'o').to(200, { hyaw: -0.2 }, 'io').to(90, { lx: 0.8 }, 'o').to(220, { hyaw: 0.2 }, 'io').to(200, { hyaw: 0, lx: 0 }, 'io'); },
        yum: t => { t.to(120, { open: 0.35, hap: 1, smile: 1 }, 'o'); for (let i = 0; i < 3; i++) t.to(80, { lift: 1.6, sq: -0.05 }, 'o').to(90, { lift: 0, sq: 0.04 }, 'i'); t.e('emit', 'note', 'head').to(140, { sq: 0, open: 0 }, 'io'); },
        love: t => { hearts(t, 2); jump(t, { h: 10, ant: 100, up: 200, c: 0.14, arm: 50, spin: 360 }); CARDS.zippy.yum(t); } },
      mango: { chewMs: 170, chewN: 0.8, open: 0.7, crumbs: 1, txt: 'Stalks it slowly with his tail tip twitching, a quick snap, slow chewing; licks his eye and grins when he likes it.',
        pre: t => { t.to(300, { pitch: -0.08, ly: 0.5 }, 'io').osc(700, 7, { wag: 10 }, { wag: -6 }, 'l').to(100, { wag: 0, pitch: 0, ly: 0 }, 'io'); },
        post: t => lipLick(t),
        yum: t => { t.to(300, { hap: 1, smile: 1 }, 'io').to(120, { tongue: 1, open: 0.3, pitch: 0.18, htilt: 8, winkR: 1 }, 'o').to(180, { tongue: 0, open: 0, pitch: 0, htilt: 0, winkR: 0 }, 'io'); swing(t, 1400, 3, { wag: 30 }); },
        love: t => { hearts(t, 2); CARDS.mango.yum(t); } },
    };
    buildAll(CARDS);
  })();
})();
