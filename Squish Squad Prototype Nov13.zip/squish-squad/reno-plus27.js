// Renovation Catalog round 27 — Kitchen FLOORS remodel (same build as the Living Room floors in plus20).
// Floors = r.f27: 80 x 56 perspective trapezoid; details laid out in flat floor space (u across, y depth) through RD.H20 W(u, y), creature scale.
// KIT-005 yellow linoleum tiles, KIT-025 retro diner checker, KIT-045 terracotta quarry tiles, KIT-065 wide-plank French oak, KIT-085 heated cushion-stone + vacuum plinth.
// Sets RenoDraw.PLUS27; catalog edits RD.SET27.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS26 && RD.H20 && RD.H21 && RD.H14 && RD.H11 && RD.N && RD.H13 && RD.H10 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS27) return;
  const shade = X.K.shade, PI = Math.PI, H = RD.H10;
  const { rng, an, SPL, f1, n4, rep } = H;
  const { FL, fblot } = RD.H13;
  const { W, polyW, lineW, crvW, chip } = RD.H20;
  const TR = 'M14 0H66L80 56H0Z';
  const wk = v => (52 + 28 * v) / 80, gv = t => t * (0.7 + 0.3 * t), K = y => RD._FLAT ? 0.82 : wk(gv(y));
  const pt = p => f1(p[0]) + ' ' + f1(p[1]);
  const quadW = (u0, y0, u1, y1) => polyW([[u0, y0], [u1, y0], [u1, y1], [u0, y1]]);
  const dot = (u, y, r, ex) => { const p = W(u, y), k = K(y); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(r * k)}" ry="${f1(r * k * (0.55 + 0.2 * gv(y)))}" ${ex}/>`; };
  const dotD = (u, y, r) => { const p = W(u, y), k = K(y), rx = r * k, ry = rx * (0.55 + 0.2 * gv(y)); return `M${f1(p[0] - rx)} ${f1(p[1])}a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(2 * rx)} 0a${f1(rx)} ${f1(ry)} 0 1 0 ${f1(-2 * rx)} 0Z`; };
  const rrW = (u0, y0, u1, y1, ru, ry) => { const P = []; [[u1 - ru, y0 + ry, -PI / 2], [u1 - ru, y1 - ry, 0], [u0 + ru, y1 - ry, PI / 2], [u0 + ru, y0 + ry, PI]].forEach(([cu, cy, a0]) => { for (let i = 0; i <= 4; i++) { const a = a0 + i / 8 * PI; P.push([cu + ru * Math.cos(a), cy + ry * Math.sin(a)]); } }); return polyW(P); };
  const refl = (op, col) => `<g filter="url(#fb3)"><path d="${polyW([[0.17, 0], [0.33, 0], [0.37, 0.5], [0.14, 0.5]])}" fill="${col || '#ffffff'}" opacity="${op}"/><path d="${polyW([[0.2, 0], [0.3, 0], [0.32, 0.3], [0.18, 0.3]])}" fill="${col || '#ffffff'}" opacity="${f1(op * 0.8)}"/>${dot(0.55, 0.22, 7, `fill="${col || '#ffffff'}" opacity="${f1(op * 0.7)}"`)}</g>`;
  const walk = (R, u, y, du, dy, n, jit) => { const P = [[u, y]]; for (let i = 0; i < n; i++) { u += du + (R() - 0.5) * jit; y += dy + (R() - 0.5) * jit * 1.4; P.push([u, y]); } return P; };
  const heel = (R, n, u0, u1) => rep(n, () => { const y = 0.15 + R() * 0.85, u = u0 + R() * (u1 - u0), p = W(u, y), k = K(y), l = (1 + R() * 2.2) * k, a = (R() - 0.5) * 1.4;
    return `<path d="M${pt(p)}q${f1(l * 0.5 * Math.cos(a))} ${f1(-0.4 * k)} ${f1(l * Math.cos(a))} ${f1(l * Math.sin(a) * 0.5)}" stroke="#2e2a26" stroke-width="${f1((0.14 + R() * 0.22) * k)}" stroke-linecap="round" fill="none" opacity="${f1(0.3 + R() * 0.35)}"/>`; }).join('');

  // KIT-005 cracked yellow linoleum, curled corners: 70s marbled mustard vinyl squares laid quarter-turned, grimy seams, cracks,
  // four corners curling up off the tar glue, one tile missing (trowel-combed black adhesive + stuck fragments), grease by the stove, a pot ring
  function fYlino() { const R = rng('ylino27'), NU = 12, NV = 8, gu = 0.0025, gy = 0.004, T = ['#e9c75e', '#e3bd50', '#efcd6a', '#dcb348', '#e6c25a', '#f0d274'];
    const MISS = '7,5', CURL = { '10,7': 2, '2,3': 1, '5,0': 3, '0,6': 2 }, CRACK = ['3,6', '8,2', '9,5', '1,1', '6,4', '11,3'];
    let s = '<rect width="80" height="56" fill="#6a5124"/>', hi = '', lo = '', mL = '', mD = '', ov = '', cr = '', miss = null; const curls = [];
    for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const key = i + ',' + j, u0 = i / NU + gu, u1 = (i + 1) / NU - gu, y0 = j / NV + gy, y1 = (j + 1) / NV - gy;
      if (key === MISS) { miss = [u0, y0, u1, y1]; continue; }
      const col = shade(T[(i * 5 + j * 3 + ((R() * 4) | 0)) % T.length], 0.94 + R() * 0.09), fl = (i + j) % 2;
      s += `<path d="${quadW(u0, y0, u1, y1)}" fill="${col}"/>`;
      for (let n = 0; n < 4; n++) { const a = 0.12 + R() * 0.76, b = a + (R() - 0.5) * 0.5, ph = R() * 6;
        const P = rep(6, q => { const t = q / 5, m = Math.min(0.95, Math.max(0.05, a + (b - a) * t + 0.07 * Math.sin(t * 7 + ph))), tu = fl ? m : 0.04 + t * 0.92, ty = fl ? 0.04 + t * 0.92 : m; return [u0 + (u1 - u0) * tu, y0 + (y1 - y0) * ty]; });
        if (n < 2) mL += crvW(P); else mD += crvW(P); }
      hi += lineW([[u0, y1], [u0, y0], [u1, y0]]); lo += lineW([[u1, y0], [u1, y1], [u0, y1]]);
      if (CURL[key] != null) curls.push([u0, y0, u1, y1, CURL[key], col]);
      if (CRACK.includes(key)) { const P = walk(R, u0 + (u1 - u0) * (0.2 + R() * 0.6), y0, (R() - 0.5) * 0.006, (y1 - y0) / 5, 5, 0.012); P[P.length - 1][1] = y1;
        cr += `<path d="${lineW(P)}" stroke="#fff0b8" stroke-width="0.2" fill="none" stroke-linejoin="round" opacity="0.8" transform="translate(0.18 0.12)"/><path d="${lineW(P)}" stroke="#4a3412" stroke-width="0.3" fill="none" stroke-linejoin="round"/>`;
        if (R() < 0.6) { const q = P[2]; cr += `<path d="${chip(R, q[0], q[1], 0.45, 5)}" fill="#2c2214"/>`; }
        const q = P[3]; cr += `<path d="${lineW(walk(R, q[0], q[1], (R() < 0.5 ? -1 : 1) * 0.008, 0.012, 2, 0.008))}" stroke="#4a3412" stroke-width="0.18" fill="none"/>`; } }
    s += `<path d="${mL}" stroke="#fbe49a" stroke-width="0.5" fill="none" opacity="0.55" stroke-linecap="round"/><path d="${mD}" stroke="#b88a28" stroke-width="0.22" fill="none" opacity="0.5" stroke-linecap="round"/>`;
    s += rep(420, () => { const u = R(), y = R(), p = W(u, y); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1((0.08 + R() * 0.14) * K(y))}" fill="${R() < 0.6 ? '#a9822c' : '#fff3c4'}" opacity="0.7"/>`; }).join('');
    s += fblot('ylino', 26, ['#f6dc80', '#b8902e', '#e0bb52'], 0.35, 6);
    // dirt packed into the seams, worst toward the walls
    s += `<path d="${hi}" stroke="#fff0b0" stroke-width="0.26" fill="none" opacity="0.75"/><path d="${lo}" stroke="#5e4518" stroke-width="0.34" fill="none" opacity="0.75"/>` + cr;
    s += `<path d="${TR}" fill="none" stroke="#6e4e14" stroke-width="8" opacity="0.28" filter="url(#fb3)"/>`;
    // grease + splatter in front of the stove (back left), a scorched pot ring
    s += '<g filter="url(#fb2)">' + rep(7, () => dot(0.08 + R() * 0.28, 0.03 + R() * 0.22, 2 + R() * 3, `fill="#8a5414" opacity="${f1(0.14 + R() * 0.12)}"`)).join('') + '</g>';
    s += rep(26, () => dot(0.06 + R() * 0.34, 0.02 + R() * 0.3, 0.15 + R() * 0.35, `fill="#6e3e0c" opacity="${f1(0.3 + R() * 0.3)}"`)).join('');
    s += dot(0.3, 0.2, 2.3, 'fill="none" stroke="#5a3410" stroke-width="0.35" opacity="0.45"') + dot(0.3, 0.2, 2.0, 'fill="none" stroke="#5a3410" stroke-width="0.18" opacity="0.3"');
    // worn traffic path (wax gone, dull) from the front to the sink + heel marks
    const path = crvW([[0.46, 1.08], [0.5, 0.75], [0.56, 0.45], [0.6, 0.15], [0.6, -0.05]]);
    s += `<g filter="url(#fb3)"><path d="${path}" stroke="#8a6a22" stroke-width="15" fill="none" opacity="0.14"/><path d="${path}" stroke="#fff4c8" stroke-width="8" fill="none" opacity="0.32"/></g>` + heel(R, 18, 0.35, 0.68);
    // missing tile: black tar adhesive combed by a notched trowel, yellow fragments still stuck at the edges
    if (miss) { const [u0, y0, u1, y1] = miss; let tw = ''; for (let n = 0; n < 7; n++) { const yy = y0 + (y1 - y0) * (n + 0.5) / 7; tw += crvW(rep(6, q => [u0 + (u1 - u0) * q / 5, yy + 0.006 * Math.sin(q * 1.3 + n)])); }
      ov += `<path d="${quadW(u0 - gu, y0 - gy, u1 + gu, y1 + gy)}" fill="#241b10"/><path d="${tw}" stroke="#4a3a22" stroke-width="0.4" fill="none"/><path d="${tw}" stroke="#6a5634" stroke-width="0.12" fill="none" transform="translate(0 -0.2)"/>`;
      ov += rep(6, () => { const e = R(), side = (R() * 4) | 0, u = side === 0 ? u0 + 0.004 : side === 1 ? u1 - 0.004 : u0 + (u1 - u0) * e, y = side === 2 ? y0 + 0.006 : side === 3 ? y1 - 0.006 : y0 + (y1 - y0) * e;
        return `<path d="${chip(R, u, y, 0.6 + R() * 0.5, 6)}" fill="${T[(R() * 6) | 0]}" stroke="#fff0b8" stroke-width="0.12"/>`; }).join('');
      ov += rep(10, () => dot(u0 + (u1 - u0) * R(), y0 + (y1 - y0) * R(), 0.12 + R() * 0.16, `fill="${R() < 0.5 ? '#9a8a6a' : '#e8c460'}"`)).join('');
      ov += `<path d="${lineW([[u0 - gu, y1 + gy], [u0 - gu, y0 - gy], [u1 + gu, y0 - gy]])}" stroke="#000000" stroke-width="0.5" fill="none" opacity="0.4"/>`; }
    // curled corners: the tip lifts off the glue, shows its brown edge + grey felt backing, casts a soft shadow, tar shows underneath
    curls.forEach(([u0, y0, u1, y1, c, col]) => { const cu = (u1 - u0) * 0.55, cy = (y1 - y0) * 0.55, sx = c === 1 || c === 2 ? -1 : 1, sy = c >= 2 ? -1 : 1, tu = sx < 0 ? u1 : u0, ty = sy < 0 ? y1 : y0;
      const A = [tu + sx * cu, ty], B = [tu, ty + sy * cy], Pa = W(...A), Pb = W(...B), Pt = W(tu, ty), k = K(ty), T2 = [Pt[0] + sx * 0.9 * k, Pt[1] - 3.4 * k];
      const lerp = (p, q, t) => [p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t];
      ov += `<path d="${polyW([A, [tu, ty], B])}" fill="#2a2012"/>` + [0.3, 0.55, 0.8].map(t => `<path d="M${pt(lerp(Pa, Pt, t))}L${pt(lerp(Pb, Pt, t))}" stroke="#4e3c20" stroke-width="0.22"/>`).join('');
      ov += `<path d="M${pt(Pa)}L${f1(Pt[0] + sx * 0.4 * k)} ${f1(Pt[1] + 0.4 * k)}L${pt(Pb)}Z" fill="#000000" opacity="0.4" filter="url(#fb1)"/>`;
      const c1 = lerp(Pa, T2, 0.5), c2 = lerp(Pb, T2, 0.5), fl = `M${pt(Pa)}Q${f1(c1[0])} ${f1(c1[1] + 0.5 * k)} ${pt(T2)}Q${f1(c2[0])} ${f1(c2[1] + 0.5 * k)} ${pt(Pb)}Z`;
      ov += `<path d="${fl}" fill="#8a6a2a" transform="translate(0 0.35)"/><path d="${fl}" fill="${shade(col, 1.07)}"/>`;
      const t1 = lerp(T2, c1, 0.35), t2 = lerp(T2, c2, 0.35);
      ov += `<path d="M${pt(T2)}L${pt(t1)}Q${f1((t1[0] + t2[0]) / 2)} ${f1((t1[1] + t2[1]) / 2 - 0.5 * k)} ${pt(t2)}Z" fill="#8c867a"/><path d="M${pt(Pa)}Q${f1(c1[0])} ${f1(c1[1] + 0.5 * k)} ${pt(T2)}" stroke="#fff4c8" stroke-width="0.2" fill="none" opacity="0.8"/>`; });
    return FL(s + ov); }

  // KIT-025 black-and-white retro diner vinyl: glossy checkerboard with chip-speckled VCT, a cherry-red border + chrome edge strip, wax shine, scuffs
  function fDiner() { const R = rng('diner27'), NU = 12, NV = 8, bu = 0.032, by = 0.05, ua = bu + 0.008, ub = 1 - bu - 0.008, ya = by + 0.012, WT = ['#f4f1e9', '#efebe1', '#f7f5ef', '#ebe6db'], BK = ['#1d1d21', '#232328', '#18181b', '#28282d'];
    const cu = (ub - ua) / NU, cy = (1.03 - ya) / NV; let wh = '', bk = '', sw = '', sb = '', hi = '', lo = '', sc = '';
    let s = `<defs><clipPath id="d27f"><path d="${quadW(ua, ya, ub, 1.06)}"/></clipPath></defs><rect width="80" height="56" fill="#9a958c"/>`;
    for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const u0 = ua + i * cu + 0.0015, u1 = ua + (i + 1) * cu - 0.0015, y0 = ya + j * cy + 0.0022, y1 = ya + (j + 1) * cy - 0.0022, w = (i + j) % 2 === 0;
      s += `<path d="${quadW(u0, y0, u1, y1)}" fill="${w ? shade(WT[(R() * 4) | 0], 0.98 + R() * 0.03) : BK[(R() * 4) | 0]}"/>`;
      for (let n = 0; n < (w ? 14 : 8); n++) { const u = u0 + (u1 - u0) * (0.06 + R() * 0.88), y = y0 + (y1 - y0) * (0.06 + R() * 0.88), d = dotD(u, y, 0.08 + R() * 0.12); if (w) { if (R() < 0.7) wh += d; else bk += d; } else { if (R() < 0.7) sw += d; else sb += d; } }
      hi += lineW([[u0, y1], [u0, y0], [u1, y0]]); lo += lineW([[u1, y0], [u1, y1], [u0, y1]]);
      if (!w && R() < 0.35) { const u = u0 + (u1 - u0) * (0.2 + R() * 0.5), y = y0 + (y1 - y0) * (0.2 + R() * 0.6), p = W(u, y), k = K(y), l = (1 + R() * 1.6) * k; sc += `<path d="M${pt(p)}q${f1(l * 0.5)} ${f1(-0.5 * k)} ${f1(l)} ${f1((R() - 0.5) * k)}" stroke="#8a8a90" stroke-width="${f1(0.12 * k)}" fill="none" opacity="0.5"/>`; } }
    s += `<g clip-path="url(#d27f)"><path d="${wh}" fill="#c9c2b2"/><path d="${bk}" fill="#8f897c"/><path d="${sw}" fill="#3e3e45"/><path d="${sb}" fill="#55555c"/>`
      + `<path d="${hi}" stroke="#ffffff" stroke-width="0.22" fill="none" opacity="0.45"/><path d="${lo}" stroke="#000000" stroke-width="0.22" fill="none" opacity="0.35"/>${sc}</g>`;
    // cherry-red border band + polished chrome trim strip
    const RD1 = '#c42d36', band = [[[0, -0.03], [1, -0.03], [1 - bu, by], [bu, by]], [[0, -0.03], [bu, by], [bu, 1.06], [0, 1.06]], [[1, -0.03], [1, 1.06], [1 - bu, 1.06], [1 - bu, by]]];
    s += band.map(P => `<path d="${polyW(P)}" fill="${RD1}"/>`).join('') + rep(140, () => { const side = (R() * 3) | 0, y = side ? R() * 1.05 : -0.02 + R() * (by + 0.01), u = side === 1 ? R() * bu : side === 2 ? 1 - R() * bu : R(); return `<circle cx="${f1(W(u, y)[0])}" cy="${f1(W(u, y)[1])}" r="${f1(0.1 * K(y))}" fill="#e86a70" opacity="0.6"/>`; }).join('');
    const trim = lineW([[ua - 0.004, 1.06], [ua - 0.004, ya - 0.006], [ub + 0.004, ya - 0.006], [ub + 0.004, 1.06]]);
    s += `<path d="${trim}" stroke="#55585e" stroke-width="0.95" fill="none" stroke-linejoin="miter"/><path d="${trim}" stroke="#d7dbe0" stroke-width="0.6" fill="none"/><path d="${trim}" stroke="#ffffff" stroke-width="0.18" fill="none" transform="translate(-0.1 -0.12)"/>`;
    s += `<path d="${lineW([[0, -0.03], [bu, by]])}M${pt(W(1, -0.03))}L${pt(W(1 - bu, by))}" stroke="#8a1c24" stroke-width="0.2"/>`;
    // traffic scuffs on the white squares, dull spots where the wax wore off, a big glossy shine
    s += heel(R, 22, 0.25, 0.75) + fblot('diner', 10, ['#ffffff', '#cfcac0'], 0.12, 9) + refl(0.36) + refl(0.12, '#ff9aa0');
    return FL(s); }

  // KIT-045 terracotta quarry tiles, warm grout: hand-made squares in fired orange to brick-brown, wavy edges + pillowed rims, kiln flashing,
  // pits and chalky bloom, sandy recessed grout lines, two cat paw prints pressed in before firing, a sealed satin sheen
  function fQuarry() { const R = rng('quarry27'), NU = 15, NV = 10, gu = 0.0055, gy = 0.0085, TC = ['#b85a34', '#c4663c', '#a94f2e', '#cf7448', '#b9603a', '#9e4a2c', '#c86d40', '#d27c52'];
    let s = `<defs><radialGradient id="q27f"><stop offset="0" stop-color="#5a2410" stop-opacity="0.38"/><stop offset="1" stop-color="#5a2410" stop-opacity="0"/></radialGradient><radialGradient id="q27l"><stop offset="0" stop-color="#ffc08a" stop-opacity="0.35"/><stop offset="1" stop-color="#ffc08a" stop-opacity="0"/></radialGradient></defs><rect width="80" height="56" fill="#d6bc94"/>`;
    s += rep(500, () => { const u = R(), y = R(), p = W(u, y); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.1 * K(y))}" fill="${R() < 0.5 ? '#b89a70' : '#efdcbc'}"/>`; }).join('');
    let tiles = '', fx = '', hi = '', lo = '', pits = ['', ''];
    for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const u0 = i / NU + gu, u1 = (i + 1) / NU - gu, y0 = j / NV + gy, y1 = (j + 1) / NV - gy, ju = gu * 0.45, jy = gy * 0.45, J = () => (R() - 0.5) * 2;
      const P = [[u0 + J() * ju, y0 + J() * jy], [(u0 + u1) / 2 + J() * ju, y0 + J() * jy * 0.7], [u1 + J() * ju, y0 + J() * jy], [u1 + J() * ju * 0.7, (y0 + y1) / 2 + J() * jy], [u1 + J() * ju, y1 + J() * jy], [(u0 + u1) / 2 + J() * ju, y1 + J() * jy * 0.7], [u0 + J() * ju, y1 + J() * jy], [u0 + J() * ju * 0.7, (y0 + y1) / 2 + J() * jy]];
      const col = shade(TC[(R() * TC.length) | 0], 0.93 + R() * 0.12);
      tiles += `<path d="${polyW(P)}" fill="${col}"/>`;
      hi += lineW([P[6], P[7], P[0], P[1], P[2]]); lo += lineW([P[2], P[3], P[4], P[5], P[6]]);
      const fu = u0 + (u1 - u0) * (R() < 0.5 ? 0.25 : 0.75), fy = y0 + (y1 - y0) * (R() < 0.5 ? 0.25 : 0.75), pf = W(fu, fy), k = K(fy);
      fx += `<ellipse cx="${f1(pf[0])}" cy="${f1(pf[1])}" rx="${f1(1.4 * k)}" ry="${f1(0.9 * k)}" fill="url(#q27f)"/>`;
      if (R() < 0.4) { const pl = W(u0 + (u1 - u0) * (0.3 + R() * 0.4), y0 + (y1 - y0) * (0.3 + R() * 0.4)); fx += `<ellipse cx="${f1(pl[0])}" cy="${f1(pl[1])}" rx="${f1(1.2 * k)}" ry="${f1(0.7 * k)}" fill="url(#q27l)"/>`; }
      for (let n = 0; n < 4; n++) pits[n % 2] += dotD(u0 + (u1 - u0) * (0.1 + R() * 0.8), y0 + (y1 - y0) * (0.1 + R() * 0.8), 0.07 + R() * 0.09); }
    s += tiles + fx + `<path d="${pits[0]}" fill="#5a2612" opacity="0.6"/><path d="${pits[1]}" fill="#f6dcc0" opacity="0.5"/>`;
    s += `<path d="${hi}" stroke="#f0a070" stroke-width="0.26" fill="none" opacity="0.6" stroke-linejoin="round"/><path d="${lo}" stroke="#6a2a12" stroke-width="0.32" fill="none" opacity="0.55" stroke-linejoin="round"/>`;
    s += '<g filter="url(#fb1)">' + rep(16, () => dot(R(), 0.1 + R() * 0.9, 0.5 + R() * 0.9, `fill="#f4e6d4" opacity="${f1(0.18 + R() * 0.15)}"`)).join('') + '</g>';
    // cat paw prints pressed into two tiles (a little trail)
    const paw = (u, y, a) => { const p = W(u, y), k = K(y) * 1.35, sq = 0.62; return `<g transform="translate(${pt(p)}) scale(${n4(k)} ${n4(k * sq)}) rotate(${a})" fill="#6a2810" opacity="0.78"><ellipse cx="0" cy="0.5" rx="0.9" ry="0.75"/><ellipse cx="-1" cy="-0.6" rx="0.32" ry="0.42"/><ellipse cx="-0.36" cy="-1.05" rx="0.32" ry="0.42"/><ellipse cx="0.36" cy="-1.05" rx="0.32" ry="0.42"/><ellipse cx="1" cy="-0.6" rx="0.32" ry="0.42"/></g>`; };
    s += paw(0.62, 0.55, 20) + paw(0.67, 0.42, 30) + paw(0.71, 0.29, 22);
    s += fblot('quarry', 18, ['#e08a5a', '#7a3418'], 0.16, 8) + refl(0.15, '#ffe2c8');
    return FL(s); }

  // KIT-065 wide-plank distressed French oak: smoky honey boards of random lengths, wire-brushed grain, cathedral figure, cracked knots,
  // hand-scraped scallops, dents + wormholes, filled checks, square oak pegs at the plank ends, dark open joints, a low oiled sheen
  function fOak() { const R = rng('oak27'), NP = 10, PC = ['#a88664', '#9c7a58', '#b39270', '#8f6e50', '#a5835f', '#b99a78', '#987454'];
    let s = '<rect width="80" height="56" fill="#2e1e12"/>', gr = '', br = '', cat = '', kn = '', ends = '', pegs = '', sc = '', dn = '', wh = '', ck = '';
    for (let i = 0; i < NP; i++) { const u0 = i / NP, u1 = (i + 1) / NP, cw = u1 - u0; let y = -R() * 0.6;
      while (y < 1.03) { const L = 0.45 + R() * 0.75, ya = Math.max(y, -0.02), yb = Math.min(y + L, 1.04), Q = rng('oakp' + i + '_' + f1(y));
        s += `<path d="${quadW(u0 + 0.0025, ya, u1 - 0.0025, yb)}" fill="${shade(PC[(Q() * PC.length) | 0], 0.94 + Q() * 0.1)}"/>`;
        rep(6, () => { const f = 0.08 + Q() * 0.84, a = 0.02 + Q() * 0.05, ph = Q() * 6, w = 1 + Q() * 2; gr += crvW(rep(8, j => { const t = j / 7; return [u0 + cw * Math.min(0.96, Math.max(0.04, f + a * Math.sin(t * w * 3 + ph))), ya + t * (yb - ya)]; })); });
        rep(10, () => { const f = 0.05 + Q() * 0.9, t0 = Q() * 0.8, l = 0.05 + Q() * 0.2; br += lineW([[u0 + cw * f, ya + (yb - ya) * t0], [u0 + cw * (f + (Q() - 0.5) * 0.02), ya + (yb - ya) * Math.min(1, t0 + l)]]); });
        if (Q() < 0.45) { const uc = u0 + cw * (0.3 + Q() * 0.4), yc = ya + (yb - ya) * (0.2 + Q() * 0.5); for (let n = 1; n <= 4; n++) { const w = cw * 0.09 * n, h = 0.035 * n; cat += crvW([[uc - w, yc + h], [uc - w * 0.55, yc + h * 0.3], [uc, yc], [uc + w * 0.55, yc + h * 0.3], [uc + w, yc + h]]); } }
        if (Q() < 0.4) { const ku = u0 + cw * (0.25 + Q() * 0.5), ky = ya + (yb - ya) * (0.2 + Q() * 0.6), r = 0.45 + Q() * 0.35;
          kn += dot(ku, ky, r * 1.6, 'fill="#6a4a30" opacity="0.45"') + dot(ku, ky, r, 'fill="#3e2616"') + dot(ku, ky, r * 0.55, 'fill="#26160c"') + dot(ku, ky, r * 1.25, 'fill="none" stroke="#4a3020" stroke-width="0.18" opacity="0.7"');
          rep(2, () => { ck += lineW(walk(Q, ku, ky, (Q() - 0.5) * 0.004, (Q() < 0.5 ? -1 : 1) * 0.014, 3, 0.004)); }); }
        if (Q() < 0.35) { const cu = u0 + cw * (0.2 + Q() * 0.6), cy0 = ya + (yb - ya) * Q() * 0.5; ck += lineW(walk(Q, cu, cy0, (Q() - 0.5) * 0.003, 0.025, 4, 0.003)); }
        for (let t = 0.12; t < 1; t += 0.14 + Q() * 0.08) { const yy = ya + (yb - ya) * t, h = 0.02 + Q() * 0.015; sc += `<path d="${quadW(u0 + 0.003, yy, u1 - 0.003, yy + h)}" fill="${Q() < 0.5 ? '#f4dcb8' : '#3a2414'}" opacity="0.08"/>`; }
        rep(3, () => { const p = W(u0 + cw * (0.15 + Q() * 0.7), ya + (yb - ya) * Q()), k = K(ya + (yb - ya) * 0.5); dn += `<path d="M${pt(p)}q${f1(0.4 * k)} ${f1(0.3 * k)} ${f1(0.8 * k)} 0" stroke="#3e2818" stroke-width="${f1(0.2 * k)}" fill="none" opacity="0.6"/>`; });
        if (Q() < 0.3) { const wu = u0 + cw * (0.2 + Q() * 0.6), wy = ya + (yb - ya) * Q(); rep(5, () => wh += dotD(wu + (Q() - 0.5) * 0.02, wy + (Q() - 0.5) * 0.04, 0.09)); }
        if (y > 0) { ends += lineW([[u0, y], [u1, y]]); }
        [y, y + L].forEach(ye => { if (ye > 0 && ye < 1.02) [0.3, 0.7].forEach(f => { const ey = ye + (ye === y ? 0.018 : -0.018); pegs += polyW([[u0 + cw * f - 0.004, ey - 0.006], [u0 + cw * f + 0.004, ey - 0.006], [u0 + cw * f + 0.004, ey + 0.006], [u0 + cw * f - 0.004, ey + 0.006]]); }); });
        y += L; } }
    s += sc + `<path d="${gr}" stroke="#5a3c24" stroke-width="0.17" fill="none" opacity="0.3"/><path d="${br}" stroke="#e2cfae" stroke-width="0.1" fill="none" opacity="0.35"/><path d="${cat}" stroke="#5a3c24" stroke-width="0.2" fill="none" opacity="0.32"/>`;
    s += kn + `<path d="${ck}" stroke="#2a1a0e" stroke-width="0.24" fill="none" stroke-linejoin="round"/><path d="${ck}" stroke="#c9a878" stroke-width="0.1" fill="none" transform="translate(0.15 0.1)" opacity="0.6"/>` + dn + `<path d="${wh}" fill="#24140a"/>`;
    s += `<path d="${pegs}" fill="#5a3a22" stroke="#2e1c10" stroke-width="0.15"/>`;
    s += fblot('oak', 20, ['#c8b8a0', '#6e5440', '#b89a74'], 0.22, 8);
    s += `<path d="${ends}" stroke="#2a1a0e" stroke-width="0.32" opacity="0.9"/><path d="${ends}" stroke="#e8cfa6" stroke-width="0.12" opacity="0.35" transform="translate(0 0.22)"/>`;
    s += `<path d="${rep(NP - 1, i => lineW([[(i + 1) / NP, -0.02], [(i + 1) / NP, 1.04]])).join('')}" stroke="#e8cfa6" stroke-width="0.14" opacity="0.3" transform="translate(0.26 0)"/>`;
    s += refl(0.1, '#fff0d8');
    return FL(s); }

  // KIT-085 anti-fatigue heated cushion-stone + self-sweeping vacuum plinth (luxury): large book-matched cream Calacatta slabs with pillowed
  // bevel edges, soft grey + gold veins flowing across the joints, polished brass seams that glow warm from the heating, brass keystone inlays
  // with a glint, a mirror shine; a step dimple springs back with a champagne ripple; gold dust motes drift into a bronze + brass vacuum plinth
  function fCush() { const R = rng('cush27b'), NU = 4, NV = 3, y00 = 0.05, gu = 0.0045, gy = 0.008, ru = 0.012, ry = 0.022;
    const yj = j => y00 + j * (1 - y00) / NV, SC = ['#f4eee4', '#f1eadf', '#f6f1e8', '#efe7da'];
    let s = '<defs><radialGradient id="c27h" cx="50%" cy="62%" r="65%"><stop offset="0" stop-color="#ffb062" stop-opacity="0.2"/><stop offset="1" stop-color="#ffb062" stop-opacity="0"/></radialGradient>'
      + '<linearGradient id="c27b" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8a5f1e"/><stop offset="0.3" stop-color="#f2cf7a"/><stop offset="0.5" stop-color="#fff0b8"/><stop offset="0.7" stop-color="#d9a84a"/><stop offset="1" stop-color="#8a5f1e"/></linearGradient>'
      + '<linearGradient id="c27g" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="30" y2="0"><stop offset="0" stop-color="#fff4c8" stop-opacity="0"/><stop offset="0.5" stop-color="#fff4c8" stop-opacity="0.95"/><stop offset="1" stop-color="#fff4c8" stop-opacity="0"/>'
      + '<animateTransform attributeName="gradientTransform" type="translate" values="-40 0;-40 0;110 0" keyTimes="0;0.45;1" dur="9s" repeatCount="indefinite"/></linearGradient></defs><rect width="80" height="56" fill="#a87a32"/>';
    // brass bed under the seams + warm heat glow breathing through them
    let gl = ''; for (let i = 0; i <= NU; i++) gl += lineW([[i / NU, y00], [i / NU, 1.05]]); for (let j = 0; j <= NV; j++) gl += lineW([[-0.02, yj(j)], [1.02, yj(j)]]);
    s += `<path d="${gl}" stroke="url(#c27b)" stroke-width="0.9" fill="none"/><path d="${gl}" stroke="#ffb45a" stroke-width="2.6" fill="none" opacity="0.18" filter="url(#fb2)">${an('opacity', '0.08;0.3;0.08', 7, 0, SPL(2))}</path>`;
    // slabs: dark bevel lip, pillowed face, soft top-left highlight
    let pads = '', clip = '';
    for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const u0 = i / NU + gu, u1 = (i + 1) / NU - gu, y0 = yj(j) + gy, y1 = yj(j + 1) - gy, du = u1 - u0, dy = y1 - y0, col = shade(SC[(i + j * 2) % 4], 0.99 + R() * 0.02);
      pads += `<path d="${rrW(u0, y0, u1, y1, ru, ry)}" fill="${shade(col, 0.8)}"/><path d="${rrW(u0, y0, u1 - du * 0.012, y1 - dy * 0.03, ru, ry)}" fill="${shade(col, 0.92)}"/>`
        + `<path d="${rrW(u0 + du * 0.016, y0 + dy * 0.025, u1 - du * 0.02, y1 - dy * 0.055, ru, ry)}" fill="${col}"/>`;
      clip += rrW(u0 + du * 0.016, y0 + dy * 0.025, u1 - du * 0.02, y1 - dy * 0.055, ru, ry); }
    s += `<defs><clipPath id="c27c"><path d="${clip}"/></clipPath></defs>` + pads;
    // veins: flowing book-matched (mirrored about the middle), soft grey clouds + crisp grey/gold threads, crossing the seams like one stone
    const vein = (c, ph, ph2, amp, side) => rep(13, q => { const y = -0.05 + q * 0.095, x = c + amp * Math.sin(y * 3.2 + ph) + 0.03 * Math.sin(y * 9 + ph2) + 0.12 * y; return [side ? 1 - x : x, y]; });
    let cloud = '', grey = '', gold = '', fine = '';
    rep(4, k => { const c = 0.06 + k * 0.11 + R() * 0.04, ph = R() * 6, ph2 = R() * 6, amp = 0.04 + R() * 0.05;
      [0, 1].forEach(sd => { const d = crvW(vein(c, ph, ph2, amp, sd)); cloud += d; if (k % 2 === 0) gold += d; else grey += d;
        rep(2, () => { const P = vein(c + (R() - 0.5) * 0.05, ph + 0.4, ph2 + 1, amp * 0.6, sd), st = 2 + ((R() * 6) | 0); fine += crvW(P.slice(st, st + 4)); }); }); });
    s += `<g clip-path="url(#c27c)"><g filter="url(#fb2)"><path d="${cloud}" stroke="#b9b2a8" stroke-width="2.2" fill="none" opacity="0.35"/></g><path d="${grey}" stroke="#8e877e" stroke-width="0.32" fill="none" opacity="0.75"/>`
      + `<path d="${gold}" stroke="#b8893a" stroke-width="0.5" fill="none" opacity="0.5" filter="url(#fb1)"/><path d="${gold}" stroke="#c99a44" stroke-width="0.22" fill="none"/><path d="${fine}" stroke="#9a938a" stroke-width="0.13" fill="none" opacity="0.6"/>`
      + fblot('cush27', 16, ['#ffffff', '#e8dfd0'], 0.35, 9) + '</g>';
    // pillow highlight + top-left rim light on every slab
    for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const u0 = i / NU + gu, u1 = (i + 1) / NU - gu, y0 = yj(j) + gy, y1 = yj(j + 1) - gy, du = u1 - u0, dy = y1 - y0;
      s += `<path d="${rrW(u0 + du * 0.1, y0 + dy * 0.1, u1 - du * 0.2, y1 - dy * 0.32, ru * 3, ry * 3)}" fill="#ffffff" opacity="0.22" filter="url(#fb2)"/>`
        + `<path d="${lineW([[u0 + du * 0.018, y1 - dy * 0.15], [u0 + du * 0.018, y0 + dy * 0.06], [u0 + du * 0.05, y0 + dy * 0.028], [u1 - du * 0.06, y0 + dy * 0.028]])}" stroke="#ffffff" stroke-width="0.32" fill="none" opacity="0.8" stroke-linecap="round"/>`; }
    // brass seam caps (polished) + keystone diamonds at the crossings with a glint
    s += `<path d="${gl}" stroke="#fff3c8" stroke-width="0.14" fill="none" opacity="0.8" transform="translate(-0.08 -0.1)"/><path d="${gl}" stroke="url(#c27g)" stroke-width="0.6" fill="none"/>`;
    for (let j = 1; j < NV; j++) for (let i = 1; i < NU; i++) { const u = i / NU, y = yj(j), a = 0.016, b2 = 0.03, D = polyW([[u, y - b2], [u + a, y], [u, y + b2], [u - a, y]]), di = polyW([[u, y - b2 * 0.5], [u + a * 0.5, y], [u, y + b2 * 0.5], [u - a * 0.5, y]]), p = W(u, y), k = K(y);
      s += `<path d="${D}" fill="#000000" opacity="0.25" transform="translate(0.25 0.3)" filter="url(#fb1)"/><path d="${D}" fill="url(#c27b)" stroke="#7a5418" stroke-width="0.15"/><path d="${di}" fill="#f6efe2"/>`
        + `<path d="M${f1(p[0] - 1.6 * k)} ${f1(p[1])}H${f1(p[0] + 1.6 * k)}M${f1(p[0])} ${f1(p[1] - 0.9 * k)}V${f1(p[1] + 0.9 * k)}" stroke="#ffffff" stroke-width="0.2" stroke-linecap="round" opacity="0">${an('opacity', '0;0;0.95;0', 6, -(i + j) * 1.3, ' keyTimes="0;0.7;0.8;1"')}</path>`; }
    s += `<path d="${TR}" fill="url(#c27h)">${an('opacity', '0.35;1;0.35', 8, 0, SPL(2))}</path>`;
    // a step dimple springs back with a soft champagne ripple
    [[0.4, 0.66, 0], [0.72, 0.4, 3]].forEach(([u, y, b]) => { const p = W(u, y), k = K(y), KT = ' keyTimes="0;0.2;0.55;1"', A = (at, v) => `<animate attributeName="${at}" values="${v}"${KT} dur="6s" begin="${n4(-b)}s" repeatCount="indefinite"/>`;
      s += `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(2.2 * k)}" ry="${f1(1 * k)}" fill="#8a7a62" opacity="0" filter="url(#fb1)">${A('opacity', '0;0.22;0;0')}</ellipse>`
        + `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(0.6 * k)}" ry="${f1(0.28 * k)}" fill="none" stroke="#ffe2a8" stroke-width="0.28" opacity="0">${A('rx', `${f1(0.6 * k)};${f1(0.6 * k)};${f1(3.8 * k)};${f1(3.8 * k)}`)}${A('ry', `${f1(0.28 * k)};${f1(0.28 * k)};${f1(1.8 * k)};${f1(1.8 * k)}`)}${A('opacity', '0;0.8;0;0')}</ellipse>`; });
    // bronze plinth with a polished brass lip, fine brass louvres and a champagne light line that breathes
    s += `<path d="${quadW(-0.02, -0.03, 1.02, y00 - 0.006)}" fill="#2a1e14"/><path d="${rep(90, i => lineW([[i / 90 + 0.003, 0.006], [i / 90 + 0.003, y00 - 0.014]])).join('')}" stroke="#b8893a" stroke-width="0.14" opacity="0.7"/>`
      + `<path d="${lineW([[-0.02, 0.003], [1.02, 0.003]])}" stroke="#d9a84a" stroke-width="0.3"/><path d="${lineW([[-0.02, y00 - 0.006], [1.02, y00 - 0.006]])}" stroke="url(#c27b)" stroke-width="0.6"/>`;
    s += `<path d="${lineW([[0, y00 - 0.002], [1, y00 - 0.002]])}" stroke="#ffd99a" stroke-width="1.8" opacity="0.35" filter="url(#fb2)">${an('opacity', '0.2;0.5;0.2', 4, 0, SPL(2))}</path><path d="${lineW([[0, y00 - 0.002], [1, y00 - 0.002]])}" stroke="#fff1cf" stroke-width="0.2"/>`;
    // gold dust motes glide on the air current into the plinth
    rep(7, i => { const u = 0.08 + i * 0.14 + (R() - 0.5) * 0.04, d = crvW([[u, 0.95], [u + (0.5 - u) * 0.12, 0.6], [u + (0.5 - u) * 0.06, 0.3], [u, y00 + 0.008]]), dur = 5 + R() * 2, b = -R() * dur;
      rep(2, q => { const bb = b - q * dur / 2; s += `<circle r="0.26" fill="#ffe7a8"><animateMotion path="${d}" dur="${n4(dur)}s" begin="${n4(bb)}s" repeatCount="indefinite"/><animate attributeName="r" values="0.3;0.22;0.08" dur="${n4(dur)}s" begin="${n4(bb)}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.9;0.9;0" keyTimes="0;0.12;0.85;1" dur="${n4(dur)}s" begin="${n4(bb)}s" repeatCount="indefinite"/></circle>`; }); });
    s += refl(0.34, '#fffaf0');
    return FL(s); }

  // ======================= CEILINGS (r.c27) — same frame as the Living Room ceilings (plus21): RD.H14.mk + G.VY depth =======================
  const { band, mould, mkV } = RD.H21, CFRM = RD.H14.FRM, { at, P2 } = H;
  const cE = (G, u, t) => { const y = G.y(t); return { x: G.x(u, y), y, z: G.z(y), q: 0.28 + 0.22 * (1 - y / G.H) }; };
  const cHi = (G, y, m) => G.VY - (G.VY - y) * m; // m > 1 = above the ceiling plane (recess), m < 1 = hanging below
  const cD = (x, y, rx, ry) => `M${n4(x - rx)} ${n4(y)}a${n4(rx)} ${n4(ry)} 0 1 0 ${n4(2 * rx)} 0a${n4(rx)} ${n4(ry)} 0 1 0 ${n4(-2 * rx)} 0`;
  const cEl = (P, rx, ry, ex, dy) => `<ellipse cx="${f1(P.x)}" cy="${f1(P.y + (dy || 0))}" rx="${f1(rx)}" ry="${f1(ry)}" ${ex}/>`;
  const cShade = (G, a, b) => `<defs><linearGradient id="k27s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000000" stop-opacity="${a}"/><stop offset="0.7" stop-color="#000000" stop-opacity="0"/><stop offset="0.92" stop-color="#ffffff" stop-opacity="${b || 0.05}"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs><path d="${G.tr}" fill="url(#k27s)"/>`;
  const cDoc = (G, body) => `<defs><clipPath id="k27c"><path d="${G.tr}"/></clipPath>${G.b(1)}${G.b(3)}${G.b(6)}</defs><g clip-path="url(#k27c)">${body}</g>`;
  const cBlots = (G, sd, n, cols, op, w) => { const R = rng(sd); return `<g filter="url(#cb6)" opacity="${op}">` + rep(n, i => { const t = 0.05 + R() * 0.92, y = G.y(t), z = G.z(y); return `<ellipse cx="${f1(G.x(R() * 1.1 - 0.05, y))}" cy="${f1(y)}" rx="${f1((w + R() * w) * z)}" ry="${f1((4 + R() * 5) * z)}" fill="${cols[i % cols.length]}"/>`; }).join('') + '</g>'; };
  const cStain = (G, u, t, rw, sd) => { const P = cE(G, u, t), Rr = rng(sd), pts = rep(22, i => { const a = i / 22 * 2 * PI, k = rw * P.z * (0.78 + Rr() * 0.4); return [P.x + Math.cos(a) * k, P.y + Math.sin(a) * k * P.q]; });
    const d = 'M' + pts.map(P2).join('L') + 'Z', d2 = 'M' + pts.map(([x, y]) => [P.x + (x - P.x) * 0.6, P.y + (y - P.y) * 0.6]).map(P2).join('L') + 'Z';
    return `<path d="${d}" fill="#cdb078" opacity="0.38"/><path d="${d}" fill="none" stroke="#9c7642" stroke-width="${f1(1.1 * P.z)}" opacity="0.55"/><path d="${d2}" fill="#c4a264" opacity="0.2"/><path d="${d2}" fill="none" stroke="#a8844e" stroke-width="${f1(0.7 * P.z)}" opacity="0.42"/>`; };
  const cWeb = (G, u, t, r, fl, col) => { const P = cE(G, u, t), z = P.z * r, A = rep(6, k => (k / 5) * PI / 2), sx = fl ? -1 : 1;
    let d = A.map(a => 'M' + f1(P.x) + ' ' + f1(P.y) + 'l' + f1(sx * Math.cos(a) * 9 * z) + ' ' + f1(-Math.sin(a) * 5 * z)).join('');
    [0.35, 0.65, 0.95].forEach(k => { d += 'M' + A.map(a => f1(P.x + sx * Math.cos(a) * 9 * z * k) + ' ' + f1(P.y - Math.sin(a) * 5 * z * k)).join('L'); });
    return `<path d="${d}" stroke="${col}" stroke-opacity="0.75" stroke-width="${f1(0.35 * G.s)}" fill="none"/>`; };

  // KIT-009 stained acoustic drop ceiling + greasy fan: fissured mineral-fibre tiles with pinholes in a yellowed T-bar grid, brown leak rings,
  // one waterlogged tile sagging at a corner, one tile missing (dark plenum, grey duct, pink insulation, a wire loop hanging out),
  // a grease-caked exhaust fan in the tile over the stove (blades spin behind the louvres, the grille rattles, a grease drip forms and falls)
  function cAcou(G) { const R = rng('acou27'), NU = 14, NT = 5, du = 1 / NU, dt = 1 / NT, TC = ['#e8e2cf', '#e3dcc6', '#ece7d7', '#ded6bf'];
    const gk = (u, t) => Math.max(0, 1 - Math.hypot((u - 0.18) / 0.26, (t - 0.72) / 0.45)), MI = [4, 2], SG = [9, 3], FN = [2, 3];
    let s = `<path d="${G.tr}" fill="#1c1813"/>`, fis = '', pin = '', eD = '', eL = '', ov = '';
    for (let j = 0; j < NT; j++) for (let i = 0; i < NU; i++) { const u0 = i * du, u1 = u0 + du, t0 = j * dt, t1 = t0 + dt, is = A => A[0] === i && A[1] === j;
      if (is(MI) || is(FN) || is(SG)) continue;
      s += `<path d="${G.quad(u0, t0, u1, t1)}" fill="${shade(TC[(R() * 4) | 0], 1 - 0.14 * gk(u0 + du / 2, t0 + dt / 2) - R() * 0.03)}"/>`;
      rep(11, () => { const P = cE(G, u0 + du * (0.06 + R() * 0.88), t0 + dt * (0.1 + R() * 0.8)), l = (1.4 + R() * 2.2) * P.z, a = R() * PI;
        fis += `M${f1(P.x)} ${f1(P.y)}q${f1(Math.cos(a) * l * 0.5 + (R() - 0.5) * P.z)} ${f1(Math.sin(a) * l * 0.5 * P.q)} ${f1(Math.cos(a) * l)} ${f1(Math.sin(a) * l * P.q)}`; });
      rep(16, () => { const P = cE(G, u0 + du * (0.05 + R() * 0.9), t0 + dt * (0.08 + R() * 0.84)); pin += cD(P.x, P.y, 0.22 * P.z, 0.22 * P.z * P.q); });
      eD += 'M' + G.P(u0, t0 + dt * 0.05) + 'L' + G.P(u1, t0 + dt * 0.05); eL += 'M' + G.P(u0, t1 - dt * 0.05) + 'L' + G.P(u1, t1 - dt * 0.05); }
    s += `<path d="${fis}" stroke="#a59a80" stroke-width="${f1(0.42 * G.s)}" fill="none" stroke-linecap="round" opacity="0.75"/><path d="${pin}" fill="#9d927a" opacity="0.7"/>`
      + `<path d="${eD}" stroke="#a89c80" stroke-width="${f1(0.7 * G.s)}" opacity="0.5"/><path d="${eL}" stroke="#fbf8ef" stroke-width="${f1(0.6 * G.s)}" opacity="0.6"/>`;
    s += cStain(G, 0.47, 0.58, 30, 'ks1') + cStain(G, 0.83, 0.3, 20, 'ks2') + cStain(G, 0.58, 0.2, 12, 'ks4');
    // grease film + speckles round the stove
    s += '<g filter="url(#cb6)">' + rep(8, () => { const P = cE(G, 0.04 + R() * 0.32, 0.5 + R() * 0.5); return cEl(P, (14 + R() * 20) * P.z, (3 + R() * 3) * P.z, `fill="#a07a34" opacity="${f1(0.12 + R() * 0.12)}"`); }).join('') + '</g>';
    s += rep(80, () => { const u = 0.02 + R() * 0.38, t = 0.42 + R() * 0.58, P = cE(G, u, t); return gk(u, t) > R() * 0.8 ? cEl(P, 0.3 * P.z, 0.3 * P.z * P.q, 'fill="#6e4c1a" opacity="0.6"') : ''; }).join('');
    // missing tile: plenum with a duct and insulation; the wire loop hangs below the grid (ov)
    { const u0 = MI[0] * du, t0 = MI[1] * dt, A = (f, g) => cE(G, u0 + du * f, t0 + dt * g);
      s += `<path d="${G.quad(u0 - 0.01, t0 + dt * 0.2, u0 + du + 0.01, t0 + dt * 0.46)}" fill="#5c5850"/><path d="M${G.P(u0, t0 + dt * 0.2)}L${G.P(u0 + du, t0 + dt * 0.2)}" stroke="#9a958a" stroke-width="${f1(0.6 * G.s)}"/>`
        + '<g filter="url(#cb1)">' + [[0.08, 0.75], [0.9, 0.8], [0.2, 0.95]].map(([f, g]) => { const P = A(f, g); return cEl(P, 4 * P.z, 1.4 * P.z, 'fill="#e6a49a" opacity="0.8"'); }).join('') + '</g>';
      const a = A(0.25, 0.55), b = A(0.7, 0.62), z = a.z, w = `M${f1(a.x)} ${f1(a.y)}C${f1(a.x + 5 * z)} ${f1(a.y + 13 * z)} ${f1(b.x - 4 * z)} ${f1(b.y + 15 * z)} ${f1(b.x)} ${f1(b.y)}`;
      ov += `<g>${at('rotate', `-4 ${f1(a.x)} ${f1(a.y)};5 ${f1(a.x)} ${f1(a.y)};-4 ${f1(a.x)} ${f1(a.y)}`, 6.5, 0, SPL(2))}<path d="${w}" stroke="#2e2a24" stroke-width="${f1(1.3 * z)}" fill="none"/><path d="${w}" stroke="#d9d2c0" stroke-width="${f1(0.8 * z)}" fill="none"/></g>`; }
    // greasy exhaust fan in the tile over the stove
    { const u0 = FN[0] * du, t0 = FN[1] * dt, ua = u0 + du * 0.13, ub = u0 + du * 0.87, ta = t0 + dt * 0.2, tb = t0 + dt * 0.8;
      const c = cE(G, u0 + du / 2, t0 + dt / 2), z = c.z, w = G.x(ub, c.y) - G.x(ua, c.y), h = G.y(tb) - G.y(ta), rb = w * 0.42, sy = h / w;
      const bl = `M0 0C${f1(-0.42 * rb)} ${f1(-0.25 * rb)} ${f1(-0.36 * rb)} ${f1(-0.95 * rb)} 0 ${f1(-rb)}C${f1(0.3 * rb)} ${f1(-0.92 * rb)} ${f1(0.22 * rb)} ${f1(-0.3 * rb)} 0 0Z`;
      const blades = rep(4, k => `<path d="${bl}" transform="rotate(${k * 90})" fill="#7e6c4c" stroke="#4a3c26" stroke-width="${f1(0.4 * z)}"/>`).join('');
      let L = ''; rep(5, k => { const t = ta + (tb - ta) * (k + 1) / 6; L += 'M' + G.P(ua, t) + 'L' + G.P(ub, t); });
      const box = `<path d="${G.quad(u0, t0, u0 + du, t0 + dt)}" fill="#d2c7a8" stroke="#8c7a52" stroke-width="${f1(0.5 * G.s)}"/><path d="${G.quad(u0 + du * 0.05, t0 + dt * 0.09, u0 + du * 0.95, t0 + dt * 0.91)}" fill="none" stroke="#f0e8d0" stroke-width="${f1(0.5 * G.s)}"/>`
        + `<defs><clipPath id="k27f"><path d="${G.quad(ua, ta, ub, tb)}"/></clipPath></defs><path d="${G.quad(ua, ta, ub, tb)}" fill="#1e1810"/>`
        + `<g clip-path="url(#k27f)"><g transform="translate(${f1(c.x)} ${f1(c.y)}) scale(1 ${n4(sy)})"><circle r="${f1(rb)}" fill="#8a7650" opacity="0.22"/><g>${at('rotate', '0;360', 0.9, 0, '')}${blades}</g><circle r="${f1(rb * 0.17)}" fill="#3a3024" stroke="#9a8660" stroke-width="${f1(0.5 * z)}"/></g></g>`
        + `<path d="${L}" stroke="#4a3a20" stroke-width="${f1(1.5 * z)}" transform="translate(0 ${f1(0.35 * z)})"/><path d="${L}" stroke="#c9bc98" stroke-width="${f1(1 * z)}"/><path d="${L}" stroke="#efe6cc" stroke-width="${f1(0.3 * z)}" transform="translate(0 ${f1(-0.3 * z)})"/>`
        + '<g filter="url(#cb1)">' + rep(7, () => { const P = cE(G, ua + (ub - ua) * R(), ta + (tb - ta) * R()); return cEl(P, (1.5 + R() * 2) * P.z, 0.6 * P.z, `fill="#6a4e1e" opacity="${f1(0.35 + R() * 0.3)}"`); }).join('') + '</g>';
      s += `<g>${at('translate', `0 0;0 0;${f1(0.45 * z)} 0;${f1(-0.4 * z)} 0;${f1(0.25 * z)} 0;0 0`, 3.4, 0, ' keyTimes="0;0.72;0.78;0.84;0.9;1"')}${box}</g>`;
      const dp = cE(G, u0 + du * 0.6, t0 + dt), y0 = dp.y, KT = ' keyTimes="0;0.7;0.86;0.87;1" dur="7s" repeatCount="indefinite"';
      ov += `<ellipse cx="${f1(dp.x)}" cy="${f1(y0)}" rx="${f1(0.55 * z)}" ry="${f1(0.4 * z)}" fill="#8a6420"><animate attributeName="ry" values="${f1(0.3 * z)};${f1(0.9 * z)};${f1(1.1 * z)};${f1(0.3 * z)};${f1(0.3 * z)}"${KT}/><animate attributeName="cy" values="${f1(y0)};${f1(y0 + 0.5 * z)};${f1(y0 + 9 * z)};${f1(y0)};${f1(y0)}"${KT}/><animate attributeName="opacity" values="0.9;0.95;0;0;0.9"${KT}/></ellipse>`; }
    // T-bar grid (yellowed), browner over the stove
    let gu = ''; for (let i = 0; i <= NU; i++) gu += 'M' + G.P(i * du, 0) + 'L' + G.P(i * du, 1);
    s += `<path d="${gu}" stroke="#7a6e56" stroke-width="${f1(1.6 * G.s)}" opacity="0.45" transform="translate(${f1(0.3 * G.s)} 0)"/><path d="${gu}" stroke="#e9e2cc" stroke-width="${f1(1.1 * G.s)}"/>`;
    for (let j = 1; j < NT; j++) { const y = G.y(j * dt), z = G.z(y), d = G.hl(y); s += `<path d="${d}" stroke="#7a6e56" stroke-width="${f1(1.5 * z)}" opacity="0.45" transform="translate(0 ${f1(0.45 * z)})"/><path d="${d}" stroke="#ece5d0" stroke-width="${f1(1.1 * z)}"/><path d="${d}" stroke="#fffbf0" stroke-width="${f1(0.3 * z)}" transform="translate(0 ${f1(-0.3 * z)})"/>`; }
    s += '<g filter="url(#cb6)">' + [[0.16, 0.75, 30], [0.3, 0.92, 22], [0.06, 0.55, 18]].map(([u, t, r]) => { const P = cE(G, u, t); return cEl(P, r * P.z, 5 * P.z, 'fill="#8a6424" opacity="0.16"'); }).join('') + '</g>';
    // waterlogged tile, front-right corner dropped out of the grid
    { const u0 = SG[0] * du, u1 = u0 + du, t0 = SG[1] * dt, t1 = t0 + dt, A = cE(G, u0, t0), B = cE(G, u1, t0), C2 = cE(G, u1, t1), D2 = cE(G, u0, t1), d = 4.5 * B.z, m = cE(G, u0 + du * 0.62, t0 + dt * 0.45);
      const poly = `M${f1(A.x)} ${f1(A.y)}L${f1(B.x)} ${f1(B.y + d)}L${f1(C2.x)} ${f1(C2.y)}L${f1(D2.x)} ${f1(D2.y)}Z`, ed = `M${f1(A.x)} ${f1(A.y)}L${f1(B.x)} ${f1(B.y + d)}`;
      ov += `<defs><radialGradient id="k27w" gradientUnits="userSpaceOnUse" cx="${f1(m.x)}" cy="${f1(m.y)}" r="${f1((B.x - A.x) * 0.6)}"><stop offset="0" stop-color="#b3935a"/><stop offset="0.6" stop-color="#cdb98e"/><stop offset="1" stop-color="#ddd2b6"/></radialGradient></defs>`
        + `<path d="${poly}" fill="#000000" opacity="0.25" filter="url(#cb1)" transform="translate(0 ${f1(0.8 * B.z)})"/><path d="${poly}" fill="url(#k27w)"/>`
        + `<path d="${ed}" stroke="#8a7a5c" stroke-width="${f1(0.4 * B.z)}" transform="translate(0 ${f1(0.7 * B.z)})"/><path d="${ed}" stroke="#f4eedf" stroke-width="${f1(1 * B.z)}"/>`
        + cStain(G, u0 + du * 0.55, t0 + dt * 0.55, 10, 'ks3')
        + `<path d="M${G.P(u0 + du * 0.3, t0 + dt * 0.25)}L${G.P(u0 + du * 0.42, t0 + dt * 0.5)}L${G.P(u0 + du * 0.38, t0 + dt * 0.7)}L${G.P(u0 + du * 0.5, t1 - dt * 0.05)}" stroke="#6e5a38" stroke-width="${f1(0.45 * G.s)}" fill="none"/>`; }
    ov += cWeb(G, 0.995, 1, 1.1, 1, '#d8cfb6') + cWeb(G, 0.008, 0.99, 0.9, 0, '#d8cfb6');
    { const P = cE(G, 0.93, 0.62), z = P.z, c = `${f1(P.x)} ${f1(P.y)}`; ov += `<g>${at('rotate', `-8 ${c};8 ${c};-8 ${c}`, 4.6, 0, SPL(2))}<path d="M${c}q${f1(0.6 * z)} ${f1(4 * z)} ${f1(-0.3 * z)} ${f1(8 * z)}" stroke="#7a6a4a" stroke-width="${f1(0.35 * z)}" fill="none" opacity="0.7"/><ellipse cx="${f1(P.x - 0.3 * z)}" cy="${f1(P.y + 8 * z)}" rx="${f1(0.8 * z)}" ry="${f1(0.6 * z)}" fill="#6a5a3e" opacity="0.7"/></g>`; }
    return s + ov + cShade(G, 0.32, 0.05) + mould(G, 2.4, ['#ddd5bd'], '#f8f3e4'); }

  // KIT-029 painted beadboard cottage ceiling (over the under-cabinet hood): buttercream tongue-and-groove boards running to the back wall,
  // joint grooves + rounded beads, staggered butt joints, nail heads, brush marks, paint drips, knots bleeding through the paint, a cove crown;
  // a bundle of drying herbs sways on a cup hook and steam from the hood curls along the boards
  function cBead(G) { const R = rng('bead27'), NB = 46, BC = ['#f4ecd6', '#f1e8d0', '#f6efdc', '#efe5cb'];
    let s = `<path d="${G.tr}" fill="#f2e9d2"/>`, gv = '', hl = '', cg = '', ch = '', jn = '', nl = '', bL = '', bD = '', dr = '';
    for (let i = 0; i < NB; i++) { const u0 = i / NB * 1.1 - 0.05, u1 = (i + 1) / NB * 1.1 - 0.05, cu = (u0 + u1) / 2, bw = u1 - u0;
      s += `<path d="${G.quad(u0, 0, u1, 1)}" fill="${shade(BC[(i * 3 + ((R() * 3) | 0)) % 4], 0.985 + R() * 0.03)}"/>`;
      gv += 'M' + G.P(u0, 0) + 'L' + G.P(u0, 1); hl += 'M' + G.P(u0 + bw * 0.12, 0) + 'L' + G.P(u0 + bw * 0.12, 1);
      cg += 'M' + G.P(cu, 0) + 'L' + G.P(cu, 1); ch += 'M' + G.P(cu + bw * 0.1, 0) + 'L' + G.P(cu + bw * 0.1, 1);
      if (i % 3 === 1) { const t = 0.15 + R() * 0.7; jn += 'M' + G.P(u0, t) + 'L' + G.P(u1, t); }
      if (i % 2 === 0) [0.2, 0.5, 0.82].forEach(t => { const P = cE(G, u0 + bw * 0.3, t); nl += cD(P.x, P.y, 0.32 * P.z, 0.32 * P.z * P.q); });
      rep(3, () => { const u = u0 + bw * (0.2 + R() * 0.6), t = R() * 0.9, d = 'M' + G.P(u, t) + 'L' + G.P(u + (R() - 0.5) * 0.002, t + 0.04 + R() * 0.12); if (R() < 0.5) bL += d; else bD += d; });
      if (R() < 0.14) { const P = cE(G, u0, 0.1 + R() * 0.8); dr += cEl(P, 0.6 * P.z, 1.1 * P.z * P.q, `fill="#f8f1de" stroke="#d6c8a6" stroke-width="${f1(0.2 * P.z)}"`); } }
    s += '<g filter="url(#cb1)">' + rep(6, () => { const P = cE(G, R(), 0.08 + R() * 0.85); return cEl(P, 1.6 * P.z, 0.9 * P.z, 'fill="#c9ae78" opacity="0.28"'); }).join('') + '</g>';
    s += `<path d="${bL}" stroke="#ffffff" stroke-width="${f1(0.5 * G.s)}" opacity="0.4"/><path d="${bD}" stroke="#d9cba8" stroke-width="${f1(0.5 * G.s)}" opacity="0.4"/>`
      + `<path d="${cg}" stroke="#cbb98f" stroke-width="${f1(0.55 * G.s)}"/><path d="${ch}" stroke="#fffaf0" stroke-width="${f1(0.45 * G.s)}" opacity="0.8"/>`
      + `<path d="${gv}" stroke="#b4a27a" stroke-width="${f1(1 * G.s)}"/><path d="${hl}" stroke="#fffaf0" stroke-width="${f1(0.7 * G.s)}"/><path d="${jn}" stroke="#b4a27a" stroke-width="${f1(0.6 * G.s)}"/>`
      + `<path d="${nl}" fill="#a8987a"/>${dr}`;
    // steam from the hood rolls along the boards toward the room
    rep(7, i => { const u = 0.26 + (i % 3) * 0.04, a = cE(G, u, 0.99), b = cE(G, u + (i % 2 ? 0.05 : -0.04), 0.48 + (i % 3) * 0.06), m = cE(G, u, 0.8), dur = 8, bg = n4(-i * dur / 7), KT = ` keyTimes="0;0.25;1" dur="${dur}s" begin="${bg}s" repeatCount="indefinite"`;
      const d = `M${f1(a.x)} ${f1(a.y)}Q${f1(m.x + (i % 2 ? 6 : -6) * m.z)} ${f1(m.y)} ${f1(b.x)} ${f1(b.y)}`;
      s += `<ellipse cx="0" cy="0" rx="${f1(5 * a.z)}" ry="${f1(1.6 * a.z)}" fill="#ffffff" filter="url(#cb3)" opacity="0"><animateMotion path="${d}" dur="${dur}s" begin="${bg}s" repeatCount="indefinite"/>`
        + `<animate attributeName="rx" values="${f1(4 * a.z)};${f1(9 * a.z)};${f1(18 * b.z)}"${KT}/><animate attributeName="ry" values="${f1(1.4 * a.z)};${f1(2.4 * a.z)};${f1(4.5 * b.z)}"${KT}/><animate attributeName="opacity" values="0;0.7;0"${KT}/></ellipse>`; });
    // drying herbs on a brass cup hook
    { const P = cE(G, 0.7, 0.36), z = P.z, hx = P.x, hy = P.y, ty = hy + 4.5 * z, Rr = rng('herb27'); let sp = '';
      rep(11, k => { const a = (k - 5) * 0.11 + (Rr() - 0.5) * 0.06, L = (7 + Rr() * 4) * z, ex = hx + Math.sin(a) * L, ey = ty + Math.cos(a) * L, col = ['#5e7a44', '#6d8a4e', '#7f9a58', '#56703e'][k % 4];
        sp += `<path d="M${f1(hx)} ${f1(ty)}Q${f1(hx + Math.sin(a) * L * 0.5 + (Rr() - 0.5) * z)} ${f1(ty + L * 0.5)} ${f1(ex)} ${f1(ey)}" stroke="${col}" stroke-width="${f1(0.45 * z)}" fill="none" stroke-linecap="round"/>`;
        rep(4, q => { const f = 0.3 + q * 0.17, x = hx + (ex - hx) * f, y = ty + (ey - ty) * f; sp += `<path d="M${f1(x)} ${f1(y)}l${f1((q % 2 ? 1 : -1) * 1.1 * z)} ${f1(0.7 * z)}" stroke="${col}" stroke-width="${f1(0.4 * z)}" stroke-linecap="round"/>`; });
        if (k % 3 === 0) sp += `<ellipse cx="${f1(ex)}" cy="${f1(ey)}" rx="${f1(0.45 * z)}" ry="${f1(1.1 * z)}" fill="#8e7bb0" transform="rotate(${f1(-a * 57)} ${f1(ex)} ${f1(ey)})"/>`; });
      s += `<ellipse cx="${f1(hx)}" cy="${f1(hy)}" rx="${f1(0.8 * z)}" ry="${f1(0.45 * z)}" fill="none" stroke="#b08a4a" stroke-width="${f1(0.35 * z)}"/><g>${at('rotate', `-3 ${f1(hx)} ${f1(hy)};3 ${f1(hx)} ${f1(hy)};-3 ${f1(hx)} ${f1(hy)}`, 5.2, 0, SPL(2))}`
        + `<path d="M${f1(hx)} ${f1(hy)}V${f1(ty)}" stroke="#b89466" stroke-width="${f1(0.35 * z)}"/>${sp}<path d="M${f1(hx - 1.1 * z)} ${f1(ty + 0.6 * z)}h${f1(2.2 * z)}" stroke="#c9a46a" stroke-width="${f1(0.9 * z)}" stroke-linecap="round"/></g>`; }
    return s + cShade(G, 0.24, 0.05) + mould(G, 3.4, ['#e6dcc0', '#f4ecd8', '#fffbf1'], '#ffffff'); }

  // KIT-049 smooth matte white ceiling with recessed pot lights: 8 cans (trim ring, grooved baffle, deep lens glowing warm, halo),
  // an in-ceiling speaker grille, a slot diffuser near the hood wall, sage bounce from the walls and a modern shadow-gap reveal
  function cPots(G) {
    let s = `<path d="${G.tr}" fill="#f4f3ef"/>` + cBlots(G, 'pot27b', 8, ['#ffffff', '#e7e5df'], 0.5, 90)
      + `<defs><linearGradient id="k27v" x1="0" y1="0" x2="0" y2="1"><stop offset="0.45" stop-color="#9caf8b" stop-opacity="0"/><stop offset="1" stop-color="#9caf8b" stop-opacity="0.2"/></linearGradient>`
      + '<radialGradient id="k27l"><stop offset="0" stop-color="#fffdf6"/><stop offset="0.55" stop-color="#fff3d2"/><stop offset="1" stop-color="#f2d9a0"/></radialGradient><radialGradient id="k27h"><stop offset="0" stop-color="#fff2d2" stop-opacity="0.6"/><stop offset="1" stop-color="#fff2d2" stop-opacity="0"/></radialGradient></defs>'
      + `<path d="${G.tr}" fill="url(#k27v)"/>`;
    const can = (u, t) => { const P = cE(G, u, t), z = P.z, r = 10 * z, ry = r * P.q, L = { x: P.x, y: cHi(G, P.y, 1.02), z, q: P.q };
      return cEl(P, r * 2.6, ry * 2.6, 'fill="url(#k27h)"') + cEl(P, r * 1.04, ry * 1.04, 'fill="#000000" opacity="0.12"', 0.5 * z)
        + cEl(P, r, ry, `fill="#fbfaf7" stroke="#cdc9c0" stroke-width="${f1(0.35 * G.s)}"`) + cEl(P, r * 0.8, ry * 0.8, 'fill="#d6d2c8"')
        + [0.74, 0.66, 0.58].map((k, i) => cEl({ x: P.x, y: P.y + (L.y - P.y) * (i + 1) / 4 }, r * k, ry * k, `fill="none" stroke="#bcb7ac" stroke-width="${f1(0.25 * G.s)}"`)).join('')
        + cEl(L, r * 0.6, ry * 0.6, 'fill="#fff6dc" opacity="0.7" filter="url(#cb1)"') + cEl(L, r * 0.44, ry * 0.44, 'fill="url(#k27l)"')
        + cEl({ x: L.x - r * 0.15, y: L.y - ry * 0.12 }, r * 0.14, ry * 0.1, 'fill="#ffffff"'); };
    [0.3, 0.7].forEach(t => [0.14, 0.38, 0.62, 0.86].forEach(u => s += can(u, t)));
    { const P = cE(G, 0.5, 0.5), z = P.z, r = 11 * z, ry = r * P.q; let h = '';
      for (let a = -1; a <= 1.001; a += 0.085) for (let b = -1; b <= 1.001; b += 0.11) if (a * a + b * b < 0.86) h += cD(P.x + a * r, P.y + b * ry, 0.18 * z, 0.18 * z * P.q);
      s += cEl(P, r * 1.06, ry * 1.06, 'fill="#000000" opacity="0.1"', 0.4 * z) + cEl(P, r, ry, `fill="#fbfaf7" stroke="#cfcbc2" stroke-width="${f1(0.35 * G.s)}"`) + `<path d="${h}" fill="#bfbab0"/>`; }
    s += `<path d="${G.quad(0.28, 0.885, 0.72, 0.915)}" fill="#2c2c2c" stroke="#e6e4de" stroke-width="${f1(0.5 * G.s)}"/><path d="M${G.P(0.285, 0.895)}L${G.P(0.715, 0.895)}M${G.P(0.285, 0.905)}L${G.P(0.715, 0.905)}" stroke="#f4f3ef" stroke-width="${f1(0.5 * G.s)}"/>`;
    return s + cShade(G, 0.22, 0.05) + mould(G, 1.4, ['#4a4946'], '#e9e7e1'); }

  // KIT-069 Venetian lime plaster + gold-leaf tray (luxury): hand-troweled warm plaster with burnished sweeps and sheen, a recessed tray
  // above the island lined with hand-laid gold leaf (crackle, overlapping sheets, a slow glint), lit by a warm hidden cove that breathes,
  // a polished brass fillet round the opening and a deep plaster crown with a brass line
  function cTray(G) { const R = rng('tray27'), u0 = 0.2, u1 = 0.8, t0 = 0.24, t1 = 0.8, mt = 1.07, O = G.quad(u0, t0, u1, t1);
    const hp = (u, t, m) => { const y = G.y(t); return [G.x(u, y), cHi(G, y, m)]; }, TS = rep(13, i => t0 + (t1 - t0) * i / 12), US = rep(25, i => u0 + (u1 - u0) * i / 24);
    let s = `<path d="${G.tr}" fill="#eee2cc"/>` + cBlots(G, 'tray27b', 10, ['#f8f0e2', '#dccbb0', '#f3e8d6'], 0.55, 60), sw = '', bn = '';
    rep(80, () => { const P = cE(G, R() * 1.1 - 0.05, 0.03 + R() * 0.95), rx = (8 + R() * 18) * P.z, a0 = R() * 2 * PI, a1 = a0 + 0.9 + R() * 1.3, d = 'M' + rep(9, k => { const a = a0 + (a1 - a0) * k / 8; return P2([P.x + Math.cos(a) * rx, P.y + Math.sin(a) * rx * P.q]); }).join('L');
      if (R() < 0.75) sw += `<path d="${d}" stroke="${R() < 0.5 ? '#fbf4e6' : '#d6c4a4'}" stroke-width="${f1((2 + R() * 3.5) * P.z)}" fill="none" stroke-linecap="round" opacity="0.3"/>`; else bn += d; });
    s += `<g filter="url(#cb3)">${sw}</g><path d="${bn}" stroke="#fffaf0" stroke-width="${f1(0.5 * G.s)}" fill="none" opacity="0.6" stroke-linecap="round"/>`
      + '<g filter="url(#cb6)">' + [[0.1, 0.3], [0.9, 0.55], [0.5, 0.93]].map(([u, t]) => { const P = cE(G, u, t); return cEl(P, 40 * P.z, 6 * P.z, 'fill="#ffffff" opacity="0.28"'); }).join('') + '</g>';
    // inside the tray: gold leaf on the raised plane, plaster walls, cove glow
    let v = `<defs><linearGradient id="k27g" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="${f1(G.W * 0.12)}" y2="0"><stop offset="0" stop-color="#fff6d0" stop-opacity="0"/><stop offset="0.5" stop-color="#fff6d0" stop-opacity="0.85"/><stop offset="1" stop-color="#fff6d0" stop-opacity="0"/>`
      + `<animateTransform attributeName="gradientTransform" type="translate" values="${f1(-G.W * 0.2)} 0;${f1(-G.W * 0.2)} 0;${f1(G.W * 1.1)} 0" keyTimes="0;0.5;1" dur="11s" repeatCount="indefinite"/></linearGradient></defs><rect x="0" y="0" width="${f1(G.W)}" height="${f1(G.H)}" fill="#c9a24e"/>`;
    const NL = 18, NM = 6, GC = ['#dcb862', '#e2bf68', '#d6b15a', '#e8c872', '#dfbb64'], su = (u1 - u0 + 0.04) / NL, st = (t1 - t0 + 0.02) / NM; let le = '', cr = '';
    for (let j = 0; j < NM; j++) for (let i = 0; i < NL; i++) { const a = u0 - 0.02 + su * i, b = a + su, c = t0 + st * j, d = c + st, J = () => (R() - 0.5) * 0.004;
      const Q = [hp(a + J(), c + J(), mt), hp(b + 0.003 + J(), c + J(), mt), hp(b + 0.003 + J(), d + 0.008, mt), hp(a + J(), d + 0.008, mt)];
      v += `<path d="M${Q.map(P2).join('L')}Z" fill="${shade(GC[(R() * GC.length) | 0], 0.98 + R() * 0.04)}"/>`; le += 'M' + P2(Q[3]) + 'L' + P2(Q[0]) + 'L' + P2(Q[1]);
      if (R() < 0.55) { const p1 = hp(a + su * R(), c + st * 0.1, mt), p2 = hp(a + su * R(), c + st * 0.5, mt), p3 = hp(a + su * R(), c + st * 0.9, mt); cr += `M${P2(p1)}L${P2(p2)}L${P2(p3)}`; } }
    v += `<path d="${le}" stroke="#fff0b0" stroke-width="${f1(0.35 * G.s)}" fill="none" opacity="0.7"/><path d="${cr}" stroke="#9a7428" stroke-width="${f1(0.25 * G.s)}" fill="none" opacity="0.6"/><rect x="0" y="0" width="${f1(G.W)}" height="${f1(G.H)}" fill="url(#k27g)"/>`;
    const side = (u, col) => `<path d="M${TS.map(t => P2(hp(u, t, 1))).join('L')}L${TS.slice().reverse().map(t => P2(hp(u, t, mt))).join('L')}Z" fill="${col}"/>`;
    v += side(u0, '#f4e9d6') + side(u1, '#e0d0b4') + `<path d="M${US.map(u => P2(hp(u, t1, 1))).join('L')}L${US.slice().reverse().map(u => P2(hp(u, t1, mt))).join('L')}Z" fill="#fbf1de"/>`;
    const rim = 'M' + TS.map(t => P2(hp(u0, t, mt))).join('L') + 'L' + US.map(u => P2(hp(u, t1, mt))).join('L') + 'L' + TS.slice().reverse().map(t => P2(hp(u1, t, mt))).join('L');
    v += `<path d="${rim}" stroke="#ffc874" stroke-width="${f1(7 * G.s)}" fill="none" filter="url(#cb3)" opacity="0.6">${an('opacity', '0.4;0.8;0.4', 7, 0, SPL(2))}</path><path d="${rim}" stroke="#fff2d0" stroke-width="${f1(0.6 * G.s)}" fill="none"/>`;
    s += `<path d="${O}" fill="none" stroke="#ffd9a0" stroke-width="${f1(12 * G.s)}" opacity="0.25" filter="url(#cb6)"/><defs><clipPath id="k27t"><path d="${O}"/></clipPath></defs><g clip-path="url(#k27t)">${v}</g>`;
    s += `<path d="${O}" fill="none" stroke="#fbf6ec" stroke-width="${f1(4 * G.s)}"/><path d="${O}" fill="none" stroke="#9e7424" stroke-width="${f1(2.2 * G.s)}"/><path d="${O}" fill="none" stroke="#e2b552" stroke-width="${f1(1.3 * G.s)}"/><path d="${O}" fill="none" stroke="#fff0b8" stroke-width="${f1(0.4 * G.s)}" transform="translate(0 ${f1(-0.4 * G.s)})"/>`;
    return s + cShade(G, 0.2, 0.05) + mould(G, 6, ['#dccdb2', '#f6eee0', '#d2c1a3', '#fbf5ea', '#e6d9c2'], '#ffffff', `<path d="${band(G, 6, 0, 1).lip}" stroke="#d4a548" stroke-width="${f1(0.5 * G.s)}" fill="none" transform="translate(0 ${f1(0.6 * G.s)})"/>`); }

  // KIT-089 backlit honey-onyx ceiling + whisper-vortex purifier (legendary, luxury): book-matched translucent onyx slabs with wavy banding,
  // glowing warm from behind (each slab breathes), polished brass seams; in the middle a brass-rimmed vortex intake whose brass vanes turn
  // slowly, gold motes spiralling into it, a champagne glow deep in the throat, ionizer sparkles, a light line in the shadow gap, a shine sweep
  function cOnyx(G) { const R = rng('onyx27'), NU = 4, NT = 3, du = 1 / NU, dt = 1 / NT, SL = ['#f6dfb2', '#f3d7a2', '#f8e5c0', '#f1d29c'];
    let s = '<defs><linearGradient id="k27b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8a5f1e"/><stop offset="0.35" stop-color="#f2cf7a"/><stop offset="0.5" stop-color="#fff0b8"/><stop offset="0.7" stop-color="#d9a84a"/><stop offset="1" stop-color="#7a5418"/></linearGradient>'
      + '<radialGradient id="k27o"><stop offset="0" stop-color="#fffaf0" stop-opacity="0.75"/><stop offset="0.5" stop-color="#ffe2a8" stop-opacity="0.3"/><stop offset="1" stop-color="#ffd080" stop-opacity="0"/></radialGradient>'
      + `<radialGradient id="k27n" cx="0.4" cy="0.35" r="0.7"><stop offset="0" stop-color="#fff6d8"/><stop offset="0.4" stop-color="#e8bc62"/><stop offset="1" stop-color="#8a5f1e"/></radialGradient></defs><path d="${G.tr}" fill="#e8c890"/>`;
    for (let j = 0; j < NT; j++) for (let i = 0; i < NU; i++) s += `<path d="${G.quad(i * du - (i ? 0 : 0.05), j * dt, (i + 1) * du + (i === NU - 1 ? 0.05 : 0), (j + 1) * dt)}" fill="${SL[(i + j * 2) % 4]}"/>`;
    s += cBlots(G, 'onx1', 12, ['#e2a556', '#fff4dc', '#d99a4c'], 0.45, 70);
    let bw = '', bands = '';
    rep(6, f => { const c = -0.05 + f * 0.22 + R() * 0.06, A = 0.05 + R() * 0.08, fr = 4 + R() * 5, ph = R() * 6, A2 = 0.02 + R() * 0.02;
      rep(7, k => { const off = k * (0.008 + R() * 0.012), col = ['#fff3da', '#d49a50', '#f8e4bc', '#bf8640', '#ffffff', '#e3b06a', '#fff8ea'][k], w = (0.3 + R() * 1.6) * G.s;
        const d = 'M' + rep(27, q => { const u = -0.05 + q * 0.0423, x = Math.abs(u - 0.5); return G.P(u, c + off + A * Math.sin(x * fr + ph) + A2 * Math.sin(x * 17 + ph * 2)); }).join('L');
        bands += `<path d="${d}" stroke="${col}" stroke-width="${f1(w)}" fill="none" opacity="${f1(0.45 + R() * 0.4)}" stroke-linejoin="round"/>`; if (k === 2) bw += d; }); });
    s += `<g filter="url(#cb1)"><path d="${bw}" stroke="#d08c3c" stroke-width="${f1(5 * G.s)}" fill="none" opacity="0.35"/></g>` + bands;
    s += rep(110, () => { const P = cE(G, R(), R()); return cEl(P, 0.3 * P.z, 0.3 * P.z * P.q, `fill="${R() < 0.6 ? '#fffaf0' : '#b77a34'}" opacity="0.55"`); }).join('');
    for (let j = 0; j < NT; j++) for (let i = 0; i < NU; i++) { const P = cE(G, (i + 0.5) * du, (j + 0.5) * dt), w = G.x((i + 1) * du, P.y) - G.x(i * du, P.y), h = G.y((j + 1) * dt) - G.y(j * dt);
      s += `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(w * 0.6)}" ry="${f1(h * 0.7)}" fill="url(#k27o)" opacity="0.6">${an('opacity', '0.45;0.85;0.45', 9, -(i * 2 + j * 3), SPL(2))}</ellipse>`; }
    s += `<rect x="${f1(-G.W * 0.4)}" y="0" width="${f1(G.W * 0.1)}" height="${f1(G.H)}" fill="#ffffff" opacity="0.14" transform="skewX(-25)">${at('translate', `0 0;0 0;${f1(G.W * 1.7)} 0`, 13, 0, ' keyTimes="0;0.6;1"')}</rect>`;
    let gl = ''; for (let i = 1; i < NU; i++) gl += 'M' + G.P(i * du, -0.02) + 'L' + G.P(i * du, 1.02); for (let j = 1; j < NT; j++) gl += G.hl(G.y(j * dt));
    s += `<path d="${gl}" stroke="#7a5418" stroke-width="${f1(1.5 * G.s)}" fill="none"/><path d="${gl}" stroke="url(#k27b)" stroke-width="${f1(1 * G.s)}" fill="none"/><path d="${gl}" stroke="#fff3c8" stroke-width="${f1(0.25 * G.s)}" fill="none" transform="translate(0 ${f1(-0.25 * G.s)})"/>`;
    // whisper vortex
    { const P = cE(G, 0.5, 0.42), z = P.z, q = P.q, R0 = 20 * z, cx = P.x, cy = P.y, D = m => ({ x: cx, y: cHi(G, cy, m) });
      let v = cEl(P, R0 * 1.2, R0 * 1.2 * q, 'fill="#000000" opacity="0.18" filter="url(#cb3)"', 0.8 * z) + cEl(P, R0 * 1.1, R0 * 1.1 * q, `fill="url(#k27b)" stroke="#6a4612" stroke-width="${f1(0.4 * z)}"`)
        + cEl(P, R0 * 0.96, R0 * 0.96 * q, 'fill="#3a2410"') + cEl(D(1.025), R0 * 0.8, R0 * 0.8 * q, 'fill="#24160a"') + cEl(D(1.05), R0 * 0.55, R0 * 0.55 * q, 'fill="#160d05"')
        + `<g>${an('opacity', '0.3;0.75;0.3', 5, 0, SPL(2))}${cEl(D(1.05), R0 * 0.5, R0 * 0.5 * q, 'fill="#ffd99a" filter="url(#cb3)"')}</g>`;
      const pp = (r, b) => f1(Math.cos(b) * r) + ' ' + f1(Math.sin(b) * r), vn = rep(20, k => { const a = k / 20 * 2 * PI; return `M${pp(R0 * 0.28, a)}Q${pp(R0 * 0.62, a + 0.32)} ${pp(R0 * 0.9, a + 0.75)}`; }).join(''), c1 = D(1.015);
      v += `<g transform="translate(${f1(c1.x)} ${f1(c1.y)}) scale(1 ${n4(q)})"><g>${at('rotate', '0;360', 18, 0, '')}<path d="${vn}" stroke="#6a4612" stroke-width="${f1(1.6 * z)}" fill="none" stroke-linecap="round"/><path d="${vn}" stroke="#d4a548" stroke-width="${f1(1.05 * z)}" fill="none" stroke-linecap="round"/><path d="${vn}" stroke="#fff0b8" stroke-width="${f1(0.3 * z)}" fill="none" stroke-linecap="round" transform="translate(${f1(-0.3 * z)} ${f1(-0.3 * z)})"/></g>`
        + `<circle r="${f1(R0 * 0.22)}" fill="url(#k27n)" stroke="#7a5418" stroke-width="${f1(0.3 * z)}"/><ellipse cx="${f1(-R0 * 0.07)}" cy="${f1(-R0 * 0.08)}" rx="${f1(R0 * 0.08)}" ry="${f1(R0 * 0.05)}" fill="#ffffff" opacity="0.8"/></g>`;
      const rr = R0 * 1.03; v += `<path d="M${f1(cx - rr)} ${f1(cy)}A${f1(rr)} ${f1(rr * q)} 0 0 1 ${f1(cx + rr * 0.3)} ${f1(cy - rr * q * 0.95)}" stroke="#fff6d0" stroke-width="${f1(0.5 * z)}" fill="none" stroke-linecap="round"/>`;
      rep(12, i => { const a0 = i / 12 * 2 * PI, d = 'M' + rep(16, k => { const f = k / 15, r = R0 * (3.2 - 2.9 * f), a = a0 + f * 2.2; return P2([cx + Math.cos(a) * r, cy + Math.sin(a) * r * q]); }).join('L'), dur = 6 + (i % 4), b = n4(-i * 0.7);
        v += `<circle r="${f1(0.45 * z)}" fill="#ffe7a8" opacity="0"><animateMotion path="${d}" dur="${dur}s" begin="${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.95;0.9;0" keyTimes="0;0.15;0.8;1" dur="${dur}s" begin="${b}s" repeatCount="indefinite"/></circle>`; });
      s += v; }
    s += rep(16, i => { const P = cE(G, 0.05 + R() * 0.9, 0.05 + R() * 0.9), z = P.z; return `<path d="M${f1(P.x - 1.4 * z)} ${f1(P.y)}H${f1(P.x + 1.4 * z)}M${f1(P.x)} ${f1(P.y - 0.9 * z)}V${f1(P.y + 0.9 * z)}" stroke="#fff8e0" stroke-width="${f1(0.25 * z)}" stroke-linecap="round" opacity="0">${an('opacity', '0;0;0.9;0', 5 + (i % 4), -i * 0.9, ' keyTimes="0;0.7;0.8;1"')}</path>`; }).join('');
    return s + cShade(G, 0.1, 0.04) + mould(G, 2.6, ['#2a1e14', '#7a5a2c', '#c99a44'], '#fff0c8', `<path d="${band(G, 2.6, 0, 1).lip}" stroke="#ffd99a" stroke-width="${f1(3 * G.s)}" fill="none" filter="url(#cb3)" opacity="0.5">${an('opacity', '0.3;0.65;0.3', 6, 0, SPL(2))}</path>`); }

  // card: the tier's Kitchen wall below the ceiling, with the hood that goes with it
  const CEIL27 = { acou: cAcou, bead: cBead, pots: cPots, tray: cTray, onyx: cOnyx }, CMEMO = {};
  const WALL27 = { acou: '#ddd0b0', bead: '#e9dec4', pots: '#a8b79b', tray: '#d6c3a3', onyx: '#ebe5da' };
  const CB27 = { acou: ['#e6dfca', '#e4dcc6'], bead: ['#f2e9d2', '#f4ecd8'], pots: ['#f4f3ef', '#4a4946'], tray: ['#eee2cc', '#f6eee0'], onyx: ['#f2d7a6', '#c99a44'] };
  const BRASS = '<stop offset="0" stop-color="#8a5f1e"/><stop offset="0.35" stop-color="#f2cf7a"/><stop offset="0.5" stop-color="#fff0b8"/><stop offset="0.7" stop-color="#d9a84a"/><stop offset="1" stop-color="#8a5f1e"/>';
  const HOOD27 = {
    acou: '<path d="M16 26H64V31H16Z" fill="#8a6a2a" opacity="0.14"/>',
    bead: '<rect x="27" y="26" width="26" height="9" fill="#f7f3ea" stroke="#c4b99f" stroke-width="0.3"/><path d="M40 26V35M28.2 27.2H38.8V33.8H28.2ZM41.2 27.2H51.8V33.8H41.2Z" stroke="#d2c8b0" stroke-width="0.25" fill="none"/><circle cx="38.2" cy="33" r="0.35" fill="#b08a4a"/><circle cx="41.8" cy="33" r="0.35" fill="#b08a4a"/>'
      + '<rect x="28" y="35" width="24" height="2.6" fill="#e6e6e2" stroke="#9a9a96" stroke-width="0.25"/><rect x="28" y="37" width="24" height="0.7" fill="#55585a"/><circle cx="49.5" cy="36" r="0.35" fill="#7a7e80"/><circle cx="48.3" cy="36" r="0.35" fill="#7a7e80"/><ellipse cx="40" cy="39.4" rx="9" ry="1.4" fill="#fff4d2" opacity="0.6"/>',
    pots: '<defs><linearGradient id="k27m" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#868c91"/><stop offset="0.35" stop-color="#e9edf0"/><stop offset="0.6" stop-color="#b9bfc4"/><stop offset="1" stop-color="#787e83"/></linearGradient></defs><rect x="36.4" y="26" width="7.2" height="11.5" fill="url(#k27m)" stroke="#6c7276" stroke-width="0.25"/>'
      + '<path d="M29.5 41.5L36.4 37.5H43.6L50.5 41.5Z" fill="url(#k27m)" stroke="#6c7276" stroke-width="0.25"/><rect x="29.5" y="41.5" width="21" height="1.1" fill="#5e6468"/><path d="M38 27V37M42 27V37" stroke="#ffffff" stroke-width="0.15" opacity="0.6"/><ellipse cx="40" cy="44" rx="9.5" ry="1.4" fill="#fff4d2" opacity="0.55"/>',
    tray: '<defs><linearGradient id="k27p" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#d6c6aa"/><stop offset="0.4" stop-color="#f6eddd"/><stop offset="1" stop-color="#c9b594"/></linearGradient><linearGradient id="k27q" x1="0" y1="0" x2="1" y2="0">' + BRASS + '</linearGradient></defs>'
      + '<path d="M34 26H46C46 32 49.5 36.5 53 40H27C30.5 36.5 34 32 34 26Z" fill="url(#k27p)" stroke="#b8a482" stroke-width="0.25"/><path d="M37 26C37 32 34.5 36.5 31.5 40M43 26C43 32 45.5 36.5 48.5 40" stroke="#c99a44" stroke-width="0.9" fill="none"/><path d="M36.8 26C36.8 32 34.3 36.5 31.3 40M42.8 26C42.8 32 45.3 36.5 48.3 40" stroke="#fff0b8" stroke-width="0.2" fill="none"/>'
      + '<rect x="26.4" y="40" width="27.2" height="2.4" rx="0.4" fill="url(#k27q)" stroke="#7a5418" stroke-width="0.2"/><path d="M27 40.5H53" stroke="#fff3c8" stroke-width="0.2"/><ellipse cx="40" cy="44.6" rx="11" ry="1.5" fill="#fff0c8" opacity="0.6"/>',
    onyx: '<defs><linearGradient id="k27x" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd99a" stop-opacity="0.5"/><stop offset="1" stop-color="#ffd99a" stop-opacity="0"/></linearGradient></defs><rect x="16" y="26" width="48" height="10" fill="url(#k27x)"/>',
  };
  const cardOf27 = k => { const G = mkV(CFRM.card), w = WALL27[k];
    return `<path d="M16 26H64V56H16Z" fill="${w}"/><path d="M0 0L16 26V56H0Z" fill="${shade(w, 0.88)}"/><path d="M80 0L64 26V56H80Z" fill="${shade(w, 0.8)}"/><path d="M16 26V56M64 26V56" stroke="#000000" stroke-opacity="0.2" stroke-width="0.6"/>`
      + cDoc(G, CEIL27[k](G)) + `<path d="${G.tr}" fill="none" stroke="#000000" stroke-opacity="0.25" stroke-width="0.5"/>` + HOOD27[k]; };

  // ======================= ISLAND LIGHTS (ceiling pieces, mount 'ceil', like the Living Room lights in plus21) =======================
  const N = RD.N, { cam } = H, { DEF11, zsort } = RD.H11;
  const lbox = (C, o) => H.box3(C, Object.assign({}, o, { mat: null, tpat: null, gl: o.gl ? Math.min(o.gl, 0.2) : 0, olw: 1, olo: 0.95, olc: shade(o.col, 0.32), edge: 0.5 }));
  const lcyl = (C, a, b, r, col, o) => H.cyl3(C, a, b, r, col, Object.assign({ olw: 0.8 }, o || {}, { mat: (o && o.mat) || 'plastic', pat: null, olo: 0.95 }));
  const lsph = (C, q, r, col, o) => { const c = C.P(q); return H.sph(C, q, r, col, o) + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * C.k)}" fill="none" stroke="${shade(col, 0.35)}" stroke-width="0.5"/>`; };
  const DEF27 = DEF11 + '<filter id="l27b1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.8"/></filter><filter id="l27b3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>'
    + '<radialGradient id="l27w"><stop offset="0" stop-color="#fff0c0" stop-opacity="0.85"/><stop offset="0.35" stop-color="#ffd27a" stop-opacity="0.35"/><stop offset="1" stop-color="#ffc060" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="l27c"><stop offset="0" stop-color="#f2fbff" stop-opacity="0.85"/><stop offset="0.35" stop-color="#d8efff" stop-opacity="0.3"/><stop offset="1" stop-color="#c4e4ff" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="l27a"><stop offset="0" stop-color="#fff6e2" stop-opacity="0.9"/><stop offset="0.4" stop-color="#ffdca6" stop-opacity="0.4"/><stop offset="1" stop-color="#ffc880" stop-opacity="0"/></radialGradient>'
    + '<radialGradient id="l27g"><stop offset="0" stop-color="#fff4d6" stop-opacity="0.8"/><stop offset="0.4" stop-color="#ffe0a4" stop-opacity="0.32"/><stop offset="1" stop-color="#ffd08a" stop-opacity="0"/></radialGradient>';
  const lglow = (C, q, r, op, A, g) => { const c = C.P(q); return `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * C.k)}" fill="url(#${g || 'l27w'})" opacity="${op}">${A || ''}</circle>`; };
  const lring = (C, y, r, a0, a1, n) => rep(n + 1, i => { const a = a0 + (a1 - a0) * i / n; return C.p(r * Math.sin(a), y, r * Math.cos(a)); });
  const lswing = (C, q, deg, T, b) => { const c = P2(C.P(q)); return `<animateTransform attributeName="transform" type="rotate" values="${-deg} ${c};${deg} ${c};${-deg} ${c}" dur="${n4(T)}s" begin="${n4(b || 0)}s" repeatCount="indefinite"${SPL(2)}/>`; };
  const lrot = (p, deg, T, b) => { const c = P2(p); return at('rotate', `${-deg} ${c};${deg} ${c};${-deg} ${c}`, n4(T), n4(b || 0), SPL(2)); };
  const FLK27 = (T, b) => an('opacity', '1;1;0.3;1;0.55;1;1', T, b, ' keyTimes="0;0.6;0.62;0.64;0.66;0.69;1"');
  const tube27 = (C, P, w, col, hi) => { const d = 'M' + P.map(P2).join('L'), k = C.k; return `<path d="${d}" stroke="${shade(col, 0.45)}" stroke-width="${f1(w * 1.35 * k)}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" stroke="${col}" stroke-width="${f1(w * k)}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" stroke="${hi || '#fff0b8'}" stroke-opacity="0.6" stroke-width="${f1(w * 0.3 * k)}" fill="none" stroke-linecap="round" transform="translate(0 ${f1(-w * 0.28 * k)})"/>`; };
  const front = (C, x, z) => x * C.v[0] + z * C.v[2] > 0;

  // KIT-017 bare fluorescent strip: grubby enamel channel hung on two jack chains, two T8 tubes (one end burnt black, a couple of dead bugs),
  // tombstone sockets, a grey cord looping up to the ceiling, a bead pull-chain that sways; the old tube stutters now and then
  N.fluor27 = S => { const T = 40, Y = 22, L = 28, D = { w: 64, d: 14, zs: 1.5, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx), k = C.k;
      let s = lglow(C, [0, Y - 6, 0], 48, 0.5, FLK27(7.3, 0), 'l27c');
      [-22, 22].forEach(x => { const a = C.p(x, T - 0.6, 0), b = C.p(x, Y + 3, 0), d = `M${P2(a)}L${P2(b)}`, da = `${f1(1.2 * k)} ${f1(0.5 * k)}`;
        s += lsph(C, [x, T - 0.6, 0], 0.7, '#8a867e') + `<path d="${d}" stroke="#4e4a44" stroke-width="${f1(1 * k)}" stroke-dasharray="${da}"/><path d="${d}" stroke="#c4beb2" stroke-width="${f1(0.45 * k)}" stroke-dasharray="${da}"/>`; });
      { const a = C.p(L - 2, Y + 3, -1.5), m = C.p(L + 7, Y + 2, -2), b = C.p(L + 3, T, -2); s += `<path d="M${P2(a)}Q${P2(m)} ${P2(b)}" stroke="#8a867c" stroke-width="${f1(0.75 * k)}" fill="none"/><path d="M${P2(a)}Q${P2(m)} ${P2(b)}" stroke="#d8d3c6" stroke-width="${f1(0.45 * k)}" fill="none"/>`; }
      s += lbox(C, { c: [0, Y, 0], w: 2 * L, h: 3, d: 5.4, col: '#e2dfd4', r: 0.6 });
      s += rep(14, i => { const p = C.p(-L + 3 + i * 4 + (i % 3), Y + 3, (i % 2 ? 1 : -1) * 1.2); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(1.4 * k)}" ry="${f1(0.5 * k)}" fill="#8a7a5a" opacity="0.3"/>`; }).join('');
      [-L + 0.8, L - 0.8].forEach(x => s += lbox(C, { c: [x, Y - 2.4, 0], w: 1.6, h: 2.4, d: 4.8, col: '#d6d2c4' }));
      [-1.25, 1.25].forEach((z, i) => { const a = [-L + 1.6, Y - 1.5, z], b = [L - 1.6, Y - 1.5, z], e = [L - 4.6, Y - 1.5, z];
        s += lcyl(C, a, b, 1.05, '#eef4f6', { olw: 0.3 }) + lcyl(C, a, [a[0] + 1.6, a[1], z], 1.1, '#9aa0a2', { olw: 0.3 }) + lcyl(C, [b[0] - 1.6, b[1], z], b, 1.1, '#9aa0a2', { olw: 0.3 });
        if (i) s += lcyl(C, e, [b[0] - 1.6, b[1], z], 1.07, '#5c544a', { ol: 0, op: 0.7 }) + lcyl(C, [a[0] + 1.6, a[1], z], [a[0] + 3, a[1], z], 1.07, '#8a8274', { ol: 0, op: 0.5 });
        const ln = `M${P2(C.P([a[0] + 2.4, a[1], z]))}L${P2(C.P([(i ? e[0] : b[0]) - 0.8, b[1], z]))}`;
        s += `<g>${i ? FLK27(4.1, -1) : ''}<path d="${ln}" stroke="#ffffff" stroke-width="${f1(1.5 * k)}" stroke-linecap="round" opacity="0.85" filter="url(#l27b1)"/><path d="${ln}" stroke="#ffffff" stroke-width="${f1(0.5 * k)}" stroke-linecap="round"/></g>`; });
      [[-9, -1.25], [14, 1.25]].forEach(([x, z]) => { const p = C.p(x, Y - 2.2, z); s += `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(0.5 * k)}" ry="${f1(0.3 * k)}" fill="#3a3026" opacity="0.7"/>`; });
      { const q = [5, Y - 0.2, 2.7], p = C.P(q), b = C.p(5, Y - 9, 2.7); s += `<g>${lrot(p, 6, 2.8, -0.4)}<path d="M${P2(p)}L${P2(b)}" stroke="#8e8a80" stroke-width="${f1(0.45 * k)}" stroke-dasharray="${f1(0.3 * k)} ${f1(0.25 * k)}" stroke-linecap="round"/>${lsph(C, [5, Y - 9.6, 2.7], 0.6, '#b8b2a6')}</g>`; }
      return { defs: DEF27, front: s, bb: C.bb(5) }; };
    return D; };

  // KIT-037 farmhouse enamel barn pendant: glossy green porcelain-enamel dome flaring to a wide rolled white rim, chipped to black steel
  // in a few spots, galvanized socket cap on a braided cloth cord, the bulb tip peeking under the rim; sways gently
  N.barn27 = S => { const T = 56, GR = '#2f5f4c', D = { w: 36, d: 36, zs: 1.6, mount: 'ceil', build: () => [] };
    const prof = [[T - 20, 2.6], [T - 21.6, 4.8], [T - 24, 9], [T - 27.5, 13.2], [T - 30, 15.6], [T - 31, 16.2]];
    const rr = y => { for (let i = 1; i < prof.length; i++) { const [ya, ra] = prof[i - 1], [yb, rb] = prof[i]; if (y >= yb) return ra + (rb - ra) * (ya - y) / (ya - yb); } return 16.2; };
    D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('barn27');
      let sh = lglow(C, [0, T - 36, 0], 30, 0.7, an('opacity', '0.6;0.85;0.6', 5, 0, SPL(2)));
      { const a = C.p(0, T - 1.4, 0), b = C.p(0, T - 17, 0), d = `M${P2(a)}L${P2(b)}`; sh += `<path d="${d}" stroke="#3a2a1e" stroke-width="${f1(1 * k)}"/><path d="${d}" stroke="#c9b08a" stroke-width="${f1(0.75 * k)}" stroke-dasharray="${f1(0.45 * k)} ${f1(0.4 * k)}"/>`; }
      sh += lcyl(C, [0, T - 17, 0], [0, T - 20.4, 0], 2.2, '#9a9c98', { mat: 'metal', olw: 0.4 }) + lcyl(C, [0, T - 19.6, 0], [0, T - 20.6, 0], 3, '#8a8c88', { mat: 'metal', olw: 0.4 });
      for (let i = 1; i < prof.length; i++) sh += lcyl(C, [0, prof[i - 1][0], 0], [0, prof[i][0], 0], prof[i - 1][1], GR, { r2: prof[i][1], ol: 0, mat: 'gloss' });
      { const H2 = []; prof.forEach(([y, r]) => { H2.push(C.p(r * Math.sin(C.thV - PI / 2), y, r * Math.cos(C.thV - PI / 2))); }); prof.slice().reverse().forEach(([y, r]) => H2.push(C.p(r * Math.sin(C.thV + PI / 2), y, r * Math.cos(C.thV + PI / 2))));
        sh += `<path d="M${H2.map(P2).join('L')}Z" fill="none" stroke="#16302a" stroke-width="${f1(0.35 * k)}" stroke-linejoin="round"/>`; }
      rep(7, i => { const a = C.thV + (R() - 0.5) * 2.4, y = i < 5 ? T - 30.2 + R() * 1.2 : T - 22 - R() * 5, r0 = rr(y) + 0.08, p = C.p(r0 * Math.sin(a), y, r0 * Math.cos(a)), w = (0.45 + R() * 0.6) * k * Math.cos(a - C.thV);
        sh += `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(w + 0.25 * k)}" ry="${f1(0.55 * k)}" fill="#9fb8aa" opacity="0.5"/><ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(w)}" ry="${f1(0.38 * k)}" fill="#1a1c1a"/>`; });
      { const P = rep(9, i => { const y = T - 20.6 - i * 1.2; return C.p(rr(y) * Math.sin(C.thV - 0.55), y, rr(y) * Math.cos(C.thV - 0.55)); }); sh += `<path d="M${P.map(P2).join('L')}" stroke="#ffffff" stroke-width="${f1(0.8 * k)}" fill="none" opacity="0.5" stroke-linecap="round"/>`; }
      const rim = (y, r0, w, col) => { const P = lring(C, y, r0, C.thV - PI / 2 - 0.15, C.thV + PI / 2 + 0.15, 26); return `<path d="M${P.map(P2).join('L')}" stroke="${col}" stroke-width="${f1(w * k)}" fill="none" stroke-linecap="round"/>`; };
      sh += rim(T - 31.1, 16.3, 1.9, '#cfcabe') + rim(T - 31, 16.3, 1.4, '#f1eee6') + rim(T - 30.7, 16.4, 0.45, '#ffffff');
      sh += `<ellipse cx="${f1(C.p(0, T - 32.2, 0)[0])}" cy="${f1(C.p(0, T - 32.2, 0)[1])}" rx="${f1(11 * k)}" ry="${f1(1.6 * k)}" fill="#fff2c8" opacity="0.55" filter="url(#l27b1)"/>`;
      return { defs: DEF27, front: lcyl(C, [0, T - 1.4, 0], [0, T, 0], 3.6, '#9a9c98', { mat: 'metal' }) + `<g>${lswing(C, [0, T - 1.4, 0], 1.8, 6)}${sh}</g>`, bb: C.bb(5) }; };
    return D; };

  // KIT-057 trio of ribbed clear glass globes on a slim brass canopy bar: each globe has fine vertical ribs (front ones bright, back ones
  // seen through the glass), a brass socket cap and an amber Edison bulb whose looped filament glows; each sways on its own cord
  N.globe27 = S => { const T = 50, GD = '#c9a04a', XS = [-20, 0, 20], YC = 22, RG = 7.2, D = { w: 62, d: 20, zs: 1.5, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx), k = C.k, v = C.v;
      let s = lbox(C, { c: [0, T - 1.6, 0], w: 50, h: 1.6, d: 5, col: GD, r: 1.2, gl: 0.2 });
      const L = XS.map((x, i) => { const top = [x, T - 1.6, 0], cap = [x, YC + RG + 2.2, 0], c = C.P([x, YC, 0]), Rr = RG * k;
        let g = lglow(C, [x, YC - 2, 0], 20, 0.55, an('opacity', '0.45;0.75;0.45', 4 + i, -i, SPL(2))) + `<path d="M${P2(C.P(top))}L${P2(C.P(cap))}" stroke="#1e1a16" stroke-width="${f1(0.45 * k)}"/>`;
        let rb = '', rf = '';
        rep(18, j => { const a = j / 18 * 2 * PI, d = 'M' + rep(13, m => { const lat = -1.25 + 2.5 * m / 12; return P2(C.P([x + RG * Math.cos(lat) * Math.sin(a), YC + RG * Math.sin(lat), RG * Math.cos(lat) * Math.cos(a)])); }).join('L'); if (front(C, Math.sin(a), Math.cos(a))) rf += d; else rb += d; });
        g += `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(Rr)}" fill="#eef6f3" opacity="0.16"/><path d="${rb}" stroke="#b8c8c2" stroke-width="${f1(0.35 * k)}" fill="none" opacity="0.45"/>`;
        const bq = [x, YC + 0.6, 0], b = C.P(bq), fl = `M${f1(b[0] - 1.2 * k)} ${f1(b[1] + 0.5 * k)}L${f1(b[0] - 0.6 * k)} ${f1(b[1] - 0.8 * k)}L${f1(b[0])} ${f1(b[1] + 0.5 * k)}L${f1(b[0] + 0.6 * k)} ${f1(b[1] - 0.8 * k)}L${f1(b[0] + 1.2 * k)} ${f1(b[1] + 0.5 * k)}`;
        g += lcyl(C, [x, YC + 5.2, 0], [x, YC + 3, 0], 0.9, '#d9c08a', { op: 0.6, olw: 0.2 }) + lsph(C, bq, 2.6, '#f6d590', { op: 0.5 })
          + `<g>${an('opacity', '0.85;1;0.85', 2.2 + i * 0.4, -i * 0.5, SPL(2))}<path d="${fl}" stroke="#ff9a2a" stroke-width="${f1(1 * k)}" fill="none" opacity="0.7" filter="url(#l27b1)"/><path d="${fl}" stroke="#ffe08a" stroke-width="${f1(0.28 * k)}" fill="none" stroke-linejoin="round"/></g>`;
        g += `<path d="${rf}" stroke="#8ea29b" stroke-width="${f1(0.55 * k)}" fill="none" opacity="0.35" transform="translate(${f1(0.2 * k)} 0)"/><path d="${rf}" stroke="#ffffff" stroke-width="${f1(0.4 * k)}" fill="none" opacity="0.6"/>`
          + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(Rr)}" fill="none" stroke="#9fb2ac" stroke-width="${f1(0.4 * k)}" opacity="0.8"/>`
          + `<path d="M${f1(c[0] - Rr * 0.78)} ${f1(c[1] - Rr * 0.2)}A${f1(Rr * 0.82)} ${f1(Rr * 0.82)} 0 0 1 ${f1(c[0] - Rr * 0.1)} ${f1(c[1] - Rr * 0.8)}" stroke="#ffffff" stroke-width="${f1(0.9 * k)}" fill="none" opacity="0.7" stroke-linecap="round"/><circle cx="${f1(c[0] + Rr * 0.35)}" cy="${f1(c[1] - Rr * 0.5)}" r="${f1(0.5 * k)}" fill="#ffffff" opacity="0.85"/>`;
        g += lcyl(C, [x, YC + RG * 0.93, 0], [x, YC + RG + 0.2, 0], 2.4, '#e8f0ec', { op: 0.5, olw: 0.3 }) + lcyl(C, [x, YC + RG + 2.4, 0], [x, YC + RG - 0.2, 0], 1.7, GD, { mat: 'metal', olw: 0.4 });
        return { q: [x, YC, 0], s: `<g>${lswing(C, top, 1.4, 5.5 + i * 0.8, -i * 1.3)}${g}</g>` }; });
      return { defs: DEF27, front: s + zsort(C, L), bb: C.bb(5) }; };
    return D; };

  // KIT-077 linear hand-forged brass + alabaster island chandelier (luxury): a hammered brass bar with scrolled ends on two brass rods,
  // five veined alabaster drums in brass bobeche cups glowing warm from inside (each breathes), a glint travelling along the bar
  N.alab27 = S => { const T = 54, YB = 30, L = 30, GD = '#c9a04a', XS = [-24, -12, 0, 12, 24], D = { w: 70, d: 22, zs: 1.5, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('alab27');
      let s = lglow(C, [0, YB - 14, 0], 52, 0.5, an('opacity', '0.4;0.6;0.4', 7, 0, SPL(2)), 'l27a');
      [-L + 6, L - 6].forEach(x => { s += lcyl(C, [x, T - 1.4, 0], [x, T, 0], 3.4, GD, { mat: 'metal' }) + lcyl(C, [x, YB + 1.8, 0], [x, T - 1.4, 0], 0.45, GD, { mat: 'metal', olw: 0.35 }); });
      s += lbox(C, { c: [0, YB, 0], w: 2 * L, h: 1.8, d: 1.8, col: '#c39a46', gl: 0.2 });
      s += rep(30, i => { const p = C.p(-L + 1 + i * 2 + R(), YB + 0.3 + R() * 1.2, 0.95); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(0.45 * k)}" ry="${f1(0.3 * k)}" fill="${i % 2 ? '#8a6420' : '#ffe6a0'}" opacity="0.55"/>`; }).join('');
      [-1, 1].forEach(sg => { const c = C.P([sg * L, YB + 0.9, 0]); s += `<path d="M${f1(c[0])} ${f1(c[1])}c${f1(sg * 1.6 * k)} ${f1(-0.4 * k)} ${f1(sg * 2.4 * k)} ${f1(1.4 * k)} ${f1(sg * 1.6 * k)} ${f1(2.4 * k)}c${f1(-sg * 0.8 * k)} ${f1(0.9 * k)} ${f1(-sg * 1.8 * k)} ${f1(0.1 * k)} ${f1(-sg * 1.4 * k)} ${f1(-0.8 * k)}" stroke="#6a4612" stroke-width="${f1(1.3 * k)}" fill="none" stroke-linecap="round"/><path d="M${f1(c[0])} ${f1(c[1])}c${f1(sg * 1.6 * k)} ${f1(-0.4 * k)} ${f1(sg * 2.4 * k)} ${f1(1.4 * k)} ${f1(sg * 1.6 * k)} ${f1(2.4 * k)}c${f1(-sg * 0.8 * k)} ${f1(0.9 * k)} ${f1(-sg * 1.8 * k)} ${f1(0.1 * k)} ${f1(-sg * 1.4 * k)} ${f1(-0.8 * k)}" stroke="${GD}" stroke-width="${f1(0.85 * k)}" fill="none" stroke-linecap="round"/>`; });
      { const a = C.p(-L + 2, YB + 1.6, 0.9), b = C.p(L - 2, YB + 1.6, 0.9); s += `<ellipse cx="0" cy="0" rx="${f1(2.2 * k)}" ry="${f1(0.35 * k)}" fill="#fff6d0" opacity="0"><animateMotion path="M${P2(a)}L${P2(b)}" dur="9s" repeatCount="indefinite" keyPoints="0;0;1" keyTimes="0;0.55;1" calcMode="linear"/><animate attributeName="opacity" values="0;0;0.9;0" keyTimes="0;0.55;0.8;1" dur="9s" repeatCount="indefinite"/></ellipse>`; }
      const Ls = XS.map((x, i) => { const y0 = YB - 4, y1 = YB - 12.5, a0 = C.thV;
        let g = lglow(C, [x, y1 - 2, 0], 15, 0.6, an('opacity', '0.45;0.85;0.45', 6, -i * 1.1, SPL(2)), 'l27a');
        g += lcyl(C, [x, YB, 0], [x, y0 + 0.7, 0], 0.4, GD, { mat: 'metal', olw: 0.3 }) + lcyl(C, [x, y0 + 0.9, 0], [x, y0, 0], 2.6, GD, { mat: 'metal', r2: 3.6, olw: 0.35 });
        g += lcyl(C, [x, y0, 0], [x, y1, 0], 4.4, '#f4e8d4', { r2: 5.6, olw: 0.5, olc: '#b89e7a' });
        let vn = ''; rep(5, m => { const b0 = a0 + (R() - 0.5) * 2.2, d = rep(9, q => { const f = q / 8, y = y0 - (y0 - y1) * f, r0 = 4.45 + 1.2 * f, a = b0 + 0.45 * Math.sin(f * 4 + m * 1.7); return Math.cos(a - a0) > 0.15 ? C.p(x + r0 * Math.sin(a), y, r0 * Math.cos(a)) : null; }).filter(Boolean); if (d.length > 2) vn += 'M' + d.map(P2).join('L'); });
        g += `<path d="${vn}" stroke="#c8a676" stroke-width="${f1(0.3 * k)}" fill="none" opacity="0.6" stroke-linejoin="round"/><path d="${vn}" stroke="#fffaf0" stroke-width="${f1(0.6 * k)}" fill="none" opacity="0.25" transform="translate(${f1(0.4 * k)} 0)"/>`;
        g += `<g>${an('opacity', '0.25;0.55;0.25', 6, -i * 1.1, SPL(2))}${lcyl(C, [x, y0, 0], [x, y1, 0], 4.42, '#ffd9a0', { r2: 5.62, ol: 0, noCap: 1 })}</g>`;
        { const P = lring(C, y1, 5.7, a0 - PI / 2, a0 + PI / 2, 22).map(q => [q[0] + C.p(x, 0, 0)[0] - C.p(0, 0, 0)[0], q[1] + C.p(x, 0, 0)[1] - C.p(0, 0, 0)[1]]); g += tube27(C, P, 0.55, GD); }
        return { q: [x, y0, 0], s: g }; });
      return { defs: DEF27, front: s + zsort(C, Ls), bb: C.bb(5) }; };
    return D; };

  // KIT-097 living herb-halo grow-light chandelier (luxury): a polished brass halo trough on four fine brass cables, planted all round with
  // living basil, purple basil, rosemary and thyme (each tuft sways on its own), trailing thyme hanging over the edge, a warm champagne
  // grow-light line glowing under the ring, dew drops twinkling on the leaves
  N.herb27 = S => { const T = 56, YR = 24, RR = 24, GD = '#c9a04a', D = { w: 60, d: 60, zs: 1.4, mount: 'ceil', build: () => [] };
    D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('herb27b'), th = C.thV;
      const LC = [['#5f8f3e', '#7fae4e', '#4e7a34'], ['#6a4a6e', '#83607e', '#55385a'], ['#4e6e48', '#6a8a5a', '#3e5a3a'], ['#6f9a4a', '#8fb85e', '#5a8a3c']];
      const tufts = { f: '', b: '' }, vines = { f: '', b: '' }, dew = [];
      rep(40, i => { const a = i / 40 * 2 * PI + R() * 0.08, r0 = RR + (R() - 0.5) * 2.2, q = [r0 * Math.sin(a), YR + 1.4, r0 * Math.cos(a)], p = C.P(q), kd = i % 7 === 3 ? 1 : i % 3 === 0 ? 2 : i % 5 === 1 ? 3 : 0, cl = LC[kd]; let g = '';
        if (kd === 2) rep(6, j => { const an2 = (j - 2.5) * 0.22 + (R() - 0.5) * 0.1, l = (3 + R() * 1.6) * k, ex = p[0] + Math.sin(an2) * l, ey = p[1] - Math.cos(an2) * l; g += `<path d="M${P2(p)}L${f1(ex)} ${f1(ey)}" stroke="${cl[2]}" stroke-width="${f1(0.3 * k)}"/>`;
          rep(4, m => { const f = 0.3 + m * 0.18, x = p[0] + (ex - p[0]) * f, y = p[1] + (ey - p[1]) * f; g += `<path d="M${f1(x - 0.6 * k)} ${f1(y + 0.3 * k)}L${f1(x)} ${f1(y)}L${f1(x + 0.6 * k)} ${f1(y + 0.3 * k)}" stroke="${cl[m % 2]}" stroke-width="${f1(0.25 * k)}" fill="none"/>`; }); });
        else rep(kd === 3 ? 9 : 6, j => { const an2 = (j - (kd === 3 ? 4 : 2.5)) * (kd === 3 ? 0.3 : 0.45) + (R() - 0.5) * 0.2, l = (kd === 3 ? 1.6 : 2.4) * k * (0.7 + R() * 0.6), cx = p[0] + Math.sin(an2) * l, cy = p[1] - Math.cos(an2) * l * 0.9, rx = (kd === 3 ? 0.45 : 0.85) * k, ry = (kd === 3 ? 0.7 : 1.4) * k;
          g += `<ellipse cx="${f1(cx)}" cy="${f1(cy)}" rx="${f1(rx)}" ry="${f1(ry)}" fill="${cl[j % 3]}" transform="rotate(${f1(an2 * 57)} ${f1(cx)} ${f1(cy)})"/><path d="M${f1(cx)} ${f1(cy + ry * 0.8)}L${f1(cx)} ${f1(cy - ry * 0.7)}" stroke="${shade(cl[j % 3], 1.3)}" stroke-width="${f1(0.12 * k)}" transform="rotate(${f1(an2 * 57)} ${f1(cx)} ${f1(cy)})"/>`; if (j === 2 && i % 4 === 0) dew.push([cx, cy - ry * 0.3]); });
        if (i % 9 === 4) g += `<circle cx="${f1(p[0])}" cy="${f1(p[1] - 3.4 * k)}" r="${f1(0.35 * k)}" fill="#f4efff"/>`;
        tufts[front(C, Math.sin(a), Math.cos(a)) ? 'f' : 'b'] += `<g>${lrot(p, 4 + R() * 3, 3 + R() * 2.4, -R() * 3)}${g}</g>`; });
      rep(12, i => { const a = i / 12 * 2 * PI + 0.26, q = [(RR + 1.8) * Math.sin(a), YR + 0.6, (RR + 1.8) * Math.cos(a)], p = C.P(q), len = (8 + (i * 7) % 9) * k, P = rep(7, m => [p[0] + Math.sin(m * 0.9 + i) * 0.7 * k, p[1] + len * m / 6]);
        let g = `<path d="M${P.map(P2).join('L')}" stroke="#4e6e3a" stroke-width="${f1(0.25 * k)}" fill="none"/>`; P.slice(1).forEach((pp, m) => { g += `<ellipse cx="${f1(pp[0] + (m % 2 ? 0.5 : -0.5) * k)}" cy="${f1(pp[1])}" rx="${f1(0.42 * k)}" ry="${f1(0.3 * k)}" fill="${m % 2 ? '#7fa05a' : '#5e8a44'}"/>`; });
        vines[front(C, Math.sin(a), Math.cos(a)) ? 'f' : 'b'] += `<g>${lrot(p, 3, 4 + (i % 4) * 0.6, -i * 0.5)}${g}</g>`; });
      let s = lglow(C, [0, YR - 8, 0], 46, 0.55, an('opacity', '0.4;0.65;0.4', 6, 0, SPL(2)), 'l27g');
      s += rep(4, i => { const a = i * PI / 2 + PI / 4, b = C.p(RR * Math.sin(a), YR + 1, RR * Math.cos(a)), t = C.p(0, T - 1.4, 0); return `<path d="M${P2(t)}L${P2(b)}" stroke="#b8893a" stroke-width="${f1(0.22 * k)}"/>`; }).join('');
      const soil = lring(C, YR + 1.2, RR, 0, 2 * PI, 48);
      s += vines.b + `<path d="M${soil.map(P2).join('L')}Z" stroke="#3a2a1c" stroke-width="${f1(3.4 * k)}" fill="none"/>`;
      s += tube27(C, lring(C, YR + 1, RR + 1.8, th + PI / 2, th + 3 * PI / 2, 30), 1.3, GD) + tube27(C, lring(C, YR + 1, RR - 1.8, th + PI / 2, th + 3 * PI / 2, 30), 1, GD) + tufts.b;
      const ul = lring(C, YR - 0.4, RR, th - PI / 2, th + PI / 2, 30), ud = 'M' + ul.map(P2).join('L');
      s += `<path d="${ud}" stroke="#ffd58a" stroke-width="${f1(3 * k)}" fill="none" filter="url(#l27b1)" opacity="0.6">${an('opacity', '0.4;0.75;0.4', 6, 0, SPL(2))}</path>`;
      s += tube27(C, lring(C, YR + 1, RR - 1.8, th - PI / 2, th + PI / 2, 30), 1, GD) + tufts.f + tube27(C, lring(C, YR + 1, RR + 1.8, th - PI / 2, th + PI / 2, 30), 1.3, GD) + `<path d="${ud}" stroke="#fff3d4" stroke-width="${f1(0.4 * k)}" fill="none"/>` + vines.f;
      s += dew.map(([x, y], i) => `<path d="M${f1(x - 0.8 * k)} ${f1(y)}H${f1(x + 0.8 * k)}M${f1(x)} ${f1(y - 0.8 * k)}V${f1(y + 0.8 * k)}" stroke="#ffffff" stroke-width="${f1(0.2 * k)}" stroke-linecap="round" opacity="0">${an('opacity', '0;0;1;0', 4 + (i % 3), -i * 0.8, ' keyTimes="0;0.7;0.8;1"')}</path>`).join('');
      return { defs: DEF27, front: lcyl(C, [0, T - 1.4, 0], [0, T, 0], 4.6, GD, { mat: 'metal' }) + s, bb: C.bb(6) }; };
    return D; };

  const FLOOR27 = { ylino: fYlino, diner: fDiner, quarry: fQuarry, oak: fOak, cush: fCush }, MEMO = {};
  const draw26 = RD.draw;
  RD.draw = (r, o) => { const res = draw26(r, o); if (!res || res._p27) return res;
    try { const f = r.f27 && FLOOR27[r.f27]; if (f && res.surf) { res._p27 = 1; res.vb = '0 0 80 56'; res.svg = MEMO[r.f27] || (MEMO[r.f27] = RD.svgDoc('0 0 80 56', [], f())); res.src = 'data:image/svg+xml,' + encodeURIComponent(res.svg); }
      const c = r.c27 && CEIL27[r.c27]; if (c && res.surf) { res._p27 = 1; res.vb = '0 0 80 56';
        const M = CMEMO[r.c27] || (CMEMO[r.c27] = (() => { const G = mkV(CFRM.room); return { svg: RD.svgDoc('0 0 80 56', [], cardOf27(r.c27)), room: RD.svgDoc('0 0 ' + G.W + ' ' + G.H, [], cDoc(G, c(G))) }; })());
        res.svg = M.svg; res.src = 'data:image/svg+xml,' + encodeURIComponent(M.svg); res.ceilRoom = M.room; res.ceilBase = CB27[r.c27][0]; res.ceilTrim = CB27[r.c27][1]; } } catch (e) { console.warn('reno plus27', r.id, e); }
    return res; };

  // ======================= WALLS & BACKSPLASH (r.s12 creature-scale 80 x 56 tiles, plus12 / plus19 pipeline) =======================
  // one tile = full wall height (BB = skirting top); backsplash band BT..BB; S.sup = upper wall for the side-wall rows above, S.smat = side-wall bottom row
  const WMEMO27 = {};
  { const { blot, outlet, BB, SURF12 } = RD.H12, BT = 24, SR = Math.SQRT2;
    const memo = (k, f) => () => WMEMO27[k] || (WMEMO27[k] = f());
    const capB = (col, h) => { const t = BB - h; return `<rect y="${f1(t - 0.9)}" width="80" height="0.9" fill="#000000" opacity="0.14" filter="url(#wb1)"/><rect y="${f1(t)}" width="80" height="${f1(h)}" fill="${col}"/><rect y="${f1(t)}" width="80" height="0.35" fill="${shade(col, 1.14)}"/><rect y="${f1(t + 0.55)}" width="80" height="0.2" fill="${shade(col, 0.8)}"/><rect y="${f1(BB - 0.25)}" width="80" height="0.25" fill="${shade(col, 0.86)}"/>`; };
    const scf = (seed, n, a, b) => { const R = rng(seed); return rep(n, () => `<path d="M${f1(R() * 78)} ${f1(BB + 0.5 + R() * 1.6)}h${f1(0.6 + R() * 1.6)}" stroke="${R() < 0.5 ? a : b}" stroke-width="${f1(0.12 + R() * 0.16)}" stroke-linecap="round" opacity="0.6"/>`).join(''); };
    const bandC = id => `<clipPath id="${id}"><rect y="${BT}" width="80" height="${f1(BB - BT)}"/></clipPath>`;
    const lblot = (seed, n, cols, op, sz, y0, y1) => { const R = rng(seed); let o = '<g filter="url(#wb2)">'; rep(n, i => { const x = R() * 80, y = y0 + R() * (y1 - y0), rx = sz * (0.6 + R() * 0.9), ry = rx * (0.5 + R() * 0.3);
      [-80, 0, 80].forEach(dx => { const cx = x + dx; if (cx + rx < -3 || cx - rx > 83) return; o += `<ellipse cx="${f1(cx)}" cy="${f1(y)}" rx="${f1(rx)}" ry="${f1(ry)}" fill="${cols[i % cols.length]}" opacity="${op}"/>`; }); }); return o + '</g>'; };
    const wrapX = (x, w, f) => [-80, 0, 80].filter(dx => x + dx + w > -1 && x + dx - w < 81).map(dx => f(x + dx)).join('');

    // KIT-001 grease-splattered drywall behind the stove: builder-beige drywall, taped + mudded joints, screw pops, a spackle patch,
    // a yellowed smoke haze, amber grease splatter + runs round the stove spot (one drip slowly forms and falls), scorch mark, greasy outlet, peeling vinyl cove base
    const kDry = memo('k01', () => { const R = rng('kd01');
      let s = '<rect width="80" height="56" fill="#dcd2bd"/>' + blot('kd01', 32, ['#e3dac7', '#d2c7b0', '#d8cdb7'], 0.4, 3);
      [0, 40, 80].forEach(x => s += `<rect x="${x - 2.6}" width="5.2" height="56" fill="#e7dfcd" opacity="0.6" filter="url(#wb2)"/><path d="M${f1(x - 1.05)} 0V56M${f1(x + 1.05)} 0V56" stroke="#bdb197" stroke-width="0.1" opacity="0.55"/><path d="M${f1(x + 0.2)} 0V56" stroke="#c9bea6" stroke-width="0.08" opacity="0.5"/>`);
      s += '<rect y="26.4" width="80" height="4.2" fill="#e7dfcd" opacity="0.5" filter="url(#wb2)"/><path d="M0 27.6H80M0 29.4H80" stroke="#bdb197" stroke-width="0.08" opacity="0.45"/>';
      for (let x = 4; x < 80; x += 8) for (let y = 4; y < 52; y += 6) { if (R() < 0.3) continue; const px = x + (R() - 0.5) * 0.6, py = y + (R() - 0.5) * 0.6;
        s += `<circle cx="${f1(px)}" cy="${f1(py)}" r="0.34" fill="#cbbfa6"/><circle cx="${f1(px - 0.08)}" cy="${f1(py - 0.1)}" r="0.19" fill="#efe8da"/>` + (R() < 0.15 ? `<circle cx="${f1(px)}" cy="${f1(py)}" r="0.62" fill="none" stroke="#a99c82" stroke-width="0.08" opacity="0.7"/>` : ''); }
      // spackle patch (never sanded or painted) + crack + nail holes
      s += '<path d="M10.6 17.4Q12.4 15.8 15.6 16.6Q17.6 17.8 16.8 20.4Q15.4 22.4 12.2 21.8Q10 20.6 10.6 17.4Z" fill="#e8e1d2" opacity="0.75"/><path d="M11.6 18.2q1.6 -1 3.4 -0.2M11.4 19.8q2 -0.8 4.6 0.2M12.4 21q1.4 -0.4 3 0" stroke="#d9d0bd" stroke-width="0.14" fill="none"/><path d="M10.6 17.4Q12.4 15.8 15.6 16.6" stroke="#ffffff" stroke-width="0.16" fill="none" opacity="0.8"/>';
      s += '<path d="M70.4 0L71 2.2L70.6 3.6L71.8 5.4L71.4 7.2L72.6 9.4" stroke="#8f826a" stroke-width="0.16" fill="none" stroke-linejoin="bevel"/><path d="M70.6 0.2L71.2 2.3L70.8 3.7L72 5.5" stroke="#ffffff" stroke-width="0.08" fill="none" opacity="0.5"/>';
      [[24.6, 12.2], [55.2, 9.8], [57.1, 10.1]].forEach(([x, y]) => s += `<circle cx="${x}" cy="${y}" r="0.2" fill="#5a4c38"/><circle cx="${x + 0.07}" cy="${y + 0.07}" r="0.27" fill="none" stroke="#ffffff" stroke-width="0.06" opacity="0.6"/>`);
      const sup = s + '<rect width="80" height="56" fill="url(#kdy)"/>';
      s += '<rect width="80" height="56" fill="url(#kdy)"/>';
      // grease: haze, splatter (dense near the burner spot), glossy beads, runs, scorch
      s += lblot('kdg', 22, ['#b89048', '#a07a38', '#c49d58'], 0.16, 5, 22, 42) + lblot('kdg2', 10, ['#94702f', '#7a5a26'], 0.14, 3.4, 28, 40);
      const SP = ['#9a7434', '#a8823e', '#7a5a26', '#b89250', '#6a4c20'];
      s += rep(260, () => { const x = R() * 80, y = 32 + (R() + R() + R() - 1.5) * 9, r = 0.06 + R() * R() * 0.5, op = f1(0.25 + R() * 0.45);
        return wrapX(x, r, x => `<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(r)}" ry="${f1(r * (0.8 + R() * 0.4))}" fill="${SP[Math.floor(R() * 5)]}" opacity="${op}"/>` + (r > 0.28 ? `<circle cx="${f1(x - r * 0.3)}" cy="${f1(y - r * 0.35)}" r="${f1(r * 0.32)}" fill="#fff6dc" opacity="0.55"/>` : '')); }).join('');
      const run = (x, y0, l, w, c) => `<path d="M${f1(x - w / 2)} ${y0}V${f1(y0 + l)}a${f1(w / 2)} ${f1(w * 0.7)} 0 0 0 ${f1(w)} 0V${y0}Z" fill="${c}" opacity="0.5"/><path d="M${f1(x - w * 0.18)} ${f1(y0 + 0.3)}V${f1(y0 + l)}" stroke="#fff2cc" stroke-width="${f1(w * 0.18)}" opacity="0.5"/>`;
      [[6.4, 31, 3.2, 0.3], [19.2, 29.6, 5.2, 0.4], [35.2, 31.6, 6.8, 0.5], [38.6, 30.4, 2.6, 0.28], [47, 28.6, 9.6, 0.5], [58.6, 32.2, 3.6, 0.32], [71.8, 30, 4.6, 0.38]].forEach(([x, y, l, w], i) => s += run(x, y, l, w, SP[i % 5]));
      s += `<g opacity="0">${an('opacity', '0;0.8;0.8;0', 11, 0, ' keyTimes="0;0.15;0.85;1"')}<ellipse cx="47" cy="38.9" rx="0.36" ry="0.48" fill="#8a6428">${an('cy', '38.7;39.3;39.3;45', 11, 0, ' keyTimes="0;0.6;0.82;1" calcMode="spline" keySplines="0.4 0 0.6 1;0 0 1 1;0.6 0 1 1"')}${an('ry', '0.3;0.62;0.62;0.42', 11, 0, ' keyTimes="0;0.6;0.82;1"')}</ellipse></g>`;
      s += '<g filter="url(#wb2)"><ellipse cx="27" cy="40.6" rx="3.6" ry="2.4" fill="#2a2018" opacity="0.32"/><ellipse cx="26.4" cy="38.6" rx="2" ry="3.4" fill="#2a2018" opacity="0.2"/></g><path d="M25 41.4q1.6 -2.4 1.2 -5.2q1.4 2.6 1 5.4" stroke="#3a2c1e" stroke-width="0.14" fill="none" opacity="0.4"/>';
      s += outlet(61.6, 44.4, '#e8e0cc', '#5a5244') + '<rect x="61.6" y="44.4" width="1.5" height="2.3" rx="0.22" fill="#9a7434" opacity="0.3"/><path d="M62.2 44.5l0.5 0.8l-0.3 0.5" stroke="#8a806c" stroke-width="0.07" fill="none"/><circle cx="62.35" cy="45.55" r="0.08" fill="#c8c0ac"/>';
      const board = '#7e6e58';
      return { mat: s, sup, smat: sup + outlet(61.6, 44.4, '#e8e0cc', '#5a5244'), board,
        defs: '<linearGradient id="kdy" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c49d52" stop-opacity="0.26"/><stop offset="0.5" stop-color="#c49d52" stop-opacity="0.06"/><stop offset="1" stop-color="#c49d52" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.05, ao: 0.17, board: `<rect y="${BB}" width="80" height="0.55" fill="${shade(board, 1.25)}"/>` + '<path d="M18.2 53.6Q20.6 52.8 23.4 53.6Z" fill="#9c8a6e"/><path d="M18.2 53.6Q20.6 52.9 23.4 53.6" stroke="#5a4c38" stroke-width="0.1" fill="none"/><rect x="18.4" y="53.6" width="4.8" height="0.4" fill="#2a2018" opacity="0.35" filter="url(#wb1)"/>' + scf('kdb', 22, '#4e4232', '#a8977a') + `<rect y="${f1(BB + 0.9)}" width="80" height="0.3" fill="#9a7434" opacity="0.35"/>` } }; });

    // KIT-021 peel-and-stick faux-tile vinyl over mint paint: printed fake subway tiles (flat grout lines, the SAME printed shine on every tile),
    // 4 sticky sheets with misaligned seams, air bubbles, one corner peeling off the paper backing (flutters), rough cut round the outlet, plastic J-trim, cherry vinyl base
    const kVinyl = memo('k21', () => { const R = rng('kv21'), PT = '#f1ede3';
      let up = '<rect width="80" height="56" fill="#d3e6d8"/>' + blot('kv21', 26, ['#dcecdf', '#c8dccd', '#d6e8da'], 0.4, 3);
      for (let i = 0; i < 40; i++) up += `<rect x="${f1(i * 2 + R())}" width="${f1(1 + R() * 2)}" height="56" fill="${R() < 0.5 ? '#ffffff' : '#9ab8a2'}" opacity="${f1(0.03 + R() * 0.04)}"/>`;
      up += rep(70, () => `<circle cx="${f1(R() * 80)}" cy="${f1(R() * 56)}" r="${f1(0.1 + R() * 0.12)}" fill="#b6cfbd" opacity="0.5"/>`).join('');
      let s = up, b = '';
      const OFF = [0, 0.42, -0.26, 0.18];
      OFF.forEach((o, i) => b += `<g transform="translate(0 ${o})"><rect x="${i * 20}" y="${BT - 1}" width="20" height="${f1(BB - BT + 2)}" fill="url(#kvp)"/></g>`);
      b += '<rect y="' + BT + '" width="80" height="' + f1(BB - BT) + '" fill="url(#kvs)"/>';
      [0, 20, 40, 60, 80].forEach((x, i) => b += `<path d="M${x} ${BT}V${BB}" stroke="#8f8a7e" stroke-width="0.16" opacity="0.7"/><path d="M${f1(x + 0.14)} ${BT}V${BB}" stroke="#ffffff" stroke-width="0.12" opacity="0.8"/>` + (i === 2 ? `<rect x="${x - 0.12}" y="${BT}" width="0.24" height="${f1(BB - BT)}" fill="#d3e6d8"/>` : ''));
      [[12.6, 33.4, 1.3], [50.2, 41.8, 0.9], [27.4, 46.6, 1.1], [69, 30.2, 0.8]].forEach(([x, y, r]) => b += `<ellipse cx="${x}" cy="${f1(y + r * 0.25)}" rx="${f1(r * 1.1)}" ry="${f1(r * 0.75)}" fill="#000000" opacity="0.08" filter="url(#wb1)"/><ellipse cx="${x}" cy="${y}" rx="${r}" ry="${f1(r * 0.7)}" fill="url(#kvb)"/><path d="M${f1(x - r * 0.6)} ${f1(y - r * 0.2)}q${f1(r * 0.4)} ${f1(-r * 0.45)} ${f1(r * 0.9)} ${f1(-r * 0.35)}" stroke="#ffffff" stroke-width="0.16" fill="none" opacity="0.85"/>`);
      // rough cut round the outlet + grease thumbprint
      b += '<path d="M58.6 43.6L61.9 43.4L62.1 47.3L58.5 47.5Z" fill="#d3e6d8"/><path d="M58.6 43.6L60.2 43.5L61.9 43.4L62 45.2L62.1 47.3L60.4 47.4L58.5 47.5L58.6 45.6Z" fill="none" stroke="#8f8a7e" stroke-width="0.1"/>' + outlet(59.5, 44.2, '#f4f1e8', '#5a5850');
      b += '<ellipse cx="33" cy="38" rx="0.9" ry="1.2" fill="#c8b48a" opacity="0.18"/>';
      // peeling corner: sheet 2 top-left corner at x 40 lifts off, showing tacky glue on the wall + the paper-white back of the vinyl
      b += '<path d="M40.12 24L45.4 24L40.12 30.2Z" fill="#e8deb4"/><path d="M40.6 24.6l3 0.3M40.6 25.8l2.2 0.6M40.5 27.2l1.4 0.4" stroke="#cdbf8a" stroke-width="0.1" opacity="0.8"/>'
        + `<g>${at('rotate', '0 40.2 24.4;-4 40.2 24.4;1 40.2 24.4;0 40.2 24.4', 6.5, 0, SPL(3))}<path d="M45.4 24Q43.4 27.6 40.12 30.2Q42.6 30.4 44.6 29.2Q46.6 27 45.4 24Z" fill="#000000" opacity="0.18" filter="url(#wb1)"/><path d="M45.4 24Q43.4 27.6 40.12 30.2Q42 29.6 43.6 28.4Q45.6 26.6 45.4 24Z" fill="#faf8f2"/><path d="M45.4 24Q43.4 27.6 40.12 30.2" stroke="#b8b2a4" stroke-width="0.12" fill="none"/><path d="M44.6 25.6Q43.4 27.6 41.6 29.2" stroke="#e0dbd0" stroke-width="0.25" fill="none"/></g>`;
      s += `<g clip-path="url(#kvc)">${b}</g>`;
      s += `<rect y="${BT}" width="80" height="0.9" fill="#000000" opacity="0.12" filter="url(#wb1)"/><rect y="${BT - 0.8}" width="80" height="0.9" fill="#f6f4ee"/><rect y="${BT - 0.8}" width="80" height="0.25" fill="#ffffff"/><rect y="${f1(BT - 0.05)}" width="80" height="0.15" fill="#b9b4a8"/>`;
      const board = '#b5262c';
      return { mat: s, sup: up, smat: up, board,
        defs: bandC('kvc') + '<pattern id="kvp" width="4" height="4" patternUnits="userSpaceOnUse"><rect width="4" height="4" fill="#bdb8ac"/>'
          + [[0.11, 0.11, 3.78], [-1.89, 2.11, 3.78], [2.11, 2.11, 3.78]].map(([x, y, w]) => `<rect x="${x}" y="${y}" width="${w}" height="1.78" fill="${PT}"/><rect x="${x}" y="${y}" width="${w}" height="0.18" fill="#ffffff" opacity="0.8"/><rect x="${x}" y="${f1(y + 1.56)}" width="${w}" height="0.22" fill="#cfcabd"/><path d="M${f1(x + 0.6)} ${f1(y + 1.2)}l0.9 -0.8M${f1(x + 1.1)} ${f1(y + 1.3)}l0.5 -0.45" stroke="#ffffff" stroke-width="0.16" opacity="0.9"/>`).join('') + '</pattern>'
          + '<linearGradient id="kvs" x1="0" y1="0" x2="1" y2="0.4"><stop offset="0.15" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.45" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.8" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="0.9" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
          + '<radialGradient id="kvb" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.7"/><stop offset="0.6" stop-color="#f1ede3" stop-opacity="0.2"/><stop offset="1" stop-color="#8f8a7e" stop-opacity="0.35"/></radialGradient>',
        ro: { top: 0.06, ao: 0.12, board: `<rect y="${BB}" width="80" height="0.5" fill="#e0545a"/><rect y="${f1(BB + 0.7)}" width="80" height="0.2" fill="#ffffff" opacity="0.35"/>` + scf('kvb', 12, '#5a1014', '#e87a7e') } }; });

    // KIT-041 glossy white herringbone subway tile (45 deg, true herringbone: 18 repeats per tile) under eggshell sage walls; bullnose cap,
    // each tile slightly different white with a glazed bevel, window reflections + a slow glint sliding over the glaze
    const kHerr = memo('k41', () => { const R = rng('kh41'), sc = 80 / (18 * 2 * SR), g = 0.11, WH = ['#fbfcfa', '#f5f7f4', '#eff2ef', '#f8f9f6', '#f2f4f1'];
      let up = '<rect width="80" height="56" fill="#a9b698"/>' + blot('kh41', 30, ['#b3bfa3', '#9fad8f', '#aab798'], 0.4, 3.4) + rep(60, () => `<circle cx="${f1(R() * 80)}" cy="${f1(R() * 56)}" r="0.12" fill="#c4cfb6" opacity="0.5"/>`).join('');
      let s = up, b = '<rect y="' + BT + '" width="80" height="' + f1(BB - BT) + '" fill="#c9cdc6"/>';
      const rp = (x0, y0, x1, y1) => [[x0 + g, y0 + g], [x1 - g, y0 + g], [x1 - g, y1 - g], [x0 + g, y1 - g]].map(([x, y]) => [(x - y) / SR * sc, (x + y) / SR * sc + BT - 4]);
      const brick = Q => { const xs = Q.map(p => p[0]), ys = Q.map(p => p[1]); if (Math.max(...xs) < -0.5 || Math.min(...xs) > 80.5 || Math.max(...ys) < BT - 0.5 || Math.min(...ys) > BB + 0.5) return '';
        const d = 'M' + Q.map(pt).join('L') + 'Z', c = WH[Math.floor(R() * 5)];
        return `<path d="${d}" fill="${c}"/><path d="${d}" fill="url(#khg)"/><path d="M${pt(Q[3])}L${pt(Q[0])}L${pt(Q[1])}" stroke="#ffffff" stroke-width="0.14" fill="none"/><path d="M${pt(Q[1])}L${pt(Q[2])}L${pt(Q[3])}" stroke="#c2c7c0" stroke-width="0.12" fill="none"/>`; };
      for (let k = -3; k < 21; k++) for (let n = -6; n < 26; n++) { const ox = n + 2 * k, oy = n - 2 * k; b += brick(rp(ox, oy, ox + 2, oy + 1)) + brick(rp(ox + 2, oy - 1, ox + 3, oy + 1)); }
      b += '<g filter="url(#wb2)"><path d="M12 26L20 26L14 52L6 52Z" fill="#ffffff" opacity="0.2"/><path d="M52 26L57 26L51 52L46 52Z" fill="#ffffff" opacity="0.14"/></g>';
      b += `<rect x="-30" y="${BT}" width="14" height="${f1(BB - BT)}" fill="url(#khs)" transform="skewX(-18)">${an('x', '-30;110;110', 15, 0, ' keyTimes="0;0.45;1"')}</rect>`;
      b += outlet(65.4, 44.2, '#fbfbf8', '#7a7e78');
      s += `<g clip-path="url(#khc)">${b}</g>`;
      s += `<rect y="${f1(BT + 0.4)}" width="80" height="0.8" fill="#000000" opacity="0.14" filter="url(#wb1)"/><rect y="${f1(BT - 1)}" width="80" height="1.3" rx="0.6" fill="url(#khb)"/><rect y="${f1(BT - 0.85)}" width="80" height="0.22" fill="#ffffff" opacity="0.9"/>`;
      const board = '#efeee8';
      return { mat: s, sup: up, smat: up, board,
        defs: bandC('khc') + '<linearGradient id="khg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.75"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.8" stop-color="#9aa39c" stop-opacity="0.08"/><stop offset="1" stop-color="#7d867f" stop-opacity="0.2"/></linearGradient>'
          + '<linearGradient id="khb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="0.5" stop-color="#f1f3ef"/><stop offset="1" stop-color="#c8cdc6"/></linearGradient>'
          + '<linearGradient id="khs" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.07, ao: 0.12, board: capB(board, 1.1) + scf('khb', 6, '#c9c8c0', '#ffffff') } }; });

    // KIT-061 hand-hammered copper backsplash under Venetian lime plaster: troweled plaster sweeps + burnish, copper sheets with hundreds of
    // hammer dimples (lit like real concave dents), warm rose/gold/brown tones, standing seams with domed copper rivets, polished half-round cap, warm glint + twinkles
    const kCop = memo('k61', () => { const R = rng('kc61');
      let up = '<rect width="80" height="56" fill="#e7dac2"/>' + blot('kc61', 30, ['#efe4d0', '#dccdb2', '#e9dcc4', '#d6c5a6'], 0.45, 3.6) + '<g filter="url(#wb1)">';
      up += rep(90, () => { const x = R() * 84 - 2, y = R() * 58 - 1, l = 3 + R() * 7, h = (R() - 0.5) * 3, w = 0.6 + R() * 1.8, lt = R() < 0.55;
        return wrapX(x, l, xx => `<path d="M${f1(xx)} ${f1(y)}q${f1(l / 2)} ${f1(h)} ${f1(l)} ${f1(h * 0.3)}" stroke="${lt ? '#f8f1e4' : '#cdbb9a'}" stroke-width="${f1(w)}" stroke-linecap="round" fill="none" opacity="${f1(lt ? 0.35 : 0.22)}"/>`); }).join('') + '</g>';
      up += rep(40, () => `<ellipse cx="${f1(R() * 80)}" cy="${f1(R() * 56)}" rx="${f1(0.3 + R() * 0.9)}" ry="0.18" fill="#ffffff" opacity="${f1(0.2 + R() * 0.3)}"/>`).join('');
      let s = up, b = `<rect y="${BT}" width="80" height="${f1(BB - BT)}" fill="url(#kcb)"/>` + lblot('kc61b', 26, ['#d8996c', '#93502e', '#e8b07e', '#7a3e24', '#c07850', '#b88a5a'], 0.4, 3.4, BT, BB);
      let dk = '', lt = '';
      for (let y = BT - 0.4, j = 0; y < BB + 1.2; y += 1.42, j++) for (let x = (j % 2) * 0.82; x < 80; x += 1.64) { const px = x + (R() - 0.5) * 0.6, py = y + (R() - 0.5) * 0.5, r = 0.85 + R() * 0.35, o1 = f1(0.25 + R() * 0.25), o2 = f1(0.25 + R() * 0.3);
        dk += wrapX(px, r, xx => `<ellipse cx="${f1(xx - r * 0.28)}" cy="${f1(py - r * 0.3)}" rx="${f1(r * 0.62)}" ry="${f1(r * 0.5)}" opacity="${o1}"/>`); lt += wrapX(px, r, xx => `<ellipse cx="${f1(xx + r * 0.3)}" cy="${f1(py + r * 0.32)}" rx="${f1(r * 0.55)}" ry="${f1(r * 0.42)}" opacity="${o2}"/>`); }
      b += `<g filter="url(#kcf)"><g fill="#5a2a12">${dk}</g><g fill="#ffd2a2">${lt}</g></g>`;
            [0, 20, 40, 60, 80].forEach(x => { b += `<rect x="${x - 0.45}" y="${BT}" width="0.9" height="${f1(BB - BT)}" fill="url(#kcs)"/><rect x="${f1(x + 0.45)}" y="${BT}" width="0.5" height="${f1(BB - BT)}" fill="#5a2c14" opacity="0.25" filter="url(#wb1)"/>`;
        for (let y = BT + 1.6; y < BB; y += 3.2) b += `<circle cx="${f1(x + 0.15)}" cy="${f1(y + 0.15)}" r="0.42" fill="#4a2410" opacity="0.35"/><circle cx="${x}" cy="${f1(y)}" r="0.36" fill="url(#kcr)"/>`; });
            b += outlet(67.4, 44.2, '#c27a48', '#3a1c0c') + '<rect x="67.4" y="44.2" width="1.5" height="2.3" rx="0.22" fill="url(#kcg2)"/>';
      s += `<g clip-path="url(#kcc)">${b}</g>`;
      s += `<rect y="${f1(BT + 0.5)}" width="80" height="1" fill="#3a1a08" opacity="0.3" filter="url(#wb1)"/><rect y="${f1(BT - 1.1)}" width="80" height="1.6" rx="0.8" fill="url(#kch)"/><rect y="${f1(BT - 0.85)}" width="80" height="0.2" fill="#ffe6c4" opacity="0.9"/>`;
      const board = '#4e3b2a';
      return { mat: s, sup: up, smat: up, board,
        defs: bandC('kcc') + '<filter id="kcf" x="-5%" y="-5%" width="110%" height="110%"><feGaussianBlur stdDeviation="0.2"/></filter><linearGradient id="kcb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c07a50"/><stop offset="0.5" stop-color="#a9623c"/><stop offset="1" stop-color="#8a4c2c"/></linearGradient>'
          + '<radialGradient id="kcd" cx="50%" cy="50%" r="50%" fx="62%" fy="64%"><stop offset="0" stop-color="#c47646" stop-opacity="0"/><stop offset="0.45" stop-color="#e8a878" stop-opacity="0.35"/><stop offset="0.78" stop-color="#ffd2a4" stop-opacity="0.75"/><stop offset="0.86" stop-color="#8a4626" stop-opacity="0.65"/><stop offset="1" stop-color="#5e2e14" stop-opacity="0"/></radialGradient>'
          + '<radialGradient id="kcr" cx="35%" cy="32%" r="70%"><stop offset="0" stop-color="#ffe2bc"/><stop offset="0.5" stop-color="#c87a48"/><stop offset="1" stop-color="#6e3a1e"/></radialGradient>'
          + '<linearGradient id="kcs" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8a4a28"/><stop offset="0.4" stop-color="#f2b482"/><stop offset="0.7" stop-color="#c47646"/><stop offset="1" stop-color="#7a3e20"/></linearGradient>'
          + '<linearGradient id="kch" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd8a8"/><stop offset="0.35" stop-color="#e09460"/><stop offset="0.7" stop-color="#a85c32"/><stop offset="1" stop-color="#6e3a1e"/></linearGradient>'
          + '<linearGradient id="kcg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffe0b0" stop-opacity="0"/><stop offset="0.5" stop-color="#ffe0b0" stop-opacity="0.32"/><stop offset="1" stop-color="#ffe0b0" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="kcg2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd8a8" stop-opacity="0.6"/><stop offset="1" stop-color="#6e3a1e" stop-opacity="0.3"/></linearGradient>',
        ro: { top: 0.06, ao: 0.14, board: capB(board, 1.3) + rep(5, i => `<path d="M0 ${f1(BB - 1.1 + i * 0.22)}H80" stroke="#2e2216" stroke-width="0.06" opacity="0.4"/>`).join('') + scf('kcb2', 8, '#2e2216', '#7a624a') } }; });

    // KIT-081 book-matched Patagonia quartzite, floor to ceiling, lit from behind: milky quartz with clusters of black, smoky grey, caramel and white
    // crystals (left half drawn, right half mirrored at the middle seam), brass hairline seams, breathing backlight; a frameless smoked-glass recipe display
    // set into the stone that pages through 3 recipes (title, ingredients, step + progress, timer ring, tap ripple); bronze plinth with a champagne light line
    const kQtz = memo('k81', () => { const R = rng('kq81');
      let h = '<rect width="40" height="56" fill="#efe8db"/>' + `<g clip-path="url(#kqh)">` + lblot('kq81', 18, ['#f8f4ec', '#e6dcc8', '#f2ead8'], 0.6, 4, -2, 58);
      const CL = [[9, 8, 6, 'a'], [27, 15, 5, 'd'], [6, 29, 7, 'd'], [22, 34, 4, 'g'], [33, 42, 6, 'a'], [12, 47, 5, 'g'], [31, 4, 4, 'g'], [17, 21, 3.4, 'a'], [37, 26, 3, 'd'], [3, 52, 3.4, 'a']];
      const PAL = { a: ['#c48a4c', '#d9a868', '#a86a36', '#e8c58e', '#b47a40'], d: ['#2b2724', '#4f4740', '#6d655c', '#857b70', '#3a332e'], g: ['#8f877c', '#b3aca0', '#6e6760', '#cfc8bc'] };
      h += '<g filter="url(#wb2)">' + CL.map(([x, y, r, t]) => `<ellipse cx="${x}" cy="${y}" rx="${f1(r * 1.5)}" ry="${f1(r * 1.1)}" fill="${t === 'a' ? '#e0b070' : t === 'd' ? '#a89e94' : '#cdc5b8'}" opacity="${t === 'a' ? 0.4 : 0.26}"/>`).join('') + '</g>';
      const vein = (P, c, w, op) => `<path d="M${P.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L')}" stroke="${c}" stroke-width="${w}" fill="none" stroke-linejoin="round" opacity="${op}"/>`;
      const sv = (P, c, w, op) => { let d = 'M' + pt(P[0]); for (let j = 1; j < P.length - 1; j++) d += 'Q' + pt(P[j]) + ' ' + pt([(P[j][0] + P[j + 1][0]) / 2, (P[j][1] + P[j + 1][1]) / 2]); return `<path d="${d}L${pt(P[P.length - 1])}" stroke="${c}" stroke-width="${w}" fill="none" stroke-linecap="round" opacity="${op}"/>`; };
      for (let i = 0; i < CL.length - 1; i++) { const A = CL[i], B = CL[(i + 3) % CL.length], P = []; for (let j = 0; j <= 6; j++) { const t = j / 6; P.push([A[0] + (B[0] - A[0]) * t + (R() - 0.5) * 4, A[1] + (B[1] - A[1]) * t + (R() - 0.5) * 2.4]); }
        h += `<g filter="url(#wb1)">${sv(P, '#cfc3ae', 1.2, 0.35)}</g>` + sv(P, '#7a7064', f1(0.08 + R() * 0.14), 0.4) + sv(P.map(p => [p[0] + 0.25, p[1] + 0.18]), '#ffffff', 0.1, 0.55); }
      CL.forEach(([cx, cy, r, t]) => { const C = PAL[t]; h += '<g filter="url(#wb1)">' + rep(14, () => { const a = R() * 2 * PI, d = Math.pow(R(), 0.7) * r; return `<circle cx="${f1(cx + Math.cos(a) * d * 1.3)}" cy="${f1(cy + Math.sin(a) * d)}" r="${f1(0.5 + R() * 1.1)}" fill="${C[Math.floor(R() * C.length)]}" opacity="0.35"/>`; }).join('') + '</g>';
        h += rep(Math.round(26 + r * 5), () => { const a = R() * 2 * PI, d = Math.pow(R(), 0.65) * r, x = cx + Math.cos(a) * d * 1.3, y = cy + Math.sin(a) * d, sz = 0.18 + R() * R() * (0.5 + r * 0.11) * (1.2 - d / r * 0.6), nv = 4 + Math.floor(R() * 3), a0 = R() * PI;
          const P = rep(nv, k => { const aa = a0 + k / nv * 2 * PI + (R() - 0.5) * 0.6, rr = sz * (0.55 + R() * 0.6); return [x + Math.cos(aa) * rr * 1.25, y + Math.sin(aa) * rr]; }), c = C[Math.floor(R() * C.length)], d2 = 'M' + P.map(pt).join('L') + 'Z';
          return (R() < 0.22 ? `<path d="${d2}" fill="#fbf8f0" opacity="0.7"/>` : `<path d="${d2}" fill="${c}" opacity="${f1(0.45 + R() * 0.4)}"/>`) + `<path d="M${pt(P[0])}L${pt(P[1])}" stroke="${shade(c, 1.45)}" stroke-width="0.08" opacity="0.6"/>` + (R() < 0.2 ? `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(sz * 0.18)}" fill="#ffffff" opacity="0.8"/>` : ''); }).join(''); });
      h += rep(120, () => `<circle cx="${f1(R() * 40)}" cy="${f1(R() * 56)}" r="${f1(0.06 + R() * 0.14)}" fill="${R() < 0.6 ? '#3a332e' : '#c48a4c'}" opacity="${f1(0.3 + R() * 0.4)}"/>`).join('') + '</g>';
      const half = `<g id="kqH">${h}</g>`;
      let stone = half + '<use href="#kqH" transform="translate(80 0) scale(-1 1)"/>'
        + `<rect width="80" height="56" fill="url(#kqg)" opacity="0.5">${an('opacity', '0.35;0.7;0.35', 9, 0, SPL(2))}</rect><rect width="80" height="56" fill="url(#kqs)"/>`
        + [0, 40, 80].map(x => `<rect x="${x - 0.22}" width="0.44" height="56" fill="url(#kqb)"/>`).join('');
      // recipe display
      const DX = 29, DY = 19.4, DW = 22, DH = 13;
      const RCP = [['Honey Cake', 'Step 2 of 5', '#f0c46a'], ['Lemon Pasta', 'Step 3 of 4', '#f3e27a'], ['Berry Tart', 'Step 1 of 6', '#e88a9a']];
      const ic = [`<ellipse cx="0" cy="0.6" rx="2.1" ry="1" fill="none" stroke="#f2d9a0" stroke-width="0.22"/><path d="M-2.1 0.6Q-2 2.6 0 2.8Q2 2.6 2.1 0.6" fill="none" stroke="#f2d9a0" stroke-width="0.22"/><path d="M-0.6 -1.8l0.8 2.2M0.8 -2l-0.4 2.4" stroke="#f0c46a" stroke-width="0.2"/>`,
        `<circle r="2.1" fill="none" stroke="#f2d9a0" stroke-width="0.22"/><path d="M-1.2 -0.4q0.6 -0.8 1.2 0t1.2 0M-1.3 0.6q0.6 -0.8 1.2 0t1.2 0" stroke="#f3e27a" stroke-width="0.2" fill="none"/>`,
        `<path d="M-2.2 0.4H2.2L1.6 2.2H-1.6Z" fill="none" stroke="#f2d9a0" stroke-width="0.22"/><circle cx="-0.9" cy="-0.2" r="0.5" fill="#e88a9a"/><circle cx="0.3" cy="-0.5" r="0.5" fill="#d0607a"/><circle cx="1.2" cy="-0.1" r="0.45" fill="#e88a9a"/>`];
      let pg = ''; RCP.forEach(([t, st, c], i) => { const ov = ['1;1;0;0;0;0;1', '0;0;1;1;0;0;0', '0;0;0;0;1;1;0'][i];
        pg += `<g opacity="${i ? 0 : 1}">${an('opacity', ov, 30, 0, ' keyTimes="0;0.3;0.333;0.633;0.667;0.967;1"')}<g transform="translate(${DX + 3.6} ${DY + 4.6})">${ic[i]}</g><text x="${DX + 7}" y="${DY + 3.8}" font-family="Georgia,'Times New Roman',serif" font-size="2" fill="#f6e4b8" font-style="italic">${t}</text><text x="${DX + 7}" y="${DY + 5.6}" font-family="Arial,Helvetica,sans-serif" font-size="0.9" fill="#c9b48a" letter-spacing="0.08">${st.toUpperCase()}</text>`
          + rep(4, k => `<circle cx="${DX + 7.3}" cy="${f1(DY + 7.2 + k * 1.15)}" r="0.2" fill="${c}"/><rect x="${DX + 8}" y="${f1(DY + 6.95 + k * 1.15)}" width="${f1(5 + ((k * 7 + i * 3) % 6))}" height="0.45" rx="0.22" fill="#e9d6aa" opacity="0.55"/>`).join('')
          + `<rect x="${DX + 1.4}" y="${DY + DH - 1.6}" width="${DW - 2.8}" height="0.35" rx="0.17" fill="#ffffff" opacity="0.12"/><rect x="${DX + 1.4}" y="${DY + DH - 1.6}" width="1" height="0.35" rx="0.17" fill="${c}">${an('width', `1;${DW - 2.8}`, 10, i * 10)}</rect></g>`; });
      const disp = `<rect x="${DX - 0.5}" y="${DY - 0.5}" width="${DW + 1}" height="${DH + 1}" rx="0.9" fill="#000000" opacity="0.3" filter="url(#wb1)"/><rect x="${DX - 0.25}" y="${DY - 0.25}" width="${DW + 0.5}" height="${DH + 0.5}" rx="0.8" fill="url(#kqb)"/><rect x="${DX}" y="${DY}" width="${DW}" height="${DH}" rx="0.6" fill="#17130e"/><rect x="${DX}" y="${DY}" width="${DW}" height="${DH}" rx="0.6" fill="url(#kqd)"/>`
        + pg + `<g transform="translate(${DX + DW - 2.4} ${DY + 2.4})"><circle r="1.3" fill="none" stroke="#ffffff" stroke-width="0.2" opacity="0.15"/><circle r="1.3" fill="none" stroke="#f0c46a" stroke-width="0.22" stroke-dasharray="8.17" stroke-dashoffset="0" transform="rotate(-90)">${an('stroke-dashoffset', '0;8.17', 10)}</circle><text y="0.32" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="0.85" fill="#f6e4b8">12</text></g>`
        + `<circle cx="${DX + 15}" cy="${DY + 9}" r="0.4" fill="none" stroke="#ffffff" stroke-width="0.16" opacity="0">${an('r', '0.4;0.4;3', 10, 9.4, ' keyTimes="0;0.9;1"')}${an('opacity', '0;0;0.6;0', 10, 9.4, ' keyTimes="0;0.9;0.92;1"')}</circle>`
        + `<path d="M${DX + 0.6} ${DY + 0.6}H${DX + 9}L${DX + 4} ${DY + DH - 0.6}H${DX + 0.6}Z" fill="#ffffff" opacity="0.06"/>`
        + `<g filter="url(#wb2)"><rect x="${DX - 1.5}" y="${DY + DH}" width="${DW + 3}" height="2.4" fill="#ffd89a" opacity="0.2"/></g>`;
      const board = '#7c5c30';
      return { mat: stone, one: disp, sup: stone, smat: stone, board,
        defs: '<clipPath id="kqh"><rect width="40" height="56"/></clipPath><radialGradient id="kqg" cx="50%" cy="45%" r="65%"><stop offset="0" stop-color="#fff2d0" stop-opacity="0.5"/><stop offset="1" stop-color="#ffe2a8" stop-opacity="0"/></radialGradient>'
          + '<linearGradient id="kqs" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.14"/><stop offset="0.4" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#5a4020" stop-opacity="0.08"/></linearGradient>'
          + '<linearGradient id="kqb" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset="0.4" stop-color="#d8ac58"/><stop offset="1" stop-color="#8a6420"/></linearGradient>'
          + '<linearGradient id="kqd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2c1a" stop-opacity="0.6"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.04, ao: 0.1, board: `<rect y="${BB}" width="80" height="0.4" fill="#f2d58a"/><rect y="${f1(BB + 0.4)}" width="80" height="0.3" fill="#fff0c0" opacity="0.7"/>` + rep(16, i => `<rect x="${f1(i * 5 + 1)}" y="${f1(BB + 1)}" width="3" height="0.9" rx="0.2" fill="#5a3e1a" opacity="0.6"/>`).join('') + `<rect y="${f1(56 - 0.4)}" width="80" height="0.4" fill="#ffe2a0" opacity="0.6">${an('opacity', '0.45;0.75;0.45', 6, 0, SPL(2))}</rect>` } }; });

    Object.assign(SURF12, { k01dry: kDry, k21vin: kVinyl, k41herr: kHerr, k61cop: kCop, k81qtz: kQtz });
    // walls with a one-off feature (S.one, e.g. the recipe display): the room tile (res.svg) repeats without it, the card (res.src) shows it,
    // res.wallOne = 80 x 56 overlay drawn ONCE, centred on the back wall (Squad House v6 rt.wallOne, catalog test room wallBg)
    const draw27w = RD.draw;
    RD.draw = (r, o) => { const res = draw27w(r, o); if (!res || !res.tile || !r.s12 || res._one) return res;
      try { const f = SURF12[r.s12], S = f && f(); if (S && S.one) { res._one = 1;
        const M = WMEMO27[r.s12 + '|one'] || (WMEMO27[r.s12 + '|one'] = { card: 'data:image/svg+xml,' + encodeURIComponent(RD.svgDoc('0 0 80 56', [], RD.H12.tile(Object.assign({}, S, { mat: S.mat + S.one })))),
          one: 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 56" preserveAspectRatio="none"><defs><filter id="wb2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.3"/></filter><filter id="wb1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.45"/></filter>' + (S.defs || '') + '</defs>' + S.one + '</svg>') });
        res.src = M.card; res.wallOne = M.one; } } catch (e) { console.warn('reno plus27 wallOne', r.id, e); }
      return res; };
  }


  // ======================= KITCHEN WINDOWS (front-on art the house shell draws in its window slot, like the Living Room windows in plus19) =======================
  // functions added to RD.H19.WIN19 (key k*), row r.w19 = key; vb = room px around winX (y 0 = 50 px below the wall top, wall bottom y 100)
  { const WIN = RD.H19.WIN19;
    const WDEF = '<filter id="b1" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="0.6"/></filter><filter id="b2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.6"/></filter>'
      + '<linearGradient id="gref" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.22"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0.02"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.1"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>'
      + '<linearGradient id="tc" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8e4426"/><stop offset="0.35" stop-color="#d4804e"/><stop offset="0.6" stop-color="#c06a3e"/><stop offset="1" stop-color="#7e3a20"/></linearGradient>';
    const bev = (x, y, w, h, c, t) => '<rect x="' + f1(x) + '" y="' + f1(y) + '" width="' + f1(w) + '" height="' + f1(h) + '" fill="' + c + '"/><path d="M' + f1(x) + ' ' + f1(y) + 'h' + f1(w) + 'l' + (-t) + ' ' + t + 'h' + f1(-(w - 2 * t)) + 'v' + f1(h - 2 * t) + 'l' + (-t) + ' ' + t + 'Z" fill="#ffffff" opacity="0.38"/><path d="M' + f1(x + w) + ' ' + f1(y + h) + 'h' + f1(-w) + 'l' + t + ' ' + (-t) + 'h' + f1(w - 2 * t) + 'v' + f1(-(h - 2 * t)) + 'l' + t + ' ' + (-t) + 'Z" fill="#000000" opacity="0.2"/>';
    const ring = (x0, y0, x1, y1, t, c, e) => bev(x0, y0, x1 - x0, t, c, e) + bev(x0, y1 - t, x1 - x0, t, c, e) + bev(x0, y0 + t, t, y1 - y0 - 2 * t, c, e) + bev(x1 - t, y0 + t, t, y1 - y0 - 2 * t, c, e);
    const reveal = (x0, y0, x1, y1, d, c) => '<path d="M' + x0 + ' ' + y0 + 'H' + x1 + 'L' + (x1 - d) + ' ' + (y0 + d) + 'H' + (x0 + d) + 'Z" fill="' + shade(c, 0.62) + '"/><path d="M' + x0 + ' ' + y0 + 'L' + (x0 + d) + ' ' + (y0 + d) + 'V' + (y1 - d) + 'L' + x0 + ' ' + y1 + 'Z" fill="' + shade(c, 0.78) + '"/><path d="M' + x1 + ' ' + y0 + 'V' + y1 + 'L' + (x1 - d) + ' ' + (y1 - d) + 'V' + (y0 + d) + 'Z" fill="' + shade(c, 0.95) + '"/><path d="M' + x0 + ' ' + y1 + 'L' + (x0 + d) + ' ' + (y1 - d) + 'H' + (x1 - d) + 'L' + x1 + ' ' + y1 + 'Z" fill="' + shade(c, 1.06) + '"/>';
    const sill = (x0, x1, y, c, d) => '<rect x="' + x0 + '" y="' + (y + 2.6) + '" width="' + (x1 - x0) + '" height="2" fill="#000000" opacity="0.22" filter="url(#b1)"/><path d="M' + (x0 + d) + ' ' + (y - d) + 'H' + (x1 - d) + 'L' + x1 + ' ' + y + 'H' + x0 + 'Z" fill="' + shade(c, 1.08) + '"/><rect x="' + x0 + '" y="' + y + '" width="' + (x1 - x0) + '" height="3" fill="' + c + '"/><rect x="' + x0 + '" y="' + y + '" width="' + (x1 - x0) + '" height="0.4" fill="#ffffff" opacity="0.5"/><rect x="' + x0 + '" y="' + (y + 2.6) + '" width="' + (x1 - x0) + '" height="0.4" fill="#000000" opacity="0.2"/>';
    const cloud = (x, y, k, c) => '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') scale(' + n4(k) + ')"><ellipse cx="0.6" cy="1.4" rx="7" ry="2.2" fill="' + shade(c, 0.86) + '"/><ellipse rx="7" ry="2.6" fill="' + c + '"/><circle cx="-3" cy="-1.6" r="3" fill="' + c + '"/><circle cx="1.4" cy="-2.8" r="3.8" fill="' + c + '"/><circle cx="4.8" cy="-0.9" r="2.5" fill="' + c + '"/><circle cx="0.4" cy="-3.6" r="1.6" fill="#ffffff" opacity="0.6"/></g>';
    const drift = (q, w, d) => '<g>' + at('translate', '0 0;' + f1(w) + ' 0', d) + q + '<g transform="translate(' + f1(-w) + ' 0)">' + q + '</g></g>';
    const sway = (x, y, k, a, d, ph, inner) => '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') scale(' + n4(k) + ')"><g>' + at('rotate', (-a) + ' 0 0;' + a + ' 0 0;' + (-a) + ' 0 0', d, -ph, SPL(2)) + inner + '</g></g>';
    const tree = (x, y, k, c, ph) => sway(x, y, k, 0, 1, 0, '<path d="M-1 0L-0.7 -10H0.7L1 0Z" fill="#6a4a2e"/>') + sway(x, y - 8 * k, k, 2.5, 5 + ph, ph, '<circle cx="-3.6" cy="-3" r="4.6" fill="' + shade(c, 0.85) + '"/><circle cx="3.4" cy="-3.6" r="4.4" fill="' + shade(c, 0.9) + '"/><circle cy="-7" r="5.4" fill="' + c + '"/><circle cx="-1.6" cy="-8.6" r="2.2" fill="' + shade(c, 1.2) + '"/><circle cx="2.6" cy="-5" r="1.8" fill="' + shade(c, 1.12) + '"/>');
    const glassRef = (x, y, w, h) => '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="url(#gref)"/><path d="M' + f1(x + w * 0.2) + ' ' + y + 'L' + f1(x + w * 0.05) + ' ' + (y + h) + 'H' + f1(x + w * 0.12) + 'L' + f1(x + w * 0.27) + ' ' + y + 'Z" fill="#ffffff" opacity="0.08"/>';
    const pot = (x, y, w, h, rim) => { const t = w * 0.8; return '<ellipse cx="' + f1(x) + '" cy="' + f1(y + h) + '" rx="' + f1(w * 0.55) + '" ry="' + f1(w * 0.12) + '" fill="#000000" opacity="0.28" filter="url(#b1)"/><path d="M' + f1(x - w / 2) + ' ' + f1(y) + 'L' + f1(x - t / 2) + ' ' + f1(y + h) + 'H' + f1(x + t / 2) + 'L' + f1(x + w / 2) + ' ' + f1(y) + 'Z" fill="url(#tc)"/>'
      + '<rect x="' + f1(x - w / 2 - w * 0.06) + '" y="' + f1(y - h * 0.2) + '" width="' + f1(w * 1.12) + '" height="' + f1(h * 0.24) + '" rx="' + f1(w * 0.04) + '" fill="' + (rim || '#c8744a') + '"/><rect x="' + f1(x - w / 2 - w * 0.06) + '" y="' + f1(y - h * 0.2) + '" width="' + f1(w * 1.12) + '" height="' + f1(h * 0.06) + '" fill="#f0b088" opacity="0.7"/><rect x="' + f1(x - w / 2) + '" y="' + f1(y + h * 0.04) + '" width="' + f1(w) + '" height="' + f1(h * 0.08) + '" fill="#000000" opacity="0.18"/>'
      + '<ellipse cx="' + f1(x - w * 0.18) + '" cy="' + f1(y + h * 0.55) + '" rx="' + f1(w * 0.08) + '" ry="' + f1(h * 0.25) + '" fill="#f4b890" opacity="0.35"/><ellipse cx="' + f1(x + w * 0.2) + '" cy="' + f1(y + h * 0.7) + '" rx="' + f1(w * 0.12) + '" ry="' + f1(h * 0.12) + '" fill="#e8e4d4" opacity="0.25"/>'; };
    // herbs (base at 0 0, grow up), drawn in a unit of ~10 tall
    const HB = {
      basil: () => { let o = ''; [[-2.4, -3, -40], [2.4, -3.4, 40], [-1.6, -6, -25], [1.8, -6.4, 25], [0, -8.8, 0], [-3.2, -1.4, -70], [3.2, -1.6, 70], [-0.6, -4.6, -8]].forEach(([x, y, a], i) => o += '<path d="M0 0Q' + f1(x * 0.3) + ' ' + f1(y * 0.6) + ' ' + f1(x * 0.8) + ' ' + f1(y * 0.9) + '" stroke="#4a7e32" stroke-width="0.3" fill="none"/><g transform="translate(' + x + ' ' + y + ') rotate(' + a + ')"><ellipse rx="1.5" ry="2.3" fill="' + (i % 3 ? '#5fae42' : '#4e9a36') + '"/><path d="M0 2.1V-2" stroke="#88c86a" stroke-width="0.18"/><ellipse cx="-0.5" cy="-0.6" rx="0.5" ry="1" fill="#9ad47a" opacity="0.5"/></g>'); return o; },
      rose: () => { let o = ''; [-24, -11, 0, 12, 25].forEach((a, i) => { const L = 9 + (i % 2) * 2, r = a * PI / 180; let d = ''; for (let t = 1.4; t < L; t += 0.8) { const x = Math.sin(r) * t, y = -Math.cos(r) * t; d += 'M' + f1(x) + ' ' + f1(y) + 'l' + f1(-1.1 * Math.cos(r) - 0.5 * Math.sin(r)) + ' ' + f1(-1.1 * Math.sin(r) + 0.5 * Math.cos(r) - 0.6) + 'M' + f1(x) + ' ' + f1(y) + 'l' + f1(1.1 * Math.cos(r) - 0.5 * Math.sin(r)) + ' ' + f1(1.1 * Math.sin(r) - 0.5 * Math.cos(r) + 0.2 - 0.6) + ''; }
        o += '<path d="M0 0L' + f1(Math.sin(r) * L) + ' ' + f1(-Math.cos(r) * L) + '" stroke="#6a5a3e" stroke-width="0.35"/><path d="' + d + '" stroke="' + (i % 2 ? '#47664c' : '#56785a') + '" stroke-width="0.34" stroke-linecap="round"/>'; }); return o; },
      chive: () => { let o = ''; for (let i = 0; i < 12; i++) { const a = (i - 5.5) * 0.12, L = 8 + (i * 7 % 4); o += '<path d="M' + f1((i - 5.5) * 0.25) + ' 0Q' + f1(Math.sin(a) * L * 0.5) + ' ' + f1(-L * 0.6) + ' ' + f1(Math.sin(a) * L) + ' ' + f1(-L) + '" stroke="' + (i % 3 ? '#5c9a3c' : '#4c8a30') + '" stroke-width="0.42" fill="none" stroke-linecap="round"/>'; }
        [[-1.6, -10.2], [1.4, -11]].forEach(([x, y]) => o += '<circle cx="' + x + '" cy="' + y + '" r="1.3" fill="#b07ac2"/><circle cx="' + (x - 0.4) + '" cy="' + (y - 0.4) + '" r="0.6" fill="#d4a8e0"/>'); return o; },
      thyme: () => { const Q = rng('thy'); let o = ''; for (let i = 0; i < 46; i++) { const a = PI * (0.08 + 0.84 * Q()), d = Math.sqrt(Q()) * 4.6; o += '<circle cx="' + f1(-Math.cos(a) * d * 1.2) + '" cy="' + f1(-Math.sin(a) * d) + '" r="' + f1(0.42 + Q() * 0.3) + '" fill="' + (Q() < 0.5 ? '#6f8f4a' : '#8aa65a') + '"/>'; }
        for (let i = 0; i < 6; i++) o += '<circle cx="' + f1((Q() - 0.5) * 8) + '" cy="' + f1(-2.5 - Q() * 2.4) + '" r="0.35" fill="#e2b8d8"/>'; return o; },
      mint: () => { let o = ''; [[-2.6, -2.6, -45], [2.6, -2.8, 45], [-1.4, -6.2, -20], [1.6, -6.6, 22], [0, -9.4, 0], [-3.4, -5, -55]].forEach(([x, y, a]) => o += '<path d="M0 0L' + f1(x * 0.7) + ' ' + f1(y * 0.8) + '" stroke="#5a8a3a" stroke-width="0.35"/><g transform="translate(' + x + ' ' + y + ') rotate(' + a + ')"><ellipse rx="1.8" ry="2.4" fill="#72c46a"/><ellipse rx="1.8" ry="2.4" fill="none" stroke="#a8e0a0" stroke-width="0.25" stroke-dasharray="0.5 0.4"/><path d="M0 2.2V-2.2M0 -0.4l-1 -0.8M0 0.6l1 -0.8" stroke="#4a8a40" stroke-width="0.16"/></g>'); return o; },
      pars: () => { let o = ''; [[-3, -6], [-1.2, -8.6], [1, -9], [3, -6.4], [0, -5]].forEach(([x, y], i) => { o += '<path d="M0 0Q' + f1(x * 0.4) + ' ' + f1(y * 0.5) + ' ' + x + ' ' + y + '" stroke="#4e8a36" stroke-width="0.3" fill="none"/>';
        [[0, 0], [-1, 0.5], [1, 0.4], [-0.5, -0.9], [0.6, -0.8], [0, 1]].forEach(([dx, dy]) => o += '<circle cx="' + f1(x + dx * 1.2) + '" cy="' + f1(y + dy * 1.1) + '" r="0.85" fill="' + (i % 2 ? '#3f8f3a' : '#4a9c42') + '"/>'); o += '<circle cx="' + (x - 0.4) + '" cy="' + (y - 0.6) + '" r="0.4" fill="#8fcf70" opacity="0.6"/>'; }); return o; },
    };
    const herb = (k, x, y, sc, ph) => sway(x, y, sc, 2.2 + (ph % 1.3), 4.2 + ph * 0.7, ph, HB[k]());

    // KIT-012 tiny basement hopper window, high on the wall: chipped steel frame, deep concrete reveal, tilted-in sash on 2 friction arms,
    // rusty torn insect screen, grimy glass, ground-level view (grass + dandelion sway, a pigeon struts by, snail creeps), rust streaks, cobweb, dead fly
    WIN.khop = () => { const FC = '#7a8270', R = rng('khop'), GX = 25.6, GY0 = -27.6, GY1 = -8.4;
      let s = '<defs>' + WDEF + '<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c3ccce"/><stop offset="1" stop-color="#e4e6da"/></linearGradient><linearGradient id="gr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8a8468" stop-opacity="0.05"/><stop offset="1" stop-color="#6a6248" stop-opacity="0.4"/></linearGradient>'
        + '<pattern id="ms" width="0.7" height="0.7" patternUnits="userSpaceOnUse"><path d="M0 0.35H0.7M0.35 0V0.7" stroke="#5a4030" stroke-width="0.1" stroke-opacity="0.55"/></pattern><clipPath id="gc"><rect x="' + (-GX) + '" y="' + GY0 + '" width="' + (2 * GX) + '" height="' + (GY1 - GY0) + '"/></clipPath><clipPath id="sc"><path d="M-25.6 -27.6H18L25.6 -21V-8.4H-25.6Z"/></clipPath></defs>';
      s += '<g filter="url(#b2)"><path d="M-22 -2Q-21 3 -22.6 7M-8 -2Q-7.4 2 -8.6 5M14 -2Q15 4 13.6 8M26 -2Q26.6 1 25.8 4" stroke="#9a5a2a" stroke-width="1.6" fill="none" opacity="0.45"/></g><path d="M-22 -2Q-21 3 -22.6 7M14 -2Q15 4 13.6 8" stroke="#7a3e18" stroke-width="0.4" fill="none" opacity="0.5"/>';
      s += '<rect x="-34" y="-36" width="68" height="36" fill="#000000" opacity="0.2" filter="url(#b2)"/>' + ring(-33, -35, 33, -1.6, 3.4, FC, 0.8) + reveal(-29.6, -31.6, 29.6, -5, 3.4, '#a19b90');
      let sc = '<rect x="-27" y="-29" width="54" height="22" fill="url(#k)"/>' + drift(cloud(-14, -25, 0.7, '#eef0ee') + cloud(12, -26.4, 0.5, '#e8ebea'), 54, 52);
      sc += '<path d="M-27 -17Q-14 -18.4 0 -17.2T27 -17.6V-7H-27Z" fill="#5a4632"/><path d="M-27 -14Q-10 -15 4 -14.2T27 -14.6V-7H-27Z" fill="#4a3826"/>' + rep(16, () => '<circle cx="' + f1(-27 + R() * 54) + '" cy="' + f1(-14 + R() * 6) + '" r="' + f1(0.3 + R() * 0.5) + '" fill="' + (R() < 0.5 ? '#6e5a44' : '#3a2c1e') + '"/>').join('');
      // pigeon struts along the soil edge, head bobbing; snail creeps
      sc += '<g>' + at('translate', '-40 0;-40 0;40 0;40 0', 26, 0, ' keyTimes="0;0.35;0.85;1"') + '<g transform="translate(0 -17.2)"><path d="M0 0l-0.4 1.4M1 0l0.4 1.4" stroke="#d07a7a" stroke-width="0.3"/><ellipse cy="-1.6" rx="2.6" ry="1.7" fill="#8a8e98"/><path d="M-2.4 -1.8L-4.4 -1.2L-2.2 -0.6Z" fill="#5a5e68"/><path d="M-1.2 -2.2Q0 -2.8 1.2 -2" stroke="#6a6e78" stroke-width="0.5" fill="none"/>'
        + '<g>' + at('translate', '0 0;0.6 0.5;0 0', 0.6) + '<path d="M1.4 -2.4Q2.2 -3.4 2.4 -4" stroke="#5a8a7a" stroke-width="1.1" fill="none"/><circle cx="2.6" cy="-4.4" r="0.95" fill="#7a7e88"/><circle cx="2.9" cy="-4.6" r="0.2" fill="#e88a30"/><path d="M3.4 -4.3l0.7 0.2l-0.7 0.2Z" fill="#3a3a3a"/></g></g></g>';
      sc += '<g>' + at('translate', '-20 0;20 0', 70) + '<g transform="translate(0 -16.6)"><path d="M-1.4 0H1.6Q2.2 -0.6 2 -1" stroke="#a89a7a" stroke-width="0.6" fill="none" stroke-linecap="round"/><circle cx="-0.2" cy="-0.9" r="1" fill="#9a6a3a"/><path d="M-0.2 -0.9m-0.5 0a0.5 0.5 0 1 1 0.7 0.3" stroke="#6a4420" stroke-width="0.2" fill="none"/><path d="M1.9 -1l0.4 -0.7M2.1 -0.9l0.6 -0.4" stroke="#a89a7a" stroke-width="0.12"/></g></g>';
      // grass + dandelion
      for (let i = 0; i < 26; i++) { const x = -26 + i * 2.05 + R(), h = 2.5 + R() * 5.5, b = (R() - 0.5) * 2; sc += sway(x, -16.4 + R() * 0.8, 1, 4 + R() * 3, 2.6 + R() * 2, R() * 3, '<path d="M-0.35 0Q' + f1(b * 0.5) + ' ' + f1(-h * 0.6) + ' ' + f1(b) + ' ' + f1(-h) + 'Q' + f1(b * 0.4 + 0.3) + ' ' + f1(-h * 0.5) + ' 0.35 0Z" fill="' + (i % 3 ? '#6e9a48' : '#5a8a3a') + '"/>'); }
      sc += sway(-9, -16, 1, 5, 3.4, 0.4, '<path d="M0 0Q0.6 -4 0.2 -8" stroke="#7a9a4a" stroke-width="0.3" fill="none"/><circle cx="0.2" cy="-8.6" r="1.9" fill="#ffffff" opacity="0.55"/>' + rep(12, i => '<path d="M0.2 -8.6l' + f1(1.8 * Math.cos(i * PI / 6)) + ' ' + f1(1.8 * Math.sin(i * PI / 6)) + '" stroke="#ffffff" stroke-width="0.1" opacity="0.8"/>').join('') + '<circle cx="0.2" cy="-8.6" r="0.4" fill="#b8a878"/>');
      sc += sway(17, -16.2, 1, 3, 4, 1, '<path d="M0 0V-4.6" stroke="#6a8a3a" stroke-width="0.3"/>' + rep(10, i => '<ellipse cx="' + f1(0.9 * Math.cos(i * PI / 5)) + '" cy="' + f1(-5.2 + 0.9 * Math.sin(i * PI / 5)) + '" rx="0.55" ry="0.3" transform="rotate(' + (i * 36) + ' ' + f1(0.9 * Math.cos(i * PI / 5)) + ' ' + f1(-5.2 + 0.9 * Math.sin(i * PI / 5)) + ')" fill="#f2c83a"/>').join('') + '<circle cy="-5.2" r="0.55" fill="#d89a2a"/>');
      // screen: rust mesh, torn top-right corner curling away
      sc += '<g clip-path="url(#sc)"><rect x="-26" y="-28" width="52" height="20" fill="url(#ms)"/><rect x="-26" y="-28" width="52" height="20" fill="#6a4a30" opacity="0.1"/>' + lblotW(R) + '</g><path d="M18 -27.6L25.6 -21L21.8 -22.4Q19.6 -25 18 -27.6Z" fill="url(#ms)" stroke="#6a4a30" stroke-width="0.12"/><path d="M18 -27.6L25.6 -21" stroke="#5a4030" stroke-width="0.12" stroke-dasharray="0.3 0.25"/>';
      s += '<g clip-path="url(#gc)">' + sc + '<rect x="-27" y="-29" width="54" height="22" fill="url(#gr)"/><rect x="-27" y="-29" width="54" height="22" fill="#a49c7c" opacity="0.14"/>' + glassRef(-25.6, -27.6, 51.2, 19.2)
        + rep(7, () => { const x = -24 + R() * 48; return '<path d="M' + f1(x) + ' -27.4Q' + f1(x + 0.3) + ' -20 ' + f1(x - 0.2) + ' ' + f1(-14 + R() * 5) + '" stroke="#8a7e5a" stroke-width="' + f1(0.3 + R() * 0.4) + '" fill="none" opacity="0.18"/>'; }).join('') + '</g>';
      // hopper sash tilted in at the top: dark air gap above the top rail, friction arms
      s += '<rect x="-25.6" y="-27.6" width="51.2" height="1.4" fill="#2a2a24" opacity="0.5"/>' + ring(-26.2, -26.4, 26.2, -8, 1.9, shade(FC, 0.95), 0.5) + bev(-26.6, -27.4, 53.2, 2.4, shade(FC, 1.05), 0.5);
      [-24.4, 24.4].forEach(x => s += '<path d="M' + x + ' -26L' + f1(x * 1.06) + ' -29.2" stroke="#4a4a44" stroke-width="0.55"/><circle cx="' + x + '" cy="-26" r="0.4" fill="#3a3a34"/>');
      s += '<g transform="translate(0 -26.2)"><rect x="-2.4" y="-0.8" width="4.8" height="1.6" rx="0.4" fill="#8a7a5a"/><path d="M-1.6 0.8Q0 2.4 1.6 0.8" stroke="#6a5a3a" stroke-width="0.6" fill="none"/><circle r="0.35" fill="#4a3a20"/></g>';
      s += rep(18, () => { const side = R(), x = side < 0.5 ? -33 + R() * 66 : (R() < 0.5 ? -32.4 + R() * 2.4 : 30 + R() * 2.4), y = side < 0.5 ? (R() < 0.5 ? -34.6 + R() * 2.6 : -4.6 + R() * 2.6) : -32 + R() * 28; return '<path d="M' + f1(x) + ' ' + f1(y) + 'l' + f1(0.5 + R() * 0.8) + ' 0.2l-0.2 ' + f1(0.5 + R() * 0.5) + 'l' + f1(-0.6 - R() * 0.8) + ' -0.2Z" fill="' + (R() < 0.5 ? '#8a5a32' : '#9a948a') + '" opacity="0.85"/>'; }).join('');
      s += '<path d="M-29.4 -31.4L-22 -31.4M-29.4 -31.4L-29.4 -24.6M-29.4 -31.4L-23.4 -26.2M-27 -31.4Q-27.4 -29 -29.4 -28.6M-24.6 -31.4Q-25.6 -27.6 -29.4 -26.6" stroke="#ffffff" stroke-width="0.1" fill="none" opacity="0.6"/>';
      s += sill(-35, 35, -1.6, '#aaa49a', 1.2) + '<g transform="translate(8 -2)"><ellipse rx="0.7" ry="0.35" fill="#2a2a26"/><path d="M-0.2 -0.2l-0.8 -0.6M0.2 -0.2l0.8 -0.6" stroke="#b8c4c8" stroke-width="0.35" opacity="0.7"/></g>';
      return { vb: [-36, -38, 72, 44], s }; };
    function lblotW(R) { return '<g filter="url(#b1)">' + rep(9, () => '<ellipse cx="' + f1(-24 + R() * 48) + '" cy="' + f1(-27 + R() * 18) + '" rx="' + f1(1 + R() * 2.4) + '" ry="' + f1(0.6 + R()) + '" fill="#8a4a20" opacity="0.28"/>').join('') + '</g>' + '<path d="M-6 -20.4q0.8 -0.6 1.4 0.2t1.2 0.4M10 -12.8q0.6 0.8 1.4 0" stroke="#3a2a1a" stroke-width="0.14" fill="none"/><ellipse cx="-4.8" cy="-20" rx="1.2" ry="0.9" fill="#1e1a14" opacity="0.5"/>'; }

    // KIT-032 white double-hung window with red gingham cafe curtains: valance, brass tension rod + rings, curtains sway, sash lock + lift handles,
    // sunny backyard with laundry on a line swaying, a maple + swinging bird feeder (a bird visits), geranium pot + glass suncatcher throwing rainbow spots
    WIN.kging = () => { const FC = '#fbf8f1', R = rng('kgn');
      let s = '<defs>' + WDEF + '<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fbbe8"/><stop offset="1" stop-color="#d6eefa"/></linearGradient><radialGradient id="sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff8d0"/><stop offset="0.35" stop-color="#fff0a0" stop-opacity="0.7"/><stop offset="1" stop-color="#fff0a0" stop-opacity="0"/></radialGradient>'
        + '<pattern id="gh" width="2.4" height="2.4" patternUnits="userSpaceOnUse"><rect width="2.4" height="2.4" fill="#fbf6f0"/><rect width="1.2" height="2.4" fill="#d83a3a" opacity="0.5"/><rect width="2.4" height="1.2" fill="#d83a3a" opacity="0.5"/></pattern>'
        + '<pattern id="fo" width="5" height="40" patternUnits="userSpaceOnUse"><rect width="5" height="40" fill="url(#fg)"/></pattern><linearGradient id="fg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000000" stop-opacity="0.2"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.22"/></linearGradient>'
        + '<linearGradient id="br" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset="0.5" stop-color="#d8a848"/><stop offset="1" stop-color="#8a6420"/></linearGradient><clipPath id="gc"><rect x="-36.6" y="-4.6" width="73.2" height="62.6"/></clipPath></defs>';
      s += '<rect x="-42" y="-11" width="88" height="80" fill="#000000" opacity="0.18" filter="url(#b2)"/>' + ring(-43, -11, 43, 63, 5, FC, 1.2) + bev(-46, -15, 92, 4.6, FC, 0.8) + reveal(-38, -6, 38, 63, 1.4, '#e3ddd0');
      let sc = '<rect x="-37" y="-5" width="74" height="64" fill="url(#k)"/><circle cx="-22" cy="2" r="14" fill="url(#sun)"/><circle cx="-22" cy="2" r="3.8" fill="#fff6c8"/>' + drift(cloud(-6, 8, 0.9, '#ffffff') + cloud(24, 3, 0.7, '#ffffff'), 74, 60);
      sc += '<path d="M-37 34Q-16 28 2 33T37 30V59H-37Z" fill="#a6d0a0"/><path d="M-37 42Q-8 37 14 42T37 40V59H-37Z" fill="#86b77e"/>';
      sc += rep(10, i => '<rect x="' + (-36 + i * 7.6) + '" y="35" width="2.2" height="11" fill="#f6f2e8"/><path d="M' + (-36 + i * 7.6) + ' 35l1.1 -1.4l1.1 1.4" fill="#f6f2e8"/>').join('') + '<rect x="-37" y="38" width="74" height="1.2" fill="#eeeae0"/><rect x="-37" y="43" width="74" height="1.2" fill="#eeeae0"/>';
      sc += tree(27, 42, 2, '#5f9a4e', 0.6);
      // bird feeder hanging from the maple, swinging; a bird visits
      sc += '<g transform="translate(20 14)"><g>' + at('rotate', '-6 0 0;6 0 0;-6 0 0', 3.6, 0, SPL(2)) + '<path d="M0 0V5" stroke="#6a5a40" stroke-width="0.2"/><path d="M-2.6 6.4L0 4.6L2.6 6.4Z" fill="#b8542e"/><rect x="-1.8" y="6.4" width="3.6" height="3.2" fill="#e8d8a8" opacity="0.9"/><rect x="-1.8" y="8.4" width="3.6" height="1.2" fill="#c8a058"/><rect x="-2.4" y="9.6" width="4.8" height="0.6" fill="#8a5a30"/>'
        + '<g opacity="0">' + an('opacity', '0;0;1;1;0;0', 14, 0, ' keyTimes="0;0.4;0.45;0.75;0.8;1"') + '<g transform="translate(-2.6 9.4)"><ellipse cy="-1" rx="1.3" ry="0.9" fill="#3a6ab8"/><circle cx="-0.8" cy="-1.8" r="0.65" fill="#3a6ab8"/><ellipse cx="-0.2" cy="-0.7" rx="0.8" ry="0.5" fill="#f2e8d8"/><path d="M-1.4 -1.8l-0.6 0.2l0.6 0.2Z" fill="#2a2a2a"/><path d="M1 -1l1.4 0.6" stroke="#2a4a88" stroke-width="0.5"/></g></g></g></g>';
      // clothes line with laundry
      sc += '<path d="M-34 10V34M-34 10H-31" stroke="#8a7a62" stroke-width="0.8"/><path d="M-32 11Q-12 17 10 12" stroke="#ece6da" stroke-width="0.18" fill="none"/>';
      const PEG = (x, y) => '<rect x="' + f1(x - 0.25) + '" y="' + f1(y - 0.6) + '" width="0.5" height="1.4" fill="#c49a5a"/>';
      [[-26, 12.6, 'shirt'], [-16, 14.2, 'sock'], [-12, 14.6, 'sock'], [-4, 14.4, 'towel']].forEach(([x, y, k], i) => { let p;
        if (k === 'shirt') p = '<path d="M-3 0L-5 1.6L-4 3.2L-2.6 2.6V8H2.6V2.6L4 3.2L5 1.6L3 0Q0 1.4 -3 0Z" fill="#f2c14a"/><path d="M-1 0.6Q0 1.6 1 0.6" stroke="#d8a030" stroke-width="0.2" fill="none"/><path d="M-2.6 5H2.6" stroke="#e8b038" stroke-width="0.3" opacity="0.6"/>';
        else if (k === 'sock') p = '<path d="M-0.8 0H0.8V3.8Q0.8 5 2.2 5.2V6.4Q-0.8 6.6 -0.8 4.4Z" fill="' + (i === 1 ? '#e86a6a' : '#6aa8e8') + '"/><rect x="-0.8" width="1.6" height="0.8" fill="#ffffff" opacity="0.6"/>';
        else p = '<rect x="-3.2" width="6.4" height="8.4" fill="#8cc8c0"/><rect x="-3.2" y="6.6" width="6.4" height="0.8" fill="#ffffff" opacity="0.7"/><rect x="-3.2" y="7.6" width="6.4" height="0.3" fill="#ffffff" opacity="0.7"/>';
        sc += '<g transform="translate(' + x + ' ' + y + ')"><g>' + at('rotate', '-5 0 0;6 0 0;-5 0 0', 3 + i * 0.4, -i * 0.7, SPL(2)) + p + '</g>' + PEG(-0.6, 0) + '</g>'; });
      s += '<g clip-path="url(#gc)">' + sc + glassRef(-37, -5, 74, 64) + '</g>';
      // sashes: upper 2-lite + meeting rail + lower sash; lock + lift handles
      s += ring(-36.6, -4.6, 36.6, 27.4, 2.8, FC, 0.7) + bev(-1, -1.8, 2, 26.4, FC, 0.4) + ring(-36.6, 25, 36.6, 58, 2.8, FC, 0.7) + bev(-36.6, 24.6, 73.2, 3.4, shade(FC, 0.98), 0.6);
      s += '<g transform="translate(0 26.2)"><ellipse rx="3" ry="1.1" fill="#b8892e"/><path d="M-2.2 -0.4Q0 -2.4 2.6 -1" stroke="#e8c062" stroke-width="0.8" fill="none" stroke-linecap="round"/><circle cx="2.6" cy="-1" r="0.7" fill="#f2d07a"/></g>';
      // valance (gathered scallops) on a rod
      let val = '<rect x="-40" y="-8" width="80" height="9" fill="url(#gh)"/><rect x="-40" y="-8" width="80" height="9" fill="url(#fo)"/>';
      val += '<path d="M-40 1' + rep(10, i => 'Q' + (-36 + i * 8) + ' 4.6 ' + (-32 + i * 8) + ' 1').join('') + 'V-8H-40Z" fill="url(#gh)"/><path d="M-40 1' + rep(10, i => 'Q' + (-36 + i * 8) + ' 4.6 ' + (-32 + i * 8) + ' 1').join('') + 'V-8H-40Z" fill="url(#fo)"/><path d="M-40 1' + rep(10, i => 'Q' + (-36 + i * 8) + ' 4.6 ' + (-32 + i * 8) + ' 1').join('') + '" stroke="#ffffff" stroke-width="0.6" fill="none"/>';
      s += '<rect x="-40" y="1" width="80" height="3" fill="#000000" opacity="0.14" filter="url(#b1)"/>' + val + '<rect x="-41" y="-8.6" width="82" height="1.2" rx="0.6" fill="url(#br)"/>';
      // cafe curtains on a brass tension rod at y 30, parted in the middle, sway from the rod
      const cur = (x0, w, flip) => { let o = '<rect x="' + x0 + '" width="' + w + '" height="27" fill="url(#gh)"/><rect x="' + x0 + '" width="' + w + '" height="27" fill="url(#fo)"/>';
        o += '<path d="M' + x0 + ' 27' + rep(Math.round(w / 5), i => 'q1.25 1 2.5 0t2.5 0').join('') + 'V25H' + x0 + 'Z" fill="url(#gh)"/><rect x="' + x0 + '" y="25.4" width="' + w + '" height="0.5" fill="#ffffff" opacity="0.7"/>';
        return '<g transform="translate(0 30)"><g>' + at('skewX', '0;' + (flip ? -1.4 : 1.4) + ';0;' + (flip ? 0.8 : -0.8) + ';0', 7 + (flip ? 1.3 : 0), 0, SPL(4)) + o + '</g></g>'; };
      s += '<rect x="-38" y="31" width="76" height="27" fill="#000000" opacity="0.1" filter="url(#b1)"/>' + cur(-37.5, 36, 0) + cur(1.5, 36, 1) + '<rect x="-39" y="29.4" width="78" height="1.2" rx="0.6" fill="url(#br)"/>' + rep(14, i => '<circle cx="' + f1(-36 + i * 5.5) + '" cy="30" r="0.8" fill="none" stroke="#c8983a" stroke-width="0.35"/>').join('');
      // suncatcher on the upper sash + rainbow spots on the casing
      s += '<path d="M-14 -0.4V7" stroke="#e8e2d4" stroke-width="0.12"/><g transform="translate(-14 8.6)"><g>' + at('rotate', '-10 0 -1.6;10 0 -1.6;-10 0 -1.6', 4.4, 0, SPL(2)) + '<path d="M0 -1.6L1.6 0L0 1.6L-1.6 0Z" fill="#e8f4ff" opacity="0.7" stroke="#ffffff" stroke-width="0.12"/><path d="M0 -1.6L0.6 0L0 1.6" fill="#b8d8ff" opacity="0.5"/></g></g>';
      [['#ff8a8a', -30, 61], ['#ffd27a', -27.6, 61.6], ['#9ae0a8', -25, 61.2], ['#9ab8ff', 30, 3]].forEach(([c, x, y], i) => s += '<ellipse cx="' + x + '" cy="' + y + '" rx="1" ry="0.5" fill="' + c + '" opacity="0.4">' + an('opacity', '0.1;0.6;0.1', 4.4, i * 0.6, SPL(2)) + '</ellipse>');
      s += sill(-47, 47, 63, '#f1ece0', 2) + bev(-39, 66, 78, 4, FC, 0.7);
      // geranium pot on the sill
      s += pot(28, 58, 7, 5, '#c8744a') + sway(28, 57.4, 1, 2, 5, 0.3, '<path d="M0 0Q-2 -3 -3 -6M0 0Q1 -4 2.6 -7M0 0Q0 -3 -0.4 -4" stroke="#5a7a3a" stroke-width="0.35" fill="none"/>'
        + [[-3.6, -1.6], [3.2, -2], [-1, -3], [1.8, -0.8]].map(([x, y]) => '<circle cx="' + x + '" cy="' + y + '" r="1.8" fill="#5f9a46"/><circle cx="' + x + '" cy="' + y + '" r="1" fill="none" stroke="#8a6a3a" stroke-width="0.25" opacity="0.5"/>').join('')
        + [[-3, -6.4], [2.6, -7.4]].map(([x, y]) => rep(7, i => '<circle cx="' + f1(x + 1.2 * Math.cos(i * 0.9)) + '" cy="' + f1(y + 1 * Math.sin(i * 0.9)) + '" r="0.75" fill="' + (i % 2 ? '#e8384a' : '#f0505e') + '"/>').join('') + '<circle cx="' + (x - 0.3) + '" cy="' + (y - 0.4) + '" r="0.4" fill="#ff8a90"/>').join(''));
      return { vb: [-48, -16, 96, 88], s }; };

    // KIT-052 sunny herb-garden greenhouse box window: a glass box pushed out past the wall (side + roof + front panes in perspective),
    // white-painted muntins, a glass mid shelf, a zinc pebble tray; 9 terracotta pots of basil, rosemary, chives, thyme, mint, parsley swaying,
    // sunbeams, condensation drop, garden behind (butterfly flits, bee), stone sill with a brass watering can
    WIN.kgreen = () => { const R = rng('kgr'), O = [-46, 46, -22, 58], F = [-34, 34, -16, 40], FC = '#f4f2ea';
      const P = (sx, u, v) => { const ox = O[0] + (O[1] - O[0]) * sx, fx = F[0] + (F[1] - F[0]) * sx, oy = O[2] + (O[3] - O[2]) * v, fy = F[2] + (F[3] - F[2]) * v; return [ox + (fx - ox) * u, oy + (fy - oy) * u]; };
      const Q = (a, b, c, d) => 'M' + [a, b, c, d].map(pt).join('L') + 'Z';
      const shelf = v => Q(P(0, 0, v), P(1, 0, v), P(1, 1, v), P(0, 1, v));
      let s = '<defs>' + WDEF + '<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8cc4ea"/><stop offset="1" stop-color="#e2f2f6"/></linearGradient><radialGradient id="sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fffbe0"/><stop offset="0.4" stop-color="#fff2b0" stop-opacity="0.6"/><stop offset="1" stop-color="#fff2b0" stop-opacity="0"/></radialGradient>'
        + '<linearGradient id="zn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9aa4a6"/><stop offset="1" stop-color="#c8cfd0"/></linearGradient><linearGradient id="bm" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff6c8" stop-opacity="0.32"/><stop offset="1" stop-color="#fff6c8" stop-opacity="0"/></linearGradient>'
        + '<linearGradient id="br" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset="0.5" stop-color="#d8a848"/><stop offset="1" stop-color="#8a6420"/></linearGradient><clipPath id="oc"><rect x="-46" y="-22" width="92" height="80"/></clipPath></defs>';
      s += '<rect x="-52" y="-28" width="104" height="94" fill="#000000" opacity="0.18" filter="url(#b2)"/>';
      let sc = '<rect x="-46" y="-22" width="92" height="80" fill="url(#k)"/><circle cx="26" cy="-10" r="22" fill="url(#sun)"/>' + drift(cloud(-20, -12, 0.9, '#ffffff') + cloud(14, -4, 0.6, '#ffffff'), 92, 70);
      sc += '<path d="M-46 22Q-24 14 0 20T46 16V58H-46Z" fill="#a8d29a"/><path d="M-46 30Q-20 24 6 30T46 27V58H-46Z" fill="#88bd78"/>' + tree(-30, 26, 1.8, '#5f9a4e', 0.2) + tree(36, 22, 1.4, '#6fa85a', 1.1);
      sc += rep(30, () => { const x = -44 + R() * 88, y = 30 + R() * 10; return '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(0.5 + R() * 0.5) + '" fill="' + ['#f2a0c0', '#ffffff', '#f2d24a', '#b8a0f0'][Math.floor(R() * 4)] + '"/>'; }).join('');
      sc += '<g>' + at('translate', '-30 6;-10 -2;8 4;24 -4;8 2;-14 -4;-30 6', 18, 0, SPL(6)) + '<g>' + at('scale', '1 1;0.2 1;1 1', 0.3) + '<path d="M0 0Q-2.4 -2.6 -2.6 -0.4Q-2 1.4 0 0Q2 1.4 2.6 -0.4Q2.4 -2.6 0 0Z" fill="#f2a63a"/><path d="M0 0Q-1.4 -1.4 -1.6 -0.4M0 0Q1.4 -1.4 1.6 -0.4" stroke="#3a2a1a" stroke-width="0.15" fill="none"/></g><path d="M0 -0.8V0.8" stroke="#3a2a1a" stroke-width="0.35"/></g>';
      s += '<g clip-path="url(#oc)">' + sc + '</g>';
      // panes: sides + roof tinted, front glass
      s += '<path d="' + Q([O[0], O[2]], [F[0], F[2]], [F[0], F[3]], [O[0], O[3]]) + '" fill="#e6f2ea" opacity="0.22"/><path d="' + Q([O[1], O[2]], [F[1], F[2]], [F[1], F[3]], [O[1], O[3]]) + '" fill="#ffffff" opacity="0.14"/><path d="' + Q([O[0], O[2]], [O[1], O[2]], [F[1], F[2]], [F[0], F[2]]) + '" fill="#f6fbf8" opacity="0.4"/>' + glassRef(F[0], F[2], F[1] - F[0], F[3] - F[2]);
      // muntins: front frame + cross, box edges, side mid bars
      const bar = (a, b, w) => '<path d="M' + pt(a) + 'L' + pt(b) + '" stroke="' + shade(FC, 0.8) + '" stroke-width="' + w + '" stroke-linecap="round"/><path d="M' + pt(a) + 'L' + pt(b) + '" stroke="' + FC + '" stroke-width="' + f1(w * 0.6) + '" stroke-linecap="round"/>';
      s += bar([F[0], F[2]], [F[1], F[2]], 1.6) + bar([F[0], F[3]], [F[1], F[3]], 1.6) + bar([F[0], F[2]], [F[0], F[3]], 1.6) + bar([F[1], F[2]], [F[1], F[3]], 1.6) + bar([0, F[2]], [0, F[3]], 1.2);
      [[0, 0], [1, 0]].forEach(([sx]) => { s += bar(P(sx, 0, 0), P(sx, 1, 0), 1.6) + bar(P(sx, 0, 1), P(sx, 1, 1), 1.6) + bar(P(sx, 0.5, 0), P(sx, 0.5, 1), 1); });
      // zinc tray floor + pebbles
      s += '<path d="' + shelf(1) + '" fill="url(#zn)"/>' + rep(70, () => { const sx = R(), u = R(), p = P(sx, u, 1), k = 1 - 0.27 * u; return '<ellipse cx="' + f1(p[0]) + '" cy="' + f1(p[1] - 0.3) + '" rx="' + f1((0.5 + R() * 0.5) * k) + '" ry="' + f1((0.3 + R() * 0.25) * k) + '" fill="' + ['#d8d0c0', '#b8b0a2', '#e8e2d6', '#a09888'][Math.floor(R() * 4)] + '"/>'; }).join('');
      const potAt = (sx, u, v, h, ph) => { const p = P(sx, u, v), k = 1 - 0.27 * u; return pot(p[0], p[1] - 4.6 * k, 6.4 * k, 4.6 * k) + herb(h, p[0], p[1] - 5.6 * k, 0.95 * k, ph); };
      s += potAt(0.22, 0.85, 1, 'chive', 0.4) + potAt(0.5, 0.85, 1, 'rose', 1.1) + potAt(0.78, 0.85, 1, 'mint', 2);
      // glass mid shelf on brass brackets
      const v2 = 0.52; s += '<path d="' + shelf(v2) + '" fill="#e8f6f4" opacity="0.4"/><path d="M' + pt(P(0, 0, v2)) + 'L' + pt(P(1, 0, v2)) + '" stroke="#bfe0dc" stroke-width="0.9"/><path d="M' + pt(P(0, 0, v2)) + 'L' + pt(P(1, 0, v2)) + '" stroke="#ffffff" stroke-width="0.25" transform="translate(0 -0.3)"/>'
        + [0.02, 0.98].map(sx => { const p = P(sx, 0.2, v2); return '<path d="M' + f1(p[0]) + ' ' + f1(p[1] + 0.4) + 'l' + (sx < 0.5 ? 1.6 : -1.6) + ' 2.4" stroke="url(#br)" stroke-width="0.7"/>'; }).join('');
      s += potAt(0.25, 0.5, v2, 'thyme', 0.8) + potAt(0.5, 0.5, v2, 'pars', 1.7) + potAt(0.75, 0.5, v2, 'basil', 2.6);
      s += potAt(0.18, 0.22, 1, 'basil', 0.2) + potAt(0.5, 0.22, 1, 'thyme', 1.4) + potAt(0.82, 0.22, 1, 'pars', 2.2);
      // plant stakes
      [[0.18, 'BASIL'], [0.82, 'PARSLEY']].forEach(([sx, t]) => { const p = P(sx, 0.22, 1); s += '<g transform="translate(' + f1(p[0] + 2.4) + ' ' + f1(p[1] - 8.6) + ')"><path d="M0 0V3.4" stroke="#c8b088" stroke-width="0.3"/><rect x="-2.2" y="-1.4" width="4.4" height="1.6" rx="0.2" fill="#f4ecd8"/><text y="-0.2" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="0.9" fill="#6a5a3a">' + t + '</text></g>'; });
      // sunbeams + condensation drop
      s += '<g opacity="0.7">' + an('opacity', '0.5;0.85;0.5', 8, 0, SPL(2)) + '<path d="M34 -16L46 -22L10 58L-4 58Z" fill="url(#bm)"/><path d="M18 -16L26 -16L-14 58L-22 58Z" fill="url(#bm)" opacity="0.6"/></g>';
      s += '<g>' + at('translate', '0 0;0 0;0 18', 16, 0, ' keyTimes="0;0.5;1" calcMode="spline" keySplines="0 0 1 1;0.5 0 1 1"') + '<ellipse cx="-20" cy="-8" rx="0.5" ry="0.7" fill="#ffffff" opacity="0.7"/><path d="M-20 -8.4V-14" stroke="#ffffff" stroke-width="0.3" opacity="0.3"/></g>' + rep(16, () => '<circle cx="' + f1(F[0] + R() * 68) + '" cy="' + f1(F[2] + R() * 18) + '" r="' + f1(0.15 + R() * 0.2) + '" fill="#ffffff" opacity="0.5"/>').join('');
      // inner casing + stone sill + brass watering can
      s += ring(-50, -26, 50, 61, 4, FC, 1) + sill(-54, 54, 60, '#e8e2d4', 2) + bev(-46, 63, 92, 3.6, FC, 0.6);
      s += '<g transform="translate(-40 55.8)"><ellipse cx="2" cy="4.4" rx="4" ry="0.8" fill="#000000" opacity="0.22" filter="url(#b1)"/><path d="M0 0H4.4L4.8 4.2H-0.4Z" fill="url(#br)"/><path d="M4.4 1.2L8.4 -2.6" stroke="url(#br)" stroke-width="0.9" stroke-linecap="round"/><ellipse cx="8.6" cy="-2.8" rx="0.7" ry="1" fill="#c8983a" transform="rotate(40 8.6 -2.8)"/><path d="M0 0Q2.2 -3.4 4.4 0" stroke="#b8892e" stroke-width="0.5" fill="none"/><rect x="0.6" y="0.6" width="0.6" height="3" fill="#fff4c8" opacity="0.6"/></g>';
      return { vb: [-56, -30, 112, 98], s }; };

    // KIT-072 black-steel accordion pass-through bar window: 6 thin-profile steel bi-fold panels fold open to the left and close again (36 s),
    // walnut bar top running through the opening onto an outside ledge, golden-hour patio (string lights twinkle + sway, olive tree, rattan stools),
    // two cocktail coupes + a bowl of lemons on the bar, brass pull handle riding on the leading panel
    WIN.kaccord = () => { const R = rng('kac'), N = 6, X0 = -62, X1 = 62, WP = (X1 - X0) / N, YT = -22, YB = 40, YC = 9, YM = YT + (YB - YT) * 0.36, ST = '#1d1e20';
      let s = '<defs>' + WDEF + '<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9cc0da"/><stop offset="0.55" stop-color="#f4d6a8"/><stop offset="1" stop-color="#f8c88a"/></linearGradient><radialGradient id="sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff4d0"/><stop offset="0.3" stop-color="#ffd48a" stop-opacity="0.7"/><stop offset="1" stop-color="#ffc06a" stop-opacity="0"/></radialGradient>'
        + '<linearGradient id="wn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8a5a36"/><stop offset="1" stop-color="#5a3620"/></linearGradient><linearGradient id="wf" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7a4a2a"/><stop offset="0.2" stop-color="#5e3a22"/><stop offset="1" stop-color="#3e2414"/></linearGradient>'
        + '<linearGradient id="gl" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.3"/><stop offset="0.4" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="1" stop-color="#2a3a4a" stop-opacity="0.12"/></linearGradient>'
        + '<linearGradient id="br" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset="0.5" stop-color="#d8a848"/><stop offset="1" stop-color="#8a6420"/></linearGradient><radialGradient id="bl" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff2c0"/><stop offset="1" stop-color="#ffd27a" stop-opacity="0"/></radialGradient><clipPath id="oc"><rect x="-62" y="-22" width="124" height="62"/></clipPath></defs>';
      s += '<rect x="-68" y="-28" width="138" height="84" fill="#000000" opacity="0.18" filter="url(#b2)"/>';
      let sc = '<rect x="-62" y="-22" width="124" height="62" fill="url(#k)"/><circle cx="34" cy="12" r="22" fill="url(#sun)"/><circle cx="34" cy="12" r="4.2" fill="#fff2c8"/>' + drift(cloud(-30, -14, 0.8, '#fbe8d0') + cloud(10, -17, 0.6, '#fbe8d0'), 124, 90);
      sc += '<path d="M-62 14Q-40 6 -20 12T20 9T62 12V40H-62Z" fill="#c8a68a"/><path d="M-62 18Q-34 13 -6 18T62 16V40H-62Z" fill="#a88e76"/>';
      sc += '<path d="M-62 26H62V40H-62Z" fill="#e8d6b8"/>' + rep(9, i => '<path d="M' + (-62 + i * 16) + ' 26L' + f1(-62 + i * 16 + (i * 16 - 62) * 0.3) + ' 40" stroke="#cdb894" stroke-width="0.2"/>').join('') + '<path d="M-62 31H62M-62 36H62" stroke="#cdb894" stroke-width="0.2"/>';
      sc += sway(-46, 30, 1, 1.5, 6, 0.4, '<path d="M-1 0L-0.6 -14H0.6L1 0Z" fill="#6a5a46"/>' + rep(14, i => { const a = -PI / 2 + (i - 6.5) * 0.22, d = 7 + (i % 3) * 2; return '<ellipse cx="' + f1(Math.cos(a) * d * 0.8) + '" cy="' + f1(-14 + Math.sin(a) * d * 0.5 + 4) + '" rx="3.6" ry="1.8" fill="' + (i % 2 ? '#8a9a6e' : '#7a8a5e') + '"/>'; }).join('')) + '<path d="M-51 30H-41L-42 37H-50Z" fill="#c8b8a0"/><rect x="-51.6" y="29" width="11.2" height="1.6" fill="#ddd0b8"/>';
      // string lights in catenaries, gently swaying, bulbs twinkle
      let li = ''; [[-62, -16, 0, -10, 'a'], [0, -10, 62, -18, 'b']].forEach(([x0, y0, x1, y1, k], j) => { const my = Math.max(y0, y1) + 5; li += '<path d="M' + x0 + ' ' + y0 + 'Q' + f1((x0 + x1) / 2) + ' ' + f1(my + 3) + ' ' + x1 + ' ' + y1 + '" stroke="#3a3028" stroke-width="0.25" fill="none"/>';
        for (let i = 1; i < 9; i++) { const t = i / 9, x = (1 - t) * (1 - t) * x0 + 2 * t * (1 - t) * (x0 + x1) / 2 + t * t * x1, y = (1 - t) * (1 - t) * y0 + 2 * t * (1 - t) * (my + 3) + t * t * y1;
          li += '<circle cx="' + f1(x) + '" cy="' + f1(y + 1.6) + '" r="2.4" fill="url(#bl)" opacity="0.6">' + an('opacity', '0.4;0.75;0.4', 3 + (i % 3), i * 0.4 + j, SPL(2)) + '</circle><path d="M' + f1(x) + ' ' + f1(y) + 'v0.6" stroke="#3a3028" stroke-width="0.4"/><ellipse cx="' + f1(x) + '" cy="' + f1(y + 1.4) + '" rx="0.55" ry="0.8" fill="#fff0c0"/>'; } });
      sc += '<g>' + at('rotate', '-0.6 0 -20;0.6 0 -20;-0.6 0 -20', 7, 0, SPL(2)) + li + '</g>';
      sc += [-14, 14].map(x => '<g transform="translate(' + x + ' 34)"><path d="M-3 0L-3.6 6M3 0L3.6 6M-2.6 3.4H2.6" stroke="#3a3028" stroke-width="0.4"/><ellipse rx="3.6" ry="1.1" fill="#c8a878"/><ellipse cy="-0.2" rx="3.2" ry="0.8" fill="#dcc090"/><path d="M-3 -0.2H3M-2.4 0.3H2.4" stroke="#a8885a" stroke-width="0.12"/></g>').join('');
      s += '<g clip-path="url(#oc)">' + sc + '</g>';
      // outside ledge (bar top continues outside)
      s += '<path d="M-64 35H64L64 40H-64Z" fill="url(#wn)"/><path d="M-64 35H64" stroke="#b07a4a" stroke-width="0.3"/>';
      // header + side jambs + track
      s += ring(-66, -26, 66, 41, 4, ST, 0.6) + '<rect x="-62" y="-22.2" width="124" height="1" fill="#3a3c40"/><rect x="-62" y="39.6" width="124" height="0.6" fill="#3a3c40"/>';
      // accordion panels
      const sm = x => x * x * (3 - 2 * x), KF = [[0, 0], [0.14, 0]]; for (let i = 1; i <= 8; i++) KF.push([0.14 + 0.2 * i / 8, sm(i / 8)]); KF.push([0.62, 1]); for (let i = 1; i <= 8; i++) KF.push([0.62 + 0.2 * i / 8, 1 - sm(i / 8)]); KF.push([1, 0]);
      const KT = ' keyTimes="' + KF.map(k => n4(k[0])).join(';') + '"';
      const E = (j, f) => { const th = f * 1.38, x = X0 + j * WP * Math.cos(th), d = (j % 2) * WP * Math.sin(th), k = 1 + d * 0.0045; return [x, YC + (YT - YC) * k, YC + (YB - YC) * k, YC + (YM - YC) * k]; };
      const vals = fn => KF.map(([, f]) => fn(f)).join(';');
      for (let i = 0; i < N; i++) { const dP = f => { const a = E(i, f), b = E(i + 1, f); return 'M' + f1(a[0]) + ' ' + f1(a[1]) + 'L' + f1(b[0]) + ' ' + f1(b[1]) + 'L' + f1(b[0]) + ' ' + f1(b[2]) + 'L' + f1(a[0]) + ' ' + f1(a[2]) + 'Z'; },
          dM = f => { const a = E(i, f), b = E(i + 1, f); return 'M' + f1(a[0]) + ' ' + f1(a[3]) + 'L' + f1(b[0]) + ' ' + f1(b[3]); }, d0 = dP(0), A = (nm, fn) => '<animate attributeName="' + nm + '" values="' + vals(fn) + '" dur="36s"' + KT + ' repeatCount="indefinite"/>';
        s += '<path d="' + d0 + '" fill="#b8d0dc" opacity="0.12">' + A('d', dP) + '</path><path d="' + d0 + '" fill="url(#gl)">' + A('d', dP) + '</path><path d="' + d0 + '" fill="#ffffff" opacity="0.04">' + A('d', dP) + A('opacity', f => n4(0.04 + (i % 2 ? 0.05 : 0.3) * Math.sin(f * 1.38))) + '</path>'
          + '<path d="' + d0 + '" fill="none" stroke="' + ST + '" stroke-width="1.5" stroke-linejoin="round">' + A('d', dP) + '</path><path d="' + dM(0) + '" stroke="' + ST + '" stroke-width="0.9">' + A('d', dM) + '</path><path d="' + d0 + '" fill="none" stroke="#5a5e66" stroke-width="0.2" transform="translate(-0.35 -0.35)">' + A('d', dP) + '</path>'; }
      { const hP = f => { const e = E(N, f), k = (e[2] - e[1]) / (YB - YT); return 'M' + f1(e[0] - 1.4) + ' ' + f1(YC - 5 * k) + 'V' + f1(YC + 5 * k); }; s += '<path d="' + hP(0) + '" stroke="url(#br)" stroke-width="0.9" stroke-linecap="round"><animate attributeName="d" values="' + vals(hP) + '" dur="36s"' + KT + ' repeatCount="indefinite"/></path>'; }
      // inside bar top + front edge + props
      s += '<path d="M-66 40H66L68 44H-68Z" fill="url(#wn)"/><path d="M-66 40.2H66" stroke="#c08a58" stroke-width="0.25" opacity="0.8"/>' + rep(9, () => { const y = 40.6 + R() * 3; return '<path d="M' + f1(-66 + R() * 40) + ' ' + f1(y) + 'h' + f1(20 + R() * 60) + '" stroke="#4a2a16" stroke-width="0.12" opacity="0.4"/>'; }).join('') + '<rect x="-68" y="44" width="136" height="4.6" fill="url(#wf)"/><rect x="-68" y="44" width="136" height="0.4" fill="#d8a070" opacity="0.7"/><rect x="-68" y="48.6" width="136" height="2" fill="#000000" opacity="0.25" filter="url(#b1)"/>';
      s += '<g filter="url(#b2)"><ellipse cx="0" cy="42.4" rx="40" ry="1.8" fill="#ffd89a" opacity="0.25"/></g>';
      const coupe = (x, c) => '<g transform="translate(' + x + ' 42.6)"><ellipse rx="2" ry="0.4" fill="#000000" opacity="0.25"/><path d="M-1.4 0H1.4L0.2 -0.4V-4L2.8 -5.6Q0 -7.2 -2.8 -5.6L-0.2 -4V-0.4Z" fill="#ffffff" opacity="0.35" stroke="#ffffff" stroke-width="0.15" stroke-opacity="0.8"/><path d="M-2.6 -5.6Q0 -4.4 2.6 -5.6Q0 -6.4 -2.6 -5.6Z" fill="' + c + '" opacity="0.85"/><circle cx="2.2" cy="-6" r="0.7" fill="#f0a030"/><path d="M-2 -5.8L-1 -6.6" stroke="#ffffff" stroke-width="0.2" opacity="0.8"/></g>';
      s += coupe(-12, '#f08a4a') + coupe(-6, '#e8603a') + '<g transform="translate(16 42.6)"><ellipse rx="4.4" ry="0.6" fill="#000000" opacity="0.25"/><path d="M-4 -2.4Q0 0.8 4 -2.4Z" fill="url(#br)"/>' + [[-2, -2.6], [0.4, -3], [2.4, -2.5], [-0.8, -3.9], [1.4, -4]].map(([x, y]) => '<ellipse cx="' + x + '" cy="' + y + '" rx="1.4" ry="1.1" fill="#f2d43a"/><ellipse cx="' + (x - 0.4) + '" cy="' + (y - 0.4) + '" rx="0.5" ry="0.35" fill="#fff4a0"/>').join('') + '<path d="M-1 -4.8q1 -1.2 2 -0.6" stroke="#4a7a2a" stroke-width="0.4" fill="none"/></g>';
      return { vb: [-72, -30, 144, 84], s }; };

    // KIT-092 smart hydroponic vertical-farm panorama window: frameless floor-to-ceiling glass on a golden-hour valley (lake, vineyard rows, cypresses,
    // drifting clouds, birds), 4 polished brass gutters on fine brass hangers holding butterhead lettuce, basil, strawberries (ripen red and back),
    // kale + herbs, warm grow-light bars glowing down, water trickling gutter to gutter, mist puffs; bronze planter base with a champagne line + engraved readout
    WIN.khydro = () => { const R = rng('khy'), GX = 76, GT = -40, GB = 90, ROWS = [-16, 12, 40, 68];
      let s = '<defs>' + WDEF + '<linearGradient id="k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a8c8e0"/><stop offset="0.5" stop-color="#f6dcb0"/><stop offset="0.75" stop-color="#f8c890"/><stop offset="1" stop-color="#e8b47a"/></linearGradient><radialGradient id="sun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff6d8"/><stop offset="0.3" stop-color="#ffdc98" stop-opacity="0.7"/><stop offset="1" stop-color="#ffc878" stop-opacity="0"/></radialGradient>'
        + '<linearGradient id="bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff2c0"/><stop offset="0.35" stop-color="#e8bc62"/><stop offset="0.7" stop-color="#b08032"/><stop offset="1" stop-color="#7a5418"/></linearGradient><linearGradient id="bv" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8a6420"/><stop offset="0.45" stop-color="#f6dc96"/><stop offset="1" stop-color="#9a7228"/></linearGradient>'
        + '<linearGradient id="gw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe2a0" stop-opacity="0.32"/><stop offset="1" stop-color="#ffe2a0" stop-opacity="0"/></linearGradient><linearGradient id="bz" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7a5a34"/><stop offset="1" stop-color="#3a2a18"/></linearGradient>'
        + '<radialGradient id="lt" cx="50%" cy="70%" r="60%"><stop offset="0" stop-color="#d8f0a0"/><stop offset="0.6" stop-color="#9ccc5a"/><stop offset="1" stop-color="#6a9a3a"/></radialGradient><clipPath id="gc"><rect x="-76" y="-40" width="152" height="130"/></clipPath></defs>';
      s += '<rect x="-80" y="-44" width="160" height="142" fill="#000000" opacity="0.16" filter="url(#b2)"/>';
      let sc = '<rect x="-76" y="-40" width="152" height="130" fill="url(#k)"/><circle cx="-34" cy="34" r="34" fill="url(#sun)"/><circle cx="-34" cy="34" r="5" fill="#fff4d0"/>' + drift(cloud(-50, -28, 1.1, '#fbeedc') + cloud(10, -32, 0.8, '#fbeedc') + cloud(46, -20, 0.7, '#f8e6d0'), 152, 120);
      sc += '<g>' + at('translate', '-90 0;90 -10', 40) + rep(3, i => '<path d="M' + (i * 5) + ' ' + (i * 2 - 22) + 'q1 -1 2 0q1 -1 2 0" stroke="#5a4a3a" stroke-width="0.3" fill="none"/>').join('') + '</g>';
      sc += '<path d="M-76 30Q-50 20 -26 28T22 22T76 26V90H-76Z" fill="#b8a8a8" opacity="0.7"/><path d="M-76 38Q-40 32 0 37T76 35V90H-76Z" fill="#9ab0b8"/>' + rep(6, i => '<path d="M' + (-60 + i * 22) + ' ' + (40 + i % 2) + 'h' + (8 + i % 3 * 3) + '" stroke="#fff2d0" stroke-width="0.4" opacity="0.5">' + an('opacity', '0.2;0.6;0.2', 5 + i, i, SPL(2)) + '</path>').join('');
      sc += '<path d="M-76 50Q-30 42 10 48T76 46V90H-76Z" fill="#a8b06a"/><path d="M-76 62Q-20 54 30 60T76 58V90H-76Z" fill="#8a9a52"/>' + rep(14, i => '<path d="M-76 ' + (52 + i * 2.8) + 'Q0 ' + (44 + i * 3) + ' 76 ' + (50 + i * 2.8) + '" stroke="#6a7a3a" stroke-width="0.3" fill="none" opacity="0.45"/>').join('');
      sc += [[-62, 50], [-56, 52], [48, 48], [56, 50], [62, 49]].map(([x, y], i) => sway(x, y, 1, 1.2, 5 + i, i, '<path d="M0 0Q-1.6 -6 0 -12Q1.6 -6 0 0Z" fill="#4a6a3a"/><path d="M0 0Q-0.6 -6 0 -11" stroke="#6a8a4a" stroke-width="0.3" fill="none"/>')).join('');
      s += '<g clip-path="url(#gc)">' + sc + '<rect x="-76" y="-40" width="152" height="130" fill="url(#gref)" opacity="0.6"/></g>';
      // brass hangers
      [-56, -19, 19, 56].forEach(x => s += '<rect x="' + (x - 0.5) + '" y="-40" width="1" height="130" fill="url(#bv)"/>');
      // plants per row
      const lettuce = () => { let o = ''; for (let i = 0; i < 9; i++) { const a = -PI / 2 + (i - 4) * 0.36, d = i % 2 ? 2.4 : 3.2; o += '<ellipse cx="' + f1(Math.cos(a) * d) + '" cy="' + f1(Math.sin(a) * d * 0.8 - 1) + '" rx="2.2" ry="1.7" transform="rotate(' + f1(a * 180 / PI + 90) + ' ' + f1(Math.cos(a) * d) + ' ' + f1(Math.sin(a) * d * 0.8 - 1) + ')" fill="url(#lt)" stroke="#c8e890" stroke-width="0.2"/>'; } return o + '<ellipse cy="-2.2" rx="1.6" ry="1.2" fill="#e0f4b0"/>'; };
      const kale = () => rep(6, i => { const a = (i - 2.5) * 0.3; return '<path d="M0 0Q' + f1(Math.sin(a) * 4 - 1) + ' ' + f1(-4) + ' ' + f1(Math.sin(a) * 6) + ' ' + f1(-7 - i % 2) + 'Q' + f1(Math.sin(a) * 4 + 1.4) + ' -3 0 0Z" fill="' + (i % 2 ? '#3a6a5a' : '#4a7a64') + '" stroke="#6a9a84" stroke-width="0.25" stroke-dasharray="0.5 0.3"/>'; }).join('');
      const straw = j => { let o = rep(3, i => { const a = (i - 1) * 0.7; return '<path d="M0 0L' + f1(Math.sin(a) * 3) + ' ' + f1(-3.4) + '" stroke="#4a7a2a" stroke-width="0.3"/><ellipse cx="' + f1(Math.sin(a) * 3) + '" cy="-3.8" rx="1.5" ry="1.1" fill="#4e8a34" stroke="#3a6a24" stroke-width="0.15"/>'; }).join('');
        o += '<path d="M0.6 0.4Q2.6 3 2.2 6.4M-0.4 0.4Q-1.6 2.4 -1.2 4.6" stroke="#6a8a3a" stroke-width="0.25" fill="none"/>';
        const berry = (x, y, c, ani) => '<path d="M' + x + ' ' + (y - 0.6) + 'q1.2 0 1 1.2q-0.3 1.4 -1 1.8q-0.7 -0.4 -1 -1.8q-0.2 -1.2 1 -1.2Z" fill="' + c + '">' + (ani ? an('fill', '#b8d86a;#e8463c;#d8303a;#b8d86a', 24, j * 3, ' keyTimes="0;0.4;0.85;1"') : '') + '</path><circle cx="' + (x - 0.3) + '" cy="' + (y + 0.2) + '" r="0.12" fill="#fff4b0"/><circle cx="' + (x + 0.3) + '" cy="' + (y + 0.6) + '" r="0.12" fill="#fff4b0"/><path d="M' + (x - 0.6) + ' ' + (y - 0.6) + 'l0.6 0.3l0.6 -0.3" stroke="#4a8a2a" stroke-width="0.3" fill="none"/>';
        o += berry(2.2, 6.6, '#e8463c', j % 2) + berry(-1.2, 4.8, '#d8303a', 0) + '<circle cx="-2" cy="-1" r="0.7" fill="#ffffff"/><circle cx="-2" cy="-1" r="0.25" fill="#f2c83a"/>'; return o; };
      const ROWP = [['L', 'basil'], ['S'], ['K', 'pars'], ['basil', 'thyme', 'mint', 'L']];
      ROWS.forEach((y, ri) => { const kinds = ROWP[ri];
        s += '<g filter="url(#b2)"><path d="M-74 ' + (y + 3.6) + 'H74L80 ' + (y + 26) + 'H-80Z" fill="url(#gw)" opacity="0.9">' + an('opacity', '0.7;1;0.7', 7, ri * 1.4, SPL(2)) + '</path></g>';
        for (let i = 0; i < 10; i++) { const x = -67.5 + i * 15, k = kinds[i % kinds.length], ph = (i * 0.37 + ri * 0.6) % 3;
          s += '<ellipse cx="' + f1(x) + '" cy="' + f1(y + 0.2) + '" rx="2.6" ry="0.6" fill="#2a2014"/>';
          s += k === 'L' ? sway(x, y, 1.75, 1.2, 5 + ph, ph, lettuce()) : k === 'K' ? sway(x, y, 1.6, 1.8, 4.6 + ph, ph, kale()) : k === 'S' ? sway(x, y, 1.7, 2.4, 5 + ph, ph, straw(i)) : herb(k, x, y, 1.15, ph); }
        s += '<rect x="-76" y="' + y + '" width="152" height="3.4" rx="1.2" fill="url(#bg)"/><rect x="-76" y="' + (y + 0.4) + '" width="152" height="0.4" fill="#fff6d0" opacity="0.8"/><rect x="-76" y="' + (y + 3.4) + '" width="152" height="0.9" fill="#3a2a14" opacity="0.5"/>';
        s += '<rect x="-72" y="' + (y + 4.4) + '" width="144" height="0.9" rx="0.45" fill="#8a6420"/><rect x="-71" y="' + (y + 5) + '" width="142" height="0.35" rx="0.18" fill="#fff2c8"/>';
        if (ri < 3) { const x = ri % 2 ? -73 : 73; s += '<path d="M' + x + ' ' + (y + 3.4) + 'V' + (ROWS[ri + 1]) + '" stroke="#e8f2f4" stroke-width="0.5" stroke-dasharray="1.2 0.9" opacity="0.6"><animate attributeName="stroke-dashoffset" values="0;-4.2" dur="0.9s" repeatCount="indefinite"/></path>'; }
        [-38, 0, 38].forEach((x, j) => s += '<ellipse cx="' + (x + ri * 4) + '" cy="' + (y - 4) + '" rx="1" ry="0.6" fill="#ffffff" opacity="0">' + an('opacity', '0;0;0.45;0', 9, ri * 1.7 + j * 2.9, ' keyTimes="0;0.8;0.86;1"') + an('rx', '1;1;1;7', 9, ri * 1.7 + j * 2.9, ' keyTimes="0;0.8;0.86;1"') + an('ry', '0.6;0.6;0.6;3', 9, ri * 1.7 + j * 2.9, ' keyTimes="0;0.8;0.86;1"') + '</ellipse>'); });
      // bronze base + champagne light line + engraved readout; frameless edges
      s += '<rect x="-78" y="84" width="156" height="12" fill="url(#bz)"/><rect x="-78" y="84" width="156" height="0.6" fill="#d8b070"/><rect x="-78" y="95.4" width="156" height="0.6" fill="#ffe2a0" opacity="0.7">' + an('opacity', '0.5;0.8;0.5', 6, 0, SPL(2)) + '</rect>';
      s += rep(26, i => '<rect x="' + (-75 + i * 5.8) + '" y="86.2" width="0.5" height="7" fill="#2a1e10" opacity="0.5"/>').join('') + '<rect x="46" y="87" width="24" height="5.6" rx="0.6" fill="url(#bv)"/><text x="58" y="90.8" text-anchor="middle" font-family="Georgia,\'Times New Roman\',serif" font-size="2" fill="#4a3210" letter-spacing="0.1">pH 6.1 · 22°C</text>';
      s += '<rect x="-77" y="-41" width="154" height="132" fill="none" stroke="url(#bv)" stroke-width="1.2"/><rect x="-78.4" y="-42.4" width="156.8" height="134.8" fill="none" stroke="#000000" stroke-opacity="0.2" stroke-width="0.6"/>';
      return { vb: [-82, -46, 164, 144], s }; };
  }


  // ======================= WALL STORAGE (KIT-014 / 034 wall pieces like plus19; KIT-054 floor hutch of real solids like plus23) =======================
  { const { cam: camW, tanF, FR } = H, { box3, cyl3 } = RD.H15, { WD } = RD.H12, { ext } = RD.H11, DEF19 = RD.H19.DEF19;
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const poly3 = (C, P, fill, ex) => '<path d="M' + P.map(p => PP(C, p)).join('L') + 'Z" fill="' + fill + '"' + (ex ? ' ' + ex : '') + '/>';
    const line3 = (C, P, w, col, ex) => '<path d="M' + P.map(p => PP(C, p)).join('L') + '" stroke="' + col + '" stroke-width="' + f1(w * C.k) + '" fill="none" stroke-linecap="round" stroke-linejoin="round"' + (ex ? ' ' + ex : '') + '/>';
    const swayAt = (C, p, a, d, ph, inner) => { const q = C.P(p), o = f1(q[0]) + ' ' + f1(q[1]); return '<g>' + at('rotate', (-a) + ' ' + o + ';' + a + ' ' + o + ';' + (-a) + ' ' + o, d, -ph, SPL(2)) + inner + '</g>'; };
    const ryOf = (C, x, y, z, r) => { const a = C.P([x, y, z]), b = C.P([x, y, z + r]); return Math.abs(b[1] - a[1]); };
    const ell3 = (C, x, y, z, r, fill, ex) => { const q = C.P([x, y, z]); return '<ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + f1(r * C.k) + '" ry="' + f1(Math.max(0.2, ryOf(C, x, y, z, r))) + '" fill="' + fill + '"' + (ex ? ' ' + ex : '') + '/>'; };
    // glass jar (front-on 2D, vertical axis): body, rim, glints
    const jar = (C, x, y, z, r, h, inner, tint) => { const b = C.P([x, y, z]), t = C.P([x, y + h, z]), rx = r * C.k, ry = Math.max(0.3, ryOf(C, x, y, z, r)), g = tint || '#dcefee';
      const body = 'M' + f1(t[0] - rx) + ' ' + f1(t[1]) + 'L' + f1(b[0] - rx) + ' ' + f1(b[1]) + 'A' + f1(rx) + ' ' + f1(ry) + ' 0 0 0 ' + f1(b[0] + rx) + ' ' + f1(b[1]) + 'L' + f1(t[0] + rx) + ' ' + f1(t[1]) + 'A' + f1(rx) + ' ' + f1(ry) + ' 0 0 1 ' + f1(t[0] - rx) + ' ' + f1(t[1]) + 'Z';
      return (inner || '') + '<path d="' + body + '" fill="' + g + '" opacity="0.32"/><path d="' + body + '" fill="none" stroke="#9fbcbc" stroke-width="' + f1(0.25 * C.k) + '" opacity="0.8"/>'
        + '<ellipse cx="' + f1(t[0]) + '" cy="' + f1(t[1]) + '" rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="none" stroke="#f4fbfb" stroke-width="' + f1(0.45 * C.k) + '" opacity="0.9"/>'
        + '<path d="M' + f1(b[0] - rx * 0.62) + ' ' + f1(b[1] - 0.6 * C.k) + 'L' + f1(t[0] - rx * 0.62) + ' ' + f1(t[1] + 0.8 * C.k) + '" stroke="#ffffff" stroke-width="' + f1(0.55 * C.k) + '" opacity="0.75"/><path d="M' + f1(b[0] + rx * 0.5) + ' ' + f1(b[1] - 1 * C.k) + 'L' + f1(t[0] + rx * 0.5) + ' ' + f1(t[1] + 2 * C.k) + '" stroke="#ffffff" stroke-width="' + f1(0.25 * C.k) + '" opacity="0.5"/>'; };
    const mugH = (C, x, y, z, r, h, col, side) => { const P = rep(9, i => { const a = -PI / 2 + i / 8 * PI; return [x + side * (r + Math.cos(a) * h * 0.28), y + h * 0.5 + Math.sin(a) * h * 0.3, z]; }); return line3(C, P, 0.9, shade(col, 0.6)) + line3(C, P, 0.55, col); };
    const mugC = (C, x, y, z, r, h, col, inner) => cyl3(C, [x, y, z], [x, y + h, z], r, col, { n: 20, mat: 'gloss', capCol: col, cap: cr => '<circle r="' + f1(cr) + '" fill="' + shade(col, 1.08) + '"/><circle r="' + f1(cr * 0.84) + '" fill="' + (inner || shade(col, 0.72)) + '"/>' });

    // KIT-014 open pine plank on rusty iron brackets: knotty pine plank (grain, knots, scorch ring, coffee ring), bent L brackets with rust + drip stains,
    // a mason jar of wooden spoons, a chipped '#1 COOK' mug + mustard mug, dented tin can, blue salt tub, grandma's recipe book leaning, pothos with trailing vines,
    // upside-down bowls; red plaid tea towel on a cup hook sways, a little spider bobs on its thread
    N.pine27 = S => { const D = { w: 98, d: 26, mount: 'wall', elev: 46, build: () => [] };
      D.fx = ctx => { const C = camW(ctx), R = rng('pine27'), PY = 14, PT = PY + 2.6, PZ = 17.4, PN = '#dab27a', RU = '#6e3f26';
        ext(C, [[-50, PT + 22, 0], [50, -16, 0]]);
        let s = WD(C, -47, PY - 0.6, 0.05, '<rect width="94" height="5" rx="2" fill="#000000" opacity="0.32" filter="url(#m10b3)"/>');
        [-32, 32].forEach(x => { s += WD(C, x - 1.6, -8, 0.05, '<path d="M0.4 0Q0.2 6 1.2 10Q0.6 16 1.6 22" stroke="#8a4a22" stroke-width="1.4" fill="none" opacity="0.32" filter="url(#m12b1)"/><path d="M2 0Q2.6 5 2.2 9" stroke="#a85a28" stroke-width="0.6" fill="none" opacity="0.3"/>'); });
        s += WD(C, -44, 6, 0.05, '<path d="M0 0H18" stroke="#5a5a5a" stroke-width="0.25" opacity="0.4"/><circle cx="62" cy="-3" r="0.35" fill="#4a4036" opacity="0.7"/><circle cx="66" cy="-2.6" r="0.35" fill="#4a4036" opacity="0.7"/>');
        // brackets: wall leg, diagonal brace, arm under the plank
        const rust = (w, h) => rep(5, () => '<ellipse cx="' + f1(R() * w) + '" cy="' + f1(R() * h) + '" rx="' + f1(0.3 + R() * 0.5) + '" ry="' + f1(0.3 + R() * 0.7) + '" fill="' + (R() < 0.5 ? '#b8622e' : '#3a2416') + '" opacity="0.7"/>').join('');
        [-32, 32].forEach(x => { s += box3(C, { c: [x, -9, 1.2], w: 1.9, h: PY + 8.8, d: 1.2, col: RU, r: 0.2, dec: { f: rust(1.9, PY + 9) } });
          [-6, 2, 9].forEach(y => s += cyl3(C, [x, y, 1.8], [x, y, 2.3], 0.55, '#5a5048', { n: 10 }));
          const a = [0, -7, 1.8], b = [0, PY - 1.6, 14.4], dv = [0, b[1] - a[1], b[2] - a[2]], L = Math.hypot(dv[1], dv[2]), u = [0, dv[1] / L, dv[2] / L];
          s += box3(C, { c: [x, a[1], a[2]], ax: [[1, 0, 0], u, [0, -u[2], u[1]]], w: 1.4, h: L, d: 0.9, col: shade(RU, 0.9), r: 0.1, dec: { f: rust(1.4, L) } });
          s += box3(C, { c: [x, PY - 1.6, 8.6], w: 1.9, h: 1.6, d: 14, col: RU, r: 0.2, dec: { f: rust(14, 1.6), t: rust(1.9, 14) } }); });
        // plank
        const gr = (w, h, n, sd) => { const Q = rng(sd); let o = ''; for (let i = 0; i < n; i++) { const y = Q() * h, a = (Q() - 0.5) * 0.6; o += '<path d="M0 ' + f1(y) + 'Q' + f1(w * 0.3) + ' ' + f1(y + a) + ' ' + f1(w * 0.55) + ' ' + f1(y - a * 0.6) + 'T' + f1(w) + ' ' + f1(y + a * 0.3) + '" stroke="' + (Q() < 0.5 ? '#a8783e' : '#c2914e') + '" stroke-width="' + f1(0.06 + Q() * 0.12) + '" fill="none" opacity="0.7"/>'; } return o; };
        const knot = (x, y, r) => '<ellipse cx="' + x + '" cy="' + y + '" rx="' + f1(r * 1.7) + '" ry="' + r + '" fill="#a8743a" opacity="0.6"/><ellipse cx="' + x + '" cy="' + y + '" rx="' + f1(r * 0.9) + '" ry="' + f1(r * 0.55) + '" fill="#6a4220"/><ellipse cx="' + (x - 0.2) + '" cy="' + (y - 0.1) + '" rx="' + f1(r * 0.4) + '" ry="' + f1(r * 0.25) + '" fill="#3a2410"/>';
        const top = gr(94, 16.4, 26, 'pt') + knot(18, 6, 1.2) + knot(70, 11, 0.9) + '<circle cx="54" cy="9" r="3.6" fill="none" stroke="#6a4220" stroke-width="0.7" opacity="0.4"/><circle cx="54" cy="9" r="3.2" fill="#4a2a10" opacity="0.12"/>'
          + '<circle cx="31" cy="12" r="2.2" fill="none" stroke="#7a4a22" stroke-width="0.25" opacity="0.5"/><path d="M8 14l6 -0.4M80 3l7 0.3" stroke="#8a6438" stroke-width="0.15" opacity="0.6"/>';
        const front = gr(94, 2.6, 4, 'pf') + '<path d="M0 0.2H94" stroke="#f2d4a0" stroke-width="0.25" opacity="0.8"/>' + knot(40, 1.3, 0.6) + rep(6, () => '<path d="M' + f1(R() * 92) + ' ' + f1(0.6 + R() * 1.4) + 'l' + f1(1 + R() * 2) + ' 0.2" stroke="#8a5a2a" stroke-width="0.12"/>').join('');
        s += box3(C, { c: [0, PY, 0.6 + 8.4], w: 94, h: 2.6, d: 16.8, col: PN, r: 0.3, dec: { f: front, t: top } });
        [-44.2, 44.2].forEach(x => s += box3(C, { c: [x, PY, 0.6 + 8.4], w: 0.1, h: 2.6, d: 16.8, col: '#c8986a', r: 0 }));
        // hanging things under the plank front: cup hook + tea towel, spider on a thread
        const hk = [41, PY, PZ - 1.6], hq = C.P(hk), k = C.k;
        let tw = '<path d="M' + f1(hq[0] - 4.6 * k) + ' ' + f1(hq[1] + 1 * k) + 'L' + f1(hq[0] + 4.6 * k) + ' ' + f1(hq[1] + 1 * k) + 'L' + f1(hq[0] + 4.2 * k) + ' ' + f1(hq[1] + 13 * k) + 'Q' + f1(hq[0]) + ' ' + f1(hq[1] + 13.8 * k) + ' ' + f1(hq[0] - 4.2 * k) + ' ' + f1(hq[1] + 13 * k) + 'Z" fill="url(#pnTw)"/>'
          + '<path d="M' + f1(hq[0] - 4.6 * k) + ' ' + f1(hq[1] + 1 * k) + 'Q' + f1(hq[0]) + ' ' + f1(hq[1] - 0.4 * k) + ' ' + f1(hq[0] + 4.6 * k) + ' ' + f1(hq[1] + 1 * k) + 'Q' + f1(hq[0]) + ' ' + f1(hq[1] + 2.6 * k) + ' ' + f1(hq[0] - 4.6 * k) + ' ' + f1(hq[1] + 1 * k) + 'Z" fill="#b82a2a"/>'
          + '<path d="M' + f1(hq[0] - 4.2 * k) + ' ' + f1(hq[1] + 11.6 * k) + 'H' + f1(hq[0] + 4.2 * k) + '" stroke="#ffffff" stroke-width="' + f1(0.5 * k) + '" opacity="0.8"/>' + rep(7, i => '<path d="M' + f1(hq[0] - 4 * k + i * 1.33 * k) + ' ' + f1(hq[1] + 13 * k) + 'v' + f1(0.9 * k) + '" stroke="#e8d8c8" stroke-width="' + f1(0.18 * k) + '"/>').join('');
        s += swayAt(C, hk, 3, 4.6, 0.3, tw) + line3(C, [[41, PY, PZ - 1.6], [41, PY - 0.8, PZ - 1.6], [41.6, PY - 1.4, PZ - 1.2]], 0.3, '#c8a048');
        const sp = C.P([-10, PY, 10]);
        s += '<g>' + at('translate', '0 0;0 ' + f1(4 * k) + ';0 ' + f1(1.4 * k) + ';0 0', 9, 0, SPL(3)) + '<path d="M' + f1(sp[0]) + ' ' + f1(sp[1] - 9 * k) + 'V' + f1(sp[1] + 6 * k) + '" stroke="#ffffff" stroke-width="0.12" opacity="0.7"/><g transform="translate(' + f1(sp[0]) + ' ' + f1(sp[1] + 6.6 * k) + ') scale(' + f1(k) + ')"><path d="M-1.4 -0.6l-0.8 -0.6M-1.4 0l-1 0M-1.4 0.6l-0.8 0.6M1.4 -0.6l0.8 -0.6M1.4 0l1 0M1.4 0.6l0.8 0.6" stroke="#2a2420" stroke-width="0.18"/><ellipse rx="1" ry="0.8" fill="#2a2420"/><circle cy="-0.8" r="0.5" fill="#3a3430"/></g></g>';
        // shelf contents (back to front, left to right)
        const Y = PT;
        // mason jar with wooden spoons + spatula
        const sp1 = line3(C, [[-40, Y + 1, 6], [-41.6, Y + 16, 5.4]], 0.7, '#c8945a') + ell3(C, -41.7, Y + 16.6, 5.4, 1.4, '#c8945a') + line3(C, [[-38.4, Y + 1, 6.6], [-37.4, Y + 14.4, 7]], 0.6, '#a87444') + poly3(C, [[-38.6, Y + 13.4, 7], [-35.6, Y + 13.8, 7], [-36, Y + 18, 7], [-38.4, Y + 17.4, 7]], '#3a3a3a') + line3(C, [[-39, Y + 1, 7.4], [-39.6, Y + 13, 7.8]], 0.5, '#d8a86a');
        s += jar(C, -39, Y, 7, 3.6, 9.4, sp1) + cyl3(C, [-39, Y + 9.4, 7], [-39, Y + 10.4, 7], 3.7, '#b8b4a8', { n: 18 });
        s += WD(C, -41.6, Y + 6.6, 10.75, '<rect width="5" height="3.4" rx="0.3" fill="#f4ecd4" opacity="0.9"/><text x="2.5" y="2.2" text-anchor="middle" font-family="' + "'Segoe Print','Comic Sans MS',cursive" + '" font-size="1.3" fill="#5a3a22">spoons</text>');
        // mugs
        s += mugH(C, -27.6, Y, 7.6, 3.2, 7, '#f6f2ea', -1) + mugC(C, -27.6, Y, 7.6, 3.2, 7, '#f6f2ea', '#6a4020') + WD(C, -30.2, Y + 5.4, 10.85, '<text x="2.6" y="1.4" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="1.6" fill="#c83a2a">#1 COOK</text>') + poly3(C, [[-25.4, Y + 7, 10.1], [-24.6, Y + 6.2, 10.2], [-24.8, Y + 7, 10]], '#c8b8a0');
        s += mugC(C, -20, Y, 5, 2.9, 6.2, '#e0a030') + mugH(C, -20, Y, 5, 2.9, 6.2, '#e0a030', 1);
        // dented tin can + label
        s += cyl3(C, [-11.4, Y, 6.4], [-11.4, Y + 7, 6.4], 2.8, '#c4c8cc', { n: 18, mat: 'gloss' }) + cyl3(C, [-11.4, Y + 1.2, 6.4], [-11.4, Y + 5.8, 6.4], 2.86, '#c8402e', { n: 18 }) + WD(C, -13.6, Y + 4.6, 9.3, '<text x="2.2" y="0.6" text-anchor="middle" font-family="Georgia,serif" font-weight="700" font-size="1.5" fill="#f6e8c0">BEANS</text><ellipse cx="3.6" cy="-0.6" rx="0.9" ry="1.6" fill="#000000" opacity="0.18"/>');
        // cookbook leaning on the wall
        const A = 0.2, ax = [[1, 0, 0], [0, Math.cos(A), -Math.sin(A)], [0, Math.sin(A), Math.cos(A)]];
        s += box3(C, { c: [1, Y, 3.4], ax, w: 12, h: 15.6, d: 1.8, col: '#7a2a2a', r: 0.3, dec: { f: '<rect x="1" y="1" width="10" height="13.6" rx="0.4" fill="none" stroke="#e8c87a" stroke-width="0.25"/><text x="6" y="5" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-size="1.7" fill="#f2dca0">Grandma\'s</text><text x="6" y="7.2" text-anchor="middle" font-family="Georgia,serif" font-size="1.5" fill="#f2dca0">Recipes</text><ellipse cx="4" cy="11.6" rx="1.6" ry="1" fill="#3a1414" opacity="0.4"/><rect y="9.4" width="1.4" height="1" fill="#f6e8c0"/>', t: '<rect width="12" height="1.8" fill="#f2ead4"/>' } });
        // blue salt tub
        s += cyl3(C, [10.4, Y, 8], [10.4, Y + 7, 8], 2.6, '#2f5ba8', { n: 18, mat: 'gloss', capCol: '#f4f4f0' }) + WD(C, 8.3, Y + 4.8, 10.65, '<text x="2.1" y="0.6" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="1.4" fill="#ffffff">SALT</text><path d="M0.6 1.6h3" stroke="#f2d04a" stroke-width="0.4"/>');
        // potted pothos + trailing vines (sway)
        const PX = 24, PZp = 9;
        s += cyl3(C, [PX, Y, PZp], [PX, Y + 4.8, PZp], 3.4, '#c06a3c', { n: 18, capCol: '#4a3020' }) + cyl3(C, [PX, Y + 4.2, PZp], [PX, Y + 5.4, PZp], 3.8, '#c8744a', { n: 18, capCol: '#3a2618' });
        const leaf = (x, y, z, sc, rot, c) => { const q = C.P([x, y, z]); return '<g transform="translate(' + f1(q[0]) + ' ' + f1(q[1]) + ') rotate(' + rot + ') scale(' + f1(C.k * sc) + ')"><path d="M0 0C-1.6 -0.6 -1.8 -2.6 0 -3.4C1.8 -2.6 1.6 -0.6 0 0Z" fill="' + c + '"/><path d="M0 -0.2V-3" stroke="#d8e8a0" stroke-width="0.12" opacity="0.7"/><path d="M-0.6 -2.2Q0 -2 0.4 -1.2" stroke="#e8f0b0" stroke-width="0.2" opacity="0.5"/></g>'; };
        let pl = ''; [[-1.6, 8, 0.4, -30], [1.8, 8.6, 0.2, 25], [0, 10, -0.6, 0], [-2.8, 6.4, 1, -60], [2.8, 6.8, 0.8, 55], [-0.6, 7, 1.6, -10], [1, 9.2, 1, 15]].forEach(([dx, dy, dz, r], i) => pl += leaf(PX + dx, Y + dy, PZp + dz, 1.1, r, i % 3 ? '#5aa04a' : '#7ab85a'));
        s += pl;
        [[PX + 1.6, 6, 0.4, 0], [PX + 3.4, 4, 1.2, 1.6]].forEach(([vx, n, dz, ph]) => { const root = [vx, Y + 4, PZp + 3], tip = [vx + 1.4, PY - 14 + n, PZ + 0.6 + dz], P = rep(7, i => { const t = i / 6; return [root[0] + (tip[0] - root[0]) * t + Math.sin(t * 4) * 0.6, root[1] + (tip[1] - root[1]) * t * t * 0.9 + (t > 0.3 ? 0 : 1.6 * t), root[2] + (tip[2] - root[2]) * Math.min(1, t * 2.4)]; });
          let v = line3(C, P, 0.32, '#4a7a32'); P.slice(1).forEach((p, i) => v += leaf(p[0] + (i % 2 ? 0.6 : -0.6), p[1], p[2], 0.85, i % 2 ? 50 : -40 + 180 * (i % 3 === 2 ? 1 : 0) * 0, i % 2 ? '#62a84e' : '#4e9440'));
          s += swayAt(C, root, 2.4, 5.4 + ph, ph, v); });
        // upside-down bowls
        s += cyl3(C, [36, Y, 8], [36, Y + 2.6, 8], 4.2, '#e8e2d0', { n: 20, mat: 'gloss', capCol: '#e0d8c4' }) + cyl3(C, [36, Y + 2.6, 8], [36, Y + 4.6, 8], 3.8, '#9ab8a8', { n: 20, mat: 'gloss', capCol: '#8aa898' }) + ell3(C, 36, Y + 4.6, 8, 1.4, '#7a9888');
        return { defs: DEF19 + '<defs><pattern id="pnTw" width="2.4" height="2.4" patternUnits="userSpaceOnUse"><rect width="2.4" height="2.4" fill="#f4ece0"/><rect width="1.2" height="2.4" fill="#c83030" opacity="0.6"/><rect width="2.4" height="1.2" fill="#c83030" opacity="0.6"/></pattern></defs>', front: s, bb: C.bb(3) }; };
      return D; };

    // KIT-034 white laminate wall cabinets: a double-door + single-door upper on cheap white melamine with yellowed edge banding (one strip peeling + curling),
    // chrome bar pulls, a sagging left door, the single door left ajar (shelf of cans, peanut butter, cereal inside), fingerprints + a grease smudge, dino sticker,
    // dusty top with a wicker basket + cookie tin, under-cabinet light strip (flickers now and then) and 3 mugs on hooks that sway
    N.lam27 = S => { const D = { w: 98, d: 26, mount: 'wall', elev: 46, build: () => [] };
      D.fx = ctx => { const C = camW(ctx), R = rng('lam27'), WH = '#f2f1ea', EB = '#e8e2c8', Y0 = 4, HH = 32, DZ = 14, k = C.k;
        ext(C, [[-50, Y0 + HH + 12, 0], [50, Y0 - 14, 0]]);
        let s = WD(C, -48, Y0 + HH + 1, 0.05, '<rect width="96" height="' + (HH + 3) + '" rx="2" fill="#000000" opacity="0.3" filter="url(#m10b3)"/>');
        // under-cabinet light glow on the wall below
        s += WD(C, -44, Y0 - 0.6, 0.06, '<rect width="54" height="14" fill="url(#lmGl)" opacity="0.9">' + an('opacity', '0.9;0.9;0.3;0.9;0.5;0.9;0.9', 13, 0, ' keyTimes="0;0.7;0.71;0.73;0.74;0.76;1"') + '</rect>');
        const spk = (w, h, n) => rep(n, () => '<circle cx="' + f1(R() * w) + '" cy="' + f1(R() * h) + '" r="' + f1(0.07 + R() * 0.08) + '" fill="#b8b4a4" opacity="0.5"/>').join('');
        const fp = (x, y) => '<ellipse cx="' + x + '" cy="' + y + '" rx="0.7" ry="0.95" fill="#c8b890" opacity="0.14"/><ellipse cx="' + (x + 1.1) + '" cy="' + (y - 0.4) + '" rx="0.6" ry="0.85" fill="#c8b890" opacity="0.12"/>';
        // left double-door cabinet (x -46..14)
        const L0 = -46, L1 = 14, LW = L1 - L0, LC = (L0 + L1) / 2;
        const topDust = (w) => '<rect width="' + w + '" height="' + DZ + '" fill="#d8d2bc" opacity="0.35"/>' + spk(w, DZ, 40) + '<rect x="' + f1(w * 0.3) + '" y="2" width="' + f1(w * 0.3) + '" height="' + (DZ - 4) + '" fill="#ffffff" opacity="0.18"/>';
        s += box3(C, { c: [LC, Y0, DZ / 2], w: LW, h: HH, d: DZ, col: WH, r: 0.2, dec: { f: '<rect width="' + LW + '" height="' + HH + '" fill="none" stroke="' + EB + '" stroke-width="0.8"/>', t: topDust(LW), r: '<rect width="' + DZ + '" height="' + HH + '" fill="' + EB + '" opacity="0.4"/>' + spk(DZ, HH, 20) } });
        // doors: left one sags a touch on its hinges
        const door = (x0, w, sag, pull, ex) => { const cx = x0 + w / 2, ax = [[Math.cos(sag), Math.sin(sag), 0], [-Math.sin(sag), Math.cos(sag), 0], [0, 0, 1]];
          return box3(C, { c: [cx, Y0 + 0.4, DZ + 0.45], ax, w: w - 0.6, h: HH - 0.8, d: 0.9, col: WH, r: 0.1, edge: 0.5, dec: { f: '<rect width="' + f1(w - 0.6) + '" height="' + f1(HH - 0.8) + '" fill="url(#lmS)"/>' + spk(w, HH, 30) + '<rect width="' + f1(w - 0.6) + '" height="' + f1(HH - 0.8) + '" fill="none" stroke="' + EB + '" stroke-width="0.35"/>' + (ex || '') } })
            + box3(C, { c: [cx + pull, Y0 + 3, DZ + 1.6], ax, w: 0.7, h: 8, d: 0.6, col: '#c8ccd0', r: 0.2 })
            + [Y0 + 3.6, Y0 + 10.4].map(y => cyl3(C, [cx + pull, y, DZ + 0.9], [cx + pull, y, DZ + 1.4], 0.35, '#a8acb0', { n: 8 })).join(''); };
        s += door(L0, LW / 2, 0.012, LW / 4 - 2.2, fp(25, 22) + '<ellipse cx="8" cy="9" rx="3" ry="1.6" fill="#d0b070" opacity="0.12"/>') + door(LC, LW / 2, 0, -(LW / 4 - 2.2), fp(4, 24) + '<g transform="translate(16 9) rotate(-8)"><path d="M-3 1.6Q-3.4 -1 -1 -1.6Q0 -3.4 1.6 -2.4Q2.4 -1 3.2 -0.8Q3.8 0.6 2.6 1.6Z" fill="#7ac860"/><circle cx="1.6" cy="-2" r="0.25" fill="#2a2a2a"/><path d="M-2.4 1.6v1M1.6 1.6v1" stroke="#5aa840" stroke-width="0.6"/><path d="M-1 -1.2l0.6 -0.8l0.6 0.8" fill="#f2d04a"/></g>');
        // peeling edge banding at the left door's bottom corner (curl)
        const pc = C.P([L0 + 0.4, Y0 + 0.4, DZ + 0.95]);
        s += '<g>' + at('rotate', '0 ' + f1(pc[0]) + ' ' + f1(pc[1]) + ';-3 ' + f1(pc[0]) + ' ' + f1(pc[1]) + ';0 ' + f1(pc[0]) + ' ' + f1(pc[1]), 7, 0, SPL(2)) + '<path d="M' + f1(pc[0] + 0.2 * k) + ' ' + f1(pc[1]) + 'Q' + f1(pc[0] + 3 * k) + ' ' + f1(pc[1] + 1.6 * k) + ' ' + f1(pc[0] + 6 * k) + ' ' + f1(pc[1] + 0.8 * k) + 'q0.6 -0.8 -0.2 -1" stroke="' + EB + '" stroke-width="' + f1(0.6 * k) + '" fill="none" stroke-linecap="round"/></g>' + '<path d="M' + f1(pc[0] + 0.3 * k) + ' ' + f1(pc[1] - 0.2 * k) + 'h' + f1(5.6 * k) + '" stroke="#b8a888" stroke-width="' + f1(0.4 * k) + '" opacity="0.8"/>';
        // right single cabinet (x 16..46) with an open front, interior, then its door ajar
        const R0x = 16, R1x = 46, RW = R1x - R0x, RC = (R0x + R1x) / 2, IN = '#e6e4da';
        const CARC = box3(C, { c: [RC, Y0, DZ / 2], w: RW, h: HH, d: DZ, col: WH, r: 0.2, hole: { f: [1.4, 1.4, 1.4, 1.4] }, dec: { t: topDust(RW), r: '<rect width="' + DZ + '" height="' + HH + '" fill="' + EB + '" opacity="0.4"/>' } });
        const iz0 = 0.8, iz1 = DZ, ix0 = R0x + 1.4, ix1 = R1x - 1.4, iy0 = Y0 + 1.4, iy1 = Y0 + HH - 1.4, mid = Y0 + HH / 2;
        s += poly3(C, [[ix0, iy0, iz0], [ix1, iy0, iz0], [ix1, iy1, iz0], [ix0, iy1, iz0]], shade(IN, 0.86)) + RD.H12.innerW(C, ix0, ix1, iy0, iy1, iz0, iz1, IN, 0.9);
        s += box3(C, { c: [RC, mid - 0.6, (iz0 + iz1) / 2], w: ix1 - ix0, h: 1.2, d: iz1 - iz0 - 0.6, col: WH, r: 0 });
        // lower shelf: cans + peanut butter; upper: cereal box + spices
        const can = (x, y, z, r, h, c, lbl) => cyl3(C, [x, y, z], [x, y + h, z], r, '#c4c8cc', { n: 16, mat: 'gloss' }) + cyl3(C, [x, y + h * 0.2, z], [x, y + h * 0.82, z], r + 0.05, c, { n: 16 }) + (lbl ? WD(C, x - r, y + h * 0.62, z + r + 0.05, '<text x="' + r + '" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="1" fill="#ffffff">' + lbl + '</text>') : '');
        s += can(20.6, iy0, 5, 2.2, 5.4, '#2f7a3a', 'PEAS') + can(25.8, iy0, 6.4, 2.2, 5.4, '#c8402e', 'SOUP') + cyl3(C, [31.6, iy0, 6], [31.6, iy0 + 5.6, 6], 2.6, '#e8b86a', { n: 16, capCol: '#c83a2a' }) + cyl3(C, [31.6, iy0 + 5.6, 6], [31.6, iy0 + 6.8, 6], 2.7, '#c83a2a', { n: 16 });
        s += box3(C, { c: [24, mid, 6], w: 7, h: 12, d: 3, col: '#f2c040', r: 0.2, dec: { f: '<rect width="7" height="12" fill="#f2c040"/><circle cx="3.5" cy="7" r="2.4" fill="#ffffff"/><circle cx="3.5" cy="7" r="1.8" fill="#d8903a"/><text x="3.5" y="3" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="1.4" fill="#c83a2a">O\'s</text>' } });
        [[30, '#c83a2a'], [33, '#6a8a3a'], [36, '#e0a030']].forEach(([x, c]) => s += cyl3(C, [x, mid, 8.4], [x, mid + 4, 8.4], 1.2, '#f2f0e8', { n: 12 }) + cyl3(C, [x, mid + 4, 8.4], [x, mid + 5, 8.4], 1.25, c, { n: 12 }));
        s += CARC; // carcass with its open front drawn over the interior so the face frame + side walls stay on top
        // light strip under the left cabinet
        s += box3(C, { c: [-16, Y0 - 1.2, 11], w: 50, h: 1.2, d: 2, col: '#e8e8e2', r: 0.3 }) + poly3(C, [[-40.6, Y0 - 1.25, 10.4], [8.6, Y0 - 1.25, 10.4], [8.6, Y0 - 1.25, 11.6], [-40.6, Y0 - 1.25, 11.6]], '#fffbe6', 'opacity="0.9"');
        // mug hooks under the left cabinet front, 3 mugs swaying
        [[-38, '#e86a5a', 0], [-30, '#5a9ad8', 1.1], [-22, '#f2f2ea', 2]].forEach(([x, c, ph]) => { const hk = [x, Y0, DZ - 2.6], m = mugC(C, x, Y0 - 7.8, DZ - 2.6, 2.4, 5.4, c) + mugH(C, x, Y0 - 7.8, DZ - 2.6, 2.4, 5.4, c, 1);
          s += line3(C, [[x, Y0, DZ - 2.6], [x, Y0 - 1, DZ - 2.6], [x + 0.8, Y0 - 1.6, DZ - 2.4]], 0.28, '#b8bcc0') + swayAt(C, [x + 2.8, Y0 - 1.4, DZ - 2.6], 3.2, 3.8 + ph * 0.5, ph, m); });
        // ajar door (hinged on its left edge x 16, swung ~110 deg open, so the open cabinet shows)
        const th = 1.95, hx = R0x + 0.2, hz = DZ + 0.45, dw = RW - 0.6, ux = [Math.cos(th), 0, Math.sin(th)], nz = [-Math.sin(th), 0, Math.cos(th)], cx = hx + ux[0] * dw / 2, cz = hz + ux[2] * dw / 2, AX = [ux, [0, 1, 0], nz];
        const dFace = '<rect width="' + f1(dw) + '" height="' + f1(HH - 0.8) + '" fill="url(#lmS)"/>' + spk(dw, HH, 26) + '<rect width="' + f1(dw) + '" height="' + f1(HH - 0.8) + '" fill="none" stroke="' + EB + '" stroke-width="0.35"/>' + fp(dw - 4, 20);
        const dBack = '<rect width="' + f1(dw) + '" height="' + f1(HH - 0.8) + '" fill="#e2e0d6"/><circle cx="' + f1(dw - 2) + '" cy="4" r="0.8" fill="#b8bcc0"/><circle cx="' + f1(dw - 2) + '" cy="' + f1(HH - 5) + '" r="0.8" fill="#b8bcc0"/><rect x="' + f1(dw - 3.4) + '" y="3" width="2.8" height="2" fill="#c8ccd0"/><rect x="' + f1(dw - 3.4) + '" y="' + f1(HH - 6) + '" width="2.8" height="2" fill="#c8ccd0"/>';
        s += box3(C, { c: [cx, Y0 + 0.4, cz], ax: AX, w: dw, h: HH - 0.8, d: 0.9, col: WH, r: 0.1, dec: { f: dFace, b: dBack } });
        { const px = cx + ux[0] * (dw / 2 - 2.4) + nz[0] * 1.2, pz = cz + ux[2] * (dw / 2 - 2.4) + nz[2] * 1.2; s += box3(C, { c: [px, Y0 + 3, pz], ax: AX, w: 0.7, h: 8, d: 0.6, col: '#c8ccd0', r: 0.2 }); }
        [Y0 + 3, Y0 + HH - 5].forEach(y => s += box3(C, { c: [R0x + 0.9, y, DZ + 0.2], w: 1.4, h: 2.2, d: 1, col: '#b8bcc0', r: 0.2 }));
        // dusty top: wicker basket + cookie tin
        const TY = Y0 + HH;
        s += box3(C, { c: [-30, TY, 7], w: 14, h: 6, d: 9, col: '#c8a060', r: 0.8, dec: { f: rep(6, i => '<path d="M0 ' + (i + 0.5) + 'H14" stroke="#8a6430" stroke-width="0.3"/>').join('') + rep(10, i => '<path d="M' + (i * 1.4 + 0.7) + ' 0V6" stroke="#a87e44" stroke-width="0.2"/>').join(''), t: '<rect x="1" y="1" width="12" height="7" fill="#5a3e20" opacity="0.5"/>' } });
        s += cyl3(C, [-12, TY, 7], [-12, TY + 4, 7], 4.6, '#2e5a8a', { n: 22, mat: 'gloss', capCol: '#2e5a8a', cap: cr => '<circle r="' + f1(cr) + '" fill="#3a6a9a"/><circle r="' + f1(cr * 0.7) + '" fill="none" stroke="#e8c870" stroke-width="' + f1(cr * 0.05) + '"/><circle r="' + f1(cr * 0.3) + '" fill="#e8c870" opacity="0.6"/>' }) + WD(C, -15.4, TY + 2.6, 11.65, '<text x="3.4" text-anchor="middle" font-family="Georgia,serif" font-weight="700" font-size="1.2" fill="#f2dc98">BUTTER</text>');
        return { defs: DEF19 + '<defs><linearGradient id="lmS" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.75" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#c8c4b0" stop-opacity="0.25"/></linearGradient><linearGradient id="lmGl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff6d4" stop-opacity="0.8"/><stop offset="1" stop-color="#fff6d4" stop-opacity="0"/></linearGradient></defs>', front: s, bb: C.bb(3) }; };
      return D; };

    // KIT-054 glass-front mullion china hutch (floor piece, real solids): creamy painted shaker base (2 doors + 3 drawers, brass knobs + cup pulls), honed marble counter,
    // upper cabinet with 2 glass doors of 6 panes each (mullions glued to the centre stile, glass = fx panes that hide from behind), warm-lit interior (glowing back panels +
    // light cones that breathe), blue-and-white plates on a plate rail, teacups on saucers + bowl stacks, tureen + pitcher + plate stacks, crown moulding; cake stand on the counter
    { const K2 = X.K, { box, cyl, ball, slab, slabX, disc } = K2, { W_, M_, PL, em, rod } = RD.H16, { glue } = RD.H22, { face, qd } = RD.H23;
      N.china27 = S => { const PA = '#ece6d6', PD = shade(PA, 0.9), MB = '#e9e6e0', BR2 = '#c99a3e', W = 100, Dp = 40, WU = 96, DU = 20, ZU = -Dp / 2 + DU / 2 + 1, Y1 = 46, HU = 84, ZF = ZU + DU / 2, BW = (WU - 8) / 2, SH = [76, 104];
        const BAYS = []; [-1, 1].forEach(sg => [Y1 + 2, SH[0] + 1.6, SH[1] + 1.6].forEach((b, j) => BAYS.push({ cx: sg * (BW / 2 + 0.75), b, t: j < 2 ? SH[j] : Y1 + 2 + HU, j })));
        return { w: 104, d: 46, build: () => { const o = [], on = glue(o);
          o.push(box(0, 0, 0, W - 8, 5, Dp - 8, '#3a3630', W_({ r: 0.4 })));
          const LC = box(0, 5, 0, W, 38, Dp, PA, PL({ r: 0.6 })); o.push(LC);
          // doors (shaker: slab + 4 frame rails glued), drawers in the middle
          [-34.5, 34.5].forEach(x => { const DR = on(LC, [box(x, 7, Dp / 2 + 0.45, 28, 34, 0.8, PA, PL({ r: 0.5 }))], [0, 0, 1])[0];
            on(DR, [box(x, 7, Dp / 2 + 1.15, 28, 3, 0.6, PA, PL({ r: 0.3 })), box(x, 38, Dp / 2 + 1.15, 28, 3, 0.6, PA, PL({ r: 0.3 })), box(x - 12.5, 10, Dp / 2 + 1.15, 3, 28, 0.6, PA, PL({ r: 0.3 })), box(x + 12.5, 10, Dp / 2 + 1.15, 3, 28, 0.6, PA, PL({ r: 0.3 })),
              box(x, 10, Dp / 2 + 0.95, 22, 28, 0.1, PD, { r: 0, noOut: 1 }), ball(x + (x < 0 ? 10.6 : -10.6), 23, Dp / 2 + 1.9, 1.1, BR2, M_({ k: 3, n: 8, shine: 1 }))], [0, 0, 1]); });
          [9, 20.4, 31.8].forEach(y => { const DW = on(LC, [box(0, y, Dp / 2 + 0.45, 36, 10.4, 0.8, PA, PL({ r: 0.5 }))], [0, 0, 1])[0];
            on(DW, [box(0, y + 1.6, Dp / 2 + 0.95, 30, 7.2, 0.1, PD, { r: 0, noOut: 1 }), slabX(0, y + 5.2, Dp / 2 + 1.5, 7, 1.4, 1, BR2, M_({ r: 0.5, shine: 1 }))], [0, 0, 1]); });
          // marble counter + cake stand
          const CT = box(0, 43, 0, W + 4, 3, Dp + 2, MB, { r: 0.8, mat: 'cer', shine: 1 }); o.push(CT);
          on(CT, [slabX(0, 44.2, Dp / 2 + 1.05, W + 2, 0.2, 0.05, '#c8c2b8', { r: 0, noOut: 1 }), cyl(28, 46, 13, 2, 6, '#f6f4ee', { n: 14, mat: 'cer', rg: [[0, 0, 1.6], [1, 0, 0.6], [6, 0, 0.7]] }), cyl(28, 52, 13, 7.4, 0.8, '#f6f4ee', { n: 20, mat: 'cer' }),
            cyl(28, 52.8, 13, 5.6, 4.6, '#f2dc8a', { n: 20, rg: [[0, 0, 1], [4.2, 0, 1], [4.6, 0, 0.92]] }), cyl(28, 57.4, 13, 5.2, 0.6, '#fbf6e6', { n: 18 }), ball(26, 58, 11.4, 0.9, '#f2d43a', { k: 3, n: 8 }), ball(30, 58, 14, 0.9, '#f2d43a', { k: 3, n: 8 }),
            cyl(-30, 46, 12, 5.6, 1.2, '#2f5ba8', { n: 18, mat: 'cer' }), cyl(-30, 47.2, 12, 3.6, 5.4, '#f6f4ee', { n: 18, mat: 'cer', rg: [[0, 0, 0.8], [2.6, 0, 1], [5, 0, 0.62], [5.4, 0, 0.66]] }), ball(-30, 52.4, 12, 1, '#2f5ba8', { k: 3, n: 8 })]);
          // upper cabinet carcass
          o.push(box(0, Y1, ZU, WU, 2, DU, PA, PL({ r: 0.3 })));
          [-1, 1].forEach(sg => o.push(box(sg * (WU / 2 - 2), Y1 + 2, ZU, 4, HU, DU, PA, PL({ r: 0.4 }))));
          const BS = slab(0, Y1 + 2, ZU - DU / 2 + 1, WU - 8, HU, 2, '#f4ead2', W_({ r: 0 })); o.push(BS);
          const TB = box(0, Y1 + 2 + HU, ZU, WU, 4, DU, PA, PL({ r: 0.3 })); o.push(TB);
          o.push(box(0, Y1 + 6 + HU, ZU + 0.8, WU + 6, 2.6, DU + 3.6, PA, PL({ r: 0.6 })), box(0, Y1 + 8.6 + HU, ZU + 1.2, WU + 10, 3, DU + 6, shade(PA, 1.03), PL({ r: 0.8 })));
          BAYS.forEach(B => on(BS, [box(B.cx, B.b + 1, ZU - DU / 2 + 2.05, BW - 3, B.t - B.b - 2.4, 0.1, '#fff1cc', em({ r: 1, op: 0.55 }))], [0, 0, 1]));
          const SB = SH.map(y => { const Q = box(0, y, ZU + 1, WU - 8, 1.6, DU - 2, PA, PL({ r: 0.2 })); o.push(Q); return Q; });
          const BOT = o[o.indexOf(BS) - 3];
          // bay contents (glued to the board they stand on, back row first)
          const plate = (x, y, z, r, par) => { const P = disc(x, y + r, z, r, 0.7, '#2f5ba8', { n: 20, mat: 'cer', shine: 1 }); on(par, [P]); on(P, [disc(x, y + r, z + 0.7, r * 0.9, 0.05, '#f8f6f0', { n: 20, noOut: 1 }), disc(x, y + r, z + 0.75, r * 0.62, 0.05, '#7a9ad0', { n: 18, noOut: 1 }), disc(x, y + r, z + 0.8, r * 0.5, 0.05, '#f8f6f0', { n: 18, noOut: 1 }), disc(x, y + r, z + 0.85, r * 0.26, 0.05, '#2f5ba8', { n: 12, noOut: 1 })], [0, 0, 1]); };
          [-1, 1].forEach(sg => { const bx = sg * (BW / 2 + 0.75);
            [-14, 0, 14].forEach(dx => plate(bx + dx, SH[1] + 1.6, ZU - DU / 2 + 2.4, 6.4, SB[1]));
            on(SB[1], [rod([bx - BW / 2 + 0.4, SH[1] + 4.4, ZU - DU / 2 + 4.6], [bx + BW / 2 - 0.4, SH[1] + 4.4, ZU - DU / 2 + 4.6], 0.35, BR2, M_({ n: 8, shine: 1 }))]);
            [-13, 0, 13].forEach((dx, i) => { const x = bx + dx, yb = SH[0] + 1.6; on(SB[0], [cyl(x, yb, ZU - 4, 5.2, 1.3, '#f6f4ee', { n: 18, mat: 'cer' }), cyl(x, yb + 1.3, ZU - 4, 4.6, 1.3, '#f6f4ee', { n: 18, mat: 'cer' }), cyl(x, yb + 2.6, ZU - 4, 4, 1.3, '#f6f4ee', { n: 18, mat: 'cer' })]);
              on(SB[0], [cyl(x, yb, ZU + 5, 4, 0.6, '#f6f4ee', { n: 18, mat: 'cer' }), cyl(x, yb + 0.6, ZU + 5, 2.6, 4, i === 1 ? '#2f5ba8' : '#f6f4ee', { n: 16, mat: 'cer', rg: [[0, 0, 0.6], [1.2, 0, 0.9], [4, 0, 1]] }), cyl(x, yb + 4.4, ZU + 5, 2.4, 0.2, '#7a5030', { n: 14, noOut: 1 })]); });
            const yb = Y1 + 2; on(BOT, [cyl(bx - 12, yb, ZU - 3, 6.6, 1, '#f6f4ee', { n: 20, mat: 'cer' }), cyl(bx - 12, yb + 1, ZU - 3, 6.6, 1, '#2f5ba8', { n: 20, mat: 'cer' }), cyl(bx - 12, yb + 2, ZU - 3, 6.6, 1, '#f6f4ee', { n: 20, mat: 'cer' }), cyl(bx - 12, yb + 3, ZU - 3, 6.6, 1, '#f6f4ee', { n: 20, mat: 'cer' })]);
            if (sg < 0) on(BOT, [cyl(bx + 8, yb, ZU - 1, 6, 9, '#f6f4ee', { n: 20, mat: 'cer', rg: [[0, 0, 0.6], [1, 0, 0.8], [5, 0, 1], [8, 0, 0.8], [9, 0, 0.5]] }), ball(bx + 8, yb + 9, ZU - 1, 1.2, '#2f5ba8', { k: 3, n: 8 })]);
            else on(BOT, [cyl(bx + 8, yb, ZU - 1, 4.2, 14, '#f6f4ee', { n: 18, mat: 'cer', rg: [[0, 0, 0.8], [6, 0, 1], [11, 0, 0.62], [14, 0, 0.8]] }), cyl(bx + 8, yb + 5, ZU - 1, 4.25, 2, '#2f5ba8', { n: 18, noOut: 1 })]); });
          // front frame: centre stile (sorted) + door rails / mullions glued to it
          const ST = box(0, Y1 + 2, ZF - 0.4, 3.4, HU, 1.2, PA, PL({ r: 0.2 })); o.push(ST);
          const fr = []; [-1, 1].forEach(sg => { const x0 = sg > 0 ? 1.7 : -(WU / 2 - 4), x1 = sg > 0 ? WU / 2 - 4 : -1.7, cx = (x0 + x1) / 2, w = x1 - x0, zf = ZF + 0.25;
            fr.push(box(cx, Y1 + 2, zf, w, 2.6, 0.6, PA, PL({ r: 0.2 })), box(cx, Y1 + HU - 0.6, zf, w, 2.6, 0.6, PA, PL({ r: 0.2 })), box(x0 + 1.2, Y1 + 4.6, zf, 2.4, HU - 5.2, 0.6, PA, PL({ r: 0.2 })), box(x1 - 1.2, Y1 + 4.6, zf, 2.4, HU - 5.2, 0.6, PA, PL({ r: 0.2 })));
            SH.forEach(y => fr.push(box(cx, y - 0.4, zf, w - 4.8, 2.4, 0.6, PA, PL({ r: 0.2 }))));
            [[Y1 + 4.6, SH[0] - 0.4], [SH[0] + 2, SH[1] - 0.4], [SH[1] + 2, Y1 + HU - 0.6]].forEach(([a, b]) => fr.push(box(cx, a, zf + 0.1, 1.4, b - a, 0.4, PA, PL({ r: 0.1 }))));
            fr.push(ball(sg > 0 ? x0 + 2.6 : x1 - 2.6, Y1 + HU / 2, zf + 1.2, 0.9, BR2, M_({ k: 3, n: 8, shine: 1 }))); });
          on(ST, fr, [0, 0, 1]);
          return o; },
          fx: c => { const f0 = face(c, 0, 1); if (f0 < 0.08) return {}; let f = '';
            BAYS.forEach((B, i) => { const x0 = B.cx - BW / 2 + 0.6, x1 = B.cx + BW / 2 - 0.6, z = ZU - DU / 2 + 2.2;
              f += '<path d="' + qd(c, [[x0 + 4, B.t - 0.3, z + 1], [x1 - 4, B.t - 0.3, z + 1], [x1, B.b + 0.4, ZF - 1], [x0, B.b + 0.4, ZF - 1]]) + '" fill="url(#c54L)" opacity="0.6">' + an('opacity', '0.5;0.72;0.5', 8, n4(-i * 1.3), SPL(2)) + '</path>'; });
            [-1, 1].forEach(sg => { const x0 = sg > 0 ? 1.7 : -(WU / 2 - 4), x1 = sg > 0 ? WU / 2 - 4 : -1.7, z = ZF + 0.3, y0 = Y1 + 2, y1 = Y1 + 2 + HU;
              f += '<path d="' + qd(c, [[x0, y1, z], [x1, y1, z], [x1, y0, z], [x0, y0, z]]) + '" fill="#e6f4f6" opacity="' + n4(0.08 * f0) + '"/>';
              const w = x1 - x0; f += '<path d="' + qd(c, [[x0 + w * 0.12, y1, z], [x0 + w * 0.3, y1, z], [x0 + w * 0.08, y0, z], [x0 - w * 0.02 + 0.2, y0, z]]) + '" fill="#ffffff" opacity="' + n4(0.12 * f0) + '"/><path d="' + qd(c, [[x0 + w * 0.42, y1, z], [x0 + w * 0.47, y1, z], [x0 + w * 0.3, y0, z], [x0 + w * 0.25, y0, z]]) + '" fill="#ffffff" opacity="' + n4(0.08 * f0) + '"/>'; });
            return { defs: '<linearGradient id="c54L" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff2c8" stop-opacity="0.7"/><stop offset="1" stop-color="#fff2c8" stop-opacity="0"/></linearGradient>', front: f }; } }; };
    }

    // ---------- KIT-074 / KIT-094 (floor hutches, real solids + fx interiors) ----------
    { const K2 = X.K, { box, cyl, ball, slab, slabX, disc } = K2, { W_, M_, PL, em, rod, frame } = RD.H16, { glue, R0: R0w } = RD.H22, { face, qd } = RD.H23;
      const FP = (c, P) => { const q = c.p(P[0], P[1], P[2]); return [q[0], q[1]]; };
      const vY = c => { const a = c.p(0, 0, 0), b = c.p(0, 1, 0); return [b[0] - a[0], b[1] - a[1]]; };
      const KT = n => ' keyTimes="' + rep(n + 1, i => n4(i / n)).join(';') + '"';
      // brass two-tier lazy susan of spice jars, turning (front/back halves swap round the post)
      const carousel = (c, cx, y0, cz, T, ph, cols) => { const NK = 24, k = c.k, vy = vY(c), C0 = FP(c, [cx, y0, cz]); let back = '', front = '', base = '';
        const tier = (y, r, n, jr, jh, ti) => { let b = '', f = ''; const ctr = FP(c, [cx, y, cz]), ry = Math.abs(FP(c, [cx, y, cz + r])[1] - ctr[1]);
          base += '<ellipse cx="' + f1(ctr[0]) + '" cy="' + f1(ctr[1] + 0.5 * k) + '" rx="' + f1((r + 1.6) * k) + '" ry="' + f1(ry * (r + 1.6) / r + 0.5 * k) + '" fill="#6a4a14"/><ellipse cx="' + f1(ctr[0]) + '" cy="' + f1(ctr[1]) + '" rx="' + f1((r + 1.6) * k) + '" ry="' + f1(ry * (r + 1.6) / r) + '" fill="url(#k74b)"/><ellipse cx="' + f1(ctr[0]) + '" cy="' + f1(ctr[1]) + '" rx="' + f1((r + 1.2) * k) + '" ry="' + f1(ry * (r + 1.2) / r) + '" fill="none" stroke="#fff2c0" stroke-width="' + f1(0.25 * k) + '" opacity="0.7"/>';
          for (let i = 0; i < n; i++) { const pos = [], fr = []; for (let j = 0; j <= NK; j++) { const a = ph + 2 * PI * (i / n + j / NK), q = FP(c, [cx + Math.sin(a) * r, y, cz + Math.cos(a) * r]); pos.push(f1(q[0]) + ' ' + f1(q[1])); fr.push(q[1] > ctr[1] ? 1 : 0); }
            const col = cols[(i + ti * 3) % cols.length], hh = jh * Math.hypot(vy[0], vy[1]), rx = jr * k, ry2 = Math.max(0.3, ry * jr / r);
            const J = '<path d="M' + f1(-rx) + ' 0V' + f1(-hh) + 'H' + f1(rx) + 'V0A' + f1(rx) + ' ' + f1(ry2) + ' 0 0 1 ' + f1(-rx) + ' 0Z" fill="' + col + '"/><path d="M' + f1(-rx) + ' ' + f1(-hh * 0.82) + 'V' + f1(-hh) + 'H' + f1(rx) + 'V' + f1(-hh * 0.82) + 'Z" fill="#f4f4ee" opacity="0.5"/>'
              + '<rect x="' + f1(-rx) + '" y="' + f1(-hh * 0.6) + '" width="' + f1(2 * rx) + '" height="' + f1(hh * 0.28) + '" fill="#f6efdc"/><path d="M' + f1(-rx * 0.6) + ' ' + f1(-hh * 0.47) + 'h' + f1(rx * 1.2) + '" stroke="#5a4020" stroke-width="' + f1(0.18 * k) + '"/>'
              + '<ellipse cy="' + f1(-hh) + '" rx="' + f1(rx * 1.05) + '" ry="' + f1(ry2 * 1.05) + '" fill="url(#k74b)"/><rect x="' + f1(-rx * 1.05) + '" y="' + f1(-hh - 0.9 * k) + '" width="' + f1(rx * 2.1) + '" height="' + f1(0.9 * k) + '" fill="url(#k74v)"/><ellipse cy="' + f1(-hh - 0.9 * k) + '" rx="' + f1(rx * 1.05) + '" ry="' + f1(ry2 * 1.05) + '" fill="#e8c46a"/>'
              + '<path d="M' + f1(-rx * 0.6) + ' ' + f1(-hh * 0.1) + 'V' + f1(-hh * 0.78) + '" stroke="#ffffff" stroke-width="' + f1(0.4 * k) + '" opacity="0.55"/>';
            const mv = '<animateTransform attributeName="transform" type="translate" values="' + pos.join(';') + '" dur="' + T + 's"' + KT(NK) + ' repeatCount="indefinite"/>';
            const op = v => '<animate attributeName="opacity" values="' + fr.map(x => x === v ? 1 : 0).join(';') + '" dur="' + T + 's"' + KT(NK) + ' calcMode="discrete" repeatCount="indefinite"/>';
            b += '<g opacity="' + (fr[0] ? 0 : 1) + '">' + op(0) + '<g>' + mv + J + '</g></g>'; f += '<g opacity="' + fr[0] + '">' + op(1) + '<g>' + mv + J + '</g></g>'; }
          return [b, f]; };
        const t1 = tier(y0 + 0.6, 7.4, 8, 1.5, 4.4, 0), t2 = tier(y0 + 8.6, 5.4, 6, 1.3, 3.8, 1);
        const pa = FP(c, [cx, y0, cz]), pb = FP(c, [cx, y0 + 15, cz]), post = '<path d="M' + f1(pa[0]) + ' ' + f1(pa[1]) + 'L' + f1(pb[0]) + ' ' + f1(pb[1]) + '" stroke="#8a6420" stroke-width="' + f1(1.3 * k) + '"/><path d="M' + f1(pa[0] - 0.3 * k) + ' ' + f1(pa[1]) + 'L' + f1(pb[0] - 0.3 * k) + ' ' + f1(pb[1]) + '" stroke="#fff0b8" stroke-width="' + f1(0.35 * k) + '"/><circle cx="' + f1(pb[0]) + '" cy="' + f1(pb[1]) + '" r="' + f1(1.3 * k) + '" fill="url(#k74b)"/>';
        const b1 = base.split('<ellipse').length; void b1;
        const bs = base.match(/<ellipse[^>]*\/>/g) || [], base1 = bs.slice(0, 3).join(''), base2 = bs.slice(3).join('');
        return '<ellipse cx="' + f1(C0[0]) + '" cy="' + f1(C0[1] + 1 * k) + '" rx="' + f1(10 * k) + '" ry="' + f1(3 * k) + '" fill="#000000" opacity="0.25" filter="url(#k74f)"/>' + base1 + t1[0] + post.replace(/<circle[^>]*\/>/, '') + t1[1] + base2 + t2[0] + post.match(/<circle[^>]*\/>/)[0] + t2[1]; };
      const DEF74 = '<linearGradient id="k74b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset="0.45" stop-color="#d8a848"/><stop offset="1" stop-color="#8a6420"/></linearGradient><linearGradient id="k74v" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8a6420"/><stop offset="0.4" stop-color="#f6dc96"/><stop offset="1" stop-color="#9a7228"/></linearGradient><filter id="k74f" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1"/></filter>';

      // KIT-074 walk-in butler's pantry: deep green lacquered cabinetry with brass bin pulls + labelled spice drawers, Calacatta counter,
      // open walnut shelves lit by warm LED strips (glass canisters of pasta / rice / beans / oats, copper pots, cookbooks, olive oil + wine), brass back rail
      // with copper ladles, and two brass two-tier spice carousels on the counter slowly turning
      N.butler27 = S => { const GR = '#2f4a3c', GL = shade(GR, 1.12), BR2 = '#c99a3e', WAL = '#5a3820', MB = '#f2efe9', W = 100, Dp = 40, WU = 98, DU = 22, ZU = -Dp / 2 + DU / 2 + 1, Y1 = 46, HU = 84, ZF = ZU + DU / 2, SH = [70, 94];
        return { w: 104, d: 46, build: () => { const o = [], on = glue(o), R = R0w('but27');
          o.push(box(0, 0, 0, W - 6, 4, Dp - 6, '#1e2a22', PL({ r: 0.4 })));
          const LC = box(0, 4, 0, W, 39, Dp, GR, PL({ r: 0.6, shine: 1 })); o.push(LC);
          on(LC, [slabX(0, 4.6, Dp / 2 + 0.05, W - 2, 0.6, 0.1, BR2, M_({ r: 0, noOut: 1 }))], [0, 0, 1]);
          [-33, 33].forEach(x => { const DR = on(LC, [box(x, 7, Dp / 2 + 0.45, 32, 34, 0.8, GR, PL({ r: 0.5, shine: 1 }))], [0, 0, 1])[0];
            on(DR, [box(x, 7, Dp / 2 + 1.15, 32, 3, 0.6, GL, PL({ r: 0.3 })), box(x, 38, Dp / 2 + 1.15, 32, 3, 0.6, GL, PL({ r: 0.3 })), box(x - 14.5, 10, Dp / 2 + 1.15, 3, 28, 0.6, GL, PL({ r: 0.3 })), box(x + 14.5, 10, Dp / 2 + 1.15, 3, 28, 0.6, GL, PL({ r: 0.3 })),
              box(x, 10, Dp / 2 + 0.95, 26, 28, 0.1, shade(GR, 0.9), { r: 0, noOut: 1 }), box(x + (x < 0 ? 11 : -11), 30, Dp / 2 + 1.75, 1, 6, 0.8, BR2, M_({ r: 0.3, shine: 1 }))], [0, 0, 1]); });
          [8, 19.6, 31.2].forEach((y, j) => [-8.4, 8.4].forEach(x => { const DW = on(LC, [box(x, y, Dp / 2 + 0.45, 16, 10.6, 0.8, GR, PL({ r: 0.5, shine: 1 }))], [0, 0, 1])[0];
            on(DW, [box(x, y + 6.4, Dp / 2 + 0.95, 6, 2.6, 0.2, BR2, M_({ r: 0.2, shine: 1 })), box(x, y + 6.8, Dp / 2 + 1.2, 4.6, 1.8, 0.05, '#f6efdc', { r: 0, noOut: 1 }), slabX(x, y + 2.6, Dp / 2 + 1.4, 6, 1.4, 1, BR2, M_({ r: 0.5, shine: 1 }))], [0, 0, 1]); }));
          const CT = box(0, 43, 0, W + 4, 3, Dp + 2, MB, { r: 0.8, mat: 'cer', shine: 1 }); o.push(CT);
          const vein = []; [[-40, 3, 0.5, 22], [-6, -8, -0.3, 30], [20, 8, 0.7, 18], [36, -4, -0.6, 20]].forEach(([x, z, yaw, L]) => vein.push(box(x, 46.02, z, L, 0.04, 0.35, '#b8b0a4', { r: 0, yaw, noOut: 1 }), box(x + 4, 46.03, z + 1.2, L * 0.5, 0.04, 0.2, '#c8a868', { r: 0, yaw: yaw + 0.3, noOut: 1 })));
          on(CT, vein.concat([slabX(0, 44.2, Dp / 2 + 1.05, W + 2, 0.2, 0.05, '#c8c2b8', { r: 0, noOut: 1 })]));
          // upper: sides, back, top, crown, walnut shelves with LED strips
          o.push(box(0, Y1, ZU, WU, 2, DU, GR, PL({ r: 0.3 })));
          [-1, 1].forEach(sg => o.push(box(sg * (WU / 2 - 2), Y1 + 2, ZU, 4, HU, DU, GR, PL({ r: 0.4, shine: 1 }))));
          const BS = slab(0, Y1 + 2, ZU - DU / 2 + 1, WU - 8, HU, 2, '#24382e', PL({ r: 0 })); o.push(BS);
          on(BS, [slabX(0, Y1 + 9, ZU - DU / 2 + 2.05, WU - 10, 0.5, 0.1, BR2, M_({ r: 0, noOut: 1 }))], [0, 0, 1]);
          const TB = box(0, Y1 + 2 + HU, ZU, WU, 4, DU, GR, PL({ r: 0.3 })); o.push(TB);
          o.push(box(0, Y1 + 6 + HU, ZU + 0.8, WU + 6, 2.6, DU + 3.6, GR, PL({ r: 0.6, shine: 1 })), box(0, Y1 + 8.6 + HU, ZU + 1.2, WU + 10, 3, DU + 6, GL, PL({ r: 0.8, shine: 1 })));
          on(TB, [slabX(0, Y1 + 5.4 + HU, ZU + DU / 2 + 0.05, WU, 0.5, 0.1, BR2, M_({ r: 0, noOut: 1 }))], [0, 0, 1]);
          const SB = SH.map(y => { const Q = box(0, y, ZU + 1, WU - 8, 2.2, DU - 2, WAL, W_({ r: 0.3 })); o.push(Q); on(Q, [slabX(0, y - 0.05, ZU + DU / 2 - 2.6, WU - 10, 0.3, 0.8, '#fff1c4', em({ r: 0 })), slabX(0, y + 0.4, ZU + DU / 2 + 0.05, WU - 8, 1.4, 0.1, BR2, M_({ r: 0, noOut: 1 }))], [0, 0, 1]); return Q; });
          const BOT = o.find(q => q.col === GR && Math.abs(q.pts[0][1] - Y1) < 0.01 && q.pts.some(p => Math.abs(p[1] - (Y1 + 2)) < 0.01));
          // canisters (glass + contents + walnut lid) on shelf 1; copper pots + cookbooks on shelf 2; bottles + crock on the bottom board
          const can = (par, x, y, z, r, h, fill) => { const G = cyl(x, y, z, r, h, fill, { n: 16, mat: 'cer', shine: 1 }); on(par, [G]); on(G, [cyl(x, y + h, z, r * 1.04, 1.4, WAL, W_({ n: 16 })), ball(x, y + h + 1.4, z, 0.7, BR2, M_({ k: 3, n: 8, shine: 1 })), box(x, y + h * 0.42, z + r + 0.05, r * 1.1, h * 0.28, 0.05, '#f6efdc', { r: 0, noOut: 1 })]); };
          [[-38, '#f2d48a', 11], [-29, '#f6f2e6', 9], [-20.4, '#8a4a2a', 10], [-12, '#e0c890', 8.6], [12, '#f2d48a', 9.6], [20.4, '#c86a3a', 8], [29, '#6a8a3a', 10.4], [38, '#e8d8b0', 9]].forEach(([x, col, h], i) => can(SB[0], x, SH[0] + 2.2, ZU - 2 + (i % 2) * 3, 3.2, h, col));
          [[-30, '#c87a4a', 6.4, 9], [-14, '#b86a3a', 5, 7], [30, '#c87a4a', 5.6, 8]].forEach(([x, col, r, h]) => { const P = cyl(x, SH[1] + 2.2, ZU, r, h, col, M_({ n: 20, shine: 1 })); on(SB[1], [P]); on(P, [cyl(x, SH[1] + 2.2 + h - 0.8, ZU, r + 0.3, 0.8, '#e8a070', M_({ n: 20 })), rod([x - r - 2.6, SH[1] + 2.2 + h - 2, ZU], [x - r, SH[1] + 2.2 + h - 2, ZU], 0.5, '#3a3a3a', M_({ n: 6 })), rod([x + r, SH[1] + 2.2 + h - 2, ZU], [x + r + 2.6, SH[1] + 2.2 + h - 2, ZU], 0.5, '#3a3a3a', M_({ n: 6 }))]); });
          [[0, '#7a2a2a', 13], [2.6, '#2f4a6a', 12], [5, '#e8dcc0', 13.4], [7.4, '#3a5a3a', 11.6], [9.8, '#c89a3a', 12.6]].forEach(([dx, col, h]) => { const B = box(4 + dx, SH[1] + 2.2, ZU - 2, 2.2, h, 9, col, PL({ r: 0.3 })); on(SB[1], [B]); on(B, [box(4 + dx, SH[1] + 2.2 + h * 0.7, ZU + 2.55, 1.4, 1, 0.05, '#e8c870', { r: 0, noOut: 1 })], [0, 0, 1]); });
          const yb = Y1 + 2; [[-36, '#3a5a2a', 16], [-31, '#4a2a3a', 15], [-26, '#3a5a2a', 16.4]].forEach(([x, col, h]) => { const B = cyl(x, yb, ZU - 1, 2, h * 0.65, col, { n: 14, shine: 1, rg: [[0, 0, 1], [h * 0.65, 0, 1]] }); on(BOT, [B]); on(B, [cyl(x, yb + h * 0.65, ZU - 1, 2, h * 0.35, col, { n: 14, shine: 1, rg: [[0, 0, 1], [h * 0.12, 0, 0.45], [h * 0.35, 0, 0.4]] }), box(x, yb + h * 0.3, ZU + 1.05, 2.6, 3.6, 0.05, '#f2e8d0', { r: 0, noOut: 1 })]); });
          on(BOT, [cyl(30, yb, ZU - 1, 6, 11, '#e8e0cc', { n: 18, mat: 'cer', shine: 1, rg: [[0, 0, 0.8], [3, 0, 1], [9, 0, 0.9], [11, 0, 0.7]] })]);
          { const L = o[o.length - 1]; on(L, [cyl(30, yb + 11, ZU - 1, 4.4, 1.2, WAL, W_({ n: 16 })), box(30, yb + 5, ZU + 5.05, 6, 2.6, 0.05, '#2f4a3c', { r: 0, noOut: 1 })]); }
          // brass rail along the back above the counter with S-hooks + copper ladles
          const RL = rod([-44, 60, ZU - DU / 2 + 3.6], [44, 60, ZU - DU / 2 + 3.6], 0.6, BR2, M_({ n: 10, shine: 1 })); on(BS, [RL]);
          on(BS, [-40, 40].map(x => rod([x, 60, ZU - DU / 2 + 2], [x, 60, ZU - DU / 2 + 3.6], 0.5, BR2, M_({ n: 6 }))));
          [-18, -12, -6].forEach((x, i) => on(RL, [rod([x, 59.4, ZU - DU / 2 + 3.6], [x, 49 + i, ZU - DU / 2 + 3.6], 0.4, '#c87a4a', M_({ n: 6, shine: 1 })), ball(x, 47.6 + i, ZU - DU / 2 + 3.6, 1.6, '#c87a4a', M_({ k: 4, n: 10, shine: 1, sy: 0.6 }))]));
          return o; },
          fx: c => { if (face(c, 0, 1) < 0.1) return {}; const f = carousel(c, -28, 46, 8, 30, 0, ['#c84a2a', '#e8a030', '#6a8a3a', '#8a4a2a', '#d8c070', '#a83a2a', '#4a6a2a', '#e8c890'])
              + carousel(c, 28, 46, 8, 36, 1.3, ['#e8a030', '#8a4a2a', '#c84a2a', '#4a6a2a', '#d8c070', '#6a3a2a']);
            let g = ''; [-24, 0, 24].forEach((x, i) => g += '<path d="' + qd(c, [[x - 12, SH[0] - 0.2, ZU + 6], [x + 12, SH[0] - 0.2, ZU + 6], [x + 18, SH[0] - 12, ZF], [x - 18, SH[0] - 12, ZF]]) + '" fill="url(#k74L)" opacity="0.2">' + an('opacity', '0.14;0.26;0.14', 9, n4(-i * 2), SPL(2)) + '</path>');
            return { defs: DEF74 + '<linearGradient id="k74L" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff2c8" stop-opacity="0.7"/><stop offset="1" stop-color="#fff2c8" stop-opacity="0"/></linearGradient>', front: g + f }; } }; };

      // KIT-094 Patisserie Pantry: cream lacquer + polished brass on a bronze plinth with a champagne light line, under a blush-and-cream scalloped awning.
      // Middle: arched glass vitrine with a glowing blush interior and a 3-tier brass cake stand slowly turning (cupcakes, macaron towers, petit cakes; cherry cake on top).
      // Sides: glass candy cabinets (apothecary jars: gumballs, lollipops, jelly beans, peppermints, cookies, marshmallows; twinkles) over labelled drawers with brass pulls.
      N.patis27 = S => { const CR = '#f4ead9', BR2 = '#c99a3e', BZ = '#4e3a22', PK = '#f4b6c4', W = 104, Dp = 42, YB = 6, SW = 26, HS = 104, HC = 120, ZS = Dp / 2, ZC = Dp / 2 + 1.5, XS = W / 2 - SW / 2;
        const VO = { x0: -20, x1: 20, y0: YB + 28, yA: YB + 84, r: 20 }, SO = { y0: YB + 40, y1: YB + HS - 7, i: 3.2 };
        const sx = sg => sg * XS, sOp = sg => [sx(sg) - SW / 2 + SO.i, sx(sg) + SW / 2 - SO.i];
        return { w: 108, d: 46, build: () => { const o = [], on = glue(o);
          const PLN = box(0, 0, 0, W - 2, YB, Dp - 2, BZ, M_({ r: 0.6, shine: 1 })); o.push(PLN);
          on(PLN, [slabX(0, 0.6, Dp / 2 - 0.95, W - 4, 0.5, 0.1, '#ffe2a0', em({ r: 0 })), slabX(0, YB - 0.8, Dp / 2 - 0.95, W - 4, 0.4, 0.1, '#f2d58a', M_({ r: 0, noOut: 1 }))], [0, 0, 1]);
          const C = box(0, YB, 0, 52, HC, Dp + 3, CR, PL({ r: 0.6, shine: 1 })); o.push(C);
          const SU = [-1, 1].map(sg => { const B = box(sx(sg), YB, 0, SW, HS, Dp, CR, PL({ r: 0.6, shine: 1 })); o.push(B); return B; });
          [-1, 1].forEach(sg => { const x = sg * 39.5; o.push(box(x, YB + HS, 0.5, 27, 3, Dp + 1, CR, PL({ r: 0.4 })), box(x, YB + HS + 3, 0.5, 27, 1.6, Dp + 2, BR2, M_({ r: 0.4, shine: 1 })), box(x, YB + HS + 4.6, 0.5, 27, 2.2, Dp + 3, CR, PL({ r: 0.6, shine: 1 }))); });
          o.push(box(0, YB + HC, 0, 56, 3, Dp + 5, CR, PL({ r: 0.4 })), box(0, YB + HC + 3, 0, 58, 1.8, Dp + 6, BR2, M_({ r: 0.4, shine: 1 })));
          const CAP = box(0, YB + HC + 4.8, 0, 60, 2.6, Dp + 7, CR, PL({ r: 0.8, shine: 1 })); o.push(CAP);
          on(CAP, [cyl(0, YB + HC + 7.4, 0, 3.2, 1.2, BR2, M_({ n: 16, shine: 1 })), ball(0, YB + HC + 10.4, 0, 2.4, BR2, M_({ k: 3, n: 12, shine: 1 })), ball(0, YB + HC + 13.4, 0, 1.1, '#d8283a', M_({ k: 3, n: 10, shine: 1 }))]);
          on(C, [-1, 1].map(sg => box(sg * 24.4, YB + 2, ZC + 0.4, 1.6, HC - 4, 0.8, BR2, M_({ r: 0.2, shine: 1 }))), [0, 0, 1]);
          [-1, 1].forEach(sg => { const x = sg * 11.6, DW = on(C, [box(x, YB + 4, ZC + 0.45, 21, 19, 0.9, CR, PL({ r: 0.5, shine: 1 }))], [0, 0, 1])[0];
            on(DW, [box(x, YB + 16.4, ZC + 1.05, 8, 2.8, 0.3, BR2, M_({ r: 0.2, shine: 1 })), box(x, YB + 16.75, ZC + 1.25, 6.6, 2.1, 0.05, '#fff6ea', { r: 0, noOut: 1 }), slabX(x, YB + 8.6, ZC + 1.6, 7.4, 1.5, 1.1, BR2, M_({ r: 0.5, shine: 1 }))], [0, 0, 1]); });
          SU.forEach((B, j) => { const sg = j ? 1 : -1, x = sx(sg), [x0, x1] = sOp(sg), y0 = SO.y0, y1 = SO.y1, z = ZS + 0.05, b = 0.8;
            on(B, [slabX(x, y1, z, x1 - x0 + 2 * b, b, 0.3, BR2, M_({ r: 0, shine: 1 })), slabX(x, y0 - b, z, x1 - x0 + 2 * b, b, 0.3, BR2, M_({ r: 0, shine: 1 })), box(x0 - b / 2, y0, z + 0.15, b, y1 - y0, 0.3, BR2, M_({ r: 0, shine: 1 })), box(x1 + b / 2, y0, z + 0.15, b, y1 - y0, 0.3, BR2, M_({ r: 0, shine: 1 })),
              ball(sg < 0 ? x1 + 1.7 : x0 - 1.7, (y0 + y1) / 2, ZS + 0.8, 0.85, BR2, M_({ k: 3, n: 10, shine: 1 }))], [0, 0, 1]);
            [YB + 3, YB + 14.6, YB + 26.2].forEach(y => { const DW = on(B, [box(x, y, ZS + 0.45, 21, 10.6, 0.9, CR, PL({ r: 0.5, shine: 1 }))], [0, 0, 1])[0];
              on(DW, [box(x, y + 6.6, ZS + 1.05, 8, 2.6, 0.3, BR2, M_({ r: 0.2, shine: 1 })), box(x, y + 6.9, ZS + 1.25, 6.6, 2, 0.05, '#fff6ea', { r: 0, noOut: 1 }), slabX(x, y + 2.4, ZS + 1.6, 6.6, 1.4, 1.1, BR2, M_({ r: 0.5, shine: 1 }))], [0, 0, 1]); }); });
          return o; },
          fx: c => { const f0 = face(c, 0, 1); if (f0 < 0.12) return {}; const id = 'k94' + Math.round(Math.random() * 1e6), k = c.k, vy = vY(c), hv = Math.hypot(vy[0], vy[1]), eyS = Math.abs(FP(c, [0, 0, 1])[1] - FP(c, [0, 0, 0])[1]), R = rng('patis27');
            let defs = DEF74 + '<linearGradient id="' + id + 'y" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0.4"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.7" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#3a1a10" stop-opacity="0.3"/></linearGradient>'
              + '<radialGradient id="' + id + 'r" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.55"/><stop offset="0.45" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#3a1a10" stop-opacity="0.3"/></radialGradient>'
              + '<linearGradient id="' + id + 'w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fbe4e6"/><stop offset="1" stop-color="#f0c0ca"/></linearGradient>'
              + '<radialGradient id="' + id + 'g" cx="50%" cy="10%" r="85%"><stop offset="0" stop-color="#fff6dc" stop-opacity="0.8"/><stop offset="1" stop-color="#ffd8c8" stop-opacity="0"/></radialGradient>'
              + '<linearGradient id="' + id + 'a" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.28"/><stop offset="1" stop-color="#5a2030" stop-opacity="0.2"/></linearGradient>'
              + '<filter id="' + id + 'f" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="0.9"/></filter>';
            const P2 = P => { const q = FP(c, P); return f1(q[0]) + ' ' + f1(q[1]); }, poly = Ps => 'M' + Ps.map(P2).join('L') + 'Z';
            const RG = 'url(#' + id + 'r)', CY = 'url(#' + id + 'y)';
            const el = (cx, cy, rx, ry, fill, ex) => '<ellipse cx="' + f1(cx) + '" cy="' + f1(cy) + '" rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="' + fill + '"' + (ex || '') + '/>';
            const el2 = (cx, cy, rx, ry, fill) => el(cx, cy, rx, ry, fill) + el(cx, cy, rx, ry, RG);
            const rc = (x, y, w, h, rr, fill, ex) => '<rect x="' + f1(x) + '" y="' + f1(y) + '" width="' + f1(w) + '" height="' + f1(h) + '" rx="' + f1(rr) + '" fill="' + fill + '"' + (ex || '') + '/>';
            const shd = r => el(0, 0, r * k, r * eyS, '#5a2a1a', ' opacity="0.18"');
            const tw = (q, sz, dur, beg) => { const z = sz * k, h = z * 0.25; return '<path transform="translate(' + f1(q[0]) + ' ' + f1(q[1]) + ')" d="M0 ' + f1(-z) + 'L' + f1(h) + ' ' + f1(-h) + 'L' + f1(z) + ' 0L' + f1(h) + ' ' + f1(h) + 'L0 ' + f1(z) + 'L' + f1(-h) + ' ' + f1(h) + 'L' + f1(-z) + ' 0L' + f1(-h) + ' ' + f1(-h) + 'Z" fill="#ffffff" opacity="0">' + an('opacity', '0;0.95;0', dur, n4(beg), SPL(2)) + '</path>'; };
            const walls = (x0, x1, y0, y1, za, zb2, col) => { let w = ''; if (face(c, 1, 0) > 0) w += '<path d="' + poly([[x0, y1, za], [x0, y1, zb2], [x0, y0, zb2], [x0, y0, za]]) + '" fill="' + shade(col, 0.8) + '"/>'; if (face(c, -1, 0) > 0) w += '<path d="' + poly([[x1, y1, za], [x1, y1, zb2], [x1, y0, zb2], [x1, y0, za]]) + '" fill="' + shade(col, 0.92) + '"/>';
              return w + '<path d="' + poly([[x0, y0, za], [x1, y0, za], [x1, y0, zb2], [x0, y0, zb2]]) + '" fill="' + shade(col, 1.04) + '"/>'; };
            // ---- treats (sprites drawn at their base point)
            const FR = ['#f8bccb', '#c4ead6', '#dccaf2', '#fff2d4', '#9a5e3e', '#ffd2ac'], WR = ['#f08aa0', '#7cc8a8', '#b49ae0', '#e8c070'], SPR = ['#f04a5a', '#4ab0f0', '#f6c040', '#7cd07a', '#ffffff'];
            const cup = i => { const h = 3.4 * hv, b = 1.9 * k, t = 2.5 * k, w = WR[i % 4], f = FR[i % 6], wp = 'M' + f1(-b) + ' 0L' + f1(-t) + ' ' + f1(-h) + 'H' + f1(t) + 'L' + f1(b) + ' 0Z';
              let s = shd(2.4) + '<path d="' + wp + '" fill="' + w + '"/>' + [-0.6, -0.2, 0.2, 0.6].map(u => '<path d="M' + f1(u * b) + ' 0L' + f1(u * t) + ' ' + f1(-h) + '" stroke="' + shade(w, 0.78) + '" stroke-width="' + f1(0.22 * k) + '"/>').join('') + '<path d="' + wp + '" fill="' + CY + '"/>';
              s += el2(0, -h - 0.8 * hv, 2.9 * k, 1.3 * hv, f) + el2(0, -h - 2.1 * hv, 2.2 * k, 1.15 * hv, f) + el2(0, -h - 3.2 * hv, 1.35 * k, 0.95 * hv, f);
              if (i % 2 === 0) s += '<path d="M0 ' + f1(-h - 4.6 * hv) + 'q' + f1(0.4 * k) + ' ' + f1(-1 * hv) + ' ' + f1(1.1 * k) + ' ' + f1(-1.4 * hv) + '" stroke="#5a7a2a" stroke-width="' + f1(0.22 * k) + '" fill="none"/>' + el2(0, -h - 4.3 * hv, 0.95 * k, 0.95 * k, '#d8283a');
              else s += rep(6, j => { const a = j * 1.05 + i, r2 = 0.9 + (j % 3) * 0.5, x = Math.cos(a) * r2 * k, y = -h - (1.3 + (j % 3) * 0.9) * hv; return '<rect x="' + f1(x - 0.3 * k) + '" y="' + f1(y) + '" width="' + f1(0.6 * k) + '" height="' + f1(0.22 * k) + '" fill="' + SPR[j % 5] + '" transform="rotate(' + (j * 47 % 180) + ' ' + f1(x) + ' ' + f1(y) + ')"/>'; }).join('');
              return s; };
            const MC = ['#f8bccb', '#c4ead6', '#dccaf2', '#fff0a8', '#ffc8a0', '#b4dcf4', '#c89a70'];
            const mac = i => { const rx = 2.3 * k, sh = 1.05 * hv, fl = 0.5 * hv, st = 2 * sh + fl + 0.2 * hv; let s = shd(2.4), top = 0;
              for (let j = 0; j < 3; j++) { const col = MC[(i + j * 3) % MC.length], yb = -j * st, d2 = shade(col, 0.82), da = ' stroke="' + d2 + '" stroke-width="' + f1(0.3 * k) + '" stroke-dasharray="' + f1(0.3 * k) + ' ' + f1(0.25 * k) + '" fill="none"/>';
                s += rc(-rx, yb - sh, 2 * rx, sh, sh / 2, col) + rc(-rx, yb - sh, 2 * rx, sh, sh / 2, CY) + rc(-rx * 0.92, yb - sh - fl, rx * 1.84, fl, fl / 2, '#fff8ee') + rc(-rx, yb - 2 * sh - fl, 2 * rx, sh, sh / 2, col) + rc(-rx, yb - 2 * sh - fl, 2 * rx, sh, sh / 2, CY)
                  + '<path d="M' + f1(-rx * 0.85) + ' ' + f1(yb - sh * 1.02) + 'H' + f1(rx * 0.85) + '"' + da + '<path d="M' + f1(-rx * 0.85) + ' ' + f1(yb - sh - fl + 0.1 * hv) + 'H' + f1(rx * 0.85) + '"' + da;
                top = yb - 2 * sh - fl; }
              return s + el(-0.4 * k, top + sh * 0.3, rx * 0.6, sh * 0.2, '#ffffff', ' opacity="0.55"'); };
            const CK = [['#fff2f6', '#f4a0b4'], ['#fff6dc', '#9a5e3e'], ['#ecf8f0', '#8ad0b0'], ['#f6eeff', '#c0a8e8'], ['#fff2e2', '#f2a868']];
            const cake = (i, sc) => { const [ic, sp] = CK[i % 5], rx = 2.5 * k * sc, ry = 2.5 * eyS * sc, h = 3.2 * hv * sc, d = 1.1 * hv * sc, arc = y => 'M' + f1(-rx) + ' ' + f1(y) + 'A' + f1(rx) + ' ' + f1(ry) + ' 0 0 0 ' + f1(rx) + ' ' + f1(y);
              let s = shd(2.8 * sc) + el(0, 0, rx, ry, sp) + rc(-rx, -h, 2 * rx, h, 0, sp) + '<path d="M' + f1(-rx) + ' ' + f1(-h) + 'V0A' + f1(rx) + ' ' + f1(ry) + ' 0 0 0 ' + f1(rx) + ' 0V' + f1(-h) + 'Z" fill="' + CY + '"/>'
                + '<path d="' + arc(-h * 0.45) + '" stroke="' + ic + '" stroke-width="' + f1(0.45 * hv * sc) + '" fill="none"/>' + el(0, -h, rx, ry, ic) + '<path d="' + arc(-h) + '" stroke="' + ic + '" stroke-width="' + f1(d * 0.7) + '" fill="none"/>';
              for (let j = 0; j < 5; j++) { const t = PI * (0.1 + 0.2 * j); s += el(-rx * Math.cos(t), -h + ry * Math.sin(t) + d * (0.35 + 0.35 * (j % 2)), 0.42 * k * sc, d * 0.55, ic); }
              s += el(0, -h, rx, ry, RG);
              const by = -h - 0.1 * hv * sc, bw = 1.2 * k * sc, bh = 2.2 * hv * sc, bp = 'M0 ' + f1(by) + 'C' + f1(-bw * 1.3) + ' ' + f1(by - bh * 0.15) + ' ' + f1(-bw) + ' ' + f1(by - bh) + ' 0 ' + f1(by - bh) + 'C' + f1(bw) + ' ' + f1(by - bh) + ' ' + f1(bw * 1.3) + ' ' + f1(by - bh * 0.15) + ' 0 ' + f1(by) + 'Z';
              s += '<path d="' + bp + '" fill="#e0303e"/><path d="' + bp + '" fill="' + RG + '"/>' + rep(4, j => el((j % 2 - 0.5) * bw * 0.8, by - bh * (0.3 + j * 0.15), 0.12 * k * sc, 0.16 * k * sc, '#fff0a0')).join('') + el(-0.4 * bw, by - bh * 1.02, bw * 0.55, 0.3 * k * sc, '#5aa040') + el(0.4 * bw, by - bh * 1.02, bw * 0.55, 0.3 * k * sc, '#4a9038');
              return s; };
            const GB = ['#f04a5a', '#f6c040', '#4ab0f0', '#7cd07a', '#f08ad0', '#ffffff', '#ff9a4a'], MS = ['#fff6f8', '#f8d0dc', '#d8f0e4', '#fff0c8'];
            const jar = kind => { const rx = 3.3 * k, h = 9 * hv, ery = 3.3 * eyS, lvl = h * 0.78, lol = kind === 'lolly'; let s = shd(3.4) + rc(-rx, -h, 2 * rx, h, 0.9 * k, '#e8f4f2', ' opacity="0.45"'), cn = '';
              if (kind === 'gum') for (let r = 0; r < 5; r++) for (let q = -2; q <= 2; q++) { const x = (q + (r % 2) * 0.5 - 0.25) * 1.25 * k; if (Math.abs(x) > rx - 0.7 * k) continue; cn += el2(x, -(0.8 + r * 1.35) * hv, 0.68 * k, 0.68 * k, GB[(r * 3 + q + 7) % 7]); }
              if (kind === 'bean') { const B = rep(22, () => [(R() - 0.5) * 2 * (rx - 0.8 * k), -(0.6 + R() * (lvl / hv - 1.2)) * hv, R() * 180, GB[(R() * 7) | 0]]).sort((p, q) => q[1] - p[1]);
                cn += B.map(([x, y, a, col]) => '<g transform="translate(' + f1(x) + ' ' + f1(y) + ') rotate(' + f1(a) + ')">' + el(0, 0, 0.78 * k, 0.46 * k, col) + el(-0.2 * k, -0.15 * k, 0.35 * k, 0.12 * k, '#ffffff', ' opacity="0.6"') + '</g>').join(''); }
              if (kind === 'mint') for (let r = 0; r < 4; r++) for (let q = -1; q <= 1; q++) { const x = (q + (r % 2) * 0.4 - 0.2) * 1.9 * k, y = -(1 + r * 1.65) * hv; cn += el(x, y, 0.9 * k, 0.9 * k, '#ffffff') + '<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="' + f1(0.5 * k) + '" fill="none" stroke="#e83a4a" stroke-width="' + f1(0.6 * k) + '" stroke-dasharray="' + f1(0.52 * k) + ' ' + f1(0.52 * k) + '"/>' + el(x, y, 0.9 * k, 0.9 * k, RG); }
              if (kind === 'cookie') for (let j = 0; j < 6; j++) { const y = -(0.7 + j * 1.05) * hv; cn += el(0, y, 2.7 * k, Math.max(0.3 * k, 2.7 * eyS), '#b87a3e') + el(0, y - 0.3 * hv, 2.6 * k, Math.max(0.28 * k, 2.6 * eyS), '#dca868') + rep(3, q => el((q - 1) * 1.1 * k, y - 0.3 * hv + ((q % 2) - 0.5) * 0.4 * eyS, 0.28 * k, 0.2 * k, '#4a2a18')).join(''); }
              if (kind === 'marsh') for (let r = 0; r < 4; r++) for (let q = -1; q <= 1; q++) { const x = (q + (r % 2) * 0.3 - 0.15) * 1.85 * k, y = -(0.4 + r * 1.6) * hv; cn += rc(x - 0.8 * k, y - 1.3 * hv, 1.6 * k, 1.3 * hv, 0.45 * k, MS[(r + q + 4) % 4]) + rc(x - 0.8 * k, y - 1.3 * hv, 1.6 * k, 1.3 * hv, 0.45 * k, RG); }
              if (lol) cn += rc(-rx + 0.3 * k, -lvl * 0.45, 2 * rx - 0.6 * k, lvl * 0.45, 0.6 * k, '#f8d0dc') + rep(10, j => el((R() - 0.5) * 2 * (rx - 0.8 * k), -(0.3 + R() * 0.35) * lvl, 0.35 * k, 0.35 * k, GB[j % 7])).join('');
              s += cn + rc(-rx, -h, 2 * rx, h, 0.9 * k, CY, ' opacity="0.7"') + rc(-rx * 0.68, -h * 0.92, 0.5 * k, h * 0.8, 0.25 * k, '#ffffff', ' opacity="0.5"') + el(0, -h, rx, ery, 'none', ' stroke="#ffffff" stroke-width="' + f1(0.25 * k) + '" opacity="0.7"');
              if (lol) s += rep(3, j => { const x = (j - 1) * 1.6 * k, ty = -h - (2.4 + (j % 2) * 1.5) * hv, col = ['#f04a5a', '#f6c040', '#7cc8f0'][j]; return '<path d="M' + f1(x * 0.5) + ' ' + f1(-lvl * 0.5) + 'L' + f1(x) + ' ' + f1(ty) + '" stroke="#ffffff" stroke-width="' + f1(0.36 * k) + '"/>' + el(x, ty, 1.6 * k, 1.6 * k, col) + '<circle cx="' + f1(x) + '" cy="' + f1(ty) + '" r="' + f1(0.95 * k) + '" fill="none" stroke="#ffffff" stroke-width="' + f1(0.36 * k) + '" stroke-dasharray="' + f1(1 * k) + ' ' + f1(0.6 * k) + '"/>' + el(x, ty, 1.6 * k, 1.6 * k, RG); }).join('');
              else s += rc(-rx, -h + 0.2 * hv, 2 * rx, 0.8 * hv, 0, '#f4a0b4') + el2(rx * 0.55, -h + 0.6 * hv, 0.6 * k, 0.45 * k, '#f08aa0') + rc(-rx * 1.04, -h - 1.2 * hv, 2.08 * rx, 1.2 * hv, 0.3 * k, 'url(#k74v)') + el(0, -h - 1.2 * hv, rx * 1.04, ery * 1.04, '#e8c46a') + el2(0, -h - 1.2 * hv - 0.7 * k, 0.9 * k, 0.9 * k, '#d8aa4e');
              return s; };
            // ---- turning 3-tier cake stand (items swap front/back halves round the brass post)
            const stand = (cx, y0, cz, T) => { const NK = 24, post = (ya, yb) => { const a = FP(c, [cx, ya, cz]), b = FP(c, [cx, yb, cz]); return '<path d="M' + f1(a[0]) + ' ' + f1(a[1]) + 'L' + f1(b[0]) + ' ' + f1(b[1]) + '" stroke="#a87a2a" stroke-width="' + f1(1.2 * k) + '"/><path d="M' + f1(a[0] - 0.3 * k) + ' ' + f1(a[1]) + 'L' + f1(b[0] - 0.3 * k) + ' ' + f1(b[1]) + '" stroke="#fff0b8" stroke-width="' + f1(0.35 * k) + '"/>'; };
              const pl = (y, r) => { const q = FP(c, [cx, y, cz]), rr = r + 1.2; return el(q[0], q[1] + 0.9 * k, rr * k, rr * eyS, '#7a5418') + el(q[0], q[1], rr * k, rr * eyS, 'url(#k74b)') + el(q[0], q[1], r * k, r * eyS, '#fff8f0') + el(q[0], q[1], (r - 0.8) * k, (r - 0.8) * eyS, 'none', ' stroke="#f2c4cc" stroke-width="' + f1(0.35 * k) + '" stroke-dasharray="' + f1(0.5 * k) + ' ' + f1(0.35 * k) + '"'); };
              const TI = [[y0 + 3, 14, 8, cup, 1, 0.78], [y0 + 21, 11, 7, mac, -1, 0.78], [y0 + 37, 8.5, 5, i => cake(i, 1), 1, 0.68]], YT = y0 + 51, q0 = FP(c, [cx, y0, cz]);
              let s = el(q0[0], q0[1] + 0.6 * k, 8 * k, 8 * eyS, '#5a2a1a', ' opacity="0.22" filter="url(#' + id + 'f)"') + el(q0[0], q0[1], 5 * k, 5 * eyS, 'url(#k74b)') + post(y0, TI[0][0]);
              TI.forEach(([y, r, n, it, dir, ins], ti) => { const ctr = FP(c, [cx, y, cz]), yN = ti < 2 ? TI[ti + 1][0] : YT; let b = '', f = '';
                for (let i = 0; i < n; i++) { const pos = [], fr = [], spr = it(i); for (let j = 0; j <= NK; j++) { const a = dir * 2 * PI * (i / n + j / NK) + ti, q = FP(c, [cx + Math.sin(a) * r * ins, y, cz + Math.cos(a) * r * ins]); pos.push(f1(q[0]) + ' ' + f1(q[1])); fr.push(q[1] > ctr[1] ? 1 : 0); }
                  const mv = '<animateTransform attributeName="transform" type="translate" values="' + pos.join(';') + '" dur="' + T + 's"' + KT(NK) + ' repeatCount="indefinite"/>';
                  const op = v => '<animate attributeName="opacity" values="' + fr.map(x => x === v ? 1 : 0).join(';') + '" dur="' + T + 's"' + KT(NK) + ' calcMode="discrete" repeatCount="indefinite"/>';
                  b += '<g opacity="' + (fr[0] ? 0 : 1) + '">' + op(0) + '<g>' + mv + spr + '</g></g>'; f += '<g opacity="' + fr[0] + '">' + op(1) + '<g>' + mv + spr + '</g></g>'; }
                s += pl(y, r) + b + post(y, yN) + f; });
              const qt = FP(c, [cx, YT, cz]); return s + pl(YT, 5.6) + '<g transform="translate(' + f1(qt[0]) + ' ' + f1(qt[1]) + ')">' + cake(0, 1.7) + '</g>'; };
            let out = '';
            // ---- side candy cabinets
            [-1, 1].forEach(sg => { const [x0, x1] = sOp(sg), y0 = SO.y0, y1 = SO.y1, z0 = ZS + 0.02, zb = ZS - 20, cp = id + 'c' + (sg > 0 ? 1 : 0);
              defs += '<clipPath id="' + cp + '"><path d="' + poly([[x0, y1, z0], [x1, y1, z0], [x1, y0, z0], [x0, y0, z0]]) + '"/></clipPath>';
              let s = '<path d="' + poly([[x0 - 8, y1 + 8, zb], [x1 + 8, y1 + 8, zb], [x1 + 8, y0 - 8, zb], [x0 - 8, y0 - 8, zb]]) + '" fill="url(#' + id + 'w)"/>';
              for (let x = x0 - 8; x < x1 + 8; x += 2.6) s += '<path d="' + poly([[x, y1 + 8, zb + 0.02], [x + 1, y1 + 8, zb + 0.02], [x + 1, y0 - 8, zb + 0.02], [x, y0 - 8, zb + 0.02]]) + '" fill="#fff4f4" opacity="0.5"/>';
              s += walls(x0, x1, y0, y1, zb, z0, '#f2c8d0') + '<path d="' + poly([[x0, y1, zb], [x1, y1, zb], [x1, y0, zb], [x0, y0, zb]]) + '" fill="url(#' + id + 'g)"/>';
              const KS = sg < 0 ? [['gum', 'lolly'], ['mint', 'cookie'], ['bean', 'marsh']] : [['marsh', 'gum'], ['cookie', 'bean'], ['lolly', 'mint']];
              [y0, y0 + 19, y0 + 38].forEach((y, si) => { if (si) s += '<path d="' + poly([[x0, y, zb], [x1, y, zb], [x1, y, z0 - 1], [x0, y, z0 - 1]]) + '" fill="#eaf6f4" opacity="0.45"/><path d="M' + P2([x0, y, z0 - 1]) + 'L' + P2([x1, y, z0 - 1]) + '" stroke="#ffffff" stroke-width="' + f1(0.4 * k) + '" opacity="0.85"/>';
                KS[2 - si].forEach((kd, ji) => { const q = FP(c, [x0 + (x1 - x0) * (ji ? 0.73 : 0.27), y, zb + 9]); s += '<g transform="translate(' + f1(q[0]) + ' ' + f1(q[1]) + ')">' + jar(kd) + '</g>'; }); });
              s += rep(3, i => tw(FP(c, [x0 + 3 + R() * (x1 - x0 - 6), y0 + 6 + R() * (y1 - y0 - 12), z0]), 1.1, 3.4 + i * 0.7, -(i * 1.7 + (sg > 0 ? 0.9 : 0)))).join('');
              s += '<path d="' + poly([[x0, y1, z0], [x1, y1, z0], [x1, y0, z0], [x0, y0, z0]]) + '" fill="#fff6f0" opacity="0.08"/><path d="' + poly([[x0 + 3, y1, z0], [x0 + 7, y1, z0], [x0 + 1, y0, z0], [x0 - 3, y0, z0]]) + '" fill="#ffffff" opacity="0.1"/><path d="' + poly([[x0 + 9, y1, z0], [x0 + 10.4, y1, z0], [x0 + 4.4, y0, z0], [x0 + 3, y0, z0]]) + '" fill="#ffffff" opacity="0.07"/>';
              out += '<g clip-path="url(#' + cp + ')">' + s + '</g>'; });
            // ---- arched vitrine with the cake stand
            { const { x0, x1, y0, yA, r } = VO, z0 = ZC + 0.02, zb = ZC - 34, cp = id + 'cv', AR = [[x0, y0, z0], [x1, y0, z0], [x1, yA, z0]].concat(rep(17, i => { const a = i / 16 * PI; return [r * Math.cos(a), yA + r * Math.sin(a), z0]; })).concat([[x0, yA, z0]]);
              defs += '<clipPath id="' + cp + '"><path d="' + poly(AR) + '"/></clipPath>';
              let s = '<path d="' + poly([[x0 - 12, yA + r + 12, zb], [x1 + 12, yA + r + 12, zb], [x1 + 12, y0 - 12, zb], [x0 - 12, y0 - 12, zb]]) + '" fill="url(#' + id + 'w)"/>';
              for (let x = x0 - 12; x < x1 + 12; x += 3) s += '<path d="' + poly([[x, yA + r + 12, zb + 0.02], [x + 1.2, yA + r + 12, zb + 0.02], [x + 1.2, y0 - 12, zb + 0.02], [x, y0 - 12, zb + 0.02]]) + '" fill="#fff4f4" opacity="0.45"/>';
              s += walls(x0, x1, y0, yA + r, zb, z0, '#f2c8d0') + '<path d="' + poly([[x0, yA + r, zb], [x1, yA + r, zb], [x1, y0, zb], [x0, y0, zb]]) + '" fill="url(#' + id + 'g)">' + an('opacity', '0.75;1;0.75', 7, 0, SPL(2)) + '</path>';
              s += stand(0, y0, ZC - 17, 48) + rep(4, i => tw(FP(c, [x0 + 4 + R() * 32, y0 + 10 + R() * 60, z0]), 1.3, 3 + i * 0.6, -i * 1.3)).join('');
              s += '<path d="' + poly(AR) + '" fill="#fff6f0" opacity="0.07"/><path d="' + poly([[x0 + 5, yA + 18, z0], [x0 + 11, yA + 18, z0], [x0 + 3, y0, z0], [x0 - 3, y0, z0]]) + '" fill="#ffffff" opacity="0.09"/><path d="' + poly([[x0 + 15, yA + 18, z0], [x0 + 17, yA + 18, z0], [x0 + 9, y0, z0], [x0 + 7, y0, z0]]) + '" fill="#ffffff" opacity="0.06"/>';
              out += '<g clip-path="url(#' + cp + ')">' + s + '</g>';
              const bz = 'M' + AR.map(P2).join('L') + 'Z'; out += '<path d="' + bz + '" fill="none" stroke="#b8882e" stroke-width="' + f1(1.5 * k) + '" stroke-linejoin="round"/><path d="' + bz + '" fill="none" stroke="#f6dc96" stroke-width="' + f1(0.6 * k) + '" stroke-linejoin="round"/>';
              const kq = FP(c, [0, yA + r + 0.4, z0 + 0.4]); out += el(kq[0], kq[1], 1.3 * k, 1.3 * k, 'url(#k74b)'); }
            // ---- drawer labels
            const txt = (x, y, z, t, sz) => '<g transform="' + frame(c.p, [x, y, z], [1, 0, 0], [0, -1, 0]) + '"><text text-anchor="middle" font-family="Georgia,\'Times New Roman\',serif" font-size="' + sz + '" fill="#8a5a3a" letter-spacing="0.1">' + t + '</text></g>';
            [-1, 1].forEach(sg => (sg < 0 ? ['COCOA', 'SPRINKLES', 'COOKIES'] : ['FUDGE', 'MINTS', 'TOFFEE']).forEach((t, i) => out += txt(sx(sg), YB + 3 + i * 11.6 + 7.35, ZS + 1.3, t, 1.25)));
            out += txt(-11.6, YB + 17.35, ZC + 1.3, 'CAKES', 1.4) + txt(11.6, YB + 17.35, ZC + 1.3, 'TARTS', 1.4);
            // ---- scalloped blush-and-cream awning over the vitrine
            { const xa = -28, xb = 28, N = 8, yT = YB + HC - 1, yBt = YB + HC - 10, zT = ZC + 0.2, zB = ZC + 8, sc = 2.4; let a = '<path d="' + poly([[xa + 2, yBt - 0.5, ZC + 0.05], [xb - 2, yBt - 0.5, ZC + 0.05], [xb - 2, yBt - 7, ZC + 0.05], [xa + 2, yBt - 7, ZC + 0.05]]) + '" fill="#5a2030" opacity="0.16" filter="url(#' + id + 'f)"/>';
              [[xa, face(c, -1, 0)], [xb, face(c, 1, 0)]].forEach(([x, fv]) => { if (fv > 0) a += '<path d="' + poly([[x, yT, zT], [x, yBt, zB], [x, yBt, zT]]) + '" fill="' + shade(PK, 0.8) + '"/>'; });
              for (let i = 0; i < N; i++) { const u0 = xa + (xb - xa) * i / N, u1 = xa + (xb - xa) * (i + 1) / N, col = i % 2 ? '#fff7ec' : PK;
                const d = poly([[u0, yT, zT], [u1, yT, zT]].concat(rep(9, j => { const t = j / 8 * PI; return [u1 - (u1 - u0) * (0.5 - 0.5 * Math.cos(t)), yBt - Math.sin(t) * sc, zB]; })));
                a += '<path d="' + d + '" fill="' + col + '"/><path d="' + d + '" fill="url(#' + id + 'a)"/>'; }
              a += '<path d="M' + P2([xa, yBt, zB]) + 'L' + P2([xb, yBt, zB]) + '" stroke="#e890a4" stroke-width="' + f1(0.3 * k) + '" opacity="0.7"/>';
              const ra = FP(c, [xa - 1.2, yT, zT + 0.3]), rb = FP(c, [xb + 1.2, yT, zT + 0.3]);
              a += '<path d="M' + f1(ra[0]) + ' ' + f1(ra[1]) + 'L' + f1(rb[0]) + ' ' + f1(rb[1]) + '" stroke="#b8882e" stroke-width="' + f1(1.1 * k) + '" stroke-linecap="round"/><path d="M' + f1(ra[0]) + ' ' + f1(ra[1] - 0.3 * k) + 'L' + f1(rb[0]) + ' ' + f1(rb[1] - 0.3 * k) + '" stroke="#fff0b8" stroke-width="' + f1(0.3 * k) + '" opacity="0.8"/>' + el(ra[0], ra[1], 1 * k, 1 * k, 'url(#k74b)') + el(rb[0], rb[1], 1 * k, 1 * k, 'url(#k74b)');
              out += a; }
            return { defs, front: out }; } }; };
    }

    // ======================= WALL ACCENTS (KIT-004/024/044/064/084) + WALL SIGN (KIT-101): wall pieces, same build as pine27 =======================
    { const sp3 = (C, q, r, col) => { const c = C.P(q); return H.sph(C, q, r, col) + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r * C.k)}" fill="none" stroke="${shade(col, 0.4)}" stroke-width="${f1(0.22 * C.k)}" opacity="0.7"/>`; };
      const xe = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
      const SERIF = "Georgia,'Times New Roman',serif", HAND = "'Segoe Print','Comic Sans MS','Marker Felt',cursive", SANS = 'Arial,Helvetica,sans-serif';
      const shW = (C, x, y, w, h, rx, op) => WD(C, x + 1.4, y - 2.2, 0.05, `<rect width="${f1(w)}" height="${f1(h)}" rx="${rx || 1}" fill="#000000" opacity="${op || 0.3}" filter="url(#m10b3)"/>`);
      // S-hook over a rail: top hump at yT, loop bottom at yT - 5.3 * sc
      const sHook = (C, x, yT, z, sc, col) => WD(C, x, yT, z, `<g transform="scale(${sc})"><path d="M-1.2 1.4C-1.2 -0.4 1.2 -0.4 1.2 1.2V3.6C1.2 5.8 -1.2 5.8 -1.2 4.2" stroke="${col}" stroke-width="0.5" fill="none" stroke-linecap="round"/><path d="M-0.9 1.2C-0.9 0 0.9 0 0.9 1" stroke="#ffffff" stroke-width="0.15" fill="none" opacity="0.4"/></g>`);

      // KIT-004 tacked-up takeout menus + paper towel holder (T1, cheap): Tony's Pizza trifold (grease spot), Golden Wok menu, a taped Taco Loco flyer whose half-torn
      // coupon flutters, a Burger Barn coupon, a sticky note, plastic push pins + an old pin hole; under them a white plastic towel holder (right arm cracked + duct-taped),
      // flowery roll with perforations, the hanging sheet sways
      N.menus27 = S => { const D = { w: 86, d: 12, mount: 'wall', elev: 44, build: () => [] };
        D.fx = ctx => { const C = camW(ctx), R = rng('menus27'), k = C.k, RY = 6, RZ = 6.4, RR = 5.2;
          ext(C, [[-44, 50, 0], [44, -17, 0], [44, -17, 12]]);
          const ln = (x, y, w, n, dy, col) => rep(n, i => `<rect x="${f1(x)}" y="${f1(y + i * dy)}" width="${f1(w * (0.5 + R() * 0.5))}" height="0.42" fill="${col || '#3a3430'}" opacity="0.55"/>`).join('');
          const pr = (x, y, n, dy) => rep(n, i => `<rect x="${f1(x)}" y="${f1(y + i * dy)}" width="1.8" height="0.42" fill="#3a3430" opacity="0.65"/>`).join('');
          const paper = (x, y, z, w, h, rot, body) => WD(C, x, y, z, `<g transform="rotate(${rot} ${f1(w / 2)} 0)"><rect x="0.5" y="0.9" width="${w}" height="${h}" fill="#000000" opacity="0.22" filter="url(#m12b1)"/>${body}</g>`);
          const pin = (x, y, col) => cyl3(C, [x, y, 0.2], [x, y, 0.9], 0.22, '#c8ccd0', { n: 8 }) + cyl3(C, [x, y, 0.9], [x, y, 2], 0.95, col, { n: 14, mat: 'gloss', r2: 0.7 }) + sp3(C, [x, y, 2.3], 0.85, col);
          let s = WD(C, -34, 33, 0.04, '<circle r="0.35" fill="#3a3028" opacity="0.6"/><circle cx="0.7" cy="0.5" r="0.6" fill="#000000" opacity="0.06"/>');
          const A = `<rect width="22" height="30" fill="#f8f4ea"/><rect width="22" height="7" fill="#c8302a"/><text x="11" y="4.2" text-anchor="middle" font-family="${SERIF}" font-weight="700" font-size="3" fill="#fff6e0">TONY'S</text><text x="11" y="6.3" text-anchor="middle" font-family="${SANS}" font-weight="700" font-size="1.5" fill="#ffe08a" letter-spacing="0.3">PIZZA · SUBS</text>`
            + rep(11, i => `<rect x="${i * 2}" y="7" width="1" height="1" fill="#2f7a3a"/><rect x="${i * 2 + 1}" y="7" width="1" height="1" fill="#ffffff"/>`).join('')
            + '<circle cx="6.5" cy="13" r="3.6" fill="#e0a040"/><circle cx="6.5" cy="13" r="3" fill="#d84a2a"/>' + rep(6, i => { const a = i / 6 * PI * 2; return `<circle cx="${f1(6.5 + Math.cos(a) * 1.7)}" cy="${f1(13 + Math.sin(a) * 1.7)}" r="0.55" fill="#9a2018"/>`; }).join('') + '<circle cx="6.5" cy="13" r="0.7" fill="#f6e0a0"/>'
            + ln(11.5, 10.5, 8, 5, 1.4) + ln(2, 18.5, 14, 8, 1.3) + pr(18.2, 18.5, 8, 1.3)
            + '<rect x="7.33" width="7.34" height="30" fill="#000000" opacity="0.05"/><path d="M7.33 0V30M14.67 0V30" stroke="#c8bca4" stroke-width="0.25"/>'
            + '<ellipse cx="16" cy="24" rx="3.4" ry="2.4" fill="#d89a3a" opacity="0.3"/><ellipse cx="16.6" cy="24.4" rx="2" ry="1.4" fill="#c88a2a" opacity="0.25"/>'
            + `<text x="11" y="28.6" text-anchor="middle" font-family="${SANS}" font-weight="700" font-size="1.5" fill="#c8302a">555-0142</text>`;
          s += paper(-41, 46, 0.1, 22, 30, -3, A);
          const B = `<rect width="20" height="27" fill="#c42a24"/><rect x="1" y="1" width="18" height="25" fill="none" stroke="#e8c050" stroke-width="0.4"/><rect x="2" y="7.4" width="16" height="17.4" fill="#fbf2dc"/>`
            + `<text x="10" y="4.4" text-anchor="middle" font-family="${SERIF}" font-weight="700" font-size="2.8" fill="#f4d060">GOLDEN WOK</text><text x="10" y="6.4" text-anchor="middle" font-family="${SANS}" font-size="1.2" fill="#f8e0a0" letter-spacing="0.2">FREE DELIVERY</text>`
            + '<path d="M13.2 9.4h4.2l-0.6 4.2h-3z" fill="#ffffff" stroke="#8a2a20" stroke-width="0.2"/><path d="M14.4 9.4q0.9 -1.6 1.8 0" stroke="#8a2a20" stroke-width="0.2" fill="none"/>'
            + ln(3, 9.4, 9, 4, 1.2) + ln(3, 15, 11, 7, 1.3) + pr(15.4, 15, 7, 1.3)
            + `<text x="10" y="25.4" text-anchor="middle" font-family="${SANS}" font-weight="700" font-size="1.3" fill="#f4d060">LUNCH SPECIAL #7</text>`;
          s += paper(-19, 47, 0.15, 20, 27, 4, B);
          const Cf = `<g>${at('rotate', '-0.6 9 0;0.8 9 0;-0.6 9 0', 7, 0, SPL(2))}<rect width="18" height="16.4" fill="#f6d84a"/><text x="9" y="4.6" text-anchor="middle" font-family="${HAND}" font-weight="700" font-size="3.3" fill="#2f7a3a">Taco Loco</text>`
            + '<path d="M4 12a5 5 0 0 1 10 0z" fill="#e8b040" stroke="#b07a20" stroke-width="0.3"/><path d="M5 11.6q1 -2.4 2 -1.2q1 -2 2 -0.4q1 -1.8 2.2 0q0.8 -1 1.8 1.6" fill="#6ab04a"/><circle cx="7.2" cy="10.4" r="0.6" fill="#d84a2a"/><circle cx="10.6" cy="10.2" r="0.6" fill="#d84a2a"/>'
            + ln(2.4, 13.4, 13, 2, 1.2, '#2a3a20')
            + `<g>${at('rotate', '0 0 16.4;4 0 16.4;-1 0 16.4;0 0 16.4', 5.2, 0, SPL(3))}<path d="M0 16.4H18V21.4L16.6 22L15 21.3L13 22H0Z" fill="#f8e070"/><path d="M0 16.5H18" stroke="#3a3020" stroke-width="0.2" stroke-dasharray="0.6 0.4"/><text x="9" y="19.4" text-anchor="middle" font-family="${SANS}" font-weight="700" font-size="1.9" fill="#c83a2a">$2 OFF</text><text x="9" y="21" text-anchor="middle" font-family="${SANS}" font-size="0.9" fill="#3a3020">any 3 tacos · Tue only</text></g>`
            + '<rect x="5" y="-1.4" width="8" height="3" fill="#f2eedc" opacity="0.6" transform="rotate(-4 9 0)"/><path d="M5.2 -1.2v2.8M12.8 -1.6v2.8" stroke="#ffffff" stroke-width="0.15" opacity="0.7"/></g>';
          s += paper(-1, 42, 0.2, 18, 16.4, -5, Cf);
          const Dc = `<rect width="14" height="9" fill="#fff8ee"/><rect x="0.4" y="0.4" width="13.2" height="8.2" fill="none" stroke="#c83a2a" stroke-width="0.3" stroke-dasharray="0.8 0.5"/><text x="7" y="3.4" text-anchor="middle" font-family="${SERIF}" font-weight="700" font-size="1.8" fill="#6a3a1a">BURGER BARN</text><text x="7" y="6.4" text-anchor="middle" font-family="${SANS}" font-weight="700" font-size="2.2" fill="#c83a2a">2 for $5</text><path d="M10 7.6l2.6 -1" stroke="#8a6a4a" stroke-width="0.2" opacity="0.5"/>`;
          s += paper(19, 45, 0.25, 14, 9, 7, Dc);
          s += paper(25, 33, 0.3, 9, 9, -4, `<rect width="9" height="9" fill="#f6a8c4"/><rect width="9" height="1.6" fill="#e890b0"/><text x="4.5" y="4.6" text-anchor="middle" font-family="${HAND}" font-size="1.7" fill="#3a2a6a">pizza</text><text x="4.5" y="7" text-anchor="middle" font-family="${HAND}" font-weight="700" font-size="2" fill="#3a2a6a">Fri!</text>`);
          s += pin(-30, 44.4, '#d83a2a') + pin(-8.6, 45.4, '#2f6ad0') + pin(26, 43.4, '#3aa050');
          // towel holder: back plates + arms, axle, roll, prints, perforation, hanging sheet
          s += shW(C, -19, RY + 4, 38, 10, 4, 0.2);
          [-21, 21].forEach(x => { s += box3(C, { c: [x, RY - 5, 0.6], w: 3.6, h: 9, d: 1.2, col: '#eceae0', r: 0.6, dec: x > 0 ? { f: '<path d="M0.6 2.6L1.6 4.2L1.2 5.4L2.4 7" stroke="#7a766e" stroke-width="0.2" fill="none"/>' } : null })
            + cyl3(C, [x, RY - 7.4, 1.2], [x, RY - 7.4, 1.5], 0.5, '#b8bcc0', { n: 10 }) + box3(C, { c: [x, RY - 1.3, 3.8], w: 2.2, h: 2.6, d: 5.2, col: '#eceae0', r: 0.4 }); });
          s += box3(C, { c: [21, RY - 1.6, 3.6], w: 2.7, h: 3.2, d: 4.2, col: '#9ea1a6', r: 0.3, dec: { f: '<path d="M0.2 0.8L2.4 1.2M0.3 2.2L2.5 1.9" stroke="#ffffff" stroke-width="0.15" opacity="0.5"/>', t: '<path d="M0.4 0.6L2.2 1.4M0.3 2.8L2.4 2.4" stroke="#6a6c70" stroke-width="0.15"/>' } });
          s += cyl3(C, [-21, RY, RZ], [21, RY, RZ], 0.55, '#d8d6cc', { n: 10 });
          const rollCap = cr => `<circle r="${f1(cr)}" fill="#f2efe6"/>` + rep(5, i => `<circle r="${f1(cr * (0.36 + i * 0.12))}" fill="none" stroke="#d6d0c2" stroke-width="${f1(cr * 0.015)}"/>`).join('') + `<circle r="${f1(cr * 0.3)}" fill="#b88a58"/><circle r="${f1(cr * 0.23)}" fill="#4a3628"/>`;
          s += cyl3(C, [-18.4, RY, RZ], [18.4, RY, RZ], RR, '#f8f6f0', { n: 30, capCol: '#f0ede4', cap: rollCap });
          const flw = (x, y, sc) => `<g transform="translate(${f1(x)} ${f1(y)}) scale(${f1(sc)})"><circle cx="-0.35" r="0.3" fill="#8aa6d8"/><circle cx="0.35" r="0.3" fill="#8aa6d8"/><circle cy="-0.35" r="0.3" fill="#8aa6d8"/><circle cy="0.35" r="0.3" fill="#8aa6d8"/><circle r="0.22" fill="#f2d04a"/></g>`;
          s += rep(16, () => { const x = -17 + R() * 34, a = (R() - 0.3) * 1.8, p = C.P([x, RY + RR * Math.sin(a), RZ + RR * Math.cos(a)]); return flw(p[0], p[1], k * (0.5 + 0.5 * Math.cos(a))); }).join('');
          s += line3(C, [[-18.4, RY + RR * Math.sin(1), RZ + RR * Math.cos(1)], [18.4, RY + RR * Math.sin(1), RZ + RR * Math.cos(1)]], 0.14, '#c8c2b4', `stroke-dasharray="${f1(0.6 * k)} ${f1(0.4 * k)}"`);
          const SW = 36.8, SHh = 19, tear = rep(13, i => [SW - i * SW / 12, SHh + (i % 2 ? 0.9 : 0) + R() * 0.7]);
          let sh = `<path d="M0 0H${SW}${tear.map(p => 'L' + f1(p[0]) + ' ' + f1(p[1])).join('')}Z" fill="#faf8f2"/>` + rep(60, i => `<circle cx="${f1(1.5 + (i % 12) * 3.05)}" cy="${f1(1.6 + Math.floor(i / 12) * 3.4)}" r="0.2" fill="#e4e0d4"/>`).join('')
            + rep(10, () => flw(1.5 + R() * 33.8, 2 + R() * 15.6, 0.9)).join('') + `<path d="M0 9.6H${SW}" stroke="#c8c2b4" stroke-width="0.16" stroke-dasharray="0.6 0.4"/>`
            + `<rect width="${SW}" height="2.6" fill="url(#k04s)"/><ellipse cx="27" cy="13.6" rx="1.3" ry="1.7" fill="#d8b060" opacity="0.22"/><path d="M${SW - 0.2} 0V${SHh}" stroke="#d8d4c8" stroke-width="0.3"/>`;
          s += swayAt(C, [0, RY, RZ + RR], 1.4, 5.2, 0.4, WD(C, -SW / 2, RY, RZ + RR + 0.05, sh));
          return { defs: DEF19 + '<defs><linearGradient id="k04s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000000" stop-opacity="0.2"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></linearGradient></defs>', front: s, bb: C.bb(3) }; };
        return D; };

      // KIT-024 magnetic wooden knife strip + chalkboard menu (T2, cosy): pine-framed chalkboard on jute twine from a nail (sways), chalk menu with pastel hearts,
      // cupcake + mug doodles, eraser ghosts, chalk + felt eraser on the ledge; acacia magnetic bar holding chef's knife, bread knife, santoku, red paring knife, shears, honing steel
      N.knife27 = S => { const D = { w: 100, d: 10, mount: 'wall', elev: 44, build: () => [] };
        D.fx = ctx => { const C = camW(ctx), R = rng('knife27'), id = C.u('k24'), Y0 = 10, PN = '#c8965a', NL = [-25, 54, 1.4];
          ext(C, [[-48, 56, 0], [48, 8, 0], [48, 8, 8]]);
          const CH = '#f2f0e8', items = [['Pancakes', '#f6b8c8', '$2'], ['Tomato Soup', '#f6e08a', '$3'], ['Mac & Cheese', '#a8e0c0', '$3'], ['Apple Pie', '#a8c8f0', '$2']];
          let chalk = `<text x="20" y="8.4" text-anchor="middle" font-family="${HAND}" font-weight="700" font-size="3.3" fill="${CH}">Today's Menu</text><path d="M9 9.9q11 1.6 22 -0.4" stroke="${CH}" stroke-width="0.35" fill="none" stroke-linecap="round"/>`;
          items.forEach(([t, c, p], i) => { const y = 13.6 + i * 3.6; chalk += `<path d="M0 0.6C-1 -0.2 -0.6 -1 0 -0.5C0.6 -1 1 -0.2 0 0.6Z" transform="translate(5.6 ${f1(y - 0.7)})" fill="none" stroke="${c}" stroke-width="0.3"/><text x="7.2" y="${f1(y)}" font-family="${HAND}" font-size="2.1" fill="${CH}">${xe(t)}</text><text x="26.4" y="${f1(y)}" text-anchor="end" font-family="${HAND}" font-size="2" fill="${c}">${p}</text>`; });
          chalk += '<path d="M30.6 21.8h4l-0.7 3.6h-2.6z" fill="none" stroke="#f6b8c8" stroke-width="0.3"/><path d="M31.4 22.4l0.2 2.6M32.6 22.4v2.8M33.8 22.4l-0.2 2.6" stroke="#f6b8c8" stroke-width="0.15"/><path d="M30.2 21.8q-0.2 -1.6 1.4 -1.6q0.4 -1.4 2 -0.8q1.6 -0.2 1.4 1.4q0.4 0.6 -0.4 1z" fill="none" stroke="' + CH + '" stroke-width="0.3"/><circle cx="32.8" cy="18.8" r="0.6" fill="none" stroke="#f08080" stroke-width="0.3"/>'
            + '<path d="M31 13.6h3.2v2.6q0 1 -1 1h-1.2q-1 0 -1 -1z" fill="none" stroke="#a8c8f0" stroke-width="0.3"/><path d="M34.2 14.2q1.2 0 1.2 0.9q0 0.9 -1.2 0.9" fill="none" stroke="#a8c8f0" stroke-width="0.3"/><path d="M31.8 12.8q-0.6 -0.8 0 -1.6q0.6 -0.8 0 -1.6M33.4 12.8q-0.6 -0.8 0 -1.6q0.6 -0.8 0 -1.6" fill="none" stroke="' + CH + '" stroke-width="0.22" opacity="0.8"/>';
          const ghost = rep(4, () => `<ellipse cx="${f1(6 + R() * 28)}" cy="${f1(5 + R() * 22)}" rx="${f1(4 + R() * 5)}" ry="${f1(1.2 + R() * 1.6)}" transform="rotate(${f1((R() - 0.5) * 30)} 20 16)" fill="#ffffff" opacity="0.06"/>`).join('') + `<text x="20" y="28" text-anchor="middle" font-family="${HAND}" font-size="1.8" fill="#ffffff" opacity="0.1">Tues: tacos!</text>`;
          const msk = `<defs><mask id="${id}m"><rect x="-2" y="-2" width="44" height="36" fill="#ffffff"/>${rep(110, () => `<circle cx="${f1(R() * 40)}" cy="${f1(R() * 32)}" r="${f1(0.1 + R() * 0.28)}" fill="#000000"/>`).join('')}</mask></defs>`;
          const grain = rep(14, () => `<path d="M${f1(R() * 33)} ${f1(R() * 32)}h${f1(2 + R() * 5)}" stroke="#9a6a3a" stroke-width="0.15" opacity="0.6"/>`).join('');
          const face = grain + '<path d="M0 0L2.4 2.4M40 0L37.6 2.4M0 32L2.4 29.6M40 32L37.6 29.6" stroke="#8a6034" stroke-width="0.2"/><rect x="2.4" y="2.4" width="35.2" height="27.2" fill="#2c302e"/>' + ghost + msk + `<g mask="url(#${id}m)" opacity="0.92">${chalk}</g>`
            + rep(30, () => `<circle cx="${f1(3 + R() * 34)}" cy="${f1(28.4 + R() * 1)}" r="0.12" fill="#ffffff" opacity="0.3"/>`).join('') + '<rect x="2.4" y="2.4" width="35.2" height="27.2" fill="none" stroke="#000000" stroke-width="0.5" opacity="0.4"/>';
          let bd = shW(C, -45, Y0 + 32, 40, 34, 1, 0.34);
          bd += box3(C, { c: [-25, Y0, 1.2], w: 40, h: 32, d: 2.4, col: PN, r: 0.4, dec: { f: face, t: rep(4, () => `<path d="M${f1(R() * 30)} ${f1(0.4 + R() * 1.6)}h${f1(3 + R() * 5)}" stroke="#9a6a3a" stroke-width="0.15" opacity="0.6"/>`).join('') } });
          bd += box3(C, { c: [-25, Y0 - 2, 2], w: 38, h: 2, d: 4, col: shade(PN, 0.95), r: 0.3, dec: { t: rep(24, () => `<circle cx="${f1(R() * 38)}" cy="${f1(R() * 4)}" r="0.14" fill="#ffffff" opacity="0.35"/>`).join('') } });
          bd += cyl3(C, [-38, Y0 + 0.55, 3], [-33, Y0 + 0.55, 3], 0.55, '#f6f4ee', { n: 12 }) + cyl3(C, [-31, Y0 + 0.5, 2.6], [-27.6, Y0 + 0.5, 2.6], 0.5, '#f2a8c0', { n: 12 });
          bd += box3(C, { c: [-16, Y0, 2.4], w: 6.4, h: 1.1, d: 2.6, col: '#4a4f5a', r: 0.2 }) + box3(C, { c: [-16, Y0 + 1.1, 2.4], w: 6.4, h: 1.5, d: 2.6, col: '#d8b078', r: 0.3, dec: { f: `<text x="3.2" y="1.1" text-anchor="middle" font-family="${SANS}" font-weight="700" font-size="0.9" fill="#7a4a22">ERASER</text>` } });
          [-41, -9].forEach(x => bd += WD(C, x, Y0 + 32.8, 1.5, '<circle r="0.6" fill="none" stroke="#b8a070" stroke-width="0.3"/>'));
          const tw = [[-41, Y0 + 32.6, 1.6], NL, [-9, Y0 + 32.6, 1.6]];
          bd += line3(C, tw, 0.6, '#a8844e') + line3(C, tw, 0.3, '#d8b884', `stroke-dasharray="${f1(0.4 * C.k)} ${f1(0.4 * C.k)}"`);
          let s = swayAt(C, NL, 0.8, 6.4, 0, bd) + cyl3(C, [NL[0], NL[1], 0], [NL[0], NL[1], 2.3], 0.32, '#8a8f96', { n: 8 }) + sp3(C, [NL[0], NL[1], 2.4], 0.7, '#9aa0a8');
          // acacia magnetic strip
          const bg = rep(8, () => `<path d="M${f1(R() * 30)} ${f1(0.4 + R() * 4.2)}q${f1(3 + R() * 4)} ${f1((R() - 0.5) * 0.6)} ${f1(8 + R() * 6)} 0" stroke="#6a3a1c" stroke-width="0.15" fill="none" opacity="0.55"/>`).join('');
          s += shW(C, 2, 35, 44, 5, 1, 0.3) + box3(C, { c: [24, 30, 1.4], w: 44, h: 5, d: 2.8, col: '#9a5f34', r: 0.5, dec: { f: bg + '<circle cx="2.4" cy="2.5" r="0.7" fill="#c9a24a"/><path d="M1.9 2.5h1" stroke="#7a5a1a" stroke-width="0.2"/><circle cx="41.6" cy="2.5" r="0.7" fill="#c9a24a"/><path d="M41.1 2.5h1" stroke="#7a5a1a" stroke-width="0.2"/>', t: rep(4, () => `<path d="M${f1(R() * 32)} ${f1(0.4 + R() * 2)}h${f1(4 + R() * 6)}" stroke="#6a3a1c" stroke-width="0.15" opacity="0.55"/>`).join('') } });
          const KN = [
            [5.6, 27, 'M0 0V-17.6Q0 -20.6 1 -23Q3.4 -19.4 4.4 -13Q4.8 -5 4.6 0Z', 'M0.3 1.3H4.3L4.1 12.2Q2.3 13.4 0.5 12.2Z', '#2a2624', '<rect width="4.6" height="1.3" fill="#aab2b8"/><circle cx="2.3" cy="4" r="0.42" fill="#dfe3e6"/><circle cx="2.3" cy="7.4" r="0.42" fill="#dfe3e6"/><circle cx="2.3" cy="10.6" r="0.42" fill="#dfe3e6"/><path d="M3.4 -0.4Q3.8 -6 3.5 -12.4Q2.8 -18 1.3 -21.6" stroke="#ffffff" stroke-width="0.3" fill="none" opacity="0.55"/>'],
            [12.4, 27.6, 'M0 0V-19.6Q0.2 -21.4 1.6 -21.6H3.1V0Z', 'M0 0.6H3.1V11Q1.55 12 0 11Z', '#8a5a30', '<rect width="3.1" height="0.6" fill="#c8ccd0"/><path d="M3.1 -21' + rep(23, () => 'q-0.5 0.45 0 0.9').join('') + '" stroke="#88929a" stroke-width="0.18" fill="none"/><path d="M0.8 2v8M2 3v7" stroke="#6a4020" stroke-width="0.15"/>'],
            [18.8, 27, 'M0 0V-13Q0 -15.4 2.4 -15.4Q4 -15.2 4.4 -13V0Z', 'M0.3 1.2H4.1V11.4Q2.2 12.4 0.3 11.4Z', '#d8b07a', '<rect width="4.4" height="1.2" fill="#2a2624"/>' + [-2.5, -5.5, -8.5, -11.5].map(y => `<ellipse cx="3.2" cy="${y}" rx="0.45" ry="0.9" fill="#9aa4ac" opacity="0.6"/>`).join('') + '<path d="M1.2 3v7M2.8 3v7" stroke="#b08a50" stroke-width="0.15"/>'],
            [25.6, 28.6, 'M0 0V-7.6Q0.2 -9.4 2.8 -9.8Q2.9 -5 2.8 0Z', 'M0 0.2H2.8V7Q1.4 7.8 0 7Z', '#c83a2a', '<path d="M0.5 1v5.4" stroke="#f08070" stroke-width="0.3" opacity="0.6"/>'],
            [31.2, 28.4, 'M0.2 0L0.9 -10.8Q1.3 -11.4 1.6 -10.8L2 0ZM1.6 0L2.4 -10.2Q2.8 -10.6 3 -10L3.4 0Z', '', '', '<circle cx="1.8" cy="0.4" r="0.55" fill="#6a7278"/><ellipse cx="0.6" cy="3.6" rx="1.4" ry="2.4" fill="none" stroke="#e8772a" stroke-width="0.9"/><ellipse cx="3" cy="3.4" rx="1.3" ry="2.2" fill="none" stroke="#e8772a" stroke-width="0.9"/>']];
          KN.forEach(([x, y, bl, hd, hc, ex]) => s += WD(C, x, y, 2.85, `<g transform="translate(0.45 0.7)" opacity="0.28" filter="url(#m12b1)"><path d="${bl}" fill="#000000"/>${hd ? `<path d="${hd}" fill="#000000"/>` : ''}</g><path d="${bl}" fill="url(#k24st)" stroke="#6a747c" stroke-width="0.15"/>${hd ? `<path d="${hd}" fill="${hc}" stroke="${shade(hc, 0.6)}" stroke-width="0.15"/>` : ''}${ex}`));
          s += cyl3(C, [40.6, 12, 3.4], [40.6, 20, 3.4], 0.9, '#2a2624', { n: 12 }) + cyl3(C, [40.6, 19.8, 3.4], [40.6, 20.4, 3.4], 1.4, '#b8c0c6', { n: 14, mat: 'gloss' }) + cyl3(C, [40.6, 20.4, 3.4], [40.6, 44, 3.4], 0.55, '#8a9098', { n: 12, mat: 'gloss' });
          return { defs: DEF19 + '<defs><linearGradient id="k24st" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8e98a0"/><stop offset="0.45" stop-color="#e8edf0"/><stop offset="0.7" stop-color="#c4ccd2"/><stop offset="1" stop-color="#f6f8fa"/></linearGradient></defs>', front: s, bb: C.bb(3) }; };
        return D; };

      // KIT-044 wall-mounted French copper saucepan + skillet rail (T3): black wrought-iron rail on scrolled brackets with brass finials, S-hooks, hammered copper
      // skillet + 3 graded saucepans + butter warmer on long iron handles (copper bottoms facing out: polish rings, dents, CUIVRE stamp), copper ladle, brass whisk; all sway
      N.copper27 = S => { const D = { w: 110, d: 22, mount: 'wall', elev: 50, build: () => [] };
        D.fx = ctx => { const C = camW(ctx), R = rng('copper27'), RY = 32, RZ = 7.2, IR = '#2b2724', CU = '#b8683a', BR = '#c99a3e', HY = RY - 4.3;
          ext(C, [[-55, RY + 4, 0], [55, -5, 0], [55, -5, 14]]);
          const mkD = () => rep(22, () => { const a = R() * 2 * PI, d = Math.sqrt(R()) * 0.82; return [Math.cos(a) * d, Math.sin(a) * d, 0.04 + R() * 0.05]; });
          const capCu = dn => cr => `<circle r="${f1(cr)}" fill="url(#k44cu)"/>` + rep(4, i => `<circle r="${f1(cr * (0.24 + i * 0.19))}" fill="none" stroke="${i % 2 ? '#f6b882' : '#8a4424'}" stroke-width="${f1(cr * 0.014)}" opacity="0.45"/>`).join('')
            + dn.map(([x, y, r]) => `<ellipse cx="${f1(x * cr)}" cy="${f1(y * cr)}" rx="${f1(r * cr)}" ry="${f1(r * cr * 0.8)}" fill="#7a3a1c" opacity="0.25"/><ellipse cx="${f1((x - r * 0.5) * cr)}" cy="${f1((y - r * 0.5) * cr)}" rx="${f1(r * cr * 0.6)}" ry="${f1(r * cr * 0.45)}" fill="#ffd0a0" opacity="0.35"/>`).join('')
            + `<circle r="${f1(cr * 0.2)}" fill="none" stroke="#7a3a1e" stroke-width="${f1(cr * 0.016)}" opacity="0.6"/><text y="${f1(cr * 0.035)}" text-anchor="middle" font-family="${SERIF}" font-size="${f1(cr * 0.085)}" fill="#6a3018" opacity="0.7">CUIVRE</text>`
            + `<ellipse cx="${f1(-cr * 0.36)}" cy="${f1(-cr * 0.4)}" rx="${f1(cr * 0.34)}" ry="${f1(cr * 0.15)}" transform="rotate(-38 ${f1(-cr * 0.36)} ${f1(-cr * 0.4)})" fill="#ffe4c4" opacity="0.4"/><circle r="${f1(cr * 0.97)}" fill="none" stroke="#6a2e16" stroke-width="${f1(cr * 0.03)}" opacity="0.5"/>`;
          const PANS = [[-40, 9, 3.6, 11, 0.8, 6.2, 0], [-20.5, 7, 6, 8, 1, 5.4, 1.2], [-3.5, 6, 5.4, 7, 1, 5, 2.1], [11, 5, 4.6, 6, 1.2, 4.6, 0.6], [23.5, 3.4, 3.6, 7, 1.4, 4.2, 1.7]];
          let s = shW(C, -50, RY + 1, 100, 2, 1, 0.25);
          PANS.forEach(([x, r, d, Lh]) => { const cy = HY - Lh - r; s += WD(C, x - r + 1.4, cy + r - 2.6, 0.05, `<circle cx="${r}" cy="${r}" r="${r}" fill="#000000" opacity="0.2" filter="url(#m10b3)"/>`); });
          [-46, 46].forEach(x => { s += cyl3(C, [x, RY, 0], [x, RY, 0.8], 2.2, IR, { n: 18, capCol: shade(IR, 1.3), cap: cr => `<circle r="${f1(cr * 0.6)}" fill="none" stroke="#4a4440" stroke-width="${f1(cr * 0.1)}"/>` }) + cyl3(C, [x, RY - 5.4, 0], [x, RY - 5.4, 0.6], 1.1, IR, { n: 14 })
            + line3(C, [[x, RY - 5.4, 0.5], [x, RY - 4.2, 2.6], [x, RY - 2.4, 4.6], [x, RY - 0.8, RZ - 0.4]], 0.45, IR) + cyl3(C, [x, RY, 0.8], [x, RY, RZ], 0.55, IR, { n: 10 }); });
          s += cyl3(C, [-50, RY, RZ], [50, RY, RZ], 0.85, IR, { n: 14, mat: 'gloss' });
          [-1, 1].forEach(sg => s += cyl3(C, [sg * 50, RY, RZ], [sg * 51, RY, RZ], 1.1, BR, { n: 14, mat: 'gloss' }) + sp3(C, [sg * 52.3, RY, RZ], 1.4, BR));
          PANS.forEach(([x, r, d, Lh, a, du, ph]) => { const cy = HY - Lh - r, z0 = RZ - d / 2, z1 = RZ + d / 2;
            const g = cyl3(C, [x, cy, z0], [x, cy, z0 + 0.7], r + 0.45, shade(CU, 0.9), { n: 30, mat: 'gloss' }) + cyl3(C, [x, cy, z0 + 0.7], [x, cy, z1], r, CU, { n: 30, mat: 'gloss', cap: capCu(mkD()) })
              + [-1, 1].map(sg => sp3(C, [x + sg * 1.1, cy + r + 0.1, z0 + 1.5], 0.38, shade(CU, 1.1))).join('')
              + line3(C, [[x, HY, RZ], [x, cy + r + 0.4, z0 + 1.5]], 1.9, IR) + line3(C, [[x - 0.4, HY - 1.4, RZ + 0.1], [x - 0.4, cy + r + 0.9, z0 + 1.6]], 0.35, '#6a625c') + WD(C, x, HY, RZ + 0.3, '<circle r="0.7" fill="#14110f"/>');
            s += swayAt(C, [x, HY + 0.4, RZ], a, du, ph, g); });
          s += swayAt(C, [33.5, HY + 0.4, RZ], 1.3, 4.4, 0.9, line3(C, [[33.5, HY, RZ], [33.5, HY - 13, RZ + 0.8]], 1.1, IR) + WD(C, 33.5, HY, RZ + 0.2, '<circle r="0.45" fill="#14110f"/>') + sp3(C, [33.5, HY - 15.6, RZ + 1.2], 2.9, CU) + line3(C, [[31, HY - 14.9, RZ + 1.4], [36, HY - 14.9, RZ + 1.4]], 0.3, shade(CU, 1.3)));
          { const x = 43.5; let g = WD(C, x, HY - 0.2, RZ + 0.1, `<circle r="0.8" fill="none" stroke="${BR}" stroke-width="0.35"/>`) + cyl3(C, [x, HY - 1, RZ], [x, HY - 8, RZ], 0.62, BR, { n: 12, mat: 'gloss' });
            g += WD(C, x, HY - 8, RZ + 0.3, [3.2, 2.2, 1.1, 0.25].map((w, i) => `<path d="M0 0C${-w} 3.6 ${-w} 9 0 10.4C${w} 9 ${w} 3.6 0 0Z" fill="none" stroke="${i % 2 ? '#b8bec4' : '#e4e8ec'}" stroke-width="0.24"/>`).join(''));
            s += swayAt(C, [x, HY + 0.4, RZ], 1.5, 3.9, 2.4, g); }
          [-40, -20.5, -3.5, 11, 23.5, 33.5, 43.5].forEach(x => s += sHook(C, x, RY + 1, RZ + 0.95, 1, '#3a3532'));
          return { defs: DEF19 + '<defs><radialGradient id="k44cu" cx="38%" cy="32%" r="75%"><stop offset="0" stop-color="#f6b886"/><stop offset="0.35" stop-color="#d07a48"/><stop offset="0.75" stop-color="#a85630"/><stop offset="1" stop-color="#7a3a20"/></radialGradient></defs>', front: s, bb: C.bb(3) }; };
        return D; };

      // KIT-064 framed vintage wine maps + brass utensil gallery rail (T4 luxury): Bordeaux + Bourgogne maps on aged parchment (rivers, vineyard parcels, villages,
      // cartouche, compass rose) in walnut frames with a gilt fillet + linen mat + glass sheen, polished brass picture lights whose warm wash breathes;
      // polished brass rail with olive-wood + brass ladle, skimmer, slotted spoon, whisk, fish slice, carving fork, pastry brush, each swaying
      N.winemap27 = S => { const D = { w: 112, d: 14, mount: 'wall', elev: 50, build: () => [] };
        D.fx = ctx => { const C = camW(ctx), R = rng('winemap27'), BR = '#c99a3e', FW = 42, FH = 30, Y0 = 16, RY = 9, RZ = 4.2, HY = RY - 2.5;
          ext(C, [[-54, Y0 + FH + 7, 0], [54, -14, 0], [54, -14, 8]]);
          const mapArt = kd => { const W2 = 28.4, H2 = 18; let m = `<rect width="${W2}" height="${H2}" fill="#ead8ae"/>` + rep(16, () => `<circle cx="${f1(R() * W2)}" cy="${f1(R() * H2)}" r="${f1(0.15 + R() * 0.45)}" fill="#c09a5e" opacity="${f1(0.15 + R() * 0.25)}"/>`).join('');
            const vil = (x, y, n, e) => `<circle cx="${x}" cy="${y}" r="0.32" fill="#5a3a22"/><text x="${f1(x + (e ? -0.6 : 0.6))}" y="${f1(y + 0.3)}" text-anchor="${e ? 'end' : 'start'}" font-family="${SERIF}" font-style="italic" font-size="0.85" fill="#4a3020">${n}</text>`;
            const parc = (x, y, w, h, r, c) => `<g transform="rotate(${r} ${x} ${y})"><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${c}" opacity="0.75"/><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#k64h)"/><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="none" stroke="#6a5030" stroke-width="0.08"/></g>`;
            const PC = ['#b4a06a', '#a6ae78', '#c49a7a', '#b8946a'];
            const cart = (x, t, sub) => `<rect x="${x}" y="1" width="11.4" height="5" fill="#f2e4c0" stroke="#6a4a2a" stroke-width="0.2"/><rect x="${f1(x + 0.4)}" y="1.4" width="10.6" height="4.2" fill="none" stroke="#6a4a2a" stroke-width="0.1"/><text x="${f1(x + 5.7)}" y="3.5" text-anchor="middle" font-family="${SERIF}" font-style="italic" font-weight="700" font-size="1.6" fill="#5a2a1e">${t}</text><text x="${f1(x + 5.7)}" y="4.9" text-anchor="middle" font-family="${SERIF}" font-size="0.7" fill="#5a3a22" letter-spacing="0.08">${sub}</text>`;
            const rose = (x, y) => `<g transform="translate(${x} ${y})"><circle r="1.3" fill="none" stroke="#5a3a22" stroke-width="0.1"/><path d="M0 -2L0.4 -0.4L2 0L0.4 0.4L0 2L-0.4 0.4L-2 0L-0.4 -0.4Z" fill="#5a3a22"/><path d="M0 -2L0.4 -0.4L0 0ZM2 0L0.4 0.4L0 0ZM0 2L-0.4 0.4L0 0ZM-2 0L-0.4 -0.4L0 0Z" fill="#f2e4c0"/><text y="-2.3" text-anchor="middle" font-family="${SERIF}" font-size="0.7" fill="#5a3a22">N</text></g>`;
            if (kd === 'bdx') { m += rep(9, i => `<path d="M0 ${f1(1 + i * 1.8)}h${f1(1.4 + R() * 1.6)}" stroke="#7a9aa0" stroke-width="0.18" opacity="0.6"/>`).join('');
              [[5.4, 4.6, 2, 1.1, 30], [7.6, 6, 2.2, 1, 36], [9.4, 8, 1.8, 1.2, 42], [12.4, 8.4, 2, 1, 38], [13.8, 10.6, 2.2, 1.1, 30], [16.4, 11.8, 1.8, 1, 28], [10, 11.2, 2, 1, 40], [17.6, 15.6, 2.2, 1.2, 10], [22.4, 12.4, 2, 1.1, -10], [25, 13.2, 2.2, 1, -6], [23, 16.6, 2, 1, 4], [19.6, 9.6, 1.8, 1, 32]].forEach(([x, y, w, h, r], i) => m += parc(x, y, w, h, r, PC[i % 4]));
              m += '<path d="M0 2.4C4 3.6 8 5.4 11 8.6C13.4 11 16.4 12.6 19.6 14.4" stroke="#9ab2b2" stroke-width="1.8" fill="none" stroke-linecap="round"/><path d="M19.6 14.4C22 15.4 25 15.8 28.4 16.4M19.6 14.4C20.6 15.8 21.2 16.8 21.6 18" stroke="#9ab2b2" stroke-width="0.8" fill="none"/><path d="M0 2.4C4 3.6 8 5.4 11 8.6C13.4 11 16.4 12.6 19.6 14.4" stroke="#6a8a90" stroke-width="0.12" fill="none" opacity="0.6"/>';
              m += vil(6.4, 4, 'St-Estèphe') + vil(8.8, 7.2, 'Pauillac') + vil(13.4, 12.6, 'Margaux', 1) + vil(17.4, 17.2, 'Pessac', 1) + vil(23.4, 12, 'St-Émilion') + cart(16.2, 'Bordeaux', 'CARTE DES VIGNOBLES') + rose(3.6, 15); }
            else { m += rep(26, () => { const x = 1 + R() * 9, y = 7 + R() * 10; return `<path d="M${f1(x)} ${f1(y)}l${f1(0.4 + R() * 0.4)} ${f1(-0.8 - R() * 0.4)}" stroke="#8a6a44" stroke-width="0.12" opacity="0.55"/>`; }).join('');
              m += '<path d="M28.4 4C26 7 27.6 10 25.6 13C24 15.6 25.4 17 24.6 18" stroke="#9ab2b2" stroke-width="0.9" fill="none"/><path d="M24 1C21 5 17 8.4 13.6 11.4C11 13.6 8 15.6 5 17.6" stroke="#8a5a3a" stroke-width="0.3" stroke-dasharray="0.8 0.4" fill="none"/>';
              rep(12, i => { const t = i / 11, x = 24 - 19 * t + 1.2, y = 1.4 + 16 * t; m += parc(f1(x), f1(y), 2.4, 1.1, -38, PC[i % 4]); });
              m += vil(21.4, 3.8, 'Gevrey', 1) + vil(17.2, 7.6, 'Nuits', 1) + vil(12.4, 11.8, 'Beaune', 1) + vil(8.8, 15, 'Meursault', 1) + cart(1, 'Bourgogne', "CÔTE D'OR") + rose(26.2, 2.8); }
            return m + `<rect width="${W2}" height="${H2}" fill="url(#k64v)"/><rect width="${W2}" height="${H2}" fill="none" stroke="#6a4a2a" stroke-width="0.25"/>`; };
          let s = '';
          [-25, 25].forEach((cx, j) => { const LY = Y0 + FH + 3.6;
            s += WD(C, cx - FW / 2 - 8, Y0 + FH + 6, 0.04, `<ellipse cx="${FW / 2 + 8}" cy="14" rx="${FW / 2 + 5}" ry="16" fill="#ffd890" opacity="0.18" filter="url(#m11b8)">${an('opacity', '0.14;0.24;0.14', 9, j * 2, SPL(2))}</ellipse>`);
            s += shW(C, cx - FW / 2, Y0 + FH, FW, FH, 0.6, 0.38);
            const grain = rep(18, () => `<path d="M${f1(R() * (FW - 8))} ${f1(R() * FH)}h${f1(2 + R() * 6)}" stroke="#2e1a0e" stroke-width="0.18" opacity="0.5"/>`).join('');
            const face = `<rect width="${FW}" height="${FH}" fill="url(#k64w)"/>${grain}<path d="M0 0L2.2 2.2M${FW} 0L${FW - 2.2} 2.2M0 ${FH}L2.2 ${FH - 2.2}M${FW} ${FH}L${FW - 2.2} ${FH - 2.2}" stroke="#1e1008" stroke-width="0.2"/><rect x="0.25" y="0.25" width="${FW - 0.5}" height="${FH - 0.5}" fill="none" stroke="#7a5236" stroke-width="0.3"/>`
              + `<rect x="2.2" y="2.2" width="${FW - 4.4}" height="${FH - 4.4}" fill="none" stroke="url(#k64g)" stroke-width="0.9"/><rect x="2.65" y="2.65" width="${FW - 5.3}" height="${FH - 5.3}" fill="#efe6d2"/>` + rep(16, i => `<path d="M2.7 ${f1(3 + i * 1.55)}H${FW - 2.7}" stroke="#d8ccb2" stroke-width="0.08" opacity="0.45"/>`).join('')
              + `<rect x="6.3" y="5.7" width="29.4" height="18.6" fill="#fbf6ea"/><g transform="translate(6.8 6.2)">${mapArt(j ? 'bgn' : 'bdx')}</g><path d="M2.65 2.65H14L6 27.35H2.65Z" fill="#ffffff" opacity="0.07"/><path d="M17 2.65H20L12 27.35H9Z" fill="#ffffff" opacity="0.05"/>`;
            s += box3(C, { c: [cx, Y0, 1.3], w: FW, h: FH, d: 2.6, col: '#4a2a18', r: 0.3, dec: { f: face, t: rep(5, () => `<path d="M${f1(R() * 32)} ${f1(0.4 + R() * 1.8)}h${f1(3 + R() * 5)}" stroke="#2e1a0e" stroke-width="0.18" opacity="0.5"/>`).join('') } });
            s += WD(C, cx - FW / 2, Y0 + FH + 0.2, 2.65, `<path d="M9 0H${FW - 9}L${FW} ${FH}H0Z" fill="url(#k64l)" opacity="0.5">${an('opacity', '0.42;0.58;0.42', 9, j * 2, SPL(2))}</path>`);
            s += cyl3(C, [cx, LY + 1, 0], [cx, LY + 1, 0.6], 1.5, BR, { n: 16, mat: 'gloss' }) + line3(C, [[cx, LY + 1, 0.6], [cx, LY + 2.4, 2.2], [cx, LY + 1.4, 4.2]], 0.55, shade(BR, 0.85))
              + cyl3(C, [cx - 10, LY, 4.6], [cx + 10, LY, 4.6], 1.25, BR, { n: 16, mat: 'gloss', capCol: shade(BR, 1.1) }) + line3(C, [[cx - 9.4, LY - 1, 5.35], [cx + 9.4, LY - 1, 5.35]], 0.4, '#fff2c4', 'opacity="0.9"'); });
          // brass gallery rail + utensils
          s += shW(C, -48, RY + 1, 96, 2, 1, 0.25);
          [-40, 40].forEach(x => s += cyl3(C, [x, RY, 0], [x, RY, 0.6], 1.4, BR, { n: 16, mat: 'gloss' }) + cyl3(C, [x, RY, 0.6], [x, RY, RZ], 0.4, BR, { n: 10 }));
          s += cyl3(C, [-48, RY, RZ], [48, RY, RZ], 0.7, BR, { n: 14, mat: 'gloss' });
          [-1, 1].forEach(sg => s += cyl3(C, [sg * 48, RY, RZ], [sg * 48.8, RY, RZ], 1, BR, { n: 14, mat: 'gloss' }) + sp3(C, [sg * 49.9, RY, RZ], 1.1, BR));
          ['ladle', 'skim', 'slot', 'whisk', 'fish', 'fork', 'brush'].forEach((u, i) => { const x = -39 + i * 13, y1 = HY - 8.8, zH = RZ + 0.6;
            let g = WD(C, x, HY, RZ + 0.2, `<circle r="0.75" fill="none" stroke="${BR}" stroke-width="0.32"/>`) + line3(C, [[x, HY - 0.6, RZ], [x, HY - 7.6, RZ + 0.25]], 1.35, '#8a6438') + line3(C, [[x - 0.32, HY - 1, RZ + 0.1], [x - 0.32, HY - 7.2, RZ + 0.35]], 0.35, '#c8a070', 'opacity="0.8"')
              + cyl3(C, [x, HY - 7.6, RZ + 0.25], [x, y1, RZ + 0.3], u === 'brush' ? 1.05 : 0.78, BR, { n: 12, mat: 'gloss' });
            const nk = L => line3(C, [[x, y1, RZ + 0.3], [x, y1 - L, zH]], 0.55, shade(BR, 0.9)) + line3(C, [[x - 0.12, y1, RZ + 0.35], [x - 0.12, y1 - L, zH]], 0.15, '#fff0c0', 'opacity="0.7"');
            if (u === 'ladle') g += nk(4.4) + sp3(C, [x, y1 - 6.8, RZ + 1.2], 2.5, BR) + line3(C, [[x - 2.2, y1 - 6.2, RZ + 1.4], [x + 2.2, y1 - 6.2, RZ + 1.4]], 0.25, '#fff0c0');
            else if (u === 'skim') { g += nk(4); const r = 3.1; let m = ''; for (let q = -2.4; q <= 2.41; q += 0.8) { const h = Math.sqrt(r * r - q * q); m += `<path d="M${f1(q)} ${f1(-h)}V${f1(h)}M${f1(-h)} ${f1(q)}H${f1(h)}" stroke="${BR}" stroke-width="0.14"/>`; }
              g += WD(C, x, y1 - 4 - r, zH, `<circle r="${r}" fill="#2a1a0c" opacity="0.15"/>${m}<circle r="${r}" fill="none" stroke="url(#k64b)" stroke-width="0.55"/>`); }
            else if (u === 'slot') g += nk(3.4) + WD(C, x, y1 - 6.6, zH, `<ellipse rx="2.3" ry="3.3" fill="url(#k64b)" stroke="#8a6420" stroke-width="0.2"/>${[-1.1, 0, 1.1].map(sx => `<rect x="${f1(sx - 0.25)}" y="-1.8" width="0.5" height="3.2" rx="0.25" fill="#3a2810"/>`).join('')}<ellipse cx="-0.9" cy="-1.8" rx="0.6" ry="1" fill="#ffffff" opacity="0.35"/>`);
            else if (u === 'whisk') g += WD(C, x, y1, zH, [2.6, 1.8, 0.9, 0.2].map((w, j) => `<path d="M0 0C${-w} 3 ${-w} 7.6 0 8.8C${w} 7.6 ${w} 3 0 0Z" fill="none" stroke="${j % 2 ? '#b8bec4' : '#e4e8ec'}" stroke-width="0.22"/>`).join(''));
            else if (u === 'fish') g += nk(3) + WD(C, x, y1 - 3, zH, `<path d="M-1.4 0H1.4L2.8 8.2Q0 9.2 -2.8 8.2Z" fill="url(#k64b)" stroke="#8a6420" stroke-width="0.2"/>${[-1.2, -0.4, 0.4, 1.2].map(sx => `<path d="M${f1(sx * 0.8)} 1.6L${f1(sx * 1.3)} 7" stroke="#3a2810" stroke-width="0.4" stroke-linecap="round"/>`).join('')}`);
            else if (u === 'fork') g += nk(1.2) + WD(C, x, y1 - 1.2, zH, '<path d="M-1.3 0H1.3V1.2H-1.3Z" fill="url(#k64b)"/><path d="M-1.1 1.2V8.4L-0.75 9.4L-0.4 8.4V1.2ZM0.4 1.2V8.4L0.75 9.4L1.1 8.4V1.2Z" fill="url(#k64b)" stroke="#8a6420" stroke-width="0.12"/>');
            else g += WD(C, x, y1, zH, rep(9, j => `<path d="M${f1(-0.9 + j * 0.22)} 0L${f1(-1.3 + j * 0.32)} 5.6" stroke="${j % 2 ? '#e8d8b0' : '#d8c494'}" stroke-width="0.3" stroke-linecap="round"/>`).join('') + '<path d="M-1.3 5.2H1.3" stroke="#c8a868" stroke-width="0.4" opacity="0.6"/>');
            s += swayAt(C, [x, HY + 0.4, RZ], 1.1, 4.8 + i * 0.37, i * 0.7, g); });
          [-39, -26, -13, 0, 13, 26, 39].forEach(x => s += sHook(C, x, RY + 0.85, RZ + 0.75, 0.75, '#b88a32'));
          return { defs: DEF19 + '<defs><linearGradient id="k64w" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6a3e22"/><stop offset="0.5" stop-color="#4a2a18"/><stop offset="1" stop-color="#341c0e"/></linearGradient>'
            + '<linearGradient id="k64g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0b0"/><stop offset="0.35" stop-color="#e2b456"/><stop offset="0.7" stop-color="#b38432"/><stop offset="1" stop-color="#f2d488"/></linearGradient>'
            + '<linearGradient id="k64b" x1="0" y1="0" x2="1" y2="0.4"><stop offset="0" stop-color="#a87a2a"/><stop offset="0.4" stop-color="#f6dc8a"/><stop offset="0.7" stop-color="#c99a3e"/><stop offset="1" stop-color="#8a6420"/></linearGradient>'
            + '<linearGradient id="k64l" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe6a8" stop-opacity="0.65"/><stop offset="0.55" stop-color="#ffe0a0" stop-opacity="0.18"/><stop offset="1" stop-color="#ffe0a0" stop-opacity="0"/></linearGradient>'
            + '<radialGradient id="k64v" cx="50%" cy="50%" r="70%"><stop offset="0.55" stop-color="#8a5a2a" stop-opacity="0"/><stop offset="1" stop-color="#8a5a2a" stop-opacity="0.45"/></radialGradient>'
            + '<pattern id="k64h" width="0.5" height="0.5" patternUnits="userSpaceOnUse"><path d="M0 0.5L0.5 0" stroke="#5a4020" stroke-width="0.06" opacity="0.6"/></pattern></defs>', front: s, bb: C.bb(3) }; };
        return D; };

      // KIT-084 smart-glass recipe wall + floating spice orb rack (T5): frameless smoked-glass panel in a champagne-brass bezel on brass standoffs, warm-lit UI
      // (amber/champagne, no cyan) paging through 3 recipes (dish, steps with the current one lit, timer ring, progress, ingredient chips), soft breathing halo;
      // two floating walnut shelves with brass edges, 8 glass spice orbs (saffron, paprika, turmeric, pink pepper, cardamom, black pepper, fleur de sel, sumac) bobbing over pools of light
      N.smart27 = S => { const D = { w: 122, d: 14, mount: 'wall', elev: 40, build: () => [] };
        D.fx = ctx => { const C = camW(ctx), k = C.k, PX = -58, PW = 64, PY0 = 12, PH = 42, CH = '#d8b878';
          ext(C, [[-62, PY0 + PH + 6, 0], [60, 8, 0], [60, 8, 12]]);
          let s = WD(C, PX - 5, PY0 + PH + 5, 0.04, `<rect width="${PW + 10}" height="${PH + 10}" rx="6" fill="#ffcf7a" opacity="0.2" filter="url(#m11b8)">${an('opacity', '0.16;0.26;0.16', 8, 0, SPL(2))}</rect>`) + shW(C, PX, PY0 + PH, PW, PH, 0.8, 0.35);
          const RC = [{ t: 'Saffron Risotto', m: '4 servings · 35 min', st: ['Toast the rice in butter', 'Ladle in warm stock', 'Fold in saffron + parmesan'], tm: '18:00', ing: ['Arborio', 'Saffron', 'Parmesan', 'Shallot'] },
            { t: 'Lemon Meringue Tart', m: '8 slices · 1 h 10', st: ['Blind-bake the pastry', 'Whisk the lemon curd', 'Torch the meringue'], tm: '25:00', ing: ['Lemons', 'Eggs', 'Butter', 'Sugar'] },
            { t: 'Coq au Vin', m: '6 servings · 2 h', st: ['Brown the chicken', 'Deglaze with Burgundy', 'Simmer with mushrooms'], tm: '90:00', ing: ['Chicken', 'Burgundy', 'Mushrooms', 'Onions'] }];
          const dish = i => { const Q = rng('dish27' + i), pt = (rx, ry) => { const a = Q() * 2 * PI, d = Math.sqrt(Q()) * 0.88; return [13 + Math.cos(a) * rx * d, 22 + Math.sin(a) * ry * d]; };
            let o = `<circle cx="13.4" cy="22.6" r="8.2" fill="#000000" opacity="0.35" filter="url(#m12b1)"/><circle cx="13" cy="22" r="8" fill="#efe4cc"/><circle cx="13" cy="22" r="7.7" fill="none" stroke="${CH}" stroke-width="0.25"/><circle cx="13" cy="22" r="5.6" fill="#f8f0de"/>`;
            if (i === 0) { o += '<ellipse cx="13" cy="22.2" rx="4.6" ry="3.8" fill="#e6b648"/>' + rep(40, () => { const [x, y] = pt(4.4, 3.6); return `<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="0.42" ry="0.22" fill="#f6dc8a"/>`; }).join('') + rep(7, () => { const [x, y] = pt(3.6, 3); return `<path d="M${f1(x)} ${f1(y)}l${f1((Q() - 0.5) * 1.4)} ${f1((Q() - 0.5) * 1)}" stroke="#c83a1e" stroke-width="0.18"/>`; }).join('')
              + '<path d="M11 20.6l1.6 -0.4l0.4 1.2l-1.4 0.3z M14.6 23l1.4 0.2l-0.2 1.1l-1.3 -0.3z" fill="#fbf6ea" opacity="0.9"/><ellipse cx="14.4" cy="20.6" rx="0.9" ry="0.45" transform="rotate(-30 14.4 20.6)" fill="#5a8a3a"/><ellipse cx="15.2" cy="21" rx="0.8" ry="0.4" transform="rotate(20 15.2 21)" fill="#6a9a4a"/>'; }
            else if (i === 1) { o += '<circle cx="13" cy="22" r="4.9" fill="#cf9a58"/>' + rep(22, j => { const a = j / 22 * 2 * PI; return `<circle cx="${f1(13 + Math.cos(a) * 4.9)}" cy="${f1(22 + Math.sin(a) * 4.9)}" r="0.55" fill="#b88040"/>`; }).join('') + '<circle cx="13" cy="22" r="4.1" fill="#f0cc3a"/>'
              + [[0, 0], [2, -1.2], [-2, -1.2], [2, 1.4], [-2, 1.4], [0, 2.6], [0, -2.6]].map(([dx, dy]) => `<circle cx="${f1(13 + dx)}" cy="${f1(22 + dy)}" r="1" fill="#fbf6ea"/><circle cx="${f1(12.7 + dx)}" cy="${f1(21.6 + dy)}" r="0.38" fill="#d8a060"/>`).join(''); }
            else { o += '<ellipse cx="13" cy="22" rx="4.8" ry="4" fill="#5e1a1e"/><ellipse cx="11.8" cy="20.6" rx="2.2" ry="0.9" fill="#8a3036" opacity="0.6"/>' + [[11.4, 22.4, 1.8, 1.1], [14.6, 21.2, 1.6, 1], [13.6, 24, 1.5, 0.9]].map(([x, y, a, b]) => `<ellipse cx="${x}" cy="${y}" rx="${a}" ry="${b}" fill="#b87448"/><ellipse cx="${f1(x - 0.3)}" cy="${f1(y - 0.3)}" rx="${f1(a * 0.5)}" ry="${f1(b * 0.4)}" fill="#d89a6a"/>`).join('')
              + '<path d="M15.6 23.4a0.9 0.9 0 0 1 1.8 0z M10 20.4a0.8 0.8 0 0 1 1.6 0z" fill="#e0d0b0"/><circle cx="10.4" cy="23.8" r="0.5" fill="#e07a30"/><circle cx="16.4" cy="21.4" r="0.45" fill="#e07a30"/><circle cx="12.4" cy="19.4" r="0.55" fill="#f2ead8"/>' + rep(8, () => { const [x, y] = pt(4.2, 3.4); return `<circle cx="${f1(x)}" cy="${f1(y)}" r="0.2" fill="#6a9a4a"/>`; }).join(''); }
            return o; };
          const KT = [['1;1;0;0;1', '0;0.31;0.333;0.977;1'], ['0;0;1;1;0;0', '0;0.333;0.356;0.643;0.666;1'], ['0;0;1;1;0', '0;0.666;0.689;0.977;1']];
          let ui = `<rect width="${PW}" height="${PH}" fill="url(#k84g)"/><text x="3" y="4" font-family="${SANS}" font-size="1.3" fill="#c8a868" letter-spacing="0.35">CHEF'S TABLE</text><text x="61" y="4" text-anchor="end" font-family="${SANS}" font-size="1.3" fill="#c8a868">18:42</text><path d="M3 5.6H61" stroke="#5a4a32" stroke-width="0.12"/>`
            + `<g>${at('translate', '0 0;0 0;0 4.4;0 4.4;0 8.8;0 8.8;0 0', 10, 0, ' keyTimes="0;0.3;0.34;0.63;0.67;0.97;1"')}<rect x="24.2" y="17.3" width="25.4" height="3.2" rx="0.6" fill="#f2c66a" opacity="0.13"/></g>`
            + `<circle cx="55" cy="22" r="4.4" fill="none" stroke="#3a3024" stroke-width="0.7"/><circle cx="55" cy="22" r="4.4" fill="none" stroke="#f2c66a" stroke-width="0.7" stroke-linecap="round" stroke-dasharray="27.65" transform="rotate(-90 55 22)">${an('stroke-dashoffset', '27.65;0', 10, 0)}</circle>`
            + `<rect x="3" y="33.4" width="58" height="0.5" rx="0.25" fill="#3a3024"/><rect x="3" y="33.4" width="20" height="0.5" rx="0.25" fill="#f2c66a">${an('width', '0;58', 10, 0)}</rect>`;
          RC.forEach((r, i) => { let g = dish(i) + `<text x="25" y="11.6" font-family="${SERIF}" font-style="italic" font-size="3.2" fill="#f6e2a8">${xe(r.t)}</text><text x="25" y="14.4" font-family="${SANS}" font-size="1.3" fill="#b89a60" letter-spacing="0.1">${xe(r.m)}</text>`;
            r.st.forEach((t, j) => { const y = 19.4 + j * 4.4; g += `<circle cx="26" cy="${f1(y - 0.5)}" r="1.1" fill="none" stroke="${CH}" stroke-width="0.2"/><text x="26" y="${f1(y)}" text-anchor="middle" font-family="${SANS}" font-size="1.2" fill="${CH}">${j + 1}</text><text x="28" y="${f1(y)}" font-family="${SANS}" font-size="1.45" fill="#ecd8a6">${xe(t)}</text>`; });
            g += `<text x="55" y="22.6" text-anchor="middle" font-family="${SANS}" font-size="1.9" fill="#f6e2a8">${r.tm}</text><text x="55" y="24.4" text-anchor="middle" font-family="${SANS}" font-size="0.8" fill="#b89a60" letter-spacing="0.2">MIN</text>`;
            r.ing.forEach((t, j) => { const x = 3 + j * 14.6; g += `<rect x="${f1(x)}" y="36.4" width="13.4" height="3" rx="1.5" fill="#241d16" stroke="#6a5638" stroke-width="0.18"/><circle cx="${f1(x + 1.6)}" cy="37.9" r="0.62" fill="${j < 2 ? '#f2c66a' : 'none'}" stroke="#f2c66a" stroke-width="0.18"/>${j < 2 ? `<path d="M${f1(x + 1.25)} 37.9l0.3 0.3l0.55 -0.6" stroke="#1c1712" stroke-width="0.2" fill="none"/>` : ''}<text x="${f1(x + 2.8)}" y="38.4" font-family="${SANS}" font-size="1.2" fill="#d8c090">${xe(t)}</text>`; });
            ui += `<g opacity="${i ? 0 : 1}">${an('opacity', KT[i][0], 30, 0, ' keyTimes="' + KT[i][1] + '"')}${g}</g>`; });
          ui += `<path d="M12 0H20L6 ${PH}H0Z" fill="#ffffff" opacity="0.04"/><rect x="0.3" y="0.3" width="${PW - 0.6}" height="${PH - 0.6}" rx="0.6" fill="none" stroke="url(#k84b)" stroke-width="0.6"/>`;
          s += box3(C, { c: [PX + PW / 2, PY0, 0.7], w: PW, h: PH, d: 1.4, col: '#1c1712', r: 0.3, dec: { f: ui } });
          [[PX + 2.4, PY0 + 2.4], [PX + PW - 2.4, PY0 + 2.4], [PX + 2.4, PY0 + PH - 2.4], [PX + PW - 2.4, PY0 + PH - 2.4]].forEach(([x, y]) => s += cyl3(C, [x, y, 1.4], [x, y, 1.9], 0.85, CH, { n: 14, mat: 'gloss' }));
          // floating spice orbs
          const orb = (q, r, sp, ph, du) => { const [col, ty] = sp, c = C.P(q), cx = c[0], cy = c[1], Rr = r * k, id = C.u('ob'), Q = rng('orb' + col);
            let fl = `<rect x="${f1(cx - Rr)}" y="${f1(cy - Rr * 0.08)}" width="${f1(2 * Rr)}" height="${f1(Rr * 1.1)}" fill="${col}"/>`;
            fl += rep(ty === 'bd' ? 18 : 36, () => { const x = cx + (Q() - 0.5) * 1.8 * Rr, y = cy + Q() * Rr * 0.95, sc = shade(col, 0.75 + Q() * 0.5);
              if (ty === 'th') return `<path d="M${f1(x)} ${f1(y)}l${f1((Q() - 0.5) * 1.4 * k)} ${f1((Q() - 0.5) * 0.9 * k)}" stroke="${Q() < 0.5 ? '#e85a2a' : '#8a1e10'}" stroke-width="${f1(0.14 * k)}"/>`;
              if (ty === 'bd') return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(0.42 * k)}" fill="${sc}"/><circle cx="${f1(x - 0.12 * k)}" cy="${f1(y - 0.12 * k)}" r="${f1(0.12 * k)}" fill="#ffffff" opacity="0.4"/>`;
              if (ty === 'pd') return `<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(0.6 * k)}" ry="${f1(0.32 * k)}" transform="rotate(${f1(Q() * 180)} ${f1(x)} ${f1(y)})" fill="${sc}"/>`;
              if (ty === 'cr') return `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(0.3 * k)}" height="${f1(0.3 * k)}" transform="rotate(${f1(Q() * 90)} ${f1(x)} ${f1(y)})" fill="#ffffff" stroke="#c8c4bc" stroke-width="${f1(0.04 * k)}"/>`;
              return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(0.12 * k)}" fill="${sc}"/>`; }).join('');
            fl += `<ellipse cx="${f1(cx)}" cy="${f1(cy - Rr * 0.08)}" rx="${f1(Rr * 0.92)}" ry="${f1(Rr * 0.2)}" fill="${shade(col, 1.18)}"/>`;
            const body = `<defs><clipPath id="${id}"><circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(Rr * 0.93)}"/></clipPath></defs><circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(Rr)}" fill="#fff4dc" opacity="0.12"/>`
              + `<g clip-path="url(#${id})">${fl}<rect x="${f1(cx - Rr)}" y="${f1(cy - Rr)}" width="${f1(2 * Rr)}" height="${f1(2 * Rr)}" fill="url(#k84s)"/></g>`
              + `<circle cx="${f1(cx)}" cy="${f1(cy)}" r="${f1(Rr)}" fill="none" stroke="#f6ead0" stroke-width="${f1(0.28 * k)}" opacity="0.75"/><path d="M${f1(cx - Rr * 0.72)} ${f1(cy + Rr * 0.6)}Q${f1(cx)} ${f1(cy + Rr * 1.06)} ${f1(cx + Rr * 0.72)} ${f1(cy + Rr * 0.6)}" stroke="#ffd890" stroke-width="${f1(0.35 * k)}" fill="none" opacity="0.7"/>`
              + `<ellipse cx="${f1(cx - Rr * 0.38)}" cy="${f1(cy - Rr * 0.44)}" rx="${f1(Rr * 0.3)}" ry="${f1(Rr * 0.15)}" transform="rotate(-38 ${f1(cx - Rr * 0.38)} ${f1(cy - Rr * 0.44)})" fill="#ffffff" opacity="0.7"/><circle cx="${f1(cx + Rr * 0.42)}" cy="${f1(cy - Rr * 0.2)}" r="${f1(Rr * 0.06)}" fill="#ffffff" opacity="0.8"/>`
              + `<path d="M${f1(cx - Rr * 0.26)} ${f1(cy - Rr * 0.9)}h${f1(Rr * 0.52)}v${f1(-Rr * 0.24)}q0 ${f1(-Rr * 0.12)} ${f1(-Rr * 0.1)} ${f1(-Rr * 0.12)}h${f1(-Rr * 0.32)}q${f1(-Rr * 0.1)} 0 ${f1(-Rr * 0.1)} ${f1(Rr * 0.12)}Z" fill="url(#k84b)"/>`;
            return `<g>${at('translate', '0 0;0 ' + f1(-1.5 * k) + ';0 0', du, -ph, SPL(2))}${body}</g>`; };
          const SP = [['#c8401e', 'th'], ['#b8321e', 'pw'], ['#e0a020', 'pw'], ['#d86a7a', 'bd'], ['#8aa060', 'pd'], ['#2e2826', 'bd'], ['#f2efe8', 'cr'], ['#7a2a30', 'pw']];
          [14, 34].forEach((SY, row) => { const XS = [0, 1, 2, 3].map(i => 17.5 + i * 11), PH2 = XS.map((x, i) => [(row * 4 + i) * 0.9, 5.2 + ((row * 4 + i) % 3) * 0.6]);
            let top = '<rect width="44" height="9" fill="url(#k84w)"/>' + rep(8, j => `<path d="M0 ${f1(0.6 + j * 1.1)}q14 0.3 22 -0.1t22 0.2" stroke="#2a160c" stroke-width="0.12" fill="none" opacity="0.5"/>`).join('');
            XS.forEach((x, i) => top += `<ellipse cx="${f1(x - 12)}" cy="4.5" rx="3.2" ry="2.4" fill="url(#k84o)">${an('opacity', '0.95;0.55;0.95', PH2[i][1], -PH2[i][0], SPL(2))}</ellipse>`);
            s += shW(C, 12, SY + 1.8, 44, 2.6, 0.6, 0.3) + box3(C, { c: [34, SY, 4.5], w: 44, h: 1.8, d: 9, col: '#4a2c1a', r: 0.3, dec: { f: `<rect width="44" height="1.8" fill="url(#k84w)"/><rect width="44" height="0.4" fill="${CH}"/><rect y="1.5" width="44" height="0.3" fill="#2a160c" opacity="0.6"/>`, t: top } });
            XS.forEach((x, i) => s += orb([x, SY + 7.9, 4.5], 3.6, SP[row * 4 + i], PH2[i][0], PH2[i][1])); });
          return { defs: DEF19 + `<defs><linearGradient id="k84g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2e251b"/><stop offset="1" stop-color="#120e0a"/></linearGradient><linearGradient id="k84b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0c8"/><stop offset="0.5" stop-color="#d8b878"/><stop offset="1" stop-color="#9a7a40"/></linearGradient><linearGradient id="k84w" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#5a3420"/><stop offset="1" stop-color="#3e2214"/></linearGradient><radialGradient id="k84o"><stop offset="0" stop-color="#ffd88a" stop-opacity="0.85"/><stop offset="1" stop-color="#ffd88a" stop-opacity="0"/></radialGradient><radialGradient id="k84s" cx="40%" cy="35%" r="70%"><stop offset="0.3" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#2a1a0a" stop-opacity="0.5"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
        return D; };

      // KIT-101 painted wooden sign (custom text, default 'Kitchen'): cream-painted pine board chipped to bare wood at the edges, brush streaks, sage border,
      // barn-red dry-brushed letters, painted crossed spoon + fork and a heart, brass screw eyes, red gingham ribbon tied in a bow on a nail; sways a little
      N.ksign27 = S => { const t = (S.txt || (S.row && S.row.txt0) || 'Kitchen').slice(0, 26), W = Math.max(54, Math.min(150, 30 + t.length * 6.2)), Hh = 18, Y0 = 20, YT = Y0 + Hh, NY = YT + 10, DP = 3, ex = W / 2 - 7;
        const D = { w: W + 10, d: 6, mount: 'wall', elev: 48, build: () => [] };
        D.fx = ctx => { const C = camW(ctx), R = rng('ks' + t), id = C.u('ks'), k = C.k;
          ext(C, [[-W / 2 - 2, NY + 3, 0], [W / 2 + 2, Y0 - 3, 0], [W / 2, Y0, 6]]);
          let f = `<rect width="${f1(W)}" height="${Hh}" fill="url(#k101p)"/>` + rep(18, () => `<path d="M${f1(R() * (W - 16))} ${f1(0.6 + R() * (Hh - 1.2))}h${f1(4 + R() * 12)}" stroke="${R() < 0.5 ? '#ffffff' : '#d4c8aa'}" stroke-width="0.3" opacity="0.35"/>`).join('');
          f += rep(9, () => { const e = R(), x = e < 0.5 ? 1 + R() * (W - 2) : (e < 0.75 ? 0.8 : W - 0.8), y = e < 0.25 ? 0.8 : e < 0.5 ? Hh - 0.8 : 2 + R() * (Hh - 4), rr = 0.6 + R() * 1.1;
            const P = rep(6, j => { const a = j / 6 * 2 * PI, q = rr * (0.6 + R() * 0.6); return f1(x + Math.cos(a) * q * 1.4) + ' ' + f1(y + Math.sin(a) * q); });
            return `<path d="M${P.join('L')}Z" fill="#c8965a" stroke="#9a6a3a" stroke-width="0.15"/>`; }).join('');
          f += `<rect x="1.8" y="1.8" width="${f1(W - 3.6)}" height="${Hh - 3.6}" rx="1" fill="none" stroke="#8aa08a" stroke-width="0.55"/>`;
          f += `<defs><mask id="${id}m"><rect width="${f1(W)}" height="${Hh}" fill="#ffffff"/>${rep(70, () => `<rect x="${f1(R() * W)}" y="${f1(R() * Hh)}" width="${f1(0.6 + R() * 1.4)}" height="0.22" fill="#000000" opacity="0.8"/>`).join('')}</mask></defs>`
            + `<g mask="url(#${id}m)"><text x="${f1(W / 2)}" y="${f1(Hh / 2 + 3.2)}" text-anchor="middle" font-family="${SERIF}" font-weight="700" font-size="9" letter-spacing="0.4" textLength="${f1(W - 26)}" lengthAdjust="spacingAndGlyphs" fill="#9a3324">${xe(t)}</text></g>`;
          f += `<g transform="translate(6.6 ${Hh / 2})" fill="#7a5a3a"><g transform="rotate(30)"><ellipse cy="-3.6" rx="1.2" ry="1.8"/><rect x="-0.3" y="-2" width="0.6" height="6" rx="0.3"/></g><g transform="rotate(-30)"><path d="M-1.1 -5.4V-3.4Q-1.1 -2.4 -0.3 -2.2V3.8H0.3V-2.2Q1.1 -2.4 1.1 -3.4V-5.4H0.7V-3.6H0.2V-5.4H-0.2V-3.6H-0.7V-5.4Z"/></g></g>`
            + `<path d="M0 1C-1.6 -0.4 -1 -1.8 0 -1C1 -1.8 1.6 -0.4 0 1Z" transform="translate(${f1(W - 6.6)} ${Hh / 2}) scale(1.4)" fill="#b84a3a"/>`;
          let g = shW(C, -W / 2, YT, W, Hh, 2, 0.36);
          g += box3(C, { c: [0, Y0, DP / 2], w: W, h: Hh, d: DP, col: '#efe5cc', r: 1, dec: { f, t: rep(5, () => `<rect x="${f1(R() * (W - 6))}" y="0.4" width="${f1(1.5 + R() * 4)}" height="${f1(DP - 0.8)}" rx="0.4" fill="#c8965a"/>`).join('') } });
          [-ex, ex].forEach(x => g += WD(C, x, YT + 0.9, 1.5, '<circle r="0.7" fill="none" stroke="#c99a3e" stroke-width="0.32"/>'));
          const rb = [[-ex, YT + 0.9, 2.2], [0, NY - 0.6, 2.2], [ex, YT + 0.9, 2.2]];
          g += line3(C, rb, 1.3, '#c8302a') + line3(C, rb, 0.55, '#ffffff', `stroke-dasharray="${f1(0.7 * k)} ${f1(0.7 * k)}" opacity="0.85"`);
          g += WD(C, 0, NY + 0.6, 2.6, '<path d="M0 1.6C-3 -0.6 -4.4 2.4 -3.6 3.4C-2.6 4.4 -1 3 0 1.8ZM0 1.6C3 -0.6 4.4 2.4 3.6 3.4C2.6 4.4 1 3 0 1.8Z" fill="#c8302a" stroke="#8a1e1a" stroke-width="0.15"/><path d="M-2.4 1.6L-2 3.2M-1.2 1.2L-1 2.8M2.4 1.6L2 3.2M1.2 1.2L1 2.8" stroke="#ffffff" stroke-width="0.35" opacity="0.8"/><path d="M-0.4 2.2L-2.2 6.4L-1.2 6M0.4 2.2L1.8 6.6L2.6 5.8" stroke="#c8302a" stroke-width="1" fill="none" stroke-linejoin="round"/><circle cy="1.8" r="0.9" fill="#a8241e"/>');
          let s = swayAt(C, [0, NY, 1.6], 0.9, 5.6, 0, g) + cyl3(C, [0, NY, 0], [0, NY, 3], 0.4, '#7d838b', { n: 8 }) + sp3(C, [0, NY, 3.1], 0.9, '#8a8f96');
          return { defs: DEF19 + '<defs><linearGradient id="k101p" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f8f0da"/><stop offset="1" stop-color="#e4d8ba"/></linearGradient></defs>', front: s, bb: C.bb(4) }; };
        return D; };
    }
  }

  RD.SET27 = {
    'KIT-004': { spec: 'menus27', live: 'Fluttering coupon', note: 'Takeout menus tacked straight onto the wall with plastic push pins: Tony\'s Pizza (with a grease spot), the Golden Wok, a taped-up Taco Loco flyer whose half-torn coupon flutters, a Burger Barn coupon and a "pizza Fri!" sticky note. Below, a cheap white plastic paper-towel holder, one arm cracked and patched with duct tape; the hanging sheet sways.' },
    'KIT-024': { spec: 'knife27', live: 'Swaying board', note: 'A pine-framed chalkboard hung on jute twine from a nail, swaying a little: "Today\'s Menu" in chalk with pastel hearts, a cupcake and a steaming mug, old eraser smudges, chalk and a felt eraser on its ledge. Beside it an acacia magnetic strip holds a chef\'s knife, bread knife, santoku, a red paring knife, kitchen shears and a honing steel.' },
    'KIT-044': { spec: 'copper27', live: 'Swaying pans', note: 'A black wrought-iron rail on scrolled brackets with polished brass finials. Hammered French copper hangs from S-hooks on long iron handles: a wide skillet, three graded saucepans and a little butter warmer, plus a copper ladle and a brass whisk. Each piece sways gently, its hammered bottom catching the light.' },
    'KIT-064': { spec: 'winemap27', live: 'Picture lights', note: 'Two antique wine maps of Bordeaux and Burgundy on aged parchment, in walnut frames with a gilt fillet and linen mats, each lit by a polished brass picture light whose warm glow softly breathes. Below, a brass gallery rail holds olive-wood and brass utensils: ladle, skimmer, slotted spoon, whisk, fish slice, carving fork and pastry brush.' },
    'KIT-084': { spec: 'smart27', live: 'Floating orbs', note: 'A frameless smoked-glass recipe wall in a champagne-brass bezel, glowing warm. It pages through Saffron Risotto, Lemon Meringue Tart and Coq au Vin with the current step lit, a timer ring and the ingredients. Beside it, two floating walnut shelves of glass spice orbs (saffron, paprika, turmeric, pink pepper, cardamom, black pepper, fleur de sel, sumac) bob over soft pools of light.' },
    'KIT-101': { spec: 'ksign27', live: 'Swaying sign', note: 'A hand-painted pine board in soft cream, chipped to bare wood at the edges, with your word painted in barn red inside a sage border, a crossed spoon and fork and a little heart. It hangs on a red gingham ribbon tied in a bow on a nail and sways a little. Tap to change the writing.' },
    'KIT-001': { s12: 'k01dry', live: 'Dripping grease', note: 'Builder-beige drywall behind the stove: taped and mudded joints, screw pops, an unpainted spackle patch, a yellow haze from years of frying and amber grease splatter with runs (one drip slowly forms and falls), a scorch mark and a greasy outlet. The vinyl base is peeling.' },
    'KIT-021': { s12: 'k21vin', live: 'Peeling corner', note: 'Peel-and-stick vinyl "subway tile" sheets over mint paint. The grout lines are printed flat and every tile has the same printed shine. The sheet seams do not quite line up, there are air bubbles, a rough cut round the outlet and one corner peeling off its sticky back. Cherry-red vinyl base.' },
    'KIT-041': { s12: 'k41herr', live: 'Glinting glaze', note: 'Glossy white subway tile laid in a true 45 degree herringbone, every tile a slightly different white with a glazed bevel, under eggshell sage walls, finished with a bullnose cap. A soft glint slides over the glaze.' },
    'KIT-061': { s12: 'k61cop', note: 'Hand-hammered copper sheets with hundreds of little dents catching the light in rose, gold and brown, joined by standing seams with domed copper rivets and a polished half-round cap, under soft troweled Venetian lime plaster.' },
    'KIT-081': { s12: 'k81qtz', live: 'Recipe display', note: 'Floor-to-ceiling book-matched Patagonia quartzite lit from behind: milky quartz with clusters of black, smoky and caramel crystals, mirrored at a brass seam. A frameless smoked-glass display set into the stone pages through recipes with a timer ring. Bronze plinth with a champagne light line.' },
    'KIT-012': { w19: 'khop', live: 'Passing pigeon', note: 'A tiny hopper window high up in a deep concrete well, the steel frame chipped and rusting down the wall. The sash tilts in on two arms, the insect screen is rusty and torn at a corner, and through the grimy glass you see the grass at ground level: a dandelion clock sways, a pigeon struts past, a snail creeps along.' },
    'KIT-032': { w19: 'kging', live: 'Swaying curtains', note: 'A white double-hung window with red gingham cafe curtains on a brass tension rod and a gathered valance. Outside, laundry sways on the line and a little bird visits the swinging feeder. A geranium sits on the sill and a glass suncatcher throws rainbow spots.' },
    'KIT-052': { w19: 'kgreen', live: 'Swaying herbs', note: 'A glass greenhouse box pushed out past the wall, with a glass shelf and a zinc pebble tray full of terracotta pots: basil, rosemary, chives, thyme, mint and parsley all swaying in the sun. Sunbeams fall through the panes, a butterfly flits in the garden and a brass watering can waits on the stone sill.' },
    'KIT-072': { w19: 'kaccord', live: 'Folding panels', note: 'Six thin black-steel glass panels that fold open like an accordion and close again, turning the window into a pass-through bar. The walnut bar top runs out onto the patio ledge, with cocktail coupes and a brass bowl of lemons; outside, string lights twinkle over a golden-hour terrace.' },
    'KIT-092': { w19: 'khydro', live: 'Living farm', note: 'Frameless floor-to-ceiling glass on a golden-hour valley, lined with polished brass gutters on fine hangers: butterhead lettuce, basil, kale, herbs and strawberries that slowly ripen. Warm grow-light bars glow down, water trickles gutter to gutter, mist puffs now and then, over a bronze planter base with a champagne light line.' },
    'KIT-014': { spec: 'pine27', live: 'Swaying towel', note: 'A knotty pine plank on bent, rusty iron brackets that have left drip stains on the wall. On it: a mason jar of wooden spoons, a chipped "#1 COOK" mug, a dented can of beans, a blue salt tub, Grandma\'s recipe book and a pothos trailing down. A plaid tea towel sways on a cup hook and a tiny spider bobs on its thread.' },
    'KIT-034': { spec: 'lam27', live: 'Swaying mugs', note: 'Cheap white laminate wall cabinets with yellowed edge banding (one strip peeling), chrome bar pulls and a left door that sags a little. The right door is left ajar on cans, peanut butter and cereal. A dusty basket and cookie tin sit on top, a strip light flickers underneath and three mugs sway on hooks.' },
    'KIT-054': { spec: 'china27', live: 'Glowing cabinet', note: 'A creamy painted shaker hutch with brass knobs and cup pulls under a honed marble counter with a lemon cake on a stand. Above, two glass doors with mullions show a warm-lit interior: blue-and-white plates on a brass plate rail, teacups on saucers, bowl stacks, a tureen and a pitcher.' },
    'KIT-074': { spec: 'butler27', live: 'Turning carousels', note: 'A butler\'s pantry in deep green lacquer with brass bin pulls and little labelled spice drawers under a Calacatta marble counter. Open walnut shelves lit by warm strips hold glass canisters, copper pots and cookbooks, copper ladles hang from a brass rail, and two brass spice carousels slowly turn on the counter.' },
    'KIT-094': { name: 'Patisserie Pantry', spec: 'patis27', live: 'Turning cake stand', note: 'A cream lacquer and polished brass patisserie cabinet on a bronze plinth with a champagne light line, under a blush-and-cream scalloped awning. In the middle an arched glass vitrine glows pink, and a three-tier brass cake stand slowly turns: cupcakes, macaron towers and little cakes, with a strawberry cake on top. On each side a glass candy cabinet of apothecary jars (gumballs, lollipops, jelly beans, peppermints, cookies, marshmallows) twinkles over labelled drawers.' },
    'KIT-005': { f27: 'ylino', note: 'Old mustard-yellow vinyl squares with a marbled swirl, laid quarter-turned. Grime in the seams, cracked tiles, four corners curling up off the black glue, one tile missing (combed tar and stuck bits), grease spots in front of the stove and a scorched pot ring.' },
    'KIT-025': { f27: 'diner', note: 'Glossy black and white vinyl checkerboard like a 50s diner, each tile flecked with little chips, framed by a cherry-red border and a polished chrome strip. Waxed to a shine, with a few heel scuffs.' },
    'KIT-045': { f27: 'quarry', note: 'Hand-made terracotta quarry tiles in fired orange to brick-brown, with wavy edges, darker kiln flashing, pits and chalky bloom, set in warm sandy grout. A cat walked over three of them before they were fired.' },
    'KIT-065': { f27: 'oak', note: 'Wide smoky French oak planks of random lengths: wire-brushed grain, cracked knots, hand-scraped ripples, old dents and wormholes, square oak pegs at the board ends and dark open joints, finished with a low oiled sheen.' },
    'KIT-085': { f27: 'cush', live: 'Self-sweeping', note: 'Large book-matched cream Calacatta slabs with soft pillowed edges that spring back underfoot, their grey and gold veins flowing from slab to slab. Polished brass seams glow warm from the heating, brass keystones glint at the corners, and gold dust drifts into a bronze-and-brass vacuum plinth under a champagne light.' },
    'KIT-009': { c27: 'acou', live: 'Rattling fan', note: 'An old drop ceiling of fissured acoustic tiles in a yellowed metal grid. Brown leak rings, one soggy tile sagging out of the grid, one tile missing with a wire loop hanging out, and over the stove a grease-caked exhaust fan that spins, rattles and drips.' },
    'KIT-029': { c27: 'bead', live: 'Steam curls', note: 'A cosy painted beadboard ceiling in soft buttercream: tongue-and-groove boards with rounded beads, nail heads and brush marks, a bundle of drying herbs on a brass hook, and steam from the under-cabinet hood curling along the boards.' },
    'KIT-049': { c27: 'pots', note: 'A smooth matte white ceiling with eight recessed pot lights glowing warm in their grooved trims, a flush speaker grille, a slim slot vent by the stainless chimney hood and a crisp shadow-gap edge.' },
    'KIT-069': { c27: 'tray', live: 'Glowing cove', note: 'Hand-troweled Venetian lime plaster with soft burnished sweeps. Above the island a recessed tray lined with hand-laid gold leaf glows from a hidden warm cove, edged in polished brass, under a deep plaster crown that goes with the brass canopy hood.' },
    'KIT-017': { spec: 'fluor27', s3: null, live: 'Flickering tube', note: 'A bare fluorescent strip hung on two chains: a grubby enamel channel with two tubes, one burnt black at the end with a couple of dead bugs inside. The old tube stutters now and then and the pull-chain sways.' },
    'KIT-037': { spec: 'barn27', s3: null, live: 'Swaying shade', note: 'A farmhouse barn pendant in glossy green porcelain enamel with a wide rolled white rim, chipped to black steel in a few spots, on a braided cloth cord. It sways gently with the bulb peeking under the rim.' },
    'KIT-057': { spec: 'globe27', s3: null, live: 'Glowing filaments', note: 'Three ribbed clear glass globes on a slim brass canopy bar. Through the fine ribs you see an amber Edison bulb in each, its looped filament glowing, and every globe sways on its own cord.' },
    'KIT-077': { spec: 'alab27', s3: null, live: 'Glowing alabaster', note: 'A long hand-forged brass bar with scrolled ends, hammer marks catching the light, holding five veined alabaster drums in brass cups. Each stone glows warm from inside and a glint slides along the brass.' },
    'KIT-097': { spec: 'herb27', s3: null, live: 'Living herbs', note: 'A polished brass halo on four fine cables, planted all round with living basil, purple basil, rosemary and thyme. Trailing thyme hangs over the edge, a warm grow-light glows under the ring and dew twinkles on the leaves.' },
    'KIT-089': { c27: 'onyx', live: 'Whisper vortex', note: 'Book-matched slabs of honey onyx lit from behind so the whole ceiling glows warm, joined by polished brass seams. In the middle a brass-rimmed vortex slowly turns its brass vanes, drawing in drifting gold motes without a sound.' },
  };
  const edit26 = RD.edit;
  RD.edit = rows => edit26(rows).map(r => RD.SET27[r.id] ? Object.assign({}, r, RD.SET27[r.id]) : r);
  RD.H27 = { FLOOR27, CEIL27, rrW, quadW, dot, dotD, walk, cE, cHi, cDoc, cShade };
  RD.PLUS27 = 1;
})();
