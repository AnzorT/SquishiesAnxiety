/* Squish Squad food catalogue. style = how it is eaten; fx = extra particles. art is drawn around 0,0 (about ±9 units). */
(function () {
  const L = [
    { k: 'carrot', name: 'Carrot', price: 8, fill: 15, sec: 9, style: 'nibble', fx: 'crumbs', crumb: '#ff9a3c',
      art: '<path d="M-4.4 -4 Q0 -5.4 4.4 -4 L0.8 9 Q0 10 -0.8 9Z" fill="#ff9a3c"/><path d="M-2.6 -1 h3.4 M-1.6 2.5 h2.6 M-1 5.5 h1.6" stroke="#e07a1c" stroke-width="0.7" stroke-linecap="round"/><path d="M0 -4 L-3 -9 M0 -4 L0 -10 M0 -4 L3 -9" stroke="#6cc06a" stroke-width="1.6" stroke-linecap="round"/>' },
    { k: 'chocolate', name: 'Chocolate', price: 14, fill: 18, sec: 12, style: 'savor', fx: 'hearts',
      art: '<rect x="-6" y="-8" width="12" height="16" rx="1.6" fill="#7a4428"/><path d="M-6 -3.4 H6 M0 -8 V1" stroke="#5a2e18" stroke-width="0.8"/><path d="M-6 1 H6 V6.4 Q6 8 4.4 8 H-4.4 Q-6 8 -6 6.4Z" fill="#ff5c8a"/><rect x="-6" y="1" width="12" height="1.2" fill="#fff" opacity=".6"/>' },
    { k: 'burger', name: 'Burger', price: 40, fill: 45, sec: 16, style: 'chomp', fx: 'crumbs', crumb: '#e8963c',
      art: '<path d="M-8 -1 Q-8 -8 0 -8 Q8 -8 8 -1Z" fill="#f0a64a"/><circle cx="-3" cy="-5" r="0.6" fill="#fff6d0"/><circle cx="1" cy="-6" r="0.6" fill="#fff6d0"/><circle cx="4" cy="-4" r="0.6" fill="#fff6d0"/><rect x="-8" y="0.4" width="16" height="2.6" rx="1.2" fill="#ffd23a"/><path d="M-8.9 -1.3 H8.9 V0 L7.6 2 L6 0.2 L4.4 2.2 L2.8 0.2 L1.2 2.2 L-0.4 0.2 L-2 2.2 L-3.6 0.2 L-5.2 2.2 L-6.8 0.2 L-8.4 2 L-8.9 0Z" fill="#7fd06f" stroke="#5fb85a" stroke-width="0.3" stroke-linejoin="round"/><rect x="-8" y="2.6" width="16" height="2.8" rx="1.4" fill="#8a4a2a"/><path d="M-8 5.2 H8 Q8 8 4 8 H-4 Q-8 8 -8 5.2Z" fill="#e8963c"/>' },
    { k: 'pizza', name: 'Pizza slice', price: 30, fill: 35, sec: 14, style: 'chomp', fx: 'crumbs', crumb: '#ffd36a',
      art: '<path d="M-8 -7 Q0 -10 8 -7 L0 9Z" fill="#ffd36a"/><path d="M-8 -7 Q0 -10 8 -7 L7.2 -5.4 Q0 -8.2 -7.2 -5.4Z" fill="#d9893c"/><circle cx="-2.5" cy="-3" r="1.6" fill="#e2483e"/><circle cx="2.6" cy="-2" r="1.5" fill="#e2483e"/><circle cx="0" cy="2.5" r="1.3" fill="#e2483e"/><path d="M-4 -1 q1 2 0 3" stroke="#ffe9a8" stroke-width="0.8" fill="none"/>' },
    { k: 'sushi', name: 'Sushi', price: 24, fill: 25, sec: 10, style: 'gulp', fx: 'none',
      art: '<ellipse cx="0" cy="2" rx="7.5" ry="4" fill="#fffaf0"/><path d="M-8 0.4 Q0 -7 8 0.4 Q0 -2.2 -8 0.4Z" fill="#ff8a5c"/><path d="M-5 -2 l2 1.4 M-1 -3 l2 1.4 M3 -2.6 l2 1.4" stroke="#ffd0b8" stroke-width="0.8"/><rect x="-1.6" y="-1.6" width="3.2" height="7.6" rx="0.6" fill="#2f3b36"/>' },
    { k: 'noodles', name: 'Noodles', price: 34, fill: 40, sec: 15, style: 'slurp', fx: 'steam',
      art: '<path d="M-9 -1 H9 Q8 8 0 8 Q-8 8 -9 -1Z" fill="#ff6f6f"/><path d="M-7 -1 Q-5 -4 -3 -1 Q-1 -4 1 -1 Q3 -4 5 -1 Q6.5 -3 7 -1" stroke="#ffe08a" stroke-width="1.6" fill="none"/><path d="M-9 -1 H9" stroke="#fff" stroke-width="1"/><path d="M3 -9 L-2 -1 M6 -8 L0 -1" stroke="#a8693a" stroke-width="1" stroke-linecap="round"/><path d="M-6 3 h12" stroke="#fff" stroke-width="0.8" opacity=".6"/>' },
    { k: 'fish', name: 'Fish', price: 26, fill: 30, sec: 12, style: 'gulp', fx: 'none',
      art: '<path d="M-8 0 Q-3 -6 4 0 Q-3 6 -8 0Z" fill="#9fc6e8"/><path d="M4 0 L9 -4.5 L9 4.5Z" fill="#7fb0dc"/><circle cx="-5" cy="-1" r="0.9" fill="#2a1a30"/><path d="M-2 -2.6 q1 2.6 0 5.2 M1 -2 q0.8 2 0 4" stroke="#7fb0dc" stroke-width="0.8" fill="none"/>' },
    { k: 'pineapple', name: 'Pineapple', price: 18, fill: 22, sec: 11, style: 'savor', fx: 'juice',
      art: '<circle r="7.5" fill="#ffd23a"/><circle r="7.5" fill="none" stroke="#e8a63a" stroke-width="1.4"/><circle r="2.4" fill="#fff2b0"/><path d="M0 -2.4 V-6.6 M0 2.4 V6.6 M-2.4 0 H-6.6 M2.4 0 H6.6 M-1.7 -1.7 L-4.7 -4.7 M1.7 1.7 L4.7 4.7 M1.7 -1.7 L4.7 -4.7 M-1.7 1.7 L-4.7 4.7" stroke="#ffe680" stroke-width="0.7"/>' },
    { k: 'donut', name: 'Donut', price: 16, fill: 20, sec: 10, style: 'chomp', fx: 'crumbs', crumb: '#ff8fc8',
      art: '<path fill-rule="evenodd" d="M-8 0a8 8 0 1 0 16 0a8 8 0 1 0 -16 0Z M-2.6 0a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0Z" fill="#e8a65a"/><path fill-rule="evenodd" d="M-7 -0.6a7 6.6 0 1 0 14 0a7 6.6 0 1 0 -14 0Z M-3.2 0a3.2 3.2 0 1 0 6.4 0a3.2 3.2 0 1 0 -6.4 0Z" fill="#ff8fc8"/><rect x="-5" y="-3.6" width="2.2" height="0.9" rx="0.4" fill="#fff" transform="rotate(30 -4 -3)"/><rect x="2" y="-5" width="2.2" height="0.9" rx="0.4" fill="#7cc8ff"/><rect x="3.4" y="2" width="2.2" height="0.9" rx="0.4" fill="#ffd84a" transform="rotate(-30 4 2.4)"/><rect x="-5" y="3" width="2.2" height="0.9" rx="0.4" fill="#7be495"/>' },
    { k: 'cookie', name: 'Cookie', price: 10, fill: 12, sec: 8, style: 'nibble', fx: 'crumbs', crumb: '#e7a95c',
      art: '<circle r="7.5" fill="#e7a95c"/><circle cx="-3" cy="-2" r="1.3" fill="#5b3a29"/><circle cx="2.6" cy="-3.4" r="1.1" fill="#5b3a29"/><circle cx="1" cy="2.6" r="1.4" fill="#5b3a29"/><circle cx="-2.4" cy="3.4" r="0.9" fill="#5b3a29"/><circle cx="4.4" cy="1.4" r="0.9" fill="#5b3a29"/>' },
    { k: 'salad', name: 'Salad', price: 18, fill: 20, sec: 13, style: 'nibble', fx: 'none',
      art: '<circle cx="-5" cy="-1" r="3.4" fill="#7fd06f"/><circle cx="0" cy="-2.6" r="3.8" fill="#5fb85a"/><circle cx="5" cy="-1" r="3.2" fill="#8fdc7a"/><circle cx="-2" cy="-0.6" r="1.4" fill="#ff5c5c"/><circle cx="3" cy="-3" r="1.2" fill="#ff5c5c"/><path d="M-9 0 H9 Q8 8 0 8 Q-8 8 -9 0Z" fill="#9fd8f0"/><path d="M-9 0 H9" stroke="#fff" stroke-width="1"/>' },
    { k: 'marshmallow', name: 'Marshmallow', price: 6, fill: 10, sec: 7, style: 'gulp', fx: 'none',
      art: '<rect x="-6" y="-6" width="12" height="12" rx="4" fill="#fff6fb" stroke="#f0d6e2" stroke-width="0.7"/><rect x="-6" y="-6" width="12" height="4.4" rx="2.2" fill="#ffd6ea"/><ellipse cx="-2" cy="1.6" rx="1.6" ry="1" fill="#fff"/>' },
    { k: 'dumpling', name: 'Dumpling', price: 22, fill: 28, sec: 12, style: 'chomp', fx: 'steam',
      art: '<path d="M-8.5 3 Q-7.5 -7 0 -7 Q7.5 -7 8.5 3 Q0 6 -8.5 3Z" fill="#fff6e8" stroke="#ead8bf" stroke-width="0.7"/><path d="M-4 -5.5 Q-2.6 -3 -1.4 -6 Q0 -3 1.4 -6 Q2.6 -3 4 -5.5" stroke="#e2cfb6" stroke-width="0.8" fill="none"/>' },
  ];
  const BITES = { nibble: 8, chomp: 5, savor: 4, gulp: 3, slurp: 4 };
  const MAP = {};
  L.forEach(f => { f.bites = BITES[f.style]; f.img = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="-11 -11 22 22">' + f.art + '</svg>'); MAP[f.k] = f; });
  const KEY = 'squishPantry';
  const pantry = () => { try { const p = JSON.parse(localStorage.getItem(KEY) || 'null'); if (p) return p; } catch (e) {} return { carrot: 3, cookie: 2, marshmallow: 2 }; };
  const save = p => { try { localStorage.setItem(KEY, JSON.stringify(p)); } catch (e) {} };
  window.SquishFoods = { LIST: L, get: k => MAP[k] || null, pantry, save };
})();
