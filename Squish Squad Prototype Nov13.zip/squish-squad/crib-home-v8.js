/* v8: plush-skinned home + shabby starting rooms, buyable walls/floors/ceilings, worn tier-0 furniture, creature move unlocks. Squish Squad home system: upgradeable room slots (5 tiers), yard games, free decor, wall/floor/ceiling themes, save data, room layout. */
(function () {
  const O = '#8e1580';
  const S3 = ' stroke="' + O + '" stroke-width="3"', S2 = ' stroke="' + O + '" stroke-width="2"', S25 = ' stroke="' + O + '" stroke-width="2.5"';
  const UC = new Map(); const uri = (w, h, inner) => { const ck = w + 'x' + h + inner; if (UC.has(ck)) return UC.get(ck); const r = uri0(w, h, inner); UC.set(ck, r); return r; }; const uri0 = (w, h, inner) => { const PS = window.PlushSkin, s = PS && PS.svgStr(w, h, inner); return 'data:image/svg+xml,' + encodeURIComponent(s || ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + w + ' ' + h + '">' + inner + '</svg>')); };
  const LV = [1, 2, 4, 6, 8], CO = [0, 300, 800, 1600, 3000], US = [0, 0.99, 1.99, 2.99, 4.99];
  const ROOMS = [{ k: 'living', name: 'Living Room' }, { k: 'kitchen', name: 'Kitchen' }, { k: 'bath', name: 'Bathroom' }, { k: 'bed', name: 'Bedroom' }, { k: 'dance', name: 'Dance Room' }, { k: 'yard', name: 'Yard' }];

  /* ---------- art ---------- */
  const SOFA = [['#dcbcf7', '#b98ae6'], ['#ffa8e6', '#ff5cc6'], ['#9fd8f0', '#5fb6dc'], ['#c9b6f0', '#9b84d8'], ['#ffd66b', '#e8a63a']], SEATS = [2, 3, 4, 5, 6];
  function sofaArt(t) {
    const n = SEATS[t], W = 64 * n + 60, m = SOFA[t][0], d = SOFA[t][1];
    let b = '<rect x="4" y="2" width="' + (W - 8) + '" height="70" rx="30" fill="' + m + '"' + S3 + '/>';
    if (t >= 2) for (let k = 0; k < n; k++) b += '<circle cx="' + (62 + 64 * k) + '" cy="28" r="3" fill="' + d + '"/>';
    if (t === 4) b += '<path d="M' + (W / 2 - 16) + ' 14 l6 -10 l10 8 l10 -8 l6 10z" fill="#fff3b0"' + S2 + '/>';
    b += '<rect x="22" y="18" width="48" height="40" rx="12" fill="#ffd66b"' + S25 + ' transform="rotate(-8 46 38)"/><rect x="' + (W - 70) + '" y="18" width="48" height="40" rx="12" fill="' + (t === 4 ? '#c9b6f0' : '#a8d98a') + '"' + S25 + ' transform="rotate(8 ' + (W - 46) + ' 38)"/>';
    b += '<rect x="0" y="54" width="' + W + '" height="36" rx="14" fill="' + d + '"' + S3 + '/>';
    for (let k = 1; k < n; k++) b += '<path d="M' + (30 + 64 * k) + ' 58 V86" stroke="rgba(80,12,140,0.45)" stroke-width="2"/>';
    let f = '<rect x="2" y="2" width="44" height="74" rx="20" fill="' + m + '"' + S3 + '/><rect x="' + (W - 2) + '" y="2" width="44" height="74" rx="20" fill="' + m + '"' + S3 + '/>';
    f += '<path d="M26 48 H' + (W + 18) + ' V64 Q' + (W + 18) + ' 74 ' + (W + 8) + ' 74 H36 Q26 74 26 64Z" fill="' + d + '"' + S3 + '/>';
    f += '<rect x="40" y="72" width="12" height="9" fill="#7a2a9e"' + S2 + '/><rect x="' + (W - 8) + '" y="72" width="12" height="9" fill="#7a2a9e"' + S2 + '/>';
    const x = 820 - W;
    return { back: { img: uri(W, 92, b), x, y: 146, w: W, h: 92 }, front: { img: uri(W + 44, 82, f), x: x - 22, y: 180, w: W + 44, h: 82 }, seats: Array.from({ length: n }, (_, k) => ({ x: x + 62 + 64 * k, y: 238 })) };
  }
  function tvBack(t) {
    let s = '<rect x="18" y="112" width="164" height="62" rx="6" fill="#f09ad8"' + S3 + '/><rect x="20" y="114" width="160" height="10" fill="#f9c4ec"/><path d="M30 140 H170 M30 154 H170" stroke="rgba(80,12,140,0.35)" stroke-width="3"/><rect x="32" y="168" width="10" height="11" fill="#7a2a9e"' + S2 + '/><rect x="158" y="168" width="10" height="11" fill="#7a2a9e"' + S2 + '/>';
    const vents = (x, y, w, n) => Array.from({ length: n }, (_, k) => '<rect x="' + (x + k * (w / n)) + '" y="' + y + '" width="' + (w / n - 4) + '" height="4" rx="2" fill="rgba(0,0,0,0.35)"/>').join('');
    const cable = (x, y) => '<path d="M' + x + ' ' + y + ' q-6 20 10 30 q14 8 6 20" stroke="#2a2a33" stroke-width="3" fill="none" stroke-linecap="round"/>';
    if (t === 0) s += '<path d="M88 62 L70 8 M112 62 L130 10" stroke="' + O + '" stroke-width="3"/><path d="M44 66 H156 V96 Q156 116 134 116 H66 Q44 116 44 96Z" fill="#c06ad8"' + S3 + '/><path d="M64 52 H136 L150 66 H50Z" fill="#a64dc4"' + S3 + '/>' + vents(70, 80, 60, 5) + vents(70, 92, 60, 5) + cable(120, 104);
    if (t === 1) s += '<rect x="40" y="38" width="120" height="72" rx="6" fill="#3a3a44"' + S3 + '/><rect x="72" y="56" width="56" height="36" rx="4" fill="#2a2a33"/>' + vents(80, 62, 40, 4) + vents(80, 74, 40, 4) + cable(110, 92) + '<rect x="90" y="108" width="20" height="5" fill="#2a2a33"/>';
    if (t === 2) s += '<rect x="20" y="16" width="160" height="96" rx="6" fill="#3a3a44"' + S3 + '/><rect x="66" y="40" width="68" height="48" rx="5" fill="#2a2a33"/>' + vents(74, 50, 52, 5) + vents(74, 62, 52, 5) + vents(74, 74, 52, 5) + cable(116, 88);
    if (t === 3) s += '<path d="M8 22 Q100 36 192 22 V108 Q100 122 8 108Z" fill="#33333d"' + S3 + '/><rect x="66" y="48" width="68" height="44" rx="5" fill="#26262e"/>' + vents(74, 58, 52, 5) + vents(74, 70, 52, 5) + cable(116, 92);
    if (t === 4) s += '<rect x="0" y="36" width="18" height="78" rx="5" fill="#3a2a40"' + S25 + '/><rect x="182" y="36" width="18" height="78" rx="5" fill="#3a2a40"' + S25 + '/><rect x="24" y="6" width="152" height="92" rx="6" fill="#33333d"' + S3 + '/><rect x="70" y="30" width="60" height="44" rx="5" fill="#26262e"/>' + vents(78, 40, 44, 4) + vents(78, 52, 44, 4) + vents(78, 64, 44, 4) + '<rect x="44" y="100" width="112" height="11" rx="5" fill="#3a2a40"' + S2 + '/>' + cable(116, 76);
    return { img: uri(200, 180, s), x: 531, y: 206, w: 200, h: 180 };
  }
  function tvArt(t) {
    let s = '<rect x="18" y="112" width="164" height="62" rx="6" fill="#f09ad8"' + S3 + '/><rect x="20" y="114" width="160" height="10" fill="#f9c4ec"/><path d="M30 140 H170 M30 154 H170" stroke="rgba(80,12,140,0.35)" stroke-width="3"/><rect x="32" y="168" width="10" height="11" fill="#7a2a9e"' + S2 + '/><rect x="158" y="168" width="10" height="11" fill="#7a2a9e"' + S2 + '/>';
    const gloss = (x, y, w, h) => '<path d="M' + x + ' ' + (y + h) + ' L' + (x + w * 0.35) + ' ' + y + ' H' + (x + w * 0.5) + ' L' + (x + w * 0.15) + ' ' + (y + h) + 'Z" fill="#fff" opacity=".13"/>';
    if (t === 0) s += '<path d="M88 62 L70 8 M112 62 L130 10" stroke="' + O + '" stroke-width="3"/><rect x="36" y="48" width="128" height="18" rx="8" fill="#5a0f6e"' + S3 + '/><path d="M50 60 H150 V96 Q150 116 128 116 H72 Q50 116 50 96Z" fill="#e389d4"' + S3 + '/><rect x="60" y="68" width="80" height="40" rx="8" fill="#4a6a7a"' + S2 + '/>' + gloss(60, 68, 80, 40);
    if (t === 1) s += '<rect x="40" y="36" width="120" height="76" rx="6" fill="#2a2a33"' + S3 + '/><rect x="46" y="42" width="108" height="62" rx="3" fill="#4a6a8a"/>' + gloss(46, 42, 108, 62) + '<rect x="90" y="110" width="20" height="4" fill="#2a2a33"/>';
    if (t === 2) s += '<rect x="20" y="14" width="160" height="98" rx="6" fill="#2a2a33"' + S3 + '/><rect x="26" y="20" width="148" height="84" rx="3" fill="#4f7aa8"/>' + gloss(26, 20, 148, 84) + '<circle cx="100" cy="108" r="1.6" fill="#7cf"/>';
    if (t === 3) s += '<path d="M8 18 Q100 2 192 18 V108 Q100 94 8 108Z" fill="#22222b"' + S3 + '/><path d="M15 24 Q100 10 185 24 V100 Q100 87 15 100Z" fill="#5a6fc0"/>' + gloss(15, 18, 170, 80);
    if (t === 4) s += '<rect x="0" y="36" width="18" height="78" rx="5" fill="#3a2a40"' + S25 + '/><rect x="182" y="36" width="18" height="78" rx="5" fill="#3a2a40"' + S25 + '/><circle cx="9" cy="60" r="5" fill="#5a4a60"/><circle cx="191" cy="60" r="5" fill="#5a4a60"/><circle cx="9" cy="92" r="6" fill="#5a4a60"/><circle cx="191" cy="92" r="6" fill="#5a4a60"/><rect x="24" y="4" width="152" height="94" rx="6" fill="#22222b"' + S3 + '/><rect x="30" y="10" width="140" height="80" rx="3" fill="#6a5ad0"/>' + gloss(30, 10, 140, 80) + '<rect x="44" y="100" width="112" height="11" rx="5" fill="#3a2a40"' + S2 + '/>';
    return { img: uri(200, 180, s), x: 531, y: 206, w: 200, h: 180 };
  }
  const FR = [[70, 110], [84, 150], [110, 176], [120, 186], [134, 196]];
  function fridgeArt(t) {
    const [w, h] = FR[t]; let s = '';
    if (t === 0) s = '<rect x="2" y="2" width="' + (w - 4) + '" height="' + (h - 4) + '" rx="12" fill="#ffffff"' + S3 + '/><path d="M2 40 H' + (w - 2) + '" stroke="' + O + '" stroke-width="2.5"/><rect x="' + (w - 16) + '" y="14" width="5" height="18" rx="2" fill="#e389d4"/><rect x="' + (w - 16) + '" y="52" width="5" height="26" rx="2" fill="#e389d4"/>';
    if (t === 1) s = '<rect x="2" y="2" width="' + (w - 4) + '" height="' + (h - 4) + '" rx="24" fill="#bfe8d0"' + S3 + '/><path d="M2 52 H' + (w - 2) + '" stroke="' + O + '" stroke-width="2.5"/><rect x="' + (w - 18) + '" y="22" width="6" height="22" rx="3" fill="#e6eef2"' + S2 + '/><rect x="' + (w - 18) + '" y="64" width="6" height="36" rx="3" fill="#e6eef2"' + S2 + '/><rect x="10" y="10" width="8" height="34" rx="4" fill="#fff" opacity=".5"/>';
    if (t === 2) s = '<rect x="2" y="2" width="' + (w - 4) + '" height="' + (h - 4) + '" rx="12" fill="#e6f0f5"' + S3 + '/><path d="M' + w / 2 + ' 2 V' + (h - 2) + '" stroke="' + O + '" stroke-width="2.5"/><rect x="' + (w / 2 - 12) + '" y="40" width="6" height="40" rx="3" fill="#9fb4c0"' + S2 + '/><rect x="' + (w / 2 + 6) + '" y="40" width="6" height="40" rx="3" fill="#9fb4c0"' + S2 + '/><circle cx="22" cy="24" r="6" fill="#ffd66b"' + S2 + '/><rect x="' + (w - 30) + '" y="18" width="14" height="10" rx="2" fill="#ff9db0"' + S2 + '/>';
    if (t === 3) s = '<rect x="2" y="2" width="' + (w - 4) + '" height="' + (h - 4) + '" rx="10" fill="#c9d3dc"' + S3 + '/><path d="M' + w / 2 + ' 2 V' + (h - 2) + '" stroke="' + O + '" stroke-width="2.5"/><rect x="12" y="40" width="40" height="52" rx="5" fill="#3a5a8a"' + S2 + '/><circle cx="24" cy="56" r="5" fill="#ffd66b"/><rect x="32" y="52" width="12" height="8" rx="2" fill="#ff9db0"/><path d="M18 76 H46 M18 84 H40" stroke="#9fd8f0" stroke-width="2.5"/><rect x="' + (w / 2 + 6) + '" y="40" width="6" height="52" rx="3" fill="#8a9aa8"/>';
    if (t === 4) s = '<rect x="2" y="2" width="' + (w - 4) + '" height="' + (h - 4) + '" rx="10" fill="#d8e0e6"' + S3 + '/><rect x="12" y="14" width="' + (w / 2 - 18) + '" height="' + (h - 30) + '" rx="6" fill="#bfe6f5"' + S2 + '/>' + [40, 78, 116].map(y => '<path d="M14 ' + y + ' H' + (w / 2 - 8) + '" stroke="' + O + '" stroke-width="2"/>').join('') + '<rect x="18" y="26" width="14" height="12" rx="2" fill="#ff5cc6"/><circle cx="44" cy="32" r="6" fill="#ffd66b"/><rect x="20" y="62" width="10" height="14" rx="2" fill="#7fd06f"/><rect x="36" y="64" width="14" height="12" rx="2" fill="#ff9db0"/><circle cx="26" cy="104" r="6" fill="#ff9a3c"/><rect x="38" y="96" width="14" height="18" rx="3" fill="#9fd8f0"/><path d="M' + (w / 2 + 2) + ' 2 V' + (h - 2) + '" stroke="' + O + '" stroke-width="2.5"/><rect x="' + (w / 2 + 14) + '" y="30" width="34" height="40" rx="6" fill="#3a4a5a"' + S2 + '/><path d="M' + (w / 2 + 31) + ' 44 v14" stroke="#9fd8f0" stroke-width="3"/>';
    return { img: uri(w, h, s), x: 20, y: 238 - h, w, h };
  }
  const TUBW = [280, 340, 400, 440, 460], TUBCAP = [3, 4, 5, 6, 6], TUBSTYLE = ['tub', 'bubble', 'hottub', 'spa', 'duck'];
  function tubArt(t) {
    const W = TUBW[t], H = 112; let s = '';
    const basin = 'M10 42 H' + (W - 10) + ' V64 Q' + (W - 10) + ' 104 ' + (W - 60) + ' 104 H60 Q10 104 10 64Z';
    const foam = (r, n) => { let f = ''; for (let k = 0; k < n; k++) { const x = 24 + (W - 48) * k / (n - 1); f += '<circle cx="' + x.toFixed(1) + '" cy="' + (30 - (k % 2) * 5) + '" r="' + (r - (k % 3)) + '" fill="#fff" stroke="#d6eef5" stroke-width="1.5"/>'; } return f; };
    const feet = c => '<rect x="34" y="100" width="18" height="12" rx="6" fill="' + c + '"' + S25 + '/><rect x="' + (W - 52) + '" y="100" width="18" height="12" rx="6" fill="' + c + '"' + S25 + '/>';
    if (t === 0) s = feet('#e8b24a') + foam(10, 7) + '<rect x="2" y="28" width="' + (W - 4) + '" height="16" rx="8" fill="#fff"' + S3 + '/><path d="' + basin + '" fill="#f4f8fb"' + S3 + '/>';
    if (t === 1) s = feet('#e8b24a') + foam(15, 11) + '<circle cx="' + (W * 0.3) + '" cy="10" r="7" fill="#fff" stroke="#d6eef5"/><circle cx="' + (W * 0.7) + '" cy="8" r="6" fill="#fff" stroke="#d6eef5"/><rect x="2" y="28" width="' + (W - 4) + '" height="16" rx="8" fill="#ffd6e6"' + S3 + '/><path d="' + basin + '" fill="#ffb3c7"' + S3 + '/>' + Array.from({ length: 8 }, (_, k) => '<circle cx="' + (40 + (W - 80) * k / 7).toFixed(1) + '" cy="' + (62 + (k % 2) * 16) + '" r="4" fill="#fff" opacity=".7"/>').join('');
    if (t === 2) s = '<path d="M' + (W * 0.3) + ' 22 q-6 -10 0 -20 M' + (W * 0.5) + ' 20 q6 -10 0 -20 M' + (W * 0.7) + ' 22 q-6 -10 0 -20" stroke="#fff" stroke-width="4" fill="none" opacity=".8" stroke-linecap="round"/><rect x="6" y="26" width="' + (W - 12) + '" height="18" rx="6" fill="#7fd0e0"/>' + '<rect x="2" y="30" width="' + (W - 4) + '" height="14" rx="6" fill="#c06ad8"' + S3 + '/><path d="M8 42 H' + (W - 8) + ' V100 Q' + (W - 8) + ' 108 ' + (W - 16) + ' 108 H16 Q8 108 8 100Z" fill="#f09ad8"' + S3 + '/>' + Array.from({ length: Math.floor(W / 40) }, (_, k) => '<path d="M' + (28 + 40 * k) + ' 44 V106" stroke="rgba(80,12,140,0.4)" stroke-width="2"/>').join('') + '<path d="M8 60 H' + (W - 8) + ' M8 90 H' + (W - 8) + '" stroke="#8a9aa8" stroke-width="4"/>';
    if (t === 3) s = '<rect x="6" y="24" width="' + (W - 12) + '" height="20" rx="6" fill="#bff0ea"/><rect x="2" y="30" width="' + (W - 4) + '" height="14" rx="7" fill="#eef2f6"' + S3 + '/><path d="' + basin + '" fill="#8fd6d0"' + S3 + '/><path d="M30 60 H' + (W - 30) + ' M40 80 H' + (W - 40) + '" stroke="#fff" stroke-width="2" opacity=".6"/>' + [14, W - 26].map(x => '<rect x="' + x + '" y="14" width="12" height="16" rx="2" fill="#ffffff"' + S2 + '/><path d="M' + (x + 6) + ' 14 q-3 -6 0 -10 q3 4 0 10" fill="#ffb000"/>').join('') + '<path d="M' + (W / 2 - 20) + ' 30 q-8 -16 -18 -14 M' + (W / 2) + ' 30 q2 -18 12 -20 M' + (W / 2 + 18) + ' 30 q10 -12 20 -8" stroke="#5fb85a" stroke-width="4" fill="none" stroke-linecap="round"/>';
    if (t === 4) s = feet('#ff5cc6') + '<rect x="6" y="24" width="' + (W - 12) + '" height="20" rx="6" fill="#9fe0f5"/><rect x="2" y="30" width="' + (W - 4) + '" height="14" rx="7" fill="#fff"' + S3 + '/>' + Array.from({ length: Math.floor(W / 30) }, (_, k) => '<rect x="' + (10 + 30 * k) + '" y="32" width="14" height="10" fill="#ff5cc6"/>').join('') + '<path d="' + basin + '" fill="#5fb6dc"' + S3 + '/><path d="M30 66 q20 -8 40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0" stroke="#fff" stroke-width="2.5" fill="none" opacity=".6"/>' + [W * 0.18, W * 0.8].map(x => '<g transform="translate(' + x.toFixed(0) + ' 4)"><ellipse cx="12" cy="20" rx="12" ry="8" fill="#ffd23a"' + S2 + '/><circle cx="16" cy="9" r="7" fill="#ffd23a"' + S2 + '/><path d="M22 9 l6 2 l-6 2z" fill="#ff9a3c"/><circle cx="17" cy="7.5" r="1.3" fill="#2a1a30"/></g>').join('');
    return { img: uri(W, H, s), x: 426 - W / 2, y: 252, w: W, h: H, seats: Array.from({ length: TUBCAP[t] }, (_, k) => ({ x: Math.round(426 - W / 2 + W * (k + 0.5) / TUBCAP[t]), y: 284, style: TUBSTYLE[t] })) };
  }
  function showerArt() {
    const back = '<rect x="6" y="20" width="68" height="190" rx="4" fill="#e6f7fd"' + S25 + '/>' + [50, 80, 110, 140, 170].map(y => '<path d="M6 ' + y + ' H74" stroke="#bfe3ef" stroke-width="2"/>').join('') + '<path d="M60 20 V8 H40 V22" stroke="#9fb4c0" stroke-width="4" fill="none"/><path d="M28 22 H52 L48 30 H32Z" fill="#c9d3dc"' + S2 + '/><path d="M0 4 H80" stroke="#f09ad8" stroke-width="4"/>';
    const front = '<rect x="4" y="2" width="72" height="60" rx="4" fill="rgba(191,227,239,0.45)" stroke="#8e1580" stroke-width="2.5"/><path d="M14 10 l12 -6 M18 22 l16 -8" stroke="#fff" stroke-width="3" opacity=".8"/><rect x="0" y="56" width="80" height="8" rx="3" fill="#fff"' + S2 + '/>';
    return { back: { img: uri(80, 212, back), x: 132, y: 88, w: 80, h: 212 }, front: { img: uri(80, 64, front), x: 132, y: 240, w: 80, h: 64 }, seats: [{ x: 172, y: 296, style: 'shower' }] };
  }
  function mudArt() {
    const back = '<rect x="6" y="20" width="68" height="190" rx="4" fill="#efdcc4"' + S25 + '/>' + [50, 80, 110, 140, 170].map(y => '<path d="M6 ' + y + ' H74" stroke="#d9b48a" stroke-width="2"/>').join('') + '<path d="M60 20 V8 H40 V22" stroke="#a64dc4" stroke-width="4" fill="none"/><path d="M26 22 H54 L50 32 H30Z" fill="#c06ad8"' + S2 + '/><ellipse cx="22" cy="150" rx="8" ry="5" fill="#a64dc4" opacity=".6"/><ellipse cx="58" cy="120" rx="6" ry="4" fill="#a64dc4" opacity=".5"/><path d="M0 4 H80" stroke="#a64dc4" stroke-width="4"/>';
    const front = '<rect x="4" y="2" width="72" height="60" rx="4" fill="rgba(200,160,110,0.35)" stroke="#8e1580" stroke-width="2.5"/><path d="M14 30 q4 10 0 18 M40 22 q4 12 0 22 M62 34 q4 8 0 14" stroke="#a64dc4" stroke-width="4" fill="none" stroke-linecap="round"/><rect x="0" y="56" width="80" height="8" rx="3" fill="#c06ad8"' + S2 + '/>';
    return { back: { img: uri(80, 212, back), x: 52, y: 88, w: 80, h: 212 }, front: { img: uri(80, 64, front), x: 52, y: 240, w: 80, h: 64 }, seats: [{ x: 92, y: 296, style: 'mud' }] };
  }
  function saunaArt() {
    const back = '<rect x="4" y="4" width="168" height="160" rx="8" fill="#f7b6e6"' + S3 + '/>' + [30, 56, 82, 108, 134].map(y => '<path d="M4 ' + y + ' H172" stroke="rgba(80,12,140,0.35)" stroke-width="2"/>').join('') + '<rect x="12" y="100" width="152" height="14" rx="3" fill="#c06ad8"' + S2 + '/><rect x="20" y="16" width="34" height="24" rx="3" fill="#ffe8b8"' + S2 + '/><text x="88" y="34" text-anchor="middle" font-family="Fredoka, sans-serif" font-weight="700" font-size="16" fill="#ffffff" stroke="#8e1580" stroke-width="1" paint-order="stroke">SAUNA</text>';
    const front = '<rect x="2" y="2" width="172" height="40" rx="6" fill="#e389d4"' + S3 + '/><path d="M2 22 H174" stroke="rgba(80,12,140,0.4)" stroke-width="2"/><g transform="translate(130 -18)"><path d="M2 20 H30 L26 38 H6Z" fill="#c06ad8"' + S2 + '/><circle cx="10" cy="16" r="5" fill="#8a8a96"' + S2 + '/><circle cx="20" cy="14" r="6" fill="#9a9aa6"' + S2 + '/></g>';
    return { back: { img: uri(176, 168, back), x: 672, y: 124, w: 176, h: 168 }, front: { img: uri(176, 44, front), x: 672, y: 264, w: 176, h: 44 }, seats: [{ x: 724, y: 288, style: 'sauna' }, { x: 800, y: 288, style: 'sauna' }] };
  }
  const BEDC = [['#f09ad8', '#ffffff', '#e8d6b8'], ['#ff9db0', '#ffffff', 'conic-check'], ['#c9b6f0', '#ffffff', '#b7a0e6'], ['#d6eefc', '#ffffff', '#9fd8f0'], ['#8a5fd6', '#ffffff', '#6a3fb0']];
  function bedArt(t) {
    const [hb, mat, bl] = BEDC[t]; let b = '';
    if (t === 0) b = '<rect x="10" y="66" width="164" height="46" rx="8" fill="' + hb + '"' + S3 + '/>';
    else if (t === 1) b = '<path d="M6 112 V82 Q6 40 92 40 Q178 40 178 82 V112Z" fill="' + hb + '"' + S3 + '/><circle cx="92" cy="66" r="7" fill="#ffd66b"' + S2 + '/>';
    else if (t === 2) b = '<rect x="4" y="0" width="8" height="140" fill="#c06ad8"' + S2 + '/><rect x="172" y="0" width="8" height="140" fill="#c06ad8"' + S2 + '/><path d="M4 4 H180 Q170 30 150 34 Q92 44 34 34 Q14 30 4 4Z" fill="' + hb + '"' + S25 + '/><path d="M12 62 Q92 30 172 62 V112 H12Z" fill="#ead8ff"' + S3 + '/>';
    else if (t === 3) b = '<path d="M8 112 V80 Q2 58 24 54 Q30 34 56 40 Q70 20 92 30 Q114 20 128 40 Q154 34 160 54 Q182 58 176 80 V112Z" fill="' + hb + '"' + S3 + '/>';
    else b = '<path d="M6 112 V70 Q6 38 92 38 Q178 38 178 70 V112Z" fill="' + hb + '"' + S3 + '/>' + [46, 92, 138].map(x => '<circle cx="' + x + '" cy="66" r="3.5" fill="#ffd66b"/>').join('') + '<path d="M76 30 l6 -12 l10 8 l10 -8 l6 12z" fill="#ffd66b"' + S2 + '/>';
    b += '<rect x="0" y="98" width="184" height="58" rx="22" fill="' + mat + '"' + S3 + '/><rect x="14" y="104" width="66" height="24" rx="12" fill="#fff"' + S25 + '/><rect x="104" y="104" width="66" height="24" rx="12" fill="#fff"' + S25 + '/>';
    let f;
    if (bl === 'conic-check') f = '<defs><pattern id="c" width="20" height="20" patternUnits="userSpaceOnUse"><rect width="20" height="20" fill="#ffe3a3"/><rect width="10" height="10" fill="#ffb3c7"/><rect x="10" y="10" width="10" height="10" fill="#ffb3c7"/></pattern></defs><rect x="2" y="2" width="184" height="38" rx="16" fill="url(#c)"' + S3 + '/>';
    else f = '<rect x="2" y="2" width="184" height="38" rx="16" fill="' + bl + '"' + S3 + '/>' + (t === 2 ? [30, 80, 130, 160].map((x, k) => '<circle cx="' + x + '" cy="' + (16 + (k % 2) * 10) + '" r="3" fill="#fff"/>').join('') : t === 3 ? '<path d="M30 26 q8 -10 16 0 q8 -8 14 2 M110 20 q8 -10 16 0 q8 -8 14 2" stroke="#fff" stroke-width="3" fill="none"/>' : t === 4 ? '<path d="M2 12 H186" stroke="#ffd66b" stroke-width="4"/>' : '');
    return { back: uri(184, 170, b), front: uri(188, 42, f) };
  }
  const DJS = [[110, 46], [172, 60], [190, 66], [204, 74], [230, 86]];
  function djArt(t) {
    const [w, h] = DJS[t]; let s;
    if (t === 0) s = '<rect x="6" y="18" width="' + (w - 12) + '" height="10" rx="3" fill="#c06ad8"' + S25 + '/><path d="M14 28 V' + h + ' M' + (w - 14) + ' 28 V' + h + '" stroke="#8e1580" stroke-width="5"/><path d="M38 18 L44 2 H70 L76 18Z" fill="#c9d3dc"' + S2 + '/>';
    else {
      const base = ['#5a2a78', '#2a3a78', '#1a1a2a', '#3a1850'][t - 1];
      s = '<rect x="2" y="12" width="' + (w - 4) + '" height="' + (h - 12) + '" rx="10" fill="' + base + '" stroke="#2a1430" stroke-width="3"/>' + '<circle cx="' + (w * 0.28) + '" cy="10" r="12" fill="#222" stroke="#2a1430" stroke-width="3"/><circle cx="' + (w * 0.72) + '" cy="10" r="12" fill="#222" stroke="#2a1430" stroke-width="3"/><circle cx="' + (w * 0.28) + '" cy="10" r="3" fill="#ff5cc6"/><circle cx="' + (w * 0.72) + '" cy="10" r="3" fill="#5cf2c8"/>';
      if (t >= 2) s += '<rect x="10" y="' + (h - 14) + '" width="' + (w - 20) + '" height="5" rx="2" fill="#5cf2c8"/>';
      if (t >= 3) s += '<rect x="' + (w / 2 - 26) + '" y="24" width="52" height="22" rx="3" fill="#ff5cc6" opacity=".85"/><path d="M' + (w / 2 - 20) + ' 40 l8 -8 l8 6 l8 -10 l8 8 l8 -4" stroke="#fff" stroke-width="2" fill="none"/>';
      if (t >= 4) s += [12, w - 24].map(x => '<rect x="' + x + '" y="30" width="12" height="' + (h - 40) + '" rx="3" fill="#ffd66b"/>').join('');
    }
    return { img: uri(w, h, s), x: 426 - w / 2, y: 198 - h, w, h };
  }
  const SPK = [[46, 64], [66, 110], [72, 136], [78, 156], [92, 176]];
  function speakerArt(t) {
    const [w, h] = SPK[t]; let s = '<rect x="2" y="2" width="' + (w - 4) + '" height="' + (h - 4) + '" rx="10" fill="#3a2030" stroke="#2a1430" stroke-width="3"/>';
    const cone = (cy, r, c) => '<circle cx="' + w / 2 + '" cy="' + cy + '" r="' + r + '" fill="#5a3a50" stroke="#2a1430" stroke-width="2.5"/><circle cx="' + w / 2 + '" cy="' + cy + '" r="' + (r * 0.4) + '" fill="' + c + '"/>';
    if (t === 0) s += cone(h * 0.55, w * 0.32, '#ff5cc6');
    else if (t === 1) s += cone(h * 0.27, w * 0.2, '#ff5cc6') + cone(h * 0.66, w * 0.3, '#5cf2c8');
    else if (t === 2) s += '<path d="M2 ' + h / 2 + ' H' + (w - 2) + '" stroke="#2a1430" stroke-width="3"/>' + cone(h * 0.24, w * 0.3, '#ff5cc6') + cone(h * 0.74, w * 0.3, '#5cf2c8');
    else { s += cone(h * 0.2, w * 0.24, '#ffd66b') + cone(h * 0.48, w * 0.32, '#ff5cc6') + cone(h * 0.8, w * 0.32, '#5cf2c8') + '<rect x="6" y="6" width="5" height="' + (h - 12) + '" rx="2" fill="' + (t === 4 ? '#7cb8ff' : '#ff5cc6') + '"/><rect x="' + (w - 11) + '" y="6" width="5" height="' + (h - 12) + '" rx="2" fill="' + (t === 4 ? '#7cb8ff' : '#ff5cc6') + '"/>'; }
    return { img: uri(w, h, s), w, h };
  }
  function ballArt(t) {
    const disco = (cx, cy, r) => '<path d="M' + cx + ' 0 V' + (cy - r) + '" stroke="#c9c9d6" stroke-width="2"/><circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="#c9cfe0" stroke="#2a1430" stroke-width="2.5"/>' + Array.from({ length: 5 }, (_, k) => '<path d="M' + (cx - r) + ' ' + (cy - r + (k + 1) * r / 3) + ' H' + (cx + r) + '" stroke="rgba(40,30,60,0.35)" stroke-width="1"/>').join('') + '<circle cx="' + (cx - r * 0.35) + '" cy="' + (cy - r * 0.35) + '" r="' + (r * 0.25) + '" fill="#fff" opacity=".9"/>';
    if (t === 0) return { img: uri(40, 60, disco(20, 38, 16)), x: 406, y: 0, w: 40, h: 60 };
    if (t === 2) return { img: uri(160, 90, disco(40, 60, 24) + disco(120, 52, 22) + '<path d="M80 0 V30" stroke="#c9c9d6" stroke-width="2"/><circle cx="80" cy="36" r="8" fill="#ffd66b" stroke="#2a1430" stroke-width="2"/>'), x: 346, y: 0, w: 160, h: 90 };
    if (t === 3) { let s = '<path d="M75 0 V20" stroke="#ffd66b" stroke-width="3"/><path d="M20 40 Q75 70 130 40" stroke="#ffd66b" stroke-width="4" fill="none"/><path d="M40 30 Q75 52 110 30" stroke="#ffd66b" stroke-width="4" fill="none"/><circle cx="75" cy="22" r="8" fill="#ffd66b" stroke="#2a1430" stroke-width="2"/>'; for (let k = 0; k < 9; k++) { const x = 22 + k * 13.3, y = 44 + Math.sin(k / 8 * Math.PI) * 22; s += '<path d="M' + x.toFixed(1) + ' ' + (y - 4).toFixed(1) + ' l4 10 l-4 10 l-4 -10z" fill="#e6f7ff" stroke="#9fd8f0" stroke-width="1.2"/>'; } return { img: uri(150, 100, s), x: 351, y: 0, w: 150, h: 100 }; }
    if (t === 4) return { img: uri(110, 120, '<path d="M55 0 V18" stroke="#c9c9d6" stroke-width="2"/><circle cx="55" cy="66" r="44" fill="#3a2a8a" stroke="#2a1430" stroke-width="3"/><circle cx="55" cy="66" r="44" fill="url(#g)"/><defs><radialGradient id="g" cx=".35" cy=".3"><stop offset="0" stop-color="#ff9fe0"/><stop offset=".5" stop-color="#7c5cff" stop-opacity=".6"/><stop offset="1" stop-color="#1a0c46" stop-opacity="0"/></radialGradient></defs>' + [[30, 50], [70, 40], [50, 80], [80, 76], [38, 92], [62, 60]].map(([x, y]) => '<circle cx="' + x + '" cy="' + y + '" r="1.8" fill="#fff"/>').join('') + '<ellipse cx="55" cy="66" rx="58" ry="10" fill="none" stroke="#ffd66b" stroke-width="3" opacity=".8"/>'), x: 371, y: 0, w: 110, h: 120 };
    return null;
  }

  /* ---------- slots ---------- */
  const T = (key, room, slotName, names, effects, extra) => ({ key, room, name: slotName, tiers: names.map((n, i) => ({ id: key + i, slot: key, room, tier: i, name: n, lvl: LV[i], coins: CO[i], usd: US[i], effect: effects[i] })), ...(extra || {}) });
  const SLOTS = [
    T('sofa', 'living', 'Sofa', ['Saggy Old Sofa', 'Comfy Sofa', 'Big Sofa', 'Sectional', 'Royal Lounge'], SEATS.map(n => n + ' seats for TV time')),
    T('tv', 'living', 'TV', ['Fuzzy Old TV', 'Flat TV', 'Big Screen', 'Curved TV', 'Home Cinema'], ['+0.20 energy/s', '+0.30 energy/s', '+0.45 energy/s', '+0.60 energy/s', '+0.80 energy/s']),
    T('fridge', 'kitchen', 'Fridge', ['Rusty Mini Fridge', 'Retro Fridge', 'Double Door', 'Smart Fridge', 'Chef Fridge'], ['3 foods', '5 foods', '8 foods', '11 foods', 'All 13 foods']),
    T('tub', 'bath', 'Bathtub', ['Leaky Old Tub', 'Bubble Bath', 'Hot Tub', 'Spa Pool', 'Duck Pool Party'], ['3 spots · slow clean', '4 spots · bubbly clean', '5 spots · clean + energy', '6 spots · face mask spa', '6 spots · clean + coins']),
    T('bed', 'bed', 'Beds', ['Creaky Cot', 'Cozy Bed', 'Canopy Bed', 'Cloud Bed', 'Royal Bed'], ['Naps up to 1h', 'Sleep up to 2h', 'Sleep up to 4h', 'Sleep up to 8h', 'Sleep up to 12h']),
    T('floor', 'dance', 'Dance Floor', ['Scuffed Floor', 'Small Floor', 'Party Floor', 'Big Floor', 'Mega Floor'], ['2 dancers', '3 dancers', '4 dancers', '6 dancers', '8 dancers']),
    T('dj', 'dance', 'DJ Booth', ['Old Laptop', 'DJ Deck', 'Pro Mixer', 'LED Booth', 'Mega Stage'], ['1 song', '2 songs', '3 songs', '4 songs', '6 songs']),
    T('speakers', 'dance', 'Speakers', ['Crackly Speakers', 'Party Speakers', 'Bass Stacks', 'LED Towers', 'Mega Stacks'], ['Basic sound', '-3% draining', '-5% draining', '-8% draining', '-10% draining']),
    T('ball', 'dance', 'Ceiling Light', ['Dusty Disco Ball', 'Disco Ball', 'Twin Balls', 'Crystal Chandelier', 'Galaxy Ball'], ['Tiny sparkle', '-2% draining', '-3% draining', '-5% draining', '-7% draining']),
    T('lights', 'dance', 'Club Lights', ['Flickery Bulb', 'Spotlights', 'Color Beams', 'Lasers', 'Laser Show'], ['No effects', '-2% draining', '-4% draining', '-6% draining', '-8% draining']),
  ];
  const DRAIN = { speakers: [0, 0.03, 0.05, 0.08, 0.1], ball: [0, 0.02, 0.03, 0.05, 0.07], lights: [0, 0.02, 0.04, 0.06, 0.08] };
  const EXTRAS = [
    { id: 'shower', room: 'bath', name: 'Shower', lvl: 3, coins: 600, usd: 1.99, effect: '1 spot · fastest clean' },
    { id: 'mud', room: 'bath', name: 'Mud Shower', lvl: 4, coins: 900, usd: 1.99, effect: '1 spot · messy fun, then clean' },
    { id: 'sauna', room: 'bath', name: 'Steam Sauna', lvl: 5, coins: 1200, usd: 2.99, effect: '2 spots · clean + energy' },
  ];
  /* ---------- yard games ---------- */
  const PADS = [{ k: 'A', cx: 110 }, { k: 'B', cx: 290 }, { k: 'C', cx: 480 }, { k: 'D', cx: 730 }];
  const G = (id, name, lvl, coins, usd, pad, effect) => ({ id, name, lvl, coins, usd, pad: pad || null, effect });
  const GAMES = [
    G('swing', 'Swing', 1, 0, 0, 'A', '1 player'), G('ball', 'Ball Field', 1, 0, 0, 'D', '2 players'),
    G('hop', 'Hopscotch', 1, 150, 0.99, null, '1 player'), G('tramp', 'Trampoline', 1, 200, 0.99, 'B', '1 player'),
    G('bubble', 'Bubble Wand', 2, 250, 0.99, null, '1 player'), G('seesaw', 'Seesaw', 2, 300, 0.99, 'C', '2 players'),
    G('sand', 'Sandbox', 3, 500, 1.99, null, '2 players'), G('kite', 'Kite', 4, 700, 1.99, null, '1 player'),
    G('slide', 'Slide', 5, 1000, 1.99, null, '1 player'), G('pit', 'Ball Pit', 6, 1300, 2.99, null, '2 players'),
    G('pool', 'Paddling Pool', 7, 1600, 2.99, null, '2 players'), G('merry', 'Merry-go-round', 8, 2000, 2.99, null, '2 players'),
  ];
  function gameArt(id, cx) {
    const B = (w, h, s) => ({ img: uri(w, h, s), w, h });
    switch (id) {
      case 'slide': return { back: { ...B(140, 150, '<path d="M14 150 V40 M34 150 V40" stroke="#8e1580" stroke-width="5"/>' + [60, 80, 100, 120, 140].map(y => '<path d="M14 ' + y + ' H34" stroke="#8e1580" stroke-width="4"/>').join('') + '<rect x="8" y="34" width="40" height="10" rx="4" fill="#ffd66b"' + S25 + '/><path d="M44 36 Q90 50 136 140 L124 146 Q82 64 40 48Z" fill="#ff5cc6"' + S25 + '/>'), x: cx - 70, y: 212 }, spots: [{ dx: 0, y: 360, g: 'slide' }] };
      case 'sand': return { back: { ...B(150, 30, '<rect x="2" y="4" width="146" height="24" rx="6" fill="#f6dca4"' + S25 + '/><path d="M20 10 q10 -6 20 0 M90 12 q10 -6 20 0" stroke="#e2c08a" stroke-width="3" fill="none"/><path d="M118 6 l10 -8" stroke="#ff5cc6" stroke-width="4"/><rect x="124" y="-6" width="10" height="8" rx="2" fill="#7cc8ff"/>'), x: cx - 75, y: 330 }, front: { ...B(150, 22, '<rect x="2" y="2" width="146" height="18" rx="5" fill="#f09ad8"' + S25 + '/>'), x: cx - 75, y: 352 }, spots: [{ dx: -36, y: 356, g: 'sand', side: 0 }, { dx: 36, y: 356, g: 'sand', side: 1 }] };
      case 'pit': return { back: { ...B(150, 30, Array.from({ length: 16 }, (_, k) => '<circle cx="' + (10 + k * 8.6).toFixed(1) + '" cy="' + (12 + (k % 3) * 5) + '" r="6" fill="' + ['#ff5cc6', '#ffd66b', '#7cc8ff', '#7be495', '#c9b6f0'][k % 5] + '"' + S2 + '/>').join('')), x: cx - 75, y: 318 }, front: { ...B(150, 36, '<rect x="2" y="2" width="146" height="32" rx="10" fill="#9fd8f0"' + S3 + '/>' + Array.from({ length: 6 }, (_, k) => '<circle cx="' + (16 + k * 24) + '" cy="4" r="6" fill="' + ['#ff5cc6', '#ffd66b', '#7cc8ff', '#7be495', '#c9b6f0', '#ff9db0'][k] + '"' + S2 + '/>').join('')), x: cx - 75, y: 334 }, spots: [{ dx: -36, y: 352, g: 'pit', side: 0 }, { dx: 36, y: 352, g: 'pit', side: 1 }] };
      case 'pool': return { back: { ...B(160, 24, '<ellipse cx="80" cy="12" rx="76" ry="10" fill="#7fd0f0"/>'), x: cx - 80, y: 326 }, front: { ...B(160, 34, '<path d="M4 4 H156 V22 Q156 32 146 32 H14 Q4 32 4 22Z" fill="#ff9db0"' + S3 + '/><path d="M4 4 H156" stroke="#fff" stroke-width="3"/>' + [30, 70, 110, 140].map(x => '<circle cx="' + x + '" cy="18" r="4" fill="#fff" opacity=".7"/>').join('')), x: cx - 80, y: 334 }, spots: [{ dx: -38, y: 350, g: 'pool', side: 0 }, { dx: 38, y: 350, g: 'pool', side: 1 }] };
      case 'merry': return { back: { ...B(150, 120, '<path d="M8 34 L75 4 L142 34Z" fill="#ff5cc6"' + S3 + '/><path d="M30 34 L75 4 L52 34Z M98 34 L75 4 L120 34Z" fill="#ffffff"/><rect x="71" y="34" width="8" height="70" fill="#c9b6f0"' + S2 + '/><ellipse cx="75" cy="106" rx="70" ry="12" fill="#ffd66b"' + S3 + '/>'), x: cx - 75, y: 252 }, spots: [{ dx: 0, y: 348, g: 'merry', side: 0 }, { dx: 0, y: 348, g: 'merry', side: 1 }] };
      case 'kite': return { back: { ...B(80, 160, '<path d="M30 150 Q34 90 58 30" stroke="#8e1580" stroke-width="1.5" fill="none"/><path d="M58 4 L76 26 L58 50 L40 26Z" fill="#ff5cc6"' + S25 + '/><path d="M58 4 V50 M40 26 H76" stroke="#ffd66b" stroke-width="2"/><path d="M58 50 q-6 10 2 18 q-8 8 0 16" stroke="#8e1580" stroke-width="1.5" fill="none"/><path d="M56 62 l6 4 l-6 2z M56 78 l6 4 l-6 2z" fill="#7cc8ff"/>'), x: cx - 40, y: 168 }, spots: [{ dx: -12, y: 362, g: 'kite' }] };
      case 'bubble': return { back: { ...B(110, 90, '<rect x="70" y="64" width="26" height="22" rx="5" fill="#9fd8f0"' + S25 + '/><ellipse cx="83" cy="64" rx="13" ry="4" fill="#d6f2fc"' + S2 + '/>' + [[30, 30, 9], [52, 16, 6], [16, 52, 6], [44, 44, 4], [64, 30, 5]].map(([x, y, r]) => '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="rgba(210,244,255,0.5)" stroke="#fff" stroke-width="1.5"/>').join('')), x: cx - 40, y: 276 }, spots: [{ dx: -14, y: 362, g: 'bubble' }] };
      case 'hop': return { back: { ...B(170, 40, [0, 1, 2, 3, 4].map(k => '<rect x="' + (6 + k * 32) + '" y="' + (k % 2 ? 4 : 14) + '" width="28" height="22" rx="3" fill="none" stroke="#fff" stroke-width="3"/><text x="' + (20 + k * 32) + '" y="' + (k % 2 ? 20 : 30) + '" text-anchor="middle" font-family="Fredoka, sans-serif" font-weight="700" font-size="12" fill="#fff">' + (k + 1) + '</text>').join('')), x: cx - 85, y: 346 }, spots: [{ dx: 0, y: 366, g: 'hop' }] };
    }
    return null;
  }

  /* ---------- decor (free placement) ---------- */
  const D = (id, room, name, perk, perkText, lvl, coins, usd, x, y, w, h, art) => ({ id, room, name, perk, perkText, lvl, coins, usd, x, y, w, h, art });
  const OS = ' stroke="' + O + '"';
  const star = (x, y, c) => '<path transform="translate(' + x + ' ' + y + ')" d="M0 -7 L2 -2.2 L7 -2 L3 1.4 L4.4 6.4 L0 3.6 L-4.4 6.4 L-3 1.4 L-7 -2 L-2 -2.2Z" fill="' + c + '"' + OS + ' stroke-width="1.5" stroke-linejoin="round"/>';
  const DECOR = [
    D('l_art', 'living', 'Rainbow Art', 0.04, '+4% coins', 1, 150, 0.99, 664, 44, 100, 76, '<rect x="3" y="3" width="94" height="70" rx="6" fill="#e389d4"' + S3 + '/><rect x="11" y="11" width="78" height="54" rx="3" fill="#ffffff"' + S2 + '/><path d="M22 54 A28 28 0 0 1 78 54" fill="none" stroke="#ff5cc6" stroke-width="6"/><path d="M29 54 A21 21 0 0 1 71 54" fill="none" stroke="#ffd66b" stroke-width="6"/><path d="M36 54 A14 14 0 0 1 64 54" fill="none" stroke="#7fae6a" stroke-width="6"/>'),
    D('l_lamp', 'living', 'Cozy Lamp', 0.06, '+6% coins', 3, 400, 1.99, 800, 100, 46, 140, '<ellipse cx="23" cy="38" rx="22" ry="8" fill="#fff3b0" opacity=".7"/><path d="M6 34 L14 4 H32 L40 34 Z" fill="#ffd66b"' + S3 + ' stroke-linejoin="round"/><rect x="21" y="34" width="4" height="96" fill="#a64dc4"/><ellipse cx="23" cy="132" rx="16" ry="5" fill="#c06ad8"' + S25 + '/>'),
    D('l_fish', 'living', 'Fishbowl', 0.08, '+8% coins', 5, 900, 2.99, 396, 106, 54, 44, '<ellipse cx="27" cy="25" rx="24" ry="17" fill="#bfe8f6"' + S25 + '/><rect x="12" y="4" width="30" height="7" rx="3" fill="#e6f7fd"' + S2 + '/><path d="M20 23 q7 -6 14 0 q-7 6 -14 0Z M33 23 l6 -4 v8Z" fill="#ff9a3c"/><circle cx="24" cy="22" r="1" fill="#2a1a30"/>'),
    D('l_plant', 'living', 'Monstera Plant', 0.03, '+3% coins', 2, 250, 0.99, 140, 250, 60, 90, '<path d="M30 54 C6 50 2 24 14 12 C24 22 28 36 30 54Z" fill="#7fae6a"' + S25 + '/><path d="M30 54 C54 50 58 22 46 8 C36 20 32 36 30 54Z" fill="#94c47c"' + S25 + '/><path d="M14 54 H46 L42 88 H18 Z" fill="#ff5cc6"' + S25 + '/>'),
    D('k_herb', 'kitchen', 'Herb Pots', 0.05, '+5% food fill', 2, 200, 0.99, 176, 112, 140, 40, '<circle cx="22" cy="12" r="8" fill="#7fd06f"' + S2 + '/><circle cx="66" cy="10" r="8" fill="#8fdc7a"' + S2 + '/><circle cx="112" cy="12" r="8" fill="#5fb85a"' + S2 + '/>' + [9, 53, 100].map(x => '<path d="M' + x + ' 16 h26 l-3 18 h-20 Z" fill="#d9774f"' + S2 + '/>').join('') + '<rect x="1" y="33" width="138" height="6" rx="3" fill="#c06ad8"' + S2 + '/>'),
    D('k_clock', 'kitchen', 'Kitty Clock', 0.05, '+5% food fill', 4, 450, 1.99, 562, 132, 60, 70, '<path d="M12 22 L10 4 L24 14Z M48 22 L50 4 L36 14Z" fill="#ff9db0"' + S25 + '/><circle cx="30" cy="36" r="24" fill="#ffffff"' + S3 + '/><path d="M30 36 V22 M30 36 L39 41" stroke="' + O + '" stroke-width="3" stroke-linecap="round"/>'),
    D('k_plant', 'kitchen', 'Hanging Plant', 0.08, '+8% food fill', 6, 1000, 2.99, 468, 10, 46, 104, '<path d="M23 0 V40" stroke="#a64dc4" stroke-width="2"/><path d="M6 42 H40 L36 62 H10 Z" fill="#7fc8e8"' + S25 + '/><path d="M10 60 q-6 18 -2 34 M30 62 q4 16 -1 30 M37 60 q6 14 3 26" stroke="#5fb85a" stroke-width="3.2" fill="none" stroke-linecap="round"/>'),
    D('b_duck', 'bath', 'Duck Shelf', 0.05, '+5% clean speed', 2, 200, 0.99, 266, 94, 86, 40, [2, 30, 58].map(x => '<g transform="translate(' + x + ' 0)"><ellipse cx="12" cy="27" rx="11" ry="7" fill="#ffd23a"' + S2 + '/><circle cx="15" cy="16" r="6.5" fill="#ffd23a"' + S2 + '/></g>').join('') + '<rect x="0" y="33" width="86" height="6" rx="3" fill="#e6f7fd"' + S2 + '/>'),
    D('b_fern', 'bath', 'Spa Fern', 0.08, '+8% clean speed', 4, 450, 1.99, 486, 30, 76, 104, '<path d="M38 0 V30" stroke="#a64dc4" stroke-width="2"/><path d="M16 30 H60 L54 56 H22 Z" fill="#ffffff"' + S25 + '/><path d="M22 54 Q4 70 2 96 M30 56 Q22 76 24 102 M46 56 Q54 76 52 102 M54 54 Q72 70 74 96" stroke="#5fb85a" stroke-width="3.4" fill="none" stroke-linecap="round"/>'),
    D('d_moon', 'bed', 'Moon Light', 0.01, '+1% energy speed', 2, 250, 0.99, 556, 52, 52, 60, '<path d="M26 0 V10" stroke="' + O + '" stroke-width="2"/><path d="M34 12 A22 22 0 1 0 44 50 A17 17 0 0 1 34 12Z" fill="#ffe680"' + S25 + '/>'),
    D('d_stars', 'bed', 'Star Garland', 0.015, '+1.5% energy speed', 3, 500, 1.99, 194, 28, 124, 42, '<path d="M2 4 Q62 34 122 4" stroke="' + O + '" stroke-width="2" fill="none"/>' + star(18, 16, '#ffd66b') + star(42, 25, '#ff9db0') + star(62, 28, '#9fd8f0') + star(82, 25, '#ffd66b') + star(106, 16, '#c9b6f0')),
    D('d_teddy', 'bed', 'Teddy Pile', 0.015, '+1.5% energy speed', 4, 600, 1.99, 20, 310, 70, 60, '<circle cx="35" cy="34" r="22" fill="#f09ad8"' + S25 + '/><circle cx="18" cy="16" r="8" fill="#f09ad8"' + S25 + '/><circle cx="52" cy="16" r="8" fill="#f09ad8"' + S25 + '/><ellipse cx="35" cy="40" rx="9" ry="7" fill="#f6dca4"/><circle cx="28" cy="30" r="2" fill="' + O + '"/><circle cx="42" cy="30" r="2" fill="' + O + '"/>'),
    D('d_rug', 'bed', 'Fluffy Rug', 0.02, '+2% energy speed', 6, 1100, 2.99, 326, 352, 200, 34, '<ellipse cx="100" cy="17" rx="97" ry="15" fill="#c9b6f0"' + S3 + '/><ellipse cx="100" cy="17" rx="70" ry="9" fill="#e4d9fb"/>'),
    D('d_diff', 'bed', 'Lavender Diffuser', 0.02, '+2% energy speed', 7, 1300, 2.99, 802, 250, 40, 60, '<path d="M8 26 Q20 10 32 26 V54 H8Z" fill="#c9b6f0"' + S25 + '/><path d="M16 18 q-4 -8 2 -14 M24 18 q4 -8 -2 -14" stroke="#e4d9fb" stroke-width="3" fill="none" stroke-linecap="round"/>'),
    D('n_neon', 'dance', 'Neon "PARTY"', 0.02, '-2% draining', 2, 300, 0.99, 168, 22, 152, 48, '<rect x="2" y="2" width="148" height="44" rx="12" fill="#2b1d3a"' + S3 + '/><text x="76" y="33" text-anchor="middle" font-family="Fredoka, sans-serif" font-weight="700" font-size="24" fill="#fff" stroke="#ff4fbf" stroke-width="1.5" paint-order="stroke">PARTY</text>'),
    D('n_heart', 'dance', 'Neon Heart', 0.02, '-2% draining', 3, 400, 0.99, 640, 30, 70, 64, '<path d="M35 58 C10 40 2 26 10 14 C18 2 32 6 35 16 C38 6 52 2 60 14 C68 26 60 40 35 58Z" fill="none" stroke="#ff5cc6" stroke-width="5"/><path d="M35 58 C10 40 2 26 10 14 C18 2 32 6 35 16 C38 6 52 2 60 14 C68 26 60 40 35 58Z" fill="none" stroke="#fff" stroke-width="1.5"/>'),
    D('n_vinyl', 'dance', 'Vinyl Wall', 0.03, '-3% draining', 4, 600, 1.99, 30, 30, 96, 60, [[22, 22, '#ff5cc6'], [72, 20, '#5cf2c8'], [48, 44, '#ffd66b']].map(([x, y, c]) => '<circle cx="' + x + '" cy="' + y + '" r="16" fill="#1a1a22" stroke="#2a1430" stroke-width="2"/><circle cx="' + x + '" cy="' + y + '" r="5" fill="' + c + '"/>').join('')),
    D('n_led', 'dance', 'LED Panel', 0.04, '-4% draining', 6, 1000, 2.99, 520, 60, 80, 56, '<rect x="2" y="2" width="76" height="52" rx="6" fill="#1a0c26" stroke="#2a1430" stroke-width="3"/>' + Array.from({ length: 24 }, (_, k) => '<rect x="' + (8 + (k % 6) * 11) + '" y="' + (8 + Math.floor(k / 6) * 11) + '" width="8" height="8" rx="2" fill="' + ['#ff5cc6', '#5cf2c8', '#ffd66b', '#7cb8ff'][(k + Math.floor(k / 6)) % 4] + '"/>').join('')),
    D('n_fog', 'dance', 'Fog Machine', 0.05, '-5% draining', 7, 1200, 2.99, 120, 320, 86, 60, '<ellipse cx="24" cy="14" rx="16" ry="9" fill="#fff" opacity=".85"/><ellipse cx="42" cy="10" rx="14" ry="8" fill="#fff" opacity=".7"/><rect x="6" y="24" width="74" height="30" rx="8" fill="#5a4a60"' + S3 + '/><circle cx="58" cy="38" r="5" fill="#7be495"/>'),
    D('y_flower', 'yard', 'Flower Bed', 0.03, '-3% draining', 2, 250, 0.99, 380, 352, 98, 40, '<circle cx="14" cy="10" r="5" fill="#ff9db0"' + S2 + '/><circle cx="34" cy="7" r="5" fill="#ffd66b"' + S2 + '/><circle cx="54" cy="9" r="5" fill="#ff5cc6"' + S2 + '/><circle cx="74" cy="7" r="5" fill="#c9b6f0"' + S2 + '/><path d="M3 22 H95 V34 Q95 38 91 38 H7 Q3 38 3 34Z" fill="#c06ad8"' + S25 + '/>'),
    D('y_bird', 'yard', 'Birdhouse', 0.04, '-4% draining', 4, 550, 1.99, 792, 94, 52, 110, '<rect x="23" y="44" width="6" height="64" fill="#a64dc4"/><path d="M4 26 L26 6 L48 26Z" fill="#ff5cc6"' + S25 + '/><rect x="9" y="24" width="34" height="26" rx="2" fill="#ffd66b"' + S25 + '/><circle cx="26" cy="36" r="5" fill="' + O + '"/>'),
    D('y_lamp', 'yard', 'Garden Lamp', 0.06, '-6% draining', 7, 1200, 2.99, 196, 230, 34, 112, '<circle cx="17" cy="16" r="15" fill="#fff3b0" opacity=".55"/><path d="M8 8 H26 L23 26 H11 Z" fill="#ffe680"' + S25 + '/><rect x="15" y="26" width="4" height="80" fill="#3a2a40"/><rect x="8" y="104" width="18" height="6" rx="2" fill="#3a2a40"/>'),
  ];
  const LIGHT = { l_lamp: [23, 36, 170, '255,214,122'], l_fish: [27, 25, 70, '140,220,255'], d_moon: [26, 36, 130, '255,240,170'], d_diff: [20, 20, 70, '200,170,255'], n_neon: [76, 24, 120, '255,92,198'], n_heart: [35, 32, 100, '255,92,198'], n_led: [40, 28, 110, '92,242,200'], y_lamp: [17, 16, 140, '255,226,140'], y_bird: [26, 36, 50, '255,214,107'] };
  DECOR.forEach(d => { d.img = uri(d.w, d.h, d.art); if (LIGHT[d.id]) { const [lx, ly, r, c] = LIGHT[d.id]; d.light = { lx, ly, r, c }; } });

  /* ---------- themes ---------- */
  const W_GEN = [['Original', null, 1], ['Mint Stripes', 'repeating-linear-gradient(90deg,#d9f2e3 0 26px,#eafaf0 26px 52px)', 2], ['Lilac Dots', 'radial-gradient(rgba(155,132,216,0.4) 2px, transparent 2.6px) 0 0/24px 24px, #efe7ff', 3], ['Sunny Check', 'conic-gradient(#fff3c4 90deg,#ffe6a0 90deg 180deg,#fff3c4 180deg 270deg,#ffe6a0 270deg) 0 0/40px 40px', 4], ['Berry Paper', 'radial-gradient(circle, #ff9db0 3px, transparent 3.6px) 0 0/30px 30px, radial-gradient(circle, #a8d98a 2px, transparent 2.6px) 15px 15px/30px 30px, #fff0f3', 5], ['Starry Night', 'radial-gradient(#fff 1px, transparent 1.6px) 0 0/23px 29px, radial-gradient(#ffd66b 1.2px, transparent 1.8px) 11px 13px/31px 37px, linear-gradient(180deg,#2a2060,#4a3a90)', 7]];
  const W_CLUB = [['Original', null, 1], ['Neon Grid', 'linear-gradient(90deg, rgba(255,92,198,0.35) 1px, transparent 1px) 0 0/32px 32px, linear-gradient(0deg, rgba(92,242,200,0.3) 1px, transparent 1px) 0 0/32px 32px, #1a0c26', 3], ['Galaxy', 'radial-gradient(#fff 1px, transparent 1.6px) 0 0/27px 31px, radial-gradient(ellipse at 30% 30%, #6a2a9a, #1a0c26 70%)', 4], ['Velvet Club', 'repeating-linear-gradient(90deg,#5a1a3a 0 30px,#4a1230 30px 60px)', 5], ['Gold Lounge', 'radial-gradient(circle, rgba(255,214,107,0.5) 2px, transparent 2.6px) 0 0/22px 22px, linear-gradient(180deg,#3a2410,#1e1208)', 6], ['Rainbow Club', 'linear-gradient(90deg, rgba(255,92,138,0.45), rgba(255,214,107,0.45), rgba(92,242,200,0.45), rgba(124,184,255,0.45), rgba(195,139,255,0.45)), #1a0c26', 8]];
  const F_GEN = [['Original', null, 1], ['Honey Planks', 'repeating-linear-gradient(90deg,#f9c4ec 0 80px,#8e1580 80px 82px,#f6b2e4 82px 162px,#8e1580 162px 164px)', 2], ['Pink Checker', 'conic-gradient(#fff 90deg,#ffd6e6 90deg 180deg,#fff 180deg 270deg,#ffd6e6 270deg) 0 0/48px 48px', 3], ['Blue Tiles', 'linear-gradient(90deg, #fff 2px, transparent 2px) 0 0/40px 40px, linear-gradient(0deg, #fff 2px, transparent 2px) 0 0/40px 40px, #bfe3ef', 4], ['Cozy Carpet', 'radial-gradient(rgba(255,255,255,0.35) 2px, transparent 2.6px) 0 0/16px 16px, #c9b6f0', 5], ['Marble', 'linear-gradient(135deg, transparent 45%, rgba(160,150,180,0.25) 46%, transparent 48%) 0 0/120px 90px, linear-gradient(45deg, transparent 60%, rgba(160,150,180,0.2) 61%, transparent 62%) 0 0/90px 70px, #f6f3fa', 7]];
  const F_CLUB = [['Original', null, 1], ['LED Tiles', 'conic-gradient(#3a1a5a 90deg,#1a2a5a 90deg 180deg,#5a1a3a 180deg 270deg,#1a4a4a 270deg) 0 0/60px 60px', 3], ['Mirror Floor', 'linear-gradient(135deg, rgba(255,255,255,0.12) 25%, transparent 25% 50%, rgba(255,255,255,0.12) 50% 75%, transparent 75%) 0 0/40px 40px, #2a2a3a', 5], ['Gold Stage', 'repeating-linear-gradient(90deg,#c98a00 0 60px,#a86e00 60px 62px)', 6], ['Starfield', 'radial-gradient(#fff 1px, transparent 1.6px) 0 0/19px 23px, #12081e', 8]];
  const F_YARD = [['Original', null, 1], ['Clover', 'radial-gradient(#7fd06f 3px, transparent 3.6px) 0 0/22px 22px, #a2d482', 2], ['Sandy Beach', 'radial-gradient(rgba(255,255,255,0.4) 1.5px, transparent 2px) 0 0/14px 14px, #f6dca4', 3], ['Flower Meadow', 'radial-gradient(#ff9db0 3px, transparent 3.6px) 0 0/34px 34px, radial-gradient(#ffd66b 3px, transparent 3.6px) 17px 17px/34px 34px, #96cb75', 5], ['Autumn Leaves', 'radial-gradient(#ff5cc6 4px, transparent 4.6px) 0 0/30px 30px, radial-gradient(#ffb000 3px, transparent 3.6px) 15px 15px/30px 30px, #c9a46a', 6], ['Snow', 'radial-gradient(#fff 3px, transparent 3.6px) 0 0/24px 24px, #e6f4fb', 8]];
  const C_GEN = [['None', null, 1], ['Wood Beams', 'repeating-linear-gradient(90deg,#c06ad8 0 44px,#a64dc4 44px 48px)', 2], ['Candy Stripes', 'repeating-linear-gradient(90deg,#ff9db0 0 18px,#fff 18px 36px)', 3], ['Fairy Lights', 'radial-gradient(circle, #ffe680 3px, transparent 4px) 0 4px/28px 16px, #8e1580', 4], ['Neon Trim', 'linear-gradient(90deg,#ff5c8a,#ffd66b,#5cf2c8,#7cb8ff,#c38bff)', 6], ['Cloud Puffs', 'radial-gradient(circle at 50% 0, #fff 14px, transparent 15px) 0 0/40px 20px, #bfe6ff', 7]];
  const SU = s => 'url("data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" ' + s + '</svg>') + '")';
  const CRACKS = c => '<g fill="none" stroke="' + c + '" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" opacity="0.75"><path d="M30 0 L38 22 L31 40 L44 63 L40 82"/><path d="M38 22 L53 30 L60 27"/><path d="M190 118 L176 138 L184 156 L170 180"/><path d="M184 156 L201 163"/></g>';
  const SH_WALL = SU('width="260" height="200">' + CRACKS('#6f5f48') + '<path d="M118 38 q16 -9 32 2 q11 15 -2 27 q-17 9 -31 -2 q-11 -14 1 -27z" fill="#e6dac3" stroke="#968466" stroke-width="1.4"/><path d="M124 44 q10 -4 18 2" stroke="#fff6e0" stroke-width="1.4" fill="none" opacity="0.7"/><g transform="translate(62 118)"><rect width="44" height="26" fill="#b5735a"/><path d="M0 9 h44 M0 18 h44 M14 0 v9 M30 9 v9 M18 18 v8" stroke="#86503e" stroke-width="1.4"/><path d="M-4 -3 q20 -7 52 2 q4 14 -2 30 q-26 5 -50 -2 q-4 -14 0 -30z" fill="none" stroke="#968466" stroke-width="1.8"/></g><circle cx="220" cy="30" r="5" fill="#7d8a5c" opacity="0.28"/><circle cx="230" cy="40" r="3" fill="#7d8a5c" opacity="0.25"/><circle cx="212" cy="44" r="2.4" fill="#7d8a5c" opacity="0.25"/>') + ' 0 0/260px 200px, radial-gradient(ellipse 90px 70px at 18% 32%, rgba(140,100,50,0.3), transparent 70%), radial-gradient(ellipse 60px 120px at 74% 6%, rgba(130,95,50,0.32), transparent 70%), radial-gradient(ellipse 140px 50px at 46% 100%, rgba(100,80,50,0.28), transparent 70%), linear-gradient(180deg,#d4c4a6,#c0ae8c)';
  const SH_FLOOR = SU('width="240" height="120"><g stroke="#5e4b35" stroke-width="1" opacity="0.55" stroke-linecap="round"><path d="M12 20 l30 6 M100 70 l40 -5 M170 30 l22 8 M40 96 l26 -4"/></g><ellipse cx="120" cy="34" rx="5" ry="3" fill="#6a5238" opacity="0.6"/><ellipse cx="200" cy="88" rx="4" ry="2.4" fill="#6a5238" opacity="0.6"/><path d="M160 60 L178 52 L186 64 L172 76 L158 70z" fill="#2c2117"/><path d="M160 60 L178 52" stroke="#b49a76" stroke-width="1.2"/>') + ' 0 0/240px 120px, radial-gradient(ellipse 120px 40px at 30% 40%, rgba(70,50,30,0.3), transparent 70%), radial-gradient(ellipse 80px 30px at 80% 70%, rgba(70,50,30,0.28), transparent 70%), repeating-linear-gradient(90deg,#9a8263 0 76px,#3d2e20 76px 79px,#8a7254 79px 158px,#3d2e20 158px 161px)';
  const SH_CEIL = 'radial-gradient(ellipse 44px 11px at 20% 100%, rgba(110,80,40,0.5), transparent 70%), radial-gradient(ellipse 30px 13px at 66% 100%, rgba(110,80,40,0.45), transparent 70%), repeating-linear-gradient(90deg,#b1a184 0 60px,#9d8d70 60px 62px)';
  const SH_CLUBW = SU('width="260" height="200">' + CRACKS('#4c4842') + '') + ' 0 0/260px 200px, radial-gradient(ellipse 100px 80px at 25% 40%, rgba(60,50,40,0.3), transparent 70%), radial-gradient(ellipse 70px 120px at 80% 0%, rgba(80,60,40,0.3), transparent 70%), linear-gradient(0deg, #5d5953 2px, transparent 2px) 0 0/62px 26px, linear-gradient(90deg, #5d5953 2px, transparent 2px) 0 0/62px 26px, #8a857d';
  const SH_CLUBF = SU('width="260" height="160"><g fill="none" stroke="#45423e" stroke-width="1.5" stroke-linecap="round"><path d="M20 10 L48 40 L44 70 L70 100"/><path d="M48 40 L80 46"/><path d="M200 60 L180 90 L196 130"/></g><circle cx="140" cy="40" r="10" fill="#5a5650" opacity="0.35"/>') + ' 0 0/260px 160px, radial-gradient(ellipse 120px 50px at 60% 50%, rgba(40,35,30,0.3), transparent 70%), #77736c';
  const SH_YARD = SU('width="200" height="120"><g stroke="#8f8346" stroke-width="1.6" stroke-linecap="round" fill="none"><path d="M20 70 l-4 -10 M22 70 l2 -12 M24 70 l6 -8"/><path d="M140 30 l-3 -8 M142 30 l2 -9 M144 30 l5 -6"/><path d="M90 104 l-4 -9 M92 104 l3 -10"/></g><ellipse cx="60" cy="30" rx="5" ry="3" fill="#7e6e5c"/><ellipse cx="170" cy="90" rx="4" ry="2.6" fill="#7e6e5c"/><ellipse cx="120" cy="70" rx="3" ry="2" fill="#6e6050"/>') + ' 0 0/200px 120px, radial-gradient(ellipse 90px 30px at 20% 30%, rgba(120,140,70,0.35), transparent 70%), radial-gradient(ellipse 70px 26px at 75% 70%, rgba(120,140,70,0.3), transparent 70%), #a2865a';
  const PRICE = lv => lv <= 1 ? 150 : lv * 130;
  const RN = { Original: 'Fresh Paint', None: 'Plain Trim' };
  const P = (sh, L, nm) => [sh].concat(L.map(o => [(o[1] == null && nm) || RN[o[0]] || o[0], o[1], o[2], PRICE(o[2])]));
  const THEMES = {};
  ['living', 'kitchen', 'bath', 'bed'].forEach(r => THEMES[r] = { wall: P(['Cracked Plaster', SH_WALL, 1, 0], W_GEN), floor: P(['Worn Boards', SH_FLOOR, 1, 0], F_GEN, 'New Floor'), ceil: P(['Leaky Ceiling', SH_CEIL, 1, 0], C_GEN) });
  THEMES.dance = { wall: P(['Bare Garage', SH_CLUBW, 1, 0], W_CLUB, 'Club Walls'), floor: P(['Cracked Concrete', SH_CLUBF, 1, 0], F_CLUB, 'Club Floor'), ceil: P(['Leaky Ceiling', SH_CEIL, 1, 0], C_GEN) };
  THEMES.yard = { floor: P(['Dirt Patch', SH_YARD, 1, 0], F_YARD, 'Fresh Grass') };
  const WORN_BG = SU('width="240" height="180"><g fill="#6e4e28" opacity="0.3"><ellipse cx="40" cy="44" rx="22" ry="13"/><ellipse cx="170" cy="120" rx="26" ry="15"/><circle cx="120" cy="30" r="7"/><circle cx="70" cy="150" r="5"/></g><g transform="rotate(-20 150 60)"><rect x="124" y="54" width="54" height="12" fill="#b3aea4"/><path d="M124 54 l3 3 -3 3 3 3 -3 3 M178 54 l-3 3 3 3 -3 3 3 3" stroke="#8a857c" fill="none"/><path d="M128 57 h46" stroke="#e2ded6" stroke-width="1.2"/></g><rect x="28" y="104" width="22" height="18" fill="#c9b48a" stroke="#6a5234" stroke-width="1.2" stroke-dasharray="3 2"/><path d="M214 14 L206 30 L212 40" stroke="#4a3a28" stroke-width="1.3" fill="none"/>') + ' 0 0/240px 180px';
  const WORN_F = 'saturate(0.45) sepia(0.4) brightness(0.88) contrast(0.95)';

  const SONGS = [{ name: 'Squish Groove', track: 'crib_dance' }, { name: 'Disco Fever', track: 'club_disco' }, { name: 'Bubble House', track: 'club_house' }, { name: 'Neon Synth', track: 'club_synth' }, { name: 'Jelly Bounce', track: 'club_bounce' }, { name: 'Turbo Beat', track: 'club_turbo' }];
  const SONGN = [1, 2, 3, 4, 6];
  const FRIDGE_FOODS = ['marshmallow', 'cookie', 'carrot', 'donut', 'salad', 'chocolate', 'pineapple', 'sushi', 'dumpling', 'fish', 'pizza', 'noodles', 'burger'], FOODN = [3, 5, 8, 11, 13];
  const BED_SLEEP = [2, 3, 4, 5, 6];
  const TV_RATE = [0.2, 0.3, 0.45, 0.6, 0.8];
  const BATH = { tub: { mul: 0.7 }, bubble: { mul: 1 }, hottub: { mul: 1.2, energy: 0.2 }, spa: { mul: 1.4, energy: 0.15 }, duck: { mul: 1.6, coins: 0.25 }, shower: { mul: 1.8 }, mud: { mul: 1.3, coins: 0.15 }, sauna: { mul: 1, energy: 0.3 } };

  /* ---------- creature moves unlocked by furniture ---------- */
  const BATH_TIERS = [['soak', 'face'], ['belly', 'splash'], ['shampoo', 'bubbles'], ['back', 'ears', 'mask'], ['duck', 'shake']];
  const BATH_STYLE = { tub: 0, bubble: 1, hottub: 2, spa: 3, duck: 4 };
  const BATH_EXTRA = { shower: ['shampoo', 'shake', 'face'], mud: ['mask', 'splash', 'shake'], sauna: ['sauna', 'soak'] };
  const bathMoves = style => (BATH_EXTRA[style] || [].concat(...BATH_TIERS.slice(0, (BATH_STYLE[style] != null ? BATH_STYLE[style] : tier('tub')) + 1))).map(k => 'bath_' + k);
  const FOOD_RIG = { marshmallow: 'cupcake', cookie: 'cookie', carrot: 'carrot', donut: 'donut', salad: 'apple', chocolate: 'lollipop', pineapple: 'watermelon', sushi: 'sushi', dumpling: 'strawberry', fish: 'fish', pizza: 'pizza', noodles: 'noodles', burger: 'burger' };
  const YARD_MOVES = { none: ['look', 'idle_look'], swing: ['happy', 'idle_waveL', 'idle_waveR'], ball: ['hop', 'spin', 'idle_look'], hop: ['hop', 'hop', 'spin'], tramp: ['hop', 'spin', 'happy'], bubble: ['bath_bubbles', 'happy'], seesaw: ['happy', 'surprised'], sand: ['look', 'happy', 'idle_look'], kite: ['look', 'idle_waveR', 'happy'], slide: ['surprised', 'happy', 'spin'], pit: ['bath_splash', 'happy', 'hop'], pool: ['bath_splash', 'bath_shake', 'happy'], merry: ['spin', 'happy', 'surprised'] };
  SLOTS.forEach(s => s.tiers.forEach((t, i) => { if (s.key === 'tub') t.effect += ' · ' + (BATH_TIERS.slice(0, i + 1).reduce((n, a) => n + a.length, 0)) + ' bath moves'; if (s.key === 'fridge') t.effect += ' · ' + FOODN[i] + ' eating moves'; }));
  EXTRAS.forEach(e => { if (BATH_EXTRA[e.id]) e.effect += ' · ' + BATH_EXTRA[e.id].length + ' bath moves'; });
  GAMES.forEach(g => { const m = YARD_MOVES[g.id]; if (m) g.effect += ' · ' + new Set(m).size + ' play moves'; });

  /* ---------- save data ---------- */
  const KEY = 'squishHome8';
  const ITEM = {};
  SLOTS.forEach(s => s.tiers.forEach(t => ITEM[t.id] = { ...t, kind: 'tier' }));
  EXTRAS.forEach(e => ITEM[e.id] = { ...e, kind: 'extra' });
  GAMES.forEach(g => ITEM['g_' + g.id] = { ...g, id: 'g_' + g.id, game: g.id, room: 'yard', kind: 'game' });
  DECOR.forEach(d => ITEM[d.id] = { ...d, kind: 'decor' });
  function fresh() { const s = { own: {}, eq: {}, pads: { A: 'swing', B: null, C: null, D: 'ball' }, padX: {}, padY: {}, pos: {}, stored: {}, th: {}, song: 0, off: {} }; SLOTS.forEach(sl => { s.own[sl.key + '0'] = true; s.eq[sl.key] = sl.key + '0'; }); s.own.g_swing = true; s.own.g_ball = true; return s; }
  let ST;
  function load() { try { ST = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { ST = null; } if (!ST) { ST = fresh(); try { (JSON.parse(localStorage.getItem('squishDecor') || '[]') || []).forEach(id => { if (ITEM[id]) ST.own[id] = true; }); } catch (e) {} save(); } const f = fresh(); for (const k in f) if (ST[k] == null) ST[k] = f[k]; }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(ST)); } catch (e) {} }
  load();
  const tier = key => { const id = ST.eq[key]; return id ? Number(id.slice(key.length)) || 0 : 0; };

  /* ---------- public helpers ---------- */
  function layout() {
    const sofa = sofaArt(tier('sofa')), tub = tubArt(tier('tub'));
    const bath = tub.seats.slice(); if (ST.own.shower) bath.push(...showerArt().seats); if (ST.own.mud) bath.push(...mudArt().seats); if (ST.own.sauna) bath.push(...saunaArt().seats);
    const f = tier('floor'), cap = [2, 3, 4, 6, 8][f], fw = [200, 280, 360, 460, 552][f], fl = 426 - fw / 2;
    const rows = cap > 4 ? [[262, Math.ceil(cap / 2)], [356, Math.floor(cap / 2)]] : [[320, cap]];
    const dance = []; rows.forEach(([y, n]) => { for (let k = 0; k < n; k++) dance.push({ x: Math.round(fl + fw * (k + 0.5) / n), y }); });
    const yard = []; PADS.forEach(p => { const g = ST.pads[p.k]; if (!g) return; const d = ST.padX[p.k] || 0, e = (ST.padY || {})[p.k] || 0, cx = p.cx + d;
      if (g === 'swing') yard.push({ x: 110 + d, y: 318 + e, dy: e, g: 'swing' }); else if (g === 'tramp') yard.push({ x: 290 + d, y: 322 + e, dy: e, g: 'tramp' }); else if (g === 'seesaw') yard.push({ x: 412 + d, y: 318 + e, dy: e, g: 'seesaw', side: -1 }, { x: 548 + d, y: 318 + e, dy: e, g: 'seesaw', side: 1 }); else if (g === 'ball') yard.push({ x: 660 + d, y: 360 + e, dy: e, g: 'ball', side: 0 }, { x: 800 + d, y: 360 + e, dy: e, g: 'ball', side: 1 });
      else { const a = gameArt(g, cx); if (a) a.spots.forEach(s => yard.push({ x: cx + (s.dx || 0), y: s.y + e, dy: e, g: s.g, side: s.side || 0, cx })); } });
    return { tv: sofa.seats, bath, dance, yard };
  }
  function visuals(room) {
    const back = [], front = [], out = { back, front, flags: {} };
    const put = (arr, a, tf, wn) => { if (a) arr.push({ img: a.img, x: a.x, y: a.y, w: a.w, h: a.h, tf: tf || 'none', worn: !!wn }); }; const W0 = k => tier(k) === 0;
    if (room === 'living') { const s = sofaArt(tier('sofa')); put(back, s.back, 0, W0('sofa')); put(front, s.front, 0, W0('sofa')); put(front, tvBack(tier('tv')), 0, W0('tv')); }
    if (room === 'kitchen') put(back, fridgeArt(tier('fridge')), 0, W0('fridge'));
    if (room === 'bath') { put(front, tubArt(tier('tub')), 0, W0('tub')); if (ST.own.shower) { const a = showerArt(); put(back, a.back); put(front, a.front); } if (ST.own.mud) { const a = mudArt(); put(back, a.back); put(front, a.front); } if (ST.own.sauna) { const a = saunaArt(); put(back, a.back); put(front, a.front); } }
    if (room === 'bed') { const b = bedArt(tier('bed')); [38, 238, 438, 638].forEach(x => { back.push({ img: b.back, x, y: 138, w: 184, h: 170, tf: 'none', worn: W0('bed') }); front.push({ img: b.front, x: x - 2, y: 288, w: 188, h: 42, tf: 'none', worn: W0('bed') }); }); }
    if (room === 'dance') {
      put(back, djArt(tier('dj')), 0, W0('dj'));
      const sp = speakerArt(tier('speakers')); back.push({ img: sp.img, x: 40, y: 222 - sp.h, w: sp.w, h: sp.h, tf: 'none', worn: W0('speakers') }); back.push({ img: sp.img, x: 852 - 40 - sp.w, y: 222 - sp.h, w: sp.w, h: sp.h, tf: 'scaleX(-1)', worn: W0('speakers') });
      const bt = tier('ball'); put(back, ballArt(bt), 0, bt === 0);
      const f = tier('floor'), fw = [200, 280, 360, 460, 552][f], lt = tier('lights');
      out.flags = { floorL: 426 - fw / 2, floorW: fw, classicBall: bt === 1, spots: lt >= 1, beams: lt >= 2, lasers: lt >= 3, show: lt >= 4 };
    }
    if (room === 'yard') { const P = ST.pads; const X = ST.padX; out.flags = { swing: P.A === 'swing', tramp: P.B === 'tramp', seesaw: P.C === 'seesaw', ball: P.D === 'ball', dxA: X.A || 0, dxB: X.B || 0, dxC: X.C || 0, dxD: X.D || 0, dyA: (ST.padY || {}).A || 0, dyB: (ST.padY || {}).B || 0, dyC: (ST.padY || {}).C || 0, dyD: (ST.padY || {}).D || 0 };
      PADS.forEach(p => { const g = ST.pads[p.k]; if (!g || ['swing', 'tramp', 'seesaw', 'ball'].indexOf(g) >= 0) return; const a = gameArt(g, p.cx + (ST.padX[p.k] || 0)); if (!a) return; const e = (ST.padY || {})[p.k] || 0; put(back, { ...a.back, y: a.back.y + e }); if (a.front) put(front, { ...a.front, y: a.front.y + e }); }); }
    back.concat(front).forEach(d => { d.worn = !!d.worn; d.filt = d.worn ? WORN_F : 'none'; d.wornBg = WORN_BG; });
    return out;
  }
  function itemImg(id) {
    const it = ITEM[id]; if (!it) return '';
    if (it.kind === 'decor') return it.img;
    if (it.kind === 'game') { if (it.game === 'swing') return uri(80, 80, '<path d="M10 78 L20 6 H60 L70 78" stroke="#f09ad8" stroke-width="6" fill="none"/><path d="M30 6 V54 M50 6 V54" stroke="' + O + '" stroke-width="2.5"/><rect x="24" y="52" width="32" height="8" rx="4" fill="#ff5cc6"' + S2 + '/>'); if (it.game === 'tramp') return uri(90, 50, '<ellipse cx="45" cy="16" rx="42" ry="12" fill="#5a6f8f" stroke="#7fae6a" stroke-width="5"/><path d="M14 22 V46 M76 22 V46" stroke="#7fae6a" stroke-width="5"/>'); if (it.game === 'seesaw') return uri(100, 50, '<path d="M50 20 L64 48 H36Z" fill="#ff5cc6"' + S25 + '/><rect x="4" y="12" width="92" height="9" rx="4" fill="#f7b6e6"' + S25 + ' transform="rotate(-10 50 16)"/>'); if (it.game === 'ball') return uri(60, 60, '<circle cx="30" cy="30" r="24" fill="#ffd66b"' + S3 + '/><path d="M6 30 H54 M30 6 V54" stroke="#ff5cc6" stroke-width="4"/>'); if (it.game === 'hop') return uri(170, 40, '<rect x="0" y="0" width="170" height="40" rx="8" fill="#a2d482"/>' + [0, 1, 2, 3, 4].map(k => '<rect x="' + (6 + k * 32) + '" y="' + (k % 2 ? 4 : 14) + '" width="28" height="22" rx="3" fill="none" stroke="#fff" stroke-width="3"/>').join('')); const a = gameArt(it.game, 0); return a ? a.back.img : ''; }
    if (it.kind === 'extra') return it.id === 'shower' ? showerArt().back.img : it.id === 'mud' ? mudArt().back.img : saunaArt().back.img;
    const t = it.tier;
    switch (it.slot) { case 'sofa': { const a = sofaArt(t), W = a.back.w; return uri(W + 44, 116, '<image href="' + a.back.img + '" x="22" y="0" width="' + W + '" height="92"/><image href="' + a.front.img + '" x="0" y="34" width="' + (W + 44) + '" height="82"/>'); } case 'tv': return tvArt(t).img; case 'fridge': return fridgeArt(t).img; case 'tub': return tubArt(t).img; case 'bed': return bedArt(t).back; case 'floor': { const fw = [200, 280, 360, 460, 552][t]; return uri(160, 60, '<defs><pattern id="t" width="12" height="12" patternUnits="userSpaceOnUse"><rect width="12" height="12" fill="#ff8fd8"/><rect width="6" height="6" fill="#7ff2d8"/><rect x="6" y="6" width="6" height="6" fill="#9fc8ff"/></pattern></defs><rect x="' + (80 - fw / 7) + '" y="10" width="' + (fw / 3.5) + '" height="40" rx="8" fill="url(#t)" stroke="#8e1580" stroke-width="3"/>'); } case 'dj': return djArt(t).img; case 'speakers': return speakerArt(t).img; case 'ball': return t === 1 ? ballArt(0).img.replace('', '') : ballArt(t).img; case 'lights': return uri(80, 60, t === 0 ? '<circle cx="40" cy="20" r="12" fill="#fff3b0"' + S2 + '/>' : Array.from({ length: t + 1 }, (_, k) => '<path d="M40 4 L' + (8 + k * 64 / Math.max(1, t)) + ' 58" stroke="' + ['#ff5cc6', '#5cf2c8', '#ffd66b', '#7cb8ff', '#c38bff'][k % 5] + '" stroke-width="' + (t >= 3 ? 2 : 6) + '" opacity=".85"/>').join('') + '<circle cx="40" cy="6" r="5" fill="#2a1430"/>'); }
    return '';
  }
  window.SquishHome = {
    ROOMS, SLOTS, EXTRAS, GAMES, PADS, DECOR, THEMES, SONGS, ITEM,
    state: () => ST, save, tier, layout, visuals, itemImg,
    owns: id => !!ST.own[id],
    buy(id) { ST.own[id] = true; const it = ITEM[id]; if (it.kind === 'tier') ST.eq[it.slot] = id; if (it.kind === 'game') { const pad = it.pad ? [it.pad] : ['A', 'B', 'C', 'D']; const free = pad.find(k => !ST.pads[k]); if (free) this.placeGame(free, it.game); } save(); },
    equip(slot, id) { if (ST.own[id]) { ST.eq[slot] = id; save(); } },
    placeGame(pad, game) { if (game) { const g = GAMES.find(x => x.id === game); if (!g || (g.pad && g.pad !== pad) || !ST.own['g_' + game]) return false; for (const k in ST.pads) if (ST.pads[k] === game) ST.pads[k] = null; } ST.pads[pad] = game || null; save(); return true; },
    padX: k => ST.padX[k] || 0,
    padY: k => (ST.padY || {})[k] || 0,
    setPadY(k, d, persist) { ST.padY = ST.padY || {}; ST.padY[k] = d; if (persist) save(); },
    padBox(k) { const g = ST.pads[k]; if (!g) return null; const p = PADS.find(x => x.k === k), d = ST.padX[k] || 0, e = (ST.padY || {})[k] || 0; let b;
      if (g === 'swing') b = { x: 30, y: 186, w: 160, h: 150 }; else if (g === 'tramp') b = { x: 226, y: 306, w: 128, h: 58 }; else if (g === 'seesaw') b = { x: 382, y: 304, w: 196, h: 58 }; else if (g === 'ball') b = { x: 606, y: 340, w: 248, h: 44 };
      else { const a = gameArt(g, p.cx); const fr = a.front; const y0 = a.back.y, y1 = Math.max(a.back.y + a.back.h, fr ? fr.y + fr.h : 0); b = { x: a.back.x - 4, y: y0 - 4, w: a.back.w + 8, h: y1 - y0 + 8 }; }
      return { x: b.x + d, y: b.y + e, w: b.w, h: b.h }; },
    setPadX(k, d, persist) { ST.padX[k] = d; if (persist) save(); },
    decorPos(id) { const d = ITEM[id]; const p = ST.pos[id]; return { x: p ? p.x : d.x, y: p ? p.y : d.y, w: d.w, h: d.h }; },
    setPos(id, x, y) { ST.pos[id] = { x, y }; save(); },
    lightOn: id => !(ST.off || {})[id],
    toggleLight(id) { ST.off = ST.off || {}; ST.off[id] = !ST.off[id]; save(); },
    lights(room) { return DECOR.filter(d => d.light && d.room === room && ST.own[d.id] && !ST.stored[d.id] && !(ST.off || {})[d.id]).map(d => { const p = this.decorPos(d.id); return { x: p.x + d.light.lx, y: p.y + d.light.ly, r: d.light.r, c: d.light.c }; }); },
    toggleStore(id) { ST.stored[id] = !ST.stored[id]; save(); },
    placedDecor(room) { return DECOR.filter(d => d.room === room && ST.own[d.id] && !ST.stored[d.id]); },
    perk(room) { let p = 0; DECOR.forEach(d => { if (d.room === room && ST.own[d.id] && !ST.stored[d.id]) p += d.perk; }); if (room === 'dance') p += DRAIN.speakers[tier('speakers')] + DRAIN.ball[tier('ball')] + DRAIN.lights[tier('lights')]; return p; },
    theme(room) { const T = THEMES[room] || {}, sel = ST.th[room] || {}; const g = k => { const L = T[k]; if (!L) return null; const o = L[sel[k] || 0]; return o ? o[1] : null; }; return { wall: g('wall'), floor: g('floor'), ceil: g('ceil') }; },
    setTheme(room, kind, i) { ST.th[room] = ST.th[room] || {}; ST.th[room][kind] = i; save(); },
    themeIdx(room, kind) { return (ST.th[room] || {})[kind] || 0; },
    themeOwned(room, kind, i) { return !i || !!(ST.tho || {})[room + '.' + kind + '.' + i]; },
    buyTheme(room, kind, i) { ST.tho = ST.tho || {}; ST.tho[room + '.' + kind + '.' + i] = true; ST.th[room] = ST.th[room] || {}; ST.th[room][kind] = i; save(); },
    bathMoves, FOOD_RIG, YARD_MOVES,
    tvRate: () => TV_RATE[tier('tv')],
    fridgeFoods: () => FRIDGE_FOODS.slice(0, FOODN[tier('fridge')]),
    sleepCount: () => BED_SLEEP[tier('bed')],
    bath: style => BATH[style] || BATH.tub,
    songs: () => SONGS.slice(0, SONGN[tier('dj')]),
    song() { const L = this.songs(); return L[Math.min(ST.song || 0, L.length - 1)]; },
    nextSong() { const n = this.songs().length; ST.song = ((ST.song || 0) + 1) % n; save(); },
  };
})();
