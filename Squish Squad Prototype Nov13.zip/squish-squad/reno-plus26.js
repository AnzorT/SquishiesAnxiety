// Renovation Catalog round 26 — Living Room user review fixes (Oct 28):
// remodels: LIV-120 ABC blocks, LIV-050 papasan (tilted bowl = real backrest), LIV-062 alabaster totem, LIV-107 velvet chesterfield (3D deep buttoning, new colours), LIV-088 chronometer (rebuilt);
// fixes: every chesterfield (back slab + back roll now stop between the arms, arms run the full depth -> no more arm/back clash), LIV-111 legs under the apron + water instead of whisky + real rose bouquet,
// LIV-083 no flashy animation; texture: LIV-056 real fruit + more wood texture, LIV-068 ikebana, LIV-100 terrarium; bigger: LIV-007/047/067/087.
// Sets RenoDraw.PLUS26; catalog edits RD.SET26.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS25 && RD.H25 && RD.H24 && RD.H22 && RD.H16 && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS26) return;
  const K = X.K, { solid, ball, box, cyl, arcW, disc, pillowZ, shade, mix, f1 } = K, N = RD.N, PI = Math.PI, GOLD = '#e2b14a', BR = '#d4a548', SA = X.SA, CA = X.CA;
  const { dec, spot, elP, wv, at, ringY } = RD.H24, { glue, R0 } = RD.H22, { rep, rod, pipe, tilt, M_, W_, F_, PL, em, bobA } = RD.H16;
  const { fr2, hatch, wavy, outline, dots, caps, sides, bbS } = RD.H25;
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], mul = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
  const cr = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], nz = a => { const L = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / L, a[1] / L, a[2] / L]; };
  const X3 = [1, 0, 0], Y3 = [0, 1, 0], Z3 = [0, 0, 1];
  const mvPts = (S, f) => { const seen = new Set(), mv = p => { if (seen.has(p)) return; seen.add(p); const q = f(p); p[0] = q[0]; p[1] = q[1]; p[2] = q[2]; }; S.pts.forEach(mv); S.faces.forEach(F => F.q.forEach(mv)); };
  const drop = (o, pred) => { const del = new Set(o.filter(pred)); let g = 1; while (g) { g = 0; o.forEach(S => { if (S.par && del.has(S.par) && !del.has(S)) { del.add(S); g = 1; } }); } for (let i = o.length - 1; i >= 0; i--) if (del.has(o[i])) o.splice(i, 1); };
  const cen = S => { const L = bbS(S); return [(L[0] + L[1]) / 2, (L[2] + L[3]) / 2, (L[4] + L[5]) / 2]; };
  // point + normal on an ellipsoid (centre c, radii a b cz) in direction d
  const eS = (c, a, b, cz) => d => { const u = nz(d); return [add(c, [u[0] * a, u[1] * b, u[2] * cz]), nz([u[0] / a, u[1] / b, u[2] / cz])]; };
  const lineOn = (D, f, m, w, tp) => { const Q = rep(m + 1, i => f(i / m)); D.line(Q.map(q => q[0]), Q.map(q => q[1]), w, tp); };
  const plane = (c, u, v) => (a, b) => add(c, add(mul(u, a), mul(v, b)));
  const WH2 = G => { const xs = G.P.map(q => q[0]), ys = G.P.map(q => q[1]); return [Math.max(...xs) - Math.min(...xs), Math.max(...ys) - Math.min(...ys)]; };
  const nap = (D1, D2, F, R, n) => rep(n, i => { const ph = R() * 6, yy = R() * 0.8 - 0.4, amp = 0.05 + R() * 0.08; wavy(i % 2 ? D2 : D1, F, (t, G) => { const [W, H] = WH2(G); return [-W / 2 + W * t, yy * H + Math.sin(t * 5 + ph) * H * amp]; }, 24, 1.6 + R() * 2, 1); });
  const fleck = (D1, D2, F, R, n, r) => { const G = fr2(F), [W, H] = WH2(G); rep(n, k => { const a = (R() - 0.5) * W * 0.9, b = (R() - 0.5) * H * 0.9, rr = r * (0.6 + R() * 0.8); spot(k % 2 ? D2 : D1, G.at(a, b), G.n, rr, rr * 0.8, R() * 3, 6); }); };
  // grain along the longest edge of a face
  const grainF = (D1, D2, F, R, sp, w) => { const G = fr2(F); let best = 0, th = 0; G.P.forEach((p, i) => { const q = G.P[(i + 1) % G.P.length], L = Math.hypot(q[0] - p[0], q[1] - p[1]); if (L > best) { best = L; th = Math.atan2(q[1] - p[1], q[0] - p[0]); } });
    const dir = [Math.cos(th), Math.sin(th)], m = [-dir[1], dir[0]], E = Math.max(...G.P.map(q => Math.hypot(q[0], q[1]))), n = Math.max(1, Math.floor(2 * E / sp));
    rep(n, k => { const s = -E + (k + 0.5) * sp + (R() - 0.5) * sp * 0.5, ph = R() * 6; wavy(k % 2 ? D2 : D1, F, t => { const u = -E + 2 * E * t, off = s + 0.4 * Math.sin(u * 0.13 + ph); return [dir[0] * u + m[0] * off, dir[1] * u + m[1] * off]; }, 26, (w || 0.25) * (0.7 + R() * 0.6), 1); }); };
  const roots = o => o.filter(S => S && S.pts && S.pts.length && !S.par);

  // ======================= CHESTERFIELD FIX (all chester rows: 107/108/109/110 + clubs) =======================
  // the back slab and its roll ran the full width, through both arms (and the arms started 3 in front of the back) -> the parts were sunk into each other and
  // the layer order flipped with the angle (left arm vs back). Now: back slab + roll stop just inside the arms, arms run the full depth to the back edge.
  { const ch0 = N.chester; N.chester = S => { const D = ch0(S), n = S.n || 3, chn = S.st === 'channel', AW = chn ? 21 : 24, Wd = n * 58 + AW * 2, BZ0 = -47, z0 = BZ0 + 3, ZF = 47, xr = Wd / 2 - AW, kx = (xr - 0.45) / (Wd / 2 - 1), kz = (ZF - BZ0) / (ZF - z0), L0 = D.layers;
    D.layers = L0.map((L, i) => i === 0 ? Object.assign({}, L, { build: P => { const o = L.build(P); roots(o).forEach(S0 => mvPts(S0, p => [p[0] * kx, p[1], p[2]])); return o; } })
      : (i === 1 || i === 3) ? Object.assign({}, L, { build: P => { const o = L.build(P); roots(o).forEach(S0 => mvPts(S0, p => [p[0], p[1], p[2] < ZF ? ZF - (ZF - p[2]) * kz : p[2]])); return o; } }) : L);
    D.geo26 = { n, AW, Wd, xl: -xr, xr, BZ0, BZ1: BZ0 + 18, ZF, RT: 22, ST: 31, CT: 44, TOP: 22 + (chn ? 50 : 46), rollY: 22 + (chn ? 50 : 46) - (chn ? 5 : 6), rB: chn ? 6 : 7.6 };
    return D; }; }

  // ======================= LIV-107 TUFTED VELVET CHESTERFIELD (remodel) =======================
  // real 3D deep buttoning on the inner back and both inner arms (buttons in a diamond grid, dimples, pleat creases between the buttons, puffy diamonds),
  // vertical pleats under the bottom row, brass castors under the walnut bun feet; the flat printed tuft pattern is gone.
  const btn = (c, n, col, r) => ball(c[0], c[1] - r, c[2], r, col, Object.assign({ k: 3, n: 9, mat: 'fab', shine: 0, noOut: 1 }, Math.abs(n[0]) > 0.5 ? { sx: 0.45 } : { sz: 0.45 }));
  const tuftGrid = (on, host, PT, n, a0, a1, b0, b1, F0, pleat) => { const DK = dec(shade(F0, 0.5), { op: 0.6 }), DM = dec(shade(F0, 0.38), { op: 0.55 }), HL = dec(mix(F0, '#ffffff', 0.32), { op: 0.24 }), HL2 = dec(mix(F0, '#ffffff', 0.18), { op: 0.2 });
    const cols = Math.max(2, Math.round((a1 - a0) / 9.2)), rows = Math.max(1, Math.round((b1 - b0) / 7.4)), da = (a1 - a0) / cols, db = (b1 - b0) / rows, G = new Map(), B = [];
    for (let j = 0; j <= rows; j++) for (let i = 0; i <= cols; i++) if ((i + j) % 2 === 0) { const q = [a0 + i * da, b0 + j * db]; G.set(i + ',' + j, q); B.push([q, i, j]); }
    for (let j = 0; j <= rows; j++) for (let i = 0; i <= cols; i++) if ((i + j) % 2 === 1 && i > 0 && i < cols && j > 0 && j < rows) { spot(HL, PT(a0 + i * da - 0.6, b0 + j * db + 0.5), n, da * 0.32, db * 0.26, 0, 10); spot(HL2, PT(a0 + i * da - 0.3, b0 + j * db + 0.3), n, da * 0.5, db * 0.42, 0, 12); }
    B.forEach(([q, i, j]) => { spot(DM, PT(q[0], q[1]), n, 2.5, 2.1, 0, 12); [[1, 1], [1, -1]].forEach(([di, dj]) => { const t = G.get((i + di) + ',' + (j + dj)); if (!t) return; DK.line([PT(q[0], q[1]), PT(t[0], t[1])], n, 0.42); HL.line([PT(q[0] + 0.45, q[1] + 0.4), PT(t[0] + 0.45, t[1] + 0.4)], n, 0.3); });
      if (pleat != null && j === 0) { DK.line([PT(q[0], q[1]), PT(q[0], pleat)], n, 0.36); HL.line([PT(q[0] + 0.5, q[1]), PT(q[0] + 0.5, pleat)], n, 0.25); } });
    on(host, [HL2, HL, DM, DK]); on(host, B.map(([q]) => btn(add(PT(q[0], q[1]), mul(n, 0.2)), n, shade(F0, 0.42), 1.25)), n); const BH = dec(mix(F0, '#ffffff', 0.5), { op: 0.8 }); B.forEach(([q]) => spot(BH, add(PT(q[0] - 0.35, q[1] + 0.35), mul(n, 0.78)), n, 0.4, 0.3, 0, 6)); on(host, [BH]); };
  N.chester26V = S => { const B = N.chester25V2(S), g = N.chester(S).geo26, D = Object.assign({}, B);
    D.layers = B.layers.map((L, i) => Object.assign({}, L, { wrap: (p, s) => s, build: P => { const o = L.build(P), on = glue(o), F0 = (P.c && P.c.a) || P.a, rs = roots(o).map(S0 => ({ S: S0, L: bbS(S0) }));
      if (i === 0) { const bk = rs.find(b => b.S.col === F0 && b.L[3] - b.L[2] > 20); if (bk) tuftGrid(on, bk.S, plane([0, 0, g.BZ1 + 0.05], X3, Y3), Z3, g.xl + 3.5, g.xr - 3.5, g.ST + 4, g.TOP - 9.5, F0, g.ST + 1); }
      if (i === 1 || i === 3) { const sg = i === 1 ? -1 : 1, ab = rs.find(b => b.S.col === F0 && b.L[2] < 30 && b.L[1] - b.L[0] < 30); if (ab) { const x = sg < 0 ? ab.L[1] + 0.05 : ab.L[0] - 0.05; tuftGrid(on, ab.S, plane([x, 0, 0], Z3, Y3), [-sg, 0, 0], g.BZ1 + 3.5, g.ZF - 5, g.CT + 2.5, g.rollY - g.rB - 1.2, F0, null); } }
      return o; } }));
    D.build = P => { const o = B.build(P); o.forEach(S0 => { if (S0.col === '#1d140c') { S0.col = '#c9a24a'; S0.mat = 'metal'; S0.shine = 1; } }); return o; };
    return D; };

  // ======================= LIV-050 VELVET SWIVEL PAPASAN (remodel) =======================
  // the whole rattan bowl is tilted back on its swivel yoke, so its back rises like a real backrest; a deep round velvet cushion sits in the bowl and rises with it,
  // plus a plump head pillow against the high back. Bowl, cushion, rim and pillow are one glued group: the bowl's outer wall is drawn again after the cushion
  // (per-face culled) so from behind the wall covers the cushion, from the front the cushion sits over the rim.
  N.papasan26 = S => ({ w: 88, d: 88, round: 1, act: 'sit', seats: [{ x: 0, z: 6, h: 40 }], build: P => { const V = P.a, RT = '#c99a5a', BK = '#2c2d31', BRs = '#d9a84a', o = [], on = glue(o), R = R0('pp26'), TL = -0.38, PV = [0, 24, 2], T = S0 => tilt(S0, X3, TL, PV);
    o.push(cyl(0, 0, 0, 22, 3, BK, { n: 22, mat: 'metal', rg: [[0, 0, 1], [2, 0, 1], [3, 0, 0.88]] }), cyl(0, 3, 0, 8, 2.4, BRs, { n: 16, mat: 'metal', shine: 1 }), cyl(0, 5.4, 0, 3.4, 9.6, BK, { n: 10, mat: 'metal' }), cyl(0, 15, 2, 13, 4, BRs, { n: 18, mat: 'metal', shine: 1, rg: [[0, 0, 0.8], [2, 0, 1], [4, 0, 0.92]] }));
    { const BB = o[0], ST = dec('#5a5c62', { op: 0.6 }), HL = dec('#ffffff', { op: 0.35 }); [8, 12, 16, 20].forEach((r, k) => ringY(k % 2 ? ST : HL, 0, 0, r, 3.02, 0.2, 40)); on(BB, [ST, HL]); }
    const BW = cyl(0, 23, 2, 38, 22, RT, { n: 30, rz: 34, rg: [[0, 0, 0.32], [8, 0, 0.72], [16, 0, 0.94], [22, 0, 1]], mat: 'wood' }); o.push(BW);
    const OUT = { faces: BW.faces.filter(F => !F.cap).map(F => ({ q: F.q.map(p => p.slice()), n: F.n.slice() })), pts: [], col: RT, cv: 0, zb: 0, mat: 'wood' }; OUT.faces.forEach(F => F.q.forEach(p => OUT.pts.push(p)));
    const W1 = dec(shade(RT, 0.68), { op: 0.6 }), W2 = dec(mix(RT, '#fff1d0', 0.4), { op: 0.55 }), BD = dec(shade(RT, 0.6), { op: 0.8 }), BDh = dec(mix(RT, '#fff1d0', 0.3), { op: 0.5 });
    OUT.faces.forEach(F => { if (!(Math.abs(fr2(F).P.reduce((s, p, i, A) => s + p[0] * A[(i + 1) % A.length][1] - A[(i + 1) % A.length][0] * p[1], 0)) > 4)) return; hatch(W1, F, PI / 4, 1.7, 0.55, { sh: 0.98 }); hatch(W2, F, -PI / 4, 1.7, 0.5, { sh: 0.98, ph: 0.85 }); });
    const prof = y => { const t = (y - 23) / 22; return t < 0.36 ? 0.32 + 0.4 * t / 0.36 : t < 0.73 ? 0.72 + 0.22 * (t - 0.36) / 0.37 : 0.94 + 0.06 * (t - 0.73) / 0.27; };
    [27.5, 31.5, 36, 40.5].forEach(y => { const k = prof(y) * 1.014, Q = rep(61, i => { const a = i / 60 * 2 * PI; return [Math.cos(a) * 38 * k, y, 2 + Math.sin(a) * 34 * k]; }), Nn = rep(61, i => nz([Math.cos(i / 60 * 2 * PI), -0.3, Math.sin(i / 60 * 2 * PI)])); BD.line(Q, Nn, 1.1); BDh.line(Q.map(q => [q[0], q[1] + 0.45, q[2]]), Nn, 0.3); });
    // cushion: thick round velvet pad resting on the rim (equator at rim height, never outside the bowl wall)
    const CU = ball(0, 37.4, 3, 38.6, V, { sy: 0.2, sz: 0.88, k: 6, n: 28, soft: 1, shine: 0, mat: 'fab' }), cc = [0, 37.4 + 7.72, 3], sp = (x, z, k) => { const e = 1 - (x / 38.6) ** 2 - ((z - 3) / 33.97) ** 2, y = cc[1] + 7.72 * Math.sqrt(Math.max(0, e)), n = nz([x / 38.6 / 38.6, (y - cc[1]) / 7.72 / 7.72, (z - 3) / 33.97 / 33.97]); return [add([x, y, z], mul(n, k || 0.1)), n]; };
    const RIM = arcW(0, 43.4, 2, 39.4, 35.4, 2.8, 2.8, 0, 2 * PI, shade(RT, 0.84), { n: 36, mat: 'wood' }), RB1 = dec(shade(RT, 0.55), { op: 0.75 }), RB2 = dec(mix(RT, '#fff1d0', 0.35), { op: 0.5 });
    RIM.faces.forEach(F => { if (Math.abs(fr2(F).P.reduce((s, p, i, A) => s + p[0] * A[(i + 1) % A.length][1] - A[(i + 1) % A.length][0] * p[1], 0)) > 0.6) { hatch(RB1, F, PI / 2.5, 0.9, 0.24, { sh: 0.99 }); hatch(RB2, F, PI / 2.5, 0.9, 0.12, { sh: 0.99, ph: 0.45 }); } });
    const PLW = pillowZ(0, 49, -21, 36, 13, 9, shade(V, 1.08), { mat: 'fab', soft: 1 });
    // cushion texture: velvet nap, 10 radial pleats into a centre button, ring of buttons, piped welt round the edge, sheen
    const D1 = dec(mix(V, '#ffffff', 0.24), { op: 0.22 }), D2 = dec(shade(V, 0.84), { op: 0.2 }), PLT = dec(shade(V, 0.62), { op: 0.6 }), PLL = dec(mix(V, '#ffffff', 0.3), { op: 0.38 }), BTN = dec(shade(V, 0.45)), BTH = dec(mix(V, '#ffffff', 0.45), { op: 0.7 }), WL = dec(shade(V, 0.62), { op: 0.85 }), WH = dec(mix(V, '#ffffff', 0.3), { op: 0.5 }), SH = dec('#ffffff', { op: 0.16 });
    CU.faces.forEach(F => { if (F.n[1] > 0.4 && Math.abs(fr2(F).P.reduce((s, p, i, A) => s + p[0] * A[(i + 1) % A.length][1] - A[(i + 1) % A.length][0] * p[1], 0)) > 40) nap(D1, D2, F, R, 1); });
    rep(10, i => { const a = i / 10 * 2 * PI + 0.15, ex = Math.cos(a) * 33, ez = 3 + Math.sin(a) * 29; lineOn(PLT, t => sp(ex * t, 3 + (ez - 3) * t), 12, 0.55, 1); lineOn(PLL, t => sp(ex * t + 0.9, 3 + (ez - 3) * t + 0.6), 12, 0.3, 1);
      const bx = Math.cos(a + PI / 10) * 18, bz = 3 + Math.sin(a + PI / 10) * 15.8, q = sp(bx, bz, 0.15); spot(BTN, q[0], q[1], 1.2, 1.2, 0, 8); spot(BTH, add(q[0], [-0.3, 0.06, -0.3]), q[1], 0.45, 0.38, 0, 6);
      const q2 = sp(Math.cos(a + PI / 10) * 9, 3 + Math.sin(a + PI / 10) * 7.9, 0.12); spot(SH, q2[0], q2[1], 3.4, 2.4, a, 10); });
    { const q = sp(0, 3, 0.15); spot(BTN, q[0], q[1], 1.8, 1.8, 0, 10); spot(BTH, add(q[0], [-0.4, 0.06, -0.4]), q[1], 0.6, 0.5, 0, 6); }
    { const Q = rep(73, i => { const a = i / 72 * 2 * PI; return [[Math.cos(a) * 38.8, cc[1] + 0.3, 3 + Math.sin(a) * 34.15], nz([Math.cos(a), 0.25, Math.sin(a)])]; }); WL.line(Q.map(q => q[0]), Q.map(q => q[1]), 1.1); WH.line(Q.map(q => add(q[0], [0, 0.5, 0])), Q.map(q => q[1]), 0.3); }
    const E1 = dec(mix(V, '#ffffff', 0.25), { op: 0.22 }), E2 = dec(shade(V, 0.84), { op: 0.18 }), PG = dec(shade(V, 0.6), { op: 0.85 }), CH = dec(shade(V, 0.78), { op: 0.5 });
    PLW.faces.forEach(F => { if (F.cap) { nap(E1, E2, F, R, 2); outline(PG, F, 0.93, 0.6); const G = fr2(F); [-9, -3, 3, 9].forEach(a => CH.line([G.at(a, -5.5), G.at(a, 5.5)], G.n, 0.45, 1)); } });
    const TS = '#e0b34a', ta = PI * 0.74, tx = Math.cos(ta) * 39.9, tz = 2 + Math.sin(ta) * 35.9, TA = [ball(tx, 42.9, tz, 1.3, TS, { k: 3, n: 8, mat: 'fab' }), solid({ ax: 'y', sh: 'el', c: [tx, tz], a: 0.6, b: 0.6, n: 6, rings: [[36.6, 0, 1.8], [40.8, 0, 0.9], [43, 0, 0.5]], col: shade(TS, 0.9), mat: 'fab', noOut: 1 })];
    [OUT, W1, W2, BD, BDh, CU, D1, D2, PLT, PLL, SH, BTN, BTH, WL, WH, RIM, RB1, RB2, PLW, E1, E2, PG, CH].concat(TA).forEach(T); T(BW);
    on(BW, [CU]); on(CU, [D1, D2, SH, PLT, PLL, BTN, BTH, WL, WH]); on(BW, [OUT]); on(OUT, [W1, W2, BD, BDh]); on(BW, [RIM]); on(RIM, [RB1, RB2].concat(TA)); on(BW, [PLW]); on(PLW, [E1, E2, PG, CH]);
    return o; } });

  // ======================= LIV-062 SCULPTURAL ALABASTER TOTEM (remodel) =======================
  // six differently carved alabaster pieces on bronze spacers: a rough-hewn block, a soft disc, a sphere, an octagonal chiselled drum, a flat river pebble and an open bowl shade
  // glowing on top; amber + white veins wrapping round each piece, cloudy inclusions, chisel marks, inner glow breathing piece to piece; square bronze plinth with cord + dimmer.
  N.alab26 = S => { const BRZ = '#6e4a2c', AL = ['#f6dfba', '#fbe9cc', '#f3d4a6', '#fcecd2', '#f7e0bc', '#fbe6c4'];
    const lay = () => { let y = 5.6; const Lr = []; [['blk', 17, 0], ['disc', 7, 1], ['ball', 18, 2], ['drum', 22, 3], ['peb', 8.4, 4], ['bowl', 12, 5]].forEach(([k, h, i]) => { Lr.push({ k, h, i, y }); y += h + (i < 5 ? 2.4 : 0); }); return Lr; };
    return { w: 40, d: 40, round: 1, glow: () => ({ y: 112, r: 80 }), build: () => { const o = [], on = glue(o), R = R0('alab26');
      const PB = box(0, 0, 0, 26, 3.2, 26, BRZ, M_({ r: 2, bev: 0.8 })), PB2 = box(0, 3.2, 0, 18, 2.4, 18, shade(BRZ, 1.1), M_({ r: 2 })); o.push(PB, PB2);
      { const PT = dec('#5f8a72', { op: 0.3 }), BRh = dec('#c9925a', { op: 0.45 }), CD = dec('#2a2a2e'), DM = dec('#f4f2ee'), DK = dec('#9aa1a6'); caps(PB, 2).forEach(F => { fleck(PT, PT, F, R, 30, 0.5); outline(BRh, F, 0.94, 0.3); }); sides(PB, 1).forEach(F => { if (Math.abs(F.n[1]) < 0.3) hatch(BRh, F, 0, 0.8, 0.1, { sh: 0.97 }); });
        CD.line([[13.1, 0.6, 6], [18, 0.4, 9], [24, 0.4, 16]], Y3, 0.6); DM.poly([[17.6, 0.5, 8], [20.4, 0.5, 8], [20.4, 0.5, 10.6], [17.6, 0.5, 10.6]], Y3); spot(DK, [19, 0.56, 9.3], Y3, 0.7, 0.7, 0, 8); on(PB, [PT, BRh, CD, DM, DK]); }
      const Lr = lay(), parts = [];
      Lr.forEach(s => { const c = AL[s.i], y = s.y; let P0;
        if (s.k === 'blk') P0 = box(0.6, y, 0, 19, s.h, 15, c, { r: 3.2, bev: 1.6, yaw: 0.22, mat: 'cer' });
        else if (s.k === 'disc') P0 = cyl(-0.4, y, 0, 11.6, s.h, c, { n: 26, mat: 'cer', rg: [[0, 0, 0.86], [1.4, 0, 0.98], [s.h - 1.4, 0, 1], [s.h, 0, 0.88]] });
        else if (s.k === 'ball') P0 = ball(0.8, y, 0, 9, c, { k: 8, n: 22, mat: 'cer', shine: 0 });
        else if (s.k === 'drum') P0 = cyl(0, y, 0, 6.8, s.h, c, { n: 8, mat: 'cer', yaw: 0.2, rg: [[0, 0, 0.9], [1.2, 0, 1], [s.h - 1.2, 0, 1], [s.h, 0, 0.9]] });
        else if (s.k === 'peb') P0 = ball(-0.6, y, 0.4, 10.6, c, { sy: 0.4, sz: 0.86, k: 6, n: 22, mat: 'cer', shine: 0 });
        else P0 = cyl(0, y, 0, 13, s.h, c, { n: 28, mat: 'cer', rg: [[0, 0, 0.36], [3, 0, 0.62], [7, 0, 0.88], [s.h, 0, 1]] });
        o.push(P0); parts.push(P0);
        if (s.i < 5) o.push(cyl(0, y + s.h, 0, 3.2, 2.4, BRZ, M_({ n: 12, shine: 1, rg: [[0, 0, 1], [0.6, 0, 0.8], [1.8, 0, 0.8], [2.4, 0, 1]] }))); });
      // veins, inclusions, chisel marks, glow cores
      parts.forEach((P0, i) => { const s = Lr[i], VA = dec('#c98a4e', { op: 0.38 }), VW = dec('#ffffff', { op: 0.55 }), CL = dec('#ffffff', { op: 0.42 }), CK = dec('#b0906a', { op: 0.5 }), GC = dec('#ffd9a0', { emit: 1, op: 0.3 });
        P0.faces.forEach(F => { const G = fr2(F), A = Math.abs(G.P.reduce((a, p, j, Q) => a + p[0] * Q[(j + 1) % Q.length][1] - Q[(j + 1) % Q.length][0] * p[1], 0)) / 2; if (A < 3) return;
          if (s.k === 'blk') { const [W, H] = WH2(G), E = Math.max(W, H); rep(Math.min(3, 1 + Math.round(A / 60)), v => { const ph = R() * 6, s = (R() - 0.5) * E * 0.7, th = 0.5 + i * 0.6 + v * 1.1, D0 = v % 2 ? VW : VA; wavy(D0, F, t => { const u = -E + 2 * E * t, w = s + Math.sin(u * 0.35 + ph) * E * 0.1 + Math.sin(u * 0.9 + ph) * 0.3; return [u * Math.cos(th) - w * Math.sin(th), u * Math.sin(th) + w * Math.cos(th)]; }, 26, v % 2 ? 0.4 : 0.26, 1); }); } if (A > 12) fleck(CL, CL, F, R, Math.min(6, Math.round(A / 12)), 0.8);
          if (s.k === 'blk' || s.k === 'drum') rep(Math.min(5, Math.round(A / 20)), () => { const [W, H] = WH2(G), a = (R() - 0.5) * W * 0.8, b = (R() - 0.5) * H * 0.8; CK.line([G.at(a, b), G.at(a + 1.4, b + 0.5)], G.n, 0.22); });
          if (F.n[2] > 0.6 && A > 20) spot(GC, G.at(0, 0), G.n, 2.6, 3.2, 0, 10); });
        if (s.k !== 'blk') { const ip = (Q, y) => { for (let j = 0; j < Q.length - 1; j++) if (y <= Q[j + 1][0]) return Q[j][1] + (Q[j + 1][1] - Q[j][1]) * (y - Q[j][0]) / (Q[j + 1][0] - Q[j][0]); return Q[Q.length - 1][1]; }, h = s.h, y0 = s.y;
          const RF = s.k === 'disc' ? [-0.4, 0, y => 11.6 * ip([[0, 0.86], [1.4, 0.98], [h - 1.4, 1], [h, 0.88]], y - y0), 1] : s.k === 'ball' ? [0.8, 0, y => Math.sqrt(Math.max(0.01, 81 - (y - y0 - 9) ** 2)), 1] : s.k === 'drum' ? [0, 0, () => 6.45, 1] : s.k === 'peb' ? [-0.6, 0.4, y => 10.6 * Math.sqrt(Math.max(0.01, 1 - ((y - y0 - 4.24) / 4.24) ** 2)), 0.86] : [0, 0, y => 13 * ip([[0, 0.36], [3, 0.62], [7, 0.88], [h, 1]], y - y0), 1];
          const sp = (a, y) => { const r = RF[2](y) + 0.06; return [[RF[0] + Math.cos(a) * r, y, RF[1] + Math.sin(a) * r * RF[3]], nz([Math.cos(a), 0.15, Math.sin(a) / RF[3]])]; };
          rep(s.k === 'disc' || s.k === 'peb' ? 2 : 3, v => { const ph = R() * 6, f2 = 1 + Math.floor(R() * 2), D0 = v % 2 ? VW : VA; lineOn(D0, u => { const a = u * 2 * PI, yy = y0 + h * (0.5 + 0.32 * Math.sin(a * f2 + ph) + 0.08 * Math.sin(a * 5 + ph * 2)); return sp(a, Math.max(y0 + 0.4, Math.min(y0 + h - 0.4, yy))); }, 64, v % 2 ? 0.45 : 0.3, 0); });
          rep(2, () => { const a0 = R() * 2 * PI, yy = y0 + h * (0.25 + R() * 0.5); lineOn(CK, u => sp(a0 + u * 0.5, yy + Math.sin(u * 9) * 0.25), 8, 0.14, 1); }); }
        on(P0, [GC, VA, VW, CL, CK]); });
      // glowing inside of the bowl shade
      { const s = Lr[5], BW = parts[5]; on(BW, [cyl(0, s.y + s.h - 0.6, 0, 12.2, 0.3, '#fff1d0', em({ n: 28 }))], Y3); }
      return o; },
      fx: c => { const k = c.k; let f = ''; lay().forEach((s, i) => { const q = c.p(0, s.y + s.h / 2, 0), rx = (s.k === 'drum' ? 6 : s.k === 'ball' ? 8 : 10) * k, ry = s.h * 0.4 * k; f += '<ellipse cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" rx="' + f1(rx) + '" ry="' + f1(ry) + '" fill="url(#q26al)" opacity="0.3"><animate attributeName="opacity" values="0.15;0.6;0.15" dur="4.6s" begin="' + f1(-i * 0.75) + 's" repeatCount="indefinite"/></ellipse>'; });
        const t = c.p(0, 112, 0); f += '<ellipse cx="' + f1(t[0]) + '" cy="' + f1(t[1] - 6 * k) + '" rx="' + f1(16 * k) + '" ry="' + f1(14 * k) + '" fill="url(#q26al)" opacity="0.45"/>';
        return { defs: '<radialGradient id="q26al"><stop offset="0" stop-color="#ffffff" stop-opacity="0.9"/><stop offset="0.45" stop-color="#ffe2b0" stop-opacity="0.5"/><stop offset="1" stop-color="#ffd08a" stop-opacity="0"/></radialGradient>', front: f }; } }; };

  // ======================= LIV-120 CHUNKY ABC BLOCKS (remodel) =======================
  // natural beech toy blocks: every face has a painted border and an embossed letter / number / shape (shadow + highlight), wood grain, chips and dents;
  // a tower of four (two at the bottom, one across them, a small one on top) and two loose blocks on the floor
  const GLY = { A: [[[-0.7, -1], [0, 1], [0.7, -1]], [[-0.38, -0.18], [0.38, -0.18]]], B: [[[-0.6, -1], [-0.6, 1], [0.25, 1], [0.56, 0.76], [0.56, 0.3], [0.25, 0.04], [-0.6, 0.04]], [[0.25, 0.04], [0.66, -0.22], [0.66, -0.74], [0.3, -1], [-0.6, -1]]],
    C: [rep(15, i => { const a = PI * (0.27 + 1.46 * i / 14); return [0.72 * Math.cos(a), Math.sin(a)]; })], D: [[[-0.6, -1], [-0.6, 1], [0.05, 1], [0.5, 0.72], [0.68, 0], [0.5, -0.72], [0.05, -1], [-0.6, -1]]],
    E: [[[0.6, 1], [-0.6, 1], [-0.6, -1], [0.6, -1]], [[-0.6, 0], [0.35, 0]]], F: [[[0.6, 1], [-0.6, 1], [-0.6, -1]], [[-0.6, 0.05], [0.35, 0.05]]],
    1: [[[-0.35, 0.62], [0.08, 1], [0.08, -1]], [[-0.45, -1], [0.55, -1]]], 2: [[[-0.6, 0.55], [-0.35, 0.92], [0.05, 1], [0.45, 0.88], [0.62, 0.5], [0.45, 0.08], [-0.62, -1], [0.66, -1]]],
    3: [[[-0.6, 0.78], [-0.2, 1], [0.3, 1], [0.6, 0.72], [0.5, 0.25], [0, 0.04], [0.52, -0.2], [0.65, -0.62], [0.35, -1], [-0.2, -1], [-0.62, -0.78]]] };
  const SHP = { star: rep(10, i => { const a = PI / 2 + i / 10 * 2 * PI, r = i % 2 ? 0.42 : 1; return [Math.cos(a) * r, Math.sin(a) * r]; }), heart: rep(28, i => { const t = i / 28 * 2 * PI; return [Math.pow(Math.sin(t), 3) * 0.95, (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) / 16 * 0.95 + 0.12]; }) };
  const ABC_ORDER = ['A', 'B', 'C', 'star', 'D', 'E', 'F', 'heart', '1', '2', '3', 'star', 'A', 'B', 'heart', 'C', 'D', '1', 'E', 'star', '2', 'F', '3', 'heart', 'A', 'C', 'B', 'star', 'E', 'D'];
  N.abc26 = S => ({ w: 90, d: 66, act: 'play', use: { x: 56, z: 14 }, build: () => { const o = [], on = glue(o), R = R0('abc26'), WD = '#edcb92', PC = ['#e8504a', '#3f86d6', '#f2b92a', '#4caf62', '#f08a2e', '#8f62cc'];
    const BL = [[-26, 0, -4, 26, 0.1], [5, 0, -6, 26, -0.15], [-10, 26, -5, 26, 0.35], [-10, 52, -5, 16, -0.3], [-14, 0, 24, 18, -0.5], [18, 0, 22, 16, 0.25]];
    let gi = 0;
    BL.forEach(([x, y, z, s, yw], bi) => { const B = box(x, y, z, s, s, s, WD, { r: s * 0.1, bev: s * 0.07, yaw: yw, mat: 'wood' }); o.push(B);
      const cy = Math.cos(yw), sy = Math.sin(yw), LX = [cy, 0, sy], LZ = [-sy, 0, cy], h = s / 2, C = [x, y + h, z];
      const FACES = [[LZ, LX], [mul(LZ, -1), mul(LX, -1)], [LX, mul(LZ, -1)], [mul(LX, -1), LZ]].map(([n, r]) => ({ n, r, u: Y3, c: add(C, mul(n, h)) })).concat([{ n: Y3, r: LX, u: mul(LZ, -1), c: [x, y + s, z] }]);
      const Ds = [];
      FACES.forEach((Fc, fi) => { const P = (a, b) => add(Fc.c, add(mul(Fc.r, a * h), mul(Fc.u, b * h))), col = PC[(bi * 2 + fi) % 6], gc = PC[(bi * 2 + fi + 3) % 6], g = ABC_ORDER[gi++ % ABC_ORDER.length], n = Fc.n;
        const GR = dec(shade(WD, 0.78), { op: 0.45 }), GL = dec(mix(WD, '#ffffff', 0.35), { op: 0.4 }), FR = dec(col), FRh = dec(mix(col, '#ffffff', 0.4), { op: 0.6 }), SHd = dec(shade(gc, 0.55), { op: 0.75 }), GM = dec(gc), GH = dec(mix(gc, '#ffffff', 0.5), { op: 0.7 }), CHp = dec(mix(WD, '#ffffff', 0.5), { op: 0.8 }), DN = dec(shade(WD, 0.6), { op: 0.4 });
        rep(5, k => { const b = -0.8 + k * 0.4 + (R() - 0.5) * 0.12, ph = R() * 6; (k % 2 ? GL : GR).line(rep(9, i => { const a = -0.86 + i * 0.215; return P(a, b + 0.04 * Math.sin(a * 5 + ph)); }), n, h * 0.035, 1); });
        const sq = rep(5, i => [[-1, -1], [1, -1], [1, 1], [-1, 1], [-1, -1]][i]).map(([a, b]) => P(a * 0.74, b * 0.74)); FR.line(sq, n, h * 0.11); FRh.line(sq.map((p, i) => P([[-1, -1], [1, -1], [1, 1], [-1, 1], [-1, -1]][i][0] * 0.66, [[-1, -1], [1, -1], [1, 1], [-1, 1], [-1, -1]][i][1] * 0.66)), n, h * 0.025);
        const gs = 0.44;
        if (SHP[g]) { const Q = SHP[g]; SHd.poly(Q.map(([a, b]) => P(a * gs + 0.05, b * gs - 0.05)), n); GM.poly(Q.map(([a, b]) => P(a * gs, b * gs)), n); GH.line(Q.slice(0, Math.ceil(Q.length / 2)).map(([a, b]) => P(a * gs * 0.8 - 0.02, b * gs * 0.8 + 0.02)), n, h * 0.03); }
        else GLY[g].forEach(L => { SHd.line(L.map(([a, b]) => P(a * gs + 0.05, b * gs - 0.05)), n, h * 0.17); GM.line(L.map(([a, b]) => P(a * gs, b * gs)), n, h * 0.15); GH.line(L.map(([a, b]) => P(a * gs - 0.025, b * gs + 0.03)), n, h * 0.035); });
        rep(2, () => { const e = R() < 0.5 ? -0.9 : 0.9, t = (R() - 0.5) * 1.6; spot(CHp, R() < 0.5 ? P(e, t) : P(t, e), n, h * 0.05, h * 0.035, R() * 3, 6); }); if (R() < 0.5) spot(DN, P((R() - 0.5) * 1.1, (R() - 0.5) * 1.1), n, h * 0.05, h * 0.03, R() * 3, 6);
        Ds.push(GR, GL, FR, FRh, SHd, GM, GH, CHp, DN); });
      on(B, Ds); });
    return o; } });

  // ======================= LIV-088 LEVITATING CHRONOMETER SPHERE & METEORITE (rebuilt) =======================
  // black marble plinth with white veins + brass inlay and plaque; left: brass magnetic pad (glow ring) under a floating navy enamel clock sphere with a white dial
  // and ticking hands, held in three armillary rings that really go round it (back half behind the sphere, front half in front), all bobbing;
  // right: a real iron meteorite (lumpy, thumbprint pits, rust, fusion crust) with a polished cut face showing the silver Widmanstätten crosshatch, on a walnut stand with a brass label.
  const SXc = -11, SYc = 24, SRc = 5.6, MXc = 15;
  const CRG = [{ r: 8.8, e1: X3, e2: Z3, col: '#e2b14a', w: 1.25, tk: 24 }, { r: 8.0, e1: Y3, e2: nz([Math.cos(0.75), 0, Math.sin(0.75)]), col: '#d5dbe0', w: 0.8 }, { r: 10.2, e1: nz([Math.cos(0.3), 0, Math.sin(0.3)]), e2: nz([-Math.sin(0.3) * Math.cos(0.42), Math.sin(0.42), Math.cos(0.3) * Math.cos(0.42)]), col: '#c9932e', w: 0.65, dots: 12 }];
  const ringsSVG = (p, k) => { const o0 = p(0, 0, 0), dep = P => P[1] * SA + (p(P[0], 0, P[2])[1] - o0[1]) * CA / (SA * k), C = [SXc, SYc, 0], dc = dep(C), out = { b: '', f: '' };
    const pth = L => 'M' + L.map(q => f1(q[0]) + ' ' + f1(q[1])).join('L');
    CRG.forEach((Rg, ri) => { const m = 80, P3 = rep(m + 1, i => { const t = i / m * 2 * PI; return add(C, add(mul(Rg.e1, Math.cos(t) * Rg.r), mul(Rg.e2, Math.sin(t) * Rg.r))); });
      const runs = { b: [], f: [] }; let cur = null, kd = null; P3.forEach(P => { const q = p(P[0], P[1], P[2]), kk = dep(P) > dc ? 'f' : 'b'; if (kk !== kd) { if (cur && cur.length > 1) runs[kd].push(cur); cur = cur ? [cur[cur.length - 1]] : []; kd = kk; } cur.push(q); }); if (cur && cur.length > 1) runs[kd].push(cur);
      ['b', 'f'].forEach(s => runs[s].forEach(L => { const d = pth(L), op = s === 'b' ? 0.75 : 1; out[s] += '<path d="' + d + '" fill="none" stroke="#3a2a10" stroke-width="' + f1((Rg.w + 0.55) * k) + '" stroke-linecap="round" opacity="' + op + '"/><path d="' + d + '" fill="none" stroke="' + Rg.col + '" stroke-width="' + f1(Rg.w * k) + '" stroke-linecap="round" opacity="' + op + '"/><path d="' + d + '" fill="none" stroke="#fff6d0" stroke-width="' + f1(Rg.w * 0.28 * k) + '" stroke-linecap="round" opacity="' + op * 0.7 + '"/>'
        + '<path d="' + d + '" fill="none" stroke="#ffffff" stroke-width="' + f1(Rg.w * 0.5 * k) + '" stroke-linecap="round" stroke-dasharray="' + f1(1.4 * k) + ' ' + f1(14 * k) + '" opacity="' + (s === 'f' ? 0.9 : 0.4) + '"><animate attributeName="stroke-dashoffset" values="0;' + f1((ri % 2 ? 1 : -1) * 15.4 * k) + '" dur="' + (2.6 + ri) + 's" repeatCount="indefinite"/></path>'; }));
      const nR = nz(cr(Rg.e1, Rg.e2)); if (Rg.tk) rep(Rg.tk, i => { const t = i / Rg.tk * 2 * PI, P = add(C, add(mul(Rg.e1, Math.cos(t) * Rg.r), mul(Rg.e2, Math.sin(t) * Rg.r))), a = p(...add(P, mul(nR, Rg.w * 0.48))), b = p(...sub(P, mul(nR, Rg.w * 0.48))); out[dep(P) > dc ? 'f' : 'b'] += '<path d="M' + f1(a[0]) + ' ' + f1(a[1]) + 'L' + f1(b[0]) + ' ' + f1(b[1]) + '" stroke="#5a3a0c" stroke-width="' + f1((i % 6 ? 0.18 : 0.36) * k) + '"/>'; });
      if (Rg.dots) rep(Rg.dots, i => { const t = (i + 0.5) / Rg.dots * 2 * PI, P = add(C, add(mul(Rg.e1, Math.cos(t) * Rg.r), mul(Rg.e2, Math.sin(t) * Rg.r))), q = p(...P); out[dep(P) > dc ? 'f' : 'b'] += '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(0.55 * k) + '" fill="#fff1b0" stroke="#7a5a1e" stroke-width="' + f1(0.15 * k) + '"/>'; });
      // pivot pins where the rings meet the equator ring
      if (ri === 1) [0, PI].forEach(t => { const P = add(C, mul(Rg.e2, Math.cos(t) * Rg.r)), q = p(...P); out[dep(P) > dc ? 'f' : 'b'] += '<circle cx="' + f1(q[0]) + '" cy="' + f1(q[1]) + '" r="' + f1(0.8 * k) + '" fill="#f0c24a" stroke="#6a4a12" stroke-width="' + f1(0.2 * k) + '"/>'; }); });
    return out; };
  N.chrono26 = S => { const zf = Math.sqrt(SRc * SRc - 3.6 * 3.6);
    return { w: 62, d: 36, small: 1, topH: 5, build: () => { const o = [], on = glue(o), R = R0('chr26');
        const BS = box(0, 0, 0, 56, 4.4, 28, '#17171b', { r: 2, mat: 'cer', shine: 1, bev: 0.8 }); o.push(BS);
        { const V1 = dec('#e8e6e2', { op: 0.42 }), V2 = dec('#8a8a90', { op: 0.5 }), IN = dec(BR), GL = dec('#ffffff', { op: 0.12 });
          caps(BS, 2).forEach(F => { rep(4, i => { const ph = R() * 6, z0 = -10 + i * 6.5; (i % 2 ? V2 : V1).line(wv(24, t => [-27 + 54 * t, 4.45, z0 + 2.4 * Math.sin(t * 5 + ph) + (t - 0.5) * 5]), Y3, 0.25 + R() * 0.25, 1); }); outline(IN, F, 0.93, 0.32); GL.poly([[-26, 4.46, -6], [-20, 4.46, -13], [-16, 4.46, -13], [-22, 4.46, -6]], Y3); });
          sides(BS, 1).forEach(F => { if (F.n[2] > 0.9) { wavy(V1, F, (t, G) => { const [W] = WH2(G); return [-W / 2 + W * t, Math.sin(t * 7) * 0.8]; }, 30, 0.22, 1); } });
          on(BS, [GL, V1, V2, IN]); const PQ = on(BS, [box(2, 0.9, 14.05, 14, 2.6, 0.34, BR, M_({ r: 0.2, shine: 1 }))], Z3)[0], EN = dec('#5a4214', { op: 0.85 });
          EN.line([[-3.6, 2.8, 14.42], [7.6, 2.8, 14.42]], Z3, 0.32); EN.line([[-2.4, 1.9, 14.42], [6.4, 1.9, 14.42]], Z3, 0.18); [[-4.4, 1.4], [8.4, 1.4], [-4.4, 3.2], [8.4, 3.2]].forEach(([x, y]) => spot(EN, [x, y, 14.42], Z3, 0.22, 0.22, 0, 6)); on(PQ, [EN]); }
        // magnetic pad
        const PD = cyl(SXc, 4.4, 0, 8.6, 1.8, '#c9a24a', M_({ n: 30, shine: 1, rg: [[0, 0, 1], [1.2, 0, 1], [1.8, 0, 0.94]] })); o.push(PD);
        { const TK = dec('#5a3a0c', { op: 0.8 }), HL = dec('#fff6d0', { op: 0.5 }); rep(36, i => { const a = i / 36 * 2 * PI; TK.line([[SXc + Math.cos(a) * 7, 6.22, Math.sin(a) * 7], [SXc + Math.cos(a) * (i % 3 ? 7.7 : 8.2), 6.22, Math.sin(a) * (i % 3 ? 7.7 : 8.2)]], Y3, i % 3 ? 0.14 : 0.24); }); ringY(HL, SXc, 0, 8.3, 6.22, 0.2, 48);
          on(PD, [TK, HL, cyl(SXc, 6.2, 0, 6.2, 0.22, '#6ac8ff', em({ n: 28 }))]); }
        // meteorite stand + meteorite
        const STd = cyl(MXc, 4.4, 0, 7.8, 2.8, '#4a2c18', W_({ n: 24, rg: [[0, 0, 1], [2, 0, 1], [2.8, 0, 0.9]] })); o.push(STd);
        { const G1 = dec('#24160c', { op: 0.55 }), G2 = dec('#7a4e2e', { op: 0.5 }); [1.6, 2.8, 4, 5.2, 6.4].forEach((r, i) => (i % 2 ? G2 : G1).line(wv(30, t => { const a = t * 2 * PI; return [MXc + Math.cos(a) * r * (1 + 0.05 * Math.sin(a * 4 + i)), 7.22, Math.sin(a) * r]; }), Y3, 0.16));
          const LBp = on(STd, [box(MXc, 5, 7.6, 6, 1.6, 0.3, BR, M_({ r: 0.2, shine: 1 }))], Z3)[0], EN = dec('#5a4214', { op: 0.85 }); EN.line([[MXc - 2.4, 6, 7.92], [MXc + 2.4, 6, 7.92]], Z3, 0.2); EN.line([[MXc - 1.6, 5.5, 7.92], [MXc + 1.6, 5.5, 7.92]], Z3, 0.14); on(LBp, [EN]);
          on(STd, [G1, G2, rod([MXc, 7.2, 0], [MXc, 9.6, 0], 0.55, '#9aa3a8', M_({ n: 8 }))]); }
        const MC = [MXc, 8.8 + 6 * 0.82, 0], MT = ball(MXc, 8.8, 0, 6, '#3b393c', { sy: 0.82, k: 6, n: 16, mat: 'metal' }); o.push(MT);
        const LU = [[-2.8, 1.8, 1.2, 4.2], [2.8, 2.4, -1.4, 4], [0.2, 3.4, -0.6, 3.6]].map(([dx, dy, dz, r]) => { const c = add(MC, [dx, dy, dz]), S1 = ball(c[0], c[1] - r * 0.85, c[2], r, '#403e41', { sy: 0.85, k: 5, n: 12, mat: 'metal' }); S1.fn = nz([dx, dy, dz]); return { S: S1, c, r, ry: r * 0.85 }; });
        on(MT, LU.map(l => l.S)); LU.forEach(l => { l.S.fn = nz(sub(l.c, MC)); });
        [{ S: MT, c: MC, r: 6, ry: 6 * 0.82 }].concat(LU).forEach((l, li) => { const f = eS(l.c, l.r, l.ry, l.r), TP = dec('#1f1e21', { op: 0.55 }), TR = dec('#57555a', { op: 0.28 }), RS = dec('#8a4e26', { op: 0.55 }), MG = dec('#e6ebf0', { op: 0.9 }), FC = dec('#2a2629', { op: 0.6 });
          rep(Math.round(l.r * 2.2), () => { const [p0, n0] = f([(R() - 0.5) * 2, 0.1 + R(), (R() - 0.4) * 2]), rr = l.r * (0.12 + R() * 0.1); spot(TP, p0, n0, rr, rr * 0.8, R() * 3, 9); spot(TR, add(p0, mul(n0, -0.01)), n0, rr * 1.35, rr * 1.1, R() * 3, 10); });
          rep(3, () => { const [p0, n0] = f([(R() - 0.5) * 2, R() * 0.8, 0.3 + R()]); spot(RS, p0, n0, 0.4 + R() * 0.5, 0.3 + R() * 0.3, R() * 3, 7); });
          rep(10, () => { const [p0, n0] = f([(R() - 0.5) * 2, (R() - 0.3) * 2, (R() - 0.5) * 2]); spot(FC, p0, n0, 0.25, 0.18, R() * 3, 5); });
          if (li < 2) rep(2, () => { const [p0, n0] = f([-0.5 + (R() - 0.5), 0.7 + R() * 0.4, 0.3 + (R() - 0.5)]); spot(MG, p0, n0, 0.14, 0.09, R() * 3, 5); });
          on(l.S, [TR, TP, RS, FC, MG]); });
        { const nC = nz([0.45, 0.2, 0.87]), u = nz(cr(Y3, nC)), v = cr(nC, u), c0 = add(MC, mul(nC, 4.6)), CF = dec('#a9b0ba'), W1 = dec('#545b66', { op: 0.85 }), W2 = dec('#ffffff', { op: 0.8 }), RM = dec('#5a585e', { op: 0.9 }), GL = dec('#ffffff', { op: 0.6 });
          const Q = rep(22, i => { const a = i / 22 * 2 * PI, rr = 3.7 * (1 + 0.08 * Math.sin(a * 3 + 1) + 0.05 * Math.cos(a * 5)); return add(c0, add(mul(u, Math.cos(a) * rr), mul(v, Math.sin(a) * rr * 0.85))); });
          CF.poly(Q, nC); [0.3, 0.3 + PI / 3, 0.3 + 2 * PI / 3].forEach((a, j) => { hatch(W1, { q: Q, n: nC }, a, 0.95, 0.24, { sh: 0.94, ph: j * 0.3 }); hatch(W2, { q: Q, n: nC }, a, 0.95, 0.14, { sh: 0.94, ph: j * 0.3 + 0.45 }); });
          RM.line(Q.concat([Q[0]]), nC, 0.4); GL.line([add(c0, add(mul(u, -2.6), mul(v, 1.6))), add(c0, add(mul(u, 1.2), mul(v, -2.2)))], nC, 0.5, 1); on(MT, [CF, W1, W2, RM, GL]); }
        return o; },
      layers: [{ build: () => { const o = [], on = glue(o), R = R0('chr26s'), c = [SXc, SYc, 0], SP = ball(SXc, SYc - SRc, 0, SRc, '#1c2b52', { k: 8, n: 22, shine: 1, mat: 'metal' }); o.push(SP);
          const gp = d => { d = nz(d); return [add(c, mul(d, SRc + 0.02)), d]; }, ML = dec('#c9a24a', { op: 0.7 }), STr = dec('#ffffff', { op: 0.9 }), CN = dec('#9fb4e0', { op: 0.5 }), HL = dec('#ffffff', { op: 0.45 });
          rep(6, m => { const ph = m * PI / 6; lineOn(ML, t => gp([Math.sin(t * PI) * Math.cos(ph), Math.cos(t * PI), Math.sin(t * PI) * Math.sin(ph)]), 24, 0.12); }); lineOn(ML, t => gp([Math.cos(t * 2 * PI), 0, Math.sin(t * 2 * PI)]), 40, 0.3);
          const stars = rep(26, () => [(R() - 0.5) * 2, (R() - 0.4) * 2, (R() - 0.5) * 2]); stars.forEach(d => { const [p0, n0] = gp(d); spot(STr, p0, n0, 0.13, 0.13, 0, 5); });
          rep(4, i => { const a = gp(stars[i * 3]), b = gp(stars[i * 3 + 1]); CN.line([a[0], b[0]], [a[1], b[1]], 0.08); }); { const [p0, n0] = gp([-0.5, 0.72, 0.45]); spot(HL, p0, n0, 1.4, 0.8, 0.6, 12); }
          on(SP, [ML, CN, STr, HL]);
          const DL = disc(SXc, SYc, zf, 3.6, 0.3, '#fbf6ea', { n: 24 }), TK = dec('#2a2a30'), BZ = dec('#e2b14a'), zz = zf + 0.31; on(SP, [DL], Z3);
          rep(12, i => { const a = i / 12 * 2 * PI, r0 = i % 3 ? 2.9 : 2.5; TK.line([[SXc + Math.sin(a) * r0, SYc + Math.cos(a) * r0, zz], [SXc + Math.sin(a) * 3.25, SYc + Math.cos(a) * 3.25, zz]], Z3, i % 3 ? 0.16 : 0.32); });
          BZ.line(rep(41, i => { const a = i / 40 * 2 * PI; return [SXc + Math.cos(a) * 3.55, SYc + Math.sin(a) * 3.55, zz]; }), Z3, 0.36); on(DL, [TK, BZ]);
          return o; },
        wrap: (p, s) => { const k = (p(0, 0, 0)[1] - p(0, 1, 0)[1]) / CA, RS = ringsSVG(p, k), O = [SXc, SYc, zf + 0.35], o0 = p(...O); let hd = '';
          if (p(O[0], O[1], O[2] + 1)[1] - o0[1] > 0.002) { const mtx = (a, b) => 'matrix(' + [a[0] - o0[0], a[1] - o0[1], b[0] - o0[0], b[1] - o0[1], o0[0], o0[1]].map(v => Math.round(v * 1e4) / 1e4).join(' ') + ')', M = mtx(p(O[0] + 1, O[1], O[2]), p(O[0], O[1] - 1, O[2]));
            const hand = (L, w, col, d) => '<line x1="0" y1="0.4" x2="0" y2="' + (-L) + '" stroke="' + col + '" stroke-width="' + w + '" stroke-linecap="round"><animateTransform attributeName="transform" type="rotate" values="0;360" dur="' + d + 's" repeatCount="indefinite"/></line>';
            hd = '<g transform="' + M + '">' + hand(1.8, 0.34, '#1f2230', 120) + hand(2.7, 0.22, '#1f2230', 12) + hand(2.9, 0.1, '#c8303a', 3) + '<circle r="0.32" fill="#c9a24a"/></g>'; }
          return '<g>' + bobA(f1(2.2 * k), 3.4) + RS.b + s + hd + RS.f + '</g>'; } }],
      fx: c => { const p = c.p, k = c.k, top = p(SXc, 6.3, 0), q0 = p(SXc - 5.5, 6.3, 0), q1 = p(SXc + 5.5, 6.3, 0), q2 = p(SXc + 3, SYc - SRc - 1, 0), q3 = p(SXc - 3, SYc - SRc - 1, 0);
        let f = '<path d="M' + [q0, q1, q2, q3].map(q => f1(q[0]) + ' ' + f1(q[1])).join('L') + 'Z" fill="url(#q26bm)" opacity="0.5"><animate attributeName="opacity" values="0.25;0.6;0.25" dur="3.4s" repeatCount="indefinite"/></path>';
        rep(2, i => { f += '<ellipse cx="' + f1(top[0]) + '" cy="' + f1(top[1]) + '" rx="' + f1(3 * k) + '" ry="' + f1(3 * k * SA) + '" fill="none" stroke="#9fe6ff" stroke-width="' + f1(0.35 * k) + '" opacity="0"><animate attributeName="rx" values="' + f1(2 * k) + ';' + f1(8 * k) + '" dur="2.4s" begin="' + (-i * 1.2) + 's" repeatCount="indefinite"/><animate attributeName="ry" values="' + f1(2 * k * SA) + ';' + f1(8 * k * SA) + '" dur="2.4s" begin="' + (-i * 1.2) + 's" repeatCount="indefinite"/><animate attributeName="opacity" values="0.8;0" dur="2.4s" begin="' + (-i * 1.2) + 's" repeatCount="indefinite"/></ellipse>'; });
        rep(3, i => { const s = p(MXc + 2 + (i - 1) * 2.4, 12 + i * 1.4, 5.2); f += '<circle cx="' + f1(s[0]) + '" cy="' + f1(s[1]) + '" r="' + f1(0.45 * k) + '" fill="#ffffff" opacity="0"><animate attributeName="opacity" values="0;1;0;0" dur="2.6s" begin="' + (-i * 0.85) + 's" repeatCount="indefinite"/></circle>'; });
        return { defs: '<linearGradient id="q26bm" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#9fe6ff" stop-opacity="0.55"/><stop offset="1" stop-color="#9fe6ff" stop-opacity="0"/></linearGradient>', under: '', front: f }; } }; };

  // ======================= LIV-056 LIVE-EDGE WALNUT: real fruit + more wood texture =======================
  // the three green moss balls are gone: a red apple (stem, leaf, streaks, lenticels), an orange (dimpled peel, navel), a lemon (pointed ends), a green pear and two bananas
  // heaped on the turned bowl (fruit rest on the bowl so the sort stays clean); slab: fine pores, ray flecks, worm holes, end-grain lines on the edge, brushed steel + welds
  const fruitDecor = (D, f, R, n, r0, r1) => rep(n, () => { const [p0, n0] = f([(R() - 0.5) * 2, (R() - 0.2) * 2, (R() - 0.5) * 2]); spot(D, p0, n0, r0 + R() * (r1 - r0), (r0 + R() * (r1 - r0)) * 0.8, R() * 3, 5); });
  const leaf = (c, d, sd, L, W, col) => { const n = nz(cr(d, sd)), Q = rep(14, i => { const t = i / 13; return add(c, add(mul(d, L * t), mul(sd, W * Math.sin(t * PI) * (0.9 + 0.1 * Math.sin(t * 9))))); }).concat(rep(12, i => { const t = 1 - (i + 1) / 13; return add(c, add(mul(d, L * t), mul(sd, -W * Math.sin(t * PI)))); }));
    const A = dec(col), B2 = dec(shade(col, 0.8)), V = dec(mix(col, '#ffffff', 0.35), { op: 0.7 }); A.poly(Q, n); B2.poly(Q.slice().reverse(), mul(n, -1)); V.line([c, add(c, mul(d, L * 0.92))], n, Math.max(0.1, W * 0.12)); rep(3, i => { const t = 0.25 + i * 0.22, b = add(c, mul(d, L * t)); V.line([b, add(b, add(mul(d, L * 0.12), mul(sd, W * 0.6)))], n, 0.08); V.line([b, add(b, add(mul(d, L * 0.12), mul(sd, -W * 0.6)))], n, 0.08); }); return [A, B2, V]; };
  const mkFruit = (o, on, R, kind, x, y0, z, r) => {
    if (kind === 'apple') { const sy = 0.9, A = ball(x, y0, z, r, '#c42f2c', { sy, k: 6, n: 16, mat: 'pl' }), c = [x, y0 + r * sy, z], f = eS(c, r, r * sy, r), ST = dec('#f0b040', { op: 0.35 }), LT = dec('#ffe8b0', { op: 0.7 }), HL = dec('#ffffff', { op: 0.5 }), DP = dec('#6a1a14', { op: 0.6 }); o.push(A);
      rep(12, i => { const a = i / 12 * 2 * PI + R() * 0.2; lineOn(ST, t => f([Math.cos(a) * Math.sin(0.25 + t * 2.4), Math.cos(0.25 + t * 2.4), Math.sin(a) * Math.sin(0.25 + t * 2.4)]), 8, 0.35, 1); });
      fruitDecor(LT, f, R, 14, 0.05, 0.08); { const [p0, n0] = f([-0.5, 0.65, 0.45]); spot(HL, p0, n0, r * 0.32, r * 0.2, 0.6, 10); } spot(DP, [x, c[1] + r * sy - 0.15, z], Y3, r * 0.22, r * 0.22, 0, 10);
      const sT = [x, c[1] + r * sy - 0.2, z]; on(A, [ST, LT, HL, DP, rod(sT, add(sT, [0.4, 1.8, 0.2]), 0.16, '#5a3a1a', { n: 5 })].concat(leaf(add(sT, [0.35, 1.3, 0.15]), nz([0.8, 0.35, 0.3]), nz([-0.3, 0, 0.9]), 2.6, 0.9, '#4f8a2e'))); return A; }
    if (kind === 'orange') { const A = ball(x, y0, z, r, '#f08a1e', { sy: 0.95, k: 6, n: 16, mat: 'pl' }), c = [x, y0 + r * 0.95, z], f = eS(c, r, r * 0.95, r), P1 = dec('#d07214', { op: 0.3 }), P2 = dec('#ffc070', { op: 0.3 }), HL = dec('#ffffff', { op: 0.45 }), NV = dec('#6a7a2a'); o.push(A);
      fruitDecor(P1, f, R, 34, 0.05, 0.08); fruitDecor(P2, f, R, 12, 0.04, 0.06); { const [p0, n0] = f([-0.5, 0.6, 0.5]); spot(HL, p0, n0, r * 0.3, r * 0.18, 0.6, 10); }
      const tp = [x, c[1] + r * 0.95 + 0.02, z]; NV.poly(rep(10, i => { const a = i / 10 * 2 * PI, rr = i % 2 ? 0.25 : 0.6; return add(tp, [Math.cos(a) * rr, 0, Math.sin(a) * rr]); }), Y3); on(A, [P1, P2, HL, NV]); return A; }
    if (kind === 'lemon') { const A = ball(x, y0, z, r, '#f4d43a', { sy: 0.88, sz: 1.22, k: 6, n: 16, mat: 'pl' }), c = [x, y0 + r * 0.88, z], f = eS(c, r, r * 0.88, r * 1.22), P1 = dec('#d8b020', { op: 0.3 }), HL = dec('#ffffff', { op: 0.5 }); o.push(A);
      fruitDecor(P1, f, R, 26, 0.04, 0.07); { const [p0, n0] = f([-0.5, 0.65, 0.4]); spot(HL, p0, n0, r * 0.3, r * 0.2, 0.3, 10); }
      on(A, [P1, HL, ball(x, c[1] - 0.6, z + r * 1.18, 0.75, '#e8c42a', { sz: 1.3, k: 3, n: 8, mat: 'pl', noOut: 1 }), ball(x, c[1] - 0.6, z - r * 1.18, 0.7, '#e8c42a', { sz: 1.3, k: 3, n: 8, mat: 'pl', noOut: 1 })]); return A; }
    if (kind === 'pear') { const A = ball(x, y0, z, r, '#a8c84a', { sy: 0.92, k: 6, n: 16, mat: 'pl' }), c = [x, y0 + r * 0.92, z], f = eS(c, r, r * 0.92, r), SPk = dec('#7a5a2a', { op: 0.35 }), BLs = dec('#d8603a', { op: 0.3 }), HL = dec('#ffffff', { op: 0.45 }); o.push(A);
      const T = ball(x - 0.2, y0 + r * 1.35, z + 0.1, r * 0.62, '#b2cc52', { k: 5, n: 14, mat: 'pl' }), tc = [x - 0.2, y0 + r * 1.35 + r * 0.62, z + 0.1], ft = eS(tc, r * 0.62, r * 0.62, r * 0.62);
      fruitDecor(SPk, f, R, 14, 0.04, 0.07); fruitDecor(SPk, ft, R, 6, 0.04, 0.06); { const [p0, n0] = f([0.6, 0.3, 0.7]); spot(BLs, p0, n0, r * 0.5, r * 0.4, 0.4, 12); const [p1, n1] = f([-0.6, 0.5, 0.5]); spot(HL, p1, n1, r * 0.28, r * 0.18, 0.6, 10); }
      const sT = [tc[0], tc[1] + r * 0.6, tc[2]]; on(A, [SPk, BLs, HL, T]); on(T, [rod(sT, add(sT, [-0.5, 1.8, 0]), 0.17, '#5a3a1a', { n: 5 })]); return A; }
    return null; };
  N.live26 = S => { const B = N.live24(S), D = Object.assign({}, B); D.build = (...a) => { const o = B.build(...a), on = glue(o), R = R0('live26'), TY = 26.4, YT = TY + 4;
    drop(o, S0 => ['#5f9a4a', '#7fb25a', '#4f8a3e'].includes(S0.col) && !S0.par && !S0.emit);
    { const BWl = o.find(S0 => S0.col === '#8a5a34' && !S0.par); if (BWl) { const fam = new Set([BWl]); let g2 = 1; while (g2) { g2 = 0; o.forEach(S0 => { if (S0.par && fam.has(S0.par) && !fam.has(S0)) { fam.add(S0); g2 = 1; } }); } fam.forEach(S0 => mvPts(S0, p => [26 + (p[0] - 26) * 1.22, p[1], -4 + (p[2] + 4) * 1.22])); } }
    const yb = TY + 8.4; [['apple', 22.6, -7.4], ['orange', 29.4, -7.4], ['pear', 22.6, -0.6], ['lemon', 29.4, -0.6]].forEach(([kd, x, z]) => mkFruit(o, on, R, kd, x, yb, z, kd === 'lemon' ? 2.75 : 3.3));
    rep(2, j => { const yc = TY + 15.4 + j * 0.15, zc = -4.6 + j * 0.25, xc = 26 + j * 0.8, rB = 1.3 - j * 0.08, BN = ball(xc, yc, zc, rB, j ? '#f2cf3e' : '#f6d84e', { sx: 4.3, sy: 0.92, k: 5, n: 14, mat: 'pl', shine: 1 }), cb = (x) => (x - xc) * (x - xc);
      mvPts(BN, p => [p[0], p[1] + cb(p[0]) * 0.045, p[2] + cb(p[0]) * 0.02]); o.push(BN); const L = bbS(BN), xe = [L[0] + 0.5, L[1] - 0.5], RGl = dec('#c8a028', { op: 0.55 }), RGh = dec('#fff4b0', { op: 0.6 }), SPk = dec('#7a5a20', { op: 0.45 });
      RGl.line(rep(13, i => { const x = xe[0] + (xe[1] - xe[0]) * i / 12; return [x, yc + rB * 1.82 + cb(x) * 0.045, zc + cb(x) * 0.02 + 0.15]; }), nz([0, 1, 0.3]), 0.18); RGh.line(rep(13, i => { const x = xe[0] + 1 + (xe[1] - xe[0] - 2) * i / 12; return [x, yc + rB * 1.6 + cb(x) * 0.045, zc + cb(x) * 0.02 + rB * 0.6]; }), nz([0, 0.6, 1]), 0.3);
      rep(5, i => { const x = xc - 3.5 + i * 1.8; spot(SPk, [x, yc + rB * 1.4 + cb(x) * 0.045, zc + cb(x) * 0.02 + rB * 0.75], nz([0, 0.5, 1]), 0.18, 0.12, 0, 5); });
      on(BN, [RGl, RGh, SPk, ball(L[0] + 0.2, yc + rB * 0.7 + cb(L[0]) * 0.045 - 0.4, zc + cb(L[0]) * 0.02, 0.5, '#4a3014', { k: 3, n: 6 }), ball(L[1] - 0.3, yc + rB * 0.7 + cb(L[1]) * 0.045 - 0.2, zc + cb(L[1]) * 0.02, 0.45, '#6a4a1a', { sx: 1.6, k: 3, n: 6 })]); });
    o.forEach(S0 => { if (S0.cv === 0 && S0.noOut && (S0.col === '#3a1f0e' || S0.col === '#a06a3c') && S0.op >= 0.45) S0.op = 0.3; });
    // slab top: fine pores, ray flecks, worm holes; end grain + saw lines on the edges; welds + brushing on the steel
    const SW = at(o, [40, TY + 1.5, 0], '#d9b07c'), HW = SW && o.find(S0 => S0.col === '#6e4226' && S0.par === SW);
    if (HW) { const PO = dec('#3a1f0e', { op: 0.28 }), RF = dec('#c08a58', { op: 0.35 }), WH = dec('#1a0c04', { op: 0.85 }), inside = (x, z) => (Math.abs(x) / 52) ** 3 + (Math.abs(z) / 22) ** 2 < 1;
      rep(160, () => { const x = (R() - 0.5) * 104, z = (R() - 0.5) * 44; if (!inside(x, z)) return; PO.line([[x, YT, z], [x + 0.5 + R() * 0.8, YT, z + (R() - 0.5) * 0.1]], Y3, 0.07); });
      rep(26, () => { const x = (R() - 0.5) * 96, z = (R() - 0.5) * 40; if (!inside(x, z)) return; spot(RF, [x, YT, z], Y3, 0.9 + R() * 1.2, 0.18, 0.05, 6); });
      [[-26, 12], [38, -14], [8, 16]].forEach(([x, z]) => spot(WH, [x, YT, z], Y3, 0.32, 0.28, 0, 6)); on(HW, [RF, PO, WH]);
      const ED = dec('#3a1f0e', { op: 0.45 }), EL = dec('#a87448', { op: 0.4 }); HW.faces.forEach(F => { if (Math.abs(F.n[1]) < 0.3) hatch([ED, EL], F, 0, 0.42, 0.1, { sh: 0.98 }); }); on(HW, [ED, EL]); }
    if (SW) { const SD = dec('#a87a48', { op: 0.5 }), SL = dec('#f4dcb0', { op: 0.45 }); SW.faces.forEach(F => { if (Math.abs(F.n[1]) < 0.3) { hatch(SD, F, 0, 0.7, 0.12, { sh: 0.98 }); hatch(SL, F, PI / 2 + 0.2, 2.6, 0.1, { sh: 0.95, ph: 1.1 }); } }); on(SW, [SD, SL]); }
    o.filter(S0 => S0.col === '#232428' && !S0.par && S0.pts).forEach(S0 => { const BRu = dec('#6a6d74', { op: 0.45 }), WLd = dec('#4a4c52', { op: 0.85 }), L = bbS(S0); sides(S0, 1).forEach(F => { if (Math.abs(F.n[1]) < 0.4) hatch(BRu, F, L[3] - L[2] > 10 ? PI / 2 : 0, 0.7, 0.08, { sh: 0.96 }); });
      if (L[3] - L[2] < 3 && L[5] - L[4] > 30) [L[4] + 1.6, L[5] - 1.6].forEach(z => rep(4, i => spot(WLd, [(L[0] + L[1]) / 2 + 1.55, L[2] + 0.6 + i * 0.45, z], X3, 0.4, 0.3, 0, 6))); on(S0, [BRu, WLd]); });
    return o; }; return D; };

  // ======================= LIV-111 GILDED ROCOCO TABLE: legs under the apron, water, rose bouquet =======================
  // the four cabriole legs stood outside the oval apron (they looked detached on the left): moved in under the apron, feet splay out a touch;
  // whisky -> clear water with ice + lemon slices in the decanter and tumblers; the ball roses are replaced by layered roses, buds, serrated leaves and baby's breath
  { const lc0 = N.luxCoffee; N.luxCoffee = S => { const B = lc0(S), D = Object.assign({}, B); D.build = P => { const o = B.build(P), on = glue(o), R = R0('lux26'), WAT = '#cfeaf6';
    o.forEach(S0 => { if (S0.col !== GOLD || !S0.pts) return; const L = bbS(S0), cx = (L[0] + L[1]) / 2, cz = (L[4] + L[5]) / 2;
      if (Math.abs(L[2] - 3) < 0.3 && Math.abs(Math.abs(cx) - 46) < 1 && Math.abs(Math.abs(cz) - 22) < 1) mvPts(S0, p => [p[0] - Math.sign(cx) * 6, p[1], p[2] - Math.sign(cz) * 4.4]);
      else if (L[2] < 0.3 && Math.abs(Math.abs(cx) - 48.8) < 1 && Math.abs(Math.abs(cz) - 24.2) < 1) mvPts(S0, p => [p[0] - Math.sign(cx) * 6.6, p[1], p[2] - Math.sign(cz) * 5]); });
    const liq = o.filter(S0 => S0.col === '#b8692a'); liq.forEach(S0 => { S0.col = WAT; S0.op = 0.55; S0.shine = 1; });
    drop(o, S0 => ['#c8243a', '#f6a8c4', '#fff2f6', '#e94a6a', '#4f8a3a'].includes(S0.col));
    liq.forEach(S0 => { const L = bbS(S0), cx = (L[0] + L[1]) / 2, cz = (L[4] + L[5]) / 2, r = (L[1] - L[0]) / 2, top = L[3], SU = dec('#ffffff', { op: 0.5 }), RI = dec('#9fd0e6', { op: 0.6 });
      spot(SU, [cx - r * 0.3, top + 0.02, cz - r * 0.2], Y3, r * 0.4, r * 0.18, 0.4, 10); ringY(RI, cx, cz, r * 0.92, top + 0.02, 0.18, 24); const ex = [SU, RI];
      if (r < 3) ex.push(box(cx - 0.6, top - 1.1, cz + 0.4, 1.5, 1.5, 1.5, '#eef9ff', { r: 0.3, yaw: 0.5, op: 0.6, mat: 'cer', noOut: 1 }), box(cx + 0.7, top - 0.9, cz - 0.4, 1.3, 1.3, 1.3, '#eef9ff', { r: 0.3, yaw: -0.3, op: 0.6, mat: 'cer', noOut: 1 }), cyl(cx + 0.2, top + 0.05, cz + 0.9, 1.1, 0.25, '#f4d43a', { n: 12, noOut: 1 }));
      on(S0, ex); });
    const VA = o.find(S0 => S0.col === '#f4efe6' || (S0.mat === 'cer' && S0.pts && Math.abs(cen(S0)[0] - 22) < 1 && Math.abs(bbS(S0)[2] - 40.8) < 0.3 && bbS(S0)[3] - bbS(S0)[2] > 10));
    if (VA) { const vx = 22, vz = -4, vy = 54, kids = [];
      // leaves first (they sit under the roses)
      rep(9, i => { const a = i / 9 * 2 * PI + 0.2, d = nz([Math.cos(a), -0.35, Math.sin(a)]), sd = nz(cr(Y3, d)), c = [vx + Math.cos(a) * 2.6, vy + 0.8, vz + Math.sin(a) * 2.6]; kids.push(...leaf(c, d, sd, 5.2, 1.7, i % 2 ? '#3f7a32' : '#4f8a3a')); });
      // baby's breath sprigs
      rep(7, i => { const a = i / 7 * 2 * PI + 0.6, b = [vx + Math.cos(a) * 1.4, vy + 0.5, vz + Math.sin(a) * 1.4], t = [vx + Math.cos(a) * 6.4, vy + 4.6 + (i % 3), vz + Math.sin(a) * 5.4]; kids.push(rod(b, t, 0.1, '#6a8a4a', { n: 4 })); rep(4, j => kids.push(ball(t[0] + (R() - 0.5) * 1.6, t[1] + (R() - 0.3) * 1.2, t[2] + (R() - 0.5) * 1.6, 0.42, '#fbfaf4', { k: 3, n: 6, shine: 0, noOut: 1 }))); });
      // roses (layered petals) + buds, back ones first
      const RO = [[0, 0, 0, 2.5, '#b8182e'], [-3.4, -0.6, -2, 2.1, '#e05070'], [3.2, -0.8, -1.6, 2.1, '#f2a8bc'], [-2.6, -1, 2.6, 2, '#f6c8d4'], [2.8, -0.9, 2.4, 2.2, '#c8243a'], [0.4, 2.2, -3, 1.6, '#e94a6a']].sort((a, b) => a[2] - b[2]);
      RO.forEach(([dx, dy, dz, r, col]) => { const c = [vx + dx, vy + 2.6 + dy, vz + dz], CTR = ball(c[0], c[1] - r * 0.45, c[2], r * 0.55, shade(col, 0.85), { sy: 0.85, k: 4, n: 10, shine: 0 }), PE = [];
        rep(7, i => { const a = i / 7 * 2 * PI + dx, q = [c[0] + Math.cos(a) * r * 0.62, c[1] - r * 0.55, c[2] + Math.sin(a) * r * 0.62]; PE.push(ball(q[0], q[1], q[2], r * 0.5, i % 2 ? col : mix(col, '#ffffff', 0.12), { sy: 0.7, k: 4, n: 9, shine: 0 })); });
        PE.sort((p1, p2) => cen(p1)[2] - cen(p2)[2]); const SPd = dec(shade(col, 0.55), { op: 0.75 }), EDl = dec(mix(col, '#ffffff', 0.4), { op: 0.6 });
        SPd.line(rep(18, i => { const t = i / 17, a = t * 4 * PI, rr = 0.15 + t * r * 0.45; return [c[0] + Math.cos(a) * rr, c[1] + 0.03 + (1 - t) * 0.2, c[2] + Math.sin(a) * rr]; }), Y3, 0.16); EDl.line(rep(18, i => { const t = i / 17, a = t * 4 * PI + 0.4, rr = 0.25 + t * r * 0.45; return [c[0] + Math.cos(a) * rr, c[1] + 0.05 + (1 - t) * 0.2, c[2] + Math.sin(a) * rr]; }), Y3, 0.08);
        kids.push(...PE.filter(p1 => cen(p1)[2] < c[2]), CTR, ...PE.filter(p1 => cen(p1)[2] >= c[2])); on(CTR, [SPd, EDl]); });
      [[4.6, 3.6, -0.6], [-4.4, 4, 0.8]].forEach(([dx, dy, dz]) => { const c = [vx + dx, vy + dy, vz + dz]; kids.push(rod([vx + dx * 0.4, vy + 0.6, vz + dz * 0.4], c, 0.12, '#4f7a32', { n: 4 }), ball(c[0], c[1], c[2], 0.8, '#c8243a', { sy: 1.4, k: 4, n: 8, shine: 0 }), ball(c[0], c[1] - 0.3, c[2], 0.75, '#3f7a32', { sy: 0.6, k: 3, n: 8, shine: 0 })); });
      const RC = o.find(S0 => S0.col === GOLD && S0.pts && Math.abs(bbS(S0)[2] - 52.8) < 0.3 && Math.abs(cen(S0)[0] - 22) < 1); on(RC || VA, kids); }
    return o; }; return D; }; }

  // ======================= LIV-083 LIQUID-METAL CONSOLE: calm =======================
  N.liquid26 = S => Object.assign({}, N.liquid24(S), { fx: undefined });

  // ======================= LIV-068 IKEBANA: retexture =======================
  // plum blossoms become 5-petal flowers with pink centres + stamens, bark lines + lenticels on the branches, veined leaves, camellia petal veins + stamen ring,
  // moss tufts on the kokedama, rust + mica + chipped edges on the slate, sparkle glints on the crystal, brass clasp on the incense box
  const ikeMore = o => { const on = glue(o), R = R0('ike26');
    o.filter(S0 => (S0.col === '#f6c2d0' || S0.col === '#fbe4ea') && S0.par && S0.pts).forEach((S0, i) => { const c = cen(S0); S0.col = '#fff2f5'; const PE = rep(5, j => { const a = j / 5 * 2 * PI + i; return ball(c[0] + Math.cos(a) * 0.85, c[1] - 0.25, c[2] + Math.sin(a) * 0.85, 0.62, j % 2 ? '#fbd0dc' : '#f8bccd', { sy: 0.45, k: 3, n: 8, shine: 0, noOut: 1 }); });
      const ST = dec('#f2c040'), CT = dec('#e86a92'); rep(6, j => { const a = j / 6 * 2 * PI; spot(ST, [c[0] + Math.cos(a) * 0.5, c[1] + 0.45, c[2] + Math.sin(a) * 0.5], Y3, 0.12, 0.12, 0, 5); }); spot(CT, [c[0], c[1] + 0.47, c[2]], Y3, 0.16, 0.16, 0, 6);
      on(S0, PE.sort((p1, p2) => cen(p1)[2] - cen(p2)[2]).concat([CT, ST])); });
    o.filter(S0 => ['#5a4030', '#4a5a2a', '#3f6a2e'].includes(S0.col) && S0.pts && !S0.emit).forEach(S0 => { const BK = dec(shade(S0.col, 0.6), { op: 0.7 }), BL = dec(mix(S0.col, '#ffffff', 0.35), { op: 0.5 }), LN = dec('#d8c8a8', { op: 0.7 });
      sides(S0, 1).forEach((F, j) => { if (F.q.length !== 4) return; const m0 = add(F.q[0], mul(sub(F.q[1], F.q[0]), 0.5)), m1 = add(F.q[3], mul(sub(F.q[2], F.q[3]), 0.5)), L = Math.hypot(...sub(m1, m0)); if (L < 1.2) return;
        (j % 2 ? BL : BK).line([add(m0, mul(sub(m1, m0), 0.1)), add(m0, mul(sub(m1, m0), 0.55)), add(m0, mul(sub(m1, m0), 0.9))], F.n, 0.1); if (j % 3 === 0 && R() < 0.6) spot(LN, add(m0, mul(sub(m1, m0), 0.3 + R() * 0.4)), F.n, 0.16, 0.07, 0, 5); }); on(S0, [BK, BL, LN]); });
    o.filter(S0 => ['#3f7a34', '#5a9a44', '#2f5a2a'].includes(S0.col) && S0.pts).forEach(S0 => { const L = bbS(S0), c = cen(S0), a = (L[1] - L[0]) / 2, b = (L[5] - L[4]) / 2, y = L[3] + 0.02, MR = dec(mix(S0.col, '#ffffff', 0.35), { op: 0.75 }), VN = dec(shade(S0.col, 0.7), { op: 0.6 }), HL = dec('#ffffff', { op: 0.25 }), ax = a > b;
      const P = (u, v) => ax ? [c[0] + u * a, y, c[2] + v * b] : [c[0] + v * a, y, c[2] + u * b]; MR.line([P(-0.9, 0), P(0.9, 0)], Y3, 0.14); rep(4, i => { const u = -0.6 + i * 0.4; [-1, 1].forEach(sg => VN.line([P(u, 0), P(u + 0.25, sg * 0.7)], Y3, 0.07)); }); spot(HL, P(-0.3, -0.3), Y3, Math.max(a, b) * 0.3, Math.min(a, b) * 0.25, 0, 8); on(S0, [VN, MR, HL]); });
    o.filter(S0 => (S0.col === '#d8283e' || S0.col === '#e8344a') && S0.pts).forEach(S0 => { const c = cen(S0), L = bbS(S0), VN = dec('#8a1424', { op: 0.55 }), HL = dec('#ff8a9a', { op: 0.45 }); rep(3, i => { const a = i * 2.1; VN.line([[c[0], L[3] + 0.02, c[2]], [c[0] + Math.cos(a) * 0.9, L[3] + 0.02, c[2] + Math.sin(a) * 0.9]], Y3, 0.07); }); spot(HL, [c[0] - 0.3, L[3] + 0.03, c[2] - 0.2], Y3, 0.4, 0.2, 0.5, 6); on(S0, [VN, HL]); });
    o.filter(S0 => S0.col === '#b81e34' && S0.pts).forEach(S0 => { const c = cen(S0), L = bbS(S0), SM = dec('#f2c230'); rep(10, i => { const a = i / 10 * 2 * PI; spot(SM, [c[0] + Math.cos(a) * 0.95, L[3] + 0.02, c[2] + Math.sin(a) * 0.95], Y3, 0.16, 0.16, 0, 5); }); on(S0, [SM]); });
    const KB = o.find(S0 => S0.col === '#4f7a3a' && !S0.par); if (KB) { const c = cen(KB), T = rep(14, i => { const a = i * 2.4, el = -0.3 + (i % 5) * 0.32, d = nz([Math.cos(a) * Math.cos(el), Math.sin(el) + 0.3, Math.sin(a) * Math.cos(el)]), q = add(c, mul(d, 2.9)); return ball(q[0], q[1] - 0.3, q[2], 0.55, ['#5f9a3e', '#3f6f2e', '#7ab84a'][i % 3], { sy: 0.6, k: 3, n: 7, shine: 0, mat: 'fab', noOut: 1 }); }); T.forEach(S1 => { S1.fn = nz(sub(cen(S1), c)); }); on(KB, T); }
    const TR = o.find(S0 => S0.col === '#2c2f35' && !S0.par); if (TR) { const RS = dec('#a8643a', { op: 0.4 }), MI = dec('#c8d0da', { op: 0.35 }), CH = dec('#5a5f68', { op: 0.9 }); caps(TR, 2).forEach(F => { fleck(RS, RS, F, R, 7, 1.4); fleck(MI, MI, F, R, 14, 0.07); });
      rep(16, i => { const x = -25 + i * 3.3 + R(); CH.line([[x, 1.42, 13.9], [x + 1.2 + R(), 1.42, 13.2 + R() * 0.5]], Y3, 0.22); CH.line([[x, 1.42, -13.9], [x + 1.4, 1.42, -13.3 - R() * 0.4]], Y3, 0.2); }); on(TR, [RS, MI, CH]); }
    const VS = o.find(S0 => S0.col === '#e3f3fa' && !S0.par); if (VS) { const L = bbS(VS), c = cen(VS), SP = dec('#ffffff', { emit: 1, op: 0.95 }); [[-0.4, 0.3], [0.5, -0.2], [0.1, 0.55], [-0.6, -0.4]].forEach(([u, v]) => { const a = PI / 2 + u, y = c[1] + v * (L[3] - L[2]) * 0.4, r = (L[1] - L[0]) / 2 * 0.95, p0 = [c[0] + Math.cos(a) * r, y, c[2] + Math.sin(a) * r], n0 = [Math.cos(a), 0, Math.sin(a)];
      SP.line([add(p0, [0, -0.7, 0]), add(p0, [0, 0.7, 0])], n0, 0.12); SP.line([add(p0, mul(nz(cr(Y3, n0)), -0.6)), add(p0, mul(nz(cr(Y3, n0)), 0.6))], n0, 0.12); }); on(VS, [SP]); }
    const IB = o.find(S0 => S0.col === '#d8b88a' && !S0.par); if (IB) { const L = bbS(IB); on(IB, [box((L[0] + L[1]) / 2, L[2] + 0.7, L[5] + 0.05, 1.6, 1.1, 0.25, BR, M_({ r: 0.15, shine: 1, noOut: 1 }))], Z3); }
    return o; };
  N.ikebana26 = S => { const B = N.ikebana25x(S), D = Object.assign({}, B); D.build = (...a) => ikeMore(B.build(...a)); return D; };

  // ======================= LIV-100 TERRARIUM: more texture =======================
  // moss cushions in four greens, tiny ferns, red toadstools with white spots, pebbles round the pond, lichen on the rocks, vines + roots hanging under the island,
  // water drops falling from the island into the moat (self-watering), sparkle on the moat water
  const terraMore = o => { const on = glue(o), R = R0('ter26'), GRb = o.find(S0 => S0.col === '#5a8f3a' && !S0.par), RK = o.find(S0 => S0.col === '#7a6a5a' && !S0.par), GY = 40.5, GRr = 15.6, gH = (x, z) => GY + GRr * 0.16 * Math.sqrt(Math.max(0, 1 - (x * x + z * z) / (GRr * GRr))) + 0.05;
    const ok = (x, z) => Math.hypot(x - 10.2, z - 5.2) > 4.2 && Math.hypot(x + 9, z - 6.5) > 3.2 && Math.hypot(x, z) > 4 && Math.hypot(x, z) < 14 && !(x < 2 && x > -13 && Math.abs(z - (9 - 11 * (x + 12) / 13)) < 2);
    if (GRb) { const kids = [], pts = []; let tries = 0; while (pts.length < 16 && tries++ < 400) { const a = R() * 2 * PI, r = 4 + R() * 10, x = Math.cos(a) * r, z = Math.sin(a) * r; if (ok(x, z) && pts.every(q => Math.hypot(q[0] - x, q[1] - z) > 2.6)) pts.push([x, z]); }
      pts.sort((a, b) => a[1] - b[1]).forEach(([x, z], i) => { const y = gH(x, z), kd = i % 4;
        if (kd < 2) { const r = 0.8 + R() * 0.6, M = ball(x, y - r * 0.3, z, r, ['#4f8a30', '#6fa83e', '#3f7a2a', '#86b84a'][i % 4], { sy: 0.55, k: 4, n: 10, shine: 0, mat: 'fab', noOut: 1 }), D1 = dec('#a8d070', { op: 0.6 }); dots(D1, caps(M, 2)[0] || M.faces[0], 0.6, 0.12, { sh: 0.8 }); kids.push(M, D1); }
        else if (kd === 2) { const FN = dec('#3f8a34'), FL = dec('#6fb84a', { op: 0.9 }); rep(5, j => { const a = j / 5 * 2 * PI + i, e = [x + Math.cos(a) * 2.2, y + 0.9, z + Math.sin(a) * 2.2]; FN.line([[x, y, z], [x + Math.cos(a) * 1.1, y + 0.8, z + Math.sin(a) * 1.1], e], Y3, 0.12); rep(4, k2 => { const t = 0.3 + k2 * 0.17, b = [x + Math.cos(a) * 2.2 * t, y + 0.9 * Math.min(1, t * 1.6), z + Math.sin(a) * 2.2 * t], sd = [-Math.sin(a), 0, Math.cos(a)]; FL.line([add(b, mul(sd, -0.4)), add(b, mul(sd, 0.4))], Y3, 0.14); }); }); kids.push(FN, FL); }
        else { const h = 1.3 + R() * 0.5, STm = cyl(x, y - 0.1, z, 0.28, h, '#f2ead8', { n: 6, noOut: 1 }), CP = ball(x, y + h - 0.35, z, 0.85, '#d8342a', { sy: 0.55, k: 4, n: 10 }), WD = dec('#ffffff'); rep(5, j => { const a = j * 1.3 + i; spot(WD, [x + Math.cos(a) * 0.45, y + h + 0.12, z + Math.sin(a) * 0.45], nz([Math.cos(a) * 0.5, 1, Math.sin(a) * 0.5]), 0.13, 0.13, 0, 5); }); kids.push(STm, CP, WD); } });
      const PB = rep(12, i => { const a = i / 12 * 2 * PI, x = 10.2 + Math.cos(a) * 3.2, z = 5.2 + Math.sin(a) * 2.4; return ball(x, gH(x, z) - 0.2, z, 0.38 + R() * 0.2, ['#c9c4ba', '#a8a399', '#e2ddd2'][i % 3], { sy: 0.6, k: 3, n: 7, shine: 0, noOut: 1 }); }).sort((a, b) => cen(a)[2] - cen(b)[2]);
      on(GRb, kids.concat(PB)); }
    o.filter(S0 => ['#7a6a5a', '#6a5a4a', '#5a4a3a', '#4e4034'].includes(S0.col) && !S0.par && S0.pts).forEach(S0 => { const L = bbS(S0), c = cen(S0), f = eS(c, (L[1] - L[0]) / 2, (L[3] - L[2]) / 2, (L[5] - L[4]) / 2), LC = dec('#c9d08a', { op: 0.7 }), LY = dec('#e8d890', { op: 0.6 }), CK = dec('#3a2e24', { op: 0.6 });
      rep(10, i => { const [p0, n0] = f([(R() - 0.5) * 2, (R() - 0.5) * 1.6, (R() - 0.5) * 2]); spot(i % 2 ? LC : LY, p0, n0, 0.35 + R() * 0.4, 0.25 + R() * 0.3, R() * 3, 7); });
      rep(4, () => { const d0 = [(R() - 0.5) * 2, (R() - 0.7), (R() - 0.5) * 2]; lineOn(CK, t => f(add(d0, [t * 0.3, t * 0.4, 0])), 4, 0.12); }); on(S0, [LC, LY, CK]); });
    if (RK) { const vines = rep(6, i => { const a = i / 6 * 2 * PI + 0.4, r0 = 9.6, p0 = [Math.cos(a) * r0, 29.6, Math.sin(a) * r0], L = 5 + (i % 3) * 2.2, P3 = [p0, [p0[0] * 1.06, p0[1] - L * 0.5, p0[2] * 1.06], [p0[0] * 1.02 + 0.6, p0[1] - L, p0[2] * 1.02]], VP = pipe(P3, 0.16, '#4f7a32', { n: 4 });
        return VP.concat(rep(3, j => { const q = P3[1 + (j % 2)]; return ball(q[0] + (j - 1) * 0.6, q[1] + 0.6 - j * 0.9, q[2], 0.65, j % 2 ? '#5f9a3e' : '#3f7a2a', { sx: 1.3, sy: 0.4, k: 3, n: 7, shine: 0, noOut: 1 }); })); });
      on(RK, [].concat(...vines)); }
    return o; };
  N.terra26 = S => { const B = N.terra25x(S), D = Object.assign({}, B);
    if (B.layers) D.layers = B.layers.map((L, i) => Object.assign({}, L, { build: (...a) => { const o = L.build(...a); return i === 0 ? terraMore(o) : o; } }));
    const fx0 = B.fx; D.fx = c => { const F = fx0 ? Object.assign({}, fx0(c) || {}) : {}, p = c.p, k = c.k; let f = '';
      rep(3, i => { const a = i * 2.1 + 0.5, x = Math.cos(a) * 9, z = Math.sin(a) * 9, q0 = p(x, 25, z), q1 = p(Math.cos(a) * 13.8, 2.2, Math.sin(a) * 13.8), d = f1(q1[1] - q0[1]), dx = f1(q1[0] - q0[0]);
        f += '<ellipse cx="' + f1(q0[0]) + '" cy="' + f1(q0[1]) + '" rx="' + f1(0.35 * k) + '" ry="' + f1(0.55 * k) + '" fill="#bfe8ff" stroke="#5aa8d8" stroke-width="' + f1(0.12 * k) + '" opacity="0"><animateTransform attributeName="transform" type="translate" values="0 0;' + dx + ' ' + d + '" dur="1.6s" begin="' + f1(-i * 1.1) + 's" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.95;0.95;0" keyTimes="0;0.1;0.9;1" dur="1.6s" begin="' + f1(-i * 1.1) + 's" repeatCount="indefinite"/></ellipse>';
        f += '<ellipse cx="' + f1(q1[0]) + '" cy="' + f1(q1[1]) + '" rx="1" ry="1" fill="none" stroke="#e8fbff" stroke-width="' + f1(0.18 * k) + '" opacity="0"><animate attributeName="rx" values="' + f1(0.3 * k) + ';' + f1(2.4 * k) + '" dur="1.6s" begin="' + f1(-i * 1.1 + 1.5) + 's" repeatCount="indefinite"/><animate attributeName="ry" values="' + f1(0.3 * k * SA) + ';' + f1(2.4 * k * SA) + '" dur="1.6s" begin="' + f1(-i * 1.1 + 1.5) + 's" repeatCount="indefinite"/><animate attributeName="opacity" values="0.9;0" dur="1.6s" begin="' + f1(-i * 1.1 + 1.5) + 's" repeatCount="indefinite"/></ellipse>'; });
      F.front = (F.front || '') + f; return F; };
    return D; };

  // ======================= BOOKCASES: a little bigger =======================
  const big = (src, k) => S => { const D = N[src](S), E = Object.assign({}, D, { zs: (D.zs || 1) * k, w: D.w * k, d: D.d * k }); if (D.use) E.use = Object.assign({}, D.use, { x: D.use.x * k, z: D.use.z * k }); if (D.seats) E.seats = D.seats.map(q => Object.assign({}, q, { x: q.x * k, z: q.z * k, h: q.h * k })); return E; };
  N.cube26 = big('cube23', 1.25); N.arch26 = big('arch23', 1.18); N.lib26 = big('lib23', 1.18); N.arc26 = big('arc23', 1.2);

  // ---------- catalog edits ----------
  RD.SET26 = {
    'LIV-120': { spec: 'abc26', note: 'Chunky beech toy blocks with painted borders and embossed letters, numbers, stars and hearts on every face, a little chipped from play. Four stacked in a wobbly tower and two loose ones on the floor.' },
    'LIV-050': { spec: 'papasan26', colors: [{ n: 'Blush Velvet', c: '#d98c95' }, { n: 'Mustard Velvet', c: '#c99a2e' }, { n: 'Emerald Velvet', c: '#1f6a4c' }, { n: 'Navy Velvet', c: '#2b3f7a' }, { n: 'Rust Velvet', c: '#a8492b' }, { n: 'Ivory Boucl\u00e9', c: '#ece5d6' }], note: 'A papasan on a black and brass swivel base: the woven rattan bowl tilts back so its high back holds you, with binding bands and a wrapped rim. A deep round velvet cushion with pleats running into buttons and a piped edge, a plump channelled head pillow against the back and a gold tassel on the rim.' },
    'LIV-062': { spec: 'alab26', note: 'A sculptural totem of six hand-carved alabaster pieces (a rough block, a soft disc, a sphere, a chiselled drum, a river pebble and an open bowl shade) on bronze spacers over a square bronze plinth. Amber and white veins wrap round every stone and the light glows from inside, breathing from stone to stone.' },
    'LIV-107': { spec: 'chester26V', colors: [{ n: 'Midnight Sapphire Velvet', c: '#22306a' }, { n: 'Oxblood Velvet', c: '#6a1c26' }, { n: 'Deep Emerald Velvet', c: '#145c40' }, { n: 'Plum Velvet', c: '#4e2052' }, { n: 'Old Gold Velvet', c: '#b8862a' }, { n: 'Dusty Rose Velvet', c: '#c98a8e' }, { n: 'Charcoal Velvet', c: '#3a3a40' }],
      note: 'A classic chesterfield in soft velvet with real deep buttoning across the back and inside both arms: buttons in a diamond grid, pleats folding between them and down to the seat. Rolled scroll arms, piped seat cushions, walnut bun feet on brass castors, two velvet pillows with tassels, a knit throw and an open paperback.' },
    'LIV-056': { spec: 'live26', note: 'A thick walnut slab with flowing grain, fine pores and ray flecks round two knots, a resin-filled crack held by bowties and a pale sapwood rim with bark, on brushed black steel frames. A turned bowl heaped with a red apple, an orange, a lemon, a green pear and two bananas, a latte and a book.' },
    'LIV-007': { spec: 'cube26' }, 'LIV-047': { spec: 'arch26' }, 'LIV-067': { spec: 'lib26' }, 'LIV-087': { spec: 'arc26' },
    'LIV-068': { spec: 'ikebana26' },
    'LIV-111': { note: 'A gilded rococo coffee table: an oval white marble top over a gold-leaf apron carved with C-scrolls and bead rows, on fluted cabriole legs. A cut-crystal carafe of water and two tumblers with ice and lemon on a gold tray, a vase of layered roses with buds, leaves and baby\u2019s breath, and a leather book with a gilt title.' },
    'LIV-083': { spec: 'liquid26', live: '', note: 'A mirror-chrome console that looks poured: its legs flow up like liquid metal into the top, reflecting the room, with drips frozen under the edge. A dark glass vase with a dried branch and a chrome droplet on top.' },
    'LIV-088': { spec: 'chrono26', note: 'A black marble plinth with white veins and a brass inlay. On the left a navy enamel clock sphere with a white dial and ticking hands floats over a glowing magnetic pad, held in three brass armillary rings that circle it. On the right a real iron meteorite, pitted and rusty, with a polished cut face showing its silver crystal pattern, on a walnut stand.' },
    'LIV-100': { spec: 'terra26' },
  };
  const edit25 = RD.edit;
  RD.edit = rows => edit25(rows).map(r => RD.SET26[r.id] ? Object.assign({}, r, RD.SET26[r.id]) : r);
  RD.PLUS26 = 1;
})();
