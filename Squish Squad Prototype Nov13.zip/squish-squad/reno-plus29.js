// Renovation Catalog round 29 — Bathroom realism pass: FLOORS (r.f29, same build as the Kitchen floors in plus27) + FLOOR MATS (RUG fx builds like LIV mat20).
// Floors = r.f29: 80 x 56 perspective trapezoid; details laid out in flat floor space (u across, y depth) through RD.H20 W(u, y), creature scale.
// BTH-005 peeling vinyl checker, 025 matte white hex porcelain, 045 river pebble + teak duckboard, 065 heated black basalt + brass drains,
// 085 thermal hydro-massage glass + heated quartz. Mats: 014 soggy cotton, 034 memory-foam pebble rug, 054 diatomite stone, 074 teak + cotton runner,
// 094 heated moss + silk spa carpet. Sets RenoDraw.PLUS29; catalog edits RD.SET29; helpers RD.H29.
(function boot() {
  const RD = window.RenoDraw, X = window.House3D; if (!(RD && RD.PLUS28 && RD.FLX && RD.H27 && RD.H20 && RD.H13 && RD.H10 && RD.H12 && RD.H11 && RD.H15 && RD.H19 && RD.H21 && RD.H14 && RD.N && X && X.K)) { setTimeout(boot, 30); return; } if (RD.PLUS29) return;
  const shade = X.K.shade, PI = Math.PI, H = RD.H10, N = RD.N;
  // H.vis(C, n) is a BOOLEAN (dot > 0.004); vdot = the real dot with the unit view vector, for thresholds
  const vdot = (C, n) => n[0] * C.v[0] + n[1] * C.v[1] + n[2] * C.v[2];
  const { rng, an, at, SPL, f1, n4, rep, cam, P2 } = H;
  const { FL, fblot, slab, top, face, ellP, rrP } = RD.H13;
  const { W, polyW, lineW, crvW, chip } = RD.H20;
  const { quadW, dot, dotD, walk } = RD.H27;
  const TR = 'M14 0H66L80 56H0Z';
  const wk = v => (52 + 28 * v) / 80, gv = t => t * (0.7 + 0.3 * t), K = y => wk(gv(y));
  const pt = p => f1(p[0]) + ' ' + f1(p[1]);
  const KT = k => ` keyTimes="${k}"`;
  const hexW = (u, y, r, a, rot) => polyW(rep(6, i => { const t = (rot || 0) + i * PI / 3; return [u + Math.cos(t) * r, y + Math.sin(t) * r * a]; }));
  const ripple = (u, y, r, T, b, col) => { const p = W(u, y), k = K(y), A = (att, v) => `<animate attributeName="${att}" values="${v}" dur="${T}s" begin="${n4(-b)}s" repeatCount="indefinite"${KT('0;0.15;0.6;1')}/>`;
    return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="0.2" ry="0.1" fill="none" stroke="${col || '#ffffff'}" stroke-width="0.22" opacity="0">${A('rx', `0.2;0.2;${f1(r * k)};${f1(r * k)}`)}${A('ry', `0.1;0.1;${f1(r * k * 0.5)};${f1(r * k * 0.5)}`)}${A('opacity', '0;0.85;0;0')}</ellipse>`; };
  const glint = (u, y, s, T, b) => { const p = W(u, y), k = K(y) * s; return `<path d="M${f1(p[0] - 1.4 * k)} ${f1(p[1])}H${f1(p[0] + 1.4 * k)}M${f1(p[0])} ${f1(p[1] - 0.8 * k)}V${f1(p[1] + 0.8 * k)}" stroke="#ffffff" stroke-width="0.2" stroke-linecap="round" opacity="0">${an('opacity', '0;0;0.95;0', T, -b, KT('0;0.7;0.8;1'))}</path>`; };
  const steamF = (u, y, s, T, b, col) => { const p = W(u, y), k = K(y) * s; return `<g transform="translate(${pt(p)}) scale(${n4(k)})"><ellipse rx="4" ry="1.8" fill="${col || '#ffffff'}" opacity="0" filter="url(#fb2)">${an('opacity', '0;0.22;0', T, -b)}<animateTransform attributeName="transform" type="translate" values="0 0;1 -9" dur="${T}s" begin="${n4(-b)}s" repeatCount="indefinite"/></ellipse></g>`; };

  // ======================= FLOORS =======================
  // BTH-005 PEELING VINYL CHECKERBOARD (T1): tired red + cream vinyl squares flecked like cheap sheet vinyl, grey grout gone dark toward the walls, mildew
  // blooming out of the back corner, three corners curling up off the yellow glue (dark underside + glue strings), one square gone down to the paper backing,
  // a yellowed ring and two rusty bolt caps where the old toilet stood, a rust ring from a can, soap scum, hair, a worn path, heel scuffs, and a slow leak
  // at the back that drips into a little puddle with ripples.
  function fVinyl() { const R = rng('vinyl29b'), NU = 12, NV = 10, gu = 0.0022, gy = 0.0036, RD0 = ['#c8443a', '#bf3d34', '#cf4b40', '#b9382f'], CR = ['#ece0c6', '#e6d8bc', '#efe4cc', '#e1d2b4'];
    const MISS = '3,2', PEEL = { '9,8': 1, '1,6': 3, '7,1': 2 };
    let s = '<rect width="80" height="56" fill="#6a6052"/>', hi = '', lo = '', ov = '', fx = '';
    for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const key = i + ',' + j, u0 = i / NU + gu, u1 = (i + 1) / NU - gu, y0 = j / NV + gy, y1 = (j + 1) / NV - gy, red = (i + j) % 2 === 0;
      if (key === MISS) { ov += `<path d="${quadW(u0 - gu, y0 - gy, u1 + gu, y1 + gy)}" fill="#c4a868"/>` + rep(6, n => `<path d="${lineW(rep(7, q => [u0 + (u1 - u0) * q / 6, y0 + (y1 - y0) * (n + 0.5) / 6 + 0.004 * Math.sin(q * 1.7 + n)]))}" stroke="#94783e" stroke-width="0.3" fill="none"/>`).join('')
          + rep(5, () => `<path d="${chip(R, u0 + (u1 - u0) * (0.15 + R() * 0.7), y0 + (y1 - y0) * (0.15 + R() * 0.7), 0.7 + R() * 0.7, 6)}" fill="#f0e6d0" opacity="0.9"/>`).join('')
          + rep(3, () => `<path d="${chip(R, u0 + (u1 - u0) * (R() < 0.5 ? 0.04 : 0.96), y0 + (y1 - y0) * R(), 0.6, 5)}" fill="${RD0[0]}"/>`).join('')
          + `<path d="${lineW([[u0 - gu, y1 + gy], [u0 - gu, y0 - gy], [u1 + gu, y0 - gy]])}" stroke="#000" stroke-width="0.45" fill="none" opacity="0.4"/>`; continue; }
      const col = shade((red ? RD0 : CR)[(i * 3 + j * 5) % 4], 0.94 + R() * 0.08);
      s += `<path d="${quadW(u0, y0, u1, y1)}" fill="${col}"/>`;
      fx += rep(14, () => dot(u0 + (u1 - u0) * (0.05 + R() * 0.9), y0 + (y1 - y0) * (0.05 + R() * 0.9), 0.1 + R() * 0.22, `fill="${red ? (R() < 0.5 ? '#e87a6a' : '#8a2a22') : (R() < 0.5 ? '#c8b48e' : '#fffaf0')}" opacity="0.75"`)).join('');
      if (!red) fx += rep(2, () => dot(u0 + (u1 - u0) * R(), y0 + (y1 - y0) * R(), 0.6 + R() * 1.4, `fill="#b09a72" opacity="${f1(0.1 + R() * 0.12)}"`)).join('');
      hi += lineW([[u0, y1], [u0, y0], [u1, y0]]); lo += lineW([[u1, y0], [u1, y1], [u0, y1]]);
      if (PEEL[key]) { const c = PEEL[key], cu = c === 1 || c === 2 ? u1 : u0, cy = c >= 2 ? y0 : y1, du = (u1 - u0) * 0.68 * (cu === u1 ? -1 : 1), dy = (y1 - y0) * 0.68 * (cy === y1 ? -1 : 1);
        const A = [cu + du, cy], B = [cu, cy + dy], lift = -0.05, FLP = [A, [cu + du * 0.62, cy + dy * 0.18 + lift * 0.5], [cu + du * 0.25, cy + dy * 0.25 + lift], [cu + du * 0.18, cy + dy * 0.62 + lift * 0.5], B];
        ov += `<path d="${polyW([[cu, cy], A, B])}" fill="#c8ac60"/>` + rep(4, q => `<path d="${lineW([[cu + du * (0.2 + q * 0.18), cy], [cu, cy + dy * (0.2 + q * 0.18)]])}" stroke="#a88a40" stroke-width="0.14" fill="none"/>`).join('')
          + `<path d="${polyW(FLP)}" fill="#3a2a1e" opacity="0.4" filter="url(#fb1)" transform="translate(0.6 0.8)"/><path d="${polyW(FLP)}" fill="#d8c8a8"/>`
          + `<path d="${polyW([FLP[1], FLP[2], FLP[3], [cu + du * 0.4, cy + dy * 0.4 + lift * 0.4]])}" fill="${shade(col, 0.82)}"/><path d="${lineW(FLP)}" stroke="${shade(col, 0.6)}" stroke-width="0.25" fill="none"/>`
          + rep(3, q => `<path d="${lineW([[cu + du * (0.3 + q * 0.12), cy + dy * 0.05], [cu + du * (0.26 + q * 0.12), cy + dy * 0.15 + lift * 0.6]])}" stroke="#e8d088" stroke-width="0.12" opacity="0.8"/>`).join(''); } }
    s += fx + fblot('vinyl29', 22, ['#fff4e0', '#7a5a3a', '#d8c8a8'], 0.18, 6);
    s += `<path d="${hi}" stroke="#ffffff" stroke-width="0.2" fill="none" opacity="0.35"/><path d="${lo}" stroke="#4a4038" stroke-width="0.4" fill="none" opacity="0.75"/>`;
    s += `<path d="${TR}" fill="none" stroke="#3a3228" stroke-width="9" opacity="0.28" filter="url(#fb3)"/>` + '<g filter="url(#fb2)">' + rep(16, () => dot(R() * 0.35, R() * 0.16, 1.4 + R() * 3, `fill="#2a3428" opacity="${f1(0.14 + R() * 0.18)}"`)).join('') + '</g>'
      + rep(80, () => dot(R() * 0.45, R() * 0.24, 0.1 + R() * 0.22, `fill="#1e2620" opacity="${f1(0.35 + R() * 0.45)}"`)).join('');
    s += `<path d="${dotD(0.8, 0.14, 4.2)}" fill="#c8a85a" opacity="0.22" filter="url(#fb1)"/><path d="${dotD(0.8, 0.14, 3.8)}" fill="none" stroke="#a8884a" stroke-width="0.4" opacity="0.55"/><path d="${dotD(0.8, 0.14, 3.4)}" fill="none" stroke="#f4ecd8" stroke-width="0.25" opacity="0.5"/>`
      + [0.745, 0.855].map(u => dot(u, 0.165, 0.9, 'fill="#8a4a1a" opacity="0.3" filter="url(#fb1)"') + `<path d="${dotD(u, 0.16, 0.55)}" fill="#e8e4dc" stroke="#8a4a1a" stroke-width="0.18"/>`).join('');
    s += dot(0.62, 0.34, 1.9, 'fill="none" stroke="#8a4a1a" stroke-width="0.45" opacity="0.55"') + dot(0.62, 0.34, 1.6, 'fill="none" stroke="#a8642e" stroke-width="0.2" opacity="0.4"') + dot(0.22, 0.64, 2.8, 'fill="none" stroke="#ffffff" stroke-width="0.35" opacity="0.3"');
    s += rep(6, () => { const u = 0.15 + R() * 0.7, y = 0.2 + R() * 0.7, P = walk(R, u, y, 0.012, 0.004, 4, 0.01); return `<path d="${crvW(P)}" stroke="${R() < 0.5 ? '#3a2a1a' : '#6a4a2a'}" stroke-width="0.1" fill="none" opacity="0.8"/>`; }).join('');
    const path = crvW([[0.42, 1.06], [0.5, 0.7], [0.64, 0.42], [0.78, 0.2]]);
    s += `<g filter="url(#fb3)"><path d="${path}" stroke="#ffffff" stroke-width="9" fill="none" opacity="0.16"/><path d="${path}" stroke="#5a4a3a" stroke-width="13" fill="none" opacity="0.1"/></g>`;
    s += rep(16, () => { const y = 0.2 + R() * 0.8, u = 0.3 + R() * 0.45, p = W(u, y), k = K(y), l = (1 + R() * 2) * k, a = (R() - 0.5) * 1.4; return `<path d="M${pt(p)}l${f1(l * Math.cos(a))} ${f1(l * Math.sin(a) * 0.5)}" stroke="#2a2420" stroke-width="${f1(0.18 * k)}" stroke-linecap="round" opacity="${f1(0.25 + R() * 0.3)}"/>`; }).join('');
    { const p = W(0.14, 0.02), q = W(0.14, 0.12); s += `<path d="${dotD(0.14, 0.12, 4.4)}" fill="#b8ccd4" opacity="0.35"/><path d="${dotD(0.12, 0.11, 1.8)}" fill="#ffffff" opacity="0.3"/>`
      + `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="0.3" ry="0.45" fill="#d8ecf4" opacity="0"><animate attributeName="cy" values="${f1(p[1])};${f1(p[1])};${f1(q[1])}"${KT('0;0.6;0.75')} dur="3.4s" repeatCount="indefinite"/>${an('opacity', '0;0.9;0.9;0', 3.4, 0, KT('0;0.3;0.74;0.76'))}</ellipse>` + ripple(0.14, 0.12, 3.8, 3.4, 0.8); }
    return FL(s + ov); }

  // BTH-025 HEXAGONAL MATTE WHITE PORCELAIN (T2): small matte white hex tiles, each with a soft bevel (light top-left, shade bottom-right), grey grout
  // darker toward the tub, a black border band and black hex flowers, chips, one replaced tile a shade too white, splash spots by the tub, a round chrome
  // drain with a water film, and soft daylight drifting slowly across.
  function fHex() { const R = rng('hex29b'), r = 0.021, a = 1.55, du = r * 1.5, dyy = r * Math.sqrt(3) * a, WH = ['#f6f5f1', '#f2f1ec', '#f8f7f3', '#efeee8'];
    let s = '<defs><linearGradient id="hx29" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.65"/><stop offset="0.45" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#8a8680" stop-opacity="0.28"/></linearGradient>'
      + '<linearGradient id="hx29k" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5a5a60"/><stop offset="0.5" stop-color="#26262a"/><stop offset="1" stop-color="#121214"/></linearGradient></defs><rect width="80" height="56" fill="#a9a7a0"/>', hex = '', blk = '', bev = '';
    const flower = new Set(); [[8, 4], [24, 6], [16, 13], [34, 12], [6, 17], [26, 19], [40, 4], [42, 18], [32, 22]].forEach(([c, rw]) => { flower.add(c + ',' + rw); [[0, -1], [0, 1], [-1, 0], [1, 0], [-1, c % 2 ? 1 : -1], [1, c % 2 ? 1 : -1]].forEach(([dc, dr]) => flower.add((c + dc) + ',' + (rw + dr))); });
    for (let c = -1; c * du < 1.05; c++) for (let rw = -1; rw * dyy < 1.08; rw++) { const u = c * du, y = rw * dyy + (c % 2 ? dyy / 2 : 0), key = c + ',' + rw, bd = y < 0.04;
      const d = hexW(u, y, r * 0.88, a); if (flower.has(key) || bd) blk += d; else { const col = key === '20,9' ? '#ffffff' : shade(WH[(c * 7 + rw * 3) & 3], 0.97 + R() * 0.04); hex += `<path d="${d}" fill="${col}"/>`; bev += d; } }
    s += hex + `<path d="${bev}" fill="url(#hx29)"/><path d="${blk}" fill="url(#hx29k)"/><path d="${blk}" fill="none" stroke="#000" stroke-width="0.1" opacity="0.5"/>`;
    s += fblot('hex29', 16, ['#e8e6e0', '#ffffff', '#cfcdc6'], 0.2, 7);
    s += `<g filter="url(#fb3)"><path d="${polyW([[-0.02, 0.04], [1.02, 0.04], [1.02, 0.2], [-0.02, 0.2]])}" fill="#7a7466" opacity="0.18"/></g><path d="${TR}" fill="none" stroke="#5a5852" stroke-width="7" opacity="0.2" filter="url(#fb3)"/>`;
    s += rep(8, () => { const u = R(), y = 0.1 + R() * 0.9; return `<path d="${chip(R, u, y, 0.25 + R() * 0.2, 5)}" fill="#a8a6a0" opacity="0.75"/>`; }).join('');
    s += rep(22, () => dot(0.1 + R() * 0.6, 0.05 + R() * 0.2, 0.15 + R() * 0.35, `fill="#ffffff" opacity="${f1(0.4 + R() * 0.4)}"`)).join('') + rep(10, () => dot(0.1 + R() * 0.6, 0.05 + R() * 0.2, 0.3 + R() * 0.5, `fill="none" stroke="#c8c6c0" stroke-width="0.1" opacity="0.6"`)).join('');
    const du0 = 0.62, dy0 = 0.78, p = W(du0, dy0), k = K(dy0);
    s += `<path d="${dotD(du0, dy0, 5.4)}" fill="#c0d4dc" opacity="0.22" filter="url(#fb1)"/><path d="${dotD(du0, dy0, 2.3)}" fill="#e2e6e8" stroke="#6a7076" stroke-width="0.25"/><path d="${dotD(du0, dy0, 1.7)}" fill="#3a3e42"/>`
      + rep(6, i => `<path d="M${f1(p[0] - 1.5 * k)} ${f1(p[1] + (i - 2.5) * 0.36 * k)}H${f1(p[0] + 1.5 * k)}" stroke="#d0d4d8" stroke-width="${f1(0.18 * k)}"/>`).join('') + `<path d="${dotD(du0 - 0.004, dy0 - 0.006, 1.2)}" fill="#ffffff" opacity="0.25"/>` + ripple(du0, dy0, 3.8, 7, 0, '#e8f4f8');
    s += `<g filter="url(#fb3)"><path d="${polyW([[0.1, 0.1], [0.32, 0.1], [0.42, 0.6], [0.16, 0.6]])}" fill="#fffbe8" opacity="0.26"><animateTransform attributeName="transform" type="translate" values="0 0;6 1;0 0" dur="16s" repeatCount="indefinite"/></path></g>`;
    return FL(s); }

  // BTH-045 RIVER PEBBLE & TEAK DUCKBOARD (T3): a packed mosaic of smooth, shaded river pebbles (grey, cream, slate, rust) in dark wet grout, an oiled teak
  // duckboard of slats on battens with little brass screws over the middle, water beads glinting between the stones and a drip off the front slat.
  function fPebble() { const R = rng('peb29'), PC = ['#9a968e', '#b8b2a6', '#7a7670', '#cfc8ba', '#8a7a6a', '#a89a88', '#6e6c6a', '#c8bca8', '#9a7a62'];
    let s = '<defs>' + PC.map((c, i) => `<radialGradient id="pb29${i}" cx="36%" cy="30%" r="72%"><stop offset="0" stop-color="${shade(c, 1.32)}"/><stop offset="0.55" stop-color="${c}"/><stop offset="1" stop-color="${shade(c, 0.66)}"/></radialGradient>`).join('') + '</defs>'
      + '<rect width="80" height="56" fill="#5a544a"/>' + fblot('pebg', 18, ['#46403a', '#6a6256'], 0.4, 6), stones = '';
    const SU = 0.021, SY = 0.026, PL = []; for (let y0 = -0.02; y0 < 1.03; y0 += SY) for (let u0 = -0.02 + (Math.round(y0 / SY) % 2) * SU / 2; u0 < 1.03; u0 += SU) PL.push([u0 + (R() - 0.5) * SU * 0.5, y0 + (R() - 0.5) * SY * 0.5]);
    PL.forEach(([u, y]) => { const rr = 0.0105 + R() * 0.006, rot = R() * PI, el = 0.55 + R() * 0.4, p = W(u, y), k = K(y), rx = rr * 80 * k, ry = rx * el * (0.55 + 0.2 * gv(y)), ci = (R() * PC.length) | 0, tf = `rotate(${f1(rot * 20 - 10)} ${pt(p)})`;
      stones += `<ellipse cx="${f1(p[0] + rx * 0.08)}" cy="${f1(p[1] + ry * 0.3)}" rx="${f1(rx)}" ry="${f1(ry)}" transform="${tf}" fill="#221e1a" opacity="0.55"/><ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(rx)}" ry="${f1(ry)}" transform="${tf}" fill="url(#pb29${ci})"/>`; });
    s += stones + `<path d="${TR}" fill="none" stroke="#2a2620" stroke-width="7" opacity="0.3" filter="url(#fb3)"/>`;
    s += rep(16, i => glint(0.05 + R() * 0.9, 0.1 + R() * 0.85, 0.6, 5 + (i % 4), i * 0.7)).join('');
    const u0 = 0.22, u1 = 0.78, y0 = 0.36, y1 = 0.86, NS = 7, sl = (y1 - y0) / NS;
    s += `<g filter="url(#fb2)"><path d="${quadW(u0 + 0.01, y0 + 0.02, u1 + 0.02, y1 + 0.04)}" fill="#14100c" opacity="0.5"/></g>`;
    [0.08, 0.5, 0.92].forEach(t => { const u = u0 + (u1 - u0) * t; s += `<path d="${quadW(u - 0.012, y0 - 0.005, u + 0.012, y1 + 0.005)}" fill="#4a2e18"/>`; });
    for (let i = 0; i < NS; i++) { const a = y0 + i * sl + sl * 0.12, b = y0 + (i + 1) * sl - sl * 0.12, col = shade(['#b07440', '#a86c3a', '#b87c48', '#a06434'][i % 4], 0.96 + R() * 0.08);
      s += `<path d="${quadW(u0, a, u1, b)}" fill="${col}"/><path d="${lineW([[u0, a], [u1, a]])}" stroke="#f0c088" stroke-width="0.28" opacity="0.75" fill="none"/><path d="${lineW([[u0, b], [u1, b]])}" stroke="#3a2010" stroke-width="0.35" opacity="0.65" fill="none"/>`
        + rep(4, () => { const yy = a + (b - a) * (0.15 + R() * 0.7); return `<path d="${crvW(rep(6, q => [u0 + (u1 - u0) * q / 5, yy + 0.002 * Math.sin(q * 2 + R() * 3)]))}" stroke="#5a3418" stroke-width="0.12" fill="none" opacity="0.55"/>`; }).join('')
        + [0.08, 0.5, 0.92].map(t => dot(u0 + (u1 - u0) * t, (a + b) / 2, 0.28, 'fill="#c9a256" stroke="#7a5a22" stroke-width="0.06"')).join('')
        + `<path d="${polyW([[u0, a], [u0 + 0.008, a], [u0 + 0.008, b], [u0, b]])}" fill="#000" opacity="0.15"/>`; }
    s += `<path d="${polyW([[0.3, y0 + 0.02], [0.44, y0 + 0.02], [0.47, 0.6], [0.32, 0.6]])}" fill="#ffffff" opacity="0.12" filter="url(#fb2)"/>`;
    { const p = W(0.6, y1 - sl * 0.12), q = W(0.6, y1 + 0.03), k = K(y1); s += `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(0.35 * k)}" ry="${f1(0.5 * k)}" fill="#d8ecf4" opacity="0"><animate attributeName="cy" values="${f1(p[1])};${f1(p[1])};${f1(q[1])}"${KT('0;0.7;0.9')} dur="5s" repeatCount="indefinite"/>${an('opacity', '0;0.9;0.9;0', 5, 0, KT('0;0.3;0.88;0.9'))}</ellipse>` + ripple(0.6, y1 + 0.03, 2.4, 5, -4.5, '#e8f4f8'); }
    return FL(s); }

  // BTH-065 HEATED BLACK BASALT SLABS WITH LINEAR BRASS DRAINS (T4): big honed black basalt slabs, each a slightly different black, with a flamed grain,
  // pores and pale mineral flecks, eased edges catching light; two long polished brass slot drains with a moving glint; a water film near the shower drain
  // reflecting warm light with ripples; condensation beads; the heated stone breathes a warm glow and wisps of steam lift off it.
  function fBasalt() { const R = rng('bas29b'), NU = 3, NV = 3, gu = 0.0025, gy = 0.004, BC = ['#2c2c2e', '#262628', '#303032', '#29292c'];
    let s = '<defs><linearGradient id="b29b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f4dc9a"/><stop offset="0.45" stop-color="#c9a256"/><stop offset="1" stop-color="#8a6a2a"/></linearGradient>'
      + '<linearGradient id="b29g" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="20" y2="0"><stop offset="0" stop-color="#fff4c8" stop-opacity="0"/><stop offset="0.5" stop-color="#fff4c8" stop-opacity="0.95"/><stop offset="1" stop-color="#fff4c8" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-30 0;-30 0;100 0" keyTimes="0;0.5;1" dur="8s" repeatCount="indefinite"/></linearGradient>'
      + '<radialGradient id="b29h" cx="50%" cy="60%" r="65%"><stop offset="0" stop-color="#ffb062" stop-opacity="0.16"/><stop offset="1" stop-color="#ffb062" stop-opacity="0"/></radialGradient>'
      + '<linearGradient id="b29s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.07"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.2"/></linearGradient></defs><rect width="80" height="56" fill="#111113"/>';
    for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const u0 = i / NU + gu, u1 = (i + 1) / NU - gu, y0 = j / NV + gy, y1 = (j + 1) / NV - gy, col = shade(BC[(i + j * 2) & 3], 0.95 + R() * 0.12);
      s += `<path d="${quadW(u0, y0, u1, y1)}" fill="${col}"/><path d="${quadW(u0, y0, u1, y1)}" fill="url(#b29s)"/>`;
      const ang = (R() - 0.5) * 0.3; let gr = '';
      rep(46, () => { const u = u0 + (u1 - u0) * R(), y = y0 + (y1 - y0) * R(), L = 0.02 + R() * 0.05; gr += lineW([[u, y], [u + L, y + L * ang + (R() - 0.5) * 0.01]]); });
      s += `<path d="${gr}" stroke="#4a4a50" stroke-width="0.14" fill="none" opacity="0.45"/>` + rep(120, () => dot(u0 + (u1 - u0) * R(), y0 + (y1 - y0) * R(), 0.05 + R() * 0.12, `fill="${R() < 0.65 ? '#0c0c0e' : '#5a5a60'}" opacity="${f1(0.5 + R() * 0.4)}"`)).join('')
        + rep(10, () => dot(u0 + (u1 - u0) * R(), y0 + (y1 - y0) * R(), 0.06 + R() * 0.08, 'fill="#d8d4cc" opacity="0.6"')).join('')
        + `<path d="${lineW([[u0, y1], [u0, y0], [u1, y0]])}" stroke="#6a6a70" stroke-width="0.2" fill="none" opacity="0.7"/><path d="${lineW([[u1, y0], [u1, y1], [u0, y1]])}" stroke="#000" stroke-width="0.25" fill="none" opacity="0.6"/>`; }
    const drain = (ua, ub, y, h) => { let d = `<path d="${quadW(ua - 0.004, y - h - 0.006, ub + 0.004, y + h + 0.006)}" fill="#000" opacity="0.5"/><path d="${quadW(ua, y - h, ub, y + h)}" fill="url(#b29b)"/><path d="${quadW(ua + 0.006, y - h * 0.45, ub - 0.006, y + h * 0.45)}" fill="#1a140c"/>`;
      const n = Math.round((ub - ua) / 0.012); for (let i = 0; i < n; i++) { const u = ua + 0.008 + i * (ub - ua - 0.016) / n; d += `<path d="${quadW(u, y - h * 0.3, u + 0.006, y + h * 0.3)}" fill="#c9a256" opacity="0.9"/>`; }
      return d + `<path d="${lineW([[ua, y - h], [ub, y - h]])}" stroke="#fff0c0" stroke-width="0.2" fill="none" opacity="0.8"/><path d="${lineW([[ua, y - h], [ub, y - h]])}" stroke="url(#b29g)" stroke-width="0.7" fill="none"/>`; };
    s += drain(0.04, 0.96, 0.07, 0.012) + drain(0.06, 0.64, 0.58, 0.016);
    s += `<g filter="url(#fb2)"><path d="${polyW([[0.08, 0.42], [0.6, 0.42], [0.62, 0.56], [0.06, 0.56]])}" fill="#3a3a42" opacity="0.55"/><path d="${polyW([[0.18, 0.44], [0.3, 0.44], [0.32, 0.54], [0.16, 0.54]])}" fill="#ffd8a0" opacity="0.2"/><path d="${polyW([[0.42, 0.44], [0.48, 0.44], [0.49, 0.54], [0.41, 0.54]])}" fill="#ffffff" opacity="0.1"/></g>`
      + ripple(0.36, 0.5, 4, 6, 0, '#ffe8c0') + ripple(0.22, 0.47, 3, 6, 3, '#ffe8c0');
    s += rep(40, () => { const u = R(), y = 0.12 + R() * 0.85; return dot(u, y, 0.12 + R() * 0.12, 'fill="#ffffff" opacity="0.35"') + dot(u + 0.001, y + 0.002, 0.06, 'fill="#ffffff" opacity="0.7"'); }).join('');
    s += `<path d="${TR}" fill="url(#b29h)">${an('opacity', '0.4;1;0.4', 8, 0, SPL(2))}</path>` + rep(4, i => steamF(0.15 + i * 0.22, 0.72 + (i % 2) * 0.14, 0.8, 6 + i * 0.5, i * 1.4, '#f4e8dc')).join('');
    s += `<g filter="url(#fb3)"><path d="${polyW([[0.6, 0.1], [0.78, 0.1], [0.84, 0.5], [0.64, 0.5]])}" fill="#ffffff" opacity="0.08"/></g>`;
    return FL(s); }

  // BTH-085 THERMAL HYDRO-MASSAGE GLASS & HEATED QUARTZ (T5): warm white quartz slabs with soft grey-gold veins, polished brass seams with travelling glints
  // and brass diamond keystones, framing a big walk-on glass panel in a brass bezel: under it warm-lit water where hydro-massage jets rise in ribbons of
  // bubbles and golden caustic light ripples across the basin. Steam curls up at the glass edge and the heated stone breathes a warm glow.
  function fHydro() { const R = rng('hyd29'), NU = 4, NV = 3, gu = 0.004, gy = 0.007, QC = ['#f6f1e8', '#f3ede2', '#f8f4ec', '#f1eadd'], G0 = [0.3, 0.32, 0.7, 0.72];
    let s = '<defs><linearGradient id="h29b" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8a5f1e"/><stop offset="0.3" stop-color="#f2cf7a"/><stop offset="0.5" stop-color="#fff0b8"/><stop offset="0.7" stop-color="#d9a84a"/><stop offset="1" stop-color="#8a5f1e"/></linearGradient>'
      + '<radialGradient id="h29w" cx="50%" cy="55%" r="60%"><stop offset="0" stop-color="#ffd8a0"/><stop offset="0.55" stop-color="#e8a868"/><stop offset="1" stop-color="#7a4e2c"/></radialGradient>'
      + '<linearGradient id="h29q" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#a89a80" stop-opacity="0.18"/></linearGradient>'
      + '<linearGradient id="h29g" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="24" y2="0"><stop offset="0" stop-color="#fff4c8" stop-opacity="0"/><stop offset="0.5" stop-color="#fff4c8" stop-opacity="0.95"/><stop offset="1" stop-color="#fff4c8" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-30 0;-30 0;100 0" keyTimes="0;0.5;1" dur="9s" repeatCount="indefinite"/></linearGradient>'
      + '<radialGradient id="h29h" cx="50%" cy="60%" r="65%"><stop offset="0" stop-color="#ffb062" stop-opacity="0.18"/><stop offset="1" stop-color="#ffb062" stop-opacity="0"/></radialGradient></defs><rect width="80" height="56" fill="#b8955a"/>';
    let gl = ''; for (let i = 0; i <= NU; i++) gl += lineW([[i / NU, -0.02], [i / NU, 1.04]]); for (let j = 0; j <= NV; j++) gl += lineW([[-0.02, j / NV], [1.02, j / NV]]);
    s += `<path d="${gl}" stroke="url(#h29b)" stroke-width="0.85" fill="none"/>`;
    let qall = '';
    for (let j = 0; j < NV; j++) for (let i = 0; i < NU; i++) { const u0 = i / NU + gu, u1 = (i + 1) / NU - gu, y0 = j / NV + gy, y1 = (j + 1) / NV - gy, col = shade(QC[(i + j) & 3], 0.99 + R() * 0.02), q = quadW(u0, y0, u1, y1); qall += q;
      s += `<path d="${q}" fill="${col}"/><path d="${q}" fill="url(#h29q)"/>` + rep(60, () => dot(u0 + (u1 - u0) * R(), y0 + (y1 - y0) * R(), 0.06 + R() * 0.14, `fill="${R() < 0.5 ? '#d8cfc0' : '#ffffff'}" opacity="0.7"`)).join('')
        + `<path d="${lineW([[u0, y1], [u0, y0], [u1, y0]])}" stroke="#ffffff" stroke-width="0.28" fill="none" opacity="0.85"/><path d="${lineW([[u1, y0], [u1, y1], [u0, y1]])}" stroke="#b8a888" stroke-width="0.2" fill="none" opacity="0.5"/>`; }
    let vg = '', vd = '', vf = ''; rep(6, k => { const c = 0.02 + k * 0.17 + R() * 0.05, ph = R() * 6; const P = rep(12, q => { const y = -0.05 + q * 0.1; return [c + 0.05 * Math.sin(y * 3 + ph) + 0.1 * y, y]; }); if (k % 2) vg += crvW(P); else vd += crvW(P); const st = 2 + ((R() * 6) | 0); vf += crvW(P.slice(st, st + 3).map(([u, y]) => [u + 0.02, y + 0.01])); });
    s += `<defs><clipPath id="h29qc"><path d="${qall}"/></clipPath></defs><g clip-path="url(#h29qc)"><g filter="url(#fb2)"><path d="${vd + vg}" stroke="#c8beb0" stroke-width="1.9" fill="none" opacity="0.32"/></g><path d="${vd}" stroke="#9a948a" stroke-width="0.25" fill="none" opacity="0.6"/><path d="${vg}" stroke="#c99a44" stroke-width="0.26" fill="none" opacity="0.85"/><path d="${vf}" stroke="#a8a294" stroke-width="0.12" fill="none" opacity="0.6"/></g>`;
    s += `<path d="${gl}" stroke="#fff3c8" stroke-width="0.14" fill="none" opacity="0.8" transform="translate(-0.08 -0.1)"/><path d="${gl}" stroke="url(#h29g)" stroke-width="0.6" fill="none"/>`;
    for (let j = 1; j < NV; j++) for (let i = 1; i < NU; i++) { const u = i / NU, y = j / NV, aa = 0.014, bb = 0.026; if (u > G0[0] - 0.02 && u < G0[2] + 0.02 && y > G0[1] - 0.03 && y < G0[3] + 0.03) continue;
      s += `<path d="${polyW([[u, y - bb], [u + aa, y], [u, y + bb], [u - aa, y]])}" fill="url(#h29b)" stroke="#7a5418" stroke-width="0.15"/><path d="${polyW([[u, y - bb * 0.5], [u + aa * 0.5, y], [u, y + bb * 0.5], [u - aa * 0.5, y]])}" fill="#f6efe2"/>` + glint(u, y, 1, 6, (i + j) * 1.3); }
    const [a0, b0, a1, b1] = G0;
    s += `<path d="${quadW(a0 - 0.018, b0 - 0.028, a1 + 0.018, b1 + 0.028)}" fill="#000" opacity="0.25" filter="url(#fb1)"/><path d="${quadW(a0 - 0.014, b0 - 0.022, a1 + 0.014, b1 + 0.022)}" fill="url(#h29b)"/><path d="${quadW(a0, b0, a1, b1)}" fill="url(#h29w)"/>`;
    s += `<defs><clipPath id="h29c"><path d="${quadW(a0, b0, a1, b1)}"/></clipPath></defs><g clip-path="url(#h29c)">`;
    let cau = ''; rep(9, i => { const y = b0 + (b1 - b0) * (i + 0.5) / 9; cau += crvW(rep(8, q => [a0 + (a1 - a0) * q / 7, y + 0.014 * Math.sin(q * 2.3 + i * 1.7)])); }); rep(8, i => { const u = a0 + (a1 - a0) * (i + 0.5) / 8; cau += crvW(rep(8, q => [u + 0.018 * Math.sin(q * 2.1 + i * 1.3), b0 + (b1 - b0) * q / 7])); });
    s += `<path d="${dotD((a0 + a1) / 2, (b0 + b1) / 2, 14)}" fill="#fff0c8" opacity="0.25" filter="url(#fb3)"/>`;
    s += `<path d="${cau}" stroke="#fff2c8" stroke-width="0.32" fill="none" opacity="0.4"><animateTransform attributeName="transform" type="translate" values="0 0;1.4 0.5;0 0" dur="5s" repeatCount="indefinite"/></path>`
      + `<path d="${cau}" stroke="#ffe0a0" stroke-width="0.22" fill="none" opacity="0.3" transform="translate(0.8 1.2)"><animateTransform attributeName="transform" type="translate" values="0.8 1.2;-0.6 0.6;0.8 1.2" dur="6.4s" repeatCount="indefinite"/></path>`;
    [[0.38, 0.42], [0.5, 0.6], [0.62, 0.45], [0.45, 0.66], [0.58, 0.68]].forEach(([u, y], j) => { const p = W(u, y), k = K(y); s += `<path d="${dotD(u, y, 1.4)}" fill="#c9a256" stroke="#7a5418" stroke-width="0.15"/><path d="${dotD(u, y, 0.6)}" fill="#3a2a14"/>`;
      s += rep(5, i => { const T = 2.2 + (i % 3) * 0.4, b = -(i * 0.45 + j * 0.3); return `<circle cx="${f1(p[0] + (i - 2) * 0.5 * k)}" cy="${f1(p[1])}" r="${f1((0.25 + (i % 3) * 0.12) * k)}" fill="none" stroke="#fffaf0" stroke-width="0.12" opacity="0"><animate attributeName="cy" values="${f1(p[1])};${f1(p[1] - 6 * k)}" dur="${T}s" begin="${b}s" repeatCount="indefinite"/><animate attributeName="cx" values="${f1(p[0] + (i - 2) * 0.5 * k)};${f1(p[0] + (i - 2) * 0.9 * k + 0.6)}" dur="${T}s" begin="${b}s" repeatCount="indefinite"/>${an('opacity', '0;0.9;0', T, b)}</circle>`; }).join(''); });
    s += '</g>';
    s += `<path d="${polyW([[a0 + 0.04, b0 + 0.02], [a0 + 0.12, b0 + 0.02], [a0 + 0.16, b1 - 0.02], [a0 + 0.06, b1 - 0.02]])}" fill="#ffffff" opacity="0.18"/><path d="${polyW([[a0 + 0.17, b0 + 0.02], [a0 + 0.2, b0 + 0.02], [a0 + 0.23, b1 - 0.02], [a0 + 0.19, b1 - 0.02]])}" fill="#ffffff" opacity="0.1"/><path d="${lineW([[a0, b1], [a0, b0], [a1, b0]])}" stroke="#ffffff" stroke-width="0.3" fill="none" opacity="0.8"/>`;
    s += rep(5, i => steamF(a0 + (a1 - a0) * (0.1 + i * 0.2), b1, 1, 5 + i * 0.6, i * 1.1, '#fff6e8')).join('');
    s += `<path d="${TR}" fill="url(#h29h)">${an('opacity', '0.35;1;0.35', 8, 0, SPL(2))}</path>`;
    s += `<g filter="url(#fb3)"><path d="${polyW([[0.12, 0.02], [0.24, 0.02], [0.3, 0.32], [0.14, 0.32]])}" fill="#ffffff" opacity="0.2"/></g>`;
    return FL(s); }

  const FLOOR29 = { vinyl: fVinyl, hex: fHex, pebble: fPebble, basalt: fBasalt, hydro: fHydro }, MEMO = {};
  const draw28 = RD.draw;
  RD.draw = (r, o) => { const res = draw28(r, o); if (!res || res._p29) return res;
    try { const f = r.f29 && FLOOR29[r.f29]; if (f && res.surf) { res._p29 = 1; res.vb = '0 0 80 56'; res.svg = MEMO[r.f29] || (MEMO[r.f29] = RD.svgDoc('0 0 80 56', [], f())); res.src = 'data:image/svg+xml,' + encodeURIComponent(res.svg); } } catch (e) { console.warn('reno plus29', r.id, e); }
    return res; };

  // ======================= FLOOR MATS (flat rugs: RUG fx, art drawn in the piece's own x / z, footprints kept) =======================
  const DEF29 = '<filter id="m29b" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="1.4"/></filter><filter id="m29s" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="0.6"/></filter>';
  const RUG = (w, d, o) => Object.assign({ w, d, flat: 1, noBlock: 1, build: () => [] }, o || {});
  const ell = (x, z, rx, rz, ex) => `<ellipse cx="${f1(x)}" cy="${f1(z)}" rx="${f1(rx)}" ry="${f1(rz)}" ${ex}/>`;
  // a wet footprint (heel + ball + toes) at (x, z), pointing toward -z
  const foot = (x, z, s, col, op) => `<g transform="translate(${f1(x)} ${f1(z)}) scale(${s})" fill="${col}" opacity="${op}"><ellipse cx="0" cy="2.2" rx="2.4" ry="3.2"/><ellipse cx="-0.2" cy="-1.8" rx="1.9" ry="2"/>${[[-1.6, -4.4, 0.7], [-0.5, -4.8, 0.62], [0.5, -4.7, 0.55], [1.4, -4.3, 0.5], [2.1, -3.6, 0.45]].map(([a, b, r]) => `<circle cx="${a}" cy="${b}" r="${r}"/>`).join('')}</g>`;

  // BTH-014 SOGGY THREADBARE COTTON BATH MAT (T1): 120 x 72 kept. A faded blue terry mat gone thin and lumpy: worn bald patches showing the backing, a dark
  // soggy middle, a frayed fringe at both ends with a loose thread, a little hole, hair and lint, pink mildew dots. Alive: wet footprints soak in and fade.
  N.mat29a = S => { const W0 = 112, Dd = 64, T = 0.9, P = rrP(W0, Dd, 3), D = RUG(120, 72);
    D.fx = ctx => { const C = cam(ctx), R = rng('mat29a'), id = C.u('ma');
      let art = `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="#7a9ab8"/>`;
      let lp = ''; for (let z = -Dd / 2 + 1; z < Dd / 2; z += 1.1) for (let x = -W0 / 2 + 1 + (Math.round(z) % 2) * 0.55; x < W0 / 2; x += 1.1) if (R() < 0.75) lp += `M${f1(x)} ${f1(z)}h0.01`;
      art += `<path d="${lp}" stroke="#9ab4cc" stroke-width="0.7" stroke-linecap="round"/><path d="${lp}" stroke="#5a7a98" stroke-width="0.25" stroke-linecap="round" transform="translate(0.25 0.3)"/>`;
      art += `<rect x="${-W0 / 2 + 4}" y="${-Dd / 2 + 4}" width="${W0 - 8}" height="${Dd - 8}" rx="2" fill="none" stroke="#5a7a98" stroke-width="1.2" stroke-dasharray="0.6 0.8" opacity="0.7"/>`;
      art += `<g filter="url(#m29b)">${ell(-4, 2, 26, 15, 'fill="#3a5878" opacity="0.45"')}${ell(18, -6, 12, 8, 'fill="#3a5878" opacity="0.3"')}</g>`;
      art += rep(5, () => { const x = (R() - 0.5) * W0 * 0.7, z = (R() - 0.5) * Dd * 0.6; return `<g filter="url(#m29s)">${ell(x, z, 4 + R() * 6, 2.4 + R() * 3, 'fill="#d8d0c0" opacity="0.55"')}</g>` + rep(10, () => `<path d="M${f1(x + (R() - 0.5) * 8)} ${f1(z + (R() - 0.5) * 5)}h0.6" stroke="#c8beac" stroke-width="0.25"/>`).join(''); }).join('');
      art += ell(30, 14, 1.6, 1.3, 'fill="#1e2a36"') + ell(30, 14, 2.2, 1.9, 'fill="none" stroke="#3a3020" stroke-width="0.4" opacity="0.6"');
      art += rep(22, () => ell((R() - 0.5) * W0 * 0.9, (R() - 0.5) * Dd * 0.9, 0.3 + R() * 0.5, 0.3 + R() * 0.4, 'fill="#e89aa8" opacity="0.5"')).join('');
      art += rep(5, () => { const x = (R() - 0.5) * W0 * 0.8, z = (R() - 0.5) * Dd * 0.8; return `<path d="M${f1(x)} ${f1(z)}q${f1(2 + R() * 3)} ${f1(-1 - R())} ${f1(4 + R() * 3)} ${f1(R() * 2)}" stroke="#2a1e14" stroke-width="0.15" fill="none"/>`; }).join('');
      art += [[-16, 8, 0], [10, -4, 3.2]].map(([x, z, b]) => `<g opacity="0">${an('opacity', '0;0.6;0.35;0;0', 9, -b, KT('0;0.05;0.4;0.85;1'))}${foot(x, z, 1, '#2a4868', 1)}</g>`).join('');
      let fr = ''; [-1, 1].forEach(sd => { for (let z = -Dd / 2 + 1; z < Dd / 2; z += 1.2) { const x0 = sd * W0 / 2, L = 2.6 + R() * 1.6; fr += `M${f1(x0)} ${f1(z)}l${f1(sd * L)} ${f1((R() - 0.5) * 0.8)}`; } });
      const fring = top(C, 0.05, `<path d="${fr}" stroke="#c8d4e0" stroke-width="0.45" fill="none" stroke-linecap="round"/><path d="${fr}" stroke="#5a7a98" stroke-width="0.15" fill="none" opacity="0.6"/><path d="M${W0 / 2 + 3} 6q4 1 6 -2" stroke="#c8d4e0" stroke-width="0.35" fill="none"/>`);
      const s = fring + slab(C, P, T, '#5a7090') + top(C, T, face(id, P, art, 0.2));
      return { defs: DEF29, front: s, bb: C.bb(4) }; };
    return D; };

  // BTH-034 MEMORY-FOAM MICROFIBER PEBBLE BATH RUG (T2): 200 x 130 oval kept. A plush sage microfiber rug moulded into puffy pebbles of different sizes with
  // soft grooves between them, a velvety sheen that drifts and a bound edge. Alive: one pebble slowly squishes in and springs back as if just stepped on.
  N.mat29b = S => { const A = 94, B = 60, T = 2.2, P = ellP(A, B, 48), D = RUG(200, 130, { round: 1 });
    D.fx = ctx => { const C = cam(ctx), R = rng('mat29b'), id = C.u('mb');
      let art = `<defs><radialGradient id="${id}p" cx="38%" cy="32%" r="70%"><stop offset="0" stop-color="#c8d8b8"/><stop offset="0.6" stop-color="#a0b890"/><stop offset="1" stop-color="#6a8460"/></radialGradient><linearGradient id="${id}sh" x1="0" y1="0" x2="1" y2="0.3"><stop offset="0.3" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.22"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-0.6 0;0.6 0;-0.6 0" dur="12s" repeatCount="indefinite"/></linearGradient></defs>`;
      art += `<ellipse rx="${A}" ry="${B}" fill="#4e6a48"/>`;
      const peb = []; for (let n = 0; n < 1400 && peb.length < 70; n++) { const rx = 7 + R() * 9, rz = rx * (0.6 + R() * 0.3), x = (R() - 0.5) * 2 * (A - 6), z = (R() - 0.5) * 2 * (B - 6); if ((x / (A - rx - 3)) ** 2 + (z / (B - rz - 3)) ** 2 > 1) continue; if (peb.some(q => ((x - q[0]) / (rx + q[2] + 1.4)) ** 2 + ((z - q[1]) / (rz + q[3] + 1.4)) ** 2 < 1)) continue; peb.push([x, z, rx, rz, (R() - 0.5) * 40]); }
      peb.forEach(([x, z, rx, rz, rot], i) => { const body = ell(0.6, 1, rx, rz, 'fill="#3a5236" opacity="0.6"') + ell(0, 0, rx, rz, `fill="url(#${id}p)"`) + ell(-rx * 0.25, -rz * 0.3, rx * 0.45, rz * 0.32, 'fill="#ffffff" opacity="0.18"');
        art += `<g transform="translate(${f1(x)} ${f1(z)}) rotate(${f1(rot)})">` + (i === 7 ? `<g><animateTransform attributeName="transform" type="scale" values="1;1;0.84;1.04;1" dur="7s" repeatCount="indefinite"${KT('0;0.55;0.62;0.78;1')}/>${body}</g>` : body) + '</g>'; });
      art += rep(260, () => { const x = (R() - 0.5) * 2 * A, z = (R() - 0.5) * 2 * B; return (x / A) ** 2 + (z / B) ** 2 < 0.95 ? `<path d="M${f1(x)} ${f1(z)}l0.5 0.2" stroke="#d8e4c8" stroke-width="0.25" opacity="0.5"/>` : ''; }).join('');
      art += `<ellipse rx="${A}" ry="${B}" fill="url(#${id}sh)"/><ellipse rx="${A - 1.6}" ry="${B - 1.6}" fill="none" stroke="#3e5638" stroke-width="3"/><ellipse rx="${A - 1.6}" ry="${B - 1.6}" fill="none" stroke="#8aa478" stroke-width="0.4" stroke-dasharray="1 0.8"/>`;
      const s = slab(C, P, T, '#4e6a48') + top(C, T, face(id, P, art, 0.25));
      return { defs: DEF29, front: s, bb: C.bb(4) }; };
    return D; };

  // BTH-054 QUICK-DRY DIATOMACEOUS EARTH STONE MAT (T3): 120 x 72 kept. A thin pale-grey diatomite slab with a fine sandy speckle and a soft bevel, a faint
  // pressed wave pattern and a little embossed leaf, on a cork pad. Alive: a pair of wet footprints appears dark and dries away in seconds.
  N.mat29c = S => { const W0 = 110, Dd = 62, T = 1.8, P = rrP(W0, Dd, 4), D = RUG(120, 72);
    D.fx = ctx => { const C = cam(ctx), R = rng('mat29c'), id = C.u('mc');
      let art = `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="#d8d4cc"/>` + rep(700, () => ell((R() - 0.5) * W0, (R() - 0.5) * Dd, 0.12 + R() * 0.2, 0.12 + R() * 0.2, `fill="${R() < 0.5 ? '#b8b2a8' : '#f2f0ea'}" opacity="0.8"`)).join('');
      art += rep(9, i => `<path d="M${-W0 / 2 + 6} ${f1(-Dd / 2 + 6 + i * 6.2)}q14 -2.4 28 0t28 0t28 0t28 0" stroke="#c4beb4" stroke-width="0.6" fill="none" opacity="0.6"/><path d="M${-W0 / 2 + 6} ${f1(-Dd / 2 + 6.5 + i * 6.2)}q14 -2.4 28 0t28 0t28 0t28 0" stroke="#ffffff" stroke-width="0.3" fill="none" opacity="0.5"/>`).join('');
      art += `<g transform="translate(${W0 / 2 - 10} ${Dd / 2 - 8})" opacity="0.45"><path d="M0 2Q-3 -2 0 -4Q3 -2 0 2Z" fill="none" stroke="#9a948a" stroke-width="0.4"/><path d="M0 2V-3.4" stroke="#9a948a" stroke-width="0.3"/></g>`;
      art += `<rect x="${-W0 / 2 + 1}" y="${-Dd / 2 + 1}" width="${W0 - 2}" height="${Dd - 2}" rx="3.4" fill="none" stroke="#ffffff" stroke-width="0.8" opacity="0.6"/>`;
      art += [[-14, 6, 0, 1], [6, -2, 0.5, 0.95]].map(([x, z, b, sc]) => `<g opacity="0">${an('opacity', '0;0;0.7;0.45;0;0', 8, -b, KT('0;0.08;0.12;0.4;0.75;1'))}${foot(x, z, sc, '#8a8478', 1)}<g filter="url(#m29s)">${foot(x, z, sc * 1.12, '#9a948a', 0.5)}</g></g>`).join('');
      const s = slab(C, rrP(W0 + 2, Dd + 2, 4.6), 0.6, '#b8925a') + slab(C, P, T + 0.6, '#c4beb4') + top(C, T + 0.6, face(id, P, art, 0.3));
      return { defs: DEF29, front: s, bb: C.bb(4) }; };
    return D; };

  // BTH-074 SLATTED BURMESE TEAK & PLUSH EGYPTIAN COTTON RUNNER (T4): 250 x 70 kept. A long runner of oiled golden teak slats on a teak frame with polished brass
  // corner caps, three panels inset with deep plush ivory Egyptian cotton framed by a fine gold line, a little monogram. Alive: a warm glint slides along the
  // oiled teak and the cotton pile sheen drifts.
  N.mat29d = S => { const W0 = 240, Dd = 62, T = 2.4, P = rrP(W0, Dd, 2), D = RUG(250, 70, { round: 1 });
    D.fx = ctx => { const C = cam(ctx), R = rng('mat29d'), id = C.u('md');
      let art = `<defs><linearGradient id="${id}t" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d8a060"/><stop offset="0.5" stop-color="#b87a3a"/><stop offset="1" stop-color="#8a5424"/></linearGradient><linearGradient id="${id}g" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="30" y2="0"><stop offset="0" stop-color="#fff0c8" stop-opacity="0"/><stop offset="0.5" stop-color="#fff0c8" stop-opacity="0.55"/><stop offset="1" stop-color="#fff0c8" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-160 0;-160 0;160 0" keyTimes="0;0.4;1" dur="10s" repeatCount="indefinite"/></linearGradient>`
        + `<linearGradient id="${id}c" x1="0" y1="0" x2="1" y2="0.4"><stop offset="0.3" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.35"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/><animateTransform attributeName="gradientTransform" type="translate" values="-0.7 0;0.7 0;-0.7 0" dur="11s" repeatCount="indefinite"/></linearGradient></defs>`;
      art += `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="#5a3418"/>`;
      const slats = [], pan = [[-72, -28], [-14, 30], [44, 72]]; for (let x = -W0 / 2 + 4; x < W0 / 2 - 4; x += 7) slats.push(x);
      slats.forEach(x => { if (pan.some(([a, b]) => x + 5.6 > a && x < b)) return; art += `<rect x="${f1(x)}" y="${-Dd / 2 + 4}" width="5.6" height="${Dd - 8}" rx="0.6" fill="url(#${id}t)"/>` + rep(3, () => { const xx = x + 0.6 + R() * 4.4; return `<path d="M${f1(xx)} ${-Dd / 2 + 4}q${f1((R() - 0.5) * 1.4)} ${Dd / 2 - 4} 0 ${Dd - 8}" stroke="#6a3e18" stroke-width="0.18" fill="none" opacity="0.6"/>`; }).join('') + `<path d="M${f1(x + 0.4)} ${-Dd / 2 + 4.4}V${Dd / 2 - 4.4}" stroke="#f0c890" stroke-width="0.3" opacity="0.7"/>`; });
      art += [-Dd / 2 + 1.6, Dd / 2 - 1.6].map(z => `<rect x="${-W0 / 2 + 1}" y="${f1(z - 1.6)}" width="${W0 - 2}" height="3.2" rx="0.8" fill="url(#${id}t)"/><path d="M${-W0 / 2 + 2} ${f1(z - 1.2)}H${W0 / 2 - 2}" stroke="#f0c890" stroke-width="0.3" opacity="0.7"/>`).join('');
      pan.forEach(([a, b]) => { art += `<rect x="${a}" y="${-Dd / 2 + 4}" width="${b - a}" height="${Dd - 8}" rx="2.4" fill="#4a2a14"/><rect x="${a + 1}" y="${-Dd / 2 + 5}" width="${b - a - 2}" height="${Dd - 10}" rx="2" fill="#f4eee2"/>`
        + rep(Math.round((b - a) * 6), () => { const x = a + 1.6 + R() * (b - a - 3.2), z = -Dd / 2 + 5.6 + R() * (Dd - 11.2); return `<path d="M${f1(x)} ${f1(z)}l0.4 0.25" stroke="${R() < 0.5 ? '#ffffff' : '#ddd4c2'}" stroke-width="0.4" stroke-linecap="round"/>`; }).join('')
        + `<rect x="${a + 1}" y="${-Dd / 2 + 5}" width="${b - a - 2}" height="${Dd - 10}" rx="2" fill="url(#${id}c)"/><rect x="${a + 2.6}" y="${-Dd / 2 + 6.6}" width="${b - a - 5.2}" height="${Dd - 13.2}" rx="1.4" fill="none" stroke="#c9a256" stroke-width="0.4" opacity="0.7"/>`; });
      art += `<text x="8" y="2" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-size="6" fill="#c9a256" opacity="0.75">S</text>`;
      art += `<rect x="${-W0 / 2}" y="${-Dd / 2}" width="${W0}" height="${Dd}" fill="url(#${id}g)"/>`;
      art += [[-W0 / 2 + 2.4, -Dd / 2 + 2.4], [W0 / 2 - 2.4, -Dd / 2 + 2.4], [-W0 / 2 + 2.4, Dd / 2 - 2.4], [W0 / 2 - 2.4, Dd / 2 - 2.4]].map(([x, z]) => `<rect x="${f1(x - 2.4)}" y="${f1(z - 2.4)}" width="4.8" height="4.8" rx="0.8" fill="#c9a256" stroke="#7a5418" stroke-width="0.25"/><circle cx="${f1(x)}" cy="${f1(z)}" r="0.6" fill="#7a5418"/>`).join('');
      const s = slab(C, P, T, '#6a3e1c') + top(C, T, face(id, P, art, 0.2));
      return { defs: DEF29, front: s, bb: C.bb(4) }; };
    return D; };

  // BTH-094 SELF-DRYING HEATED MOSS & SILK SPA CARPET (T5): 180 x 130 oval kept. A living carpet of preserved cushion moss in many greens (bun-moss mounds, fine
  // sheet moss, tiny fern fronds, white star flowers), framed by a wide ivory silk border with a champagne-gold key pattern and a gold edge. A warm glow
  // breathes underneath; dew twinkles on the moss and lifts away as faint wisps of steam.
  N.mat29e = S => { const A = 86, B = 60, T = 2.8, P = ellP(A, B, 56), D = RUG(180, 130, { round: 1 });
    D.fx = ctx => { const C = cam(ctx), R = rng('mat29e'), id = C.u('me'), a2 = A - 9, b2 = B - 9;
      let art = `<defs><radialGradient id="${id}g" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffc878" stop-opacity="0.35"/><stop offset="1" stop-color="#ffc878" stop-opacity="0"/></radialGradient><linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fbf7ee"/><stop offset="0.5" stop-color="#efe6d4"/><stop offset="1" stop-color="#f8f2e6"/></linearGradient>`
        + ['#5a8a3a', '#6a9a42', '#4a7a32', '#7aa84a', '#3e6a2c'].map((c, i) => `<radialGradient id="${id}m${i}" cx="38%" cy="32%" r="70%"><stop offset="0" stop-color="${shade(c, 1.3)}"/><stop offset="0.6" stop-color="${c}"/><stop offset="1" stop-color="${shade(c, 0.6)}"/></radialGradient>`).join('') + '</defs>';
      art += `<ellipse rx="${A}" ry="${B}" fill="url(#${id}s)"/><ellipse rx="${A - 0.8}" ry="${B - 0.8}" fill="none" stroke="#c9a256" stroke-width="1.2"/>`;
      art += rep(64, i => { const t = i / 64 * 2 * PI, x = Math.cos(t) * (A - 4.5), z = Math.sin(t) * (B - 4.5); return `<g transform="translate(${f1(x)} ${f1(z)}) rotate(${f1(t * 180 / PI + 90)})"><path d="M-1.4 0.8V-0.8H1.4V0.4H-0.2V-0.2" stroke="#c9a256" stroke-width="0.35" fill="none"/></g>`; }).join('');
      art += `<ellipse rx="${a2 + 1}" ry="${b2 + 1}" fill="#3a5a2a"/>`;
      art += rep(1400, () => { const t = R() * 2 * PI, rr = Math.sqrt(R()), x = Math.cos(t) * a2 * rr, z = Math.sin(t) * b2 * rr; return `<circle cx="${f1(x)}" cy="${f1(z)}" r="${f1(0.5 + R() * 0.7)}" fill="${['#4a7a32', '#5a8a3a', '#6a9a42', '#3e6a2c', '#7aa84a'][(R() * 5) | 0]}"/>`; }).join('');
      const mounds = []; for (let n = 0; n < 600 && mounds.length < 40; n++) { const r = 4 + R() * 6, t = R() * 2 * PI, rr = Math.sqrt(R()) * 0.9, x = Math.cos(t) * (a2 - r) * rr, z = Math.sin(t) * (b2 - r) * rr; if (mounds.some(q => Math.hypot(x - q[0], z - q[1]) < r + q[2] - 1)) continue; mounds.push([x, z, r]); }
      mounds.sort((p, q) => p[1] - q[1]).forEach(([x, z, r], i) => { art += ell(x + 0.5, z + 0.8, r, r * 0.86, 'fill="#1e3214" opacity="0.5"') + ell(x, z, r, r * 0.86, `fill="url(#${id}m${i % 5})"`) + rep(Math.round(r * 3), () => { const a = R() * 2 * PI, q = R() * r * 0.85; return `<circle cx="${f1(x + Math.cos(a) * q)}" cy="${f1(z + Math.sin(a) * q * 0.86)}" r="0.35" fill="${R() < 0.5 ? '#a8d070' : '#2e5220'}" opacity="0.8"/>`; }).join(''); });
      art += rep(9, () => { const t = R() * 2 * PI, rr = Math.sqrt(R()) * 0.8, x = Math.cos(t) * a2 * rr, z = Math.sin(t) * b2 * rr, rot = R() * 360; return `<g transform="translate(${f1(x)} ${f1(z)}) rotate(${f1(rot)})"><path d="M0 0V-6" stroke="#4a7a2a" stroke-width="0.25"/>${rep(6, k => `<path d="M0 ${f1(-1 - k * 0.9)}l${f1(1.6 - k * 0.2)} -0.6M0 ${f1(-1 - k * 0.9)}l${f1(-1.6 + k * 0.2)} -0.6" stroke="#7ab84a" stroke-width="0.3"/>`).join('')}</g>`; }).join('');
      art += rep(14, () => { const t = R() * 2 * PI, rr = Math.sqrt(R()) * 0.85, x = Math.cos(t) * a2 * rr, z = Math.sin(t) * b2 * rr; return `<g transform="translate(${f1(x)} ${f1(z)})">${rep(5, k => { const cx = Math.cos(k * 1.26) * 0.7, cz = Math.sin(k * 1.26) * 0.7; return `<ellipse cx="${f1(cx)}" cy="${f1(cz)}" rx="0.55" ry="0.3" transform="rotate(${f1(k * 72)} ${f1(cx)} ${f1(cz)})" fill="#fbf8f0"/>`; }).join('')}<circle r="0.3" fill="#f2c84a"/></g>`; }).join('');
      art += `<ellipse rx="${a2}" ry="${b2}" fill="url(#${id}g)">${an('opacity', '0.5;1;0.5', 7, 0, SPL(2))}</ellipse>`;
      art += rep(18, i => { const t = R() * 2 * PI, rr = Math.sqrt(R()) * 0.85, x = Math.cos(t) * a2 * rr, z = Math.sin(t) * b2 * rr; return `<path d="M${f1(x - 1)} ${f1(z)}H${f1(x + 1)}M${f1(x)} ${f1(z - 1)}V${f1(z + 1)}" stroke="#ffffff" stroke-width="0.3" stroke-linecap="round" opacity="0">${an('opacity', '0;0;1;0', 5 + (i % 4), -i * 0.7, KT('0;0.6;0.7;0.85'))}</path>`; }).join('');
      const wisps = rep(5, i => { const t = i * 1.3, x = Math.cos(t) * a2 * 0.5, z = Math.sin(t) * b2 * 0.5, p = C.P([x, T, z]), k = C.k; return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><ellipse rx="6" ry="2.6" fill="#fff8ec" opacity="0" filter="url(#m29b)">${an('opacity', '0;0.32;0', 6 + i * 0.4, -i * 1.2)}${at('translate', '0 0;1.6 -12', 6 + i * 0.4, -i * 1.2)}</ellipse></g>`; }).join('');
      const s = slab(C, P, T, '#e8dcc4') + top(C, T, face(id, P, art, 0.15)) + wisps;
      C.p(0, 14, 0);
      return { defs: DEF29, front: s, bb: C.bb(4) }; };
    return D; };

  // ======================= WALLS (r.s12 80 x 56 creature-scale tiles registered into RD.H12.SURF12, same pipeline as the Kitchen walls in plus27) =======================
  // one tile = full wall height (BB = skirting top); S.sup = what the side walls repeat above; S.one = one-off overlay drawn once on the back wall (plus27 draw hook)
  const WMEMO29 = {};
  { const { blot, outlet, BB, SURF12 } = RD.H12;
    const memo = (k, f) => () => WMEMO29[k] || (WMEMO29[k] = f());
    const wrapX = (x, w, f) => [-80, 0, 80].filter(dx => x + dx + w > -1 && x + dx - w < 81).map(dx => f(x + dx)).join('');
    const lblot = (seed, n, cols, op, sz, y0, y1) => { const R = rng(seed); let o = '<g filter="url(#wb2)">'; rep(n, i => { const x = R() * 80, y = y0 + R() * (y1 - y0), rx = sz * (0.6 + R() * 0.9), ry = rx * (0.5 + R() * 0.3);
      o += wrapX(x, rx, cx => `<ellipse cx="${f1(cx)}" cy="${f1(y)}" rx="${f1(rx)}" ry="${f1(ry)}" fill="${cols[i % cols.length]}" opacity="${op}"/>`); }); return o + '</g>'; };
    const scf = (seed, n, a, b) => { const R = rng(seed); return rep(n, () => `<path d="M${f1(R() * 78)} ${f1(BB + 0.5 + R() * 1.6)}h${f1(0.6 + R() * 1.6)}" stroke="${R() < 0.5 ? a : b}" stroke-width="${f1(0.12 + R() * 0.16)}" stroke-linecap="round" opacity="0.6"/>`).join(''); };
    const smooth = P => { let d = 'M' + pt([(P[0][0] + P[1][0]) / 2, (P[0][1] + P[1][1]) / 2]); for (let j = 1; j <= P.length; j++) { const a = P[j % P.length], b = P[(j + 1) % P.length]; d += 'Q' + pt(a) + ' ' + pt([(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]); } return d + 'Z'; };
    const sv = (P, c, w, op) => { let d = 'M' + pt(P[0]); for (let j = 1; j < P.length - 1; j++) d += 'Q' + pt(P[j]) + ' ' + pt([(P[j][0] + P[j + 1][0]) / 2, (P[j][1] + P[j + 1][1]) / 2]); return `<path d="${d}L${pt(P[P.length - 1])}" stroke="${c}" stroke-width="${w}" fill="none" stroke-linecap="round" opacity="${op}"/>`; };

    // BTH-001 CRACKED WHITE TILES WITH MILDEWED GROUT (T1): 4" white glazed squares up to a chipped bullnose cap, each a slightly different white with a
    // cushion glaze; grout going grey then black-green with mildew toward the floor; cracked tiles (one crack runs across two), a chipped corner, a missing
    // tile showing combed mortar, one too-blue replacement tile in fresh grout, two plastic anchors + rust runs where a towel bar was ripped off, soap scum,
    // yellowed caulk; above, yellowed bathroom paint with a water-stain tide ring, peeling flakes and mildew speckles creeping from the ceiling.
    // Live: condensation beads slide down the tiles leaving wet trails.
    const bTile = memo('b01', () => { const R = rng('bt01'), WT = 21.4, CAP = 1.5, TS = 80 / 28, Y0 = WT + CAP, g = 0.2;
      let up = '<rect width="80" height="56" fill="#e4dfcb"/>' + blot('bt01', 34, ['#ebe7d6', '#d6cfb6', '#e0d9c2', '#cfc6a8'], 0.45, 3.2);
      up += rep(30, i => `<rect x="${f1(i * 2.7 + R())}" width="${f1(1 + R() * 1.6)}" height="56" fill="${R() < 0.5 ? '#ffffff' : '#b8ae90'}" opacity="${f1(0.03 + R() * 0.04)}"/>`).join('');
      up += '<rect width="80" height="9" fill="url(#b01m)"/>' + lblot('bt01m', 9, ['#5a5e48', '#6a6650'], 0.12, 3, 0, 3) + rep(220, () => { const cx = [8, 31, 47, 70][Math.floor(R() * 4)], x = cx + (R() - 0.5) * 22 * R(), y = Math.pow(R(), 2.6) * 11, r = 0.04 + R() * R() * 0.16; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="${R() < 0.8 ? '#3c4232' : '#6a5e48'}" opacity="${f1(0.2 + R() * 0.4)}"/>`; }).join('');
      // water-stain tide rings + flaking paint
      up += '<g filter="url(#wb1)"><path d="M50 0Q51 5.6 55.4 7.4Q61 8.8 64.6 6Q67.4 3.4 67 0Z" fill="#c4a868" opacity="0.28"/><path d="M50 0Q51 5.6 55.4 7.4Q61 8.8 64.6 6Q67.4 3.4 67 0" stroke="#9a7a3e" stroke-width="0.35" fill="none" opacity="0.5"/><path d="M52.4 0Q53.4 3.8 57 5Q61.4 5.8 63.6 3.6Q64.8 2 64.6 0" stroke="#9a7a3e" stroke-width="0.25" fill="none" opacity="0.4"/></g>';
      up += '<path d="M58.6 7.6Q58.4 11 58.8 14.6" stroke="#a88a4e" stroke-width="0.5" opacity="0.25" filter="url(#wb1)"/>';
      const flake = (x, y, r) => `<path d="M${f1(x - r)} ${f1(y)}Q${f1(x - r * 0.4)} ${f1(y - r * 0.9)} ${f1(x + r * 0.6)} ${f1(y - r * 0.6)}Q${f1(x + r)} ${f1(y + r * 0.2)} ${f1(x + r * 0.2)} ${f1(y + r * 0.7)}Q${f1(x - r * 0.6)} ${f1(y + r * 0.8)} ${f1(x - r)} ${f1(y)}Z" fill="#b8b0a0"/>`
        + `<path d="M${f1(x + r * 0.6)} ${f1(y - r * 0.6)}Q${f1(x + r * 1.5)} ${f1(y - r * 1.2)} ${f1(x + r * 1.4)} ${f1(y - r * 0.1)}Q${f1(x + r)} ${f1(y - r * 0.5)} ${f1(x + r * 0.6)} ${f1(y - r * 0.6)}Z" fill="#f2eedf" stroke="#bdb59c" stroke-width="0.1"/><path d="M${f1(x + r * 0.62)} ${f1(y - r * 0.55)}l${f1(r * 0.6)} ${f1(r * 0.25)}" stroke="#7a705a" stroke-width="0.08" opacity="0.5"/>`;
      up += flake(14.6, 10.2, 1.1) + flake(39, 4.6, 0.8) + flake(71.4, 15.6, 0.7) + flake(27, 17.4, 0.55);
      let b = '<rect y="' + f1(Y0) + '" width="80" height="' + f1(BB - Y0) + '" fill="url(#b01g)"/>', tl = '', ov = '';
      const WH = ['#f4f2ea', '#efece2', '#f6f4ed', '#ebe8dc', '#f1eee5', '#e8e4d6'], MISS = '6,9', BLUE = '3,20';
      const CRK = { '2,4': [[0.3, 0.2], [1.1, 1.2], [0.9, 1.8], [1.9, 2.6]], '7,15': [[2.6, 0.3], [1.8, 1.1], [2, 1.7], [0.9, 2.65]], '4,24': [[0.2, 1.4], [1.2, 1.3], [1.6, 2], [2.65, 2.2]], '9,2': [[1.4, 0.2], [1.2, 1.4], [1.6, 2.65]], '9,3': [[0, 2.15], [1, 1.9], [2.65, 2.4]] };
      for (let i = 0; Y0 + i * TS < BB; i++) for (let j = 0; j < 28; j++) { const x = j * TS + g / 2, y = Y0 + i * TS + g / 2, w = TS - g, key = i + ',' + j;
        if (key === MISS) { tl += `<rect x="${f1(x - 0.05)}" y="${f1(y - 0.05)}" width="${f1(w + 0.1)}" height="${f1(w + 0.1)}" fill="#8a8476"/>` + [[0.7, 0.8, 0.55], [1.9, 0.7, 0.5], [1.2, 1.7, 0.6], [2.1, 2, 0.45], [0.5, 2.1, 0.4]].map(([a, q, r]) => `<ellipse cx="${f1(x + a)}" cy="${f1(y + q)}" rx="${r}" ry="${f1(r * 0.8)}" fill="#a49e8e"/><ellipse cx="${f1(x + a - 0.1)}" cy="${f1(y + q - 0.12)}" rx="${f1(r * 0.6)}" ry="${f1(r * 0.4)}" fill="#bab4a4"/><ellipse cx="${f1(x + a + 0.1)}" cy="${f1(y + q + 0.2)}" rx="${f1(r * 0.7)}" ry="${f1(r * 0.3)}" fill="#5e5a4e" opacity="0.4"/>`).join('')
            + `<path d="M${f1(x)} ${f1(y)}h${f1(w)}l-0.3 0.4l-0.5 -0.15l-0.6 0.35l-0.7 -0.2l-0.5 0.3L${f1(x)} ${f1(y + 0.5)}Z" fill="#ece8de" stroke="#8a8270" stroke-width="0.06"/><path d="M${f1(x + w)} ${f1(y + w)}h-1.1l0.4 -0.3l0.3 -0.6Z" fill="#e6e2d6" stroke="#8a8270" stroke-width="0.06"/>`
            + `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="0.35" fill="#000000" opacity="0.35"/><rect x="${f1(x)}" y="${f1(y)}" width="0.3" height="${f1(w)}" fill="#000000" opacity="0.25"/><path d="M${f1(x + 0.6)} ${f1(y + w - 0.3)}l0.5 -0.4l0.4 0.3l0.4 -0.2" fill="#f0ede4" stroke="#bdb8a8" stroke-width="0.06"/>`; continue; }
        const c = key === BLUE ? '#eef4f8' : WH[Math.floor(R() * WH.length)];
        if (key === BLUE) tl += `<rect x="${f1(x - g / 2)}" y="${f1(y - g / 2)}" width="${f1(TS)}" height="${f1(TS)}" fill="#f8f8f4"/>`;
        tl += `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(w)}" rx="0.18" fill="${c}"/><rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(w)}" rx="0.18" fill="url(#b01t)"/>`
          + `<path d="M${f1(x + 0.15)} ${f1(y + w - 0.2)}V${f1(y + 0.15)}H${f1(x + w - 0.2)}" stroke="#ffffff" stroke-width="0.1" fill="none" opacity="0.9"/>`;
        if (R() < 0.3) tl += `<ellipse cx="${f1(x + w * (0.3 + R() * 0.4))}" cy="${f1(y + w * (0.3 + R() * 0.4))}" rx="${f1(0.3 + R() * 0.6)}" ry="0.2" fill="#d8d2c0" opacity="${f1(0.3 + R() * 0.3)}"/>`;
        if (CRK[key]) { const P = CRK[key].map(([a, q]) => [x + a, y + q]); tl += `<path d="M${P.map(pt).join('L')}" stroke="#4a463c" stroke-width="0.12" fill="none" stroke-linejoin="bevel"/><path d="M${P.map(p => pt([p[0] + 0.08, p[1] + 0.08])).join('L')}" stroke="#ffffff" stroke-width="0.07" fill="none" opacity="0.8"/><path d="M${P.map(pt).join('L')}" stroke="#7a6a48" stroke-width="0.4" fill="none" opacity="0.15"/>`; }
        if (key === '5,12') tl += `<path d="M${f1(x + w)} ${f1(y + w)}l-0.9 0l0.3 -0.35l0.25 -0.6Z" fill="#cfc8b4" stroke="#8a8270" stroke-width="0.06"/>`; }
      b += tl;
      // mildew in the grout (bottom rows + round the missing tile), soap scum, anchors + rust runs, condensation
      b += rep(150, () => { const j = Math.floor(R() * 29), i = Math.floor(Math.pow(R(), 0.55) * 11), v = R() < 0.5, x = j * TS + (v ? 0 : R() * TS), y = Y0 + i * TS + (v ? R() * TS : 0); return y > BB ? '' : `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(0.1 + R() * 0.18)}" fill="${R() < 0.8 ? '#2e3424' : '#a86070'}" opacity="${f1(0.35 + R() * 0.4)}"/>`; }).join('');
      b += '<g filter="url(#wb2)"><ellipse cx="22" cy="49" rx="9" ry="3.4" fill="#ffffff" opacity="0.28"/><ellipse cx="58" cy="51" rx="7" ry="2.2" fill="#ffffff" opacity="0.22"/><ellipse cx="27.6" cy="40.6" rx="2" ry="1.6" fill="#3a4030" opacity="0.18"/></g>';
      [[46.4, 31.2], [61.2, 31.2]].forEach(([x, y]) => b += `<path d="M${f1(x - 0.25)} ${f1(y + 0.4)}Q${f1(x - 0.4)} ${f1(y + 4)} ${f1(x - 0.1)} ${f1(y + 7.8)}L${f1(x + 0.3)} ${f1(y + 7.8)}Q${f1(x + 0.5)} ${f1(y + 4)} ${f1(x + 0.25)} ${f1(y + 0.4)}Z" fill="url(#b01r)" opacity="0.7"/><circle cx="${x}" cy="${y}" r="0.55" fill="#c8c6bc" stroke="#8a887e" stroke-width="0.1"/><circle cx="${x}" cy="${y}" r="0.2" fill="#3a3a34"/><path d="M${f1(x - 0.9)} ${f1(y - 0.7)}l0.6 0.3l0.3 -0.5" stroke="#8a8270" stroke-width="0.1" fill="none"/>`);
      b += [[33.9, 25.6, 9, 0], [74.2, 28.4, 11, 4.2], [8.4, 33, 10, 7]].map(([x, y0, T, ph]) => `<path d="M${f1(x)} ${f1(y0)}V${f1(y0 + 15)}" stroke="#ffffff" stroke-width="0.32" opacity="0">${an('opacity', '0;0.5;0.15;0', T, -ph, KT('0;0.2;0.9;1'))}</path><g>${at('translate', `0 0;0 0;0 15;0 15`, T, -ph, KT('0;0.15;0.85;1'))}<circle cx="${f1(x)}" cy="${f1(y0)}" r="0.42" fill="#d8e4e8" opacity="0">${an('opacity', '0;0.9;0.9;0', T, -ph, KT('0;0.15;0.85;1'))}</circle><circle cx="${f1(x - 0.12)}" cy="${f1(y0 - 0.14)}" r="0.13" fill="#ffffff" opacity="0">${an('opacity', '0;1;1;0', T, -ph, KT('0;0.15;0.85;1'))}</circle></g>`).join('');
      b += `<path d="M0 ${f1(BB - 0.35)}H80" stroke="#e2d6a8" stroke-width="0.7"/><path d="M12 ${f1(BB - 0.35)}h3.4M44 ${f1(BB - 0.35)}h2.2" stroke="#3a3a30" stroke-width="0.6" opacity="0.6"/>`;
      let s = up + `<g clip-path="url(#b01c)">${b}</g>`;
      // bullnose cap row (6" pieces), one chipped
      s += `<rect y="${f1(WT + CAP - 0.2)}" width="80" height="0.8" fill="#000000" opacity="0.12" filter="url(#wb1)"/><rect y="${f1(WT)}" width="80" height="${CAP}" fill="url(#b01k)"/><rect y="${f1(WT + 0.15)}" width="80" height="0.2" fill="#ffffff" opacity="0.9"/>`
        + rep(15, i => `<rect x="${f1(i * TS * 2 - 0.1)}" y="${f1(WT)}" width="0.2" height="${CAP}" fill="#a8a494"/>`).join('') + `<path d="M35.4 ${f1(WT)}h1.6l-0.4 0.7h-0.9Z" fill="#b8b2a0"/><path d="M35.4 ${f1(WT)}l0.3 0.7h0.9l0.4 -0.7" stroke="#7a7464" stroke-width="0.07" fill="none"/>`;
      const board = '#d6d0bc';
      return { mat: s, sup: up, board,
        defs: `<clipPath id="b01c"><rect y="${f1(Y0)}" width="80" height="${f1(BB - Y0)}"/></clipPath>`
          + '<linearGradient id="b01g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b4b0a2"/><stop offset="0.55" stop-color="#8a8a78"/><stop offset="1" stop-color="#3c4232"/></linearGradient>'
          + '<linearGradient id="b01t" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.7"/><stop offset="0.35" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.8" stop-color="#8a8470" stop-opacity="0.06"/><stop offset="1" stop-color="#6a6450" stop-opacity="0.22"/></linearGradient>'
          + '<linearGradient id="b01k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="0.45" stop-color="#efece2"/><stop offset="1" stop-color="#b8b4a4"/></linearGradient>'
          + '<linearGradient id="b01m" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a4e3c" stop-opacity="0.22"/><stop offset="1" stop-color="#4a4e3c" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="b01r" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8a4a1e"/><stop offset="0.6" stop-color="#b0682a" stop-opacity="0.6"/><stop offset="1" stop-color="#c88a40" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.05, ao: 0.18, board: rep(28, i => `<rect x="${f1(i * TS - 0.1)}" y="${BB}" width="0.2" height="${f1(56 - BB)}" fill="#3c4232" opacity="0.7"/>`).join('') + `<rect y="${f1(BB + 0.45)}" width="80" height="0.4" fill="#ffffff" opacity="0.5"/>` + scf('b01b', 16, '#5a5a48', '#a8a490') } }; });

    // BTH-021 CLEAN MINT SUBWAY TILES WITH WHITE GROUT (T2): glossy 3x6 mint subway in running bond, every tile a slightly different mint with a
    // cushion glaze + crisp bevel, crisp white grout, one white accent row, a rounded white pencil liner, warm white eggshell paint above,
    // soft window reflections, a GFCI outlet with a green pilot light; white cove base. Live: a slow glint slides across the glaze.
    const bSub = memo('b21', () => { const R = rng('bs21'), WT = 13.6, Y0 = WT + 1.3, TW = 4, TH = 2, g = 0.17;
      let up = '<rect width="80" height="56" fill="#f2efe6"/>' + blot('bs21', 26, ['#f6f4ec', '#e8e4d8', '#f4f1e8'], 0.4, 3.2) + rep(60, () => `<circle cx="${f1(R() * 80)}" cy="${f1(R() * 56)}" r="0.1" fill="#dcd6c6" opacity="0.5"/>`).join('');
      const MT = ['#9fd6be', '#a7dbc4', '#98d0b8', '#ade0c9', '#a2d8c0', '#94ccb3'];
      let b = `<rect y="${f1(Y0)}" width="80" height="${f1(BB - Y0)}" fill="#f2f4f0"/>`;
      for (let i = 0; Y0 + i * TH < BB; i++) { const off = i % 2 ? TW / 2 : 0, wr = i === 2;
        for (let x0 = -off; x0 < 80; x0 += TW) { const x = x0 + g / 2, y = Y0 + i * TH + g / 2, w = TW - g, h = TH - g, c = wr ? (R() < 0.5 ? '#f6f8f5' : '#eef2ee') : MT[Math.floor(R() * MT.length)];
          b += `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" rx="0.22" fill="${c}"/><rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" rx="0.22" fill="url(#b21t)"/>`
            + `<path d="M${f1(x + 0.2)} ${f1(y + h - 0.25)}V${f1(y + 0.18)}H${f1(x + w - 0.25)}" stroke="#ffffff" stroke-width="0.12" fill="none" opacity="0.85"/><path d="M${f1(x + w - 0.12)} ${f1(y + 0.3)}V${f1(y + h - 0.12)}H${f1(x + 0.3)}" stroke="${wr ? '#c8ccc4' : '#6aa88e'}" stroke-width="0.1" fill="none" opacity="0.7"/>`
            + (R() < 0.35 ? `<ellipse cx="${f1(x + w * (0.25 + R() * 0.5))}" cy="${f1(y + h * 0.35)}" rx="${f1(0.4 + R() * 0.7)}" ry="0.14" fill="#ffffff" opacity="${f1(0.35 + R() * 0.3)}"/>` : ''); } }
      b += '<g filter="url(#wb2)"><path d="M14 18L21 18L15.4 52L8.4 52Z" fill="#ffffff" opacity="0.2"/><path d="M23 18L25.4 18L19.8 52L17.4 52Z" fill="#ffffff" opacity="0.16"/><path d="M56 18L59 18L54 52L51 52Z" fill="#ffffff" opacity="0.12"/></g>';
      b += `<rect x="-30" y="${f1(Y0)}" width="12" height="${f1(BB - Y0)}" fill="url(#b21s)" transform="skewX(-16)">${an('x', '-30;112;112', 16, 0, ' keyTimes="0;0.5;1"')}</rect>`;
      // GFCI outlet
      b += `<rect x="64.6" y="35.6" width="2.6" height="4" rx="0.3" fill="#000000" opacity="0.15" filter="url(#wb1)"/><rect x="64.4" y="35.2" width="2.6" height="4" rx="0.3" fill="#fbfbf8" stroke="#c8ccc4" stroke-width="0.1"/>`
        + [35.7, 37.9].map(y => `<rect x="${f1(65.1)}" y="${f1(y)}" width="0.2" height="0.5" fill="#5a5e58"/><rect x="${f1(66.1)}" y="${f1(y)}" width="0.2" height="0.5" fill="#5a5e58"/><path d="M65.55 ${f1(y + 0.75)}a0.15 0.15 0 0 1 0.3 0v0.15h-0.3Z" fill="#5a5e58"/>`).join('')
        + '<rect x="64.75" y="37.15" width="0.9" height="0.45" rx="0.1" fill="#ececE6" stroke="#b8bcb4" stroke-width="0.06"/><rect x="65.75" y="37.15" width="0.9" height="0.45" rx="0.1" fill="#ececE6" stroke="#b8bcb4" stroke-width="0.06"/>'
        + `<circle cx="66.6" cy="38.95" r="0.12" fill="#4ade80">${an('opacity', '0.6;1;0.6', 4, 0, SPL(2))}</circle><circle cx="66.6" cy="38.95" r="0.35" fill="#4ade80" opacity="0.2"/>`;
      let s = up + `<g clip-path="url(#b21c)">${b}</g>`;
      s += `<rect y="${f1(WT + 1.1)}" width="80" height="0.7" fill="#000000" opacity="0.12" filter="url(#wb1)"/><rect y="${f1(WT)}" width="80" height="1.3" rx="0.65" fill="url(#b21k)"/><rect y="${f1(WT + 0.2)}" width="80" height="0.2" fill="#ffffff"/>` + rep(10, i => `<rect x="${f1(i * 8 + 3.9)}" y="${f1(WT)}" width="0.15" height="1.3" fill="#d4d8d0"/>`).join('');
      const board = '#f2f3ee';
      return { mat: s, sup: up, board,
        defs: `<clipPath id="b21c"><rect y="${f1(Y0)}" width="80" height="${f1(BB - Y0)}"/></clipPath>`
          + '<linearGradient id="b21t" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.75"/><stop offset="0.3" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="0.75" stop-color="#2a6a52" stop-opacity="0"/><stop offset="1" stop-color="#2a6a52" stop-opacity="0.16"/></linearGradient>'
          + '<linearGradient id="b21k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="0.5" stop-color="#f2f4f0"/><stop offset="1" stop-color="#c4cac2"/></linearGradient>'
          + '<linearGradient id="b21s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.32"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.07, ao: 0.12, board: rep(20, i => `<rect x="${f1(i * 4 - 0.08)}" y="${BB}" width="0.16" height="${f1(56 - BB)}" fill="#d0d4cc"/>`).join('') + `<rect y="${f1(BB + 0.3)}" width="80" height="0.5" fill="#ffffff" opacity="0.8"/>` } }; });

    // BTH-041 MATTE SLATE STONE SLABS & CEDAR ACCENT WALL (T3): large staggered slate slabs floor to ceiling, each its own blue-grey with split cleft layers,
    // little step edges, iron-rust blooms, mica glints and a damp darkening near the floor, fine dark joints; matte black steel base. The cedar accent wall
    // is a ONE-OFF (S.one, centred on the back wall once): vertical red cedar tongue-and-groove boards with grain + knots in a black steel frame, washed
    // by a warm LED cove light from above that slowly breathes.
    const bSlate = memo('b41', () => { const R = rng('bs41'), SW = 80 / 3, SH = BB / 4;
      const PAL = ['#5a6068', '#646a70', '#555b63', '#6a6e70', '#5e6266', '#616468', '#52585e'];
      let s = '<rect width="80" height="56" fill="#24282c"/>', n = 0;
      for (let r = 0; r < 4; r++) for (let x0 = r % 2 ? -SW / 2 : 0; x0 < 80; x0 += SW) { const x = x0 + 0.18, y = r * SH + 0.18, w = SW - 0.36, h = SH - 0.36, c = PAL[n++ % PAL.length], id = 'b41s' + r + '_' + Math.round(x0);
        let t = `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="${c}"/>`;
        // cleft layers: wavy horizontal bands of a slightly different grey, each with a lit step edge and shadow
        let yy = y - 1; while (yy < y + h) { const th = 0.8 + R() * 2.4, sh2 = R() < 0.5 ? 1.07 : 0.93, P = rep(9, k => [x - 1 + k * (w + 2) / 8, yy + (R() - 0.5) * 0.8]);
          const top2 = 'M' + P.map(pt).join('L'), bot = P.slice().reverse().map(p => [p[0], p[1] + th]);
          t += `<path d="${top2}L${bot.map(pt).join('L')}Z" fill="${shade(c, sh2)}" opacity="${f1(0.3 + R() * 0.35)}"/>`;
          if (R() < 0.3) t += `<path d="${top2}" stroke="#8a9098" stroke-width="0.12" fill="none" opacity="0.7"/><path d="${'M' + P.map(p => pt([p[0], p[1] + 0.18])).join('L')}" stroke="#1e2226" stroke-width="0.14" fill="none" opacity="0.6"/>`;
          yy += th; }
        if (R() < 0.45) t += `<g filter="url(#wb2)"><ellipse cx="${f1(x + w * (0.2 + R() * 0.6))}" cy="${f1(y + h * (0.3 + R() * 0.4))}" rx="${f1(2 + R() * 4)}" ry="${f1(1 + R() * 1.6)}" fill="#b0683a" opacity="${f1(0.18 + R() * 0.16)}"/></g>`;
        t += `<g filter="url(#wb2)"><ellipse cx="${f1(x + R() * w)}" cy="${f1(y + R() * h)}" rx="${f1(4 + R() * 5)}" ry="${f1(1.5 + R() * 2)}" fill="${R() < 0.5 ? '#7a8088' : '#3e444a'}" opacity="0.3"/></g>`;
        t += rep(28, () => { const sx = x + R() * w, sy = y + R() * h; return `<path d="M${f1(sx)} ${f1(sy)}q${f1(1 + R() * 2)} ${f1((R() - 0.5) * 0.4)} ${f1(2 + R() * 4)} 0" stroke="${R() < 0.5 ? '#8a9098' : '#30363c'}" stroke-width="${f1(0.05 + R() * 0.08)}" fill="none" opacity="${f1(0.3 + R() * 0.4)}"/>`; }).join('');
        t += rep(14, () => `<circle cx="${f1(x + R() * w)}" cy="${f1(y + R() * h)}" r="0.08" fill="#e4e8ee" opacity="${f1(0.4 + R() * 0.5)}"/>`).join('');
        t += `<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="url(#b41e)"/><path d="M${f1(x)} ${f1(y + h)}V${f1(y)}H${f1(x + w)}" stroke="#7c838a" stroke-width="0.14" fill="none" opacity="0.7"/>`;
        s += `<clipPath id="${id}"><rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}"/></clipPath><g clip-path="url(#${id})">${t}</g>`; }
      s += '<rect y="38" width="80" height="18" fill="url(#b41d)"/>';
      // cedar accent panel (one-off)
      const CX0 = 15, CX1 = 65, CED = ['#b5653a', '#a85a32', '#c2784a', '#9c5230', '#b86c40', '#c98656', '#ad6036'];
      let one = `<rect x="${CX0 - 1.4}" y="-1" width="${CX1 - CX0 + 2.8}" height="${f1(BB + 1)}" fill="#000000" opacity="0.4" filter="url(#wb2)"/><rect x="${CX0 - 0.9}" y="0" width="${CX1 - CX0 + 1.8}" height="${BB}" fill="#1a1c1e"/>`;
      for (let x = CX0, i = 0; x < CX1 - 0.01; x += 2.5, i++) { const c = CED[(i * 5 + 3) % CED.length], w = Math.min(2.5, CX1 - x);
        one += `<rect x="${f1(x)}" width="${f1(w)}" height="${BB}" fill="${c}"/>`;
        one += rep(6, () => { const gx = x + 0.2 + R() * (w - 0.4); let d = `M${f1(gx)} 0`; for (let y = 4; y <= BB + 4; y += 4) d += `Q${f1(gx + (R() - 0.5) * 0.5)} ${f1(y - 2)} ${f1(gx + (R() - 0.5) * 0.3)} ${f1(y)}`; return `<path d="${d}" stroke="${R() < 0.6 ? shade(c, 0.78) : shade(c, 1.18)}" stroke-width="${f1(0.06 + R() * 0.1)}" fill="none" opacity="0.7"/>`; }).join('');
        if (R() < 0.3) { const ky = 4 + R() * 44, kx = x + w * (0.3 + R() * 0.4); one += `<ellipse cx="${f1(kx)}" cy="${f1(ky)}" rx="0.7" ry="1.6" fill="${shade(c, 0.8)}" opacity="0.6"/><ellipse cx="${f1(kx)}" cy="${f1(ky)}" rx="0.32" ry="0.7" fill="#4a2414"/><ellipse cx="${f1(kx)}" cy="${f1(ky)}" rx="0.95" ry="2.3" fill="none" stroke="${shade(c, 0.75)}" stroke-width="0.08"/>`; }
        one += `<rect x="${f1(x)}" width="0.16" height="${BB}" fill="#3a1a0c" opacity="0.7"/><rect x="${f1(x + 0.16)}" width="0.12" height="${BB}" fill="#ffd2a8" opacity="0.35"/>`; }
      one += `<rect x="${CX0}" width="${CX1 - CX0}" height="${BB}" fill="url(#b41w)"/><rect x="${CX0}" width="${CX1 - CX0}" height="${BB}" fill="url(#b41n)"/><path d="M${CX0} 0H${CX1}V30H${CX0}Z" fill="url(#b41l)" opacity="0.6">${an('opacity', '0.45;0.8;0.45', 8, 0, SPL(2))}</path>`
        + `<rect x="${CX0 - 0.9}" y="0" width="${CX1 - CX0 + 1.8}" height="1.2" fill="#1a1c1e"/><rect x="${CX0}" y="1.2" width="${CX1 - CX0}" height="0.3" fill="#ffe2b0">${an('opacity', '0.7;1;0.7', 8, 0, SPL(2))}</rect>`
        + `<path d="M${CX0 - 0.9} 0V${BB}M${CX1 + 0.9} 0V${BB}" stroke="#4a4e52" stroke-width="0.12"/>`;
      const board = '#202224';
      one = `<clipPath id="b41o"><rect y="-2" width="80" height="${f1(BB + 2)}"/></clipPath><g clip-path="url(#b41o)">${one}</g>`;
      return { mat: s, sup: s, one, board,
        defs: '<linearGradient id="b41e" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.06"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.16"/></linearGradient>'
          + '<linearGradient id="b41d" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#101418" stop-opacity="0"/><stop offset="1" stop-color="#101418" stop-opacity="0.32"/></linearGradient>'
          + '<linearGradient id="b41w" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000000" stop-opacity="0.22"/><stop offset="0.12" stop-color="#000000" stop-opacity="0"/><stop offset="0.88" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.22"/></linearGradient>'
          + '<linearGradient id="b41l" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0c8" stop-opacity="0.85"/><stop offset="0.3" stop-color="#ffd896" stop-opacity="0.3"/><stop offset="1" stop-color="#ffd896" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="b41n" x1="0" y1="0" x2="0" y2="1"><stop offset="0.3" stop-color="#2a1006" stop-opacity="0"/><stop offset="1" stop-color="#2a1006" stop-opacity="0.35"/></linearGradient>',
        ro: { top: 0.03, ao: 0.16, board: `<rect y="${BB}" width="80" height="0.3" fill="#8a7a5a" opacity="0.7"/>` + scf('b41b', 8, '#0e1012', '#4a4e52') } }; });

    // BTH-061 SEAMLESS TADELAKT MOROCCAN PLASTER & HINOKI WOOD (T4): warm sand tadelakt burnished to a soft waxy stone sheen (cloudy lime tones,
    // curved trowel burnish strokes, polished pinpoints), grazing scallops of warm light from above, a polished brass inlay line, then a pale golden
    // hinoki wainscot (fine straight grain, quiet board joints, cap rail); black basalt skirting with a brass edge to sit on the BTH-065 floor.
    // Live: a burnished sheen slowly drifts across the plaster.
    const bTad = memo('b61', () => { const R = rng('bt61'), HT = 35.2;
      let up = '<rect width="80" height="56" fill="#d6ae88"/>' + blot('bt61', 34, ['#dcb690', '#cfa680', '#e0bc98', '#d3aa84'], 0.4, 6);
      up += '<g filter="url(#wb1)">' + rep(70, () => { const x = R() * 84 - 2, y = R() * 58 - 1, l = 8 + R() * 12, h = (R() - 0.5) * 7, w = 1.6 + R() * 3, lt = R() < 0.7;
        return wrapX(x, l, xx => `<path d="M${f1(xx)} ${f1(y)}q${f1(l / 2)} ${f1(h)} ${f1(l)} ${f1(h * 0.15)}" stroke="${lt ? '#f4dcc0' : '#bd9470'}" stroke-width="${f1(w)}" stroke-linecap="round" fill="none" opacity="${f1(lt ? 0.16 : 0.1)}"/>`); }).join('') + '</g>';
      up += rep(40, () => `<circle cx="${f1(R() * 80)}" cy="${f1(R() * 56)}" r="0.08" fill="#fffaf0" opacity="${f1(0.4 + R() * 0.4)}"/>`).join('') + rep(70, () => `<circle cx="${f1(R() * 80)}" cy="${f1(R() * 56)}" r="0.06" fill="#8a6446" opacity="0.35"/>`).join('');
      up += '<g filter="url(#wb2)">' + [20, 60].map(x => `<path d="M${x - 6} -1H${x + 6}C${x + 12} 10 ${x + 10} 22 ${x} 28C${x - 10} 22 ${x - 12} 10 ${x - 6} -1Z" fill="url(#b61w)"/>`).join('') + '</g>';
      up += `<rect x="-24" width="20" height="56" fill="url(#b61s)" transform="skewX(-10)">${an('x', '-24;100', 18)}</rect>`;
      let s = up, h = '';
      const HN = ['#ead3a2', '#e6cd9a', '#eed9ac', '#e2c894', '#ecd5a6'];
      for (let x = 0, i = 0; x < 80; x += 4, i++) { const c = HN[(i * 3) % HN.length];
        h += `<rect x="${x}" y="${HT}" width="4" height="${f1(BB - HT)}" fill="${c}"/>` + rep(9, () => { const gx = x + 0.2 + R() * 3.6; return `<path d="M${f1(gx)} ${HT}L${f1(gx + (R() - 0.5) * 0.3)} ${BB}" stroke="${R() < 0.7 ? '#c8a874' : '#f8e8c4'}" stroke-width="${f1(0.05 + R() * 0.07)}" opacity="0.75"/>`; }).join('')
          + `<rect x="${x}" y="${HT}" width="0.14" height="${f1(BB - HT)}" fill="#8a6a3e" opacity="0.6"/><rect x="${f1(x + 0.14)}" y="${HT}" width="0.1" height="${f1(BB - HT)}" fill="#fff4dc" opacity="0.6"/>`; }
      h += `<rect y="${HT}" width="80" height="${f1(BB - HT)}" fill="url(#b61h)"/>`;
      s += h + `<rect y="${f1(HT - 0.2)}" width="80" height="1.6" fill="#000000" opacity="0.15" filter="url(#wb1)"/><rect y="${f1(HT - 1.2)}" width="80" height="1.4" fill="url(#b61c)"/><rect y="${f1(HT - 1.2)}" width="80" height="0.18" fill="#fff6dc"/>`
        + `<rect y="${f1(HT - 1.75)}" width="80" height="0.55" fill="url(#b61b)"/><rect y="${f1(HT - 1.7)}" width="80" height="0.12" fill="#fff4c8" opacity="0.9"/>`;
      const board = '#25221f';
      return { mat: s, sup: up, board,
        defs: '<linearGradient id="b61w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff4dc" stop-opacity="0.6"/><stop offset="0.5" stop-color="#ffe8c4" stop-opacity="0.22"/><stop offset="1" stop-color="#ffe8c4" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="b61s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff6e8" stop-opacity="0"/><stop offset="0.5" stop-color="#fff6e8" stop-opacity="0.18"/><stop offset="1" stop-color="#fff6e8" stop-opacity="0"/></linearGradient>'
          + '<linearGradient id="b61h" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a3c18" stop-opacity="0.14"/><stop offset="0.25" stop-color="#ffffff" stop-opacity="0.06"/><stop offset="1" stop-color="#5a3c18" stop-opacity="0.1"/></linearGradient>'
          + '<linearGradient id="b61c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f6e2b6"/><stop offset="0.5" stop-color="#e2c690"/><stop offset="1" stop-color="#b8965e"/></linearGradient>'
          + '<linearGradient id="b61b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset="0.5" stop-color="#d4a84e"/><stop offset="1" stop-color="#8a6420"/></linearGradient>',
        ro: { top: 0.04, ao: 0.12, board: `<rect y="${BB}" width="80" height="0.35" fill="#e2b456"/><rect y="${f1(BB + 0.35)}" width="80" height="0.12" fill="#fff0b8" opacity="0.8"/>` + rep(30, () => `<circle cx="${f1(R() * 80)}" cy="${f1(BB + 0.8 + R() * 1.4)}" r="0.08" fill="#c8c0b0" opacity="0.5"/>`).join('') } }; });

    // BTH-081 BACKLIT TRANSLUCENT ONYX & SELF-CLEANING NANO-CERAMIC (T5): book-matched honey onyx floor to ceiling on the upper wall (nested wavy growth
    // bands in amber, cream and caramel, milky crystal zones, dark resin veins), lit from behind with a warm glow that breathes; polished brass band;
    // below, pearl-white nano-ceramic panels on brass hairline seams where water beads gather, roll off and a clean sheen wipes down after them;
    // bronze plinth with a champagne light line.
    const bOnyx = memo('b81', () => { const R = rng('bo81'), CT = 39.4;
      let hf = '<rect width="40" height="56" fill="#efc47a"/><g clip-path="url(#b81h)">';
      const BC = ['#e9b860', '#f6d79a', '#d99a48', '#fbe6b8', '#c98538', '#f2c676', '#e4a85a', '#fdf0d0'];
      [[14, 15, 34, 'a'], [33, 45, 24, 'b'], [5, 47, 13, 'c'], [36, 12, 9, 'd']].forEach(([cx, cy, r0, sd]) => { const Q = rng('onx' + sd), ph = rep(4, () => Q() * 2 * PI), am = [0.1 + Q() * 0.06, 0.07 + Q() * 0.05, 0.05, 0.035];
        for (let k = 0, r = r0; r > 0.8; k++, r *= 0.93 - Q() * 0.04) { const P = rep(44, i => { const t = i / 44 * 2 * PI, rr = r * (1 + am[0] * Math.sin(2 * t + ph[0] + k * 0.08) + am[1] * Math.sin(3 * t + ph[1] - k * 0.1) + am[2] * Math.sin(5 * t + ph[2]) + am[3] * Math.sin(8 * t + ph[3] + k * 0.3));
            return [cx + Math.cos(t) * rr * 1.25, cy + Math.sin(t) * rr * 0.85]; }), d = smooth(P), c = BC[(k * 3 + (sd === 'b' ? 2 : 0)) % BC.length];
          hf += `<path d="${d}" fill="${c}" opacity="${f1(0.3 + Q() * 0.35)}"${Q() < 0.85 ? ' filter="url(#wb1)"' : ''}/>` + (Q() < 0.4 ? `<path d="${d}" fill="none" stroke="${Q() < 0.45 ? '#c07a28' : '#fffaf0'}" stroke-width="${f1(0.05 + Q() * 0.08)}" opacity="${f1(0.18 + Q() * 0.25)}"/>` : ''); } });
      hf += '<g filter="url(#wb2)"><ellipse cx="24" cy="8" rx="9" ry="4" fill="#fff8e8" opacity="0.55"/><ellipse cx="8" cy="30" rx="5" ry="8" fill="#fff8e8" opacity="0.45"/><ellipse cx="32" cy="27" rx="7" ry="3" fill="#ffffff" opacity="0.4"/><ellipse cx="18" cy="50" rx="8" ry="3" fill="#fff4dc" opacity="0.35"/></g>';
      [[[0, 22], [6, 21], [12, 25], [19, 24], [26, 29], [34, 28], [40, 31]], [[22, 0], [23, 6], [20, 12], [22, 18]], [[40, 9], [35, 12], [31, 11], [27, 15]]].forEach((P, i) => hf += `<g filter="url(#wb2)">${sv(P, '#9a5a1e', 1.6, 0.3)}</g><g filter="url(#wb1)">${sv(P, '#7a4014', f1(0.25 + i * 0.05), 0.4)}</g>`);
      hf += rep(80, () => `<circle cx="${f1(R() * 40)}" cy="${f1(R() * 56)}" r="${f1(0.05 + R() * 0.12)}" fill="${R() < 0.5 ? '#7a4416' : '#fffaf0'}" opacity="${f1(0.3 + R() * 0.4)}"/>`).join('') + '</g>';
      let stone = `<g id="b81H">${hf}</g><use href="#b81H" transform="translate(80 0) scale(-1 1)"/>`
        + `<rect width="80" height="56" fill="url(#b81g)">${an('opacity', '0.45;0.85;0.45', 10, 0, SPL(2))}</rect><rect width="80" height="56" fill="url(#b81v)"/>`
        + [0, 40, 80].map(x => `<rect x="${f1(x - 0.2)}" width="0.4" height="56" fill="url(#b81b)"/>`).join('');
      let c = `<rect y="${CT}" width="80" height="${f1(BB - CT)}" fill="url(#b81c)"/>` + [0, 20, 40, 60, 80].map(x => `<rect x="${f1(x - 0.12)}" y="${CT}" width="0.24" height="${f1(BB - CT)}" fill="url(#b81b)"/>`).join('');
      c += rep(26, () => { const x = 1 + R() * 78, y = CT + 1.2 + R() * (BB - CT - 2.4), r = 0.12 + R() * 0.2; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="#dfe6ea" opacity="0.55"/><circle cx="${f1(x - r * 0.35)}" cy="${f1(y - r * 0.35)}" r="${f1(r * 0.35)}" fill="#ffffff" opacity="0.9"/>`; }).join('');
      c += [[7, 2], [26, 6.4], [47, 0.8], [66, 4.2], [33, 9.6], [72, 8]].map(([x, ph]) => `<g opacity="0">${an('opacity', '0;0.9;0.9;0', 12, -ph, KT('0;0.1;0.55;0.62'))}<g>${at('translate', '0 0;0 0;0 11.5;0 11.5', 12, -ph, KT('0;0.25;0.6;1'))}<path d="M${x} ${f1(CT + 1.4)}V${f1(CT + 0.4)}" stroke="#ffffff" stroke-width="0.12" opacity="0.5"/><ellipse cx="${x}" cy="${f1(CT + 1.6)}" rx="0.3" ry="0.38" fill="#dfe8ec"/><circle cx="${f1(x - 0.1)}" cy="${f1(CT + 1.45)}" r="0.12" fill="#ffffff"/></g></g>`).join('');
      c += `<rect y="${f1(CT - 4)}" width="80" height="4" fill="url(#b81w)" opacity="0">${at('translate', `0 0;0 0;0 ${f1(BB - CT + 4)}`, 12, 0, KT('0;0.6;1'))}${an('opacity', '0;0;0.9;0', 12, 0, KT('0;0.6;0.65;1'))}</rect>`;
      let s = stone + `<g clip-path="url(#b81k)">${c}</g>` + `<rect y="${f1(CT - 0.2)}" width="80" height="1.4" fill="#000000" opacity="0.18" filter="url(#wb1)"/><rect y="${f1(CT - 0.9)}" width="80" height="1.1" fill="url(#b81p)"/><rect y="${f1(CT - 0.85)}" width="80" height="0.16" fill="#fff6d0"/>`;
      const board = '#5a4026';
      return { mat: s, sup: stone, board,
        defs: `<clipPath id="b81h"><rect width="40" height="56"/></clipPath><clipPath id="b81k"><rect y="${CT}" width="80" height="${f1(BB - CT)}"/></clipPath>`
          + '<radialGradient id="b81g" cx="50%" cy="40%" r="70%"><stop offset="0" stop-color="#fff6de" stop-opacity="0.75"/><stop offset="0.6" stop-color="#ffd890" stop-opacity="0.15"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient>'
          + '<linearGradient id="b81v" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="0.4" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#6a3a10" stop-opacity="0.08"/></linearGradient>'
          + '<linearGradient id="b81b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset="0.4" stop-color="#d8ac58"/><stop offset="1" stop-color="#8a6420"/></linearGradient>'
          + '<linearGradient id="b81p" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset="0.45" stop-color="#d8ac58"/><stop offset="1" stop-color="#7a5418"/></linearGradient>'
          + '<linearGradient id="b81c" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fbfaf7"/><stop offset="0.45" stop-color="#f0ede7"/><stop offset="0.55" stop-color="#f6f4ef"/><stop offset="1" stop-color="#e2ddd4"/></linearGradient>'
          + '<linearGradient id="b81w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0.55"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>',
        ro: { top: 0.04, ao: 0.1, board: `<rect y="${BB}" width="80" height="0.4" fill="#f2d58a"/><rect y="${f1(BB + 0.4)}" width="80" height="0.3" fill="#fff0c0" opacity="0.7"/>` + rep(16, i => `<rect x="${f1(i * 5 + 1)}" y="${f1(BB + 1)}" width="3" height="0.9" rx="0.2" fill="#3a2810" opacity="0.6"/>`).join('') + `<rect y="${f1(56 - 0.4)}" width="80" height="0.4" fill="#ffe2a0" opacity="0.6">${an('opacity', '0.45;0.75;0.45', 6, 0, SPL(2))}</rect>` } }; });

    Object.assign(SURF12, { b01tile: bTile, b21sub: bSub, b41slate: bSlate, b61tad: bTad, b81onyx: bOnyx });
  }

  // ======================= WALL ACCENTS (BTH-004/024/044/064/084): wall pieces (mount 'wall', D.fx via H.cam + RD.H15 box3/cyl3), same build as the Kitchen accents in plus27 =======================
  { const { tanF, FR } = H, { box3, cyl3 } = RD.H15, { WD } = RD.H12, { ext } = RD.H11, DEF19 = RD.H19.DEF19;
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const line3 = (C, P, w, col, ex) => '<path d="M' + P.map(p => PP(C, p)).join('L') + '" stroke="' + col + '" stroke-width="' + f1(w * C.k) + '" fill="none" stroke-linecap="round" stroke-linejoin="round"' + (ex ? ' ' + ex : '') + '/>';
    const swayAt = (C, p, a, d, ph, inner) => { const q = C.P(p), o = f1(q[0]) + ' ' + f1(q[1]); return '<g>' + at('rotate', (-a) + ' ' + o + ';' + a + ' ' + o + ';' + (-a) + ' ' + o, d, -ph, SPL(2)) + inner + '</g>'; };
    const sp3 = (C, q, r, col) => H.sph(C, q, r, col);
    const shW = (C, x, y, w, h, rx, op) => WD(C, x + 1.4, y - 2.2, 0.05, `<rect width="${f1(w)}" height="${f1(h)}" rx="${rx || 1}" fill="#000000" opacity="${op || 0.3}" filter="url(#m10b3)"/>`);
    const SERIF = "Georgia,'Times New Roman',serif", HAND = "'Segoe Print','Comic Sans MS','Marker Felt',cursive", SANS = 'Arial,Helvetica,sans-serif';
    const nail = (C, x, y) => cyl3(C, [x, y, 0], [x, y, 0.8], 0.22, '#8a8478', { n: 8 }) + cyl3(C, [x, y, 0.8], [x, y, 1], 0.5, '#a8a294', { n: 12 });

    // BTH-004 PEELING 'WASH YOUR HANDS' VINYL STICKER (T1): a sun-faded vinyl sticker (cartoon hands under a tap, soap bubbles, '20 SEC!' burst) with air
    // bubbles, scratches, grime round the edge; its top corner has peeled and folded over showing the paper-grey back and a tacky dust-caught patch, and it
    // flutters in the draught; the ghost + tape scraps of an older sticker; a cloudy suction-cup hook that has slid down the wall (smear trail) holding a
    // pink mesh loofah on a cord that sways and drips.
    N.sticker29 = S => { const D = { w: 72, d: 10, mount: 'wall', elev: 40, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('sticker29'), id = C.u('b04');
        ext(C, [[-36, 30, 0], [36, -22, 0], [36, -22, 8]]);
        let s = WD(C, -33, 27, 0.03, '<rect width="15" height="11" rx="1.2" fill="#d8ceb2" opacity="0.28"/><rect width="15" height="11" rx="1.2" fill="none" stroke="#8a826c" stroke-width="0.3" stroke-dasharray="1.6 0.6 0.4 0.8" opacity="0.4"/>'
          + '<rect x="-1" y="-0.6" width="4" height="1.6" fill="#ece4c8" opacity="0.7" transform="rotate(-8)"/><rect x="12.4" y="9.6" width="3.6" height="1.5" fill="#ece4c8" opacity="0.6" transform="rotate(6 14 10)"/><path d="M3 4l1.6 0.4M9 6.6l2 -0.3" stroke="#6a6250" stroke-width="0.12" opacity="0.4"/>');
        // sticker art 30 x 24 (corner 24..30 x 0..6 peeled)
        const SW = 30, SH = 24, BODY = 'M2 0H24L30 6V22Q30 24 28 24H2Q0 24 0 22V2Q0 0 2 0Z';
        let a = `<path d="${BODY}" fill="#f6f2e4"/><path d="${BODY}" fill="none" stroke="#6e9ec0" stroke-width="0.9"/><path d="M1.6 1.6H23.4L28.4 6.6V21.6Q28.4 22.4 27.6 22.4H2.4Q1.6 22.4 1.6 21.6Z" fill="none" stroke="#a8c8de" stroke-width="0.25"/>`;
        a += `<text x="12.6" y="5.6" text-anchor="middle" font-family="${SANS}" font-weight="900" font-size="3.4" fill="#4a86b8" letter-spacing="0.2">WASH</text><text x="15" y="9.4" text-anchor="middle" font-family="${SANS}" font-weight="900" font-size="3" fill="#4a86b8">YOUR HANDS</text>`;
        // tap + water + hands + bubbles
        a += '<path d="M4 11.4H10.6Q12 11.4 12 12.8V13.6H10.4V13.2H4Z" fill="#9aa4ac" stroke="#5a646c" stroke-width="0.2"/><rect x="6.4" y="10.4" width="1.6" height="1" rx="0.3" fill="#c84a3a"/><path d="M10.6 13.8Q11 16 10.8 18" stroke="#7ab8e8" stroke-width="1" stroke-linecap="round" opacity="0.8"/>';
        a += '<path d="M8.4 21.4Q7 18.4 9.2 16.8Q11 15.8 12.4 17.2Q14 18.6 12.8 21Z" fill="#f4c4a0" stroke="#b07a58" stroke-width="0.22"/><path d="M13.2 21.6Q12.4 18.6 14.6 17.4Q16.8 16.6 17.6 18.6Q18.2 20.6 16.6 21.8Z" fill="#f8cfac" stroke="#b07a58" stroke-width="0.22"/><path d="M10 18.6l1 -0.4M10.2 19.8l1.1 -0.3M15 19l1 0.3M15 20.2l1 0.3" stroke="#b07a58" stroke-width="0.16"/>';
        a += [[9, 15.6, 0.8], [14.2, 16, 1.1], [17.4, 16.4, 0.7], [12, 21.6, 0.6], [18.4, 20, 0.9], [7.4, 19.6, 0.5]].map(([x, y, r]) => `<circle cx="${x}" cy="${y}" r="${r}" fill="#dceef8" stroke="#8ab8d8" stroke-width="0.15"/><circle cx="${f1(x - r * 0.35)}" cy="${f1(y - r * 0.35)}" r="${f1(r * 0.28)}" fill="#ffffff"/>`).join('');
        a += '<g transform="translate(24 16.4)"><path d="' + rep(16, i => { const t = i / 16 * 2 * PI, r = i % 2 ? 3 : 4.2; return (i ? 'L' : 'M') + f1(Math.cos(t) * r) + ' ' + f1(Math.sin(t) * r); }).join('') + 'Z" fill="#f2a848" stroke="#c8782a" stroke-width="0.2"/>'
          + `<text y="-0.2" text-anchor="middle" font-family="${SANS}" font-weight="900" font-size="1.9" fill="#ffffff">20</text><text y="1.6" text-anchor="middle" font-family="${SANS}" font-weight="700" font-size="1.1" fill="#ffffff">SEC!</text></g>`;
        // age: fading, scratches, grime, air bubbles
        a += `<path d="${BODY}" fill="#fff4cc" opacity="0.3"/><path d="${BODY}" fill="url(#${id}f)"/>` + rep(14, () => { const x = 2 + R() * 26, y = 2 + R() * 20; return `<path d="M${f1(x)} ${f1(y)}l${f1(1 + R() * 3)} ${f1((R() - 0.5) * 1.6)}" stroke="#ffffff" stroke-width="0.12" opacity="0.7"/>`; }).join('')
          + `<path d="${BODY}" fill="none" stroke="#6a5e44" stroke-width="0.5" opacity="0.3"/>`
          + [[6, 8.4, 1.1], [21, 12.4, 0.8], [26.4, 20.6, 0.9], [3.4, 15, 0.6]].map(([x, y, r]) => `<circle cx="${x}" cy="${y}" r="${r}" fill="#ffffff" opacity="0.25"/><path d="M${f1(x - r * 0.7)} ${f1(y - r * 0.2)}A${r} ${r} 0 0 1 ${f1(x + r * 0.3)} ${f1(y - r * 0.9)}" stroke="#ffffff" stroke-width="0.2" fill="none"/><path d="M${f1(x + r * 0.7)} ${f1(y + r * 0.3)}A${r} ${r} 0 0 1 ${f1(x - r * 0.2)} ${f1(y + r * 0.95)}" stroke="#8a826c" stroke-width="0.15" fill="none" opacity="0.6"/>`).join('');
        // peeled corner: tacky patch, shadow, folded flap that flutters
        a += '<path d="M24 0H30V6Z" fill="#cfc7b0" opacity="0.7"/>' + rep(7, () => `<circle cx="${f1(25.5 + R() * 3.6)}" cy="${f1(0.6 + R() * 2.6)}" r="0.12" fill="#4a4436" opacity="0.6"/>`).join('');
        const fl = (x, y) => `M24 0L30 6L${x} ${y}Z`;
        a += `<path d="${fl(25.2, 4.6)}" fill="#000000" opacity="0.25" filter="url(#m12b1)" transform="translate(0.6 0.8)">${an('d', fl(25.2, 4.6) + ';' + fl(26.4, 3.4) + ';' + fl(25.6, 4.2) + ';' + fl(25.2, 4.6), 3.6, 0, SPL(3))}</path>`
          + `<path d="${fl(25.2, 4.6)}" fill="url(#${id}b)" stroke="#a8a090" stroke-width="0.15">${an('d', fl(25.2, 4.6) + ';' + fl(26.4, 3.4) + ';' + fl(25.6, 4.2) + ';' + fl(25.2, 4.6), 3.6, 0, SPL(3))}</path>`;
        s += WD(C, -16, 26.4, 0.06, `<g transform="rotate(-2.4 15 12)"><path d="${BODY}" fill="#000000" opacity="0.15" transform="translate(0.4 0.5)" filter="url(#m12b1)"/>${a}</g>`);
        // suction cup hook (slid down: smear trail), cord + pink mesh loofah sways, drip
        const HX = 24, HY = 12;
        s += WD(C, HX - 2, HY + 13, 0.03, '<g filter="url(#m12b1)"><path d="M2 0.4V9" stroke="#b8bcb0" stroke-width="4.4" opacity="0.14" stroke-linecap="round"/></g><ellipse cx="2" cy="0.4" rx="2.4" ry="0.8" fill="#a8a088" opacity="0.18"/>');
        s += WD(C, HX - 3.4, HY + 3.4, 0.08, `<circle cx="3.4" cy="3.4" r="3.4" fill="url(#${id}c)"/><circle cx="3.4" cy="3.4" r="3.3" fill="none" stroke="#ffffff" stroke-width="0.25" opacity="0.6"/><circle cx="3.4" cy="3.4" r="2.2" fill="none" stroke="#c8d0d0" stroke-width="0.15" opacity="0.7"/><path d="M1.4 1.8A2.6 2.6 0 0 1 3.4 0.9" stroke="#ffffff" stroke-width="0.35" fill="none" opacity="0.9"/>`);
        s += cyl3(C, [HX, HY, 0.2], [HX, HY, 2.2], 0.75, '#e8eeee', { n: 12, op: 0.85 }) + line3(C, [[HX, HY, 2.2], [HX, HY - 0.4, 3.6], [HX, HY - 2.2, 3.8], [HX, HY - 2.8, 3.2]], 0.55, '#f2f4f2');
        const meshP = `<pattern id="${id}m" width="0.9" height="0.9" patternUnits="userSpaceOnUse" patternTransform="rotate(30)"><path d="M0 0.45H0.9M0.45 0V0.9" stroke="#c84a7a" stroke-width="0.1"/></pattern>`;
        let loof = line3(C, [[HX, HY - 1.6, 3.6], [HX - 1.2, HY - 5, 3.8], [HX, HY - 7, 4], [HX + 1.2, HY - 5, 3.8], [HX, HY - 1.6, 3.6]], 0.25, '#f2f0e8');
        loof += WD(C, HX - 7, HY - 6, 4.4, [[3, 4.2, 3.2], [7, 3.2, 3.6], [11, 4.6, 3], [5, 7.6, 3.4], [9.4, 8, 3.2], [7, 10.4, 2.6], [3.4, 9.8, 2], [11.4, 9.4, 2]].map(([x, y, r], i) => `<circle cx="${x}" cy="${y}" r="${r}" fill="${i % 2 ? '#f48ab2' : '#f6a0c0'}"/><circle cx="${x}" cy="${y}" r="${r}" fill="url(#${id}m)" opacity="0.8"/><path d="M${f1(x - r * 0.8)} ${f1(y - r * 0.2)}Q${x} ${f1(y - r * 1.1)} ${f1(x + r * 0.8)} ${f1(y - r * 0.2)}" stroke="#ffd2e2" stroke-width="0.3" fill="none" opacity="0.8"/><path d="M${f1(x - r * 0.7)} ${f1(y + r * 0.5)}Q${x} ${f1(y + r)} ${f1(x + r * 0.7)} ${f1(y + r * 0.5)}" stroke="#a83a64" stroke-width="0.25" fill="none" opacity="0.5"/>`).join('')
          + `<ellipse cx="7" cy="12.6" rx="0.45" ry="0.6" fill="#cfe4ee" opacity="0">${an('opacity', '0;0.9;0.9;0', 5, 0, KT('0;0.4;0.7;0.75'))}${an('cy', '12.4;12.9;13.2;21', 5, 0, KT('0;0.4;0.7;0.95'))}</ellipse>`);
        s += swayAt(C, [HX, HY - 2.6, 3.4], 3, 4.6, 0.6, loof);
        return { defs: DEF19 + `<defs>${meshP}<linearGradient id="${id}f" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.25"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#8a7a4a" stop-opacity="0.12"/></linearGradient>`
          + `<linearGradient id="${id}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#d8d4ca"/><stop offset="1" stop-color="#b8b2a4"/></linearGradient><radialGradient id="${id}c" cx="45%" cy="40%" r="60%"><stop offset="0" stop-color="#f4f8f8" stop-opacity="0.75"/><stop offset="0.8" stop-color="#d8e2e2" stop-opacity="0.55"/><stop offset="1" stop-color="#b8c4c4" stop-opacity="0.8"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BTH-024 FRAMED BOTANICAL SEAWEED PRINTS (T2): three pressed-seaweed specimens on cream rag paper, in pale oak frames with white mats + glass sheen,
    // hung on picture wire from nails: red Plocamium (fine branching fronds), translucent green Ulva sea lettuce, olive Fucus bladder wrack (forked straps,
    // midribs, paired air bladders), each with a handwritten label + specimen number; a little orange starfish tucked into the corner of one frame.
    // Live: the crooked right frame gently sways on its wire.
    N.seaweed29 = S => { const D = { w: 96, d: 8, mount: 'wall', elev: 46, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('seaweed29'), id = C.u('b24'), OAK = '#d6b486';
        ext(C, [[-46, 40, 0], [46, -2, 0], [46, -2, 6]]);
        const paper = (W2, H2) => `<rect width="${W2}" height="${H2}" fill="#f5eedc"/>` + rep(10, () => `<circle cx="${f1(R() * W2)}" cy="${f1(R() * H2)}" r="${f1(0.15 + R() * 0.4)}" fill="#c8a870" opacity="${f1(0.12 + R() * 0.15)}"/>`).join('') + `<rect width="${W2}" height="${H2}" fill="url(#${id}v)"/>`;
        // Plocamium: recursive red fronds with comb-like side branchlets
        const ploc = () => { let o = ''; const br = (x, y, a, L, d) => { if (d > 4 || L < 0.8) return; const x2 = x + Math.cos(a) * L, y2 = y + Math.sin(a) * L; o += `<path d="M${f1(x)} ${f1(y)}Q${f1((x + x2) / 2 + Math.sin(a) * 0.4)} ${f1((y + y2) / 2)} ${f1(x2)} ${f1(y2)}" stroke="${d < 2 ? '#a8242c' : '#c83a3e'}" stroke-width="${f1(0.42 - d * 0.07)}" fill="none" stroke-linecap="round"/>`;
            for (let t = 0.3; t < 1; t += 0.22) { const px = x + (x2 - x) * t, py = y + (y2 - y) * t, sg = Math.round(t * 10) % 2 ? 1 : -1; o += `<path d="M${f1(px)} ${f1(py)}l${f1(Math.cos(a + sg * 0.9) * 0.7)} ${f1(Math.sin(a + sg * 0.9) * 0.7)}" stroke="#d04a4a" stroke-width="0.12" stroke-linecap="round"/>`; }
            br(x2, y2, a - 0.45 - R() * 0.2, L * 0.72, d + 1); br(x2, y2, a + 0.4 + R() * 0.2, L * 0.68, d + 1); };
          br(7, 16, -PI / 2 - 0.1, 4.6, 0); return o + '<path d="M7 16v1.6" stroke="#8a1a22" stroke-width="0.4"/>'; };
        // Ulva: layered translucent ruffled sheets
        const ulva = () => { let o = ''; [[10, 13, 7, 9, '#7cc46a', 0], [8.4, 15, 5, 6.4, '#5eae52', 1], [12.4, 11, 4.6, 6, '#94d47e', 2], [10.4, 17, 4, 4.2, '#4e9a46', 3]].forEach(([cx, cy, rx, ry, c, k]) => {
            const P = rep(26, i => { const t = i / 26 * 2 * PI, w = 1 + 0.12 * Math.sin(7 * t + k) + 0.08 * Math.sin(13 * t + k * 2); return [cx + Math.cos(t) * rx * w, cy + Math.sin(t) * ry * w]; });
            const d = 'M' + P.map(pt).join('L') + 'Z'; o += `<path d="${d}" fill="${c}" opacity="0.55"/><path d="${d}" fill="none" stroke="${shade(c, 0.7)}" stroke-width="0.12" opacity="0.7"/>` + rep(4, j => `<path d="M${f1(cx)} ${f1(cy + ry * 0.7)}Q${f1(cx + (j - 1.5) * rx * 0.3)} ${f1(cy)} ${f1(cx + (j - 1.5) * rx * 0.55)} ${f1(cy - ry * 0.7)}" stroke="#e8f8d8" stroke-width="0.08" fill="none" opacity="0.6"/>`).join(''); });
          return o + '<path d="M10.4 21v1.6" stroke="#3e7a36" stroke-width="0.4"/>'; };
        // Fucus: forked olive straps with midrib + paired bladders
        const fucus = () => { let o = '', mid = ''; const st = (x, y, a, L, d) => { const x2 = x + Math.cos(a) * L, y2 = y + Math.sin(a) * L, w = 1.1 - d * 0.16, nx = -Math.sin(a) * w / 2, ny = Math.cos(a) * w / 2;
            o += `<path d="M${f1(x + nx)} ${f1(y + ny)}L${f1(x2 + nx)} ${f1(y2 + ny)}Q${f1(x2 + Math.cos(a) * w * 0.5)} ${f1(y2 + Math.sin(a) * w * 0.5)} ${f1(x2 - nx)} ${f1(y2 - ny)}L${f1(x - nx)} ${f1(y - ny)}Z" fill="${d % 2 ? '#8a7a32' : '#7a6a2a'}"/>`;
            mid += `<path d="M${f1(x)} ${f1(y)}L${f1(x2)} ${f1(y2)}" stroke="#4e4218" stroke-width="0.12"/>`;
            if (d > 0 && d < 3) [0.4, 0.75].forEach(t => [-1, 1].forEach(sg => { const px = x + (x2 - x) * t + sg * nx * 1.2, py = y + (y2 - y) * t + sg * ny * 1.2; o += `<ellipse cx="${f1(px)}" cy="${f1(py)}" rx="${f1(w * 0.55)}" ry="${f1(w * 0.42)}" fill="#9a8a3e"/><ellipse cx="${f1(px - 0.15)}" cy="${f1(py - 0.15)}" rx="${f1(w * 0.2)}" ry="${f1(w * 0.14)}" fill="#d8c88a" opacity="0.7"/>`; }));
            if (d < 3) { st(x2, y2, a - 0.38, L * 0.8, d + 1); st(x2, y2, a + 0.38, L * 0.8, d + 1); } };
          st(8, 17, -PI / 2, 3.6, 0); return o + mid + '<path d="M8 17v1.4" stroke="#4e4218" stroke-width="0.5"/>'; };
        const label = (x, y, t, n) => `<text x="${x}" y="${y}" text-anchor="middle" font-family="${HAND}" font-style="italic" font-size="0.95" fill="#4a3a2a">${t}</text><text x="${x}" y="${f1(y + 1.2)}" text-anchor="middle" font-family="${SERIF}" font-size="0.7" fill="#7a6a54">No. ${n}</text>`;
        const frame = (cx, yB, FW, FH, art, AW, AH, lab, extra) => { const M = 2.6, face = `<rect width="${FW}" height="${FH}" fill="url(#${id}o)"/>` + rep(10, () => `<path d="M${f1(R() * (FW - 6))} ${f1(R() * FH)}h${f1(2 + R() * 4)}" stroke="#b8945e" stroke-width="0.12" opacity="0.5"/>`).join('')
            + `<path d="M0 0L1.6 1.6M${FW} 0L${FW - 1.6} 1.6M0 ${FH}L1.6 ${FH - 1.6}M${FW} ${FH}L${FW - 1.6} ${FH - 1.6}" stroke="#a88456" stroke-width="0.15"/><rect x="1.6" y="1.6" width="${FW - 3.2}" height="${FH - 3.2}" fill="#fbf8f0"/><rect x="1.6" y="1.6" width="${FW - 3.2}" height="0.4" fill="#000000" opacity="0.12"/>`
            + `<rect x="${f1(1.6 + M - 0.15)}" y="${f1(1.6 + M - 0.15)}" width="${f1(FW - 3.2 - 2 * M + 0.3)}" height="${f1(FH - 3.2 - 2 * M + 0.3)}" fill="#d8d2c2"/><g transform="translate(${f1(1.6 + M)} ${f1(1.6 + M)})">${paper(AW, AH)}${art}${lab}</g>${extra || ''}`
            + `<path d="M1.6 1.6H${f1(FW * 0.45)}L${f1(FW * 0.2)} ${FH - 1.6}H1.6Z" fill="#ffffff" opacity="0.1"/><path d="M${f1(FW * 0.55)} 1.6H${f1(FW * 0.62)}L${f1(FW * 0.38)} ${FH - 1.6}H${f1(FW * 0.31)}Z" fill="#ffffff" opacity="0.08"/>`;
          return shW(C, cx - FW / 2, yB + FH, FW, FH, 0.5, 0.32) + box3(C, { c: [cx, yB, 0.9], w: FW, h: FH, d: 1.8, col: OAK, r: 0.25, dec: { f: face } }); };
        const wire = (cx, yT, ny, FW) => line3(C, [[cx - FW * 0.38, yT - 3, 0.6], [cx, ny, 0.9], [cx + FW * 0.38, yT - 3, 0.6]], 0.14, '#9a9488') + nail(C, cx, ny);
        let s = '';
        s += wire(-29, 30, 33.4, 17) + frame(-29, 6, 17, 24, `<g transform="translate(0.3 0.4) scale(0.95)">${ploc()}</g>`, 17 - 3.2 - 5.2, 24 - 3.2 - 5.2, label(4.3, 14.4, 'Plocamium', 12));
        s += wire(0, 35, 38.4, 21) + frame(0, 4, 21, 31, `<g transform="translate(-2.4 -1.6) scale(0.95)">${ulva()}</g>`, 21 - 3.2 - 5.2, 31 - 3.2 - 5.2, label(6.3, 20.6, 'Ulva lactuca', 7));
        const star = `<g transform="translate(13.6 20.4) rotate(18)">${rep(5, i => { const t = -PI / 2 + i * 2 * PI / 5; return `<path d="M0 0L${f1(Math.cos(t - 0.3) * 0.9)} ${f1(Math.sin(t - 0.3) * 0.9)}L${f1(Math.cos(t) * 2.4)} ${f1(Math.sin(t) * 2.4)}L${f1(Math.cos(t + 0.3) * 0.9)} ${f1(Math.sin(t + 0.3) * 0.9)}Z" fill="#f08a4a" stroke="#c8602a" stroke-width="0.1"/>`; }).join('')}${rep(10, i => { const t = i * 0.63; return `<circle cx="${f1(Math.cos(t) * (0.6 + (i % 3) * 0.5))}" cy="${f1(Math.sin(t) * (0.6 + (i % 3) * 0.5))}" r="0.12" fill="#ffd2a8"/>`; }).join('')}</g>`;
        s += swayAt(C, [29, 33.4, 1], 1.4, 7.2, 1.2, wire(29, 30, 33.4, 17) + `<g>${frame(29, 6, 17, 24, `<g transform="translate(0.6 -0.2) scale(0.9)">${fucus()}</g>`, 17 - 3.2 - 5.2, 24 - 3.2 - 5.2, label(4.3, 14.4, 'Fucus', 3), star)}</g>`);
        return { defs: DEF19 + `<defs><linearGradient id="${id}o" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ecd2a6"/><stop offset="0.5" stop-color="#d6b486"/><stop offset="1" stop-color="#b8925e"/></linearGradient><radialGradient id="${id}v" cx="50%" cy="50%" r="70%"><stop offset="0.6" stop-color="#a88a5a" stop-opacity="0"/><stop offset="1" stop-color="#a88a5a" stop-opacity="0.25"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BTH-044 CARVED WOODEN ONSEN KANJI SIGN & HANGING NOREN (T3): a thick weathered cedar board with a deeply carved, gilded 湯 ('hot water') and a red
    // seal, pegged to the wall; under it a bamboo pole on two wooden brackets carrying an indigo cotton noren split in two panels, with a big white ゆ
    // across the split, a seigaiha wave band at the hem, fabric folds and stitched sleeves round the pole. Live: the two panels sway gently.
    N.noren29 = S => { const D = { w: 100, d: 10, mount: 'wall', elev: 30, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('noren29'), id = C.u('b44'), PY = 36, PB = -2, PW = 23.8, G = 0.4;
        ext(C, [[-34, 54, 0], [34, PB - 2, 0], [34, PB - 2, 8]]);
        const KAN = 'M1.3 1.4L2.2 2.2M0.8 4L1.8 4.8M0.7 8.9L2.2 6.4M4.5 0.9H8.4V3.7H4.5ZM4.5 2.3H8.4M3.4 4.7H9.6M4.9 5.9H8.8Q8.9 8.6 8.2 9.4L7.3 9M5.6 6Q5.1 7.7 3.6 8.9M7 6.1Q6.6 7.9 5.1 9.3';
        const HYU = 'M2.3 2.4Q1.5 5.4 2.4 7.8Q2.9 8.6 3.3 7.4M2.5 5.8Q3.3 3.2 6.2 3.2Q8.7 3.4 8.4 5.9Q8.1 8 5.5 8.1M5.5 1Q6.4 4.4 5.8 7.4Q5.3 9.2 3.8 9.9';
        // sign
        const SW = 34, SH = 12, sy = 41;
        let face = `<rect width="${SW}" height="${SH}" fill="url(#${id}w)"/>` + rep(26, () => { const y = R() * SH; return `<path d="M0 ${f1(y)}Q${f1(SW / 2)} ${f1(y + (R() - 0.5) * 1.6)} ${SW} ${f1(y + (R() - 0.5))}" stroke="${R() < 0.6 ? '#6a4224' : '#c89a6a'}" stroke-width="${f1(0.06 + R() * 0.1)}" fill="none" opacity="0.6"/>`; }).join('')
          + `<rect width="${SW}" height="${SH}" fill="none" stroke="#3a2010" stroke-width="0.6" opacity="0.45"/>`
          + `<g transform="translate(${f1(SW / 2 - 4.6)} 1.4) scale(0.92)"><path d="${KAN}" stroke="#ffe8b8" stroke-width="1.25" fill="none" stroke-linecap="round" stroke-linejoin="round" transform="translate(0.12 0.14)" opacity="0.5"/><path d="${KAN}" stroke="#2a160a" stroke-width="1.3" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${KAN}" stroke="url(#${id}g)" stroke-width="0.75" fill="none" stroke-linecap="round" stroke-linejoin="round" transform="translate(0.08 0.1)"/></g>`
          + `<rect x="${SW - 5.4}" y="${SH - 4.4}" width="2.6" height="2.6" rx="0.3" fill="#b8302a" opacity="0.85"/><path d="M${SW - 5} ${SH - 3.8}h1.8M${SW - 4.1} ${SH - 4}v2.2M${SW - 5} ${SH - 2.4}h1.8" stroke="#f4d8c8" stroke-width="0.2"/>`
          + `<text x="3.4" y="4" font-family="${SERIF}" font-size="1.1" fill="#3a2010" opacity="0.6">ONSEN</text>`;
        let s = shW(C, -SW / 2, sy + SH, SW, SH, 0.8, 0.35) + box3(C, { c: [0, sy, 1.4], w: SW, h: SH, d: 2.8, col: '#9a6a40', r: 0.6, dec: { f: face } })
          + [-SW / 2 + 2.2, SW / 2 - 2.2].map(x => cyl3(C, [x, sy + SH / 2, 2.8], [x, sy + SH / 2, 3.2], 0.55, '#6a4224', { n: 12 })).join('');
        // brackets + bamboo pole
        [-26.4, 26.4].forEach(x => s += box3(C, { c: [x, PY - 2.4, 1.6], w: 1.6, h: 4, d: 3.2, col: '#8a5a32', r: 0.3 }) + box3(C, { c: [x, PY - 0.6, 3.6], w: 1.6, h: 1.2, d: 1.6, col: '#8a5a32', r: 0.3 }));
        s += cyl3(C, [-29, PY + 0.4, 4], [29, PY + 0.4, 4], 0.75, '#c8b46a', { n: 14, capCol: '#a8944a' }) + [-18, -6, 6, 18].map(x => cyl3(C, [x - 0.3, PY + 0.4, 4], [x + 0.3, PY + 0.4, 4], 0.85, '#a8944a', { n: 14, noCap: 1 })).join('');
        // noren panels (each its own group, swaying from the pole)
        const PH = PY - PB, NV = '#24386a';
        const panel = side => { const x0 = side < 0 ? -PW - G / 2 : G / 2, cid = `${id}p${side < 0 ? 'l' : 'r'}`;
          let p = `<clipPath id="${cid}"><rect width="${PW}" height="${f1(PH)}"/></clipPath><g clip-path="url(#${cid})"><rect width="${PW}" height="${f1(PH)}" fill="${NV}"/>`
            + rep(60, () => `<path d="M${f1(R() * PW)} 0V${f1(PH)}" stroke="${R() < 0.5 ? '#2e4478' : '#1c2c56'}" stroke-width="0.12" opacity="0.5"/>`).join('')
            + `<rect width="${PW}" height="${f1(PH)}" fill="url(#${id}f)"/>`
            + `<g transform="translate(${f1(side < 0 ? PW + G / 2 - 7.8 : -G / 2 - 7.8)} 9.4) scale(1.56)"><path d="${HYU}" stroke="#f4f0e4" stroke-width="1.15" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${HYU}" stroke="#c8ccd8" stroke-width="0.25" fill="none" stroke-linecap="round" transform="translate(0.1 0.12)" opacity="0.5"/></g>`
            + `<rect y="${f1(PH - 6.2)}" width="${PW}" height="6.2" fill="#2e4a82"/>` + rep(14, i => { const cx = (i % 7) * 4 + (Math.floor(i / 7) % 2) * 2 - (side < 0 ? 0 : 1), cy = PH - 4 + Math.floor(i / 7) * 2.4; return [1.8, 1.2, 0.6].map(r => `<path d="M${f1(cx - r)} ${f1(cy)}A${r} ${r} 0 0 1 ${f1(cx + r)} ${f1(cy)}" stroke="#d8e2f4" stroke-width="0.16" fill="none" opacity="0.8"/>`).join(''); }).join('')
            + `<path d="M0 ${f1(PH - 6.2)}H${PW}" stroke="#d8e2f4" stroke-width="0.2"/><path d="M0 2.6H${PW}" stroke="#d8e2f4" stroke-width="0.14" stroke-dasharray="0.6 0.4" opacity="0.6"/><rect width="${PW}" height="2.4" fill="#000000" opacity="0.22"/>`
            + `<path d="M0.4 ${f1(PH - 0.5)}H${PW - 0.4}" stroke="#7a8ab0" stroke-width="0.1" stroke-dasharray="0.5 0.3"/></g>`;
          return swayAt(C, [x0 + PW / 2, PY, 4], 0.9, 6.4, side < 0 ? 0 : 2.1, WD(C, x0, PY + 0.8, 4.2, p)); };
        s += WD(C, -PW - 1, PY - 0.6, 0.05, `<rect width="${f1(PW * 2 + 2)}" height="${f1(PH)}" fill="#000000" opacity="0.18" filter="url(#m10b3)"/><rect x="${f1(PW + 0.4)}" y="1" width="1.2" height="${f1(PH - 1)}" fill="#1a2440" opacity="0.8"/>`);
        s += panel(-1) + panel(1);
        return { defs: DEF19 + `<defs><linearGradient id="${id}w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b07a4a"/><stop offset="0.5" stop-color="#9a6a40"/><stop offset="1" stop-color="#7a4e2c"/></linearGradient>`
          + `<linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset="0.45" stop-color="#e0b456"/><stop offset="1" stop-color="#9a7024"/></linearGradient>`
          + `<linearGradient id="${id}f" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000000" stop-opacity="0.18"/><stop offset="0.2" stop-color="#ffffff" stop-opacity="0.05"/><stop offset="0.38" stop-color="#000000" stop-opacity="0.12"/><stop offset="0.6" stop-color="#ffffff" stop-opacity="0.06"/><stop offset="0.8" stop-color="#000000" stop-opacity="0.1"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.04"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BTH-064 BAS-RELIEF ZEN SAND-RIPPLE STONE SCULPTURE (T4): a honed travertine panel carved like a raked zen garden (straight raked grooves that swirl into
    // concentric ripples round three raised stones, lit from above so every groove has a shadowed upper lip and a lit lower lip), travertine pores + bands,
    // floating off the wall on a dark bronze reveal; a polished brass picture light washes it in warm light that slowly breathes and a soft sheen glides
    // across the ripples; below, a floating travertine ledge with a candle in a brass cup (flickering, glowing on the wall) and an incense curl.
    N.ripple29 = S => { const D = { w: 104, d: 12, mount: 'wall', elev: 40, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('ripple29'), id = C.u('b64'), PW = 72, PH = 40, PY = 8, BR = '#c99a3e';
        ext(C, [[-PW / 2 - 4, PY + PH + 9, 0], [PW / 2 + 4, -4, 0], [PW / 2 + 4, -4, 10]]);
        const ST = [[20, 24, 5.4], [50, 13, 4], [56, 29.5, 2.6]], SP = 1.35, NR = 6, OUT = ST.map(([, , r]) => r + SP * NR + 0.6);
        const groove = (d, msk) => `<g${msk ? ` mask="url(#${msk})"` : ''}><path d="${d}" stroke="#8c7e66" stroke-width="0.34" fill="none" transform="translate(0 -0.16)" opacity="0.8"/><path d="${d}" stroke="#fffaf0" stroke-width="0.26" fill="none" transform="translate(0 0.2)" opacity="0.9"/><path d="${d}" stroke="#c4b69c" stroke-width="0.3" fill="none"/></g>`;
        let lines = ''; for (let y = 1.4; y < PH - 0.6; y += SP) lines += `M0 ${f1(y)}H${PW}`;
        let defs = `<mask id="${id}m0" maskUnits="userSpaceOnUse" x="0" y="0" width="${PW}" height="${PH}"><rect width="${PW}" height="${PH}" fill="#ffffff"/>${ST.map(([x, y], i) => `<circle cx="${x}" cy="${y}" r="${f1(OUT[i])}" fill="#000000"/>`).join('')}</mask>`;
        let art = `<rect width="${PW}" height="${PH}" fill="url(#${id}t)"/>` + rep(8, () => { const y = R() * PH; return `<path d="M0 ${f1(y)}Q${f1(PW / 2)} ${f1(y + (R() - 0.5) * 3)} ${PW} ${f1(y + (R() - 0.5) * 2)}" stroke="${R() < 0.5 ? '#cdbf9e' : '#efe6d2'}" stroke-width="${f1(0.6 + R() * 1.4)}" fill="none" opacity="0.35"/>`; }).join('');
        art += groove(lines, `${id}m0`);
        ST.forEach(([x, y, r], i) => { let rings = ''; for (let k = 1; k <= NR; k++) rings += `M${f1(x - r - k * SP)} ${y}a${f1(r + k * SP)} ${f1((r + k * SP) * 0.92)} 0 1 0 ${f1(2 * (r + k * SP))} 0a${f1(r + k * SP)} ${f1((r + k * SP) * 0.92)} 0 1 0 ${f1(-2 * (r + k * SP))} 0`;
          defs += `<mask id="${id}m${i + 1}" maskUnits="userSpaceOnUse" x="0" y="0" width="${PW}" height="${PH}"><circle cx="${x}" cy="${y}" r="${f1(OUT[i])}" fill="#ffffff"/>${ST.slice(0, i).map(([x2, y2], j) => `<circle cx="${x2}" cy="${y2}" r="${f1(OUT[j])}" fill="#000000"/>`).join('')}</mask>`;
          art += groove(rings, `${id}m${i + 1}`); });
        ST.forEach(([x, y, r]) => art += `<ellipse cx="${f1(x + 0.6)}" cy="${f1(y + 0.9)}" rx="${f1(r * 1.04)}" ry="${f1(r * 0.92)}" fill="#6a5a44" opacity="0.4" filter="url(#m12b1)"/><ellipse cx="${x}" cy="${y}" rx="${r}" ry="${f1(r * 0.88)}" fill="url(#${id}s)"/><ellipse cx="${f1(x - r * 0.3)}" cy="${f1(y - r * 0.35)}" rx="${f1(r * 0.4)}" ry="${f1(r * 0.22)}" fill="#ffffff" opacity="0.4"/>`);
        art += rep(70, () => { const x = R() * PW, y = R() * PH; return `<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(0.15 + R() * 0.5)}" ry="${f1(0.06 + R() * 0.12)}" fill="#8a7a5e" opacity="${f1(0.35 + R() * 0.3)}"/>`; }).join('');
        art += `<rect width="${PW}" height="${PH}" fill="url(#${id}l)"><animate attributeName="opacity" values="0.55;0.95;0.55" dur="9s" repeatCount="indefinite" calcMode="spline" keySplines="0.45 0 0.55 1;0.45 0 0.55 1"/></rect>`
          + `<rect x="-20" width="14" height="${PH}" fill="url(#${id}h)" transform="skewX(-14)">${an('x', `-20;${PW + 14};${PW + 14}`, 14, 0, ' keyTimes="0;0.6;1"')}</rect>`;
        let s = shW(C, -PW / 2, PY + PH, PW, PH, 0.8, 0.35);
        s += box3(C, { c: [0, PY + 1, 0.8], w: PW - 2, h: PH - 2, d: 1.6, col: '#3a2c1c', r: 0.2 });
        s += box3(C, { c: [0, PY, 2.6], w: PW, h: PH, d: 2.4, col: '#e6dac2', r: 0.3, dec: { f: `<defs>${defs}<clipPath id="${id}k"><rect width="${PW}" height="${PH}"/></clipPath></defs><g clip-path="url(#${id}k)">${art}</g>`, t: rep(6, () => `<path d="M${f1(R() * (PW - 8))} ${f1(0.3 + R() * 1.6)}h${f1(2 + R() * 5)}" stroke="#b8a888" stroke-width="0.2" opacity="0.6"/>`).join('') } });
        // picture light
        const LY = PY + PH + 4.6;
        s += WD(C, -PW / 2, PY + PH + 3, 3.9, `<path d="M8 0H${PW - 8}L${PW} 14H0Z" fill="url(#${id}c)" opacity="0.5">${an('opacity', '0.35;0.6;0.35', 9, 0, SPL(2))}</path>`);
        s += cyl3(C, [0, LY + 1.4, 0], [0, LY + 1.4, 0.6], 1.6, BR, { n: 16, mat: 'gloss' }) + line3(C, [[0, LY + 1.4, 0.6], [0, LY + 2.4, 2.4], [0, LY + 0.6, 4.4]], 0.6, shade(BR, 0.85))
          + cyl3(C, [-16, LY, 4.8], [16, LY, 4.8], 1.3, BR, { n: 16, mat: 'gloss', capCol: shade(BR, 1.1) }) + line3(C, [[-15.4, LY - 1.05, 5.5], [15.4, LY - 1.05, 5.5]], 0.45, '#fff2c4', 'opacity="0.9"');
        // ledge + candle + incense
        s += WD(C, -6, 8, 0.04, `<ellipse cx="6" cy="4" rx="9" ry="7" fill="#ffd890" opacity="0.2" filter="url(#m11b8)">${an('opacity', '0.14;0.26;0.18;0.24;0.14', 3.4, 0, SPL(4))}</ellipse>`);
        s += box3(C, { c: [0, -2.8, 3.6], w: 30, h: 2.4, d: 7.2, col: '#e2d6be', r: 0.3, dec: { f: rep(6, () => `<ellipse cx="${f1(R() * 30)}" cy="${f1(0.4 + R() * 1.6)}" rx="0.4" ry="0.1" fill="#8a7a5e" opacity="0.5"/>`).join('') } });
        s += cyl3(C, [4, -0.4, 4.4], [4, 2.2, 4.4], 2, BR, { n: 18, mat: 'gloss', capCol: '#f4ecd8', cap: cr => `<circle r="${f1(cr)}" fill="#f6eedc"/><circle r="${f1(cr * 0.82)}" fill="#fbf6ea"/><circle r="${f1(cr * 0.1)}" fill="#3a2a1a"/>` });
        const fp = C.P([4, 2.4, 4.4]), k = C.k;
        s += `<g transform="translate(${P2(fp)}) scale(${n4(k)})"><ellipse cy="-1.4" rx="2.4" ry="3" fill="#ffd27a" opacity="0.25" filter="url(#m12b1)"/><path d="M0 0.2C-0.75 -0.6 -0.6 -1.8 0 -3.2C0.6 -1.8 0.75 -0.6 0 0.2Z" fill="#ffb84a">${at('skewX', '-4;5;-2;3;-4', 2.6, 0, SPL(4))}${an('opacity', '0.85;1;0.9;1;0.85', 1.7)}</path><path d="M0 -0.1C-0.35 -0.6 -0.3 -1.3 0 -2C0.3 -1.3 0.35 -0.6 0 -0.1Z" fill="#fff4cc"/></g>`;
        s += cyl3(C, [-6, -0.4, 4.4], [-6, 0.4, 4.4], 0.9, BR, { n: 12, mat: 'gloss' }) + line3(C, [[-6, 0.4, 4.4], [-4.2, 9, 4.4]], 0.18, '#7a4a2a') + line3(C, [[-4.4, 8, 4.4], [-4.2, 9, 4.4]], 0.24, '#ff8a4a');
        const ip = C.P([-4.2, 9.2, 4.4]);
        s += `<g transform="translate(${P2(ip)}) scale(${n4(k)})">${[0, 3, 6].map(ph => `<path d="M0 0C-1 -2 1 -4 0 -6C-1 -8 1.2 -9 0.4 -11" stroke="#ffffff" stroke-width="0.35" fill="none" stroke-linecap="round" opacity="0">${an('opacity', '0;0.45;0', 9, -ph)}<animateTransform attributeName="transform" type="translate" values="0 0;0.6 -3" dur="9s" begin="${-ph}s" repeatCount="indefinite"/></path>`).join('')}</g>`;
        return { defs: DEF19 + `<defs><linearGradient id="${id}t" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ece2cc"/><stop offset="0.5" stop-color="#e2d6bc"/><stop offset="1" stop-color="#d4c6a8"/></linearGradient>`
          + `<radialGradient id="${id}s" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#fbf4e4"/><stop offset="0.55" stop-color="#e2d4b8"/><stop offset="1" stop-color="#a89878"/></radialGradient>`
          + `<linearGradient id="${id}l" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0c8" stop-opacity="0.5"/><stop offset="0.4" stop-color="#ffe8b8" stop-opacity="0.12"/><stop offset="1" stop-color="#3a2a14" stop-opacity="0.16"/></linearGradient>`
          + `<linearGradient id="${id}h" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff6e0" stop-opacity="0"/><stop offset="0.5" stop-color="#fff6e0" stop-opacity="0.28"/><stop offset="1" stop-color="#fff6e0" stop-opacity="0"/></linearGradient>`
          + `<linearGradient id="${id}c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe6a8" stop-opacity="0.65"/><stop offset="1" stop-color="#ffe0a0" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BTH-084 HOLOGRAPHIC MOUNTAIN HOT-SPRING WINDOW ILLUSION (T5): a deep walnut window frame with a polished brass bezel that looks out on a snowy
    // mountain onsen at dusk: violet-to-peach sky, moon + twinkling stars, snowy peaks, a ryokan with glowing windows among snowy pines, a rock-ringed hot
    // spring with lantern reflections where a snow monkey soaks with a towel on its head, a stone lantern, rising steam and falling snow. Holographic depth:
    // the layers drift with slow parallax and a faint iridescent sheen crosses the glass. Brass sill with an engraved plaque and a warm light line.
    N.holo29 = S => { const D = { w: 120, d: 12, mount: 'wall', elev: 34, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('holo29'), id = C.u('b84'), FW = 86, FH = 52, FY = 6, B = 4.2, VW = FW - 2 * B, VH = FH - 2 * B, BR = '#c99a3e';
        ext(C, [[-FW / 2 - 4, FY + FH + 4, 0], [FW / 2 + 4, FY - 6, 0], [FW / 2 + 4, FY - 6, 10]]);
        const drift = (dx, T, inner) => `<g>${at('translate', `0 0;${dx} 0;0 0`, T, 0, SPL(2))}${inner}</g>`;
        const pine = (x, y, h, sn) => `<path d="M${f1(x)} ${f1(y - h)}L${f1(x + h * 0.22)} ${f1(y - h * 0.62)}H${f1(x + h * 0.12)}L${f1(x + h * 0.32)} ${f1(y - h * 0.28)}H${f1(x + h * 0.18)}L${f1(x + h * 0.38)} ${f1(y)}H${f1(x - h * 0.38)}L${f1(x - h * 0.18)} ${f1(y - h * 0.28)}H${f1(x - h * 0.32)}L${f1(x - h * 0.12)} ${f1(y - h * 0.62)}H${f1(x - h * 0.22)}Z" fill="#1e2c3a"/>`
          + (sn ? `<path d="M${f1(x)} ${f1(y - h)}L${f1(x + h * 0.12)} ${f1(y - h * 0.8)}L${f1(x)} ${f1(y - h * 0.84)}L${f1(x - h * 0.12)} ${f1(y - h * 0.8)}ZM${f1(x - h * 0.22)} ${f1(y - h * 0.6)}h${f1(h * 0.18)}l-${f1(h * 0.06)} ${f1(h * 0.05)}ZM${f1(x + h * 0.05)} ${f1(y - h * 0.3)}h${f1(h * 0.24)}l-${f1(h * 0.08)} ${f1(h * 0.05)}Z" fill="#e8eef8" opacity="0.85"/>` : '');
        let sc = `<rect width="${VW}" height="${VH}" fill="url(#${id}k)"/>`;
        sc += rep(22, i => { const x = R() * VW, y = R() * VH * 0.4, r = 0.1 + R() * 0.12; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="#ffffff">${an('opacity', '0.3;1;0.3', 2 + R() * 4, -R() * 4)}</circle>`; }).join('');
        sc += `<circle cx="${f1(VW * 0.78)}" cy="8" r="6" fill="#fff4dc" opacity="0.18" filter="url(#m12b1)"/><circle cx="${f1(VW * 0.78)}" cy="8" r="2.6" fill="#fff8e8"/><circle cx="${f1(VW * 0.78 - 0.8)}" cy="7.4" r="0.6" fill="#ece0c8" opacity="0.6"/>`;
        const far = `<path d="M-4 26L8 13L14 17L24 8L34 18L42 14L54 6L66 16L74 12L86 22V40H-4Z" fill="#6a6a9a"/><path d="M8 13L11 15.2L9.6 16L8 15L6.4 16.4ZM24 8L28 12L26 12.6L24 11.4L21.6 13ZM54 6L59 10.6L56.6 11L54 9.6L51 11.4ZM74 12L77 14.4L75 14.8L73 14Z" fill="#f2eef8"/>`;
        const mid = `<path d="M-4 30Q10 22 22 26T46 24T70 26T86 23V40H-4Z" fill="#3a4466"/>` + rep(16, i => pine(-2 + i * 5.6 + R() * 2, 28 + R() * 2, 4 + R() * 3, 1)).join('')
          + `<g transform="translate(46 25.4)"><rect x="-6" y="-3" width="12" height="4" fill="#4a3424"/><path d="M-8 -3L0 -7L8 -3Z" fill="#2a2a34"/><path d="M-8 -3L0 -7L8 -3L7 -3.4L0 -6.4L-7 -3.4Z" fill="#eef2fa" opacity="0.8"/>${[-4.2, -1.4, 1.4, 4.2].map(x => `<rect x="${x - 0.9}" y="-2.2" width="1.8" height="1.8" fill="#ffc86a"><animate attributeName="opacity" values="0.8;1;0.8" dur="${3 + Math.abs(x)}s" repeatCount="indefinite"/></rect>`).join('')}<rect x="-6" y="0.6" width="12" height="0.4" fill="#ffd890" opacity="0.4"/></g>`;
        const near = rep(5, i => pine(i < 2 ? -1 + i * 6 : VW - 14 + (i - 2) * 6, VH - 9 + (i % 2), 10 + (i % 3) * 3, 1)).join('');
        // hot spring pool + rocks + monkey + lantern
        const PX = VW * 0.46, PYc = VH - 6.4;
        let pool = `<ellipse cx="${f1(PX)}" cy="${f1(PYc)}" rx="22" ry="5.6" fill="url(#${id}p)"/>` + rep(4, i => `<ellipse cx="${f1(PX - 8 + i * 6)}" cy="${f1(PYc + 0.6 + (i % 2) * 1.4)}" rx="${f1(2.4 + i % 2)}" ry="0.3" fill="#ffe0a0" opacity="0.5">${an('opacity', '0.2;0.6;0.2', 3 + i, -i)}</ellipse>`).join('')
          + [0, 2.4, 4.8].map(ph => `<ellipse cx="${f1(PX + 2)}" cy="${f1(PYc - 0.6)}" rx="1" ry="0.25" fill="none" stroke="#ffffff" stroke-width="0.15" opacity="0">${an('rx', '1;6', 7.2, -ph)}${an('ry', '0.25;1.4', 7.2, -ph)}${an('opacity', '0.6;0', 7.2, -ph)}</ellipse>`).join('');
        // snow monkey with a towel, bobbing
        pool += `<g>${at('translate', '0 0;0 -0.35;0 0', 4.4, 0, SPL(2))}<g transform="translate(${f1(PX + 2)} ${f1(PYc - 1.6)})"><ellipse cy="1.6" rx="3.4" ry="1.4" fill="#8a7a6a"/><circle r="2.5" fill="#a89888"/><circle cx="-1.2" cy="-1.4" r="0.9" fill="#b8a898"/><circle cx="1.2" cy="-1.4" r="0.9" fill="#b8a898"/><ellipse cy="0.3" rx="1.7" ry="1.5" fill="#e88a8a"/><path d="M-1 -0.1q0.4 -0.3 0.7 0M0.3 -0.1q0.4 -0.3 0.7 0" stroke="#5a2a2a" stroke-width="0.18" fill="none" stroke-linecap="round"/><path d="M-0.4 0.9q0.4 0.3 0.8 0" stroke="#7a3a3a" stroke-width="0.14" fill="none"/><circle cx="-1.2" cy="0.6" r="0.35" fill="#f4a0a0" opacity="0.7"/><circle cx="1.2" cy="0.6" r="0.35" fill="#f4a0a0" opacity="0.7"/><path d="M-1.8 -2.2Q0 -3.4 1.8 -2.2L1.6 -1.6Q0 -2.4 -1.6 -1.6Z" fill="#f4f0e8"/><path d="M-1.6 -2.2L1.6 -2.2" stroke="#7aa0c8" stroke-width="0.12"/></g></g>`
          + `<ellipse cx="${f1(PX + 2)}" cy="${f1(PYc + 0.2)}" rx="3.8" ry="0.5" fill="#bfe0d8" opacity="0.6"/>`;
        pool += rep(14, i => { const t = i / 13 * PI, x = PX + Math.cos(PI - t) * 23, y = PYc + Math.sin(t) * 5.6 * (i % 2 ? 1.05 : 0.95) + (i > 6 ? 0.8 : 0) - (Math.sin(t) < 0.3 ? 1 : 0), r = 1.6 + R() * 1.4; return `<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(r * 1.3)}" ry="${f1(r * 0.8)}" fill="#5a5450"/><ellipse cx="${f1(x - r * 0.2)}" cy="${f1(y - r * 0.3)}" rx="${f1(r * 0.9)}" ry="${f1(r * 0.4)}" fill="#7a726a"/><path d="M${f1(x - r)} ${f1(y - r * 0.45)}Q${f1(x)} ${f1(y - r * 1)} ${f1(x + r)} ${f1(y - r * 0.45)}Z" fill="#f2f4fa"/>`; }).join('');
        const LX = VW - 12, LYb = VH - 4.6;
        pool += `<g transform="translate(${f1(LX)} ${f1(LYb)})"><circle cy="-6.4" r="4.4" fill="#ffc86a" opacity="0.22" filter="url(#m12b1)">${an('opacity', '0.16;0.3;0.2;0.28;0.16', 4, 0, SPL(4))}</circle><rect x="-0.8" y="-4" width="1.6" height="4" fill="#6a6660"/><rect x="-2.2" y="-4.6" width="4.4" height="0.8" fill="#7a7670"/><rect x="-1.6" y="-7.6" width="3.2" height="3" fill="#5a5650"/><rect x="-1" y="-7" width="2" height="1.8" fill="#ffd27a">${an('opacity', '0.75;1;0.85;1;0.75', 2.6, 0, SPL(4))}</rect><path d="M-3 -7.6L0 -10L3 -7.6Z" fill="#6a6660"/><path d="M-3 -7.6L0 -10L3 -7.6L2.4 -8L0 -9.4L-2.4 -8Z" fill="#f2f4fa"/></g>`;
        const steam = rep(6, i => `<ellipse cx="${f1(PX - 14 + i * 5.4)}" cy="${f1(PYc - 2)}" rx="${f1(3 + (i % 3))}" ry="1.6" fill="#ffffff" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.35;0', 8, -i * 1.3)}<animateTransform attributeName="transform" type="translate" values="0 0;${i % 2 ? 1.5 : -1.5} -12" dur="8s" begin="${f1(-i * 1.3)}s" repeatCount="indefinite"/></ellipse>`).join('');
        const snow = `<g>${at('translate', `0 -${VH};0 0`, 16)}${rep(46, () => { const x = R() * VW, y = R() * VH * 2, r = 0.1 + R() * 0.2; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="#ffffff" opacity="${f1(0.5 + R() * 0.4)}"/>`; }).join('')}</g>`;
        sc += drift(-0.6, 26, far) + drift(-1.6, 26, mid) + drift(-3, 26, pool + near) + steam + snow;
        sc += `<rect width="${VW}" height="${VH}" fill="url(#${id}v)"/><rect x="-40" width="22" height="${VH}" fill="url(#${id}i)" transform="skewX(-20)">${an('x', `-40;${VW + 20};${VW + 20}`, 15, 0, ' keyTimes="0;0.55;1"')}</rect>`
          + `<path d="M0 0H${f1(VW * 0.3)}L${f1(VW * 0.12)} ${VH}H0Z" fill="#ffffff" opacity="0.05"/>`;
        const face = `<rect width="${FW}" height="${FH}" fill="url(#${id}w)"/>` + rep(16, () => `<path d="M${f1(R() * (FW - 8))} ${f1(R() * FH)}h${f1(2 + R() * 6)}" stroke="#2a160a" stroke-width="0.16" opacity="0.5"/>`).join('')
          + `<path d="M0 0L${B} ${B}M${FW} 0L${FW - B} ${B}M0 ${FH}L${B} ${FH - B}M${FW} ${FH}L${FW - B} ${FH - B}" stroke="#1e1008" stroke-width="0.2"/>`
          + `<rect x="${f1(B - 1)}" y="${f1(B - 1)}" width="${f1(VW + 2)}" height="${f1(VH + 2)}" rx="0.4" fill="url(#${id}b)"/><rect x="${f1(B - 0.3)}" y="${f1(B - 0.3)}" width="${f1(VW + 0.6)}" height="${f1(VH + 0.6)}" fill="#1a120a"/>`
          + `<clipPath id="${id}c"><rect width="${VW}" height="${VH}"/></clipPath><g transform="translate(${B} ${B})" clip-path="url(#${id}c)">${sc}</g>`
          + `<rect x="${B}" y="${B}" width="${VW}" height="1.4" fill="url(#${id}d)"/>`;
        let s = WD(C, -FW / 2 - 6, FY + FH + 6, 0.04, `<rect width="${FW + 12}" height="${FH + 14}" rx="10" fill="#ffd8a0" opacity="0.14" filter="url(#m11b8)">${an('opacity', '0.1;0.18;0.1', 10, 0, SPL(2))}</rect>`);
        s += shW(C, -FW / 2, FY + FH, FW, FH, 0.8, 0.4) + box3(C, { c: [0, FY, 1.6], w: FW, h: FH, d: 3.2, col: '#4a2a18', r: 0.4, dec: { f: face } });
        // brass sill + plaque + light line
        s += box3(C, { c: [0, FY - 2.4, 3], w: FW + 4, h: 2.2, d: 6, col: BR, r: 0.4, dec: { f: `<rect width="${FW + 4}" height="2.2" fill="url(#${id}b)"/><rect y="1.7" width="${FW + 4}" height="0.4" fill="#fff0c0" opacity="0.8"/>` } });
        s += WD(C, -9, FY - 3.2, 6.05, `<rect width="18" height="3.4" rx="0.4" fill="url(#${id}b)" stroke="#8a6420" stroke-width="0.12"/><text x="9" y="1.6" text-anchor="middle" font-family="${SERIF}" font-size="1.05" fill="#4a3010" letter-spacing="0.15">KUROKAWA ONSEN</text><text x="9" y="2.8" text-anchor="middle" font-family="${SANS}" font-size="0.65" fill="#5a4018" letter-spacing="0.1">1,200 m · 42°C</text>`);
        s += WD(C, -FW / 2 - 2, FY - 4.6, 0.05, `<rect width="${FW + 4}" height="5" fill="#ffd890" opacity="0.25" filter="url(#m12b1)">${an('opacity', '0.18;0.32;0.18', 7, 0, SPL(2))}</rect>`);
        return { defs: DEF19 + `<defs><linearGradient id="${id}k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#262250"/><stop offset="0.35" stop-color="#5a4682"/><stop offset="0.6" stop-color="#d88a8a"/><stop offset="0.75" stop-color="#f4b884"/><stop offset="1" stop-color="#f6c890"/></linearGradient>`
          + `<radialGradient id="${id}p" cx="50%" cy="40%" r="60%"><stop offset="0" stop-color="#7ac0b8"/><stop offset="0.7" stop-color="#4a8a90"/><stop offset="1" stop-color="#2e5a68"/></radialGradient>`
          + `<radialGradient id="${id}v" cx="50%" cy="50%" r="75%"><stop offset="0.6" stop-color="#000000" stop-opacity="0"/><stop offset="1" stop-color="#000000" stop-opacity="0.35"/></radialGradient>`
          + `<linearGradient id="${id}i" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffb8d8" stop-opacity="0"/><stop offset="0.3" stop-color="#ffb8d8" stop-opacity="0.1"/><stop offset="0.5" stop-color="#fff0b8" stop-opacity="0.14"/><stop offset="0.7" stop-color="#b8f0d8" stop-opacity="0.1"/><stop offset="1" stop-color="#b8f0d8" stop-opacity="0"/></linearGradient>`
          + `<linearGradient id="${id}w" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6a3e22"/><stop offset="0.5" stop-color="#4a2a18"/><stop offset="1" stop-color="#341c0e"/></linearGradient>`
          + `<linearGradient id="${id}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0b0"/><stop offset="0.35" stop-color="#e2b456"/><stop offset="0.7" stop-color="#b38432"/><stop offset="1" stop-color="#f2d488"/></linearGradient>`
          + `<linearGradient id="${id}d" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000000" stop-opacity="0.45"/><stop offset="1" stop-color="#000000" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };
  }

  // ======================= CEILINGS (r.c29) — same frame + hook as the Kitchen ceilings (plus27 r.c27): RD.H14 frame + G.VY depth, t 0 = front edge, 1 = back wall line =======================
  // card = the tier's new Bathroom wall (SURF12 tile) under the ceiling; res.ceilRoom = the wide room ceiling (Squad House v6 rt.ceil)
  { const { mould, band, mkV } = RD.H21, CFRM = RD.H14.FRM, { cE, cHi, cDoc, cShade } = RD.H27, { SURF12, tile: wTile } = RD.H12;
    const cD = (x, y, rx, ry) => `M${n4(x - rx)} ${n4(y)}a${n4(rx)} ${n4(ry)} 0 1 0 ${n4(2 * rx)} 0a${n4(rx)} ${n4(ry)} 0 1 0 ${n4(-2 * rx)} 0`;
    const cEl = (P, rx, ry, ex, dy) => `<ellipse cx="${f1(P.x)}" cy="${f1(P.y + (dy || 0))}" rx="${f1(rx)}" ry="${f1(ry)}" ${ex}/>`;
    const cBl = (G, sd, n, cols, op, w) => { const R = rng(sd); return `<g filter="url(#cb6)" opacity="${op}">` + rep(n, i => { const t = 0.05 + R() * 0.92, y = G.y(t), z = G.z(y); return `<ellipse cx="${f1(G.x(R() * 1.1 - 0.05, y))}" cy="${f1(y)}" rx="${f1((w + R() * w) * z)}" ry="${f1((4 + R() * 5) * z)}" fill="${cols[i % cols.length]}"/>`; }).join('') + '</g>'; };
    const cSt = (G, u, t, rw, sd) => { const P = cE(G, u, t), Rr = rng(sd), pts = rep(22, i => { const a = i / 22 * 2 * PI, k = rw * P.z * (0.78 + Rr() * 0.4); return [P.x + Math.cos(a) * k, P.y + Math.sin(a) * k * P.q]; });
      const d = 'M' + pts.map(P2).join('L') + 'Z', d2 = 'M' + pts.map(([x, y]) => [P.x + (x - P.x) * 0.6, P.y + (y - P.y) * 0.6]).map(P2).join('L') + 'Z';
      return `<path d="${d}" fill="#cdb078" opacity="0.34"/><path d="${d}" fill="none" stroke="#9c7642" stroke-width="${f1(1.1 * P.z)}" opacity="0.5"/><path d="${d2}" fill="#c4a264" opacity="0.18"/><path d="${d2}" fill="none" stroke="#a8844e" stroke-width="${f1(0.7 * P.z)}" opacity="0.4"/>`; };
    const loc = (P, inner) => `<g transform="translate(${f1(P.x)} ${f1(P.y)}) scale(1 ${n4(P.q)})">${inner}</g>`;
    const blob = (R, r, n) => 'M' + rep(n, i => { const a = i / n * 2 * PI, k = r * (0.65 + R() * 0.55); return f1(Math.cos(a) * k) + ' ' + f1(Math.sin(a) * k); }).join('L') + 'Z';

    // BTH-009 RUSTED RATTLING EXHAUST FAN & PEELING PAINT (T1): yellowed drywall with taped seams (one cracked, a strip of tape peeling and swaying),
    // brown leak rings, mildew creeping in from the back corners, big patches where the paint has blistered and peeled off down to the old blue-grey
    // coat with curling flakes hanging; a rust-streaked plastic exhaust fan whose louvres are caked with dust, blades spinning lopsided behind them, the
    // grille rattling; a lint strand dangling and a cobweb in the corner.
    function cPeel(G) { const R = rng('peel29');
      let s = `<path d="${G.tr}" fill="#e2dcc6"/>` + cBl(G, 'peel29b', 16, ['#ece7d6', '#d2c8aa', '#dbd2b8'], 0.5, 50), ov = '';
      [0.27, 0.73].forEach(u => { const d = 'M' + G.P(u, -0.02) + 'L' + G.P(u, 1.02); s += `<path d="${d}" stroke="#ebe6d6" stroke-width="${f1(7 * G.s)}" opacity="0.6"/>` + [-3, 3].map(o => `<path d="${d}" stroke="#b4aa8e" stroke-width="${f1(0.5 * G.s)}" transform="translate(${f1(o * G.s)} 0)" opacity="0.45"/>`).join(''); });
      { const P = rep(12, i => { const t = 0.08 + i * 0.045, y = G.y(t); return [G.x(0.73 + (R() - 0.5) * 0.006, y), y]; }); s += `<path d="M${P.map(P2).join('L')}" stroke="#5a5040" stroke-width="${f1(0.7 * G.s)}" fill="none"/><path d="M${P.map(([x, y]) => P2([x + 0.6 * G.s, y + 0.3 * G.s])).join('L')}" stroke="#fffaf0" stroke-width="${f1(0.4 * G.s)}" fill="none" opacity="0.7"/>`; }
      { const a = cE(G, 0.27, 0.34), z = a.z, d = `M${f1(a.x - 2.6 * z)} ${f1(a.y)}C${f1(a.x - 3 * z)} ${f1(a.y + 6 * z)} ${f1(a.x + 2 * z)} ${f1(a.y + 9 * z)} ${f1(a.x + 0.6 * z)} ${f1(a.y + 14 * z)}L${f1(a.x + 5.6 * z)} ${f1(a.y + 13 * z)}C${f1(a.x + 7 * z)} ${f1(a.y + 8 * z)} ${f1(a.x + 2.4 * z)} ${f1(a.y + 5 * z)} ${f1(a.x + 2.6 * z)} ${f1(a.y)}Z`;
        s += cEl(a, 3 * z, 2 * z * a.q, 'fill="#a8a088" opacity="0.5"');
        ov += `<g>${at('rotate', `-5 ${f1(a.x)} ${f1(a.y)};6 ${f1(a.x)} ${f1(a.y)};-5 ${f1(a.x)} ${f1(a.y)}`, 5.4, 0, SPL(2))}<path d="${d}" fill="#000000" opacity="0.15" transform="translate(${f1(1.2 * z)} ${f1(1.6 * z)})"/><path d="${d}" fill="#f2eedf" stroke="#b8ae94" stroke-width="${f1(0.4 * z)}"/><path d="M${f1(a.x)} ${f1(a.y + 2 * z)}l${f1(1.4 * z)} ${f1(9 * z)}" stroke="#d8d0bc" stroke-width="${f1(0.4 * z)}"/></g>`; }
      s += cSt(G, 0.13, 0.6, 28, 'p29a') + cSt(G, 0.87, 0.34, 18, 'p29b') + cSt(G, 0.62, 0.86, 12, 'p29c');
      // mildew creeping from the back corners + along the back wall line
      s += '<g filter="url(#cb6)">' + [[0.04, 0.95, 30], [0.96, 0.92, 24], [0.5, 0.99, 40]].map(([u, t, r]) => { const P = cE(G, u, t); return cEl(P, r * P.z, 5 * P.z, 'fill="#4a5038" opacity="0.22"'); }).join('') + '</g>';
      s += rep(320, () => { const c = [[0.04, 0.95], [0.96, 0.92], [0.3, 1], [0.7, 1]][(R() * 4) | 0], u = c[0] + (R() - 0.5) * 0.14 * R(), t = Math.min(1, c[1] - R() * R() * 0.3), P = cE(G, u, t); return cEl(P, (0.25 + R() * 0.5) * P.z, (0.25 + R() * 0.4) * P.z * P.q, `fill="${R() < 0.85 ? '#2e3424' : '#5a4a32'}" opacity="${f1(0.3 + R() * 0.5)}"`); }).join('');
      // peeled patches: old blue-grey paint, ragged edge, curling flakes hanging
      [[0.36, 0.7, 18], [0.6, 0.2, 14], [0.84, 0.66, 11], [0.2, 0.22, 9]].forEach(([u, t, r], i) => { const P = cE(G, u, t), z = P.z, Q = rng('pp29' + i), d = blob(Q, r * z, 16);
        s += loc(P, `<path d="${d}" fill="#000000" opacity="0.12" transform="translate(${f1(0.6 * z)} ${f1(1.2 * z)})"/><path d="${d}" fill="#aebcc0"/><path d="${blob(Q, r * z * 0.55, 12)}" fill="#9aaab0" opacity="0.6"/><path d="${d}" fill="none" stroke="#f6f2e4" stroke-width="${f1(1.2 * z)}"/><path d="${d}" fill="none" stroke="#8a826c" stroke-width="${f1(0.35 * z)}" transform="translate(${f1(0.4 * z)} ${f1(0.6 * z)})" opacity="0.6"/>`);
        rep(2, k => { const a = Q() * 2 * PI, x = P.x + Math.cos(a) * r * z * 0.8, y = P.y + Math.sin(a) * r * z * 0.8 * P.q, w = (2 + Q() * 2.4) * z, h = (3 + Q() * 4) * z, fl = `M${f1(x - w / 2)} ${f1(y)}Q${f1(x - w * 0.6)} ${f1(y + h * 0.7)} ${f1(x + w * 0.1)} ${f1(y + h)}Q${f1(x + w * 0.4)} ${f1(y + h * 0.5)} ${f1(x + w / 2)} ${f1(y)}Z`;
          ov += `<g>${at('rotate', `-3 ${f1(x)} ${f1(y)};4 ${f1(x)} ${f1(y)};-3 ${f1(x)} ${f1(y)}`, 4 + k + i * 0.7, -i, SPL(2))}<path d="${fl}" fill="#000000" opacity="0.14" transform="translate(${f1(0.8 * z)} ${f1(1 * z)})"/><path d="${fl}" fill="#f0ebdc" stroke="#b0a68c" stroke-width="${f1(0.3 * z)}"/><path d="M${f1(x - w * 0.3)} ${f1(y + h * 0.2)}Q${f1(x - w * 0.2)} ${f1(y + h * 0.6)} ${f1(x + w * 0.05)} ${f1(y + h * 0.85)}" stroke="#aebcc0" stroke-width="${f1(0.5 * z)}" fill="none"/></g>`; }); });
      // rusty exhaust fan
      { const P = cE(G, 0.5, 0.44), z = P.z, a = 21 * z;
        s += '<g filter="url(#cb3)">' + loc(P, `<circle r="${f1(a * 1.55)}" fill="#9a6a3a" opacity="0.22"/>`) + '</g>' + loc(P, rep(6, () => { const g = (R() - 0.5) * 2 * a, sg = R() < 0.5 ? -1 : 1; return `<path d="M${f1(g)} ${f1(sg * a)}q${f1((R() - 0.5) * a * 0.2)} ${f1(sg * a * 0.4)} ${f1((R() - 0.5) * a * 0.1)} ${f1(sg * a * (0.5 + R() * 0.5))}" stroke="#8a4e20" stroke-width="${f1((0.6 + R() * 0.8) * z)}" fill="none" opacity="0.45" stroke-linecap="round"/>`; }).join(''));
        const bl = `M0 0C${f1(-0.42 * a * 0.7)} ${f1(-0.25 * a * 0.7)} ${f1(-0.36 * a * 0.7)} ${f1(-0.95 * a * 0.7)} 0 ${f1(-a * 0.7)}C${f1(0.3 * a * 0.7)} ${f1(-0.92 * a * 0.7)} ${f1(0.22 * a * 0.7)} ${f1(-0.3 * a * 0.7)} 0 0Z`;
        let L = ''; rep(7, k => { const y = -0.78 * a + (k + 0.5) * 1.56 * a / 7; L += `<rect x="${f1(-0.78 * a)}" y="${f1(y - 0.06 * a)}" width="${f1(1.56 * a)}" height="${f1(0.12 * a)}" fill="#c4b898"/><rect x="${f1(-0.78 * a)}" y="${f1(y - 0.06 * a)}" width="${f1(1.56 * a)}" height="${f1(0.04 * a)}" fill="#5a5040" opacity="0.6"/>`; });
        const rust = rep(16, () => `<ellipse cx="${f1((R() - 0.5) * 1.9 * a)}" cy="${f1((R() - 0.5) * 1.9 * a)}" rx="${f1((0.06 + R() * 0.12) * a)}" ry="${f1((0.04 + R() * 0.08) * a)}" fill="${R() < 0.5 ? '#9a5222' : '#7a3a14'}" opacity="${f1(0.4 + R() * 0.4)}"/>`).join('');
        const box = `<rect x="${f1(-a)}" y="${f1(-a)}" width="${f1(2 * a)}" height="${f1(2 * a)}" rx="${f1(0.12 * a)}" fill="#d0c6a8" stroke="#8a7a58" stroke-width="${f1(0.5 * z)}"/><rect x="${f1(-0.9 * a)}" y="${f1(-0.9 * a)}" width="${f1(1.8 * a)}" height="${f1(1.8 * a)}" rx="${f1(0.08 * a)}" fill="none" stroke="#efe8d2" stroke-width="${f1(0.5 * z)}"/>`
          + `<clipPath id="b09f"><rect x="${f1(-0.78 * a)}" y="${f1(-0.78 * a)}" width="${f1(1.56 * a)}" height="${f1(1.56 * a)}"/></clipPath><rect x="${f1(-0.78 * a)}" y="${f1(-0.78 * a)}" width="${f1(1.56 * a)}" height="${f1(1.56 * a)}" fill="#18140e"/>`
          + `<g clip-path="url(#b09f)"><g>${at('translate', `0 0;${f1(0.06 * a)} ${f1(-0.04 * a)};0 0`, 0.35)}<g>${at('rotate', '0;360', 0.75)}${rep(4, k => `<path d="${bl}" transform="rotate(${k * 90 + (k === 2 ? 9 : 0)})" fill="#6e5e44" stroke="#3a3022" stroke-width="${f1(0.4 * z)}"/>`).join('')}</g><circle r="${f1(0.12 * a)}" fill="#3a3024"/></g></g>`
          + L + `<g filter="url(#cb1)">${rust}</g>` + rep(7, k => { const y = -0.78 * a + (k + 0.5) * 1.56 * a / 7; return `<path d="M${f1(-0.76 * a)} ${f1(y - 0.07 * a)}H${f1(0.76 * a)}" stroke="#6a6458" stroke-width="${f1(0.5 * z)}" stroke-dasharray="${f1(0.6 * z)} ${f1(0.3 * z)}" opacity="0.6"/>`; }).join('');
        s += `<g>${at('translate', `0 0;0 0;${f1(0.4 * z)} 0;${f1(-0.35 * z)} 0;${f1(0.2 * z)} 0;0 0`, 2.8, 0, ' keyTimes="0;0.7;0.77;0.84;0.9;1"')}${loc(P, box)}</g>`;
        const lp = { x: P.x + 0.6 * a, y: P.y + 0.85 * a * P.q }, lint = `M${f1(lp.x)} ${f1(lp.y)}q${f1(-1 * z)} ${f1(4 * z)} ${f1(0.6 * z)} ${f1(8 * z)}q${f1(1.4 * z)} ${f1(3 * z)} ${f1(-0.4 * z)} ${f1(6 * z)}`;
        ov += `<g>${at('rotate', `-8 ${f1(lp.x)} ${f1(lp.y)};8 ${f1(lp.x)} ${f1(lp.y)};-8 ${f1(lp.x)} ${f1(lp.y)}`, 2.2, 0, SPL(2))}<path d="${lint}" stroke="#7a766a" stroke-width="${f1(0.8 * z)}" fill="none" stroke-linecap="round"/><circle cx="${f1(lp.x - 0.4 * z)}" cy="${f1(lp.y + 14 * z)}" r="${f1(1.1 * z)}" fill="#8a8678"/></g>`; }
      { const P = cE(G, 0.015, 0.97), z = P.z, A = rep(6, k => (k / 5) * PI / 2); let d = A.map(a => `M${f1(P.x)} ${f1(P.y)}l${f1(Math.cos(a) * 14 * z)} ${f1(-Math.sin(a) * 6 * z)}`).join('');
        [0.35, 0.65, 0.95].forEach(k => { d += 'M' + A.map(a => f1(P.x + Math.cos(a) * 14 * z * k) + ' ' + f1(P.y - Math.sin(a) * 6 * z * k)).join('L'); }); s += `<path d="${d}" stroke="#f8f6ee" stroke-opacity="0.7" stroke-width="${f1(0.35 * G.s)}" fill="none"/>`; }
      return s + ov + cShade(G, 0.22, 0.04) + mould(G, 2, ['#bdb59a', '#dcd5bf'], '#f2eee2'); }

    // BTH-029 MOISTURE-RESISTANT PVC PANEL CEILING WITH LED VENT (T2): glossy white tongue-and-groove PVC strips running to the back wall (each a hair
    // different white, V-grooves with a lit lip, soft blurred reflections), a white PVC cove trim; a round low-profile vent with concentric slots and a warm
    // white LED ring, soft halo on the panels, air wisps curling into it, a few condensation beads. Live: the LED ring glows softly and the wisps turn.
    function cPvc(G) { const R = rng('pvc29'), NU = 30;
      let s = `<path d="${G.tr}" fill="#f2f3f0"/>`, gr = '';
      for (let i = -1; i <= NU; i++) s += `<path d="${G.quad(i / NU, -0.02, (i + 1) / NU, 1.02)}" fill="${['#f4f5f2', '#eef0ec', '#f6f7f4', '#f0f1ee'][(i + 4) % 4]}"/>`;
      for (let i = 0; i <= NU; i++) gr += 'M' + G.P(i / NU, -0.02) + 'L' + G.P(i / NU, 1.02);
      s += `<path d="${gr}" stroke="#b4b9b4" stroke-width="${f1(1 * G.s)}"/><path d="${gr}" stroke="#ffffff" stroke-width="${f1(0.6 * G.s)}" transform="translate(${f1(1.2 * G.s)} 0)"/>`;
      s += '<g filter="url(#cb3)">' + rep(14, () => { const u = R(), t0 = R() * 0.6; return `<path d="M${G.P(u, t0)}L${G.P(u, t0 + 0.2 + R() * 0.2)}" stroke="#ffffff" stroke-width="${f1((3 + R() * 5) * G.s)}" opacity="0.75"/>`; }).join('') + '</g>';
      s += '<g filter="url(#cb6)">' + [[0.08, 0.9], [0.92, 0.92]].map(([u, t]) => { const P = cE(G, u, t); return cEl(P, 26 * P.z, 4 * P.z, 'fill="#a8b0a8" opacity="0.14"'); }).join('') + '</g>';
      { const P = cE(G, 0.5, 0.45), z = P.z, r0 = 20 * z;
        let v = `<circle r="${f1(r0 * 2.6)}" fill="url(#b29h)">${an('opacity', '0.55;0.95;0.55', 6, 0, SPL(2))}</circle><circle r="${f1(r0 * 1.06)}" fill="#000000" opacity="0.12" transform="translate(${f1(0.5 * z)} ${f1(1 * z)})"/><circle r="${f1(r0)}" fill="url(#b29b)" stroke="#c4c8c4" stroke-width="${f1(0.4 * z)}"/>`;
        [0.86, 0.72, 0.58, 0.46].forEach((k, i) => { const r = r0 * k, c = 2 * PI * r, n = 18 - i * 2; v += `<circle r="${f1(r)}" fill="none" stroke="#3a3e3c" stroke-width="${f1(0.07 * r0)}" stroke-dasharray="${f1(c / n * 0.78)} ${f1(c / n * 0.22)}"/><circle r="${f1(r + 0.04 * r0)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.025 * r0)}" opacity="0.8"/>`; });
        v += `<circle r="${f1(r0 * 0.36)}" fill="#fbfbf8" stroke="#d4d8d4" stroke-width="${f1(0.3 * z)}"/><circle r="${f1(r0 * 0.3)}" fill="none" stroke="#fff0d2" stroke-width="${f1(0.18 * r0)}" filter="url(#cb1)">${an('opacity', '0.5;1;0.5', 6, 0, SPL(2))}</circle><circle r="${f1(r0 * 0.3)}" fill="none" stroke="#fffaf0" stroke-width="${f1(0.05 * r0)}"/>`;
        v += `<g>${at('rotate', '0;360', 14)}${rep(3, k => `<path d="M${f1(r0 * 2.2)} 0A${f1(r0 * 2.2)} ${f1(r0 * 2.2)} 0 0 1 ${f1(r0 * 0.6)} ${f1(r0 * 1.4)}" stroke="#d8dee0" stroke-width="${f1(0.5 * z)}" fill="none" stroke-linecap="round" transform="rotate(${k * 120})" opacity="0">${an('opacity', '0;0.6;0', 4.6, -k * 1.5)}</path>`).join('')}</g>`;
        v += [[-1.3, -0.6], [1.15, 0.9], [0.4, 1.4]].map(([x, y]) => `<circle cx="${f1(x * r0)}" cy="${f1(y * r0)}" r="${f1(0.06 * r0)}" fill="#dfe8ea"/><circle cx="${f1(x * r0 - 0.02 * r0)}" cy="${f1(y * r0 - 0.02 * r0)}" r="${f1(0.025 * r0)}" fill="#ffffff"/>`).join('');
        s += `<defs><radialGradient id="b29h"><stop offset="0.35" stop-color="#fff4dc" stop-opacity="0.5"/><stop offset="1" stop-color="#fff4dc" stop-opacity="0"/></radialGradient><radialGradient id="b29b" cx="45%" cy="40%" r="60%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.8" stop-color="#f2f3f0"/><stop offset="1" stop-color="#d6dad6"/></radialGradient></defs>` + loc(P, v); }
      return s + cShade(G, 0.12, 0.05) + mould(G, 2.4, ['#dcdfda', '#f4f5f2', '#ffffff'], '#ffffff'); }

    // BTH-049 AROMATIC RED CEDAR PLANK CEILING WITH SKYLIGHT (T3): red cedar boards running across the room with staggered butt joints, flowing grain,
    // knots and warm colour shifts; a deep white-painted skylight well with a slim bronze frame and mullion, blue sky with clouds drifting across, a fallen
    // maple leaf and condensation on the glass, warm daylight spilling onto the cedar round the opening; cedar crown. Live: clouds drift past.
    function cCedar(G) { const R = rng('cedar29'), NT = 15, CED = ['#b5653a', '#a85a32', '#c2784a', '#9c5230', '#b86c40', '#c98656', '#ad6036'];
      let s = `<path d="${G.tr}" fill="#a85c34"/>`, gr = '', jn = '', kn = '';
      for (let j = 0; j < NT; j++) { const t0 = j / NT, t1 = (j + 1) / NT; let u = -0.06 - R() * 0.2;
        while (u < 1.06) { const u1 = Math.min(1.06, u + 0.2 + R() * 0.32), c = CED[(R() * CED.length) | 0];
          s += `<path d="${G.quad(u, t0, u1, t1)}" fill="${c}"/>`;
          rep(4, () => { const tt = t0 + (t1 - t0) * (0.15 + R() * 0.7), w = (R() - 0.5) * (t1 - t0) * 0.5; let d = ''; for (let k = 0; k <= 10; k++) { const uu = u + (u1 - u) * k / 10, y = G.y(tt + w * Math.sin(k / 10 * PI * (1 + R()))); d += (k ? 'L' : 'M') + f1(G.x(uu, y)) + ' ' + f1(y); }
            gr += `<path d="${d}" stroke="${R() < 0.6 ? shade(c, 0.78) : shade(c, 1.18)}" stroke-width="${f1((0.4 + R() * 0.6) * G.s)}" fill="none" opacity="0.6"/>`; });
          if (R() < 0.16) { const P = cE(G, u + (u1 - u) * (0.2 + R() * 0.6), (t0 + t1) / 2); kn += cEl(P, 3 * P.z, 1.2 * P.z * P.q * 3, 'fill="#6a3418" opacity="0.45"') + cEl(P, 5 * P.z, 2 * P.z * P.q * 3, 'fill="none" stroke="#7a3a1a" stroke-width="' + f1(0.4 * P.z) + '" opacity="0.6"'); }
          jn += 'M' + G.P(u1, t0) + 'L' + G.P(u1, t1); u = u1; } }
      let hl = ''; for (let j = 1; j < NT; j++) hl += G.hl(G.y(j / NT));
      s += gr + kn + `<path d="${jn}" stroke="#3a1a0c" stroke-width="${f1(0.6 * G.s)}" opacity="0.6"/><path d="${hl}" stroke="#3a1a0c" stroke-width="${f1(1 * G.s)}" opacity="0.7"/><path d="${hl}" stroke="#ffd2a8" stroke-width="${f1(0.4 * G.s)}" opacity="0.35" transform="translate(0 ${f1(1 * G.s)})"/>`;
      // skylight
      const u0 = 0.4, u1 = 0.6, t0 = 0.22, t1 = 0.66, M = 1.06, O = G.quad(u0, t0, u1, t1), hp = (u, t, m) => { const y = G.y(t); return [G.x(u, y), cHi(G, y, m)]; };
      const TS = rep(9, i => t0 + (t1 - t0) * i / 8), US = rep(9, i => u0 + (u1 - u0) * i / 8), gq = 'M' + [hp(u0, t0, M), hp(u1, t0, M), hp(u1, t1, M), hp(u0, t1, M)].map(P2).join('L') + 'Z';
      const c = cE(G, 0.5, (t0 + t1) / 2), z = c.z, gy0 = hp(0.5, t0, M)[1], gy1 = hp(0.5, t1, M)[1], gx0 = G.x(u0, G.y(t0)) - 20 * z, gw = G.x(u1, G.y(t0)) - G.x(u0, G.y(t0)) + 40 * z;
      s += '<g filter="url(#cb6)">' + cEl(c, gw * 0.75, (G.y(t1) - G.y(t0)) * 0.95, 'fill="#ffe8c0" opacity="0.4"') + '</g>';
      let v = `<rect x="0" y="${f1(gy0 - 40 * z)}" width="${f1(G.W)}" height="${f1(gy1 - gy0 + 60 * z)}" fill="url(#b49k)"/>`;
      const cloud = (x, y, k) => `<g transform="translate(${f1(x)} ${f1(y)}) scale(${n4(k)})"><ellipse rx="9" ry="3" fill="#ffffff" opacity="0.9"/><circle cx="-3" cy="-1.6" r="3.2" fill="#ffffff"/><circle cx="2" cy="-2.6" r="4" fill="#ffffff"/><circle cx="5.6" cy="-0.8" r="2.6" fill="#f4f8fc"/><ellipse cy="1.8" rx="8" ry="1.4" fill="#d8e4ee" opacity="0.8"/></g>`;
      const cl = [[gx0 + gw * 0.2, gy0 + (gy1 - gy0) * 0.3, 1.1], [gx0 + gw * 0.75, gy0 + (gy1 - gy0) * 0.65, 0.8], [gx0 + gw * 1.3, gy0 + (gy1 - gy0) * 0.45, 1]].map(([x, y, k]) => cloud(x, y, k * z)).join('');
      v += `<g>${at('translate', `${f1(-gw * 0.1)} 0;${f1(-gw * 1.4)} 0`, 40)}${cl}<g transform="translate(${f1(gw * 1.3)} 0)">${cl}</g></g>`;
      v += `<circle cx="${f1(gx0 + gw * 0.95)}" cy="${f1(gy0)}" r="${f1(14 * z)}" fill="#fff8d8" opacity="0.5" filter="url(#cb3)"/>`;
      const lf = hp(0.555, t0 + (t1 - t0) * 0.72, M);
      v += `<g transform="translate(${P2(lf)}) scale(${n4(z)}) rotate(25)"><path d="M0 -3L0.9 -1.2L2.8 -1.8L2 0L3.2 1.2L1 1.2L0.6 3L0 1.8L-0.6 3L-1 1.2L-3.2 1.2L-2 0L-2.8 -1.8L-0.9 -1.2Z" fill="#7a3a14" opacity="0.75"/><path d="M0 1.8V4.2" stroke="#5a2a10" stroke-width="0.3" opacity="0.7"/></g>`;
      v += rep(26, () => { const p = hp(u0 + (u1 - u0) * R(), t0 + (t1 - t0) * R(), M); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1((0.25 + R() * 0.35) * z)}" fill="#ffffff" opacity="${f1(0.35 + R() * 0.35)}"/>`; }).join('');
      v += `<path d="M${P2(hp(0.5, t0, M))}L${P2(hp(0.5, t1, M))}M${US.map(u => P2(hp(u, (t0 + t1) / 2, M))).join('L')}" stroke="#4a3a28" stroke-width="${f1(1.4 * z)}" fill="none"/><path d="${gq}" fill="none" stroke="#4a3a28" stroke-width="${f1(2.2 * z)}"/><path d="${gq}" fill="none" stroke="#a88a5a" stroke-width="${f1(0.5 * z)}"/>`;
      const side = (u, col) => `<path d="M${TS.map(t => P2(hp(u, t, 1))).join('L')}L${TS.slice().reverse().map(t => P2(hp(u, t, M))).join('L')}Z" fill="${col}"/>`;
      v += side(u0, '#f4f0e8') + side(u1, '#dcd6cc') + `<path d="M${US.map(u => P2(hp(u, t1, 1))).join('L')}L${US.slice().reverse().map(u => P2(hp(u, t1, M))).join('L')}Z" fill="#fbf8f2"/>`;
      s += `<clipPath id="b49c"><path d="${O}"/></clipPath><g clip-path="url(#b49c)">${v}</g><path d="${O}" fill="none" stroke="#5a3018" stroke-width="${f1(3 * G.s)}"/><path d="${O}" fill="none" stroke="#e0a070" stroke-width="${f1(0.8 * G.s)}"/>`;
      s += `<defs><linearGradient id="b49k" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6aa8e0"/><stop offset="0.6" stop-color="#9cc8ee"/><stop offset="1" stop-color="#cfe4f4"/></linearGradient></defs>`;
      return s + cShade(G, 0.2, 0.05) + mould(G, 3, ['#6a3418', '#9a5230', '#c4784a'], '#e8a878'); }

    // BTH-069 VAULTED STEAM-DOME CEILING WITH CHROMOTHERAPY HALO (T4): warm ivory tadelakt ceiling (troweled sweeps, burnish) rising into a hammam dome
    // (shaded rings up to a glowing oculus), pierced by rings of star-shaped 'elephant eye' glass lenses that twinkle, a polished brass rim, and a hidden cove
    // halo that slowly cycles through soft amber, rose, lavender and sea-glass, tinting the dome; steam curls drift up into it.
    function cDome(G) { const R = rng('dome29'), P = cE(G, 0.5, 0.5), z = P.z, q = P.q, rowW = G.x(1, P.y) - G.x(0, P.y), RX = Math.min(rowW * 0.3, G.H * 0.5 / q), NR = 14;
      let s = `<path d="${G.tr}" fill="#efe4d2"/>` + cBl(G, 'dome29b', 12, ['#f8f0e2', '#dccbb0', '#f3e8d6'], 0.5, 60), sw = '';
      rep(70, () => { const Q = cE(G, R() * 1.1 - 0.05, 0.03 + R() * 0.95), rx = (8 + R() * 18) * Q.z, a0 = R() * 2 * PI, a1 = a0 + 0.9 + R() * 1.3; sw += `<path d="M${rep(9, k => { const a = a0 + (a1 - a0) * k / 8; return P2([Q.x + Math.cos(a) * rx, Q.y + Math.sin(a) * rx * Q.q]); }).join('L')}" stroke="${R() < 0.5 ? '#fbf4e6' : '#d6c4a4'}" stroke-width="${f1((2 + R() * 3.5) * Q.z)}" fill="none" stroke-linecap="round" opacity="0.3"/>`; });
      s += `<g filter="url(#cb3)">${sw}</g>`;
      const HC = '#ffc89a;#f6a8b8;#c8b0f0;#9ad8cc;#ffd89a;#ffc89a', ring = k => { const f = k / NR, ph = f * PI / 2; return { r: RX * Math.cos(ph), y: P.y - RX * q * 0.55 * Math.sin(ph) }; };
      s += '<g filter="url(#cb6)">' + `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(RX * 1.25)}" ry="${f1(RX * 1.25 * q)}" fill="#ffc89a" opacity="0.3">${an('fill', HC, 24)}</ellipse>` + '</g>';
      let d = '';
      for (let k = 0; k < NR; k++) { const a = ring(k), f = k / NR; d += `<ellipse cx="${f1(P.x)}" cy="${f1(a.y)}" rx="${f1(a.r)}" ry="${f1(a.r * q)}" fill="${shade('#cdb894', 0.86 + f * 0.36)}"/><ellipse cx="${f1(P.x)}" cy="${f1(a.y)}" rx="${f1(a.r)}" ry="${f1(a.r * q)}" fill="none" stroke="#a88c64" stroke-width="${f1(0.3 * z)}" opacity="0.5"/>`; }
      d += `<ellipse cx="${f1(P.x)}" cy="${f1(ring(NR - 1).y)}" rx="${f1(RX * 0.16)}" ry="${f1(RX * 0.16 * q)}" fill="#fff8ea"/><ellipse cx="${f1(P.x)}" cy="${f1(ring(NR - 1).y)}" rx="${f1(RX * 0.3)}" ry="${f1(RX * 0.3 * q)}" fill="#fff4dc" opacity="0.5" filter="url(#cb3)"/>`;
      d += `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(RX)}" ry="${f1(RX * q)}" fill="#ffc89a" opacity="0.18">${an('fill', HC, 24)}</ellipse>`;
      [[3, 14], [6, 11], [9, 8]].forEach(([k, n], j) => { const a = ring(k); rep(n, i => { const t = (i + j * 0.5) / n * 2 * PI, x = P.x + Math.cos(t) * a.r, y = a.y + Math.sin(t) * a.r * q, sz = (2.8 - j * 0.5) * z * (0.75 + 0.25 * Math.sin(t));
        d += `<g transform="translate(${f1(x)} ${f1(y)}) scale(1 ${n4(q * 1.6)})"><path d="${rep(8, m => { const aa = m / 8 * 2 * PI, rr = m % 2 ? sz * 0.5 : sz; return (m ? 'L' : 'M') + f1(Math.cos(aa) * rr) + ' ' + f1(Math.sin(aa) * rr); }).join('')}Z" fill="#fff6e0" stroke="#8a6a3a" stroke-width="${f1(0.3 * z)}"><animate attributeName="opacity" values="0.7;1;0.7" dur="${n4(3 + (i % 4))}s" begin="${n4(-i * 0.6 - j)}s" repeatCount="indefinite"/></path></g>`; }); });
      d += rep(6, i => { const t = i / 6 * 2 * PI, x0 = P.x + Math.cos(t) * RX * 0.85, y0 = P.y + Math.sin(t) * RX * 0.85 * q, yA = ring(NR - 2).y; return `<ellipse cx="${f1(x0)}" cy="${f1(y0)}" rx="${f1(8 * z)}" ry="${f1(3 * z)}" fill="#ffffff" opacity="0" filter="url(#cb3)">${an('opacity', '0;0.4;0', 10, -i * 1.6)}<animateTransform attributeName="transform" type="translate" values="0 0;${f1((P.x - x0) * 0.7)} ${f1((yA - y0) * 0.7)}" dur="10s" begin="${n4(-i * 1.6)}s" repeatCount="indefinite"/></ellipse>`; }).join('');
      s += `<clipPath id="b69c"><path d="${cD(P.x, P.y, RX, RX * q)}"/></clipPath><g clip-path="url(#b69c)">${d}</g>`;
      s += `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(RX + 3 * z)}" ry="${f1((RX + 3 * z) * q)}" fill="none" stroke="#ffc89a" stroke-width="${f1(7 * z)}" filter="url(#cb3)" opacity="0.75">${an('stroke', HC, 24)}</ellipse>`
        + `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(RX)}" ry="${f1(RX * q)}" fill="none" stroke="#8a6420" stroke-width="${f1(2.4 * z)}"/><ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(RX)}" ry="${f1(RX * q)}" fill="none" stroke="#e2b456" stroke-width="${f1(1.5 * z)}"/><ellipse cx="${f1(P.x)}" cy="${f1(P.y - 0.4 * z)}" rx="${f1(RX)}" ry="${f1(RX * q)}" fill="none" stroke="#fff0b8" stroke-width="${f1(0.4 * z)}"/>`;
      return s + cShade(G, 0.18, 0.05) + mould(G, 3, ['#cdb898', '#efe4d2', '#e2d2b8', '#fbf4e8'], '#ffffff', `<path d="${band(G, 3, 0, 1).lip}" stroke="#d4a548" stroke-width="${f1(0.6 * G.s)}" fill="none" transform="translate(0 ${f1(0.6 * G.s)})"/>`); }

    // BTH-089 ATMOSPHERIC RAIN-CLOUD & NEGATIVE-ION MIST CANOPY (T5): honed charcoal stone ceiling with a champagne light line in a shadow gap round a
    // huge brass-framed canopy of luminous opal glass where soft clouds drift; a grid of polished brass rain nozzles across it twinkles in a slow wave,
    // fine rain streaks fall from them, cool mist puffs roll beneath, and negative-ion sparkles glint in the air.
    function cRain(G) { const R = rng('rain29'), u0 = 0.15, u1 = 0.85, t0 = 0.14, t1 = 0.86, O = G.quad(u0, t0, u1, t1), OG = G.quad(u0 - 0.012, t0 - 0.03, u1 + 0.012, t1 + 0.025);
      let s = `<path d="${G.tr}" fill="#34302c"/>` + cBl(G, 'rain29b', 14, ['#403a34', '#2a2622', '#3a3530'], 0.6, 60);
      let sl = ''; for (let i = 1; i < 6; i++) sl += 'M' + G.P(i / 6, 0) + 'L' + G.P(i / 6, 1); for (let j = 1; j < 3; j++) sl += G.hl(G.y(j / 3));
      s += `<path d="${sl}" stroke="#1e1a16" stroke-width="${f1(0.8 * G.s)}" opacity="0.6"/>` + rep(60, () => { const P = cE(G, R(), R()); return cEl(P, 0.4 * P.z, 0.4 * P.z * P.q, 'fill="#8a8070" opacity="0.4"'); }).join('');
      s += `<path d="${OG}" fill="#0e0c0a"/><path d="${OG}" fill="none" stroke="#ffe2a8" stroke-width="${f1(5 * G.s)}" filter="url(#cb3)" opacity="0.55">${an('opacity', '0.35;0.7;0.35', 7, 0, SPL(2))}</path><path d="${OG}" fill="none" stroke="#fff0c8" stroke-width="${f1(0.6 * G.s)}"/>`;
      let v = `<rect width="${f1(G.W)}" height="${f1(G.H)}" fill="url(#b89g)"/>`;
      const c = cE(G, 0.5, 0.5), z = c.z, cw = G.x(u1, c.y) - G.x(u0, c.y);
      const puff = (x, y, k, op) => `<g transform="translate(${f1(x)} ${f1(y)}) scale(${n4(k)})" opacity="${op}"><ellipse rx="16" ry="4" fill="#ffffff"/><ellipse cx="-6" cy="-2" rx="7" ry="3.4" fill="#ffffff"/><ellipse cx="4" cy="-2.6" rx="8" ry="3.8" fill="#ffffff"/><ellipse cy="1.6" rx="14" ry="2" fill="#c8d0dc" opacity="0.6"/></g>`;
      const cl = rep(6, i => { const t = t0 + (t1 - t0) * (0.15 + (i % 3) * 0.33), P = cE(G, u0 + (u1 - u0) * (i / 6 + 0.05), t); return puff(P.x, P.y, P.z * (0.9 + (i % 2) * 0.5), f1(0.55 + (i % 3) * 0.12)); }).join('');
      v += `<g filter="url(#cb3)"><g>${at('translate', `0 0;${f1(-cw * 0.5)} 0`, 60)}${cl}<g transform="translate(${f1(cw * 0.5)} 0)">${cl}</g></g></g>`;
      v += `<ellipse cx="${f1(c.x)}" cy="${f1(c.y)}" rx="${f1(cw * 0.4)}" ry="${f1(cw * 0.4 * c.q)}" fill="url(#b89o)">${an('opacity', '0.5;0.9;0.5', 10, 0, SPL(2))}</ellipse>`;
      const NU = 22, NT = 9; let nz = '', tw = '', rn = '';
      for (let j = 0; j < NT; j++) for (let i = 0; i < NU; i++) { const P = cE(G, u0 + (u1 - u0) * (i + 0.5) / NU, t0 + (t1 - t0) * (j + 0.5) / NT), r = 1 * P.z;
        nz += cEl(P, r, r * P.q * 1.6, 'fill="#8a6420"') + cEl(P, r * 0.7, r * 0.7 * P.q * 1.6, 'fill="#e2b456"', -0.2 * P.z);
        tw += `<circle cx="${f1(P.x)}" cy="${f1(P.y - 0.3 * P.z)}" r="${f1(r * 0.45)}" fill="#fff6d8" opacity="0"><animate attributeName="opacity" values="0;0;1;0" keyTimes="0;0.8;0.88;1" dur="6s" begin="${n4(-(6 - i / NU * 4 - j / NT * 1.2))}s" repeatCount="indefinite"/></circle>`;
        if (R() < 0.18) { const L = (6 + R() * 6) * P.z, T = 1.1 + R() * 0.8, b = n4(-R() * T); rn += `<path d="M${f1(P.x)} ${f1(P.y)}v${f1(L)}" stroke="#e8f0f8" stroke-width="${f1(0.4 * P.z)}" stroke-linecap="round" opacity="0"><animate attributeName="opacity" values="0;0.8;0" dur="${n4(T)}s" begin="${b}s" repeatCount="indefinite"/><animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(L * 1.4)}" dur="${n4(T)}s" begin="${b}s" repeatCount="indefinite"/></path>`; } }
      v += nz + tw + rn;
      v += '<g filter="url(#cb6)">' + rep(5, i => { const P = cE(G, u0 + (u1 - u0) * (0.1 + i * 0.2), t0 + (t1 - t0) * (0.3 + (i % 2) * 0.4)), T = n4(9 + i), b = n4(-i * 2); return `<ellipse cx="${f1(P.x)}" cy="${f1(P.y)}" rx="${f1(30 * P.z)}" ry="${f1(6 * P.z)}" fill="#eef4fa" opacity="0"><animate attributeName="opacity" values="0;0.45;0" dur="${T}s" begin="${b}s" repeatCount="indefinite"/><animateTransform attributeName="transform" type="translate" values="0 0;${f1(30 * P.z)} ${f1(3 * P.z)}" dur="${T}s" begin="${b}s" repeatCount="indefinite"/></ellipse>`; }).join('') + '</g>';
      v += rep(18, i => { const P = cE(G, u0 + (u1 - u0) * R(), t0 + (t1 - t0) * R()), k = P.z; return `<path d="M${f1(P.x - 1.6 * k)} ${f1(P.y)}H${f1(P.x + 1.6 * k)}M${f1(P.x)} ${f1(P.y - 1 * k)}V${f1(P.y + 1 * k)}" stroke="#f4f8ff" stroke-width="${f1(0.25 * k)}" stroke-linecap="round" opacity="0">${an('opacity', '0;0;0.9;0', 4 + (i % 4), -i * 0.7, ' keyTimes="0;0.7;0.8;1"')}</path>`; }).join('');
      s += `<clipPath id="b89c"><path d="${O}"/></clipPath><g clip-path="url(#b89c)">${v}</g>`;
      s += `<path d="${O}" fill="none" stroke="#6a4612" stroke-width="${f1(3.2 * G.s)}"/><path d="${O}" fill="none" stroke="url(#b89b)" stroke-width="${f1(2 * G.s)}"/><path d="${O}" fill="none" stroke="#fff0c0" stroke-width="${f1(0.4 * G.s)}" transform="translate(0 ${f1(-0.5 * G.s)})"/>`;
      s += `<defs><linearGradient id="b89g" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="${f1(G.H)}"><stop offset="0" stop-color="#b8c6d6"/><stop offset="0.6" stop-color="#cdd2d8"/><stop offset="1" stop-color="#e2d8cc"/></linearGradient>`
        + '<radialGradient id="b89o"><stop offset="0" stop-color="#fff6e4" stop-opacity="0.7"/><stop offset="1" stop-color="#fff6e4" stop-opacity="0"/></radialGradient><linearGradient id="b89b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8a5f1e"/><stop offset="0.35" stop-color="#f2cf7a"/><stop offset="0.5" stop-color="#fff0b8"/><stop offset="0.7" stop-color="#d9a84a"/><stop offset="1" stop-color="#7a5418"/></linearGradient></defs>';
      return s + cShade(G, 0.12, 0.04) + mould(G, 2.6, ['#1e1a16', '#4a3e30', '#c99a44'], '#fff0c8', `<path d="${band(G, 2.6, 0, 1).lip}" stroke="#ffd99a" stroke-width="${f1(3 * G.s)}" fill="none" filter="url(#cb3)" opacity="0.5">${an('opacity', '0.3;0.65;0.3', 6, 0, SPL(2))}</path>`); }

    const CEIL29 = { peel: cPeel, pvc: cPvc, cedar: cCedar, dome: cDome, rain: cRain }, CM29 = {};
    const WALL29 = { peel: 'b01tile', pvc: 'b21sub', cedar: 'b41slate', dome: 'b61tad', rain: 'b81onyx' };
    const CB29 = { peel: ['#e2dcc6', '#cfc8b2'], pvc: ['#f2f3f0', '#ffffff'], cedar: ['#b06238', '#7a3a1c'], dome: ['#efe4d2', '#c99a44'], rain: ['#34302c', '#c99a44'] };
    const cardOf29 = k => { const G = mkV(CFRM.card), S = SURF12[WALL29[k]](), ws = { peel: '#d8d2bc', pvc: '#a6d8c2', cedar: '#555b62', dome: '#d6ae88', rain: '#e8c078' }[k];
      return `<svg x="16" y="26" width="48" height="30" viewBox="0 0 80 56" preserveAspectRatio="xMidYMax slice">${wTile(S)}</svg><path d="M0 0L16 26V56H0Z" fill="${shade(ws, 0.86)}"/><path d="M80 0L64 26V56H80Z" fill="${shade(ws, 0.78)}"/><path d="M16 26V56M64 26V56" stroke="#000000" stroke-opacity="0.2" stroke-width="0.6"/>`
        + cDoc(G, CEIL29[k](G)) + `<path d="${G.tr}" fill="none" stroke="#000000" stroke-opacity="0.25" stroke-width="0.5"/>`; };
    const draw29c = RD.draw;
    RD.draw = (r, o) => { const res = draw29c(r, o); if (!res || res._p29c) return res;
      try { const c = r.c29 && CEIL29[r.c29]; if (c && res.surf) { res._p29c = 1; res.vb = '0 0 80 56';
          const M = CM29[r.c29] || (CM29[r.c29] = (() => { const G = mkV(CFRM.room); return { svg: RD.svgDoc('0 0 80 56', [], cardOf29(r.c29)), room: RD.svgDoc('0 0 ' + G.W + ' ' + G.H, [], cDoc(G, c(G))) }; })());
          res.svg = M.svg; res.src = 'data:image/svg+xml,' + encodeURIComponent(M.svg); res.ceilRoom = M.room; res.ceilBase = CB29[r.c29][0]; res.ceilTrim = CB29[r.c29][1]; } } catch (e) { console.warn('reno plus29 ceil', r.id, e); }
      return res; };
    RD.H29C = { CEIL29, cardOf29 };
  }

  // ======================= LIGHTING (BTH-013/033/053/073/093): wall pieces like the accents (053 stays a FLOOR piece: saved houses keep it on the floor) =======================
  { const { box3, cyl3 } = RD.H15, { WD } = RD.H12, { ext } = RD.H11, DEF19 = RD.H19.DEF19, { shadow, dot } = H;
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const line3 = (C, P, w, col, ex) => '<path d="M' + P.map(p => PP(C, p)).join('L') + '" stroke="' + col + '" stroke-width="' + f1(w * C.k) + '" fill="none" stroke-linecap="round" stroke-linejoin="round"' + (ex ? ' ' + ex : '') + '/>';
    const swayAt = (C, p, a, d, ph, inner) => { const q = C.P(p), o = f1(q[0]) + ' ' + f1(q[1]); return '<g>' + at('rotate', (-a) + ' ' + o + ';' + a + ' ' + o + ';' + (-a) + ' ' + o, d, -ph, SPL(2)) + inner + '</g>'; };
    const vsort = (C, L) => L.sort((a, b) => dot(a.q, C.v) - dot(b.q, C.v)).map(o => o.s).join('');
    const glowW = (C, x, y, rx, ry, col, op, A) => WD(C, x - rx, y + ry, 0.03, `<ellipse cx="${f1(rx)}" cy="${f1(ry)}" rx="${f1(rx)}" ry="${f1(ry)}" fill="${col}" opacity="${op}" filter="url(#m11b8)">${A || ''}</ellipse>`);
    const FLK = (T, b) => `<animate attributeName="opacity" values="1;1;0.25;1;0.1;0.8;1;1" keyTimes="0;0.55;0.57;0.59;0.62;0.64;0.67;1" dur="${T}s" begin="${n4(b || 0)}s" repeatCount="indefinite"/>`;

    // BTH-013 FLICKERING FLUORESCENT TUBE OVER THE MIRROR (T1): a cheap enamel strip light with a yellowed, cracked prismatic lens (dead bugs collected
    // inside), one end cap gone so the bare tube shows with its blackened end, rusty screws and a rust dribble, a grey cord stapled up the wall and a ball-chain
    // pull switch that sways. Live: the tube stutters and the greenish wash on the wall flickers with it.
    N.fluor29 = S => { const D = { w: 72, d: 10, mount: 'wall', elev: 92, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('fluor29'), id = C.u('b13'), W0 = 60;
        ext(C, [[-36, 26, 0], [36, -22, 0], [36, -22, 8]]);
        let s = glowW(C, 0, -2, 44, 18, '#e4f6e8', 0.45, FLK(5.2));
        s += WD(C, -34, 24, 0.04, `<path d="M3 0V19Q3 20.4 4.6 21" stroke="#7a7a74" stroke-width="0.7" fill="none"/>${[2.6, 7.4, 11.4].map(y => `<path d="M2.2 ${y}h1.6v0.7h-1.6" stroke="#b8b8b0" stroke-width="0.25" fill="none"/>`).join('')}`);
        s += WD(C, -27.6, -2.8, 0.04, '<path d="M0 0Q0.3 3 -0.2 6.4L0.5 6.6Q0.8 3 0.6 0Z" fill="#9a5a24" opacity="0.4"/>');
        const lens = `<rect width="${W0}" height="4.4" fill="#f2ecc8"/><rect width="${W0}" height="4.4" fill="url(#${id}p)"/><rect width="${W0}" height="4.4" fill="url(#${id}g)">${FLK(5.2)}</rect>`
          + [[9, 1.4], [10.6, 2.6], [31, 2], [44, 1.2], [45.2, 2.8], [46, 1.9]].map(([x, y]) => `<ellipse cx="${x}" cy="${y}" rx="0.5" ry="0.25" fill="#3a3020" opacity="0.6" transform="rotate(${f1(R() * 180)} ${x} ${y})"/>`).join('')
          + '<path d="M38 0.2L39.4 1.8L38.8 2.6L40.6 4.2" stroke="#8a8060" stroke-width="0.15" fill="none"/><rect width="60" height="0.5" fill="#c8bc8c" opacity="0.7"/><rect x="50" width="10" height="4.4" fill="#d8cc9a" opacity="0.5"/>';
        s += box3(C, { c: [2, -3.4, 1.4], w: W0 + 4, h: 7, d: 2.8, col: '#e6e2d4', r: 0.4, dec: { f: rep(4, () => `<ellipse cx="${f1(R() * 60)}" cy="${f1(R() * 6)}" rx="${f1(0.4 + R())}" ry="0.3" fill="#a89a6a" opacity="0.4"/>`).join('') } });
        s += box3(C, { c: [5, -2.8, 4.4], w: W0 - 6, h: 5.4, d: 3.2, col: '#efe8c6', r: 0.6, dec: { f: lens } });
        s += cyl3(C, [-28.4, -0.1, 4.4], [-22, -0.1, 4.4], 1.2, '#f6f6ee', { n: 12, capCol: '#2a2622' }) + cyl3(C, [-28.6, -0.1, 4.4], [-27.2, -0.1, 4.4], 1.22, '#3a342c', { n: 12, noCap: 1 })
          + `<g>${FLK(5.2)}${cyl3(C, [-26.8, -0.1, 4.4], [-22.2, -0.1, 4.4], 0.9, '#f4fff6', { n: 12, noCap: 1 })}</g>`;
        [-26, 30].forEach(x => s += cyl3(C, [x, -0.4, 2.8], [x, -0.4, 3.1], 0.55, '#8a6a4a', { n: 10 }));
        const ch = rep(14, i => [31, -6.4 - i * 0.8, 3.4]);
        s += swayAt(C, [31, -6, 3.4], 4, 3.4, 0.4, `<path d="M${ch.map(p => PP(C, p)).join('L')}" stroke="#9a9a92" stroke-width="${f1(0.45 * C.k)}" stroke-dasharray="${f1(0.3 * C.k)} ${f1(0.25 * C.k)}" fill="none"/>` + H.sph(C, [31, -18, 3.4], 0.9, '#b8b8b0'));
        return { defs: DEF19 + `<defs><pattern id="${id}p" width="1.2" height="1.2" patternUnits="userSpaceOnUse"><path d="M0.6 0L1.2 0.6L0.6 1.2L0 0.6Z" fill="none" stroke="#ffffff" stroke-width="0.12" opacity="0.7"/></pattern><linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.2"/><stop offset="0.5" stop-color="#f6fff4" stop-opacity="0.85"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.3"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BTH-033 FROSTED GLASS GLOBE VANITY BAR (T2): a polished chrome backplate bar with three curved chrome arms and fitters holding satin-frosted glass globes
    // glowing warm white (one a slightly whiter replacement), soft pools of light on the wall above and below. Live: the warm glow gently breathes.
    N.globe29 = S => { const D = { w: 80, d: 14, mount: 'wall', elev: 90, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('b33'), CH = '#d4dae0', GX = [-24, 0, 24], GY = 5.4, GZ = 8, GR = 6.4;
        ext(C, [[-34, 14, 0], [34, -8, 0], [34, -8, 14]]);
        let s = GX.map((x, i) => glowW(C, x, GY, 16, 14, '#fff0d0', 0.55, an('opacity', '0.45;0.65;0.45', 7, -i * 1.3, SPL(2)))).join('');
        s += box3(C, { c: [0, -3.2, 0.8], w: 64, h: 4.4, d: 1.6, col: CH, r: 0.8, gl: 0.2, dec: { f: '<rect width="64" height="0.6" fill="#ffffff" opacity="0.8"/><rect y="3.6" width="64" height="0.8" fill="#6a7076" opacity="0.4"/><path d="M8 1.4H40" stroke="#ffffff" stroke-width="0.4" opacity="0.6"/>' } });
        const items = GX.map((x, i) => { let g = line3(C, [[x, -1, 1.6], [x, -1.6, 4.4], [x, -0.6, GZ], [x, GY - GR - 0.8, GZ]], 1, '#8a9096') + line3(C, [[x, -1, 1.6], [x, -1.6, 4.4], [x, -0.6, GZ], [x, GY - GR - 0.8, GZ]], 0.6, CH)
            + cyl3(C, [x, GY - GR - 1.6, GZ], [x, GY - GR + 0.6, GZ], 1.9, CH, { mat: 'gloss', n: 16, r2: 2.3 });
          const c = C.P([x, GY, GZ]), r = GR * C.k, wh = i === 2 ? '#fbfaf6' : '#f6efe0';
          g += `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r)}" fill="${wh}"/><circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r)}" fill="url(#${id}f)"/><circle cx="${f1(c[0])}" cy="${f1(c[1] + r * 0.1)}" r="${f1(r * 0.62)}" fill="url(#${id}c)">${an('opacity', '0.75;1;0.75', 7, -i * 1.3, SPL(2))}</circle>`
            + `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(r)}" fill="none" stroke="#c8bca4" stroke-width="${f1(0.3 * C.k)}"/><ellipse cx="${f1(c[0] - r * 0.4)}" cy="${f1(c[1] - r * 0.45)}" rx="${f1(r * 0.3)}" ry="${f1(r * 0.18)}" fill="#ffffff" opacity="0.7" transform="rotate(-30 ${f1(c[0] - r * 0.4)} ${f1(c[1] - r * 0.45)})"/>`
            + `<ellipse cx="${f1(c[0])}" cy="${f1(c[1] - r * 0.86)}" rx="${f1(r * 0.42)}" ry="${f1(r * 0.12)}" fill="#a8a090" opacity="0.5"/>`;
          return { q: [x, GY, GZ], s: g }; });
        s += vsort(C, items);
        return { defs: DEF19 + `<defs><radialGradient id="${id}f" cx="40%" cy="38%" r="65%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.6"/><stop offset="0.7" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#b8a888" stop-opacity="0.35"/></radialGradient><radialGradient id="${id}c"><stop offset="0" stop-color="#fffaf0"/><stop offset="0.6" stop-color="#ffe8b8" stop-opacity="0.6"/><stop offset="1" stop-color="#ffe0a8" stop-opacity="0"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BTH-053 WARM WOOD & RICE-PAPER ONSEN LANTERN SCONCES (T3, floor piece): a hinoki lantern post on a split-granite base with a little shingled cap and two
    // carved arms, each holding an andon lantern (hinoki frame, kumiko lattice over warm rice paper) glowing like candlelight, a pool of light on the floor,
    // and a tiny moth circling one lantern. Live: the paper lanterns flicker softly.
    N.lant29 = S => { const D = { w: 44, d: 26, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('lant29'), id = C.u('b53'), HN = '#d8b47c', PH = 74, LY = 40, LH = 15, LW = 10.4;
        const grain = (w, h, n) => rep(n, () => { const x = R() * w; return `<path d="M${f1(x)} 0L${f1(x + (R() - 0.5) * 0.6)} ${h}" stroke="#a87a44" stroke-width="0.12" opacity="0.6"/>`; }).join('');
        const paper = (w, h) => `<rect width="${w}" height="${h}" fill="#fff4dc"/><rect width="${w}" height="${h}" fill="url(#${id}g)">${an('opacity', '0.8;1;0.85;1;0.8', 3.2, -R() * 3, SPL(4))}</rect>`
          + rep(14, () => `<path d="M${f1(R() * w)} ${f1(R() * h)}l${f1(R() * 2)} ${f1((R() - 0.5) * 0.6)}" stroke="#e8d4a8" stroke-width="0.1"/>`).join('')
          + `<path d="M${f1(w / 3)} 0V${h}M${f1(2 * w / 3)} 0V${h}M0 ${f1(h / 4)}H${w}M0 ${f1(h / 2)}H${w}M0 ${f1(3 * h / 4)}H${w}" stroke="#8a5e30" stroke-width="0.45"/>`
          + `<path d="M0 0H${w}V${h}H0Z" fill="none" stroke="#7a5028" stroke-width="1"/>`;
        let s = shadow(C, 0, 0, 22, 14, 0.5) + PLN0(C, `<ellipse cx="0" cy="0" rx="26" ry="16" fill="#ffd890" opacity="0.28" filter="url(#m11b8)">${an('opacity', '0.22;0.34;0.24;0.32;0.22', 3.6, 0, SPL(4))}</ellipse>`);
        const base = box3(C, { c: [0, 0, 0], w: 15, h: 5, d: 15, col: '#8a8884', r: 1, dec: { f: rep(10, () => `<circle cx="${f1(R() * 15)}" cy="${f1(R() * 5)}" r="0.2" fill="#ffffff" opacity="0.5"/>`).join(''), t: rep(16, () => `<circle cx="${f1(R() * 15)}" cy="${f1(R() * 15)}" r="0.2" fill="#3a3834" opacity="0.5"/>`).join('') } });
        const post = box3(C, { c: [0, 5, 0], w: 4.4, h: PH - 5, d: 4.4, col: HN, r: 0.3, dec: { f: grain(4.4, PH - 5, 5), l: grain(4.4, PH - 5, 5), r: grain(4.4, PH - 5, 5), b: grain(4.4, PH - 5, 5) } })
          + box3(C, { c: [0, PH, 0], w: 9, h: 1.6, d: 9, col: '#5a4030', r: 0.3 }) + box3(C, { c: [0, PH + 1.6, 0], w: 6, h: 2.2, d: 6, col: '#6a4a34', r: 0.6 }) + box3(C, { c: [0, PH + 3.8, 0], w: 2.4, h: 1.6, d: 2.4, col: '#c99a3e', r: 0.8 });
        const arm = sg => box3(C, { c: [sg * 9, LY + LH + 9, 0], w: 14, h: 2.2, d: 2.6, col: HN, r: 0.4, dec: { f: grain(14, 2.2, 3) } }) + box3(C, { c: [sg * 15.2, LY + LH + 6, 0], w: 1.6, h: 3.2, d: 1.6, col: '#5a4030', r: 0.3 });
        const lantern = sg => { const x = sg * 15.2, P = paper(LW, LH - 3);
          let g = box3(C, { c: [x, LY, 0], w: LW + 1.6, h: 1.6, d: LW + 1.6, col: '#7a5028', r: 0.3 }) + box3(C, { c: [x, LY + 1.6, 0], w: LW, h: LH - 3, d: LW, col: '#fff0d0', r: 0.1, dec: { f: P, b: P, l: P, r: P } })
            + box3(C, { c: [x, LY + LH - 1.4, 0], w: LW + 1.2, h: 1.4, d: LW + 1.2, col: '#a87a48', r: 0.3, dec: { t: `<rect width="${LW + 1.2}" height="${LW + 1.2}" fill="#b8885a"/>` + grain(LW + 1.2, LW + 1.2, 6) + `<rect x="${f1(LW / 2 - 2)}" y="${f1(LW / 2 - 2)}" width="5.2" height="5.2" fill="#3a2414"/><rect x="${f1(LW / 2 - 1.6)}" y="${f1(LW / 2 - 1.6)}" width="4.4" height="4.4" fill="#ffd890" opacity="0.6"/>` } }) + line3(C, [[x, LY + LH, 0], [x, LY + LH + 5, 0]], 0.3, '#3a2a1a');
          return g; };
        const items = [{ q: [0, 30, 0], s: base + post }, { q: [-12, LY + 8, 0.5], s: arm(-1) + lantern(-1) }, { q: [12, LY + 8, 0.5], s: arm(1) + lantern(1) }];
        s += vsort(C, items);
        [-15.2, 15.2].forEach((x, i) => { const c = C.P([x, LY + 7, 0]); s += `<circle cx="${f1(c[0])}" cy="${f1(c[1])}" r="${f1(13 * C.k)}" fill="url(#${id}h)" opacity="0.7">${an('opacity', '0.55;0.8;0.6;0.75;0.55', 3.4 + i * 0.6, -i, SPL(4))}</circle>`; });
        const mc = C.P([15.2, LY + 10, 6]), k = C.k, mp = `M${f1(mc[0] - 9 * k)} ${f1(mc[1])}a${f1(9 * k)} ${f1(4 * k)} 0 1 0 ${f1(18 * k)} 0a${f1(9 * k)} ${f1(4 * k)} 0 1 0 ${f1(-18 * k)} 0`;
        s += `<g><animateMotion path="${mp}" dur="7s" repeatCount="indefinite"/><g transform="scale(${n4(k)})"><path d="M0 0L-1.4 -0.9L-1.2 0.4ZM0 0L1.4 -0.9L1.2 0.4Z" fill="#e8dcc4"><animateTransform attributeName="transform" type="scale" values="1 1;1 0.3;1 1" dur="0.16s" repeatCount="indefinite"/></path><ellipse rx="0.3" ry="0.6" fill="#8a7a5a"/></g></g>`;
        C.p(0, PH + 8, 0);
        return { defs: DEF19 + `<defs><radialGradient id="${id}g" cx="50%" cy="55%" r="65%"><stop offset="0" stop-color="#fff8e4"/><stop offset="0.6" stop-color="#ffe2a0" stop-opacity="0.6"/><stop offset="1" stop-color="#f0b860" stop-opacity="0.5"/></radialGradient><radialGradient id="${id}h"><stop offset="0" stop-color="#ffe8b0" stop-opacity="0.5"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient></defs>`, front: s, bb: C.bb(6) }; };
      return D; };
    const PLN0 = (C, svg) => `<g transform="${H.FR(C, [0, 0.05, 0], [1, 0, 0], [0, 0, 1])}">${svg}</g>`;

    // BTH-073 RECESSED WATERPROOF HIMALAYAN SALT-GLOW WALL LIGHTS (T4): three square niches set into the wall at skirting height, each with a brushed brass
    // bezel and a sealed glass cover beaded with condensation over a rough-hewn block of pink-orange Himalayan salt (facets, white mineral veins) lit from
    // behind; warm rose light spills across the wall and floor. Live: each block slowly breathes, out of step with the others.
    N.salt29 = S => { const D = { w: 96, d: 6, mount: 'wall', elev: 16, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('salt29'), id = C.u('b73'), NX = [-32, 0, 32], NS = 18, IN = 14;
        ext(C, [[-46, 14, 0], [46, -14, 0], [46, -14, 3]]);
        let s = NX.map((x, i) => glowW(C, x, 0, 22, 16, '#ffb898', 0.5, an('opacity', '0.35;0.6;0.35', 8, -i * 2.6, SPL(2)))).join('');
        NX.forEach((x, i) => { const Q = rng('salt' + i);
          let a = `<rect width="${IN}" height="${IN}" fill="url(#${id}s)"/>`;
          rep(16, () => { const cx = Q() * IN, cy = Q() * IN, P = rep(5, k => { const t = k / 5 * 2 * PI + Q() * 0.6, r = 1.6 + Q() * 2.6; return [cx + Math.cos(t) * r, cy + Math.sin(t) * r]; }); a += `<path d="M${P.map(pt).join('L')}Z" fill="${['#ffd8a8', '#f8a060', '#e87a48', '#ffe8c8', '#fbb478'][(Q() * 5) | 0]}" opacity="${f1(0.25 + Q() * 0.3)}"/><path d="M${pt(P[0])}L${pt(P[1])}" stroke="#fff4e8" stroke-width="0.12" opacity="0.7"/>`; });
          a += rep(3, () => { let d = `M${f1(Q() * IN)} 0`; for (let y = 2; y <= IN; y += 2) d += `L${f1(Q() * IN)} ${y}`; return `<path d="${d}" stroke="#fff6e8" stroke-width="${f1(0.12 + Q() * 0.15)}" fill="none" opacity="0.35" stroke-linejoin="round"/>`; }).join('');
          a += `<rect width="${IN}" height="${IN}" fill="url(#${id}c)">${an('opacity', '0.55;1;0.55', 8, -i * 2.6, SPL(2))}</rect><rect width="${IN}" height="${IN}" fill="url(#${id}v)"/>`;
          a += `<path d="M0 0H${IN * 0.4}L0 ${IN * 0.7}Z" fill="#ffffff" opacity="0.12"/>` + rep(9, () => { const bx = Q() * IN, by = Q() * IN, r = 0.18 + Q() * 0.25; return `<circle cx="${f1(bx)}" cy="${f1(by)}" r="${f1(r)}" fill="#ffffff" opacity="0.4"/><circle cx="${f1(bx - r * 0.3)}" cy="${f1(by - r * 0.3)}" r="${f1(r * 0.35)}" fill="#ffffff" opacity="0.9"/>`; }).join('');
          const bez = `<rect width="${NS}" height="${NS}" rx="0.6" fill="url(#${id}b)"/><rect x="0.5" y="0.5" width="${NS - 1}" height="${NS - 1}" rx="0.4" fill="none" stroke="#fff0c0" stroke-width="0.15" opacity="0.8"/>` + rep(12, k => `<path d="M0.6 ${f1(0.8 + k * 1.4)}H${NS - 0.6}" stroke="#ffffff" stroke-width="0.06" opacity="0.25"/>`).join('')
            + `<rect x="${(NS - IN) / 2 - 0.3}" y="${(NS - IN) / 2 - 0.3}" width="${IN + 0.6}" height="${IN + 0.6}" fill="#4a2a1a"/><g transform="translate(${(NS - IN) / 2} ${(NS - IN) / 2})">${a}</g><rect x="${(NS - IN) / 2}" y="${(NS - IN) / 2}" width="${IN}" height="1.2" fill="#000000" opacity="0.3"/>`
            + [[1, 1], [NS - 1, 1], [1, NS - 1], [NS - 1, NS - 1]].map(([cx, cy]) => `<circle cx="${cx}" cy="${cy}" r="0.35" fill="#8a6420"/><path d="M${cx - 0.25} ${cy}h0.5" stroke="#4a3010" stroke-width="0.1"/>`).join('');
          s += box3(C, { c: [x, -NS / 2, 0.3], w: NS, h: NS, d: 0.6, col: '#c99a3e', r: 0.2, dec: { f: bez } }); });
        return { defs: DEF19 + `<defs><linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffc07a"/><stop offset="0.5" stop-color="#f6955a"/><stop offset="1" stop-color="#d86a40"/></linearGradient><radialGradient id="${id}c" cx="50%" cy="55%" r="60%"><stop offset="0" stop-color="#fff6dc" stop-opacity="0.95"/><stop offset="0.5" stop-color="#ffd8a0" stop-opacity="0.5"/><stop offset="1" stop-color="#ff9a78" stop-opacity="0"/></radialGradient>`
          + `<radialGradient id="${id}v" cx="50%" cy="50%" r="72%"><stop offset="0.55" stop-color="#5a1a10" stop-opacity="0"/><stop offset="1" stop-color="#5a1a10" stop-opacity="0.5"/></radialGradient><linearGradient id="${id}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f2d488"/><stop offset="0.4" stop-color="#c99a3e"/><stop offset="0.7" stop-color="#e2b456"/><stop offset="1" stop-color="#8a6420"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BTH-093 CIRCADIAN BIOLUMINESCENT JELLYFISH LIGHT ORBS (T5): a polished brass wall rail with three swan-neck arms, each hanging a hand-blown glass orb on a
    // fine brass chain under a fluted cap. Inside each, a glowing moon jelly pulses and drifts among sparkling plankton; the water light follows a slow circadian
    // day (dawn amber, soft daylight, dusk rose, night blue) and washes the wall behind. Live: the jellies pulse and the orbs gently sway.
    N.jelly29 = S => { const D = { w: 104, d: 20, mount: 'wall', elev: 66, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('jelly29'), id = C.u('b93'), BR = '#c99a3e', CYC = '#ffb860;#fff0d0;#ff98b8;#6a88ff;#ffb860', OR = [[-32, 6, 8.6, 11], [0, 0, 10.4, 13], [32, 8, 7.8, 12]];
        ext(C, [[-48, 34, 0], [48, -14, 0], [48, -14, 18]]);
        let s = OR.map(([x, y, r], i) => WD(C, x - 24, y + 22, 0.03, `<ellipse cx="24" cy="22" rx="24" ry="20" fill="#ffcf8a" opacity="0.4" filter="url(#m11b8)">${an('fill', CYC, 48, -i * 3)}</ellipse>`)).join('');
        s += box3(C, { c: [0, 26, 0.9], w: 92, h: 2.4, d: 1.8, col: BR, r: 0.8, gl: 0.2, dec: { f: '<rect width="92" height="0.5" fill="#fff0b8" opacity="0.9"/>' } }) + [-44, 44].map(x => H.sph(C, [x, 27.2, 1.4], 1.6, BR)).join('');
        const items = OR.map(([x, y, r, ar], i) => { const hy = y + r + 6, top = [x, 27, 1.8], hook = [x, 28, ar];
          let g = line3(C, [top, [x, 31, 4], [x, 32, ar * 0.6], [x, 30.4, ar], hook], 1.1, '#7a5418') + line3(C, [top, [x, 31, 4], [x, 32, ar * 0.6], [x, 30.4, ar], hook], 0.7, BR);
          let o = line3(C, [hook, [x, hy + 2.6, ar]], 0.3, '#b88a32', `stroke-dasharray="${f1(0.4 * C.k)} ${f1(0.25 * C.k)}"`) + cyl3(C, [x, hy, ar], [x, hy + 2.6, ar], 2.2, BR, { mat: 'gloss', n: 16, r2: 1 });
          const c = C.P([x, y, ar]), rr = r * C.k, cid = `${id}o${i}`;
          let j = `<circle r="${f1(rr)}" fill="url(#${id}w)"/><circle r="${f1(rr)}" fill="#ffcf8a" opacity="0.72">${an('fill', CYC, 48, -i * 3)}</circle><circle r="${f1(rr * 0.8)}" fill="url(#${id}j)" opacity="0.35"/>`;
          j += rep(14, k => { const a = R() * 2 * PI, d = R() * rr * 0.85; return `<circle cx="${f1(Math.cos(a) * d)}" cy="${f1(Math.sin(a) * d)}" r="${f1((0.12 + R() * 0.15) * C.k)}" fill="#fffef0">${an('opacity', '0.2;1;0.2', 2 + (k % 4), -k * 0.5)}</circle>`; }).join('');
          const bw = rr * 0.48, bell = `M${f1(-bw)} 0C${f1(-bw)} ${f1(-bw * 1.1)} ${f1(bw)} ${f1(-bw * 1.1)} ${f1(bw)} 0Q${f1(bw * 0.5)} ${f1(bw * 0.18)} 0 ${f1(bw * 0.08)}Q${f1(-bw * 0.5)} ${f1(bw * 0.18)} ${f1(-bw)} 0Z`;
          const tent = rep(5, k => { const tx = -bw * 0.7 + k * bw * 0.35; return `<path d="M${f1(tx)} ${f1(bw * 0.1)}q${f1(bw * 0.25)} ${f1(bw * 0.5)} 0 ${f1(bw * 0.9)}t0 ${f1(bw * 0.8)}" stroke="#fff4f8" stroke-width="${f1(0.18 * C.k)}" fill="none" opacity="0.7"><animate attributeName="d" values="M${f1(tx)} ${f1(bw * 0.1)}q${f1(bw * 0.25)} ${f1(bw * 0.5)} 0 ${f1(bw * 0.9)}t0 ${f1(bw * 0.8)};M${f1(tx)} ${f1(bw * 0.1)}q${f1(-bw * 0.25)} ${f1(bw * 0.5)} 0 ${f1(bw * 0.9)}t0 ${f1(bw * 0.8)};M${f1(tx)} ${f1(bw * 0.1)}q${f1(bw * 0.25)} ${f1(bw * 0.5)} 0 ${f1(bw * 0.9)}t0 ${f1(bw * 0.8)}" dur="${n4(2.6 + i * 0.3)}s" repeatCount="indefinite"/></path>`; }).join('');
          j += `<g>${at('translate', `${f1(-rr * 0.12)} ${f1(rr * 0.15)};${f1(rr * 0.1)} ${f1(-rr * 0.2)};${f1(-rr * 0.12)} ${f1(rr * 0.15)}`, 9 + i * 2, -i * 2, SPL(2))}<g>${at('scale', '1 1;1.08 0.84;1 1', 1.3 + i * 0.15, -i * 0.4, SPL(2))}<circle cy="${f1(-bw * 0.3)}" r="${f1(bw * 1.3)}" fill="url(#${id}j)"/><path d="${bell}" fill="#fff6fa" opacity="0.8"/><path d="${bell}" fill="none" stroke="#ffffff" stroke-width="${f1(0.2 * C.k)}" opacity="0.9"/>`
            + rep(4, k => `<circle cx="${f1((k - 1.5) * bw * 0.32)}" cy="${f1(-bw * 0.45)}" r="${f1(bw * 0.13)}" fill="none" stroke="#ffd8e8" stroke-width="${f1(0.18 * C.k)}"/>`).join('') + `</g>${tent}</g>`;
          o += `<g transform="translate(${f1(c[0])} ${f1(c[1])})"><clipPath id="${cid}"><circle r="${f1(rr)}"/></clipPath><g clip-path="url(#${cid})">${j}</g><circle r="${f1(rr)}" fill="url(#${id}e)"/><circle r="${f1(rr)}" fill="none" stroke="#f4ecdc" stroke-width="${f1(0.35 * C.k)}" opacity="0.8"/><ellipse cx="${f1(-rr * 0.38)}" cy="${f1(-rr * 0.45)}" rx="${f1(rr * 0.28)}" ry="${f1(rr * 0.14)}" fill="#ffffff" opacity="0.75" transform="rotate(-35 ${f1(-rr * 0.38)} ${f1(-rr * 0.45)})"/><path d="M${f1(rr * 0.55)} ${f1(rr * 0.4)}A${f1(rr * 0.75)} ${f1(rr * 0.75)} 0 0 1 ${f1(rr * 0.1)} ${f1(rr * 0.72)}" stroke="#ffffff" stroke-width="${f1(0.4 * C.k)}" fill="none" opacity="0.5"/></g>`;
          g += swayAt(C, hook, 1.6, 6 + i * 0.8, i * 1.4, o);
          return { q: [x, y, ar], s: g }; });
        s += vsort(C, items);
        return { defs: DEF19 + `<defs><radialGradient id="${id}w" cx="50%" cy="45%" r="60%"><stop offset="0" stop-color="#b4c6da"/><stop offset="0.6" stop-color="#6a86a8"/><stop offset="1" stop-color="#2e4664"/></radialGradient><radialGradient id="${id}j"><stop offset="0" stop-color="#ffffff" stop-opacity="0.55"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient><radialGradient id="${id}e" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.15"/><stop offset="0.75" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#e8dcc8" stop-opacity="0.35"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };
  }

  // ======================= MIRRORS (BTH-010/030/050/070/090): wall pieces, mirror art as box3 face decals / cyl3 cap / WD planes =======================
  { const { box3, cyl3 } = RD.H15, { WD } = RD.H12, { ext } = RD.H11, DEF19 = RD.H19.DEF19;
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const line3 = (C, P, w, col, ex) => '<path d="M' + P.map(p => PP(C, p)).join('L') + '" stroke="' + col + '" stroke-width="' + f1(w * C.k) + '" fill="none" stroke-linecap="round" stroke-linejoin="round"' + (ex ? ' ' + ex : '') + '/>';
    const shW = (C, x, y, w, h, rx, op) => WD(C, x + 1.4, y - 2.2, 0.05, `<rect width="${f1(w)}" height="${f1(h)}" rx="${rx || 1}" fill="#000000" opacity="${op || 0.3}" filter="url(#m10b3)"/>`);
    const SANS = 'Arial,Helvetica,sans-serif', SERIF = "Georgia,'Times New Roman',serif";
    // soft reflection of the room: tinted gradient, the vanity light bloom, faint far-wall tiles, floor line and diagonal sheen; in a W x H box
    const refl = (id, W, H, o) => { o = o || {}; const R = rng(id);
      return `<rect width="${W}" height="${H}" fill="url(#${id}r)"/><g filter="url(#m12b1)" opacity="${o.op || 0.5}">` + rep(Math.round(W / 4), i => `<path d="M${f1(i * 4 + 2)} ${f1(H * 0.12)}V${f1(H * 0.78)}" stroke="${o.tile || '#ffffff'}" stroke-width="0.25" opacity="0.5"/>`).join('')
        + `<rect y="${f1(H * 0.78)}" width="${W}" height="${f1(H * 0.22)}" fill="${o.floor || '#8a8070'}" opacity="0.35"/><ellipse cx="${f1(W * 0.5)}" cy="${f1(H * 0.05)}" rx="${f1(W * 0.35)}" ry="${f1(H * 0.12)}" fill="${o.bloom || '#fff6e0'}" opacity="0.8"/></g>`
        + `<path d="M${f1(W * 0.12)} 0H${f1(W * 0.3)}L${f1(W * 0.08)} ${H}H0V${f1(H * 0.5)}Z" fill="#ffffff" opacity="0.14"/><path d="M${f1(W * 0.38)} 0H${f1(W * 0.44)}L${f1(W * 0.22)} ${H}H${f1(W * 0.16)}Z" fill="#ffffff" opacity="0.1"/>`; };
    const rDef = (id, a, b) => `<linearGradient id="${id}r" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>`;

    // BTH-010 UNFRAMED MIRROR WITH DESILVERED CORNERS (T1): a plain rectangle of mirror glass with a ground edge, held by four plastic clips (one snapped and
    // replaced by a bent nail); black-brown desilvering creeping in from the corners and bottom edge, a crack across one corner, scratches, toothpaste flecks
    // and a sticker scrap. Live: steam fogs the bottom of the glass and slowly clears.
    N.mirr29a = S => { const D = { w: 52, d: 4, mount: 'wall', elev: 50, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('mirr29a'), id = C.u('b10'), MW = 34, MH = 26;
        ext(C, [[-22, 32, 0], [22, -4, 0], [22, -4, 3]]);
        const sil = (cx, cy, n, sz) => rep(n, () => { const a = R() * 2 * PI, d = Math.pow(R(), 1.6) * sz, x = cx + Math.cos(a) * d, y = cy + Math.sin(a) * d * 0.8, r = 0.25 + R() * (1 - d / sz) * 1.6; return `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(r)}" fill="${R() < 0.6 ? '#1e1a14' : '#5a4628'}" opacity="${f1(0.4 + R() * 0.5)}"/>`; }).join('');
        let m = refl(id, MW, MH, { floor: '#7a7466', tile: '#e8ecea' }) + `<rect width="${MW}" height="${MH}" fill="#b8c2b8" opacity="0.18"/>`;
        m += `<g filter="url(#m12b1)">${sil(0, 0, 40, 10)}${sil(MW, MH, 46, 11)}${sil(0, MH, 30, 7)}</g>` + sil(0, 0, 60, 9) + sil(MW, MH, 70, 10) + sil(0, MH, 36, 6) + sil(MW, 0, 18, 4.4) + rep(24, () => `<circle cx="${f1(R() * MW)}" cy="${f1(MH - R() * 1.6)}" r="${f1(0.2 + R() * 0.4)}" fill="#2a2418" opacity="0.6"/>`).join('');
        m += `<path d="M${MW - 9} 0L${MW - 6.4} 3.2L${MW - 7} 5L${MW} 8.6" stroke="#ffffff" stroke-width="0.25" fill="none" opacity="0.9"/><path d="M${MW - 8.8} 0.1L${MW - 6.2} 3.3L${MW - 6.8} 5.1L${MW} 8.8" stroke="#3a3a34" stroke-width="0.12" fill="none" opacity="0.7"/>`
          + rep(10, () => { const x = R() * MW, y = R() * MH; return `<path d="M${f1(x)} ${f1(y)}l${f1((R() - 0.5) * 6)} ${f1((R() - 0.5) * 2)}" stroke="#ffffff" stroke-width="0.1" opacity="0.6"/>`; }).join('')
          + rep(22, () => `<circle cx="${f1(8 + R() * 18)}" cy="${f1(MH - 6 - R() * 9)}" r="${f1(0.12 + R() * 0.25)}" fill="#f4f8f6" opacity="0.9"/>`).join('')
          + `<rect x="3" y="3" width="3.6" height="2.4" rx="0.3" fill="#f0e8c8" opacity="0.8" transform="rotate(-8 4.8 4.2)"/><path d="M3.4 3.6l2.6 0.8" stroke="#c84a3a" stroke-width="0.3" opacity="0.6"/>`
          + `<rect y="${f1(MH * 0.55)}" width="${MW}" height="${f1(MH * 0.45)}" fill="url(#${id}f)" opacity="0">${an('opacity', '0;0.9;0.9;0', 14, 0, KT('0;0.25;0.5;1'))}</rect>`
          + `<rect width="${MW}" height="${MH}" fill="none" stroke="#c8d4d0" stroke-width="0.5"/>`;
        let s = shW(C, -MW / 2, MH + 2, MW, MH, 0.5, 0.25) + box3(C, { c: [0, 2, 0.4], w: MW, h: MH, d: 0.8, col: '#a8b8b2', r: 0.1, dec: { f: `<clipPath id="${id}k"><rect width="${MW}" height="${MH}"/></clipPath><g clip-path="url(#${id}k)">${m}</g>` } });
        [[-MW / 2 + 5, MH + 2.4], [MW / 2 - 5, MH + 2.4], [-MW / 2 + 5, 1.6]].forEach(([x, y]) => s += box3(C, { c: [x, y - 1.6, 0.9], w: 3.2, h: 2, d: 1.8, col: '#ecebe4', r: 0.4 }));
        s += cyl3(C, [MW / 2 - 5, 1.2, 0], [MW / 2 - 5, 1.2, 1.2], 0.25, '#8a8070', { n: 8 }) + line3(C, [[MW / 2 - 5, 1.2, 1.2], [MW / 2 - 5, 2.4, 1.6]], 0.45, '#7a7060');
        return { defs: DEF19 + `<defs>${rDef(id, '#dfe4dc', '#9aa49a')}<linearGradient id="${id}f" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#eef2f0" stop-opacity="0.95"/><stop offset="1" stop-color="#eef2f0" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BTH-030 MEDICINE CABINET MIRROR WITH CHROME TRIM (T2): a white steel medicine cabinet with a bright chrome trim frame round the mirrored door, a chrome
    // finger pull, a hint of the shelves through the gap at the hinge side, a 'dentist Tue 4pm' sticky note and a kid's gold star sticker. Live: a glint slides
    // across the mirror.
    N.mirr29b = S => { const D = { w: 50, d: 8, mount: 'wall', elev: 46, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('b30'), MW = 36, MH = 30, DZ = 5.6;
        ext(C, [[-20, 33, 0], [20, -2, 0], [20, -2, 7]]);
        let m = refl(id, MW - 3, MH - 3, { floor: '#7a8a84', tile: '#a6d8c2', bloom: '#fff8e8' }) + `<rect x="-40" width="10" height="${MH - 3}" fill="url(#${id}g)" transform="skewX(-18)">${an('x', `-40;${MW + 20};${MW + 20}`, 11, 0, ' keyTimes="0;0.5;1"')}</rect>`;
        const face = `<rect width="${MW}" height="${MH}" fill="url(#${id}c)"/><rect x="0.5" y="0.5" width="${MW - 1}" height="${MH - 1}" fill="none" stroke="#ffffff" stroke-width="0.35"/><rect x="1.5" y="1.5" width="${MW - 3}" height="${MH - 3}" fill="#5a6064"/><clipPath id="${id}k"><rect x="1.5" y="1.5" width="${MW - 3}" height="${MH - 3}"/></clipPath><g clip-path="url(#${id}k)" transform="translate(1.5 1.5)">${m}</g>`
          + `<rect x="1.5" y="1.5" width="${MW - 3}" height="0.4" fill="#ffffff" opacity="0.6"/><rect x="${MW - 7}" y="3.4" width="5" height="5" fill="#fff07a" transform="rotate(5 ${MW - 4.5} 6)"/><text x="${MW - 4.6}" y="5.8" text-anchor="middle" font-family="'Comic Sans MS',cursive" font-size="0.95" fill="#3a3a7a" transform="rotate(5 ${MW - 4.5} 6)">dentist</text><text x="${MW - 4.6}" y="7.2" text-anchor="middle" font-family="'Comic Sans MS',cursive" font-size="0.95" fill="#3a3a7a" transform="rotate(5 ${MW - 4.5} 6)">Tue 4pm</text>`
          + `<path d="M5 ${MH - 6}l0.7 1.5l1.6 0.2l-1.2 1.1l0.3 1.6l-1.4 -0.8l-1.4 0.8l0.3 -1.6l-1.2 -1.1l1.6 -0.2Z" fill="#f2c040" stroke="#c89020" stroke-width="0.12"/>`;
        let s = shW(C, -MW / 2 - 1, MH + 3, MW + 2, MH + 2, 0.8, 0.3) + box3(C, { c: [0, -0.6, DZ / 2 - 0.4], w: MW + 1.6, h: MH + 1.6, d: DZ - 0.8, col: '#f4f4f0', r: 0.4, dec: { l: '<rect width="20" height="40" fill="#e4e6e2"/>' } });
        s += box3(C, { c: [0, 0.2, DZ - 0.3], w: MW, h: MH, d: 0.9, col: '#d8dee4', r: 0.3, gl: 0.2, dec: { f: face } });
        s += box3(C, { c: [MW / 2 - 1.2, MH / 2 - 3, DZ + 0.5], w: 1.2, h: 6, d: 0.9, col: '#d4dae0', r: 0.5, gl: 0.2 });
        return { defs: DEF19 + `<defs>${rDef(id, '#f2f4f0', '#b8c8c0')}<linearGradient id="${id}c" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="0.3" stop-color="#b8c0c8"/><stop offset="0.55" stop-color="#eef2f6"/><stop offset="1" stop-color="#8a9298"/></linearGradient><linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.45"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BTH-050 ROUND BACKLIT ANTI-FOG LED VANITY MIRROR (T3): a big frameless round mirror floating off the wall on a warm halo of backlight, a frosted LED ring
    // inside its edge, a touch button with a defog icon glowing at the bottom. Live: steam mist creeps in from the rim and the anti-fog clears it from the middle out.
    N.mirr29c = S => { const D = { w: 56, d: 6, mount: 'wall', elev: 44, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('b50'), RR = 20, CY = 20;
        ext(C, [[-26, 46, 0], [26, -6, 0], [26, -6, 4]]);
        let s = WD(C, -RR - 8, CY + RR + 8, 0.04, `<circle cx="${RR + 8}" cy="${RR + 8}" r="${RR + 3}" fill="#ffe8c0" opacity="0.6" filter="url(#m11b8)">${an('opacity', '0.5;0.7;0.5', 8, 0, SPL(2))}</circle>`);
        const cap = cr => { const k = cr / RR; return `<g transform="scale(${n4(k)})"><clipPath id="${id}k"><circle r="${RR}"/></clipPath><circle r="${RR}" fill="url(#${id}r)"/><g clip-path="url(#${id}k)"><g transform="translate(${-RR} ${-RR})">${refl(id + 'x', RR * 2, RR * 2, { floor: '#6a5a4a', tile: '#9aa4b0', bloom: '#fff2d8' })}</g></g>`
          + `<circle r="${RR}" fill="url(#${id}m)" opacity="0">${an('opacity', '0;0.95;0.95;0', 12, 0, KT('0;0.3;0.45;0.8'))}</circle><circle r="${RR - 1.4}" fill="none" stroke="#fff4dc" stroke-width="1.6" opacity="0.85" filter="url(#m12b1)"/><circle r="${RR - 1.4}" fill="none" stroke="#fffaf0" stroke-width="0.5"/>`
          + `<g transform="translate(0 ${RR - 4.4})"><circle r="1.5" fill="#ffffff" opacity="0.15"/><path d="M-0.9 0.4q0.45 -0.6 0.9 0t0.9 0M-0.9 -0.4q0.45 -0.6 0.9 0t0.9 0" stroke="#fff4dc" stroke-width="0.22" fill="none"><animate attributeName="opacity" values="0.6;1;0.6" dur="3s" repeatCount="indefinite"/></path></g><circle r="${RR}" fill="none" stroke="#e8eef0" stroke-width="0.4"/></g>`; };
        s += cyl3(C, [0, CY, 0.4], [0, CY, 2.2], RR, '#b8c4c8', { n: 40, cap, capCol: '#c8d4d8' });
        return { defs: DEF19 + `<defs>${rDef(id + 'x', '#f2ece2', '#a8a090')}<radialGradient id="${id}r"><stop offset="0" stop-color="#e8e4dc"/><stop offset="1" stop-color="#b8b4a8"/></radialGradient><radialGradient id="${id}m"><stop offset="0.35" stop-color="#f4f6f6" stop-opacity="0"/><stop offset="0.75" stop-color="#f4f6f6" stop-opacity="0.75"/><stop offset="1" stop-color="#f4f6f6" stop-opacity="0.95"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BTH-070 ARCHWAY BRASS SMART MIRROR WITH WEATHER & CLOCK (T4): a tall arch mirror in a slim polished brass frame with a fine beaded inner edge, on a little
    // brass ledge with a perfume bottle and a tiny trailing plant; through the glass a soft champagne display shows a clock with a sweeping second hand, the
    // date and the weather (sun and cloud, 24°). Live: the second hand sweeps and the sun's rays slowly turn.
    N.mirr29d = S => { const D = { w: 52, d: 8, mount: 'wall', elev: 40, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), R = rng('mirr29d'), id = C.u('b70'), AW = 32, AH = 46, BR = '#c99a3e', NOW = new Date(), HA = ((NOW.getHours() % 12) + NOW.getMinutes() / 60) * 30, MA = NOW.getMinutes() * 6, DS = NOW.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
        ext(C, [[-22, 50, 0], [22, -4, 0], [22, -4, 7]]);
        const arch = (w, h, o) => `M${o} ${h + o}V${w / 2 + o}A${w / 2 - o} ${w / 2 - o} 0 0 1 ${w - o} ${w / 2 + o}V${h + o}Z`;
        let g = `<path d="${arch(AW, AH, 0)}" fill="url(#${id}b)"/><path d="${arch(AW, AH, 0)}" fill="none" stroke="#7a5418" stroke-width="0.3"/>` + `<clipPath id="${id}k"><path d="${arch(AW, AH - 1.6, 1.6)}"/></clipPath><g clip-path="url(#${id}k)">${refl(id, AW, AH, { floor: '#8a6a4a', tile: '#f2d8b8', bloom: '#fff2d0' })}`
          + `<g transform="translate(${AW / 2} 13)" opacity="0.85"><circle r="5.2" fill="none" stroke="#f6e2b0" stroke-width="0.18" opacity="0.7"/>${rep(12, i => { const a = i / 12 * 2 * PI; return `<path d="M${f1(Math.sin(a) * 4.5)} ${f1(-Math.cos(a) * 4.5)}L${f1(Math.sin(a) * 4.9)} ${f1(-Math.cos(a) * 4.9)}" stroke="#f6e2b0" stroke-width="${i % 3 ? 0.12 : 0.28}"/>`; }).join('')}`
          + `<path d="M0 0L0 -3" stroke="#fff4d8" stroke-width="0.35" stroke-linecap="round" transform="rotate(${f1(HA)})"/><path d="M0 0L0 -4.2" stroke="#fff4d8" stroke-width="0.25" stroke-linecap="round" transform="rotate(${f1(MA)})"/><g>${at('rotate', '0;360', 60)}<path d="M0 0.8L0 -4.6" stroke="#f0c46a" stroke-width="0.12"/></g><circle r="0.35" fill="#f0c46a"/></g>`
          + `<text x="${AW / 2}" y="22.6" text-anchor="middle" font-family="${SERIF}" font-style="italic" font-size="1.5" fill="#f6e4b8" opacity="0.85">${DS}</text>`
          + `<g transform="translate(${AW / 2 - 4} 27.4)" opacity="0.9"><g>${at('rotate', '0;360', 30)}${rep(8, i => `<path d="M0 -2.2V-3" stroke="#f6c860" stroke-width="0.3" stroke-linecap="round" transform="rotate(${i * 45})"/>`).join('')}</g><circle r="1.6" fill="#f6c860"/><path d="M0.4 1.8a1.4 1.4 0 0 1 1.4 -1.6a2 2 0 0 1 3.6 0.6a1.2 1.2 0 0 1 -0.2 2.4H1.4a1.2 1.2 0 0 1 -1 -1.4Z" fill="#f8f2e6"/><text x="7.4" y="1.4" font-family="${SANS}" font-size="2.4" fill="#f6e4b8">24°</text></g>`
          + `<rect x="-30" width="8" height="${AH}" fill="#ffffff" opacity="0.12" transform="skewX(-14)">${an('x', `-30;${AW + 16};${AW + 16}`, 13, 0, ' keyTimes="0;0.5;1"')}</rect></g>`
          + `<path d="${arch(AW, AH - 1.6, 1.6)}" fill="none" stroke="#fff0b8" stroke-width="0.25"/><path d="${arch(AW, AH - 2.4, 2.4)}" fill="none" stroke="#e2b456" stroke-width="0.35" stroke-dasharray="0.3 0.35"/>`;
        let s = WD(C, -AW / 2 + 1.4, AH - 2.2, 0.03, `<path d="${arch(AW, AH, 0)}" fill="#000000" opacity="0.32" filter="url(#m10b3)"/>`) + WD(C, -AW / 2, AH, 0.9, g);
        s += box3(C, { c: [0, -3, 2.6], w: 28, h: 1.6, d: 5.2, col: BR, r: 0.3, gl: 0.2, dec: { f: '<rect width="28" height="0.4" fill="#fff0b8"/>' } });
        s += cyl3(C, [-7, -1.4, 3], [-7, 3.6, 3], 1.6, '#f2d8e0', { mat: 'gloss', n: 16, op: 0.85 }) + cyl3(C, [-7, 3.6, 3], [-7, 5.2, 3], 0.9, BR, { mat: 'gloss', n: 12 }) + H.sph(C, [-7, 5.9, 3], 0.8, '#e8e4dc');
        s += cyl3(C, [7, -1.4, 3], [7, 1.6, 3], 1.7, '#f4f0e8', { n: 16 }) + rep(7, i => { const a = -1 + i * 0.35, l = 2 + R() * 4; return line3(C, [[7, 1.6, 3], [7 + Math.sin(a) * 2, 1.2 - (i % 3), 3.6], [7 + Math.sin(a) * 3, 1.6 - l, 4]], 0.25, '#4a7a3a') + H.sph(C, [7 + Math.sin(a) * 3, 1.6 - l, 4], 0.6, '#6aa24a'); }).join('');
        return { defs: DEF19 + `<defs>${rDef(id, '#ece2d0', '#8a7a62')}<linearGradient id="${id}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0b0"/><stop offset="0.35" stop-color="#e2b456"/><stop offset="0.7" stop-color="#b38432"/><stop offset="1" stop-color="#f2d488"/></linearGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };

    // BTH-090 AI SKIN-DIAGNOSTIC & HOLOGRAPHIC STYLING VANITY MIRROR (T5): a large rounded-rectangle mirror in a champagne-gold frame studded with glowing
    // globe bulbs; in the glass a soft rose-gold hologram scans a cute creature face (a light line sweeps down a dotted face outline), shows little readings
    // (hydration, glow, a sunscreen reminder) and floats a styling preview that cycles through a bow, a tiara and a flower crown over the head.
    // Live: the scan sweeps, the bulbs breathe and the styles change.
    N.mirr29e = S => { const D = { w: 64, d: 8, mount: 'wall', elev: 40, build: () => [] };
      D.fx = ctx => { const C = cam(ctx), id = C.u('b90'), FW = 50, FH = 44, M = 4.6, HC = '#ffd2c8';
        ext(C, [[-28, 48, 0], [28, -4, 0], [28, -4, 6]]);
        let s = WD(C, -FW / 2 - 6, FH + 4, 0.03, `<rect width="${FW + 12}" height="${FH + 12}" rx="10" fill="#ffe0c0" opacity="0.4" filter="url(#m11b8)">${an('opacity', '0.3;0.5;0.3', 7, 0, SPL(2))}</rect>`);
        const VW = FW - 2 * M, VH = FH - 2 * M, cx = VW / 2, cy = VH * 0.46;
        let v = refl(id, VW, VH, { floor: '#7a5a52', tile: '#f2d0c0', bloom: '#fff2e0', op: 0.4 });
        v += `<g opacity="0.9"><ellipse cx="${cx}" cy="${cy}" rx="9" ry="8" fill="none" stroke="${HC}" stroke-width="0.25" stroke-dasharray="0.3 0.5"/><ellipse cx="${cx}" cy="${cy}" rx="9" ry="8" fill="${HC}" opacity="0.06"/>`
          + [[-3.2, -0.6], [3.2, -0.6]].map(([dx, dy]) => `<ellipse cx="${cx + dx}" cy="${cy + dy}" rx="1.2" ry="1.5" fill="none" stroke="${HC}" stroke-width="0.25"/>`).join('') + `<path d="M${cx - 1.4} ${cy + 3}q1.4 1.2 2.8 0" stroke="${HC}" stroke-width="0.25" fill="none"/><ellipse cx="${cx - 5}" cy="${cy + 2.2}" rx="1.2" ry="0.6" fill="#ff9ab0" opacity="0.4"/><ellipse cx="${cx + 5}" cy="${cy + 2.2}" rx="1.2" ry="0.6" fill="#ff9ab0" opacity="0.4"/>`
          + rep(18, i => { const a = i / 18 * 2 * PI; return `<circle cx="${f1(cx + Math.cos(a) * 9)}" cy="${f1(cy + Math.sin(a) * 8)}" r="0.22" fill="#fff0e8"/>`; }).join('')
          + `<rect x="${cx - 11}" y="${cy - 9}" width="22" height="0.5" fill="#ffe8e0"><animate attributeName="y" values="${cy - 9};${cy + 9};${cy - 9}" dur="4s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.9;0.4;0.9" dur="4s" repeatCount="indefinite"/></rect>`
          + [[cx - 14, cy - 10], [cx + 14, cy - 10], [cx - 14, cy + 10], [cx + 14, cy + 10]].map(([x, y], i) => `<path d="M${x} ${y}h${i % 2 ? -2 : 2}M${x} ${y}v${i < 2 ? 2 : -2}" stroke="${HC}" stroke-width="0.3"/>`).join('') + '</g>';
        const chip = (x, y, t, val, k) => `<g transform="translate(${x} ${y})" opacity="0">${an('opacity', '0;0.95;0.95;0', 9, -k * 1.2, KT('0;0.12;0.85;1'))}<rect width="9.6" height="3.2" rx="1.6" fill="#ffffff" opacity="0.14" stroke="${HC}" stroke-width="0.15"/><text x="1" y="1.4" font-family="${SANS}" font-size="0.9" fill="#fff0e8">${t}</text><text x="1" y="2.6" font-family="${SANS}" font-weight="700" font-size="1" fill="#ffd8a8">${val}</text></g>`;
        v += chip(1.4, 2.4, 'HYDRATION', '92%', 0) + chip(1.4, 6.4, 'GLOW', 'radiant ✓', 1) + chip(VW - 11, 2.4, 'SPF', 'reapply 2pm', 2);
        const sty = [`<path d="M-3 0Q-4.6 -1.8 -3.6 -2.6Q-2 -2 -0.6 -0.4Q-2 1.4 -3.6 1.6Q-4.6 1 -3 0ZM3 0Q4.6 -1.8 3.6 -2.6Q2 -2 0.6 -0.4Q2 1.4 3.6 1.6Q4.6 1 3 0Z" fill="#ff9ab8" stroke="#fff0f4" stroke-width="0.15"/><circle r="0.9" fill="#ff7aa0"/>`,
          `<path d="M-4 1L-3.2 -1.6L-1.6 0L0 -3L1.6 0L3.2 -1.6L4 1Z" fill="#ffe08a" stroke="#fff6d8" stroke-width="0.15"/><circle cy="-2.2" r="0.5" fill="#ff9ab8"/><circle cx="-3" cy="-1" r="0.35" fill="#a8e0ff"/><circle cx="3" cy="-1" r="0.35" fill="#a8e0ff"/>`,
          rep(7, i => { const x = -4.2 + i * 1.4, c = ['#ffb8c8', '#fff0a0', '#c8b8ff'][i % 3]; return `<circle cx="${f1(x)}" cy="${f1(Math.abs(i - 3) * 0.3)}" r="0.7" fill="${c}"/><circle cx="${f1(x)}" cy="${f1(Math.abs(i - 3) * 0.3)}" r="0.25" fill="#ffe08a"/>`; }).join('') + '<path d="M-4.6 0.6Q0 2 4.6 0.6" stroke="#8ac87a" stroke-width="0.3" fill="none"/>'];
        v += sty.map((g, i) => `<g transform="translate(${cx} ${cy - 9.6})" opacity="${i ? 0 : 1}">${an('opacity', ['1;1;0;0;0;0;1', '0;0;1;1;0;0;0', '0;0;0;0;1;1;0'][i], 15, 0, KT('0;0.3;0.333;0.633;0.667;0.967;1'))}${g}</g>`).join('')
          + `<text x="${cx}" y="${VH - 2.4}" text-anchor="middle" font-family="${SERIF}" font-style="italic" font-size="1.3" fill="#ffe8dc" opacity="0.85">styling preview · 3 looks</text>`;
        v += `<rect x="-30" width="10" height="${VH}" fill="#ffffff" opacity="0.1" transform="skewX(-16)">${an('x', `-30;${VW + 20};${VW + 20}`, 12, 0, ' keyTimes="0;0.5;1"')}</rect>`;
        let face = `<rect width="${FW}" height="${FH}" rx="6" fill="url(#${id}b)"/><rect x="0.4" y="0.4" width="${FW - 0.8}" height="${FH - 0.8}" rx="5.6" fill="none" stroke="#fff4d0" stroke-width="0.3"/><rect x="${M - 0.4}" y="${M - 0.4}" width="${VW + 0.8}" height="${VH + 0.8}" rx="3.6" fill="#8a6a3a"/>`
          + `<clipPath id="${id}k"><rect x="${M}" y="${M}" width="${VW}" height="${VH}" rx="3.2"/></clipPath><g clip-path="url(#${id}k)"><g transform="translate(${M} ${M})">${v}</g></g>`;
        const bulbs = []; for (let i = 0; i < 6; i++) { const x = M + 1 + i * (VW - 2) / 5; bulbs.push([x, M / 2], [x, FH - M / 2]); } for (let j = 1; j < 4; j++) { const y = M + j * VH / 4; bulbs.push([M / 2, y], [FW - M / 2, y]); }
        face += bulbs.map(([x, y], i) => `<circle cx="${f1(x)}" cy="${f1(y)}" r="2.6" fill="#fff4d8" opacity="0.4" filter="url(#m12b1)">${an('opacity', '0.3;0.6;0.3', 5, -i * 0.3, SPL(2))}</circle><circle cx="${f1(x)}" cy="${f1(y)}" r="1.5" fill="url(#${id}g)" stroke="#c8a060" stroke-width="0.2"/><circle cx="${f1(x - 0.4)}" cy="${f1(y - 0.45)}" r="0.4" fill="#ffffff"/>`).join('');
        s += shW(C, -FW / 2, FH, FW, FH, 6, 0.35) + box3(C, { c: [0, 0, 1.4], w: FW, h: FH, d: 2.8, col: '#d8b878', r: 0.6, dec: { f: face } });
        return { defs: DEF19 + `<defs>${rDef(id, '#f6e6dc', '#9a7a6a')}<linearGradient id="${id}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fbe8c0"/><stop offset="0.35" stop-color="#e2c088"/><stop offset="0.7" stop-color="#c8a060"/><stop offset="1" stop-color="#f0d8a0"/></linearGradient><radialGradient id="${id}g" cx="40%" cy="35%" r="65%"><stop offset="0" stop-color="#ffffff"/><stop offset="0.6" stop-color="#fff2d0"/><stop offset="1" stop-color="#f0d098"/></radialGradient></defs>`, front: s, bb: C.bb(3) }; };
      return D; };
  }

  // ======================= TOILETS (Lavatory Throne BTH-002/022/042/062/082): real solids (X.K, solid-sorted, nf = 0 every 5 deg) + fx for decals and motion =======================
  // footprint kept 56 x 70 (z -35 back .. 35 front); no seats on the old rows, none added. Bowl centre z 8, rim y 37, seat top 39.6.
  { const K = () => X.K, glue = o => (p, L) => L.map(k => { k.par = p; o.push(k); return k; });
    const { shadow, vis } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const line3 = (C, P, w, col, ex) => '<path d="M' + P.map(p => PP(C, p)).join('L') + '" stroke="' + col + '" stroke-width="' + f1(w * C.k) + '" fill="none" stroke-linecap="round" stroke-linejoin="round"' + (ex ? ' ' + ex : '') + '/>';
    const sol = o => X.K.solid(o);
    // porcelain pedestal + bowl (+ seat ring + water/opening) for the floor-standing toilets
    const pedBowl = (o, c, seat, water, op) => { op = op || {}; const S = sol, CZ = 8;
      o.push(S({ ax: 'y', sh: 'el', c: [0, 5], a: 10.5, b: 13.5, n: 20, rings: [[0, 0, 1.22], [1.6, 0, 1.14], [5, 0, 0.92], [16, 0, 0.84], [22, 0, 0.96]], col: c, mat: 'cer' }));
      const B = S({ ax: 'y', sh: 'el', c: [0, CZ], a: 19, b: 24, n: 28, rings: [[22, 0, 0.56], [26, 0, 0.78], [31, 0, 0.93], [35.4, 0, 0.995], [37, 0, 1]], col: c, mat: 'cer' }); o.push(B);
      const SE = S({ ax: 'y', sh: 'el', c: [0, CZ + 0.4], a: 19.4, b: 24.6, n: 28, rings: [[37, 0, 0.99], [38.8, 0, 1], [39.6, 0, 0.97]], col: seat, mat: op.seatMat || 'plastic' }); o.push(SE);
      const W = S({ ax: 'y', sh: 'el', c: [0, CZ + 1.8], a: 12.4, b: 16.6, n: 24, rings: [[39.6, 0, 1], [39.8, 0, 1]], col: water, noOut: 1, mat: 'gloss' }); o.push(W);
      return { B, SE, W }; };
    // raised lid standing against the tank / panel: an upright ellipse plate (bottom on the seat's rear edge)
    const lidUp = (z0, t, col, mat) => sol({ ax: 'z', sh: 'el', c: [0, 39.8 + 23.6], a: 18.6, b: 23.6, n: 26, rings: [[z0, 0, 0.98], [z0 + 0.4, 0, 1], [z0 + t, 0, 1]], col, mat });

    // BTH-002 WOBBLY PULL-CHAIN TANK TOILET (T1): a Victorian-style high cistern gone shabby: chipped white cast cistern on two rusty brackets high on the wall,
    // a long corroded flush pipe down to the bowl, a cracked wooden seat that sits askew, a stained bowl, a chipped foot, a rag stuffed round a leaking joint.
    // Live: the pull chain sways, the cistern drips into a little puddle and the whole toilet gives a wobble now and then.
    N.loo29a = S => { const WH = '#ece6d6', RU = '#8a6a4a', TZ = -27;
      const D = { w: 56, d: 70, arch: 'toilet', build: () => { const { box, cyl } = K(), o = [], on = glue(o);
          const { B, SE, W } = pedBowl(o, WH, '#b8864e', '#c8c49a', { seatMat: 'wood' });
          o.push(box(0, 110, TZ - 1, 40, 18, 14, '#e2dccb', { r: 3, bev: 1.6, mat: 'cer' }), box(0, 128, TZ - 1, 42, 2.4, 15, '#d6cfbc', { r: 3 }));
          [-14, 14].forEach(x => o.push(box(x, 104, -32, 3, 6, 6, '#5a4a3a', { r: 0.6, mat: 'metal' })));
          o.push(cyl(-12, 30, TZ, 2.2, 80, RU, { n: 12, mat: 'metal' }));
          o.push(sol({ ax: 'z', sh: 'el', c: [-12, 30], a: 2.2, b: 2.2, n: 12, rings: [[TZ, 0], [-11.5, 0]], col: RU, mat: 'metal' }));
          o.push(sol({ ax: 'z', sh: 'el', c: [-12, 30], a: 3.4, b: 3.4, n: 12, rings: [[-15, 0], [-12.2, 0]], col: '#9a8a70', mat: 'fab' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('loo29a'), id = C.u('t02'), k = C.k;
        const under = shadow(C, 0, 6, 22, 26, 0.45) + FL(C, 0.06, `<ellipse cx="-8" cy="-26" rx="7" ry="4.6" fill="#b8c4c4" opacity="0.55"/><ellipse cx="-8" cy="-26" rx="7" ry="4.6" fill="none" stroke="#8a9898" stroke-width="0.3" opacity="0.6"/><ellipse cx="-8" cy="-26" rx="1" ry="0.6" fill="none" stroke="#ffffff" stroke-width="0.25" opacity="0">${an('rx', '1;5', 4)}${an('ry', '0.6;3.2', 4)}${an('opacity', '0.8;0', 4)}</ellipse>`);
        // seat: cracks, worn varnish; bowl: stain ring (on the water plate)
        const top = FL(C, 39.84, `<ellipse cx="0" cy="9.8" rx="11" ry="14.8" fill="none" stroke="#a87a3a" stroke-width="1.6" opacity="0.45"/><ellipse cx="0" cy="12" rx="5" ry="6" fill="#d8c070" opacity="0.4"/>`)
          + FL(C, 39.66, `<path d="M-15 0Q-16.6 8 -13.6 17" stroke="#6a4424" stroke-width="0.5" fill="none" opacity="0.8"/><path d="M16 -4L17.6 1L16.4 3L18 8" stroke="#3a2414" stroke-width="0.4" fill="none"/><ellipse cx="9" cy="22" rx="4" ry="2" fill="#d8b888" opacity="0.5"/><ellipse cx="-11" cy="24" rx="3" ry="1.6" fill="#d8b888" opacity="0.4"/>`);
        const chip = vdot(C, [0, 0, 1]) > 0.1 ? PLN(C, [4, 1.2, 21.5], [1, 0, 0], [0, -1, 0], `<path d="M0 0l2.4 0.6l-0.6 1.4l-2 -0.4Z" fill="#a8a090"/>`) : '';
        // pull chain from the cistern lever + drip
        const CX = 15, CY0 = 110, CZ = TZ + 6;
        const ch = rep(30, i => [CX, CY0 - i * 1.1, CZ]);
        const chain = `<g>${at('rotate', `-3 ${PP(C, [CX, CY0, CZ])};4 ${PP(C, [CX, CY0, CZ])};-3 ${PP(C, [CX, CY0, CZ])}`, 3.6, 0, SPL(2))}<path d="M${ch.map(p => PP(C, p)).join('L')}" stroke="#7a6a52" stroke-width="${f1(0.5 * k)}" stroke-dasharray="${f1(0.35 * k)} ${f1(0.3 * k)}" fill="none"/>`
          + `<g transform="translate(${PP(C, [CX, CY0 - 34, CZ])})"><rect x="${f1(-1 * k)}" y="0" width="${f1(2 * k)}" height="${f1(5 * k)}" rx="${f1(0.8 * k)}" fill="#e8e0cc" stroke="#8a7a5a" stroke-width="${f1(0.3 * k)}"/><text y="${f1(3.3 * k)}" text-anchor="middle" font-family="Georgia,serif" font-size="${f1(1.3 * k)}" fill="#6a5a3a">PULL</text></g></g>`
          + line3(C, [[CX - 6, CY0 + 2, CZ], [CX, CY0, CZ]], 0.7, '#6a5a42');
        const dp = C.P([-8, 109.6, TZ - 1]), fl = C.P([-8, 0.1, -26]), K2 = ' keyTimes="0;0.7;0.9;0.91;1" dur="4s" repeatCount="indefinite"';
        const drip = `<ellipse cx="${f1(dp[0])}" cy="${f1(dp[1])}" rx="${f1(0.5 * k)}" ry="${f1(0.6 * k)}" fill="#c8dcdc"><animate attributeName="cy" values="${f1(dp[1])};${f1(dp[1] + 0.6 * k)};${f1(fl[1])};${f1(dp[1])};${f1(dp[1])}"${K2}/><animate attributeName="opacity" values="0.9;0.9;0.9;0;0.9"${K2}/></ellipse>`
          + `<path d="M${PP(C, [-8, 110, TZ + 6.1])}l0 ${f1(4 * k)}" stroke="#8a5a2a" stroke-width="${f1(1 * k)}" opacity="0.35"/>`;
        const fF = vdot(C, [0, 0, 1]) > -0.05;
        return { under, front: top + chip + (fF ? chain : '') + drip, back: fF ? '' : chain, bb: C.bb(4) }; };
      return D; };

    // BTH-022 STANDARD TWO-PIECE CERAMIC FLUSH TOILET (T2): clean glossy white close-coupled toilet: tank on its deck with a chrome lever, white seat with a
    // closed lid under a fluffy mint lid cover, a spare roll and a little succulent on the tank lid. Live: the plug-in air freshener on the tank puffs now and then.
    N.loo29b = S => { const WH = '#f6f4ef';
      const D = { w: 56, d: 70, arch: 'toilet', build: () => { const { box, cyl, pillowY } = K(), o = [], on = glue(o);
          const { SE, W } = pedBowl(o, WH, '#fbfaf6', '#bfe0ee');
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 8.4], a: 19.2, b: 24.4, n: 28, rings: [[39.8, 0, 1], [41.6, 0, 0.98], [42, 0, 0.94]], col: '#fbfaf6', mat: 'plastic' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 8.4], a: 18.4, b: 23.4, n: 28, rings: [[42, 1.2, 0.9], [43, 0, 1], [44.4, 0, 0.94], [45, 0, 0.7]], col: '#a8dcc8', soft: 1, mat: 'fab' }));
          o.push(box(0, 21, -21, 22, 5, 10, WH, { r: 3, mat: 'cer' }));
          o.push(box(0, 26, -26.4, 44, 40, 17, WH, { r: 5, bev: 2, mat: 'cer' }), box(0, 66, -26.4, 46, 3.4, 18.6, WH, { r: 5, bev: 1.2, mat: 'cer' }));
          o.push(box(-16, 60, -17.4, 6, 2, 1.4, '#d8dde2', { r: 0.8, mat: 'metal' }));
          o.push(sol({ ax: 'x', sh: 'el', c: [-25.4, 74.6], a: 5.2, b: 5.2, n: 18, rings: [[-2, 0], [10, 0]], col: '#fbfbf8', mat: 'fab' }));
          o.push(cyl(14, 69.4, -27, 3.4, 4, '#d8a07a', { n: 14, mat: 'cer' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('loo29b'), k = C.k;
        const under = shadow(C, 0, 2, 24, 30, 0.4);
        const cover = FL(C, 45.02, rep(40, () => { const a = R() * 2 * PI, r = Math.sqrt(R()); return `<circle cx="${f1(Math.cos(a) * r * 12)}" cy="${f1(8.4 + Math.sin(a) * r * 15)}" r="0.5" fill="#d8f2e6" opacity="0.7"/>`; }).join(''));
        const roll = vdot(C, [1, 0, 0]) > 0.05 ? PLN(C, [10.02, 74.6, -25.4], [0, 0, 1], [0, -1, 0], `<circle r="1.6" fill="#c8a878"/><circle r="0.9" fill="#6a5a44"/>`) : '';
        const succ = rep(7, i => { const a = i / 7 * 2 * PI, p = C.P([14 + Math.cos(a) * 1.6, 75, -27 + Math.sin(a) * 1.6]), q = C.P([14 + Math.cos(a) * 3.6, 77.4, -27 + Math.sin(a) * 3.6]); return `<path d="M${P2(p)}Q${P2([(p[0] + q[0]) / 2, q[1] - 1.4 * k])} ${P2(q)}" stroke="#6aa070" stroke-width="${f1(1.6 * k)}" stroke-linecap="round" fill="none"/>`; }).join('') + H.sph(C, [14, 75.4, -27], 1.6, '#8ac08a');
        const fr = C.P([-16, 69.6, -20]);
        const puff = rep(3, i => `<circle cx="${f1(fr[0])}" cy="${f1(fr[1])}" r="${f1(1.6 * k)}" fill="#ffffff" opacity="0"><animate attributeName="cy" values="${f1(fr[1])};${f1(fr[1] - 12 * k)}" dur="6s" begin="${-i * 0.3}s" repeatCount="indefinite"/><animate attributeName="r" values="${f1(1 * k)};${f1(4 * k)}" dur="6s" begin="${-i * 0.3}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.5;0;0" keyTimes="0;0.08;0.35;1" dur="6s" begin="${-i * 0.3}s" repeatCount="indefinite"/></circle>`).join('');
        const fresh = RD.H15.box3(C, { c: [-16, 69.4, -21], w: 4, h: 3.6, d: 2.2, col: '#f2c4d8', r: 0.8 });
        return { under, front: (vdot(C, [0, 0, 1]) > -0.2 ? cover : '') + roll + succ + fresh + puff, bb: C.bb(4) }; };
      return D; };

    // BTH-042 WALL-HUNG CONCEALED-CISTERN MODERN TOILET (T3): a matte charcoal stone-look panel hides the cistern, topped by an oiled oak shelf with a reed
    // diffuser and a small fern; the rimless bowl floats off the floor on its bracket with a slim soft-close seat and the lid up against the panel; a brushed
    // brass dual-flush plate. Live: a soft warm night-light glows under the floating bowl and the diffuser reeds give off a faint scent curl.
    N.loo29c = S => { const WH = '#f4f2ee', CH = '#3c3e42', OAK = '#c9a37a';
      const D = { w: 56, d: 70, arch: 'toilet', build: () => { const { box, cyl } = K(), o = [];
          o.push(box(0, 0, -31, 44, 100, 8, CH, { r: 1.2, mat: 'cer' }), box(0, 100, -30.4, 46, 3, 9.6, OAK, { r: 1, mat: 'wood' }));
          o.push(box(0, 22, -24.5, 22, 14, 5, WH, { r: 2.4, mat: 'cer' }));
          o.push(sol({ ax: 'y', sh: 'rr', c: [0, 2], a: 18, b: 23, r: 11, n: 6, rings: [[20, 0, 0.6], [24, 0, 0.82], [30, 0, 0.95], [35.6, 0, 0.995], [37, 0, 1]], col: WH, mat: 'cer' }));
          o.push(sol({ ax: 'y', sh: 'rr', c: [0, 2.3], a: 18.2, b: 23.2, r: 11, n: 6, rings: [[37, 0, 1], [38.4, 0, 0.99]], col: '#fbfaf8', mat: 'plastic' }));
          o.push(sol({ ax: 'y', sh: 'rr', c: [0, 4.4], a: 12, b: 16.2, r: 9, n: 6, rings: [[38.4, 0, 1], [38.6, 0, 1]], col: '#c8e6f0', noOut: 1, mat: 'gloss' }));
          o.push(sol({ ax: 'z', sh: 'rr', c: [0, 38.6 + 22], a: 17.6, b: 22, r: 11, n: 6, rings: [[-21.4, 0, 0.98], [-21, 0, 1], [-19.8, 0, 1]], col: '#fbfaf8', mat: 'plastic' }));
          o.push(cyl(14, 103, -30, 2.4, 6, '#e8e0d0', { n: 14, mat: 'cer' }), cyl(-14, 103, -30, 3, 3.6, '#6a5a4a', { n: 14, mat: 'cer' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('loo29c'), id = C.u('t42'), k = C.k;
        const under = FL(C, 0.06, `<ellipse cx="0" cy="2" rx="24" ry="28" fill="url(#${id}g)">${an('opacity', '0.6;1;0.6', 6, 0, SPL(2))}</ellipse>`) + shadow(C, 0, -4, 18, 22, 0.25);
        const plate = vdot(C, [0, 0, 1]) > 0.05 ? PLN(C, [-6, 93, -26.98], [1, 0, 0], [0, -1, 0], `<rect width="12" height="7" rx="0.8" fill="url(#${id}b)" stroke="#8a6a30" stroke-width="0.15"/><rect x="0.8" y="0.8" width="6" height="5.4" rx="0.5" fill="#d8b878" stroke="#8a6a30" stroke-width="0.12"/><rect x="7.4" y="0.8" width="3.8" height="5.4" rx="0.5" fill="#d8b878" stroke="#8a6a30" stroke-width="0.12"/>`) : '';
        const reeds = rep(6, i => line3(C, [[14 + (i - 2.5) * 0.3, 108, -30], [14 + (i - 2.5) * 1.6, 120, -30 + (i % 2 ? 1.5 : -1.5)]], 0.3, '#3a2a1a')).join('');
        const fern = rep(9, i => { const a = -1.2 + i * 0.3, p = [-14, 106.6, -30], q = [-14 + Math.sin(a) * 9, 106.6 + Math.cos(a) * 6, -30 + (i % 3 - 1) * 2]; let d = 'M' + PP(C, p) + 'L' + PP(C, q); for (let t = 0.25; t < 1; t += 0.2) { const m = [p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t, p[2] + (q[2] - p[2]) * t], a2 = C.P(m); d += `M${P2(a2)}l${f1(-1.2 * k)} ${f1(-0.6 * k)}M${P2(a2)}l${f1(1.2 * k)} ${f1(-0.6 * k)}`; } return `<path d="${d}" stroke="#4a8a46" stroke-width="${f1(0.4 * k)}" fill="none" stroke-linecap="round"/>`; }).join('');
        const tp = C.P([14, 121, -30]), scent = `<path d="M${P2(tp)}c${f1(-2 * k)} ${f1(-3 * k)} ${f1(2 * k)} ${f1(-5 * k)} 0 ${f1(-9 * k)}" stroke="#ffffff" stroke-width="${f1(0.5 * k)}" fill="none" opacity="0">${an('opacity', '0;0.5;0', 7)}</path>`;
        return { defs: `<defs><radialGradient id="${id}g"><stop offset="0" stop-color="#ffe2a8" stop-opacity="0.55"/><stop offset="1" stop-color="#ffe2a8" stop-opacity="0"/></radialGradient><linearGradient id="${id}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f2d488"/><stop offset="0.5" stop-color="#c99a3e"/><stop offset="1" stop-color="#8a6420"/></linearGradient></defs>`, under, front: plate + reeds + fern + scent, bb: C.bb(4) }; };
      return D; };
  }

  // ---- toilets batch 2 (062 / 082), same helpers as batch 1
  { const K = () => X.K, glue = o => (p, L) => L.map(k => { k.par = p; o.push(k); return k; });
    const { shadow, vis } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const sol = o => X.K.solid(o);
    // near-side arc of an ellipse ring (cx, cz, a, b) at height y, as a stroke: only the segments facing the camera
    const ringNear = (C, cx, cz, a, b, y, w, col, ex, zmin) => { let d = '', on = false; for (let i = 0; i <= 64; i++) { const t = i / 64 * 2 * PI, x = cx + Math.cos(t) * a, z = cz + Math.sin(t) * b, n = [Math.cos(t) / a, 0, Math.sin(t) / b], f = vis(C, n) > 0.02 && (zmin == null || z > zmin);
        if (f) { d += (on ? 'L' : 'M') + PP(C, [x, y, z]); on = true; } else on = false; } return d ? `<path d="${d}" stroke="${col}" stroke-width="${f1(w * C.k)}" fill="none" stroke-linecap="round"${ex ? ' ' + ex : ''}/>` : ''; };

    // BTH-062 JAPANESE SMART BIDET TOILET WITH HEATED SEAT & DEODORIZER (T4): a one-piece skirted, tankless toilet in warm ivory porcelain with a fine
    // champagne-gold line round the skirt, an elongated soft-close seat and closed lid, a sleek rear unit with a brushed champagne control strip (seat heat
    // lit amber, water, dryer, deodorizer). Live: a warm shimmer rises off the heated seat, the deodorizer breathes out a faint curl from the rear vent and a
    // soft amber night-light glows on the floor round the base.
    N.loo29d = S => { const IV = '#f6f1e6', CG = '#d6b878';
      const D = { w: 56, d: 70, arch: 'toilet', build: () => { const { box } = K(), o = [];
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 4], a: 17.4, b: 23.4, n: 30, rings: [[0, 0, 0.72], [1.2, 0, 0.78], [3, 0, 0.79], [14, 0, 0.8], [24, 0, 0.9], [31, 0, 1.01], [35.6, 0, 1.07], [37, 0, 1.06]], col: IV, mat: 'gloss' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 4.6], a: 18.4, b: 24.6, n: 30, rings: [[37, 0, 0.99], [38.8, 0, 1], [39.4, 0, 0.98]], col: '#fbf8f0', mat: 'gloss' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 4.6], a: 18.2, b: 24.4, n: 30, rings: [[39.4, 0, 0.99], [41, 0, 1], [42.6, 0, 0.94], [43.6, 0, 0.8], [44, 0, 0.6]], col: '#fbf8f0', mat: 'gloss' }));
          o.push(box(0, 24, -28.4, 36, 22, 13, IV, { r: 6, bev: 3, mat: 'gloss' }));
          o.push(box(0, 46, -28.4, 30, 1.4, 10, CG, { r: 4, mat: 'brush' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), id = C.u('t62'), k = C.k;
        const under = FL(C, 0.06, `<ellipse cx="0" cy="4" rx="26" ry="32" fill="url(#${id}g)">${an('opacity', '0.6;1;0.6', 7, 0, SPL(2))}</ellipse>`) + shadow(C, 0, 2, 20, 26, 0.35);
        const band = ringNear(C, 0, 4, 17.4 * 0.875, 23.4 * 0.875, 20, 0.45, CG, '', -2) + ringNear(C, 0, 4, 17.4 * 0.875, 23.4 * 0.875, 20.3, 0.15, '#fff0c0', '', -2);
        const strip = FL(C, 47.42, `<g transform="translate(0 -28.4)"><circle cx="-9" r="1.1" fill="#ffb060">${an('opacity', '0.6;1;0.6', 2.4)}</circle><circle cx="-9" r="1.8" fill="#ffb060" opacity="0.25"/>${[-3, 3, 9].map(x => `<circle cx="${x}" r="1.1" fill="none" stroke="#8a6a30" stroke-width="0.3"/>`).join('')}<path d="M-3.6 0.3q0.6 -1.2 1.2 0" stroke="#8a6a30" stroke-width="0.25" fill="none"/><path d="M2.4 -0.4h1.2M2.4 0.4h1.2" stroke="#8a6a30" stroke-width="0.25"/><path d="M8.5 0.5q0.5 -1.6 1 0" stroke="#8a6a30" stroke-width="0.25" fill="none"/></g>`);
        const heat = rep(3, i => { const p = C.P([-7 + i * 7, 43.8, 4.6]); return `<path d="M${P2(p)}c${f1(-1.2 * k)} ${f1(-2 * k)} ${f1(1.2 * k)} ${f1(-3.4 * k)} 0 ${f1(-5.6 * k)}c${f1(-1.2 * k)} ${f1(-2 * k)} ${f1(1.2 * k)} ${f1(-3.4 * k)} 0 ${f1(-5.6 * k)}" stroke="#ffc890" stroke-width="${f1(0.45 * k)}" fill="none" opacity="0">${an('opacity', '0;0.55;0', 4, -i * 1.3)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-4 * k)}" dur="4s" begin="${-i * 1.3}s" repeatCount="indefinite"/></path>`; }).join('');
        const vp = C.P([12, 46.2, -34]), curl = vdot(C, [0, 0, 1]) > -0.4 ? `<path d="M${P2(vp)}c${f1(2 * k)} ${f1(-3 * k)} ${f1(-2 * k)} ${f1(-5 * k)} ${f1(0.6 * k)} ${f1(-9 * k)}" stroke="#ffffff" stroke-width="${f1(0.6 * k)}" fill="none" opacity="0">${an('opacity', '0;0.5;0', 6)}</path>` : '';
        return { defs: `<defs><radialGradient id="${id}g"><stop offset="0.55" stop-color="#ffcf8a" stop-opacity="0.5"/><stop offset="1" stop-color="#ffcf8a" stop-opacity="0"/></radialGradient></defs>`, under, front: band + strip + heat + curl, bb: C.bb(4) }; };
      return D; };

    // BTH-082 ZERO-GRAVITY UV-SANITIZING BIO-HEALTH SMART THRONE (T5): a sculpted Carrara-marble throne that hovers over a polished gold plinth with a black
    // glass top: a tall marble back panel with a gold crown cap and three gold finials, floating marble armrests capped in gold, a marble bowl and closed lid
    // edged in gold. Live: a warm beam and a gold halo fill the hover gap, a soft UV ring breathes round the seat while the lid sanitises, and a little
    // champagne hologram over the arm shows a heartbeat line and 'all clear'.
    N.loo29e = S => { const MB = '#f4f1ec', GD = '#d6b06a', HB = 10;
      const D = { w: 56, d: 70, arch: 'toilet', float: true, build: () => { const { box, cyl, ball } = K(), o = [], on = glue(o), MT = { tex: 'url(#t82m) none', mat: 'gloss' };
          o.push(cyl(0, 0, 0, 24, 1.4, GD, { rz: 30, n: 32, mat: 'metal' }), cyl(0, 1.4, 0, 22.6, 1.4, '#141216', { rz: 28.6, n: 32, mat: 'gloss' }));
          o.push(sol(Object.assign({ ax: 'y', sh: 'el', c: [0, 6], a: 17.4, b: 22.6, n: 30, rings: [[HB, 0, 0.6], [HB + 2, 0, 0.82], [HB + 10, 0, 0.95], [33, 0, 1.03], [37, 0, 1.06]], col: MB }, MT)));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 6.4], a: 18.6, b: 24, n: 30, rings: [[37, 0, 1], [38.4, 0, 1]], col: GD, mat: 'metal' }));
          o.push(sol(Object.assign({ ax: 'y', sh: 'el', c: [0, 6.4], a: 18.4, b: 23.8, n: 30, rings: [[38.4, 0, 0.99], [41, 0, 1], [42.6, 0, 0.95], [43.2, 0, 0.82]], col: MB }, MT)));
          o.push(box(0, HB + 4, -24, 18, 20, 6, MB, Object.assign({ r: 3 }, MT)));
          o.push(box(0, HB, -31.6, 44, 92, 6.8, MB, Object.assign({ r: 3, bev: 1.6 }, MT)), box(0, HB + 92, -31.6, 46, 2.6, 7.6, GD, { r: 3, mat: 'metal' }));
          [-15, 0, 15].forEach((x, i) => o.push(ball(x, HB + 94.6, -31.6, i === 1 ? 2.6 : 1.8, GD, { k: 5, n: 14, mat: 'metal' })));
          [-1, 1].forEach(sg => { o.push(box(sg * 23.6, 48, -15.2, 5.2, 4.6, 26, MB, Object.assign({ r: 2.4 }, MT)), box(sg * 23.6, 52.6, -15.2, 5.6, 1.2, 26.6, GD, { r: 2.6, mat: 'metal' })); });
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('loo29e'), id = C.u('t82'), k = C.k;
        const veins = rep(4, () => { const y0 = R() * 60; let d = `M0 ${f1(y0)}`; for (let x = 10; x <= 60; x += 10) d += `Q${f1(x - 5)} ${f1(y0 + (R() - 0.5) * 16)} ${x} ${f1(y0 + (R() - 0.5) * 10)}`; return `<path d="${d}" stroke="#c4bdb2" stroke-width="${f1(0.15 + R() * 0.25)}" fill="none" opacity="0.5"/>`; }).join('');
        const defs = `<defs><pattern id="t82m" width="60" height="60" patternUnits="userSpaceOnUse"><rect width="60" height="60" fill="#f4f1ec"/>${veins}<path d="M0 34Q30 22 60 38" stroke="#d6c49a" stroke-width="0.25" fill="none" opacity="0.5"/></pattern>`
          + `<radialGradient id="${id}a"><stop offset="0" stop-color="#ffe6b0" stop-opacity="0.7"/><stop offset="1" stop-color="#ffe6b0" stop-opacity="0"/></radialGradient><linearGradient id="${id}b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe6b0" stop-opacity="0.8"/><stop offset="1" stop-color="#ffb05a" stop-opacity="0.2"/></linearGradient></defs>`;
        const under = FL(C, 0.05, `<ellipse rx="34" ry="40" fill="url(#${id}a)" opacity="0.6">${an('opacity', '0.4;0.75;0.4', 4.8)}</ellipse>`)
          + FL(C, 2.84, `<g><ellipse rx="18" ry="23" fill="none" stroke="${GD}" stroke-width="0.5" stroke-dasharray="0.5 2" opacity="0.9"/>${at('rotate', '0;360', 40)}</g><ellipse rx="10" ry="13" fill="#ffe6b0" opacity="0.4" filter="url(#m11b8)">${an('opacity', '0.25;0.55;0.25', 2.4)}</ellipse>`);
        const a = C.P([0, 2.9, 6]), b = C.P([0, HB + 0.3, 6]), w0 = 14 * k, w1 = 10 * k;
        const beam = `<path d="M${f1(a[0] - w0)} ${f1(a[1])}L${f1(b[0] - w1)} ${f1(b[1])}H${f1(b[0] + w1)}L${f1(a[0] + w0)} ${f1(a[1])}Z" fill="url(#${id}b)" opacity="0.6">${an('opacity', '0.4;0.75;0.4', 2.4)}</path>`
          + ringNear(C, 0, 6, 15, 19.5, 6.4, 0.6, '#fff0c0', `opacity="0.8"`) + rep(4, i => { const t = i * 1.7, p = C.P([Math.cos(t) * 8, 3.4, 6 + Math.sin(t) * 10]), q = C.P([Math.cos(t) * 6, HB - 0.5, 6 + Math.sin(t) * 7]); return `<circle r="${f1(0.4 * k)}" fill="#fff0c8" opacity="0"><animate attributeName="cx" values="${f1(p[0])};${f1(q[0])}" dur="2.8s" begin="${-i * 0.7}s" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(p[1])};${f1(q[1])}" dur="2.8s" begin="${-i * 0.7}s" repeatCount="indefinite"/>${an('opacity', '0;0.9;0', 2.8, -i * 0.7)}</circle>`; }).join('');
        const uv = ringNear(C, 0, 6.4, 18.8, 24.2, 38.2, 2.4, '#c8a8ff', `opacity="0.4" filter="url(#m12b1)"`).replace('/>', `>${an('opacity', '0.15;0.55;0.15', 5)}</path>`);
        const hp = C.P([23.6, 60, -10]), hs = (5.6 * k).toFixed(2);
        const holo = `<g transform="translate(${P2(hp)}) scale(${hs})" opacity="0.9"><rect x="-2.4" y="-1.6" width="4.8" height="3.2" rx="0.5" fill="#fff0d0" opacity="0.16" stroke="#f6dca0" stroke-width="0.06"/><path d="M-2 0.2H-1L-0.7 -0.6L-0.4 0.9L-0.1 -1L0.2 0.2H2" stroke="#ffd08a" stroke-width="0.1" fill="none" stroke-dasharray="6" stroke-dashoffset="6">${an('stroke-dashoffset', '6;0;0', 2.2, 0, KT('0;0.7;1'))}</path><text y="1.2" text-anchor="middle" font-family="Arial,sans-serif" font-size="0.42" fill="#fff0d0">ALL CLEAR · 72 bpm</text><path d="M0 1.6V3" stroke="#f6dca0" stroke-width="0.05" stroke-dasharray="0.15 0.12"/></g>`;
        return { defs, under: under + beam, front: uv + holo, bb: C.bb(4) }; };
      return D; };
  }

  // ======================= WASHBASINS (BTH-006/026/046/066/086): real solids + fx, arch 'bsink', 60 x 50, act 'wash' + use {0, 44} kept, rim/top ~ y 44-58 =======================
  { const K = () => X.K, sol = o => X.K.solid(o), CHR = '#d8dde2';
    const { shadow, vis } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const FR0 = (C, z, y0, svg) => vdot(C, [0, 0, 1]) > 0.08 ? PLN(C, [0, y0, z], [1, 0, 0], [0, -1, 0], svg) : '';
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const line3 = (C, P, w, col, ex) => '<path d="M' + P.map(p => PP(C, p)).join('L') + '" stroke="' + col + '" stroke-width="' + f1(w * C.k) + '" fill="none" stroke-linecap="round" stroke-linejoin="round"' + (ex ? ' ' + ex : '') + '/>';
    const SINK = o => Object.assign({ w: 60, d: 50, arch: 'bsink', act: 'wash', use: { x: 0, z: 44 } }, o);
    const zP = (z0, z1, x, y, r, col, mat) => sol({ ax: 'z', sh: 'el', c: [x, y], a: r, b: r, n: 12, rings: [[z0, 0], [z1, 0]], col, mat: mat || 'metal' });
    // drip from a spout tip p (world) down to water level y1, every T s
    const drip = (C, p, y1, T, b) => { const a = C.P(p), w = C.P([p[0], y1, p[2]]), k = C.k, KQ = ` keyTimes="0;0.7;0.9;0.91;1" dur="${T}s" begin="${n4(b || 0)}s" repeatCount="indefinite"`;
      return `<ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="${f1(0.45 * k)}" ry="${f1(0.55 * k)}" fill="#cfe4ee"><animate attributeName="cy" values="${f1(a[1])};${f1(a[1] + 0.6 * k)};${f1(w[1])};${f1(a[1])};${f1(a[1])}"${KQ}/><animate attributeName="opacity" values="0.9;0.9;0.9;0;0.9"${KQ}/></ellipse>`
        + `<ellipse cx="${f1(w[0])}" cy="${f1(w[1])}" rx="0" ry="0" fill="none" stroke="#ffffff" stroke-width="${f1(0.2 * k)}"><animate attributeName="rx" values="0;0;0;${f1(0.5 * k)};${f1(4 * k)}"${KQ}/><animate attributeName="ry" values="0;0;0;${f1(0.2 * k)};${f1(1.4 * k)}"${KQ}/><animate attributeName="opacity" values="0;0;0;0.9;0"${KQ}/></ellipse>`; };

    // BTH-006 CRACKED PORCELAIN PEDESTAL SINK WITH EXPOSED PIPES (T1): a chipped yellowing basin on a cracked pedestal, two old cross-head taps (red and blue
    // buttons, one dripping), copper supply lines and a rusty drain pipe running bare into the wall, a rust streak in the bowl under the taps, a worn bar of
    // soap stuck to the rim. Live: the hot tap drips and rings spread on the water.
    N.sink29a = S => { const PC = '#ebe4d2';
      const D = SINK({ build: () => { const { box, cyl, ball } = K(), o = [];
          o.push(sol({ ax: 'y', sh: 'el', c: [0, -4], a: 8, b: 7, n: 18, rings: [[0, 0, 1.4], [1.6, 0, 1.24], [6, 0, 1], [36, 0, 0.92], [42, 0, 1.1], [44, 0, 1.25]], col: PC, mat: 'cer' }));
          o.push(sol({ ax: 'y', sh: 'rr', c: [0, -2], a: 26, b: 21, r: 11, n: 6, rings: [[44, 0, 0.7], [50, 0, 0.94], [55.6, 0, 1], [58, 0, 0.99]], col: PC, mat: 'cer' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 1.6], a: 17, b: 12.4, n: 22, rings: [[58, 0], [58.2, 0]], col: '#d6e2e2', noOut: 1, mat: 'gloss' }));
          [-9, 9].forEach((x, i) => { o.push(cyl(x, 58.2, -15.6, 1.3, 4.4, '#c8ccc8', { n: 10, mat: 'metal' }), zP(-14.3, -10.6, x, 61.4, 0.75, '#c8ccc8'), ball(x, 62.6, -15.6, 1.5, i ? '#c84a3a' : '#3a6ac8', { k: 4, n: 10 }));
            o.push(cyl(x, 30, -20.6, 0.8, 14, '#c07a48', { n: 8, mat: 'metal' }), zP(-25, -21.4, x, 30, 0.8, '#c07a48')); });
          o.push(cyl(0, 24, -18.6, 1.6, 20, '#8a8478', { n: 10, mat: 'metal' }), zP(-25, -20.2, 0, 24, 1.6, '#7a6a58'));
          o.push(box(16, 58, -12, 4.4, 1.4, 2.8, '#e8d8a8', { r: 1 }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('sink29a'), k = C.k;
        const under = shadow(C, 0, -2, 18, 16, 0.4);
        const bowl = FL(C, 58.25, `<path d="M9 -14Q8 -8 7.4 -2Q9 2 8.4 6" stroke="#b07a3a" stroke-width="1.4" fill="none" opacity="0.4" stroke-linecap="round"/><ellipse cx="0" cy="1.6" rx="4" ry="3" fill="#a8a088" opacity="0.35"/><circle cx="0" cy="1.6" r="1" fill="#5a5a50"/>`)
          + FL(C, 58.04, `<path d="M-6 18.6l1.2 1.8l1.6 -0.4l0.6 -1.4" fill="#c8bca0" stroke="#8a7e66" stroke-width="0.15"/><path d="M14 -10.4l1.6 0.6" stroke="#8a7e66" stroke-width="0.2"/>`);
        const crack = FR0(C, 5.2, 40, `<path d="M-1 6L0.4 12L-0.8 17L1 24L0.2 30" stroke="#6a6250" stroke-width="0.3" fill="none"/><path d="M-0.8 6.2L0.6 12.2L-0.6 17.2L1.2 24.2" stroke="#ffffff" stroke-width="0.15" fill="none" opacity="0.8"/><path d="M-6 2.6l2 -0.4l1 0.8" fill="#c8bca0"/>`);
        return { under, front: bowl + crack + drip(C, [9, 61.4, -10.4], 58.3, 3.6), bb: C.bb(4) }; };
      return D; };

    // BTH-026 SINGLE-BASIN WHITE CABINET VANITY (T2): a crisp white shaker vanity (two doors, brushed nickel knobs, toe kick) under a cultured-marble top
    // with an integrated oval basin and a short backsplash; a single-lever chrome faucet, a blush soap pump and a mint cup of toothbrushes, a folded hand
    // towel on the counter. Live: soap bubbles drift up from the pump now and then and a glint slides along the faucet.
    N.sink29b = S => { const WH = '#f6f4ee', TOP = '#f1eee6';
      const D = SINK({ build: () => { const { box, cyl } = K(), o = [];
          o.push(box(0, 0, -5, 50, 3, 36, '#d8d4ca', { r: 1 }), box(0, 3, -5, 54, 41, 40, WH, { r: 1.4, mat: 'matte' }));
          o.push(box(0, 44, -3, 58, 3, 44, TOP, { r: 2, mat: 'gloss' }), box(0, 47, -23.8, 58, 6, 2.4, TOP, { r: 1, mat: 'gloss' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, -2], a: 15, b: 11, n: 22, rings: [[47, 0], [47.15, 0]], col: '#e4ecee', noOut: 1, mat: 'gloss' }));
          o.push(cyl(0, 47, -18, 1.5, 7, CHR, { n: 12, mat: 'chrome' }), zP(-16.5, -10.4, 0, 53, 0.9, CHR, 'chrome'), box(0, 54, -19.4, 1.2, 1, 5, CHR, { r: 0.5, mat: 'chrome' }));
          o.push(cyl(18, 47, -16, 2.3, 6.4, '#ecc8d4', { n: 14, mat: 'gloss' }), cyl(18, 53.4, -16, 0.7, 2, '#f6f4ee', { n: 8 }), zP(-15.3, -13, 18, 55.2, 0.5, '#f6f4ee', 'plastic'));
          o.push(cyl(-18, 47, -16, 2.4, 5.4, '#a8dcc8', { n: 14, mat: 'gloss' }));
          o.push(box(-17, 47, 8, 12, 2.2, 8, '#f4c8a8', { r: 1, mat: 'fab' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('sink29b'), id = C.u('s26'), k = C.k;
        const under = shadow(C, 0, -5, 30, 24, 0.35);
        const doors = FR0(C, 15.02, 44, `<g transform="translate(-27 0)">${[0, 27].map(x => `<rect x="${x + 1}" y="2" width="25" height="37" fill="none" stroke="#d8d6cc" stroke-width="0.5"/><rect x="${x + 4.4}" y="5.4" width="18.2" height="30.2" fill="none" stroke="#e8e6de" stroke-width="0.35"/><rect x="${x + 4.6}" y="5.6" width="18" height="0.4" fill="#d0ccc0"/>`).join('')}<circle cx="23.4" cy="9" r="0.9" fill="#b8bcc0"/><circle cx="30.6" cy="9" r="0.9" fill="#b8bcc0"/><circle cx="23.2" cy="8.7" r="0.3" fill="#ffffff"/><circle cx="30.4" cy="8.7" r="0.3" fill="#ffffff"/></g>`);
        const basin = FL(C, 47.18, `<ellipse cx="0" cy="-2" rx="15" ry="11" fill="url(#${id}b)"/><circle cx="0" cy="0.6" r="0.9" fill="#a8b0b4"/><circle cx="0" cy="0.6" r="0.4" fill="#5a6064"/>`);
        const towel = FL(C, 49.22, `<g transform="translate(-17 8)"><rect x="-6" y="-4" width="12" height="8" fill="#f8d4b8"/><path d="M-6 -2.4H6M-6 2.4H6" stroke="#e8b898" stroke-width="0.4"/></g>`);
        const brushes = [[-19, '#f6a8b8'], [-17.6, '#8ac8e8'], [-16.6, '#f6d878']].map(([x, c], i) => line3(C, [[x, 50, -16 + i * 0.6], [x - 1 + i, 58, -17 + i]], 0.55, c) + line3(C, [[x - 1 + i, 57, -17 + i], [x - 1 + i, 58.6, -16.4 + i]], 0.8, '#ffffff')).join('');
        const bp = C.P([18, 55.6, -13.4]), bub = rep(3, i => `<circle cx="${f1(bp[0])}" cy="${f1(bp[1])}" r="${f1(0.8 * k)}" fill="#ffffff" fill-opacity="0.3" stroke="#d8e8f0" stroke-width="${f1(0.15 * k)}" opacity="0"><animate attributeName="cy" values="${f1(bp[1])};${f1(bp[1] - 14 * k)}" dur="7s" begin="${-i * 0.5}s" repeatCount="indefinite"/><animate attributeName="cx" values="${f1(bp[0])};${f1(bp[0] + (i - 1) * 3 * k)}" dur="7s" begin="${-i * 0.5}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;0.9;0.9;0;0" keyTimes="0;0.05;0.3;0.38;1" dur="7s" begin="${-i * 0.5}s" repeatCount="indefinite"/></circle>`).join('');
        return { defs: `<defs><radialGradient id="${id}b" cx="50%" cy="40%" r="60%"><stop offset="0" stop-color="#f8fafa"/><stop offset="0.7" stop-color="#dfe6e8"/><stop offset="1" stop-color="#b8c2c6"/></radialGradient></defs>`, under, front: doors + basin + towel + brushes + bub, bb: C.bb(4) }; };
      return D; };

    // BTH-046 FLOATING TEAK VANITY WITH CERAMIC VESSEL BOWL (T3): an oiled teak drawer unit floating off the wall (finger-pull groove, straight grain), a teak
    // top with a hand-thrown matte white vessel bowl, a tall matte black gooseneck faucet, a stone soap dish and a bud vase of eucalyptus; a floating teak shelf
    // below with two rolled linen towels. Live: a warm LED line glows under the drawer and the eucalyptus sways.
    N.sink29c = S => { const TK = '#a8703e', TK2 = '#b8804a', BK = '#2a2a2c';
      const D = SINK({ build: () => { const { box, cyl } = K(), o = [];
          o.push(box(0, 24, -6, 52, 17, 38, TK, { r: 1.2, mat: 'wood' }), box(0, 41, -5, 56, 3, 40, TK2, { r: 1.2, mat: 'wood' }));
          o.push(box(0, 7, -11, 48, 2.4, 28, TK2, { r: 1, mat: 'wood' }));
          [[-15, 0], [-1, 1]].forEach(([x0, i]) => o.push(sol({ ax: 'x', sh: 'el', c: [-12, 12.4], a: 3, b: 3, n: 16, rings: [[x0, 0, 0.92], [x0 + 0.6, 0, 1], [x0 + 11.4, 0, 1], [x0 + 12, 0, 0.92]], col: i ? '#e8e0d0' : '#c8d4c8', mat: 'fab' })));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, -3], a: 13, b: 11, n: 28, rings: [[44, 0, 0.52], [45.4, 0, 0.78], [49, 0, 0.95], [53.6, 0, 1], [54, 0, 0.99]], col: '#f2efe8', mat: 'matte' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, -2.6], a: 11.2, b: 9.2, n: 24, rings: [[54, 0], [54.15, 0]], col: '#dfe7ea', noOut: 1, mat: 'gloss' }));
          o.push(cyl(0, 44, -19, 1.1, 18, BK, { n: 12, mat: 'matte' }), zP(-17.9, -8, 0, 61.2, 0.8, BK, 'matte'), cyl(0, 58.4, -7.2, 0.8, 2.8, BK, { n: 10, mat: 'matte' }), box(2.6, 52, -19, 2.8, 0.9, 0.9, BK, { r: 0.4 }));
          o.push(sol({ ax: 'y', sh: 'el', c: [19, -14], a: 4.4, b: 3.2, n: 16, rings: [[44, 0, 0.9], [45.2, 0, 1]], col: '#8a8a84', mat: 'matte' }), box(19, 45.2, -14, 3.4, 1.2, 2, '#e8dcc8', { r: 0.8 }));
          o.push(cyl(19, 44, -2, 1.6, 6, '#c8d0c4', { n: 12, mat: 'gloss', rg: [[0, 0, 1], [4, 0, 1.1], [6, 0, 0.5]] }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('sink29c'), id = C.u('s46'), k = C.k;
        const under = shadow(C, 0, -8, 28, 18, 0.25) + FL(C, 0.06, `<ellipse cx="0" cy="-6" rx="28" ry="20" fill="url(#${id}g)">${an('opacity', '0.6;1;0.6', 7, 0, SPL(2))}</ellipse>`);
        const grain = rep(14, () => { const y = 25 + R() * 15; return `<path d="M-26 ${f1(-y)}Q0 ${f1(-y + (R() - 0.5) * 1.6)} 26 ${f1(-y + (R() - 0.5))}" stroke="#7a4a24" stroke-width="0.15" opacity="0.6"/>`; }).join('');
        const front = vdot(C, [0, 0, 1]) > 0.08 ? PLN(C, [0, 0, 13.02], [1, 0, 0], [0, 1, 0], `<g transform="scale(1 -1)">${grain}<path d="M-26 -36.4H26" stroke="#4a2a14" stroke-width="0.8"/><path d="M-26 -35.6H26" stroke="#d8a070" stroke-width="0.2"/><path d="M0 -41V-24" stroke="#6a3e1c" stroke-width="0.25"/></g>`) : '';
        const led = vdot(C, [0, 0, 1]) > 0.1 ? `<path d="M${PP(C, [-24, 23.8, 12.6])}L${PP(C, [24, 23.8, 12.6])}" stroke="#ffd890" stroke-width="${f1(0.6 * k)}">${an('opacity', '0.6;1;0.6', 7, 0, SPL(2))}</path>` : '';
        const vp = [19, 50, -2], euc = `<g>${at('rotate', `-3 ${PP(C, vp)};4 ${PP(C, vp)};-3 ${PP(C, vp)}`, 5.4, 0, SPL(2))}` + rep(3, i => { const tip = [19 + (i - 1) * 4, 64 + i * 2, -2 - i], P = [vp, [19 + (i - 1) * 2, 57, -2], tip]; return line3(C, P, 0.3, '#6a7a5a') + rep(5, j => { const t = 0.3 + j * 0.15, q = C.P([vp[0] + (tip[0] - vp[0]) * t, vp[1] + (tip[1] - vp[1]) * t, vp[2] + (tip[2] - vp[2]) * t]); return `<ellipse cx="${f1(q[0] + (j % 2 ? 1 : -1) * 1.1 * k)}" cy="${f1(q[1])}" rx="${f1(1 * k)}" ry="${f1(0.8 * k)}" fill="#8aa898" stroke="#6a8878" stroke-width="${f1(0.1 * k)}"/>`; }).join(''); }).join('') + '</g>';
        const bowl = FL(C, 54.2, `<ellipse cx="0" cy="-2.6" rx="11" ry="9" fill="url(#${id}b)"/><circle cx="0" cy="-2" r="0.8" fill="#4a4e50"/>`);
        return { defs: `<defs><radialGradient id="${id}g"><stop offset="0" stop-color="#ffd890" stop-opacity="0.5"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient><radialGradient id="${id}b" cx="50%" cy="38%" r="62%"><stop offset="0" stop-color="#f6f6f2"/><stop offset="0.75" stop-color="#e2e4e0"/><stop offset="1" stop-color="#b8bcb8"/></radialGradient></defs>`, under, front: front + led + bowl + euc, bb: C.bb(4) }; };
      return D; };
  }

  // ---- washbasins batch 2 (066 / 086)
  { const K = () => X.K, sol = o => X.K.solid(o);
    const { shadow, vis } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const SINK = o => Object.assign({ w: 60, d: 50, arch: 'bsink', act: 'wash', use: { x: 0, z: 44 } }, o);
    const zP = (z0, z1, x, y, r, col, mat) => sol({ ax: 'z', sh: 'el', c: [x, y], a: r, b: r, n: 12, rings: [[z0, 0], [z1, 0]], col, mat: mat || 'metal' });
    const rip = (C, p, T, b, s) => { const k = C.k * (s || 1); return `<g transform="translate(${PP(C, p)}) scale(1 0.4)">${[0, T / 2].map(d => `<circle r="0" fill="none" stroke="#ffffff" stroke-width="${f1(0.25 * C.k)}"><animate attributeName="r" values="0;${f1(5 * k)}" dur="${T}s" begin="${n4(-(b || 0) - d)}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.8;0" dur="${T}s" begin="${n4(-(b || 0) - d)}s" repeatCount="indefinite"/></circle>`).join('')}</g>`; };
    // a falling water sheet / stream between two world points (screen-space quad with moving highlights)
    const sheet = (C, a0, a1, b0, b1, id, T, op) => { const P = [a0, a1, b1, b0].map(p => C.P(p)), d = 'M' + P.map(P2).join('L') + 'Z';
      return `<path d="${d}" fill="#dceef4" opacity="${op || 0.55}"/><path d="${d}" fill="url(#${id})" opacity="0.9"/>`; };

    // BTH-066 DOUBLE CARVED RIVER-STONE BASINS ON QUARTZ (T4): a thick white quartz top veined in grey and gold with a matching backsplash, on a slim brushed
    // brass console (four square legs, a walnut shelf with rolled towels and a woven basket); two hand-carved river-stone basins in dark green-grey stone with
    // chisel marks and a polished rim, each under a brass wall spout with a lever; a brass tray with a perfume bottle between them. Live: the spouts trickle
    // in turn and rings spread across the water; a glint runs down a brass leg.
    N.sink29d = S => { const QZ = '#f4f2ee', BR = '#c9a256', ST = '#5c625a', WN = '#6a4229', BX = [-14, 14];
      const D = SINK({ build: () => { const { box, cyl } = K(), o = [], QT = { tex: 'url(#s66q) none', mat: 'gloss' };
          [[-27.4, -23], [27.4, -23], [-27.4, 15], [27.4, 15]].forEach(([x, z]) => o.push(box(x, 0, z, 1.8, 47.6, 1.8, BR, { r: 0.3, mat: 'brush' })));
          o.push(box(0, 12, -4, 52.4, 2.4, 36, WN, { r: 0.8, mat: 'wood' }));
          o.push(box(0, 47.6, -4, 60, 3.8, 42, QZ, Object.assign({ r: 1.2 }, QT)), box(0, 51.4, -23.8, 60, 11, 2.4, QZ, Object.assign({ r: 0.6 }, QT)));
          BX.forEach(x => { o.push(sol({ ax: 'y', sh: 'el', c: [x, 0], a: 10.6, b: 9.4, n: 26, rings: [[51.4, 0, 0.66], [53, 0, 0.84], [56.6, 0, 0.98], [59.4, 0, 1], [60, 0, 0.98]], col: ST, mat: 'matte' }));
            o.push(sol({ ax: 'y', sh: 'el', c: [x, 0.4], a: 8.4, b: 7.2, n: 22, rings: [[60, 0], [60.15, 0]], col: '#8aa6a2', noOut: 1, mat: 'gloss' }));
            o.push(zP(-25, -12, x, 64.6, 0.9, BR, 'metal'), cyl(x, 62.6, -11.1, 0.9, 2, BR, { n: 10, mat: 'metal' }), zP(-25, -22.4, x + 4.4, 64.6, 1.4, BR, 'metal'), box(x + 4.4, 66, -23.2, 0.9, 3.2, 0.9, BR, { r: 0.4 })); });
          o.push(box(0, 51.4, -18, 5.2, 0.6, 5, BR, { r: 0.6, mat: 'metal' }), cyl(0, 52, -18, 1.4, 4.4, '#e8c4a8', { n: 12, mat: 'gloss', rg: [[0, 0, 1], [3.4, 0, 1], [4.4, 0, 0.5]] }), cyl(0, 56.4, -18, 0.8, 1.4, BR, { n: 10, mat: 'metal' }));
          [[-18, '#e8e2d6'], [-7.4, '#d6ccbc']].forEach(([x0, c]) => o.push(sol({ ax: 'x', sh: 'el', c: [-6, 17.4], a: 3, b: 3, n: 16, rings: [[x0, 0, 0.92], [x0 + 0.6, 0, 1], [x0 + 9.4, 0, 1], [x0 + 10, 0, 0.92]], col: c, mat: 'fab' })));
          o.push(box(14, 14.4, -6, 13, 8, 10, '#b8925a', { r: 1.4, mat: 'fab' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('sink29d'), id = C.u('s66'), k = C.k;
        const veins = rep(5, () => { const y0 = R() * 50; let d = `M0 ${f1(y0)}`; for (let x = 10; x <= 50; x += 10) d += `Q${x - 5} ${f1(y0 + (R() - 0.5) * 14)} ${x} ${f1(y0 + (R() - 0.5) * 8)}`; return `<path d="${d}" stroke="${R() < 0.4 ? '#d4b06a' : '#b8b4ac'}" stroke-width="${f1(0.15 + R() * 0.3)}" fill="none" opacity="0.6"/>`; }).join('');
        const defs = `<defs><pattern id="s66q" width="50" height="50" patternUnits="userSpaceOnUse"><rect width="50" height="50" fill="#f4f2ee"/>${veins}</pattern><linearGradient id="${id}w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.8"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/><animate attributeName="y1" values="-1;1" dur="0.6s" repeatCount="indefinite"/><animate attributeName="y2" values="0;2" dur="0.6s" repeatCount="indefinite"/></linearGradient></defs>`;
        const under = shadow(C, 0, -4, 30, 24, 0.3);
        let top = BX.map(x => FL(C, 60.02, `<g transform="translate(${x} 0)">${rep(26, i => { const a = i / 26 * 2 * PI; return `<path d="M${f1(Math.cos(a) * 9)} ${f1(Math.sin(a) * 8)}L${f1(Math.cos(a) * 10.2)} ${f1(Math.sin(a) * 9.1)}" stroke="#3e443e" stroke-width="0.35" opacity="0.6"/>`; }).join('')}<ellipse rx="10.3" ry="9.1" fill="none" stroke="#8a9288" stroke-width="0.3"/></g>`)).join('');
        top += BX.map(x => FL(C, 60.18, `<ellipse cx="${x}" cy="0.4" rx="8.4" ry="7.2" fill="url(#${id}d)"/><circle cx="${x}" cy="1.4" r="0.8" fill="${BR}"/>`)).join('');
        const stream = BX.map((x, i) => { const T = 8, b = i * 4, s = `<g opacity="0">${an('opacity', '0;1;1;0;0', T, -b, KT('0;0.04;0.4;0.44;1'))}${sheet(C, [x - 0.35, 62.6, -11.1], [x + 0.35, 62.6, -11.1], [x - 0.5, 60.2, -11], [x + 0.5, 60.2, -11], id + 'w')}${rip(C, [x, 60.2, -10.6], 1.6, 0, 0.8)}</g>`; return s; }).join('');
        const glint = vdot(C, [0, 0, 1]) > 0.1 ? `<path d="M${PP(C, [27.4, 47, 15.9])}L${PP(C, [27.4, 40, 15.9])}" stroke="#fff4d0" stroke-width="${f1(0.5 * k)}" stroke-linecap="round" opacity="0">${an('opacity', '0;0;0.9;0', 9, 0, KT('0;0.8;0.86;1'))}<animateTransform attributeName="transform" type="translate" values="0 0;0 0;0 ${f1(30 * k)};0 ${f1(30 * k)}" keyTimes="0;0.8;0.95;1" dur="9s" repeatCount="indefinite"/></path>` : '';
        return { defs: defs + `<defs><radialGradient id="${id}d" cx="50%" cy="40%" r="60%"><stop offset="0" stop-color="#a8c0bc"/><stop offset="1" stop-color="#4a5a56"/></radialGradient></defs>`, under, front: top + stream + glint, bb: C.bb(4) }; };
      return D; };

    // BTH-086 SCULPTED FLOATING ALABASTER WATERFALL BASIN WITH SENSOR FAUCETS (T5): a polished nero marquina panel with a gold inlay line; a sculpted block of
    // translucent honey-white alabaster floats off it, glowing warm from within; a gold blade spout pours a clear sheet of water into its shallow basin, which
    // overflows the front lip in a second sheet into a long gold-and-black-glass trough on the floor; a gold sensor plate with a glowing ring. Live: both
    // waterfalls flow, the alabaster breathes with light, ripples spread in the basin and the trough, a glint travels along the gold.
    N.sink29e = S => { const NM = '#1c1a1c', GD = '#d6b06a', AL = '#f6ead6';
      const D = SINK({ build: () => { const { box } = K(), o = [];
          o.push(box(0, 0, -23, 58, 98, 4, NM, { r: 1, mat: 'gloss', tex: 'url(#s86n) none' }), box(0, 98, -23, 59, 1.6, 4.6, GD, { r: 0.8, mat: 'metal' }));
          o.push(sol({ ax: 'y', sh: 'rr', c: [0, -3], a: 25, b: 17.4, r: 9, n: 6, rings: [[40, 0, 0.82], [42, 0, 0.94], [46, 0, 0.99], [55, 0, 1], [56, 0, 0.99]], col: AL, mat: 'gloss', tex: 'url(#s86a) none', emit: 1 }));
          o.push(sol({ ax: 'y', sh: 'rr', c: [0, -1.6], a: 21, b: 13.6, r: 7, n: 6, rings: [[56, 0], [56.15, 0]], col: '#e8f0ee', noOut: 1, mat: 'gloss' }));
          o.push(box(0, 66, -17.6, 14, 1.2, 6.8, GD, { r: 0.4, mat: 'metal' }), box(0, 74, -20.6, 6, 6, 0.8, GD, { r: 1, mat: 'metal' }));
          o.push(box(0, 0, 7, 50, 4.4, 20, GD, { r: 2, mat: 'metal' }), box(0, 4.4, 7, 46, 0.3, 16, '#2a3a40', { r: 1.6, mat: 'gloss', noOut: 1 }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('sink29e'), id = C.u('s86'), k = C.k;
        const nv = rep(5, () => { let d = `M${f1(R() * 50)} 0`; for (let y = 10; y <= 50; y += 10) d += `L${f1(R() * 50)} ${y}`; return `<path d="${d}" stroke="#e8e4dc" stroke-width="${f1(0.15 + R() * 0.2)}" fill="none" opacity="0.3"/>`; }).join('');
        const av = rep(5, () => { const y0 = R() * 40; let d = `M0 ${f1(y0)}`; for (let x = 10; x <= 40; x += 10) d += `Q${x - 5} ${f1(y0 + (R() - 0.5) * 10)} ${x} ${f1(y0 + (R() - 0.5) * 6)}`; return `<path d="${d}" stroke="#e0c08a" stroke-width="${f1(0.3 + R() * 0.6)}" fill="none" opacity="0.45"/>`; }).join('');
        const defs = `<defs><pattern id="s86n" width="50" height="50" patternUnits="userSpaceOnUse"><rect width="50" height="50" fill="${NM}"/>${nv}</pattern><pattern id="s86a" width="40" height="40" patternUnits="userSpaceOnUse"><rect width="40" height="40" fill="${AL}"/>${av}</pattern>`
          + `<linearGradient id="${id}w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.75"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/><animate attributeName="y1" values="-1;1" dur="0.8s" repeatCount="indefinite"/><animate attributeName="y2" values="0;2" dur="0.8s" repeatCount="indefinite"/></linearGradient>`
          + `<radialGradient id="${id}g"><stop offset="0" stop-color="#ffe8c0" stop-opacity="0.6"/><stop offset="1" stop-color="#ffe8c0" stop-opacity="0"/></radialGradient></defs>`;
        const gc = C.P([0, 48, -3]);
        const back = `<ellipse cx="${f1(gc[0])}" cy="${f1(gc[1])}" rx="${f1(40 * k)}" ry="${f1(22 * k)}" fill="url(#${id}g)">${an('opacity', '0.5;0.9;0.5', 8, 0, SPL(2))}</ellipse>`;
        const under = shadow(C, 0, 7, 28, 14, 0.3) + FL(C, 0.06, `<ellipse cx="0" cy="4" rx="34" ry="22" fill="url(#${id}g)" opacity="0.6"/>`);
        const inlay = vdot(C, [0, 0, 1]) > 0.1 ? PLN(C, [-28, 90, -20.98], [1, 0, 0], [0, -1, 0], `<rect width="56" height="0.5" fill="${GD}"/><rect width="56" height="0.15" fill="#fff0c0"/>`) + PLN(C, [-3, 80, -19.78], [1, 0, 0], [0, -1, 0], `<circle cx="3" cy="3" r="1.6" fill="none" stroke="#fff0c0" stroke-width="0.3">${an('opacity', '0.4;1;0.4', 3)}</circle><circle cx="3" cy="3" r="0.5" fill="#fff0c0"/>`) : '';
        const glow = `<g opacity="0.5">${an('opacity', '0.3;0.6;0.3', 8, 0, SPL(2))}` + FL(C, 56.2, `<ellipse cx="0" cy="-1.6" rx="18" ry="11" fill="#fff4dc" filter="url(#m12b1)"/>`) + '</g>';
        const w1 = sheet(C, [-5.6, 66, -14.2], [5.6, 66, -14.2], [-6, 56.2, -12.4], [6, 56.2, -12.4], id + 'w') + rip(C, [0, 56.2, -10], 1.8, 0, 1.4) + rip(C, [0, 56.2, -10], 1.8, 0.9, 1.4);
        const fv = vdot(C, [0, 0, 1]) > -0.1;
        const w2 = fv ? sheet(C, [-9, 56, 14.4], [9, 56, 14.4], [-9.6, 4.7, 15.6], [9.6, 4.7, 15.6], id + 'w', 0, 0.3) + rip(C, [0, 4.8, 13], 2.2, 0, 2) + rip(C, [0, 4.8, 13], 2.2, 1.1, 2) : '';
        const gl = vdot(C, [0, 0, 1]) > 0.1 ? `<path d="M${PP(C, [-25, 4.4, 17.02])}L${PP(C, [-21, 4.4, 17.02])}" stroke="#fff6d8" stroke-width="${f1(0.6 * k)}" stroke-linecap="round" opacity="0">${an('opacity', '0;0.9;0.9;0', 7, 0, KT('0;0.1;0.6;0.7'))}<animateTransform attributeName="transform" type="translate" values="0 0;${f1(C.P([25, 4.4, 17])[0] - C.P([-25, 4.4, 17])[0])} ${f1(C.P([25, 4.4, 17])[1] - C.P([-25, 4.4, 17])[1])}" dur="7s" repeatCount="indefinite"/></path>` : '';
        const fr = vdot(C, [0, 0, 1]) > -0.1;
        return { defs, back, under, front: inlay + (fr ? glow + w1 : '') + w2 + gl, bb: C.bb(4) }; };
      return D; };
  }

  // ======================= TUBS (Primary Tub BTH-015/035/055/075/095): real solids, nf = 0 every 5 deg =======================
  // 015/035/055 keep the 'tub' arch data: 172 x 90, act 'bath', inside [0, 14, 0], seats x +-36 h 14 kind 'bath'.
  // Oval tubs = N convex wall quads (sh 'poly', straight chords) round one convex N-gon water prism whose rings follow the walls' inner faces exactly,
  // so every pair touches along a plane (the old arcW quarters + water cylinder + floating bubble balls were the nf source).
  { const K = () => X.K, sol = o => X.K.solid(o);
    const { shadow, vis } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const TUB = o => Object.assign({ w: 172, d: 90, arch: 'tub', act: 'bath', inside: [0, 14, 0], seats: [{ x: -36, z: 0, h: 14, k: 'bath' }, { x: 36, z: 0, h: 14, k: 'bath' }] }, o);
    const sAt = (rings, y) => { for (let i = 1; i < rings.length; i++) if (y <= rings[i][0]) { const a = rings[i - 1], b = rings[i], t = (y - a[0]) / ((b[0] - a[0]) || 1); return a[2] + (b[2] - a[2]) * t; } return rings[rings.length - 1][2]; };
    // walls of an oval tub (A x B outer, th thick, N chords) + water (top wy, colour wc) filling the inside from the first ring up
    // oval tub: a solid lower body (outer N-gon) from the first ring up to the water line wy, with the water plate GLUED on its top (drawn right after it,
    // never sorted), then N convex wall quads from wy to the rim. The sort compares axis-aligned boxes, so nothing may sit inside a ring of walls:
    // a water volume inside the walls always cycled.
    const oval = (o, A, B, th, N, rings, col, mat, wy, wc, ex) => { const E = (a, b, t) => [a * Math.cos(t), b * Math.sin(t)], T = i => (i + 0.5) / N * 2 * PI;
      rings = rings.map(r => [r[0], 0, r[2]]);
      const lo = rings.filter(r => r[0] < wy).concat([[wy, 0, sAt(rings, wy)]]), hi = [[wy, 0, sAt(rings, wy)]].concat(rings.filter(r => r[0] > wy));
      const body = sol(Object.assign({ ax: 'y', sh: 'poly', c: [0, 0], pts: rep(N, i => E(A, B, T(i))), rings: lo, col, mat }, ex || {})); o.push(body);
      for (let i = 0; i < N; i++) { const t0 = T(i), t1 = T(i + 1); o.push(sol(Object.assign({ ax: 'y', sh: 'poly', c: [0, 0], pts: [E(A, B, t0), E(A, B, t1), E(A - th, B - th, t1), E(A - th, B - th, t0)], rings: hi, col, mat, noOut: 1 }, ex || {}))); }
      if (wc) { const sw = sAt(rings, wy), W = sol({ ax: 'y', sh: 'poly', c: [0, 0], pts: rep(N, i => E(A - th, B - th, T(i))), rings: [[wy, 0, sw], [wy + 0.12, 0, sw]], col: wc, mat: 'gloss', emit: 1, noOut: 1 }); W.par = body; o.push(W); }
      return { body }; };
    const xP = (x0, x1, z, y, r, col, mat) => sol({ ax: 'x', sh: 'el', c: [z, y], a: r, b: r, n: 12, rings: [[x0, 0], [x1, 0]], col, mat: mat || 'metal' });
    const rip = (C, p, T, b, s) => { const k = C.k * (s || 1); return `<g transform="translate(${PP(C, p)}) scale(1 0.4)">${[0, T / 2].map(d => `<circle r="0" fill="none" stroke="#ffffff" stroke-width="${f1(0.25 * C.k)}"><animate attributeName="r" values="0;${f1(5 * k)}" dur="${T}s" begin="${n4(-(b || 0) - d)}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.8;0" dur="${T}s" begin="${n4(-(b || 0) - d)}s" repeatCount="indefinite"/></circle>`).join('')}</g>`; };
    RD.H29T = { oval, sAt, rip };
    const dripTo = (C, p, y1, T) => { const a = C.P(p), w = C.P([p[0], y1, p[2]]), k = C.k, KQ = ` keyTimes="0;0.7;0.9;0.91;1" dur="${T}s" repeatCount="indefinite"`;
      return `<ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="${f1(0.55 * k)}" ry="${f1(0.7 * k)}" fill="#d8eaee"><animate attributeName="cy" values="${f1(a[1])};${f1(a[1] + 0.7 * k)};${f1(w[1])};${f1(a[1])};${f1(a[1])}"${KQ}/><animate attributeName="opacity" values="0.9;0.9;0.9;0;0.9"${KQ}/></ellipse>` + rip(C, [p[0], y1, p[2]], T, -0.9 * T, 1.2); };
    // little foam heaps (fx on the water, kept off the two seats)
    const foam = (C, y, L, sd) => { const R = rng(sd); return FL(C, y, L.map(([x, z, r]) => rep(7, () => { const a = R() * 2 * PI, d = R() * r; return `<circle cx="${f1(x + Math.cos(a) * d)}" cy="${f1(z + Math.sin(a) * d * 0.7)}" r="${f1(1.4 + R() * 2.2)}" fill="#ffffff" stroke="#d6eaf2" stroke-width="0.3" opacity="0.92"/>`; }).join('')).join('')); };
    const duck = (C, p, T) => { const q = C.P(p), k = C.k; return `<g transform="translate(${P2(q)}) scale(${n4(k)})"><g>${at('translate', '0 0;0 -0.8;0 0', T, 0, SPL(2))}<g>${at('rotate', '-6;6;-6', T * 1.3, 0, SPL(2))}<ellipse cx="0" cy="0.6" rx="5" ry="1.2" fill="#000000" opacity="0.12"/><path d="M-4.6 -1.2Q-4.6 -4.4 -0.6 -4.4Q2.4 -4.4 3.4 -2.4Q5 -1.8 4.4 -0.2Q2 1.2 -1.6 1Q-4.6 0.6 -4.6 -1.2Z" fill="#ffd23a" stroke="#d89a1a" stroke-width="0.25"/><circle cx="1.2" cy="-6.4" r="2.6" fill="#ffd23a" stroke="#d89a1a" stroke-width="0.25"/><path d="M3.4 -6.6L6 -6Q5.6 -5 3.4 -5.4Z" fill="#ff8a2a"/><circle cx="1.8" cy="-7" r="0.45" fill="#2a2a2a"/><circle cx="1.95" cy="-7.15" r="0.15" fill="#ffffff"/><path d="M-2.6 -2.4Q-1 -3.4 0.6 -2.4" stroke="#e8b020" stroke-width="0.4" fill="none"/></g></g></g>`; };
    Object.assign(RD.H29T, { duck, foam });

    // BTH-015 CHIPPED CAST-IRON CLAWFOOT TUB WITH RUST RING (T1): an old roll-top cast-iron tub on four rusty claw feet: tired cream enamel inside with a brown
    // rust ring at the waterline and a rust streak under the spout, the outside paint flaked off in patches down to black iron, chips along the rolled rim,
    // tarnished brass taps and spout, cloudy water and a rubber duck. Live: the spout drips (rings spread) and the duck bobs.
    N.tub29a = S => { const EN = '#efe6d2', EXT = '#d8d2c2', BRS = '#b8985a', RG = [[10, 0, 0.84], [16, 0, 0.93], [28, 0, 0.99], [37, 0, 1.01], [39.4, 0, 1.035], [40.6, 0, 1.02]];
      const D = TUB({ build: () => { const { cyl, ball } = K(), o = [];
          [[-56, -20], [56, -20], [-56, 20], [56, 20]].forEach(([x, z]) => o.push(ball(x, 0, z, 4, '#6a4a32', { k: 4, n: 12, sx: 1.25, mat: 'metal' })));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 0], a: 72, b: 37, n: 24, rings: [[8, 0, 0.98], [10, 0, 1]], col: '#3a3632', mat: 'metal' }));
          oval(o, 85, 44, 6, 24, RG, EXT, 'gloss', 30, '#b8cec8');
          o.push(cyl(-81, 40.9, 0, 1.8, 8.7, BRS, { n: 12, mat: 'metal' }), xP(-79.2, -70, 0, 48, 1.1, BRS), cyl(-70, 45.6, 0, 1.1, 1.2, BRS, { n: 10, mat: 'metal' }));
          [-6, 6].forEach((z, i) => o.push(cyl(-81, 40.9, z, 1, 3.1, BRS, { n: 10, mat: 'metal' }), ball(-81, 44, z, 1.7, i ? '#e8e0d0' : '#e8e0d0', { k: 4, n: 10 })));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('tub29a'), k = C.k, N = 24;
        const under = shadow(C, 0, 0, 80, 42, 0.45) + FL(C, 0.06, `<ellipse cx="-70" cy="0" rx="9" ry="5" fill="#a89878" opacity="0.25"/>`);
        // waterline rust ring (on the water edge) + streak under the spout + chips round the rim
        const wr = rep(48, i => { const t = i / 48 * 2 * PI; return `${i ? 'L' : 'M'}${f1(Math.cos(t) * 77.6)} ${f1(Math.sin(t) * 36.6)}`; }).join('') + 'Z';
        let top = FL(C, 30.06, `<path d="${wr}" fill="none" stroke="#9a6a34" stroke-width="2.4" opacity="0.45"/><path d="M-74 -3Q-66 0 -60 -1Q-66 3 -74 3Z" fill="#a8743a" opacity="0.5"/>`);
        top += FL(C, 40.66, rep(7, () => { const t = R() * 2 * PI, x = Math.cos(t) * 82.4, z = Math.sin(t) * 42.6; return `<ellipse cx="${f1(x)}" cy="${f1(z)}" rx="${f1(0.6 + R() * 0.9)}" ry="${f1(0.4 + R() * 0.5)}" fill="#3a3430" opacity="0.75"/>`; }).join(''));
        // flaked exterior paint: dark iron patches on the outer faces that face the viewer
        let ext = ''; rep(5, j => { const i = Math.floor(R() * N), t0 = (i + 0.5) / N * 2 * PI, t1 = (i + 1.5) / N * 2 * PI, s = 0.99, a = [85 * s * Math.cos(t0), 44 * s * Math.sin(t0)], b = [85 * s * Math.cos(t1), 44 * s * Math.sin(t1)], n = [b[1] - a[1], 0, -(b[0] - a[0])];
          if (vdot(C, n) / (Math.hypot(n[0], n[2]) || 1) < 0.15) return; const y = 16 + R() * 14, u = 0.2 + R() * 0.5, L = Math.hypot(b[0] - a[0], b[1] - a[1]), O = [a[0] + (b[0] - a[0]) * u, y, a[1] + (b[1] - a[1]) * u], U = [(b[0] - a[0]) / L, 0, (b[1] - a[1]) / L];
          ext += PLN(C, [O[0] + n[0] * 0.012, O[1], O[2] + n[2] * 0.012], U, [0, -1, 0], `<path d="M0 0q2 -1.6 4.4 -0.4q1.6 1.8 0.4 3.6q-2.6 1.2 -4.4 -0.4q-1 -1.4 -0.4 -2.8Z" fill="#2e2a26" opacity="0.85"/><path d="M0 0q2 -1.6 4.4 -0.4" stroke="#f4eee0" stroke-width="0.3" fill="none"/>`); });
        const front = top + ext + dripTo(C, [-70, 45.4, 0], 30.2, 3.8) + duck(C, [6, 30, 14], 3.4);
        return { under, front, bb: C.bb(4) }; };
      return D; };

    // BTH-035 STANDARD ACRYLIC ALCOVE SOAKING TUB (T2): a clean glossy white acrylic alcove tub with a tall front apron, wide ledges, a chrome wall-style spout
    // and overflow plate at the tap end, a soft grey bath pillow at the other, mounds of bubble foam, a rubber duck and a jar candle on the back ledge.
    // Live: the candle flickers, the foam slowly shimmers and the duck bobs.
    N.tub29b = S => { const AC = '#f6f7f6', CH = '#d8dde2';
      const D = TUB({ build: () => { const { box, cyl } = K(), o = [];
          o.push(box(0, 0, 0, 152, 6, 70, '#eceeee', { r: 3 }));
          o.push(box(0, 0, -40, 172, 40, 10, AC, { r: 2.4, mat: 'gloss' }), box(0, 0, 40, 172, 40, 10, AC, { r: 2.4, mat: 'gloss' }), box(-81, 0, 0, 10, 40, 70, AC, { r: 1, mat: 'gloss' }), box(81, 0, 0, 10, 40, 70, AC, { r: 1, mat: 'gloss' }));
          o.push(sol({ ax: 'y', sh: 'rr', c: [0, 0], a: 76, b: 35, r: 4, n: 4, rings: [[6, 0], [29, 0]], col: '#bfe6f0', mat: 'gloss', emit: 1, noOut: 1 }));
          o.push(cyl(-81, 40, -2, 2, 3, CH, { n: 12, mat: 'chrome' }), xP(-79, -71, -2, 41.6, 1.3, CH, 'chrome'), cyl(-81, 40, 10, 1.6, 2.4, CH, { n: 12, mat: 'chrome' }), cyl(-81, 40, -14, 1.6, 2.4, CH, { n: 12, mat: 'chrome' }));
          o.push(X.K.pillowY(81, 40, 0, 9, 6, 26, '#c8ccd0', { mat: 'fab' }));
          o.push(cyl(64, 40, -40, 3, 5.6, '#f2e6d0', { n: 14, mat: 'gloss', op: 0.85 }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('tub29b'), k = C.k;
        const under = shadow(C, 0, 0, 90, 48, 0.35);
        const ov = vdot(C, [1, 0, 0]) > 0.1 ? PLN(C, [-75.98, 26, -6], [0, 0, 1], [0, -1, 0], `<circle cx="4" cy="4" r="3" fill="${CH}" stroke="#8a9096" stroke-width="0.3"/><circle cx="4" cy="4" r="2" fill="none" stroke="#ffffff" stroke-width="0.25" opacity="0.7"/>`) : '';
        const fm = foam(C, 29.1, [[-62, -24, 10], [-58, 22, 9], [0, -26, 12], [58, -22, 9], [62, 24, 8], [-10, 26, 8]], 'tub29b') ;
        const shim = `<g>${an('opacity', '0.7;1;0.7', 5, 0, SPL(2))}${fm}</g>`;
        const fp = C.P([64, 46, -40]), fl = `<g transform="translate(${P2(fp)}) scale(${n4(k)})"><ellipse cy="-1" rx="2.6" ry="3.2" fill="#ffd27a" opacity="0.3" filter="url(#m12b1)"/><path d="M0 0.4C-0.7 -0.4 -0.6 -1.6 0 -2.8C0.6 -1.6 0.7 -0.4 0 0.4Z" fill="#ffb84a">${at('skewX', '-5;6;-3;4;-5', 2.4, 0, SPL(4))}</path></g>`;
        return { under, front: ov + shim + duck(C, [10, 29, 16], 3.6) + fl, bb: C.bb(4) }; };
      return D; };

    // BTH-055 FREESTANDING MATTE-WHITE EGG SOAKING TUB (T3): a seamless egg-shaped tub in matte white stone resin, thin-rimmed and wide at the shoulder,
    // on a recessed plinth; a tall matte black floor-standing tub filler with a hand shower at the head end; a teak bath bridge across the middle with a book,
    // a glass of iced tea and a tea-light; clear water. Live: the tea-light flickers, the hand shower sways on its hose and slow ripples cross the water.
    N.tub29c = S => { const WM = '#f2f0ec', BK = '#2a2a2c', TK = '#b07a46', RG = [[6, 0, 0.74], [12, 0, 0.87], [22, 0, 0.97], [33, 0, 1], [40, 0, 0.995], [41, 0, 0.98]];
      const D = TUB({ build: () => { const { box, cyl } = K(), o = [];
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 0], a: 56, b: 29, n: 24, rings: [[0, 0, 1], [6, 0, 1.02]], col: '#dcdad4', mat: 'matte' }));
          oval(o, 79, 42, 3.6, 28, RG, WM, 'matte', 31, '#c4e8f2');
          o.push(cyl(-83.4, 0, 22, 2.6, 1.2, BK, { n: 14, mat: 'matte' }), cyl(-83.4, 1.2, 22, 1.3, 50, BK, { n: 12, mat: 'matte' }), xP(-82.1, -72, 22, 50, 1, BK, 'matte'), cyl(-72, 46.4, 22, 1, 2.6, BK, { n: 10, mat: 'matte' }));
          o.push(box(0, 41.3, 0, 13, 1.6, 92, TK, { r: 0.6, mat: 'wood' }));
          o.push(box(0, 43.1, -10, 8, 1.6, 10, '#c84a3a', { r: 0.3 }), cyl(2, 43.1, 10, 1.6, 5.4, '#e8d098', { n: 14, mat: 'gloss', op: 0.75 }), cyl(-3, 43.1, 18, 1.6, 1.6, '#f4f2ee', { n: 12 }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('tub29c'), k = C.k;
        const under = shadow(C, 0, 0, 78, 40, 0.35);
        const r1 = rip(C, [-40, 31.1, -10], 6, 0, 3) + rip(C, [44, 31.1, 12], 7, 3, 3);
        const hp = [-83.4, 44, 23.4], hose = `<g>${at('rotate', `-4 ${PP(C, hp)};5 ${PP(C, hp)};-4 ${PP(C, hp)}`, 5, 0, SPL(2))}<path d="M${PP(C, [-83.4, 44, 23.4])}Q${PP(C, [-85, 30, 24])} ${PP(C, [-84.6, 20, 23.6])}" stroke="#3a3a3c" stroke-width="${f1(0.6 * k)}" fill="none"/></g>`;
        const tp = C.P([-3, 44.9, 18]), fl = `<g transform="translate(${P2(tp)}) scale(${n4(k)})"><ellipse cy="-1" rx="2.2" ry="2.8" fill="#ffd27a" opacity="0.35" filter="url(#m12b1)"/><path d="M0 0.3C-0.6 -0.3 -0.5 -1.3 0 -2.4C0.5 -1.3 0.6 -0.3 0 0.3Z" fill="#ffb84a">${at('skewX', '-5;6;-3;4;-5', 2.2, 0, SPL(4))}</path></g>`;
        const ice = FL(C, 48.6, `<circle cx="2" cy="10" r="1.3" fill="#c87a2a" opacity="0.6"/><rect x="1.2" y="9.2" width="1" height="1" fill="#ffffff" opacity="0.8"/><path d="M2.6 9.4L4.4 7.2" stroke="#e8e4dc" stroke-width="0.3"/>`);
        const book = FL(C, 44.74, `<rect x="-3.6" y="-14.6" width="7.2" height="9.2" fill="#c84a3a"/><path d="M0 -14.6V-5.4" stroke="#8a2a20" stroke-width="0.3"/><rect x="-2.6" y="-12.4" width="5.2" height="1" fill="#f4d8a8" opacity="0.8"/>`);
        return { under, front: r1 + hose + book + ice + fl, bb: C.bb(4) }; };
      return D; };
  }

  // ---- tubs batch 2: onsen tubs 075 / 095 (arch 'onsen' kept, 150 x 110, no act / seats as before). Square = axis-aligned boxes only, so the water
  // box sits beside every wall box on x or z (sorts cleanly).
  { const K = () => X.K, sol = o => X.K.solid(o);
    const { shadow, vis } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const ONS = o => Object.assign({ w: 150, d: 110, arch: 'onsen' }, o);
    const xP = (x0, x1, z, y, r, col, mat) => sol({ ax: 'x', sh: 'el', c: [z, y], a: r, b: r, n: 12, rings: [[x0, 0], [x1, 0]], col, mat: mat || 'metal' });
    const rip = (C, p, T, b, s) => { const k = C.k * (s || 1); return `<g transform="translate(${PP(C, p)}) scale(1 0.4)">${[0, T / 2].map(d => `<circle r="0" fill="none" stroke="#ffffff" stroke-width="${f1(0.25 * C.k)}"><animate attributeName="r" values="0;${f1(5 * k)}" dur="${T}s" begin="${n4(-(b || 0) - d)}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.8;0" dur="${T}s" begin="${n4(-(b || 0) - d)}s" repeatCount="indefinite"/></circle>`).join('')}</g>`; };
    const sheet = (C, a0, a1, b0, b1, gid, op) => { const d = 'M' + [a0, a1, b1, b0].map(p => P2(C.P(p))).join('L') + 'Z'; return `<path d="${d}" fill="#dceef4" opacity="${op || 0.5}"/><path d="${d}" fill="url(#${gid})"/>`; };
    const wgrad = id => `<linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.75"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/><animate attributeName="y1" values="-1;1" dur="0.7s" repeatCount="indefinite"/><animate attributeName="y2" values="0;2" dur="0.7s" repeatCount="indefinite"/></linearGradient>`;
    const steam = (C, pts, T) => pts.map(([x, y, z], i) => { const p = C.P([x, y, z]), k = C.k; return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(9 * k)}" ry="${f1(3.4 * k)}" fill="#ffffff" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.4;0', T, -i * T / pts.length)}<animateTransform attributeName="transform" type="translate" values="0 0;${f1((i % 2 ? 4 : -4) * k)} ${f1(-26 * k)}" dur="${T}s" begin="${n4(-i * T / pts.length)}s" repeatCount="indefinite"/></ellipse>`; }).join('');
    // outer-face decal on a box face (normal n), only when it faces the viewer; O = top-left corner, U along the face, drawn y-down
    const face = (C, n, O, U, svg) => vdot(C, n) > 0.08 ? PLN(C, [O[0] + n[0] * 0.02, O[1], O[2] + n[2] * 0.02], U, [0, -1, 0], svg) : '';

    // BTH-075 TRADITIONAL DEEP SQUARE HINOKI CYPRESS ONSEN TUB (T4): a deep square tub of pale golden hinoki boards (fine straight grain, board joints) bound
    // by two hammered copper bands, under a wide hinoki rim; a bamboo kakehi spout on a hinoki post pours hot spring water in at the back corner; a hinoki
    // oke bucket with a ladle on the rim, yuzu floating on the steaming water, river stones at the foot. Live: the spout pours, rings spread, yuzu bob and
    // steam curls rise.
    N.onsen29a = S => { const HN = '#e6c68c', HN2 = '#d8b57a', CU = '#b8703e';
      const D = ONS({ build: () => { const { box, cyl, ball } = K(), o = [];
          o.push(box(0, 0, -51, 150, 46, 8, HN, { r: 0.6, mat: 'wood' }), box(0, 0, 51, 150, 46, 8, HN, { r: 0.6, mat: 'wood' }), box(-71, 0, 0, 8, 46, 94, HN, { r: 0.6, mat: 'wood' }), box(71, 0, 0, 8, 46, 94, HN, { r: 0.6, mat: 'wood' }));
          o.push(box(0, 0, 0, 134, 4, 94, HN2, { r: 0.3, mat: 'wood' }), box(0, 4, 0, 134, 32, 94, '#a8d4cc', { r: 0.3, mat: 'gloss', emit: 1, noOut: 1 }));
          o.push(box(0, 46.2, -51.4, 153, 3, 9, HN2, { r: 0.6, mat: 'wood' }), box(0, 46.2, 51.4, 153, 3, 9, HN2, { r: 0.6, mat: 'wood' }), box(-71.4, 46.2, 0, 9, 3, 93.8, HN2, { r: 0.6, mat: 'wood' }), box(71.4, 46.2, 0, 9, 3, 93.8, HN2, { r: 0.6, mat: 'wood' }));
          o.push(box(62, 49.4, -51.4, 3.4, 18, 3.4, HN2, { r: 0.4, mat: 'wood' }), xP(42, 60.3, -51.4, 64.4, 1.7, '#a8a050', 'gloss'));
          o.push(cyl(-60, 49.4, 50.6, 4.6, 6.4, HN, { n: 18, mat: 'wood' }), xP(-55.4, -46, 50.6, 54.6, 0.5, HN2, 'wood'));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('onsen29a'), id = C.u('o75'), k = C.k;
        const joints = (L, H) => rep(Math.floor(L / 9), i => `<path d="M${f1(i * 9 + 9)} 0V${H}" stroke="#a8844e" stroke-width="0.25"/>`).join('') + rep(8, () => { const x = R() * L; return `<path d="M${f1(x)} 0L${f1(x + (R() - 0.5))} ${H}" stroke="#c8a46a" stroke-width="0.12" opacity="0.6"/>`; }).join('');
        const band = L => [12, 34].map(y => `<rect y="${y}" width="${L}" height="2.4" fill="${CU}"/><rect y="${y}" width="${L}" height="0.6" fill="#e8a878" opacity="0.8"/>` + rep(Math.floor(L / 3), i => `<circle cx="${f1(i * 3 + 1.5)}" cy="${f1(y + 1.4)}" r="0.4" fill="#8a4a24" opacity="0.5"/>`).join('')).join('');
        let fc = face(C, [0, 0, 1], [-75, 46, 55], [1, 0, 0], `<g>${joints(150, 46)}${band(150)}</g>`) + face(C, [0, 0, -1], [75, 46, -55], [-1, 0, 0], `<g>${joints(150, 46)}${band(150)}</g>`)
          + face(C, [1, 0, 0], [75, 46, 47], [0, 0, -1], `<g>${joints(94, 46)}${band(94)}</g>`) + face(C, [-1, 0, 0], [-75, 46, -47], [0, 0, 1], `<g>${joints(94, 46)}${band(94)}</g>`);
        const water = FL(C, 36.04, `<rect x="-67" y="-47" width="134" height="94" fill="url(#${id}w)">${an('opacity', '0.6;1;0.6', 6, 0, SPL(2))}</rect>`);
        const yuzu = [[-30, -14], [-8, 22], [20, -6], [40, 20], [-46, 10]].map(([x, z], i) => { const p = C.P([x, 36.4, z]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><g>${at('translate', `0 0;0 -0.5;0 0`, 3 + i * 0.4, -i, SPL(2))}<ellipse cy="0.6" rx="3" ry="0.9" fill="#000000" opacity="0.12"/><circle r="2.6" fill="#f2c430"/><circle cx="-0.8" cy="-0.9" r="0.8" fill="#fff2a0" opacity="0.8"/><path d="M0 -2.6l0.4 -0.7" stroke="#5a7a2a" stroke-width="0.4"/></g></g>`; }).join('');
        const pour = sheet(C, [41.6, 63.4, -51.8], [41.6, 63.4, -51], [42.4, 36.2, -51.8], [42.4, 36.2, -51], id + 's', 0.6) + rip(C, [42, 36.2, -46], 1.6, 0, 1.6) + rip(C, [42, 36.2, -46], 1.6, 0.8, 1.6);
        const st = steam(C, [[-40, 37, -20], [-10, 37, 10], [20, 37, -30], [45, 37, 15], [0, 37, -40], [-55, 37, 30]], 7);
        const under = shadow(C, 0, 0, 80, 60, 0.4);
        return { defs: `<defs>${wgrad(id + 's')}<radialGradient id="${id}w" cx="50%" cy="45%" r="60%"><stop offset="0" stop-color="#d8f2ea" stop-opacity="0.6"/><stop offset="1" stop-color="#a8d4cc" stop-opacity="0"/></radialGradient></defs>`, under, front: fc + water + yuzu + pour + st, bb: C.bb(4) }; };
      return D; };

    // BTH-095 INFINITY-EDGE OVERFLOWING THERMAL MINERAL POOL WITH WHIRLPOOL JETS (T5): a pool of honed warm travertine capped in polished gold, filled with
    // milky turquoise mineral water lit from below; the front edge is a knife-thin infinity lip where the water slides over in a glassy sheet into a gold-lined
    // catch channel; a gold slot spout in the back wall feeds a thin waterfall; three whirlpool jets swirl rings of bubbles; mineral sparkles and steam.
    N.onsen29b = S => { const TV = '#ddd0b6', GD = '#d6b06a', MW = '#9fd8d0';
      const D = ONS({ build: () => { const { box } = K(), o = [], TX = { tex: 'url(#o95t) none', mat: 'matte' };
          o.push(box(0, 0, -50, 150, 50, 10, TV, Object.assign({ r: 0.6 }, TX)), box(-70, 0, -0.5, 10, 46, 89, TV, Object.assign({ r: 0.6 }, TX)), box(70, 0, -0.5, 10, 46, 89, TV, Object.assign({ r: 0.6 }, TX)));
          o.push(box(0, 0, 41.5, 130, 37.6, 5, TV, Object.assign({ r: 0.3 }, TX)));
          o.push(box(0, 0, -3, 130, 4, 84, '#c8bca2', { r: 0.3, mat: 'matte' }), box(0, 4, -3, 130, 34, 84, MW, { r: 0.3, mat: 'gloss', emit: 1, noOut: 1 }));
          o.push(box(0, 50.2, -50, 151, 1.6, 10.6, GD, { r: 0.6, mat: 'metal' }), box(-70, 46.2, -0.5, 10.6, 1.6, 89, GD, { r: 0.6, mat: 'metal' }), box(70, 46.2, -0.5, 10.6, 1.6, 89, GD, { r: 0.6, mat: 'metal' }));
          o.push(box(0, 0, 49.6, 150, 9, 10.8, GD, { r: 0.8, mat: 'metal' }), box(0, 9, 49.6, 146, 0.3, 7.6, '#7ac8c4', { r: 0.6, mat: 'gloss', emit: 1, noOut: 1 }));
          o.push(box(0, 40.2, -43.6, 22, 1.4, 2.8, GD, { r: 0.4, mat: 'metal' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('onsen29b'), id = C.u('o95'), k = C.k;
        const veins = rep(5, () => { const y0 = R() * 40; let d = `M0 ${f1(y0)}`; for (let x = 10; x <= 40; x += 10) d += `L${x} ${f1(y0 + (R() - 0.5) * 3)}`; return `<path d="${d}" stroke="#c8b898" stroke-width="${f1(0.3 + R() * 0.5)}" fill="none" opacity="0.6"/>`; }).join('') + rep(18, () => `<ellipse cx="${f1(R() * 40)}" cy="${f1(R() * 40)}" rx="${f1(0.3 + R() * 0.8)}" ry="0.2" fill="#a8987a" opacity="0.6"/>`).join('');
        const glow = FL(C, 38.04, `<rect x="-65" y="-45" width="130" height="84" fill="url(#${id}g)">${an('opacity', '0.5;0.9;0.5', 8, 0, SPL(2))}</rect>`);
        const jets = [[-36, -14, 0], [8, 10, 1.2], [42, -18, 2.4]].map(([x, z, b]) => FL(C, 38.1, `<g transform="translate(${x} ${z})"><g>${at('rotate', '0;360', 4)}${[3, 6, 9].map((r, i) => `<circle r="${r}" fill="none" stroke="#ffffff" stroke-width="${0.5 - i * 0.1}" stroke-dasharray="${f1(0.6 + i * 0.3)} ${f1(1.4 + i)}" opacity="${f1(0.8 - i * 0.2)}"/>`).join('')}</g>${rep(8, j => { const a = j / 8 * 2 * PI; return `<circle cx="${f1(Math.cos(a) * 5)}" cy="${f1(Math.sin(a) * 5)}" r="0.7" fill="#ffffff" opacity="0">${an('opacity', '0;0.9;0', 1.6, -j * 0.2 - b)}</circle>`; }).join('')}</g>`)).join('');
        const sparks = rep(14, i => { const p = C.P([-60 + R() * 120, 38.2, -40 + R() * 76]); return `<path d="M${f1(p[0] - 1.2 * k)} ${f1(p[1])}H${f1(p[0] + 1.2 * k)}M${f1(p[0])} ${f1(p[1] - 0.8 * k)}V${f1(p[1] + 0.8 * k)}" stroke="#ffffff" stroke-width="${f1(0.22 * k)}" opacity="0">${an('opacity', '0;0;0.9;0', 4 + (i % 4), -i * 0.6, KT('0;0.7;0.8;1'))}</path>`; }).join('');
        const fv = vdot(C, [0, 0, 1]) > -0.05;
        const edge = fv ? sheet(C, [-65, 38, 44], [65, 38, 44], [-65, 9.3, 46], [65, 9.3, 46], id + 's', 0.32) : '';
        const lip = fv ? `<path d="M${PP(C, [-65, 38.05, 44])}L${PP(C, [65, 38.05, 44])}" stroke="#e8fbf8" stroke-width="${f1(0.5 * k)}" opacity="0.9"/>` : '';
        const fall = sheet(C, [-10, 40.2, -42.2], [10, 40.2, -42.2], [-10.6, 38.2, -40], [10.6, 38.2, -40], id + 's', 0.5) + rip(C, [0, 38.2, -38], 1.8, 0, 2.4) + rip(C, [0, 38.2, -38], 1.8, 0.9, 2.4);
        const st = steam(C, [[-40, 39, -20], [-10, 39, 10], [20, 39, -30], [45, 39, 15], [0, 39, -10]], 8);
        const under = shadow(C, 0, 0, 80, 60, 0.35);
        return { defs: `<defs><pattern id="o95t" width="40" height="40" patternUnits="userSpaceOnUse"><rect width="40" height="40" fill="${TV}"/>${veins}</pattern>${wgrad(id + 's')}<radialGradient id="${id}g" cx="50%" cy="50%" r="60%"><stop offset="0" stop-color="#f0fff8" stop-opacity="0.7"/><stop offset="0.6" stop-color="#bff0e4" stop-opacity="0.25"/><stop offset="1" stop-color="#ffd890" stop-opacity="0.2"/></radialGradient></defs>`, under, front: glow + jets + sparks + lip + edge + fall + st, bb: C.bb(4) }; };
      return D; };
  }

  // ======================= SHOWERS (Shower Fixture BTH-018/038/058/078/098): whole stalls like the generic 'shower' arch, 90 x 86, act 'wash'
  // (v6 turns it into 'shower'), use {0, 6, inside} + inside [0, 6, 0] kept; front left open so the creature inside shows (curtains / doors are the Entry &
  // Divider items). Walls are boxes (axis-separable): tray y 0..6, back wall z -43..-37, left wall x -45..-39; fx sprays draw over the bather on purpose.
  { const K = () => X.K, sol = o => X.K.solid(o);
    const { shadow, vis } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const SHW = o => Object.assign({ w: 90, d: 86, arch: 'shower', act: 'wash', use: { x: 0, z: 6, inside: 1 }, inside: [0, 6, 0] }, o);
    const zP = (z0, z1, x, y, r, col, mat) => sol({ ax: 'z', sh: 'el', c: [x, y], a: r, b: r, n: 12, rings: [[z0, 0], [z1, 0]], col, mat: mat || 'metal' });
    const xP = (x0, x1, z, y, r, col, mat) => sol({ ax: 'x', sh: 'el', c: [z, y], a: r, b: r, n: 12, rings: [[x0, 0], [x1, 0]], col, mat: mat || 'metal' });
    const face = (C, n, O, U, svg) => vdot(C, n) > 0.06 ? PLN(C, [O[0] + n[0] * 0.03, O[1], O[2] + n[2] * 0.03], U, [0, -1, 0], svg) : '';
    // everything drawn ON a wall is a thin solid GLUED to it (S.par): fx 'back' would sit under the wall and fx 'front' over the bather
    // each wall = outer slab + a thin inner skin; decals are glued to the skin, so from behind the outer slab (sorted after the skin) hides skin + decals
    const stall = (o, tray, wall, ex) => { const { box } = K(), wx = Object.assign({ r: 1 }, ex && ex.w), T = box(0, 0, 0, 90, 6, 86, tray, Object.assign({ r: 3, mat: 'gloss' }, ex && ex.t)),
        B = box(0, 6, -40.2, 90, 144, 5.6, wall, wx), Bs = box(0, 6, -37.2, 90, 144, 0.4, wall, Object.assign({}, wx, { r: 0.1, noOut: 1 })), L = box(-42.2, 6, 3, 5.6, 144, 80, wall, wx), Ls = box(-39.2, 6, 3, 0.4, 144, 80, wall, Object.assign({}, wx, { r: 0.1, noOut: 1 }));
      o.push(T, B, Bs, L, Ls); return { T, B: Bs, L: Ls }; };
    // wall decals are thin solids that sort on their own (they sit clear of the wall on z / x), so the wall hides them from behind
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const onB = (x, y, w, h, col, ex) => X.K.box(x, y, -36.85, w, h, 0.3, col, Object.assign({ r: 0.1, noOut: 1 }, ex || {}));
    const onL = (z, y, d, h, col, ex) => X.K.box(-38.85, y, z, 0.3, h, d, col, Object.assign({ r: 0.1, noOut: 1 }, ex || {}));
    // grout grid on the back (x -39..45) and left (z -37..43) faces from y0 to y1
    const grid = (o, W, tw, th, y0, y1, gc, rb) => { const b = [], l = [];
      for (let y = y0 + th; y < y1; y += th) { b.push(onB(3, y - 0.2, 84, 0.4, gc)); l.push(onL(3, y - 0.2, 80, 0.4, gc)); }
      for (let r = 0, y = y0; y < y1; r++, y += th) { const h = Math.min(th, y1 - y) - 0.4; for (let x = -39 + (rb && r % 2 ? tw / 2 : tw); x < 45; x += tw) b.push(onB(x, y + 0.2, 0.4, h, gc)); for (let z = -37 + (rb && r % 2 ? tw / 2 : tw); z < 43; z += tw) l.push(onL(z, y + 0.2, 0.4, h, gc)); }
      glue(o, W.B, b); glue(o, W.L, l); };
    const drainS = (o, W, x, z, col) => { const d = X.K.cyl(x, 6, z, 3.6, 0.15, col, { n: 16, mat: 'metal' }); d.par = W.T; o.push(d); };
    const seen = C => vdot(C, [0, 0, 1]) > -0.15 && vdot(C, [-1, 0, 0]) < 0.15;
    // tile grid decal (W x H, tile tw x th, grout g colour, running bond rb)
    const tiles = (W, H, tw, th, cols, gc, R, rb, extra) => { let s = `<rect width="${W}" height="${H}" fill="${gc}"/>`; for (let r = 0, y = 0; y < H; r++, y += th) for (let x = rb && r % 2 ? -tw / 2 : 0; x < W; x += tw) s += `<rect x="${f1(x + 0.25)}" y="${f1(y + 0.25)}" width="${f1(tw - 0.5)}" height="${f1(th - 0.5)}" rx="0.3" fill="${cols[(R() * cols.length) | 0]}"/><path d="M${f1(x + 0.6)} ${f1(y + th - 0.6)}V${f1(y + 0.6)}H${f1(x + tw - 0.6)}" stroke="#ffffff" stroke-width="0.2" fill="none" opacity="0.6"/>`;
      return `<clipPath id="${extra}"><rect width="${W}" height="${H}"/></clipPath><g clip-path="url(#${extra})">${s}</g>`; };
    // falling water streaks from a head (centre p, radius r) down to the tray (y 6.2)
    const rain = (C, p, r, n, T, op, sd) => { const R = rng(sd), k = C.k; return rep(n, i => { const a = R() * 2 * PI, d = Math.sqrt(R()) * r, x = p[0] + Math.cos(a) * d, z = p[2] + Math.sin(a) * d, t = C.P([x, p[1], z]), b = C.P([x, 6.2, z]), L = 8 * k, dl = n4(-R() * T);
      return `<path d="M${f1(t[0])} ${f1(t[1])}v${f1(L)}" stroke="#e4f2f8" stroke-width="${f1(0.35 * k)}" stroke-linecap="round" opacity="${op}"><animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(b[1] - t[1] - L)}" dur="${T}s" begin="${dl}s" repeatCount="indefinite"/></path>`; }).join(''); };
    const drain = (C, x, z, col) => FL(C, 6.05, `<g transform="translate(${x} ${z})"><circle r="4" fill="${col}"/><circle r="4" fill="none" stroke="#6a7076" stroke-width="0.3"/>${rep(6, i => `<path d="M${f1(Math.cos(i / 6 * PI * 2) * 1)} ${f1(Math.sin(i / 6 * PI * 2) * 1)}L${f1(Math.cos(i / 6 * PI * 2) * 3.2)} ${f1(Math.sin(i / 6 * PI * 2) * 3.2)}" stroke="#4a4e52" stroke-width="0.5"/>`).join('')}</g>`);

    // BTH-018 LOW-PRESSURE DRIPPING CHROME SHOWERHEAD (T1): a dingy stall: grey 4in tiles with darkened grout and mildew creeping up from the floor, a cracked
    // acrylic tray with a rusty drain, an exposed chrome riser with a crusty old showerhead that only dribbles, two worn cross handles, a sagging wire soap rack
    // with a soap sliver, a peeling 'shower' sticker. Live: weak sputtering drips fall in uneven bursts.
    N.shw29a = S => { const CH = '#c8ccd0';
      const D = SHW({ build: () => { const { box, cyl } = K(), o = [], W = stall(o, '#ece8de', '#c8c6be', { w: { tex: 'url(#s18m) none' } });
          grid(o, W, 6, 6, 6, 150, '#7e7c72', 0);
          glue(o, W.B, [onB(10, 40, 9, 5, '#f2e8c8'), onB(10, 42, 6, 1, '#4a7ab0')]);
          { const cr = box(-6, 6, 22, 18, 0.15, 0.5, '#8a8478', { r: 0, noOut: 1 }); cr.par = W.T; o.push(cr); } drainS(o, W, 6, 8, '#9a8a70');
          o.push(cyl(-20, 6.2, -35.6, 1.4, 111, CH, { n: 10, mat: 'chrome' }), zP(-34.2, -27, -20, 118.6, 1.2, CH, 'chrome'), sol({ ax: 'z', sh: 'el', c: [-20, 117.4], a: 5, b: 5, n: 16, rings: [[-27, 0, 0.5], [-24, 0, 1], [-23.4, 0, 0.95]], col: '#b8bcc0', mat: 'chrome' }));
          [-27, -8].forEach(x => o.push(zP(-36.7, -34, x, 66, 1.6, CH, 'chrome'), box(x, 65.4, -33.4, 5, 1.2, 0.8, '#e8e4dc', { r: 0.4 })));
          o.push(box(18, 70, -34.5, 16, 0.8, 5, '#b8bcc0', { r: 0.3, mat: 'metal' }), box(14, 71, -34.5, 4, 1, 2.6, '#e6dca8', { r: 0.8 }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('shw29a'), k = C.k;
        const burst = rain(C, [-20, 116.6, -23.6], 2.4, 9, 1.4, 0.8, 's18r');
        const drips = `<g opacity="0">${an('opacity', '0;1;1;0;0;1;0;0', 6, 0, KT('0;0.05;0.25;0.3;0.55;0.6;0.7;1'))}${burst}</g>`;
        const drips2 = seen(C) ? drips : '';
        return { defs: `<defs><linearGradient id="s18m" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#2e3424" stop-opacity="0.45"/><stop offset="0.25" stop-color="#2e3424" stop-opacity="0"/><stop offset="0.9" stop-color="#ffffff" stop-opacity="0"/><stop offset="1" stop-color="#5a5a48" stop-opacity="0.2"/></linearGradient></defs>`, under: shadow(C, 0, 0, 48, 46, 0.3), front: drips2, bb: C.bb(4) }; };
      return D; };

    // BTH-038 HANDHELD DUAL-SPRAY CHROME SHOWER WAND (T2): a clean stall in white subway tile with a mint band, a white tray, a chrome slide bar with the
    // handheld wand on its silver hose, a chrome mixer, a two-shelf chrome corner caddy with pastel bottles and a lilac pouf.
    // Live: the wand sprays in a gentle stream, then switches to its wide ring spray.
    N.shw29b = S => { const CH = '#d8dde2';
      const D = SHW({ build: () => { const { box, cyl, ball } = K(), o = [], W = stall(o, '#f6f6f4', '#f8f8f6');
          grid(o, W, 8, 4, 6, 150, '#dfe2de', 1);
          glue(o, W.B, [onB(3, 70, 84, 4, '#a8dcc8')]); glue(o, W.L, [onL(3, 70, 80, 4, '#a8dcc8')]); drainS(o, W, 6, 8, CH);
          o.push(zP(-36.7, -35.4, 18, 40, 1.6, CH, 'chrome'), zP(-36.7, -35.4, 18, 120, 1.6, CH, 'chrome'), cyl(18, 40, -34, 0.9, 80, CH, { n: 10, mat: 'chrome' }));
          o.push(box(18, 98, -31.4, 4, 4, 2.4, CH, { r: 1, mat: 'chrome' }), sol({ ax: 'y', sh: 'el', c: [18, -28.6], a: 1.1, b: 1.1, n: 10, rings: [[89, 0], [101, 0]], col: CH, mat: 'chrome' }), sol({ ax: 'z', sh: 'el', c: [18, 104], a: 4.4, b: 4.4, n: 18, rings: [[-30.4, 0, 0.6], [-28.6, 0, 1], [-27.4, 0, 0.98]], col: CH, mat: 'chrome' }));
          o.push(zP(-36.7, -34, 0, 64, 2.4, CH, 'chrome'), box(0, 64, -32, 1.4, 1.4, 4, CH, { r: 0.6 }));
          o.push(box(-33, 56, -31.2, 6, 0.8, 6, CH, { r: 0.6, mat: 'chrome' }), box(-33, 80, -31.2, 6, 0.8, 6, CH, { r: 0.6, mat: 'chrome' }));
          [[-34.6, '#f6b8c8', 7], [-31.6, '#a8dcc8', 6]].forEach(([x, c, h]) => o.push(cyl(x, 56.9, -31.2, 1.3, h, c, { n: 12, mat: 'gloss' })));
          o.push(ball(-33, 80.9, -31.2, 2.6, '#c8a8e8', { k: 4, n: 12, mat: 'fab' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), k = C.k;
        const hose = `<path d="M${PP(C, [18, 89, -28.6])}C${PP(C, [22, 70, -22])} ${PP(C, [10, 58, -22])} ${PP(C, [0, 62, -30])}" stroke="#b8bec4" stroke-width="${f1(0.9 * k)}" fill="none"/>`;
        const sprayC = `<g opacity="0">${an('opacity', '0;1;1;0;0', 8, 0, KT('0;0.05;0.45;0.5;1'))}${rain(C, [18, 101.6, -18], 3, 10, 1.2, 0.75, 's38a')}</g>`;
        const sprayR = `<g opacity="0">${an('opacity', '0;0;1;1;0', 8, 0, KT('0;0.5;0.55;0.95;1'))}${rain(C, [18, 101.6, -14], 9, 18, 1.3, 0.6, 's38b')}</g>`;
        return { under: shadow(C, 0, 0, 48, 46, 0.25), front: seen(C) ? hose + sprayC + sprayR : '', bb: C.bb(4) }; };
      return D; };

    // BTH-058 BRUSHED BRASS RAINFALL OVERHEAD SHOWER COLUMN (T3): warm grey microcement walls with a lit recessed niche (amber bottles + a candle), a slate
    // tray under an oiled teak duckboard; an exposed brushed-brass column: riser, mixing valve with two knurled handles, a long arm to a big round rain head,
    // and a handheld on a brass cradle. Live: soft rain falls from the head in waves and the niche candle flickers.
    N.shw29c = S => { const BR = '#c9a256', MC = '#bdb6ac', TK = '#b07a46';
      const D = SHW({ build: () => { const { box, cyl } = K(), o = [], W = stall(o, '#4a4c4e', MC, { t: { mat: 'matte' }, w: { mat: 'matte', tex: 'url(#s58m) none' } });
          glue(o, W.B, [onB(32, 52, 20, 16, '#4a3e34'), onB(32, 67.4, 20, 0.6, '#ffd890', { emit: 1 }), onB(25.5, 52.2, 3, 9, '#c87a2a'), onB(29.5, 52.2, 3, 7, '#a8641e'), onB(37, 52.2, 4, 5, '#f2ead8')]);
          for (let i = 0; i < 9; i++) o.push(box(-2 + (i - 4) * 8.4, 6.3, 6, 7, 1.6, 64, TK, { r: 0.4, mat: 'wood' }));
          o.push(cyl(16, 6.2, -34, 1.6, 120, BR, { n: 12, mat: 'brush' }), box(16, 58, -31.4, 7, 7, 3.2, BR, { r: 1.4, mat: 'brush' }), xP(19.5, 23, -31.4, 61.5, 1.6, BR, 'brush'), xP(9, 12.5, -31.4, 61.5, 1.6, BR, 'brush'));
          o.push(zP(-32.4, -4, 16, 128.4, 1.2, BR, 'brush'), cyl(16, 124.6, -4, 1.4, 2.6, BR, { n: 12, mat: 'brush' }), sol({ ax: 'y', sh: 'el', c: [16, -4], a: 11, b: 11, n: 28, rings: [[121.8, 0, 0.9], [122.6, 0, 1], [124.4, 0, 1]], col: BR, mat: 'brush' }));
          o.push(box(-14, 90, -35.2, 6, 3, 3.6, BR, { r: 1, mat: 'brush' }), sol({ ax: 'y', sh: 'el', c: [-14, -33.4], a: 1.2, b: 1.2, n: 10, rings: [[93.2, 0], [104, 0]], col: BR, mat: 'brush' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), k = C.k;
        const r1 = `<g>${an('opacity', '0.6;1;0.6', 5, 0, SPL(2))}${rain(C, [16, 121.6, -4], 9.5, 34, 1.5, 0.55, 's58r')}</g>`;
        const fp = C.P([37, 57.6, -36.6]), fl = vdot(C, [0, 0, 1]) > 0.1 ? `<g transform="translate(${P2(fp)}) scale(${n4(k)})"><ellipse cy="-1" rx="2.4" ry="3" fill="#ffd27a" opacity="0.35" filter="url(#m12b1)"/><path d="M0 0.3C-0.6 -0.3 -0.5 -1.3 0 -2.4C0.5 -1.3 0.6 -0.3 0 0.3Z" fill="#ffb84a">${at('skewX', '-5;6;-3;4;-5', 2.2, 0, SPL(4))}</path></g>` : '';
        return { defs: `<defs><linearGradient id="s58m" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/><stop offset="0.5" stop-color="#8a8070" stop-opacity="0.08"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.06"/></linearGradient></defs>`, under: shadow(C, 0, 0, 48, 46, 0.3), front: seen(C) ? fl + r1 : '', bb: C.bb(4) }; };
      return D; };
  }

  // ---- showers batch 2 (078 / 098)
  { const K = () => X.K, sol = o => X.K.solid(o);
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const SHW = o => Object.assign({ w: 90, d: 86, arch: 'shower', act: 'wash', use: { x: 0, z: 6, inside: 1 }, inside: [0, 6, 0] }, o);
    const zP = (z0, z1, x, y, r, col, mat) => sol({ ax: 'z', sh: 'el', c: [x, y], a: r, b: r, n: 12, rings: [[z0, 0], [z1, 0]], col, mat: mat || 'metal' });
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const onB = (x, y, w, h, col, ex) => X.K.box(x, y, -36.85, w, h, 0.3, col, Object.assign({ r: 0.1, noOut: 1 }, ex || {}));
    const seen = C => vdot(C, [0, 0, 1]) > -0.15 && vdot(C, [-1, 0, 0]) < 0.15;
    const wgrad = id => `<linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset="0.5" stop-color="#ffffff" stop-opacity="0.75"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/><animate attributeName="y1" values="-1;1" dur="0.7s" repeatCount="indefinite"/><animate attributeName="y2" values="0;2" dur="0.7s" repeatCount="indefinite"/></linearGradient>`;
    const sheet = (C, a0, a1, b0, b1, gid, op) => { const d = 'M' + [a0, a1, b1, b0].map(p => P2(C.P(p))).join('L') + 'Z'; return `<path d="${d}" fill="#dceef4" opacity="${op || 0.5}"/><path d="${d}" fill="url(#${gid})"/>`; };

    // BTH-078 THERMOSTATIC 6-JET BODY-SPRAY & WATERFALL SHOWER PANEL (T4): Calacatta marble walls with soft grey-gold veins and a brushed-gold base trim, a
    // white marble tray with a gold linear drain, a glass side screen with a slim gold profile; on the back wall a tall smoked-glass shower panel framed in
    // champagne gold with six round gold body jets, a warm thermostat display (38.0°) and a gold blade waterfall spout at the top. Live: the jets fire soft
    // mist in turns, the waterfall pours, the display breathes and steam drifts up.
    N.shw29d = S => { const MB = '#f4f1ec', CG = '#d6b878', JT = [[-12, 92], [12, 92], [-12, 72], [12, 72], [-12, 52], [12, 52]];
      const D = SHW({ build: () => { const { box, cyl } = K(), o = [], WX = { mat: 'gloss', tex: 'url(#s78v) none' };
          const T = box(0, 0, 0, 90, 6, 86, '#f6f4f0', { r: 3, mat: 'gloss' }), B = box(0, 6, -40.2, 90, 144, 5.6, MB, Object.assign({ r: 1 }, WX)), Bs = box(0, 6, -37.2, 90, 144, 0.4, MB, Object.assign({ r: 0.1, noOut: 1 }, WX)), L = box(-42.2, 6, 3, 5.6, 144, 80, MB, Object.assign({ r: 1 }, WX)), Ls = box(-39.2, 6, 3, 0.4, 144, 80, MB, Object.assign({ r: 0.1, noOut: 1 }, WX));
          o.push(T, B, Bs, L, Ls);
          glue(o, T, [box(0, 6, 36, 60, 0.2, 3, CG, { r: 0.4, mat: 'metal' })]);
          glue(o, Bs, [onB(3, 6, 84, 3, CG, { mat: 'metal' }), onB(0, 34, 34, 86, CG, { mat: 'metal' }), onB(0, 35.4, 31, 83.2, '#2a2826', { mat: 'gloss' }), onB(0, 104, 14, 7, '#141210', { mat: 'gloss' }), onB(0, 108.4, 10, 1.6, '#ffc870', { emit: 1 }), onB(-3, 105.2, 2, 2, '#ffc870', { emit: 1 }), onB(3, 105.2, 2, 2, CG, { mat: 'metal' })]);
          glue(o, Ls, [X.K.box(-38.85, 6, 3, 0.3, 3, 80, CG, { r: 0.1, noOut: 1, mat: 'metal' })]);
          JT.forEach(([x, y]) => o.push(zP(-36.5, -35.2, x, y, 2.4, CG, 'metal')));
          o.push(box(0, 116, -32.4, 18, 1.4, 8, CG, { r: 0.6, mat: 'metal' }));
          o.push(box(44, 6.2, -12, 1.4, 136, 50, '#dff0f2', { r: 0.4, mat: 'gloss', op: 0.25, noOut: 1 }), box(44, 142.2, -12, 1.8, 1.6, 50.4, CG, { r: 0.4, mat: 'metal' }), box(44, 6.2, 13.6, 1.8, 136, 1.2, CG, { r: 0.3, mat: 'metal' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('shw29d'), id = C.u('s78'), k = C.k;
        const veins = rep(3, i => { const x0 = 8 + i * 20 + R() * 8; let d = `M${f1(x0)} 0`; for (let y = 30; y <= 90; y += 30) d += `Q${f1(x0 + (R() - 0.5) * 10)} ${y - 15} ${f1(x0 + (R() - 0.5) * 8)} ${y}`; return `<path d="${d}" stroke="${i === 1 ? '#d0b070' : '#c4c0b8'}" stroke-width="${f1(0.3 + R() * 0.4)}" fill="none" opacity="0.4"/>`; }).join('');
        const sp = (x, y, i) => { const a = C.P([x, y, -35]), b = C.P([x, y - 6, -12]), k2 = k; return `<g opacity="0">${an('opacity', '0;0.9;0.9;0;0', 6, -i, KT('0;0.05;0.35;0.4;1'))}${rep(5, j => { const dy = (j - 2) * 1.6 * k2; return `<path d="M${f1(a[0])} ${f1(a[1] + dy * 0.3)}L${f1(b[0])} ${f1(b[1] + dy)}" stroke="#eef8fc" stroke-width="${f1(0.4 * k2)}" stroke-dasharray="${f1(1.4 * k2)} ${f1(1.6 * k2)}" opacity="0.7"><animate attributeName="stroke-dashoffset" values="${f1(3 * k2)};0" dur="0.3s" repeatCount="indefinite"/></path>`; }).join('')}</g>`; };
        const jets = JT.map(([x, y], i) => sp(x, y, i)).join('');
        const fall = sheet(C, [-8, 116, -28.4], [8, 116, -28.4], [-8.6, 6.4, -24], [8.6, 6.4, -24], id + 'w', 0.4);
        const steam = rep(4, i => { const p = C.P([-20 + i * 14, 40, -10 + (i % 2) * 10]); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(12 * k)}" ry="${f1(5 * k)}" fill="#ffffff" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.35;0', 9, -i * 2.2)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-60 * k)}" dur="9s" begin="${-i * 2.2}s" repeatCount="indefinite"/></ellipse>`; }).join('');
        const disp = vdot(C, [0, 0, 1]) > 0.1 ? PLN(C, [-6, 111, -36.66], [1, 0, 0], [0, -1, 0], `<text x="6" y="4.6" text-anchor="middle" font-family="Arial,sans-serif" font-size="3.2" fill="#ffd08a">38.0°<animate attributeName="opacity" values="0.7;1;0.7" dur="4s" repeatCount="indefinite"/></text>`) : '';
        return { defs: `<defs><pattern id="s78v" width="60" height="90" patternUnits="userSpaceOnUse"><rect width="60" height="90" fill="${MB}"/>${veins}</pattern>${wgrad(id + 'w')}</defs>`, under: shadow(C, 0, 0, 48, 46, 0.3), front: disp + (seen(C) ? jets + fall + steam : ''), bb: C.bb(4) }; };
      return D; };

    // BTH-098 360-DEGREE SONIC MIST & VITAMIN-INFUSED HYDRO-CAPSULE (T5): a round walk-in pod: a polished gold plinth with a black-glass floor ring and a softly
    // lit control strip, a curved wall of clear glass faintly tinted champagne, crowned by a pearl-white and gold dome with a ring of mist nozzles. Live: warm
    // citrus 'vitamin' mist swirls round inside, sonic rings travel up and down the glass, droplets sparkle and the plinth light breathes.
    N.shw29e = S => { const GD = '#d6b06a', N2 = 24, A = 41, B = 40, th = 1.2;
      const D = SHW({ build: () => { const { cyl } = K(), o = [];
          o.push(cyl(0, 0, 0, A + 2, 5, GD, { rz: B + 2, n: 36, mat: 'metal' }), cyl(0, 5, 0, A + 1.2, 1, '#ece6da', { rz: B + 1.2, n: 36, mat: 'gloss' }));
          const E = (a, b, t) => [a * Math.cos(t), b * Math.sin(t)], T = i => (i + 0.5) / N2 * 2 * PI;
          for (let i = 0; i < N2; i++) { const t0 = T(i), t1 = T(i + 1); o.push(sol({ ax: 'y', sh: 'poly', c: [0, 0], pts: [E(A, B, t0), E(A, B, t1), E(A - th, B - th, t1), E(A - th, B - th, t0)], rings: [[6.2, 0], [128, 0]], col: '#f2ead8', mat: 'gloss', op: 0.16, noOut: 1 })); }
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 0], a: A + 1.6, b: B + 1.6, n: 36, rings: [[128.2, 0, 1], [131, 0, 1], [131.6, 0, 0.98]], col: GD, mat: 'metal' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 0], a: A + 1.2, b: B + 1.2, n: 36, rings: [[131.6, 0, 0.98], [136, 0, 0.9], [140, 0, 0.72], [143, 0, 0.44], [144.4, 0, 0.15]], col: '#f6f2ea', mat: 'gloss' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 0], a: 4, b: 4, n: 16, rings: [[144.4, 0, 1], [146.4, 0, 0.8], [147.4, 0, 0.3]], col: GD, mat: 'metal' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('shw29e'), id = C.u('s98'), k = C.k;
        const under = shadow(C, 0, 0, 50, 48, 0.3) + FL(C, 0.05, `<ellipse rx="56" ry="54" fill="url(#${id}g)">${an('opacity', '0.4;0.8;0.4', 5, 0, SPL(2))}</ellipse>`);
        const strip = vdot(C, [0, 0, 1]) > 0.2 ? PLN(C, [-10, 4, B + 2.02], [1, 0, 0], [0, -1, 0], `<rect width="20" height="1.6" rx="0.8" fill="#fff0c8">${an('opacity', '0.5;1;0.5', 3)}</rect>`) : '';
        // sonic rings: ellipses travelling up and down the glass
        const ring = (y0, y1, T, b) => { const a0 = C.P([0, y0, 0]), a1 = C.P([0, y1, 0]), rx = A * C.k, ry = Math.abs(C.P([0, y0, B])[1] - a0[1]);
          return `<ellipse cx="${f1(a0[0])}" cy="${f1(a0[1])}" rx="${f1(rx)}" ry="${f1(ry)}" fill="none" stroke="#ffd8a0" stroke-width="${f1(0.6 * k)}" opacity="0"><animate attributeName="cy" values="${f1(a0[1])};${f1(a1[1])};${f1(a0[1])}" dur="${T}s" begin="${n4(-b)}s" repeatCount="indefinite" calcMode="spline" keySplines="0.45 0 0.55 1;0.45 0 0.55 1"/>${an('opacity', '0;0.8;0;0.8;0', T, -b)}</ellipse>`; };
        const sonic = ring(14, 120, 7, 0) + ring(14, 120, 7, 3.5);
        const mist = rep(7, i => { const t = i / 7 * 2 * PI, y = 30 + (i % 3) * 30, p = C.P([Math.cos(t) * 26, y, Math.sin(t) * 24]); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(14 * k)}" ry="${f1(7 * k)}" fill="#ffd8a8" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.32;0', 8, -i * 1.1)}<animateTransform attributeName="transform" type="translate" values="0 0;${f1((i % 2 ? 10 : -10) * k)} ${f1(-18 * k)}" dur="8s" begin="${n4(-i * 1.1)}s" repeatCount="indefinite"/></ellipse>`; }).join('');
        const nz = rep(10, i => { const t = i / 10 * 2 * PI, p = C.P([Math.cos(t) * 34, 128, Math.sin(t) * 33]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.8 * k)}" fill="#fff0c8" opacity="0.4">${an('opacity', '0.2;0.9;0.2', 2, -i * 0.2)}</circle>`; }).join('');
        const drops = rep(16, i => { const t = R() * 2 * PI, rr = R() * 30, p = C.P([Math.cos(t) * rr, 20 + R() * 100, Math.sin(t) * rr]); return `<path d="M${f1(p[0] - 1 * k)} ${f1(p[1])}H${f1(p[0] + 1 * k)}M${f1(p[0])} ${f1(p[1] - 0.7 * k)}V${f1(p[1] + 0.7 * k)}" stroke="#fff6e0" stroke-width="${f1(0.22 * k)}" opacity="0">${an('opacity', '0;0;0.9;0', 3 + (i % 3), -i * 0.4, KT('0;0.7;0.8;1'))}</path>`; }).join('');
        const sheen = `<path d="M${PP(C, [-28, 120, 30])}L${PP(C, [-28, 12, 30])}" stroke="#ffffff" stroke-width="${f1(2 * k)}" opacity="0.18"/><path d="M${PP(C, [-22, 120, 34])}L${PP(C, [-22, 12, 34])}" stroke="#ffffff" stroke-width="${f1(0.6 * k)}" opacity="0.25"/>`;
        return { defs: `<defs><radialGradient id="${id}g"><stop offset="0.6" stop-color="#ffd890" stop-opacity="0.45"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient></defs>`, under, front: strip + mist + sonic + nz + drops + sheen, bb: C.bb(4) }; };
      return D; };
  }

  // ======================= TOWEL & ROBE STORAGE (BTH-003/023/043/063/083): floor pieces as before (arch 'rack' 74 x 30 / 'washer' / 'wardrobe' kept) =======================
  // (the Entry & Divider rows BTH-012..092 are removed from the catalog in reno-plus.js, so they are skipped)
  { const K = () => X.K, sol = o => X.K.solid(o), CH = '#d8dde2';
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const xP = (x0, x1, z, y, r, col, mat) => sol({ ax: 'x', sh: 'el', c: [z, y], a: r, b: r, n: 12, rings: [[x0, 0], [x1, 0]], col, mat: mat || 'metal' });
    const RACK = o => Object.assign({ w: 74, d: 30, arch: 'rack' }, o);
    // a towel folded over a bar at (y, z): front + back panels (thin soft slabs hanging x0..x1 down to y - L / y - Lb) and a top fold; stripes glued to the front
    const towel = (o, x0, x1, y, z, L, Lb, col, br, stripes) => { const { box } = K(), w = x1 - x0, cx = (x0 + x1) / 2;
      const F = box(cx, y - L, z + 1.7, w, L, 1, col, { r: 0.6, mat: 'fab', soft: 1 }), Bk = box(cx, y - Lb, z - 1.7, w, Lb, 1, shade(col, 0.92), { r: 0.6, mat: 'fab', soft: 1 }), T = box(cx, y + br, z, w, 1.2, 4.4, shade(col, 1.04), { r: 0.6, mat: 'fab', soft: 1 });
      o.push(F, Bk, T); if (stripes) glue(o, F, stripes.map(([dy, h, c]) => box(cx, y - L + dy, z + 2.25, w, h, 0.1, c, { r: 0, noOut: 1, mat: 'fab' }))); return F; };

    // BTH-003 LOOSE METAL WALL HOOK (T1, floor piece as before): a cheap chrome-plated hook rail on a thin pole stand with a dented base, flaking to rust: a
    // damp grey threadbare towel with a frayed hem on one hook, a pink shower cap on another, and the middle hook hanging loose by one screw. Live: the loose
    // hook swings and rattles, and the damp towel drips into a little puddle.
    N.rack29a = S => { const ST = '#a8acb0';
      const D = RACK({ build: () => { const { box, cyl, ball } = K(), o = [];
          o.push(cyl(0, 0, 0, 12, 1.8, '#8a8e92', { n: 20, mat: 'metal' }), cyl(0, 1.8, 0, 1.2, 81.2, ST, { n: 10, mat: 'metal' }), xP(-20, 20, 0, 84, 1, ST));
          [-12, 12].forEach(x => o.push(cyl(x, 79, 0, 0.5, 4, ST, { n: 8, mat: 'metal' }), ball(x, 77.6, 0, 0.7, ST, { k: 3, n: 8 })));
          towel(o, -21, -4, 75, 0, 30, 24, '#a8aaa4', 1, [[1.4, 1.2, '#8a8c86'], [4, 0.6, '#8a8c86']]);
          o.push(ball(12, 70, 0, 4.6, '#f2b0c4', { sy: 0.7, k: 4, n: 14, mat: 'gloss' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('rack29a'), k = C.k;
        const hp = C.P([0, 83, 0]), hook = `<g>${at('rotate', `-14 ${P2(hp)};18 ${P2(hp)};-6 ${P2(hp)};12 ${P2(hp)};-14 ${P2(hp)}`, 3.2, 0, SPL(4))}<path d="M${P2(hp)}l0 ${f1(6 * k)}q0 ${f1(2.4 * k)} ${f1(2 * k)} ${f1(2.4 * k)}q${f1(2 * k)} 0 ${f1(2 * k)} ${f1(-2 * k)}" stroke="#a8acb0" stroke-width="${f1(1 * k)}" fill="none" stroke-linecap="round"/><path d="M${P2(hp)}l0 ${f1(6 * k)}" stroke="#7a5a3a" stroke-width="${f1(0.5 * k)}" opacity="0.6"/></g>`;
        const rust = vdot(C, [0, 0, 1]) > 0.1 ? [[0, 30], [0, 52], [0, 70]].map(([x, y]) => PLN(C, [x - 1, y, 1.25], [1, 0, 0], [0, -1, 0], `<ellipse cx="1" cy="0" rx="0.9" ry="1.6" fill="#9a5a2a" opacity="0.7"/>`)).join('') : '';
        const tip = C.P([-12, 45, 2.2]), fl = C.P([-12, 0.1, 6]), KQ = ' keyTimes="0;0.7;0.9;0.91;1" dur="4.6s" repeatCount="indefinite"';
        const drip = `<ellipse cx="${f1(tip[0])}" cy="${f1(tip[1])}" rx="${f1(0.5 * k)}" ry="${f1(0.6 * k)}" fill="#c8d8dc"><animate attributeName="cy" values="${f1(tip[1])};${f1(tip[1] + 0.6 * k)};${f1(fl[1])};${f1(tip[1])};${f1(tip[1])}"${KQ}/><animate attributeName="opacity" values="0.9;0.9;0.9;0;0.9"${KQ}/></ellipse>`;
        const under = shadow(C, 0, 0, 16, 14, 0.35) + FL(C, 0.06, `<ellipse cx="-12" cy="6" rx="6" ry="3.6" fill="#b8c8cc" opacity="0.45"/>`);
        return { under, front: hook + rust + drip, bb: C.bb(4) }; };
      return D; };

    // BTH-023 CHROME 3-BAR TOWEL RACK (T2): a polished chrome valet with three round bars between two uprights on chrome feet: a fluffy blush bath towel with a
    // cream band folded over the top bar, a mint hand towel on the middle bar and a white face cloth with a mint stripe on the bottom one. Live: a glint slides
    // along the chrome bars.
    N.rack29b = S => {
      const D = RACK({ build: () => { const { box, cyl } = K(), o = [];
          [-32, 32].forEach(x => o.push(box(x, 0, 0, 3, 1.8, 26, CH, { r: 0.8, mat: 'chrome' }), cyl(x, 1.8, 0, 1.3, 82, CH, { n: 12, mat: 'chrome' }), cyl(x, 83.8, 0, 1.8, 1.6, CH, { n: 12, mat: 'chrome' })));
          [[50], [66], [82]].forEach(([y]) => o.push(xP(-30.7, 30.7, 0, y, 1, CH, 'chrome')));
          towel(o, -27, -1, 82, 0, 12.6, 11, '#f2c4c8', 1, [[2, 2.4, '#f8ecd8'], [5.6, 0.7, '#f8ecd8']]);
          towel(o, 4, 24, 66, 0, 14, 12, '#a8dcc8', 1, [[2, 1, '#ffffff']]);
          towel(o, 6, 18, 50, 0, 9, 7, '#fbfaf6', 1, [[2, 0.8, '#a8dcc8']]);
          return o; } });
      D.fx = ctx => { const C = cam(ctx), k = C.k;
        const gl = [82, 66, 50].map((y, i) => { const a = C.P([-30, y + 0.6, 0.9]), b = C.P([30, y + 0.6, 0.9]); return `<circle r="${f1(0.8 * k)}" fill="#ffffff" opacity="0"><animate attributeName="cx" values="${f1(a[0])};${f1(b[0])}" dur="7s" begin="${-i * 2.3}s" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(a[1])};${f1(b[1])}" dur="7s" begin="${-i * 2.3}s" repeatCount="indefinite"/>${an('opacity', '0;0.9;0.9;0', 7, -i * 2.3, KT('0;0.1;0.9;1'))}</circle>`; }).join('');
        return { under: shadow(C, 0, 0, 36, 14, 0.3), front: gl, bb: C.bb(4) }; };
      return D; };

    // BTH-043 FREESTANDING BAMBOO LADDER TOWEL & ROBE STAND (T3): a natural bamboo ladder leaning on the wall (knuckled rails with nodes, five rungs), an oatmeal
    // linen towel with a fringe over the second rung and a sage waffle towel over the fourth. Live: the linen fringe sways softly.
    N.rack29c = S => { const BB = '#d8b878';
      const D = RACK({ build: () => { const { cyl } = K(), o = [], { rod } = RD.H16, Zb = 11, Zt = -12, YT = 92, z = y => Zb + (Zt - Zb) * y / YT;
          [-25, 25].forEach(x => o.push(rod([x, 0, Zb], [x, YT, Zt], 1.7, BB, { mat: 'wood' })));
          [18, 36, 54, 72, 88].forEach(y => o.push(xP(-23.3, 23.3, z(y), y, 1.1, shade(BB, 0.95), 'wood')));
          towel(o, -20, 2, 36, z(36), 22, 18, '#e6dccb', 1.1, [[2, 0.6, '#c8b898']]);
          towel(o, 4, 20, 72, z(72), 16, 13, '#b8c8b0', 1.1, [[2, 1, '#a0b098']]);
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('rack29c'), k = C.k, z = y => 11 + (-23) * y / 92;
        const nodes = [-25, 25].map(x => rep(5, i => { const y = 10 + i * 18, p = C.P([x, y, z(y)]); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(1.9 * k)}" ry="${f1(0.5 * k)}" fill="none" stroke="#a88a4a" stroke-width="${f1(0.4 * k)}"/>`; }).join('')).join('');
        const fr = rep(12, i => { const x = -19.4 + i * 1.8, t = C.P([x, 14, z(36) + 2.2]); return `<path d="M${P2(t)}l0 ${f1(2 * k)}" stroke="#c8b898" stroke-width="${f1(0.3 * k)}">${at('rotate', `-8 ${P2(t)};8 ${P2(t)};-8 ${P2(t)}`, 3 + (i % 3) * 0.4, -i * 0.2, SPL(2))}</path>`; }).join('');
        return { under: shadow(C, 0, 0, 34, 18, 0.3), front: nodes + fr, bb: C.bb(4) }; };
      return D; };
  }

  // ---- towel storage batch 2: 063 (arch 'washer' 66 x 60 kept) / 083 (arch 'wardrobe' 106 x 54 kept); hollow cabinets = wall boxes + contents + glass doors
  { const K = () => X.K, sol = o => X.K.solid(o);
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const xP = (x0, x1, z, y, r, col, mat) => sol({ ax: 'x', sh: 'el', c: [z, y], a: r, b: r, n: 12, rings: [[x0, 0], [x1, 0]], col, mat: mat || 'metal' });
    const zR = (x, y, z0, z1, r, col) => sol({ ax: 'z', sh: 'el', c: [x, y], a: r, b: r, n: 16, rings: [[z0, 0, 0.92], [z0 + 0.6, 0, 1], [z1, 0, 1]], col, mat: 'fab', soft: 1 });

    // BTH-063 HYDRONIC HEATED BRASS TOWEL WARMER CABINET (T4): a walnut cabinet on brass bun feet with a polished brass frame, a crown and a glass door: inside,
    // brass hot-water rails glow along the back above walnut shelves stacked with rolled white, cream and taupe towels; a brass thermostat plate reads 52°C.
    // Live: a warm amber glow breathes behind the glass, heat shimmers above the crown and the reading pulses.
    N.warm29 = S => { const WN = '#5e3c24', BR = '#c9a256';
      const D = { w: 66, d: 60, arch: 'washer', build: () => { const { box, ball } = K(), o = [];
          [[-24, -20], [24, -20], [-24, 20], [24, 20]].forEach(([x, z]) => o.push(ball(x, 0, z, 2.2, BR, { k: 4, n: 12, mat: 'metal' })));
          const Bk = box(0, 4.4, -26.5, 62, 79.6, 3, WN, { r: 0.6, mat: 'wood' }), SL = box(-29.5, 4.4, 0.7, 3, 79.6, 51.4, WN, { r: 0.6, mat: 'wood' }), SR = box(29.5, 4.4, 0.7, 3, 79.6, 51.4, WN, { r: 0.6, mat: 'wood' }), SB = box(0, 4.4, 0.7, 56, 3, 51.4, WN, { r: 0.4, mat: 'wood' }); o.push(Bk, SL, SR, SB);
          o.push(box(0, 84, 0, 66, 2.6, 60, BR, { r: 1, mat: 'metal' }), box(0, 86.6, 0, 62, 1.4, 56, WN, { r: 0.6, mat: 'wood' }));
          const Sk = box(0, 7.4, -24.9, 55.8, 76.6, 0.2, shade(WN, 0.9), { r: 0, noOut: 1, mat: 'wood' }); o.push(Sk); glue(o, Sk, [20, 46, 72].map(y => xP(-25, 25, -22.6, y, 0.9, '#e2b456')));
          [31, 57].forEach(y => o.push(box(0, y, 0.4, 56, 1.6, 49.2, WN, { r: 0.3, mat: 'wood' })));
          [[7.4, ['#fbfaf6', '#efe6d6', '#fbfaf6', '#c8b8a4', '#fbfaf6']], [32.6, ['#efe6d6', '#fbfaf6', '#c8b8a4', '#fbfaf6', '#efe6d6']], [58.6, ['#fbfaf6', '#c8b8a4', '#fbfaf6', '#efe6d6', '#fbfaf6']]].forEach(([y, cs]) => cs.forEach((c, i) => o.push(zR(-21.6 + i * 10.8, y + 5.1, -16, 12, 5.1, c))));
          const TF = box(0, 81, 27.3, 50, 3, 1.6, BR, { r: 0.4, mat: 'metal' }); o.push(TF); glue(o, SL, [box(-27, 4.4, 27.3, 4, 79.6, 1.6, BR, { r: 0.4, mat: 'metal' })]); glue(o, SR, [box(27, 4.4, 27.3, 4, 79.6, 1.6, BR, { r: 0.4, mat: 'metal' })]); glue(o, SB, [box(0, 4.4, 27.3, 50, 3, 1.6, BR, { r: 0.4, mat: 'metal' })]);
          glue(o, TF, [box(0, 7.4, 27.3, 50, 73.6, 0.6, '#f4e8d4', { r: 0.2, mat: 'gloss', op: 0.2, noOut: 1 })]);
          o.push(box(27, 34, 28.7, 1.2, 18, 1.2, '#f2d488', { r: 0.6, mat: 'metal' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('w63'), fr = vdot(C, [0, 0, 1]) > 0.1;
        const glow = fr ? PLN(C, [-25, 81, 27.7], [1, 0, 0], [0, -1, 0], `<rect width="50" height="73.6" fill="url(#${id}g)">${an('opacity', '0.45;0.85;0.45', 6, 0, SPL(2))}</rect><path d="M2 0H14L4 73.6H0V0Z" fill="#ffffff" opacity="0.1"/>`) : '';
        const plate = fr ? PLN(C, [-8, 85.9, 30.02], [1, 0, 0], [0, -1, 0], `<rect width="16" height="1.8" rx="0.4" fill="#2a1a0c"/><text x="8" y="1.45" text-anchor="middle" font-family="Arial,sans-serif" font-size="1.5" fill="#ffc870">52°C<animate attributeName="opacity" values="0.6;1;0.6" dur="3s" repeatCount="indefinite"/></text>`) : '';
        const sh = rep(3, i => { const p = C.P([-14 + i * 14, 88, 0]); return `<path d="M${P2(p)}c${f1(-1.4 * k)} ${f1(-2.4 * k)} ${f1(1.4 * k)} ${f1(-4 * k)} 0 ${f1(-6.4 * k)}c${f1(-1.4 * k)} ${f1(-2.4 * k)} ${f1(1.4 * k)} ${f1(-4 * k)} 0 ${f1(-6.4 * k)}" stroke="#ffd8a8" stroke-width="${f1(0.5 * k)}" fill="none" opacity="0">${an('opacity', '0;0.5;0', 4.6, -i * 1.5)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-6 * k)}" dur="4.6s" begin="${-i * 1.5}s" repeatCount="indefinite"/></path>`; }).join('');
        return { defs: `<defs><radialGradient id="${id}g" cx="50%" cy="45%" r="70%"><stop offset="0" stop-color="#ffcf8a" stop-opacity="0.45"/><stop offset="1" stop-color="#ff9a4a" stop-opacity="0.08"/></radialGradient></defs>`, under: shadow(C, 0, 0, 34, 31, 0.35), front: glow + plate + sh, bb: C.bb(4) }; };
      return D; };

    // BTH-083 UV-STERILIZING & LAVENDER-INFUSING ROBE WARMING VAULT (T5): a tall ivory-lacquer vault on a champagne-gold plinth under a gold crown: the left door
    // is closed (raised gold-lined panels, a tall gold pull, a smoked display), the right one is smoked glass in a gold frame showing a plush white robe on a
    // gold rod with a lavender sachet below and a soft UV bar above. Live: the robe glows in a slow UV-to-warm cycle, lavender mist curls inside, sterilising
    // sparkles twinkle and the display ring fills.
    N.vault29 = S => { const IV = '#f4efe6', GD = '#d6b06a';
      const D = { w: 106, d: 54, arch: 'wardrobe', build: () => { const { box, cyl } = K(), o = [];
          o.push(box(0, 0, 0, 106, 6, 54, '#c9a464', { r: 1, mat: 'gloss' }));
          o.push(box(0, 6, -24.5, 104, 150, 5, IV, { r: 0.6, mat: 'gloss' }), box(-50, 6, 2.5, 4, 150, 49, IV, { r: 0.6, mat: 'gloss' }), box(50, 6, 2.5, 4, 150, 49, IV, { r: 0.6, mat: 'gloss' }), box(0, 6, 1.8, 3, 150, 47.6, IV, { r: 0.4, mat: 'gloss' }));
          o.push(box(0, 156, 0, 108, 3, 56, IV, { r: 0.8, mat: 'gloss' }), box(0, 159, 0, 106, 1.2, 54, GD, { r: 0.4, mat: 'metal' }), box(0, 160.2, 0, 104, 2, 52, IV, { r: 0.8, mat: 'gloss' }));
          const LD = box(-25, 6.2, 26, 45.6, 149.6, 2, IV, { r: 0.6, mat: 'gloss' }); o.push(LD);
          glue(o, LD, [[16, 66], [90, 50]].map(([y, h]) => [box(-25, y, 27.05, 36, h, 0.1, '#ece5d8', { r: 0, noOut: 1, mat: 'matte' }), box(-25, y, 27.1, 36, 0.6, 0.1, GD, { r: 0, noOut: 1 }), box(-25, y + h - 0.6, 27.1, 36, 0.6, 0.1, GD, { r: 0, noOut: 1 }), box(-42.7, y, 27.1, 0.6, h, 0.1, GD, { r: 0, noOut: 1 }), box(-7.3, y, 27.1, 0.6, h, 0.1, GD, { r: 0, noOut: 1 })]).flat());
          o.push(box(-6, 60, 27.6, 1.4, 40, 1.2, GD, { r: 0.7, mat: 'metal' }));
          const LV = '#b49ad8', RB = box(25.5, 62, 0, 27, 72, 10, '#fbfaf6', { r: 4, mat: 'fab', soft: 1 }); o.push(xP(3.5, 46, 0, 142, 0.9, GD), cyl(25.5, 134, 0, 0.5, 8, GD, { n: 8, mat: 'metal' }), xP(14, 37, 0, 133, 0.8, '#e8d8b8', 'wood'), RB);
          [9.5, 41.5].forEach(x => o.push(box(x, 82, 0, 4, 46, 7, '#f6f3ec', { r: 2, mat: 'fab', soft: 1 })));
          glue(o, RB, [RD.H16.rod([17, 127, 5.05], [24, 99, 5.05], 0.6, LV, { mat: 'fab' }), RD.H16.rod([34, 127, 5.05], [27, 99, 5.05], 0.6, LV, { mat: 'fab' }), box(25.5, 95, 5.05, 27.2, 3, 0.8, LV, { r: 0.4, mat: 'fab' }), box(18, 72, 5.05, 7, 8, 0.4, '#f2eee6', { r: 1, mat: 'fab' }), box(33, 72, 5.05, 7, 8, 0.4, '#f2eee6', { r: 1, mat: 'fab' })]);
          o.push(cyl(40, 6, 12, 3, 5, '#a890d0', { n: 12, mat: 'fab' }), box(25.5, 152.4, 18, 40, 1.4, 2, '#c8b0ff', { r: 0.6, emit: 1, noOut: 1 }));
          const TF = box(25.5, 153, 26.2, 45.2, 2.8, 1.4, GD, { r: 0.4, mat: 'metal' }); o.push(box(2.2, 6.2, 26.2, 1.4, 149.6, 1.4, GD, { r: 0.4, mat: 'metal' }), box(48.8, 6.2, 26.2, 1.4, 149.6, 1.4, GD, { r: 0.4, mat: 'metal' }), box(25.5, 6.2, 26.2, 45.2, 2.8, 1.4, GD, { r: 0.4, mat: 'metal' }), TF);
          glue(o, TF, [box(25.5, 9, 26, 45, 144, 1, '#d8d0c8', { r: 0.2, mat: 'gloss', op: 0.2, noOut: 1 })]);
          o.push(box(6, 60, 27.6, 1.2, 30, 1.2, GD, { r: 0.6, mat: 'metal' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('vault29'), id = C.u('v83'), k = C.k, fr = vdot(C, [0, 0, 1]) > 0.1;
        const robeGlow = fr ? PLN(C, [3, 153, 26.7], [1, 0, 0], [0, -1, 0], `<rect width="45" height="144" fill="#c8b0ff" opacity="0.2">${an('fill', '#c8b0ff;#ffe0b0;#c8b0ff', 12, 0, SPL(2))}${an('opacity', '0.12;0.3;0.12', 12, 0, SPL(2))}</rect><path d="M4 0H12L2 144H0V0Z" fill="#ffffff" opacity="0.1"/>`) : '';
        const mist = fr ? rep(4, i => { const p = C.P([14 + i * 8, 14, 12]); return `<path d="M${P2(p)}c${f1(-3 * k)} ${f1(-5 * k)} ${f1(3 * k)} ${f1(-9 * k)} 0 ${f1(-16 * k)}" stroke="#c8b0ff" stroke-width="${f1(1.2 * k)}" fill="none" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.5;0', 7, -i * 1.6)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-30 * k)}" dur="7s" begin="${-i * 1.6}s" repeatCount="indefinite"/></path>`; }).join('') : '';
        const tw = fr ? rep(10, i => { const p = C.P([8 + R() * 36, 30 + R() * 110, 8]); return `<path d="M${f1(p[0] - 1 * k)} ${f1(p[1])}H${f1(p[0] + 1 * k)}M${f1(p[0])} ${f1(p[1] - 0.7 * k)}V${f1(p[1] + 0.7 * k)}" stroke="#ffffff" stroke-width="${f1(0.22 * k)}" opacity="0">${an('opacity', '0;0;0.9;0', 3 + (i % 3), -i * 0.5, KT('0;0.7;0.8;1'))}</path>`; }).join('') : '';
        const disp = fr ? PLN(C, [-35, 136, 27.05], [1, 0, 0], [0, -1, 0], `<rect width="20" height="9" rx="1.2" fill="#1a1618"/><circle cx="4.6" cy="4.5" r="2.6" fill="none" stroke="#3a3238" stroke-width="0.6"/><circle cx="4.6" cy="4.5" r="2.6" fill="none" stroke="#c8b0ff" stroke-width="0.6" stroke-dasharray="16.3" stroke-dashoffset="16.3" transform="rotate(-90 4.6 4.5)">${an('stroke-dashoffset', '16.3;0;0', 10, 0, KT('0;0.85;1'))}</circle><text x="13.6" y="4" text-anchor="middle" font-family="Arial,sans-serif" font-size="1.7" fill="#f2e6d0">UV 99.9%</text><text x="13.6" y="6.8" text-anchor="middle" font-family="Arial,sans-serif" font-size="1.3" fill="#c8b0ff">lavender</text>`) : '';
        return { under: shadow(C, 0, 0, 56, 30, 0.35), front: robeGlow + mist + tw + disp, bb: C.bb(4) }; };
      return D; };
  }

  // ======================= THERMAL STATION (BTH-007/027/047/067/087): floor pieces, arch 'sauna' 130 x 110 kept (no act / seats) =======================
  { const K = () => X.K, sol = o => X.K.solid(o), { oval, rip } = RD.H29T, { rod } = RD.H16;
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const xP = (x0, x1, z, y, r, col, mat) => sol({ ax: 'x', sh: 'el', c: [z, y], a: r, b: r, n: 12, rings: [[x0, 0], [x1, 0]], col, mat: mat || 'metal' });
    const SAU = o => Object.assign({ w: 130, d: 110, arch: 'sauna' }, o);
    // rising steam wisps from a point (screen-space s-curves that drift up and fade)
    const steam = (C, p, n, T, h, w, col, sd) => { const R = rng(sd), k = C.k; return rep(n, i => { const q = C.P([p[0] + (R() - 0.5) * w, p[1], p[2] + (R() - 0.5) * w * 0.6]), b = -i * T / n, s = 0.7 + R() * 0.6;
        return `<path d="M${P2(q)}c${f1(-2.4 * k * s)} ${f1(-3 * k)} ${f1(2.4 * k * s)} ${f1(-6 * k)} 0 ${f1(-9 * k)}c${f1(-2.4 * k * s)} ${f1(-3 * k)} ${f1(2.4 * k * s)} ${f1(-6 * k)} 0 ${f1(-9 * k)}" stroke="${col || '#ffffff'}" stroke-width="${f1(1.6 * k * s)}" stroke-linecap="round" fill="none" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.55;0', T, b)}<animateTransform attributeName="transform" type="translate" values="0 0;${f1((R() - 0.5) * 4 * k)} ${f1(-h * k)}" dur="${T}s" begin="${n4(b)}s" repeatCount="indefinite"/></path>`; }).join(''); };
    // near-side arc of a horizontal circle (radius r(y)) around (cx, cz) at height y
    const arcY = (C, cx, cz, r, y, w, col, op) => { let d = '', on = false; for (let i = 0; i <= 48; i++) { const t = i / 48 * 2 * PI, n = [Math.cos(t), 0, Math.sin(t)];
        if (vdot(C, n) > 0.03) { d += (on ? 'L' : 'M') + PP(C, [cx + n[0] * r, y, cz + n[2] * r]); on = true; } else on = false; }
      return d ? `<path d="${d}" stroke="${col}" stroke-width="${f1(w * C.k)}" fill="none" stroke-linecap="round" opacity="${op || 1}"/>` : ''; };
    // near-side arc of a z-axis circle (barrel band) at depth z
    const arcZ = (C, cx, cy, r, z, w, col, op, ymin) => { let d = '', on = false; for (let i = 0; i <= 64; i++) { const t = i / 64 * 2 * PI, n = [Math.cos(t), Math.sin(t), 0], y = cy + n[1] * r;
        if (vdot(C, n) > 0.03 && y > (ymin || 0)) { d += (on ? 'L' : 'M') + PP(C, [cx + n[0] * r, y, z]); on = true; } else on = false; }
      return d ? `<path d="${d}" stroke="${col}" stroke-width="${f1(w * C.k)}" fill="none" stroke-linecap="round" stroke-linejoin="round" opacity="${op || 1}"/>` : ''; };

    // BTH-007 STEAMY BUCKET OF HOT WATER & MENTHOL DROPS (T1): a dented, rust-spotted galvanised bucket with two pressed ribs and a wire bail handle, full of
    // hot water gone pale minty green; a little green glass bottle of menthol drops with a rubber dropper beside it, a thin worn blue-grey towel folded on the
    // floor with a dented tin ladle on it, and a splashed puddle. Live: steam curls up off the water, a mint swirl turns slowly in it, ripples spread and a
    // drip runs down the bucket into the puddle.
    N.therm29a = S => { const GV = '#a9b0b4', RG = [[0, 0, 0.8], [30, 0, 1]];
      const D = SAU({ build: () => { const { box, cyl, ball } = K(), o = [];
          oval(o, 19, 19, 0.8, 18, RG, GV, 'metal', 23, '#cfe6d4');
          [-1, 1].forEach(s => o.push(box(s * 19.9, 25.5, 0, 1.2, 3, 3, shade(GV, 0.9), { r: 0.4, mat: 'metal' })));
          o.push(cyl(32, 0, 18, 3.4, 9, '#2f7a4c', { n: 14, mat: 'gloss' }), cyl(32, 9, 18, 1.5, 2, '#2f7a4c', { n: 10, mat: 'gloss' }), cyl(32, 11, 18, 1.9, 2.4, '#1e1e1e', { n: 12, mat: 'plastic' }), ball(32, 15, 18, 1.6, '#3a3a3a', { sy: 1.3, k: 4, n: 10, mat: 'plastic' }));
          o.push(box(36, 0, -18, 28, 4.4, 20, '#a6b8c0', { r: 1.6, mat: 'fab', soft: 1 }), box(36, 4.4, -18, 27, 1.4, 19, '#b2c4cb', { r: 1, mat: 'fab', soft: 1 }));
          o.push(ball(29, 7.6, -18, 3.4, '#b8bcc0', { sy: 0.45, k: 4, n: 14, mat: 'metal' }), xP(32.6, 47, -18, 7.4, 0.5, '#b8bcc0'));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('therm29a'), k = C.k, rA = y => 19 * (0.8 + 0.2 * y / 30);
        const under = shadow(C, 4, 0, 46, 30, 0.3) + FL(C, 0.06, `<path d="M-14 16Q-4 24 12 22Q20 30 8 34Q-8 34 -18 26Q-24 20 -14 16Z" fill="#b8cfd2" opacity="0.4"/><ellipse cx="22" cy="20" rx="5" ry="2.4" fill="#b8cfd2" opacity="0.35"/>`);
        let side = [8, 16].map(y => arcY(C, 0, 0, rA(y) + 0.2, y, 0.7, '#7c8286', 0.7) + arcY(C, 0, 0, rA(y) + 0.25, y + 0.7, 0.4, '#d8dde0', 0.6)).join('') + arcY(C, 0, 0, 19.3, 29.7, 0.6, '#e4e8ea', 0.8);
        side += rep(14, () => { const t = R() * 2 * PI, y = 3 + R() * 24, n = [Math.cos(t), 0, Math.sin(t)]; if (vdot(C, n) < 0.25) return ''; const q = C.P([n[0] * (rA(y) + 0.1), y, n[2] * (rA(y) + 0.1)]);
          return R() < 0.55 ? `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((0.4 + R() * 0.8) * k)}" ry="${f1((0.5 + R() * 0.9) * k)}" fill="#9a5a2a" opacity="${n4(0.45 + R() * 0.3)}"/>` : `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((1.6 + R() * 1.6) * k)}" ry="${f1((1 + R()) * k)}" fill="#5a6064" opacity="0.18"/><path d="M${f1(q[0] - 1.4 * k)} ${f1(q[1] - 0.6 * k)}q${f1(1.4 * k)} ${f1(-0.8 * k)} ${f1(2.8 * k)} 0" stroke="#e8ecee" stroke-width="${f1(0.3 * k)}" fill="none" opacity="0.6"/>`; }).join('');
        const swirl = FL(C, 23.2, `<g>${at('rotate', '0;360', 16, 0)}<path d="M0 0C4 -2 8 2 6 6C3 10 -5 8 -8 3C-10 -2 -6 -8 0 -9C7 -10 13 -4 13 3" stroke="#7ad0a4" stroke-width="1.4" fill="none" opacity="0.45" stroke-linecap="round"/></g>`);
        const tip = [Math.cos(0.9) * 19.2, 22, Math.sin(0.9) * 19.2], fl = vdot(C, [Math.cos(0.9), 0, Math.sin(0.9)]) > 0.15;
        const drip = fl ? (() => { const a = C.P(tip), b = C.P([tip[0] * 0.86, 0.2, tip[2] * 1.05]), KQ = ' keyTimes="0;0.75;0.95;0.96;1" dur="5s" repeatCount="indefinite"';
          return `<ellipse rx="${f1(0.45 * k)}" ry="${f1(0.65 * k)}" fill="#d8ece4"><animate attributeName="cx" values="${f1(a[0])};${f1(a[0])};${f1(b[0])};${f1(a[0])};${f1(a[0])}"${KQ}/><animate attributeName="cy" values="${f1(a[1])};${f1(a[1] + 0.6 * k)};${f1(b[1])};${f1(a[1])};${f1(a[1])}"${KQ}/><animate attributeName="opacity" values="0.9;0.9;0.9;0;0.9"${KQ}/></ellipse>`; })() : '';
        const lab = vdot(C, [0, 0, 1]) > 0.1 ? PLN(C, [28.6, 7.6, 21.45], [1, 0, 0], [0, -1, 0], `<rect width="6.8" height="5" rx="0.4" fill="#f2efe4"/><path d="M1.4 3.4Q1.8 1.2 3.6 1Q3.6 3 1.4 3.4Z" fill="#3a9a5a"/><text x="4.6" y="3.4" font-family="Arial,sans-serif" font-size="1.2" font-weight="bold" fill="#2f7a4c">M</text><rect x="0.6" y="4" width="5.6" height="0.4" fill="#2f7a4c" opacity="0.6"/>`) : '';
        // wire bail handle standing up over the water (fx: only the part above the rim, so the bucket never needs to hide it)
        let hd = ''; for (let i = 0; i <= 40; i++) { const t = i / 40 * PI, p = [Math.cos(t) * 20.4, 27 + Math.sin(t) * 17, 0]; if (p[1] < 30.4) continue; hd += (hd ? 'L' : 'M') + PP(C, p); }
        const bail = `<path d="${hd}" stroke="#6a7074" stroke-width="${f1(0.8 * k)}" fill="none" stroke-linecap="round"/><path d="${hd}" stroke="#d8dde0" stroke-width="${f1(0.25 * k)}" fill="none" opacity="0.8"/>` + [-1, 1].map(s => `<path d="M${PP(C, [s * 20.4, 27.4, 0])}L${PP(C, [s * 20.2, 31, 0])}" stroke="#6a7074" stroke-width="${f1(0.8 * k)}" stroke-linecap="round"/>`).filter((_, i) => vdot(C, [i ? 1 : -1, 0, 0]) > -0.3).join('');
        const tw = FL(C, 5.86, `<path d="M23.4 -14.4H48.6" stroke="#6f8690" stroke-width="0.5" opacity="0.6"/><path d="M23.4 -24H48.6" stroke="#ffffff" stroke-width="1.2" opacity="0.3"/>` + rep(14, i => `<path d="M${f1(24 + i * 1.8)} -9.2l${f1((i % 3 - 1) * 0.4)} 1.6" stroke="#8ea2ac" stroke-width="0.35"/>`).join('') + rep(6, () => `<circle cx="${f1(24 + R() * 24)}" cy="${f1(-26 + R() * 16)}" r="${f1(0.6 + R())}" fill="#6f8690" opacity="0.25"/>`).join(''));
        const front = tw + side + bail + swirl + rip(C, [-5, 23.15, 4], 3.6, 0) + rip(C, [7, 23.15, -6], 4.4, 1.8) + drip + lab + steam(C, [0, 24, 0], 6, 6, 34, 22, '#ffffff', 'st29a');
        return { under, front, bb: C.bb(6) }; };
      return D; };

    // BTH-027 PORTABLE ZIP-UP PERSONAL STEAM TENT (T2): a sage nylon pop-up steam tent on a white frame, with a padded collar and toggled drawstring round the
    // head hole on top, a U-shaped zip door with a dangling pull, a brand tag, soft creases and a side hose port; beside it a small white plastic steam
    // generator with a dial, a green power light and a ribbed hose into the tent. Live: steam leaks from the collar and the zip seam, the light blinks and the
    // nylon front slowly puffs (sheen breathing).
    N.therm29b = S => { const SG = '#9fc684', WH = '#f4f1ea';
      const D = SAU({ build: () => { const { box, cyl } = K(), o = [];
          o.push(box(-12, 0, 0, 72, 94, 72, SG, { r: 9, mat: 'fab', soft: 1 }), cyl(-12, 94, 0, 10, 2.6, shade(SG, 0.86), { n: 18, mat: 'fab', soft: 1 }));
          o.push(box(44, 0, 14, 18, 20, 16, WH, { r: 4, mat: 'plastic' }), cyl(44, 20, 14, 6, 2, '#e4e0d8', { n: 16, mat: 'plastic' }), cyl(44, 22, 14, 1.6, 2, '#d0ccc4', { n: 10, mat: 'plastic' }));
          const hp = [[44, 23.6, 14], [42, 33, 14], [36, 39, 14], [29.6, 40, 14]]; for (let i = 0; i < 3; i++) o.push(rod(hp[i], hp[i + 1], 1.3, '#dcd8d0', { mat: 'plastic' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('therm29b'), k = C.k, id = C.u('t27');
        const fr = vdot(C, [0, 0, 1]) > 0.05, sd = vdot(C, [1, 0, 0]) > 0.05;
        const zip = `M10 92V20Q10 8 22 8H50Q62 8 62 20V92`;
        const fA = fr ? PLN(C, [-48, 94, 36.05], [1, 0, 0], [0, -1, 0], `<rect x="1" y="1" width="70" height="92" fill="#ffffff" opacity="0.06">${an('opacity', '0.02;0.12;0.02', 7, 0, SPL(2))}</rect>` +
          rep(6, i => `<path d="M${8 + i * 11 + (i % 2) * 3} 4Q${12 + i * 11} 46 ${6 + i * 11 + (i % 3) * 2} 90" stroke="#5f7e4c" stroke-width="0.7" fill="none" opacity="0.18"/>`).join('') +
          `<path d="${zip}" stroke="#4a5e3c" stroke-width="2.4" fill="none"/><path d="${zip}" stroke="#d8dccc" stroke-width="1.2" fill="none" stroke-dasharray="0.4 0.6"/><path d="M60.6 52v6" stroke="#2a2a2a" stroke-width="1.6" stroke-linecap="round"/><rect x="59.6" y="57" width="2" height="4" rx="0.6" fill="#c8ccc4" stroke="#2a2a2a" stroke-width="0.3"/>` +
          `<rect x="28" y="86" width="16" height="4.4" rx="0.6" fill="#3a4a30"/><text x="36" y="89.3" text-anchor="middle" font-family="Arial,sans-serif" font-size="2.4" font-weight="bold" fill="#e8f0d8">STEAMEZ</text><path d="M4 2V92M68 2V92" stroke="#ffffff" stroke-width="0.8" opacity="0.25"/>`) : '';
        const sA = sd ? PLN(C, [24.05, 94, 36], [0, 0, -1], [0, -1, 0], rep(5, i => `<path d="M${8 + i * 14} 4Q${12 + i * 14} 46 ${6 + i * 14} 90" stroke="#5f7e4c" stroke-width="0.7" fill="none" opacity="0.16"/>`).join('') + `<circle cx="22" cy="54" r="3.2" fill="#4a5e3c"/><circle cx="22" cy="54" r="2" fill="#2a3424"/>`) : '';
        const top = FL(C, 96.65, `<ellipse cx="-12" cy="0" rx="6.4" ry="6.4" fill="#2e3a28"/><ellipse cx="-12" cy="-1" rx="5.4" ry="4.6" fill="#1e261a"/>`) + (fr ? PLN(C, [-14, 96, 10.02], [1, 0, 0], [0, -1, 0], `<path d="M0 0Q-1 4 -2 7M4 0Q5 4 6 7" stroke="#e8e4d8" stroke-width="0.5" fill="none"/><rect x="-3" y="6.6" width="2" height="3" rx="0.8" fill="#2a2a2a"/><rect x="5" y="6.6" width="2" height="3" rx="0.8" fill="#2a2a2a"/>`) : '');
        const gen = fr ? PLN(C, [37, 16, 22.05], [1, 0, 0], [0, -1, 0], `<rect x="1" y="1" width="12" height="9" rx="1.4" fill="#e8e4dc"/><circle cx="5" cy="6" r="2.6" fill="#d0ccc4" stroke="#8a867e" stroke-width="0.3"/><path d="M5 6L6.6 4.2" stroke="#4a4a4a" stroke-width="0.5"/><circle cx="10.6" cy="3.6" r="0.8" fill="#4ad06a">${an('opacity', '1;0.25;1', 1.6, 0)}</circle><text x="10.6" y="8.2" text-anchor="middle" font-family="Arial,sans-serif" font-size="1.4" fill="#6a665e">15</text>`) : '';
        const st = steam(C, [-12, 97, 0], 6, 6.4, 34, 14, '#ffffff', 'st29b') + (fr ? steam(C, [8, 50, 37], 3, 5, 14, 4, '#ffffff', 'st29b2') : '');
        return { under: shadow(C, 4, 0, 58, 44, 0.3), front: fA + sA + top + gen + st, bb: C.bb(6) }; };
      return D; };

    // BTH-047 CORNER CEDAR BARREL DRY SAUNA WITH LAVA ROCKS (T3): a western red cedar barrel sauna lying on two cedar cradles, tongue-and-groove staves held by
    // three black steel bands, a vertical-board end wall with a round-topped tempered-glass door (black frame, cedar pull, hinges) and an outside thermometer,
    // a black stovepipe at the back. Through the glass: warm cedar benches, a black heater piled with glowing lava rocks, a bucket and ladle. Live: the lava
    // rocks breathe red-orange, a steam puff rises off the stones every few seconds, the glass glows warm and heat shimmers over the stovepipe.
    N.therm29c = S => { const CD = '#b8693f', BK = '#2c2d31', RB = 47, CY = 54, Z0 = -50, Z1 = 50;
      const D = SAU({ build: () => { const { box, cyl } = K(), o = [];
          [-34, 34].forEach(z => { o.push(box(0, 0, z, 84, 5, 9, shade(CD, 0.8), { r: 0.8, mat: 'wood' })); [-1, 1].forEach(s => o.push(box(s * 30, 5, z, 12, 6, 9, shade(CD, 0.8), { r: 0.8, mat: 'wood' }))); });
          o.push(sol({ ax: 'z', sh: 'el', c: [0, CY], a: RB, b: RB, n: 32, rings: [[Z0, 0, 0.985], [Z0 + 1.2, 0, 1], [Z1 - 1.2, 0, 1], [Z1, 0, 0.985]], col: CD, mat: 'wood' }));
          o.push(cyl(22, 96, -32, 3, 18, BK, { n: 12, mat: 'metal' }), cyl(22, 114, -32, 4.2, 1.6, BK, { n: 12, mat: 'metal' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('therm29c'), k = C.k, id = C.u('b47'), fr = vdot(C, [0, 0, 1]) > 0.02;
        let side = ''; for (let i = 0; i < 40; i++) { const t = (i + 0.5) / 40 * 2 * PI, n = [Math.cos(t), Math.sin(t), 0], y = CY + n[1] * RB; if (vdot(C, n) < 0.05 || y < 14) continue;
          side += `<path d="M${PP(C, [n[0] * RB, y, Z0 + 1.4])}L${PP(C, [n[0] * RB, y, Z1 - 1.4])}" stroke="#7a3e1e" stroke-width="${f1(0.35 * k)}" opacity="0.45"/>`; }
        side += [-40, 0, 40].map(z => arcZ(C, 0, CY, RB + 0.25, z, 2.6, BK, 1, 12) + arcZ(C, 0, CY, RB + 0.3, z - 0.8, 0.5, '#6a6c72', 0.6, 12)).join('');
        side += rep(22, () => { const t = R() * 2 * PI, n = [Math.cos(t), Math.sin(t), 0], y = CY + n[1] * RB; if (vdot(C, n) < 0.3 || y < 16) return ''; const z = Z0 + 4 + R() * 92, a = C.P([n[0] * RB, y, z]);
          return `<ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="${f1(0.7 * k)}" ry="${f1(0.45 * k)}" fill="#6a3418" opacity="0.5"/>`; }).join('');
        let end = '';
        if (fr) { const wood = rep(13, i => `<rect x="${-RB + i * 7.25}" y="${-RB}" width="7.25" height="${2 * RB}" fill="${['#c2744a', '#b4683e', '#c87c50', '#ba6e44'][i % 4]}"/><path d="M${-RB + i * 7.25} ${-RB}V${RB}" stroke="#6a3418" stroke-width="0.35" opacity="0.7"/>`).join('');
          const inside = `<rect x="-18" y="-34" width="36" height="74" fill="url(#${id}i)"/>` + rep(7, i => `<path d="M${-17 + i * 5.6} -34V40" stroke="#4a2410" stroke-width="0.3" opacity="0.6"/>`).join('') +
            `<path d="M-18 6H8V9H-18Z" fill="#c8844e"/><path d="M-18 9H8V11H-18Z" fill="#6a3a1c"/><path d="M-18 22H8V25H-18Z" fill="#d0905a"/><path d="M-18 25H8V27H-18Z" fill="#6a3a1c"/><path d="M-16 11V22M4 11V22" stroke="#6a3a1c" stroke-width="1"/>` +
            `<rect x="9" y="12" width="9" height="17" fill="#1e1e22"/><rect x="9" y="12" width="9" height="1.4" fill="#3a3a40"/>` + rep(9, i => `<ellipse cx="${10.4 + (i % 4) * 2.2 + (i > 3 ? 1 : 0)}" cy="${11.6 - Math.floor(i / 4) * 1.6}" rx="1.3" ry="1" fill="${['#4a3a36', '#5a3e34', '#3e302c'][i % 3]}"/>`).join('') +
            `<ellipse cx="13.5" cy="11" rx="7.4" ry="4.4" fill="#ff7a28" opacity="0.6" filter="url(#m12b1)">${an('opacity', '0.45;1;0.45', 3.4, 0, SPL(2))}</ellipse>` + rep(5, i => `<circle cx="${10.6 + i * 1.6}" cy="${10.6 + (i % 2) * 0.8}" r="0.45" fill="#ffb040">${an('opacity', '0.3;1;0.3', 1.6 + i * 0.3, -i * 0.4)}</circle>`).join('') +
            `<path d="M-12 39h6l-1 -5h-4z" fill="#8a5a30"/><path d="M-6 35l6 -6" stroke="#8a5a30" stroke-width="0.6"/>` +
            `<g opacity="0">${an('opacity', '0;0;0.7;0', 5, 0, KT('0;0.55;0.7;1'))}<ellipse cx="13" cy="4" rx="4" ry="3" fill="#ffffff" filter="url(#m12b1)"><animate attributeName="cy" values="8;8;-4;-12" dur="5s" repeatCount="indefinite" keyTimes="0;0.55;0.8;1"/></ellipse></g>` +
            `<rect x="-18" y="-34" width="36" height="74" fill="url(#${id}w)">${an('opacity', '0.6;1;0.6', 4.6, 0, SPL(2))}</rect><path d="M-14 -34L-4 -34L-16 40H-18V-30Z" fill="#ffffff" opacity="0.1"/>`;
          end = PLN(C, [0, CY, Z1 + 0.06], [1, 0, 0], [0, -1, 0], `<defs><clipPath id="${id}c"><circle r="${RB * 0.985}"/></clipPath><clipPath id="${id}d"><path d="M-17 40V-20Q-17 -34 0 -34Q17 -34 17 -20V40Z"/></clipPath>` +
            `<linearGradient id="${id}i" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a2410"/><stop offset="1" stop-color="#8a4a22"/></linearGradient><radialGradient id="${id}w" cx="70%" cy="60%" r="70%"><stop offset="0" stop-color="#ff9a40" stop-opacity="0.35"/><stop offset="1" stop-color="#ff7a20" stop-opacity="0"/></radialGradient></defs>` +
            `<g clip-path="url(#${id}c)">${wood}<circle r="${RB * 0.985}" fill="none" stroke="#7a3e1e" stroke-width="1.4" opacity="0.5"/></g>` +
            `<g clip-path="url(#${id}d)">${inside}</g><path d="M-17 40V-20Q-17 -34 0 -34Q17 -34 17 -20V40Z" fill="none" stroke="${BK}" stroke-width="2.2"/><path d="M-15.6 40V-20Q-15.6 -32.4 0 -32.4Q15.6 -32.4 15.6 -20V40" fill="none" stroke="#4a4c52" stroke-width="0.4"/>` +
            `<rect x="-19.4" y="-12" width="3" height="5" rx="0.6" fill="${BK}"/><rect x="-19.4" y="24" width="3" height="5" rx="0.6" fill="${BK}"/><rect x="11.6" y="-2" width="2.6" height="20" rx="1.2" fill="#8a4a24" stroke="#4a2410" stroke-width="0.3"/><rect x="12" y="-1" width="0.8" height="18" rx="0.4" fill="#c8844e" opacity="0.7"/>` +
            `<circle cx="-30" cy="-14" r="5" fill="#e8dcc0" stroke="#3a2a1a" stroke-width="0.9"/><path d="M-30 -14L-27.4 -16.2" stroke="#c83a2a" stroke-width="0.6"/><circle cx="-30" cy="-14" r="0.6" fill="#3a2a1a"/>` + rep(7, i => { const a = PI * (0.8 + i * 0.233); return `<path d="M${f1(-30 + Math.cos(a) * 3.8)} ${f1(-14 + Math.sin(a) * 3.8)}L${f1(-30 + Math.cos(a) * 4.5)} ${f1(-14 + Math.sin(a) * 4.5)}" stroke="#3a2a1a" stroke-width="0.3"/>`; }).join('')); }
        const sh = rep(3, i => { const p = C.P([22, 116, -32]); return `<path d="M${P2(p)}c${f1(-1.4 * k)} ${f1(-2.4 * k)} ${f1(1.4 * k)} ${f1(-4 * k)} 0 ${f1(-6.4 * k)}c${f1(-1.4 * k)} ${f1(-2.4 * k)} ${f1(1.4 * k)} ${f1(-4 * k)} 0 ${f1(-6.4 * k)}" stroke="#d8c8b8" stroke-width="${f1(0.6 * k)}" fill="none" opacity="0">${an('opacity', '0;0.45;0', 4, -i * 1.33)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-8 * k)}" dur="4s" begin="${-i * 1.33}s" repeatCount="indefinite"/></path>`; }).join('');
        return { under: shadow(C, 0, 0, 56, 52, 0.4), front: side + end + sh, bb: C.bb(8) }; };
      return D; };

    // BTH-067 GLASS-FRONT FINNISH INFRARED & HIMALAYAN SALT SAUNA (T4): a smoked thermo-ash cabin on a black plinth under a black cornice with a gold edge; the
    // whole front is bronze-tinted glass in a black frame with a door mullion and a tall gold pull, and a touch panel on the frame. Inside (real 3D): a back
    // wall of glowing pink-amber Himalayan salt bricks, a two-tier hemlock bench with slats, red carbon infrared panels under the upper tier, a brushed-steel
    // Finnish heater with a stone pile, and a cedar bucket. Live: the salt wall and the IR panels breathe, heat shimmers off the stones, the panel reads 65°C.
    N.therm29d = S => { const EXT = '#6a4630', IN = '#e6c898', FR = '#1e1c1e', GD = '#d6b06a';
      const D = SAU({ build: () => { const { box, ball, cyl } = K(), o = [], R = rng('therm29d');
          const Bk = box(0, 4, -27.5, 126, 142, 5, EXT, { r: 0.6, mat: 'wood' }), SL = box(-60.5, 4, 10.5, 5, 142, 71, EXT, { r: 0.6, mat: 'wood' }), SR = box(60.5, 4, 10.5, 5, 142, 71, EXT, { r: 0.6, mat: 'wood' });
          const FLR = box(0, 4, 10.7, 116, 2, 70.6, IN, { r: 0.2, mat: 'wood' }), Rf = box(0, 146, 10, 130, 5, 84, FR, { r: 0.8, mat: 'matte' });
          o.push(box(0, 0, 10, 126, 4, 80, FR, { r: 1, mat: 'matte' }), Bk, SL, SR, FLR, Rf);
          glue(o, Rf, [box(0, 147.6, 52.05, 130, 1.2, 0.2, GD, { r: 0, noOut: 1, mat: 'metal' })]);
          const Sk = box(0, 6, -24.9, 115.8, 140, 0.2, '#b86a44', { r: 0, noOut: 1 }); o.push(Sk);
          const SC = ['#f6b088', '#f0a078', '#f8c09a', '#eea070', '#f4b890', '#f9caa8'], bw = 115.8 / 8, bh = 140 / 10;
          glue(o, Sk, rep(80, i => { const c = i % 8, r = Math.floor(i / 8); return box(-57.9 + bw * (c + 0.5), 6 + r * bh + 0.25, -24.62, bw - 0.5, bh - 0.5, 0.3, SC[Math.floor(R() * SC.length)], { r: 0.3, emit: 1, noOut: 1 }); }));
          const UB = box(0, 6, -15, 112, 40, 17, IN, { r: 0.6, mat: 'wood' }), LB = box(0, 6, 1.5, 112, 18, 14, IN, { r: 0.6, mat: 'wood' }); o.push(UB, LB);
          glue(o, UB, [-20.4, -16.8, -13.2, -9.6].map(z => box(0, 46, z, 112, 0.1, 0.5, '#b08a58', { r: 0, noOut: 1 })).concat([-36, 0, 36].map(x => box(x, 26, -6.42, 30, 14, 0.2, '#a83426', { r: 0.4, emit: 1, noOut: 1 }))));
          glue(o, LB, [-2.4, 1.4, 5.2].map(z => box(0, 24, z, 112, 0.1, 0.5, '#b08a58', { r: 0, noOut: 1 })));
          const HT = box(44, 6, 26, 18, 28, 16, '#b8bcc0', { r: 1, mat: 'brush' }); o.push(HT);
          glue(o, HT, [box(44, 30, 34.05, 16, 1.2, 0.2, '#2a2a2a', { r: 0, noOut: 1 })].concat(rep(9, i => ball(38 + (i % 3) * 6 + (R() - 0.5), 34.6 + Math.floor(i / 3) * 1.4, 21 + Math.floor(i / 3) * 5 + (R() - 0.5), 3 + R(), ['#5a4a44', '#4a3e3a', '#6a5850'][i % 3], { sy: 0.6, k: 5, n: 10 }))));
          o.push(cyl(-40, 24, 1.5, 4, 6, '#c89a5a', { n: 14, mat: 'wood' }));
          const TF = box(0, 140, 48, 116, 6, 4, FR, { r: 0.4, mat: 'matte' }); o.push(TF);
          glue(o, TF, [box(0, 8, 48, 116, 132, 0.6, '#e8c8a0', { r: 0, mat: 'gloss', op: 0.16, noOut: 1 }), box(-8, 8, 48.6, 1.4, 132, 1, FR, { r: 0.2, mat: 'matte' }), box(-12.4, 48, 50.6, 1.4, 46, 1.4, GD, { r: 0.7, mat: 'metal' }), box(-12.4, 52, 49.4, 1, 1, 1.2, GD, { r: 0.3, mat: 'metal' }), box(-12.4, 90, 49.4, 1, 1, 1.2, GD, { r: 0.3, mat: 'metal' })]);
          glue(o, SL, [box(-60.5, 4, 48, 5, 142, 4, FR, { r: 0.4, mat: 'matte' })]); glue(o, SR, [box(60.5, 4, 48, 5, 142, 4, FR, { r: 0.4, mat: 'matte' })]); glue(o, FLR, [box(0, 4, 48, 116, 4, 4, FR, { r: 0.4, mat: 'matte' })]);
          return o; } });
      D.fx = ctx => { const C = cam(ctx), k = C.k, id = C.u('s67'), fr = vdot(C, [0, 0, 1]) > 0.05;
        const boards = s => vdot(C, [s, 0, 0]) > 0.05 ? PLN(C, [s * 63.05, 146, s > 0 ? 50 : -30], [0, 0, -s], [0, -1, 0], rep(10, i => `<path d="M${f1(7.6 + i * 7.2)} 0V142" stroke="#3a2416" stroke-width="0.35" opacity="0.55"/>`).join('') + `<path d="M0 0V142" stroke="${FR}" stroke-width="0.1"/>`) : '';
        const glow = fr ? PLN(C, [-58, 140, 48.62], [1, 0, 0], [0, -1, 0], `<defs><radialGradient id="${id}g" cx="50%" cy="40%" r="65%"><stop offset="0" stop-color="#ffb47a" stop-opacity="0.32"/><stop offset="1" stop-color="#ff8a5a" stop-opacity="0"/></radialGradient><linearGradient id="${id}l" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0d0" stop-opacity="0.45"/><stop offset="1" stop-color="#fff0d0" stop-opacity="0"/></linearGradient></defs>` +
          `<rect width="116" height="132" fill="url(#${id}g)">${an('opacity', '0.5;1;0.5', 7, 0, SPL(2))}</rect><rect width="116" height="16" fill="url(#${id}l)"/><path d="M6 0H22L4 132H0V8Z" fill="#ffffff" opacity="0.08"/><path d="M60 0H66L46 132H40Z" fill="#ffffff" opacity="0.05"/>`) : '';
        const ir = false ? [-36, 0, 36].map((x, i) => PLN(C, [x - 15, 54, -22.2], [1, 0, 0], [0, -1, 0], `<rect width="30" height="18" rx="0.4" fill="#ff4a2a" opacity="0.2" filter="url(#m12b1)">${an('opacity', '0.1;0.45;0.1', 5, -i * 1.2, SPL(2))}</rect>`)).join('') : '';
        const pan = fr ? PLN(C, [58.5, 104, 50.05], [1, 0, 0], [0, -1, 0], `<rect width="4" height="14" rx="0.6" fill="#0e0d0e" stroke="${GD}" stroke-width="0.2"/><text x="2" y="4.2" text-anchor="middle" font-family="Arial,sans-serif" font-size="1.5" fill="#ffc890">65°<animate attributeName="opacity" values="0.7;1;0.7" dur="3s" repeatCount="indefinite"/></text><circle cx="2" cy="8" r="1.2" fill="none" stroke="#ff7a4a" stroke-width="0.3"/><path d="M1.3 8h1.4M2 7.3v1.4" stroke="#ff7a4a" stroke-width="0.25"/><text x="2" y="12.4" text-anchor="middle" font-family="Arial,sans-serif" font-size="1" fill="${GD}">IR</text>`) : '';
        const sh = rep(3, i => { const p = C.P([40 + i * 4, 38, 26]); return `<path d="M${P2(p)}c${f1(-1.2 * k)} ${f1(-2 * k)} ${f1(1.2 * k)} ${f1(-3.4 * k)} 0 ${f1(-5.4 * k)}c${f1(-1.2 * k)} ${f1(-2 * k)} ${f1(1.2 * k)} ${f1(-3.4 * k)} 0 ${f1(-5.4 * k)}" stroke="#ffe0c0" stroke-width="${f1(0.5 * k)}" fill="none" opacity="0">${an('opacity', '0;0.5;0', 3.6, -i * 1.2)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-10 * k)}" dur="3.6s" begin="${-i * 1.2}s" repeatCount="indefinite"/></path>`; }).join('');
        return { under: shadow(C, 0, 0, 70, 56, 0.4), front: boards(1) + boards(-1) + ir + sh + glow + pan, bb: C.bb(6) }; };
      return D; };

    // BTH-087 CRYO-TO-THERMAL DUAL CHAMBER BIO-REJUVENATION POD (T5): two tall pearl-white capsules with champagne-gold bands and finials on an oval white
    // marble plinth, joined by a slim pearl column with a gold cap and a bio-readout. The left (cryo) chamber's window is frosted ice-blue and full of
    // swirling cold mist; the right (thermal) chamber's window glows amber with rising heat waves. Live: mist swirls and frost sparkles, heat waves rise,
    // the readouts pulse (-110°C / +65°C, BIO 98%), base light rings breathe mint and amber, and cold fog spills over the plinth from the cryo side.
    N.therm29e = S => { const PE = '#f6f4f0', GD = '#d6b06a', MI = '#bff0dc', LA = '#cdb8f5', CX = 33, A = 24, B = 22;
      const RG = [[6, 0, 0.62], [10, 0, 0.86], [18, 0, 0.97], [30, 0, 1], [112, 0, 1], [126, 0, 0.93], [136, 0, 0.74], [143, 0, 0.44], [146, 0, 0.12]];
      const D = SAU({ build: () => { const { cyl, ball } = K(), o = [];
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 0], a: 64, b: 52, n: 40, rings: [[0, 0, 0.97], [1.4, 0, 1], [4.8, 0, 1], [6, 0, 0.97]], col: '#f2eee8', mat: 'gloss' }));
          [-CX, CX].forEach(x => o.push(sol({ ax: 'y', sh: 'el', c: [x, 0], a: A, b: B, n: 32, rings: RG, col: PE, mat: 'gloss' }), cyl(x, 146, 0, 3.2, 1.6, GD, { n: 14, mat: 'metal' }), ball(x, 150, 0, 2, GD, { k: 4, n: 12, mat: 'metal' })));
          o.push(cyl(0, 6, 0, 6, 100, PE, { n: 18, mat: 'gloss' }), cyl(0, 106, 0, 7.4, 3, GD, { n: 18, mat: 'metal' }), ball(0, 113, 0, 4, GD, { k: 4, n: 14, mat: 'metal' }));
          return o; } });
      const arcE = (C, cx, cz, a, b, y, w, col, ex) => { let d = '', on = false; for (let i = 0; i <= 64; i++) { const t = i / 64 * 2 * PI, n = [Math.cos(t) / a, 0, Math.sin(t) / b];
          if (vdot(C, n) * a > 0.03) { d += (on ? 'L' : 'M') + PP(C, [cx + Math.cos(t) * a, y, cz + Math.sin(t) * b]); on = true; } else on = false; }
        return d ? `<path d="${d}" stroke="${col}" stroke-width="${f1(w * C.k)}" fill="none" stroke-linecap="round"${ex ? ' ' + ex : ''}/>` : ''; };
      D.fx = ctx => { const C = cam(ctx), R = rng('therm29e'), k = C.k, id = C.u('p87');
        const sAt = y => { for (let i = 1; i < RG.length; i++) if (y <= RG[i][0]) { const a = RG[i - 1], b = RG[i]; return a[2] + (b[2] - a[2]) * (y - a[0]) / (b[0] - a[0]); } return 0; };
        const pt = (x, t, y) => { const s = sAt(y) * 1.004; return [x + Math.cos(t) * A * s, y, Math.sin(t) * B * s]; };
        const visT = t => vdot(C, [Math.cos(t) / A, 0, Math.sin(t) / B]) * A > 0.08;
        const win = (x, cold, j) => { const ts = []; for (let i = 0; i <= 24; i++) { const t = PI / 2 - 0.8 + i / 24 * 1.6; if (visT(t)) ts.push(t); } if (ts.length < 6) return '';
          const y0 = 40, y1 = 118, bot = ts.map(t => PP(C, pt(x, t, y0))), topP = ts.slice().reverse().map(t => PP(C, pt(x, t, y1)));
          const d = `M${bot.join('L')}L${topP.join('L')}Z`, c = C.P(pt(x, PI / 2, 80)), cid = id + 'w' + j;
          let inner = cold ? `<rect x="${f1(c[0] - 40 * k)}" y="${f1(c[1] - 60 * k)}" width="${f1(80 * k)}" height="${f1(120 * k)}" fill="url(#${id}c)"/>` + rep(5, i => `<ellipse cx="${f1(c[0] + (R() - 0.5) * 20 * k)}" cy="${f1(c[1] + (R() - 0.5) * 50 * k)}" rx="${f1(10 * k)}" ry="${f1(6 * k)}" fill="#ffffff" opacity="0.4" filter="url(#m12b1)">${at('translate', `0 0;${f1(8 * k)} ${f1(-6 * k)};${f1(-6 * k)} ${f1(4 * k)};0 0`, 9 + i, -i * 1.7, SPL(3))}</ellipse>`).join('') +
            rep(12, i => { const px = c[0] + (R() - 0.5) * 26 * k, py = c[1] + (R() - 0.5) * 70 * k; return `<path d="M${f1(px - k)} ${f1(py)}H${f1(px + k)}M${f1(px)} ${f1(py - k)}V${f1(py + k)}" stroke="#ffffff" stroke-width="${f1(0.25 * k)}" opacity="0">${an('opacity', '0;0;1;0', 3 + (i % 3), -i * 0.4, KT('0;0.6;0.75;1'))}</path>`; }).join('')
            : `<rect x="${f1(c[0] - 40 * k)}" y="${f1(c[1] - 60 * k)}" width="${f1(80 * k)}" height="${f1(120 * k)}" fill="url(#${id}h)"><animate attributeName="opacity" values="0.8;1;0.8" dur="5s" repeatCount="indefinite"/></rect>` +
              rep(5, i => `<path d="M${f1(c[0] - 12 * k + i * 6 * k)} ${f1(c[1] + 40 * k)}q${f1(2 * k)} ${f1(-5 * k)} 0 ${f1(-10 * k)}t0 ${f1(-10 * k)}" stroke="#fff4d0" stroke-width="${f1(0.6 * k)}" fill="none" opacity="0">${an('opacity', '0;0.6;0', 4, -i * 0.8)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-40 * k)}" dur="4s" begin="${-i * 0.8}s" repeatCount="indefinite"/></path>`).join('');
          return `<clipPath id="${cid}"><path d="${d}"/></clipPath><g clip-path="url(#${cid})">${inner}<path d="M${f1(c[0] - 14 * k)} ${f1(c[1] - 60 * k)}l${f1(6 * k)} 0l${f1(-10 * k)} ${f1(120 * k)}l${f1(-6 * k)} 0Z" fill="#ffffff" opacity="0.18"/></g><path d="${d}" fill="none" stroke="${GD}" stroke-width="${f1(0.9 * k)}" stroke-linejoin="round"/>`; };
        const defs = `<defs><linearGradient id="${id}c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f2fbff"/><stop offset="1" stop-color="#9ccfe6"/></linearGradient><linearGradient id="${id}h" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd890"/><stop offset="1" stop-color="#ff8a46"/></linearGradient></defs>`;
        const bands = [-CX, CX].map(x => [30, 112].map(y => arcE(C, x, 0, A * sAt(y) + 0.15, B * sAt(y) + 0.15, y, 1.2, GD)).join('')).join('');
        const leds = arcE(C, -CX, 0, A * 0.95, B * 0.95, 8.4, 1, MI, `opacity="0.7"><animate attributeName="opacity" values="0.35;1;0.35" dur="4s" repeatCount="indefinite"/></path><path d="" fill="none"`) + arcE(C, CX, 0, A * 0.95, B * 0.95, 8.4, 1, '#ffc070', `opacity="0.7"><animate attributeName="opacity" values="0.35;1;0.35" dur="4s" begin="-2s" repeatCount="indefinite"/></path><path d="" fill="none"`);
        const rd = (x, txt, col) => vdot(C, [0, 0, 1]) > 0.2 ? PLN(C, [x - 7, 36, B * sAt(36) + 0.1], [1, 0, 0], [0, -1, 0], `<rect width="14" height="4.2" rx="1" fill="#1a1a20" opacity="0.88"/><text x="7" y="3.1" text-anchor="middle" font-family="Arial,sans-serif" font-size="2.6" fill="${col}">${txt}<animate attributeName="opacity" values="0.6;1;0.6" dur="2.6s" repeatCount="indefinite"/></text>`) : '';
        const col = vdot(C, [0, 0, 1]) > 0.2 ? PLN(C, [-3, 96, 6.02], [1, 0, 0], [0, -1, 0], `<rect width="6" height="22" rx="1" fill="#1a1a20"/><text x="3" y="4" text-anchor="middle" font-family="Arial,sans-serif" font-size="1.4" fill="${LA}">BIO</text><text x="3" y="7" text-anchor="middle" font-family="Arial,sans-serif" font-size="1.7" fill="#fff1a0">98%</text>` + rep(5, i => `<rect x="1.4" y="${9 + i * 2.4}" width="3.2" height="1.4" rx="0.4" fill="${[MI, LA, '#fff1a0', LA, MI][i]}">${an('opacity', '0.3;1;0.3', 2.4, -i * 0.4)}</rect>`).join('')) : '';
        const under = shadow(C, 0, 0, 66, 54, 0.35) + FL(C, 0.08, `<ellipse cx="-34" cy="0" rx="44" ry="34" fill="${MI}" opacity="0.25" filter="url(#m12b1)">${an('opacity', '0.12;0.32;0.12', 6, 0, SPL(2))}</ellipse><ellipse cx="34" cy="0" rx="44" ry="34" fill="#ffc070" opacity="0.2" filter="url(#m12b1)">${an('opacity', '0.1;0.28;0.1', 6, -3, SPL(2))}</ellipse>`);
        const fog = FL(C, 6.2, rep(5, i => `<ellipse cx="-34" cy="${f1(18 + (i % 2) * 6)}" rx="8" ry="4" fill="#ffffff" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.55;0', 7, -i * 1.4)}<animateTransform attributeName="transform" type="translate" values="${f1(-10 + i * 5)} 0;${f1(-16 + i * 8)} 22" dur="7s" begin="${-i * 1.4}s" repeatCount="indefinite"/></ellipse>`).join(''));
        const front = defs + bands + leds + win(-CX, 1, 0) + win(CX, 0, 1) + rd(-CX, '−110°C', '#cfefff') + rd(CX, '+65°C', '#ffd08a') + col + fog;
        return { under, front, bb: C.bb(8) }; };
      return D; };
  }

  // ======================= COUNTERTOP AMENITIES (BTH-008/028/048/068/088): small counter props, footprints kept (008/028 22 x 22 round, 048 32 x 22, 068/088 34 x 20) =======================
  { const K = () => X.K, sol = o => X.K.solid(o), { rod } = RD.H16;
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const xP = (x0, x1, z, y, r, col, mat) => sol({ ax: 'x', sh: 'el', c: [z, y], a: r, b: r, n: 12, rings: [[x0, 0], [x1, 0]], col, mat: mat || 'metal' });
    const zR = (x, y, z0, z1, r, col) => sol({ ax: 'z', sh: 'el', c: [x, y], a: r, b: r, n: 16, rings: [[z0, 0, 0.9], [z0 + 0.5, 0, 1], [z1 - 0.5, 0, 1], [z1, 0, 0.9]], col, mat: 'fab', soft: 1 });
    // speckles on the visible side of an upright round body (cx, cz, radius r(y)), y0..y1
    const speck = (C, R, cx, cz, r, y0, y1, n, cols) => rep(n, () => { const t = R() * 2 * PI, y = y0 + R() * (y1 - y0), nn = [Math.cos(t), 0, Math.sin(t)]; if (vdot(C, nn) < 0.25) return ''; const q = C.P([cx + nn[0] * (r(y) + 0.05), y, cz + nn[2] * (r(y) + 0.05)]);
      return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1((0.08 + R() * 0.14) * C.k)}" fill="${cols[Math.floor(R() * cols.length)]}" opacity="0.8"/>`; }).join('');
    // a glint that sweeps down the front of a round body
    const sweep = (C, cx, cz, r, y0, y1, T, b) => { const t = PI / 2 - 0.5, a = C.P([cx + Math.cos(t) * r, y1, cz + Math.sin(t) * r]), z = C.P([cx + Math.cos(t) * r, y0, cz + Math.sin(t) * r]);
      return `<path d="M${P2(a)}L${P2(z)}" stroke="#ffffff" stroke-width="${f1(0.5 * C.k)}" stroke-linecap="round" opacity="0">${an('opacity', '0;0;0.8;0', T, b || 0, KT('0;0.6;0.8;1'))}</path>`; };
    // a liquid drop forming at p and falling to y1
    const dropAt = (C, p, y1, T, col) => { const a = C.P(p), w = C.P([p[0], y1, p[2]]), k = C.k, KQ = ` keyTimes="0;0.7;0.86;0.87;1" dur="${T}s" repeatCount="indefinite"`;
      return `<ellipse cx="${f1(a[0])}" rx="${f1(0.38 * k)}" fill="${col}"><animate attributeName="ry" values="${f1(0.1 * k)};${f1(0.55 * k)};${f1(0.5 * k)};0;0"${KQ}/><animate attributeName="cy" values="${f1(a[1])};${f1(a[1] + 0.4 * k)};${f1(w[1])};${f1(w[1])};${f1(a[1])}"${KQ}/></ellipse>`; };

    // BTH-008 HALF-SQUEEZED TOOTHPASTE TUBE & BAR SOAP SLIVER (T1): a grimy translucent blue plastic soap dish with drain ridges holding a cracked, worn-thin
    // pink soap sliver (a stray hair stuck to it), and a crumpled half-squeezed toothpaste tube - flat and creased at the crimped end, a faded red band,
    // the cap off and lying aside, a worm of paste oozing from the nozzle. Live: a soap bubble swells and pops on the sliver, and a drip gathers on the dish.
    N.amen29a = S => { const D = { w: 22, d: 22, small: 1, round: 1, build: () => { const { box, cyl, ball } = K(), o = [];
        o.push(sol({ ax: 'y', sh: 'el', c: [-2, -4], a: 7.4, b: 4.8, n: 22, rings: [[0, 0, 0.84], [0.5, 0, 0.92], [2, 0, 1]], col: '#9cc0d2', mat: 'plastic' }));
        o.push(sol({ ax: 'y', sh: 'el', c: [-2.4, -4.2], a: 4.6, b: 2.8, n: 18, rings: [[2, 0, 0.9], [2.5, 0, 1], [2.9, 0, 0.82]], col: '#e8b4ac', mat: 'gloss' }));
        o.push(box(-10.4, 0, 5, 1.2, 0.6, 6.8, '#ececea', { r: 0.2, mat: 'plastic' }));
        o.push(sol({ ax: 'x', sh: 'el', c: [5, 0.7], a: 3.2, b: 0.7, n: 14, rings: [[-9.8, 0, 1], [-3, 0, 1]], col: '#f2f2ef', mat: 'plastic' }));
        o.push(sol({ ax: 'x', sh: 'el', c: [5, 1.7], a: 3, b: 1.7, n: 16, rings: [[-3, 0, 0.5], [-1.6, 0, 0.92], [3.6, 0, 1], [5.6, 0, 0.5]], col: '#f6f6f3', mat: 'plastic' }));
        o.push(xP(5.6, 7.2, 5, 1.7, 0.85, '#e8e8e4', 'plastic'), ball(7.4, 0, 5.2, 1.3, '#f4f8ff', { sx: 1.4, sy: 0.6, k: 4, n: 10, mat: 'gloss' }));
        o.push(cyl(8.6, 0, -7, 1.4, 1.6, '#d43a34', { n: 12, mat: 'plastic' }));
        return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('amen29a'), k = C.k;
        const under = shadow(C, 0, 0, 11, 9, 0.25) + FL(C, 0.05, `<ellipse cx="-2" cy="-4" rx="9" ry="6" fill="#a8b4b8" opacity="0.25"/><ellipse cx="9.4" cy="2.6" rx="1.6" ry="1" fill="#f4f8ff" opacity="0.7"/>`);
        const dish = FL(C, 2.03, rep(3, i => `<path d="M${-8.8 + i * 0.6} -5V-3M${4.6 - i * 0.6} -5V-3" stroke="#7aa2b8" stroke-width="0.25" opacity="0.7"/>`).join('') + `<ellipse cx="-8" cy="-2.2" rx="1.2" ry="0.7" fill="#8a7a5a" opacity="0.35"/><ellipse cx="3.6" cy="-6.6" rx="1" ry="0.6" fill="#8a7a5a" opacity="0.3"/>`);
        const soap = FL(C, 2.92, `<path d="M-5.6 -4.4l1.4 0.6l0.8 -0.8l1.2 0.5" stroke="#c88a82" stroke-width="0.2" fill="none"/><path d="M-4.4 -3.2C-2.6 -5.4 -1 -2.6 1 -4.8" stroke="#3a2a22" stroke-width="0.08" fill="none"/><ellipse cx="-1.2" cy="-5" rx="1.6" ry="0.6" fill="#ffffff" opacity="0.4"/>`);
        const tube = FL(C, 3.42, `<rect x="-0.6" y="3.2" width="3.8" height="3.6" fill="#d43a34" opacity="0.85"/><rect x="-0.6" y="4.5" width="3.8" height="0.5" fill="#3a6ac8" opacity="0.85"/><path d="M-2.4 3.6V6.4M3.8 3.4V6.6" stroke="#d8d8d4" stroke-width="0.2"/>`) + FL(C, 1.42, `<path d="M-9.6 3.2l1.6 1l-1 1l1.4 1.2M-7 2.8l1.2 1.4l-0.8 1.2l1 1.2M-5 3l0.8 1.6l-0.6 1.6" stroke="#b8b8b4" stroke-width="0.18" fill="none"/><text x="-6" y="5.6" text-anchor="middle" font-family="Arial,sans-serif" font-size="1" fill="#d43a34" opacity="0.6">SQUISH</text>`);
        const bub = (() => { const p = C.P([0.6, 2.9, -3.2]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1] - 0.6 * k)}" r="0" fill="#ffffff" fill-opacity="0.18" stroke="#ffffff" stroke-width="${f1(0.12 * k)}"><animate attributeName="r" values="0;${f1(1.2 * k)};${f1(1.3 * k)};0;0" dur="6s" keyTimes="0;0.7;0.78;0.79;1" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(p[1])};${f1(p[1] - 1.2 * k)};${f1(p[1] - 1.3 * k)};${f1(p[1])};${f1(p[1])}" dur="6s" keyTimes="0;0.7;0.78;0.79;1" repeatCount="indefinite"/></circle>`; })();
        const front = dish + soap + tube + bub + dropAt(C, [-2, 1.9, 0.75], 0.05, 5.4, '#c8dce4');
        return { under, front, bb: C.bb(4) }; };
      return D; };

    // BTH-028 MATCHING CERAMIC SOAP DISPENSER & TOOTHBRUSH TUMBLER (T2): a speckled oatmeal stoneware set on a matching oval tray - a pump dispenser (stamped
    // "savon", brushed-steel pump) and a tumbler holding a teal and a coral toothbrush. Live: a pearl of soap slowly gathers on the nozzle and drops, and a
    // glint slides down the glaze.
    N.amen29b = S => { const CE = '#efe6d6', ST = '#c8ccd0', RD1 = [[1.2, 0, 0.92], [2, 0, 1], [11, 0, 1], [13, 0, 0.8], [14, 0, 0.45]], RT = [[1.2, 0, 0.88], [1.8, 0, 0.95], [10, 0, 1], [10.4, 0, 0.97]];
      const D = { w: 22, d: 22, small: 1, round: 1, build: () => { const { box, cyl } = K(), o = [];
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 0], a: 10.2, b: 7.4, n: 26, rings: [[0, 0, 0.94], [0.5, 0, 1], [1.2, 0, 1]], col: CE, mat: 'gloss' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [-4.8, 0], a: 4, b: 4, n: 22, rings: RD1, col: CE, mat: 'gloss' }), cyl(-4.8, 14, 0, 1.3, 2.2, ST, { n: 12, mat: 'brush' }), cyl(-4.8, 16.2, 0, 0.55, 2, ST, { n: 8, mat: 'brush' }), box(-4.8, 18.2, 0.6, 2.2, 1.5, 4.4, ST, { r: 0.6, mat: 'brush' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [5, 0], a: 3.6, b: 3.6, n: 20, rings: RT, col: CE, mat: 'gloss' }));
          [[[4.2, 10.6, -0.4], [1.8, 22, -1.2], '#3aa8a0'], [[5.8, 10.6, 0.4], [8.6, 21, 1.2], '#f08a6a']].forEach(([a, b, c]) => { const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], L = Math.hypot(...d), u = d.map(v => v / L);
            o.push(rod(a, b, 0.45, c, { mat: 'plastic' }), rod(b, [b[0] + u[0] * 3.2, b[1] + u[1] * 3.2, b[2] + u[2] * 3.2], 0.62, c, { mat: 'plastic' }), rod([b[0] + 0.1, b[1] + 0.2, b[2] + 0.75], [b[0] + u[0] * 3 + 0.1, b[1] + u[1] * 3 + 0.2, b[2] + u[2] * 3 + 0.75], 0.5, '#f4f6f8', { mat: 'plastic' })); });
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('amen29b'), k = C.k, sA = (G, y) => { for (let i = 1; i < G.length; i++) if (y <= G[i][0]) { const a = G[i - 1], b = G[i]; return a[2] + (b[2] - a[2]) * (y - a[0]) / (b[0] - a[0]); } return 0; };
        const sp = speck(C, R, -4.8, 0, y => 4 * sA(RD1, y), 2, 13, 60, ['#8a7a68', '#5a4a3a', '#b0a088']) + speck(C, R, 5, 0, y => 3.6 * sA(RT, y), 1.8, 10, 40, ['#8a7a68', '#5a4a3a', '#b0a088']) + FL(C, 1.22, rep(30, () => `<circle cx="${f1((R() - 0.5) * 18)}" cy="${f1((R() - 0.5) * 12)}" r="${f1(0.08 + R() * 0.12)}" fill="#8a7a68" opacity="0.7"/>`).join(''));
        const cup = FL(C, 10.43, `<circle cx="5" cy="0" r="3.1" fill="#6a5e50"/><circle cx="5" cy="0.4" r="2.7" fill="#4a4036"/>`);
        const stamp = vdot(C, [0, 0, 1]) > 0.2 ? PLN(C, [-7.2, 9, 4.03], [1, 0, 0], [0, -1, 0], `<text x="2.4" y="1.4" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-size="1.5" fill="#8a6a4a">savon</text>`) : '';
        const front = sp + cup + stamp + sweep(C, -4.8, 0, 4.02, 3, 11, 6, 0) + sweep(C, 5, 0, 3.62, 2.4, 9, 6, -3) + dropAt(C, [-4.8, 18.2, 2.9], 1.25, 7, '#f4e8d0');
        return { under: shadow(C, 0, 0, 11, 8, 0.25), front, bb: C.bb(4) }; };
      return D; };

    // BTH-048 REED DIFFUSER, VOLCANIC PUMICE STONE & ROLLED HAND TOWELS (T3): a teak tray holding a smoked-glass reed diffuser (black collar, minimal kraft label)
    // with a fan of rattan reeds, a grey porous volcanic pumice stone, three rolled waffle hand towels in oatmeal, white and sage, and a eucalyptus sprig.
    // Live: faint scent curls rise from the reed tips and an oil glint creeps up a reed.
    N.amen29c = S => { const TK = '#c9a37a', GL = '#4a4038';
      const D = { w: 32, d: 22, small: 1, build: () => { const { box, cyl, ball } = K(), o = [];
          o.push(box(0, 0, 0, 30, 1.2, 20, TK, { r: 0.5, mat: 'wood' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [-9, -3], a: 3.8, b: 3.8, n: 20, rings: [[1.2, 0, 0.95], [1.6, 0, 1], [7, 0, 1], [8.4, 0, 0.7], [9, 0, 0.36]], col: GL, mat: 'gloss' }), cyl(-9, 9, -3, 1.4, 1.4, '#1e1e1e', { n: 12, mat: 'matte' }));
          [[-15.6, 26, -7], [-13.4, 27.6, -1], [-10.6, 28.4, -8], [-7.4, 28, 0.6], [-4.6, 26.6, -6], [-3.2, 25, -1.6]].forEach(([x, y, z], i) => { const a = [-9 + (x + 9) * 0.04, 10.5, -3 + (z + 3) * 0.04]; o.push(rod(a, [x, y, z], 0.22, i % 2 ? '#c8a878' : '#2a2420', { mat: 'wood' })); });
          o.push(ball(-1.4, 1.2, 5.6, 3.2, '#b9b4aa', { sx: 1.25, sy: 0.55, k: 5, n: 14, mat: 'matte' }));
          o.push(zR(5.4, 4, -7, 7, 2.8, '#ece2d0'), zR(11, 4, -7, 7, 2.8, '#f8f6f0'), zR(8.2, 8.4, -6.6, 6.6, 2.8, '#b8c8b0'));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('amen29c'), k = C.k, fr = vdot(C, [0, 0, 1]) > 0.2;
        const holes = rep(18, () => { const a = R() * 2 * PI, d = R() * 0.8, y = 1.2 + 3.52 * Math.sqrt(1 - d * d) * 0.99, n = [Math.cos(a) * d, Math.sqrt(1 - d * d), Math.sin(a) * d]; if (vdot(C, n) < 0.2) return ''; const q = C.P([-1.4 + Math.cos(a) * d * 4, y, 5.6 + Math.sin(a) * d * 3.2]);
          return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1((0.12 + R() * 0.2) * k)}" ry="${f1((0.1 + R() * 0.14) * k)}" fill="#6a665e" opacity="0.8"/>`; }).join('');
        const waf = [[5.4, 4, '#d8cebc', 7.03], [11, 4, '#e4e2dc', 7.03], [8.2, 8.4, '#a0b098', 6.63]].map(([x, y, c, ze]) => fr ? PLN(C, [x, y + 2.8, ze], [1, 0, 0], [0, -1, 0], `<circle r="2.6" fill="none" stroke="${c}" stroke-width="0.35"/><circle r="1.7" fill="none" stroke="${c}" stroke-width="0.3"/><circle r="0.8" fill="none" stroke="${c}" stroke-width="0.25"/>`) : '').join('');
        const lab = fr ? PLN(C, [-11, 6.6, 0.85], [1, 0, 0], [0, -1, 0], `<rect width="4" height="3.4" rx="0.2" fill="#d8c09a"/><text x="2" y="1.5" text-anchor="middle" font-family="Georgia,serif" font-size="0.75" fill="#3a2a1a">CEDAR</text><text x="2" y="2.6" text-anchor="middle" font-family="Georgia,serif" font-size="0.55" fill="#3a2a1a">&amp; SAGE</text>`) : '';
        const euc = vdot(C, [0, 0, 1]) < 0 ? '' : FL(C, 1.25, `<path d="M-14.4 8.4Q-11 6.6 -7.6 8.4" stroke="#7a8a6a" stroke-width="0.3" fill="none"/>` + rep(4, i => `<ellipse cx="${f1(-13.6 + i * 1.7)}" cy="${f1(7.6 + (i % 2) * 1.2)}" rx="1" ry="0.8" fill="#9ab4a4" stroke="#7a9a8a" stroke-width="0.15"/>`).join(''));
        const scent = [[-10.6, 28.4, -8], [-7.4, 28, 0.6], [-13.4, 27.6, -1]].map((p, i) => { const q = C.P(p); return `<path d="M${P2(q)}c${f1(-1.2 * k)} ${f1(-1.6 * k)} ${f1(1.2 * k)} ${f1(-3 * k)} 0 ${f1(-4.6 * k)}c${f1(-1.2 * k)} ${f1(-1.6 * k)} ${f1(1.2 * k)} ${f1(-3 * k)} 0 ${f1(-4.6 * k)}" stroke="#d8c8e8" stroke-width="${f1(0.35 * k)}" fill="none" opacity="0">${an('opacity', '0;0.55;0', 6, -i * 2)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-5 * k)}" dur="6s" begin="${-i * 2}s" repeatCount="indefinite"/></path>`; }).join('');
        const gl = (() => { const a = C.P([-8.8, 10.6, -2.8]), b = C.P([-7.4, 28, 0.6]); return `<circle r="${f1(0.3 * k)}" fill="#fff4d8"><animate attributeName="cx" values="${f1(a[0])};${f1(b[0])}" dur="8s" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(a[1])};${f1(b[1])}" dur="8s" repeatCount="indefinite"/>${an('opacity', '0;0.9;0.9;0', 8, 0, KT('0;0.1;0.85;1'))}</circle>`; })();
        const front = holes + waf + lab + euc + scent + gl + sweep(C, -9, -3, 3.82, 2, 7, 7, 0);
        return { under: shadow(C, 0, 0, 16, 11, 0.25), front, bb: C.bb(4) }; };
      return D; };
  }

  // ---- countertop amenities batch 2: 068 (34 x 20) / 088 (34 x 20)
  { const K = () => X.K, sol = o => X.K.solid(o), { rod } = RD.H16, { sAt, rip } = RD.H29T;
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const xP = (x0, x1, z, y, r, col, mat) => sol({ ax: 'x', sh: 'el', c: [z, y], a: r, b: r, n: 12, rings: [[x0, 0], [x1, 0]], col, mat: mat || 'metal' });
    const zC = (x, y, z0, z1, r, col, mat) => sol({ ax: 'z', sh: 'el', c: [x, y], a: r, b: r, n: 14, rings: [[z0, 0, 0.9], [z0 + 0.3, 0, 1], [z1 - 0.3, 0, 1], [z1, 0, 0.9]], col, mat });
    // oval() from the tubs with an offset centre: solid lower body up to wy + glued water/inner plate + N wall quads above
    const ovalC = (o, cx, cz, A, B, th, N, rings, col, mat, wy, wc, ex, wex) => { const E = (a, b, t) => [cx + a * Math.cos(t), cz + b * Math.sin(t)], T = i => (i + 0.5) / N * 2 * PI;
      rings = rings.map(r => [r[0], 0, r[2]]); const sw = sAt(rings, wy);
      const lo = rings.filter(r => r[0] < wy).concat([[wy, 0, sw]]), hi = [[wy, 0, sw]].concat(rings.filter(r => r[0] > wy));
      // scale about the centre: pts are given relative to c, so pass c and local pts
      const L = (a, b, t) => [a * Math.cos(t), b * Math.sin(t)];
      const body = sol(Object.assign({ ax: 'y', sh: 'poly', c: [cx, cz], pts: rep(N, i => L(A, B, T(i))), rings: lo, col, mat }, ex || {})); o.push(body);
      for (let i = 0; i < N; i++) { const t0 = T(i), t1 = T(i + 1); o.push(sol(Object.assign({ ax: 'y', sh: 'poly', c: [cx, cz], pts: [L(A, B, t0), L(A, B, t1), L(A - th, B - th, t1), L(A - th, B - th, t0)], rings: hi, col, mat, noOut: 1 }, ex || {}))); }
      if (wc) { const W = sol(Object.assign({ ax: 'y', sh: 'poly', c: [cx, cz], pts: rep(N, i => L(A - th, B - th, T(i))), rings: [[wy, 0, sw], [wy + 0.12, 0, sw]], col: wc, mat: 'gloss', emit: 1, noOut: 1 }, wex || {})); W.par = body; o.push(W); }
      return body; };
    const sweep = (C, cx, cz, r, y0, y1, T, b, tt) => { const t = tt == null ? PI / 2 - 0.5 : tt, a = C.P([cx + Math.cos(t) * r, y1, cz + Math.sin(t) * r]), z = C.P([cx + Math.cos(t) * r, y0, cz + Math.sin(t) * r]);
      return `<path d="M${P2(a)}L${P2(z)}" stroke="#ffffff" stroke-width="${f1(0.45 * C.k)}" stroke-linecap="round" opacity="0">${an('opacity', '0;0;0.85;0', T, b || 0, KT('0;0.6;0.8;1'))}</path>`; };
    // a label band wrapped round the visible front of an upright cylinder (screen-space, sampled on the surface)
    const wrapL = (C, cx, cz, r, y0, y1, half, fill, ex) => { const ts = []; for (let i = 0; i <= 16; i++) { const t = PI / 2 - half + i / 16 * 2 * half; if (vdot(C, [Math.cos(t), 0, Math.sin(t)]) > 0.06) ts.push(t); } if (ts.length < 4) return '';
      const P = (t, y) => PP(C, [cx + Math.cos(t) * (r + 0.04), y, cz + Math.sin(t) * (r + 0.04)]);
      return `<path d="M${ts.map(t => P(t, y0)).join('L')}L${ts.slice().reverse().map(t => P(t, y1)).join('L')}Z" fill="${fill}"${ex || ''}/>`; };
    const lineL = (C, cx, cz, r, y, half, col, w) => { const ts = []; for (let i = 0; i <= 10; i++) { const t = PI / 2 - half + i / 10 * 2 * half; if (vdot(C, [Math.cos(t), 0, Math.sin(t)]) > 0.06) ts.push(t); } if (ts.length < 3) return '';
      return `<path d="M${ts.map(t => PP(C, [cx + Math.cos(t) * (r + 0.05), y, cz + Math.sin(t) * (r + 0.05)])).join('L')}" stroke="${col}" stroke-width="${f1(w * C.k)}" fill="none"/>`; };

    // BTH-068 ARTISANAL AMBER GLASS APOTHECARY SET & JADE ROLLER (T4): a honed travertine tray holding two amber glass pump bottles (black pumps, minimal
    // cream labels with fine black type - hand wash and balm), a small amber dropper bottle of face oil, and a double-ended jade facial roller in a gold frame
    // lying in front. Live: honey-gold light drifts through the amber glass, an amber caustic shimmers on the tray, and a sheen slides over the jade.
    N.amen29d = S => { const AM = '#9a5418', BK = '#1c1a1a', JD = '#5fae8a', GD = '#d6b06a';
      const BT = [[-11, -3.4, 3.2, 14], [-4.4, -4.6, 2.8, 11.4], [2, -5.2, 2.1, 6.2]];
      const D = { w: 34, d: 20, small: 1, build: () => { const { box, cyl } = K(), o = [];
          o.push(box(0, 0, 0, 32, 1, 18, '#e8dcc6', { r: 0.6, mat: 'matte' }));
          BT.forEach(([x, z, r, h], i) => { o.push(sol({ ax: 'y', sh: 'el', c: [x, z], a: r, b: r, n: 22, rings: [[1, 0, 0.94], [1.5, 0, 1], [1 + h - 1.6, 0, 1], [1 + h - 0.4, 0, 0.66], [1 + h, 0, 0.4]], col: AM, mat: 'gloss' }));
            const ty = 1 + h; if (i < 2) o.push(cyl(x, ty, z, 1.3, 1.4, BK, { n: 12, mat: 'matte' }), cyl(x, ty + 1.4, z, 0.45, 1.8, BK, { n: 8, mat: 'matte' }), box(x, ty + 3.2, z + 0.7, 1.8, 1.4, 3.6, BK, { r: 0.5, mat: 'matte' }));
            else o.push(cyl(x, ty, z, 1.1, 1.6, BK, { n: 12, mat: 'matte' }), sol({ ax: 'y', sh: 'el', c: [x, z], a: 0.9, b: 0.9, n: 10, rings: [[ty + 1.6, 0, 1], [ty + 3, 0, 1], [ty + 3.6, 0, 0.6]], col: '#2a2626', mat: 'plastic' })); });
          o.push(zC(4, 2.6, 1.2, 7.4, 1.6, JD, 'gloss'), zC(16, 1.9, 3, 5.6, 0.9, JD, 'gloss'));
          [0.9, 7.7].forEach(z => o.push(rod([4, 2.6, z], [9, 2.3, 4.3], 0.18, GD, { mat: 'metal' })));
          o.push(rod([15, 1.9, 2.7], [15, 1.9, 5.9], 0.16, GD, { mat: 'metal' }), xP(9.4, 14.6, 4.3, 2.1, 0.75, JD, 'gloss'), xP(9, 9.4, 4.3, 2.2, 0.82, GD), xP(14.6, 15, 4.3, 2.0, 0.78, GD));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), k = C.k, R = rng('amen29d');
        let fx = '';
        BT.forEach(([x, z, r, h], i) => { const yl = 1 + h * 0.36, yh = 1 + h * (i < 2 ? 0.78 : 0.8);
          fx += wrapL(C, x, z, r, yl, yh, 0.85, '#f2ead8') + lineL(C, x, z, r, yh - (yh - yl) * 0.22, 0.45, '#1e1c1a', 0.32) + rep(3, j => lineL(C, x, z, r, yl + (yh - yl) * (0.2 + j * 0.14), 0.32 - j * 0.06, '#5a544c', 0.12)).join('');
          fx += sweep(C, x, z, r + 0.02, 1.8, 1 + h - 1.8, 7, -i * 2.3) + lineL(C, x, z, r, 1 + h * 0.9, 0.9, '#ffd890', 0.25); });
        const caus = vdot(C, [0, 0, 1]) > 0 ? FL(C, 1.03, `<ellipse cx="-8" cy="3.4" rx="5" ry="1.6" fill="#ffb050" opacity="0.18" filter="url(#m12b1)">${an('opacity', '0.08;0.28;0.08', 6, 0, SPL(2))}</ellipse>`) : '';
        const jade = (() => { const a = C.P([4, 4.2, 1.6]), b = C.P([4, 4.2, 7]); return `<path d="M${P2(a)}L${P2(b)}" stroke="#d8fff0" stroke-width="${f1(0.4 * k)}" stroke-linecap="round" opacity="0">${an('opacity', '0;0.7;0', 5, 0, SPL(2))}</path>`; })();
        return { under: shadow(C, 0, 0, 17, 10, 0.25), front: caus + fx + jade, bb: C.bb(4) }; };
      return D; };

    // BTH-088 24K GOLD ELIXIR DISPENSERS, FLOATING LOTUS CANDLES & CRYSTAL SINGING BOWL (T5): a white marble tray with a gold edge: two faceted crystal
    // dispensers of golden elixir with 24k gold collars and pumps and tiny gold "ELIXIR" plaques; a frosted quartz singing bowl on a deep plum silk ring
    // cushion with a suede mallet; and a clear glass bowl of water with two blush lotus candles floating in it. Live: gold flakes drift and twinkle in the
    // elixir, the lotus flames flicker with ripples, and soft sound rings pulse out of the singing bowl.
    N.amen29e = S => { const GD = '#e2b14a', MB = '#f6f3ee', EL = '#f2c860';
      const DP = [[-13.4, -3.6, 2.8, 12.4], [-7.4, -4.8, 2.5, 10.4]], SB = [1.4, 4.8], LB = [11.6, -4.8];
      const oct = r => rep(8, i => { const t = (i + 0.5) / 8 * 2 * PI; return [Math.cos(t) * r, Math.sin(t) * r]; });
      const D = { w: 34, d: 20, small: 1, build: () => { const { box, cyl, ball } = K(), o = [];
          const T = box(0, 0, 0, 33, 1.2, 19, MB, { r: 0.5, mat: 'gloss' }); o.push(T); glue(o, T, [box(0, 0, 9.52, 33, 1.2, 0.1, GD, { r: 0, noOut: 1, mat: 'metal' }), box(16.52, 0, 0, 0.1, 1.2, 19, GD, { r: 0, noOut: 1, mat: 'metal' }), box(-16.52, 0, 0, 0.1, 1.2, 19, GD, { r: 0, noOut: 1, mat: 'metal' })]);
          DP.forEach(([x, z, r, h]) => { const ty = 1.2 + h; o.push(sol({ ax: 'y', sh: 'poly', c: [x, z], pts: oct(r), rings: [[1.2, 0, 0.94], [1.8, 0, 1], [ty - 1.6, 0, 1], [ty - 0.5, 0, 0.6], [ty, 0, 0.42]], col: EL, mat: 'gloss', emit: 1 }));
            o.push(cyl(x, ty, z, 1.3, 1.2, GD, { n: 12, mat: 'metal' }), cyl(x, ty + 1.2, z, 0.42, 1.6, GD, { n: 8, mat: 'metal' }), box(x, ty + 2.8, z + 0.7, 1.7, 1.3, 3.4, GD, { r: 0.5, mat: 'metal' })); });
          o.push(ball(SB[0], 1.2, SB[1], 4.3, '#5a2448', { sy: 0.34, k: 4, n: 18, mat: 'fab', soft: 1 }));
          ovalC(o, SB[0], SB[1], 4.8, 4.8, 0.45, 32, [[4.3, 0, 0.62], [5.1, 0, 0.84], [6.6, 0, 0.96], [8.8, 0, 1], [9.4, 0, 0.99]], '#f2f4f6', 'gloss', 5.1, '#e6eaf0', null, { emit: 0 });
          o.push(xP(-14, -8.6, 6.4, 1.62, 0.42, '#c89a6a', 'wood'), xP(-8.6, -6, 6.4, 1.95, 0.75, '#8a6a58', 'fab'));
          ovalC(o, LB[0], LB[1], 4.6, 4.6, 0.3, 20, [[1.2, 0, 0.8], [1.8, 0, 0.94], [3.4, 0, 1], [5.6, 0, 1.04]], '#e8f4f6', 'gloss', 3.6, '#bfe0e8', { op: 0.4 });
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('amen29e'), k = C.k, fr = vdot(C, [0, 0, 1]) > 0.15;
        let fx = '';
        DP.forEach(([x, z, r, h], i) => { const q = C.P([x, 1.2 + h * 0.5, z + r * 0.8]);
          fx += rep(9, j => { const px = q[0] + (R() - 0.5) * r * 1.3 * k, py = q[1] + (R() - 0.5) * h * 0.7 * k; return `<rect x="${f1(px)}" y="${f1(py)}" width="${f1(0.32 * k)}" height="${f1(0.22 * k)}" fill="#fff6c8" opacity="0.2" transform="rotate(${Math.floor(R() * 90)} ${f1(px)} ${f1(py)})">${an('opacity', '0.15;1;0.15', 2 + (j % 4) * 0.7, -j * 0.5)}<animateTransform attributeName="transform" type="translate" additive="sum" values="0 0;0 ${f1(0.8 * k)};0 0" dur="${5 + j % 3}s" repeatCount="indefinite"/></rect>`; }).join('');
          rep(8, j => { const t = (j + 0.5) / 8 * 2 * PI, n0 = [Math.cos(t - PI / 8), 0, Math.sin(t - PI / 8)], n1 = [Math.cos(t + PI / 8), 0, Math.sin(t + PI / 8)]; if (vdot(C, n0) < 0.05 || vdot(C, n1) < 0.05) return; const rr = r * 1.004;
            fx += `<path d="M${PP(C, [x + Math.cos(t) * rr, 2, z + Math.sin(t) * rr])}L${PP(C, [x + Math.cos(t) * rr, 1.2 + h - 1.7, z + Math.sin(t) * rr])}" stroke="#fffbe8" stroke-width="${f1(0.22 * k)}" opacity="0.75"/>`; });
          if (fr) fx += PLN(C, [x - 1.3, 1.2 + h * 0.36, z + r * 0.93 + 0.05], [1, 0, 0], [0, -1, 0], `<rect width="2.6" height="1.1" rx="0.2" fill="${GD}"/><text x="1.3" y="0.8" text-anchor="middle" font-family="Georgia,serif" font-size="0.6" fill="#5a3a10">ELIXIR</text>`); });
        // floating lotus candles (fx on the water, seen through the glass) + ripples
        const lot = (x, z, s, i) => { const y = 3.64, rose = (rr, n, c, a0, yy) => FL(C, yy, rep(n, j => { const t = a0 + j / n * 2 * PI, px = x + Math.cos(t) * rr * 0.6, pz = z + Math.sin(t) * rr * 0.6;
            return `<ellipse cx="${f1(px)}" cy="${f1(pz)}" rx="${f1(rr * 0.55)}" ry="${f1(rr * 0.28)}" fill="${c}" stroke="#d88aa0" stroke-width="0.08" transform="rotate(${f1(t * 180 / PI)} ${f1(px)} ${f1(pz)})"/>`; }).join(''));
          const fl = C.P([x, y + 1.6, z]);
          return rose(2.2 * s, 8, '#f6c8d4', 0, y) + rose(1.6 * s, 6, '#fbe0e6', 0.4, y + 0.5) + FL(C, y + 0.9, `<circle cx="${f1(x)}" cy="${f1(z)}" r="${f1(0.75 * s)}" fill="#fbf6ea" stroke="#e0d4bc" stroke-width="0.08"/>`) +
            `<g transform="translate(${P2(fl)}) scale(${n4(k * s)})"><ellipse cx="0" cy="-0.4" rx="1.6" ry="2" fill="#ffd27a" opacity="0.25" filter="url(#m12b1)"/><g><animateTransform attributeName="transform" type="scale" values="1 1;0.9 1.14;1.06 0.92;1 1" dur="${f1(1.3 + i * 0.4)}s" repeatCount="indefinite"/><path d="M0 0.4Q-0.55 -0.4 0 -1.8Q0.55 -0.4 0 0.4Z" fill="#ffb43a"/><path d="M0 0.2Q-0.25 -0.3 0 -1Q0.25 -0.3 0 0.2Z" fill="#fff4c8"/></g></g>`; };
        const lotus = lot(LB[0] - 1.6, LB[1] - 1.2, 0.95, 0) + lot(LB[0] + 1.7, LB[1] + 1.4, 0.8, 1) + rip(C, [LB[0] - 1.6, 3.62, LB[1] - 1.2], 4.2, 0, 0.5) + rip(C, [LB[0] + 1.7, 3.62, LB[1] + 1.4], 5, 2, 0.45);
        const rings = FL(C, 9.4, rep(3, i => `<circle cx="${SB[0]}" cy="${SB[1]}" r="5" fill="none" stroke="#ffffff" stroke-width="0.22" opacity="0"><animate attributeName="r" values="5;9.4" dur="4.5s" begin="${-i * 1.5}s" repeatCount="indefinite"/>${an('opacity', '0.75;0', 4.5, -i * 1.5)}</circle>`).join(''));
        const bowl = sweep(C, SB[0], SB[1], 4.8, 5, 9, 6, 0) + sweep(C, LB[0], LB[1], 4.75, 1.8, 5.2, 7, -3, PI / 2 + 0.6);
        const under = shadow(C, 0, 0, 17, 10, 0.25);
        return { under, front: fx + bowl + lotus + rings, bb: C.bb(4) }; };
      return D; };
  }

  // ======================= PET BATH ZONE (BTH-011/031/051/071/091): user Nov 3 - "make it 3 and as the tier goes up, make it more and make the pool bigger".
  // Bathing pools at full scale (zs 1, no spec shrink): seats 3 / 4 / 5 / 6 / 7 (act 'bath'), each pool bigger than the last. A creature is ~70 units wide,
  // so seats are >= ~60 apart side by side (rows ~40 apart in depth). =======================
  { const K = () => X.K, sol = o => X.K.solid(o), { rod } = RD.H16, { sAt, rip, duck, foam } = RD.H29T;
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const POOL = (w, d, h, seats, cx) => ({ w, d, act: 'bath', inside: [cx || 0, h, 0], seats: seats.map(([x, z]) => ({ x, z, h, k: 'bath' })) });
    const ovalC = (o, cx, cz, A, B, th, N, rings, col, mat, wy, wc, ex, wex) => { const T = i => (i + 0.5) / N * 2 * PI, L = (a, b, t) => [a * Math.cos(t), b * Math.sin(t)];
      rings = rings.map(r => [r[0], 0, r[2]]); const sw = sAt(rings, wy);
      const lo = rings.filter(r => r[0] < wy).concat([[wy, 0, sw]]), hi = [[wy, 0, sw]].concat(rings.filter(r => r[0] > wy));
      const body = sol(Object.assign({ ax: 'y', sh: 'poly', c: [cx, cz], pts: rep(N, i => L(A, B, T(i))), rings: lo, col, mat }, ex || {})); o.push(body);
      for (let i = 0; i < N; i++) { const t0 = T(i), t1 = T(i + 1); o.push(sol(Object.assign({ ax: 'y', sh: 'poly', c: [cx, cz], pts: [L(A, B, t0), L(A, B, t1), L(A - th, B - th, t1), L(A - th, B - th, t0)], rings: hi, col, mat, noOut: 1 }, ex || {}))); }
      if (wc) { const W = sol(Object.assign({ ax: 'y', sh: 'poly', c: [cx, cz], pts: rep(N, i => L(A - th, B - th, T(i))), rings: [[wy, 0, sw], [wy + 0.12, 0, sw]], col: wc, mat: 'gloss', emit: 1, noOut: 1 }, wex || {})); W.par = body; o.push(W); }
      return body; };
    // is a point on the water (x, wy, z) seen over the near rim of an ellipse (cx, cz, a, b) at rim height ry? (front-layer water decals must not paint over the wall)
    const wVis = (C, cx, cz, a, b, wy, ry, x, z) => { let dx = C.v[0], dz = C.v[2]; const L = Math.hypot(dx, dz); if (L < 0.05) return true; dx /= L; dz /= L;
      const px = x - cx, pz = z - cz, A2 = dx * dx / (a * a) + dz * dz / (b * b), B2 = 2 * (px * dx / (a * a) + pz * dz / (b * b)), C2 = px * px / (a * a) + pz * pz / (b * b) - 1, D2 = B2 * B2 - 4 * A2 * C2;
      if (D2 < 0) return true; const t = (-B2 + Math.sqrt(D2)) / (2 * A2), q = C.P([x + t * dx, ry, z + t * dz]), p = C.P([x, wy, z]); return p[1] < q[1] - 0.6 * C.k; };
    const arcE = (C, cx, cz, a, b, y, w, col, op, ex) => { let d = '', on = false; for (let i = 0; i <= 72; i++) { const t = i / 72 * 2 * PI, n = [Math.cos(t) / a, 0, Math.sin(t) / b];
        if (vdot(C, n) * a > 0.03) { d += (on ? 'L' : 'M') + PP(C, [cx + Math.cos(t) * a, y, cz + Math.sin(t) * b]); on = true; } else on = false; }
      return d ? `<path d="${d}" stroke="${col}" stroke-width="${f1(w * C.k)}" fill="none" stroke-linecap="round" opacity="${op || 1}"${ex || ''}/>` : ''; };
    const facet = (C, cx, cz, A, B, N, i, y, u0, svg, th) => { const t0 = (i + 0.5) / N * 2 * PI, t1 = (i + 1.5) / N * 2 * PI, a = [cx + A * Math.cos(t0), cz + B * Math.sin(t0)], b = [cx + A * Math.cos(t1), cz + B * Math.sin(t1)];
      const n = [b[1] - a[1], 0, -(b[0] - a[0])], nl = Math.hypot(n[0], n[2]); if (vdot(C, n) / nl < (th == null ? 0.15 : th)) return ''; const Lf = Math.hypot(b[0] - a[0], b[1] - a[1]), U = [(b[0] - a[0]) / Lf, 0, (b[1] - a[1]) / Lf];
      return PLN(C, [a[0] + U[0] * u0 + n[0] / nl * 0.06, y, a[1] + U[2] * u0 + n[2] / nl * 0.06], U, [0, -1, 0], svg); };
    const steam = (C, p, n, T, h, w, sd) => { const R = rng(sd), k = C.k; return rep(n, i => { const q = C.P([p[0] + (R() - 0.5) * w, p[1], p[2] + (R() - 0.5) * w * 0.6]), b = -i * T / n;
        return `<path d="M${P2(q)}c${f1(-2.4 * k)} ${f1(-3 * k)} ${f1(2.4 * k)} ${f1(-6 * k)} 0 ${f1(-9 * k)}c${f1(-2.4 * k)} ${f1(-3 * k)} ${f1(2.4 * k)} ${f1(-6 * k)} 0 ${f1(-9 * k)}" stroke="#ffffff" stroke-width="${f1(1.8 * k)}" stroke-linecap="round" fill="none" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.5;0', T, b)}<animateTransform attributeName="transform" type="translate" values="0 0;${f1((R() - 0.5) * 6 * k)} ${f1(-h * k)}" dur="${T}s" begin="${n4(b)}s" repeatCount="indefinite"/></path>`; }).join(''); };
    const bubbles = (C, L, sd, sz) => { const R = rng(sd), k = C.k; return L.map(([x, y, z]) => { const p = C.P([x, y, z]), T = 3 + R() * 3, r = (0.8 + R() * 1.2) * k * (sz || 1);
        return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="0" fill="#ffffff" fill-opacity="0.15" stroke="#ffffff" stroke-width="${f1(0.18 * k)}"><animate attributeName="r" values="0;${f1(r)};${f1(r * 1.1)};0;0" dur="${f1(T)}s" begin="${f1(-R() * T)}s" keyTimes="0;0.6;0.7;0.71;1" repeatCount="indefinite"/></circle>`; }).join(''); };
    // random water points away from the seats (creatures cover those)
    const freePts = (R, n, cx, a, b, seats, gap) => { const out = []; for (let t = 0; t < n * 30 && out.length < n; t++) { const u = (R() * 2 - 1) * 0.9, v = (R() * 2 - 1) * 0.9; if (u * u + v * v > 0.8) continue; const x = cx + u * a, z = v * b;
        if (seats.every(([sx, sz]) => Math.hypot(x - sx, (z - sz) * 1.4) > (gap || 40))) out.push([x, z]); } return out; };

    // BTH-011 PLASTIC WASHBASIN & RUBBER DUCKIE (T1, 3 seats): a big cheap faded-blue plastic washtub on the floor, scuffed and grimy outside, with moulded grip slots
    // at the ends and a crack patched with silver duct tape; soapy water with foam patches, a rubber duck and a pink squeaky bone floating. Live: the duck bobs,
    // bubbles pop on the foam, ripples spread and a drip seeps from the taped crack into a puddle.
    N.pet29a = S => { const PL = '#86b0c6', A = 116, B = 66, RY = 30, WY = 20, NN = 40, ST = [[-56, -18], [56, -18], [0, 28]];
      const D = Object.assign(POOL(240, 140, 8, ST), { build: () => { const o = [];
          ovalC(o, 0, 0, A, B, 3.4, NN, [[0, 0, 0.88], [4, 0, 0.94], [27, 0, 1], [29, 0, 1.03], [30, 0, 1.03]], PL, 'plastic', WY, '#cfe4ea');
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('pet29a'), k = C.k;
        const under = shadow(C, 0, 0, 124, 72, 0.35) + FL(C, 0.06, `<path d="M52 66Q72 74 92 66Q100 78 76 82Q54 82 52 66Z" fill="#b8ccd2" opacity="0.4"/><ellipse cx="-96" cy="56" rx="10" ry="4" fill="#b8ccd2" opacity="0.3"/>`);
        let ext = rep(NN, i => facet(C, 0, 0, A * 0.965, B * 0.965, NN, i, 8 + (i % 3) * 4, 2, `<path d="M0 ${4 + (i % 2) * 3}l${f1(4 + R() * 4)} ${f1(-1 + R() * 2)}M2 ${9 + (i % 3)}l${f1(3 + R() * 3)} ${f1(R())}" stroke="#ffffff" stroke-width="0.35" opacity="0.55"/><ellipse cx="${f1(4 + R() * 4)}" cy="12" rx="${f1(3 + R() * 3)}" ry="2" fill="#5a6a70" opacity="0.15"/>`)).join('');
        [NN - 1, NN / 2 - 1].forEach(i => { ext += facet(C, 0, 0, A * 1.028, B * 1.028, NN, i, 26, 2, `<rect x="0" y="0" width="9" height="2.6" rx="1.3" fill="#3a5868" opacity="0.6"/>`, 0.05); });
        ext += facet(C, 0, 0, A * 0.975, B * 0.975, NN, 8, 24, 3, `<path d="M3 0L4 4L2.6 7L4.4 11L3.4 15" stroke="#3a4a50" stroke-width="0.4" fill="none"/><rect x="-0.4" y="3" width="8" height="8" fill="#b8bcc0" transform="rotate(-6 3.6 7)"/><path d="M-0.4 3l0.6 1l-0.6 1l0.6 1l-0.6 1l0.6 1l-0.6 1l0.6 1M7.6 3l0.6 1l-0.6 1l0.6 1l-0.6 1l0.6 1l-0.6 1l0.6 1" stroke="#9aa0a4" stroke-width="0.3" fill="none" transform="rotate(-6 3.6 7)"/><path d="M0.4 5h6.6M0.4 8h6.6" stroke="#d8dcde" stroke-width="0.25" opacity="0.7" transform="rotate(-6 3.6 7)"/>`, 0.1);
        const rim = arcE(C, 0, 0, A * 1.03 + 0.1, B * 1.03 + 0.1, RY - 0.2, 0.6, '#c8e0ec', 0.8);
        const v = (x, z) => wVis(C, 0, 0, A - 3.4, B - 3.4, WY, RY, x, z);
        const fm = foam(C, WY + 0.15, [[-98, -6, 10], [98, 6, 9], [0, -48, 12], [-68, 42, 8], [68, 40, 8], [-28, -50, 8]].filter(([x, z]) => v(x, z)), 'pet29a');
        const bone = v(-26, -34) ? (() => { const p = C.P([-26, WY + 0.4, -34]); return `<g transform="translate(${P2(p)}) scale(${n4(k)})"><g>${at('translate', '0 0;0 -0.5;0 0', 3.2, -1, SPL(2))}<g transform="rotate(-18)"><rect x="-4" y="-1" width="8" height="2" rx="1" fill="#f49ab8"/><circle cx="-4" cy="-1.1" r="1.4" fill="#f49ab8"/><circle cx="-4" cy="1.1" r="1.4" fill="#f49ab8"/><circle cx="4" cy="-1.1" r="1.4" fill="#f49ab8"/><circle cx="4" cy="1.1" r="1.4" fill="#f49ab8"/><path d="M-3 -0.5H3" stroke="#ffffff" stroke-width="0.4" opacity="0.6"/></g></g></g>`; })() : '';
        const dk = v(92, 16) ? duck(C, [92, WY, 16], 3.4) : '';
        const bb = bubbles(C, [[-96, WY + 1, -2], [94, WY + 1, 10], [4, WY + 1, -46], [-64, WY + 1, 44]].filter(([x, , z]) => v(x, z)), 'pet29ab');
        const ripp = (v(92, 16) ? rip(C, [92, WY + 0.1, 16], 3.4, 0, 1.4) : '') + (v(-26, -34) ? rip(C, [-26, WY + 0.1, -34], 4.2, 1.6, 1.2) : '');
        const t5 = (8 + 1) / NN * 2 * PI, tip = [A * Math.cos(t5) * 0.99, 14, B * Math.sin(t5) * 0.99], dr = vdot(C, [Math.cos(t5), 0, Math.sin(t5)]) > 0.2 ? (() => { const a = C.P(tip), b = C.P([tip[0] * 0.94, 0.2, tip[2] * 1.05]), KQ = ' keyTimes="0;0.75;0.95;0.96;1" dur="5.5s" repeatCount="indefinite"';
          return `<ellipse rx="${f1(0.6 * k)}" ry="${f1(0.8 * k)}" fill="#d8eaee"><animate attributeName="cx" values="${f1(a[0])};${f1(a[0])};${f1(b[0])};${f1(a[0])};${f1(a[0])}"${KQ}/><animate attributeName="cy" values="${f1(a[1])};${f1(a[1] + 0.8 * k)};${f1(b[1])};${f1(a[1])};${f1(a[1])}"${KQ}/><animate attributeName="opacity" values="0.9;0.9;0.9;0;0.9"${KQ}/></ellipse>`; })() : '';
        return { under, front: ext + rim + fm + ripp + bone + dk + bb + dr, bb: C.bb(4) }; };
      return D; };

    // BTH-031 NON-SLIP PET TUB INSERT & FOAMING BRUSH (T2, 4 seats): a roomy clean white acrylic oval pet tub with a rolled rim; on its floor a teal non-slip rubber
    // insert with rows of suction-cup bubbles shows through the clear water; a teal palm foaming brush with soft nubs and a white pump dome sits on the rim, and a
    // pink paw-print shampoo bottle on the other side. Live: foam bubbles bloom round the brush and float off, ripples cross the water and a glint slides on the rim.
    N.pet29b = S => { const AC = '#f6f7f6', TL = '#3ab0a8', A = 132, B = 76, RY = 32, WY = 24, NN = 48, ST = [[-54, -26], [54, -26], [-54, 30], [54, 30]], BR = [98, -53], SH = [-100, -51];
      const D = Object.assign(POOL(280, 162, 10, ST), { build: () => { const { cyl, ball } = K(), o = [];
          ovalC(o, 0, 0, A, B, 5, NN, [[0, 0, 0.88], [3, 0, 0.95], [29, 0, 1], [31, 0, 1.04], [32, 0, 1.03]], AC, 'gloss', WY, '#bfe6ee');
          o.push(cyl(BR[0], RY + 0.2, BR[1], 5.4, 2.4, TL, { n: 18, mat: 'plastic' }), ball(BR[0], RY + 2.6, BR[1], 3.4, '#f4f4f2', { sy: 0.6, k: 4, n: 14, mat: 'gloss' }));
          o.push(sol({ ax: 'y', sh: 'rr', c: SH, a: 3.2, b: 2, r: 1.6, rings: [[RY + 0.2, 0], [RY + 11, 0], [RY + 12.4, 0, 0.8]], col: '#f4a8c4', mat: 'gloss' }), cyl(SH[0], RY + 12.4, SH[1], 1.4, 1.8, '#ffffff', { n: 10, mat: 'plastic' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('pet29b'), k = C.k;
        const v = (x, z) => wVis(C, 0, 0, A - 5, B - 5, WY, RY, x, z);
        let mat = ''; for (let x = -112; x <= 112; x += 7) for (let z = -56; z <= 56; z += 7) { const e = (x / 118) ** 2 + (z / 62) ** 2; if (e > 1 || !v(x, z)) continue; mat += `<circle cx="${x}" cy="${z}" r="1.5" fill="#2a9a92" opacity="0.5"/>`; }
        const ins = FL(C, WY + 0.14, mat);
        const fm = foam(C, WY + 0.16, [[-104, 4, 8], [104, 6, 8], [0, -52, 7], [0, 50, 6]].filter(([x, z]) => v(x, z)), 'pet29b');
        const nubs = FL(C, RY + 2.64, rep(14, i => { const t = i / 14 * 2 * PI; return `<circle cx="${f1(BR[0] + Math.cos(t) * 4.5)}" cy="${f1(BR[1] + Math.sin(t) * 4.5)}" r="0.45" fill="#7ad8d0"/>`; }).join(''));
        const paw = vdot(C, [0, 0, 1]) > 0.15 ? PLN(C, [SH[0] - 3.2, RY + 9, SH[1] + 2.05], [1, 0, 0], [0, -1, 0], `<rect x="0.4" y="0" width="5.6" height="6" rx="0.6" fill="#ffffff" opacity="0.85"/><ellipse cx="3.2" cy="3.8" rx="1.2" ry="1" fill="#e46a94"/>` + [[1.8, 2.2], [2.8, 1.6], [3.7, 1.6], [4.6, 2.2]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="0.45" fill="#e46a94"/>`).join('')) : '';
        const blooms = bubbles(C, rep(7, i => { const t = i / 7 * 2 * PI; return [BR[0] + Math.cos(t) * 6.4, RY + 1.4 + (i % 3) * 1.2, BR[1] + Math.sin(t) * 6.4]; }), 'pet29bb') + rep(3, i => { const p = C.P([BR[0] + (i - 1) * 3, RY + 4, BR[1]]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.9 * k)}" fill="#ffffff" fill-opacity="0.2" stroke="#ffffff" stroke-width="${f1(0.15 * k)}" opacity="0">${an('opacity', '0;0.9;0', 5, -i * 1.6)}<animateTransform attributeName="transform" type="translate" values="0 0;${f1((i - 1) * 3 * k)} ${f1(-12 * k)}" dur="5s" begin="${-i * 1.6}s" repeatCount="indefinite"/></circle>`; }).join('');
        const rim = arcE(C, 0, 0, A * 1.035 + 0.1, B * 1.035 + 0.1, RY - 0.4, 0.5, '#ffffff', 0.9);
        const gl = (() => { let d = ''; for (let i = 0; i <= 12; i++) { const t = PI / 2 - 0.9 + i * 0.05; d += (i ? 'L' : 'M') + PP(C, [A * 1.04 * Math.cos(t), RY - 1, B * 1.04 * Math.sin(t)]); } return vdot(C, [0, 0, 1]) > 0.2 ? `<path d="${d}" stroke="#ffffff" stroke-width="${f1(0.6 * k)}" fill="none" opacity="0">${an('opacity', '0;0.9;0', 6, 0, SPL(2))}</path>` : ''; })();
        const ripp = (v(0, 2) ? rip(C, [0, WY + 0.2, 2], 4, 0, 1.6) : '') + (v(0, -36) ? rip(C, [0, WY + 0.2, -36], 5, 2, 1.4) : '');
        return { under: shadow(C, 0, 0, 140, 84, 0.3), front: ins + fm + ripp + rim + gl + nubs + paw + blooms, bb: C.bb(4) }; };
      return D; };

    // BTH-051 MINI HINOKI PET ONSEN BARREL WITH YUZU CITRUS (T3, 5 seats): a big round pale hinoki-cypress soaking tub bound with two copper hoops, full of clear hot
    // water with yuzu bobbing in it (yuzu-yu), beside a little hinoki stool holding a wooden hishaku ladle and a spare yuzu. Live: steam curls up, the yuzu bob
    // and ripples spread.
    N.pet29c = S => { const HN = '#e8c890', CU = '#b8703e', CX = -18, A = 100, B = 96, RY = 52, WY = 42, NN = 52, SX = 108;
      const ST = [90, 162, 234, 306, 18].map(d => [CX + Math.cos(d * PI / 180) * 60, Math.sin(d * PI / 180) * 58].map(v => Math.round(v * 10) / 10));
      const YZ = [[CX + 4, -4], [CX - 10, 8], ...[54, 126, 198, 270, 342].map(d => [CX + Math.cos(d * PI / 180) * 80, Math.sin(d * PI / 180) * 76])];
      const D = Object.assign(POOL(248, 200, 24, ST, CX), { build: () => { const { box, ball } = K(), o = [];
          ovalC(o, CX, 0, A, B, 4.4, NN, [[0, 0, 0.97], [3, 0, 1], [RY, 0, 1]], HN, 'wood', WY, '#d4ecd8');
          o.push(box(SX, 0, 10.6, 24, 19, 2.6, shade(HN, 0.92), { r: 0.6, mat: 'wood' }), box(SX, 0, 25.4, 24, 19, 2.6, shade(HN, 0.92), { r: 0.6, mat: 'wood' }), box(SX, 19, 18, 28, 3, 20, HN, { r: 0.8, mat: 'wood' }));
          o.push(sol({ ax: 'y', sh: 'el', c: [SX - 7, 14], a: 3.8, b: 3.8, n: 16, rings: [[22, 0, 0.95], [22.6, 0, 1], [27, 0, 1]], col: HN, mat: 'wood' }), rod([SX - 3.4, 25.4, 14.6], [SX + 11, 23.4, 22], 0.55, shade(HN, 0.95), { mat: 'wood' }));
          o.push(ball(SX + 4, 22, 9.6, 3.2, '#f2c430', { k: 5, n: 14, mat: 'gloss' }));
          return o; } });
      D.fx = ctx => { const C = cam(ctx), k = C.k;
        let ext = ''; for (let i = 0; i < 64; i++) { const t = (i + 0.5) / 64 * 2 * PI, n = [Math.cos(t) / A, 0, Math.sin(t) / B]; if (vdot(C, n) * A < 0.06) continue; const x = CX + A * 1.003 * Math.cos(t), z = B * 1.003 * Math.sin(t);
          ext += `<path d="M${PP(C, [x, 1, z])}L${PP(C, [x, RY - 0.5, z])}" stroke="#b8945a" stroke-width="${f1(0.3 * k)}" opacity="0.55"/>`; }
        ext += [8, 40].map(y => arcE(C, CX, 0, A + 0.5, B + 0.5, y, 2.6, CU) + arcE(C, CX, 0, A + 0.55, B + 0.55, y + 0.8, 0.6, '#e8a070', 0.8)).join('');
        const rim = arcE(C, CX, 0, A - 0.2, B - 0.2, RY + 0.02, 0.5, '#f8e4b8', 0.9);
        const v = (x, z) => wVis(C, CX, 0, A - 4.4, B - 4.4, WY, RY, x, z);
        const yz = YZ.filter(([x, z]) => v(x, z)).map(([x, z], i) => { const p = C.P([x, WY, z]); return `<g transform="translate(${P2(p)}) scale(${n4(k * 1.2)})"><g>${at('translate', '0 0;0 -0.7;0 0', 3 + i * 0.4, -i * 0.7, SPL(2))}<ellipse cx="0" cy="0.4" rx="4" ry="1.3" fill="#7aa08a" opacity="0.3"/><circle cx="0" cy="-2.2" r="3.4" fill="#f4b828" stroke="#d89418" stroke-width="0.25"/><circle cx="-1" cy="-3.2" r="1.2" fill="#fff4a8" opacity="0.6"/>` +
          rep(6, j => `<circle cx="${f1(Math.cos(j * 1.3 + i) * 1.8)}" cy="${f1(-2.2 + Math.sin(j * 1.3 + i) * 1.6)}" r="0.22" fill="#d8a018"/>`).join('') + `<circle cx="0" cy="-5.3" r="0.35" fill="#5a7a3a"/></g></g>` + rip(C, [x, WY + 0.1, z], 4 + i * 0.5, i * 0.8, 1.5); }).join('');
        const under = shadow(C, CX, 0, 106, 102, 0.4) + shadow(C, SX, 18, 18, 14, 0.25);
        return { under, front: ext + rim + yz + steam(C, [CX, WY + 2, 0], 9, 6.4, 46, 120, 'pet29cs'), bb: C.bb(8) }; };
      return D; };

    // BTH-071 AUTOMATED WARM-AIR PET BLOW-DRY & BUBBLE SPA POD (T4, 6 seats): a big pearl-white bubble-spa pool with a brushed-champagne rim band and a soft blue
    // LED glow under the lip, backed by a curved pearl blow-dry hood: a canopy lip with warm amber vent slots, two round dryer fans and a touch display
    // (WARM AIR 38°C). Live: jets fizz bubbles up through the water, warm-air ribbons stream down from the vents, the fans spin and the LED ring breathes.
    N.pet29d = S => { const PE = '#f6f4f0', CH = '#d8c8a8', A = 154, B = 88, RY = 34, WY = 26, NN = 52, HZ = -104, ST = [[-86, -28], [0, -28], [86, -28], [-86, 32], [0, 32], [86, 32]];
      const D = Object.assign(POOL(320, 226, 12, ST), { build: () => { const { box } = K(), o = [];
          ovalC(o, 0, 0, A, B, 5, NN, [[0, 0, 0.9], [3, 0, 0.96], [30, 0, 1], [32.6, 0, 1.03], [34, 0, 1.025]], PE, 'gloss', WY, '#c4ecf4');
          const Hd = box(0, 0, HZ, 220, 94, 14, PE, { r: 7, mat: 'gloss' }); o.push(Hd, box(0, 94, HZ + 13, 230, 7, 40, PE, { r: 3.4, mat: 'gloss' }));
          glue(o, Hd, [box(0, 6, HZ + 7.05, 200, 1.2, 0.2, CH, { r: 0, noOut: 1, mat: 'metal' }), box(0, 86, HZ + 7.05, 200, 1.2, 0.2, CH, { r: 0, noOut: 1, mat: 'metal' })]);
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('pet29d'), k = C.k, fr = vdot(C, [0, 0, 1]) > 0.05, id = C.u('p71');
        const v = (x, z) => wVis(C, 0, 0, A - 5, B - 5, WY, RY, x, z);
        const band = arcE(C, 0, 0, A * 1.03 + 0.1, B * 1.03 + 0.1, RY - 1.2, 1.6, CH) + arcE(C, 0, 0, A * 1.025 + 0.12, B * 1.025 + 0.12, RY - 4, 1.4, '#8ad8ff', 0.5, `><animate attributeName="opacity" values="0.25;0.8;0.25" dur="5s" repeatCount="indefinite"/></path><path d=""`);
        const jets = bubbles(C, freePts(R, 26, 0, A - 10, B - 10, ST, 36).filter(([x, z]) => v(x, z)).map(([x, z]) => [x, WY + 0.4, z]), 'pet29dj', 1.3);
        const fm = foam(C, WY + 0.16, freePts(R, 5, 0, A - 20, B - 16, ST, 44).filter(([x, z]) => v(x, z)).map(([x, z]) => [x, z, 7]), 'pet29d');
        const hood = fr ? PLN(C, [-110, 94, HZ + 7.06], [1, 0, 0], [0, -1, 0], `<defs><linearGradient id="${id}a" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffb860"/><stop offset="1" stop-color="#ff8a40"/></linearGradient></defs>` +
          rep(9, i => `<rect x="${f1(30 + i * 18)}" y="10" width="12" height="3" rx="1.5" fill="url(#${id}a)">${an('opacity', '0.55;1;0.55', 3, -i * 0.3, SPL(2))}</rect>`).join('') +
          [52, 168].map((x, i) => `<circle cx="${x}" cy="44" r="15" fill="#e8e4dc" stroke="${CH}" stroke-width="1.4"/><circle cx="${x}" cy="44" r="11.6" fill="#2a2a2e"/><g>${at('rotate', `0 ${x} 44;360 ${x} 44`, 1.6 + i * 0.3, 0)}` + rep(5, j => `<path d="M${x} 44L${f1(x + Math.cos(j * 1.2566) * 10.4)} ${f1(44 + Math.sin(j * 1.2566) * 10.4)}A10.4 10.4 0 0 1 ${f1(x + Math.cos(j * 1.2566 + 0.7) * 10.4)} ${f1(44 + Math.sin(j * 1.2566 + 0.7) * 10.4)}Z" fill="#9a9aa2"/>`).join('') + `</g><circle cx="${x}" cy="44" r="2.6" fill="${CH}"/><circle cx="${x}" cy="44" r="11.6" fill="none" stroke="#ffb860" stroke-width="0.6" opacity="0.6"/>`).join('') +
          `<rect x="88" y="30" width="44" height="26" rx="4" fill="#1c1c22"/><text x="110" y="40" text-anchor="middle" font-family="Arial,sans-serif" font-size="5" fill="#ffc890">WARM AIR</text><text x="110" y="50" text-anchor="middle" font-family="Arial,sans-serif" font-size="8" font-weight="bold" fill="#ffffff">38°C<animate attributeName="opacity" values="0.7;1;0.7" dur="3s" repeatCount="indefinite"/></text>` +
          `<path d="M10 0H40L6 94H0V8Z" fill="#ffffff" opacity="0.14"/>`) : '';
        const air = fr ? rep(9, i => { const x = -80 + i * 18, a = C.P([x, 82, HZ + 8]), w = 3 + (i % 3); return `<path d="M${P2(a)}q${f1(-w * k)} ${f1(8 * k)} 0 ${f1(16 * k)}t0 ${f1(16 * k)}" stroke="#ffd8a8" stroke-width="${f1(1.4 * k)}" fill="none" stroke-linecap="round" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.5;0', 3.4, -i * 0.38)}<animateTransform attributeName="transform" type="translate" values="0 0;${f1(2 * k)} ${f1(26 * k)}" dur="3.4s" begin="${-i * 0.38}s" repeatCount="indefinite"/></path>`; }).join('') : '';
        const under = shadow(C, 0, -8, 164, 108, 0.35) + FL(C, 0.07, `<ellipse cx="0" cy="0" rx="164" ry="96" fill="#8ad8ff" opacity="0.14" filter="url(#m12b1)">${an('opacity', '0.08;0.2;0.08', 5, 0, SPL(2))}</ellipse>`);
        return { under, front: band + fm + jets + hood + air, bb: C.bb(8) }; };
      return D; };

    // BTH-091 ROYAL PET HYDRO-MASSAGE & DIAMOND-FUR GROOMING SANCTUARY (T5, 7 seats): a grand oval white-marble pool on a stepped marble plinth with a 24k gold rim
    // and gold jet rosettes, rose petals on the water, and behind it a gold swan fountain on a marble pedestal pouring a stream into the pool, flanked by two
    // gold lantern columns with warm glow. Live: the swan's stream pours and splashes, hydro-massage jets swirl bubbles, diamond sparkles drift over the water
    // and the lanterns glow.
    N.pet29e = S => { const MB = '#f6f2ec', GD = '#e2b14a', A = 172, B = 98, RY = 42, WY = 33, NN = 60, PZ = -126, ST = [[-114, -32], [-38, -32], [38, -32], [114, -32], [-76, 34], [0, 34], [76, 34]];
      const D = Object.assign(POOL(372, 284, 18, ST), { build: () => { const { box, cyl, ball } = K(), o = [];
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 0], a: A + 10, b: B + 10, n: 56, rings: [[0, 0, 0.99], [1, 0, 1], [6, 0, 1]], col: '#ebe4da', mat: 'gloss' }));
          ovalC(o, 0, 0, A, B, 6, NN, [[6, 0, 0.96], [8, 0, 1], [39, 0, 1], [41, 0, 1.03], [42, 0, 1.025]], MB, 'gloss', WY, '#bfe6ec');
          o.push(box(0, 0, PZ, 40, 46, 24, MB, { r: 2, mat: 'gloss' }), box(0, 46, PZ, 46, 4, 28, GD, { r: 1, mat: 'metal' }));
          o.push(ball(0, 50, PZ, 14, GD, { sx: 1.2, sz: 0.9, sy: 0.7, k: 5, n: 18, mat: 'metal' }));
          o.push(rod([0, 64, PZ - 3], [0, 86, PZ + 3], 3.4, GD, { mat: 'metal' }), rod([0, 86, PZ + 3], [0, 90, PZ + 12], 3, GD, { mat: 'metal' }), ball(0, 84.6, PZ + 13, 3.8, GD, { k: 4, n: 12, mat: 'metal' }));
          [-1, 1].forEach(s => o.push(rod([s * 9, 62, PZ], [s * 24, 76, PZ - 6], 4.2, GD, { mat: 'metal' })));
          [-1, 1].forEach(s => { const x = s * 164, z = -118; o.push(box(x, 0, z, 14, 6, 14, MB, { r: 1, mat: 'gloss' }), cyl(x, 6, z, 4, 70, GD, { n: 14, mat: 'metal' }), cyl(x, 76, z, 8, 14, '#fff2d0', { n: 16, mat: 'gloss', emit: 1, op: 0.85 }), cyl(x, 90, z, 9, 2, GD, { n: 16, mat: 'metal' }), ball(x, 92, z, 3, GD, { k: 4, n: 12, mat: 'metal' })); });
          return o; } });
      D.fx = ctx => { const C = cam(ctx), R = rng('pet29e'), k = C.k;
        const v = (x, z) => wVis(C, 0, 0, A - 6, B - 6, WY, RY, x, z);
        const band = arcE(C, 0, 0, A * 1.03 + 0.1, B * 1.03 + 0.1, RY - 1, 2, GD) + arcE(C, 0, 0, A + 10.1, B + 10.1, 5.4, 1.2, GD, 0.9) + arcE(C, 0, 0, A - 6.2, B - 6.2, RY + 0.05, 0.8, GD, 0.9);
        const ros = rep(8, i => { const t = (i + 0.5) / 8 * 2 * PI, x = Math.cos(t) * (A - 6.3), z = Math.sin(t) * (B - 6.3), n = [-Math.cos(t), 0, -Math.sin(t)]; if (vdot(C, n) < 0.2) return ''; const p = C.P([x, WY + 4, z]);
          return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(1.8 * k)}" fill="${GD}" stroke="#8a6a20" stroke-width="${f1(0.2 * k)}"/><circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.7 * k)}" fill="#3a2a10"/>`; }).join('');
        const pet = FL(C, WY + 0.15, freePts(R, 14, 0, A - 16, B - 14, ST, 38).filter(([x, z]) => v(x, z)).map(([x, z]) => `<ellipse cx="${f1(x)}" cy="${f1(z)}" rx="2.2" ry="1.4" fill="${['#e8607a', '#f08aa0', '#d84a66'][Math.floor(R() * 3)]}" transform="rotate(${Math.floor(R() * 180)} ${f1(x)} ${f1(z)})"/>`).join(''));
        const jets = bubbles(C, freePts(R, 30, 0, A - 12, B - 10, ST, 36).filter(([x, z]) => v(x, z)).map(([x, z]) => [x, WY + 0.4, z]), 'pet29ej', 1.3);
        const dia = rep(16, i => { const [x, z] = [(R() - 0.5) * 2 * (A - 30), (R() - 0.5) * 2 * (B - 24)], p = C.P([x, WY + 8 + R() * 20, z]), s = (0.8 + R() * 0.8) * k; return `<path d="M${f1(p[0])} ${f1(p[1] - s * 1.6)}L${f1(p[0] + s)} ${f1(p[1])}L${f1(p[0])} ${f1(p[1] + s * 1.6)}L${f1(p[0] - s)} ${f1(p[1])}Z" fill="#ffffff" opacity="0">${an('opacity', '0;0;1;0', 3 + (i % 4) * 0.6, -i * 0.45, KT('0;0.55;0.7;1'))}</path>`; }).join('');
        const sp = C.P([0, 87, PZ + 17]), en = C.P([0, WY, -B + 26]), mid = [(sp[0] + en[0]) / 2, Math.min(sp[1], en[1]) - 6 * k];
        const stream = `<path d="M${P2(sp)}Q${f1(mid[0])} ${f1(mid[1])} ${P2(en)}" stroke="#d8f2f8" stroke-width="${f1(3.2 * k)}" fill="none" opacity="0.75" stroke-linecap="round"/><path d="M${P2(sp)}Q${f1(mid[0])} ${f1(mid[1])} ${P2(en)}" stroke="#ffffff" stroke-width="${f1(0.8 * k)}" fill="none" stroke-dasharray="${f1(3 * k)} ${f1(4 * k)}" opacity="0.9"><animate attributeName="stroke-dashoffset" values="${f1(14 * k)};0" dur="0.8s" repeatCount="indefinite"/></path>` + (v(0, -B + 26) ? rip(C, [0, WY + 0.2, -B + 26], 1.6, 0, 2) + rip(C, [0, WY + 0.2, -B + 26], 1.6, 0.8, 1.5) : '');
        const lan = [-164, 164].map((x, i) => { const p = C.P([x, 83, -118]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(16 * k)}" fill="#ffd890" opacity="0.25" filter="url(#m12b1)">${an('opacity', '0.15;0.35;0.15', 4, -i * 2, SPL(2))}</circle>`; }).join('');
        const under = shadow(C, 0, -10, 190, 122, 0.35);
        return { under, front: band + ros + pet + jets + stream + dia + lan, bb: C.bb(10) }; };
      return D; };
  }

  // ======================= BATH SEATING (BTH-016/036/056/076/096): seats, footprints, act kept (016/036/056 40 x 40 sit h 38/41/60, 076 144 x 50 two seats h 30,
  // 096 176 x 74 nap h 32). The seat surface sits exactly at the seat height. =======================
  { const K = () => X.K, sol = o => X.K.solid(o), { rod } = RD.H16, { sAt, rip } = RD.H29T;
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const ovalC = (o, cx, cz, A, B, th, N, rings, col, mat, wy, wc, ex) => { const T = i => (i + 0.5) / N * 2 * PI, L = (a, b, t) => [a * Math.cos(t), b * Math.sin(t)];
      rings = rings.map(r => [r[0], 0, r[2]]); const sw = sAt(rings, wy);
      const lo = rings.filter(r => r[0] < wy).concat([[wy, 0, sw]]), hi = [[wy, 0, sw]].concat(rings.filter(r => r[0] > wy));
      const body = sol(Object.assign({ ax: 'y', sh: 'poly', c: [cx, cz], pts: rep(N, i => L(A, B, T(i))), rings: lo, col, mat }, ex || {})); o.push(body);
      for (let i = 0; i < N; i++) { const t0 = T(i), t1 = T(i + 1); o.push(sol(Object.assign({ ax: 'y', sh: 'poly', c: [cx, cz], pts: [L(A, B, t0), L(A, B, t1), L(A - th, B - th, t1), L(A - th, B - th, t0)], rings: hi, col, mat, noOut: 1 }, ex || {}))); }
      if (wc) { const W = sol({ ax: 'y', sh: 'poly', c: [cx, cz], pts: rep(N, i => L(A - th, B - th, T(i))), rings: [[wy, 0, sw], [wy + 0.12, 0, sw]], col: wc, mat: 'gloss', emit: 1, noOut: 1 }); W.par = body; o.push(W); }
      return body; };
    const arcE = (C, cx, cz, a, b, y, w, col, op) => { let d = '', on = false; for (let i = 0; i <= 64; i++) { const t = i / 64 * 2 * PI, n = [Math.cos(t) / a, 0, Math.sin(t) / b];
        if (vdot(C, n) * a > 0.03) { d += (on ? 'L' : 'M') + PP(C, [cx + Math.cos(t) * a, y, cz + Math.sin(t) * b]); on = true; } else on = false; }
      return d ? `<path d="${d}" stroke="${col}" stroke-width="${f1(w * C.k)}" fill="none" stroke-linecap="round" opacity="${op || 1}"/>` : ''; };
    // a falling drop from p to the floor (y1) + a ripple where it lands
    const dropTo = (C, p, y1, T, col, b) => { const a = C.P(p), w = C.P([p[0], y1, p[2]]), k = C.k, KQ = ` keyTimes="0;0.7;0.9;0.91;1" dur="${T}s" begin="${-(b || 0)}s" repeatCount="indefinite"`;
      return `<ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="${f1(0.5 * k)}" ry="${f1(0.65 * k)}" fill="${col || '#d8eaee'}"><animate attributeName="cy" values="${f1(a[1])};${f1(a[1] + 0.6 * k)};${f1(w[1])};${f1(a[1])};${f1(a[1])}"${KQ}/><animate attributeName="opacity" values="0.9;0.9;0.9;0;0.9"${KQ}/></ellipse>` + rip(C, [p[0], y1, p[2]], T, -0.9 * T + (b || 0), 0.8); };
    // a band round a tilted rod at fraction f (screen-space ellipse across the rod)
    const band = (C, a, b, f, r, col, w) => { const p = [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f], q = C.P(p), A = C.P(a), B = C.P(b), ang = Math.atan2(B[1] - A[1], B[0] - A[0]) * 180 / PI;
      return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(r * 0.35 * C.k)}" ry="${f1(r * 1.05 * C.k)}" fill="none" stroke="${col}" stroke-width="${f1((w || 0.35) * C.k)}" transform="rotate(${f1(ang)} ${f1(q[0])} ${f1(q[1])})"/>`; };

    // BTH-016 PLASTIC STEP-STOOL WITH CRACKED LEG (T1): a cheap faded mustard plastic step stool - a ribbed anti-slip top with a hand-grip slot, four splayed legs
    // with cross braces, one leg split and bound with grey duct tape, a peeling sticker and scuffs, standing in a wet ring on the floor. Live: a drop slides off
    // the top edge and plinks into the puddle.
    N.seat29a = S => { const PL = '#cdb468', H0 = 38;
      const D = { w: 40, d: 40, round: 0, act: 'sit', seats: [{ x: 0, z: 0, h: H0 }], build: () => { const { box } = K(), o = [];
          o.push(box(0, H0 - 4, 0, 34, 4, 30, PL, { r: 2.4, mat: 'plastic' }), box(0, H0 - 7, 0, 30, 3, 26, shade(PL, 0.9), { r: 1.4, mat: 'plastic' }));
          [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => o.push(rod([sx * 12, H0 - 7, sz * 10], [sx * 16, 0, sz * 14], 1.9, shade(PL, 0.95), { mat: 'plastic' })));
          [-1, 1].forEach(sz => o.push(rod([-14.2, 12, sz * 12.2], [14.2, 12, sz * 12.2], 1, shade(PL, 0.92), { mat: 'plastic' })));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('seat29a'), k = C.k, la = [12, H0 - 7, 10], lb = [16, 0, 14];
        const top = FL(C, H0 + 0.03, `<rect x="-8" y="-12.6" width="16" height="3.6" rx="1.8" fill="#5a4a24"/>` + rep(7, i => `<path d="M-14 ${-6 + i * 2.8}H14" stroke="${shade(PL, 0.78)}" stroke-width="0.8" stroke-linecap="round"/>`).join('') + `<ellipse cx="6" cy="8" rx="5" ry="2.4" fill="#8a7a4a" opacity="0.2"/><path d="M-12 12l4 -1.4" stroke="#ffffff" stroke-width="0.4" opacity="0.5"/>`);
        const fr = vdot(C, [0, 0, 1]) > 0.1, side = fr ? PLN(C, [-15, H0 - 0.6, 15.03], [1, 0, 0], [0, -1, 0], `<rect x="16" y="0.6" width="7" height="2.6" fill="#f2efe6" opacity="0.8" transform="rotate(-4 19 2)"/><path d="M16 0.6l1.4 1l-1 1.6" stroke="#cdb468" stroke-width="0.6" fill="none"/><path d="M3 1.4l5 1" stroke="#ffffff" stroke-width="0.4" opacity="0.5"/>`) : '';
        const leg = vdot(C, [0.6, 0, 0.8]) > -0.2 ? [0.42, 0.5, 0.58].map(f => band(C, la, lb, f, 2.1, '#a8acb0', 1.1)).join('') + (() => { const p = C.P([14, H0 * 0.3, 12]), q = C.P([14.6, H0 * 0.14, 12.6]); return `<path d="M${P2(p)}L${f1((p[0] + q[0]) / 2 + 0.8 * k)} ${f1((p[1] + q[1]) / 2)}L${P2(q)}" stroke="#4a3a14" stroke-width="${f1(0.35 * k)}" fill="none"/><path d="M${f1(p[0] - 0.6 * k)} ${f1(p[1] + 1.4 * k)}l${f1(0.8 * k)} ${f1(0.6 * k)}" stroke="#f4ecd0" stroke-width="${f1(0.3 * k)}"/>`; })() : '';
        const under = shadow(C, 0, 0, 22, 20, 0.3) + FL(C, 0.05, `<ellipse cx="2" cy="4" rx="21" ry="17" fill="#b8ccd2" opacity="0.28"/>`);
        return { under, front: top + side + leg + (fr ? dropTo(C, [6, H0 - 4, 15.3], 0.06, 5, '#d8eaee') : ''), bb: C.bb(4) }; };
      return D; };

    // BTH-036 FOLDABLE BAMBOO SHOWER STOOL (T2): a round slatted bamboo seat on two X-folding bamboo leg frames with nodes, steel hinge rivets and foot rails, water
    // beaded on the slats and a white face cloth folded over the edge. Live: drops gather on the slats and fall between them, and a glint slides along a rail.
    N.seat29b = S => { const BB = '#d8c27a', H0 = 41;
      const D = { w: 40, d: 40, round: 1, act: 'sit', seats: [{ x: 0, z: 0, h: H0 }], build: () => { const { box } = K(), o = [];
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 0], a: 17, b: 17, n: 26, rings: [[H0 - 2.4, 0, 0.96], [H0 - 1.8, 0, 1], [H0, 0, 0.98]], col: BB, mat: 'wood' }));
          o.push(box(0, H0 - 4.6, 0, 22, 2.2, 3, shade(BB, 0.85), { r: 0.6, mat: 'wood' }));
          [-9, 9].forEach((z, j) => { const dz = j ? 0.9 : -0.9; o.push(rod([-14, 0.8, z - dz], [12, H0 - 4.6, z - dz], 1.25, shade(BB, 0.95), { mat: 'wood' }), rod([14, 0.8, z + dz], [-12, H0 - 4.6, z + dz], 1.25, shade(BB, 0.92), { mat: 'wood' })); });
          [-15.4, 15.4].forEach(x => o.push(rod([x, 0.9, -11], [x, 0.9, 11], 1.1, shade(BB, 0.9), { mat: 'wood' })));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('seat29b'), k = C.k;
        const cid = C.u('b36'), slats = FL(C, H0 + 0.02, `<defs><clipPath id="${cid}"><circle r="16.4"/></clipPath></defs><g clip-path="url(#${cid})">` + rep(8, i => `<path d="M${-14 + i * 4} -17V17" stroke="#9a8040" stroke-width="0.55"/>`).join('') + rep(8, i => `<path d="M${-15.4 + i * 4} -17V17" stroke="#f4e4a8" stroke-width="0.3" opacity="0.6"/>`).join('') + `</g><circle r="16.6" fill="none" stroke="#a8904a" stroke-width="0.5"/>` +
          rep(9, () => `<ellipse cx="${f1((R() - 0.5) * 22)}" cy="${f1((R() - 0.5) * 22)}" rx="0.7" ry="0.5" fill="#ffffff" opacity="0.7"/>`).join(''));
        const legs = []; [-9, 9].forEach((z, j) => { const dz = j ? 0.9 : -0.9; legs.push([[-14, 0.8, z - dz], [12, H0 - 4.6, z - dz]], [[14, 0.8, z + dz], [-12, H0 - 4.6, z + dz]]); });
        const nodes = legs.map(([a, b]) => [0.3, 0.62].map(f => band(C, a, b, f, 1.3, '#a08848', 0.4)).join('')).join('');
        const piv = [-9.9, 9.9].map(z => { const p = C.P([0, 17.4, z]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.8 * k)}" fill="#c8ccd0" stroke="#6a6e72" stroke-width="${f1(0.15 * k)}"/>`; }).join('');
        const dr = rep(3, i => dropTo(C, [-10 + i * 8, H0 - 2.6, -4 + i * 5], 0.05, 4 + i, '#e0eef2', i * 1.3)).join('');
        const gl = (() => { const a = C.P([-15.4, 1.9, 11]), b = C.P([-15.4, 1.9, -11]); return `<circle r="${f1(0.5 * k)}" fill="#ffffff"><animate attributeName="cx" values="${f1(a[0])};${f1(b[0])}" dur="5s" repeatCount="indefinite"/><animate attributeName="cy" values="${f1(a[1])};${f1(b[1])}" dur="5s" repeatCount="indefinite"/>${an('opacity', '0;0.9;0', 5, 0)}</circle>`; })();
        return { under: shadow(C, 0, 0, 20, 18, 0.3), front: slats + nodes + piv + dr + gl, bb: C.bb(4) }; };
      return D; };

    // BTH-056 TRADITIONAL HINOKI WOOD ONSEN WASH STOOL & BUCKET SET (T3): a tall pale hinoki stool with a round dished seat, four square legs and a slatted lower
    // shelf holding a matching hinoki oke bucket bound with two dark copper hoops and filled with warm water, a hishaku ladle resting across it. Live: steam
    // curls from the bucket, ripples cross the water and a drop falls from the ladle.
    N.seat29c = S => { const HN = '#e8cf9c', CU = '#6a4a34', H0 = 60;
      const D = { w: 40, d: 40, round: 1, act: 'sit', seats: [{ x: 0, z: 0, h: H0 }], build: () => { const { box } = K(), o = [];
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 0], a: 19, b: 19, n: 28, rings: [[H0 - 4, 0, 0.94], [H0 - 3, 0, 1], [H0, 0, 1]], col: HN, mat: 'wood' }));
          [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => o.push(box(sx * 14, 0, sz * 14, 3.4, H0 - 4, 3.4, shade(HN, 0.94), { r: 0.6, mat: 'wood' })));
          o.push(box(0, 16, 0, 22, 2, 22, shade(HN, 0.97), { r: 0.4, mat: 'wood' }));
          const sec = (y0, y1, s0, s1, col, mat) => sol({ ax: 'y', sh: 'el', c: [0, 0], a: 10.6, b: 10.6, n: 24, rings: [[y0, 0, s0], [y1, 0, s1]], col, mat });
          o.push(sec(18, 19, 0.94, 1, HN, 'wood'), sec(19, 21, 1, 1.006, HN, 'wood'), sec(21, 22.4, 1.03, 1.03, CU, 'metal'), sec(22.4, 26.6, 1.009, 1.025, HN, 'wood'), sec(26.6, 28, 1.045, 1.045, CU, 'metal'));
          ovalC(o, 0, 0, 10.6, 10.6, 1.2, 24, [[28, 0, 1.026], [33, 0, 1.04]], HN, 'wood', 30, '#cfe4dc');
          o.push(rod([-7.4, 35, -2.4], [12.6, 33.6, 3], 0.5, shade(HN, 0.9), { mat: 'wood' }), sol({ ax: 'y', sh: 'el', c: [-10.4, -3], a: 3, b: 3, n: 14, rings: [[33.2, 0, 0.95], [33.6, 0, 1], [37, 0, 1]], col: HN, mat: 'wood' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), k = C.k, rr = y => 10.6 * (y < 19 ? 0.94 : 1 + 0.04 * (y - 19) / 14);
        // stave lines (fx) - skipped where a leg stands in front of them
        const legs = [[-14, -14], [14, -14], [-14, 14], [14, 14]].filter(([x, z]) => x * C.v[0] + z * C.v[2] > 0).map(([x, z]) => C.P([x, 25, z])[0]);
        let st = ''; for (let i = 0; i < 24; i++) { const t = (i + 0.5) / 24 * 2 * PI, n = [Math.cos(t), 0, Math.sin(t)]; if (vdot(C, n) < 0.06) continue; const a = C.P([n[0] * 10.7, 22.6, n[2] * 10.7]); if (legs.some(lx => Math.abs(lx - a[0]) < 2.6 * k)) continue;
          st += `<path d="M${PP(C, [n[0] * 10.72, 22.6, n[2] * 10.72])}L${PP(C, [n[0] * 10.88, 26.4, n[2] * 10.88])}M${PP(C, [n[0] * 10.62, 19.2, n[2] * 10.62])}L${PP(C, [n[0] * 10.66, 20.8, n[2] * 10.66])}" stroke="#b8945a" stroke-width="${f1(0.22 * k)}" opacity="0.5"/>`; }
        const hoops = '';
        const seat = FL(C, H0 + 0.02, `<circle r="15" fill="none" stroke="#c8a870" stroke-width="0.5" opacity="0.6"/>` + rep(6, i => `<path d="M-17 ${-12 + i * 5}Q0 ${-11 + i * 5} 17 ${-12.4 + i * 5}" stroke="#c8a870" stroke-width="0.25" fill="none" opacity="0.45"/>`).join('') + `<ellipse cx="-4" cy="-4" rx="9" ry="6" fill="#ffffff" opacity="0.12"/>`);
        const steam = rep(4, i => { const q = C.P([-4 + i * 3, 31, -2 + (i % 2) * 4]); return `<path d="M${P2(q)}c${f1(-1.6 * k)} ${f1(-2 * k)} ${f1(1.6 * k)} ${f1(-4 * k)} 0 ${f1(-6 * k)}c${f1(-1.6 * k)} ${f1(-2 * k)} ${f1(1.6 * k)} ${f1(-4 * k)} 0 ${f1(-6 * k)}" stroke="#ffffff" stroke-width="${f1(0.9 * k)}" fill="none" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.5;0', 5, -i * 1.25)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-12 * k)}" dur="5s" begin="${-i * 1.25}s" repeatCount="indefinite"/></path>`; }).join('');
        const wr = rip(C, [3, 30.15, 3], 4.4, 0, 0.8) + rip(C, [-4, 30.15, -2], 5.2, 2, 0.6);
        return { under: shadow(C, 0, 0, 20, 20, 0.3), front: st + hoops + seat + wr + steam + dropTo(C, [-8.6, 33.1, -1.2], 30.1, 4.6, '#cfe4dc'), bb: C.bb(4) }; };
      return D; };
  }

  // ---- bath seating batch 2: 076 (144 x 50, sit x +-34 h 30) / 096 (176 x 74, nap x 14 h 32)
  { const K = () => X.K, sol = o => X.K.solid(o), { rod } = RD.H16, { rip } = RD.H29T;
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FL = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const PP = (C, p) => { const q = C.P(p); return f1(q[0]) + ' ' + f1(q[1]); };
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const zR = (x, y, z0, z1, r, col) => sol({ ax: 'z', sh: 'el', c: [x, y], a: r, b: r, n: 16, rings: [[z0, 0, 0.9], [z0 + 0.5, 0, 1], [z1 - 0.5, 0, 1], [z1, 0, 0.9]], col, mat: 'fab', soft: 1 });

    // BTH-076 HEATED MARBLE HAMMAM MASSAGE SLAB BENCH (T4): a long white Carrara marble slab (soft grey and gold veins) on a fluted marble body over a stepped plinth,
    // brass trim along the slab edge; on the plinth ledge a hammered brass hammam bowl (tas) of water and a rolled
    // striped peshtemal towel. Live: thin steam lifts off the heated slab and ripples cross the bowl.
    N.seat29d = S => { const MB = '#f4f1ec', BR = '#d6b06a', H0 = 30;
      const D = { w: 144, d: 50, act: 'sit', seats: [{ x: -34, z: 2, h: H0 }, { x: 34, z: 2, h: H0 }], build: () => { const { box, cyl } = K(), o = [], VT = { tex: 'url(#h76v) none', texO: 0.9 };
          o.push(box(0, 0, 2, 136, 8, 46, '#e8e2d8', Object.assign({ r: 1, mat: 'gloss' }, VT)));
          const Bd = box(0, 8, -3, 124, 18, 32, MB, Object.assign({ r: 0.6, mat: 'gloss' }, VT)); o.push(Bd);
          const Sl = box(0, 26, 0, 144, 4, 50, MB, Object.assign({ r: 1.2, mat: 'gloss' }, VT)); o.push(Sl);
          o.push(box(0, 26.6, 25.2, 143, 0.8, 0.3, BR, { r: 0, noOut: 1, mat: 'metal' }));
          glue(o, Bd, rep(15, i => box(-56 + i * 8, 9, 13.05, 3.2, 16, 0.1, '#e2ddd4', { r: 0, noOut: 1, mat: 'matte' })));
          o.push(sol({ ax: 'y', sh: 'el', c: [-54, 19.4], a: 5.4, b: 5.4, n: 22, rings: [[8, 0, 0.6], [9.6, 0, 0.85], [12, 0, 1], [12.6, 0, 1.02]], col: BR, mat: 'metal' }));
          o.push(zR(52, 11.4, 14.2, 24.8, 3.4, '#e8dcc8'));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('seat29d'), k = C.k, fr = vdot(C, [0, 0, 1]) > 0.08;
        const veins = rep(6, () => { const y0 = R() * 60; let d = `M0 ${f1(y0)}`; for (let x = 12; x <= 60; x += 12) d += `Q${x - 6} ${f1(y0 + (R() - 0.5) * 16)} ${x} ${f1(y0 + (R() - 0.5) * 10)}`; return `<path d="${d}" stroke="${R() < 0.35 ? '#d4b06a' : '#b4b0a8'}" stroke-width="${f1(0.2 + R() * 0.35)}" fill="none" opacity="0.55"/>`; }).join('');
        const defs = `<defs><pattern id="h76v" width="60" height="60" patternUnits="userSpaceOnUse">${veins}</pattern></defs>`;
        const glow = false ? PLN(C, [-62, 26, 13.12], [1, 0, 0], [0, -1, 0], `<defs><linearGradient id="g76x" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffb060" stop-opacity="0.7"/><stop offset="1" stop-color="#ffb060" stop-opacity="0"/></linearGradient></defs>` + `<rect width="124" height="7" fill="url(#g76x)">${an('opacity', '0.4;1;0.4', 6, 0, SPL(2))}</rect>`) : '';
        const bowl = !fr ? '' : FL(C, 11.9, `<circle cx="-54" cy="19.4" r="4.9" fill="#c8e0e4"/><circle cx="-54" cy="19.4" r="4.9" fill="none" stroke="#b08a40" stroke-width="0.5"/>`) + rip(C, [-54, 12, 19.4], 4, 0, 0.45) + (vdot(C, [0, 0, 1]) > 0.1 ? rep(10, i => { const t = PI / 2 - 1.1 + i * 0.24, p = C.P([-54 + Math.cos(t) * 5.6, 10.4, 19.4 + Math.sin(t) * 5.6]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.45 * k)}" fill="#f2d890" opacity="0.6"/>`; }).join('') : '');
        const tw = fr ? PLN(C, [52, 14.8, 24.86], [1, 0, 0], [0, -1, 0], `<circle r="3.2" fill="none" stroke="#c8b8a0" stroke-width="0.3"/><circle r="2" fill="none" stroke="#c8b8a0" stroke-width="0.3"/>`) + rep(3, i => { const a = C.P([49, 11.4 + 3.4, 15 + i * 4]), b = C.P([55, 11.4 + 3.4, 15 + i * 4]); return `<path d="M${P2(a)}L${P2(b)}" stroke="#4a7aa8" stroke-width="${f1(0.9 * k)}" opacity="0.7"/>`; }).join('') : '';
        const steam = rep(6, i => { const q = C.P([-60 + i * 24, 30.2, -8 + (i % 3) * 8]); return `<path d="M${P2(q)}c${f1(-1.6 * k)} ${f1(-2.4 * k)} ${f1(1.6 * k)} ${f1(-4.6 * k)} 0 ${f1(-7 * k)}c${f1(-1.6 * k)} ${f1(-2.4 * k)} ${f1(1.6 * k)} ${f1(-4.6 * k)} 0 ${f1(-7 * k)}" stroke="#ffffff" stroke-width="${f1(1 * k)}" fill="none" opacity="0" filter="url(#m12b1)">${an('opacity', '0;0.4;0', 6, -i * 1)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-12 * k)}" dur="6s" begin="${-i}s" repeatCount="indefinite"/></path>`; }).join('');
        return { defs, under: shadow(C, 0, 0, 74, 28, 0.35), front: glow + bowl + tw + steam, bb: C.bb(4) }; };
      return D; };

    // BTH-096 FLOATING ZERO-GRAVITY THERMAL SPA LOUNGE BED (T5): a sculpted zero-gravity lounger of quilted pearl leather panels with mint piping (raised head, cradled
    // hips, lifted knees) hovering over a black glass disc on the floor ringed with mint light, a lavender control orb floating at its foot. Live: the bed's
    // under-light breathes mint-to-lavender, warm thermal shimmer rises off the cushions, motes drift up through the gap and the orb pulses.
    N.seat29e = S => { const PE = '#f6f2f4', MI = '#8fe0c4', LA = '#cdb8f5', H0 = 32, Z = 28;
      const top = x => { const P = [[-88, 54], [-64, 46], [-40, 38], [-18, 33], [0, 31], [20, 31], [36, 34], [52, 38], [68, 36], [88, 31]]; for (let i = 1; i < P.length; i++) if (x <= P[i][0]) { const a = P[i - 1], b = P[i], t = (x - a[0]) / (b[0] - a[0]); return a[1] + (b[1] - a[1]) * t; } return 31; };
      const XS = [-88, -64, -40, -18, 0, 20, 36, 52, 68, 88];
      const D = { w: 176, d: 74, act: 'nap', seats: [{ x: 14, z: 2, h: H0, k: 'nap' }], build: () => { const { ball } = K(), o = [];
          for (let i = 0; i < XS.length - 1; i++) { const x0 = XS[i] + (i ? 0.15 : 0), x1 = XS[i + 1] - 0.15; o.push(sol({ ax: 'z', sh: 'poly', c: [0, 0], pts: [[x0, top(x0)], [x1, top(x1)], [x1, top(x1) - 8], [x0, top(x0) - 8]], rings: [[-Z, 0], [Z, 0]], col: PE, mat: 'gloss', soft: 1 })); }
          o.push(ball(84, 44, 0, 4, LA, { k: 5, n: 14, mat: 'gloss', emit: 1 }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('seat29e'), k = C.k, fr = vdot(C, [0, 0, 1]) > 0.05, id = C.u('z96');
        const edge = z => `M${XS.map(x => PP(C, [x, top(x) - 0.4, z])).join('L')}`;
        const pip = fr ? `<path d="${edge(Z + 0.05)}" stroke="${MI}" stroke-width="${f1(0.8 * k)}" fill="none" stroke-linejoin="round"/><path d="M${XS.map(x => PP(C, [x, top(x) - 7.6, Z + 0.05])).join('L')}" stroke="${MI}" stroke-width="${f1(0.6 * k)}" fill="none" opacity="0.8"/>` : '';
        const quilt = XS.slice(0, -1).map((x0, i) => { const x1 = XS[i + 1], m = (x0 + x1) / 2; return [-14, 0, 14].map(z => { const p = C.P([m, top(m) + 0.05, z]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.45 * k)}" fill="#c8c0c8"/>`; }).join(''); }).join('') + `<path d="${edge(-Z + 0.5)}" stroke="#e0d8e0" stroke-width="${f1(0.4 * k)}" fill="none"/>`;
        const under = shadow(C, 0, 0, 80, 34, 0.25) + FL(C, 0.06, `<defs><radialGradient id="${id}g"><stop offset="0" stop-color="${MI}" stop-opacity="0.7"><animate attributeName="stop-color" values="${MI};${LA};${MI}" dur="8s" repeatCount="indefinite"/></stop><stop offset="1" stop-color="${MI}" stop-opacity="0"/></radialGradient></defs><ellipse rx="80" ry="32" fill="#141418"/><ellipse rx="80" ry="32" fill="none" stroke="${MI}" stroke-width="1.6" opacity="0.9"><animate attributeName="stroke" values="${MI};${LA};${MI}" dur="8s" repeatCount="indefinite"/></ellipse><ellipse rx="70" ry="28" fill="url(#${id}g)">${an('opacity', '0.5;1;0.5', 4, 0, SPL(2))}</ellipse><ellipse cx="-20" cy="-10" rx="30" ry="6" fill="#ffffff" opacity="0.08"/>`);
        const motes = rep(12, i => { const x = -70 + R() * 150, z = (R() - 0.5) * 40, a = C.P([x, 3, z]); return `<circle cx="${f1(a[0])}" cy="${f1(a[1])}" r="${f1(0.5 * k)}" fill="${i % 2 ? MI : LA}" opacity="0">${an('opacity', '0;0.9;0', 4 + (i % 3), -i * 0.6)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-(top(x) - 10) * k)}" dur="${4 + (i % 3)}s" begin="${-i * 0.6}s" repeatCount="indefinite"/></circle>`; }).join('');
        const heat = rep(5, i => { const x = -60 + i * 30, q = C.P([x, top(x) + 0.5, 0]); return `<path d="M${P2(q)}c${f1(-1.4 * k)} ${f1(-2 * k)} ${f1(1.4 * k)} ${f1(-4 * k)} 0 ${f1(-6 * k)}c${f1(-1.4 * k)} ${f1(-2 * k)} ${f1(1.4 * k)} ${f1(-4 * k)} 0 ${f1(-6 * k)}" stroke="#fff1a0" stroke-width="${f1(0.6 * k)}" fill="none" opacity="0">${an('opacity', '0;0.5;0', 5, -i)}<animateTransform attributeName="transform" type="translate" values="0 0;0 ${f1(-10 * k)}" dur="5s" begin="${-i}s" repeatCount="indefinite"/></path>`; }).join('');
        const orb = (() => { const p = C.P([84, 48, 0]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(7 * k)}" fill="${LA}" opacity="0.3" filter="url(#m12b1)">${an('opacity', '0.15;0.5;0.15', 3, 0, SPL(2))}</circle>`; })();
        return { under, front: pip + quilt + motes + heat + orb, bb: C.bb(6) }; };
      return D; };
  }

  // ---- spa plants batch 1: 017 (54 x 54 floor pot) / 037 (40 x 30 wall, showerhead) / 057 (70 x 44 floor)
  // Foliage uses the flora toolkit (RD.FLX.Flora) with a view-based depth (dp) so the back/front split stays right at every rotation.
  { const K = () => X.K, sol = o => X.K.solid(o), { rod } = RD.H16, mixC = (a, b, t) => X.K.mix(a, b, t);
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FLy = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const addv = (a, b, k) => [a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k];
    const DP = C => (x, y, z) => x * C.v[0] + y * C.v[1] + z * C.v[2];
    const flo = (ctx, C, o) => new RD.FLX.Flora(ctx, Object.assign({ dp: DP(C) }, o || {}));
    // a patch on a vertical cylinder (centre x0,z0, radius r) between angles a0..a1 and heights y0..y1; angle from +z toward +x
    const cylP = (C, x0, z0, r, a0, a1, y0, y1, n) => { const S = [], T = []; for (let i = 0; i <= n; i++) { const a = a0 + (a1 - a0) * i / n; S.push(C.P([x0 + Math.sin(a) * r, y0, z0 + Math.cos(a) * r])); T.push(C.P([x0 + Math.sin(a) * r, y1, z0 + Math.cos(a) * r])); }
      return 'M' + S.map(P2).join('L') + 'L' + T.reverse().map(P2).join('L') + 'Z'; };
    const cylL = (C, x0, z0, r, a0, a1, y, n) => { let d = ''; for (let i = 0; i <= n; i++) { const a = a0 + (a1 - a0) * i / n; d += (i ? 'L' : 'M') + P2(C.P([x0 + Math.sin(a) * r, y, z0 + Math.cos(a) * r])); } return d; };
    const facing = (C, a) => vdot(C, [Math.sin(a), 0, Math.cos(a)]);

    // BTH-017 PLASTIC FAUX-FERN (T1): the dollar-store fake fern that lived on the toilet tank - stiff moulded fronds with identical leaflets in a too-bright
    // green, two of them sun-bleached to yellow-green and one kinked where it was knocked, stuck into a block of green-dyed foam in a thin glossy
    // terracotta-look plastic pot (sun-faded, a moulding seam up the side, a half-peeled 99c price sticker), all standing on a crocheted pastel doily
    // with a dust bunny and a snapped-off leaflet beside it. Live: the stiff fronds barely tremble and dust motes hang in the air.
    N.spa29a = S => { const PT = '#cf8a62', TOP = 15;
      const D = { w: 54, d: 54, round: 1, build: () => { const { cyl } = K(), o = [];
          o.push(cyl(0, 0, 0, 10.4, TOP, PT, { n: 26, rg: [[0, 0, 0.76], [TOP - 2.6, 0, 1], [TOP - 2.6, 0, 1.08], [TOP, 0, 1.08]], mat: 'gloss' }));
          o.push(cyl(0, TOP - 1.6, 0, 10.6, 1.2, '#5f8a3a', { n: 22, noOut: 1, mat: 'matte' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('spa29a'), k = C.k, E = flo(ctx, C, { split: DP(C)(0, TOP, 0), piv: [0, TOP, 0], sw: 0.35, dur: 7.5 });
        rep(16, i => { const a = i * 2 * PI / 16 + (i % 2) * 0.14, bleach = i === 3 || i === 10, kink = i === 6, col = bleach ? '#a9c46a' : '#4cba48', st = bleach ? '#8fae52' : '#36983a', el0 = i % 2 ? 0.95 : 0.62, len = 23 + (i % 3) * 3.5, n = 8, ca = Math.cos(a), sa = Math.sin(a);
          let P = [ca * 1.2, TOP - 0.6, sa * 1.2]; const pts = [P], els = [];
          for (let j = 0; j < n; j++) { const t = j / n, e = kink && t > 0.45 ? -1.15 : el0 - 1.25 * t; els.push(e); P = addv(P, [Math.cos(e) * ca, Math.sin(e), Math.cos(e) * sa], len / n); pts.push(P); }
          E.stem(pts, 0.8, 0.45, st);
          for (let j = 1; j <= n; j++) { const t = j / n, e = els[Math.min(n - 1, j)]; [-1, 1].forEach(sg => E.leaf({ b: pts[j], az: a + sg * 1.4, el: e - 0.1, len: 5.4 * (1 - t * 0.5), wid: 1.9, droop: 0.04, roll: 0.25 * sg, sh: 'lance', col, col2: mixC(col, '#ffffff', 0.22), simple: 1, seg: 3, lk: 1.12 })); }
          E.leaf({ b: pts[n], az: a, el: els[n - 1], len: 3.4, wid: 1.6, droop: 0, sh: 'lance', col, simple: 1, seg: 3, lk: 1.12 }); });
        const o = E.out();
        // floor: doily (scalloped crochet rounds), dust bunny, snapped leaflet
        const doily = FLy(C, 0.04, `<circle r="19.4" fill="#f3dfe4"/>` + rep(24, i => { const a = i / 24 * 2 * PI; return `<circle cx="${f1(Math.cos(a) * 19.4)}" cy="${f1(Math.sin(a) * 19.4)}" r="2.6" fill="#f3dfe4"/>`; }).join('')
          + rep(24, i => { const a = (i + 0.5) / 24 * 2 * PI; return `<circle cx="${f1(Math.cos(a) * 17.6)}" cy="${f1(Math.sin(a) * 17.6)}" r="1" fill="#d9c2c8"/>`; }).join('')
          + `<circle r="15.4" fill="none" stroke="#e3c9d0" stroke-width="0.7" stroke-dasharray="1.2 0.9"/><circle r="12.8" fill="none" stroke="#fbeef1" stroke-width="1.6" stroke-dasharray="0.6 1"/><circle r="21.2" fill="none" stroke="#e8d0d6" stroke-width="0.4"/>`
          + `<ellipse cx="6" cy="9" rx="5" ry="3" fill="#c9b090" opacity="0.25"/>`);
        const lf = (() => { const E2 = flo(ctx, C, {}); E2.leaf({ b: [17, 0.5, 13], az: 0.9, el: 0, len: 5, wid: 1.9, droop: 0, sh: 'lance', col: '#4cba48', simple: 1, seg: 3, lk: 1.1 }); E2.stem([[17, 0.5, 13], [15.4, 0.5, 11.6]], 0.5, 0.4, '#36983a'); return E2.out(); })();
        const fluff = (() => { const q = C.P([-19, 0.8, 16]); return `<g opacity="0.8"><ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(2.6 * k)}" ry="${f1(1.3 * k)}" fill="#c8c2ba" opacity="0.6"/>` + rep(26, () => { const a = R() * 2 * PI, r0 = R() * 1.6, r1 = r0 + 0.8 + R() * 1.4; return `<path d="M${f1(q[0] + Math.cos(a) * r0 * k)} ${f1(q[1] + Math.sin(a) * r0 * 0.5 * k)}Q${f1(q[0] + Math.cos(a + 0.6) * r1 * k)} ${f1(q[1] + Math.sin(a + 0.6) * r1 * 0.5 * k)} ${f1(q[0] + Math.cos(a) * r1 * 1.2 * k)} ${f1(q[1] + Math.sin(a) * r1 * 0.6 * k)}" stroke="${R() < 0.5 ? '#a8a29a' : '#8a847c'}" stroke-width="0.18" fill="none"/>`; }).join('') + `<path d="M${f1(q[0] - 2 * k)} ${f1(q[1])}q${f1(1 * k)} ${f1(-1.4 * k)} ${f1(2.6 * k)} ${f1(-0.4 * k)}" stroke="#6a645c" stroke-width="0.25" fill="none"/></g>`; })();
        // pot: moulding seam, faded band, scuffs, price sticker, rim highlight
        let pot = ''; const tv = C.thV, rP = y => 10.4 * (0.76 + 0.24 * Math.min(1, y / (TOP - 2.6)));
        { const aS = 0.9; if (facing(C, aS) > 0.1) pot += `<path d="M${P2(C.P([Math.sin(aS) * rP(0.4), 0.4, Math.cos(aS) * rP(0.4)]))}L${P2(C.P([Math.sin(aS) * rP(TOP - 2.8), TOP - 2.8, Math.cos(aS) * rP(TOP - 2.8)]))}" stroke="#e8b898" stroke-width="${f1(0.35 * k)}" opacity="0.8"/>`; }
        pot += `<path d="${cylP(C, 0, 0, 10.5, tv - 1.3, tv + 1.3, TOP - 2.4, TOP - 0.2, 12)}" fill="#f2d2be" opacity="0.28"/>`;
        { const aP = -0.35; if (facing(C, aP) > 0.2) { const a0 = aP - 0.32, a1 = aP + 0.32, y0 = 4.4, y1 = 8.2, rr = y => rP(y) + 0.06, sp = (a, y) => C.P([Math.sin(a) * rr(y), y, Math.cos(a) * rr(y)]);
            const pa = [sp(a0, y0), sp(a1, y0), sp(a1, y1 - 1.2), sp(a1 - 0.12, y1), sp(a0, y1)]; pot += `<path d="M${pa.map(P2).join('L')}Z" fill="#f6f2e6" stroke="#d8d0bc" stroke-width="0.2"/><path d="M${P2(sp(a1, y1 - 1.2))}L${P2(sp(a1 - 0.12, y1))}L${P2(sp(a1 - 0.02, y1 + 0.4))}Z" fill="#e2dccb"/>`;
            const m = sp(aP, (y0 + y1) / 2), ang = Math.atan2(C.P([Math.sin(a1) * rr(6), 6, Math.cos(a1) * rr(6)])[1] - C.P([Math.sin(a0) * rr(6), 6, Math.cos(a0) * rr(6)])[1], C.P([Math.sin(a1) * rr(6), 6, Math.cos(a1) * rr(6)])[0] - C.P([Math.sin(a0) * rr(6), 6, Math.cos(a0) * rr(6)])[0]) * 180 / PI;
            pot += `<text x="${f1(m[0])}" y="${f1(m[1] + 0.9 * k)}" font-family="Arial,sans-serif" font-weight="700" font-size="${f1(2.1 * k)}" fill="#d0302a" text-anchor="middle" transform="rotate(${f1(ang)} ${P2(m)})">99¢</text>`; } }
        rep(5, i => { const a = tv + (R() - 0.5) * 2.2, y = 1.5 + R() * 9; if (facing(C, a) > 0.15) pot += `<path d="${cylL(C, 0, 0, rP(y) + 0.05, a, a + 0.1 + R() * 0.15, y, 3)}" stroke="#f6e2d6" stroke-width="${f1(0.22 * k)}" opacity="0.7"/>`; });
        pot += `<path d="${cylL(C, 0, 0, 11.25, tv - 1.1, tv + 0.6, TOP - 0.25, 10)}" stroke="#ffffff" stroke-width="${f1(0.4 * k)}" fill="none" opacity="0.55"/>`;
        const motes = rep(6, i => { const q = C.P([(R() - 0.5) * 40, 14 + R() * 26, (R() - 0.5) * 30]), T = 6 + R() * 5; return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.35 * k)}" fill="#fff6e0" opacity="0">${an('opacity', '0;0.7;0', T, -i * 1.3)}${an('cy', `${f1(q[1])};${f1(q[1] + 3 * k)}`, T, -i * 1.3)}</circle>`; }).join('');
        const bb = C.bb(3); bb[0] = Math.min(bb[0], o.bb[0]); bb[1] = Math.min(bb[1], o.bb[1]); bb[2] = Math.max(bb[2], o.bb[2]); bb[3] = Math.max(bb[3], o.bb[3]);
        return { defs: o.defs + lf.defs, under: doily + shadow(C, 0, 0, 13, 13, 0.4) + fluff + lf.front, back: o.back, front: pot + o.front + motes, bb }; };
      return D; };

    // BTH-037 HANGING EUCALYPTUS BUNDLE ON THE SHOWERHEAD (T2): a plain chrome shower arm out of a round wall flange, a swivel ball and a bell head with
    // limescale spots, and a fresh bundle of silver-dollar eucalyptus tied with jute twine looped over the arm, hanging upside down: round blue-grey leaves
    // with a white bloom in opposite pairs on red-brown stems, cut ends poking up out of the wrap. Live: the bundle sways in the steam, wisps of steam rise
    // through the leaves and drops gather on the head and fall.
    N.spa29b = S => { const CH = '#d3dbe0', Z0 = -15, AY = 33;
      const A0 = [0, AY + 1, Z0 + 1.2], A1 = [0, AY - 3, 5], HB = [0, AY - 4.6, 6.6];
      const D = { w: 40, d: 30, mount: 'wall', elev: 70, build: () => { const o = [];
          o.push(sol({ ax: 'z', sh: 'el', c: [0, AY + 1], a: 3.6, b: 3.6, n: 20, rings: [[Z0, 0, 1], [Z0 + 0.7, 0, 1], [Z0 + 1.4, 0, 0.55]], col: CH, mat: 'metal' }));
          o.push(rod(A0, A1, 1.05, CH, { mat: 'metal' }));
          o.push(X.K.ball(HB[0], HB[1] - 1.4, HB[2] - 0.6, 1.9, CH, { mat: 'metal', n: 12 }));
          o.push(sol({ ax: 'y', sh: 'el', c: [0, 8.2], a: 6.2, b: 6.2, n: 24, rings: [[AY - 10.2, 0, 1], [AY - 9.4, 0, 1.02], [AY - 8, 0, 0.92], [AY - 6.4, 0, 0.5], [AY - 5.4, 0, 0.3]], col: CH, mat: 'metal' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('spa29b'), k = C.k, f = 0.32, T0 = A0.map((v, i) => v + (A1[i] - v) * f), NK = [0, T0[1] - 6.5, T0[2] + 0.6];
        const E = flo(ctx, C, { piv: T0, sw: 2.2, dur: 6 });
        // stems: gathered at the neck, cut ends up, fanning down
        rep(11, i => { const a = -1.1 + i * 0.22 + (R() - 0.5) * 0.15, len = 28 + R() * 10, sp = 0.36 + R() * 0.12, zf = (R() - 0.5) * 6, col = i % 3 ? '#8a6656' : '#7a6a58';
          const pts = rep(9, j => { const t = j / 8; return [NK[0] + Math.sin(a) * len * t * sp, NK[1] - len * t, NK[2] + zf * t + Math.cos(a) * 2 * t]; });
          E.stem([[NK[0] + Math.sin(a) * 0.5, NK[1] + 2.6 + R(), NK[2] + (R() - 0.5)]].concat(pts), 0.55, 0.3, col);
          for (let j = 1; j < 9; j++) { const t = j / 8, s = 1.25 - t * 0.45; [-1, 1].forEach(sg => E.leaf({ b: pts[j], az: PI / 2 + sg * 1.45 + (R() - 0.5) * 0.4, el: -0.5 + (R() - 0.5) * 0.5, len: 4 * s, wid: 4.2 * s, droop: 0.35, roll: (R() - 0.5) * 0.9, sh: 'coin', col: R() < 0.2 ? '#6f9a90' : '#86aaa0', col2: '#c6d8d2', seg: 4, simple: 1, lk: 1.04 })); }
          E.leaf({ b: pts[8], az: PI / 2, el: -1.3, len: 2.6, wid: 2.4, droop: 0.2, sh: 'coin', col: '#86aaa0', seg: 3, simple: 1 }); });
        // jute: loop over the arm down to the neck, wraps round the neck, a bow
        const J = '#b8995e'; E.stem([[T0[0] - 0.9, T0[1] + 0.9, T0[2] - 0.4], [NK[0] - 1.1, NK[1] + 0.4, NK[2]]], 0.55, 0.55, J, { db: 3 }); E.stem([[T0[0] + 0.9, T0[1] + 0.9, T0[2] + 0.4], [NK[0] + 1.1, NK[1] + 0.4, NK[2]]], 0.55, 0.55, J, { db: 3 });
        rep(3, i => E.stem([[NK[0] - 1.9, NK[1] - i * 0.8, NK[2] + 0.4], [NK[0] + 1.9, NK[1] - i * 0.8 - 0.2, NK[2] + 0.4]], 0.7, 0.7, i % 2 ? '#a88a52' : J, { db: 4 }));
        E.stem([[NK[0] + 1.6, NK[1] - 0.6, NK[2] + 0.8], [NK[0] + 4, NK[1] + 0.4, NK[2] + 1], [NK[0] + 3.2, NK[1] - 1.6, NK[2] + 1], [NK[0] + 1.6, NK[1] - 0.6, NK[2] + 0.8], [NK[0] + 3.4, NK[1] - 4, NK[2] + 0.9]], 0.5, 0.45, J, { db: 5 });
        const o = E.out(), wrapTop = (() => { const q = C.P(T0); return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(1.5 * k)}" ry="${f1(0.9 * k)}" fill="none" stroke="${J}" stroke-width="${f1(0.55 * k)}"/>`; })();
        // chrome: limescale dots and a highlight on the bell, a highlight along the arm
        let ch = ''; { const tv = C.thV; rep(9, () => { const a = tv + (R() - 0.5) * 2.4, y = AY - 9.8 + R() * 2.4, rr = 6.2 * (1 - (y - (AY - 10.2)) * 0.03); ch += `<circle cx="${f1(C.P([Math.sin(a) * rr, y, 8.2 + Math.cos(a) * rr])[0])}" cy="${f1(C.P([Math.sin(a) * rr, y, 8.2 + Math.cos(a) * rr])[1])}" r="${f1((0.2 + R() * 0.3) * k)}" fill="#f4f1e6" opacity="0.8"/>`; });
          ch += `<path d="${cylL(C, 0, 8.2, 5.6, tv - 1.2, tv - 0.3, AY - 8.2, 6)}" stroke="#ffffff" stroke-width="${f1(0.6 * k)}" fill="none" opacity="0.7" stroke-linecap="round"/>`; }
        // drops off the rim of the head, steam wisps rising through the bundle
        const drops = [[-3.4, 2.4, 0], [2.6, 3.2, 2.1], [0.6, 5.4, 4.2]].map(([dx, dz, b]) => { const a = C.P([dx, AY - 10.4, 8.2 + dz]), w = C.P([dx, AY - 40, 8.2 + dz]), KQ = ` keyTimes="0;0.55;0.85;0.86;1" dur="4.6s" begin="${-b}s" repeatCount="indefinite"`;
          return `<ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="${f1(0.45 * k)}" ry="${f1(0.6 * k)}" fill="#e8f4f8" stroke="#9ab8c4" stroke-width="0.15"><animate attributeName="cy" values="${f1(a[1])};${f1(a[1] + 0.5 * k)};${f1(w[1])};${f1(a[1])};${f1(a[1])}"${KQ}/><animate attributeName="opacity" values="0.9;0.95;0;0;0.9"${KQ}/></ellipse>`; }).join('');
        const sid = C.u('s37'), steam = `<defs><filter id="${sid}" x="-1" y="-1" width="3" height="3"><feGaussianBlur stdDeviation="${f1(1.4 * k)}"/></filter></defs>` + rep(4, i => { const q = C.P([(i - 1.5) * 5, NK[1] - 34, NK[2] + 3]), T = 7 + i * 0.8;
          return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(4 * k)}" ry="${f1(2.4 * k)}" fill="#ffffff" opacity="0" filter="url(#${sid})">${an('opacity', '0;0.32;0.18;0', T, -i * 1.9)}${an('cy', `${f1(q[1])};${f1(q[1] - 30 * k)}`, T, -i * 1.9)}${an('cx', `${f1(q[0])};${f1(q[0] + (i % 2 ? 4 : -4) * k)}`, T, -i * 1.9)}</ellipse>`; }).join('');
        const bb = C.bb(3); bb[0] = Math.min(bb[0], o.bb[0]); bb[1] = Math.min(bb[1], o.bb[1]); bb[2] = Math.max(bb[2], o.bb[2]); bb[3] = Math.max(bb[3], o.bb[3]);
        return { defs: o.defs, back: o.back + o.front, front: wrapTop + ch + drops + steam, bb }; };
      return D; };

    // BTH-057 POTTED LUCKY BAMBOO & BOSTON FERN (T3): a tall clear glass cylinder of lucky bamboo - stalks cut in three heights with darker nodes and
    // fresh leaf sprouts, standing in white river pebbles and clear water, bound with a gold ribbon - beside a lush Boston fern spilling arching fronds
    // over a matte white ceramic planter on a slim three-legged brass stand. Live: the fern breathes in the humid air and light shimmers on the water.
    N.spa29c = S => { const VX = -20, VR = 7.2, VH = 24, PX = 14, PY = 12, PR = 11.5, PH = 17, BR = '#c9a35a';
      const D = { w: 70, d: 44, build: () => { const { cyl } = K(), o = [];
          o.push(cyl(VX, 0, 0, VR, VH, '#e4f2f6', { n: 26, op: 0.26, mat: 'gloss' }));
          o.push(cyl(VX, 0.4, 0, VR - 0.5, 4.2, '#efeae0', { n: 22, noOut: 1, mat: 'matte' }));
          o.push(cyl(VX, 4.6, 0, VR - 0.5, 10.4, '#cfe8ee', { n: 22, op: 0.32, noOut: 1, mat: 'gloss' }));
          const RG = cyl(PX, PY - 1.2, 0, PR * 0.86, 1.2, BR, { n: 24, mat: 'metal' }); o.push(RG);
          [0, 2.094, 4.189].forEach(a => glue(o, RG, [rod([PX + Math.sin(a) * PR * 0.8, PY - 1, Math.cos(a) * PR * 0.8], [PX + Math.sin(a) * PR * 1.05, 0, Math.cos(a) * PR * 1.05], 0.7, BR, { mat: 'metal' })]));
          o.push(cyl(PX, PY, 0, PR, PH, '#f1efea', { n: 28, rg: [[0, 0, 0.84], [3, 0, 0.95], [PH - 1, 0, 1], [PH, 0, 0.98]], mat: 'matte' }));
          o.push(cyl(PX, PY + PH - 1.4, 0, PR * 0.94, 1, '#4a3424', { n: 22, noOut: 1, mat: 'matte' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('spa29c'), k = C.k, dp = DP(C), pf = dp(PX, 20, 0) > dp(VX, 20, 0) + 4;
        // fern
        const E = flo(ctx, C, { split: dp(PX, PY + PH, 0), piv: [PX, PY + PH, 0], sw: 0.8, dur: 6.4 });
        rep(24, i => { const a = i * 2.39996 + (R() - 0.5) * 0.3, ca = Math.cos(a), sa = Math.sin(a), inner = i % 3 === 0, el0 = inner ? 1.25 : 0.55 + R() * 0.45, len = (inner ? 20 : 25) + R() * 9, n = 10;
          let P = [PX + ca * (inner ? 1 : 4), PY + PH - 0.6, sa * (inner ? 1 : 4)]; const pts = [P];
          for (let j = 0; j < n; j++) { const e = el0 - (inner ? 1.4 : 2.1) * (j / n); P = addv(P, [Math.cos(e) * ca, Math.sin(e), Math.cos(e) * sa], len / n); pts.push(P); }
          E.stem(pts, 0.6, 0.25, '#4a7a2a');
          for (let j = 1; j < n; j++) { const t = j / n, e = el0 - 2 * t; [-1, 1].forEach(sg => E.leaf({ b: pts[j], az: a + sg * (1.2 + R() * 0.2), el: e - 0.3, len: 4.4 * (1 - t * 0.55), wid: 1.6, droop: 0.35, roll: 0.35 * sg, sh: 'lance', col: j % 2 ? '#3f8f34' : '#4c9c3c', col2: '#7ab85a', simple: 1, seg: 3, lk: 0.96 + (inner ? 0.12 : 0) })); }
          E.leaf({ b: pts[n], az: a, el: el0 - 2, len: 2.6, wid: 1.2, droop: 0.2, sh: 'lance', col: '#5aa844', simple: 1, seg: 3 }); });
        const o = E.out();
        // bamboo (separate canvas, all in front of the glass back, under the glass highlights)
        const B = flo(ctx, C, { piv: [VX, 4, 0], sw: 0.25, dur: 8 }), ST = [[-2.4, -1.4, 50], [2.2, -1.8, 50], [0, 2.4, 50], [-3.6, 1.6, 40], [3.6, 1, 40], [-1.2, -3.6, 31], [1.6, 3.8, 31]];
        ST.forEach(([dx, dz, h], i) => { const x = VX + dx, z = dz, y0 = 4.6, col = i % 2 ? '#8cbf4c' : '#9ac85a'; let y = y0, seg = 0;
          while (y < h - 0.5) { const y1 = Math.min(h, y + 8.4 + (i % 3)); B.stem([[x, y, z], [x, y1 - 0.4, z]], 1.5, 1.5, col); if (y1 < h) B.stem([[x - 0.95, y1 - 0.2, z], [x + 0.95, y1 - 0.2, z]], 0.65, 0.65, '#6f9a3a', { db: 0.2 }); y = y1; seg++; }
          B.blob([x, h, z], 0.75, '#c8b878', { sy: 0.5, hl: 0.3, db: 0.3 });
          if (h > 35) [h - 3, h - 9].forEach((yy, j) => { const az = i * 1.7 + j * 2.4; B.stem([[x, yy, z], [x + Math.cos(az) * 2.6, yy + 3, z + Math.sin(az) * 2.6]], 0.45, 0.35, '#5a9a3a'); rep(3, q => B.leaf({ b: [x + Math.cos(az) * 2.6, yy + 3, z + Math.sin(az) * 2.6], az: az + (q - 1) * 0.9, el: 0.55, len: 8, wid: 2.4, droop: 0.75, sh: 'lance', col: '#3f9636', col2: '#78b860', seg: 5, gloss: 1 })); }); });
        const bo = B.out();
        // gold ribbon round the bundle above the water, water line + shimmer, glass rim + highlights
        const gb = (() => { const q = C.P([VX, 17, 0]); return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(5.2 * k)}" ry="${f1(5.2 * k * 0.42)}" fill="none" stroke="#d8ae4a" stroke-width="${f1(1.3 * k)}"/><path d="M${f1(q[0] + 4 * k)} ${f1(q[1] + 1.4 * k)}l${f1(1.6 * k)} ${f1(4 * k)}M${f1(q[0] + 4.4 * k)} ${f1(q[1] + 1.2 * k)}l${f1(3 * k)} ${f1(3 * k)}" stroke="#d8ae4a" stroke-width="${f1(0.7 * k)}"/>`; })();
        const tv = C.thV, wl = `<path d="${cylL(C, VX, 0, VR - 0.4, tv - PI, tv + PI, 15, 30)}" fill="none" stroke="#9ccad8" stroke-width="${f1(0.4 * k)}" opacity="0.8"/>`
          + `<path d="${cylL(C, VX, 0, VR - 1.4, tv - 0.9, tv - 0.2, 15, 6)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.5 * k)}" opacity="0">${an('opacity', '0;0.8;0', 3.6)}</path>`
          + rep(6, i => { const a = tv - 1.4 + i * 0.5, q = C.P([VX + Math.sin(a) * (VR - 2), 2.4 + (i % 2), Math.cos(a) * (VR - 2)]); return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(1.3 * k)}" ry="${f1(0.8 * k)}" fill="${i % 2 ? '#d8d2c6' : '#f8f6f0'}" stroke="#bfb8aa" stroke-width="0.15"/>`; }).join('')
          + `<path d="${cylL(C, VX, 0, VR, tv - PI, tv + PI, VH, 30)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.5 * k)}" opacity="0.8"/>`
          + `<path d="${cylP(C, VX, 0, VR + 0.02, tv - 0.95, tv - 0.7, 2, VH - 1.5, 3)}" fill="#ffffff" opacity="0.38"/><path d="${cylP(C, VX, 0, VR + 0.02, tv + 0.55, tv + 0.62, 3, VH - 3, 2)}" fill="#ffffff" opacity="0.25"/>`;
        // planter: soft matte highlight, brass ring glint
        const pl = `<path d="${cylP(C, PX, 0, PR + 0.04, tv - 1.15, tv - 0.75, PY + 3, PY + PH - 1.5, 4)}" fill="#ffffff" opacity="0.3"/>`;
        const bb = C.bb(3); [o.bb, bo.bb].forEach(b => { bb[0] = Math.min(bb[0], b[0]); bb[1] = Math.min(bb[1], b[1]); bb[2] = Math.max(bb[2], b[2]); bb[3] = Math.max(bb[3], b[3]); });
        return { defs: o.defs + bo.defs, under: shadow(C, VX, 0, 10, 9, 0.4) + shadow(C, PX, 0, 15, 14, 0.35), back: o.back + (pf ? bo.front : ''), front: (pf ? '' : bo.front) + gb + wl + pl + o.front, bb }; };
      return D; };
  }

  // ---- spa plants batch 2: 077 (90 x 34 moss wall) / 097 (110 x 90 koi pond island)
  { const K = () => X.K, { rod } = RD.H16, mixC = (a, b, t) => X.K.mix(a, b, t);
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FLy = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const DP = C => (x, y, z) => x * C.v[0] + y * C.v[1] + z * C.v[2];
    const flo = (ctx, C, o) => new RD.FLX.Flora(ctx, Object.assign({ dp: DP(C) }, o || {}));
    const grow = (bb, b) => { bb[0] = Math.min(bb[0], b[0]); bb[1] = Math.min(bb[1], b[1]); bb[2] = Math.max(bb[2], b[2]); bb[3] = Math.max(bb[3], b[3]); };

    // BTH-077 LIVING VERTICAL MOSS WALL WITH TRICKLING BAMBOO SPOUT (T4): a tall walnut-framed panel planted solid with living moss - cushion mounds in a
    // dozen greens, pale reindeer-moss clusters and tiny ferns tucked in - washed from above by a warm LED strip under the top frame; a cut bamboo spout
    // with nodes juts from the moss and trickles a thin stream into a long honed basalt basin trimmed in brass, with river stones under the water.
    // Live: the stream trickles and splashes, rings spread on the basin, a fine mist lifts and the warm light breathes over the moss.
    N.spa29d = S => { const WN = '#5e3d27', BS = '#2b2d30', BB = '#c4ad62', PZ = -13, PF = -9, BZ = 4, BT = 11, SP0 = [24, 48, PF + 0.5], SP1 = [22, 43, 6.5];
      const D = { w: 90, d: 34, build: () => { const { box } = K(), o = [];
          o.push(box(0, 0, PZ, 88, 94, 8, WN, { r: 1, mat: 'wood' }));
          o.push(box(0, 0, BZ, 88, BT, 24, BS, { r: 1.2, mat: 'gloss' }));
          o.push(rod(SP0, SP1, 2.2, BB, { mat: 'wood' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('spa29d'), k = C.k, fr = vdot(C, [0, 0, 1]) > 0.02, MZ = PF + 0.06, E = flo(ctx, C, { piv: [0, 60, MZ], sw: 0.15, dur: 9 });
        const GR = ['#4f7a2e', '#5f8a34', '#6e9a3a', '#3f6a28', '#7aa846', '#577f30', '#86b24e', '#456f2a'];
        for (let j = 0; j < 14; j++) for (let i = 0; i < 15; i++) { const x = -37 + i * 5.3 + (j % 2) * 2.6 + (R() - 0.5) * 2, y = 16.5 + j * 5.1 + (R() - 0.5) * 2; if (x > 37.5 || y > 84) continue; const col = GR[Math.floor(R() * GR.length)], r = 2.6 + R() * 1.4;
          E.blob([x, y, MZ + 1], r, col, { sy: 0.88, hl: 0.16, ow: 0.12, db: -2 });
          if (R() < 0.35) E.clump([x, y + 0.4, MZ + 1.8], r * 0.8, r * 0.6, 1, 7, { R, cols: [mixC(col, '#ffffff', 0.1), mixC(col, '#d8e868', 0.25)], len: 1.1, wid: 0.6, droop: 0.1, top: 1 }); }
        rep(8, c0 => { const cx = -32 + R() * 62, cy = 20 + R() * 58; rep(16, q => E.blob([cx + (R() - 0.5) * 6, cy + (R() - 0.5) * 4.6, MZ + 2.4], 0.55 + R() * 0.45, R() < 0.5 ? '#d2dcbc' : '#b4c49a', { sy: 0.9, hl: 0.3, ow: 0.1 })); });
        [[-26, 70], [14, 32], [-6, 56], [30, 74]].forEach(([x, y], i) => rep(5, q => { const a = -PI / 2 + (q - 2) * 0.5; E.leaf({ b: [x, y, MZ + 2.4], az: PI / 2 + (q - 2) * 0.5, el: 0.3 + (2 - Math.abs(q - 2)) * 0.25, len: 7, wid: 2.6, droop: 0.7, sh: 'lance', col: '#5aa040', col2: '#8ac060', seg: 5, band: null, vein: 1 }); }));
        const mo = E.out(), bed = PLN(C, [-40, 88, MZ - 0.02], [1, 0, 0], [0, -1, 0], `<rect x="0" y="0" width="80" height="76" fill="#24381c"/><rect x="0" y="0" width="80" height="76" fill="none" stroke="#3a2416" stroke-width="0.8"/>`);
        const lid = C.u('l77'), led = '', ledG = fr ? PLN(C, [-40, 88, MZ + 3], [1, 0, 0], [0, -1, 0], `<defs><linearGradient id="${lid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd890" stop-opacity="0.55"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></linearGradient></defs><rect x="0" y="0" width="80" height="34" fill="url(#${lid})" opacity="0.6">${an('opacity', '0.45;0.75;0.45', 7)}</rect><rect x="1" y="-0.2" width="78" height="1" fill="#fff2cc" opacity="0.9"/>`) : '';
        // bamboo nodes + cut face, stream, splash, rings, basin water + stones + brass, mist
        const nd = !fr ? '' : (() => { const A = C.P(SP0), B = C.P(SP1), ang = Math.atan2(B[1] - A[1], B[0] - A[0]) * 180 / PI, L = Math.hypot(B[0] - A[0], B[1] - A[1]);
          const pipe = `<g transform="translate(${P2(A)}) rotate(${f1(ang)})"><rect x="0" y="${f1(-2.4 * k)}" width="${f1(L)}" height="${f1(4.8 * k)}" fill="#7a6a2a"/><rect x="0" y="${f1(-2.1 * k)}" width="${f1(L)}" height="${f1(4.2 * k)}" fill="${BB}"/><rect x="0" y="${f1(-1.6 * k)}" width="${f1(L)}" height="${f1(1.1 * k)}" fill="#e2d08a"/><rect x="0" y="${f1(1.1 * k)}" width="${f1(L)}" height="${f1(1 * k)}" fill="#9a8840" opacity="0.7"/>`
            + `<ellipse cx="${f1(L)}" cy="0" rx="${f1(1.3 * k)}" ry="${f1(2.1 * k)}" fill="#e8dca0" stroke="#7a6a2a" stroke-width="${f1(0.3 * k)}"/><ellipse cx="${f1(L + 0.2 * k)}" cy="${f1(0.3 * k)}" rx="${f1(0.7 * k)}" ry="${f1(1.3 * k)}" fill="#4a3a1a"/></g>`;
          return pipe + [0.35, 0.72].map(f => { const p = C.P([SP0[0] + (SP1[0] - SP0[0]) * f, SP0[1] + (SP1[1] - SP0[1]) * f, SP0[2] + (SP1[2] - SP0[2]) * f]); return `<ellipse cx="${f1(p[0])}" cy="${f1(p[1])}" rx="${f1(0.5 * k)}" ry="${f1(1.9 * k)}" fill="none" stroke="#7a6a2a" stroke-width="${f1(0.6 * k)}" transform="rotate(${f1(ang)} ${P2(p)})"/>`.replace(/rx="[^"]+" ry="[^"]+"/, `rx="${f1(0.5 * k)}" ry="${f1(2.3 * k)}"`); }).join('')
; })();
        const mouth = C.P([SP1[0], SP1[1] - 1.2, SP1[2] + 0.4]), land = C.P([SP1[0] - 0.4, BT + 0.05, SP1[2] + 2.2]);
        const stream = `<path d="M${P2(mouth)}Q${f1(mouth[0] + 1.2 * k)} ${f1(mouth[1] + 3 * k)} ${P2(land)}" fill="none" stroke="#dff2f6" stroke-width="${f1(0.9 * k)}" stroke-linecap="round" opacity="0.8"/><path d="M${P2(mouth)}Q${f1(mouth[0] + 1.2 * k)} ${f1(mouth[1] + 3 * k)} ${P2(land)}" fill="none" stroke="#ffffff" stroke-width="${f1(0.5 * k)}" stroke-dasharray="${f1(1.6 * k)} ${f1(2.2 * k)}" opacity="0.9">${an('stroke-dashoffset', `0;-${f1(7.6 * k)}`, 0.7)}</path>`;
        const rings = rep(3, i => `<ellipse cx="${f1(land[0])}" cy="${f1(land[1])}" rx="0" ry="0" fill="none" stroke="#e8f6fa" stroke-width="${f1(0.3 * k)}">${an('rx', `${f1(0.5 * k)};${f1(9 * k)}`, 2.4, -i * 0.8)}${an('ry', `${f1(0.25 * k)};${f1(4 * k * Math.abs(C.v[1]))}`, 2.4, -i * 0.8)}${an('opacity', '0.9;0', 2.4, -i * 0.8)}</ellipse>`).join('')
          + rep(4, i => { const a = -PI / 2 + (i - 1.5) * 0.7; return `<circle cx="${f1(land[0])}" cy="${f1(land[1])}" r="${f1(0.35 * k)}" fill="#f2fbff" opacity="0">${an('cx', `${f1(land[0])};${f1(land[0] + Math.cos(a) * 2.6 * k)}`, 0.9, -i * 0.22)}${an('cy', `${f1(land[1])};${f1(land[1] - 2 * k)};${f1(land[1] + 0.5 * k)}`, 0.9, -i * 0.22)}${an('opacity', '0.9;0.9;0', 0.9, -i * 0.22)}</circle>`; }).join('');
        const water = FLy(C, BT + 0.04, `<rect x="-42" y="${BZ - 10}" width="84" height="20" rx="1.4" fill="#1a3034"/><rect x="-41" y="${BZ - 9}" width="82" height="18" rx="1" fill="#24484e"/>`
          + rep(16, () => `<ellipse cx="${f1(-36 + R() * 72)}" cy="${f1(BZ - 7 + R() * 14)}" rx="${f1(1.2 + R() * 1.6)}" ry="${f1(0.8 + R())}" fill="${['#8a8478', '#a8a296', '#6a665e', '#c4bcae'][Math.floor(R() * 4)]}" opacity="0.55"/>`).join('')
          + `<rect x="-41" y="${BZ - 9}" width="82" height="18" rx="1" fill="#3a7a86" opacity="0.18"/>` + rep(5, i => `<path d="M${f1(-34 + i * 15)} ${BZ - 4 + (i % 2) * 6}q4 -1.4 8 0" stroke="#ffffff" stroke-width="0.35" fill="none" opacity="0">${an('opacity', '0;0.55;0', 4 + i * 0.4, -i * 0.9)}</path>`).join('')
          + `<rect x="-44" y="${BZ - 12}" width="88" height="24" rx="1.2" fill="none" stroke="${'#c9a35a'}" stroke-width="0.5" opacity="0.85"/>`);
        const trim = vdot(C, [0, 0, 1]) > 0.05 ? PLN(C, [-44, BT, BZ + 12.03], [1, 0, 0], [0, -1, 0], `<rect x="0" y="0.4" width="88" height="0.9" fill="#c9a35a"/><rect x="0" y="0.4" width="88" height="0.3" fill="#f2dc9a"/>`) : '';
        const sid = C.u('m77'), mist = `<defs><filter id="${sid}" x="-1" y="-1" width="3" height="3"><feGaussianBlur stdDeviation="${f1(1.6 * k)}"/></filter></defs>` + rep(4, i => { const q = C.P([SP1[0] - 10 + i * 7, BT + 1, BZ + 2]), T = 6 + i; return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(6 * k)}" ry="${f1(2.6 * k)}" fill="#ffffff" opacity="0" filter="url(#${sid})">${an('opacity', '0;0.3;0', T, -i * 1.6)}${an('cy', `${f1(q[1])};${f1(q[1] - 16 * k)}`, T, -i * 1.6)}</ellipse>`; }).join('');
        // walnut panel: grain on the visible side and edge
        const grain = !fr ? PLN(C, [44, 94, PZ - 4.03], [-1, 0, 0], [0, -1, 0], rep(14, i => `<path d="M0 ${f1(4 + i * 6.4)}c22 ${f1((R() - 0.5) * 3)} 44 ${f1((R() - 0.5) * 3)} 88 0" stroke="#3e2818" stroke-width="0.35" fill="none" opacity="0.5"/>`).join('')) : PLN(C, [-44, 94, PF + 0.02], [1, 0, 0], [0, -1, 0], `<path d="M0 0H88V94H84V6H4V94H0Z" fill="none"/>` + rep(10, i => `<path d="M${f1(0.6 + (i % 3) * 1.1)} 2V92M${f1(84.6 + (i % 3) * 1.1)} 2V92" stroke="#3e2818" stroke-width="0.25" opacity="0.45"/>`).join(''));
        const front = (fr ? bed + mo.front + led + ledG + nd + water + rings + stream + trim + mist : grain);
        const back = (fr ? '' : bed + mo.front + water + stream) + mo.back;
        const bb = C.bb(3); grow(bb, mo.bb);
        return { defs: mo.defs, under: shadow(C, 0, 2, 46, 18, 0.35), back, front: front + (fr ? grain : ''), bb }; };
      return D; };

    // BTH-097 BONSAI MIST-WATERFALL ISLAND WITH KOI POND PERIMETER (T5): a pond sunk into the floor, ringed with weathered granite stones (moss on the near
    // ones), deep teal water lit warm from below round a craggy stone island; on the island an old juniper bonsai with silver deadwood and cloud pads over
    // cushions of moss, a thread of water slipping down the rock into the pond, lily pads with a pink lotus, drifting petals. Five koi (kohaku, gold ogon,
    // showa, tancho, orange) circle the island. Live: koi swim, the waterfall runs, low mist rolls off the water, rings spread and the underwater light breathes.
    N.spa29e = S => { const AX = 47, AZ = 37, RK = '#6d6862';
      const D = { w: 110, d: 90, round: 1, build: () => { const { ball } = K(), o = [], R = rng('spa29e-st');
          rep(20, i => { const a = i / 20 * 2 * PI + (R() - 0.5) * 0.08, r = 4.2 + R() * 1.3; o.push(ball(Math.cos(a) * (AX + 3), 0, Math.sin(a) * (AZ + 3), r, ['#8a8780', '#75716a', '#9a968c', '#807a70'][i % 4], { sy: 0.45 + R() * 0.25, k: 4, n: 10, mat: 'matte' })); });
          const B0 = ball(0, 0, 0, 19, RK, { sy: 0.5, k: 6, n: 16, mat: 'matte' }); o.push(B0);
          [ball(-5, 10, -5, 9, shade(RK, 0.92), { sy: 0.9, k: 5, n: 14, mat: 'matte' }), ball(8, 6, 4, 8, shade(RK, 1.08), { sy: 0.85, k: 5, n: 12, mat: 'matte' })].forEach(s0 => { s0.par = B0; o.push(s0); });
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('spa29e'), k = C.k, dp = DP(C), dI = dp(0, 10, 0), tid = C.u('t97');
        // ---- water (under layer): rim shadow, depth gradient, warm light, caustics, lily pads, lotus, petals, koi, ripples
        const gw = C.u('w97'), gl = C.u('g97');
        let w = `<defs><radialGradient id="${gw}" cx="50%" cy="50%" r="50%"><stop offset="0.3" stop-color="#0f3a44"/><stop offset="0.8" stop-color="#1f5c66"/><stop offset="1" stop-color="#2f6f72"/></radialGradient>`
          + `<radialGradient id="${gl}" cx="50%" cy="50%" r="50%"><stop offset="0.35" stop-color="#ffd890" stop-opacity="0.55"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient></defs>`
          + `<ellipse rx="${AX + 2}" ry="${AZ + 2}" fill="#1b2626"/><ellipse rx="${AX}" ry="${AZ}" fill="url(#${gw})"/>`
          + `<ellipse rx="30" ry="24" fill="url(#${gl})">${an('opacity', '0.55;0.95;0.55', 6)}</ellipse>`
          + rep(7, i => { const a = i / 7 * 2 * PI, r1 = 26 + (i % 3) * 5; return `<path d="M${f1(Math.cos(a) * r1)} ${f1(Math.sin(a) * r1 * 0.8)}q3 -1.6 6 0t6 0" stroke="#bfe8e8" stroke-width="0.4" fill="none" opacity="0" transform="rotate(${f1(a * 57 + 90)} ${f1(Math.cos(a) * r1)} ${f1(Math.sin(a) * r1 * 0.8)})">${an('opacity', '0;0.4;0', 5 + i * 0.6, -i)}</path>`; }).join('');
        const KOI = [['#f6f2ea', [['#e0402a', 1, -0.3, 1.6], ['#e0402a', -1.6, 0.4, 1.2]]], ['#f2b23a', [['#ffe08a', 2, 0, 0.8]]], ['#1e1c1e', [['#e0402a', 0.6, 0.4, 1.3], ['#f6f2ea', -1.8, -0.3, 1.1]]], ['#f6f2ea', [['#d82a2a', 2.6, 0, 0.75]]], ['#f07a2a', [['#f6f2ea', -1, 0, 1]]]];
        const fish = (body, sp) => `<g><ellipse cx="-0.4" cy="1.2" rx="4.6" ry="1.4" fill="#000" opacity="0.18"/><g>${'<animateTransform attributeName="transform" type="rotate" values="-6;6;-6" dur="0.9s" repeatCount="indefinite"/>'}`
          + `<path d="M-3.6 0L-6.4 -2.2Q-5.6 0 -6.4 2.2Z" fill="${body}" opacity="0.85"/><path d="M-0.6 -1.3l-1.2 -1.6l2.4 0.9ZM-0.6 1.3l-1.2 1.6l2.4 -0.9Z" fill="${body}" opacity="0.7"/>`
          + `<path d="M4.4 0C3.6 -1.7 -1 -1.9 -3.8 -0.4L-3.8 0.4C-1 1.9 3.6 1.7 4.4 0Z" fill="${body}" stroke="${shade(body, 0.6)}" stroke-width="0.15"/>` + sp.map(([c, x, y, r]) => `<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${f1(r * 0.62)}" fill="${c}"/>`).join('') + `<circle cx="3.2" cy="-0.6" r="0.22" fill="#1a1a1a"/><circle cx="3.2" cy="0.6" r="0.22" fill="#1a1a1a"/></g></g>`;
        KOI.forEach(([b, sp], i) => { const rx = 30 + (i % 3) * 4, rz = 24 + (i % 3) * 3.4, cw = i % 2, T = 20 + i * 3, pth = cw ? `M${rx} 0A${rx} ${rz} 0 1 1 ${-rx} 0A${rx} ${rz} 0 1 1 ${rx} 0` : `M${rx} 0A${rx} ${rz} 0 1 0 ${-rx} 0A${rx} ${rz} 0 1 0 ${rx} 0`;
          w += `<g>${fish(b, sp)}<animateMotion path="${pth}" dur="${T}s" begin="${-i * T / 5}s" repeatCount="indefinite" rotate="auto"/></g>`; });
        const pad = (x, z, r, a) => `<g transform="translate(${x} ${z}) rotate(${a})"><path d="M0 0L${r} -0.6A${r} ${r * 0.9} 0 1 0 ${r} 0.6Z" fill="#4f8a3a" stroke="#2f5a26" stroke-width="0.2"/>` + rep(6, j => `<path d="M0 0L${f1(Math.cos(j * 1.05 + 0.5) * r * 0.85)} ${f1(Math.sin(j * 1.05 + 0.5) * r * 0.75)}" stroke="#7ab85a" stroke-width="0.18"/>`).join('') + `</g>`;
        w += pad(-34, 14, 4.6, 20) + pad(-28, 20, 3.2, 140) + pad(36, -12, 4, 250) + pad(30, 18, 3.4, 300);
        w += `<g transform="translate(-31 16)">` + rep(8, j => `<ellipse cx="0" cy="-1.6" rx="1" ry="2.2" fill="${j % 2 ? '#f6b8cc' : '#fbd4e0'}" stroke="#d87a9a" stroke-width="0.12" transform="rotate(${j * 45})"/>`).join('') + `<circle r="0.9" fill="#f2c94c"/></g>`;
        rep(5, i => { const x0 = -40 + R() * 80, z0 = -28 + R() * 56; if (Math.hypot(x0 / 22, z0 / 18) < 1.1) return; w += `<ellipse cx="${f1(x0)}" cy="${f1(z0)}" rx="0.9" ry="0.55" fill="#f8c8d6" opacity="0.9">${an('cx', `${f1(x0)};${f1(x0 + 5)};${f1(x0)}`, 14 + i * 2, -i * 3)}${an('cy', `${f1(z0)};${f1(z0 + 2)};${f1(z0)}`, 11 + i, -i * 2)}</ellipse>`; });
        rep(3, i => { w += `<ellipse cx="13" cy="21" rx="0" ry="0" fill="none" stroke="#e8f6fa" stroke-width="0.3">${an('rx', '0.5;9', 2.6, -i * 0.87)}${an('ry', '0.4;7', 2.6, -i * 0.87)}${an('opacity', '0.8;0', 2.6, -i * 0.87)}</ellipse>`; });
        const water = FLy(C, 0.05, w); [[-AX - 8, -AZ - 8], [AX + 8, AZ + 8], [-AX - 8, AZ + 8], [AX + 8, -AZ - 8]].forEach(([x, z]) => C.P([x, 0, z]));
        // ---- island: moss cushions, juniper bonsai with deadwood
        const E = flo(ctx, C, { split: dp(-5, 26, -5), piv: [-5, 26, -5], sw: 0.35, dur: 8 });
        [[-12, 16.4, 5, 4.5], [3, 16.6, -12.4, 4], [-13.4, 16.2, -4, 3.6], [-1, 25.4, -2.6, 3.4], [8, 19.4, 4, 3]].forEach(([x, y, z, r], i) => E.clump([x, y, z], r, 1.4, r * 0.8, 16, { R, cols: ['#5f8a34', '#6e9a3a', '#4f7a2e', '#86b24e'], len: 1.6, wid: 1, droop: 0.1, top: 0.6 }));
        RD.FLX.bonsai(E, -5, 26, -5, 0.95, R, [[-16, 15, 2, 12, 4.4, 9], [12, 20, -2, 10.5, 4, 8], [3, 29, 0, 12, 5, 9], [-7, 23, 4, 7.4, 3.2, 6]]);
        E.stem([[-5, 26.6, -5], [-2, 31.6, -3], [1, 36.6, -4.5], [-1, 40.6, -4]], 1.2, 0.5, '#e2ddd0'); E.stem([[-8, 28.6, -4], [-12, 31.6, -2], [-13, 34.6, -3]], 0.8, 0.4, '#d6d0c2');
        const io = E.out();
        // ---- moss caps on the near rim stones
        let caps = ''; { const R2 = rng('spa29e-st'); rep(20, i => { const a = i / 20 * 2 * PI + (R2() - 0.5) * 0.08, r = 4.2 + R2() * 1.3, sy = 0.45 + R2() * 0.25, x = Math.cos(a) * (AX + 3), z = Math.sin(a) * (AZ + 3);
          if (i % 3 || dp(x, 0, z) < dI + 6) return; const q = C.P([x - 0.6, r * 2 * sy - 0.6, z]); caps += `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(r * 0.62 * k)}" ry="${f1(r * 0.3 * k)}" fill="#5f8a34" opacity="0.85"/>` + rep(6, j => `<circle cx="${f1(q[0] + (R2() - 0.5) * r * k)}" cy="${f1(q[1] + (R2() - 0.5) * r * 0.4 * k)}" r="${f1(0.5 * k)}" fill="#86b24e"/>`).join(''); }); }
        // ---- waterfall down the island's +z face; mist off the falls and rolling over the water
        const vis = vdot(C, [0.35, 0, 0.94]) > 0.05, WF = [[7, 13.2, 10.5], [8.4, 9, 14.6], [9.6, 4, 17.4], [10.4, 0.2, 19.6]].map(p => C.P(p)), wd = 'M' + P2(WF[0]) + 'C' + P2(WF[1]) + ' ' + P2(WF[2]) + ' ' + P2(WF[3]);
        const fall = `<path d="${wd}" fill="none" stroke="#bfe6ee" stroke-width="${f1(1.6 * k)}" stroke-linecap="round" opacity="0.5"/><ellipse cx="${f1(WF[3][0])}" cy="${f1(WF[3][1])}" rx="${f1(2.4 * k)}" ry="${f1(1 * k)}" fill="#ffffff" opacity="0.6">${an('rx', `${f1(2 * k)};${f1(2.8 * k)};${f1(2 * k)}`, 0.6)}</ellipse><path d="${wd}" fill="none" stroke="#ffffff" stroke-width="${f1(0.6 * k)}" stroke-dasharray="${f1(1.4 * k)} ${f1(2 * k)}" opacity="0.9">${an('stroke-dashoffset', `0;-${f1(6.8 * k)}`, 0.8)}</path>`;
        const mid = C.u('m97'), mist = `<defs><filter id="${mid}" x="-1" y="-1" width="3" height="3"><feGaussianBlur stdDeviation="${f1(2.2 * k)}"/></filter></defs>`
          + rep(6, i => { const a = i / 6 * 2 * PI + 0.4, q0 = C.P([Math.cos(a) * 22, 1, Math.sin(a) * 18]), q1 = C.P([Math.cos(a) * 40, 1, Math.sin(a) * 32]), T = 9 + i; return `<ellipse cx="${f1(q0[0])}" cy="${f1(q0[1])}" rx="${f1(8 * k)}" ry="${f1(3 * k)}" fill="#ffffff" opacity="0" filter="url(#${mid})">${an('cx', `${f1(q0[0])};${f1(q1[0])}`, T, -i * 1.5)}${an('cy', `${f1(q0[1])};${f1(q1[1])}`, T, -i * 1.5)}${an('opacity', '0;0.32;0', T, -i * 1.5)}</ellipse>`; }).join('')
          + (vis ? rep(3, i => { const q = C.P([11, 2, 20]), T = 5 + i; return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(4 * k)}" ry="${f1(2.4 * k)}" fill="#ffffff" opacity="0" filter="url(#${mid})">${an('opacity', '0;0.4;0', T, -i * 1.7)}${an('cy', `${f1(q[1])};${f1(q[1] - 12 * k)}`, T, -i * 1.7)}</ellipse>`; }).join('') : '');
        const bb = C.bb(3); grow(bb, io.bb);
        return { defs: io.defs, under: water, back: io.back + (vis ? '' : fall), front: (vis ? fall : '') + caps + io.front + mist, bb }; };
      return D; };
  }

  // ---- bath surface batch 1: 019 (22 x 22) / 039 (52 x 40) / 059 (50 x 50, host top)
  { const K = () => X.K, sol = o => X.K.solid(o), { rod } = RD.H16, { rip } = RD.H29T;
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FLy = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const nrm = v => { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; };
    // candle flame: teardrop at p, flickering, with a soft warm halo
    const flame = (C, p, s, b) => { const q = C.P(p), k = C.k * (s || 1), id = C.u('fl');
      return `<defs><radialGradient id="${id}"><stop offset="0" stop-color="#ffd27a" stop-opacity="0.55"/><stop offset="1" stop-color="#ffb04a" stop-opacity="0"/></radialGradient></defs><circle cx="${f1(q[0])}" cy="${f1(q[1] - 1.4 * k)}" r="${f1(7 * k)}" fill="url(#${id})">${an('opacity', '0.7;1;0.8;0.95;0.7', 1.7, b)}</circle>`
        + `<g transform="translate(${P2(q)})"><g>${at('scale', '1 1;0.92 1.12;1.05 0.94;1 1', 0.9, b)}<path d="M0 ${f1(-4 * k)}C${f1(1.6 * k)} ${f1(-1.6 * k)} ${f1(1.4 * k)} 0 0 0C${f1(-1.4 * k)} 0 ${f1(-1.6 * k)} ${f1(-1.6 * k)} 0 ${f1(-4 * k)}Z" fill="#ffb648"/><path d="M0 ${f1(-2.6 * k)}C${f1(0.8 * k)} ${f1(-1.2 * k)} ${f1(0.7 * k)} ${f1(-0.2 * k)} 0 ${f1(-0.2 * k)}C${f1(-0.7 * k)} ${f1(-0.2 * k)} ${f1(-0.8 * k)} ${f1(-1.2 * k)} 0 ${f1(-2.6 * k)}Z" fill="#fff4cc"/></g></g>`; };
    const steamUp = (C, p, n, h, T, w) => { const id = C.u('st'), k = C.k; return `<defs><filter id="${id}" x="-1" y="-1" width="3" height="3"><feGaussianBlur stdDeviation="${f1(0.8 * k)}"/></filter></defs>` + rep(n, i => { const q = C.P(p), d = (i % 2 ? 1 : -1) * (w || 1.6) * k;
      return `<path d="M${P2(q)}q${f1(d)} ${f1(-h * 0.3 * k)} 0 ${f1(-h * 0.55 * k)}t0 ${f1(-h * 0.45 * k)}" stroke="#ffffff" stroke-width="${f1(1.2 * k)}" fill="none" stroke-linecap="round" opacity="0" filter="url(#${id})">${an('opacity', '0;0.55;0', T, -i * T / n)}${at('translate', `0 0;0 ${f1(-h * 0.35 * k)}`, T, -i * T / n)}</path>`; }).join(''); };

    // BTH-019 SUCTION-CUP PLASTIC CORNER SOAP DISH (T1): a cheap quarter-round corner dish in yellowed aqua plastic with drain ribs, two grey suction cups
    // on its back edges (one gone cloudy and slipped), a cracked, shrunken bar of soap gone grey at the edges with a hair stuck to it, soap-scum slime
    // oozing over the front rim, black mildew dots along the rim and a milky puddle on the floor. Live: slimy drops gather at the rim and drip into the puddle.
    N.surf29a = S => { const PL = '#a6d2d0', CX = -9, CZ = -9, RA = 17, TH = 3, SB = [-0.6, TH + 0.5, -1.4];
      const D = { w: 22, d: 22, build: () => { const { box } = K(), o = [];
          const T0 = sol({ ax: 'y', sh: 'poly', c: [CX, CZ], pts: [[0, 0]].concat(rep(13, i => { const t = i / 12 * PI / 2; return [Math.cos(t) * RA, Math.sin(t) * RA]; })), rings: [[0, 0, 0.93], [0.7, 0, 1], [TH, 0, 1]], col: PL, mat: 'plastic' }); o.push(T0);
          glue(o, T0, rep(6, i => { const z = -6.8 + i * 2.3, x1 = CX + Math.sqrt(RA * RA - (z - CZ) * (z - CZ)) - 1.6, x0 = CX + 1.4; return box((x0 + x1) / 2, TH, z, x1 - x0, 0.5, 0.9, X.K.shade(PL, 0.94), { r: 0.2, mat: 'plastic' }); }));
          o.push(sol({ ax: 'z', sh: 'el', c: [2.6, 1.9], a: 2.3, b: 2.3, n: 14, rings: [[CZ - 0.12, 0, 0.35], [CZ - 0.9, 0, 0.45], [CZ - 1.4, 0, 0.8], [CZ - 1.9, 0, 1]], col: '#9aa4a8', mat: 'plastic' }));
          o.push(sol({ ax: 'x', sh: 'el', c: [2.2, 1.4], a: 2.1, b: 2.1, n: 14, rings: [[CX - 0.12, 0, 0.35], [CX - 0.9, 0, 0.45], [CX - 1.4, 0, 0.8], [CX - 1.9, 0, 1]], col: '#c8ccc6', mat: 'plastic' }));
          o.push(box(SB[0], SB[1], SB[2], 8.4, 2.4, 5.8, '#e6dcc0', { r: 1.3, mat: 'matte' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('surf29a'), k = C.k, tp = SB[1] + 2.4;
        const soap = FLy(C, tp + 0.02, `<rect x="${SB[0] - 4.2}" y="${SB[2] - 2.9}" width="8.4" height="5.8" rx="1.3" fill="none" stroke="#c4b898" stroke-width="0.4" opacity="0.5"/><path d="M${SB[0] - 2.6} ${SB[2] - 1.6}l1.6 0.9l0.6 1.5l1.8 0.4" stroke="#8a7e64" stroke-width="0.22" fill="none"/>`
          + `<path d="M${SB[0] - 1} ${SB[2] + 1.6}q1.6 -0.8 2.6 0.4t2.2 -0.6" stroke="#2a2420" stroke-width="0.09" fill="none"/><ellipse cx="${SB[0] + 2}" cy="${SB[2] - 1.2}" rx="1.2" ry="0.7" fill="#c8bca0" opacity="0.6"/>`);
        // rim mildew + front ooze, on the visible part of the round side
        let side = ''; rep(16, i => { const t = (i + 0.5) / 16 * PI / 2, n = [Math.cos(t), 0, Math.sin(t)]; if (vdot(C, n) < 0.15) return; const p = [CX + Math.cos(t) * (RA + 0.05), 0.6 + R() * 2, CZ + Math.sin(t) * (RA + 0.05)], q = C.P(p);
          side += `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1((0.15 + R() * 0.2) * k)}" fill="#2a2e26" opacity="0.7"/>`; });
        const tO = PI / 4, nO = [Math.cos(tO), 0, Math.sin(tO)], fr = vdot(C, nO) > 0.1, rimP = [CX + Math.cos(tO) * (RA + 0.1), TH, CZ + Math.sin(tO) * (RA + 0.1)], flr = [rimP[0] + 0.6, 0.04, rimP[2] + 0.6];
        let ooze = ''; if (fr) { const a = C.P([rimP[0], TH + 0.1, rimP[2]]), b = C.P([rimP[0], 1.2, rimP[2]]), w = 1.4 * k; ooze = `<path d="M${f1(a[0] - w)} ${f1(a[1])}Q${f1(a[0] - w * 0.8)} ${f1(b[1])} ${f1(b[0])} ${f1(b[1] + 0.6 * k)}Q${f1(a[0] + w * 0.8)} ${f1(b[1])} ${f1(a[0] + w)} ${f1(a[1])}Z" fill="#e8ecd8" opacity="0.7"/>`
          + (() => { const KQ = ` keyTimes="0;0.7;0.9;0.91;1" dur="5.2s" repeatCount="indefinite"`, g = C.P(flr); return `<ellipse cx="${f1(b[0])}" cy="${f1(b[1])}" rx="${f1(0.45 * k)}" ry="${f1(0.6 * k)}" fill="#eef0e0" stroke="#b8bca8" stroke-width="0.1"><animate attributeName="cy" values="${f1(b[1])};${f1(b[1] + 0.7 * k)};${f1(g[1])};${f1(b[1])};${f1(b[1])}"${KQ}/><animate attributeName="opacity" values="0.9;0.9;0.9;0;0.9"${KQ}/></ellipse>` + rip(C, flr, 5.2, 0.1 * 5.2, 0.6); })(); }
        const under = shadow(C, 0, 0, 12, 12, 0.3) + FLy(C, 0.03, `<ellipse cx="${f1(flr[0])}" cy="${f1(flr[2])}" rx="5.4" ry="3.6" fill="#dfe6e2" opacity="0.55"/><ellipse cx="${f1(flr[0] - 0.6)}" cy="${f1(flr[2] - 0.4)}" rx="3.4" ry="2" fill="#ffffff" opacity="0.35"/><path d="M${f1(flr[0] - 3)} ${f1(flr[2] + 1.6)}q2 -1.4 4 -0.2t3 0.6" stroke="#2a2420" stroke-width="0.1" fill="none"/>`);
        return { under, front: soap + side + ooze, bb: C.bb(4) }; };
      return D; };

    // BTH-039 EXPANDABLE BAMBOO BATHTUB READING CADDY (T2): a slatted bamboo caddy with both extension arms pulled out to their end grips, a hinged book
    // rest with a lip holding a paperback open (cream pages, text, a worn cover), a sage stoneware mug of tea with the tea-bag tag hanging over the rim,
    // and a tealight in a tin. Live: steam curls off the tea and the tealight flickers.
    N.surf29b = S => { const BA = '#d9b878', BD = '#b8945a', TY = 3.6, MG = [10, TY, -4], TL = [15.6, TY, 6.4];
      // book rest: tilted panel, x -19 .. -3; section in (z, y): bottom z -2.2..-0.8, top z -7..-5.6 at height +12
      const BR0 = [-2.2, TY], BRt = [-5.6, TY + 12], BRb = [-0.8, TY];
      const D = { w: 52, d: 40, build: () => { const { box, cyl } = K(), o = [];
          [-1, 1].forEach(s => { const A = box(s * 16, 0.6, 0, 20, 1.4, 18, BD, { r: 0.4, mat: 'wood' }); o.push(A); glue(o, A, [box(s * 25.6, 0, 0, 1.2, 2.4, 18, BD, { r: 0.4, mat: 'wood' })]); });
          const T0 = box(0, 2, 0, 38, 1.6, 24, BA, { r: 0.8, mat: 'wood' }); o.push(T0);
          glue(o, T0, rep(5, i => box(0, TY, -9.6 + i * 4.8, 37, 0.04, 0.35, '#8a6a3a', { r: 0, noOut: 1, mat: 'matte' })));
          o.push(sol({ ax: 'x', sh: 'poly', c: [0, 0], pts: [[BR0[0], BR0[1]], [BRb[0], BRb[1]], [BRt[0] + 1.4, BRt[1]], [BRt[0], BRt[1]]], rings: [[-19, 0, 1], [-3, 0, 1]], col: BA, mat: 'wood' }));
          o.push(box(-11, TY, 0.6, 16, 1.4, 1.6, BD, { r: 0.4, mat: 'wood' }));
          o.push(cyl(MG[0], TY, MG[2], 3.6, 7, '#9fb89a', { n: 22, rg: [[0, 0, 0.92], [1, 0, 1], [7, 0, 1.02]], mat: 'gloss' }));
          o.push(cyl(TL[0], TY, TL[2], 2.4, 1.4, '#d4d8dc', { n: 18, mat: 'metal' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('surf29b'), k = C.k;
        // paperback on the rest: the rest's front face runs from (z -0.8, y TY) up to (z -4.2, y TY+12)
        const P0 = [-18.4, TY + 11.6, -4.2 + 0.25], Dn = nrm([0, -12, 3.4]), Ln = 12.2, fN = nrm([0, 3.4, 12]), bf = vdot(C, fN) > 0.05;
        const book = bf ? PLN(C, [P0[0], P0[1], P0[2] + 0.12], [1, 0, 0], Dn, `<rect x="-0.4" y="-0.3" width="16.2" height="${f1(Ln - 0.2)}" rx="0.4" fill="#b8402e"/><path d="M0 0.4Q3.8 -0.6 7.7 0.6V${f1(Ln - 1)}Q3.8 ${f1(Ln - 2)} 0 ${f1(Ln - 1)}Z" fill="#f4ecd8"/><path d="M7.7 0.6Q11.6 -0.6 15.4 0.4V${f1(Ln - 1)}Q11.6 ${f1(Ln - 2)} 7.7 ${f1(Ln - 1)}Z" fill="#efe6d0"/>`
          + `<path d="M7.7 0.6V${f1(Ln - 1)}" stroke="#b8ac90" stroke-width="0.35"/><path d="M6.6 1V${f1(Ln - 1.4)}" stroke="#d8ccb0" stroke-width="0.9" opacity="0.6"/>` + rep(9, i => { const y = 1.8 + i * 1.02; return `<path d="M1 ${f1(y)}H${f1(6.4 - (i === 4 ? 2 : 0))}M9 ${f1(y)}H${f1(14.4 - (i === 7 ? 3 : 0))}" stroke="#8a8478" stroke-width="0.32" opacity="0.75"/>`; }).join('')
          + `<path d="M1 0.9H5" stroke="#3a3430" stroke-width="0.5"/>`) : '';
        // tea: surface, rim, bag string + tag over the front, handle
        const mt = MG[1] + 7, tea = FLy(C, mt - 0.6, `<ellipse cx="${MG[0]}" cy="${MG[2]}" rx="3.3" ry="3.3" fill="#8a4a1e"/><ellipse cx="${MG[0] - 0.6}" cy="${MG[2] - 0.8}" rx="1.6" ry="0.9" fill="#c87a3a" opacity="0.5"/>`) + FLy(C, mt + 0.02, `<circle cx="${MG[0]}" cy="${MG[2]}" r="3.6" fill="none" stroke="#e8eee4" stroke-width="0.35"/>`);
        const tagA = [MG[0] + 1.6, mt, MG[2] + 3.3], fT = vdot(C, [0.4, 0, 0.9]) > 0.1;
        const tag = fT ? (() => { const a = C.P([MG[0] + 0.6, mt - 0.6, MG[2] + 1]), b = C.P(tagA), c = C.P([tagA[0] + 0.3, mt - 3.6, tagA[2] + 0.1]); return `<path d="M${P2(a)}L${P2(b)}L${P2(c)}" stroke="#f2ead6" stroke-width="${f1(0.18 * k)}" fill="none"/><rect x="${f1(c[0] - 1.1 * k)}" y="${f1(c[1])}" width="${f1(2.2 * k)}" height="${f1(1.8 * k)}" fill="#e8c860" stroke="#b89a3a" stroke-width="0.12"/>`; })() : '';
        const hv = vdot(C, [1, 0, 0]), hnd = (() => { const a = C.P([MG[0] + 3.7, MG[1] + 5.4, MG[2]]), b = C.P([MG[0] + 3.7, MG[1] + 1.8, MG[2]]), o2 = C.P([MG[0] + 6.4, MG[1] + 3.6, MG[2]]); return `<path d="M${P2(a)}Q${f1(o2[0] + (o2[0] - (a[0] + b[0]) / 2) * 0.4)} ${f1(o2[1])} ${P2(b)}" stroke="#7f9a7a" stroke-width="${f1(1.3 * k)}" fill="none" stroke-linecap="round"/><path d="M${P2(a)}Q${f1(o2[0] + (o2[0] - (a[0] + b[0]) / 2) * 0.4)} ${f1(o2[1])} ${P2(b)}" stroke="#b4c8ae" stroke-width="${f1(0.4 * k)}" fill="none"/>`; })();
        const tlt = FLy(C, TL[1] + 1.42, `<circle cx="${TL[0]}" cy="${TL[2]}" r="2" fill="#f4f0e4"/><circle cx="${TL[0]}" cy="${TL[2]}" r="0.5" fill="#d8c890"/>`), wick = C.P([TL[0], TL[1] + 1.6, TL[2]]);
        const fl = flame(C, [TL[0], TL[1] + 1.9, TL[2]], 0.75, 0) + `<path d="M${P2(wick)}l0 ${f1(-0.6 * k)}" stroke="#2a2420" stroke-width="${f1(0.25 * k)}"/>`;
        const st = steamUp(C, [MG[0], mt + 0.5, MG[2]], 3, 12, 4.2, 1.4);
        return { under: shadow(C, 0, 0, 26, 16, 0.3), back: hv < -0.2 ? hnd : '', front: book + tea + (hv >= -0.2 ? hnd : '') + tag + tlt + `<path d="M${P2(wick)}l0 ${f1(-0.7 * k)}" stroke="#2a2420" stroke-width="${f1(0.3 * k)}"/>` + fl + st, bb: C.bb(5) }; };
      return D; };

    // BTH-059 TEAK PEDESTAL SPA SIDE TABLE FOR TEA & TOWELS (T3): a solid oiled-teak round top with a softened edge on a turned teak pedestal and round foot,
    // golden grain; at the back a white ceramic teapot with a bamboo handle, a celadon cup of green tea, and a little pyramid of rolled white spa towels
    // with grey stripes. Live: steam rises from the cup and the spout, a warm glint moves across the oiled top.
    N.surf29c = S => { const TK = '#b07a42', TOP = 30, TP = [7, TOP, -9], CU = [15.2, TOP, -1.6];
      const roll = (x0, x1, y, z, r, col) => sol({ ax: 'x', sh: 'el', c: [z, y + r], a: r, b: r, n: 16, rings: [[x0, 0, 0.9], [x0 + 0.5, 0, 1], [x1 - 0.5, 0, 1], [x1, 0, 0.9]], col, mat: 'fab', soft: 1 });
      const D = { w: 50, d: 50, round: 1, topH: TOP, topZ: 4, topW: 26, build: () => { const { cyl, ball } = K(), o = [], TX = { tex: 'url(#t59g) none', texO: 0.85 };
          o.push(cyl(0, 0, 0, 13, 2.6, TK, Object.assign({ n: 28, rg: [[0, 0, 1], [1.8, 0, 0.97], [2.6, 0, 0.82]], mat: 'wood' }, TX)));
          o.push(cyl(0, 2.6, 0, 5.4, TOP - 5.6, TK, Object.assign({ n: 22, rg: [[0, 0, 0.9], [2, 0, 0.62], [6, 0, 0.72], [9, 0, 0.6], [18, 0, 0.66], [22, 0, 0.82], [TOP - 5.6, 0, 1]], mat: 'wood' }, TX)));
          o.push(cyl(0, TOP - 3, 0, 22, 3, TK, Object.assign({ n: 40, rg: [[0, 0, 0.95], [1, 0, 0.99], [2.4, 0, 1], [3, 0, 0.98]], mat: 'gloss' }, TX)));
          // teapot: body, lid, knob, spout
          const TB = ball(TP[0], TOP, TP[2], 4.6, '#f4f1ea', { sy: 0.78, n: 18, mat: 'gloss' }); o.push(TB);
          glue(o, TB, [cyl(TP[0], TOP + 6.6, TP[2], 2.4, 0.8, '#ece8e0', { n: 16, mat: 'gloss' }), ball(TP[0], TOP + 7.3, TP[2], 0.8, '#ece8e0', { n: 10, mat: 'gloss' })]);
          o.push(rod([TP[0] + 4, TOP + 2.6, TP[2] + 0.4], [TP[0] + 8, TOP + 6, TP[2] + 0.8], 0.75, '#f4f1ea', { mat: 'gloss' }));
          o.push(cyl(CU[0], TOP, CU[2], 2.6, 3.6, '#b8d4c0', { n: 18, rg: [[0, 0, 0.62], [1.2, 0, 0.9], [3.6, 0, 1]], mat: 'gloss' }));
          // towels: two rolls + one on top (glued)
          const W1 = roll(-17, -5, TOP, -8.4, 2.9, '#f6f4ee'), W2 = roll(-17, -5, TOP, -2.4, 2.9, '#f2f0ea'); o.push(W1, W2); glue(o, W1, [roll(-16.4, -5.6, TOP + 5, -5.4, 2.9, '#f8f6f0')]);
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('surf29c'), k = C.k;
        const gr = rep(7, () => { const y0 = R() * 40; let d = `M0 ${f1(y0)}`; for (let x = 10; x <= 40; x += 10) d += `Q${x - 5} ${f1(y0 + (R() - 0.5) * 5)} ${x} ${f1(y0 + (R() - 0.5) * 3)}`; return `<path d="${d}" stroke="${R() < 0.3 ? '#8a5a2e' : '#c8925a'}" stroke-width="${f1(0.2 + R() * 0.25)}" fill="none" opacity="0.4"/>`; }).join('');
        const defs = `<pattern id="t59g" width="40" height="40" patternUnits="userSpaceOnUse">${gr}</pattern>`;
        // towel stripes on the visible ends + roll spirals
        let tw = ''; [[-5, -8.4, TOP], [-5, -2.4, TOP], [-5.6, -5.4, TOP + 5]].forEach(([x, z, y]) => { if (vdot(C, [1, 0, 0]) < 0.12) return; const c = C.P([x + 0.02, y + 2.9, z]); tw += `<path d="M${P2(c)}m${f1(1.6 * k)} 0a${f1(1.6 * k)} ${f1(1.6 * k)} 0 1 0 ${f1(-0.4 * k)} ${f1(1 * k)}a${f1(0.9 * k)} ${f1(0.9 * k)} 0 1 1 ${f1(0.2 * k)} ${f1(-0.6 * k)}" stroke="#c8c4bc" stroke-width="${f1(0.3 * k)}" fill="none"/>`; });
        [[-8.4, TOP], [-2.4, TOP], [-5.4, TOP + 5]].forEach(([z, y], i) => [-0.3, 0.3].forEach(dx => { const x = (i === 2 ? -9 : -9.4) + dx * 6, n = [0, 0.3, 1]; if (vdot(C, nrm([0, 0.4, 1])) < 0.1 && vdot(C, [0, 1, 0]) < 0.5) return; const a = C.P([x, y + 5.7, z]), b = C.P([x, y + 2.9, z + 2.9]); tw += `<path d="M${P2(a)}Q${f1((a[0] + b[0]) / 2)} ${f1(a[1] + (b[1] - a[1]) * 0.35)} ${P2(b)}" stroke="#a8b0b8" stroke-width="${f1(0.45 * k)}" fill="none" opacity="0.7"/>`; }));
        // teapot handle (bamboo arc over the lid), tea surface, cup rim
        const hA = C.P([TP[0] - 3, TOP + 6, TP[2]]), hB = C.P([TP[0] + 3, TOP + 6, TP[2]]), hT = C.P([TP[0], TOP + 12.4, TP[2]]);
        const hnd = `<path d="M${P2(hA)}Q${f1(hT[0])} ${f1(hT[1] - (hA[1] - hT[1]) * 0.25)} ${P2(hB)}" stroke="#7a5a2a" stroke-width="${f1(1.4 * k)}" fill="none" stroke-linecap="round"/><path d="M${P2(hA)}Q${f1(hT[0])} ${f1(hT[1] - (hA[1] - hT[1]) * 0.25)} ${P2(hB)}" stroke="#c8a060" stroke-width="${f1(0.8 * k)}" fill="none" stroke-dasharray="${f1(2.4 * k)} ${f1(0.4 * k)}"/>`;
        const tea = FLy(C, TOP + 3.1, `<circle cx="${CU[0]}" cy="${CU[2]}" r="2.3" fill="#b8b05a"/><ellipse cx="${CU[0] - 0.5}" cy="${CU[2] - 0.6}" rx="1" ry="0.6" fill="#e0d88a" opacity="0.6"/>`) + FLy(C, TOP + 3.62, `<circle cx="${CU[0]}" cy="${CU[2]}" r="2.6" fill="none" stroke="#e4f0e8" stroke-width="0.3"/>`);
        const gl = (() => { const id = C.u('g59'); return PLN(C, [-22, TOP + 0.02, -22], [1, 0, 0], [0, 0, 1], `<defs><clipPath id="${id}"><path d="M0.4 22H43.6A21.6 21.6 0 0 1 0.4 22Z"/></clipPath></defs><g clip-path="url(#${id})"><ellipse cx="0" cy="40" rx="5" ry="2.4" fill="#fff4dc" opacity="0.35" transform="rotate(-30 0 40)">${an('cx', '-6;48', 9)}${an('cy', '42;4', 9)}</ellipse></g>`); })();
        const st = steamUp(C, [CU[0], TOP + 4, CU[2]], 3, 11, 4.4, 1.3) + steamUp(C, [TP[0] + 8.2, TOP + 6.4, TP[2] + 0.8], 2, 7, 3.6, 1);
        return { defs, under: shadow(C, 0, 0, 16, 16, 0.4), front: gl + tw + tea + hnd + st, bb: C.bb(5) }; };
      return D; };
  }

  // ---- bath surface batch 2: 079 (60 x 42 host trolley) / 099 (52 x 40 floating tray)
  { const K = () => X.K, sol = o => X.K.solid(o), { rod } = RD.H16;
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FLy = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const nrm = v => { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; };
    const bubbles = (C, x, z, y0, y1, r, n, T) => rep(n, i => { const a = i * 2.4, q0 = C.P([x + Math.cos(a) * r * 0.5, y0, z + Math.sin(a) * r * 0.4]), q1 = C.P([x + Math.cos(a) * r * 0.3, y1, z + Math.sin(a) * r * 0.3]), d = T * (0.7 + (i % 3) * 0.2);
      return `<circle cx="${f1(q0[0])}" cy="${f1(q0[1])}" r="${f1(0.22 * C.k)}" fill="#fff8e0" opacity="0">${an('cy', `${f1(q0[1])};${f1(q1[1])}`, d, -i * d / n)}${an('opacity', '0;0.95;0.9;0', d, -i * d / n)}</circle>`; }).join('');

    // BTH-079 BRASS & TRAVERTINE ROLLING SPA TROLLEY (T4): a brushed-brass tube frame on four brass casters carrying two honed travertine shelves (honey
    // banding, open pores), a brass towel bar at one end with a waffle hand towel over it; on top a glass carafe of cucumber-mint water with two tumblers,
    // below a stack of folded white towels and a bowl of pink Himalayan bath salts with a little wooden scoop. Live: condensation runs down the carafe,
    // the cucumber slices drift in the water, a glint travels along the brass.
    N.surf29d = S => { const BR = '#c9a35a', TV = '#e6d6b8', PX = 26.6, PZ = 17, SL = 8, ST = 30, SH = 3.4, CF = [-14, ST + SH, -8];
      const D = { w: 60, d: 42, topH: ST + SH, topZ: 6, topW: 30, build: () => { const { box, cyl, ball } = K(), o = [], TX = { tex: 'url(#t79t) none', texO: 0.9 };
          [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => { o.push(ball(sx * PX, 0, sz * PZ, 2, '#b08a44', { n: 12, mat: 'metal' })); o.push(rod([sx * PX, 4, sz * PZ], [sx * PX, ST + SH + 1.4, sz * PZ], 0.9, BR, { mat: 'metal' })); });
          [-1, 1].forEach(sz => [SL - 1, ST - 1].forEach(y => o.push(rod([-PX + 1, y, sz * PZ], [PX - 1, y, sz * PZ], 0.6, BR, { mat: 'metal' }))));
          o.push(box(0, SL, 0, 50, SH, 32, TV, Object.assign({ r: 0.6, mat: 'matte' }, TX)), box(0, ST, 0, 50, SH, 32, TV, Object.assign({ r: 0.6, mat: 'matte' }, TX)));
          // towel bar at +x: two arms + bar ends outside the towel; towel over the bar
          [-1, 1].forEach(sz => { o.push(rod([25.6, ST + 1.6, sz * 12], [30.6, ST + 1.6, sz * 12], 0.6, BR, { mat: 'metal' })); o.push(rod([30.6, ST + 1.6, sz * 12], [30.6, ST + 1.6, sz * 9.6], 0.6, BR, { mat: 'metal' })); });
          o.push(box(30.6, ST - 13, 0, 2.6, 16.4, 17, '#f2eee6', { r: 1.1, mat: 'fab', soft: 1 }));
          // top: carafe (glass + water glued), two tumblers
          const G = cyl(CF[0], CF[1], CF[2], 4, 13, '#e8f4f6', { n: 22, rg: [[0, 0, 1], [8, 0, 1], [10.5, 0, 0.6], [13, 0, 0.55]], op: 0.3, mat: 'gloss' }); o.push(G);
          glue(o, G, [cyl(CF[0], CF[1] + 0.4, CF[2], 3.6, 7.4, '#cfe8d8', { n: 20, op: 0.45, noOut: 1, mat: 'gloss' })]);
          [[-4.6, -10], [-4, -2.4]].forEach(([x, z]) => o.push(cyl(x, CF[1], z, 2.2, 5.4, '#eef6f8', { n: 16, rg: [[0, 0, 0.9], [5.4, 0, 1]], op: 0.35, mat: 'gloss' })));
          // lower shelf: folded towel stack (glued), salt bowl
          const T1 = box(-12, SL + SH, 2, 16, 3.2, 12, '#f6f4ee', { r: 1.2, mat: 'fab', soft: 1 }); o.push(T1); glue(o, T1, [box(-12, SL + SH + 3.2, 2, 16, 3.2, 12, '#f2f0ea', { r: 1.2, mat: 'fab', soft: 1 }), box(-12, SL + SH + 6.4, 2, 16, 3.2, 12, '#f8f6f0', { r: 1.2, mat: 'fab', soft: 1 })]);
          const BW = cyl(12, SL + SH, 2, 5.6, 3.8, '#f0ece4', { n: 22, rg: [[0, 0, 0.55], [1.4, 0, 0.85], [3.8, 0, 1]], mat: 'gloss' }); o.push(BW);
          glue(o, BW, [sol({ ax: 'y', sh: 'el', c: [12, 2], a: 5.2, b: 5.2, n: 20, rings: [[SL + SH + 3.6, 0, 1], [SL + SH + 4.6, 0, 0.75], [SL + SH + 5.4, 0, 0.35]], col: '#eaa8a0', mat: 'matte' })]);
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('surf29d'), k = C.k;
        const pores = rep(40, () => `<ellipse cx="${f1(R() * 40)}" cy="${f1(R() * 40)}" rx="${f1(0.3 + R() * 0.6)}" ry="${f1(0.15 + R() * 0.2)}" fill="#b89a6e" opacity="0.55"/>`).join('') + rep(5, i => `<path d="M0 ${f1(4 + i * 8 + R() * 3)}c14 ${f1((R() - 0.5) * 2)} 26 ${f1((R() - 0.5) * 2)} 40 0" stroke="#d2b88e" stroke-width="${f1(0.8 + R())}" fill="none" opacity="0.4"/>`).join('');
        const defs = `<pattern id="t79t" width="40" height="40" patternUnits="userSpaceOnUse">${pores}</pattern>`;
        // water: surface, cucumber + mint drifting, condensation drops on the visible side, tumbler water lines
        const wt = CF[1] + 7.8, tv = C.thV;
        const water = FLy(C, wt, `<circle cx="${CF[0]}" cy="${CF[2]}" r="3.5" fill="#b8e0c8" opacity="0.5"/>` + [[0.6, -0.8, 0], [-1.2, 0.8, 1]].map(([dx, dz, i]) => `<g transform="translate(${f1(CF[0] + dx)} ${f1(CF[2] + dz)})"><g>${at('translate', `0 0;${i ? -0.6 : 0.6} 0.5;0 0`, 6 + i, -i * 2)}<circle r="1.3" fill="#5f9a3a"/><circle r="1.05" fill="#d8eab0"/><circle r="0.35" fill="#b8d088"/></g></g>`).join('')
          + `<path d="M${CF[0] + 1.2} ${CF[2] + 1.6}q1 -1.2 2 0q-1 0.6 -2 0Z" fill="#3f8a3a"/>`);
        const drops = rep(6, i => { const a = tv + (i - 2.5) * 0.35, x = CF[0] + Math.sin(a) * 4.05, z = CF[2] + Math.cos(a) * 4.05, y0 = CF[1] + 2 + (i % 3) * 1.8, p = C.P([x, y0, z]), q = C.P([x, CF[1] + 0.6, z]), T = 6 + i;
          return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.28 * k)}" fill="#ffffff" opacity="0.8">${i % 2 ? an('cy', `${f1(p[1])};${f1(p[1])};${f1(q[1])}`, T, -i * 1.4) + an('opacity', '0.8;0.8;0', T, -i * 1.4) : ''}</circle>`; }).join('');
        const tw = [[-4.6, -10], [-4, -2.4]].map(([x, z]) => FLy(C, CF[1] + 3.4, `<circle cx="${x}" cy="${z}" r="2.05" fill="#d4ecf0" opacity="0.5"/>`)).join('');
        // salts: pink heap in the bowl + a scoop
        const salts = FLy(C, SL + SH + 3.6, `<circle cx="12" cy="2" r="5.1" fill="#e8a8a0"/>` + rep(26, () => `<circle cx="${f1(12 + (R() - 0.5) * 8)}" cy="${f1(2 + (R() - 0.5) * 8)}" r="${f1(0.3 + R() * 0.4)}" fill="${R() < 0.5 ? '#f6c8c0' : '#d88a84'}"/>`).join('').replace(/cx="([\d.-]+)" cy="([\d.-]+)"/g, (m, x, y) => Math.hypot(x - 12, y - 2) < 4.6 ? m : 'cx="12" cy="2"'));
        const scoop = (() => { const a = C.P([13, SL + SH + 4, 3]), b = C.P([18, SL + SH + 5.6, 5.4]); return `<path d="M${P2(a)}L${P2(b)}" stroke="#a8784a" stroke-width="${f1(0.7 * k)}" stroke-linecap="round"/><ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="${f1(1.3 * k)}" ry="${f1(0.8 * k)}" fill="#c8945a"/>`; })();
        // towel: waffle grid + hem on the visible face
        const tf = vdot(C, [1, 0, 0]) > 0.1 ? PLN(C, [31.92, ST - 0.4, -9], [0, 0, 1], [0, -1, 0], rep(9, i => `<path d="M${1 + i * 2} 1V14M1 ${f1(1.6 + i * 1.5)}H17" stroke="#dcd6ca" stroke-width="0.3"/>`).join('') + `<rect x="0" y="12.6" width="18" height="1.4" fill="#d8ceb8"/>`) : '';
        // shelf edges: brass-toned honed edge highlight on the facing long side; glint along the front rail
        const fz = vdot(C, [0, 0, 1]) > 0.1, glint = fz ? (() => { const a = C.P([-PX, ST - 1, PZ + 0.7]), b = C.P([PX, ST - 1, PZ + 0.7]); return `<ellipse cx="${f1(a[0])}" cy="${f1(a[1])}" rx="${f1(2.4 * k)}" ry="${f1(0.4 * k)}" fill="#fff6d8" opacity="0">${an('cx', `${f1(a[0])};${f1(b[0])}`, 6)}${an('cy', `${f1(a[1])};${f1(b[1])}`, 6)}${an('opacity', '0;0.9;0.9;0', 6)}</ellipse>`; })() : '';
        return { defs, under: shadow(C, 0, 0, 32, 22, 0.35), front: water + tw + drops + tf + glint, bb: C.bb(4) }; };
      return D; };

    // BTH-099 LEVITATING WATERPROOF HOLO-BOOK & BEVERAGE TRAY (T5): a honey-onyx puck on the floor glowing warm from inside, ringed in gold, holds a
    // polished walnut tray with a gold gallery rail in the air; on the tray a crystal flute of champagne, a gold-rimmed dish of strawberries, water beading
    // on the lacquer, and a slim gold emitter bar projecting an open book of warm amber light. Live: the tray bobs, the book's pages turn, bubbles stream
    // up the champagne, the light under the tray breathes.
    N.surf29e = S => { const TY = 26, TT = TY + 1.6, FL0 = [14, TT, -5], DS = [15, TT, 7], EM = [-9, TT, 1], GD = '#d8b25a', BOB = () => at('translate', '0 0;0 -3;0 0', 5.2);
      const D = { w: 52, d: 40, build: () => { const { cyl } = K(); return [cyl(0, 0, 0, 12, 3, '#e8c48a', { n: 30, rg: [[0, 0, 1], [2.4, 0, 1], [3, 0, 0.94]], mat: 'gloss' }), cyl(0, 3, 0, 9, 0.4, '#fff0c8', { n: 28, noOut: 1, mat: 'gloss', emit: 1 })]; },
        layers: [{ build: () => { const { box, cyl, ball } = K(), o = [];
            const T0 = box(0, TY, 0, 46, 1.6, 30, '#6a3e22', { r: 0.8, mat: 'gloss' }); o.push(T0);
            const FT = sol({ ax: 'y', sh: 'el', c: [FL0[0], FL0[2]], a: 2.6, b: 2.6, n: 18, rings: [[TT, 0, 1], [TT + 0.5, 0, 0.9], [TT + 0.7, 0, 0.3]], col: '#eef6f8', op: 0.45, mat: 'gloss' }); o.push(FT);
            glue(o, FT, [rod([FL0[0], TT + 0.6, FL0[2]], [FL0[0], TT + 6.4, FL0[2]], 0.32, '#f4fafc', { mat: 'gloss' }), sol({ ax: 'y', sh: 'el', c: [FL0[0], FL0[2]], a: 2.2, b: 2.2, n: 18, rings: [[TT + 6.4, 0, 0.2], [TT + 7.6, 0, 0.75], [TT + 9, 0, 0.92], [TT + 14, 0, 1]], col: '#eef6f8', op: 0.32, mat: 'gloss' })]);
            const DSh = cyl(DS[0], TT, DS[2], 4.6, 1.6, '#f6f2ea', { n: 22, rg: [[0, 0, 0.7], [1.6, 0, 1]], mat: 'gloss' }); o.push(DSh);
            glue(o, DSh, [[0, 0], [1.8, 1.2], [-1.6, 1.4], [0.8, -1.8], [-1.4, -1.2]].map(([x, z], i) => ball(DS[0] + x, TT + 1.2, DS[2] + z, 1.4, i % 2 ? '#d8283a' : '#e23a40', { sy: 1.15, n: 10, mat: 'gloss' })));
            o.push(box(EM[0], TT, EM[2], 16, 0.8, 2.4, GD, { r: 0.4, mat: 'metal' }));
            return o; }, wrap: (p, s) => `<g>${BOB()}${s}</g>` }] };
      D.fx = ctx => { const C = cam(ctx), R = rng('surf29e'), k = C.k, tv = C.thV;
        // under: floor glow; back: the soft light column up to the tray (the tray covers its top)
        const g1 = C.u('g99'), g2 = C.u('c99'), b0 = C.P([0, 3.4, 0]), b1 = C.P([0, TY, 0]);
        const under = `<defs><radialGradient id="${g1}"><stop offset="0" stop-color="#ffd890" stop-opacity="0.5"/><stop offset="1" stop-color="#ffd890" stop-opacity="0"/></radialGradient><linearGradient id="${g2}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#ffe0a0" stop-opacity="0.45"/><stop offset="1" stop-color="#ffe0a0" stop-opacity="0.04"/></linearGradient></defs>`
          + FLy(C, 0.04, `<ellipse rx="24" ry="20" fill="url(#${g1})">${an('opacity', '0.6;1;0.6', 5.2)}</ellipse>`) + shadow(C, 0, 0, 13, 13, 0.25);
        const beam = `<path d="M${f1(b0[0] - 9 * k)} ${f1(b0[1])}L${f1(b1[0] - 14 * k)} ${f1(b1[1])}H${f1(b1[0] + 14 * k)}L${f1(b0[0] + 9 * k)} ${f1(b0[1])}Z" fill="url(#${g2})">${an('opacity', '0.55;1;0.55', 5.2)}</path>`;
        const ring = FLy(C, 3.02, `<circle r="11.6" fill="none" stroke="${GD}" stroke-width="0.7"/><circle r="8.6" fill="none" stroke="#fff6d8" stroke-width="0.3" opacity="0.8"/>`) + rep(10, i => { const a = tv + (i - 4.5) * 0.24; if (Math.abs(i - 4.5) > 4) return ''; const p = C.P([Math.sin(a) * 12.05, 0.4, Math.cos(a) * 12.05]), q = C.P([Math.sin(a) * 12.05, 2.6, Math.cos(a) * 12.05]); return `<path d="M${P2(p)}L${P2(q)}" stroke="#c89a4a" stroke-width="${f1(0.25 * k)}" opacity="0.5"/>`; }).join('');
        // tray decals (all bob): gold gallery rail, burl figure, beads, champagne, strawberry seeds, the holo-book
        const rail = FLy(C, TT + 0.02, `<rect x="-22.6" y="-14.6" width="45.2" height="29.2" rx="1" fill="none" stroke="${GD}" stroke-width="0.6"/>` + rep(6, i => `<ellipse cx="${f1(-18 + i * 6 + R() * 2)}" cy="${f1(10 + R() * 3)}" rx="${f1(2 + R() * 2)}" ry="${f1(0.7 + R() * 0.6)}" fill="none" stroke="#8a5a32" stroke-width="0.3" opacity="0.7"/>`).join('')
          + [[-20, -11], [-3, 11.5], [4, -12], [-16, 9], [21, 12.6], [8, 12]].map(([x, z]) => `<ellipse cx="${x}" cy="${z}" rx="0.7" ry="0.55" fill="#a8d0e0" opacity="0.6"/><ellipse cx="${x - 0.2}" cy="${z - 0.2}" rx="0.25" ry="0.18" fill="#ffffff"/>`).join(''));
        const railS = vdot(C, [0, 0, 1]) > 0.05 ? PLN(C, [-23, TT + 1.6, 15.02], [1, 0, 0], [0, -1, 0], `<path d="M0 0H46" stroke="${GD}" stroke-width="0.6"/>` + rep(12, i => `<path d="M${f1(0.6 + i * 4.07)} 0V1.6" stroke="${GD}" stroke-width="0.35"/>`).join('')) : '';
        const ch = FLy(C, TT + 12.4, `<circle cx="${FL0[0]}" cy="${FL0[2]}" r="2.1" fill="#f2d888" opacity="0.8"/>`) + (() => { const a = C.P([FL0[0], TT + 7.8, FL0[2]]), b = C.P([FL0[0], TT + 12.4, FL0[2]]); return `<path d="M${f1(a[0] - 1.5 * k)} ${f1(a[1])}L${f1(b[0] - 2.1 * k)} ${f1(b[1])}H${f1(b[0] + 2.1 * k)}L${f1(a[0] + 1.5 * k)} ${f1(a[1])}Z" fill="#f2d070" opacity="0.55"/>`; })() + bubbles(C, FL0[0], FL0[2], TT + 7.4, TT + 12.2, 2.4, 9, 2.4);
        const fN = (FL0[0] - DS[0]) * C.v[0] + (FL0[2] - DS[2]) * C.v[2] > 2, seeds = fN ? '' : rep(14, () => { const p = C.P([DS[0] + (R() - 0.5) * 6, TT + 3.2 + R() * 0.6, DS[2] + (R() - 0.2) * 5]); return `<circle cx="${f1(p[0])}" cy="${f1(p[1])}" r="${f1(0.14 * k)}" fill="#ffe08a"/>`; }).join('') + FLy(C, TT + 1.62, `<circle cx="${DS[0]}" cy="${DS[2]}" r="4.5" fill="none" stroke="${GD}" stroke-width="0.4"/>`);
        // holo-book: an open book of warm light tilted toward the front, hovering over the emitter, one page sweeping across
        const bf = vdot(C, nrm([0, 1, 1])) > 0, U = [1, 0, 0], V = nrm([0, -1, 0.9]), O = [EM[0] - 10, TT + 15, EM[2] - 6];
        const page = (x0, w, op) => `<path d="M${x0} 0.5Q${x0 + w / 2} ${w > 0 ? -0.6 : -0.6} ${x0 + w} 0.4V12.4Q${x0 + w / 2} 11.4 ${x0} 12.6Z" fill="#ffd68a" opacity="${op}" stroke="#ffe8b8" stroke-width="0.25"/>`;
        const lines = rep(8, i => `<path d="M1.4 ${f1(2 + i * 1.25)}H${f1(8.4 - (i === 3 ? 2 : 0))}M11.4 ${f1(2 + i * 1.25)}H${f1(18.4 - (i === 6 ? 3 : 0))}" stroke="#fff4d8" stroke-width="0.3" opacity="0.8"/>`).join('');
        const holo = PLN(C, O, U, V, `<g opacity="0.85">${an('opacity', '0.75;0.92;0.8;0.75', 3.4)}` + page(0, 10, 0.32) + page(10, 10, 0.32) + lines + `<path d="M10 0V12.6" stroke="#fff0c8" stroke-width="0.35"/>`
          + `<g transform="translate(10 0)"><g>${at('scale', '1 1;1 1;-1 1;-1 1', 4.8, 0, ' keyTimes="0;0.55;0.8;1" calcMode="spline" keySplines="0 0 1 1;0.45 0 0.55 1;0 0 1 1"')}<path d="M0 0.5Q5 -0.6 10 0.4V12.4Q5 11.4 0 12.6Z" fill="#ffe2a0" opacity="0.4" stroke="#fff0c8" stroke-width="0.25"/></g></g></g>`);
        const rays = (() => { const e0 = C.P([EM[0] - 7, TT + 0.8, EM[2]]), e1 = C.P([EM[0] + 7, TT + 0.8, EM[2]]), t0 = C.P(O), t1 = C.P([O[0] + 20, O[1], O[2]]), t2 = C.P([O[0] + 20, O[1] + V[1] * 12.6, O[2] + V[2] * 12.6]), t3 = C.P([O[0], O[1] + V[1] * 12.6, O[2] + V[2] * 12.6]);
          return `<path d="M${P2(e0)}L${P2(t3)}L${P2(t2)}L${P2(e1)}Z" fill="#ffd890" opacity="0.12"/><path d="M${P2(e0)}L${P2(t0)}M${P2(e1)}L${P2(t1)}" stroke="#ffe0a0" stroke-width="${f1(0.25 * k)}" opacity="0.35"/>`; })();
        const motes = rep(6, i => { const q = C.P([EM[0] - 8 + R() * 16, TT + 4 + R() * 12, EM[2] - 4 + R() * 6]), T = 4 + R() * 3; return `<circle cx="${f1(q[0])}" cy="${f1(q[1])}" r="${f1(0.3 * k)}" fill="#fff0c0" opacity="0">${an('opacity', '0;0.9;0', T, -i)}${an('cy', `${f1(q[1])};${f1(q[1] - 4 * k)}`, T, -i)}</circle>`; }).join('');
        const top = `<g>${BOB()}${rail + railS + ch + seeds + rays + (bf ? holo : '') + motes}</g>`;
        return { under, back: beam, front: ring + top, bb: (() => { C.P([O[0], O[1] + 4, O[2]]); C.P([O[0] + 20, O[1] + 4, O[2]]); return C.bb(6); })() }; };
      return D; };
  }

  // ---- clothes care batch 1: 020 (50 x 50) / 040 (50 x 50) / 060 (104 x 46, host top)
  { const K = () => X.K, sol = o => X.K.solid(o);
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`, FLy = (C, y, svg) => PLN(C, [0, y, 0], [1, 0, 0], [0, 0, 1], svg);
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const facing = (C, a) => vdot(C, [Math.sin(a), 0, Math.cos(a)]);
    const cylL = (C, x0, z0, rF, a0, a1, y, n) => { let d = ''; for (let i = 0; i <= n; i++) { const a = a0 + (a1 - a0) * i / n, r = typeof rF === 'function' ? rF(y) : rF; d += (i ? 'L' : 'M') + P2(C.P([x0 + Math.sin(a) * r, y, z0 + Math.cos(a) * r])); } return d; };
    // a cloth strip hanging over a round rim at angle a: from inside the rim, over it and down the outside; w wide (angle), drop long
    const drape = (C, rF, a, w, yR, drop, col, stripe) => { const pt = (aa, y, dr) => { const r = rF(y) + dr; return C.P([Math.sin(aa) * r, y, Math.cos(aa) * r]); };
      const L = [pt(a - w, yR - 2, -1.2), pt(a - w, yR + 0.8, 0.2), pt(a - w * 0.9, yR - drop * 0.5, 0.6), pt(a - w * 0.7, yR - drop, 0.7)], Rr = [pt(a + w, yR - 2, -1.2), pt(a + w, yR + 0.8, 0.2), pt(a + w * 0.9, yR - drop * 0.6, 0.6), pt(a + w * 0.6, yR - drop * 0.9, 0.7)];
      let s = `<path d="M${P2(L[0])}L${P2(L[1])}Q${P2(L[2])} ${P2(L[3])}L${P2(Rr[3])}Q${P2(Rr[2])} ${P2(Rr[1])}L${P2(Rr[0])}Z" fill="${col}" stroke="${X.K.shade(col, 0.6)}" stroke-width="0.3"/>`;
      if (stripe) s += [0.35, 0.65].map(f => { const a2 = pt(a - w + 2 * w * f, yR + 0.6, 0.25), b2 = pt(a - w * 0.8 + 1.5 * w * f, yR - drop * 0.8, 0.75); return `<path d="M${P2(a2)}L${P2(b2)}" stroke="${stripe}" stroke-width="${f1(0.7 * C.k)}"/>`; }).join('');
      return s; };

    // BTH-020 PLASTIC MESH POP-UP LAUNDRY HAMPER (T1): a dingy white pop-up mesh hamper on a spring-wire frame, sides sagging in and grubby toward the base,
    // a frayed grey binding round the rim, cloth carry loops, and laundry heaped over the top: jeans, a pink tee, a grey towel, a black sock; a striped sleeve
    // and a sock hang over the edge and a lost sock lies on the floor. Live: the hanging sock sways and a lint fluff drifts.
    N.cloth29a = S => { const H0 = 40, RB = 17.5, rF = y => RB * (y < 3 ? 0.97 + 0.01 * y : y < 22 ? 1 - 0.1 * (y - 3) / 19 : 0.9 + 0.1 * (y - 22) / 18);
      const D = { w: 50, d: 50, round: 1, build: () => { const { cyl, ball } = K(), o = [];
          const B0 = cyl(0, 0, 0, RB, H0, '#dcddd8', { n: 30, rg: [[0, 0, 0.97], [3, 0, 1], [12, 0, 0.95], [22, 0, 0.9], [32, 0, 0.95], [H0 - 1, 0, 1], [H0, 0, 1]], mat: 'fab', tex: 'url(#m20) none', texO: 0.9 }); o.push(B0);
          glue(o, B0, [cyl(0, H0 - 1.6, 0, RB + 0.3, 1.8, '#8a8c88', { n: 30, mat: 'fab' })]);
          glue(o, B0, [[-6, 3, '#4f6a98', 9.4, 0.5], [5, -4, '#e88a96', 8.6, 0.48], [3, 7, '#9a9c98', 7.6, 0.55], [-8, -6, '#f0ece2', 7.4, 0.45], [9, 4, '#2c2c30', 3, 0.6]].map(([x, z, col, r, sy]) => ball(x, H0 - r * sy * 0.7, z, r, col, { sy, k: 3, n: 14, mat: 'fab', soft: 1 })));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('cloth29a'), k = C.k, tv = C.thV;
        const mesh = `<pattern id="m20" width="2.6" height="2.6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="2.6" height="2.6" fill="#ffffff" opacity="0.25"/><path d="M0 0H2.6M0 0V2.6" stroke="#7a7c78" stroke-width="0.35" opacity="0.6"/></pattern>`;
        // grime toward the base, wire ring lines, a split in the mesh, binding fray, carry loops at +-x
        let s = `<path d="${cylL(C, 0, 0, rF, tv - 1.45, tv + 1.45, 3, 18)}L${P2(C.P([Math.sin(tv + 1.45) * rF(0), 0.2, Math.cos(tv + 1.45) * rF(0)]))}${cylL(C, 0, 0, rF, tv + 1.45, tv - 1.45, 0.2, 18).replace('M', 'L')}Z" fill="#9a9070" opacity="0.28"/>`;
        s += [0.5, H0 - 1.8].map(y => `<path d="${cylL(C, 0, 0, y => rF(y) + 0.1, tv - 1.5, tv + 1.5, y, 20)}" stroke="#5a5c58" stroke-width="${f1(0.45 * k)}" fill="none"/>`).join('');
        { const a = tv + 0.5, p0 = C.P([Math.sin(a) * (rF(14) + 0.1), 16, Math.cos(a) * (rF(14) + 0.1)]), p1 = C.P([Math.sin(a + 0.08) * (rF(10) + 0.1), 10.5, Math.cos(a + 0.08) * (rF(10) + 0.1)]); s += `<path d="M${P2(p0)}Q${f1((p0[0] + p1[0]) / 2 + 1.4 * k)} ${f1((p0[1] + p1[1]) / 2)} ${P2(p1)}Q${f1((p0[0] + p1[0]) / 2 - 0.6 * k)} ${f1((p0[1] + p1[1]) / 2)} ${P2(p0)}Z" fill="#3a3c38" opacity="0.65"/>`; }
        [-PI / 2, PI / 2].forEach(a => { if (facing(C, a) < -0.2) return; const p = C.P([Math.sin(a) * (RB + 0.4), H0 - 1, Math.cos(a) * (RB + 0.4)]), q = C.P([Math.sin(a) * (RB + 0.6), H0 - 6, Math.cos(a) * (RB + 0.6)]); s += `<path d="M${f1(p[0] - 2 * k)} ${f1(p[1])}Q${f1(q[0] - 2.4 * k)} ${f1(q[1] + 2 * k)} ${f1(q[0])} ${f1(q[1] + 1.4 * k)}Q${f1(q[0] + 2.4 * k)} ${f1(q[1] + 2 * k)} ${f1(p[0] + 2 * k)} ${f1(p[1])}" stroke="#8a8c88" stroke-width="${f1(0.9 * k)}" fill="none"/>`; });
        rep(5, i => { const a = tv + (R() - 0.5) * 2.4, p = C.P([Math.sin(a) * (RB + 0.35), H0 - 1.6, Math.cos(a) * (RB + 0.35)]); s += `<path d="M${P2(p)}l${f1((R() - 0.5) * 0.8 * k)} ${f1(1.2 * k)}" stroke="#6a6c68" stroke-width="${f1(0.2 * k)}"/>`; });
        s += [[-6, 3, '#3a527a', 9.4, 0.5], [5, -4, '#c86a78', 8.6, 0.48], [3, 7, '#7a7c78', 7.6, 0.55], [-8, -6, '#c8c4b8', 7.4, 0.45]].map(([x, z, col, r, sy]) => { const c = C.P([x, H0 + r * sy * 1.3, z]); return rep(3, j => { const dx = (R() - 0.5) * r * 0.9 * k, dy = (R() - 0.5) * r * 0.4 * k, l = (1.6 + R() * 2) * k; return `<path d="M${f1(c[0] + dx - l)} ${f1(c[1] + dy)}q${f1(l)} ${f1(-l * 0.6)} ${f1(l * 2)} ${f1(0.2 * l)}" stroke="${col}" stroke-width="${f1(0.35 * k)}" fill="none" opacity="0.8"/>`; }).join(''); }).join('')
          + (() => { const c = C.P([-4, H0 + 4.6, 3]); return `<path d="M${f1(c[0] - 1.6 * k)} ${f1(c[1])}h${f1(1.2 * k)}v${f1(2.4 * k)}" stroke="#d8c86a" stroke-width="${f1(0.3 * k)}" fill="none"/>`; })();
        // hanging laundry (each only when its side faces the viewer)
        const aS = 0.6, aK = -0.9; let hang = '';
        if (facing(C, aS) > 0.05) hang += drape(C, rF, aS, 0.2, H0, 15, '#f2f0ea', '#4a6ab0');
        if (facing(C, aK) > 0.05) { const P0 = C.P([Math.sin(aK) * (RB + 0.6), H0 + 0.6, Math.cos(aK) * (RB + 0.6)]); hang += `<g>${at('rotate', `-4 ${P2(P0)};5 ${P2(P0)};-4 ${P2(P0)}`, 3.6)}${drape(C, rF, aK, 0.09, H0, 12, '#2c2c30')}<path d="M${P2(C.P([Math.sin(aK) * (RB + 0.9), H0 - 11.6, Math.cos(aK) * (RB + 0.9)]))}l${f1(-2.4 * k)} ${f1(0.4 * k)}" stroke="#2c2c30" stroke-width="${f1(2.2 * k)}" stroke-linecap="round"/></g>`; }
        const sock = FLy(C, 0.05, `<path d="M22 12q-4 1 -6 -1.4l-1.2 -2.6q2.4 -1.6 3.4 0.6l1 1.2q1.6 0.6 3 1.2Z" fill="#f2f0ea" stroke="#b8b4aa" stroke-width="0.2"/><path d="M17 8.6q1.2 -0.8 2.2 0.2" stroke="#d84a5a" stroke-width="0.5" fill="none"/>`);
        const lint = (() => { const q = C.P([-12, 30, 14]); return `<g opacity="0.7"><g>${at('translate', `0 0;${f1(5 * k)} ${f1(-6 * k)};${f1(-2 * k)} ${f1(-12 * k)}`, 9)}${rep(6, () => `<path d="M${P2(q)}l${f1((R() - 0.5) * 2 * k)} ${f1((R() - 0.5) * 2 * k)}" stroke="#c8c4bc" stroke-width="0.25"/>`).join('')}</g>${an('opacity', '0;0.8;0', 9)}</g>`; })();
        return { defs: mesh, under: shadow(C, 0, 0, 20, 20, 0.35) + sock, front: s + hang + lint, bb: C.bb(5) }; };
      return D; };

    // BTH-040 WOVEN SEAGRASS LID HAMPER (T2): a tapered round hamper hand-coiled from natural seagrass (row on row of twisted coils with darker stitches),
    // a braided rim, a domed lid with a loop handle sitting a little ajar on a white cotton liner that folds out over the rim, twisted rope side handles,
    // and a striped sleeve escaping from under the lid. Live: the escaped sleeve sways a little and a lavender sachet tag swings on the handle.
    N.cloth29b = S => { const H0 = 36, rF = y => 16.4 + 2.2 * y / H0, GR = '#c8b07a';
      const D = { w: 50, d: 50, round: 1, build: () => { const { cyl } = K(), o = [];
          o.push(cyl(0, 0, 0, 16.4, H0, GR, { n: 30, rg: [[0, 0, 0.97], [1, 0, 1], [H0, 0, 18.6 / 16.4]], mat: 'matte' }));
          o.push(cyl(0, H0 + 0.05, 0, 19.2, 1.4, '#f2eee4', { n: 30, mat: 'fab', soft: 1 }));
          const L0 = cyl(1, H0 + 1.5, 1.2, 19.4, 4.4, shade(GR, 1.05), { n: 30, rg: [[0, 0, 1], [1.4, 0, 1], [2.6, 0, 0.86], [4.4, 0, 0.5]], mat: 'matte' }); o.push(L0);
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('cloth29b'), k = C.k, tv = C.thV;
        let s = '';
        // coils: a twisted row every 1.8 units with stitch ticks
        for (let y = 1.2, j = 0; y < H0 - 0.4; y += 1.8, j++) { s += `<path d="${cylL(C, 0, 0, y => rF(y) + 0.05, tv - 1.5, tv + 1.5, y, 24)}" stroke="${j % 2 ? '#9a8048' : '#a88c52'}" stroke-width="${f1(0.4 * k)}" fill="none" opacity="0.75"/>`;
          rep(16, i => { const a = tv - 1.4 + i * 0.187 + (j % 2) * 0.09, y2 = y + 0.9, p = C.P([Math.sin(a) * (rF(y2) + 0.06), y2 + 0.6, Math.cos(a) * (rF(y2) + 0.06)]), q = C.P([Math.sin(a + 0.04) * (rF(y2) + 0.06), y2 - 0.5, Math.cos(a + 0.04) * (rF(y2) + 0.06)]); if (facing(C, a) > 0.2) s += `<path d="M${P2(p)}L${P2(q)}" stroke="#e2cc94" stroke-width="${f1(0.3 * k)}" opacity="0.8"/>`; }); }
        // braided rim + lid coils + lid loop, liner fold, rope handles
        s += `<path d="${cylL(C, 0, 0, () => 18.75, tv - 1.55, tv + 1.55, H0 - 0.3, 26)}" stroke="#8a7040" stroke-width="${f1(1.3 * k)}" fill="none" stroke-dasharray="${f1(1 * k)} ${f1(0.5 * k)}"/>`;
        [0.6, 1.8, 3].forEach(dy => s += `<path d="${cylL(C, 1, 1.2, () => 19.4 * (dy < 1.4 ? 1 : dy < 2.6 ? 0.92 : 0.78) + 0.05, tv - 1.5, tv + 1.5, H0 + 1.5 + dy, 24)}" stroke="#a88c52" stroke-width="${f1(0.4 * k)}" fill="none" opacity="0.7"/>`);
        const lt = C.P([1, H0 + 5.9, 1.2]), lp = `<path d="M${f1(lt[0] - 2.4 * k)} ${f1(lt[1])}q${f1(2.4 * k)} ${f1(-4.4 * k)} ${f1(4.8 * k)} 0" stroke="#8a7040" stroke-width="${f1(1.1 * k)}" fill="none" stroke-linecap="round"/>`;
        s += FLy(C, H0 + 5.92, `<circle cx="1" cy="1.2" r="9" fill="none" stroke="#a88c52" stroke-width="0.4" opacity="0.7"/><circle cx="1" cy="1.2" r="5" fill="none" stroke="#a88c52" stroke-width="0.4" opacity="0.7"/>`);
        { const a0 = tv - 0.5, a1 = tv + 0.9; s += `<path d="${cylL(C, 0, 0, () => 19.25, a0, a1, H0 + 1.45, 10)}${cylL(C, 0, 0, () => 19.3, a1, a0, H0 - 2.6, 10).replace('M', 'L')}Z" fill="#f4f0e6" stroke="#d8d2c4" stroke-width="0.25"/>`; }
        [-PI / 2, PI / 2].forEach(a => { if (facing(C, a) < -0.25) return; const p = C.P([Math.sin(a) * 18.4, H0 - 4, Math.cos(a) * 18.4]); s += `<path d="M${f1(p[0] - 3 * k)} ${f1(p[1])}q${f1(3 * k)} ${f1(4 * k)} ${f1(6 * k)} 0" stroke="#d8c8a0" stroke-width="${f1(1.2 * k)}" fill="none"/><path d="M${f1(p[0] - 3 * k)} ${f1(p[1])}q${f1(3 * k)} ${f1(4 * k)} ${f1(6 * k)} 0" stroke="#a8946a" stroke-width="${f1(0.4 * k)}" fill="none" stroke-dasharray="${f1(0.6 * k)} ${f1(0.6 * k)}"/>`; });
        // escaped sleeve (fixed side) + lavender sachet tag on the lid loop
        const aS = 0.35; let sl = ''; if (facing(C, aS) > 0.05) { const P0 = C.P([Math.sin(aS) * 19.4, H0 + 1, Math.cos(aS) * 19.4]); sl = `<g>${at('rotate', `-3 ${P2(P0)};3 ${P2(P0)};-3 ${P2(P0)}`, 4.4)}${drape(C, y => y > H0 ? 19.2 : rF(y), aS, 0.13, H0 + 1.3, 13, '#e8e4dc', '#d85a4a')}</g>`; }
        const tag = (() => { const p = C.P([3.4, H0 + 7, 1.2]); return `<g><g>${at('rotate', `-8 ${P2(p)};8 ${P2(p)};-8 ${P2(p)}`, 2.8)}<path d="M${P2(p)}l0 ${f1(3.4 * k)}" stroke="#7a6a9a" stroke-width="0.3"/><ellipse cx="${f1(p[0])}" cy="${f1(p[1] + 4.6 * k)}" rx="${f1(1.5 * k)}" ry="${f1(1.9 * k)}" fill="#b8a4d8" stroke="#8a74b0" stroke-width="0.25"/><path d="M${f1(p[0] - 0.8 * k)} ${f1(p[1] + 3.2 * k)}h${f1(1.6 * k)}" stroke="#6a5a8a" stroke-width="0.3"/></g></g>`; })();
        return { under: shadow(C, 0, 0, 20, 20, 0.35), front: s + lp + tag + sl, bb: C.bb(6) }; };
      return D; };

    // BTH-060 DUAL-COMPARTMENT BAMBOO TILT-OUT LAUNDRY CABINET (T3): a caramelised strand-bamboo cabinet on short tapered legs with two tilt-out laundry
    // bins - the left one tipped open on its hinge showing a grey linen bag of whites heaped inside, the right one shut with a cut-out finger pull - each
    // with a small brass label holder (WHITES / COLOURS); a matte top with a jar of laundry pods. Live: a warm light line glides along the bamboo.
    N.cloth29c = S => { const BB = '#c8955a', TOP = 42, FZ = 22, DT = 14 * PI / 180, DH = 32, HY = 6;
      const D = { w: 104, d: 46, topH: TOP, topZ: 2, topW: 60, build: () => { const { box, cyl } = K(), o = [], TX = { tex: 'url(#b60) none', texO: 0.8 };
          [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => o.push(box(sx * 46, 0, sz * 18, 3, 4, 3, shade(BB, 0.78), { r: 0.6, mat: 'wood' })));
          o.push(box(0, TOP - 2, 0, 100, 2, 44, BB, Object.assign({ r: 0.6, mat: 'wood' }, TX)), box(23.5, 4, 0, 53, TOP - 6, 44, BB, Object.assign({ r: 0.6, mat: 'wood' }, TX)), box(-25, 4, -2.5, 43.6, TOP - 6, 39, '#4a3220', { r: 0, mat: 'matte' }), box(-48.5, 4, 0, 3, TOP - 6, 44, BB, Object.assign({ r: 0.6, mat: 'wood' }, TX)));
          const zt = FZ + 0.4 + DH * Math.sin(DT), yt = HY + DH * Math.cos(DT);
          const Dr = sol(Object.assign({ ax: 'x', sh: 'poly', c: [0, 0], pts: [[FZ + 0.4, HY], [FZ + 2, HY], [zt + 1.6, yt], [zt, yt]], rings: [[-47, 0, 1], [-3, 0, 1]], col: BB, mat: 'wood' }, TX)); o.push(Dr);
          glue(o, Dr, [-46.4, -3.6].map(x => sol({ ax: 'x', sh: 'poly', c: [0, 0], pts: [[FZ + 0.4, HY + 1], [zt - 0.2, yt - 0.6], [FZ + 0.4, yt - 0.6]], rings: [[x - 0.5, 0, 1], [x + 0.5, 0, 1]], col: shade(BB, 0.9), mat: 'wood' })));
          const J = cyl(38, TOP, -12, 4, 8, '#eef4f6', { n: 20, rg: [[0, 0, 1], [6.4, 0, 1], [7, 0, 0.8], [8, 0, 0.8]], op: 0.4, mat: 'gloss' }); o.push(J);
          glue(o, J, [cyl(38, TOP + 6.6, -12, 3.4, 1.8, '#c8955a', { n: 18, mat: 'wood' })]);
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('cloth60'), k = C.k, fr = vdot(C, [0, 0, 1]) > 0.05, zt = FZ + 0.4 + DH * Math.sin(DT), yt = HY + DH * Math.cos(DT);
        const st = rep(26, i => `<path d="M${f1(i * 1.6 + R() * 0.6)} 0V40" stroke="${R() < 0.5 ? '#9a6a3a' : '#e0b07a'}" stroke-width="${f1(0.2 + R() * 0.3)}" opacity="0.45"/>`).join('') + rep(4, () => `<ellipse cx="${f1(R() * 40)}" cy="${f1(R() * 40)}" rx="0.25" ry="2" fill="#7a4a22" opacity="0.4"/>`).join('');
        const defs = `<pattern id="b60" width="40" height="40" patternUnits="userSpaceOnUse">${st}</pattern>`;
        let s = '';
        if (fr) { // the dark opening behind the tipped bin, the bin's laundry heap (clipped above the door's top edge), the closed bin's finger pull, labels
          const cid = C.u('c60'), hull = [[-46, yt, 17.2], [-4, yt, 17.2], [-4, yt, zt], [-46, yt, zt], [-46, yt + 7, 17.2], [-4, yt + 7, 17.2], [-4, yt + 7, zt], [-46, yt + 7, zt]].map(p => C.P(p));
          const cx = hull.reduce((a, q) => a + q[0], 0) / 8, cy = hull.reduce((a, q) => a + q[1], 0) / 8, hp = hull.slice().sort((p, q) => Math.atan2(p[1] - cy, p[0] - cx) - Math.atan2(q[1] - cy, q[0] - cx));
          const blobs = [[-40, '#e8e6e0', 4.4], [-33, '#f4f2ec', 5], [-25, '#d8dee8', 4.6], [-17, '#f0eee8', 5.2], [-10, '#e4e8ee', 4.4]].map(([x, col, r], i) => { const q = C.P([x, yt - 0.4 + (i % 2) * 0.8, (17.2 + zt) / 2]); return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(r * k)}" ry="${f1(r * 0.75 * k)}" fill="${col}" stroke="#b8b8b0" stroke-width="0.25"/>`; }).join('');
          const bag = (() => { const a = C.P([-46, yt - 0.4, 17.6]), b = C.P([-4, yt - 0.4, 17.6]), c = C.P([-4, yt + 1, zt - 1]), d = C.P([-46, yt + 1, zt - 1]); return `<path d="M${P2(a)}L${P2(b)}L${P2(c)}L${P2(d)}Z" fill="#8a8a84"/>`; })();
          s += `<defs><clipPath id="${cid}"><path d="M${hp.map(P2).join('L')}Z"/></clipPath></defs><g clip-path="url(#${cid})">${bag}${blobs}</g>`;
          s += PLN(C, [3, TOP - 6, FZ + 0.03], [1, 0, 0], [0, -1, 0], `<path d="M14 0.4H30Q31 4 22 4Q13 4 14 0.4Z" fill="#3a2414"/><rect x="18.6" y="7" width="7" height="3.4" rx="0.5" fill="#d8b25a"/><rect x="19.2" y="7.5" width="5.8" height="2.4" fill="#f6f0e2"/><text x="22.1" y="9.4" font-family="Arial,sans-serif" font-size="1.7" font-weight="700" fill="#5a4a3a" text-anchor="middle">COLOURS</text>`);
          s += PLN(C, [-3, TOP - 2, FZ + 0.03], [1, 0, 0], [0, -1, 0], `<rect x="1.4" y="1" width="50" height="${TOP - 7.6}" rx="0.6" fill="none" stroke="#6a4422" stroke-width="0.45"/>`);
          const DV = [0, Math.cos(DT), Math.sin(DT)], O = [-33.6, HY + DH * 0.62 * Math.cos(DT), FZ + 2.05 + DH * 0.62 * Math.sin(DT)];
          s += PLN(C, O, [1, 0, 0], [0, -DV[1], -DV[2]], `<rect x="4.6" y="0" width="7" height="3.4" rx="0.5" fill="#d8b25a"/><rect x="5.2" y="0.5" width="5.8" height="2.4" fill="#f6f0e2"/><text x="8.1" y="2.4" font-family="Arial,sans-serif" font-size="1.7" font-weight="700" fill="#5a4a3a" text-anchor="middle">WHITES</text>`); }
        // pods in the jar (seen through the glass), top glint
        const pods = rep(7, i => { const a = i * 2.2, q = C.P([38 + Math.cos(a) * 2, TOP + 1 + (i % 3) * 1.6, -12 + Math.sin(a) * 2]); return `<ellipse cx="${f1(q[0])}" cy="${f1(q[1])}" rx="${f1(1.3 * k)}" ry="${f1(1 * k)}" fill="${['#4a8ad8', '#f2f2f2', '#7ac85a'][i % 3]}" opacity="0.85"/>`; }).join('');
        const gl = PLN(C, [-50, TOP + 0.02, -22], [1, 0, 0], [0, 0, 1], `<rect x="0" y="40" width="10" height="1.2" fill="#fff4dc" opacity="0">${an('x', '0;90', 8)}${an('opacity', '0;0.5;0.5;0', 8)}</rect>`);
        return { defs, under: shadow(C, 0, 0, 52, 24, 0.3), front: s + pods + gl, bb: C.bb(5) }; };
      return D; };
  }

  // ---- clothes care batch 2: 080 (66 x 60 washer-dryer cabinetry) / 100 (106 x 54 sonic wardrobe)
  { const K = () => X.K, { rod } = RD.H16;
    const { shadow } = H, PLN = (C, O, U, V, svg) => `<g transform="${H.FR(C, O, U, V)}">${svg}</g>`;
    const glue = (o, p, L) => L.forEach(k => { k.par = p; o.push(k); });
    const clipQ = (C, id, pts) => `<clipPath id="${id}"><path d="M${pts.map(p => P2(C.P(p))).join('L')}Z"/></clipPath>`;

    // BTH-080 COMPACT SMART WASHER-DRYER HIDDEN IN CABINETRY (T4): a run of rift-sawn white-oak cabinetry with shaker doors and brass knobs above a recessed
    // toe-kick; the lower bay's pocket doors are slid back into the sides to reveal a graphite front-loading washer-dryer set into the bay - a chrome
    // porthole on smoked glass, a detergent drawer, a slim touch strip glowing soft white with the time left. Live: the drum turns and the laundry tumbles,
    // suds slosh, the display colon blinks and a status light breathes.
    N.cloth29d = S => { const OK = '#c9a476', WG = '#3a3d42', WZ = 23.4, WY0 = 3.4, WY1 = 48.6;
      const D = { w: 66, d: 60, build: () => { const { box } = K(), o = [], TX = { tex: 'url(#o80) none', texO: 0.8 };
          [-1, 1].forEach(s => o.push(box(s * 32, 0, 0, 2, 74, 60, OK, Object.assign({ r: 0.5, mat: 'wood' }, TX))));
          o.push(box(0, 50.2, 0, 61.8, 23.8, 60, OK, Object.assign({ r: 0.4, mat: 'wood' }, TX)));
          o.push(box(0, 0, -2, 61.8, 3.2, 56, '#3a3026', { r: 0.2, mat: 'matte' }), box(0, 3.4, -29.5, 61.8, 46.6, 1, OK, Object.assign({ r: 0.2, mat: 'wood' }, TX)));
          o.push(box(0, WY0, -2.6, 57.4, WY1 - WY0, 52, WG, { r: 1.4, mat: 'gloss' }));
          [-1, 1].forEach(s => o.push(box(s * 30.4, 3.4, 25, 0.9, 46.6, 10, shade(OK, 0.92), { r: 0.2, mat: 'wood' })));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('cloth29d'), k = C.k, fr = vdot(C, [0, 0, 1]) > 0.05;
        const gr = rep(22, i => `<path d="M${f1(i * 1.8 + R())} 0V40" stroke="${R() < 0.5 ? '#a8845a' : '#e0c49a'}" stroke-width="${f1(0.15 + R() * 0.25)}" opacity="0.5"/>`).join('') + rep(6, () => `<path d="M${f1(R() * 40)} ${f1(R() * 40)}l${f1(1 + R())} ${f1(-0.4)}" stroke="#a8845a" stroke-width="0.25" opacity="0.6"/>`).join('');
        const defs = `<pattern id="o80" width="40" height="40" patternUnits="userSpaceOnUse">${gr}</pattern>`;
        let s = '';
        if (fr) {
          // upper doors: two shaker panels + brass knobs; the bay's shadow under the upper cabinet
          s += PLN(C, [-30.9, 74, 30.03], [1, 0, 0], [0, -1, 0], [0, 31].map(x => `<rect x="${x + 0.4}" y="0.6" width="30" height="22.6" rx="0.4" fill="none" stroke="#7a5a36" stroke-width="0.5"/><rect x="${x + 4}" y="4" width="22.8" height="15.8" fill="#000" opacity="0.08"/><path d="M${x + 4} 19.8V4H${x + 26.8}" stroke="#6a4a2a" stroke-width="0.7" fill="none"/><path d="M${x + 26.8} 4V19.8H${x + 4}" stroke="#f0d8b0" stroke-width="0.6" fill="none"/>`).join('')
            + [28.2, 33.6].map(x => `<circle cx="${x}" cy="19" r="1.1" fill="#d8b25a" stroke="#8a6a2a" stroke-width="0.25"/><circle cx="${x - 0.3}" cy="18.7" r="0.4" fill="#fff2c8"/>`).join(''));
          s += PLN(C, [-29, 50.2, WZ + 0.05], [1, 0, 0], [0, -1, 0], `<defs><linearGradient id="${C.u('sh')}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0.45"/><stop offset="1" stop-color="#000" stop-opacity="0"/></linearGradient></defs>`.replace(/id="([^"]+)"/, (m, id) => (C._sh = id, m)) + `<rect x="0" y="0" width="58" height="5" fill="url(#${C._sh})"/>`);
          // washer front
          const PX = -8, PY = 24, PR = 13.6, did = C.u('dr'), cid = C.u('dc');
          s += PLN(C, [-28.7, WY1, WZ + 0.06], [1, 0, 0], [0, -1, 0], `<rect x="2.2" y="2.2" width="14" height="5" rx="0.8" fill="#2a2c30" stroke="#55585e" stroke-width="0.3"/><rect x="11.4" y="4" width="3.6" height="1.4" rx="0.5" fill="#4a4d52"/>`
            + `<rect x="31" y="2" width="24" height="5.6" rx="2.8" fill="#1a1b1e" stroke="#5a5d62" stroke-width="0.3"/><text x="40" y="6.3" font-family="Arial,sans-serif" font-size="3.6" fill="#f4efe2">0<tspan>:${an('opacity', '1;1;0;0', 1.2)}</tspan>42</text><circle cx="35" cy="4.8" r="1.1" fill="none" stroke="#e8e2d2" stroke-width="0.35"/><path d="M35 4.1V4.9L35.6 5.3" stroke="#e8e2d2" stroke-width="0.3" fill="none"/><circle cx="51.6" cy="4.8" r="0.7" fill="#f2c27a">${an('opacity', '0.4;1;0.4', 2.4)}</circle>`
            + `<rect x="0.6" y="9.4" width="56" height="0.25" fill="#55585e"/>`
            + `<defs><clipPath id="${cid}"><circle cx="${28.7 + PX}" cy="${WY1 - PY}" r="${PR - 3}"/></clipPath><radialGradient id="${did}" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#5a6068"/><stop offset="1" stop-color="#16181b"/></radialGradient></defs>`
            + `<circle cx="${28.7 + PX}" cy="${WY1 - PY}" r="${PR + 1}" fill="#4a4d52"/><circle cx="${28.7 + PX}" cy="${WY1 - PY}" r="${PR}" fill="none" stroke="#d8dde2" stroke-width="2.4"/><circle cx="${28.7 + PX}" cy="${WY1 - PY}" r="${PR - 1.2}" fill="none" stroke="#8a9096" stroke-width="0.5"/>`
            + `<circle cx="${28.7 + PX}" cy="${WY1 - PY}" r="${PR - 3}" fill="url(#${did})"/><g clip-path="url(#${cid})"><g transform="translate(${28.7 + PX} ${WY1 - PY})"><g>${at('rotate', '0;360', 3.2)}`
            + [['#e8e4da', 4, 0, 4.4], ['#5a7ab0', -3, 4, 4], ['#d86a6a', -2, -5, 3.6], ['#f0ece4', 5, 5, 3]].map(([c, x, y, r]) => `<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${f1(r * 0.7)}" fill="${c}" opacity="0.75" transform="rotate(${x * 20} ${x} ${y})"/>`).join('')
            + rep(10, i => `<circle cx="${f1(Math.cos(i * 0.63) * 8.6)}" cy="${f1(Math.sin(i * 0.63) * 8.6)}" r="0.45" fill="#2a2c30"/>`).join('') + `</g></g>`
            + `<path d="M-12 4Q-6 1 0 4T12 4V12H-12Z" transform="translate(${28.7 + PX} ${WY1 - PY})" fill="#d8e4ec" opacity="0.35">${at('translate', `${28.7 + PX} ${WY1 - PY};${28.7 + PX + 1.4} ${WY1 - PY - 0.8};${28.7 + PX} ${WY1 - PY}`, 1.6)}</path></g>`
            + `<path d="M${28.7 + PX - 7} ${WY1 - PY - 7}A9.6 9.6 0 0 1 ${28.7 + PX + 4} ${WY1 - PY - 9}" stroke="#ffffff" stroke-width="1" fill="none" opacity="0.35" stroke-linecap="round"/>`
            + `<rect x="${28.7 + PX + PR + 0.6}" y="${WY1 - PY - 3}" width="1.6" height="6" rx="0.8" fill="#6a6d72"/>`);
          // pocket-door edge highlights
          [-1, 1].forEach(sd => { const a = C.P([sd * 30.4, 4, 30.03]), b = C.P([sd * 30.4, 49.6, 30.03]); s += `<path d="M${P2(a)}L${P2(b)}" stroke="#f0d8b0" stroke-width="${f1(0.3 * k)}" opacity="0.7"/>`; });
        }
        return { defs, under: shadow(C, 0, 0, 34, 30, 0.35), front: s, bb: C.bb(4) }; };
      return D; };

    // BTH-100 SONIC DRY-CLEANING & STEAM-PRESSING WARDROBE (T5): a tall atelier wardrobe in figured walnut on a dark plinth with gold pinstripe inlay and a
    // gilded crown. Left, a full-height glass door onto a warm-lit chamber: a charcoal suit jacket, a cream silk slip dress, a camel coat and a white shirt on
    // walnut hangers along a brass rail, steam drifting through them while slow rings of sound pulse from gold emitters above. Right, a closed burl door with
    // a gold dial ringed in a soft amber display. Live: the garments sway, steam rises, the rings pulse, the dial's ring turns and the back glow breathes.
    N.cloth29e = S => { const WN = '#6a3e24', BZ = 27, GX0 = -51, GX1 = 9, Y0 = 4.6, Y1 = 91;
      const D = { w: 106, d: 54, build: () => { const { box } = K(), o = [], TX = { tex: 'url(#w100) none', texO: 0.85 };
          o.push(box(0, 0, 0, 104, 4.4, 52, '#2a1c14', { r: 0.4, mat: 'gloss' }));
          [-1, 1].forEach(s => o.push(box(s * 52, 4.4, 0, 2, 87, 54, WN, Object.assign({ r: 0.5, mat: 'gloss' }, TX))));
          o.push(box(0, 91.4, 0, 104, 5, 54, WN, Object.assign({ r: 0.8, mat: 'gloss' }, TX)));
          o.push(box(-20.6, 4.4, -5, 58, 87, 2, '#3a2a1e', { r: 0, mat: 'matte' }), box(-20.6, 4.4, -26, 58, 87, 2, WN, Object.assign({ r: 0, mat: 'gloss' }, TX)));
          o.push(box(11, 4.4, 0, 4, 87, 54, WN, Object.assign({ r: 0.4, mat: 'gloss' }, TX)));
          o.push(box(32, 4.4, 0, 37.6, 87, 54, WN, Object.assign({ r: 0.4, mat: 'gloss' }, TX)));
          o.push(box(-21, 4.6, 26.6, 58, 86.6, 0.4, '#f2f6f6', { r: 0, op: 0.16, mat: 'gloss' }));
          return o; } };
      D.fx = ctx => { const C = cam(ctx), R = rng('cloth29e'), k = C.k, fr = vdot(C, [0, 0, 1]) > 0.05;
        const fig = rep(10, () => { const y0 = R() * 40; let d = `M0 ${f1(y0)}`; for (let x = 8; x <= 40; x += 8) d += `Q${x - 4} ${f1(y0 + (R() - 0.5) * 6)} ${x} ${f1(y0 + (R() - 0.5) * 3)}`; return `<path d="${d}" stroke="${R() < 0.5 ? '#4a2614' : '#9a5e34'}" stroke-width="${f1(0.25 + R() * 0.4)}" fill="none" opacity="0.5"/>`; }).join('');
        const defs = `<pattern id="w100" width="40" height="40" patternUnits="userSpaceOnUse">${fig}</pattern>`;
        if (!fr) return { defs, under: shadow(C, 0, 0, 54, 28, 0.35), bb: C.bb(4) };
        const cid = C.u('w0'), gid = C.u('g0');
        // chamber (clipped to the glass opening): warm back glow, rail, hangers + garments, steam, sound rings
        const IZ = 9, GW = GX1 - GX0;
        const garment = (x, kind, i) => { const hook = `<path d="M${x} 9.2q0 -1.6 1.2 -1.6t1 1.2" stroke="#c9a35a" stroke-width="0.35" fill="none"/><path d="M${x - 6} 13.2L${x} 9.6L${x + 6} 13.2" stroke="#5a3a22" stroke-width="0.9" fill="none" stroke-linecap="round"/>`;
          let g = '';
          if (kind === 'suit') g = `<path d="M${x - 6.2} 13L${x - 7} 46H${x + 7}L${x + 6.2} 13Q${x} 11.6 ${x - 6.2} 13Z" fill="#3a3c40"/><path d="M${x - 2.6} 12.4L${x} 26L${x + 2.6} 12.4" fill="#f2f0ea"/><path d="M${x - 3.2} 12.4L${x - 0.6} 30L${x - 4} 20Z M${x + 3.2} 12.4L${x + 0.6} 30L${x + 4} 20Z" fill="#2c2e32"/><circle cx="${x}" cy="33" r="0.5" fill="#1a1a1c"/><circle cx="${x}" cy="37" r="0.5" fill="#1a1a1c"/><path d="M${x - 5} 34h3" stroke="#2a2c30" stroke-width="0.4"/>`;
          if (kind === 'dress') g = `<path d="M${x - 2.4} 12.6L${x - 3.6} 22Q${x - 8} 44 ${x - 8.6} 58H${x + 8.6}Q${x + 8} 44 ${x + 3.6} 22L${x + 2.4} 12.6" fill="#efe4d0" stroke="#d8c8ac" stroke-width="0.3"/><path d="M${x - 3.6} 22Q${x} 24 ${x + 3.6} 22" stroke="#d8c8ac" stroke-width="0.4" fill="none"/>` + [-4, 0, 4].map(d => `<path d="M${x + d * 0.4} 26Q${x + d} 44 ${x + d * 1.6} 57" stroke="#ffffff" stroke-width="0.6" fill="none" opacity="0.5"/>`).join('');
          if (kind === 'coat') g = `<path d="M${x - 6.6} 13L${x - 8} 62H${x + 8}L${x + 6.6} 13Q${x} 11.4 ${x - 6.6} 13Z" fill="#b88a58"/><path d="M${x} 13V62" stroke="#8a6238" stroke-width="0.4"/><path d="M${x - 3} 12.6L${x} 22L${x + 3} 12.6" fill="#a87a48"/><path d="M${x - 7.6} 36h15.2" stroke="#9a6e40" stroke-width="1.6"/>` + [26, 32, 42].map(y => `<circle cx="${x + 1.6}" cy="${y}" r="0.6" fill="#5a3a22"/>`).join('');
          if (kind === 'shirt') g = `<path d="M${x - 5.6} 13L${x - 6} 44H${x + 6}L${x + 5.6} 13Q${x} 11.8 ${x - 5.6} 13Z" fill="#f8f8f6" stroke="#dcdcd8" stroke-width="0.3"/><path d="M${x - 2} 12.4L${x} 16L${x + 2} 12.4" fill="#ffffff" stroke="#d0d0cc" stroke-width="0.3"/><path d="M${x} 16V44" stroke="#dcdcd8" stroke-width="0.35"/>` + [20, 26, 32, 38].map(y => `<circle cx="${x + 0.6}" cy="${y}" r="0.35" fill="#c8c8c4"/>`).join('');
          return `<g>${at('rotate', `-1.4 ${x} 9;1.4 ${x} 9;-1.4 ${x} 9`, 5 + i * 0.7, -i)}${hook}${g}</g>`; };
        const room = `<defs><radialGradient id="${gid}" cx="50%" cy="40%" r="65%"><stop offset="0" stop-color="#ffd9a0"/><stop offset="0.6" stop-color="#b8784a"/><stop offset="1" stop-color="#4a2e1c"/></radialGradient></defs>`
          + PLN(C, [GX0 + 1.05, Y1, -3.95], [0, 0, 1], [0, -1, 0], `<rect width="31" height="${Y1 - Y0}" fill="#5a3a24"/><rect width="31" height="${Y1 - Y0}" fill="#ffd9a0" opacity="0.12"/>`)
          + PLN(C, [GX0, Y0 + 0.08, -4], [1, 0, 0], [0, 0, 1], `<rect width="${GW}" height="31" fill="#4a2e1c"/><ellipse cx="${GW / 2}" cy="14" rx="${GW / 2.4}" ry="12" fill="#ffd9a0" opacity="0.25"/>` + rep(6, i => `<rect x="0" y="${f1(i * 5.2)}" width="${GW}" height="0.25" fill="#2a1a10" opacity="0.5"/>`).join(''))
          + PLN(C, [GX0, Y1, -3.95], [1, 0, 0], [0, -1, 0], `<rect width="${GW}" height="${Y1 - Y0}" fill="url(#${gid})"><animate attributeName="opacity" values="0.85;1;0.85" dur="6s" repeatCount="indefinite"/></rect>` + rep(8, i => `<rect x="${f1(i * 7.6 + 2)}" y="0" width="0.3" height="${Y1 - Y0}" fill="#e8c890" opacity="0.18"/>`).join(''))
          + PLN(C, [GX0, Y1 - 13, IZ], [1, 0, 0], [0, -1, 0], `<rect x="0" y="7.6" width="${GW}" height="1.4" rx="0.7" fill="#c9a35a"/><rect x="0" y="7.7" width="${GW}" height="0.4" fill="#fff0c8" opacity="0.7"/>` + [['coat', 10], ['suit', 24], ['dress', 37.6], ['shirt', 50]].map(([kd, x], i) => garment(x, kd, i)).join('')
            + rep(6, i => `<ellipse cx="${f1(8 + i * 9)}" cy="70" rx="6" ry="3" fill="#ffffff" opacity="0" filter="url(#${cid}b)">${an('opacity', '0;0.35;0', 6 + i * 0.6, -i)}${an('cy', '78;20', 6 + i * 0.6, -i)}</ellipse>`).join('')
            + [14, 30, 46].map((x, i) => `<rect x="${x - 3}" y="1" width="6" height="1.6" rx="0.6" fill="#c9a35a"/>` + rep(3, j => `<ellipse cx="${x}" cy="2.6" rx="0" ry="0" fill="none" stroke="#ffe0a0" stroke-width="0.35">${an('rx', '1;9', 3.6, -j * 1.2 - i * 0.4)}${an('ry', '0.4;6', 3.6, -j * 1.2 - i * 0.4)}${an('opacity', '0.7;0', 3.6, -j * 1.2 - i * 0.4)}</ellipse>`).join('')).join(''));
        const chamber = `<defs>${clipQ(C, cid, [[GX0, Y0, BZ], [GX1, Y0, BZ], [GX1, Y1, BZ], [GX0, Y1, BZ]])}<filter id="${cid}b" x="-1" y="-1" width="3" height="3"><feGaussianBlur stdDeviation="1.4"/></filter></defs><g clip-path="url(#${cid})">${room}</g>`;
        // glass reflections, gold pinstripes on the walnut, dial + handles, crown and plinth gold
        const glass = PLN(C, [GX0, Y1, BZ + 0.02], [1, 0, 0], [0, -1, 0], `<path d="M8 0L22 0L6 ${Y1 - Y0}H-8Z" fill="#ffffff" opacity="0.08"/><path d="M30 0H33L17 ${Y1 - Y0}H14Z" fill="#ffffff" opacity="0.1"/><rect x="0.4" y="0.4" width="${GW - 0.8}" height="${Y1 - Y0 - 0.8}" fill="none" stroke="#c9a35a" stroke-width="0.6"/>`);
        const door = PLN(C, [13.2, 91.4, BZ + 0.03], [1, 0, 0], [0, -1, 0], `<rect x="3" y="4" width="31.6" height="79" rx="0.6" fill="none" stroke="#d8b25a" stroke-width="0.45"/><rect x="5" y="6" width="27.6" height="75" rx="0.4" fill="none" stroke="#d8b25a" stroke-width="0.25" opacity="0.7"/>`
          + `<circle cx="18.8" cy="30" r="5.2" fill="#2a1c14" stroke="#d8b25a" stroke-width="0.9"/><g transform="translate(18.8 30)"><g>${at('rotate', '0;360', 24)}<circle r="4" fill="none" stroke="#ffc878" stroke-width="0.5" stroke-dasharray="1.4 0.8" opacity="0.85"/></g></g><circle cx="18.8" cy="30" r="2.4" fill="#d8b25a"/><circle cx="18.2" cy="29.4" r="0.8" fill="#fff2c8"/>`
          + `<text x="18.8" y="39.4" font-family="Georgia,serif" font-size="1.8" letter-spacing="0.5" fill="#d8b25a" text-anchor="middle">ATELIER</text><rect x="1.2" y="38" width="1.2" height="18" rx="0.6" fill="#d8b25a"/>`);
        const pull = PLN(C, [GX1 - 2.6, 58, BZ + 0.05], [1, 0, 0], [0, -1, 0], `<rect x="0" y="0" width="1.2" height="18" rx="0.6" fill="#d8b25a"/><rect x="0.2" y="0.4" width="0.4" height="17" fill="#fff2c8" opacity="0.7"/>`);
        const crown = PLN(C, [-52, 96.4, BZ + 0.03], [1, 0, 0], [0, -1, 0], `<rect x="0" y="1.2" width="104" height="0.6" fill="#d8b25a"/><rect x="0" y="3.6" width="104" height="0.3" fill="#d8b25a" opacity="0.7"/>`) + PLN(C, [-52, 4.4, 26.03], [1, 0, 0], [0, -1, 0], `<rect x="0" y="1.2" width="104" height="0.5" fill="#d8b25a"/>`);
        return { defs, under: shadow(C, 0, 0, 54, 28, 0.35) + (() => { const id = C.u('fg'); return PLN(C, [GX0, 0.05, BZ], [1, 0, 0], [0, 0, 1], `<defs><radialGradient id="${id}"><stop offset="0" stop-color="#ffd9a0" stop-opacity="0.35"/><stop offset="1" stop-color="#ffd9a0" stop-opacity="0"/></radialGradient></defs><ellipse cx="${GW / 2}" cy="6" rx="${GW / 2}" ry="8" fill="url(#${id})"/>`); })(), front: chamber + glass + door + pull + crown, bb: C.bb(4) }; };
      return D; };
  }

  RD.SET29 = {
    'BTH-080': { spec: 'cloth29d', live: 'Drum turns + laundry tumbles', note: 'A run of rift-sawn white-oak cabinetry with shaker doors and brass knobs over a recessed toe-kick; the lower pocket doors are slid back to reveal a graphite front-loading washer-dryer set into the bay, with a chrome porthole on smoked glass, a detergent drawer and a slim touch strip glowing soft white with the time left. The drum turns, laundry tumbles, suds slosh and the display blinks.' },
    'BTH-100': { spec: 'cloth29e', live: 'Garments sway + steam + sound rings', note: 'A tall atelier wardrobe in figured walnut with gold pinstripe inlay and a gilded crown. Behind a full-height glass door, a warm-lit chamber holds a camel coat, a charcoal suit jacket, a cream silk dress and a white shirt on walnut hangers along a brass rail, steam drifting through them while slow rings of sound pulse from gold emitters above; beside it a closed walnut door with a gold dial ringed in amber light.' },
    'BTH-020': { spec: 'cloth29a', live: 'Swinging sock + drifting lint', note: 'A dingy white pop-up mesh hamper on a spring-wire frame, sides sagging and grubby toward the base, a frayed grey rim binding and cloth carry loops, with laundry heaped over the top (jeans, a pink tee, a grey towel, a black sock), a striped sleeve and a sock hanging over the edge, a split in the mesh and a lost sock on the floor.' },
    'BTH-040': { spec: 'cloth29b', live: 'Swaying sleeve + swinging sachet', note: 'A tapered round hamper hand-coiled from natural seagrass with darker stitches, a braided rim and twisted rope handles, a domed coiled lid with a loop handle sitting a little ajar on a white cotton liner folded over the rim, a striped sleeve escaping from under the lid and a lavender sachet tag hanging from the loop.' },
    'BTH-060': { spec: 'cloth29c', live: 'Light glides along the bamboo', note: 'A caramelised strand-bamboo cabinet on short legs with two tilt-out laundry bins: the left tipped open showing a grey linen bag heaped with whites, the right shut with a cut-out finger pull, each with a small brass label holder (WHITES / COLOURS), and a glass jar of laundry pods on the top.' },
    'BTH-079': { spec: 'surf29d', live: 'Condensation + drifting cucumber + brass glint', note: 'A brushed-brass tube trolley on four brass casters with two honed travertine shelves and a towel bar carrying a waffle hand towel. On top a glass carafe of cucumber-mint water with two tumblers; below a stack of folded white towels and a bowl of pink Himalayan bath salts with a wooden scoop. Condensation runs down the carafe and a glint travels along the brass.' },
    'BTH-099': { spec: 'surf29e', live: 'Floating tray + turning pages + champagne bubbles', note: 'A honey-onyx puck glowing warm from inside, ringed in gold, holds a polished walnut tray with a gold gallery rail in the air: a crystal flute of champagne, a gold-rimmed dish of strawberries, water beading on the lacquer and a slim gold emitter projecting an open book of warm amber light. The tray bobs, pages turn, bubbles stream up and the light breathes.' },
    'BTH-019': { spec: 'surf29a', live: 'Slimy drip', note: 'A cheap quarter-round corner soap dish in yellowed aqua plastic with drain ribs and two grey suction cups on its back edges (one gone cloudy), holding a cracked, shrunken bar of soap with a hair stuck to it. Soap-scum slime oozes over the front rim past black mildew dots and drips into a milky puddle on the floor.' },
    'BTH-039': { spec: 'surf29b', live: 'Tea steam + tealight flicker', note: 'A slatted bamboo bath caddy with both extension arms pulled out to their end grips, a hinged book rest holding a paperback open, a sage stoneware mug of tea with the tea-bag tag hanging over the rim and a tealight in a tin. Steam curls off the tea and the tealight flickers.' },
    'BTH-059': { spec: 'surf29c', live: 'Tea steam + glint on the oiled top', note: 'A solid oiled-teak round side table with a softened edge on a turned teak pedestal and round foot, golden grain. At the back: a white ceramic teapot with a bamboo handle, a celadon cup of green tea and a little pyramid of rolled white spa towels. Steam rises from the cup and spout, and a warm glint moves across the top.' },
    'BTH-077': { spec: 'spa29d', live: 'Trickling water + mist + warm light', note: 'A tall walnut-framed panel planted solid with living moss (cushion mounds in many greens, pale reindeer-moss clusters, tiny ferns) washed by a warm LED strip under the top frame; a cut bamboo spout juts from the moss and trickles into a long honed basalt basin trimmed in brass with river stones under the water. Rings spread, mist lifts and the light breathes.' },
    'BTH-097': { spec: 'spa29e', live: 'Koi swim + waterfall + rolling mist', note: 'A pond sunk into the floor, ringed with weathered granite stones, deep teal water lit warm from below round a craggy stone island crowned by an old juniper bonsai with silver deadwood over moss cushions; a thread of water slips down the rock, lily pads and a pink lotus float, petals drift. Five koi circle the island while low mist rolls off the water.' },
    'BTH-017': { spec: 'spa29a', live: 'Stiff fronds tremble + dust motes', note: 'The dollar-store fake fern off the toilet tank: stiff moulded fronds with identical leaflets in a too-bright green, two sun-bleached and one kinked, stuck in green-dyed foam in a thin faded terracotta-look plastic pot with a moulding seam and a half-peeled 99c sticker, standing on a pastel crocheted doily beside a dust bunny and a snapped-off leaflet.' },
    'BTH-037': { spec: 'spa29b', live: 'Swaying bundle + rising steam + drips', note: 'A fresh bundle of silver-dollar eucalyptus (round blue-grey leaves with a white bloom on red-brown stems) tied with jute twine looped over a plain chrome shower arm, hanging upside down below a bell showerhead with limescale spots. The bundle sways, steam wisps rise through the leaves and drops fall from the head.' },
    'BTH-057': { spec: 'spa29c', live: 'Fern breathes + water shimmer', note: 'A tall clear glass cylinder of lucky bamboo cut in three heights with darker nodes and fresh sprouts, standing in white pebbles and clear water and bound with a gold ribbon, beside a lush Boston fern spilling arching fronds over a matte white ceramic planter on a slim three-legged brass stand.' },
    'BTH-076': { spec: 'seat29d', live: 'Steam off the heated slab', note: 'A long white Carrara marble slab with soft grey and gold veins on a fluted marble body over a stepped plinth, with brass trim along the edge; on the plinth ledge a hammered brass hammam bowl of water and a rolled striped peshtemal. Thin steam lifts off the heated slab and ripples cross the bowl.' },
    'BTH-096': { spec: 'seat29e', live: 'Floating glow + rising motes', note: 'A sculpted zero-gravity lounger of quilted pearl panels with mint piping (raised head, cradled hips, lifted knees) hovering over a black glass disc ringed with mint light, with a lavender control orb floating at its foot. The under-light breathes mint to lavender, warm shimmer rises off the cushions, motes drift up through the gap and the orb pulses.' },
    'BTH-016': { spec: 'seat29a', live: 'Dripping edge', note: 'A cheap faded mustard plastic step stool with a ribbed anti-slip top and a hand-grip slot, four splayed legs with braces, one leg split and bound with grey duct tape, a peeling sticker and scuffs, standing in a wet ring. A drop slides off the edge and plinks into the puddle.' },
    'BTH-036': { spec: 'seat29b', live: 'Drips between the slats', note: 'A round slatted bamboo seat on two X-folding bamboo leg frames with nodes, steel hinge rivets and foot rails, water beaded on the slats and a white face cloth folded over the edge. Drops fall between the slats and a glint slides along a rail.' },
    'BTH-056': { spec: 'seat29c', live: 'Steaming oke bucket', note: 'A tall pale hinoki stool with a round seat, four square legs and a lower shelf holding a matching hinoki oke bucket bound with dark copper hoops and full of warm water, a hishaku ladle resting across it. Steam curls from the bucket, ripples cross the water and a drop falls from the ladle.' },
    'BTH-071': { spec: 'pet29d', live: 'Bubble jets + warm-air ribbons', note: 'A big pearl-white bubble-spa pool (6 bathing spots) with a champagne rim band and a soft blue glow under the lip, backed by a curved pearl blow-dry hood with warm amber vents, two round dryer fans and a WARM AIR 38°C display. Jets fizz bubbles up, warm-air ribbons stream down, the fans spin and the glow breathes.' },
    'BTH-091': { spec: 'pet29e', live: 'Swan fountain + diamond sparkles', note: 'A grand oval white-marble pool (7 bathing spots) on a stepped marble plinth with a 24k gold rim and gold jet rosettes, rose petals on the water, a gold swan fountain pouring into it and two gold lantern columns. The stream pours and splashes, jets swirl bubbles, diamond sparkles drift and the lanterns glow.' },
    'BTH-011': { spec: 'pet29a', live: 'Bobbing duck + taped leak', note: 'A big (3 bathing spots) cheap faded-blue plastic washtub, scuffed and grimy outside, with moulded grip slots and a crack patched with silver duct tape; soapy water with foam patches, a rubber duck and a pink squeaky bone floating. The duck bobs, bubbles pop, ripples spread and a drip seeps from the taped crack into a puddle.' },
    'BTH-031': { spec: 'pet29b', live: 'Foam bubbles', note: 'A roomy (4 bathing spots) clean white acrylic pet tub with a rolled rim; a teal non-slip insert with rows of suction-cup bubbles shows through the clear water, a teal palm foaming brush with soft nubs sits on the rim, and a pink paw-print shampoo bottle on the other side. Foam bubbles bloom round the brush and float off, ripples cross the water and a glint slides on the rim.' },
    'BTH-051': { spec: 'pet29c', live: 'Steam + bobbing yuzu', note: 'A big round (5 bathing spots) pale hinoki-cypress soaking tub bound with two copper hoops, full of clear hot water with yuzu bobbing in it, beside a little hinoki stool with a wooden ladle and a spare yuzu. Steam curls up, the yuzu bob and ripples spread.' },
    'BTH-068': { spec: 'amen29d', live: 'Amber light + jade sheen', note: 'A honed travertine tray with two amber glass pump bottles (black pumps, minimal cream labels with fine black type), a small amber dropper bottle of face oil, and a double-ended jade facial roller in a gold frame. Honey-gold light drifts through the amber glass, an amber caustic shimmers on the tray and a sheen slides over the jade.' },
    'BTH-088': { spec: 'amen29e', live: 'Gold flakes, lotus flames, sound rings', note: 'A white marble tray with a gold edge: two faceted crystal dispensers of golden elixir with 24k gold pumps and tiny ELIXIR plaques, a frosted quartz singing bowl on a plum silk ring cushion with a suede mallet, and a glass bowl of water with two blush lotus candles floating in it. Gold flakes twinkle, the flames flicker over ripples, and soft sound rings pulse from the bowl.' },
    'BTH-008': { spec: 'amen29a', live: 'Soap bubble + drip', note: 'A grimy translucent blue soap dish with drain ridges holding a cracked, worn-thin pink soap sliver with a stray hair, and a crumpled half-squeezed toothpaste tube with a faded red band, its cap lying aside and a worm of paste oozing out. A soap bubble swells and pops on the sliver and a drip gathers under the dish.' },
    'BTH-028': { spec: 'amen29b', live: 'Soap pearl drops', note: 'A speckled oatmeal stoneware set on a matching oval tray: a pump dispenser stamped "savon" with a brushed-steel pump, and a tumbler holding a teal and a coral toothbrush. A pearl of soap gathers on the nozzle and drops, and glints slide down the glaze.' },
    'BTH-048': { spec: 'amen29c', live: 'Scent curls', note: 'A teak tray with a smoked-glass reed diffuser (black collar, kraft "Cedar & Sage" label) and a fan of rattan reeds, a grey porous volcanic pumice stone, three rolled waffle hand towels in oatmeal, white and sage, and a eucalyptus sprig. Faint scent curls rise from the reed tips and an oil glint creeps up a reed.' },
    'BTH-067': { spec: 'therm29d', live: 'Breathing salt wall + IR glow', note: 'A smoked thermo-ash cabin under a black cornice with a gold edge, its whole front bronze-tinted glass with a door mullion, a tall gold pull and a touch panel. Inside: a wall of glowing Himalayan salt bricks, a two-tier hemlock bench, red infrared panels, a brushed-steel heater with stones and a cedar bucket. The salt wall and the IR panels breathe, heat shimmers off the stones and the panel reads 65°.' },
    'BTH-087': { spec: 'therm29e', live: 'Cryo mist + heat waves', note: 'Two tall pearl-white capsules with champagne-gold bands and finials on an oval marble plinth, joined by a slim column with a gold cap and a bio readout. The cryo window is frosted ice-blue with swirling mist and sparkling frost; the thermal window glows amber with rising heat waves. Readouts pulse, base light rings breathe mint and amber, and cold fog spills over the plinth.' },
    'BTH-007': { spec: 'therm29a', live: 'Steam + mint swirl', note: 'A dented, rust-spotted galvanised bucket with pressed ribs and a wire bail handle, full of hot water gone pale minty green, a little green bottle of menthol drops with a rubber dropper, a thin worn towel on the floor with a dented tin ladle, and a splashed puddle. Steam curls up, a mint swirl turns in the water, ripples spread and a drip runs down into the puddle.' },
    'BTH-027': { spec: 'therm29b', live: 'Leaking steam + blinking light', note: 'A sage nylon pop-up steam tent with a padded collar and drawstring round the head hole, a U-shaped zip door with a dangling pull, soft creases and a side hose port; beside it a small white steam generator with a dial, a green light and a ribbed hose. Steam leaks from the collar and the zip, the light blinks and the nylon slowly puffs.' },
    'BTH-047': { spec: 'therm29c', live: 'Glowing lava rocks + steam puffs', note: 'A cedar barrel sauna on two cradles, with grooved staves held by black steel bands, a board end wall with a round-topped glass door, cedar pull and thermometer, and a black stovepipe. Through the glass: cedar benches, a heater piled with lava rocks, a bucket and ladle. The rocks breathe red-orange, steam puffs off the stones and heat shimmers over the pipe.' },
    'BTH-063': { spec: 'warm29', live: 'Breathing warm glow', note: 'A walnut cabinet on brass bun feet with a polished brass frame, crown and glass door: brass hot-water rails glow along the back above walnut shelves stacked with rolled white, cream and taupe towels, and a brass thermostat plate reads 52°C. A warm amber glow breathes behind the glass and heat shimmers above the crown.' },
    'BTH-083': { spec: 'vault29', live: 'UV-to-warm cycle + lavender mist', note: 'A tall ivory-lacquer vault on a champagne-gold plinth under a gold crown: one closed door with raised gold-lined panels and a smoked display, one smoked-glass door showing a plush white robe on a gold rod over a lavender sachet. The robe glows in a slow UV-to-warm cycle, lavender mist curls inside, sparkles twinkle and the display ring fills.' },
    'BTH-003': { spec: 'rack29a', live: 'Swinging hook', note: 'A cheap chrome-plated hook rail on a thin pole stand with a dented base, flaking to rust: a damp grey threadbare towel with a frayed hem on one hook, a pink shower cap on another, and the middle hook hanging loose by one screw. The loose hook swings and the damp towel drips into a little puddle.' },
    'BTH-023': { spec: 'rack29b', live: 'Chrome glints', note: 'A polished chrome valet with three round bars between two uprights on chrome feet: a fluffy blush bath towel with a cream band over the top bar, a mint hand towel on the middle bar and a white face cloth with a mint stripe on the bottom one. Glints slide along the chrome.' },
    'BTH-043': { spec: 'rack29c', live: 'Swaying fringe', note: 'A natural bamboo ladder leaning on the wall, with knuckled rails and five rungs: an oatmeal linen towel with a fringe over the second rung and a sage waffle towel over the fourth. The linen fringe sways softly.' },
    'BTH-078': { spec: 'shw29d', live: 'Body jets and waterfall', note: 'Calacatta marble walls with soft grey-gold veins and a brushed-gold base trim, a white marble tray with a gold linear drain and a glass side screen with a slim gold profile. On the back wall, a tall smoked-glass shower panel framed in champagne gold, with six round gold body jets, a warm thermostat display reading 38.0° and a gold blade waterfall spout. The jets fire soft mist in turns, the waterfall pours and steam drifts up.' },
    'BTH-098': { spec: 'shw29e', live: 'Sonic citrus mist', note: 'A round walk-in pod: a polished gold plinth with a black-glass floor ring and a softly lit control strip, a curved wall of clear glass faintly tinted champagne, and a pearl-white and gold dome with a ring of mist nozzles. Warm citrus "vitamin" mist swirls round inside, sonic rings travel up and down the glass, droplets sparkle and the plinth light breathes.' },
    'BTH-018': { spec: 'shw29a', live: 'Sputtering drips', note: 'A dingy stall of grey 4 inch tiles with darkened grout and mildew creeping up from the floor, a cracked acrylic tray with a rusty drain, an exposed chrome riser with a crusty old showerhead, two worn cross handles, a sagging wire soap rack with a soap sliver and a peeling "shower" sticker. The head only dribbles, in weak uneven bursts.' },
    'BTH-038': { spec: 'shw29b', live: 'Dual spray', note: 'A clean stall in white subway tile with a mint band and a white tray: a chrome slide bar with a handheld wand on its silver hose, a chrome mixer, and a chrome corner caddy with pastel bottles and a lilac pouf. The wand sprays a gentle stream, then switches to its wide ring spray.' },
    'BTH-058': { spec: 'shw29c', live: 'Rainfall', note: 'Warm grey microcement walls with a lit recessed niche holding amber bottles and a candle, a slate tray under an oiled teak duckboard, and an exposed brushed-brass column: riser, mixing valve with two handles, a long arm to a big round rain head and a handheld on a brass cradle. Soft rain falls in waves and the candle flickers.' },
    'BTH-075': { spec: 'onsen29a', live: 'Hot spring spout', note: 'A deep square tub of pale golden hinoki boards with fine straight grain, bound by two hammered copper bands under a wide hinoki rim. A bamboo spout on a hinoki post pours hot spring water in at the back corner, a hinoki bucket with a ladle sits on the rim and yuzu float on the steaming water. Rings spread, the yuzu bob and steam curls rise.' },
    'BTH-095': { spec: 'onsen29b', live: 'Infinity edge and jets', note: 'A pool of honed warm travertine capped in polished gold, filled with milky turquoise mineral water lit from below. The front is a knife-thin infinity edge where the water slides over in a glassy sheet into a gold-lined channel, a gold slot spout in the back wall feeds a thin waterfall, three whirlpool jets swirl rings of bubbles, and mineral sparkles and steam rise.' },
    'BTH-015': { spec: 'tub29a', live: 'Dripping spout', note: 'An old roll-top cast-iron tub on four rusty claw feet: tired cream enamel inside with a brown rust ring at the waterline and a rust streak under the spout, the outside paint flaked off in patches down to black iron, chips along the rolled rim, tarnished brass taps and spout, cloudy water and a rubber duck. The spout drips, rings spread and the duck bobs.' },
    'BTH-035': { spec: 'tub29b', live: 'Bubbles and candle', note: 'A clean glossy white acrylic alcove tub with a tall front apron and wide ledges, a chrome spout and overflow plate at the tap end, a soft grey bath pillow at the other, mounds of bubble foam, a rubber duck and a jar candle on the back ledge. The candle flickers, the foam shimmers and the duck bobs.' },
    'BTH-055': { spec: 'tub29c', live: 'Ripples and tea-light', note: 'A seamless egg-shaped tub in matte white stone resin, thin-rimmed and wide at the shoulder, on a recessed plinth, with a tall matte black floor-standing filler and hand shower at the head end. A teak bath bridge across the middle holds a book, a glass of iced tea and a tea-light. The tea-light flickers, the hand shower sways and slow ripples cross the clear water.' },
    'BTH-066': { spec: 'sink29d', live: 'Trickling spouts', note: 'A thick white quartz top veined in grey and gold with a matching backsplash, on a slim brushed brass console with a walnut shelf holding rolled towels and a woven basket. Two hand-carved river-stone basins in dark green-grey stone with chisel marks sit under brass wall spouts with levers, and a brass tray with a perfume bottle sits between them. The spouts trickle in turn, rings spread on the water and a glint runs down a brass leg.' },
    'BTH-086': { spec: 'sink29e', live: 'Twin waterfalls', note: 'A polished black marble panel with a gold inlay line; a sculpted block of translucent honey-white alabaster floats off it, glowing warm from within. A gold blade spout pours a clear sheet of water into its shallow basin, which overflows the front lip in a second sheet into a long gold-and-black-glass trough on the floor, with a gold sensor plate and its glowing ring. Ripples spread in the basin and the trough and a glint travels along the gold.' },
    'BTH-006': { spec: 'sink29a', live: 'Dripping tap', note: 'A chipped, yellowing basin on a cracked pedestal with two old cross-head taps (red and blue buttons). Copper supply lines and a rusty drain pipe run bare into the wall, there is a rust streak in the bowl under the taps and a worn bar of soap stuck to the rim. The hot tap drips and rings spread on the water.' },
    'BTH-026': { spec: 'sink29b', live: 'Soap bubbles', note: 'A crisp white shaker vanity with two doors, brushed nickel knobs and a toe kick under a cultured-marble top with an integrated oval basin and a short backsplash. A single-lever chrome faucet, a blush soap pump, a mint cup of toothbrushes and a folded peach hand towel. Soap bubbles drift up from the pump now and then.' },
    'BTH-046': { spec: 'sink29c', live: 'Warm under-glow', note: 'An oiled teak drawer unit floating off the wall with a finger-pull groove, a teak top with a hand-thrown matte white vessel bowl, a tall matte black gooseneck faucet, a stone soap dish and a bud vase of eucalyptus that gently sways. A floating teak shelf below holds two rolled linen towels, and a warm LED line glows under the drawer.' },
    'BTH-062': { spec: 'loo29d', live: 'Heated seat', note: 'A one-piece skirted, tankless toilet in warm ivory porcelain with a fine champagne-gold line round the skirt, an elongated soft-close seat and closed lid, and a sleek rear unit with a brushed champagne control strip (seat heat lit amber, water, dryer, deodorizer). A warm shimmer rises off the heated seat, the deodorizer breathes out a faint curl and a soft amber night-light glows on the floor round the base.' },
    'BTH-082': { spec: 'loo29e', live: 'Hovering throne', note: 'A sculpted Carrara-marble throne hovering over a polished gold plinth with a black glass top: a tall marble back with a gold crown cap and three gold finials, floating marble armrests capped in gold, and a marble bowl and closed lid edged in gold. A warm beam and a turning gold halo fill the hover gap, a soft UV ring breathes round the seat and a little champagne hologram over the arm shows a heartbeat line and "all clear".' },
    'BTH-002': { spec: 'loo29a', live: 'Dripping cistern', note: 'A shabby high-cistern toilet: a chipped cast cistern on two rusty brackets high on the wall, a long corroded flush pipe down to the bowl with a rag stuffed round a leaking joint, a cracked wooden seat, a stained bowl and a chipped foot. The pull chain sways and the cistern drips into a little puddle.' },
    'BTH-022': { spec: 'loo29b', live: 'Air freshener puffs', note: 'A clean glossy white two-piece toilet: the tank on its deck with a chrome lever, a white seat and closed lid under a fluffy mint lid cover, a spare roll and a little succulent on the tank lid. The plug-in air freshener on the tank puffs now and then.' },
    'BTH-042': { spec: 'loo29c', live: 'Night-light glow', note: 'A matte charcoal panel hides the cistern, topped by an oiled oak shelf with a reed diffuser and a small fern. The rimless bowl floats off the floor with a slim soft-close seat and the lid up against the panel, and there is a brushed brass dual-flush plate. A soft warm night-light glows under the floating bowl.' },
    'BTH-010': { spec: 'mirr29a', live: 'Steam fog', note: 'A plain rectangle of mirror glass with a ground edge, held by plastic clips (one snapped and replaced by a bent nail). Black-brown desilvering creeps in from the corners and bottom edge, with a crack across one corner, scratches, toothpaste flecks and a sticker scrap. Steam fogs the bottom of the glass and slowly clears.' },
    'BTH-030': { spec: 'mirr29b', live: 'Glinting mirror', note: 'A white steel medicine cabinet with a bright chrome trim round its mirrored door and a chrome finger pull, a "dentist Tue 4pm" sticky note and a kid\'s gold star sticker. A glint slides across the mirror.' },
    'BTH-050': { spec: 'mirr29c', live: 'Anti-fog clears', note: 'A big frameless round mirror floating off the wall on a warm halo of backlight, with a frosted LED ring inside its edge and a glowing defog touch button. Steam mist creeps in from the rim and the anti-fog clears it from the middle out.' },
    'BTH-070': { spec: 'mirr29d', live: 'Clock and weather', note: 'A tall arch mirror in a slim polished brass frame with a fine beaded inner edge, on a little brass ledge with a perfume bottle and a tiny trailing plant. Through the glass a soft champagne display shows the clock with a sweeping second hand, the date and the weather (sun and cloud, 24°).' },
    'BTH-090': { spec: 'mirr29e', live: 'Face scan and styles', note: 'A large rounded mirror in a champagne-gold frame studded with glowing globe bulbs. In the glass a soft rose-gold hologram scans a cute creature face, shows little readings (hydration, glow, a sunscreen reminder) and floats a styling preview that cycles through a bow, a tiara and a flower crown.' },
    'BTH-013': { spec: 'fluor29', live: 'Flickering tube', note: 'A cheap enamel strip light over the mirror with a yellowed, cracked prismatic lens full of dead bugs. One end cap is gone so the bare tube shows its blackened end, there are rusty screws with a rust dribble, a grey cord stapled up the wall and a ball-chain pull switch that sways. The tube stutters and the greenish wash on the wall flickers with it.' },
    'BTH-033': { spec: 'globe29', live: 'Warm glow', note: 'A polished chrome backplate with three curved chrome arms holding satin-frosted glass globes that glow warm white (one a slightly whiter replacement), with soft pools of light on the wall that gently breathe.' },
    'BTH-053': { spec: 'lant29', live: 'Flickering lanterns', note: 'A hinoki lantern post on a split-granite base with a little cap and two carved arms, each holding an andon lantern: a hinoki frame and kumiko lattice over warm rice paper glowing like candlelight. A pool of light falls on the floor, the paper softly flickers and a tiny moth circles one lantern.' },
    'BTH-073': { spec: 'salt29', live: 'Breathing salt glow', note: 'Three square niches set into the wall near the floor, each with a brushed brass bezel and a sealed glass cover beaded with condensation over a rough block of pink-orange Himalayan salt with facets and white veins, lit from behind. Warm rose light spills across the wall, and each block slowly breathes out of step with the others.' },
    'BTH-093': { spec: 'jelly29', live: 'Pulsing jellyfish', note: 'A polished brass wall rail with three swan-neck arms, each hanging a hand-blown glass orb on a fine brass chain. Inside each, a glowing moon jelly pulses and drifts among sparkling plankton. The light follows a slow day (dawn amber, soft daylight, dusk rose, night blue) and washes the wall behind, and the orbs gently sway.' },
    'BTH-009': { c29: 'peel', live: 'Rattling fan', note: 'Yellowed drywall with taped seams (one cracked, a strip of tape peeling and swaying), brown leak rings and mildew creeping in from the back corners. Big patches have blistered and peeled down to the old blue-grey coat, with curling flakes hanging. A rust-streaked exhaust fan with dust-caked louvres spins lopsided and rattles its grille, with a lint strand dangling and a cobweb in the corner.' },
    'BTH-029': { c29: 'pvc', live: 'Glowing vent', note: 'Glossy white tongue-and-groove PVC strips running to the back wall, each a hair different white, with V-grooves and soft reflections, finished with a white cove trim. A round low-profile vent with concentric slots and a warm white LED ring glows softly on the panels while little wisps of air curl into it, with a few condensation beads.' },
    'BTH-049': { c29: 'cedar', live: 'Drifting clouds', note: 'Aromatic red cedar boards run across the room with staggered joints, flowing grain, knots and warm colour shifts, under a cedar crown. In the middle, a deep white skylight well with a slim bronze frame looks up at blue sky where clouds drift past, with a fallen maple leaf and condensation on the glass and warm daylight spilling onto the cedar.' },
    'BTH-069': { c29: 'dome', live: 'Chromotherapy halo', note: 'Warm ivory tadelakt rising into a hammam dome that climbs to a glowing oculus, pierced by rings of star-shaped glass lenses that twinkle and edged with a polished brass rim. A hidden halo slowly cycles through soft amber, rose, lavender and sea-glass, tinting the dome, while steam curls drift up into it.' },
    'BTH-089': { c29: 'rain', live: 'Rain-cloud canopy', note: 'A honed charcoal stone ceiling with a champagne light line glowing in the shadow gap round a huge brass-framed canopy of luminous opal glass where soft clouds drift. A grid of polished brass rain nozzles twinkles in a slow wave, fine rain streaks fall from them, cool mist rolls beneath and negative-ion sparkles glint in the air.' },
    'BTH-004': { spec: 'sticker29', live: 'Fluttering corner', note: 'A sun-faded vinyl "WASH YOUR HANDS" sticker (cartoon hands under a tap, soap bubbles and a "20 SEC!" burst) with air bubbles, scratches and grime round the edge. Its top corner has peeled and folded over, showing the grey back and a dusty sticky patch, and it flutters in the draught. Beside it the ghost and tape scraps of an older sticker, and a cloudy suction-cup hook that has slid down the wall, holding a pink mesh loofah that sways and drips.' },
    'BTH-024': { spec: 'seaweed29', live: 'Swaying frame', note: 'Three pressed-seaweed specimens on cream rag paper in pale oak frames with white mats, hung on picture wire from nails: red Plocamium with fine branching fronds, translucent green Ulva sea lettuce and olive Fucus bladder wrack with its air bladders, each with a handwritten label and number. A little orange starfish is tucked into one frame, and the crooked right frame gently sways.' },
    'BTH-044': { spec: 'noren29', live: 'Swaying noren', note: 'A thick weathered cedar board with a deeply carved, gilded 湯 ("hot water") and a red seal, pegged to the wall. Under it, an indigo cotton noren hangs in two panels from a bamboo pole on wooden brackets, with a big white ゆ across the split, a wave pattern at the hem and soft folds. The panels sway gently.' },
    'BTH-064': { spec: 'ripple29', live: 'Candle and light', note: 'A honed travertine panel carved like a raked zen garden: straight grooves swirl into rings around three raised stones, lit from above so every groove shows. It floats on a dark bronze reveal under a polished brass picture light whose warm wash slowly breathes while a soft sheen glides across the ripples. Below, a floating stone ledge holds a candle in a brass cup that flickers on the wall and a curl of incense.' },
    'BTH-084': { spec: 'holo29', live: 'Living window', note: 'A deep walnut window frame with a polished brass bezel that looks out on a snowy mountain hot spring at dusk: a violet-to-peach sky, the moon and twinkling stars, snowy peaks, a ryokan with glowing windows among snowy pines, and a rock-ringed pool where a snow monkey soaks with a towel on its head beside a stone lantern. Steam rises, snow falls and the layers drift with slow parallax for depth, with a faint iridescent sheen crossing the glass. A brass sill with an engraved plaque and a warm light line.' },
    'BTH-001': { s12: 'b01tile', live: 'Condensation drips', note: 'Old 4 inch white tiles up to a chipped bullnose cap, every one a slightly different white, with grout going grey and then black-green with mildew toward the floor. Several tiles are cracked (one crack runs across two), a corner is chipped, one tile is missing down to the combed mortar and one too-blue replacement sits in fresh grout. Two plastic anchors and rust runs show where a towel bar was ripped off. Soap scum, yellowed caulk, and above it all yellowed paint with a water-stain ring, peeling flakes and mildew creeping from the ceiling. Beads of condensation slide down the tiles.' },
    'BTH-021': { s12: 'b21sub', live: 'Glinting glaze', note: 'Glossy mint subway tiles in a running bond, each a slightly different mint with a soft cushion glaze and a crisp bevel, set in clean white grout with one white accent row. A rounded white pencil liner caps them under warm white eggshell paint, with a GFCI outlet and its little green light. Window light reflects in the glaze and a slow glint slides across it.' },
    'BTH-041': { s12: 'b41slate', live: 'Cedar glow', note: 'Large staggered slate slabs from floor to ceiling, each its own blue-grey, with split cleft layers, little step edges, rusty iron blooms and mica glints, darker and damp near the floor, on a matte black steel base. Once, in the middle of the back wall, a red cedar accent wall: vertical tongue-and-groove boards with grain and knots in a black steel frame, washed by a warm cove light that slowly breathes.' },
    'BTH-061': { s12: 'b61tad', live: 'Burnished sheen', note: 'Seamless warm sand tadelakt burnished to a soft waxy stone sheen: cloudy lime tones, curved trowel strokes and polished pinpoints, with scallops of warm light grazing down from above and a sheen that slowly drifts across it. A polished brass inlay line and cap rail sit on a pale golden hinoki wainscot with fine straight grain, over a black basalt skirting with a brass edge.' },
    'BTH-081': { s12: 'b81onyx', live: 'Self-cleaning beads', note: 'Book-matched honey onyx from the brass band to the ceiling: nested wavy growth bands in amber, cream and caramel, milky crystal zones and dark resin veins, lit from behind with a warm glow that breathes. Below, pearl-white nano-ceramic panels on brass hairline seams, where water beads gather and roll off and a clean sheen wipes down after them. Bronze plinth with a champagne light line.' },
    'BTH-005': { f29: 'vinyl', live: 'Leaky drip', note: 'Tired red and cream vinyl squares flecked like cheap sheet vinyl, the grout gone grey and dark toward the walls, mildew blooming from the back corner. Three corners curl up off the yellow glue, one square is missing down to the paper backing, and a yellowed ring with two rusty bolt caps shows where the old toilet stood. A rust ring from a can, soap scum, hair, a worn path and heel scuffs; a slow leak drips into a little puddle at the back.' },
    'BTH-025': { f29: 'hex', live: 'Drifting daylight', note: 'Small matte white hexagon porcelain tiles, each softly bevelled, in grey grout that darkens toward the tub, with a black border band and little black hex flowers. A few chips, one replaced tile a shade too white, splash spots by the tub and a round chrome drain with a thin film of water. Soft daylight drifts slowly across.' },
    'BTH-045': { f29: 'pebble', live: 'Dripping duckboard', note: 'A packed mosaic of smooth, rounded river pebbles in grey, cream, slate and rust, set in dark wet grout, with an oiled teak duckboard of slats on battens and little brass screws over the middle. Water beads glint between the stones and a drip runs off the front slat.' },
    'BTH-065': { f29: 'basalt', live: 'Heated stone', note: 'Big honed black basalt slabs, each a slightly different black, with a flamed grain, pores and pale mineral flecks, crossed by two long polished brass slot drains with a glint running along them. A film of water near the shower drain reflects warm light with slow ripples, condensation beads sit on the stone, and the heated floor breathes a warm glow as wisps of steam lift off it.' },
    'BTH-085': { f29: 'hydro', live: 'Hydro-massage jets', note: 'Warm white quartz slabs with soft grey and gold veins, polished brass seams with travelling glints and brass diamond keystones, framing a big walk-on glass panel in a brass bezel. Under the glass, warm-lit water: hydro-massage jets send up ribbons of bubbles while golden caustic light ripples across the basin. Steam curls up at the glass edge and the heated stone breathes a warm glow.' },
    'BTH-014': { spec: 'mat29a', live: 'Drying footprints', note: 'A faded blue terry bath mat gone thin and lumpy: bald patches showing the backing, a dark soggy middle, pink mildew dots, hair and lint, a little hole and a frayed fringe at both ends with a loose thread. Wet footprints soak in and slowly fade.' },
    'BTH-034': { spec: 'mat29b', live: 'Squishy pebble', note: 'A big oval rug in plush sage microfiber, moulded into puffy memory-foam pebbles of different sizes with soft grooves between them, a velvety sheen that drifts and a bound edge. Now and then one pebble squishes in and springs back as if someone just stepped on it.' },
    'BTH-054': { spec: 'mat29c', live: 'Quick-dry footprints', note: 'A thin pale-grey diatomaceous earth stone mat with a fine sandy speckle, a soft bevel, a faint pressed wave pattern and a little embossed leaf, sitting on a cork pad. A pair of wet footprints appears dark and dries away in seconds.' },
    'BTH-074': { spec: 'mat29d', live: 'Glint on the teak', note: 'A long runner of oiled golden Burmese teak slats on a teak frame with polished brass corner caps, its three middle panels inset with deep plush ivory Egyptian cotton framed by a fine gold line, with a little monogram. A warm glint slides along the oiled teak and the cotton pile sheen drifts.' },
    'BTH-094': { spec: 'mat29e', live: 'Self-drying moss', note: 'A living oval carpet of preserved cushion moss in many greens: plump bun-moss mounds, fine sheet moss, tiny fern fronds and white star flowers, framed by a wide ivory silk border with a champagne-gold key pattern and a gold edge. A warm glow breathes underneath; dew twinkles on the moss and lifts away as faint wisps of steam.' },
  };
  const edit28 = RD.edit;
  RD.edit = rows => edit28(rows).map(r => RD.SET29[r.id] ? Object.assign({}, r, RD.SET29[r.id]) : r);
  RD.H29 = { FLOOR29, hexW, ripple, glint, steamF, DEF29, RUG, foot };
  RD.PLUS29 = 1;
})();
