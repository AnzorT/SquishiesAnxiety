export const CREATURES = [
  { id: 0, name: "Glorp", desc: "A drippy jelly pal who loves gentle squeezes.", defaultUnlocked: true },
  { id: 1, name: "Puffle", desc: "Fluffiest ball of static-charged joy.", defaultUnlocked: true },
  { id: 2, name: "Nubbin", desc: "Small horns, big giggles when squashed.", defaultUnlocked: true },
  { id: 3, name: "Dotty", desc: "Polka-dotted egg with a bubbly laugh.", defaultUnlocked: false, keyPrice: 600 },
  { id: 4, name: "Spike", desc: "Spiky on the outside, squish on the inside.", defaultUnlocked: false, keyPrice: 750 },
  { id: 5, name: "Stellie", desc: "A little star that sparkles when pressed.", defaultUnlocked: false, keyPrice: 900 },
  { id: 6, name: "Puffington", desc: "A cloud creature with a sleepy squeak.", defaultUnlocked: false, keyPrice: 1100 },
  { id: 7, name: "Noodle", desc: "Wobbly tentacles, world-class ASMR sounds.", defaultUnlocked: false, keyPrice: 1300 },
  { id: 8, name: "Glimmer", desc: "Crystal-faceted and impossibly shiny.", defaultUnlocked: false, keyPrice: 1600 },
  { id: 9, name: "Ember", desc: "Warm, glowing, and secretly ticklish.", defaultUnlocked: false, keyPrice: 2000 },
];

export const ACHIEVEMENTS = [
  { id: "unlock3", title: "Egg-cellent!", desc: "Unlock Dotty", icon: "🥚" },
  { id: "unlock4", title: "Spiky Squish", desc: "Unlock Spike", icon: "🌵" },
  { id: "unlock5", title: "Star Struck", desc: "Unlock Stellie", icon: "⭐" },
  { id: "unlock6", title: "Head in Clouds", desc: "Unlock Puffington", icon: "☁️" },
  { id: "unlock7", title: "Noodle Master", desc: "Unlock Noodle", icon: "🍜" },
  { id: "earn10k", title: "Pocket Change", desc: "Earn 10,000 Squish Points", icon: "💰" },
  { id: "earn100k", title: "Squish Tycoon", desc: "Earn 100,000 Squish Points", icon: "🏆" },
  { id: "unlockAll", title: "Collector Supreme", desc: "Unlock all 10 creatures", icon: "👑" },
  { id: "speedTap", title: "Speed Squisher", desc: "Tap 60 times in 1 minute", icon: "⚡" },
  { id: "watchAd", title: "Ad Enthusiast", desc: "Watch a video ad", icon: "📺" },
];
