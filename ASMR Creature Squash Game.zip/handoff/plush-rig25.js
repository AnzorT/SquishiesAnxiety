// Squish Squad 2.5D rig: one soft body. Parts are skinned to the body (their roots never move), the face slides on the head, light stays put.
// Rig25.mount(hostEl, key) -> { play(action), destroy() }. Actions: idle, look, hop, dance, squish.
(function () {
  if (window.Rig25 && window.Rig25.v >= 3) return;
  const NS = 'http://www.w3.org/2000/svg';
  const cache = {};
  const load = k => cache[k] || (cache[k] = fetch('export/tripo/' + k + '/' + k + '-front.svg').then(r => r.text()).then(t => t.replace(/<metadata>[\s\S]*?<\/metadata>/, '')));
  const num = (e, a) => parseFloat(e.getAttribute(a) || '0');
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const r2 = n => Math.round(n * 100) / 100;
  const D2R = Math.PI / 180;
  let UID = 0;

  function parsePath(d) {
    const tk = d.match(/[a-zA-Z]|-?\d*\.?\d+(?:e-?\d+)?/g) || []; let i = 0, cmd = '', x = 0, y = 0, sx = 0, sy = 0; const out = []; const n = () => +tk[i++];
    while (i < tk.length) {
      if (/[a-zA-Z]/.test(tk[i])) cmd = tk[i++];
      const C = cmd.toUpperCase(), rel = cmd !== C, ox = rel ? x : 0, oy = rel ? y : 0;
      if (C === 'Z') { out.push({ c: 'Z' }); x = sx; y = sy; continue; }
      if (C === 'M' || C === 'L' || C === 'T') { const p = [ox + n(), oy + n()]; out.push({ c: C, p: [p] }); [x, y] = p; if (C === 'M') { sx = x; sy = y; cmd = rel ? 'l' : 'L'; } }
      else if (C === 'H') { x = ox + n(); out.push({ c: 'L', p: [[x, y]] }); }
      else if (C === 'V') { y = oy + n(); out.push({ c: 'L', p: [[x, y]] }); }
      else if (C === 'Q' || C === 'S') { const a = [ox + n(), oy + n()], b = [ox + n(), oy + n()]; out.push({ c: C, p: [a, b] }); [x, y] = b; }
      else if (C === 'C') { const a = [ox + n(), oy + n()], b = [ox + n(), oy + n()], c = [ox + n(), oy + n()]; out.push({ c: 'C', p: [a, b, c] }); [x, y] = c; }
      else if (C === 'A') { const r = [n(), n(), n(), n(), n()]; const e = [ox + n(), oy + n()]; out.push({ c: 'A', r, p: [e] }); [x, y] = e; }
      else i++;
    }
    return out;
  }
  const pts = segs => segs.flatMap(g => g.p || []);
  function pathStr(segs, F, J) {
    let s = '', i = 0;
    for (const g of segs) {
      if (g.c === 'Z') { s += 'Z'; continue; }
      if (g.c === 'A') { const p = g.p[0], [x, y] = F(p[0], p[1], i++), k = J(p[1]); s += 'A' + r2(g.r[0] * k[0]) + ' ' + r2(g.r[1] * k[1]) + ' ' + g.r[2] + ' ' + g.r[3] + ' ' + g.r[4] + ' ' + r2(x) + ' ' + r2(y); continue; }
      s += g.c; for (const p of g.p) { const [x, y] = F(p[0], p[1], i++); s += r2(x) + ' ' + r2(y) + ' '; }
    }
    return s;
  }
  // ellipse -> 8 cubic segments (smooth enough to bend)
  function ellD(cx, cy, rx, ry, rot) {
    const k = 4 / 3 * Math.tan(Math.PI / 16), c = Math.cos(rot * D2R), s = Math.sin(rot * D2R);
    const P = (x, y) => r2(cx + x * c - y * s) + ' ' + r2(cy + x * s + y * c);
    let d = 'M' + P(rx, 0);
    for (let i = 0; i < 8; i++) { const a0 = i * Math.PI / 4, a1 = a0 + Math.PI / 4;
      const p0 = [rx * Math.cos(a0), ry * Math.sin(a0)], p1 = [rx * Math.cos(a1), ry * Math.sin(a1)], d0 = [-rx * Math.sin(a0), ry * Math.cos(a0)], d1 = [-rx * Math.sin(a1), ry * Math.cos(a1)];
      d += ' C' + P(p0[0] + k * d0[0], p0[1] + k * d0[1]) + ' ' + P(p1[0] - k * d1[0], p1[1] - k * d1[1]) + ' ' + P(p1[0], p1[1]); }
    return d + 'Z';
  }
  class Sp {
    constructor(v = 0, k = 170, d = 14) { this.v = v; this.t = v; this.vel = 0; this.k = k; this.d = d; }
    set(t, k, d) { this.t = t; if (k) this.k = k; if (d != null) this.d = d; }
    step(dt) { const a = (this.t - this.v) * this.k - this.vel * this.d; this.vel += a * dt; this.v += this.vel * dt; return this.v; }
  }

  const ALL = new Set(); let raf = 0, last = 0;
  function loop(now) {
    raf = ALL.size ? requestAnimationFrame(loop) : 0;
    const dt = clamp((now - (last || now - 16)) / 1000, 0.001, 1 / 30); last = now;
    ALL.forEach(I => { if (I.ready) { try { for (let s = 0; s < 2; s++) step(I, now, dt / 2); draw(I, now); } catch (e) { if (!I._err) { I._err = 1; console.error('Rig25', I.key, e); } } } });
  }
  const kick = () => { if (!raf) { last = 0; raf = requestAnimationFrame(loop); } };
  setInterval(() => { const n = performance.now(); if (ALL.size && n - last > 70) { const r = raf; raf = 0; if (r) cancelAnimationFrame(r); loop(n); } }, 40);

  function toPath(q) {
    const e = q.e, p = document.createElementNS(NS, 'path');
    for (const a of e.attributes) if (!/^(cx|cy|r|rx|ry|transform)$/.test(a.name)) p.setAttribute(a.name, a.value);
    p.setAttribute('d', ellD(q.ox, q.oy, q.rx, q.ry, q.rot || 0)); e.parentNode.replaceChild(p, e);
    q.e = p; q.tag = 'path'; q.tr = ''; q.rot = null; q.segs = parsePath(p.getAttribute('d'));
  }

  function setup(I, svg, n) {
    const bodyG = svg.querySelector('g[filter]'); let BB = null; try { BB = bodyG.getBBox(); } catch (e) {}
    if (!BB || BB.width < 5) { if (n < 40) setTimeout(() => setup(I, svg, n + 1), 120); return; }
    const v2 = (window.CREATURES_V2 || []).find(c => c.name.toLowerCase() === I.key);
    const eyes = [...svg.querySelectorAll('[fill^="url(#ey"]')];
    const eyeY = v2 ? v2.eyes[0].y : (eyes.length ? num(eyes[0], 'cy') : 50);
    const area = BB.width * BB.height; I.G = BB.y + BB.height; I.top = BB.y; I.bb = BB;
    const eyeMap = new Map(); eyes.forEach(e => { const info = { ex: num(e, 'cx'), ey: num(e, 'cy'), side: num(e, 'cx') < 50 ? -1 : 1 }; eyeMap.set(e, { ...info, hl: false }); let s = e.nextElementSibling; for (let j = 0; j < 2 && s; j++, s = s.nextElementSibling) if ((s.getAttribute('fill') || '') === '#fff') eyeMap.set(s, { ...info, hl: true }); });
    const items = [];
    svg.querySelectorAll('path,ellipse,circle,rect').forEach(e => {
      const inClip = !!e.closest('clipPath'); if (e.closest('defs') && !inClip) return;
      const tag = e.tagName.toLowerCase(), fill = e.getAttribute('fill') || '', inBody = !!e.closest('g[filter]'), tr = e.getAttribute('transform') || '';
      const rm = tr.match(/rotate\(([-\d.]+)/); let b; try { b = e.getBBox(); } catch (x) { b = { x: 0, y: 0, width: 0, height: 0 }; }
      const it = { e, tag, tr, inBody, rot: rm ? +rm[1] : null, cx: b.x + b.width / 2, cy: b.y + b.height / 2, b, a: b.width * b.height, op: e.getAttribute('opacity'), fill };
      if (tag === 'path') it.segs = parsePath(e.getAttribute('d') || '');
      if (tag === 'circle' || tag === 'ellipse') { it.ox = num(e, 'cx'); it.oy = num(e, 'cy'); it.rx = tag === 'circle' ? num(e, 'r') : num(e, 'rx'); it.ry = tag === 'circle' ? it.rx : num(e, 'ry'); it.cx = it.ox; it.cy = it.oy; }
      if (tag === 'rect') { it.x = num(e, 'x'); it.y = num(e, 'y'); it.w = num(e, 'width'); it.h = num(e, 'height'); }
      if (inClip) it.role = 'body';
      else if (eyeMap.has(e)) { Object.assign(it, eyeMap.get(e)); it.role = 'eye'; }
      else if (e.getAttribute('stroke') === '#6a3a3a') it.role = 'mouth';
      else if (tag === 'ellipse' && /^#ff8fa3/i.test(fill)) { it.role = 'cheek'; it.side = it.ox < 50 ? -1 : 1; }
      else if (!inBody && tag === 'ellipse' && fill.indexOf('#fff') === 0 && it.op) it.role = 'shine';
      else if (inBody && tag === 'ellipse' && it.rot != null && fill.indexOf('#fff') !== 0 && !it.op) { it.role = 'arm'; it.side = it.ox < 50 ? -1 : 1; const a = it.rot * D2R; it.hx = it.ox - Math.sin(a) * it.ry; it.hy = it.oy + Math.cos(a) * it.ry; }
      else if (inBody && tag === 'ellipse' && it.rot == null && it.oy >= 84 && it.oy <= 93 && it.rx >= 4) it.role = 'foot';
      else if (it.cy < eyeY - 12 && it.a < area * 0.22 && !(!inBody && Math.abs(it.cx - 50) < 4)) { it.role = 'top'; it.side = Math.abs(it.cx - 50) < 4 ? 0 : (it.cx < 50 ? -1 : 1); }
      else if (inBody && it.cy > eyeY - 4 && (it.cx < BB.x + BB.width * 0.2 || it.cx > BB.x + BB.width * 0.8) && it.a < area * 0.12) { it.role = 'side'; it.side = it.cx < 50 ? -1 : 1; }
      else it.role = inBody || inClip ? 'body' : 'face';
      items.push(it);
    });
    // hands that sit on an arm's end belong to that arm
    items.filter(q => q.role === 'arm').forEach(a => items.forEach(q => { if (q.role === 'body' && q.tag === 'circle' && Math.hypot(q.ox - a.hx, q.oy - a.hy) < 7) { q.role = 'arm'; q.owner = a; q.side = a.side; } }));
    // body anchors: the big soft shapes everything is attached to
    const anchors = items.filter(q => q.role === 'body' && q.inBody && q.fill !== 'none' && q.a > area * 0.14).map(q => ({ q, cx: q.cx, cy: q.cy, hx: q.b.width / 2, hy: q.b.height / 2, a: q.a }));
    const dn = (x, y) => anchors.reduce((m, A) => Math.min(m, Math.hypot((x - A.cx) / A.hx, (y - A.cy) / A.hy)), 9);
    const ex = eyes.length ? eyes.reduce((s, e) => s + num(e, 'cx'), 0) / eyes.length : 50;
    const headA = anchors.filter(A => Math.hypot((ex - A.cx) / A.hx, (eyeY - A.cy) / A.hy) < 1).sort((a, b) => a.a - b.a)[0];
    // painted-on details inside the head slide with the face when it turns
    if (headA) items.forEach(q => { if (q.role !== 'body' || !q.inBody || anchors.some(A => A.q === q) || q.a < 1) return; const b = q.b;
      const ins = [[b.x, b.y], [b.x + b.width, b.y], [b.x, b.y + b.height], [b.x + b.width, b.y + b.height]].every(([x, y]) => Math.hypot((x - headA.cx) / headA.hx, (y - headA.cy) / headA.hy) < 1.02);
      if (ins) q.role = 'patch'; });
    // parts become paths so they can bend; their roots stay buried in the body
    items.forEach(q => { if ((q.role === 'arm' || q.role === 'top' || q.role === 'side') && (q.tag === 'ellipse' || q.tag === 'circle')) toPath(q); });
    [-1, 0, 1].forEach(sd => { const tops = items.filter(q => q.role === 'top' && q.side === sd && !q.owner); if (!tops.length) return; const big = tops.reduce((m, q) => q.a > m.a ? q : m);
      tops.forEach(q => { if (q !== big && (sd !== 0 || Math.hypot(q.cx - big.cx, q.cy - big.cy) < 14) && Math.hypot(q.cx - big.cx, q.cy - big.cy) < 26) q.owner = big; }); });
    const skin = q => { const P = pts(q.segs), d = P.map(p => dn(p[0], p[1])); const inside = P.filter((p, i) => d[i] < 1);
      let R; if (inside.length) R = inside.reduce((s, p) => [s[0] + p[0] / inside.length, s[1] + p[1] / inside.length], [0, 0]); else { let m = 0; d.forEach((v, i) => { if (v < d[m]) m = i; }); R = P[m]; }
      q.R = R; q.L = Math.max(1, ...P.map(p => Math.hypot(p[0] - R[0], p[1] - R[1]))); };
    items.forEach(q => { if (['arm', 'top', 'side'].includes(q.role) && !q.owner && q.segs) { skin(q); q.sp = new Sp(0, q.role === 'side' ? 80 : 125, q.role === 'side' ? 7 : 9); } });
    items.forEach(q => { if (!['arm', 'top', 'side'].includes(q.role) || !q.segs) return; const o = q.owner || q; if (!o.R) { skin(o); o.sp = o.sp || new Sp(0, 125, 9); }
      if (q.role === 'top') { if (o.dnMax == null) o.dnMax = Math.max(1.05, ...pts(o.segs).map(p => dn(p[0], p[1]))); const span = o.dnMax - 1;
        q.wt = pts(q.segs).map(p => Math.pow(clamp((dn(p[0], p[1]) - 1) / span, 0, 1), 1.7)); return; }
      q.wt = pts(q.segs).map(p => { const wo = clamp((dn(p[0], p[1]) - 1) / 0.25, 0, 1), wd = Math.pow(clamp(Math.hypot(p[0] - o.R[0], p[1] - o.R[1]) / o.L, 0, 1), 1.2); return wo * wd; }); });
    items.forEach(q => { if (q.role === 'top' && q.sp) { q.sp.k = 260; q.sp.d = 22; } });
    const main = anchors.slice().sort((a, b) => b.a - a.a)[0];
    if (main && /url\(#/.test(main.q.fill)) { const id = main.q.fill.match(/url\(#([^)]+)\)/)[1]; const src = svg.querySelector('[id="' + id + '"]');
      if (src && src.tagName.toLowerCase() === 'radialgradient') { const gc = src.cloneNode(true); gc.id = id + 'W'; gc.setAttribute('gradientUnits', 'userSpaceOnUse'); const b = main.q.b; I.gb = { cx: b.x + 0.38 * b.width, cy: b.y + 0.3 * b.height, r: 0.75 * (b.width + b.height) / 2 };
        gc.setAttribute('r', r2(I.gb.r)); src.parentNode.appendChild(gc); main.q.e.setAttribute('fill', 'url(#' + gc.id + ')'); I.gEl = gc; } }
    I.headBot = headA ? headA.cy + headA.hy * 0.7 : I.top + (I.G - I.top) * 0.55;
    I.items = items; I.eyeY = eyeY; extras(I, svg); I.ready = true;
  }

  const TAU = Math.PI * 2;
  const SM = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
  const env = (t, a, b, c, d) => t < a ? 0 : t < b ? SM((t - a) / (b - a)) : t < c ? 1 : t < d ? 1 - SM((t - c) / (d - c)) : 0;
  const bump = (t, a, b) => t < a || t > b ? 0 : Math.sin(Math.PI * (t - a) / (b - a));
  const once = (I, k) => !I.f[k] && (I.f[k] = true);
  const jump = (I, vy) => { if (I.air) return; I.air = true; I.vy = vy; I.S.sq.set(-0.05, 240, 14); I.S.sq.vel -= 3.5; };
  const star4 = (x, y, r) => 'M' + r2(x) + ' ' + r2(y - r) + ' Q' + r2(x) + ' ' + r2(y) + ' ' + r2(x + r) + ' ' + r2(y) + ' Q' + r2(x) + ' ' + r2(y) + ' ' + r2(x) + ' ' + r2(y + r) + ' Q' + r2(x) + ' ' + r2(y) + ' ' + r2(x - r) + ' ' + r2(y) + ' Q' + r2(x) + ' ' + r2(y) + ' ' + r2(x) + ' ' + r2(y - r) + 'Z';
  const heart = (x, y, s, op) => '<path transform="translate(' + r2(x) + ' ' + r2(y) + ') scale(' + r2(s) + ')" d="M0 2.6 C-4.6 -0.6 -3.4 -5.6 0 -3 C3.4 -5.6 4.6 -0.6 0 2.6Z" fill="#ff5c9e" stroke="#ffffff" stroke-width="0.5" opacity="' + r2(op) + '"/>';
  const sparks = (cx, cy, t, n, R, col) => { let h = ''; for (let i = 0; i < n; i++) { const a = i / n * TAU + i * 0.7, u = ((t / 900) + i / n) % 1, r = R * (0.55 + 0.45 * u); h += '<path d="' + star4(cx + Math.cos(a) * r, cy + Math.sin(a) * r * 0.8, 1.2 + 2.2 * Math.sin(Math.PI * u)) + '" fill="' + (col || (i % 2 ? '#fff3a0' : '#ffffff')) + '" opacity="' + r2(Math.sin(Math.PI * u)) + '"/>'; } return h; };

  // ---------- the 26 animations ----------
  const IDLE = (I, t, now, S) => { if (!I.press) S.sq.set(0.02 * Math.sin(now / 2800 * TAU), 120, 14); S.lean.set(1.2 * Math.sin(now / 4300 * TAU) + 0.5 * Math.sin(now / 1700 * TAU + 1), 60, 12); S.turn.set(S.lx.t * (I.ptr || I.fake ? 0.65 : 0.5), 55, 11); };
  const HOPS = (I, t, S, list) => list.forEach(([at, vy], i) => { if (t > at - 170 && once(I, 'c' + i)) S.sq.set(0.2, 380, 20); if (t > at && once(I, 'j' + i)) { jump(I, vy); } });
  const A = {
    idle: { run: IDLE },
    blink: { dur: 5000, run(I, t, now, S) { [[0, 1], [1500, 1], [3000, 0], [4200, 1]].forEach(([at, d], i) => { if (t >= at && once(I, 'b' + i)) { I.blinkT = now; I.dbl = !!d; I.blinkAt = now + 9000; } }); IDLE(I, t, now, S); } },
    look: { dur: 5600, run(I, t, now, S) {
      const K = [[0, 0, 0], [260, -1, 0], [1250, -1, 0], [1450, 1, 0], [2450, 1, 0], [2650, 0, -0.9], [3600, 0, 0.7], [4500, 0, 0]]; let k = 0; for (let i = 0; i < K.length; i++) if (t >= K[i][0]) k = i;
      if (k !== I.kf) { I.kf = k; S.sq.vel += 1.4; if (k === 3) I.blinkT = now; }
      S.turn.set(K[k][1], 75, 12); S.lx.set(K[k][1] * 0.95, 360, 28); S.ly.set(K[k][2], 300, 26); S.lean.set(K[k][1] * 1.2, 70, 12); S.sq.set(0, 160, 14); } },
    watch: { dur: 5200, run(I, t, now, S) { const a = t / 5200 * TAU * 2; I.fake = { x: Math.sin(a) * 0.95, y: Math.cos(a * 0.7) * 0.6 - 0.1 }; IDLE(I, t, now, S); },
      fx(I, t) { const p = I.fake || { x: 0, y: 0 }; return '<circle cx="' + r2(50 + p.x * 46) + '" cy="' + r2(50 + p.y * 46) + '" r="3.2" fill="#ffffff" stroke="#ff4fbf" stroke-width="1.2" opacity="0.9"/>'; }, end(I) { I.fake = null; } },
    squish: { dur: 1400, run(I, t, now, S) { if (once(I, 'p')) press(I, now); if (t > 700 && I.press) release(I, now); IDLE(I, t, now, S); } },
    release: { dur: 1300, run(I, t, now, S) { if (once(I, 'p')) press(I, now); if (t > 260 && I.press) release(I, now); IDLE(I, t, now, S); } },
    poke: { dur: 5200, run(I, t, now, S) { const c = Math.floor(t / 1300), P = [[36, I.eyeY + 4], [70, I.eyeY + 20], [50, I.G - 14], [44, I.top + 16]][c % 4]; if (once(I, 'p' + c)) poke(I, P[0], P[1], now); IDLE(I, t, now, S); } },
    hold: { dur: 5200, run(I, t, now, S) { if (once(I, 'p')) press(I, now); if (t > 4300 && I.press) release(I, now); IDLE(I, t, now, S); } },
    spin: { dur: 2400, run(I, t, now, S) { if (once(I, 's')) S.spin.set(S.spin.t + 360, 11, 6.2); S.lean.set(3 * Math.sin(t / 2400 * TAU), 80, 12); S.sq.set(0.03, 160, 14); } },
    happy: { dur: 2100, run(I, t, now, S) { HOPS(I, t, S, [[170, -118], [980, -100]]); S.happy.set(1, 300, 26); S.mouthO.set(0.5, 200, 20); S.armL.set(42, 240, 14); S.armR.set(42, 240, 14); S.ear.set(6, 240, 12); S.lean.set(0, 100, 12); S.turn.set(0, 80, 12); S.lx.set(0); S.ly.set(-0.3); } },
    sad: { dur: 5200, run(I, t, now, S) { S.droop.set(1, 70, 14); S.frown.set(1, 120, 16); S.lid.set(0.45, 90, 14); S.sq.set(0.07, 70, 14); S.ly.set(0.75, 120, 16); S.lx.set(-0.2, 120, 16); S.turn.set(-0.15, 50, 12); S.lean.set(0, 60, 12); S.tilt.set(3 + 1.2 * Math.sin(t / 900), 60, 12); S.armL.set(-6); S.armR.set(-6); if (t > 1500 && once(I, 'b')) { I.blinkT = now; } },
      fx(I, t) { const u = clamp((t - 700) / 3600, 0, 1); if (u <= 0 || u >= 1) return ''; const e = I.eyeW[0]; return '<path transform="translate(' + r2(e[0] - 1) + ' ' + r2(e[1] + 4 + u * 9) + ') scale(' + r2(0.9 + u * 0.3) + ')" d="M0 -2.4 Q1.8 0.4 0 1.6 Q-1.8 0.4 0 -2.4Z" fill="#8fd3ff" stroke="#ffffff" stroke-width="0.4" opacity="' + r2(Math.sin(Math.PI * u)) + '"/>'; } },
    sleep: { dur: 7800, run(I, t, now, S) {
      if (t < 1500) { S.mouthO.set(env(t, 250, 700, 1050, 1450), 200, 22); S.lid.set(0.5, 120, 16); S.sq.set(-0.07 * env(t, 150, 600, 1000, 1400), 120, 14); S.armL.set(38 * env(t, 150, 600, 1000, 1400), 160, 14); S.armR.set(38 * env(t, 150, 600, 1000, 1400), 160, 14); S.ear.set(-6 * env(t, 150, 600, 1000, 1400)); }
      else if (t < 7100) { S.lid.set(1, 60, 14); S.sq.set(0.03 + 0.045 * Math.sin((t - 1500) / 2600 * TAU), 60, 12); S.tilt.set(5, 40, 12); S.lean.set(1.5, 40, 12); S.droop.set(0.4, 40, 12); S.ly.set(0.3); }
      else { S.lid.set(0, 200, 18); if (once(I, 'w')) { S.sq.vel += 3; I.blinkT = now; I.dbl = true; } }
      S.turn.set(0, 50, 12); S.lx.set(0); },
      fx(I, t) { if (t < 1700 || t > 7100) return ''; let h = ''; for (let i = 0; i < 3; i++) { const u = (((t - 1700) / 2400) + i / 3) % 1; const x = I.topW[0] + 16 + u * 14 + Math.sin(u * TAU) * 2, y = I.topW[1] + 6 - u * 22; h += '<text x="' + r2(x) + '" y="' + r2(y) + '" font-family="Fredoka,sans-serif" font-weight="700" font-size="' + r2(5 + u * 5) + '" fill="#8f3cf2" stroke="#ffffff" stroke-width="0.6" paint-order="stroke" opacity="' + r2(Math.sin(Math.PI * u)) + '">z</text>'; } return h; } },
    love: { dur: 5600, run(I, t, now, S) { S.tilt.set(6 * Math.sin(t / 1600 * TAU), 90, 12); S.lean.set(3 * Math.sin(t / 1600 * TAU + 0.6), 90, 12); S.lid.set(0.55, 120, 16); S.happy.set(0.25); S.blush = 1; S.sq.set(0.03 + 0.02 * Math.sin(t / 800 * TAU), 120, 14); S.armL.set(14); S.armR.set(14); S.turn.set(0.3 * Math.sin(t / 1600 * TAU), 60, 12); S.lx.set(0); S.ly.set(0); },
      fx(I, t) { let h = ''; for (let i = 0; i < 5; i++) { const u = ((t / 1700) + i / 5) % 1; if (t < i * 300) continue; h += heart(I.topW[0] - 20 + i * 10 + Math.sin(u * TAU + i) * 3, I.topW[1] + 14 - u * 30, 0.8 + u * 0.6, Math.sin(Math.PI * u)); } return h; } },
    surprised: { dur: 5000, run(I, t, now, S) { if (once(I, 'j')) { jump(I, -75); S.lean.vel -= 40; } if (t > 3700 && once(I, 'j2')) { jump(I, -55); S.lean.vel += 30; } const on = t < 1000 || (t > 3700 && t < 4300) ? 1 : 0;
      if (!on && t > 1100 && t < 3700) { const g = Math.sin(t / 420) > 0 ? 1 : -1; S.lx.set(g * 0.85, 500, 32); S.turn.set(g * 0.4, 90, 12); S.frown.set(0.35); S.wide.set(0.3); S.armL.set(14); S.armR.set(14); return; } S.wide.set(on, 500, 22); S.mouthO.set(on * 0.7, 400, 22); S.lean.set(on * -4, 160, 12); S.tilt.set(on * -6, 160, 12); S.ear.set(on * -8, 300, 14); S.armL.set(on * 30); S.armR.set(on * 30); S.lx.set(0, 400, 30); S.ly.set(-0.2, 400, 30); S.turn.set(0, 120, 12); } },
    eat: { dur: 3000, run(I, t, now, S) {
      const ch = [520, 860, 1200]; let m = env(t, 250, 420, 470, 540); ch.forEach((c, i) => { m = Math.max(m, bump(t, c - 120, c + 60) * 0.55); if (t > c && once(I, 'k' + i)) S.sq.vel += 2.6; });
      S.mouthO.set(m, 500, 26); S.puff.set(t > 500 && t < 1550 ? 1 : 0, 220, 16);
      if (t > 1550 && once(I, 'g')) { S.sq.vel += 3.5; } S.wide.set(bump(t, 1500, 1800) * 0.6, 400, 24);
      if (t > 1800) { S.tilt.set(7 * Math.sin(t / 320 * TAU) * (1 - clamp((t - 2500) / 400, 0, 1)), 240, 14); S.happy.set(1); S.mouthO.set(0.3); }
      S.lx.set(t < 500 ? 0.6 : 0, 400, 30); S.ly.set(t < 500 ? -0.6 : 0, 400, 30); S.turn.set(t < 500 ? 0.3 : 0, 90, 12); S.armL.set(t > 400 && t < 1500 ? 18 : 0); S.armR.set(t > 400 && t < 1500 ? 18 : 0); },
      fx(I, t) { if (t > 1300) return ''; const m = I.mouthW, u = SM(clamp(t / 430, 0, 1)); const x = 94 + (m[0] - 94) * u, y = 6 + (m[1] - 1 - 6) * u - Math.sin(Math.PI * u) * 10; const sc = t < 520 ? 1 : t < 860 ? 0.72 : t < 1200 ? 0.45 : 0;
        if (sc <= 0) return ''; let h = '<g transform="translate(' + r2(x) + ' ' + r2(y) + ') scale(' + r2(sc) + ') rotate(' + r2(-20 * (1 - u)) + ')"><path d="M-7 0 Q-2 -5 4 0 Q-2 5 -7 0Z" fill="#ff9a5a" stroke="#ffffff" stroke-width="0.6"/><path d="M4 0 L8 -4 L8 4Z" fill="#ff9a5a" stroke="#ffffff" stroke-width="0.6"/><circle cx="-4" cy="-1" r="0.9" fill="#2a1a30"/></g>';
        [520, 860, 1200].forEach((c, i) => { const v = (t - c) / 350; if (v > 0 && v < 1) for (let k = 0; k < 3; k++) h += '<circle cx="' + r2(m[0] + (k - 1) * 4 * v + i) + '" cy="' + r2(m[1] + 2 + v * 8 + k) + '" r="0.8" fill="#ffb07a" opacity="' + r2(1 - v) + '"/>'; }); return h; } },
    bath: { dur: 5200, run(I, t, now, S) {
      const inTub = t > 150 && t < 3400; I.clip = t > 100 && t < 3500 ? 'bath' : false; S.rise.set(inTub ? 13 + 1.4 * Math.sin(t / 520 * TAU) : 0, 120, 13); S.tilt.set(inTub ? 4 * Math.sin(t / 700 * TAU) : 0, 120, 12); S.happy.set(inTub ? 0.6 : 0);
      if (t > 600 && t < 3100) { S.armL.set(22 + 20 * Math.sin(t / 250 * TAU), 300, 14); S.armR.set(22 + 20 * Math.sin(t / 250 * TAU + Math.PI), 300, 14); }
      if (t > 3600 && t < 4700) { const d = 1 - (t - 3600) / 1100; S.shake = 3.2 * d; S.ear.set(10 * Math.sin(t / 55) * d, 600, 20); } else S.shake = 0;
      S.lx.set(0); S.ly.set(0); S.turn.set(0, 80, 12); },
      fx(I, t) { let h = ''; const a = env(t, 0, 200, 3300, 3550); if (a > 0) { const y = 74 + (1 - a) * 30; h += '<g opacity="' + r2(a) + '">';
          for (let i = 0; i < 6; i++) { const u = ((t / 1100) + i / 6) % 1; h += '<circle cx="' + r2(22 + i * 11 + Math.sin(u * 6 + i) * 2) + '" cy="' + r2(y - 2 - u * 26) + '" r="' + r2(1.4 + u * 1.6) + '" fill="rgba(220,245,255,0.7)" stroke="#ffffff" stroke-width="0.5"/>'; }
          h += '<path d="M10 ' + r2(y) + ' H90 Q90 ' + r2(y + 22) + ' 70 ' + r2(y + 24) + ' H30 Q10 ' + r2(y + 22) + ' 10 ' + r2(y) + 'Z" fill="#ffffff" stroke="#8fd3ff" stroke-width="1.4"/><rect x="8" y="' + r2(y - 2) + '" width="84" height="5" rx="2.5" fill="#bfe8ff" stroke="#8fd3ff" stroke-width="0.8"/>';
          for (let i = 0; i < 7; i++) h += '<circle cx="' + r2(14 + i * 12) + '" cy="' + r2(y - 1 + Math.sin(t / 300 + i) * 0.8) + '" r="' + r2(3.4 + (i % 3)) + '" fill="#ffffff" stroke="#d6f2fc" stroke-width="0.5"/>'; h += '</g>'; }
        if (t > 3600 && t < 4800) { const v = (t - 3600) / 1200; for (let i = 0; i < 10; i++) { const ang = i / 10 * TAU, r = 18 + v * 26; h += '<path transform="translate(' + r2(50 + Math.cos(ang) * r) + ' ' + r2(55 + Math.sin(ang) * r * 0.8 + v * v * 10) + ')" d="M0 -2 Q1.4 0.4 0 1.3 Q-1.4 0.4 0 -2Z" fill="#8fd3ff" opacity="' + r2(1 - v) + '"/>'; } }
        return h; } },
    dirty: { dur: 5200, run(I, t, now, S) {
      I.dirtA = t < 2900 ? SM(t / 250) : 1 - SM((t - 2900) / 500);
      if (t < 2900) { S.frown.set(0.7, 140, 16); S.lid.set(0.3); S.armR.set(44 + 10 * Math.sin(t / 160 * TAU), 300, 14); S.tilt.set(-4, 90, 12); S.lx.set(0.5); S.ly.set(-0.2); S.turn.set(0.3, 60, 12); }
      else { S.happy.set(1); S.mouthO.set(0.35); if (t > 3400 && once(I, 'h')) { S.sq.set(0.18, 380, 20); } if (t > 3570 && once(I, 'hj')) jump(I, -100); if (t > 4300 && once(I, 'h2')) { S.sq.set(0.16, 380, 20); } if (t > 4470 && once(I, 'hj2')) jump(I, -85); S.lx.set(0); S.ly.set(0); S.turn.set(0, 80, 12); } },
      fx(I, t) { let h = ''; if (t < 2900) { for (let i = 0; i < 3; i++) { const u = ((t / 1400) + i / 3) % 1; h += '<path transform="translate(' + r2(I.topW[0] - 14 + i * 14) + ' ' + r2(I.topW[1] + 2 - u * 12) + ')" d="M0 0 q-2 -2.5 0 -5 q2 -2.5 0 -5" stroke="#9ab070" stroke-width="1.4" fill="none" stroke-linecap="round" opacity="' + r2(Math.sin(Math.PI * u) * 0.9) + '"/>'; } }
        if (t > 2850) h += sparks(50, 54, t, 8, 36); return h; } },
    tv: { dur: 5800, run(I, t, now, S) {
      S.sq.set(0.07, 120, 14); S.ly.set(0.15); S.lx.set(0.1 * Math.sin(t / 900)); S.turn.set(0, 60, 12); S.lean.set(-1.5, 60, 12);
      const laugh = (t > 1400 && t < 2300) || (t > 3100 && t < 3900) || (t > 4700 && t < 5500); S.happy.set(laugh ? 1 : 0); S.mouthO.set(laugh ? 0.55 : 0.05); S.tilt.set(laugh ? 3 * Math.sin(t / 70) : 0, 400, 20);
      if (laugh && Math.floor(t / 90) !== I.gk) { I.gk = Math.floor(t / 90); S.sq.vel += (I.gk % 2 ? 1.6 : -1.2); } },
      fx(I, t) { const cols = ['#7cc8ff', '#ff9fcb', '#ffe14a', '#9be38a']; const c = cols[Math.floor(t / 380) % 4]; return '<ellipse cx="50" cy="' + r2(I.G - 30) + '" rx="40" ry="36" fill="' + c + '" opacity="0.13"/>'; } },
    hatch: { dur: 5200, run(I, t, now, S) {
      if (once(I, 'h0')) { S.rise.v = 50; S.rise.vel = 0; I.clip = true; }
      if (t < 540) S.rise.set(50, 400, 30); else { S.rise.set(0, 150, 10); if (once(I, 'pop')) { S.sq.v = -0.14; S.sq.vel = -2; } }
      if (t > 1900) I.clip = false;
      S.sq.set(t > 1000 && t < 1500 ? -0.09 : 0, 160, 12); S.armL.set(t > 1000 && t < 1500 ? 44 : 0); S.armR.set(t > 1000 && t < 4800 ? (t > 1600 ? 40 + 16 * Math.sin(t / 380 * TAU) : 44) : 0, 280, 14); if (t > 3000) { S.lx.set(0.6 * Math.sin(t / 700), 300, 26); S.turn.set(0.3 * Math.sin(t / 700), 80, 12); }
      S.happy.set(t > 1500 ? 0.6 : 0); S.mouthO.set(t > 1600 && t < 4800 ? 0.3 : 0); S.wide.set(bump(t, 560, 1100) * 0.7); if (t <= 3000) { S.lx.set(0); S.ly.set(0); S.turn.set(0, 80, 12); } },
      fx(I, t) { const a = 1 - SM((t - 1600) / 400); if (a <= 0) return ''; const sh = t < 520 ? Math.sin(t / 30) * 1.4 : 0, y = 76 + (1 - a) * 26, lid = SM((t - 500) / 260);
        let h = '<g opacity="' + r2(a) + '" transform="translate(' + r2(sh) + ' 0)">';
        if (lid < 1) { const ly2 = y - lid * 46, lx2 = 14 - lid * 26; h += '<g opacity="' + r2(1 - SM((t - 520) / 260)) + '" transform="translate(' + r2(lx2) + ' ' + r2(ly2) + ') rotate(' + r2(-lid * 70) + ')"><rect x="0" y="-9" width="72" height="11" rx="5" fill="#ffd23a" stroke="#ffffff" stroke-width="1.2"/><rect x="31" y="-9" width="10" height="11" fill="#c02bd9"/></g>'; }
        h += '<rect x="14" y="' + r2(y) + '" width="72" height="26" rx="5" fill="#ffc23a" stroke="#ffffff" stroke-width="1.2"/><rect x="45" y="' + r2(y) + '" width="10" height="26" fill="#c02bd9"/><rect x="44" y="' + r2(y + 3) + '" width="12" height="9" rx="2" fill="#ffe7a0" stroke="#9c4d06" stroke-width="0.8"/></g>';
        if (t > 520 && t < 1700) h += sparks(50, 60, t, 10, 40); return h; } },
    unlock: { dur: 2900, run(I, t, now, S) { HOPS(I, t, S, [[170, -140], [1150, -110]]); S.happy.set(1); S.mouthO.set(0.55); S.armL.set(46, 260, 14); S.armR.set(46, 260, 14); S.ear.set(8); S.lx.set(0); S.ly.set(-0.3); S.turn.set(0, 80, 12); },
      fx(I, t) { let h = ''; const cols = ['#ff5cc6', '#ffd23a', '#7cc8ff', '#9be38a', '#c89bff']; for (let i = 0; i < 22; i++) { const u = clamp((t - (i % 5) * 60) / 2600, 0, 1); if (u <= 0) continue; const x = 6 + (i * 37) % 88 + Math.sin(u * 8 + i) * 4, y = -6 + u * 100 * (0.7 + (i % 4) * 0.12); h += '<rect x="' + r2(x) + '" y="' + r2(y) + '" width="3" height="1.8" rx="0.4" fill="' + cols[i % 5] + '" transform="rotate(' + r2(u * 720 + i * 40) + ' ' + r2(x + 1.5) + ' ' + r2(y + 0.9) + ')" opacity="' + r2(1 - u * u) + '"/>'; } return h; } },
    grow: { dur: 5200, run(I, t, now, S) {
      if (once(I, 'g0')) { S.scale.v = 0.8; S.scale.vel = 0; }
      if (t < 1150) { S.scale.set(0.8, 300, 30); S.tilt.set(8 * Math.sin(t / 150 * TAU) * SM(t / 300), 400, 20); S.sq.set(0.06 * Math.sin(t / 110 * TAU), 400, 20); S.lid.set(0.3); }
      else { S.scale.set(1, 120, 7); if (once(I, 'pop')) { S.sq.v = -0.12; S.sq.vel = -2; } S.happy.set(0.9); S.mouthO.set(0.35); S.armL.set(36); S.armR.set(36); HOPS(I, t, S, [[3000, -95], [3800, -95]]); }
      S.lx.set(0); S.ly.set(0); S.turn.set(0, 80, 12); },
      fx(I, t) { return t > 1100 && t < 4600 ? sparks(50, 55, t, 12, 46) : ''; } },
    dance: { dur: 15100, run: null },
    cheer: { dur: 2900, run(I, t, now, S) { HOPS(I, t, S, [[170, -112], [900, -112]]); S.happy.set(1); S.mouthO.set(0.6); S.armL.set(48 + 6 * Math.sin(t / 140 * TAU), 300, 14); S.armR.set(48 + 6 * Math.sin(t / 140 * TAU + 1), 300, 14); S.ear.set(8); S.lx.set(0); S.ly.set(-0.3); S.turn.set(0, 80, 12); },
      fx(I, t) { return sparks(50, 46, t, 10, 44, null); } },
    hop: { dur: 1900, run(I, t, now, S) { HOPS(I, t, S, [[190, -128], [960, -100]]); S.lean.set(0, 80, 10); S.turn.set(0, 60, 11); S.lx.set(0); S.ly.set(-0.4); } },
    walk: { dur: 5000, run(I, t, now, S) {
      const seg = [[0, -18, -0.6], [1500, -18, 0], [1800, 18, 0.6], [3800, 18, 0], [4100, 0, -0.4], [4800, 0, 0]]; let k = 0; for (let i = 0; i < seg.length; i++) if (t >= seg[i][0]) k = i;
      S.shift.set(seg[k][1], 26, 9); S.turn.set(seg[k][2], 90, 12); S.lx.set(seg[k][2], 300, 26);
      const moving = Math.abs(S.shift.vel) > 4, ph = now / 300 * Math.PI; I.step = moving ? 1 : 0;
      S.footL.set(moving ? Math.max(0, Math.sin(ph)) * 3 : 0, 400, 24); S.footR.set(moving ? Math.max(0, -Math.sin(ph)) * 3 : 0, 400, 24);
      S.rise.set(moving ? -1.4 * Math.abs(Math.sin(ph)) : 0, 400, 24); S.tilt.set(moving ? 3.5 * Math.sin(ph) : 0, 240, 16); S.sq.set(moving ? 0.03 * Math.cos(ph * 2) : 0, 300, 18);
      S.armL.set(moving ? 10 * Math.sin(ph) : 0, 260, 16); S.armR.set(moving ? -10 * Math.sin(ph) : 0, 260, 16); } },
    turn: { dur: 5200, run(I, t, now, S) { if (once(I, 'a')) S.spin.set(S.spin.t + 180, 20, 8.5); if (t > 2600 && once(I, 'b')) S.spin.set(S.spin.t + 180, 20, 8.5); S.sq.set(0.02, 160, 14); S.lean.set(0, 80, 12); } },
  };
  const loopA = (a, P, D) => { const b = A[a]; A[a] = { ...b, dur: D, run(I, t, now, S) { const c = Math.floor(t / P); if (c !== I.cyc) { I.cyc = c; I.f = {}; I.kf = -1; } b.run(I, t % P, now, S); }, fx: b.fx ? (I, t) => b.fx(I, t % P) : null }; };
  loopA('squish', 1700, 5100); loopA('release', 1250, 5000); loopA('spin', 2600, 5200); loopA('happy', 2100, 6300); loopA('eat', 2900, 5800); loopA('unlock', 2900, 5800); loopA('cheer', 2600, 5200); loopA('hop', 1900, 5700);
  A.dance.run = (I, t, now, S) => {
    const beat = 470, tb = t / beat, B = Math.floor(tb), b = B % 16, bar = b >> 2, odd = b % 2 ? 1 : -1;
    if (B !== I.lastBeat) { I.lastBeat = B;
      if (bar === 0) { S.sq.vel += 3.2; if (b % 2 === 1) jump(I, -62); }
      if (bar === 1) { S.sq.vel += 2.4; jump(I, -52); }
      if (bar === 2) S.sq.vel += 1.2;
      if (b === 12) S.sq.set(0.26, 380, 18);
      if (b === 13) { jump(I, -150); S.sq.vel -= 1; }
      if (b === 15) { S.sq.vel += 2.5; I.blinkAt = now + 1200; } }
    S.lx.set(0, 300, 26); S.ly.set(-0.2, 300, 26);
    if (bar === 0) { S.sq.set(0.04, 220, 12); S.turn.set(odd * 0.4, 120, 11); S.lean.set(odd * 3, 150, 11); S.tilt.set(odd * 3, 160, 12); S.armL.set(odd < 0 ? 38 : -4, 260, 14); S.armR.set(odd > 0 ? 38 : -4, 260, 14); S.ear.set(-odd * 8, 260, 10); S.happy.set(0.25); }
    else if (bar === 1) { S.sq.set(0.03, 220, 12); S.shift.set(odd * 10, 150, 13); S.lean.set(odd * 6, 160, 11); S.tilt.set(odd * 7, 150, 11); S.turn.set(odd * 0.7, 120, 11); S.armL.set(odd > 0 ? 30 : -6, 240, 14); S.armR.set(odd < 0 ? 30 : -6, 240, 14); S.ear.set(odd * 10, 240, 10); }
    else if (bar === 2) { S.shift.set(4 * Math.sin(TAU * tb / 4), 140, 14); S.lean.set(8 * Math.sin(TAU * tb / 2), 180, 12); S.tilt.set(6 * Math.sin(TAU * tb / 2 + 0.6), 180, 12); S.sq.set(0.05 + 0.05 * Math.sin(TAU * tb), 220, 12); S.turn.set(0.55 * Math.sin(TAU * tb / 2), 120, 11);
      S.armL.set(40 + 14 * Math.sin(TAU * tb * 2), 300, 14); S.armR.set(40 + 14 * Math.sin(TAU * tb * 2 + Math.PI), 300, 14); S.ear.set(9 * Math.sin(TAU * tb), 260, 10); S.happy.set(0.45); }
    else if (b === 12) { S.lean.set(0, 120, 12); S.turn.set(0, 120, 11); S.armL.set(-10, 260, 16); S.armR.set(-10, 260, 16); S.ear.set(-12, 260, 12); }
    else if (b === 13 || b === 14) { const u = clamp((tb - 13) / 1.3, 0, 1); S.turn.set(-1 + 2 * u, 260, 18); S.tilt.set(12 * Math.sin(TAU * u), 220, 14); S.armL.set(44, 300, 14); S.armR.set(44, 300, 14); S.ear.set(10, 220, 10); S.happy.set(0.3); }
    else { S.lean.set(-5, 150, 11); S.tilt.set(-8, 150, 11); S.turn.set(0.45, 120, 11); S.armL.set(46, 260, 14); S.armR.set(-6, 260, 14); S.ear.set(4, 220, 10); S.winkR.set(1); S.happy.set(0.55); S.shift.set(-3, 140, 14); }
  };

  function setAct(I, a) { const cur = A[I.act]; if (cur && cur.end) cur.end(I); if (I.press) { I.press = false; I.S.sq.set(0, 330, 7); } if (a !== 'spin' && a !== 'turn') { const f = Math.round(I.S.spin.v / 360) * 360; if (I.S.spin.t !== f) I.S.spin.set(f, 45, 10); } I.act = A[a] ? a : 'idle'; I.actT = performance.now(); I.f = {}; I.cyc = -1; I.lastBeat = -1; I.kf = -1; I.clip = false; I.dirtA = 0; I.shake = 0; if (I.onAct) I.onAct(I.act); }
  function press(I, now) { I.press = true; I.pressT = now || performance.now(); I.S.sq.set(0.3, 230, 18); }
  function release(I, now) { I.press = false; I.S.sq.set(0, 330, 7); I.S.sq.vel -= 2; I.giggleT = now || performance.now(); }
  function poke(I, x, y, now) { now = now || performance.now(); I.dent = { x, y, t: now }; I.S.lean.vel += (x < 50 ? 1 : -1) * 34; I.pokeT = now; I.giggleT = now + 160; }

  function mount(host, key, opts) {
    opts = opts || {};
    const mk = () => ({ sq: new Sp(0, 160, 14), lean: new Sp(0, 70, 12), turn: new Sp(0, 60, 11), lx: new Sp(0, 300, 26), ly: new Sp(0, 300, 26), shift: new Sp(0, 140, 14), tilt: new Sp(0, 120, 12),
      armL: new Sp(0, 200, 16), armR: new Sp(0, 200, 16), ear: new Sp(0, 220, 14), winkL: new Sp(0, 400, 30), winkR: new Sp(0, 400, 30), happy: new Sp(0, 300, 26), mouthO: new Sp(0, 300, 24), frown: new Sp(0, 200, 20),
      wide: new Sp(0, 400, 24), puff: new Sp(0, 220, 16), droop: new Sp(0, 120, 14), lid: new Sp(0, 160, 16), scale: new Sp(1, 160, 14), rise: new Sp(0, 160, 14), footL: new Sp(0, 400, 24), footR: new Sp(0, 400, 24), spin: new Sp(0, 40, 11) });
    const I = { key, act: 'idle', actT: performance.now(), f: {}, ptr: null, fake: null, blinkAt: performance.now() + 900, blinkT: -1e9, dbl: false, squint: 0, press: false, y: 0, vy: 0, air: false, glanceAt: 0, dirtA: 0, shake: 0, S: mk(), onAct: opts.onAct };
    const wrap = document.createElement('div'); wrap.style.cssText = 'position:relative;width:100%;height:100%;touch-action:none;cursor:pointer;user-select:none;';
    host.innerHTML = ''; host.appendChild(wrap); I.wrap = wrap;
    const layer = () => { const e = document.createElementNS(NS, 'svg'); e.setAttribute('viewBox', '0 0 100 100'); e.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;overflow:visible;pointer-events:none;'; return e; };
    const sh = layer(); I.shadow = document.createElementNS(NS, 'ellipse'); I.shadow.setAttribute('fill', '#6a1b9a'); sh.appendChild(I.shadow); wrap.appendChild(sh);
    I.clipEl = document.createElement('div'); I.clipEl.style.cssText = 'position:absolute;inset:0;'; wrap.appendChild(I.clipEl);
    I.body = document.createElement('div'); I.body.style.cssText = 'position:absolute;inset:0;'; I.clipEl.appendChild(I.body);
    I.views = {}; ['right', 'left', 'back'].forEach(v => { const im = document.createElement('img'); im.src = 'export/tripo/' + key + '/' + key + '-' + v + '.svg'; im.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;opacity:0;pointer-events:none;'; I.body.appendChild(im); I.views[v] = im; });
    I.fx = layer(); wrap.appendChild(I.fx);
    const loc = e => { const r = wrap.getBoundingClientRect(); return { r, x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height }; };
    wrap.addEventListener('pointermove', e => { const p = loc(e); I.ptr = { x: clamp((p.x * 2 - 1) * 1.4, -1, 1), y: clamp((p.y * 2 - 1) * 1.2, -1, 1) };
      if (I.down) { const dx = e.clientX - I.down.cx; if (!I.drag && Math.abs(dx) > 12) { I.drag = true; clearTimeout(I._ht); if (I.press) release(I); } if (I.drag) I.S.spin.set(I.down.s0 + dx / p.r.width * 320, 320, 26); } });
    wrap.addEventListener('pointerleave', () => { I.ptr = null; });
    wrap.addEventListener('pointerdown', e => { try { wrap.setPointerCapture(e.pointerId); } catch (x) {} const p = loc(e); if (I.act !== 'idle') setAct(I, 'idle'); I.down = { cx: e.clientX, x: p.x * 100, y: p.y * 100, s0: I.S.spin.t }; I.drag = false; clearTimeout(I._ht); I._ht = setTimeout(() => { if (I.down && !I.drag) press(I); }, 170); });
    const up = () => { if (!I.down) return; clearTimeout(I._ht); if (I.drag) { I.S.spin.set(Math.round(I.S.spin.t / 360) * 360, 45, 10); } else if (I.press) release(I); else poke(I, I.down.x, I.down.y); I.down = null; I.drag = false; };
    wrap.addEventListener('pointerup', up); wrap.addEventListener('pointercancel', up);
    load(key).then(t => {
      if (I.dead) return; const p = '_r' + (++UID);
      const txt = t.replace(/id="([^"]+)"/g, (m, id) => 'id="' + id + p + '"').replace(/url\(#([^)]+)\)/g, (m, id) => 'url(#' + id + p + ')').replace(/width="\d+" height="\d+"/, 'width="100%" height="100%"');
      I.body.insertAdjacentHTML('beforeend', txt); const svg = I.body.lastElementChild; svg.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;overflow:visible;pointer-events:none;'; I.svg = svg;
      setup(I, svg, 0);
    });
    ALL.add(I); kick();
    return { play: a => setAct(I, a), destroy: () => { I.dead = true; ALL.delete(I); clearTimeout(I._ht); host.innerHTML = ''; }, get act() { return I.act; } };
  }

  function extras(I, svg) {
    const add = (tag, at, parent) => { const e = document.createElementNS(NS, tag); for (const k in at) e.setAttribute(k, at[k]); (parent || svg).appendChild(e); return e; };
    const bodyG = svg.querySelector('g[filter]'), bb = I.bb;
    I.dirt = [[0.3, 0.3, 4], [0.68, 0.62, 3.4], [0.42, 0.8, 3], [0.72, 0.3, 2.6], [0.24, 0.7, 2.4]].map(([fx, fy, r]) => {
      const x = bb.x + bb.width * fx, y = bb.y + bb.height * fy; const d = 'M' + r2(x - r) + ' ' + r2(y) + ' Q' + r2(x - r) + ' ' + r2(y - r) + ' ' + r2(x) + ' ' + r2(y - r * 0.9) + ' Q' + r2(x + r * 1.2) + ' ' + r2(y - r) + ' ' + r2(x + r) + ' ' + r2(y + r * 0.2) + ' Q' + r2(x + r * 0.6) + ' ' + r2(y + r) + ' ' + r2(x - r * 0.2) + ' ' + r2(y + r * 0.8) + ' Q' + r2(x - r * 1.1) + ' ' + r2(y + r * 0.7) + ' ' + r2(x - r) + ' ' + r2(y) + 'Z';
      const e = add('path', { d, fill: '#8a6a4a', opacity: 0 }, bodyG); const q = { e, tag: 'path', role: 'dirt', segs: parsePath(d), tr: '' }; I.items.push(q); return q; });
    const mouth = I.items.find(q => q.role === 'mouth'); I.mouthRest = mouth ? [mouth.cx, mouth.cy] : [50, I.eyeY + 8];
    I.om = add('g', { opacity: 0 }); add('ellipse', { cx: 0, cy: 0, rx: 3.2, ry: 3, fill: '#7a2a40' }, I.om); add('ellipse', { cx: 0, cy: 1.6, rx: 2, ry: 1.2, fill: '#ff8fa3' }, I.om);
    I.arcs = I.items.filter(q => q.role === 'eye' && !q.hl).map(q => { const e = add('path', { d: 'M-1 0 Q0 0.8 1 0', stroke: '#2a1a30', 'stroke-width': 0.28, fill: 'none', 'stroke-linecap': 'round', opacity: 0 }); return { e, q }; });
  }

  function step(I, now, dt) {
    const S = I.S, t = now - I.actT, act = A[I.act] || A.idle;
    if (act.dur && t > act.dur) { setAct(I, 'idle'); return; }
    if (now > I.blinkAt) { I.blinkT = now; I.blinkAt = now + 1700 + Math.random() * 3300; I.dbl = Math.random() < 0.25; }
    I.squint += ((I.press ? 1 : 0) - I.squint) * Math.min(1, dt * 16);
    const P = I.ptr || I.fake;
    if (P) { S.lx.set(P.x, 300, 26); S.ly.set(P.y * 0.7, 300, 26); }
    else if (I.act === 'idle' || I.act === 'dance' || I.act === 'blink') { if (now > I.glanceAt) { I.glanceAt = now + 1100 + Math.random() * 2600; const g = Math.random(); S.lx.set(g < 0.3 ? 0 : (Math.random() * 2 - 1) * 0.9, 480, 32); S.ly.set((Math.random() - 0.5) * 0.6, 480, 32); } }
    ['shift', 'tilt', 'armL', 'armR', 'ear', 'winkL', 'winkR', 'happy', 'mouthO', 'frown', 'wide', 'puff', 'droop', 'lid', 'rise', 'footL', 'footR'].forEach(k => S[k].set(0));
    S.scale.set(1); S.blush = 0;
    act.run(I, t, now, S);
    if (I.press) { const h = Math.max(0, now - I.pressT); S.sq.set(Math.min(0.42, 0.3 + h / 2400 * 0.12), 230, 18); S.blush = clamp((h - 500) / 800, 0, 1); I.shake = h > 900 ? 0.5 : 0; }
    if (I.giggleT && now > I.giggleT && now < I.giggleT + 520) { const k = Math.floor((now - I.giggleT) / 75); if (k !== I.gk2) { I.gk2 = k; S.sq.vel += k % 2 ? 1.3 : -1.1; } S.happy.set(1); S.mouthO.set(0.3); }
    if (I.pokeT && now - I.pokeT < 180) { S.happy.set(1, 500, 30); }
    Object.values(S).forEach(s => s && s.step && s.step(dt));
    if (S.sq.v > 0.42) { S.sq.v = 0.42; S.sq.vel = Math.min(0, S.sq.vel); } else if (S.sq.v < -0.22) { S.sq.v = -0.22; S.sq.vel = Math.max(0, S.sq.vel); }
    if (!I.drag && I.act !== 'spin' && I.act !== 'turn' && Math.abs(S.spin.v - S.spin.t) < 0.5 && S.spin.t % 360 === 0 && S.spin.t !== 0) { S.spin.v -= S.spin.t; S.spin.t = 0; }
    if (I.air) { I.vy += 520 * dt; I.y += I.vy * dt; if (I.y >= 0) { const imp = clamp(I.vy / 150, 0, 1.2); I.y = 0; I.vy = 0; I.air = false; S.sq.set(0, 300, 8); S.sq.vel += 5 * imp; } }
    if (!I.items) return;
    const sq = S.sq.v, lean = S.lean.v, turn = S.turn.v, air = I.air ? 1 : 0, dance = I.act === 'dance', droop = S.droop.v;
    I.items.forEach(q => { if (!q.sp) return; const s = q.side || 0; let a, lim = 18;
      if (q.role === 'top') { a = -lean * 0.35 + s * (sq * 6 + (-I.vy) * 0.015 + droop * 14) + (s ? s * S.ear.v : S.ear.v) * 0.3; lim = 9; }
      else if (q.role === 'arm') { a = -s * (sq * 35 + air * 18) + lean * 1.2 - S.lean.vel * 0.15 - s * (s < 0 ? S.armL.v : S.armR.v); lim = 50; }
      else { a = dance ? 16 * Math.sin(now / 230) + lean * 1.6 : (7 - droop * 5) * Math.sin(now / (700 + droop * 600)) + lean * 1.4 + s * sq * 15 - droop * 8; lim = dance ? 26 : 18; }
      q.sp.set(clamp(a, -lim, lim)); if (q.role === 'top') { q.sp.v = q.sp.t; q.sp.vel = 0; } else q.sp.step(dt); });
  }

  function draw(I, now) {
    const S = I.S, t = now - I.actT, act = A[I.act] || A.idle;
    const spin = S.spin.v, sa = ((spin % 360) + 360) % 360, c = Math.cos(spin * D2R), sn = Math.sin(spin * D2R);
    const fa = SM((c - 0.42) / 0.16), ba = SM((-c - 0.42) / 0.16), sa2 = clamp(1 - fa - ba, 0, 1);
    const dip = 1 - 0.14 * Math.max(bump(Math.abs(c), 0.26, 0.58), 0);
    const sq = S.sq.v, lean = S.lean.v, turn = clamp(S.turn.v + (fa > 0 ? sn * 1.3 : 0), -1.4, 1.4), lx = S.lx.v, ly = S.ly.v, lift = -I.y;
    const G = I.G, H = Math.max(10, G - I.top), sy = 1 - sq, at = Math.abs(turn);
    let dent = null; if (I.dent) { const d0 = Math.max(0, now - I.dent.t); if (d0 > 1000) I.dent = null; else { const amp = d0 < 60 ? d0 / 60 : Math.exp(-(d0 - 60) / 160) * Math.cos((d0 - 60) / 55); dent = { x: I.dent.x, y: I.dent.y, a: amp * 5 }; } }
    const U = y => clamp((G - y) / H, 0, 1);
    const kx = u => 1 + sq * (0.45 + 0.6 * 4 * u * (1 - u));
    const cyB = (G + I.top) / 2;
    const W = (x, y) => { if (dent) { const ddx = x - dent.x, ddy = y - dent.y, g = Math.exp(-(ddx * ddx + ddy * ddy) / 220); if (g > 0.01) { const vx = 50 - dent.x, vy = cyB - dent.y, L = Math.hypot(vx, vy) || 1; x += vx / L * dent.a * g; y += vy / L * dent.a * g; } }
      x += turn * 3.2 * SM((I.headBot - y) / 16 + 0.5);
      const u = U(y); return [50 + (x - 50) * kx(u) + lean * Math.pow(u, 1.6), G - (G - y) * sy - lift]; };
    const J = y => [kx(U(y)), sy];
    const bt = now - I.blinkT, bk = x => (x < 0 || x > 140) ? 0 : Math.sin(Math.PI * x / 140);
    const blink = Math.max(bk(bt), I.dbl ? bk(bt - 200) : 0);
    const sqz = clamp(I.squint + S.happy.v, 0, 1), lid = clamp(S.lid.v, 0, 1), wide = clamp(S.wide.v, 0, 1);
    const eyeOpen = clamp((1 - blink * 0.94) * (1 - lid), 0, 1);
    const happyArc = sqz > 0.55 && eyeOpen > 0.3;
    const eyeSY = Math.max(0.06, eyeOpen * (1 - sqz * 0.5) * (1 + wide * 0.25));
    const wink = { '-1': clamp(S.winkL.v, 0, 1), '1': clamp(S.winkR.v, 0, 1) };
    const sh = I.shake ? (Math.random() - 0.5) * I.shake : 0;
    const tf = 'translate(' + r2(S.shift.v + sh) + '%,' + r2(S.rise.v) + '%) rotate(' + r2(S.tilt.v) + 'deg) scale(' + r2(S.scale.v * dip) + ',' + r2(S.scale.v) + ')';
    I.body.style.transformOrigin = '50% ' + r2(G) + '%'; I.body.style.transform = tf;
    I.clipEl.style.clipPath = I.clip === 'bath' ? 'inset(-60% -60% 6% -60%)' : I.clip ? 'inset(-60% -60% 24% -60%)' : '';
    if (I.svg) I.svg.style.opacity = r2(fa);
    const vs = 'scale(' + r2(kx(0.5) * dip) + ',' + r2(sy) + ')', vo = '50% ' + r2(G) + '%';
    I.views.back.style.opacity = r2(ba); I.views.right.style.opacity = r2(sn > 0 ? sa2 : 0); I.views.left.style.opacity = r2(sn <= 0 ? sa2 : 0);
    [I.views.back, I.views.right, I.views.left].forEach(v => { v.style.transformOrigin = vo; v.style.transform = 'translateY(' + r2(-lift) + '%) ' + vs; });
    const PX = 1.4;
    const place = (q, dx, dy) => {
      const e = q.e; dy = dy || 0;
      if (q.tag === 'path') { let F; if (q.wt) { const o = q.owner || q, ang = o.sp ? o.sp.v * D2R : 0, R = o.R;
          if (q.role === 'top') { const Wr = W(R[0], R[1]), uR = U(R[1]), mxs = Math.sqrt(kx(uR)), mys = Math.sqrt(sy), la = lean * 1.6 * Math.pow(uR, 0.6) / H, cl = Math.cos(la), sl = Math.sin(la);
            F = (x, y, i) => { const w = q.wt[i] || 0; let ux = x - R[0], uy = y - R[1]; if (w > 0.001) { const cw = Math.cos(ang * w), sw = Math.sin(ang * w); const nx = ux * cw - uy * sw; uy = ux * sw + uy * cw; ux = nx; }
              ux *= mxs; uy *= mys; const rx = ux * cl - uy * sl, ry = ux * sl + uy * cl; return [Wr[0] + rx + dx, Wr[1] + ry + dy]; }; }
          else F = (x, y, i) => { const w = q.wt[i] || 0; if (w > 0.001) { const cw = Math.cos(ang * w), sw = Math.sin(ang * w), ux = x - R[0], uy = y - R[1]; x = R[0] + ux * cw - uy * sw; y = R[1] + ux * sw + uy * cw; } const p = W(x, y); return [p[0] + dx, p[1] + dy]; }; }
        else F = (x, y) => { const p = W(x, y); return [p[0] + dx, p[1] + dy]; };
        e.setAttribute('d', pathStr(q.segs, F, J)); }
      else if (q.tag === 'circle' || q.tag === 'ellipse') { const [x, y] = W(q.ox, q.oy), k = J(q.oy), nx = x + dx, ny = y + dy; e.setAttribute('cx', r2(nx)); e.setAttribute('cy', r2(ny));
        if (q.tag === 'circle') e.setAttribute('r', r2(q.rx * Math.sqrt(k[0] * k[1]))); else { const m = q.rot != null ? Math.sqrt(k[0] * k[1]) : 0; e.setAttribute('rx', r2(q.rx * (m || k[0]))); e.setAttribute('ry', r2(q.ry * (m || k[1]))); }
        if (q.rot != null) e.setAttribute('transform', 'rotate(' + q.rot + ' ' + r2(nx) + ' ' + r2(ny) + ')'); }
      else if (q.tag === 'rect') { const a = W(q.x, q.y), b = W(q.x + q.w, q.y + q.h); e.setAttribute('x', r2(Math.min(a[0], b[0]) + dx)); e.setAttribute('y', r2(Math.min(a[1], b[1]) + dy)); e.setAttribute('width', r2(Math.abs(b[0] - a[0]))); e.setAttribute('height', r2(Math.abs(b[1] - a[1]))); }
    };
    I.eyeW = []; const arcOf = new Map();
    for (const q of I.items) {
      switch (q.role) {
        case 'body': case 'top': case 'side': case 'arm': place(q, 0); break;
        case 'foot': place(q, 0, -(q.ox < 50 ? S.footL.v : S.footR.v)); break;
        case 'dirt': place(q, turn * PX * 0.8); q.e.setAttribute('opacity', r2(I.dirtA * 0.8)); break;
        case 'patch': place(q, turn * PX * 0.8); break;
        case 'shine': place(q, -turn * 4.8); break;
        case 'eye': {
          const [wx, wy] = W(q.ex, q.ey), k = J(q.ey), nx = wx + turn * PX + lx * 1.2, ny = wy + ly * 1.1, far = (q.side < 0 && turn > 0) || (q.side > 0 && turn < 0);
          const sx = (far ? 1 - 0.25 * at : 1 + 0.04 * at) * k[0] * (1 + wide * 0.2), wk = wink[q.side], ey2 = Math.max(0.06, eyeSY * (1 - wk * 0.94)) * k[1], e = q.e;
          const showArc = happyArc || ey2 < 0.16 || wk > 0.6;
          e.setAttribute('cx', r2(q.ox - q.ex + nx)); e.setAttribute('cy', r2(q.oy - q.ey + ny));
          e.setAttribute('transform', 'translate(' + r2(nx) + ' ' + r2(ny) + ') scale(' + r2(sx) + ' ' + r2(ey2) + ') translate(' + r2(-nx) + ' ' + r2(-ny) + ')');
          e.setAttribute('opacity', showArc ? 0 : (q.hl ? (ey2 < 0.4 ? 0 : (q.op || 1)) : 1));
          if (!q.hl) { I.eyeW.push([nx, ny]); arcOf.set(q, { nx, ny, sx, up: happyArc || wk > 0.6, show: showArc, r: q.rx }); }
          break; }
        case 'cheek': { const far = (q.side < 0 && turn > 0) || (q.side > 0 && turn < 0); place(q, turn * PX * 1.1); const k = J(q.oy), pf = 1 + S.puff.v * 0.55;
          q.e.setAttribute('rx', r2(q.rx * k[0] * (far ? 1 - 0.3 * at : 1) * (1 + sqz * 0.2) * pf)); q.e.setAttribute('ry', r2(q.ry * k[1] * pf));
          q.e.setAttribute('opacity', r2(Math.min(1, (+q.op || 1) * (far ? 1 - 0.4 * at : 1) * (1 + sqz * 0.5 + S.blush * 0.9 + S.puff.v * 0.5)))); break; }
        case 'mouth': case 'face': {
          const depth = q.role === 'mouth' ? 1.05 : (q.cy < 40 ? 0.75 : 1); const [wx, wy] = W(q.cx, q.cy), k = J(q.cy);
          if (q.role === 'mouth') { const mo = clamp(S.mouthO.v, 0, 1), fr = clamp(S.frown.v, 0, 1), ms = 1 + sqz * 0.3;
            const mx = wx + turn * PX * depth, my = wy + fr * 1.2; I.mouthW = [mx + S.shift.v, my + S.rise.v - lift * 0];
            q.e.setAttribute('transform', 'translate(' + r2(mx) + ' ' + r2(my) + ') scale(' + r2(k[0] * (1 - 0.1 * at) * ms) + ' ' + r2(k[1] * ms * (1 - 2 * fr)) + ') translate(' + r2(-q.cx) + ' ' + r2(-q.cy) + ')');
            q.e.setAttribute('opacity', r2(1 - SM(mo * 3)));
            I.om.setAttribute('opacity', r2(SM(mo * 3))); I.om.setAttribute('transform', 'translate(' + r2(mx) + ' ' + r2(my + 1) + ') scale(' + r2(k[0] * (0.7 + 0.5 * mo)) + ' ' + r2(k[1] * (0.25 + 0.95 * mo)) + ')');
          } else q.e.setAttribute('transform', 'translate(' + r2(wx + turn * PX * depth) + ' ' + r2(wy) + ') scale(' + r2(k[0] * (1 - 0.1 * at)) + ' ' + r2(k[1]) + ') translate(' + r2(-q.cx) + ' ' + r2(-q.cy) + ')' + (q.tr ? ' ' + q.tr : ''));
          break; }
      }
    }
    if (I.arcs) I.arcs.forEach(a => { const v = arcOf.get(a.q); if (!v) return; a.e.setAttribute('opacity', v.show ? 1 : 0); if (!v.show) return; const r = v.r * 1.05 * v.sx;
      a.e.setAttribute('transform', 'translate(' + r2(v.nx) + ' ' + r2(v.ny + (v.up ? 0.6 : 0)) + ') scale(' + r2(r) + ' ' + r2(r * (v.up ? -1 : 1)) + ')'); a.e.setAttribute('stroke-width', r2(1.4 / r)); });
    if (I.gEl) { I.gEl.setAttribute('cx', r2(I.gb.cx - turn * 5 - lean * 0.3)); I.gEl.setAttribute('cy', r2(I.gb.cy - lift)); }
    I.topW = [50 + S.shift.v, I.top + S.rise.v - lift];
    const bw = I.bb.width, gl = Math.max(0, lift - S.rise.v * 0);
    I.shadow.setAttribute('cx', r2(50 + lean * 0.2 + S.shift.v)); I.shadow.setAttribute('cy', r2(G + 1.5)); I.shadow.setAttribute('rx', r2(bw * 0.4 * S.scale.v * (1 + sq * 0.5) * (1 - gl / 70))); I.shadow.setAttribute('ry', r2(3.4 * (1 - gl / 90)));
    I.shadow.setAttribute('opacity', r2((I.clip ? 0 : 0.24) * (1 - gl / 55)));
    I.fx.innerHTML = act.fx ? act.fx(I, t) : '';
  }

  window.Rig25 = { v: 3, mount, ACTIONS: Object.keys(A), _all: ALL, _tick(I, ms) { I._vt = I._vt || performance.now(); const n = Math.round(ms / (1000 / 60)); for (let k = 0; k < n; k++) { const now = (I._vt += 1000 / 60); step(I, now, 1 / 120); step(I, now, 1 / 120); } draw(I, I._vt); }, _act: setAct };
})();
