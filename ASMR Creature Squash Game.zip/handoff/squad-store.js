// Squish Squad shared roster + economy + collection. Coins live in SquishProfile (game); gems, Stars and the collection live here.
(function () {
  if (window.SquishSquad) return;
  const KEY = 'squishsquad.collection.v1';
  const RAR = [
    { k: 'Common', label: 'COMMON', bg: '#d7f0ff', dot: '#9fd8ff', ink: '#2f7fd6', card: '#e6f5ff', lip: '#a9d2f2' },
    { k: 'Rare', label: 'RARE', bg: '#c9f7e1', dot: '#7ee8b4', ink: '#16a86a', card: '#e2fbef', lip: '#98dcbc' },
    { k: 'Epic', label: 'EPIC', bg: '#ead6ff', dot: '#c89bff', ink: '#8f3cf2', card: '#f1e6ff', lip: '#cdb0f2' },
    { k: 'Legendary', label: 'LEGENDARY', bg: '#ffdcb0', dot: '#ffa94d', ink: '#d9772f', card: '#fff0dc', lip: '#f2c98f' },
    { k: 'Set reward', label: 'SET REWARD', bg: '#ffe0f3', dot: '#ff8fd3', ink: '#d3179a', card: '#ffe9f6', lip: '#f0a8d8' },
  ];
  const SETS = [
    { key: 'snack', name: 'Snack Shack', vibe: 'Street-food buddies', tint: '#fff0e2', lip: '#f2c7a0', ink: '#c4651f', perk: 'Unlocks the Snack Shack kitchen theme' },
    { key: 'fruit', name: 'Fruit Patch', vibe: 'Juicy and bright', tint: '#fff6d6', lip: '#ecd078', ink: '#b88a00', perk: 'Unlocks a fruit-stand furniture set' },
    { key: 'ocean', name: 'Ocean Pals', vibe: 'Splashy and squishy', tint: '#e4f3ff', lip: '#a9d2f2', ink: '#2f7fd6', perk: 'Unlocks the aquarium wall' },
    { key: 'pet', name: 'Pet Shop', vibe: 'Furry best friends', tint: '#ffe9f6', lip: '#f0a8d8', ink: '#c0268f', perk: 'Unlocks the pet bed set' },
    { key: 'forest', name: 'Forest Friends', vibe: 'Cozy woodland', tint: '#e2fbef', lip: '#98dcbc', ink: '#16a86a', perk: 'Unlocks the forest room theme' },
    { key: 'sky', name: 'Sky & Stars', vibe: 'Dreamy night sky', tint: '#ece6ff', lip: '#c3b0f2', ink: '#5a3ad0', perk: 'Unlocks the starry ceiling' },
    { key: 'dream', name: 'Dreamland', vibe: 'Fantasy and magic', tint: '#f6e3ff', lip: '#d9a8f0', ink: '#9a2fc8', perk: 'Unlocks the castle bed' },
    { key: 'bakery', name: 'Sweet Bakery', vibe: 'Fresh from the oven', tint: '#fff0e6', lip: '#f2b8a0', ink: '#c2502a', perk: 'Unlocks the bakery kitchen' },
  ];
  const SEASON = { key: 'spooky', name: 'Spooky Squish', label: 'SEASON 1 · OCTOBER', ends: new Date(2026, 9, 31, 23, 59).getTime(), tint: '#ffe6cc', lip: '#e0a070', ink: '#7a2a00' };
  // [id, name, set, rarity(0-3, 4 = set reward), concept, sound, move name, dance, flags]
  const R = [
    [0, 'Nimbo', 'sky', 0, 'Sleepy cloud that drizzles', 'rain patter', 'Cloud Sway', 'sway'],
    [1, 'Mittens', 'pet', 0, 'Ginger kitten', 'purr', 'Kitty Wiggle', 'wiggle'],
    [2, 'Mallow', 'snack', 1, 'Marshmallow', 'slow-rise memory foam', 'Marshmallow Jelly', 'jelly'],
    [3, 'Bao', 'snack', 0, 'Steamed bun with a soft puff of steam', 'pillowy thump', 'Dumpling Bounce', 'bounce'],
    [4, 'Dunkie', 'snack', 0, 'Sprinkle donut with one bite missing', 'sugary crunch', 'Donut Bounce', 'bounce'],
    [5, 'Frybo', 'snack', 0, 'Box of fries', 'crispy rustle', 'Fry Shuffle', 'shuffle'],
    [6, 'Pip', 'ocean', 0, 'Tiny penguin with a big waddle', 'icy slide', 'Pip Pop & Lock', 'pop'],
    [7, 'Bunbun', 'snack', 0, 'Stacked burger', 'squeaky cheese squish', 'Bunny Hop', 'hop'],
    [8, 'Jelli', 'ocean', 2, 'Wobbly jellyfish', 'world-class wobble', 'Jelly Twist', 'twist'],
    [9, 'Pina', 'fruit', 0, 'Pineapple with a spiky crown', 'fizzy squish', 'Tropical Sway', 'sway'],
    [10, 'Finn', 'ocean', 0, 'Baby dolphin', 'splash', 'Fin Leap', 'leap'],
    [11, 'Sealy', 'ocean', 1, 'Fluffy baby seal', 'pure squish', 'Seal Slide', 'slide'],
    [12, 'Biscuit', 'pet', 0, 'Floppy-eared puppy', 'tail thump', 'Biscuit Bot', 'robot'],
    [13, 'Hana', 'dream', 0, 'Kid in a cozy bunny suit', 'zipper hoodie squish', 'Petal Twist', 'twist'],
    [14, 'Choco', 'snack', 2, 'Chocolate bar that melts your heart', 'snap then gooey', 'Choco Pop', 'pop'],
    [15, 'Prickle', 'pet', 2, 'Spiky outside, squish inside', 'crinkle then soft', 'Prickly Shuffle', 'shuffle'],
    [16, 'Lumi', 'sky', 3, 'Moon bunny with a lantern', 'soft bell', 'Moonwalk', 'slide'],
    [17, 'Kiko', 'forest', 3, 'Petal-maned pony', 'flower chime', 'Kiko Leap', 'leap'],
    [18, 'Bubbly', 'sky', 1, 'Iridescent bubble that never pops', 'glassy wobble', 'Bubble Wiggle', 'wiggle'],
    [19, 'Twinkle', 'sky', 2, 'Sleepy star in a nightcap', 'twinkle chime', 'Star Hop', 'hop'],
    [20, 'Zappi', 'sky', 1, 'Static spark', 'crackle', 'Static Robot', 'robot'],
    [21, 'Scoop', 'snack', 1, 'Strawberry ice cream that never melts', 'cold crackle', 'Scoop Swirl', 'twist'],
    [22, 'Teddy', 'forest', 0, 'Huggable bear', 'deep plush hug', 'Bear Hug Sway', 'sway'],
    [23, 'Hoot', 'forest', 1, 'Wise little owl', 'feather fluff', 'Owl Bob', 'bounce'],
    [24, 'Leo', 'forest', 2, 'Lion cub with a fluffy mane', 'tiny roar', 'Roar Pop', 'pop'],
    [25, 'Nibbles', 'pet', 0, 'Hamster with stuffed cheeks', 'seed crunch', 'Cheek Wiggle', 'wiggle'],
    [26, 'Quill', 'pet', 1, 'Shy hedgehog', 'soft spike brush', 'Spike Shuffle', 'shuffle'],
    [27, 'Panko', 'forest', 1, 'Baby panda', 'bamboo creak', 'Panda Roll', 'jelly'],
    [28, 'Boba', 'snack', 3, 'Bubble tea full of pearls', 'pearls popping', 'Pearl Bounce', 'bounce'],
    [29, 'Avo', 'fruit', 1, 'Baby avocado with a pit belly', 'buttery squish', 'Pit Hop', 'hop'],
    [30, 'Berri', 'fruit', 0, 'Strawberry with seed freckles', 'juicy pop', 'Berry Bop', 'bounce'],
    [31, 'Lemmy', 'fruit', 0, 'Sour-faced lemon', 'zesty squeak', 'Sour Shuffle', 'shuffle'],
    [32, 'Kiwi', 'fruit', 0, 'Fuzzy kiwi', 'velvet brush', 'Fuzzy Wiggle', 'wiggle'],
    [33, 'Melo', 'fruit', 1, 'Watermelon slice', 'watery slosh', 'Melon Slide', 'slide'],
    [34, 'Peachy', 'fruit', 2, 'Blushing peach', 'soft fuzz and sigh', 'Peach Twist', 'twist'],
    [35, 'Pitaya', 'fruit', 3, 'Dragonfruit with leafy wings', 'crunchy seeds', 'Dragon Leap', 'leap'],
    [36, 'Tutti', 'fruit', 4, 'Fruit-basket fairy', 'basket rustle', 'Fruit Salad Sway', 'sway'],
    [37, 'Puff', 'ocean', 0, 'Pufferfish that inflates on squeeze', 'balloon stretch', 'Puff Pop', 'pop'],
    [38, 'Shelly', 'ocean', 0, 'Sea turtle in a jelly shell', 'hollow tap', 'Shell Shuffle', 'shuffle'],
    [39, 'Octo', 'ocean', 1, 'Octopus with suction-cup feet', 'tiny pops', 'Eight-Arm Robot', 'robot'],
    [40, 'Marina', 'ocean', 3, 'Baby mermaid with a pearl', 'bubbles and chimes', 'Tide Twist', 'twist'],
    [41, 'Pearl', 'ocean', 4, 'Narwhal with a glowing horn', 'whale song hum', 'Narwhal Leap', 'leap'],
    [42, 'Waffles', 'pet', 0, 'Corgi loaf', 'bread-dough squish', 'Loaf Hop', 'hop'],
    [43, 'Poppy', 'pet', 1, 'Guinea pig', 'wheek squeak', 'Popcorn Bounce', 'bounce'],
    [44, 'Duchess', 'pet', 3, 'Fluffy Persian cat with a tiny crown', 'velvet purr', 'Royal Sway', 'sway'],
    [45, 'Mama Paws', 'pet', 4, 'Big cuddly dog carrying a pup', 'double tail wag', 'Puppy Pile Jelly', 'jelly'],
    [46, 'Acorn', 'forest', 0, 'Squirrel in an acorn cap', 'nutty click', 'Nut Hop', 'hop'],
    [47, 'Fawn', 'forest', 0, 'Spotted baby deer', 'leaf rustle', 'Fawn Leap', 'leap'],
    [48, 'Moss', 'forest', 0, 'Mushroom sprite', 'spongy press', 'Spore Wiggle', 'wiggle'],
    [49, 'Sprout', 'forest', 4, 'Tree spirit with a sapling on its head', 'creaky branch', 'Sapling Sway', 'sway'],
    [50, 'Plip', 'sky', 0, 'Raindrop', 'water drip', 'Drip Drop', 'bounce'],
    [51, 'Breeze', 'sky', 0, 'Kite-tailed wind puff', 'whoosh', 'Gust Slide', 'slide'],
    [52, 'Dusty', 'sky', 0, 'Fuzzy moth', 'powder flutter', 'Moth Twist', 'twist'],
    [53, 'Aurora', 'sky', 4, 'Color-shifting sky whale', 'deep shimmer', 'Sky Swim', 'sway'],
    [54, 'Boo', 'dream', 0, 'Shy ghost', 'cool marshmallow', 'Ghost Glide', 'slide'],
    [55, 'Pixie', 'dream', 0, 'Tiny fairy', 'wing buzz', 'Fairy Hop', 'hop'],
    [56, 'Floof', 'dream', 0, 'Baby yeti', 'snow crunch', 'Snowball Shuffle', 'shuffle'],
    [57, 'Unibun', 'dream', 1, 'Unicorn bunny', 'sparkle squeak', 'Horn Twirl', 'twist'],
    [58, 'Gumdrop', 'dream', 1, 'Gummy bear', 'jelly bounce', 'Gummy Jelly', 'jelly'],
    [59, 'Ember', 'dream', 2, 'Phoenix chick', 'warm crackle', 'Flame Pop', 'pop'],
    [60, 'Drako', 'dream', 3, 'Baby dragon with tiny wings', 'puff of smoke', 'Dragon Robot', 'robot'],
    [61, 'Wishling', 'dream', 4, 'Wish-granting star sprite', 'wish chime', 'Wish Leap', 'leap'],
    [62, 'Cuppy', 'bakery', 0, 'Cupcake with frosting hair', 'frosting swirl', 'Frosting Twist', 'twist'],
    [63, 'Chip', 'bakery', 0, 'Chocolate chip cookie', 'crumbly crunch', 'Cookie Crumble', 'shuffle'],
    [64, 'Twisty', 'bakery', 0, 'Pretzel', 'salty knot creak', 'Knot Wiggle', 'wiggle'],
    [65, 'Crois', 'bakery', 0, 'Croissant', 'flaky layers', 'Flaky Sway', 'sway'],
    [66, 'Maca', 'bakery', 1, 'Macaron', 'crisp then chewy', 'Macaron Pop', 'pop'],
    [67, 'Puddi', 'bakery', 1, 'Caramel pudding', 'jiggle', 'Pudding Jelly', 'jelly'],
    [68, 'Mochi', 'bakery', 2, 'Strawberry daifuku', 'stretchy pull', 'Mochi Slide', 'slide'],
    [69, 'Cakey', 'bakery', 3, 'Three-tier party cake with candles', 'candle blow', 'Party Leap', 'leap'],
    [70, 'Sugarplum', 'bakery', 4, 'Tiny baker queen', 'sugar sprinkle', 'Sugar Hop', 'hop'],
    [71, 'Chef Bun', 'snack', 4, 'Tiny chef with a whisk', 'whisk clink', 'Whisk Robot', 'robot'],
    [72, 'Gourdy', 'spooky', 0, 'Round pumpkin with a curly vine', 'hollow thunk', 'Pumpkin Roll', 'bounce'],
    [73, 'Batty', 'spooky', 0, 'Baby bat with velvet wings', 'leathery flutter', 'Bat Flap', 'hop'],
    [74, 'Kernel', 'spooky', 0, 'Candy corn kid', 'waxy squeak', 'Candy Shuffle', 'shuffle'],
    [75, 'Hexie', 'spooky', 1, 'Witch cat in a floppy hat', 'purr and sparkle', 'Broom Sway', 'sway'],
    [76, 'Mumbles', 'spooky', 2, 'Mummy bunny in soft bandages', 'gauze rustle', 'Mummy Robot', 'robot'],
    [77, 'Hocus', 'spooky', 3, 'Wizard owl with a glowing spellbook', 'page flip and chime', 'Spell Twist', 'twist'],
    [78, 'Count Squishula', 'spooky', 3, 'Tiny vampire with a velvet cape', 'cape swish', 'Cape Slide', 'slide', 'pass'],
  ];
  const ART = new Set(R.map(r => r[0]));
  const ROSTER = R.map(([id, name, set, rar, concept, sound, move, dance, flag]) => ({
    id, name, set, rar, concept, sound, move, dance,
    key: name.toLowerCase().replace(/[^a-z]/g, ''),
    reward: rar === 4, season: set === 'spooky', pass: flag === 'pass', base: rar < 4 && set !== 'spooky',
    get art() { return ART.has(id); },
  }));
  SETS.forEach(s => { s.ids = ROSTER.filter(c => c.set === s.key && c.base).map(c => c.id).sort((a, b) => ROSTER[a].rar - ROSTER[b].rar || a - b); s.reward = ROSTER.find(c => c.set === s.key && c.reward).id; });
  SEASON.ids = ROSTER.filter(c => c.season).map(c => c.id);
  const STAR_PRICE = [40, 100, 250, 700];
  const COIN_PRICE = [1500, 4000, 9000, null];
  const DUPE = [5, 15, 40, 120, 40];
  const FIN = [
    { k: 'n', name: 'Normal', odds: 97.4, x: 0 },
    { k: 's', name: 'Shiny', odds: 2, x: 3 },
    { k: 'r', name: 'Rainbow', odds: 0.5, x: 8 },
    { k: 'g', name: 'Golden', odds: 0.1, x: 0 },
  ];
  const STAGES = [{ name: 'Baby', xp: 0, stars: 0 }, { name: 'Grown', xp: 100, stars: 10 }, { name: 'Best Friend', xp: 300, stars: 40 }];
  // how each growth stage looks: Baby is smaller and rounder, Best Friend gets a crown and a gold glow
  const STAGE_FX = [{ sx: 0.8, sy: 0.72, crown: false }, { sx: 1, sy: 1, crown: false }, { sx: 1.04, sy: 1.04, crown: true }];
  const CHESTS = {
    basic: { odds: [72, 22, 5, 1] }, silver: { odds: [55, 33, 9.5, 2.5] }, gold: { odds: [30, 45, 20, 5], gp: 1 },
    crystal: { odds: [0, 50, 38, 12], gp: 1 }, rainbow: { odds: [0, 0, 70, 30], gp: 1, fx: 3 }, season: { odds: [50, 30, 15, 5], season: 1 },
  };
  const SET_BONUS = 50;
  const SEED = () => ({
    v: 1, gems: 600, stars: 180, pity: 18, epic: 4,
    col: Object.fromEntries([[0, { f: { n: 1, s: 1 }, eq: 's', st: 1, xp: 160 }], [1, { f: { n: 1 }, eq: 'n', st: 2, xp: 320 }], [2, { f: { n: 1, r: 1 }, eq: 'r', st: 0, xp: 40 }], [3, { f: { n: 1 }, eq: 'n', st: 0, xp: 70 }]]
      .concat([4, 5, 7, 14, 28, 6, 10, 11, 8, 12, 22, 23, 9, 13].map(id => [id, { f: { n: 1 }, eq: 'n', st: 0, xp: (id * 37) % 90 }]))),
  });
  let S = null, pend = false;
  function emit() { if (pend) return; pend = true; setTimeout(() => { pend = false; window.dispatchEvent(new CustomEvent('squishsquad')); }, 0); }
  function load() {
    if (S) return S;
    try { S = JSON.parse(localStorage.getItem(KEY)); } catch (e) {}
    if (!S || S.v !== 1) { S = SEED(); save(true); }
    return S;
  }
  function save(silent) { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} if (!silent) emit(); }
  const prof = () => window.SquishProfile ? window.SquishProfile.get() : null;
  const API = {
    RAR, SETS, SEASON, ROSTER, STAR_PRICE, COIN_PRICE, DUPE, FIN, STAGES, STAGE_FX, CHESTS, SET_BONUS,
    stageOf(id) { const e = load().col[id]; return e ? e.st || 0 : 0; },
    headOf(id) { const c = ROSTER[id]; const v = c && (window.CREATURES_V2 || []).find(x => x.name.toLowerCase() === c.key); return v ? v.head : 20; },
    get: () => load(),
    src: id => { const c = ROSTER[id]; return c && c.art ? 'export/tripo/' + c.key + '/' + c.key + '-front.svg' : null; },
    markArt(ids) { ids.forEach(i => ART.add(i)); emit(); },
    coins() { const p = prof(); return p ? p.coins : (load().coins || 0); },
    wallet() { const s = load(); return { coins: API.coins(), gems: s.gems, stars: s.stars }; },
    add(cur, n) {
      if (cur === 'coins') { if (window.SquishProfile) window.SquishProfile.set({ coins: Math.max(0, API.coins() + n) }); else { load().coins = Math.max(0, (S.coins || 0) + n); save(); } emit(); return true; }
      const s = load(); s[cur] = Math.max(0, (s[cur] || 0) + n); save(); return true;
    },
    spend(cur, n) { const have = cur === 'coins' ? API.coins() : load()[cur] || 0; if (have < n) return false; API.add(cur, -n); return true; },
    setWallet(w) {
      const s = load(); let ch = false;
      ['gems', 'stars'].forEach(k => { if (w[k] != null && w[k] !== s[k]) { s[k] = w[k]; ch = true; } });
      if (w.coins != null && w.coins !== API.coins()) { if (window.SquishProfile) window.SquishProfile.set({ coins: w.coins }, true); else s.coins = w.coins; ch = true; }
      if (w.pity != null && w.pity !== s.pity) { s.pity = w.pity; ch = true; }
      if (ch) save();
    },
    owns(id) { if (load().col[id]) return true; const p = prof(); return !!(p && id < 30 && (p.owned || []).includes(id)); },
    entry(id) { const s = load(); if (!s.col[id] && API.owns(id)) { s.col[id] = { f: { n: 1 }, eq: 'n', st: 0, xp: 0 }; save(true); } return s.col[id] || null; },
    ownedIds() { return ROSTER.filter(c => API.owns(c.id)).map(c => c.id); },
    setInfo(key) { const st = SETS.find(s => s.key === key); const have = st.ids.filter(API.owns).length; return { have, total: st.ids.length, done: have === st.ids.length, rewardOwned: API.owns(st.reward) }; },
    grant(id, f) {
      f = f || 'n'; const s = load(); const c = ROSTER[id]; const e = API.entry(id); const out = { id, isNew: !e, newFinish: false, stars: 0, reward: null };
      if (!e) s.col[id] = { f: { n: 1, [f]: 1 }, eq: f, st: 0, xp: 0 };
      else if (!e.f[f]) { e.f[f] = 1; out.newFinish = true; }
      else out.stars = DUPE[c.rar] * (f !== 'n' ? 2 : 1);
      s.stars += out.stars;
      if (c.base) { const st = SETS.find(x => x.key === c.set); if (st && !s.col[st.reward] && st.ids.every(API.owns)) { s.col[st.reward] = { f: { n: 1 }, eq: 'n', st: 0, xp: 0 }; s.stars += SET_BONUS; out.reward = st.reward; } }
      save(); return out;
    },
    addXp(id, n) { const e = API.entry(id); if (!e || !n) return; e.xp = (e.xp || 0) + n; save(true); clearTimeout(API._xpT); API._xpT = setTimeout(emit, 400); },
    growInfo(id) {
      const e = API.entry(id); if (!e) return null; const next = STAGES[e.st + 1];
      if (!next) return { stage: e.st, max: true, xp: e.xp };
      return { stage: e.st, max: false, xp: e.xp, needXp: next.xp, needStars: next.stars, xpOk: e.xp >= next.xp, starsOk: load().stars >= next.stars, next: next.name };
    },
    grow(id) { const g = API.growInfo(id); if (!g || g.max || !g.xpOk || !g.starsOk) return false; const s = load(); s.stars -= g.needStars; s.col[id].st++; if (s.col[id].st === 2) s.stars += 0; save(); return true; },
    finishPrice(id, f) { const c = ROSTER[id]; const F = FIN.find(x => x.k === f); if (!c || !F || !F.x || c.rar > 3) return null; return STAR_PRICE[c.rar] * F.x; },
    buyFinish(id, f) { const p = API.finishPrice(id, f); const e = API.entry(id); if (!p || !e || e.f[f] || load().stars < p) return false; S.stars -= p; e.f[f] = 1; e.eq = f; save(); return true; },
    equip(id, f) { const e = API.entry(id); if (!e || !e.f[f]) return false; e.eq = f; save(); return true; },
    finishOf(id) { const e = load().col[id]; return e ? e.eq || 'n' : 'n'; },
    buy(id, cur) {
      const c = ROSTER[id]; if (!c || !c.base || !c.art || API.owns(id)) return null;
      const price = cur === 'stars' ? STAR_PRICE[c.rar] : COIN_PRICE[c.rar]; if (!price || !API.spend(cur, price)) return null;
      return API.grant(id, 'n');
    },
    roll(tier) {
      const T = CHESTS[tier] || CHESTS.basic; const s = load();
      if (T.gp) s.pity = (s.pity || 0) + 1; s.epic = (s.epic || 0) + 1;
      const odds = T.odds; let x = Math.random() * odds.reduce((a, b) => a + b, 0), r = 0;
      for (; r < 3; r++) { if (x < odds[r]) break; x -= odds[r]; }
      if (T.gp && s.pity >= 30) r = 3;
      if (r < 2 && s.epic >= 10) r = 2;
      if (r === 3) s.pity = 0; if (r >= 2) s.epic = 0;
      let pool = ROSTER.filter(c => (T.season ? c.season && !c.pass : c.base) && c.rar === r && c.art);
      if (!pool.length) pool = ROSTER.filter(c => c.base && c.art && c.rar <= r).sort((a, b) => b.rar - a.rar).filter((c, i, a) => c.rar === a[0].rar);
      const w = pool.map(c => API.owns(c.id) ? 1 : 3); let y = Math.random() * w.reduce((a, b) => a + b, 0), k = 0;
      for (; k < pool.length - 1; k++) { if (y < w[k]) break; y -= w[k]; }
      const m = T.fx || 1, fr = Math.random() * 100; const f = fr < 0.1 * m ? 'g' : fr < 0.6 * m ? 'r' : fr < 2.6 * m ? 's' : 'n';
      save(true); return { id: pool[k].id, rar: r, f };
    },
    reset() { S = SEED(); save(); },
  };
  window.addEventListener('storage', e => { if (e.key === KEY) { S = null; emit(); } if (e.key === 'squishsquad.profile.v1') emit(); });
  window.addEventListener('squishprofile', emit);
  window.SquishSquad = API;
})();
