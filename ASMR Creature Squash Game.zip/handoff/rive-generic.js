// Generic Rive-style renderer: rigs any Squish Squad creature from its own front art, driven by the same
// state machine, layers and move library as Mittens (squash, head sphere, ears, paws, feet, tail, face).
(function () {
  if (window.RiveGeneric) return;
  const cache = {};
  const load = k => cache[k] || (cache[k] = fetch('export/tripo/' + k + '/' + k + '-front.svg').then(r => r.text()).then(t => t.replace(/<metadata>[\s\S]*?<\/metadata>/, '')));
  const num = (e, a) => parseFloat(e.getAttribute(a) || '0');
  const pts = segs => segs.flatMap(g => g.p || []);
  const lerpN = (a, b, t) => a + (b - a) * t;

  const R = (o, k, v) => [].concat(v).forEach(i => o[i] = k);
  const PETS = {
    biscuit: o => { R(o, 'head', 5); R(o, 'body', [3, 4]); R(o, 'tail', 0); R(o, 'foot', [1, 2]); R(o, 'pad', [16, 17, 18, 19, 20, 21]); R(o, 'earF', [6, 7]); R(o, 'patch', [8, 9]); R(o, 'arm', [10, 11]); R(o, 'hide', 15); R(o, 'body', 22); R(o, 'swing', 23); },
    prickle: o => { R(o, 'head', 3); R(o, 'mane', 2); R(o, 'foot', [0, 1]); R(o, 'patch', 4); R(o, 'arm', [5, 6]); },
    nibbles: o => { R(o, 'head', 6); R(o, 'body', [2, 3]); R(o, 'foot', [0, 1]); R(o, 'earP', [4, 5]); R(o, 'inner4', 10); R(o, 'inner5', 11); R(o, 'patch', 7); R(o, 'arm', [8, 9]); },
    quill: o => { R(o, 'mane', 0); R(o, 'foot', [1, 2]); R(o, 'body', [3, 4]); R(o, 'earP', [5, 6]); R(o, 'inner5', 11); R(o, 'inner6', 12); R(o, 'head', 7); R(o, 'patch', 8); R(o, 'arm', [9, 10]); },
    waffles: o => { R(o, 'body', [0, 1]); R(o, 'foot', [2, 3]); R(o, 'earP', [4, 5]); R(o, 'inner4', 6); R(o, 'inner5', 7); R(o, 'head', 8); R(o, 'patch', 9); o.synth = 1; },
    poppy: o => { R(o, 'foot', [0, 1]); R(o, 'earP', [2, 3]); R(o, 'head', 4); R(o, 'patch', [5, 6, 7, 8]); R(o, 'arm', [9, 10]); },
    duchess: o => { R(o, 'tail', 0); R(o, 'foot', [1, 2]); R(o, 'body', [3, 11, 12]); R(o, 'arm', [4, 5]); R(o, 'earP', [6, 7]); R(o, 'inner6', 8); R(o, 'inner7', 9); R(o, 'head', 10); R(o, 'crown', [13, 14, 15, 16]); },
    mamapaws: o => { R(o, 'foot', [0, 1]); R(o, 'body', [2, 3]); R(o, 'arm', [4, 5]); R(o, 'head', 6); R(o, 'earF', [7, 8]); R(o, 'patch', 9); R(o, 'pup', [11, 12, 13, 16, 17, 18, 19, 20, 21]); R(o, 'pupEye', [14, 15]); },
  };
  function build(I, root, key, H) {
    const { mk, ellS, toD, parsePath, ellAx, SM, clamp, lerp, r2, D2R, TAU } = H;
    I.shadow = mk('ellipse', { fill: '#6a1b9a', opacity: 0.2 }, root);
    const art = mk('g', {}, root); I.fxG = mk('g', {}, root); I.pg = {}; I.E = {};
    load(key).then(txt => {
      if (!I.fxG.isConnected && !root.isConnected) return; const p = '_g' + I.u;
      txt = txt.replace(/id="([^"]+)"/g, (m, id) => 'id="' + id + p + '"').replace(/url\(#([^)]+)\)/g, (m, id) => 'url(#' + id + p + ')');
      const tmp = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); tmp.innerHTML = txt.replace(/^[\s\S]*?<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '');
      while (tmp.firstChild) art.appendChild(tmp.firstChild);
      if (PETS[key]) { const o = {}; PETS[key](o); I.petRoles = new Map(); [...art.querySelectorAll('path,ellipse,circle,rect')].filter(e => !e.closest('defs')).forEach((e, i) => { if (o[i]) I.petRoles.set(e, o[i]); });
        if (o.synth) { const bg = art.querySelector('g[filter]'), main = bg && bg.querySelector('path'); const f = main ? main.getAttribute('fill') : '#e0a060';
          [[36, 74, 15], [64, 74, -15]].forEach(([x, y, rt]) => { const el = document.createElementNS('http://www.w3.org/2000/svg', 'ellipse'); el.setAttribute('cx', x); el.setAttribute('cy', y); el.setAttribute('rx', 5.5); el.setAttribute('ry', 7.5); el.setAttribute('transform', 'rotate(' + rt + ' ' + x + ' ' + y + ')'); el.setAttribute('fill', f); bg.appendChild(el); I.petRoles.set(el, 'arm'); }); } }
      setup(I, root, art, key, H, 0);
    }).catch(e => console.error('RiveGeneric load', key, e));
  }

  function setup(I, root, art, key, H, n) {
    const { mk, ellS, toD, parsePath, clamp, D2R } = H;
    const bodyG = art.querySelector('g[filter]'); let BB = null; try { BB = (bodyG || art).getBBox(); } catch (e) {}
    if (!BB || BB.width < 5) { if (n < 50) setTimeout(() => setup(I, root, art, key, H, n + 1), 100); return; }
    const v2 = (window.CREATURES_V2 || []).find(c => c.name.toLowerCase() === key) || {};
    const eyesEl = [...art.querySelectorAll('[fill^="url(#ey"]')];
    const EY = (v2.eyes && v2.eyes.length ? v2.eyes : eyesEl.map(e => ({ x: num(e, 'cx'), y: num(e, 'cy'), r: num(e, 'r') || 4.6 }))).slice(0, 2);
    const eyeY = EY.length ? EY.reduce((s, e) => s + e.y, 0) / EY.length : 50, ex = EY.length ? EY.reduce((s, e) => s + e.x, 0) / EY.length : 50;
    const area = BB.width * BB.height, G = BB.y + BB.height, TOP = BB.y;
    const hide = new Set(); eyesEl.forEach(e => { hide.add(e); let s = e.nextElementSibling; for (let j = 0; j < 2 && s; j++, s = s.nextElementSibling) if ((s.getAttribute('fill') || '') === '#fff') hide.add(s); });
    const items = [];
    art.querySelectorAll('path,ellipse,circle,rect').forEach(e => {
      const inClip = !!e.closest('clipPath'); if (e.closest('defs') && !inClip) return;
      const tag = e.tagName.toLowerCase(), fill = e.getAttribute('fill') || '', inBody = !!e.closest('g[filter]'), tr = e.getAttribute('transform') || '';
      const rm = tr.match(/rotate\(([-\d.]+)/); let b; try { b = e.getBBox(); } catch (x) { b = { x: 0, y: 0, width: 0, height: 0 }; }
      const it = { e, tag, inBody, rot: rm ? +rm[1] : null, cx: b.x + b.width / 2, cy: b.y + b.height / 2, b, a: b.width * b.height, op: e.getAttribute('opacity'), fill };
      if (tag === 'circle' || tag === 'ellipse') { it.ox = num(e, 'cx'); it.oy = num(e, 'cy'); it.rx = tag === 'circle' ? num(e, 'r') : num(e, 'rx'); it.ry = tag === 'circle' ? it.rx : num(e, 'ry'); it.cx = it.ox; it.cy = it.oy; }
      if (hide.has(e) || e.getAttribute('stroke') === '#6a3a3a') { e.style.display = 'none'; return; }
      const pr = I.petRoles && I.petRoles.get(e);
      if (pr === 'hide') { e.style.display = 'none'; return; }
      if (pr) { it.role = pr === 'head' ? 'body' : pr; it.pet = pr; if (it.ox == null) { it.ox = it.cx; it.oy = it.cy; it.rx = it.b.width / 2; it.ry = it.b.height / 2; } if (/^inner/.test(pr)) { it.role = 'inner'; it.ownerIdx = +pr.slice(5); } if (pr === 'arm') { it.side = (it.ox != null ? it.ox : it.cx) < 50 ? -1 : 1; const a = (it.rot || 0) * D2R; it.hx = it.ox - Math.sin(a) * it.ry; it.hy = it.oy + Math.cos(a) * it.ry; } if (/^ear/.test(pr) || pr === 'tail' || pr === 'swing') it.side = it.cx < 50 ? -1 : 1; }
      else if (inClip) it.role = 'body';
      else if (tag === 'ellipse' && /^#ff8fa3/i.test(fill)) { it.role = 'cheek'; it.side = it.ox < ex ? -1 : 1; }
      else if (!inBody && tag === 'ellipse' && fill.indexOf('#fff') === 0 && it.op) it.role = 'shine';
      else if (inBody && tag === 'ellipse' && it.rot != null && fill.indexOf('#fff') !== 0 && !it.op) { it.role = 'arm'; it.side = it.ox < 50 ? -1 : 1; const a = it.rot * D2R; it.hx = it.ox - Math.sin(a) * it.ry; it.hy = it.oy + Math.cos(a) * it.ry; }
      else if (inBody && tag === 'ellipse' && it.rot == null && it.oy >= G - 14 && it.rx >= 4) it.role = 'foot';
      else if (it.cy < eyeY - 12 && it.a < area * 0.22 && !(!inBody && Math.abs(it.cx - 50) < 4)) { it.role = 'top'; it.side = Math.abs(it.cx - 50) < 4 ? 0 : (it.cx < 50 ? -1 : 1); }
      else if (inBody && it.cy > eyeY - 4 && (it.cx < BB.x + BB.width * 0.2 || it.cx > BB.x + BB.width * 0.8) && it.a < area * 0.12) { it.role = 'side'; it.side = it.cx < 50 ? -1 : 1; }
      else it.role = inBody || inClip ? 'body' : 'face';
      // every shape becomes a path so it can bend with the mesh
      if (tag === 'path') it.segs = parsePath(e.getAttribute('d') || '');
      else if (tag === 'rect') { const x = num(e, 'x'), y = num(e, 'y'), w = num(e, 'width'), h = num(e, 'height'); it.segs = parsePath('M' + x + ' ' + y + ' L' + (x + w) + ' ' + y + ' L' + (x + w) + ' ' + (y + h) + ' L' + x + ' ' + (y + h) + ' Z'); }
      else it.segs = ellS(it.ox, it.oy, it.rx, it.ry, it.rot || 0, it.a > area * 0.12 ? 16 : 8);
      if (tag !== 'path' && !inClip) { const pth = document.createElementNS('http://www.w3.org/2000/svg', 'path'); for (const at of e.attributes) if (!/^(cx|cy|r|rx|ry|x|y|width|height|transform)$/.test(at.name)) pth.setAttribute(at.name, at.value); e.parentNode.replaceChild(pth, e); it.e = pth; }
      else if (tag !== 'path' && inClip) { const pth = document.createElementNS('http://www.w3.org/2000/svg', 'path'); e.parentNode.replaceChild(pth, e); it.e = pth; }
      if (tag === 'path') it.e.removeAttribute('transform');
      items.push(it);
    });
    items.filter(q => q.role === 'arm').forEach(a => items.forEach(q => { if ((q.role === 'body' || q.role === 'foot') && q.tag === 'circle' && Math.hypot(q.ox - a.hx, q.oy - a.hy) < 7) { q.role = 'hand'; q.owner = a; q.side = a.side; } }));
    const anchors = items.filter(q => q.role === 'body' && q.inBody && q.fill !== 'none' && q.a > area * 0.14).map(q => ({ q, cx: q.cx, cy: q.cy, hx: q.b.width / 2, hy: q.b.height / 2, a: q.a }));
    const dn = (x, y) => anchors.reduce((m, A) => Math.min(m, Math.hypot((x - A.cx) / A.hx, (y - A.cy) / A.hy)), 9);
    const petHead = items.find(q => q.pet === 'head'); if (petHead && !anchors.some(A => A.q === petHead)) anchors.push({ q: petHead, cx: petHead.cx, cy: petHead.cy, hx: petHead.b.width / 2, hy: petHead.b.height / 2, a: petHead.a });
    const headA = petHead ? anchors.find(A => A.q === petHead) : anchors.filter(A => Math.hypot((ex - A.cx) / A.hx, (eyeY - A.cy) / A.hy) < 1).sort((a, b) => a.a - b.a)[0] || anchors.slice().sort((a, b) => b.a - a.a)[0];
    const main = anchors.slice().sort((a, b) => b.a - a.a)[0];
    if (headA) { headA.q.role = 'head'; const hdS = headA.q.e.getAttribute('d') || JSON.stringify(headA.q.segs); items.forEach(q => { if (q.e.closest('clipPath') && q.tag === 'path' && JSON.stringify(q.segs) === JSON.stringify(headA.q.segs)) q.role = 'headDup'; }); }
    const inHead = (x, y) => headA && Math.hypot((x - headA.cx) / headA.hx, (y - headA.cy) / headA.hy) < 1.04;
    items.forEach(q => { if (q.role === 'body' && q.inBody && !anchors.some(A => A.q === q) && q.a >= 1) { const b = q.b; if ([[b.x, b.y], [b.x + b.width, b.y], [b.x, b.y + b.height], [b.x + b.width, b.y + b.height]].every(([x, y]) => inHead(x, y))) q.role = 'patch'; }
      if (q.role === 'face' && !inHead(q.cx, q.cy) && !q.pet) q.role = 'deco'; if (q.role === 'shine' && !inHead(q.cx, q.cy)) q.role = 'body'; });
    // roots for parts that bend (ears, horns, tails, fins)
    const skin = q => { const P = pts(q.segs), d = P.map(p => dn(p[0], p[1])); const ins = P.filter((p, i) => d[i] < 1); let R;
      if (ins.length) R = ins.reduce((s, p) => [s[0] + p[0] / ins.length, s[1] + p[1] / ins.length], [0, 0]); else { let m = 0; d.forEach((v, i) => { if (v < d[m]) m = i; }); R = P[m]; }
      q.R = R; q.L = Math.max(1, ...P.map(p => Math.hypot(p[0] - R[0], p[1] - R[1]))); q.wt = P.map((p, i) => Math.pow(clamp(Math.hypot(p[0] - R[0], p[1] - R[1]) / q.L, 0, 1), 1.3) * clamp((d[i] - 0.85) / 0.4, 0, 1)); };
    [-1, 0, 1].forEach(sd => { const tops = items.filter(q => q.role === 'top' && q.side === sd); if (!tops.length) return; const big = tops.reduce((m, q) => q.a > m.a ? q : m); skin(big);
      tops.forEach(q => { if (q === big) return; if (Math.hypot(q.cx - big.cx, q.cy - big.cy) < 26) { q.owner = big; q.R = big.R; q.L = big.L; q.wt = pts(q.segs).map(p => Math.pow(clamp(Math.hypot(p[0] - big.R[0], p[1] - big.R[1]) / big.L, 0, 1), 1.3)); } else skin(q); }); });
    items.forEach(q => { if (q.role === 'side' || q.role === 'tail') skin(q); });
    const { earSec, flat } = H, allOrig = I.petRoles ? [...I.petRoles.keys()] : [];
    const els = I.petRoles ? [...art.querySelectorAll('path,ellipse,circle,rect')].filter(e => !e.closest('defs')) : [];
    items.forEach(q => { if (q.role !== 'earP' && q.role !== 'earF') return; const P = flat(q.segs, 14); const Hc = headA ? [headA.cx, headA.cy] : [50, 50], Hr = headA ? Math.max(headA.hx, headA.hy) : 26;
      const ins = P.filter(p => Math.hypot(p[0] - Hc[0], p[1] - Hc[1]) < Hr * 0.98);
      let piv; if (q.role === 'earF') { const top = P.slice().sort((a, b) => a[1] - b[1]).slice(0, Math.max(3, Math.round(P.length * 0.15))); piv = top.reduce((s, p) => [s[0] + p[0] / top.length, s[1] + p[1] / top.length], [0, 0]); piv = [lerpN(piv[0], Hc[0], 0.25), piv[1] + 3]; }
      else piv = ins.length ? ins.reduce((s, p) => [s[0] + p[0] / ins.length, s[1] + p[1] / ins.length], [0, 0]) : P.reduce((m, p) => Math.hypot(p[0] - Hc[0], p[1] - Hc[1]) < Math.hypot(m[0] - Hc[0], m[1] - Hc[1]) ? p : m, P[0]);
      const tip = P.reduce((m, p) => Math.hypot(p[0] - piv[0], p[1] - piv[1]) > Math.hypot(m[0] - piv[0], m[1] - piv[1]) ? p : m, P[0]), vx = tip[0] - piv[0], vy = tip[1] - piv[1], len = Math.hypot(vx, vy) || 1;
      if (!(len > 1) || !isFinite(piv[0]) || !isFinite(piv[1])) { q.role = 'top'; q.side = q.cx < 50 ? -1 : 1; return; }
      Object.assign(q, { pivot: piv, ux: vx / len, uy: vy / len, len }); q.S = earSec(q, P); if (!q.S.secs.length || q.S.secs.some(sc => !isFinite(sc.cx) || !isFinite(sc.hw))) { q.role = 'top'; q.side = q.cx < 50 ? -1 : 1; delete q.S; return; }
      const cid = 'gek' + I.u + '_' + items.indexOf(q); q.clipId = cid; });
    items.forEach(q => { if (q.role === 'inner') { const ow = items.find(z => z.e === els[q.ownerIdx] || (z.pet && els.indexOf(z.e) === q.ownerIdx)); q.owner = ow || items.find(z => (z.role === 'earP' || z.role === 'earF') && Math.abs(z.cx - q.cx) < 10); } });
    items.forEach(q => { if (q.role === 'pad') { const fts = items.filter(z => z.role === 'foot'); q.owner = fts.reduce((m, z) => !m || Math.abs(z.ox - q.cx) < Math.abs(m.ox - q.cx) ? z : m, null); } });
    const swingQ = items.filter(q => q.role === 'swing'); swingQ.forEach(q => { q.piv = [q.cx, q.b.y - 1]; });
    const crown = items.filter(q => q.role === 'crown'); if (crown.length) { const bx = Math.min(...crown.map(q => q.b.x)), bw = Math.max(...crown.map(q => q.b.x + q.b.width)) - bx, by = Math.max(...crown.map(q => q.b.y + q.b.height)); crown.forEach(q => { q.base = [bx + bw / 2, by]; }); }
    const pups = items.filter(q => q.role === 'pup' || q.role === 'pupEye'); if (pups.length) { const ys = pups.map(q => q.cy); I.pupC = [pups.reduce((s, q) => s + q.cx, 0) / pups.length, Math.max(...ys)]; }
    const sides = items.filter(q => q.role === 'side'); sides.forEach(q => { q.limb = !items.some(z => z.role === 'arm') && sides.some(o => o !== q && o.side === -q.side && Math.abs(o.cx - (100 - q.cx)) < 9); });
    // move paws on top of the face so they can reach the mouth; food goes between face and paws
    const filt = bodyG ? bodyG.getAttribute('filter') : null, arms = items.filter(q => q.role === 'arm' || q.role === 'hand');
    I.faceG = mk('g', {}, art); I.pg.prop = mk('g', {}, art); const armG = mk('g', filt ? { filter: filt } : {}, art);
    arms.forEach(q => armG.appendChild(q.e));
    // geometry
    const HX = headA ? headA.cx : 50, HY = headA ? headA.cy : 50, HR = headA ? Math.max(headA.hx, headA.hy) : 26;
    const armL = items.find(q => q.role === 'arm' && q.side < 0), armR = items.find(q => q.role === 'arm' && q.side > 0);
    const MO = v2.mouth || { x: ex, y: eyeY + 9, w: 9.6 };
    const pawY = armL ? (armL.oy + (armR ? armR.oy : armL.oy)) / 2 : Math.min(G - 10, MO.y + 18), pawX = armL ? armL.ox : 50 - Math.min(18, BB.width * 0.32);
    const MY = [17, 47, 58, 76, 95.5], CY = [TOP, eyeY, MO.y, pawY, G].map((v, i, a) => i && v <= a[i - 1] ? a[i - 1] + 1 : v);
    const pl = (A, B, v) => { if (v <= A[0]) return B[0] + (v - A[0]) * ((B[1] - B[0]) / (A[1] - A[0])); for (let i = 1; i < A.length; i++) if (v <= A[i] || i === A.length - 1) return B[i - 1] + (v - A[i - 1]) * (B[i] - B[i - 1]) / (A[i] - A[i - 1]); };
    const kx = Math.max(0.5, Math.abs(50 - pawX) / 18);
    I.mapHand = (inX, hy) => [inX * kx, pl(MY, CY, 76 + hy) - pawY];
    I.toM = (x, y) => [50 + (x - HX) / HR * 29, pl(CY, MY, y)];
    I.fromM = (x, y) => [HX + (x - 50) / 29 * HR, pl(MY, CY, y)];
    I.geo = { HX, HY, HR, G, TOP, eyeY, MO, EY, NY: headA ? HY + HR * 0.82 : HY + HR * 0.6, main, headA, pawY, pawX, BB };
    const tubeCol = q => { const f = q.fill || ''; const m = f.match(/url\(#([^)]+)\)/); if (!m) return f || '#e0b080'; const gEl = art.querySelector('[id="' + m[1] + '"]'); const st = gEl ? [...gEl.querySelectorAll('stop')] : []; return st.length ? st[Math.min(st.length - 1, Math.floor(st.length * 0.6))].getAttribute('stop-color') : '#e0b080'; };
    I.tubes = [armL, armR].map(a => a ? mk('path', { fill: 'none', stroke: tubeCol(a), 'stroke-linecap': 'round', opacity: 0 }, armG) : null);
    I.tubes.forEach(t => t && armG.insertBefore(t, armG.firstChild));
    // the rig's own face: eyes with lids, morphing mouth, tongue, tear pools, tints
    const defs = mk('defs', {}, I.faceG); const u = I.u;
    defs.innerHTML = '<radialGradient id="gey' + u + '" cx="35%" cy="30%" r="70%"><stop offset="0" stop-color="#6b5470"/><stop offset="1" stop-color="#2a1a30"/></radialGradient><clipPath id="ghc' + u + '" clipPathUnits="userSpaceOnUse"><path/></clipPath>' + EY.map((e, i) => '<clipPath id="gec' + i + u + '" clipPathUnits="userSpaceOnUse"><path/></clipPath>').join('');
    I.headClip = defs.querySelector('#ghc' + u + ' path');
    const fg = mk('g', { 'clip-path': 'url(#ghc' + u + ')' }, I.faceG); const E = I.E;
    E.tintR = mk('path', { fill: '#ff4040', opacity: 0 }, fg); E.tintG = mk('path', { fill: '#93b84a', opacity: 0 }, fg);
    E.eyes = EY.map((e, i) => { const gg = mk('g', {}, fg), el = mk('path', { fill: 'url(#gey' + u + ')', stroke: '#2a1a30', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, gg), hg = mk('g', { 'clip-path': 'url(#gec' + i + u + ')' }, gg);
      return { g: gg, e: el, tp: mk('path', { fill: '#a8dcff', opacity: 0 }, hg), h1: mk('path', { fill: '#fff' }, hg), h2: mk('path', { fill: '#fff' }, hg), clip: defs.querySelector('#gec' + i + u + ' path') }; });
    E.mopen = mk('path', { fill: '#7a2a40' }, fg); E.tongue = mk('path', { fill: '#ff8fa3' }, fg);
    E.mouth = mk('path', { fill: 'none', stroke: v2.mouthInk || '#6a3a3a', 'stroke-width': 1.2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, fg);
    E.tout = mk('path', { fill: '#ff7f9a', stroke: '#e0607e', 'stroke-width': 0.3, opacity: 0 }, fg);
    if (main) { E.bodyG = mk('path', { fill: '#93b84a', opacity: 0 }, main.q.e.parentNode); main.q.e.parentNode.insertBefore(E.bodyG, main.q.e.nextSibling); }
    items.forEach(q => { if (q.role === 'patch' || q.role === 'face' || q.role === 'cheek') q.e.setAttribute('clip-path', 'url(#ghc' + u + ')'); });
    const cdefs = mk('defs', {}, art); items.forEach(q => { if (q.clipId) { cdefs.innerHTML += '<clipPath id="' + q.clipId + '" clipPathUnits="userSpaceOnUse"><path/></clipPath>'; } });
    items.forEach(q => { if (q.clipId) q.clipEl = cdefs.querySelector('#' + q.clipId + ' path'); if (q.role === 'inner' && q.owner && q.owner.clipId) q.e.setAttribute('clip-path', 'url(#' + q.owner.clipId + ')'); });
    I.items = items; I.render = render(H); I.ready = true;
  }

  const render = H => (I, P, now) => {
    const { toD, ellS, parsePath, ellAx, SM, clamp, lerp, r2, D2R, TAU } = H, g = I.geo, set = (e, a, v) => e.setAttribute(a, v);
    const G = g.G, Hh = G - g.TOP, HX = g.HX, HY = g.HY, SR = g.HR + 0.5, NX = HX, NY = g.NY;
    const yb = P.spin * D2R, yh = yb + P.turn * 40 * D2R, ph = P.pitch * 22 * D2R, cyb = Math.cos(yb), syb = Math.sin(yb), cyh = Math.cos(yh), syh = Math.sin(yh), cp = Math.cos(ph), sp = Math.sin(ph);
    const sq = clamp(P.sq, -0.25, 0.45), sy = 1 - sq, tr = P.tilt * D2R, ct = Math.cos(tr), stt = Math.sin(tr), dn = I.dent && I.dent.a > 0.01 ? I.dent : null;
    const dnP = dn ? (I.fromM ? null : null) : null;
    const glob = (x, y) => {
      if (dn) { const ddx = x - dn.x, ddy = y - dn.y, gg = Math.exp(-(ddx * ddx + ddy * ddy) / 90); if (gg > 0.01) { const vx = HX - dn.x, vy = (HY + G) / 2 - dn.y, L = Math.hypot(vx, vy) || 1; x += vx / L * dn.a * 4.5 * gg; y += vy / L * dn.a * 4.5 * gg; } }
      const u = clamp((G - y) / Hh, 0, 1), k = 1 + sq * (0.45 + 0.6 * 4 * u * (1 - u)), X = (x - 50) * k + P.lean * Math.pow(u, 1.5), Y = -(G - y) * sy;
      return [50 + X * ct - Y * stt + P.x, G + X * stt + Y * ct - P.lift]; };
    const hs = I.hs, hr = P.htilt * D2R, chr = Math.cos(hr), shr = Math.sin(hr), hyo = -P.pitch * 1.1;
    const headT = (x, y) => { x = HX + (x - HX) * (1 + hs * 0.6); y = NY - (NY - y) * (1 - hs) + hyo; const dx = x - NX, dy = y - NY; return glob(NX + dx * chr - dy * shr, NY + dx * shr + dy * chr); };
    const sz = (dx, dy, zm) => { if (typeof zm === 'number') return zm; const q = SR * SR - dx * dx - dy * dy, z = q > 0 ? Math.sqrt(q) : 0; return zm === 'b' ? -z : z; };
    const sph = (x, y, zm) => { const dx = x - HX, dy = y - HY, z = sz(dx, dy, zm), x1 = dx * cyh + z * syh, z1 = -dx * syh + z * cyh; return headT(HX + x1, HY + dy * cp - z1 * sp); };
    const sphZ = (x, y, zm) => { const dx = x - HX, dy = y - HY, z = sz(dx, dy, zm), z1 = -dx * syh + z * cyh; return dy * sp + z1 * cp; };
    const face = (x, y) => sph(x, y), vis = z => SM((z - 1.5) / 6), zc = (x, y) => vis(sphZ(x, y));
    const zmS = (x, y) => { const dx = x - HX, dy = y - HY, q = SR * SR - dx * dx - dy * dy; return q > 0 ? -0.35 * Math.sqrt(q) : 0; };
    const byw = (x, y, z) => glob(50 + (x - 50) * cyb + z * syb, y), bywZ = (x, z) => -(x - 50) * syb + z * cyb;
    const pf = clamp(P.puff, -0.5, 1.2), MO = g.MO, W = I.W = {};
    const bend = (q, a) => (x, y, i) => { const w = q.wt ? (q.wt[i] || 0) : 1, R = q.R; if (!R || Math.abs(a * w) < 1e-4) return [x, y]; const c = Math.cos(a * w), s = Math.sin(a * w), vx = x - R[0], vy = y - R[1]; return [R[0] + vx * c - vy * s, R[1] + vx * s + vy * c]; };
    const mapSeg = (segs, F) => { let i = 0; return toD(segs, (x, y) => F(x, y, i++)); };
    let headD = '';
    for (const q of I.items) {
      const e = q.e;
      switch (q.role) {
        case 'head': { headD = toD(q.segs, pf ? (x, y) => { const dy = y - MO.y, gg = Math.exp(-dy * dy / 80); return headT(x + (x < HX ? -1 : 1) * pf * 3.2 * gg * clamp(Math.abs(x - HX) / 20, 0, 1), y); } : headT); set(e, 'd', headD); break; }
        case 'body': case 'shine': case 'deco': set(e, 'd', toD(q.segs, glob)); break;
        case 'patch': case 'face': set(e, 'd', toD(q.segs, face)); set(e, 'opacity', r2((q.op ? +q.op : 1) * zc(q.cx, q.cy))); break;
        case 'cheek': { const k = 1 + Math.max(0, pf) * 0.35; set(e, 'd', toD(ellS(q.ox + q.side * Math.max(0, pf) * 1.2, q.oy - clamp(P.smile, 0, 1) * 0.6, q.rx * k, q.ry * k, 0, 8), face)); set(e, 'opacity', r2(clamp((q.op ? +q.op : 0.5) + clamp(P.blush, 0, 1) * 0.45 + Math.max(0, pf) * 0.25 + clamp(P.red, 0, 1) * 0.3, 0, 1) * zc(q.ox, q.oy))); break; }
        case 'top': { const o = q.owner || q, a = (o.side < 0 ? -P.earL : o.side > 0 ? P.earR : (P.earR - P.earL) * 0.5) * D2R, B = bend(q, a);
          set(e, 'd', mapSeg(q.segs, (x, y, i) => { const p = B(x, y, i); return inHeadPt(g, p[0], p[1]) ? sph(p[0], p[1], zmS(p[0], p[1])) : sph(p[0], p[1], 0); })); break; }
        case 'side': { const a = q.limb ? ((q.side < 0 ? P.armL : -P.armR) * 0.75 + (q.side < 0 ? 1 : -1) * Math.max(0, -(q.side < 0 ? P.hLy : P.hRy)) * 1.6) * D2R : (q.side > 0 ? 1 : -1) * (P.wag * 0.6 + (q.side > 0 ? P.curl : -P.curl) * -18) * D2R, B = bend(q, a);
          if (q.limb) { const P0 = pts(q.segs), far = P0.reduce((m, p) => Math.hypot(p[0] - q.R[0], p[1] - q.R[1]) > Math.hypot(m[0] - q.R[0], m[1] - q.R[1]) ? p : m, q.R), fi = P0.indexOf(far), tp = B(far[0], far[1], fi); W[q.side < 0 ? 'pawL' : 'pawR'] = byw(tp[0], tp[1], 4); } set(e, 'd', mapSeg(q.segs, (x, y, i) => { const p = B(x, y, i); return byw(p[0], p[1], -7); })); break; }
        case 'earP': case 'earF': { const fl = q.role === 'earF', side = q.side, a = (fl ? (side < 0 ? P.earL : -P.earR) * 0.9 : (side < 0 ? -P.earL : P.earR)) * D2R, [px, py] = q.pivot, S2 = q.S, out = [], lim = SR * SR * 0.81;
          const bnd = (x, y, w) => { const vx = x - px, vy = y - py, c = Math.cos(a * w), s = Math.sin(a * w); return [px + vx * c - vy * s, py + vx * s + vy * c]; };
          for (const sc of S2.secs) { const w = Math.pow(sc.s, 1.3), c = Math.cos(a * w), s = Math.sin(a * w), nx = S2.nx * c - S2.ny * s, ny = S2.nx * s + S2.ny * c, [cx, cy] = bnd(sc.cx, sc.cy, w);
            for (let k2 = 0; k2 < 12; k2++) { const f = k2 / 12 * TAU, cf = Math.cos(f), X = cx + nx * sc.hw * cf, Y = cy + ny * sc.hw * cf, Z = zmS(X, Y) - sc.hd * 0.15 + sc.hd * Math.sin(f) * (fl ? 0.7 : 1), dx = X - HX, dy = Y - HY; if (fl || dx * dx + dy * dy + Z * Z >= lim) out.push(sph(X, Y, Z)); } }
          const hd = H.closedD(H.hull(out)); set(e, 'd', hd); if (q.clipEl) set(q.clipEl, 'd', hd); q._bnd = bnd; q._a = a; break; }
        case 'inner': { const o = q.owner; if (!o || !o._bnd) { set(e, 'd', toD(q.segs, face)); break; } const [px, py] = o.pivot; set(e, 'd', toD(q.segs, (x, y) => { const s0 = clamp(((x - px) * o.ux + (y - py) * o.uy) / o.S.amax, 0, 1), p = o._bnd(x, y, Math.pow(s0, 1.3)); return sph(p[0], p[1], zmS(p[0], p[1]) + 2.5); })); set(e, 'opacity', r2((q.op ? +q.op : 1) * SM(cyh * cp * 3))); break; }
        case 'tail': { const sd = q.side > 0 ? 1 : -1, a = sd * (P.wag * 1.1 - P.curl * 26) * D2R, B = bend(q, a); set(e, 'd', mapSeg(q.segs, (x, y, i) => { const p = B(x, y, i); return byw(p[0], p[1], -9); })); break; }
        case 'mane': { const k = 1 + clamp(P.wide, 0, 1) * 0.1 + Math.max(0, sq) * 0.06, rp = 0.03 + clamp(P.wide, 0, 1) * 0.05, tt = now / 260; set(e, 'd', toD(q.segs, (x, y) => { const dx = x - HX, dy = y - HY, rr = Math.hypot(dx, dy) || 1, th = Math.atan2(dy, dx), m = k * (1 + rp * Math.sin(th * 7 - tt)) + (I.ed || 0) * 0.004 * Math.cos(th); return headT(HX + dx * m, HY + dy * m); })); break; }
        case 'pad': { const f = q.owner; if (!f) { set(e, 'd', toD(q.segs, glob)); break; } const L = f.ox < 50, lift = L ? P.footL : P.footR, X = 50 + (f.ox - 50) * cyb + 7 * syb; set(e, 'd', toD(q.segs, (x, y) => glob(X + (x - f.ox) * cyb, y - lift))); set(e, 'opacity', r2(SM(cyb * 3))); break; }
        case 'swing': { const ang = (-(I.ed || 0) * 5 + Math.sin(now / 380) * 3 + P.lean * 1.5) * D2R, [px, py] = q.piv, c = Math.cos(ang), s = Math.sin(ang); set(e, 'd', toD(q.segs, (x, y) => { const vx = x - px, vy = y - py; return glob(px + vx * c - vy * s, py + vx * s + vy * c); })); break; }
        case 'crown': { const ang = ((P.earR - P.earL) * 0.25 - (I.ed || 0) * 2.5 + P.htilt * 0.3) * D2R, [bx, by] = q.base, c = Math.cos(ang), s = Math.sin(ang); set(e, 'd', toD(q.segs, (x, y) => { const vx = x - bx, vy = y - by; return sph(bx + vx * c - vy * s, by + vx * s + vy * c + Math.min(0, sq) * 2, -3); })); break; }
        case 'pup': case 'pupEye': { const bob = Math.sin(now / 520) * 0.7 - (I.ld || 0) * 0.25, pc = I.pupC || [50, 70], bl = q.role === 'pupEye' && (now % 3400) < 150 ? 0.12 : 1;
          set(e, 'd', toD(q.segs, (x, y) => glob(x + Math.sin(now / 700) * 0.4, (q.role === 'pupEye' ? q.cy + (y - q.cy) * bl : y) + bob))); break; }
        case 'foot': { const L = q.ox < 50, cy0 = q.oy - (L ? P.footL : P.footR), z = 6, X = 50 + (q.ox - 50) * cyb + z * syb; set(e, 'd', toD(ellAx(X, cy0, [[q.rx * cyb, 0], [0, q.ry], [q.rx * 0.9 * syb, 0]]), glob)); break; }
      }
    }
    if (headD) { set(I.headClip, 'd', headD); I.items.forEach(q => { if (q.role === 'headDup') set(q.e, 'd', headD); }); }
    // paws: reach anywhere (offsets remapped from Mittens' proportions), stay round, linked to the shoulder by a soft tube
    const arms = I.items.filter(q => q.role === 'arm'); const ed = I.ed || 0;
    arms.forEach(a => { const Lf = a.side < 0, ang = (Lf ? P.armL : -P.armR) * D2R, c = Math.cos(ang), s = Math.sin(ang), px = a.hx, py = a.hy, [ox, oy] = I.mapHand(Lf ? P.hLx : -P.hRx, Lf ? P.hLy : P.hRy), hz = Lf ? P.hLz : P.hRz;
      const vx = a.ox - px, vy = a.oy - py, cx = px + vx * c - vy * s + (Lf ? ox : -ox) + ed * 0.35, cy = py + vx * s + vy * c + oy, z = 9 + hz + Math.max(0, -oy) * 0.25, ddx = cx - px, ddy = cy - py, len = Math.hypot(ddx, ddy);
      let r0 = (a.rot || 0) * D2R + ang; if (len > 9) { const want = Math.atan2(ddy, ddx) - Math.PI / 2; let df = want - r0; df = ((df % TAU) + TAU * 1.5) % TAU - Math.PI; r0 += df * SM((len - 9) / 8); }
      const c0 = Math.cos(r0), s0 = Math.sin(r0), ax = [[a.rx * c0, a.rx * s0, 0], [-a.ry * s0, a.ry * c0, 0], [0, 0, a.rx * 1.05]].map(([x, y, zz]) => [x * cyb + zz * syb, y]);
      const PX = 50 + (cx - 50) * cyb + z * syb, Pw = glob(PX, cy), zv = bywZ(cx, z); set(a.e, 'd', toD(ellAx(PX, cy, ax), glob)); set(a.e, 'opacity', zv < -3 ? 0 : 1);
      I.items.forEach(hq => { if (hq.role === 'hand' && hq.owner === a) { const hvx = hq.ox - px, hvy = hq.oy - py, hx = px + hvx * c - hvy * s + (cx - (px + vx * c - vy * s)), hy2 = py + hvx * s + hvy * c + (cy - (py + vx * s + vy * c)); set(hq.e, 'd', toD(ellAx(50 + (hx - 50) * cyb + z * syb, hy2, [[hq.rx, 0], [0, hq.ry]]), glob)); set(hq.e, 'opacity', zv < -3 ? 0 : 1); } });
      const tb = I.tubes[Lf ? 0 : 1]; if (tb) { const Sw = byw(px - a.side * 1.2, py + 1.5, 4), mx = (Sw[0] + Pw[0]) / 2, my = (Sw[1] + Pw[1]) / 2, tx = Pw[0] - Sw[0], ty = Pw[1] - Sw[1], tl = Math.hypot(tx, ty) || 1; let nx = -ty / tl, ny = tx / tl; if (nx * a.side < 0) { nx = -nx; ny = -ny; }
        const bu = Math.max(0, tl - 10) * 0.18; set(tb, 'd', 'M' + r2(Sw[0]) + ' ' + r2(Sw[1]) + ' Q' + r2(mx + nx * bu) + ' ' + r2(my + ny * bu) + ' ' + r2(Pw[0]) + ' ' + r2(Pw[1])); set(tb, 'stroke-width', r2(a.rx * 1.6 * Math.sqrt((1 + sq * 0.4) * sy))); set(tb, 'opacity', r2(zv < -3 ? 0 : SM((len - 7.5) / 5))); }
      W[Lf ? 'pawL' : 'pawR'] = Pw; });
    ['L', 'R'].forEach(sd => { if (W['paw' + sd]) return; const s = sd === 'L' ? -1 : 1, [ox, oy] = I.mapHand(sd === 'L' ? P.hLx : -P.hRx, sd === 'L' ? P.hLy : P.hRy); W['paw' + sd] = glob(50 + s * Math.abs(50 - g.pawX) + (sd === 'L' ? ox : -ox), g.pawY + oy); });
    // face drawn by the rig
    const E = I.E, rd = clamp(P.red, 0, 1), gr = clamp(P.green, 0, 1); set(E.tintR, 'd', headD); set(E.tintR, 'opacity', r2(rd * 0.34)); set(E.tintG, 'd', headD); set(E.tintG, 'opacity', r2(gr * 0.26));
    if (E.bodyG) { if (gr > 0.01) set(E.bodyG, 'd', g.main.q.e.getAttribute('d')); set(E.bodyG, 'opacity', r2(gr * 0.26)); }
    const ox = P.lx * 2.6, oy = P.ly * 2.2, ws = 1 + clamp(P.wide, 0, 1) * 0.22, h = clamp(P.hap, 0, 1), qz = clamp(P.sqz, 0, 1), cr = clamp(P.cross, 0, 1) * 1.8, ty = clamp(P.teary, 0, 1); I.eyeW = [];
    g.EY.forEach((ey, i) => { const Lf = ey.x < (g.EY.length > 1 ? (g.EY[0].x + g.EY[1].x) / 2 : 50) || g.EY.length === 1 && false, dir = Lf ? 1 : -1, c = clamp(Math.max(P.close, Lf ? P.winkL : P.winkR), 0, 1) * (1 - SM(h * 1.6));
      const R0 = (ey.r || 4.6) * 1.08, k = R0 / 5.2, cx = ey.x + ox * k + dir * cr * k, cy = ey.y + oy * k - h * 0.8 * k, r = R0 * ws, o = E.eyes[i], sl = clamp(P.sl, 0, 1) * 0.32, out = Lf ? -1 : 1;
      const eD = toD(ellS(cx, cy, r, r, 0, 8), (x, y) => { const dy = y - cy, ce = clamp(c + sl * (0.5 + 0.5 * out * (x - cx) / r), 0, 1); let X = x, Y = cy + dy * (dy < 0 ? 1 - 2 * ce : 1 - 2 * h);
        if (qz > 0) { const cu = clamp((x - cx) / r, -1, 1), uu = dir > 0 ? (cu + 1) / 2 : (1 - cu) / 2; X = lerp(X, cx + dir * (-0.8 + uu * 1.4) * r, qz); Y = lerp(Y, cy + Math.sign(dy) * (1 - uu) * 0.6 * r, qz); } return face(X, Y); });
      set(o.e, 'd', eD); set(o.clip, 'd', eD); set(o.e, 'stroke-width', r2(1.3 * k * Math.max(SM((c - 0.5) / 0.45), SM((h - 0.5) / 0.45), SM(qz * 1.6))));
      const ha = (1 - SM((c - 0.4) / 0.25)) * (1 - SM((h - 0.12) / 0.3)) * (1 - SM(qz * 2.5)), hk = ws * (1 + ty * 0.4) * k, hd = c * r * 0.7;
      set(o.h1, 'd', toD(ellS(cx - 1.7 * k * ws, cy - 1.9 * k * ws + hd, 1.8 * hk, 1.8 * hk, 0, 6), face)); set(o.h2, 'd', toD(ellS(cx + 1.8 * k * ws, cy + 1.6 * k * ws, 0.7 * hk, 0.7 * hk, 0, 6), face));
      set(o.h1, 'opacity', r2(ha)); set(o.h2, 'opacity', r2(ha * 0.9)); set(o.tp, 'd', toD(ellS(cx, cy + r * 0.8, r, r * 0.42, 0, 8), face)); set(o.tp, 'opacity', r2(ty * 0.85 * (1 - qz) * (1 - SM(c * 1.5))));
      set(o.g, 'opacity', r2(zc(cx, cy))); const w = face(cx, cy); I.eyeW.push(w); W[Lf ? 'eyeL' : 'eyeR'] = w; });
    if (!W.eyeR && W.eyeL) W.eyeR = W.eyeL;
    { const mk0 = (MO.w || 9.6) * 0.36 / 3.5, sm = clamp(P.smile, 0, 1), op = clamp(P.open, 0, 1), fr = clamp(P.frown, 0, 1), mw = P.mw * (1 + sm * 0.12), hw = 3.5 * mk0 * mw * (1 + op * 0.3), X0 = MO.x, Y0 = MO.y;
      const y0 = Y0 + (-sm * 0.5 + fr * 1.3) * mk0, d = (2.3 * (1 + sm * 0.45) - fr * 4) * (1 - op * 0.55) * mk0, ym = Y0 - fr * 0.2 * mk0;
      const lip = 'M' + r2(X0 - hw) + ' ' + r2(y0) + ' Q' + r2(X0 - hw / 2) + ' ' + r2(y0 + d) + ' ' + r2(X0) + ' ' + r2(ym) + ' Q' + r2(X0 + hw / 2) + ' ' + r2(ym + d) + ' ' + r2(X0 + hw) + ' ' + r2(y0);
      const mv = zc(X0, Y0); set(E.mouth, 'd', toD(parsePath(lip), face)); set(E.mouth, 'opacity', r2(mv)); set(E.mouth, 'stroke-width', r2(1.2 * Math.max(0.8, mk0)));
      if (op > 0.03) { set(E.mopen, 'd', toD(parsePath(lip + ' C' + r2(X0 + hw) + ' ' + r2(y0 + op * 8 * mk0) + ' ' + r2(X0 - hw) + ' ' + r2(y0 + op * 8 * mk0) + ' ' + r2(X0 - hw) + ' ' + r2(y0) + 'Z'), face)); set(E.tongue, 'd', toD(ellS(X0, y0 + op * 4.2 * mk0, 2.3 * op * mw * mk0, 1.4 * op * mk0, 0, 8), face)); set(E.mopen, 'opacity', r2(mv)); set(E.tongue, 'opacity', r2(mv)); }
      else { set(E.mopen, 'opacity', 0); set(E.tongue, 'opacity', 0); }
      const tg = clamp(P.tongue, 0, 1); set(E.tout, 'opacity', r2(mv * SM(tg * 3))); if (tg > 0.02) set(E.tout, 'd', toD(ellS(X0, y0 + (1.3 + tg * 1.9) * mk0, 2.2 * (1 + tg * 0.15) * mk0, (1 + tg * 1.7) * mk0, 0, 8), face));
      W.mouth = face(X0, Y0); W.nose = face(X0, Y0 - 3.5); }
    const bb = g.BB, tops = I.items.filter(q => q.role === 'top' && !q.owner);
    W.head = I.topW = headT(HX, g.TOP + 1); W.body = glob(50, (g.HY + G) / 2 + 6); W.belly = glob(50, G - (G - g.HY) * 0.28); W.sideL = glob(bb.x + bb.width * 0.12, G - 14); W.sideR = glob(bb.x + bb.width * 0.88, G - 14);
    ['L', 'R'].forEach(sd => { const t = tops.find(q => q.side === (sd === 'L' ? -1 : 1)); W['ear' + sd] = t ? sph(t.cx, t.b.y + 2, 0) : headT(HX + (sd === 'L' ? -1 : 1) * g.HR * 0.6, g.TOP + 4); });
    const sideT = I.items.find(q => q.role === 'side'); W.tail = sideT ? glob(sideT.cx, sideT.cy) : glob(bb.x + bb.width * 0.9, G - 16);
    const feet = I.items.filter(q => q.role === 'foot'); W.footL = feet[0] ? glob(feet[0].ox, feet[0].oy) : glob(42, G - 3); W.footR = feet[1] ? glob(feet[1].ox, feet[1].oy) : glob(58, G - 3);
    const gl = Math.max(0, P.lift); set(I.shadow, 'cx', r2(50 + P.x + P.lean * 0.15)); set(I.shadow, 'cy', r2(G + 0.6)); set(I.shadow, 'rx', r2(bb.width * 0.5 * (1 + sq * 0.45) * (1 - gl / 70))); set(I.shadow, 'ry', r2(3.6 * (1 - gl / 90))); set(I.shadow, 'opacity', r2(0.2 * (1 - gl / 50)));
  };
  const inHeadPt = (g, x, y) => g.headA && Math.hypot((x - g.headA.cx) / g.headA.hx, (y - g.headA.cy) / g.headA.hy) < 1;

  window.RiveGeneric = { build };
})();
