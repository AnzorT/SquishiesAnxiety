# Squish Squad – creature animation handoff

Open `All Creatures Animations.dc.html` in a browser (serve the folder locally, e.g. `npx serve .`). It previews every creature and every animation.

## Files
- `rive-rig.js` – the shared skeleton + animation rig (Mittens' rig). `RiveRig.mount(hostEl, key, { onState })` → `{ play(name), destroy(), state }`. All animation timelines live in `STATES`.
- `pet-defs.js` – visual designs for Pet Shop creatures (`RiveRig.DEFS.<key>`): prickle, nibbles, quill, waffles, … Same skeleton, different look.
- `mittens-moves.js`, `rive-generic.js` – extra moves / generic defs layered on the rig.
- `plush-rig25.js` – older rig, still used for creatures not yet moved to the new rig.
- `creatures-v2.js`, `squad-store.js` – roster data and state.
- `support.js` – runtime for the `.dc.html` preview page.

## Rules
- Every creature uses Mittens' skeleton and timelines. Only the visual design changes.
- Ears, paws, spikes and tail are locked to the body and move with it.
- Body and head turn together at the same angle (`yb = yh` in `rive-rig.js`).
- Face markings stay visible from every angle. Set `"hug": true` on a `faceExtra` entry and `"hugCheeks": true` on the def (Nibbles uses this).

## Status
- Done: Mittens, Prickle, Nibbles.
- To do: review Quill, Waffles, Poppy, Duchess, Mama Paws one at a time (same checks as Prickle).
- To do: wire the new rig into the game screen and the Crib (`Squish Squad App v1.dc.html`).
