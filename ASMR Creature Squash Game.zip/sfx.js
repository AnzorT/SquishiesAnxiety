(function () {
  const S = { ctx: null, enabled: true, musicVol: 0.5, sfxVol: 0.8, want: null, track: null, hold: null, squish: null, reel: null };
  const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);

  function init() {
    if (S.ctx) return S.ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    const c = (S.ctx = new AC());
    const comp = c.createDynamicsCompressor();
    comp.threshold.value = -14; comp.ratio.value = 4; comp.connect(c.destination);
    S.master = c.createGain(); S.master.gain.value = S.enabled ? 1 : 0; S.master.connect(comp);
    S.sfx = c.createGain(); S.sfx.gain.value = S.sfxVol; S.sfx.connect(S.master);
    S.mus = c.createGain(); S.mus.gain.value = S.musicVol * 0.5; S.mus.connect(S.master);
    const len = c.sampleRate * 1.8, ir = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3); }
    S.verb = c.createConvolver(); S.verb.buffer = ir;
    S.verbIn = c.createGain(); S.verbIn.gain.value = 0.35; S.verbIn.connect(S.verb); S.verb.connect(S.master);
    const nl = c.sampleRate * 2; S.noiseBuf = c.createBuffer(1, nl, c.sampleRate);
    const nd = S.noiseBuf.getChannelData(0); for (let i = 0; i < nl; i++) nd[i] = Math.random() * 2 - 1;
    return c;
  }
  function ready() { const c = S.ctx; if (!c || c.state === 'closed') return null; if (c.state === 'suspended' && !document.hidden) c.resume(); return c; }
  function unlock() {
    const c = init(); if (!c) return;
    if (c.state === 'suspended') c.resume().then(() => { if (S.want && !S.track) startTrack(S.want); });
    else if (S.want && !S.track) startTrack(S.want);
  }
  ['pointerdown', 'keydown', 'touchstart'].forEach((ev) => window.addEventListener(ev, unlock, { capture: true, passive: true }));
  document.addEventListener('visibilitychange', () => { if (!S.ctx) return; document.hidden ? S.ctx.suspend() : S.ctx.resume(); });

  function tone(f, t, dur, o) {
    o = o || {}; const c = S.ctx;
    const osc = c.createOscillator(), g = c.createGain();
    osc.type = o.type || 'sine'; osc.frequency.setValueAtTime(f, t);
    if (o.to) osc.frequency.exponentialRampToValueAtTime(o.to, t + (o.slide || dur));
    if (o.detune) osc.detune.value = o.detune;
    const v = o.vol == null ? 0.3 : o.vol, a = o.attack || 0.004;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    let out = g;
    if (o.lp) { const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = o.lp; g.connect(lp); out = lp; }
    osc.connect(g); out.connect(o.bus || S.sfx);
    if (o.verb) { const s = c.createGain(); s.gain.value = o.verb; out.connect(s); s.connect(S.verbIn); }
    osc.start(t); osc.stop(t + dur + 0.05);
    return osc;
  }
  function noise(t, dur, o) {
    o = o || {}; const c = S.ctx;
    const src = c.createBufferSource(); src.buffer = S.noiseBuf; src.loop = true;
    const f = c.createBiquadFilter(); f.type = o.ft || 'bandpass'; f.Q.value = o.q || 1;
    f.frequency.setValueAtTime(o.f || 1000, t);
    if (o.fTo) f.frequency.exponentialRampToValueAtTime(o.fTo, t + dur);
    const g = c.createGain(), v = o.vol == null ? 0.2 : o.vol;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + (o.attack || 0.005));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(o.bus || S.sfx);
    if (o.verb) { const s = c.createGain(); s.gain.value = o.verb; g.connect(s); s.connect(S.verbIn); }
    src.start(t, Math.random()); src.stop(t + dur + 0.05);
  }
  function bell(f, t, dur, vol, bus) {
    tone(f, t, dur, { vol, verb: 0.6, bus });
    tone(f * 2.76, t, dur * 0.4, { vol: vol * 0.25, verb: 0.6, bus });
    tone(f * 5.4, t, dur * 0.15, { vol: vol * 0.1, bus });
  }
  function sparkle(t, n, base) {
    for (let i = 0; i < (n || 7); i++) bell((base || 1800) * Math.pow(2, Math.floor(Math.random() * 8) / 5), t + i * 0.045 + Math.random() * 0.02, 0.5, 0.07);
  }
  function arp(notes, t, gap, vol, dur) { notes.forEach((m, i) => bell(mtof(m), t + i * gap, dur || 0.8, vol || 0.14)); }

  const SOUNDS = {
    tap(t) { tone(480, t, 0.09, { to: 980, slide: 0.05, vol: 0.22 }); noise(t, 0.03, { f: 3000, q: 2, vol: 0.05 }); },
    bonk(t) { tone(180, t, 0.18, { type: 'triangle', to: 110, vol: 0.25 }); },
    swoosh(t) { noise(t, 0.24, { f: 500, fTo: 2600, q: 1.4, vol: 0.12, attack: 0.08 }); tone(700, t + 0.05, 0.12, { to: 1100, vol: 0.05 }); },
    swipe(t) { noise(t, 0.32, { f: 2600, fTo: 600, q: 1.2, vol: 0.13, attack: 0.1 }); tone(880, t + 0.12, 0.2, { vol: 0.08, verb: 0.3 }); },
    whoosh(t) { noise(t, 0.4, { f: 300, fTo: 1800, q: 0.8, vol: 0.12, attack: 0.15 }); bell(mtof(84), t + 0.18, 0.6, 0.06); },
    popOpen(t) { tone(300, t, 0.14, { to: 900, slide: 0.08, vol: 0.2 }); bell(mtof(88), t + 0.06, 0.4, 0.05); },
    popClose(t) { tone(800, t, 0.12, { to: 260, slide: 0.08, vol: 0.18 }); },
    tick(t) { tone(2200, t, 0.03, { type: 'triangle', vol: 0.14 }); noise(t, 0.02, { f: 5000, q: 3, vol: 0.08 }); },
    coin(t) { tone(1318, t, 0.08, { type: 'square', vol: 0.05, lp: 5000 }); tone(1976, t + 0.07, 0.35, { type: 'square', vol: 0.05, lp: 5000 }); bell(1976, t + 0.07, 0.4, 0.08); },
    coinShower(t) { for (let i = 0; i < 6; i++) SOUNDS.coin(t + i * 0.07 + Math.random() * 0.03); },
    spend(t) { tone(1500, t, 0.05, { type: 'triangle', vol: 0.12 }); tone(1000, t + 0.06, 0.2, { type: 'triangle', vol: 0.12 }); noise(t + 0.06, 0.12, { f: 4000, q: 2, vol: 0.06 }); },
    win(t) { arp([72, 76, 79, 84], t, 0.09, 0.16); sparkle(t + 0.35, 6); },
    jackpot(t) { arp([72, 76, 79, 84, 88, 91], t, 0.08, 0.16, 1.2); [60, 64, 67].forEach((m) => tone(mtof(m), t + 0.5, 1.4, { type: 'triangle', vol: 0.07, attack: 0.05, verb: 0.4 })); sparkle(t + 0.5, 12, 2200); },
    fail(t) { tone(520, t, 0.45, { type: 'triangle', to: 220, slide: 0.4, vol: 0.18 }); tone(530, t, 0.45, { type: 'triangle', to: 224, slide: 0.4, vol: 0.1 }); },
    boxOpen(t) { noise(t, 0.7, { f: 400, fTo: 5000, q: 0.9, vol: 0.18, attack: 0.5 }); tone(300, t, 0.75, { to: 1600, slide: 0.7, vol: 0.08, type: 'triangle' }); tone(80, t + 0.7, 0.4, { to: 40, vol: 0.4 }); noise(t + 0.7, 0.35, { ft: 'lowpass', f: 1500, vol: 0.3 }); },
    reveal(t) { SOUNDS.jackpot(t); },
    unlock(t) { [2400, 3720, 5150].forEach((f, i) => tone(f, t + i * 0.008, 0.25, { vol: 0.06, verb: 0.3 })); tone(900, t + 0.12, 0.08, { type: 'square', vol: 0.06, lp: 3000 }); noise(t + 0.12, 0.05, { f: 2500, q: 4, vol: 0.12 }); arp([79, 84, 88, 91], t + 0.25, 0.07, 0.13); sparkle(t + 0.5, 8); },
    achievement(t) { arp([67, 72, 76, 79, 84], t, 0.1, 0.16, 1.1); tone(mtof(48), t, 1.2, { type: 'triangle', vol: 0.1, attack: 0.02 }); sparkle(t + 0.5, 9, 2400); },
    boost(t) { tone(200, t, 0.5, { type: 'sawtooth', to: 1600, slide: 0.45, vol: 0.06, lp: 2400 }); SOUNDS.coinShower(t + 0.35); },
    adStart(t) { bell(mtof(76), t, 0.4, 0.1); bell(mtof(83), t + 0.12, 0.6, 0.1); },
    adDone(t) { arp([76, 83, 88], t, 0.08, 0.12); },
    ready(t) { bell(mtof(84), t, 0.9, 0.1); bell(mtof(91), t + 0.1, 1, 0.08); },
    blip(t) { tone(1200, t, 0.06, { vol: 0.07 }); },
    sparkle(t) { sparkle(t, 10); },
    squelch(t) { noise(t, 0.18, { f: 700, fTo: 280, q: 3, vol: 0.28, attack: 0.02 }); tone(260, t, 0.14, { to: 150, vol: 0.12 }); },
    release(t) {
      tone(180, t, 0.16, { to: 520, slide: 0.07, vol: 0.28 });
      noise(t, 0.22, { f: 400, fTo: 1600, q: 4, vol: 0.18 });
      for (let i = 0; i < 5; i++) tone(900 + Math.random() * 900, t + 0.05 + Math.random() * 0.18, 0.03, { vol: 0.05, to: 1800 });
    },
  };

  function holdStart() {
    const c = ready(); if (!c) return; holdStop();
    const o = c.createOscillator(), o2 = c.createOscillator(), g = c.createGain();
    o.type = 'triangle'; o2.type = 'sine'; o.frequency.value = 260; o2.frequency.value = 390;
    g.gain.setValueAtTime(0.0001, c.currentTime); g.gain.linearRampToValueAtTime(0.06, c.currentTime + 0.1);
    o.connect(g); o2.connect(g); g.connect(S.sfx); o.start(); o2.start();
    S.hold = { o, o2, g, last: 0 };
  }
  function holdUpdate(p) {
    const c = ready(); if (!c || !S.hold) return;
    const f = 260 + p * 700, t = c.currentTime;
    S.hold.o.frequency.setTargetAtTime(f, t, 0.03); S.hold.o2.frequency.setTargetAtTime(f * 1.5, t, 0.03);
    S.hold.g.gain.setTargetAtTime(0.05 + p * 0.07, t, 0.05);
    const step = Math.floor(p * 10); if (step > S.hold.last) { S.hold.last = step; tone(f * 2, t, 0.05, { vol: 0.05 }); }
  }
  function holdStop() {
    if (!S.hold || !S.ctx) return; const { o, o2, g } = S.hold, t = S.ctx.currentTime;
    g.gain.cancelScheduledValues(t); g.gain.setTargetAtTime(0.0001, t, 0.04);
    o.stop(t + 0.3); o2.stop(t + 0.3); S.hold = null;
  }

  function squishStart() {
    const c = ready(); if (!c) return; squishStop();
    const t = c.currentTime;
    SOUNDS.squelch(t);
    const src = c.createBufferSource(); src.buffer = S.noiseBuf; src.loop = true;
    const f = c.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 2.2; f.frequency.value = 520;
    const lfo = c.createOscillator(), lg = c.createGain(); lfo.frequency.value = 3.4; lg.gain.value = 220;
    lfo.connect(lg); lg.connect(f.frequency);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.12, t + 0.25);
    src.connect(f); f.connect(g); g.connect(S.sfx); src.start(t, Math.random()); lfo.start(t);
    const sq = { src, lfo, g, f, on: true };
    const crackle = () => {
      if (!sq.on || !S.ctx) return; const n = S.ctx.currentTime;
      tone(700 + Math.random() * 1600, n, 0.02 + Math.random() * 0.03, { vol: 0.03 + Math.random() * 0.04, to: 400 + Math.random() * 600 });
      if (Math.random() < 0.25) noise(n, 0.05, { f: 1500 + Math.random() * 2500, q: 6, vol: 0.05 });
      lfo.frequency.setTargetAtTime(2 + Math.random() * 4, n, 0.2);
      sq.timer = setTimeout(crackle, 50 + Math.random() * 140);
    };
    crackle(); S.squish = sq;
  }
  function squishStop() {
    const sq = S.squish; if (!sq || !S.ctx) return; S.squish = null; sq.on = false; clearTimeout(sq.timer);
    const t = S.ctx.currentTime; sq.g.gain.cancelScheduledValues(t); sq.g.gain.setTargetAtTime(0.0001, t, 0.05);
    sq.src.stop(t + 0.4); sq.lfo.stop(t + 0.4);
  }

  function wheelSpin(ms) {
    const c = ready(); if (!c) return; const t0 = c.currentTime, T = ms / 1000;
    noise(t0, 0.4, { f: 600, fTo: 2400, q: 1, vol: 0.12, attack: 0.1 });
    let x = 0;
    while (x < T - 0.05) {
      const p = x / T, gap = 0.035 + Math.pow(p, 2.6) * 0.42;
      SOUNDS.tick(t0 + x); x += gap;
    }
  }
  function reelStart() {
    reelStop(); const run = () => { const c = ready(); if (c) SOUNDS.tick(c.currentTime); S.reel = setTimeout(run, 70); }; run();
  }
  function reelLand(ms) {
    reelStop(); const c = ready(); if (!c) return; const t0 = c.currentTime, T = ms / 1000; let x = 0, gap = 0.07;
    while (x < T) { SOUNDS.tick(t0 + x); gap *= 1.12; x += gap; }
    tone(mtof(72), t0 + T - 0.05, 0.3, { type: 'triangle', vol: 0.12 });
  }
  function reelStop() { clearTimeout(S.reel); S.reel = null; }

  // --- music ---
  const _ = null;
  const PRESETS = {
    dream:   { bpm: 76,  key: 77, chords: [[53,57,60,64],[50,53,57,60],[46,50,53,57],[48,52,55,57]], hits: [4,12], oct: 24, bass: false, shaker: false, pad: 0.045, pluck: 'bell',
               mel: [0,_,_,4,_,7,_,_,5,_,4,_,0,_,_,_, 2,_,_,4,_,0,_,_,-3,_,_,_,_,_,_,_], lead: 'box' },
    party:   { bpm: 124, key: 72, chords: [[48,52,55],[45,48,52],[41,45,48],[43,47,50]], hits: [2,6,10,14], oct: 24, bass: true, shaker: true, kick: [0,4,8,12], clap: [4,12], pad: 0.02, pluck: 'pluck',
               mel: [0,_,4,_,7,_,4,_,9,_,7,_,4,_,2,_, 0,_,4,_,7,_,12,_,11,_,7,_,9,_,7,_], lead: 'square' },
    cozy:    { bpm: 86,  key: 79, chords: [[43,47,50,54],[40,43,47,50],[36,40,43,47],[38,42,45,47]], hits: [2,10], oct: 24, bass: true, shaker: false, kick: [0,8], pad: 0.032, pluck: 'mallet',
               mel: [0,_,_,-3,_,-5,_,_,-8,_,-5,_,-3,_,_,_, -5,_,_,-3,_,0,_,2,_,_,0,_,_,_,_,_], lead: 'box' },
    calm:    { bpm: 58,  key: 76, chords: [[40,47,52,56],[37,44,49,52],[33,40,45,49],[35,42,47,51]], hits: [], oct: 24, bass: false, shaker: false, pad: 0.05, pluck: 'bell', lp: 1500,
               mel: [0,_,_,_,_,_,_,_,-5,_,_,_,_,_,_,_, _,_,_,_,-3,_,_,_,_,_,_,_,-8,_,_,_], lead: 'bell' },
    mystery: { bpm: 96,  key: 69, chords: [[45,48,52],[41,45,48],[38,41,45],[40,44,47]], hits: [6,14], oct: 24, bass: true, shaker: true, kick: [0,10], pad: 0.028, pluck: 'pluck',
               mel: [0,_,3,_,7,_,3,_,8,_,7,_,3,_,2,_, 0,_,3,_,7,_,12,_,11,_,8,_,7,_,_,_], lead: 'box' },
  };
  function voice(kind, m, t, bus, lp) {
    const f = mtof(m);
    if (kind === 'bell') bell(f, t, 1.4, 0.07, bus);
    else if (kind === 'mallet') { tone(f, t, 0.35, { type: 'sine', vol: 0.09, bus }); tone(f * 4, t, 0.05, { vol: 0.025, bus }); }
    else tone(f, t, 0.2, { type: 'triangle', vol: 0.06, bus, lp: lp || 2600 });
  }
  function lead(kind, m, t, bus) {
    const f = mtof(m);
    if (kind === 'square') { tone(f, t, 0.22, { type: 'square', vol: 0.035, bus, lp: 2200 }); tone(f * 2, t, 0.12, { vol: 0.03, bus }); }
    else if (kind === 'bell') bell(f, t, 2, 0.06, bus);
    else { tone(f, t, 0.9, { vol: 0.07, bus, verb: 0.5 }); tone(f * 2, t, 0.35, { type: 'triangle', vol: 0.025, bus, verb: 0.5 }); tone(f * 3, t, 0.08, { vol: 0.02, bus }); }
  }
  function startTrack(name) {
    const c = ready(); if (!c) return;
    const P = PRESETS[name]; if (!P) return;
    const bus = c.createGain(); bus.gain.setValueAtTime(0.0001, c.currentTime); bus.gain.linearRampToValueAtTime(1, c.currentTime + 1.2);
    let out = bus;
    if (P.lp) { const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = P.lp; bus.connect(f); out = f; }
    out.connect(S.mus);
    const tr = { name, P, bus, step: 0, next: c.currentTime + 0.1, seed: 7 };
    const sixteenth = 60 / P.bpm / 4;
    const rnd = () => ((tr.seed = (tr.seed * 9301 + 49297) % 233280) / 233280);
    tr.timer = setInterval(() => {
      if (!S.ctx) return;
      while (tr.next < S.ctx.currentTime + 0.15) {
        const s = tr.step % 16, bar = Math.floor(tr.step / 16), ch = P.chords[bar % P.chords.length], t = tr.next;
        if (s === 0) {
          const d = sixteenth * 16;
          ch.forEach((m, i) => tone(mtof(m + 12), t, d + 0.4, { type: i % 2 ? 'triangle' : 'sine', vol: P.pad, attack: d * 0.35, bus, detune: (i - 1.5) * 4 }));
          if (P.bass) tone(mtof(ch[0] - 12), t, sixteenth * 7, { type: 'sine', vol: 0.11, attack: 0.02, bus });
          if (bar % 4 === 0) tr.seed = 7 + (bar / 4) % 3;
        }
        if (P.bass && s === 8) tone(mtof(ch[0] - 12 + (name === 'mystery' ? 0 : 7)), t, sixteenth * 5, { type: 'sine', vol: 0.08, attack: 0.02, bus });
        const phrase = Math.floor(bar / 2) % 4;
        const mi = P.mel[tr.step % 32];
        if (mi != null && phrase !== 3) lead(P.lead, P.key + mi + (phrase === 2 ? 12 : 0), t, bus);
        if (P.hits.indexOf(s) >= 0 && rnd() > 0.3) voice(P.pluck, ch[Math.floor(rnd() * ch.length)] + P.oct - (rnd() > 0.6 ? 12 : 0), t, bus, P.lp);
        if (P.kick && P.kick.indexOf(s) >= 0) tone(120, t, 0.22, { to: 42, slide: 0.12, vol: name === 'party' ? 0.22 : 0.12, bus });
        if (P.clap && P.clap.indexOf(s) >= 0) noise(t, 0.12, { f: 1600, q: 0.8, vol: 0.07, bus, verb: 0.3 });
        if (P.shaker && s % 2 === 0) noise(t, 0.04, { ft: 'highpass', f: 7000, vol: s % 4 === 2 ? 0.03 : 0.015, bus });
        tr.step++; tr.next += sixteenth;
      }
    }, 25);
    S.track = tr;
  }
  function stopTrack() {
    const tr = S.track; if (!tr) return; S.track = null; clearInterval(tr.timer);
    if (S.ctx) { const t = S.ctx.currentTime; tr.bus.gain.cancelScheduledValues(t); tr.bus.gain.setValueAtTime(tr.bus.gain.value, t); tr.bus.gain.linearRampToValueAtTime(0.0001, t + 0.9); setTimeout(() => tr.bus.disconnect(), 1400); }
  }

  window.SFX = {
    play(name, delay) { const c = ready(); if (!c || !S.enabled || !SOUNDS[name]) return; SOUNDS[name](c.currentTime + (delay || 0)); },
    boxTap(n) {
      const c = ready(); if (!c || !S.enabled) return; const t = c.currentTime;
      tone(150 + n * 15, t, 0.16, { to: 90, vol: 0.35 }); noise(t, 0.06, { f: 900 + n * 150, q: 2, vol: 0.18 });
      bell(mtof(72 + [0, 2, 4, 7, 9, 12, 14, 16, 19, 24][Math.min(9, n - 1)]), t + 0.02, 0.5, 0.1);
    },
    music(name) {
      S.want = name || null;
      if (S.track && S.track.name === name) return;
      stopTrack(); if (name && ready()) startTrack(name);
    },
    setEnabled(on) { S.enabled = !!on; if (S.master) S.master.gain.setTargetAtTime(on ? 1 : 0, S.ctx.currentTime, 0.08); if (!on) { squishStop(); holdStop(); reelStop(); } },
    setVolumes(music, sfx) {
      S.musicVol = music; S.sfxVol = sfx;
      if (S.mus) { S.mus.gain.setTargetAtTime(music * 0.5, S.ctx.currentTime, 0.1); S.sfx.gain.setTargetAtTime(sfx, S.ctx.currentTime, 0.1); }
    },
    holdStart, holdUpdate, holdStop, squishStart, squishStop, wheelSpin, reelStart, reelLand, reelStop,
    stopAll() { stopTrack(); squishStop(); holdStop(); reelStop(); },
  };
})();
