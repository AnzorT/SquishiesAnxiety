// Yard Mini Games: SLIDE & SPLASH - the big slide run (Nov 17, user: 'i want it to be like in club penguin with the sledding game: a 1-2 minute sliding where
// the goal is to make us go faster, obstacles slow us down, stuff boosts us up, at the end we jump into a pool and our speed decides how strong the splash is'
// + a reference screenshot for the angle; 'they dont need to be on sleds': your creature slides on its own bottom).
// v4 (Nov 17, user: 'the change of slope is not good, it's a slide, it should only go down; the slide itself is really really wide, look how a slide
//  looks, it's not that wide; I want the character's speed to be felt in the game, not just written; the pool: a pool like the rubber one in the yard, on
//  its own screen - the character goes up in the air, disappears, then a screen with the pool and a few characters, the character drops into the pool, the
//  faster the bigger the splash and you see the characters getting wet; that scene not from the angle but a regular view'):
//  - the slide is a narrow chute (HW 60 = about two creatures wide, walls WH 24) up on posts at one height SH all the way down the hill: no drop, no bend,
//    it only goes down the screen (down-right, like the reference); a little tower at the top (deck level with the chute, rails, a ladder on the near
//    side); the last stretch curves up into a lip (RH) that throws you up and out of sight.
//  - two halves: things sit on the left or right half (l = -0.5 / +0.5), you switch sides (LMAX 0.55); wooden bumps run full width (hop over logs).
//  - speed you can feel: ripples every 50 + seams every 150 + posts every 70 rush past, speed lines (more, longer, brighter with speed) + wind dashes
//    round you, the camera holds you further back and shakes a little when fast, a zoom punch + star trail on a boost, you lean back + squint + arms
//    swept back, and a wind / slide sound (looped noise) rising in pitch + volume with speed.
//  - the end: off the lip you fly up off the top of the screen, a white flash, and the pool scene (side on, its own layers scB / scF): the backyard's
//    three-ring kiddie pool (blue / white tube with fish + starfish / blue, crown ring, water with a rubber duck + a beach ball), three friends (two on
//    the grass, one sitting in the pool), you drop in from the sky (cannonball spin at 75+). The splash (column, fan of jets, crown, rings, drops, water
//    sheets thrown at the friends, spills over the rim + puddles, sloshing water, the toys tossed, screen shake, lens drops) and how wet / knocked over
//    the friends get grow with your speed at the lip: k < 0.3 they just cheer; from 0.3 they're splashed (soaked look, drips, shake it off, laugh);
//    from 0.6 the one in the pool is thrown up; from 0.85 the two on the grass are knocked over. Score = speed x 10.
// View on the slide: oblique top-down like the reference: down the slide = screen down-right (32 deg), across = up-right (-24 deg), height = up.
// World point (s along px, l across -1..1 = the chute's walls, h up px) -> Wp(); the world groups (bg + fg) share one camera transform; standing things
// are depth sorted round your creature (in front = fg, behind = bg); the near wall + near posts are in fg (they hide your bottom like a real chute).
// Hooks: _state, _bot(skill), _ff(sec), _setV(v), _items.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add) return setTimeout(go, 30); const { S, cl, lerp, r2, SFX, TAU } = YG;
  const rad = d => d * Math.PI / 180, FA = rad(32), LA = rad(-24), F = [Math.cos(FA), Math.sin(FA)], LV = [Math.cos(LA), Math.sin(LA)], HW = 52;
  const Wp = (s, l, h) => [s * F[0] + l * HW * LV[0], s * F[1] + l * HW * LV[1] - (h || 0)], P2 = p => r2(p[0]) + ' ' + r2(p[1]);
  const G3 = (ds, lp, h) => [ds * F[0] + lp * LV[0], ds * F[1] + lp * LV[1] - (h || 0)];   // local: ds along, lp across (px), h up
  const poly = pts => 'M' + pts.map(P2).join('L') + 'Z', quad = (s0, s1, l0, l1, h0, h1) => poly([Wp(s0, l0, h0), Wp(s1, l0, h1 == null ? h0 : h1), Wp(s1, l1, h1 == null ? h0 : h1), Wp(s0, l1, h0)]);
  // a circle lying on the ground looks like this ellipse (kx, ky, rotated rot deg)
  const EL = (() => { const a = F[0] * F[0] + LV[0] * LV[0], b = F[0] * F[1] + LV[0] * LV[1], c = F[1] * F[1] + LV[1] * LV[1], m = (a + c) / 2, d = Math.sqrt((a - c) * (a - c) / 4 + b * b); return { kx: Math.sqrt(m + d), ky: Math.sqrt(m - d), rot: r2(Math.atan2(2 * b, a - c) / 2 * 180 / Math.PI) }; })();
  const gEl = (x, y, r, a) => '<ellipse cx="' + r2(x) + '" cy="' + r2(y) + '" rx="' + r2(r * EL.kx) + '" ry="' + r2(r * EL.ky) + '" transform="rotate(' + EL.rot + ' ' + r2(x) + ' ' + r2(y) + ')" ' + (a || '') + '/>';
  // an organic blob lying on the ground: half-length hs along the slide, half-width wp across (px)
  const blob = (hs, wp, wob, sd) => { const pts = []; for (let i = 0; i < 18; i++) { const t = i / 18 * TAU, k = 1 + wob * Math.sin(t * 3 + sd) * 0.6 + wob * Math.sin(t * 5 + sd * 2) * 0.4; pts.push(G3(Math.cos(t) * hs * k, Math.sin(t) * wp * k, 0)); }
    let d = 'M' + P2(pts[0]); for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length], m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]; d += 'Q' + P2(a) + ' ' + P2(m); } return d + 'Z'; };
  const rnd = sd => () => (sd = (sd * 9301 + 49297) % 233280) / 233280;
  // ---------- tuning ----------
  const KV = 4, VB = 37, VMAX = 125, DEC = 0.1, LMAX = 0.58, RW = 0.2, CS = 480, LEN = 16000, RS = LEN - 260, RH = 40, SH = 56, WH = 21, GA = 900, GF = 560, K = 80;
  const T0 = -150, SD0 = -40, ST0 = -96;   // the tower's deck (T0..SD0) and where you sit on it
  const SECT = [[0, 'meadow'], [3200, 'garden'], [6800, 'farm'], [10400, 'sprinkle'], [13800, 'final']], secAt = s => { let n = 'meadow'; for (const [a, b] of SECT) if (s >= a) n = b; return n; };
  const HS = s => s <= RS ? SH : SH + RH * Math.pow(cl((s - RS) / (LEN - RS), 0, 1), 2);   // the chute's height: one level all the way, the lip curves up
  const TIERS = [[0, 'Splish!', '#bfe8ff'], [42, 'Splash!', '#8fe0ff'], [60, 'Big Splash!', '#7ee0d6'], [80, 'Mega Splash!', '#ffe36e'], [100, 'TIDAL WAVE!', '#ff8fc8']], tierOf = v => { let t = TIERS[0]; for (const q of TIERS) if (v >= q[0]) t = q; return t; };
  // what's on the slide: hs = half length (px along), hw = half width (across, l units; the chute is +-1), hh = height (px), k = kind
  const DEF = { rock: { hs: 18, hw: 0.34, hh: 26, k: 'hard' }, gnome: { hs: 12, hw: 0.24, hh: 46, k: 'hard' }, hay: { hs: 20, hw: 0.38, hh: 30, k: 'hard' }, log: { hs: 12, hw: 0.75, hh: 18, k: 'hard' },
    bucket: { hs: 12, hw: 0.2, hh: 22, k: 'soft' }, sand: { hs: 18, hw: 0.32, hh: 12, k: 'soft' }, leaves: { hs: 20, hw: 0.34, hh: 10, k: 'soft' },
    mud: { hs: 50, hw: 0.44, hh: 3, k: 'mud', flat: 1 }, slick: { hs: 50, hw: 0.42, hh: 3, k: 'boost', flat: 1 }, gold: { hs: 30, hw: 0.4, hh: 3, k: 'gold', flat: 1 }, ramp: { hs: 26, hw: 0.95, hh: 18, k: 'ramp', flat: 1 } };
  const LOOK = { rainbow: { bands: ['#ff7a8a', '#ffa95a', '#ffdc5a', '#7fd870', '#5cb8ff', '#a98bff'], top: '#ffffff', face: '#e6e0f6', side: '#cfc6ec', seam: '#ffffff', shine: '#ffffff', deck: '#c9b8f2', post: '#ffffff', postD: '#a89ad0', boost: 1, hit: 1, steer: 1.1 },
    gold: { bands: ['#f6c94a', '#fbd96e', '#f6c94a', '#fbd96e'], top: '#fff2c0', face: '#e8b43a', side: '#cf9a24', seam: '#fff6d0', shine: '#ffffff', deck: '#f3d27a', post: '#f4f6fb', postD: '#b9a060', boost: 1.12, hit: 1, steer: 1 },
    wood: { planks: ['#d9a066', '#cd9358'], top: '#e8b67c', face: '#b47740', side: '#9a6232', seam: '#9a6232', shine: '#fff2dc', deck: '#e2ad74', post: '#a46c3a', postD: '#6b4426', boost: 1, hit: 0.85, steer: 1 } };
  const ICON = '<svg viewBox="0 0 120 84" aria-hidden="true"><rect width="120" height="84" fill="#79c25c"/><path d="M20 -4L44 -12L124 46L100 54Z" fill="#ffffff"/><path d="M26 -4L44 -10L118 44L100 50Z" fill="#ff7a8a"/><path d="M32 -4L44 -8L112 42L100 46Z" fill="#ffdc5a"/><path d="M38 -4L44 -6L106 40L100 42Z" fill="#5cb8ff"/>'
    + '<path d="M40 30V54M70 52V76M100 54V80" stroke="#ffffff" stroke-width="3"/><ellipse cx="22" cy="70" rx="20" ry="7" fill="#2a86e6"/><ellipse cx="22" cy="66" rx="17" ry="5" fill="#8fe6ff"/><path d="M14 64Q16 50 20 62M22 62Q25 44 28 62" stroke="#ffffff" stroke-width="2.6" fill="none" stroke-linecap="round"/>'
    + '<circle cx="58" cy="18" r="8" fill="#ffe7c8" stroke="#6b4426" stroke-width="2"/><path d="M38 6h-10M40 14h-12M38 22h-9" stroke="#ffffff" stroke-width="2.4" stroke-linecap="round" opacity="0.9"/></svg>';
  // ---------- art: things on the slide (drawn round their base point) ----------
  const ART = {
    rock: () => gEl(0, 2, 22, 'fill="#2d4a22" opacity="0.22"') + '<path d="M-24 2C-26 -10 -16 -24 -2 -25C12 -26 24 -16 25 -4C26 2 20 6 0 6C-16 6 -23 5 -24 2Z" fill="#a3a9b2" stroke="#5c6470" stroke-width="2.2"/><path d="M-15 -14C-9 -21 3 -22 9 -18" stroke="#d2d6dc" stroke-width="4.5" fill="none" stroke-linecap="round"/><path d="M5 3C14 1 20 -4 22 -9" stroke="#7e8690" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M-20 -2Q-16 -8 -10 -6" stroke="#7fb06a" stroke-width="3" fill="none" stroke-linecap="round"/>',
    gnome: () => gEl(0, 2, 14, 'fill="#2d4a22" opacity="0.22"') + '<g class="ygs-tip"><ellipse cx="-6" cy="-2" rx="6.5" ry="4" fill="#6b4426"/><ellipse cx="6" cy="-2" rx="6.5" ry="4" fill="#6b4426"/><path d="M-12 -4C-13 -16 -9 -22 0 -22C9 -22 13 -16 12 -4Z" fill="#4f8ee8" stroke="#2c5aa8" stroke-width="1.6"/><path d="M-11.5 -10H11.5" stroke="#6b4426" stroke-width="3"/><rect x="-2.5" y="-12" width="5" height="4" rx="1" fill="#ffd84a"/>'
      + '<path d="M-9 -26C-13 -16 -6 -7 0 -6C6 -7 13 -16 9 -26Z" fill="#ffffff" stroke="#d8d2c6" stroke-width="1.4"/><ellipse cy="-28" rx="8" ry="6.2" fill="#ffd2b0"/><circle cy="-25.5" r="2.8" fill="#ff9a8a"/><path d="M-4.5 -29h2.4M2.1 -29h2.4" stroke="#4a3a2e" stroke-width="1.5" stroke-linecap="round"/><path d="M-10.5 -31C-9 -39 -4 -49 2 -51C3 -44 8 -37 10.5 -31Z" fill="#ff5e6c" stroke="#b8304a" stroke-width="1.6" stroke-linejoin="round"/><path d="M-10 -31.5H10.5" stroke="#b8304a" stroke-width="2" stroke-linecap="round"/></g>',
    hay: () => gEl(4, 2, 28, 'fill="#2d4a22" opacity="0.22"') + '<g class="ygs-pop"><path d="M-24 -26L-12 -34L36 -34L24 -26Z" fill="#fae39a" stroke="#b88a2a" stroke-width="1.6" stroke-linejoin="round"/><path d="M24 -26L36 -34L36 -8L24 0Z" fill="#dcb24e" stroke="#b88a2a" stroke-width="1.6" stroke-linejoin="round"/><rect x="-24" y="-26" width="48" height="26" rx="4" fill="#f2cf6a" stroke="#b88a2a" stroke-width="1.8"/>'
      + '<path d="M-20 -20h12M-4 -18h14M-18 -9h9M2 -7h16M14 -21h7" stroke="#c99a36" stroke-width="1.6" stroke-linecap="round"/><path d="M-9 -26V0M9 -26V0M-3 -34L9 -26M15 -34L27 -26" stroke="#b0453a" stroke-width="2.2"/></g>',
    log: () => { const a = G3(0, -38, 9), b = G3(0, 38, 9); return gEl(0, 3, 30, 'fill="#2d4a22" opacity="0.2"') + '<path d="M' + P2(a) + 'L' + P2(b) + '" stroke="#7a4a26" stroke-width="20" stroke-linecap="round"/><path d="M' + P2(a) + 'L' + P2(b) + '" stroke="#a46c3a" stroke-width="15" stroke-linecap="round"/>'
      + '<path d="M' + P2([a[0] + 8, a[1] - 7]) + 'L' + P2([b[0] - 4, b[1] - 6]) + '" stroke="#c48a52" stroke-width="2.4" stroke-linecap="round"/><path d="M' + P2([a[0] + 12, a[1] + 1]) + 'L' + P2([b[0] - 10, b[1] + 3]) + '" stroke="#7a4a26" stroke-width="1.8" stroke-linecap="round" opacity="0.7"/>'
      + '<ellipse cx="' + r2(a[0]) + '" cy="' + r2(a[1]) + '" rx="7" ry="9.5" transform="rotate(-24 ' + P2(a).replace(' ', ' ') + ')" fill="#f0c98e" stroke="#7a4a26" stroke-width="2"/><ellipse cx="' + r2(a[0]) + '" cy="' + r2(a[1]) + '" rx="3.4" ry="5" transform="rotate(-24 ' + P2(a) + ')" fill="none" stroke="#c49058" stroke-width="1.4"/>'
      + '<path d="M' + P2([b[0] - 14, b[1] - 9]) + 'q3 -9 9 -8" stroke="#6fbf55" stroke-width="2.4" fill="none" stroke-linecap="round"/><ellipse cx="' + r2(b[0] - 5) + '" cy="' + r2(b[1] - 17) + '" rx="4" ry="2.4" fill="#7fd06a"/>'; },
    bucket: () => gEl(0, 2, 13, 'fill="#2d4a22" opacity="0.2"') + '<g class="ygs-tip">' + gEl(10, 0, 9, 'fill="#f1d48a"') + '<path d="M-10 -20L10 -20L8 0L-8 0Z" fill="#4fc6c0" stroke="#24877f" stroke-width="1.8" stroke-linejoin="round"/><ellipse cy="-20" rx="10" ry="3.4" fill="#2e9e96" stroke="#24877f" stroke-width="1.6"/><path d="M-10 -20Q0 -34 10 -20" stroke="#ff7a8a" stroke-width="2.2" fill="none"/><path d="M-9 -12H9" stroke="#ffffff" stroke-width="2.4" opacity="0.7"/></g>',
    sand: () => gEl(0, 2, 22, 'fill="#2d4a22" opacity="0.18"') + '<g class="ygs-pop"><path d="M-24 2C-20 -8 -8 -13 0 -13C10 -13 20 -8 24 2Z" fill="#f1d48a" stroke="#c9a456" stroke-width="1.8"/><path d="M-10 -6h3M2 -9h3M10 -3h3M-3 -2h3" stroke="#c9a456" stroke-width="1.6" stroke-linecap="round"/><path d="M6 -10L14 -26" stroke="#ff7a8a" stroke-width="2.6" stroke-linecap="round"/><path d="M12 -30L18 -26L14 -20L9 -24Z" fill="#ffb84a" stroke="#d07a20" stroke-width="1.2"/></g>',
    leaves: () => { let s = gEl(0, 2, 22, 'fill="#2d4a22" opacity="0.15"') + '<g class="ygs-pop">'; [[-14, -2, '#ff9a3a', 20], [-2, -6, '#ffcf3a', -30], [10, -1, '#e8623a', 60], [-6, 2, '#ffb84a', 100], [4, -10, '#d9482a', -70], [16, -6, '#ffd84a', 10], [-18, -8, '#e8623a', 140]].forEach(([x, y, c, r]) => {
      s += '<path transform="translate(' + x + ' ' + y + ') rotate(' + r + ')" d="M-8 0Q-3 -6 4 -5Q9 -2 8 0Q4 5 -3 4Q-7 3 -8 0Z" fill="' + c + '" stroke="#9a3a1a" stroke-width="1"/>'; }); return s + '</g>'; },
    mud: (it) => '<path d="' + blob(DEF.mud.hs, DEF.mud.hw * HW, 0.18, it.s % 7) + '" fill="#8a5a34" stroke="#6e4426" stroke-width="2"/><path d="' + blob(DEF.mud.hs * 0.55, DEF.mud.hw * HW * 0.5, 0.25, it.s % 5) + '" fill="#6e4426" transform="translate(-6 2)"/>'
      + gEl(-18, -2, 4, 'fill="#a87a4e"') + gEl(14, 4, 3, 'fill="#a87a4e"') + gEl(24, -8, 2.4, 'fill="#c49a6a"'),
    slick: (it) => '<path class="ygs-shim" d="' + blob(DEF.slick.hs, DEF.slick.hw * HW, 0.12, it.s % 9) + '" fill="#8fdcff" stroke="#ffffff" stroke-width="2.5"/><path d="M' + P2(G3(-30, -6)) + 'L' + P2(G3(20, -10)) + 'M' + P2(G3(-14, 10)) + 'L' + P2(G3(30, 6)) + '" stroke="#ffffff" stroke-width="3" stroke-linecap="round" opacity="0.85"/>'
      + '<path class="ygs-tw" d="M0 -9C0.9 -3 3 -1 9 0C3 1 0.9 3 0 9C-0.9 3 -3 1 -9 0C-3 -1 -0.9 -3 0 -9Z" fill="#ffffff" transform="translate(' + P2(G3(8, 2, 6)) + ')"/>',
    gold: () => { let s = '<path class="ygs-glow" d="' + poly([G3(-34, -24), G3(34, -24), G3(34, 24), G3(-34, 24)]) + '" fill="#ffe36e" stroke="#d79a22" stroke-width="2.5" stroke-linejoin="round"/>';
      [-18, 0, 18].forEach(d => { s += '<path d="' + poly([G3(d - 9, -14), G3(d + 5, 0), G3(d - 9, 14), G3(d - 3, 14), G3(d + 11, 0), G3(d - 3, -14)]) + '" fill="#ff8a3d" stroke="#ffffff" stroke-width="1.4" stroke-linejoin="round"/>'; }); return s; },
    ramp: () => { const w = 0.95 * HW, top = [G3(-30, -w, 0), G3(30, -w, 18), G3(30, w, 18), G3(-30, w, 0)]; let s = '<path d="' + poly([G3(-30, -w, 0), G3(30, -w, 0), G3(30, -w, 18)]) + '" fill="#9a6232" stroke="#6b4426" stroke-width="1.6" stroke-linejoin="round"/>'
      + '<path d="' + poly([G3(30, -w, 0), G3(30, w, 0), G3(30, w, 18), G3(30, -w, 18)]) + '" fill="#b47740" stroke="#6b4426" stroke-width="1.6" stroke-linejoin="round"/><path d="' + poly(top) + '" fill="#e2ad74" stroke="#6b4426" stroke-width="1.8" stroke-linejoin="round"/>';
      for (let i = 1; i < 4; i++) { const ds = -30 + i * 15; s += '<path d="M' + P2(G3(ds, -w, (ds + 30) * 0.3)) + 'L' + P2(G3(ds, w, (ds + 30) * 0.3)) + '" stroke="#b47740" stroke-width="1.4"/>'; }
      return s + '<path d="' + poly([G3(-8, -10, 6.6), G3(8, 0, 11.4), G3(-8, 10, 6.6)]) + '" fill="#ffd84a" stroke="#ffffff" stroke-width="1.2"/>'; } };
  // ---------- art: the backyard round the slide ----------
  const tree = (k, c1, c2) => gEl(0, 2, 30 * k, 'fill="#2d4a22" opacity="0.22"') + '<rect x="' + r2(-5 * k) + '" y="' + r2(-38 * k) + '" width="' + r2(10 * k) + '" height="' + r2(40 * k) + '" rx="3" fill="#8a5a34"/>'
    + [[-17, -48, 21], [15, -50, 23], [0, -70, 25], [-4, -46, 18]].map(([x, y, r]) => '<circle cx="' + r2(x * k) + '" cy="' + r2(y * k) + '" r="' + r2(r * k) + '" fill="' + c1 + '"/>').join('') + '<circle cx="' + r2(-7 * k) + '" cy="' + r2(-76 * k) + '" r="' + r2(10 * k) + '" fill="' + c2 + '" opacity="0.9"/><circle cx="' + r2(12 * k) + '" cy="' + r2(-56 * k) + '" r="' + r2(7 * k) + '" fill="' + c2 + '" opacity="0.7"/>';
  const bush = (k, c) => gEl(0, 2, 20 * k, 'fill="#2d4a22" opacity="0.2"') + [[-11, -9, 11], [9, -10, 12], [0, -18, 13]].map(([x, y, r]) => '<circle cx="' + r2(x * k) + '" cy="' + r2(y * k) + '" r="' + r2(r * k) + '" fill="#57a854"/>').join('') + '<circle cx="' + r2(-3 * k) + '" cy="' + r2(-22 * k) + '" r="' + r2(5 * k) + '" fill="#7cc46a"/>'
    + (c ? [[-8, -14], [8, -18], [2, -8]].map(([x, y]) => '<circle cx="' + r2(x * k) + '" cy="' + r2(y * k) + '" r="' + r2(2.6 * k) + '" fill="' + c + '"/>').join('') : '');
  const flowers = (sd) => { const R = rnd(sd); let s = ''; for (let i = 0; i < 5; i++) { const x = (R() - 0.5) * 30, y = (R() - 0.5) * 10, h = 8 + R() * 8, c = ['#ff8fc8', '#fff3a8', '#ffffff', '#d9c8ff', '#ffb0a0'][i % 5];
      s += '<path d="M' + r2(x) + ' ' + r2(y) + 'V' + r2(y - h) + '" stroke="#4f9a3e" stroke-width="1.6"/>'; for (let j = 0; j < 5; j++) s += '<circle cx="' + r2(x + Math.cos(j * 1.2566) * 2.8) + '" cy="' + r2(y - h + Math.sin(j * 1.2566) * 2.8) + '" r="2.2" fill="' + c + '"/>'; s += '<circle cx="' + r2(x) + '" cy="' + r2(y - h) + '" r="1.5" fill="#ffb84a"/>'; } return s; };
  const pinwheel = c => '<path d="M0 0V-40" stroke="#e8e0d4" stroke-width="2.6" stroke-linecap="round"/><g transform="translate(0 -40)"><g class="ygs-spin">' + [0, 90, 180, 270].map((a, i) => '<path transform="rotate(' + a + ')" d="M0 0L0 -12L9 -9Z" fill="' + [c, '#ffffff', c, '#ffd84a'][i] + '" stroke="#4a3a2e" stroke-width="0.8"/>').join('') + '</g><circle r="1.8" fill="#ffd84a"/></g>';
  const sprinkler = () => '<ellipse cy="1" rx="8" ry="3" fill="#2d4a22" opacity="0.25"/><path d="M-3 0V-10H3V0Z" fill="#9aa0a8"/><circle cy="-11" r="3.4" fill="#5cb8ff"/><path class="ygs-spr" d="M0 -12Q-26 -60 -58 -14" stroke="#bfe8ff" stroke-width="3.4" fill="none" stroke-linecap="round" stroke-dasharray="6 9"/><path class="ygs-spr" d="M0 -12Q22 -52 50 -18" stroke="#dff4ff" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-dasharray="5 10"/>';
  const birdhouse = () => '<path d="M0 0V-46" stroke="#a46c3a" stroke-width="4"/><path d="M-10 -46V-62H10V-46Z" fill="#ffb0a0" stroke="#b05a4a" stroke-width="1.4"/><path d="M-13 -60L0 -72L13 -60Z" fill="#7a5ad0" stroke="#4a2e8a" stroke-width="1.4" stroke-linejoin="round"/><circle cy="-54" r="3" fill="#5a3a2a"/>';
  const shed = () => gEl(0, 4, 46, 'fill="#2d4a22" opacity="0.2"') + '<path d="M-34 0V-38H22V0Z" fill="#ffd2a0" stroke="#b07a46" stroke-width="2"/><path d="M22 0V-38L40 -48V-10Z" fill="#e8b67c" stroke="#b07a46" stroke-width="2" stroke-linejoin="round"/><path d="M-40 -36L-6 -62L28 -36Z" fill="#e06a5a" stroke="#9a3a2e" stroke-width="2" stroke-linejoin="round"/><path d="M28 -36L-6 -62L12 -72L46 -46Z" fill="#c85848" stroke="#9a3a2e" stroke-width="2" stroke-linejoin="round"/>'
    + '<rect x="-14" y="-26" width="14" height="26" rx="2" fill="#a46c3a"/><rect x="4" y="-30" width="12" height="10" rx="2" fill="#bfe8ff" stroke="#ffffff" stroke-width="2"/>';
  const haystack = () => gEl(0, 2, 26, 'fill="#2d4a22" opacity="0.2"') + '<path d="M-26 0C-26 -22 -12 -40 0 -40C12 -40 26 -22 26 0Z" fill="#f2cf6a" stroke="#b88a2a" stroke-width="1.8"/><path d="M-14 -10l6 -12M2 -6l3 -16M14 -12l-4 -10M-4 -26l2 -8" stroke="#c99a36" stroke-width="1.6" stroke-linecap="round"/>';
  const sunflower = () => '<path d="M0 0V-48" stroke="#4f9a3e" stroke-width="2.6"/><path d="M0 -20Q8 -26 12 -20Q6 -16 0 -20Z" fill="#57a854"/>' + [...Array(10)].map((_, i) => '<ellipse transform="translate(0 -52) rotate(' + i * 36 + ')" cy="-8" rx="3.4" ry="6" fill="#ffd84a"/>').join('') + '<circle cy="-52" r="6" fill="#8a5a34"/>';
  const lounger = () => gEl(10, 4, 34, 'fill="#2d4a22" opacity="0.18"') + '<path d="M-28 0V-8M28 0V-8M-28 -8H14L30 -30" stroke="#e8e0d4" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M-26 -12H14L28 -32" stroke="#5cb8ff" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M-20 -12H8" stroke="#ffffff" stroke-width="2" stroke-dasharray="4 4"/>';
  const umbrella = () => '<path d="M0 0V-70" stroke="#e8e0d4" stroke-width="3"/><path d="M-40 -62Q0 -96 40 -62Q30 -66 20 -62Q10 -66 0 -62Q-10 -66 -20 -62Q-30 -66 -40 -62Z" fill="#ff7a8a" stroke="#c8485a" stroke-width="1.6" stroke-linejoin="round"/><path d="M-20 -62Q-12 -84 0 -88M20 -62Q12 -84 0 -88" stroke="#ffffff" stroke-width="5" fill="none" opacity="0.85"/>';
  const ball = () => '<g class="ygs-bob">' + gEl(0, 0, 11, 'fill="#2d4a22" opacity="0.18"') + '<circle cy="-11" r="11" fill="#ffffff" stroke="#c8c0b4" stroke-width="1.4"/><path d="M0 -22A11 11 0 0 1 11 -11L0 -11Z" fill="#ff7a8a"/><path d="M0 0A11 11 0 0 1 -11 -11L0 -11Z" fill="#5cb8ff"/><path d="M-11 -11A11 11 0 0 1 0 -22L0 -11Z" fill="#ffd84a"/><circle cx="-4" cy="-15" r="3" fill="#ffffff" opacity="0.7"/></g>';
  const donut = () => '<g class="ygs-bob">' + gEl(0, 0, 26, 'fill="#ff8fc8" stroke="#d05a98" stroke-width="2"') + gEl(0, -1, 11, 'fill="#4fb4ec"') + gEl(-6, -6, 8, 'fill="#ffffff" opacity="0.4"') + '</g>';
  const fence = (len) => { let s = gEl(len / 2, 3, len * 0.42, 'fill="#2d4a22" opacity="0.12"'); const a = G3(0, 0, 9), b = G3(len, 0, 9), a2 = G3(0, 0, 18), b2 = G3(len, 0, 18);
    s += '<path d="M' + P2(a) + 'L' + P2(b) + 'M' + P2(a2) + 'L' + P2(b2) + '" stroke="#e8dccb" stroke-width="4" stroke-linecap="round"/>'; for (let d = 0; d <= len; d += 14) { const q = G3(d, 0, 0); s += '<path d="M' + r2(q[0] - 3) + ' ' + r2(q[1]) + 'V' + r2(q[1] - 22) + 'L' + r2(q[0]) + ' ' + r2(q[1] - 26) + 'L' + r2(q[0] + 3) + ' ' + r2(q[1] - 22) + 'V' + r2(q[1]) + 'Z" fill="#fffaf2" stroke="#d8c9b0" stroke-width="1"/>'; } return s; };
  const bed = (sd) => '<path d="' + blob(46, 22, 0.12, sd) + '" fill="#a8754a" stroke="#8a5a34" stroke-width="2"/>' + flowers(sd);
  function css() { if (document.getElementById('ygs-css')) return; const st = document.createElement('style'); st.id = 'ygs-css'; st.textContent =
    '.ygs-spin{animation:ygsSpin 1.1s linear infinite;}@keyframes ygsSpin{to{transform:rotate(360deg);}}'
    + '.ygs-spr{animation:ygsSpr .6s linear infinite;}@keyframes ygsSpr{to{stroke-dashoffset:-30;}}'
    + '.ygs-bob{animation:ygsBob 1.8s ease-in-out infinite;}@keyframes ygsBob{50%{transform:translateY(-2.5px);}}'
    + '.ygs-glow{animation:ygsGlow .7s ease-in-out infinite alternate;}@keyframes ygsGlow{to{fill:#fff3b0;}}'
    + '.ygs-shim{animation:ygsShim 1.2s ease-in-out infinite alternate;}@keyframes ygsShim{to{fill:#b6ecff;}}'
    + '.ygs-tw{animation:ygsTw .9s ease-in-out infinite alternate;transform-box:fill-box;transform-origin:center;}@keyframes ygsTw{from{opacity:.3;}to{opacity:1;}}'
    + '.ygs-tip,.ygs-pop{transform-box:fill-box;transform-origin:50% 100%;transition:transform .35s cubic-bezier(.3,1.5,.5,1),opacity .4s;}'
    + '.ygs-hit .ygs-tip{transform:rotate(78deg) translateY(4px);}.ygs-hit .ygs-pop{transform:scale(1.25,0.35);opacity:0.6;}';
    document.head.appendChild(st); }

  YG.add({ id: 'slide', land: true, name: 'Slide & Splash', item: 'Slides', color: '#3fd0c0', icon: ICON, stars: [550, 750, 950], coinK: 0.08,
    hint: 'Drag up or down to switch sides · grab splash slicks + gold arrows · dodge the rest',
    how: ['Slide down the big backyard slide: drag up or down (or use the arrow keys) to switch sides.', 'Splash slicks and gold arrows speed you up. Rocks, gnomes, hay, mud and sand slow you down. Wooden bumps hop you over logs.', 'At the end you fly off into the kiddie pool: the faster you go, the bigger the splash - your friends get soaked!'],
    options: [{ id: 'rainbow', label: 'Rainbow' }, { id: 'gold', label: 'Gold' }, { id: 'wood', label: 'Wooden' }],
    make(ctx) {
      const { bg, fg, W, H } = ctx; css(); let look = ctx.G._opt || 'rainbow';
      const slideBg = S('rect', { x: -20, y: -20, width: W + 40, height: H + 40, fill: '#79c25c' }, bg);
      const wB = S('g', {}, bg), gStart = S('g', {}, wB), gGround = S('g', {}, wB), gEnd = S('g', {}, wB), gDecal = S('g', {}, wB), gShadow = S('g', {}, wB), gBack = S('g', {}, wB);
      const scB = S('g', { style: 'display:none' }, bg);
      const wF = S('g', {}, fg), gStartF = S('g', {}, wF), gNear = S('g', {}, wF), gEndF = S('g', {}, wF), gFront = S('g', {}, wF);
      const scF = S('g', { style: 'display:none' }, fg), speedL = S('g', {}, fg), hud = S('g', {}, fg);
      const meSh = S('ellipse', { rx: r2(20 * EL.kx), ry: r2(20 * EL.ky), fill: '#2a3a20', opacity: 0.22 }, gShadow);
      // ---------- standing things: depth sorted round the creature ----------
      const stands = []; let riderD = 0;
      function sortIn(o, fr) { const par = fr ? gFront : gBack; let ref = null; for (let c = par.firstChild; c; c = c.nextSibling) if (c._d > o.d) { ref = c; break; } o.el._d = o.d; par.insertBefore(o.el, ref); o.fr = fr; }
      function addStand(html, s, l, h) { const el = S('g', { transform: 'translate(' + P2(Wp(s, l, h || 0)) + ')' }); el.innerHTML = html; const o = { el, d: Wp(s, l, 0)[1], fr: null }; stands.push(o); sortIn(o, o.d > riderD); return o; }
      function dropStand(o) { o.el.remove(); const i = stands.indexOf(o); if (i >= 0) stands.splice(i, 1); }
      // ---------- the slide: a narrow chute up on posts, level all the way down the hill (in chunks) ----------
      const chunks = new Map(), Lp = px => px / HW;
      const post = (L, s, l, h0, h1, w) => '<path d="M' + P2(Wp(s, l, h0)) + 'L' + P2(Wp(s, l, h1)) + '" stroke="' + L.postD + '" stroke-width="' + ((w || 6) + 2.4) + '" stroke-linecap="round"/><path d="M' + P2(Wp(s, l, h0)) + 'L' + P2(Wp(s, l, h1)) + '" stroke="' + L.post + '" stroke-width="' + (w || 6) + '" stroke-linecap="round"/>';
      function surface(a, b) { const L = LOOK[look]; let d = ''; if (b <= a) return d;
        if (L.bands) { const n = L.bands.length; L.bands.forEach((c, i) => { d += '<path d="' + quad(a, b, -1 + 2 * i / n, -1 + 2 * (i + 1) / n, SH) + '" fill="' + c + '" stroke="' + c + '" stroke-width="0.7"/>'; }); }
        else for (let s = Math.floor(a / 36) * 36; s < b; s += 36) { const x0 = Math.max(s, a), x1 = Math.min(s + 36, b); d += '<path d="' + quad(x0, x1, -1, 1, SH) + '" fill="' + L.planks[Math.round(s / 36) & 1] + '" stroke="' + L.seam + '" stroke-width="1"/>'; }
        // ripples every 50 + a seam every 150: what you see rush past
        for (let s = Math.ceil(a / 50) * 50; s < b; s += 50) { const seam = s % 150 === 0; d += '<path d="M' + P2(Wp(s, -1, SH)) + 'L' + P2(Wp(s, 1, SH)) + '" stroke="' + L.seam + '" stroke-width="' + (seam ? 2.6 : 1.3) + '" opacity="' + (seam ? 0.6 : 0.35) + '"/>'; }
        const R = rnd(Math.round(a) + 7); for (let k = 0; k < 4; k++) { const s = a + R() * (b - a), l = -0.8 + R() * 1.6; if (s + 40 < b) d += '<path d="M' + P2(Wp(s, l, SH)) + 'L' + P2(Wp(s + 26 + R() * 20, l, SH)) + '" stroke="' + L.shine + '" stroke-width="2" stroke-linecap="round" opacity="0.5"/>'; }
        return d; }
      // behind the chute: its shadow on the grass, the far posts + braces, the far wall; in front of it (fg): the near posts + the near wall
      function farSide(a, b) { const L = LOOK[look]; let d = '<path d="' + quad(a, b, -1.1, 1.1, 0) + '" fill="#2a3a20" opacity="0.14"/>';
        for (let x = Math.ceil(a / 70) * 70; x < b; x += 70) { d += post(L, x, 1.06, 0, SH - 6, 5); if ((x / 70) % 2 === 0 && x + 70 <= RS) d += '<path d="M' + P2(Wp(x, 1.06, 6)) + 'L' + P2(Wp(x + 70, 1.06, SH - 12)) + '" stroke="' + L.postD + '" stroke-width="2.6" opacity="0.7"/>'; }
        return d; }
      const farWall = (a, b) => { const L = LOOK[look]; return '<path d="' + poly([Wp(a, 1, SH), Wp(b, 1, SH), Wp(b, 1, SH + WH), Wp(a, 1, SH + WH)]) + '" fill="' + L.face + '"/><path d="' + quad(a, b, 1, 1.12, SH + WH) + '" fill="' + L.top + '" stroke="' + L.side + '" stroke-width="1"/>'; };
      function nearSide(a, b) { const L = LOOK[look]; let d = ''; for (let x = Math.ceil(a / 70) * 70; x < b; x += 70) d += post(L, x, -1.06, 0, SH - 6, 5);
        return d + '<path d="' + poly([Wp(a, -1.12, SH - 9), Wp(b, -1.12, SH - 9), Wp(b, -1.12, SH + WH), Wp(a, -1.12, SH + WH)]) + '" fill="' + L.side + '"/><path d="' + quad(a, b, -1.12, -1, SH + WH) + '" fill="' + L.top + '" stroke="' + L.side + '" stroke-width="1"/>'
          + '<path d="M' + P2(Wp(a, -1.12, SH - 9)) + 'L' + P2(Wp(b, -1.12, SH - 9)) + '" stroke="#000" stroke-opacity="0.15" stroke-width="2"/>'; }
      function buildChunk(i) { const s0 = i * CS, s1 = s0 + CS, R = rnd(1000 + i * 37), sec = secAt(s0); let d = '', dn = '';
        const clear = (s, lp) => s < 60 && s > T0 - 170 && lp > -170 && lp < 120;   // the tower's spot
        for (let k = 0; k < 4; k++) { const s = s0 + R() * CS, lp = k > 1 ? -90 - R() * 230 : 90 + R() * 380; if (clear(s, lp)) continue; d += '<path d="' + blob(60 + R() * 60, 30 + R() * 30, 0.15, k + i) + '" transform="translate(' + P2(Wp(s, Lp(lp), 0)) + ')" fill="' + (k & 1 ? '#86cc66' : '#6cb551') + '" opacity="0.55"/>'; }
        for (let k = 0; k < 26; k++) { const s = s0 + R() * CS, lp = k < 11 ? -75 - R() * 260 : 75 + R() * 420, p = Wp(s, Lp(lp), 0), q = 0.8 + R() * 0.5; if (clear(s, lp)) continue; d += '<path d="M' + r2(p[0] - 4 * q) + ' ' + r2(p[1]) + 'l' + r2(2 * q) + ' ' + r2(-7 * q) + 'l' + r2(2 * q) + ' ' + r2(5 * q) + 'l' + r2(2 * q) + ' ' + r2(-8 * q) + 'l' + r2(2 * q) + ' ' + r2(8 * q) + 'Z" fill="#5aa946" opacity="0.8"/>'; }
        for (let k = 0; k < 8; k++) { const s = s0 + R() * CS, lp = R() < 0.4 ? -80 - R() * 230 : 80 + R() * 380, p = Wp(s, Lp(lp), 0), c = ['#ffd1e8', '#fff3a8', '#ffffff', '#d9c8ff'][k % 4]; if (clear(s, lp)) continue; for (let j = 0; j < 5; j++) d += '<circle cx="' + r2(p[0] + Math.cos(j * 1.2566) * 2.4) + '" cy="' + r2(p[1] + Math.sin(j * 1.2566) * 2.4) + '" r="1.8" fill="' + c + '"/>'; }
        if (sec === 'farm') for (let k = 0; k < 2; k++) { const s = s0 + R() * CS, lp = 120 + R() * 200; d += '<path d="' + blob(70, 22, 0.1, k) + '" transform="translate(' + P2(Wp(s, Lp(lp), 0)) + ')" fill="#c9a456" opacity="0.35"/>'; }
        if (s0 < RS && s1 > SD0) { const a = Math.max(s0, SD0), b = Math.min(s1, RS); d += farSide(a, b) + surface(a, b) + farWall(a, b); dn += nearSide(a, b); }
        const g = S('g', {}); g.innerHTML = d; g._i = i; let ref = null; for (let c = gGround.firstChild; c; c = c.nextSibling) if (c._i > i) { ref = c; break; } gGround.insertBefore(g, ref);
        const gn = S('g', {}); gn.innerHTML = dn; gn._i = i; ref = null; for (let c = gNear.firstChild; c; c = c.nextSibling) if (c._i > i) { ref = c; break; } gNear.insertBefore(gn, ref);
        const st = [], n = 8 + Math.floor(R() * 4); for (let k = 0; k < n; k++) { const s = s0 + R() * CS, far = R() < 0.62, r = R(); let html, lp;
          if (far) { lp = 95 + R() * 380; html = sec === 'farm' ? (r < 0.4 ? haystack() : r < 0.75 ? sunflower() : tree(0.9, '#57a854', '#7cc46a')) : sec === 'sprinkle' ? (r < 0.45 ? sprinkler() : r < 0.7 ? pinwheel('#5cb8ff') : tree(1, '#4f9e45', '#6cbb5c'))
              : sec === 'garden' ? (r < 0.3 ? birdhouse() : r < 0.55 ? bush(1, '#ff8fc8') : r < 0.65 && lp > 200 ? shed() : tree(1.05, '#57a854', '#7cc46a')) : (r < 0.5 ? tree(0.8 + R() * 0.4, '#57a854', '#7cc46a') : r < 0.75 ? bush(0.9, '#fff3a8') : pinwheel('#ff7a8a')); }
          else { lp = -85 - R() * 30; html = r < 0.45 ? flowers(i * 7 + k) : r < 0.55 ? '<g transform="scale(0.55)">' + ART.rock() + '</g>' : r < 0.65 ? pinwheel(['#ff7a8a', '#5cb8ff', '#ffb84a'][k % 3]) : '';
            if (r >= 0.65) { lp = -140 - R() * 180; html = r > 0.9 ? tree(0.8, '#5fb04a', '#7cc46a') : r > 0.8 ? bush(1, sec === 'garden' ? '#ff8fc8' : '#fff3a8') : r > 0.72 ? fence(84 + Math.round(R() * 3) * 14) : bed(i * 5 + k); } }
          if (html && !clear(s, lp)) st.push(addStand(html, s, Lp(lp))); }
        chunks.set(i, { g, gn, st }); }
      function dropChunk(i) { const c = chunks.get(i); if (!c) return; c.g.remove(); c.gn.remove(); c.st.forEach(dropStand); chunks.delete(i); }
      function ensure(sc, z) { const a = Math.floor((sc - 700 / z) / CS), b = Math.floor((sc + 1300 / z) / CS); for (const i of [...chunks.keys()]) if (i < a || i > b) dropChunk(i); for (let i = a; i <= b; i++) if (!chunks.has(i)) buildChunk(i); }
      // ---------- the tower at the top (deck level with the chute) + the lip at the end (built once) ----------
      function buildStatic() { const L = LOOK[look]; let b = '', f = '';
        const a = T0, z = SD0, lN = -1.15, lF = 1.15, RT = SH + 56, bar = (pts, w) => '<path d="M' + pts.map(P2).join('L') + '" stroke="' + L.postD + '" stroke-width="' + (w + 2.4) + '" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M' + pts.map(P2).join('L') + '" stroke="' + L.post + '" stroke-width="' + w + '" fill="none" stroke-linecap="round" stroke-linejoin="round"/>';
        b += '<path d="' + quad(a - 14, z + 20, lN - 0.15, lF + 0.15, 0) + '" fill="#2a3a20" opacity="0.16"/>' + post(L, a, lF, 0, RT, 7) + post(L, a, lN, 0, RT, 7) + post(L, z, lF, 0, RT, 7);
        b += bar([Wp(a, lF, 10), Wp(z, lF, SH - 14)], 3.6) + bar([Wp(a, lN, 10), Wp(a, lF, SH - 14)], 3.6);
        b += '<path d="' + quad(a, z, lN, lF, SH) + '" fill="' + L.deck + '" stroke="' + L.postD + '" stroke-width="1.5" stroke-linejoin="round"/>'; for (let s = a + 22; s < z - 5; s += 22) b += '<path d="M' + P2(Wp(s, lN, SH)) + 'L' + P2(Wp(s, lF, SH)) + '" stroke="' + L.postD + '" stroke-width="1" opacity="0.45"/>';
        [28, 54].forEach(h => { b += bar([Wp(a, lN, SH + h), Wp(a, lF, SH + h), Wp(z, lF, SH + h)], 4.4); }); for (let l = lN + 0.38; l < lF - 0.1; l += 0.38) b += bar([Wp(a, l, SH), Wp(a, l, SH + 54)], 2.8); for (let s = a + 30; s < z - 8; s += 30) b += bar([Wp(s, lF, SH), Wp(s, lF, SH + 54)], 2.8);
        b += '<circle cx="' + r2(Wp(z, lF, RT + 3)[0]) + '" cy="' + r2(Wp(z, lF, RT + 3)[1]) + '" r="5.5" fill="' + (L.bands ? L.bands[0] : '#ff7a8a') + '" stroke="' + L.postD + '" stroke-width="1.5"/><circle cx="' + r2(Wp(a, lF, RT + 3)[0]) + '" cy="' + r2(Wp(a, lF, RT + 3)[1]) + '" r="5.5" fill="' + (L.bands ? L.bands[4] : '#5cb8ff') + '" stroke="' + L.postD + '" stroke-width="1.5"/>';
        const fp = Wp(a, lN, RT); b += '<path d="M' + P2(fp) + 'V' + r2(fp[1] - 30) + '" stroke="' + L.postD + '" stroke-width="2.2"/><path d="M' + r2(fp[0]) + ' ' + r2(fp[1] - 30) + 'l20 5.5l-20 6.5Z" fill="#ff7a8a" stroke="#c8485a" stroke-width="1.3" stroke-linejoin="round"/>';
        // the lip: the last stretch curves up (far side behind you), its near panel + end face in front
        const N = 12, sAt = j => RS + (LEN - RS) * j / N; let lip = '';
        for (let j = 0; j < N; j++) { const s0 = sAt(j), s1 = sAt(j + 1), h0 = HS(s0), h1 = HS(s1);
          if (L.bands) L.bands.forEach((c, i) => { const n = L.bands.length; lip += '<path d="' + quad(s0, s1, -1 + 2 * i / n, -1 + 2 * (i + 1) / n, h0, h1) + '" fill="' + c + '" stroke="' + c + '" stroke-width="0.8"/>'; });
          else lip += '<path d="' + quad(s0, s1, -1, 1, h0, h1) + '" fill="' + L.planks[j & 1] + '" stroke="' + L.seam + '" stroke-width="1"/>';
          lip += '<path d="M' + P2(Wp(s0, -1, h0)) + 'L' + P2(Wp(s0, 1, h0)) + '" stroke="' + L.seam + '" stroke-width="1.3" opacity="0.35"/>'; }
        const edge = (l, dh) => { const o = []; for (let j = 0; j <= N; j++) o.push(Wp(sAt(j), l, HS(sAt(j)) + dh)); return o; }, rev = q => q.slice().reverse();
        let lipB = '<path d="' + quad(RS, LEN + 10, -1.1, 1.1, 0) + '" fill="#2a3a20" opacity="0.14"/>' + post(L, RS + 90, 1.06, 0, HS(RS + 90) - 6, 5) + post(L, LEN - 8, 1.06, 0, HS(LEN - 8) - 6, 6);
        lipB += lip + '<path d="' + poly(edge(1, 0).concat(rev(edge(1, WH)))) + '" fill="' + L.face + '"/><path d="' + poly(edge(1, WH).concat(rev(edge(1.12, WH)))) + '" fill="' + L.top + '" stroke="' + L.side + '" stroke-width="1"/>';
        let lipF = post(L, RS + 90, -1.06, 0, HS(RS + 90) - 6, 5) + post(L, LEN - 8, -1.06, 0, HS(LEN - 8) - 6, 6);
        lipF += '<path d="' + poly(edge(-1.12, -9).concat(rev(edge(-1.12, WH)))) + '" fill="' + L.side + '"/><path d="' + poly(edge(-1.12, WH).concat(rev(edge(-1, WH)))) + '" fill="' + L.top + '" stroke="' + L.side + '" stroke-width="1"/>';
        lipF += '<path d="' + poly([Wp(LEN, -1.12, HS(LEN) - 9), Wp(LEN, 1.12, HS(LEN) - 9), Wp(LEN, 1.12, HS(LEN) + WH), Wp(LEN, -1.12, HS(LEN) + WH)]) + '" fill="' + L.side + '" stroke="#000" stroke-opacity="0.12" stroke-width="1.4"/><path d="M' + P2(Wp(LEN, -1, HS(LEN) + 1)) + 'L' + P2(Wp(LEN, 1, HS(LEN) + 1)) + '" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/>';
        gStart.innerHTML = b; gEnd.innerHTML = lipB; gEndF.innerHTML = lipF;
        // the ladder up the near side of the tower (in front of you)
        f += post(L, a, lN, 0, RT, 7) + post(L, z, lN, 0, RT, 7); const lad = s => [Wp(s, lN - 1.0, 0), Wp(s, lN, SH + 18)]; f += bar(lad(-128), 3.8) + bar(lad(-84), 3.8);
        for (let k = 1; k <= 4; k++) { const h = k * SH / 5, l = lN - 1.0 + 1.0 * h / (SH + 18); f += bar([Wp(-128, l, h), Wp(-84, l, h)], 3); }
        gStartF.innerHTML = f; }
      // ---------- the run: what's on the slide (two halves: left / right) ----------
      let items = [], nextI = 0, alive = [];
      function gen(seed) { const R = rnd(seed), out = [], add = (t, s, l) => out.push(Object.assign({ t, s, l, hit: 0 }, DEF[t])), LN = [-0.5, 0.5];
        let s = 520;
        while (s < RS - 600) { const sec = secAt(s), r = R(), A = LN[R() < 0.5 ? 0 : 1], B = -A, soft = () => ['sand', 'leaves', 'bucket'][Math.floor(R() * 3)];
          if (sec === 'meadow') { if (r < 0.34) add(soft(), s, A); else if (r < 0.6) add('slick', s, A); else if (r < 0.85) { add(soft(), s, A); add('slick', s + 20, B); } else add('ramp', s, 0); }
          else if (sec === 'garden') { if (r < 0.25) add('gnome', s, A); else if (r < 0.45) { add('gnome', s, A); add('bucket', s + 200, B); } else if (r < 0.6) add('mud', s, A); else if (r < 0.82) { add('slick', s, A); add('gnome', s + 190, A); } else add('gold', s, A); }
          else if (sec === 'farm') { if (r < 0.25) add('hay', s, A); else if (r < 0.45) { add('hay', s, A); add('hay', s + 210, B); } else if (r < 0.62) { add('ramp', s, 0); add('log', s + 100, 0); } else if (r < 0.78) add('mud', s, A); else if (r < 0.92) { add('hay', s, A); add('slick', s, B); } else { add('hay', s, A); add('gold', s + 160, B); } }
          else if (sec === 'sprinkle') { if (r < 0.28) { add('slick', s, A); add('slick', s + 200, B); } else if (r < 0.45) { add('rock', s, A); add('slick', s, B); } else if (r < 0.62) { add('rock', s, A); add('rock', s + 210, B); } else if (r < 0.74) add('mud', s, A); else if (r < 0.86) add('gold', s, A); else { add('ramp', s, 0); add('log', s + 100, 0); } }
          else { if (r < 0.3) { add('rock', s, A); add('gnome', s + 210, B); } else if (r < 0.55) { add('slick', s, A); add('rock', s + 200, A); } else if (r < 0.75) { add('hay', s, A); add('slick', s, B); } else if (r < 0.88) add('mud', s, A); else { add('rock', s, A); add('gold', s + 170, B); } }
          s += lerp(420, 330, s / LEN) * (0.88 + R() * 0.3); }
        return out.sort((a, b) => a.s - b.s); }
      function spawn(it) { const html = ART[it.t](it);
        if (it.flat) { it.el = S('g', { transform: 'translate(' + P2(Wp(it.s, it.l, SH)) + ')' }, gDecal); it.el.innerHTML = html; }
        else { it.o = addStand(html, it.s, it.l, SH); it.el = it.o.el; } alive.push(it); }
      function despawn(it) { if (it.o) dropStand(it.o); else if (it.el) it.el.remove(); it.el = it.o = null; }
      function feed(sc, z) { const lo = sc - 700 / z, hi = sc + 1300 / z; while (nextI < items.length && items[nextI].s < hi) { if (items[nextI].s > lo) spawn(items[nextI]); nextI++; }
        for (let i = alive.length - 1; i >= 0; i--) if (alive[i].s < lo) { despawn(alive[i]); alive.splice(i, 1); } }
      // ---------- HUD: speedometer (bottom left) + progress (bottom middle) ----------
      const sp = S('g', { transform: 'translate(66 ' + (H - 54) + ')' }, hud); S('rect', { x: -52, y: -50, width: 104, height: 72, rx: 24, fill: '#ffffff', opacity: 0.94, stroke: '#4a1a73', 'stroke-width': 2.5 }, sp);
      const ARC = 'M-36 4A36 36 0 0 1 36 4', arcL = Math.PI * 36; S('path', { d: ARC, fill: 'none', stroke: '#ece6fa', 'stroke-width': 9, 'stroke-linecap': 'round' }, sp);
      const spArc = S('path', { d: ARC, fill: 'none', stroke: '#5cc87a', 'stroke-width': 9, 'stroke-linecap': 'round', 'stroke-dasharray': '0 999' }, sp);
      const spTx = S('text', { y: 0, 'text-anchor': 'middle', 'font-family': 'Fredoka, sans-serif', 'font-weight': 700, 'font-size': 25, fill: '#4a1a73' }, sp); spTx.textContent = '0';
      S('text', { y: 15, 'text-anchor': 'middle', 'font-family': 'Nunito, sans-serif', 'font-weight': 800, 'font-size': 9.5, fill: '#8a6ab0', 'letter-spacing': 1 }, sp).textContent = 'KM/H';
      const tierG = S('g', { transform: 'translate(0 36)' }, sp), tierR = S('rect', { x: -48, y: -10, width: 96, height: 20, rx: 10, fill: '#bfe8ff', stroke: '#4a1a73', 'stroke-width': 2 }, tierG), tierTx = S('text', { y: 4.5, 'text-anchor': 'middle', 'font-family': 'Fredoka, sans-serif', 'font-weight': 700, 'font-size': 12, fill: '#4a1a73' }, tierG);
      const pg = S('g', { transform: 'translate(' + r2(W / 2 - 177) + ' ' + (H - 20) + ')' }, hud); S('path', { d: 'M40 0H314', stroke: '#ffffff', 'stroke-width': 7, 'stroke-linecap': 'round', opacity: 0.85 }, pg); const pgF = S('path', { d: 'M40 0H40', stroke: '#ff8fc8', 'stroke-width': 7, 'stroke-linecap': 'round' }, pg);
      S('path', { d: 'M24 6V-12M24 -12H36L32 -7L36 -2H24', stroke: '#4a1a73', 'stroke-width': 2, fill: '#ffd84a', 'stroke-linejoin': 'round' }, pg); S('ellipse', { cx: 330, cy: 1, rx: 13, ry: 6, fill: '#5cc2ff', stroke: '#ffffff', 'stroke-width': 2 }, pg);
      S('path', { d: 'M324 -1q3 -9 6 0M330 -1q3 -12 6 0', stroke: '#ffffff', 'stroke-width': 2, fill: 'none', 'stroke-linecap': 'round' }, pg); const pgD = S('circle', { r: 7, fill: '#ffffff', stroke: '#4a1a73', 'stroke-width': 2.4 }, pg);
      // speed: lines streaming past (more, longer, brighter the faster you go) + wind dashes round you
      const lines = []; for (let i = 0; i < 18; i++) lines.push({ e: S('path', { stroke: '#ffffff', 'stroke-width': i % 3 ? 2.2 : 3.2, 'stroke-linecap': 'round', opacity: 0 }, speedL), x: Math.random() * W, y: Math.random() * H, n: 0.6 + Math.random() * 0.8, near: i < 6 });
      const flash = S('rect', { x: -10, y: -10, width: W + 20, height: H + 20, fill: '#ffffff', opacity: 0, 'pointer-events': 'none' }, fg);
      // ---------- the wind / sliding sound: rises in pitch + volume with your speed ----------
      let AU = null;
      function windOn() { try { if (localStorage.getItem('yardgames.v1.mute') === '1') return; } catch (e) {} if (AU) return;
        try { const AC = window.AudioContext || window.webkitAudioContext, c = new AC(), n = c.sampleRate * 2, b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
          const src = c.createBufferSource(); src.buffer = b; src.loop = true; const f = c.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 0.9; const g = c.createGain(); g.gain.value = 0; src.connect(f); f.connect(g); g.connect(c.destination); src.start(); AU = { c, f, g, src }; } catch (e) { AU = null; } }
      function windSet(v, on) { if (!AU) return; const t = AU.c.currentTime; AU.f.frequency.setTargetAtTime(260 + v * 13, t, 0.12); AU.g.gain.setTargetAtTime(on ? cl((v - 15) / 110, 0.02, 0.2) : 0, t, on ? 0.15 : 0.35); }
      function windOff() { if (!AU) return; const a = AU; AU = null; try { a.g.gain.setTargetAtTime(0, a.c.currentTime, 0.1); setTimeout(() => { try { a.src.stop(); a.c.close(); } catch (e) {} }, 500); } catch (e) {} }
      // ---------- your creature ----------
      const me = ctx.creature(ctx.playerKey, { yaw: 58 }); me.depth(0);   // depth 0: stays under the fg layer (the chute's near wall, the pool's front + its water hide your bottom)
      const C0 = [186, 142], C1 = [150, 128], Z0 = 1.08; let tNow = 0, friends = null, pool = null;
      const st = { off: 0, phase: 'ready', s: ST0, l: 0, tgt: 0, h: SH, ha: 0, vh: 0, v: 0, top: 0, z: Z0, lc: 0, sc: ST0, cx: C0[0], cy: C0[1], stun: 0, boostT: 0, punch: 0, mud: 0, key: 0, t0: 0, yaw: 58, boosts: 0, bonks: 0, shake: 0, toldPool: 0, lipV: 0, k: 0, trail: 0, bot: 0, botT: 0, sparkT: 0 };
      const scr = (s, l, h) => { const p = Wp(s, l, h); return [st.tx + st.z * p[0], st.ty + st.z * p[1]]; };
      function reset() { Object.assign(st, { phase: 'ready', s: ST0, l: 0, tgt: 0, h: SH, ha: 0, vh: 0, v: 0, top: 0, lc: 0, sc: ST0, stun: 0, boostT: 0, punch: 0, mud: 0, boosts: 0, bonks: 0, shake: 0, toldPool: 0, k: 0 });
        alive.forEach(despawn); alive = []; items = gen(1234 + Math.floor(Math.random() * 9000)); nextI = 0; for (const i of [...chunks.keys()]) dropChunk(i); buildStatic(); me.hide(false); me.play('idle'); }
      // ---------- input: drag (up / right = far side, down / left = near side) ----------
      let drag = null; const api = {
        option(id) { look = id; for (const i of [...chunks.keys()]) dropChunk(i); buildStatic(); },
        start() { look = ctx.G._opt || look; reset(); st.phase = 'ride'; st.t0 = tNow; ctx.hint(''); SFX.whoosh(); windOn(); setTimeout(() => st.phase === 'ride' && ctx.toast('Drag up / down to switch sides', W / 2, H - 70, '#ffffff'), 900); },
        down(p) { drag = { x: p.x, y: p.y, l: st.tgt }; }, move(p) { if (!drag) return; st.tgt = cl(drag.l + ((p.x - drag.x) - (p.y - drag.y)) * 0.011, -LMAX, LMAX); }, up() { drag = null; },
        key(k, dn) { const d = (k === 'ArrowUp' || k === 'ArrowRight' || k === 'w' || k === 'd') ? 1 : (k === 'ArrowDown' || k === 'ArrowLeft' || k === 's' || k === 'a') ? -1 : 0; if (!d) return; st.key = dn ? d : (st.key === d ? 0 : st.key); return true; },
        _state: () => ({ phase: st.phase, s: Math.round(st.s), l: +st.l.toFixed(2), v: +st.v.toFixed(1), h: Math.round(st.h), top: Math.round(st.top), boosts: st.boosts, bonks: st.bonks, t: +((tNow - st.t0) / 1000).toFixed(1), k: +st.k.toFixed(2), lip: Math.round(st.lipV), z: +st.z.toFixed(2) }),
        _bot(k) { st.bot = k; }, _setV(v) { st.v = v; st.top = Math.max(st.top, v); }, _items: () => items.map(q => [q.t, Math.round(q.s), +q.l.toFixed(2)]), _look: () => look,
        _ff(sec) { const n = Math.round(sec * 60), tr = tNow - st.off; for (let i = 0; i < n; i++) { st.off += 1000 / 60; api.update(1 / 60, tr); } return api._state(); },
        celebrate(s) { me.play(s >= 2 ? 'happy' : 'idle'); if (friends) friends.forEach(f => f.c.play(s >= 2 ? 'happy' : 'idle')); },
        destroy() { windOff(); },
        update(dt, t) { t += st.off; tNow = t; const L = LOOK[look]; let E = { sit: 1, armL: 64, armR: 64, lean: -0.3, smile: 0.7 };
          if (st.phase === 'ride' || st.phase === 'ramp') {
            if (st.bot) botSteer(t); if (st.key) st.tgt = cl(st.tgt + st.key * 2.4 * dt, -LMAX, LMAX);
            const ls = (st.stun > 0 ? 1.3 : 3.2) * L.steer, dl = cl(st.tgt - st.l, -ls * dt, ls * dt); st.l += dl; st.steer = lerp(st.steer || 0, dl / Math.max(dt, 1e-3) / ls, 1 - Math.exp(-dt * 8));
            // speed: scoot to the edge of the deck, then gravity takes you to VB + 8 at least; extra speed bleeds off slowly; mud drags
            if (st.s < SD0) st.v = Math.min(14, st.v + 30 * dt); else if (st.v < VB + 8 && st.s < 700) st.v = Math.min(VB + 8, st.v + 34 * dt); else if (st.v < VB) st.v = Math.min(VB, st.v + 14 * dt); else st.v = Math.max(VB, st.v - DEC * dt);
            if (st.mud > 0) { st.v = Math.max(VB * 0.8, st.v - 24 * dt); st.mud -= dt; } st.v = Math.min(VMAX, st.v); st.top = Math.max(st.top, st.v);
            st.s += st.v * KV * dt; st.stun = Math.max(0, st.stun - dt); st.boostT = Math.max(0, st.boostT - dt); st.punch = Math.max(0, st.punch - dt * 2.5);
            // hops off the wooden bumps (ha = height over the chute)
            if (st.phase === 'ride' && (st.ha > 0 || st.vh > 0)) { st.vh -= GA * dt; st.ha += st.vh * dt; if (st.ha <= 0) { st.ha = 0; st.vh = 0; st.v += 2; ctx.burst(...scr(st.s, st.l, HS(st.s)), 'drop', 6, { col: '#ffffff', v: 70 }); SFX.tap(); } }
            if (st.s >= RS && st.phase === 'ride') { st.phase = 'ramp'; st.ha = 0; st.vh = 0; }
            st.h = HS(st.s) + st.ha;
            if (!st.toldPool && st.s > RS - 1500) { st.toldPool = 1; ctx.toast('Almost there! Go go go!', W / 2, 84, '#ffe36e'); }
            hits();
            if (st.s >= LEN) launch(); }
          if (st.phase === 'fly') { st.s += st.vs * dt; st.vh -= GF * dt; st.h += st.vh * dt; const p = scr(st.s, st.l, st.h); if ((p[1] < -90 || t - st.tf > 1300) && !st.tr) transition(); }
          // pose: the faster you go, the further you lean back, arms swept back, eyes squinting into the wind
          const fast = cl((st.v - 55) / 50, 0, 1);
          if (st.phase === 'ready') E = { sit: 1, armL: 50 + 20 * Math.sin(t / 260), armR: 50 + 20 * Math.sin(t / 260 + 1.4), lean: -0.2, smile: 0.8, sq: 0.03 * Math.sin(t / 180) };
          else if (st.phase === 'ride' || st.phase === 'ramp') {
            const sw = st.steer || 0; E = { sit: 1, armL: 60 + sw * 25 + fast * 70, armR: 60 - sw * 25 + fast * 70, lean: -0.35 - (st.v - VB) / 120, smile: 0.7, open: 0.25 + fast * 0.5, close: fast * 0.35, tilt: -sw * 9 + Math.sin(t / 37) * fast * 2.5, ly: -0.3, lx: 0.6 };
            if (st.s < SD0) Object.assign(E, { armL: 20 + 22 * Math.sin(t / 90), armR: 20 - 22 * Math.sin(t / 90), lean: 0.3, smile: 0.9, sq: 0.04 * Math.sin(t / 90) });
            if (st.boostT > 0 || st.ha > 4) Object.assign(E, { armL: 158, armR: 152, hap: 1, open: 0.85, smile: 1, close: 0 });
            if (st.stun > 0) { const u = st.stun / 0.6; Object.assign(E, { tilt: Math.sin(t / 40) * 12 * u, sq: 0.1 * u, armL: 110, armR: 40, open: 0.5, hap: 0, smile: 0, close: 0 }); }
            if (st.mud > 0) Object.assign(E, { armL: 30, armR: 30, smile: 0, open: 0.2 }); }
          else if (st.phase === 'fly') E = st.lipV >= 75 ? { sit: 1, armL: 12, armR: 12, open: 0.6, hap: 1, smile: 1, sq: 0.08, close: 0.4 } : { sit: 0.6, armL: 165, armR: 165, open: 0.9, hap: 1, smile: 1, lean: -0.5, footL: 2, footR: 2 };
          if (st.phase === 'pool') { pool.update(dt, t); return; }
          me.pose(E); st.yaw = lerp(st.yaw, 58 + (st.phase === 'ride' ? cl(st.steer || 0, -1, 1) * 16 : 0), 1 - Math.exp(-dt * 6)); me.yaw(st.yaw);
          camera(dt, t); place(t, dt); hud_(dt, t); windSet(st.v, st.phase === 'ride' || st.phase === 'ramp');
        } };
      function botSteer(t) { if (t - st.botT < 120 - st.bot * 60) return; st.botT = t; const sk = st.bot, ahead = 200 + sk * 260; let best = st.tgt, bs = -1e9;
        for (let c = -LMAX; c <= LMAX + 1e-6; c += 0.11) { let sc = -Math.abs(c - st.l) * 0.6;
          for (const q of alive) { const ds = q.s - st.s; if (ds < -10 || ds > ahead || q.hit) continue; const near = Math.abs(c - q.l) < q.hw + RW + 0.03, w = 1 - ds / ahead * 0.5;
            if (near) sc += (q.k === 'hard' ? -10 : q.k === 'soft' ? -6 : q.k === 'mud' ? -7 : q.k === 'gold' ? 9 : q.k === 'boost' ? 7 : 0) * w; }
          if (sc > bs) { bs = sc; best = c; } }
        st.tgt = Math.random() < sk ? best : cl(st.tgt + (Math.random() - 0.5) * 0.5, -LMAX, LMAX); }
      function hits() { const L = LOOK[look];
        for (const q of alive) { if (q.hit || Math.abs(q.s - st.s) > q.hs + 10 || Math.abs(q.l - st.l) > q.hw + RW) continue; if (st.ha > q.hh - 2 && q.k !== 'ramp') continue;
          const p = scr(st.s, st.l, st.h);
          if (q.k === 'ramp') { if (st.ha < 8) { q.hit = 1; st.vh = 370; st.ha = Math.max(st.ha, 1); SFX.boing(); ctx.toast('Hop!', p[0], p[1] - 70, '#ffffff'); } continue; }
          q.hit = 1;
          if (q.k === 'boost' || q.k === 'gold') { const dv = (q.k === 'gold' ? 13 : 8) * L.boost * (1 - st.v / 160); st.v += dv; st.boostT = 0.7; st.punch = 1; st.boosts++; SFX.whoosh(); if (q.k === 'gold') SFX.pop();
            ctx.toast((q.k === 'gold' ? 'Turbo! +' : 'Splash! +') + Math.round(dv), p[0] + 20, p[1] - 80, q.k === 'gold' ? '#ffe36e' : '#bfe8ff'); ctx.burst(p[0], p[1] - 10, q.k === 'gold' ? 'star' : 'drop', 14, { v: 160, spread: 2.4 }); if (q.el) q.el.style.opacity = 0.45; continue; }
          if (q.k === 'mud') { st.mud = 0.55; st.bonks++; SFX.thud(); ctx.toast('Mud!', p[0] + 20, p[1] - 80, '#e2b98a'); ctx.burst(p[0], p[1] - 6, 'dust', 10, { col: '#8a5a34', v: 90 }); continue; }
          const hard = q.k === 'hard', dv = (hard ? 9 + 0.25 * (st.v - VB) : 5 + 0.12 * (st.v - VB)) * L.hit; st.v = Math.max(VB * (hard ? 0.7 : 0.85), st.v - dv); st.stun = hard ? 0.6 : 0.35; st.bonks++; st.shake = hard ? 7 : 3.5; st.l = cl(st.l + (st.l > q.l ? 0.12 : -0.12), -LMAX, LMAX);
          if (hard) { SFX.thud(); me.play('surprised'); setTimeout(() => st.phase === 'ride' && me.play('idle'), 650); } else SFX.pop();
          ctx.toast((hard ? 'Bonk! -' : 'Oof! -') + Math.round(dv), p[0] + 20, p[1] - 80, '#ffb0a0'); ctx.burst(p[0], p[1] - 30, hard ? 'star' : 'dust', hard ? 8 : 9, { v: 110, col: q.t === 'sand' ? '#f1d48a' : q.t === 'leaves' ? '#ff9a3a' : q.t === 'hay' ? '#f2cf6a' : undefined });
          if (q.el && q.t !== 'rock' && q.t !== 'log') q.el.classList.add('ygs-hit'); } }
      // ---------- the end: off the lip, up and out of sight -> the kiddie pool scene ----------
      function launch() { st.phase = 'fly'; st.lipV = st.v; st.tf = tNow; const vs = st.v * KV; st.vs = vs * 0.45; st.vh = 360 + 0.35 * vs; st.h = HS(LEN);
        SFX.boing(); SFX.whoosh(); const p = scr(st.s, st.l, st.h); ctx.burst(p[0], p[1], 'drop', 16, { v: 170 }); const tr = tierOf(st.v); ctx.toast(Math.round(st.v) + ' km/h!', W / 2, 96, tr[2], true);
        if (st.v >= 75) setTimeout(() => st.phase === 'fly' && ctx.toast('Cannonball!', W / 2, 150, '#ffffff'), 250);
        friends = ctx.opponent(3).map((key, i) => { const c = ctx.creature(key, { yaw: i === 1 ? -20 : i === 2 ? 20 : 0 }); c.hide(true); return { c, key }; });   // made now, while you fly: no hitch at the cut
        windSet(st.v, false); }
      function transition() { st.tr = 1; const t0 = performance.now(); SFX.whoosh();
        const fade = () => { const u = (performance.now() - t0) / 160; flash.setAttribute('opacity', r2(Math.min(1, u))); if (u < 1) return requestAnimationFrame(fade);
          // swap scenes under the white
          [slideBg, wB, wF, speedL].forEach(e => e.style.display = 'none'); pg.style.display = 'none'; sp.style.display = 'none'; stands.length = 0; scB.style.display = ''; scF.style.display = '';
          pool = poolScene(); st.phase = 'pool'; windOff();
          const t1 = performance.now(), out = () => { const v = 1 - (performance.now() - t1) / 320; flash.setAttribute('opacity', r2(Math.max(0, v))); if (v > 0) requestAnimationFrame(out); }; requestAnimationFrame(out); };
        requestAnimationFrame(fade); }
      // ---------- the kiddie pool, side on: the backyard's blue + white three-ring pool, three friends, your creature dropping in from the sky ----------
      function poolScene() { const k = st.k = cl((st.lipV - 25) / 85, 0, 1.15), v = st.lipV, tr = tierOf(v), pts = Math.round(v) * 10;
        const PX = 390, PY = 244, RX = 186, RY = 44, TB = 19, IR = 24, WY = PY + 9, LX = 370;   // pool centre / rim top / radii / tube height / crown width / water line / where you land
        const ell = (cx, cy, rx, ry, a) => '<ellipse cx="' + r2(cx) + '" cy="' + r2(cy) + '" rx="' + r2(rx) + '" ry="' + r2(ry) + '" ' + a + '/>';
        let b = '<defs><linearGradient id="ygpSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6fc0ff"/><stop offset="0.7" stop-color="#c4e8ff"/><stop offset="1" stop-color="#e6f6ff"/></linearGradient>'
          + '<linearGradient id="ygpGr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9fdc6e"/><stop offset="1" stop-color="#5aaa48"/></linearGradient><linearGradient id="ygpW" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a6ecff"/><stop offset="1" stop-color="#3ea8ea"/></linearGradient>'
          + '<linearGradient id="ygpBl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6cbcff"/><stop offset="0.45" stop-color="#2a86e6"/><stop offset="1" stop-color="#1a5fb0"/></linearGradient><linearGradient id="ygpWt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="0.5" stop-color="#f2f6fb"/><stop offset="1" stop-color="#c9d6e6"/></linearGradient>'
          + '<radialGradient id="ygpSun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fffbe0"/><stop offset="0.5" stop-color="#ffe680" stop-opacity="0.7"/><stop offset="1" stop-color="#ffe680" stop-opacity="0"/></radialGradient></defs>';
        b += '<rect x="-20" y="-20" width="' + (W + 40) + '" height="260" fill="url(#ygpSky)"/><circle cx="676" cy="56" r="70" fill="url(#ygpSun)"/><circle cx="676" cy="56" r="24" fill="#fff3a0"/>';
        [[110, 58, 0.9], [300, 38, 0.65], [520, 74, 0.75], [760, 30, 0.55]].forEach(([x, y, s]) => { b += '<g transform="translate(' + x + ' ' + y + ') scale(' + s + ')" fill="#ffffff" opacity="0.95"><circle cx="-26" cy="4" r="18"/><circle cx="0" cy="-8" r="25"/><circle cx="27" cy="2" r="19"/><circle cx="10" cy="10" r="18"/><circle cx="-12" cy="11" r="16"/></g>'; });
        // trees behind the fence, the white picket fence, the lawn
        [[30, 1.1], [130, 0.85], [250, 1.0], [540, 0.9], [650, 1.15], [760, 0.9]].forEach(([x, s]) => { b += '<g transform="translate(' + x + ' 196) scale(' + s + ')"><rect x="-6" y="-60" width="12" height="62" rx="3" fill="#8a5a34"/><circle cx="-22" cy="-70" r="28" fill="#57a854"/><circle cx="20" cy="-74" r="30" fill="#57a854"/><circle cx="0" cy="-98" r="32" fill="#6cbb5c"/><circle cx="-10" cy="-106" r="13" fill="#8fd47a" opacity="0.85"/></g>'; });
        b += '<rect x="-20" y="166" width="' + (W + 40) + '" height="6" fill="#f3e8da"/><rect x="-20" y="188" width="' + (W + 40) + '" height="6" fill="#f3e8da"/>'; for (let x = -10; x < W + 20; x += 20) b += '<path d="M' + x + ' 210V164L' + (x + 7) + ' 156L' + (x + 14) + ' 164V210Z" fill="#fffaf2" stroke="#e2cfb8" stroke-width="1"/>';
        b += '<rect x="-20" y="206" width="' + (W + 40) + '" height="' + (H - 186) + '" fill="url(#ygpGr)"/>'; for (let i = 0; i < 9; i++) b += '<path d="M' + (i * 100 - 60) + ' ' + (H + 10) + 'L' + (i * 100 + 10) + ' 206H' + (i * 100 + 50) + 'L' + (i * 100 - 10) + ' ' + (H + 10) + 'Z" fill="#ffffff" opacity="0.05"/>';
        const R = rnd(42); for (let i = 0; i < 70; i++) { const x = R() * W, y = 212 + R() * (H - 212), q = 0.7 + (y - 206) / 150; b += '<path d="M' + r2(x - 3 * q) + ' ' + r2(y) + 'l' + r2(2 * q) + ' ' + r2(-7 * q) + 'l' + r2(2 * q) + ' ' + r2(5 * q) + 'l' + r2(2 * q) + ' ' + r2(-8 * q) + 'l' + r2(2 * q) + ' ' + r2(8 * q) + 'Z" fill="#4f9a3e" opacity="0.55"/>'; }
        [[60, 214], [200, 212], [470, 213], [600, 214], [720, 212]].forEach(([x, y], i) => { for (let j = 0; j < 6; j++) { const fx = x + j * 9 - 22, fy = y - 6 - (j % 2) * 5; b += '<path d="M' + fx + ' ' + (y + 2) + 'V' + fy + '" stroke="#4f9a3e" stroke-width="1.6"/><circle cx="' + fx + '" cy="' + fy + '" r="3.2" fill="' + ['#ff8fc8', '#fff3a8', '#ffffff', '#d9c8ff', '#ffb0a0'][(i + j) % 5] + '"/>'; } });
        // props: a striped towel, flip-flops, the garden hose snaking to the pool, a sun lounger
        b += '<g transform="translate(250 350) rotate(-4)"><rect x="-46" y="-12" width="92" height="26" rx="4" fill="#ffffff"/><path d="M-46 -6H46M-46 4H46" stroke="#ff7a8a" stroke-width="5"/></g><g fill="#ffd84a" stroke="#d09a20" stroke-width="1.2"><ellipse cx="36" cy="350" rx="9" ry="4.5"/><ellipse cx="56" cy="353" rx="9" ry="4.5"/></g>';
        b += '<path d="M-10 300C40 312 70 290 110 296S196 262 212 240" fill="none" stroke="#3a9a4a" stroke-width="6" stroke-linecap="round"/><path d="M-10 300C40 312 70 290 110 296S196 262 212 240" fill="none" stroke="#6fcf6a" stroke-width="2" stroke-linecap="round" opacity="0.7"/>';
        b += '<g transform="translate(742 302)"><path d="M-44 0V-10M44 0V-10M-44 -10H18L40 -38" stroke="#e8e0d4" stroke-width="3.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M-42 -14H18L38 -40" stroke="#5cb8ff" stroke-width="9" fill="none" stroke-linecap="round" stroke-linejoin="round"/></g>';
        // the pool, back: its shadow, the crown ring all round, the dark inner wall, the water (caustics, prints), the duck + the beach ball afloat
        b += ell(PX + 6, PY + 3 * TB + 6, RX + 18, RY * 0.7, 'fill="#2a4a20" opacity="0.22"');
        b += '<path d="M' + (PX - RX) + ' ' + PY + 'A' + RX + ' ' + RY + ' 0 1 1 ' + (PX + RX) + ' ' + PY + 'A' + RX + ' ' + RY + ' 0 1 1 ' + (PX - RX) + ' ' + PY + 'Z" fill="#3f9af0"/>' + ell(PX, PY - 3, RX - 9, RY - 4, 'fill="none" stroke="#9ad6ff" stroke-width="3" opacity="0.6"');
        b += ell(PX, PY + 2, RX - IR, RY - 7, 'fill="#1b5fae"');
        const water = S('g', {}); water.innerHTML = ell(PX, WY, RX - IR - 3, RY - 13, 'fill="url(#ygpW)"') + [[-70, -4], [40, 6], [-10, -8], [80, -2], [-40, 8]].map(([x, y], i) => '<path d="M' + (PX + x - 16) + ' ' + (WY + y) + 'q8 -4 16 0t16 0" stroke="#ffffff" stroke-width="2" fill="none" opacity="0.6" stroke-linecap="round" class="ygs-bob" style="animation-delay:' + (i * 0.3) + 's"/>').join('')
          + '<g opacity="0.35" transform="translate(' + (PX + 60) + ' ' + (WY + 4) + ')"><path d="M-4.2 0Q-1 -3 3 0Q-1 3 -4.2 0Z" fill="#ff8a3a" transform="scale(1.6)"/></g><g opacity="0.35" transform="translate(' + (PX - 90) + ' ' + (WY + 2) + ') scale(1.5)"><path d="M0 -3.6L1 -1.2L3.5 -1.1L1.5 0.6L2.2 3.1L0 1.7L-2.2 3.1L-1.5 0.6L-3.5 -1.1L-1 -1.2Z" fill="#ffd23a"/></g>';
        const duck = '<g class="ygs-bob"><ellipse cx="0" cy="2" rx="13" ry="4" fill="#1a5fb0" opacity="0.25"/><path d="M-12 -2Q-12 -12 0 -12Q8 -12 10 -6Q12 -2 6 0H-8Q-12 0 -12 -2Z" fill="#ffd84a" stroke="#d09a20" stroke-width="1.2"/><circle cx="4" cy="-17" r="7" fill="#ffd84a" stroke="#d09a20" stroke-width="1.2"/><path d="M10 -17l6 1l-6 3Z" fill="#ff8a3a"/><circle cx="6" cy="-19" r="1.3" fill="#2a1a10"/><path d="M-8 -6q5 -3 9 0" stroke="#e8b82a" stroke-width="1.5" fill="none"/></g>';
        const ballS = '<g class="ygs-bob" style="animation-delay:.6s"><circle cy="-10" r="11" fill="#ffffff" stroke="#c8c0b4" stroke-width="1.2"/><path d="M0 -21A11 11 0 0 1 11 -10L0 -10Z" fill="#ff7a8a"/><path d="M0 1A11 11 0 0 1 -11 -10L0 -10Z" fill="#5cb8ff"/><path d="M-11 -10A11 11 0 0 1 0 -21L0 -10Z" fill="#ffd84a"/></g>';
        const duckG = S('g', { transform: 'translate(' + (PX - 112) + ' ' + (WY + 2) + ')' }), ballG = S('g', { transform: 'translate(' + (PX + 122) + ' ' + (WY + 2) + ')' }); duckG.innerHTML = duck; ballG.innerHTML = ballS;
        scB.innerHTML = b; scB.appendChild(water);
        // front (over anyone in the pool): the splash, the crown's front half, the three tubes (blue / white with fish + starfish / blue), spills, puddles
        // the water in front of you + the friend in the pool: the same water, clipped below the waterline, so only your upper body shows above it
        const YW = WY + 2, splG = S('g', {}, scF), wc = S('clipPath', { id: 'ygpWc' }, scF); S('rect', { x: -20, y: YW, width: W + 40, height: H }, wc);
        const waterF = water.cloneNode(true); waterF.setAttribute('clip-path', 'url(#ygpWc)'); scF.appendChild(waterF);
        const ringG = S('g', {}, scF), rings = [LX, 506].map(x => S('ellipse', { cx: x, cy: YW + 1, rx: 32, ry: 6.5, fill: 'none', stroke: '#ffffff', 'stroke-width': 2.4, opacity: 0, class: 'ygs-bob' }, ringG));
        scF.appendChild(duckG); scF.appendChild(ballG);
        const front = S('g', {}, scF), spillG = S('g', {}, scF); let f = '';
        f += '<path d="M' + (PX - RX) + ' ' + PY + 'A' + RX + ' ' + RY + ' 0 0 0 ' + (PX + RX) + ' ' + PY + 'L' + (PX + RX - IR) + ' ' + (PY + 2) + 'A' + (RX - IR) + ' ' + (RY - 7) + ' 0 0 1 ' + (PX - RX + IR) + ' ' + (PY + 2) + 'Z" fill="#3f9af0"/>';
        f += '<path d="M' + (PX - RX + 8) + ' ' + (PY + 6) + 'A' + (RX - 8) + ' ' + (RY - 2) + ' 0 0 0 ' + (PX + RX - 8) + ' ' + (PY + 6) + '" fill="none" stroke="#9ad6ff" stroke-width="3" opacity="0.7"/>';
        [['url(#ygpBl)', 0], ['url(#ygpWt)', 1], ['url(#ygpBl)', 2]].forEach(([c, j]) => { const yt = PY + 4 + j * TB, yb = yt + TB;
          f += '<path d="M' + (PX - RX) + ' ' + yt + 'A' + RX + ' ' + RY + ' 0 0 0 ' + (PX + RX) + ' ' + yt + 'L' + (PX + RX) + ' ' + yb + 'A' + RX + ' ' + RY + ' 0 0 1 ' + (PX - RX) + ' ' + yb + 'Z" fill="' + c + '" stroke="' + (j === 1 ? '#c9d6e6' : '#1a5fb0') + '" stroke-width="1"/>'
            + '<circle cx="' + (PX - RX) + '" cy="' + (yt + TB / 2) + '" r="' + (TB / 2) + '" fill="' + c + '"/><circle cx="' + (PX + RX) + '" cy="' + (yt + TB / 2) + '" r="' + (TB / 2) + '" fill="' + c + '"/>'
            + '<path d="M' + (PX - RX + 12) + ' ' + (yt + 5) + 'A' + (RX - 12) + ' ' + RY + ' 0 0 0 ' + (PX + RX - 12) + ' ' + (yt + 5) + '" fill="none" stroke="#ffffff" stroke-width="2.6" opacity="' + (j === 1 ? 0.9 : 0.45) + '"/>'; });
        // fish + starfish printed round the white tube
        [-0.75, -0.42, -0.1, 0.22, 0.55, 0.85].forEach((u, i) => { const x = PX + u * RX * 0.92, y = PY + 4 + TB * 1.5 + RY * Math.sqrt(1 - u * u * 0.85) * 0.98, sc = 1.25 * Math.sqrt(1 - u * u * 0.7);
          f += '<g transform="translate(' + r2(x) + ' ' + r2(y) + ') scale(' + r2(sc) + ')">' + (i % 2 ? '<path d="M0 -3.6L1 -1.2L3.5 -1.1L1.5 0.6L2.2 3.1L0 1.7L-2.2 3.1L-1.5 0.6L-3.5 -1.1L-1 -1.2Z" fill="#ffd23a" stroke="#e8a81a" stroke-width="0.3"/>' : '<path d="M-4.2 0Q-1 -3 3 0Q-1 3 -4.2 0Z" fill="#ff8a3a"/><path d="M2.6 0L5.6 -2.2V2.2Z" fill="#ff8a3a"/><circle cx="-2.2" cy="-0.5" r="0.45" fill="#1d2a3a"/>') + '</g>'; });
        f += '<circle cx="' + (PX + RX * 0.7) + '" cy="' + (PY + 4 + TB * 0.5 + RY * 0.7) + '" r="2.6" fill="#f6f9fc" stroke="#9aa1ad" stroke-width="0.8"/>';
        front.innerHTML = f;
        // people: three friends (left + right on the grass, one sitting in the pool), you up in the sky
        const spots = [{ x: 136, y: 342, side: -1, in: 0 }, { x: 650, y: 342, side: 1, in: 0 }, { x: 506, y: WY + 36, side: 1, in: 1 }];
        friends.forEach((fr, i) => Object.assign(fr, spots[i], { size: 128, wet: 0, hitAt: Infinity, knock: 0, rot: 0, dx: 0, dy: 0, dripT: 0 }));
        friends.forEach(fr => { fr.c.hide(false); fr.c.yaw(fr.in ? 0 : fr.side < 0 ? 22 : -22); fr.c.set(fr.x, fr.y, fr.size); fr.c.depth(0); fr.c.play('idle'); });
        me.yaw(0); me.rot(0); me.depth(0); me.hide(false); me.play('idle');
        rings[1].setAttribute('opacity', 0.85);
        const T0p = tNow, fallAt = T0p + 380, hitAt = fallAt + 560, fx = { ring: [], drop: [], sheets: [], spills: [] };
        let hit = false;
        // the splash pieces (scaled up with k), built now, shown at the hit
        const col = S('path', { d: 'M-' + r2(16 + 14 * k) + ' 0C-' + r2(18 + 16 * k) + ' -55 -9 -96 0 -100C9 -96 ' + r2(18 + 16 * k) + ' -55 ' + r2(16 + 14 * k) + ' 0Z', fill: '#ffffff', opacity: 0, transform: 'translate(' + LX + ' ' + WY + ')' }, splG);
        const jets = []; const nj = 2 + Math.round(6 * k); for (let j = 0; j < nj; j++) { const a = (j / (nj - 1 || 1) - 0.5) * 2, w = 5 + 5 * k, lx = a * (50 + 120 * k), hj = (40 + 190 * k) * (0.6 + 0.4 * Math.abs(Math.sin(j * 1.9 + 0.5))) / 100;
          jets.push({ e: S('path', { d: 'M' + r2(-w) + ' 0C' + r2(-w) + ' -55 ' + r2(lx - 5) + ' -94 ' + r2(lx) + ' -100C' + r2(lx + 5) + ' -94 ' + r2(w) + ' -55 ' + r2(w) + ' 0Z', fill: '#e6f8ff', stroke: '#a8e0ff', 'stroke-width': 1.2, opacity: 0, transform: 'translate(' + LX + ' ' + WY + ')' }, splG), hj, dl: 0.03 + Math.abs(a) * 0.07 }); }
        const crown = S('g', { opacity: 0, transform: 'translate(' + LX + ' ' + WY + ')' }, splG); { let cd = ''; const n = Math.round(12 + 10 * k), cr = 26 + 34 * k; for (let i = 0; i < n; i++) { const a = i / n * TAU, x = Math.cos(a) * cr, y = Math.sin(a) * cr * 0.22, hh = (24 + 80 * k) * (0.6 + 0.4 * Math.sin(i * 2.3 + 1)), lean = Math.cos(a) * (10 + 30 * k);
          if (Math.sin(a) < -0.3) continue; cd += 'M' + r2(x - 6) + ' ' + r2(y) + 'Q' + r2(x + lean * 0.4) + ' ' + r2(y - hh * 0.6) + ' ' + r2(x + lean) + ' ' + r2(y - hh) + 'Q' + r2(x + lean * 0.5 + 3) + ' ' + r2(y - hh * 0.5) + ' ' + r2(x + 6) + ' ' + r2(y) + 'Z'; } S('path', { d: cd, fill: '#e6f8ff', stroke: '#8fd6ff', 'stroke-width': 1.5, 'stroke-linejoin': 'round' }, crown); }
        for (let i = 0; i < 4; i++) fx.ring.push(S('ellipse', { cx: LX, cy: WY, rx: 1, ry: 1, fill: 'none', stroke: '#ffffff', 'stroke-width': 3 - i * 0.5, opacity: 0 }, splG));
        // water sheets thrown at the friends on the grass (k >= 0.3), spills over the front + puddles (k >= 0.5)
        friends.filter(fr => !fr.in).forEach(fr => { if (k < 0.3) return; const e0 = S('path', { fill: 'none', stroke: '#ffffff', 'stroke-width': r2(10 + 16 * k), 'stroke-linecap': 'round', opacity: 0, 'stroke-dasharray': '1 999' }, splG), e = S('path', { fill: 'none', stroke: '#8fd8ff', 'stroke-width': r2(6 + 12 * k), 'stroke-linecap': 'round', opacity: 0, 'stroke-dasharray': '1 999' }, splG);
          const x1 = fr.x + fr.side * 10, y1 = fr.y - 50, mx = (LX + x1) / 2, my = Math.min(WY, y1) - 60 - 80 * k; const dd = 'M' + LX + ' ' + WY + 'Q' + r2(mx) + ' ' + r2(my) + ' ' + r2(x1) + ' ' + r2(y1); e.setAttribute('d', dd); e0.setAttribute('d', dd); const len = e.getTotalLength ? e.getTotalLength() : 400; fx.sheets.push({ e, len, fr }, { e: e0, len, fr }); });
        if (k >= 0.5) [-0.62, -0.2, 0.3, 0.7].slice(0, k > 0.85 ? 4 : 2).forEach((u, i) => { const x = PX + u * RX, y0 = PY + 4 + RY * Math.sqrt(1 - u * u) * 0.95; const e = S('path', { d: 'M' + r2(x - 9) + ' ' + r2(y0) + 'Q' + r2(x - 12) + ' ' + r2(y0 + 26) + ' ' + r2(x - 7) + ' ' + r2(y0 + 46) + 'H' + r2(x + 7) + 'Q' + r2(x + 12) + ' ' + r2(y0 + 26) + ' ' + r2(x + 9) + ' ' + r2(y0) + 'Z', fill: '#9fe0ff', stroke: '#ffffff', 'stroke-width': 1.4, opacity: 0, transform: 'scale(1 0.01)', 'transform-origin': r2(x) + 'px ' + r2(y0) + 'px' }, spillG);
          const pd = S('ellipse', { cx: r2(x), cy: r2(y0 + 50), rx: 1, ry: 1, fill: '#8fd6ff', opacity: 0.7 }, spillG); fx.spills.push({ e, pd, dl: 0.12 + i * 0.07 }); });
        friends.forEach(fr => { fr.pud = S('ellipse', { cx: fr.x, cy: fr.in ? -99 : fr.y + 2, rx: 1, ry: 1, fill: '#8fd6ff', opacity: 0.75 }); scB.insertBefore(fr.pud, water); fr.slap = S('path', { d: 'M-30 10C-40 -30 -20 -70 0 -76C20 -70 40 -30 30 10C14 -2 -14 -2 -30 10Z', fill: '#bfeaff', stroke: '#ffffff', 'stroke-width': 2, opacity: 0, transform: 'translate(' + fr.x + ' ' + (fr.y - 40) + ')' }, scF); });
        const shakeG = [scB, scF];
        return { update(dt, t) {
          const ts = (t - T0p) / 1000;
          // you: fall from the sky (spinning if it was a cannonball), vanish under, pop up and wave
          if (!hit) { const u = cl((t - fallAt) / (hitAt - fallAt), 0, 1), y = lerp(-100, WY + 48, u * u);
            me.set(LX, y, 128); me.rot(v >= 75 ? u * 540 : 0, 50, 62); me.pose(v >= 75 ? { sit: 1, armL: 12, armR: 12, sq: 0.08, close: 0.4, open: 0.6, hap: 1 } : { armL: 165, armR: 165, open: 0.9, hap: 1, footL: 2, footR: 2 }); me.hide(t < fallAt);
            if (t >= hitAt) { hit = true; boom(t); } }
          else { const u = (t - hitAt) / 1000; me.rot(0); rings[0].setAttribute('opacity', u < 0.38 ? 0 : 0.85); if (u < 0.38) me.hide(true); else { me.hide(false); me.set(LX, WY + 36 + Math.sin(u * 3) * 2 + (u < 0.6 ? (0.6 - u) * 60 : 0), 128); me.pose({ sit: 1, armL: 130 + 30 * Math.sin(u * 7), armR: 130 - 30 * Math.sin(u * 7), hap: 1, smile: 1, open: 0.5 }); } }
          // the splash animating
          if (hit) { const u = (t - hitAt) / 1000;
            const ch = u < 0.28 ? Math.sin(u / 0.28 * Math.PI / 2) : Math.max(0, 1 - (u - 0.28) / (0.6 + 0.5 * k)), hc = (60 + 270 * k) / 100;
            col.setAttribute('transform', 'translate(' + LX + ' ' + WY + ') scale(' + r2(1 + 0.4 * k * (1 - ch)) + ' ' + r2(Math.max(0.01, ch * hc)) + ')'); col.setAttribute('opacity', r2(0.95 * Math.min(1, ch * 2.5)));
            jets.forEach(j => { const w = u - j.dl, c2 = w < 0 ? 0 : w < 0.3 ? Math.sin(w / 0.3 * Math.PI / 2) : Math.max(0, 1 - (w - 0.3) / (0.55 + 0.45 * k)); j.e.setAttribute('transform', 'translate(' + LX + ' ' + WY + ') scale(1 ' + r2(Math.max(0.01, c2 * j.hj)) + ')'); j.e.setAttribute('opacity', r2(0.88 * Math.min(1, c2 * 2.5))); });
            const cu = cl(u / 0.2, 0, 1), cf = u < 0.5 ? 1 : cl(1 - (u - 0.5) / 0.45, 0, 1); crown.setAttribute('transform', 'translate(' + LX + ' ' + WY + ') scale(' + r2(0.6 + 0.5 * cu) + ' ' + r2(Math.max(0.01, cu * cf)) + ')'); crown.setAttribute('opacity', r2(cf));
            fx.ring.forEach((e, i) => { const w = u - i * 0.15; if (w < 0) return; const r = 14 + (RX - IR - 20) * (1 - Math.exp(-w * 2.4)); e.setAttribute('rx', r2(r)); e.setAttribute('ry', r2(r * 0.2)); e.setAttribute('opacity', r2(cl(1 - w / 1.4, 0, 1) * 0.85)); });
            fx.sheets.forEach(q => { const w = cl((u - 0.05) / 0.32, 0, 1), fade = cl(1 - (u - 0.45) / 0.4, 0, 1); q.e.setAttribute('stroke-dasharray', r2(q.len * w) + ' 999'); q.e.setAttribute('opacity', r2(0.85 * fade)); });
            fx.spills.forEach(q => { const w = cl((u - q.dl) / 0.35, 0, 1), fade = cl(1 - (u - 1.6) / 0.8, 0, 1); q.e.setAttribute('transform', 'scale(1 ' + r2(Math.max(0.01, w)) + ')'); q.e.setAttribute('opacity', r2(0.85 * fade)); q.pd.setAttribute('rx', r2(4 + 26 * w * (0.5 + k))); q.pd.setAttribute('ry', r2(1 + 5 * w * (0.5 + k))); });
            // the water sloshing
            const wy = 'translate(0 ' + r2(Math.sin(u * 12) * k * 5 * Math.exp(-u * 1.6)) + ')'; water.setAttribute('transform', wy); waterF.setAttribute('transform', wy);
            [duckG, ballG].forEach((g, i) => { const bx = (i ? 1 : -1) * 18 * k * Math.min(1, u * 3), by = -Math.max(0, Math.sin(Math.min(1, u * 2.2) * Math.PI)) * (20 + 70 * k) * (k > 0.4 ? 1 : 0.3); g.setAttribute('transform', 'translate(' + r2((i ? PX + 122 : PX - 112) + bx) + ' ' + r2(WY + 2 + by) + ') rotate(' + r2(by * (i ? 2 : -2)) + ')'); });
            let sh = st.shake * Math.exp(-u * 4); const sx = (Math.random() - 0.5) * sh, sy = (Math.random() - 0.5) * sh; shakeG.forEach(g => g.setAttribute('transform', 'translate(' + r2(sx) + ' ' + r2(sy) + ')')); }
          // the friends: look up at you, then the water reaches them
          friends.forEach((fr, i) => { const c = fr.c; let E = { ly: -0.8, lx: (LX - fr.x) / 400, open: 0.4, armR: 110, armL: 40, smile: 0.6 }; if (fr.in) E.sit = 1;
            if (hit) { const u = (t - fr.hitAt) / 1000;
              if (!isFinite(fr.hitAt) || u < 0) E = { ly: -0.3, lx: (LX - fr.x) / 300, open: 0.6, armL: 60, armR: 60, sq: 0.04, sit: fr.in ? 1 : 0 };
              else if (k < 0.3) E = { armL: 150 + 20 * Math.sin(u * 14), armR: 150 - 20 * Math.sin(u * 14), hap: 1, smile: 1, open: 0.6, sit: fr.in ? 1 : 0 };
              else { const shake = u > 1.3 && u < 2.1 ? Math.sin(u * 50) * 14 * (1 - (u - 1.3) / 0.8) : 0; E = { tilt: shake, sq: u < 0.25 ? 0.12 : 0.02, armL: u < 1.2 ? 120 : 150, armR: u < 1.2 ? 120 : 150, open: 0.7, hap: u > 1.3 ? 1 : 0, smile: u > 1.3 ? 1 : 0, close: u < 0.5 ? 0.8 : 0, sit: fr.in ? 1 : 0 };
                if (shake && Math.random() < 0.5) ctx.burst(fr.x + fr.dx + (Math.random() - 0.5) * 40, fr.y + fr.dy - 50, 'drop', 2, { v: 120, spread: TAU, life: 0.5, g: 300 }); }
              // knocked over (big splash): fall back, lie, get up
              const kn = fr.knock && u > 0 ? (u < 0.25 ? u / 0.25 : u < 1.0 ? 1 : Math.max(0, 1 - (u - 1.0) / 0.35)) : 0;
              if (fr.in && fr.knock) { const a = u > 0 && u < 1.0 ? Math.sin(u / 1.0 * Math.PI) : 0; fr.dy = -a * (60 + 120 * k); c.rot(u > 0 && u < 1 ? u * 360 : 0, 50, 60); rings[1].setAttribute('opacity', a > 0.15 ? 0 : 0.85); }
              else { const lb = !fr.knock && k >= 0.55 && u > 0 ? (u < 0.2 ? u / 0.2 : Math.max(0, 1 - (u - 0.5) / 0.6)) : 0; fr.rot = kn * fr.side * 78 + lb * fr.side * 16; fr.dx = kn * fr.side * 26 + lb * fr.side * 10; c.rot(fr.rot, 50, 92); }
              if (u > 0 && fr.wet) { const w = cl(u / 0.35, 0, 1); fr.slap.setAttribute('opacity', r2(0.8 * (1 - w) * (u < 0.35 ? 1 : 0))); fr.slap.setAttribute('transform', 'translate(' + r2(fr.x + fr.dx) + ' ' + r2(fr.y + fr.dy - 30) + ') scale(' + r2(0.6 + 0.8 * w) + ')');
                if (!fr.in) { const pw = cl(u / 0.8, 0, 1) * (0.5 + 0.7 * k); fr.pud.setAttribute('rx', r2(8 + 34 * pw)); fr.pud.setAttribute('ry', r2(2 + 6 * pw)); fr.pud.setAttribute('cx', r2(fr.x + fr.dx * 0.5)); } }
              c.set(fr.x + fr.dx, fr.y + fr.dy, fr.size);
              if (fr.wet > 0) { fr.dripT -= dt; if (fr.dripT <= 0) { fr.dripT = 0.07; ctx.burst(fr.x + fr.dx + (Math.random() - 0.5) * 46, fr.y + fr.dy - 20 - Math.random() * 60, 'drop', 2, { v: 30, dir: Math.PI / 2, spread: 0.5, life: 0.7, g: 420, k: 1.3 }); } fr.wet = Math.max(0, fr.wet - dt * 0.2); } }
            c.pose(E); });
          if (hit && t - hitAt > 3300 && !st.done) { st.done = 1; ctx.finish({ sub: 'Hit the pool at ' + Math.round(v) + ' km/h · top ' + Math.round(st.top) + ' · ' + st.boosts + ' boosts', delay: 700 }); }
          hud_(dt, t); } };
        function boom(t) { SFX.splash(); if (k > 0.5) setTimeout(SFX.splash, 120); if (k > 0.85) setTimeout(SFX.splash, 260); st.shake = 2 + 12 * k;
          ctx.burst(LX, WY - 6, 'drop', Math.round(24 + 110 * k), { v: 170 + 340 * k, spread: 1.4, life: 0.9 + 0.7 * k, g: 520, k: 1 + 0.6 * k }); ctx.burst(LX, WY, 'drop', Math.round(10 + 30 * k), { v: 100 + 150 * k, spread: 3.2, life: 0.9, g: 420, col: '#ffffff', k: 1.2 });
          // drops thrown at each friend (they reach them if the splash is big enough), and their reaction when it lands
          friends.forEach((fr, i) => { const tx = fr.x - LX, ty = (fr.y - 60) - WY, reach = fr.in ? 1 : cl((k - 0.2) / 0.6, 0, 1), T = 0.42 + Math.abs(tx) / 1400;
            if (reach > 0) { const vx = tx / T, vy = (ty - 0.5 * 520 * T * T) / T; ctx.burst(LX + Math.sign(tx) * 14, WY - 8, 'drop', Math.round(6 + 26 * reach), { v: Math.hypot(vx, vy), dir: Math.atan2(vy, vx), spread: 0.22, life: T * 1.25, g: 520, k: 1 + 0.5 * k }); }
            fr.hitAt = t + (fr.in ? 120 : T * 1000); fr.knock = fr.in ? k >= 0.6 : k >= 0.85;
            setTimeout(() => { if (k >= 0.3 || fr.in) { fr.wet = 1; fr.c.host.style.filter = 'saturate(1.35) brightness(0.88) contrast(1.05)'; fr.c.play(fr.knock ? 'surprised' : k >= 0.3 ? 'surprised' : 'happy'); setTimeout(() => fr.c.play('happy'), 1500); ctx.burst(fr.x, fr.y - 50, 'drop', Math.round(14 + 30 * k), { v: 160 + 80 * k, spread: TAU, life: 0.7, g: 400, k: 1.4 }); ctx.burst(fr.x, fr.y - 50, 'drop', 8, { v: 90, spread: TAU, life: 0.6, g: 300, col: '#ffffff', k: 1.6 }); if (fr.knock && !fr.in) SFX.thud(); } else fr.c.play('happy'); }, Math.max(0, fr.hitAt - t)); });
          if (k > 0.6) for (let i = 0; i < Math.round(4 + 8 * (k - 0.6) * 2); i++) { const e = S('circle', { cx: r2(40 + Math.random() * (W - 80)), cy: r2(40 + Math.random() * (H - 100)), r: r2(8 + Math.random() * 18), fill: '#dff6ff', opacity: 0.5, stroke: '#ffffff', 'stroke-width': 2 }, hud); setTimeout(() => e.remove(), 1600 + Math.random() * 800); }
          setTimeout(() => { ctx.toast(tr[1], W / 2, 70, tr[2], true); ctx.add(pts, W / 2, 124, '+' + pts, tr[2]); if (k > 0.55) SFX.score(); }, 520); } }
      // ---------- camera: holds you up left (pulled further back the faster you go), shakes a little at speed, punches in on a boost ----------
      function camera(dt, t) { const fly = st.phase === 'fly', fk = cl((st.v - VB) / 70, 0, 1);
        st.z = lerp(st.z, Z0 * (1 + 0.07 * st.punch), 1 - Math.exp(-dt * 6));
        st.lc = lerp(st.lc, fly ? st.lc : 0.5 * st.l, 1 - Math.exp(-dt * 5));
        if (!fly) st.sc = st.s; else st.sc = lerp(st.sc, LEN + 30, 1 - Math.exp(-dt * 3));
        const ct = [lerp(C0[0], C1[0], fk), lerp(C0[1], C1[1], fk)]; st.cx = lerp(st.cx, ct[0], 1 - Math.exp(-dt * 2.5)); st.cy = lerp(st.cy, ct[1], 1 - Math.exp(-dt * 2.5));
        let sx = 0, sy = 0; if (st.shake > 0.2) { sx = (Math.random() - 0.5) * 2 * st.shake; sy = (Math.random() - 0.5) * 2 * st.shake; st.shake *= Math.exp(-dt * 7); }
        if ((st.phase === 'ride' || st.phase === 'ramp') && st.v > 62) { const a = (st.v - 62) / 45 * 1.4; sx += (Math.random() - 0.5) * a; sy += (Math.random() - 0.5) * a; }
        const cam = Wp(st.sc, st.lc, SH * 0.85); st.tx = st.cx + sx - st.z * cam[0]; st.ty = st.cy + sy - st.z * cam[1];
        const zz = st.z.toFixed(5), tr = 'matrix(' + zz + ' 0 0 ' + zz + ' ' + r2(st.tx) + ' ' + r2(st.ty) + ')'; wB.setAttribute('transform', tr); wF.setAttribute('transform', tr);
        ensure(st.sc, st.z); feed(st.sc, st.z); }
      function place(t, dt) {
        const gh = st.phase === 'fly' ? (st.s < LEN ? HS(st.s) : 0) : HS(st.s), gp = Wp(st.s, st.l, gh), air = st.h - gh;
        meSh.setAttribute('transform', 'translate(' + P2(gp) + ') rotate(' + EL.rot + ')'); meSh.setAttribute('opacity', r2(0.22 * cl(1 - air / 220, 0.2, 1))); meSh.setAttribute('rx', r2(20 * EL.kx * cl(1 - air / 300, 0.5, 1)));
        riderD = Wp(st.s, st.l, 0)[1] + 1; for (const o of stands) { const fr = o.d > riderD; if (fr !== o.fr) sortIn(o, fr); }
        const ride = st.phase === 'ride' || st.phase === 'ramp', bob = ride && st.ha <= 0.5 ? Math.sin(t / 34) * 0.9 * cl(st.v / 70, 0, 1.6) : 0;
        const p = scr(st.s, st.l, st.h); me.set(p[0], p[1] + (5 + bob) * st.z, K * st.z);
        me.rot(st.phase === 'fly' ? (st.lipV >= 75 ? Math.min(360, (t - st.tf) / 1000 * 1.6 * 360) : cl(-st.vh / 18, -20, 24)) : st.phase === 'ramp' ? -(HS(st.s) - SH) / RH * 16 : 0, 50, st.phase === 'fly' && st.lipV >= 75 ? 62 : 80);
        // water spray off your bottom + a star trail while boosted
        if (ride && st.ha <= 1 && st.v > 42) { st.trail -= dt; if (st.trail <= 0) { st.trail = 0.07; const q = scr(st.s - 14, st.l, st.h); ctx.burst(q[0], q[1] - 4, 'drop', 2 + (st.v > 80 ? 1 : 0), { v: 60 + st.v * 1.4, dir: Math.atan2(-F[1], -F[0]) - 0.5, spread: 0.9, life: 0.45, g: 300, col: '#dff4ff' }); } }
        if (ride && st.boostT > 0) { st.sparkT -= dt; if (st.sparkT <= 0) { st.sparkT = 0.05; const q = scr(st.s - 10, st.l, st.h + 20); ctx.burst(q[0], q[1], 'star', 1, { v: 90, dir: Math.atan2(-F[1], -F[0]), spread: 0.8, life: 0.5, g: 0 }); } } }
      function hud_(dt, t) { const v = st.phase === 'pool' ? st.lipV : st.v, tr = tierOf(v), u = cl(v / 110, 0, 1); spArc.setAttribute('stroke-dasharray', r2(arcL * u) + ' 999'); spArc.setAttribute('stroke', v < 42 ? '#5cc87a' : v < 60 ? '#3fc0d8' : v < 80 ? '#ffb020' : v < 100 ? '#ff7a3a' : '#ff4d8a');
        const vt = String(Math.round(v)); if (spTx.textContent !== vt) spTx.textContent = vt; if (tierTx.textContent !== tr[1]) { tierTx.textContent = tr[1]; tierR.setAttribute('fill', tr[2]); }
        const pr = cl(st.s / LEN, 0, 1); pgF.setAttribute('d', 'M40 0H' + r2(40 + 274 * pr)); pgD.setAttribute('cx', r2(40 + 274 * pr)); hud.style.opacity = st.phase === 'ready' ? 0 : 1;
        if (st.phase === 'ride' || st.phase === 'ramp') ctx.timer(Math.max(0, Math.round((LEN - st.s) / 14.4)) + ' m'); else if (st.phase === 'ready' || st.phase === 'pool') ctx.timer('');
        if (st.phase === 'pool') return;
        const go = st.phase === 'ride' || st.phase === 'ramp' || st.phase === 'fly', sk = go ? cl((v - 42) / 55, 0, 1) : 0, spd = v * KV * st.z * 1.7, n = Math.round(6 + 12 * sk), me0 = scr(st.s, st.l, st.h + 30);
        lines.forEach((q, i) => { const on = i < n && sk > 0; q.x -= F[0] * spd * dt * q.n; q.y -= F[1] * spd * dt * q.n;
          if (q.x < -120 || q.y < -120 || q.x > W + 200 || q.y > H + 200) { if (q.near) { q.x = me0[0] + 40 + Math.random() * 160; q.y = me0[1] - 40 + Math.random() * 80; } else { q.x = W * (0.25 + Math.random() * 0.9); q.y = H * (0.05 + Math.random() * 1.05); if (q.x < W && q.y < H && Math.random() < 0.6) q.x = W + 20; } }
          const len = (24 + 120 * sk) * q.n; q.e.setAttribute('d', 'M' + r2(q.x) + ' ' + r2(q.y) + 'l' + r2(F[0] * len) + ' ' + r2(F[1] * len)); q.e.setAttribute('opacity', on ? r2((q.near ? 0.85 : 0.6) * sk) : 0); }); }
      reset(); camera(1, 0); place(0, 0); hud_(0, 0); return api;
    } });
  }; go();
})();
