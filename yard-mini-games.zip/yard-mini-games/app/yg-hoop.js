// Yard Mini Games: HOOP SHOT v2 (Nov 17, user: 'the distance from the hoop needs to be a bit further' + 'in order to shoot I want the user to take his hand
// backwards and then it shows the projection ... show the line in red when the shot would not work, else show it in green that will definitely make the shot
// enter' + 'an animation of the characters throwing the ball' + 'make the environment more detailed / realistic').
// - Pull back from anywhere, like a slingshot: the pull's length is the power, pulling to one side aims to the other. While you pull, the ball's whole flight
//   is simulated with the game's own physics (rim, backboard, net, ground, and where the hoop will be while the ball flies) and drawn as a dotted path:
//   GREEN = this throw goes in, RED = it misses. Let go to throw. The flight you then see is that same simulation played back, so green always scores.
// - Your creature (from behind) winds up as you pull (crouches, the ball sinks behind its head), then pushes up, jumps, follows through with its arms up,
//   lands, lowers its arms and takes the next ball. A hop + cheer on a basket, a little slump on a miss.
// - The hoop is farther: rim 5.0 m from you (was 3.8). It stands at the end of a concrete driveway in front of the garage: painted key, free-throw circle and
//   arc, expansion joints, cracks, an oil stain, leaves; the garage door, siding, a side door, a window with a flower box, wall lamps, the roof + gutter;
//   lawn, hedges, flower pots, a tree, a ball rack and a water bottle + towel; trees and rooftops behind; the afternoon sun's shadows falling towards you.
//   The static scene is its own <svg> under the game's layers (drawn once); only the hoop, the shadows it casts, the path and the balls redraw.
// Swish +3, rim-in / bank +2, 3 in a row = On fire (double points). From 20 points the hoop slides side to side, faster from 50 (it only starts or speeds up
// when no ball is in the air, so a green path stays true). 45 s.
// v3 (Nov 17, user: 'all the games need to be horizontal not vertical'): land: true, the 780 x 360 stage - camera YG.cam(2.4, 1.9, 166, 112) (the ball's arc
//  stays on screen), the backdrop placed from the camera (sky, tree lines, roofs, fence + trees either side of the house, flower beds), PULL 150.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add || !YG.cam) return setTimeout(go, 30); const { S, cl, lerp, r2, SFX } = YG;
  const ICON = '<svg viewBox="0 0 120 84" aria-hidden="true"><rect width="120" height="84" fill="#cfeaff"/><rect y="58" width="120" height="26" fill="#9fdc6e"/><path d="M14 84L36 58H84L106 84Z" fill="#d9d4cc"/>' +
    '<rect x="57" y="22" width="5" height="40" rx="2" fill="#3a3a44"/><rect x="38" y="8" width="44" height="28" rx="3" fill="#fff" stroke="#e8483c" stroke-width="2.5"/><rect x="51" y="18" width="18" height="12" fill="none" stroke="#e8483c" stroke-width="2"/>' +
    '<ellipse cx="60" cy="34" rx="10" ry="3" fill="none" stroke="#f07a2e" stroke-width="2.4"/><path d="M51 35L54 46H66L69 35M55 35L57 46M65 35L63 46M60 35V46" stroke="#fff" stroke-width="1.2" fill="none"/>' +
    '<circle cx="34" cy="40" r="9" fill="#f07a2e"/><path d="M25 40H43M34 31V49M27.5 33.5Q34 40 27.5 46.5M40.5 33.5Q34 40 40.5 46.5" stroke="#7a3410" stroke-width="1.2" fill="none"/></svg>';
  YG.add({ id: 'hoop', land: true, name: 'Hoop Shot', item: 'Basketball Hoop', color: '#ff9a4a', icon: ICON, dur: 45, stars: [30, 60, 100], coinK: 0.35,
    hint: 'Pull back to aim · green = it goes in · let go to throw',
    how: ['Pull back from anywhere, like a slingshot. Farther = harder; to the side = aim the other way.', 'GREEN path = it goes in, RED = it misses. Let go to throw!', 'Swish 3, rim or bank 2. Three in a row = on fire! At 20 points the hoop starts to move.'],
    make(ctx) {
      const { bg, fg, W, H } = ctx, P = YG.cam(2.4, 1.9, 166, 112), G = 9.8, BR = 0.12, RR = 0.23, RT = 0.018, RY = 3.05, RZ = 5.0, BZ = 5.38, PZ = 5.72, GZ = 7.6, DW = 1.8;
      // you stand a little left of the hoop's line (PX), so the ball's arc reads as a curve up and over from behind you, not a straight up-and-down streak
      const PX = -0.5, TH = 62 * Math.PI / 180, HOLD = [PX, 1.0, 0.36], REL = [PX, 1.34, 0.44], THROW = 120, PULL = 150, DT = 1 / 240, LIFE = 3.2;
      const SM = YG.SM, eo = u => 1 - (1 - u) * (1 - u), ei = u => u * u;
      // speed needed to drop the ball in the middle of the rim from the release point (hoop in the middle): the pull maps 0..1 to 0.94..1.06 of it
      // (a 62 deg lob comes down at ~49 deg, steep enough to drop clean through; a pull of ~0.5 swishes, about 0.4 - 0.6 still goes in)
      const L0 = Math.hypot(0 - REL[0], RZ + 0.03 - REL[2]), PH0 = Math.atan2(0 - REL[0], RZ + 0.03 - REL[2]);   // straight at the hoop's middle
      const vMid = (() => { const dz = L0, dy = RY - REL[1], ct = Math.cos(TH); return Math.sqrt(G * dz * dz / (2 * ct * ct * (dz * Math.tan(TH) - dy))); })();
      const vOf = k => vMid * (0.94 + 0.12 * k);
      // ---------- the hoop's motion: a pure function of time, so a flight can be simulated ahead ----------
      const AMP = 0.75, W1 = 0.9, W2 = 1.35, M = { t1: Infinity, t2: Infinity };
      const hxAt = t => { if (api._still || t <= M.t1) return 0; const a = AMP * Math.min(1, (t - M.t1) / 1500), ph = t <= M.t2 ? (t - M.t1) / 1000 * W1 : (M.t2 - M.t1) / 1000 * W1 + (t - M.t2) / 1000 * W2; return Math.sin(ph) * a; };
      // ---------- the static scene (its own svg, under the game's bg layer) ----------
      const court = S('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'yg-layer', preserveAspectRatio: 'none' }); bg.parentNode.insertBefore(court, bg); drawCourt(court);
      function drawCourt(sv) {
        const q = (pts, a, p) => S('path', Object.assign({ d: 'M' + pts.map(([x, z, y]) => { const s = P(x, y || 0, z); return r2(s[0]) + ' ' + r2(s[1]); }).join('L') + 'Z' }, a), p || sv);   // a ground (or wall) polygon: [x, z, y]
        const ln = (pts, a, p) => S('path', Object.assign({ d: 'M' + pts.map(([x, z, y]) => { const s = P(x, y || 0, z); return r2(s[0]) + ' ' + r2(s[1]); }).join('L'), fill: 'none' }, a), p || sv);
        const wp = (x, y) => P(x, y, GZ), wr = (x0, y0, x1, y1, a, p) => { const A = wp(x0, y1), B = wp(x1, y0); return S('rect', Object.assign({ x: r2(A[0]), y: r2(A[1]), width: r2(B[0] - A[0]), height: r2(B[1] - A[1]) }, a), p || sv); };
        const k0 = P(0, 0, GZ)[2];   // px per metre on the wall
        S('defs', {}, sv).innerHTML =
          '<linearGradient id="hcSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6fbaf2"/><stop offset="0.6" stop-color="#b6e0fb"/><stop offset="1" stop-color="#e8f6ff"/></linearGradient>' +
          '<radialGradient id="hcSun" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fffbe6" stop-opacity="0.95"/><stop offset="0.35" stop-color="#fff2b8" stop-opacity="0.55"/><stop offset="1" stop-color="#ffe9a0" stop-opacity="0"/></radialGradient>' +
          '<linearGradient id="hcCon" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e9e4dc"/><stop offset="1" stop-color="#cdc5b8"/></linearGradient>' +
          '<linearGradient id="hcLawn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8fcf62"/><stop offset="1" stop-color="#4f9a3c"/></linearGradient>' +
          '<linearGradient id="hcWall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f6eedf"/><stop offset="1" stop-color="#e9dcc6"/></linearGradient>' +
          '<linearGradient id="hcDoor" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fdfaf3"/><stop offset="1" stop-color="#e8e0d0"/></linearGradient>' +
          '<linearGradient id="hcRoof" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9a4e3e"/><stop offset="1" stop-color="#c0664e"/></linearGradient>' +
          '<linearGradient id="hcGlass" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#a9d6f2"/><stop offset="0.5" stop-color="#6aa8d8"/><stop offset="1" stop-color="#3f7fb8"/></linearGradient>' +
          '<linearGradient id="hcAO" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2a3a" stop-opacity="0.32"/><stop offset="1" stop-color="#3a2a3a" stop-opacity="0"/></linearGradient>' +
          '<radialGradient id="hcBall" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#ffb070"/><stop offset="0.55" stop-color="#f07a2e"/><stop offset="1" stop-color="#b44a14"/></radialGradient>' +
          '<filter id="hcGrain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="3" seed="11"/><feColorMatrix values="0 0 0 0 0.35  0 0 0 0 0.32  0 0 0 0 0.3  0 0 0 0.55 -0.12"/><feComposite in2="SourceGraphic" operator="in"/></filter>' +
          '<filter id="hcBlur" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="2"/></filter>' +
          '<clipPath id="hcDrive"><path d="M' + [[-DW, -1], [DW, -1], [DW, GZ], [-DW, GZ]].map(([x, z]) => { const s = P(x, 0, z); return r2(s[0]) + ' ' + r2(s[1]); }).join('L') + 'Z"/></clipPath>';
        // sky, the sun up left, soft clouds (v3 landscape: the backdrop is placed from the camera, P, so it fits the wide stage)
        const yAt = z => P(0, 0, z)[1], yF = yAt(26), yT = yAt(14);
        S('rect', { x: -20, y: -20, width: W + 40, height: yT + 40, fill: 'url(#hcSky)' }, sv); S('circle', { cx: 90, cy: 40, r: 130, fill: 'url(#hcSun)' }, sv);
        [[110, 52, 0.8], [300, 34, 0.6], [560, 50, 0.75], [700, 24, 0.5], [450, 92, 0.42], [190, 104, 0.4]].forEach(([x, y, k]) => { const g = S('g', { transform: 'translate(' + x + ' ' + y + ') scale(' + k + ')', opacity: 0.9 }, sv);
          [[-28, 6, 17], [-6, -6, 24], [20, 0, 20], [38, 8, 13], [4, 10, 18], [-18, 12, 14]].forEach(([a, b, r]) => S('circle', { cx: a, cy: b, r, fill: '#ffffff' }, g)); S('path', { d: 'M-44 18H52', stroke: '#dcefff', 'stroke-width': 6, 'stroke-linecap': 'round' }, g); });
        // far: hazy tree line + neighbours' roofs, then a nearer darker tree line
        { let d = 'M-20 ' + r2(yF + 6); for (let x = -20; x <= W + 20; x += 14) d += 'Q' + (x + 7) + ' ' + r2(yF - 22 - ((x * 37) % 23)) + ' ' + (x + 14) + ' ' + r2(yF - 12 - ((x * 53) % 11)); S('path', { d: d + 'V' + r2(yT + 10) + 'H-20Z', fill: '#8fbf9a', opacity: 0.75 }, sv); }
        [[40, 1], [150, 0.8], [640, 1.1], [745, 0.85]].forEach(([x, k]) => { const y = yF + 4; S('path', { d: 'M' + (x - 34 * k) + ' ' + r2(y - 22 * k) + 'L' + x + ' ' + r2(y - 44 * k) + 'L' + (x + 34 * k) + ' ' + r2(y - 22 * k) + 'V' + r2(y) + 'H' + (x - 34 * k) + 'Z', fill: '#c9a596', opacity: 0.8 }, sv);
          S('path', { d: 'M' + (x - 40 * k) + ' ' + r2(y - 18 * k) + 'L' + x + ' ' + r2(y - 48 * k) + 'L' + (x + 40 * k) + ' ' + r2(y - 18 * k), fill: 'none', stroke: '#a87a6a', 'stroke-width': 3, opacity: 0.8 }, sv); });
        { let d = 'M-20 ' + r2(yT + 8); for (let x = -20; x <= W + 20; x += 18) d += 'Q' + (x + 9) + ' ' + r2(yT - 18 - ((x * 29) % 19)) + ' ' + (x + 18) + ' ' + r2(yT - 6 - ((x * 41) % 9)); S('path', { d: d + 'V' + r2(yT + 26) + 'H-20Z', fill: '#5f9e5a' }, sv); }
        // the lawn (mowing stripes run towards the house)
        S('rect', { x: -20, y: r2(yT), width: W + 40, height: H, fill: 'url(#hcLawn)' }, sv);
        for (let i = -18; i <= 18; i++) { const x0 = i * 0.9; q([[x0, -1], [x0 + 0.45, -1], [x0 + 0.45, GZ], [x0, GZ]], { fill: '#ffffff', opacity: 0.06 }); }
        // the back fence either side of the house + trees behind it
        [[-11.5, GZ + 2.2, 1.15], [-7.8, GZ + 3.4, 0.9], [7.2, GZ + 2.6, 1.2], [11.8, GZ + 1.6, 0.95]].forEach(([x, z, kk]) => { const p = P(x, 0, z), k = p[2] * kk; S('rect', { x: r2(p[0] - 0.12 * k), y: r2(p[1] - 2.2 * k), width: r2(0.24 * k), height: r2(2.2 * k), fill: '#7a5034' }, sv);
          [[-0.7, -2.4, 0.75, '#4f9a3e'], [0.6, -2.5, 0.8, '#4f9a3e'], [0, -3.2, 0.9, '#5aa84a'], [-0.3, -3.7, 0.55, '#66b456']].forEach(([a, b, r, c]) => S('circle', { cx: r2(p[0] + a * k), cy: r2(p[1] + b * k), r: r2(r * k), fill: c }, sv)); });
        [[-17, -7], [3.5, 17]].forEach(([x0, x1]) => { q([[x0, GZ + 0.4, 0], [x1, GZ + 0.4, 0], [x1, GZ + 0.4, 1.7], [x0, GZ + 0.4, 1.7]], { fill: '#e9d8bd' });
          for (let x = x0; x <= x1; x += 0.36) ln([[x, GZ + 0.4, 0], [x, GZ + 0.4, 1.72]], { stroke: '#cdb796', 'stroke-width': 1 }); ln([[x0, GZ + 0.4, 1.3], [x1, GZ + 0.4, 1.3]], { stroke: '#cdb796', 'stroke-width': 1.6 }); ln([[x0, GZ + 0.4, 1.7], [x1, GZ + 0.4, 1.7]], { stroke: '#fff4e0', 'stroke-width': 2 }); });
        // ---- the house: wall, roof + gable over the garage, garage door, side door, window + flower box, lamps, gutter, downspout ----
        q([[-7, GZ, 0], [3.5, GZ, 0], [3.5, GZ, 2.75], [-7, GZ, 2.75]], { fill: 'url(#hcWall)' });
        { const g = S('g', { stroke: '#dccdb3', 'stroke-width': 0.8, opacity: 0.9 }, sv); for (let y = 0.25; y < 2.7; y += 0.24) ln([[-7, GZ, y], [3.5, GZ, y]], {}, g); }
        q([[-7, GZ, 0], [3.5, GZ, 0], [3.5, GZ, 0.16], [-7, GZ, 0.16]], { fill: '#bdb3a6' });
        // the roof band, its eave shadow and gutter; the gable over the garage
        q([[-7.2, GZ, 2.72], [3.7, GZ, 2.72], [3.4, GZ, 3.5], [-6.9, GZ, 3.5]], { fill: 'url(#hcRoof)' });
        { const g = S('g', { stroke: '#8a4434', 'stroke-width': 0.9, opacity: 0.55 }, sv); for (let y = 2.9; y < 3.5; y += 0.17) ln([[-7.1, GZ, y], [3.6, GZ, y]], {}, g); }
        q([[-1.9, GZ, 2.7], [1.9, GZ, 2.7], [0, GZ, 4.05]], { fill: '#f6eedf', stroke: '#dccdb3', 'stroke-width': 1 });
        { const a = wp(-2.05, 2.62), b = wp(0, 4.2), c = wp(2.05, 2.62); S('path', { d: 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'L' + r2(b[0]) + ' ' + r2(b[1]) + 'L' + r2(c[0]) + ' ' + r2(c[1]), fill: 'none', stroke: '#9a4e3e', 'stroke-width': 4.5, 'stroke-linejoin': 'round' }, sv); }
        { const v = wp(0, 3.35); S('circle', { cx: r2(v[0]), cy: r2(v[1]), r: r2(0.22 * k0), fill: '#e4d6bf', stroke: '#c9b89c', 'stroke-width': 1 }, sv); S('path', { d: 'M' + r2(v[0] - 0.16 * k0) + ' ' + r2(v[1]) + 'H' + r2(v[0] + 0.16 * k0) + 'M' + r2(v[0]) + ' ' + r2(v[1] - 0.16 * k0) + 'V' + r2(v[1] + 0.16 * k0), stroke: '#c9b89c', 'stroke-width': 1 }, sv); }
        q([[-7.2, GZ, 2.68], [3.7, GZ, 2.68], [3.7, GZ, 2.76], [-7.2, GZ, 2.76]], { fill: '#e7e2d8' }); wr(-7, 2.5, 3.5, 2.68, { fill: '#3a2a3a', opacity: 0.08 });
        wr(3.18, 0.1, 3.3, 2.7, { fill: '#e2ddd2', stroke: '#c9c2b4', 'stroke-width': 0.6 });
        // garage door: trim, 4 rows of raised panels, a row of windows on top, a handle
        wr(-1.35, 0, 1.35, 2.22, { fill: '#e6dccb' }); wr(-1.25, 0, 1.25, 2.12, { fill: 'url(#hcDoor)' });
        for (let r = 0; r < 4; r++) { const y0 = r * 0.53, y1 = y0 + 0.53; ln([[-1.25, GZ, y1], [1.25, GZ, y1]], { stroke: '#d3c8b4', 'stroke-width': 1.2 });
          for (let c = 0; c < 4; c++) { const x0 = -1.18 + c * 0.6; if (r === 3) wr(x0 + 0.05, y0 + 0.14, x0 + 0.5, y0 + 0.42, { fill: 'url(#hcGlass)', stroke: '#cfc4b0', 'stroke-width': 1 }); else wr(x0 + 0.05, y0 + 0.1, x0 + 0.5, y0 + 0.42, { fill: 'none', stroke: '#d8cdb9', 'stroke-width': 1 }); } }
        wr(-0.16, 0.5, 0.16, 0.55, { fill: '#9a9488', rx: 1 });
        // side door (left), window with shutters + flower box (left), wall lamps by the garage
        wr(-2.45, 0, -1.75, 2.08, { fill: '#7fa3c4' }); wr(-2.4, 0, -1.8, 2.03, { fill: '#8fb2d2' }); wr(-2.3, 1.3, -1.9, 1.9, { fill: 'url(#hcGlass)' }); { const k = wp(-1.88, 1.0); S('circle', { cx: r2(k[0]), cy: r2(k[1]), r: 1.6, fill: '#e6c060' }, sv); }
        wr(-4.9, 0.95, -3.5, 2.05, { fill: '#ffffff' }); wr(-4.83, 1.02, -3.57, 1.98, { fill: 'url(#hcGlass)' }); ln([[-4.2, GZ, 1.02], [-4.2, GZ, 1.98]], { stroke: '#ffffff', 'stroke-width': 1.6 }); ln([[-4.83, GZ, 1.5], [-3.57, GZ, 1.5]], { stroke: '#ffffff', 'stroke-width': 1.6 });
        wr(-5.25, 0.95, -4.95, 2.05, { fill: '#6f8fb0' }); wr(-3.45, 0.95, -3.15, 2.05, { fill: '#6f8fb0' }); wr(-4.95, 0.8, -3.45, 0.95, { fill: '#a8764a' });
        [[-4.8, '#ff6f91'], [-4.55, '#ffd84a'], [-4.3, '#ff9fd0'], [-4.05, '#ffffff'], [-3.8, '#ff6f91'], [-3.6, '#ffd84a']].forEach(([x, col]) => { const p = wp(x, 1.0); S('circle', { cx: r2(p[0]), cy: r2(p[1]), r: 2.4, fill: '#5fa84c' }, sv); S('circle', { cx: r2(p[0]), cy: r2(p[1] - 1.5), r: 1.7, fill: col }, sv); });
        [-1.6, 1.6].forEach(x => { const p = wp(x, 1.95); S('rect', { x: r2(p[0] - 2.2), y: r2(p[1] - 4), width: 4.4, height: 7, rx: 1.4, fill: '#3a3a44' }, sv); S('rect', { x: r2(p[0] - 1.4), y: r2(p[1] - 3), width: 2.8, height: 4.6, rx: 0.8, fill: '#fff2c4' }, sv); });
        // the wall's foot in shade on the ground; flower pots by the door; hedges either side
        q([[-7, GZ], [3.5, GZ], [3.5, GZ - 0.5], [-7, GZ - 0.5]], { fill: 'url(#hcAO)' });
        [-1.6, 1.6].forEach(x => { const p = P(x, 0, GZ - 0.25), k = p[2]; S('path', { d: 'M' + r2(p[0] - 0.16 * k) + ' ' + r2(p[1] - 0.3 * k) + 'L' + r2(p[0] + 0.16 * k) + ' ' + r2(p[1] - 0.3 * k) + 'L' + r2(p[0] + 0.12 * k) + ' ' + r2(p[1]) + 'L' + r2(p[0] - 0.12 * k) + ' ' + r2(p[1]) + 'Z', fill: '#c96a44' }, sv);
          [[-0.1, -0.42, 0.14], [0.08, -0.46, 0.15], [0, -0.55, 0.13]].forEach(([a, b, r]) => S('circle', { cx: r2(p[0] + a * k), cy: r2(p[1] + b * k), r: r2(r * k), fill: '#58a64a' }, sv)); [[-0.08, -0.5], [0.07, -0.56], [0.02, -0.44]].forEach(([a, b], i) => S('circle', { cx: r2(p[0] + a * k), cy: r2(p[1] + b * k), r: r2(0.05 * k), fill: ['#ff6f91', '#ffd84a', '#ffffff'][i] }, sv)); });
        [[-2.1, -16], [2.05, 16]].forEach(([x0, x1]) => { for (let x = Math.min(x0, x1); x < Math.max(x0, x1); x += 0.42) { const p = P(x + 0.2, 0, GZ - 0.35), k = p[2], g = S('g', {}, sv);
          [[-0.24, -0.34, 0.3], [0.04, -0.46, 0.34], [0.26, -0.32, 0.28]].forEach(([a, b, r], i) => S('circle', { cx: r2(p[0] + a * k), cy: r2(p[1] + b * k), r: r2(r * k), fill: i === 1 ? '#5aa24c' : '#4c9140' }, g)); S('circle', { cx: r2(p[0] - 0.05 * k), cy: r2(p[1] - 0.6 * k), r: r2(0.12 * k), fill: '#7cc46a', opacity: 0.7 }, g); } });
        // trees on the lawn (right + left)
        [[3.0, 6.4], [-5.2, 5.6]].forEach(([tx, tz]) => { const p = P(tx, 0, tz), k = p[2]; S('ellipse', { cx: r2(p[0] - 0.4 * k), cy: r2(p[1] + 0.05 * k), rx: r2(1.1 * k), ry: r2(0.25 * k), fill: '#2a4a20', opacity: 0.25 }, sv); S('path', { d: 'M' + r2(p[0] - 0.1 * k) + ' ' + r2(p[1]) + 'L' + r2(p[0] - 0.06 * k) + ' ' + r2(p[1] - 2.0 * k) + 'L' + r2(p[0] + 0.06 * k) + ' ' + r2(p[1] - 2.0 * k) + 'L' + r2(p[0] + 0.12 * k) + ' ' + r2(p[1]) + 'Z', fill: '#7a5034' }, sv);
          [[-0.6, -2.2, 0.62, '#4f9a3e'], [0.55, -2.3, 0.66, '#4f9a3e'], [0, -2.9, 0.75, '#5aa84a'], [-0.3, -3.3, 0.5, '#66b456'], [0.35, -3.2, 0.48, '#66b456'], [0.1, -2.5, 0.6, '#5aa84a']].forEach(([a, b, r, c]) => S('circle', { cx: r2(p[0] + a * k), cy: r2(p[1] + b * k), r: r2(r * k), fill: c }, sv)); });
        // flower beds + bushes on the side lawns
        [[-3.6, 2.2], [3.3, 1.6], [-6.4, 3.2], [5.6, 3.4]].forEach(([x, z], i) => { const p = P(x, 0, z), k = p[2]; S('ellipse', { cx: r2(p[0]), cy: r2(p[1]), rx: r2(0.7 * k), ry: r2(0.16 * k), fill: '#8a5a34', opacity: 0.85 }, sv);
          for (let j = 0; j < 7; j++) { const a = -0.55 + j * 0.18, c = ['#ff6f91', '#ffd84a', '#ffffff', '#ff9fd0'][(i + j) % 4]; S('circle', { cx: r2(p[0] + a * k), cy: r2(p[1] - 0.12 * k - Math.abs(Math.sin(j * 1.7)) * 0.1 * k), r: r2(0.07 * k), fill: '#58a64a' }, sv); S('circle', { cx: r2(p[0] + a * k), cy: r2(p[1] - 0.2 * k - Math.abs(Math.sin(j * 1.7)) * 0.1 * k), r: r2(0.055 * k), fill: c }, sv); } });
        // ---- the driveway: concrete, grain, edges, joints, cracks, an oil stain, leaves ----
        q([[-DW, -1], [DW, -1], [DW, GZ], [-DW, GZ]], { fill: 'url(#hcCon)' });
        { const y0 = P(0, 0, GZ)[1] - 6; S('rect', { x: 0, y: r2(y0), width: W, height: r2(H - y0), fill: '#ffffff', filter: 'url(#hcGrain)', 'clip-path': 'url(#hcDrive)', opacity: 0.9 }, sv); }
        q([[-DW, -1], [-DW + 0.06, -1], [-DW + 0.06, GZ], [-DW, GZ]], { fill: '#b8b0a2' }); q([[DW - 0.06, -1], [DW, -1], [DW, GZ], [DW - 0.06, GZ]], { fill: '#b8b0a2' });
        [1.4, 3.0, 4.6, 6.2].forEach(z => { ln([[-DW, z], [DW, z]], { stroke: '#a89e90', 'stroke-width': r2(1.6 * P(0, 0, z)[2] / 100) }); ln([[-DW, z + 0.03], [DW, z + 0.03]], { stroke: '#f4f0ea', 'stroke-width': r2(1.2 * P(0, 0, z)[2] / 100), opacity: 0.8 }); });
        ln([[0, -1], [0, GZ]], { stroke: '#b5ab9c', 'stroke-width': 1, opacity: 0.6 });
        ln([[-1.5, 2.3], [-1.28, 2.55], [-1.36, 2.8], [-1.1, 3.0]], { stroke: '#8f8578', 'stroke-width': 1.1, opacity: 0.7 }); ln([[1.2, 5.1], [1.36, 5.4], [1.25, 5.7]], { stroke: '#8f8578', 'stroke-width': 0.9, opacity: 0.6 });
        { const p = P(0.7, 0, 6.9), k = p[2]; S('ellipse', { cx: r2(p[0]), cy: r2(p[1]), rx: r2(0.45 * k), ry: r2(0.12 * k), fill: '#5a5450', opacity: 0.22, filter: 'url(#hcBlur)' }, sv); }
        [[-1.2, 1.9, '#d9883a', 20], [1.5, 2.4, '#c8642e', -30], [-0.4, 4.0, '#e0a040', 60], [1.1, 0.8, '#c8642e', 10], [-1.6, 5.6, '#d9883a', -50]].forEach(([x, z, c, r]) => { const p = P(x, 0, z), k = p[2] / 100;
          S('path', { d: 'M0 -6Q5 -2 0 6Q-5 -2 0 -6Z', fill: c, opacity: 0.85, transform: 'translate(' + r2(p[0]) + ' ' + r2(p[1]) + ') rotate(' + r + ') scale(' + r2(k * 1.4) + ' ' + r2(k * 0.7) + ')' }, sv); });
        // painted court (worn white): the key, the free-throw circle, the arc
        const pa = { stroke: '#ffffff', 'stroke-width': 2.4, opacity: 0.82, 'stroke-linejoin': 'round' };
        ln([[-0.9, BZ - 0.02], [-0.9, 2.3], [0.9, 2.3], [0.9, BZ - 0.02]], pa); ln([[-DW + 0.08, BZ], [DW - 0.08, BZ]], pa);
        { const pts = []; for (let i = 0; i <= 24; i++) { const a = Math.PI * i / 24; pts.push([Math.cos(a) * 0.9, 2.3 - Math.sin(a) * 0.9]); } ln(pts, pa); const p2 = []; for (let i = 0; i <= 24; i++) { const a = Math.PI * i / 24; p2.push([Math.cos(a) * 0.9, 2.3 + Math.sin(a) * 0.9]); } ln(p2, Object.assign({}, pa, { 'stroke-dasharray': '5 6', opacity: 0.6 })); }
        { const pts = [], R = 3.6; for (let i = 0; i <= 40; i++) { const a = -1.05 + 2.1 * i / 40, x = Math.sin(a) * R, z = RZ - Math.cos(a) * R; if (Math.abs(x) <= DW - 0.1) pts.push([x, z]); } ln(pts, pa); }
        // the ball rack (right lawn) with two spare balls, a water bottle + towel (left lawn)
        { const p = P(2.25, 0, 4.4), k = p[2], b = (dx, dy) => { const cx = p[0] + dx * k, cy = p[1] + dy * k, r = 0.12 * k; S('circle', { cx: r2(cx), cy: r2(cy), r: r2(r), fill: 'url(#hcBall)' }, sv); S('path', { d: 'M' + r2(cx - r) + ' ' + r2(cy) + 'H' + r2(cx + r) + 'M' + r2(cx) + ' ' + r2(cy - r) + 'V' + r2(cy + r), stroke: '#7a3410', 'stroke-width': 0.7, opacity: 0.8 }, sv); };
          S('ellipse', { cx: r2(p[0] - 0.1 * k), cy: r2(p[1]), rx: r2(0.4 * k), ry: r2(0.07 * k), fill: '#2a4a20', opacity: 0.25 }, sv); S('path', { d: 'M' + r2(p[0] - 0.3 * k) + ' ' + r2(p[1]) + 'V' + r2(p[1] - 0.55 * k) + 'M' + r2(p[0] + 0.3 * k) + ' ' + r2(p[1]) + 'V' + r2(p[1] - 0.55 * k) + 'M' + r2(p[0] - 0.32 * k) + ' ' + r2(p[1] - 0.3 * k) + 'H' + r2(p[0] + 0.32 * k) + 'M' + r2(p[0] - 0.32 * k) + ' ' + r2(p[1] - 0.55 * k) + 'H' + r2(p[0] + 0.32 * k), stroke: '#4a4a56', 'stroke-width': 1.4, 'stroke-linecap': 'round' }, sv);
          b(-0.14, -0.43); b(0.14, -0.43); b(0.02, -0.15); }
        { const p = P(-2.05, 0, 3.7), k = p[2]; S('ellipse', { cx: r2(p[0]), cy: r2(p[1]), rx: r2(0.3 * k), ry: r2(0.06 * k), fill: '#2a4a20', opacity: 0.22 }, sv);
          S('path', { d: 'M' + r2(p[0] - 0.28 * k) + ' ' + r2(p[1] - 0.02 * k) + 'Q' + r2(p[0] - 0.1 * k) + ' ' + r2(p[1] - 0.1 * k) + ' ' + r2(p[0] + 0.02 * k) + ' ' + r2(p[1] - 0.04 * k) + 'L' + r2(p[0] + 0.06 * k) + ' ' + r2(p[1] + 0.02 * k) + 'L' + r2(p[0] - 0.3 * k) + ' ' + r2(p[1] + 0.04 * k) + 'Z', fill: '#ff8fb8', stroke: '#e0608e', 'stroke-width': 0.8 }, sv);
          S('rect', { x: r2(p[0] + 0.1 * k), y: r2(p[1] - 0.24 * k), width: r2(0.08 * k), height: r2(0.24 * k), rx: 1.2, fill: '#5cc2ff', stroke: '#2f86c8', 'stroke-width': 0.7 }, sv); S('rect', { x: r2(p[0] + 0.11 * k), y: r2(p[1] - 0.29 * k), width: r2(0.06 * k), height: r2(0.05 * k), rx: 0.8, fill: '#f0f4f8' }, sv); }
        // warm afternoon light: a soft gold wash from the sun's side
        S('rect', { x: -20, y: -20, width: W + 40, height: H + 40, fill: 'url(#hcSun)', opacity: 0.25, transform: 'translate(-180 -300) scale(2.2)' }, sv);
      }
      // ---------- the dynamic layers in bg: shadows, the hoop (back / ball slot / front), the aim path, the held + flying balls ----------
      const shG = S('g', {}, bg), hoopG = S('g', {}, bg), backG = S('g', {}, hoopG), slotB = S('g', {}, hoopG), frontG = S('g', {}, hoopG), pathG = S('g', {}, bg), slotH = S('g', {}, bg), bandG = S('g', {}, fg);
      { const d = S('defs', {}, bg); d.innerHTML = '<linearGradient id="hcPole" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2c2c36"/><stop offset="0.45" stop-color="#6a6a7a"/><stop offset="1" stop-color="#2c2c36"/></linearGradient>' +
        '<linearGradient id="hcPad" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#1f4fa8"/><stop offset="0.45" stop-color="#3f7fe0"/><stop offset="1" stop-color="#1f4fa8"/></linearGradient>' +
        '<linearGradient id="hcBoard" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.92"/><stop offset="1" stop-color="#d9ecf8" stop-opacity="0.92"/></linearGradient>'; }
      let hx = 0, netSw = 0, netAt = -9, lastHx = null;
      function drawHoop(t) { const moving = Math.abs(hx - (lastHx == null ? 1e9 : lastHx)) > 1e-4, swaying = t - netAt < 1600; if (!moving && !swaying && lastHx != null) return; lastHx = hx; backG.innerHTML = ''; frontG.innerHTML = ''; shG.querySelectorAll('.hs').forEach(e => e.remove());
        const sun = S('g', { class: 'hs', opacity: 0.2 }, shG); shG.insertBefore(sun, shG.firstChild);   // its shadows on the concrete, falling towards you and right
        const gq = pts => S('path', { d: 'M' + pts.map(([x, z]) => { const s = P(x, 0, z); return r2(s[0]) + ' ' + r2(s[1]); }).join('L') + 'Z', fill: '#2a2034' }, sun);
        gq([[hx - 0.06, PZ], [hx + 0.06, PZ], [hx + 1.05, PZ - 3.2], [hx + 0.93, PZ - 3.2]]); gq([[hx + 0.95, PZ - 2.95], [hx + 2.55, PZ - 2.95], [hx + 2.75, PZ - 4.05], [hx + 1.15, PZ - 4.05]]);
        const pb = P(hx, 0, PZ), pt = P(hx, 3.6, PZ), pw = 0.11 * pb[2];
        S('ellipse', { cx: r2(pb[0]), cy: r2(pb[1]), rx: r2(0.55 * pb[2]), ry: r2(0.1 * pb[2]), fill: '#2a2034', opacity: 0.28 }, backG);
        S('path', { d: 'M' + r2(pb[0] - 0.42 * pb[2]) + ' ' + r2(pb[1]) + 'L' + r2(pb[0] - 0.36 * pb[2]) + ' ' + r2(pb[1] - 0.22 * pb[2]) + 'H' + r2(pb[0] + 0.36 * pb[2]) + 'L' + r2(pb[0] + 0.42 * pb[2]) + ' ' + r2(pb[1]) + 'Z', fill: '#3a3a46' }, backG);
        S('rect', { x: r2(pb[0] - pw / 2), y: r2(pt[1]), width: r2(pw), height: r2(pb[1] - pt[1]), fill: 'url(#hcPole)' }, backG);
        const pd = P(hx, 1.5, PZ); S('rect', { x: r2(pb[0] - pw * 0.9), y: r2(pd[1]), width: r2(pw * 1.8), height: r2(pb[1] - 0.22 * pb[2] - pd[1]), rx: 3, fill: 'url(#hcPad)' }, backG);
        const a1 = P(hx, 3.5, PZ), a2 = P(hx, 3.42, BZ + 0.05), a3 = P(hx, 3.1, PZ), a4 = P(hx, 3.0, BZ + 0.05);
        S('path', { d: 'M' + r2(a1[0]) + ' ' + r2(a1[1]) + 'L' + r2(a2[0]) + ' ' + r2(a2[1]) + 'M' + r2(a3[0]) + ' ' + r2(a3[1]) + 'L' + r2(a4[0]) + ' ' + r2(a4[1]), stroke: '#3a3a46', 'stroke-width': 4, 'stroke-linecap': 'round' }, backG);
        // backboard: shadow, white frame, see-through acrylic with reflections, the red shooter's square
        const b1 = P(hx - 0.9, 3.85, BZ), b2 = P(hx + 0.9, 2.78, BZ), bw = b2[0] - b1[0], bh = b2[1] - b1[1];
        S('rect', { x: r2(b1[0] + 2), y: r2(b1[1] + 3), width: r2(bw), height: r2(bh), rx: 4, fill: '#2a2034', opacity: 0.25 }, backG);
        S('rect', { x: r2(b1[0]), y: r2(b1[1]), width: r2(bw), height: r2(bh), rx: 4, fill: 'url(#hcBoard)', stroke: '#f4f6fa', 'stroke-width': 4 }, backG);
        S('rect', { x: r2(b1[0]), y: r2(b1[1]), width: r2(bw), height: r2(bh), rx: 4, fill: 'none', stroke: '#9aa4b4', 'stroke-width': 1 }, backG);
        S('path', { d: 'M' + r2(b1[0] + bw * 0.12) + ' ' + r2(b1[1] + 3) + 'L' + r2(b1[0] + bw * 0.3) + ' ' + r2(b1[1] + 3) + 'L' + r2(b1[0] + bw * 0.12) + ' ' + r2(b2[1] - 3) + 'L' + r2(b1[0] + 3) + ' ' + r2(b2[1] - 3) + 'L' + r2(b1[0] + 3) + ' ' + r2(b1[1] + bh * 0.4) + 'Z', fill: '#ffffff', opacity: 0.6 }, backG);
        const s1 = P(hx - 0.3, 3.5, BZ), s2 = P(hx + 0.3, 3.08, BZ); S('rect', { x: r2(s1[0]), y: r2(s1[1]), width: r2(s2[0] - s1[0]), height: r2(s2[1] - s1[1]), fill: 'none', stroke: '#e8483c', 'stroke-width': 2.4 }, backG);
        S('rect', { x: r2(b1[0]), y: r2(b2[1] - 2.6), width: r2(bw), height: 2.6, fill: '#e8483c' }, backG);
        const br = P(hx, RY - 0.02, BZ - 0.01), c = P(hx, RY, RZ); S('path', { d: 'M' + r2(br[0] - 3.5) + ' ' + r2(br[1] - 2) + 'L' + r2(br[0] + 3.5) + ' ' + r2(br[1] - 2) + 'L' + r2(c[0] + 2) + ' ' + r2(c[1] - 1 - RR * c[2] * 0.3) + 'L' + r2(c[0] - 2) + ' ' + r2(c[1] - 1 - RR * c[2] * 0.3) + 'Z', fill: '#c8501e' }, backG);
        // rim: back half behind the ball slot, front half + the net in front
        const arc = (a0, a1, w, col, g) => { let d = ''; for (let i = 0; i <= 16; i++) { const a = a0 + (a1 - a0) * i / 16, s = P(hx + Math.cos(a) * RR, RY, RZ + Math.sin(a) * RR); d += (i ? 'L' : 'M') + r2(s[0]) + ' ' + r2(s[1]); } S('path', { d, fill: 'none', stroke: col, 'stroke-width': w, 'stroke-linecap': 'round' }, g); };
        arc(0, Math.PI, 2.6, '#c8501e', backG);
        const sw = netSw * Math.sin((t - netAt) / 70) * Math.exp(-(t - netAt) / 500); let nd = '';
        const ring = (yy, rr, k) => [...Array(12)].map((_, i) => { const a = i / 12 * Math.PI * 2; return P(hx + Math.cos(a) * rr + sw * 0.05 * k, yy, RZ + Math.sin(a) * rr); });
        const r0 = ring(RY, RR, 0), r1 = ring(RY - 0.22, RR * 0.82, 1), r2b = ring(RY - 0.42, RR * 0.6, 2);
        for (let i = 0; i < 12; i++) { const j = (i + 1) % 12; nd += 'M' + r2(r0[i][0]) + ' ' + r2(r0[i][1]) + 'L' + r2(r1[j][0]) + ' ' + r2(r1[j][1]) + 'L' + r2(r2b[i][0]) + ' ' + r2(r2b[i][1]); nd += 'M' + r2(r0[j][0]) + ' ' + r2(r0[j][1]) + 'L' + r2(r1[i][0]) + ' ' + r2(r1[i][1]) + 'L' + r2(r2b[j][0]) + ' ' + r2(r2b[j][1]); }
        S('path', { d: nd, fill: 'none', stroke: '#ffffff', 'stroke-width': 0.9, opacity: 0.95 }, frontG); arc(Math.PI, Math.PI * 2, 3, '#f07a2e', frontG);
        S('ellipse', { cx: r2(c[0]), cy: r2(c[1]), rx: r2(RR * c[2]), ry: r2(RR * c[2] * 0.3), fill: 'none', stroke: '#ffb070', 'stroke-width': 0.8, opacity: 0.6 }, frontG); }
      // ---------- physics (metres, seconds): one step, then a whole flight simulated ahead ----------
      function stepB(b, dt, h, t, out) { const py = b.y, ins0 = Math.hypot(b.x - h, b.z - RZ);
        b.vy -= G * dt; b.x += b.vx * dt; b.y += b.vy * dt; b.z += b.vz * dt;
        const rx = b.x - h, rz = b.z - RZ, d = Math.hypot(rx, rz) || 1e-6, qx = h + RR * rx / d, qz = RZ + RR * rz / d, ex = b.x - qx, ey = b.y - RY, ez = b.z - qz, dist = Math.hypot(ex, ey, ez);
        if (dist < BR + RT) { const nx = ex / dist, ny = ey / dist, nz = ez / dist, vn = b.vx * nx + b.vy * ny + b.vz * nz;
          if (vn < 0) { b.vx -= 1.55 * vn * nx; b.vy -= 1.55 * vn * ny; b.vz -= 1.55 * vn * nz; b.vx *= 0.92; b.vz *= 0.92; b.rim++; out.ev.push([t, 'rim']); }
          b.x = qx + nx * (BR + RT); b.y = RY + ny * (BR + RT); b.z = qz + nz * (BR + RT); }
        if (b.vz > 0 && b.z + BR > BZ && b.z < BZ + 0.08 && Math.abs(b.x - h) < 0.9 + BR * 0.5 && b.y > 2.78 - BR * 0.5 && b.y < 3.85 + BR * 0.5) { b.vz = -b.vz * 0.6; b.vx *= 0.9; b.z = BZ - BR; b.board++; out.ev.push([t, 'board']); }
        const din = Math.hypot(b.x - h, b.z - RZ); if (b.y < RY && b.y > RY - 0.45 && ins0 < RR && py >= RY - 0.45) { if (din > RR * 0.78 - BR * 0.4) { const k = (RR * 0.78 - BR * 0.4) / din; b.x = h + (b.x - h) * k; b.z = RZ + (b.z - RZ) * k; } b.vx *= 0.9; b.vz *= 0.9; b.vy *= 0.97; }
        if (!b.scored && py >= RY && b.y < RY && b.vy < 0 && Math.hypot(b.x - h, b.z - RZ) < RR - 0.02) { b.scored = 1; out.scored = 1; out.swish = !b.rim && !b.board ? 1 : 0; out.tScore = t; out.ev.push([t, 'basket']); }
        if (b.y < BR) { b.y = BR; if (Math.abs(b.vy) > 1.2) { b.bounces++; out.ev.push([t, 'ground']); if (out.tGround < 0) out.tGround = t; } b.vy = -b.vy * 0.55; b.vx *= 0.8; b.vz *= 0.8; if (Math.abs(b.vy) < 0.6) b.vy = 0; } }
      // a throw with pull k (0..1) and aim a (-1..1, + = right), launched at tL (ms): its whole flight + events, and whether it goes in
      function sim(k, a, tL) { const v = vOf(k), ph = PH0 + Math.sign(a) * Math.pow(Math.abs(a), 1.8) * 0.16,   // aim: gentle near the middle (a finger a little off still goes straight), up to ~1 m to the side at the ends
           ct = Math.cos(TH), b = { x: REL[0], y: REL[1], z: REL[2], vx: Math.sin(ph) * v * ct, vz: Math.cos(ph) * v * ct, vy: v * Math.sin(TH), rim: 0, board: 0, scored: 0, bounces: 0 };
        const out = { pos: [], ev: [], scored: 0, swish: 0, tScore: -1, tGround: -1, k, a, tL }, n = Math.round(LIFE / DT);
        for (let i = 0; i <= n; i++) { const t = i * DT; out.pos.push([b.x, b.y, b.z]); stepB(b, DT, hxAt(tL + t * 1000), t, out); } return out; }
      const posAt = (S1, t) => { const f = cl(t / DT, 0, S1.pos.length - 1.001), i = Math.floor(f), u = f - i, A = S1.pos[i], B = S1.pos[i + 1]; return [lerp(A[0], B[0], u), lerp(A[1], B[1], u), lerp(A[2], B[2], u)]; };
      // ---------- the player: your creature from behind; a ball in its paws ----------
      const me = ctx.creature(ctx.playerKey, { yaw: 180 }); const f0 = P(PX, 0, 0.25); me.set(f0[0], f0[1], 1.12 * f0[2]);
      const meSh = YG.shadow(shG, f0[0] + 10, f0[1] - 2, 46, 0.2);
      let balls = [], held = null, nextAt = 0, streak = 0, fire = 0, cheerT = -9, missT = -9, made = 0, tNow = 0, aim = null, thr = null, lastThrow = null, clangAt = 0;
      function mkBall(layer) { const g = S('g', {}, layer || slotH), sh = S('ellipse', { fill: '#2a2034', opacity: 0.18 }, shG), b = S('circle', { r: 10, fill: 'url(#ygBall)' }, g),
          sm = S('path', { fill: 'none', stroke: '#7a3410', 'stroke-width': 1.4, 'stroke-linecap': 'round', opacity: 0.85 }, g), hl = S('ellipse', { fill: '#ffffff', opacity: 0.35 }, g), fl = S('circle', { fill: 'none', stroke: '#ffd84a', 'stroke-width': 2, opacity: 0 }, g);
        return { g, sh, b, sm, hl, fl, x: HOLD[0], y: HOLD[1], z: HOLD[2], spin: 0, born: tNow, fire: 0 }; }
      function drawBall(o, t) { const s = P(o.x, o.y, o.z), r = BR * s[2] * (o.pop == null ? 1 : o.pop); o.b.setAttribute('cx', r2(s[0])); o.b.setAttribute('cy', r2(s[1])); o.b.setAttribute('r', r2(r));
        const sp = o.spin, c = Math.cos(sp), sn = Math.sin(sp); o.sm.setAttribute('d', 'M' + r2(s[0] - r * c) + ' ' + r2(s[1] - r * sn) + 'L' + r2(s[0] + r * c) + ' ' + r2(s[1] + r * sn) + 'M' + r2(s[0] + r * sn) + ' ' + r2(s[1] - r * c) + 'Q' + r2(s[0] - r * 0.25 * c) + ' ' + r2(s[1] - r * 0.25 * sn) + ' ' + r2(s[0] - r * sn) + ' ' + r2(s[1] + r * c));
        o.hl.setAttribute('cx', r2(s[0] - r * 0.35)); o.hl.setAttribute('cy', r2(s[1] - r * 0.4)); o.hl.setAttribute('rx', r2(r * 0.4)); o.hl.setAttribute('ry', r2(r * 0.25));
        o.fl.setAttribute('cx', r2(s[0])); o.fl.setAttribute('cy', r2(s[1])); o.fl.setAttribute('r', r2(r + 2)); o.fl.setAttribute('opacity', o.fire ? 0.5 + 0.4 * Math.sin(t / 60) : 0);
        const g0 = P(o.x, 0, o.z), hgt = cl(1 - o.y / 4, 0.25, 1); o.sh.setAttribute('cx', r2(g0[0] + o.y * 3)); o.sh.setAttribute('cy', r2(g0[1])); o.sh.setAttribute('rx', r2(BR * g0[2] * 1.1 * hgt)); o.sh.setAttribute('ry', r2(BR * g0[2] * 0.3 * hgt)); o.sh.setAttribute('opacity', r2(0.2 * hgt)); }
      // ---------- aiming: the pull, the band, the simulated path ----------
      function pullOf(d) { const len = Math.hypot(d.x, d.y); if (d.y < 6 || len < 16) return null; return { k: cl((len - 16) / PULL, 0, 1), a: cl(-d.x / Math.max(60, d.y) * 0.9, -1.2, 1.2) }; }
      function drawPath(S1) { pathG.innerHTML = ''; bandG.innerHTML = ''; if (!S1 || !aim) return; const ok = S1.scored, col = ok ? '#38d96a' : '#ff4d5e', end = ok ? S1.tScore + 0.14 : Math.min(1.7, S1.tGround > 0 ? S1.tGround : 1.7, (S1.ev.find(e => e[1] === 'rim' || e[1] === 'board') || [9])[0] + 0.35);
        for (let t = 0.03, i = 0; t <= end; t += 1 / 30, i++) { const p = posAt(S1, t), s = P(p[0], p[1], p[2]), r = cl(2.9 * s[2] / 170, 1.4, 3.2);
          S('circle', { cx: r2(s[0]), cy: r2(s[1]), r: r2(r + 1.1), fill: '#1e1430', opacity: 0.32 }, pathG); S('circle', { cx: r2(s[0]), cy: r2(s[1]), r: r2(r), fill: col }, pathG); }
        const c = P(hxAt(S1.tL + S1.tScore * 1000), RY, RZ); if (ok) S('ellipse', { cx: r2(c[0]), cy: r2(c[1]), rx: r2(RR * c[2] + 4), ry: r2(RR * c[2] * 0.3 + 3), fill: 'none', stroke: col, 'stroke-width': 2.4, opacity: 0.9 }, pathG);
        // the slingshot band: from where you pressed to your finger
        S('path', { d: 'M' + r2(aim.x0) + ' ' + r2(aim.y0) + 'L' + r2(aim.x) + ' ' + r2(aim.y), stroke: '#ffffff', 'stroke-width': 3, 'stroke-dasharray': '2 6', 'stroke-linecap': 'round', opacity: 0.8 }, bandG);
        S('circle', { cx: r2(aim.x0), cy: r2(aim.y0), r: 6, fill: 'none', stroke: '#ffffff', 'stroke-width': 2.4, opacity: 0.85 }, bandG); S('circle', { cx: r2(aim.x), cy: r2(aim.y), r: 9, fill: col, stroke: '#ffffff', 'stroke-width': 2.4, opacity: 0.95 }, bandG); }
      // ---------- throwing ----------
      function release(k, a, S0) { if (!held || thr) return; const tL = S0 ? S0.tL : tNow + THROW, S1 = S0 && Math.abs(S0.tL - tL) < 1 ? S0 : sim(k, a, tL);
        thr = { t0: tNow, tL, k, a, S: S1, from: [held.x, held.y, held.z] }; aim = null; drawPath(null); SFX.whoosh(); }
      function launch() { const b = held; held = null; b.S = thr.S; b.tl = thr.tL; b.fired = 0; b.fire = fire > 0 ? 1 : 0; b.missed = 0; balls.push(b); lastThrow = { tL: thr.tL, k: thr.k }; thr = null; nextAt = tNow + 640; }
      function basket(b) { made++; const sw = b.S.swish; streak++; if (streak >= 3 && !fire) { fire = 1; ctx.toast('On fire!', W / 2, H * 0.34, '#ffb03a', true); SFX.win(); }
        const pts = (sw ? 3 : 2) * (fire ? 2 : 1), c = P(hx, RY, RZ); ctx.add(pts, c[0], c[1] - 30, (sw ? 'Swish! +' : '+') + pts, sw ? '#8fe0ff' : '#ffffff');
        ctx.burst(c[0], c[1] + 8, 'confetti', 14, { v: 120, life: 0.9 }); netSw = 1; netAt = tNow; cheerT = tNow; SFX.swish(); setTimeout(SFX.score, 80); }
      function missed() { missT = tNow; if (streak) { streak = 0; if (fire) { fire = 0; ctx.toast('Fire out', W / 2, H * 0.34, '#ffffff'); } } }
      // the hoop starts sliding at 20 points, speeds up at 50 - only once nothing is in the air (a green path stays true)
      function schedule() { const busyTo = Math.max(tNow, ...balls.map(b => b.tl + 2400), thr ? thr.tL + 2400 : 0, aim ? tNow + THROW + 2400 : 0) + 300;   // incl. a throw you may be aiming now
        if (ctx.score >= 20 && M.t1 === Infinity && !api._still) { M.t1 = busyTo; setTimeout(() => { if (ctx.playing) ctx.toast('The hoop moves!', W / 2, H * 0.34, '#ffe36e'); }, Math.max(0, M.t1 - tNow)); }
        if (ctx.score >= 50 && M.t1 < Infinity && M.t2 === Infinity) M.t2 = Math.max(busyTo, M.t1 + 1500); }
      // ---------- the creature's pose: hold, wind up with the pull, push + jump, follow through, land, reach for the next ball ----------
      function poseMe(t) { let E = { armL: 40, armR: 40, lift: 0, sq: 0, tilt: 0, lean: 0 };
        if (thr) { const u = cl((t - thr.t0) / Math.max(1, thr.tL - thr.t0), 0, 1), k = thr.k, w = { armL: 128 - 34 * k, armR: 128 - 34 * k, lift: -1.6 * k, sq: 0.12 * k };
          E = { armL: lerp(w.armL, 172, eo(u)), armR: lerp(w.armR, 172, eo(u)), lift: lerp(w.lift, 7, eo(u)), sq: lerp(w.sq, -0.1, eo(u)), tilt: thr.a * 6 * (1 - u), lean: 0 }; }
        else if (lastThrow && t - lastThrow.tL < 900) { const tt = t - lastThrow.tL, up = tt < 360 ? 1 : 1 - SM((tt - 360) / 360);
          E.armL = E.armR = lerp(40, 172, up); E.lift = tt < 380 ? 7 + Math.sin(Math.min(1, tt / 380) * Math.PI) * 5 - 7 * SM(tt / 380) : 0; E.sq = tt < 380 ? -0.1 * (1 - tt / 380) : 0.08 * Math.sin(cl((tt - 380) / 260, 0, 1) * Math.PI); }
        if (held && !thr) { const k = aim && aim.p ? aim.p.k : 0, kk = held.kk = lerp(held.kk || 0, k, 0.35), born = cl((t - held.born) / 260, 0, 1);
          E.armL = lerp(E.armL, 128 - 34 * kk, born); E.armR = lerp(E.armR, 128 - 34 * kk, born); E.sq += 0.12 * kk; E.lift += -1.6 * kk; E.tilt += aim && aim.p ? aim.p.a * 6 * kk : 0; }
        const tc = t - cheerT; if (tc < 700) { const u = tc / 700, s = Math.sin(u * Math.PI); E.lift += s * 9; E.armL = lerp(E.armL, 150 + 20 * Math.sin(tc / 60), s); E.armR = lerp(E.armR, 150 - 20 * Math.sin(tc / 60), s); E.smile = s; }
        const tm = t - missT; if (tm < 600 && tc > 700) { const s = Math.sin(tm / 600 * Math.PI); E.sq += 0.05 * s; E.armL -= 14 * s; E.armR -= 14 * s; }
        me.pose(E); me.yaw(180 - PH0 * 57.3 * 0.8 + Math.sin(t / 900) * 4 + E.tilt * 0.6); }   // turned a touch towards the hoop
      // ---------- input + loop ----------
      const api = {
        start() { if (!held) held = mkBall(); balls.forEach(b => { b.g.remove(); b.sh.remove(); }); balls = []; streak = 0; fire = 0; made = 0; M.t1 = M.t2 = Infinity; hx = 0; lastHx = null; aim = null; thr = null; drawPath(null); },
        down(p) { aim = { x0: p.x, y0: p.y, x: p.x, y: p.y, p: null, S: null }; },   // you can start pulling before the next ball is in your paws
        move(p) { if (!aim) return; aim.x = p.x; aim.y = p.y; },
        up(p) { if (!aim) return; if (p) { aim.x = p.x; aim.y = p.y; } if (!held || thr) { aim = null; drawPath(null); return; } const pp = pullOf({ x: aim.x - aim.x0, y: aim.y - aim.y0 }), S0 = aim.S; if (!pp) { aim = null; drawPath(null); return; } release(pp.k, pp.a, S0); },
        key(k, dn) { if (dn && (k === ' ' || k === 'ArrowUp')) { if (held && !thr) release(0.5, 0); return true; } },
        // for automated tests: aim (shows the path) / throw with a given pull k 0..1 + aim -1..1; the simulated outcome of a throw
        _aim: (k, a) => { aim = { x0: W / 2, y0: H * 0.45, x: W / 2 - a * 60, y: H * 0.45 + 16 + k * PULL, p: { k, a }, S: null }; }, _shoot: (k, a) => { if (held && !thr) release(k, a == null ? 0 : a); }, _sim: (k, a, tL) => { const S1 = sim(k, a, tL == null ? tNow : tL); return { scored: S1.scored, swish: S1.swish }; },
        _balls: () => balls.map(b => [b.S.scored, b.fired]), _M: M, _still: false, _ready: () => !!held && !thr && !aim,
        timeUp() { aim = null; drawPath(null); ctx.finish({ sub: made + ' basket' + (made === 1 ? '' : 's') }); },
        celebrate(st) { if (st >= 2) cheerT = tNow; },
        destroy() { court.remove(); },
        update(dt, t) { tNow = t; hx = hxAt(t); schedule();
          if (!held && !thr && t > nextAt && ctx.playing) { held = mkBall(); held.pop = 0; }
          if (held && held.pop != null) { held.pop = Math.min(1, (t - held.born) / 220); if (held.pop >= 1) held.pop = null; }
          // aiming: simulate the throw you'd make now (launched THROW ms after you let go) and draw it green / red
          if (aim && held && !thr) { const pp = pullOf({ x: aim.x - aim.x0, y: aim.y - aim.y0 }); aim.p = pp; if (pp) { aim.S = sim(pp.k, pp.a, t + THROW); drawPath(aim.S); } else { aim.S = null; pathG.innerHTML = ''; bandG.innerHTML = ''; S('circle', { cx: r2(aim.x0), cy: r2(aim.y0), r: 6, fill: 'none', stroke: '#ffffff', 'stroke-width': 2.4, opacity: 0.6 }, bandG); } }
          if (thr && t >= thr.tL) launch();
          // the held ball: in the paws over the head; sinks behind the head as you pull; rises to the release point during the throw
          if (held) { if (thr) { const u = cl((t - thr.t0) / Math.max(1, thr.tL - thr.t0), 0, 1), e = ei(u); held.x = lerp(thr.from[0], REL[0], e); held.y = lerp(thr.from[1], REL[1], e); held.z = lerp(thr.from[2], REL[2], e); }
            else { const kk = held.kk || 0; held.x = HOLD[0]; held.y = HOLD[1] - 0.22 * kk + Math.sin(t / 400) * 0.012 * (1 - kk); held.z = HOLD[2] - 0.05 * kk; held.fire = fire > 0 ? 1 : 0; } }
          // flying balls: the simulated flight played back; its events (rim clang, board thud, basket, bounces) fire as they come
          for (const b of balls) { const tt = (t - b.tl) / 1000, p = posAt(b.S, tt); b.x = p[0]; b.y = p[1]; b.z = p[2]; b.spin = tt * 9;
            while (b.fired < b.S.ev.length && b.S.ev[b.fired][0] <= tt) { const e = b.S.ev[b.fired++][1];
              if (e === 'rim') { if (t - clangAt > 120) { SFX.clang(); clangAt = t; } } else if (e === 'board' || e === 'ground') SFX.thud(); else if (e === 'basket') basket(b); }
            if (!b.S.scored && !b.missed && (tt >= 2.2 || (b.S.tGround >= 0 && tt >= b.S.tGround))) { b.missed = 1; missed(); }
            const behind = b.z > RZ - 0.3 && b.y < RY + 0.9, lay = behind ? slotB : slotH; if (b.g.parentNode !== lay) lay.appendChild(b.g);
            if (b.fire && Math.random() < 0.5 && tt < 1.2) { const s = P(b.x, b.y, b.z); ctx.burst(s[0], s[1], 'spark', 1, { v: 30, life: 0.4, g: -40, col: '#ffb03a' }); } }
          balls = balls.filter(b => { if ((t - b.tl) / 1000 > LIFE) { b.g.remove(); b.sh.remove(); return false; } return true; });
          poseMe(t); drawHoop(t); for (const b of [held, ...balls]) if (b) drawBall(b, t);
        } };
      drawHoop(0); held = mkBall(); return api;
    } });
  }; go();
})();
