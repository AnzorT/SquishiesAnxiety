// Yard Mini Games: PING-PONG v3 (Nov 17, user: 'I want to see a physical animation where the player swings the bat with a hand movement' + 'I always see
// things that are not supposed to be visible ... the bat my character is holding with his arm is visible as if he is not holding it' + 'a really good
// animation of characters moving, it just needs to feel like they are walking / running instead of just sliding' + 'change the background of the place').
// You (from behind) vs a creature across the table. Slide left / right: your creature runs to the ball and swings by itself; where the ball meets the paddle
// (and how fast you're moving) angles the return. Rallies speed up. First to 7. Score = 10 a point won + 5 x your longest rally + 50 for the win.
// v3:
// - The paddles are IN the paws: drawn inside each rig every frame at its paw (rive-rig v1117b I.propFn) and layered with the arm that holds it
//   (I.propArm), so a paddle behind the body is hidden like the arm is. You stand three-quarter turned (yaw ~150) and hold it in the arm that shows from
//   behind (armL, pawL); they face you and hold it in armR. Each creature is placed so its paw (measured in its ready pose) is on its paddle line.
// - Swings: ready (paddle out by the side) -> winds back as the ball comes (arm back, crouch, body turns away, paddle opens) -> snaps through just as the
//   ball arrives (pre-timed from the ball's flight), arm up and across, body turning into it, a little hop -> follows through -> back to ready. Same for them.
// - Moving: each creature's own walk / run gait (HouseWalk, st.run when fast) while it shifts, leaning into it, dust puffs when you dig in.
// - Scene (its own svg, drawn once) - out in the backyard (user: 'the game needs to be in the yard, not indoors'): sky, sun, clouds, the neighbours' roofs
//   and tall trees over a wooden board fence with a flower bed, a garden shed, a birdhouse on a pole, a tree with a tyre swing, the lawn (mowing stripes,
//   tufts, daisies), a stone patio under the table (pavers, joints, moss), potted plants + a watering can; the table has a dark edge + side, wheels, braces.
// - Layers: patio | them | table, the ball on their side, the net, the ball on yours | you | the ball once it is behind you.
// - The camera pans with you (the world layers slide, PAN0 - px * PANK stage px), held a little to the left: you hold the paddle on your right, so
//   your body is left of it - at the left end of the table you stay mostly on screen. Your finger still lines up with the paddle (the pan is in the mapping).
// - Nov 17 (user: 'our character is in the air, the table looks higher than him - zoom so we don't see the legs of the character and the table'): the
//   camera is closer and lower (cam(2.0, 2.32, 115, 404), was (1.4, 2.6, 60, 348)): the table's near edge sits at the bottom (~610), your creature's
//   paw / paddle line just above it (~593) with its feet below the screen, the other player from the chest up over the far edge; the table's near legs
//   and brace aren't drawn (they'd only peek in at the bottom corners). The fence moved back (GZ 7) so a strip of yard shows behind them.
// v6 (Nov 17, user: 'all the games need to be horizontal not vertical'): land: true, the 780 x 360 stage - the whole table fits, so no pan (PAN0 = PANK = 0);
//  camera YG.cam(2.0, 2.32, 14, 262) (near edge just above the bottom, your legs still off screen), MESZ 140, OPSZ 82, the fence / trees / bed run wider.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add || !YG.cam) return setTimeout(go, 30); const { S, D, cl, lerp, r2, track, SFX } = YG;
  const ICON = '<svg viewBox="0 0 120 84" aria-hidden="true"><rect width="120" height="84" fill="#9fdc6e"/><path d="M22 70L38 22H82L98 70Z" fill="#2f6fc0"/><path d="M22 70H98V75H22Z" fill="#245a9e"/>' +
    '<path d="M60 22V70M24 64L96 64M37 25H83" stroke="#fff" stroke-width="1.6" opacity="0.9"/><path d="M29 47H91" stroke="#e9eef5" stroke-width="5"/><path d="M29 44H91" stroke="#3a3a44" stroke-width="1"/>' +
    '<circle cx="40" cy="62" r="7" fill="#e8483c"/><rect x="38.5" y="67" width="3" height="7" rx="1.5" fill="#8a5a34"/><circle cx="80" cy="28" r="4.6" fill="#3a3a44"/><circle cx="66" cy="38" r="2.4" fill="#fff"/></svg>';
  YG.add({ id: 'pong', land: true, name: 'Ping-Pong', item: 'Ping-Pong Table', color: '#2f9e6f', icon: ICON, stars: [100, 160, 220], coinK: 0.25,
    hint: 'Slide left and right to move · first to 7',
    how: ['Slide your finger left and right: your creature runs to the ball and swings by itself.', 'Hit it on the paddle\'s edge (or while running) to angle your shot.', 'First to 7 wins. Long rallies score extra!'],
    make(ctx) {
      const { bg, fg, W, H } = ctx, P = YG.cam(2.0, 2.32, 14, 262), G = 8.2, TW = 0.6, Z0 = 0.55, Z1 = 2.95, ZN = 1.75, TY = 0.76, NH = 0.13, BR = 0.022, ZP = 0.45, ZO = 3.06, GZ = 7.0;
      const SM = YG.SM, eo = u => 1 - (1 - u) * (1 - u), stage = ctx.crl.parentNode, PAN0 = 0, PANK = 0, KP = P(0, TY, ZP)[2], PXM = TW + 0.04;
      const fingerToPx = x => cl((x - W / 2 - PAN0) / (KP - PANK), -PXM, PXM);   // the finger lines up with the paddle on screen, pan included
      const svgL = () => { const e = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); e.setAttribute('viewBox', '0 0 ' + W + ' ' + H); e.setAttribute('class', 'yg-layer'); e.setAttribute('preserveAspectRatio', 'none'); e.style.overflow = 'visible'; return e; };
      // layers, back to front: the patio scene | the other player | the table, the ball on their side, the net, the ball on yours | you | fg (the ball once it's behind you, sparks)
      const scene = svgL(); stage.insertBefore(scene, bg);
      const oppL = D('div', { cls: 'yg-layer yg-crl' }), tbl = svgL(); stage.insertBefore(oppL, ctx.crl); stage.insertBefore(tbl, ctx.crl);
      const quad = (pts, a, p) => S('path', Object.assign({ d: 'M' + pts.map(q => { const s = P(q[0], q[1], q[2]); return r2(s[0]) + ' ' + r2(s[1]); }).join('L') + 'Z' }, a), p);
      const line = (pts, a, p) => S('path', Object.assign({ d: 'M' + pts.map(q => { const s = P(q[0], q[1], q[2]); return r2(s[0]) + ' ' + r2(s[1]); }).join('L'), fill: 'none' }, a), p);
      drawScene(scene);
      // ---------- the backyard (drawn once; Nov 17, user: 'the game needs to be in the yard, not indoors'): sky + sun + clouds, tall trees and the
      // neighbours' roofs over a wooden board fence, a flower bed along it, a garden shed, a birdhouse on a pole, a tree with a tyre swing, the lawn
      // (mowing stripes, tufts, daisies), a stone patio under the table (pavers, joints, moss), potted plants + a watering can on its corners ----------
      function drawScene(sv) {
        const k0 = P(0, 0, GZ)[2], gp = (x, z) => P(x, 0, z);
        S('defs', {}, sv).innerHTML =
          '<linearGradient id="ppSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#62b4f0"/><stop offset="0.7" stop-color="#aedcfa"/><stop offset="1" stop-color="#e2f4ff"/></linearGradient>' +
          '<radialGradient id="ppSunG" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fffbe6" stop-opacity="0.95"/><stop offset="0.35" stop-color="#fff2b8" stop-opacity="0.5"/><stop offset="1" stop-color="#ffe9a0" stop-opacity="0"/></radialGradient>' +
          '<linearGradient id="ppLawn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8fcf62"/><stop offset="1" stop-color="#4f9a3c"/></linearGradient>' +
          '<linearGradient id="ppFence" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c98f58"/><stop offset="1" stop-color="#a8703e"/></linearGradient>' +
          '<linearGradient id="ppStone" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d8d0c2"/><stop offset="1" stop-color="#bdb3a2"/></linearGradient>' +
          '<radialGradient id="ppSun" cx="88%" cy="6%" r="90%"><stop offset="0" stop-color="#fff4c8" stop-opacity="0.4"/><stop offset="1" stop-color="#fff4c8" stop-opacity="0"/></radialGradient>' +
          '<filter id="ppGrain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency="0.7" numOctaves="3" seed="8"/><feColorMatrix values="0 0 0 0 0.3  0 0 0 0 0.28  0 0 0 0 0.25  0 0 0 0.5 -0.12"/><feComposite in2="SourceGraphic" operator="in"/></filter>';
        // sky, the sun up right, clouds
        S('rect', { x: -160, y: -20, width: W + 320, height: 380, fill: 'url(#ppSky)' }, sv); const FT = P(0, 1.45, GZ)[1] - 142, far = S('g', { transform: 'translate(0 ' + r2(FT) + ')' }, sv);   // the far tree line + roofs sit on the fence's top S('circle', { cx: 320, cy: 30, r: 130, fill: 'url(#ppSunG)' }, sv);
        [[40, 96, 0.7], [210, 70, 0.55], [430, 104, 0.6], [-90, 70, 0.5], [620, 80, 0.6], [760, 60, 0.5]].forEach(([x, y, k]) => { const g = S('g', { transform: 'translate(' + x + ' ' + y + ') scale(' + k + ')', opacity: 0.92 }, sv); [[-28, 6, 17], [-6, -6, 24], [20, 0, 20], [38, 8, 13], [4, 10, 18], [-18, 12, 14]].forEach(([a, b2, r]) => S('circle', { cx: a, cy: b2, r, fill: '#ffffff' }, g)); });
        // far: hazy tree line + two neighbours' roofs, then the big trees behind the fence
        { let d = 'M-160 150'; for (let x = -160; x <= W + 160; x += 14) d += 'Q' + (x + 7) + ' ' + (122 - ((x * 37 + 999) % 21)) + ' ' + (x + 14) + ' ' + (134 - ((x * 53 + 999) % 11)); S('path', { d: d + 'V190H-160Z', fill: '#8fbf9a', opacity: 0.8 }, far); }
        S('path', { d: 'M-40 128L-6 104L28 128V170H-40Z', fill: '#c9a596', opacity: 0.8 }, far); S('path', { d: 'M370 124L404 100L438 124V170H370Z', fill: '#c9a596', opacity: 0.8 }, far); S('path', { d: 'M600 126L640 98L680 126V170H600Z', fill: '#c9a596', opacity: 0.8 }, far); S('path', { d: 'M760 128L792 106L824 128V170H760Z', fill: '#c9a596', opacity: 0.75 }, far);
        const tree = (x, z, h, r, c1, c2) => { const a = gp(x, z), k = a[2]; S('path', { d: 'M' + r2(a[0] - 0.12 * k) + ' ' + r2(a[1]) + 'L' + r2(a[0] - 0.07 * k) + ' ' + r2(a[1] - h * k) + 'L' + r2(a[0] + 0.07 * k) + ' ' + r2(a[1] - h * k) + 'L' + r2(a[0] + 0.12 * k) + ' ' + r2(a[1]) + 'Z', fill: '#7a5034' }, sv);
          [[-0.7, -h - 0.1, r * 0.8, c1], [0.65, -h, r * 0.85, c1], [0, -h - 0.7, r, c2], [-0.35, -h - 1.1, r * 0.7, c2], [0.4, -h - 1.0, r * 0.66, c2], [0.05, -h - 0.3, r * 0.8, c2]].forEach(([dx, dy, rr, c]) => S('circle', { cx: r2(a[0] + dx * k), cy: r2(a[1] + dy * k), r: r2(rr * k), fill: c }, sv)); };
        tree(-2.6, GZ + 1.2, 2.2, 1.0, '#4c9140', '#5aa84a'); tree(0.6, GZ + 1.6, 2.6, 1.1, '#4f9a3e', '#62ad52'); tree(3.4, GZ + 1.0, 2.0, 0.95, '#4c9140', '#5aa84a'); tree(-4.8, GZ + 1.4, 2.4, 1.0, '#4f9a3e', '#62ad52'); tree(5.6, GZ + 1.4, 2.3, 1.0, '#4f9a3e', '#62ad52'); tree(-7.6, GZ + 1.1, 2.1, 1.0, '#4c9140', '#5aa84a'); tree(8.2, GZ + 1.2, 2.4, 1.05, '#4c9140', '#5aa84a');
        // the lawn (mowing stripes run away from you)
        quad([[-12, 0, -1], [12, 0, -1], [12, 0, GZ], [-12, 0, GZ]], { fill: 'url(#ppLawn)' }, sv);
        for (let i = -12; i <= 12; i++) { const x0 = i * 0.8; quad([[x0, 0, -0.8], [x0 + 0.4, 0, -0.8], [x0 + 0.4, 0, GZ], [x0, 0, GZ]], { fill: '#ffffff', opacity: 0.06 }, sv); }
        // the board fence (posts, rails, boards with gaps), a flower bed along its foot
        quad([[-10, 0, GZ], [10, 0, GZ], [10, 1.45, GZ], [-10, 1.45, GZ]], { fill: 'url(#ppFence)' }, sv);
        { const g = S('g', { stroke: '#8a5a30', 'stroke-width': 0.9, opacity: 0.7 }, sv); for (let x = -10; x <= 10; x += 0.16) line([[x, 0, GZ], [x, 1.45, GZ]], {}, g); }
        [0.25, 1.2].forEach(y => quad([[-10, y, GZ - 0.02], [10, y, GZ - 0.02], [10, y + 0.09, GZ - 0.02], [-10, y + 0.09, GZ - 0.02]], { fill: '#9a6436' }, sv));
        for (let x = -9.8; x <= 10; x += 1.8) quad([[x - 0.05, 0, GZ - 0.03], [x + 0.05, 0, GZ - 0.03], [x + 0.05, 1.52, GZ - 0.03], [x - 0.05, 1.52, GZ - 0.03]], { fill: '#8a5a30' }, sv);
        quad([[-10, 0, GZ - 0.02], [10, 0, GZ - 0.02], [10, 0, GZ - 0.5], [-10, 0, GZ - 0.5]], { fill: '#7a5a3a' }, sv);
        { let sd = 5; const rnd = () => (sd = (sd * 9301 + 49297) % 233280) / 233280; for (let i = 0; i < 110; i++) { const x = -9.6 + rnd() * 19.2, z = GZ - 0.08 - rnd() * 0.36, a = gp(x, z), k = a[2], h = (0.18 + rnd() * 0.22) * k;
          S('path', { d: 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'q' + r2(-0.03 * k) + ' ' + r2(-h * 0.6) + ' ' + r2(0.01 * k) + ' ' + r2(-h), stroke: '#3f8a34', 'stroke-width': 1.2, fill: 'none' }, sv); S('circle', { cx: r2(a[0] + 0.01 * k), cy: r2(a[1] - h), r: r2(0.05 * k + 0.6), fill: ['#ff6f91', '#ffd84a', '#ffffff', '#c9a0ff', '#ff9a4a'][i % 5] }, sv); } }
        // a garden shed (left), a birdhouse on a pole, a tree with a tyre swing (right)
        { const a = gp(-3.4, GZ - 0.9), k = a[2], X = v => r2(a[0] + v * k), Y = v => r2(a[1] - v * k);
          S('path', { d: 'M' + X(-0.8) + ' ' + Y(0) + 'V' + Y(1.7) + 'H' + X(0.8) + 'V' + Y(0) + 'Z', fill: '#b9d0e6' }, sv); S('path', { d: 'M' + X(-0.95) + ' ' + Y(1.65) + 'L' + X(0) + ' ' + Y(2.35) + 'L' + X(0.95) + ' ' + Y(1.65) + 'Z', fill: '#b8604a' }, sv);
          S('rect', { x: X(-0.32), y: Y(1.35), width: r2(0.64 * k), height: r2(1.35 * k), fill: '#8faecb', stroke: '#ffffff', 'stroke-width': 1.2 }, sv); S('circle', { cx: X(0.22), cy: Y(0.7), r: 1.3, fill: '#e6c060' }, sv); S('rect', { x: X(-0.68), y: Y(1.35), width: r2(0.26 * k), height: r2(0.3 * k), fill: '#3f6a88', stroke: '#ffffff', 'stroke-width': 1 }, sv); }
        { const a = gp(-1.9, GZ - 0.7), k = a[2]; S('path', { d: 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'V' + r2(a[1] - 1.7 * k), stroke: '#7a5034', 'stroke-width': r2(0.06 * k) }, sv); S('path', { d: 'M' + r2(a[0] - 0.2 * k) + ' ' + r2(a[1] - 1.6 * k) + 'H' + r2(a[0] + 0.2 * k) + 'V' + r2(a[1] - 1.95 * k) + 'L' + r2(a[0]) + ' ' + r2(a[1] - 2.15 * k) + 'L' + r2(a[0] - 0.2 * k) + ' ' + r2(a[1] - 1.95 * k) + 'Z', fill: '#e8956a' }, sv); S('circle', { cx: r2(a[0]), cy: r2(a[1] - 1.82 * k), r: r2(0.05 * k), fill: '#3a2a20' }, sv); }
        { const a = gp(2.6, GZ - 1.0), k = a[2]; S('ellipse', { cx: r2(a[0] - 0.3 * k), cy: r2(a[1]), rx: r2(1.0 * k), ry: r2(0.2 * k), fill: '#2a4a20', opacity: 0.22 }, sv);
          S('path', { d: 'M' + r2(a[0] - 0.14 * k) + ' ' + r2(a[1]) + 'L' + r2(a[0] - 0.08 * k) + ' ' + r2(a[1] - 2.2 * k) + 'L' + r2(a[0] + 0.08 * k) + ' ' + r2(a[1] - 2.2 * k) + 'L' + r2(a[0] + 0.14 * k) + ' ' + r2(a[1]) + 'Z', fill: '#7a5034' }, sv);
          S('path', { d: 'M' + r2(a[0]) + ' ' + r2(a[1] - 1.9 * k) + 'L' + r2(a[0] - 0.9 * k) + ' ' + r2(a[1] - 2.0 * k), stroke: '#7a5034', 'stroke-width': r2(0.08 * k) }, sv);
          S('path', { d: 'M' + r2(a[0] - 0.7 * k) + ' ' + r2(a[1] - 1.98 * k) + 'V' + r2(a[1] - 0.75 * k), stroke: '#5a5a5a', 'stroke-width': 1 }, sv); S('ellipse', { cx: r2(a[0] - 0.7 * k), cy: r2(a[1] - 0.6 * k), rx: r2(0.22 * k), ry: r2(0.16 * k), fill: 'none', stroke: '#2a2a32', 'stroke-width': r2(0.08 * k) }, sv);
          [[-0.6, -2.5, 0.8, '#4f9a3e'], [0.55, -2.4, 0.75, '#4f9a3e'], [0, -3.0, 0.9, '#5aa84a'], [-0.3, -3.5, 0.6, '#66b456'], [0.4, -3.4, 0.55, '#66b456']].forEach(([dx, dy, r, c]) => S('circle', { cx: r2(a[0] + dx * k), cy: r2(a[1] + dy * k), r: r2(r * k), fill: c }, sv)); }
        // grass tufts + daisies on the lawn
        { let sd = 9; const rnd = () => (sd = (sd * 9301 + 49297) % 233280) / 233280; for (let i = 0; i < 150; i++) { const x = -6.5 + rnd() * 13, z = -0.6 + rnd() * (GZ - 1), a = gp(x, z), k = a[2] / 100; if (Math.abs(x) < 1.45 && z > -0.05 && z < 3.75) continue;
          if (i % 6) S('path', { d: 'M' + r2(a[0] - 3 * k) + ' ' + r2(a[1]) + 'q' + r2(k) + ' ' + r2(-6 * k) + ' ' + r2(2 * k) + ' ' + r2(-8 * k) + 'q' + r2(0.5 * k) + ' ' + r2(5 * k) + ' ' + r2(1.6 * k) + ' ' + r2(8 * k) + 'q' + r2(k) + ' ' + r2(-5 * k) + ' ' + r2(3 * k) + ' ' + r2(-7 * k) + 'q' + r2(-0.6 * k) + ' ' + r2(5 * k) + ' ' + r2(0.4 * k) + ' ' + r2(7 * k) + 'Z', fill: '#3f8a34', opacity: 0.6 }, sv);
          else { for (let j = 0; j < 5; j++) S('circle', { cx: r2(a[0] + Math.cos(j * 1.2566) * 2.4 * k), cy: r2(a[1] + Math.sin(j * 1.2566) * 1.4 * k), r: r2(1.8 * k), fill: '#ffffff' }, sv); S('circle', { cx: r2(a[0]), cy: r2(a[1]), r: r2(1.2 * k), fill: '#ffc93a' }, sv); } } }
        // the stone patio under the table: pavers in rows (offset joints), a little moss, its edge stones
        quad([[-1.45, 0.001, -0.05], [1.45, 0.001, -0.05], [1.45, 0.001, 3.75], [-1.45, 0.001, 3.75]], { fill: 'url(#ppStone)' }, sv);
        S('rect', { x: -160, y: 150, width: W + 320, height: H - 150, fill: '#ffffff', filter: 'url(#ppGrain)', 'clip-path': 'url(#ppPatioC)', opacity: 0.8 }, sv);
        { const cp = S('clipPath', { id: 'ppPatioC' }, sv.querySelector('defs')); quad([[-1.45, 0, -0.05], [1.45, 0, -0.05], [1.45, 0, 3.75], [-1.45, 0, 3.75]], {}, cp); }
        { const g = S('g', { stroke: '#9c917f', 'stroke-width': 1.1, opacity: 0.85 }, sv); for (let z = -0.05, r = 0; z < 3.75; z += 0.42, r++) { line([[-1.45, 0.002, z], [1.45, 0.002, z]], {}, g); for (let x = -1.45 + (r % 2 ? 0.3 : 0); x < 1.45; x += 0.6) line([[x, 0.002, z], [x, 0.002, Math.min(3.75, z + 0.42)]], {}, g); } }
        [[-1.2, 0.5], [0.9, 2.9], [-0.3, 3.4], [1.25, 1.2]].forEach(([x, z]) => { const a = gp(x, z), k = a[2]; S('ellipse', { cx: r2(a[0]), cy: r2(a[1]), rx: r2(0.12 * k), ry: r2(0.03 * k), fill: '#6f9a4a', opacity: 0.5 }, sv); });
        quad([[-1.5, 0.003, -0.1], [1.5, 0.003, -0.1], [1.5, 0.003, -0.02], [-1.5, 0.003, -0.02]], { fill: '#a89e8c' }, sv); quad([[-1.5, 0.003, 3.72], [1.5, 0.003, 3.72], [1.5, 0.003, 3.8], [-1.5, 0.003, 3.8]], { fill: '#a89e8c' }, sv);
        // the table's shadow (the sun is up right), potted plants on the patio's far corners, a watering can
        quad([[-TW + 0.0, 0.004, Z0 + 0.35], [TW + 0.25, 0.004, Z0 + 0.35], [TW + 0.45, 0.004, Z1 - 0.1], [-TW + 0.2, 0.004, Z1 - 0.1]], { fill: '#2a2018', opacity: 0.22 }, sv);
        [[-1.3, 3.55], [1.3, 3.55]].forEach(([x, z]) => { const a = gp(x, z), k = a[2]; S('path', { d: 'M' + r2(a[0] - 0.17 * k) + ' ' + r2(a[1] - 0.36 * k) + 'H' + r2(a[0] + 0.17 * k) + 'L' + r2(a[0] + 0.13 * k) + ' ' + r2(a[1]) + 'H' + r2(a[0] - 0.13 * k) + 'Z', fill: '#c96a44' }, sv);
          [[-0.12, -0.5, 0.14], [0.1, -0.54, 0.15], [0, -0.66, 0.15], [-0.04, -0.4, 0.12]].forEach(([dx, dy, r], i) => S('circle', { cx: r2(a[0] + dx * k), cy: r2(a[1] + dy * k), r: r2(r * k), fill: i % 2 ? '#4f9a3e' : '#5aa84a' }, sv)); [[-0.1, -0.58], [0.09, -0.62], [0.02, -0.46]].forEach(([dx, dy], i) => S('circle', { cx: r2(a[0] + dx * k), cy: r2(a[1] + dy * k), r: r2(0.04 * k + 0.4), fill: ['#ff6f91', '#ffd84a', '#ffffff'][i] }, sv)); });
        { const a = gp(1.75, 2.4), k = a[2]; S('path', { d: 'M' + r2(a[0] - 0.13 * k) + ' ' + r2(a[1]) + 'V' + r2(a[1] - 0.22 * k) + 'H' + r2(a[0] + 0.13 * k) + 'V' + r2(a[1]) + 'Z', fill: '#4fa8e8', stroke: '#2f78b8', 'stroke-width': 0.8 }, sv); S('path', { d: 'M' + r2(a[0] + 0.13 * k) + ' ' + r2(a[1] - 0.18 * k) + 'L' + r2(a[0] + 0.3 * k) + ' ' + r2(a[1] - 0.32 * k), stroke: '#2f78b8', 'stroke-width': r2(0.03 * k) }, sv); S('path', { d: 'M' + r2(a[0] - 0.08 * k) + ' ' + r2(a[1] - 0.22 * k) + 'Q' + r2(a[0]) + ' ' + r2(a[1] - 0.36 * k) + ' ' + r2(a[0] + 0.08 * k) + ' ' + r2(a[1] - 0.22 * k), stroke: '#2f78b8', 'stroke-width': 1, fill: 'none' }, sv); }
        // warm sunlight from the upper right
        S('rect', { x: -160, y: -20, width: W + 320, height: H + 40, fill: 'url(#ppSun)' }, sv);
      }
      // ---------- the table (in its own layer between the two players) ----------
      { const g0 = P(0, 0, (Z0 + Z1) / 2);
        [[-TW + 0.08, Z1 - 0.15], [TW - 0.08, Z1 - 0.15]].forEach(([x, z]) => { /* the far legs only (the near ones are below the screen now) */ const a = P(x, 0.05, z), b2 = P(x, TY - 0.03, z); S('path', { d: 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'L' + r2(b2[0]) + ' ' + r2(b2[1]), stroke: '#2a2a34', 'stroke-width': r2(0.045 * a[2]), 'stroke-linecap': 'round' }, tbl); const w = P(x, 0.03, z); S('circle', { cx: r2(w[0]), cy: r2(w[1]), r: r2(0.04 * w[2]), fill: '#1a1a22' }, tbl); });
        line([[-TW + 0.08, 0.3, Z1 - 0.15], [TW - 0.08, 0.3, Z1 - 0.15]], { stroke: '#2a2a34', 'stroke-width': 2 }, tbl);
        quad([[-TW, TY - 0.045, Z0], [TW, TY - 0.045, Z0], [TW, TY, Z0], [-TW, TY, Z0]], { fill: '#1d4a86' }, tbl);
        quad([[TW, TY - 0.045, Z0], [TW, TY - 0.045, Z1], [TW, TY, Z1], [TW, TY, Z0]], { fill: '#1a4278' }, tbl);
        quad([[-TW, TY, Z0], [TW, TY, Z0], [TW, TY, Z1], [-TW, TY, Z1]], { fill: '#2d6cc0' }, tbl);
        const ln = (a, b2, w) => { const p = P(a[0], TY + 0.001, a[1]), q = P(b2[0], TY + 0.001, b2[1]); S('path', { d: 'M' + r2(p[0]) + ' ' + r2(p[1]) + 'L' + r2(q[0]) + ' ' + r2(q[1]), stroke: '#ffffff', 'stroke-width': w, opacity: 0.92 }, tbl); };
        ln([-TW + 0.015, Z0], [-TW + 0.015, Z1], 2.4); ln([TW - 0.015, Z0], [TW - 0.015, Z1], 2.4); ln([-TW, Z0 + 0.01], [TW, Z0 + 0.01], 2.4); ln([-TW, Z1 - 0.01], [TW, Z1 - 0.01], 1.6); ln([0, Z0], [0, Z1], 1.2);
        quad([[-TW + 0.1, TY + 0.001, Z0 + 0.15], [-0.05, TY + 0.001, Z0 + 0.15], [-0.25, TY + 0.001, Z1 - 0.2], [-TW + 0.1, TY + 0.001, Z1 - 0.2]], { fill: '#ffffff', opacity: 0.07 }, tbl);
        quad([[0.15, TY + 0.001, Z0 + 0.2], [TW - 0.05, TY + 0.001, Z0 + 0.2], [TW - 0.05, TY + 0.001, Z0 + 0.6], [0.3, TY + 0.001, Z0 + 0.6]], { fill: '#fff4d0', opacity: 0.08 }, tbl); }
      const ballFarSh = S('ellipse', { fill: '#10203a', opacity: 0.3 }, tbl), ballFar = S('g', {}, tbl), netG = S('g', {}, tbl), ballNear = S('g', {}, tbl), ballBack = S('g', {}, fg);
      { const a = P(-TW - 0.06, TY, ZN), b2 = P(TW + 0.06, TY, ZN), c = P(TW + 0.06, TY + NH, ZN), d = P(-TW - 0.06, TY + NH, ZN);
        S('path', { d: 'M' + [a, b2, c, d].map(s => r2(s[0]) + ' ' + r2(s[1])).join('L') + 'Z', fill: '#eef2f8', opacity: 0.5 }, netG);
        let m = ''; for (let i = 0; i <= 30; i++) { const x = -TW - 0.06 + (2 * TW + 0.12) * i / 30, p = P(x, TY, ZN), q = P(x, TY + NH, ZN); m += 'M' + r2(p[0]) + ' ' + r2(p[1]) + 'L' + r2(q[0]) + ' ' + r2(q[1]); }
        for (let j = 1; j < 4; j++) { const y = TY + NH * j / 4, p = P(-TW - 0.06, y, ZN), q = P(TW + 0.06, y, ZN); m += 'M' + r2(p[0]) + ' ' + r2(p[1]) + 'L' + r2(q[0]) + ' ' + r2(q[1]); }
        S('path', { d: m, stroke: '#3a3a44', 'stroke-width': 0.6, opacity: 0.6 }, netG); S('path', { d: 'M' + r2(d[0]) + ' ' + r2(d[1]) + 'L' + r2(c[0]) + ' ' + r2(c[1]), stroke: '#ffffff', 'stroke-width': 3 }, netG);
        [a, b2].forEach((s, i) => { const t = [d, c][i]; S('path', { d: 'M' + r2(s[0]) + ' ' + r2(s[1] + 3) + 'L' + r2(t[0]) + ' ' + r2(t[1]), stroke: '#3a3a44', 'stroke-width': 3 }, netG); }); }
      const ballSh = S('ellipse', { fill: '#10203a', opacity: 0.3 }, ballNear), ball = S('circle', { r: 5, fill: '#ffffff', stroke: '#e6dccb', 'stroke-width': 0.8 }), trail = S('path', { fill: 'none', stroke: '#ffffff', 'stroke-width': 3, 'stroke-linecap': 'round', opacity: 0.35 });
      // ---------- the players: you (from behind, three-quarter turned so your paddle arm shows) and them (facing you); paddles held IN the paw ----------
      // (rive-rig v1117b: I.propFn draws the paddle at the paw every frame, I.propArm layers it with that arm - seen from behind, a paddle in front of
      // your body is hidden by it like the arm is; the arm out to the side shows both)
      const PADDLE = (col, edge) => '<rect x="-0.75" y="0.2" width="1.5" height="4.6" rx="0.6" fill="#c98a52" stroke="#6b4426" stroke-width="0.35"/><rect x="-0.75" y="1.7" width="1.5" height="0.9" fill="#8a5a2c" opacity="0.6"/>' +
        '<ellipse cx="0" cy="-3.2" rx="3.7" ry="4" fill="' + col + '" stroke="' + edge + '" stroke-width="0.5"/><ellipse cx="-1.1" cy="-4.5" rx="1.3" ry="0.8" fill="#ffffff" opacity="0.3"/>';
      const ok = ctx.opponent(), okName = ctx.nameOf(ok), opp = YG.creature(oppL, ok, { yaw: 0 }), me = ctx.creature(ctx.playerKey, { yaw: 150 });
      const MESZ = 140, OPSZ = 82, ME = { paw: 'pawL', arm: 'armL', side: 1, ws: {}, off: [26, -36], offN: 0, rot: -25, pad: PADDLE('#e8483c', '#7a1c18'), k: 2.9 }, OP = { paw: 'pawR', arm: 'armR', side: -1, ws: {}, off: [24, -38], offN: 0, rot: 20, pad: PADDLE('#2f6fe0', '#14306e'), k: 2.3 };
      [[me, ME], [opp, OP]].forEach(([c, Q]) => { const I = c.I; if (!I) return; I.propArm = Q.arm; I.propFn = I2 => { const p = I2.W && I2.W[Q.paw]; return p ? '<g transform="translate(' + r2(p[0]) + ' ' + r2(p[1]) + ') rotate(' + r2(Q.rot) + ') scale(' + Q.k + ')">' + Q.pad + '</g>' : ''; }; });
      // where its paw sits (rig units, from its feet) in the ready pose: measured once it has settled, so the paddle in its paw lands on the ball's line
      const learn = (c, Q) => { const p = c.I && c.I.W && c.I.W[Q.paw]; if (!p) return; const o = [p[0] - 50, p[1] - 93]; Q.off = Q.offN ? [lerp(Q.off[0], o[0], 0.5), lerp(Q.off[1], o[1], 0.5)] : o; Q.offN++; };
      const scoreTx = D('div', { cls: 'yg-pill', style: 'position:absolute;left:50%;top:12.5%;transform:translateX(-50%);font-size:14px;padding:6px 12px;white-space:nowrap;' }, stage.querySelector('.yg-hud'));
      let px = 0, pxT = 0, pv = 0, ox = 0, oxT = 0, ov = 0, b = null, pts = [0, 0], rally = 0, best = 0, serve = 0, serveN = 0, phase = 'serve', ph0 = 0, tNow = 0, swingP = -9, swingO = -9, lastHit = 0, skill = 0.55, trailPts = [], dustAt = 0, pvPrev = 0;
      const say = () => { scoreTx.textContent = 'You ' + pts[0] + ' – ' + pts[1] + ' ' + okName; ctx.timer(''); };
      function newBall(who) { b = { x: who ? ox : px + 0.04, y: TY + 0.3, z: who ? ZO - 0.02 : ZP + 0.02, vx: 0, vy: 0, vz: 0, bounces: 0, side: -1 }; phase = 'serve'; ph0 = tNow; serve = who; if (!who) ctx.hint('Tap to serve · slide to move'); }
      // send the ball to land on the other half; T = flight time to that bounce
      function send(from, lx, lz) { const T = Math.max(0.34, 0.6 - rally * 0.012) * (from ? 1.05 : 1); b.vx = (lx - b.x) / T; b.vz = (lz - b.z) / T; b.vy = (TY + BR - b.y + 0.5 * G * T * T) / T;
        const tn = (ZN - b.z) / b.vz; if (tn > 0 && tn < T) { const yn = b.y + b.vy * tn - 0.5 * G * tn * tn; if (yn < TY + NH + BR + 0.03) b.vy += (TY + NH + BR + 0.05 - yn) / tn; }
        b.bounces = 0; b.side = from; lastHit = from; }
      function hitByMe() { const off = (b.x - px) / 0.11, lx = cl(b.x + off * 0.35 + pv * 0.18 + (Math.random() - 0.5) * 0.06, -TW + 0.06, TW - 0.06), lz = 2.25 + Math.random() * 0.5;
        send(0, lx, lz); rally++; if (tNow - swingP > 250) swingP = tNow; SFX.pop(); const s = P(b.x, b.y, b.z); ctx.burst(s[0], s[1], 'spark', 5, { v: 70, life: 0.35 }); if (rally > 1 && rally % 5 === 0) ctx.toast('Rally ' + rally + '!', W / 2, H * 0.3, '#ffe36e'); }
      function hitByOpp() { const away = Math.abs(px) < 0.25 ? (Math.random() < 0.5 ? -1 : 1) : -Math.sign(px), aim = Math.random() < skill * 0.6 ? away * (0.3 + Math.random() * 0.25) : (Math.random() - 0.5) * 0.7;
        send(1, cl(aim, -TW + 0.08, TW - 0.08), 0.8 + Math.random() * 0.55); rally++; if (tNow - swingO > 250) swingO = tNow; SFX.tap(); }
      function point(win, why) { if (phase === 'point') return; phase = 'point'; ph0 = tNow; pts[win ? 0 : 1]++; best = Math.max(best, rally); say();
        if (win) { ctx.add(10, W / 2, H * 0.42, why || 'Point!', '#ffe36e'); SFX.score(); me.play('happy'); opp.play('surprised'); } else { ctx.toast(why || 'Point ' + okName, W / 2, H * 0.42, '#ffffff'); SFX.miss(); opp.play('happy'); }
        rally = 0; skill = cl(0.5 + (pts[0] - pts[1]) * 0.06 + (pts[0] + pts[1]) * 0.015, 0.4, 0.85); }
      // ---------- a swing: ready (paddle out by your side) -> wind back as the ball comes -> snap through the hit, body turning into it -> follow through -> ready ----------
      // wind = 0..1 how far it has wound up (from how soon the ball reaches its paddle), since = ms since its hit
      // Nov 17 (user: 'I don't like the punching animation - the hand with the paddle needs to go forward and not go up, simply like a swing'): a level
      // forehand - the arm stays about horizontal (armL ~80-96) while the hand goes from back (hLz -9, out to the side) to forward (hLz +11, a touch across),
      // the body turning with it (yaw +14 -> -18) and leaning in; the paddle face opens on the backswing and closes through the ball. No lift, no arm up.
      function swingPose(wind, since, q) { const R = { a: 92, hx: 2, hy: 0, hz: 0, lean: 0.2, lift: 0, sq: 0.03, yaw: 0, rot: 10 }, Bk = { a: 80, hx: 7, hy: 2, hz: -9, lean: -0.4, lift: 0, sq: 0.06, yaw: 14, rot: 35 },
          Ht = { a: 96, hx: -2, hy: -1, hz: 11, lean: 0.9, lift: 0.6, sq: -0.02, yaw: -18, rot: -5 }, mix = (A, B2, u) => { const o = {}; for (const k in A) o[k] = lerp(A[k], B2[k], u); return o; };
        let p = mix(R, Bk, SM(wind));
        if (since >= 0 && since < 560) { if (since < 110) p = mix(p, Ht, eo(since / 110)); else if (since < 260) p = Ht; else p = mix(Ht, R, SM((since - 260) / 300)); }
        return p; }
      function poseCreature(c, Q, p, run, dt, spin, yaw0, extra) { const E = Object.assign({ lean: p.lean, lift: p.lift, sq: p.sq }, extra || {}); E[Q.arm] = p.a; E[Q.side > 0 ? 'hLx' : 'hRx'] = Q.side > 0 ? p.hx : -p.hx; E[Q.side > 0 ? 'hLy' : 'hRy'] = p.hy; E[Q.side > 0 ? 'hLz' : 'hRz'] = p.hz;
        c.pose(E); Q.ws.run = run > 0.55 ? 1 : 0; if (window.HouseWalk && run > 0.02) try { window.HouseWalk.step(c.key, Q.ws, c.E, Math.min(1, run * 1.3), dt, 0.7 + run * 1.6, spin); } catch (e) {}
        c.yaw(yaw0 + p.yaw * Q.side); Q.rot = (Q.side > 0 ? -25 : 20) + p.rot * Q.side; }
      const api = { oppKey: ok,   // Nov 17: the intro poster shows this same opponent facing you
        start() { api._done = false; pts = [0, 0]; rally = 0; best = 0; serveN = 0; ctx.setScore(0); say(); newBall(0); me.play('idle'); opp.play('idle'); },
        down(p) { pxT = fingerToPx(p.x); if (phase === 'serve' && serve === 0 && tNow - ph0 > 300) { phase = 'play'; ctx.hint(''); b.x = px + 0.04; hitByMe(); } },
        move(p) { pxT = fingerToPx(p.x); },
        key(k, dn) { if (!dn) return; if (k === 'ArrowLeft') { pxT = cl(pxT - 0.15, -PXM, PXM); return true; } if (k === 'ArrowRight') { pxT = cl(pxT + 0.15, -PXM, PXM); return true; } if (k === ' ' || k === 'ArrowUp') { api.down({ x: W / 2 + PAN0 + px * (KP - PANK) }); return true; } },
        _state: () => ({ phase, pts: pts.slice(), rally, best, b: b && [b.x, b.y, b.z].map(v => +v.toFixed(2)), px: +px.toFixed(2), off: ME.off.map(v => +v.toFixed(1)), offO: OP.off.map(v => +v.toFixed(1)) }), _aimAt: () => { if (b && b.vz < 0) { const tz = (ZP - b.z) / b.vz; pxT = cl(b.x + b.vx * tz - 0.04, -PXM, PXM); } },
        celebrate(st) { api._done = true; me.pose({ armL: 60 }); me.yaw(0); me.play(st >= 2 ? 'happy' : 'idle'); },
        update(dt, t) { tNow = t; const px0 = px; px += (pxT - px) * (1 - Math.exp(-dt * 12)); pv = (px - px0) / Math.max(dt, 0.001);
          if (b && phase === 'serve' && serve === 1 && t - ph0 > 900) { phase = 'play'; hitByOpp(); }
          if (b && phase === 'serve' && serve === 0) { b.x = px + 0.04; b.y = TY + 0.3 + Math.abs(Math.sin((t - ph0) / 260)) * 0.15; b.z = ZP + 0.02; }
          if (b && (phase === 'play' || phase === 'point')) { const n = 4; for (let i = 0; i < n; i++) { const h = dt / n, pz = b.z; b.vy -= G * h; b.x += b.vx * h; b.y += b.vy * h; b.z += b.vz * h;
              if (b.y <= TY + BR && b.vy < 0 && Math.abs(b.x) <= TW && b.z >= Z0 && b.z <= Z1) { b.y = TY + BR; b.vy = -b.vy * 0.82; b.bounces++; SFX.tap(); const hs = b.z < ZN ? 0 : 1;
                if (phase === 'play') { if (hs === lastHit) point(lastHit === 1, lastHit === 1 ? 'Fault!' : 'Fault'); else if (b.bounces >= 2) point(hs === 1, hs === 1 ? 'Point!' : null); } }
              if (phase === 'play' && (pz - ZN) * (b.z - ZN) <= 0 && b.y < TY + NH + BR && Math.abs(b.x) < TW + 0.06) { b.vz = -b.vz * 0.15; b.vx *= 0.3; SFX.thud(); point(lastHit === 1, lastHit === 1 ? 'Net!' : 'Into the net'); }
              if (b.y < BR) { if (phase === 'play' && b.bounces === 0) point(lastHit === 1, lastHit === 1 ? 'Out!' : 'Out'); b.y = BR; b.vy = -b.vy * 0.5; b.vx *= 0.7; b.vz *= 0.7; }
              if (phase === 'play') {
                if (b.vz < 0 && pz >= ZP && b.z < ZP && b.y < TY + 0.75) { if (Math.abs(b.x - px) < 0.13) { if (b.bounces === 1 || b.side === 1 && b.bounces >= 1) hitByMe(); else if (b.bounces === 0) { hitByMe(); } } }
                if (b.z < ZP - 0.35) point(false, null);
                if (b.vz > 0 && pz <= ZO && b.z > ZO && b.y < TY + 0.75) { const pMiss = cl(0.05 + rally * 0.012 - (skill - 0.5) * 0.12, 0.03, 0.32); if (Math.abs(b.x - ox) < 0.13 && Math.random() > pMiss) hitByOpp(); else if (Math.abs(b.x - ox) < 0.2) { swingO = tNow; } }
                if (b.z > ZO + 0.4) point(true, 'Point!'); } } }
          if (phase === 'point' && t - ph0 > 1200) { if (pts[0] >= 7 || pts[1] >= 7) { phase = 'done'; const won = pts[0] > pts[1]; if (won) ctx.add(50 + best * 5, W / 2, H * 0.46, 'You win! +' + (50 + best * 5), '#ffe36e'); else ctx.add(best * 5); ctx.finish({ title: won ? 'You win!' : okName + ' wins', sub: 'You ' + pts[0] + ' – ' + pts[1] + ' · best rally ' + best, delay: 900 }); }
            else { serveN++; newBall(Math.floor(serveN / 2) % 2); } }
          // opponent AI: track where the ball will cross its plane (late + a little off when it is far)
          if (b && phase === 'play' && b.vz > 0) { const tz = (ZO - b.z) / b.vz, gx = b.x + b.vx * tz, err = (1 - skill) * 0.16 * Math.sin(t / 300 + rally); oxT = cl(gx + err, -TW, TW); } else if (phase !== 'serve' || serve === 0) oxT = lerp(oxT, 0, 1 - Math.exp(-dt * 2));
          const sp = 0.9 + skill * 1.4, ox0 = ox; ox += cl(oxT - ox, -sp * dt, sp * dt); if (phase === 'serve' && serve === 1) { ox = lerp(ox, 0, 0.1); b.x = ox; b.y = TY + 0.28 + Math.abs(Math.sin((t - ph0) / 240)) * 0.12; b.z = ZO - 0.02; } ov = (ox - ox0) / Math.max(dt, 0.001);
          // ---- the players move like they mean it: their own walk / run gait while they shift (faster = running), a lean into it, dust when they dig in ----
          const windMe = b && phase === 'play' && b.vz < 0 && b.z > ZP ? cl(1 - ((b.z - ZP) / -b.vz - 0.06) / 0.42, 0, 1) : 0, windOp = b && phase === 'play' && b.vz > 0 && b.z < ZO ? cl(1 - ((ZO - b.z) / b.vz - 0.06) / 0.42, 0, 1) : 0;
          const runMe = cl(Math.abs(pv) / 1.6, 0, 1), runOp = cl(Math.abs(ov) / 1.4, 0, 1);
          // pre-time the forward swing so the paddle is mid-swing (60 ms in) as the ball reaches it, when it's within reach
          if (b && phase === 'play' && b.vz < 0 && b.z > ZP && t - swingP > 600) { const tz = (b.z - ZP) / -b.vz, gx = b.x + b.vx * tz; if (tz < 0.075 && Math.abs(gx - px) < 0.2) swingP = t + tz * 1000 - 60; }
          if (b && phase === 'play' && b.vz > 0 && b.z < ZO && t - swingO > 600) { const tz = (ZO - b.z) / b.vz, gx = b.x + b.vx * tz; if (tz < 0.075 && Math.abs(gx - ox) < 0.2) swingO = t + tz * 1000 - 60; }
          if (!api._done) poseCreature(me, ME, swingPose(windMe, t - swingP), runMe, dt, 180, 150 + cl(pv * 6, -14, 14), { tilt: cl(pv * 5, -7, 7), smile: phase === 'point' ? 0 : 0.2 });
          poseCreature(opp, OP, swingPose(windOp, t - swingO), runOp, dt, 0, cl(-ov * 6, -16, 16) + 8, { tilt: cl(-ov * 5, -7, 7) });
          if (Math.abs(pv - pvPrev) > 9 * dt * 60 * 0.05 && Math.abs(pv) > 1.2 && t > dustAt) { dustAt = t + 260; const f = P(px - 0.2, 0, 0.2); ctx.burst(f[0], Math.min(H - 40, f[1]), 'dust', 4, { v: 50, life: 0.5, layer: fg }); } pvPrev = pv;
          // place each so its paw (and the paddle in it) is on the ball's line: you at your paddle plane, them at theirs
          if (t > 600 && ME.offN < 6 && windMe < 0.05 && t - swingP > 700 && runMe < 0.05) learn(me, ME); if (t > 600 && OP.offN < 6 && windOp < 0.05 && t - swingO > 700 && runOp < 0.05) learn(opp, OP);
          { const g = P(px, TY + 0.11, ZP), k = MESZ / 100; me.set(g[0] - ME.off[0] * k, g[1] - ME.off[1] * k, MESZ); }
          { const g = P(ox, TY + 0.12, ZO), k = OPSZ / 100; opp.set(g[0] - OP.off[0] * k, g[1] - OP.off[1] * k, OPSZ); }
          { const pan = PAN0 - px * PANK, tr = 'translateX(' + r2(pan / W * 100) + '%)'; [scene, bg, oppL, tbl, ctx.crl, fg].forEach(e => { if (e.style.transform !== tr) e.style.transform = tr; }); }
          // ---- the ball: on their side under the net, on yours over it (under you), once behind you over everything ----
          if (b) { const s = P(b.x, b.y, b.z), r = Math.max(2.4, BR * s[2]); ball.setAttribute('cx', r2(s[0])); ball.setAttribute('cy', r2(s[1])); ball.setAttribute('r', r2(r));
            const lay = b.z > ZN ? ballFar : b.z > 0.2 ? ballNear : ballBack; if (ball.parentNode !== lay) { lay.appendChild(trail); lay.appendChild(ball); } if (ballSh.parentNode !== (b.z > ZN ? tbl : ballNear)) (b.z > ZN ? tbl.insertBefore(ballSh, ballFar) : ballNear.insertBefore(ballSh, ballNear.firstChild));
            const onT = Math.abs(b.x) <= TW && b.z >= Z0 && b.z <= Z1, gy = onT ? TY : 0, g0 = P(b.x, gy, b.z), hk = cl(1 - (b.y - gy) / 1.0, 0.2, 1); ballSh.setAttribute('cx', r2(g0[0])); ballSh.setAttribute('cy', r2(g0[1])); ballSh.setAttribute('rx', r2(r * 1.2 * hk)); ballSh.setAttribute('ry', r2(r * 0.5 * hk)); ballSh.setAttribute('opacity', r2(0.35 * hk));
            trailPts.push([s[0], s[1]]); if (trailPts.length > 6) trailPts.shift(); trail.setAttribute('d', phase === 'play' ? 'M' + trailPts.map(q => r2(q[0]) + ' ' + r2(q[1])).join('L') : ''); }
        },
        destroy() { [bg, ctx.crl, fg].forEach(e => { e.style.transform = ''; }); [me, opp].forEach(c => { if (c.I) { c.I.propFn = null; c.I.propArm = null; } }); opp.destroy(); oppL.remove(); tbl.remove(); scene.remove(); } };
      ballFarSh.remove(); newBall(0); say(); return api;
    } });
  }; go();
})();
