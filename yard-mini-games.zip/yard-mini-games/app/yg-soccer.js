// Yard Mini Games: PENALTY KICK (the backyard's Soccer Goal). 5 penalties against a goalkeeper creature. Swipe up from the ball:
// the swipe's direction aims left / right, its length sets the height (too long = over the bar). The keeper reads some shots (more each kick);
// corners and top shots are harder to save but easy to put wide. Goal 100, corner +50, top +50.
// v2 (Nov 17, user: 'all the games need to be horizontal not vertical'): land: true - camera YG.cam(2.6, 1.5, 104, 205), wider mowing stripes, the swipe
//  maps a shorter length to the height ((len - 50) / 180) for the 360-high stage.
// v3 (Nov 17, user: 'the game needs to have the same basics as the basketball one, only that we dont show it as red or green'): aiming works like Hoop
//  Shot - pull back from anywhere like a slingshot (the pull's length = how high: 0.15 + 1.85 k m where it crosses the line, over the bar past k ~0.67; pulling
//  to one side aims to the other: X = 1.7 a, the post at a ~0.76), the slingshot band from where you pressed to your finger, and the ball's whole flight
//  simulated with the game's own physics (posts, bar, net, ground; sim(k, a), DT 1/240) drawn as a dotted path + a ring where it crosses the goal line - in
//  WHITE only (no red / green: the keeper isn't in the simulation, he can still save it). Let go to kick: the flight you see is that same simulation played
//  back (no random wobble any more), until the keeper gets a glove on it (then live physics takes over). Your creature winds up as you pull (steps back,
//  crouches, arms out), runs up and kicks.
// v4 (Nov 17, user: 'make the goal larger ... the ball is behind the goalkeeper which looks as if he was supposed to block it but it doesn't ... make the goal
//  further away from my character ... the character running to kick the ball after I decided where to hit it, a real animation of the ball being kicked
//  and the distance it goes until it hits the goal, then the character trying to dodge (stop) it'):
//  - A bigger goal farther away: GW 1.9 (3.8 m wide), GH 1.9, the goal line GZ 7 (6 m from the spot, B0 z 1); camera YG.cam(4, 0.984, 144, 198) (goal
//    ~274 px wide, its bar near y 78 under the HUD, the spot near y 300; the kicker KS 0.55 so its head stays under the goal line); the box, D, mowing stripes, net (18 x 9, 1.1 deep) scaled up.
//  - You stand back at the run-up (-1.0, -0.25) while you aim (winding up with the pull); let go and you RUN (760 ms, the house gait sped up, turned towards
//    the ball) to it and kick: a back-swing, the foot through the ball, an impact star + dust, the ball off with a fading trail + spin, getting smaller all
//    the way to the goal (T = 0.88 - 0.2 k s for the 6 m).
//  - The ball is drawn on its own svg (ballL) ABOVE the keeper's rig while it's in front of him (z < KZ) and below him once past (then behind the posts
//    once in the goal) - it never slides behind a keeper it hasn't reached.
//  - The keeper's dive is planned at the kick from where the sim says the ball crosses his line (tK, xK, yK): SAVE (he read it and it's in reach: his
//    extended paw meets the ball at tK - the last 110 ms ease the ball onto the rig's real paw (I.W) - and it's parried away), BEATEN (read, but a corner /
//    out of reach: the same dive, the fingertips ~0.5 m short), WRONG WAY or STAY (a guess). The body / paw is kept clear of the ball unless it's a save
//    (a guess that ends up in the way becomes a block). Diving: the extended-arm pose (hLx/hRx 14, hLy/hRy -28) rolled so the arm points at the ball
//    (θ = 180 - φ for the left paw, -φ for the right, |θ| <= 55), a jump up to 0.9 m, a stressed face (wide teary eyes, mouth open) + sweat drops, then
//    he lands on his side.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add || !YG.cam) return setTimeout(go, 30); const { S, cl, lerp, r2, track, SFX } = YG;
  const ICON = '<svg viewBox="0 0 120 84" aria-hidden="true"><rect width="120" height="84" fill="#cfeaff"/><rect y="46" width="120" height="38" fill="#9fdc6e"/>' +
    '<path d="M22 58V22H98V58" fill="none" stroke="#fff" stroke-width="4" stroke-linejoin="round"/><path d="M26 24L34 34V56M94 24L86 34V56M34 34H86" fill="none" stroke="#e8eef5" stroke-width="2"/>' +
    '<path d="M26 26H94M26 32H94M26 38H94M26 44H94M26 50H94M34 24V56M44 24V56M54 24V56M64 24V56M74 24V56M84 24V56" stroke="#ffffff" stroke-width="0.8" opacity="0.6"/>' +
    '<path d="M12 70H108" stroke="#fff" stroke-width="2"/><circle cx="60" cy="68" r="9" fill="#fff" stroke="#3a3a44" stroke-width="1.2"/><path d="M60 63L64 66L62.5 71H57.5L56 66Z" fill="#3a3a44"/></svg>';
  YG.add({ id: 'soccer', land: true, name: 'Penalty Kick', item: 'Soccer Goal', color: '#5cc2ff', icon: ICON, stars: [250, 450, 700], coinK: 0.06,
    hint: 'Pull back to aim · the dots show the shot · let go to kick',
    how: ['Pull back from anywhere, like a slingshot. Farther = higher (too far flies over the bar); to the side = aim the other way.', 'The dotted path shows where the ball will go. Let go and your creature runs up and kicks, but the keeper can still save it!', '5 penalties. Corners and top shots score bonus points.'],
    make(ctx) {
      const { bg, fg, W, H } = ctx, CAM = [4, 0.984, 144, 198], P = YG.cam(...CAM), G = 9.8, GZ = 7, GW = 1.9, GH = 1.9, BR = 0.11, B0 = [0, BR, 1.0], KZ = GZ - 0.45, SM = YG.SM;
      const toW = (sx, sy, z) => { const k = CAM[0] / (CAM[0] + z) * CAM[3]; return [(sx - W / 2) / k, CAM[1] - (sy - CAM[2]) / k]; };   // screen -> world on the plane z
      YG.yard(bg, { hz: CAM[2] });
      const line = (pts, w, p, op) => S('path', { d: 'M' + pts.map(q => { const s = P(q[0], 0, q[1]); return r2(s[0]) + ' ' + r2(s[1]); }).join('L'), fill: 'none', stroke: '#ffffff', 'stroke-width': w || 2.5, opacity: op || 0.9, 'stroke-linejoin': 'round' }, p || bg);
      // mowing stripes + pitch lines (goal line, the box, the D, the spot, touch lines)
      for (let i = 0; i < 9; i++) { const z0 = -1.2 + i * 1.1, a = P(-14, 0, z0), b = P(14, 0, z0), c = P(14, 0, z0 + 0.55), d = P(-14, 0, z0 + 0.55); S('path', { d: 'M' + [a, b, c, d].map(s => r2(s[0]) + ' ' + r2(s[1])).join('L') + 'Z', fill: '#ffffff', opacity: 0.07 }, bg); }
      line([[-6, GZ], [6, GZ]]); line([[-3.1, GZ], [-3.1, GZ - 2.2], [3.1, GZ - 2.2], [3.1, GZ]]); line([[-2.4, GZ], [-2.4, GZ - 0.8], [2.4, GZ - 0.8], [2.4, GZ]], 2, bg, 0.7); line([[-5.2, GZ], [-5.2, -1.2]], 2, bg, 0.5); line([[5.2, GZ], [5.2, -1.2]], 2, bg, 0.5);
      { let d = ''; for (let i = 0; i <= 18; i++) { const a = Math.PI * i / 18, s = P(Math.cos(a) * 1.1, 0, GZ - 2.2 - Math.sin(a) * 0.7); d += (i ? 'L' : 'M') + r2(s[0]) + ' ' + r2(s[1]); } S('path', { d, fill: 'none', stroke: '#ffffff', 'stroke-width': 2.2, opacity: 0.8 }, bg); }
      const spot = P(0, 0, B0[2]); S('ellipse', { cx: spot[0], cy: spot[1], rx: 9, ry: 2.6, fill: '#ffffff', opacity: 0.9 }, bg);
      // the goal: back frame + net behind, then the posts in front (fg); the ball on its own layer (in front of / behind the keeper); the aim path over all
      const netG = S('g', {}, bg), shG = S('g', {}, bg), postG = S('g', {}, fg), ballSlotBack = S('g', {}, bg);
      const ballL = S('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'yg-layer', preserveAspectRatio: 'none', style: 'pointer-events:none;z-index:2' }, fg.parentNode), trailG = S('g', {}, ballL), ballSlot = S('g', {}, ballL), fxG = S('g', {}, ballL);
      const aimL = S('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'yg-layer', preserveAspectRatio: 'none', style: 'pointer-events:none;z-index:4' }, fg.parentNode), pathG = S('g', {}, aimL), bandG = S('g', {}, aimL);
      const NX = 18, NY = 9, ND = 1.1; let bulge = { x: 0, y: 0, a: 0, t: -9 };
      function drawNet(t) { netG.innerHTML = ''; const k = bulge.a * Math.exp(-(t - bulge.t) / 420) * (1 + 0.2 * Math.sin((t - bulge.t) / 60));
        const pt = (x, y) => { const back = ND * (1 - y / GH * 0.55), d = Math.hypot(x - bulge.x, y - bulge.y), push = k * Math.exp(-d * d / 0.3) * 0.6; return P(x, y, GZ + back + push); };
        let d = ''; for (let i = 0; i <= NX; i++) { const x = -GW + 2 * GW * i / NX; for (let j = 0; j <= NY; j++) { const y = GH * j / NY, s = pt(x, y); d += (j ? 'L' : 'M') + r2(s[0]) + ' ' + r2(s[1]); } }
        for (let j = 0; j <= NY; j++) { const y = GH * j / NY; for (let i = 0; i <= NX; i++) { const x = -GW + 2 * GW * i / NX, s = pt(x, y); d += (i ? 'L' : 'M') + r2(s[0]) + ' ' + r2(s[1]); } }
        for (let j = 0; j <= NY; j++) { const y = GH * j / NY, a = P(-GW, y, GZ), b = pt(-GW, y), c = P(GW, y, GZ), e = pt(GW, y); d += 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'L' + r2(b[0]) + ' ' + r2(b[1]) + 'M' + r2(c[0]) + ' ' + r2(c[1]) + 'L' + r2(e[0]) + ' ' + r2(e[1]); }
        S('path', { d, fill: 'none', stroke: '#ffffff', 'stroke-width': 0.9, opacity: 0.75 }, netG);
        const fb = [P(-GW, 0, GZ + ND), P(-GW, GH * 0.95, GZ + ND * 0.48), P(GW, GH * 0.95, GZ + ND * 0.48), P(GW, 0, GZ + ND)]; S('path', { d: 'M' + fb.map(s => r2(s[0]) + ' ' + r2(s[1])).join('L'), fill: 'none', stroke: '#dfe6ee', 'stroke-width': 2.6 }, netG); }
      { const a = P(-GW, 0, GZ), b = P(-GW, GH, GZ), c = P(GW, GH, GZ), d = P(GW, 0, GZ), w = 0.08 * a[2], pth = 'M' + r2(a[0]) + ' ' + r2(a[1]) + 'L' + r2(b[0]) + ' ' + r2(b[1]) + 'L' + r2(c[0]) + ' ' + r2(c[1]) + 'L' + r2(d[0]) + ' ' + r2(d[1]);
        S('path', { d: pth, fill: 'none', stroke: '#c9d2dc', 'stroke-width': r2(w + 1.6), 'stroke-linejoin': 'round' }, postG); S('path', { d: pth, fill: 'none', stroke: '#ffffff', 'stroke-width': r2(w), 'stroke-linejoin': 'round' }, postG); }
      // keeper (faces you) + kicker (from behind; waits at the run-up spot back left)
      const kp = ctx.opponent(), kpName = ctx.nameOf(kp), keeper = ctx.creature(kp, { yaw: 0 }), kick = ctx.creature(ctx.playerKey, { yaw: 160 });
      const RUN0 = [-1.0, -0.25], KICKAT = [-0.45, 0.8], KS = 0.55;   // the run-up start, where it plants its foot to kick, the kicker's size factor
      const kShadow = YG.shadow(shG, 0, 0, 20, 0.2), pShadow = YG.shadow(shG, 0, 0, 30, 0.2), bShadow = S('ellipse', { fill: '#3a2a55', opacity: 0.2 }, shG);
      // the ball
      const bG = S('g', {}, ballSlot), bC = S('circle', { fill: 'url(#ygWhite)', stroke: '#3a3a44', 'stroke-width': 1 }, bG), bP = S('path', { fill: '#3a3a44' }, bG);
      const PULL = 150, DT = 1 / 240, LIFE = 2.6, RUN = 760;
      const res = []; let shot = 0, phase = 'aim', ph0 = 0, tNow = 0, ball = null, aim = null, runFrom = null, skill = 0.35, outcome = null, wind = 0, shotS = null, quietAt = 0, trail = [], kickT = -9, dropAt = 0;
      // the keeper: kx / kH (feet, jump) / th (roll, deg, + = top to the right), its dive plan `dv`
      let kx = 0, kH = 0, th = 0, kx0 = 0, dv = null;
      const dotsEl = document.createElement('div'); dotsEl.className = 'yg-pill'; dotsEl.style.cssText = 'position:absolute;left:50%;top:12.5%;transform:translateX(-50%);display:flex;gap:6px;padding:6px 10px;font-size:14px;'; ctx.crl.parentNode.querySelector('.yg-hud').appendChild(dotsEl);
      function drawDots() { dotsEl.innerHTML = ''; for (let i = 0; i < 5; i++) { const s = document.createElement('span'); s.textContent = res[i] == null ? '○' : res[i] ? '●' : '✕'; s.style.color = res[i] == null ? '#b9a8d6' : res[i] ? '#2fb24a' : '#e8483c'; dotsEl.appendChild(s); } }
      function place() { const k = P(kx, 0, KZ); keeper.set(k[0], k[1] - kH * k[2], 1.15 * k[2]); keeper.rot(th, 50, 55); keeper.depth(1); kShadow.setAttribute('cx', r2(k[0])); kShadow.setAttribute('cy', r2(k[1])); kShadow.setAttribute('rx', r2(0.36 * k[2] * (1 - 0.35 * Math.min(1, kH))));
        const kk = P(kick.wx, 0, kick.wz); kick.set(kk[0], kk[1], KS * kk[2]); kick.depth(3); pShadow.setAttribute('cx', r2(kk[0])); pShadow.setAttribute('cy', r2(kk[1])); pShadow.setAttribute('rx', r2(0.24 * kk[2])); }
      function resetShot() { ball = { x: B0[0], y: B0[1], z: B0[2], vx: 0, vy: 0, vz: 0, st: 'rest', spin: 0 }; kick.wx = RUN0[0]; kick.wz = RUN0[1]; kx = 0; kH = 0; th = 0; dv = null; keeper.play('idle'); kick.play('idle'); phase = 'aim'; outcome = null; shotS = null; wind = 0; trail = []; trailG.innerHTML = '';
        skill = 0.3 + shot * 0.12; ctx.timer('Kick ' + (shot + 1) + '/5'); drawDots(); }
      // ---------- the ball's physics (the same step for the aim path and the kick you then see) ----------
      function stepB(b, h, t, out) { const pz = b.z; b.vy -= G * h; b.x += b.vx * h; b.y += b.vy * h; b.z += b.vz * h;
        if (b.y < BR) { if (out && Math.abs(b.vy) > 1.2) out.ev.push([t, 'bounce']); b.y = BR; b.vy = Math.abs(b.vy) * 0.45; b.vx *= 0.8; b.vz *= 0.8; }
        if (out && !out.tK && pz < KZ && b.z >= KZ) { out.tK = t; out.kAt = [b.x, b.y]; }
        if (b.st === 'fly' && pz < GZ && b.z >= GZ) { const ax = Math.abs(b.x); if (out) out.cross = [b.x, b.y];
          if (Math.abs(ax - GW) < BR + 0.05 && b.y < GH + 0.06 || Math.abs(b.y - GH) < BR + 0.05 && ax < GW + 0.06) { b.vz = -Math.abs(b.vz) * 0.5; b.vx += (ax < GW ? -1 : 1) * Math.sign(b.x) * 1.4; b.st = 'out'; if (out) { out.ev.push([t, Math.abs(b.y - GH) < 0.2 ? 'bar' : 'post']); out.res = 'wood'; out.tEnd = t + 0.3; } }
          else if (ax < GW && b.y < GH) { b.st = 'net'; if (out) { out.ev.push([t, 'goal']); out.res = 'goal'; out.tEnd = t + 0.12; } }
          else { b.st = 'out'; if (out) { out.ev.push([t, b.y >= GH ? 'over' : 'wide']); out.res = b.y >= GH ? 'over' : 'wide'; out.tEnd = t + 0.22; } } }
        if (b.st === 'net') { if (b.z > GZ + 0.7) { b.z = GZ + 0.7; b.vz = -0.3; b.vx *= 0.3; } if (Math.abs(b.x) > GW - 0.12) { b.x = Math.sign(b.x) * (GW - 0.12); b.vx *= -0.3; } if (b.y > GH - 0.12) { b.y = GH - 0.12; b.vy = -Math.abs(b.vy) * 0.3; } } }
      // a kick with pull k (0..1, = how high it crosses the line) and aim a (-1.2..1.2, + = right): its whole flight + events
      function sim(k, a) { const X = a * 2.4, Y = 0.15 + k * 2.35, T = 0.88 - 0.2 * k, dz = GZ + 0.05 - B0[2], b = { x: B0[0], y: B0[1], z: B0[2], vx: (X - B0[0]) / T, vz: dz / T, vy: (Y - B0[1] + 0.5 * G * T * T) / T, st: 'fly' };
        const out = { pos: [], ev: [], k, a, res: null, cross: null, tEnd: 1.3, tK: 0, kAt: null }, n = Math.round(LIFE / DT); for (let i = 0; i <= n; i++) { out.pos.push([b.x, b.y, b.z]); stepB(b, DT, i * DT, out); } return out; }
      const posAt = (S1, t) => { const f = cl(t / DT, 0, S1.pos.length - 1.001), i = Math.floor(f), u = f - i, A = S1.pos[i], B = S1.pos[i + 1]; return [lerp(A[0], B[0], u), lerp(A[1], B[1], u), lerp(A[2], B[2], u)]; };
      // ---------- aiming: the pull, the band, the simulated path (white: the keeper is not in it) ----------
      function pullOf(d) { const len = Math.hypot(d.x, d.y); if (d.y < 6 || len < 16) return null; return { k: cl((len - 16) / PULL, 0, 1), a: cl(-d.x / Math.max(60, d.y) * 0.9, -1.2, 1.2) }; }
      function drawPath(S1) { pathG.innerHTML = ''; bandG.innerHTML = ''; if (!aim) return;
        if (S1) { let lx = -1e9, ly = 0; for (let t = 0.02; t <= S1.tEnd; t += 1 / 240) { const p = posAt(S1, t), s = P(p[0], p[1], p[2]); if (Math.hypot(s[0] - lx, s[1] - ly) < 11) continue; lx = s[0]; ly = s[1];   // a dot every ~11 px on screen
            const r = cl(3.4 * s[2] / 150, 1.8, 3.6); S('circle', { cx: r2(s[0]), cy: r2(s[1]), r: r2(r + 1.1), fill: '#1e1430', opacity: 0.3 }, pathG); S('circle', { cx: r2(s[0]), cy: r2(s[1]), r: r2(r), fill: '#ffffff' }, pathG); }
          if (S1.cross) { const c = P(S1.cross[0], S1.cross[1], GZ), r = BR * c[2] + 3; S('circle', { cx: r2(c[0]), cy: r2(c[1]), r: r2(r + 1.2), fill: 'none', stroke: '#1e1430', 'stroke-width': 3.6, opacity: 0.25 }, pathG); S('circle', { cx: r2(c[0]), cy: r2(c[1]), r: r2(r), fill: 'none', stroke: '#ffffff', 'stroke-width': 2.4, opacity: 0.95 }, pathG); }
          S('path', { d: 'M' + r2(aim.x0) + ' ' + r2(aim.y0) + 'L' + r2(aim.x) + ' ' + r2(aim.y), stroke: '#ffffff', 'stroke-width': 3, 'stroke-dasharray': '2 6', 'stroke-linecap': 'round', opacity: 0.8 }, bandG); }
        S('circle', { cx: r2(aim.x0), cy: r2(aim.y0), r: 6, fill: 'none', stroke: '#ffffff', 'stroke-width': 2.4, opacity: S1 ? 0.85 : 0.6 }, bandG);
        if (S1) S('circle', { cx: r2(aim.x), cy: r2(aim.y), r: 9, fill: '#5cc2ff', stroke: '#ffffff', 'stroke-width': 2.4, opacity: 0.95 }, bandG); }
      // ---------- the keeper's dive plan ----------
      // body model (world, on his plane): pivot = (kx, kH + 0.44) (the rig turns about 55% of its 1.15 box); up axis (sin th, cos th); the body from
      //  pivot - 0.44 up to pivot + 0.62 up, ~0.4 round; the extended paw 0.7 from the pivot at angle phi (left paw: phi = 180 - th, right: -th)
      const D2R = Math.PI / 180, PIV = 0.44, REACH = 0.7;
      const pivOf = (x, h) => [x, h + PIV], pawOf = (pv, s, t) => { const ph = (s < 0 ? 180 - t : -t) * D2R; return [pv[0] + Math.cos(ph) * REACH, pv[1] + Math.sin(ph) * REACH]; };
      function segD(p, a, b) { const vx = b[0] - a[0], vy = b[1] - a[1], u = cl(((p[0] - a[0]) * vx + (p[1] - a[1]) * vy) / (vx * vx + vy * vy), 0, 1); return Math.hypot(p[0] - a[0] - vx * u, p[1] - a[1] - vy * u); }
      function clear(bp, x, h, t, s) { const pv = pivOf(x, h), u = [Math.sin(t * D2R), Math.cos(t * D2R)], a = [pv[0] - u[0] * PIV, pv[1] - u[1] * PIV], b = [pv[0] + u[0] * 0.62, pv[1] + u[1] * 0.62];
        return Math.min(segD(bp, a, b) - 0.4, s ? Math.hypot(bp[0] - pawOf(pv, s, t)[0], bp[1] - pawOf(pv, s, t)[1]) - 0.12 : 9) - BR; }
      // the dive that puts paw s on the ball at bp: [x, h, th] or null if he can't get there
      function reachFor(bp, s) { const dy = cl(bp[1] - cl(bp[1] - 0.12, PIV + 0.06, 1.34), -0.5, 0.38), dx = s * Math.sqrt(REACH * REACH - dy * dy), pv = [bp[0] - dx, bp[1] - dy], phi = Math.atan2(dy, dx) / D2R;
        let t = s < 0 ? 180 - phi : -phi; t = ((t + 540) % 360) - 180; const h = pv[1] - PIV; if (Math.abs(t) > 56 || h < -0.01 || h > 0.92 || Math.abs(pv[0] - kx0) > 1.45) return null; return [pv[0], Math.max(0, h), t]; }
      function plan(S1) { const tK = S1.tK || 0.7, bp = S1.kAt || [S1.a * 2.2, 0.8], onT = S1.res === 'goal', side = Math.abs(bp[0] - kx0) < 0.32 ? 0 : Math.sign(bp[0] - kx0);
        const corner = cl((Math.abs(bp[0]) - 0.9) / 0.9, 0, 1) * 0.5 + cl((bp[1] - 1.1) / 0.6, 0, 1) * 0.35, read = Math.random() < skill;
        let p = null;
        if (read && side) { const r = reachFor(bp, side); if (r && Math.random() > corner) p = { kind: 'save', s: side, x: r[0], h: r[1], t: r[2] };
          else { const r2_ = r || reachFor([kx0 + side * 1.45 + side * REACH * 0.8, cl(bp[1], 0.3, 1.6)], side) || [kx0 + side * 1.1, 0.25, side * 30]; p = { kind: 'beaten', s: side, x: r2_[0] - side * 0.55, h: r2_[1], t: r2_[2] }; } }
        else if (read || Math.random() < 0.3) { p = { kind: 'stay', s: 0, x: kx0 + (bp[0] - kx0) * 0.3, h: cl(bp[1] - 0.9, 0.05, 0.55), t: 0 }; }   // stays big in the middle / goes straight up
        else { const s = Math.random() < 0.5 ? -1 : 1; p = { kind: 'guess', s, x: kx0 + s * 1.0, h: 0.22, t: s * 34 }; }
        // a dive that isn't meant to save must not touch the ball: slide it away; a guess / stay that ends in the way becomes a block
        if (p.kind !== 'save') { let c = clear(bp, p.x, p.h, p.t, p.s), n = 0; if (p.kind === 'beaten') { while (c < 0.12 && n++ < 12) { p.x -= p.s * 0.08; c = clear(bp, p.x, p.h, p.t, p.s); } }
          else if (c < 0.05) p.kind = 'block'; }
        if (!onT && p.kind === 'save') p.kind = 'tip';   // a save on a ball that was going wide / over: a fingertip touch
        p.tK = tK; p.bp = bp; p.t0 = 0.12 + Math.random() * 0.08; p.dur = Math.max(0.28, tK - p.t0); return p; }
      // the rig's real paw (or chest) on the stage -> world on the keeper's plane
      function rigPaw(s) { const I = keeper.I, w = I && I.W && (s < 0 ? I.W.pawL : s > 0 ? I.W.pawR : null), sz = keeper.size, left = keeper.x - sz / 2, top = keeper.y - sz * 0.93;
        const q = w && isFinite(w[0]) ? [left + w[0] / 100 * sz, top + w[1] / 100 * sz] : [left + sz * 0.5, top + sz * 0.55], o = [left + sz * 0.5, top + sz * 0.55], r = th * D2R, dx = q[0] - o[0], dy = q[1] - o[1];
        return toW(o[0] + dx * Math.cos(r) - dy * Math.sin(r), o[1] + dx * Math.sin(r) + dy * Math.cos(r), KZ); }
      // ---------- kicking ----------
      function release(k, a, S0) { if (phase !== 'aim') return; shotS = S0 && S0.k === k && S0.a === a ? S0 : sim(k, a); aim = null; drawPath(null); phase = 'run'; ph0 = tNow; runFrom = [kick.wx, kick.wz]; SFX.tap(); }
      function launch() { ball.st = 'fly'; ball.S = shotS; ball.tl = tNow; ball.fired = 0; ball.live = 0; ball.snap = null; kickT = tNow; SFX.thud(); setTimeout(SFX.whoosh, 40);
        const s = P(ball.x, ball.y, ball.z); ctx.burst(s[0], s[1] + 4, 'dust', 7, { v: 70, life: 0.6, layer: fxG }); ctx.burst(s[0], s[1], 'star', 6, { v: 150, life: 0.45, layer: fxG, col: '#fff6c8' });
        dv = plan(shotS); dv.at = tNow; dv.from = [kx, kH, th]; phase = 'fly'; }
      function settle(goal, txt, col) { if (outcome) return; outcome = goal ? 'goal' : 'miss'; res[shot] = goal ? 1 : 0; drawDots(); phase = 'after'; ph0 = tNow;
        if (goal) { let pts = 100; const corner = Math.abs(ball.x) > 1.2, top = ball.y > 1.25; if (corner) pts += 50; if (top) pts += 50; const g = P(ball.x, ball.y, GZ);
          ctx.add(pts, W / 2, H * 0.42, (corner && top ? 'Top corner! ' : corner ? 'Corner! ' : top ? 'Top shelf! ' : 'Goal! ') + '+' + pts, '#ffe36e'); ctx.burst(g[0], g[1], 'confetti', 22, { v: 170, layer: fxG }); SFX.score(); kick.play('happy'); keeper.play('surprised'); }
        else { ctx.toast(txt, W / 2, H * 0.42, col || '#ffffff', true); SFX.miss(); if (txt === 'Saved!') keeper.play('happy'); kick.play('surprised'); } }
      const kickKey = (k, a) => { if (phase === 'aim') release(k, a); return true; };
      const api = {
        start() { shot = 0; res.length = 0; ctx.setScore(0); aim = null; resetShot(); },
        down(p) { if (phase === 'aim') aim = { x0: p.x, y0: p.y, x: p.x, y: p.y, p: null, S: null }; },
        move(p) { if (aim) { aim.x = p.x; aim.y = p.y; } },
        up(p) { if (!aim) return; if (p) { aim.x = p.x; aim.y = p.y; } const pp = aim.force || pullOf({ x: aim.x - aim.x0, y: aim.y - aim.y0 }), S0 = aim.S; if (!pp || phase !== 'aim') { aim = null; drawPath(null); return; } release(pp.k, pp.a, S0); },
        key(k, dn) { if (!dn) return; if (k === 'ArrowUp' || k === ' ') return kickKey(0.3, 0); if (k === 'ArrowLeft') return kickKey(0.4, -0.55); if (k === 'ArrowRight') return kickKey(0.4, 0.55); },
        // for automated tests: aim (shows the path) / kick with a given pull k 0..1 + aim -1.2..1.2; the simulated outcome; force the keeper's skill
        _aim: (k, a) => { aim = { x0: W * 0.6, y0: H * 0.35, x: W * 0.6 - a * 60, y: H * 0.35 + 16 + k * PULL, force: { k, a }, S: null }; }, _shoot: (k, a) => { if (phase === 'aim') release(k, a == null ? 0 : a); },
        _sim: (k, a) => { const S1 = sim(k, a); return { res: S1.res, cross: S1.cross && S1.cross.map(v => +v.toFixed(2)), kAt: S1.kAt && S1.kAt.map(v => +v.toFixed(2)), tK: +S1.tK.toFixed(2) }; }, _skill: v => { skill = v; },
        _state: () => ({ phase, shot, res: res.slice(), ball: ball && [ball.x, ball.y, ball.z].map(v => +v.toFixed(2)), dive: dv && { kind: dv.kind, s: dv.s, x: +dv.x.toFixed(2), h: +dv.h.toFixed(2), t: +dv.t.toFixed(1) } }), _ready: () => phase === 'aim' && !aim,
        celebrate(st) { kick.play(st >= 2 ? 'happy' : 'idle'); },
        destroy() { aimL.remove(); ballL.remove(); },
        update(dt, t) { tNow = t; const ts = t - ph0;
          // ---- your creature: aim (wound up at the run-up spot), run, kick, follow through ----
          if (phase === 'aim') { let pp = null; if (aim) { pp = aim.force || pullOf({ x: aim.x - aim.x0, y: aim.y - aim.y0 }); aim.p = pp; aim.S = pp ? (aim.S && aim.S.k === pp.k && aim.S.a === pp.a ? aim.S : sim(pp.k, pp.a)) : null; drawPath(aim.S); }
            wind = lerp(wind, pp ? 0.35 + 0.65 * pp.k : 0, 1 - Math.pow(0.002, dt)); kick.wx = RUN0[0] - 0.08 * wind; kick.wz = RUN0[1] - 0.1 * wind; kick.yaw(160 + 6 * Math.sin(t / 900));
            kick.pose({ sq: 0.1 * wind, lean: -4 * wind, armL: 25 + 45 * wind, armR: 20 + 35 * wind, footR: 2 * wind }); }
          else if (phase === 'run') { const u = cl(ts / RUN, 0, 1), e = u < 0.85 ? u / 0.85 : 1; kick.wx = lerp(runFrom[0], KICKAT[0], SM(e) * 0.2 + e * 0.8); kick.wz = lerp(runFrom[1], KICKAT[1], SM(e) * 0.2 + e * 0.8); kick.yaw(lerp(150, 172, u));
            if (u < 0.82) { kick.pose({ lean: 4, sq: 0.02 }); kick.walk(dt * 1.7, 1, 160); }
            else { const v = (u - 0.82) / 0.18; kick.pose({ lean: lerp(4, -3, v), sq: 0.06 * v, footR: lerp(0, -4, v), armL: 40 * v, armR: 70 * v }); }   // plant + back-swing
            if (u >= 1) { launch(); ph0 = t; } }
          else { const kt = t - kickT; kick.pose(track([[0, { lean: 9, sq: -0.06, footR: 9, armL: 70, armR: -10 }], [140, { lean: 6, sq: 0.03, footR: 6, armL: 80, armR: 20 }], [520, { lean: 0, sq: 0, footR: 0, armL: 0, armR: 0 }]], kt)); kick.yaw(172); }
          // ---- the keeper: idle sway, then the planned dive, the landing ----
          let KE = { armL: 40 + 10 * Math.sin(t / 300), armR: 40 + 10 * Math.sin(t / 300 + 1), sq: 0.06 + 0.02 * Math.sin(t / 150), lean: Math.sin(t / 700) * 3 };
          if (!dv) { kx0 = kx = Math.sin(t / 800) * 0.22; kH = 0; th = 0; }
          else { const tt = (t - dv.at) / 1000, u = cl((tt - dv.t0) / dv.dur, 0, 1), e = SM(u), f = cl((tt - dv.tK) / 0.38, 0, 1), side = dv.s;
            kx = lerp(dv.from[0], dv.x, e) + side * 0.18 * f; kH = (u < 1 ? dv.h * Math.sin(e * Math.PI / 2) : dv.h * (1 - f * f)) * (dv.kind === 'stay' || dv.kind === 'block' ? 1 : 1);
            th = side ? lerp(0, dv.t, e) + (side * 72 - dv.t) * SM(f) * (dv.h > 0.12 || Math.abs(dv.t) > 20 ? 1 : 0) : 0;
            const ext = side < 0 ? { armL: 130, armR: 150, hLx: -14 * e, hLy: -28 * e, footR: 5 * e } : side > 0 ? { armR: 130, armL: 150, hRx: 14 * e, hRy: -28 * e, footL: 5 * e } : { armL: 165 * e, armR: 165 * e, footL: 3 * e, sq: -0.05 * e };
            KE = Object.assign(ext, outcome === 'goal' && f > 0.5 ? { open: 1, cross: 0.6 } : outcome === 'miss' && f > 0.6 ? { smile: 1, hap: 0.8 } : { teary: e, open: e });
            if (tt > dv.t0 && tt < dv.tK + 0.1 && t > dropAt) { dropAt = t + 110; const hp = keeper.y - keeper.size * 0.8; ctx.burst(keeper.x + (Math.random() - 0.5) * keeper.size * 0.5, hp, 'drop', 1, { v: 50, life: 0.5, layer: fxG }); } }
          keeper.pose(KE); place();
          // ---- the ball: the simulated kick played back (its events fire as they come) until the keeper gets to it ----
          if (ball.S && !ball.live) { const tt = (t - ball.tl) / 1000, p = posAt(ball.S, tt); ball.x = p[0]; ball.y = p[1]; ball.z = p[2]; ball.spin = tt * 16;
            const touch = dv && (dv.kind === 'save' || dv.kind === 'tip' || dv.kind === 'block');
            if (touch && !outcome) { const lead = dv.tK - tt; if (lead < 0.11) { if (!ball.snap) ball.snap = rigPaw(dv.kind === 'block' ? 0 : dv.s); const sn = rigPaw(dv.kind === 'block' ? 0 : dv.s), w = SM(1 - Math.max(0, lead) / 0.11); ball.x = lerp(ball.x, sn[0], w); ball.y = lerp(ball.y, sn[1], w); }
              if (tt >= dv.tK) { const bz = ball.z; ball.live = 1; ball.z = KZ - 0.02; ball.vz = -2.2 - Math.random(); ball.vx = (dv.s || (Math.random() < 0.5 ? -1 : 1)) * (1.6 + Math.random()); ball.vy = dv.kind === 'tip' ? 3.2 : 2.2; ball.st = 'out';
                settle(false, 'Saved!', '#8fe0ff'); SFX.thud(); const s = P(ball.x, ball.y, ball.z); ctx.burst(s[0], s[1], 'star', 7, { v: 120, life: 0.4, layer: fxG, col: '#ffffff' }); } }
            while (!ball.live && ball.fired < ball.S.ev.length && ball.S.ev[ball.fired][0] <= tt) { const e = ball.S.ev[ball.fired++][1];
              if (e === 'goal') { ball.st = 'net'; bulge = { x: ball.x, y: ball.y, a: 1, t }; SFX.swish(); settle(true); }
              else if (e === 'post' || e === 'bar') { ball.st = 'out'; SFX.clang(); settle(false, e === 'bar' ? 'Off the bar!' : 'Off the post!'); }
              else if (e === 'wide' || e === 'over') { ball.st = 'out'; settle(false, e === 'over' ? 'Over the bar!' : 'Wide!'); }
              else if (e === 'bounce' && t > quietAt) { SFX.thud(); quietAt = t + 150; } } }
          else if (ball.live) { const n = 3; for (let i = 0; i < n; i++) stepB(ball, dt / n, 0, null); ball.spin += dt * 14; }
          drawNet(t);
          // ---- ball drawing: in front of the keeper until it passes him, then under him, then behind the posts in the goal; a fading trail ----
          const s = P(ball.x, ball.y, ball.z), r = BR * s[2], inG = ball.z > GZ - 0.02, front = ball.z < KZ - 0.02;
          if (inG) { if (bG.parentNode !== ballSlotBack) ballSlotBack.appendChild(bG); } else if (bG.parentNode !== ballSlot) ballSlot.appendChild(bG);
          ballL.style.zIndex = front ? 2 : 0;
          bC.setAttribute('cx', r2(s[0])); bC.setAttribute('cy', r2(s[1])); bC.setAttribute('r', r2(r)); const sp = ball.spin; let pd = ''; for (let i = 0; i < 5; i++) { const a = sp + i * 1.2566; pd += (i ? 'L' : 'M') + r2(s[0] + Math.cos(a) * r * 0.42) + ' ' + r2(s[1] + Math.sin(a) * r * 0.42); } bP.setAttribute('d', pd + 'Z');
          const g0 = P(ball.x, 0, ball.z), hk = cl(1 - ball.y / 2.5, 0.3, 1); bShadow.setAttribute('cx', r2(g0[0])); bShadow.setAttribute('cy', r2(g0[1])); bShadow.setAttribute('rx', r2(BR * g0[2] * 1.2 * hk)); bShadow.setAttribute('ry', r2(BR * g0[2] * 0.35 * hk));
          if (ball.S && !inG && (t - ball.tl) < 1400) trail.push([s[0], s[1], r, t]); trail = trail.filter(q => t - q[3] < 170); trailG.innerHTML = '';
          if (trail.length > 1) { let d = ''; trail.forEach((q, i) => { d += (i ? 'L' : 'M') + r2(q[0]) + ' ' + r2(q[1]); }); const rr = trail[trail.length - 1][2]; S('path', { d, fill: 'none', stroke: '#ffffff', 'stroke-width': r2(rr * 1.5), 'stroke-linecap': 'round', 'stroke-linejoin': 'round', opacity: 0.35 }, trailG); S('path', { d, fill: 'none', stroke: '#ffffff', 'stroke-width': r2(rr * 0.6), 'stroke-linecap': 'round', opacity: 0.6 }, trailG); }
          if (phase === 'after' && ts > 1900) { shot++; if (shot >= 5) { phase = 'done'; const g = res.filter(Boolean).length; ctx.finish({ sub: g + '/5 goals vs ' + kpName }); } else resetShot(); }
        } };
      resetShot(); place(); drawNet(0); return api;
    } });
  }; go();
})();
