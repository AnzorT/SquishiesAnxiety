// Yard Mini Games: INTRO SCREENS (Nov 17, user: 'each mini game needs to have his intro screen (no animations needed, just a cool looking image)').
// One still poster per game, drawn in SVG on the game's 360 x 640 stage: the game's title logo, its backyard object up big and close, and the player's own
// creature as a sticker (white cut-out edge + soft shadow) in the middle of the action. yard-games.js (v2) intro() shows it full screen with the how-to
// sheet + Play over its lower part, so everything that matters sits in the top ~58% (y < 370); the ground / backdrop carries on under the sheet.
// window.YardGames.POSTER[gameId](uid, { src: creature image, name }) -> '<svg ...>'.
// Nov 17 (user: 'for the intro thing use the characters in their 3rd model'): the creature is your real rig drawn in look 3 (bold line in the house's brown
//  ink, rive-rig v1117a mount option look: 3) in a pose that fits the game (ext channels: arms up after the shot, arms out on the hopscotch...): stk() leaves an
//  empty sticker group, YardGames.posterRig(el, key) mounts the rig off screen, moves its <svg> into that group, lets it settle (~0.9 s, fading in from 0.25 s)
//  and then destroys the rig so the drawing stays as a still. Without RiveRig (or if the mount fails) the group gets the creature's flat card art instead.
// Nov 17 (user: 'give me a proper character image that matches the body movement according to what it's doing' + 'remove the white border behind the
//  character'): each poster poses the rig like the house's own backyard animations at their action moment (house-cx.js: the hoop follow-through on its
//  toes, the kick with the leg up, the bean-bag toss, the ping-pong smash wind-up, the one-foot hop, arms up on the trampoline, sitting arms-up on the slide),
//  a held prop (the ping-pong paddle) is placed on the rig's own paw (I.W.pawR, rig units) after it settles, and the sticker edge is gone (no white cut-out,
//  no drop shadow: the look-3 ink line carries the creature; each poster keeps its ground shadow).
// Nov 17 (Slide & Splash became the sled-run game, user: 'like in club penguin with the sledding game', 'they dont need to be on sleds'): the slide poster
//  is now the game's own view: the giant rainbow slide running diagonally down the yard, your creature sliding down it on its bottom with its arms up
//  (yaw 58 like in the game), the gold arrows + a splash slick under it, a gnome dodged behind, the end tilting up and the pool's big splash past the lip.
// Nov 17 (user: 'for ping pong we need two characters, our character faces with the back to us and the other character facing us'): a creature slot can
//  be the game's opponent (data-who="opp": the opponent the game picked, from yard-games c.opp = inst.oppKey, else one from the games' pool) and can be turned
//  (data-yaw: 180 = its back to us); the Ping-Pong poster is now the rally seen from behind your creature, the other player facing you across the table.
// Nov 17 v7 (user: 'the penalty kick needs a rework of the intro image: a character kicking the ball and another character trying to catch the ball
//  with a "stress" look'): landscape-native (wrapL); your creature bottom left mid-kick (a swoosh + an impact burst at its foot, the ball's dotted trail
//  up to the top left corner), the opponent leaping across the goal with one arm flung at the ball (hLx/hLy stretch it out), the other paw by its cheek,
//  wide teary eyes + mouth open, sweat drops, shock lines and a !! burst; airborne, its shadow on the goal line.
(function () {
  const go = () => { const YG = window.YardGames; if (!YG || !YG.add) return setTimeout(go, 30);
  const TAU = Math.PI * 2, f = v => Math.round(v * 10) / 10, esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  // ---------- helpers ----------
  const lg = (id, x2, y2, stops) => '<linearGradient id="' + id + '" x1="0" y1="0" x2="' + x2 + '" y2="' + y2 + '">' + stops.map(([o, c, a]) => '<stop offset="' + o + '" stop-color="' + c + '"' + (a != null ? ' stop-opacity="' + a + '"' : '') + '/>').join('') + '</linearGradient>';
  const rg = (id, cx, cy, r, stops) => '<radialGradient id="' + id + '" cx="' + cx + '" cy="' + cy + '" r="' + r + '">' + stops.map(([o, c, a]) => '<stop offset="' + o + '" stop-color="' + c + '"' + (a != null ? ' stop-opacity="' + a + '"' : '') + '/>').join('') + '</radialGradient>';
  // a sunburst behind the action
  const rays = (cx, cy, n, col, op, a0) => { let d = ''; for (let i = 0; i < n; i++) { const a = (a0 || 0) + i / n * TAU, b = a + TAU / n / 2; d += 'M' + cx + ' ' + cy + 'L' + f(cx + Math.cos(a) * 1100) + ' ' + f(cy + Math.sin(a) * 1100) + 'L' + f(cx + Math.cos(b) * 1100) + ' ' + f(cy + Math.sin(b) * 1100) + 'Z'; } return '<path d="' + d + '" fill="' + col + '" opacity="' + op + '"/>'; };
  // a 4-point twinkle
  const spark = (x, y, r, col, op) => '<path transform="translate(' + f(x) + ' ' + f(y) + ') scale(' + r + ')" d="M0 -1C0.13 -0.3 0.3 -0.13 1 0C0.3 0.13 0.13 0.3 0 1C-0.13 0.3 -0.3 0.13 -1 0C-0.3 -0.13 -0.13 -0.3 0 -1Z" fill="' + (col || '#ffffff') + '"' + (op != null ? ' opacity="' + op + '"' : '') + '/>';
  // a puffy cloud
  const cloud = (x, y, k, op) => '<g transform="translate(' + x + ' ' + y + ') scale(' + k + ')" fill="#ffffff" opacity="' + (op || 0.95) + '"><circle cx="-26" cy="4" r="18"/><circle cx="0" cy="-8" r="25"/><circle cx="27" cy="2" r="19"/><circle cx="10" cy="10" r="18"/><circle cx="-12" cy="11" r="16"/></g>';
  // speed lines: tapered strokes pointing back along a direction
  const speed = (x, y, ang, n, len, col, op) => { let s = ''; const ca = Math.cos(ang), sa = Math.sin(ang); for (let i = 0; i < n; i++) { const o = (i - (n - 1) / 2) * 11, l = len * (0.6 + 0.4 * ((i * 37) % 10) / 10), bx = x - sa * o - ca * (14 + (i % 2) * 8), by = y + ca * o - sa * (14 + (i % 2) * 8);
      s += '<path d="M' + f(bx) + ' ' + f(by) + 'L' + f(bx - ca * l) + ' ' + f(by - sa * l) + '" stroke="' + (col || '#ffffff') + '" stroke-width="' + (i % 2 ? 3 : 4.5) + '" stroke-linecap="round" opacity="' + (op || 0.8) + '"/>'; } return s; };
  // the title: chunky letters with a gradient face, a thick ink outline and a dark extrusion under it
  function logo(u, lines, x, y, o) {
    const id = u + 'lg', lh = o.lh || 54; let s = '<g transform="translate(' + x + ' ' + y + ') rotate(' + (o.rot || 0) + ')" font-family="Fredoka, Nunito, system-ui, sans-serif" font-weight="700" text-anchor="middle" stroke-linejoin="round" letter-spacing="' + (o.ls || 0.5) + '">';
    lines.forEach((t, i) => { const z = (o.sizes || [])[i] || o.size || 50, yy = (o.ys || [])[i] != null ? o.ys[i] : i * lh;
      s += '<text y="' + f(yy + z * 0.1) + '" font-size="' + z + '" fill="' + o.shade + '" stroke="' + o.shade + '" stroke-width="' + f(z * 0.32) + '">' + esc(t) + '</text>'
        + '<text y="' + f(yy) + '" font-size="' + z + '" fill="' + o.ink + '" stroke="' + o.ink + '" stroke-width="' + f(z * 0.2) + '">' + esc(t) + '</text>'
        + '<text y="' + f(yy) + '" font-size="' + z + '" fill="url(#' + id + ')">' + esc(t) + '</text>'; });
    return { defs: lg(id, 0, 1, [[0, o.hi || '#ffffff'], [0.42, o.top], [1, o.bot]]), body: s + '</g>' };
  }
  // the creature as a sticker: feet at (x, y), w wide, a white cut-out edge and a soft shadow (the filter is in every poster's defs)
  const stk = (u, src, x, y, w, rot, flip, pose, prop, who, yaw) => '<g transform="translate(' + f(x) + ' ' + f(y) + ') rotate(' + (rot || 0) + ')' + (flip ? ' scale(-1 1)' : '') + '"><g class="ygp-cr" style="opacity:0;transition:opacity .25s ease" data-w="' + w + '" data-src="' + esc(src) + '"' + (pose ? ' data-pose="' + esc(JSON.stringify(pose)) + '"' : '') + (who ? ' data-who="' + who + '"' : '') + (yaw ? ' data-yaw="' + yaw + '"' : '') + '></g>'
    + (prop ? '<g class="ygp-prop" data-at="' + prop.at + '" style="opacity:0;transition:opacity .25s ease">' + prop.svg + '</g>' : '') + '</g>';
  // the real rig, look 3, posed, turned into a still (see the header)
  const POOL = ['biscuit', 'pip', 'mallow', 'nimbo', 'ribbit', 'bao', 'mittens', 'sealy', 'frybo', 'poppy'];   // the same pool the games pick opponents from
  YG.posterRig = function (el, key0, o) { const R = window.RiveRig; o = o || {}; const SQ = window.SquishSquad, pool = SQ && SQ.ROSTER ? SQ.ROSTER.filter(c => c && (YG.SETS || ['snack', 'fruit', 'pet']).includes(c.set)).map(c => c.key) : POOL, opp = o.opp || (L => L[Math.floor(Math.random() * L.length)])(pool.filter(k => k !== key0));
    el.querySelectorAll('.ygp-cr').forEach(g => { const w = +g.dataset.w, key = g.dataset.who === 'opp' ? opp : key0, flatSrc = g.dataset.who === 'opp' ? '' : g.dataset.src, flat = () => { if (!flatSrc) return; if (!g.querySelector('image')) g.insertAdjacentHTML('beforeend', '<image href="' + esc(flatSrc) + '" x="' + f(-w / 2) + '" y="' + f(-w * 0.95) + '" width="' + w + '" height="' + w + '" preserveAspectRatio="xMidYMax meet"/>'); g.style.opacity = 1; };
      if (!R || !R.mount || !key) return flat();
      const host = document.createElement('div'); host.style.cssText = 'position:fixed;left:-5000px;top:0;width:' + w + 'px;height:' + w + 'px;pointer-events:none;'; document.body.appendChild(host);
      let C = null; try { C = R.mount(host, key, { fidgets: false, look: 3 }); } catch (e) { host.remove(); return flat(); }
      const I = C && C._I, svg = host.querySelector('svg'); if (!I || !svg) { try { C && C.destroy(); } catch (e) {} host.remove(); return flat(); }
      I.fidgets = false; I.ptr = null; I.blinkAt = 1e15; I.glAt = 1e15; I.blinkT = -1e9; if (g.dataset.pose) try { I.ext = JSON.parse(g.dataset.pose); } catch (e) {} if (g.dataset.yaw) I.spinOff = +g.dataset.yaw;
      if (I.shadow) I.shadow.style.display = 'none';
      svg.setAttribute('style', 'overflow:visible'); svg.setAttribute('x', f(-w / 2)); svg.setAttribute('y', f(-w * 0.93)); svg.setAttribute('width', w); svg.setAttribute('height', w); g.appendChild(svg);
      const prop = g.parentNode && [...g.parentNode.children].find(e => e.classList && e.classList.contains('ygp-prop')), hold = () => { if (!prop) return; const p = I.W && I.W[prop.dataset.at];   // a held prop on the paw (rig units -> this group)
          if (p) prop.setAttribute('transform', 'translate(' + f(-w / 2 + p[0] * w / 100) + ' ' + f(-w * 0.93 + p[1] * w / 100) + ')'); prop.style.opacity = 1; };
      const t0 = performance.now(), end = still => { if (still) hold(); else if (prop) prop.remove(); try { C.destroy(); } catch (e) {} host.remove(); if (!still) { svg.remove(); flat(); } };
      const wait = () => { const t = performance.now() - t0; if (!g.isConnected) return end(true);
        if (I.generic && !I.ready) { if (t > 8000) return end(false); return requestAnimationFrame(wait); }
        if (I.err) return end(false); I.blinkAt = 1e15; I.blinkT = -1e9; if (t > 250) { g.style.opacity = 1; hold(); } if (t < 900) return requestAnimationFrame(wait); end(true); };
      requestAnimationFrame(wait); }); };
  const STK = u => '<filter id="' + u + 'stk" x="-20%" y="-20%" width="140%" height="145%" color-interpolation-filters="sRGB"><feMorphology in="SourceAlpha" operator="dilate" radius="3.4" result="d"/><feFlood flood-color="#ffffff"/><feComposite in2="d" operator="in" result="w"/>'
    + '<feGaussianBlur in="d" stdDeviation="4"/><feOffset dy="6" result="b"/><feFlood flood-color="#2a1048" flood-opacity="0.32"/><feComposite in2="b" operator="in" result="sh"/><feMerge><feMergeNode in="sh"/><feMergeNode in="w"/><feMergeNode in="SourceGraphic"/></feMerge></filter>'
    + '<filter id="' + u + 'soft" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="5"/></filter>';
  // a starburst badge with a word on it ('SWISH!', 'GOAL!')
  function badge(x, y, r, word, rot, fill, ink, size) { let d = ''; for (let i = 0; i < 24; i++) { const a = i / 24 * TAU, rr = i % 2 ? r * 0.8 : r; d += (i ? 'L' : 'M') + f(x + Math.cos(a) * rr * 1.25) + ' ' + f(y + Math.sin(a) * rr * 0.82); }
    return '<g transform="rotate(' + rot + ' ' + x + ' ' + y + ')"><path d="' + d + 'Z" fill="' + ink + '" transform="translate(0 4)"/><path d="' + d + 'Z" fill="' + fill + '" stroke="' + ink + '" stroke-width="3.5" stroke-linejoin="round"/>'
      + '<text x="' + x + '" y="' + f(y + size * 0.36) + '" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="' + size + '" text-anchor="middle" fill="#ffffff" stroke="' + ink + '" stroke-width="' + f(size * 0.2) + '" stroke-linejoin="round" paint-order="stroke fill">' + word + '</text></g>'; }
  // the shared frame: defs + the poster body + a soft vignette, in a slice-fit svg the size of the stage
  // v4 landscape (Nov 17, user: 'all the games need to be horizontal'): the portrait posters keep their drawing (360 wide, everything that matters in
  //  y < 370) and are seen through a 780 x 360 window (x -40..740, y 16..376): the action lands on the left, beside the how-to sheet down the right; their
  //  sky / ground / fence rows are drawn wide (x -420..980) so the window is filled
  const wrap = (u, defs, body) => '<svg viewBox="-40 16 780 360" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs>' + STK(u) + rg(u + 'vig', '40%', '45%', '80%', [[0.6, '#000000', 0], [1, '#1a0830', 0.26]]) + defs + '</defs>' + body + '<rect x="-40" y="16" width="780" height="360" fill="url(#' + u + 'vig)" pointer-events="none"/></svg>';
  // v4 landscape (Nov 17, user: 'all the games need to be horizontal'): the same frame on the 780 x 360 stage; the how-to sheet covers the right 44%
  const wrapL = (u, defs, body) => '<svg viewBox="0 0 780 360" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs>' + STK(u) + rg(u + 'vig', '40%', '45%', '80%', [[0.6, '#000000', 0], [1, '#1a0830', 0.26]]) + defs + '</defs>' + body + '<rect width="780" height="360" fill="url(#' + u + 'vig)" pointer-events="none"/></svg>';
  // the backyard's picket fence + round trees, as a far backdrop row along y
  function backdrop(y, tint, op) { let s = '<g opacity="' + (op || 1) + '">'; [[-130, 0.85], [-60, 1.0], [24, 1.1], [92, 0.8], [276, 0.9], [340, 1.2], [430, 1.0], [500, 0.8], [600, 1.1], [690, 0.9]].forEach(([x, k]) => { s += '<g transform="translate(' + x + ' ' + y + ') scale(' + k + ')"><rect x="-4" y="-30" width="8" height="32" rx="3" fill="#8a5a34"/><circle cx="-14" cy="-40" r="18" fill="' + tint[0] + '"/><circle cx="13" cy="-42" r="20" fill="' + tint[0] + '"/><circle cx="0" cy="-58" r="22" fill="' + tint[1] + '"/></g>'; });
    s += '<rect x="-420" y="' + (y - 22) + '" width="1400" height="5" fill="#fff8ee"/><rect x="-420" y="' + (y - 10) + '" width="1400" height="5" fill="#fff8ee"/>';
    for (let x = -414; x < 980; x += 16) s += '<path d="M' + x + ' ' + (y + 2) + 'V' + (y - 26) + 'L' + (x + 5) + ' ' + (y - 31) + 'L' + (x + 10) + ' ' + (y - 26) + 'V' + (y + 2) + 'Z" fill="#fffaf2" stroke="#e8d8c2" stroke-width="1"/>';
    return s + '</g>'; }

  // ---------- HOOP SHOT: a sunset driveway, the ball dropping through the net, your creature down left after the shot ----------
  function hoop(u, c) {
    const L = logo(u, ['HOOP SHOT'], 180, 84, { size: 52, top: '#ffd25a', bot: '#ff7a2a', hi: '#fff6c8', ink: '#5a1e3c', shade: '#34102a', rot: -4 });
    const defs = L.defs + lg(u + 'sk', 0, 1, [[0, '#ff7a6a'], [0.45, '#ffad6a'], [1, '#ffe2a2']]) + lg(u + 'gd', 0, 1, [[0, '#efe6d8'], [1, '#c9bfae']])
      + rg(u + 'bl', '35%', '30%', '75%', [[0, '#ffbb80'], [0.55, '#f27a2c'], [1, '#a8400f']]) + rg(u + 'sun', '50%', '50%', '50%', [[0, '#fff6d0', 0.95], [0.5, '#ffe08a', 0.45], [1, '#ffd070', 0]])
      + lg(u + 'bd', 1, 1, [[0, '#ffffff'], [1, '#e6eefc']]) + lg(u + 'pl', 1, 0, [[0, '#2c2c36'], [0.45, '#5a5a6a'], [1, '#2c2c36']]);
    let b = '<rect x="-420" width="1400" height="640" fill="url(#' + u + 'sk)"/>' + rays(262, 222, 20, '#fff4cf', 0.2, 0.1) + '<circle cx="262" cy="222" r="150" fill="url(#' + u + 'sun)"/>';
    b += cloud(52, 150, 0.7, 0.55) + cloud(320, 120, 0.5, 0.45);
    // a far rooftop line + trees, warm and soft in the low sun
    b += '<path d="M-10 330V292L30 270L70 292V300L120 300V280L150 262L180 280V330Z" fill="#d97a6a" opacity="0.45"/>' + backdrop(338, ['#c9845e', '#d99468'], 0.55);
    // the driveway + the painted key in perspective
    b += '<path d="M-420 336H980V640H-420Z" fill="url(#' + u + 'gd)"/><path d="M-420 336H980" stroke="#d8cdbc" stroke-width="3"/>';
    b += '<path d="M188 336L246 336L330 640L104 640Z" fill="#ffffff" opacity="0.18"/><path d="M188 336L104 640M246 336L330 640" stroke="#ffffff" stroke-width="5" opacity="0.85"/><path d="M150 470Q217 436 284 470" fill="none" stroke="#ffffff" stroke-width="5" opacity="0.85"/>';
    // the hoop: pole, arm, backboard, back of the rim
    b += '<ellipse cx="322" cy="346" rx="34" ry="7" fill="#3a2a55" opacity="0.25"/><rect x="314" y="150" width="17" height="198" rx="5" fill="url(#' + u + 'pl)"/><path d="M322 176L304 190" stroke="#3a3a46" stroke-width="9" stroke-linecap="round"/>';
    b += '<g transform="rotate(-3 258 160)"><rect x="186" y="104" width="148" height="104" rx="9" fill="#2a2a36" transform="translate(4 5)" opacity="0.35"/><rect x="186" y="104" width="148" height="104" rx="9" fill="url(#' + u + 'bd)" stroke="#e8483c" stroke-width="6"/>'
      + '<path d="M196 116L240 116L210 196L196 196Z" fill="#ffffff" opacity="0.8"/><rect x="232" y="146" width="54" height="42" fill="none" stroke="#e8483c" stroke-width="5"/></g>';
    b += '<rect x="250" y="203" width="16" height="9" rx="2.5" fill="#b8481a"/><path d="M216 214A44 12 0 0 1 304 214" fill="none" stroke="#b8481a" stroke-width="7" stroke-linecap="round"/>';
    // the shot: a dotted arc from your creature's paws up and over into the rim
    b += '<path d="M132 226Q188 40 248 178" fill="none" stroke="#ffffff" stroke-width="5" stroke-dasharray="1 12" stroke-linecap="round" opacity="0.95"/>';
    b += spark(178, 118, 9) + spark(212, 138, 5) + spark(146, 160, 6);
    // the ball dropping through, then the net in front of it, then the front of the rim
    b += '<g transform="translate(260 202)"><circle r="26" fill="url(#' + u + 'bl)"/><path d="M-26 0H26M0 -26V26M-18 -18Q0 0 -18 18M18 -18Q0 0 18 18" stroke="#6e2c0c" stroke-width="2.4" fill="none" opacity="0.9"/><ellipse cx="-9" cy="-11" rx="9" ry="5.5" fill="#ffffff" opacity="0.35" transform="rotate(-30 -9 -11)"/></g>';
    let net = ''; for (let i = 0; i <= 10; i++) { const a = Math.PI * i / 10, x0 = 260 - Math.cos(a) * 44, y0 = 214 + Math.sin(a) * 12, x1 = 260 - Math.cos(a) * 26, y1 = 262 + Math.sin(a) * 6; net += 'M' + f(x0) + ' ' + f(y0) + 'L' + f(x1) + ' ' + f(y1); }
    for (let k = 1; k <= 3; k++) { const rr = 44 - k * 6, yy = 214 + k * 16; net += 'M' + f(260 - rr) + ' ' + yy + 'Q260 ' + f(yy + 13) + ' ' + f(260 + rr) + ' ' + yy; }
    b += '<path d="' + net + '" fill="none" stroke="#ffffff" stroke-width="2.4" stroke-linecap="round" opacity="0.95"/>';
    b += '<path d="M216 214A44 12 0 0 0 304 214" fill="none" stroke="#f27a2c" stroke-width="8" stroke-linecap="round"/><path d="M222 217A40 9 0 0 0 298 217" fill="none" stroke="#ffc28a" stroke-width="2" opacity="0.8"/>';
    b += badge(66, 168, 32, 'SWISH!', -10, '#46c0ff', '#1e3a7a', 19);
    // your creature, just after the throw, and a few sparks on the swish
    b += '<ellipse cx="94" cy="334" rx="64" ry="12" fill="#3a2a55" opacity="0.22"/>' + stk(u, c.src, 94, 338, 160, -4, false, { armL: 125, armR: 150, lift: 8, footL: 1.4, footR: 1.4, sq: -0.08, ly: -0.7, lx: 0.5, open: 0.5, smile: 0.3 });   // the follow-through, up on its toes
    b += spark(308, 240, 8, '#fff6c8') + spark(326, 212, 5, '#ffffff') + spark(204, 252, 6, '#fff6c8');
    return wrap(u, defs, b + L.body);
  }

  // ---------- PENALTY KICK (landscape; Nov 17, user: 'a rework of the intro image: a character kicking the ball and another character trying to catch the
  //  ball with a "stress" look'): your creature bottom left mid-kick (three-quarter towards the goal, leaning back, arm flung, foot up, a swoosh + an
  //  impact burst at the foot), the ball rocketing for the top corner on a trail, the keeper (the game's opponent) diving full stretch for it with a
  //  stressed face (squeezed >< eyes, mouth wide, a tear) + sweat drops, shock lines and a "!!" - all in the left 56% (the how-to sheet covers the right) ----------
  function soccer(u, c) {
    const L = logo(u, ['PENALTY KICK'], 214, 54, { size: 44, top: '#ffffff', bot: '#9fe0ff', hi: '#ffffff', ink: '#123a7a', shade: '#0a2050', rot: -3 });
    const defs = L.defs + lg(u + 'sk', 0, 1, [[0, '#3aaaf6'], [0.6, '#9fdcff'], [1, '#e6f8ff']]) + lg(u + 'gr', 0, 1, [[0, '#8fd86a'], [1, '#4e9e3c']]) + rg(u + 'bl', '36%', '30%', '72%', [[0, '#ffffff'], [0.65, '#eef0f6'], [1, '#a9aec0']])
      + rg(u + 'im', '50%', '50%', '50%', [[0, '#ffffff'], [0.45, '#fff3a0'], [1, '#ffd84a', 0]]) + '<clipPath id="' + u + 'bc"><circle r="20"/></clipPath>';
    const GX0 = 174, GX1 = 424, GY0 = 104, GY1 = 276, BX = 202, BY = 134;   // the goal mouth; the ball heading into its top left corner
    let b = '<rect width="780" height="360" fill="url(#' + u + 'sk)"/>' + rays(BX, BY, 26, '#ffffff', 0.15) + cloud(86, 120, 0.55, 0.7) + cloud(520, 66, 0.5, 0.65) + cloud(660, 120, 0.4, 0.6);
    b += backdrop(196, ['#4f9a3e', '#62ad4c'], 0.9);
    // the lawn, mowing stripes running to the goal, the goal line + the box
    b += '<path d="M-20 190H800V380H-20Z" fill="url(#' + u + 'gr)"/>'; for (let i = -6; i < 12; i++) { const x0 = 310 + i * 60; b += '<path d="M' + f(310 + (x0 - 310) * 0.4) + ' 190L' + f(310 + (x0 + 30 - 310) * 0.4) + ' 190L' + f(310 + (x0 + 30 - 310) * 2.4) + ' 380L' + f(310 + (x0 - 310) * 2.4) + ' 380Z" fill="#ffffff" opacity="0.07"/>'; }
    b += '<g fill="none" stroke="#ffffff" stroke-width="3.2" opacity="0.8" stroke-linejoin="round"><path d="M60 ' + GY1 + 'H560"/><path d="M150 ' + GY1 + 'L118 300H500L470 ' + GY1 + '"/><path d="M40 ' + GY1 + 'L-20 340"/></g><ellipse cx="300" cy="328" rx="7" ry="2.6" fill="#ffffff" opacity="0.9"/>';
    // the goal: net box (back panel up + right, mesh), shadow, the frame
    b += '<path d="M' + GX0 + ' ' + GY1 + 'L' + (GX0 + 22) + ' ' + (GY1 - 16) + 'H' + (GX1 + 22) + 'L' + GX1 + ' ' + GY1 + 'Z" fill="#2a4a20" opacity="0.18"/>';
    b += '<path d="M' + (GX0 + 22) + ' ' + (GY0 - 14) + 'H' + (GX1 + 22) + 'V' + (GY1 - 16) + 'H' + (GX0 + 22) + 'Z" fill="#ffffff" opacity="0.18"/><g stroke="#ffffff" stroke-width="1.3" opacity="0.7" fill="none">';
    for (let x = GX0 + 22; x <= GX1 + 22; x += 13) b += '<path d="M' + x + ' ' + (GY0 - 14) + 'V' + (GY1 - 16) + '"/>'; for (let y = GY0 - 14; y <= GY1 - 16; y += 13) b += '<path d="M' + (GX0 + 22) + ' ' + y + 'H' + (GX1 + 22) + '"/>';
    for (let k = 0; k <= 6; k++) { const y = GY0 + (GY1 - GY0) * k / 6; b += '<path d="M' + GX1 + ' ' + f(y) + 'L' + (GX1 + 22) + ' ' + f(y - 15) + '"/>'; } b += '<path d="M' + GX0 + ' ' + GY0 + 'L' + (GX0 + 22) + ' ' + (GY0 - 14) + 'M' + GX1 + ' ' + GY0 + 'L' + (GX1 + 22) + ' ' + (GY0 - 14) + '"/></g>';
    b += '<path d="M' + GX0 + ' ' + (GY1 + 2) + 'V' + GY0 + 'H' + GX1 + 'V' + (GY1 + 2) + '" fill="none" stroke="#3a4a6a" stroke-width="11" stroke-linejoin="round" opacity="0.3" transform="translate(3 4)"/><path d="M' + GX0 + ' ' + (GY1 + 2) + 'V' + GY0 + 'H' + GX1 + 'V' + (GY1 + 2) + '" fill="none" stroke="#ffffff" stroke-width="10" stroke-linejoin="round"/><path d="M' + (GX0 + 3) + ' ' + (GY1 + 1) + 'V' + (GY0 + 3) + 'H' + (GX1 - 3) + 'V' + (GY1 + 1) + '" fill="none" stroke="#dfe6f2" stroke-width="2.4"/>';
    // the keeper (the other player): leaping across, one arm flung out at the ball, the other paw up by its cheek - panicking (wide teary eyes,
    //  mouth wide open) + sweat drops, shock lines, a !! burst; airborne (its shadow on the goal line below)
    const KX = 328, KY = 226, KW = 150, KR = -12, hx = KX - 0.55 * KW * Math.sin(-KR * Math.PI / 180), hy = KY - 0.55 * KW * Math.cos(KR * Math.PI / 180);
    b += '<ellipse cx="' + (KX - 14) + '" cy="' + (GY1 - 2) + '" rx="46" ry="8" fill="#2a4a20" opacity="0.22"/>' + speed(KX + 30, KY - 70, Math.PI + 0.25, 3, 44, '#ffffff', 0.8);
    b += stk(u, '', KX, KY, KW, KR, false, { armL: 130, armR: 150, hLx: -14, hLy: -28, teary: 1, open: 1, footR: 5, lx: -1, ly: -1, sq: -0.04 }, null, 'opp');
    [[hx + 56, hy - 30, 7, 20], [hx + 66, hy - 6, 5.5, 34], [hx + 42, hy - 50, 4.5, 8]].forEach(([x, y, r, a]) => { b += '<path transform="translate(' + f(x) + ' ' + f(y) + ') rotate(' + a + ') scale(' + f(r / 6) + ')" d="M0 -9Q6 -1 6 3A6 6 0 0 1 -6 3Q-6 -1 0 -9Z" fill="#bfe8ff" stroke="#3f8fd0" stroke-width="1.6"/>'; });
    b += '<g stroke="#1d3a6a" stroke-width="3" stroke-linecap="round">' + [-118, -92, -66].map(d => { const t = d * Math.PI / 180; return '<path d="M' + f(hx + Math.cos(t) * 64) + ' ' + f(hy + Math.sin(t) * 64) + 'L' + f(hx + Math.cos(t) * 80) + ' ' + f(hy + Math.sin(t) * 80) + '"/>'; }).join('') + '</g>';
    b += badge(hx + 76, hy - 62, 19, '!!', 10, '#ff6f7a', '#7a1428', 20);
    // the ball rocketing at the top corner, its trail back to the kick
    b += '<path d="M150 296Q164 196 ' + (BX - 12) + ' ' + (BY + 14) + '" fill="none" stroke="#ffffff" stroke-width="7" stroke-linecap="round" stroke-dasharray="2 13" opacity="0.9"/>' + speed(BX, BY, -1.32, 5, 70, '#ffffff', 0.85);
    b += '<g transform="translate(' + BX + ' ' + BY + ') rotate(24)"><circle r="20" fill="url(#' + u + 'bl)" stroke="#5a6078" stroke-width="1.4"/><g clip-path="url(#' + u + 'bc)" fill="#2a2a3a">';
    const pent = (cx, cy, r, a) => { let d = ''; for (let i = 0; i < 5; i++) { const t = a + i / 5 * TAU; d += (i ? 'L' : 'M') + f(cx + Math.cos(t) * r) + ' ' + f(cy + Math.sin(t) * r); } return '<path d="' + d + 'Z"/>'; };
    b += pent(0, 0, 6.8, -Math.PI / 2); for (let i = 0; i < 5; i++) { const t = -Math.PI / 2 + (i + 0.5) / 5 * TAU; b += pent(Math.cos(t) * 19.5, Math.sin(t) * 19.5, 6.8, t + Math.PI); }
    b += '</g><g stroke="#2a2a3a" stroke-width="1.3">'; for (let i = 0; i < 5; i++) { const t = -Math.PI / 2 + i / 5 * TAU; b += '<path d="M' + f(Math.cos(t) * 6.8) + ' ' + f(Math.sin(t) * 6.8) + 'L' + f(Math.cos(t) * 13.5) + ' ' + f(Math.sin(t) * 13.5) + '"/>'; } b += '</g><ellipse cx="-7" cy="-9" rx="7" ry="4" fill="#ffffff" opacity="0.6" transform="rotate(-30 -7 -9)"/></g>';
    b += spark(BX - 30, BY - 28, 7) + spark(BX + 34, BY - 18, 5) + spark(440, 60, 6, '#fff6c8');
    // your creature, mid-kick: the swoosh round its foot + the impact burst where the ball left it
    const MX = 96, MY = 344;
    b += '<ellipse cx="' + (MX + 6) + '" cy="' + (MY - 2) + '" rx="62" ry="11" fill="#2a4a20" opacity="0.24"/>';
    b += '<circle cx="152" cy="300" r="34" fill="url(#' + u + 'im)"/><path d="M152 266L158 288L178 278L164 296L186 304L162 308L170 330L152 314L136 330L142 308L118 306L140 296L126 280L146 288Z" fill="#fff6c8" stroke="#ffb020" stroke-width="2" stroke-linejoin="round" opacity="0.95"/>';
    b += '<path d="M88 338Q118 346 140 324Q154 308 152 286" fill="none" stroke="#ffffff" stroke-width="9" stroke-linecap="round" opacity="0.75"/><path d="M96 330Q120 334 136 318" fill="none" stroke="#ffffff" stroke-width="4" stroke-linecap="round" opacity="0.9"/>';
    b += stk(u, c.src, MX, MY, 176, -8, false, { footR: 10, lean: 2, armL: 40, armR: 152, smile: 1, open: 0.6, hap: 0.7, tilt: -6, sq: -0.04 }, null, null, 50);
    return wrapL(u, defs, b + L.body);
  }

  // ---------- HOPSCOTCH: a chalk court on the sidewalk running off into the distance, your creature mid-hop ----------
  function hop(u, c) {
    const P = (x, z) => { const s = 1 / (1 + z * 0.2); return [f(150 + x * 118 * s), f(122 + 268 * s), s]; };   // the court a little left of centre, so your creature can hop in from the right
    const L = logo(u, ['HOPSCOTCH'], 180, 76, { size: 46, top: '#ffe0f2', bot: '#ff6fb8', hi: '#ffffff', ink: '#6a1a52', shade: '#3e0c30', rot: -3, ls: 1 });
    const defs = L.defs + lg(u + 'sk', 0, 1, [[0, '#ffb0d8'], [1, '#ffe6c8']]) + lg(u + 'pv', 0, 1, [[0, '#cfc6cc'], [1, '#a99ea6']])
      + '<filter id="' + u + 'ch" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="3" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="2.6" xChannelSelector="R" yChannelSelector="G" result="dd"/><feComposite in="dd" in2="n" operator="in"/></filter>';
    let b = '<rect x="-420" width="1400" height="640" fill="url(#' + u + 'sk)"/>' + rays(180, 118, 26, '#ffffff', 0.18);
    b += backdrop(122, ['#7cc06a', '#93d07c'], 0.75);
    // grass verges either side of the sidewalk, the paving slabs, their joints
    const q = (pts, a) => '<path d="M' + pts.map(p => p[0] + ' ' + p[1]).join('L') + 'Z" ' + a + '/>';
    b += '<path d="M-420 118H980V640H-420Z" fill="#7cc46a"/>' + q([P(-1.55, 40), P(1.55, 40), P(1.55, -1.2), P(-1.55, -1.2)], 'fill="url(#' + u + 'pv)"');
    for (let z = 0; z < 30; z += 1.6) { const a = P(-1.55, z), b2 = P(1.55, z); b += '<path d="M' + a[0] + ' ' + a[1] + 'L' + b2[0] + ' ' + b2[1] + '" stroke="#958a92" stroke-width="' + f(1.6 * a[2]) + '" opacity="0.7"/>'; }
    b += q([P(-1.55, 40), P(-1.45, 40), P(-1.45, -1.2), P(-1.55, -1.2)], 'fill="#e6dde2"') + q([P(1.45, 40), P(1.55, 40), P(1.55, -1.2), P(1.45, -1.2)], 'fill="#e6dde2"');
    // the court: 1 | 2 3 | 4 | 5 6 | 7 | 8 9 | 10 | home
    const cells = [[-0.5, 0.5, 0, 1, '1'], [-1, 0, 1, 2, '2'], [0, 1, 1, 2, '3'], [-0.5, 0.5, 2, 3, '4'], [-1, 0, 3, 4, '5'], [0, 1, 3, 4, '6'], [-0.5, 0.5, 4, 5, '7'], [-1, 0, 5, 6, '8'], [0, 1, 5, 6, '9'], [-0.5, 0.5, 6, 7, '10']];
    const tint = ['#ff9fd0', '#9fd8ff', '#fff09a', '#b6f0a0'];
    let ch = '';
    cells.forEach(([x0, x1, z0, z1, n], i) => { const a = P(x0, z0), b2 = P(x1, z0), cc = P(x1, z1), d = P(x0, z1), m = P((x0 + x1) / 2, (z0 + z1) / 2);
      ch += q([a, b2, cc, d], 'fill="' + tint[i % 4] + '" fill-opacity="0.32" stroke="#ffffff" stroke-width="' + f(4.2 * a[2]) + '" stroke-linejoin="round"');
      ch += '<text x="' + m[0] + '" y="' + f(m[1] + 9 * m[2]) + '" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="' + f(27 * m[2]) + '" text-anchor="middle" fill="' + ['#ff5fae', '#3aa8f0', '#f0b400', '#4cbf3a'][i % 4] + '" stroke="#ffffff" stroke-width="' + f(1.6 * m[2]) + '" paint-order="stroke fill">' + n + '</text>'; });
    { let d = ''; for (let i = 0; i <= 16; i++) { const t = Math.PI * i / 16, p = P(-Math.cos(t) * 0.75, 7 + Math.sin(t) * 0.9); d += (i ? 'L' : 'M') + p[0] + ' ' + p[1]; } const hm = P(0, 7.4); ch += '<path d="' + d + 'Z" fill="#d9b8ff" fill-opacity="0.35" stroke="#ffffff" stroke-width="2.4"/><text x="' + hm[0] + '" y="' + f(hm[1] + 4) + '" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="11" text-anchor="middle" fill="#9a5ae0" stroke="#ffffff" stroke-width="1" paint-order="stroke fill">HOME</text>'; }
    // chalk doodles on the slabs around it
    const d1 = P(-1.2, 0.9), d2 = P(1.2, 5.6), d3 = P(-1.25, 4.4), d4 = P(-1.25, 2.5);
    ch += '<path transform="translate(' + d1[0] + ' ' + d1[1] + ') scale(' + f(d1[2] * 1.3) + ')" d="M0 -13L3.8 -4.6L13 -4.2L5.8 1.6L8.2 10.6L0 5.4L-8.2 10.6L-5.8 1.6L-13 -4.2L-3.8 -4.6Z" fill="none" stroke="#fff09a" stroke-width="2.6" stroke-linejoin="round"/>';
    ch += '<path transform="translate(' + d2[0] + ' ' + d2[1] + ') scale(' + f(d2[2] * 1.3) + ')" d="M0 9C-14 0 -12 -12 -5 -11C-2 -10.5 0 -8 0 -6C0 -8 2 -10.5 5 -11C12 -12 14 0 0 9Z" fill="none" stroke="#ff9fd0" stroke-width="2.6" stroke-linejoin="round"/>';
    ch += '<g transform="translate(' + d3[0] + ' ' + d3[1] + ') scale(' + f(d3[2] * 1.2) + ')" fill="none" stroke="#9fd8ff" stroke-width="2.4" stroke-linecap="round"><circle r="6"/><path d="M0 -10V-14M0 10V14M-10 0H-14M10 0H14M7 -7L10 -10M-7 7L-10 10M7 7L10 10M-7 -7L-10 -10"/></g>';
    ch += '<g transform="translate(' + d4[0] + ' ' + d4[1] + ') scale(' + f(d4[2] * 1.2) + ')" fill="none" stroke="#b6f0a0" stroke-width="2.4" stroke-linecap="round"><path d="M-10 6Q0 -12 10 6"/><path d="M-6 6Q0 -4 6 6"/></g>';
    b += '<g filter="url(#' + u + 'ch)">' + ch + '</g>';
    // the pebble on 7, a piece of chalk on the side
    const pb = P(0.1, 4.55); b += '<ellipse cx="' + pb[0] + '" cy="' + f(pb[1] + 2) + '" rx="' + f(10 * pb[2]) + '" ry="' + f(4 * pb[2]) + '" fill="#4a3a48" opacity="0.3"/><ellipse cx="' + pb[0] + '" cy="' + pb[1] + '" rx="' + f(9 * pb[2]) + '" ry="' + f(6 * pb[2]) + '" fill="#8a7f92" stroke="#5a5064" stroke-width="1"/><ellipse cx="' + f(pb[0] - 2) + '" cy="' + f(pb[1] - 2) + '" rx="' + f(3 * pb[2]) + '" ry="' + f(1.6 * pb[2]) + '" fill="#ffffff" opacity="0.5"/>';
    const ck = P(-1.25, 0.2); b += '<g transform="translate(' + ck[0] + ' ' + ck[1] + ') rotate(-24)"><rect x="-14" y="-4.5" width="28" height="9" rx="4.5" fill="#ff9fd0"/><rect x="-14" y="-4.5" width="9" height="9" rx="4.5" fill="#ffffff" opacity="0.6"/></g>';
    // your creature mid-hop over 5-6, its shadow on the court, a puff of chalk dust under it
    const sh = P(1.22, 1.2); b += '<ellipse cx="' + sh[0] + '" cy="' + sh[1] + '" rx="' + f(52 * sh[2]) + '" ry="' + f(12 * sh[2]) + '" fill="#3a2040" opacity="0.25"/>';
    b += '<g fill="#ffffff" opacity="0.7"><circle cx="' + f(sh[0] - 40) + '" cy="' + f(sh[1] + 2) + '" r="6"/><circle cx="' + f(sh[0] - 50) + '" cy="' + f(sh[1] - 6) + '" r="4"/><circle cx="' + f(sh[0] + 44) + '" cy="' + f(sh[1] - 2) + '" r="5"/></g>';
    b += stk(u, c.src, sh[0], f(sh[1] - 40), 128, -8, false, { sq: -0.06, lift: 6, footL: 3, armL: 70, armR: 70, tilt: 2, smile: 0.5, open: 0.3 });   // a one-foot hop, arms out
    b += '<path d="M' + f(sh[0] - 52) + ' ' + f(sh[1] - 66) + 'q-10 14 -2 30M' + f(sh[0] + 54) + ' ' + f(sh[1] - 70) + 'q10 14 2 30" fill="none" stroke="#ffffff" stroke-width="3.5" stroke-linecap="round" opacity="0.85"/>';
    b += spark(60, 170, 7) + spark(318, 168, 6) + spark(226, 150, 4);
    return wrap(u, defs, b + L.body);
  }

  // ---------- BOUNCE UP: high in the sky above the trampoline, a twirl, the clouds below ----------
  function tramp(u, c) {
    const L = logo(u, ['BOUNCE UP!'], 180, 80, { size: 52, top: '#ffffff', bot: '#b9c2ff', hi: '#ffffff', ink: '#2a1f7a', shade: '#160f48', rot: -4 });
    const defs = L.defs + lg(u + 'sk', 0, 1, [[0, '#2e2f9a'], [0.38, '#6f78f0'], [0.75, '#a9cbff'], [1, '#dff0ff']]) + rg(u + 'gl', '50%', '50%', '50%', [[0, '#ffffff', 0.7], [1, '#ffffff', 0]])
      + lg(u + 'mt', 0, 1, [[0, '#3a3a4e'], [1, '#1e1e2a']]);
    let b = '<rect x="-420" width="1400" height="640" fill="url(#' + u + 'sk)"/>' + rays(180, 214, 24, '#ffffff', 0.1);
    // stars up high
    [[30, 40, 5], [76, 120, 3], [320, 46, 4], [286, 132, 3], [340, 186, 3], [24, 196, 3], [130, 26, 3], [232, 22, 4]].forEach(([x, y, r]) => { b += spark(x, y, r, '#fff8d0', 0.95); });
    // the height ribbon on the left: how far up you are
    b += '<g><rect x="12" y="150" width="20" height="230" rx="10" fill="#ffffff" opacity="0.25"/>'; for (let i = 0; i <= 10; i++) { const y = 372 - i * 21.5; b += '<path d="M14 ' + y + 'H' + (i % 5 ? 22 : 30) + '" stroke="#ffffff" stroke-width="' + (i % 5 ? 2 : 3) + '" opacity="0.85"/>'; }
    b += '<text x="36" y="160" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="13" fill="#ffffff">10 m</text><text x="36" y="268" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="13" fill="#ffffff" opacity="0.8">5 m</text></g>';
    b += cloud(296, 300, 0.95, 0.95) + cloud(70, 330, 0.8, 0.9) + cloud(188, 352, 1.1, 0.95) + cloud(318, 214, 0.45, 0.7);
    // the trampoline far below between the clouds
    b += '<g transform="translate(180 384)"><path d="M-92 4L-80 46M92 4L80 46M-30 16L-26 54M30 16L26 54" stroke="#2a2a3a" stroke-width="5" stroke-linecap="round"/><ellipse rx="104" ry="24" fill="#4f8fff"/><ellipse rx="104" ry="24" fill="none" stroke="#2f5fd0" stroke-width="3"/><ellipse rx="86" ry="18" fill="url(#' + u + 'mt)"/>'
      + '<path d="M-78 -2Q0 14 78 -2" fill="none" stroke="#ffffff" stroke-width="2" opacity="0.18"/></g>';
    // the way up: a dotted trail from the mat, then swirls round the creature (it's twirling)
    b += '<path d="M178 370Q160 300 176 250" fill="none" stroke="#ffffff" stroke-width="5" stroke-dasharray="1 12" stroke-linecap="round" opacity="0.9"/>';
    b += '<circle cx="180" cy="190" r="104" fill="url(#' + u + 'gl)"/>';
    b += '<g fill="none" stroke="#ffffff" stroke-linecap="round" opacity="0.9"><path d="M98 196A86 26 -14 0 0 268 158" stroke-width="5"/><path d="M106 226A80 22 -14 0 0 256 196" stroke-width="3.5" opacity="0.7"/></g>';
    b += stk(u, c.src, 182, 262, 156, 14, false, { armL: 150, armR: 150, hap: 1, open: 0.7, sq: -0.1, footL: 2, footR: 2 });   // arms up at the top of the bounce
    b += '<path d="M268 158A86 26 -14 0 0 98 196" fill="none" stroke="#ffffff" stroke-width="5" stroke-linecap="round" stroke-dasharray="0 120 140 400" opacity="0.9"/>';
    b += spark(270, 112, 9, '#fff6c8') + spark(96, 140, 7, '#ffffff') + spark(290, 250, 6, '#ffffff');
    return wrap(u, defs, b + L.body);
  }

  // ---------- SLIDE & SPLASH (landscape, the slide-run game; Nov 17 v4: a narrow chute up on posts at one level, the kiddie pool past the lip):
  //  the slide tower top left, the rainbow slide running diagonally down the yard like
  //  in the game, your creature whooshing down it on its bottom (arms up), gold arrows ahead, a splash slick + a gnome behind, the end tilting up and the
  //  pool's big splash past the lip - all in the left 56% (the how-to sheet covers the right side) ----------
  function slide(u, c) {
    const L = logo(u, ['SLIDE & SPLASH!'], 250, 54, { size: 44, top: '#ffffff', bot: '#7ff0e0', hi: '#ffffff', ink: '#0e4a6a', shade: '#072c44', rot: -3 });
    const A = 32 * Math.PI / 180, B = -24 * Math.PI / 180, FX = Math.cos(A), FY = Math.sin(A), LX = Math.cos(B), LY = Math.sin(B), HW = 44, OX = 196, OY = 208;
    const P = (s, l, h) => [OX + s * FX + l * HW * LX, OY + s * FY + l * HW * LY - (h || 0)], pt = q => f(q[0]) + ' ' + f(q[1]), pl = a => 'M' + a.map(pt).join('L') + 'Z';
    const S0 = -150, RS = 92, LE = 162, RH = 30, CH = 30, hr = s => CH + (s <= RS ? 0 : RH * Math.pow((s - RS) / (LE - RS), 2)), WH = 10;   // the chute up on posts at one level, the lip curving up at the end
    const bands = ['#ff7a8a', '#ffa95a', '#ffdc5a', '#7fd870', '#5cb8ff', '#a98bff'], ss = []; for (let s = S0; s <= LE + 0.1; s += (s < RS ? RS - S0 : (LE - RS) / 10)) ss.push(s);
    const defs = L.defs + lg(u + 'gr', 0, 1, [[0, '#a6e07e'], [1, '#5fae4a']]) + lg(u + 'wt', 0, 1, [[0, '#8fe0ff'], [1, '#3fa6e6']]) + rg(u + 'gd', '50%', '50%', '50%', [[0, '#fff6b0'], [1, '#ffd84a']]);
    let b = '<rect width="780" height="360" fill="url(#' + u + 'gr)"/>' + rays(400, 300, 26, '#ffffff', 0.12);
    // lawn: tufts + flowers, trees on the far side (top right of the slide)
    [[40, 300], [120, 330], [24, 236], [300, 120], [420, 160], [470, 118], [250, 336], [380, 210], [150, 270]].forEach(([x, y], i) => { b += '<path d="M' + (x - 5) + ' ' + y + 'l2 -8l3 6l3 -10l3 10l3 -7l2 9Z" fill="#4f9a3e" opacity="0.7"/>'; if (i % 2) for (let j = 0; j < 5; j++) b += '<circle cx="' + f(x + 12 + Math.cos(j * 1.2566) * 2.6) + '" cy="' + f(y - 4 + Math.sin(j * 1.2566) * 2.6) + '" r="2" fill="' + ['#ffd1e8', '#fff3a8', '#ffffff', '#d9c8ff'][i % 4] + '"/>'; });
    [[352, 176, 0.75], [430, 150, 0.95], [520, 120, 1.1]].forEach(([x, y, k]) => { b += '<ellipse cx="' + x + '" cy="' + (y + 2) + '" rx="' + f(34 * k) + '" ry="' + f(12 * k) + '" fill="#2d4a22" opacity="0.2"/><g transform="translate(' + x + ' ' + y + ') scale(' + k + ')"><rect x="-5" y="-38" width="10" height="40" rx="3" fill="#8a5a34"/><circle cx="-17" cy="-48" r="21" fill="#57a854"/><circle cx="15" cy="-50" r="23" fill="#57a854"/><circle cx="0" cy="-70" r="25" fill="#6cbb5c"/><circle cx="-7" cy="-76" r="10" fill="#8fd47a" opacity="0.8"/></g>'; });
    // the slide tower at the top of the slide (deck, posts, rails), behind everything else
    const T0 = S0 - 64, tH = CH, post = (s, l, h0, h1) => '<path d="M' + pt(P(s, l, h0)) + 'L' + pt(P(s, l, h1)) + '" stroke="#a89ad0" stroke-width="8.5" stroke-linecap="round"/><path d="M' + pt(P(s, l, h0)) + 'L' + pt(P(s, l, h1)) + '" stroke="#ffffff" stroke-width="6" stroke-linecap="round"/>';
    b += '<path d="' + pl([P(T0 - 8, -1.25, 0), P(S0 + 14, -1.25, 0), P(S0 + 14, 1.25, 0), P(T0 - 8, 1.25, 0)]) + '" fill="#2a3a20" opacity="0.15"/>' + post(T0, 1.15, 0, tH + 44) + post(S0, 1.15, 0, tH + 44) + post(T0, -1.15, 0, tH + 44);
    b += '<path d="' + pl([P(T0, -1.15, tH), P(S0, -1.15, tH), P(S0, 1.15, tH), P(T0, 1.15, tH)]) + '" fill="#c9b8f2" stroke="#a89ad0" stroke-width="1.5"/><path d="' + pl([P(T0, -1.15, tH - 8), P(S0, -1.15, tH - 8), P(S0, -1.15, tH), P(T0, -1.15, tH)]) + '" fill="#cfc6ec"/>';
    [22, 42].forEach(h => { b += '<path d="M' + pt(P(T0, -1.15, tH + h)) + 'L' + pt(P(T0, 1.15, tH + h)) + 'L' + pt(P(S0, 1.15, tH + h)) + '" stroke="#a89ad0" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M' + pt(P(T0, -1.15, tH + h)) + 'L' + pt(P(T0, 1.15, tH + h)) + 'L' + pt(P(S0, 1.15, tH + h)) + '" stroke="#ffffff" stroke-width="3.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'; });
    const fp = P(T0, -1.15, tH + 44); b += '<path d="M' + pt(fp) + 'V' + f(fp[1] - 26) + '" stroke="#a89ad0" stroke-width="2.2"/><path d="M' + f(fp[0]) + ' ' + f(fp[1] - 26) + 'l18 5l-18 6Z" fill="#ff7a8a" stroke="#c8485a" stroke-width="1.2"/>';
    // the backyard's three-ring kiddie pool past the lip (blue / white / blue tubes), the splash goes up out of it
    const pc = P(206, 0.15, 0), kp = (() => { const cx = pc[0], cy = pc[1] - 4, RXp = 86, RYp = 25, T = 9, arcF = (y, rx, ry) => 'M' + f(cx - rx) + ' ' + f(y) + 'A' + rx + ' ' + ry + ' 0 0 0 ' + f(cx + rx) + ' ' + f(y);
      let k = '<ellipse cx="' + f(cx + 4) + '" cy="' + f(cy + 3 * T + 8) + '" rx="' + (RXp + 12) + '" ry="' + f(RYp * 0.7) + '" fill="#2a4a20" opacity="0.2"/><ellipse cx="' + f(cx) + '" cy="' + f(cy) + '" rx="' + RXp + '" ry="' + RYp + '" fill="#3f9af0"/><ellipse cx="' + f(cx) + '" cy="' + f(cy + 1) + '" rx="' + (RXp - 12) + '" ry="' + (RYp - 5) + '" fill="#1b5fae"/><ellipse cx="' + f(cx) + '" cy="' + f(cy + 5) + '" rx="' + (RXp - 15) + '" ry="' + (RYp - 9) + '" fill="url(#' + u + 'wt)"/>';
      k += '<path d="' + arcF(cy, RXp, RYp) + 'L' + f(cx + RXp - 12) + ' ' + f(cy + 1) + 'A' + (RXp - 12) + ' ' + (RYp - 5) + ' 0 0 1 ' + f(cx - RXp + 12) + ' ' + f(cy + 1) + 'Z" fill="#3f9af0"/>';
      ['#2a86e6', '#f6f9fc', '#2a86e6'].forEach((c, j) => { const yt = cy + 2 + j * T, yb = yt + T; k += '<path d="' + arcF(yt, RXp, RYp) + 'L' + f(cx + RXp) + ' ' + f(yb) + 'A' + RXp + ' ' + RYp + ' 0 0 1 ' + f(cx - RXp) + ' ' + f(yb) + 'Z" fill="' + c + '" stroke="' + (j === 1 ? '#c9d6e6' : '#1a5fb0') + '" stroke-width="1"/><path d="' + arcF(yt + 3, RXp - 8, RYp) + '" fill="none" stroke="#ffffff" stroke-width="1.8" opacity="' + (j === 1 ? 0.9 : 0.45) + '"/>'; });
      [-0.6, -0.15, 0.35, 0.75].forEach((v, i) => { k += '<g transform="translate(' + f(cx + v * RXp * 0.92) + ' ' + f(cy + 2 + T * 1.5 + RYp * Math.sqrt(1 - v * v * 0.85)) + ') scale(0.9)">' + (i % 2 ? '<path d="M0 -3.6L1 -1.2L3.5 -1.1L1.5 0.6L2.2 3.1L0 1.7L-2.2 3.1L-1.5 0.6L-3.5 -1.1L-1 -1.2Z" fill="#ffd23a"/>' : '<path d="M-4.2 0Q-1 -3 3 0Q-1 3 -4.2 0Z" fill="#ff8a3a"/><path d="M2.6 0L5.6 -2.2V2.2Z" fill="#ff8a3a"/>') + '</g>'; });
      return k + '<g transform="translate(' + f(cx - 46) + ' ' + f(cy + 4) + ') scale(0.75)"><path d="M-12 -2Q-12 -12 0 -12Q8 -12 10 -6Q12 -2 6 0H-8Q-12 0 -12 -2Z" fill="#ffd84a" stroke="#d09a20" stroke-width="1.2"/><circle cx="4" cy="-17" r="7" fill="#ffd84a" stroke="#d09a20" stroke-width="1.2"/><path d="M10 -17l6 1l-6 3Z" fill="#ff8a3a"/></g>'; })();
    b += kp;
    for (let s = S0 + 25; s < LE; s += 45) b += post(s, 1.05, 0, hr(s) - 4);
    // the slide: rainbow bands from the tower down the first drop, along, and curving up at the end
    for (let j = 0; j < ss.length - 1; j++) { const a = ss[j], z = ss[j + 1]; bands.forEach((col, i) => { const l0 = -1 + i / 3, l1 = -1 + (i + 1) / 3; b += '<path d="' + pl([P(a, l0, hr(a)), P(z, l0, hr(z)), P(z, l1, hr(z)), P(a, l1, hr(a))]) + '" fill="' + col + '" stroke="' + col + '" stroke-width="0.8"/>'; }); }
    for (let s = S0 + 30; s < RS; s += 50) b += '<path d="M' + pt(P(s, -1, CH)) + 'L' + pt(P(s, 1, CH)) + '" stroke="#ffffff" stroke-width="2" opacity="0.5"/>';
    [[-60, 0.5], [20, -0.5]].forEach(([s, l]) => { b += '<path d="M' + pt(P(s, l, CH)) + 'L' + pt(P(s + 60, l, CH)) + '" stroke="#ffffff" stroke-width="3" stroke-linecap="round" opacity="0.55"/>'; });
    const edge = (l, h0, h1) => ss.map(s => P(s, l, hr(s) * h0 + h1)), rev = a => a.slice().reverse();
    b += '<path d="' + pl(edge(1, 1, 0).concat(rev(edge(1, 1, WH)))) + '" fill="#e6e0f6"/><path d="' + pl(edge(1, 1, WH).concat(rev(edge(1.1, 1, WH)))) + '" fill="#ffffff" stroke="#cfc6ec" stroke-width="1.2"/>';
    // things on the slide: gold arrows just ahead, a splash slick + a gnome behind (dodged), a rock ahead
    const gp = P(52, 0.02, CH), q = (a, w) => [a * FX + w * LX, a * FY + w * LY]; b += '<g transform="translate(' + pt(gp) + ')"><path d="' + pl([q(-26, -19), q(26, -19), q(26, 19), q(-26, 19)]) + '" fill="url(#' + u + 'gd)" stroke="#d79a22" stroke-width="2.4" stroke-linejoin="round"/>';
    [-13, 2, 17].forEach(d => { b += '<path d="' + pl([q(d - 7, -11), q(d + 4, 0), q(d - 7, 11), q(d - 2, 11), q(d + 9, 0), q(d - 2, -11)]) + '" fill="#ff8a3d" stroke="#ffffff" stroke-width="1.2" stroke-linejoin="round"/>'; }); b += '</g>';
    const sp = P(-40, -0.5, CH); b += '<ellipse cx="' + f(sp[0]) + '" cy="' + f(sp[1]) + '" rx="30" ry="12" transform="rotate(8 ' + pt(sp) + ')" fill="#9fe2ff" stroke="#ffffff" stroke-width="2.2"/><path d="M' + f(sp[0] - 16) + ' ' + f(sp[1] - 2) + 'l20 2" stroke="#ffffff" stroke-width="2.6" stroke-linecap="round" opacity="0.85"/>';
    const gn = P(-58, 0.6, CH); b += '<g transform="translate(' + pt(gn) + ') rotate(-8) scale(0.85)"><ellipse cy="2" rx="15" ry="5" fill="#2d4a22" opacity="0.22"/><ellipse cx="-6" cy="-2" rx="6.5" ry="4" fill="#6b4426"/><ellipse cx="6" cy="-2" rx="6.5" ry="4" fill="#6b4426"/><path d="M-12 -4C-13 -16 -9 -22 0 -22C9 -22 13 -16 12 -4Z" fill="#4f8ee8" stroke="#2c5aa8" stroke-width="1.6"/><path d="M-9 -26C-13 -16 -6 -7 0 -6C6 -7 13 -16 9 -26Z" fill="#ffffff" stroke="#d8d2c6" stroke-width="1.4"/><ellipse cy="-28" rx="8" ry="6.2" fill="#ffd2b0"/><circle cy="-25.5" r="2.8" fill="#ff9a8a"/><path d="M-4.5 -29h2.4M2.1 -29h2.4" stroke="#4a3a2e" stroke-width="1.5" stroke-linecap="round"/><path d="M-10.5 -31C-9 -39 -4 -49 2 -51C3 -44 8 -37 10.5 -31Z" fill="#ff5e6c" stroke="#b8304a" stroke-width="1.6" stroke-linejoin="round"/></g>';
    const rk = P(70, -0.55, CH); b += '<g transform="translate(' + pt(rk) + ') scale(0.7)"><ellipse cy="3" rx="26" ry="8" fill="#2d4a22" opacity="0.22"/><path d="M-24 2C-26 -10 -16 -24 -2 -25C12 -26 24 -16 25 -4C26 2 20 6 0 6C-16 6 -23 5 -24 2Z" fill="#a3a9b2" stroke="#5c6470" stroke-width="2.2"/><path d="M-15 -14C-9 -21 3 -22 9 -18" stroke="#d2d6dc" stroke-width="4.5" fill="none" stroke-linecap="round"/></g>';
    // the near wall (its side panel grows under the first drop + into the ramp's side), the near posts + ladder of the tower, the lip's end face
    for (let s = S0 + 25; s < LE; s += 45) b += post(s, -1.05, 0, hr(s) - 4);
    b += '<path d="' + pl(edge(-1.1, 1, -6).concat(rev(edge(-1.1, 1, WH)))) + '" fill="#cfc6ec"/><path d="' + pl(edge(-1.1, 1, WH).concat(rev(edge(-1, 1, WH)))) + '" fill="#ffffff" stroke="#cfc6ec" stroke-width="1.2"/>';
    b += post(T0, -1.15, 0, tH + 44) + post(S0, -1.15, 0, tH + 44); [T0 + 14, T0 + 50].forEach(s => { b += '<path d="M' + pt(P(s, -1.8, 0)) + 'L' + pt(P(s, -1.15, tH + 16)) + '" stroke="#a89ad0" stroke-width="6.5" stroke-linecap="round"/><path d="M' + pt(P(s, -1.8, 0)) + 'L' + pt(P(s, -1.15, tH + 16)) + '" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>'; });
    for (let k = 1; k <= 4; k++) { const h = k * tH / 5, l = -1.8 + 0.65 * h / (tH + 16); b += '<path d="M' + pt(P(T0 + 14, l, h)) + 'L' + pt(P(T0 + 50, l, h)) + '" stroke="#ffffff" stroke-width="3.4" stroke-linecap="round"/>'; }
    b += '<path d="' + pl([P(LE, -1.1, hr(LE) - 6), P(LE, 1.1, hr(LE) - 6), P(LE, 1.1, hr(LE) + WH), P(LE, -1.1, hr(LE) + WH)]) + '" fill="#cfc6ec" stroke="#b6aadc" stroke-width="1.5"/><path d="M' + pt(P(LE, -1, hr(LE) + 1)) + 'L' + pt(P(LE, 1, hr(LE) + 1)) + '" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>';
    // the pool's big splash past the lip (where you're headed)
    const spl = [pc[0], pc[1] + 2]; b += '<g transform="translate(' + pt(spl) + ')"><ellipse rx="50" ry="15" fill="#ffffff" opacity="0.75"/><ellipse rx="70" ry="22" fill="none" stroke="#ffffff" stroke-width="3" opacity="0.7"/><path d="M-16 0C-20 -70 -8 -150 2 -164C12 -150 22 -70 16 0Z" fill="#ffffff" opacity="0.96"/>'
      + [[-40, -86], [-26, -118], [28, -108], [42, -76], [-52, -54], [54, -48]].map(([x, h]) => '<path d="M' + f(x * 0.4 - 5) + ' 0C' + f(x * 0.4 - 6) + ' ' + f(h * 0.55) + ' ' + f(x - 3) + ' ' + f(h * 0.95) + ' ' + f(x) + ' ' + f(h) + 'C' + f(x + 3) + ' ' + f(h * 0.95) + ' ' + f(x * 0.4 + 6) + ' ' + f(h * 0.55) + ' ' + f(x * 0.4 + 5) + ' 0Z" fill="#e6f8ff" stroke="#a8e0ff" stroke-width="1.2"/>').join('')
      + '<path d="M-42 -2Q-52 -28 -62 -32Q-48 -24 -34 -4ZM42 -2Q54 -26 64 -30Q50 -22 34 -4Z" fill="#e6f8ff" stroke="#a8e0ff" stroke-width="1.2"/></g>';
    [[spl[0] - 48, spl[1] - 136, 5], [spl[0] + 38, spl[1] - 160, 6], [spl[0] + 58, spl[1] - 100, 4.5], [spl[0] - 64, spl[1] - 90, 4], [spl[0] + 10, spl[1] - 196, 4], [spl[0] - 28, spl[1] - 182, 3.5]].forEach(([x, y, r]) => { b += '<path transform="translate(' + f(x) + ' ' + f(y) + ') scale(' + (r / 6) + ')" d="M0 -9Q6 -1 6 3A6 6 0 0 1 -6 3Q-6 -1 0 -9Z" fill="#cdf4ff" stroke="#4fb8e8" stroke-width="1.4"/>'; });
    // your creature whooshing down on its bottom, arms up, water spraying off behind
    const me = P(-6, -0.02, CH);
    b += '<ellipse cx="' + f(me[0] + 2) + '" cy="' + f(me[1] + 2) + '" rx="40" ry="13" fill="#2a3a20" opacity="0.2"/>' + speed(me[0] - 22, me[1] - 56, A, 4, 56, '#ffffff', 0.9);
    [[-52, -8], [-64, -1], [-45, 4], [-74, -12]].forEach(([dx, dy], i) => { b += '<circle cx="' + f(me[0] + dx) + '" cy="' + f(me[1] + dy) + '" r="' + (3.6 - i * 0.5) + '" fill="#dff4ff" stroke="#8fd6ff" stroke-width="1"/>'; });
    b += stk(u, c.src, me[0], me[1] + 5, 118, 0, false, { sit: 1, armL: 155, armR: 150, hap: 1, open: 0.85, smile: 1, lean: -0.55 }, null, null, 58);
    b += badge(76, 300, 23, 'WHEE!', -10, '#ffd84a', '#7a3a10', 17);
    b += spark(110, 120, 6) + spark(390, 92, 6, '#fff6c8') + spark(300, 300, 5);
    return wrapL(u, defs, b + L.body);
  }

  // ---------- CORNHOLE: a bean bag sailing over the board towards the hole, one already sliding in ----------
  function corn(u, c) {
    const L = logo(u, ['CORNHOLE'], 180, 78, { size: 52, top: '#ffffff', bot: '#ffd36a', hi: '#ffffff', ink: '#1e3a8a', shade: '#0f2258', rot: -4 });
    const defs = L.defs + lg(u + 'sk', 0, 1, [[0, '#5aa8ff'], [0.65, '#b6dcff'], [1, '#eef8ff']]) + lg(u + 'gr', 0, 1, [[0, '#9fdc6e'], [1, '#5fb04a']]) + lg(u + 'bd', 0, 1, [[0, '#6aa4ff'], [1, '#3a72e0']]) + lg(u + 'bg', 0, 1, [[0, '#ff7a6a'], [1, '#d63a3a']]);
    let b = '<rect x="-420" width="1400" height="640" fill="url(#' + u + 'sk)"/>' + rays(206, 242, 22, '#ffffff', 0.17) + cloud(70, 150, 0.6, 0.8) + cloud(300, 176, 0.5, 0.7);
    b += backdrop(290, ['#4f9a3e', '#62ad4c'], 0.9) + '<path d="M-420 286H980V640H-420Z" fill="url(#' + u + 'gr)"/>';
    // the wind flag on the right
    b += '<path d="M326 140V300" stroke="#e8e0d4" stroke-width="5" stroke-linecap="round"/><circle cx="326" cy="138" r="5" fill="#ffd84a"/><path d="M326 146C304 140 292 154 272 150C286 160 290 170 276 182C296 180 308 168 326 176Z" fill="#ff5e6c" stroke="#b8304a" stroke-width="2" stroke-linejoin="round"/>';
    b += '<path d="M262 160h-18M258 170h-12" stroke="#ffffff" stroke-width="3" stroke-linecap="round" opacity="0.8"/>';
    // the board, tilted up away from you: its far legs, the side, the top with a stripe and the hole
    const top = [[118, 362], [298, 362], [262, 214], [154, 214]];
    b += '<ellipse cx="208" cy="368" rx="104" ry="12" fill="#2a4a20" opacity="0.25"/><path d="M160 214L156 252M256 214L260 252" stroke="#a87444" stroke-width="7" stroke-linecap="round"/>';
    b += '<path d="M118 362L298 362L298 372L118 372Z" fill="#c98d54"/><path d="M' + top.map(p => p.join(' ')).join('L') + 'Z" fill="url(#' + u + 'bd)" stroke="#2a56b8" stroke-width="3" stroke-linejoin="round"/>';
    b += '<path d="M133 300L284 300L276 268L141 268Z" fill="#ffffff" opacity="0.9"/><path d="M137 286L281 286" stroke="#ff5e6c" stroke-width="6"/>';
    b += '<ellipse cx="208" cy="238" rx="22" ry="8" fill="#14224a"/><ellipse cx="208" cy="236" rx="22" ry="8" fill="none" stroke="#9fc4ff" stroke-width="2"/>';
    // a bag on the board near the hole, and one sailing in (its arc starts at your creature)
    const bag = (x, y, k, r) => '<g transform="translate(' + x + ' ' + y + ') rotate(' + r + ') scale(' + k + ')"><path d="M-17 -13Q0 -17 17 -13Q21 0 17 13Q0 17 -17 13Q-21 0 -17 -13Z" fill="url(#' + u + 'bg)" stroke="#8a1c24" stroke-width="2"/><path d="M-13 -9Q0 -12 13 -9" fill="none" stroke="#ffffff" stroke-width="1.6" stroke-dasharray="2 3" opacity="0.8"/><ellipse cx="-5" cy="-5" rx="6" ry="3" fill="#ffffff" opacity="0.35"/></g>';
    b += bag(246, 252, 0.8, 18);
    b += '<path d="M112 232Q142 70 200 220" fill="none" stroke="#ffffff" stroke-width="5" stroke-dasharray="1 12" stroke-linecap="round" opacity="0.95"/>' + speed(176, 150, 0.95, 3, 46, '#ffffff', 0.8) + bag(184, 168, 1.15, 34);
    b += badge(276, 112, 30, '+3', 10, '#ffd84a', '#7a3a10', 26);
    b += spark(226, 214, 7) + spark(140, 120, 6) + spark(196, 270, 5, '#ffffff', 0.9);
    b += '<ellipse cx="76" cy="346" rx="58" ry="11" fill="#2a4a20" opacity="0.25"/>' + stk(u, c.src, 76, 350, 150, -6, false, { hRx: -2, hRy: -6, armR: 100, lean: 0.8, footL: 2, sq: -0.03, open: 0.3, lx: 0.8, ly: -0.2 });   // the toss, arm still out towards the board
    return wrap(u, defs, b + L.body);
  }

  // ---------- PING-PONG: the rally from behind your creature (paddle up, its back to us), the other player facing you across the table ----------
  function pong(u, c) {
    const L = logo(u, ['PING-PONG'], 180, 74, { size: 50, top: '#ffffff', bot: '#9ff0c8', hi: '#ffffff', ink: '#0e4a3a', shade: '#062a20', rot: -4 });
    const defs = L.defs + lg(u + 'sk', 0, 1, [[0, '#1f8a62'], [0.55, '#5fcf9a'], [1, '#d6f6e6']]) + lg(u + 'tb', 0, 1, [[0, '#3a74e0'], [1, '#2a5ccc']]) + rg(u + 'pd', '40%', '35%', '70%', [[0, '#ff8a7a'], [1, '#d0303a']]) + rg(u + 'pb', '40%', '35%', '70%', [[0, '#7fb0ff'], [1, '#2a5ccc']]) + rg(u + 'ball', '35%', '30%', '70%', [[0, '#ffffff'], [1, '#e8dcc8']]);
    const paddle = (fill, rot, k) => '<g transform="rotate(' + rot + ') scale(' + k + ')"><rect x="-7" y="-6" width="14" height="40" rx="6" fill="#c98d54" stroke="#4a3a2e" stroke-width="3"/><rect x="-7" y="6" width="14" height="5" fill="#8a5a34" opacity="0.5"/><ellipse cy="-38" rx="30" ry="33" fill="url(#' + u + fill + ')" stroke="#4a3a2e" stroke-width="3.5"/><ellipse cx="-9" cy="-50" rx="10" ry="6" fill="#ffffff" opacity="0.3" transform="rotate(-20 -9 -50)"/></g>';
    let b = '<rect x="-420" width="1400" height="640" fill="url(#' + u + 'sk)"/>' + rays(180, 212, 24, '#ffffff', 0.12);
    // the patio under the table, the backyard behind
    b += backdrop(226, ['#2f8a5a', '#3fa06a'], 0.7) + '<path d="M-420 222H980V640H-420Z" fill="#e8dcc8"/>';
    for (let i = -7; i <= 7; i++) b += '<path d="M' + (180 + i * 20) + ' 222L' + (180 + i * 90) + ' 640" stroke="#d4c6ae" stroke-width="2"/>'; [236, 258, 290, 336, 404].forEach(y => { b += '<path d="M-10 ' + y + 'H370" stroke="#d4c6ae" stroke-width="2"/>'; });
    // the other player, facing you behind the far end (drawn before the table: the table hides its feet), its blue paddle ready
    b += '<ellipse cx="196" cy="236" rx="34" ry="7" fill="#3a2a2a" opacity="0.2"/>' + stk(u, '', 196, 240, 104, -3, false, { armR: 70, hRy: -4, lift: 1, sq: 0.04, open: 0.3, lx: 0.3, ly: 0.4 }, { at: 'pawR', svg: paddle('pb', 30, 0.36) }, 'opp');
    // the table: legs, edge, the blue top, the lines, the net
    b += '<path d="M60 360L64 410M300 360L296 410M104 232L106 262M256 232L254 262" stroke="#3a3a4a" stroke-width="6" stroke-linecap="round"/>';
    b += '<path d="M24 352L336 352L336 364L24 364Z" fill="#1e3e8a"/><path d="M24 352L336 352L268 226L92 226Z" fill="url(#' + u + 'tb)" stroke="#ffffff" stroke-width="4" stroke-linejoin="round"/><path d="M180 352L180 226" stroke="#ffffff" stroke-width="2.5"/>';
    b += '<path d="M62 280H298" stroke="#1a2a5a" stroke-width="3" opacity="0.35"/><path d="M58 258L302 258L302 282L58 282Z" fill="#ffffff" opacity="0.3"/><g stroke="#ffffff" stroke-width="1" opacity="0.7">'; for (let x = 64; x < 302; x += 8) b += '<path d="M' + x + ' 258V282"/>';
    b += '</g><path d="M54 258H306" stroke="#ffffff" stroke-width="4"/><path d="M56 256V286M304 256V286" stroke="#2a2a3a" stroke-width="4" stroke-linecap="round"/>';
    // the ball coming your way: off their paddle, a bounce on your half, up towards your paddle
    b += '<path d="M206 214Q194 250 176 318L168 300Q156 262 150 236" fill="none" stroke="#ffffff" stroke-width="4" stroke-dasharray="1 10" stroke-linecap="round" opacity="0.95"/><ellipse cx="174" cy="318" rx="11" ry="3.5" fill="#ffffff" opacity="0.6"/>';
    b += speed(150, 232, 1.85, 3, 30, '#ffffff', 0.8) + '<circle cx="150" cy="228" r="10" fill="url(#' + u + 'ball)" stroke="#c8b898" stroke-width="1"/>';
    // you, from behind, at the near end: paddle up in your right paw, ready to hit it back
    b += '<ellipse cx="236" cy="452" rx="74" ry="14" fill="#3a2a2a" opacity="0.2"/>' + stk(u, c.src, 236, 456, 200, 3, false, { armR: 120, hRy: -8, lift: 2, sq: -0.04, tilt: -3 }, { at: 'pawR', svg: paddle('pd', -26, 0.8) }, null, 180);
    b += badge(70, 168, 28, 'RALLY!', -8, '#ffd84a', '#7a3a10', 17);
    b += spark(300, 182, 7) + spark(46, 236, 5) + spark(118, 200, 5);
    return wrap(u, defs, b + L.body);
  }

  YG.POSTER = { hoop, soccer, hop, tramp, slide, corn, pong };
  }; go();
})();
