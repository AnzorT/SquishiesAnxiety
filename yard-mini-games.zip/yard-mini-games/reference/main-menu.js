// Nov 13 MAIN MENU (landscape, user picked): the player's creature stands on a lit stone pad in front of their real house (main-menu-scene.js draws
// the house from the front with the map's state: locked rooms boarded up with 'Lv n' signs, trees / grass dead -> lush by level, season + weather).
// v3 (user: 'not good, I don't want it from the png, create our own - same for the text style; PLAY opens a full screen with the mini games;
// a button that takes us to the home with a really nice animation into the house behind us; the character 12% smaller'):
//  - our own UI kit, all CSS + inline SVG (no images): gold-rimmed royal-purple velvet plaques with diamond tips, gold gem buttons, jewel orbs,
//    a winged gold crest drawn in SVG for the level, and our own title lettering (SVG text: gradient fill + dark outline + white sticker edge)
//    for the logo, PLAY, headings and the creature's nameplate (colours per rarity: wood / bronze / amethyst / gold / rainbow).
//  - PLAY (and the GAMES tab) opens a full-screen Mini Games page: Squish Time + the 7 yard games as cards (locked until the Backyard opens);
//    a yard game plays right there (YardGames, portrait stage in the middle, how-to + best score at the sides).
//  - MY HOUSE (tab, the level crest, or tapping an open room): the HUD fades, the creature turns round, walks up the path to the front door,
//    the door swings open with warm light, the camera flies in through the doorway -> opts.onHome(room, rect) (the page shows the house);
//    back() plays it in reverse (camera pulls back out of the door, the creature walks out and turns to face you).
// v9 (Nov 14, user: 'loading screens for going to the crib, opening a chest (+ a special room for chest opening) and the characters screen' ->
//  'Shop tab + chest room', 'CREATURES tab', 'Royal treasure vault'): SHOP opens the Treasure Shop page here (free chest every 4 h + every chest group
//  with its 5 tiers, prices from ChestLoot.TIERS, the same daily HOT picks as Shop v5); buying one calls opts.onChest({ gk, tier, name, label, roll })
//  -> the page plays the 'chest' loading screen (squad-loading.js) and opens the chest in the treasure vault (chest-vault.js + Chest Smash v2 room
//  'vault'); chestDone(rw) back here toasts what came out and refreshes the shop. CREATURES plays the 'creatures' loading screen while the picker's
//  cards load. (The house's loading screen is the page's: it covers the Home trip's warm light until the house has drawn.)
// v10 (user: 'the house loading screen is bad - make it more related to the real house, don't create a new area'; 'only Pet Shop, Snack Shack
//  and Fruit characters'): the Home trip's loading screen IS the real house: once the creature is in the doorway, night falls on this scene (a deep
//  blue wash, stars, a moon) and the lights of the open rooms come on one by one (each open window gets a warm pane + glow; rooms without windows
//  a soft glow) while the page loads the house (onHome(room, rect, ld) -> ld.set / ld.ready); SquadLoading 'house' (art: false) adds the title,
//  a chip per room and the bar. When the house is ready the camera flies in through the door (its exit) and opts.onHomeIn() shows the house.
//  The creature picker's loading cards come from the Pet Shop / Snack Shack / Fruit Patch sets only.
// v11 (user: 'change the purple colour to something else - use the colours of the crib's decoration pull tab'; 'in the home loading screen remove the
//  room names' + 'also the "turning on the lights"'): the Treasure Shop page and the creature picker wear the crib palette (.mm-crib: honey wood with
//  plank lines, cream paper tags, brass, brown ink #6b4426 - the house drawer's pull tab) instead of the purple velvet; the house loading overlay
//  is only the title + bar now.
// v13 (Nov 17, user: 'I need also a loading screen for when I go back to the main home screen'): leaving the house plays SquadLoading 'menu'
//  "Back outside" (squad-loading v7) over this scene, the mirror of the trip in: the camera pulls back out of the door into the night we left, then
//  the morning comes over the real house (nightLights().dawn(q): the stars fade, the moon sets, the sky blushes pink + gold behind the house, the sun
//  comes up from behind the sea - orange low down, its own colours higher up - the rooms' lights go out one by one with the Living Room last, birds
//  cross the sky; rainy = a grey-pink dawn, no sun, no birds) while the menu redraws the house front from the current level / season / creature (it
//  is frozen while we are inside - that redraw is the load); its exit is the creature stepping out of the open door, walking down the path to the
//  pad and turning round; then the HUD comes back. back({ load(ld) }) lets a page report the progress; back({ loading: false }) = the old quick way.
//  jumpIn() puts the menu 'inside' at once (no trip in) for the Loading Screens page.
// v14 (Nov 17, user: 'all the games need to be horizontal not vertical'): a yard game laid out for landscape (G.land) plays across the whole Mini Games page
//  (.mm-gp.land: the side columns hide, the game's own top bar / intro sheet carry the back button + how to play).
// window.MainMenu.mount(host, { bare, preview, season, onPlay(mode, id), onHome(room, rect, ld), onHomeIn(), onChest(item), onShop(), onSettings() }) -> { destroy(), back(o), jumpIn(), chestDone(rw) }.
(function () {
  if (window.MainMenu && window.MainMenu.v >= 13) return;
  const SQUISH = { id: 'squish', name: 'Squish Time', item: 'The classic squish', color: '#ff6fc8', how: ['Squeeze, poke and stretch your creature.', 'Every squish pays coins.', 'Fill the combo bar for a bonus!'] };
  const fmt = n => n == null ? '' : Number(n).toLocaleString('en-US');
  const BL = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
  const LS = { get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} } };
  const KEY = 'squishsquad.menu.v1';
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  let UID = 0;

  // ---------- our lettering: SVG text = gradient fill + dark outline (+ optional white sticker edge) ----------
  const FT = {
    gold: { f: ['#fffbe6', '#ffe57e', '#ffbe2e', '#f08c10'], o: '#3d1268', w: 1 },
    goldB: { f: ['#fffbe6', '#ffe57e', '#ffbe2e', '#f08c10'], o: '#4a1f04' },
    white: { f: ['#ffffff', '#ffffff', '#f6eeff', '#e4d4ff'], o: '#3d1268' },
    whiteB: { f: ['#ffffff', '#ffffff', '#fff6e2', '#ffe6b8'], o: '#6a2c00' },
    wood: { f: ['#fffbea', '#ffe9b8', '#f2c27a', '#d08a3c'], o: '#3a1e0a' },
    bronze: { f: ['#ffffff', '#ffe9d4', '#ffc392', '#ef8f50'], o: '#4a1a06' },
    amethyst: { f: ['#ffffff', '#f5e6ff', '#dcb0ff', '#b273ff'], o: '#2a0a5c' },
    rainbow: { f: ['#ff8fd0', '#ffcf5a', '#7fe9b8', '#7fc4ff', '#c39bff'], o: '#4a1a7a', h: 1 } };
  function ft(text, st, size, cls) {
    const S = FT[st] || FT.white, id = 'mmft' + (++UID), sw = Math.max(2.4, size * 0.19), w = Math.ceil(String(text).length * size * 0.62 + sw * 2 + 6), h = Math.ceil(size * 1.32 + sw);
    const stops = S.f.map((c, i) => '<stop offset="' + (i / (S.f.length - 1)).toFixed(2) + '" stop-color="' + c + '"/>').join('');
    const T = (extra, body) => '<text x="50%" y="' + (size * 0.98 + sw / 2).toFixed(1) + '" text-anchor="middle" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="' + size + '" letter-spacing="' + (size * 0.02).toFixed(1) + '" stroke-linejoin="round" paint-order="stroke" ' + extra + '>' + body + '</text>';
    const t = esc(text);
    return '<svg class="mm-ft ' + (cls || '') + '" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" overflow="visible" aria-label="' + t + '" role="img"><defs><linearGradient id="' + id + '" ' + (S.h ? 'x1="0" y1="0" x2="1" y2="0"' : 'x1="0" y1="0" x2="0" y2="1"') + '>' + stops + '</linearGradient></defs>'
      + (S.w ? T('fill="#ffffff" stroke="#ffffff" stroke-width="' + (sw * 2.1).toFixed(1) + '"', t) : '')
      + T('fill="' + S.o + '" stroke="' + S.o + '" stroke-width="' + (sw * 1.25).toFixed(1) + '" transform="translate(0 ' + (size * 0.06).toFixed(1) + ')"', t)
      + T('fill="url(#' + id + ')" stroke="' + S.o + '" stroke-width="' + sw.toFixed(1) + '"', t)
      + T('fill="none" stroke="rgba(255,255,255,0.55)" stroke-width="' + (size * 0.035).toFixed(2) + '" transform="translate(0 ' + (-size * 0.03).toFixed(2) + ')"', t) + '</svg>';
  }
  // after layout, size each lettering SVG to its real text width (the estimate above is only a first guess)
  function fitFT(root) { root.querySelectorAll('svg.mm-ft').forEach(s => { try { const ts = s.querySelectorAll('text'), t = ts[ts.length - 2], b = t.getBBox(); if (b.width > 0) { const sw = parseFloat(t.getAttribute('stroke-width')) || 4, w = Math.ceil(b.width + sw * 2.4 + 4); s.setAttribute('width', w); s.setAttribute('viewBox', '0 0 ' + w + ' ' + s.getAttribute('height')); } } catch (e) {} }); }

  // ---------- the winged gold crest (level badge), drawn in SVG ----------
  function crest(lv) {
    const id = 'mmcr' + (++UID);
    const wing = s => '<g transform="translate(60 0) scale(' + s + ' 1) translate(-60 0)"><path d="M40 52 C30 46 14 44 4 30 C8 30 13 31 16 30 C10 26 6 21 4 15 C12 19 20 21 26 22 C22 18 20 14 20 9 C28 15 36 22 42 30 C46 36 47 44 44 52 Z" fill="url(#' + id + 'w)" stroke="#3d1268" stroke-width="2.2" stroke-linejoin="round"/>'
      + '<path d="M38 46 C30 42 20 40 12 33 M40 40 C32 34 24 30 16 26 M42 34 C36 28 30 22 26 16" stroke="#b9a2e8" stroke-width="1.4" fill="none" stroke-linecap="round"/></g>';
    return '<svg class="mm-crest" viewBox="0 0 120 104" aria-label="Level ' + lv + '"><defs>'
      + '<linearGradient id="' + id + 'g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fffbe0"/><stop offset="0.35" stop-color="#ffd85a"/><stop offset="0.7" stop-color="#f0a21c"/><stop offset="1" stop-color="#b8640a"/></linearGradient>'
      + '<radialGradient id="' + id + 'p" cx="0.38" cy="0.32" r="0.75"><stop offset="0" stop-color="#f3e2ff"/><stop offset="0.3" stop-color="#b783ff"/><stop offset="0.7" stop-color="#6a26d0"/><stop offset="1" stop-color="#36107a"/></radialGradient>'
      + '<linearGradient id="' + id + 'w" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="0.6" stop-color="#f1e8ff"/><stop offset="1" stop-color="#cdb8f4"/></linearGradient></defs>'
      + wing(1) + wing(-1)
      + '<path d="M60 4 l4.4 9.2 10.1 1.4 -7.3 7.1 1.7 10 -8.9 -4.8 -8.9 4.8 1.7 -10 -7.3 -7.1 10.1 -1.4Z" fill="url(#' + id + 'g)" stroke="#3d1268" stroke-width="2" stroke-linejoin="round"/>'
      + '<circle cx="60" cy="58" r="31" fill="url(#' + id + 'g)" stroke="#3d1268" stroke-width="2.6"/>'
      + [0, 1, 2, 3, 4, 5, 6, 7].map(i => { const a = i * Math.PI / 4, x = 60 + Math.cos(a) * 27.5, y = 58 + Math.sin(a) * 27.5; return '<circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="1.7" fill="#fff6c8" stroke="#a86010" stroke-width="0.7"/>'; }).join('')
      + '<circle cx="60" cy="58" r="23" fill="url(#' + id + 'p)" stroke="#3d1268" stroke-width="2"/><ellipse cx="52" cy="48" rx="9" ry="5" fill="#ffffff" opacity="0.35" transform="rotate(-25 52 48)"/>'
      + '<path d="M38 88 L60 80 L82 88 L78 98 L60 92 L42 98Z" fill="url(#' + id + 'g)" stroke="#3d1268" stroke-width="2" stroke-linejoin="round"/>'
      + '<text x="60" y="95" text-anchor="middle" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="8" fill="#3d1268" letter-spacing="1">LEVEL</text>'
      + '<text x="60" y="67.5" text-anchor="middle" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="' + (lv > 9 ? 24 : 27) + '" fill="#3d1268" stroke="#3d1268" stroke-width="6" stroke-linejoin="round" paint-order="stroke">' + lv + '</text>'
      + '<text x="60" y="66" text-anchor="middle" font-family="Fredoka, Nunito, sans-serif" font-weight="700" font-size="' + (lv > 9 ? 24 : 27) + '" fill="url(#' + id + 'g)" stroke="#3d1268" stroke-width="3" stroke-linejoin="round" paint-order="stroke">' + lv + '</text></svg>';
  }

  let css = false;
  function addCss() {
    if (css) return; css = true; const s = document.createElement('style'); s.textContent = `
.mm-root{position:relative;font-family:'Nunito',sans-serif;-webkit-user-select:none;user-select:none;--ink:#3d1268;
  --rimG:linear-gradient(180deg,#fffbe2 0%,#ffdd6e 24%,#f2ac2c 55%,#b8680c 82%,#ffd474 100%);
  --vel:radial-gradient(130% 160% at 50% -20%,#b07cff 0%,#7a36dc 38%,#4a149a 76%,#320b74 100%);
  --dia:repeating-linear-gradient(45deg,rgba(255,255,255,.055) 0 6px,transparent 6px 12px),repeating-linear-gradient(-45deg,rgba(255,255,255,.055) 0 6px,transparent 6px 12px);
  --spk:radial-gradient(circle at 14% 28%,rgba(255,255,255,.95) 0 .9px,transparent 1.6px),radial-gradient(circle at 63% 72%,rgba(255,255,255,.85) 0 .8px,transparent 1.5px),radial-gradient(circle at 86% 22%,rgba(255,246,200,.9) 0 1px,transparent 1.7px),radial-gradient(circle at 36% 80%,rgba(255,255,255,.7) 0 .7px,transparent 1.4px);}
.mm-test{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;margin:0 auto 12px;padding:10px 14px;border-radius:14px;background:#3b2414;color:#ffe7c2;font:800 12px Nunito,sans-serif;box-shadow:inset 0 0 0 2px #6b4426;}
.mm-test b{font-family:Fredoka,sans-serif;font-weight:700;letter-spacing:1px;font-size:11px;color:#f2b866;}
.mm-test button{font:800 12px Nunito,sans-serif;border:0;border-radius:999px;padding:5px 10px;background:#f6e3c6;color:#5a3a1e;cursor:pointer;box-shadow:0 2px 0 #a8794a;}
.mm-test button.on{background:#ffcf3a;color:#5a3a00;}
.mm-test input{width:42px;font:800 13px Nunito,sans-serif;text-align:center;border:0;border-radius:8px;padding:4px;background:#fff8ee;color:#3b2414;}
.mm-test .nm{min-width:96px;text-align:center;color:#fff;}
.mm-frame{position:relative;overflow:hidden;margin:0 auto;background:#2a0d4f;}
.mm-world{position:absolute;inset:0;will-change:transform;}
.mm-scene{position:absolute;inset:0;}
.mm-stage{position:absolute;pointer-events:none;transform-origin:50% 95.5%;}
.mm-stage.walk > div{animation:mmBob .32s ease-in-out infinite;}
@keyframes mmBob{0%,100%{transform:translateY(0) rotate(-2deg);}50%{transform:translateY(-5%) rotate(2deg);}}
.mm-hit{position:absolute;left:22%;right:22%;top:20%;bottom:2%;border-radius:50%;pointer-events:auto;cursor:grab;}
.mm-veil{position:absolute;inset:0;opacity:0;pointer-events:none;}
.mm-bird{animation:mmBird 8.5s linear both;}
@keyframes mmBird{from{transform:translate(-90px,0);}to{transform:translate(1110px,-36px);}}
.mm-fade{transition:opacity .35s ease;}
.mm-gone{opacity:0 !important;pointer-events:none !important;}
.mm-gone *{pointer-events:none !important;}
.mm-hud{position:absolute;left:0;top:0;width:852px;height:393px;transform-origin:0 0;pointer-events:none;}
.mm-hud > *{pointer-events:auto;}
/* ---- our plaques: velvet / gold / bronze / jewel fills inside a gold rim, dark outline, 3D lip, diamond tips ---- */
.mm-p{position:relative;box-sizing:border-box;border:2.5px solid transparent;border-radius:999px;cursor:pointer;font:700 12.5px Fredoka,sans-serif;letter-spacing:.6px;
  box-shadow:0 0 0 1.6px var(--ink),0 3px 0 1.6px var(--ink),0 6px 12px rgba(20,0,50,.38),inset 0 1.5px 0 rgba(255,255,255,.55),inset 0 -3px 6px rgba(20,0,60,.35);}
.mm-p.tip::before,.mm-p.tip::after{content:'';position:absolute;top:50%;width:8px;height:8px;margin-top:-4px;transform:rotate(45deg);background:linear-gradient(135deg,#fff6c8,#f2ac2c 55%,#a8600a);box-shadow:0 0 0 1.5px var(--ink),inset 1px 1px 0 rgba(255,255,255,.8);pointer-events:none;}
.mm-p.tip::before{left:-7px;}.mm-p.tip::after{right:-7px;}
.v-vel{background:var(--spk) padding-box,var(--dia) padding-box,var(--vel) padding-box,var(--rimG) border-box;color:#fff;}
.v-gold{background:linear-gradient(180deg,rgba(255,255,255,.6) 0,rgba(255,255,255,0) 46%) padding-box,var(--spk) padding-box,linear-gradient(180deg,#fff1b0 0%,#ffd650 40%,#f6a524 76%,#ffc84a 100%) padding-box,linear-gradient(180deg,#fffbe8,#e9a530 60%,#8a4a06) border-box;color:var(--ink);}
.v-bronze{background:linear-gradient(180deg,rgba(255,255,255,.45) 0,rgba(255,255,255,0) 46%) padding-box,linear-gradient(180deg,#ffd7b4 0%,#ea9a64 42%,#b45e2c 78%,#d98a52 100%) padding-box,var(--rimG) border-box;color:#fff;}
.v-wood{background:repeating-linear-gradient(90deg,rgba(80,40,10,.10) 0 2px,transparent 2px 11px) padding-box,linear-gradient(180deg,#e9b97c 0%,#c4874a 45%,#8c5426 100%) padding-box,linear-gradient(180deg,#ffe3b0,#a8692e 60%,#5a3010) border-box;color:#fff;}
.v-amy{background:var(--spk) padding-box,radial-gradient(120% 140% at 50% 0%,#e6c8ff 0%,#a565ff 40%,#6420c8 80%,#4a148e 100%) padding-box,var(--rimG) border-box;color:#fff;}
.v-pearl{background:var(--spk) padding-box,radial-gradient(130% 150% at 30% 0%,#ffffff 0%,#fbf4ff 35%,#ecdcff 70%,#dcc6f6 100%) padding-box,var(--rimG) border-box;color:var(--ink);}
.v-rainbow{background:var(--spk) padding-box,linear-gradient(100deg,#ffc1e6 0%,#ffe7a0 25%,#b9f6d8 50%,#b6e2ff 75%,#e2c8ff 100%) padding-box,linear-gradient(180deg,#ffffff,#d9c4ff 50%,#9a78e8) border-box;color:var(--ink);}
.tx-w{color:#fff;text-shadow:0 1.6px 0 var(--ink),1.2px 0 0 var(--ink),-1.2px 0 0 var(--ink),0 -1.2px 0 var(--ink),1px 1px 0 var(--ink),-1px 1px 0 var(--ink);}
.tx-d{color:var(--ink);text-shadow:0 1px 0 rgba(255,255,255,.7);}
.mm-orb{position:relative;width:40px;height:40px;padding:0;border:3px solid transparent;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;
  background:radial-gradient(circle at 34% 28%,#ffffff 0 7%,#d6b4ff 16%,#9a5cf0 38%,#5a1cb8 70%,#330a78 100%) padding-box,var(--rimG) border-box;box-shadow:0 0 0 1.6px var(--ink),0 3px 0 1.6px var(--ink),0 6px 12px rgba(20,0,50,.4);}
.mm-orb svg{width:20px;height:20px;filter:drop-shadow(0 1.4px 0 var(--ink));}
.mm-gem{position:absolute;width:15px;height:15px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff 0 12%,#ffd77a 28%,#f08a12 62%,#9a4a04 100%);box-shadow:0 0 0 1.5px var(--ink),0 0 0 3.5px #ffd76a,0 0 0 5px var(--ink);pointer-events:none;}
.mm-hot{position:absolute;border-radius:10px;cursor:pointer;-webkit-tap-highlight-color:transparent;}
.mm-hot:hover,.mm-hot.on{box-shadow:0 0 0 2.5px rgba(255,236,160,0.95),0 0 18px 5px rgba(255,214,110,0.75);background:rgba(255,240,190,0.12);}
.mm-hot .lab{position:absolute;left:50%;bottom:calc(100% + 8px);white-space:nowrap;padding:3px 12px;opacity:0;pointer-events:none;transition:opacity .15s;cursor:default;}
.mm-hot:hover .lab,.mm-hot.on .lab{opacity:1;}
/* ---- top bar ---- */
.mm-top{position:absolute;left:14px;right:14px;top:9px;display:flex;align-items:center;gap:7px;pointer-events:none;}
.mm-top > *{pointer-events:auto;}
.mm-logo{margin:-6px 4px -6px -2px;filter:drop-shadow(0 3px 3px rgba(30,0,60,.45));}
.mm-narrow .mm-logo{display:none;}
.mm-tabs{display:flex;gap:10px;padding:0 6px;}
.mm-tab{height:30px;padding:0 13px;display:flex;align-items:center;gap:5px;}
.mm-tab svg{width:14px;height:14px;}
.mm-tab.v-gold{box-shadow:0 0 0 1.6px var(--ink),0 3px 0 1.6px var(--ink),0 0 14px 4px rgba(255,222,120,.8),inset 0 1.5px 0 rgba(255,255,255,.7),inset 0 -3px 5px rgba(80,30,0,.3);}
.mm-narrow .mm-tab{padding:0 9px;}.mm-narrow .mm-tabs{gap:8px;padding:0 4px;}
.mm-sp{flex:1;}
.mm-pill{height:30px;display:flex;align-items:center;gap:4px;padding:0 11px 0 4px;font-size:13.5px;}
.mm-pill img{width:28px;height:28px;margin:-6px 0 -6px -10px;filter:drop-shadow(0 2px 2px rgba(30,0,40,.45));}
/* ---- the Play card ---- */
.mm-card{position:absolute;left:16px;bottom:16px;width:204px;padding:14px 11px 11px;border-radius:20px;border-width:3.5px;cursor:default;text-align:center;}
.mm-card.mm-p{box-shadow:0 0 0 2px var(--ink),0 4px 0 2px var(--ink),0 12px 24px rgba(20,0,50,.5),inset 0 0 0 1.5px rgba(255,214,120,.55),inset 0 0 18px rgba(20,0,60,.45);}
.mm-card .star{position:absolute;left:50%;top:-17px;width:34px;height:34px;margin-left:-17px;filter:drop-shadow(0 2px 2px rgba(20,0,50,.5));}
.mm-card .k{font:800 9px Nunito,sans-serif;letter-spacing:1.6px;color:#ffd77a;}
.mm-card .ttl{margin:0 0 2px;}
.mm-card .sub{font:700 11px Nunito,sans-serif;color:#eadcff;margin-bottom:6px;}
.mm-card .icons{display:flex;justify-content:center;gap:4px;margin-bottom:9px;}
.mm-card .icons i{width:22px;height:22px;border-radius:50%;overflow:hidden;box-shadow:0 0 0 1.5px var(--ink),0 0 0 3px #ffd76a;display:block;}
.mm-card .icons i svg{width:100%;height:100%;display:block;}
.mm-card .icons i.lk{filter:grayscale(1) brightness(.7);}
.mm-play{width:100%;height:54px;border-radius:16px;border-width:3px;display:flex;align-items:center;justify-content:center;gap:4px;animation:mmGlow 2.4s ease-in-out infinite;}
.mm-play:hover .mm-ft{transform:scale(1.05);}
.mm-play .mm-ft{transition:transform .12s;}
.mm-play:active{transform:translateY(3px);}
@keyframes mmGlow{0%,100%{box-shadow:0 0 0 1.8px #4a1f04,0 4px 0 1.8px #4a1f04,0 0 6px 1px rgba(255,214,110,.45),inset 0 1.5px 0 rgba(255,255,255,.6),inset 0 -4px 8px rgba(120,50,0,.35);}50%{box-shadow:0 0 0 1.8px #4a1f04,0 4px 0 1.8px #4a1f04,0 0 20px 7px rgba(255,214,110,.9),inset 0 1.5px 0 rgba(255,255,255,.6),inset 0 -4px 8px rgba(120,50,0,.35);}}
/* ---- level: the crest + tier + next room ---- */
.mm-lv{position:absolute;right:10px;bottom:6px;display:flex;align-items:flex-end;gap:0;cursor:pointer;}
.mm-lv .tag{display:flex;flex-direction:column;align-items:flex-end;gap:8px;margin-bottom:14px;}
.mm-lv .h{height:24px;padding:0 13px;display:flex;align-items:center;font-size:12px;cursor:pointer;}
.mm-lv .n{height:22px;padding:0 11px;display:flex;align-items:center;gap:4px;font-size:11px;cursor:pointer;}
.mm-crest{width:112px;height:97px;filter:drop-shadow(0 4px 4px rgba(20,0,50,.45));}
/* ---- nameplate ---- */
.mm-name{position:absolute;transform:translateX(-50%);pointer-events:none;}
.mm-name .mm-p{height:30px;padding:0 18px;display:flex;align-items:center;justify-content:center;cursor:default;}
.mm-name .mm-ft{margin:-6px 0 -5px;}
.mm-name .pips{position:absolute;left:50%;top:-9px;transform:translateX(-50%);display:flex;gap:1px;}
.mm-name .pips svg{width:12px;height:12px;filter:drop-shadow(0 1px 0 var(--ink));}
/* ---- full-screen pages (mini games, game, creature picker) ---- */
.mm-page2{position:absolute;inset:0;pointer-events:auto;overflow:hidden;background:var(--dia),radial-gradient(120% 120% at 50% 0%,#8a46ec 0%,#5a1cb8 40%,#2e0a6e 80%,#1e0650 100%);animation:mmPage .42s cubic-bezier(.2,.9,.25,1);}
.mm-page2::before{content:'';position:absolute;inset:0;background:repeating-conic-gradient(from 0deg at 50% -10%,rgba(255,230,160,.07) 0 6deg,transparent 6deg 18deg);pointer-events:none;}
@keyframes mmPage{from{opacity:0;transform:scale(1.06);}to{opacity:1;transform:none;}}
.mm-pg{position:absolute;left:0;top:0;width:852px;height:393px;transform-origin:0 0;}
.mm-pgh{position:absolute;left:16px;right:16px;top:12px;height:46px;display:flex;align-items:center;gap:12px;}
.mm-pgh .s{font:700 11.5px Nunito,sans-serif;color:#e4d4ff;}
.mm-gr{position:absolute;left:0;right:0;top:70px;bottom:0;display:flex;gap:16px;overflow-x:auto;overflow-y:hidden;padding:14px 22px 22px;scroll-snap-type:x proximity;scrollbar-width:none;}
.mm-gr::-webkit-scrollbar{display:none;}
.mm-gc{flex:none;width:162px;height:276px;scroll-snap-align:start;position:relative;display:flex;flex-direction:column;align-items:center;padding:8px 8px 10px;border-radius:22px;border-width:3.5px;cursor:pointer;transition:transform .15s;}
.mm-gc:hover{transform:translateY(-4px);}
.mm-gc.mm-p{background:var(--spk) padding-box,var(--dia) padding-box,linear-gradient(180deg,var(--gcl) 0%,var(--gc) 45%,var(--gcd) 100%) padding-box,var(--rimG) border-box;box-shadow:0 0 0 2px var(--ink),0 5px 0 2px var(--ink),0 12px 22px rgba(10,0,40,.5),inset 0 0 0 1.5px rgba(255,236,170,.6);}
.mm-gc .win{width:100%;height:104px;border-radius:14px;overflow:hidden;position:relative;box-shadow:0 0 0 2px var(--ink),0 0 0 4.5px #ffd76a,0 0 0 6px var(--ink),inset 0 -6px 10px rgba(0,0,0,.2);background:#cfeaff;}
.mm-gc .win svg,.mm-gc .win img{width:100%;height:100%;display:block;object-fit:cover;}
.mm-gc .nm{margin:12px 0 0;}
.mm-gc .it{font:700 10.5px Nunito,sans-serif;color:#fff;opacity:.9;text-shadow:0 1px 1px rgba(0,0,0,.35);}
.mm-gc .best{margin-top:7px;padding:2px 9px;border-radius:999px;background:rgba(30,0,60,.35);box-shadow:inset 0 0 0 1px rgba(255,236,170,.6);font:800 10px Nunito,sans-serif;color:#ffe9a8;}
.mm-gc .go{margin-top:auto;width:84%;height:34px;border-radius:12px;display:flex;align-items:center;justify-content:center;}
.mm-gc.lock{filter:saturate(.25) brightness(.8);}
.mm-gc .lockv{position:absolute;inset:0;border-radius:18px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;background:rgba(30,6,70,.55);font:700 12px Fredoka,sans-serif;color:#fff;text-align:center;padding:0 10px;}
.mm-gc .lockv svg{width:34px;height:34px;}
.mm-gc.feat{width:196px;}
.mm-gp{position:absolute;inset:0;display:flex;align-items:stretch;justify-content:center;}
.mm-gp .side{flex:1;min-width:0;display:flex;flex-direction:column;padding:14px 16px;gap:10px;color:#fff;}
.mm-gp .side.r{align-items:flex-start;}
.mm-gp .mid{flex:none;height:100%;aspect-ratio:360/640;padding:8px 0;box-sizing:border-box;}
.mm-gp .mid .yg-root{min-height:0;height:100%;padding:0;background:none;display:flex;align-items:center;justify-content:center;}
.mm-gp .mid .yg-frame{height:100%;width:auto;max-width:none;box-shadow:0 0 0 4px #ffd76a,0 0 0 6px #3d1268,0 14px 30px rgba(0,0,0,.45);}
.mm-gp .how{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:7px;font:700 11.5px Nunito,sans-serif;color:#efe6ff;}
.mm-gp .how li{padding:7px 10px;border-radius:12px;background:rgba(255,255,255,.08);box-shadow:inset 0 0 0 1px rgba(255,236,170,.35);}
.mm-gp .bst{padding:4px 12px;border-radius:999px;font-size:12px;}
.mm-gp.land .side{display:none;}
.mm-gp.land .mid{flex:1;aspect-ratio:auto;padding:6px;display:flex;align-items:center;justify-content:center;}
.mm-pick .box{width:720px;height:340px;border-radius:24px;border-width:4px;display:flex;flex-direction:column;overflow:visible;cursor:default;}
.mm-pick{position:absolute;inset:0;background:rgba(24,8,40,.6);display:flex;align-items:center;justify-content:center;animation:mmIn .18s ease-out;pointer-events:auto;}
.mm-pick .hd{display:flex;align-items:center;gap:10px;padding:10px 16px 8px;}
.mm-pick .hd small{font:700 11.5px Nunito,sans-serif;color:#e8dcff;}
.mm-pick .hd .mm-orb{margin-left:auto;width:34px;height:34px;}
.mm-pick .gr{flex:1;overflow:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(82px,1fr));gap:10px 8px;padding:6px 16px 16px;scrollbar-width:thin;}
.mm-pick .it{position:relative;width:100%;aspect-ratio:1696/2528;border:0;padding:0;background:none;cursor:pointer;container-type:inline-size;}
.mm-pick .it img{position:absolute;pointer-events:none;}
.mm-pick .it .nmT{position:absolute;display:flex;align-items:center;justify-content:center;text-align:center;font:700 9cqw/1 Fredoka,sans-serif;}
.mm-pick .it.on::before{content:'';position:absolute;left:7%;right:7%;top:3%;bottom:2.5%;border-radius:10% / 7%;background:#ffd24a;box-shadow:0 0 0 3px #ffd24a,0 0 18px 6px rgba(255,210,74,.75);}
.mm-pick .it:hover{transform:translateY(-2px);}
.mm-toast{position:absolute;left:50%;top:60px;transform:translateX(-50%);max-width:70%;padding:5px 18px;font:700 13px Fredoka,sans-serif;text-align:center;animation:mmToast 2.4s ease forwards;pointer-events:none;cursor:default;}
@keyframes mmIn{from{opacity:0;transform:translateY(8px) scale(.98);}to{opacity:1;transform:none;}}
@keyframes mmToast{0%{opacity:0;transform:translate(-50%,-8px);}10%,85%{opacity:1;transform:translate(-50%,0);}100%{opacity:0;}}
.mm-sh{position:absolute;left:0;right:0;top:64px;bottom:0;display:flex;gap:16px;padding:8px 18px 14px 20px;}
.mm-fc{flex:none;width:178px;border-radius:22px;border-width:3.5px;display:flex;flex-direction:column;align-items:center;padding:20px 10px 12px;cursor:default;}
.mm-fc.mm-p,.mm-cc.mm-p{box-shadow:0 0 0 2px var(--ink),0 5px 0 2px var(--ink),0 12px 22px rgba(10,0,40,.5),inset 0 0 0 1.5px rgba(255,236,170,.6);}
.mm-fc .rib,.mm-cc .rib{position:absolute;left:50%;top:-12px;transform:translateX(-50%);white-space:nowrap;height:22px;padding:0 12px;display:flex;align-items:center;font:700 11px Fredoka,sans-serif;letter-spacing:1px;cursor:default;}
.mm-fc .win,.mm-cc .win{position:relative;width:100%;height:118px;border-radius:14px;overflow:hidden;box-shadow:0 0 0 2px var(--ink),0 0 0 4.5px #ffd76a,0 0 0 6px var(--ink),inset 0 -6px 10px rgba(0,0,0,.25);
  background:radial-gradient(circle at 50% 42%,rgba(255,250,232,.95) 0,rgba(255,250,232,0) 56%),radial-gradient(120% 120% at 50% 0%,#a46cff 0%,#5a1cb8 70%);}
.mm-fc canvas,.mm-cc canvas{position:absolute;inset:0;width:100%;height:100%;display:block;}
.mm-fc .t1{margin-top:12px;font:800 11px Nunito,sans-serif;color:#ffe9a8;letter-spacing:1px;}
.mm-fc .t2{margin:2px 0 0;font:700 11.5px Nunito,sans-serif;color:#efe6ff;text-align:center;}
.mm-fc .go,.mm-cc .go{margin-top:auto;width:92%;height:36px;border-radius:12px;display:flex;align-items:center;justify-content:center;gap:5px;}
.mm-fc .go.wait{filter:saturate(.3) brightness(.9);cursor:default;}
.mm-fc .go.wait span{font:800 12.5px Nunito,sans-serif;color:var(--ink);}
.mm-sg{flex:1;min-width:0;display:flex;gap:16px;overflow-x:auto;overflow-y:hidden;padding:12px 6px 10px;scroll-snap-type:x proximity;scrollbar-width:none;}
.mm-sg::-webkit-scrollbar{display:none;}
.mm-cc{flex:none;width:166px;scroll-snap-align:start;position:relative;display:flex;flex-direction:column;align-items:center;padding:16px 9px 11px;border-radius:22px;border-width:3.5px;cursor:default;}
.mm-cc.mm-p{background:var(--spk) padding-box,var(--dia) padding-box,linear-gradient(180deg,var(--gcl) 0%,var(--gc) 45%,var(--gcd) 100%) padding-box,var(--rimG) border-box;}
.mm-cc .nm{margin:2px 0 6px;height:24px;display:flex;align-items:center;}
.mm-cc .cn{margin-top:8px;font:800 11px Nunito,sans-serif;color:#fff;text-shadow:0 1px 0 var(--ink),1px 0 0 var(--ink),-1px 0 0 var(--ink),0 -1px 0 var(--ink);}
.mm-cc .tiers{display:flex;gap:5px;margin:7px 0 4px;}
.mm-cc .tiers button{width:22px;height:22px;border-radius:50%;border:0;padding:0;cursor:pointer;font:700 10px Fredoka,sans-serif;color:#fff;text-shadow:0 1px 0 rgba(0,0,0,.45);box-shadow:0 0 0 1.5px var(--ink),0 2px 0 1.5px var(--ink);}
.mm-cc .tiers button.on{transform:translateY(-2px) scale(1.12);box-shadow:0 0 0 1.5px var(--ink),0 0 0 4px #ffe27a,0 0 0 5.5px var(--ink),0 0 10px 3px rgba(255,214,110,.8);}
.mm-cc .od{font:700 10px Nunito,sans-serif;color:#fff;opacity:.92;text-shadow:0 1px 1px rgba(0,0,0,.4);margin-bottom:6px;}
.mm-cc .go img,.mm-fc .go img{width:24px;height:24px;margin:-4px 0 -4px -4px;filter:drop-shadow(0 1.5px 1px rgba(30,0,40,.45));}
/* v11 the crib palette (the house drawer's pull tab): honey wood + plank lines, cream paper, brass, brown ink */
.mm-crib{--ink:#6b4426;--wood:repeating-linear-gradient(90deg,rgba(107,68,38,.12) 0 2px,transparent 2px 18px),linear-gradient(180deg,#ffe9a0 0%,#e2b14a 100%);--wood2:repeating-linear-gradient(90deg,rgba(107,68,38,.12) 0 2px,transparent 2px 18px),linear-gradient(180deg,#e6b47c 0%,#c98d52 100%);}
.mm-page2.mm-crib{background:radial-gradient(80% 90% at 50% 0%,rgba(255,236,190,.5) 0%,rgba(255,236,190,0) 65%),repeating-linear-gradient(90deg,rgba(80,44,18,.22) 0 2.5px,transparent 2.5px 58px),repeating-linear-gradient(90deg,rgba(255,230,190,.08) 3px 5px,transparent 5px 58px),linear-gradient(180deg,#d6a06a 0%,#b97c44 55%,#94602e 100%);}
.mm-page2.mm-crib::before{display:none;}
.mm-crib .mm-orb{border:2.5px solid #6b4426;background:radial-gradient(circle at 35% 30%,#fffbe8 0 12%,#ffe9a0 40%,#e2b14a 100%);box-shadow:0 3px 0 #6b4426,0 6px 10px rgba(60,30,10,.35),inset 0 2px 0 rgba(255,255,255,.6);}
.mm-crib .mm-orb svg{filter:none;}.mm-crib .mm-orb svg path{stroke:#6b4426;}
.mm-crib .mm-pill.mm-p{border:2.5px solid #6b4426;background:#fff6e2;box-shadow:0 3px 0 #6b4426,0 6px 10px rgba(60,30,10,.3);}
.mm-crib .mm-pill.mm-p::before,.mm-crib .mm-pill.mm-p::after{display:none;}
.mm-crib .tx-w{color:#3b2818;text-shadow:none;}
.mm-crib .mm-pgh .s{color:#fff6e2;text-shadow:0 1.5px 0 #6b4426,1px 0 0 #6b4426,-1px 0 0 #6b4426;}
.mm-crib .mm-gem{display:none;}
.mm-crib .mm-fc.mm-p{border:3px solid #6b4426;background:var(--wood);box-shadow:0 4px 0 #6b4426,0 12px 20px rgba(60,30,10,.4),inset 0 2px 0 rgba(255,255,255,.55);}
.mm-crib .mm-cc.mm-p{border:3px solid #6b4426;background:var(--wood2);box-shadow:0 4px 0 #6b4426,0 12px 20px rgba(60,30,10,.4),inset 0 2px 0 rgba(255,240,210,.55);}
.mm-crib .mm-cc .nm{padding:0 9px;border-radius:9px;background:var(--gc);border:2px solid #6b4426;box-shadow:inset 0 2px 0 rgba(255,255,255,.35);}
.mm-crib .rib.mm-p{border:2px solid #6b4426;background:#fff6e2;color:#3b2818;box-shadow:0 2px 0 #6b4426;}
.mm-crib .rib.mm-p::before,.mm-crib .rib.mm-p::after{display:none;}
.mm-crib .rib.v-gold{background:linear-gradient(180deg,#fff3c4,#ffd23f);}
.mm-crib .win{background:radial-gradient(circle at 50% 42%,#fffdf2 0,#f6e6c0 62%,#e8cf9a 100%) !important;box-shadow:0 0 0 2.5px #6b4426,inset 0 -6px 10px rgba(107,68,38,.22) !important;}
.mm-crib .mm-fc .t1{color:#6b4426;}.mm-crib .mm-fc .t2{color:#3b2818;}
.mm-crib .mm-cc .cn,.mm-crib .mm-cc .od{color:#3b2818;text-shadow:none;}
.mm-crib .go.mm-p{border:2.5px solid #6b4426;background:repeating-linear-gradient(90deg,rgba(107,68,38,.12) 0 2px,transparent 2px 18px),linear-gradient(180deg,#fff3c4 0%,#ffd23f 55%,#e2a12a 100%);box-shadow:0 3px 0 #6b4426,inset 0 2px 0 rgba(255,255,255,.65);}
.mm-crib .go.mm-p::before,.mm-crib .go.mm-p::after{display:none;}
.mm-crib .go.wait{background:#fff6e2;filter:none;}
.mm-crib .mm-cc .tiers button{box-shadow:0 0 0 1.5px #6b4426,0 2px 0 1.5px #6b4426;}
.mm-crib .mm-cc .tiers button.on{box-shadow:0 0 0 1.5px #6b4426,0 0 0 4px #fff6e2,0 0 0 5.5px #6b4426,0 0 10px 3px rgba(255,214,110,.8);}
.mm-pick.mm-crib{background:rgba(60,30,10,.55);}
.mm-pick.mm-crib .box.mm-p{border:3.5px solid #6b4426;background:var(--wood2);box-shadow:0 5px 0 #6b4426,0 18px 30px rgba(40,20,5,.5),inset 0 2px 0 rgba(255,240,210,.55);}
.mm-pick.mm-crib .hd small{color:#3b2818;}
.mm-pick.mm-crib .gr{scrollbar-color:#6b4426 transparent;}
@media (prefers-reduced-motion: reduce){.mm-play{animation:none;}.mm-page2{animation:none;}}
`; document.head.appendChild(s);
  }
  const ic = (d, c, w) => '<svg viewBox="0 0 24 24" fill="none" stroke="' + (c || 'currentColor') + '" stroke-width="' + (w || 2.2) + '" stroke-linecap="round" stroke-linejoin="round"><path d="' + d + '"/></svg>';
  const LOCK = '<svg viewBox="0 0 16 16" width="11" height="11"><path d="M4.5 7V5a3.5 3.5 0 0 1 7 0v2" stroke="#3d1268" stroke-width="1.8" fill="none"/><rect x="2.5" y="7" width="11" height="8" rx="2" fill="#ffd54a" stroke="#3d1268" stroke-width="1.2"/></svg>';
  const STAR = '<svg viewBox="0 0 24 24"><path d="M12 2.5l2.9 6 6.6.8-4.9 4.5 1.3 6.5L12 17l-5.9 3.3 1.3-6.5L2.5 9.3l6.6-.8Z" fill="#ffc928" stroke="#5a2a06" stroke-width="1.6" stroke-linejoin="round"/><path d="M9.4 8.6 12 4.6l1.4 2.9" stroke="#fff6c0" stroke-width="1.4" fill="none" stroke-linecap="round"/></svg>';
  const GEAR = 'M12 8.5a3.5 3.5 0 1 0 .01 0Z M19.4 13a7.6 7.6 0 0 0 0-2l2-1.6-2-3.4-2.4 1a7.4 7.4 0 0 0-1.7-1L15 3.5h-4l-.4 2.5a7.4 7.4 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.6a7.6 7.6 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7.4 7.4 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.4 7.4 0 0 0 1.7-1l2.4 1 2-3.4Z';
  const HOUSE = 'M3 11.5 12 4l9 7.5 M5.5 10.5V20h13v-9.5 M10 20v-5h4v5';
  const BACK = 'M15 5L8 12L15 19';
  const PLQ = ['v-wood', 'v-bronze', 'v-amy', 'v-gold', 'v-rainbow'], NFT = ['wood', 'bronze', 'amethyst', 'whiteB', 'white'];   // nameplate plaque + lettering per rarity (common .. rainbow)
  const gems = () => '<i class="mm-gem" style="left:-9px;top:-9px"></i><i class="mm-gem" style="right:-9px;top:-9px"></i><i class="mm-gem" style="left:-9px;bottom:-9px"></i><i class="mm-gem" style="right:-9px;bottom:-9px"></i>';
  const STARG = '<svg class="star" viewBox="0 0 40 40"><defs><linearGradient id="mmsg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fffbe0"/><stop offset="0.45" stop-color="#ffd24a"/><stop offset="1" stop-color="#e08a10"/></linearGradient></defs><path d="M20 2 l5.4 11.2 12.3 1.7 -8.9 8.6 2.1 12.2 -10.9 -5.9 -10.9 5.9 2.1 -12.2 -8.9 -8.6 12.3 -1.7Z" fill="url(#mmsg)" stroke="#3d1268" stroke-width="2.4" stroke-linejoin="round"/><path d="M15 15 l5 -8 2.6 5.2" stroke="#fffbe6" stroke-width="2" fill="none" stroke-linecap="round"/></svg>';
  const shade = (c, k) => { const n = parseInt(c.slice(1), 16), f = v => Math.max(0, Math.min(255, Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k))); return '#' + [n >> 16 & 255, n >> 8 & 255, n & 255].map(v => f(v).toString(16).padStart(2, '0')).join(''); };
  const tween = (ms, fn, ease) => new Promise(res => { const t0 = performance.now(), E = ease || (t => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2); const step = () => { const t = Math.min(1, (performance.now() - t0) / ms); fn(E(t), t); if (t < 1) requestAnimationFrame(step); else res(); }; requestAnimationFrame(step); });
  const easeIn = t => t * t * t, easeOut = t => 1 - Math.pow(1 - t, 3);

  function mount(host, opts) {
    opts = opts || {}; addCss(); const Sc = window.MainMenuScene, Q = window.SquishSquad, Lb = window.SquadLobby;
    const saved = LS.get(KEY) || {}; let season = opts.season || saved.season || 'auto', preview = opts.preview != null ? opts.preview : null, ctrl = null, sh = null, curKey = null, toastT = 0, st = null, k = 1, busy = false, inside = false, page = null, ygApp = null;
    const root = document.createElement('div'); root.className = 'mm-root'; host.innerHTML = ''; host.appendChild(root);
    let test = null;
    if (!opts.bare) { test = document.createElement('div'); test.className = 'mm-test'; root.appendChild(test); }
    const frame = document.createElement('div'); frame.className = 'mm-frame'; root.appendChild(frame);
    if (opts.bare) frame.style.cssText = 'width:100%;height:100%;'; else frame.style.cssText = 'width:min(852px, calc(100vw - 24px));aspect-ratio:852/393;border-radius:34px;box-shadow:0 0 0 9px #1c0a38,0 30px 80px rgba(60,20,120,.35);';
    if (opts.bare) root.style.cssText = 'width:100%;height:100%;';
    const world = document.createElement('div'); world.className = 'mm-world'; frame.appendChild(world);
    const scene = document.createElement('div'); scene.className = 'mm-scene'; world.appendChild(scene);
    const hots = document.createElement('div'); hots.className = 'mm-fade'; hots.style.cssText = 'position:absolute;inset:0;'; world.appendChild(hots);
    const stage = document.createElement('div'); stage.className = 'mm-stage'; world.appendChild(stage);
    const name = document.createElement('div'); name.className = 'mm-name mm-fade'; world.appendChild(name);
    const veil = document.createElement('div'); veil.className = 'mm-veil'; frame.appendChild(veil);
    const hud = document.createElement('div'); hud.className = 'mm-hud mm-fade'; frame.appendChild(hud);
    const ov = document.createElement('div'); ov.style.cssText = 'position:absolute;inset:0;pointer-events:none;'; frame.appendChild(ov);

    const level = () => { try { return window.SquishProfile ? window.SquishProfile.get().level || 1 : 1; } catch (e) { return 1; } };
    const selId = () => preview != null ? preview : Lb ? Lb.selected() : 1;
    const cre = () => Q && Q.ROSTER[selId()];
    const save = () => LS.set(KEY, { season });
    const games = () => [SQUISH].concat((window.YardGames && window.YardGames.GAMES) || []);
    const open = G => G.id === 'squish' || !!(st && st.open.backyard);
    const yb = () => { try { return (JSON.parse(localStorage.getItem('yardgames.v1') || '{}').best) || {}; } catch (e) { return {}; } };
    function toast(t) { const d = document.createElement('div'); d.className = 'mm-toast mm-p tip v-gold'; d.textContent = t; if (page) { const pg = page.querySelector('.mm-pg'); (pg || hud).appendChild(d); d.style.zIndex = 30; d.style.top = '50px'; } else hud.appendChild(d); clearTimeout(toastT); toastT = setTimeout(() => d.remove(), 2400); }

    // ---- layout: viewBox (1000 x 460, xMidYMax slice) -> frame px ----
    let geo = null;
    function layout() {
      const W = frame.clientWidth, H = frame.clientHeight; if (!W || !H) return; const s = Math.max(W / 1000, H / 460), ox = (W - 1000 * s) / 2, oy = H - 460 * s; geo = { W, H, s, ox, oy, X: x => ox + x * s, Y: y => oy + y * s };
      k = H / 393; [hud, ...ov.querySelectorAll('.mm-pg')].forEach(e => { e.style.transform = 'scale(' + k + ')'; e.style.width = (W / k) + 'px'; }); hud.classList.toggle('mm-narrow', W / k < 770);
      // the creature: 12% smaller than before (0.5 -> 0.44 of the frame height), feet on the pad centre (500, 421)
      const S = H * 0.44, fx = geo.X(500), fy = geo.Y(421);
      if (!busy && !inside) stage.style.cssText = 'left:' + (fx - S / 2) + 'px;top:' + (fy - S * 0.955) + 'px;width:' + S + 'px;height:' + S + 'px;';
      name.style.left = fx + 'px'; name.style.top = (H - 38 * k) + 'px'; name.style.transform = 'translateX(-50%) scale(' + k + ')'; name.style.transformOrigin = '50% 0';
      world.style.transformOrigin = geo.X(Sc.DOOR[0]) + 'px ' + geo.Y(Sc.DOOR[1]) + 'px';
      veil.style.background = 'radial-gradient(circle at ' + geo.X(Sc.DOOR[0]) + 'px ' + geo.Y(Sc.DOOR[1]) + 'px, #fffdf0 0%, #ffe9a8 40%, #ffc25e 100%)';
      placeHots();
    }
    function placeHots() {
      if (!geo || !st) return; hots.innerHTML = '';
      Object.keys(Sc.AREAS).forEach(rk => { const [x, y, w, h] = Sc.AREAS[rk], R = Sc.ROOMS[rk], op = st.open[rk], b = document.createElement('div'); b.className = 'mm-hot';
        b.style.cssText = 'left:' + geo.X(x) + 'px;top:' + geo.Y(y) + 'px;width:' + w * geo.s + 'px;height:' + h * geo.s + 'px;';
        const cx = geo.X(x + w / 2), side = cx > geo.W - 150 * k ? 'right:0;left:auto;transform:scale(' + k + ');transform-origin:100% 100%' : cx < 150 * k ? 'left:0;transform:scale(' + k + ');transform-origin:0 100%' : 'transform:translateX(-50%) scale(' + k + ');transform-origin:50% 100%'; // labels near an edge stay on screen
        b.innerHTML = '<div class="lab mm-p tip ' + (op ? 'v-gold' : 'v-vel tx-w') + '" style="' + side + '">' + (op ? R.n + ' · tap to go in' : R.n + ' · opens at Lv ' + R.lv) + '</div>';
        b.onclick = () => { [...hots.children].forEach(c => c.classList.remove('on')); b.classList.add('on'); setTimeout(() => b.classList.remove('on'), 1600);
          if (!op) toast(R.n + ' opens at level ' + R.lv); else goHome(rk); };
        hots.appendChild(b); });
    }

    // ---- the scene ----
    function draw() { st = Sc.state({ level: level(), season: season === 'auto' ? null : season }); scene.innerHTML = Sc.svg(st); placeHots(); hudDraw(); testDraw(); lightRig(); }

    // ---- scene light on the creature (Nov 13, user: 'add shadow on the characters body so when they are on the map they look like they are part of it
    // - start with mittens'): rive-rig's ctrl.light - shade on the side away from the light, darker towards the feet, a sunlit rim, the scene's colour
    // cast over him, a cast shadow on the pad. Light per season: sunny = low sun from the upper left (warm), rainy = overcast from above (cool, soft),
    // snowy = cold sun + bright bounce off the snow; the run-down look (low level) mutes him a little like the faded scene.
    const LIT = { has: () => true };   // Nov 14 v8: every creature gets the scene light (was Mittens only)
    function lightFor(s) {
      const v = s ? s.v : 1, sea = s ? s.season : 'sunny';
      // Nov 14 v6: Club-Penguin-style shading (rive-rig v1114b, user's reference = the classic Club Penguin penguin): each part shaded as its own ball (smooth,
      // darker toward its far edge, soft highlight toward the light) + hard cast shadows under the chin / arms / on the feet; no colour wash over him by day
      // (it made him look muddy) - the season's colour goes into the shadow instead
      // Nov 14 v8 (user picked the 'Bolder, Colour line' look, for all characters): no cast shadow on the ground (plain contact shadow) + an outline in a darker
      // version of each shape's own colour (rive-rig v1115a picks it per shape when no lineC is given); each part's shade is a darker version of its own colour,
      // cooled toward the weather's colour in rain / snow (shMix)
      const LOOKD = { line: 1.05, cast: 0, contact: 1 };
      const L = Object.assign(sea === 'rainy' ? { dir: [0.3, 1], sh: 0.46, shC: '#3a3f5e', shMix: 0.4, rim: 0.24, rimC: '#eef4ff', castC: '#1e2630' }
        : sea === 'snowy' ? { dir: [0.75, 0.55], sh: 0.46, shC: '#3f4c8a', shMix: 0.35, rim: 0.45, rimC: '#ffffff', castC: '#28345a' }
        : { dir: [0.75, 0.55], sh: 0.54, rim: 0.45, rimC: '#fff4dc', castC: '#2a1820' }, LOOKD);
      if (v < 0.3) L.sh *= 0.9;   // the run-down scene is a little flatter / more overcast
      return L;
    }
    function lightRig() { if (ctrl && ctrl.light) ctrl.light(LIT.has(curKey) ? lightFor(st) : null); }

    // ---- the creature ----
    function mountRig() {
      const c = cre(); if (!c || !window.RiveRig) return; if (c.key === curKey && ctrl) { nameDraw(); return; }
      if (sh) sh.stop(); if (ctrl) ctrl.destroy(); curKey = c.key;
      if (!sh && window.RigShuffle) sh = window.RigShuffle();
      const me = window.RiveRig.mount(stage, c.key, { onState: a => { if (sh && ctrl === me && !busy && !inside) sh.onState(a); } }); ctrl = me; if (sh) sh.attach(ctrl);
      const wrap = stage.firstChild; if (wrap) { wrap.style.pointerEvents = 'none'; const hit = document.createElement('div'); hit.className = 'mm-hit'; wrap.appendChild(hit); }
      lightRig(); nameDraw();
    }
    function nameDraw() {
      const c = cre(); if (!c) { name.innerHTML = ''; return; } const r = Math.max(0, Math.min(4, c.rar | 0));
      name.innerHTML = '<div class="mm-p tip ' + PLQ[r] + '"><div class="pips">' + STAR.repeat(r + 1) + '</div>' + ft(c.name, NFT[r], 19) + '</div>'; fitFT(name);
    }

    // ---- HUD ----
    function hudDraw() {
      if (!st) return; const W = Q ? Q.wallet() : { coins: 0, gems: 0 }, SC = window.SquishCoin, G = games(), nOpen = G.filter(open).length;
      const tab = (id, label, d, cls) => '<button class="mm-tab mm-p tip ' + cls + '" data-tab="' + id + '">' + ic(d, cls === 'v-gold' ? '#3d1268' : '#fff', 2.5) + '<span' + (cls === 'v-gold' ? '' : ' class="tx-w"') + '>' + label + '</span></button>';
      hud.innerHTML = '<div class="mm-top">' + ft('SQUAD', 'gold', 30, 'mm-logo') + '<div class="mm-tabs">'
        + tab('house', 'MY HOUSE', HOUSE, 'v-gold') + tab('creatures', 'CREATURES', 'M4 4h7v7H4Z M13 4h7v7h-7Z M4 13h7v7H4Z M13 13h7v7h-7Z', 'v-vel') + tab('shop', 'SHOP', 'M4 9h16l-1.5 11h-13Z M8 9V7a4 4 0 0 1 8 0v2', 'v-vel') + tab('games', 'GAMES', 'M6 9h12a3 3 0 0 1 3 3v2a3 3 0 0 1-5.4 1.8L14.5 14h-5l-1.1 1.8A3 3 0 0 1 3 14v-2a3 3 0 0 1 3-3Z M8 11v3 M6.5 12.5h3', 'v-vel')
        + '</div><div class="mm-sp"></div>'
        + '<div class="mm-pill mm-p tip v-vel" data-act="shop"><img alt="" src="' + ((SC && SC.coin(0)) || BL) + '"><span class="tx-w">' + fmt(W.coins) + '</span></div>'
        + '<div class="mm-pill mm-p tip v-vel" data-act="shop"><img alt="" src="' + ((SC && SC.gem(0)) || BL) + '"><span class="tx-w">' + fmt(W.gems) + '</span></div>'
        + '<button class="mm-orb" data-act="settings" aria-label="Settings">' + ic(GEAR, '#fff', 2.2) + '</button></div>'
        + '<div class="mm-card mm-p v-vel">' + STARG + gems() + '<div class="k">LET\'S PLAY</div><div class="ttl">' + ft('Mini Games', 'gold', 21) + '</div>'
        + '<div class="sub">' + (nOpen === G.length ? 'All ' + G.length + ' games ready!' : nOpen + ' ready · ' + (G.length - nOpen) + ' open at Lv ' + Sc.ROOMS.backyard.lv) + '</div>'
        + '<div class="icons">' + G.slice(0, 8).map(g => '<i class="' + (open(g) ? '' : 'lk') + '" title="' + esc(g.name) + '">' + (g.icon || squishIcon()) + '</i>').join('') + '</div>'
        + '<button class="mm-play mm-p tip v-gold" data-act="play" aria-label="Play">' + ft('PLAY', 'whiteB', 30) + '</button></div>'
        + '<div class="mm-lv"><div class="tag"><div class="h mm-p tip v-gold" data-act="house">' + st.tierName + '</div>' + (st.next ? '<div class="n mm-p tip v-vel" data-act="house"><span class="tx-w" style="display:flex;align-items:center;gap:4px">' + LOCK + 'Next: ' + st.next.name + ' · Lv ' + st.next.lv + '</span></div>' : '<div class="n mm-p tip v-vel" data-act="house"><span class="tx-w">Every room is open!</span></div>') + '</div><div data-act="house">' + crest(st.L) + '</div></div>';
      fitFT(hud);
      hud.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { const t = b.dataset.tab; if (t === 'creatures') openPicker(); else if (t === 'games') openGames(); else if (t === 'house') goHome('living'); else if (t === 'shop') { if (opts.onShop) opts.onShop(); else openShop(); } });
      hud.querySelectorAll('[data-act]').forEach(b => b.onclick = () => { const a = b.dataset.act;
        if (a === 'play') openGames();
        else if (a === 'shop') { if (opts.onShop) opts.onShop(); else openShop(); }
        else if (a === 'settings') { if (opts.onSettings) opts.onSettings(); else toast('Settings open in the full app'); }
        else if (a === 'house') goHome('living'); });
    }
    function squishIcon() { const c = cre(), s = c && Q.src(c.id), T = window.SQ_THUMBS || {}; return '<svg viewBox="0 0 120 84"><defs><radialGradient id="mmsq' + (++UID) + '" cx="0.5" cy="0.4"><stop offset="0" stop-color="#ffe3f6"/><stop offset="1" stop-color="#ff8fd6"/></radialGradient></defs><rect width="120" height="84" fill="url(#mmsq' + UID + ')"/>' + (s ? '<image href="' + (T[s] || s) + '" x="22" y="6" width="76" height="76" preserveAspectRatio="xMidYMid meet"/>' : '') + '<path d="M14 30 q-6 12 0 24 M106 30 q6 12 0 24 M20 36 q-3 6 0 12 M100 36 q3 6 0 12" stroke="#ffffff" stroke-width="3" fill="none" stroke-linecap="round"/></svg>'; }

    // ---- full-screen pages ----
    function pageOpen(html) { closePage(); page = document.createElement('div'); page.className = 'mm-page2'; page.innerHTML = '<div class="mm-pg" style="transform:scale(' + k + ');width:' + (geo.W / k) + 'px">' + html + '</div>'; ov.appendChild(page); fitFT(page); return page; }
    function closePage() { if (ygApp) { try { const ex = ygApp.root && ygApp.root.parentNode; ygApp.hub && ygApp.hub(); if (ex) ex.innerHTML = ''; } catch (e) {} ygApp = null; } if (page) { page.remove(); page = null; } }
    function openGames() {
      if (busy || inside) return; const G = games(), B = yb(), c = cre();
      const card = g => { const op = open(g), col = g.color || '#ff8a3d', feat = g.id === 'squish';
        return '<div class="mm-gc mm-p' + (feat ? ' feat' : '') + (op ? '' : ' lock') + '" data-g="' + g.id + '" style="--gc:' + col + ';--gcl:' + shade(col, 0.35) + ';--gcd:' + shade(col, -0.42) + '">'
          + '<div class="win">' + (feat ? squishIcon() : g.icon || '') + '</div><div class="nm">' + ft(g.name, 'white', 17) + '</div><div class="it">' + esc(g.item || '') + '</div>'
          + (feat ? '<div class="best">Playing as ' + esc(c ? c.name : '') + '</div>' : '<div class="best">' + (B[g.id] ? '★ Best ' + B[g.id] : 'New!') + '</div>')
          + '<button class="go mm-p tip v-gold">' + ft('PLAY', 'whiteB', 17) + '</button>'
          + (op ? '' : '<div class="lockv">' + LOCK.replace('width="11" height="11"', 'width="34" height="34"') + '<span>Opens with the Backyard<br>at level ' + Sc.ROOMS.backyard.lv + '</span></div>') + '</div>'; };
      const p = pageOpen('<div class="mm-pgh"><button class="mm-orb" data-x aria-label="Back">' + ic(BACK, '#fff', 3) + '</button>' + ft('Mini Games', 'gold', 30) + '<div class="s">' + G.filter(open).length + ' of ' + G.length + ' ready · your creature plays every game</div><div class="mm-sp"></div>'
        + '<div class="mm-pill mm-p tip v-vel"><img alt="" src="' + ((window.SquishCoin && window.SquishCoin.coin(0)) || BL) + '"><span class="tx-w">' + fmt(Q ? Q.wallet().coins : 0) + '</span></div></div>'
        + '<div class="mm-gr">' + G.map(card).join('') + '</div>');
      p.querySelector('[data-x]').onclick = () => closePage();
      p.querySelectorAll('[data-g]').forEach(el => el.onclick = () => { const g = G.find(x => x.id === el.dataset.g); if (!open(g)) { toast(g.name + ' opens with the Backyard at level ' + Sc.ROOMS.backyard.lv); return; } playGame(g); });
      const gr = p.querySelector('.mm-gr'); gr.addEventListener('wheel', e => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { gr.scrollLeft += e.deltaY; e.preventDefault(); } }, { passive: false });
    }
    function playGame(g) {
      if (g.id === 'squish') { if (opts.onPlay) opts.onPlay('squish', selId()); else toast('Starting Squish Time with ' + (cre() || {}).name + '…'); return; }
      if (opts.onPlay && opts.yardExternal) { opts.onPlay(g.id, selId()); return; }
      const YG = window.YardGames; if (!YG || !YG.mount) { toast('The yard games are still loading…'); return; }
      const c = cre(), B = yb();
      const p = pageOpen('<div class="mm-gp' + (g.land ? ' land' : '') + '"><div class="side"><div style="display:flex;align-items:center;gap:10px"><button class="mm-orb" data-x aria-label="Back to the games">' + ic(BACK, '#fff', 3) + '</button>' + ft(g.name, 'gold', 22) + '</div>'
        + '<div class="bst mm-p v-vel tx-w" style="align-self:flex-start;cursor:default">' + (B[g.id] ? '★ Best ' + B[g.id] : 'First game!') + '</div><div class="bst mm-p v-gold" style="align-self:flex-start;cursor:default">Playing as ' + esc(c ? c.name : '') + '</div></div>'
        + '<div class="mid"></div><div class="side r">' + ft('How to play', 'white', 16) + '<ul class="how">' + (g.how || [g.hint || '']).map(t => '<li>' + esc(t) + '</li>').join('') + '</ul></div></div>');
      p.querySelector('[data-x]').onclick = () => openGames();
      const mid = p.querySelector('.mid');
      try { ygApp = YG.mount(mid); const pick = c && [...mid.querySelectorAll('.yg-pick')].find(b => b.title === c.name); if (pick) pick.click(); const hub0 = ygApp.hub; ygApp.hub = () => { hub0(); setTimeout(() => { if (page && page.contains(mid)) openGames(); }, 0); }; ygApp.play(g); }
      catch (e) { toast('Could not start ' + g.name); }
    }
    // v9: CREATURES first shows the 'creatures' loading screen (cards of your own creatures dealt into a fan) while the picker's card art loads
    function openPicker() {
      if (!Q || busy || inside) return; const SL = window.SquadLoading; if (!SL) { buildPicker(); return; }
      const own = Q.ownedIds(), C4 = window.SQ_CARD4, T = window.SQ_THUMBS || {}, list = own.map(i => Q.ROSTER[i]).filter(Boolean).sort((a, b) => C4 ? C4.byRar(a, b) : 0);
      busy = true; const SETS = SL.SETS || ['pet', 'snack', 'fruit'], mine = list.filter(c => SETS.includes(c.set)), deal = (mine.length >= 5 ? mine : mine.concat(Q.ROSTER.filter(c => SETS.includes(c.set) && c.art && !mine.includes(c)).sort(() => Math.random() - 0.5).slice(0, 8 - mine.length))).slice(0, 12).sort(() => Math.random() - 0.5);
      const ld = SL.show(ov, 'creatures', { sub: own.length + (own.length === 1 ? ' creature' : ' creatures'), cards: deal, z: 40 });
      const urls = []; list.slice(0, 32).forEach(c => { const s = Q.src(c.id), d = C4 ? C4.of(c) : null; urls.push(T[s] || s); if (d) { urls.push(d.cdBg, d.cdFrame); if (d.cdHasName) urls.push(d.cdName); } });
      const U = [...new Set(urls.filter(Boolean))]; let n = 0; const one = () => { n++; ld.set(n / Math.max(1, U.length)); if (n >= U.length) ld.ready(); };
      if (!U.length) ld.ready(); U.forEach(src => { const im = new Image(); im.onload = im.onerror = one; im.src = src; });
      const cap = setTimeout(() => ld.ready(), 7000);
      buildPicker(); const box = ov.querySelector('.mm-pick:last-child'); if (box) box.style.visibility = 'hidden';
      ld.done.then(() => { clearTimeout(cap); busy = false; if (box) box.style.visibility = ''; });
    }
    function buildPicker() {
      if (!Q) return; const own = Q.ownedIds(), cur = selId(), T = window.SQ_THUMBS || {};
      const box = document.createElement('div'); box.className = 'mm-pick mm-crib';
      const C4 = window.SQ_CARD4, list = own.slice().sort((a, b) => C4 ? C4.byRar(Q.ROSTER[a], Q.ROSTER[b]) : a - b);
      const card = id => { const c = Q.ROSTER[id], s = Q.src(id), d = C4 ? C4.of(c) : null; if (!d) return '<button class="it' + (id === cur ? ' on' : '') + '" data-id="' + id + '"><img alt="" style="inset:0;width:100%;height:100%;object-fit:contain" src="' + (T[s] || s) + '"></button>';
        const bx = p => 'left:' + d[p + 'L'] + ';top:' + d[p + 'T'] + ';width:' + d[p + 'W'] + ';height:' + d[p + 'H'];
        return '<button class="it' + (id === cur ? ' on' : '') + '" data-id="' + id + '" aria-label="' + esc(c.name) + '" title="' + esc(c.name) + '"><img alt="" loading="lazy" src="' + d.cdBg + '" style="' + bx('cdBg') + ';object-fit:cover;object-position:center bottom"><img alt="" loading="lazy" src="' + (T[s] || s) + '" style="' + bx('cdArt') + ';object-fit:contain;object-position:center bottom"><img alt="" loading="lazy" src="' + d.cdFrame + '" style="inset:0;width:100%;height:100%">'
          + (d.cdHasName ? '<img alt="" loading="lazy" src="' + d.cdName + '" style="' + bx('cdNm') + ';object-fit:contain">' : '<span class="nmT" style="' + bx('cdNm') + ';color:' + d.cdInk + '">' + esc(c.name) + '</span>') + '</button>'; };
      box.innerHTML = '<div class="box mm-p v-vel" style="transform:scale(' + k + ')">' + gems() + '<div class="hd">' + ft('Your creatures', 'goldB', 22) + ' <small>' + own.length + ' owned · pick who stands in front of your house</small><button class="mm-orb" data-x aria-label="Close">' + ic('M7 7l10 10M17 7L7 17', '#fff', 3) + '</button></div><div class="gr">'
        + list.map(card).join('') + '</div></div>';
      box.onclick = e => { if (e.target === box || e.target.closest('[data-x]')) box.remove(); const b = e.target.closest('[data-id]'); if (b) { preview = null; if (Lb) Lb.select(+b.dataset.id); box.remove(); mountRig(); hudDraw(); testDraw(); } };
      ov.appendChild(box); fitFT(box);
    }

    // ---- v9 the Treasure Shop: a free chest every 4 h + every chest group (today's 3 HOT picks, the season, the rest) with its 5 tiers ----
    const CL = () => window.ChestLoot, DAY = 864e5, FREE_MS = 4 * 3600e3, shopSel = {};
    const dayOf = t => Math.floor((t - new Date(t).getTimezoneOffset() * 60000) / DAY);
    const titled = t => String(t).toLowerCase().replace(/(^|\s)\S/g, c => c.toUpperCase());
    const TCOL = ['#b8744a', '#2f8cff', '#a24bf0', '#f08c00', '#e0459f'], TLET = ['C', 'R', 'E', 'L', '★'];
    function lineupKeys() {   // the same daily HOT picks as Shop v5
      const L = CL(), d = dayOf(Date.now()), keys = L.GROUPS.map(g => g.key).filter(k => k !== 'spooky'); let seed = ((d % 233280) * 9301 + 49297) % 233280; const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
      for (let i = keys.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const t = keys[i]; keys[i] = keys[j]; keys[j] = t; } return keys.slice(0, 3); }
    function shopKeys() { const L = CL(), t = lineupKeys(), rest = L.GROUPS.map(g => g.key).filter(k => k !== 'spooky' && !t.includes(k));
      return t.map(k => ({ k, tag: 'HOT TODAY', cls: 'v-gold' })).concat([{ k: 'spooky', tag: 'SEASON', cls: 'v-bronze' }], rest.map(k => ({ k, tag: '' }))); }
    // a chest drawn once on a canvas (same as Chest Art v2's still render), waits for the chest models to load
    function chestPaint(cv, g, ti) {
      const CM = window.ChestModels; if (!cv.isConnected && cv._tries > 0) return; cv._tries = (cv._tries || 0) + 1;
      if (!CM || !CM.groups.includes(g) || !cv.clientWidth) { if (cv._tries < 200) setTimeout(() => chestPaint(cv, g, ti), 150); return; }
      const w = cv.clientWidth, h = cv.clientHeight, d = Math.min(2, window.devicePixelRatio || 1); cv.width = Math.round(w * d); cv.height = Math.round(h * d);
      const c = cv.getContext('2d'), m = CM.model(g, ti), bb = m.bb, sc = Math.min(w * 0.86 / (bb.x1 - bb.x0), h * 0.8 / (6 - bb.y0)), W2 = (x, y, o) => { o[0] = x; o[1] = y; };
      c.setTransform(d, 0, 0, d, 0, 0); c.translate(w / 2 - (bb.x0 + bb.x1) / 2 * sc, h * 0.9); c.scale(sc, sc);
      if (ti >= 3) { const R = Math.max(m.W, m.H) * 0.75, cy = -m.H * 0.5, gr = c.createRadialGradient(0, cy, 0, 0, cy, R); gr.addColorStop(0, 'rgba(255,255,255,0.5)'); gr.addColorStop(0.4, ti === 4 ? 'rgba(255,159,214,0.35)' : 'rgba(255,216,74,0.35)'); gr.addColorStop(1, 'rgba(255,216,74,0)'); c.fillStyle = gr; c.fillRect(-R, cy - R, R * 2, R * 2); }
      c.save(); c.scale(1, 0.14); const sg = c.createRadialGradient(0, 14, 0, 0, 14, m.W * 0.55); sg.addColorStop(0, 'rgba(42,10,40,0.32)'); sg.addColorStop(1, 'rgba(42,10,40,0)'); c.fillStyle = sg; c.beginPath(); c.arc(0, 14, m.W * 0.55, 0, Math.PI * 2); c.fill(); c.restore();
      try { for (const p of m.parts) window.ChestModels._drawPart(c, p, W2, 0, 0); } catch (e) {}
    }
    const hm = ms => { const m = Math.max(0, Math.ceil(ms / 60000)); return Math.floor(m / 60) + 'h ' + String(m % 60).padStart(2, '0') + 'm'; };
    let shopT = 0;
    function openShop(keepScroll) {
      if (busy || inside) return; const L = CL(); if (!L || !Q) { toast('The shop is still loading…'); return; }
      const SC = window.SquishCoin, Wt = Q.wallet(), now = Date.now(), fr = L.state().freeAt, freeOk = fr == null || fr <= now, fk = lineupKeys()[0], prevX = keepScroll && page && page.querySelector('.mm-sg') ? page.querySelector('.mm-sg').scrollLeft : 0;
      const coin = SC && SC.coin(0) || BL, gem = SC && SC.gem(0) || BL;
      const card = ({ k, tag, cls }) => { const G = L.GK[k], ti = shopSel[k] != null ? shopSel[k] : 0, T = L.TIERS[ti], col = G.ink || '#7a36dc', od = T.odds, sum = od.reduce((a, b) => a + b, 0), ep = Math.round((od[2] + od[3] + od[4]) / sum * 100);
        return '<div class="mm-cc mm-p" data-k="' + k + '" style="--gc:' + col + ';--gcl:' + shade(col, 0.35) + ';--gcd:' + shade(col, -0.45) + '">' + (tag ? '<div class="rib mm-p tip ' + cls + (cls === 'v-gold' ? '' : ' tx-w') + '">' + tag + '</div>' : '')
          + '<div class="nm">' + ft(titled(G.label), 'whiteB', 15) + '</div><div class="win"><canvas data-g="' + k + '" data-t="' + ti + '"></canvas></div>'
          + '<div class="cn">' + esc(T.n) + ' · ' + esc(G.names[ti] || '') + '</div><div class="tiers">' + L.TIERS.map((t, i) => '<button data-ti="' + i + '" class="' + (i === ti ? 'on' : '') + '" aria-label="' + esc(t.n) + '" title="' + esc(t.n) + '" style="background:' + (i === 4 ? 'linear-gradient(135deg,#ff8fd8,#ffe38a,#9ff7c8,#9fd8ff,#d6b3ff)' : 'radial-gradient(circle at 35% 30%,#ffffff 0 10%,' + TCOL[i] + ' 55%,' + shade(TCOL[i], -0.45) + ' 100%)') + '">' + TLET[i] + '</button>').join('') + '</div>'
          + '<div class="od">' + (ep ? 'Epic or better: ' + ep + '%' : 'Common to Legendary') + '</div>'
          + '<button class="go mm-p tip v-gold" data-buy><img alt="" src="' + (T.price.cur === 'gems' ? gem : coin) + '">' + ft(fmt(T.price.n), 'whiteB', 16) + '</button></div>'; };
      const G0 = L.GK[fk];
      const p = pageOpen('<div class="mm-pgh"><button class="mm-orb" data-x aria-label="Back">' + ic(BACK, '#fff', 3) + '</button>' + ft('Treasure Shop', 'goldB', 28) + '<div class="s">Smash a chest open to find new creatures</div><div class="mm-sp"></div>'
        + '<div class="mm-pill mm-p tip v-vel"><img alt="" src="' + coin + '"><span class="tx-w">' + fmt(Wt.coins) + '</span></div><div class="mm-pill mm-p tip v-vel"><img alt="" src="' + gem + '"><span class="tx-w">' + fmt(Wt.gems) + '</span></div></div>'
        + '<div class="mm-sh"><div class="mm-fc mm-p v-vel">' + gems() + '<div class="rib mm-p tip v-gold">FREE CHEST</div><div class="win"><canvas data-g="' + fk + '" data-t="0"></canvas></div>'
        + '<div class="t1">' + esc(titled(G0.label)) + '</div><div class="t2">A Common chest every 4 hours. It might upgrade!</div>'
        + (freeOk ? '<button class="go mm-p tip v-gold" data-free>' + ft('OPEN', 'whiteB', 18) + '</button>' : '<div class="go mm-p tip v-pearl wait"><span>Next in ' + hm(fr - now) + '</span></div>') + '</div>'
        + '<div class="mm-sg">' + shopKeys().map(card).join('') + '</div></div>');
      p.dataset.shop = 1; p.classList.add('mm-crib');
      p.querySelector('[data-x]').onclick = () => { clearInterval(shopT); closePage(); };
      p.querySelectorAll('canvas[data-g]').forEach(cv => chestPaint(cv, cv.dataset.g, +cv.dataset.t));
      const sg = p.querySelector('.mm-sg'); sg.scrollLeft = prevX; sg.addEventListener('wheel', e => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { sg.scrollLeft += e.deltaY; e.preventDefault(); } }, { passive: false });
      // a tier chip redraws just that card (chest picture, name, odds, price)
      function wire(el) { const k = el.dataset.k, b = el.querySelector('[data-buy]'); if (b) b.onclick = () => buyChest(k, shopSel[k] || 0);
        el.querySelectorAll('[data-ti]').forEach(bt => bt.onclick = () => { shopSel[k] = +bt.dataset.ti; const tmp = document.createElement('div'); tmp.innerHTML = card(shopKeys().find(x => x.k === k)); const nw = tmp.firstChild; el.replaceWith(nw); fitFT(nw); wire(nw); chestPaint(nw.querySelector('canvas'), k, shopSel[k]); }); }
      p.querySelectorAll('.mm-cc').forEach(wire);
      const fb = p.querySelector('[data-free]'); if (fb) fb.onclick = () => { L.save({ freeAt: Date.now() + FREE_MS }); openChest(fk, 'common'); };
      clearInterval(shopT); shopT = setInterval(() => { if (!page || !page.dataset.shop) { clearInterval(shopT); return; } const w = page.querySelector('.mm-fc .wait span'), f = CL().state().freeAt; if (w) { if (f <= Date.now()) openShop(true); else w.textContent = 'Next in ' + hm(f - Date.now()); } }, 30000);
    }
    function buyChest(k, ti) {
      const L = CL(), T = L.TIERS[ti]; if (!Q.spend(T.price.cur, T.price.n)) { toast('Not enough ' + T.price.cur + ' yet'); return; }
      openChest(k, T.k);
    }
    function openChest(k, tk) {
      const L = CL(), G = L.GK[k], ti = L.TI[tk] || 0, item = { gk: k, tier: tk, name: G.names[ti] || 'Chest', label: titled(G.label), tierName: L.TIERS[ti].n, roll: t => L.open(k, L.TI[t] != null ? t : tk) };
      if (opts.onChest) opts.onChest(item); else { const rw = item.roll(tk); chestDone(rw); }
    }
    function chestDone(rw) {   // back from the vault: what came out + the shop with the new wallet
      const cr = rw && rw.creature; if (page && page.dataset.shop) openShop(true); hudDraw();
      if (cr) setTimeout(() => toast(rw.isNew ? cr.name + ' joined your squad!' : cr.name + ' again: +' + fmt(rw.dupeCoins) + ' coins'), 250);
    }

    // ---- the trip home: turn round, walk up the path, the door opens, the camera flies in through the doorway ----
    const door = () => scene.querySelector('.mm-door'), dlight = () => scene.querySelector('.mm-doorlight');
    function doorOpen(t) { const d = door(), l = dlight(); if (d) { d.style.transformBox = 'fill-box'; d.style.transformOrigin = '0% 50%'; d.style.transform = 'scaleX(' + (1 - 0.82 * t).toFixed(3) + ') skewY(' + (-6 * t).toFixed(2) + 'deg)'; } if (l) l.setAttribute('opacity', t.toFixed(3)); }
    const fade = on => [hud, hots, name].forEach(e => e.classList.toggle('mm-gone', !on));
    function stageAt(t) { // 0 = on the pad, 1 = in the doorway (smaller, further away)
      if (!geo) return; const x0 = geo.X(500), y0 = geo.Y(421), x1 = geo.X(Sc.DOOR[0]), y1 = geo.Y(300), sc = 1 - 0.74 * t;
      stage.style.transform = 'translate(' + ((x1 - x0) * t).toFixed(1) + 'px,' + ((y1 - y0) * t).toFixed(1) + 'px) scale(' + sc.toFixed(3) + ')';
    }
    async function goHome(room) {
      if (busy || inside || !geo) return; busy = true; closePage(); ov.querySelectorAll('.mm-pick').forEach(e => e.remove()); fade(false);
      if (sh) sh.stop(); if (ctrl) ctrl.play('idle'); const I = ctrl && ctrl._I, s0 = I ? I.spinOff || 0 : 0;
      await tween(430, e => { if (I) I.spinOff = s0 + 180 * e; });
      stage.classList.add('walk');
      await tween(1250, (e, t) => { stageAt(e); doorOpen(Math.max(0, Math.min(1, (t - 0.35) / 0.45))); stage.style.opacity = t > 0.84 ? Math.max(0, 1 - (t - 0.84) / 0.16) : 1; });
      stage.classList.remove('walk');
      const flyIn = () => tween(900, (e, t) => { world.style.transform = 'scale(' + (1 + 5.2 * e).toFixed(3) + ')'; veil.style.opacity = t > 0.45 ? Math.min(1, (t - 0.45) / 0.5).toFixed(3) : 0; }, easeIn);
      const SL = window.SquadLoading;
      if (SL && SL.v >= 2 && opts.onHome) {   // v10: the real house at night is the loading screen, then the fly-in
        const N = nightLights(), names = N ? N.rooms.map(k => Sc.ROOMS[k].n) : [];
        const ld = SL.show(ov, 'house', { art: false, z: 30, expect: 3600, tick: p => { if (N) N.at(p); }, exit: flyIn });
        opts.onHome(room || 'living', frame.getBoundingClientRect(), ld);
        await ld.done;
        veil.style.pointerEvents = 'auto'; inside = true; busy = false; if (opts.onHomeIn) opts.onHomeIn();
        return;
      }
      await flyIn();
      veil.style.pointerEvents = 'auto'; inside = true; busy = false;
      const r = frame.getBoundingClientRect();
      if (opts.onHome) opts.onHome(room || 'living', r); else { toast('Welcome home! (the house opens here in the full app)'); setTimeout(back, 1400); }
    }
    // v10: night on the real house + its open rooms' lights, driven by the loading progress (at(p)); removed by back()
    const LORDER = ['living', 'kitchen', 'bathroom', 'bedroom', 'movie', 'dance', 'backyard'];
    function nightLights() {
      const svg = scene.querySelector('svg'); if (!svg || !st) return null; const NS = 'http://www.w3.org/2000/svg', u = 'mmn' + (++UID);
      const mk = (tag, a, par) => { const e = document.createElementNS(NS, tag); Object.keys(a).forEach(k => e.setAttribute(k, a[k])); if (par) par.appendChild(e); return e; };
      const old = svg.querySelector('.mm-night'); if (old) old.remove();
      const g = mk('g', { class: 'mm-night', 'pointer-events': 'none' }, svg);
      g.innerHTML = '<defs><radialGradient id="' + u + 'b"><stop offset="0" stop-color="#ffd98a" stop-opacity="0.7"/><stop offset="0.5" stop-color="#ffb84a" stop-opacity="0.22"/><stop offset="1" stop-color="#ffb84a" stop-opacity="0"/></radialGradient>'
        + '<radialGradient id="' + u + 'p" cx="0.5" cy="0.42" r="0.75"><stop offset="0" stop-color="#fffbe6"/><stop offset="0.45" stop-color="#ffe08a"/><stop offset="1" stop-color="#f0a040"/></radialGradient>'
        + '<filter id="' + u + 'f" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="3.2"/></filter></defs>';
      const dk = mk('rect', { x: -60, y: -20, width: 1120, height: 500, fill: '#100a32', opacity: 0 }, g);
      const sky = mk('g', { opacity: 0 }, g); let sk = ''; for (let i = 0; i < 34; i++) { const x = (i * 131.7 + 37) % 1000, y = 8 + (i * 47) % 150; sk += '<circle cx="' + x.toFixed(0) + '" cy="' + y + '" r="' + (0.9 + (i % 3) * 0.6) + '" fill="#fff6d8" opacity="' + (0.5 + (i % 4) * 0.15) + '"/>'; }
      sky.innerHTML = sk + '<path d="M878 40 a26 26 0 1 0 22 44 a21 21 0 1 1 -22 -44Z" fill="#fff3c8" opacity="0.95"/>';
      const suns = [...svg.querySelectorAll('[fill*="Sun)"], circle[cy="70"][filter]')]; suns.slice().forEach(e => { const n = e.nextElementSibling; if (n && n.tagName === 'circle' && n.getAttribute('cx') === e.getAttribute('cx')) suns.push(n); });   // the sun sets as night falls (back() redraws nothing - it just clears the styles)
      const svgM = svg.getScreenCTM(), inv = svgM ? svgM.inverse() : null, groups = {};
      const roomOf = (cx, cy) => Object.keys(Sc.AREAS).find(k => { const [x, y, w, h] = Sc.AREAS[k]; return cx >= x && cx <= x + w && cy >= y && cy <= y + h; });
      const box = el => { try { const b = el.getBBox(), m = inv && el.getScreenCTM() ? inv.multiply(el.getScreenCTM()) : null; if (!m) return b; const P = (x, y) => new DOMPoint(x, y).matrixTransform(m), c = [P(b.x, b.y), P(b.x + b.width, b.y), P(b.x, b.y + b.height), P(b.x + b.width, b.y + b.height)];
        const xs = c.map(q => q.x), ys = c.map(q => q.y); return { x: Math.min(...xs), y: Math.min(...ys), width: Math.max(...xs) - Math.min(...xs), height: Math.max(...ys) - Math.min(...ys) }; } catch (e) { return null; } };
      const room = k => groups[k] || (groups[k] = mk('g', { opacity: 0, style: 'transition:opacity .45s ease' }, g));
      // v12 (user: 'the lights appear as squares, not merged well to the windows'): every open window is lit IN ITS OWN SHAPE - the light is clipped
      // by the window's own clip path (round / arched / square), drawn in the window's own coordinates (its matrix to the root), the window's bars
      // are copied back on top of the light, and a soft blurred glow spills round it (no hard-edged boxes)
      svg.querySelectorAll('[clip-path]').forEach(el => { const m = /url\(#([^)]+)\)/.exec(el.getAttribute('clip-path') || ''); if (!m || !/_w\d+_\d+$/.test(m[1])) return; const b = box(el); if (!b || b.width < 4) return;
        const k = roomOf(b.x + b.width / 2, b.y + b.height / 2); if (!k || !st.open[k]) return; const R = room(k), cx = b.x + b.width / 2, cy = b.y + b.height / 2;
        mk('ellipse', { cx, cy, rx: b.width * 1.15 + 6, ry: b.height * 1.05 + 6, fill: 'url(#' + u + 'b)' }, R);
        let M = null; try { M = inv && el.getScreenCTM() ? inv.multiply(el.getScreenCTM()) : null; } catch (e) {}
        const G = mk('g', M ? { transform: 'matrix(' + [M.a, M.b, M.c, M.d, M.e, M.f].map(v => +v.toFixed(4)).join(' ') + ')' } : {}, R); let lb = null; try { lb = el.getBBox(); } catch (e) {} if (!lb) return;
        const C = mk('g', { 'clip-path': 'url(#' + m[1] + ')' }, G);
        mk('rect', { x: lb.x - 3, y: lb.y - 3, width: lb.width + 6, height: lb.height + 6, fill: 'url(#' + u + 'p)', filter: 'url(#' + u + 'f)', opacity: 0.95 }, C);
        mk('rect', { x: lb.x - 1, y: lb.y + lb.height * 0.62, width: lb.width + 2, height: lb.height * 0.4, fill: '#c8782a', opacity: 0.35 }, C);
        let n = el.nextElementSibling; for (let j = 0; j < 2 && n && n.tagName === 'path' && n.getAttribute('stroke') && !n.getAttribute('fill'); j++, n = n.nextElementSibling) G.appendChild(n.cloneNode(true)); });
      // the open front door glows with the Living Room (its own arched light shape, copied); rooms with no window found (the Dance Room dome, the Backyard) get a soft glow over their area
      const dl = svg.querySelector('.mm-doorlight'), db = dl && box(dl); if (db) { const R = room('living'); mk('ellipse', { cx: db.x + db.width / 2, cy: db.y + db.height * 0.6, rx: db.width * 1.4, ry: db.height * 0.8, fill: 'url(#' + u + 'b)' }, R);
        let M = null; try { M = inv && dl.getScreenCTM() ? inv.multiply(dl.getScreenCTM()) : null; } catch (e) {} const D = dl.cloneNode(true); D.removeAttribute('class'); D.setAttribute('fill', 'url(#' + u + 'p)'); D.setAttribute('opacity', '0.95'); D.style.opacity = '';
        const G = mk('g', M ? { transform: 'matrix(' + [M.a, M.b, M.c, M.d, M.e, M.f].map(v => +v.toFixed(4)).join(' ') + ')' } : {}, R); G.appendChild(D); }
      const list = LORDER.filter(k => st.open[k]);
      list.forEach(k => { if (!groups[k]) { const [x, y, w, h] = Sc.AREAS[k], R = room(k); mk('ellipse', { cx: x + w / 2, cy: y + h * 0.55, rx: w * 0.55, ry: h * 0.5, fill: 'url(#' + u + 'b)' }, R); } });
      g._suns = suns;
      // v13 'Back outside': the morning after - dawn(q): 0 = this night (as at(1) left it), 1 = day again; end() takes the night + the dawn away
      const rain = st.season === 'rainy', snow = st.season === 'snowy', moon = sky.lastChild; let dz = null, bz = null;
      const R = (q, a, b) => { const t = Math.max(0, Math.min(1, (q - a) / (b - a))); return t * t * (3 - 2 * t); };
      function dawnBuild() {   // behind the house, right over the sky: a pink + gold glow on the horizon and a low orange sun (the scene's own sun rises over it)
        const sr = svg.querySelector('rect[fill$="Sky)"]'); if (!sr) return; dz = mk('g', { class: 'mm-dawn', 'pointer-events': 'none' }); sr.parentNode.insertBefore(dz, sr.nextSibling);
        const hz = rain ? [[0, '#8a7a9a', 0], [0.6, '#b89aa8', 0.45], [1, '#d8b8a8', 0.75]] : snow ? [[0, '#a898d8', 0], [0.55, '#f0b0c8', 0.5], [1, '#ffe0c0', 0.9]] : [[0, '#7a5aa8', 0], [0.5, '#e88aac', 0.55], [0.8, '#ffa86a', 0.9], [1, '#ffd88a', 1]];
        const cx = suns.length ? +suns[0].getAttribute('cx') || 150 : 150;
        dz.innerHTML = '<defs><linearGradient id="' + u + 'h" x1="0" y1="0" x2="0" y2="1">' + hz.map(([o, c, a]) => '<stop offset="' + o + '" stop-color="' + c + '" stop-opacity="' + a + '"/>').join('') + '</linearGradient>'
          + '<radialGradient id="' + u + 's"><stop offset="0" stop-color="#fff0c0"/><stop offset="0.3" stop-color="#ffb060" stop-opacity="0.8"/><stop offset="1" stop-color="#ff8a50" stop-opacity="0"/></radialGradient></defs>'
          + '<rect class="hz" x="-60" y="-20" width="1120" height="250" fill="url(#' + u + 'h)" opacity="0"/>'
          + (suns.length && !rain ? '<g class="ds" opacity="0"><circle cx="' + cx + '" cy="70" r="80" fill="url(#' + u + 's)"/><circle cx="' + cx + '" cy="70" r="25" fill="#ffa64a"/></g>' : '');
      }
      function birds() {   // three little birds cross the sky (in front of the clouds, behind the sea + the house); they finish their flight after the screen has gone
        const sea = svg.querySelector('rect[fill$="Sea)"]'); if (!sea) return; bz = mk('g', { class: 'mm-birds', 'pointer-events': 'none' }); sea.parentNode.insertBefore(bz, sea);
        bz.innerHTML = [[0, 92, 1], [0.7, 78, 0.8], [1.5, 104, 0.9]].map(([d, y, s]) => '<g class="mm-bird" style="animation-delay:' + d + 's"><g transform="translate(0 ' + y + ') scale(' + s + ')"><path d="M-7 0 Q-3.5 -5 0 0 Q3.5 -5 7 0" fill="none" stroke="#4a3a5e" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><animateTransform attributeName="transform" type="scale" values="1 1;1 -0.5;1 1" dur="0.46s" begin="' + (d * 0.37).toFixed(2) + 's" repeatCount="indefinite"/></path></g></g>').join('');
        setTimeout(() => { if (bz) bz.remove(); }, 11000);
      }
      let wash = null;   // the morning light: a rosy-gold veil over the whole scene, strongest in the middle of the dawn (on top, with the night)
      function dawn(q) {
        if (!dz) dawnBuild(); const day = R(q, 0.1, 0.92);
        if (!wash) { wash = mk('rect', { x: -60, y: -20, width: 1120, height: 500, fill: 'url(#' + u + 'w)', opacity: 0 }, g); const d = g.querySelector('defs'); if (d) d.insertAdjacentHTML('beforeend', '<linearGradient id="' + u + 'w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + (rain ? '#c8a8c8' : '#ff8fbf') + '"/><stop offset="0.45" stop-color="' + (rain ? '#d8b8b0' : '#ffb08a') + '" stop-opacity="0.8"/><stop offset="1" stop-color="' + (rain ? '#e0c8a8' : '#ffd890') + '" stop-opacity="0.35"/></linearGradient>'); }
        wash.setAttribute('opacity', (Math.sin(Math.PI * R(q, 0.05, 1)) * (rain ? 0.16 : 0.26)).toFixed(3));
        dk.setAttribute('opacity', (0.6 * (1 - day)).toFixed(3)); dk.setAttribute('fill', Sc.mix('#100a32', '#4a2266', R(q, 0.05, 0.55)));   // the night blue warms to a rosy violet as it lifts
        sky.setAttribute('opacity', (1 - R(q, 0.04, 0.5)).toFixed(3)); if (moon) moon.setAttribute('transform', 'translate(0 ' + (70 * R(q, 0.04, 0.6)).toFixed(1) + ')');
        const hzE = dz && dz.querySelector('.hz'); if (hzE) hzE.setAttribute('opacity', (Math.sin(Math.PI * R(q, 0.06, 1)) * (rain ? 0.6 : 0.95)).toFixed(3));
        const up = 1 - Math.pow(1 - R(q, 0.12, 0.95), 2), ty = (175 * (1 - up)).toFixed(1);   // from behind the sea (the horizon is y 214) up to its place
        suns.forEach(e => { e.style.transform = 'translateY(' + ty + 'px)'; e.style.opacity = R(q, 0.3, 0.9).toFixed(3); });
        const ds = dz && dz.querySelector('.ds'); if (ds) { ds.setAttribute('transform', 'translate(0 ' + ty + ')'); ds.setAttribute('opacity', (R(q, 0.08, 0.3) * (1 - R(q, 0.55, 0.95))).toFixed(3)); }
        const n = list.length; list.forEach((k, i) => { const on = q < 0.22 + 0.6 * (n - i) / (n + 1); if (groups[k] && groups[k]._on !== on) { groups[k]._on = on; groups[k].style.opacity = on ? 1 : 0; } });   // the last room to light up goes dark first, the Living Room last
        if (!bz && !rain && q >= 0.4) birds();
      }
      return { rooms: list, dawn, end() { g.remove(); if (dz) dz.remove(); suns.forEach(e => { e.style.opacity = ''; e.style.transform = ''; }); }, at(p) { const n = Math.min(1, p / 0.2); dk.setAttribute('opacity', (0.6 * n * n * (3 - 2 * n)).toFixed(3)); suns.forEach(e => { e.style.opacity = (1 - n).toFixed(3); }); sky.setAttribute('opacity', Math.max(0, Math.min(1, (p - 0.06) / 0.2)).toFixed(3));
        list.forEach((k, i) => { const on = p >= window.SquadLoading.roomAt(i, list.length); if (groups[k] && groups[k]._on !== on) { groups[k]._on = on; groups[k].style.opacity = on ? 1 : 0; } }); } };
    }
    // v13 (user: 'a loading screen for when I go back to the main home screen'): leaving the house = SquadLoading 'menu' "Back outside" over this scene
    async function back(o) {
      o = o || {}; if (!inside || busy) return; busy = true; inside = false; veil.style.pointerEvents = 'none'; let I = ctrl && ctrl._I;
      const SL = window.SquadLoading;
      const pullOut = () => tween(850, (e, t) => { world.style.transform = 'scale(' + (1 + 5.2 * (1 - e)).toFixed(3) + ')'; veil.style.opacity = Math.max(0, 1 - t / 0.55).toFixed(3); }, easeOut);
      const walkOut = async () => {   // out of the open door, down the path, turn round to face you
        world.style.transform = ''; stage.classList.add('walk');
        await tween(1100, (e, t) => { stageAt(1 - e); stage.style.opacity = Math.min(1, t / 0.16).toFixed(3); doorOpen(Math.max(0, 1 - t / 0.7)); });
        stage.classList.remove('walk'); doorOpen(0); stage.style.transform = ''; stage.style.opacity = '';
        I = ctrl && ctrl._I; const s0 = I ? I.spinOff || 0 : 0; await tween(430, e => { if (I) I.spinOff = s0 + 180 * e; }); if (I) I.spinOff = 0;
      };
      const settle = () => { fade(true); busy = false; if (sh && ctrl) sh.attach(ctrl); if (ctrl) ctrl.play('happy'); };
      if (!SL || !(SL.v >= 4) || o.loading === false) {   // the old quick way back (no loading screen)
        const nl = scene.querySelector('.mm-night'); if (nl) { (nl._suns || []).forEach(e => { e.style.opacity = ''; }); nl.remove(); }   // day again (the veil still covers the scene here)
        await pullOut(); await walkOut(); settle(); return;
      }
      let D = null;
      // the dawn follows the bar, but never faster than ~1.9 s from when the camera is nearly out of the door, so the morning always has time to come
      const ld = SL.show(ov, 'menu', { art: false, z: 30, min: 2700, expect: 2200, title: o.title, sub: o.sub, tips: o.tips,
        tick: (p, t) => { if (D) D.dawn(Math.min(p, Math.max(0, (t - 0.6) / 1.9))); }, exit: async () => { if (D) D.dawn(1); await walkOut(); } });
      // the load: redraw the house front from the current level / season (+ the creature if another one was picked inside), back to the night we left,
      // the door still open and the creature (not seen yet) just inside it, facing the house
      const key0 = curKey; draw(); layout(); mountRig(); if (curKey !== key0) { if (sh) sh.stop(); if (ctrl) ctrl.play('idle'); I = ctrl && ctrl._I; if (I) I.spinOff = 180; }
      doorOpen(1); stageAt(1); stage.style.opacity = 0; D = nightLights(); if (D) D.at(1);
      if (o.load) o.load(ld); else ld.set(0.35);
      const tl = performance.now(); await pullOut(); if (!o.load) { ld.set(0.85); setTimeout(() => ld.ready(), Math.max(0, 1500 - (performance.now() - tl))); }   // loaded: the bar fills as the sun comes up
      await ld.done; if (D) D.end(); settle();
    }
    // v13: start 'Back outside' from inside the house without the trip in (the Loading Screens page): the creature just inside the open door, the camera in it
    function jumpIn() {
      if (busy || inside || !geo) return false; closePage(); ov.querySelectorAll('.mm-pick').forEach(e => e.remove()); fade(false); if (sh) sh.stop(); if (ctrl) ctrl.play('idle');
      const I = ctrl && ctrl._I; if (I) I.spinOff = (I.spinOff || 0) + 180; stageAt(1); stage.style.opacity = 0; doorOpen(1);
      world.style.transform = 'scale(6.2)'; veil.style.opacity = 1; veil.style.pointerEvents = 'auto'; inside = true; return true;
    }

    // ---- the game intro (Nov 14, squad-intro.js "Squish wakes the house"): it plays on this same scene with Mittens, then hands the menu back ----
    const HOUSE_ROOMS = ['living', 'kitchen', 'bedroom', 'bathroom', 'movie', 'dance'];
    function introSvg(o) { const s = Sc.state(o); HOUSE_ROOMS.forEach(r => { s.open[r] = true; }); return Sc.svg(s); }   // every window open: the story lights them up
    let intro = null;
    function startIntro() {
      if (intro || busy || inside || !window.SquadIntro || !geo) return false;
      busy = true; closePage(); ov.querySelectorAll('.mm-pick').forEach(e => e.remove()); fade(false); if (test) test.style.visibility = 'hidden';
      const prev = preview, mi = Q ? Q.ROSTER.findIndex(c => c.key === 'mittens') : -1;
      if (mi >= 0 && (!cre() || cre().key !== 'mittens')) { preview = mi; mountRig(); }
      if (sh) sh.stop(); if (ctrl) ctrl.play('idle');
      intro = window.SquadIntro.run({ frame, world, scene, stage, Sc, geo: () => geo, ctrl: () => ctrl, light: L => { if (ctrl && ctrl.light) ctrl.light(L); }, lightFor, sceneSvg: introSvg,
        finish: () => { intro = null; preview = prev; busy = false; if (test) test.style.visibility = ''; draw(); layout(); mountRig(); lightRig(); fade(true); if (sh && ctrl) sh.attach(ctrl); if (ctrl) ctrl.play('happy'); if (opts.onIntroDone) opts.onIntroDone(); } });
      return true;
    }

    // ---- test controls (design view only) ----
    function testDraw() {
      if (!test || !st) return; const c = cre();
      test.innerHTML = '<b>TEST CONTROLS</b><button data-intro style="background:#ffd650;color:#3d1268;font-weight:800">▶ Intro</button><span>Level</span><button data-l="-1">−</button><input value="' + st.L + '"><button data-l="1">+</button>'
        + '<span>Season</span>' + ['auto', 'sunny', 'rainy', 'snowy'].map(s => '<button data-s="' + s + '" class="' + (season === s ? 'on' : '') + '">' + s[0].toUpperCase() + s.slice(1) + '</button>').join('')
        + '<span>Creature</span><button data-c="-1">◀</button><span class="nm">' + (c ? esc(c.name) : '') + (preview != null ? ' (preview)' : '') + '</span><button data-c="1">▶</button>';
      const setL = n => { n = Math.max(1, Math.min(30, n | 0)); try { window.SquishProfile && window.SquishProfile.set({ level: n }); } catch (e) {} draw(); };
      test.querySelector('[data-intro]').onclick = () => startIntro();
      test.querySelectorAll('[data-l]').forEach(b => b.onclick = () => setL(st.L + +b.dataset.l));
      const inp = test.querySelector('input'); inp.onchange = () => setL(+inp.value); inp.onkeydown = e => { if (e.key === 'Enter') setL(+inp.value); };
      test.querySelectorAll('[data-s]').forEach(b => b.onclick = () => { season = b.dataset.s; save(); draw(); });
      test.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { const n = Q.ROSTER.length; preview = ((selId() + +b.dataset.c) % n + n) % n; mountRig(); hudDraw(); testDraw(); });
    }

    const onWallet = () => { if (!busy && !inside) hudDraw(); }, onProf = () => { if (!busy && !inside) draw(); }, onSel = () => { if (preview == null && !busy && !inside) mountRig(); hudDraw(); };
    window.addEventListener('squishsquad', onWallet); window.addEventListener('squishcoin', onWallet); window.addEventListener('squishprofile', onProf); window.addEventListener('squadlobby', onSel);
    let ro = null; if (window.ResizeObserver) { ro = new ResizeObserver(() => layout()); ro.observe(frame); } else window.addEventListener('resize', layout);
    draw(); layout(); mountRig();
    if (opts.intro) startIntro();
    const iv =setInterval(() => { if (season === 'auto' && !busy && !inside) { const s0 = st && st.season; const s1 = Sc.state({ level: level() }).season; if (s0 !== s1) draw(); } }, 60000);
    return { destroy() { clearInterval(iv); closePage(); if (sh) sh.stop(); if (ctrl) ctrl.destroy(); if (ro) ro.disconnect(); window.removeEventListener('squishsquad', onWallet); window.removeEventListener('squishcoin', onWallet); window.removeEventListener('squishprofile', onProf); window.removeEventListener('squadlobby', onSel); host.innerHTML = ''; },
      back, jumpIn, home: goHome, games: openGames, shop: openShop, chestDone, intro: startIntro, skipIntro: () => intro && intro.finish(), frame: () => frame, _st: () => st, _ctrl: () => ctrl, _geo: () => geo, _busy: () => busy, _inside: () => inside };
  }
  window.MainMenu = { v: 13, mount, ft, crest, fitFT };
})();
