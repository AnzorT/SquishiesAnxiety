# Yard Mini Games: handoff package

There are seven backyard mini games for Squish Squad, each starring the player's own creature (the real animated rig):

- Hoop Shot
- Penalty Kick
- Hopscotch
- Bounce Up
- Slide & Splash
- Cornhole
- Ping-Pong

There is also a hub with a creature picker and game cards, an intro poster for each game, and a results screen. Everything is plain JavaScript that draws with SVG and DOM. There is no framework and no build step.

The `app/` folder is a complete, working copy: the page, every script it loads, and every image it requests. It was tested by serving `app/` on its own and playing every game with several creatures, with no missing files and no errors.

## Quick start

```
cd app
python3 -m http.server 8000
# open http://localhost:8000/yard-mini-games.html
```

There are two pages, and both run the same games:

| Page | What it is |
|---|---|
| `yard-mini-games.html` | **Use this one to integrate.** A plain HTML page: the styles, the script tags in load order, and a 10-line mount script. It needs no React. |
| `Yard Mini Games.dc.html` | The original page from the design-canvas project. It needs `support.js`, which loads React 18.3.1 and ReactDOM from unpkg. It is only a wrapper, and the games don't use React. |

The only network dependency is Google Fonts (Fredoka and Nunito). Without it, the system font is used.

## Folder map

```
yard-mini-games/
  README.md          this file
  NOTES.md           the design and change log (why each game looks and plays the way it does)
  reference/
    main-menu.js     the Main Menu page's code; its "Mini Games" page embeds these games (see "Embedding" below)
  app/
    yard-mini-games.html, Yard Mini Games.dc.html, support.js
    -- the mini games (the actual feature) --
    yard-games.js    the framework: hub, stage, input, HUD, particles, sound, intro and results screens, saving
    yg-intros.js     the intro poster of each game (an SVG still with the real rig posed in it)
    yg-hoop.js       Hoop Shot      (id 'hoop')
    yg-soccer.js     Penalty Kick   (id 'soccer')
    yg-hop.js        Hopscotch      (id 'hop')
    yg-tramp.js      Bounce Up      (id 'tramp')
    yg-slide.js      Slide & Splash (id 'slide')
    yg-corn.js       Cornhole       (id 'corn')
    yg-pong.js       Ping-Pong      (id 'pong')
    -- the creature system the games need (shared with the rest of the app) --
    creatures-v2.js                           window.CREATURES_V2 / SquishMoves: the creature catalogue
    squad-store.js                            window.SquishSquad: the roster + store (ROSTER, src(id), wallet(), add(cur, n) ...)
    export/thumbs/thumbs.js + *.webp          window.SQ_THUMBS: raster thumbnails for the picker strip
    export/cards4/names.js, cards4.js         window.SQ_NAMES / SQ_CARD4: creature name + card data
    export/tripo/<key>/<key>-front.svg        front art the generic rigs are drawn from
    plush-rig25.js (window.Rig25), rive-rig.js (window.RiveRig): the creature rig (RiveRig.mount(el, key, {look}), poses through ext channels)
    rive-generic.js, snack-3d.js, fruit-3d.js window.RiveGeneric + the 3D-ish part builders
    pet-defs.js, pet2-defs.js                 Pet Shop creature definitions
    house-*.js, mittens-moves.js              moves; house-walk.js = window.HouseWalk (the walk / run gait the games use)
    *-anims.js, *-pokes.js, *-eats.js, *-house.js, ocean-anims.js, whip-spin.js
                                              per-set animation states (idle, happy, surprised ... used by c.play(name))
```

**Load order matters.** Keep the script order of `yard-mini-games.html`: the creature system first, then `yard-games.js`, then `yg-intros.js`, then the seven games. Each file is a self-running script that puts its result on `window`. The game files retry with `setTimeout` until `yard-games.js` is there, and the creature system files expect this order.

## How it fits together

- **Mounting:** `window.YardGames.mount(el)` builds the hub in `el` and returns `app`:
  - `app.hub()` shows the hub;
  - `app.play(G)` starts a game, where `G` is an entry of `YardGames.GAMES`.

  The page calls it only once these are ready: `SquishSquad`, `RiveRig` (with `RiveRig.GROUPS`), `RiveGeneric`, `HouseWalk`, and 7 entries in `YardGames.GAMES`.
- **Registering a game:** each game file registers with `YardGames.add({...})`. If two registrations use the same `id`, the second replaces the first.
- **Stage and layers:** the stage is landscape, **780 × 360** stage units, scaled to fit a frame with a 780/360 aspect ratio. Its layers, from bottom to top:
  1. the `bg` svg;
  2. the creature layer (`.yg-crl`): rig host divs;
  3. the `fg` svg;
  4. the HUD (top bar, score, timer, hint);
  5. the input layer (pointer events);
  6. overlays (intro poster and sheet, results).

  A creature with a positive `depth()` (CSS z-index) draws above `fg`. Penalty Kick uses this, and adds its own svg layers above and below its keeper.
- **3D look:** each game projects its own small 3D scene with `YardGames.cam(Dc, CH, HY, K)`, which returns `(x, y, z) => [screenX, screenY, scale]`. The parameters are camera distance, camera height, horizon y and scale. Each game file's header records its camera numbers.
- **Who plays:** players and opponents come from the roster filtered to `YardGames.SETS = ['snack', 'fruit', 'pet']`.
- **Saving:** `localStorage['yardgames.v1']` holds `{ best: {gameId: score}, player: creatureId, plays: {gameId: n} }`, and `yardgames.v1.mute` holds the mute setting.
- **Sound:** small synthesized effects through WebAudio (`YardGames.SFX`). There are no audio files.

### A game module (the contract)

```js
YardGames.add({
  id: 'soccer', land: true,               // land: true = the landscape 780 x 360 stage (all 7 games are landscape)
  name: 'Penalty Kick', item: 'Soccer Goal', color: '#5cc2ff', icon: '<svg ...>',   // hub card
  dur: 45,                                 // optional countdown in seconds (otherwise the game ends itself)
  stars: [250, 450, 700], coinK: 0.06,     // star thresholds; coins = score * coinK
  hint: '...', how: ['...', '...'],        // in-game hint line; the how-to-play bullets
  options: [{ id, label }],                // optional (shown on the intro sheet, passed to inst.option(id))
  make(ctx) { /* build the scene */ return api; }
});
```

**What `make()` returns (`api`)**:

- `start()`: called when the player presses Play.
- `update(dt, t)`: called every frame; `dt` is in seconds and `t` is the `requestAnimationFrame` time in ms.
- `down(p)`, `move(p)`, `up(p)`: pointer events, with `p = {x, y}` in stage units.
- `key(k, isDown)`: keyboard events; return `true` to prevent the browser's default.
- `timeUp()`: called when the countdown ends.
- `celebrate(stars)`: called on the results screen.
- `destroy()`: called when leaving the game.
- Optional test hooks prefixed with `_`, such as `_aim` and `_shoot`.

**What `ctx` provides**:

- `W` and `H`; the layers `bg`, `fg` and `crl`; the helpers `S(tag, attrs, parent)` (SVG) and `D(...)` (DOM); `YG`; `SFX`.
- `creature(key, opts)`: returns a creature, `c`. Its methods:
  - `c.set(x, y, size)`;
  - `c.pose({ext channels})`;
  - `c.play('idle' | 'happy' | 'surprised' ...)`;
  - `c.yaw(deg)`, where 0 means facing you and 180 means facing away;
  - `c.rot(deg, ox, oy)`;
  - `c.walk(dt, w, spin)`;
  - `c.depth(z)` and `c.hide()`.
- `playerKey`, `playerName`, `opponent(n)` and `nameOf(key)`.
- Score and HUD: `score`, `add(points, x, y, text, color)`, `setScore(n)`, `timer(text)`, `hint(text)` and `toast(text, x, y, color, big)`.
- Particles: `burst(x, y, 'spark' | 'star' | 'drop' | 'dust' | 'confetti', n, {v, life, col, layer, dir, spread})`.
- `finish({sub, title})`: ends the game and shows the results.
- `playing`: whether the game is running.

**Rig ext channels** are the pose numbers a game sets, added on top of the playing animation. The main ones:

- `armL`/`armR`: arm angle, where 0 is down and 160+ is up by the face;
- `hLx`/`hLy`/`hRx`/`hRy`: hand offsets that stretch an arm out;
- `lean`, `tilt`, `sq` (squash), `lift`, `footL`/`footR`;
- face: `smile`, `open` (mouth), `hap` (happy closed eyes), `teary`, `sqz` (><), `cross`;
- `sit`.

## Embedding in the app (how the Main Menu does it)

`reference/main-menu.js`, in `playGame(g)` around line 432, mounts the hub into its own panel and starts the chosen game:

```js
ygApp = YardGames.mount(mid);                                  // mid = the panel element
const pick = [...mid.querySelectorAll('.yg-pick')].find(b => b.title === creature.name); if (pick) pick.click();   // play as the selected creature
const hub0 = ygApp.hub; ygApp.hub = () => { hub0(); /* back to the menu's own games list */ };
ygApp.play(game);                                              // game = an entry of YardGames.GAMES
```

The Mini Games page wraps it in `.mm-gp.land`, so a landscape game fills the page.

## Integration notes and to-dos

- **Coins are only a preview.** The results card shows `+N coins (preview)`, where `N = max(1, round(score * coinK))`; see `results()` in `yard-games.js`. Nothing is added to the wallet. To pay out, call `window.SquishSquad.add('coins', N)` there. That is the store's own API; `wallet()` reads the balance.
- **Each game file is self-contained.** You can drop one, or add one, by removing or adding its script tag. The mount check in the page waits for `GAMES.length >= 7`, so change that number to match.
- **Ports to other platforms:** the logic is plain JS with clear seams:
  - physics and simulation in each `make()`;
  - drawing through `S()` into the layers;
  - the rig through `ctx.creature`.

  Each file's header comment lists its camera, sizes and tuning numbers, and NOTES.md has the history.
- **Cache-busting:** the `?v=` on each script tag is a cache-buster. Bump it when a file changes.
